"""Reset sequencing: initial reset, scheduled pulses, state-triggered pulses and mid-cycle async pulses.

Cycle convention: ``drive()`` in cycle ``c`` decides the reset level that is present *during* the
interval before rising edge ``c+1``.  A pulse (start, length) therefore is asserted for the length
edges ``start+1 .. start+length``.  Agents receive ``on_reset(True/False)`` from the Env in the same
cycle the level changes, and ``env.in_reset`` is the level currently being driven.
"""
from __future__ import annotations

import random
from typing import Callable, List, Optional, Tuple

from .core import Agent, Env, Sig


class ResetSequencer(Agent):
    def __init__(self, name: str, rst: Sig, active_low: bool = True, initial_cycles: int = 4):
        super().__init__(name)
        self.rst = rst
        self.active = 0 if active_low else 1
        self.inactive = 1 - self.active
        self.asserted = True
        self._sched: List[Tuple[int, int]] = [(0, initial_cycles)]
        self._armed: List[Tuple[Callable[[], bool], int, str]] = []
        self.n_pulses = 0
        self.log: List[Tuple[int, int, str]] = []  # (cycle, length, reason)
        rst.write(self.active)

    def attach(self, env: Env) -> None:
        super().attach(env)
        self.env.in_reset = True

    # ---- scheduling
    def at(self, cycle: int, length: int, reason: str = "scheduled") -> None:
        self._sched.append((cycle, cycle + length))
        self.log.append((cycle, length, reason))

    def pulse(self, length: int = 2, delay: int = 1, reason: str = "pulse") -> None:
        self.at(self.env.cycle + delay, length, reason)

    def random_pulse(self, rng: random.Random, lo: int, hi: int, length=(1, 3), reason: str = "random") -> int:
        start = self.env.cycle + rng.randint(lo, hi)
        self.at(start, rng.randint(*length), reason)
        return start

    def arm(self, predicate: Callable[[], bool], length: int = 2, reason: str = "triggered") -> None:
        """Assert reset on the first drive() where ``predicate()`` is true (e.g. 'DMA is mid-transfer')."""
        self._armed.append((predicate, length, reason))

    @property
    def disarmed(self) -> bool:
        return not self._armed

    # ---- agent
    def drive(self) -> None:
        c = self.env.cycle
        for item in list(self._armed):
            pred, length, reason = item
            if not self.asserted and pred():
                self._armed.remove(item)
                self.at(c, length, reason)
        want = any(s <= c < e for s, e in self._sched)
        if want != self.asserted:
            self.asserted = want
            self.rst.write(self.active if want else self.inactive)
            if want:
                self.n_pulses += 1
            self.env.digest.event("reset", c, int(want))
            self.env.notify_reset(want)

    async def async_pulse(self, phase_ns: float = 3.0, length_cycles: int = 2, reason: str = "async-midcycle") -> None:
        """Assert reset *between* clock edges (``phase_ns`` after the next rising edge) and hold it for
        ``length_cycles`` cycles.  Exercises the asynchronous assert path of ``posedge clk or negedge rst_n``
        flops, which a synchronous testbench cannot reach.

        IMPORTANT: this coroutine waits for a rising edge itself and does not call ``Env.step()``.  Start it
        CONCURRENTLY with the test's own tick loop (``cocotb.start_soon(rst.async_pulse(...))``) so both wake
        at the same edge; awaiting it between ``env.tick()`` calls would swallow one edge without running the
        agents' sample/drive and desynchronise them from the DUT."""
        from cocotb.triggers import RisingEdge

        await RisingEdge(getattr(self.env.dut, self.env.clk_name))
        await self.assert_now(phase_ns, length_cycles, reason)

    async def assert_now(self, phase_ns: float = 3.0, length_cycles: int = 2, reason: str = "async-midcycle") -> None:
        """Like ``async_pulse`` but without waiting for an edge: call it right after ``await env.tick()`` in a
        tick-driven test, which is then already aligned to the edge ``phase_ns`` is measured from."""
        from cocotb.triggers import Timer

        await Timer(max(1, int(round(phase_ns * 1000))), units="ps")  # integer ps: floats such as 3.14 are not representable
        sh = self.rst.sh
        sh.h.value = self.active
        sh.pend = self.active
        sh.dirty = False
        c = self.env.cycle
        self.asserted = True
        self.n_pulses += 1
        self.log.append((c, length_cycles, reason))
        self._sched.append((c + 1, c + 1 + length_cycles))
        self.env.digest.event("reset-async", c, length_cycles)
        self.env.notify_reset(True)

    async def glitch(self, t_assert_ns: float, t_release_ns: float, peers=(), reason: str = "glitch") -> None:
        """Sub-cycle reset pulse: asserted ``t_assert_ns`` after the next rising edge and released
        ``t_release_ns`` after it (both before the following edge).  A pulse that never spans a clock edge
        resets only asynchronous-reset flops, so this is the stimulus that distinguishes ``posedge clk or negedge
        rst_n`` from a synchronous reset.  ``peers`` are agents of the same reset domain whose outputs are lost
        asynchronously too: they are told about the reset and their reset-state values are driven immediately.
        Start with ``cocotb.start_soon`` next to the tick loop (see ``async_pulse``)."""
        from cocotb.triggers import RisingEdge, Timer

        assert 0 < t_assert_ns < t_release_ns, "glitch must assert before it releases"
        await RisingEdge(getattr(self.env.dut, self.env.clk_name))
        await Timer(max(1, int(round(t_assert_ns * 1000))), units="ps")
        sh = self.rst.sh
        sh.h.value = self.active
        sh.pend = self.active
        sh.dirty = False
        c = self.env.cycle
        self.n_pulses += 1
        self.log.append((c, 0, reason))
        self.env.digest.event("reset-glitch", c, int(round(t_assert_ns * 1000)), int(round(t_release_ns * 1000)))
        self.env.notify_reset(True)
        for a in peers:
            a.drive()
        for shd in self.env.shadows.values():
            shd.flush()
        await Timer(max(1, int(round((t_release_ns - t_assert_ns) * 1000))), units="ps")
        sh.h.value = self.inactive
        sh.pend = self.inactive
        sh.dirty = False
        self.env.notify_reset(False)
