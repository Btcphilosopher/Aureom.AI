"""Suite descriptions: which DUT configurations are built, which cocotb tests run on them, with which seeds.

A subsystem registers itself by providing ``tests/<subsystem>/suite.py`` with a ``SUITES`` dict.  The
pytest plugin, the CLI (`albion run/regress/mutate/determinism`) and the mutation engine all read
the same registry, so there is exactly one definition of "the regression" for each block.
"""
from __future__ import annotations

import importlib
import pkgutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from .sim.build import DutSpec

ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Case:
    """One cocotb test (or all tests of a module) on one DUT configuration, repeated per seed."""

    dut: DutSpec
    module: str  # importable from verification/albion/tests (e.g. ``fabric.cocotb_xbar``)
    testcase: Optional[str] = None  # None => every @cocotb.test in the module
    seeds: Tuple[int, ...] = (1, 2, 3)
    timeout: float = 600.0
    tags: Tuple[str, ...] = ()  # e.g. ("smoke",), ("random",), ("reset",), ("long",)

    @property
    def label(self) -> str:
        return "%s::%s::%s" % (self.dut.name, self.module.split(".")[-1], self.testcase or "all")


@dataclass
class Suite:
    name: str  # registry key, e.g. "xbar"
    subsystem: str  # one of: sram | dma | fabric | compute | control | framework
    title: str
    cases: List[Case]
    # fast subset used for mutation runs (default: first seed of every case)
    mutation_cases: Optional[List[Case]] = None
    mutants_file: Optional[str] = None  # relative to verification/albion, e.g. mutants/xbar.yaml
    spec_refs: Tuple[str, ...] = ()  # specification documents the reference models were written from
    notes: str = ""

    def mutation_set(self) -> List[Case]:
        if self.mutation_cases is not None:
            return self.mutation_cases
        return [Case(c.dut, c.module, c.testcase, c.seeds[:1], c.timeout, c.tags) for c in self.cases]

    def duts(self) -> List[DutSpec]:
        seen: Dict[str, DutSpec] = {}
        for c in self.cases + (self.mutation_cases or []):
            seen[c.dut.name] = c.dut
        return list(seen.values())


LOAD_ERRORS: Dict[str, str] = {}


def load_suites(strict: bool = None) -> Dict[str, Suite]:
    """Import every ``tests/*/suite.py`` and merge their SUITES dicts.

    A suite module that fails to import is reported loudly and skipped (so one broken subsystem does not
    block the others while developing); with ``strict=True`` (or env ALBION_STRICT=1, used by CI) the error
    is raised instead, so a broken suite can never be silently dropped from a regression."""
    import os
    import traceback

    if strict is None:
        strict = os.environ.get("ALBION_STRICT", "0") == "1"
    tests_dir = ROOT / "tests"
    for p in (str(ROOT), str(tests_dir)):
        if p not in sys.path:
            sys.path.insert(0, p)
    out: Dict[str, Suite] = {}
    LOAD_ERRORS.clear()
    for sub in sorted(tests_dir.iterdir()):
        if sub.is_dir() and (sub / "suite.py").exists():
            modname = "%s.suite" % sub.name
            try:
                mod = importlib.import_module(modname)
                for name, s in getattr(mod, "SUITES", {}).items():
                    if name in out:
                        raise RuntimeError("duplicate suite name %r (in %s)" % (name, sub.name))
                    out[name] = s
            except Exception as e:
                if strict:
                    raise
                LOAD_ERRORS[modname] = "%r" % e
                print("WARNING: suite module %s failed to import and was SKIPPED: %r" % (modname, e), file=sys.stderr)
                sys.modules.pop(modname, None)
    return out
