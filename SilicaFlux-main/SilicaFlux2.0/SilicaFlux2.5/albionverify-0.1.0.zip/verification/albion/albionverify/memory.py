"""Byte-accurate reference memory used by slave models and scoreboards.

Each byte is in one of three states:
  exact      value known (set by a completed write, or the init policy)
  uncertain  one of a small set of values (an accepted write that was cancelled by reset "may or may not
             have been performed" -- SFB2 R11 -- so the byte may hold the old OR the new value)
  unknown    never written and the DUT's power-up content is unspecified (init="unknown"); any value is
             legal on first read, but once observed the value is pinned and must stay stable

Little-endian lanes: byte lane ``b`` of a word at aligned address ``A`` is bits [8b+7:8b] and holds
address ``A+b``; write strobe bit ``b`` enables lane ``b``.
"""
from __future__ import annotations

from typing import Callable, Dict, List, Optional, Set, Tuple, Union

Init = Union[str, Callable[[int], int]]


class BackingStore:
    def __init__(self, init: Init = "zero", name: str = "mem", size: Optional[int] = None):
        self.name = name
        self.init = init
        self.size = size
        self._val: Dict[int, Optional[int]] = {}
        self._alts: Dict[int, Set[int]] = {}
        self.n_writes = 0
        self.n_reads = 0

    # ------------------------------------------------------------------ helpers
    def _init_byte(self, a: int) -> Optional[int]:
        if callable(self.init):
            return self.init(a) & 0xFF
        if self.init == "zero":
            return 0
        if self.init == "unknown":
            return None
        raise ValueError("bad init %r" % (self.init,))

    def _get(self, a: int) -> Optional[int]:
        if a in self._val:
            return self._val[a]
        return self._init_byte(a)

    def in_range(self, addr: int, nbytes: int = 1) -> bool:
        return self.size is None or (0 <= addr and addr + nbytes <= self.size)

    # ------------------------------------------------------------------ writes
    def write_bytes(self, addr: int, data: bytes) -> None:
        for i, b in enumerate(data):
            self._val[addr + i] = b
            self._alts.pop(addr + i, None)
        self.n_writes += 1

    def write_word(self, addr: int, data: int, strb: Optional[int], nbytes: int) -> None:
        """Write lanes enabled in ``strb`` (None = all lanes).  Lane b -> byte at addr+b."""
        for b in range(nbytes):
            if strb is None or (strb >> b) & 1:
                a = addr + b
                self._val[a] = (data >> (8 * b)) & 0xFF
                self._alts.pop(a, None)
        self.n_writes += 1

    def write_uncertain(self, addr: int, data: int, strb: Optional[int], nbytes: int) -> None:
        """A write whose completion is unknown (cancelled by reset): each enabled byte may be old or new."""
        for b in range(nbytes):
            if strb is None or (strb >> b) & 1:
                a = addr + b
                new = (data >> (8 * b)) & 0xFF
                cur = self._get(a)
                alts = self._alts.get(a)
                if alts is None:
                    alts = set() if cur is None else {cur}
                    if cur is None:
                        # unknown stays unknown (any value legal); keep it unconstrained
                        self._val[a] = None
                        self._alts[a] = set()
                        continue
                alts.add(new)
                self._alts[a] = alts
                self._val[a] = new

    def clear(self) -> None:
        """Forget everything (e.g. after a modelled content-clearing reset) -> back to init policy."""
        self._val.clear()
        self._alts.clear()

    def set_all_unknown(self) -> None:
        """Contents become unspecified (e.g. SRAM without a reset: data after power-down)."""
        self._val.clear()
        self._alts.clear()
        self.init = "unknown"

    # ------------------------------------------------------------------ reads / checks
    def read_word(self, addr: int, nbytes: int) -> int:
        """Best-estimate current value (uncertain bytes -> most recent write, unknown -> 0)."""
        v = 0
        for b in range(nbytes):
            x = self._get(addr + b)
            v |= (0 if x is None else x) << (8 * b)
        self.n_reads += 1
        return v

    def allowed(self, a: int) -> Optional[Set[int]]:
        """Set of legal values for byte ``a`` (None = unconstrained)."""
        if a in self._alts and self._alts[a]:
            return set(self._alts[a])
        if a in self._alts and not self._alts[a]:
            return None
        x = self._get(a)
        return None if x is None else {x}

    def check_word(self, addr: int, nbytes: int, observed: int, lanes: Optional[int] = None, pin: bool = True) -> Optional[str]:
        """Compare an observed read word against the model.  ``lanes`` = bitmask of lanes to compare
        (None = all).  Returns None if legal, else a human-readable mismatch.  Pins uncertain/unknown bytes
        to the observed value (a later read must agree)."""
        bad: List[str] = []
        for b in range(nbytes):
            if lanes is not None and not (lanes >> b) & 1:
                continue
            a = addr + b
            got = (observed >> (8 * b)) & 0xFF
            ok = self.allowed(a)
            if ok is not None and got not in ok:
                exp = "|".join("%02x" % x for x in sorted(ok))
                bad.append("byte@0x%x lane%d exp=%s got=%02x" % (a, b, exp, got))
            elif pin:
                self._val[a] = got
                self._alts.pop(a, None)
        self.n_reads += 1
        if bad:
            return "%s: read of 0x%x (%dB) mismatch: %s" % (self.name, addr, nbytes, "; ".join(bad[:4]) + (" ..." if len(bad) > 4 else ""))
        return None

    def snapshot(self, addr: int, n: int) -> bytes:
        out = bytearray()
        for i in range(n):
            x = self._get(addr + i)
            out.append(0 if x is None else x)
        return bytes(out)

    def written_addresses(self) -> List[int]:
        return sorted(self._val)

    def copy(self) -> "BackingStore":
        c = BackingStore(self.init, self.name, self.size)
        c._val = dict(self._val)
        c._alts = {k: set(v) for k, v in self._alts.items()}
        return c


def lanes_from_strobe(strb: Optional[int], nbytes: int) -> int:
    return ((1 << nbytes) - 1) if strb is None else strb & ((1 << nbytes) - 1)
