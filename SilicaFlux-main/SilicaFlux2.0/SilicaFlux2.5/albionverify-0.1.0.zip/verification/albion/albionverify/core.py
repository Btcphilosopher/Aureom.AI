"""AlbionVerify core: signal access, the cycle-driven agent model and the test environment.

Execution model (measured, not assumed -- see docs/FRAMEWORK.md "sampling semantics"):

  On Verilator, a value read immediately after ``await RisingEdge(clk)`` is the value the flops
  *sampled* at that edge (pre-edge, settled).  Values written after the edge take effect for the
  next cycle.  The Env therefore runs a strictly ordered, single-threaded cycle loop:

      await RisingEdge(clk)
      for a in agents: a.sample()     # observe what the DUT/hardware saw at this edge
      for a in agents: a.drive()      # decide what to present for the next cycle
      flush all driven signals        # one write per handle, so slices of one vector never race

  Agents are plain Python objects (no per-agent coroutines), so stimulus order is deterministic and
  agents can be unit-tested with fake signal handles and ``Env.step()`` (no simulator).
"""
from __future__ import annotations

import json
import os
import random
from typing import Any, Callable, Dict, Iterable, List, Optional

from .digest import TraceDigest
from .rng import SeedRoot


def _lit_to_int(v: Any) -> int:
    if isinstance(v, str) and "'" in v:
        base = v.split("'", 1)[1][0].lower()
        digits = v.split("'", 1)[1][1:].replace("_", "")
        return int(digits, {"h": 16, "d": 10, "b": 2, "o": 8}[base])
    return int(v)


class AlbionCheckError(AssertionError):
    """A scoreboard / protocol / model check failed.  The message carries cycle and context."""


class LivenessError(AlbionCheckError):
    """An expected event did not happen within its cycle budget."""


# --------------------------------------------------------------------------- signals


class Shadow:
    """One per DUT handle.  Aggregates field writes and performs one handle write per cycle."""

    def __init__(self, handle, name: str, width: Optional[int] = None):
        self.h = handle
        self.name = name
        try:
            self.width = width or len(handle)
        except TypeError:
            self.width = width or 1
        self.pend = 0
        self.dirty = False  # becomes dirty only when something writes (never write to pure outputs)
        self._rd: Optional[int] = None

    def clear_cache(self) -> None:
        self._rd = None

    def read(self) -> int:
        if self._rd is None:
            self._rd = int(self.h.value)
        return self._rd

    def read_field(self, lo: int, w: int) -> int:
        return (self.read() >> lo) & ((1 << w) - 1)

    def write_field(self, lo: int, w: int, v: int) -> None:
        m = ((1 << w) - 1) << lo
        nv = (self.pend & ~m) | ((int(v) << lo) & m)
        self.pend = nv
        self.dirty = True  # first write always dirties; unchanged rewrites are cheap enough

    def flush(self) -> None:
        if self.dirty:
            self.h.value = self.pend
            self.dirty = False


class Sig:
    """A scalar signal or one ``[lo +: width]`` field of a flat vector."""

    __slots__ = ("sh", "lo", "w", "name")

    def __init__(self, shadow: Shadow, lo: int = 0, w: Optional[int] = None, name: Optional[str] = None):
        self.sh = shadow
        self.lo = lo
        self.w = w if w is not None else shadow.width
        self.name = name or shadow.name

    def read(self) -> int:
        return self.sh.read_field(self.lo, self.w)

    def write(self, v: int) -> None:
        self.sh.write_field(self.lo, self.w, v)

    def __repr__(self) -> str:
        return "Sig(%s[%d+:%d])" % (self.name, self.lo, self.w)


class Const:
    """A constant stand-in for an unused optional port (reads as ``value``, ignores writes)."""

    def __init__(self, value: int = 0, w: int = 1):
        self.value, self.w, self.name, self.lo = value, w, "const", 0

    def read(self) -> int:
        return self.value

    def write(self, v: int) -> None:
        pass


# --------------------------------------------------------------------------- agents


class Agent:
    """Cycle-based verification component.  Override sample/drive/on_reset as needed."""

    def __init__(self, name: str):
        self.name = name
        self.env: Optional["Env"] = None

    def attach(self, env: "Env") -> None:
        self.env = env

    # called once per rising edge, in registration order
    def sample(self) -> None:  # observe pre-edge values
        pass

    def drive(self) -> None:  # present next-cycle values
        pass

    def on_reset(self, asserted: bool) -> None:  # reset asserted / released
        pass

    def finalize(self) -> None:  # end-of-test checks (conservation, drained queues, ...)
        pass

    def summary(self) -> dict:
        return {}


# --------------------------------------------------------------------------- environment


class Env:
    def __init__(
        self,
        dut,
        *,
        clk: str = "clk",
        period_ns: float = 10.0,
        seed: Optional[int] = None,
        name: str = "tb",
        fail_fast: bool = True,
    ):
        self.dut = dut
        self.name = name
        self.clk_name = clk
        self.period_ns = period_ns
        self.seed = int(os.environ.get("ALBION_SEED", "1")) if seed is None else int(seed)
        self.seeds = SeedRoot(self.seed, name)
        self.rng: random.Random = self.seeds.stream("env")
        self.cycle = 0
        self.agents: List[Agent] = []
        self.shadows: Dict[str, Shadow] = {}
        self.errors: List[str] = []
        self.fail_fast = fail_fast
        self.digest = TraceDigest()
        self.in_reset = False
        self.checks = 0
        self.coverage: List[Any] = []  # CoverGroup objects registered by tests
        self._pre_step: List[Callable[[], None]] = []
        self.notes: Dict[str, Any] = {}

    # ---- signals
    def shadow(self, name: str, handle=None, width: Optional[int] = None) -> Shadow:
        sh = self.shadows.get(name)
        if sh is None:
            h = handle if handle is not None else getattr(self.dut, name)
            sh = Shadow(h, name, width)
            self.shadows[name] = sh
        return sh

    def sig(self, name: str, lo: int = 0, width: Optional[int] = None, handle=None) -> Sig:
        """Signal ``name`` (or the field ``[lo +: width]`` of flat vector ``name``)."""
        sh = self.shadow(name, handle)
        return Sig(sh, lo, width, name if (lo == 0 and (width is None or width == sh.width)) else "%s[%d+:%d]" % (name, lo, width or 0))

    def sigmap(self, mapping: Dict[str, Optional[str]], index: int = 0, widths: Optional[Dict[str, int]] = None) -> Dict[str, Sig]:
        """Map logical field -> Sig.  For flat per-port vectors pass index and per-field widths;
        fields mapped to None become ``Const(0)`` (optional port not present on this DUT)."""
        out: Dict[str, Any] = {}
        for k, nm in mapping.items():
            if nm is None:
                out[k] = Const(0)
                continue
            w = (widths or {}).get(k)
            if w is None:
                out[k] = self.sig(nm)
            else:
                out[k] = self.sig(nm, lo=index * w, width=w)
        return out

    def tie(self, *names: str, value: int = 0) -> None:
        """Drive DUT inputs that no agent owns (config pins, stall/hold inputs, ...) to a constant."""
        for n in names:
            self.sig(n).write(value)

    # ---- agents
    def add(self, agent: Agent) -> Agent:
        agent.attach(self)
        self.agents.append(agent)
        return agent

    def error(self, msg: str) -> None:
        full = "[%s @cycle %d] %s" % (self.name, self.cycle, msg)
        self.errors.append(full)
        if self.fail_fast:
            raise AlbionCheckError(full)

    def check(self, cond: bool, msg: str) -> bool:
        self.checks += 1
        if not cond:
            self.error(msg)
        return bool(cond)

    # ---- cycle loop
    def step(self) -> None:
        """One cycle of the agent loop (what runs after each rising edge).  Usable without a simulator."""
        self.cycle += 1
        for sh in self.shadows.values():
            sh.clear_cache()
        for a in self.agents:
            a.sample()
        for a in self.agents:
            a.drive()
        for sh in self.shadows.values():
            sh.flush()

    def notify_reset(self, asserted: bool) -> None:
        self.in_reset = asserted
        for a in self.agents:
            a.on_reset(asserted)

    def verify_params(self, expected: Optional[Dict[str, Any]] = None) -> int:
        """Read the DUT's elaborated parameters through VPI and compare with what the build asked for.

        Guards against silent parameter loss in the simulator build (measured: Verilator -G with a plain
        decimal or 0x literal wider than 32 bits is silently truncated).  VPI limits (measured, Verilator
        5.020): parameters *declared* wider than 32 bits (e.g. ``logic [63:0]``, whatever the value) read back as 0 and 32-bit values with the top bit set read
        back negative, so only values that fit in 32 bits are compared (modulo 2**32); wider ones are listed
        in ``env.notes['params_unverifiable']`` and must be proven behaviourally by the test that uses them.
        Returns the number of parameters verified; raises AlbionCheckError on any mismatch."""
        if expected is None:
            expected = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
        n = 0
        skipped = []
        for k, v in expected.items():
            try:
                want = _lit_to_int(v)
            except Exception:
                skipped.append(k)  # non-numeric (string) parameter
                continue
            if want.bit_length() > 32 or want < 0:
                skipped.append(k)
                continue
            try:
                h = getattr(self.dut, k)
                if len(h) > 32:
                    skipped.append(k)  # declared wider than 32 bits (e.g. logic [63:0]): VPI reads 0 whatever the value
                    continue
                got = int(h.value) & 0xFFFFFFFF
            except Exception:
                skipped.append(k)  # not exposed through VPI
                continue
            self.checks += 1
            n += 1
            if got != (want & 0xFFFFFFFF):
                raise AlbionCheckError("DUT parameter %s elaborated as 0x%x but the build requested 0x%x (parameter lost/truncated in the simulator build)" % (k, got, want))
        self.notes["params_verified"] = n
        self.notes["params_unverifiable"] = skipped
        return n

    def prime(self) -> None:
        """Present every agent's idle/reset-state values (also callable without a simulator)."""
        for a in self.agents:
            a.drive()
        for sh in self.shadows.values():
            sh.flush()

    def notify_internal_reset(self, *agents: "Agent") -> None:
        """A reset generated INSIDE the DUT (soft / watchdog / host-requested) cancels in-flight transactions
        of the agents attached to the affected interfaces without the ResetSequencer being involved."""
        for a in agents:
            a.on_reset(True)
        for a in agents:
            a.on_reset(False)

    async def start(self) -> None:
        """Start the clock (first rising edge at half a period) after pushing initial input values."""
        import cocotb
        from cocotb.clock import Clock

        # every agent presents its idle/reset-state values before the first edge (inputs are otherwise
        # random under +verilator+rand+reset); tests tie off remaining inputs with env.tie(...)
        self.prime()
        clk = getattr(self.dut, self.clk_name)
        clk.value = 0
        self.verify_params()
        cocotb.start_soon(Clock(clk, self.period_ns, units="ns").start(start_high=False))

    async def tick(self) -> None:
        from cocotb.triggers import RisingEdge

        await RisingEdge(getattr(self.dut, self.clk_name))
        self.step()

    async def cycles(self, n: int) -> None:
        for _ in range(n):
            await self.tick()

    async def until(self, pred: Callable[[], bool], max_cycles: int, what: str = "condition") -> int:
        """Tick until ``pred()`` is true; raise LivenessError after ``max_cycles``.  Returns cycles waited."""
        for i in range(max_cycles):
            if pred():
                return i
            await self.tick()
        if pred():
            return max_cycles
        raise LivenessError("[%s @cycle %d] liveness: %s not reached within %d cycles" % (self.name, self.cycle, what, max_cycles))

    # ---- end of test
    def finalize(self) -> None:
        for a in self.agents:
            a.finalize()
        if self.errors:
            raise AlbionCheckError("; ".join(self.errors[:5]))

    def result(self, **extra) -> dict:
        r = {
            "seed": self.seed,
            "cycles": self.cycle,
            "checks": self.checks + sum(a.summary().get("checks", 0) for a in self.agents),
            "digest": self.digest.hexdigest(),
            "digest_events": self.digest.n_events,
            "errors": list(self.errors),
            "agents": {a.name: a.summary() for a in self.agents},
        }
        r.update(extra)
        return r

    def write_result(self, test: str, **extra) -> dict:
        """Write results/coverage side files if the runner asked for them (env ALBION_RESULT_DIR)."""
        r = self.result(test=test, **extra)
        d = os.environ.get("ALBION_RESULT_DIR")
        if d:
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "%s.result.json" % test), "w") as f:
                json.dump(r, f, indent=1, sort_keys=True)
            if self.coverage:
                from .coverage import dump_groups

                dump_groups(self.coverage, os.path.join(d, "%s.func_cov.json" % test))
        # the digest line is parsed by the runner and by the determinism check
        print("ALBION_DIGEST test=%s seed=%d cycles=%d checks=%d digest=%s" % (test, self.seed, self.cycle, r["checks"], r["digest"]))
        return r
