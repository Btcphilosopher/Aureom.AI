"""Mutation / fault-injection engine: the machine-checkable form of the success criterion

    "Injected functional errors must cause tests to fail."

For a suite, each mutant is a small textual change to the vendored RTL (written by a verification
engineer to model a plausible functional bug: wrong arbitration, dropped byte enable, off-by-one on a
burst boundary, ...).  The engine
  1. builds and runs the UNMUTATED DUT first; if the baseline does not pass, nothing else is trusted;
  2. for each mutant builds a mutated DUT (a patch that does not apply exactly, or does not compile, is
     reported as BUILD_ERROR -- an invalid mutant, never counted as 'killed');
  3. runs the suite's mutation cases and stops at the first failing test:
        KILLED    a test failed.  The kill is classified: CHECK (scoreboard/protocol/model assertion),
                  LIVENESS (a progress timeout in the bench), TIMEOUT/CRASH (hung or crashed simulation --
                  detected, but weaker evidence);
        SURVIVED  every test passed => a verification gap, unless the mutant is annotated as equivalent
                  (behaviour-preserving) with a written justification.
The tests never see the mutants; mutants live only in mutants/*.yaml.
"""
from __future__ import annotations

import json
import re
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import yaml

from ..sim.build import BuildError, DutSpec, MutantApplyError, Patch, build_dut
from ..sim.runner import SimResult, out_root, run_cocotb
from ..suite import Case, Suite, ROOT


@dataclass
class MutantSpec:
    id: str
    desc: str
    klass: str
    patches: List[Patch]
    equivalent: bool = False
    equivalent_reason: str = ""
    unobservable: bool = False  # survives, NOT proven equivalent: cannot be provoked through the ports (a verification limit)
    expect_dut: Optional[str] = None  # restrict to one DUT config name (default: every DUT whose closure has the file)


@dataclass
class MutantResult:
    id: str
    klass: str
    desc: str
    status: str  # KILLED | SURVIVED | BUILD_ERROR | EQUIVALENT_SURVIVED | EQUIVALENT_KILLED | BASELINE_FAIL
    kill_kind: str = ""  # CHECK | LIVENESS | TIMEOUT | CRASH
    killed_by: str = ""  # test id
    message: str = ""
    seed: Optional[int] = None
    duts: List[str] = field(default_factory=list)
    repro: str = ""
    seconds: float = 0.0
    equivalent_reason: str = ""


def load_mutants(path: Path) -> List[MutantSpec]:
    d = yaml.safe_load(path.read_text())
    out = []
    for m in d["mutants"]:
        ps = [Patch(p["file"], p["find"], p["replace"], int(p.get("count", 1))) for p in m["patches"]]
        eq = m.get("equivalent")
        unobs = isinstance(eq, str) and eq.strip().upper().startswith("UNOBSERVABLE")
        out.append(MutantSpec(
            id=m["id"], desc=m["desc"].strip(), klass=m.get("class", "functional"), patches=ps,
            equivalent=bool(eq) and not unobs,
            equivalent_reason=(eq if isinstance(eq, str) else m.get("equivalent_reason", "")),
            unobservable=unobs, expect_dut=m.get("dut")))
    ids = [m.id for m in out]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate mutant ids in %s" % path)
    return out


_RTL_ASSERT = re.compile(r"%Error:[^\n]*(Assertion failed|\$error)|Verilog \$(?:stop|fatal)")


def resolve_mutant(ident: str, dut: DutSpec, suites: Dict[str, Suite]) -> "tuple[str, MutantSpec]":
    """Find the mutant named ``ident`` (``ID`` or ``suite:ID``).  Mutant ids are only unique within a suite
    (e.g. ``SM-01`` exists in two suites), so an unqualified id is narrowed to the mutants whose patched files
    are part of ``dut``'s source closure; if that is still ambiguous the caller must qualify it."""
    from ..sim.build import spec_sources

    want_suite, _, want_id = ident.rpartition(":")
    cands = []
    for sname, su in suites.items():
        if want_suite and sname != want_suite:
            continue
        if su.mutants_file and (ROOT / su.mutants_file).exists():
            for m in load_mutants(ROOT / su.mutants_file):
                if m.id == want_id:
                    cands.append((sname, m))
    if not want_suite:
        files = set(spec_sources(dut))
        cands = [c for c in cands if all(p.file in files for p in c[1].patches)]
    if len(cands) != 1:
        names = ", ".join("%s:%s" % (sn, m.id) for sn, m in cands) or "none"
        raise ValueError("mutant %r for DUT %s is %s (candidates: %s); use the suite-qualified form suite:ID" % (ident, dut.name, "ambiguous" if cands else "unknown", names))
    return cands[0]


def classify_kill(res: SimResult) -> str:
    """CHECK (bench scoreboard/protocol/model), ASSERT (an assertion in the RTL itself aborted the simulation
    before cocotb saw the edge), LIVENESS, TIMEOUT, CRASH."""
    if res.status == "TIMEOUT":
        return "TIMEOUT"
    if res.status in ("CRASH", "NO_TESTS"):
        try:
            tail = Path(res.log).read_text(errors="replace")[-6000:]
        except OSError:
            tail = ""
        return "ASSERT" if _RTL_ASSERT.search(tail) else "CRASH"
    msgs = " ".join(c.message for c in res.cases)
    if "liveness" in msgs.lower() or "LivenessError" in msgs:
        return "LIVENESS"
    return "CHECK"


def _affected_duts(suite: Suite, m: MutantSpec) -> List[DutSpec]:
    from ..sim.build import spec_sources

    files = {p.file for p in m.patches}
    out = []
    want = {c.dut.name for c in suite.mutation_set()}  # building a mutant for a DUT that runs no mutation case is wasted work
    for d in suite.duts():
        if d.name not in want:
            continue
        if m.expect_dut and d.name != m.expect_dut:
            continue
        if files & set(spec_sources(d)):
            out.append(d)
    return out


def run_baseline(suite: Suite, cases: Sequence[Case], timeout_scale: float = 1.0) -> List[SimResult]:
    res = []
    built: Dict[str, object] = {}
    for c in cases:
        b = built.get(c.dut.name) or build_dut(c.dut)
        built[c.dut.name] = b
        for s in c.seeds:
            res.append(run_cocotb(b, c.module, c.testcase, s, timeout=c.timeout * timeout_scale))
    return res


def run_one_mutant(suite: Suite, m: MutantSpec, cases: Sequence[Case], timeout_scale: float = 1.0) -> MutantResult:
    t0 = time.time()
    duts = _affected_duts(suite, m)
    mr = MutantResult(m.id, m.klass, m.desc, "SURVIVED", duts=[d.name for d in duts], equivalent_reason=m.equivalent_reason)
    if not duts:
        mr.status = "BUILD_ERROR"
        mr.message = "no DUT of suite %s contains the patched file(s) %s" % (suite.name, [p.file for p in m.patches])
        return mr
    try:
        for d in duts:
            try:
                b = build_dut(d, patches=m.patches, tag="mut-" + re.sub(r"[^A-Za-z0-9]", "", m.id))
            except MutantApplyError as e:
                mr.status, mr.message = "BUILD_ERROR", "patch did not apply: %s" % e
                return mr
            except BuildError as e:
                mr.status, mr.message = "BUILD_ERROR", "mutant does not compile: %s" % e
                return mr
            for c in [c for c in cases if c.dut.name == d.name]:
                for s in c.seeds:
                    r = run_cocotb(b, c.module, c.testcase, s, timeout=c.timeout * timeout_scale, mutant="%s:%s" % (suite.name, m.id))
                    if not r.passed:
                        mr.status = "EQUIVALENT_KILLED" if m.equivalent else "KILLED"
                        mr.kill_kind = classify_kill(r)
                        mr.killed_by = r.test_id
                        mr.seed = s
                        mr.message = next((c2.message for c2 in r.cases if c2.status in ("FAIL", "ERROR")), r.status)[:400]
                        mr.repro = r.repro
                        return mr
        mr.status = "EQUIVALENT_SURVIVED" if m.equivalent else ("UNOBSERVABLE_SURVIVED" if m.unobservable else "SURVIVED")
        return mr
    except Exception as e:  # pragma: no cover
        mr.status, mr.message = "BUILD_ERROR", "engine error: %r\n%s" % (e, traceback.format_exc()[-500:])
        return mr
    finally:
        mr.seconds = round(time.time() - t0, 1)


def run_mutation(suite: Suite, mutant_ids: Optional[Sequence[str]] = None, jobs: int = 2, timeout_scale: float = 1.0, progress=print) -> dict:
    if not suite.mutants_file:
        raise ValueError("suite %s has no mutants_file" % suite.name)
    mutants = load_mutants(ROOT / suite.mutants_file)
    if mutant_ids:
        mutants = [m for m in mutants if m.id in set(mutant_ids)]
    cases = [c for c in suite.mutation_set() if not any(t.startswith("known_defect:") for t in c.tags)]
    progress("[%s] baseline (unmutated) on %d case(s)..." % (suite.name, len(cases)))
    base = run_baseline(suite, cases, timeout_scale)
    bad = [r for r in base if not r.passed]
    report = {"suite": suite.name, "baseline": [r.test_id + ":" + r.status for r in base], "baseline_ok": not bad, "mutants": []}
    if bad:
        progress("[%s] BASELINE FAILS -- mutation results would be meaningless:" % suite.name)
        for r in bad:
            progress("   " + r.failure_summary())
        report["baseline_failures"] = [r.failure_summary() for r in bad]
        return report
    progress("[%s] baseline OK; running %d mutant(s) with %d worker(s)" % (suite.name, len(mutants), jobs))
    results: List[MutantResult] = []
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(run_one_mutant, suite, m, cases, timeout_scale): m for m in mutants}
        for fu in as_completed(futs):
            r = fu.result()
            results.append(r)
            progress("   %-10s %-20s %-9s %s" % (r.id, r.status, r.kill_kind, (r.message or "")[:100].replace("\n", " ")))
    results.sort(key=lambda r: r.id)
    report["mutants"] = [asdict(r) for r in results]
    report.update(score(results))
    return report


def score(results: Sequence[MutantResult]) -> dict:
    valid = [r for r in results if r.status != "BUILD_ERROR"]
    killed = [r for r in valid if r.status in ("KILLED", "EQUIVALENT_KILLED")]
    surv = [r for r in valid if r.status == "SURVIVED"]
    eq = [r for r in valid if r.status == "EQUIVALENT_SURVIVED"]
    unobs = [r for r in valid if r.status == "UNOBSERVABLE_SURVIVED"]
    # unobservable survivors are NOT proven equivalent, so they count against the score (only argued-equivalent ones are excluded)
    denom = len(killed) + len(surv) + len(unobs)
    return {
        "n_mutants": len(results),
        "n_invalid": len(results) - len(valid),
        "n_killed": len(killed),
        "n_survived": len(surv),
        "n_equivalent_survived": len(eq),
        "n_unobservable_survived": len(unobs),
        "n_killed_by_check": len([r for r in killed if r.kill_kind == "CHECK"]),
        "n_killed_by_rtl_assert": len([r for r in killed if r.kill_kind == "ASSERT"]),
        "n_killed_by_liveness_or_hang": len([r for r in killed if r.kill_kind not in ("CHECK", "ASSERT")]),
        "mutation_score_percent": round(100.0 * len(killed) / denom, 1) if denom else None,
    }


def write_reports(report: dict, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / ("%s.json" % report["suite"])).write_text(json.dumps(report, indent=1))
    lines = ["# Mutation report: %s\n" % report["suite"]]
    if not report.get("baseline_ok", True):
        lines.append("**BASELINE FAILED -- no mutation results.**\n")
        lines += ["```", *report.get("baseline_failures", []), "```"]
    else:
        lines.append("Baseline (unmutated RTL): %d run(s), all PASS.\n" % len(report["baseline"]))
        lines.append("**Mutation score: %s%%** (%d killed / %d survived; %d argued-equivalent survivors excluded; %d survivors unobservable through the ports (not proven equivalent, counted against the score); %d invalid mutants excluded). %d kills came from scoreboard/protocol/model checks, %d from an assertion inside the RTL aborting the simulation, %d from liveness/hang/crash detection.\n" % (
            report.get("mutation_score_percent"), report["n_killed"], report["n_survived"], report["n_equivalent_survived"], report.get("n_unobservable_survived", 0), report["n_invalid"], report["n_killed_by_check"], report.get("n_killed_by_rtl_assert", 0), report["n_killed_by_liveness_or_hang"]))
        lines.append("| id | class | status | kill | detected by | message |\n|---|---|---|---|---|---|")
        for m in report["mutants"]:
            lines.append("| %s | %s | %s | %s | %s | %s |" % (m["id"], m["klass"], m["status"], m["kill_kind"], m["killed_by"].split("::")[-3:-1] if m["killed_by"] else "", (m["message"] or m["equivalent_reason"] or "").replace("|", "/").replace("\n", " ")[:140]))
        unobs = [m for m in report["mutants"] if m["status"] == "UNOBSERVABLE_SURVIVED"]
        if unobs:
            lines.append("\n## Survivors unobservable through the ports (verification limit, NOT proven equivalent)\n")
            for m in unobs:
                lines.append("* **%s** (%s): %s -- %s" % (m["id"], m["klass"], m["desc"], (m["equivalent_reason"] or "")[:240]))
        surv = [m for m in report["mutants"] if m["status"] == "SURVIVED"]
        if surv:
            lines.append("\n## Survivors (verification gaps)\n")
            for m in surv:
                lines.append("* **%s** (%s): %s" % (m["id"], m["klass"], m["desc"]))
    (outdir / ("%s.md" % report["suite"])).write_text("\n".join(lines) + "\n")
