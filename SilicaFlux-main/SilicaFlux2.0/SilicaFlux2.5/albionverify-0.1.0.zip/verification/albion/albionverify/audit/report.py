"""Turn inventory.json + exec_results.json into AUDIT.md, CSV tables and audit_summary.json.

Every number in the report is computed here from the raw results; nothing is typed in by hand.
Rule applied throughout: a testbench counts as *passing* only with the verdict PASS (it was built,
executed to completion, printed an explicit pass marker and no fail marker).  NO_VERDICT, NEEDS_FLOW,
BUILD_FAIL, TIMEOUT and anything not run are reported as such, never as passing.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from . import exec_checks as ec

# The blocks AlbionVerify targets (module 93 priorities A-E) -- used for the focused tables.
KEY_BLOCKS = {
    "A SRAM": ["sram_sp", "sram_bank_controller", "sram_1r1w", "sram_tdp", "hpc_scratchpad", "hpc_spm_bank_arb"],
    "B DMA": ["silicaflux_dma", "dma_transfer_engine", "dma_burst_engine", "dma_control_regs", "dma_irq", "dma_validate", "hpc_dma_adapter"],
    "C DataFabric": ["sfb_crossbar", "sfb_arbiter", "sfb_addr_decoder", "sfb_reg_slice", "sfb_skid_buffer", "sfb_req_mux", "sfb_rsp_router", "sfb_error_slave"],
    "D Vector/Tensor": ["hpc_vector_array", "hpc_vector_lane", "hpc_fp32_add", "hpc_fp32_mul", "hpc_fp32_fma", "tensor_systolic_array", "tensor_pe", "tensor_skew", "tensor_output_collect"],
    "E Control": ["silicaflux_control_core", "cc_mailbox", "cc_sysctrl", "cc_pmu", "cc_ras", "cc_perf", "cc_secmon", "cc_sfb_gate"],
}


def _k(name, fsha, role):
    return "%s|%s|%s" % (name, fsha, role)


def build(inv: dict, res: dict, out: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    uniq = ec.dedupe_units(inv)
    idx = ec.build_indexes(inv)
    arc_name = {sha: a["name"] for sha, a in inv["archives"].items()}
    fsha = {(f["arc"], f["path"]): f["sha256"] for f in inv["files"]}

    # ------------------------------------------------------------- tables per unique unit
    rows: Dict[Tuple[str, str, str], dict] = {}
    for k, u in uniq.items():
        projects = sorted({arc_name[s["arc"]] for s in u["seen_in"]})
        rows[k] = {
            "name": u["name"], "role": u["role"], "kind": u["kind"], "ports": u["n_ports"], "families": ",".join(u["families"]),
            "copies": len(u["seen_in"]), "projects": projects, "file": u["file"], "file_sha": k[1][:12],
            "assert_prop": u["n_assert_prop"], "assert_imm": u["n_assert_imm"], "assume": u["n_assume"], "cover": u["n_cover"],
            "error_calls": u["n_error_calls"], "behavioural": [r for r in u["behavioural_reasons"] if r.startswith("S:")],
            "weak": [r for r in u["behavioural_reasons"] if r.startswith("W:")], "instantiates": u["instantiates"], "uses_packages": u["uses_packages"],
        }
        c = res["compile"].get(ec_key(k))
        if c:
            rows[k]["verilator"] = c.get("verilator", {}).get("status", "?")
            rows[k]["icarus"] = c.get("icarus", {}).get("status", "?")
            rows[k]["v_warn"] = c.get("verilator", {}).get("warnings")
            rows[k]["v_err_class"] = c.get("verilator", {}).get("error_class", "")
            rows[k]["v_err"] = c.get("verilator", {}).get("first_error", "")
            rows[k]["unresolved"] = c.get("unresolved_instances", [])
            rows[k]["closure_files"] = c.get("closure_files")
            rows[k]["assert_parse"] = c.get("verilator_assert", {}).get("status", "")
        t = res["tb"].get(ec_key(k))
        if t:
            rows[k]["tb_status"] = t.get("status")
            rows[k]["tb_tool"] = t.get("tool")
            rows[k]["tb_detail"] = t.get("detail", "")
            rows[k]["tb_error_class"] = t.get("error_class", "")

    rtl = [r for r in rows.values() if r["role"] == "rtl" and r["kind"] == "module"]
    tbs = [r for r in rows.values() if r["role"] == "tb_top"]

    # ------------------------------------------------------------- compile statistics
    vstat = Counter(r.get("verilator", "NOT_RUN") for r in rtl)
    istat = Counter(r.get("icarus", "NOT_RUN") for r in rtl)
    both_ok = sum(1 for r in rtl if r.get("verilator") == "PASS" and r.get("icarus") == "PASS")
    vfail_cls = Counter(r.get("v_err_class", "other") for r in rtl if r.get("verilator") == "FAIL")
    ifail_cls = Counter()
    for k, r in rows.items():
        if r["role"] == "rtl" and r.get("icarus") == "FAIL":
            c = res["compile"].get(ec_key(k), {})
            ifail_cls[c.get("icarus", {}).get("error_class", "other")] += 1
    # ------------------------------------------------------------- testbench statistics
    tstat = Counter(r.get("tb_status", "NOT_RUN") for r in tbs)
    tool_pass = Counter(r.get("tb_tool") for r in tbs if r.get("tb_status") == "PASS")
    tb_build_cls = Counter(r.get("tb_error_class", "other") for r in tbs if r.get("tb_status") == "BUILD_FAIL")

    # ------------------------------------------------------------- which RTL is exercised by a PASSING tb
    passing_tbs = [(k, u) for k, u in uniq.items() if u["role"] == "tb_top" and res["tb"].get(ec_key(k), {}).get("status") == "PASS"]
    exercised: Dict[Tuple[str, str], Set[str]] = defaultdict(set)  # (module name, file sha) -> tb names
    direct: Set[Tuple[str, str]] = set()
    for k, u in passing_tbs:
        rep = u["seen_in"][0]
        ix = idx[rep["arc"]]
        tbu = next(x for x in ix.by_file[rep["file"]] if x["name"] == u["name"] and x["role"] == "tb_top")
        files, _ = ec.closure(ix, tbu, tb_mode=True)
        for f in files:
            for x in ix.by_file[f]:
                if x["role"] == "rtl":
                    exercised[(x["name"], ix.file_sha[f])].add(u["name"])
        for d in tbu["instantiates"]:
            for x in ix.by_name.get(d, []):
                if x["role"] == "rtl":
                    direct.add((x["name"], ix.file_sha[x["file"]]))
    n_ex = sum(1 for k, r in rows.items() if r["role"] == "rtl" and r["kind"] == "module" and (r["name"], k[1]) in exercised)
    for k, r in rows.items():
        if r["role"] == "rtl" and r["kind"] == "module":
            r["pass_tbs"] = sorted(exercised.get((r["name"], k[1]), []))
            r["tb_direct"] = (r["name"], k[1]) in direct

    # ------------------------------------------------------------- tops (never instantiated within their archive)
    inst_in_arc: Dict[str, Set[str]] = defaultdict(set)
    for u in inv["units"]:
        if u["role"] not in ("rtl", "interface"):
            continue  # testbenches/formal harnesses instantiating a block do not make it "non-top"
        for d in u["instantiates"]:
            inst_in_arc[u["arc"]].add(d)
    tops = []
    for k, u in uniq.items():
        if u["role"] == "rtl" and u["kind"] == "module":
            if all(u["name"] not in inst_in_arc[s["arc"]] for s in u["seen_in"]):
                tops.append(k)

    # ------------------------------------------------------------- version drift
    ver: Dict[str, Dict[str, List[str]]] = defaultdict(lambda: defaultdict(list))
    for (name, fs, role), u in uniq.items():
        if role in ("rtl",):
            ver[name][fs].append(arc_name[u["seen_in"][0]["arc"]])
    drift = {n: v for n, v in ver.items() if len(v) > 1}

    summary = {
        "tool_versions": res["tool_versions"],
        "archives_with_hdl": len(inv["archives"]),
        "hdl_files_in_archives": len(inv["files"]),
        "units_total": len(inv["units"]),
        "unique_units": len(uniq),
        "unique_by_role": dict(Counter(k[2] for k in uniq)),
        "rtl_modules_unique": len(rtl),
        "compile_verilator": dict(vstat), "compile_icarus": dict(istat), "compile_both_pass": both_ok,
        "verilator_fail_classes": dict(vfail_cls), "icarus_fail_classes": dict(ifail_cls),
        "testbenches_unique": len(tbs), "testbench_verdicts": dict(tstat), "testbench_pass_tool": dict(tool_pass), "testbench_buildfail_classes": dict(tb_build_cls),
        "rtl_modules_in_hierarchy_of_passing_tb": n_ex,
        "behavioural_strong": sum(1 for r in rtl if r["behavioural"]),
        "behavioural_weak_only": sum(1 for r in rtl if not r["behavioural"] and r["weak"]),
        "modules_with_multiple_versions": len(drift),
        "assertions": {
            "units_with_sva_property": sum(1 for r in rows.values() if r["assert_prop"]),
            "units_with_immediate_assert": sum(1 for r in rows.values() if r["assert_imm"]),
            "sva_properties_total": sum(r["assert_prop"] for r in rows.values()),
            "units_with_error_or_fatal_checks": sum(1 for r in rows.values() if r["error_calls"]),
        },
    }

    # ------------------------------------------------------------- CSVs
    def write_csv(name, header, data):
        with open(out / name, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(header)
            w.writerows(data)

    write_csv("rtl_modules.csv",
              ["module", "copies", "projects", "ports", "interface_families", "verilator", "icarus", "verilator_error_class", "verilator_first_error", "closure_files", "unresolved_instances", "behavioural_evidence", "in_hierarchy_of_passing_tb", "passing_tbs"],
              [[r["name"], r["copies"], ";".join(r["projects"][:4]), r["ports"], r["families"], r.get("verilator", "NOT_RUN"), r.get("icarus", "NOT_RUN"), r.get("v_err_class", ""), (r.get("v_err", "") or "")[:200], r.get("closure_files", ""), ";".join(r.get("unresolved", [])), ";".join(r["behavioural"]), bool(r.get("pass_tbs")), ";".join(r.get("pass_tbs", [])[:5])] for r in sorted(rtl, key=lambda r: r["name"])])
    write_csv("testbenches.csv", ["testbench", "copies", "projects", "verdict", "tool", "detail", "build_error_class", "file"],
              [[r["name"], r["copies"], ";".join(r["projects"][:4]), r.get("tb_status", "NOT_RUN"), r.get("tb_tool", ""), (r.get("tb_detail", "") or "")[:200], r.get("tb_error_class", ""), r["file"]] for r in sorted(tbs, key=lambda r: r["name"])])
    write_csv("assertions.csv", ["unit", "role", "sva_property", "immediate_assert", "assume", "cover", "error_fatal_calls", "projects"],
              [[r["name"], r["role"], r["assert_prop"], r["assert_imm"], r["assume"], r["cover"], r["error_calls"], ";".join(r["projects"][:3])] for r in sorted(rows.values(), key=lambda r: (r["role"], r["name"])) if r["assert_prop"] or r["assert_imm"] or r["assume"] or r["cover"] or r["error_calls"]])
    write_csv("behavioural_blocks.csv", ["module", "evidence", "projects", "file"],
              [[r["name"], ";".join(r["behavioural"]), ";".join(r["projects"][:3]), r["file"]] for r in sorted(rtl, key=lambda r: r["name"]) if r["behavioural"]])
    write_csv("version_drift.csv", ["module", "n_versions", "versions(sha12:projects)"],
              [[n, len(v), " | ".join("%s:%s" % (s[:12], "+".join(sorted(set(p))[:3])) for s, p in v.items())] for n, v in sorted(drift.items())])

    # ------------------------------------------------------------- markdown
    md: List[str] = []
    A = md.append
    A("# AlbionVerify existing-code audit\n")
    A("*Generated by `python -m albionverify.audit.report`; every figure is computed from the raw results in `inventory.json` / `exec_results.json` (kept with this report).*\n")
    A("## 0. What was executed\n")
    A("Tools: %s; %s.  Everything below is the outcome of **running those tools**, not of reading the code or the projects' own reports." % (res["tool_versions"].get("verilator"), res["tool_versions"].get("iverilog")))
    A("* **Compile**: every unique RTL module was linted with Verilator (`--lint-only`, default warnings) and elaborated with Icarus (`-g2012`), each on its *dependency closure* (sources found by instantiation / package use, packages ordered first, every header directory on the include path).")
    A("* **Simulation**: every unique testbench was built (Icarus first; Verilator `--binary --timing` as fallback when Icarus cannot build or run it) and executed with a wall-clock limit.")
    A("* **Verdict policy**: `PASS` = built, ran to `$finish`/exit 0, printed an explicit pass marker, printed no fail/error marker.  `NO_VERDICT` = ran but printed no pass/fail marker (**not counted as passing**).  `NEEDS_FLOW` = aborted because it needs a project-specific flow (plusargs, vector files) the generic runner does not provide (**not a design failure, not a pass**).  `BUILD_FAIL` = neither tool could build it generically.  `TIMEOUT`, `FAIL` as named.  Nothing that was not run is reported as passing.")
    A("* A generic-flow failure does **not** mean the design is broken: many projects drive their testbenches through their own Makefiles/scripts, defines and generated stimulus.  It means *AlbionVerify cannot count that testbench as evidence*.\n")

    A("## 1. Corpus\n")
    A("| item | count |\n|---|---:|")
    A("| archives containing HDL (unique by content) | %d |" % summary["archives_with_hdl"])
    A("| HDL files (per unique archive) | %d |" % summary["hdl_files_in_archives"])
    A("| declared units (module/interface/package) incl. duplicates | %d |" % summary["units_total"])
    A("| unique units (same name **and** same file content counted once) | %d |" % summary["unique_units"])
    for role, n in sorted(summary["unique_by_role"].items()):
        A("| &nbsp;&nbsp;of which `%s` | %d |" % (role, n))
    A("")
    A("The same SilicaFlux IP is vendored under `third_party/` in many archives; de-duplicating by content is what makes the audit tractable and is itself a finding (section 8).\n")

    A("## 2. Which modules compile\n")
    A("Unique RTL modules compiled: **%d** (interfaces and packages are compiled as part of their users)." % len(rtl))
    A("\n| tool | PASS | FAIL | TIMEOUT |\n|---|---:|---:|---:|")
    A("| Verilator lint | %d | %d | %d |" % (vstat["PASS"], vstat["FAIL"], vstat["TIMEOUT"]))
    A("| Icarus elaboration | %d | %d | %d |" % (istat["PASS"], istat["FAIL"], istat["TIMEOUT"]))
    A("\nPass on **both** tools: %d.  Verilator is the stricter front end and is the simulator AlbionVerify uses.\n" % both_ok)
    A("Failure classes (Verilator): " + (", ".join("%s=%d" % kv for kv in sorted(vfail_cls.items())) or "none") + ".  (Icarus): " + (", ".join("%s=%d" % kv for kv in sorted(ifail_cls.items())) or "none") + ".")
    A("`missing_module`/`missing_include`/`undefined_macro` mean the unit's closure is not self-contained in its own archive (needs a vendored sibling, a generated file or a Makefile `+define`), which is a packaging issue rather than a design error.\n")
    A("Modules whose closure has instantiations that resolve to no source in the archive (they may sit in inactive generate branches; Verilator may still pass):")
    unres = [r for r in rtl if r.get("unresolved")]
    A("%d unique modules; examples: %s.\n" % (len(unres), ", ".join("`%s`→%s" % (r["name"], ",".join(r["unresolved"][:2])) for r in sorted(unres, key=lambda r: r["name"])[:6]) or "none"))

    A("## 3. Which modules have working simulations\n")
    A("Unique testbenches executed: **%d**.\n" % len(tbs))
    A("| verdict | count |\n|---|---:|")
    for v in ("PASS", "FAIL", "NO_VERDICT", "NEEDS_FLOW", "TIMEOUT", "BUILD_FAIL", "NOT_RUN"):
        if tstat.get(v):
            A("| %s | %d |" % (v, tstat[v]))
    A("\n`PASS` verdicts came from: " + ", ".join("%s=%d" % kv for kv in sorted(tool_pass.items())) + ".  Build-failure classes: " + (", ".join("%s=%d" % kv for kv in sorted(tb_build_cls.items())) or "none") + ".\n")
    A("**%d of %d unique RTL modules (%.1f%%) sit in the instantiation hierarchy of at least one testbench that PASSED.**  This counts hierarchy reachability, not the quality of checking: a leaf instantiated inside a passing system testbench is exercised, but not necessarily checked in isolation.\n" % (n_ex, len(rtl), 100.0 * n_ex / max(1, len(rtl))))
    A("### Passing testbenches\n")
    A("| testbench | tool | evidence line | projects |\n|---|---|---|---|")
    for r in sorted(tbs, key=lambda r: r["name"]):
        if r.get("tb_status") == "PASS":
            A("| `%s` | %s | %s | %s |" % (r["name"], r.get("tb_tool"), (r.get("tb_detail", "") or "").replace("|", "/")[:90], ", ".join(r["projects"][:2])))
    A("\n### Executed but NOT passing (not counted as evidence)\n")
    for v in ("FAIL", "TIMEOUT", "NO_VERDICT", "NEEDS_FLOW"):
        sel = [r for r in tbs if r.get("tb_status") == v]
        if sel:
            A("**%s (%d)**: " % (v, len(sel)) + ", ".join("`%s`" % r["name"] for r in sorted(sel, key=lambda r: r["name"])[:40]) + (" ..." if len(sel) > 40 else "") + "\n")
    A("Full per-testbench verdicts and the first diagnostic line are in `testbenches.csv`.\n")

    A("## 4. Focus blocks (module 93 priorities A-E)\n")
    A("| block | module | Verilator | Icarus | closure files | behavioural? | in a PASSING tb's hierarchy | passing tb(s) |\n|---|---|---|---|---:|---|---|---|")
    by_name: Dict[str, List[dict]] = defaultdict(list)
    for r in rtl:
        by_name[r["name"]].append(r)
    for blk, names in KEY_BLOCKS.items():
        for n in names:
            rs = by_name.get(n)
            if not rs:
                A("| %s | `%s` | — | — | — | — | not in corpus | |" % (blk, n))
                continue
            r = sorted(rs, key=lambda x: -x["copies"])[0]
            A("| %s | `%s` | %s | %s | %s | %s | %s | %s |" % (blk, n, r.get("verilator", "NOT_RUN"), r.get("icarus", "NOT_RUN"), r.get("closure_files", ""), ("yes: " + ",".join(x.replace("S:", "") for x in r["behavioural"][:2])) if r["behavioural"] else "no", "yes" if r.get("pass_tbs") else "no", ", ".join(("`%s`" % t) for t in r.get("pass_tbs", [])[:3])))
    A("")

    A("## 5. Interfaces and tests\n")
    fam_rows: Dict[str, List[dict]] = defaultdict(list)
    for r in rtl:
        for f in (r["families"].split(",") if r["families"] else []):
            fam_rows[f].append(r)
    A("Interface families are recognised from port names (a heuristic).  'Tested' = the module is in the hierarchy of a PASSING testbench.\n")
    A("| interface family | modules | in a passing tb's hierarchy | not exercised by any passing tb |\n|---|---:|---:|---:|")
    for f, rs in sorted(fam_rows.items(), key=lambda kv: -len(kv[1])):
        te = sum(1 for r in rs if r.get("pass_tbs"))
        A("| %s | %d | %d | %d |" % (f, len(rs), te, len(rs) - te))
    A("")
    focus_names = {n for ns in KEY_BLOCKS.values() for n in ns}
    lacking = sorted({n for n in focus_names if by_name.get(n) and not any(r.get("pass_tbs") for r in by_name[n])})
    partial = sorted({n for n in focus_names if by_name.get(n) and any(r.get("pass_tbs") for r in by_name[n]) and not all(r.get("pass_tbs") for r in by_name[n])})
    A("Focus-block modules with **no** passing testbench for any version in this audit: " + (", ".join("`%s`" % n for n in lacking) or "none") + ".")
    if partial:
        A("Modules where some *versions* have a passing testbench and others do not: " + ", ".join("`%s`" % n for n in partial) + ".")
    A("(That is what AlbionVerify's own benches are for; see the suites under `tests/`.)\n")

    A("## 6. Behavioural / stand-in blocks\n")
    beh = [r for r in rtl if r["behavioural"]]
    A("%d unique RTL units carry **strong** evidence of being behavioural, stand-in, stub or black-box models (self-description in comments, directory such as `standin/`, `sim_models/`, `stubs/`, or non-synthesizable constructs: `fork`, `$random`, `real`, DPI).  A further %d have only weak hints (`#N` delays) and are not counted." % (len(beh), summary["behavioural_weak_only"]))
    c = Counter(x for r in beh for x in r["behavioural"])
    A("\n| evidence | units |\n|---|---:|")
    for e, n in c.most_common(14):
        A("| %s | %d |" % (e.replace("S:", ""), n))
    A("\nFull list (`behavioural_blocks.csv`).  Any simulation result that includes such a block verifies the *model*, not synthesizable RTL.\n")

    A("## 7. Assertions\n")
    asr = summary["assertions"]
    A("* units containing concurrent `assert property`: **%d** (%d property assertions in total)" % (asr["units_with_sva_property"], asr["sva_properties_total"]))
    A("* units containing immediate `assert (...)`: %d;  units using `$error`/`$fatal` as checks: %d" % (asr["units_with_immediate_assert"], asr["units_with_error_or_fatal_checks"]))
    ap_pass = Counter(r.get("assert_parse") for r in rtl if r.get("assert_parse"))
    A("* RTL modules containing assertions, re-linted with `verilator --assert`: " + (", ".join("%s=%d" % kv for kv in sorted(ap_pass.items())) or "none") + ".")
    fv = [r for r in rows.values() if r["role"] == "formal"]
    A("* formal harness units (`fv_*`, formal/): %d (these were **not** run here: the formal flows need Yosys/SMT tooling that was not part of this audit; they are inventory only).\n" % len(fv))
    A("Assertions are *inventoried* from source text; whether they hold was not established by this audit.  (`assertions.csv`)\n")

    A("## 8. Version drift of vendored copies\n")
    A("Modules (RTL) that exist in more than one *different* version across the archives: **%d**." % len(drift))
    for n, v in sorted(drift.items(), key=lambda kv: -len(kv[1]))[:20]:
        A("* `%s`: %d versions (%s)" % (n, len(v), "; ".join("%s in %s" % (s[:8], "+".join(sorted(set(p))[:2])) for s, p in v.items())))
    A("\nIdentical content across copies means verifying one pinned copy verifies them all (AlbionVerify pins the copies it tests by SHA-256 in `rtl/MANIFEST.json`); the drift list is where that assumption does **not** hold.\n")

    A("## 9. Which subsystems can already be integrated\n")
    ok_tops = [k for k in tops if rows[k].get("verilator") == "PASS" and not rows[k].get("unresolved")]
    A("Top-level modules (never instantiated inside their own archive) that lint clean on Verilator with a fully resolved closure: **%d** of %d top-level modules.  Of those, **%d** are in the hierarchy of a passing testbench (i.e. already integrated *and* simulated)." % (len(ok_tops), len(tops), sum(1 for k in ok_tops if rows[k].get("pass_tbs"))))
    A("\n| integrable top | project (first of N copies) | closure files | behavioural | in a passing tb's hierarchy |\n|---|---|---:|---|---|")
    seen9 = set()
    cand = sorted(ok_tops, key=lambda k: (-(rows[k].get("closure_files") or 0), rows[k]["name"]))
    shown = 0
    for k in cand:
        r = rows[k]
        key9 = (r["name"], r["projects"][0])
        if key9 in seen9:
            continue
        seen9.add(key9)
        shown += 1
        if shown > 25:
            break
        A("| `%s` | %s (+%d other copies) | %s | %s | %s |" % (r["name"], r["projects"][0], max(0, len(r["projects"]) - 1), r.get("closure_files"), "yes" if r["behavioural"] else "no", ", ".join("`%s`" % t for t in r.get("pass_tbs", [])[:2]) or "no"))
    A("\nWhere several projects contain the same top, the row is the first copy encountered.\n")

    A("## 10. Limits of this audit\n")
    A("* Static facts (module lists, instantiation graph, assertion counts, behavioural markers) come from a regex-based scanner, not a full SystemVerilog parser; port-family detection is name-based.")
    A("* Testbenches that need project-specific flows (plusargs, generated vector files, `+define`s, cross-compiled firmware) are reported as `NEEDS_FLOW`/`BUILD_FAIL`; they may well pass in their own flow, but that is not shown here.")
    A("* Hierarchy reachability from a passing testbench is not proof that a module's behaviour is checked.")
    A("* Formal proofs, synthesis and gate-level results claimed in the projects' own reports were not re-run.")
    (out / "AUDIT.md").write_text("\n".join(md) + "\n")
    (out / "audit_summary.json").write_text(json.dumps(summary, indent=1, sort_keys=True))
    return summary


def ec_key(k):
    return "%s|%s|%s" % k


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="directory with inventory.json and exec_results.json")
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    d = Path(a.inp)
    inv = json.loads((d / "inventory.json").read_text())
    res = json.loads((d / "exec_results.json").read_text())
    s = build(inv, res, Path(a.out))
    print(json.dumps({k: v for k, v in s.items() if k in ("rtl_modules_unique", "compile_verilator", "compile_icarus", "testbenches_unique", "testbench_verdicts")}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
