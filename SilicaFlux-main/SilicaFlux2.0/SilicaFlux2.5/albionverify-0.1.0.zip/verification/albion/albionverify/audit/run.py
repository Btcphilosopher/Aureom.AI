"""`python -m albionverify.audit.run` : run the executed audit over a repository tree.

Outputs (in --out):
    inventory.json    static inventory (archives, files, units, assertions, roles)
    exec_results.json compile + testbench results from real tools
Then `python -m albionverify.audit.report --out <dir>` turns them into AUDIT.md / CSV.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from . import corpus as corpus_mod
from . import exec_checks


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo-root", default=".", help="repository root containing the SilicaFlux archives")
    ap.add_argument("--workdir", required=True, help="scratch directory (archives are extracted here)")
    ap.add_argument("--out", required=True, help="output directory for JSON results")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--skip-exec", action="store_true", help="inventory only (no compile / simulation)")
    ap.add_argument("--skip-tb", action="store_true")
    ap.add_argument("--tb-limit", type=int, default=None)
    ap.add_argument("--reuse-inventory", action="store_true")
    a = ap.parse_args(argv)

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    work = Path(a.workdir)
    work.mkdir(parents=True, exist_ok=True)
    inv_path = out / "inventory.json"

    t0 = time.time()
    if a.reuse_inventory and inv_path.exists():
        inv = json.loads(inv_path.read_text())
        print("reusing inventory", inv_path)
    else:
        c = corpus_mod.Corpus(Path(a.repo_root), work)
        c.discover()
        print("archives: %d (unique by content) ; loose HDL files: %d" % (len(c.archives), len(c.loose_files)))
        inv = corpus_mod.build_inventory(c)
        inv_path.write_text(json.dumps(inv))
        print("inventory: %d archives with HDL, %d files, %d units  (%.0fs)" % (len(inv["archives"]), len(inv["files"]), len(inv["units"]), time.time() - t0))
    if a.skip_exec:
        return 0
    res = exec_checks.run_exec_audit(inv, work, jobs=a.jobs, do_tb=not a.skip_tb, tb_limit=a.tb_limit)
    (out / "exec_results.json").write_text(json.dumps(res, indent=1))
    print("done in %.0fs" % (time.time() - t0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
