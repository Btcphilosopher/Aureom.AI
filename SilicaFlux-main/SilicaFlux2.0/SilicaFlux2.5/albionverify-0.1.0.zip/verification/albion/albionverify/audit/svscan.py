"""Lightweight SystemVerilog scanner used by the AlbionVerify audit.

This is deliberately *not* a full SystemVerilog parser.  It is a comment/string-aware
regex scanner that is good enough to answer the audit questions (which modules exist,
what they instantiate, which assertions they contain, whether they use constructs that
are not synthesizable).  Everything it reports is a static fact about the text; whether a
module *compiles* or a testbench *passes* is decided only by running real tools
(see compile_check.py / sim_check.py), never by this scanner.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

# --------------------------------------------------------------------------- text cleaning


def strip_comments(text: str) -> str:
    """Replace comments and string literals with spaces, preserving newlines/offsets."""
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        c2 = text[i : i + 2]
        if c2 == "//":
            j = text.find("\n", i)
            j = n if j < 0 else j
            out.append(" " * (j - i))
            i = j
        elif c2 == "/*":
            j = text.find("*/", i + 2)
            j = n if j < 0 else j + 2
            seg = text[i:j]
            out.append("".join("\n" if ch == "\n" else " " for ch in seg))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                if text[j] == "\\":
                    j += 1
                if text[j : j + 1] == "\n":
                    break
                j += 1
            j = min(j + 1, n)
            out.append('"' + " " * (j - i - 2) + '"' if j - i >= 2 else " " * (j - i))
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


# --------------------------------------------------------------------------- data classes


@dataclass
class ModuleInfo:
    name: str
    kind: str  # module | interface | package | program
    file: str
    line: int
    ports: List[Tuple[str, str]] = field(default_factory=list)  # (direction, name)
    n_ports: int = 0
    params: List[str] = field(default_factory=list)
    body: str = ""  # comment-stripped body (kept in memory only, not serialised)
    # derived facts
    instantiates: Set[str] = field(default_factory=set)
    uses_packages: Set[str] = field(default_factory=set)
    n_assert_prop: int = 0
    n_assert_imm: int = 0
    n_assume: int = 0
    n_cover: int = 0
    n_sva_property_decl: int = 0
    n_error_calls: int = 0  # $error/$fatal used as checks
    n_display: int = 0
    n_finish: int = 0
    n_delay: int = 0
    n_initial: int = 0
    n_random: int = 0
    n_fork: int = 0
    n_real: int = 0
    n_always_ff: int = 0
    n_always_comb: int = 0
    n_always_latch: int = 0
    n_always_other: int = 0
    n_dpi: int = 0
    n_readmem: int = 0
    marker_comments: List[str] = field(default_factory=list)

    def public(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k not in ("body",)}
        d["instantiates"] = sorted(self.instantiates)
        d["uses_packages"] = sorted(self.uses_packages)
        return d


# --------------------------------------------------------------------------- regexes

_DECL_RE = re.compile(
    r"^[ \t]*(?:extern[ \t]+)?(?:(?:virtual|automatic|static)[ \t]+)?(module|macromodule|interface|package|program)[ \t]+"
    r"(?:automatic[ \t]+|static[ \t]+)?([A-Za-z_]\w*)",
    re.M,
)
_END_RE = re.compile(r"\b(endmodule|endinterface|endpackage|endprogram)\b")
_IMPORT_RE = re.compile(r"\bimport\s+([A-Za-z_]\w*)\s*::")
_SCOPE_RE = re.compile(r"\b([A-Za-z_]\w*)\s*::")
_ASSERT_PROP_RE = re.compile(r"\bassert\s+property\b")
_ASSERT_IMM_RE = re.compile(r"\bassert\s*(?:final\s*)?\(")
_ASSUME_RE = re.compile(r"\bassume\s*(?:property\s*)?\(")
_COVER_RE = re.compile(r"\bcover\s*(?:property\s*)?\(")
_PROP_DECL_RE = re.compile(r"\b(?:property|sequence)\s+[A-Za-z_]\w*")
_ERR_RE = re.compile(r"\$(?:error|fatal)\b")
_DISP_RE = re.compile(r"\$(?:display|write|strobe|monitor|info|warning)\b")
_FINISH_RE = re.compile(r"\$(?:finish|stop)\b")
_DELAY_RE = re.compile(r"(?<![\w$`])#\s*\d")
_INITIAL_RE = re.compile(r"\binitial\b")
_RANDOM_RE = re.compile(r"\$(?:u?random|urandom_range|dist_\w+)\b")
_FORK_RE = re.compile(r"\bfork\b")
_REAL_RE = re.compile(r"\b(?:real|shortreal|realtime)\b")
_ALWAYS_FF_RE = re.compile(r"\balways_ff\b")
_ALWAYS_COMB_RE = re.compile(r"\balways_comb\b")
_ALWAYS_LATCH_RE = re.compile(r"\balways_latch\b")
_ALWAYS_RE = re.compile(r"\balways\b(?!_)")
_DPI_RE = re.compile(r"\bimport\s+\"DPI")
_READMEM_RE = re.compile(r"\$readmem[hb]\b")
_MARKER_RE = re.compile(
    r"\b(stand-?in|stub|place-?holder|behaviou?ral(?:\s+model)?|simulation[- ]only|"
    r"not\s+synthesi[sz]able|reference\s+model|golden\s+model|black-?box|"
    r"sim(?:ulation)?\s+model|verification[- ]only|mock)\b",
    re.I,
)  # word-bounded: an unbounded 'stand-?in' matches inside 'outstanding'


def _split_top_commas(s: str) -> List[str]:
    parts, depth, cur = [], 0, []
    for ch in s:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    if "".join(cur).strip():
        parts.append("".join(cur))
    return parts


def _matching_paren(s: str, start: int) -> int:
    """Index of the ')' matching the '(' at s[start]; -1 if unbalanced."""
    depth = 0
    for i in range(start, len(s)):
        if s[i] == "(":
            depth += 1
        elif s[i] == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


def _parse_header(body: str) -> Tuple[List[Tuple[str, str]], List[str]]:
    """Parse '#(params) (ports);' that follows the module name. Returns (ports, params)."""
    ports: List[Tuple[str, str]] = []
    params: List[str] = []
    i = 0
    n = len(body)
    while i < n and body[i].isspace():
        i += 1
    if i < n and body[i] == "#":
        j = body.find("(", i)
        if j >= 0:
            k = _matching_paren(body, j)
            if k > 0:
                for item in _split_top_commas(body[j + 1 : k]):
                    m = re.search(r"\b([A-Za-z_]\w*)\s*(?:=|$)", item.strip().split("=")[0] + "=")
                    nm = re.findall(r"[A-Za-z_]\w*", item.split("=")[0])
                    if nm:
                        params.append(nm[-1])
                i = k + 1
    while i < n and body[i].isspace():
        i += 1
    if i < n and body[i] == "(":
        k = _matching_paren(body, i)
        if k > 0:
            direction = ""
            for item in _split_top_commas(body[i + 1 : k]):
                it = item.strip()
                if not it:
                    continue
                dm = re.match(r"(input|output|inout|ref)\b", it)
                if dm:
                    direction = dm.group(1)
                core = it.split("=")[0]
                core = re.sub(r"\[[^\]]*\]", " ", core)
                toks = re.findall(r"[A-Za-z_]\w*", core)
                toks = [t for t in toks if t not in ("input", "output", "inout", "ref", "wire", "logic", "reg", "var", "signed", "unsigned", "bit", "int", "integer", "byte", "tri", "uwire")]
                if toks:
                    ports.append((direction or "?", toks[-1]))
    return ports, params


def scan_text(text: str, path: str) -> List[ModuleInfo]:
    clean = strip_comments(text)
    mods: List[ModuleInfo] = []
    pos = 0
    while True:
        m = _DECL_RE.search(clean, pos)
        if not m:
            break
        kind = m.group(1)
        if kind == "macromodule":
            kind = "module"
        name = m.group(2)
        if clean[max(0, m.start() - 8) : m.start()].strip().endswith("extern"):
            pos = m.end()
            continue
        e = _END_RE.search(clean, m.end())
        if not e:
            pos = m.end()
            continue
        body = clean[m.end() : e.start()]
        line = clean.count("\n", 0, m.start()) + 1
        mi = ModuleInfo(name=name, kind=kind, file=path, line=line, body=body)
        if kind in ("module", "interface", "program"):
            mi.ports, mi.params = _parse_header(body)
            mi.n_ports = len(mi.ports)
        # facts
        mi.uses_packages = set(_IMPORT_RE.findall(body)) | set(_SCOPE_RE.findall(body))
        mi.n_assert_prop = len(_ASSERT_PROP_RE.findall(body))
        mi.n_assert_imm = len(_ASSERT_IMM_RE.findall(body))
        mi.n_assume = len(_ASSUME_RE.findall(body))
        mi.n_cover = len(_COVER_RE.findall(body))
        mi.n_sva_property_decl = len(_PROP_DECL_RE.findall(body))
        mi.n_error_calls = len(_ERR_RE.findall(body))
        mi.n_display = len(_DISP_RE.findall(body))
        mi.n_finish = len(_FINISH_RE.findall(body))
        mi.n_delay = len(_DELAY_RE.findall(body))
        mi.n_initial = len(_INITIAL_RE.findall(body))
        mi.n_random = len(_RANDOM_RE.findall(body))
        mi.n_fork = len(_FORK_RE.findall(body))
        mi.n_real = len(_REAL_RE.findall(body))
        mi.n_always_ff = len(_ALWAYS_FF_RE.findall(body))
        mi.n_always_comb = len(_ALWAYS_COMB_RE.findall(body))
        mi.n_always_latch = len(_ALWAYS_LATCH_RE.findall(body))
        mi.n_always_other = len(_ALWAYS_RE.findall(body))
        mi.n_dpi = len(_DPI_RE.findall(body))
        mi.n_readmem = len(_READMEM_RE.findall(body))
        # marker comments: look at the *original* comment text just before/inside the unit
        a = text.rfind("\n", 0, max(0, _line_start(clean, m.start()) - 1))
        head = "\n".join(text.splitlines()[max(0, line - 12) : line + 2])
        mi.marker_comments = sorted({mm.group(1).lower() for mm in _MARKER_RE.finditer(head)})
        mods.append(mi)
        pos = e.end()
    # File-scope imports (``import pkg::*;`` before/between declarations) apply to every unit in the file.
    # Missing these silently drops package dependencies from the closure (found by auditing the audit).
    spans = []
    for mi in mods:
        spans.append((mi.line, mi.line + mi.body.count("\n") + 1))
    file_pkgs = set()
    lines = clean.split("\n")
    for i, ln in enumerate(lines, 1):
        if any(a <= i <= b for a, b in spans):
            continue
        file_pkgs.update(_IMPORT_RE.findall(ln))
        file_pkgs.update(_SCOPE_RE.findall(ln))
    for mi in mods:
        mi.uses_packages |= {p for p in file_pkgs if p != mi.name}
    return mods


def _line_start(s: str, idx: int) -> int:
    k = s.rfind("\n", 0, idx)
    return 0 if k < 0 else k + 1


_INST_RE = re.compile(
    r"(?<![\w.$`])([A-Za-z_]\w*)\s*"
    r"(?:#\s*\((?:[^()]|\((?:[^()]|\([^()]*\))*\))*\)\s*)?"
    r"([A-Za-z_]\w*)\s*(?:\[[^\]]*\]\s*)*\("
)


def resolve_instances(mods: List[ModuleInfo], known: Set[str]) -> None:
    """Fill ModuleInfo.instantiates: identifiers in 'TYPE [#(..)] inst (' position that are known modules."""
    if not known:
        return
    for mi in mods:
        if mi.kind == "package":
            continue
        found = {m.group(1) for m in _INST_RE.finditer(mi.body) if m.group(1) in known}
        found.discard(mi.name)
        mi.instantiates = found


# --------------------------------------------------------------------------- interface families

# Port-name signatures identifying a bus/handshake family exposed by a module's ports.
FAMILIES = [
    ("SFB2", ("req_valid", "req_ready", "rsp_valid")),
    ("SFB2-xbar-flat", ("m_req_valid", "s_req_valid", "m_rsp_valid")),
    ("AXI4", ("awvalid", "awready", "arvalid")),
    ("AXI4-prefixed", ("awvalid", "wvalid", "bvalid")),
    ("ALP", ("alp_req_valid", "alp_rsp_valid")),
    ("SRAM-core", ("req_valid", "req_ready", "rvalid")),
    ("SRAM-simple", ("addr", "wdata", "we")),
    ("register-bus", ("reg_addr", "reg_wdata", "reg_we")),
    ("irq", ("irq",)),
]


def interface_families(ports: List[Tuple[str, str]]) -> List[str]:
    names = {p[1].lower() for p in ports}
    joined = " ".join(names)
    fam = []
    for fname, sig in FAMILIES:
        if all(any(s in nm for nm in names) for s in sig):
            fam.append(fname)
    if any(nm.endswith(("_valid", "valid")) for nm in names) and any(nm.endswith(("_ready", "ready")) for nm in names):
        if "valid/ready" not in fam:
            fam.append("valid/ready")
    return fam
