"""Executed audit checks: compile every RTL unit and run every testbench with real tools.

Verdict policy (this is the 'do not report unexecuted tests as passing' rule, in code):

  compile:   PASS      tool exited 0 and printed no error
             FAIL      tool reported an error (first error line + category recorded)
             TIMEOUT   exceeded wall-clock limit
             (never inferred: a unit that was not run has no verdict at all)

  testbench: PASS        simulation finished (exit 0, $finish reached, no timeout) AND printed an explicit
                         pass marker AND printed no fail/error marker
             FAIL        printed a fail/error marker or exited non-zero after building
             NO_VERDICT  ran to completion but printed no explicit pass/fail marker (NOT counted as passing)
             TIMEOUT     exceeded the simulation wall-clock limit
             BUILD_FAIL  could not be built by any tool in this generic flow (this does NOT mean the
                         design is broken; many testbenches need project-specific flows/defines/plusargs)
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Dict, Iterable, List, Optional, Set, Tuple

# ------------------------------------------------------------------------------ tools


def tool_versions() -> Dict[str, str]:
    out = {}
    for name, cmd in (("verilator", ["verilator", "--version"]), ("iverilog", ["iverilog", "-V"])):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
            out[name] = (r.stdout or r.stderr).strip().splitlines()[0]
        except Exception as e:  # pragma: no cover
            out[name] = "unavailable: %s" % e
    return out


def run_cmd(cmd: List[str], cwd: Path, timeout: float, env: Optional[dict] = None) -> Tuple[int, str, bool]:
    """Run a command in its own process group; return (rc, combined_output, timed_out)."""
    try:
        p = subprocess.Popen(cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", start_new_session=True, env=env)
    except FileNotFoundError as e:
        return 127, "tool not found: %s" % e, False
    try:
        out, _ = p.communicate(timeout=timeout)
        return p.returncode, out, False
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        out, _ = p.communicate()
        return -9, (out or ""), True


# ------------------------------------------------------------------------------ dependency closure


@dataclass
class ArcIndex:
    """Per-archive declaration index used to compute source closures."""

    sha: str
    root: Path
    units: List[dict]
    # name -> list of unit dicts
    by_name: Dict[str, List[dict]] = field(default_factory=lambda: defaultdict(list))
    # file -> list of unit dicts
    by_file: Dict[str, List[dict]] = field(default_factory=lambda: defaultdict(list))
    file_sha: Dict[str, str] = field(default_factory=dict)
    header_dirs: List[str] = field(default_factory=list)

    @classmethod
    def build(cls, sha: str, root: Path, units: List[dict], files: List[dict]) -> "ArcIndex":
        ix = cls(sha=sha, root=root, units=units)
        for u in units:
            ix.by_name[u["name"]].append(u)
            ix.by_file[u["file"]].append(u)
        for f in files:
            ix.file_sha[f["path"]] = f["sha256"]
        hdirs = set()
        for f in files:
            if f["path"].lower().endswith((".svh", ".vh")):
                hdirs.add(str(PurePosixPath(f["path"]).parent))
        ix.header_dirs = sorted(hdirs)
        return ix


def _common_prefix_len(a: str, b: str) -> int:
    pa, pb = PurePosixPath(a).parent.parts, PurePosixPath(b).parent.parts
    n = 0
    for x, y in zip(pa, pb):
        if x != y:
            break
        n += 1
    return n


def _pick(cands: List[dict], from_file: str, allowed_roles: Optional[Set[str]] = None) -> Optional[dict]:
    if allowed_roles is not None:
        c2 = [c for c in cands if c["role"] in allowed_roles]
        cands = c2 or cands
    if not cands:
        return None
    return max(cands, key=lambda u: (_common_prefix_len(u["file"], from_file), -len(u["file"])))


def closure(ix: ArcIndex, top: dict, tb_mode: bool = False) -> Tuple[List[str], List[str]]:
    """Return (ordered_files, unresolved_names).  Packages first (topologically), then everything else.

    In tb_mode we may pull in tb_support / rtl / interface units; in RTL mode formal/tb units are
    not considered as dependencies.
    """
    allowed = {"rtl", "interface", "package", "tb_support"} | ({"tb_top"} if tb_mode else set())
    seen_files: List[str] = []
    seen: Set[str] = set()
    unresolved: Set[str] = set()
    queue = [top["file"]]
    while queue:
        f = queue.pop()
        if f in seen:
            continue
        seen.add(f)
        seen_files.append(f)
        for u in ix.by_file.get(f, []):
            for dep in list(u["instantiates"]) + list(u["uses_packages"]):
                if dep == u["name"]:
                    continue
                cands = ix.by_name.get(dep, [])
                pick = _pick(cands, f, allowed)
                if pick is None:
                    if dep in u["instantiates"]:
                        unresolved.add(dep)
                    continue
                if pick["file"] not in seen:
                    queue.append(pick["file"])
    # package ordering: package files first, each after the packages it uses
    pkg_files = [f for f in seen_files if any(u["kind"] == "package" for u in ix.by_file[f])]
    other = [f for f in seen_files if f not in pkg_files]
    ordered_pk: List[str] = []
    placed: Set[str] = set()

    def place(f: str, stack: Tuple[str, ...] = ()):
        if f in placed or f in stack:
            return
        for u in ix.by_file[f]:
            for dep in u["uses_packages"]:
                for cand in ix.by_name.get(dep, []):
                    if cand["kind"] == "package" and cand["file"] in pkg_files and cand["file"] != f:
                        place(cand["file"], stack + (f,))
        placed.add(f)
        ordered_pk.append(f)

    for f in sorted(pkg_files):
        place(f)
    other_sorted = sorted(other, key=lambda p: (p == top["file"], p))  # top file last
    return ordered_pk + other_sorted, sorted(unresolved)


def include_dirs(ix: ArcIndex, files: List[str]) -> List[str]:
    dirs = []
    for f in files:
        d = str(PurePosixPath(f).parent)
        if d not in dirs:
            dirs.append(d)
    for d in ix.header_dirs:
        if d not in dirs:
            dirs.append(d)
    return dirs


# ------------------------------------------------------------------------------ error classification

_ERR_CLASSES = [
    ("missing_module", re.compile(r"(Cannot find file containing module|Unknown module type|Unknown module|cannot find module|Module/UDP/primitive .* not found|Unable to bind|unknown module type)", re.I)),
    ("missing_include", re.compile(r"(Cannot find include file|include file .* not found|Unable to open include|could not open include)", re.I)),
    ("missing_package", re.compile(r"(Package/class for ':: reference' not found|Package .* not found|Unable to find package|Cannot find package|package .* not found)", re.I)),
    ("undefined_macro", re.compile(r"(Define or directive not defined|Undefined macro|`[A-Za-z_]\w*.*not defined|macro .* undefined)", re.I)),
    ("tool_unsupported_construct", re.compile(r"(not supported|unsupported|sorry:|syntax error|Unexpected|is not implemented|cannot .* with .*iverilog|This feature requires|Class|covergroup|randomize)", re.I)),
    ("elaboration_error", re.compile(r"(Cannot find|not declared|Unknown|Illegal|undeclared|not found|Port|%Error)", re.I)),
]


def classify_error(text: str) -> str:
    for name, rx in _ERR_CLASSES:
        if rx.search(text):
            return name
    return "other"


def first_error(text: str, n: int = 2) -> str:
    lines = [l.strip() for l in text.splitlines() if re.search(r"(%Error|error:|Error:|ERROR|sorry:|syntax error)", l)]
    if not lines:
        lines = [l.strip() for l in text.splitlines() if l.strip()][:n]
    return " | ".join(l[:260] for l in lines[:n])


# ------------------------------------------------------------------------------ compile check


def _cache_key(kind: str, top: str, ix: ArcIndex, files: List[str], hdirs: List[str], versions: Dict[str, str]) -> str:
    h = hashlib.sha256()
    h.update(kind.encode())
    h.update(top.encode())
    for f in files:
        h.update(ix.file_sha.get(f, f).encode())
    # headers that could be included
    for f in sorted(ix.file_sha):
        if f.lower().endswith((".svh", ".vh")):
            h.update(ix.file_sha[f].encode())
    h.update(json.dumps(versions, sort_keys=True).encode())
    return h.hexdigest()


def compile_unit(ix: ArcIndex, top: dict, versions: Dict[str, str], cache_dir: Path, timeout: float = 90.0) -> dict:
    files, unresolved = closure(ix, top)
    hdirs = include_dirs(ix, files)
    key = _cache_key("compile", top["name"], ix, files, hdirs, versions)
    cf = cache_dir / ("c_" + key + ".json")
    if cf.exists():
        r = json.loads(cf.read_text())
        r["cached"] = True
        return r
    inc = ["-I" + d for d in hdirs]
    res: dict = {"top": top["name"], "closure_files": len(files), "unresolved_instances": unresolved, "key": key, "cached": False}
    # --- verilator lint
    cmd = ["verilator", "--lint-only", "-Wno-fatal", "--top-module", top["name"]] + inc + files
    t0 = time.time()
    rc, out, to = run_cmd(cmd, ix.root, timeout)
    n_err = len(re.findall(r"^%Error", out, re.M))
    n_warn = len(re.findall(r"^%Warning", out, re.M))
    v = {"rc": rc, "errors": n_err, "warnings": n_warn, "seconds": round(time.time() - t0, 2)}
    if to:
        v["status"] = "TIMEOUT"
    elif rc == 0 and n_err == 0:
        v["status"] = "PASS"
    else:
        v["status"] = "FAIL"
        msg = first_error(out)
        v["first_error"] = msg
        v["error_class"] = classify_error(msg + "\n" + out[:2000])
    res["verilator"] = v
    # --- verilator lint with assertions enabled, only for units that have assertions
    if top.get("n_assert_prop") or top.get("n_assume") or top.get("n_cover"):
        cmd = ["verilator", "--lint-only", "--assert", "-Wno-fatal", "--top-module", top["name"]] + inc + files
        rc2, out2, to2 = run_cmd(cmd, ix.root, timeout)
        e2 = len(re.findall(r"^%Error", out2, re.M))
        res["verilator_assert"] = {"status": "TIMEOUT" if to2 else ("PASS" if rc2 == 0 and e2 == 0 else "FAIL"), "first_error": first_error(out2) if (rc2 != 0 or e2) else ""}
    # --- icarus elaboration
    cmd = ["iverilog", "-g2012", "-t", "null", "-s", top["name"]] + inc + files
    t0 = time.time()
    rc, out, to = run_cmd(cmd, ix.root, timeout)
    iv = {"rc": rc, "seconds": round(time.time() - t0, 2)}
    if to:
        iv["status"] = "TIMEOUT"
    elif rc == 0:
        iv["status"] = "PASS"
    else:
        iv["status"] = "FAIL"
        iv["first_error"] = first_error(out)
        iv["error_class"] = classify_error(out[:3000])
    res["icarus"] = iv
    cf.write_text(json.dumps(res))
    return res


# ------------------------------------------------------------------------------ testbench run

PASS_RX = re.compile(
    r"(\bPASS(?:ED)?\b|ALL\s+TESTS?\s+PASS|RESULT[: ]+PASS|TB_RESULT:\s*PASS|\bSUCCESS\b|tests?\s+passed|0\s+errors?\b|errors?\s*[=:]\s*0\b|failures?\s*[=:]\s*0\b|no\s+errors)",
    re.I,
)
# Strict failure markers.  The bare word "error" is NOT a marker (it appears in "error-free", "error response as
# specified", "range error -> SLVERR", ...); only conventional failure tokens are.
FAIL_RX = re.compile(
    r"(\bFAIL(?:ED|URE)?\b|(?:^|[\s\[\]])ERROR\s*[:!]|%Error|\bFATAL\s*[:!]|\bmismatch\b|assertion\s+failed|ASSERT\w*[\s-]*FAIL|TB_FATAL)",
    re.I,
)
# phrases that look like fail markers but are positive statements or announced *expected* failures
BENIGN_FAIL_RX = re.compile(
    r"(0\s+fail(?:ures|ed|s)?\b|fail(?:ures|ed|s)?\s*[=:]\s*0\b|errors?\s*[=:]\s*0\b|0\s+errors?\b|no\s+(?:fail|error)s?|\bfail(?:ures)?\s*=\s*0|"
    r"expected[- ]?(?:error|fail)|^\s*(?:\[\w+\]\s*)?Expecting\b|\bexpecting:|expect(?:ed)?\s+to\s+fail|negative\s+test|self-?test|^\s*ok\b)",
    re.I,
)


NEEDS_FLOW_RX = re.compile(
    r"(\+\w+\s*(?:=|<)?[^\n]{0,40}(?:required|missing|expected|not\s+given|not\s+provided)|(?:required|missing|usage)[^\n]{0,40}\+\w+|\bno\s+\+\w+|\bneed(?:s|ed)?\b[^\n]{0,24}\+\w+|missing\s+\S+\.(?:hex|mem|txt|bin|csv)\b|plusarg|"
    r"\$readmem[^\n]{0,60}(?:cannot|unable|fail|No such)|No such file|cannot\s+open|can't\s+open|could\s+not\s+open|file\s+not\s+found|usage:)",
    re.I,
)
TOOL_ERR_RX = re.compile(r"(internal\s+error|not\s+implemented|sorry:|unsupported|Segmentation fault|^vvp:.*\.cc:\d+:|vvp.*abort|\.cc:\d+:.*[Aa]ssertion|must be an integer/time variable)", re.I | re.M)


def judge_output(rc: int, out: str, timed_out: bool, finished: bool) -> Tuple[str, str]:
    if timed_out:
        return "TIMEOUT", "simulation exceeded wall-clock limit"
    lines = out.splitlines()
    for l in lines:
        if TOOL_ERR_RX.search(l):
            return "TOOL_ERROR", l.strip()[:220]
    fail_lines = []
    for l in lines:
        if FAIL_RX.search(l) and not BENIGN_FAIL_RX.search(l):
            fail_lines.append(l.strip())
    pass_lines = [l.strip() for l in lines if PASS_RX.search(l)]
    if fail_lines:
        if any(NEEDS_FLOW_RX.search(l) for l in fail_lines) or (rc != 0 and any(NEEDS_FLOW_RX.search(l) for l in lines)):
            return "NEEDS_FLOW", fail_lines[0][:220]
        if rc == 0 and finished and pass_lines:
            # contradictory evidence (e.g. a checker self-test that provokes failures on purpose and ends with PASS):
            # neither counted as passing nor as a design failure
            return "NO_VERDICT", "mixed markers: fail-like '%s' and pass-like '%s'" % (fail_lines[0][:80], pass_lines[-1][:80])
        return "FAIL", fail_lines[0][:220]
    if rc != 0:
        if any(NEEDS_FLOW_RX.search(l) for l in lines):
            return "NEEDS_FLOW", next(l for l in lines if NEEDS_FLOW_RX.search(l)).strip()[:220]
        return "FAIL", "non-zero exit code %d" % rc
    if pass_lines and finished:
        return "PASS", pass_lines[-1][:220]
    if pass_lines and not finished:
        return "NO_VERDICT", "pass-like text but simulation did not reach $finish"
    return "NO_VERDICT", (lines[-1][:200] if lines else "no output")


def run_testbench(ix: ArcIndex, tb: dict, versions: Dict[str, str], cache_dir: Path, workdir: Path, build_timeout: float = 150.0, sim_timeout: float = 60.0, try_verilator: bool = True) -> dict:
    files, unresolved = closure(ix, tb, tb_mode=True)
    hdirs = include_dirs(ix, files)
    key = _cache_key("tb", tb["name"], ix, files, hdirs, versions)
    cf = cache_dir / ("t_" + key + ".json")
    if cf.exists():
        r = json.loads(cf.read_text())
        r["cached"] = True
        return r
    inc = ["-I" + d for d in hdirs]
    jobdir = workdir / "tbrun" / key[:16]
    jobdir.mkdir(parents=True, exist_ok=True)
    res: dict = {"tb": tb["name"], "closure_files": len(files), "unresolved_instances": unresolved, "key": key, "cached": False, "attempts": []}
    final = None
    # ---------------- icarus
    vvp = jobdir / "sim.vvp"
    t0 = time.time()
    rc, out, to = run_cmd(["iverilog", "-g2012", "-s", tb["name"], "-o", str(vvp)] + inc + files, ix.root, build_timeout)
    att = {"tool": "iverilog", "build_rc": rc, "build_seconds": round(time.time() - t0, 2)}
    if rc == 0 and vvp.exists():
        t0 = time.time()
        rc2, out2, to2 = run_cmd(["vvp", "-n", str(vvp)], ix.root, sim_timeout)
        finished = bool(re.search(r"\$finish|\$stop|simulation complete|finish called", out2, re.I)) or rc2 == 0
        verdict, detail = judge_output(rc2, out2, to2, finished and not to2)
        att.update({"status": verdict, "detail": detail, "sim_seconds": round(time.time() - t0, 2), "tail": "\n".join(out2.splitlines()[-4:])[-400:]})
        if verdict != "TOOL_ERROR":
            final = att
    else:
        att.update({"status": "BUILD_FAIL", "detail": first_error(out), "error_class": classify_error(out[:3000])})
    res["attempts"].append(att)
    # ---------------- verilator fallback
    if final is None and try_verilator:
        mdir = jobdir / "obj"
        shutil.rmtree(mdir, ignore_errors=True)
        t0 = time.time()
        cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", tb["name"], "-Mdir", str(mdir), "-o", "simv"] + inc + files
        rc, out, to = run_cmd(cmd, ix.root, build_timeout)
        att2 = {"tool": "verilator", "build_rc": rc, "build_seconds": round(time.time() - t0, 2)}
        exe = mdir / "simv"
        if rc == 0 and exe.exists():
            t0 = time.time()
            rc2, out2, to2 = run_cmd([str(exe)], ix.root, sim_timeout)
            finished = bool(re.search(r"\$finish|\$stop|simulation complete|finish called|- .*:\d+: Verilog \$finish", out2, re.I)) or rc2 == 0
            verdict, detail = judge_output(rc2, out2, to2, finished and not to2)
            att2.update({"status": verdict, "detail": detail, "sim_seconds": round(time.time() - t0, 2), "tail": "\n".join(out2.splitlines()[-4:])[-400:]})
            final = att2
        else:
            att2.update({"status": "TIMEOUT" if to else "BUILD_FAIL", "detail": first_error(out), "error_class": classify_error(out[:3000])})
        res["attempts"].append(att2)
        shutil.rmtree(mdir, ignore_errors=True)
    if final is None:
        final = res["attempts"][-1]
        if final["status"] == "TOOL_ERROR":
            final = dict(final, status="BUILD_FAIL", error_class="tool_unsupported_construct")
    if final["status"] == "FAIL" and re.search(r"bug", tb["name"], re.I):
        # a testbench whose purpose is to demonstrate a bug prints failures on purpose
        final = dict(final, status="NO_VERDICT", detail="deliberate bug-demonstration testbench (by name): " + final.get("detail", ""))
    res["status"] = final["status"]
    res["detail"] = final.get("detail", "")
    res["tool"] = final["tool"]
    res["tail"] = final.get("tail", "")
    if final["status"] == "BUILD_FAIL":
        res["error_class"] = final.get("error_class", "other")
    cf.write_text(json.dumps(res))
    shutil.rmtree(jobdir, ignore_errors=True)
    return res


# ------------------------------------------------------------------------------ orchestration


def dedupe_units(inventory: dict) -> Dict[Tuple[str, str, str], dict]:
    """Map (unit name, file sha, role) -> first unit record; also record all archives it appears in."""
    fsha = {(f["arc"], f["path"]): f["sha256"] for f in inventory["files"]}
    uniq: Dict[Tuple[str, str, str], dict] = {}
    for u in inventory["units"]:
        k = (u["name"], fsha[(u["arc"], u["file"])], u["role"])
        if k not in uniq:
            uu = dict(u)
            uu["file_sha256"] = k[1]
            uu["seen_in"] = []
            uniq[k] = uu
        uniq[k]["seen_in"].append({"arc": u["arc"], "file": u["file"]})
    return uniq


def build_indexes(inventory: dict) -> Dict[str, ArcIndex]:
    by_arc_units: Dict[str, List[dict]] = defaultdict(list)
    by_arc_files: Dict[str, List[dict]] = defaultdict(list)
    for u in inventory["units"]:
        by_arc_units[u["arc"]].append(u)
    for f in inventory["files"]:
        by_arc_files[f["arc"]].append(f)
    idx = {}
    for sha, a in inventory["archives"].items():
        idx[sha] = ArcIndex.build(sha, Path(a["root"]), by_arc_units.get(sha, []), by_arc_files.get(sha, []))
    return idx


def run_exec_audit(inventory: dict, workdir: Path, jobs: int = 4, do_compile: bool = True, do_tb: bool = True, progress=print, tb_limit: Optional[int] = None) -> dict:
    cache_dir = workdir / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    versions = tool_versions()
    idx = build_indexes(inventory)
    uniq = dedupe_units(inventory)
    results = {"tool_versions": versions, "compile": {}, "tb": {}}

    # choose one representative archive per unique unit (the first one it was seen in)
    compile_jobs = []
    tb_jobs = []
    for k, u in uniq.items():
        rep = u["seen_in"][0]
        ixr = idx[rep["arc"]]
        urep = next(x for x in ixr.by_file[rep["file"]] if x["name"] == u["name"] and x["role"] == u["role"])
        if u["role"] == "rtl" and u["kind"] in ("module",):
            compile_jobs.append((k, ixr, urep))
        elif u["role"] == "tb_top":
            tb_jobs.append((k, ixr, urep))
    if tb_limit:
        tb_jobs = tb_jobs[:tb_limit]
    progress("unique RTL modules to compile: %d ; unique testbenches to run: %d" % (len(compile_jobs), len(tb_jobs)))

    def kstr(k):
        return "%s|%s|%s" % k

    if do_compile:
        t0 = time.time()
        with ThreadPoolExecutor(max_workers=jobs) as ex:
            futs = {ex.submit(compile_unit, ixr, urep, versions, cache_dir): k for k, ixr, urep in compile_jobs}
            for i, fu in enumerate(as_completed(futs), 1):
                k = futs[fu]
                try:
                    results["compile"][kstr(k)] = fu.result()
                except Exception as e:  # pragma: no cover
                    results["compile"][kstr(k)] = {"error": repr(e)}
                if i % 100 == 0:
                    progress("  compile %d/%d  (%.0fs)" % (i, len(compile_jobs), time.time() - t0))
    if do_tb:
        t0 = time.time()
        with ThreadPoolExecutor(max_workers=jobs) as ex:
            futs = {ex.submit(run_testbench, ixr, urep, versions, cache_dir, workdir): k for k, ixr, urep in tb_jobs}
            for i, fu in enumerate(as_completed(futs), 1):
                k = futs[fu]
                try:
                    results["tb"][kstr(k)] = fu.result()
                except Exception as e:  # pragma: no cover
                    results["tb"][kstr(k)] = {"error": repr(e), "status": "BUILD_FAIL"}
                if i % 20 == 0:
                    progress("  tb %d/%d  (%.0fs)" % (i, len(tb_jobs), time.time() - t0))
    return results
