"""Enumerate every HDL file in the repository (loose files and inside nested zip archives),
de-duplicate archives by content hash, extract each unique archive once, and scan it.

Extraction is safe (no absolute paths / '..' components) and every unique archive is
extracted into its own directory, keyed by the archive SHA-256.  Nothing extracted is ever
executed by this module.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Dict, Iterable, List, Optional, Set, Tuple

from . import svscan

HDL_EXT = (".sv", ".v", ".svh", ".vh")
SRC_EXT = (".sv", ".v")
SKIP_DIRS = {".git", "node_modules", "__pycache__"}


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


@dataclass
class Archive:
    sha: str
    labels: List[str]  # every location this exact archive appears at
    nbytes: int
    parent: Optional[str] = None  # sha of containing archive
    root: Optional[Path] = None  # extraction directory
    n_hdl: int = 0
    n_members: int = 0
    other_flow_files: List[str] = field(default_factory=list)  # Makefiles/run scripts/cocotb tests etc.

    @property
    def name(self) -> str:
        return PurePosixPath(self.labels[0].split("!")[-1]).name

    @property
    def short(self) -> str:
        return self.sha[:12]


def _safe_member(name: str) -> bool:
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and "\x00" not in name


class Corpus:
    def __init__(self, repo_root: Path, workdir: Path, exclude_prefixes: Iterable[str] = ("verification/", "albionverify-")):
        self.repo_root = Path(repo_root)
        self.workdir = Path(workdir)
        self.exclude = tuple(exclude_prefixes)
        self.archives: Dict[str, Archive] = {}
        self.loose_files: List[Path] = []

    # ------------------------------------------------------------------ discovery
    def discover(self) -> None:
        for dp, dn, fn in os.walk(self.repo_root):
            dn[:] = [d for d in dn if d not in SKIP_DIRS]
            rel_dir = os.path.relpath(dp, self.repo_root)
            for f in fn:
                rel = os.path.normpath(os.path.join(rel_dir, f))
                if rel.startswith(self.exclude):
                    continue
                p = Path(dp) / f
                lf = f.lower()
                if lf.endswith(".zip"):
                    try:
                        self._visit(p.read_bytes(), rel, None, 0)
                    except (OSError, zipfile.BadZipFile):
                        pass
                elif lf.endswith(HDL_EXT):
                    self.loose_files.append(p)

    def _visit(self, data: bytes, label: str, parent: Optional[str], depth: int) -> None:
        sha = sha256_bytes(data)
        if sha in self.archives:
            self.archives[sha].labels.append(label)
            return
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            return
        arc = Archive(sha=sha, labels=[label], nbytes=len(data), parent=parent)
        self.archives[sha] = arc
        root = self.workdir / "arc" / arc.short
        arc.root = root
        done_marker = root / ".extracted"
        extract = not done_marker.exists()
        for info in zf.infolist():
            if info.is_dir() or not _safe_member(info.filename):
                continue
            arc.n_members += 1
            low = info.filename.lower()
            if low.endswith(HDL_EXT):
                arc.n_hdl += 1
            if _is_flow_file(low):
                arc.other_flow_files.append(info.filename)
            if low.endswith(".zip") and depth < 4:
                self._visit(zf.read(info), label + "!" + info.filename, sha, depth + 1)
                continue  # nested archives are separate nodes; do not extract their bytes here
            if extract and (low.endswith(HDL_EXT) or _is_flow_file(low) or low.endswith((".md", ".hex", ".txt", ".mem", ".json", ".yaml", ".yml", ".toml", ".py", ".sh", ".mk", ".h", ".c", ".tcl", ".sdc", ".csv"))):
                dest = root / info.filename
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(zf.read(info))
        if extract:
            root.mkdir(parents=True, exist_ok=True)
            done_marker.write_text("ok")

    # ------------------------------------------------------------------ scanning
    def hdl_files(self, arc: Archive) -> List[Path]:
        out = []
        for dp, dn, fn in os.walk(arc.root):
            for f in fn:
                if f.lower().endswith(HDL_EXT):
                    out.append(Path(dp) / f)
        return sorted(out)


def _is_flow_file(low: str) -> bool:
    b = low.rsplit("/", 1)[-1]
    return (
        b in ("makefile", "gnumakefile", "run_sim.sh", "run_tests.sh", "sim.sh", "run.sh", "build.sh", "pytest.ini", "conftest.py", "tox.ini")
        or b.startswith(("test_", "run_", "regress"))
        and b.endswith((".py", ".sh", ".tcl"))
        or b.endswith(".mk")
    )


# --------------------------------------------------------------------------- classification

_TB_DIR = re.compile(r"(^|/)(tb|tbs|tests?|testbench(es)?|verif(ication)?|bench)(/|$)")
_FORMAL_DIR = re.compile(r"(^|/)(formal|fv)(/|$)")
_BEHAV_PATH = re.compile(r"(^|/)(sim_models?|behav\w*|models?|standin|stand_in|stubs?|mocks?|blackbox\w*|ref|reference)(/|$)")
_BEHAV_NAME = re.compile(r"(_behav\w*|_model|_ref|_stub|_standin|_stand_in|_bfm|_mock|_sim|^ref_|^model_|^mock_)$|^(ref|model|mock|bfm)_", re.I)


def classify_unit(mi: svscan.ModuleInfo, rel_path: str) -> Tuple[str, List[str]]:
    """Return (role, behavioural_reasons).  role in tb_top|tb_support|formal|package|interface|rtl."""
    p = rel_path.lower().replace("\\", "/")
    base = p.rsplit("/", 1)[-1]
    reasons: List[str] = []
    in_tb = bool(_TB_DIR.search(p)) or base.startswith("tb_") or mi.name.startswith("tb_") or mi.name.endswith("_tb")
    in_formal = bool(_FORMAL_DIR.search(p)) or base.startswith("fv_") or mi.name.startswith("fv_")
    if mi.kind == "package":
        role = "package"
    elif in_formal:
        role = "formal"
    elif in_tb or (mi.n_ports == 0 and mi.n_finish > 0):
        role = "tb_top" if (mi.n_ports == 0 and (mi.n_finish > 0 or mi.n_initial > 0 or mi.name.startswith("tb_"))) else "tb_support"
    elif mi.kind == "interface":
        role = "interface"
    else:
        role = "rtl"
    if role in ("rtl", "interface"):
        # S: = strong evidence the unit is a behavioural / stand-in / reference model;  W: = weak hint only.
        m = _BEHAV_PATH.search(p)
        if m:
            reasons.append("S:path:" + m.group(2))
        if _BEHAV_NAME.search(mi.name):
            reasons.append("S:name")
        for mk in mi.marker_comments:
            reasons.append("S:comment:" + mk)
        if mi.n_fork:
            reasons.append("S:fork")
        if mi.n_random:
            reasons.append("S:$random")
        if mi.n_real:
            reasons.append("S:real")
        if mi.n_dpi:
            reasons.append("S:DPI")
        if mi.n_delay:
            reasons.append("W:delays(#N)")
    return role, reasons


def scan_archive(corpus: Corpus, arc: Archive, known_global: Set[str]) -> Tuple[List[dict], List[dict]]:
    """Scan all HDL files of one archive. Returns (file_records, unit_records)."""
    files: List[dict] = []
    units: List[dict] = []
    per_file: List[Tuple[str, List[svscan.ModuleInfo]]] = []
    all_mods: List[svscan.ModuleInfo] = []
    for p in corpus.hdl_files(arc):
        rel = str(p.relative_to(arc.root))
        data = p.read_bytes()
        text = data.decode("utf-8", "replace")
        mods = svscan.scan_text(text, rel) if rel.lower().endswith(SRC_EXT) else []
        per_file.append((rel, mods))
        all_mods.extend(mods)
        files.append({"arc": arc.sha, "path": rel, "sha256": sha256_bytes(data), "bytes": len(data), "lines": text.count("\n") + 1, "units": [m.name for m in mods]})
    svscan.resolve_instances(all_mods, known_global)
    for rel, mods in per_file:
        for mi in mods:
            role, why = classify_unit(mi, rel)
            rec = mi.public()
            rec.update({"arc": arc.sha, "role": role, "behavioural_reasons": why, "families": svscan.interface_families(mi.ports)})
            units.append(rec)
    return files, units


def known_names(corpus: Corpus) -> Set[str]:
    """First pass: every module/interface name declared anywhere in the corpus."""
    names: Set[str] = set()
    rx = re.compile(r"^[ \t]*(?:module|macromodule|interface)[ \t]+(?:automatic[ \t]+|static[ \t]+)?([A-Za-z_]\w*)", re.M)
    for arc in corpus.archives.values():
        for p in corpus.hdl_files(arc):
            if p.suffix.lower() in SRC_EXT:
                txt = svscan.strip_comments(p.read_text("utf-8", "replace"))
                names.update(rx.findall(txt))
    return names


def build_inventory(corpus: Corpus) -> dict:
    names = known_names(corpus)
    archives = {}
    files: List[dict] = []
    units: List[dict] = []
    for sha, arc in sorted(corpus.archives.items(), key=lambda kv: kv[1].labels[0]):
        if arc.n_hdl == 0:
            continue
        f, u = scan_archive(corpus, arc, names)
        files += f
        units += u
        archives[sha] = {
            "sha256": sha,
            "name": arc.name,
            "labels": arc.labels,
            "n_hdl_files": arc.n_hdl,
            "bytes": arc.nbytes,
            "flow_files": sorted(arc.other_flow_files)[:50],
            "root": str(arc.root),
        }
    return {"archives": archives, "files": files, "units": units, "n_known_module_names": len(names)}
