"""Deterministic randomness for AlbionVerify.

Rules (enforced by convention and by tests/unit/test_rng.py):
  * Nothing in AlbionVerify ever calls the global ``random`` module or ``hash()``.
  * Every random stream is a ``random.Random`` derived from (root seed, stream name) via SHA-256,
    so adding or removing one stream never perturbs another, and the same seed reproduces the same
    stimulus on every machine and Python version.
"""
from __future__ import annotations

import hashlib
import random
from typing import List, Optional, Sequence


class SeedRoot:
    """Deterministic fan-out of one integer seed into named independent streams."""

    def __init__(self, seed: int, namespace: str = ""):
        self.seed = int(seed)
        self.namespace = namespace
        self._streams = {}

    def _derive(self, name: str) -> int:
        h = hashlib.sha256(("%d|%s|%s" % (self.seed, self.namespace, name)).encode()).digest()
        return int.from_bytes(h[:8], "little")

    def child(self, name: str) -> random.Random:
        """A fresh Random for ``name`` (same name => same stream, every call)."""
        return random.Random(self._derive(name))

    def stream(self, name: str) -> random.Random:
        """A cached Random for ``name`` (the same object on repeated calls)."""
        if name not in self._streams:
            self._streams[name] = self.child(name)
        return self._streams[name]

    def sub(self, name: str) -> "SeedRoot":
        return SeedRoot(self._derive("sub:" + name) & 0x7FFFFFFFFFFFFFFF, self.namespace + "/" + name)


class Throttle:
    """Per-cycle allow/deny decisions (ready/valid pacing, stalls, gaps).

    Modes
      always            : allow every cycle
      never             : deny every cycle (until ``set_mode`` is called)
      random:<p>        : allow with probability p each cycle
      bursty:<lo>-<hi>  : alternate allow-runs and deny-runs, each of random length in [lo, hi]
      pattern:<0110..>  : repeat the given 0/1 pattern
      stall:<n>         : deny the first n cycles, then always allow
    The owner calls ``allow()`` exactly once per cycle.  ``denied_run`` is the current run of denials
    (backpressure duration), ``max_denied_run`` the longest seen.
    """

    def __init__(self, rng: random.Random, spec: str = "always"):
        self.rng = rng
        self.spec = spec
        self.denied_run = 0
        self.max_denied_run = 0
        self.n_allowed = 0
        self.n_denied = 0
        self._phase_left = 0
        self._phase_allow = True
        self._pat_i = 0
        self.set_mode(spec)

    def set_mode(self, spec: str) -> None:
        self.spec = spec
        kind, _, arg = spec.partition(":")
        self.kind = kind
        self.p = 1.0
        self.lo = self.hi = 1
        self.pattern: List[bool] = []
        self._stall_left = 0
        if kind == "random":
            self.p = float(arg)
        elif kind == "bursty":
            lo, _, hi = arg.partition("-")
            self.lo, self.hi = int(lo), int(hi or lo)
            self._phase_left = 0
            self._phase_allow = True
        elif kind == "pattern":
            self.pattern = [c == "1" for c in arg]
            self._pat_i = 0
        elif kind == "stall":
            self._stall_left = int(arg)
        elif kind in ("always", "never"):
            pass
        else:
            raise ValueError("unknown throttle spec %r" % spec)

    def _next(self) -> bool:
        k = self.kind
        if k == "always":
            return True
        if k == "never":
            return False
        if k == "random":
            return self.rng.random() < self.p
        if k == "bursty":
            if self._phase_left <= 0:
                self._phase_allow = not self._phase_allow
                self._phase_left = self.rng.randint(self.lo, self.hi)
            self._phase_left -= 1
            return self._phase_allow
        if k == "pattern":
            v = self.pattern[self._pat_i % len(self.pattern)]
            self._pat_i += 1
            return v
        if k == "stall":
            if self._stall_left > 0:
                self._stall_left -= 1
                return False
            return True
        raise AssertionError(k)

    def allow(self) -> bool:
        v = self._next()
        if v:
            self.n_allowed += 1
            self.denied_run = 0
        else:
            self.n_denied += 1
            self.denied_run += 1
            if self.denied_run > self.max_denied_run:
                self.max_denied_run = self.denied_run
        return v


class Latency:
    """Response-latency generator (cycles >= ``min``).

    Specs: ``fixed:N``, ``uniform:LO-HI``, ``choice:a,b,c``, ``tail:N,P,M`` (N usually, M with prob P).
    """

    def __init__(self, rng: random.Random, spec: str = "fixed:1"):
        self.rng = rng
        kind, _, arg = spec.partition(":")
        self.kind = kind
        if kind == "fixed":
            self.n = int(arg)
        elif kind == "uniform":
            lo, _, hi = arg.partition("-")
            self.lo, self.hi = int(lo), int(hi)
        elif kind == "choice":
            self.choices = [int(x) for x in arg.split(",")]
        elif kind == "tail":
            n, p, m = arg.split(",")
            self.n, self.p, self.m = int(n), float(p), int(m)
        else:
            raise ValueError("unknown latency spec %r" % spec)
        self.spec = spec

    def next(self) -> int:
        k = self.kind
        if k == "fixed":
            return self.n
        if k == "uniform":
            return self.rng.randint(self.lo, self.hi)
        if k == "choice":
            return self.rng.choice(self.choices)
        if k == "tail":
            return self.m if self.rng.random() < self.p else self.n
        raise AssertionError(k)


def rand_bits(rng: random.Random, width: int) -> int:
    return rng.getrandbits(width) if width > 0 else 0


def weighted_choice(rng: random.Random, items: Sequence, weights: Sequence[float]):
    tot = float(sum(weights))
    x = rng.random() * tot
    acc = 0.0
    for it, w in zip(items, weights):
        acc += w
        if x < acc:
            return it
    return items[-1]
