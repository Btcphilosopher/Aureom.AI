"""Independent model of the descriptor-level behaviour of ``hpc_dma_adapter`` (HPC DMA adapter, Module 05).

Written from rtl/hpc_m05_dma_adapter/docs (01 architecture/interface, 02 address spaces, 03 transfer semantics),
not from the RTL.  The beat-level behaviour of the reused DataFabric engines is the DMA model (dma_spec /
dma_model); this module adds what the adapter owns:

  * the REGION rule: source and destination ranges must each lie entirely inside or entirely outside the
    scratchpad window ``[SPM_BASE, SPM_BASE + SPM_BYTES)``; checked only after DataFabric rules 1-7 passed;
    ``cpl_err_addr`` = the window boundary the offending range crosses;
  * address routing (which target a beat goes to) and the completion record expected for a descriptor.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Set, Tuple

from . import dma_spec as S

E_REGION = 11
ERROR_NAMES = dict(S.ERROR_NAMES)
ERROR_NAMES[E_REGION] = "REGION"


@dataclass(frozen=True)
class AdapterConfig:
    dw_bytes: int = 4
    engine: int = 0
    fifo_depth: int = 8
    burst: int = 8
    dual_port: int = 0
    max_out: int = 2
    max_len_log2: int = 24
    spm_base: int = 0x20000000
    spm_bytes: int = 65536
    spm_tag_w: int = 8
    cmd_depth: int = 2
    cpl_depth: int = 2
    tag_w: int = 8
    fab_slice: int = 0
    perf_en: int = 1
    cnt_w: int = 32

    @property
    def buffered(self) -> bool:
        return self.engine != 0

    @property
    def dual(self) -> bool:
        return self.buffered and self.dual_port != 0

    @property
    def nports(self) -> int:
        return 2 if self.dual else 1

    @property
    def out_limit(self) -> int:
        return self.max_out if self.buffered else 1

    @property
    def win_lo(self) -> int:
        return self.spm_base

    @property
    def win_hi(self) -> int:
        return self.spm_base + self.spm_bytes

    @staticmethod
    def from_params(p: dict) -> "AdapterConfig":
        return AdapterConfig(dw_bytes=p.get("DW", 32) // 8, engine=p.get("ENGINE", 0), fifo_depth=p.get("FIFO_DEPTH", 8), burst=p.get("BURST", 8),
                             dual_port=p.get("DUAL_PORT", 0), max_out=p.get("MAX_OUT", 2), max_len_log2=p.get("MAX_LEN_LOG2", 24),
                             spm_base=p.get("SPM_BASE", 0x20000000), spm_bytes=p.get("SPM_BYTES", 65536), spm_tag_w=p.get("SPM_TAG_W", 8),
                             cmd_depth=p.get("CMD_DEPTH", 2), cpl_depth=p.get("CPL_DEPTH", 2), tag_w=p.get("TAG_W", 8), fab_slice=p.get("FAB_SLICE", 0),
                             perf_en=p.get("PERF_EN", 1), cnt_w=p.get("CNT_W", 32))


def in_window(addr: int, cfg: AdapterConfig) -> bool:
    return cfg.win_lo <= addr < cfg.win_hi


def range_region_ok(start: int, n: int, cfg: AdapterConfig) -> bool:
    """True if [start, start+n) is entirely inside or entirely outside the scratchpad window."""
    lo, hi = start, start + n
    return (lo >= cfg.win_lo and hi <= cfg.win_hi) or hi <= cfg.win_lo or lo >= cfg.win_hi


def crossed_boundaries(start: int, n: int, cfg: AdapterConfig) -> Set[int]:
    """The window edge(s) a region-violating range crosses (empty for a legal range)."""
    if range_region_ok(start, n, cfg):
        return set()
    lo, hi = start, start + n
    out = set()
    if lo < cfg.win_lo < hi:
        out.add(cfg.win_lo)  # enters the window from below
    if lo < cfg.win_hi < hi:
        out.add(cfg.win_hi)  # leaves the window
    return out


def expected_completion(src: int, dst: int, length: int, cfg: AdapterConfig) -> Tuple[int, Set[int]]:
    """(code, legal cpl_err_addr values) of a descriptor that is rejected without any bus access, or
    (NONE, {0}) if the descriptor is legal (bus errors / aborts are only known from the run)."""
    code = S.validate(src, dst, length, cfg.dw_bytes, cfg.max_len_log2)
    if code != S.E_NONE:
        return code, {0}
    addrs = crossed_boundaries(src, length, cfg) | crossed_boundaries(dst, length, cfg)
    if addrs:
        return E_REGION, addrs
    return S.E_NONE, {0}


def target_of(addr: int, cfg: AdapterConfig) -> str:
    """Which target serves the word at ``addr``: the scratchpad port ('spm') or the DataFabric port ('fab')."""
    return "spm" if in_window(addr, cfg) else "fab"


def direction(src: int, dst: int, cfg: AdapterConfig) -> str:
    return "%s_to_%s" % (target_of(src, cfg), target_of(dst, cfg))
