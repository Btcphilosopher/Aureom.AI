"""Reference model of ``cc_secmon`` (security STATUS page: host write lock, write-once boot measurement, violation log).

Written from MEMORY_MAP.md (block ``cc_secmon``), 03_BOOT.md section 4 and HW_SW_INTERFACE.md -- NOT from the RTL.
  CAPS RO = bit4 HOST_WRITE_LOCK, bit5 IMAGE_CRC32, bit6 XN_DMEM_EXT_PERIPH, bits [3:0] = 0 (no auth / secure boot / RoT / debug).
  STATUS RO = [0] HOST_LOCK [1] MEASURED [3:2] AUTH_STATE (0) [8] HOST_VIOLATION.
  CTRL RW: [0] HOST_LOCK, set-only until system reset (a write of 0 does not release it).
  BOOT_MEASURE RW: written once (second write refused, value kept); MEASURED reports that it was written.
  VIOL_ADDR / VIOL_COUNT RO: address of the last refused host write / number of refused host writes (saturating).
  CLEAR WO: [0] clear HOST_VIOLATION.  AUTH_HOOK RO reads 0 (absent).
  host_lock pin = HOST_LOCK.
  Interpretations: A-1 (read of the WO CLEAR register is refused), A-10 (a violation event in the same cycle as CLEAR wins).
"""
from __future__ import annotations

from typing import Dict, Optional

from . import ctl_spec as S
from .ctl_base import MASK32, RegModel

A = S.SECMON
RO = (A["CAPS"], A["STATUS"], A["VIOL_ADDR"], A["VIOL_COUNT"], A["AUTH_HOOK"])


class SecmonModel(RegModel):
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.lock = 0
        self.meas_v = 0
        self.meas = 0
        self.viol = 0
        self.vaddr = 0
        self.vcnt = 0

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:
        addr, we = inp["addr"], inp["we"]
        known = (addr & 3) == 0 and addr in (A["CAPS"], A["STATUS"], A["CTRL"], A["BOOT_MEASURE"], A["VIOL_ADDR"], A["VIOL_COUNT"], A["CLEAR"], A["AUTH_HOOK"])
        if not known:
            err, rdata = 1, 0
        elif we:
            err = 1 if (addr in RO or (addr == A["BOOT_MEASURE"] and self.meas_v)) else 0
            rdata = None
        else:
            err = 1 if addr == A["CLEAR"] else 0
            if err:
                rdata = 0
            elif addr == A["CAPS"]:
                rdata = S.CAPS_VALUE
            elif addr == A["STATUS"]:
                rdata = (self.viol << 8) | (self.meas_v << 1) | self.lock
            elif addr == A["CTRL"]:
                rdata = self.lock
            elif addr == A["BOOT_MEASURE"]:
                rdata = self.meas
            elif addr == A["VIOL_ADDR"]:
                rdata = self.vaddr
            elif addr == A["VIOL_COUNT"]:
                rdata = self.vcnt
            else:
                rdata = 0  # AUTH_HOOK
        return {"rdata": rdata, "err": err, "host_lock": self.lock}

    def clock(self, inp: Dict[str, int]) -> None:
        if inp["sel"] and inp["we"] and not inp["addr"] & 3:
            a, d = inp["addr"], inp["wdata"] & MASK32
            if a == A["CTRL"] and d & 1:
                self.lock = 1
            elif a == A["BOOT_MEASURE"] and not self.meas_v:
                self.meas, self.meas_v = d, 1
            elif a == A["CLEAR"] and d & 1:
                self.viol = 0
        if inp["viol_evt"]:
            self.viol = 1
            self.vaddr = inp["viol_addr"] & MASK32
            if self.vcnt != MASK32:
                self.vcnt += 1
