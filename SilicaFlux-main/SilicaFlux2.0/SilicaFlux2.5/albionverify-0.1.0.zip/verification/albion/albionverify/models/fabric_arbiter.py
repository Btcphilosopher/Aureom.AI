"""Independent arbitration-policy model (SFB2 per-slave arbiter).

Specification used (not the RTL source):

* PROTOCOL.md section 4: ``ARB_MODE = 0`` fixed priority (master 0 highest), ``1`` round robin (pointer
  moves past the winner only on *acceptance*).  A granted request that was presented to the slave but not
  accepted keeps the grant next cycle (**grant lock**) so the slave-side payload is stable (R2 at the slave
  port).  Round robin: bounded waiting (<= N-1 other acceptances while a request waits), exclusive
  one-hot grant, work conservation.  Fixed priority starves lower masters under sustained contention.
* header comment of rtl/interconnect/sfb_arbiter.sv: the lock is released when the locked requester
  withdraws ("normal arbitration resumes in that cycle"); N need not be a power of two; the round-robin
  pointer is the priority-highest index.

Interpretation (spec is silent): after reset the lock is clear and the round-robin pointer is 0 (master 0
has the highest priority), i.e. the arbiter starts exactly like a fixed-priority one.
"""
from __future__ import annotations

from typing import List, Optional, Sequence

FIXED = 0
ROUND_ROBIN = 1


class ArbiterModel:
    def __init__(self, n: int, mode: int):
        self.n = n
        self.mode = mode
        self.reset()

    def reset(self) -> None:
        self.ptr = 0  # highest-priority index (round robin only)
        self.lock: Optional[int] = None  # requester that was presented but not accepted last cycle

    # ---- combinational: who is granted this cycle (pure function of state and ``req``)
    def select(self, req: Sequence[bool]) -> Optional[int]:
        n = self.n
        if self.lock is not None and req[self.lock]:
            return self.lock
        if self.mode == FIXED:
            for i in range(n):
                if req[i]:
                    return i
            return None
        for k in range(n):
            i = (self.ptr + k) % n
            if req[i]:
                return i
        return None

    # ---- sequential: state update at the clock edge
    def step(self, winner: Optional[int], presented: bool, accepted: bool) -> None:
        """``presented``: the winner's request was offered to the slave this cycle (valid at the slave
        port); ``accepted``: the slave took it (valid && ready)."""
        self.lock = winner if (winner is not None and presented and not accepted) else None
        if self.mode == ROUND_ROBIN and accepted and winner is not None:
            self.ptr = (winner + 1) % self.n

    # ---- helpers for property checks / stimulus
    def distance(self, i: int) -> int:
        """Round-robin rank of requester i from the pointer (0 = highest priority)."""
        return (i - self.ptr) % self.n


def rr_wait_bound(n: int) -> int:
    """Maximum number of OTHER acceptances a continuously waiting requester can see (PROTOCOL.md sec. 4)."""
    return n - 1
