"""Independent reference arithmetic for the SilicaFlux-HPC vector lane (IEEE 754-2019 binary32).

Written from first principles and from the *documented* lane policy (rtl/hpc_m03_vector_array README and
docs/*.md, RISC-V conventions) -- never from the RTL data path.  Everything is exact integer arithmetic:

  * a finite operand is decoded to  (-1)^s * m * 2^e  with integer m (no rounding anywhere until the very end);
  * add / sub / mul / fma form the EXACT result as one big integer significand and round once;
  * round_pack() implements the five rounding modes (RNE, RTZ, RDN, RUP, RMM = round-to-nearest ties-away),
    gradual underflow (full subnormal support, no flush-to-zero), overflow policy, and the flags
        NV  invalid            DZ  never raised (no division)
        OF  overflow           UF  tiny (detected AFTER rounding) AND inexact
        NX  inexact
  * NaN results are the canonical quiet NaN 0x7FC00000 (RISC-V); NaN payloads are never propagated, except by
    FMV (bit-exact move) and by FMIN/FMAX which return the non-NaN operand bit-exactly;
  * zero results: an exact zero sum of opposite-signed terms (including exact cancellation) is +0, or -0 in
    round-down; a zero sum of same-signed zero terms keeps that sign; a non-zero value that rounds to zero keeps
    its own sign.

Flag word layout (RISC-V fflags): bit4 NV, bit3 DZ, bit2 OF, bit1 UF, bit0 NX.
"""
from __future__ import annotations

from typing import Tuple

NV, DZ, OF, UF, NX = 16, 8, 4, 2, 1
QNAN = 0x7FC00000
RNE, RTZ, RDN, RUP, RMM = 0, 1, 2, 3, 4
M32 = 0xFFFFFFFF

# --------------------------------------------------------------------------- operation encodings (docs: ARRAY_INTERFACE 4.1)
OP_FMV, OP_FADD, OP_FSUB, OP_FMUL, OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD = 0, 1, 2, 3, 4, 5, 6, 7
OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE = 8, 9, 10, 11, 12
OP_IADD, OP_IMUL = 0x10, 0x11
ROUNDING_OPS = (OP_FADD, OP_FSUB, OP_FMUL, OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD)
FCMP_OPS = (OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE)
INT_OPS = (OP_IADD, OP_IMUL)
FMA_OPS = (OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD)
ALL_LEGAL_OPS = (OP_FMV,) + ROUNDING_OPS + FCMP_OPS + INT_OPS
OP_NAMES = {OP_FMV: "FMV", OP_FADD: "FADD", OP_FSUB: "FSUB", OP_FMUL: "FMUL", OP_FMADD: "FMADD", OP_FMSUB: "FMSUB",
            OP_FNMSUB: "FNMSUB", OP_FNMADD: "FNMADD", OP_FMIN: "FMIN", OP_FMAX: "FMAX", OP_FEQ: "FEQ", OP_FLT: "FLT",
            OP_FLE: "FLE", OP_IADD: "IADD", OP_IMUL: "IMUL"}


# --------------------------------------------------------------------------- classification
def sign_of(x: int) -> int:
    return (x >> 31) & 1


def exp_of(x: int) -> int:
    return (x >> 23) & 0xFF


def frac_of(x: int) -> int:
    return x & 0x7FFFFF


def is_nan(x: int) -> bool:
    return exp_of(x) == 0xFF and frac_of(x) != 0


def is_snan(x: int) -> bool:
    return is_nan(x) and not (x >> 22) & 1


def is_inf(x: int) -> bool:
    return exp_of(x) == 0xFF and frac_of(x) == 0


def is_zero(x: int) -> bool:
    return (x & 0x7FFFFFFF) == 0


def is_subnormal(x: int) -> bool:
    return exp_of(x) == 0 and frac_of(x) != 0


def value_class(x: int) -> str:
    """Coarse class used by functional coverage and generators."""
    if is_nan(x):
        return "snan" if is_snan(x) else "qnan"
    if is_inf(x):
        return "inf"
    if is_zero(x):
        return "zero"
    if is_subnormal(x):
        return "subnormal"
    if exp_of(x) == 254:
        return "huge"
    if exp_of(x) == 1:
        return "tiny_normal"
    return "normal"


def decode_finite(x: int) -> Tuple[int, int, int]:
    """Finite x -> (sign, m, e) with |x| = m * 2**e exactly (m = 0 for the zeros)."""
    s = sign_of(x)
    ex = exp_of(x)
    fr = frac_of(x)
    if ex == 0:
        return s, fr, -149
    return s, fr | (1 << 23), ex - 150


# --------------------------------------------------------------------------- rounding
def _rnd_to_grid(m: int, e: int, lsb: int, sign: int, rm: int) -> Tuple[int, bool]:
    """Round m*2**e to an integer multiple q*2**lsb.  Returns (q, inexact)."""
    sh = lsb - e
    if sh <= 0:
        return m << (-sh), False
    q = m >> sh
    rem = m - (q << sh)
    if rem == 0:
        return q, False
    half = 1 << (sh - 1)
    if rm == RNE:
        inc = rem > half or (rem == half and (q & 1))
    elif rm == RMM:
        inc = rem >= half
    elif rm == RTZ:
        inc = False
    elif rm == RDN:
        inc = bool(sign)
    elif rm == RUP:
        inc = not sign
    else:
        raise ValueError("illegal rounding mode %d" % rm)
    return q + (1 if inc else 0), True


def _overflow_result(sign: int, rm: int) -> int:
    to_inf = {RNE: True, RMM: True, RTZ: False, RDN: bool(sign), RUP: not sign}[rm]
    return (sign << 31) | (0x7F800000 if to_inf else 0x7F7FFFFF)


def round_pack(sign: int, m: int, e: int, rm: int) -> Tuple[int, int]:
    """Round the exact non-zero value (-1)^sign * m * 2**e to binary32.  Returns (bits, flags)."""
    assert m > 0
    E = e + m.bit_length() - 1  # exponent of the leading one
    lsb24 = E - 23  # 24-bit significand, unbounded exponent range
    lsb = max(lsb24, -149)  # the grid actually available (subnormals share the 2**-149 grid)
    q, inexact = _rnd_to_grid(m, e, lsb, sign, rm)
    # tininess is detected AFTER rounding (documented lane policy): round to 24 bits with an unbounded exponent
    # range; the result is tiny iff that value is still below the smallest normal 2**-126.
    tiny = False
    if E < -126:
        q24, _ = _rnd_to_grid(m, e, lsb24, sign, rm)
        # |value24| = q24 * 2**lsb24 < 2**-126  <=>  q24 < 2**(-126 - lsb24)   (E < -126 => exponent is positive)
        tiny = q24 < (1 << (-126 - lsb24))
    # overflow: rounded magnitude >= 2**128
    top = lsb + q.bit_length() - 1 if q else -1000
    if top >= 128:
        return _overflow_result(sign, rm), OF | NX
    bits = (sign << 31) | (((lsb + 149) << 23) + q)
    flags = NX if inexact else 0
    if inexact and tiny:
        flags |= UF
    return bits, flags


def _sum_exact(t1: Tuple[int, int, int], t2: Tuple[int, int, int]) -> Tuple[int, int, int]:
    """Exact sum of two (sign, m, e) terms -> (sign, magnitude, e); magnitude 0 means an exact zero sum."""
    (s1, m1, e1), (s2, m2, e2) = t1, t2
    if m1 == 0:
        return s2, m2, e2
    if m2 == 0:
        return s1, m1, e1
    e = min(e1, e2)
    v = (-m1 if s1 else m1) * (1 << (e1 - e)) + (-m2 if s2 else m2) * (1 << (e2 - e))
    return (1 if v < 0 else 0), abs(v), e


def _finish_sum(t1, t2, rm: int) -> Tuple[int, int]:
    """Round the exact sum of two finite terms, applying the zero-sign rules."""
    s, m, e = _sum_exact(t1, t2)
    if m == 0:
        s1, s2 = t1[0], t2[0]
        if t1[1] == 0 and t2[1] == 0 and s1 == s2:
            return (s1 << 31), 0  # (+0)+(+0) = +0, (-0)+(-0) = -0 in every mode
        return ((1 << 31) if rm == RDN else 0), 0  # exact cancellation / opposite-signed zeros
    return round_pack(s, m, e, rm)


def _check_rm(rm: int) -> None:
    if rm not in (RNE, RTZ, RDN, RUP, RMM):
        raise ValueError("illegal rounding mode %d for a rounding operation" % rm)


# --------------------------------------------------------------------------- IEEE operations
def fadd(a: int, b: int, rm: int, sub: bool = False) -> Tuple[int, int]:
    """round(a + b) or round(a - b).  Returns (bits, flags)."""
    _check_rm(rm)
    sb = sign_of(b) ^ (1 if sub else 0)
    if is_nan(a) or is_nan(b):
        return QNAN, NV if (is_snan(a) or is_snan(b)) else 0
    ia, ib = is_inf(a), is_inf(b)
    if ia and ib:
        if sign_of(a) != sb:
            return QNAN, NV
        return (sign_of(a) << 31) | 0x7F800000, 0
    if ia:
        return (sign_of(a) << 31) | 0x7F800000, 0
    if ib:
        return (sb << 31) | 0x7F800000, 0
    s1, m1, e1 = decode_finite(a)
    s2, m2, e2 = decode_finite(b)
    return _finish_sum((s1, m1, e1), (sb, m2, e2), rm)


def fmul(a: int, b: int, rm: int) -> Tuple[int, int]:
    _check_rm(rm)
    sp = sign_of(a) ^ sign_of(b)
    if is_nan(a) or is_nan(b):
        return QNAN, NV if (is_snan(a) or is_snan(b)) else 0
    if (is_inf(a) and is_zero(b)) or (is_zero(a) and is_inf(b)):
        return QNAN, NV
    if is_inf(a) or is_inf(b):
        return (sp << 31) | 0x7F800000, 0
    _, ma, ea = decode_finite(a)
    _, mb, eb = decode_finite(b)
    if ma == 0 or mb == 0:
        return sp << 31, 0
    return round_pack(sp, ma * mb, ea + eb, rm)


def fma(a: int, b: int, c: int, rm: int, neg_prod: bool = False, neg_add: bool = False) -> Tuple[int, int]:
    """round( (neg_prod ? -(a*b) : a*b) + (neg_add ? -c : c) ), one rounding.  FMADD: no negation; FMSUB: neg_add;
    FNMSUB: neg_prod; FNMADD: both."""
    _check_rm(rm)
    sp = sign_of(a) ^ sign_of(b) ^ (1 if neg_prod else 0)
    sc = sign_of(c) ^ (1 if neg_add else 0)
    inv = (is_inf(a) and is_zero(b)) or (is_zero(a) and is_inf(b))
    if is_nan(a) or is_nan(b) or is_nan(c):
        # RISC-V: NV for a signalling NaN input, and for inf*0 even when c is a quiet NaN
        return QNAN, NV if (is_snan(a) or is_snan(b) or is_snan(c) or inv) else 0
    if inv:
        return QNAN, NV
    prod_inf = is_inf(a) or is_inf(b)
    if prod_inf and is_inf(c):
        if sp != sc:
            return QNAN, NV
        return (sp << 31) | 0x7F800000, 0
    if prod_inf:
        return (sp << 31) | 0x7F800000, 0
    if is_inf(c):
        return (sc << 31) | 0x7F800000, 0
    _, ma, ea = decode_finite(a)
    _, mb, eb = decode_finite(b)
    _, mc, ec = decode_finite(c)
    return _finish_sum((sp, ma * mb, ea + eb), (sc, mc, ec), rm)


def fmin(a: int, b: int, want_max: bool = False) -> Tuple[int, int]:
    """IEEE minimumNumber / maximumNumber (RISC-V FMIN.S / FMAX.S): NaN loses, both NaN -> canonical NaN,
    -0 < +0, NV if either input is a signalling NaN."""
    nv = NV if (is_snan(a) or is_snan(b)) else 0
    if is_nan(a) and is_nan(b):
        return QNAN, nv
    if is_nan(a):
        return b, nv
    if is_nan(b):
        return a, nv
    lt = _lt_total(a, b)
    if want_max:
        return (b if lt else a), nv
    return (a if lt else b), nv


def _lt_total(a: int, b: int) -> bool:
    ka = -(a & 0x7FFFFFFF) if sign_of(a) else (a & 0x7FFFFFFF)
    kb = -(b & 0x7FFFFFFF) if sign_of(b) else (b & 0x7FFFFFFF)
    if ka == kb:
        return sign_of(a) == 1 and sign_of(b) == 0  # -0 < +0
    return ka < kb


def _lt_num(a: int, b: int) -> bool:
    if is_zero(a) and is_zero(b):
        return False
    return _lt_total(a, b)


def feq(a: int, b: int) -> Tuple[int, int]:
    nv = NV if (is_snan(a) or is_snan(b)) else 0  # quiet comparison: NV only for sNaN
    if is_nan(a) or is_nan(b):
        return 0, nv
    return (1 if (a == b or (is_zero(a) and is_zero(b))) else 0), nv


def flt(a: int, b: int) -> Tuple[int, int]:
    if is_nan(a) or is_nan(b):
        return 0, NV  # signalling comparison: NV for any NaN
    return (1 if _lt_num(a, b) else 0), 0


def fle(a: int, b: int) -> Tuple[int, int]:
    if is_nan(a) or is_nan(b):
        return 0, NV
    return (1 if (_lt_num(a, b) or a == b or (is_zero(a) and is_zero(b))) else 0), 0


def rm_legal(rm: int) -> bool:
    return 0 <= rm <= 4


def op_legal(op: int, rm: int, en_fcmp: bool = True, en_int: bool = True) -> bool:
    """Lane / array element-operation legality (docs: ARRAY_INTERFACE 4.3, lane decode table)."""
    if op == OP_FMV:
        return True
    if op in ROUNDING_OPS:
        return rm_legal(rm)
    if op in FCMP_OPS:
        return bool(en_fcmp)
    if op in INT_OPS:
        return bool(en_int)
    return False


def exec_op(op: int, a: int, b: int, c: int, rm: int, en_fcmp: bool = True, en_int: bool = True) -> Tuple[int, int, bool]:
    """Execute one lane operation.  Returns (result, flags, illegal).  An illegal operation yields (0, 0, True)."""
    a &= M32
    b &= M32
    c &= M32
    if not op_legal(op, rm, en_fcmp, en_int):
        return 0, 0, True
    if op == OP_FMV:
        r, f = a, 0
    elif op == OP_FADD:
        r, f = fadd(a, b, rm)
    elif op == OP_FSUB:
        r, f = fadd(a, b, rm, sub=True)
    elif op == OP_FMUL:
        r, f = fmul(a, b, rm)
    elif op == OP_FMADD:
        r, f = fma(a, b, c, rm)
    elif op == OP_FMSUB:
        r, f = fma(a, b, c, rm, neg_add=True)
    elif op == OP_FNMSUB:
        r, f = fma(a, b, c, rm, neg_prod=True)
    elif op == OP_FNMADD:
        r, f = fma(a, b, c, rm, neg_prod=True, neg_add=True)
    elif op == OP_FMIN:
        r, f = fmin(a, b)
    elif op == OP_FMAX:
        r, f = fmin(a, b, want_max=True)
    elif op == OP_FEQ:
        r, f = feq(a, b)
    elif op == OP_FLT:
        r, f = flt(a, b)
    elif op == OP_FLE:
        r, f = fle(a, b)
    elif op == OP_IADD:
        r, f = (a + b) & M32, 0
    elif op == OP_IMUL:
        r, f = (a * b) & M32, 0
    else:  # pragma: no cover - op_legal() above covers every legal code
        raise AssertionError(op)
    return r & M32, f, False
