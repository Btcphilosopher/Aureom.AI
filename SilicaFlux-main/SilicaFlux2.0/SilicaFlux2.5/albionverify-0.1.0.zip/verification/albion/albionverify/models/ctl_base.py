"""Common base for the ControlCore register-level reference models.

All control register pages share the SilicaFlux-V register-bus contract (rtl/controlcore/docs/01_ARCHITECTURE.md
section 5, HW_SW_INTERFACE.md): one access = one cycle (``sel`` [+ ``we``] with ``addr``/``wdata``), the page answers
``rdata`` / ``err`` combinationally in that cycle, side effects happen at the end of the cycle, a refused access
(``err = 1``) has no side effect.

A model exposes
    reset()                    all state to its documented reset value
    evaluate(inp) -> dict      the outputs of the CURRENT cycle (pure function of state + inputs, no state change)
    clock(inp)                 state update at the end of the cycle
    step(inp, resets) -> dict  reset handling + evaluate + clock (what the lockstep checker calls)
``inp`` is a dict with at least sel / we / addr / wdata plus the block's own event inputs.
An expected value of ``None`` means "unspecified / do not compare".
"""
from __future__ import annotations

from typing import Dict, Optional


MASK32 = 0xFFFF_FFFF


class RegModel:
    #: bits of rdata that are specified for each register offset; default: all 32
    def rdata_mask(self, addr: int) -> int:
        return MASK32

    def reset(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:  # pragma: no cover - abstract
        raise NotImplementedError

    def clock(self, inp: Dict[str, int]) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    def in_reset(self, resets: Dict[str, bool]) -> bool:
        return bool(resets.get("sys", False))

    def apply_reset(self, resets: Dict[str, bool]) -> None:
        if resets.get("sys", False):
            self.reset()

    def step(self, inp: Dict[str, int], resets: Dict[str, bool]) -> Dict[str, Optional[int]]:
        self.apply_reset(resets)
        out = self.evaluate(inp)
        if not self.in_reset(resets):
            self.clock(inp)
        return out


def is_write(inp: Dict[str, int]) -> bool:
    return bool(inp["sel"]) and bool(inp["we"])


def is_read(inp: Dict[str, int]) -> bool:
    return bool(inp["sel"]) and not bool(inp["we"])
