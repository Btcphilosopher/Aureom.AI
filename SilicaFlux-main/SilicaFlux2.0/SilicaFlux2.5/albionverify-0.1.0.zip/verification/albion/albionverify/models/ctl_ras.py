"""Reference model of ``cc_ras`` (error collection, severity, counters, first/last capture, injection, parity controls).

Written from MEMORY_MAP.md (block ``cc_ras`` + RAS_SRC enumeration), 04_INTERRUPTS.md (FATAL / RAS_WARN sources,
acknowledge by W1C of RAS.STATUS), 09_LIMITATIONS.md (level sources, counts saturate at 2^32-1) and HW_SW_INTERFACE.md
(``ras_fatal_o`` = STATUS[15:8] != 0 and CTRL.FATAL_TO_HOST) -- NOT from the RTL.

Documented behaviour used
  STATUS (W1C): sticky source bits, [7:0] warning class, [15:8] fatal class; level sources re-set while active.
    BUS_DECODE=0 PERIPH_ERR=1 DMA_ERR=2 HOST_VIOL=3 ISO_ACCESS=4 EXT_WARN=5 SW_WARN=6 | MEM_PARITY=8 TSU_HALTED=9 EXT_FATAL=10 SW_FATAL=11.
    EXT_WARN / EXT_FATAL / TSU_HALTED are level inputs (lv_*), the others are one-cycle event pulses (ev_*) or the SW_REPORT write.
  WARN_EN [7:0] / FATAL_EN [7:0]: sources -> interrupt.  irq_warn = |(STATUS[7:0] & WARN_EN), irq_fatal = |(STATUS[15:8] & FATAL_EN).
  WARN_COUNT / FATAL_COUNT RO: event counters (one per source per cycle, pulses and RISING EDGES of level sources),
    saturating at 2^32-1, cleared by CTRL.CLEAR_COUNTS.
  FIRST_SRC RO [4:0] source of the first event since CLEAR_FIRST, [31] VALID;  LAST_SRC likewise for the most recent event;
    FIRST_ADDR / LAST_ADDR the associated address (bus-decode / periph-error / host-violation / parity address inputs;
    SW_REPORT: its code).
  INJECT WO [15:0]: raise these sources (only defined sources can be raised).  SW_REPORT WO: [31] FATAL, [30:0] code -> SW_FATAL / SW_WARN;
    SW_CODE RO = last code.
  CTRL RW reset 1: [0] FATAL_TO_HOST [1] FATAL_ISOLATE; write-1 pulses [2] CLEAR_FIRST [3] CLEAR_COUNTS (read back 0).
  PAR_INJECT RW [0] arm, self-clearing on the next IMEM/DMEM write (mem_write); PAR_CHK_EN RW [0]; RAW RO live levels [2:0].
  Pins: fatal_pin = FATAL_TO_HOST & |STATUS[15:8]; fatal_iso = FATAL_ISOLATE & |STATUS[15:8]; par_inject, par_chk_en.
Interpretations of what the documents leave open (docs/ctl_verification_plan.md): A-7 for several events in one cycle FIRST_SRC takes
  the lowest and LAST_SRC the highest source index; A-8 address of sources without an address input is 0, FIRST/LAST_ADDR of an
  injection-only event are unspecified (not compared); A-13 INJECT bit 7 and bits [15:12] raise nothing (no such source);
  A-14 an event in the same cycle as CLEAR_FIRST becomes the new first event; A-15 a new event wins over a same-cycle W1C.
"""
from __future__ import annotations

from typing import Dict, Optional

from . import ctl_spec as S
from .ctl_base import MASK32, RegModel

A = S.RAS
SRC = S.RAS_SRC
INJ_MASK = 0x0F7F  # defined sources: 0..6 and 8..11
RO = ("WARN_COUNT", "FATAL_COUNT", "FIRST_SRC", "FIRST_ADDR", "LAST_SRC", "LAST_ADDR", "SW_CODE", "RAW")
WO = ("INJECT", "SW_REPORT")
RW = ("STATUS", "WARN_EN", "FATAL_EN", "CTRL", "PAR_INJECT", "PAR_CHK_EN")
KIND = {A[n]: "ro" for n in RO}
KIND.update({A[n]: "wo" for n in WO})
KIND.update({A[n]: "rw" for n in RW})
NAME = {v: k for k, v in A.items()}


class RasModel(RegModel):
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.st = 0
        self.wen = 0
        self.fen = 0
        self.wcnt = 0
        self.fcnt = 0
        self.first_v = 0
        self.first_src = 0
        self.first_addr: Optional[int] = 0
        self.last_v = 0
        self.last_src = 0
        self.last_addr: Optional[int] = 0
        self.sw_code = 0
        self.ctl_host = S.RAS_CTRL_RESET & 1
        self.ctl_iso = (S.RAS_CTRL_RESET >> 1) & 1
        self.pinj = 0
        self.pchk = 0
        self.lv_prev = 0
        self.first_stale = False  # CLEAR_FIRST dropped VALID: the remaining FIRST_* fields are unspecified
        self.lv_now = 0
        self.last_events = self.last_real = 0

    # ------------------------------------------------------------------ events of the current cycle
    def events(self, inp: Dict[str, int]):
        """Returns (events, set_vector, real) with ``real`` the subset of events that are genuine (not injected)."""
        sel_we = bool(inp["sel"] and inp["we"])
        sw_wr = sel_we and inp["addr"] == A["SW_REPORT"]
        inj_wr = sel_we and inp["addr"] == A["INJECT"]
        pulse = 0
        for bit, key in ((SRC["BUS_DECODE"], "ev_bus_decode"), (SRC["PERIPH_ERR"], "ev_periph_err"), (SRC["DMA_ERR"], "ev_dma_err"),
                         (SRC["HOST_VIOL"], "ev_host_viol"), (SRC["ISO_ACCESS"], "ev_iso_access"), (SRC["MEM_PARITY"], "ev_parity")):
            if inp[key]:
                pulse |= 1 << bit
        if sw_wr:
            pulse |= 1 << (SRC["SW_FATAL"] if (inp["wdata"] >> 31) & 1 else SRC["SW_WARN"])
        lv = (inp["lv_ext_warn"], inp["lv_ext_fatal"], inp["lv_tsu_halted"])
        level = 0
        rise = 0
        for i, bit in enumerate((SRC["EXT_WARN"], SRC["EXT_FATAL"], SRC["TSU_HALTED"])):
            if lv[i]:
                level |= 1 << bit
                if not (self.lv_prev >> i) & 1:
                    rise |= 1 << bit
        inj = (inp["wdata"] & INJ_MASK) if inj_wr else 0
        real = pulse | rise
        return real | inj, pulse | level | inj, real

    def addr_of(self, src: int, inp: Dict[str, int], real_mask: int) -> Optional[int]:
        if not (real_mask >> src) & 1:
            return None  # injection only: address unspecified
        if src == SRC["BUS_DECODE"]:
            return inp["ev_bus_decode_addr"]
        if src == SRC["PERIPH_ERR"]:
            return inp["ev_periph_err_addr"]
        if src == SRC["HOST_VIOL"]:
            return inp["ev_host_viol_addr"]
        if src == SRC["MEM_PARITY"]:
            return inp["ev_parity_addr"]
        if src in (SRC["SW_WARN"], SRC["SW_FATAL"]):
            return inp["wdata"] & 0x7FFF_FFFF
        return 0

    # ------------------------------------------------------------------ combinational
    def rdata_mask(self, addr: int) -> int:
        return MASK32

    def _read(self, addr: int) -> Optional[int]:
        n = NAME[addr]
        if n == "STATUS":
            return self.st
        if n == "WARN_EN":
            return self.wen
        if n == "FATAL_EN":
            return self.fen
        if n == "WARN_COUNT":
            return self.wcnt
        if n == "FATAL_COUNT":
            return self.fcnt
        if n == "FIRST_SRC":
            return (self.first_v << 31) | (0 if self.first_stale else self.first_src)
        if n == "FIRST_ADDR":
            return None if self.first_stale else self.first_addr
        if n == "LAST_SRC":
            return (self.last_v << 31) | self.last_src
        if n == "LAST_ADDR":
            return self.last_addr
        if n == "SW_CODE":
            return self.sw_code
        if n == "CTRL":
            return (self.ctl_iso << 1) | self.ctl_host
        if n == "PAR_INJECT":
            return self.pinj
        if n == "PAR_CHK_EN":
            return self.pchk
        if n == "RAW":
            return self.lv_now
        raise KeyError(n)

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:
        self.lv_now = inp["lv_ext_warn"] | (inp["lv_ext_fatal"] << 1) | (inp["lv_tsu_halted"] << 2)
        addr, we = inp["addr"], inp["we"]
        k = KIND.get(addr) if not addr & 3 else None
        if k is None:
            err, rdata = 1, 0
        elif we:
            err, rdata = (1 if k == "ro" else 0), None
        else:
            err = 1 if k == "wo" else 0
            rdata = 0 if err else self._read(addr)
        rmask = 0x8000_0000 if (not err and not we and addr == A["FIRST_SRC"] and self.first_stale) else None
        fatal_any = int((self.st >> 8) & 0xFF != 0)
        return {
            "rdata": rdata, "err": err,
            "irq_warn": int((self.st & 0xFF & self.wen) != 0), "irq_fatal": int(((self.st >> 8) & 0xFF & self.fen) != 0),
            "fatal_pin": self.ctl_host & fatal_any, "fatal_iso": self.ctl_iso & fatal_any,
            "par_inject": self.pinj, "par_chk_en": self.pchk, "rmask": rmask,
        }

    # ------------------------------------------------------------------ clock
    def clock(self, inp: Dict[str, int]) -> None:
        self.lv_now = inp["lv_ext_warn"] | (inp["lv_ext_fatal"] << 1) | (inp["lv_tsu_halted"] << 2)
        events, setv, real = self.events(inp)
        self.last_events, self.last_real = events, real  # for functional coverage
        sel_we = bool(inp["sel"] and inp["we"])
        a, d = inp["addr"], inp["wdata"] & MASK32
        w = sel_we and not a & 3
        w1c = (d & 0xFFFF) if (w and a == A["STATUS"]) else 0
        clr_first = w and a == A["CTRL"] and (d >> 2) & 1
        clr_counts = w and a == A["CTRL"] and (d >> 3) & 1
        lo = next((i for i in range(16) if (events >> i) & 1), None)
        hi = next((i for i in range(15, -1, -1) if (events >> i) & 1), None)
        wn = bin(events & 0xFF).count("1")
        fn = bin((events >> 8) & 0xFF).count("1")
        n_st = (self.st & ~w1c & 0xFFFF) | setv
        # counters
        if clr_counts:
            self.wcnt = self.fcnt = 0
        else:
            self.wcnt = min(self.wcnt + wn, MASK32)
            self.fcnt = min(self.fcnt + fn, MASK32)
        # first / last
        if clr_first:
            if self.first_v:
                self.first_stale = True
            self.first_v = 0
        if events:
            if not self.first_v or clr_first:
                self.first_v, self.first_src, self.first_addr = 1, lo, self.addr_of(lo, inp, real)
                self.first_stale = False
            self.last_v, self.last_src, self.last_addr = 1, hi, self.addr_of(hi, inp, real)
        # registers
        if w and a == A["WARN_EN"]:
            self.wen = d & 0xFF
        if w and a == A["FATAL_EN"]:
            self.fen = d & 0xFF
        if w and a == A["CTRL"]:
            self.ctl_host, self.ctl_iso = d & 1, (d >> 1) & 1
        if w and a == A["SW_REPORT"]:
            self.sw_code = d & 0x7FFF_FFFF
        if w and a == A["PAR_INJECT"]:
            self.pinj = d & 1
        elif inp["mem_write"]:
            self.pinj = 0
        if w and a == A["PAR_CHK_EN"]:
            self.pchk = d & 1
        self.st = n_st
        self.lv_prev = self.lv_now
