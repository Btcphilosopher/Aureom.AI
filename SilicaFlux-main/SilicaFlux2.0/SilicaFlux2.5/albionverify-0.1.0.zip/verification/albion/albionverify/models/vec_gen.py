"""Corner-biased FP32 / integer operand generators for the vector benches and the model tests.

Pure Python, deterministic given a ``random.Random``.  Classes are named so functional coverage can sample
the class of every operand actually applied (see vec_fp32.value_class).
"""
from __future__ import annotations

import random
import struct
from typing import List, Sequence, Tuple

from . import vec_fp32 as F

M32 = 0xFFFFFFFF


def f2b(x: float) -> int:
    """Python float -> nearest binary32 bit pattern (test convenience only)."""
    return struct.unpack("<I", struct.pack("<f", x))[0]


def b2f(b: int) -> float:
    return struct.unpack("<f", struct.pack("<I", b & M32))[0]


# a fixed set of interesting encodings (positive; the sign is randomised by callers)
SPECIALS = [
    0x00000000,  # +0
    0x00000001,  # smallest subnormal
    0x00000002,
    0x007FFFFF,  # largest subnormal
    0x00400000,  # 2^-127
    0x00800000,  # smallest normal
    0x00800001,
    0x3F800000,  # 1.0
    0x3F800001,  # 1 + ulp
    0x3F7FFFFF,  # 1 - ulp/2
    0x3F000000,  # 0.5
    0x40000000,  # 2.0
    0x40490FDB,  # pi
    0x4B000000,  # 2^23
    0x4B800000,  # 2^24
    0x4B7FFFFF,
    0x7F7FFFFF,  # max normal
    0x7F7FFFFE,
    0x7F000000,  # 2^127
    0x7F800000,  # +inf
    0x7FC00000,  # canonical qNaN
    0x7FA00000,  # sNaN
    0x7F800001,  # sNaN (smallest payload)
    0x7FFFFFFF,  # qNaN with full payload
    0x7FC12345,  # qNaN, payload
]

CLASSES = ("zero", "subnormal", "tiny_normal", "normal", "huge", "inf", "qnan", "snan")


def rand_class(rng: random.Random, cls: str) -> int:
    """A random encoding of value class ``cls`` (random sign)."""
    s = rng.getrandbits(1) << 31
    if cls == "zero":
        return s
    if cls == "subnormal":
        return s | rng.randint(1, 0x7FFFFF)
    if cls == "tiny_normal":
        return s | (rng.randint(1, 3) << 23) | rng.getrandbits(23)
    if cls == "normal":
        return s | (rng.randint(1, 254) << 23) | rng.getrandbits(23)
    if cls == "huge":
        return s | (rng.randint(252, 254) << 23) | rng.getrandbits(23)
    if cls == "inf":
        return s | 0x7F800000
    if cls == "qnan":
        return s | 0x7FC00000 | rng.getrandbits(22)
    if cls == "snan":
        return s | 0x7F800000 | rng.randint(1, 0x3FFFFF)
    raise ValueError(cls)


def rand_fp32(rng: random.Random, mode: str = "mixed") -> int:
    """Random binary32 encoding.

    mode 'uniform'  : any 32-bit pattern
    mode 'moderate' : normals with exponent in [100, 150] (sums rarely over/underflow)
    mode 'mixed'    : biased mix of specials, classes, near-ties and moderate values
    mode 'finite'   : mixed without inf/NaN
    """
    if mode == "uniform":
        return rng.getrandbits(32)
    if mode == "moderate":
        return (rng.getrandbits(1) << 31) | (rng.randint(100, 150) << 23) | rng.getrandbits(23)
    r = rng.random()
    if r < 0.18:
        x = rng.choice(SPECIALS) | (rng.getrandbits(1) << 31)
    elif r < 0.45:
        x = rand_fp32(rng, "moderate")
    elif r < 0.60:
        # exponent biased to extremes, mantissa biased to all-0 / all-1 / single bit
        e = rng.choice([0, 0, 1, 2, 126, 127, 128, 253, 254, 254, 24, 25, 22, 23])
        mk = rng.choice([0, 0x7FFFFF, 1, 0x400000, 0x7FFFFE, 0x3FFFFF, rng.getrandbits(23), rng.getrandbits(23)])
        x = (rng.getrandbits(1) << 31) | (e << 23) | mk
    elif r < 0.70:
        x = rand_class(rng, rng.choice(CLASSES))
    elif r < 0.82:
        x = (rng.getrandbits(1) << 31) | (rng.randint(1, 254) << 23) | rng.getrandbits(23)
    else:
        x = rng.getrandbits(32)
    if mode == "finite" and (x & 0x7F800000) == 0x7F800000:
        x = (x & 0x807FFFFF) | (rng.randint(0, 254) << 23)  # force a finite exponent
    return x & M32


def operand_pair_for(rng: random.Random, op: int) -> Tuple[int, int, int]:
    """Operands (a, b, c) with deliberately correlated structure for the interesting arithmetic cases:
    cancellation (a ~ -b for FADD, a*b ~ -c for FMA), tie patterns, huge/tiny products."""
    a, b, c = rand_fp32(rng), rand_fp32(rng), rand_fp32(rng)
    k = rng.random()
    if op in (F.OP_FADD, F.OP_FSUB) and k < 0.25:
        # catastrophic cancellation: b = +-a with a few low mantissa bits changed
        b = (a ^ (1 << 31)) if op == F.OP_FADD else a
        b ^= rng.choice([0, 0, 1, 2, 3, 0x7F, rng.getrandbits(8)])
    elif op in (F.OP_FADD, F.OP_FSUB) and k < 0.40:
        # large exponent gap (sticky-only addend) / gap of exactly 24, 25, 26, 27 (tie / sticky boundary)
        gap = rng.choice([22, 23, 24, 25, 26, 27, 28, 30, 60])
        ea = rng.randint(max(1, gap + 1), 254)
        a = (rng.getrandbits(1) << 31) | (ea << 23) | rng.getrandbits(23)
        b = (rng.getrandbits(1) << 31) | ((ea - gap) << 23) | rng.getrandbits(23)
    elif op == F.OP_FMUL and k < 0.30:
        # product near the overflow / underflow / subnormal boundaries
        ea = rng.randint(1, 254)
        eb = rng.choice([254 - ea + 127 - 1, 254 - ea + 127, 254 - ea + 127 + 1, 127 - ea + 1, 127 - ea, 127 - ea - 1, 127 - ea - 22, 127 - ea - 23, 127 - ea - 24])
        eb = max(1, min(254, eb))
        a = (rng.getrandbits(1) << 31) | (ea << 23) | rng.getrandbits(23)
        b = (rng.getrandbits(1) << 31) | (eb << 23) | rng.getrandbits(23)
    elif op in F.FMA_OPS and k < 0.45:
        # addend close to -(a*b): exact cancellation or near cancellation
        pb, _ = F.fmul(a, b, F.RNE)
        if not (F.is_nan(pb) or F.is_inf(pb)):
            c = pb ^ (1 << 31) if op in (F.OP_FMADD, F.OP_FNMSUB) else pb
            c ^= rng.choice([0, 0, 0, 1, 2, 0xFF, rng.getrandbits(10)])
            c &= M32
    elif op in F.FMA_OPS and k < 0.60:
        # product much smaller / larger than the addend, to exercise the alignment extremes
        ea = rng.randint(1, 254)
        eb = rng.randint(1, 254)
        a = (rng.getrandbits(1) << 31) | (ea << 23) | rng.getrandbits(23)
        b = (rng.getrandbits(1) << 31) | (eb << 23) | rng.getrandbits(23)
        ec = max(1, min(254, ea + eb - 127 + rng.choice([-60, -50, -30, -26, -25, -24, -23, -22, 0, 22, 23, 24, 25, 26, 30, 50])))
        c = (rng.getrandbits(1) << 31) | (ec << 23) | rng.getrandbits(23)
    elif op in (F.OP_FMIN, F.OP_FMAX, F.OP_FEQ, F.OP_FLT, F.OP_FLE) and k < 0.35:
        b = a if rng.random() < 0.5 else (a ^ (1 << 31))  # equal / sign-flipped (zeros!)
    return a, b, c


def rm_for(rng: random.Random) -> int:
    return rng.choices([0, 1, 2, 3, 4], weights=[4, 2, 2, 2, 2])[0]
