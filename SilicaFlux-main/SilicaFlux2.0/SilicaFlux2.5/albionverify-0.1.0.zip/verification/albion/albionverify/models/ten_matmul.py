"""Independent reference model of the TENSORCORE 02 systolic array (``tensor_systolic_array``).

Written from rtl/tensorcore02/README.md and docs/ARCHITECTURE.md, CONFIGURATION.md, PERFORMANCE.md.

NOTE on the dataflow: the verification brief called the array "weight-stationary"; the DOCUMENTATION says the
opposite ("This is not a weight-stationary design ... output-stationary: PE(i,j) computes C[i][j]").  The model
follows the documentation.  Nothing observable at the ports differs between the two descriptions except timing,
which is specified exactly below.

Function
    C[M,N] = A[M,K] x B[K,N], signed DATA_WIDTH operands, signed ACC_WIDTH accumulation that WRAPS modulo
    2**ACC_WIDTH (no saturation, no overflow flag).  One tile per launch; K is streamed as k-slices
    (s_a = A[:,k] lane i = row i, s_b = B[k,:] lane j = column j), lanes beyond M / N are ignored.

Timing (ARCHITECTURE.md 7, no stalls; h = cycle of the launch handshake)
    h+1  CLEAR (1 cycle) | h+2 .. RUN: one slice accepted per cycle in which s_valid & ~stall_i
    then DRAIN: free running, enabled (stall_i = 0) steps until the last active PE has committed its last
    product; the cycle after the last needed step still belongs to DRAIN (all_done visible) and moves to READOUT
    unconditionally.  Needed enabled DRAIN steps = M + N - 1 + MUL_PIPE (last fire step K+M+N-2 vs the last slice
    accepted at step K-1), i.e. DRAIN lasts M + N + MUL_PIPE cycles without stalls and
        busy = 1 + K + M + N + MUL_PIPE + stall_up + stall_ext.
    READOUT: tile_done = m_valid = 1, M beats (m_row = 0..M-1, m_last on the final row), paced by m_ready, then IDLE.

TileModel is a lock-step, cycle-accurate model of everything observable at the ports.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

IDLE, CLEAR, RUN, DRAIN, READOUT = "IDLE", "CLEAR", "RUN", "DRAIN", "READOUT"


@dataclass(frozen=True)
class TenParams:
    rows: int = 4
    cols: int = 4
    dw: int = 8
    acc: int = 32
    k_w: int = 17
    mul_pipe: int = 0

    @property
    def k_max(self) -> int:
        return (1 << self.k_w) - 1

    @property
    def m_w(self) -> int:
        return max(1, (self.rows).bit_length())  # clog2(rows + 1)

    @property
    def n_w(self) -> int:
        return max(1, (self.cols).bit_length())


def to_signed(v: int, bits: int) -> int:
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


def wrap_signed(v: int, bits: int) -> int:
    return to_signed(v, bits)


def to_unsigned(v: int, bits: int) -> int:
    return v & ((1 << bits) - 1)


def matmul(A: Sequence[Sequence[int]], B: Sequence[Sequence[int]], acc_bits: int) -> List[List[int]]:
    """Exact integer GEMM with the documented signed wrap-around of the accumulator (pure Python)."""
    M, K = len(A), len(A[0]) if A else 0
    N = len(B[0]) if B else 0
    C = [[0] * N for _ in range(M)]
    for i in range(M):
        for j in range(N):
            s = 0
            for k in range(K):
                s += A[i][k] * B[k][j]
            C[i][j] = wrap_signed(s, acc_bits)
    return C


def cfg_legal(m: int, n: int, k: int, p: TenParams) -> bool:
    """CONFIGURATION.md 3: 1 <= M <= ROWS, 1 <= N <= COLS, 1 <= K <= 2**K_WIDTH - 1 (K = 0 is rejected)."""
    return 1 <= m <= p.rows and 1 <= n <= p.cols and 1 <= k <= p.k_max


def drain_steps_needed(m: int, n: int, p: TenParams) -> int:
    return m + n - 1 + p.mul_pipe


def commits_at_step(step: int, m: int, n: int, k: int, mul_pipe: int) -> int:
    """Number of PEs committing a product in enabled step ``step`` (0 = the step in which slice 0 is accepted):
    PE(i,j) commits index kk in step kk + 1 + i + j + MUL_PIPE (ARCHITECTURE.md 5, 6)."""
    t = step - 1 - mul_pipe
    if t < 0:
        return 0
    cnt = 0
    for i in range(m):
        for j in range(n):
            if 0 <= t - i - j < k:
                cnt += 1
    return cnt


@dataclass
class TenOutputs:
    cfg_ready: int
    cfg_reject: int
    s_ready: int
    s_k: int
    m_valid: int
    m_row: int
    m_data: List[int]  # per column, UNSIGNED ACC_WIDTH patterns
    m_col_mask: int
    m_last: int
    busy: int
    tile_done: int
    perf: Dict[str, int]


class TileModel:
    def __init__(self, p: TenParams):
        self.p = p
        self.reset()

    # ------------------------------------------------------------------ state
    def reset(self) -> None:
        self.state = IDLE
        self.m = self.n = self.k = 0
        self.k_cnt = 0
        self.rd_row = 0
        self.reject_q = 0
        self.ens = 0  # enabled steps completed in the current tile
        self.drain_done = 0
        self.C: List[List[int]] = []
        self.perf = dict(busy=0, issue=0, stall_up=0, stall_ext=0, mac=0, pad=0)
        self.cum_commits_cache: Dict[int, int] = {}
        self.n_tiles = 0
        self.slices_accepted = 0

    def _all_done(self) -> bool:
        return self.state == DRAIN and self.drain_done >= drain_steps_needed(self.m, self.n, self.p)

    # ------------------------------------------------------------------ outputs for the current cycle
    def outputs(self, stall_i: int) -> TenOutputs:
        p = self.p
        # result-stream payload (m_row / m_data / m_col_mask / m_last) is only specified while m_valid = 1
        row_data = [0] * p.cols
        mask = 0
        if self.state == READOUT:
            for j in range(self.n):
                row_data[j] = to_unsigned(self.C[self.rd_row][j], p.acc)
            mask = (1 << self.n) - 1
        return TenOutputs(
            cfg_ready=int(self.state == IDLE),
            cfg_reject=self.reject_q,
            s_ready=int(self.state == RUN and not stall_i),
            s_k=self.k_cnt,
            m_valid=int(self.state == READOUT),
            m_row=self.rd_row,
            m_data=row_data,
            m_col_mask=mask,
            m_last=int(self.state == READOUT and self.rd_row == self.m - 1),
            busy=int(self.state != IDLE),
            tile_done=int(self.state == READOUT),
            perf=dict(self.perf),
        )

    # ------------------------------------------------------------------ rising edge
    def edge(self, *, cfg_valid: int, cfg_m: int, cfg_n: int, cfg_k: int, s_valid: int, s_a: Optional[Sequence[int]],
             s_b: Optional[Sequence[int]], stall_i: int, m_ready: int) -> dict:
        """Advance one clock.  ``s_a`` / ``s_b`` are the lane values (signed ints, one per row / column) presented
        with s_valid.  Returns events {'launched', 'accepted', 'tile_end'} for the scoreboard."""
        p = self.p
        ev = dict(launched=False, accepted=False, tile_end=False, rejected=False)
        st = self.state
        all_done = self._all_done()
        s_ready = (st == RUN) and not stall_i
        s_go = bool(s_valid and s_ready)
        cfg_go = bool(cfg_valid and st == IDLE and cfg_legal(cfg_m, cfg_n, cfg_k, p))
        new_reject = int(bool(cfg_valid and st == IDLE and not cfg_legal(cfg_m, cfg_n, cfg_k, p)))
        ev["rejected"] = bool(new_reject)
        perf = self.perf
        nstate = st
        # ---- performance counters (registered: updated at this edge from this cycle's state)
        if cfg_go:
            for key in perf:
                perf[key] = 0
        else:
            if st in (CLEAR, RUN, DRAIN):
                perf["busy"] += 1
            if s_go:
                perf["issue"] += 1
                perf["pad"] += p.rows * p.cols - self.m * self.n
            if st == RUN and not stall_i and not s_valid:
                perf["stall_up"] += 1
            if (st == RUN or (st == DRAIN and not all_done)) and stall_i:
                perf["stall_ext"] += 1
            # commits happen only in enabled steps
            enabled = (st == RUN and s_go) or (st == DRAIN and not stall_i)
            if enabled:
                perf["mac"] += commits_at_step(self.ens, self.m, self.n, self.k, p.mul_pipe)
        # ---- tile state machine
        if st == IDLE:
            if cfg_go:
                self.m, self.n, self.k = cfg_m, cfg_n, cfg_k
                self.k_cnt = 0
                self.rd_row = 0
                self.C = [[0] * self.n for _ in range(self.m)]
                self.ens = 0
                self.drain_done = 0
                nstate = CLEAR
                ev["launched"] = True
                self.n_tiles += 1
        elif st == CLEAR:
            nstate = RUN
        elif st == RUN:
            if s_go:
                assert s_a is not None and s_b is not None
                for i in range(self.m):
                    for j in range(self.n):
                        self.C[i][j] = wrap_signed(self.C[i][j] + s_a[i] * s_b[j], p.acc)
                ev["accepted"] = True
                self.slices_accepted += 1
                self.ens += 1
                if self.k_cnt == self.k - 1:
                    nstate = DRAIN
                self.k_cnt += 1
        elif st == DRAIN:
            if all_done:
                nstate = READOUT
            elif not stall_i:
                self.ens += 1
                self.drain_done += 1
        elif st == READOUT:
            if m_ready:
                if self.rd_row == self.m - 1:
                    nstate = IDLE
                    ev["tile_end"] = True
                else:
                    self.rd_row += 1
        self.state = nstate
        self.reject_q = new_reject
        return ev
