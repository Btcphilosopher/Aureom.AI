"""Independent reference model of the SilicaFlux SRAM-core handshake port.

Written from the specification only: ``rtl/sramlib/docs/mem/01_interface_spec.md`` sec. 1, 2, 4, 9, 10
(and sec. 3 of ``03_banking.md`` for the per-master response rules).  Nothing here is copied from the RTL.

What the specification says (the rules this model encodes, with the interpretation used where the text
leaves room):

  addressing   word addresses; lane ``l`` of wdata/rdata/wmask is bits ``[l*LW +: LW]`` (little endian,
               ``LW = DATA_WIDTH / MASK_WIDTH``).  An address ``>= DEPTH`` is *invalid*: accepted, never
               touches the array, answered with ``rsp_err = 1`` and zero data -- also for a write when
               ``WRITE_ACK = 0`` ("errors are never silent").
  write        the write is architecturally complete at the acceptance edge: a read accepted in a later cycle
               returns it.  ``WRITE_ACK = 1``: an acknowledgement (``rsp_we = 1``, data 0) in order;
               ``WRITE_ACK = 0``: posted -- no response (unless the address is invalid).
  read         response ``READ_LATENCY`` cycles after acceptance when not back-pressured; ``rsp_we = 0``.
  ordering     exactly one response per response-producing request, strictly in acceptance order, carrying
               the request's ``req_id``; never dropped, duplicated or unsolicited.  An error response to a
               write carries ``rsp_we = 1`` (interpretation: ``rsp_we`` says which kind of request the
               response belongs to).
  req_ready    0 in reset and in the cycle after reset release; 0 in test mode; otherwise 1 when a response
               credit is free (posted writes need none).  Credits bound the number of outstanding responses
               (accepted, response not yet handed over) to ``RSP_FIFO_DEPTH``; a credit freed by a response
               hand-over at edge h can be used by a request accepted at edge h+1 or later ("sustains one
               access per cycle at RSP_FIFO_DEPTH = READ_LATENCY + 1").  ``RSP_FIFO_DEPTH = 0`` means no
               back-pressure: no credit limit, the master must keep ``rsp_ready = 1``.
  backpressure rsp_* hold stable while ``rsp_valid && !rsp_ready``; responses leave in order, the head of the
               queue is valid from ``accept + READ_LATENCY`` on and stays valid until handed over.
  reset        control/status/output-valid state resets (asynchronously); the array is never reset and has no
               defined power-up content (sec. 9): lanes never written read back as *any* value, but a value
               once observed must stay stable until the lane is written.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, FrozenSet, List, Optional, Tuple

ANY = None  # constraint "any value legal"


def clog2(n: int) -> int:
    return max(1, (n - 1).bit_length()) if n > 1 else 1


# --------------------------------------------------------------------------- lane memory


@dataclass
class Snap:
    """What a read accepted at some edge is allowed to return, per lane (frozenset of values, or None = any)."""

    seq: int
    addr: int
    cons: Tuple[Optional[FrozenSet[int]], ...]


class LaneMemory:
    """Word memory with ``lanes`` lanes of ``lane_bits`` bits.

    Each lane is in one of three states (the same vocabulary as ``albionverify.memory.BackingStore`` but at
    lane granularity, because the spec allows 9-bit or 1-bit lanes and because a read's legal data must be
    frozen at its *acceptance* edge while its response may be delivered much later):

      exact      one legal value (written, or pinned by an earlier observation)
      uncertain  a small set of legal values (a write whose completion is unknown: cancelled by reset)
      unknown    never written, power-up content unspecified (``init='unknown'``): any value is legal on
                 the first read; the value observed is then pinned (a later read must return the same)
    """

    def __init__(self, lanes: int, lane_bits: int, init: str = "unknown"):
        if init not in ("unknown", "zero"):
            raise ValueError(init)
        self.lanes, self.lane_bits, self.init = lanes, lane_bits, init
        self._lmask = (1 << lane_bits) - 1
        self._st: Dict[Tuple[int, int], object] = {}  # (addr, lane) -> int | frozenset | None(explicit any)
        self._wseq: Dict[Tuple[int, int], int] = {}  # sequence number of the last write to the lane
        self.seq = 0
        self.n_writes = 0
        self.n_pins = 0

    # ---- helpers
    def lane_of(self, data: int, l: int) -> int:
        return (data >> (l * self.lane_bits)) & self._lmask

    def constraint(self, addr: int, l: int) -> Optional[FrozenSet[int]]:
        k = (addr, l)
        if k in self._st:
            s = self._st[k]
            if s is None:
                return ANY
            return frozenset((s,)) if isinstance(s, int) else s  # type: ignore[return-value]
        return frozenset((0,)) if self.init == "zero" else ANY

    # ---- writes
    def write(self, addr: int, data: int, mask: int) -> None:
        """Write the lanes enabled in ``mask`` (bit l <-> lane l); other lanes keep their value."""
        self.seq += 1
        self.n_writes += 1
        for l in range(self.lanes):
            if (mask >> l) & 1:
                self._st[(addr, l)] = self.lane_of(data, l)
                self._wseq[(addr, l)] = self.seq

    def write_uncertain(self, addr: int, data: int, mask: int) -> None:
        """A write that may or may not have happened: every enabled lane is old OR new."""
        self.seq += 1
        for l in range(self.lanes):
            if (mask >> l) & 1:
                new = self.lane_of(data, l)
                cur = self.constraint(addr, l)
                self._st[(addr, l)] = ANY if cur is ANY else frozenset(cur | {new})
                self._wseq[(addr, l)] = self.seq

    # ---- reads
    def snapshot(self, addr: int) -> Snap:
        return Snap(self.seq, addr, tuple(self.constraint(addr, l) for l in range(self.lanes)))

    def check(self, snap: Snap, observed: int, pin: bool = True) -> Optional[str]:
        """Compare a read response with the snapshot taken at the acceptance edge.  Returns None if legal,
        otherwise a message.  Lanes that were not written since the snapshot are pinned to the observation
        (a read delivered later must agree), also across the delivery of an earlier read of the same lane."""
        bad: List[str] = []
        for l in range(self.lanes):
            got = self.lane_of(observed, l)
            allowed = snap.cons[l]
            wrote_since = self._wseq.get((snap.addr, l), 0) > snap.seq
            if not wrote_since:
                cur = self.constraint(snap.addr, l)
                if allowed is ANY:
                    allowed = cur
                elif cur is not ANY:
                    allowed = allowed & cur
            if allowed is not ANY and got not in allowed:
                bad.append("lane%d exp=%s got=0x%x" % (l, "|".join("0x%x" % x for x in sorted(allowed)) or "{}", got))
            elif pin and not wrote_since:
                if self._st.get((snap.addr, l), "absent") != got:
                    self.n_pins += 1
                self._st[(snap.addr, l)] = got
        if bad:
            return "word 0x%x mismatch: %s" % (snap.addr, "; ".join(bad[:4]) + (" ..." if len(bad) > 4 else ""))
        return None

    def exact_word(self, addr: int) -> Optional[int]:
        """The word value if every lane is exact, else None (for tests/docs)."""
        v = 0
        for l in range(self.lanes):
            c = self.constraint(addr, l)
            if c is ANY or len(c) != 1:
                return None
            v |= next(iter(c)) << (l * self.lane_bits)
        return v


# --------------------------------------------------------------------------- response path


@dataclass
class ExpRsp:
    """The predicted response of one accepted request."""

    key: int  # acceptance sequence number (unique per port)
    kind: str  # read | write_ack | err_read | err_write
    we: bool
    err: bool
    id: int
    addr: int
    due: int  # first cycle in which the response may be valid (accept edge + READ_LATENCY)
    snap: Optional[Snap] = None  # reads only


class RspPathModel:
    """Credits + in-order response queue of one port (spec sec. 4)."""

    def __init__(self, read_latency: int, fifo_depth: int):
        if read_latency < 1:
            raise ValueError("READ_LATENCY must be >= 1")
        self.rl = read_latency
        self.fd = fifo_depth
        self.pending: Deque[ExpRsp] = deque()
        self._live = False
        self.max_outstanding = 0

    # ---- reset
    def reset(self) -> List[ExpRsp]:
        """Asynchronous reset: everything outstanding is cancelled.  Returns the cancelled responses."""
        gone = list(self.pending)
        self.pending.clear()
        self._live = False
        return gone

    def begin_edge(self) -> bool:
        """Call once per rising edge outside reset.  True if the port is 'live' at this edge: it is not in the
        reset cycle nor in the first cycle after reset release (req_ready = 0 there)."""
        live = self._live
        self._live = True
        return live

    # ---- credits
    @property
    def outstanding(self) -> int:
        return len(self.pending)

    def credit_free(self) -> bool:
        return self.fd == 0 or len(self.pending) < self.fd

    def ready(self, live: bool, needs_rsp: bool, test_mode: bool = False) -> bool:
        if test_mode or not live:
            return False
        return (not needs_rsp) or self.credit_free()

    # ---- responses
    def head_valid(self, cycle: int) -> Optional[ExpRsp]:
        """The response that must be presented (rsp_valid = 1) in the cycle ending at edge ``cycle``."""
        if self.pending and self.pending[0].due <= cycle:
            return self.pending[0]
        return None

    def push(self, rsp: ExpRsp) -> None:
        self.pending.append(rsp)
        self.max_outstanding = max(self.max_outstanding, len(self.pending))

    def pop(self) -> ExpRsp:
        return self.pending.popleft()


# --------------------------------------------------------------------------- single-port wrapper


class SramSpModel:
    """Transaction/cycle model of ``sram_sp`` (and of one master port of ``sram_bank_controller``).

    Usage per rising edge outside reset (the checker passes what it observed at the edge):

        live  = m.begin_edge()
        exp   = m.head_valid(cycle)                    # response that must be valid now (or None)
        rdy   = m.expected_ready(live, we, addr)       # exact req_ready for the presented payload
        ...compare with the DUT...
        if hand-over:  m.pop()
        if accepted:   m.accept(cycle, we, addr, wdata, wmask, id)
    """

    def __init__(self, data_width: int, depth: int, mask_width: int, read_latency: int,
                 write_ack: int = 1, rsp_fifo_depth: Optional[int] = None, id_width: int = 1,
                 init: str = "unknown"):
        if data_width % mask_width:
            raise ValueError("MASK_WIDTH must divide DATA_WIDTH")
        self.dw, self.depth, self.mw = data_width, depth, mask_width
        self.lw = data_width // mask_width
        self.aw = clog2(depth)
        self.rl = read_latency
        self.write_ack = int(write_ack)
        self.fd = read_latency + 1 if rsp_fifo_depth is None else rsp_fifo_depth
        self.idw = id_width
        self.mem = LaneMemory(mask_width, self.lw, init)
        self.rsp = RspPathModel(read_latency, self.fd)
        self._seq = 0
        self.stats = {"read": 0, "write": 0, "err_read": 0, "err_write": 0, "posted": 0}

    # ---- decode
    def addr_ok(self, addr: int) -> bool:
        return 0 <= addr < self.depth

    def needs_rsp(self, we: bool, addr: int) -> bool:
        return (not we) or self.write_ack != 0 or not self.addr_ok(addr)

    # ---- per-edge API
    def begin_edge(self) -> bool:
        return self.rsp.begin_edge()

    def head_valid(self, cycle: int) -> Optional[ExpRsp]:
        return self.rsp.head_valid(cycle)

    def expected_ready(self, live: bool, we: bool, addr: int, test_mode: bool = False) -> bool:
        return self.rsp.ready(live, self.needs_rsp(we, addr), test_mode)

    def pop(self) -> ExpRsp:
        return self.rsp.pop()

    def accept(self, cycle: int, we: bool, addr: int, wdata: int, wmask: int, rid: int) -> Optional[ExpRsp]:
        """Apply an accepted request.  Writes take effect now (commit at the acceptance edge)."""
        self._seq += 1
        ok = self.addr_ok(addr)
        rid &= (1 << self.idw) - 1
        if not ok:
            kind = "err_write" if we else "err_read"
            self.stats[kind] += 1
            e = ExpRsp(self._seq, kind, bool(we), True, rid, addr, cycle + self.rl)
        elif we:
            self.mem.write(addr, wdata, wmask)
            self.stats["write"] += 1
            if not self.write_ack:
                self.stats["posted"] += 1
                return None
            e = ExpRsp(self._seq, "write_ack", True, False, rid, addr, cycle + self.rl)
        else:
            self.stats["read"] += 1
            e = ExpRsp(self._seq, "read", False, False, rid, addr, cycle + self.rl, snap=self.mem.snapshot(addr))
        self.rsp.push(e)
        return e

    def check_rsp_data(self, exp: ExpRsp, rdata: int) -> Optional[str]:
        """Data check of a delivered response (zero for acknowledgements and errors, snapshot for reads)."""
        if exp.kind == "read":
            return self.mem.check(exp.snap, rdata)  # type: ignore[arg-type]
        if rdata != 0:
            return "%s response must carry all-zero rdata, got 0x%x" % (exp.kind, rdata)
        return None

    def reset(self) -> List[ExpRsp]:
        """Asynchronous reset: responses cancelled; the array keeps its content (spec sec. 1, 9)."""
        return self.rsp.reset()
