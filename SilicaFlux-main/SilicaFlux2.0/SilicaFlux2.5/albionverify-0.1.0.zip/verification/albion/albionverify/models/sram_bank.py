"""Independent reference model of ``sram_bank_controller`` (NUM_MASTERS x NUM_BANKS single-port banks).

Written from the specification only: ``rtl/sramlib/docs/mem/03_banking.md``, ``01_interface_spec.md`` sec. 2, 4, 7
(and the header comment of the module, which restates the same contract).  Rules encoded:

  addressing   ``ADDR_MODE = WORD``: the address is a word address.  ``BYTE``: a byte address; the low
               ``log2(DATA_WIDTH/8)`` bits must be zero, else the request completes with ``rsp_err = 1``
               (misaligned); word = addr >> log2(DATA_WIDTH/8).  word >= NUM_BANKS * BANK_DEPTH is out of range
               (error response, zero data, no side effect).  (For ``DATA_WIDTH < 16`` there is no sub-word offset.)
  interleave   LOW : bank = word mod NUM_BANKS, row = word div NUM_BANKS
               HIGH: bank = word div BANK_DEPTH, row = word mod BANK_DEPTH
  arbitration  a bank grants at most one master per cycle.  RR: rotating priority per bank -- the master that was
               granted last gets the lowest priority afterwards (pointer <- winner + 1, pointer starts at 0), so a
               master holding a request is granted within NUM_MASTERS grants.  FIXED: master 0 highest, strict
               priority by index (lower masters can starve).
  acceptance   ``m_req_ready`` = granted this cycle, or (error request with a free response credit); acceptance
               equals issue.  A master is only *eligible* for its bank when it holds a response credit (posted
               writes need none).  Masters addressing different banks proceed in parallel.
  perf hook    ``m_stall_conflict[m]``: master was ready to issue (valid, decoded OK, credit available) but lost
               bank arbitration.
  responses    per master exactly as for the single-port wrapper (``sram_core``): in acceptance order, carrying the
               request id, READ_LATENCY cycles after acceptance, credits RSP_FIFO_DEPTH per master, a stalled master
               never blocks another master's banks.
  reset        control state (pointers, response paths) is reset; the arrays keep their content.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from .sram_core import ExpRsp, LaneMemory, RspPathModel, clog2

RR = 0
FIXED = 1
ILV_LOW = 0
ILV_HIGH = 1
ADDR_WORD = 0
ADDR_BYTE = 1


@dataclass(frozen=True)
class BReq:
    """One master's presented request (payload as seen on the port)."""

    valid: bool
    we: bool = False
    addr: int = 0
    wdata: int = 0
    wmask: int = 0
    id: int = 0


@dataclass
class Dec:
    ok: bool
    kind: str  # "" | "range" | "align"
    word: int = 0
    bank: int = 0
    row: int = 0


@dataclass
class Pred:
    """The model's prediction for one edge."""

    ready: List[bool]  # per master (meaningful where valid)
    stall: List[bool]  # m_stall_conflict
    grant: Dict[int, int]  # bank -> granted master
    eligible: Dict[int, List[int]]  # bank -> eligible masters (in index order)


class BankModel:
    def __init__(self, num_masters: int, num_banks: int, data_width: int, mask_width: int, bank_depth: int,
                 read_latency: int = 1, arb: int = RR, interleave: int = ILV_LOW, addr_mode: int = ADDR_WORD,
                 id_width: int = 4, rsp_fifo_depth: Optional[int] = None, write_ack: int = 1):
        self.nm, self.nb = num_masters, num_banks
        self.dw, self.mw, self.bd = data_width, mask_width, bank_depth
        self.lw = data_width // mask_width
        self.rl, self.arb, self.ilv, self.amode = read_latency, arb, interleave, addr_mode
        self.idw, self.wa = id_width, int(write_ack)
        self.fd = read_latency + 1 if rsp_fifo_depth is None else rsp_fifo_depth
        self.total = num_banks * bank_depth
        self.boff = clog2(data_width // 8) if (addr_mode == ADDR_BYTE and data_width >= 16) else 0
        self.mem = LaneMemory(mask_width, self.lw, "unknown")
        self.ports = [RspPathModel(read_latency, self.fd) for _ in range(num_masters)]
        self.ptr = [0] * num_banks
        self._seq = [0] * num_masters
        self._live = False
        self.stats = {"read": 0, "write": 0, "posted": 0, "err_read": 0, "err_write": 0, "grants": 0, "conflicts": 0}

    # ------------------------------------------------------------------ decode
    def decode(self, addr: int) -> Dec:
        if self.boff and (addr & ((1 << self.boff) - 1)):
            return Dec(False, "align")
        w = addr >> self.boff
        if w >= self.total:
            return Dec(False, "range")
        if self.nb == 1:
            return Dec(True, "", w, 0, w)
        if self.ilv == ILV_LOW:
            return Dec(True, "", w, w % self.nb, w // self.nb)
        return Dec(True, "", w, w // self.bd, w % self.bd)

    def needs_rsp(self, we: bool, ok: bool) -> bool:
        return (not we) or self.wa != 0 or not ok

    # ------------------------------------------------------------------ reset
    def reset(self) -> List[ExpRsp]:
        gone: List[ExpRsp] = []
        for p in self.ports:
            gone += p.reset()
        self.ptr = [0] * self.nb
        self._live = False
        return gone

    def begin_edge(self) -> bool:
        live = self._live
        self._live = True
        for p in self.ports:
            p.begin_edge()
        return live

    # ------------------------------------------------------------------ one edge
    def predict(self, live: bool, reqs: Sequence[BReq], test_mode: bool = False) -> Pred:
        """Arbitration + ready + stall flags for the requests presented at this edge (pre-edge state)."""
        nm = self.nm
        dec = [self.decode(r.addr) for r in reqs]
        elig: Dict[int, List[int]] = {b: [] for b in range(self.nb)}
        credit = [False] * nm
        for m, r in enumerate(reqs):
            need = self.needs_rsp(r.we, dec[m].ok)
            credit[m] = self.ports[m].ready(live, need, test_mode)
            if r.valid and dec[m].ok and credit[m] and not test_mode:
                elig[dec[m].bank].append(m)
        grant: Dict[int, int] = {}
        for b in range(self.nb):
            cands = elig[b]
            if not cands:
                continue
            if self.arb == FIXED:
                grant[b] = min(cands)
            else:
                p = self.ptr[b]
                grant[b] = min(cands, key=lambda m: (m - p) % nm)  # first eligible in order p, p+1, ... (mod NM)
        granted = set(grant.values())
        ready = [False] * nm
        stall = [False] * nm
        for m, r in enumerate(reqs):
            err_ready = (not dec[m].ok) and credit[m] and not test_mode  # error request: needs a free credit only
            ready[m] = (m in granted) or err_ready
            stall[m] = bool(r.valid and dec[m].ok and credit[m] and not test_mode and m not in granted)
        return Pred(ready, stall, grant, elig)

    def accept(self, c: int, m: int, r: BReq, pred: Pred) -> Optional[ExpRsp]:
        """Apply request ``r`` of master ``m`` accepted at edge ``c`` (writes commit now)."""
        d = self.decode(r.addr)
        self._seq[m] += 1
        rid = r.id & ((1 << self.idw) - 1)
        if d.ok:
            self.ptr[d.bank] = (m + 1) % self.nm  # RR: the winner gets the lowest priority next (unused for FIXED)
            self.stats["grants"] += 1
        if not d.ok:
            kind = "err_write" if r.we else "err_read"
            self.stats[kind] += 1
            e = ExpRsp(self._seq[m], kind, bool(r.we), True, rid, r.addr, c + self.rl)
        elif r.we:
            self.mem.write(d.word, r.wdata, r.wmask)
            self.stats["write"] += 1
            if not self.wa:
                self.stats["posted"] += 1
                return None
            e = ExpRsp(self._seq[m], "write_ack", True, False, rid, r.addr, c + self.rl)
        else:
            self.stats["read"] += 1
            e = ExpRsp(self._seq[m], "read", False, False, rid, d.word, c + self.rl, snap=self.mem.snapshot(d.word))
        self.ports[m].push(e)
        return e

    def check_rsp_data(self, exp: ExpRsp, rdata: int) -> Optional[str]:
        if exp.kind == "read":
            return self.mem.check(exp.snap, rdata)  # type: ignore[arg-type]
        if rdata != 0:
            return "%s response must carry all-zero rdata, got 0x%x" % (exp.kind, rdata)
        return None
