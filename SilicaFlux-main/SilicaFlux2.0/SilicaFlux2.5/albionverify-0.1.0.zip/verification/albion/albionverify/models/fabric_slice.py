"""Reference models for the SFB2 timing cells: elastic 2-entry register slice (skid buffer), ``sfb_reg_slice``
and the default (decode-error) slave.

Specification used (not the RTL source):

* PROTOCOL.md R12 / section 7: ``sfb_reg_slice`` is protocol-transparent, adds one cycle per sliced
  direction, sustains one transfer per cycle with full back-pressure, stores up to one more transaction
  per sliced channel; "a write still inside an sfb_reg_slice is dropped" by reset (R11).
* ARCHITECTURE.md: ``sfb_skid_buffer`` = "2-entry skid", header of sfb_reg_slice.sv: "(valid, data AND ready
  registered); +1 cycle latency", header of sfb_skid_buffer.sv: "two-entry valid/ready register slice.
  Registers the forward (valid/data) and backward (ready) paths; 1 transfer per cycle; payload stable while
  m_valid && !m_ready".
* header of sfb_error_slave.sv: "answers every request with rsp_error = 1 and rsp_rdata = 0, one cycle after
  acceptance ... ``req_ready = !pending || rsp_ready`` (one response buffered; full throughput) ...
  ``rsp_valid = pending`` (registered; held until rsp_ready)".

``ElasticBuffer`` is the cycle model of a skid buffer: a FIFO of at most two items; the forward side shows
the oldest item (``m_valid = len > 0``) and the backward side offers space (``s_ready = len < 2``), both a
pure function of the registered state (registered ready: it does not look at ``m_ready``).  An item accepted
at edge e is visible at the output during the cycle after e (the +1 cycle latency).
"""
from __future__ import annotations

from typing import Any, List, Optional, Tuple


class ElasticBuffer:
    DEPTH = 2

    def __init__(self):
        self.q: List[Any] = []

    def reset(self) -> None:
        self.q.clear()

    # ---- state -> outputs
    @property
    def s_ready(self) -> int:
        return int(len(self.q) < self.DEPTH)

    @property
    def m_valid(self) -> int:
        return int(len(self.q) > 0)

    @property
    def m_data(self) -> Any:
        return self.q[0] if self.q else None

    # ---- edge
    def step(self, s_valid: int, s_data: Any, m_ready: int) -> Tuple[bool, bool]:
        """Advance one clock edge given the inputs present before it.  Returns (pushed, popped)."""
        pop = bool(self.m_valid and m_ready)
        push = bool(s_valid and self.s_ready)
        if pop:
            self.q.pop(0)
        if push:
            self.q.append(s_data)
        return push, pop


class RegSliceModel:
    """Cycle model of ``sfb_reg_slice`` (REQ_SLICE / RSP_SLICE selectable per channel).

    Upstream (master side, ``s_``): requests in, responses out.  Downstream (slave side, ``m_``): requests
    out, responses in.  A channel without a slice is a wire (combinational pass-through)."""

    def __init__(self, req_slice: bool, rsp_slice: bool):
        self.req_slice, self.rsp_slice = bool(req_slice), bool(rsp_slice)
        self.req = ElasticBuffer()
        self.rsp = ElasticBuffer()

    def reset(self) -> None:
        self.req.reset()
        self.rsp.reset()

    def expected(self, s_req: Optional[tuple], m_req_ready: int, m_rsp: Optional[tuple], s_rsp_ready: int) -> dict:
        """Expected outputs for the cycle.  ``s_req`` = request payload tuple offered upstream (None when
        s_req_valid = 0); ``m_rsp`` = response payload tuple offered downstream (None when m_rsp_valid = 0).
        Returns dict(s_req_ready, m_req_valid, m_req_data, s_rsp_valid, s_rsp_data, m_rsp_ready)."""
        o = {}
        if self.req_slice:
            o["s_req_ready"], o["m_req_valid"], o["m_req_data"] = self.req.s_ready, self.req.m_valid, self.req.m_data
        else:
            o["s_req_ready"], o["m_req_valid"], o["m_req_data"] = m_req_ready, int(s_req is not None), s_req
        if self.rsp_slice:
            o["m_rsp_ready"], o["s_rsp_valid"], o["s_rsp_data"] = self.rsp.s_ready, self.rsp.m_valid, self.rsp.m_data
        else:
            o["m_rsp_ready"], o["s_rsp_valid"], o["s_rsp_data"] = s_rsp_ready, int(m_rsp is not None), m_rsp
        return o

    def step(self, s_req: Optional[tuple], m_req_ready: int, m_rsp: Optional[tuple], s_rsp_ready: int) -> None:
        if self.req_slice:
            self.req.step(int(s_req is not None), s_req, m_req_ready)
        if self.rsp_slice:
            self.rsp.step(int(m_rsp is not None), m_rsp, s_rsp_ready)


class ErrorSlaveModel:
    """``sfb_error_slave``: one buffered decode-error response."""

    def __init__(self):
        self.pend = 0

    def reset(self) -> None:
        self.pend = 0

    def req_ready(self, rsp_ready: int) -> int:
        return int((not self.pend) or bool(rsp_ready))

    def rsp_valid(self) -> int:
        return self.pend

    def step(self, req_valid: int, rsp_ready: int) -> None:
        acc = bool(req_valid) and bool(self.req_ready(rsp_ready))
        self.pend = int(acc or (bool(self.pend) and not rsp_ready))
