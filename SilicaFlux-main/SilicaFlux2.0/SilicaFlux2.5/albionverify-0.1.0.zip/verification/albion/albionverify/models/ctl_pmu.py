"""Reference model of ``cc_pmu`` (accelerator clock gate, reset and isolation control).

Written from MEMORY_MAP.md (block ``cc_pmu``), 01_ARCHITECTURE.md section 4, 05_ACCELERATORS.md section 3 and the
power-management paragraph of HW_SW_INTERFACE.md -- NOT from the RTL.

Documented behaviour used
  * INFO RO = [3:0] clock domains (1), [7:4] gateable domains (1), [8] DVFS (0), [9] power switches (0)  => 0x11.
  * ACC_CTRL RW, reset 0x1: [0] CLK_EN [1] RST [2] ISO.
  * ACC_STATUS RO: [0] CLK_ON [1] IN_RESET [2] ISOLATED [3] EXT_IDLE [4] VEC_BUSY [5] TSU_BUSY [6] TSU_HALTED
    [7] CLK_OFF_PENDING [8] FATAL_ISO.  CC_STATE RO [0] = CPU in WFI.  SLEEP_CYC / GATED_CYC RO, saturating cycle counters.
  * CLK_EN = 0 requests the accelerator clock off; "the PMU enable is registered (glitch-free) and only drops when both
    accelerators are idle and no ControlCore transaction is outstanding" (01_ARCHITECTURE.md): CLK_ON stays 1 while a unit
    is busy or the external port is not idle.  RST = 1 holds the domain in reset, "applied only once the external port is
    idle"; release is immediate.  Isolation is automatic "whenever the clock is requested off or the domain is in reset,
    and optionally on a RAS fatal" (05_ACCELERATORS.md section 3); ACC_CTRL.ISO forces it.
  * Interpretation A-9 (cycle timing): the documents only say "registered"; ACC_CTRL is one register, CLK_ON and the
    effective reset are one more register stage computed from it (so CLK_ON falls two edges after the ACC_CTRL write).
  * A-1: reads of write-only registers do not exist here; unmapped offsets and writes to RO registers are refused.
"""
from __future__ import annotations

from typing import Dict, Optional

from . import ctl_spec as S
from .ctl_base import MASK32, RegModel

A = S.PMU
RO = (A["INFO"], A["ACC_STATUS"], A["CC_STATE"], A["SLEEP_CYC"], A["GATED_CYC"])
RW = (A["ACC_CTRL"],)


class PmuModel(RegModel):
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.ctl = S.PMU_ACC_CTRL_RESET & 7
        self.clk_on = 1
        self.rst_eff = 0
        self.sleep = 0
        self.gated = 0

    @staticmethod
    def iso(ctl, clk_on, fatal_iso, in_reset) -> int:
        return int(bool((ctl >> 2) & 1 or (ctl >> 1) & 1 or not ctl & 1 or not clk_on or fatal_iso or in_reset))

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:
        addr, we = inp["addr"], inp["we"]
        iso = self.iso(self.ctl, self.clk_on, inp["fatal_iso"], inp["acc_in_reset"])
        if addr & 3 or (addr not in RO and addr not in RW):
            err, rdata = 1, 0
        elif we:
            err, rdata = (1 if addr in RO else 0), None
        else:
            err = 0
            if addr == A["INFO"]:
                rdata = 0x11
            elif addr == A["ACC_CTRL"]:
                rdata = self.ctl
            elif addr == A["ACC_STATUS"]:
                rdata = (self.clk_on | (inp["acc_in_reset"] << 1) | (iso << 2) | (inp["ext_idle"] << 3) | (inp["vec_busy"] << 4) | (inp["tsu_busy"] << 5)
                         | (inp["tsu_halted"] << 6) | ((self.clk_on & (1 - (self.ctl & 1))) << 7) | (inp["fatal_iso"] << 8))
            elif addr == A["CC_STATE"]:
                rdata = inp["cpu_sleep"]
            elif addr == A["SLEEP_CYC"]:
                rdata = self.sleep
            else:
                rdata = self.gated
        return {"rdata": rdata, "err": err, "acc_clk_en": self.clk_on, "acc_rst_req": self.rst_eff, "acc_iso": iso}

    def clock(self, inp: Dict[str, int]) -> None:
        busy = inp["vec_busy"] or inp["tsu_busy"] or not inp["ext_idle"]
        n_clk_on = int(bool((self.ctl & 1) or busy))
        n_rst = int(bool((self.ctl >> 1) & 1 and (self.rst_eff or inp["ext_idle"])))
        if inp["cpu_sleep"] and self.sleep != MASK32:
            self.sleep += 1
        if not self.clk_on and self.gated != MASK32:
            self.gated += 1
        if inp["sel"] and inp["we"] and inp["addr"] == A["ACC_CTRL"]:
            self.ctl = inp["wdata"] & 7
        self.clk_on, self.rst_eff = n_clk_on, n_rst
