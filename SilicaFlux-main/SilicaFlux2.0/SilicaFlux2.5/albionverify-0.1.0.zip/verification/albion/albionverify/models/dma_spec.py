"""Specification constants and pure functions of the SilicaFlux DataFabric DMA.

Written from the SPEC documents only (rtl/datafabric/docs/datafabric/DMA.md, MEMORY_MAP.md,
PROTOCOL.md), never from the RTL.  Nothing here imports cocotb or the simulator.

Terminology
    SB   = DW/8, the number of bytes of one SFB2 data beat (the "word")
    beat = one aligned word of the transfer: beat k reads the word at SRC + k*SB and writes the word
           at DST + k*SB; the final beat of a length that is not a multiple of SB writes only the
           bytes < LENGTH (byte-accurate lengths, DMA.md sec. 2)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

# ----------------------------------------------------------------------------- register map (MEMORY_MAP.md)
CONTROL = 0x000
STATUS = 0x004
SRC_ADDR = 0x008
DST_ADDR = 0x00C
LENGTH = 0x010
BYTES_DONE = 0x014
INT_ENABLE = 0x018
INT_STATUS = 0x01C
ERROR_CODE = 0x020
ERROR_ADDR = 0x024
INFO = 0x028
ID = 0x02C
ACTIVE_CYCLES = 0x030
STALL_CYCLES = 0x034
TRANSFERS = 0x038

REG_NAMES = {
    CONTROL: "CONTROL", STATUS: "STATUS", SRC_ADDR: "SRC_ADDR", DST_ADDR: "DST_ADDR", LENGTH: "LENGTH",
    BYTES_DONE: "BYTES_DONE", INT_ENABLE: "INT_ENABLE", INT_STATUS: "INT_STATUS", ERROR_CODE: "ERROR_CODE",
    ERROR_ADDR: "ERROR_ADDR", INFO: "INFO", ID: "ID", ACTIVE_CYCLES: "ACTIVE_CYCLES",
    STALL_CYCLES: "STALL_CYCLES", TRANSFERS: "TRANSFERS",
}
PERF_REGS = (ACTIVE_CYCLES, STALL_CYCLES, TRANSFERS)
ALL_REGS = tuple(REG_NAMES)
READ_ONLY_REGS = (STATUS, BYTES_DONE, ERROR_CODE, ERROR_ADDR, INFO, ID) + PERF_REGS
# the register page is 4 KiB: every other 12-bit offset is unmapped (and so is any non word-aligned one)

CTRL_START = 1 << 0
CTRL_ABORT = 1 << 1
ST_BUSY = 1 << 0
ST_DONE = 1 << 1
ST_ERROR = 1 << 2
ST_ABORTED = 1 << 3
ST_STATE_LSB = 8
INT_DONE = 1 << 0
INT_ERROR = 1 << 1

ID_VALUE = 0x53464446  # 'SFDF'
VERSION = 1

# ----------------------------------------------------------------------------- ERROR_CODE enum (dma.error)
E_NONE = 0
E_ZERO_LENGTH = 1
E_LENGTH = 2
E_SRC_ALIGN = 3
E_DST_ALIGN = 4
E_SRC_OVERFLOW = 5
E_DST_OVERFLOW = 6
E_OVERLAP = 7
E_READ_BUS = 8
E_WRITE_BUS = 9
E_ABORTED = 10
ERROR_NAMES = {0: "NONE", 1: "ZERO_LENGTH", 2: "LENGTH", 3: "SRC_ALIGN", 4: "DST_ALIGN", 5: "SRC_OVERFLOW", 6: "DST_OVERFLOW",
               7: "OVERLAP", 8: "READ_BUS", 9: "WRITE_BUS", 10: "ABORTED"}

# ----------------------------------------------------------------------------- STATUS.STATE enum (dma.state)
S_IDLE = 0
S_VALIDATE = 1
S_ISSUE_READ = 2
S_WAIT_READ = 3
S_ISSUE_WRITE = 4
S_WAIT_WRITE = 5
S_COMPLETE = 6
S_ERROR = 7
STATE_NAMES = {0: "IDLE", 1: "VALIDATE", 2: "ISSUE_READ", 3: "WAIT_READ", 4: "ISSUE_WRITE", 5: "WAIT_WRITE", 6: "COMPLETE", 7: "ERROR"}

ADDR_SPACE = 1 << 32


def validate(src: int, dst: int, length: int, sb: int, max_len_log2: int) -> int:
    """Descriptor validation, DMA.md sec. 2: the FIRST failing rule wins.  Returns an ERROR_CODE."""
    if length == 0:
        return E_ZERO_LENGTH
    if length > (1 << max_len_log2):
        return E_LENGTH
    if src % sb:
        return E_SRC_ALIGN
    if dst % sb:
        return E_DST_ALIGN
    if src + length > ADDR_SPACE:
        return E_SRC_OVERFLOW
    if dst + length > ADDR_SPACE:
        return E_DST_OVERFLOW
    # half-open byte ranges [src, src+len) and [dst, dst+len) intersect (includes src == dst)
    if src < dst + length and dst < src + length:
        return E_OVERLAP
    return E_NONE


def num_beats(length: int, sb: int) -> int:
    return (length + sb - 1) // sb


def beat_nbytes(k: int, length: int, sb: int) -> int:
    """Bytes of the transfer carried by beat k (SB for every beat but a partial last one)."""
    return min(sb, length - k * sb)


def beat_strobe(k: int, length: int, sb: int) -> int:
    """Write strobe of beat k: only bytes < LENGTH are enabled (bit b = byte lane b = address + b)."""
    return (1 << beat_nbytes(k, length, sb)) - 1


@dataclass(frozen=True)
class Beat:
    index: int
    src_addr: int
    dst_addr: int
    nbytes: int
    strobe: int


def beat_plan(src: int, dst: int, length: int, sb: int) -> List[Beat]:
    return [Beat(k, src + k * sb, dst + k * sb, beat_nbytes(k, length, sb), beat_strobe(k, length, sb)) for k in range(num_beats(length, sb))]


def info_word(dw_bytes: int, buffered: int, fifo_depth: int, max_len_log2: int) -> int:
    """INFO register: [7:0] DW_BYTES, [8] BUFFERED, [15:12] FIFO_LOG2, [23:16] MAX_LEN_LOG2, [31:24] VERSION."""
    fifo_log2 = (fifo_depth - 1).bit_length() if buffered else 0
    return (VERSION << 24) | (max_len_log2 << 16) | (fifo_log2 << 12) | ((1 if buffered else 0) << 8) | dw_bytes


def lane_mask_bits(strobe: int, sb: int) -> int:
    """Bit mask (over the DW-bit data word) of the byte lanes enabled in ``strobe``."""
    m = 0
    for b in range(sb):
        if (strobe >> b) & 1:
            m |= 0xFF << (8 * b)
    return m


def split_word(word: int, sb: int) -> List[int]:
    return [(word >> (8 * b)) & 0xFF for b in range(sb)]


def word_bytes_at(addr: int, sb: int) -> Tuple[int, int]:
    """(aligned base address, lane offset) of a byte address."""
    return addr - (addr % sb), addr % sb
