"""Independent reference model of ``hpc_scratchpad`` (SilicaFlux-HPC Module 04, QUEUE_DEPTH = 0 direct mode).

Written from the specification only: ``rtl/hpc_m04_scratchpad/docs/01_architecture_and_interface.md`` (ports, handshake
rules H1-H7, exact timing, ordering, reset), ``02_address_map.md`` (byte address -> bank/row/error, with golden
examples), ``03_banking_and_arbitration.md`` (eligibility, port models, arbitration algorithm, events).  Not
modelled: request queues (QUEUE_DEPTH > 0), byte-parity integrity (ECC_MODE), FPGA/ASIC backends.

  address map  CB = log2(CAPACITY), OFF = log2(DATA_WIDTH/8), word = A[CB-1:OFF], BW = log2(NUM_BANKS),
               LOW  : bank = w mod B,            row = w div B
               XOR  : bank = (w mod B) xor ((w div B) mod B), row = w div B
               HIGH : bank = w div depth,        row = w mod depth        (depth = 2^(CB-OFF-BW))
               in range <=> A[ADDR_WIDTH-1:CB] == BASE[ADDR_WIDTH-1:CB]   (all upper bits compared; no aliasing)
  errors       priority RANGE(1) > ALIGN(2) > STROBE(3); error requests never touch a bank, are answered in order
               with rsp_err = 1, err_code, rdata = 0, rsp_we = (request was a write); STROBE only when BYTE_WE = 0
               and a write strobe is not all-ones.  A write with wstrb = 0 and BYTE_WE = 1 is a legal no-op.
  eligibility  a head request is eligible for its bank when it decodes without error and the port has a response
               credit (posted writes need none); an error request needs no bank, only a free credit.
  arbitration  per bank, order = ptr, ptr+1, ... (RR) or 0, 1, ... (FIXED); first requester that fits a free slot gets
               it (1RW: 1 slot; 1R1W: 1 write + 1 read, same row of a write and a read never together; 2RW: 2 slots,
               same row only if both are reads); RR: ptr <- (FIRST granted port) + 1.
  events       ev_conflict[p] = eligible and not granted; ev_bank_conflict[b] = an eligible requester of bank b
               left unserved; ev_bank_ops[b] = grants of bank b; ev_credit_stall[p] = head blocked by credits;
               ev_error[p] = decode-error request issued; ev_accept/ev_issue (accept == issue in direct mode).
  counters     perf_* count the events since reset, saturating (never wrap); perf_cycles counts cycles since reset.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from .sram_core import ExpRsp, LaneMemory, RspPathModel

MAP_LOW, MAP_XOR, MAP_HIGH = 0, 1, 2
PORT_1RW, PORT_1R1W, PORT_2RW = 0, 1, 2
ARB_RR, ARB_FIXED = 0, 1
ERR_OK, ERR_RANGE, ERR_ALIGN, ERR_STROBE = 0, 1, 2, 3


@dataclass
class SpmExp(ExpRsp):
    code: int = 0


@dataclass(frozen=True)
class SReq:
    valid: bool
    we: bool = False
    addr: int = 0
    wdata: int = 0
    wstrb: int = 0
    tag: int = 0


@dataclass
class SDec:
    code: int
    word: int = 0
    bank: int = 0
    row: int = 0

    @property
    def ok(self) -> bool:
        return self.code == ERR_OK


@dataclass
class SPred:
    ready: List[bool]  # == ev_issue == req_ready (direct mode: accept == issue)
    conflict: List[bool]  # ev_conflict
    credit_stall: List[bool]
    error: List[bool]  # ev_error
    bank_ops: List[int]
    bank_conflict: List[bool]
    slots: Dict[int, Dict[str, int]]  # bank -> {"a": port, "b": port}
    first: Dict[int, int]  # bank -> first granted port (for the RR pointer)


def log2(n: int) -> int:
    assert n > 0 and n & (n - 1) == 0
    return n.bit_length() - 1


class SpmModel:
    def __init__(self, num_ports: int, capacity: int, num_banks: int, data_width: int, addr_width: int, base: int = 0,
                 read_latency: int = 1, byte_we: int = 1, port_mode: int = PORT_1RW, map_: int = MAP_LOW, arb: int = ARB_RR,
                 rsp_fifo_depth: Optional[int] = None, write_ack: int = 1, tag_w: int = 8, cnt_w: int = 32):
        self.np, self.cap, self.nb, self.dw, self.aw, self.base = num_ports, capacity, num_banks, data_width, addr_width, base
        self.nbytes = data_width // 8
        self.cb = log2(capacity)
        self.off = log2(self.nbytes)
        self.waw = self.cb - self.off
        self.bw = log2(num_banks)
        self.rw = self.waw - self.bw
        self.depth = 1 << self.rw
        self.rl, self.byte_we, self.pm, self.map, self.arb = read_latency, byte_we, port_mode, map_, arb
        self.wa, self.tag_w, self.cnt_w = int(write_ack), tag_w, cnt_w
        self.fd = read_latency + 1 if rsp_fifo_depth is None else rsp_fifo_depth
        self.full_strb = (1 << self.nbytes) - 1
        self.mem = LaneMemory(self.nbytes, 8, "unknown")
        self.ports = [RspPathModel(read_latency, self.fd) for _ in range(num_ports)]
        self.ptr = [0] * num_banks
        self._seq = [0] * num_ports
        self._live = False
        self.stats = {"read": 0, "write": 0, "posted": 0, "err": 0, "grants": 0, "conflicts": 0}
        self.counters = self._zero_counters()

    # ------------------------------------------------------------------ decode
    def decode(self, addr: int, we: bool, wstrb: int) -> SDec:
        if self.aw > self.cb and (addr >> self.cb) != (self.base >> self.cb):
            return SDec(ERR_RANGE)
        if self.off and (addr & (self.nbytes - 1)):
            return SDec(ERR_ALIGN)
        if self.byte_we == 0 and we and (wstrb & self.full_strb) != self.full_strb:
            return SDec(ERR_STROBE)
        w = (addr >> self.off) & ((1 << self.waw) - 1)
        B = self.nb
        if B == 1:
            return SDec(ERR_OK, w, 0, w)
        if self.map == MAP_LOW:
            return SDec(ERR_OK, w, w % B, w // B)
        if self.map == MAP_XOR:
            return SDec(ERR_OK, w, (w % B) ^ ((w // B) % B), w // B)
        return SDec(ERR_OK, w, w // self.depth, w % self.depth)

    def needs_rsp(self, we: bool, ok: bool) -> bool:
        return (not we) or self.wa != 0 or not ok

    # ------------------------------------------------------------------ reset / counters
    def _zero_counters(self) -> Dict[str, List[int]]:
        z = lambda n: [0] * n
        return {"cycles": [0], "accept": z(self.np), "issue": z(self.np), "complete": z(self.np), "conflict": z(self.np), "wait": z(self.np),
                "error": z(self.np), "bank_ops": z(self.nb)}

    def reset(self) -> List[ExpRsp]:
        gone: List[ExpRsp] = []
        for p in self.ports:
            gone += p.reset()
        self.ptr = [0] * self.nb
        self._live = False
        self.counters = self._zero_counters()
        return gone

    def begin_edge(self) -> bool:
        live = self._live
        self._live = True
        for p in self.ports:
            p.begin_edge()
        return live

    def count(self, name: str, idx: int, inc: int) -> None:
        mx = (1 << self.cnt_w) - 1
        c = self.counters[name]
        c[idx] = min(mx, c[idx] + inc)

    # ------------------------------------------------------------------ one edge
    def predict(self, live: bool, reqs: Sequence[SReq]) -> SPred:
        NP, NB = self.np, self.nb
        dec = [self.decode(r.addr, r.we, r.wstrb) for r in reqs]
        can = [self.ports[p].ready(live, True) for p in range(NP)]  # a response credit is free (and the port is live)
        credit = [self.ports[p].ready(live, self.needs_rsp(reqs[p].we, dec[p].ok)) for p in range(NP)]
        elig = [bool(reqs[p].valid and dec[p].ok and credit[p]) for p in range(NP)]
        slots: Dict[int, Dict[str, int]] = {b: {} for b in range(NB)}
        first: Dict[int, int] = {}
        bank_conflict = [False] * NB
        granted = [False] * NP
        for b in range(NB):
            order = range(NP) if self.arb == ARB_FIXED else [(self.ptr[b] + k) % NP for k in range(NP)]
            a: Optional[int] = None
            bb: Optional[int] = None
            for p in order:
                if not elig[p] or dec[p].bank != b:
                    continue
                r = dec[p].row
                we = reqs[p].we
                slot = None
                if self.pm == PORT_1R1W:
                    if we:
                        if a is None and not (bb is not None and dec[bb].row == r):
                            slot = "a"
                    else:
                        if bb is None and not (a is not None and dec[a].row == r):
                            slot = "b"
                elif self.pm == PORT_2RW:
                    if a is None:
                        slot = "a"
                    elif bb is None and not (dec[a].row == r and (reqs[a].we or we)):
                        slot = "b"
                else:
                    if a is None:
                        slot = "a"
                if slot == "a":
                    a = p
                elif slot == "b":
                    bb = p
                if slot:
                    slots[b][slot] = p
                    granted[p] = True
                    first.setdefault(b, p)
                else:
                    bank_conflict[b] = True
        ready = [bool(granted[p] or (reqs[p].valid and not dec[p].ok and can[p])) for p in range(NP)]
        conflict = [bool(elig[p] and not granted[p]) for p in range(NP)]
        credit_stall = [bool(reqs[p].valid and live and ((not credit[p]) if dec[p].ok else (not can[p]))) for p in range(NP)]
        error = [bool(ready[p] and not dec[p].ok) for p in range(NP)]
        ops = [len(slots[b]) for b in range(NB)]
        return SPred(ready, conflict, credit_stall, error, ops, bank_conflict, slots, first)

    def accept(self, c: int, p: int, r: SReq, pred: SPred) -> Optional[SpmExp]:
        """Apply the request of port ``p`` issued at edge ``c`` (accept == issue; writes commit now)."""
        d = self.decode(r.addr, r.we, r.wstrb)
        self._seq[p] += 1
        tag = r.tag & ((1 << self.tag_w) - 1)
        if not d.ok:
            self.stats["err"] += 1
            e = SpmExp(self._seq[p], "err_write" if r.we else "err_read", bool(r.we), True, tag, r.addr, c + self.rl, code=d.code)
        elif r.we:
            self.mem.write(d.word, r.wdata, r.wstrb & self.full_strb)
            self.stats["write"] += 1
            if not self.wa:
                self.stats["posted"] += 1
                return None
            e = SpmExp(self._seq[p], "write_ack", True, False, tag, r.addr, c + self.rl, code=0)
        else:
            self.stats["read"] += 1
            e = SpmExp(self._seq[p], "read", False, False, tag, r.addr, c + self.rl, snap=self.mem.snapshot(d.word), code=0)
        self.ports[p].push(e)
        return e

    def end_edge(self, pred: SPred, reqs: Sequence[SReq], completed: Sequence[bool]) -> None:
        """Advance the RR pointers and the event counters for an edge (call after accept())."""
        if self.arb == ARB_RR:
            for b, p in pred.first.items():
                self.ptr[b] = (p + 1) % self.np
        self.count("cycles", 0, 1)
        for p in range(self.np):
            r = reqs[p]
            if r.valid and pred.ready[p]:
                self.count("accept", p, 1)
            if pred.ready[p]:
                self.count("issue", p, 1)
            if completed[p]:
                self.count("complete", p, 1)
            if pred.conflict[p]:
                self.count("conflict", p, 1)
            if pred.error[p]:
                self.count("error", p, 1)
            if r.valid and not pred.ready[p]:  # direct mode: requests presented and not issued (Little's law counter)
                self.count("wait", p, 1)
        for b in range(self.nb):
            self.count("bank_ops", b, pred.bank_ops[b])

    def check_rsp_data(self, exp: ExpRsp, rdata: int) -> Optional[str]:
        if exp.kind == "read":
            return self.mem.check(exp.snap, rdata)  # type: ignore[arg-type]
        if rdata != 0:
            return "%s response must carry all-zero rdata, got 0x%x" % (exp.kind, rdata)
        return None
