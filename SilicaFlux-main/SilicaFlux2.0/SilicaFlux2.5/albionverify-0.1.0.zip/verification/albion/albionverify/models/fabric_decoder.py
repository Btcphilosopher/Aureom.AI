"""Independent address-decode model of the SFB2 crossbar (DataFabric).

Written from the specification documents, not from the RTL source:

* docs/datafabric/PROTOCOL.md  R8 (causes of rsp_error: unmapped address, access-matrix denial,
  misaligned address are *fabric decode errors*), R9 (alignment: ``addr[log2(DW/8)-1:0] = 0``; with
  ``CHECK_ALIGN = 1`` a misaligned request is answered with a decode error and no slave sees it),
  section 5 (error table), section 6 ("unmapped addresses are never aliased").
* docs/datafabric/ARCHITECTURE.md section 2: ``sfb_addr_decoder`` = "mask decode, first match, access-matrix
  bit, alignment check".
* MEMORY_MAP.md: region = base + size window, little-endian 32-bit byte addresses.
* header comment of rtl/interconnect/sfb_addr_decoder.sv: "slave s is selected when
  (addr & SLV_MASK[s]) == SLV_BASE[s] and the access matrix bit EN[s] for this master is set. ... if
  [regions] overlapped, the lowest slave index would win".

Decision (``Decode.kind``):

  misaligned   CHECK_ALIGN and addr is not DW-aligned      -> decode error (takes precedence: the
               address is "treated as unmapped" by the spec; the three kinds are indistinguishable on the
               wire, the label only serves coverage)
  ok           some slave s with (addr & mask[s]) == base[s] and EN[m][s]; the lowest such s is selected
  denied       (addr & mask[s]) == base[s] holds for at least one slave but none of them is enabled for m
  unmapped     no region matches
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence, Tuple

KINDS = ("ok", "unmapped", "denied", "misaligned")


@dataclass(frozen=True)
class Decode:
    kind: str
    slave: Optional[int] = None

    @property
    def ok(self) -> bool:
        return self.kind == "ok"

    @property
    def error(self) -> bool:
        return self.kind != "ok"

    def __repr__(self) -> str:
        return "ok->s%d" % self.slave if self.kind == "ok" else self.kind


def unpack(value: int, n: int, width: int) -> List[int]:
    """Split a packed parameter (slave/master 0 in the LOW bits) into n fields of ``width`` bits."""
    return [(value >> (i * width)) & ((1 << width) - 1) for i in range(n)]


class AddressMap:
    def __init__(self, bases: Sequence[int], masks: Sequence[int], en: Optional[Sequence[Sequence[int]]] = None,
                 dw: int = 32, aw: int = 32, check_align: bool = True):
        assert len(bases) == len(masks)
        self.ns = len(bases)
        self.aw = aw
        self.full = (1 << aw) - 1
        self.bases = [b & self.full for b in bases]
        self.masks = [m & self.full for m in masks]
        self.dw = dw
        self.nbytes = dw // 8
        self.check_align = bool(check_align)
        self.nm = len(en) if en is not None else 1
        self.en = [[1] * self.ns for _ in range(self.nm)] if en is None else [list(map(int, r)) for r in en]

    @classmethod
    def from_params(cls, P: dict) -> "AddressMap":
        """Build from the elaboration parameters (ALBION_PARAMS JSON: wide values are plain ints)."""
        nm, ns = int(P.get("NM", 2)), int(P.get("NS", 2))
        aw = int(P.get("AW", 32))
        bases = unpack(int(P.get("SLV_BASE", 0)), ns, aw)
        masks = unpack(int(P.get("SLV_MASK", 0)), ns, aw)
        en_all = int(P["MST_SLV_EN"]) if "MST_SLV_EN" in P else (1 << (nm * ns)) - 1
        en = [[(en_all >> (m * ns + s)) & 1 for s in range(ns)] for m in range(nm)]  # PROTOCOL/ARCH: bit m*NS+s
        return cls(bases, masks, en, dw=int(P.get("DW", 32)), aw=aw, check_align=bool(int(P.get("CHECK_ALIGN", 1))))

    # ------------------------------------------------------------------ decode
    def matches(self, s: int, addr: int) -> bool:
        return (addr & self.masks[s]) == self.bases[s]

    def decode(self, m: int, addr: int) -> Decode:
        addr &= self.full
        if self.check_align and (addr & (self.nbytes - 1)):
            return Decode("misaligned")
        hits = [s for s in range(self.ns) if self.matches(s, addr)]
        for s in hits:  # lowest permitted slave index wins
            if self.en[m][s]:
                return Decode("ok", s)
        return Decode("denied") if hits else Decode("unmapped")

    # ------------------------------------------------------------------ region geometry
    def region_first(self, s: int) -> int:
        """Lowest address of region s (all don't-care bits zero)."""
        return self.bases[s]

    def region_last(self, s: int) -> int:
        """Highest address of region s (all don't-care bits one)."""
        return self.bases[s] | (~self.masks[s] & self.full)

    def region_size(self, s: int) -> int:
        """Number of addresses (valid for any mask: 2 ** number-of-free-bits)."""
        return 1 << bin(~self.masks[s] & self.full).count("1")

    def contiguous(self, s: int) -> bool:
        free = ~self.masks[s] & self.full
        return (free & (free + 1)) == 0

    def aligned(self, addr: int) -> int:
        return addr & ~(self.nbytes - 1) & self.full

    def probe_addresses(self, s: int, include_misaligned: bool = False) -> List[int]:
        """Boundary-focused addresses around region s (aligned unless asked otherwise):
        first/last, one word before/after each, every single-bit departure from the region (flip each
        mask bit of first and of last), and each don't-care bit set on its own.  Which of them are
        inside/outside is NOT assumed here: the caller classifies them with ``decode``."""
        nb, full = self.nbytes, self.full
        first, last = self.region_first(s), self.region_last(s)
        pts = {first, last & ~(nb - 1), (first - nb) & full, (last & ~(nb - 1)) + nb & full, (first + nb) & full,
               ((last & ~(nb - 1)) - nb) & full}
        lo_bit = (nb - 1).bit_length()
        for i in range(lo_bit, self.aw):
            if (self.masks[s] >> i) & 1:
                pts.add(first ^ (1 << i))
                pts.add((last & ~(nb - 1)) ^ (1 << i))
            else:
                pts.add(first | (1 << i))
        out = sorted(a & ~(nb - 1) & full for a in pts)
        if include_misaligned:
            for a in list(out):
                for off in range(1, nb):
                    out.append((a | off) & full)
        return sorted(set(out))

    def all_probe_addresses(self) -> List[int]:
        pts = set()
        for s in range(self.ns):
            pts.update(self.probe_addresses(s))
        return sorted(pts)

    def edge_class(self, addr: int, s: int) -> str:
        """Position of an (aligned) address relative to region s, for coverage: 'first', 'last',
        'inside', 'below' (one word below first), 'above' (one word above last), or 'far'."""
        a = addr & ~(self.nbytes - 1) & self.full
        first, last = self.region_first(s), self.region_last(s) & ~(self.nbytes - 1)
        if self.matches(s, a):
            if a == first:
                return "first"
            if a == last:
                return "last"
            return "inside"
        if a == (first - self.nbytes) & self.full:
            return "below"
        if a == (last + self.nbytes) & self.full:
            return "above"
        return "far"
