"""Cycle-accurate reference model of ``sfb_crossbar`` (SFB2 interconnect), written from the spec.

Specification used (not the RTL source): PROTOCOL.md (R1-R12 and sections 3-5), ARCHITECTURE.md
(sections 1-2) and the header comment of rtl/interconnect/sfb_crossbar.sv, sfb_error_slave.sv:

* every master port and every slave port carries at most ONE transaction (R6); a master's next request is
  accepted no earlier than the cycle in which its previous response is accepted (and that very cycle is
  allowed: full throughput); a slave is re-granted in the cycle its response is accepted (section 3);
* per slave one arbiter (:mod:`fabric_arbiter`) chooses among the masters whose request is *eligible*
  (valid, master free, decoded to this slave, access matrix permits);
* a request is accepted by the master port exactly when the chosen slave accepts it, in the same cycle
  (``s_req_ready -> m_req_ready`` is a combinational path), and then appears unchanged at the slave;
* requests that do not decode to a slave (unmapped / denied / misaligned) go to the per-master error slave:
  accepted without delay, answered ``rsp_error = 1, rsp_rdata = 0`` ONE cycle after acceptance, held until
  ``rsp_ready``; no slave sees them;
* a slave's response is steered only to the master that owns the transaction (recorded at acceptance), the
  master's ``rsp_ready`` is steered back to that slave;
* ``err_evt/err_addr/err_master/err_write``: the first (lowest-index) decode error accepted in a cycle;
* per-master events ``ev_req_accept``, ``ev_req_stall``, ``ev_arb_loss``, ``ev_rsp_stall``.

Interpretation (spec ambiguity, recorded in docs/fabric_verification_plan.md): ``ev_arb_loss[m]`` = master m
is eligible for slave s in the cycle but the arbiter's grant for s belongs to another master
(independent of whether slave s can accept in that cycle).

The model is a pure checker: ``evaluate`` maps (state, observed inputs) -> expected outputs, ``commit``
advances the state; it never looks at DUT outputs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from .fabric_arbiter import ArbiterModel
from .fabric_decoder import AddressMap, Decode


@dataclass
class XIn:
    """Observed DUT inputs of one cycle (values present before the clock edge)."""
    m_valid: List[int]
    m_write: List[int]
    m_addr: List[int]
    m_wdata: List[int]
    m_wstrb: List[int]
    m_rsp_ready: List[int]
    s_ready: List[int]
    s_rsp_valid: List[int]
    s_rsp_rdata: List[int]
    s_rsp_err: List[int]


@dataclass
class XOut:
    """Expected DUT outputs of the same cycle (+ internal decisions useful for diagnostics/coverage)."""
    m_req_ready: List[int]
    m_rsp_valid: List[int]
    m_rsp_rdata: List[int]
    m_rsp_err: List[int]
    s_req_valid: List[int]
    s_req_write: List[int]
    s_req_addr: List[int]
    s_req_wdata: List[int]
    s_req_wstrb: List[int]
    s_rsp_ready: List[Optional[int]]  # None = unconstrained (slave idle)
    err_evt: int
    err_addr: int
    err_master: int
    err_write: int
    ev_req_accept: List[int]
    ev_req_stall: List[int]
    ev_arb_loss: List[int]
    ev_rsp_stall: List[int]
    # diagnostics
    dec: List[Optional[Decode]] = field(default_factory=list)
    winner: List[Optional[int]] = field(default_factory=list)  # arbiter choice per slave
    elig: List[List[int]] = field(default_factory=list)  # elig[s][m]
    acc_s: List[int] = field(default_factory=list)  # slave s accepted a request this cycle
    acc_e: List[int] = field(default_factory=list)  # master m's decode error accepted this cycle
    m_free: List[int] = field(default_factory=list)
    s_free: List[int] = field(default_factory=list)
    m_rsp_hs: List[int] = field(default_factory=list)
    s_rsp_hs: List[int] = field(default_factory=list)


class XbarModel:
    def __init__(self, amap: AddressMap, nm: int, ns: int, arb_mode: int):
        self.amap = amap
        self.nm, self.ns = nm, ns
        self.arb = [ArbiterModel(nm, arb_mode) for _ in range(ns)]
        self.reset()

    def reset(self) -> None:
        self.out = [0] * self.nm  # master has a transaction in flight
        self.busy = [0] * self.ns  # slave has a transaction in flight
        self.owner = [0] * self.ns  # master index that owns the slave's transaction
        self.epend = [0] * self.nm  # error slave holds an unanswered decode error
        for a in self.arb:
            a.reset()

    # ------------------------------------------------------------------------------------------
    def evaluate(self, x: XIn) -> XOut:
        nm, ns = self.nm, self.ns
        dec: List[Optional[Decode]] = [self.amap.decode(m, x.m_addr[m]) if x.m_valid[m] else None for m in range(nm)]

        # --- responses (state + slave inputs)
        m_rsp_valid = [0] * nm
        m_rsp_err = [0] * nm
        m_rsp_rdata = [0] * nm
        for m in range(nm):
            if self.epend[m]:
                m_rsp_valid[m], m_rsp_err[m] = 1, 1
        s_rsp_ready: List[Optional[int]] = [None] * ns
        for s in range(ns):
            if self.busy[s]:
                m = self.owner[s]
                s_rsp_ready[s] = x.m_rsp_ready[m]
                if x.s_rsp_valid[s]:
                    m_rsp_valid[m], m_rsp_err[m], m_rsp_rdata[m] = 1, x.s_rsp_err[s], x.s_rsp_rdata[s]
        m_rsp_hs = [m_rsp_valid[m] & x.m_rsp_ready[m] for m in range(nm)]
        s_rsp_hs = [int(bool(self.busy[s]) and bool(x.s_rsp_valid[s]) and bool(x.m_rsp_ready[self.owner[s]])) for s in range(ns)]
        m_free = [int((not self.out[m]) or bool(m_rsp_hs[m])) for m in range(nm)]
        s_free = [int((not self.busy[s]) or bool(s_rsp_hs[s])) for s in range(ns)]

        # --- arbitration among eligible masters, one arbiter per slave
        elig = [[int(bool(x.m_valid[m]) and bool(m_free[m]) and dec[m].ok and dec[m].slave == s) for m in range(nm)] for s in range(ns)]
        winner = [self.arb[s].select(elig[s]) for s in range(ns)]
        s_req_valid = [int(winner[s] is not None and bool(s_free[s])) for s in range(ns)]
        acc_s = [int(bool(s_req_valid[s]) and bool(x.s_ready[s])) for s in range(ns)]

        s_req_write = [0] * ns
        s_req_addr = [0] * ns
        s_req_wdata = [0] * ns
        s_req_wstrb = [0] * ns
        for s in range(ns):
            if s_req_valid[s]:
                w = winner[s]
                s_req_write[s], s_req_addr[s], s_req_wdata[s], s_req_wstrb[s] = x.m_write[w], x.m_addr[w], x.m_wdata[w], x.m_wstrb[w]

        # --- decode-error slaves (req_ready = !pending || rsp_ready)
        acc_e = [0] * nm
        for m in range(nm):
            e_valid = bool(x.m_valid[m]) and bool(m_free[m]) and dec[m] is not None and dec[m].error
            e_ready = (not self.epend[m]) or bool(x.m_rsp_ready[m])
            acc_e[m] = int(e_valid and e_ready)

        # --- master-side request acceptance and events
        m_req_ready = [0] * nm
        for m in range(nm):
            m_req_ready[m] = acc_e[m]
            for s in range(ns):
                if acc_s[s] and winner[s] == m:
                    m_req_ready[m] = 1
        ev_loss = [int(any(elig[s][m] and winner[s] is not None and winner[s] != m for s in range(ns))) for m in range(nm)]

        # --- decode-error capture: the lowest-index master among those whose error was accepted
        err_evt, err_addr, err_master, err_write = 0, 0, 0, 0
        for m in range(nm):
            if acc_e[m]:
                err_evt, err_addr, err_master, err_write = 1, x.m_addr[m], m, x.m_write[m]
                break

        return XOut(
            m_req_ready=m_req_ready, m_rsp_valid=m_rsp_valid, m_rsp_rdata=m_rsp_rdata, m_rsp_err=m_rsp_err,
            s_req_valid=s_req_valid, s_req_write=s_req_write, s_req_addr=s_req_addr, s_req_wdata=s_req_wdata,
            s_req_wstrb=s_req_wstrb, s_rsp_ready=s_rsp_ready, err_evt=err_evt, err_addr=err_addr, err_master=err_master,
            err_write=err_write,
            ev_req_accept=[int(bool(x.m_valid[m]) and bool(m_req_ready[m])) for m in range(nm)],
            ev_req_stall=[int(bool(x.m_valid[m]) and not m_req_ready[m]) for m in range(nm)],
            ev_arb_loss=ev_loss,
            ev_rsp_stall=[int(bool(m_rsp_valid[m]) and not x.m_rsp_ready[m]) for m in range(nm)],
            dec=dec, winner=winner, elig=elig, acc_s=acc_s, acc_e=acc_e, m_free=m_free, s_free=s_free,
            m_rsp_hs=m_rsp_hs, s_rsp_hs=s_rsp_hs,
        )

    # ------------------------------------------------------------------------------------------
    def commit(self, x: XIn, o: XOut) -> None:
        """Advance the registered state across the clock edge that ends the evaluated cycle."""
        nm, ns = self.nm, self.ns
        for m in range(nm):
            if o.ev_req_accept[m]:
                self.out[m] = 1
            elif o.m_rsp_hs[m]:
                self.out[m] = 0
            self.epend[m] = int(bool(o.acc_e[m]) or (bool(self.epend[m]) and not x.m_rsp_ready[m]))
        for s in range(ns):
            if o.acc_s[s]:
                self.busy[s] = 1
                self.owner[s] = o.winner[s]
            elif o.s_rsp_hs[s]:
                self.busy[s] = 0
            presented = bool(o.s_req_valid[s])
            self.arb[s].step(o.winner[s], presented, bool(o.acc_s[s]))
