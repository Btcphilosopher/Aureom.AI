"""Cycle-level reference model of ``cc_sfb_gate`` (SFB2 pass-through that can refuse).

Written from the specification text of the block (RTL header: refuse semantics, one transaction at a time, refused request
accepted locally and answered one cycle later with rsp_error = 1 and rdata = 0, a request presented downstream is never
withdrawn, ``idle`` = nothing outstanding), the SFB2 protocol rules R1-R8 (rtl/datafabric/docs/datafabric/PROTOCOL.md) and
the two uses described in HW_SW_INTERFACE.md (host write lock: refused host writes get an error response; accelerator
isolation on the external port) -- NOT by copying RTL expressions.

Behaviour
  * The gate carries ONE transaction at a time ("free" = no forwarded transaction waiting for its response and no locally
    answered one waiting for its acceptance).
  * A request that arrives while the gate is free is decided on the spot: ``refuse`` = 1 -> accepted locally (s_req_ready = 1,
    nothing reaches the master side), answered with error / rdata 0 in a later cycle and held until s_rsp_ready;
    ``refuse`` = 0 -> presented on the master side (m_req_valid) and accepted when the downstream accepts (s_req_ready = m_req_ready).
  * Once a request has been presented downstream and not accepted, it is never withdrawn: a later refuse is ignored for it.
  * Responses of forwarded transactions pass through unchanged (rdata, error); the master-side response ready follows s_rsp_ready.
  * refused_evt pulses in the cycle a request is refused; idle = free and nothing presented downstream.
"""
from __future__ import annotations

from typing import Dict, Optional

from .ctl_base import RegModel


class SfbGateModel(RegModel):
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.out = 0  # forwarded transaction accepted, response pending
        self.loc = 0  # locally refused transaction, response pending
        self.pend = 0  # request presented downstream in the previous cycle and not accepted

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:
        free = not self.out and not self.loc
        refuse = bool(inp["refuse"]) and not self.pend
        m_valid = bool(inp["s_req_valid"] and free and not refuse)
        loc_acc = bool(inp["s_req_valid"] and free and refuse)
        s_ready = bool(free and (True if refuse else inp["m_req_ready"]))
        s_rvalid = bool(self.loc or inp["m_rsp_valid"])
        out = {
            "s_req_ready": int(s_ready), "s_rsp_valid": int(s_rvalid),
            "s_rsp_rdata": 0 if self.loc else (inp["m_rsp_rdata"] if inp["m_rsp_valid"] else None),
            "s_rsp_error": 1 if self.loc else (inp["m_rsp_error"] if inp["m_rsp_valid"] else None),
            "m_req_valid": int(m_valid),
            "m_req_write": inp["s_req_write"] if m_valid else None, "m_req_addr": inp["s_req_addr"] if m_valid else None,
            "m_req_wdata": inp["s_req_wdata"] if m_valid else None, "m_req_wstrb": inp["s_req_wstrb"] if m_valid else None,
            "m_rsp_ready": int(not self.loc and inp["s_rsp_ready"]),
            "refused_evt": int(loc_acc), "idle": int(free and not m_valid),
        }
        self._d = (free, m_valid, loc_acc)
        return out

    def clock(self, inp: Dict[str, int]) -> None:
        free, m_valid, loc_acc = self._d
        fwd = m_valid and inp["m_req_ready"]
        m_hs = bool(inp["m_rsp_valid"] and not self.loc and inp["s_rsp_ready"])
        self.pend = int(m_valid and not inp["m_req_ready"])
        if fwd and not m_hs:
            self.out = 1
        elif m_hs:
            self.out = 0
        if loc_acc:
            self.loc = 1
        elif self.loc and inp["s_rsp_ready"]:
            self.loc = 0
