"""Independent reference model of the SilicaFlux DataFabric DMA (`silicaflux_dma`).

Written from DMA.md / MEMORY_MAP.md / PROTOCOL.md (see dma_spec.py), NOT from the RTL.  It is an
*observation driven* architectural model: the bench feeds it, edge by edge, everything that can be seen on
the pins (register-bus accesses, SFB2 request/response handshakes, the busy / irq pins) and the model

  * predicts what every register read must return and which register writes must be refused,
  * checks every bus transaction the DMA issues against the transfer descriptor (address, order, strobe,
    data, outstanding limits, FIFO credit, burst phases, error / abort stop rules),
  * decides the final outcome of the transfer (DONE or ERROR + ERROR_CODE + ERROR_ADDR + BYTES_DONE) from the
    transaction history, and checks the DUT's terminal edge against it.

The cycle at which a transfer ends is a DUT choice (the spec gives none); it is taken from the ``busy`` pin
and *validated* (never before the work is done, never later than ``HANG_CYCLES`` after the last bus activity,
BUSY rises with START, ...).  Everything else is predicted from the spec alone.

Edge convention (matches docs/FRAMEWORK.md): an ``Edge`` describes what the flops sampled at rising edge ``n``
(values read just after the edge are pre-edge values).  Registers / counters change AT the edge, so a register
read at edge ``n`` sees the effects of edges < n only.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Sequence, Set, Tuple

from . import dma_spec as S

HANG_CYCLES = 24  # max cycles the DMA may sit with nothing presented / outstanding before it must finish


class DmaModelError(AssertionError):
    """The DUT's observed behaviour contradicts the specification model."""


@dataclass(frozen=True)
class DmaConfig:
    dw_bytes: int = 4
    engine: int = 0
    fifo_depth: int = 8
    burst: int = 8
    dual_port: int = 0
    max_out: int = 2
    max_len_log2: int = 24
    perf: int = 1

    @property
    def buffered(self) -> bool:
        return self.engine != 0

    @property
    def dual(self) -> bool:
        return self.buffered and self.dual_port != 0

    @property
    def nports(self) -> int:
        return 2 if self.dual else 1

    @property
    def out_limit(self) -> int:
        """Max outstanding transactions per port: 1 for the simple engine, MAX_OUT for the buffered one."""
        return self.max_out if self.buffered else 1

    @property
    def info(self) -> int:
        return S.info_word(self.dw_bytes, 1 if self.buffered else 0, self.fifo_depth if self.buffered else 1, self.max_len_log2)

    @staticmethod
    def from_params(p: dict, dw: Optional[int] = None) -> "DmaConfig":
        return DmaConfig(
            dw_bytes=(dw or p.get("DW", 32)) // 8, engine=p.get("ENGINE", 0), fifo_depth=p.get("FIFO_DEPTH", 8), burst=p.get("BURST", 8),
            dual_port=p.get("DUAL_PORT", 0), max_out=p.get("MAX_OUT", 2), max_len_log2=p.get("MAX_LEN_LOG2", 24), perf=p.get("PERF", 1))


# --------------------------------------------------------------------------------------------- observations


@dataclass
class BusReq:
    """A request that transferred (valid && ready) at this edge."""
    port: int
    write: bool
    addr: int
    wdata: int
    strb: int
    since: int  # first edge at which this request was seen presented (valid)


@dataclass
class BusRsp:
    port: int
    rdata: int
    err: bool


@dataclass
class RegAcc:
    write: bool
    addr: int
    wdata: int
    rdata: int  # observed rb_rdata
    err: bool  # observed rb_err


@dataclass
class Edge:
    n: int
    busy: bool  # busy pin during the cycle that ends at this edge (pre-edge)
    busy_next: Optional[bool] = None  # busy pin during the next cycle (None = unknown, e.g. reset)
    irq: Optional[bool] = None
    bytes_done_pin: Optional[int] = None
    fifo_level: Optional[int] = None
    ev_done: Optional[bool] = None
    reg: Optional[RegAcc] = None
    valid: Tuple[bool, ...] = ()  # per-port req_valid (pre-edge)
    ready: Tuple[bool, ...] = ()  # per-port req_ready (pre-edge)
    pres_write: Tuple[Optional[bool], ...] = ()  # per-port req_write of a presented request
    reqs: List[BusReq] = field(default_factory=list)
    rsps: List[BusRsp] = field(default_factory=list)


@dataclass
class Outcome:
    done: bool
    code: int  # ERROR_CODE (0 for done)
    addr: int  # ERROR_ADDR
    bytes_done: int
    alts: Dict[int, int] = field(default_factory=dict)  # code -> addr for legal alternatives (same-edge ties)


@dataclass
class RegExpect:
    err: bool
    rdata: Optional[int] = None  # exact expected value (reads), None = not checked
    mask: int = 0xFFFFFFFF
    rdata_set: Optional[Set[int]] = None  # alternatively: any of these
    state_allowed: Optional[Set[int]] = None  # STATUS.STATE legal values (compared separately)
    what: str = ""


def _fail(msg: str) -> None:
    raise DmaModelError(msg)


# --------------------------------------------------------------------------------------------- one transfer


class Transfer:
    """Transaction-level tracker of one started transfer."""

    def __init__(self, cfg: DmaConfig, src: int, dst: int, length: int, start_edge: int, strict: bool = True):
        # strict=False: only the data-level rules (address, strobe, data, read-before-write, error / BYTES_DONE
        # bookkeeping); the engine-side timing rules (issue closing after errors / abort, alternation, phases, credit,
        # outstanding limits) need the engine's own port and are skipped (used behind the adapter's router / slices)
        self.strict = strict
        self.cfg = cfg
        self.sb = cfg.dw_bytes
        self.src, self.dst, self.length = src, dst, length
        self.start_edge = start_edge
        self.code = S.validate(src, dst, length, self.sb, cfg.max_len_log2)
        self.valid = self.code == S.E_NONE
        self.plan = S.beat_plan(src, dst, length, self.sb) if self.valid else []
        self.n = len(self.plan)
        self.reads_acc = self.writes_acc = 0
        self.reads_rsp = 0
        self.rd_data: Dict[int, int] = {}
        self.rd_rsp_edge: Dict[int, int] = {}
        self.wstate: Dict[int, str] = {}  # beat -> pending | ok | err
        self.out: List[Deque[Tuple[bool, int, int]]] = [deque() for _ in range(cfg.nports)]  # (write, beat, accept edge)
        self.last_rsp_edge = -1
        self.last_req_write: Optional[bool] = None
        self.run_len = 0
        self.err_first: Optional[Tuple[int, str, int]] = None  # (edge, 'R'|'W', beat)
        self.err_tie: List[Tuple[str, int]] = []  # other errors at the same edge as the first
        self.read_err_beat: Optional[int] = None
        self.write_err_beat: Optional[int] = None
        self.close_r: Optional[int] = None  # edge after which no new READ may be presented (error)
        self.close_w: Optional[int] = None
        self.abort_edge: Optional[int] = None
        self.abort_tol = 0  # new requests tolerated after an abort that coincided with a response
        self.ok_prefix = 0
        self.bytes_ok = 0
        self.rd_ok_pushed = 0  # reads whose data entered the (model) FIFO
        self.rd_stopped = False
        self.quiet = 0
        self.n_ok_writes = 0

    # ------------------------------------------------------------------ queries
    def outstanding(self) -> int:
        return sum(len(q) for q in self.out)

    @property
    def clean(self) -> bool:
        return self.err_first is None and self.abort_edge is None

    @property
    def complete(self) -> bool:
        return self.valid and self.n_ok_writes == self.n

    def stop_met(self) -> bool:
        """True when the transfer has reached a state in which finishing is legal (given nothing in flight)."""
        if not self.valid or self.complete:
            return True
        if self.err_first is not None:
            if self.err_first[1] == "W" or self.abort_edge is not None or self.write_err_beat is not None:
                return True
            k = self.err_first[2]
            return all(self.wstate.get(j) == "ok" for j in range(k))  # read error: the beats before it are still written
        return self.abort_edge is not None

    # ------------------------------------------------------------------ events
    def on_rsp(self, e: int, r: BusRsp) -> None:
        q = self.out[r.port]
        if not q:
            _fail("edge %d: response on port %d with no outstanding request (SFB2 R5)" % (e, r.port))
        write, beat, acc_e = q.popleft()
        if acc_e >= e:
            _fail("edge %d: response in the acceptance cycle of its request (SFB2 R5)" % e)
        self.last_rsp_edge = e
        kind = "W" if write else "R"
        if r.err:
            self._note_error(e, kind, beat)
        if write:
            if r.err:
                self.wstate[beat] = "err"
                if self.write_err_beat is None:
                    self.write_err_beat = beat
                    extra = self.writes_acc - (beat + 1)
                    if self.strict and extra > self.cfg.out_limit - 1:
                        _fail("edge %d: write error at beat %d but %d later writes were already accepted (spec bound: MAX_OUT-1 = %d)" % (e, beat, extra, self.cfg.out_limit - 1))
                self.close_r = e if self.close_r is None else min(self.close_r, e)
                self.close_w = e if self.close_w is None else min(self.close_w, e)
            else:
                self.wstate[beat] = "ok"
                self.n_ok_writes += 1
                if self.write_err_beat is None and beat == self.ok_prefix:
                    self.bytes_ok += self.plan[beat].nbytes
                    self.ok_prefix += 1
        else:
            if r.err:
                if self.read_err_beat is None:
                    self.read_err_beat = beat
                self.close_r = e if self.close_r is None else min(self.close_r, e)
            else:
                self.rd_data[beat] = r.rdata
                self.rd_rsp_edge[beat] = e
                self.reads_rsp += 1

    def _note_error(self, e: int, kind: str, beat: int) -> None:
        if self.err_first is None:
            self.err_first = (e, kind, beat)
        elif self.err_first[0] == e and (kind, beat) != (self.err_first[1], self.err_first[2]):
            self.err_tie.append((kind, beat))

    def on_req(self, e: int, r: BusReq) -> None:
        cfg, sb = self.cfg, self.sb
        if not self.valid:
            _fail("edge %d: bus request issued for a descriptor that failed validation (%s)" % (e, S.ERROR_NAMES[self.code]))
        wr = r.write
        if cfg.dual:
            if r.port != (1 if wr else 0):
                _fail("edge %d: %s request on port %d (dual port: reads on port 0, writes on port 1)" % (e, "write" if wr else "read", r.port))
        k = self.writes_acc if wr else self.reads_acc
        what = "write" if wr else "read"
        if k >= self.n:
            _fail("edge %d: more %s requests (%d) than the %d beats of the transfer" % (e, what, k + 1, self.n))
        beat = self.plan[k]
        exp_addr = beat.dst_addr if wr else beat.src_addr
        if r.addr != exp_addr:
            _fail("edge %d: %s beat %d addressed 0x%08x, expected 0x%08x" % (e, what, k, r.addr, exp_addr))
        # ---- request ordering / data
        if wr:
            if r.strb != beat.strobe:
                _fail("edge %d: write beat %d strobe 0x%x, expected 0x%x (length %d, SB %d)" % (e, k, r.strb, beat.strobe, self.length, sb))
            if k not in self.rd_data:
                if self.read_err_beat is not None and k >= self.read_err_beat:
                    _fail("edge %d: write of beat %d issued although its read failed (a write needs data from an error-free read)" % (e, k))
                _fail("edge %d: write of beat %d issued before the data of read %d was returned" % (e, k, k))
            if self.rd_rsp_edge[k] >= e:
                _fail("edge %d: write of beat %d accepted in/before the cycle its read data arrived" % (e, k))
            if (r.wdata ^ self.rd_data[k]) & S.lane_mask_bits(beat.strobe, sb):
                _fail("edge %d: write beat %d data 0x%x differs from the read data 0x%x under strobe 0x%x" % (e, k, r.wdata, self.rd_data[k], beat.strobe))
        # ---- closed issue after an error / abort
        closed = (self.close_w if wr else self.close_r) if self.strict else None
        if closed is not None and r.since > closed:
            _fail("edge %d: new %s request presented (since edge %d) after the error response at edge %d" % (e, what, r.since, closed))
        if self.strict and self.abort_edge is not None and r.since > self.abort_edge:
            if self.abort_tol > 0:
                self.abort_tol -= 1
            else:
                _fail("edge %d: new %s request presented (since edge %d) after ABORT was accepted at edge %d" % (e, what, r.since, self.abort_edge))
        # ---- engine specific structure
        if not self.strict:
            pass
        elif not cfg.buffered:
            if self.outstanding() or r.since <= self.last_rsp_edge:
                _fail("edge %d: simple engine presented a %s request while a transaction was still outstanding (exactly one in flight)" % (e, what))
            if wr and self.reads_acc != k + 1 or (not wr and self.writes_acc != k):
                _fail("edge %d: simple engine broke the read/write alternation at beat %d" % (e, k))
        else:
            if not cfg.dual:
                if self.last_req_write is not None and self.last_req_write != wr:
                    if self.outstanding() or r.since <= self.last_rsp_edge:
                        _fail("edge %d: single-port phase switch to %s while the port was not idle (phase changes only when idle)" % (e, what))
                    self.run_len = 0
                self.run_len += 1
                if self.run_len > cfg.burst:
                    _fail("edge %d: %d back-to-back %s requests exceed BURST=%d" % (e, self.run_len, what, cfg.burst))
            if not wr and (self.reads_acc + 1) - self.writes_acc > cfg.fifo_depth:
                _fail("edge %d: read %d issued with %d beats already in flight/buffered (FIFO_DEPTH=%d credit)" % (e, k, self.reads_acc - self.writes_acc, cfg.fifo_depth))
            if wr and self.write_err_beat is not None and k > self.write_err_beat:
                if k - self.write_err_beat > cfg.out_limit - 1:
                    _fail("edge %d: write beat %d accepted after the write error at beat %d (MAX_OUT-1 bound)" % (e, k, self.write_err_beat))
        self.last_req_write = wr
        self.out[r.port].append((wr, k, e))
        if self.strict and len(self.out[r.port]) > cfg.out_limit:
            _fail("edge %d: %d transactions outstanding on port %d, limit %d (SFB2 R6)" % (e, len(self.out[r.port]), r.port, cfg.out_limit))
        if wr:
            self.writes_acc += 1
            self.wstate[k] = "pending"
        else:
            self.reads_acc += 1

    def on_abort(self, e: int, rsp_this_edge: bool) -> None:
        if self.abort_edge is None:
            self.abort_edge = e
            # an abort that lands on the very edge of a response may let ONE more request start (same-edge race;
            # DMA.md only fixes the "next beat boundary" for aborts that precede the response)
            self.abort_tol = 1 if rsp_this_edge else 0

    # ------------------------------------------------------------------ result
    def try_outcome(self) -> Optional[Outcome]:
        if not self.valid:
            return Outcome(False, self.code, 0, 0, {self.code: 0})
        if self.err_first is not None:
            cands = [(self.err_first[1], self.err_first[2])] + self.err_tie
            alts = {}
            for kind, beat in cands:
                if kind == "R":
                    alts[S.E_READ_BUS] = self.plan[beat].src_addr
                else:
                    alts[S.E_WRITE_BUS] = self.plan[beat].dst_addr
            kind, beat = self.err_first[1], self.err_first[2]
            code = S.E_READ_BUS if kind == "R" else S.E_WRITE_BUS
            return Outcome(False, code, alts[code], self.bytes_ok, alts)
        if self.complete:
            return Outcome(True, S.E_NONE, 0, self.bytes_ok)
        if self.abort_edge is not None:
            return Outcome(False, S.E_ABORTED, 0, self.bytes_ok, {S.E_ABORTED: 0})
        return None


# --------------------------------------------------------------------------------------------- DMA register + engine model


class DmaModel:
    def __init__(self, cfg: DmaConfig):
        self.cfg = cfg
        self.reset()

    def reset(self) -> None:
        self.src = self.dst = self.length = 0
        self.ie = 0
        self.ist = 0
        self.done_f = self.err_f = self.abt_f = False
        self.err_code = 0
        self.err_addr = 0
        self.err_alts: Dict[int, int] = {}
        self.bytes_done = 0
        self.act = self.stl = self.xfers = 0
        self.active = False
        self.xfer: Optional[Transfer] = None
        self.n_started = 0
        self.last_outcome: Optional[Outcome] = None
        self.quiet = 0

    # ------------------------------------------------------------------ helpers
    @property
    def irq(self) -> bool:
        return bool(self.ist & self.ie)

    def _status_word(self, state: int) -> int:
        return (state << S.ST_STATE_LSB) | (S.ST_ABORTED if self.abt_f else 0) | (S.ST_ERROR if self.err_f else 0) | \
               (S.ST_DONE if self.done_f else 0) | (S.ST_BUSY if self.active else 0)

    def _expected_states(self, e: Edge) -> Optional[Set[int]]:
        """Legal STATUS.STATE values during the cycle ending at edge e (spec FSM, derived from the bus view)."""
        if not self.active:
            return {S.S_IDLE}
        if e.busy_next is None:
            return None
        xf = self.xfer
        if e.busy_next is False:  # last busy cycle of the transfer
            o = xf.try_outcome()
            if o is None:
                return {S.S_COMPLETE, S.S_ERROR}
            return {S.S_COMPLETE} if o.done else {S.S_ERROR}
        if e.n == xf.start_edge + 1 or not xf.valid:
            return {S.S_VALIDATE}
        cfg = self.cfg
        if cfg.buffered:
            if cfg.dual:
                return {S.S_ISSUE_READ, S.S_ISSUE_WRITE}
            if e.valid and e.valid[0]:
                return {S.S_ISSUE_WRITE if e.pres_write[0] else S.S_ISSUE_READ}
            if xf.out[0]:
                return {S.S_ISSUE_WRITE if xf.out[0][0][0] else S.S_ISSUE_READ}
            return {S.S_ISSUE_READ, S.S_ISSUE_WRITE}
        if e.valid and e.valid[0]:
            return {S.S_ISSUE_WRITE if e.pres_write[0] else S.S_ISSUE_READ}
        if xf.out[0]:
            return {S.S_WAIT_WRITE if xf.out[0][0][0] else S.S_WAIT_READ}
        return set()  # the simple engine always has a request presented or outstanding between VALIDATE and the end

    # ------------------------------------------------------------------ register access prediction
    def reg_expect(self, e: Edge) -> RegExpect:
        r = e.reg
        a = r.addr
        busy = self.active
        cfg = self.cfg
        name = S.REG_NAMES.get(a, "0x%03x" % a)
        if a not in S.ALL_REGS:
            return RegExpect(True, None, what=name)  # unmapped (also every non word-aligned offset)
        if r.write:
            if a == S.CONTROL:
                return RegExpect(bool(r.wdata & S.CTRL_START) and busy, None, what=name)
            if a in (S.SRC_ADDR, S.DST_ADDR, S.LENGTH):
                return RegExpect(busy, None, what=name)
            if a in (S.INT_ENABLE, S.INT_STATUS):
                return RegExpect(False, None, what=name)
            return RegExpect(True, None, what=name)  # read-only register (incl. absent perf registers)
        # ---- reads
        if a == S.CONTROL:
            return RegExpect(False, 0, what=name)  # write-only; reads return 0 (interpretation I3)
        if a == S.STATUS:
            states = self._expected_states(e)
            return RegExpect(False, self._status_word(0), 0xFFFFFFFF & ~(7 << S.ST_STATE_LSB), state_allowed=states, what=name)
        if a == S.SRC_ADDR:
            return RegExpect(False, self.src, what=name)
        if a == S.DST_ADDR:
            return RegExpect(False, self.dst, what=name)
        if a == S.LENGTH:
            return RegExpect(False, self.length, what=name)
        if a == S.BYTES_DONE:
            return RegExpect(False, self.bytes_done, what=name)
        if a == S.INT_ENABLE:
            return RegExpect(False, self.ie, what=name)
        if a == S.INT_STATUS:
            return RegExpect(False, self.ist, what=name)
        if a == S.ERROR_CODE:
            if busy:
                return RegExpect(False, None, what=name)  # not defined while the transfer runs (I1)
            return RegExpect(False, None, rdata_set=set(self.err_alts) if self.err_alts else {self.err_code}, what=name)
        if a == S.ERROR_ADDR:
            if busy:
                return RegExpect(False, None, what=name)
            return RegExpect(False, None, rdata_set=set(self.err_alts.values()) if self.err_alts else {self.err_addr}, what=name)
        if a == S.INFO:
            return RegExpect(False, cfg.info, what=name)
        if a == S.ID:
            return RegExpect(False, S.ID_VALUE, what=name)
        if cfg.perf == 0:
            return RegExpect(True, None, what=name)  # PERF = 0: the registers answer with a bus error
        if a == S.ACTIVE_CYCLES:
            return RegExpect(False, self.act, what=name)
        if a == S.STALL_CYCLES:
            return RegExpect(False, self.stl, what=name)
        return RegExpect(False, self.xfers, what=name)  # TRANSFERS

    def check_reg(self, e: Edge, exp: RegExpect) -> None:
        r = e.reg
        n = e.n
        if r.err != exp.err:
            _fail("edge %d: %s %s rb_err=%d, expected %d (busy=%d)" % (n, "write" if r.write else "read", exp.what, r.err, exp.err, self.active))
        if r.write or exp.err:
            return
        got = r.rdata
        if exp.rdata is not None and (got ^ exp.rdata) & exp.mask:
            _fail("edge %d: read %s = 0x%08x, expected 0x%08x (mask 0x%08x)" % (n, exp.what, got, exp.rdata, exp.mask))
        if exp.rdata_set is not None and got not in exp.rdata_set:
            _fail("edge %d: read %s = 0x%x, expected one of %s" % (n, exp.what, got, sorted(hex(x) for x in exp.rdata_set)))
        if exp.state_allowed is not None:
            st = (got >> S.ST_STATE_LSB) & 7
            if st not in exp.state_allowed:
                _fail("edge %d: STATUS.STATE=%s, expected one of %s" % (n, S.STATE_NAMES[st], sorted(S.STATE_NAMES[x] for x in exp.state_allowed)))
        # pin an ambiguous (same-edge tie) error code / address to the observed value
        if r.addr == S.ERROR_CODE and self.err_alts and got in self.err_alts:
            self.err_alts = {got: self.err_alts[got]}
        elif r.addr == S.ERROR_ADDR and self.err_alts:
            self.err_alts = {c: a for c, a in self.err_alts.items() if a == got}

    # ------------------------------------------------------------------ the edge
    def edge(self, e: Edge) -> None:
        cfg = self.cfg
        n = e.n
        # ---- 1. pre-edge observable state
        if e.busy != self.active:
            _fail("edge %d: busy pin=%d but the model says %s" % (n, e.busy, "busy" if self.active else "idle"))
        if e.irq is not None and e.irq != self.irq:
            _fail("edge %d: irq pin=%d, expected %d (INT_STATUS=%d & INT_ENABLE=%d)" % (n, e.irq, self.irq, self.ist, self.ie))
        if e.bytes_done_pin is not None and e.bytes_done_pin != self.bytes_done:
            _fail("edge %d: bytes_done pin=%d, expected %d" % (n, e.bytes_done_pin, self.bytes_done))
        xf = self.xfer if self.active else None
        any_valid = any(e.valid)
        if any_valid and (xf is None or not xf.valid):
            _fail("edge %d: DMA presents a bus request while %s" % (n, "idle (no transfer started / after reset)" if xf is None else "its descriptor failed validation"))
        if e.fifo_level is not None:
            if not cfg.buffered:
                if e.fifo_level != 0:
                    _fail("edge %d: fifo_level=%d on the simple engine" % (n, e.fifo_level))
            elif xf is not None and e.fifo_level > cfg.fifo_depth:
                _fail("edge %d: fifo_level=%d exceeds FIFO_DEPTH=%d" % (n, e.fifo_level, cfg.fifo_depth))
            elif xf is not None and xf.valid and xf.clean:
                occ = xf.reads_rsp - xf.writes_acc
                if e.fifo_level != occ:
                    _fail("edge %d: fifo_level=%d, expected %d (read responses %d - writes accepted %d)" % (n, e.fifo_level, occ, xf.reads_rsp, xf.writes_acc))
        quiet_pre = xf is not None and not any_valid and xf.outstanding() == 0
        # ---- 2. register access prediction (against pre-edge state)
        exp = None
        if e.reg is not None:
            exp = self.reg_expect(e)
            self.check_reg(e, exp)
        # ---- 3. bus events (responses first: a response frees its slot for a request of the same edge)
        for r in e.rsps:
            if xf is None:
                _fail("edge %d: response handshake while no transfer is active" % n)
            xf.on_rsp(n, r)
        for q in e.reqs:
            if xf is None:
                _fail("edge %d: request handshake while no transfer is active" % n)
            xf.on_req(n, q)
        # ---- 4. register-write side effects
        started = False
        clr_mask = None
        if e.reg is not None and e.reg.write and not exp.err:
            a, d = e.reg.addr, e.reg.wdata
            if a == S.CONTROL:
                if d & S.CTRL_START:
                    started = True  # accepted only when idle (a busy START was predicted to be refused)
                elif d & S.CTRL_ABORT and self.active and xf is not None:
                    xf.on_abort(n, bool(e.rsps))  # (ABORT has no effect when idle: START|ABORT while idle just starts)
            elif a == S.SRC_ADDR:
                self.src = d
            elif a == S.DST_ADDR:
                self.dst = d
            elif a == S.LENGTH:
                self.length = d
            elif a == S.INT_ENABLE:
                self.ie = d & 3
            elif a == S.INT_STATUS:
                clr_mask = d & 3
        # ---- 5. performance counters
        stall = any(v and not r for v, r in zip(e.valid, e.ready))
        if started:
            self.act = self.stl = 0
        else:
            if self.active:
                self.act = (self.act + 1) & 0xFFFFFFFF
            if stall:
                self.stl = (self.stl + 1) & 0xFFFFFFFF
        # ---- 6. end of transfer?
        set_bits = 0
        terminal = False
        if self.active and not started and e.busy_next is False:
            terminal = True
            if not quiet_pre:
                _fail("edge %d: BUSY fell while a bus request was presented or a response was still outstanding" % n)
            if not xf.stop_met():
                if xf.err_first is not None and xf.err_first[1] == "R":
                    _fail("edge %d: transfer ended after the read error at beat %d but the beats before it were not all written (BYTES_DONE rule)" % (n, xf.err_first[2]))
                _fail("edge %d: transfer ended early: %d of %d beats written, no error and no abort" % (n, xf.n_ok_writes, xf.n))
            o = xf.try_outcome()
            if o is None:
                _fail("edge %d: transfer ended with no outcome" % n)
            if e.ev_done is not None and e.ev_done != o.done:
                _fail("edge %d: ev_done=%d at the end of a transfer that %s" % (n, e.ev_done, "completed" if o.done else "failed (%s)" % S.ERROR_NAMES[o.code]))
            self.bytes_done = o.bytes_done
            self.err_code, self.err_addr, self.err_alts = o.code, o.addr, dict(o.alts)
            if o.done:
                self.done_f = True
                set_bits |= S.INT_DONE
                self.xfers = (self.xfers + 1) & 0xFFFFFFFF
            else:
                self.err_f = True
                self.abt_f = o.code == S.E_ABORTED
                set_bits |= S.INT_ERROR
            self.last_outcome = o
            self.active = False
            self.xfer = None
        elif e.ev_done and e.busy_next is not None:
            _fail("edge %d: ev_done pulse without the end of a completed transfer" % n)
        # ---- 7. bytes_done tracks acknowledged writes while running; START clears everything
        if self.active and xf is not None and not terminal:
            self.bytes_done = xf.bytes_ok
        if started:
            self.done_f = self.err_f = self.abt_f = False
            self.err_code = self.err_addr = 0
            self.err_alts = {}
            self.bytes_done = 0
            self.active = True
            self.n_started += 1
            self.xfer = Transfer(cfg, self.src, self.dst, self.length, n)
            self.quiet = 0
            if e.busy_next is False:
                _fail("edge %d: START accepted but BUSY did not rise (software would see !BUSY with no outcome)" % n)
        # ---- 8. interrupt status: set wins over a same-edge write-one-to-clear
        if clr_mask is not None:
            self.ist &= ~clr_mask
        self.ist |= set_bits
        # ---- 9. liveness inside the model
        if self.active and not terminal and not started:
            if quiet_pre:
                self.quiet += 1
                if self.quiet > HANG_CYCLES:
                    _fail("edge %d: no bus activity for %d cycles and the transfer has not finished (%s)" % (
                        n, self.quiet, "work is done" if xf.stop_met() else "%d/%d beats written" % (xf.n_ok_writes, xf.n)))
            else:
                self.quiet = 0
