"""Reference model of ``hpc_vector_array`` (functional + documented timing), written from
rtl/hpc_m03_vector_array/README.md, docs/ARRAY_INTERFACE.md and docs/REDUCTION.md.

Functional contract
  * command k consumes exactly ceil(vl_k / N) operand beats; element e -> beat e // N, lane e % N;
  * active(e) = legal & (e < vl) & (!vm | mask_g[l]); inactive positions read back data 0 / flags 0 / mask 0 and
    never contribute to flags, count or a reduction;
  * broadcast bits {c, b, a} replace that operand of every element by the command scalar;
  * elementwise commands produce one result beat per operand beat (also illegal ones: mask 0 / data 0 / flags 0);
    reductions and vl = 0 commands produce no result beat;
  * one completion record per command, in command order: tid, OR of active-element flags (+ every reduction add
    for reductions), illegal, active-element count, red, reduction result;
  * reduction (docs/REDUCTION.md section 1): per beat a pairwise tree over lane index whose absent leaves are
    skipped (never replaced by an identity), then ``acc = scalar; for g: if S_g present: acc = acc + S_g``, every
    add being an FP32 add under the command's rounding mode.

Timing helpers (docs/PERFORMANCE.md 2.1, REDUCTION.md section 4) are provided for the directed latency tests.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

from . import vec_fp32 as F
from .vec_lane import LaneParams


@dataclass(frozen=True)
class ArrayParams:
    n: int = 2
    vl_w: int = 16
    tid_w: int = 8
    red_en: bool = True
    red_lat: int = 3
    lane: LaneParams = LaneParams()

    @property
    def lat(self) -> LaneParams:
        return self.lane


@dataclass(frozen=True)
class Cmd:
    op: int
    rm: int
    vl: int
    vm: int = 0
    bcast: int = 0
    scalar: int = 0
    red: int = 0
    tid: int = 0


@dataclass
class Beat:
    """One operand beat (N elements): lists of N 32-bit words and the N-bit mask."""
    a: List[int]
    b: List[int]
    c: List[int]
    mask: int = 0


@dataclass
class ExpBeat:
    data: List[int]
    flags: List[int]
    mask: int
    tid: int
    beat: int
    last: int


@dataclass
class ExpCpl:
    tid: int
    flags: int
    illegal: int
    count: int
    red: int
    result: int


@dataclass
class Expected:
    beats: List[ExpBeat] = field(default_factory=list)
    cpl: Optional[ExpCpl] = None
    n_active_elems: int = 0
    classes: List[str] = field(default_factory=list)


def nbeats(vl: int, n: int) -> int:
    return (vl + n - 1) // n


def cmd_legal(c: Cmd, p: ArrayParams) -> bool:
    """docs/ARRAY_INTERFACE.md 4.3."""
    if c.red:
        return bool(p.red_en and (0 <= c.op <= 7) and F.rm_legal(c.rm) and c.bcast == 0)
    return F.op_legal(c.op, c.rm, p.lane.en_fcmp, p.lane.en_int)


def elem_operands(c: Cmd, beat: Beat, lane: int) -> Tuple[int, int, int]:
    a = c.scalar if c.bcast & 1 else beat.a[lane]
    b = c.scalar if c.bcast & 2 else beat.b[lane]
    cc = c.scalar if c.bcast & 4 else beat.c[lane]
    return a & F.M32, b & F.M32, cc & F.M32


def active_mask(c: Cmd, beat: Beat, g: int, n: int, legal: bool) -> int:
    m = 0
    for l in range(n):
        e = g * n + l
        if legal and e < c.vl and (not c.vm or (beat.mask >> l) & 1):
            m |= 1 << l
    return m


def reduce_beat(vals: Sequence[Optional[int]], rm: int) -> Tuple[Optional[int], int]:
    """Pairwise tree over lane index with absent leaves skipped.  Returns (S or None, OR of add flags)."""
    lst = list(vals)
    fl = 0
    while len(lst) > 1:
        nxt: List[Optional[int]] = []
        for i in range(0, len(lst), 2):
            l, r = lst[i], lst[i + 1]
            if l is not None and r is not None:
                s, f = F.fadd(l, r, rm)
                fl |= f
                nxt.append(s)
            else:
                nxt.append(l if l is not None else r)
        lst = nxt
    return lst[0], fl


def expected(c: Cmd, beats: Sequence[Beat], p: ArrayParams) -> Expected:
    n = p.n
    legal = cmd_legal(c, p)
    nb = nbeats(c.vl, n)
    assert len(beats) == nb, "command needs exactly ceil(vl/N) = %d operand beats, got %d" % (nb, len(beats))
    out = Expected()
    cmd_flags = 0
    count = 0
    acc = c.scalar & F.M32
    for g in range(nb):
        b = beats[g]
        am = active_mask(c, b, g, n, legal)
        data, flags = [0] * n, [0] * n
        xs: List[Optional[int]] = [None] * n
        for l in range(n):
            if (am >> l) & 1:
                a, bb, cc = elem_operands(c, b, l)
                r, f, ill = F.exec_op(c.op, a, bb, cc, c.rm, p.lane.en_fcmp, p.lane.en_int)
                assert not ill
                data[l], flags[l] = r, f
                xs[l] = r
                cmd_flags |= f
                count += 1
                out.classes.append(F.value_class(a))
        if c.red:
            if legal:
                s, f = reduce_beat(xs, c.rm)
                cmd_flags |= f
                if s is not None:
                    acc, f2 = F.fadd(acc, s, c.rm)
                    cmd_flags |= f2
        else:
            out.beats.append(ExpBeat(data, flags, am, c.tid, g, int(g == nb - 1)))
    out.n_active_elems = count
    result = acc if (c.red and legal) else 0
    out.cpl = ExpCpl(c.tid, cmd_flags if legal else 0, int(not legal), count if legal else 0, int(c.red), result)
    return out


# ------------------------------------------------------------------------------------- documented timing
def _log2(n: int) -> int:
    return n.bit_length() - 1


def elementwise_result_latency(op: int, rm: int, p: ArrayParams) -> int:
    """Operand-beat handshake edge -> result-beat handshake edge (nothing stalling): lane latency (LAT_unit + 1)
    plus one collector / output-register cycle (PERFORMANCE.md 2.1: 3 / 5 / 6 cycles for FMV / FADD, FMUL / FMADD)."""
    return p.lane.unit_latency(op) + 2


def reduction_latency(op: int, p: ArrayParams) -> int:
    """Last operand beat accepted -> completion handed over: (LAT_unit + 1) + TL + RED_LAT + 1 with
    TL = 1 + log2(N) * RED_LAT (REDUCTION.md section 4)."""
    tl = 1 + _log2(p.n) * p.red_lat
    return (p.lane.unit_latency(op) + 1) + tl + p.red_lat + 1
