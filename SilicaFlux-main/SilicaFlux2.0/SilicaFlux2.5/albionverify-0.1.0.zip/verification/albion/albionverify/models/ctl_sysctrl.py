"""Reference model of ``cc_sysctrl`` + its reset chain (SYSCTRL page, reset generator, POR/SYS domains).

Written from MEMORY_MAP.md (block ``cc_sysctrl``), HW_SW_INTERFACE.md, 01_ARCHITECTURE.md section 4 (clock and reset),
03_BOOT.md (stage / reset-cause semantics) and 04_INTERRUPTS.md (watchdog -> reset generator) -- NOT from the RTL.

The model covers the page AND the parts of the top level that make the block observable (the verification wrapper
ctl_sysctrl_wrap.sv replicates exactly that part of silicaflux_control_core):
  * ``rst_ni`` -> 2-flop reset synchroniser (async assert, sync release) -> POR domain reset (``por_rst_n``)
  * ``sys_reset_req`` (the stretched reset pulse) -> second synchroniser together with POR -> SYS domain reset (``sys_rst_n``)
  * ``boot_mode_i`` and ``host_rst_req_i`` pass 2-flop synchronisers (clocked by clk, reset by the POR domain)

Documented behaviour used
  POR domain (survives soft / watchdog / host resets): RESET_CAUSE (W1C, sticky: POR/SOFT/WDT/HOST), RESET_COUNT,
  SCRATCH0..3, the reset stretcher.  SYS domain: BOOT_STAGE, BOOT_STATUS, HOST_STATUS, FW_VERSION, TEST_CTRL.
  Reset generator: SOFT_RESET write of 0x5AFEC0DE, a watchdog reset request (level) or the rising edge of the
  synchronised host request starts a CC_RESET_STRETCH (16) cycle pulse on ``sys_reset_req``; the cause is OR-ed into
  RESET_CAUSE and RESET_COUNT increments.  Any other SOFT_RESET value is refused (err, no reset).
  Interpretations for what the documents do not say (see docs/ctl_verification_plan.md): A-3 requests that arrive while a
  pulse is active are merged into it (their cause is not recorded, they are not counted); A-4 a cause set in the same
  cycle as a W1C of the same bit wins; A-5 RESET_CAUSE after POR = POR (bit 0) only; A-1 read of a WO register is refused;
  A-6 TEST_CTRL[29:16] are unspecified (not compared).
"""
from __future__ import annotations

from typing import Dict, Optional

from . import ctl_spec as S
from .ctl_base import MASK32, RegModel

A = S.SYSCTRL
RO = ("ID", "HW_VERSION", "MAP_VERSION", "FEATURES", "ROM_BYTES", "IMEM_BYTES", "DMEM_BYTES", "RESET_COUNT", "BOOT_MODE")
RW = ("BOOT_STAGE", "BOOT_STATUS", "HOST_STATUS", "FW_VERSION", "SCRATCH0", "SCRATCH1", "SCRATCH2", "SCRATCH3", "TEST_CTRL")
KIND = {}
for _n in RO:
    KIND[A[_n]] = "ro"
for _n in RW:
    KIND[A[_n]] = "rw"
KIND[A["RESET_CAUSE"]] = "w1c"
KIND[A["SOFT_RESET"]] = "wo"
SCRATCH = [A["SCRATCH0"], A["SCRATCH1"], A["SCRATCH2"], A["SCRATCH3"]]
NAME = {v: k for k, v in A.items()}


class SysctrlModel(RegModel):
    def __init__(self, features=S.SYSCTRL_FEATURES_TOP, rom_bytes=S.BOOTROM_SIZE, imem_bytes=S.IMEM_SIZE, dmem_bytes=S.DMEM_SIZE,
                 stretch: int = S.RESET_STRETCH):
        self.features, self.rom, self.imem, self.dmem, self.stretch = features, rom_bytes, imem_bytes, dmem_bytes, stretch
        self.por_reset()
        self.s_por = [0, 0]  # unknown power-up: first cycles are in reset anyway
        self.s_sys = [0, 0]
        self.sys_reset()

    # ------------------------------------------------------------------ state
    def por_reset(self) -> None:
        self.cause = S.RESET_CAUSE["POR"]
        self.rcount = 0
        self.scratch = [0, 0, 0, 0]
        self.str = 0
        self.host_prev = 0
        self.s_bm = [[0, 0], [0, 0]]  # two boot-mode bits, two stages each (stage 0 first)
        self.s_host = [0, 0]

    def sys_reset(self) -> None:
        self.stage = 0
        self.bstat = 0
        self.hstat = 0
        self.fwver = 0
        self.test = 0

    def reset(self) -> None:  # full reset (interface of the base class)
        self.por_reset()
        self.sys_reset()

    # ------------------------------------------------------------------ derived levels
    @property
    def boot_mode(self) -> int:
        return (self.s_bm[1][1] << 1) | self.s_bm[0][1]

    @property
    def host_req(self) -> int:  # synchronised host reset request
        return self.s_host[1]

    @property
    def sys_reset_req(self) -> int:
        return int(self.str != 0)

    def soft_req(self, inp) -> bool:
        return bool(inp["sel"] and inp["we"] and inp["addr"] == A["SOFT_RESET"] and (inp["wdata"] & MASK32) == S.SOFT_RESET_KEY)

    # ------------------------------------------------------------------ combinational
    def _read(self, addr: int) -> int:
        n = NAME[addr]
        if n == "ID":
            return S.SYSCTRL_ID
        if n == "HW_VERSION":
            return S.SYSCTRL_HW_VERSION
        if n == "MAP_VERSION":
            return S.MAP_VERSION
        if n == "FEATURES":
            return self.features
        if n == "ROM_BYTES":
            return self.rom
        if n == "IMEM_BYTES":
            return self.imem
        if n == "DMEM_BYTES":
            return self.dmem
        if n == "RESET_CAUSE":
            return self.cause
        if n == "RESET_COUNT":
            return self.rcount
        if n == "BOOT_MODE":
            return self.boot_mode
        if n == "BOOT_STAGE":
            return self.stage
        if n == "BOOT_STATUS":
            return self.bstat
        if n == "HOST_STATUS":
            return self.hstat
        if n == "FW_VERSION":
            return self.fwver
        if n.startswith("SCRATCH"):
            return self.scratch[int(n[-1])]
        if n == "TEST_CTRL":
            return self.test
        return 0

    def rdata_mask(self, addr: int) -> int:
        return 0xC000_FFFF if addr == A["TEST_CTRL"] else MASK32  # TEST_CTRL[29:16] unspecified (A-6)

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:
        addr, we = inp["addr"], inp["we"]
        k = KIND.get(addr) if not addr & 3 else None
        if k is None:
            err, rdata = 1, 0
        elif we:
            err = 1 if k == "ro" else 0
            if addr == A["SOFT_RESET"]:
                err = 0 if (inp["wdata"] & MASK32) == S.SOFT_RESET_KEY else 1
            rdata = None
        else:
            err = 1 if k == "wo" else 0
            rdata = 0 if err else self._read(addr)
        return {
            "rdata": rdata, "err": err,
            "sys_reset_req": self.sys_reset_req, "host_ready": self.hstat & 1, "cmdproc_ready": (self.hstat >> 1) & 1,
            "test_done": (self.test >> 31) & 1, "test_fail": (self.test >> 30) & 1, "test_code": self.test & 0xFFFF,
            "por_rst_n": self.s_por[1], "sys_rst_n": self.s_sys[1],
        }

    # ------------------------------------------------------------------ clock edge (POR / SYS domains separate)
    def clock(self, inp: Dict[str, int]) -> None:
        pass  # see step(): the two domains need their own reset levels

    def step(self, inp: Dict[str, int], resets: Dict[str, bool]) -> Dict[str, Optional[int]]:
        # asynchronous assertion of the external reset clears the synchronisers at once
        if resets.get("por_in"):
            self.s_por = [0, 0]
        por_n = self.s_por[1]
        if not por_n:
            self.por_reset()
        sys_in = por_n and not self.sys_reset_req  # input of the SYS synchroniser (comb. of POR state)
        if not sys_in:
            self.s_sys = [0, 0]
        sys_n = self.s_sys[1]
        if not sys_n:
            self.sys_reset()
        out = self.evaluate(inp)
        # ----- edge: every flop takes its next value from the pre-edge state
        wdt = inp.get("wdt_req", 0)
        soft = self.soft_req(inp)
        host_edge = bool(self.host_req and not self.host_prev)
        any_req = bool(soft or wdt or host_edge)
        nxt = {}
        if por_n:
            n_str, n_count = self.str, self.rcount
            if self.str != 0:
                n_str = self.str - 1
            elif any_req:
                n_str, n_count = self.stretch, self.rcount + 1
            c = self.cause
            if inp["sel"] and inp["we"] and inp["addr"] == A["RESET_CAUSE"]:
                c &= ~(inp["wdata"] & 0xF)
            if self.str == 0 and any_req:
                c |= (host_edge << 3) | ((1 if wdt else 0) << 2) | ((1 if soft else 0) << 1)
            nxt["cause"], nxt["str"], nxt["rcount"] = c & 0xF, n_str, n_count & MASK32
            if inp["sel"] and inp["we"] and inp["addr"] in SCRATCH:
                sc = list(self.scratch)
                sc[SCRATCH.index(inp["addr"])] = inp["wdata"] & MASK32
                nxt["scratch"] = sc
            nxt["host_prev"] = self.host_req
            nxt["s_bm"] = [[inp["boot_mode_i"] & 1, self.s_bm[0][0]], [(inp["boot_mode_i"] >> 1) & 1, self.s_bm[1][0]]]
            nxt["s_host"] = [inp["host_rst_req_i"] & 1, self.s_host[0]]
        if sys_n and inp["sel"] and inp["we"] and not (inp["addr"] & 3):
            a, d = inp["addr"], inp["wdata"] & MASK32
            if a == A["BOOT_STAGE"]:
                nxt["stage"] = d & 0xFF
            elif a == A["BOOT_STATUS"]:
                nxt["bstat"] = d
            elif a == A["HOST_STATUS"]:
                nxt["hstat"] = d & 0xF
            elif a == A["FW_VERSION"]:
                nxt["fwver"] = d
            elif a == A["TEST_CTRL"]:
                nxt["test"] = d
        # reset synchronisers: shift a 1 in unless their asynchronous clear is active
        n_por = [0, 0] if resets.get("por_in") else [1, self.s_por[0]]
        n_sys = [1, self.s_sys[0]] if sys_in else [0, 0]
        for k, v in nxt.items():
            setattr(self, k, v)
        self.s_por, self.s_sys = n_por, n_sys
        return out
