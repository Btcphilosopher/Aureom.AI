"""Reference model of ``cc_perf`` (ControlCore performance counters).

Written from MEMORY_MAP.md (block ``cc_perf``) and 05_ACCELERATORS.md section 4 -- NOT from the RTL.
  CTRL RW: [0] FREEZE (reads back), write [1] = 1 clears all counters.  INFO RO [7:0] = number of event counters.
  CYCLE_LO / CYCLE_HI RO: free-running 64-bit cycle counter.  CNT0 + 4i RO: 32-bit saturating event counter i.
  Counting: an event input counts every cycle it is high, or (for bits set in the EDGE parameter, used for interrupt
  lines) once per rising edge.  FREEZE holds every counter (consistent multi-register read); the clear wins over a
  same-cycle event and also clears the cycle counter ("clear all counters").  FREEZE written 1 takes effect the cycle after.
  Interpretations: A-11 the clear also works while frozen; A-12 the edge detector keeps tracking the input while frozen.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from . import ctl_spec as S
from .ctl_base import MASK32, RegModel

A = S.PERF


class PerfModel(RegModel):
    def __init__(self, nev: int = 20, edge: int = 0):
        self.nev, self.edge = nev, edge
        self.reset()

    def reset(self) -> None:
        self.frz = 0
        self.cyc = 0
        self.ev_prev = 0
        self.cnt: List[int] = [0] * self.nev

    def kind(self, addr: int) -> str:
        if addr & 3:
            return "none"
        if addr == A["CTRL"]:
            return "rw"
        if addr in (A["INFO"], A["CYCLE_LO"], A["CYCLE_HI"]):
            return "ro"
        if A["CNT0"] <= addr < A["CNT0"] + 4 * self.nev:
            return "ro"
        return "none"

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:
        addr, we = inp["addr"], inp["we"]
        k = self.kind(addr)
        if k == "none":
            return {"rdata": 0, "err": 1}
        if we:
            return {"rdata": None, "err": 1 if k == "ro" else 0}
        if addr == A["CTRL"]:
            v = self.frz
        elif addr == A["INFO"]:
            v = self.nev
        elif addr == A["CYCLE_LO"]:
            v = self.cyc & MASK32
        elif addr == A["CYCLE_HI"]:
            v = (self.cyc >> 32) & MASK32
        else:
            v = self.cnt[(addr - A["CNT0"]) >> 2]
        return {"rdata": v, "err": 0}

    def clock(self, inp: Dict[str, int]) -> None:
        ev = inp["ev"]
        wr_ctl = bool(inp["sel"] and inp["we"] and inp["addr"] == A["CTRL"])
        clr = wr_ctl and bool((inp["wdata"] >> 1) & 1)
        if clr:
            self.cyc = 0
            self.cnt = [0] * self.nev
        elif not self.frz:
            self.cyc = (self.cyc + 1) & ((1 << 64) - 1)
            for i in range(self.nev):
                rising_only = (self.edge >> i) & 1
                inc = (ev >> i) & 1 and not (rising_only and (self.ev_prev >> i) & 1)
                if inc and self.cnt[i] != MASK32:
                    self.cnt[i] += 1
        if wr_ctl:
            self.frz = inp["wdata"] & 1
        self.ev_prev = ev
