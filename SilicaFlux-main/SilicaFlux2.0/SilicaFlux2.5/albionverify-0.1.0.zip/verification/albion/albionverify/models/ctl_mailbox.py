"""Register-level reference model of ``cc_mailbox`` (host <-> firmware mailbox + diagnostic console FIFO).

Written from rtl/controlcore/docs/MEMORY_MAP.md (block ``cc_mailbox``), HW_SW_INTERFACE.md (pins ``host_irq_o``,
``diag_valid_o`` / ``diag_char_o``), 04_INTERRUPTS.md (HOST source = H2F_PEND), 09_LIMITATIONS.md (console FIFO keeps
the first 256 unread characters, later ones dropped, OVF) -- NOT from the RTL.

Documented behaviour used
  * H2F_MSG0..7 (0x000..0x01C) and F2H_MSG0..7 (0x020..0x03C): plain 32-bit RW words.
  * DB_STATUS RO: [0] H2F_PEND [1] F2H_PEND.
  * H2F_RING / F2H_RING (WO): set the pending flag, the written value is latched in H2F_CODE / F2H_CODE (RO);
    RING_COUNT RO = {F2H rings[15:0], H2F rings[15:0]}, wrapping.
  * H2F_ACK / F2H_ACK (WO): clear the pending flag.
  * DIAG_TX (WO): [7:0] pushed into a DEPTH-entry FIFO, dropped when full and OVF set.  DIAG_RX (RO): [7:0] head
    character, [8] VALID, no side effect.  DIAG_POP (WO) pops.  DIAG_STATUS (RW): [8:0] level, [16] OVF (W1C).
  * pins: irq_h2f = H2F_PEND, host_irq = F2H_PEND, diag_valid/diag_char mirror every DIAG_TX write.
  * refused accesses (err): unmapped offsets, writes to RO registers.  Interpretation (spec silent, see
    docs/ctl_verification_plan.md A-1): a READ of a write-only register is refused too (err, rdata 0).
  * Reset values: all zero (the doc's reset column is blank for these registers; interpretation A-2).
"""
from __future__ import annotations

from collections import deque
from typing import Deque, Dict, List, Optional

from . import ctl_spec as S
from .ctl_base import MASK32, RegModel

A = S.MAILBOX


class MailboxModel(RegModel):
    def __init__(self, depth: int = S.DIAG_DEPTH_DEFAULT):
        self.depth = depth
        self.reset()

    def reset(self) -> None:
        self.h2f: List[int] = [0] * 8
        self.f2h: List[int] = [0] * 8
        self.h2f_pend = 0
        self.f2h_pend = 0
        self.h2f_code = 0
        self.f2h_code = 0
        self.h2f_cnt = 0
        self.f2h_cnt = 0
        self.ovf = 0
        self.fifo: Deque[int] = deque()

    # ------------------------------------------------------------------ classification of an offset
    @staticmethod
    def kind(addr: int) -> str:
        """'rw', 'ro', 'wo', 'w1c' (DIAG_STATUS is RW with a W1C flag) or 'none'."""
        if addr & 3:
            return "none"
        if 0x000 <= addr <= 0x03C:
            return "rw"
        if addr in (A["DB_STATUS"], A["H2F_CODE"], A["F2H_CODE"], A["RING_COUNT"], A["DIAG_RX"]):
            return "ro"
        if addr in (A["H2F_RING"], A["H2F_ACK"], A["F2H_RING"], A["F2H_ACK"], A["DIAG_TX"], A["DIAG_POP"]):
            return "wo"
        if addr == A["DIAG_STATUS"]:
            return "rw"
        return "none"

    def level(self) -> int:
        return len(self.fifo)

    def _read(self, addr: int) -> int:
        if 0x000 <= addr <= 0x01C:
            return self.h2f[addr >> 2]
        if 0x020 <= addr <= 0x03C:
            return self.f2h[(addr - 0x20) >> 2]
        if addr == A["DB_STATUS"]:
            return (self.f2h_pend << 1) | self.h2f_pend
        if addr == A["H2F_CODE"]:
            return self.h2f_code
        if addr == A["F2H_CODE"]:
            return self.f2h_code
        if addr == A["RING_COUNT"]:
            return ((self.f2h_cnt & 0xFFFF) << 16) | (self.h2f_cnt & 0xFFFF)
        if addr == A["DIAG_RX"]:
            return (0x100 | self.fifo[0]) if self.fifo else 0
        if addr == A["DIAG_STATUS"]:
            return (self.ovf << 16) | self.level()
        return 0

    def evaluate(self, inp: Dict[str, int]) -> Dict[str, Optional[int]]:
        addr, we, sel = inp["addr"], inp["we"], inp["sel"]
        k = self.kind(addr)
        if k == "none":
            err, rdata = 1, 0
        elif we:
            err = 1 if k == "ro" else 0
            rdata = None  # write: rdata is not part of the contract (the bridge returns 0)
        else:
            err = 1 if k == "wo" else 0
            rdata = 0 if err else self._read(addr)
        wr_tx = bool(sel and we and addr == A["DIAG_TX"])
        return {
            "rdata": rdata, "err": err, "irq_h2f": self.h2f_pend, "host_irq": self.f2h_pend,
            "diag_valid": int(wr_tx), "diag_char": (inp["wdata"] & 0xFF) if wr_tx else None,
        }

    def clock(self, inp: Dict[str, int]) -> None:
        if not (inp["sel"] and inp["we"]):
            return
        addr, d = inp["addr"], inp["wdata"] & MASK32
        k = self.kind(addr)
        if k in ("none", "ro"):
            return  # refused: no side effect
        if 0x000 <= addr <= 0x01C:
            self.h2f[addr >> 2] = d
        elif 0x020 <= addr <= 0x03C:
            self.f2h[(addr - 0x20) >> 2] = d
        elif addr == A["H2F_RING"]:
            self.h2f_pend, self.h2f_code, self.h2f_cnt = 1, d, (self.h2f_cnt + 1) & 0xFFFF
        elif addr == A["F2H_RING"]:
            self.f2h_pend, self.f2h_code, self.f2h_cnt = 1, d, (self.f2h_cnt + 1) & 0xFFFF
        elif addr == A["H2F_ACK"]:
            self.h2f_pend = 0
        elif addr == A["F2H_ACK"]:
            self.f2h_pend = 0
        elif addr == A["DIAG_TX"]:
            if len(self.fifo) >= self.depth:
                self.ovf = 1
            else:
                self.fifo.append(d & 0xFF)
        elif addr == A["DIAG_POP"]:
            if self.fifo:
                self.fifo.popleft()
        elif addr == A["DIAG_STATUS"]:
            if (d >> 16) & 1:
                self.ovf = 0
