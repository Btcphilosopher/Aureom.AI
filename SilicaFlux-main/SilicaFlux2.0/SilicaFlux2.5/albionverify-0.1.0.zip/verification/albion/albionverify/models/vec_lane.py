"""Cycle-level reference model of one ``hpc_vector_lane`` (interface + in-order retirement), from the documented
contract (rtl/hpc_m03_vector_array docs, lane header comments) -- not from the RTL structure.

Contract modelled
  * one operation accepted per cycle when ``in_valid & in_ready``; ``in_ready`` is a function of registered
    state only: it is low during reset and during the first cycle after reset de-assertion, and low whenever all
    ROB_DEPTH completion slots are occupied.
  * an *enabled* operation (lane_en = 1) takes one slot at acceptance.  A *disabled* one (lane_en = 0) is consumed
    by the handshake without a slot, without a result and without flags.
  * latency: an operation on unit u (latency parameter LAT_u) is first presented LAT_u + 1 cycles after the cycle
    in which it was accepted (array docs: "lane latency (LAT_unit + 1)").  An illegal operation completes at once
    and is presented one cycle after acceptance (lane header: "complete at once ... in order").
  * retirement is strictly in acceptance order through the ROB: out_valid is high exactly while the oldest
    outstanding operation has completed; it is held (with a stable payload) until ``out_ready``.
  * a result of an illegal operation is 0 with flags 0 and out_illegal = 1.  While out_valid = 0 every payload
    output (result, flags, tag, illegal) is 0.  busy = at least one slot occupied.
  * perf event pulses: accept (enabled op accepted), retire, pipe_stall (valid & init & ~ready), backpressure
    (out_valid & ~out_ready), illegal (illegal op accepted), masked (disabled op consumed).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Deque, Optional, Tuple

from . import vec_fp32 as F


@dataclass(frozen=True)
class LaneParams:
    rob_depth: int = 8
    lat_fadd: int = 3
    lat_fmul: int = 3
    lat_fma: int = 4
    lat_misc: int = 1
    lat_imul: int = 2
    en_fcmp: bool = True
    en_int: bool = True
    tag_w: int = 8

    def unit_latency(self, op: int) -> int:
        if op in (F.OP_FADD, F.OP_FSUB):
            return self.lat_fadd
        if op == F.OP_FMUL:
            return self.lat_fmul
        if op in F.FMA_OPS:
            return self.lat_fma
        if op == F.OP_IMUL:
            return self.lat_imul
        return self.lat_misc  # FMV, FMIN, FMAX, FEQ, FLT, FLE, IADD

    def visible_latency(self, op: int, rm: int) -> int:
        """Cycles from the acceptance cycle to the first cycle the result is presented (no earlier op in front)."""
        if not F.op_legal(op, rm, self.en_fcmp, self.en_int):
            return 1
        return self.unit_latency(op) + 1


@dataclass
class LaneOp:
    op: int
    a: int
    b: int
    c: int
    rm: int
    tag: int
    en: bool = True


@dataclass
class _Entry:
    done_at: int
    result: int
    flags: int
    illegal: bool
    tag: int
    op: int
    unit_lat: int


@dataclass
class LaneOutputs:
    in_ready: int
    out_valid: int
    out_result: int
    out_flags: int
    out_tag: int
    out_illegal: int
    busy: int


class LaneModel:
    """Lock-step prediction of the lane.  Call ``outputs(t)`` for the values the DUT must show in sample cycle t,
    then ``edge(t, ...)`` with the handshake facts of that cycle."""

    def __init__(self, p: LaneParams):
        self.p = p
        self.init = False
        self.q: Deque[_Entry] = deque()
        self.n_accept = self.n_retire = 0

    def reset(self) -> None:
        self.init = False
        self.q.clear()

    # -- what the DUT must present in cycle t (a function of registered state only)
    def outputs(self, t: int) -> LaneOutputs:
        ready = int(self.init and len(self.q) < self.p.rob_depth)
        if self.q and self.q[0].done_at <= t:
            e = self.q[0]
            return LaneOutputs(ready, 1, 0 if e.illegal else e.result, 0 if e.illegal else e.flags, e.tag, int(e.illegal), 1)
        return LaneOutputs(ready, 0, 0, 0, 0, 0, int(len(self.q) != 0))

    def events(self, t: int, in_valid: int, lane_en: int, op: Optional[LaneOp], out_ready: int) -> dict:
        """Expected combinational event pulses in cycle t (before applying the edge)."""
        o = self.outputs(t)
        hs = bool(in_valid and o.in_ready)
        illegal = bool(hs and lane_en and op is not None and not F.op_legal(op.op, op.rm, self.p.en_fcmp, self.p.en_int))
        return {
            "accept": int(hs and lane_en),
            "retire": int(o.out_valid and out_ready),
            "pipe_stall": int(in_valid and self.init and not o.in_ready),
            "backpressure": int(o.out_valid and not out_ready),
            "illegal": int(illegal),
            "masked": int(hs and not lane_en),
        }

    # -- state update at the rising edge ending cycle t
    def edge(self, t: int, in_valid: int, op: Optional[LaneOp], out_ready: int) -> None:
        o = self.outputs(t)
        retire = bool(o.out_valid and out_ready)
        accept = bool(in_valid and o.in_ready and op is not None and op.en)
        if retire:
            self.q.popleft()
            self.n_retire += 1
        if accept:
            res, fl, ill = F.exec_op(op.op, op.a, op.b, op.c, op.rm, self.p.en_fcmp, self.p.en_int)
            self.q.append(_Entry(t + self.p.visible_latency(op.op, op.rm), res, fl, ill, op.tag & ((1 << self.p.tag_w) - 1), op.op, self.p.unit_latency(op.op)))
            self.n_accept += 1
        self.init = True

    @property
    def occupancy(self) -> int:
        return len(self.q)
