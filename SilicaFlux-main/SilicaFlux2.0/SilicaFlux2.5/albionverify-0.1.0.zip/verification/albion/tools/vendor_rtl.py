#!/usr/bin/env python3
"""Vendor the exact RTL under test from the repository archives into verification/albion/rtl/.

  * every source archive is pinned by SHA-256 (the run aborts if the archive on disk differs);
  * for each DUT top module the dependency closure is computed (same engine as the audit) and only
    those files are copied;
  * rtl/MANIFEST.json records, per file, the SHA-256 and where it came from, plus the ordered file
    list and include directories of every DUT -- the builder never re-discovers sources, so a build is
    a pure function of the manifest;
  * documentation (*.md) of each project is copied next to the RTL: the independent reference models
    are written from these specs, not from the RTL.

Usage:  python tools/vendor_rtl.py --repo-root /path/to/Aureom.AI [--check]
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))

from albionverify.audit import corpus as cm  # noqa: E402
from albionverify.audit import exec_checks as ec  # noqa: E402

SPEC_PATH = ROOT / "rtl" / "VENDOR_SPEC.json"
OUT_DIR = ROOT / "rtl"


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def build(repo_root: Path, check_only: bool = False) -> int:
    spec = json.loads(SPEC_PATH.read_text())
    manifest = {"schema": 1, "generated_by": "tools/vendor_rtl.py", "projects": {}, "duts": {}, "files": {}}
    rc = 0
    tmp_root = Path(tempfile.mkdtemp(prefix="albion_vendor_"))
    try:
        for proj in spec["projects"]:
            name = proj["project"]
            apath = repo_root / proj["archive"]
            if not apath.exists():
                print("ERROR: archive missing: %s" % apath)
                rc = 1
                continue
            data = apath.read_bytes()
            sha = hashlib.sha256(data).hexdigest()
            if proj.get("archive_sha256") and proj["archive_sha256"] != sha:
                print("ERROR: archive %s changed: pinned %s, found %s" % (proj["archive"], proj["archive_sha256"][:12], sha[:12]))
                rc = 1
                continue
            work = tmp_root / name
            work.mkdir(parents=True)
            with zipfile.ZipFile(apath) as zf:
                for info in zf.infolist():
                    if info.is_dir():
                        continue
                    pp = PurePosixPath(info.filename)
                    if pp.is_absolute() or ".." in pp.parts:
                        continue
                    low = info.filename.lower()
                    if low.endswith((".sv", ".v", ".svh", ".vh", ".md", ".yaml", ".yml", ".json", ".hex", ".mem")):
                        d = work / info.filename
                        d.parent.mkdir(parents=True, exist_ok=True)
                        d.write_bytes(zf.read(info))
            arc_root = work / proj["root"].rstrip("/")
            # scan this one archive
            c = cm.Corpus(repo_root, tmp_root / "scan")
            arc = cm.Archive(sha=sha, labels=[proj["archive"]], nbytes=len(data), root=work)
            c.archives[sha] = arc
            names = set()
            import re

            rx = re.compile(r"^[ \t]*(?:module|macromodule|interface)[ \t]+(?:automatic[ \t]+|static[ \t]+)?([A-Za-z_]\w*)", re.M)
            for p in c.hdl_files(arc):
                if p.suffix.lower() in cm.SRC_EXT:
                    from albionverify.audit import svscan

                    names.update(rx.findall(svscan.strip_comments(p.read_text("utf-8", "replace"))))
            files, units = cm.scan_archive(c, arc, names)
            ix = ec.ArcIndex.build(sha, work, units, files)
            proj_files = set()
            for top in proj["tops"]:
                cands = [u for u in ix.by_name.get(top, []) if u["role"] == "rtl" and u["file"].startswith(proj["root"])]
                if not cands:
                    print("ERROR: top %s not found in %s" % (top, name))
                    rc = 1
                    continue
                u = min(cands, key=lambda x: len(x["file"]))  # the project's own copy (shortest path), not a third_party copy
                ordered, unresolved = ec.closure(ix, u)
                hdirs = ec.include_dirs(ix, ordered)
                # keep only include dirs that are inside the project root
                rel = lambda f: "%s/%s" % (name, f[len(proj["root"]):]) if f.startswith(proj["root"]) else "%s/_ext/%s" % (name, f)
                manifest["duts"][top] = {
                    "project": name,
                    "files": [rel(f) for f in ordered],
                    "incdirs": sorted({str(PurePosixPath(rel(f)).parent) for f in ordered} | {rel(d) for d in hdirs if d.startswith(proj["root"])}),
                    "unresolved": unresolved,
                    "source_file": rel(u["file"]),
                }
                proj_files.update(ordered)
            # docs
            doc_files = set()
            for pat in proj.get("docs", []):
                for p in arc_root.rglob("*"):
                    if p.is_file() and fnmatch.fnmatch(str(p.relative_to(arc_root)), pat) and "third_party" not in p.relative_to(arc_root).parts:
                        doc_files.add(str(PurePosixPath(proj["root"]) / p.relative_to(arc_root).as_posix()))
            # headers: copy every .svh/.vh that lives in an include directory of this project's DUTs
            hdr_files = set()
            for top in proj["tops"]:
                d = manifest["duts"].get(top)
                if not d or d["project"] != name:
                    continue
                for inc in d["incdirs"]:
                    inc_arch = proj["root"] + inc[len(name) + 1:]
                    src_dir = work / inc_arch
                    if src_dir.is_dir():
                        for h in src_dir.iterdir():
                            if h.is_file() and h.suffix.lower() in (".svh", ".vh"):
                                hdr_files.add(inc_arch + "/" + h.name)
            proj_files |= {f for f in hdr_files}
            manifest["projects"][name] = {"archive": proj["archive"], "archive_sha256": sha, "root": proj["root"], "description": proj.get("description", "")}
            dest_root = OUT_DIR / name
            for f in sorted(proj_files | doc_files):
                src = work / f
                if not src.exists():
                    continue
                relp = f[len(proj["root"]):]
                dst = dest_root / relp
                key = "%s/%s" % (name, relp)
                manifest["files"][key] = {"sha256": sha256_file(src), "archive": proj["archive"], "member": f, "kind": "doc" if f in doc_files and f not in proj_files else "rtl"}
                if not check_only:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(src, dst)
            if not check_only:
                for top in proj["tops"]:
                    d = manifest["duts"].get(top)
                    if d and d["project"] == name:
                        d["incdirs"] = [i for i in d["incdirs"] if (OUT_DIR / i).is_dir()]
            print("%-22s %3d RTL files, %2d docs, %d DUT tops" % (name, len(proj_files), len(doc_files), len(proj["tops"])))
        if not check_only:
            (OUT_DIR / "MANIFEST.json").write_text(json.dumps(manifest, indent=1, sort_keys=True))
            print("wrote rtl/MANIFEST.json  (%d files)" % len(manifest["files"]))
        else:
            old = json.loads((OUT_DIR / "MANIFEST.json").read_text())
            bad = [k for k, v in manifest["files"].items() if old["files"].get(k, {}).get("sha256") != v["sha256"]]
            print("check: %d files differ from manifest" % len(bad))
            rc = rc or (1 if bad else 0)
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)
    return rc


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root", default=str(ROOT.parent.parent))
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    return build(Path(a.repo_root), a.check)


if __name__ == "__main__":
    sys.exit(main())
