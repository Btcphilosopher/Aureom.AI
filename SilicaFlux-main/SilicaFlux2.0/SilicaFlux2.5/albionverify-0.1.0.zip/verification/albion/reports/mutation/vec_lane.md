# Mutation report: vec_lane

Baseline (unmutated RTL): 8 run(s), all PASS.

**Mutation score: 100.0%** (39 killed / 0 survived; 1 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 37 kills came from scoreboard/protocol/model checks, 2 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| VL-01 | rounding | KILLED | CHECK | ['random_ops', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 489] mon: out_result mismatch: expected 0x3db0b9ce got 0x3db0b9cf |
| VL-02 | rounding | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1313] mon: out_result mismatch: expected 0x3299dd22 got 0x3299dd21 |
| VL-03 | rounding | KILLED | CHECK | ['random_ops', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1597] mon: out_result mismatch: expected 0x9e466405 got 0x9e466404 |
| VL-04 | rounding | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 48] mon: out_result mismatch: expected 0x3743805c got 0x3743805d |
| VL-05 | rounding | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 67] mon: out_result mismatch: expected 0x1 got 0x0 |
| VL-06 | sticky | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 27] mon: out_result mismatch: expected 0xff7ffffe got 0xff7fffff |
| VL-07 | boundary | EQUIVALENT_SURVIVED |  |  | Proven equivalent. For an exponent difference d = 26 the smaller significand sigy (< 2^24) lands entirely in the 26 guard/sticky positions b |
| VL-08 | normalisation | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 20] mon: out_result mismatch: expected 0x40400000 got 0x40c00000 |
| VL-09 | exponent-bias | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 44] mon: out_result mismatch: expected 0x40000000 got 0x3f800000 |
| VL-10 | sign-of-zero | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 420] mon: out_result mismatch: expected 0x80000000 got 0x0 |
| VL-11 | sign-of-zero | KILLED | CHECK | ['random_ops', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 85] mon: out_result mismatch: expected 0x80000000 got 0x0 |
| VL-12 | sticky | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1486] mon: out_flags mismatch: expected 0x1 got 0x0 |
| VL-13 | fma-sign | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 70] mon: out_result mismatch: expected 0xbf800000 got 0x40a00000 |
| VL-14 | fma-sign | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 83] mon: out_result mismatch: expected 0x3f800000 got 0x40a00000 |
| VL-15 | flags | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 67] mon: out_flags mismatch: expected 0x3 got 0x1 |
| VL-16 | tininess | KILLED | CHECK | ['directed_arith', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 10300] mon: out_flags mismatch: expected 0x1 got 0x3 |
| VL-17 | overflow | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 35] mon: out_result mismatch: expected 0x7f7fffff got 0x7f800000 |
| VL-18 | sticky | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 67] mon: out_result mismatch: expected 0x1 got 0x0 |
| VL-19 | flags | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 35] mon: out_flags mismatch: expected 0x5 got 0x1 |
| VL-20 | min-max | KILLED | CHECK | ['random_ops', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 303] mon: out_result mismatch: expected 0x0 got 0x80000000 |
| VL-21 | flags | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1725] mon: out_flags mismatch: expected 0x0 got 0x10 |
| VL-22 | flags | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1618] mon: out_flags mismatch: expected 0x10 got 0x0 |
| VL-23 | move | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 8] mon: out_result mismatch: expected 0x3f800000 got 0x3fc00000 |
| VL-24 | integer | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 115] mon: out_result mismatch: expected 0xdbfed2a3 got 0xd3fed293 |
| VL-25 | integer | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 22] mon: out_result mismatch: expected 0x32be8d62 got 0xc86b8d62 |
| VL-26 | arithmetic | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 32] mon: out_result mismatch: expected 0xbf800000 got 0x40400000 |
| VL-27 | special-values | KILLED | CHECK | ['directed_arith', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 9740] mon: out_flags mismatch: expected 0x10 got 0x0 |
| VL-28 | special-values | KILLED | CHECK | ['directed_arith', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 19496] mon: out_flags mismatch: expected 0x10 got 0x0 |
| VL-29 | sign-of-zero | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 259] mon: out_result mismatch: expected 0x0 got 0x80000000 |
| VL-30 | latency | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 20] mon: out_valid mismatch: expected 0x1 got 0x0 |
| VL-31 | latency | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 167] mon: out_valid mismatch: expected 0x1 got 0x0 |
| VL-32 | capacity | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 26] mon: in_ready mismatch: expected 0x1 got 0x0 |
| VL-33 | reset | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1] mon: in_ready during reset mismatch: expected 0x0 got 0x1 |
| VL-34 | lane-enable | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 9] mon: ev_accept mismatch: expected 0x0 got 0x1 |
| VL-35 | illegal | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 176] mon: out_result mismatch: expected 0x0 got 0xc0a00000 |
| VL-36 | interface | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1] mon: out_tag during reset mismatch: expected 0x0 got 0xbd |
| VL-37 | status | KILLED | CHECK | ['latency_per_op', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 7] mon: busy mismatch: expected 0x1 got 0x0 |
| VL-38 | reset | KILLED | ASSERT | ['latency_per_op', 'seed1'] | ly LAT_unit + 1 cycles after                                                           acceptance for every operation class; illegal operati |
| VL-39 | ordering | KILLED | ASSERT | ['latency_per_op', 'seed1'] |                                                           acceptance for every operation class; illegal operations one cycle after. [965000] |
| VL-40 | event | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 1027] mon: ev_pipe_stall mismatch: expected 0x0 got 0x1 |
