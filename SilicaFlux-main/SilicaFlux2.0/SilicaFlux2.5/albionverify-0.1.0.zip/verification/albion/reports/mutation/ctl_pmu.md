# Mutation report: ctl_pmu

Baseline (unmutated RTL): 7 run(s), all PASS.

**Mutation score: 96.6%** (28 killed / 0 survived; 0 argued-equivalent survivors excluded; 1 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 28 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CP-01 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 1] acc_iso mismatch [cyc=1 sel=0 we=1 addr=0x536 wdata=0xfc02bba2 rst=sys inputs={'cpu_s |
| CP-02 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 1] acc_clk_en mismatch [cyc=1 sel=0 we=1 addr=0x536 wdata=0xfc02bba2 rst=sys inputs={'cp |
| CP-03 | field | KILLED | CHECK | ['acc_ctrl_fields', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 24] rb_rdata mismatch [cyc=24 sel=1 we=0 addr=0x004 wdata=0x2000defc rst=- inputs={'cpu_ |
| CP-04 | busy | KILLED | CHECK | ['clock_gating_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 64] acc_clk_en mismatch [cyc=64 sel=0 we=0 addr=0x1c2 wdata=0xfe371d15 rst=- inputs={'cp |
| CP-05 | busy | KILLED | CHECK | ['clock_gating_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 39] acc_clk_en mismatch [cyc=39 sel=0 we=1 addr=0xba8 wdata=0xa3194a2f rst=- inputs={'cp |
| CP-06 | busy | KILLED | CHECK | ['clock_gating_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 89] acc_clk_en mismatch [cyc=89 sel=0 we=1 addr=0xa38 wdata=0x9faebcba rst=- inputs={'cp |
| CP-07 | gate | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 6] acc_clk_en mismatch [cyc=6 sel=1 we=0 addr=0x000 wdata=0x6fedc667 rst=- inputs={'cpu_ |
| CP-08 | timing | KILLED | CHECK | ['acc_ctrl_fields', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 7] acc_clk_en mismatch [cyc=7 sel=0 we=0 addr=0xe9f wdata=0x714c4f28 rst=- inputs={'cpu_ |
| CP-09 | reset-req | KILLED | CHECK | ['reset_isolation_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 27] acc_rst_req mismatch [cyc=27 sel=0 we=1 addr=0x329 wdata=0xf465be89 rst=- inputs={'c |
| CP-10 | reset-req | KILLED | CHECK | ['reset_isolation_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 13] acc_rst_req mismatch [cyc=13 sel=0 we=1 addr=0x28a wdata=0xe3dcb779 rst=- inputs={'c |
| CP-11 | counter | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 10] rb_rdata mismatch [cyc=10 sel=1 we=0 addr=0x010 wdata=0x4ee0f780 rst=- inputs={'cpu_ |
| CP-12 | counter | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 11] rb_rdata mismatch [cyc=11 sel=1 we=0 addr=0x014 wdata=0x2cb3835d rst=- inputs={'cpu_ |
| CP-13 | counter | KILLED | CHECK | ['counter_width', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 65553] rb_rdata mismatch [cyc=65553 sel=1 we=0 addr=0x010 wdata=0x50b088fe rst=- inputs= |
| CP-14 | counter | KILLED | CHECK | ['counter_width', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 65555] rb_rdata mismatch [cyc=65555 sel=1 we=0 addr=0x014 wdata=0xd3eeb77d rst=- inputs= |
| CP-15 | counter | UNOBSERVABLE_SURVIVED |  |  | UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs from the original only after 2^32 - 1 sleeping cycles (4.29e9 simu |
| CP-16 | isolation | KILLED | CHECK | ['acc_ctrl_fields', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 28] acc_iso mismatch [cyc=28 sel=1 we=0 addr=0x004 wdata=0xe0ca3931 rst=- inputs={'cpu_s |
| CP-17 | isolation | KILLED | CHECK | ['acc_ctrl_fields', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 20] acc_iso mismatch [cyc=20 sel=1 we=0 addr=0x004 wdata=0x1c1e7d9a rst=- inputs={'cpu_s |
| CP-18 | isolation | KILLED | CHECK | ['acc_ctrl_fields', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 7] acc_iso mismatch [cyc=7 sel=0 we=0 addr=0xe9f wdata=0x714c4f28 rst=- inputs={'cpu_sle |
| CP-19 | isolation | KILLED | CHECK | ['acc_ctrl_fields', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 11] acc_iso mismatch [cyc=11 sel=0 we=0 addr=0x63f wdata=0xb398c585 rst=- inputs={'cpu_s |
| CP-20 | isolation | KILLED | CHECK | ['reset_isolation_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 57] acc_iso mismatch [cyc=57 sel=0 we=1 addr=0xe64 wdata=0x4010da14 rst=- inputs={'cpu_s |
| CP-21 | isolation | KILLED | CHECK | ['reset_isolation_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 61] acc_iso mismatch [cyc=61 sel=0 we=0 addr=0x6cb wdata=0x9439590a rst=- inputs={'cpu_s |
| CP-22 | id | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 6] rb_rdata mismatch [cyc=6 sel=1 we=0 addr=0x000 wdata=0x6fedc667 rst=- inputs={'cpu_sl |
| CP-23 | status | KILLED | CHECK | ['clock_gating_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 45] rb_rdata mismatch [cyc=45 sel=1 we=0 addr=0x008 wdata=0x7c92ad69 rst=- inputs={'cpu_ |
| CP-24 | status | KILLED | CHECK | ['clock_gating_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 12] rb_rdata mismatch [cyc=12 sel=1 we=0 addr=0x008 wdata=0xfbf0d266 rst=- inputs={'cpu_ |
| CP-25 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 1032] rb_err mismatch [cyc=1032 sel=1 we=1 addr=0x008 wdata=0xffffffff rst=- inputs={'cp |
| CP-26 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 12] rb_err mismatch [cyc=12 sel=1 we=0 addr=0x018 wdata=0x85d3f0c2 rst=- inputs={'cpu_sl |
| CP-27 | read | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 9] rb_rdata mismatch [cyc=9 sel=1 we=0 addr=0x00c wdata=0x517987de rst=- inputs={'cpu_sl |
| CP-28 | decode | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 1032] acc_iso mismatch [cyc=1032 sel=1 we=1 addr=0x008 wdata=0xffffffff rst=- inputs={'c |
| CP-29 | read | KILLED | CHECK | ['reset_isolation_directed', 'seed1'] | albionverify.core.AlbionCheckError: [pmu/pmu @cycle 85] rb_rdata mismatch [cyc=85 sel=1 we=0 addr=0x010 wdata=0x334ba3e2 rst=- inputs={'cpu_ |

## Survivors unobservable through the ports (verification limit, NOT proven equivalent)

* **CP-15** (counter): SLEEP_CYC never saturates (wraps at 2^32): not observable in simulation (needs 4.29e9 sleeping cycles). -- UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs from the original only after 2^32 - 1 sleeping cycles (4.29e9 simulated cycles); unreachable in any simulation of bounded length. Saturation is covered by the model u
