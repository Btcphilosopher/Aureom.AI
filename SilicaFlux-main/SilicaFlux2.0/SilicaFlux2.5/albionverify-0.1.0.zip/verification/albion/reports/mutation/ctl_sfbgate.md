# Mutation report: ctl_sfbgate

Baseline (unmutated RTL): 7 run(s), all PASS.

**Mutation score: 100.0%** (26 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 26 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CG-01 | deny | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 6] a request reached the slave although none was forwarded by the gate (refused reques |
| CG-02 | error | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 7] refused request: rsp_error mismatch [addr 0x40]: expected 0x1, got 0x0 |
| CG-03 | error | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 7] refused request: rdata mismatch: expected 0x0, got 0xd7182af8 |
| CG-04 | deny | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 8] a request reached the slave although none was forwarded by the gate (refused reques |
| CG-05 | deny | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 6] a request reached the slave although none was forwarded by the gate (refused reques |
| CG-06 | withdraw | KILLED | CHECK | ['refuse_rise_while_stalled', 'seed1'] | albionverify.core.AlbionCheckError: [gate @cycle 14] mon_m: PROTOCOL VIOLATION: R2: request withdrawn before acceptance (valid dropped while |
| CG-07 | deny | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 3] s_req_ready mismatch [cyc=3 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=sys inputs={ |
| CG-08 | flow | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 1] s_req_ready mismatch [cyc=1 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=sys inputs={ |
| CG-09 | event | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 6] refused_evt mismatch [cyc=6 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s |
| CG-10 | event | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 7] refused_evt mismatch [cyc=7 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s |
| CG-11 | idle | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 7] idle mismatch [cyc=7 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s_req_va |
| CG-12 | idle | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 6] idle mismatch [cyc=6 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s_req_va |
| CG-13 | one-at-a-time | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 7] s_req_ready mismatch [cyc=7 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s |
| CG-14 | one-at-a-time | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 8] m_req_valid mismatch [cyc=8 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s |
| CG-15 | hold | KILLED | CHECK | ['refuse_rise_while_stalled', 'seed1'] | albionverify.core.AlbionCheckError: [gate @cycle 33] mon_s: PROTOCOL VIOLATION: R4: response withdrawn before acceptance (rsp_valid dropped  |
| CG-16 | flow | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 7] m_rsp_ready mismatch [cyc=7 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s |
| CG-17 | liveness | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 12] s_req_ready mismatch [cyc=12 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={ |
| CG-18 | passthrough | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 27] forwarded request: rsp_error (slave decides) mismatch [addr 0x1008]: expected 0x1, |
| CG-19 | passthrough | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 16] forwarded read data mismatch [addr 0x10]: expected 0xdeadbeef, got 0x0 |
| CG-20 | passthrough | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 12] m_req_wstrb mismatch [cyc=12 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={ |
| CG-21 | passthrough | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 28] forwarded request address mismatch: expected 0x100c, got 0x1008 |
| CG-22 | passthrough | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 12] forwarded request write flag mismatch: expected 0x0, got 0x1 |
| CG-23 | passthrough | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 6] m_req_wdata mismatch [cyc=6 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s |
| CG-24 | liveness | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 11] s_rsp_valid mismatch [cyc=11 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={ |
| CG-25 | reset | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 1] idle mismatch [cyc=1 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=sys inputs={'s_req_ |
| CG-26 | accept | KILLED | CHECK | ['refuse_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 7] refused_evt mismatch [cyc=7 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s |
