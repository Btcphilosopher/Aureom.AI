# Mutation report: heldout_ten

Baseline (unmutated RTL): 10 run(s), all PASS.

**Mutation score: 100.0%** (1 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 1 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| HT-1 | pipeline | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 17] mon: tile_done mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 1, 2))  |
