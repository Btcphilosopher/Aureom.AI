# Mutation report: heldout_sram

Baseline (unmutated RTL): 18 run(s), all PASS.

**Mutation score: 100.0%** (2 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 1 kills came from scoreboard/protocol/model checks, 1 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| HS-1 | error-response | KILLED | CHECK | ['invalid_address', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 111] rsp_valid (response due since cycle 111, kind err_write) mismatch [missing / late res |
| HS-2 | address-boundary | KILLED | ASSERT | ['invalid_address', 'seed1'] |                              addr >= DEPTH (non power-of-two depths only): error response, zero data, no side effect (also posted). [1075000 |
