# Mutation report: ten_array

Baseline (unmutated RTL): 10 run(s), all PASS.

**Mutation score: 96.0%** (48 killed / 0 survived; 2 argued-equivalent survivors excluded; 2 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 48 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| TM-01 | cfg-legality | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 7] mon: cfg_ready mismatch: expected 0x1 got 0x0 (model state IDLE, tile (0, 0, 0)) / |
| TM-02 | cfg-legality | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 80] mon: cfg_ready mismatch: expected 0x1 got 0x0 (model state IDLE, tile (2, 2, 4)) / |
| TM-03 | cfg-legality | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 118] mon: cfg_ready mismatch: expected 0x1 got 0x0 (model state IDLE, tile (1, 2, 3))  |
| TM-04 | cfg-legality | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 45] mon: cfg_ready mismatch: expected 0x1 got 0x0 (model state IDLE, tile (2, 1, 4)) / |
| TM-05 | cfg-legality | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 27] mon: cfg_ready mismatch: expected 0x1 got 0x0 (model state IDLE, tile (2, 1, 5)) / |
| TM-06 | cfg-reject | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 7] mon: cfg_reject mismatch: expected 0x1 got 0x0 (model state IDLE, tile (0, 0, 0)) / |
| TM-07 | cfg-reject | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 351] mon: cfg_reject mismatch: expected 0x0 got 0x1 (model state RUN, tile (2, 2, 16)) |
| TM-08 | cfg-handshake | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 11] mon: cfg_ready mismatch: expected 0x0 got 0x1 (model state READOUT, tile (1, 1, 1) |
| TM-09 | stall | KILLED | CHECK | ['stalls_and_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 8] mon: s_ready mismatch: expected 0x0 got 0x1 (model state RUN, tile (2, 1, 8)) / |
| TM-10 | stall | KILLED | CHECK | ['stalls_and_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 21] mon: perf_mac mismatch: expected 0xf got 0x10 (model state DRAIN, tile (2, 1, 8))  |
| TM-11 | stall | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 13] mon: perf_mac mismatch: expected 0x3 got 0x5 (model state RUN, tile (2, 1, 5)) / t |
| TM-12 | k-counter | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 8] mon: s_k (index of the slice expected next) mismatch: expected 0x0 got 0x1 (model s |
| TM-13 | k-counter | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 9] mon: s_ready mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 1, 1)) / t |
| TM-14 | mask | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 11] mon: tile_done mismatch: expected 0x1 got 0x0 (model state READOUT, tile (1, 1, 1) |
| TM-15 | col-mask | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 10] mon: tile_done mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 1, 1))  |
| TM-16 | readout | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 11] mon: m_last mismatch: expected 0x1 got 0x0 (model state READOUT, tile (1, 1, 1)) / |
| TM-17 | readout | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 256] mon: m_row mismatch: expected 0x0 got 0x1 (model state READOUT, tile (2, 2, 10))  |
| TM-18 | readout | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 127] mon: cfg_ready mismatch: expected 0x0 got 0x1 (model state READOUT, tile (2, 1, 1 |
| TM-19 | completion | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 86] mon: tile_done mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 2, 1))  |
| TM-20 | readout | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 66] mon: m_data lane 1 (row 0) mismatch: expected 0x5e got 0x73 (model state READOUT,  |
| TM-21 | readout-mask | EQUIVALENT_SURVIVED |  |  | Inactive PEs (row >= M or column >= N) never accumulate (a MAC needs BOTH operand tokens valid and lanes outside the tile inject valid = 0)  |
| TM-22 | pe-valid | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 11] mon: perf_mac mismatch: expected 0x1 got 0x3 (model state READOUT, tile (1, 1, 1)) |
| TM-23 | pe-valid | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 9] mon: perf_mac mismatch: expected 0x0 got 0x4 (model state DRAIN, tile (1, 1, 1)) /  |
| TM-24 | arithmetic | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 11] mon: m_data lane 0 (row 0) mismatch: expected 0xf9c got 0xf064 (model state READOU |
| TM-25 | arithmetic | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 18] mon: m_data lane 0 (row 0) mismatch: expected 0xffb1 got 0xb1 (model state READOUT |
| TM-26 | arithmetic | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 20] mon: m_data lane 0 (row 0) mismatch: expected 0xffff96 got 0xff96 (model state REA |
| TM-27 | overflow | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 174] mon: m_data lane 1 (row 0) mismatch: expected 0xaa7e got 0x7fff (model state READ |
| TM-28 | done | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 17] mon: tile_done mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 1, 2))  |
| TM-29 | stall | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 14] mon: align_err mismatch: expected 0x0 got 0x1 (model state RUN, tile (2, 1, 5)) /  |
| TM-30 | reset | KILLED | CHECK | ['reset_mid_tile', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 125] mon: align_err mismatch: expected 0x0 got 0x1 (model state RUN, tile (1, 2, 2)) / |
| TM-31 | forwarding | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 66] mon: m_data lane 1 (row 0) mismatch: expected 0x5e got 0x0 (model state READOUT, t |
| TM-32 | forwarding | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 125] mon: align_err mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (2, 1, 1)) |
| TM-33 | mul-pipe | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 12] mon: tile_done mismatch: expected 0x1 got 0x0 (model state READOUT, tile (1, 1, 1) |
| TM-34 | mul-pipe | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 9] mon: perf_mac mismatch: expected 0x0 got 0x6 (model state DRAIN, tile (1, 1, 1)) /  |
| TM-35 | checker | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 10] mon: align_err mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 1, 1))  |
| TM-36 | checker | UNOBSERVABLE_SURVIVED |  |  | UNOBSERVABLE UNDER LEGAL STIMULUS: the missing-token condition (an active PE sees exactly one valid token) cannot occur at the ports in a he |
| TM-37 | checker | UNOBSERVABLE_SURVIVED |  |  | UNOBSERVABLE UNDER LEGAL STIMULUS: align_err can only be set by an alignment violation, which cannot be provoked through the ports of a heal |
| TM-38 | skew | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 350] mon: align_err mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (3, 1, 1)) |
| TM-39 | skew | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 64] mon: align_err mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 2, 1))  |
| TM-40 | skew | KILLED | CHECK | ['cfg_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 14] mon: align_err mismatch: expected 0x0 got 0x1 (model state RUN, tile (2, 1, 5)) /  |
| TM-41 | skew-flush | EQUIVALENT_SURVIVED |  |  | By the time all_done raises tile_done the skew network holds only zero bubbles: the last token has crossed at most M (A) / N (B) lane stages |
| TM-42 | perf | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 9] mon: perf_pad mismatch: expected 0x3 got 0x4 (model state DRAIN, tile (1, 1, 1)) /  |
| TM-43 | perf | KILLED | CHECK | ['stalls_and_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 52] mon: perf_stall_ext mismatch: expected 0x4 got 0x5 (model state READOUT, tile (2,  |
| TM-44 | perf | KILLED | CHECK | ['stalls_and_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 35] mon: perf_stall_up mismatch: expected 0x2 got 0x3 (model state RUN, tile (2, 2, 5) |
| TM-45 | perf | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 6] mon: perf_mac mismatch: expected 0x0 got 0x1 (model state IDLE, tile (0, 0, 0)) / |
| TM-46 | perf | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 13] mon: perf_busy mismatch: expected 0x0 got 0x4 (model state CLEAR, tile (1, 1, 2))  |
| TM-47 | status | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 10] mon: tile_done mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 1, 1))  |
| TM-48 | reset | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 5] mon: cfg_ready mismatch: expected 0x1 got 0x0 (model state IDLE, tile (0, 0, 0)) / |
| TM-49 | accumulate | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 11] mon: m_data lane 0 (row 0) mismatch: expected 0xf9c got 0xea1c (model state READOU |
| TM-50 | k-counter | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 14] mon: s_k (index of the slice expected next) mismatch: expected 0x0 got 0x1 (model  |
| TM-51 | readout | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 135] mon: m_row mismatch: expected 0x0 got 0x1 (model state READOUT, tile (2, 1, 2)) / |
| TM-52 | completion | KILLED | CHECK | ['directed_tiles', 'seed1'] | albionverify.core.AlbionCheckError: [ten_array @cycle 10] mon: tile_done mismatch: expected 0x0 got 0x1 (model state DRAIN, tile (1, 1, 1))  |

## Survivors unobservable through the ports (verification limit, NOT proven equivalent)

* **TM-36** (checker): Alignment checker: the missing-token check is removed. -- UNOBSERVABLE UNDER LEGAL STIMULUS: the missing-token condition (an active PE sees exactly one valid token) cannot occur at the ports in a healthy array; align_err stays 0 either way. The vendor kills it only with an Icarus 'force' fault inj
* **TM-37** (checker): align_err is not cleared at the next launch (sticky forever). -- UNOBSERVABLE UNDER LEGAL STIMULUS: align_err can only be set by an alignment violation, which cannot be provoked through the ports of a healthy array, so 'not cleared at launch' has nothing to clear. Documented as a verification limitation 
