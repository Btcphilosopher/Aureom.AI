# Mutation report: ctl_secmon

Baseline (unmutated RTL): 6 run(s), all PASS.

**Mutation score: 96.0%** (24 killed / 0 survived; 0 argued-equivalent survivors excluded; 1 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 24 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CT-01 | caps | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 6] rb_rdata mismatch [cyc=6 sel=1 we=0 addr=0x000 wdata=0x409dff8e rst=- inputs={' |
| CT-02 | lock | KILLED | CHECK | ['lock_and_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 18] host_lock mismatch [cyc=18 sel=0 we=1 addr=0x75e wdata=0x909dcbfa rst=- inputs |
| CT-03 | lock | KILLED | CHECK | ['lock_and_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 7] host_lock mismatch [cyc=7 sel=0 we=0 addr=0x987 wdata=0x7d994a5c rst=- inputs={ |
| CT-04 | write-once | KILLED | CHECK | ['lock_and_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 35] rb_rdata mismatch [cyc=35 sel=1 we=0 addr=0x00c wdata=0x4087134f rst=- inputs= |
| CT-05 | write-once | KILLED | CHECK | ['lock_and_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 33] rb_err mismatch [cyc=33 sel=1 we=1 addr=0x00c wdata=0x12345678 rst=- inputs={' |
| CT-06 | write-once | KILLED | CHECK | ['lock_and_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 27] rb_err mismatch [cyc=27 sel=1 we=1 addr=0x00c wdata=0xdeadbeef rst=- inputs={' |
| CT-07 | write-once | KILLED | CHECK | ['zero_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 8] rb_rdata mismatch [cyc=8 sel=1 we=0 addr=0x004 wdata=0xee61a4e4 rst=- inputs={' |
| CT-08 | violation | KILLED | CHECK | ['violation_log_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 14] rb_rdata mismatch [cyc=14 sel=1 we=0 addr=0x014 wdata=0x724959a9 rst=- inputs= |
| CT-09 | violation | KILLED | CHECK | ['violation_log_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 20] rb_rdata mismatch [cyc=20 sel=1 we=0 addr=0x010 wdata=0xbddaadff rst=- inputs= |
| CT-10 | violation | KILLED | CHECK | ['violation_log_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 22] rb_rdata mismatch [cyc=22 sel=1 we=0 addr=0x014 wdata=0xd8769fb5 rst=- inputs= |
| CT-11 | clear | KILLED | CHECK | ['violation_log_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 36] rb_rdata mismatch [cyc=36 sel=1 we=0 addr=0x004 wdata=0x95b69af0 rst=- inputs= |
| CT-12 | priority | KILLED | CHECK | ['violation_log_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 52] rb_rdata mismatch [cyc=52 sel=1 we=0 addr=0x004 wdata=0x39e55da2 rst=- inputs= |
| CT-13 | clear | KILLED | CHECK | ['violation_log_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 42] rb_rdata mismatch [cyc=42 sel=1 we=0 addr=0x014 wdata=0xfa04f0f6 rst=- inputs= |
| CT-14 | status | KILLED | CHECK | ['lock_and_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 15] rb_rdata mismatch [cyc=15 sel=1 we=0 addr=0x004 wdata=0xda5a7dc3 rst=- inputs= |
| CT-15 | status | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 7] rb_rdata mismatch [cyc=7 sel=1 we=0 addr=0x004 wdata=0x987a0bfc rst=- inputs={' |
| CT-16 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 1031] rb_err mismatch [cyc=1031 sel=1 we=1 addr=0x000 wdata=0xffffffff rst=- input |
| CT-17 | auth | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 13] rb_rdata mismatch [cyc=13 sel=1 we=0 addr=0x01c wdata=0x4d2b37ea rst=- inputs= |
| CT-18 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 14] rb_err mismatch [cyc=14 sel=1 we=0 addr=0x020 wdata=0xb07de165 rst=- inputs={' |
| CT-19 | read | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 8] rb_rdata mismatch [cyc=8 sel=1 we=0 addr=0x008 wdata=0x7d994a5c rst=- inputs={' |
| CT-20 | pin | KILLED | CHECK | ['lock_and_measure_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 11] host_lock mismatch [cyc=11 sel=0 we=0 addr=0xb07 wdata=0xb7bf1485 rst=- inputs |
| CT-21 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 1] host_lock mismatch [cyc=1 sel=0 we=1 addr=0x536 wdata=0xfc02bba2 rst=sys inputs |
| CT-22 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 7] rb_rdata mismatch [cyc=7 sel=1 we=0 addr=0x004 wdata=0x987a0bfc rst=- inputs={' |
| CT-23 | read | KILLED | CHECK | ['violation_log_directed', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 12] rb_rdata mismatch [cyc=12 sel=1 we=0 addr=0x010 wdata=0x2fd77118 rst=- inputs= |
| CT-24 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [secmon/secmon @cycle 12] rb_err mismatch [cyc=12 sel=1 we=0 addr=0x018 wdata=0x83b4a840 rst=- inputs={' |
| CT-25 | counter | UNOBSERVABLE_SURVIVED |  |  | UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs only after 2^32 - 1 violations: unreachable in a bounded simulatio |

## Survivors unobservable through the ports (verification limit, NOT proven equivalent)

* **CT-25** (counter): VIOL_COUNT wraps instead of saturating (not observable in simulation). -- UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs only after 2^32 - 1 violations: unreachable in a bounded simulation (documented limitation).
