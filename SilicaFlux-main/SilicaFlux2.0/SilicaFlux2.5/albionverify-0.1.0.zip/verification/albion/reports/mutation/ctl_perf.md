# Mutation report: ctl_perf

Baseline (unmutated RTL): 9 run(s), all PASS.

**Mutation score: 95.8%** (23 killed / 0 survived; 0 argued-equivalent survivors excluded; 1 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 23 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CF-01 | clear | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 115] rb_rdata mismatch [cyc=115 sel=1 we=0 addr=0x100 wdata=0x840b13e5 rst=- inputs={' |
| CF-02 | clear | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 117] rb_rdata mismatch [cyc=117 sel=1 we=0 addr=0x010 wdata=0x25bed67f rst=- inputs={' |
| CF-03 | clear | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 115] rb_rdata mismatch [cyc=115 sel=1 we=0 addr=0x100 wdata=0x840b13e5 rst=- inputs={' |
| CF-04 | clear | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 150] rb_rdata mismatch [cyc=150 sel=1 we=0 addr=0x100 wdata=0xa7cf7a49 rst=- inputs={' |
| CF-05 | freeze | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 39] rb_rdata mismatch [cyc=39 sel=1 we=0 addr=0x000 wdata=0x9110770f rst=- inputs={'ev |
| CF-06 | freeze | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 81] rb_rdata mismatch [cyc=81 sel=1 we=0 addr=0x100 wdata=0xbe3d236b rst=- inputs={'ev |
| CF-07 | freeze | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 41] rb_rdata mismatch [cyc=41 sel=1 we=0 addr=0x010 wdata=0xf9204522 rst=- inputs={'ev |
| CF-08 | edge | KILLED | CHECK | ['counting_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 326] rb_rdata mismatch [cyc=326 sel=1 we=0 addr=0x120 wdata=0xad4eec37 rst=- inputs={' |
| CF-09 | edge | KILLED | CHECK | ['counting_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 22] rb_rdata mismatch [cyc=22 sel=1 we=0 addr=0x100 wdata=0xecf655b5 rst=- inputs={'ev |
| CF-10 | edge | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 103] rb_rdata mismatch [cyc=103 sel=1 we=0 addr=0x120 wdata=0xa813a966 rst=- inputs={' |
| CF-11 | edge | KILLED | CHECK | ['freeze_clear_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 103] rb_rdata mismatch [cyc=103 sel=1 we=0 addr=0x120 wdata=0xa813a966 rst=- inputs={' |
| CF-12 | counter | KILLED | CHECK | ['cycle_counter_wide', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 70010] rb_rdata mismatch [cyc=70010 sel=1 we=0 addr=0x100 wdata=0x0744616b rst=- input |
| CF-13 | counter | KILLED | CHECK | ['cycle_counter_wide', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 70010] rb_rdata mismatch [cyc=70010 sel=1 we=0 addr=0x100 wdata=0x0744616b rst=- input |
| CF-14 | counter | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 10] rb_rdata mismatch [cyc=10 sel=1 we=0 addr=0x010 wdata=0x6ee62c7f rst=- inputs={'ev |
| CF-15 | counter | UNOBSERVABLE_SURVIVED |  |  | UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs only after 2^32 - 1 counted events: unreachable in a bounded simul |
| CF-16 | read | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 7] rb_rdata mismatch [cyc=7 sel=1 we=0 addr=0x004 wdata=0x5b407d22 rst=- inputs={'ev': |
| CF-17 | decode | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 90] rb_err mismatch [cyc=90 sel=1 we=0 addr=0x150 wdata=0xcf9cab95 rst=- inputs={'ev': |
| CF-18 | decode | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 70] rb_err mismatch [cyc=70 sel=1 we=0 addr=0x100 wdata=0x42fef699 rst=- inputs={'ev': |
| CF-19 | decode | KILLED | CHECK | ['counting_directed', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 23] rb_rdata mismatch [cyc=23 sel=1 we=0 addr=0x104 wdata=0xa301d839 rst=- inputs={'ev |
| CF-20 | read | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 11] rb_rdata mismatch [cyc=11 sel=1 we=0 addr=0x014 wdata=0xe13d742e rst=- inputs={'ev |
| CF-21 | read | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 6] rb_rdata mismatch [cyc=6 sel=1 we=0 addr=0x000 wdata=0xf6e60b38 rst=- inputs={'ev': |
| CF-22 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 1034] rb_err mismatch [cyc=1034 sel=1 we=1 addr=0x100 wdata=0xffffffff rst=- inputs={' |
| CF-23 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 8] rb_err mismatch [cyc=8 sel=1 we=0 addr=0x008 wdata=0xd90b68a1 rst=- inputs={'ev': 0 |
| CF-24 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [perf/perf @cycle 6] rb_rdata mismatch [cyc=6 sel=1 we=0 addr=0x000 wdata=0xf6e60b38 rst=- inputs={'ev': |

## Survivors unobservable through the ports (verification limit, NOT proven equivalent)

* **CF-15** (counter): Event counters never saturate (wrap at 2^32): not observable in simulation. -- UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs only after 2^32 - 1 counted events: unreachable in a bounded simulation (documented limitation, saturation covered by model tests only).
