# Mutation report: ctl_core

Baseline (unmutated RTL): 4 run(s), all PASS.

**Mutation score: 100.0%** (19 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 17 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 2 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CK-01 | lock | KILLED | CHECK | ['boot_handshake_irq', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 325531] lock_refused_dmem: host write refused with an error response mismatch: expecte |
| CK-02 | lock | KILLED | CHECK | ['boot_handshake_irq', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 325534] lock_refused_imem: host write refused with an error response mismatch: expecte |
| CK-03 | lock | KILLED | CHECK | ['boot_handshake_irq', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 325531] lock_refused_dmem: host write refused with an error response mismatch: expecte |
| CK-04 | lock | KILLED | CHECK | ['boot_handshake_irq', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 325561] RAS HOST_VIOL bit set mismatch: expected 0x1, got 0x0 |
| CK-05 | map | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 295294] host read of 0x40011000 (reg_ok) returned an error / was cancelled |
| CK-06 | map | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 295793] every access to pages 8..15 produced one acc_rb strobe with acc_rb_addr = page |
| CK-07 | isolation | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 295851] isolation: nothing is forwarded on acc_rb_* mismatch: expected 0x10, got 0x12 |
| CK-08 | isolation | KILLED | CHECK | ['boot_handshake_irq', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 324768] accelerator interrupt lines are masked while the domain is isolated mismatch:  |
| CK-09 | irq | KILLED | LIVENESS | ['boot_handshake_irq', 'seed1'] | albionverify.core.LivenessError: [core @cycle 341721] liveness: firmware answer #0 not reached within 20000 cycles |
| CK-10 | irq | KILLED | CHECK | ['boot_handshake_irq', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 325106] ext_warn_i raised the RAS_WARN interrupt exactly once (handler masks the level |
| CK-11 | ras-wiring | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 295621] RAS: BUS_DECODE only mismatch: expected 0x1, got 0x0 |
| CK-12 | ras-wiring | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 295721] RAS: PERIPH_ERR only mismatch: expected 0x2, got 0x0 |
| CK-13 | ras-wiring | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 295879] RAS ISO_ACCESS set; every refused access counted as ISO_ACCESS + PERIPH_ERR mi |
| CK-14 | sync | KILLED | CHECK | ['boot_handshake_irq', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 325110] handler saw EXT_WARN in RAS.STATUS mismatch: expected 0x1, got 0x0 |
| CK-15 | sync | KILLED | CHECK | ['reset_early', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 24761] host reset request: RESET_CAUSE / RESET_COUNT mismatch: expected (9, 1), got (1 |
| CK-16 | reset | KILLED | CHECK | ['reset_early', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 24769] host reset request: SYS-domain register cleared, POR-domain scratch kept mismat |
| CK-17 | reset | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 295959] PMU.ACC_CTRL.RST asserts acc_rst_no (async assert) mismatch: expected 0x0, got |
| CK-18 | reset | KILLED | LIVENESS | ['boot_mode_straps', 'seed1'] | albionverify.core.LivenessError: [core @cycle 20012] liveness: host read 0x4000002c not reached within 20000 cycles |
| CK-19 | clock | KILLED | CHECK | ['host_access_control', 'seed1'] | albionverify.core.AlbionCheckError: [core/core @cycle 296053] accelerator clock stopped while CLK_EN = 0 (idle accelerator) mismatch: expect |
