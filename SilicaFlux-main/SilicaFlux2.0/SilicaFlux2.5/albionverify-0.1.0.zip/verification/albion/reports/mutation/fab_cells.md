# Mutation report: fab_cells

Baseline (unmutated RTL): 2 run(s), all PASS.

**Mutation score: 100.0%** (15 killed / 0 survived; 1 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 15 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| FC-01 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_phases @cycle 509] skid: s_ready=1, model expects 0 (fill 2) |
| FC-02 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_phases @cycle 510] skid: m_data=0xe2, model expects 0x5b |
| FC-03 | ordering | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_phases @cycle 510] skid: m_data=0x6d, model expects 0x5b |
| FC-04 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_phases @cycle 509] skid: m_data=0x5b, model expects 0xe2 |
| FC-05 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_phases @cycle 510] skid: s_ready=0, model expects 1 (fill 1) |
| FC-06 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_phases @cycle 5] skid: s_ready=0, model expects 1 (fill 0) |
| FC-07 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_phases @cycle 2] skid: m_valid asserted during reset |
| FC-08 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [skid_reset @cycle 118] skid: s_ready=0, model expects 1 (fill 0) |
| FC-09 | throughput | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [err_phases @cycle 6] errslave: req_ready=0, model expects 1 |
| FC-10 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [err_phases @cycle 5] errslave: rsp_rdata=0xffffffff, must be 0 (R8) |
| FC-11 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [err_phases @cycle 6] errslave: response without rsp_error |
| FC-12 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [err_phases @cycle 307] errslave: req_ready=1, model expects 0 |
| FC-13 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [err_phases @cycle 2] errslave: rsp_valid asserted during reset |
| FC-14 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [err_reset @cycle 193] errslave: req_ready=0, model expects 1 |
| FC-15 | latency | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [err_phases @cycle 5] errslave: rsp_valid=1, model expects 0 |
| FC-90 | equivalent | EQUIVALENT_SURVIVED |  |  | Case analysis of the next-state expression: (a) pend_q = 0: req_ready = !pend_q // rsp_ready = 1, so req_valid && req_ready = req_valid; (b) |
