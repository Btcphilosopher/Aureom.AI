# Mutation report: fab_regslice

Baseline (unmutated RTL): 4 run(s), all PASS.

**Mutation score: 100.0%** (16 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 16 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| FS-01 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity/slice @cycle 8] LOCKSTEP s_req_ready: model expects 0, DUT drives 1 (req fill=2 rsp fill |
| FS-02 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity/slice @cycle 32] request altered by the slice: master sent (wr=0 addr=0x7b0dc934 wdata=0 |
| FS-03 | ordering | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity/slice @cycle 32] request altered by the slice: master sent (wr=0 addr=0x7b0dc934 wdata=0 |
| FS-04 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity @cycle 8] mon_dn: PROTOCOL VIOLATION: R2: request payload changed while stalled: (0, 288 |
| FS-05 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity/slice @cycle 32] LOCKSTEP s_req_ready: model expects 1, DUT drives 0 (req fill=1 rsp fil |
| FS-06 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_latency/slice @cycle 5] LOCKSTEP m_rsp_ready: model expects 1, DUT drives 0 (req fill=0 rsp fill= |
| FS-07 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_reset/slice @cycle 26] R11: upstream rsp_valid asserted during reset |
| FS-08 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_reset/slice @cycle 272] LOCKSTEP m_req_valid: model expects 0, DUT drives 1 (req fill=0 rsp fill= |
| FS-09 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity/slice @cycle 6] LOCKSTEP s_req_ready: model expects 0, DUT drives 1 (req fill=0 rsp fill |
| FS-10 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity/slice @cycle 33] response mismatch (seq 1 addr 0xac113344 rd): expected rdata=0x0 err=1, |
| FS-11 | byte-enable | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_latency/slice @cycle 7] request altered by the slice: master sent (wr=0 addr=0x6b62f70 wdata=0x0  |
| FS-12 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_throughput/slice @cycle 8] request altered by the slice: master sent (wr=1 addr=0xdcb7b7e7 wdata= |
| FS-13 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity @cycle 50] mon_up: PROTOCOL VIOLATION: R4: response payload changed while stalled: (3363 |
| FS-14 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity @cycle 8] mon_dn: PROTOCOL VIOLATION: R2: request payload changed while stalled: (0, 288 |
| FS-15 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_capacity/slice @cycle 45] LOCKSTEP m_rsp_ready: model expects 0, DUT drives 1 (req fill=0 rsp fil |
| FS-16 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slice_latency/slice @cycle 21] request altered by the slice: master sent (wr=1 addr=0xbd14fd64 wdata=0x |
