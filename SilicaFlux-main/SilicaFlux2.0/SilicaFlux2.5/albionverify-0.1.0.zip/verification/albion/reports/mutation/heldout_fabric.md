# Mutation report: heldout_fabric

Baseline (unmutated RTL): 10 run(s), all PASS.

**Mutation score: 100.0%** (4 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 4 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| HF-1 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slave_errors/xbar @cycle 8] LOCKSTEP m_rsp_error[0]: model expects 1, DUT drives 0  [model state: out=[ |
| HF-2 | decode-precedence | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 6] LOCKSTEP s_req_valid[0]: model expects 1, DUT drives 0  [model state: out=[0, |
| HF-3 | events | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 2] R11: ev_req_stall asserted during reset ([1, 1, 1]) |
| HF-4 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 8] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out=[0, |
