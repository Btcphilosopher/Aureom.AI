# Mutation report: heldout_dma

Baseline (unmutated RTL): 8 run(s), all PASS.

**Mutation score: 100.0%** (3 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 3 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| HD-1 | validation-boundary | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 572] DMA reference model: edge 571: transfer ended early: 0 of 4 beats written, no error and |
| HD-2 | validation-boundary | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 443] DMA reference model: edge 442: read ERROR_CODE = 0x5, expected one of ['0x6'] |
| HD-3 | progress-count | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 648] DMA reference model: edge 647: bytes_done pin=12, expected 9 |
