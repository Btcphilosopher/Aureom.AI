# Mutation report: ctl_mailbox

Baseline (unmutated RTL): 11 run(s), all PASS.

**Mutation score: 100.0%** (31 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 31 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CM-01 | ack | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 21] irq_h2f mismatch [cyc=21 sel=0 we=1 addr=0x8cb wdata=0xef86dbf3 rst=- inputs={'_cy |
| CM-02 | ack | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 45] host_irq mismatch [cyc=45 sel=0 we=1 addr=0xf43 wdata=0xed6a8461 rst=- inputs={'_c |
| CM-03 | ack | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 21] irq_h2f mismatch [cyc=21 sel=0 we=1 addr=0x8cb wdata=0xef86dbf3 rst=- inputs={'_cy |
| CM-04 | ring | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 36] rb_rdata mismatch [cyc=36 sel=1 we=0 addr=0x058 wdata=0x98b3ce5d rst=- inputs={'_c |
| CM-05 | ring | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 16] rb_rdata mismatch [cyc=16 sel=1 we=0 addr=0x054 wdata=0xbaef4537 rst=- inputs={'_c |
| CM-06 | counter | KILLED | CHECK | ['ring_count_mid', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 777] rb_rdata mismatch [cyc=777 sel=1 we=0 addr=0x05c wdata=0x53209b2b rst=- inputs={' |
| CM-07 | counter | KILLED | CHECK | ['ring_count_mid', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 12306] rb_rdata mismatch [cyc=12306 sel=1 we=0 addr=0x05c wdata=0x2f316602 rst=- input |
| CM-08 | counter | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 18] rb_rdata mismatch [cyc=18 sel=1 we=0 addr=0x05c wdata=0x149b8f53 rst=- inputs={'_c |
| CM-09 | fifo | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 528] rb_rdata mismatch [cyc=528 sel=1 we=0 addr=0x08c wdata=0x19379618 rst=- inputs={' |
| CM-10 | fifo | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 540] rb_rdata mismatch [cyc=540 sel=1 we=0 addr=0x08c wdata=0x10cd8091 rst=- inputs={' |
| CM-11 | w1c | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 546] rb_rdata mismatch [cyc=546 sel=1 we=0 addr=0x08c wdata=0xd931d369 rst=- inputs={' |
| CM-12 | w1c | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 546] rb_rdata mismatch [cyc=546 sel=1 we=0 addr=0x08c wdata=0xd931d369 rst=- inputs={' |
| CM-13 | fifo | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 12] rb_rdata mismatch [cyc=12 sel=1 we=0 addr=0x08c wdata=0xa71081f2 rst=- inputs={'_c |
| CM-14 | fifo | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 528] rb_rdata mismatch [cyc=528 sel=1 we=0 addr=0x08c wdata=0x19379618 rst=- inputs={' |
| CM-15 | fifo | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 540] rb_rdata mismatch [cyc=540 sel=1 we=0 addr=0x08c wdata=0x10cd8091 rst=- inputs={' |
| CM-16 | decode | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 526] rb_err mismatch [cyc=526 sel=1 we=0 addr=0x820 wdata=0xfa020ad9 rst=- inputs={'_c |
| CM-17 | decode | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 96] rb_rdata mismatch [cyc=96 sel=1 we=0 addr=0x000 wdata=0xcc8637f2 rst=- inputs={'_c |
| CM-18 | error | KILLED | CHECK | ['random_traffic', 'seed2'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 1031] rb_err mismatch [cyc=1031 sel=1 we=1 addr=0x054 wdata=0x00000400 rst=- inputs={' |
| CM-19 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 30] rb_err mismatch [cyc=30 sel=1 we=0 addr=0x060 wdata=0x0f2bb698 rst=- inputs={'_cyc |
| CM-20 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 23] rb_err mismatch [cyc=23 sel=1 we=0 addr=0x044 wdata=0x96e85419 rst=- inputs={'_cyc |
| CM-21 | status | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 10] rb_rdata mismatch [cyc=10 sel=1 we=0 addr=0x040 wdata=0xc45a431f rst=- inputs={'_c |
| CM-22 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 41] rb_rdata mismatch [cyc=41 sel=1 we=0 addr=0x08c wdata=0x30c3195c rst=- inputs={'_c |
| CM-23 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 29] rb_rdata mismatch [cyc=29 sel=1 we=0 addr=0x05c wdata=0x4468b386 rst=- inputs={'_c |
| CM-24 | pin | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 9] irq_h2f mismatch [cyc=9 sel=0 we=1 addr=0x532 wdata=0x5a8af593 rst=- inputs={'_cycl |
| CM-25 | pin | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 530] diag_valid mismatch [cyc=530 sel=1 we=1 addr=0x080 wdata=0x00000041 rst=- inputs= |
| CM-26 | pin | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 14] diag_char mismatch [cyc=14 sel=1 we=1 addr=0x080 wdata=0xabcd0041 rst=- inputs={'_ |
| CM-27 | status | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 528] rb_rdata mismatch [cyc=528 sel=1 we=0 addr=0x08c wdata=0x19379618 rst=- inputs={' |
| CM-28 | fifo | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 16] rb_rdata mismatch [cyc=16 sel=1 we=0 addr=0x084 wdata=0xbaef4537 rst=- inputs={'_c |
| CM-29 | fifo | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 39] rb_rdata mismatch [cyc=39 sel=1 we=0 addr=0x084 wdata=0xf9ad61d3 rst=- inputs={'_c |
| CM-30 | storage | KILLED | CHECK | ['doorbell_handshake', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 96] rb_rdata mismatch [cyc=96 sel=1 we=0 addr=0x000 wdata=0xcc8637f2 rst=- inputs={'_c |
| CM-31 | counter | KILLED | CHECK | ['ring_count_wrap', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 133124] rb_rdata mismatch [cyc=133124 sel=1 we=0 addr=0x05c wdata=0x3ed8b2ba rst=- inp |
