# Mutation report: framework_smoke

Baseline (unmutated RTL): 1 run(s), all PASS.

**Mutation score: 100.0%** (6 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 6 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| SM-01 | byte-enable | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [xbar_smoke/xbar @cycle 75] ref: read of 0x10001000 (4B) mismatch: byte@0x10001000 lane0 exp=00 got=b9;  |
| SM-02 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [xbar_smoke/xbar @cycle 8] ref: read of 0x10000000 (4B) mismatch: byte@0x10000000 lane0 exp=00 got=ff; b |
| SM-03 | response-routing | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [xbar_smoke @cycle 13] m1: response with no earlier accepted request (rdata=0x0 err=0) |
| SM-04 | address-check | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [xbar_smoke/xbar @cycle 74] decode-error rsp_error mismatch [addr 0x1000000f]: expected 0x1, got 0x0 |
| SM-05 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [xbar_smoke/xbar @cycle 15] decode-error rsp_error mismatch [addr 0xe0000000]: expected 0x1, got 0x0 |
| SM-06 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [xbar_smoke @cycle 43] mon_s1: PROTOCOL VIOLATION: R2: request payload changed while stalled: (1, 536870 |
