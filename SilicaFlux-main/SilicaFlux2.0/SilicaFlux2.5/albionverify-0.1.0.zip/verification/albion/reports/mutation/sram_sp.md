# Mutation report: sram_sp

Baseline (unmutated RTL): 18 run(s), all PASS.

**Mutation score: 100.0%** (34 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 31 kills came from scoreboard/protocol/model checks, 3 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| SP-01 | byte-enable | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_rdata word 0x0 mismatch: lane0 exp=0x37 got=0x79 (kind read, id 1) / recent: c8 ac |
| SP-02 | byte-enable | KILLED | CHECK | ['byte_lanes', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 12] rsp_rdata word 0x0 mismatch: lane3 exp=0x0 got=0xff (kind read, id 0) / recent: c8 acc |
| SP-03 | byte-enable | KILLED | CHECK | ['byte_lanes', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 12] rsp_rdata word 0x0 mismatch: lane1 exp=0x0 got=0xff; lane2 exp=0x0 got=0xff; lane3 exp |
| SP-04 | byte-enable | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_rdata word 0x0 mismatch: lane0 exp=0x37 got=0x43; lane1 exp=0xde got=0xa; lane2 ex |
| SP-05 | byte-enable | KILLED | CHECK | ['byte_lanes', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_rdata word 0x0 mismatch: lane0 exp=0x1ff got=0xff (kind read, id 0) / recent: c8 a |
| SP-06 | boundary | KILLED | ASSERT | ['invalid_address', 'seed1'] |                             addr >= DEPTH (non power-of-two depths only): error response, zero data, no side effect (also posted). [1075000] |
| SP-07 | error-response | KILLED | CHECK | ['invalid_address', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 110] rsp_err mismatch [err_write addr 0x64]: expected 0x1, got 0x0 / recent: c104 rsp writ |
| SP-08 | error-response | KILLED | CHECK | ['invalid_address', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 111] rsp_valid (response due since cycle 111, kind err_write) mismatch [missing / late res |
| SP-09 | boundary | KILLED | ASSERT | ['invalid_address', 'seed1'] |                             addr >= DEPTH (non power-of-two depths only): error response, zero data, no side effect (also posted). [1075000] |
| SP-10 | boundary | KILLED | ASSERT | ['test_port_mode', 'seed1'] |  exactly READ_LATENCY                                                           cycles later, test addresses >= DEPTH are ignored. [1785000] |
| SP-11 | data-path | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_rdata word 0x0 mismatch: lane0 exp=0x37 got=0x60; lane1 exp=0xde got=0x1e; lane2 e |
| SP-12 | write-ack | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 10] rsp_valid (response due since cycle 10, kind write_ack) mismatch [missing / late respo |
| SP-13 | write-ack | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_valid (nothing due) mismatch [unsolicited / early response]: expected 0x0, got 0x1 |
| SP-14 | write-ack | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 10] rsp_rdata write_ack response must carry all-zero rdata, got 0x67b57747 (kind write_ack |
| SP-15 | response-id | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 10] rsp_id mismatch [write_ack addr 0x0]: expected 0x0, got 0xf / recent: c8 acc W a=0x0 ; |
| SP-16 | response-id | KILLED | CHECK | ['credits_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_id mismatch [write_ack addr 0x1]: expected 0x0, got 0x3 / recent: c8 acc W a=0x1 ; |
| SP-17 | response-flags | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 10] rsp_we mismatch [write_ack addr 0x0]: expected 0x1, got 0x0 / recent: c8 acc W a=0x0 ; |
| SP-18 | response-flags | KILLED | CHECK | ['credits_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 321] rsp_err mismatch [err_write addr 0x64]: expected 0x1, got 0x0 / recent: c310 acc W a= |
| SP-19 | latency | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_valid (nothing due) mismatch [unsolicited / early response]: expected 0x0, got 0x1 |
| SP-20 | latency | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 125] rsp_rdata word 0x0 mismatch: lane0 exp=0x15 got=0x2a; lane1 exp=0x7c got=0xf8; lane2  |
| SP-21 | ordering | KILLED | CHECK | ['credits_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] stalled rsp_rdata write_ack response must carry all-zero rdata, got 0xe4002b3b (kind w |
| SP-22 | ordering | KILLED | CHECK | ['credits_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 79] rsp_err mismatch [write_ack addr 0x7]: expected 0x0, got 0x1 / recent: c8 acc W a=0x1  |
| SP-23 | flow-control | KILLED | CHECK | ['credits_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 13] rsp_valid (response due since cycle 10, kind write_ack) mismatch [missing / late respo |
| SP-24 | flow-control | KILLED | CHECK | ['credits_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] req_ready mismatch: expected 0, got 1 (live=1, we=1, addr=0x7, outstanding=3/3, posted |
| SP-25 | flow-control | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] req_ready mismatch: expected 1, got 0 (live=1, we=0, addr=0x1, outstanding=2/3, posted |
| SP-26 | flow-control | KILLED | CHECK | ['credits_backpressure', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 16] req_ready mismatch: expected 1, got 0 (live=1, we=1, addr=0x29, outstanding=4/4, poste |
| SP-27 | flow-control | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 11] rsp_err mismatch [read addr 0x0]: expected 0x0, got 0x1 / recent: c8 acc W a=0x0 ; c9  |
| SP-28 | reset | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 2] rsp_valid while rst_n low mismatch: expected 0x0, got 0x1 / recent: |
| SP-29 | reset | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 8] req_ready mismatch: expected 1, got 0 (live=1, we=1, addr=0x0, outstanding=0/3, posted- |
| SP-30 | reset | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 2] rsp_valid while rst_n low mismatch: expected 0x0, got 0x1 / recent: |
| SP-31 | reset | KILLED | CHECK | ['directed_rw', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 2] req_ready while rst_n low mismatch: expected 0x0, got 0x1 / recent: |
| SP-32 | reset | KILLED | CHECK | ['reset_during_traffic', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 88] req_ready while rst_n low mismatch: expected 0x0, got 0x1 / recent: c73 acc W a=0x65 ; |
| SP-33 | test-mode | KILLED | CHECK | ['test_port_mode', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 46] req_ready mismatch: expected 0, got 1 (live=1, we=0, addr=0x0, outstanding=0/3, posted |
| SP-34 | test-mode | KILLED | CHECK | ['test_port_mode', 'seed1'] | albionverify.core.AlbionCheckError: [sp/sp @cycle 77] tst_rdata word 0x1 mismatch: lane2 exp=0x50 got=0x48; lane3 exp=0xb3 got=0x50 (test re |
