# Mutation report: fab_arbiter

Baseline (unmutated RTL): 3 run(s), all PASS.

**Mutation score: 100.0%** (15 killed / 0 survived; 2 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 15 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| FA-01 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 1755] arbiter: grant 0x2, model expects 0x4 (req=0x6 stall=1 accept=0 ptr=1 lock=2) |
| FA-02 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 2879] arbiter: grant 0x1, model expects 0x2 (req=0x2 stall=0 accept=1 ptr=0 lock=0) |
| FA-03 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 6] arbiter: grant 0x1, model expects 0x2 (req=0x7 stall=0 accept=1 ptr=1 lock=None) |
| FA-04 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 1205] arbiter: grant 0x2, model expects 0x1 (req=0x7 stall=0 accept=1 ptr=0 lock=None |
| FA-05 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 6] arbiter: grant 0x1, model expects 0x2 (req=0x7 stall=0 accept=1 ptr=1 lock=None) |
| FA-06 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 5] arbiter: grant 0x4, model expects 0x1 (req=0x7 stall=0 accept=1 ptr=0 lock=None) |
| FA-07 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 1747] arbiter: grant 0x0, model expects 0x1 (req=0x1 stall=0 accept=1 ptr=1 lock=None |
| FA-08 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 756] arbiter: grant 0x1, model expects 0x2 (req=0x7 stall=0 accept=1 ptr=1 lock=1) |
| FA-09 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_reset @cycle 5] arbiter: grant 0x2, model expects 0x1 (req=0x7 stall=0 accept=1 ptr=0 lock=None) |
| FA-10 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 6] arbiter: grant 0x1, model expects 0x2 (req=0x7 stall=0 accept=1 ptr=1 lock=None) |
| FA-11 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 8] arbiter: grant 0x2, model expects 0x1 (req=0x7 stall=0 accept=1 ptr=0 lock=None) |
| FA-12 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 1742] arbiter: grant 0x4, model expects 0x2 (req=0x6 stall=1 accept=0 ptr=1 lock=None |
| FA-13 | equivalent | EQUIVALENT_SURVIVED |  |  | After reset lock_idx_q = 0 and prio_q = 0 (both still reset by the patched RTL).  A stale lock_q = 1 only selects requester 0 when req[0] is |
| FA-14 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 1748] arbiter: grant 0x2, model expects 0x0 (req=0x0 stall=0 accept=0 ptr=1 lock=None |
| FA-15 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_phases @cycle 8] arbiter: grant 0x1, model expects 0x8 (req=0xf stall=0 accept=1 ptr=3 lock=None) |
| FA-16 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [arb_reset @cycle 130] arbiter: grant 0x4, model expects 0x2 (req=0x6 stall=0 accept=1 ptr=0 lock=None) |
| FA-90 | equivalent | EQUIVALENT_SURVIVED |  |  | stall means 'the granted request was presented to the slave and not accepted'; in every protocol-legal use (crossbar: stall = s_req_valid && |
