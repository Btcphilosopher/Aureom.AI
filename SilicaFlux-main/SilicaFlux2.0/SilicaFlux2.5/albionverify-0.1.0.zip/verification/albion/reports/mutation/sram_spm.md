# Mutation report: sram_spm

Baseline (unmutated RTL): 16 run(s), all PASS.

**Mutation score: 100.0%** (30 killed / 0 survived; 2 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 29 kills came from scoreboard/protocol/model checks, 1 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| SM-01 | address-range | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 347] req_ready[0] mismatch: expected 1, got 0 (live=1 we=1 addr=0x0 code=1 bank=0 row=0  |
| SM-02 | error-response | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 176] ev_error[0] mismatch: expected 0x1, got 0x0 / recent: c168 p2 W a=0x43fc ; c169 p1  |
| SM-03 | error-response | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 116] ev_error[3] mismatch: expected 0x1, got 0x0 / recent: c105 p3 W a=0x77c ; c106 p2 W |
| SM-04 | error-response | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 132] rsp_err_code[1] mismatch [port 1 err_write addr 0x46a]: expected 0x2, got 0x3 / rec |
| SM-05 | bank-select | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 8] req_ready[1] mismatch: expected 1, got 0 (live=1 we=1 addr=0x4004 code=0 bank=1 row=0 |
| SM-06 | bank-select | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 76] req_ready[2] mismatch: expected 0, got 1 (live=1 we=0 addr=0x424 code=0 bank=3 row=2 |
| SM-07 | bank-select | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 8] req_ready[1] mismatch: expected 1, got 0 (live=1 we=1 addr=0x8 code=0 bank=0 row=1 ou |
| SM-08 | arbitration | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 222] req_ready[1] mismatch: expected 0, got 1 (live=1 we=0 addr=0x43fc code=0 bank=3 row |
| SM-09 | arbitration | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 25] req_ready[1] mismatch: expected 0, got 1 (live=1 we=1 addr=0x68 code=0 bank=0 row=13 |
| SM-10 | arbitration | KILLED | CHECK | ['bank_conflicts', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 145] req_ready[3] mismatch: expected 0, got 1 (live=1 we=1 addr=0x698 code=0 bank=3 row= |
| SM-11 | arbitration | KILLED | CHECK | ['bank_conflicts', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 144] req_ready[1] mismatch: expected 0, got 1 (live=1 we=0 addr=0x698 code=0 bank=3 row= |
| SM-12 | arbitration | KILLED | ASSERT | ['byte_strobes', 'seed1'] | 0] %Error: sram_generic_2rw.sv:93: Assertion failed in hpc_scratchpad.g_core.g_bank[0].u_bank.g_ram.u_ram.g_generic.u_mem: hpc_scratchpad.g_ |
| SM-13 | arbitration | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 76] req_ready[0] mismatch: expected 1, got 0 (live=1 we=0 addr=0x42c code=0 bank=1 row=2 |
| SM-14 | arbitration | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 341] req_ready[1] mismatch: expected 1, got 0 (live=1 we=0 addr=0x400c code=0 bank=3 row |
| SM-15 | reset | KILLED | CHECK | ['reset_during_traffic', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 106] req_ready[0] mismatch: expected 1, got 0 (live=1 we=1 addr=0x4238 code=0 bank=2 row |
| SM-16 | error-response | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 282] rsp_valid[1] (response due since cycle 282, kind err_write) mismatch [missing / lat |
| SM-17 | flow-control | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 167] req_ready[1] mismatch: expected 0, got 1 (live=1 we=1 addr=0x3e90 code=1 bank=0 row |
| SM-18 | events | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 11] ev_conflict[2] mismatch: expected 0x0, got 0x1 / recent: c8 p0 W a=0x4000 ; c8 p1 W  |
| SM-19 | events | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 167] ev_error[1] mismatch: expected 0x0, got 0x1 / recent: c150 p2 W a=0x43ec ; c151 p1  |
| SM-20 | events | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 8] ev_bank_ops[0] mismatch: expected 0x2, got 0x1 / recent: |
| SM-21 | events | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 16] ev_bank_conflict[2] mismatch: expected 0x1, got 0x0 / recent: c10 p0 W a=0x4018 ; c1 |
| SM-22 | reset | KILLED | CHECK | ['reset_during_traffic', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 20] req_ready[0] mismatch: expected 0, got 1 (live=0 we=1 addr=0x794 code=0 bank=0 row=5 |
| SM-23 | flow-control | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 11] req_ready[2] mismatch: expected 0, got 1 (live=1 we=1 addr=0x402c code=0 bank=3 row= |
| SM-24 | latency | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 10] rsp_valid[0] (nothing due) mismatch [unsolicited / early response]: expected 0x0, go |
| SM-25 | byte-enable | KILLED | CHECK | ['byte_strobes', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 15] rsp_rdata[2] word 0x0 mismatch: lane1 exp=0x7c got=0xf5; lane3 exp=0x7f got=0x8e (ki |
| SM-26 | response-routing | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 119] rsp_rdata[0] word 0x2 mismatch: lane1 exp=0x74 got=0xfc; lane3 exp=0x7d got=0xff (k |
| SM-27 | error-response | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 181] rsp_err_code[0] mismatch [port 0 err_write addr 0x406a]: expected 0x2, got 0x1 / re |
| SM-28 | counters | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 276] perf_cycles mismatch: expected 0xff, got 0xf / recent: c261 p2 R a=0x404 ; c262 p3  |
| SM-29 | counters | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 20] perf_conflict[1] mismatch: expected 0x1, got 0x0 / recent: c14 p1 W a=0x404c ; c14 p |
| SM-30 | counters | KILLED | CHECK | ['map_data', 'seed1'] | albionverify.core.AlbionCheckError: [spm/spm @cycle 20] perf_wait[0] mismatch: expected 0x2, got 0xc / recent: c14 p1 W a=0x404c ; c14 p2 W  |
| SM-31 | response-masking | EQUIVALENT_SURVIVED |  |  | With ECC_MODE = NONE (every configuration of this suite) the response path already delivers all-zero data for every error response: sram_rsp |
| SM-32 | byte-enable | EQUIVALENT_SURVIVED |  |  | With BYTE_WE = 0 the address map rejects every write whose strobe is not all-ones (STROBE error, no bank access), so a bank only ever sees a |
