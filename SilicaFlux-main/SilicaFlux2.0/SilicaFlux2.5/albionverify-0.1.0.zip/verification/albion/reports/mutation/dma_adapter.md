# Mutation report: dma_adapter

Baseline (unmutated RTL): 14 run(s), all PASS.

**Mutation score: 100.0%** (24 killed / 0 survived; 2 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 22 kills came from scoreboard/protocol/model checks, 1 from an assertion inside the RTL aborting the simulation, 1 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| DA-01 | region | KILLED | CHECK | ['rejects_and_region', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 236] adapter: completion pushed without the engine for a descriptor that is not a REGION |
| DA-02 | region | KILLED | CHECK | ['rejects_and_region', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 287] adapter: completion pushed without the engine for a descriptor that is not a REGION |
| DA-03 | region | KILLED | CHECK | ['rejects_and_region', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 131] adapter: completion record (tag,err,code,err_addr,bytes) = (232, 1, 11, 536871936,  |
| DA-04 | precedence | KILLED | CHECK | ['rejects_and_region', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 40] adapter: completion pushed without the engine for a descriptor that is not a REGION  |
| DA-05 | region | KILLED | CHECK | ['rejects_and_region', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 138] adapter: the REGION rule must reject descriptor src=0x30000000 dst=0x1ffffffc len=8 |
| DA-06 | completion-queue | KILLED | CHECK | ['queues_and_order', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 28] adapter: a descriptor was started with the completion queue full (2 of 2 records; a  |
| DA-07 | descriptor-queue | KILLED | ASSERT | ['directions_lengths', 'seed1'] | ngths (1/1)                                                           All four directions, every length 1 .. 3*DW/8+1 and burst / FIFO bound |
| DA-08 | status | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 10] adapter: busy pin=0 with 1 descriptor(s) accepted and not yet completed (edge 10) |
| DA-09 | bytes | KILLED | CHECK | ['rejects_and_region', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 33] adapter: completion record (tag,err,code,err_addr,bytes) = (111, 1, 2, 0, 257), expe |
| DA-10 | tag | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 21] adapter: completion record (tag,err,code,err_addr,bytes) = (43, 0, 0, 0, 1), expecte |
| DA-11 | routing | KILLED | CHECK | ['rejects_and_region', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 313] adapter: request 0x20000400 went to the spm target, the address belongs to the fab  |
| DA-12 | routing | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 16] adapter: reference model: edge 16: write beat 0 data 0x0 differs from the read data  |
| DA-13 | routing | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 15] adapter: completion produced with only 0 of 1 beats written and acknowledged (no err |
| DA-14 | byte-enable | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 16] adapter: reference model: edge 16: write beat 0 strobe 0xf, expected 0x1 (length 1,  |
| DA-15 | byte-enable | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 1492] adapter: reference model: edge 1492: write beat 0 strobe 0xf, expected 0x1 (length |
| DA-16 | flow-control | KILLED | LIVENESS | ['directions_lengths', 'seed1'] | albionverify.core.LivenessError: [adapter @cycle 60006] liveness: all descriptors to complete not reached within 60000 cycles |
| DA-17 | tag-check | KILLED | CHECK | ['errors_and_abort', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 963] adapter: reference model: edge 963: write of beat 0 issued although its read failed |
| DA-18 | tag-check | KILLED | CHECK | ['errors_and_abort', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 983] adapter: reference model: edge 983: write of beat 1 issued although its read failed |
| DA-19 | tag | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 20] adapter: ev_cpl_err=1 but the completion code is NONE |
| DA-20 | perf | KILLED | CHECK | ['random_descriptors', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 2640] adapter perf counter BYTES_WR = 845, testbench total 825 |
| DA-21 | perf | KILLED | CHECK | ['random_descriptors', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 2640] adapter perf counter BYTES_RD = 924, testbench total 900 |
| DA-22 | perf | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 7178] adapter perf counter SPM_REQ = 1100, testbench total 972 |
| DA-23 | perf | KILLED | CHECK | ['errors_and_abort', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 3571] adapter perf counter READS = 354, testbench total 227 |
| DA-24 | perf | KILLED | CHECK | ['directions_lengths', 'seed1'] | albionverify.core.AlbionCheckError: [adapter @cycle 2792] adapter perf counter READS = 196, testbench total 255 |
| DA-25 | ownership | EQUIVALENT_SURVIVED |  |  | The engines never present a request to a different target while a response of the same port is outstanding: the simple engine has one transa |
| DA-26 | ownership | EQUIVALENT_SURVIVED |  |  | The engines bound their own outstanding count to MAX_OUT (credit: rd_iss-rd_rsp < MAX_OUT) so the router's cnt never exceeds MAX_OUT; the ex |
