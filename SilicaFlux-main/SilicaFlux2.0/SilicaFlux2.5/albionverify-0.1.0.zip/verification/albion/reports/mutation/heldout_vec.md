# Mutation report: heldout_vec

Baseline (unmutated RTL): 8 run(s), all PASS.

**Mutation score: 100.0%** (1 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 1 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| HV-1 | arithmetic | KILLED | CHECK | ['reset_mid_pipeline', 'seed1'] | albionverify.core.AlbionCheckError: [vec_lane @cycle 104] mon: out_result mismatch: expected 0x28a164dd got 0xa8a164dd |
