# Mutation report: heldout_gate

Baseline (unmutated RTL): 7 run(s), all PASS.

**Mutation score: 100.0%** (1 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 1 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| HC-2 | idle-status | KILLED | CHECK | ['forward_directed', 'seed1'] | albionverify.core.AlbionCheckError: [gate/gate @cycle 6] idle mismatch [cyc=6 sel=0 we=0 addr=0x000 wdata=0x00000000 rst=- inputs={'s_req_va |
