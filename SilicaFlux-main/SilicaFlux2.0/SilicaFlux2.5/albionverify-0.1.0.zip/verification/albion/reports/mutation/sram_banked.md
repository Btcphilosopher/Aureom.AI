# Mutation report: sram_banked

Baseline (unmutated RTL): 23 run(s), all PASS.

**Mutation score: 100.0%** (30 killed / 0 survived; 1 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 29 kills came from scoreboard/protocol/model checks, 1 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| BM-01 | bank-select | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 8] m_req_ready[1] mismatch: expected 1, got 0 (live=1 we=1 addr=0x1 ok=1 bank=1 outsta |
| BM-02 | bank-select | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 30] m_rsp_rdata[0] word 0x3 mismatch: lane0 exp=0x54 got=0xa8; lane1 exp=0xf0 got=0xe0 |
| BM-03 | bank-select | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 19] m_req_ready[1] mismatch: expected 1, got 0 (live=1 we=1 addr=0x4 ok=1 bank=0 outst |
| BM-04 | boundary | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 44] m_rsp_err[2] mismatch [master 2 err_read addr 0x40]: expected 0x1, got 0x0 / recen |
| BM-05 | error-response | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 59] m_req_ready[1] mismatch: expected 1, got 0 (live=1 we=0 addr=0x2a ok=0 bank=0 outs |
| BM-06 | address-map | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 14] m_req_ready[1] mismatch: expected 0, got 1 (live=1 we=1 addr=0x4 ok=1 bank=0 outst |
| BM-07 | interleave | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 8] m_req_ready[1] mismatch: expected 1, got 0 (live=1 we=1 addr=0x1 ok=1 bank=1 outsta |
| BM-08 | boundary | KILLED | ASSERT | ['map_integrity', 'seed1'] | iasing or lost write shows up as wrong data.  Then lane-masked partial writes. [185000] %Error: sram_generic_1rw.sv:122: Assertion failed in |
| BM-09 | arbitration | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 79] m_req_ready[0] mismatch: expected 0, got 1 (live=1 we=1 addr=0x3a ok=1 bank=2 outs |
| BM-10 | arbitration | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 79] m_req_ready[0] mismatch: expected 0, got 1 (live=1 we=1 addr=0x3a ok=1 bank=2 outs |
| BM-11 | arbitration | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 79] m_req_ready[0] mismatch: expected 0, got 1 (live=1 we=1 addr=0x3a ok=1 bank=2 outs |
| BM-12 | arbitration | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 9] m_req_ready[1] mismatch: expected 1, got 0 (live=1 we=1 addr=0xc ok=1 bank=2 outsta |
| BM-13 | arbitration | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 8] m_req_ready[0] mismatch: expected 1, got 0 (live=1 we=1 addr=0x0 ok=1 bank=0 outsta |
| BM-14 | arbitration | KILLED | CHECK | ['arbitration_order', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 11] m_req_ready[0] mismatch: expected 1, got 0 (live=1 we=0 addr=0x0 ok=1 bank=0 outst |
| BM-15 | flow-control | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 10] m_req_ready[0] mismatch: expected 0, got 1 (live=1 we=1 addr=0x8 ok=1 bank=0 outst |
| BM-16 | flow-control | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 2] m_req_ready[0] while rst_n low mismatch: expected 0x0, got 0x1 / recent: |
| BM-17 | perf-flag | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 8] m_stall_conflict[0] mismatch [valid=1]: expected 0x0, got 0x1 / recent: |
| BM-18 | perf-flag | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 10] m_stall_conflict[0] mismatch [valid=1]: expected 0x0, got 0x1 / recent: c8 m0 W a= |
| BM-19 | reset | KILLED | CHECK | ['reset_during_traffic', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 32] m_req_ready[0] mismatch: expected 0, got 1 (live=0 we=1 addr=0x30 ok=1 bank=0 outs |
| BM-20 | reset | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 2] m_req_ready[0] while rst_n low mismatch: expected 0x0, got 0x1 / recent: |
| BM-21 | flow-control | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 10] m_req_ready[0] mismatch: expected 0, got 1 (live=1 we=1 addr=0x8 ok=1 bank=0 outst |
| BM-22 | byte-enable | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 89] m_rsp_rdata[2] word 0x3a mismatch: lane1 exp=0xc7 got=0x38; lane3 exp=0x2f got=0x6 |
| BM-23 | data-path | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 30] m_rsp_rdata[0] word 0x3 mismatch: lane0 exp=0x54 got=0x15; lane1 exp=0xf0 got=0x7c |
| BM-24 | response-routing | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 30] m_rsp_rdata[0] word 0x3 mismatch: lane0 exp=0x54 got=0x7f; lane1 exp=0xf0 got=0xfc |
| BM-25 | response-routing | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 111] m_rsp_rdata[0] word 0x1 mismatch: lane0 exp=0x2a got=0x3f; lane1 exp=0xf8 got=0xf |
| BM-26 | response-id | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 9] m_rsp_id[0] mismatch [master 0 write_ack addr 0x0]: expected 0x0, got 0x1 / recent: |
| BM-27 | write-ack | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 9] m_rsp_valid[0] (response due since cycle 9, kind write_ack) mismatch [missing / lat |
| BM-28 | error-response | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 63] m_rsp_valid[0] (response due since cycle 63, kind err_write) mismatch [missing / l |
| BM-29 | error-response | KILLED | CHECK | ['error_requests', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 61] m_rsp_err[1] mismatch [master 1 err_read addr 0x2a]: expected 0x1, got 0x0 / recen |
| BM-30 | latency | KILLED | CHECK | ['map_integrity', 'seed1'] | albionverify.core.AlbionCheckError: [bank/bank @cycle 10] m_rsp_valid[0] (nothing due) mismatch [unsolicited / early response]: expected 0x0 |
| BM-31 | routing-assertion-only | EQUIVALENT_SURVIVED |  |  | bk_rd only feeds the owner-valid pipeline whose output (m_arr / m_owned) is consumed (a) by the response path, which masks the data with stg |
