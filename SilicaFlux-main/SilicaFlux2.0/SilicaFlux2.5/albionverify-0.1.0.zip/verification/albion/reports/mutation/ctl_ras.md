# Mutation report: ctl_ras

Baseline (unmutated RTL): 9 run(s), all PASS.

**Mutation score: 97.3%** (36 killed / 0 survived; 0 argued-equivalent survivors excluded; 1 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 36 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CR-01 | w1c | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 139] irq_warn mismatch [cyc=139 sel=0 we=0 addr=0xb3d wdata=0x3369cef8 rst=- inputs={'ev |
| CR-02 | priority | KILLED | CHECK | ['level_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 21] irq_warn mismatch [cyc=21 sel=0 we=1 addr=0x4b1 wdata=0xe95ad74d rst=- inputs={'ev_b |
| CR-03 | w1c | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 144] irq_fatal mismatch [cyc=144 sel=0 we=0 addr=0xb9e wdata=0x1d2f78a0 rst=- inputs={'e |
| CR-04 | level | KILLED | CHECK | ['level_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 21] irq_warn mismatch [cyc=21 sel=0 we=1 addr=0x4b1 wdata=0xe95ad74d rst=- inputs={'ev_b |
| CR-05 | inject | KILLED | CHECK | ['sw_report_inject_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 108] rb_rdata mismatch [cyc=108 sel=1 we=0 addr=0x000 wdata=0x53782499 rst=- inputs={'ev |
| CR-06 | inject | KILLED | CHECK | ['sw_report_inject_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 111] fatal_pin mismatch [cyc=111 sel=0 we=0 addr=0x4a8 wdata=0xc8fc8123 rst=- inputs={'e |
| CR-07 | sw | KILLED | CHECK | ['sw_report_inject_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 7] fatal_pin mismatch [cyc=7 sel=0 we=1 addr=0xd4c wdata=0x71732e3e rst=- inputs={'ev_bu |
| CR-08 | sw | KILLED | CHECK | ['sw_report_inject_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 20] rb_rdata mismatch [cyc=20 sel=1 we=0 addr=0x02c wdata=0x6979af21 rst=- inputs={'ev_b |
| CR-09 | enable | KILLED | CHECK | ['random_traffic', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 131] rb_rdata mismatch [cyc=131 sel=1 we=0 addr=0x004 wdata=0xeb2e42bc rst=- inputs={'ev |
| CR-10 | irq | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 11] irq_warn mismatch [cyc=11 sel=0 we=1 addr=0x835 wdata=0x309b0d46 rst=- inputs={'ev_b |
| CR-11 | irq | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 135] irq_fatal mismatch [cyc=135 sel=0 we=0 addr=0xf0a wdata=0x03421162 rst=- inputs={'e |
| CR-12 | irq | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 106] irq_fatal mismatch [cyc=106 sel=0 we=1 addr=0xcd4 wdata=0x0ff0b6e2 rst=- inputs={'e |
| CR-13 | pin | KILLED | CHECK | ['level_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 73] fatal_pin mismatch [cyc=73 sel=0 we=0 addr=0xee9 wdata=0xf406c4ff rst=- inputs={'ev_ |
| CR-14 | pin | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 106] fatal_iso mismatch [cyc=106 sel=0 we=1 addr=0xcd4 wdata=0x0ff0b6e2 rst=- inputs={'e |
| CR-15 | pin | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 11] fatal_pin mismatch [cyc=11 sel=0 we=1 addr=0x835 wdata=0x309b0d46 rst=- inputs={'ev_ |
| CR-16 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 18] rb_rdata mismatch [cyc=18 sel=1 we=0 addr=0x030 wdata=0xfd6d08d2 rst=- inputs={'ev_b |
| CR-17 | reset | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 7] rb_rdata mismatch [cyc=7 sel=1 we=0 addr=0x004 wdata=0xd4c9f877 rst=- inputs={'ev_bus |
| CR-18 | counter | KILLED | CHECK | ['first_last_counters_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 60] rb_rdata mismatch [cyc=60 sel=1 we=0 addr=0x00c wdata=0xca4cda37 rst=- inputs={'ev_b |
| CR-19 | counter | KILLED | CHECK | ['level_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 25] rb_rdata mismatch [cyc=25 sel=1 we=0 addr=0x00c wdata=0x0a613858 rst=- inputs={'ev_b |
| CR-20 | counter | KILLED | CHECK | ['level_at_reset_release', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 14] rb_rdata mismatch [cyc=14 sel=1 we=0 addr=0x010 wdata=0x8d7275f4 rst=- inputs={'ev_b |
| CR-21 | counter | KILLED | CHECK | ['first_last_counters_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 54] rb_rdata mismatch [cyc=54 sel=1 we=0 addr=0x00c wdata=0x55e56a96 rst=- inputs={'ev_b |
| CR-22 | counter | UNOBSERVABLE_SURVIVED |  |  | UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs only after 2^32 - 1 counted events (4.29e9 cycles at one event per |
| CR-23 | first | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 44] rb_rdata mismatch [cyc=44 sel=1 we=0 addr=0x014 wdata=0x74ea2a73 rst=- inputs={'ev_b |
| CR-24 | first | KILLED | CHECK | ['first_last_counters_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 28] rb_rdata mismatch [cyc=28 sel=1 we=0 addr=0x014 wdata=0xa516ac13 rst=- inputs={'ev_b |
| CR-25 | last | KILLED | CHECK | ['first_last_counters_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 50] rb_rdata mismatch [cyc=50 sel=1 we=0 addr=0x01c wdata=0x97c19098 rst=- inputs={'ev_b |
| CR-26 | first | KILLED | CHECK | ['random_traffic', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 5054] rb_rdata mismatch [cyc=5054 sel=1 we=0 addr=0x018 wdata=0x47075fa4 rst=- inputs={' |
| CR-27 | addr | KILLED | CHECK | ['pulse_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 118] rb_rdata mismatch [cyc=118 sel=1 we=0 addr=0x020 wdata=0xce8141ad rst=- inputs={'ev |
| CR-28 | addr | KILLED | CHECK | ['sw_report_inject_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 14] rb_rdata mismatch [cyc=14 sel=1 we=0 addr=0x018 wdata=0xf2a34717 rst=- inputs={'ev_b |
| CR-29 | parity | KILLED | CHECK | ['parity_controls_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 26] par_inject mismatch [cyc=26 sel=0 we=0 addr=0xe00 wdata=0x858f88fc rst=- inputs={'ev |
| CR-30 | parity | KILLED | CHECK | ['parity_controls_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 39] par_inject mismatch [cyc=39 sel=0 we=1 addr=0xd33 wdata=0xcecfaaf2 rst=- inputs={'ev |
| CR-31 | parity | KILLED | CHECK | ['parity_controls_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 7] par_chk_en mismatch [cyc=7 sel=0 we=1 addr=0xd4c wdata=0x71732e3e rst=- inputs={'ev_b |
| CR-32 | read | KILLED | CHECK | ['level_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 18] rb_rdata mismatch [cyc=18 sel=1 we=0 addr=0x03c wdata=0xb66fc895 rst=- inputs={'ev_b |
| CR-33 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 1031] rb_err mismatch [cyc=1031 sel=1 we=1 addr=0x00c wdata=0xffffffff rst=- inputs={'ev |
| CR-34 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 22] rb_err mismatch [cyc=22 sel=1 we=0 addr=0x040 wdata=0x7f0021b7 rst=- inputs={'ev_bus |
| CR-35 | error | KILLED | CHECK | ['reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 15] rb_err mismatch [cyc=15 sel=1 we=0 addr=0x024 wdata=0xb7fc87af rst=- inputs={'ev_bus |
| CR-36 | level | KILLED | CHECK | ['level_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 25] rb_rdata mismatch [cyc=25 sel=1 we=0 addr=0x00c wdata=0x0a613858 rst=- inputs={'ev_b |
| CR-37 | ctrl | KILLED | CHECK | ['level_sources_directed', 'seed1'] | albionverify.core.AlbionCheckError: [ras/ras @cycle 73] fatal_pin mismatch [cyc=73 sel=0 we=0 addr=0xee9 wdata=0xf406c4ff rst=- inputs={'ev_ |

## Survivors unobservable through the ports (verification limit, NOT proven equivalent)

* **CR-22** (counter): Counters wrap instead of saturating at 2^32-1 (not observable in simulation). -- UNOBSERVABLE (not proven equivalent; a bounded-simulation limit): Differs only after 2^32 - 1 counted events (4.29e9 cycles at one event per cycle): unreachable in any bounded simulation; the saturation rule is covered by model unit tests o
