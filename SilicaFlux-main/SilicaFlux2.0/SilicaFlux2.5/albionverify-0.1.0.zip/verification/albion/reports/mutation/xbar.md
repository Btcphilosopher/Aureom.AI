# Mutation report: xbar

Baseline (unmutated RTL): 10 run(s), all PASS.

**Mutation score: 100.0%** (57 killed / 0 survived; 5 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 57 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| FX-01 | address-map | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 29] LOCKSTEP m_req_ready[2]: model expects 1, DUT drives 0  [model state: out=[0 |
| FX-02 | address-map | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 11] LOCKSTEP m_req_ready[2]: model expects 0, DUT drives 1  [model state: out=[0 |
| FX-03 | access-matrix | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 6] LOCKSTEP m_req_ready[2]: model expects 1, DUT drives 0  [model state: out=[0, |
| FX-04 | access-matrix | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 6] LOCKSTEP m_req_ready[2]: model expects 1, DUT drives 0  [model state: out=[0, |
| FX-05 | address-map | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 6] LOCKSTEP s_req_valid[0]: model expects 1, DUT drives 0  [model state: out=[0, |
| FX-06 | alignment | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 50] LOCKSTEP s_req_valid[0]: model expects 0, DUT drives 1  [model state: out=[0 |
| FX-07 | alignment | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 9] LOCKSTEP m_req_ready[0]: model expects 0, DUT drives 1  [model state: out=[1, |
| FX-08 | address-map | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 23] LOCKSTEP s_req_valid[1]: model expects 0, DUT drives 1  [model state: out=[1 |
| FX-09 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 50] LOCKSTEP s_req_valid[0]: model expects 0, DUT drives 1  [model state: out=[0 |
| FX-10 | routing | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 8] LOCKSTEP s_req_write[0]: model expects 1, DUT drives 0  [model state: out=[0, |
| FX-11 | routing | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 8] LOCKSTEP m_req_ready[2]: model expects 1, DUT drives 0  [model state: out=[0, |
| FX-12 | throughput | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 7] LOCKSTEP m_req_ready[2]: model expects 1, DUT drives 0  [model state: out=[1, |
| FX-13 | throughput | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 9] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out=[1, |
| FX-14 | outstanding | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries/xbar @cycle 17] LOCKSTEP ev_arb_loss[1]: model expects 0, DUT drives 1  [model state: ou |
| FX-15 | outstanding | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries @cycle 17] mon_m1: PROTOCOL VIOLATION: R4: response withdrawn before acceptance (rsp_val |
| FX-16 | response-routing | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 9] LOCKSTEP m_rsp_error[0]: model expects 1, DUT drives 0  [model state: out=[1, |
| FX-17 | outstanding | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden @cycle 28] mon_m2: PROTOCOL VIOLATION: R6: 2 transactions outstanding on a port limited to 1 |
| FX-18 | outstanding | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden @cycle 12] mon_s0: PROTOCOL VIOLATION: R6: 2 transactions outstanding on a port limited to 1 |
| FX-19 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries/xbar @cycle 27] LOCKSTEP m_req_ready[0]: model expects 0, DUT drives 1  [model state: ou |
| FX-20 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries @cycle 28] mon_s0: PROTOCOL VIOLATION: R2: request payload changed while stalled: (0, 26 |
| FX-21 | error-capture | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 6] LOCKSTEP err_master: model expects 0, DUT drives 2  [model state: out=[0, 0,  |
| FX-22 | error-capture | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 7] LOCKSTEP err_addr: model expects 0xffffffc, DUT drives 0x93b5af38  [model sta |
| FX-23 | error-capture | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 6] LOCKSTEP err_write: model expects 1, DUT drives 0  [model state: out=[0, 0, 0 |
| FX-24 | error-capture | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 6] LOCKSTEP err_evt: model expects 1, DUT drives 0  [model state: out=[0, 0, 0]  |
| FX-25 | perf-event | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 8] LOCKSTEP ev_arb_loss[2]: model expects 0, DUT drives 1  [model state: out=[0, |
| FX-26 | perf-event | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 12] LOCKSTEP ev_arb_loss[0]: model expects 0, DUT drives 1  [model state: out=[1 |
| FX-27 | perf-event | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 2] R11: ev_req_stall asserted during reset ([1, 1, 1]) |
| FX-28 | perf-event | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 2] R11: ev_rsp_stall asserted during reset ([1, 1, 1]) |
| FX-29 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 8] LOCKSTEP s_req_wdata[0]: model expects 0x7b24de4f, DUT drives 0xde4f  [model  |
| FX-30 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 28] LOCKSTEP s_req_addr[1]: model expects 0x80000000, DUT drives 0  [model state |
| FX-31 | byte-enable | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 8] LOCKSTEP s_req_wstrb[0]: model expects 0xa, DUT drives 0  [model state: out=[ |
| FX-32 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [slave_errors/xbar @cycle 8] LOCKSTEP m_rsp_error[0]: model expects 1, DUT drives 0  [model state: out=[ |
| FX-33 | flow-control | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries/xbar @cycle 16] LOCKSTEP s_rsp_ready[1]: model expects 0, DUT drives 1  [model state: ou |
| FX-34 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden @cycle 7] mon_m0: PROTOCOL VIOLATION: R8: rsp_error=1 but rsp_rdata=0x47860e18 (must be 0) |
| FX-35 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 11] LOCKSTEP m_rsp_rdata[2]: model expects 0x7b11dee7, DUT drives 0xe77b11de  [m |
| FX-36 | error-response | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries @cycle 30] mon_m1: PROTOCOL VIOLATION: R4: response withdrawn before acceptance (rsp_val |
| FX-37 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [reset_sync_states/xbar @cycle 17] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: |
| FX-38 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 29] LOCKSTEP m_req_ready[2]: model expects 1, DUT drives 0  [model state: out=[0 |
| FX-39 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 2] R11: m_rsp_valid asserted during reset ([1, 1, 1]) |
| FX-40 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [reset_glitch/xbar @cycle 14] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out= |
| FX-41 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries @cycle 54] mon_s1: PROTOCOL VIOLATION: R2: request payload changed while stalled: (0, 26 |
| FX-42 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [lock_release_on_withdraw/xbar @cycle 15] LOCKSTEP ev_arb_loss[0]: model expects 0, DUT drives 1  [model |
| FX-43 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 14] LOCKSTEP m_req_ready[0]: model expects 0, DUT drives 1  [model state: out=[1 |
| FX-44 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [lock_withdraw_pointer/xbar @cycle 16] LOCKSTEP ev_arb_loss[0]: model expects 0, DUT drives 1  [model st |
| FX-45 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 9] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out=[1, |
| FX-46 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 8] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out=[0, |
| FX-47 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 38] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out=[0 |
| FX-48 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries @cycle 33] mon_s0: PROTOCOL VIOLATION: R2: request payload changed while stalled: (0, 26 |
| FX-49 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries/xbar @cycle 6] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out |
| FX-50 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 9] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out=[1, |
| FX-51 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 9] LOCKSTEP m_req_ready[0]: model expects 1, DUT drives 0  [model state: out=[1, |
| FX-52 | arbitration | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 10] LOCKSTEP m_req_ready[0]: model expects 0, DUT drives 1  [model state: out=[1 |
| FX-53 | equivalent | EQUIVALENT_SURVIVED |  |  | After reset lock_idx_q = 0 and prio_q = 0 (both still reset by the patched RTL).  A stale lock_q = 1 only selects requester 0 when req[0] is |
| FX-54 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 12] LOCKSTEP m_rsp_rdata[0]: model expects 0xd877900073bf3eb, DUT drives 0x87790 |
| FX-55 | byte-enable | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 10] LOCKSTEP s_req_wstrb[1]: model expects 0xffff, DUT drives 0xefff  [model sta |
| FX-56 | error-capture | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 7] LOCKSTEP err_master: model expects 1, DUT drives 0  [model state: out=[1, 0,  |
| FX-57 | response-routing | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_boundaries/xbar @cycle 8] LOCKSTEP s_rsp_ready[2]: model expects 1, DUT drives 0  [model state: out |
| FX-58 | alignment | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [map_golden/xbar @cycle 7] LOCKSTEP m_req_ready[1]: model expects 1, DUT drives 0  [model state: out=[1, |
| FX-90 | equivalent | EQUIVALENT_SURVIVED |  |  | e_req_valid[m] already contains m_free[m] = ~out_q[m] / m_rsp_hs[m], and sfb_error_slave.req_ready = ~pend_q / rsp_ready.  The error slave's |
| FX-91 | equivalent | EQUIVALENT_SURVIVED |  |  | With busy = 0 the stale owner one-hot would steer s_rsp_ready / s_rsp_valid of an IDLE slave.  A protocol-compliant slave (PROTOCOL.md R5: e |
| FX-92 | equivalent | EQUIVALENT_SURVIVED |  |  | cand[gm] is also qualified by dec_oh[gm*NS+gs], and dec_oh comes from sfb_addr_decoder instantiated with .EN(MST_SLV_EN[gm*NS +: NS]): the d |
| FX-93 | equivalent | EQUIVALENT_SURVIVED |  |  | Same argument as FX-92: dec_oh[m*NS+s] already implies MST_SLV_EN[m*NS+s] (the decoder is instantiated with the master's EN row), so the exp |
