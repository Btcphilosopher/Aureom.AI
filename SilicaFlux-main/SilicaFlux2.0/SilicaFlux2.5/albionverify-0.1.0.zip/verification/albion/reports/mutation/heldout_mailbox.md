# Mutation report: heldout_mailbox

Baseline (unmutated RTL): 11 run(s), all PASS.

**Mutation score: 100.0%** (1 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 1 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| HC-1 | fifo-boundary | KILLED | CHECK | ['console_fifo', 'seed1'] | albionverify.core.AlbionCheckError: [mbox/mbox @cycle 528] rb_rdata mismatch [cyc=528 sel=1 we=0 addr=0x08c wdata=0x19379618 rst=- inputs={' |
