# Mutation report: dma_buffered

Baseline (unmutated RTL): 8 run(s), all PASS.

**Mutation score: 100.0%** (30 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 29 kills came from scoreboard/protocol/model checks, 1 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| DB-01 | fifo-credit | KILLED | ASSERT | ['all', 'seed1'] | NFO     cocotb.regression                  running backpressure (8/8)                                                           Long request |
| DB-02 | outstanding | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 540] mon0: PROTOCOL VIOLATION: R6: 3 transactions outstanding on a port limited to 2 |
| DB-03 | outstanding | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 629] mon1: PROTOCOL VIOLATION: R6: 3 transactions outstanding on a port limited to 2 |
| DB-04 | length | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 635] DMA reference model: edge 634: write beat 1 strobe 0x1, expected 0xf (length 9, SB 4) |
| DB-05 | byte-enable | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 644] DMA reference model: edge 643: write beat 2 strobe 0x3, expected 0x1 (length 9, SB 4) |
| DB-06 | bytes-done | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 647] DMA reference model: edge 646: bytes_done pin=12, expected 9 |
| DB-07 | byte-enable | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 644] DMA reference model: edge 643: write beat 2 strobe 0xf, expected 0x1 (length 9, SB 4) |
| DB-08 | read-error | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 422] DMA reference model: edge 421: write of beat 0 issued although its read failed (a write |
| DB-09 | abort | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 54] DMA reference model: edge 53: new read request presented (since edge 53) after ABORT was |
| DB-10 | abort | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 129] DMA reference model: edge 128: new write request presented (since edge 128) after ABORT |
| DB-11 | write-error | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 761] DMA reference model: edge 760: new write request presented (since edge 760) after the e |
| DB-12 | bytes-done | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 510] DMA reference model: edge 509: bytes_done pin=1, expected 0 |
| DB-13 | error-code | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 77] DMA reference model: edge 76: read ERROR_CODE = 0x8, expected one of ['0x9'] |
| DB-14 | error-addr | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 27] DMA reference model: edge 26: read ERROR_ADDR = 0x10000044, expected one of ['0x10000040 |
| DB-15 | error-addr | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 77] DMA reference model: edge 76: read ERROR_ADDR = 0x20000044, expected one of ['0x20000040 |
| DB-16 | abort-race | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 831] DMA reference model: edge 830: ev_done=0 at the end of a transfer that completed |
| DB-17 | abort | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 14] DMA reference model: edge 13: new read request presented (since edge 13) after ABORT was |
| DB-18 | phase | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 542] DMA reference model: edge 541: single-port phase switch to write while the port was not |
| DB-19 | burst | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 541] DMA reference model: edge 540: 3 back-to-back read requests exceed BURST=2 |
| DB-20 | fifo | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 545] DMA reference model: edge 544: write beat 0 data 0x153df76 differs from the read data 0 |
| DB-21 | fifo | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 99] DMA reference model: edge 98: fifo_level=1, expected 0 (read responses 0 - writes accept |
| DB-22 | dual-port | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 541] DMA reference model: edge 540: bytes_done pin=4, expected 0 |
| DB-23 | response-order | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 547] DMA reference model: edge 546: fifo_level=1, expected 0 (read responses 2 - writes acce |
| DB-24 | completion | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 560] DMA reference model: edge 559: BUSY fell while a bus request was presented or a respons |
| DB-25 | fifo | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 540] DMA reference model: edge 539: fifo_level=1, expected 0 (read responses 0 - writes acce |
| DB-26 | addressing | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 546] DMA reference model: edge 545: write beat 1 addressed 0x10000018, expected 0x10000014 |
| DB-27 | read-error | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 40] DMA reference model: edge 39: no bus activity for 25 cycles and the transfer has not fin |
| DB-28 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 14] busy asserted while reset is active |
| DB-29 | status | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 20] DMA reference model: edge 19: STATUS.STATE=ISSUE_READ, expected one of ['ISSUE_WRITE'] |
| DB-30 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 14] m_req_valid[0] asserted while reset is active |
