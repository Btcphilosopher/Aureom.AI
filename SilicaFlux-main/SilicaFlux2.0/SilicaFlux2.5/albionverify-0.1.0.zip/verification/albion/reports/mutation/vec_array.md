# Mutation report: vec_array

Baseline (unmutated RTL): 14 run(s), all PASS.

**Mutation score: 100.0%** (48 killed / 0 survived; 1 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 41 kills came from scoreboard/protocol/model checks, 4 from an assertion inside the RTL aborting the simulation, 3 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| VA-01 | tail | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 221] mon: perf counter ELEM_IN mismatch: expected 0x1d got 0x1e / recent: t213 ELEM_IN |
| VA-02 | vl | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 11] mon: res_last [cmd op=0x0 rm=0 vl=2 vm=0 bc=0 red=0 tid=7 beat=0] mismatch: expect |
| VA-03 | framing | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 300] mon: perf counter ELEM_IN mismatch: expected 0x67 got 0x68 / recent: t294 ELEM_IN |
| VA-04 | mask | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 69] mon: perf counter ELEM_IN mismatch: expected 0x1 got 0x2 / recent: t61 ELEM_IN obs |
| VA-05 | mask | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 70] mon: perf counter ELEM_IN mismatch: expected 0x2 got 0x1 / recent: t64 ELEM_IN obs |
| VA-06 | broadcast | KILLED | CHECK | ['directed_elementwise', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 41] mon: res_data lane 0 [cmd op=0x1 rm=1 vl=1 vm=0 bc=2 red=0 tid=11 beat=0] mismatch |
| VA-07 | broadcast | KILLED | CHECK | ['directed_elementwise', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 124] mon: res_flags lane 0 [cmd op=0x4 rm=3 vl=2 vm=1 bc=7 red=0 tid=39 beat=0] mismat |
| VA-08 | legality | KILLED | CHECK | ['illegal_commands', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 13] mon: perf counter ELEM_IN mismatch: expected 0x7 got 0x9 / recent: t9 ELEM_IN obs= |
| VA-09 | hold | KILLED | CHECK | ['stalls_and_holds', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 287] mon: operand beat 0 of command tid=178 released at edge 287 although live lane 1  |
| VA-10 | partial-issue | KILLED | LIVENESS | ['latency_and_throughput', 'seed1'] | albionverify.core.LivenessError: [vec_array @cycle 417] liveness: all commands completed not reached within 400 cycles |
| VA-11 | partial-issue | KILLED | ASSERT | ['stalls_and_holds', 'seed1'] |          per-lane holds (stuck lane, out-of-phase, bursty, all lanes) and operand starvation: lossless, in order, bit-exact. [2865000] %Fata |
| VA-12 | reset | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 1] mon: cmd_ready_o during reset mismatch: expected 0x0 got 0x1 / recent: |
| VA-13 | association | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 11] mon: res_tid [cmd op=0x0 rm=0 vl=2 vm=0 bc=0 red=0 tid=7 beat=0] mismatch: expecte |
| VA-14 | rounding | KILLED | CHECK | ['directed_elementwise', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 41] mon: res_data lane 0 [cmd op=0x1 rm=1 vl=1 vm=0 bc=2 red=0 tid=11 beat=0] mismatch |
| VA-15 | scalar | KILLED | CHECK | ['directed_elementwise', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 13] mon: res_data lane 0 [cmd op=0x0 rm=1 vl=2 vm=1 bc=3 red=0 tid=3 beat=0] mismatch: |
| VA-16 | last | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 11] mon: res_last [cmd op=0x0 rm=0 vl=2 vm=0 bc=0 red=0 tid=7 beat=0] mismatch: expect |
| VA-17 | throughput | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | +  where 2 = max([2, 2, 2, 2, 2, 2, ...]) |
| VA-18 | vl | KILLED | LIVENESS | ['directed_elementwise', 'seed1'] | albionverify.core.LivenessError: [vec_array @cycle 60004] liveness: all commands completed not reached within 60000 cycles |
| VA-19 | flags | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 91] mon: cpl_flags mismatch: expected 0x11 got 0x1 / recent: t85 opnd_hs ; t85 beat op |
| VA-20 | count | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 306] mon: cpl_count mismatch: expected 0x3 got 0x2 / recent: t302 opnd_hs ; t302 beat  |
| VA-21 | beat-index | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 305] mon: res_beat [cmd op=0x4 rm=0 vl=3 vm=0 bc=0 red=0 tid=0 beat=1] mismatch: expec |
| VA-22 | last | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 11] mon: res_last [cmd op=0x0 rm=0 vl=2 vm=0 bc=0 red=0 tid=7 beat=0] mismatch: expect |
| VA-23 | zeroing | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 80] mon: res_data lane 1 [cmd op=0x3 rm=0 vl=1 vm=0 bc=0 red=0 tid=3 beat=0] mismatch: |
| VA-24 | mask-out | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 226] mon: res_mask [cmd op=0x4 rm=0 vl=1 vm=0 bc=0 red=0 tid=0 beat=0] mismatch: expec |
| VA-25 | interface | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 1] mon: res_data_o during reset mismatch: expected 0x0 got 0xa2495db473334794 / recent |
| VA-26 | backpressure | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 78] mon: result beat changed / withdrawn while res_valid_o && !res_ready_i / recent: t |
| VA-27 | backpressure | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 78] mon: result beat changed / withdrawn while res_valid_o && !res_ready_i / recent: t |
| VA-28 | lane-sync | KILLED | ASSERT | ['latency_and_throughput', 'seed1'] |                                                   commands run at ceil(vl/N) cycles per command (full-rate configurations). [2205000] %Fatal |
| VA-29 | ordering | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 90] mon: completion presented before the last result beat of its command was handed ov |
| VA-30 | interface | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 1] mon: cpl_tid_o during reset mismatch: expected 0x0 got 0xdd / recent: |
| VA-31 | status | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 12] mon: busy_o while a command is outstanding mismatch: expected 0x1 got 0x0 / recent |
| VA-32 | perf | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 77] mon: perf counter CMD_DONE mismatch: expected 0x0 got 0x1 / recent: t73 opnd_hs ;  |
| VA-33 | perf | KILLED | CHECK | ['queue_depth', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 78] mon: perf counter BEAT_OUT mismatch: expected 0x3 got 0x4 / recent: t74 opnd_hs ;  |
| VA-34 | perf | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 261] mon: perf counter CYCLES mismatch: expected 0xff got 0x0 / recent: t255 ELEM_IN o |
| VA-35 | perf | KILLED | CHECK | ['random_mixed', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 7] mon: perf counter CYCLES mismatch: expected 0x0 got 0x2 / recent: t5 ELEM_IN obs=0  |
| VA-36 | perf | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 9] mon: perf counter ELEM_IN mismatch: expected 0x2 got 0x1 / recent: t5 ELEM_IN obs=0 |
| VA-37 | reduction-order | KILLED | CHECK | ['illegal_commands', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 27] mon: cpl_flags mismatch: expected 0x1 got 0x0 / recent: t21 opnd_hs ; t21 beat op= |
| VA-38 | reduction | KILLED | CHECK | ['illegal_commands', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 29] mon: cpl_flags mismatch: expected 0x1 got 0x0 / recent: t23 ELEM_IN obs=8 model=8  |
| VA-39 | flags | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 190] mon: cpl_flags mismatch: expected 0x1 got 0x0 / recent: t180 opnd_hs ; t180 beat  |
| VA-40 | accumulator | KILLED | ASSERT | ['illegal_commands', 'seed1'] |              complete in order with cpl_illegal = 1 and count / flags / result 0 -- interleaved with legal commands. [1195000] %Fatal: hpc_v |
| VA-41 | credit | KILLED | LIVENESS | ['latency_and_throughput', 'seed1'] | albionverify.core.LivenessError: [vec_array @cycle 460] liveness: all commands completed not reached within 400 cycles |
| VA-42 | ordering | KILLED | ASSERT | ['illegal_commands', 'seed1'] |                       complete in order with cpl_illegal = 1 and count / flags / result 0 -- interleaved with legal commands. [195000] %Fata |
| VA-43 | reduction | KILLED | CHECK | ['reductions', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 15] mon: cpl_result mismatch: expected 0x3f800000 got 0x0 / recent: t5 ELEM_IN obs=0 m |
| VA-44 | count | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 190] mon: cpl_count mismatch: expected 0x2 got 0x15 / recent: t180 opnd_hs ; t180 beat |
| VA-45 | rounding | KILLED | CHECK | ['reductions', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 213] mon: cpl_result mismatch: expected 0xc6bf5330 got 0xc6bf5332 / recent: t205 ELEM_ |
| VA-46 | rounding | KILLED | CHECK | ['reductions', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 73] mon: cpl_result mismatch: expected 0x4b800001 got 0x4b800000 / recent: t66 beat op |
| VA-47 | reset | KILLED | CHECK | ['latency_and_throughput', 'seed1'] | albionverify.core.AlbionCheckError: [vec_array @cycle 1] mon: cpl_valid_o during reset mismatch: expected 0x0 got 0x1 / recent: |
| VA-48 | capacity | KILLED | CHECK | ['queue_depth', 'seed1'] | +    where <compute.varr_agents.CmdDriver object at 0x7fc1d8b22660> = <compute.cocotb_vec_array.Bench object at 0x7fc1d8b21d30>.cmd |
| VA-49 | equivalent-candidate | EQUIVALENT_SURVIVED |  |  | IEEE-754 addition is commutative in every rounding mode: the exact sum, the zero-sign rule (equal-signed zeros keep the sign, opposite-signe |
