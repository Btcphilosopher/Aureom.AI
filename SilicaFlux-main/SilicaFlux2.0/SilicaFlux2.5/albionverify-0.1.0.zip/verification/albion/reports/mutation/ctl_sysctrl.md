# Mutation report: ctl_sysctrl

Baseline (unmutated RTL): 7 run(s), all PASS.

**Mutation score: 100.0%** (33 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 33 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| CS-01 | key | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 38] sys_reset_req mismatch [cyc=38 sel=0 we=0 addr=0x0dd wdata=0xd33d69fa rst=-  |
| CS-02 | key | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 33] rb_err mismatch [cyc=33 sel=1 we=1 addr=0x028 wdata=0x00000000 rst=- inputs= |
| CS-03 | key | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 34] sys_reset_req mismatch [cyc=34 sel=0 we=1 addr=0xdf6 wdata=0x245b4984 rst=-  |
| CS-04 | stretch | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 93] sys_reset_req mismatch [cyc=93 sel=0 we=1 addr=0xea0 wdata=0x2cfa32f7 rst=-  |
| CS-05 | stretch | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 94] sys_reset_req mismatch [cyc=94 sel=0 we=1 addr=0x81e wdata=0x9012e5d4 rst=-  |
| CS-06 | count | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 134] rb_rdata mismatch [cyc=134 sel=1 we=0 addr=0x024 wdata=0x1015f32e rst=- inp |
| CS-07 | stretch | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 167] sys_reset_req mismatch [cyc=167 sel=0 we=0 addr=0x8fa wdata=0x22104b1e rst= |
| CS-08 | w1c | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 138] rb_rdata mismatch [cyc=138 sel=1 we=0 addr=0x020 wdata=0xe5014aef rst=- inp |
| CS-09 | priority | KILLED | CHECK | ['wdt_host_boot_mode_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 339] rb_rdata mismatch [cyc=339 sel=1 we=0 addr=0x020 wdata=0x8458a11f rst=- inp |
| CS-10 | w1c | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 138] rb_rdata mismatch [cyc=138 sel=1 we=0 addr=0x020 wdata=0xe5014aef rst=- inp |
| CS-11 | cause | KILLED | CHECK | ['wdt_host_boot_mode_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 33] rb_rdata mismatch [cyc=33 sel=1 we=0 addr=0x020 wdata=0xf2d9d3c9 rst=- input |
| CS-12 | host | KILLED | CHECK | ['wdt_host_boot_mode_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 120] sys_reset_req mismatch [cyc=120 sel=0 we=1 addr=0x053 wdata=0x66604451 rst= |
| CS-13 | reset | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 19] rb_rdata mismatch [cyc=19 sel=1 we=0 addr=0x020 wdata=0x6814c6ef rst=- input |
| CS-14 | decode | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 124] rb_rdata mismatch [cyc=124 sel=1 we=0 addr=0x040 wdata=0xdea9f7dd rst=- inp |
| CS-15 | reset | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 5] host_ready mismatch [cyc=5 sel=0 we=0 addr=0xdb6 wdata=0x7f947559 rst=- input |
| CS-16 | field | KILLED | CHECK | ['random_traffic', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 261] rb_rdata mismatch [cyc=261 sel=1 we=0 addr=0x038 wdata=0x35c2f40c rst=- inp |
| CS-17 | pin | KILLED | CHECK | ['status_pins_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 15] host_ready mismatch [cyc=15 sel=0 we=1 addr=0x663 wdata=0x6814c6ef rst=- inp |
| CS-18 | pin | KILLED | CHECK | ['status_pins_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 42] test_done mismatch [cyc=42 sel=0 we=0 addr=0xf45 wdata=0x277ae5ff rst=- inpu |
| CS-19 | pin | KILLED | CHECK | ['status_pins_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 48] test_code mismatch [cyc=48 sel=0 we=1 addr=0x0da wdata=0xdcc2b63d rst=- inpu |
| CS-20 | field | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 29] rb_rdata mismatch [cyc=29 sel=1 we=0 addr=0x030 wdata=0xc87517c9 rst=- input |
| CS-21 | error | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 1036] rb_err mismatch [cyc=1036 sel=1 we=1 addr=0x000 wdata=0xffffffff rst=- inp |
| CS-22 | error | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 18] rb_err mismatch [cyc=18 sel=1 we=0 addr=0x01c wdata=0x66322005 rst=- inputs= |
| CS-23 | read | KILLED | CHECK | ['wdt_host_boot_mode_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 343] rb_rdata mismatch [cyc=343 sel=1 we=0 addr=0x02c wdata=0x5f1b5a0f rst=- inp |
| CS-24 | source | KILLED | CHECK | ['wdt_host_boot_mode_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 13] sys_reset_req mismatch [cyc=13 sel=0 we=1 addr=0x663 wdata=0x6814c6ef rst=-  |
| CS-25 | pin | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 93] sys_reset_req mismatch [cyc=93 sel=0 we=1 addr=0xea0 wdata=0x2cfa32f7 rst=-  |
| CS-26 | reset | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 27] rb_rdata mismatch [cyc=27 sel=1 we=0 addr=0x040 wdata=0xad034578 rst=- input |
| CS-27 | error | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 1039] rb_err mismatch [cyc=1039 sel=1 we=1 addr=0x00c wdata=0xffffffff rst=- inp |
| CS-28 | decode | KILLED | CHECK | ['status_pins_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 63] rb_rdata mismatch [cyc=63 sel=1 we=0 addr=0x034 wdata=0x98ae8261 rst=- input |
| CS-29 | status | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 20] rb_rdata mismatch [cyc=20 sel=1 we=0 addr=0x024 wdata=0xa1ed5641 rst=- input |
| CS-30 | sync | KILLED | CHECK | ['wdt_host_boot_mode_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 103] sys_reset_req mismatch [cyc=103 sel=0 we=1 addr=0xf1f wdata=0x5210338e rst= |
| CS-31 | sync | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 7] por_rst_n mismatch [cyc=7 sel=0 we=0 addr=0xd96 wdata=0x1b0806b0 rst=- inputs |
| CS-32 | read | KILLED | CHECK | ['identity_reset_values', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 16] rb_rdata mismatch [cyc=16 sel=1 we=0 addr=0x014 wdata=0x2f8e7b21 rst=- input |
| CS-33 | cause | KILLED | CHECK | ['soft_reset_directed', 'seed1'] | albionverify.core.AlbionCheckError: [sysctrl/sysctrl @cycle 132] rb_rdata mismatch [cyc=132 sel=1 we=0 addr=0x020 wdata=0x00ffe1b6 rst=- inp |
