# Mutation report: dma_simple

Baseline (unmutated RTL): 8 run(s), all PASS.

**Mutation score: 100.0%** (45 killed / 0 survived; 0 argued-equivalent survivors excluded; 0 survivors unobservable through the ports (not proven equivalent, counted against the score); 0 invalid mutants excluded). 45 kills came from scoreboard/protocol/model checks, 0 from an assertion inside the RTL aborting the simulation, 0 from liveness/hang/crash detection.

| id | class | status | kill | detected by | message |
|---|---|---|---|---|---|
| DS-01 | byte-enable | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 645] DMA reference model: edge 644: write beat 2 strobe 0x3, expected 0x1 (length 9, SB 4) |
| DS-02 | error-code | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 25] DMA reference model: edge 24: read ERROR_CODE = 0x9, expected one of ['0x8'] |
| DS-03 | off-by-one | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 317] DMA reference model: edge 316: read ERROR_CODE = 0x2, expected one of ['0x3'] |
| DS-04 | off-by-one | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 561] DMA reference model: edge 560: more read requests (5) than the 4 beats of the transfer |
| DS-05 | validation | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 572] DMA reference model: edge 571: transfer ended early: 0 of 4 beats written, no error and |
| DS-06 | precedence | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 296] DMA reference model: edge 295: read ERROR_CODE = 0x4, expected one of ['0x3'] |
| DS-07 | off-by-one | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 443] DMA reference model: edge 442: read ERROR_CODE = 0x5, expected one of ['0x6'] |
| DS-08 | precedence | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 422] DMA reference model: edge 421: read ERROR_CODE = 0x7, expected one of ['0x5'] |
| DS-09 | bytes-done | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 648] DMA reference model: edge 647: bytes_done pin=12, expected 9 |
| DS-10 | error-addr | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 27] DMA reference model: edge 26: read ERROR_ADDR = 0x20000040, expected one of ['0x10000040 |
| DS-11 | error-addr | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 77] DMA reference model: edge 76: read ERROR_ADDR = 0x10000040, expected one of ['0x20000040 |
| DS-12 | abort | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 56] DMA reference model: edge 55: new write request presented (since edge 55) after ABORT wa |
| DS-13 | abort-race | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 857] DMA reference model: edge 856: ev_done=0 at the end of a transfer that completed |
| DS-14 | bytes-done | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 571] DMA reference model: edge 570: bytes_done pin=16, expected 0 |
| DS-15 | addressing | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 546] DMA reference model: edge 545: write beat 1 addressed 0x10000018, expected 0x10000014 |
| DS-16 | error-handling | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 16] DMA reference model: edge 15: write of beat 0 issued although its read failed (a write n |
| DS-17 | error-handling | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 66] DMA reference model: edge 65: bytes_done pin=1, expected 0 |
| DS-18 | status | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 560] DMA reference model: edge 559: BUSY fell while a bus request was presented or a respons |
| DS-19 | abort | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 14] DMA reference model: edge 13: new read request presented (since edge 13) after ABORT was |
| DS-20 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 1] busy asserted while reset is active |
| DS-21 | reset | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 1] m_req_valid[0] asserted while reset is active |
| DS-22 | data-path | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 541] DMA reference model: edge 540: write beat 0 data 0x64eeba50 differs from the read data  |
| DS-23 | busy-protection | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 51] DMA reference model: edge 50: read LENGTH = 0xb57379b6, expected 0x00000027 (mask 0xffff |
| DS-24 | busy-protection | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 1024] DMA reference model: edge 1023: write SRC_ADDR rb_err=0, expected 1 (busy=1) |
| DS-25 | busy-protection | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 21] DMA reference model: edge 20: write LENGTH rb_err=0, expected 1 (busy=1) |
| DS-26 | busy-protection | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 39] DMA reference model: edge 38: read ACTIVE_CYCLES = 0x00000005, expected 0x0000001a (mask |
| DS-27 | busy-protection | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 5116] DMA reference model: edge 5115: transfer ended early: 0 of 6 beats written, no error a |
| DS-28 | busy-protection | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 5114] DMA reference model: edge 5113: write CONTROL rb_err=0, expected 1 (busy=1) |
| DS-29 | registers | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 348] DMA reference model: edge 347: irq pin=0, expected 1 (INT_STATUS=2 & INT_ENABLE=3) |
| DS-30 | registers | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 100] DMA reference model: edge 99: read 0x03c rb_err=0, expected 1 (busy=0) |
| DS-31 | registers | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 1204] DMA reference model: edge 1203: read INT_STATUS = 0x00000001, expected 0x00000003 (mas |
| DS-32 | status | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 19] DMA reference model: edge 18: read STATUS = 0x00000004, expected 0x0000000c (mask 0xffff |
| DS-33 | status | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 19] DMA reference model: edge 18: read STATUS = 0x00000002, expected 0x00000004 (mask 0xffff |
| DS-34 | status | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 614] DMA reference model: edge 613: read STATUS = 0x00000006, expected 0x00000004 (mask 0xff |
| DS-35 | perf | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 104] DMA reference model: edge 103: read STALL_CYCLES = 0x00000057, expected 0x00000051 (mas |
| DS-36 | perf | KILLED | CHECK | ['all', 'seed1'] | AssertionError: assert 10 == 9 |
| DS-37 | perf | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 106] DMA reference model: edge 105: read ACTIVE_CYCLES = 0x00000056, expected 0x00000057 (ma |
| DS-38 | perf | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 556] DMA reference model: edge 555: read ACTIVE_CYCLES = 0x0000020c, expected 0x000001b5 (ma |
| DS-39 | info | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 32] DMA reference model: edge 31: read INFO = 0x01080008, expected 0x01080004 (mask 0xffffff |
| DS-40 | perf-absent | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 37] DMA reference model: edge 36: read ACTIVE_CYCLES rb_err=0, expected 1 (busy=0) |
| DS-41 | interrupt | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 60] DMA reference model: edge 59: irq pin=0, expected 1 (INT_STATUS=1 & INT_ENABLE=3) |
| DS-42 | interrupt | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 15] DMA reference model: edge 14: irq pin=1, expected 0 (INT_STATUS=2 & INT_ENABLE=0) |
| DS-43 | interrupt | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 27] DMA reference model: edge 26: read INT_STATUS = 0x00000001, expected 0x00000002 (mask 0x |
| DS-44 | interrupt | KILLED | CHECK | ['all', 'seed1'] | AssertionError: assert 0 == 2 |
| DS-45 | events | KILLED | CHECK | ['all', 'seed1'] | albionverify.core.AlbionCheckError: [dma @cycle 14] DMA reference model: edge 13: ev_done=1 at the end of a transfer that failed (ZERO_LENGT |
