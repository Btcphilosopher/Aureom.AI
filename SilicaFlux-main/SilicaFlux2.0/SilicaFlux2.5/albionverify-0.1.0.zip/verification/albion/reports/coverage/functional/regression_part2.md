# Functional coverage: regression_part2

Merged from 140 test run(s) over 10 DUT configuration(s), merged **per configuration** (never across configurations).  **Overall: 99.1% (639 of 645 defined bins hit).**  This is scenario coverage of the stimulus, not RTL code coverage.

| DUT :: group | bins | hit | % | samples |
|---|---:|---:|---:|---:|
| ctl_core::core.access | 19 | 19 | 100.0 | 180 |
| ctl_core::core.boot | 29 | 25 | 86.2 | 719541 |
| ctl_core::core.boot_errors | 6 | 6 | 100.0 | 13 |
| ctl_core::core.irq | 15 | 15 | 100.0 | 36 |
| ctl_mbox256::mbox.addr | 9 | 9 | 100.0 | 211303 |
| ctl_mbox256::mbox.bus | 5 | 5 | 100.0 | 447895 |
| ctl_mbox256::mbox.count | 2 | 2 | 100.0 | 2 |
| ctl_mbox256::mbox.doorbell | 14 | 14 | 100.0 | 147767 |
| ctl_mbox256::mbox.fifo | 19 | 19 | 100.0 | 24437 |
| ctl_mbox256::mbox.reset | 5 | 5 | 100.0 | 95 |
| ctl_mbox256::mbox.txn | 19 | 19 | 100.0 | 211303 |
| ctl_mbox8::mbox.addr | 9 | 9 | 100.0 | 63260 |
| ctl_mbox8::mbox.bus | 5 | 5 | 100.0 | 147697 |
| ctl_mbox8::mbox.count | 2 | 0 | 0.0 | 0 |
| ctl_mbox8::mbox.doorbell | 14 | 14 | 100.0 | 14624 |
| ctl_mbox8::mbox.fifo | 19 | 19 | 100.0 | 12877 |
| ctl_mbox8::mbox.reset | 5 | 5 | 100.0 | 95 |
| ctl_mbox8::mbox.txn | 19 | 19 | 100.0 | 63260 |
| ctl_perf20::perf.addr | 9 | 9 | 100.0 | 26300 |
| ctl_perf20::perf.bus | 5 | 5 | 100.0 | 117501 |
| ctl_perf20::perf.ctrl | 8 | 8 | 100.0 | 49180 |
| ctl_perf20::perf.events | 45 | 45 | 100.0 | 274472 |
| ctl_perf20::perf.txn | 13 | 13 | 100.0 | 26300 |
| ctl_perf5::perf.addr | 9 | 9 | 100.0 | 25550 |
| ctl_perf5::perf.bus | 5 | 5 | 100.0 | 46396 |
| ctl_perf5::perf.ctrl | 8 | 8 | 100.0 | 32821 |
| ctl_perf5::perf.events | 15 | 15 | 100.0 | 48308 |
| ctl_perf5::perf.txn | 13 | 13 | 100.0 | 25550 |
| ctl_pmu::pmu.addr | 6 | 6 | 100.0 | 30146 |
| ctl_pmu::pmu.bus | 5 | 5 | 100.0 | 120609 |
| ctl_pmu::pmu.state | 65 | 65 | 100.0 | 406470 |
| ctl_pmu::pmu.txn | 13 | 13 | 100.0 | 30146 |
| ctl_ras::ras.addr | 4 | 4 | 100.0 | 35536 |
| ctl_ras::ras.bus | 5 | 5 | 100.0 | 64175 |
| ctl_ras::ras.events | 21 | 21 | 100.0 | 76875 |
| ctl_ras::ras.irq | 14 | 14 | 100.0 | 256248 |
| ctl_ras::ras.mask | 8 | 8 | 100.0 | 128124 |
| ctl_ras::ras.misc | 10 | 10 | 100.0 | 3770 |
| ctl_ras::ras.txn | 16 | 16 | 100.0 | 35536 |
| ctl_secmon::secmon.addr | 5 | 5 | 100.0 | 33529 |
| ctl_secmon::secmon.bus | 5 | 5 | 100.0 | 61284 |
| ctl_secmon::secmon.state | 11 | 11 | 100.0 | 27760 |
| ctl_secmon::secmon.txn | 22 | 22 | 100.0 | 33529 |
| ctl_sfbgate::gate.scenario | 12 | 12 | 100.0 | 99158 |
| ctl_sfbgate::gate.txn | 13 | 13 | 100.0 | 24368 |
| ctl_sysctrl::sysctrl.addr | 9 | 9 | 100.0 | 34345 |
| ctl_sysctrl::sysctrl.boot_mode | 4 | 4 | 100.0 | 481 |
| ctl_sysctrl::sysctrl.bus | 5 | 5 | 100.0 | 59001 |
| ctl_sysctrl::sysctrl.pins | 14 | 14 | 100.0 | 236060 |
| ctl_sysctrl::sysctrl.reset | 12 | 12 | 100.0 | 6645 |
| ctl_sysctrl::sysctrl.txn | 21 | 21 | 100.0 | 34345 |

## Uncovered bins (6)

* `ctl_core::core.boot` point.stage.ACC_DISCOVERY
* `ctl_core::core.boot` point.stage.FATAL
* `ctl_core::core.boot` point.stage.SELF_TEST
* `ctl_core::core.boot` point.stage.SHUTDOWN
* `ctl_mbox8::mbox.count` point.event.f2h_wrap
* `ctl_mbox8::mbox.count` point.event.h2f_wrap
