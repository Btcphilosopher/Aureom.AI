# Functional coverage: regression_part1

Merged from 1615 test run(s) over 70 DUT configuration(s), merged **per configuration** (never across configurations).  **Overall: 99.4% (11130 of 11202 defined bins hit).**  This is scenario coverage of the stimulus, not RTL code coverage.

| DUT :: group | bins | hit | % | samples |
|---|---:|---:|---:|---:|
| dma_adapter_dp::adapter_backpressure | 7 | 7 | 100.0 | 5885 |
| dma_adapter_dp::adapter_queues | 11 | 11 | 100.0 | 1560 |
| dma_adapter_dp::adapter_region | 6 | 6 | 100.0 | 202 |
| dma_adapter_dp::adapter_reset | 4 | 4 | 100.0 | 60 |
| dma_adapter_dp::adapter_transfer | 39 | 39 | 100.0 | 678 |
| dma_adapter_simple::adapter_backpressure | 7 | 7 | 100.0 | 5236 |
| dma_adapter_simple::adapter_queues | 9 | 9 | 100.0 | 1518 |
| dma_adapter_simple::adapter_region | 6 | 6 | 100.0 | 189 |
| dma_adapter_simple::adapter_reset | 4 | 4 | 100.0 | 60 |
| dma_adapter_simple::adapter_transfer | 39 | 39 | 100.0 | 656 |
| dma_adapter_sp64::adapter_backpressure | 7 | 7 | 100.0 | 3702 |
| dma_adapter_sp64::adapter_queues | 7 | 7 | 100.0 | 1562 |
| dma_adapter_sp64::adapter_region | 8 | 8 | 100.0 | 196 |
| dma_adapter_sp64::adapter_reset | 4 | 4 | 100.0 | 60 |
| dma_adapter_sp64::adapter_transfer | 39 | 39 | 100.0 | 714 |
| dma_buf_dp::dma_abort | 15 | 15 | 100.0 | 312 |
| dma_buf_dp::dma_backpressure | 24 | 24 | 100.0 | 36732 |
| dma_buf_dp::dma_bus_error | 16 | 16 | 100.0 | 277 |
| dma_buf_dp::dma_concurrency | 8 | 8 | 100.0 | 73150 |
| dma_buf_dp::dma_descriptor | 93 | 93 | 100.0 | 4579 |
| dma_buf_dp::dma_interrupts | 11 | 11 | 100.0 | 2876 |
| dma_buf_dp::dma_perf | 5 | 5 | 100.0 | 1210 |
| dma_buf_dp::dma_registers | 87 | 87 | 100.0 | 25119 |
| dma_buf_dp::dma_reset | 8 | 8 | 100.0 | 211 |
| dma_buf_dp_min128::dma_abort | 15 | 15 | 100.0 | 268 |
| dma_buf_dp_min128::dma_backpressure | 24 | 24 | 100.0 | 23165 |
| dma_buf_dp_min128::dma_bus_error | 15 | 15 | 100.0 | 234 |
| dma_buf_dp_min128::dma_concurrency | 5 | 5 | 100.0 | 59216 |
| dma_buf_dp_min128::dma_descriptor | 93 | 93 | 100.0 | 4485 |
| dma_buf_dp_min128::dma_interrupts | 11 | 11 | 100.0 | 2644 |
| dma_buf_dp_min128::dma_perf | 5 | 5 | 100.0 | 1153 |
| dma_buf_dp_min128::dma_registers | 87 | 87 | 100.0 | 23850 |
| dma_buf_dp_min128::dma_reset | 8 | 8 | 100.0 | 228 |
| dma_buf_dp_w64::dma_abort | 15 | 15 | 100.0 | 234 |
| dma_buf_dp_w64::dma_backpressure | 24 | 24 | 100.0 | 28875 |
| dma_buf_dp_w64::dma_bus_error | 16 | 16 | 100.0 | 247 |
| dma_buf_dp_w64::dma_concurrency | 13 | 13 | 100.0 | 54319 |
| dma_buf_dp_w64::dma_descriptor | 93 | 93 | 100.0 | 4417 |
| dma_buf_dp_w64::dma_interrupts | 11 | 11 | 100.0 | 2635 |
| dma_buf_dp_w64::dma_perf | 5 | 5 | 100.0 | 1081 |
| dma_buf_dp_w64::dma_registers | 87 | 87 | 100.0 | 23048 |
| dma_buf_dp_w64::dma_reset | 8 | 8 | 100.0 | 205 |
| dma_buf_min::dma_abort | 15 | 15 | 100.0 | 531 |
| dma_buf_min::dma_backpressure | 24 | 24 | 100.0 | 29070 |
| dma_buf_min::dma_bus_error | 15 | 15 | 100.0 | 243 |
| dma_buf_min::dma_concurrency | 4 | 4 | 100.0 | 194383 |
| dma_buf_min::dma_descriptor | 93 | 93 | 100.0 | 4351 |
| dma_buf_min::dma_interrupts | 11 | 11 | 100.0 | 2806 |
| dma_buf_min::dma_perf | 5 | 5 | 100.0 | 1400 |
| dma_buf_min::dma_registers | 87 | 87 | 100.0 | 27917 |
| dma_buf_min::dma_reset | 8 | 8 | 100.0 | 268 |
| dma_buf_sp::dma_abort | 15 | 15 | 100.0 | 493 |
| dma_buf_sp::dma_backpressure | 24 | 24 | 100.0 | 34331 |
| dma_buf_sp::dma_bus_error | 16 | 16 | 100.0 | 250 |
| dma_buf_sp::dma_concurrency | 7 | 7 | 100.0 | 178750 |
| dma_buf_sp::dma_descriptor | 113 | 113 | 100.0 | 4598 |
| dma_buf_sp::dma_interrupts | 11 | 11 | 100.0 | 3005 |
| dma_buf_sp::dma_perf | 5 | 5 | 100.0 | 1456 |
| dma_buf_sp::dma_registers | 87 | 87 | 100.0 | 28392 |
| dma_buf_sp::dma_reset | 8 | 8 | 100.0 | 257 |
| dma_buf_sp_b4::dma_abort | 15 | 15 | 100.0 | 379 |
| dma_buf_sp_b4::dma_backpressure | 24 | 24 | 100.0 | 32528 |
| dma_buf_sp_b4::dma_bus_error | 16 | 16 | 100.0 | 248 |
| dma_buf_sp_b4::dma_concurrency | 12 | 12 | 100.0 | 138063 |
| dma_buf_sp_b4::dma_descriptor | 113 | 113 | 100.0 | 4717 |
| dma_buf_sp_b4::dma_interrupts | 11 | 11 | 100.0 | 2866 |
| dma_buf_sp_b4::dma_perf | 5 | 5 | 100.0 | 1228 |
| dma_buf_sp_b4::dma_registers | 87 | 87 | 100.0 | 25893 |
| dma_buf_sp_b4::dma_reset | 8 | 8 | 100.0 | 237 |
| dma_simple::dma_abort | 15 | 15 | 100.0 | 551 |
| dma_simple::dma_backpressure | 24 | 24 | 100.0 | 34180 |
| dma_simple::dma_bus_error | 15 | 15 | 100.0 | 264 |
| dma_simple::dma_concurrency | 2 | 2 | 100.0 | 121900 |
| dma_simple::dma_descriptor | 93 | 93 | 100.0 | 4579 |
| dma_simple::dma_interrupts | 11 | 11 | 100.0 | 3068 |
| dma_simple::dma_perf | 5 | 5 | 100.0 | 1476 |
| dma_simple::dma_registers | 87 | 87 | 100.0 | 29136 |
| dma_simple::dma_reset | 10 | 10 | 100.0 | 254 |
| dma_simple_w64::dma_abort | 15 | 15 | 100.0 | 380 |
| dma_simple_w64::dma_backpressure | 24 | 24 | 100.0 | 25078 |
| dma_simple_w64::dma_bus_error | 15 | 15 | 100.0 | 235 |
| dma_simple_w64::dma_concurrency | 2 | 2 | 100.0 | 85583 |
| dma_simple_w64::dma_descriptor | 93 | 93 | 100.0 | 4391 |
| dma_simple_w64::dma_interrupts | 11 | 11 | 100.0 | 2696 |
| dma_simple_w64::dma_perf | 0 | 0 | 100.0 | 0 |
| dma_simple_w64::dma_registers | 87 | 87 | 100.0 | 25539 |
| dma_simple_w64::dma_reset | 10 | 10 | 100.0 | 253 |
| fab_arb_fx4::arb_unit | 28 | 28 | 100.0 | 111992 |
| fab_arb_rr1::arb_unit | 15 | 15 | 100.0 | 158846 |
| fab_arb_rr3::arb_unit | 37 | 37 | 100.0 | 169726 |
| fab_arb_rr4::arb_unit | 54 | 54 | 100.0 | 176394 |
| fab_arb_rr6::arb_unit | 100 | 100 | 100.0 | 189527 |
| fab_err_dw128::errslave | 5 | 5 | 100.0 | 15697 |
| fab_err_dw32::errslave | 5 | 5 | 100.0 | 15697 |
| fab_skid_w37::skid | 8 | 8 | 100.0 | 46577 |
| fab_skid_w8::skid | 8 | 8 | 100.0 | 46529 |
| fab_slice_00::slice | 10 | 10 | 100.0 | 39175 |
| fab_slice_01::slice | 14 | 14 | 100.0 | 38338 |
| fab_slice_10::slice | 14 | 14 | 100.0 | 38495 |
| fab_slice_11::slice | 18 | 18 | 100.0 | 37326 |
| fab_slice_11_w64::slice | 18 | 18 | 100.0 | 37355 |
| sram_bank_1x1::bank.access | 3 | 3 | 100.0 | 5015 |
| sram_bank_1x1::bank.arb | 1 | 1 | 100.0 | 5015 |
| sram_bank_1x1::bank.contention | 6 | 6 | 100.0 | 17236 |
| sram_bank_1x1::bank.err | 5 | 5 | 100.0 | 330 |
| sram_bank_1x1::bank.flow | 11 | 11 | 100.0 | 16011 |
| sram_bank_1x1::bank.id | 3 | 3 | 100.0 | 5345 |
| sram_bank_1x1::bank.reset | 6 | 6 | 100.0 | 100 |
| sram_bank_1x1::bank.txn | 22 | 22 | 100.0 | 5345 |
| sram_bank_2x8_rr_w64_l3::bank.access | 26 | 26 | 100.0 | 9687 |
| sram_bank_2x8_rr_w64_l3::bank.arb | 7 | 7 | 100.0 | 9978 |
| sram_bank_2x8_rr_w64_l3::bank.contention | 12 | 12 | 100.0 | 69858 |
| sram_bank_2x8_rr_w64_l3::bank.err | 5 | 5 | 100.0 | 475 |
| sram_bank_2x8_rr_w64_l3::bank.flow | 12 | 12 | 100.0 | 54976 |
| sram_bank_2x8_rr_w64_l3::bank.id | 3 | 3 | 100.0 | 10162 |
| sram_bank_2x8_rr_w64_l3::bank.reset | 7 | 7 | 100.0 | 100 |
| sram_bank_2x8_rr_w64_l3::bank.txn | 28 | 28 | 100.0 | 10162 |
| sram_bank_3x2_fixed_high_byte::bank.access | 11 | 11 | 100.0 | 13690 |
| sram_bank_3x2_fixed_high_byte::bank.arb | 12 | 12 | 100.0 | 18007 |
| sram_bank_3x2_fixed_high_byte::bank.contention | 15 | 15 | 100.0 | 36098 |
| sram_bank_3x2_fixed_high_byte::bank.err | 8 | 8 | 100.0 | 1365 |
| sram_bank_3x2_fixed_high_byte::bank.flow | 12 | 12 | 100.0 | 31881 |
| sram_bank_3x2_fixed_high_byte::bank.id | 3 | 3 | 100.0 | 15055 |
| sram_bank_3x2_fixed_high_byte::bank.reset | 7 | 7 | 100.0 | 100 |
| sram_bank_3x2_fixed_high_byte::bank.txn | 31 | 31 | 100.0 | 15055 |
| sram_bank_4x4_rr_low::bank.access | 24 | 24 | 100.0 | 19171 |
| sram_bank_4x4_rr_low::bank.arb | 23 | 23 | 100.0 | 24990 |
| sram_bank_4x4_rr_low::bank.contention | 23 | 23 | 100.0 | 53381 |
| sram_bank_4x4_rr_low::bank.err | 5 | 5 | 100.0 | 898 |
| sram_bank_4x4_rr_low::bank.flow | 12 | 12 | 100.0 | 64271 |
| sram_bank_4x4_rr_low::bank.id | 3 | 3 | 100.0 | 20069 |
| sram_bank_4x4_rr_low::bank.reset | 7 | 7 | 100.0 | 100 |
| sram_bank_4x4_rr_low::bank.txn | 28 | 28 | 100.0 | 20069 |
| sram_bank_5x4_nofifo_byte16::bank.access | 29 | 29 | 100.0 | 22404 |
| sram_bank_5x4_nofifo_byte16::bank.arb | 34 | 34 | 100.0 | 32191 |
| sram_bank_5x4_nofifo_byte16::bank.contention | 28 | 28 | 100.0 | 44265 |
| sram_bank_5x4_nofifo_byte16::bank.err | 8 | 8 | 100.0 | 2147 |
| sram_bank_5x4_nofifo_byte16::bank.flow | 5 | 5 | 100.0 | 48792 |
| sram_bank_5x4_nofifo_byte16::bank.id | 3 | 3 | 100.0 | 24551 |
| sram_bank_5x4_nofifo_byte16::bank.reset | 7 | 7 | 100.0 | 100 |
| sram_bank_5x4_nofifo_byte16::bank.txn | 31 | 31 | 100.0 | 24551 |
| sram_bank_8x2_rr_high::bank.access | 26 | 26 | 100.0 | 37699 |
| sram_bank_8x2_rr_high::bank.arb | 79 | 79 | 100.0 | 66266 |
| sram_bank_8x2_rr_high::bank.contention | 30 | 30 | 100.0 | 148858 |
| sram_bank_8x2_rr_high::bank.err | 5 | 5 | 100.0 | 1572 |
| sram_bank_8x2_rr_high::bank.flow | 12 | 12 | 100.0 | 109366 |
| sram_bank_8x2_rr_high::bank.id | 3 | 3 | 100.0 | 39271 |
| sram_bank_8x2_rr_high::bank.reset | 7 | 7 | 100.0 | 100 |
| sram_bank_8x2_rr_high::bank.txn | 28 | 28 | 100.0 | 39271 |
| sram_sp_d1000_l1::sp.flow | 13 | 13 | 100.0 | 71310 |
| sram_sp_d1000_l1::sp.id | 3 | 3 | 100.0 | 28749 |
| sram_sp_d1000_l1::sp.latency | 2 | 2 | 100.0 | 28619 |
| sram_sp_d1000_l1::sp.mask | 7 | 7 | 100.0 | 8566 |
| sram_sp_d1000_l1::sp.reset | 11 | 11 | 100.0 | 88 |
| sram_sp_d1000_l1::sp.seq | 24 | 24 | 100.0 | 28645 |
| sram_sp_d1000_l1::sp.txn | 28 | 28 | 100.0 | 28749 |
| sram_sp_d100_l2::sp.flow | 14 | 14 | 100.0 | 40361 |
| sram_sp_d100_l2::sp.id | 3 | 3 | 100.0 | 13440 |
| sram_sp_d100_l2::sp.latency | 2 | 2 | 100.0 | 13244 |
| sram_sp_d100_l2::sp.mask | 7 | 7 | 100.0 | 5863 |
| sram_sp_d100_l2::sp.reset | 12 | 12 | 100.0 | 88 |
| sram_sp_d100_l2::sp.seq | 24 | 24 | 100.0 | 13337 |
| sram_sp_d100_l2::sp.txn | 28 | 28 | 100.0 | 13440 |
| sram_sp_d100_l3_posted::sp.flow | 16 | 16 | 100.0 | 25252 |
| sram_sp_d100_l3_posted::sp.id | 2 | 2 | 100.0 | 13743 |
| sram_sp_d100_l3_posted::sp.latency | 2 | 2 | 100.0 | 7500 |
| sram_sp_d100_l3_posted::sp.mask | 7 | 7 | 100.0 | 6030 |
| sram_sp_d100_l3_posted::sp.reset | 12 | 12 | 100.0 | 88 |
| sram_sp_d100_l3_posted::sp.seq | 24 | 24 | 100.0 | 13639 |
| sram_sp_d100_l3_posted::sp.txn | 28 | 28 | 100.0 | 13743 |
| sram_sp_d100_nofifo::sp.flow | 9 | 9 | 100.0 | 28595 |
| sram_sp_d100_nofifo::sp.id | 3 | 3 | 100.0 | 14352 |
| sram_sp_d100_nofifo::sp.latency | 1 | 1 | 100.0 | 14243 |
| sram_sp_d100_nofifo::sp.mask | 7 | 7 | 100.0 | 5580 |
| sram_sp_d100_nofifo::sp.reset | 9 | 9 | 100.0 | 88 |
| sram_sp_d100_nofifo::sp.seq | 24 | 24 | 100.0 | 14248 |
| sram_sp_d100_nofifo::sp.txn | 28 | 28 | 100.0 | 14352 |
| sram_sp_d3_w1_l4::sp.flow | 17 | 17 | 100.0 | 31904 |
| sram_sp_d3_w1_l4::sp.id | 3 | 3 | 100.0 | 11664 |
| sram_sp_d3_w1_l4::sp.latency | 2 | 2 | 100.0 | 11283 |
| sram_sp_d3_w1_l4::sp.mask | 2 | 2 | 100.0 | 4294 |
| sram_sp_d3_w1_l4::sp.reset | 12 | 12 | 100.0 | 88 |
| sram_sp_d3_w1_l4::sp.seq | 24 | 24 | 100.0 | 11560 |
| sram_sp_d3_w1_l4::sp.txn | 16 | 16 | 100.0 | 11664 |
| sram_sp_d64_l1::sp.flow | 13 | 13 | 100.0 | 39471 |
| sram_sp_d64_l1::sp.id | 3 | 3 | 100.0 | 12508 |
| sram_sp_d64_l1::sp.latency | 2 | 2 | 100.0 | 12386 |
| sram_sp_d64_l1::sp.mask | 7 | 7 | 100.0 | 6589 |
| sram_sp_d64_l1::sp.reset | 11 | 11 | 100.0 | 88 |
| sram_sp_d64_l1::sp.seq | 24 | 24 | 100.0 | 12403 |
| sram_sp_d64_l1::sp.txn | 17 | 17 | 100.0 | 12508 |
| sram_sp_fpga_d64_l2::sp.flow | 14 | 14 | 100.0 | 39210 |
| sram_sp_fpga_d64_l2::sp.id | 3 | 3 | 100.0 | 12561 |
| sram_sp_fpga_d64_l2::sp.latency | 2 | 2 | 100.0 | 12367 |
| sram_sp_fpga_d64_l2::sp.mask | 7 | 7 | 100.0 | 6621 |
| sram_sp_fpga_d64_l2::sp.reset | 12 | 12 | 100.0 | 88 |
| sram_sp_fpga_d64_l2::sp.seq | 24 | 24 | 100.0 | 12456 |
| sram_sp_fpga_d64_l2::sp.txn | 17 | 17 | 100.0 | 12561 |
| sram_sp_lane9_posted::sp.flow | 14 | 14 | 100.0 | 27137 |
| sram_sp_lane9_posted::sp.id | 3 | 3 | 100.0 | 12514 |
| sram_sp_lane9_posted::sp.latency | 2 | 2 | 100.0 | 7143 |
| sram_sp_lane9_posted::sp.mask | 4 | 4 | 100.0 | 5257 |
| sram_sp_lane9_posted::sp.reset | 11 | 11 | 100.0 | 88 |
| sram_sp_lane9_posted::sp.seq | 24 | 24 | 100.0 | 12411 |
| sram_sp_lane9_posted::sp.txn | 28 | 28 | 100.0 | 12514 |
| sram_sp_w64_l1_fd1::sp.flow | 12 | 12 | 100.0 | 62124 |
| sram_sp_w64_l1_fd1::sp.id | 3 | 3 | 100.0 | 13656 |
| sram_sp_w64_l1_fd1::sp.latency | 2 | 2 | 100.0 | 13589 |
| sram_sp_w64_l1_fd1::sp.mask | 11 | 11 | 100.0 | 6273 |
| sram_sp_w64_l1_fd1::sp.reset | 9 | 9 | 100.0 | 88 |
| sram_sp_w64_l1_fd1::sp.seq | 15 | 15 | 100.0 | 13551 |
| sram_sp_w64_l1_fd1::sp.txn | 17 | 17 | 100.0 | 13656 |
| sram_spm_3p2b_high_2rw_w64::spm.arb | 8 | 8 | 100.0 | 15797 |
| sram_spm_3p2b_high_2rw_w64::spm.contention | 19 | 19 | 100.0 | 47607 |
| sram_spm_3p2b_high_2rw_w64::spm.counters | 1 | 1 | 100.0 | 2102 |
| sram_spm_3p2b_high_2rw_w64::spm.err | 8 | 8 | 100.0 | 528 |
| sram_spm_3p2b_high_2rw_w64::spm.events | 7 | 7 | 100.0 | 58436 |
| sram_spm_3p2b_high_2rw_w64::spm.flow | 11 | 11 | 100.0 | 70537 |
| sram_spm_3p2b_high_2rw_w64::spm.mask | 11 | 11 | 100.0 | 6639 |
| sram_spm_3p2b_high_2rw_w64::spm.reset | 5 | 5 | 100.0 | 100 |
| sram_spm_3p2b_high_2rw_w64::spm.tag | 3 | 3 | 100.0 | 14786 |
| sram_spm_3p2b_high_2rw_w64::spm.txn | 28 | 28 | 100.0 | 14786 |
| sram_spm_3p4b_low_1rw::spm.arb | 8 | 8 | 100.0 | 18997 |
| sram_spm_3p4b_low_1rw::spm.contention | 15 | 15 | 100.0 | 20478 |
| sram_spm_3p4b_low_1rw::spm.counters | 1 | 1 | 100.0 | 1240 |
| sram_spm_3p4b_low_1rw::spm.err | 8 | 8 | 100.0 | 782 |
| sram_spm_3p4b_low_1rw::spm.events | 7 | 7 | 100.0 | 52397 |
| sram_spm_3p4b_low_1rw::spm.flow | 11 | 11 | 100.0 | 42052 |
| sram_spm_3p4b_low_1rw::spm.mask | 7 | 7 | 100.0 | 6399 |
| sram_spm_3p4b_low_1rw::spm.reset | 5 | 5 | 100.0 | 100 |
| sram_spm_3p4b_low_1rw::spm.tag | 3 | 3 | 100.0 | 16640 |
| sram_spm_3p4b_low_1rw::spm.txn | 31 | 31 | 100.0 | 16640 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.arb | 11 | 11 | 100.0 | 25119 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.contention | 27 | 27 | 100.0 | 38366 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.counters | 2 | 2 | 100.0 | 1063 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.err | 10 | 10 | 100.0 | 1291 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.events | 7 | 7 | 100.0 | 44458 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.flow | 11 | 11 | 100.0 | 38600 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.mask | 1 | 1 | 100.0 | 8182 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.reset | 5 | 5 | 100.0 | 100 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.tag | 3 | 3 | 100.0 | 20707 |
| sram_spm_4p4b_xor_1r1w_fixed::spm.txn | 33 | 33 | 100.0 | 20707 |
| ten_1x3_lean::ten_config | 14 | 14 | 100.0 | 35404 |
| ten_1x3_lean::ten_perf | 5 | 5 | 100.0 | 2435 |
| ten_1x3_lean::ten_pressure | 23 | 22 | 95.7 | 27918 |
| ten_1x3_lean::ten_reset | 5 | 5 | 100.0 | 20 |
| ten_1x3_lean::ten_shape | 20 | 20 | 100.0 | 1336 |
| ten_1x3_lean::ten_values | 14 | 14 | 100.0 | 3972 |
| ten_2x2_acc16::ten_config | 18 | 18 | 100.0 | 50619 |
| ten_2x2_acc16::ten_perf | 5 | 5 | 100.0 | 3674 |
| ten_2x2_acc16::ten_pressure | 23 | 23 | 100.0 | 43203 |
| ten_2x2_acc16::ten_reset | 6 | 6 | 100.0 | 60 |
| ten_2x2_acc16::ten_shape | 34 | 34 | 100.0 | 1754 |
| ten_2x2_acc16::ten_values | 16 | 16 | 100.0 | 5154 |
| ten_3x2_mp1_acc24::ten_config | 17 | 17 | 100.0 | 70895 |
| ten_3x2_mp1_acc24::ten_perf | 6 | 6 | 100.0 | 5959 |
| ten_3x2_mp1_acc24::ten_pressure | 23 | 23 | 100.0 | 55167 |
| ten_3x2_mp1_acc24::ten_reset | 6 | 6 | 100.0 | 40 |
| ten_3x2_mp1_acc24::ten_shape | 37 | 37 | 100.0 | 1710 |
| ten_3x2_mp1_acc24::ten_values | 16 | 16 | 100.0 | 5058 |
| ten_4x4::ten_config | 18 | 18 | 100.0 | 78410 |
| ten_4x4::ten_perf | 5 | 5 | 100.0 | 4308 |
| ten_4x4::ten_pressure | 23 | 23 | 100.0 | 66110 |
| ten_4x4::ten_reset | 6 | 6 | 100.0 | 20 |
| ten_4x4::ten_shape | 44 | 44 | 100.0 | 1545 |
| ten_4x4::ten_values | 14 | 14 | 100.0 | 4599 |
| vec_arr_deep::arr_cmd | 186 | 186 | 100.0 | 1665 |
| vec_arr_deep::arr_config_change | 39 | 39 | 100.0 | 6958 |
| vec_arr_deep::arr_errors | 20 | 17 | 85.0 | 1665 |
| vec_arr_deep::arr_lanes | 76 | 76 | 100.0 | 99841 |
| vec_arr_deep::arr_pressure | 29 | 29 | 100.0 | 40537 |
| vec_arr_deep::arr_reduction | 43 | 43 | 100.0 | 790 |
| vec_arr_deep::arr_reset | 6 | 3 | 50.0 | 18 |
| vec_arr_lean::arr_cmd | 181 | 176 | 97.2 | 1690 |
| vec_arr_lean::arr_config_change | 39 | 29 | 74.4 | 7629 |
| vec_arr_lean::arr_errors | 20 | 20 | 100.0 | 1690 |
| vec_arr_lean::arr_lanes | 52 | 52 | 100.0 | 24259 |
| vec_arr_lean::arr_pressure | 27 | 27 | 100.0 | 22375 |
| vec_arr_lean::arr_reset | 5 | 4 | 80.0 | 18 |
| vec_arr_n16::arr_cmd | 186 | 184 | 98.9 | 1496 |
| vec_arr_n16::arr_config_change | 39 | 39 | 100.0 | 6375 |
| vec_arr_n16::arr_errors | 23 | 22 | 95.7 | 1496 |
| vec_arr_n16::arr_lanes | 103 | 102 | 99.0 | 67645 |
| vec_arr_n16::arr_pressure | 29 | 29 | 100.0 | 17954 |
| vec_arr_n16::arr_reduction | 43 | 43 | 100.0 | 916 |
| vec_arr_n16::arr_reset | 6 | 3 | 50.0 | 18 |
| vec_arr_n1::arr_cmd | 171 | 160 | 93.6 | 1320 |
| vec_arr_n1::arr_config_change | 39 | 39 | 100.0 | 5008 |
| vec_arr_n1::arr_errors | 20 | 16 | 80.0 | 1320 |
| vec_arr_n1::arr_lanes | 67 | 67 | 100.0 | 16460 |
| vec_arr_n1::arr_pressure | 29 | 29 | 100.0 | 13163 |
| vec_arr_n1::arr_reduction | 43 | 43 | 100.0 | 662 |
| vec_arr_n1::arr_reset | 6 | 4 | 66.7 | 18 |
| vec_arr_n2::arr_cmd | 181 | 181 | 100.0 | 5809 |
| vec_arr_n2::arr_config_change | 39 | 39 | 100.0 | 30186 |
| vec_arr_n2::arr_errors | 20 | 20 | 100.0 | 5809 |
| vec_arr_n2::arr_lanes | 70 | 70 | 100.0 | 106936 |
| vec_arr_n2::arr_pressure | 29 | 29 | 100.0 | 89523 |
| vec_arr_n2::arr_reduction | 43 | 43 | 100.0 | 2051 |
| vec_arr_n2::arr_reset | 6 | 6 | 100.0 | 54 |
| vec_arr_n4::arr_cmd | 186 | 186 | 100.0 | 5227 |
| vec_arr_n4::arr_config_change | 39 | 39 | 100.0 | 27848 |
| vec_arr_n4::arr_errors | 20 | 20 | 100.0 | 5227 |
| vec_arr_n4::arr_lanes | 76 | 76 | 100.0 | 129004 |
| vec_arr_n4::arr_pressure | 29 | 29 | 100.0 | 89531 |
| vec_arr_n4::arr_reduction | 43 | 43 | 100.0 | 2011 |
| vec_arr_n4::arr_reset | 6 | 5 | 83.3 | 36 |
| vec_arr_n8::arr_cmd | 186 | 180 | 96.8 | 1754 |
| vec_arr_n8::arr_config_change | 39 | 39 | 100.0 | 7913 |
| vec_arr_n8::arr_errors | 20 | 18 | 90.0 | 1754 |
| vec_arr_n8::arr_lanes | 88 | 88 | 100.0 | 57691 |
| vec_arr_n8::arr_pressure | 29 | 29 | 100.0 | 23793 |
| vec_arr_n8::arr_reduction | 43 | 43 | 100.0 | 1005 |
| vec_arr_n8::arr_reset | 6 | 4 | 66.7 | 18 |
| vec_arr_tiny::arr_cmd | 181 | 179 | 98.9 | 2384 |
| vec_arr_tiny::arr_config_change | 39 | 29 | 74.4 | 11066 |
| vec_arr_tiny::arr_errors | 20 | 20 | 100.0 | 2384 |
| vec_arr_tiny::arr_lanes | 70 | 70 | 100.0 | 42746 |
| vec_arr_tiny::arr_pressure | 29 | 28 | 96.5 | 40502 |
| vec_arr_tiny::arr_reduction | 43 | 43 | 100.0 | 911 |
| vec_arr_tiny::arr_reset | 6 | 5 | 83.3 | 36 |
| vec_lane_def::lane_flags | 28 | 28 | 100.0 | 310789 |
| vec_lane_def::lane_op_rm | 113 | 113 | 100.0 | 193178 |
| vec_lane_def::lane_pipeline | 30 | 30 | 100.0 | 845811 |
| vec_lane_def::lane_values | 286 | 286 | 100.0 | 188897 |
| vec_lane_lean::lane_flags | 25 | 25 | 100.0 | 202821 |
| vec_lane_lean::lane_op_rm | 113 | 113 | 100.0 | 115429 |
| vec_lane_lean::lane_pipeline | 29 | 29 | 100.0 | 397365 |
| vec_lane_lean::lane_values | 220 | 220 | 100.0 | 111875 |
| vec_lane_min::lane_flags | 28 | 28 | 100.0 | 158527 |
| vec_lane_min::lane_op_rm | 113 | 113 | 100.0 | 113496 |
| vec_lane_min::lane_pipeline | 28 | 28 | 100.0 | 676118 |
| vec_lane_min::lane_values | 286 | 286 | 100.0 | 109723 |
| vec_lane_tiny::lane_flags | 28 | 28 | 100.0 | 23197 |
| vec_lane_tiny::lane_op_rm | 113 | 113 | 100.0 | 16909 |
| vec_lane_tiny::lane_pipeline | 22 | 22 | 100.0 | 227130 |
| vec_lane_tiny::lane_values | 286 | 286 | 100.0 | 16160 |
| xbar_1x1::fab_addr | 11 | 11 | 100.0 | 12272 |
| xbar_1x1::fab_arb | 4 | 4 | 100.0 | 27587 |
| xbar_1x1::fab_bp | 15 | 15 | 100.0 | 45746 |
| xbar_1x1::fab_conc | 4 | 4 | 100.0 | 55015 |
| xbar_1x1::fab_err | 12 | 12 | 100.0 | 9837 |
| xbar_1x1::fab_perf | 9 | 9 | 100.0 | 275075 |
| xbar_1x1::fab_reset | 27 | 27 | 100.0 | 198 |
| xbar_1x1::fab_txn | 9 | 9 | 100.0 | 16855 |
| xbar_2x2_dw64::fab_addr | 15 | 15 | 100.0 | 19103 |
| xbar_2x2_dw64::fab_arb | 10 | 10 | 100.0 | 36977 |
| xbar_2x2_dw64::fab_bp | 15 | 15 | 100.0 | 68759 |
| xbar_2x2_dw64::fab_conc | 8 | 8 | 100.0 | 55855 |
| xbar_2x2_dw64::fab_err | 13 | 13 | 100.0 | 12415 |
| xbar_2x2_dw64::fab_perf | 10 | 10 | 100.0 | 236655 |
| xbar_2x2_dw64::fab_reset | 27 | 27 | 100.0 | 296 |
| xbar_2x2_dw64::fab_txn | 19 | 19 | 100.0 | 25054 |
| xbar_2x2_fx::fab_addr | 15 | 15 | 100.0 | 22056 |
| xbar_2x2_fx::fab_arb | 9 | 9 | 100.0 | 41959 |
| xbar_2x2_fx::fab_bp | 15 | 15 | 100.0 | 81333 |
| xbar_2x2_fx::fab_conc | 8 | 8 | 100.0 | 64051 |
| xbar_2x2_fx::fab_err | 13 | 13 | 100.0 | 16104 |
| xbar_2x2_fx::fab_perf | 10 | 10 | 100.0 | 286560 |
| xbar_2x2_fx::fab_reset | 27 | 27 | 100.0 | 295 |
| xbar_2x2_fx::fab_txn | 19 | 19 | 100.0 | 29841 |
| xbar_2x2_noal::fab_addr | 15 | 15 | 100.0 | 18675 |
| xbar_2x2_noal::fab_arb | 10 | 10 | 100.0 | 38452 |
| xbar_2x2_noal::fab_bp | 15 | 15 | 100.0 | 64924 |
| xbar_2x2_noal::fab_conc | 8 | 8 | 100.0 | 55704 |
| xbar_2x2_noal::fab_err | 10 | 10 | 100.0 | 9793 |
| xbar_2x2_noal::fab_perf | 10 | 10 | 100.0 | 238155 |
| xbar_2x2_noal::fab_reset | 27 | 27 | 100.0 | 285 |
| xbar_2x2_noal::fab_txn | 19 | 19 | 100.0 | 23282 |
| xbar_2x4_rr::fab_addr | 27 | 27 | 100.0 | 18420 |
| xbar_2x4_rr::fab_arb | 10 | 10 | 100.0 | 36477 |
| xbar_2x4_rr::fab_bp | 15 | 15 | 100.0 | 68428 |
| xbar_2x4_rr::fab_conc | 8 | 8 | 100.0 | 47186 |
| xbar_2x4_rr::fab_err | 13 | 13 | 100.0 | 13951 |
| xbar_2x4_rr::fab_perf | 10 | 10 | 100.0 | 214055 |
| xbar_2x4_rr::fab_reset | 27 | 27 | 100.0 | 310 |
| xbar_2x4_rr::fab_txn | 29 | 29 | 100.0 | 25236 |
| xbar_3x2_dw128::fab_addr | 17 | 17 | 100.0 | 19927 |
| xbar_3x2_dw128::fab_arb | 17 | 17 | 100.0 | 34230 |
| xbar_3x2_dw128::fab_bp | 15 | 15 | 100.0 | 82390 |
| xbar_3x2_dw128::fab_conc | 9 | 9 | 100.0 | 54195 |
| xbar_3x2_dw128::fab_err | 17 | 17 | 100.0 | 21763 |
| xbar_3x2_dw128::fab_perf | 10 | 10 | 100.0 | 196390 |
| xbar_3x2_dw128::fab_reset | 27 | 27 | 100.0 | 340 |
| xbar_3x2_dw128::fab_txn | 24 | 24 | 100.0 | 31477 |
| xbar_3x3_part::fab_addr | 23 | 23 | 100.0 | 14796 |
| xbar_3x3_part::fab_arb | 12 | 12 | 100.0 | 26953 |
| xbar_3x3_part::fab_bp | 15 | 15 | 100.0 | 73109 |
| xbar_3x3_part::fab_conc | 10 | 10 | 100.0 | 35418 |
| xbar_3x3_part::fab_err | 17 | 17 | 100.0 | 26530 |
| xbar_3x3_part::fab_perf | 10 | 10 | 100.0 | 160725 |
| xbar_3x3_part::fab_reset | 27 | 27 | 100.0 | 349 |
| xbar_3x3_part::fab_txn | 27 | 27 | 100.0 | 29449 |
| xbar_3x3_rr::fab_addr | 21 | 21 | 100.0 | 30132 |
| xbar_3x3_rr::fab_arb | 17 | 17 | 100.0 | 54006 |
| xbar_3x3_rr::fab_bp | 15 | 15 | 100.0 | 108486 |
| xbar_3x3_rr::fab_conc | 10 | 10 | 100.0 | 69423 |
| xbar_3x3_rr::fab_err | 14 | 14 | 100.0 | 19286 |
| xbar_3x3_rr::fab_perf | 10 | 10 | 100.0 | 255955 |
| xbar_3x3_rr::fab_reset | 27 | 27 | 100.0 | 361 |
| xbar_3x3_rr::fab_txn | 33 | 33 | 100.0 | 39502 |
| xbar_4x2_rr::fab_addr | 15 | 15 | 100.0 | 37019 |
| xbar_4x2_rr::fab_arb | 26 | 26 | 100.0 | 63730 |
| xbar_4x2_rr::fab_bp | 15 | 15 | 100.0 | 127478 |
| xbar_4x2_rr::fab_conc | 10 | 10 | 100.0 | 115082 |
| xbar_4x2_rr::fab_err | 15 | 15 | 100.0 | 18755 |
| xbar_4x2_rr::fab_perf | 10 | 10 | 100.0 | 317605 |
| xbar_4x2_rr::fab_reset | 27 | 27 | 100.0 | 367 |
| xbar_4x2_rr::fab_txn | 33 | 33 | 100.0 | 45556 |
| xbar_ovl::fab_addr | 17 | 17 | 100.0 | 21319 |
| xbar_ovl::fab_arb | 10 | 10 | 100.0 | 42031 |
| xbar_ovl::fab_bp | 15 | 15 | 100.0 | 67712 |
| xbar_ovl::fab_conc | 8 | 8 | 100.0 | 54795 |
| xbar_ovl::fab_err | 10 | 10 | 100.0 | 4712 |
| xbar_ovl::fab_perf | 10 | 10 | 100.0 | 238360 |
| xbar_ovl::fab_reset | 27 | 27 | 100.0 | 286 |
| xbar_ovl::fab_txn | 20 | 20 | 100.0 | 23300 |
| xbar_soc4x7::fab_addr | 41 | 41 | 100.0 | 37174 |
| xbar_soc4x7::fab_arb | 26 | 26 | 100.0 | 64081 |
| xbar_soc4x7::fab_bp | 15 | 15 | 100.0 | 144463 |
| xbar_soc4x7::fab_conc | 12 | 12 | 100.0 | 61542 |
| xbar_soc4x7::fab_err | 18 | 18 | 100.0 | 32239 |
| xbar_soc4x7::fab_perf | 10 | 10 | 100.0 | 232170 |
| xbar_soc4x7::fab_reset | 27 | 27 | 100.0 | 476 |
| xbar_soc4x7::fab_txn | 74 | 74 | 100.0 | 54196 |

## Uncovered bins (72)

* `ten_1x3_lean::ten_pressure` point.gap_run.8+
* `vec_arr_deep::arr_errors` crosse.kind_x_vl.bad_rm*zero
* `vec_arr_deep::arr_errors` crosse.kind_x_vl.red_nonfp_op*zero
* `vec_arr_deep::arr_errors` crosse.kind_x_vl.reserved_op*zero
* `vec_arr_deep::arr_reset` point.ctx.cmd_queued
* `vec_arr_deep::arr_reset` point.ctx.cpl_stalled
* `vec_arr_deep::arr_reset` point.ctx.result_stalled
* `vec_arr_lean::arr_cmd` point.vl_class.max
* `vec_arr_lean::arr_cmd` crosse.vl_x_vm_x_red.max*0*0
* `vec_arr_lean::arr_cmd` crosse.vl_x_vm_x_red.max*0*1
* `vec_arr_lean::arr_cmd` crosse.vl_x_vm_x_red.max*1*0
* `vec_arr_lean::arr_cmd` crosse.vl_x_vm_x_red.max*1*1
* `vec_arr_lean::arr_config_change` point.gap.b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.bcast*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.none*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.op*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.red*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.rm*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.scalar*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.tid*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.vl*b2b
* `vec_arr_lean::arr_config_change` crosse.field_x_gap.vm*b2b
* `vec_arr_lean::arr_reset` point.ctx.cmd_queued
* `vec_arr_n16::arr_cmd` crosse.op_x_rm.FEQ*RDN
* `vec_arr_n16::arr_cmd` crosse.op_x_rm.IMUL*illegal5-7
* `vec_arr_n16::arr_errors` crosse.kind_x_vl.bad_rm*zero
* `vec_arr_n16::arr_lanes` point.lanes_held.14
* `vec_arr_n16::arr_reset` point.ctx.cmd_queued
* `vec_arr_n16::arr_reset` point.ctx.cpl_stalled
* `vec_arr_n16::arr_reset` point.ctx.result_stalled
* `vec_arr_n1::arr_cmd` point.vl_class.max
* `vec_arr_n1::arr_cmd` point.vl_class.nonmult_gt_N
* `vec_arr_n1::arr_cmd` crosse.op_x_rm.IADD*illegal5-7
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.max*0*0
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.max*0*1
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.max*1*0
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.max*1*1
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.nonmult_gt_N*0*0
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.nonmult_gt_N*0*1
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.nonmult_gt_N*1*0
* `vec_arr_n1::arr_cmd` crosse.vl_x_vm_x_red.nonmult_gt_N*1*1
* `vec_arr_n1::arr_errors` crosse.kind_x_vl.bad_rm*zero
* `vec_arr_n1::arr_errors` crosse.kind_x_vl.red_bad_rm*zero
* `vec_arr_n1::arr_errors` crosse.kind_x_vl.red_bcast*zero
* `vec_arr_n1::arr_errors` crosse.kind_x_vl.red_nonfp_op*zero
* `vec_arr_n1::arr_reset` point.ctx.cmd_queued
* `vec_arr_n1::arr_reset` point.ctx.result_stalled
* `vec_arr_n4::arr_reset` point.ctx.cpl_stalled
* `vec_arr_n8::arr_cmd` point.vl_class.max
* `vec_arr_n8::arr_cmd` crosse.op_x_rm.IADD*illegal5-7
* `vec_arr_n8::arr_cmd` crosse.vl_x_vm_x_red.max*0*0
* `vec_arr_n8::arr_cmd` crosse.vl_x_vm_x_red.max*0*1
* `vec_arr_n8::arr_cmd` crosse.vl_x_vm_x_red.max*1*0
* `vec_arr_n8::arr_cmd` crosse.vl_x_vm_x_red.max*1*1
* `vec_arr_n8::arr_errors` crosse.kind_x_vl.red_bad_rm*zero
* `vec_arr_n8::arr_errors` crosse.kind_x_vl.reserved_op*zero
* `vec_arr_n8::arr_reset` point.ctx.cmd_queued
* `vec_arr_n8::arr_reset` point.ctx.cpl_stalled
* `vec_arr_tiny::arr_cmd` crosse.op_x_rm.FMIN*illegal5-7
* `vec_arr_tiny::arr_cmd` crosse.op_x_rm.IADD*illegal5-7
* `vec_arr_tiny::arr_config_change` point.gap.b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.bcast*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.none*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.op*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.red*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.rm*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.scalar*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.tid*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.vl*b2b
* `vec_arr_tiny::arr_config_change` crosse.field_x_gap.vm*b2b
* `vec_arr_tiny::arr_pressure` point.outstanding.5+
* `vec_arr_tiny::arr_reset` point.ctx.cmd_queued
