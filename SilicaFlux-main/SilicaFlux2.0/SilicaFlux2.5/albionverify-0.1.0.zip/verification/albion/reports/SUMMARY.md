# AlbionVerify regression report

* generated: 2026-11-17T12:27:11Z (first regression part; later parts and the mutation/coverage runs followed on the same day)
* tools: Verilator `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`, cocotb `1.9.2`, Python `3.13.18`
* RTL under test (pinned set digest): `0c5e1db7f824d934fdb990bdf9a28282e071910943c02955d27e8feca717ceaf`
* **runs: 824** -- PASS 822, XFAIL 2 -- 59718792 scoreboard/protocol checks evaluated

## 1. Regression by suite

| suite | runs | PASS | FAIL/other | XFAIL (known defect) | checks | sim wall (s) |
|---|---:|---:|---:|---:|---:|---:|
| ctl_core | 16 | 16 | 0 | 0 | 1999092 | 968 |
| ctl_core_fast | 4 | 4 | 0 | 0 | 216236 | 108 |
| ctl_mailbox | 32 | 31 | 0 | 1 | 1241186 | 61 |
| ctl_perf | 19 | 19 | 0 | 0 | 96139 | 33 |
| ctl_pmu | 13 | 13 | 0 | 0 | 411050 | 25 |
| ctl_ras | 16 | 16 | 0 | 0 | 443268 | 22 |
| ctl_secmon | 12 | 12 | 0 | 0 | 117142 | 15 |
| ctl_sfbgate | 15 | 15 | 0 | 0 | 1326539 | 31 |
| ctl_sysctrl | 14 | 14 | 0 | 0 | 527179 | 18 |
| dma_adapter | 27 | 27 | 0 | 0 | 59304 | 45 |
| dma_buffered | 50 | 50 | 0 | 0 | 1395155 | 210 |
| dma_simple | 17 | 17 | 0 | 0 | 492617 | 74 |
| fab_arbiter | 15 | 15 | 0 | 0 | 2784711 | 57 |
| fab_cells | 12 | 12 | 0 | 0 | 276158 | 15 |
| fab_regslice | 15 | 15 | 0 | 0 | 547255 | 25 |
| framework_smoke | 3 | 3 | 0 | 0 | 23817 | 3 |
| sram_banked | 90 | 90 | 0 | 0 | 2665620 | 143 |
| sram_sp | 153 | 153 | 0 | 0 | 1753505 | 219 |
| sram_spm | 39 | 39 | 0 | 0 | 3020468 | 69 |
| ten_array | 37 | 37 | 0 | 0 | 3431041 | 65 |
| vec_array | 86 | 86 | 0 | 0 | 6851569 | 131 |
| vec_lane | 46 | 46 | 0 | 0 | 13096526 | 199 |
| xbar | 93 | 92 | 0 | 1 | 16943215 | 398 |

*`ctl_core_fast` re-runs 4 of the 16 `ctl_core` cases (used to keep the determinism check affordable); its runs are included in the totals above.*

### Non-passing runs

* **XFAIL** `xbar_3x3_rr::cocotb_xbar_known::all::seed1` (known defect DF-F1)
  * why: albionverify.core.AlbionCheckError: R11: req_ready of the fabric was high in 8 of 8 reset cycles while master 0 presented a request (a transfer is possible during reset)
  * reproduce: `python -m albionverify run --dut xbar_3x3_rr --module fabric.cocotb_xbar_known --seed 1`
  * waveform: `reports/out/waves/xbar_3x3_rr_cocotb_xbar_known_all_seed1.fst`
* **XFAIL** `ctl_mbox256::cocotb_mailbox::unaligned_probe::seed1` (known defect CTL-001)
  * why: albionverify.core.AlbionCheckError: [mbox/mbox @cycle 6] rb_err mismatch [cyc=6 sel=1 we=1 addr=0x001 wdata=0xdeadbeef rst=- inputs={'_cycle': 6}]: expected 0x1, got 0x0
  * reproduce: `python -m albionverify run --dut ctl_mbox256 --module control.cocotb_mailbox --testcase unaligned_probe --seed 1`
  * waveform: `reports/out/waves/ctl_mbox256_cocotb_mailbox_unaligned_probe_seed1.fst`
## 2. Reproducibility

* determinism check: **487** run(s) executed twice in fresh processes (2 file(s)); **0 mismatch(es)** of status/trace digest -> REPRODUCIBLE
* every run's seed, build key and trace digest are recorded in `reports/regression/<label>.seeds.json` (labels: `regression_part1`, `regression_part2`); non-passing runs list their exact reproduction command in `<label>.failures.txt`.

## 3. Fault injection (mutation) -- do injected functional errors fail the tests?

**Block mutant sets (written by the bench authors; see docs/MUTATION_NOTES.md for the validity caveat)**

| suite | mutants | killed | survived | unobservable | argued-equivalent | invalid | score | kills by check | by RTL assertion | by hang/crash |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctl_core | 19 | 19 | 0 | 0 | 0 | 0 | 100.0% | 17 | 0 | 2 |
| ctl_mailbox | 31 | 31 | 0 | 0 | 0 | 0 | 100.0% | 31 | 0 | 0 |
| ctl_perf | 24 | 23 | 0 | 1 | 0 | 0 | 95.8% | 23 | 0 | 0 |
| ctl_pmu | 29 | 28 | 0 | 1 | 0 | 0 | 96.6% | 28 | 0 | 0 |
| ctl_ras | 37 | 36 | 0 | 1 | 0 | 0 | 97.3% | 36 | 0 | 0 |
| ctl_secmon | 25 | 24 | 0 | 1 | 0 | 0 | 96.0% | 24 | 0 | 0 |
| ctl_sfbgate | 26 | 26 | 0 | 0 | 0 | 0 | 100.0% | 26 | 0 | 0 |
| ctl_sysctrl | 33 | 33 | 0 | 0 | 0 | 0 | 100.0% | 33 | 0 | 0 |
| dma_adapter | 26 | 24 | 0 | 0 | 2 | 0 | 100.0% | 22 | 1 | 1 |
| dma_buffered | 30 | 30 | 0 | 0 | 0 | 0 | 100.0% | 29 | 1 | 0 |
| dma_simple | 45 | 45 | 0 | 0 | 0 | 0 | 100.0% | 45 | 0 | 0 |
| fab_arbiter | 17 | 15 | 0 | 0 | 2 | 0 | 100.0% | 15 | 0 | 0 |
| fab_cells | 16 | 15 | 0 | 0 | 1 | 0 | 100.0% | 15 | 0 | 0 |
| fab_regslice | 16 | 16 | 0 | 0 | 0 | 0 | 100.0% | 16 | 0 | 0 |
| framework_smoke | 6 | 6 | 0 | 0 | 0 | 0 | 100.0% | 6 | 0 | 0 |
| sram_banked | 31 | 30 | 0 | 0 | 1 | 0 | 100.0% | 29 | 1 | 0 |
| sram_sp | 34 | 34 | 0 | 0 | 0 | 0 | 100.0% | 31 | 3 | 0 |
| sram_spm | 32 | 30 | 0 | 0 | 2 | 0 | 100.0% | 29 | 1 | 0 |
| ten_array | 52 | 48 | 0 | 2 | 2 | 0 | 96.0% | 48 | 0 | 0 |
| vec_array | 49 | 48 | 0 | 0 | 1 | 0 | 100.0% | 41 | 4 | 3 |
| vec_lane | 40 | 39 | 0 | 0 | 1 | 0 | 100.0% | 37 | 2 | 0 |
| xbar | 62 | 57 | 0 | 0 | 5 | 0 | 100.0% | 57 | 0 | 0 |

**Total: 657 killed, 0 survived, 6 unobservable-survived.**

**HELD-OUT mutants (written by the lead after the benches were finished; the benches' own test cases, unchanged)**

| suite | mutants | killed | survived | unobservable | argued-equivalent | invalid | score | kills by check | by RTL assertion | by hang/crash |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| heldout_dma | 3 | 3 | 0 | 0 | 0 | 0 | 100.0% | 3 | 0 | 0 |
| heldout_fabric | 4 | 4 | 0 | 0 | 0 | 0 | 100.0% | 4 | 0 | 0 |
| heldout_gate | 1 | 1 | 0 | 0 | 0 | 0 | 100.0% | 1 | 0 | 0 |
| heldout_mailbox | 1 | 1 | 0 | 0 | 0 | 0 | 100.0% | 1 | 0 | 0 |
| heldout_sram | 2 | 2 | 0 | 0 | 0 | 0 | 100.0% | 1 | 1 | 0 |
| heldout_ten | 1 | 1 | 0 | 0 | 0 | 0 | 100.0% | 1 | 0 | 0 |
| heldout_vec | 1 | 1 | 0 | 0 | 0 | 0 | 100.0% | 1 | 0 | 0 |

**Total: 13 killed, 0 survived, 0 unobservable-survived.**

### Survivors (verification gaps / limits)

* `ctl_perf` / CF-15 [counter] **UNOBSERVABLE_SURVIVED**: Event counters never saturate (wrap at 2^32): not observable in simulation.
* `ctl_pmu` / CP-15 [counter] **UNOBSERVABLE_SURVIVED**: SLEEP_CYC never saturates (wraps at 2^32): not observable in simulation (needs 4.29e9 sleeping cycles).
* `ctl_ras` / CR-22 [counter] **UNOBSERVABLE_SURVIVED**: Counters wrap instead of saturating at 2^32-1 (not observable in simulation).
* `ctl_secmon` / CT-25 [counter] **UNOBSERVABLE_SURVIVED**: VIOL_COUNT wraps instead of saturating (not observable in simulation).
* `ten_array` / TM-36 [checker] **UNOBSERVABLE_SURVIVED**: Alignment checker: the missing-token check is removed.
* `ten_array` / TM-37 [checker] **UNOBSERVABLE_SURVIVED**: align_err is not cleared at the next launch (sticky forever).

## 4. Functional coverage (stimulus scenarios -- not RTL coverage)

**regression_part1**: 99.4% (11130 of 11202 defined bins hit) from 1615 test results over 70 DUT configuration(s); merged per configuration, never across them

| DUT configuration | bins | hit | uncovered |
|---|---:|---:|---:|
| ten_1x3_lean | 81 | 80 | 1 |
| vec_arr_deep | 399 | 393 | 6 |
| vec_arr_lean | 324 | 308 | 16 |
| vec_arr_n1 | 375 | 358 | 17 |
| vec_arr_n16 | 429 | 422 | 7 |
| vec_arr_n4 | 399 | 398 | 1 |
| vec_arr_n8 | 411 | 401 | 10 |
| vec_arr_tiny | 388 | 374 | 14 |

62 of 70 configurations have every defined bin hit; per-group tables and the exact uncovered bins are in `reports/coverage/functional/regression_part1.md`.

**regression_part2**: 99.1% (639 of 645 defined bins hit) from 140 test results over 10 DUT configuration(s); merged per configuration, never across them

| DUT configuration | bins | hit | uncovered |
|---|---:|---:|---:|
| ctl_core | 69 | 65 | 4 |
| ctl_mbox8 | 73 | 71 | 2 |

8 of 10 configurations have every defined bin hit; per-group tables and the exact uncovered bins are in `reports/coverage/functional/regression_part2.md`.

## 5. RTL code coverage (Verilator line / branch / toggle -- separate from the above)

**coverage_run** (260 runs merged, over 22 DUT configurations -- the first configuration of each suite, `--first-config-only`): line 90.29% (1600/1772), branch 89.81% (1031/1148), toggle 98.66% (49055/49723)

Per-file tables and LCOV `.info` files are in `reports/coverage/code/`.

## 6. Existing-code audit headline

* 1442 unique RTL modules: Verilator lint PASS 1306 / FAIL 136; Icarus PASS 1198 / FAIL 243
* 405 unique testbenches executed: BUILD_FAIL 86, FAIL 11, NEEDS_FLOW 39, NO_VERDICT 39, PASS 194, TIMEOUT 36
* 684 unique RTL modules are in the hierarchy of a passing testbench; 160 carry strong behavioural/stand-in evidence; 131 modules exist in >1 different version
* details: `reports/audit/AUDIT.md`

## 7. Findings and known defects

RTL defects/discrepancies reproduced by the regression (reported as XFAIL, not as passes):

* **DF-F1** -- albionverify.core.AlbionCheckError: R11: req_ready of the fabric was high in 8 of 8 reset cycles while master 0 presented a request (a transfer is possible during reset); reproduce: `python -m albionverify run --dut xbar_3x3_rr --module fabric.cocotb_xbar_known --seed 1`
* **CTL-001** -- albionverify.core.AlbionCheckError: [mbox/mbox @cycle 6] rb_err mismatch [cyc=6 sel=1 we=1 addr=0x001 wdata=0xdeadbeef rst=- inputs={'_cycle': 6}]: expected 0x1, got 0x0; reproduce: `python -m albionverify run --dut ctl_mbox256 --module control.cocotb_mailbox --testcase unaligned_probe --seed 1`

* `docs/findings_compute.md`
* `docs/findings_control.md`
* `docs/findings_dma.md`
* `docs/findings_fabric.md`
* `docs/findings_sram.md`
