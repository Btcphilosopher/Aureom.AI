# AlbionVerify -- functional hardware verification for SilicaFlux (Module 93)

A reusable verification environment in which the **actual SilicaFlux RTL** is checked against **independent
reference models**. Simulation: Verilator 5.020 + cocotb 1.9.2 + pytest; audit tooling also uses Icarus 12.

**Read first:** `reports/SUMMARY.md` (every number, from executed runs), `reports/audit/AUDIT.md` (what the existing code
does), `docs/VERIFICATION_PLAN.md` (requirement traceability), `docs/MUTATION_NOTES.md` (how to read the fault-injection scores).

## Success criterion, and how it is checked

| criterion | mechanism | evidence |
|---|---|---|
| the actual RTL is exercised | RTL is vendored byte-for-byte from the repository archives, pinned by SHA-256 (`rtl/MANIFEST.json`); every build re-checks the pins | `make vendor-check` |
| ...against independent models | pure-Python models written from the specification documents and first principles, with their own simulator-free tests; never fitted to the RTL | `albionverify/models/`, `tests/*/test_model_*.py`, `docs/*_verification_plan.md` |
| injected functional errors fail the tests | mutation engine: exact-text RTL patches; baseline must pass; a mutant is killed only by a failing test; unobservable survivors count against the score; plus a **held-out** mutant set the benches were never tuned against | `reports/mutation/`, `make mutate` |
| passing results are reproducible | deterministic seeded stimulus (no global RNG), pinned RTL, content-keyed builds, SHA-256 trace digest per run, every suite run twice in fresh processes and compared | `reports/determinism_*.json`, `reports/regression/*.seeds.json`, `make determinism` |

## Results at delivery (all from executed runs; details in `reports/SUMMARY.md`)

| item | result |
|---|---|
| existing-code audit | 1,442 unique RTL modules: Verilator lint 1,306 PASS / 136 FAIL, Icarus 1,198 PASS / 243 FAIL; 405 unique testbenches executed: **194 PASS**, 11 FAIL, 39 NO_VERDICT, 36 TIMEOUT, 39 NEEDS_FLOW, 86 BUILD_FAIL (only PASS counts as evidence; the rest are never reported as passing) |
| regression (22 suites, 70+10 DUT configurations) | **824 runs: 822 PASS, 2 XFAIL (documented RTL defects), 0 FAIL**; 59.7 M scoreboard/protocol checks (824 includes 4 re-runs of `ctl_core` cases in `ctl_core_fast`) |
| reproducibility | **487 runs executed twice in fresh processes: 0 mismatches** of status and SHA-256 trace digest |
| fault injection, block mutant sets | 680 mutants: **657 killed** (638 by bench checks, 13 by RTL assertions, 6 by hang/crash), **0 survived**, 6 unobservable through the ports (counted against the score: 99.1%), 17 argued equivalent (excluded) |
| fault injection, **held-out** mutants (authored after the benches, benches unchanged) | **13 / 13 killed** (12 by bench checks, 1 by an RTL assertion) |
| functional coverage | 99.4% of 11,202 defined bins (70 configurations) and 99.1% of 645 bins (10 control configurations); holes listed per bin |
| RTL code coverage (first configuration of each suite, 22 configurations, 260 runs) | line 90.3%, branch 89.8%, toggle 98.7% (kept separate from functional coverage) |

RTL defects / discrepancies found (reproduced as `XFAIL` in the regression):
**DF-F1** `sfb_crossbar` does not gate `req_ready` during reset although `PROTOCOL.md` R11 says it is 0 (`docs/findings_fabric.md`);
**CTL-001** `cc_mailbox` accepts unaligned offsets in its message windows with no bus error (`docs/findings_control.md`).
Documentation defects: `hpc_spm_defs.svh` says the RR pointer moves past the *last* winner while the RTL and doc 03 use the *first* (F-SRAM-01);
ROM mailbox reply format / unsolicited BAD_CMD undocumented (CTL-D1); tensor array called "weight-stationary" by the Albion tooling but is output-stationary per its own docs (D-SPEC-01).
No other defect was found; that is a statement about the stimulus and models here, not a proof of absence (see each plan's "not verified" list and `docs/MUTATION_NOTES.md`).

## Quick start

```bash
sudo apt-get install -y verilator make g++ perl python3-pip      # Ubuntu 24.04 ships Verilator 5.020 (the tested version)
pip install -r requirements.txt                                   # cocotb==1.9.2, pytest, pyyaml, numpy
make doctor vendor-check unit                                     # toolchain, RTL pins, all simulator-free tests (framework + reference models)
make regress                                                      # every suite, every seed; waveforms kept for failures
make determinism mutate coverage                                  # reproducibility, fault injection, coverage
make report                                                       # reports/SUMMARY.md
python -m albionverify run --dut D --module M --testcase T --seed S [--mutant ID|suite:ID]   # reproduce ONE run
```

Every failing run prints its exact reproduction command and leaves a waveform (`reports/out/waves/*.fst`, or `.vcd` with
`ALBION_WAVE_FORMAT=vcd`). `reports/regression/<label>.failures.txt` lists them all; `<label>.seeds.json` records every run's seed and trace digest.

## What is where

```
albionverify/            framework: Env/agents, req-rsp + register-bus drivers and monitors, request generator, scoreboard, memory model,
                         functional coverage, error injectors, reset sequencer, build/run/mutation/report engines, audit
albionverify/models/     independent reference models (SRAM, DMA, DataFabric, FP32/vector, tensor, control)
rtl/                     pinned vendored RTL under test + MANIFEST.json + the project specification documents the models were written from
tests/<block>/           cocotb benches, suite registry (suite.py), model tests;  tests/heldout/: held-out mutation suites
tests/framework_smoke/   worked example and framework self-test on the real crossbar
tests/unit/              framework tests (agents, monitors incl. negative tests, scoreboard, memory, coverage, mutation engine, audit)
mutants/                 fault-injection definitions (one YAML per suite; heldout_*.yaml = held-out set)
docs/                    FRAMEWORK.md (contract + measured simulator facts), VERIFICATION_PLAN.md, per-block plans and findings, guides
reports/                 SUMMARY.md, audit/, regression/, mutation/, coverage/{functional,code}/, determinism_*.json
tools/vendor_rtl.py      regenerate rtl/ from the archives (aborts if an archive's SHA-256 changed)
ci/albion-verify.yml     GitHub Actions workflow (not installed anywhere; copy to .github/workflows/ to enable)
```

## Blocks verified

| block | DUTs | suites |
|---|---|---|
| A SRAM subsystem | `sram_sp`, `sram_bank_controller`, `hpc_scratchpad` | `sram_sp`, `sram_banked`, `sram_spm` |
| B DMA | `silicaflux_dma` (simple + buffered, single/dual port), `hpc_dma_adapter` | `dma_simple`, `dma_buffered`, `dma_adapter` |
| C DataFabric | `sfb_crossbar`, `sfb_arbiter`, `sfb_reg_slice`, `sfb_skid_buffer`, `sfb_error_slave` | `xbar`, `fab_arbiter`, `fab_regslice`, `fab_cells` |
| D Vector / tensor | `hpc_vector_lane`, `hpc_vector_array`, `tensor_systolic_array` | `vec_lane`, `vec_array`, `ten_array` |
| E Control | `cc_mailbox`, `cc_sysctrl`, `cc_pmu`, `cc_ras`, `cc_perf`, `cc_secmon`, `cc_sfb_gate`, `silicaflux_control_core` (real CPU + boot ROM) | `ctl_*` |

Each block's plan lists what is checked and, explicitly, what is **not** verified (`docs/*_verification_plan.md`).

## Policies

* **Evidence only from executed runs.** The audit never turns "not run" into "passed"; the summary refuses to show an absent result as zero failures.
* **Models are never fitted to the RTL.** Disagreements are decided from the specification. Confirmed RTL defects are recorded in `docs/findings_*.md`;
  the reproducing case carries `known_defect:<ID>` and reports `XFAIL` (an unexpected pass is `XPASS`, a failure, so stale annotations cannot linger).
* **Survivors are gaps.** A surviving mutant is fixed by strengthening tests; "equivalent" needs a written argument; "unobservable through the ports" is its own status and counts against the score.
* **Functional and code coverage are never merged** into one number.

## Known limitations of this environment

* Simulation only (cycle-based cocotb on Verilator): no formal proofs, gate level, timing, CDC, power; no hardware run.
* Cycle-driven agents cannot observe combinational-path properties (e.g. SFB2 R3) or glitches between edges other than the provided sub-cycle reset helper.
* White-box fault injection into RTL state is not possible with VPI deposits on this toolchain (measured); fault injection is by RTL mutation.
* Only the DUT configurations built by the suites are verified (small parameter sets: widths, depths, lane counts); wider/larger configurations are not.
* The reference models are only as good as the specifications; each plan lists spec ambiguities and the interpretation used.
