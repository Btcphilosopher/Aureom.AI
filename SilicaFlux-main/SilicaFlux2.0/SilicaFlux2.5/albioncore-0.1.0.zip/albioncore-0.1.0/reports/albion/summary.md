

**Overall: PASS**

# AlbionCore verification summary

Tools: Verilator 5.020, Yosys 0.33, Python 3.13.18.  All results below were produced by the commands in docs/albion/BUILD.md; nothing is hand-entered.

## Static checks

| Check | Result | Detail |
|---|---|---|
| style_check (17 rules) | PASS |  |
| check_deps (dependencies, layering, naming conflicts) | PASS |  |
| validate_params (profiles) | PASS |  |
| gen_proto --check (C/Rust/tables up to date) | PASS |  |
| gen_memmap --check (committed map up to date) | PASS |  |
| trace (contract rules <-> evidence) | PASS |  |

## Lint (Verilator -Wall + Yosys elaboration checks)

40 jobs (every module with default parameters, 23 parameter variants, the profile reference top for each profile): **all clean**

## Simulations (Verilator, self-checking)

| Test | Result | Checks | Errors | Cover bins | Run (s) |
|---|---|---|---|---|---|
| tb_sf_albion_cdc | PASS | 1387570 | 0 | 47 | 3.9 |
| tb_sf_albion_err_resp | PASS | 42761 | 0 | 60 | 1.4 |
| tb_sf_albion_fifo | PASS | 6662220 | 0 | 128 | 8.1 |
| tb_sf_albion_memmap_cloud | PASS | 91 | 0 | 4 | 0.0 |
| tb_sf_albion_memmap_hpc | PASS | 78 | 0 | 4 | 0.0 |
| tb_sf_albion_memmap_min | PASS | 66 | 0 | 4 | 0.0 |
| tb_sf_albion_pkg | PASS | 80076 | 0 | 11 | 1.4 |
| tb_sf_albion_regslice | PASS | 957179 | 0 | 80 | 4.9 |
| tb_sf_albion_skid | PASS | 761169 | 0 | 40 | 2.4 |
| tb_sf_albion_system_cloud | PASS | 2565076 | 0 | 297 | 86.5 |
| tb_sf_albion_system_hpc | PASS | 2520042 | 0 | 297 | 87.4 |
| tb_sf_albion_system_min | PASS | 3110653 | 0 | 297 | 91.1 |
| tb_sf_albion_tag_tracker | PASS | 2376197 | 0 | 107 | 1.3 |
| tb_sf_albion_width_adapter | PASS | 67336 | 0 | 140 | 181.8 |

Total checks executed: **20530514**.

## Functional-coverage goals

55 goals evaluated against the bins printed by the testbenches: **all met**.

## Line coverage of the RTL (Verilator, merged over 14 simulations)

| RTL file | Lines covered | Lines | % |
|---|---|---|---|
| rtl/albion/cdc/sf_albion_async_fifo.sv | 43 | 43 | 100.0 |
| rtl/albion/cdc/sf_albion_cdc_bit_sync.sv | 8 | 8 | 100.0 |
| rtl/albion/cdc/sf_albion_cdc_pulse.sv | 17 | 17 | 100.0 |
| rtl/albion/cdc/sf_albion_reset_sync.sv | 7 | 7 | 100.0 |
| rtl/albion/ref/sf_albion_ref_mem.sv | 55 | 55 | 100.0 |
| rtl/albion/ref/sf_albion_ref_subsystem.sv | 40 | 41 | 97.6 |
| rtl/albion/ref/sf_albion_ref_top.sv | 8 | 8 | 100.0 |
| rtl/albion/sf_albion_err_resp.sv | 27 | 27 | 100.0 |
| rtl/albion/sf_albion_fifo.sv | 44 | 44 | 100.0 |
| rtl/albion/sf_albion_regslice.sv | 19 | 19 | 100.0 |
| rtl/albion/sf_albion_skid.sv | 38 | 38 | 100.0 |
| rtl/albion/sf_albion_tag_tracker.sv | 84 | 84 | 100.0 |
| rtl/albion/sf_albion_width_adapter.sv | 180 | 182 | 98.9 |

Overall: **99.5%** (570 of 573 instrumented lines).  Uncovered lines are listed in coverage.md.

## Formal verification (Yosys + ABC)

| Job | Result | Evidence |
|---|---|---|
| pkg_funcs | PASS | unbounded proof (ABC pdr): PROVED |
| fifo_w2_d1 | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 3); cover 2 reachable: ok (frame 3); cover 3 reachable: ok (frame 3); cover 5 reachable: ok (frame 3); cover 1 unreachable (exhaustive): ok; cover 4 unreachable (bounded 30 frames): ok |
| fifo_w2_d2 | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 4); cover 1 reachable: ok (frame 3); cover 2 reachable: ok (frame 3); cover 3 reachable: ok (frame 3); cover 4 reachable: ok (frame 6); cover 5 reachable: ok (frame 4) |
| fifo_w2_d3 | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 5); cover 1 reachable: ok (frame 3); cover 2 reachable: ok (frame 3); cover 3 reachable: ok (frame 3); cover 4 reachable: ok (frame 6); cover 5 reachable: ok (frame 5) |
| fifo_w2_d4 | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 6); cover 1 reachable: ok (frame 3); cover 2 reachable: ok (frame 3); cover 3 reachable: ok (frame 3); cover 4 reachable: ok (frame 10); cover 5 reachable: ok (frame 6) |
| skid | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 4); cover 1 reachable: ok (frame 3); cover 3 reachable: ok (frame 3); cover 4 reachable: ok (frame 4) |
| regslice_bypass | PASS | unbounded proof (ABC pdr): PROVED; cover 1 reachable: ok (frame 2); cover 2 reachable: ok (frame 2); cover 3 reachable: ok (frame 6); cover 4 reachable: ok (frame 2) |
| regslice_fwd | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 3); cover 1 reachable: ok (frame 3); cover 3 reachable: ok (frame 3); cover 4 reachable: ok (frame 3) |
| regslice_bwd | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 3); cover 1 reachable: ok (frame 2); cover 2 reachable: ok (frame 2); cover 3 reachable: ok (frame 3); cover 4 reachable: ok (frame 3) |
| regslice_full | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 4); cover 1 reachable: ok (frame 3); cover 3 reachable: ok (frame 3); cover 4 reachable: ok (frame 4) |
| tracker_ordered | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 5); cover 1 reachable: ok (frame 3); cover 2 reachable: ok (frame 4); cover 3 reachable: ok (frame 3) |
| tracker_unordered | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 5); cover 1 reachable: ok (frame 3); cover 2 reachable: ok (frame 4); cover 3 reachable: ok (frame 3) |
| tracker_1tag | PASS | unbounded proof (ABC pdr): PROVED |
| tracker_4tag | PASS | unbounded proof (ABC pdr): PROVED |
| tracker_arbitrary_env | PASS | unbounded proof (ABC pdr): PROVED; cover 4 reachable: ok (frame 2); cover 5 reachable: ok (frame 3) |
| err_resp_d1 | PASS | unbounded proof (ABC pdr): PROVED |
| err_resp_d2 | PASS | unbounded proof (ABC pdr): PROVED; cover 0 reachable: ok (frame 3); cover 1 reachable: ok (frame 3); cover 2 reachable: ok (frame 4); cover 3 reachable: ok (frame 3) |
| err_resp_d2_nolegal | PASS | unbounded proof (ABC pdr): PROVED |

## Synthesis (Yosys generic, technology independent)

Cell and flip-flop counts are generic and for regression only -- not area, timing or power.

| Target | Result | Cells | Flop bits | Latches | Budget |
|---|---|---|---|---|---|
| fifo_w16_d8 | PASS | 325 | 138 | 0 |  |
| fifo_req_d4 | PASS | 1702 | 951 | 0 |  |
| skid_req | PASS | 722 | 474 | 0 |  |
| regslice_fwd | PASS | 151 | 149 | 0 |  |
| regslice_bwd | PASS | 303 | 149 | 0 |  |
| regslice_full | PASS | 458 | 298 | 0 |  |
| tag_tracker_8 | PASS | 549 | 119 | 0 |  |
| tag_tracker_64 | PASS | 4269 | 1051 | 0 |  |
| err_resp | PASS | 122 | 32 | 0 |  |
| width_down_32 | PASS | 1325 | 522 | 0 |  |
| width_up_32 | PASS | 1627 | 639 | 0 |  |
| cdc_async_fifo | PASS | 579 | 288 | 0 |  |
| cdc_reset_sync | PASS | 2 | 2 | 0 |  |
| cdc_pulse | PASS | 10 | 6 | 0 |  |
| profile_cloud | PASS | 37600 | 18624 | 0 | <= 41500 cells, <= 20500 flops |
| profile_hpc | PASS | 70699 | 35020 | 0 | <= 78000 cells, <= 38500 flops |
| profile_min | PASS | 5444 | 2656 | 0 | <= 6100 cells, <= 2900 flops |

## Mutation campaign

67 mutants: **67 killed**, 0 survived, 0 invalid.  Every killed mutant was rejected by at least one self-checking simulation or formal proof; see build/mut/summary.json for the killing checks.
