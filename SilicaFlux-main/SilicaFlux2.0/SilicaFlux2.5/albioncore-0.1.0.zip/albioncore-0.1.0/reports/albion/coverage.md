# RTL line coverage

- `rtl/albion/cdc/sf_albion_async_fifo.sv`: 43/43  uncovered lines: none
- `rtl/albion/cdc/sf_albion_cdc_bit_sync.sv`: 8/8  uncovered lines: none
- `rtl/albion/cdc/sf_albion_cdc_pulse.sv`: 17/17  uncovered lines: none
- `rtl/albion/cdc/sf_albion_reset_sync.sv`: 7/7  uncovered lines: none
- `rtl/albion/ref/sf_albion_ref_mem.sv`: 55/55  uncovered lines: none
- `rtl/albion/ref/sf_albion_ref_subsystem.sv`: 40/41  uncovered lines: 87
- `rtl/albion/ref/sf_albion_ref_top.sv`: 8/8  uncovered lines: none
- `rtl/albion/sf_albion_err_resp.sv`: 27/27  uncovered lines: none
- `rtl/albion/sf_albion_fifo.sv`: 44/44  uncovered lines: none
- `rtl/albion/sf_albion_regslice.sv`: 19/19  uncovered lines: none
- `rtl/albion/sf_albion_skid.sv`: 38/38  uncovered lines: none
- `rtl/albion/sf_albion_tag_tracker.sv`: 84/84  uncovered lines: none
- `rtl/albion/sf_albion_width_adapter.sv`: 180/182  uncovered lines: 104, 105
