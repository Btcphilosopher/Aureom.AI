// FIFO properties (sf_noc_fifo, DEPTH=4, 4-bit payload).
//   environment: never push when full, never pop when empty (the handshake the
//   NoC buffers are built around); reset in the first cycle only.
//   proves (induction, unbounded): count bounds, flag consistency, no loss/dup
//   (count == pushes - pops). Proves (BMC): FIFO order of a marked element.
module fv_fifo (input logic clk, input logic rst_n, input logic push, input logic [3:0] din, input logic pop,
                input logic mark);                    // mark: choose (nondeterministically) which push to follow
  localparam int DEPTH = 4;
  logic        full, empty;
  logic [3:0]  dout;
  logic [$clog2(DEPTH+1)-1:0] count;

  sf_noc_fifo #(.T(logic [3:0]), .DEPTH(DEPTH)) dut (
    .clk_i(clk), .rst_ni(rst_n), .push_i(push), .data_i(din), .full_o(full),
    .pop_i(pop), .data_o(dout), .empty_o(empty), .count_o(count));

  logic past_valid = 1'b0;
  always_ff @(posedge clk) past_valid <= 1'b1;
  always_comb if (!past_valid) assume (!rst_n);
  always_comb if (past_valid)  assume (rst_n);

  always_comb assume (!(push && full));
  always_comb assume (!(pop && empty));

  // ---- structural invariants
  always_comb if (past_valid) begin
    assert (count <= DEPTH);
    assert (full  == (count == DEPTH));
    assert (empty == (count == 0));
  end

  // ---- conservation: occupancy == pushes - pops
  logic [$clog2(DEPTH+1)-1:0] shadow = '0;
  always_ff @(posedge clk) if (past_valid) shadow <= shadow + (push ? 1'b1 : 1'b0) - (pop ? 1'b1 : 1'b0);
  always_comb if (past_valid) assert (shadow == count);

`ifdef ORDERING
  // ---- ordering of one marked element: `ahead` = elements queued in front of it
  logic       tracking = 1'b0, done = 1'b0;
  logic [2:0] ahead = '0;
  logic [3:0] val = '0;
  always_ff @(posedge clk) if (past_valid) begin
    if (!tracking && !done && push && mark) begin
      tracking <= 1'b1;
      val      <= din;
      ahead    <= 3'(count) - (pop ? 3'd1 : 3'd0);   // elements in front after this cycle's pop
    end else if (tracking) begin
      if (pop && ahead == 0) begin tracking <= 1'b0; done <= 1'b1; end
      else if (pop)          ahead <= ahead - 1'b1;
    end
  end
  always_comb if (past_valid && tracking) begin
    assert (ahead < count);                       // it is still inside the FIFO
    if (pop && ahead == 0) assert (dout == val);  // it comes out, unchanged, after exactly those in front
  end
`endif
endmodule
