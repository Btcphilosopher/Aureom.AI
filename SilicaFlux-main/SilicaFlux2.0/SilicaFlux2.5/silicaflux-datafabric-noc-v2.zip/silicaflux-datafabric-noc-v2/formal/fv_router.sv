// =============================================================================
//  fv_router : formal properties of the UNMODIFIED noc_router (v2 RTL)
//
//  DUT: the interior node (1,1) of a 3x3 mesh (all five ports present),
//  BUF_DEPTH = 2, single-flit packets, reduced-width flit (fv_pkt_t).
//
//  ENVIRONMENT ASSUMPTIONS (what the rest of the system guarantees)
//    E1  reset asserted in the first cycle only
//    E2  every input holds valid and payload while stalled (ready/valid contract)
//    E3  neighbour ports (N/E/S/W) carry only flits that an upstream router already
//        validated and routed: valid, legal class, destination inside the mesh,
//        and consistent with XY order (a flit arriving from the west is eastbound,
//        i.e. dst_x >= my x; from south it has resolved X and dst_y >= my y; ...)
//    E4  the local port is UNCONSTRAINED apart from E2: the router must validate it
//    E5  output ready signals are arbitrary
//
//  PROPERTIES (all stated on ports and counter taps, none on RTL internals)
//    P_HOLD     output valid and payload stable while the sink stalls
//    P_OVF/UDF  no input-buffer overflow / underflow; occupancy <= BUF_DEPTH
//    P_GNT      at most one grant per output and per input; grant needs a request,
//               a non-empty buffer and an output able to accept
//    P_ROUTE    every flit leaving on port o is one XY routing sends to o (this
//               also proves: no Y->X turns, no 180-degree turns, local ejection
//               only for flits addressed here)
//    P_CONS     flits in the router == accepted - transferred (no loss, no duplication)
//    P_RESET    reset state: buffers empty, outputs idle, inputs ready
//    P_INGRESS  local-port flits that are invalid/illegal/spoofed/out-of-range are
//               dropped and never enter a buffer; all others are accepted
//    P_FAIR     per-output round-robin starvation bound (QOS_ARB_EN = 0):
//               a requester waits at most NP-1 accepting cycles
//    P_QOS      with QOS_ARB_EN = 1 and QOS_STARVE_LIMIT = K, any requester waits at
//               most K + NP accepting cycles
// =============================================================================
module fv_router
  import silicaflux_pkg::*;
  import fv_pkg::*;
#(
  parameter bit          QOS_ARB_EN       = 1'b0,
  parameter int unsigned QOS_STARVE_LIMIT = 0,
  parameter int unsigned FAIR_BOUND       = 4
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic        [4:0]       in_valid,
  input  fv_pkt_t     [4:0]       in_pkt,
  input  logic        [4:0]       out_ready,
  input  logic        [2:0]       sel_o,
  input  logic        [2:0]       sel_i
);
  localparam int unsigned MX = 3, MY = 3, NX = 1, NY = 1, DEPTH = 2, NP = 5;
  localparam int unsigned XW = 2, YW = 2;                          // coordinate field widths for a 3x3 mesh
  localparam int unsigned L = 0, N = 1, E = 2, S = 3, W = 4;

  logic        [4:0]            in_ready, out_valid;
  fv_pkt_t     [4:0]            out_pkt;
  logic        [4:0]            lstall, hol;
  logic                         idle, err_drop, err_drop_head;
  logic        [2:0]            err_cause;
  logic        [4:0]            in_fire, in_head, out_fire, out_head;
  logic        [4:0][4:0]       sa_req, sa_gnt;                      // [out][in]
  logic        [4:0][$clog2(DEPTH+1)-1:0] bcount;
  fv_pkt_t     [4:0]            tap_out_pkt;

  noc_router #(
    .pkt_t(fv_pkt_t), .MESH_X(MX), .MESH_Y(MY), .NODE_X(NX), .NODE_Y(NY), .BUF_DEPTH(DEPTH),
    .FLITS_PER_PKT(1), .QOS_ARB_EN(QOS_ARB_EN), .PROGRESS_WDOG_CYCLES(0),
    .EXPLICIT_FRAMING(1'b0), .QOS_STARVE_LIMIT(QOS_STARVE_LIMIT), .CHECK_CLASS(1'b1), .CHECK_SRC(1'b1)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .local_in_valid_i(in_valid[L]), .local_in_pkt_i(in_pkt[L]), .local_in_ready_o(in_ready[L]),
    .local_out_valid_o(out_valid[L]), .local_out_pkt_o(out_pkt[L]), .local_out_ready_i(out_ready[L]),
    .north_in_valid_i(in_valid[N]), .north_in_pkt_i(in_pkt[N]), .north_in_ready_o(in_ready[N]),
    .north_out_valid_o(out_valid[N]), .north_out_pkt_o(out_pkt[N]), .north_out_ready_i(out_ready[N]),
    .east_in_valid_i(in_valid[E]), .east_in_pkt_i(in_pkt[E]), .east_in_ready_o(in_ready[E]),
    .east_out_valid_o(out_valid[E]), .east_out_pkt_o(out_pkt[E]), .east_out_ready_i(out_ready[E]),
    .south_in_valid_i(in_valid[S]), .south_in_pkt_i(in_pkt[S]), .south_in_ready_o(in_ready[S]),
    .south_out_valid_o(out_valid[S]), .south_out_pkt_o(out_pkt[S]), .south_out_ready_i(out_ready[S]),
    .west_in_valid_i(in_valid[W]), .west_in_pkt_i(in_pkt[W]), .west_in_ready_o(in_ready[W]),
    .west_out_valid_o(out_valid[W]), .west_out_pkt_o(out_pkt[W]), .west_out_ready_i(out_ready[W]),
    .perf_link_stall_o(lstall), .perf_hol_block_o(hol), .idle_o(idle),
    .err_drop_o(err_drop), .err_drop_head_o(err_drop_head), .err_cause_o(err_cause),
    .perf_in_fire_o(in_fire), .perf_in_head_o(in_head), .perf_out_fire_o(out_fire), .perf_out_head_o(out_head),
    .perf_sa_req_o(sa_req), .perf_sa_gnt_o(sa_gnt), .perf_buf_count_o(bcount), .perf_out_pkt_o(tap_out_pkt)
  );

  // ---- time base -------------------------------------------------------------
  logic past_valid = 1'b0;
  always_ff @(posedge clk) past_valid <= 1'b1;
  always_comb if (!past_valid) assume (!rst_n);                    // E1
  always_comb if (past_valid)  assume (rst_n);

  // ---- helpers (independent of the RTL) ----------------------------------------
  function automatic int dx_of(input sf_noc_id_t id); return int'(id[XW-1:0]); endfunction
  function automatic int dy_of(input sf_noc_id_t id); return int'(id[XW+YW-1:XW]); endfunction
  function automatic bit dst_valid(input sf_noc_id_t id);
    return (dx_of(id) < MX) && (dy_of(id) < MY);     // 3x3: all four ID bits are coordinate bits
  endfunction
  // expected output port, plain XY: X first, then Y, then eject
  function automatic int xy_port(input sf_noc_id_t id);
    if      (dx_of(id) > NX) return E;
    else if (dx_of(id) < NX) return W;
    else if (dy_of(id) > NY) return N;
    else if (dy_of(id) < NY) return S;
    else                     return L;
  endfunction
  localparam sf_noc_id_t MY_ID = sf_noc_id_t'((NY << XW) | NX);

  // ---- E2: hold under stall; E3/E4 input legality -----------------------------
  logic    [4:0] pstall = '0;
  fv_pkt_t [4:0] ppkt;
  always_ff @(posedge clk) begin
    pstall <= in_valid & ~in_ready;
    ppkt   <= in_pkt;
  end
  for (genvar p = 0; p < NP; p++) begin : g_env
    always_comb if (past_valid && pstall[p]) assume (in_valid[p] && in_pkt[p] == ppkt[p]);   // E2
    if (p != L) begin : g_nb                                       // E3
      always_comb if (in_valid[p]) begin
        assume (in_pkt[p].valid && sf_noc_class_legal(in_pkt[p].pclass));
        assume (dst_valid(in_pkt[p].dst_id));
        if (p == W) assume (dx_of(in_pkt[p].dst_id) >= NX);
        if (p == E) assume (dx_of(in_pkt[p].dst_id) <= NX);
        if (p == S) assume (dx_of(in_pkt[p].dst_id) == NX && dy_of(in_pkt[p].dst_id) >= NY);
        if (p == N) assume (dx_of(in_pkt[p].dst_id) == NX && dy_of(in_pkt[p].dst_id) <= NY);
        assume (in_pkt[p].sop && in_pkt[p].eop);                   // single-flit packets
      end
    end
  end
  always_comb if (in_valid[L]) assume (in_pkt[L].sop && in_pkt[L].eop);

`ifdef G_RESET
  // ---- P_RESET ------------------------------------------------------------------
  always_comb if (!rst_n) begin
    assert (out_valid == '0);
    assert (bcount[L] == 0 && bcount[N] == 0 && bcount[E] == 0 && bcount[S] == 0 && bcount[W] == 0);
    assert (in_ready == 5'b11111);
    assert (idle);
  end
`endif

`ifdef G_HOLD
  // ---- P_HOLD: output stable under stall ------------------------------------------
  logic    [4:0] ostall = '0;
  fv_pkt_t [4:0] opkt_q;
  always_ff @(posedge clk) begin ostall <= out_valid & ~out_ready; opkt_q <= out_pkt; end
  for (genvar o = 0; o < NP; o++) begin : g_hold
    always_comb if (past_valid && ostall[o]) assert (out_valid[o] && out_pkt[o] == opkt_q[o]);
  end
`endif

`ifdef G_GNT
  // ---- P_OVF / P_UDF / P_GNT -----------------------------------------------------------
  always_comb if (past_valid) begin
    for (int i = 0; i < NP; i++) begin
      assert (int'(bcount[i]) <= DEPTH);
      if (in_fire[i]) assert (int'(bcount[i]) < DEPTH);                       // no overflow
      assert (in_ready[i] == (int'(bcount[i]) < DEPTH));                       // registered not-full
    end
    for (int o = 0; o < NP; o++) begin
      assert ($onehot0(sa_gnt[o]));                                            // one grant per output
      assert ((sa_gnt[o] & ~sa_req[o]) == '0);                                 // grant needs request
      if (sa_gnt[o] != '0) assert (!out_valid[o] || out_ready[o]);             // output can accept
      for (int i = 0; i < NP; i++) if (sa_gnt[o][i]) assert (bcount[i] != 0);  // no underflow
    end
    for (int i = 0; i < NP; i++) begin                                         // one output per input
      assert ($onehot0({sa_gnt[4][i], sa_gnt[3][i], sa_gnt[2][i], sa_gnt[1][i], sa_gnt[0][i]}));
    end
  end
`endif

`ifdef G_ROUTE
  // ---- P_ROUTE ---------------------------------------------------------------------------
  always_comb if (past_valid) begin
    for (int o = 0; o < NP; o++)
      if (out_fire[o]) begin
        assert (dst_valid(tap_out_pkt[o].dst_id));
        assert (xy_port(tap_out_pkt[o].dst_id) == o);
      end
  end
`endif

`ifdef G_CONS
  // ---- P_CONS ------------------------------------------------------------------------------
  logic [5:0] shadow = '0;
  always_ff @(posedge clk) if (past_valid) shadow <= shadow + 6'($countones(in_fire)) - 6'($countones(out_fire));
  always_comb if (past_valid)
    assert (shadow == 6'(int'(bcount[0]) + int'(bcount[1]) + int'(bcount[2]) + int'(bcount[3]) + int'(bcount[4])
                         + $countones(out_valid)));
`endif

`ifdef G_INGRESS
  // ---- P_INGRESS ---------------------------------------------------------------------------
  logic bad_dst, bad_cls, bad_src, bad;
  assign bad_dst = !dst_valid(in_pkt[L].dst_id);
  assign bad_cls = !in_pkt[L].valid || !sf_noc_class_legal(in_pkt[L].pclass);
  assign bad_src = (in_pkt[L].src_id != MY_ID);
  assign bad     = bad_dst || bad_cls || bad_src;
  always_comb if (past_valid) begin
    if (in_valid[L] && in_ready[L] && bad) begin
      assert (err_drop && err_drop_head && !in_fire[L]);
      assert (err_cause == {bad_src, bad_cls, bad_dst});
    end
    if (in_valid[L] && in_ready[L] && !bad) assert (in_fire[L] && !err_drop);
    if (!(in_valid[L] && in_ready[L])) assert (!err_drop);
  end
`endif

  // ---- P_FAIR / P_QOS: bounded wait of a requester while the output accepts ----------
  // One (output, input) pair, chosen by the solver and held constant, is watched; the
  // proof therefore covers every pair. A 3-bit counter counts consecutive cycles in which
  // the pair requests, is not granted, and the output could have accepted a flit.
`ifdef FAIR
  logic [2:0] so_q = '0, si_q = '0;
  always_ff @(posedge clk) begin so_q <= sel_o; si_q <= sel_i; end
  always_comb if (past_valid) assume (sel_o == so_q && sel_i == si_q);
  always_comb assume (sel_o < 5 && sel_i < 5);

  logic [3:0] wait_c = '0;                       // 4 bits: must be able to exceed every bound under test
  logic       req_s, gnt_s, acc_s;
  assign req_s = sa_req[sel_o][sel_i];
  assign gnt_s = sa_gnt[sel_o][sel_i];
  assign acc_s = !out_valid[sel_o] || out_ready[sel_o];
  always_ff @(posedge clk) begin
    if (!rst_n || !req_s || gnt_s)  wait_c <= '0;
    else if (acc_s && wait_c != 4'd15) wait_c <= wait_c + 4'd1;
  end
  always_comb if (past_valid) assert (wait_c <= 4'(FAIR_BOUND));
`endif
endmodule
