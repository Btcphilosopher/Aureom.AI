// Reduced-width packet for formal runs. noc_router/noc_interconnect take the flit
// type as a parameter, so the UNMODIFIED RTL is verified; only the payload is
// narrowed (the fabric never inspects it). Every field the fabric reads is kept.
package fv_pkg;
  import silicaflux_pkg::*;
  typedef struct packed {
    logic          valid;
    logic          sop;
    logic          eop;
    sf_noc_class_e pclass;
    sf_noc_qos_t   qos;
    sf_noc_id_t    dst_id;
    sf_noc_id_t    src_id;
    logic [3:0]    txn_id;
    logic [3:0]    data;
  } fv_pkt_t;
endpackage
