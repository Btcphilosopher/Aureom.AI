// =============================================================================
//  fv_mesh : formal check of the 2x2 mesh (UNMODIFIED noc_interconnect, reduced flit)
//
//  One packet with a symbolic source, destination, transaction id and payload is
//  injected on an otherwise idle network with the sinks always ready. Proves, for ALL
//  16 (source, destination) pairs and ALL payloads:
//     M_ROUTE    it is delivered ONLY at its destination tile, never elsewhere
//     M_INTEGRITY every field arrives bit-exact
//     M_ONCE     it is delivered exactly once (no duplication), and only after injection
//     M_LATENCY  it is delivered at exactly 2*(hops+1) cycles after injection
//  (src, dst, txn, data are module inputs pinned by assumptions: SLANG ignores anyconst)
// =============================================================================
module fv_mesh
  import silicaflux_pkg::*;
  import fv_pkg::*;
(
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] src,
  input  logic [1:0] dst,
  input  logic [3:0] txn,
  input  logic [3:0] data
);
  localparam int NT = 4;
  logic        [NT-1:0] inj_valid, inj_ready, ej_valid, ej_ready, err_drop, err_head;
  fv_pkt_t     [NT-1:0] inj_pkt, ej_pkt;
  logic        [NT-1:0][4:0]        stall, hol, in_fire, in_head, out_fire, out_head;
  logic        [NT-1:0][4:0][4:0]   sa_req, sa_gnt;
  logic        [NT-1:0][4:0][1:0]   bcount;
  fv_pkt_t     [NT-1:0][4:0]        tap_pkt;
  logic        [NT-1:0][2:0]        cause;
  logic                              idle;

  noc_interconnect #(.pkt_t(fv_pkt_t), .MESH_X(2), .MESH_Y(2), .BUF_DEPTH(2), .FLITS_PER_PKT(1),
                     .QOS_ARB_EN(1'b0), .PROGRESS_WDOG_CYCLES(0), .EXPLICIT_FRAMING(1'b0),
                     .QOS_STARVE_LIMIT(0), .CHECK_CLASS(1'b1), .CHECK_SRC(1'b1)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .tile_inj_valid_i(inj_valid), .tile_inj_pkt_i(inj_pkt), .tile_inj_ready_o(inj_ready),
    .tile_ej_valid_o(ej_valid), .tile_ej_pkt_o(ej_pkt), .tile_ej_ready_i(ej_ready),
    .perf_link_stall_o(stall), .perf_hol_block_o(hol), .noc_idle_o(idle),
    .err_drop_o(err_drop), .err_drop_head_o(err_head), .err_cause_o(cause),
    .perf_in_fire_o(in_fire), .perf_in_head_o(in_head), .perf_out_fire_o(out_fire), .perf_out_head_o(out_head),
    .perf_sa_req_o(sa_req), .perf_sa_gnt_o(sa_gnt), .perf_buf_count_o(bcount), .perf_out_pkt_o(tap_pkt));

  // ---- time base, pinned symbols -----------------------------------------------
  logic past_valid = 1'b0;
  always_ff @(posedge clk) past_valid <= 1'b1;
  always_comb if (!past_valid) assume (!rst_n);
  always_comb if (past_valid)  assume (rst_n);

  logic [1:0] src_q = '0, dst_q = '0;  logic [3:0] txn_q = '0, data_q = '0;
  always_ff @(posedge clk) begin src_q <= src; dst_q <= dst; txn_q <= txn; data_q <= data; end
  always_comb if (past_valid) assume (src == src_q && dst == dst_q && txn == txn_q && data == data_q);

  // ---- stimulus: ONE packet, injected in cycle 2; sinks always ready ------------------
  logic [3:0] cyc = '0;
  always_ff @(posedge clk) if (past_valid && cyc != 4'd15) cyc <= cyc + 1'b1;
  fv_pkt_t pkt;
  always_comb begin
    pkt         = '0;
    pkt.valid   = 1'b1; pkt.sop = 1'b1; pkt.eop = 1'b1;
    pkt.pclass  = SF_NOC_RD_REQ;
    pkt.dst_id  = sf_noc_id(int'(dst[0]), int'(dst[1]), 2);
    pkt.src_id  = sf_noc_id(int'(src[0]), int'(src[1]), 2);
    pkt.txn_id  = txn;
    pkt.data    = data;
  end
  always_comb begin
    inj_valid = '0; inj_pkt = '0;
    if (cyc == 4'd2) begin inj_valid[src] = 1'b1; inj_pkt[src] = pkt; end
  end
  assign ej_ready = '1;

  // ---- reference quantities --------------------------------------------------------------
  function automatic int hops_of(input logic [1:0] a, input logic [1:0] b);
    int ax, ay, bx, by;
    ax = int'(a[0]); ay = int'(a[1]); bx = int'(b[0]); by = int'(b[1]);
    return ((ax > bx) ? ax - bx : bx - ax) + ((ay > by) ? ay - by : by - ay);
  endfunction
  localparam int INJ_CYC = 2;

  logic [4:0] delivered = '0;                    // number of ejections seen (saturating)
  always_ff @(posedge clk) if (past_valid) delivered <= delivered + 5'($countones(ej_valid & ej_ready));

  always_comb if (past_valid) begin
    // M_ROUTE / M_INTEGRITY / M_ONCE
    for (int t = 0; t < NT; t++) if (ej_valid[t]) begin
      assert (t == int'(dst));                                       // only at the destination
      assert (ej_pkt[t] == pkt);                                     // bit exact
      assert (cyc > 4'(INJ_CYC));                                    // only after injection
      assert (delivered == 0);                                       // exactly once
    end
    // M_LATENCY: ejection exactly 2*(hops+1) cycles after the injection cycle
    if (cyc == 4'(INJ_CYC + 2 * (hops_of(src, dst) + 1))) assert (ej_valid[dst]);
    if (ej_valid[dst]) assert (cyc == 4'(INJ_CYC + 2 * (hops_of(src, dst) + 1)));
    assert (err_drop == '0);                                         // a legal packet is never rejected
  end
endmodule
