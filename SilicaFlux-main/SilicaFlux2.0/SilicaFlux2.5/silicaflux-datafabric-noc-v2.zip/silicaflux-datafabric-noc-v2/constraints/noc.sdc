# =============================================================================
# SilicaFlux DataFabric NoC v2 - SDC skeleton for sf_noc_fabric (one clock domain)
#
# NO TARGET FREQUENCY IS ASSUMED. Static timing analysis was NOT run for this design (no
# liberty library exists in the repository or in the build sandbox). Set NOC_CLK_PERIOD_NS
# from the SoC budget before use; the file refuses to proceed otherwise.
# =============================================================================
if {![info exists ::env(NOC_CLK_PERIOD_NS)]} {
  error "set NOC_CLK_PERIOD_NS (ns) from the SoC clock budget - none is assumed by this project"
}
set period  $::env(NOC_CLK_PERIOD_NS)

create_clock -name noc_clk -period $period [get_ports clk_i]
set_clock_uncertainty -setup [expr {0.05 * $period}] [get_clocks noc_clk]
set_clock_uncertainty -hold  [expr {0.02 * $period}] [get_clocks noc_clk]

# Reset: asserted asynchronously, released synchronously by the integrator's reset synchroniser
# (the NoC contains no synchroniser; see docs/PHYSICAL.md). The deassertion must meet recovery/removal.
set_false_path -from [get_ports rst_ni] -to [all_registers -async_pins]

# Tile-side ports: registered at the tile or at the NI (every sf_noc_* output toward the fabric is a flop output),
# so a fraction of the period is the only budget the fabric needs. Placeholders - replace with the SoC's numbers.
set tile_in_frac  0.5      ;# tile -> fabric input delay as a fraction of the period (PLACEHOLDER)
set tile_out_frac 0.5      ;# fabric -> tile output delay as a fraction of the period (PLACEHOLDER)
set_input_delay  -clock noc_clk [expr {$tile_in_frac  * $period}] [get_ports {req_in_* rsp_in_* req_out_ready_i rsp_out_ready_i ctrl_* rd_*}]
set_output_delay -clock noc_clk [expr {$tile_out_frac * $period}] [get_ports {req_out_* rsp_out_* req_in_ready_o rsp_in_ready_o rd_data_o noc_idle_o err_drop_o ovf_o}]

# Counter read port is a debug/CSR path: combinational address -> data. Give it a multi-cycle budget if it is read through a
# slower CSR bus (integrator's decision); left single-cycle here.

# --- structural facts the constraints rely on (proved in reports/comb_paths.md) -------------------
#  * every router-to-router signal (valid, payload, ready) is driven directly by a flop: the longest inter-router
#    path is one wire between two flops; no combinational path crosses a router.
#  * the longest combinational path is INSIDE a router: switch allocation (request AND-OR, round-robin pick),
#    grant -> input-buffer pop/count, and the one-hot crossbar into the egress register.
