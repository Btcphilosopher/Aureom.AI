# Original router versus v2: cycle-for-cycle comparison

Same testbench, same seeds, legal traffic, QoS off, single-flit. For every test that BOTH routers pass, the injected/ejected
counts and the global cycle count at the end of the test are compared. (The original stops at the first invalid-destination
packet because its own assertion aborts the run; tests after that point are not comparable.)

| seed | test | cycles original | cycles v2 | packets (inj) orig | v2 | result |
|---|---|---|---|---|---|---|
| 1 | reset_state | 16 | 16 | 0 | 0 | identical |
| 1 | all_pairs_zero_load | 181 | 181 | 16 | 16 | identical |
| 1 | local_delivery | 243 | 243 | 200 | 200 | identical |
| 1 | one_hop | 480 | 480 | 160 | 160 | identical |
| 1 | diagonal | 536 | 536 | 160 | 160 | identical |
| 1 | simultaneous_permutations | 1174 | 1174 | 2400 | 2400 | identical |
| 1 | all_pairs_simultaneous | 3005 | 3005 | 6000 | 6000 | identical |
| 1 | bidirectional | 3830 | 3830 | 3200 | 3200 | identical |
| 1 | all_to_one_hotspot | 10359 | 10359 | 2400 | 2400 | identical |
| 1 | random_backpressure | 18795 | 18795 | 10000 | 10000 | identical |
| 1 | periodic_backpressure | 25647 | 25647 | 3200 | 3200 | identical |
| 1 | queue_saturation | 26951 | 26951 | 2400 | 2400 | identical |
| 1 | reset_during_traffic | 27635 | 27635 | 1200 | 1200 | identical |
| 1 | repeated_reset_cycles | 28191 | 28191 | 1784 | 1784 | identical |
| 1 | qos_class_starvation | 30229 | 30229 | 2024 | 2024 | identical |
| 2 | reset_state | 16 | 16 | 0 | 0 | identical |
| 2 | all_pairs_zero_load | 181 | 181 | 16 | 16 | identical |
| 2 | local_delivery | 243 | 243 | 200 | 200 | identical |
| 2 | one_hop | 480 | 480 | 160 | 160 | identical |
| 2 | diagonal | 536 | 536 | 160 | 160 | identical |
| 2 | simultaneous_permutations | 1174 | 1174 | 2400 | 2400 | identical |
| 2 | all_pairs_simultaneous | 2981 | 2981 | 6000 | 6000 | identical |
| 2 | bidirectional | 3806 | 3806 | 3200 | 3200 | identical |
| 2 | all_to_one_hotspot | 10254 | 10254 | 2400 | 2400 | identical |
| 2 | random_backpressure | 18180 | 18180 | 10000 | 10000 | identical |
| 2 | periodic_backpressure | 25386 | 25386 | 3200 | 3200 | identical |
| 2 | queue_saturation | 26699 | 26699 | 2400 | 2400 | identical |
| 2 | reset_during_traffic | 27390 | 27390 | 1200 | 1200 | identical |
| 2 | repeated_reset_cycles | 27941 | 27941 | 1775 | 1775 | identical |
| 2 | qos_class_starvation | 29979 | 29979 | 2024 | 2024 | identical |
| 3 | reset_state | 16 | 16 | 0 | 0 | identical |
| 3 | all_pairs_zero_load | 181 | 181 | 16 | 16 | identical |
| 3 | local_delivery | 243 | 243 | 200 | 200 | identical |
| 3 | one_hop | 480 | 480 | 160 | 160 | identical |
| 3 | diagonal | 536 | 536 | 160 | 160 | identical |
| 3 | simultaneous_permutations | 1174 | 1174 | 2400 | 2400 | identical |
| 3 | all_pairs_simultaneous | 2998 | 2998 | 6000 | 6000 | identical |
| 3 | bidirectional | 3823 | 3823 | 3200 | 3200 | identical |
| 3 | all_to_one_hotspot | 10217 | 10217 | 2400 | 2400 | identical |
| 3 | random_backpressure | 18444 | 18444 | 10000 | 10000 | identical |
| 3 | periodic_backpressure | 25665 | 25665 | 3200 | 3200 | identical |
| 3 | queue_saturation | 26976 | 26976 | 2400 | 2400 | identical |
| 3 | reset_during_traffic | 27669 | 27669 | 1200 | 1200 | identical |
| 3 | repeated_reset_cycles | 28216 | 28216 | 1759 | 1759 | identical |
| 3 | qos_class_starvation | 30254 | 30254 | 2024 | 2024 | identical |

**All compared tests identical.** (45 comparisons)
