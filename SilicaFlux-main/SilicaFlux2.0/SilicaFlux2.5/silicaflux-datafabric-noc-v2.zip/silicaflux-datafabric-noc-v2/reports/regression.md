# Functional regression

Seeds: [1, 2, 3]. Each run executes the full directed + random suite in `tb/tb_noc.sv` with the DUT's own
assertions armed. `expected-fail` lists tests that the *unmodified original* router is known to fail
(or strict-priority QoS fails by design); for those rows the regression requires the failure to reproduce.

| configuration | seeds | min tests passed | failing tests | expected-fail | verdict |
|---|---|---|---|---|---|
| mesh2x2_d2 | 3 | 19/19 | - | - | OK |
| mesh2x2_d3 | 3 | 19/19 | - | - | OK |
| mesh2x2_d4 | 3 | 19/19 | - | - | OK |
| mesh2x2_d8 | 3 | 19/19 | - | - | OK |
| mesh3x3_d4 | 3 | 19/19 | - | - | OK |
| mesh4x4_d4 | 3 | 19/19 | - | - | OK |
| mesh3x2_d4 | 3 | 19/19 | - | - | OK |
| mesh2x3_d4 | 3 | 19/19 | - | - | OK |
| mesh4x2_d3 | 3 | 19/19 | - | - | OK |
| mesh2x2_flits2 | 3 | 20/20 | - | - | OK |
| mesh2x2_flits4_d2 | 3 | 20/20 | - | - | OK |
| mesh2x2_explicit | 3 | 20/20 | - | - | OK |
| mesh3x3_explicit | 3 | 20/20 | - | - | OK |
| mesh2x2_qos_guard7 | 3 | 19/19 | - | - | OK |
| mesh2x2_qos_guard3 | 3 | 19/19 | - | - | OK |
| mesh2x2_qos_strict | 3 | 18/19 | qos_class_starvation | qos_class_starvation | OK |
| xbar4_d4 | 3 | 19/19 | - | - | OK |
| xbar9_d4 | 3 | 19/19 | - | - | OK |
| xbar16_d4 | 3 | 19/19 | - | - | OK |
| ORIG_mesh2x2 | 3 | 15/15 | - | - + abort:a_inj_reachable | OK (aborts on a_inj_reachable) |
| ORIG_mesh2x2_qos | 3 | 14/15 | qos_class_starvation | qos_class_starvation + abort:a_inj_reachable | OK (aborts on a_inj_reachable) |
| ORIG_mesh3x3 | 3 | 15/15 | - | - + abort:a_inj_reachable|a_rc_turn_legal | OK (aborts on a_inj_reachable, a_rc_turn_legal) |
| ORIG_mesh2x2_flits2 | 3 | 16/16 | - | - + abort:a_inj_reachable | OK (aborts on a_inj_reachable) |
| ORIG_mesh2x2_flits4 | 3 | 16/16 | - | - + abort:a_inj_reachable | OK (aborts on a_inj_reachable) |
| ORIG_mesh3x3_hwview | 3 | 16/19 | invalid_destination, reserved_class_and_invalid_pkt, spoofed_source_id | invalid_destination, reserved_class_and_invalid_pkt, spoofed_source_id | OK |
| ORIG_mesh2x2_hwview | 3 | 16/19 | invalid_destination, reserved_class_and_invalid_pkt, spoofed_source_id | invalid_destination, reserved_class_and_invalid_pkt, spoofed_source_id | OK |

**Overall: ALL AS EXPECTED**
