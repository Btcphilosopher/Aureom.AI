# Formal verification results

Tool chain: SymbiYosys (YoWASP), SLANG frontend, smtbmc + z3. The RTL under test is the unmodified
`rtl/noc_interconnect.sv` / `rtl/sf_noc_fifo.sv`, instantiated with a reduced-width flit (`fv_pkt_t`).

| task | result | strength | depth | time (s) | establishes |
|---|---|---|---|---|---|
| fifo:invariants | **PASS** | unbounded (k-induction) | 6 | 2 | FIFO: count<=depth, full/empty flags exact, occupancy == pushes-pops |
| fifo:order | **PASS** | bounded (BMC depth 14) | 14 | 24 | FIFO: marked element leaves in order and unchanged |
| router:reset_prove | **PASS** | unbounded (k-induction) | 4 | 2 | router: reset state (buffers empty, outputs idle, ready high) |
| router:hold_prove | **PASS** | unbounded (k-induction) | 4 | 2 | router: output valid+payload stable under stall |
| router:gnt_bmc | **PASS** | bounded (BMC depth 8) | 8 | 14 | router: one grant/output & /input, grant needs request+space, no overflow/underflow |
| router:route_bmc | **PASS** | bounded (BMC depth 8) | 8 | 141 | router: every flit leaves on the port XY routing selects |
| router:cons_bmc | **PASS** | bounded (BMC depth 5) | 5 | 415 | router: occupancy == accepted - transferred (no loss, no duplication) |
| router:ingress_bmc | **PASS** | bounded (BMC depth 5) | 5 | 2 | router: invalid/illegal/spoofed local flits dropped, others accepted, cause exact |
| router:fair | **PASS** | bounded (BMC depth 10) | 10 | 6 | router: round-robin wait <= NP-1 = 4 accepting cycles (any output, any input) |
| router:qos | **PASS** | bounded (BMC depth 14) | 14 | 216 | router: QoS guard K=1: wait <= (NP-1)(K+1)+K = 9 |
| mesh:mesh | **PASS** | bounded (BMC depth 11) | 11 | 4 | 2x2 mesh: any src/dst/payload delivered only at dst, exactly once, exact, 2*(hops+1) cycles |
| router:gnt_prove | **UNKNOWN** | k-induction inconclusive (needs strengthening; base case holds to depth 4); the bounded result is the matching _bmc row | 4 | 4 | router: gnt by k-induction (may need strengthening) |
| router:route_prove | **UNKNOWN** | k-induction inconclusive (needs strengthening; base case holds to depth 4); the bounded result is the matching _bmc row | 4 | 3 | router: route by k-induction (may need strengthening) |
| router:cons_prove | **UNKNOWN** | k-induction inconclusive (needs strengthening; base case holds to depth 4); the bounded result is the matching _bmc row | 4 | 8 | router: cons by k-induction (may need strengthening) |
| router:ingress_prove | **UNKNOWN** | k-induction inconclusive (needs strengthening; base case holds to depth 4); the bounded result is the matching _bmc row | 4 | 3 | router: ingress by k-induction (may need strengthening) |
