# Combinational dependency of outputs on inputs (gate-level, flops cut the paths)

Netlist: `noc_router` node (1,1) of a 3x3 mesh (all five ports present), synthesized to NAND2/NOT/DFF.

## Link-facing outputs (ready / valid / payload that other routers or tiles see)

| output | combinationally depends on inputs |
|---|---|
| east_in_ready_o | **none** (driven only by flops) |
| east_out_pkt_o | **none** (driven only by flops) |
| east_out_valid_o | **none** (driven only by flops) |
| local_in_ready_o | **none** (driven only by flops) |
| local_out_pkt_o | **none** (driven only by flops) |
| local_out_valid_o | **none** (driven only by flops) |
| north_in_ready_o | **none** (driven only by flops) |
| north_out_pkt_o | **none** (driven only by flops) |
| north_out_valid_o | **none** (driven only by flops) |
| south_in_ready_o | **none** (driven only by flops) |
| south_out_pkt_o | **none** (driven only by flops) |
| south_out_valid_o | **none** (driven only by flops) |
| west_in_ready_o | **none** (driven only by flops) |
| west_out_pkt_o | **none** (driven only by flops) |
| west_out_valid_o | **none** (driven only by flops) |

## Telemetry / error outputs (not connected to any other router)

| output | combinationally depends on |
|---|---|
| err_cause_o | local_in_pkt_i |
| err_drop_head_o | local_in_pkt_i, local_in_valid_i |
| err_drop_o | local_in_pkt_i, local_in_valid_i |
| idle_o | none |
| perf_buf_count_o | none |
| perf_hol_block_o | east_out_ready_i, local_out_ready_i, north_out_ready_i, south_out_ready_i, west_out_ready_i |
| perf_in_fire_o | east_in_valid_i, local_in_pkt_i, local_in_valid_i, north_in_valid_i, south_in_valid_i, west_in_valid_i |
| perf_in_head_o | east_in_valid_i, local_in_pkt_i, local_in_valid_i, north_in_valid_i, south_in_valid_i, west_in_valid_i |
| perf_link_stall_o | east_out_ready_i, local_out_ready_i, north_out_ready_i, south_out_ready_i, west_out_ready_i |
| perf_out_fire_o | east_out_ready_i, local_out_ready_i, north_out_ready_i, south_out_ready_i, west_out_ready_i |
| perf_out_head_o | east_out_ready_i, local_out_ready_i, north_out_ready_i, south_out_ready_i, west_out_ready_i |
| perf_out_pkt_o | none |
| perf_sa_gnt_o | east_out_ready_i, local_out_ready_i, north_out_ready_i, south_out_ready_i, west_out_ready_i |
| perf_sa_req_o | none |

**Result: PASS - no link-facing output depends combinationally on any input; every inter-router signal is flop-driven, so no combinational loop or ready-chain can form across routers in any mesh built from this router (the interconnect adds only wires; `yosys check -assert` also reports 0 problems on the flattened 2x2 mesh).**
