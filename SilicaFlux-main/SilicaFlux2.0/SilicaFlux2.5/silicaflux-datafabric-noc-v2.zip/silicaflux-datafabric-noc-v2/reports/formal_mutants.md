# Formal non-vacuity (mutation) check

| mutant | property task | verdict | what was broken | failing assertion |
|---|---|---|---|---|
| rr_fixed_priority | fair | **CAUGHT** | round-robin pointer never rotates: lowest-numbered input always wins | fv_router.sv:227.31-227.65 |
| route_east_west_swapped | route_bmc | **CAUGHT** | XY decode sends eastbound traffic west and vice versa | fv_router.sv:177.9-177.54 |
| egress_drops_under_stall | hold_bmc | **CAUGHT** | egress valid clears even when the sink has not accepted the flit | fv_router.sv:147.46-147.95 |
| buffer_never_full | gnt_bmc | **CAUGHT** | full flag never asserts: input buffer can overflow | fv_router.sv:157.7-157.57 |
| ingress_validation_off | ingress_bmc | **CAUGHT** | rejected local-port flits are stored and forwarded | fv_router.sv:200.7-200.57 |
| qos_guard_removed | qos | **CAUGHT** | QoS starvation guard disabled: strict priority | fv_router.sv:227.31-227.65 |
| qos_shared_pointer | qos | **CAUGHT** | ONE round-robin pointer shared by both classes (my first QoS guard): low requester can starve | fv_router.sv:227.31-227.65 |
| mesh_route_swapped | mesh | **CAUGHT** | mesh-level: XY decode swapped in every router (misdelivery for any pair with an X hop) | fv_mesh.sv:94.59-94.82 |
| arb_ignores_backpressure | gnt_bmc | **CAUGHT** | switch allocator grants into an occupied, stalled egress register | fv_router.sv:162.28-162.67 |
