# System-level regression (real memory_controller behind the NoC)

Configurations: `sep_*` = separate request/response networks (supported), `shared_*` = one shared network.
`*_stress`: BUFD=2, REQ_Q=RSP_Q=CTX_Q=2, 32 outstanding scalar + 32 vector per master, sustained fixed-target traffic
plus 40 DMA bursts per tile. The shared-network stress runs are REQUIRED to deadlock (that is the evidence);
the separate-network runs of the same workload are required to complete.
`shared_default` (default sizes) and `shared_big` (64-deep everything) run the FUNCTIONAL suite on one shared network as a study:
single-flit memory traffic must still work, tests with DMA bursts may deadlock at default sizes, and with 64-deep buffers only the
spoofed-response-class corner test may fail. See docs/DEADLOCK.md.

| configuration | workload | outcome | detail | verdict |
|---|---|---|---|---|
| sep_default | functional seed 1 | 10/10 tests | - | OK |
| sep_default | functional seed 2 | 10/10 tests | - | OK |
| sep_default | functional seed 3 | 10/10 tests | - | OK |
| sep_tight | functional seed 1 | 10/10 tests | - | OK |
| sep_tight | functional seed 2 | 10/10 tests | - | OK |
| sep_tight | functional seed 3 | 10/10 tests | - | OK |
| shared_default | functional seed 1 | 5/10 tests | fails: concurrent_random_backpressure, control_regs_and_corner_packets, dma_burst_rw_strobes, reset_during_memory_traffic, smoke_all_ports_all_targets | OK (study) |
| shared_big | functional seed 1 | 9/10 tests | fails: control_regs_and_corner_packets | OK (study) |
| shared_default | functional seed 2 | 4/10 tests | fails: concurrent_random_backpressure, control_regs_and_corner_packets, counters_match_traffic, dma_burst_rw_strobes, reset_during_memory_traffic, smoke_all_ports_all_targets | OK (study) |
| shared_big | functional seed 2 | 9/10 tests | fails: control_regs_and_corner_packets | OK (study) |
| shared_default | functional seed 3 | 4/10 tests | fails: concurrent_random_backpressure, control_regs_and_corner_packets, counters_match_traffic, dma_burst_rw_strobes, reset_during_memory_traffic, smoke_all_ports_all_targets | OK (study) |
| shared_big | functional seed 3 | 9/10 tests | fails: control_regs_and_corner_packets | OK (study) |
| shared_stress | rotate seed 1 | DEADLOCK | 57 outstanding | OK |
| sep_stress | rotate seed 1 | completed | 4960 txns in 1810 cycles | OK |
| shared_stress | rotate seed 2 | DEADLOCK | 53 outstanding | OK |
| sep_stress | rotate seed 2 | completed | 4960 txns in 1793 cycles | OK |
| shared_stress | rotate seed 3 | DEADLOCK | 59 outstanding | OK |
| sep_stress | rotate seed 3 | completed | 4960 txns in 1831 cycles | OK |
| shared_stress | diagonal seed 1 | DEADLOCK | 65 outstanding | OK |
| sep_stress | diagonal seed 1 | completed | 4960 txns in 1803 cycles | OK |
| shared_stress | diagonal seed 2 | DEADLOCK | 67 outstanding | OK |
| sep_stress | diagonal seed 2 | completed | 4960 txns in 1862 cycles | OK |
| shared_stress | diagonal seed 3 | DEADLOCK | 60 outstanding | OK |
| sep_stress | diagonal seed 3 | completed | 4960 txns in 1907 cycles | OK |
| shared_stress | pairs seed 1 | DEADLOCK | 52 outstanding | OK |
| sep_stress | pairs seed 1 | completed | 4960 txns in 1836 cycles | OK |
| shared_stress | pairs seed 2 | DEADLOCK | 56 outstanding | OK |
| sep_stress | pairs seed 2 | completed | 4960 txns in 1824 cycles | OK |
| shared_stress | pairs seed 3 | DEADLOCK | 56 outstanding | OK |
| sep_stress | pairs seed 3 | completed | 4960 txns in 1831 cycles | OK |

**Overall: ALL AS EXPECTED**
