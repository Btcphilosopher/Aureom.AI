# Highest-fanout nets

Flattened gate netlist of the interior router (3x3 mesh node (1,1), BUF_DEPTH=4). Fanout = number of gate/port pins driven.

| net | fanout |
|---|---|
| `clk_i` | 5302 |
| `g_input_buffer[0].g_port.rd_ptr_q[0]` | 426 |
| `g_input_buffer[2].g_port.rd_ptr_q[0]` | 426 |
| `g_input_buffer[4].g_port.rd_ptr_q[0]` | 424 |
| `$240y[0]` | 422 |
| `g_input_buffer[1].g_port.rd_ptr_q[0]` | 422 |
| `$322y[0]` | 422 |
| `g_input_buffer[3].g_port.rd_ptr_q[0]` | 422 |
| `$404y[0]` | 420 |
| `$281y[0]` | 418 |
| `$363y[0]` | 418 |
| `g_switch_alloc[0].g_port.arb_advance` | 215 |
| `g_switch_alloc[1].g_port.arb_advance` | 214 |
| `g_switch_alloc[3].g_port.arb_advance` | 214 |
| `g_switch_alloc[2].g_port.arb_advance` | 212 |
| `g_switch_alloc[4].g_port.arb_advance` | 212 |
| `$abc$18453$new_n1064` | 212 |
| `$abc$18458$new_n1064` | 212 |
