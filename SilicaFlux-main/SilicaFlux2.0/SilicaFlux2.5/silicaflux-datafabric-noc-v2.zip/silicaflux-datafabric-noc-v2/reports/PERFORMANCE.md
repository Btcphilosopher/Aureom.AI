# DataFabric NoC v2 - performance laboratory

All values are measured in RTL simulation (Verilator) of `tb/tb_noc.sv` in open-loop mode: Bernoulli arrivals into
source queues, 3000-cycle warm-up, then a fixed 30000-cycle measurement window, 3 seeds [1, 2, 3]. Cycles, not seconds: **no clock frequency is assumed or claimed.**

Latency terms: *network latency* = injection accepted -> ejected (what the fabric adds); *total latency* = packet
arrival at the source queue -> ejected (adds source queueing, +1 cycle of generator pipeline even at zero load).
Throughput = delivered flits per tile per cycle inside the window. One flit/cycle/tile is the injection and ejection
port limit. Packet = 1 flit; flit = 207 bits = 26 bytes (default DATA_W = 128).

## 1. Zero-load latency (measured per source/destination pair)

| fabric | pairs | latency (cycles) | analytic | all pairs match |
|---|---|---|---|---|
| mesh2x2_d4 | 16 | 0 hop(s): 2; 1 hop(s): 4; 2 hop(s): 6 | 2 x (hops + 1) | yes |
| xbar2x2_d4 | 16 | 0 hop(s): 2; 1 hop(s): 2; 2 hop(s): 2 | 2 (any pair) | yes |
| mesh3x3_d4 | 81 | 0 hop(s): 2; 1 hop(s): 4; 2 hop(s): 6; 3 hop(s): 8; 4 hop(s): 10 | 2 x (hops + 1) | yes |
| mesh4x4_d4 | 256 | 0 hop(s): 2; 1 hop(s): 4; 2 hop(s): 6; 3 hop(s): 8; 4 hop(s): 10; 5 hop(s): 12; 6 hop(s): 14 | 2 x (hops + 1) | yes |
| xbar3x3_d4 | 81 | 0 hop(s): 2; 1 hop(s): 2; 2 hop(s): 2; 3 hop(s): 2; 4 hop(s): 2 | 2 (any pair) | yes |
| xbar4x4_d4 | 256 | 0 hop(s): 2; 1 hop(s): 2; 2 hop(s): 2; 3 hop(s): 2; 4 hop(s): 2; 5 hop(s): 2; 6 hop(s): 2 | 2 (any pair) | yes |

Each router adds 2 cycles (buffer write, then switch allocation + egress register); a link is a register, so a hop costs exactly one router. The crossbar pays one router regardless of source and destination.

## 2. Latency and throughput versus offered load (uniform random, destination != source)

| offered | fabric | accepted | net lat mean | p50 | p95 | p99 | p99.9 | max | src backlog at end |
|---|---|---|---|---|---|---|---|---|---|
| 0.031 | mesh2x2_d4 | 0.032 | 4.68 | 4 | 6 | 6 | 7 | 7 | 0 |
| 0.062 | mesh2x2_d4 | 0.063 | 4.69 | 4 | 6 | 6 | 7 | 8 | 0 |
| 0.125 | mesh2x2_d4 | 0.125 | 4.72 | 4 | 6 | 7 | 8 | 9 | 0 |
| 0.188 | mesh2x2_d4 | 0.188 | 4.75 | 4 | 6 | 7 | 8 | 9 | 0 |
| 0.250 | mesh2x2_d4 | 0.250 | 4.79 | 4 | 6 | 7 | 8 | 10 | 0 |
| 0.312 | mesh2x2_d4 | 0.313 | 4.84 | 4 | 7 | 7 | 9 | 11 | 0 |
| 0.375 | mesh2x2_d4 | 0.375 | 4.90 | 4 | 7 | 8 | 9 | 12 | 0 |
| 0.438 | mesh2x2_d4 | 0.437 | 4.97 | 4 | 7 | 8 | 10 | 13 | 0 |
| 0.500 | mesh2x2_d4 | 0.500 | 5.07 | 5 | 7 | 9 | 10 | 15 | 0 |
| 0.562 | mesh2x2_d4 | 0.563 | 5.20 | 5 | 8 | 9 | 12 | 16 | 0 |
| 0.625 | mesh2x2_d4 | 0.625 | 5.38 | 5 | 8 | 10 | 13 | 18 | 0 |
| 0.688 | mesh2x2_d4 | 0.687 | 5.66 | 5 | 9 | 11 | 15 | 22 | 0 |
| 0.750 | mesh2x2_d4 | 0.750 | 6.15 | 6 | 10 | 13 | 18 | 27 | 0 |
| 0.875 | mesh2x2_d4 | 0.869 | 9.78 | 9 | 16 | 20 | 25 | 35 | 761 |
| 1.000 | mesh2x2_d4 | 0.870 | 9.82 | 9 | 16 | 20 | 25 | 35 | 16376 |
| 0.031 | xbar2x2_d4 | 0.032 | 2.01 | 2 | 2 | 3 | 3 | 4 | 0 |
| 0.062 | xbar2x2_d4 | 0.063 | 2.03 | 2 | 2 | 3 | 3 | 4 | 0 |
| 0.125 | xbar2x2_d4 | 0.125 | 2.05 | 2 | 3 | 3 | 4 | 5 | 0 |
| 0.188 | xbar2x2_d4 | 0.188 | 2.09 | 2 | 3 | 3 | 4 | 5 | 0 |
| 0.250 | xbar2x2_d4 | 0.250 | 2.14 | 2 | 3 | 4 | 5 | 7 | 0 |
| 0.312 | xbar2x2_d4 | 0.313 | 2.21 | 2 | 3 | 4 | 5 | 7 | 0 |
| 0.375 | xbar2x2_d4 | 0.375 | 2.30 | 2 | 4 | 5 | 6 | 9 | 0 |
| 0.438 | xbar2x2_d4 | 0.437 | 2.45 | 2 | 4 | 5 | 7 | 9 | 0 |
| 0.500 | xbar2x2_d4 | 0.500 | 2.69 | 2 | 5 | 6 | 8 | 10 | 0 |
| 0.562 | xbar2x2_d4 | 0.563 | 3.12 | 3 | 6 | 7 | 9 | 11 | 0 |
| 0.625 | xbar2x2_d4 | 0.625 | 3.92 | 4 | 7 | 8 | 10 | 12 | 1 |
| 0.688 | xbar2x2_d4 | 0.686 | 5.63 | 6 | 8 | 9 | 11 | 12 | 168 |
| 0.750 | xbar2x2_d4 | 0.689 | 5.80 | 6 | 8 | 9 | 11 | 12 | 7820 |
| 0.875 | xbar2x2_d4 | 0.689 | 5.80 | 6 | 8 | 9 | 11 | 12 | 16375 |
| 1.000 | xbar2x2_d4 | 0.689 | 5.80 | 6 | 8 | 9 | 11 | 12 | 16378 |

Beyond saturation the network latency plateaus (9.8 cycles mesh, 5.8 crossbar) because the buffers are finite: the excess load queues at the *sources* (the `src backlog` column grows without bound), not in the fabric. Total latency including source queueing keeps growing.

![latency and throughput](img/latency_throughput.png)

## 3. Saturation throughput: predicted versus observed

Offered load 1.0 flit/cycle/tile (beyond saturation) with unbounded source queues. *Channel-load bound* =
`1 / max(load per unit injection rate)` over every directed link, ejection port and injection port (XY routing, 1 flit/cycle per resource) - it ignores head-of-line blocking, arbitration and buffer limits, so the simulation sits below it. The gap is the cost of the real microarchitecture.

| pattern | fabric | channel-load bound | limiting resource | observed accepted | observed / bound | note |
|---|---|---|---|---|---|---|
| uniform_ne | mesh | 1.000 | injection | 0.870 (0.867..0.871) | 0.87 |  |
| uniform_ne | xbar | 1.000 | injection | 0.689 (0.689..0.690) | 0.69 | above the incl.-self HOL limit: excluding self leaves fewer output conflicts |
| uniform | mesh | 1.000 | injection | 0.832 (0.831..0.834) | 0.83 |  |
| uniform | xbar | 1.000 | injection | 0.655 (0.654..0.656) | 0.66 | matches the FIFO input-queued HOL limit 0.655 (independent Monte-Carlo, N=4, uniform incl. self) |
| transpose | mesh | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| transpose | xbar | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| complement | mesh | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| complement | xbar | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| neighbor | mesh | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| neighbor | xbar | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| local | mesh | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| local | xbar | 1.000 | injection | 1.000 (1.000..1.000) | 1.00 |  |
| allto1 | mesh | 0.250 | ejection | 0.250 (0.250..0.250) | 1.00 |  |
| allto1 | xbar | 0.250 | ejection | 0.250 (0.250..0.250) | 1.00 |  |
| hotspot | mesh | 0.400 | ejection | 0.399 (0.398..0.400) | 1.00 |  |
| hotspot | xbar | 0.400 | ejection | 0.399 (0.398..0.402) | 1.00 |  |

![saturation](img/saturation_vs_bound.png)

## 4. Per-link utilisation (from the RTL traffic counters)

Utilisation = FLITS_OUT / measurement cycles for each router output; `L` is the ejection port. Raw link width is 26 B/flit, so 1.00 = 26 bytes/cycle. Payload bytes depend on the random byte enables and classes and are exported by the counters (PAYLOAD_BYTES_OUT) but not used here.

**uniform random (saturated), mesh 2x2** (router (x,y): tile = 2y+x)

| router | L(eject) | N | E | S | W |
|---|---|---|---|---|---|
| 0 (0,0) | 0.865 | 0.578 | 0.580 | - | - |
| 1 (1,0) | 0.874 | 0.582 | - | - | 0.579 |
| 2 (0,1) | 0.867 | - | 0.583 | 0.575 | - |
| 3 (1,1) | 0.872 | - | - | 0.585 | 0.577 |

**all-to-one -> tile 0 (saturated), mesh 2x2** (router (x,y): tile = 2y+x)

| router | L(eject) | N | E | S | W |
|---|---|---|---|---|---|
| 0 (0,0) | 1.000 | - | - | - | - |
| 1 (1,0) | - | - | - | - | 0.333 |
| 2 (0,1) | - | - | - | 0.333 | - |
| 3 (1,1) | - | - | - | - | 0.167 |

**transpose (saturated), mesh 2x2** (router (x,y): tile = 2y+x)

| router | L(eject) | N | E | S | W |
|---|---|---|---|---|---|
| 0 (0,0) | 1.000 | 1.000 | - | - | - |
| 1 (1,0) | 1.000 | - | - | - | 1.000 |
| 2 (0,1) | 1.000 | - | 1.000 | - | - |
| 3 (1,1) | 1.000 | - | - | 1.000 | - |

![link utilisation](img/link_utilisation.png)

### 4b. Contention counters, all-to-one -> tile 0, mesh 2x2, saturated

Rates are events per cycle over the measurement window (mean of seeds). Output-indexed: link stall (output register held a flit the sink refused), arbitration blocked (requesters present, none granted: back-pressure), arbitration losers per cycle (contention). Input-indexed: mean and maximum input-buffer occupancy (capacity 4), head-of-line blocking cycles.

| router.port | link stall | arb blocked | arb losers | mean occupancy | max occupancy | HOL block |
|---|---|---|---|---|---|---|
| r0.L | 0.000 | 0.000 | 2.000 | 3.67 | 4 | 0.667 |
| r0.N | 0.000 | 0.000 | 0.000 | 3.67 | 4 | 0.667 |
| r0.E | 0.000 | 0.000 | 0.000 | 3.67 | 4 | 0.667 |
| r1.L | 0.000 | 0.000 | 0.000 | 3.67 | 4 | 0.667 |
| r1.W | 0.667 | 0.667 | 0.667 | 0.00 | 0 | 0.000 |
| r2.L | 0.000 | 0.000 | 0.000 | 3.83 | 4 | 0.833 |
| r2.E | 0.000 | 0.000 | 0.000 | 3.83 | 4 | 0.833 |
| r2.S | 0.667 | 0.667 | 1.667 | 0.00 | 0 | 0.000 |
| r3.L | 0.000 | 0.000 | 0.000 | 3.83 | 4 | 0.833 |
| r3.W | 0.833 | 0.833 | 0.833 | 0.00 | 0 | 0.000 |

| tile | injection stalled (source back-pressure) | ejection refused by sink | flits in flight to this tile: mean | max | cycles with >= 4 in flight |
|---|---|---|---|---|---|
| 0 | 0.667 | 0.000 | 30.17 | 31 | 1.000 |
| 1 | 0.667 | 0.000 | 0.00 | 0 | 0.000 |
| 2 | 0.833 | 0.000 | 0.00 | 0 | 0.000 |
| 3 | 0.833 | 0.000 | 0.00 | 0 | 0.000 |

Reading the counters: the hot tile's ejection output (`r0.L`) is *saturated*, not blocked: it is granted in every cycle (utilisation 1.000), the sink always accepts (link stall 0), and the arbiter sees about two losing requesters per cycle (ARB_LOSE). The back-pressure appears one step upstream: the links into router 0 stall (`r1.W`, `r2.S`, `r3.W`), router 0's input buffers sit nearly full (occupancy ~3.7 of 4, HOL blocking), and every other tile sees only source-side injection stalls.

## 5. Fairness and waiting time under contention (all-to-one, tile 0, saturated)

Per-source accepted throughput share. Round-robin arbitration is *locally* fair at each output, which does not make it *globally* fair: a source that merges after more hops competes against the aggregate of everything upstream (the parking-lot effect). Jain index J = (sum x)^2 / (n sum x^2); 1.0 = perfectly equal.

| fabric | tiles | per-source share of delivered flits (src 0..n-1) | Jain | min/max | mean net latency | p99 net latency (worst source) |
|---|---|---|---|---|---|---|
| mesh2x2_d4 | 4 | 0.333, 0.333, 0.167, 0.167 | 0.900 | 0.50 | 30.2 | 67 |
| xbar2x2_d4 | 4 | 0.250, 0.250, 0.250, 0.250 | 1.000 | 1.00 | 16.0 | 16 |
| mesh3x3_d4 | 9 | 0.333, 0.167, 0.167, 0.111, 0.056, 0.056, 0.056, 0.028, 0.028 | 0.585 | 0.08 | 74.8 | 470 |
| xbar3x3_d4 | 9 | 0.111, 0.111, 0.111, 0.111, 0.111, 0.111, 0.111, 0.111, 0.111 | 1.000 | 1.00 | 36.0 | 36 |
| mesh4x4_d4 | 16 | 0.333, 0.167, 0.083, 0.083, 0.111, 0.056, 0.028, 0.028, 0.037, 0.018, 0.009, 0.009, 0.019, 0.009, 0.005, 0.005 | 0.363 | 0.01 | 137.6 | 2943 |
| xbar4x4_d4 | 16 | 0.062, 0.062, 0.062, 0.062, 0.062, 0.063, 0.062, 0.062, 0.062, 0.062, 0.062, 0.062, 0.062, 0.062, 0.062, 0.062 | 1.000 | 1.00 | 64.0 | 64 |

![fairness](img/fairness.png)

## 6. Buffer-depth sensitivity (2x2, uniform random)

| depth | mesh sat. throughput | mesh net lat @0.375 | mesh p99 | xbar sat. throughput | xbar net lat @0.375 | xbar p99 | mesh all-to-one sat. | xbar all-to-one sat. |
|---|---|---|---|---|---|---|---|---|
| 2 | 0.794 | 4.89 | 8 | 0.690 | 2.25 | 4 | 0.250 | 0.250 |
| 3 | 0.841 | 4.90 | 8 | 0.689 | 2.30 | 5 | 0.250 | 0.250 |
| 4 | 0.870 | 4.90 | 8 | 0.689 | 2.30 | 5 | 0.250 | 0.250 |
| 6 | 0.898 | 4.90 | 8 | 0.689 | 2.31 | 5 | 0.250 | 0.250 |
| 8 | 0.913 | 4.90 | 8 | 0.690 | 2.31 | 5 | 0.250 | 0.250 |
| 16 | 0.929 | 4.90 | 8 | 0.689 | 2.31 | 5 | 0.250 | 0.250 |

![depth](img/depth_sensitivity.png)

## 7. Scaling (uniform random, d=4)

| tiles | mesh sat. | mesh channel bound | mesh low-load latency | xbar sat. | xbar HOL limit (MC) | xbar low-load latency |
|---|---|---|---|---|---|---|
| 4 | 0.870 | 1.000 | 4.69 | 0.689 | 0.655 | 2.03 |
| 9 | 0.760 | 1.000 | 6.04 | 0.620 | 0.614 | 2.03 |
| 16 | 0.633 | 0.938 | 7.40 | 0.603 | 0.602 | 2.03 |

The mesh's per-tile saturation throughput *falls* with size under uniform traffic (bisection bandwidth per tile shrinks as 1/k), while its latency grows with the diameter; the crossbar keeps one-router latency, its saturation approaches the large-N input-queue limit (0.586) and its logic grows about as N^2 (14,620 -> 57,412 NAND2-eq from 4 to 9 ports, 3.9x for 2.25x the endpoints; reports/synth.md). At 16 tiles the mesh's advantage in saturation throughput has nearly vanished (0.633 vs 0.603).

## 8. Ejection back-pressure (uniform random, offered 0.375)

| sink accept probability | mesh accepted | mesh net lat | xbar accepted | xbar net lat |
|---|---|---|---|---|
| 0.25 | 0.228 | 50.5 | 0.184 | 24.7 |
| 0.50 | 0.375 | 10.7 | 0.361 | 12.1 |
| 0.75 | 0.375 | 5.7 | 0.375 | 3.6 |

## 9. Measurement integrity

* 324 simulations, all with the DUT's assertions armed and the scoreboard checking every flit: 0 reported errors.
* Hardware latency counters (when dumped) agreed with the testbench: collisions/unmatched = 0 in 45 runs, non-zero in 0.
* The latency counters time packets whose txn_id is unique per source in flight; the load generator guarantees this for the 256-entry table used here.

