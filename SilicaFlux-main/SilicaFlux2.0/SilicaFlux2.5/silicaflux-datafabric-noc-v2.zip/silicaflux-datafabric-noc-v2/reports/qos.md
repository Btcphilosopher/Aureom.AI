# QoS: one high-class source vs two low-class sources on one output (2000-cycle window, all sources saturated)

Tile 0 is the high class; tiles 1 and 2 are low; all send to tile 3, so they contend for one ejection output (and tile 1/tile 0 share a link).
The low class must keep a bounded share; the testbench requires >= 2000 / (2(K+1)) flits (K = guard limit; 100 for strict priority).

| configuration | seed | high-class delivered | low-class delivered (2 sources) | low share | test |
|---|---|---|---|---|---|
| QOS_ARB_EN=0 (round-robin, classes ignored) | 1 | 498 | 1497 | 75.0% | PASS |
| QOS_ARB_EN=0 (round-robin, classes ignored) | 2 | 498 | 1497 | 75.0% | PASS |
| QOS_ARB_EN=0 (round-robin, classes ignored) | 3 | 498 | 1497 | 75.0% | PASS |
| QOS_ARB_EN=1, QOS_STARVE_LIMIT=0 (strict priority, the original behaviour) | 1 | 1992 | 3 | 0.2% | FAIL |
| QOS_ARB_EN=1, QOS_STARVE_LIMIT=0 (strict priority, the original behaviour) | 2 | 1992 | 3 | 0.2% | FAIL |
| QOS_ARB_EN=1, QOS_STARVE_LIMIT=0 (strict priority, the original behaviour) | 3 | 1992 | 3 | 0.2% | FAIL |
| QOS_ARB_EN=1, K=7 | 1 | 1550 | 445 | 22.3% | PASS |
| QOS_ARB_EN=1, K=7 | 2 | 1550 | 445 | 22.3% | PASS |
| QOS_ARB_EN=1, K=7 | 3 | 1550 | 445 | 22.3% | PASS |
| QOS_ARB_EN=1, K=3 | 1 | 1196 | 799 | 40.1% | PASS |
| QOS_ARB_EN=1, K=3 | 2 | 1196 | 799 | 40.1% | PASS |
| QOS_ARB_EN=1, K=3 | 3 | 1196 | 799 | 40.1% | PASS |

Strict priority gives the low class essentially nothing while the high class is active (a deliberate, documented failure of the
starvation requirement); the guard bounds it. The guard's *formal* wait bound is (NP-1)(K+1)+K cycles, proved for K = 1 (`reports/formal.md`).
