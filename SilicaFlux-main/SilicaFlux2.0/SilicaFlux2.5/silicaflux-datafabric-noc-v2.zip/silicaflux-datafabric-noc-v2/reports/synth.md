# Synthesis results (technology independent)

Yosys 0.71 + SLANG; `synth -flatten`, `abc -g NAND`. **No PDK: no um^2, ns or MHz are claimed.**
NAND2-eq = NAND2 x 1.0 + NOT x 0.5 + flop x 5.0 (conventional weights, stated for re-derivation).
`levels` = Yosys `ltp -noff` longest combinational path in NAND2/NOT levels (structural timing proxy).

| design | flops | NAND2 | NOT | NAND2-eq (logic) | NAND2-eq (total) | logic levels | note |
|---|---|---|---|---|---|---|---|
| fifo_d4_w8 | 41 | 105 | 31 | 120 | 326 | 13 | $_DFFE_PN0P_=4; $_DFFE_PP_=32; $_DFF_PN0_=4; $_DFF_PN1_=1 |
| router_2x2_n00_d4 | 3160 | 7679 | 620 | 7989 | 23789 | 30 | $_DFFE_PN0P_=18; $_DFFE_PP_=3127; $_DFF_PN0_=12; $_DFF_PN1_=3 |
| router_3x3_n11_d4 | 5302 | 15844 | 1853 | 16770 | 43280 | 33 | $_DFFE_PN0P_=37; $_DFFE_PP_=5240; $_DFF_PN0_=20; $_DFF_PN1_=5 |
| mesh2x2_d2 | 7602 | 15508 | 2282 | 16649 | 54659 | 24 | $_DFFE_PN0P_=48; $_DFFE_PP_=7506; $_DFF_PN0_=36; $_DFF_PN1_=12 |
| mesh2x2_d4 | 12650 | 30733 | 2469 | 31968 | 95218 | 33 | $_DFFE_PN0P_=72; $_DFFE_PP_=12518; $_DFF_PN0_=48; $_DFF_PN1_=12 |
| mesh2x2_d8 | 22710 | 56130 | 18361 | 65310 | 178860 | 42 | $_DFFE_PN0P_=96; $_DFFE_PP_=22542; $_DFF_PN0_=60; $_DFF_PN1_=12 |
| mesh2x2_d4_explicit | 12712 | 30949 | 2531 | 32214 | 95774 | 35 | $_DFFE_PN0P_=136; $_DFFE_PP_=12516; $_DFF_PN0_=48; $_DFF_PN1_=12 |
| mesh2x2_d4_qos | 12687 | 31060 | 2726 | 32423 | 95858 | 48 | $_DFFE_PN0P_=108; $_DFFE_PP_=12519; $_DFF_PN0_=48; $_DFF_PN1_=12 |
| mesh3x3_d4 | 34898 | 92967 | 9026 | 97480 | 271970 | 33 | $_DFFE_PN0P_=217; $_DFFE_PP_=34516; $_DFF_PN0_=132; $_DFF_PN1_=33 |
| xbar4_d2 | 2524 | 8566 | 1984 | 9558 | 22178 | 33 | $_DFFE_PN0P_=24; $_DFFE_PP_=2484; $_DFF_PN0_=12; $_DFF_PN1_=4 |
| xbar4_d4 | 4192 | 13595 | 2050 | 14620 | 35580 | 40 | $_DFFE_PN0P_=32; $_DFFE_PP_=4140; $_DFF_PN0_=16; $_DFF_PN1_=4 |
| xbar4_d8 | 7516 | 22035 | 7327 | 25698 | 63278 | 48 | $_DFFE_PN0P_=40; $_DFFE_PP_=7452; $_DFF_PN0_=20; $_DFF_PN1_=4 |
| xbar9_d4 | 9477 | 50068 | 14687 | 57412 | 104796 | 72 | $_DFFE_PN0P_=117; $_DFFE_PP_=9315; $_DFF_PN0_=36; $_DFF_PN1_=9 |
| counters_2x2 | 14173 | 134716 | 60754 | 165093 | 235958 | 229 | $_DFFE_PN0N_=128; $_DFFE_PN0P_=9725; $_DFFE_PN1P_=64; $_DFFE_PP_=4096; $_DFF_PN0_=160 |
| master_ni | 5592 | 15765 | 5054 | 18292 | 46252 | 64 | $_DFFE_PN0P_=103; $_DFFE_PN1P_=1; $_DFFE_PP_=5463; $_DFF_PN0_=19; $_DFF_PN1_=3; $_SDFFCE_PP0P_=2; $_SDFFCE_PP1P_=1 |
| target_ni | 4590 | 12716 | 2161 | 13796 | 36746 | 62 | $_DFFE_PN0P_=616; $_DFFE_PN1P_=2; $_DFFE_PP_=3927; $_DFF_PN0_=35; $_DFF_PN1_=8; $_SDFFCE_PP0P_=2 |
| fabric_dual_nocnt | 25424 | 61835 | 5027 | 64348 | 191468 | 35 | $_DFFE_PN0P_=272; $_DFFE_PP_=25032; $_DFF_PN0_=96; $_DFF_PN1_=24 |
| fabric_dual_cnt | 50074 | 290567 | 109856 | 345495 | 595865 | 229 | $_DFFE_PN0N_=256; $_DFFE_PN0P_=16026; $_DFFE_PN1P_=128; $_DFFE_PP_=33224; $_DFF_PN0_=416; $_DFF_PN1_=24 |
