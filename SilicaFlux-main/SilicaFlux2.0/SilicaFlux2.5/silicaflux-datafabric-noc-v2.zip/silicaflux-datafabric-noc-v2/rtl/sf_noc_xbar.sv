// =============================================================================
//  sf_noc_xbar : NUM_TILES x NUM_TILES single-flit crossbar (comparison fabric)
//
//  Purpose: the brief asks that a 4-node mesh is not assumed to be the right
//  answer without comparing it with a small crossbar. This module is that
//  crossbar, built to the same conventions as noc_router so the comparison is
//  like-for-like:
//     * same noc_packet_t, same ready/valid contract on the tile ports
//     * input FIFO per tile (registered full/empty, BUF_DEPTH entries)
//     * per-output round-robin arbitration (same mask/lsb scheme)
//     * egress staging register driving the ejection port
//     * same hardware ingress validation (V2-1) and error taps
//  Pipeline: accept (t) -> FIFO head visible (t+1) -> SA + egress register
//  (t+1) -> ejection valid (t+2): every source/destination pair has a
//  zero-load latency of 2 cycles (the mesh needs 2*(hops+1)).
//  Single-flit packets only (no wormhole, no QoS): it is a baseline, not a
//  second product.
// =============================================================================
module sf_noc_xbar
  import silicaflux_pkg::*;
#(
  parameter int unsigned NUM_TILES = 4,
  parameter int unsigned MESH_X    = 2,           // coordinate decode of dst_id/src_id
  parameter int unsigned MESH_Y    = NUM_TILES / MESH_X,
  parameter int unsigned BUF_DEPTH = 4,
  parameter bit          CHECK_CLASS = 1'b1,
  parameter bit          CHECK_SRC   = 1'b1
) (
  input  logic                                  clk_i,
  input  logic                                  rst_ni,

  input  logic        [NUM_TILES-1:0]           tile_inj_valid_i,
  input  noc_packet_t [NUM_TILES-1:0]           tile_inj_pkt_i,
  output logic        [NUM_TILES-1:0]           tile_inj_ready_o,

  output logic        [NUM_TILES-1:0]           tile_ej_valid_o,
  output noc_packet_t [NUM_TILES-1:0]           tile_ej_pkt_o,
  input  logic        [NUM_TILES-1:0]           tile_ej_ready_i,

  output logic                                  noc_idle_o,

  output logic        [NUM_TILES-1:0]           err_drop_o,
  output logic        [NUM_TILES-1:0][2:0]      err_cause_o,

  output logic        [NUM_TILES-1:0]           perf_in_fire_o,
  output logic        [NUM_TILES-1:0]           perf_out_fire_o,
  output logic        [NUM_TILES-1:0][NUM_TILES-1:0] perf_sa_req_o,   // [out][in]
  output logic        [NUM_TILES-1:0][NUM_TILES-1:0] perf_sa_gnt_o,
  output logic        [NUM_TILES-1:0][$clog2(BUF_DEPTH+1)-1:0] perf_buf_count_o
);

  localparam int unsigned PTR_W  = (BUF_DEPTH > 1) ? $clog2(BUF_DEPTH) : 1;
  localparam int unsigned CNT_W  = $clog2(BUF_DEPTH + 1);
  localparam int unsigned XW     = (MESH_X > 1) ? $clog2(MESH_X) : 1;
  localparam int unsigned YW     = (MESH_Y > 1) ? $clog2(MESH_Y) : 1;
  localparam int unsigned IDW    = $bits(sf_noc_id_t);
  localparam int unsigned PKT_BITS = $bits(noc_packet_t);

  if (BUF_DEPTH < 2) begin : g_chk_depth
    $error("sf_noc_xbar: BUF_DEPTH >= 2 required for full-rate registered-ready flow control");
  end
  if (MESH_X * MESH_Y != NUM_TILES) begin : g_chk_dims
    $error("sf_noc_xbar: MESH_X*MESH_Y must equal NUM_TILES");
  end

  function automatic logic [NUM_TILES-1:0] lsb_onehot(input logic [NUM_TILES-1:0] v);
    return v & (~v + NUM_TILES'(1));
  endfunction

  function automatic logic [PTR_W-1:0] ptr_inc(input logic [PTR_W-1:0] p);
    return (p == PTR_W'(BUF_DEPTH - 1)) ? '0 : (p + PTR_W'(1));
  endfunction

  // Per-input decode (index of the destination tile, validity)
  logic [NUM_TILES-1:0]                 in_push;
  logic [NUM_TILES-1:0]                 hd_valid;
  noc_packet_t                          hd_pkt   [NUM_TILES];
  logic [NUM_TILES-1:0][NUM_TILES-1:0]  hd_dest;     // [in][out] one-hot
  logic [NUM_TILES-1:0][NUM_TILES-1:0]  sa_req;      // [out][in]
  logic [NUM_TILES-1:0][NUM_TILES-1:0]  sa_gnt;      // [out][in]
  logic [NUM_TILES-1:0]                 hd_pop;
  logic [NUM_TILES-1:0]                 out_valid;
  noc_packet_t                          out_pkt  [NUM_TILES];

  for (genvar i = 0; i < NUM_TILES; i++) begin : g_in
    localparam logic [IDW-1:0] MY_ID = sf_noc_id(i % MESH_X, i / MESH_X, MESH_X);

    logic [CNT_W-1:0] count_q, count_d;
    logic [PTR_W-1:0] wr_q, rd_q;
    logic             full_q, empty_q;
    noc_packet_t      mem [BUF_DEPTH];

    logic bad_dst, bad_cls, bad_src, drop, push;
    int unsigned dx, dy;
    assign dx = int'(tile_inj_pkt_i[i].dst_id) & ((1 << XW) - 1);
    assign dy = (int'(tile_inj_pkt_i[i].dst_id) >> XW) & ((1 << YW) - 1);
    assign bad_dst = ~(((32'(tile_inj_pkt_i[i].dst_id) >> (XW + YW)) == 0) &&
                       (dx < MESH_X) && (dy < MESH_Y));
    assign bad_cls = ~tile_inj_pkt_i[i].valid |
                     (CHECK_CLASS & ~sf_noc_class_legal(tile_inj_pkt_i[i].pclass));
    assign bad_src = CHECK_SRC & (tile_inj_pkt_i[i].src_id != MY_ID);
    assign drop    = tile_inj_valid_i[i] & ~full_q & (bad_dst | bad_cls | bad_src);
    assign push    = tile_inj_valid_i[i] & ~full_q & ~drop;

    assign tile_inj_ready_o[i] = ~full_q;
    assign in_push[i]          = push;
    assign err_drop_o[i]       = drop;
    assign err_cause_o[i]      = {bad_src, bad_cls, bad_dst};
    assign perf_in_fire_o[i]   = push;
    assign perf_buf_count_o[i] = count_q;

    always_comb begin
      unique case ({push, hd_pop[i]})
        2'b10:   count_d = count_q + CNT_W'(1);
        2'b01:   count_d = count_q - CNT_W'(1);
        default: count_d = count_q;
      endcase
    end

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        wr_q <= '0; rd_q <= '0; count_q <= '0; full_q <= 1'b0; empty_q <= 1'b1;
      end else begin
        if (push)      wr_q <= ptr_inc(wr_q);
        if (hd_pop[i]) rd_q <= ptr_inc(rd_q);
        count_q <= count_d;
        full_q  <= (count_d == CNT_W'(BUF_DEPTH));
        empty_q <= (count_d == '0);
      end
    end

    always_ff @(posedge clk_i) begin
      if (push) mem[wr_q] <= tile_inj_pkt_i[i];
    end

    assign hd_valid[i] = ~empty_q;
    assign hd_pkt[i]   = mem[rd_q];

    // destination one-hot of the head flit (head is known-valid: it passed V2-1)
    always_comb begin
      int unsigned hx, hy, hidx;
      hx   = int'(hd_pkt[i].dst_id) & ((1 << XW) - 1);
      hy   = (int'(hd_pkt[i].dst_id) >> XW) & ((1 << YW) - 1);
      hidx = hy * MESH_X + hx;
      hd_dest[i] = '0;
      for (int o = 0; o < NUM_TILES; o++) hd_dest[i][o] = hd_valid[i] && (hidx == o);
    end

`ifndef SYNTHESIS
    a_no_overflow:  assert property (@(posedge clk_i) disable iff (!rst_ni) push |-> (count_q < CNT_W'(BUF_DEPTH)));
    a_no_underflow: assert property (@(posedge clk_i) disable iff (!rst_ni) hd_pop[i] |-> !empty_q);
`endif
  end

  // Switch allocation + egress per output
  for (genvar o = 0; o < NUM_TILES; o++) begin : g_out
    logic [NUM_TILES-1:0] req, req_masked, gnt_rr, mask_q;
    logic                 valid_q, can_accept;
    noc_packet_t          pkt_q;
    logic [PKT_BITS-1:0]  xbar_bits;

    for (genvar i = 0; i < NUM_TILES; i++) begin : g_req
      assign req[i] = hd_dest[i][o];
    end
    assign sa_req[o]      = req;
    assign req_masked     = req & mask_q;
    assign gnt_rr         = (|req_masked) ? lsb_onehot(req_masked) : lsb_onehot(req);
    assign can_accept     = ~valid_q | tile_ej_ready_i[o];
    assign sa_gnt[o]      = can_accept ? gnt_rr : '0;

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) mask_q <= '0;
      else if (|sa_gnt[o]) mask_q <= ~(sa_gnt[o] | (sa_gnt[o] - NUM_TILES'(1)));
    end

    always_comb begin
      xbar_bits = '0;
      for (int i = 0; i < NUM_TILES; i++) xbar_bits |= {PKT_BITS{sa_gnt[o][i]}} & PKT_BITS'(hd_pkt[i]);
    end

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni)              valid_q <= 1'b0;
      else if (|sa_gnt[o])      valid_q <= 1'b1;
      else if (tile_ej_ready_i[o]) valid_q <= 1'b0;
    end
    always_ff @(posedge clk_i) begin
      if (|sa_gnt[o]) pkt_q <= noc_packet_t'(xbar_bits);
    end

    assign out_valid[o]        = valid_q;
    assign out_pkt[o]          = pkt_q;
    assign tile_ej_valid_o[o]  = valid_q;
    assign tile_ej_pkt_o[o]    = pkt_q;
    assign perf_out_fire_o[o]  = valid_q & tile_ej_ready_i[o];
    assign perf_sa_req_o[o]    = req;
    assign perf_sa_gnt_o[o]    = sa_gnt[o];

`ifndef SYNTHESIS
    a_onehot0_gnt: assert property (@(posedge clk_i) disable iff (!rst_ni) $onehot0(sa_gnt[o]));
    a_ej_hold: assert property (@(posedge clk_i) disable iff (!rst_ni)
      (valid_q && !tile_ej_ready_i[o]) |=> (valid_q && $stable(pkt_q)));
`endif
  end

  always_comb begin
    hd_pop = '0;
    for (int o = 0; o < NUM_TILES; o++) hd_pop |= sa_gnt[o];
  end

  assign noc_idle_o = ~|{hd_valid, out_valid};

endmodule : sf_noc_xbar
