// =============================================================================
//  sf_noc_fabric : SilicaFlux DataFabric NoC v2 top
//
//  SEPARATE_RSP = 1 (the supported configuration)
//      two physically separate meshes: a REQUEST network (RD_REQ, WR_REQ, MSG)
//      and a RESPONSE network (RD_RSP, WR_RSP). A tile has four ports: request
//      inject/eject and response inject/eject. No buffer, link or arbiter is
//      shared between the two classes, so a stalled request can never occupy
//      the resources a response needs.
//  SEPARATE_RSP = 0 (evidence configuration)
//      ONE mesh carries both classes (per-tile injection merge, ejection demux
//      by class). Provided so the protocol-level deadlock can be demonstrated
//      and measured, not for use: see docs/DEADLOCK.md and tb/tb_noc_sys.sv.
//
//  XY routing makes each mesh deadlock-free on its own; it says nothing about a
//  protocol in which delivering a request requires injecting a response. That
//  dependency is closed by (1) the two networks and (2) the requester's
//  guaranteed response sink (credit reservation in sf_noc_mem_master_ni).
//
//  Counters: one sf_noc_traffic_counters per network; rd_plane_i selects which
//  one the read port addresses (0 request, 1 response).
// =============================================================================
module sf_noc_fabric
  import silicaflux_pkg::*;
#(
  parameter int unsigned MESH_X           = 2,
  parameter int unsigned MESH_Y           = 2,
  parameter int unsigned BUF_DEPTH        = 4,
  parameter bit          SEPARATE_RSP     = 1'b1,
  parameter bit          EXPLICIT_FRAMING = 1'b1,
  parameter bit          QOS_ARB_EN       = 1'b0,
  parameter int unsigned QOS_STARVE_LIMIT = 0,
  parameter bit          CNT_EN           = 1'b1,
  parameter int unsigned LAT_IDX_W        = 8,
  localparam int unsigned NT              = MESH_X * MESH_Y
) (
  input  logic                          clk_i,
  input  logic                          rst_ni,

  // request network
  input  logic        [NT-1:0]          req_in_valid_i,
  input  noc_packet_t [NT-1:0]          req_in_pkt_i,
  output logic        [NT-1:0]          req_in_ready_o,
  output logic        [NT-1:0]          req_out_valid_o,
  output noc_packet_t [NT-1:0]          req_out_pkt_o,
  input  logic        [NT-1:0]          req_out_ready_i,

  // response network
  input  logic        [NT-1:0]          rsp_in_valid_i,
  input  noc_packet_t [NT-1:0]          rsp_in_pkt_i,
  output logic        [NT-1:0]          rsp_in_ready_o,
  output logic        [NT-1:0]          rsp_out_valid_o,
  output noc_packet_t [NT-1:0]          rsp_out_pkt_o,
  input  logic        [NT-1:0]          rsp_out_ready_i,

  output logic                          noc_idle_o,
  output logic        [NT-1:0]          err_drop_o,

  // counters
  input  logic                          ctrl_clear_i,
  input  logic                          ctrl_freeze_i,
  input  logic                          rd_plane_i,
  input  logic        [15:0]            rd_addr_i,
  output logic        [31:0]            rd_data_o,
  output logic                          ovf_o
);

  localparam int unsigned NP = 5;
  localparam int unsigned BW = $clog2(BUF_DEPTH + 1);
  localparam int unsigned NPL = SEPARATE_RSP ? 2 : 1;

  // per-plane tile ports (plane 0 = request or shared, plane 1 = response)
  logic        [NPL-1:0][NT-1:0]  p_inj_valid, p_inj_ready, p_ej_valid, p_ej_ready;
  noc_packet_t [NPL-1:0][NT-1:0]  p_inj_pkt, p_ej_pkt;
  logic        [NPL-1:0]          p_idle;
  logic        [NPL-1:0][NT-1:0]  p_err_drop, p_err_drop_head;
  logic        [NPL-1:0][NT-1:0][2:0] p_err_cause;
  logic        [NPL-1:0][NT-1:0][NP-1:0]        p_in_fire, p_in_head, p_out_fire, p_out_head, p_lstall, p_hol;
  logic        [NPL-1:0][NT-1:0][NP-1:0][NP-1:0] p_sa_req, p_sa_gnt;
  logic        [NPL-1:0][NT-1:0][NP-1:0][BW-1:0] p_buf;
  noc_packet_t [NPL-1:0][NT-1:0][NP-1:0]        p_out_pkt;

  for (genvar pl = 0; pl < NPL; pl++) begin : g_plane
    noc_interconnect #(
      .pkt_t(noc_packet_t), .MESH_X(MESH_X), .MESH_Y(MESH_Y), .BUF_DEPTH(BUF_DEPTH),
      .FLITS_PER_PKT(1), .QOS_ARB_EN(QOS_ARB_EN), .PROGRESS_WDOG_CYCLES(0),
      .EXPLICIT_FRAMING(EXPLICIT_FRAMING), .QOS_STARVE_LIMIT(QOS_STARVE_LIMIT)
    ) u_net (
      .clk_i, .rst_ni,
      .tile_inj_valid_i(p_inj_valid[pl]), .tile_inj_pkt_i(p_inj_pkt[pl]), .tile_inj_ready_o(p_inj_ready[pl]),
      .tile_ej_valid_o(p_ej_valid[pl]),   .tile_ej_pkt_o(p_ej_pkt[pl]),   .tile_ej_ready_i(p_ej_ready[pl]),
      .perf_link_stall_o(p_lstall[pl]), .perf_hol_block_o(p_hol[pl]), .noc_idle_o(p_idle[pl]),
      .err_drop_o(p_err_drop[pl]), .err_drop_head_o(p_err_drop_head[pl]), .err_cause_o(p_err_cause[pl]),
      .perf_in_fire_o(p_in_fire[pl]), .perf_in_head_o(p_in_head[pl]), .perf_out_fire_o(p_out_fire[pl]),
      .perf_out_head_o(p_out_head[pl]), .perf_sa_req_o(p_sa_req[pl]), .perf_sa_gnt_o(p_sa_gnt[pl]),
      .perf_buf_count_o(p_buf[pl]), .perf_out_pkt_o(p_out_pkt[pl])
    );
  end

  if (SEPARATE_RSP) begin : g_sep
    assign p_inj_valid[0] = req_in_valid_i;   assign p_inj_pkt[0] = req_in_pkt_i;   assign req_in_ready_o = p_inj_ready[0];
    assign p_inj_valid[1] = rsp_in_valid_i;   assign p_inj_pkt[1] = rsp_in_pkt_i;   assign rsp_in_ready_o = p_inj_ready[1];
    assign req_out_valid_o = p_ej_valid[0];   assign req_out_pkt_o = p_ej_pkt[0];   assign p_ej_ready[0] = req_out_ready_i;
    assign rsp_out_valid_o = p_ej_valid[1];   assign rsp_out_pkt_o = p_ej_pkt[1];   assign p_ej_ready[1] = rsp_out_ready_i;
    assign noc_idle_o = &p_idle;
    assign err_drop_o = p_err_drop[0] | p_err_drop[1];
  end else begin : g_shared
    // ---- injection merge: packet-granular, selection held while stalled ----
    for (genvar t = 0; t < NT; t++) begin : g_tile
      logic sel, sel_q, hold_q, lock_q, lock_sel_q, rr_q;
      logic v_sel, r_sel;
      always_comb begin
        if (hold_q)      sel = sel_q;
        else if (lock_q) sel = lock_sel_q;
        else if (req_in_valid_i[t] && rsp_in_valid_i[t]) sel = ~rr_q;       // alternate
        else             sel = rsp_in_valid_i[t];
      end
      assign p_inj_valid[0][t] = sel ? rsp_in_valid_i[t] : req_in_valid_i[t];
      assign p_inj_pkt[0][t]   = sel ? rsp_in_pkt_i[t]   : req_in_pkt_i[t];
      assign req_in_ready_o[t] = !sel && p_inj_ready[0][t];
      assign rsp_in_ready_o[t] =  sel && p_inj_ready[0][t];
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          sel_q <= 1'b0; hold_q <= 1'b0; lock_q <= 1'b0; lock_sel_q <= 1'b0; rr_q <= 1'b0;
        end else begin
          sel_q  <= sel;
          hold_q <= p_inj_valid[0][t] && !p_inj_ready[0][t];
          if (p_inj_valid[0][t] && p_inj_ready[0][t]) begin
            rr_q <= sel;
            if (!p_inj_pkt[0][t].eop) begin lock_q <= 1'b1; lock_sel_q <= sel; end
            else                      lock_q <= 1'b0;
          end
        end
      end
      // ---- ejection demux by class ----
      wire ej_is_rsp = sf_noc_is_rsp(p_ej_pkt[0][t].pclass);
      assign req_out_valid_o[t] = p_ej_valid[0][t] && !ej_is_rsp;
      assign rsp_out_valid_o[t] = p_ej_valid[0][t] &&  ej_is_rsp;
      assign req_out_pkt_o[t]   = p_ej_pkt[0][t];
      assign rsp_out_pkt_o[t]   = p_ej_pkt[0][t];
      assign p_ej_ready[0][t]   = ej_is_rsp ? rsp_out_ready_i[t] : req_out_ready_i[t];
    end
    assign noc_idle_o = p_idle[0];
    assign err_drop_o = p_err_drop[0];
  end

  // ---------------------------------------------------------------------------
  // counters
  // ---------------------------------------------------------------------------
  logic [NPL-1:0][31:0] cnt_data;
  logic [NPL-1:0]       cnt_ovf;
  if (CNT_EN) begin : g_cnt
    for (genvar pl = 0; pl < NPL; pl++) begin : g_pl
      logic        [NT-1:0] c_inj_valid, c_inj_ready, c_ej_valid, c_ej_ready;
      assign c_inj_valid = p_inj_valid[pl];
      assign c_inj_ready = p_inj_ready[pl];
      assign c_ej_valid  = p_ej_valid[pl];
      assign c_ej_ready  = p_ej_ready[pl];
      sf_noc_traffic_counters #(
        .MESH_X(MESH_X), .MESH_Y(MESH_Y), .BUF_DEPTH(BUF_DEPTH), .LAT_IDX_W(LAT_IDX_W), .LAT_EN(1'b1)
      ) u_cnt (
        .clk_i, .rst_ni, .ctrl_clear_i, .ctrl_freeze_i,
        .inj_valid_i(c_inj_valid), .inj_ready_i(c_inj_ready), .inj_pkt_i(p_inj_pkt[pl]),
        .ej_valid_i(c_ej_valid),   .ej_ready_i(c_ej_ready),   .ej_pkt_i(p_ej_pkt[pl]),
        .in_fire_i(p_in_fire[pl]), .in_head_i(p_in_head[pl]), .out_fire_i(p_out_fire[pl]),
        .out_head_i(p_out_head[pl]), .link_stall_i(p_lstall[pl]), .hol_block_i(p_hol[pl]),
        .sa_req_i(p_sa_req[pl]), .sa_gnt_i(p_sa_gnt[pl]), .buf_count_i(p_buf[pl]), .out_pkt_i(p_out_pkt[pl]),
        .err_drop_i(p_err_drop[pl]), .err_drop_head_i(p_err_drop_head[pl]), .err_cause_i(p_err_cause[pl]),
        .rd_addr_i(rd_addr_i), .rd_data_o(cnt_data[pl]), .ovf_o(cnt_ovf[pl])
      );
    end
    assign rd_data_o = (SEPARATE_RSP && rd_plane_i) ? cnt_data[NPL-1] : cnt_data[0];
    assign ovf_o     = |cnt_ovf;
  end else begin : g_nocnt
    assign cnt_data  = '0;
    assign cnt_ovf   = '0;
    assign rd_data_o = 32'hDEAD_C0DE;
    assign ovf_o     = 1'b0;
  end

endmodule : sf_noc_fabric
