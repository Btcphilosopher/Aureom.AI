// =============================================================================
//  sf_noc_fifo : small synchronous FIFO, first-word-fall-through, registered flags
//  Used by the network interfaces. DEPTH need not be a power of two (>= 2).
//  Overflow / underflow are simulation assertions; the interfaces are built so
//  that neither can occur (credit reservation).
// =============================================================================
module sf_noc_fifo #(
  parameter type         T     = logic [7:0],
  parameter int unsigned DEPTH = 4
) (
  input  logic                        clk_i,
  input  logic                        rst_ni,
  input  logic                        push_i,
  input  T                            data_i,
  output logic                        full_o,
  input  logic                        pop_i,
  output T                            data_o,
  output logic                        empty_o,
  output logic [$clog2(DEPTH+1)-1:0]  count_o
);
  localparam int unsigned PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int unsigned CW = $clog2(DEPTH + 1);

  if (DEPTH < 2) begin : g_chk
    $error("sf_noc_fifo: DEPTH >= 2 required");
  end

  T               mem [DEPTH];
  logic [PW-1:0]  wr_q, rd_q;
  logic [CW-1:0]  cnt_q, cnt_d;
  logic           full_q, empty_q;

  function automatic logic [PW-1:0] inc(input logic [PW-1:0] p);
    return (p == PW'(DEPTH - 1)) ? '0 : (p + PW'(1));
  endfunction

  always_comb begin
    unique case ({push_i, pop_i})
      2'b10:   cnt_d = cnt_q + CW'(1);
      2'b01:   cnt_d = cnt_q - CW'(1);
      default: cnt_d = cnt_q;
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      wr_q <= '0; rd_q <= '0; cnt_q <= '0; full_q <= 1'b0; empty_q <= 1'b1;
    end else begin
      if (push_i) wr_q <= inc(wr_q);
      if (pop_i)  rd_q <= inc(rd_q);
      cnt_q   <= cnt_d;
      full_q  <= (cnt_d == CW'(DEPTH));
      empty_q <= (cnt_d == '0);
    end
  end

  always_ff @(posedge clk_i) begin
    if (push_i) mem[wr_q] <= data_i;
  end

  assign data_o  = mem[rd_q];
  assign full_o  = full_q;
  assign empty_o = empty_q;
  assign count_o = cnt_q;

`ifndef SYNTHESIS
  a_no_overflow:  assert property (@(posedge clk_i) disable iff (!rst_ni) push_i |-> (cnt_q < CW'(DEPTH)))
    else $error("sf_noc_fifo: overflow");
  a_no_underflow: assert property (@(posedge clk_i) disable iff (!rst_ni) pop_i |-> !empty_q)
    else $error("sf_noc_fifo: underflow");
`endif
endmodule : sf_noc_fifo
