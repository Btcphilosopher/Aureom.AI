// =============================================================================
//  SF-NOC packet contract, version 1          (included inside silicaflux_pkg)
//  File : silicaflux_noc_section.svh
//
//  WHY THIS FILE EXISTS
//    noc_interconnect.sf does `import silicaflux_pkg::*` and defaults its
//    `pkt_t` parameter to `noc_packet_t`, but the only silicaflux_pkg in the
//    SilicaFlux2.5 tree ("silicaflux_pkg (1).sf", memory-subsystem section)
//    does not define it, so the NoC cannot be compiled from the repository as
//    shipped. This section supplies it. The memory section is reused untouched:
//    transaction tag, exception/status code, address and strobe widths come
//    straight from it, so memory packets map onto NoC packets without
//    re-encoding.
//
//  CONTRACT RULES
//    1. One noc_packet_t is one FLIT on a link. A packet is one or more flits.
//       Single-flit packets (the default) have sop = eop = 1.
//    2. The fabric inspects ONLY: valid, sop, eop, dst_id, src_id (checked at
//       injection), qos (MSB) and pclass (legality/validation at injection).
//       Every other field is carried unmodified and bit-exact.
//    3. dst_id / src_id are COORDINATE encoded {y, x} (x in the LSBs,
//       X_W = clog2(MESH_X) bits). They equal the linear tile index
//       t = y*MESH_X + x ONLY when MESH_X is a power of two. Use
//       sf_noc_id() / sf_noc_tile_index() to convert; never assume.
//    4. Requests (pclass RD_REQ, WR_REQ, MSG) and responses (RD_RSP, WR_RSP)
//       are separated onto different networks by sf_noc_vnet_of(); the fabric
//       must never carry both on one network when end-points can block a
//       request on the ability to emit a response (see docs/DEADLOCK.md).
//    5. A response copies txn_id, addr, xfer from its request and swaps
//       src_id/dst_id (sf_noc_make_rsp). txn_id values must be unique per
//       (source tile) while outstanding.
//    6. Changing any field width or order is a CONTRACT CHANGE: bump
//       SF_NOC_PKT_VERSION and re-check every producer/consumer listed in
//       docs/PACKET_SPEC.md section 6.
// =============================================================================

  localparam int unsigned SF_NOC_PKT_VERSION = 1;

  localparam int unsigned SF_NOC_ID_W   = 4;                    // {y[1:0],x[1:0]}: meshes up to 4x4
  localparam int unsigned SF_NOC_QOS_W  = 2;                    // MSB = high-priority class
  localparam int unsigned SF_NOC_DATA_W = SF_VLEN;              // 128: one vector line per flit
  localparam int unsigned SF_NOC_BE_W   = SF_NOC_DATA_W / 8;    // 16 byte enables

  typedef logic [SF_NOC_ID_W-1:0]   sf_noc_id_t;
  typedef logic [SF_NOC_QOS_W-1:0]  sf_noc_qos_t;
  typedef logic [SF_NOC_DATA_W-1:0] sf_noc_data_t;
  typedef logic [SF_NOC_BE_W-1:0]   sf_noc_be_t;

  // ---------------------------------------------------------------------------
  // Packet class
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    SF_NOC_RD_REQ = 3'd0,    // read request                (request network)
    SF_NOC_WR_REQ = 3'd1,    // write request, data + be    (request network)
    SF_NOC_RD_RSP = 3'd2,    // read response, data         (response network)
    SF_NOC_WR_RSP = 3'd3,    // write completion, no data   (response network)
    SF_NOC_MSG    = 3'd4,    // posted one-way message      (request network)
    SF_NOC_RSVD5  = 3'd5,    // reserved: illegal, rejected at injection
    SF_NOC_RSVD6  = 3'd6,
    SF_NOC_RSVD7  = 3'd7
  } sf_noc_class_e;

  // ---------------------------------------------------------------------------
  // Transfer kind: selects the memory-side port and carries command metadata
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    SF_NOC_X_SCALAR = 2'd0,  // 32-bit word  -> memory_controller scalar port
    SF_NOC_X_VECTOR = 2'd1,  // 128-bit line -> memory_controller vector port
    SF_NOC_X_BURST  = 2'd2,  // DMA/tensor stream beat -> burst port
    SF_NOC_X_CTRL   = 2'd3   // control / status register access
  } sf_noc_xfer_e;

  // ---------------------------------------------------------------------------
  // The packet (one flit). MSB first.            width = 207 bits at DATA_W=128
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic           valid;     // packet valid qualifier (checked on head/sop flits)
    logic           sop;       // first flit of a packet
    logic           eop;       // last flit of a packet
    sf_noc_class_e  pclass;    // see above
    sf_noc_qos_t    qos;       // [MSB] = high-priority class
    sf_noc_id_t     dst_id;    // destination tile, coordinate encoded
    sf_noc_id_t     src_id;    // source tile, coordinate encoded
    sf_mem_tag_t    txn_id;    // transaction ID (silicaflux_pkg memory tag, 8b)
    sf_mem_exc_e    status;    // response status (silicaflux_pkg exception code)
    sf_noc_xfer_e   xfer;      // transfer kind
    sf_mem_hint_e   hint;      // memory hint, carried transparently
    sf_paddr_t      addr;      // physical address / register offset
    sf_noc_be_t     be;        // byte enables (writes, read data)
    sf_noc_data_t   data;      // payload
  } noc_packet_t;

  // ---------------------------------------------------------------------------
  // Helpers (pure functions, synthesizable)
  // ---------------------------------------------------------------------------
  function automatic logic sf_noc_class_legal(input sf_noc_class_e c);
    return (c == SF_NOC_RD_REQ) || (c == SF_NOC_WR_REQ) || (c == SF_NOC_RD_RSP) ||
           (c == SF_NOC_WR_RSP) || (c == SF_NOC_MSG);
  endfunction

  function automatic logic sf_noc_is_rsp(input sf_noc_class_e c);
    return (c == SF_NOC_RD_RSP) || (c == SF_NOC_WR_RSP);
  endfunction

  // Virtual-network / plane selector: 0 = request network, 1 = response network
  function automatic logic sf_noc_vnet_of(input sf_noc_class_e c);
    return sf_noc_is_rsp(c);
  endfunction

  // Coordinate-encoded node ID for (x,y) in a mesh_x-wide mesh
  function automatic sf_noc_id_t sf_noc_id(input int unsigned x, input int unsigned y,
                                           input int unsigned mesh_x);
    int unsigned xw;
    xw = (mesh_x > 1) ? $clog2(mesh_x) : 1;
    return sf_noc_id_t'((y << xw) | x);
  endfunction

  // Linear tile index (port index on noc_interconnect) for a coordinate ID.
  function automatic int unsigned sf_noc_tile_index(input sf_noc_id_t id,
                                                    input int unsigned mesh_x);
    int unsigned xw;
    xw = (mesh_x > 1) ? $clog2(mesh_x) : 1;
    return (32'(id) >> xw) * mesh_x + (32'(id) & ((32'd1 << xw) - 32'd1));
  endfunction

  // Payload bytes carried by a flit (data-bearing classes only)
  function automatic int unsigned sf_noc_payload_bytes(input noc_packet_t p);
    int unsigned n;
    n = 0;
    if (p.valid && (p.pclass == SF_NOC_WR_REQ || p.pclass == SF_NOC_RD_RSP ||
                    p.pclass == SF_NOC_MSG)) begin
      for (int i = 0; i < SF_NOC_BE_W; i++) n += int'(p.be[i]);
    end
    return n;
  endfunction

  // Response for a request: swap src/dst, keep txn_id/addr/xfer/hint/qos
  function automatic noc_packet_t sf_noc_make_rsp(input noc_packet_t req,
                                                  input sf_noc_data_t rdata,
                                                  input sf_noc_be_t   rbe,
                                                  input sf_mem_exc_e  st);
    noc_packet_t r;
    r        = '0;
    r.valid  = 1'b1;
    r.sop    = 1'b1;
    r.eop    = 1'b1;
    r.pclass = (req.pclass == SF_NOC_RD_REQ) ? SF_NOC_RD_RSP : SF_NOC_WR_RSP;
    r.qos    = req.qos;
    r.dst_id = req.src_id;
    r.src_id = req.dst_id;
    r.txn_id = req.txn_id;
    r.status = st;
    r.xfer   = req.xfer;
    r.hint   = req.hint;
    r.addr   = req.addr;
    r.be     = (req.pclass == SF_NOC_RD_REQ) ? rbe : '0;
    r.data   = (req.pclass == SF_NOC_RD_REQ) ? rdata : '0;
    return r;
  endfunction
