// =============================================================================
//  sf_noc_traffic_counters : NoC performance instrumentation
//
//  NOTE ON PROVENANCE: the brief refers to a "supplied sf_noc_traffic_counters.sv
//  starter". No file of that name exists anywhere in the repository (searched
//  every .sf/.sv file and every archive), so this block is written from scratch
//  under that name. Nothing was integrated from an unavailable source.
//
//  WHAT IT MEASURES (all event counts, saturating 32-bit, sticky overflow flag)
//    per router, per port (port order 0=L 1=N 2=E 3=S 4=W)
//      FLITS_IN / PKTS_IN        flits / head flits accepted into the input buffer
//      FLITS_OUT / PKTS_OUT      flits / head flits transferred on the output
//      PAYLOAD_BYTES_OUT         sum of valid payload bytes on that output
//      RAW_BYTES_OUT             flits * flit width in bytes (physical link bytes)
//      LINK_STALL                cycles the output register held a flit that
//                                the sink did not accept (link stall)
//      ARB_BLOCKED               cycles >=1 flit requested this output and none
//                                was granted (output blocked by back-pressure)
//      ARB_LOSE                  sum over cycles of (requesters - grants):
//                                flits that lost arbitration (contention)
//      HOL_BLOCK                 cycles a valid input-buffer head was not served
//      OCC_SUM / OCC_MAX         integral and maximum of input buffer occupancy
//    per tile
//      INJ_FLITS/INJ_PKTS/INJ_STALL, EJ_FLITS/EJ_PKTS/EJ_STALL, DROP_*,
//      DST_INFLIGHT_{CUR,MAX,SUM}: flits in the network addressed to the tile
//      (destination congestion), DST_CONG_CYCLES: cycles with >= DST_CONG_THR
//    latency (only where correlatable, see LATENCY RULES)
//      network latency   inject-accept -> eject of the same (src,txn_id)
//      round trip        request inject -> response eject at the requester
//      each: count, sum, min, max, 8 log2 histogram bins
//
//  PACKETS vs FLITS: every *_PKTS counter counts head (sop) flits, every
//  *_FLITS counter counts all flits. They differ only for multi-flit packets.
//
//  LATENCY RULES (documented assumption, checked by two counters)
//    A latency sample needs injection and ejection to be matched. Matching key
//    is (source tile, txn_id[LAT_IDX_W-1:0]). It is exact if every flit in
//    flight from one source has a distinct key. If a key is reused while its
//    previous entry is still pending, LAT_COLLIDE increments and the older
//    timestamp is overwritten; an ejection with no pending entry increments
//    LAT_UNMATCHED. Both must read 0 for the latency numbers to be trusted.
//    Only head flits (sop) of packets are timed.
//
//  CONTROL
//    ctrl_clear_i   : synchronous clear of every counter (timestamps survive)
//    ctrl_freeze_i  : counters hold their values (events are NOT recorded
//                     meanwhile; FROZEN_CYCLES counts the cycles missed)
//
//  READ INTERFACE (combinational read of 32-bit registers, see docs/COUNTERS.md)
//    rd_addr_i[15:12] group   0 global, 1 router/port, 2 tile, 3 latency
//    group 1: addr = 0x1000 | metric<<8 | router<<3 | port
//    group 2: addr = 0x2000 | metric<<8 | tile
//    group 3: addr = 0x3000 | kind<<8 | field          (kind 0 network, 1 round trip)
//    group 0: 0x0000 ID/version, 0x0001 config, 0x0002 CYCLES, 0x0003 FROZEN_CYCLES,
//             0x0004 STATUS {ovf}, 0x0005 LAT_COLLIDE, 0x0006 LAT_UNMATCHED
//    Reads of unmapped addresses return 32'hDEAD_C0DE.
// =============================================================================
module sf_noc_traffic_counters
  import silicaflux_pkg::*;
#(
  parameter int unsigned MESH_X      = 2,
  parameter int unsigned MESH_Y      = 2,
  parameter int unsigned BUF_DEPTH   = 4,
  parameter int unsigned LAT_IDX_W   = 4,    // 2**LAT_IDX_W timestamps per source tile
  parameter bit          LAT_EN      = 1'b1,
  parameter int unsigned DST_CONG_THR = 4,   // DST_CONG_CYCLES threshold (flits in flight to a tile)
  localparam int unsigned NT         = MESH_X * MESH_Y,
  localparam int unsigned NP         = 5,
  localparam int unsigned BW         = $clog2(BUF_DEPTH + 1)
) (
  input  logic                              clk_i,
  input  logic                              rst_ni,

  input  logic                              ctrl_clear_i,
  input  logic                              ctrl_freeze_i,

  // tile-side taps (the same wires the tiles drive/see)
  input  logic        [NT-1:0]              inj_valid_i,
  input  logic        [NT-1:0]              inj_ready_i,
  input  noc_packet_t [NT-1:0]              inj_pkt_i,
  input  logic        [NT-1:0]              ej_valid_i,
  input  logic        [NT-1:0]              ej_ready_i,
  input  noc_packet_t [NT-1:0]              ej_pkt_i,

  // router taps, port order {W,S,E,N,L} = bits [4:0] (index 0 = local)
  input  logic        [NT-1:0][NP-1:0]      in_fire_i,
  input  logic        [NT-1:0][NP-1:0]      in_head_i,
  input  logic        [NT-1:0][NP-1:0]      out_fire_i,
  input  logic        [NT-1:0][NP-1:0]      out_head_i,
  input  logic        [NT-1:0][NP-1:0]      link_stall_i,
  input  logic        [NT-1:0][NP-1:0]      hol_block_i,
  input  logic        [NT-1:0][NP-1:0][NP-1:0] sa_req_i,     // [router][out][in]
  input  logic        [NT-1:0][NP-1:0][NP-1:0] sa_gnt_i,
  input  logic        [NT-1:0][NP-1:0][BW-1:0] buf_count_i,
  input  noc_packet_t [NT-1:0][NP-1:0]      out_pkt_i,
  input  logic        [NT-1:0]              err_drop_i,
  input  logic        [NT-1:0]              err_drop_head_i,
  input  logic        [NT-1:0][2:0]         err_cause_i,

  // read port
  input  logic        [15:0]                rd_addr_i,
  output logic        [31:0]                rd_data_o,
  output logic                              ovf_o
);

  localparam int unsigned CW        = 32;
  localparam int unsigned PKT_BYTES = ($bits(noc_packet_t) + 7) / 8;
  localparam int unsigned XW        = (MESH_X > 1) ? $clog2(MESH_X) : 1;
  localparam int unsigned LAT_N     = 1 << LAT_IDX_W;
  localparam int unsigned NHIST     = 8;
  localparam logic [31:0] VERSION   = {16'h5F0C, 8'h01, 8'h01};   // magic, block rev, packet contract version

  // metric ids
  localparam int unsigned M_FLITS_IN  = 0;
  localparam int unsigned M_PKTS_IN   = 1;
  localparam int unsigned M_FLITS_OUT = 2;
  localparam int unsigned M_PKTS_OUT  = 3;
  localparam int unsigned M_PAY_OUT   = 4;
  localparam int unsigned M_RAW_OUT   = 5;
  localparam int unsigned M_LINK_STALL= 6;
  localparam int unsigned M_ARB_BLOCK = 7;
  localparam int unsigned M_ARB_LOSE  = 8;
  localparam int unsigned M_HOL       = 9;
  localparam int unsigned M_OCC_SUM   = 10;
  localparam int unsigned M_OCC_MAX   = 11;
  localparam int unsigned NM_RP       = 12;

  localparam int unsigned T_INJ_FLITS = 0;
  localparam int unsigned T_INJ_PKTS  = 1;
  localparam int unsigned T_INJ_STALL = 2;
  localparam int unsigned T_EJ_FLITS  = 3;
  localparam int unsigned T_EJ_PKTS   = 4;
  localparam int unsigned T_EJ_STALL  = 5;
  localparam int unsigned T_DROP_FLITS= 6;
  localparam int unsigned T_DROP_PKTS = 7;
  localparam int unsigned T_DROP_DST  = 8;
  localparam int unsigned T_DROP_CLS  = 9;
  localparam int unsigned T_DROP_SRC  = 10;
  localparam int unsigned T_DST_CUR   = 11;
  localparam int unsigned T_DST_MAX   = 12;
  localparam int unsigned T_DST_SUM   = 13;
  localparam int unsigned T_DST_CONG  = 14;
  localparam int unsigned NM_T        = 15;

  // ---------------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------------
  logic ovf_q;

  function automatic logic [CW-1:0] sat_add(input logic [CW-1:0] a, input logic [CW-1:0] b);
    logic [CW:0] s;
    s = {1'b0, a} + {1'b0, b};
    return s[CW] ? {CW{1'b1}} : s[CW-1:0];
  endfunction

  function automatic logic add_ovf(input logic [CW-1:0] a, input logic [CW-1:0] b);
    logic [CW:0] s;
    s = {1'b0, a} + {1'b0, b};
    return s[CW];
  endfunction

  function automatic int unsigned popc(input logic [NP-1:0] v);
    int unsigned n;
    n = 0;
    for (int i = 0; i < NP; i++) n += int'(v[i]);
    return n;
  endfunction

  function automatic int unsigned tile_of(input sf_noc_id_t id);
    return sf_noc_tile_index(id, MESH_X);
  endfunction

  function automatic int unsigned hist_bin(input logic [31:0] lat);
    int unsigned b;
    b = 0;
    for (int k = 1; k < NHIST; k++) if (lat >= (32'd1 << k)) b = k;
    return b;
  endfunction

  // free-running timestamp (NOT stopped by freeze or clear, so pending latency
  // entries stay valid) and the measurement-window cycle counter
  logic [31:0] ts_q;
  logic [CW-1:0] cycles_q, frozen_q;

  // ---------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------
  // packed state (indexing identical to unpacked; avoids simulator limits on
  // non-blocking assignment to unpacked arrays inside loops)
  logic [NM_RP-1:0][NT-1:0][NP-1:0][CW-1:0] rp;
  logic [NM_T-1:0][NT-1:0][CW-1:0]          tl;
  logic [1:0][CW-1:0]                       lat_cnt;
  logic [1:0][CW-1:0]                       lat_sum;
  logic [1:0][CW-1:0]                       lat_min;
  logic [1:0][CW-1:0]                       lat_max;
  logic [1:0][NHIST-1:0][CW-1:0]            lat_hist;
  logic [CW-1:0]                            lat_collide, lat_unmatched;

  // latency timestamp tables: net = per injecting tile, rt = per requesting tile
  logic [NT-1:0][LAT_N-1:0][31:0] ts_net;
  logic [NT-1:0][LAT_N-1:0]       ts_net_v;
  logic [NT-1:0][LAT_N-1:0][31:0] ts_rt;
  logic [NT-1:0][LAT_N-1:0]       ts_rt_v;

  wire frozen = ctrl_freeze_i;

  // ---------------------------------------------------------------------------
  // per-router / per-port counters
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin : p_rp
    int unsigned   req_cnt, gnt_cnt;
    if (!rst_ni) begin
      for (int m = 0; m < NM_RP; m++)
        for (int r = 0; r < NT; r++)
          for (int p = 0; p < NP; p++) rp[m][r][p] <= '0;
      ovf_q <= 1'b0;
    end else if (ctrl_clear_i) begin
      for (int m = 0; m < NM_RP; m++)
        for (int r = 0; r < NT; r++)
          for (int p = 0; p < NP; p++) rp[m][r][p] <= '0;
      ovf_q <= 1'b0;
    end else if (!frozen) begin
      for (int r = 0; r < NT; r++) begin
        for (int p = 0; p < NP; p++) begin
          req_cnt = popc(sa_req_i[r][p]);
          gnt_cnt = popc(sa_gnt_i[r][p]);

          // input-indexed metrics
          if (in_fire_i[r][p])  rp[M_FLITS_IN][r][p] <= sat_add(rp[M_FLITS_IN][r][p], 1);
          if (in_head_i[r][p])  rp[M_PKTS_IN][r][p]  <= sat_add(rp[M_PKTS_IN][r][p], 1);
          if (hol_block_i[r][p]) rp[M_HOL][r][p]     <= sat_add(rp[M_HOL][r][p], 1);
          rp[M_OCC_SUM][r][p] <= sat_add(rp[M_OCC_SUM][r][p], CW'(buf_count_i[r][p]));
          if (CW'(buf_count_i[r][p]) > rp[M_OCC_MAX][r][p]) rp[M_OCC_MAX][r][p] <= CW'(buf_count_i[r][p]);

          // output-indexed metrics
          if (out_fire_i[r][p]) begin
            rp[M_FLITS_OUT][r][p] <= sat_add(rp[M_FLITS_OUT][r][p], 1);
            rp[M_RAW_OUT][r][p]   <= sat_add(rp[M_RAW_OUT][r][p], CW'(PKT_BYTES));
            rp[M_PAY_OUT][r][p]   <= sat_add(rp[M_PAY_OUT][r][p], CW'(sf_noc_payload_bytes(out_pkt_i[r][p])));
          end
          if (out_head_i[r][p])  rp[M_PKTS_OUT][r][p]  <= sat_add(rp[M_PKTS_OUT][r][p], 1);
          if (link_stall_i[r][p]) rp[M_LINK_STALL][r][p] <= sat_add(rp[M_LINK_STALL][r][p], 1);
          if (req_cnt > 0 && gnt_cnt == 0) rp[M_ARB_BLOCK][r][p] <= sat_add(rp[M_ARB_BLOCK][r][p], 1);
          if (req_cnt > gnt_cnt) rp[M_ARB_LOSE][r][p] <= sat_add(rp[M_ARB_LOSE][r][p], CW'(req_cnt - gnt_cnt));

          // saturation detection (one representative bound per metric class)
          for (int m = 0; m < NM_RP; m++)
            if (rp[m][r][p] == {CW{1'b1}}) ovf_q <= 1'b1;
        end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // per-tile counters, destination congestion
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin : p_tile
    int unsigned inc_dst [NT];
    int unsigned dec_dst [NT];
    int unsigned di;
    logic [CW-1:0] cur;
    if (!rst_ni) begin
      for (int m = 0; m < NM_T; m++) for (int t = 0; t < NT; t++) tl[m][t] <= '0;
    end else if (ctrl_clear_i) begin
      for (int m = 0; m < NM_T; m++)
        for (int t = 0; t < NT; t++) begin
          // clearing the live in-flight count would corrupt it: keep CUR, restart statistics
          if (m == T_DST_CUR) tl[m][t] <= tl[m][t];
          else if (m == T_DST_MAX) tl[m][t] <= tl[T_DST_CUR][t];
          else tl[m][t] <= '0;
        end
    end else begin
      // in-flight bookkeeping must run even while frozen, or it would drift
      for (int t = 0; t < NT; t++) begin inc_dst[t] = 0; dec_dst[t] = 0; end
      for (int s = 0; s < NT; s++)
        if (in_fire_i[s][0] && inj_valid_i[s] && inj_ready_i[s]) begin
          // a flit accepted into the fabric counts toward its destination
          // (flits rejected at ingress never enter, so they are excluded)
          di = tile_of(inj_pkt_i[s].dst_id);
          if (di < NT) inc_dst[di] = inc_dst[di] + 1;
        end
      for (int t = 0; t < NT; t++) if (ej_valid_i[t] && ej_ready_i[t]) dec_dst[t] = dec_dst[t] + 1;

      for (int t = 0; t < NT; t++) begin
        cur = tl[T_DST_CUR][t] + CW'(inc_dst[t]) - CW'(dec_dst[t]);
        tl[T_DST_CUR][t] <= cur;
        if (!frozen) begin
          if (cur > tl[T_DST_MAX][t]) tl[T_DST_MAX][t] <= cur;
          tl[T_DST_SUM][t] <= sat_add(tl[T_DST_SUM][t], cur);
          if (cur >= CW'(DST_CONG_THR)) tl[T_DST_CONG][t] <= sat_add(tl[T_DST_CONG][t], 1);

          if (inj_valid_i[t] && inj_ready_i[t]) begin
            tl[T_INJ_FLITS][t] <= sat_add(tl[T_INJ_FLITS][t], 1);
            if (inj_pkt_i[t].sop) tl[T_INJ_PKTS][t] <= sat_add(tl[T_INJ_PKTS][t], 1);
          end
          if (inj_valid_i[t] && !inj_ready_i[t]) tl[T_INJ_STALL][t] <= sat_add(tl[T_INJ_STALL][t], 1);
          if (ej_valid_i[t] && ej_ready_i[t]) begin
            tl[T_EJ_FLITS][t] <= sat_add(tl[T_EJ_FLITS][t], 1);
            if (ej_pkt_i[t].sop) tl[T_EJ_PKTS][t] <= sat_add(tl[T_EJ_PKTS][t], 1);
          end
          if (ej_valid_i[t] && !ej_ready_i[t]) tl[T_EJ_STALL][t] <= sat_add(tl[T_EJ_STALL][t], 1);
          if (err_drop_i[t])      tl[T_DROP_FLITS][t] <= sat_add(tl[T_DROP_FLITS][t], 1);
          if (err_drop_head_i[t]) begin
            tl[T_DROP_PKTS][t] <= sat_add(tl[T_DROP_PKTS][t], 1);
            if (err_cause_i[t][0]) tl[T_DROP_DST][t] <= sat_add(tl[T_DROP_DST][t], 1);
            if (err_cause_i[t][1]) tl[T_DROP_CLS][t] <= sat_add(tl[T_DROP_CLS][t], 1);
            if (err_cause_i[t][2]) tl[T_DROP_SRC][t] <= sat_add(tl[T_DROP_SRC][t], 1);
          end
        end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // window cycle counters, free-running timestamp
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin : p_cyc
    if (!rst_ni) begin
      ts_q <= '0; cycles_q <= '0; frozen_q <= '0;
    end else begin
      ts_q <= ts_q + 32'd1;
      if (ctrl_clear_i) begin cycles_q <= '0; frozen_q <= '0; end
      else if (frozen)  frozen_q <= sat_add(frozen_q, 1);
      else              cycles_q <= sat_add(cycles_q, 1);
    end
  end

  // ---------------------------------------------------------------------------
  // latency: timestamp tables and statistics
  // ---------------------------------------------------------------------------
  if (LAT_EN) begin : g_lat
    always_ff @(posedge clk_i or negedge rst_ni) begin : p_lat
      // Several tiles can eject in the same cycle: accumulate every sample of
      // this cycle in blocking temporaries and update each counter ONCE.
      logic [31:0]   lat;
      int unsigned   s, idx, hb;
      int unsigned   n_s    [2];
      logic [CW-1:0] sum_s  [2];
      logic [CW-1:0] min_s  [2];
      logic [CW-1:0] max_s  [2];
      int unsigned   h_s    [2][NHIST];
      int unsigned   n_unm, n_col;
      if (!rst_ni) begin
        ts_net_v <= '0;
        ts_rt_v  <= '0;
        lat_cnt  <= '0; lat_sum <= '0; lat_max <= '0; lat_hist <= '0;
        lat_min  <= {2{ {CW{1'b1}} }};
        lat_collide <= '0; lat_unmatched <= '0;
      end else begin
        for (int c = 0; c < 2; c++) begin
          n_s[c] = 0; sum_s[c] = '0; min_s[c] = {CW{1'b1}}; max_s[c] = '0;
          for (int h = 0; h < NHIST; h++) h_s[c][h] = 0;
        end
        n_unm = 0; n_col = 0;

        // ---- ejection: look up (before injection so a fresh timestamp wins) --
        for (int t = 0; t < NT; t++) begin
          if (ej_valid_i[t] && ej_ready_i[t] && ej_pkt_i[t].sop) begin
            s   = tile_of(ej_pkt_i[t].src_id);
            idx = int'(ej_pkt_i[t].txn_id) & (LAT_N - 1);
            if (s < NT && ts_net_v[s][idx]) begin
              lat = ts_q - ts_net[s][idx];
              ts_net_v[s][idx] <= 1'b0;
              n_s[0] = n_s[0] + 1; sum_s[0] = sum_s[0] + CW'(lat);
              if (CW'(lat) < min_s[0]) min_s[0] = CW'(lat);
              if (CW'(lat) > max_s[0]) max_s[0] = CW'(lat);
              hb = hist_bin(lat);
              h_s[0][hb] = h_s[0][hb] + 1;
            end else begin
              n_unm = n_unm + 1;
            end
            // round trip: a response arriving at the requester it answers
            if ((ej_pkt_i[t].pclass == SF_NOC_RD_RSP || ej_pkt_i[t].pclass == SF_NOC_WR_RSP) && ts_rt_v[t][idx]) begin
              lat = ts_q - ts_rt[t][idx];
              ts_rt_v[t][idx] <= 1'b0;
              n_s[1] = n_s[1] + 1; sum_s[1] = sum_s[1] + CW'(lat);
              if (CW'(lat) < min_s[1]) min_s[1] = CW'(lat);
              if (CW'(lat) > max_s[1]) max_s[1] = CW'(lat);
              hb = hist_bin(lat);
              h_s[1][hb] = h_s[1][hb] + 1;
            end
          end
        end

        // ---- injection: record timestamps (always, even if frozen) ----------
        for (int t = 0; t < NT; t++) begin
          if (inj_valid_i[t] && inj_ready_i[t] && in_fire_i[t][0] && inj_pkt_i[t].sop) begin
            idx = int'(inj_pkt_i[t].txn_id) & (LAT_N - 1);
            if (ts_net_v[t][idx]) n_col = n_col + 1;
            ts_net[t][idx]   <= ts_q;
            ts_net_v[t][idx] <= 1'b1;
            if (inj_pkt_i[t].pclass == SF_NOC_RD_REQ || inj_pkt_i[t].pclass == SF_NOC_WR_REQ) begin
              ts_rt[t][idx]   <= ts_q;
              ts_rt_v[t][idx] <= 1'b1;
            end
          end
        end

        // ---- statistics: one update per counter per cycle -------------------
        if (ctrl_clear_i) begin
          lat_cnt <= '0; lat_sum <= '0; lat_max <= '0; lat_hist <= '0;
          lat_min <= {2{ {CW{1'b1}} }};
          lat_collide <= '0; lat_unmatched <= '0;
        end else if (!frozen) begin
          for (int c = 0; c < 2; c++) begin
            if (n_s[c] != 0) begin
              lat_cnt[c] <= sat_add(lat_cnt[c], CW'(n_s[c]));
              lat_sum[c] <= sat_add(lat_sum[c], sum_s[c]);
              if (min_s[c] < lat_min[c]) lat_min[c] <= min_s[c];
              if (max_s[c] > lat_max[c]) lat_max[c] <= max_s[c];
            end
            for (int h = 0; h < NHIST; h++)
              if (h_s[c][h] != 0) lat_hist[c][h] <= sat_add(lat_hist[c][h], CW'(h_s[c][h]));
          end
          if (n_unm != 0) lat_unmatched <= sat_add(lat_unmatched, CW'(n_unm));
          if (n_col != 0) lat_collide   <= sat_add(lat_collide, CW'(n_col));
        end
      end
    end
  end else begin : g_nolat
    always_comb begin
      for (int c = 0; c < 2; c++) begin
        lat_cnt[c] = '0; lat_sum[c] = '0; lat_min[c] = '0; lat_max[c] = '0;
        for (int h = 0; h < NHIST; h++) lat_hist[c][h] = '0;
      end
      lat_collide = '0; lat_unmatched = '0;
    end
  end

  assign ovf_o = ovf_q;

  // ---------------------------------------------------------------------------
  // read port
  // ---------------------------------------------------------------------------
  always_comb begin
    int unsigned g, m, r, p, t, kind, fld;
    rd_data_o = 32'hDEAD_C0DE;
    g = int'(rd_addr_i[15:12]);
    case (g)
      0: begin
        case (rd_addr_i[7:0])
          8'h00:   rd_data_o = VERSION;
          8'h01:   rd_data_o = {8'(MESH_X), 8'(MESH_Y), 8'(BUF_DEPTH), 4'(LAT_IDX_W), 3'b000, 1'(LAT_EN)};
          8'h02:   rd_data_o = cycles_q;
          8'h03:   rd_data_o = frozen_q;
          8'h04:   rd_data_o = {31'b0, ovf_q};
          8'h05:   rd_data_o = lat_collide;
          8'h06:   rd_data_o = lat_unmatched;
          8'h07:   rd_data_o = 32'(PKT_BYTES);
          default: rd_data_o = 32'hDEAD_C0DE;
        endcase
      end
      1: begin
        m = int'(rd_addr_i[11:8]);
        r = int'(rd_addr_i[7:3]);
        p = int'(rd_addr_i[2:0]);
        if (m < NM_RP && r < NT && p < NP) rd_data_o = rp[m][r][p];
      end
      2: begin
        m = int'(rd_addr_i[11:8]);
        t = int'(rd_addr_i[7:0]);
        if (m < NM_T && t < NT) rd_data_o = tl[m][t];
      end
      3: begin
        kind = int'(rd_addr_i[8]);
        fld  = int'(rd_addr_i[7:0]);
        case (fld)
          0: rd_data_o = lat_cnt[kind];
          1: rd_data_o = lat_sum[kind];
          2: rd_data_o = lat_min[kind];
          3: rd_data_o = lat_max[kind];
          default: if (fld >= 8 && fld < 8 + NHIST) rd_data_o = lat_hist[kind][fld - 8];
        endcase
      end
      default: rd_data_o = 32'hDEAD_C0DE;
    endcase
  end

endmodule : sf_noc_traffic_counters
