// =============================================================================
//  sf_noc_mem_master_ni : requester-side network interface
//
//  The tile-side ports are the SLAVE side of memory_controller, port for port and
//  type for type (scalar / vector / burst with the real silicaflux_pkg
//  sf_*_mem_* types). A tile's LSU or DMA therefore connects to a local
//  memory_controller or, through this adapter, to a remote one without change.
//
//  Request path   scalar / vector requests -> one single-flit noc_packet_t.
//                 Burst read  -> one descriptor flit (RD_REQ, data[7:0]=len_m1).
//                 Burst write -> descriptor flit (sop) + len_m1+1 beat flits (the
//                 last carries eop). The injection port is locked for the
//                 packet, so beats are contiguous (explicit-framing wormhole).
//                 The destination tile is decoded from the address:
//                    tile = (addr - MAP_BASE) >> MAP_SHIFT        (< NUM_TILES)
//                 An address outside every tile aperture is answered locally
//                 with SF_MEM_EXC_RANGE and never enters the fabric.
//  Response path  The NI ALWAYS accepts responses (rsp_ready_o = 1). That is a
//                 guarantee, not a hope: buffer space for every response is
//                 reserved at issue time (credit = free entry in the response
//                 FIFO of that port; a burst read needs len_m1+1 <= BRD_DEPTH
//                 beats of space). Responses therefore never wait on the tile,
//                 which removes the memory-protocol dependency (a request
//                 waiting on a response that cannot drain) that XY routing
//                 alone does not break. See docs/DEADLOCK.md.
//  Ordering       memory_controller returns responses in request order PER PORT.
//                 To keep that contract with several targets, a port may only
//                 have requests outstanding to ONE target at a time (a request
//                 to a different target waits for the port to drain). Within one
//                 target the fabric is in order (single deterministic path, FIFO
//                 buffers, in-order controller).
//  Transaction ID The tile's sf_mem_tag_t travels unchanged as txn_id and comes
//                 back in the response. One burst may be outstanding at a time
//                 (the controller's burst engine is also single-issue).
//  Read/write completion
//                 Every request, store included, gets exactly one completion:
//                 a store completes when the target controller has committed it.
// =============================================================================
module sf_noc_mem_master_ni
  import silicaflux_pkg::*;
#(
  parameter int unsigned NUM_TILES = 4,
  parameter int unsigned MESH_X    = 2,
  parameter sf_noc_id_t  MY_ID     = '0,
  parameter sf_paddr_t   MAP_BASE  = 32'h1000_0000,
  parameter int unsigned MAP_SHIFT = 20,
  parameter int unsigned OUT_S     = 4,      // max outstanding scalar requests
  parameter int unsigned OUT_V     = 4,      // max outstanding vector requests
  parameter int unsigned BRD_DEPTH = 32,     // burst-read buffer = max read burst beats
  parameter sf_noc_qos_t QOS       = '0
) (
  input  logic                    clk_i,
  input  logic                    rst_ni,

  // ---- scalar port (mirrors memory_controller) ----
  input  logic                    scalar_req_valid_i,
  output logic                    scalar_req_ready_o,
  input  sf_scalar_mem_req_t      scalar_req_i,
  output logic                    scalar_rsp_valid_o,
  input  logic                    scalar_rsp_ready_i,
  output sf_scalar_mem_rsp_t      scalar_rsp_o,

  // ---- vector port ----
  input  logic                    vector_req_valid_i,
  output logic                    vector_req_ready_o,
  input  sf_vector_mem_req_t      vector_req_i,
  output logic                    vector_rsp_valid_o,
  input  logic                    vector_rsp_ready_i,
  output sf_vector_mem_rsp_t      vector_rsp_o,

  // ---- burst (DMA / tensor stream) port ----
  input  logic                    burst_req_valid_i,
  output logic                    burst_req_ready_o,
  input  sf_burst_desc_t          burst_req_i,
  input  logic                    burst_wdata_valid_i,
  output logic                    burst_wdata_ready_o,
  input  sf_burst_wbeat_t         burst_wdata_i,
  output logic                    burst_rdata_valid_o,
  input  logic                    burst_rdata_ready_i,
  output sf_burst_rbeat_t         burst_rdata_o,
  output logic                    burst_done_valid_o,
  input  logic                    burst_done_ready_i,
  output sf_burst_done_t          burst_done_o,

  // ---- NoC side ----
  output logic                    req_valid_o,
  input  logic                    req_ready_i,
  output noc_packet_t             req_pkt_o,
  input  logic                    rsp_valid_i,
  output logic                    rsp_ready_o,
  input  noc_packet_t             rsp_pkt_i,

  output logic                    err_decode_o     // pulse: request completed locally with RANGE
);

  localparam int unsigned SF_D = (OUT_S < 2) ? 2 : OUT_S;
  localparam int unsigned VF_D = (OUT_V < 2) ? 2 : OUT_V;
  localparam int unsigned BF_D = (BRD_DEPTH < 2) ? 2 : BRD_DEPTH;
  localparam int unsigned CS_W = $clog2(SF_D + 1);
  localparam int unsigned CV_W = $clog2(VF_D + 1);

  // --------------------------------------------------------------------------
  // helpers
  // --------------------------------------------------------------------------
  function automatic logic dec_ok(input sf_paddr_t a);
    sf_paddr_t off;
    off = a - MAP_BASE;
    return (a >= MAP_BASE) && ((off >> MAP_SHIFT) < NUM_TILES);
  endfunction

  function automatic sf_noc_id_t dec_dst(input sf_paddr_t a);
    sf_paddr_t off;
    int unsigned t;
    off = a - MAP_BASE;
    t   = int'(off >> MAP_SHIFT);
    return sf_noc_id(t % MESH_X, t / MESH_X, MESH_X);
  endfunction

  function automatic noc_packet_t base_pkt(input sf_noc_id_t dst, input sf_noc_class_e c,
                                           input sf_noc_xfer_e x, input sf_mem_tag_t tag,
                                           input sf_mem_hint_e h, input sf_paddr_t a);
    noc_packet_t p;
    p        = '0;
    p.valid  = 1'b1;
    p.sop    = 1'b1;
    p.eop    = 1'b1;
    p.pclass = c;
    p.qos    = QOS;
    p.dst_id = dst;
    p.src_id = MY_ID;
    p.txn_id = tag;
    p.xfer   = x;
    p.hint   = h;
    p.addr   = a;
    return p;
  endfunction

  // --------------------------------------------------------------------------
  // outstanding tracking (credit = response buffer space)
  // --------------------------------------------------------------------------
  logic [CS_W-1:0] s_out_q;  sf_noc_id_t s_tgt_q;  logic s_err_q;  sf_scalar_mem_rsp_t s_err_rsp_q;
  logic [CV_W-1:0] v_out_q;  sf_noc_id_t v_tgt_q;  logic v_err_q;  sf_vector_mem_rsp_t v_err_rsp_q;
  logic            b_busy_q;                  // a burst is outstanding (desc accepted .. done delivered)
  logic            bd_valid_q;
  sf_burst_done_t  bd_q;

  // --------------------------------------------------------------------------
  // request candidates
  // --------------------------------------------------------------------------
  logic        s_ok, v_ok, b_ok;
  logic        s_can, v_can, b_can, s_lerr, v_lerr, b_lerr;
  sf_noc_id_t  s_dst, v_dst, b_dst;
  noc_packet_t s_pkt, v_pkt, b_pkt;

  assign s_ok  = dec_ok(scalar_req_i.addr);
  assign v_ok  = dec_ok(vector_req_i.addr);
  assign b_ok  = dec_ok(burst_req_i.base);
  assign s_dst = dec_dst(scalar_req_i.addr);
  assign v_dst = dec_dst(vector_req_i.addr);
  assign b_dst = dec_dst(burst_req_i.base);

  wire b_len_ok = (burst_req_i.op == SF_MEM_STORE) || (int'(burst_req_i.len_m1) < BRD_DEPTH);

  // may issue to the fabric: valid target, credit available, single-target-per-port rule
  assign s_can  = scalar_req_valid_i && !s_err_q && s_ok &&
                  (s_out_q < CS_W'(OUT_S)) && ((s_out_q == '0) || (s_tgt_q == s_dst));
  assign v_can  = vector_req_valid_i && !v_err_q && v_ok &&
                  (v_out_q < CV_W'(OUT_V)) && ((v_out_q == '0) || (v_tgt_q == v_dst));
  assign b_can  = burst_req_valid_i && !b_busy_q && !bd_valid_q && b_ok && b_len_ok;
  // complete locally with an error (only when nothing is outstanding on the port: keeps order)
  assign s_lerr = scalar_req_valid_i && !s_err_q && !s_ok && (s_out_q == '0);
  assign v_lerr = vector_req_valid_i && !v_err_q && !v_ok && (v_out_q == '0);
  assign b_lerr = burst_req_valid_i && !b_busy_q && !bd_valid_q && (!b_ok || !b_len_ok);

  always_comb begin
    s_pkt = base_pkt(s_dst, (scalar_req_i.op == SF_MEM_LOAD) ? SF_NOC_RD_REQ : SF_NOC_WR_REQ,
                     SF_NOC_X_SCALAR, scalar_req_i.tag, scalar_req_i.hint, scalar_req_i.addr);
    s_pkt.be   = sf_noc_be_t'(scalar_req_i.wstrb);
    s_pkt.data = sf_noc_data_t'(scalar_req_i.wdata);

    v_pkt = base_pkt(v_dst, (vector_req_i.op == SF_MEM_LOAD) ? SF_NOC_RD_REQ : SF_NOC_WR_REQ,
                     SF_NOC_X_VECTOR, vector_req_i.tag, vector_req_i.hint, vector_req_i.addr);
    for (int l = 0; l < SF_VLANES; l++) v_pkt.be[4*l +: 4] = {4{vector_req_i.lane_mask[l]}};
    v_pkt.data = vector_req_i.wdata;

    b_pkt = base_pkt(b_dst, (burst_req_i.op == SF_MEM_LOAD) ? SF_NOC_RD_REQ : SF_NOC_WR_REQ,
                     SF_NOC_X_BURST, burst_req_i.tag, burst_req_i.hint, burst_req_i.base);
    b_pkt.data[7:0] = burst_req_i.len_m1;
    b_pkt.eop       = (burst_req_i.op == SF_MEM_LOAD);    // a write descriptor opens a multi-flit packet
  end

  // --------------------------------------------------------------------------
  // injection stage: round-robin over {scalar, vector, burst}, burst-write lock
  // --------------------------------------------------------------------------
  logic        ov_q;                     // output register valid
  noc_packet_t opkt_q;
  logic        out_free;
  logic [1:0]  rr_q;
  logic        wlock_q;                  // burst-write beats in progress
  logic [8:0]  w_left_q;                 // beats still to send
  noc_packet_t w_tmpl_q;                 // template for beat flits

  assign out_free = ~ov_q | req_ready_i;

  // round-robin pick over 3 candidates, priority starts after the last winner
  function automatic logic [2:0] rr_pick3(input logic [2:0] c, input logic [1:0] last);
    logic [2:0] g;
    g = '0;
    for (int k = 0; k < 3; k++) begin
      if (g == '0 && c[(int'(last) + 1 + k) % 3]) g[(int'(last) + 1 + k) % 3] = 1'b1;
    end
    return g;
  endfunction

  logic [2:0] cand;
  logic [2:0] gnt;
  assign cand = {b_can, v_can, s_can};
  assign gnt  = (out_free && !wlock_q) ? rr_pick3(cand, rr_q) : 3'b000;

  wire s_acc = gnt[0] & scalar_req_valid_i;
  wire v_acc = gnt[1] & vector_req_valid_i;
  wire b_acc = gnt[2] & burst_req_valid_i;

  assign scalar_req_ready_o = s_acc | s_lerr;
  assign vector_req_ready_o = v_acc | v_lerr;
  assign burst_req_ready_o  = b_acc | b_lerr;

  // burst write beat
  wire beat_go = wlock_q && out_free && burst_wdata_valid_i;
  assign burst_wdata_ready_o = wlock_q && out_free;

  noc_packet_t beat_pkt;
  always_comb begin
    beat_pkt      = w_tmpl_q;
    beat_pkt.sop  = 1'b0;
    beat_pkt.eop  = (w_left_q == 9'd1);
    beat_pkt.data = burst_wdata_i.data;
    beat_pkt.be   = burst_wdata_i.strb;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ov_q <= 1'b0; rr_q <= 2'd2; wlock_q <= 1'b0; w_left_q <= '0;
    end else begin
      if (ov_q && req_ready_i) ov_q <= 1'b0;
      if (s_acc) begin ov_q <= 1'b1; opkt_q <= s_pkt; rr_q <= 2'd0; end
      if (v_acc) begin ov_q <= 1'b1; opkt_q <= v_pkt; rr_q <= 2'd1; end
      if (b_acc) begin
        ov_q <= 1'b1; opkt_q <= b_pkt; rr_q <= 2'd2;
        if (burst_req_i.op == SF_MEM_STORE) begin
          wlock_q  <= 1'b1;
          w_left_q <= 9'(burst_req_i.len_m1) + 9'd1;
          w_tmpl_q <= b_pkt;
        end
      end
      if (beat_go) begin
        ov_q <= 1'b1; opkt_q <= beat_pkt;
        w_left_q <= w_left_q - 9'd1;
        if (w_left_q == 9'd1) wlock_q <= 1'b0;
      end
    end
  end

  assign req_valid_o = ov_q;
  assign req_pkt_o   = opkt_q;

  // --------------------------------------------------------------------------
  // responses from the fabric (always accepted: space was reserved at issue)
  // --------------------------------------------------------------------------
  assign rsp_ready_o = 1'b1;

  sf_scalar_mem_rsp_t sf_in, sf_out;  logic sf_push, sf_pop, sf_full, sf_empty;
  sf_vector_mem_rsp_t vf_in, vf_out;  logic vf_push, vf_pop, vf_full, vf_empty;
  sf_burst_rbeat_t    bf_in, bf_out;  logic bf_push, bf_pop, bf_full, bf_empty;
  logic [$clog2(SF_D+1)-1:0] sf_cnt;
  logic [$clog2(VF_D+1)-1:0] vf_cnt;
  logic [$clog2(BF_D+1)-1:0] bf_cnt;

  sf_noc_fifo #(.T(sf_scalar_mem_rsp_t), .DEPTH(SF_D)) u_sf (.clk_i, .rst_ni, .push_i(sf_push), .data_i(sf_in),
    .full_o(sf_full), .pop_i(sf_pop), .data_o(sf_out), .empty_o(sf_empty), .count_o(sf_cnt));
  sf_noc_fifo #(.T(sf_vector_mem_rsp_t), .DEPTH(VF_D)) u_vf (.clk_i, .rst_ni, .push_i(vf_push), .data_i(vf_in),
    .full_o(vf_full), .pop_i(vf_pop), .data_o(vf_out), .empty_o(vf_empty), .count_o(vf_cnt));
  sf_noc_fifo #(.T(sf_burst_rbeat_t), .DEPTH(BF_D)) u_bf (.clk_i, .rst_ni, .push_i(bf_push), .data_i(bf_in),
    .full_o(bf_full), .pop_i(bf_pop), .data_o(bf_out), .empty_o(bf_empty), .count_o(bf_cnt));

  logic            rd_final_q;           // last beat of the read burst has arrived
  logic [8:0]      rd_beats_q;
  sf_mem_exc_e     rd_exc_q;
  sf_mem_tag_t     rd_tag_q;

  wire rsp_beat = rsp_valid_i && (rsp_pkt_i.xfer == SF_NOC_X_BURST) &&
                  (rsp_pkt_i.pclass == SF_NOC_RD_RSP) && (rsp_pkt_i.be != '0);

  always_comb begin
    sf_push = 1'b0; vf_push = 1'b0; bf_push = 1'b0;
    sf_in = '0; vf_in = '0; bf_in = '0;
    if (rsp_valid_i) begin
      unique case (rsp_pkt_i.xfer)
        SF_NOC_X_SCALAR: begin
          sf_push      = 1'b1;
          sf_in.op     = (rsp_pkt_i.pclass == SF_NOC_RD_RSP) ? SF_MEM_LOAD : SF_MEM_STORE;
          sf_in.rdata  = rsp_pkt_i.data[SF_XLEN-1:0];
          sf_in.tag    = rsp_pkt_i.txn_id;
          sf_in.exc    = rsp_pkt_i.status;
        end
        SF_NOC_X_VECTOR: begin
          vf_push      = 1'b1;
          vf_in.op     = (rsp_pkt_i.pclass == SF_NOC_RD_RSP) ? SF_MEM_LOAD : SF_MEM_STORE;
          vf_in.rdata  = rsp_pkt_i.data;
          for (int l = 0; l < SF_VLANES; l++) vf_in.lane_mask[l] = &rsp_pkt_i.be[4*l +: 4];
          vf_in.tag    = rsp_pkt_i.txn_id;
          vf_in.exc    = rsp_pkt_i.status;
        end
        SF_NOC_X_BURST: begin
          if (rsp_beat) begin
            bf_push     = 1'b1;
            bf_in.data  = rsp_pkt_i.data;
            bf_in.tag   = rsp_pkt_i.txn_id;
            bf_in.last  = rsp_pkt_i.eop;
            bf_in.exc   = rsp_pkt_i.status;
          end
        end
        default: ;
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rd_final_q <= 1'b0; rd_beats_q <= '0; rd_exc_q <= SF_MEM_EXC_NONE; rd_tag_q <= '0;
      bd_valid_q <= 1'b0; bd_q <= '0;
    end else begin
      // burst completion bookkeeping
      if (rsp_valid_i && rsp_pkt_i.xfer == SF_NOC_X_BURST) begin
        if (rsp_beat) begin
          rd_beats_q <= rd_beats_q + 9'd1;
          rd_tag_q   <= rsp_pkt_i.txn_id;
          if (rd_exc_q == SF_MEM_EXC_NONE) rd_exc_q <= rsp_pkt_i.status;
          if (rsp_pkt_i.eop) rd_final_q <= 1'b1;
        end else if (rsp_pkt_i.pclass == SF_NOC_RD_RSP) begin        // error completion, no data
          bd_valid_q <= 1'b1;
          bd_q       <= '{op: SF_MEM_LOAD, tag: rsp_pkt_i.txn_id, beats: '0, exc: rsp_pkt_i.status};
        end else if (rsp_pkt_i.pclass == SF_NOC_WR_RSP) begin
          bd_valid_q <= 1'b1;
          bd_q       <= '{op: SF_MEM_STORE, tag: rsp_pkt_i.txn_id, beats: rsp_pkt_i.data[SF_BURST_LEN_W:0],
                          exc: rsp_pkt_i.status};
        end
      end
      // read burst done once the last beat has been handed to the tile
      if (rd_final_q && bf_empty && !bd_valid_q) begin
        bd_valid_q <= 1'b1;
        bd_q       <= '{op: SF_MEM_LOAD, tag: rd_tag_q, beats: rd_beats_q, exc: rd_exc_q};
        rd_final_q <= 1'b0;
      end
      // local completions (decode / length error)
      if (b_lerr && burst_req_ready_o) begin
        bd_valid_q <= 1'b1;
        bd_q       <= '{op: burst_req_i.op, tag: burst_req_i.tag, beats: '0,
                        exc: !b_ok ? SF_MEM_EXC_RANGE : SF_MEM_EXC_BURST_LEN};
      end
      if (bd_valid_q && burst_done_ready_i) begin
        bd_valid_q <= 1'b0;
        rd_beats_q <= '0; rd_exc_q <= SF_MEM_EXC_NONE;
      end
    end
  end

  assign burst_done_valid_o  = bd_valid_q;
  assign burst_done_o        = bd_q;
  assign burst_rdata_valid_o = !bf_empty;
  assign burst_rdata_o       = bf_out;
  assign bf_pop              = !bf_empty && burst_rdata_ready_i;

  // b_busy: desc accepted into the fabric until its done is delivered
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) b_busy_q <= 1'b0;
    else if (b_acc) b_busy_q <= 1'b1;
    else if (bd_valid_q && burst_done_ready_i) b_busy_q <= 1'b0;
  end

  // --------------------------------------------------------------------------
  // scalar / vector response delivery (FIFO first, local error otherwise)
  // --------------------------------------------------------------------------
  assign scalar_rsp_valid_o = !sf_empty || s_err_q;
  assign scalar_rsp_o       = !sf_empty ? sf_out : s_err_rsp_q;
  assign sf_pop             = !sf_empty && scalar_rsp_ready_i;
  assign vector_rsp_valid_o = !vf_empty || v_err_q;
  assign vector_rsp_o       = !vf_empty ? vf_out : v_err_rsp_q;
  assign vf_pop             = !vf_empty && vector_rsp_ready_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      s_out_q <= '0; s_tgt_q <= '0; s_err_q <= 1'b0; s_err_rsp_q <= '0;
      v_out_q <= '0; v_tgt_q <= '0; v_err_q <= 1'b0; v_err_rsp_q <= '0;
    end else begin
      s_out_q <= s_out_q + CS_W'(s_acc) - CS_W'(sf_pop);
      v_out_q <= v_out_q + CV_W'(v_acc) - CV_W'(vf_pop);
      if (s_acc) s_tgt_q <= s_dst;
      if (v_acc) v_tgt_q <= v_dst;
      if (s_lerr && scalar_req_ready_o) begin
        s_err_q     <= 1'b1;
        s_err_rsp_q <= '{op: scalar_req_i.op, rdata: '0, tag: scalar_req_i.tag, exc: SF_MEM_EXC_RANGE};
      end else if (s_err_q && sf_empty && scalar_rsp_ready_i) s_err_q <= 1'b0;
      if (v_lerr && vector_req_ready_o) begin
        v_err_q     <= 1'b1;
        v_err_rsp_q <= '{op: vector_req_i.op, rdata: '0, lane_mask: '0, tag: vector_req_i.tag, exc: SF_MEM_EXC_RANGE};
      end else if (v_err_q && vf_empty && vector_rsp_ready_i) v_err_q <= 1'b0;
    end
  end

  assign err_decode_o = (s_lerr & scalar_req_ready_o) | (v_lerr & vector_req_ready_o) | (b_lerr & burst_req_ready_o & !b_ok);

`ifndef SYNTHESIS
  // The central guarantee: a response never finds its buffer full.
  a_sf_space: assert property (@(posedge clk_i) disable iff (!rst_ni) sf_push |-> !sf_full)
    else $error("master_ni: scalar response buffer overflow - credit accounting broken");
  a_vf_space: assert property (@(posedge clk_i) disable iff (!rst_ni) vf_push |-> !vf_full)
    else $error("master_ni: vector response buffer overflow - credit accounting broken");
  a_bf_space: assert property (@(posedge clk_i) disable iff (!rst_ni) bf_push |-> !bf_full)
    else $error("master_ni: burst response buffer overflow - credit accounting broken");
  a_one_target: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (s_acc && s_out_q != '0) |-> (s_tgt_q == s_dst))
    else $error("master_ni: scalar request to a second target while responses outstanding");
`endif
endmodule : sf_noc_mem_master_ni
