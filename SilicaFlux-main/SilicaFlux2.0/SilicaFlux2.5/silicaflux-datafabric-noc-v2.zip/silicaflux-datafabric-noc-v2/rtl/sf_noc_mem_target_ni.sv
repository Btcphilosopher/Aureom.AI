// =============================================================================
//  sf_noc_mem_target_ni : memory-side network interface
//
//  Turns request packets from the request network into transactions on the real
//  memory_controller slave ports (the "m_*" ports below connect one-to-one to
//  memory_controller's scalar / vector / burst ports) and returns exactly one
//  completion packet per request on the response network.
//
//    xfer SCALAR  RD_REQ/WR_REQ      -> scalar port   (be[3:0] = wstrb)
//    xfer VECTOR  RD_REQ/WR_REQ      -> vector port   (byte enables must be lane
//                                       aligned: each 4-byte lane all-set or all-clear,
//                                       otherwise SF_MEM_EXC_MISALIGN and nothing issues)
//    xfer BURST   RD_REQ (1 flit)    -> burst port, response = beat flits (sop..eop),
//                                       read data flits carry be = 16'hFFFF;
//                                       an error completion has NO data and be = 0
//                 WR_REQ (descriptor flit + len_m1+1 beat flits)
//                                    -> burst port; completion = WR_RSP with
//                                       data[8:0] = beats committed, status = exc
//                                       (a descriptor the controller rejects never
//                                       accepts beats: they are drained here and
//                                       the rejection is returned)
//    xfer CTRL    RD_REQ/WR_REQ      -> 16 scratch registers @ 0x00..0x3C, CNT_CTL @ 0x100
//                                       (bit0 write-1-to-clear counters, bit1 freeze),
//                                       counter window @ addr[18]=1: counter word address
//                                       = addr[17:2] (read-only, if HAS_CNT)
//
//  Transaction IDs: the request's txn_id is stored in a per-port context FIFO and
//  placed in the response; the controller's own tag is cross-checked against it.
//  The controller answers in request order per port, so a context FIFO suffices.
//
//  Back-pressure: the request FIFO is the only place requests wait. Nothing here
//  waits for the RESPONSE network except the response FIFOs, and the response
//  network is guaranteed to drain (requesters reserve response buffers), so a
//  full response FIFO is always a transient condition.
// =============================================================================
module sf_noc_mem_target_ni
  import silicaflux_pkg::*;
#(
  parameter sf_noc_id_t  MY_ID     = '0,
  parameter int unsigned REQ_DEPTH = 4,
  parameter int unsigned CTX_DEPTH = 8,
  parameter int unsigned RSP_DEPTH = 4,
  parameter bit          HAS_CNT   = 1'b0
) (
  input  logic                clk_i,
  input  logic                rst_ni,

  // ---- NoC side ----
  input  logic                req_valid_i,
  output logic                req_ready_o,
  input  noc_packet_t         req_pkt_i,
  output logic                rsp_valid_o,
  input  logic                rsp_ready_i,
  output noc_packet_t         rsp_pkt_o,

  // ---- memory_controller slave ports ----
  output logic                m_scalar_req_valid_o,
  input  logic                m_scalar_req_ready_i,
  output sf_scalar_mem_req_t  m_scalar_req_o,
  input  logic                m_scalar_rsp_valid_i,
  output logic                m_scalar_rsp_ready_o,
  input  sf_scalar_mem_rsp_t  m_scalar_rsp_i,

  output logic                m_vector_req_valid_o,
  input  logic                m_vector_req_ready_i,
  output sf_vector_mem_req_t  m_vector_req_o,
  input  logic                m_vector_rsp_valid_i,
  output logic                m_vector_rsp_ready_o,
  input  sf_vector_mem_rsp_t  m_vector_rsp_i,

  output logic                m_burst_req_valid_o,
  input  logic                m_burst_req_ready_i,
  output sf_burst_desc_t      m_burst_req_o,
  output logic                m_burst_wdata_valid_o,
  input  logic                m_burst_wdata_ready_i,
  output sf_burst_wbeat_t     m_burst_wdata_o,
  input  logic                m_burst_rdata_valid_i,
  output logic                m_burst_rdata_ready_o,
  input  sf_burst_rbeat_t     m_burst_rdata_i,
  input  logic                m_burst_done_valid_i,
  output logic                m_burst_done_ready_o,
  input  sf_burst_done_t      m_burst_done_i,

  // ---- counter bridge (control-register window) ----
  output logic [15:0]         cnt_rd_addr_o,
  output logic                cnt_rd_plane_o,     // addr[19]: 0 request network counters, 1 response network
  input  logic [31:0]         cnt_rd_data_i,
  output logic                cnt_clear_o,
  output logic                cnt_freeze_o,

  // ---- status pulses ----
  output logic                err_msg_drop_o,     // posted MSG / response-class packet received and dropped
  output logic                err_frame_o         // malformed burst framing
);

  // --------------------------------------------------------------------------
  // types
  // --------------------------------------------------------------------------
  typedef struct packed {
    sf_noc_id_t   src;
    sf_mem_tag_t  txn;
    sf_noc_qos_t  qos;
    sf_mem_op_e   op;
    sf_paddr_t    addr;
    sf_mem_hint_e hint;
  } ctx_t;

  typedef enum logic [2:0] { D_IDLE, BR_ACTIVE, BW_BEATS, BW_DRAIN, BW_FIN } dstate_e;

  localparam sf_noc_be_t BE_ALL = '1;

  // --------------------------------------------------------------------------
  // request FIFO
  // --------------------------------------------------------------------------
  noc_packet_t rq_data;
  logic        rq_empty, rq_full, rq_pop;
  logic [$clog2(REQ_DEPTH+1)-1:0] rq_cnt;
  sf_noc_fifo #(.T(noc_packet_t), .DEPTH(REQ_DEPTH)) u_rq (.clk_i, .rst_ni,
    .push_i(req_valid_i & ~rq_full), .data_i(req_pkt_i), .full_o(rq_full), .pop_i(rq_pop),
    .data_o(rq_data), .empty_o(rq_empty), .count_o(rq_cnt));
  assign req_ready_o = ~rq_full;

  // --------------------------------------------------------------------------
  // response FIFOs (packets): scalar, vector, control/error, burst
  // --------------------------------------------------------------------------
  noc_packet_t os_in, ov_in, oc_in, ob_in, os_out, ov_out, oc_out, ob_out;
  logic os_push, ov_push, oc_push, ob_push, os_pop, ov_pop, oc_pop, ob_pop;
  logic os_full, ov_full, oc_full, ob_full, os_empty, ov_empty, oc_empty, ob_empty;
  logic [$clog2(RSP_DEPTH+1)-1:0] os_cnt, ov_cnt, oc_cnt, ob_cnt;
  sf_noc_fifo #(.T(noc_packet_t), .DEPTH(RSP_DEPTH)) u_os (.clk_i, .rst_ni, .push_i(os_push), .data_i(os_in),
    .full_o(os_full), .pop_i(os_pop), .data_o(os_out), .empty_o(os_empty), .count_o(os_cnt));
  sf_noc_fifo #(.T(noc_packet_t), .DEPTH(RSP_DEPTH)) u_ov (.clk_i, .rst_ni, .push_i(ov_push), .data_i(ov_in),
    .full_o(ov_full), .pop_i(ov_pop), .data_o(ov_out), .empty_o(ov_empty), .count_o(ov_cnt));
  sf_noc_fifo #(.T(noc_packet_t), .DEPTH(RSP_DEPTH)) u_oc (.clk_i, .rst_ni, .push_i(oc_push), .data_i(oc_in),
    .full_o(oc_full), .pop_i(oc_pop), .data_o(oc_out), .empty_o(oc_empty), .count_o(oc_cnt));
  sf_noc_fifo #(.T(noc_packet_t), .DEPTH(RSP_DEPTH)) u_ob (.clk_i, .rst_ni, .push_i(ob_push), .data_i(ob_in),
    .full_o(ob_full), .pop_i(ob_pop), .data_o(ob_out), .empty_o(ob_empty), .count_o(ob_cnt));

  // --------------------------------------------------------------------------
  // context FIFOs (scalar, vector)
  // --------------------------------------------------------------------------
  ctx_t cs_in, cs_out, cv_in, cv_out;
  logic cs_push, cs_pop, cs_full, cs_empty, cv_push, cv_pop, cv_full, cv_empty;
  logic [$clog2(CTX_DEPTH+1)-1:0] cs_cnt, cv_cnt;
  sf_noc_fifo #(.T(ctx_t), .DEPTH(CTX_DEPTH)) u_cs (.clk_i, .rst_ni, .push_i(cs_push), .data_i(cs_in),
    .full_o(cs_full), .pop_i(cs_pop), .data_o(cs_out), .empty_o(cs_empty), .count_o(cs_cnt));
  sf_noc_fifo #(.T(ctx_t), .DEPTH(CTX_DEPTH)) u_cv (.clk_i, .rst_ni, .push_i(cv_push), .data_i(cv_in),
    .full_o(cv_full), .pop_i(cv_pop), .data_o(cv_out), .empty_o(cv_empty), .count_o(cv_cnt));

  // --------------------------------------------------------------------------
  // helpers
  // --------------------------------------------------------------------------
  function automatic noc_packet_t rsp_base(input noc_packet_t h);
    noc_packet_t r;
    r        = '0;
    r.valid  = 1'b1; r.sop = 1'b1; r.eop = 1'b1;
    r.pclass = (h.pclass == SF_NOC_RD_REQ) ? SF_NOC_RD_RSP : SF_NOC_WR_RSP;
    r.qos    = h.qos;
    r.dst_id = h.src_id;
    r.src_id = MY_ID;
    r.txn_id = h.txn_id;
    r.xfer   = h.xfer;
    r.hint   = h.hint;
    r.addr   = h.addr;
    return r;
  endfunction

  function automatic noc_packet_t rsp_from_ctx(input ctx_t c);
    noc_packet_t r;
    r        = '0;
    r.valid  = 1'b1; r.sop = 1'b1; r.eop = 1'b1;
    r.pclass = (c.op == SF_MEM_LOAD) ? SF_NOC_RD_RSP : SF_NOC_WR_RSP;
    r.qos    = c.qos;
    r.dst_id = c.src;
    r.src_id = MY_ID;
    r.txn_id = c.txn;
    r.hint   = c.hint;
    r.addr   = c.addr;
    return r;
  endfunction

  // --------------------------------------------------------------------------
  // registers
  // --------------------------------------------------------------------------
  dstate_e     st_q;
  ctx_t        bctx_q;               // burst context
  logic [8:0]  b_idx_q;              // beats produced (read) / forwarded (write)
  logic [8:0]  b_left_q;             // write beats still to take from the request FIFO
  sf_mem_exc_e b_rej_exc_q;
  logic [31:0] scratch_q [16];
  logic        freeze_q;
  logic        clear_pulse_q;

  // --------------------------------------------------------------------------
  // dispatch (combinational)
  // --------------------------------------------------------------------------
  noc_packet_t h;
  logic        h_is_req, h_is_rd;
  logic        lane_ok;
  logic [31:0] ctrl_rdata;
  logic        ctrl_hit, ctrl_wr_hit, ctrl_win_hit;

  assign h        = rq_data;
  assign h_is_rd  = (h.pclass == SF_NOC_RD_REQ);
  // a flit that is not a packet head cannot open a transaction: it falls into disp_drop (orphan)
  assign h_is_req = h.sop && ((h.pclass == SF_NOC_RD_REQ) || (h.pclass == SF_NOC_WR_REQ));

  always_comb begin
    lane_ok = 1'b1;
    for (int l = 0; l < SF_VLANES; l++)
      if (!(&h.be[4*l +: 4] || ~|h.be[4*l +: 4])) lane_ok = 1'b0;
  end

  // control register decode
  always_comb begin
    ctrl_hit     = 1'b0;
    ctrl_wr_hit  = 1'b0;
    ctrl_win_hit = 1'b0;
    ctrl_rdata   = '0;
    cnt_rd_addr_o  = h.addr[17:2];
    cnt_rd_plane_o = h.addr[19];
    if (!h.addr[18]) begin
      if (h.addr[17:6] == '0) begin                  // 16 scratch registers: addr[5:2] covers 0..15
        ctrl_hit = 1'b1; ctrl_rdata = scratch_q[h.addr[5:2]];
      end else if (h.addr[17:2] == 16'h0040) begin
        ctrl_hit = 1'b1; ctrl_rdata = {30'b0, freeze_q, 1'b0};
      end
    end else if (HAS_CNT && h_is_rd) begin
      ctrl_hit = 1'b1; ctrl_win_hit = 1'b1; ctrl_rdata = cnt_rd_data_i;
    end
  end

  logic disp_scalar, disp_vector, disp_ctrl, disp_drop, disp_vmis;
  logic burst_rd_go, burst_wr_go, burst_bad;

  assign disp_scalar = (st_q == D_IDLE) && !rq_empty && h_is_req && (h.xfer == SF_NOC_X_SCALAR);
  assign disp_vector = (st_q == D_IDLE) && !rq_empty && h_is_req && (h.xfer == SF_NOC_X_VECTOR);
  assign disp_ctrl   = (st_q == D_IDLE) && !rq_empty && h_is_req && (h.xfer == SF_NOC_X_CTRL);
  assign disp_vmis   = disp_vector && !lane_ok;
  assign disp_drop   = (st_q == D_IDLE) && !rq_empty && !h_is_req;     // MSG or response class
  assign burst_rd_go = (st_q == D_IDLE) && !rq_empty && h_is_req && (h.xfer == SF_NOC_X_BURST) && h_is_rd;
  assign burst_wr_go = (st_q == D_IDLE) && !rq_empty && h_is_req && (h.xfer == SF_NOC_X_BURST) && !h_is_rd;
  assign burst_bad   = burst_wr_go && h.eop;                           // write descriptor must open a multi-flit packet

  // ---- scalar issue
  assign m_scalar_req_valid_o = disp_scalar && !cs_full;
  assign m_scalar_req_o       = '{op: h_is_rd ? SF_MEM_LOAD : SF_MEM_STORE, addr: h.addr,
                                  wdata: h.data[SF_XLEN-1:0], wstrb: h.be[SF_XBYTES-1:0],
                                  tag: h.txn_id, hint: h.hint};
  wire s_issue = m_scalar_req_valid_o && m_scalar_req_ready_i;
  assign cs_push = s_issue;
  assign cs_in   = '{src: h.src_id, txn: h.txn_id, qos: h.qos, op: h_is_rd ? SF_MEM_LOAD : SF_MEM_STORE,
                     addr: h.addr, hint: h.hint};

  // ---- vector issue
  sf_vector_mem_req_t vreq;
  always_comb begin
    vreq.op   = h_is_rd ? SF_MEM_LOAD : SF_MEM_STORE;
    vreq.addr = h.addr;
    vreq.wdata = h.data;
    for (int l = 0; l < SF_VLANES; l++) vreq.lane_mask[l] = &h.be[4*l +: 4];
    vreq.tag  = h.txn_id;
    vreq.hint = h.hint;
  end
  assign m_vector_req_valid_o = disp_vector && lane_ok && !cv_full;
  assign m_vector_req_o       = vreq;
  wire v_issue = m_vector_req_valid_o && m_vector_req_ready_i;
  assign cv_push = v_issue;
  assign cv_in   = '{src: h.src_id, txn: h.txn_id, qos: h.qos, op: h_is_rd ? SF_MEM_LOAD : SF_MEM_STORE,
                     addr: h.addr, hint: h.hint};

  // ---- burst descriptor
  assign m_burst_req_valid_o = (burst_rd_go || (burst_wr_go && !burst_bad)) && (st_q == D_IDLE);
  assign m_burst_req_o       = '{op: h_is_rd ? SF_MEM_LOAD : SF_MEM_STORE, base: h.addr,
                                 len_m1: h.data[SF_BURST_LEN_W-1:0], tag: h.txn_id, hint: h.hint};
  wire b_issue = m_burst_req_valid_o && m_burst_req_ready_i;

  // ---- request pop
  logic bw_beat_take, bw_drain_take;
  always_comb begin
    rq_pop = 1'b0;
    if (s_issue || v_issue || b_issue) rq_pop = 1'b1;
    if (disp_vector && !lane_ok && !oc_full) rq_pop = 1'b1;       // local MISALIGN response
    if (disp_ctrl && !oc_full)               rq_pop = 1'b1;
    if (disp_drop)                           rq_pop = 1'b1;
    if (burst_bad && !oc_full)               rq_pop = 1'b1;
    if (bw_beat_take || bw_drain_take)       rq_pop = 1'b1;
  end

  // ---- control / error responses (oc FIFO)
  always_comb begin
    oc_push = 1'b0;
    oc_in   = '0;
    if (disp_vmis && !oc_full) begin
      oc_push = 1'b1; oc_in = rsp_base(h); oc_in.status = SF_MEM_EXC_MISALIGN;
    end else if (disp_ctrl && !oc_full) begin
      oc_push = 1'b1; oc_in = rsp_base(h);
      if (!ctrl_hit || (!h_is_rd && h.addr[18])) begin
        oc_in.status = SF_MEM_EXC_RANGE;
      end else if (h_is_rd) begin
        oc_in.data = sf_noc_data_t'(ctrl_rdata); oc_in.be = sf_noc_be_t'(4'hF);
      end
    end else if (burst_bad && !oc_full) begin
      oc_push = 1'b1; oc_in = rsp_base(h); oc_in.status = SF_MEM_EXC_BURST_LEN;
    end else if ((st_q == BW_FIN) && m_burst_done_valid_i && !oc_full) begin
      oc_push = 1'b1; oc_in = rsp_from_ctx(bctx_q); oc_in.xfer = SF_NOC_X_BURST;
      oc_in.pclass = SF_NOC_WR_RSP; oc_in.status = m_burst_done_i.exc;
      oc_in.data[8:0] = m_burst_done_i.beats;
    end else if ((st_q == BW_DRAIN) && (b_left_q == 9'd0) && !oc_full) begin
      oc_push = 1'b1; oc_in = rsp_from_ctx(bctx_q); oc_in.xfer = SF_NOC_X_BURST;
      oc_in.pclass = SF_NOC_WR_RSP; oc_in.status = b_rej_exc_q;
    end
  end

  // ---- burst read beats / error completion (ob FIFO)
  always_comb begin
    ob_push = 1'b0;
    ob_in   = '0;
    m_burst_rdata_ready_o = 1'b0;
    if (st_q == BR_ACTIVE) begin
      m_burst_rdata_ready_o = !ob_full;
      if (m_burst_rdata_valid_i && !ob_full) begin
        ob_push        = 1'b1;
        ob_in          = rsp_from_ctx(bctx_q);
        ob_in.pclass   = SF_NOC_RD_RSP;
        ob_in.xfer     = SF_NOC_X_BURST;
        ob_in.sop      = (b_idx_q == 9'd0);
        ob_in.eop      = m_burst_rdata_i.last;
        ob_in.data     = m_burst_rdata_i.data;
        ob_in.be       = BE_ALL;
        ob_in.status   = m_burst_rdata_i.exc;
        ob_in.addr     = bctx_q.addr + sf_paddr_t'({b_idx_q, 4'b0});
      end else if (m_burst_done_valid_i && (m_burst_done_i.beats == '0) &&
                   (m_burst_done_i.exc != SF_MEM_EXC_NONE) && !ob_full) begin
        // descriptor rejected by the controller: error completion, no data
        ob_push        = 1'b1;
        ob_in          = rsp_from_ctx(bctx_q);
        ob_in.pclass   = SF_NOC_RD_RSP;
        ob_in.xfer     = SF_NOC_X_BURST;
        ob_in.be       = '0;
        ob_in.status   = m_burst_done_i.exc;
      end
    end
  end

  // ---- burst write beats
  assign bw_beat_take  = (st_q == BW_BEATS) && (b_left_q != 9'd0) && !rq_empty &&
                         m_burst_wdata_ready_i && !(m_burst_done_valid_i);
  assign m_burst_wdata_valid_o = (st_q == BW_BEATS) && (b_left_q != 9'd0) && !rq_empty &&
                                 !m_burst_done_valid_i;
  assign m_burst_wdata_o       = '{data: h.data, strb: h.be};
  assign bw_drain_take = (st_q == BW_DRAIN) && (b_left_q != 9'd0) && !rq_empty;

  assign m_burst_done_ready_o =
      ((st_q == BR_ACTIVE) && m_burst_done_valid_i &&
         !(m_burst_done_i.beats == '0 && m_burst_done_i.exc != SF_MEM_EXC_NONE && ob_full)) ||
      ((st_q == BW_BEATS) && m_burst_done_valid_i && (m_burst_done_i.beats == '0) &&
         (m_burst_done_i.exc != SF_MEM_EXC_NONE)) ||
      ((st_q == BW_FIN) && m_burst_done_valid_i && !oc_full);

  // ---- state machine
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= D_IDLE; b_idx_q <= '0; b_left_q <= '0; b_rej_exc_q <= SF_MEM_EXC_NONE; bctx_q <= '0;
    end else begin
      unique case (st_q)
        D_IDLE: begin
          if (b_issue) begin
            bctx_q <= '{src: h.src_id, txn: h.txn_id, qos: h.qos, op: h_is_rd ? SF_MEM_LOAD : SF_MEM_STORE,
                        addr: h.addr, hint: h.hint};
            b_idx_q  <= '0;
            b_left_q <= 9'(h.data[SF_BURST_LEN_W-1:0]) + 9'd1;
            st_q     <= h_is_rd ? BR_ACTIVE : BW_BEATS;
          end
        end
        BR_ACTIVE: begin
          if (m_burst_rdata_valid_i && !ob_full) b_idx_q <= b_idx_q + 9'd1;
          if (m_burst_done_valid_i && m_burst_done_ready_o) st_q <= D_IDLE;
        end
        BW_BEATS: begin
          if (bw_beat_take) begin
            b_left_q <= b_left_q - 9'd1;
            if (b_left_q == 9'd1) st_q <= BW_FIN;
          end
          if (m_burst_done_valid_i && m_burst_done_ready_o) begin      // descriptor rejected
            b_rej_exc_q <= m_burst_done_i.exc;
            st_q        <= BW_DRAIN;
          end
        end
        BW_DRAIN: begin
          if (bw_drain_take) b_left_q <= b_left_q - 9'd1;
          if (b_left_q == 9'd0 && !oc_full) st_q <= D_IDLE;
        end
        BW_FIN: begin
          if (m_burst_done_valid_i && m_burst_done_ready_o) st_q <= D_IDLE;
        end
        default: st_q <= D_IDLE;
      endcase
    end
  end

  // --------------------------------------------------------------------------
  // scalar / vector completions from the controller
  // --------------------------------------------------------------------------
  assign m_scalar_rsp_ready_o = !os_full && !cs_empty;
  assign cs_pop               = m_scalar_rsp_valid_i && m_scalar_rsp_ready_o;
  always_comb begin
    os_push = cs_pop;
    os_in   = rsp_from_ctx(cs_out);
    os_in.xfer   = SF_NOC_X_SCALAR;
    os_in.status = m_scalar_rsp_i.exc;
    os_in.data   = sf_noc_data_t'(m_scalar_rsp_i.rdata);
    os_in.be     = (cs_out.op == SF_MEM_LOAD) ? sf_noc_be_t'(4'hF) : '0;
  end

  assign m_vector_rsp_ready_o = !ov_full && !cv_empty;
  assign cv_pop               = m_vector_rsp_valid_i && m_vector_rsp_ready_o;
  always_comb begin
    ov_push = cv_pop;
    ov_in   = rsp_from_ctx(cv_out);
    ov_in.xfer   = SF_NOC_X_VECTOR;
    ov_in.status = m_vector_rsp_i.exc;
    ov_in.data   = m_vector_rsp_i.rdata;
    for (int l = 0; l < SF_VLANES; l++) ov_in.be[4*l +: 4] = {4{m_vector_rsp_i.lane_mask[l]}};
  end

  // --------------------------------------------------------------------------
  // control registers
  // --------------------------------------------------------------------------
  wire ctrl_wr_fire = disp_ctrl && !oc_full && !h_is_rd && ctrl_hit && !h.addr[18];
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int i = 0; i < 16; i++) scratch_q[i] <= '0;
      freeze_q <= 1'b0; clear_pulse_q <= 1'b0;
    end else begin
      clear_pulse_q <= 1'b0;
      if (ctrl_wr_fire) begin
        if (h.addr[17:6] == '0) begin
          for (int b = 0; b < 4; b++)
            if (h.be[b]) scratch_q[h.addr[5:2]][8*b +: 8] <= h.data[8*b +: 8];
        end else begin                       // CNT_CTL
          freeze_q      <= h.data[1];
          clear_pulse_q <= h.data[0];
        end
      end
    end
  end
  assign cnt_clear_o  = clear_pulse_q;
  assign cnt_freeze_o = freeze_q;

  // --------------------------------------------------------------------------
  // response arbitration onto the response network (burst packets locked)
  // --------------------------------------------------------------------------
  logic        ov_q;
  noc_packet_t opkt_q;
  logic        blk_q;                 // inside a multi-flit burst response
  logic [1:0]  rr_q;
  logic [3:0]  avail, sel;
  logic        can_load;
  assign can_load = ~ov_q | rsp_ready_i;
  assign avail    = {~ob_empty, ~oc_empty, ~ov_empty, ~os_empty};   // [0]=scalar [1]=vector [2]=ctrl [3]=burst

  function automatic logic [3:0] rr_pick4(input logic [3:0] c, input logic [1:0] last);
    logic [3:0] g;
    g = '0;
    for (int k = 0; k < 4; k++) begin
      if (g == '0 && c[(int'(last) + 1 + k) % 4]) g[(int'(last) + 1 + k) % 4] = 1'b1;
    end
    return g;
  endfunction

  always_comb begin
    sel = '0;
    if (can_load) begin
      if (blk_q) sel[3] = avail[3];
      else       sel = rr_pick4(avail, rr_q);
    end
  end
  assign os_pop = sel[0];
  assign ov_pop = sel[1];
  assign oc_pop = sel[2];
  assign ob_pop = sel[3];

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ov_q <= 1'b0; blk_q <= 1'b0; rr_q <= 2'd3;
    end else begin
      if (ov_q && rsp_ready_i) ov_q <= 1'b0;
      if (|sel) begin
        ov_q <= 1'b1;
        if (sel[0]) begin opkt_q <= os_out; rr_q <= 2'd0; end
        if (sel[1]) begin opkt_q <= ov_out; rr_q <= 2'd1; end
        if (sel[2]) begin opkt_q <= oc_out; rr_q <= 2'd2; end
        if (sel[3]) begin
          opkt_q <= ob_out; rr_q <= 2'd3;
          blk_q  <= ob_out.eop ? 1'b0 : 1'b1;
        end
      end
    end
  end
  assign rsp_valid_o = ov_q;
  assign rsp_pkt_o   = opkt_q;

  assign err_msg_drop_o = disp_drop;
  assign err_frame_o    = burst_bad && !oc_full;

`ifndef SYNTHESIS
  a_scalar_tag: assert property (@(posedge clk_i) disable iff (!rst_ni)
    cs_pop |-> (m_scalar_rsp_i.tag == cs_out.txn))
    else $error("target_ni: scalar response tag %0d != request txn %0d", m_scalar_rsp_i.tag, cs_out.txn);
  a_vector_tag: assert property (@(posedge clk_i) disable iff (!rst_ni)
    cv_pop |-> (m_vector_rsp_i.tag == cv_out.txn))
    else $error("target_ni: vector response tag mismatch");
  a_rsp_hold: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (rsp_valid_o && !rsp_ready_i) |=> (rsp_valid_o && $stable(rsp_pkt_o)))
    else $error("target_ni: response dropped/changed under stall");
`endif
endmodule : sf_noc_mem_target_ni
