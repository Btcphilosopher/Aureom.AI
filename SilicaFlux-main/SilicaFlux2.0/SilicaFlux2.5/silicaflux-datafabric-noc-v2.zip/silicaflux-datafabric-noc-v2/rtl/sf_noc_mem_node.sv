// =============================================================================
//  sf_noc_mem_node : one tile's memory-side attachment to the DataFabric NoC
//
//    initiator ports (memory_controller slave-side ports, same types)
//        |  sf_noc_mem_master_ni ---> request network  (req_in_*)
//        |                      <--- response network (rsp_out_*)
//        |  sf_noc_mem_target_ni <--- request network  (req_out_*)
//        |           |          ---> response network  (rsp_in_*)
//        |      memory_controller  (the tile's scratchpad / shared SRAM, real RTL)
//
//  A tile's LSU / vector LSU / DMA drive the initiator ports exactly as they would
//  drive a local memory_controller; every tile's scratchpad is reachable from every
//  other tile (and from itself, through the network) at
//     MAP_BASE + (tile << MAP_SHIFT) + offset.
// =============================================================================
module sf_noc_mem_node
  import silicaflux_pkg::*;
#(
  parameter int unsigned TILE         = 0,
  parameter int unsigned NUM_TILES    = 4,
  parameter int unsigned MESH_X       = 2,
  parameter sf_paddr_t   MAP_BASE     = 32'h1000_0000,
  parameter int unsigned MAP_SHIFT    = 20,
  // scratchpad geometry (memory_controller parameters)
  parameter int unsigned NUM_BANKS    = 8,
  parameter int unsigned BANK_DEPTH   = 512,
  parameter int unsigned SCALAR_LINES = 1024,
  parameter int unsigned BURST_MAX_BEATS = 256,
  // network interface sizing
  parameter int unsigned OUT_S        = 4,
  parameter int unsigned OUT_V        = 4,
  parameter int unsigned BRD_DEPTH    = 32,
  parameter int unsigned REQ_DEPTH    = 4,
  parameter int unsigned CTX_DEPTH    = 8,
  parameter int unsigned RSP_DEPTH    = 4,
  parameter bit          HAS_CNT      = 1'b0
) (
  input  logic                clk_i,
  input  logic                rst_ni,

  // ---- initiator ports (tile side) ----
  input  logic                scalar_req_valid_i, output logic scalar_req_ready_o, input  sf_scalar_mem_req_t scalar_req_i,
  output logic                scalar_rsp_valid_o, input  logic scalar_rsp_ready_i, output sf_scalar_mem_rsp_t scalar_rsp_o,
  input  logic                vector_req_valid_i, output logic vector_req_ready_o, input  sf_vector_mem_req_t vector_req_i,
  output logic                vector_rsp_valid_o, input  logic vector_rsp_ready_i, output sf_vector_mem_rsp_t vector_rsp_o,
  input  logic                burst_req_valid_i,  output logic burst_req_ready_o,  input  sf_burst_desc_t     burst_req_i,
  input  logic                burst_wdata_valid_i, output logic burst_wdata_ready_o, input sf_burst_wbeat_t   burst_wdata_i,
  output logic                burst_rdata_valid_o, input  logic burst_rdata_ready_i, output sf_burst_rbeat_t  burst_rdata_o,
  output logic                burst_done_valid_o, input  logic burst_done_ready_i, output sf_burst_done_t      burst_done_o,

  // ---- fabric side (connect to sf_noc_fabric tile ports [TILE]) ----
  output logic                req_in_valid_o,  input  logic req_in_ready_i,  output noc_packet_t req_in_pkt_o,
  input  logic                req_out_valid_i, output logic req_out_ready_o, input  noc_packet_t req_out_pkt_i,
  output logic                rsp_in_valid_o,  input  logic rsp_in_ready_i,  output noc_packet_t rsp_in_pkt_o,
  input  logic                rsp_out_valid_i, output logic rsp_out_ready_o, input  noc_packet_t rsp_out_pkt_i,

  // ---- control-register window onto the fabric counters (meaningful only if HAS_CNT) ----
  output logic [15:0]         cnt_rd_addr_o,
  output logic                cnt_rd_plane_o,
  input  logic [31:0]         cnt_rd_data_i,
  output logic                cnt_clear_o,
  output logic                cnt_freeze_o,

  output logic                init_done_o,
  output logic                err_decode_o
);
  localparam sf_noc_id_t MY_ID = sf_noc_id(TILE % MESH_X, TILE / MESH_X, MESH_X);

  sf_noc_mem_master_ni #(
    .NUM_TILES(NUM_TILES), .MESH_X(MESH_X), .MY_ID(MY_ID), .MAP_BASE(MAP_BASE), .MAP_SHIFT(MAP_SHIFT),
    .OUT_S(OUT_S), .OUT_V(OUT_V), .BRD_DEPTH(BRD_DEPTH), .QOS('0)
  ) u_master (
    .clk_i, .rst_ni,
    .scalar_req_valid_i, .scalar_req_ready_o, .scalar_req_i, .scalar_rsp_valid_o, .scalar_rsp_ready_i, .scalar_rsp_o,
    .vector_req_valid_i, .vector_req_ready_o, .vector_req_i, .vector_rsp_valid_o, .vector_rsp_ready_i, .vector_rsp_o,
    .burst_req_valid_i, .burst_req_ready_o, .burst_req_i, .burst_wdata_valid_i, .burst_wdata_ready_o, .burst_wdata_i,
    .burst_rdata_valid_o, .burst_rdata_ready_i, .burst_rdata_o, .burst_done_valid_o, .burst_done_ready_i, .burst_done_o,
    .req_valid_o(req_in_valid_o), .req_ready_i(req_in_ready_i), .req_pkt_o(req_in_pkt_o),
    .rsp_valid_i(rsp_out_valid_i), .rsp_ready_o(rsp_out_ready_o), .rsp_pkt_i(rsp_out_pkt_i),
    .err_decode_o
  );

  logic m_s_v, m_s_r, m_s_rv, m_s_rr;  sf_scalar_mem_req_t m_s_q;  sf_scalar_mem_rsp_t m_s_p;
  logic m_v_v, m_v_r, m_v_rv, m_v_rr;  sf_vector_mem_req_t m_v_q;  sf_vector_mem_rsp_t m_v_p;
  logic m_b_v, m_b_r;   sf_burst_desc_t m_b_q;
  logic m_bw_v, m_bw_r; sf_burst_wbeat_t m_bw;
  logic m_br_v, m_br_r; sf_burst_rbeat_t m_br;
  logic m_bd_v, m_bd_r; sf_burst_done_t m_bd;

  sf_noc_mem_target_ni #(
    .MY_ID(MY_ID), .REQ_DEPTH(REQ_DEPTH), .CTX_DEPTH(CTX_DEPTH), .RSP_DEPTH(RSP_DEPTH), .HAS_CNT(HAS_CNT)
  ) u_target (
    .clk_i, .rst_ni,
    .req_valid_i(req_out_valid_i), .req_ready_o(req_out_ready_o), .req_pkt_i(req_out_pkt_i),
    .rsp_valid_o(rsp_in_valid_o), .rsp_ready_i(rsp_in_ready_i), .rsp_pkt_o(rsp_in_pkt_o),
    .m_scalar_req_valid_o(m_s_v), .m_scalar_req_ready_i(m_s_r), .m_scalar_req_o(m_s_q),
    .m_scalar_rsp_valid_i(m_s_rv), .m_scalar_rsp_ready_o(m_s_rr), .m_scalar_rsp_i(m_s_p),
    .m_vector_req_valid_o(m_v_v), .m_vector_req_ready_i(m_v_r), .m_vector_req_o(m_v_q),
    .m_vector_rsp_valid_i(m_v_rv), .m_vector_rsp_ready_o(m_v_rr), .m_vector_rsp_i(m_v_p),
    .m_burst_req_valid_o(m_b_v), .m_burst_req_ready_i(m_b_r), .m_burst_req_o(m_b_q),
    .m_burst_wdata_valid_o(m_bw_v), .m_burst_wdata_ready_i(m_bw_r), .m_burst_wdata_o(m_bw),
    .m_burst_rdata_valid_i(m_br_v), .m_burst_rdata_ready_o(m_br_r), .m_burst_rdata_i(m_br),
    .m_burst_done_valid_i(m_bd_v), .m_burst_done_ready_o(m_bd_r), .m_burst_done_i(m_bd),
    .cnt_rd_addr_o, .cnt_rd_plane_o, .cnt_rd_data_i, .cnt_clear_o, .cnt_freeze_o,
    .err_msg_drop_o(), .err_frame_o()
  );

  memory_controller #(
    .SPM_BASE(MAP_BASE + (sf_paddr_t'(TILE) << MAP_SHIFT)), .NUM_BANKS(NUM_BANKS), .BANK_DEPTH(BANK_DEPTH),
    .SCALAR_LINES(SCALAR_LINES), .BURST_MAX_BEATS(BURST_MAX_BEATS)
  ) u_mc (
    .clk_i, .rst_ni, .flush_i(1'b0), .burst_kill_i(1'b0),
    .scalar_req_valid_i(m_s_v), .scalar_req_ready_o(m_s_r), .scalar_req_i(m_s_q),
    .scalar_rsp_valid_o(m_s_rv), .scalar_rsp_ready_i(m_s_rr), .scalar_rsp_o(m_s_p),
    .vector_req_valid_i(m_v_v), .vector_req_ready_o(m_v_r), .vector_req_i(m_v_q),
    .vector_rsp_valid_o(m_v_rv), .vector_rsp_ready_i(m_v_rr), .vector_rsp_o(m_v_p),
    .burst_req_valid_i(m_b_v), .burst_req_ready_o(m_b_r), .burst_req_i(m_b_q),
    .burst_wdata_valid_i(m_bw_v), .burst_wdata_ready_o(m_bw_r), .burst_wdata_i(m_bw),
    .burst_rdata_valid_o(m_br_v), .burst_rdata_ready_i(m_br_r), .burst_rdata_o(m_br),
    .burst_done_valid_o(m_bd_v), .burst_done_ready_i(m_bd_r), .burst_done_o(m_bd),
    .coh_wr_valid_o(), .coh_wr_addr_o(), .init_done_o, .busy_o(), .bank_conflict_o()
  );
endmodule : sf_noc_mem_node
