// =============================================================================
//  tb_noc.sv - SilicaFlux NoC self-checking verification + traffic laboratory
//
//  One top for functional tests and performance runs.
//     +TEST=<name|all|perf>   (default all)
//     +SEED=<n>               deterministic seed (default 1)
//  Parameters (override with verilator -G): MESH_X MESH_Y BUF_DEPTH
//     FLITS_PER_PKT QOS_ARB_EN FABRIC (0 = mesh noc_interconnect, 1 = crossbar)
//
//  Independent checker (does not trust DUT assertions):
//     * every injected flit is recorded by (src tile, per-source counter)
//     * every ejected flit must match a live record bit-exactly   (integrity)
//     * must be delivered at the tile its dst_id names            (routing)
//     * must not already have been delivered                      (duplication)
//     * must have been injected                                   (phantom)
//     * per (src,dst) delivery must be in injection order         (ordering)
//     * at quiescence nothing may remain live                     (loss)
//     * ejection valid/payload must be stable while stalled       (stability)
//  Stimulus is a behavioural traffic generator: it is test equipment, not RTL.
// =============================================================================
`timescale 1ns/1ps

module tb_noc;
  import silicaflux_pkg::*;

  parameter int unsigned MESH_X        = 2;
  parameter int unsigned MESH_Y        = 2;
  parameter int unsigned BUF_DEPTH     = 4;
  parameter int unsigned FLITS_PER_PKT = 1;
  parameter bit          QOS_ARB_EN    = 1'b0;
  parameter int unsigned FABRIC        = 0;
  parameter int unsigned WDOG          = 0;   // router progress watchdog (0 = off)
  parameter bit          EXPLICIT_FRAMING = 1'b0;
  parameter int unsigned QOS_LIMIT     = 0;    // QOS_STARVE_LIMIT
  parameter int unsigned VARLEN        = 4;    // max flits/packet in explicit-framing mode

  localparam int unsigned NT     = MESH_X * MESH_Y;
  localparam int unsigned SLOTS  = 1024;      // in-flight window per source
  localparam int unsigned XW     = (MESH_X > 1) ? $clog2(MESH_X) : 1;
  localparam int unsigned MAXCY  = 4_000_000; // global safety net
  localparam int unsigned YW     = (MESH_Y > 1) ? $clog2(MESH_Y) : 1;
  localparam int unsigned COORD_W = XW + YW;
  // an invalid destination can only be forged if some ID encoding is unused
  localparam bit HAS_BAD_DST = (MESH_X < (1 << XW)) || (MESH_Y < (1 << YW)) || (SF_NOC_ID_W > COORD_W);

  // --------------------------------------------------------------------------
  // Clock / reset / DUT
  // --------------------------------------------------------------------------
  logic clk = 1'b0;
  logic rst_n;
  always #5 clk = ~clk;

  logic        [NT-1:0] inj_valid;
  logic        [NT-1:0] inj_ready;
  noc_packet_t [NT-1:0] inj_pkt;
  logic        [NT-1:0] ej_valid;
  logic        [NT-1:0] ej_ready;
  noc_packet_t [NT-1:0] ej_pkt;
  logic        [NT-1:0][4:0] perf_link_stall;
  logic        [NT-1:0][4:0] perf_hol_block;
  logic                      noc_idle;

  logic        [NT-1:0]      err_drop, err_drop_head;
  logic        [NT-1:0][2:0] err_cause;
  localparam int unsigned BWC = $clog2(BUF_DEPTH + 1);
  logic        [NT-1:0][4:0]        t_in_fire, t_in_head, t_out_fire, t_out_head;
  logic        [NT-1:0][4:0][4:0]   t_sa_req, t_sa_gnt;
  logic        [NT-1:0][4:0][BWC-1:0] t_buf;
  noc_packet_t [NT-1:0][4:0]        t_out_pkt;
  logic                              cnt_clear = 1'b0;
  logic        [15:0]                cnt_addr  = 16'h0;
  logic        [31:0]                cnt_data;
  logic                              cnt_ovf;
  localparam bit HAVE_CNT =
`ifdef SF_TB_ORIGINAL
      1'b0;
`else
      (FABRIC == 0);
`endif

  if (FABRIC == 0) begin : g_mesh
    noc_interconnect #(
      .pkt_t(noc_packet_t), .MESH_X(MESH_X), .MESH_Y(MESH_Y), .BUF_DEPTH(BUF_DEPTH),
      .FLITS_PER_PKT(FLITS_PER_PKT), .QOS_ARB_EN(QOS_ARB_EN),
      .PROGRESS_WDOG_CYCLES(WDOG)
`ifndef SF_TB_ORIGINAL
      , .EXPLICIT_FRAMING(EXPLICIT_FRAMING), .QOS_STARVE_LIMIT(QOS_LIMIT)
`endif
    ) u_dut (
      .clk_i(clk), .rst_ni(rst_n),
      .tile_inj_valid_i(inj_valid), .tile_inj_pkt_i(inj_pkt), .tile_inj_ready_o(inj_ready),
      .tile_ej_valid_o(ej_valid),   .tile_ej_pkt_o(ej_pkt),   .tile_ej_ready_i(ej_ready),
      .perf_link_stall_o(perf_link_stall), .perf_hol_block_o(perf_hol_block),
`ifndef SF_TB_ORIGINAL
      .err_drop_o(err_drop), .err_drop_head_o(err_drop_head), .err_cause_o(err_cause),
      .perf_in_fire_o(t_in_fire), .perf_in_head_o(t_in_head), .perf_out_fire_o(t_out_fire),
      .perf_out_head_o(t_out_head), .perf_sa_req_o(t_sa_req), .perf_sa_gnt_o(t_sa_gnt),
      .perf_buf_count_o(t_buf), .perf_out_pkt_o(t_out_pkt),
`endif
      .noc_idle_o(noc_idle)
    );
`ifdef SF_TB_ORIGINAL
    assign err_drop = '0; assign err_drop_head = '0; assign err_cause = '0;
`endif
  end else begin : g_xbar
    sf_noc_xbar #(
      .NUM_TILES(NT), .MESH_X(MESH_X), .MESH_Y(MESH_Y), .BUF_DEPTH(BUF_DEPTH)
    ) u_dut (
      .clk_i(clk), .rst_ni(rst_n),
      .tile_inj_valid_i(inj_valid), .tile_inj_pkt_i(inj_pkt), .tile_inj_ready_o(inj_ready),
      .tile_ej_valid_o(ej_valid),   .tile_ej_pkt_o(ej_pkt),   .tile_ej_ready_i(ej_ready),
      .noc_idle_o(noc_idle),
      .err_drop_o(err_drop), .err_cause_o(err_cause),
      .perf_in_fire_o(), .perf_out_fire_o(), .perf_sa_req_o(), .perf_sa_gnt_o(), .perf_buf_count_o()
    );
    assign err_drop_head = err_drop;
    assign perf_link_stall = '0;
    assign perf_hol_block  = '0;
    assign t_in_fire = '0; assign t_in_head = '0; assign t_out_fire = '0; assign t_out_head = '0;
    assign t_sa_req = '0; assign t_sa_gnt = '0; assign t_buf = '0; assign t_out_pkt = '0;
  end

`ifndef SF_TB_ORIGINAL
  if (FABRIC == 0) begin : g_cnt
    sf_noc_traffic_counters #(
      .MESH_X(MESH_X), .MESH_Y(MESH_Y), .BUF_DEPTH(BUF_DEPTH), .LAT_IDX_W(8), .LAT_EN(1'b1)
    ) u_cnt (
      .clk_i(clk), .rst_ni(rst_n), .ctrl_clear_i(cnt_clear), .ctrl_freeze_i(1'b0),
      .inj_valid_i(inj_valid), .inj_ready_i(inj_ready), .inj_pkt_i(inj_pkt),
      .ej_valid_i(ej_valid), .ej_ready_i(ej_ready), .ej_pkt_i(ej_pkt),
      .in_fire_i(t_in_fire), .in_head_i(t_in_head), .out_fire_i(t_out_fire), .out_head_i(t_out_head),
      .link_stall_i(perf_link_stall), .hol_block_i(perf_hol_block),
      .sa_req_i(t_sa_req), .sa_gnt_i(t_sa_gnt), .buf_count_i(t_buf), .out_pkt_i(t_out_pkt),
      .err_drop_i(err_drop), .err_drop_head_i(err_drop_head), .err_cause_i(err_cause),
      .rd_addr_i(cnt_addr), .rd_data_o(cnt_data), .ovf_o(cnt_ovf)
    );
  end
`endif

  // --------------------------------------------------------------------------
  // Utilities
  // --------------------------------------------------------------------------
  function automatic logic [31:0] xs32(input logic [31:0] s);
    logic [31:0] x;
    x = s;
    x = x ^ (x << 13);
    x = x ^ (x >> 17);
    x = x ^ (x << 5);
    return x;
  endfunction

  function automatic sf_noc_id_t tid(input int unsigned t);
    return sf_noc_id(t % MESH_X, t / MESH_X, MESH_X);
  endfunction

  // forge a destination ID that names no tile (x out of range, y out of range,
  // or bits above the coordinate field - whichever the mesh geometry allows)
  function automatic sf_noc_id_t make_bad_dst(input sf_noc_id_t id);
    int unsigned v;
    v = int'(id);
    if (MESH_X < (1 << XW))             return sf_noc_id_t'(((v >> XW) << XW) | MESH_X);
    else if (MESH_Y < (1 << YW))        return sf_noc_id_t'((MESH_Y << XW) | (v & ((1 << XW) - 1)));
    else if (SF_NOC_ID_W > COORD_W)     return sf_noc_id_t'(v | (1 << COORD_W));
    else                                return id;
  endfunction

  function automatic int unsigned hops(input int unsigned a, input int unsigned b);
    int ax, ay, bx, by;
    ax = a % MESH_X; ay = a / MESH_X; bx = b % MESH_X; by = b / MESH_X;
    return (ax > bx ? ax - bx : bx - ax) + (ay > by ? ay - by : by - ay);
  endfunction

  // --------------------------------------------------------------------------
  // Test configuration (written by the sequencer between clock edges)
  // --------------------------------------------------------------------------
  int unsigned cfg_left   [NT];   // packets still to generate
  int unsigned cfg_rate   [NT];   // inject probability numerator /256
  int          cfg_dst    [NT];   // fixed destination (mode 0)
  int          cfg_dmode;         // 0 fixed, 1 uniform incl self, 2 uniform excl self, 3 hotspot
  int unsigned cfg_hot;           // hotspot tile
  int unsigned cfg_hotpct;        // hotspot probability /256
  int          cfg_ejmode [NT];   // 0 always, 1 random(rate), 2 blocked, 3 periodic
  int unsigned cfg_ejrate [NT];
  int unsigned cfg_ejper  [NT];
  int unsigned cfg_qos_mode;      // 0 random, 1 per-tile fixed (tile 0 = hi), 2 all low
  int unsigned cfg_bad_mode;      // 0 none; 1 inject bad-dst; 2 reserved class; 3 valid=0
  int unsigned cfg_bad_pct;       // probability /256 that a generated packet is "bad"
  int unsigned cfg_multi;         // 1 = emit FLITS_PER_PKT flits per packet (wormhole)
  bit          cfg_open;          // open-loop arrivals into source queues (performance runs)

  localparam int unsigned ARRQ = 4096;                 // source queue depth (open loop)
  longint unsigned arr_q   [NT][ARRQ];
  int unsigned     arr_wr  [NT];
  int unsigned     arr_rd  [NT];
  longint unsigned gen_arr [NT];                       // arrival time of the packet on inj_pkt
  longint unsigned arr_in_win [NT];                    // arrivals inside the measurement window
  longint unsigned src_ovf [NT];                       // arrivals refused: source queue full (saturated)
  longint unsigned sb_arr  [NT][SLOTS];
  longint unsigned tlat_sum;                           // total latency: arrival -> ejection
  bit              meas_active;
  logic [31:0] rng      [NT];
  logic [31:0] seed;

  // generator state
  int unsigned gen_cnt  [NT];          // per-source packet counter (28b used)
  int unsigned gen_flit [NT];          // flit index within current packet
  logic [31:0] cur_dst  [NT];
  int unsigned cur_len  [NT];          // flits in the packet being generated
  bit          pkt_bad  [NT];          // scoreboard: current packet is expected to be rejected

  // --------------------------------------------------------------------------
  // Scoreboard state
  // --------------------------------------------------------------------------
  noc_packet_t    sb_pkt   [NT][SLOTS];
  bit             sb_live  [NT][SLOTS];
  longint unsigned sb_t0   [NT][SLOTS];
  int unsigned    sb_dst   [NT][SLOTS];
  int unsigned    last_ord [NT][NT];       // last delivered counter+1 per (src,dst)
  bit             ord_seen [NT][NT];

  longint unsigned cycle;
  longint unsigned n_inj, n_ej, n_inj_flits, n_ej_flits;
  longint unsigned n_drop_expected;
  longint unsigned n_drop_seen;
  int unsigned     errors, total_errors, err_print;
  int unsigned     outstanding;
  longint unsigned inj_by_src [NT];
  longint unsigned ej_by_src  [NT];        // delivered, indexed by source
  longint unsigned ej_by_dst  [NT];
  longint unsigned ej_pair    [NT][NT];
  longint unsigned lat_sum, lat_max, lat_cnt, lat_min;
  longint unsigned lat_hist   [16];        // log2 buckets
  longint unsigned lat_sum_pair [NT][NT];
  longint unsigned lat_cnt_pair [NT][NT];
  int unsigned     last_ej_flit_pkt [NT];  // wormhole contiguity tracking
  bit              in_pkt_at_ej [NT];
  int              lat_fd;
  bit              lat_log;
  longint unsigned last_progress_cycle;

  // ejection stability tracking
  logic        prev_ej_stall [NT];
  noc_packet_t prev_ej_pkt   [NT];

  task automatic err(input string msg);
    errors++;
    total_errors++;
    if (err_print < 25) begin
      $display("ERROR @%0t cy=%0d: %s", $time, cycle, msg);
      err_print++;
    end
  endtask

  // --------------------------------------------------------------------------
  // Cycle counter
  // --------------------------------------------------------------------------
  always @(posedge clk) cycle <= cycle + 1;

  // --------------------------------------------------------------------------
  // Injector (per tile)
  // --------------------------------------------------------------------------
  for (genvar t = 0; t < NT; t++) begin : g_tb_tile

    function automatic noc_packet_t build(input int unsigned src, input int unsigned dstt,
                                          input logic [31:0] r1, input logic [31:0] r2,
                                          input logic [31:0] r3, input logic [31:0] r4,
                                          input int unsigned cnt, input int unsigned fidx,
                                          input bit sop, input bit eop);
      noc_packet_t p;
      logic [31:0] seq;
      seq = {src[3:0], cnt[27:0]};
      p = '0;
      p.valid  = 1'b1;
      p.sop    = sop;
      p.eop    = eop;
      p.pclass = sf_noc_class_e'(r1[2:0] % 5);          // legal classes only
      case (cfg_qos_mode)
        1:       p.qos = (src == 0) ? 2'b10 : 2'b00;
        2:       p.qos = 2'b00;
        default: p.qos = r1[4:3];
      endcase
      p.dst_id = tid(dstt);
      p.src_id = tid(src);
      p.txn_id = seq[7:0];
      p.status = sf_mem_exc_e'(r1[7:5]);
      p.xfer   = sf_noc_xfer_e'(r1[9:8]);
      p.hint   = sf_mem_hint_e'(r1[11:10]);
      p.addr   = r2;
      p.be     = r1[31:16];
      p.data   = {r3, r4, ~seq ^ {16'(fidx), 16'hC0DE}, seq};
      return p;
    endfunction

    always @(posedge clk or negedge rst_n) begin : p_inj
      logic [31:0] a, b, c, d, e, f;
      int unsigned dstt;
      int unsigned plen;
      bit accepted;
      bit make_bad;
      bit gen_ok;
      noc_packet_t p;
      if (!rst_n) begin
        inj_valid[t] <= 1'b0;
        inj_pkt[t]   <= '0;
        gen_flit[t]  <= 0;
        arr_wr[t]    = 0;
        arr_rd[t]    = 0;
      end else begin
        a = xs32(rng[t]); b = xs32(a); c = xs32(b); d = xs32(c); e = xs32(d); f = xs32(e);
        rng[t] <= f;                                  // the stream advances every cycle
        accepted = inj_valid[t] && inj_ready[t];

        // open-loop arrival process: Bernoulli(rate/256) arrivals into a source queue
        if (cfg_open && (a[31:24] < cfg_rate[t][7:0] || cfg_rate[t] >= 256)) begin
          if (arr_wr[t] - arr_rd[t] < ARRQ - 1) begin
            arr_q[t][arr_wr[t] % ARRQ] = cycle;
            arr_wr[t] = arr_wr[t] + 1;
            arr_in_win[t]++;
          end else begin
            src_ovf[t]++;
          end
        end

        if (!inj_valid[t] || accepted) begin
          // a started packet is always completed (a truncated wormhole packet
          // would legitimately wedge an output lock); new packets need budget
          if (cfg_open)
            gen_ok = (arr_wr[t] != arr_rd[t]);
          else
            gen_ok = (gen_flit[t] != 0 || cfg_left[t] > 0) && (a[15:8] < cfg_rate[t][7:0] || cfg_rate[t] >= 256);
          if (gen_ok) begin
            // destination and length are chosen on the head flit
            if (gen_flit[t] == 0) begin
              case (cfg_dmode)
                0:       dstt = (cfg_dst[t] < 0) ? t : cfg_dst[t];
                1:       dstt = b % NT;
                2:       dstt = (NT > 1) ? ((t + 1 + (b % (NT - 1))) % NT) : t;
                3:       dstt = (c[7:0] < cfg_hotpct[7:0] || cfg_hotpct >= 256) ? cfg_hot : (b % NT);
                default: dstt = t;
              endcase
              cur_dst[t] <= dstt;
              plen = (cfg_multi == 0) ? 1 : (EXPLICIT_FRAMING ? (1 + (e % VARLEN)) : FLITS_PER_PKT);
              cur_len[t] <= plen;
              if (cfg_open) begin
                gen_arr[t] <= arr_q[t][arr_rd[t] % ARRQ];
                arr_rd[t] = arr_rd[t] + 1;
              end else begin
                gen_arr[t] <= cycle;
              end
            end else begin
              dstt = cur_dst[t];
              plen = cur_len[t];
            end
            p = build(t, dstt, c, d, e, f, gen_cnt[t],
                      gen_flit[t],
                      (gen_flit[t] == 0),
                      (gen_flit[t] == plen - 1));
            make_bad = (cfg_bad_mode != 0) && (a[23:16] < cfg_bad_pct[7:0]) && gen_flit[t] == 0;
            if (make_bad) begin
              case (cfg_bad_mode)
                1: p.dst_id = make_bad_dst(p.dst_id);
                2: p.pclass = SF_NOC_RSVD6;
                3: p.valid  = 1'b0;
                4: p.src_id = p.src_id ^ sf_noc_id_t'(1);
                default: ;
              endcase
            end
            inj_valid[t] <= 1'b1;
            inj_pkt[t]   <= p;
            if (gen_flit[t] != plen - 1) begin
              gen_flit[t] <= gen_flit[t] + 1;
            end else begin
              gen_flit[t] <= 0;
              if (!cfg_open && cfg_left[t] != 0) cfg_left[t] <= cfg_left[t] - 1;
            end
            gen_cnt[t] <= gen_cnt[t] + 1;
          end else begin
            inj_valid[t] <= 1'b0;
          end
        end
      end
    end

    // Ejection sink: ready policy
    always @(posedge clk or negedge rst_n) begin : p_ej
      logic [31:0] a;
      if (!rst_n) begin
        ej_ready[t] <= 1'b1;
      end else begin
        a = xs32(rng[t] ^ 32'hA5A5_1234 ^ cycle[31:0]);
        case (cfg_ejmode[t])
          0:       ej_ready[t] <= 1'b1;
          1:       ej_ready[t] <= (a[15:8] < cfg_ejrate[t][7:0]) || (cfg_ejrate[t] >= 256);
          2:       ej_ready[t] <= 1'b0;
          3:       ej_ready[t] <= (cfg_ejper[t] == 0) ? 1'b1 : ((cycle % cfg_ejper[t]) == 0);
          default: ej_ready[t] <= 1'b1;
        endcase
      end
    end
  end

  // --------------------------------------------------------------------------
  // Scoreboard / monitors (sampled on the clock edge, before NBA update)
  // --------------------------------------------------------------------------
  always @(posedge clk) begin : p_sb
    noc_packet_t p, q;
    int unsigned s, slot, d, cnt;
    longint unsigned lat;
    if (rst_n) begin
      for (int t = 0; t < NT; t++) begin
        // ---- injection accept -------------------------------------------------
        if (inj_valid[t] && inj_ready[t]) begin
          p    = inj_pkt[t];
          cnt  = int'(p.data[27:0]);
          slot = cnt % SLOTS;
          n_inj_flits++;
          if (p.eop) n_inj++;
          inj_by_src[t]++;
          // A packet with a deliberately invalid header is expected to be
          // rejected whole: the head decides, body flits inherit the verdict.
          if (p.sop) begin
            pkt_bad[t] = !(p.valid && sf_noc_class_legal(p.pclass) && (p.src_id == tid(t)) &&
                           ((32'(p.dst_id) >> XW) < MESH_Y) &&
                           ((32'(p.dst_id) & ((1 << XW) - 1)) < MESH_X) &&
                           ((32'(p.dst_id) >> (XW + ((MESH_Y > 1) ? $clog2(MESH_Y) : 1))) == 0));
          end
          if (!pkt_bad[t]) begin
            if (sb_live[t][slot]) err($sformatf("src %0d slot %0d reused while live (earlier packet lost)", t, slot));
            sb_pkt[t][slot]  = p;
            sb_live[t][slot] = 1'b1;
            sb_t0[t][slot]   = cycle;
            sb_arr[t][slot]  = cfg_open ? gen_arr[t] : cycle;
            sb_dst[t][slot]  = sf_noc_tile_index(p.dst_id, MESH_X);
            outstanding++;
          end else begin
            n_drop_expected++;
          end
        end
        if (err_drop[t]) n_drop_seen++;
        // ---- ejection ----------------------------------------------------------
        if (ej_valid[t] && ej_ready[t]) begin
          q   = ej_pkt[t];
          s   = int'(q.data[31:28]);
          cnt = int'(q.data[27:0]);
          slot = cnt % SLOTS;
          n_ej_flits++;
          if (q.eop) n_ej++;
          last_progress_cycle = cycle;
          if (s >= NT) begin
            err($sformatf("phantom flit at tile %0d (src field %0d)", t, s));
          end else if (!sb_live[s][slot]) begin
            err($sformatf("tile %0d: flit src %0d cnt %0d not live (duplicate or phantom)", t, s, cnt));
          end else begin
            if (q !== sb_pkt[s][slot])
              err($sformatf("tile %0d: payload corruption src %0d cnt %0d", t, s, cnt));
            if (sb_dst[s][slot] != t)
              err($sformatf("MISROUTE: src %0d cnt %0d delivered to tile %0d, wanted %0d", s, cnt, t, sb_dst[s][slot]));
            if (sf_noc_tile_index(q.dst_id, MESH_X) != t)
              err($sformatf("tile %0d: delivered flit names dst_id %0d", t, q.dst_id));
            if (ord_seen[s][t] && cnt < last_ord[s][t])
              err($sformatf("ORDER: src %0d -> dst %0d cnt %0d after %0d", s, t, cnt, last_ord[s][t]));
            ord_seen[s][t] = 1'b1;
            last_ord[s][t] = cnt;
            sb_live[s][slot] = 1'b0;
            outstanding--;
            lat = cycle - sb_t0[s][slot];
            tlat_sum += cycle - sb_arr[s][slot];
            lat_sum += lat; lat_cnt++;
            if (lat > lat_max) lat_max = lat;
            if (lat < lat_min) lat_min = lat;
            lat_hist[(lat == 0) ? 0 : ((lat >= 32768) ? 15 : $clog2(lat + 1))]++;
            ej_by_src[s]++; ej_by_dst[t]++; ej_pair[s][t]++;
            lat_sum_pair[s][t] += lat; lat_cnt_pair[s][t]++;
            if (lat_log && meas_active) $fdisplay(lat_fd, "%0d,%0d,%0d,%0d,%0d,%0d,%0d", s, t, sb_arr[s][slot], sb_t0[s][slot], cycle, lat, cycle - sb_arr[s][slot]);
          end
          // wormhole: flits of one packet must be contiguous at the ejection port
          if ((FLITS_PER_PKT > 1 || EXPLICIT_FRAMING) && cfg_multi != 0) begin
            if (in_pkt_at_ej[t] && q.sop) err($sformatf("tile %0d: new packet began inside a packet", t));
            if (!in_pkt_at_ej[t] && !q.sop) err($sformatf("tile %0d: body flit without head", t));
            in_pkt_at_ej[t] = !q.eop;
          end
        end
        // ---- ejection stability under stall ------------------------------------
        if (prev_ej_stall[t]) begin
          if (!ej_valid[t]) err($sformatf("tile %0d: ej_valid dropped under stall", t));
          else if (ej_pkt[t] !== prev_ej_pkt[t]) err($sformatf("tile %0d: ej payload changed under stall", t));
        end
        prev_ej_stall[t] = ej_valid[t] && !ej_ready[t];
        prev_ej_pkt[t]   = ej_pkt[t];
      end
    end else begin
      // reset: everything in flight is legitimately discarded
      for (int t = 0; t < NT; t++) begin
        for (int k = 0; k < SLOTS; k++) sb_live[t][k] = 1'b0;
        prev_ej_stall[t] = 1'b0;
        in_pkt_at_ej[t]  = 1'b0;
        pkt_bad[t]       = 1'b0;
      end
      outstanding = 0;
    end
  end

  // --------------------------------------------------------------------------
  // Sequencer helpers
  // --------------------------------------------------------------------------
  string cur_test;
  bit skip_cnt_check;
  int unsigned test_err0;
  int unsigned n_pass, n_fail;

  task automatic cfg_defaults();
    for (int t = 0; t < NT; t++) begin
      cfg_left[t]   = 0;
      cfg_rate[t]   = 256;
      cfg_dst[t]    = -1;
      cfg_ejmode[t] = 0;
      cfg_ejrate[t] = 256;
      cfg_ejper[t]  = 0;
    end
    cfg_dmode    = 0;
    cfg_hot      = 0;
    cfg_hotpct   = 256;
    cfg_qos_mode = 0;
    cfg_bad_mode = 0;
    cfg_bad_pct  = 0;
    cfg_multi    = (FLITS_PER_PKT > 1 || EXPLICIT_FRAMING) ? 1 : 0;
    cfg_open     = 1'b0;
    meas_active  = 1'b0;
  endtask

  task automatic clear_stats();
    n_inj = 0; n_ej = 0; n_inj_flits = 0; n_ej_flits = 0; n_drop_expected = 0; n_drop_seen = 0;
    lat_sum = 0; lat_max = 0; lat_cnt = 0; lat_min = 64'hFFFF_FFFF; tlat_sum = 0;
    for (int k = 0; k < 16; k++) lat_hist[k] = 0;
    for (int s = 0; s < NT; s++) begin
      inj_by_src[s] = 0; ej_by_src[s] = 0; ej_by_dst[s] = 0; arr_in_win[s] = 0; src_ovf[s] = 0;
      for (int d = 0; d < NT; d++) begin
        ej_pair[s][d] = 0; lat_sum_pair[s][d] = 0; lat_cnt_pair[s][d] = 0;
        last_ord[s][d] = 0; ord_seen[s][d] = 1'b0;
      end
    end
  endtask

  task automatic do_reset(input int unsigned cycles);
    @(negedge clk);
    rst_n = 1'b0;
    repeat (cycles) @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);
  endtask

  task automatic begin_test(input string name);
    cur_test = name;
    test_err0 = total_errors;
    err_print = 0;
    cfg_defaults();
    clear_stats();
    do_reset(3);
    last_progress_cycle = cycle;
  endtask

  task automatic end_test();
    check_counters();
    skip_cnt_check = 1'b0;
    if (total_errors == test_err0) begin
      n_pass++;
      $display("TEST %-28s PASS  (inj=%0d ej=%0d cycles=%0d)", cur_test, n_inj, n_ej, cycle);
    end else begin
      n_fail++;
      $display("TEST %-28s FAIL  (%0d errors)", cur_test, total_errors - test_err0);
    end
  endtask

  function automatic bit all_injected();
    for (int t = 0; t < NT; t++) if (cfg_left[t] != 0 || inj_valid[t]) return 1'b0;
    return 1'b1;
  endfunction

  // Run until all stimulus is injected and everything is delivered.
  // On timeout (no ejection for `stall_limit` cycles with work pending) it
  // reports a stall: the signature of deadlock or loss.
  task automatic run_to_drain(input int unsigned stall_limit, output bit drained);
    int unsigned guard;
    drained = 1'b0;
    guard = 0;
    forever begin
      @(negedge clk);
      guard++;
      if (all_injected() && outstanding == 0 && noc_idle) begin
        drained = 1'b1;
        break;
      end
      if (cycle - last_progress_cycle > stall_limit && (outstanding > 0 || !all_injected())) begin
        break;
      end
      if (guard > MAXCY) break;
    end
    repeat (4) @(negedge clk);
  endtask

  task automatic drain_check(input int unsigned stall_limit = 20000);
    bit ok;
    run_to_drain(stall_limit, ok);
    if (!ok) begin
      err($sformatf("NO PROGRESS: %0d packets still outstanding, injection %s (deadlock or loss)",
                    outstanding, all_injected() ? "complete" : "incomplete"));
    end else if (outstanding != 0) begin
      err($sformatf("%0d packets outstanding after drain", outstanding));
    end
    if (ok && !noc_idle) err("noc_idle low after drain");
  endtask

  task automatic set_all_dst_perm(input int unsigned kind);
    for (int t = 0; t < NT; t++) begin
      case (kind)
        0: cfg_dst[t] = t;                         // local loopback
        1: cfg_dst[t] = (t + 1) % NT;              // rotate
        2: cfg_dst[t] = NT - 1 - t;                // bit-complement (diagonal on 2x2)
        3: cfg_dst[t] = (t % MESH_X) * MESH_Y + (t / MESH_X); // transpose
        default: cfg_dst[t] = t;
      endcase
    end
    cfg_dmode = 0;
  endtask

  // --------------------------------------------------------------------------
  // Counter read-back and independent cross-check against the scoreboard
  // --------------------------------------------------------------------------

  task automatic rdc(input logic [15:0] a, output logic [31:0] v);
    cnt_addr = a;
    #0.001;          // 1 ps: lets the combinational read settle but never lets a clock edge intervene,
                      // so reading the counters cannot perturb the experiment (a #1 here once skewed cycle counts)
    v = cnt_data;
  endtask

  // metric ids (mirror sf_noc_traffic_counters)
  localparam int M_FLITS_IN = 0, M_PKTS_IN = 1, M_FLITS_OUT = 2, M_PKTS_OUT = 3, M_PAY_OUT = 4,
                 M_RAW_OUT = 5, M_LINK_STALL = 6, M_ARB_BLOCK = 7, M_ARB_LOSE = 8, M_HOL = 9,
                 M_OCC_SUM = 10, M_OCC_MAX = 11;
  localparam int T_INJ_FLITS = 0, T_INJ_PKTS = 1, T_INJ_STALL = 2, T_EJ_FLITS = 3, T_EJ_PKTS = 4,
                 T_EJ_STALL = 5, T_DROP_FLITS = 6, T_DROP_PKTS = 7, T_DST_CUR = 11, T_DST_MAX = 12;

  task automatic check_counters();
`ifndef SF_TB_ORIGINAL
    logic [31:0] v, w;
    longint unsigned s_inj, s_ej, s_drop, s_in_all, s_out_all, s_cur, s_ejp, s_injp;
    longint unsigned occ_max_seen, bufmax;
    if (!HAVE_CNT || skip_cnt_check) return;
    s_inj = 0; s_ej = 0; s_drop = 0; s_in_all = 0; s_out_all = 0; s_cur = 0; s_ejp = 0; s_injp = 0;
    for (int t = 0; t < NT; t++) begin
      rdc(16'h2000 | (T_INJ_FLITS << 8) | t, v);  s_inj += v;
      rdc(16'h2000 | (T_EJ_FLITS  << 8) | t, v);  s_ej  += v;
      rdc(16'h2000 | (T_DROP_FLITS<< 8) | t, v);  s_drop += v;
      rdc(16'h2000 | (T_DST_CUR   << 8) | t, v);  s_cur += v;
      rdc(16'h2000 | (T_EJ_PKTS   << 8) | t, v);  s_ejp += v;
      rdc(16'h2000 | (T_INJ_PKTS  << 8) | t, v);  s_injp += v;
      for (int p = 0; p < 5; p++) begin
        rdc(16'h1000 | (M_FLITS_IN  << 8) | (t << 3) | p, v); s_in_all  += v;
        rdc(16'h1000 | (M_FLITS_OUT << 8) | (t << 3) | p, v); s_out_all += v;
        rdc(16'h1000 | (M_OCC_MAX   << 8) | (t << 3) | p, v);
        if (v > BUF_DEPTH) err($sformatf("counters: router %0d port %0d OCC_MAX %0d exceeds BUF_DEPTH", t, p, v));
      end
    end
    if (s_inj  != n_inj_flits) err($sformatf("counters: INJ_FLITS %0d != scoreboard %0d", s_inj, n_inj_flits));
    if (s_ej   != n_ej_flits)  err($sformatf("counters: EJ_FLITS %0d != scoreboard %0d", s_ej, n_ej_flits));
    if (s_drop != n_drop_seen) err($sformatf("counters: DROP_FLITS %0d != observed %0d", s_drop, n_drop_seen));
    if (s_injp != n_inj)       err($sformatf("counters: INJ_PKTS %0d != scoreboard packets %0d", s_injp, n_inj));
    if (s_ejp  != n_ej)        err($sformatf("counters: EJ_PKTS %0d != scoreboard packets %0d", s_ejp, n_ej));
    if (outstanding == 0 && noc_idle) begin
      if (s_cur != 0) err($sformatf("counters: DST_INFLIGHT sums to %0d at drain (must be 0)", s_cur));
      // flit conservation across the whole fabric: accepted into buffers == transferred out of output registers
      if (s_in_all != s_out_all)
        err($sformatf("counters: FLITS_IN %0d != FLITS_OUT %0d over all ports (conservation)", s_in_all, s_out_all));
    end
    // latency (single-flit packets only: the counters time head flits, the scoreboard times every flit)
    if (FLITS_PER_PKT == 1 && !EXPLICIT_FRAMING) begin
      logic [31:0] c0, s0, mn, mx, col, unm;
      rdc(16'h3000, c0); rdc(16'h3001, s0); rdc(16'h3002, mn); rdc(16'h3003, mx);
      rdc(16'h0005, col); rdc(16'h0006, unm);
      if (c0 != lat_cnt) err($sformatf("counters: latency count %0d != scoreboard %0d", c0, lat_cnt));
      if (s0 != lat_sum) err($sformatf("counters: latency sum %0d != scoreboard %0d", s0, lat_sum));
      if (lat_cnt != 0 && mn != lat_min) err($sformatf("counters: latency min %0d != %0d", mn, lat_min));
      if (lat_cnt != 0 && mx != lat_max) err($sformatf("counters: latency max %0d != %0d", mx, lat_max));
      if (col != 0 || unm != 0) err($sformatf("counters: latency correlation errors collide=%0d unmatched=%0d", col, unm));
    end
    rdc(16'h0004, v);
    if (v != 0) err("counters: overflow flag set");
`endif
  endtask

  // ==========================================================================
  // Directed tests
  // ==========================================================================
  task automatic t_reset_state();
    begin_test("reset_state");
    repeat (6) @(negedge clk);
    if (|ej_valid) err("ej_valid set after reset");
    if (!noc_idle) err("noc_idle not set after reset");
    if (~&inj_ready) err("inj_ready not all-ones after reset (buffers must be empty)");
    end_test();
  endtask

  task automatic t_zero_load_all_pairs();
    int unsigned exp;
    begin_test("all_pairs_zero_load");
    for (int s = 0; s < NT; s++) begin
      for (int d = 0; d < NT; d++) begin
        longint unsigned lsum0, lcnt0, inj0, ep0;
        for (int t = 0; t < NT; t++) cfg_left[t] = 0;
        cfg_dmode = 0; cfg_dst[s] = d; cfg_left[s] = 1;
        lsum0 = lat_sum; lcnt0 = lat_cnt; inj0 = inj_by_src[s]; ep0 = ej_pair[s][d];
        drain_check(2000);
        // every flit of the (possibly multi-flit) packet must be delivered with the
        // zero-load latency: flits are pipelined, so each one sees the same latency
        if (lat_cnt - lcnt0 != inj_by_src[s] - inj0 || lat_cnt == lcnt0) begin
          err($sformatf("pair %0d->%0d: %0d flits injected, %0d delivered", s, d, inj_by_src[s] - inj0, lat_cnt - lcnt0));
        end else begin
          exp = (FABRIC == 0) ? 2 * (hops(s, d) + 1) : 2;
          $display("ZL,fabric=%0d,src=%0d,dst=%0d,hops=%0d,latency=%0d,expected=%0d", FABRIC, s, d, hops(s, d),
                   (lat_sum - lsum0) / (lat_cnt - lcnt0), exp);
          if (lat_sum - lsum0 != exp * (lat_cnt - lcnt0))
            err($sformatf("zero-load latency %0d->%0d = %0d per flit, expected %0d", s, d,
                          (lat_sum - lsum0) / (lat_cnt - lcnt0), exp));
        end
        if (ej_pair[s][d] - ep0 != inj_by_src[s] - inj0) err($sformatf("pair %0d->%0d: delivery count mismatch", s, d));
      end
    end
    end_test();
  endtask

  task automatic t_local_delivery();
    begin_test("local_delivery");
    set_all_dst_perm(0);
    for (int t = 0; t < NT; t++) cfg_left[t] = 50;
    drain_check();
    for (int t = 0; t < NT; t++) if (ej_pair[t][t] != inj_by_src[t]) err($sformatf("tile %0d local count %0d of %0d", t, ej_pair[t][t], inj_by_src[t]));
    end_test();
  endtask

  task automatic t_one_hop();
    begin_test("one_hop");
    // every tile sends to each X/Y neighbour
    for (int t = 0; t < NT; t++) begin
      for (int d = 0; d < NT; d++) begin
        if (hops(t, d) == 1) begin
          cfg_dmode = 0; cfg_dst[t] = d; cfg_left[t] = 20;
          drain_check();
          cfg_left[t] = 0;
        end
      end
    end
    end_test();
  endtask

  task automatic t_diagonal();
    begin_test("diagonal");
    for (int t = 0; t < NT; t++) begin
      int unsigned d;
      d = NT - 1 - t;
      cfg_dmode = 0; cfg_dst[t] = d; cfg_left[t] = 40;   // all diagonals at once
    end
    drain_check();
    end_test();
  endtask

  task automatic t_simultaneous_permutations();
    begin_test("simultaneous_permutations");
    for (int k = 1; k <= 3; k++) begin
      set_all_dst_perm(k);
      for (int t = 0; t < NT; t++) cfg_left[t] = 200;
      drain_check();
    end
    end_test();
  endtask

  task automatic t_all_pairs_simultaneous();
    begin_test("all_pairs_simultaneous");
    cfg_dmode = 1;                      // uniform incl. self, full rate
    for (int t = 0; t < NT; t++) cfg_left[t] = 1500;
    drain_check();
    for (int s = 0; s < NT; s++) for (int d = 0; d < NT; d++)
      if (ej_pair[s][d] == 0) err($sformatf("pair %0d->%0d never exercised", s, d));
    end_test();
  endtask

  task automatic t_bidirectional();
    begin_test("bidirectional");
    // swap partners simultaneously: s <-> NT-1-s and neighbours
    for (int k = 0; k < 2; k++) begin
      for (int t = 0; t < NT; t++) begin
        cfg_dmode = 0;
        cfg_dst[t] = (k == 0) ? (NT - 1 - t) : (((t ^ 1) < NT) ? (t ^ 1) : t);
        cfg_left[t] = 400;
      end
      drain_check();
    end
    end_test();
  endtask

  task automatic t_hotspot_fairness();
    longint unsigned mn, mx;
    begin_test("all_to_one_hotspot");
    cfg_dmode = 3; cfg_hot = 0; cfg_hotpct = 256;       // everyone -> tile 0
    for (int t = 0; t < NT; t++) cfg_left[t] = 600;
    // slow the sink so the network saturates and contention is sustained
    cfg_ejmode[0] = 1; cfg_ejrate[0] = 96;
    drain_check(100000);
    mn = 64'hFFFF_FFFF_FFFF; mx = 0;
    for (int s = 0; s < NT; s++) begin
      if (ej_by_src[s] < mn) mn = ej_by_src[s];
      if (ej_by_src[s] > mx) mx = ej_by_src[s];
      if (ej_by_src[s] != inj_by_src[s]) err($sformatf("src %0d delivered %0d of %0d", s, ej_by_src[s], inj_by_src[s]));
    end
    $display("      hotspot: lowest-served src %0d, highest %0d flits (each must equal its injected count)", mn, mx);
    end_test();
  endtask

  task automatic t_random_backpressure();
    begin_test("random_backpressure");
    cfg_dmode = 1;
    for (int t = 0; t < NT; t++) begin
      cfg_left[t]   = 2500;
      cfg_rate[t]   = 180;
      cfg_ejmode[t] = 1;
      cfg_ejrate[t] = 80 + 30 * t;
    end
    drain_check(50000);
    end_test();
  endtask

  task automatic t_periodic_backpressure();
    begin_test("periodic_backpressure");
    cfg_dmode = 2;
    for (int t = 0; t < NT; t++) begin
      cfg_left[t] = 800; cfg_ejmode[t] = 3; cfg_ejper[t] = 3 + 2 * t;
    end
    drain_check(50000);
    end_test();
  endtask

  task automatic t_queue_saturation();
    int unsigned stuck_ready;
    begin_test("queue_saturation");
    cfg_dmode = 2;
    for (int t = 0; t < NT; t++) begin cfg_left[t] = 600; cfg_ejmode[t] = 2; end   // every sink blocked
    repeat (600) @(negedge clk);
    // network must have back-pressured the injectors: some inj_ready low, nothing lost
    if (&inj_ready) err("no back-pressure reached the injectors with all sinks blocked");
    if (n_ej != 0) err("flit ejected while sinks were blocked");
    for (int t = 0; t < NT; t++) cfg_ejmode[t] = 0;                                // release
    drain_check(50000);
    end_test();
  endtask

  task automatic t_reset_during_traffic();
    begin_test("reset_during_traffic");
    skip_cnt_check = 1'b1;
    cfg_dmode = 1;
    for (int t = 0; t < NT; t++) begin cfg_left[t] = 100000; cfg_rate[t] = 256; cfg_ejmode[t] = 1; cfg_ejrate[t] = 100; end
    repeat (300) @(negedge clk);
    // reset hits while flits are in buffers, egress registers and links
    @(negedge clk); rst_n = 1'b0;
    repeat (2) @(negedge clk);
    if (|ej_valid && 1'b0) err("unreachable");
    repeat (2) @(negedge clk);
    if (|ej_valid) err("ej_valid asserted during reset");
    for (int t = 0; t < NT; t++) cfg_left[t] = 0;
    rst_n = 1'b1;
    @(negedge clk); @(negedge clk);
    if (!noc_idle) err("noc not idle after reset deassert (stale flits survived reset)");
    if (~&inj_ready) err("inj_ready low after reset");
    // fresh traffic must be clean (no stale flits delivered => no phantoms)
    clear_stats();
    for (int t = 0; t < NT; t++) begin cfg_left[t] = 300; cfg_ejmode[t] = 0; cfg_rate[t] = 256; end
    drain_check();
    end_test();
  endtask

  task automatic t_multiple_resets();
    begin_test("repeated_reset_cycles");
    skip_cnt_check = 1'b1;
    for (int r = 0; r < 5; r++) begin
      cfg_dmode = 1;
      for (int t = 0; t < NT; t++) begin cfg_left[t] = 100000; cfg_rate[t] = 256; cfg_ejmode[t] = 0; end
      repeat (40 + 7 * r) @(negedge clk);
      for (int t = 0; t < NT; t++) cfg_left[t] = 0;
      @(negedge clk); rst_n = 1'b0; repeat (1 + r) @(negedge clk); rst_n = 1'b1;
      @(negedge clk);
      if (!noc_idle) err($sformatf("reset %0d: not idle", r));
    end
    for (int t = 0; t < NT; t++) begin cfg_left[t] = 200; cfg_rate[t] = 256; end
    drain_check();
    end_test();
  endtask

  task automatic t_invalid_dest();
    bit ok;
    begin_test("invalid_destination");
    if (!HAS_BAD_DST) begin
      $display("      SKIP: every ID encoding names a valid tile in this mesh (no invalid destination exists)");
      end_test();
      return;
    end
    // 25% of packets carry a destination outside the mesh. A correct fabric
    // keeps delivering the good traffic, never wedges, never mis-delivers
    // (scoreboard flags any flit that was not expected) and reports every
    // rejected packet.
    cfg_dmode = 2; cfg_bad_mode = 1; cfg_bad_pct = 64;
    for (int t = 0; t < NT; t++) cfg_left[t] = 400;
    run_to_drain(3000, ok);
    if (!ok) err($sformatf("FABRIC WEDGED by invalid destination (%0d valid packets stranded)", outstanding));
`ifndef SF_TB_ORIGINAL
    if (n_drop_seen != n_drop_expected)
      err($sformatf("drop accounting: DUT reported %0d rejected, %0d bad packets were injected", n_drop_seen, n_drop_expected));
    if (n_drop_expected == 0) err("test invalid: no bad packets generated");
    $display("      rejected %0d of %0d injected packets (bad dst), good traffic %0d/%0d delivered",
             n_drop_seen, n_inj, n_ej, n_inj - n_drop_expected);
`endif
    end_test();
  endtask

  task automatic t_reserved_class();
    bit ok;
    begin_test("reserved_class_and_invalid_pkt");
    cfg_dmode = 2; cfg_bad_mode = 2; cfg_bad_pct = 64;
    for (int t = 0; t < NT; t++) cfg_left[t] = 200;
    run_to_drain(3000, ok);
    if (!ok) err($sformatf("FABRIC WEDGED by reserved class (%0d stranded)", outstanding));
`ifndef SF_TB_ORIGINAL
    if (n_drop_seen != n_drop_expected)
      err($sformatf("reserved-class drops: DUT %0d vs injected %0d", n_drop_seen, n_drop_expected));
`endif
    cfg_bad_mode = 3;
    for (int t = 0; t < NT; t++) cfg_left[t] = 200;
    run_to_drain(3000, ok);
    if (!ok) err($sformatf("FABRIC WEDGED by valid=0 packet (%0d stranded)", outstanding));
`ifndef SF_TB_ORIGINAL
    if (n_drop_seen != n_drop_expected)
      err($sformatf("valid=0 drops: DUT %0d vs injected %0d", n_drop_seen, n_drop_expected));
`endif
    end_test();
  endtask

  task automatic t_bad_source();
    bit ok;
    begin_test("spoofed_source_id");
    cfg_dmode = 2; cfg_bad_mode = 4; cfg_bad_pct = 64;
    for (int t = 0; t < NT; t++) cfg_left[t] = 200;
    run_to_drain(3000, ok);
    if (!ok) err($sformatf("FABRIC WEDGED by spoofed source (%0d stranded)", outstanding));
`ifndef SF_TB_ORIGINAL
    if (n_drop_seen != n_drop_expected)
      err($sformatf("spoofed-src drops: DUT %0d vs injected %0d", n_drop_seen, n_drop_expected));
`endif
    end_test();
  endtask

  task automatic t_qos_starvation();
    longint unsigned lo_mid, hi_mid, lo_sum;
    int unsigned i0;
    begin_test("qos_class_starvation");
    // Tile 0 is the high-priority class; all others low. All -> tile NT-1,
    // so they contend for one output. Sample at 2000 cycles, while tile 0
    // still has >1000 packets left, so a strict-priority arbiter that never
    // yields is exposed rather than hidden by the stream ending.
    cfg_qos_mode = 1; cfg_dmode = 0;
    for (int t = 0; t < NT; t++) begin cfg_dst[t] = NT - 1; cfg_left[t] = 4000; end
    cfg_left[NT-1] = 0;
    repeat (2000) @(negedge clk);
    hi_mid = ej_by_src[0];
    lo_sum = 0;
    for (int t = 1; t < NT - 1; t++) lo_sum += ej_by_src[t];
    $display("      @2000 cycles (hi stream active): hi(src0)=%0d  low-class total=%0d  (low srcs: %0d)",
             hi_mid, lo_sum, NT - 2);
    if (cfg_left[0] == 0) err("test invalid: high-priority stream ended before the sample point");
    // Requirement: the low class must keep a bounded share. With
    // QOS_STARVE_LIMIT=K a waiting low flit is served after at most K high
    // grants, so the low class gets >= 1/(K+1) of a contended output; we demand
    // half of that bound (slack for the multi-hop topology). Strict priority
    // (K=0) is required to deliver at least 5% and is reported as starvation
    // when it does not.
    begin : qos_bound
      longint unsigned need;
      need = (QOS_LIMIT > 0) ? (2000 / (2 * (QOS_LIMIT + 1))) : 100;
      if (QOS_ARB_EN && lo_sum < need)
        err($sformatf("LOW-PRIORITY STARVATION: low class got %0d of 2000 cycles (need >= %0d)", lo_sum, need));
    end
    for (int t = 0; t < NT; t++) cfg_left[t] = 0;
    drain_check(100000);
    end_test();
  endtask

  task automatic t_wormhole();
    begin_test("wormhole_multiflit");
    cfg_dmode = 1;
    for (int t = 0; t < NT; t++) begin cfg_left[t] = 300; cfg_ejmode[t] = 1; cfg_ejrate[t] = 160; end
    drain_check(50000);
    end_test();
  endtask

  task automatic t_long_random(input int unsigned n);
    begin_test("long_random_mixed");
    for (int ph = 0; ph < 6; ph++) begin
      cfg_dmode = 1 + (ph % 3);
      cfg_hot = ph % NT; cfg_hotpct = 128;
      for (int t = 0; t < NT; t++) begin
        cfg_left[t]   = n;
        cfg_rate[t]   = 64 + 32 * ((t + ph) % 7);
        cfg_ejmode[t] = (ph + t) % 3;       // 0 always, 1 random, 2 blocked -> fixed below
        if (cfg_ejmode[t] == 2) cfg_ejmode[t] = 3;
        cfg_ejrate[t] = 64 + 40 * ((t + ph) % 5);
        cfg_ejper[t]  = 2 + ((t + ph) % 5);
      end
      if (ph == 3) cfg_dmode = 3;
      drain_check(100000);
    end
    end_test();
  endtask

  // ==========================================================================
  // Performance phase: one (pattern, rate) point, machine-readable output
  // ==========================================================================
  string pat_name;
  int unsigned p_rate, p_warmc, p_meas, p_hot, p_hotpct, p_ejrate, p_qos, p_dump;
  string latfile;
  string mname [12] = '{"FLITS_IN","PKTS_IN","FLITS_OUT","PKTS_OUT","PAYLOAD_BYTES_OUT","RAW_BYTES_OUT",
                        "LINK_STALL","ARB_BLOCKED","ARB_LOSE","HOL_BLOCK","OCC_SUM","OCC_MAX"};
  string tname [15] = '{"INJ_FLITS","INJ_PKTS","INJ_STALL","EJ_FLITS","EJ_PKTS","EJ_STALL","DROP_FLITS",
                        "DROP_PKTS","DROP_DST","DROP_CLS","DROP_SRC","DST_INFLIGHT_CUR","DST_INFLIGHT_MAX",
                        "DST_INFLIGHT_SUM","DST_CONG_CYCLES"};

  task automatic dump_counters();
`ifndef SF_TB_ORIGINAL
    logic [31:0] v, v2, v3, v4;
    if (!HAVE_CNT) return;
    rdc(16'h0002, v); $display("CNT,cycles,%0d", v);
    for (int m = 0; m < 12; m++)
      for (int r = 0; r < NT; r++)
        for (int pp = 0; pp < 5; pp++) begin
          rdc(16'h1000 | (m << 8) | (r << 3) | pp, v);
          if (v != 0) $display("CNT,rp,%s,%0d,%0d,%0d", mname[m], r, pp, v);
        end
    for (int m = 0; m < 15; m++)
      for (int t = 0; t < NT; t++) begin
        rdc(16'h2000 | (m << 8) | t, v);
        if (v != 0) $display("CNT,tile,%s,%0d,%0d", tname[m], t, v);
      end
    for (int k = 0; k < 2; k++) begin
      rdc(16'h3000 | (k << 8) | 0, v);  rdc(16'h3000 | (k << 8) | 1, v2);
      rdc(16'h3000 | (k << 8) | 2, v3); rdc(16'h3000 | (k << 8) | 3, v4);
      $display("CNT,lat,%0d,cnt=%0d,sum=%0d,min=%0d,max=%0d", k, v, v2, v3, v4);
    end
    rdc(16'h0005, v); rdc(16'h0006, v2);
    $display("CNT,latcheck,collide=%0d,unmatched=%0d", v, v2);
`endif
  endtask

  // One open-loop load point: warm up, then measure over a fixed window.
  task automatic t_perf();
    longint unsigned c0, win, ej_win, inj_win, arr_win, ovf, backlog;
    begin_test("perf");
    skip_cnt_check = 1'b1;
    cfg_open = 1'b1;
    case (pat_name)
      "uniform":    cfg_dmode = 1;
      "uniform_ne": cfg_dmode = 2;
      "hotspot":    begin cfg_dmode = 3; cfg_hot = p_hot; cfg_hotpct = p_hotpct; end
      "allto1":     begin cfg_dmode = 3; cfg_hot = p_hot; cfg_hotpct = 256; end
      "transpose":  set_all_dst_perm(3);
      "complement": set_all_dst_perm(2);
      "neighbor":   set_all_dst_perm(1);
      "local":      set_all_dst_perm(0);
      default:      cfg_dmode = 1;
    endcase
    cfg_open = 1'b1;
    cfg_qos_mode = p_qos;
    for (int t = 0; t < NT; t++) begin
      cfg_rate[t]   = p_rate;
      cfg_ejmode[t] = (p_ejrate >= 256) ? 0 : 1;
      cfg_ejrate[t] = p_ejrate;
    end
    repeat (p_warmc) @(negedge clk);
    // ---- measurement window ------------------------------------------------
    clear_stats();
    meas_active = 1'b1;
    cnt_clear = 1'b1;
    @(negedge clk);
    cnt_clear = 1'b0;
    c0 = cycle;
    repeat (p_meas) @(negedge clk);
    win = cycle - c0;
    ej_win = 0; inj_win = 0; arr_win = 0; ovf = 0; backlog = 0;
    for (int t = 0; t < NT; t++) begin
      ej_win += ej_by_src[t]; inj_win += inj_by_src[t]; arr_win += arr_in_win[t]; ovf += src_ovf[t];
      backlog += arr_wr[t] - arr_rd[t];
    end
    $display("PERF,fabric=%0d,mx=%0d,my=%0d,depth=%0d,flits=%0d,qos=%0d,pattern=%s,rate=%0d,ejrate=%0d,seed=%0d,window=%0d,arrivals=%0d,accepted=%0d,delivered=%0d,backlog=%0d,src_ovf=%0d,net_lat_x1000=%0d,tot_lat_x1000=%0d,errors=%0d",
             FABRIC, MESH_X, MESH_Y, BUF_DEPTH, FLITS_PER_PKT, QOS_ARB_EN, pat_name, p_rate, p_ejrate, seed, win,
             arr_win, inj_win, ej_win, backlog, ovf,
             (lat_cnt == 0) ? 0 : (lat_sum * 1000 / lat_cnt), (lat_cnt == 0) ? 0 : (tlat_sum * 1000 / lat_cnt),
             total_errors - test_err0);
    for (int s = 0; s < NT; s++)
      $display("PERF_SRC,src=%0d,delivered=%0d,accepted=%0d,arrivals=%0d", s, ej_by_src[s], inj_by_src[s], arr_in_win[s]);
    for (int d = 0; d < NT; d++)
      $display("PERF_DST,dst=%0d,delivered=%0d", d, ej_by_dst[d]);
    for (int s = 0; s < NT; s++) for (int d = 0; d < NT; d++)
      if (lat_cnt_pair[s][d] != 0)
        $display("PERF_PAIR,src=%0d,dst=%0d,n=%0d,lat_sum=%0d", s, d, lat_cnt_pair[s][d], lat_sum_pair[s][d]);
    if (p_dump != 0) dump_counters();
    meas_active = 1'b0;
    end_test();
  endtask

  // ==========================================================================
  // Main sequence
  // ==========================================================================
  string testname;
  int unsigned seed_i;
  string skiplist;
  function automatic bit want(input string n);
    if (testname == "all") return 1'b1;
    return (testname == n);
  endfunction
  initial begin
    rst_n = 1'b0;
    cycle = 0; total_errors = 0; errors = 0; err_print = 0; n_pass = 0; n_fail = 0; outstanding = 0;
    lat_log = 1'b0;
    for (int t = 0; t < NT; t++) begin gen_cnt[t] = 0; gen_flit[t] = 0; prev_ej_stall[t] = 0; in_pkt_at_ej[t] = 0; end
    if (!$value$plusargs("TEST=%s", testname)) testname = "all";
    if (!$value$plusargs("SEED=%d", seed_i)) seed_i = 1;
    seed = seed_i;
    for (int t = 0; t < NT; t++) rng[t] = xs32(seed ^ (32'h9E3779B9 * (t + 1))) | 32'd1;
    if ($value$plusargs("LATFILE=%s", latfile)) begin lat_fd = $fopen(latfile, "w"); lat_log = (lat_fd != 0); end
    if (!$value$plusargs("PAT=%s", pat_name)) pat_name = "uniform";
    if (!$value$plusargs("RATE=%d", p_rate))   p_rate = 256;
    if (!$value$plusargs("WARMC=%d", p_warmc)) p_warmc = 2000;
    if (!$value$plusargs("MEAS=%d", p_meas))   p_meas = 20000;
    if (!$value$plusargs("HOT=%d", p_hot))     p_hot = 0;
    if (!$value$plusargs("HOTPCT=%d", p_hotpct)) p_hotpct = 128;
    if (!$value$plusargs("EJRATE=%d", p_ejrate)) p_ejrate = 256;
    if (!$value$plusargs("QOS=%d", p_qos))     p_qos = 0;
    if (!$value$plusargs("DUMP=%d", p_dump))   p_dump = 0;
    cfg_defaults();
    clear_stats();
    $display("CONFIG fabric=%0d mesh=%0dx%0d depth=%0d flits=%0d qos_arb=%0d seed=%0d test=%s",
             FABRIC, MESH_X, MESH_Y, BUF_DEPTH, FLITS_PER_PKT, QOS_ARB_EN, seed, testname);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);

    if (testname == "perf") begin
      t_perf();
    end else begin
      if (want("reset_state"))                t_reset_state();
      if (want("all_pairs_zero_load"))        t_zero_load_all_pairs();
      if (want("local_delivery"))             t_local_delivery();
      if (want("one_hop"))                    t_one_hop();
      if (want("diagonal"))                   t_diagonal();
      if (want("simultaneous_permutations"))  t_simultaneous_permutations();
      if (want("all_pairs_simultaneous"))     t_all_pairs_simultaneous();
      if (want("bidirectional"))              t_bidirectional();
      if (want("all_to_one_hotspot"))         t_hotspot_fairness();
      if (want("random_backpressure"))        t_random_backpressure();
      if (want("periodic_backpressure"))      t_periodic_backpressure();
      if (want("queue_saturation"))           t_queue_saturation();
      if (want("reset_during_traffic"))       t_reset_during_traffic();
      if (want("repeated_reset_cycles"))      t_multiple_resets();
      if ((FLITS_PER_PKT > 1 || EXPLICIT_FRAMING) && want("wormhole_multiflit")) t_wormhole();
      if (want("qos_class_starvation"))       t_qos_starvation();
      if (want("invalid_destination"))        t_invalid_dest();
      if (want("reserved_class_and_invalid_pkt")) t_reserved_class();
      if (want("spoofed_source_id"))         t_bad_source();
      if (want("long_random_mixed"))          t_long_random(400);
    end

    $display("SUMMARY tests_passed=%0d tests_failed=%0d total_errors=%0d", n_pass, n_fail, total_errors);
    if (lat_log) $fclose(lat_fd);
    if (n_fail == 0 && total_errors == 0) begin
      $display("RESULT: PASS");
      $finish;
    end else begin
      $display("RESULT: FAIL");
      $fatal(1, "tb_noc: %0d tests failed", n_fail);
    end
  end

  // global safety net
  initial begin
    #(10 * 400_000_000);
    $display("RESULT: FAIL (global timeout)");
    $fatal(1, "global timeout");
  end

endmodule
