// =============================================================================
//  tb_noc_sys.sv - system-level verification: tiles <-> NoC <-> real SRAM
//
//  4 tiles on the 2x2 fabric. Every tile has
//     initiator agent --> sf_noc_mem_master_ni --(req net)--> sf_noc_mem_target_ni --> memory_controller (REAL RTL)
//                     <-- ...                  <-(rsp net)--                      <--
//  so every memory (shared / local scratchpad) is reachable from every tile, local
//  accesses included, through the network. The initiator agents are behavioural
//  stimulus; everything between them and the SRAM array is RTL.
//
//  Checking: shadow memory per target, updated in program order. Each initiator
//  (port, tile) owns a disjoint address region, and every port is in-order, so a
//  read must return exactly what the shadow holds at issue time. Responses are
//  matched in order: tag, op, status and data (enabled bytes / lanes / beats).
//
//     +TEST=<name|all>  +SEED=<n>
//  Parameters (-G): SEP (1 = separate request/response networks, 0 = one shared
//  network), BUFD, REQ_Q, RSP_Q, CTX_Q, OUT_S, OUT_V, BRD
// =============================================================================
`timescale 1ns/1ps

module tb_noc_sys;
  import silicaflux_pkg::*;

  parameter bit          SEP   = 1'b1;
  parameter int unsigned BUFD  = 4;
  parameter int unsigned REQ_Q = 4;
  parameter int unsigned RSP_Q = 4;
  parameter int unsigned CTX_Q = 8;
  parameter int unsigned OUT_S = 4;
  parameter int unsigned OUT_V = 4;
  parameter int unsigned BRD   = 16;

  localparam int unsigned MX = 2, MY = 2, NT = 4;
  localparam sf_paddr_t  MAP_BASE  = 32'h1000_0000;
  localparam int unsigned MAP_SHIFT = 20;
  // memory geometry: 4 banks x 64 lines x 16 B = 4 KiB per tile
  localparam int unsigned NB = 4, BD = 64, SCL = 64, TOT_LINES = NB * BD;
  localparam int unsigned BURST_MAX = 16, PAGE_B = 1024;

  // --------------------------------------------------------------------------
  logic clk = 1'b0;
  logic rst_n;
  always #5 clk = ~clk;
  longint unsigned cycle;
  always @(posedge clk) cycle <= cycle + 1;

  // --------------------------------------------------------------------------
  // fabric wiring
  // --------------------------------------------------------------------------
  logic        [NT-1:0] f_req_in_v, f_req_in_r, f_req_out_v, f_req_out_r;
  logic        [NT-1:0] f_rsp_in_v, f_rsp_in_r, f_rsp_out_v, f_rsp_out_r;
  noc_packet_t [NT-1:0] f_req_in_p, f_req_out_p, f_rsp_in_p, f_rsp_out_p;
  logic                 noc_idle;
  logic        [NT-1:0] err_drop;
  logic                 cnt_clear, cnt_freeze, cnt_ovf;
  logic                 fab_rd_plane;
  logic [15:0]          fab_rd_addr;
  logic [31:0]          fab_rd_data;
  // counter read mux: NoC control window (tile 0) or direct testbench read
  logic [15:0]          tni_rd_addr;  logic tni_rd_plane;
  logic                 tb_direct = 1'b0;
  logic [15:0]          tb_rd_addr = 16'h0;  logic tb_rd_plane = 1'b0;
  logic                 tni_clear, tni_freeze;
  assign fab_rd_addr  = tb_direct ? tb_rd_addr  : tni_rd_addr;
  assign fab_rd_plane = tb_direct ? tb_rd_plane : tni_rd_plane;
  assign cnt_clear    = tni_clear;
  assign cnt_freeze   = tni_freeze;

  sf_noc_fabric #(
    .MESH_X(MX), .MESH_Y(MY), .BUF_DEPTH(BUFD), .SEPARATE_RSP(SEP), .EXPLICIT_FRAMING(1'b1),
    .CNT_EN(1'b1), .LAT_IDX_W(8)
  ) u_fab (
    .clk_i(clk), .rst_ni(rst_n),
    .req_in_valid_i(f_req_in_v), .req_in_pkt_i(f_req_in_p), .req_in_ready_o(f_req_in_r),
    .req_out_valid_o(f_req_out_v), .req_out_pkt_o(f_req_out_p), .req_out_ready_i(f_req_out_r),
    .rsp_in_valid_i(f_rsp_in_v), .rsp_in_pkt_i(f_rsp_in_p), .rsp_in_ready_o(f_rsp_in_r),
    .rsp_out_valid_o(f_rsp_out_v), .rsp_out_pkt_o(f_rsp_out_p), .rsp_out_ready_i(f_rsp_out_r),
    .noc_idle_o(noc_idle), .err_drop_o(err_drop),
    .ctrl_clear_i(cnt_clear), .ctrl_freeze_i(cnt_freeze), .rd_plane_i(fab_rd_plane),
    .rd_addr_i(fab_rd_addr), .rd_data_o(fab_rd_data), .ovf_o(cnt_ovf)
  );

  // --------------------------------------------------------------------------
  // per-tile signal arrays (agent side of the master NI)
  // --------------------------------------------------------------------------
  logic                 s_req_v [NT];  logic s_req_r [NT];  sf_scalar_mem_req_t s_req [NT];
  logic                 s_rsp_v [NT];  logic s_rsp_r [NT];  sf_scalar_mem_rsp_t s_rsp [NT];
  logic                 v_req_v [NT];  logic v_req_r [NT];  sf_vector_mem_req_t v_req [NT];
  logic                 v_rsp_v [NT];  logic v_rsp_r [NT];  sf_vector_mem_rsp_t v_rsp [NT];
  logic                 b_req_v [NT];  logic b_req_r [NT];  sf_burst_desc_t     b_req [NT];
  logic                 b_wd_v  [NT];  logic b_wd_r  [NT];  sf_burst_wbeat_t    b_wd  [NT];
  logic                 b_rd_v  [NT];  logic b_rd_r  [NT];  sf_burst_rbeat_t    b_rd  [NT];
  logic                 b_dn_v  [NT];  logic b_dn_r  [NT];  sf_burst_done_t     b_dn  [NT];
  logic                 mni_err [NT];

  // raw packet injection (control registers, partial lanes, MSG, orphans)
  logic        [NT-1:0] raw_en = '0;
  logic        [NT-1:0] raw_v  = '0;
  noc_packet_t          raw_p [NT];
  logic        [NT-1:0] mni_req_v, mni_req_r;
  noc_packet_t [NT-1:0] mni_req_p;

  // controller <-> target NI
  logic mc_init [NT];
  logic diag_pulse = 1'b0;                       // toggled to make every tile print its buffer state

  for (genvar t = 0; t < NT; t++) begin : g_tile
    localparam sf_noc_id_t MY_ID = sf_noc_id(t % MX, t / MX, MX);

    logic mni_rsp_r;
    sf_noc_mem_master_ni #(
      .NUM_TILES(NT), .MESH_X(MX), .MY_ID(MY_ID), .MAP_BASE(MAP_BASE), .MAP_SHIFT(MAP_SHIFT),
      .OUT_S(OUT_S), .OUT_V(OUT_V), .BRD_DEPTH(BRD), .QOS(2'b00)
    ) u_mni (
      .clk_i(clk), .rst_ni(rst_n),
      .scalar_req_valid_i(s_req_v[t]), .scalar_req_ready_o(s_req_r[t]), .scalar_req_i(s_req[t]),
      .scalar_rsp_valid_o(s_rsp_v[t]), .scalar_rsp_ready_i(s_rsp_r[t]), .scalar_rsp_o(s_rsp[t]),
      .vector_req_valid_i(v_req_v[t]), .vector_req_ready_o(v_req_r[t]), .vector_req_i(v_req[t]),
      .vector_rsp_valid_o(v_rsp_v[t]), .vector_rsp_ready_i(v_rsp_r[t]), .vector_rsp_o(v_rsp[t]),
      .burst_req_valid_i(b_req_v[t]), .burst_req_ready_o(b_req_r[t]), .burst_req_i(b_req[t]),
      .burst_wdata_valid_i(b_wd_v[t]), .burst_wdata_ready_o(b_wd_r[t]), .burst_wdata_i(b_wd[t]),
      .burst_rdata_valid_o(b_rd_v[t]), .burst_rdata_ready_i(b_rd_r[t]), .burst_rdata_o(b_rd[t]),
      .burst_done_valid_o(b_dn_v[t]), .burst_done_ready_i(b_dn_r[t]), .burst_done_o(b_dn[t]),
      .req_valid_o(mni_req_v[t]), .req_ready_i(mni_req_r[t]), .req_pkt_o(mni_req_p[t]),
      .rsp_valid_i(f_rsp_out_v[t]), .rsp_ready_o(mni_rsp_r), .rsp_pkt_i(f_rsp_out_p[t]),
      .err_decode_o(mni_err[t])
    );

    // injection mux: master NI or raw injector
    assign f_rsp_out_r[t] = mni_rsp_r;                // master NI sinks every response (credit reservation)
    assign f_req_in_v[t]  = raw_en[t] ? raw_v[t] : mni_req_v[t];
    assign f_req_in_p[t]  = raw_en[t] ? raw_p[t] : mni_req_p[t];
    assign mni_req_r[t]   = raw_en[t] ? 1'b0 : f_req_in_r[t];

    // target side
    logic                tni_rsp_v, tni_rsp_r;
    noc_packet_t         tni_rsp_p;
    logic                m_s_v, m_s_r, m_s_rv, m_s_rr;  sf_scalar_mem_req_t m_s_q;  sf_scalar_mem_rsp_t m_s_p;
    logic                m_v_v, m_v_r, m_v_rv, m_v_rr;  sf_vector_mem_req_t m_v_q;  sf_vector_mem_rsp_t m_v_p;
    logic                m_b_v, m_b_r;  sf_burst_desc_t m_b_q;
    logic                m_bw_v, m_bw_r; sf_burst_wbeat_t m_bw;
    logic                m_br_v, m_br_r; sf_burst_rbeat_t m_br;
    logic                m_bd_v, m_bd_r; sf_burst_done_t m_bd;
    logic [15:0]         c_addr;  logic c_plane;  logic c_clear, c_freeze;
    logic                e_msg, e_frame;

    sf_noc_mem_target_ni #(
      .MY_ID(MY_ID), .REQ_DEPTH(REQ_Q), .CTX_DEPTH(CTX_Q), .RSP_DEPTH(RSP_Q), .HAS_CNT(t == 0)
    ) u_tni (
      .clk_i(clk), .rst_ni(rst_n),
      .req_valid_i(f_req_out_v[t]), .req_ready_o(f_req_out_r[t]), .req_pkt_i(f_req_out_p[t]),
      .rsp_valid_o(tni_rsp_v), .rsp_ready_i(tni_rsp_r), .rsp_pkt_o(tni_rsp_p),
      .m_scalar_req_valid_o(m_s_v), .m_scalar_req_ready_i(m_s_r), .m_scalar_req_o(m_s_q),
      .m_scalar_rsp_valid_i(m_s_rv), .m_scalar_rsp_ready_o(m_s_rr), .m_scalar_rsp_i(m_s_p),
      .m_vector_req_valid_o(m_v_v), .m_vector_req_ready_i(m_v_r), .m_vector_req_o(m_v_q),
      .m_vector_rsp_valid_i(m_v_rv), .m_vector_rsp_ready_o(m_v_rr), .m_vector_rsp_i(m_v_p),
      .m_burst_req_valid_o(m_b_v), .m_burst_req_ready_i(m_b_r), .m_burst_req_o(m_b_q),
      .m_burst_wdata_valid_o(m_bw_v), .m_burst_wdata_ready_i(m_bw_r), .m_burst_wdata_o(m_bw),
      .m_burst_rdata_valid_i(m_br_v), .m_burst_rdata_ready_o(m_br_r), .m_burst_rdata_i(m_br),
      .m_burst_done_valid_i(m_bd_v), .m_burst_done_ready_o(m_bd_r), .m_burst_done_i(m_bd),
      .cnt_rd_addr_o(c_addr), .cnt_rd_plane_o(c_plane), .cnt_rd_data_i(fab_rd_data),
      .cnt_clear_o(c_clear), .cnt_freeze_o(c_freeze),
      .err_msg_drop_o(e_msg), .err_frame_o(e_frame)
    );
    assign f_rsp_in_v[t]  = tni_rsp_v;
    assign f_rsp_in_p[t]  = tni_rsp_p;
    assign tni_rsp_r      = f_rsp_in_r[t];

    if (t == 0) begin : g_cnt_bridge
      assign tni_rd_addr  = c_addr;
      assign tni_rd_plane = c_plane;
      assign tni_clear    = c_clear;
      assign tni_freeze   = c_freeze;
    end

    // deadlock diagnosis: occupancy of every queue a request or response can be waiting in
    always @(posedge diag_pulse) begin
      $display("DIAG tile %0d | target NI: reqQ %0d/%0d ctx s/v %0d/%0d rspQ s/v/c/b %0d/%0d/%0d/%0d st=%0d | master NI: outstanding s=%0d v=%0d burst_busy=%b | router in-buffers L/N/E/S/W %0d/%0d/%0d/%0d/%0d (cap %0d)",
        t, u_tni.rq_cnt, REQ_Q, u_tni.cs_cnt, u_tni.cv_cnt, u_tni.os_cnt, u_tni.ov_cnt, u_tni.oc_cnt, u_tni.ob_cnt, u_tni.st_q,
        u_mni.s_out_q, u_mni.v_out_q, u_mni.b_busy_q,
        u_fab.g_plane[0].u_net.g_router_x[t % MX].g_router_y[t / MX].u_router.buf_count[0],
        u_fab.g_plane[0].u_net.g_router_x[t % MX].g_router_y[t / MX].u_router.buf_count[1],
        u_fab.g_plane[0].u_net.g_router_x[t % MX].g_router_y[t / MX].u_router.buf_count[2],
        u_fab.g_plane[0].u_net.g_router_x[t % MX].g_router_y[t / MX].u_router.buf_count[3],
        u_fab.g_plane[0].u_net.g_router_x[t % MX].g_router_y[t / MX].u_router.buf_count[4], BUFD);
    end

    memory_controller #(
      .SPM_BASE(MAP_BASE + (t << MAP_SHIFT)), .NUM_BANKS(NB), .BANK_DEPTH(BD), .SCALAR_LINES(SCL),
      .SRAM_LATENCY(1), .BURST_MAX_BEATS(BURST_MAX), .BURST_PAGE_BYTES(PAGE_B)
    ) u_mc (
      .clk_i(clk), .rst_ni(rst_n), .flush_i(1'b0), .burst_kill_i(1'b0),
      .scalar_req_valid_i(m_s_v), .scalar_req_ready_o(m_s_r), .scalar_req_i(m_s_q),
      .scalar_rsp_valid_o(m_s_rv), .scalar_rsp_ready_i(m_s_rr), .scalar_rsp_o(m_s_p),
      .vector_req_valid_i(m_v_v), .vector_req_ready_o(m_v_r), .vector_req_i(m_v_q),
      .vector_rsp_valid_o(m_v_rv), .vector_rsp_ready_i(m_v_rr), .vector_rsp_o(m_v_p),
      .burst_req_valid_i(m_b_v), .burst_req_ready_o(m_b_r), .burst_req_i(m_b_q),
      .burst_wdata_valid_i(m_bw_v), .burst_wdata_ready_o(m_bw_r), .burst_wdata_i(m_bw),
      .burst_rdata_valid_o(m_br_v), .burst_rdata_ready_i(m_br_r), .burst_rdata_o(m_br),
      .burst_done_valid_o(m_bd_v), .burst_done_ready_i(m_bd_r), .burst_done_o(m_bd),
      .coh_wr_valid_o(), .coh_wr_addr_o(),
      .init_done_o(mc_init[t]), .busy_o(), .bank_conflict_o()
    );
  end

  // --------------------------------------------------------------------------
  // utilities
  // --------------------------------------------------------------------------
  function automatic logic [31:0] xs32(input logic [31:0] s);
    logic [31:0] x;
    x = s; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5);
    return x;
  endfunction

  function automatic int unsigned tgt_pick(input int unsigned t, input logic [31:0] r);
    case (tgt_mode)
      1:       return (t + 1) % NT;
      2:       return NT - 1 - t;
      3:       return t ^ 1;
      default: return r % NT;
    endcase
  endfunction

  function automatic sf_paddr_t tile_base(input int unsigned t);
    return MAP_BASE + (t << MAP_SHIFT);
  endfunction

  // --------------------------------------------------------------------------
  // shadow memory (byte accurate) and expectations
  // --------------------------------------------------------------------------
  byte unsigned shadow [int unsigned];

  function automatic byte unsigned sh_rd(input int unsigned a);
    return shadow.exists(a) ? shadow[a] : 8'h00;
  endfunction

  typedef struct {
    bit             is_wr;
    logic [7:0]     tag;
    logic [31:0]    data;        // expected read word (scalar)
    logic [3:0]     strb;
    sf_mem_exc_e    exc;
  } sexp_t;
  typedef struct {
    bit             is_wr;
    logic [7:0]     tag;
    logic [127:0]   data;
    logic [3:0]     mask;
    sf_mem_exc_e    exc;
  } vexp_t;
  typedef struct {
    bit             is_wr;
    logic [7:0]     tag;
    int unsigned    len;                         // beats
    logic [BURST_MAX*128-1:0] data;              // expected read beats / written beats
    sf_mem_exc_e    exc;
  } bexp_t;

  sexp_t exp_s [NT][$];
  vexp_t exp_v [NT][$];
  bexp_t exp_b [NT][$];

  // --------------------------------------------------------------------------
  // run-time knobs and counters
  // --------------------------------------------------------------------------
  int unsigned s_left [NT], v_left [NT], b_left [NT];
  int unsigned p_issue, p_rsp, p_wdata, p_err;     // /256
  int unsigned tgt_mode;                            // 0 random, 1 rotate (t+1), 2 diagonal, 3 pairs (t^1)
  bit          rsp_stop [NT];                       // consumer refuses all responses
  logic [31:0] rng_s [NT], rng_v [NT], rng_b [NT], rng_c [NT];
  int unsigned errors, total_errors, err_print;
  longint unsigned n_done_s, n_done_v, n_done_b, last_done_cycle;
  longint unsigned n_err_rsp;
  string cur_test;
  int unsigned test_err0, n_pass, n_fail;
  bit          expect_deadlock;

  task automatic err(input string m);
    errors++; total_errors++;
    if (err_print < 20) begin $display("ERROR @%0t cy=%0d: %s", $time, cycle, m); err_print++; end
  endtask

  // tag counters
  logic [7:0] tag_s [NT], tag_v [NT], tag_b [NT];
  int unsigned raw_ign_s [NT], raw_ign_v [NT];     // responses owed to raw-injected packets (not agent traffic)

  // --------------------------------------------------------------------------
  // scalar / vector / burst agents
  // --------------------------------------------------------------------------
  for (genvar t = 0; t < NT; t++) begin : g_agent
    // ---- scalar -----------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin : p_scalar
      logic [31:0] a, b, c, d, e;
      logic        accepted;
      int unsigned tgt, line, word, k;
      sf_scalar_mem_req_t r;
      sexp_t x;
      logic [31:0] rw;
      if (!rst_n) begin
        s_req_v[t] <= 1'b0; s_rsp_r[t] <= 1'b1;
      end else begin
        a = xs32(rng_s[t]); b = xs32(a); c = xs32(b); d = xs32(c); e = xs32(d);
        rng_s[t] <= e;
        s_rsp_r[t] <= !rsp_stop[t] && (a[15:8] < p_rsp[7:0] || p_rsp >= 256);
        // ---- response check (ready was a flop: handshake uses pre-edge values)
        if (s_rsp_v[t] && s_rsp_r[t]) begin
          if (exp_s[t].size() == 0 && raw_ign_s[t] > 0) begin
            raw_ign_s[t] = raw_ign_s[t] - 1;
          end else if (exp_s[t].size() == 0) begin
            err($sformatf("tile %0d: unexpected scalar response", t));
          end else begin
            x = exp_s[t].pop_front();
            n_done_s++; last_done_cycle = cycle;
            if (s_rsp[t].tag != x.tag) err($sformatf("tile %0d scalar: tag %0d != %0d (order/ID)", t, s_rsp[t].tag, x.tag));
            if (s_rsp[t].op != (x.is_wr ? SF_MEM_STORE : SF_MEM_LOAD)) err($sformatf("tile %0d scalar: wrong op in response", t));
            if (s_rsp[t].exc != x.exc) err($sformatf("tile %0d scalar tag %0d: status %0d != expected %0d", t, x.tag, s_rsp[t].exc, x.exc));
            if (x.exc != SF_MEM_EXC_NONE) n_err_rsp++;
            if (!x.is_wr && x.exc == SF_MEM_EXC_NONE && s_rsp[t].rdata != x.data)
              err($sformatf("tile %0d scalar tag %0d: read data %08h != %08h", t, x.tag, s_rsp[t].rdata, x.data));
          end
        end
        accepted = s_req_v[t] && s_req_r[t];
        if (!s_req_v[t] || accepted) begin
          if (s_left[t] > 0 && (b[15:8] < p_issue[7:0] || p_issue >= 256)) begin
            tgt  = tgt_pick(t, c);
            line = t * 16 + (d % 16);                       // own slice of the scalar domain
            word = (d >> 8) % 4;
            r.op    = (e[0]) ? SF_MEM_STORE : SF_MEM_LOAD;
            r.addr  = tile_base(tgt) + line * 16 + word * 4;
            r.wdata = {c[15:0], d[31:16]} ^ e;
            r.wstrb = e[4:1] == 0 ? 4'hF : e[4:1];
            r.tag   = tag_s[t];
            r.hint  = SF_MEM_HINT_NORMAL;
            x.is_wr = (r.op == SF_MEM_STORE);
            x.tag   = r.tag;
            x.strb  = r.wstrb;
            x.exc   = SF_MEM_EXC_NONE;
            x.data  = '0;
            // error injection
            if (p_err != 0 && a[23:16] < p_err[7:0]) begin
              case (e[9:8])
                0: begin r.addr = r.addr + 1; x.exc = SF_MEM_EXC_MISALIGN; end                         // misaligned
                1: begin r.addr = tile_base(tgt) + (SCL + 3) * 16; x.exc = SF_MEM_EXC_DOMAIN; end      // vector domain
                2: begin r.addr = tile_base(tgt) + 32'h0000_8000; x.exc = SF_MEM_EXC_RANGE; end        // beyond aperture (same tile window)
                3: begin r.addr = 32'h2000_0000; x.exc = SF_MEM_EXC_RANGE; end                         // no tile: master NI rejects
              endcase
            end
            if (x.exc == SF_MEM_EXC_NONE) begin
              if (x.is_wr) begin
                for (k = 0; k < 4; k++) if (r.wstrb[k]) shadow[r.addr + k] = r.wdata[8*k +: 8];
              end else begin
                for (k = 0; k < 4; k++) rw[8*k +: 8] = sh_rd(r.addr + k);
                x.data = rw;
              end
            end
            exp_s[t].push_back(x);
            s_req_v[t] <= 1'b1;
            s_req[t]   <= r;
            tag_s[t]   <= tag_s[t] + 8'd1;
            s_left[t]  <= s_left[t] - 1;
          end else begin
            s_req_v[t] <= 1'b0;
          end
        end
      end
    end

    // ---- vector -----------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin : p_vector
      logic [31:0] a, b, c, d, e;
      logic        accepted;
      int unsigned tgt, line, k, l;
      sf_vector_mem_req_t r;
      vexp_t x;
      logic [127:0] rv;
      if (!rst_n) begin
        v_req_v[t] <= 1'b0; v_rsp_r[t] <= 1'b1;
      end else begin
        a = xs32(rng_v[t]); b = xs32(a); c = xs32(b); d = xs32(c); e = xs32(d);
        rng_v[t] <= e;
        v_rsp_r[t] <= !rsp_stop[t] && (a[15:8] < p_rsp[7:0] || p_rsp >= 256);
        if (v_rsp_v[t] && v_rsp_r[t]) begin
          if (exp_v[t].size() == 0 && raw_ign_v[t] > 0) begin
            raw_ign_v[t] = raw_ign_v[t] - 1;
          end else if (exp_v[t].size() == 0) begin
            err($sformatf("tile %0d: unexpected vector response", t));
          end else begin
            x = exp_v[t].pop_front();
            n_done_v++; last_done_cycle = cycle;
            if (v_rsp[t].tag != x.tag) err($sformatf("tile %0d vector: tag %0d != %0d", t, v_rsp[t].tag, x.tag));
            if (v_rsp[t].op != (x.is_wr ? SF_MEM_STORE : SF_MEM_LOAD)) err($sformatf("tile %0d vector: wrong op", t));
            if (v_rsp[t].exc != x.exc) err($sformatf("tile %0d vector tag %0d: status %0d != expected %0d", t, x.tag, v_rsp[t].exc, x.exc));
            if (x.exc != SF_MEM_EXC_NONE) n_err_rsp++;
            if (!x.is_wr && x.exc == SF_MEM_EXC_NONE) begin
              if (v_rsp[t].lane_mask != x.mask) err($sformatf("tile %0d vector tag %0d: lane mask %b != %b", t, x.tag, v_rsp[t].lane_mask, x.mask));
              for (l = 0; l < SF_VLANES; l++)
                if (x.mask[l] && v_rsp[t].rdata[32*l +: 32] != x.data[32*l +: 32])
                  err($sformatf("tile %0d vector tag %0d: lane %0d data %08h != %08h", t, x.tag, l, v_rsp[t].rdata[32*l +: 32], x.data[32*l +: 32]));
            end
          end
        end
        accepted = v_req_v[t] && v_req_r[t];
        if (!v_req_v[t] || accepted) begin
          if (v_left[t] > 0 && (b[15:8] < p_issue[7:0] || p_issue >= 256)) begin
            tgt  = tgt_pick(t, c);
            line = SCL + t * 32 + (d % 32);                  // own slice of the vector domain
            r.op        = e[0] ? SF_MEM_STORE : SF_MEM_LOAD;
            r.addr      = tile_base(tgt) + line * 16;
            r.wdata     = {a, b, c, d} ^ {e, d, c, b};
            r.lane_mask = (e[4:1] == 0) ? 4'hF : e[4:1];
            r.tag       = tag_v[t];
            r.hint      = SF_MEM_HINT_NORMAL;
            x.is_wr = (r.op == SF_MEM_STORE);
            x.tag   = r.tag;
            x.mask  = r.lane_mask;
            x.exc   = SF_MEM_EXC_NONE;
            x.data  = '0;
            if (p_err != 0 && a[23:16] < p_err[7:0]) begin
              case (e[9:8])
                0: begin r.addr = r.addr + 4; x.exc = SF_MEM_EXC_MISALIGN; end                         // not line aligned
                1: begin r.addr = tile_base(tgt) + 5 * 16; x.exc = SF_MEM_EXC_DOMAIN; end              // scalar domain
                2: begin r.addr = tile_base(tgt) + 32'h0000_8000; x.exc = SF_MEM_EXC_RANGE; end
                3: begin r.addr = 32'h0000_0100; x.exc = SF_MEM_EXC_RANGE; end
              endcase
            end
            if (x.exc == SF_MEM_EXC_NONE) begin
              if (x.is_wr) begin
                for (l = 0; l < SF_VLANES; l++)
                  if (r.lane_mask[l]) for (k = 0; k < 4; k++) shadow[r.addr + 4*l + k] = r.wdata[32*l + 8*k +: 8];
              end else begin
                for (l = 0; l < SF_VLANES; l++) for (k = 0; k < 4; k++) rv[32*l + 8*k +: 8] = sh_rd(r.addr + 4*l + k);
                x.data = rv;
              end
            end
            exp_v[t].push_back(x);
            v_req_v[t] <= 1'b1;
            v_req[t]   <= r;
            tag_v[t]   <= tag_v[t] + 8'd1;
            v_left[t]  <= v_left[t] - 1;
          end else begin
            v_req_v[t] <= 1'b0;
          end
        end
      end
    end

    // ---- burst (DMA) ----------------------------------------------------------
    // states: 0 idle, 1 descriptor presented, 2 write data beats, 3 reading beats, 4 waiting done
    int unsigned bst;
    int unsigned bk, blen;
    bexp_t       bcur;
    logic [BURST_MAX*128-1:0] bdata;
    logic [BURST_MAX*16-1:0]  bstrb;
    int unsigned bwrite_idx, bread_idx;
    logic        bpend_is_wr;

    always @(posedge clk or negedge rst_n) begin : p_burst
      logic [31:0] a, b, c, d, e;
      int unsigned tgt, line, len, k, i;
      logic [127:0] beat;
      sf_burst_desc_t r;
      if (!rst_n) begin
        b_req_v[t] <= 1'b0; b_wd_v[t] <= 1'b0; b_rd_r[t] <= 1'b1; b_dn_r[t] <= 1'b1;
        bst = 0; bwrite_idx = 0; bread_idx = 0;
      end else begin
        a = xs32(rng_b[t]); b = xs32(a); c = xs32(b); d = xs32(c); e = xs32(d);
        rng_b[t] <= e;
        b_rd_r[t] <= !rsp_stop[t] && (a[15:8] < p_rsp[7:0] || p_rsp >= 256);
        b_dn_r[t] <= 1'b1;
        // completion: consumed at the handshake (done_ready is a constant 1), so check it here
        if (b_dn_v[t] && b_dn_r[t]) begin
          n_done_b++; last_done_cycle = cycle;
          if (exp_b[t].size() == 0) begin
            err($sformatf("tile %0d: unexpected burst completion", t));
          end else begin
            bcur = exp_b[t].pop_front();
            if (b_dn[t].tag != bcur.tag) err($sformatf("tile %0d burst done tag %0d != %0d", t, b_dn[t].tag, bcur.tag));
            if (b_dn[t].op != (bcur.is_wr ? SF_MEM_STORE : SF_MEM_LOAD)) err($sformatf("tile %0d burst done: wrong op", t));
            if (b_dn[t].beats != 9'(bcur.len)) err($sformatf("tile %0d burst done: %0d beats, expected %0d", t, b_dn[t].beats, bcur.len));
            if (b_dn[t].exc != SF_MEM_EXC_NONE) err($sformatf("tile %0d burst done: status %0d", t, b_dn[t].exc));
            if (!bcur.is_wr && bread_idx != bcur.len) err($sformatf("tile %0d burst: %0d read beats delivered, expected %0d", t, bread_idx, bcur.len));
          end
          bst = 0;
        end
        case (bst)
          0: begin
            if (b_left[t] > 0 && (b[15:8] < p_issue[7:0] || p_issue >= 256)) begin
              tgt  = tgt_pick(t, c);
              len  = 1 + (d % BURST_MAX);                      // 1..16 beats
              line = SCL + 128 + t * 16 + (e % (17 - len));    // own slice, burst stays inside it
              r.op     = e[8] ? SF_MEM_STORE : SF_MEM_LOAD;
              r.base   = tile_base(tgt) + line * 16;
              r.len_m1 = 8'(len - 1);
              r.tag    = tag_b[t];
              r.hint   = SF_MEM_HINT_NORMAL;
              bcur.is_wr = (r.op == SF_MEM_STORE);
              bcur.tag   = r.tag;
              bcur.len   = len;
              bcur.exc   = SF_MEM_EXC_NONE;
              bcur.data  = '0;
              bdata = '0; bstrb = '0;
              for (i = 0; i < len; i++) begin
                if (bcur.is_wr) begin
                  beat = {xs32(a ^ i), xs32(b + i), xs32(c ^ (i * 7)), xs32(d + i)};
                  bdata[128*i +: 128] = beat;
                  bstrb[16*i +: 16]   = 16'hFFFF ^ {8'h00, e[15:8]} ^ (i[0] ? 16'h00F0 : 16'h0);
                  for (k = 0; k < 16; k++) if (bstrb[16*i + k]) shadow[r.base + 16*i + k] = beat[8*k +: 8];
                end else begin
                  for (k = 0; k < 16; k++) beat[8*k +: 8] = sh_rd(r.base + 16*i + k);
                  bcur.data[128*i +: 128] = beat;
                end
              end
              if (bcur.is_wr) bcur.data = bdata;
              exp_b[t].push_back(bcur);
              b_req_v[t] <= 1'b1; b_req[t] <= r;
              tag_b[t] <= tag_b[t] + 8'd1;
              b_left[t] <= b_left[t] - 1;
              bwrite_idx = 0; bread_idx = 0;
              bst = 1;
            end
          end
          1: begin                                           // descriptor handshake
            if (b_req_v[t] && b_req_r[t]) begin
              b_req_v[t] <= 1'b0;
              bst = bcur.is_wr ? 2 : 3;
            end
          end
          2: begin                                           // write beats: supply with random gaps
            if (b_wd_v[t] && b_wd_r[t]) begin
              bwrite_idx = bwrite_idx + 1;
              b_wd_v[t] <= 1'b0;
            end
            if ((!b_wd_v[t] || (b_wd_v[t] && b_wd_r[t])) && bwrite_idx < bcur.len) begin
              if (c[15:8] < p_wdata[7:0] || p_wdata >= 256) begin
                b_wd_v[t] <= 1'b1;
                b_wd[t].data <= bcur.data[128*bwrite_idx +: 128];
                b_wd[t].strb <= bstrb[16*bwrite_idx +: 16];
              end
            end
            if (bwrite_idx >= bcur.len && !(b_wd_v[t] && !b_wd_r[t])) bst = 4;
          end
          3: begin                                           // read beats
            if (b_rd_v[t] && b_rd_r[t]) begin
              if (bread_idx >= bcur.len) err($sformatf("tile %0d burst: more read beats than requested", t));
              else begin
                if (b_rd[t].data !== bcur.data[128*bread_idx +: 128])
                  err($sformatf("tile %0d burst tag %0d beat %0d: data mismatch", t, bcur.tag, bread_idx));
                if (b_rd[t].tag != bcur.tag) err($sformatf("tile %0d burst beat tag %0d != %0d", t, b_rd[t].tag, bcur.tag));
                if (b_rd[t].last != (bread_idx == bcur.len - 1)) err($sformatf("tile %0d burst: wrong last flag at beat %0d", t, bread_idx));
                if (b_rd[t].exc != SF_MEM_EXC_NONE) err($sformatf("tile %0d burst: beat exc %0d", t, b_rd[t].exc));
              end
              bread_idx = bread_idx + 1;
            end
          end
          4: ;                                                // waiting for the completion handshake (handled above)
          default: bst = 0;
        endcase
      end
    end
  end

  // --------------------------------------------------------------------------
  // raw packet injection and response capture (control registers, protocol corner cases)
  // --------------------------------------------------------------------------
  task automatic raw_send(input int unsigned t, input noc_packet_t p);
    @(negedge clk);
    if (p.pclass == SF_NOC_RD_REQ || p.pclass == SF_NOC_WR_REQ) begin
      if (p.xfer == SF_NOC_X_SCALAR) raw_ign_s[t]++;
      if (p.xfer == SF_NOC_X_VECTOR) raw_ign_v[t]++;
    end
    raw_en[t] = 1'b1;
    raw_p[t]  = p;
    raw_v[t]  = 1'b1;
    // the transfer happens at the rising edge where ready is (pre-edge) high
    do @(posedge clk); while (!f_req_in_r[t]);
    @(negedge clk);
    raw_v[t]  = 1'b0;
    raw_en[t] = 1'b0;
  endtask

  // wait for one response packet addressed to tile `t` that is NOT a master-NI-managed class
  task automatic raw_wait_rsp(input int unsigned t, output noc_packet_t r, output bit ok, input int unsigned limit);
    int unsigned n;
    ok = 1'b0; n = 0;
    r = '0;
    while (!ok && n < limit) begin
      @(posedge clk);
      if (f_rsp_out_v[t] && f_rsp_out_r[t]) begin r = f_rsp_out_p[t]; ok = 1'b1; end
      n++;
    end
  endtask


  function automatic noc_packet_t mk_raw(input int unsigned src, input int unsigned dst, input sf_noc_class_e c,
                                         input sf_noc_xfer_e x, input sf_paddr_t a, input logic [31:0] w,
                                         input sf_noc_be_t be, input logic [7:0] tag);
    noc_packet_t p;
    p = '0;
    p.valid = 1; p.sop = 1; p.eop = 1; p.pclass = c; p.xfer = x;
    p.dst_id = sf_noc_id(dst % MX, dst / MX, MX);
    p.src_id = sf_noc_id(src % MX, src / MX, MX);
    p.txn_id = tag; p.addr = a; p.data = sf_noc_data_t'(w); p.be = be;
    return p;
  endfunction

  // --------------------------------------------------------------------------
  // test control
  // --------------------------------------------------------------------------
  task automatic do_reset();
    @(negedge clk);
    rst_n = 1'b0;
    for (int t = 0; t < NT; t++) begin
      s_left[t] = 0; v_left[t] = 0; b_left[t] = 0; rsp_stop[t] = 1'b0; raw_ign_s[t] = 0; raw_ign_v[t] = 0;
      exp_s[t].delete(); exp_v[t].delete(); exp_b[t].delete();
    end
    shadow.delete();
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    // memory controllers zero their arrays after reset
    begin : wait_init
      int unsigned n = 0;
      while (!(mc_init[0] && mc_init[1] && mc_init[2] && mc_init[3]) && n < 5000) begin @(negedge clk); n++; end
      if (n >= 5000) err("memory_controller never reported init_done");
    end
    repeat (3) @(negedge clk);
  endtask

  function automatic bit work_left();
    for (int t = 0; t < NT; t++)
      if (s_left[t] != 0 || v_left[t] != 0 || b_left[t] != 0 || exp_s[t].size() != 0 ||
          exp_v[t].size() != 0 || exp_b[t].size() != 0) return 1'b1;
    return 1'b0;
  endfunction

  task automatic begin_test(input string n);
    cur_test = n; test_err0 = total_errors; err_print = 0;
    p_issue = 256; p_rsp = 256; p_wdata = 256; p_err = 0; tgt_mode = 0;
    n_done_s = 0; n_done_v = 0; n_done_b = 0; n_err_rsp = 0;
    do_reset();
    last_done_cycle = cycle;
  endtask

  task automatic end_test();
    if (total_errors == test_err0) begin
      n_pass++;
      $display("TEST %-32s PASS  (scalar=%0d vector=%0d burst=%0d completed, %0d error-status responses, cycles=%0d)",
               cur_test, n_done_s, n_done_v, n_done_b, n_err_rsp, cycle);
    end else begin
      n_fail++;
      $display("TEST %-32s FAIL  (%0d errors)", cur_test, total_errors - test_err0);
    end
  endtask

  // run until every issued op is complete; returns 0 on stall (deadlock/loss)
  task automatic drain(input int unsigned stall, output bit ok);
    ok = 1'b0;
    forever begin
      @(negedge clk);
      if (!work_left()) begin ok = 1'b1; break; end
      if (cycle - last_done_cycle > stall) break;
    end
    if (ok) repeat (10) @(negedge clk);
  endtask

  task automatic check_quiescent();
    int unsigned n;
    n = 0;
    while (!noc_idle && n < 2000) begin @(negedge clk); n++; end
    if (!noc_idle) err("network not idle after all transactions completed");
    if (|err_drop) err("ingress rejection pulsed");
  endtask

  task automatic run_ops(input int unsigned ns, input int unsigned nv, input int unsigned nb, input int unsigned stall = 20000);
    bit ok;
    for (int t = 0; t < NT; t++) begin s_left[t] = ns; v_left[t] = nv; b_left[t] = nb; end
    drain(stall, ok);
    if (!ok) begin
      int unsigned pend;
      pend = 0;
      for (int t = 0; t < NT; t++) pend += exp_s[t].size() + exp_v[t].size() + exp_b[t].size();
      $display("      state at the stall (network %s):", SEP ? "SEPARATE (request plane shown)" : "SHARED");
      diag_pulse = 1'b1; #1; diag_pulse = 1'b0;
      if (expect_deadlock) $display("      DEADLOCK reproduced: no completion for %0d cycles with %0d transactions outstanding", stall, pend);
      else err($sformatf("NO PROGRESS: %0d transactions outstanding after %0d idle cycles (deadlock or loss)", pend, stall));
    end else if (expect_deadlock) begin
      err("expected a protocol deadlock but the workload completed");
    end
  endtask

  // ==========================================================================
  // tests
  // ==========================================================================
  task automatic t_smoke();
    begin_test("smoke_all_ports_all_targets");
    run_ops(64, 64, 24);
    check_quiescent();
    end_test();
  endtask

  task automatic t_scalar_only();
    begin_test("scalar_rw_every_target");
    run_ops(400, 0, 0);
    check_quiescent();
    end_test();
  endtask

  task automatic t_vector_only();
    begin_test("vector_lane_masked_rw");
    run_ops(0, 300, 0);
    check_quiescent();
    end_test();
  endtask

  task automatic t_dma();
    begin_test("dma_burst_rw_strobes");
    run_ops(0, 0, 60);
    check_quiescent();
    end_test();
  endtask

  task automatic t_concurrent_random();
    begin_test("concurrent_random_backpressure");
    p_issue = 160; p_rsp = 110; p_wdata = 150;
    run_ops(300, 300, 50);
    check_quiescent();
    end_test();
  endtask

  task automatic t_errors();
    begin_test("error_completions");
    p_err = 90;                                           // ~35% of ops are deliberately illegal
    run_ops(300, 300, 0);
    check_quiescent();
    if (n_err_rsp == 0) err("no error responses generated: test invalid");
    end_test();
  endtask

  // credit exhaustion: the tile stops consuming responses entirely, then resumes
  task automatic t_consumer_stall();
    bit ok;
    begin_test("response_consumer_stall");
    for (int t = 0; t < NT; t++) begin rsp_stop[t] = 1'b1; s_left[t] = 200; v_left[t] = 200; end
    repeat (3000) @(negedge clk);
    // no response may have been delivered; requests must have throttled at the credit limit, not wedged the network
    if (n_done_s != 0 || n_done_v != 0) err("response delivered to a stalled consumer");
    for (int t = 0; t < NT; t++) rsp_stop[t] = 1'b0;
    last_done_cycle = cycle;
    drain(20000, ok);
    if (!ok) err("did not recover after the consumers resumed");
    check_quiescent();
    end_test();
  endtask

  task automatic t_reset_mid_traffic();
    bit ok;
    begin_test("reset_during_memory_traffic");
    p_issue = 200; p_rsp = 160;
    for (int t = 0; t < NT; t++) begin s_left[t] = 100000; v_left[t] = 100000; b_left[t] = 100000; end
    repeat (700) @(negedge clk);
    do_reset();                                           // flushes testbench state and re-initialises memories
    p_issue = 256; p_rsp = 256;
    run_ops(100, 100, 20);
    check_quiescent();
    end_test();
  endtask

  // raw-packet corner cases and control registers
  task automatic t_ctrl_and_corners();
    noc_packet_t r;
    bit ok;
    logic [31:0] w;
    begin_test("control_regs_and_corner_packets");
    // ---- scratch registers: write then read, every (src,dst) pair, byte enables honoured
    for (int s = 0; s < NT; s++) begin
      for (int d = 0; d < NT; d++) begin
        w = 32'hA5000000 | (s << 16) | (d << 8) | 8'h3C;
        raw_send(s, mk_raw(s, d, SF_NOC_WR_REQ, SF_NOC_X_CTRL, 32'h0000_0000 + 4 * ((s + d) % 16), w, 16'h000F, 8'(10*s+d)));
        raw_wait_rsp(s, r, ok, 400);
        if (!ok) err($sformatf("ctrl write %0d->%0d: no response", s, d));
        else if (r.pclass != SF_NOC_WR_RSP || r.status != SF_MEM_EXC_NONE || r.txn_id != 8'(10*s+d) ||
                 r.src_id != sf_noc_id(d % MX, d / MX, MX))
          err($sformatf("ctrl write %0d->%0d: bad completion cls=%0d st=%0d txn=%0d", s, d, r.pclass, r.status, r.txn_id));
        raw_send(s, mk_raw(s, d, SF_NOC_RD_REQ, SF_NOC_X_CTRL, 32'h0000_0000 + 4 * ((s + d) % 16), 0, 16'h000F, 8'(100+10*s+d)));
        raw_wait_rsp(s, r, ok, 400);
        if (!ok) err($sformatf("ctrl read %0d->%0d: no response", s, d));
        else if (r.pclass != SF_NOC_RD_RSP || r.status != SF_MEM_EXC_NONE || r.data[31:0] != w || r.txn_id != 8'(100+10*s+d))
          err($sformatf("ctrl read %0d->%0d: got %08h expected %08h (txn %0d)", s, d, r.data[31:0], w, r.txn_id));
      end
    end
    // ---- a write to an unmapped control address is a RANGE error
    raw_send(1, mk_raw(1, 2, SF_NOC_WR_REQ, SF_NOC_X_CTRL, 32'h0000_0F00, 32'h1, 16'h000F, 8'd77));
    raw_wait_rsp(1, r, ok, 400);
    if (!ok || r.status != SF_MEM_EXC_RANGE) err("unmapped control write did not return RANGE");
    // ---- counters read over the NoC (tile 0 hosts the window): version word
    raw_send(3, mk_raw(3, 0, SF_NOC_RD_REQ, SF_NOC_X_CTRL, 32'h0004_0000 | (16'h0000 << 2), 0, 16'h000F, 8'd90));
    raw_wait_rsp(3, r, ok, 400);
    if (!ok || r.data[31:0] != 32'h5F0C_0101) err($sformatf("counter version over NoC = %08h (expected 5F0C0101)", r.data[31:0]));
    // counters window on a tile without counters is RANGE
    raw_send(3, mk_raw(3, 1, SF_NOC_RD_REQ, SF_NOC_X_CTRL, 32'h0004_0000, 0, 16'h000F, 8'd91));
    raw_wait_rsp(3, r, ok, 400);
    if (!ok || r.status != SF_MEM_EXC_RANGE) err("counter window on a tile without counters did not return RANGE");

    // ---- partial-lane vector write: rejected, memory untouched
    begin : partial
      noc_packet_t p;
      sf_noc_be_t  be;
      be = 16'hFFFF; be[5] = 1'b0;                         // lane 1 only 3 of 4 bytes
      p = mk_raw(2, 3, SF_NOC_WR_REQ, SF_NOC_X_VECTOR, tile_base(3) + (SCL + 1) * 16, 0, be, 8'd55);
      p.data = {4{32'hDEAD_BEEF}};
      raw_send(2, p);
      raw_wait_rsp(2, r, ok, 400);
      if (!ok || r.status != SF_MEM_EXC_MISALIGN) err($sformatf("partial-lane write status %0d (expected MISALIGN)", r.status));
      p = mk_raw(2, 3, SF_NOC_RD_REQ, SF_NOC_X_VECTOR, tile_base(3) + (SCL + 1) * 16, 0, 16'hFFFF, 8'd56);
      raw_send(2, p);
      raw_wait_rsp(2, r, ok, 400);
      if (!ok || r.status != SF_MEM_EXC_NONE || r.data != '0) err("partial-lane write modified memory");
    end
    // ---- posted MSG and a response-class packet on the request network are dropped without effect
    raw_send(0, mk_raw(0, 3, SF_NOC_MSG, SF_NOC_X_SCALAR, tile_base(3) + 16, 32'hFFFF_FFFF, 16'h000F, 8'd60));
    raw_send(0, mk_raw(0, 3, SF_NOC_RD_RSP, SF_NOC_X_SCALAR, tile_base(3) + 16, 32'hFFFF_FFFF, 16'h000F, 8'd61));
    repeat (50) @(negedge clk);
    raw_send(0, mk_raw(0, 3, SF_NOC_RD_REQ, SF_NOC_X_SCALAR, tile_base(3) + 16, 0, 16'h000F, 8'd62));
    raw_wait_rsp(0, r, ok, 400);
    if (!ok || r.status != SF_MEM_EXC_NONE || r.data[31:0] != 32'h0 || r.txn_id != 8'd62)
      err("target NI did not recover cleanly after MSG / response-class packets");
    // ---- orphan burst beat (no descriptor) is dropped; next transaction still works
    begin : orphan
      noc_packet_t p;
      p = mk_raw(1, 2, SF_NOC_WR_REQ, SF_NOC_X_BURST, tile_base(2) + 16 * 100, 0, 16'hFFFF, 8'd70);
      p.sop = 1'b0; p.eop = 1'b1; p.data = {4{32'h1234_5678}};
      raw_send(1, p);
      repeat (30) @(negedge clk);
      raw_send(1, mk_raw(1, 2, SF_NOC_RD_REQ, SF_NOC_X_SCALAR, tile_base(2) + 32, 0, 16'h000F, 8'd71));
      raw_wait_rsp(1, r, ok, 400);
      if (!ok || r.status != SF_MEM_EXC_NONE) err("target NI wedged by an orphan burst beat");
    end
    check_quiescent();
    end_test();
  endtask

  // counters are readable directly and agree with what the transactions did
  task automatic t_counters_over_noc();
    logic [31:0] v;
    longint unsigned inj0, ej0, inj1, ej1;
    begin_test("counters_match_traffic");
    run_ops(100, 100, 12);
    check_quiescent();
    // request network (plane 0) vs response network (plane 1): every request gets exactly one completion packet
    // (a burst write is 1+len flits on the request network, a burst read is len flits back; scalar/vector are 1 each)
    tb_direct = 1'b1;
    inj0 = 0; ej0 = 0; inj1 = 0; ej1 = 0;
    for (int t = 0; t < NT; t++) begin
      tb_rd_plane = 0; tb_rd_addr = 16'h2000 | (0 << 8) | t; #1; inj0 += fab_rd_data;
      tb_rd_plane = 0; tb_rd_addr = 16'h2000 | (3 << 8) | t; #1; ej0  += fab_rd_data;
      if (SEP) begin
        tb_rd_plane = 1; tb_rd_addr = 16'h2000 | (0 << 8) | t; #1; inj1 += fab_rd_data;
        tb_rd_plane = 1; tb_rd_addr = 16'h2000 | (3 << 8) | t; #1; ej1  += fab_rd_data;
      end
    end
    tb_direct = 1'b0;
    $display("      request network: %0d flits in / %0d out   response network: %0d in / %0d out", inj0, ej0, inj1, ej1);
    if (inj0 != ej0) err($sformatf("request network not conserving flits: %0d in, %0d out", inj0, ej0));
    if (SEP && inj1 != ej1) err($sformatf("response network not conserving flits: %0d in, %0d out", inj1, ej1));
    if (inj0 == 0) err("request network counters read zero after traffic");
    if (cnt_ovf) err("counter overflow");
    end_test();
  endtask

  // --- protocol deadlock study: identical workload, identical seed; SEP decides ---
  int unsigned nops, nbur;
  task automatic t_protocol_stress();
    begin_test(SEP ? "protocol_stress_separate_networks" : "protocol_stress_shared_network");
    expect_deadlock = (SEP == 1'b0) && expect_deadlock;       // only the shared-network run may be expected to deadlock
    p_issue = 256; p_rsp = 256;
    if (!$value$plusargs("TGT=%d", tgt_mode)) tgt_mode = 1;
    if (!$value$plusargs("NOPS=%d", nops)) nops = 600;
    if (!$value$plusargs("NBURST=%d", nbur)) nbur = 0;
    run_ops(nops, nops, nbur, 8000);
    if (!expect_deadlock) check_quiescent();
    end_test();
  endtask

  // ==========================================================================
  string testname;
  int unsigned seed_i;
  logic [31:0] seed;
  function automatic bit want(input string n);
    return (testname == "all") || (testname == n);
  endfunction

  initial begin
    rst_n = 1'b0; cycle = 0; total_errors = 0; errors = 0; err_print = 0; n_pass = 0; n_fail = 0;
    expect_deadlock = 1'b0;
    last_done_cycle = 0; n_done_s = 0; n_done_v = 0; n_done_b = 0; n_err_rsp = 0;
    if (!$value$plusargs("TEST=%s", testname)) testname = "all";
    if (!$value$plusargs("SEED=%d", seed_i)) seed_i = 1;
    if ($test$plusargs("EXPECT_DEADLOCK")) expect_deadlock = 1'b1;
    seed = seed_i;
    for (int t = 0; t < NT; t++) begin
      rng_s[t] = xs32(seed ^ (32'h9E3779B9 * (t + 1))) | 1;
      rng_v[t] = xs32(seed ^ (32'h7F4A7C15 * (t + 3))) | 1;
      rng_b[t] = xs32(seed ^ (32'h85EBCA6B * (t + 5))) | 1;
      rng_c[t] = xs32(seed ^ (32'hC2B2AE35 * (t + 7))) | 1;
      tag_s[t] = 8'(t * 40); tag_v[t] = 8'(t * 40 + 7); tag_b[t] = 8'(t * 40 + 13);
      rsp_stop[t] = 1'b0; raw_ign_s[t] = 0; raw_ign_v[t] = 0;
    end
    $display("CONFIG sep_rsp=%0d bufd=%0d req_q=%0d rsp_q=%0d ctx_q=%0d out_s=%0d out_v=%0d seed=%0d test=%s",
             SEP, BUFD, REQ_Q, RSP_Q, CTX_Q, OUT_S, OUT_V, seed, testname);
    repeat (4) @(negedge clk);

    if (want("smoke_all_ports_all_targets"))        t_smoke();
    if (want("scalar_rw_every_target"))             t_scalar_only();
    if (want("vector_lane_masked_rw"))              t_vector_only();
    if (want("dma_burst_rw_strobes"))               t_dma();
    if (want("concurrent_random_backpressure"))     t_concurrent_random();
    if (want("error_completions"))                  t_errors();
    if (want("response_consumer_stall"))            t_consumer_stall();
    if (want("reset_during_memory_traffic"))        t_reset_mid_traffic();
    if (want("control_regs_and_corner_packets"))    t_ctrl_and_corners();
    if (want("counters_match_traffic"))             t_counters_over_noc();
    if (testname == "protocol_stress")              t_protocol_stress();

    $display("SUMMARY tests_passed=%0d tests_failed=%0d total_errors=%0d", n_pass, n_fail, total_errors);
    if (n_fail == 0 && total_errors == 0) begin $display("RESULT: PASS"); $finish; end
    else begin $display("RESULT: FAIL"); $fatal(1, "tb_noc_sys failed"); end
  end

  initial begin
    #(10 * 60_000_000);
    $display("RESULT: FAIL (global timeout)");
    $fatal(1, "global timeout");
  end
endmodule
