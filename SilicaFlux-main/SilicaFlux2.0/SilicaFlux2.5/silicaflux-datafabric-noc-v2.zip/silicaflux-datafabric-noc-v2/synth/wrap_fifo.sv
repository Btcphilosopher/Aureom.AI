// width-8 / depth-4 instance of sf_noc_fifo so synthesis has a concrete top (a type parameter cannot be set with -G)
module fifo_w8 (input logic clk_i, rst_ni, push_i, input logic [7:0] data_i, output logic full_o, input logic pop_i,
                output logic [7:0] data_o, output logic empty_o, output logic [2:0] count_o);
  sf_noc_fifo #(.T(logic [7:0]), .DEPTH(4)) u (.*);
endmodule
