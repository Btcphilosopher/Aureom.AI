# SilicaFlux DataFabric NoC v2

Verification, performance and system integration of the SilicaFlux 2x2 mesh Network-on-Chip
(`SilicaFlux2.0/SilicaFlux2.5/noc_interconnect.sf`). Delivered as an archive; **nothing was committed to git.**

## Result in one paragraph
The 2x2 SilicaFlux NoC routes packets correctly between four tile endpoints under simultaneous traffic, applies correct back-pressure, produces
no dropped or duplicated transactions in any tested condition, and exports genuine measurements from RTL simulation. The existing router
turned out to be sound at its core; its defects were at the edges (an undefined packet type, validation that exists only in simulation, strict-priority QoS,
no answer to request/response deadlock) and are fixed by a scripted patch of the untouched original. The memory path was verified against the
repository's **real `memory_controller`**. **Not done: static timing analysis** (no PDK liberty exists in the repository or sandbox) - no ns, MHz or um^2 appears anywhere.

## Definition of done - evidence
| requirement | evidence |
|---|---|
| routes correctly between four tiles, simultaneous traffic | 26 configurations x 3 seeds all as expected (`reports/regression.md`): every one of the 16 pairs at exactly `2(hops+1)` cycles, permutations, all-pairs random, hotspot; formal: any src/dst/payload delivered only at dst, exactly once, bit exact (`reports/formal.md`) |
| correct back-pressure | random / periodic / blocked sinks, queue saturation, reset mid-traffic; output hold and ready semantics proved (hold & reset **unbounded**) |
| no dropped or duplicated transactions | independent scoreboard on every flit; hardware counters cross-checked against it; formal occupancy == accepted - transferred; system tests with a shadow memory |
| genuine performance measurements | `reports/PERFORMANCE.md`: 324 simulations, 0 errors; zero-load, load sweep, saturation vs analytic bound, tail latency, per-link utilisation, fairness, depth sensitivity |

## Headline findings (all measured in this work)
| | |
|---|---|
| **Existing router** | passes 15/15 legal-traffic tests; with assertions off, a bad `dst_id` is **misdelivered**, and on a 3x3 mesh **wedges an input port (43 packets stranded)**; strict-priority QoS gave the low class **3 of 1,995 flits (0.2 %)** |
| **v2 router** | bad destination/class/source rejected in hardware (395 of 395 bad packets, 0 of 1,205 good ones lost); QoS guard restores 22 % (K=7) / 40 % (K=3); **cycle-for-cycle identical** to the original on legal traffic (45 comparisons) |
| **Latency** | mesh 2 / 4 / 6 cycles for 0 / 1 / 2 hops; crossbar 2 for every pair |
| **Saturation (uniform random, 4 tiles, depth 4)** | mesh **0.870**, crossbar **0.689** flits/cycle/tile; the crossbar's 0.655 under uniform-incl.-self **equals the analytic input-queued limit** |
| **Cost (no PDK)** | mesh 2x2 = 2.7x the crossbar's NAND2-eq (3.0x the flops); dual request/response fabric = 2.0x one mesh; the optional **traffic-counter block is 2.5x the whole mesh** |
| **Fairness** | round-robin is locally, not globally, fair: all-to-one Jain index 0.90 (2x2), 0.59 (3x3), **0.36 (4x4)**; the crossbar stays at 1.00 |
| **Protocol deadlock** | **reproduced**: shared request/response network deadlocks in 9 of 9 sustained-traffic runs (and with any DMA burst at default sizes); the identical workload on separate networks completes in 9 of 9 (4,960 transactions, ~1,800 cycles) |
| **Formal** | 11 property groups pass (reset, output-hold, FIFO invariants unbounded; the rest bounded, depths 5-14); 9 of 9 injected bugs caught. Formal found a real flaw in my own first QoS guard (shared round-robin pointer) |
| **Structure** | gate level: all 15 link-facing outputs of the interior router depend on no input - no combinational ready chain across routers |

## What is NOT done (details: `docs/KNOWN_LIMITATIONS.md`)
* **No STA / timing closure / PDK numbers.** FloorplanLab and TimingFlow integration is configuration only, not run.
* **`tile_interface` is not connected** (its package types are absent from the tree); `compute_tile`, `scheduler`, `silicaflux_top` do not compile from the tree and were not integrated; no tensor-operand-buffer RTL exists to attach to.
* The "supplied" `sf_noc_traffic_counters.sv` starter does not exist in the repository; the counters are new work and are large (instrumentation, `CNT_EN = 0` for production).
* Virtual networks were evaluated, not implemented (two physical networks used).
* Formal is mostly bounded; no coverage metric was collected; Verilator is the only simulator (Icarus cannot compile the design).


## Where to start
| you want | read |
|---|---|
| what was wrong with the existing code, with evidence | `docs/AUDIT.md` |
| the packet contract | `docs/PACKET_SPEC.md` |
| how it works, mesh vs crossbar | `docs/ARCHITECTURE.md` |
| request/response deadlock: analysis and measured evidence | `docs/DEADLOCK.md` |
| counters and their register map | `docs/COUNTERS.md` |
| what is verified, how, and how strongly | `docs/VERIFICATION.md`, `reports/formal.md` |
| performance numbers and charts | `reports/PERFORMANCE.md`, `reports/qos.md` |
| area / structure / timing situation | `reports/synth.md`, `reports/comb_paths.md`, `docs/PHYSICAL.md` |
| everything that is NOT done | `docs/KNOWN_LIMITATIONS.md` |
| how to rerun it all | `docs/REPRODUCE.md`, `Makefile` |

## Layout
```
original/            the untouched audited sources + SHA256SUMS
rtl/                 silicaflux_pkg.sv (+ NoC section), noc_interconnect.sv (v2, generated from original/),
                     sf_noc_xbar.sv, sf_noc_traffic_counters.sv, sf_noc_fabric.sv, sf_noc_mem_{master,target}_ni.sv,
                     sf_noc_mem_node.sv, sf_noc_fifo.sv
third_party/         memory_controller.sv (verbatim copy of the repository's memory_controller.sf)
tb/                  tb_noc.sv (NoC functional + performance), tb_noc_sys.sv (system with the real memory controller)
formal/              SymbiYosys harnesses (FIFO, router, 2x2 mesh)
scripts/             regression, lab, formal, synthesis, packaging
constraints/         SDC skeleton, TimingFlow config, floorplan manifest (not run: no PDK)
examples/            sf_noc_system_example.sv  (4 tiles + fabric + real scratchpads)
reports/             generated results, charts          docs/   documentation
```

## Quick start
```bash
scripts/setup_tools.sh && make lint && make quick     # ~ minutes
make all                                              # everything (about an hour on 4 cores)
```
