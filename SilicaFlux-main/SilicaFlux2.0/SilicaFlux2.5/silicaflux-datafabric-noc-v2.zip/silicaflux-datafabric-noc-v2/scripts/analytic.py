"""Analytic bandwidth models used to bound the simulated results.

These are *predictions*, kept apart from measurements:

  channel_bound(...)   Dally & Towles channel-load bound: with XY routing the
                       sustainable injection rate per tile is limited by the most
                       heavily loaded resource (a directed link, an ejection port or
                       the injection port), each of capacity 1 flit/cycle.
                       theta_max = 1 / max(load per unit injection rate).
  hol_saturation(N)    Monte-Carlo of a saturated N x N input-queued switch with one
                       FIFO per input (head-of-line blocking), uniform destinations,
                       random tie-break: the throughput an ideal FIFO input-queued
                       crossbar saturates at (infinite buffering, no pipeline).
Neither includes arbitration inefficiency of the RTL, finite buffers, or pipeline
stalls; the gap to the simulated value is exactly what the simulation adds.
"""
import numpy as np

DIRS = {"E": (1, 0), "W": (-1, 0), "N": (0, 1), "S": (0, -1)}


def traffic_matrix(pattern, nt, mx, my, hot=0, hotpct=128):
    L = np.zeros((nt, nt))
    for s in range(nt):
        sx, sy = s % mx, s // mx
        if pattern == "uniform":
            L[s, :] = 1.0 / nt
        elif pattern == "uniform_ne":
            L[s, :] = 1.0 / (nt - 1)
            L[s, s] = 0
        elif pattern == "transpose":
            d = (s % mx) * my + (s // mx) if mx == my else s
            L[s, d] = 1
        elif pattern == "complement":
            L[s, nt - 1 - s] = 1
        elif pattern == "neighbor":
            L[s, (s + 1) % nt] = 1
        elif pattern == "local":
            L[s, s] = 1
        elif pattern == "allto1":
            L[s, hot] = 1
        elif pattern == "hotspot":                 # TB: pct/256 -> hot, else uniform over all tiles
            p = min(hotpct, 256) / 256.0
            L[s, :] = (1 - p) / nt
            L[s, hot] += p
    return L


def xy_links(mx, my, s, d):
    """Directed links used by XY routing s -> d, as ((x,y),dir)."""
    x, y = s % mx, s // mx
    dx, dy = d % mx, d // mx
    links = []
    while x != dx:
        step = 1 if dx > x else -1
        links.append(((x, y), "E" if step > 0 else "W")); x += step
    while y != dy:
        step = 1 if dy > y else -1
        links.append(((x, y), "N" if step > 0 else "S")); y += step
    return links


def channel_loads(kind, mx, my, L):
    nt = mx * my
    links, ej = {}, np.zeros(nt)
    for s in range(nt):
        for d in range(nt):
            if L[s, d] == 0:
                continue
            ej[d] += L[s, d]
            if kind == "mesh":
                for lk in xy_links(mx, my, s, d):
                    links[lk] = links.get(lk, 0.0) + L[s, d]
    return links, ej


def channel_bound(kind, mx, my, pattern, **kw):
    nt = mx * my
    L = traffic_matrix(pattern, nt, mx, my, **kw)
    links, ej = channel_loads(kind, mx, my, L)
    inj = L.sum(axis=1).max()                       # = 1 for every pattern here
    worst_link = max(links.values()) if links else 0.0
    cand = {"injection": inj, "ejection": ej.max(), "link": worst_link}
    lim = max(cand, key=cand.get)
    return {"theta_max": 1.0 / max(cand.values()), "limiter": lim, "max_link_load": worst_link,
            "max_ej_load": float(ej.max()), "links": {f"{k[0][0]},{k[0][1]}{k[1]}": v for k, v in links.items()},
            "ej": ej.tolist()}


def hol_saturation(n, cycles=200000, seed=7):
    """Saturated FIFO input-queued NxN crossbar, uniform destinations (incl. self)."""
    rng = np.random.default_rng(seed)
    head = rng.integers(0, n, n)
    served = 0
    for _ in range(cycles):
        winners = {}
        order = rng.permutation(n)
        for i in order:
            d = head[i]
            if d not in winners:
                winners[d] = i
        for d, i in winners.items():
            head[i] = rng.integers(0, n)
        served += len(winners)
    return served / (cycles * n)


if __name__ == "__main__":
    for n in (2, 3, 4, 8):
        print(n, round(hol_saturation(n, 60000), 4))
    for pat in ("uniform_ne", "transpose", "allto1"):
        b = channel_bound("mesh", 2, 2, pat)
        print(pat, round(b["theta_max"], 4), b["limiter"], round(b["max_link_load"], 3))
