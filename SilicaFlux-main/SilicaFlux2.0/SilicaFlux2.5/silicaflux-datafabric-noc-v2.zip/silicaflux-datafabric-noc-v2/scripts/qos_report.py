#!/usr/bin/env python3
"""Measured QoS behaviour: one high-class source against two low-class sources contending for one output.
Reuses the regression builds. Writes reports/qos.md."""
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import sfbuild as sb
ROOT = sb.ROOT
CASES = [("QOS_ARB_EN=0 (round-robin, classes ignored)", [], "RR"),
         ("QOS_ARB_EN=1, QOS_STARVE_LIMIT=0 (strict priority, the original behaviour)", ["-GQOS_ARB_EN=1", "-GQOS_LIMIT=0"], "strict"),
         ("QOS_ARB_EN=1, K=7", ["-GQOS_ARB_EN=1", "-GQOS_LIMIT=7"], "K7"),
         ("QOS_ARB_EN=1, K=3", ["-GQOS_ARB_EN=1", "-GQOS_LIMIT=3"], "K3")]
rows = []
for title, args, tag in CASES:
    names = {"RR": "mesh2x2_d4", "strict": "mesh2x2_qos_strict", "K7": "mesh2x2_qos_guard7", "K3": "mesh2x2_qos_guard3"}
    exe = sb.build(names[tag], "tb_noc", sb.RTL_V2 + ["tb/tb_noc.sv"], args)
    for seed in (1, 2, 3):
        _, out = sb.run(exe, ["+TEST=qos_class_starvation", f"+SEED={seed}"])
        m = re.search(r"hi\(src0\)=(\d+)\s+low-class total=(\d+)", out)
        res = re.search(r"qos_class_starvation\s+(PASS|FAIL)", out)
        rows.append((title, seed, int(m.group(1)), int(m.group(2)), res.group(1) if res else "?"))
md = ["# QoS: one high-class source vs two low-class sources on one output (2000-cycle window, all sources saturated)", "",
      "Tile 0 is the high class; tiles 1 and 2 are low; all send to tile 3, so they contend for one ejection output (and tile 1/tile 0 share a link).",
      "The low class must keep a bounded share; the testbench requires >= 2000 / (2(K+1)) flits (K = guard limit; 100 for strict priority).", "",
      "| configuration | seed | high-class delivered | low-class delivered (2 sources) | low share | test |", "|---|---|---|---|---|---|"]
for t, s, hi, lo, r in rows:
    md.append(f"| {t} | {s} | {hi} | {lo} | {lo/(hi+lo):.1%} | {r} |")
md += ["", "Strict priority gives the low class essentially nothing while the high class is active (a deliberate, documented failure of the",
       "starvation requirement); the guard bounds it. The guard's *formal* wait bound is (NP-1)(K+1)+K cycles, proved for K = 1 (`reports/formal.md`).", ""]
(ROOT / "reports" / "qos.md").write_text("\n".join(md))
print("\n".join(md))
