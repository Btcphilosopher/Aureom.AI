#!/usr/bin/env python3
"""Technology-independent synthesis + structural timing proxies (Yosys 0.71 / SLANG).

  scripts/synth.py [--quick]      ->  reports/synth.md, reports/comb_paths.md, reports/fanout.md,
                                      synth/<name>.log

WHAT THIS IS AND IS NOT
  * Real synthesis of the real RTL: proc, flatten, memory->flops, abc mapped to a
    NAND2/NOT-only generic library. Area is reported as flop count and a NAND2-equivalent
    estimate (documented weights). No PDK is present in this environment, so there is NO
    area in um^2, NO delay in ns and NO frequency claim. Do not read the numbers as such.
  * 'logic levels' is Yosys `ltp -noff`: the longest combinational path, counted in
    NAND2/NOT gate levels, between flops / ports. It is a structural proxy for the
    critical path, comparable between designs, not a timing result.
  * Static timing analysis with a liberty library was NOT run (no liberty files exist in
    the repository or the sandbox). constraints/ holds the SDC and TimingFlow config for
    whoever has the PDK.
"""
import concurrent.futures as cf, json, os, pathlib, re, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "synth"
OUT.mkdir(exist_ok=True)
YOSYS = [str(ROOT / "build/venv/bin/yowasp-yosys")]
PKG = ["rtl/silicaflux_pkg.sv"]

# NAND2-equivalent weights (conventional, stated so the estimate can be re-derived):
W_NAND, W_NOT, W_DFF = 1.0, 0.5, 5.0

DESIGNS = [
    # name, top, files, -G parameters
    ("fifo_d4_w8",        "fifo_w8", PKG + ["rtl/sf_noc_fifo.sv", "synth/wrap_fifo.sv"], {}),
    ("router_2x2_n00_d4", "noc_router", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 2, "MESH_Y": 2, "NODE_X": 0, "NODE_Y": 0, "BUF_DEPTH": 4}),
    ("router_3x3_n11_d4", "noc_router", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 3, "MESH_Y": 3, "NODE_X": 1, "NODE_Y": 1, "BUF_DEPTH": 4}),
    ("mesh2x2_d2", "noc_interconnect", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 2}),
    ("mesh2x2_d4", "noc_interconnect", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 4}),
    ("mesh2x2_d8", "noc_interconnect", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 8}),
    ("mesh2x2_d4_explicit", "noc_interconnect", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 4, "EXPLICIT_FRAMING": 1}),
    ("mesh2x2_d4_qos", "noc_interconnect", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 4, "QOS_ARB_EN": 1, "QOS_STARVE_LIMIT": 7}),
    ("mesh3x3_d4", "noc_interconnect", PKG + ["rtl/noc_interconnect.sv"], {"MESH_X": 3, "MESH_Y": 3, "BUF_DEPTH": 4}),
    ("xbar4_d2", "sf_noc_xbar", PKG + ["rtl/sf_noc_xbar.sv"], {"NUM_TILES": 4, "MESH_X": 2, "BUF_DEPTH": 2}),
    ("xbar4_d4", "sf_noc_xbar", PKG + ["rtl/sf_noc_xbar.sv"], {"NUM_TILES": 4, "MESH_X": 2, "BUF_DEPTH": 4}),
    ("xbar4_d8", "sf_noc_xbar", PKG + ["rtl/sf_noc_xbar.sv"], {"NUM_TILES": 4, "MESH_X": 2, "BUF_DEPTH": 8}),
    ("xbar9_d4",  "sf_noc_xbar", PKG + ["rtl/sf_noc_xbar.sv"], {"NUM_TILES": 9, "MESH_X": 3, "BUF_DEPTH": 4}),
    ("counters_2x2", "sf_noc_traffic_counters", PKG + ["rtl/sf_noc_traffic_counters.sv"], {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 4, "LAT_IDX_W": 4}),
    ("master_ni", "sf_noc_mem_master_ni", PKG + ["rtl/sf_noc_fifo.sv", "rtl/sf_noc_mem_master_ni.sv"], {}),
    ("target_ni", "sf_noc_mem_target_ni", PKG + ["rtl/sf_noc_fifo.sv", "rtl/sf_noc_mem_target_ni.sv"], {}),
    ("fabric_dual_nocnt", "sf_noc_fabric", PKG + ["rtl/noc_interconnect.sv", "rtl/sf_noc_traffic_counters.sv", "rtl/sf_noc_fabric.sv"],
     {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 4, "CNT_EN": 0}),
    ("fabric_dual_cnt", "sf_noc_fabric", PKG + ["rtl/noc_interconnect.sv", "rtl/sf_noc_traffic_counters.sv", "rtl/sf_noc_fabric.sv"],
     {"MESH_X": 2, "MESH_Y": 2, "BUF_DEPTH": 4, "CNT_EN": 1, "LAT_IDX_W": 4}),
]
QUICK = {"router_2x2_n00_d4", "mesh2x2_d4", "xbar4_d4", "fifo_d4_w8"}


def script(name, top, files, params):
    g = " ".join(f"-G {k}={v}" for k, v in params.items() if v is not None)
    return f"""read_slang --threads 1 --top {top} {g} -D SYNTHESIS -I rtl {' '.join(files)}
hierarchy -check -top {top}
proc
flatten
opt_expr
opt_clean
check -assert
synth -top {top} -flatten
abc -g NAND
opt_clean -purge
tee -o synth/{name}.stat stat
tee -o synth/{name}.ltp ltp -noff
write_json synth/{name}.json
"""


def run(d):
    name, top, files, params = d
    ys = OUT / f"{name}.ys"
    ys.write_text(script(name, top, files, params))
    s = time.time()
    try:
        r = subprocess.run(YOSYS + ["-q", "-l", f"synth/{name}.log", f"synth/{name}.ys"], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    except subprocess.TimeoutExpired:
        return {"name": name, "error": "timeout"}
    if r.returncode != 0:
        return {"name": name, "error": (r.stdout + r.stderr)[-400:]}
    st = (OUT / f"{name}.stat").read_text()
    def cnt(pat):
        m = re.search(pat, st, re.M)
        return int(m.group(1)) if m else 0
    nand = cnt(r"\$_NAND_\s*(\d+)") or cnt(r"(\d+)\s+\$_NAND_")
    notc = cnt(r"(\d+)\s+\$_NOT_")
    nand = cnt(r"(\d+)\s+\$_NAND_")
    dffs = sum(int(m.group(1)) for m in re.finditer(r"^\s*(\d+)\s+\$_(?:S?DFF|DFFE|ALDFF|DLATCH|SDFFE|SDFFCE|DFFSR)\w*", st, re.M))
    cells = cnt(r"^\s*(\d+)\s+cells\s*$")
    ltp = re.search(r"length=(\d+)", (OUT / f"{name}.ltp").read_text())
    other = {m.group(2): int(m.group(1)) for m in re.finditer(r"^\s*(\d+)\s+(\$_\w+)", st, re.M)}
    other.pop("$_NAND_", None); other.pop("$_NOT_", None)
    gate_eq = nand * W_NAND + notc * W_NOT
    return {"name": name, "top": top, "params": params, "cells": cells, "nand": nand, "not": notc, "dff": dffs,
            "nand2_eq_logic": gate_eq, "nand2_eq_total": gate_eq + dffs * W_DFF, "levels": int(ltp.group(1)) if ltp else None,
            "other_cells": other, "time": time.time() - s}


def main():
    sel = [d for d in DESIGNS if "--quick" not in sys.argv or d[0] in QUICK]
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        res = list(ex.map(run, sel))
    json.dump(res, open(ROOT / "reports" / "synth.json", "w"), indent=1)
    md = ["# Synthesis results (technology independent)", "",
          "Yosys 0.71 + SLANG; `synth -flatten`, `abc -g NAND`. **No PDK: no um^2, ns or MHz are claimed.**",
          f"NAND2-eq = NAND2 x {W_NAND} + NOT x {W_NOT} + flop x {W_DFF} (conventional weights, stated for re-derivation).",
          "`levels` = Yosys `ltp -noff` longest combinational path in NAND2/NOT levels (structural timing proxy).", "",
          "| design | flops | NAND2 | NOT | NAND2-eq (logic) | NAND2-eq (total) | logic levels | note |", "|---|---|---|---|---|---|---|---|"]
    for r in res:
        if "error" in r:
            md.append(f"| {r['name']} | - | - | - | - | - | - | **FAILED**: {r['error'][:80]} |"); continue
        note = ("; ".join(f"{k}={v}" for k, v in r["other_cells"].items() if v) or "")
        md.append(f"| {r['name']} | {r['dff']} | {r['nand']} | {r['not']} | {r['nand2_eq_logic']:.0f} | {r['nand2_eq_total']:.0f} | {r['levels']} | {note} |")
    (ROOT / "reports" / "synth.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    return 0 if all("error" not in r for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
