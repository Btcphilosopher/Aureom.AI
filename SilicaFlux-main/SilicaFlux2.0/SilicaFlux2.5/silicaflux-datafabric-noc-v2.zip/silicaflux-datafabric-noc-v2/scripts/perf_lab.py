#!/usr/bin/env python3
"""NoC performance laboratory.

  scripts/perf_lab.py [--quick]            run every experiment, write reports/perf/results.json
  (then)  scripts/perf_report.py           tables + plots + reports/PERFORMANCE.md

Everything measured here comes from RTL simulation of tb/tb_noc.sv in open-loop
mode (Bernoulli arrivals into source queues, warm-up, then a fixed measurement
window). Nothing is taken from a model. The analytic numbers (channel-load
bound, saturated input-queue Monte-Carlo) are computed separately in
`analytic.py` and are only ever shown NEXT TO the measurements.
"""
import argparse, json, pathlib, re, sys, time, os, itertools
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import sfbuild as sb

ROOT = sb.ROOT
OUT = ROOT / "reports" / "perf"
TMP = ROOT / "build" / "perf_tmp"
RTL = sb.RTL_V2
SEEDS = [1, 2, 3]
WARMC, MEAS = 3000, 30000


def variant(kind, mx, my, depth, extra=()):
    """kind: mesh|xbar. returns (name, verilator args)"""
    fab = 0 if kind == "mesh" else 1
    name = f"{kind}{mx}x{my}_d{depth}" + ("".join(extra) if extra else "")
    args = [f"-GFABRIC={fab}", f"-GMESH_X={mx}", f"-GMESH_Y={my}", f"-GBUF_DEPTH={depth}", *extra]
    return name, args


def parse_kv(line):
    d = {}
    for kv in line.split(",")[1:]:
        if "=" in kv:
            k, v = kv.split("=", 1)
            d[k] = v
    return d


def percentiles(csv_path):
    a = np.loadtxt(csv_path, delimiter=",", dtype=np.int64, ndmin=2) if os.path.getsize(csv_path) else np.zeros((0, 7), np.int64)
    if a.shape[0] == 0:
        return {}
    out = {"n": int(a.shape[0])}
    for nm, col in (("net", 5), ("tot", 6)):
        x = a[:, col]
        out[nm] = {"mean": float(x.mean()), "p50": float(np.percentile(x, 50)), "p95": float(np.percentile(x, 95)),
                   "p99": float(np.percentile(x, 99)), "p999": float(np.percentile(x, 99.9)), "max": float(x.max()),
                   "min": float(x.min())}
    return out, a


def run_point(job):
    exe, cfg, seed = job
    TMP.mkdir(parents=True, exist_ok=True)
    tag = f"{cfg['var']}_{cfg['pat']}_{cfg['rate']}_{cfg.get('hotpct',0)}_{cfg.get('ejrate',256)}_{seed}"
    lat = TMP / (re.sub(r'[^A-Za-z0-9_.-]', '_', tag) + ".csv")
    pa = ["+TEST=perf", f"+SEED={seed}", f"+PAT={cfg['pat']}", f"+RATE={cfg['rate']}", f"+WARMC={WARMC}",
          f"+MEAS={MEAS}", f"+HOT={cfg.get('hot',0)}", f"+HOTPCT={cfg.get('hotpct',128)}",
          f"+EJRATE={cfg.get('ejrate',256)}", f"+LATFILE={lat}", f"+DUMP={1 if cfg.get('dump') else 0}"]
    rc, out = sb.run(exe, pa, timeout=600)
    res = {"cfg": cfg, "seed": seed, "rc": rc}
    m = re.search(r"^PERF,.*$", out, re.M)
    if not m:
        res["error"] = out[-800:]
        return res
    res["perf"] = parse_kv(m.group(0))
    res["src"] = [parse_kv(l) for l in re.findall(r"^PERF_SRC,.*$", out, re.M)]
    res["dst"] = [parse_kv(l) for l in re.findall(r"^PERF_DST,.*$", out, re.M)]
    cnt = {"rp": {}, "tile": {}, "lat": {}}
    for l in re.findall(r"^CNT,.*$", out, re.M):
        f = l.split(",")
        if f[1] == "rp":
            cnt["rp"][(f[2], int(f[3]), int(f[4]))] = int(f[5])
        elif f[1] == "tile":
            cnt["tile"][(f[2], int(f[3]))] = int(f[4])
        elif f[1] == "cycles":
            cnt["cycles"] = int(f[2])
        elif f[1] == "lat" and f[2] == "0":
            cnt["lat"] = {k: int(v) for k, v in (x.split("=") for x in f[3:])}
        elif f[1] == "latcheck":
            cnt["latcheck"] = {k: int(v) for k, v in (x.split("=") for x in f[2:])}
    res["cnt"] = {"rp": [[k[0], k[1], k[2], v] for k, v in cnt["rp"].items()],
                  "tile": [[k[0], k[1], v] for k, v in cnt["tile"].items()],
                  "cycles": cnt.get("cycles"), "lat": cnt.get("lat"), "latcheck": cnt.get("latcheck")}
    if lat.exists():
        p = percentiles(lat)
        if p:
            res["pct"], arr = p
            # per-source and per-pair total latency summary (waiting time under contention)
            res["per_src_lat"] = {}
            for s in sorted(set(arr[:, 0].tolist())):
                x = arr[arr[:, 0] == s]
                res["per_src_lat"][int(s)] = {"n": int(len(x)), "net_mean": float(x[:, 5].mean()),
                                              "net_p99": float(np.percentile(x[:, 5], 99)),
                                              "net_max": float(x[:, 5].max())}
            res["_lat_samples"] = None
        lat.unlink()
    return res


def zero_load(exe):
    rc, out = sb.run(exe, ["+TEST=all_pairs_zero_load"])
    rows = [parse_kv(l) for l in re.findall(r"^ZL,.*$", out, re.M)]
    return [{k: int(v) for k, v in r.items()} for r in rows], ("RESULT: PASS" in out)


def qos_point(exe_args, limit, strict=False):
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    t0 = time.time()
    OUT.mkdir(parents=True, exist_ok=True)

    depths = [2, 3, 4, 6, 8, 16] if not a.quick else [2, 4, 8]
    rates = [8, 16, 32, 48, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256] if not a.quick else [16, 64, 128, 256]
    sizes = [(2, 2), (3, 3), (4, 4)]

    variants = {}
    for kind in ("mesh", "xbar"):
        for d in depths:
            n, ar = variant(kind, 2, 2, d); variants[n] = (kind, 2, 2, d, ar)
        for (mx, my) in sizes[1:]:
            n, ar = variant(kind, mx, my, 4); variants[n] = (kind, mx, my, 4, ar)
    print(f"building {len(variants)} variants ...", flush=True)

    def bld(item):
        n, (kind, mx, my, d, ar) = item
        return n, sb.build("perf_" + n, "tb_noc", RTL + ["tb/tb_noc.sv"], ar)

    exes = dict(sb.pmap(bld, list(variants.items())))
    print(f"  built in {time.time()-t0:.0f}s", flush=True)

    jobs = []

    def add(var, pat, rate, **kw):
        cfg = {"var": var, "pat": pat, "rate": rate, **kw}
        for s in SEEDS:
            jobs.append((exes[var], cfg, s))

    # E2/E6: latency & throughput vs offered load, 2x2 mesh vs crossbar (uniform, excluding self)
    for var in ("mesh2x2_d4", "xbar2x2_d4"):
        for r in rates:
            add(var, "uniform_ne", r, exp="load_sweep")
    # E3/E5: traffic patterns at saturation with counter dumps (link utilisation)
    pats = ["uniform_ne", "uniform", "transpose", "complement", "neighbor", "local"]
    for var in ("mesh2x2_d4", "xbar2x2_d4"):
        for p in pats:
            add(var, p, 256, exp="pattern_sat", dump=True)
        add(var, "allto1", 256, exp="pattern_sat", dump=True, hot=0)
        add(var, "hotspot", 256, exp="pattern_sat", dump=True, hot=0, hotpct=128)
        # moderate load with counters (utilisation below saturation)
        add(var, "uniform_ne", 96, exp="pattern_mid", dump=True)
    # E4: all-to-one fairness / waiting time vs size
    for var in variants:
        if variants[var][3] == 4:
            add(var, "allto1", 256, exp="fairness", hot=0, dump=True)
            add(var, "uniform_ne", 256, exp="scaling_sat", dump=True)
            add(var, "uniform_ne", 16, exp="scaling_low")
    # E7: buffer depth sensitivity
    for var, (kind, mx, my, d, ar) in variants.items():
        if (mx, my) == (2, 2):
            add(var, "uniform_ne", 256, exp="depth_sat")
            add(var, "uniform_ne", 96, exp="depth_mid")
            add(var, "allto1", 256, exp="depth_hot", hot=0)
    # slow sinks (ejection back-pressure)
    for var in ("mesh2x2_d4", "xbar2x2_d4"):
        for er in (64, 128, 192):
            add(var, "uniform_ne", 96, exp="sink_bp", ejrate=er)

    print(f"running {len(jobs)} simulations ...", flush=True)
    results = sb.pmap(run_point, jobs)
    bad = [r for r in results if "error" in r or r["rc"] != 0 or r.get("perf", {}).get("errors") != "0"]
    print(f"  done in {time.time()-t0:.0f}s, {len(bad)} problem runs", flush=True)

    zl = {}
    for var in ("mesh2x2_d4", "xbar2x2_d4", "mesh3x3_d4", "mesh4x4_d4", "xbar3x3_d4", "xbar4x4_d4"):
        if var in exes:
            rows, ok = zero_load(exes[var])
            zl[var] = {"rows": rows, "ok": ok}

    for r in results:
        r.pop("_lat_samples", None)
    json.dump({"seeds": SEEDS, "warm": WARMC, "meas": MEAS, "results": results, "zero_load": zl,
               "problems": [str(b.get("cfg")) + str(b.get("error", ""))[:200] for b in bad]},
              open(OUT / "results.json", "w"), indent=0)
    print("wrote", OUT / "results.json")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
