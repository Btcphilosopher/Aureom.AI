#!/usr/bin/env python3
"""Run every formal task and write reports/formal.md.
Needs build/venv (pip install yowasp-yosys, which provides yowasp-sby/SLANG) and z3 in PATH.
See docs/REPRODUCE.md. Each row states mode, depth and what an UNBOUNDED vs BOUNDED result means."""
import concurrent.futures as cf, pathlib, re, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent.parent
F = ROOT / "formal"
ENV = {"PATH": f"{ROOT}/build/bin:/usr/bin:/bin:/usr/local/bin", "HOME": "/root"}

# (sby file, task, timeout, what it establishes)
TASKS = [
  ("fifo.sby",   "invariants",   120, "FIFO: count<=depth, full/empty flags exact, occupancy == pushes-pops"),
  ("fifo.sby",   "order",        300, "FIFO: marked element leaves in order and unchanged"),
  ("router.sby", "reset_prove",  120, "router: reset state (buffers empty, outputs idle, ready high)"),
  ("router.sby", "hold_prove",   120, "router: output valid+payload stable under stall"),
  ("router.sby", "gnt_bmc",      300, "router: one grant/output & /input, grant needs request+space, no overflow/underflow"),
  ("router.sby", "route_bmc",    600, "router: every flit leaves on the port XY routing selects"),
  ("router.sby", "cons_bmc",     600, "router: occupancy == accepted - transferred (no loss, no duplication)"),
  ("router.sby", "ingress_bmc",  300, "router: invalid/illegal/spoofed local flits dropped, others accepted, cause exact"),
  ("router.sby", "fair",         300, "router: round-robin wait <= NP-1 = 4 accepting cycles (any output, any input)"),
  ("router.sby", "qos",          600, "router: QoS guard K=1: wait <= (NP-1)(K+1)+K = 9"),
  ("mesh.sby",   "mesh",         300, "2x2 mesh: any src/dst/payload delivered only at dst, exactly once, exact, 2*(hops+1) cycles"),
]
# induction attempts for the groups where it is expected to need strengthening (reported as such)
EXTRA = [("router.sby", f"{g}_prove", 150, f"router: {g} by k-induction (may need strengthening)") for g in ("gnt", "route", "cons", "ingress")]

def run(job):
    f, t, to, what = job
    base = f[:-4]
    subprocess.run(["rm", "-rf", str(F / f"{base}_{t}")])
    s = time.time()
    try:
        r = subprocess.run([str(ROOT / "build/venv/bin/yowasp-sby"), "-f", f, t], cwd=F, capture_output=True, text=True,
                           timeout=to, env=ENV)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return (f, t, "TIMEOUT", time.time() - s, what, "", "")
    res = re.search(r"DONE \((\w+),", out)
    res = res.group(1) if res else "ERROR"
    ind = "unbounded (k-induction)" if "successful proof by k-induction" in out else ""
    dep = re.search(r"depth\s+(\d+)", (F / f).read_text().split(f"{t}:")[1] if f"{t}:" in (F / f).read_text() else "")
    d = re.search(rf"^{t}: depth (\d+)", (F / f).read_text(), re.M) or re.search(r"^depth (\d+)", (F / f).read_text(), re.M)
    return (f, t, res, time.time() - s, what, ind, d.group(1) if d else "?")

if __name__ == "__main__":
    jobs = TASKS + (EXTRA if "--all" in sys.argv else [])
    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        res = list(ex.map(run, jobs))
    md = ["# Formal verification results", "",
          "Tool chain: SymbiYosys (YoWASP), SLANG frontend, smtbmc + z3. The RTL under test is the unmodified",
          "`rtl/noc_interconnect.sv` / `rtl/sf_noc_fifo.sv`, instantiated with a reduced-width flit (`fv_pkt_t`).", "",
          "| task | result | strength | depth | time (s) | establishes |", "|---|---|---|---|---|---|"]
    for f, t, r, dt, what, ind, d in res:
        if ind:
            strength = ind
        elif t.endswith("_prove"):
            strength = f"k-induction inconclusive (needs strengthening; base case holds to depth {d}); the bounded result is the matching _bmc row"
        else:
            strength = f"bounded (BMC depth {d})"
        md.append(f"| {f[:-4]}:{t} | **{r}** | {strength} | {d} | {dt:.0f} | {what} |")
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "formal.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    sys.exit(0 if all(r[2] == "PASS" for r in res if not r[1].endswith("_prove")) else 1)
