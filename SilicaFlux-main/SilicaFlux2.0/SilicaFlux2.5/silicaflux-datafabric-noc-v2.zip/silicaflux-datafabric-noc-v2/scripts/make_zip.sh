#!/usr/bin/env bash
# Package the project (no git involved). Excludes build products, tool workspaces and generated mutant files (all regenerable
# with `make setup`, `make formal`, `make mutants`, `make synth`); includes sources, docs, reports and charts.
set -eu
cd "$(dirname "$0")/.."
name=silicaflux-datafabric-noc-v2
root=$PWD
out=${1:-$root/../$name.zip}
case "$out" in /*) ;; *) out=$root/$out ;; esac
rm -f "$out"
here=$(basename "$PWD")
cd ..
zip -qr "$out" "$here" \
  -x "$here/build/*" "*/__pycache__/*" "*.pyc" \
     "$here/formal/*/*" "$here/formal/mut_*.sby" \
     "$here/synth/*.json"
echo "wrote $out ($(du -h "$out" | cut -f1))"
