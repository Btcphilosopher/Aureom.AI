"""Shared build helper: hash-cached Verilator builds of the NoC testbenches."""
import hashlib, os, pathlib, subprocess, sys, concurrent.futures as cf

ROOT = pathlib.Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"

PKG = "rtl/silicaflux_pkg.sv"
RTL_V2 = [PKG, "rtl/noc_interconnect.sv", "rtl/sf_noc_xbar.sv", "rtl/sf_noc_traffic_counters.sv"]
VFLAGS = ["--binary", "--timing", "--assert", "-Wno-fatal", "-Wno-lint", "-Wno-style",
          "-Wno-TIMESCALEMOD", "-O1"]


def _hash(files, args):
    h = hashlib.sha256()
    for f in files:
        h.update(pathlib.Path(ROOT / f).read_bytes() if not os.path.isabs(f) else pathlib.Path(f).read_bytes())
    h.update(" ".join(args).encode())
    return h.hexdigest()[:12]


def build(name, top, files, args=(), force=False):
    """Build `top` from `files` with extra verilator `args`; returns path of binary."""
    files = list(files)
    args = list(args)
    key = _hash(files, args + [top])
    d = BUILD / f"{name}_{key}"
    exe = d / "obj" / "sim"
    if exe.exists() and not force:
        return exe
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", *VFLAGS, "--top-module", top, "-Mdir", str(d / "obj"), "-o", "sim",
           f"-I{ROOT/'rtl'}", *args, *[str(ROOT / f) if not os.path.isabs(f) else f for f in files]]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    (d / "build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0 or not exe.exists():
        raise RuntimeError(f"build failed for {name}: see {d/'build.log'}\n" +
                           "\n".join(l for l in (r.stdout + r.stderr).splitlines() if "%Error" in l)[:2000])
    return exe


def run(exe, plusargs=(), timeout=900):
    r = subprocess.run([str(exe), *plusargs], capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr


def pmap(fn, items, workers=None):
    workers = workers or max(1, (os.cpu_count() or 2))
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, items))
