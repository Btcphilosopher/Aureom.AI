#!/usr/bin/env bash
# One-time tool setup (Ubuntu 24.04). Nothing here needs network access to GitHub.
set -eu
cd "$(dirname "$0")/.."
echo "== system packages (needs root): verilator 5.020, iverilog 12 (optional), yosys 0.33 (provides yosys-abc), g++, make"
echo "   apt-get install -y verilator iverilog yosys g++ make python3-venv zip"
echo "== python packages"
python3 -m pip install --user numpy matplotlib pandas z3-solver
echo "== YoWASP yosys (SLANG frontend + SymbiYosys) in an isolated venv, used for synthesis and formal"
python3 -m venv build/venv
build/venv/bin/pip install -q yowasp-yosys
mkdir -p build/bin
for pair in "yosys:yowasp-yosys" "yosys-smtbmc:yowasp-yosys-smtbmc" "yosys-witness:yowasp-yosys-witness"; do
  n=${pair%%:*}; w=${pair##*:}
  printf '#!/bin/sh\nexec "%s/build/venv/bin/%s" "$@"\n' "$PWD" "$w" > "build/bin/$n"; chmod +x "build/bin/$n"
done
echo "tools ready. z3 must be on PATH (pip z3-solver installs it)."
