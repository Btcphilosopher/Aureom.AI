#!/usr/bin/env python3
"""System-level regression: tiles <-> NoC <-> real memory_controller (tb/tb_noc_sys.sv).
Includes the protocol-deadlock study: identical workload, seed and NI RTL on a SHARED network
(must deadlock) versus SEPARATE request/response networks (must complete)."""
import pathlib, re, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import sfbuild as sb
ROOT = sb.ROOT
FILES = ["rtl/silicaflux_pkg.sv", "third_party/memory_controller.sv", "rtl/sf_noc_fifo.sv", "rtl/noc_interconnect.sv",
         "rtl/sf_noc_traffic_counters.sv", "rtl/sf_noc_fabric.sv", "rtl/sf_noc_mem_master_ni.sv",
         "rtl/sf_noc_mem_target_ni.sv", "tb/tb_noc_sys.sv"]
TIGHT = ["-GBUFD=2", "-GREQ_Q=2", "-GRSP_Q=2", "-GCTX_Q=2", "-GOUT_S=32", "-GOUT_V=32"]
CFG = {
    "sep_default":  ["-GSEP=1"],
    "sep_tight":    ["-GSEP=1", "-GBUFD=2", "-GREQ_Q=2", "-GRSP_Q=2", "-GCTX_Q=2", "-GOUT_S=2", "-GOUT_V=2"],
    "shared_default": ["-GSEP=0"],
    "sep_stress":   ["-GSEP=1", *TIGHT],
    "shared_stress": ["-GSEP=0", *TIGHT],
    "shared_big":   ["-GSEP=0", "-GBUFD=64", "-GREQ_Q=64", "-GRSP_Q=64", "-GCTX_Q=64"],
}
# Shared-network study (informational, but with hard assertions about WHAT must still work / what is expected to break):
#  * single-flit memory traffic must keep working on a shared network at default sizes
#  * every test involving DMA bursts (multi-flit packets) may deadlock at default sizes (capacity-driven protocol deadlock)
#  * with 64-deep buffers only the spoofed-response-class corner test may fail (a response injected on the request path is
#    indistinguishable on one network; on separate networks it is dropped by the target NI)
MUST_PASS_SHARED = {"scalar_rw_every_target", "vector_lane_masked_rw", "error_completions", "response_consumer_stall"}
MAY_FAIL_SHARED = {"smoke_all_ports_all_targets", "dma_burst_rw_strobes", "concurrent_random_backpressure",
                   "reset_during_memory_traffic", "control_regs_and_corner_packets", "counters_match_traffic"}
BIG_EXPECTED_FAIL = {"control_regs_and_corner_packets"}

def main():
    t0 = time.time()
    exes = {k: sb.build("sys_" + k, "tb_noc_sys", FILES, v) for k, v in CFG.items()} if False else None
    built = sb.pmap(lambda kv: (kv[0], sb.build("sys_" + kv[0], "tb_noc_sys", FILES, kv[1])), list(CFG.items()))
    exes = dict(built)
    print(f"built in {time.time()-t0:.0f}s", flush=True)
    jobs = []
    for cfg in ("sep_default", "sep_tight"):
        for seed in (1, 2, 3):
            jobs.append((cfg, ["+TEST=all", f"+SEED={seed}"], f"functional seed {seed}", "functional"))
    for seed in (1, 2, 3):
        jobs.append(("shared_default", ["+TEST=all", f"+SEED={seed}"], f"functional seed {seed}", "shared_info"))
        jobs.append(("shared_big", ["+TEST=all", f"+SEED={seed}"], f"functional seed {seed}", "shared_big"))
    for tgt, name in ((1, "rotate"), (2, "diagonal"), (3, "pairs")):
        for seed in (1, 2, 3):
            jobs.append(("shared_stress", ["+TEST=protocol_stress", f"+SEED={seed}", f"+TGT={tgt}", "+NBURST=40", "+EXPECT_DEADLOCK"],
                         f"{name} seed {seed}", "deadlock"))
            jobs.append(("sep_stress", ["+TEST=protocol_stress", f"+SEED={seed}", f"+TGT={tgt}", "+NBURST=40"],
                         f"{name} seed {seed}", "complete"))
    def run1(j):
        cfg, pa, label, kind = j
        rc, out = sb.run(exes[cfg], pa, timeout=1200)
        return (cfg, label, kind, rc, out)
    res = sb.pmap(run1, jobs)
    rows, ok = [], True
    diag = ""
    for cfg, label, kind, rc, out in res:
        passed = "RESULT: PASS" in out
        tests = re.findall(r"^TEST\s+(\S+)\s+(PASS|FAIL)", out, re.M)
        cyc = re.search(r"cycles=(\d+)\)", out.splitlines()[-1] if False else "\n".join(l for l in out.splitlines() if l.startswith("TEST")))
        if kind == "deadlock":
            dl = "DEADLOCK reproduced" in out
            ok &= (passed and dl)
            m = re.search(r"DEADLOCK reproduced: no completion for (\d+) cycles with (\d+) transactions outstanding", out)
            rows.append((cfg, label, "DEADLOCK" if dl else "completed(!)", m.group(2) + " outstanding" if m else "-", "OK" if passed and dl else "UNEXPECTED"))
            if dl and not diag:
                diag = "\n".join(l for l in out.splitlines() if l.startswith("DIAG") or "state at the stall" in l or "DEADLOCK" in l)
        elif kind == "complete":
            c = re.search(r"\(scalar=(\d+) vector=(\d+) burst=(\d+) completed.*cycles=(\d+)\)", out)
            ok &= passed
            rows.append((cfg, label, "completed" if passed else "FAILED",
                         (f"{int(c.group(1))+int(c.group(2))+int(c.group(3))} txns in {c.group(4)} cycles" if c else "-"),
                         "OK" if passed else "UNEXPECTED"))
        elif kind in ("shared_info", "shared_big"):
            failed = {n for n, v in tests if v == "FAIL"}
            passed_set = {n for n, v in tests if v == "PASS"}
            if kind == "shared_info":
                good = MUST_PASS_SHARED <= passed_set and failed <= MAY_FAIL_SHARED
                detail = "fails: " + (", ".join(sorted(failed)) or "none")
                verdict = "OK (study)" if good else "UNEXPECTED"
            else:
                good = failed == BIG_EXPECTED_FAIL
                detail = "fails: " + (", ".join(sorted(failed)) or "none")
                verdict = "OK (study)" if good else "UNEXPECTED"
            ok &= good
            rows.append((cfg, label, f"{len(passed_set)}/{len(tests)} tests", detail, verdict))
        else:
            npass = len([1 for _, v in tests if v == "PASS"])
            ok &= passed
            rows.append((cfg, label, f"{npass}/{len(tests)} tests", "-", "OK" if passed else "UNEXPECTED"))
    md = ["# System-level regression (real memory_controller behind the NoC)", "",
          "Configurations: `sep_*` = separate request/response networks (supported), `shared_*` = one shared network.",
          "`*_stress`: BUFD=2, REQ_Q=RSP_Q=CTX_Q=2, 32 outstanding scalar + 32 vector per master, sustained fixed-target traffic",
          "plus 40 DMA bursts per tile. The shared-network stress runs are REQUIRED to deadlock (that is the evidence);",
          "the separate-network runs of the same workload are required to complete.",
          "`shared_default` (default sizes) and `shared_big` (64-deep everything) run the FUNCTIONAL suite on one shared network as a study:",
          "single-flit memory traffic must still work, tests with DMA bursts may deadlock at default sizes, and with 64-deep buffers only the",
          "spoofed-response-class corner test may fail. See docs/DEADLOCK.md.", "",
          "| configuration | workload | outcome | detail | verdict |", "|---|---|---|---|---|"]
    md += [f"| {a} | {b} | {c} | {d} | {e} |" for a, b, c, d, e in rows]
    md += ["", f"**Overall: {'ALL AS EXPECTED' if ok else 'UNEXPECTED RESULTS'}**", ""]
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "regression_sys.md").write_text("\n".join(md))
    (ROOT / "reports" / "deadlock_diag.txt").write_text(
        "Buffer state of the SHARED network at the stall (rotate pattern, seed 1). Capacities: router input buffer 2, NI queues 2.\n"
        "reqQ = target NI request FIFO, ctx = outstanding controller transactions, rspQ s/v/c/b = target NI response queues,\n"
        "router in-buffers = occupancy of the local/N/E/S/W input buffers of that tile's router.\n\n" + diag + "\n")
    print("\n".join(md))
    print(f"total {time.time()-t0:.0f}s")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
