#!/usr/bin/env python3
"""Turn reports/perf/results.json into tables, charts and reports/PERFORMANCE.md.

Every number comes from RTL simulation; analytic values come from scripts/analytic.py and are always shown
beside (never instead of) the measurement. Statistics are the mean over seeds of each per-run statistic
(min..max over seeds shown where it matters).

Charts: light surface, categorical slots 1-4 of the validated palette (blue, orange, aqua, yellow; validated with
the dataviz validator: lightness band, chroma, adjacent CVD and normal-vision separation pass; contrast of aqua and
yellow on the surface is < 3:1, which is why every chart also has marker shapes, direct labels and a table below it).
"""
import json, math, pathlib, sys, collections
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import analytic as an

ROOT = pathlib.Path(__file__).resolve().parent.parent
D = json.load(open(ROOT / "reports" / "perf" / "results.json"))
IMG = ROOT / "reports" / "img"
IMG.mkdir(parents=True, exist_ok=True)

SURF, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e3e2de"
C = {"mesh": "#2a78d6", "xbar": "#eb6834", "s3": "#1baf7a", "s4": "#eda100"}
MARK = {"mesh": "o", "xbar": "s", "s3": "^", "s4": "D"}
plt.rcParams.update({"figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF, "axes.edgecolor": GRID,
                     "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK,
                     "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
                     "axes.spines.right": False, "font.size": 10, "lines.linewidth": 1.6, "lines.markersize": 5})

R = D["results"]
SEEDS = D["seeds"]
for r in R:
    r["cfg"]["kind"] = "mesh" if r["cfg"]["var"].startswith("mesh") else "xbar"
    p = r["perf"]
    r["nt"] = int(p["mx"]) * int(p["my"])
    r["win"] = int(p["window"])
    r["tput"] = int(p["delivered"]) / (r["win"] * r["nt"])          # accepted flits / cycle / tile
    r["offered"] = int(p["rate"]) / 256.0
    r["net_mean"] = int(p["net_lat_x1000"]) / 1000.0
    r["backlog"] = int(p["backlog"])


def sel(**kw):
    out = []
    for r in R:
        ok = all((r["cfg"].get(k) == v) for k, v in kw.items())
        if ok:
            out.append(r)
    return out


def agg(rs, f):
    v = [f(r) for r in rs]
    return (float(np.mean(v)), float(np.min(v)), float(np.max(v))) if v else (math.nan,) * 3


def pct(rs, which, stat):
    v = [r["pct"][which][stat] for r in rs if "pct" in r and which in r["pct"]]
    return float(np.mean(v)) if v else math.nan


def style_ax(ax, xl, yl, title):
    ax.set_xlabel(xl); ax.set_ylabel(yl); ax.set_title(title, loc="left", fontsize=11, color=INK)


def label_end(ax, x, y, text, color, dy=0):
    ax.annotate(text, (x, y), xytext=(6, dy), textcoords="offset points", color=color, fontsize=9, va="center")


MD = ["# DataFabric NoC v2 - performance laboratory", "",
      "All values are measured in RTL simulation (Verilator) of `tb/tb_noc.sv` in open-loop mode: Bernoulli arrivals into",
      "source queues, 3000-cycle warm-up, then a fixed 30000-cycle measurement window, "
      f"{len(SEEDS)} seeds {SEEDS}. Cycles, not seconds: **no clock frequency is assumed or claimed.**", "",
      "Latency terms: *network latency* = injection accepted -> ejected (what the fabric adds); *total latency* = packet",
      "arrival at the source queue -> ejected (adds source queueing, +1 cycle of generator pipeline even at zero load).",
      "Throughput = delivered flits per tile per cycle inside the window. One flit/cycle/tile is the injection and ejection",
      "port limit. Packet = 1 flit; flit = 207 bits = 26 bytes (default DATA_W = 128).", ""]

# ---------------------------------------------------------------- zero load
MD += ["## 1. Zero-load latency (measured per source/destination pair)", ""]
zl = D["zero_load"]
MD += ["| fabric | pairs | latency (cycles) | analytic | all pairs match |", "|---|---|---|---|---|"]
for var, z in zl.items():
    rows = z["rows"]
    if not rows:
        continue
    lat = collections.Counter((r["hops"], r["latency"]) for r in rows)
    desc = "; ".join(f"{h} hop(s): {l}" for (h, l) in sorted(lat))
    ex = "2 x (hops + 1)" if var.startswith("mesh") else "2 (any pair)"
    match = all(r["latency"] == r["expected"] for r in rows)
    MD.append(f"| {var} | {len(rows)} | {desc} | {ex} | {'yes' if match else '**NO**'} |")
MD += ["", "Each router adds 2 cycles (buffer write, then switch allocation + egress register); a link is a register, so a hop "
       "costs exactly one router. The crossbar pays one router regardless of source and destination.", ""]

# ---------------------------------------------------------------- load sweep
fig, ax = plt.subplots(1, 2, figsize=(10.2, 3.9))
MD += ["## 2. Latency and throughput versus offered load (uniform random, destination != source)", "",
       "| offered | fabric | accepted | net lat mean | p50 | p95 | p99 | p99.9 | max | src backlog at end |", "|---|---|---|---|---|---|---|---|---|---|"]
sat_row = {}
for kind, var in (("mesh", "mesh2x2_d4"), ("xbar", "xbar2x2_d4")):
    pts = []
    rates = sorted({r["cfg"]["rate"] for r in sel(var=var, exp="load_sweep")})
    for rate in rates:
        rs = sel(var=var, exp="load_sweep", rate=rate)
        t = agg(rs, lambda r: r["tput"]); l = agg(rs, lambda r: r["net_mean"]); bl = agg(rs, lambda r: r["backlog"])
        p50, p95, p99, p999 = (pct(rs, "net", s) for s in ("p50", "p95", "p99", "p999"))
        mx = pct(rs, "net", "max")
        pts.append((rate / 256, t[0], l[0], p99, bl[0]))
        MD.append(f"| {rate/256:.3f} | {var} | {t[0]:.3f} | {l[0]:.2f} | {p50:.0f} | {p95:.0f} | {p99:.0f} | {p999:.0f} | {mx:.0f} | {bl[0]:.0f} |")
    pts = np.array(pts)
    ax[0].plot(pts[:, 0], pts[:, 2], color=C[kind], marker=MARK[kind], label=f"{kind} mean")
    ax[0].plot(pts[:, 0], pts[:, 3], color=C[kind], marker=MARK[kind], ls="--", alpha=0.75, label=f"{kind} p99")
    ax[1].plot(pts[:, 0], pts[:, 1], color=C[kind], marker=MARK[kind], label=kind)
    sat_row[kind] = pts
    label_end(ax[0], pts[-1, 0], pts[-1, 2], f"{kind} mean", C[kind])
    label_end(ax[1], pts[-1, 0], pts[-1, 1], kind, C[kind])
ax[1].plot([0, 1], [0, 1], color=INK2, lw=0.9, ls=":"); ax[1].text(0.03, 0.93, "dotted: accepted = offered", color=INK2, fontsize=8)
b_x = an.hol_saturation(4, 60000)
ax[1].axhline(b_x, color=C["xbar"], lw=0.9, ls=":"); ax[1].text(0.02, b_x - 0.045, f"HOL limit, N=4, analytic: {b_x:.3f}", color=INK2, fontsize=8)
style_ax(ax[0], "offered load (flits / cycle / tile)", "network latency (cycles)", "Latency vs offered load")
style_ax(ax[1], "offered load (flits / cycle / tile)", "accepted throughput (flits / cycle / tile)", "Accepted vs offered")
ax[0].legend(frameon=False, fontsize=8, loc="upper left")
fig.tight_layout(); fig.savefig(IMG / "latency_throughput.png", dpi=170); plt.close(fig)
MD += ["", "Beyond saturation the network latency plateaus (9.8 cycles mesh, 5.8 crossbar) because the buffers are finite: the excess load queues "
       "at the *sources* (the `src backlog` column grows without bound), not in the fabric. Total latency including source queueing keeps growing.", "",
       "![latency and throughput](img/latency_throughput.png)", ""]

# ---------------------------------------------------------------- saturation + analytic
MD += ["## 3. Saturation throughput: predicted versus observed", "",
       "Offered load 1.0 flit/cycle/tile (beyond saturation) with unbounded source queues. *Channel-load bound* =",
       "`1 / max(load per unit injection rate)` over every directed link, ejection port and injection port "
       "(XY routing, 1 flit/cycle per resource) - it ignores head-of-line blocking, arbitration and buffer limits, so the "
       "simulation sits below it. The gap is the cost of the real microarchitecture.", "",
       "| pattern | fabric | channel-load bound | limiting resource | observed accepted | observed / bound | note |", "|---|---|---|---|---|---|---|"]
pat_rows = []
for pat in ("uniform_ne", "uniform", "transpose", "complement", "neighbor", "local", "allto1", "hotspot"):
    for kind, var in (("mesh", "mesh2x2_d4"), ("xbar", "xbar2x2_d4")):
        rs = sel(var=var, exp="pattern_sat", pat=pat)
        if not rs:
            continue
        t = agg(rs, lambda r: r["tput"])
        kw = {"hot": 0}
        if pat == "hotspot":
            kw["hotpct"] = 128
        b = an.channel_bound(kind, 2, 2, pat, **kw)
        note = ""
        if kind == "xbar" and pat == "uniform":
            note = f"matches the FIFO input-queued HOL limit {an.hol_saturation(4, 60000):.3f} (independent Monte-Carlo, N=4, uniform incl. self)"
        elif kind == "xbar" and pat == "uniform_ne":
            note = "above the incl.-self HOL limit: excluding self leaves fewer output conflicts"
        MD.append(f"| {pat} | {kind} | {b['theta_max']:.3f} | {b['limiter']} | {t[0]:.3f} ({t[1]:.3f}..{t[2]:.3f}) | {t[0]/b['theta_max']:.2f} | {note} |")
        pat_rows.append((pat, kind, b["theta_max"], t[0]))
fig, ax = plt.subplots(figsize=(8.6, 3.6))
pats = [p for p in ("uniform_ne", "uniform", "transpose", "complement", "neighbor", "local", "allto1", "hotspot") if any(x[0] == p for x in pat_rows)]
x = np.arange(len(pats)); w = 0.2
for j, (kind, off) in enumerate((("mesh", -0.3), ("xbar", -0.1))):
    obs = [next((r[3] for r in pat_rows if r[0] == p and r[1] == kind), 0) for p in pats]
    bnd = [next((r[2] for r in pat_rows if r[0] == p and r[1] == kind), 0) for p in pats]
    ax.bar(x + off, obs, w, color=C[kind], label=f"{kind} observed")
    ax.bar(x + off + 0.4, bnd, w, color=C[kind], alpha=0.30, hatch="//", edgecolor=C[kind], label=f"{kind} channel-load bound")
ax.set_xticks(x + 0.1); ax.set_xticklabels(pats, rotation=20, ha="right", fontsize=8)
style_ax(ax, "", "flits / cycle / tile", "Saturation throughput: observed (solid) vs analytic bound (hatched)")
ax.set_ylim(0, 1.38)
ax.legend(frameon=False, fontsize=8, ncol=2, loc="upper right")
fig.tight_layout(); fig.savefig(IMG / "saturation_vs_bound.png", dpi=170); plt.close(fig)
MD += ["", "![saturation](img/saturation_vs_bound.png)", ""]

# ---------------------------------------------------------------- link utilisation
MD += ["## 4. Per-link utilisation (from the RTL traffic counters)", "",
       "Utilisation = FLITS_OUT / measurement cycles for each router output; `L` is the ejection port. Raw link width is "
       "26 B/flit, so 1.00 = 26 bytes/cycle. Payload bytes depend on the random byte enables and classes and are exported by "
       "the counters (PAYLOAD_BYTES_OUT) but not used here.", ""]
PN = {0: "L(eject)", 1: "N", 2: "E", 3: "S", 4: "W"}
def link_util(rs):
    acc = collections.defaultdict(list)
    for r in rs:
        cyc = r["cnt"]["cycles"]
        for m, rt, pt, v in r["cnt"]["rp"]:
            if m == "FLITS_OUT":
                acc[(rt, pt)].append(v / cyc)
    return {k: float(np.mean(v)) for k, v in acc.items()}
for pat, ttl in (("uniform_ne", "uniform random (saturated)"), ("allto1", "all-to-one -> tile 0 (saturated)"), ("transpose", "transpose (saturated)")):
    rs = sel(var="mesh2x2_d4", exp="pattern_sat", pat=pat)
    if not rs:
        continue
    u = link_util(rs)
    MD += [f"**{ttl}, mesh 2x2** (router (x,y): tile = 2y+x)", "", "| router | " + " | ".join(PN[p] for p in range(5)) + " |", "|---|" + "---|" * 5]
    for rt in range(4):
        MD.append(f"| {rt} ({rt%2},{rt//2}) | " + " | ".join(f"{u.get((rt,p),0):.3f}" if (rt, p) in u else "-" for p in range(5)) + " |")
    MD.append("")
fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.4), sharey=True)
for ax, pat, ttl in zip(axs, ("uniform_ne", "allto1"), ("uniform random", "all-to-one -> tile 0")):
    u = link_util(sel(var="mesh2x2_d4", exp="pattern_sat", pat=pat))
    labels, vals = [], []
    for rt in range(4):
        for p in (1, 2, 3, 4, 0):
            if (rt, p) in u:
                labels.append(f"r{rt}.{'LNESW'[p]}"); vals.append(u[(rt, p)])
    ax.bar(range(len(vals)), vals, color=[C["xbar"] if l.endswith(".L") else C["mesh"] for l in labels], width=0.7)
    ax.set_xticks(range(len(vals))); ax.set_xticklabels(labels, rotation=90, fontsize=7)
    style_ax(ax, "", "link utilisation (flits/cycle)", f"{ttl} (saturated)")
axs[0].text(0.01, 0.97, "blue: mesh link   orange: ejection port", transform=axs[0].transAxes, fontsize=8, color=INK2, va="top")
fig.tight_layout(); fig.savefig(IMG / "link_utilisation.png", dpi=170); plt.close(fig)
MD += ["![link utilisation](img/link_utilisation.png)", ""]

# ---------------------------------------------------------------- contention counters
def rp_metric(rs, name, per_cycle=True):
    acc = collections.defaultdict(list)
    for r in rs:
        cyc = r["cnt"]["cycles"]
        for m, rt, pt, v in r["cnt"]["rp"]:
            if m == name:
                acc[(rt, pt)].append(v / cyc if per_cycle else v)
    return {k: float(np.mean(v)) for k, v in acc.items()}

def tile_metric(rs, name, per_cycle=True):
    acc = collections.defaultdict(list)
    for r in rs:
        cyc = r["cnt"]["cycles"]
        for m, t, v in r["cnt"]["tile"]:
            if m == name:
                acc[t].append(v / cyc if per_cycle else v)
    return {k: float(np.mean(v)) for k, v in acc.items()}

MD += ["### 4b. Contention counters, all-to-one -> tile 0, mesh 2x2, saturated", "",
       "Rates are events per cycle over the measurement window (mean of seeds). Output-indexed: link stall (output register held a flit the "
       "sink refused), arbitration blocked (requesters present, none granted: back-pressure), arbitration losers per cycle (contention). "
       "Input-indexed: mean and maximum input-buffer occupancy (capacity 4), head-of-line blocking cycles.", ""]
rs = sel(var="mesh2x2_d4", exp="pattern_sat", pat="allto1")
if rs:
    ls = rp_metric(rs, "LINK_STALL"); ab = rp_metric(rs, "ARB_BLOCKED"); al = rp_metric(rs, "ARB_LOSE")
    oc = rp_metric(rs, "OCC_SUM"); om = rp_metric(rs, "OCC_MAX", per_cycle=False); hb = rp_metric(rs, "HOL_BLOCK")
    MD += ["| router.port | link stall | arb blocked | arb losers | mean occupancy | max occupancy | HOL block |", "|---|---|---|---|---|---|---|"]
    for rt in range(4):
        for pt in range(5):
            key = (rt, pt)
            if any(key in d for d in (ls, ab, al, oc, om, hb)):
                MD.append(f"| r{rt}.{'LNESW'[pt]} | {ls.get(key,0):.3f} | {ab.get(key,0):.3f} | {al.get(key,0):.3f} | {oc.get(key,0):.2f} | {om.get(key,0):.0f} | {hb.get(key,0):.3f} |")
    ej = tile_metric(rs, "EJ_STALL"); ist = tile_metric(rs, "INJ_STALL")
    dm = tile_metric(rs, "DST_INFLIGHT_MAX", per_cycle=False); ds = tile_metric(rs, "DST_INFLIGHT_SUM"); dc = tile_metric(rs, "DST_CONG_CYCLES")
    MD += ["", "| tile | injection stalled (source back-pressure) | ejection refused by sink | flits in flight to this tile: mean | max | cycles with >= 4 in flight |", "|---|---|---|---|---|---|"]
    for t in range(4):
        MD.append(f"| {t} | {ist.get(t,0):.3f} | {ej.get(t,0):.3f} | {ds.get(t,0):.2f} | {dm.get(t,0):.0f} | {dc.get(t,0):.3f} |")
    MD += ["", "Reading the counters: the hot tile's ejection output (`r0.L`) is *saturated*, not blocked: it is granted in every cycle "
           "(utilisation 1.000), the sink always accepts (link stall 0), and the arbiter sees about two losing requesters per cycle "
           "(ARB_LOSE). The back-pressure appears one step upstream: the links into router 0 stall (`r1.W`, `r2.S`, `r3.W`), router 0's input "
           "buffers sit nearly full (occupancy ~3.7 of 4, HOL blocking), and every other tile sees only source-side injection stalls.", ""]

# ---------------------------------------------------------------- fairness
MD += ["## 5. Fairness and waiting time under contention (all-to-one, tile 0, saturated)", "",
       "Per-source accepted throughput share. Round-robin arbitration is *locally* fair at each output, which does not make it "
       "*globally* fair: a source that merges after more hops competes against the aggregate of everything upstream "
       "(the parking-lot effect). Jain index J = (sum x)^2 / (n sum x^2); 1.0 = perfectly equal.", "",
       "| fabric | tiles | per-source share of delivered flits (src 0..n-1) | Jain | min/max | mean net latency | p99 net latency (worst source) |", "|---|---|---|---|---|---|---|"]
fair_rows = []
for var in ("mesh2x2_d4", "xbar2x2_d4", "mesh3x3_d4", "xbar3x3_d4", "mesh4x4_d4", "xbar4x4_d4"):
    rs = sel(var=var, exp="fairness")
    if not rs:
        continue
    n = rs[0]["nt"]
    shares = np.zeros(n)
    for r in rs:
        v = np.array([int(s["delivered"]) for s in r["src"]], float)
        shares += v / max(v.sum(), 1)
    shares /= len(rs)
    J = float(shares.sum() ** 2 / (n * (shares ** 2).sum()))
    p99w = max((max(r.get("per_src_lat", {}).get(str(s), r.get("per_src_lat", {}).get(s, {"net_p99": 0}))["net_p99"] for s in range(n)) for r in rs), default=math.nan)
    MD.append(f"| {var} | {n} | {', '.join(f'{x:.3f}' for x in shares)} | {J:.3f} | {shares.min()/shares.max():.2f} | {agg(rs, lambda r: r['net_mean'])[0]:.1f} | {p99w:.0f} |")
    fair_rows.append((var, n, shares, J))
fig, ax = plt.subplots(figsize=(8.8, 3.4))
off = 0
ticks, tl = [], []
for var, n, sh, J in fair_rows:
    kind = "mesh" if var.startswith("mesh") else "xbar"
    ax.bar(np.arange(n) + off, sh, color=C[kind], width=0.8)
    ax.text(off + (n - 1) / 2, max(sh) * 1.04, f"J={J:.2f}", ha="center", fontsize=8, color=INK2)
    ticks.append(off + (n - 1) / 2); tl.append(var.replace("_d4", ""))
    off += n + 1
ax.set_xticks(ticks); ax.set_xticklabels(tl, fontsize=8)
ax.set_ylim(0, 0.40)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=C["mesh"], label="mesh"), Patch(color=C["xbar"], label="crossbar")], frameon=False, fontsize=8, loc="upper right")
style_ax(ax, "", "share of delivered flits", "All-to-one: per-source share (bars = sources 0..n-1)")
fig.tight_layout(); fig.savefig(IMG / "fairness.png", dpi=170); plt.close(fig)
MD += ["", "![fairness](img/fairness.png)", ""]

# ---------------------------------------------------------------- buffer depth
MD += ["## 6. Buffer-depth sensitivity (2x2, uniform random)", "",
       "| depth | mesh sat. throughput | mesh net lat @0.375 | mesh p99 | xbar sat. throughput | xbar net lat @0.375 | xbar p99 | mesh all-to-one sat. | xbar all-to-one sat. |", "|---|---|---|---|---|---|---|---|---|"]
depths = sorted({int(r["perf"]["depth"]) for r in R if r["cfg"].get("exp") == "depth_sat"})
series = {k: {"sat": [], "lat": [], "p99": []} for k in ("mesh", "xbar")}
for d in depths:
    row = [str(d)]
    for kind in ("mesh", "xbar"):
        var = f"{kind}2x2_d{d}"
        sat = agg(sel(var=var, exp="depth_sat"), lambda r: r["tput"])[0]
        mid = sel(var=var, exp="depth_mid")
        lat = agg(mid, lambda r: r["net_mean"])[0]; p99 = pct(mid, "net", "p99")
        series[kind]["sat"].append(sat); series[kind]["lat"].append(lat); series[kind]["p99"].append(p99)
        row += [f"{sat:.3f}", f"{lat:.2f}", f"{p99:.0f}"]
    for kind in ("mesh", "xbar"):
        row.append(f"{agg(sel(var=f'{kind}2x2_d{d}', exp='depth_hot'), lambda r: r['tput'])[0]:.3f}")
    MD.append("| " + " | ".join(row[:7] + row[7:]) + " |")
fig, ax = plt.subplots(1, 2, figsize=(9.6, 3.6))
for kind in ("mesh", "xbar"):
    ax[0].plot(depths, series[kind]["sat"], color=C[kind], marker=MARK[kind], label=kind)
    ax[1].plot(depths, series[kind]["p99"], color=C[kind], marker=MARK[kind], label=kind)
    label_end(ax[0], depths[-1], series[kind]["sat"][-1], kind, C[kind]); label_end(ax[1], depths[-1], series[kind]["p99"][-1], kind, C[kind])
for a in ax:
    a.set_xscale("log", base=2); a.set_xticks(depths); a.set_xticklabels([str(d) for d in depths])
style_ax(ax[0], "input buffer depth (flits)", "saturation throughput (flits/cycle/tile)", "Saturation throughput vs depth")
style_ax(ax[1], "input buffer depth (flits)", "p99 network latency at 0.375 load (cycles)", "Tail latency vs depth")
fig.tight_layout(); fig.savefig(IMG / "depth_sensitivity.png", dpi=170); plt.close(fig)
MD += ["", "![depth](img/depth_sensitivity.png)", ""]

# ---------------------------------------------------------------- scaling
MD += ["## 7. Scaling (uniform random, d=4)", "",
       "| tiles | mesh sat. | mesh channel bound | mesh low-load latency | xbar sat. | xbar HOL limit (MC) | xbar low-load latency |", "|---|---|---|---|---|---|---|"]
for (mx, my) in ((2, 2), (3, 3), (4, 4)):
    nt = mx * my
    row = [str(nt)]
    for kind in ("mesh", "xbar"):
        var = f"{kind}{mx}x{my}_d4"
        sat = agg(sel(var=var, exp="scaling_sat"), lambda r: r["tput"])[0] if mx > 2 else agg(sel(var=var, exp="pattern_sat", pat="uniform_ne"), lambda r: r["tput"])[0]
        low = agg(sel(var=var, exp="scaling_low"), lambda r: r["net_mean"])[0]
        b = an.channel_bound(kind, mx, my, "uniform_ne")["theta_max"] if kind == "mesh" else an.hol_saturation(nt, 40000)
        row += [f"{sat:.3f}", f"{b:.3f}", f"{low:.2f}"]
    MD.append("| " + " | ".join([row[0], row[1], row[2], row[3], row[4], row[5], row[6]]) + " |")
MD += ["", "The mesh's per-tile saturation throughput *falls* with size under uniform traffic (bisection bandwidth per tile shrinks as "
       "1/k), while its latency grows with the diameter; the crossbar keeps one-router latency, its saturation approaches the large-N input-queue "
       "limit (0.586) and its logic grows about as N^2 (14,620 -> 57,412 NAND2-eq from 4 to 9 ports, 3.9x for 2.25x the endpoints; reports/synth.md). "
       "At 16 tiles the mesh's advantage in saturation throughput has nearly vanished (0.633 vs 0.603).", ""]

# ---------------------------------------------------------------- sink back-pressure
MD += ["## 8. Ejection back-pressure (uniform random, offered 0.375)", "",
       "| sink accept probability | mesh accepted | mesh net lat | xbar accepted | xbar net lat |", "|---|---|---|---|---|"]
for er in (64, 128, 192):
    row = [f"{er/256:.2f}"]
    for kind in ("mesh", "xbar"):
        rs = sel(var=f"{kind}2x2_d4", exp="sink_bp", ejrate=er)
        row += [f"{agg(rs, lambda r: r['tput'])[0]:.3f}", f"{agg(rs, lambda r: r['net_mean'])[0]:.1f}"]
    MD.append("| " + " | ".join(row) + " |")
MD.append("")

# ---------------------------------------------------------------- counter self-check
bad = [r for r in R if r.get("cnt", {}).get("latcheck") and (r["cnt"]["latcheck"]["collide"] or r["cnt"]["latcheck"]["unmatched"])]
MD += ["## 9. Measurement integrity", "",
       f"* {len(R)} simulations, all with the DUT's assertions armed and the scoreboard checking every flit: "
       f"{sum(1 for r in R if r['perf']['errors'] != '0')} reported errors.",
       f"* Hardware latency counters (when dumped) agreed with the testbench: collisions/unmatched = 0 in "
       f"{sum(1 for r in R if r.get('cnt',{}).get('latcheck') and not r['cnt']['latcheck']['collide'] and not r['cnt']['latcheck']['unmatched'])} runs, "
       f"non-zero in {len(bad)}.",
       "* The latency counters time packets whose txn_id is unique per source in flight; the load generator guarantees this for the "
       "256-entry table used here.", ""]

(ROOT / "reports" / "PERFORMANCE.md").write_text("\n".join(MD) + "\n")
print("wrote reports/PERFORMANCE.md and", len(list(IMG.glob('*.png'))), "charts")
