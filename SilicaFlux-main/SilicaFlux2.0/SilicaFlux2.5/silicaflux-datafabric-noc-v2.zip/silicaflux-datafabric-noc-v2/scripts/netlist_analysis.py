#!/usr/bin/env python3
"""Structural analysis of the synthesized (NAND/NOT/DFF) netlists written by scripts/synth.py.

 1. Combinational input -> output dependency of every top-level output (backward cone through
    combinational cells, stopping at flops). This is the machine check behind "no combinational
    ready/valid path crosses a router": a link-facing output must depend on NO input.
 2. Highest-fanout nets (control nets that need buffering / physical attention).
"""
import json, pathlib, re, sys, collections
ROOT = pathlib.Path(__file__).resolve().parent.parent

def load(name):
    j = json.load(open(ROOT / "synth" / f"{name}.json"))
    top = [m for m, d in j["modules"].items() if d.get("attributes", {}).get("top") in ("00000000000000000000000000000001", 1, "1")]
    mod = j["modules"][top[0] if top else list(j["modules"])[0]]
    return mod

def is_seq(t):
    return t.startswith("$_DFF") or t.startswith("$_ALDFF") or t.startswith("$_SDFF") or t.startswith("$_DLATCH") or t.startswith("$dff") or t.startswith("$mem")

def analyse(name):
    mod = load(name)
    ports = mod["ports"]
    bit2port = {}
    for pn, pd in ports.items():
        for i, b in enumerate(pd["bits"]):
            if isinstance(b, int):
                bit2port[b] = (pn, pd["direction"], i)
    driver = {}                       # bit -> cell name (combinational drivers only)
    cells = mod["cells"]
    loads = collections.Counter()
    for cn, c in cells.items():
        pd = c["port_directions"]
        for p, bits in c["connections"].items():
            for b in bits:
                if not isinstance(b, int):
                    continue
                if pd[p] == "output":
                    if not is_seq(c["type"]):
                        driver[b] = cn
                else:
                    loads[b] += 1
    # fanout also counts output ports as loads
    for pn, pd in ports.items():
        if pd["direction"] == "output":
            for b in pd["bits"]:
                if isinstance(b, int):
                    loads[b] += 1
    names = {}
    for nn, nd in mod["netnames"].items():
        for i, b in enumerate(nd["bits"]):
            if isinstance(b, int) and b not in names:
                names[b] = f"{nn}[{i}]" if len(nd["bits"]) > 1 else nn
    memo = {}
    def cone(bit, seen=None):
        if bit in memo:
            return memo[bit]
        res, stack, vis = set(), [bit], set()
        while stack:
            b = stack.pop()
            if b in vis:
                continue
            vis.add(b)
            if b in bit2port and bit2port[b][1] == "input":
                res.add(bit2port[b][0])
            cn = driver.get(b)
            if cn is None:
                continue
            c = cells[cn]
            for p, bits in c["connections"].items():
                if c["port_directions"][p] == "input":
                    stack.extend(x for x in bits if isinstance(x, int))
        memo[bit] = res
        return res
    deps = {}
    for pn, pd in ports.items():
        if pd["direction"] != "output":
            continue
        s = set()
        for b in pd["bits"]:
            if isinstance(b, int):
                s |= cone(b)
        deps[pn] = s
    return deps, loads, names, mod

def main():
    out = ["# Combinational dependency of outputs on inputs (gate-level, flops cut the paths)", "",
           "Netlist: `noc_router` node (1,1) of a 3x3 mesh (all five ports present), synthesized to NAND2/NOT/DFF.", ""]
    deps, loads, names, mod = analyse("router_3x3_n11_d4")
    link = [p for p in deps if re.match(r"(local|north|east|south|west)_(in_ready|out_valid|out_pkt)", p)]
    out += ["## Link-facing outputs (ready / valid / payload that other routers or tiles see)", "",
            "| output | combinationally depends on inputs |", "|---|---|"]
    bad = False
    for p in sorted(link):
        out.append(f"| {p} | {', '.join(sorted(deps[p])) or '**none** (driven only by flops)'} |")
        bad |= bool(deps[p])
    tel = [p for p in deps if p not in link]
    out += ["", "## Telemetry / error outputs (not connected to any other router)", "", "| output | combinationally depends on |", "|---|---|"]
    for p in sorted(tel):
        out.append(f"| {p} | {', '.join(sorted(deps[p])) or 'none'} |")
    out += ["", f"**Result: {'FAIL - a link-facing output depends combinationally on an input' if bad else 'PASS - no link-facing output depends combinationally on any input; every inter-router signal is flop-driven, so no combinational loop or ready-chain can form across routers in any mesh built from this router (the interconnect adds only wires; `yosys check -assert` also reports 0 problems on the flattened 2x2 mesh).'}**", ""]
    (ROOT / "reports" / "comb_paths.md").write_text("\n".join(out))

    # fanout
    fo = ["# Highest-fanout nets", "", "Flattened gate netlist of the interior router (3x3 mesh node (1,1), BUF_DEPTH=4). Fanout = number of gate/port pins driven.", "",
          "| net | fanout |", "|---|---|"]
    top = loads.most_common(40)
    seen = set()
    for b, n in top:
        nm = names.get(b, f"n{b}")
        base = re.sub(r"\[\d+\]$", "", nm)
        if base in seen and len(seen) > 12:
            continue
        seen.add(base)
        fo.append(f"| `{nm}` | {n} |")
        if len(seen) >= 18:
            break
    (ROOT / "reports" / "fanout.md").write_text("\n".join(fo) + "\n")
    print("\n".join(out)); print("\n".join(fo))
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
