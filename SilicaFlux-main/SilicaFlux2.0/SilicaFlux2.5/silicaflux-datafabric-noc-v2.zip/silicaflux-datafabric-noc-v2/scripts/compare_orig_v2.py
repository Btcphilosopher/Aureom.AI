#!/usr/bin/env python3
"""Evidence for "v2 does not change router timing": run the UNMODIFIED original router and the v2 router through the
same testbench and the same seed and compare the cycle count at the end of every test that both complete."""
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import sfbuild as sb
import regress as rg
ROOT = sb.ROOT

def tests(out):
    return [(m.group(1), m.group(2), int(m.group(3)), int(m.group(4)), int(m.group(5)))
            for m in re.finditer(r"^TEST\s+(\S+)\s+(PASS|FAIL)\s+\(inj=(\d+) ej=(\d+) cycles=(\d+)\)", out, re.M)]

def main():
    rg.ORIG_TMP = sb.BUILD / "orig_src"
    of = rg.orig_files()
    e_orig = sb.build("ORIG_mesh2x2", "tb_noc", of + ["tb/tb_noc.sv"], ["-DSF_TB_ORIGINAL"])
    e_v2 = sb.build("mesh2x2_d4", "tb_noc", sb.RTL_V2 + ["tb/tb_noc.sv"], [])
    rows, allsame = [], True
    for seed in (1, 2, 3):
        _, o = sb.run(e_orig, ["+TEST=all", f"+SEED={seed}"])
        _, v = sb.run(e_v2, ["+TEST=all", f"+SEED={seed}"])
        to, tv = tests(o), tests(v)
        n = 0
        for a, b in zip(to, tv):
            if a[0] != b[0] or a[1] != "PASS" or b[1] != "PASS":
                break
            same = (a[2:] == b[2:])
            allsame &= same
            rows.append((seed, a[0], a[4], b[4], a[2], b[2], "identical" if same else "**DIFFERENT**"))
            n += 1
    md = ["# Original router versus v2: cycle-for-cycle comparison", "",
          "Same testbench, same seeds, legal traffic, QoS off, single-flit. For every test that BOTH routers pass, the injected/ejected",
          "counts and the global cycle count at the end of the test are compared. (The original stops at the first invalid-destination",
          "packet because its own assertion aborts the run; tests after that point are not comparable.)", "",
          "| seed | test | cycles original | cycles v2 | packets (inj) orig | v2 | result |", "|---|---|---|---|---|---|---|"]
    md += [f"| {a} | {b} | {c} | {d} | {e} | {f} | {g} |" for a, b, c, d, e, f, g in rows]
    md += ["", f"**{'All compared tests identical.' if allsame else 'DIFFERENCES FOUND - see rows marked DIFFERENT.'}** ({len(rows)} comparisons)", ""]
    (ROOT / "reports" / "orig_vs_v2_cycles.md").write_text("\n".join(md))
    print("\n".join(md))
    return 0 if allsame else 1

if __name__ == "__main__":
    sys.exit(main())
