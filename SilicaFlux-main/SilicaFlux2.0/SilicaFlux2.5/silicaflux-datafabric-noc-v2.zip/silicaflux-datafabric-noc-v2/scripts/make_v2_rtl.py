#!/usr/bin/env python3
"""Derive rtl/noc_interconnect.sv (NoC v2) from the untouched original.

original/noc_interconnect.sf  --(this script)-->  rtl/noc_interconnect.sv

Every edit is an exact-string replacement whose anchor must occur exactly once;
the script aborts otherwise, so a silent mis-patch is impossible. The resulting
delta is also emitted as docs/noc_interconnect_v2.diff. Nothing in the original
router pipeline, arbitration or flow-control equations is altered; changes are
(1) hardware ingress validation, (2) optional QoS starvation guard,
(3) optional explicit head/tail framing, (4) additive telemetry/error taps,
(5) conservation-assertion bookkeeping that follows from (1).
"""
import pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
src = (ROOT / "original" / "noc_interconnect.sf").read_text()
out = src
n_edits = 0


def sub(anchor: str, repl: str, what: str):
    global out, n_edits
    cnt = out.count(anchor)
    if cnt != 1:
        sys.exit(f"PATCH FAILED [{what}]: anchor found {cnt} times\n---\n{anchor}\n---")
    out = out.replace(anchor, repl)
    n_edits += 1


# ---------------------------------------------------------------------------
# 0. Header: modification log
# ---------------------------------------------------------------------------
HDR = """// =============================================================================
//  NoC v2 MODIFICATION LOG  (derived from SilicaFlux2.5/noc_interconnect.sf by
//  scripts/make_v2_rtl.py; see docs/AUDIT.md for the evidence behind each item
//  and docs/noc_interconnect_v2.diff for the exact delta)
//
//   V2-1  Hardware ingress validation on the LOCAL port. Out-of-range or
//         aliasing dst_id, !valid, reserved packet class and src_id != tile are
//         now discarded in hardware (handshake completes, flit is not stored,
//         err_* pulse) instead of being checked only by simulation assertions.
//         Original defect: with assertions compiled out, dst_id bits above the
//         coordinate field aliased onto another tile, and an out-of-range
//         coordinate wedged the input port forever.
//   V2-2  QOS_STARVE_LIMIT: bounds consecutive high-class grants while a
//         low-class request waits (0 = original strict priority). Each class
//         has its own round-robin pointer (V2-2b; the first version shared one
//         pointer and formal found unbounded low-class starvation).
//   V2-3  EXPLICIT_FRAMING: head/tail taken from pkt.sop/pkt.eop so variable
//         length packets (as emitted by tile_interface) work; original counted
//         framing (FLITS_PER_PKT) is unchanged and remains the default.
//   V2-4  Additive telemetry taps (perf_*, err_*) for sf_noc_traffic_counters.
//   V2-5  Conservation checks count accepted (not dropped) flits.
// =============================================================================

"""
out = HDR + out
n_edits += 1

# ---------------------------------------------------------------------------
# 1. noc_router parameters
# ---------------------------------------------------------------------------
sub("""  parameter int unsigned  PROGRESS_WDOG_CYCLES = 0,
  localparam int unsigned NUM_PORTS            = 5
) (
  input  logic                 clk_i,""",
"""  parameter int unsigned  PROGRESS_WDOG_CYCLES = 0,
  parameter bit           EXPLICIT_FRAMING     = 1'b0,   // V2-3
  parameter int unsigned  QOS_STARVE_LIMIT     = 0,      // V2-2
  parameter bit           CHECK_CLASS          = 1'b1,   // V2-1
  parameter bit           CHECK_SRC            = 1'b1,   // V2-1
  localparam int unsigned NUM_PORTS            = 5
) (
  input  logic                 clk_i,""", "router params")

# ---------------------------------------------------------------------------
# 2. noc_router ports
# ---------------------------------------------------------------------------
sub("""  output logic [NUM_PORTS-1:0] perf_hol_block_o,
  output logic                 idle_o
);""",
"""  output logic [NUM_PORTS-1:0] perf_hol_block_o,
  output logic                 idle_o,

  // V2-1: ingress rejection (local port). err_drop_o pulses per discarded
  // flit, err_drop_head_o per discarded packet; err_cause_o is valid with
  // err_drop_head_o as {bad_src, bad_class_or_invalid, bad_dst}.
  output logic                 err_drop_o,
  output logic                 err_drop_head_o,
  output logic [2:0]           err_cause_o,

  // V2-4: counter taps, port order {W, S, E, N, L} = bits [4:0]
  output logic [NUM_PORTS-1:0]                           perf_in_fire_o,    // flit accepted into buffer
  output logic [NUM_PORTS-1:0]                           perf_in_head_o,    // ... and it was a head flit
  output logic [NUM_PORTS-1:0]                           perf_out_fire_o,   // link/ejection transfer
  output logic [NUM_PORTS-1:0]                           perf_out_head_o,   // ... of a head flit
  output logic [NUM_PORTS-1:0][NUM_PORTS-1:0]            perf_sa_req_o,     // [out][in] requests
  output logic [NUM_PORTS-1:0][NUM_PORTS-1:0]            perf_sa_gnt_o,     // [out][in] grants
  output logic [NUM_PORTS-1:0][$clog2(BUF_DEPTH+1)-1:0]  perf_buf_count_o,  // input buffer occupancy
  output pkt_t [NUM_PORTS-1:0]                           perf_out_pkt_o     // flit held in each output register
);""", "router ports")

# ---------------------------------------------------------------------------
# 3. derived localparam
# ---------------------------------------------------------------------------
sub("""  localparam int unsigned PKT_W      = $bits(pkt_t);
""",
"""  localparam int unsigned PKT_W      = $bits(pkt_t);
  localparam bit          WORMHOLE   = (FLITS_PER_PKT > 1) || EXPLICIT_FRAMING;
""", "wormhole localparam")

# ---------------------------------------------------------------------------
# 4. new signals
# ---------------------------------------------------------------------------
sub("""  logic        [NUM_PORTS-1:0]                in_push;
""",
"""  logic        [NUM_PORTS-1:0]                in_push;
  logic        [NUM_PORTS-1:0]                in_acc;       // V2-1 handshake accepted (incl. dropped)
  logic        [NUM_PORTS-1:0]                in_drop;      // V2-1 accepted but discarded
  logic        [NUM_PORTS-1:0][2:0]           rc_bad;       // V2-1 head rejection cause
  logic        [NUM_PORTS-1:0]                hd_head;
""", "new signals")

# ---------------------------------------------------------------------------
# 5. route compute: explicit framing + counted (in_acc) + validation
# ---------------------------------------------------------------------------
sub("""      if (FLITS_PER_PKT > 1) begin : g_wormhole
        // Head flit carries the route; body/tail flits follow the held route
        logic [FLIT_CNT_W-1:0] flit_idx_q;""",
"""      if (EXPLICIT_FRAMING) begin : g_explicit
        // V2-3: head/tail from the flit itself; body flits follow the held route
        logic [NUM_PORTS-1:0]  route_hold_q;

        assign head      = in_pkt[i].sop;
        assign tail      = in_pkt[i].eop;
        assign route_raw = head ? dor_select(productive) : route_hold_q;

        always_ff @(posedge clk_i or negedge rst_ni) begin
          if (!rst_ni) begin
            route_hold_q <= '0;
          end else if (in_acc[i] && head) begin
            route_hold_q <= route_raw;
          end
        end
      end else if (FLITS_PER_PKT > 1) begin : g_wormhole
        // Head flit carries the route; body/tail flits follow the held route
        logic [FLIT_CNT_W-1:0] flit_idx_q;""", "route compute explicit")

sub("""          end else if (in_push[i]) begin
            flit_idx_q <= tail ? '0 : (flit_idx_q + FLIT_CNT_W'(1));""",
"""          end else if (in_acc[i]) begin
            flit_idx_q <= tail ? '0 : (flit_idx_q + FLIT_CNT_W'(1));""", "counted framing uses in_acc")

sub("""      assign rc_route[i] = route_raw & REQ_LEGAL[i];
      assign rc_head[i]  = head;
      assign rc_tail[i]  = tail;
""",
"""      assign rc_route[i] = route_raw & REQ_LEGAL[i];
      assign rc_head[i]  = head;
      assign rc_tail[i]  = tail;

      // V2-1: hardware ingress validation (local injection port only; mesh
      // links only ever carry flits that already passed this check)
      if (i == PORT_LOCAL) begin : g_inj_check
        logic bad_dst;
        logic bad_cls;
        logic bad_src;
        assign bad_dst = ~((((in_pkt[i].dst_id >> COORD_W) == '0)) &&
                           (32'(dst_x) < MESH_X) && (32'(dst_y) < MESH_Y));
        assign bad_cls = ~in_pkt[i].valid | (CHECK_CLASS & ~sf_noc_class_legal(in_pkt[i].pclass));
        assign bad_src = CHECK_SRC & (in_pkt[i].src_id != TILE_ID_W'(MY_ID));
        assign rc_bad[i] = {bad_src, bad_cls, bad_dst};
      end else begin : g_no_check
        assign rc_bad[i] = '0;
      end
""", "route compute validation")

sub("""    end else begin : g_absent
      assign rc_route[i] = '0;
      assign rc_head[i]  = 1'b0;
      assign rc_tail[i]  = 1'b0;
    end""",
"""    end else begin : g_absent
      assign rc_route[i] = '0;
      assign rc_head[i]  = 1'b0;
      assign rc_tail[i]  = 1'b0;
      assign rc_bad[i]   = '0;
    end""", "route compute absent")

# source-id assertion only when the hardware check is enabled
sub("""          (in_push[i] && head) |-> (in_pkt[i].src_id == TILE_ID_W'(MY_ID)))""",
    """          (in_push[i] && head && CHECK_SRC) |-> (in_pkt[i].src_id == TILE_ID_W'(MY_ID)))""",
    "src assertion")

# ---------------------------------------------------------------------------
# 6. input buffer: accept / drop / push
# ---------------------------------------------------------------------------
sub("""      logic              push;
      logic              pop;
""",
"""      logic              push;
      logic              acc;
      logic              pop;
""", "buffer decl")

sub("""      assign push        = in_valid[i] & ~full_q;
      assign pop         = hd_pop[i];
      assign in_ready[i] = ~full_q;
      assign in_push[i]  = push;
""",
"""      assign acc         = in_valid[i] & ~full_q;       // link handshake (unchanged ready)
      assign pop         = hd_pop[i];
      assign in_ready[i] = ~full_q;
      assign in_acc[i]   = acc;

      // V2-1: discard rejected packets whole (head decides, body flits follow)
      if (i == PORT_LOCAL) begin : g_inj_drop
        logic drop_q;
        logic head_bad;
        assign head_bad   = |rc_bad[i];
        assign in_drop[i] = acc & ((rc_head[i] & head_bad) | drop_q);
        always_ff @(posedge clk_i or negedge rst_ni) begin
          if (!rst_ni) begin
            drop_q <= 1'b0;
          end else if (acc) begin
            drop_q <= (rc_head[i] ? head_bad : drop_q) & ~rc_tail[i];
          end
        end
      end else begin : g_no_drop
        assign in_drop[i] = 1'b0;
      end

      assign push        = acc & ~in_drop[i];
      assign in_push[i]  = push;
""", "buffer accept/drop")

sub("""      assign in_ready[i]  = 1'b0;
      assign in_push[i]   = 1'b0;
""",
"""      assign in_ready[i]  = 1'b0;
      assign in_push[i]   = 1'b0;
      assign in_acc[i]    = 1'b0;
      assign in_drop[i]   = 1'b0;
""", "buffer absent")

# ---------------------------------------------------------------------------
# 7. head vector + QoS guard
# ---------------------------------------------------------------------------
sub("""  // QoS class of each buffer head
  always_comb begin
    for (int i = 0; i < NUM_PORTS; i++) begin
      hd_qos_hi[i] = QOS_ARB_EN & hd_entry[i].pkt.qos[QOS_W-1];
    end
  end
""",
"""  // QoS class of each buffer head
  always_comb begin
    for (int i = 0; i < NUM_PORTS; i++) begin
      hd_qos_hi[i] = QOS_ARB_EN & hd_entry[i].pkt.qos[QOS_W-1];
      hd_head[i]   = hd_entry[i].head;
    end
  end
""", "head vector")

sub("""      logic [NUM_PORTS-1:0] req_hi;
      logic [NUM_PORTS-1:0] req_arb;""",
"""      logic [NUM_PORTS-1:0] req_hi;
      logic [NUM_PORTS-1:0] req_lo;
      logic                 force_lo;
      logic [NUM_PORTS-1:0] req_arb;""", "sa decl")

sub("""      assign req_hi         = req & hd_qos_hi;
      assign req_arb        = (|req_hi) ? req_hi : req;
""",
"""      assign req_hi         = req & hd_qos_hi;
      assign req_lo         = req & ~hd_qos_hi;

      // V2-2: after QOS_STARVE_LIMIT consecutive high-class grants while a
      // low-class request waits, the low class is served next.
      if (QOS_ARB_EN && QOS_STARVE_LIMIT > 0) begin : g_starve_guard
        localparam int unsigned RUN_W = $clog2(QOS_STARVE_LIMIT + 1);
        logic [RUN_W-1:0] hi_run_q;
        assign force_lo = (hi_run_q == RUN_W'(QOS_STARVE_LIMIT)) & (|req_lo);
        always_ff @(posedge clk_i or negedge rst_ni) begin
          if (!rst_ni) begin
            hi_run_q <= '0;
          end else if (arb_advance) begin
            if ((|(sa_gnt[o] & hd_qos_hi)) && (|req_lo)) begin
              hi_run_q <= hi_run_q + RUN_W'(1);
            end else begin
              hi_run_q <= '0;
            end
          end
        end
      end else begin : g_no_starve_guard
        assign force_lo = 1'b0;
      end

      assign req_arb        = force_lo ? req_lo : ((|req_hi) ? req_hi : req);
""", "qos guard")

sub("""      if (FLITS_PER_PKT > 1) begin : g_wormhole_lock""",
    """      if (WORMHOLE) begin : g_wormhole_lock""", "wormhole lock")

# V2-2b: one pointer per class. A single shared pointer lets a persistent high-class
# requester park it above a low requester's index, so forced low-class slots
# always favour higher-indexed lows and the low requester can starve (found by
# formal: formal/fv_router.sv P_QOS). With QoS off every head is "low", so the
# low pointer is the original pointer and behaviour is unchanged.
sub("""      logic [NUM_PORTS-1:0] rr_mask_q;
""",
"""      logic [NUM_PORTS-1:0] rr_mask_q;       // low class (the only pointer when QoS is off)
      logic [NUM_PORTS-1:0] rr_mask_hi_q;    // V2-2b: high class has its own pointer
""", "rr hi decl")

sub("""      assign req_masked     = req_arb & rr_mask_q;""",
    """      assign req_masked     = req_arb & ((QOS_ARB_EN && !force_lo && (|req_hi)) ? rr_mask_hi_q : rr_mask_q);""",
    "rr masked")

sub("""        if (!rst_ni) begin
          rr_mask_q <= '0;
        end else if (arb_advance) begin
          rr_mask_q <= ~(sa_gnt[o] | (sa_gnt[o] - NUM_PORTS'(1)));
        end""",
"""        if (!rst_ni) begin
          rr_mask_q    <= '0;
          rr_mask_hi_q <= '0;
        end else if (arb_advance) begin
          if (|(sa_gnt[o] & hd_qos_hi)) begin
            rr_mask_hi_q <= ~(sa_gnt[o] | (sa_gnt[o] - NUM_PORTS'(1)));
          end else begin
            rr_mask_q    <= ~(sa_gnt[o] | (sa_gnt[o] - NUM_PORTS'(1)));
          end
        end""", "rr update")

# ---------------------------------------------------------------------------
# 8. egress head tracking
# ---------------------------------------------------------------------------
sub("""      logic             valid_q;
      pkt_t             pkt_q;
""",
"""      logic             valid_q;
      logic             head_q;
      pkt_t             pkt_q;
""", "egress decl")

sub("""      always_ff @(posedge clk_i) begin
        if (sa_fire[o]) begin
          pkt_q <= pkt_t'(xbar_bits);
        end
      end

      assign out_valid[o] = valid_q;
      assign out_pkt[o]   = pkt_q;
""",
"""      always_ff @(posedge clk_i) begin
        if (sa_fire[o]) begin
          pkt_q  <= pkt_t'(xbar_bits);
          head_q <= |(sa_gnt[o] & hd_head);
        end
      end

      assign out_valid[o]        = valid_q;
      assign out_pkt[o]          = pkt_q;
      assign perf_out_head_o[o]  = valid_q & out_ready[o] & head_q;
""", "egress body")

sub("""    end else begin : g_absent
      assign out_valid[o] = 1'b0;
      assign out_pkt[o]   = '0;
    end""",
"""    end else begin : g_absent
      assign out_valid[o]       = 1'b0;
      assign out_pkt[o]         = '0;
      assign perf_out_head_o[o] = 1'b0;
    end""", "egress absent")

# ---------------------------------------------------------------------------
# 9. telemetry / error taps
# ---------------------------------------------------------------------------
sub("""  assign idle_o            = ~|{hd_valid, out_valid};
""",
"""  assign idle_o            = ~|{hd_valid, out_valid};

  // V2-1 / V2-4 taps
  assign err_drop_o        = |in_drop;
  assign err_drop_head_o   = |(in_drop & rc_head);
  assign err_cause_o       = rc_bad[PORT_LOCAL];
  assign perf_in_fire_o    = in_push;
  assign perf_in_head_o    = in_push & rc_head;
  assign perf_out_fire_o   = out_valid & out_ready;
  assign perf_sa_req_o     = sa_req;
  assign perf_sa_gnt_o     = sa_gnt;
  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_tap_occ
    assign perf_buf_count_o[p] = buf_count[p];
    assign perf_out_pkt_o[p]   = out_pkt[p];
  end
""", "taps")

sub("""                    + OCC_W'($countones(in_valid & in_ready))""",
    """                    + OCC_W'($countones(in_push))""", "occupancy shadow")

# ---------------------------------------------------------------------------
# 10. noc_interconnect
# ---------------------------------------------------------------------------
sub("""  parameter int unsigned  PROGRESS_WDOG_CYCLES = 0,
  localparam int unsigned NUM_TILES            = MESH_X * MESH_Y,""",
"""  parameter int unsigned  PROGRESS_WDOG_CYCLES = 0,
  parameter bit           EXPLICIT_FRAMING     = 1'b0,
  parameter int unsigned  QOS_STARVE_LIMIT     = 0,
  parameter bit           CHECK_CLASS          = 1'b1,
  parameter bit           CHECK_SRC            = 1'b1,
  localparam int unsigned NUM_TILES            = MESH_X * MESH_Y,""", "interconnect params")

sub("""  // Fabric quiescent: all buffers and egress registers empty
  output logic                                noc_idle_o
);""",
"""  // Fabric quiescent: all buffers and egress registers empty
  output logic                                noc_idle_o,

  // V2-1 ingress rejection per tile (see noc_router)
  output logic [NUM_TILES-1:0]                err_drop_o,
  output logic [NUM_TILES-1:0]                err_drop_head_o,
  output logic [NUM_TILES-1:0][2:0]           err_cause_o,

  // V2-4 counter taps per router, port order {W, S, E, N, L}
  output logic [NUM_TILES-1:0][NUM_PORTS-1:0]                          perf_in_fire_o,
  output logic [NUM_TILES-1:0][NUM_PORTS-1:0]                          perf_in_head_o,
  output logic [NUM_TILES-1:0][NUM_PORTS-1:0]                          perf_out_fire_o,
  output logic [NUM_TILES-1:0][NUM_PORTS-1:0]                          perf_out_head_o,
  output logic [NUM_TILES-1:0][NUM_PORTS-1:0][NUM_PORTS-1:0]           perf_sa_req_o,
  output logic [NUM_TILES-1:0][NUM_PORTS-1:0][NUM_PORTS-1:0]           perf_sa_gnt_o,
  output logic [NUM_TILES-1:0][NUM_PORTS-1:0][$clog2(BUF_DEPTH+1)-1:0] perf_buf_count_o,
  output pkt_t [NUM_TILES-1:0][NUM_PORTS-1:0]                          perf_out_pkt_o
);""", "interconnect ports")

sub("""        .PROGRESS_WDOG_CYCLES (PROGRESS_WDOG_CYCLES)
      ) u_router (""",
"""        .PROGRESS_WDOG_CYCLES (PROGRESS_WDOG_CYCLES),
        .EXPLICIT_FRAMING     (EXPLICIT_FRAMING),
        .QOS_STARVE_LIMIT     (QOS_STARVE_LIMIT),
        .CHECK_CLASS          (CHECK_CLASS),
        .CHECK_SRC            (CHECK_SRC)
      ) u_router (""", "router instance params")

sub("""        .idle_o            (router_idle[TILE])
      );""",
"""        .idle_o            (router_idle[TILE]),

        .err_drop_o        (err_drop_o[TILE]),
        .err_drop_head_o   (err_drop_head_o[TILE]),
        .err_cause_o       (err_cause_o[TILE]),
        .perf_in_fire_o    (perf_in_fire_o[TILE]),
        .perf_in_head_o    (perf_in_head_o[TILE]),
        .perf_out_fire_o   (perf_out_fire_o[TILE]),
        .perf_out_head_o   (perf_out_head_o[TILE]),
        .perf_sa_req_o     (perf_sa_req_o[TILE]),
        .perf_sa_gnt_o     (perf_sa_gnt_o[TILE]),
        .perf_buf_count_o  (perf_buf_count_o[TILE]),
        .perf_out_pkt_o    (perf_out_pkt_o[TILE])
      );""", "router instance ports")

sub("""  assign inj_fire_cnt = FLIGHT_W'($countones(tile_inj_valid_i & tile_inj_ready_o));""",
"""  // V2-5: count flits accepted into the fabric (dropped flits never enter it)
  logic [NUM_TILES-1:0] inj_accept;
  always_comb begin
    for (int t = 0; t < NUM_TILES; t++) begin
      inj_accept[t] = perf_in_fire_o[t][0];
    end
  end
  assign inj_fire_cnt = FLIGHT_W'($countones(inj_accept));""", "conservation inject")

(ROOT / "rtl" / "noc_interconnect.sv").write_text(out)
print(f"rtl/noc_interconnect.sv written: {n_edits} edits, {len(out.splitlines())} lines "
      f"(original {len(src.splitlines())} lines)")
