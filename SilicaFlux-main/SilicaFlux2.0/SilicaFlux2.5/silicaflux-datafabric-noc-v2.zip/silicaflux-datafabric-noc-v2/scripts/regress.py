#!/usr/bin/env python3
"""Functional regression: config x seed matrix over tb/tb_noc.sv.

  scripts/regress.py [--quick] [--seeds 1,2,3] [--only name,name]

Writes reports/regression.md and reports/regression.json. A configuration may
declare tests that are EXPECTED to fail (used for the unmodified original
router, whose known defects must be reproduced, not hidden).
"""
import argparse, json, pathlib, re, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import sfbuild as sb

ROOT = sb.ROOT
ORIG_TMP = sb.BUILD / "orig_src"

# name, verilator args, expected-failing tests, use-original-rtl, expected-abort-assertion
CONFIGS = [
    # --- mesh 2x2 (the baseline configuration), buffer depth sweep
    ("mesh2x2_d2",   ["-GBUF_DEPTH=2"], [], False),
    ("mesh2x2_d3",   ["-GBUF_DEPTH=3"], [], False),
    ("mesh2x2_d4",   [], [], False),
    ("mesh2x2_d8",   ["-GBUF_DEPTH=8"], [], False),
    # --- larger / non-square / non-power-of-two meshes (tile ID != tile index)
    ("mesh3x3_d4",   ["-GMESH_X=3", "-GMESH_Y=3"], [], False),
    ("mesh4x4_d4",   ["-GMESH_X=4", "-GMESH_Y=4"], [], False),
    ("mesh3x2_d4",   ["-GMESH_X=3", "-GMESH_Y=2"], [], False),
    ("mesh2x3_d4",   ["-GMESH_X=2", "-GMESH_Y=3"], [], False),
    ("mesh4x2_d3",   ["-GMESH_X=4", "-GMESH_Y=2", "-GBUF_DEPTH=3"], [], False),
    # --- framing
    ("mesh2x2_flits2", ["-GFLITS_PER_PKT=2"], [], False),
    ("mesh2x2_flits4_d2", ["-GFLITS_PER_PKT=4", "-GBUF_DEPTH=2"], [], False),
    ("mesh2x2_explicit", ["-GEXPLICIT_FRAMING=1", "-GVARLEN=4"], [], False),
    ("mesh3x3_explicit", ["-GMESH_X=3", "-GMESH_Y=3", "-GEXPLICIT_FRAMING=1", "-GVARLEN=3"], [], False),
    # --- QoS
    ("mesh2x2_qos_guard7", ["-GQOS_ARB_EN=1", "-GQOS_LIMIT=7"], [], False),
    ("mesh2x2_qos_guard3", ["-GQOS_ARB_EN=1", "-GQOS_LIMIT=3"], [], False),
    ("mesh2x2_qos_strict", ["-GQOS_ARB_EN=1", "-GQOS_LIMIT=0"], ["qos_class_starvation"], False),
    # --- crossbar comparison fabric
    ("xbar4_d4",     ["-GFABRIC=1"], [], False),
    ("xbar9_d4",     ["-GFABRIC=1", "-GMESH_X=3", "-GMESH_Y=3"], [], False),
    ("xbar16_d4",    ["-GFABRIC=1", "-GMESH_X=4", "-GMESH_Y=4"], [], False),
    # --- the UNMODIFIED original router (baseline: defects must reproduce)
    # simulation view: the router's own assertion aborts the run at the bad destination
    ("ORIG_mesh2x2", ["-DSF_TB_ORIGINAL"], [], True, "a_inj_reachable"),
    ("ORIG_mesh2x2_qos", ["-DSF_TB_ORIGINAL", "-GQOS_ARB_EN=1"], ["qos_class_starvation"], True, "a_inj_reachable"),
    ("ORIG_mesh3x3", ["-DSF_TB_ORIGINAL", "-GMESH_X=3", "-GMESH_Y=3"], [], True, "a_inj_reachable|a_rc_turn_legal"),
    ("ORIG_mesh2x2_flits2", ["-DSF_TB_ORIGINAL", "-GFLITS_PER_PKT=2"], [], True, "a_inj_reachable"),
    ("ORIG_mesh2x2_flits4", ["-DSF_TB_ORIGINAL", "-GFLITS_PER_PKT=4"], [], True, "a_inj_reachable"),
    ("ORIG_mesh3x3_hwview", ["-DSF_TB_ORIGINAL", "-DSYNTHESIS", "-GMESH_X=3", "-GMESH_Y=3"],
     ["invalid_destination", "reserved_class_and_invalid_pkt", "spoofed_source_id"], True, ""),
    # hardware view: assertions compiled out (as in synthesis) -> mis-delivery shows up as FAILs
    ("ORIG_mesh2x2_hwview", ["-DSF_TB_ORIGINAL", "-DSYNTHESIS"],
     ["invalid_destination", "reserved_class_and_invalid_pkt", "spoofed_source_id"], True, ""),
]
CONFIGS = [c if len(c) == 5 else (*c, "") for c in CONFIGS]
QUICK = {"mesh2x2_d4", "mesh3x3_d4", "mesh2x2_explicit", "xbar4_d4", "ORIG_mesh2x2"}


def orig_files():
    ORIG_TMP.mkdir(parents=True, exist_ok=True)
    f = ORIG_TMP / "noc_interconnect_orig.sv"       # .sf is plain SystemVerilog: rename only
    f.write_text((ROOT / "original" / "noc_interconnect.sf").read_text())
    stub = ORIG_TMP / "xbar_stub.sv"
    stub.write_text("""module sf_noc_xbar import silicaflux_pkg::*; #(parameter int NUM_TILES=4, parameter int MESH_X=2,
 parameter int MESH_Y=2, parameter int BUF_DEPTH=4)(
 input logic clk_i, rst_ni, input logic [NUM_TILES-1:0] tile_inj_valid_i, input noc_packet_t [NUM_TILES-1:0] tile_inj_pkt_i,
 output logic [NUM_TILES-1:0] tile_inj_ready_o, output logic [NUM_TILES-1:0] tile_ej_valid_o, output noc_packet_t [NUM_TILES-1:0] tile_ej_pkt_o,
 input logic [NUM_TILES-1:0] tile_ej_ready_i, output logic noc_idle_o, output logic [NUM_TILES-1:0] err_drop_o,
 output logic [NUM_TILES-1:0][2:0] err_cause_o, output logic [NUM_TILES-1:0] perf_in_fire_o, output logic [NUM_TILES-1:0] perf_out_fire_o,
 output logic [NUM_TILES-1:0][NUM_TILES-1:0] perf_sa_req_o, perf_sa_gnt_o, output logic [NUM_TILES-1:0][$clog2(BUF_DEPTH+1)-1:0] perf_buf_count_o);
 assign tile_inj_ready_o='0; assign tile_ej_valid_o='0; assign tile_ej_pkt_o='0; assign noc_idle_o=1;
 assign err_drop_o='0; assign err_cause_o='0; assign perf_in_fire_o='0; assign perf_out_fire_o='0;
 assign perf_sa_req_o='0; assign perf_sa_gnt_o='0; assign perf_buf_count_o='0;
endmodule
""")
    return [sb.PKG, str(f), str(stub)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--seeds", default="1,2,3")
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default="regression")
    a = ap.parse_args()
    seeds = [int(x) for x in a.seeds.split(",")]
    sel = [c for c in CONFIGS if (not a.quick or c[0] in QUICK) and (not a.only or c[0] in a.only.split(","))]
    ofiles = orig_files() if any(c[3] for c in sel) else None
    t0 = time.time()

    def do_build(c):
        name, args, exp, orig, _abort = c
        files = (ofiles if orig else sb.RTL_V2) + ["tb/tb_noc.sv"]
        return c, sb.build(name, "tb_noc", files, args)

    print(f"building {len(sel)} configurations ...", flush=True)
    built = sb.pmap(do_build, sel)
    print(f"  built in {time.time()-t0:.0f}s", flush=True)

    jobs = [(c, exe, s) for c, exe in built for s in seeds]

    def do_run(j):
        c, exe, seed = j
        rc, out = sb.run(exe, [f"+TEST=all", f"+SEED={seed}"])
        tests = re.findall(r"^TEST\s+(\S+)\s+(PASS|FAIL)", out, re.M)
        res = re.search(r"RESULT:\s*(PASS|FAIL)", out)
        return {"config": c[0], "seed": seed, "rc": rc, "tests": tests,
                "result": res.group(1) if res else "NO-RESULT",
                "failed": [t for t, v in tests if v == "FAIL"],
                "aborted_by": (re.search(r"Assertion failed in \S+\.(a_\w+)", out) or [None, ""])[1],
                "expected_fail": c[2], "tail": out[-1500:] if rc and not tests else ""}

    results = sb.pmap(do_run, jobs)

    rows, ok_all = [], True
    for c, _ in built:
        rs = [r for r in results if r["config"] == c[0]]
        npass = [len([1 for t, v in r["tests"] if v == "PASS"]) for r in rs]
        ntot = [len(r["tests"]) for r in rs]
        failed = sorted({f for r in rs for f in r["failed"]})
        exp = sorted(c[2])
        abort = c[4]
        aborted = {r["aborted_by"] for r in rs}
        if abort:      # the run must terminate on exactly that DUT assertion
            good = failed == exp and bool(aborted) and aborted <= set(abort.split("|"))   # either assertion catches an unroutable dst
        else:
            good = failed == exp and aborted == {""} and \
                (all(r["result"] == "PASS" for r in rs) if not exp else all(r["result"] == "FAIL" for r in rs))
        ok_all &= good
        verdict = "OK" if good else "UNEXPECTED"
        if abort and good:
            verdict = f"OK (aborts on {', '.join(sorted(aborted))})"
        rows.append((c[0], len(rs), f"{min(npass)}/{max(ntot) if ntot else 0}", ", ".join(failed) or "-",
                     (", ".join(exp) or "-") + (f" + abort:{abort}" if abort else ""), verdict))

    md = ["# Functional regression", "",
          f"Seeds: {seeds}. Each run executes the full directed + random suite in `tb/tb_noc.sv` with the DUT's own",
          "assertions armed. `expected-fail` lists tests that the *unmodified original* router is known to fail",
          "(or strict-priority QoS fails by design); for those rows the regression requires the failure to reproduce.", "",
          "| configuration | seeds | min tests passed | failing tests | expected-fail | verdict |",
          "|---|---|---|---|---|---|"]
    md += [f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[4]} | {r[5]} |" for r in rows]
    md += ["", f"**Overall: {'ALL AS EXPECTED' if ok_all else 'UNEXPECTED RESULTS - see rows marked UNEXPECTED'}**", ""]
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / f"{a.out}.md").write_text("\n".join(md))
    (ROOT / "reports" / f"{a.out}.json").write_text(json.dumps(results, indent=1))
    print("\n".join(md))
    print(f"total {time.time()-t0:.0f}s")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
