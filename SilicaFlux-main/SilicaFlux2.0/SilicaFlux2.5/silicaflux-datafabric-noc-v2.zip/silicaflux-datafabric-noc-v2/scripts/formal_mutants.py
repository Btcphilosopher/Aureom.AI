#!/usr/bin/env python3
"""Non-vacuity check for the formal properties: every mutant of the router RTL must
make the property group that targets it FAIL (counterexample). A property that still
passes on its mutant is vacuous or too weak and is reported as UNCAUGHT."""
import pathlib, re, shutil, subprocess, sys, concurrent.futures as cf
ROOT = pathlib.Path(__file__).resolve().parent.parent
F = ROOT / "formal"
SRC = (ROOT / "rtl" / "noc_interconnect.sv").read_text()

MUTANTS = [
  # name, task, (anchor, replacement), description
  ("rr_fixed_priority", "fair",
   ("            rr_mask_q    <= ~(sa_gnt[o] | (sa_gnt[o] - NUM_PORTS'(1)));", "            rr_mask_q    <= '0;"),
   "round-robin pointer never rotates: lowest-numbered input always wins"),
  ("route_east_west_swapped", "route_bmc",
   ("    prod[PORT_EAST]  = ~delta_x[X_W] & ~x_done;\n    prod[PORT_WEST]  =  delta_x[X_W];",
    "    prod[PORT_EAST]  =  delta_x[X_W];\n    prod[PORT_WEST]  = ~delta_x[X_W] & ~x_done;"),
   "XY decode sends eastbound traffic west and vice versa"),
  ("egress_drops_under_stall", "hold_bmc",
   ("        end else if (out_ready[o]) begin\n          valid_q <= 1'b0;", "        end else begin\n          valid_q <= 1'b0;"),
   "egress valid clears even when the sink has not accepted the flit"),
  ("buffer_never_full", "gnt_bmc",
   ("          full_q  <= (count_d == CNT_W'(BUF_DEPTH));", "          full_q  <= (count_d == CNT_W'(BUF_DEPTH + 1));"),
   "full flag never asserts: input buffer can overflow"),
  ("ingress_validation_off", "ingress_bmc",
   ("      assign push        = acc & ~in_drop[i];", "      assign push        = acc;"),
   "rejected local-port flits are stored and forwarded"),
  ("qos_guard_removed", "qos",
   ("        assign force_lo = (hi_run_q == RUN_W'(QOS_STARVE_LIMIT)) & (|req_lo);", "        assign force_lo = 1'b0;"),
   "QoS starvation guard disabled: strict priority"),
  ("qos_shared_pointer", "qos",
   [("assign req_masked     = req_arb & ((QOS_ARB_EN && !force_lo && (|req_hi)) ? rr_mask_hi_q : rr_mask_q);",
     "assign req_masked     = req_arb & rr_mask_q;"),
    ("if (|(sa_gnt[o] & hd_qos_hi)) begin", "if (1'b0) begin")],
   "ONE round-robin pointer shared by both classes (my first QoS guard): low requester can starve"),
  ("mesh_route_swapped", "mesh",
   ("    prod[PORT_EAST]  = ~delta_x[X_W] & ~x_done;\n    prod[PORT_WEST]  =  delta_x[X_W];",
    "    prod[PORT_EAST]  =  delta_x[X_W];\n    prod[PORT_WEST]  = ~delta_x[X_W] & ~x_done;"),
   "mesh-level: XY decode swapped in every router (misdelivery for any pair with an X hop)"),
  ("arb_ignores_backpressure", "gnt_bmc",
   ("  assign out_can_accept = ~out_valid[o] | out_ready[o];", "  assign out_can_accept = 1'b1;"),
   "switch allocator grants into an occupied, stalled egress register"),
]

def run(m):
    name, task, edits, desc = m
    if isinstance(edits[0], str):
        edits = [edits]
    d = F / "mut" / name
    shutil.rmtree(d, ignore_errors=True); d.mkdir(parents=True)
    src = SRC
    for (a, b) in edits:
        if src.count(a) != 1:
            pat = re.escape(a.strip())
            hits = re.findall(pat, src)
            if len(hits) != 1:
                return (name, task, "ANCHOR?", desc, f"anchor matched {len(hits)} times: {a.strip()[:50]}")
            mm = re.search(pat, src)
            src = src[:mm.start()] + b.strip() + src[mm.end():]
        else:
            src = src.replace(a, b)
    (d / "noc_interconnect.sv").write_text(src)
    base = "mesh.sby" if task == "mesh" else "router.sby"
    sby = (F / base).read_text().replace("../rtl/noc_interconnect.sv", f"mut/{name}/noc_interconnect.sv")
    (F / f"mut_{name}.sby").write_text(sby)
    shutil.rmtree(F / f"mut_{name}_{task}", ignore_errors=True)
    env_path = f"{ROOT}/build/bin:/usr/bin:/bin:/usr/local/bin"
    try:
        r = subprocess.run([str(ROOT / "build/venv/bin/yowasp-sby"), "-f", f"mut_{name}.sby", task],
                           cwd=F, capture_output=True, text=True, timeout=400, env={"PATH": env_path, "HOME": "/root"})
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return (name, task, "TIMEOUT", desc, "")
    res = re.search(r"DONE \((\w+),", out)
    res = res.group(1) if res else "ERROR"
    af = re.search(r"Assert failed in \w+: (\S+)", out)
    return (name, task, "CAUGHT" if res == "FAIL" else ("UNCAUGHT" if res == "PASS" else res), desc, af.group(1) if af else "")

if __name__ == "__main__":
    only = sys.argv[1:]
    ms = [m for m in MUTANTS if not only or m[0] in only]
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        res = list(ex.map(run, ms))
    lines = ["| mutant | property task | verdict | what was broken | failing assertion |", "|---|---|---|---|---|"]
    for n, t, v, d, a in res:
        lines.append(f"| {n} | {t} | **{v}** | {d} | {a} |")
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "formal_mutants.md").write_text("# Formal non-vacuity (mutation) check\n\n" + "\n".join(lines) + "\n")
    print("\n".join(lines))
    sys.exit(0 if all(v == "CAUGHT" for _, _, v, _, _ in res) else 1)
