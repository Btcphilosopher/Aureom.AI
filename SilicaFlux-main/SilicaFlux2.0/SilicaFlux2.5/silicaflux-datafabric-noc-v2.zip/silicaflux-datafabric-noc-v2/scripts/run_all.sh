#!/usr/bin/env bash
# Full pipeline. About 45-60 minutes on 4 cores. Order matters only for CPU load.
set -u
cd "$(dirname "$0")/.."
python3 scripts/make_v2_rtl.py
python3 scripts/regress.py            || echo "REGRESS: unexpected results"
python3 scripts/compare_orig_v2.py    || echo "ORIG vs V2: differences"
python3 scripts/qos_report.py         || echo "QOS report failed"
python3 scripts/regress_sys.py        || echo "SYS REGRESS: unexpected results"
python3 scripts/perf_lab.py           || echo "PERF LAB: problem runs"
python3 scripts/perf_report.py        || echo "PERF REPORT failed"
python3 scripts/run_formal.py --all   || echo "FORMAL: failures"
python3 scripts/formal_mutants.py     || echo "FORMAL MUTANTS: uncaught"
python3 scripts/synth.py              || echo "SYNTH failed"
python3 scripts/netlist_analysis.py   || echo "NETLIST analysis failed"
echo "ALL DONE"
