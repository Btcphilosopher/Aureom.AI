// =============================================================================
//  Integration example: a 2x2 SilicaFlux system with four tiles, each with a
//  scratchpad (real memory_controller) reachable from every tile over the NoC.
//
//  The tile-side ports are the memory_controller slave ports: wire a tile's
//  scalar LSU, vector LSU and DMA to `scalar_*[t]`, `vector_*[t]`, `burst_*[t]`
//  exactly as you would to a local controller. Tile t's memory is at
//      MAP_BASE + (t << MAP_SHIFT) + offset           (here 0x1000_0000 + t * 1 MiB)
//  Tile 0 additionally hosts the NoC control window (scratch registers and the
//  traffic counters of both networks) at xfer = CTRL, see docs/COUNTERS.md.
//  Compile with:  verilator --lint-only -Irtl --top-module sf_noc_system_example <files>
//  (Makefile target `lint`).
// =============================================================================
module sf_noc_system_example
  import silicaflux_pkg::*;
#(
  parameter int unsigned MESH_X = 2,
  parameter int unsigned MESH_Y = 2,
  localparam int unsigned NT    = MESH_X * MESH_Y
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,
  // per-tile initiator ports
  input  logic          [NT-1:0]       scalar_req_valid_i, output logic [NT-1:0] scalar_req_ready_o,
  input  sf_scalar_mem_req_t [NT-1:0]  scalar_req_i,
  output logic          [NT-1:0]       scalar_rsp_valid_o, input  logic [NT-1:0] scalar_rsp_ready_i,
  output sf_scalar_mem_rsp_t [NT-1:0]  scalar_rsp_o,
  input  logic          [NT-1:0]       vector_req_valid_i, output logic [NT-1:0] vector_req_ready_o,
  input  sf_vector_mem_req_t [NT-1:0]  vector_req_i,
  output logic          [NT-1:0]       vector_rsp_valid_o, input  logic [NT-1:0] vector_rsp_ready_i,
  output sf_vector_mem_rsp_t [NT-1:0]  vector_rsp_o,
  input  logic          [NT-1:0]       burst_req_valid_i,  output logic [NT-1:0] burst_req_ready_o,
  input  sf_burst_desc_t [NT-1:0]      burst_req_i,
  input  logic          [NT-1:0]       burst_wdata_valid_i, output logic [NT-1:0] burst_wdata_ready_o,
  input  sf_burst_wbeat_t [NT-1:0]     burst_wdata_i,
  output logic          [NT-1:0]       burst_rdata_valid_o, input  logic [NT-1:0] burst_rdata_ready_i,
  output sf_burst_rbeat_t [NT-1:0]     burst_rdata_o,
  output logic          [NT-1:0]       burst_done_valid_o, input  logic [NT-1:0] burst_done_ready_i,
  output sf_burst_done_t [NT-1:0]      burst_done_o,
  output logic                         noc_idle_o,
  output logic          [NT-1:0]       init_done_o
);
  logic        [NT-1:0] req_in_v, req_in_r, req_out_v, req_out_r, rsp_in_v, rsp_in_r, rsp_out_v, rsp_out_r;
  noc_packet_t [NT-1:0] req_in_p, req_out_p, rsp_in_p, rsp_out_p;
  logic [15:0] c_addr;  logic c_plane, c_clear, c_freeze, c_ovf;  logic [31:0] c_data;
  logic        [NT-1:0] err_drop;

  sf_noc_fabric #(.MESH_X(MESH_X), .MESH_Y(MESH_Y), .BUF_DEPTH(4), .SEPARATE_RSP(1'b1), .EXPLICIT_FRAMING(1'b1),
                  .CNT_EN(1'b1), .LAT_IDX_W(8)) u_fabric (
    .clk_i, .rst_ni,
    .req_in_valid_i(req_in_v), .req_in_pkt_i(req_in_p), .req_in_ready_o(req_in_r),
    .req_out_valid_o(req_out_v), .req_out_pkt_o(req_out_p), .req_out_ready_i(req_out_r),
    .rsp_in_valid_i(rsp_in_v), .rsp_in_pkt_i(rsp_in_p), .rsp_in_ready_o(rsp_in_r),
    .rsp_out_valid_o(rsp_out_v), .rsp_out_pkt_o(rsp_out_p), .rsp_out_ready_i(rsp_out_r),
    .noc_idle_o, .err_drop_o(err_drop),
    .ctrl_clear_i(c_clear), .ctrl_freeze_i(c_freeze), .rd_plane_i(c_plane), .rd_addr_i(c_addr),
    .rd_data_o(c_data), .ovf_o(c_ovf)
  );

  for (genvar t = 0; t < NT; t++) begin : g_node
    logic [15:0] a;  logic pl, cl, fr;
    sf_noc_mem_node #(.TILE(t), .NUM_TILES(NT), .MESH_X(MESH_X), .HAS_CNT(t == 0)) u_node (
      .clk_i, .rst_ni,
      .scalar_req_valid_i(scalar_req_valid_i[t]), .scalar_req_ready_o(scalar_req_ready_o[t]), .scalar_req_i(scalar_req_i[t]),
      .scalar_rsp_valid_o(scalar_rsp_valid_o[t]), .scalar_rsp_ready_i(scalar_rsp_ready_i[t]), .scalar_rsp_o(scalar_rsp_o[t]),
      .vector_req_valid_i(vector_req_valid_i[t]), .vector_req_ready_o(vector_req_ready_o[t]), .vector_req_i(vector_req_i[t]),
      .vector_rsp_valid_o(vector_rsp_valid_o[t]), .vector_rsp_ready_i(vector_rsp_ready_i[t]), .vector_rsp_o(vector_rsp_o[t]),
      .burst_req_valid_i(burst_req_valid_i[t]), .burst_req_ready_o(burst_req_ready_o[t]), .burst_req_i(burst_req_i[t]),
      .burst_wdata_valid_i(burst_wdata_valid_i[t]), .burst_wdata_ready_o(burst_wdata_ready_o[t]), .burst_wdata_i(burst_wdata_i[t]),
      .burst_rdata_valid_o(burst_rdata_valid_o[t]), .burst_rdata_ready_i(burst_rdata_ready_i[t]), .burst_rdata_o(burst_rdata_o[t]),
      .burst_done_valid_o(burst_done_valid_o[t]), .burst_done_ready_i(burst_done_ready_i[t]), .burst_done_o(burst_done_o[t]),
      .req_in_valid_o(req_in_v[t]), .req_in_ready_i(req_in_r[t]), .req_in_pkt_o(req_in_p[t]),
      .req_out_valid_i(req_out_v[t]), .req_out_ready_o(req_out_r[t]), .req_out_pkt_i(req_out_p[t]),
      .rsp_in_valid_o(rsp_in_v[t]), .rsp_in_ready_i(rsp_in_r[t]), .rsp_in_pkt_o(rsp_in_p[t]),
      .rsp_out_valid_i(rsp_out_v[t]), .rsp_out_ready_o(rsp_out_r[t]), .rsp_out_pkt_i(rsp_out_p[t]),
      .cnt_rd_addr_o(a), .cnt_rd_plane_o(pl), .cnt_rd_data_i(c_data), .cnt_clear_o(cl), .cnt_freeze_o(fr),
      .init_done_o(init_done_o[t]), .err_decode_o()
    );
    if (t == 0) begin : g_cnt
      assign c_addr = a; assign c_plane = pl; assign c_clear = cl; assign c_freeze = fr;
    end
  end
endmodule : sf_noc_system_example
