# Architecture

## 1. System view
```
        tile 0                tile 1                          each tile: initiator ports (memory_controller slave types)
   +-------------+       +-------------+                      -> sf_noc_mem_master_ni  -- request network  -->
   | LSU/VLSU/DMA|       | LSU/VLSU/DMA|                      <- (credit-reserved sink) <- response network <--
   | scratchpad  |       | scratchpad  |                      sf_noc_mem_target_ni  <- request network  <--  real
   +------+------+       +------+------+                                              -> response network -->  memory_controller
          | NI x2               | NI x2
     R(0,1)=====R(1,1)    request net  : 2x2 mesh, XY, registered links, wormhole   (RD_REQ, WR_REQ, MSG)
        ||        ||      response net : second, physically separate 2x2 mesh       (RD_RSP, WR_RSP)
     R(0,0)=====R(1,0)    tile index t = y*2 + x; North = +Y, East = +X
```
`sf_noc_fabric` = request mesh + response mesh + one `sf_noc_traffic_counters` per mesh. `sf_noc_mem_node` = master NI +
target NI + `memory_controller` for one tile; `examples/sf_noc_system_example.sv` wires four of them.

## 2. Router (`noc_router`, 5 ports: L N E S W) - the existing design, kept
* **Pipeline, 2 cycles/hop.** S1 *buffer write + route compute* (the flit is stored with its one-hot XY output mask, so routing is off
  the allocation path). S2 *switch allocation + traversal*: per-output round-robin over buffer heads, one-hot AND-OR crossbar,
  capture in the egress register, which drives the link. **A hop = exactly one router: zero-load latency `2 x (hops+1)`** (measured on all
  16 pairs, formally proved for the 2x2 mesh).
* **Flow control**: `ready` = registered `~full` of the downstream buffer; a transfer happens iff `valid && ready` in the same cycle.
  Link valid/payload are egress-flop outputs. Therefore no combinational path crosses a router (gate-level check) and back-pressure moves
  one hop per cycle. `BUF_DEPTH >= 2` sustains one flit/cycle/link.
* **Routing**: deterministic XY: resolve X (E or W), then Y (N or S), then eject. The turn table forbids Y->X and U-turns at elaboration, so
  the channel-dependency graph is acyclic; routing is minimal (every hop reduces Manhattan distance).
* **Arbitration**: per-output round-robin with a rotating priority mask; in wormhole mode the grant is locked head-to-tail.
  Measured: a requester waits at most `NP-1 = 4` accepting cycles (formal proof, `reports/formal.md`).
* **Wormhole**: counted framing (`FLITS_PER_PKT` fixed) as originally, or explicit framing (V2-3).

## 3. What v2 adds (each item is a scripted, anchor-checked patch; `docs/noc_interconnect_v2.diff`)
| id | change | why (evidence in `docs/AUDIT.md`) |
|---|---|---|
| V2-1 | hardware ingress validation on the local port: bad dst / `valid=0` / reserved class / spoofed src -> packet dropped whole, `err_drop`, `err_drop_head`, `err_cause[2:0]` | D1-D2: a bad header misdelivered or wedged the original |
| V2-2 / 2b | `QOS_STARVE_LIMIT` K: after K consecutive high-class grants a waiting low-class request is served; **separate round-robin pointer per class** | D3: strict priority starved the low class; first version's shared pointer was caught by formal |
| V2-3 | `EXPLICIT_FRAMING`: head/tail from `sop/eop`, any packet length | D4: `tile_interface` emits variable-length packets |
| V2-4 | additive taps: per-port fire/head, request/grant matrix, buffer occupancy, output flit | D7: counters need them |
| V2-5 | conservation assertions count accepted (not dropped) flits | follows from V2-1 |

Nothing in the pipeline or flow-control equations changed: with QoS off, framing counted and legal traffic, v2 and the original are
cycle-identical (`reports/orig_vs_v2_cycles.md` compares them test by test).

Parameters of `noc_interconnect`: `MESH_X, MESH_Y` (1..4 per ID width), `BUF_DEPTH`, `FLITS_PER_PKT`, `EXPLICIT_FRAMING`, `QOS_ARB_EN`,
`QOS_STARVE_LIMIT`, `CHECK_CLASS`, `CHECK_SRC`, `PROGRESS_WDOG_CYCLES` (simulation watchdog), `pkt_t` (flit type; default `noc_packet_t`).

## 4. Network interfaces and memory integration (`docs/PACKET_SPEC.md` section 5)
* `sf_noc_mem_master_ni` exposes the **memory_controller slave ports** (scalar / vector / burst) with the real `sf_*` types.
  Address -> tile: `(addr - MAP_BASE) >> MAP_SHIFT`; outside every aperture -> local `SF_MEM_EXC_RANGE`, nothing enters the fabric.
  One target per port at a time so responses stay in order per port (the controller's contract). Tags travel as `txn_id` and come back.
  **Responses are always accepted**: buffer space is reserved at issue (credits); this is what makes the response network drain
  unconditionally (`docs/DEADLOCK.md`).
* `sf_noc_mem_target_ni` drives the real `memory_controller`: scalar/vector ports, and the **DMA/burst port** (descriptor flit +
  beat flits; a rejected descriptor never accepts data, so the NI drains the beats and returns the controller's status); CTRL accesses
  to 16 scratch registers and a read-only window onto the traffic counters; partial-lane vector writes -> MISALIGN; MSG and
  response-class packets on the request network are dropped and counted.
* Completion semantics: every request, a store included, gets exactly one completion carrying the controller's status; a store completes
  when the target controller has committed it.

## 5. Mesh versus small crossbar (the "do not over-engineer a 4-node mesh" check)
`sf_noc_xbar` is a 4x4 crossbar built to the same conventions (same packet, FIFOs, round-robin, egress register, validation) so the
comparison is like-for-like. Everything below is measured: cost from technology-independent synthesis (`reports/synth.md`, no PDK),
behaviour from RTL simulation (`reports/PERFORMANCE.md`).

| 4 tiles, buffer depth 4 | mesh 2x2 | crossbar 4x4 | mesh / crossbar |
|---|---|---|---|
| flops | 12,650 | 4,192 | 3.0x |
| NAND2-equivalents (total) | 95,218 | 35,580 | 2.7x |
| logic levels, longest path (`ltp`) | 33 | 40 | 0.8x |
| zero-load latency | 2 / 4 / 6 cycles (0 / 1 / 2 hops) | 2 cycles (any pair) | |
| mean network latency, uniform random, light load | 4.7 cycles | 2.0 cycles | |
| saturation throughput, uniform random (flits/cycle/tile) | **0.870** | 0.689 | 1.26x |
| saturation throughput, uniform incl. self | 0.832 | **0.655** = analytic input-queued HOL limit | |
| all-to-one fairness (Jain index) | 0.90 (shares 0.33/0.33/0.17/0.17) | **1.00** | |
| permutations / neighbour / hotspot / all-to-one | at the channel-load bound | at the channel-load bound | equal |

* **Why the mesh wins on uniform throughput**: it has 3x the buffering, and the crossbar's single FIFO per input is head-of-line limited at
  0.655-0.689 *whatever the depth* (0.690 at depth 2, 0.689 at depth 16, `reports/PERFORMANCE.md` section 6), whereas the mesh's saturation rises
  with depth (0.794 at depth 2 -> 0.929 at depth 16). It is a buffering effect, not a topology effect; a crossbar with virtual output queues would
  remove it (not built).
* **Scale**: the mesh's per-tile saturation throughput falls with size (0.870 / 0.760 / 0.633 at 4 / 9 / 16 tiles) and its latency grows with the
  diameter (4.7 -> 6.0 -> 7.4 cycles), while the crossbar keeps one-router latency (2.0) but its logic grows ~N^2 (14,620 -> 57,412 NAND2-eq at 9 ports) and its longest path
  deepens (40 -> 72 levels). At 16 tiles the mesh's throughput edge is almost gone (0.633 vs 0.603) while the mesh router's path stays at 33 levels (2x2 and 3x3) - that and bounded wire
  length are the mesh's real arguments.
* **Fairness is the mesh's weak spot**: round-robin is locally fair, not globally fair. Under all-to-one the share of a source halves at every merge (4x4 mesh: Jain 0.36,
  worst source 0.5 % of the hot tile's bandwidth, p99 latency 2,943 cycles) while the crossbar stays at 1.00. A mesh used for hot-spot traffic needs weighted
  or age-based arbitration; the QoS guard bounds a *class*, not a *position*.
* The dual-network fabric is 191,468 NAND2-eq = 2.01x one mesh.
* **Conclusion**: for four endpoints the crossbar is cheaper (2.7x), lower latency (2 vs up to 6 cycles) and fairer; the mesh offers higher uniform-random
  throughput at equal per-input buffer depth only because it spends 3x the storage. The mesh is justified by scale and physical locality, not by anything visible at
  four tiles. This agrees with the sibling `sfn_*` DataFabric-NoC study in the repository. The mesh is kept because it is the configuration the brief and the existing RTL target,
  and because it scales (verified on 3x3 and 4x4).
* Buffer depth is the main cost lever: mesh 2x2 total NAND2-eq is 54,659 / 95,218 / 178,860 at depth 2 / 4 / 8; explicit framing adds 0.6 %, the QoS guard (K=7) 0.7 %
  area and lengthens the longest path (33 -> 48 levels).
