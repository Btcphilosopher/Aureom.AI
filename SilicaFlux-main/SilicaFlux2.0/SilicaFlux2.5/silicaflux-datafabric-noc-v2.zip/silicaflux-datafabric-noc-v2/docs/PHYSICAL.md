# Physical-design integration

**Status in one line: synthesizable, placement-friendly hierarchy and the structural facts a floorplanner needs are
delivered; static timing analysis was NOT run and no timing closure is claimed.**

## Why there is no STA result
Real STA needs a liberty library (and, for post-place, LEF). The repository ships TimingFlow/TimingLab *configurations* and
reports but no PDK collateral, GitHub (where ORFS/open_pdks live) is not reachable from the build sandbox, and the PyPI
packages that carry SKY130 contain SPICE models and schematics only, no `.lib` timing. OpenSTA/OpenROAD are not installed, and an
unverified 113 MB native wheel found on PyPI was deliberately not run (no library to give it anyway). Therefore:

* no ns, no MHz, no um^2 appear anywhere in this project's deliverables;
* what *was* done is real: technology-independent synthesis, gate-level structural analysis, and a formal/simulated proof of the
  properties timing depends on (see below);
* `constraints/noc.sdc` and `constraints/timingflow_noc_v2.yaml` are ready for someone with the PDK and refuse to run without a
  clock period (`NOC_CLK_PERIOD_NS`, `period_ns: null`).

## Structure that matters for timing (all measured / proved here)
| item | fact | evidence |
|---|---|---|
| pipeline boundaries | **every router-to-router signal is a flop output**: egress register (valid, payload) and registered `~full` (ready). A link is flop -> wire -> flop | `reports/comb_paths.md`: 15/15 link-facing outputs of the interior router depend combinationally on no input |
| longest combinational path | inside one router: request vector -> round-robin pick -> grant -> input-buffer pop/count and the one-hot crossbar into the egress register | 30-33 NAND2/NOT levels for the interior router (`reports/synth.md`, `ltp -noff`) - a structural proxy, not ns |
| no loops across routers | no combinational path crosses a router, so a mesh built from this router has no combinational cycle | gate-level cone analysis; `yosys check -assert`: 0 problems on the flattened 2x2 mesh; each output cone stops at flops |
| clock domains | **one** (`clk_i`) inside the fabric. Reset: asynchronous assert, expects a synchronous deassert from the integrator. `tile_interface` (not integrated, see limitations) owns the tile<->NoC CDC | RTL |
| wide links | 207 payload bits + 1 reverse ready per directed link; 8 directed links per 2x2 network, 2 networks -> 3,312 payload wires + 16 ready | RTL / `constraints/floorplan_manifest.yaml` |
| physically long routes | the mesh links. Each is registered at the source, so a link has a full cycle for its wire; the diagonal pairs (0<->3, 1<->2) have **no** direct wire (two XY hops) | RTL |
| high-fanout controls | buffer read-pointer bit 0 (~420 pins/port: selects the 207-bit read mux), grant `sa_gnt[o][i]` (207: crossbar select), `rst_ni` | `reports/fanout.md` |
| instances | per network: 4 `noc_router` (3 ports each in 2x2: local + 2 neighbours); per tile: master NI, target NI, memory_controller (+ counters if enabled) | `constraints/floorplan_manifest.yaml` |
| area | flop count and NAND2-equivalents only; buffers dominate | `reports/synth.md` |

## FloorplanLab and TimingFlow: what "integrated" honestly means
* **TimingFlow**: its own documentation states FloorplanLab is only an Angular UI component with no database; TimingFlow defines an
  *import interface* (`floorplan.json`, `.odb` stages) and an in-flow OpenROAD implementation of it. `constraints/timingflow_noc_v2.yaml`
  follows the schema of `configs/designs/*.yaml`, has `status: RTL_ONLY`, and `period_ns: null`. It has **not** been run.
* **FloorplanLab**: `constraints/floorplan_manifest.yaml` lists the instances, links, widths, fanouts and placement hints in the
  form such a tool consumes. It contains no coordinates; none were invented.

## What the integrator must still do
1. Choose the clock period; run synthesis + STA with the PDK (`timingflow run`, or the SDC directly).
2. Synchronise reset deassertion.
3. Buffer/duplicate the high-fanout nets listed above (a placement-aware tool will; the RTL does not hand-instantiate buffers).
4. Decide SRAM vs register buffers for the input FIFOs: 12 buffers x 4 entries x 210 bits per network are written as
   inferred arrays; at larger depths a register-file macro is the likelier choice (`sf_noc_fifo`/the router array is the swap point).
5. Check the 207-bit links against the available routing tracks; narrowing `SF_NOC_DATA_W` (a package constant) halves them.
