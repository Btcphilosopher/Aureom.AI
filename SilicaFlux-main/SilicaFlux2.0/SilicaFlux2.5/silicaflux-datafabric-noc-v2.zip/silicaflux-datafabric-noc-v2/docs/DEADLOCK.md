# Request/response deadlock

## 1. The problem XY routing does not solve
A mesh with dimension-order routing has an **acyclic channel-dependency graph** (no Y->X turns, no U-turns - enforced by the turn table at
elaboration and proved on every output port by the formal routing property). That proves the *network* cannot deadlock **provided every
ejected flit is eventually consumed.** A memory protocol breaks that proviso:

```
 a request can only be consumed by the target NI if the target can later emit its RESPONSE
 a response needs injection buffer -> link buffers -> ... -> the requester's ejection port
 on one shared network those buffers are also holding REQUESTS waiting for full target NIs
```
Wait-for cycle: request waits for target -> target waits to inject its response -> response waits for a buffer held by a request ->
that request waits for another full target -> ... The cycle is formed by the *message* dependency request -> response, not by any channel
cycle, so no routing argument about the mesh can rule it out.

## 2. Options evaluated
| option | verdict |
|---|---|
| **A. Physically separate request and response networks** | **implemented** (`sf_noc_fabric`, `SEPARATE_RSP = 1`). No buffer, link, arbiter or ejection port is shared; a stalled request cannot occupy anything a response needs. Cost: a second set of routers (about 2x router area; `reports/synth.md`, `fabric_dual_nocnt`) |
| B. Virtual networks (two VC buffer sets per port, shared links and crossbar) | **evaluated, not implemented.** Same buffer storage as A, shared links/crossbar logic, but needs VC allocation, per-VC ready on every link and a larger allocator in the router that the formal and simulation work above targets. A is simpler to verify and has independent timing paths; B is the area optimisation to make if routers dominate and wires are scarce. Any area figure for B would be an estimate and none is claimed |
| C. Isolated buffers on a shared network | **partially present on the shared configuration and shown insufficient**: the injection merge gives each class its own source queue and alternates between them, yet the shared network still deadlocks (section 3), because the buffers *inside* the mesh and the ejection port are shared |

## 3. Evidence (measured, `reports/regression_sys.md`)
`tb/tb_noc_sys.sv`, identical NI RTL, identical workload and seed; only `SEPARATE_RSP` differs.

**(a) Stress study - sustained fixed-target traffic** (rotate, diagonal and pair patterns x seeds 1-3 = 9 runs per network): router input
buffers 2, NI request/response/context queues 2, 32 outstanding scalar + 32 vector requests per master, plus 40 DMA bursts per tile
(4,960 transactions per run).

| network | outcome |
|---|---|
| **shared** | **deadlocks in 9 of 9 runs**: no transaction completes for 8,000 cycles, 52-67 transactions outstanding, the network never drains |
| **separate** | **completes in 9 of 9 runs**: all 4,960 transactions in 1,793-1,907 cycles |

**(b) Functional suite on a shared network (a study, not a supported configuration)**
* default sizes (4-deep): single-flit memory traffic (scalar, vector, error completions, stalled consumer) still works; **every test that
  involves DMA bursts can deadlock - even `dma_burst_rw_strobes` with only four transactions in flight** (multi-flit packets hold wormhole
  locks along their path, which makes the shared ejection port and shared buffers a trap much sooner).
* with 64-deep buffers everywhere the same wrapper passes every burst and memory test: the failures are **capacity-driven protocol
  deadlock, not a defect of the shared-network wrapper** (this was the control experiment). The one remaining failure is the
  `control_regs_and_corner_packets` test that deliberately injects a **response-class packet on the request path**: on one network the
  class-based ejection demux hands it to the master NI as a (spoofed) response; on separate networks it arrives at the target NI and is
  dropped and counted. Separation therefore also gives containment of misclassified traffic.
* with random targets the master NI's one-target-at-a-time rule keeps so little outstanding that nine shared-network runs over three
  parameter sets completed. An early attempt to *claim* a deadlock there was refused by the testbench's own check; what fills the buffers is
  sustained traffic to fixed targets, or bursts.

**(c) State at the stall** (`reports/deadlock_diag.txt`, rotate pattern, seed 1; capacities 2):
```
tile 0  target NI reqQ 2/2  burst-response queue 2/2  router in-buffers L/N/E 2/2/2    master NI: 6+5 outstanding
tile 1  target NI reqQ 2/2  burst-response queue 2/2  router in-buffers L/N/W 2/2/2
tile 2  target NI reqQ 0/2  response queues scalar/vector 2/2 (full)  router L 2/2 (full)
tile 3  target NI reqQ 0/2  response queues scalar/vector 2/2 (full)  router L 2/2 (full)
```
Tiles 2 and 3 finished their work but cannot inject their responses because their router's local input buffer is full; tiles 0 and 1 hold full request
queues and a burst-read response they cannot inject; every router buffer on the way is full. Every flit waits on a buffer that waits on an ejection port that
waits on a target that waits to inject: the cycle of section 1.

## 4. Why the separated configuration cannot deadlock (argument, not a machine proof)
1. Each network is a mesh with an acyclic channel-dependency graph (XY), so it is deadlock-free if its ejected flits are eventually consumed.
2. **Response network: consumption is guaranteed by construction.** `sf_noc_mem_master_ni` reserves response-buffer space *at issue time*
   (scalar/vector: one credit per outstanding request, burst read: `len_m1+1 <= BRD_DEPTH` beats, one burst at a time) and keeps
   `rsp_ready_o = 1`. A response therefore never waits for the tile, whatever the tile does (tested: `response_consumer_stall`).
   Simulation assertions `a_sf_space`, `a_vf_space`, `a_bf_space` fire if the accounting is ever wrong.
3. **Request network:** an ejected request is consumed by the target NI when its request queue has room. The queue drains when the
   memory_controller accepts requests, which needs only the controller (always progresses) and room in the response queues, which drain
   into the response network - which by (2) always drains. So the request network's consumption depends only on a network that is
   unconditionally live; there is no cycle back to the request network.
4. Dependencies therefore form a chain request network -> target NI -> response network -> master NI sink, with no edge back.

Assumptions: the controller completes every request it accepts; every target NI sits behind this chain (no endpoint issues a *new request* as
a precondition of consuming a response - a tile that did would reintroduce a dependency); the injector completes every wormhole packet it starts.

## 5. Other protocol-level dependencies found
* **Bursts**: a long burst holds wormhole locks along its path for its duration. Writes: the target NI drains beats (it also drains the beats of a
  rejected burst, because the controller never accepts data for a rejected descriptor - otherwise the lock would be held forever). Reads: beats go
  to the response network, whose sink is guaranteed.
* **Per-port ordering**: one target per memory port at a time keeps responses in order without a reorder buffer; it costs throughput for scattered access.
* **Ejection head-of-line blocking** on a shared network is the coupling through which a stalled request delays responses behind it; separation removes it.
