# Repository audit: SilicaFlux NoC

Scope: `SilicaFlux2.0/SilicaFlux2.5/` of the Aureom.AI repository, with every claim below backed by a command that was
actually run in this session (commands are in `docs/REPRODUCE.md`). README text was not accepted as evidence of anything.
The original sources are kept byte-identical in `original/` (`SHA256SUMS`); everything this project changes is a scripted,
anchor-checked patch of them (`scripts/make_v2_rtl.py`, delta in `docs/noc_interconnect_v2.diff`).

## 1. What is in the tree

| item | where | status |
|---|---|---|
| `noc_router`, `noc_interconnect` (2x2 XY wormhole mesh, 1069 lines) | `noc_interconnect.sf` | the subject; elaborates only after a missing type is supplied (D0) |
| `silicaflux_pkg` | `silicaflux_pkg (1).sf`, header "Memory subsystem transaction types" | **defines no `noc_packet_t`**, no `sf_tile_pkt_t`, no `sf_noc_flit_t` |
| `memory_controller` | `memory_controller.sf` | compiles clean (Verilator `-Wall`, only filename warnings) with the package above; real scalar/vector/burst ports |
| `register_bank`, `vector_engine` | `*.sf` | lint without errors against the memory package |
| `compute_tile`, `tile_interface`, `scheduler`, `silicaflux_top` | `*.sf` | **do not compile from this tree**: they use package types (`sf_tile_pkt_t`, `sf_noc_flit_t`, `sf_exec_pkt_t`, ...) from a `silicaflux_pkg` section that is not present |
| NoC testbench | `tb_noc_interconnect.sf` (2,952 lines) | **cannot run against `noc_interconnect.sf`** (D10) |
| flow script | `run_sim.sh` (Icarus) | cannot build the NoC (Icarus 12 rejects the router's concurrent assertions and assignment patterns, even with `-DSYNTHESIS`) |
| `sf_noc_traffic_counters.sv` ("supplied starter") | **nowhere** | searched every `.sf/.sv` and every archive: it does not exist. `rtl/sf_noc_traffic_counters.sv` is written from scratch |

### `.sf` is SystemVerilog
No transformation is needed: Verilator 5.020 accepts the files with `+systemverilogext+sf`, or after a pure `.sf -> .sv`
rename. Verilator is the supported simulator for this project; Icarus 12 is not (no concurrent assertions, no
assignment patterns, no `parameter type`).

### Four more NoC lineages in the repository (not the same design)
| lineage | what it is | relevance |
|---|---|---|
| April `silicaflux.zip` `rtl/noc_router.sv` | 5-port router, 43-bit `noc_flit_t`, one flit of buffering | the TimingLab "noc_router" synthesis/PnR reports describe **this**, not `noc_interconnect.sf`; they are not evidence about the subject |
| `silicaflux-datafabric-noc.zip` (`sfn_*`) | transaction-level SFB3 fabric: bus / crossbar / mesh, formal + synth + benchmarks | mature, different protocol (master/target endpoints). Its crossbar-vs-mesh conclusion (crossbar at this endpoint count) matches ours; reused as prior art only |
| `silicaflux-noc-spine-p34.zip` | integration of the above into DataFabric | not examined further |
| `tile_interface.sf` | tile<->NoC boundary: framing, CRC, parity, CDC, `vc_id` | the real *producer* of NoC traffic; speaks `sf_noc_flit_t`, not `noc_packet_t` |

### Five incompatible NoC packet formats
| format | used by | fields |
|---|---|---|
| `noc_packet_t` | `noc_interconnect.sf` | `dst_id, src_id, valid, qos` read by the router; `txn_id, spec_tag, class, data` "carried" - **type defined nowhere** |
| `sf_noc_flit_t` | `tile_interface.sf` | `flit_type, vc_id, dst_id, data` + 1 parity bit; HEAD/BODY/TAIL, class-dependent length; request on VC0, response on VC1 |
| `noc_flit_t` (tb) | `tb_noc_interconnect.sf` | `chk, payload[64], id[16], src, dst`; single flit |
| `noc_flit_t` (April) | April rtl | 43 bits: type, dst/src row/col, 32-bit data |
| SFB3 packets | `sfn_*` | transaction packets with opcode/addr/strobes |

`rtl/silicaflux_noc_section.svh` defines `noc_packet_t` (contract v1, `docs/PACKET_SPEC.md`) so that every field the
router reads exists, memory tags/status/widths come from the real memory types, and `tile_interface` traffic can be
adapted (explicit head/tail framing, `qos` from `vc_id`).

## 2. Baseline: does the existing router work?

The **unmodified** router (copy of the `.sf`, renamed) with the new packet type, against `tb/tb_noc.sv`
(independent scoreboard; bit-exact compare, routing, duplication, phantom, per-pair order, loss, stability) with the
router's own assertions armed:

* 15 of 15 tests that exercise legal traffic pass: reset state, **all 16 (src,dst) pairs at the exact zero-load latency
  `2 x (hops+1)`**, local delivery, one hop, diagonal, simultaneous permutations, uniform all-pairs, bidirectional,
  all-to-one hotspot, random and periodic back-pressure, queue saturation, reset during traffic, repeated resets,
  QoS starvation (off). Also passes with `FLITS_PER_PKT = 2, 4` and on a 3x3 mesh.
* Verilator `-Wall`: 5 benign warnings (4 x UNUSEDSIGNAL on absent-port bits, 1 x SYNCASYNCNET on `rst_ni`).

So the router core is sound. The defects are at its edges:

| # | defect | evidence (run in this session) | consequence | fix in this project |
|---|---|---|---|---|
| D0 | `noc_packet_t` undefined | Verilator: router does not elaborate against the shipped package | nothing compiles | `rtl/silicaflux_noc_section.svh`, one `include` line added to the package; memory section byte-identical |
| D1 | destination validated only by a **simulation** assertion | with assertions compiled out (as in synthesis): bad `dst_id` bits above the coordinate field are **silently delivered to another tile** (phantom flits at tiles 0-3); in a 3x3 mesh an out-of-range coordinate **wedges the input port permanently - 43 valid packets stranded** | misrouting / total loss of an input port from one corrupt header | V2-1: ingress validation in hardware, packet dropped whole, `err_drop`/`err_cause` taps (test: 395 of 395 bad packets rejected, 1205 of 1205 good delivered) |
| D2 | invalid class, `valid=0`, spoofed `src_id`: sim-only assertions | with assertions off, reserved-class and spoofed-source packets are delivered | protocol/identity violations pass | V2-1 (same mechanism) |
| D3 | `QOS_ARB_EN=1` is strict priority | high class src0 delivered 1992 packets while the low class got **3 packets in 2000 cycles** (0.15 %); the starvation bound in the file's header is explicitly disabled for QoS | "QoS must not silently starve" violated | V2-2/V2-2b: `QOS_STARVE_LIMIT`, per-class round-robin pointers; formal bound `(NP-1)(K+1)+K` |
| D4 | wormhole packet length is a fixed `FLITS_PER_PKT` | `tile_interface` emits HEAD/BODY/TAIL with class-dependent length | cannot carry tile packets | V2-3: `EXPLICIT_FRAMING` (head/tail from `sop/eop`); legacy counted mode unchanged |
| D5 | no virtual channels; request/response dependency not addressed | `tile_interface` assigns `VC_MEM_RSP=1` but the router has no VC; XY is deadlock-free only as a channel graph | memory-protocol deadlock | request/response on **separate networks** (`sf_noc_fabric`); deadlock reproduced on a shared network (`docs/DEADLOCK.md`) |
| D6 | tile **ID** != tile **index** unless `MESH_X` is a power of two | `ID = {y, x}` with `X_W = clog2(MESH_X)`; index `= y*MESH_X + x` | wrong tile if a producer assumes `ID == index` on e.g. a 3-wide mesh | documented; `sf_noc_id()` / `sf_noc_tile_index()`; tested on 3x3, 3x2, 2x3, 4x2 |
| D7 | telemetry too coarse for performance work | only `perf_link_stall` / `perf_hol_block` | cannot count bytes, occupancy, arbitration stalls | V2-4 additive taps + `sf_noc_traffic_counters` |
| D8 | TimingLab NoC reports describe a different router | see lineage table | no timing evidence exists for the subject | `docs/PHYSICAL.md`: structural proxies only, STA not run |
| D10 | existing testbench targets a different DUT | with its own `SF_TB_NO_COVERGROUPS`: `PINNOTFOUND inj_valid_i, inj_ready_o, inj_flit_i, ej_valid_o, ...`; it expects `hops+1` latency, the DUT gives `2(hops+1)` | no usable NoC testbench | `tb/tb_noc.sv`, `tb/tb_noc_sys.sv` |

D9 is not a defect of the original: it is a defect **introduced and fixed during this work** (the first version of the QoS
guard shared one round-robin pointer between classes, which formal verification showed can starve a low-class requester);
see `docs/VERIFICATION.md` section 5.

## 3. Things the original does well (kept)
Registered outputs and registered `ready` (no combinational path crosses a router - now checked on the gate-level
netlist, `reports/comb_paths.md`); one-hot AND-OR crossbar; round-robin per output with wormhole lock; registered
full/empty; correct reset; sound XY turn table. The v2 patch does not change the pipeline: on every test both routers
pass, cycle counts are identical.
