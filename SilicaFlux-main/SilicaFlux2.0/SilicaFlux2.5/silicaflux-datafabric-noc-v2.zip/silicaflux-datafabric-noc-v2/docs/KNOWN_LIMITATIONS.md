# Known limitations (nothing here is hidden elsewhere in the docs)

**Timing and physical**
1. **No static timing analysis, no timing numbers, no area in um^2.** No liberty library exists in the repository or the sandbox
   (details in `docs/PHYSICAL.md`). Only technology-independent synthesis (flops, NAND2-equivalents, logic levels) and a gate-level
   structural analysis were run. FloorplanLab/TimingFlow: configuration and manifests only, not run.
2. Reset deassertion must be synchronised by the integrator; the fabric has no synchroniser.

**Integration**
3. **`tile_interface` is not connected.** Its package types (`sf_tile_pkt_t`, `sf_noc_flit_t`, ...) are not in the tree, so a flit
   adapter could only have been written against stand-ins. The packet contract has what it needs (explicit framing, `qos`, `src_id`), but
   the adapter does not exist. Likewise `compute_tile`, `scheduler` and `silicaflux_top` do not compile from this tree and were not integrated.
4. **Tensor operand buffers**: no such RTL exists in the 2.5 tree; tensor traffic is expressed as VECTOR/BURST transfers to a scratchpad,
   not attached to a dedicated operand buffer.
5. `sf_noc_traffic_counters.sv` ("supplied starter") does not exist in the repository; the block is new work.
6. Memory side: one outstanding burst per master NI; one burst context per target NI (other requests wait behind a burst, the response
   network keeps draining); `burst_kill_i`/`flush_i` are tied low; per memory port only one target at a time (in-order responses),
   which limits throughput of scattered access; no posted writes on the memory ports (a store is acknowledged).
7. Control window: 16 scratch registers + counters; no interrupt, no atomic operations, no coherence (the controller's write-notify hook is not used).

**Network**
8. Mesh size is bounded by `SF_NOC_ID_W = 4` (4x4, or 16x1/1x16). Larger meshes need a wider ID (contract change).
9. Two QoS classes; strict-priority behaviour remains available (`QOS_STARVE_LIMIT = 0`) and starves by design. The guard's wait bound
   `(NP-1)(K+1)+K` is formally proved only for K = 1.
10. Ingress validation exists at the local port only; neighbour ports trust the upstream router (they cannot receive a flit that did not pass it).
11. A truncated wormhole packet (head without tail) wedges the output it holds until reset: the injector must complete packets.
    `PROGRESS_WDOG_CYCLES` detects this in simulation only.
12. **The traffic-counter block is large and slow**: 2.5x the mesh area with a 229-level combinational path (`docs/COUNTERS.md`); instrumentation only, `CNT_EN = 0` for production.
12b. **Virtual networks were evaluated, not implemented.** Request/response separation is by two physical networks (about 2x router area).
13. Deterministic XY only; no adaptive routing, no multicast (both are structural hooks in the original, untouched).
14. `sf_noc_xbar` is a comparison baseline: single-flit packets, no QoS, no wormhole.

**Deadlock**
15. The shared-network deadlock was **reproduced** under specific sustained-traffic patterns (rotate / diagonal / pair, tiny queues). For the
    separate-network configuration the guarantee is an *argument plus tests* (credit-reserved sink, acyclic networks), not a machine proof;
    the argument assumes every target NI eventually drains its request queue given that the response network drains.

**Verification**
16. Simulation is Verilator-only, seeds 1-3 per configuration, behavioural stimulus; **no line/functional coverage metric was collected.**
17. Formal results are mostly **bounded**: unbounded (k-induction) only for FIFO invariants, router reset state and output-hold; everything
    else is BMC at the depth stated in `reports/formal.md` (solver scaling limits depth to roughly 5-14 on the router). Formal runs use the
    unmodified RTL with a reduced-width flit, on one interior router (3x3 node (1,1)) and the 2x2 mesh. The NIs, the dual-network fabric
    and the counters have no formal properties (simulation only).
18. Performance numbers: synthetic traffic with random class/byte-enables (so payload-byte counters are exported but not used for
    bandwidth claims), single-flit packets, 2x2 / 3x3 / 4x4 at buffer depth 4 for scaling; cycles only.
19. The memory geometry in the system tests is small (4 KiB per tile) for speed; the default controller geometry compiles and lints but was not stress-tested.
