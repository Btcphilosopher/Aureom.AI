# Traffic counters (`rtl/sf_noc_traffic_counters.sv`)

**Provenance.** The brief refers to a supplied `sf_noc_traffic_counters.sv` starter. It does not exist anywhere in the repository
(every `.sf/.sv` file and every archive was searched), so this block is original work.

One instance per network (`sf_noc_fabric` instantiates one for the request network and one for the response network; `rd_plane_i`
selects which one the read port addresses). All counters are 32-bit, saturating; `ovf` is sticky. Flits and packets are counted
separately: `*_PKTS` count **head (sop) flits**, `*_FLITS` count every flit (they differ only for multi-flit packets).

## Interface
| signal | meaning |
|---|---|
| `ctrl_clear_i` | synchronous clear of all counters (latency timestamps and the in-flight count survive) |
| `ctrl_freeze_i` | counters hold; events are **not** recorded meanwhile (`FROZEN_CYCLES` counts them) |
| `rd_addr_i[15:0]` / `rd_data_o[31:0]` | combinational read port, unmapped address returns `0xDEADC0DE` |
| taps | the router/tile signals listed in the module header (`perf_*` outputs of `noc_interconnect`) |

Over the NoC: a CTRL read to the tile that hosts the counters (`HAS_CNT`, tile 0 in the examples) at byte address
`0x0004_0000 | (plane << 19) | (word_address << 2)` returns the counter; CTRL write to `0x100` bit0 = clear (write-1), bit1 = freeze.
Tested in `tb_noc_sys` (`control_regs_and_corner_packets`, `counters_match_traffic`).

## Address map (word addresses)
| group | address | contents |
|---|---|---|
| global | `0x0000` | `{16'h5F0C, block rev 8'h01, packet contract version 8'h01}` |
| | `0x0001` | `{MESH_X[7:0], MESH_Y[7:0], BUF_DEPTH[7:0], LAT_IDX_W[3:0], 3'b0, LAT_EN}` |
| | `0x0002/3` | `CYCLES` (window), `FROZEN_CYCLES` |
| | `0x0004` | `{31'b0, ovf}` |
| | `0x0005/6` | `LAT_COLLIDE`, `LAT_UNMATCHED` (must be 0 for latency to be trusted) |
| | `0x0007` | flit size in bytes (26) |
| router/port | `0x1000 \| metric<<8 \| router<<3 \| port` | port 0=L 1=N 2=E 3=S 4=W; metrics below |
| tile | `0x2000 \| metric<<8 \| tile` | per-tile metrics below |
| latency | `0x3000 \| kind<<8 \| field` | kind 0 network, 1 round trip; field 0 count, 1 sum, 2 min, 3 max, 8..15 log2 histogram |

| router/port metric | id | indexed by | definition |
|---|---|---|---|
| FLITS_IN / PKTS_IN | 0 / 1 | input port | flits / head flits accepted into the input buffer |
| FLITS_OUT / PKTS_OUT | 2 / 3 | output port | flits / head flits transferred on the output (**per-link flits**) |
| PAYLOAD_BYTES_OUT | 4 | output port | sum of `popcount(be)` over data-bearing flits (WR_REQ, RD_RSP, MSG) |
| RAW_BYTES_OUT | 5 | output port | flits x 26 B (**per-link bytes transferred**) |
| LINK_STALL | 6 | output port | cycles the output register held a flit the sink did not accept |
| ARB_BLOCKED | 7 | output port | cycles >= 1 requester and no grant (output blocked by back-pressure) |
| ARB_LOSE | 8 | output port | sum over cycles of (requesters - grants): arbitration losers (contention) |
| HOL_BLOCK | 9 | input port | cycles a valid buffer head was not served |
| OCC_SUM / OCC_MAX | 10 / 11 | input port | integral (divide by CYCLES for the mean) and maximum of input-buffer occupancy |

| tile metric | id | definition |
|---|---|---|
| INJ_FLITS / INJ_PKTS / INJ_STALL | 0 / 1 / 2 | handshakes at the injection port / head flits / cycles valid and not ready (source back-pressure) |
| EJ_FLITS / EJ_PKTS / EJ_STALL | 3 / 4 / 5 | ejections / head flits / cycles the tile refused a flit (**destination congestion at the sink**) |
| DROP_FLITS / DROP_PKTS | 6 / 7 | ingress-rejected flits / packets |
| DROP_DST / DROP_CLS / DROP_SRC | 8 / 9 / 10 | by cause (a packet can have several) |
| DST_INFLIGHT_CUR / MAX / SUM | 11 / 12 / 13 | flits in the network addressed to this tile; SUM is the integral (mean = SUM/CYCLES); **destination congestion in the fabric** |
| DST_CONG_CYCLES | 14 | cycles with >= `DST_CONG_THR` (4) flits in flight to the tile |

## Latency (where correlatable)
Network latency = injection accepted -> ejected, for the same `(src, txn_id[LAT_IDX_W-1:0])`; round trip = request injected ->
its response ejected at the requester. Exact when each source has at most `2^LAT_IDX_W` distinct txn_ids in flight; violations
are *counted* (`LAT_COLLIDE`, `LAT_UNMATCHED`), never silently absorbed. Head flits are timed. Tail latency and percentiles are
produced by the lab from per-packet logs, not by the hardware (the hardware keeps count/sum/min/max and 8 log2 bins).

## Verification of the counters themselves
`tb/tb_noc.sv::check_counters` compares, after every test, INJ/EJ/DROP flits and packets, latency count/sum/min/max, the in-flight
sum (must be 0 at drain), fabric-wide FLITS_IN == FLITS_OUT, and OCC_MAX <= BUF_DEPTH against the scoreboard's independent
bookkeeping. This caught a real bug in the first version (several tiles ejecting in one cycle: only the last latency sample was
recorded). `tb_noc_sys` checks flit conservation on both networks through the NoC-readable window.

## Cost (be aware)
From `reports/synth.md` (technology independent, no PDK): one `sf_noc_traffic_counters` for a 2x2 network is **14,173 flops and 235,958
NAND2-equivalents - about 2.5x the entire mesh it observes** (95,218) - with a 229-level combinational path (latency table lookup, histogram,
saturating adders). `sf_noc_fabric` with counters on both networks is 595,865 NAND2-eq against 191,468 without. This is measurement
instrumentation for the performance laboratory and bring-up, not something to ship as is: set `CNT_EN = 0` for production, or slim it
(fewer metrics, narrower counters, a pipelined/serial read-out, no per-router latency table). No such slimmed variant was built.
