# Verification

Four independent layers, each with a different failure mode. Results are in `reports/` (generated, not hand-written).

| layer | tool | what it can find | results |
|---|---|---|---|
| 1. NoC functional | `tb/tb_noc.sv`, Verilator, independent scoreboard | routing, integrity, ordering, loss/duplication, back-pressure, reset, error handling, fairness | `reports/regression.md` |
| 2. System | `tb/tb_noc_sys.sv`, Verilator, **real `memory_controller`** | protocol semantics, data integrity through the memory, DMA, control registers, deadlock | `reports/regression_sys.md` |
| 3. Formal | SymbiYosys + SLANG, smtbmc/z3 | all-input properties the tests only sample | `reports/formal.md`, `reports/formal_mutants.md` |
| 4. Structural | Yosys netlist analysis | combinational loops / paths, fanout | `reports/comb_paths.md`, `reports/fanout.md` |

## 1. NoC functional tests (`tb/tb_noc.sv`)
The checker does not trust the DUT: every injected flit is recorded (source, per-source counter); every ejected flit must match a live
record bit-exactly, arrive at the tile its `dst_id` names, not have been delivered before (duplicate), have been injected (phantom), be in
injection order for its (src,dst) pair, and ejection valid/payload must be stable under stall. At quiescence nothing may remain live (loss).
Stimulus is a deterministic xorshift generator (`+SEED`), per-tile injection and ejection policies, and an open-loop mode for the lab.

| test | what it establishes |
|---|---|
| `reset_state` | after reset: no ejection, `noc_idle`, every `inj_ready` high |
| `all_pairs_zero_load` | every (src,dst) pair alone at **exactly `2(hops+1)` cycles** (crossbar: 2); delivery count exact |
| `local_delivery`, `one_hop`, `diagonal` | local loopback, every neighbour pair, both diagonals at once |
| `simultaneous_permutations` | rotate / complement / transpose permutations injected simultaneously |
| `all_pairs_simultaneous` | uniform random incl. self at full rate, every pair exercised |
| `bidirectional` | partner swaps in both directions at once |
| `all_to_one_hotspot` | every source to tile 0 with a slow sink; per-source delivered == injected |
| `random_backpressure`, `periodic_backpressure` | random and periodic sink stalls |
| `queue_saturation` | all sinks blocked: back-pressure must reach the injectors, nothing may eject, nothing lost on release |
| `reset_during_traffic`, `repeated_reset_cycles` | reset with flits in buffers/egress/links; clean state, no stale flit after |
| `qos_class_starvation` | low class must keep a quantified share while the high class is active (bound derived from `QOS_STARVE_LIMIT`) |
| `invalid_destination`, `reserved_class_and_invalid_pkt`, `spoofed_source_id` | bad packets are rejected **and counted exactly** (DUT `err_drop` == injected bad), good traffic unaffected, fabric never wedges |
| `wormhole_multiflit` (counted / explicit) | flits of a packet contiguous at the ejection port; variable lengths 1..VARLEN |
| `long_random_mixed` | six phases of mixed patterns and policies |

After **every** test `check_counters` compares the hardware counters with the scoreboard (INJ/EJ/DROP flits and packets, latency
count/sum/min/max, in-flight == 0 at drain, FLITS_IN == FLITS_OUT fabric-wide, OCC_MAX <= depth).

Configurations (`scripts/regress.py`): mesh 2x2 at depth 2/3/4/8; 3x3, 4x4, 3x2, 2x3, 4x2 (tile ID != index for the non-power-of-two
ones); counted wormhole 2 and 4 flits; explicit framing 2x2 and 3x3; QoS guard K=7 and K=3; strict priority (the QoS test is *expected to
fail* there); crossbar 4/9/16; and the **unmodified original router** (assertions armed, assertions compiled out, 2x2/3x3/multi-flit/QoS),
where the known defects are *required* to reproduce. Seeds 1, 2, 3. `reports/orig_vs_v2_cycles.md`: where both pass, v2 equals the
original cycle for cycle.

## 2. System tests (`tb/tb_noc_sys.sv`)
Four tiles; each has a master NI, a target NI and a real `memory_controller` (4 banks x 64 lines). Per-(initiator, port) address regions
are disjoint and every port is in order, so a shadow memory gives exact expectations (data, lane masks, strobes, burst beats, tags, status).
`smoke_all_ports_all_targets`, `scalar_rw_every_target`, `vector_lane_masked_rw`, `dma_burst_rw_strobes`, `concurrent_random_backpressure`,
`error_completions` (~35 % deliberately illegal: misaligned, wrong domain, beyond aperture, no tile - exact status codes),
`response_consumer_stall` (credits throttle, then recover), `reset_during_memory_traffic`, `control_regs_and_corner_packets` (scratch
registers for every pair, unmapped control address, counters read over the NoC, partial-lane write rejected and memory untouched, MSG and
response-class packets dropped, orphan burst beat dropped), `counters_match_traffic` (flit conservation on both networks).
`protocol_stress` is the deadlock study (`docs/DEADLOCK.md`); the functional suite is also run on a *shared* network at default and at 64-deep sizes as a control experiment, with hard assertions about what must still work and what is expected to break.

## 3. Formal (`formal/`, `scripts/run_formal.py`)
Properties are stated on **ports and counter taps** and written independently of the RTL (e.g. the expected XY output port is recomputed with plain integer
comparisons). The router is verified with a reduced-width flit through its generic `pkt_t` parameter, so the RTL under test is the shipped RTL.
Environment assumptions (listed in `formal/fv_router.sv`): reset first, ready/valid hold, neighbour ports carry upstream-validated XY-consistent flits,
local port unconstrained, sinks arbitrary. SLANG ignores `(* anyconst *)`, so symbolic constants are module inputs pinned by assumptions.

| property | result strength |
|---|---|
| FIFO count bounds, flag exactness, occupancy == pushes - pops | **unbounded** (k-induction) |
| FIFO order/integrity of a marked element | bounded, depth 14 |
| router reset state | **unbounded** |
| router output valid+payload stable under stall | **unbounded** |
| grants: one per output and per input, need request/space/non-empty buffer; no overflow/underflow; `ready == registered not-full` | bounded, depth 8 |
| every flit leaves on the port XY routing selects (=> no Y->X turn, no U-turn, eject only if addressed here) | bounded, depth 8 |
| flits in router == accepted - transferred (no loss, no duplication) | bounded, depth 5 |
| ingress validation exact (drop iff bad, cause bits exact, good accepted) | bounded, depth 5 |
| round-robin: wait <= NP-1 = 4 accepting cycles, any output, any input | bounded, depth 10 |
| QoS guard K=1: wait <= (NP-1)(K+1)+K = 9 | bounded, depth 14 |
| 2x2 mesh: any src/dst/payload delivered only at dst, exactly once, bit exact, at exactly 2(hops+1) cycles | bounded, depth 11 (covers every pair) |

**Bounded** means "no violation within N cycles from reset for any input sequence"; induction fails on the remaining groups only because it
starts from unreachable internal states (for example the wormhole `drop_q` flop being 1 in single-flit mode), not because a counterexample
exists. The solver (z3) scales roughly x2.5 per two extra steps, which sets the depths above; **liveness is therefore established by the
bounded starvation properties, by the acyclic dependency argument, and by simulation, not by an unbounded proof.**

### Non-vacuity: mutation testing of the proofs (`reports/formal_mutants.md`)
Nine deliberate RTL bugs (round-robin pointer frozen; E/W decode swapped; egress valid dropped under stall; full flag never set;
ingress validation off; QoS guard off; **single shared QoS pointer**; mesh-wide E/W swap; allocator ignoring back-pressure), each run
against the property group that should catch it: every one must yield a counterexample, otherwise the property is vacuous.

## 4. Structural (`scripts/netlist_analysis.py`)
On the gate netlist of the interior router: back-cone of every output through combinational cells (flops stop the cone). All 15 link-facing
outputs (ready, valid, payload on 5 ports) have an **empty** input dependency set; only telemetry taps depend on `out_ready`/local inputs.
`yosys check -assert` reports 0 problems (no loops, no multiple drivers) on the flattened 2x2 mesh.

## 5. Bugs found by this verification (including my own)
| found by | bug | resolution |
|---|---|---|
| layer 1 | original: bad destination misdelivers/wedges (hardware view); QoS strict priority starves | V2-1, V2-2 |
| layer 1 (counters cross-check) | **my** counters recorded only one latency sample per cycle when several tiles ejected together | accumulate per cycle, single update |
| layer 3 (formal) | **my** first QoS guard shared one round-robin pointer between classes: a low-class requester could be passed over indefinitely | per-class pointers (V2-2b) |
| layer 3 | **my** QoS property had a 3-bit saturating counter against a bound of 7 (a tautology) and then two wrong bound formulas; found because the mutants were not caught, then by reading the counterexample grants | counter widened; bound derived and checked on real grants: (NP-1)(K+1)+K |
| layer 1 | **my** counter cross-check read the counters with `#1` delays, so only builds that contain counters (v2) spent simulated time between tests, shifting cycle-dependent stimulus: the original-vs-v2 comparison showed false differences even on an idle test (16 vs 25 cycles) | reads take 1 ps; regression and comparison rerun |
| layer 2 | burst agent (testbench) looked for the completion one cycle after its handshake, so every burst test hung; the NI trace showed the NI was correct | agent consumes the completion at the handshake |
| tb | several testbench slips (truncated wormhole packet on stop, unsigned underflow, `ready` sampled at the wrong edge in the raw injector, `anyconst` ignored by SLANG) | fixed; each had been reported as a DUT failure first and was traced to the testbench before any RTL change |

Not collected: line or functional coverage (no coverage tool run).
