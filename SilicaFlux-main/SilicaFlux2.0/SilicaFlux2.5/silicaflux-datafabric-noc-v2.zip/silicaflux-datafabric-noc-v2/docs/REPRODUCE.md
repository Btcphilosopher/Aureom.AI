# Reproduction commands

Tools used (versions as run): Verilator 5.020, Yosys 0.71 + SLANG + SymbiYosys (YoWASP, isolated venv), z3 (PyPI), Python 3.13
with numpy/matplotlib/pandas. Icarus 12 was only used to establish that it cannot compile the original (not required).
Network access needed once: apt and PyPI. GitHub is not needed.

```bash
scripts/setup_tools.sh        # follow the apt line it prints, then it installs the Python parts and the YoWASP venv
```

## Audit evidence (section 1-2 of docs/AUDIT.md)
```bash
sha256sum -c original/SHA256SUMS                                    # originals are untouched
cp "SilicaFlux2.5/silicaflux_pkg (1).sf" /tmp/pkg.sv; cp SilicaFlux2.5/memory_controller.sf /tmp/mc.sv
verilator --lint-only -Wall --top-module memory_controller /tmp/pkg.sv /tmp/mc.sv      # clean
verilator --lint-only +systemverilogext+sf --top-module memory_controller pkg.sf mc.sf  # .sf accepted directly
```
(`noc_interconnect.sf` needs the package type from `rtl/silicaflux_noc_section.svh`; `python3 scripts/regress.py --only ORIG_mesh2x2`
reproduces the original's behaviour.)

## Build the corrected RTL from the original
```bash
make rtl            # scripts/make_v2_rtl.py -> rtl/noc_interconnect.sv ; delta in docs/noc_interconnect_v2.diff
make lint
```

## Functional verification
```bash
make quick          # 5 configurations x 1 seed, includes the original router (expected defects reproduce)
make regress        # 26 configurations x 3 seeds -> reports/regression.md
make sys            # real memory_controller behind the NoC + deadlock study -> reports/regression_sys.md, reports/deadlock_diag.txt
```
One configuration by hand (crossbar, 4 tiles, depth 4):
```bash
verilator --binary --timing --assert -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD --top-module tb_noc -GFABRIC=1 \
  -Mdir build/one -o sim -Irtl rtl/silicaflux_pkg.sv rtl/noc_interconnect.sv rtl/sf_noc_xbar.sv rtl/sf_noc_traffic_counters.sv tb/tb_noc.sv
build/one/sim +TEST=all +SEED=7
```
The shared-network deadlock by hand:
```bash
# build tb_noc_sys with -GSEP=0 -GBUFD=2 -GREQ_Q=2 -GRSP_Q=2 -GCTX_Q=2 -GOUT_S=32 -GOUT_V=32  (see scripts/regress_sys.py)
build/.../sim +TEST=protocol_stress +SEED=1 +TGT=1 +NBURST=40 +EXPECT_DEADLOCK     # prints the DIAG buffer state
```

## Performance laboratory
```bash
make perf           # scripts/perf_lab.py (~10-20 min after builds) then scripts/perf_report.py -> reports/PERFORMANCE.md, reports/img/*.png
```
A single load point: `build/<variant>/obj/sim +TEST=perf +PAT=uniform_ne +RATE=96 +WARMC=3000 +MEAS=30000 +SEED=1 +DUMP=1 +LATFILE=lat.csv`
(`RATE` is arrivals per cycle per tile in 1/256 units; patterns: uniform uniform_ne transpose complement neighbor local allto1 hotspot).

## Formal
```bash
make formal         # reports/formal.md   (FIFO, router property groups, QoS bound, 2x2 mesh)
make mutants        # reports/formal_mutants.md : every injected bug must produce a counterexample
```
Single task: `cd formal && PATH=../build/bin:$PATH ../build/venv/bin/yowasp-sby -f router.sby route_bmc`

## Synthesis and structural timing
```bash
make synth          # reports/synth.md, reports/comb_paths.md, reports/fanout.md  (no PDK: no ns / MHz / um^2)
```
