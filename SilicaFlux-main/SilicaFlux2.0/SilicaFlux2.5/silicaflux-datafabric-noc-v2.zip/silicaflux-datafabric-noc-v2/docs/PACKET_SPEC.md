# SF-NOC packet contract, version 1

Defined in `rtl/silicaflux_noc_section.svh` (included by `rtl/silicaflux_pkg.sv`, whose memory section is byte-identical to
`SilicaFlux2.5/silicaflux_pkg (1).sf`). One `noc_packet_t` is one **flit** on a link; a packet is one or more flits.

## 1. Layout (MSB first, 207 bits at DATA_W = 128)

| bits | field | width | type | meaning | inspected by the fabric? |
|---|---|---|---|---|---|
| 206 | `valid` | 1 | | packet valid qualifier | yes - checked on the head flit at injection |
| 205 | `sop` | 1 | | first flit of a packet | yes with `EXPLICIT_FRAMING` |
| 204 | `eop` | 1 | | last flit of a packet | yes with `EXPLICIT_FRAMING` |
| 203:201 | `pclass` | 3 | `sf_noc_class_e` | RD_REQ 0, WR_REQ 1, RD_RSP 2, WR_RSP 3, MSG 4, 5-7 reserved | legality checked at injection; selects request/response network |
| 200:199 | `qos` | 2 | | MSB = high-priority class | MSB used by the QoS arbiter (when enabled) |
| 198:195 | `dst_id` | 4 | `sf_noc_id_t` | destination tile, **coordinate encoded `{y,x}`** | yes - routing + validation |
| 194:191 | `src_id` | 4 | `sf_noc_id_t` | source tile, coordinate encoded | checked == injecting tile (`CHECK_SRC`) |
| 190:183 | `txn_id` | 8 | `sf_mem_tag_t` | transaction ID (the memory tag) | no - carried |
| 182:180 | `status` | 3 | `sf_mem_exc_e` | response status = the memory exception code | no - carried |
| 179:178 | `xfer` | 2 | `sf_noc_xfer_e` | SCALAR / VECTOR / BURST / CTRL | no - used by the NIs |
| 177:176 | `hint` | 2 | `sf_mem_hint_e` | memory hint | no - carried |
| 175:144 | `addr` | 32 | `sf_paddr_t` | physical address / register offset | no - carried |
| 143:128 | `be` | 16 | | byte enables (writes; read data validity) | no - carried |
| 127:0 | `data` | 128 | | payload (`SF_VLEN`, one vector line) | no - carried |

"Carried" means bit-exact end to end (checked by the scoreboard on every flit of every test).

## 2. Rules
1. **Single-flit packets** (default) have `sop = eop = 1`. Multi-flit packets use either counted framing (`FLITS_PER_PKT`, fixed
   length, original behaviour) or **explicit framing** (`EXPLICIT_FRAMING = 1`: any length, head/tail from `sop/eop`). Flits of one
   packet are delivered contiguously at the ejection port (wormhole lock).
2. **IDs are coordinates**, `{y, x}` with `x` in the low `clog2(MESH_X)` bits. `ID == linear tile index` only when `MESH_X` is a
   power of two. Use `sf_noc_id(x,y,mesh_x)` and `sf_noc_tile_index(id,mesh_x)`; never assume.
3. **Requests** (RD_REQ, WR_REQ, MSG) and **responses** (RD_RSP, WR_RSP) travel on different networks (`sf_noc_vnet_of`).
4. A **response** copies `txn_id, addr, xfer, hint, qos` from its request and swaps `src_id/dst_id` (`sf_noc_make_rsp`).
   `txn_id` must be unique per source while outstanding (the master NI and the latency counters rely on it).
5. Read data flits carry `be != 0`; an **error completion carries no data and `be = 0`** (how a burst-read requester tells an
   error from a data beat).
6. Burst write: descriptor flit (`WR_REQ`, `xfer = BURST`, `sop`, `data[7:0] = len_m1`, `addr = base`) then `len_m1+1` beat flits
   (`data`, `be = strobes`), last with `eop`. Burst read: one descriptor flit (`RD_REQ`) -> `len_m1+1` response beats (`sop` ... `eop`).
7. **Response status reuses the memory exception codes**: NONE, MISALIGN, RANGE, DOMAIN, BURST_BND, BURST_LEN, ECC, FLUSHED.
   A NoC-level decode error (address maps to no tile, or a rejected injection) is reported as RANGE by the master NI.

## 3. Ingress validation (hardware, local port only)
A head flit is **dropped whole** (handshake completes, nothing stored, `err_drop`/`err_drop_head`/`err_cause` pulse) if:
`dst_id` names no tile (bits above the coordinate field, x >= MESH_X, y >= MESH_Y) -> cause bit 0; `valid = 0` or reserved
`pclass` -> bit 1; `src_id` != the injecting tile -> bit 2. Neighbour ports carry only flits that already passed this check.

## 4. Versioning
`SF_NOC_PKT_VERSION = 1`. It is also readable at run time: `sf_noc_traffic_counters` register `0x0000` = `{16'h5F0C, block revision 8'h01, packet contract version 8'h01}` (`docs/COUNTERS.md`).
Any change of a width, order or meaning is a contract change: bump the version and re-check every producer and consumer.

## 5. Memory-type mapping (reuse of `silicaflux_pkg`)
| memory type (real) | NoC packet |
|---|---|
| `sf_scalar_mem_req_t {op, addr, wdata, wstrb, tag, hint}` | `pclass = op ? WR_REQ : RD_REQ`, `xfer = SCALAR`, `be[3:0] = wstrb`, `data[31:0] = wdata`, `txn_id = tag` |
| `sf_scalar_mem_rsp_t {op, rdata, tag, exc}` | `RD_RSP/WR_RSP`, `data[31:0]`, `txn_id`, `status = exc` |
| `sf_vector_mem_req_t {op, addr, wdata, lane_mask, tag, hint}` | `xfer = VECTOR`, `be[4i+:4] = {4{lane_mask[i]}}`, `data = wdata` |
| `sf_burst_desc_t / wbeat / rbeat / done` | `xfer = BURST`, see rule 6; `done` is synthesised by the master NI |

## 6. Producers and consumers checked for this contract
| module | role | status |
|---|---|---|
| `noc_router` / `noc_interconnect` (v2) | consumer/forwarder | verified (simulation + formal) |
| `sf_noc_xbar` | consumer/forwarder | simulation |
| `sf_noc_mem_master_ni` | producer of requests, consumer of responses | system tests |
| `sf_noc_mem_target_ni` | consumer of requests, producer of responses | system tests, real `memory_controller` |
| `sf_noc_traffic_counters` | observer | cross-checked against an independent scoreboard |
| `tile_interface` | producer (`sf_noc_flit_t`) | **not connected**: its package (`sf_tile_pkt_t`, `sf_noc_flit_t`) is absent from the tree; see KNOWN_LIMITATIONS |
