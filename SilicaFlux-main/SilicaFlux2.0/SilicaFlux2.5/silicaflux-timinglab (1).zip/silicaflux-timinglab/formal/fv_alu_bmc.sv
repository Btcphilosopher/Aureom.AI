`default_nettype none
// =============================================================================
//  SilicaFlux TimingLab - cycle-exact sequential miter: sf_alu (upstream
//  alu.sf) vs sf_alu_mulcsa. Same free inputs every cycle (incl. flush,
//  branch kill/resolve, back-pressure); ok = every output identical in every
//  cycle. All state starts at its (all-zero) reset value. Bounded model check
//  at XLEN = 8 (the 64-bit multiplier miter is beyond SAT; 64-bit equivalence
//  is covered by tb/equiv/tb_eq_alu.sv).
// =============================================================================
module fv_alu_bmc #(parameter int unsigned XLEN = 8, parameter int unsigned MUL_STAGES = 2) (
  input  logic            clk, flush_i, req_valid_i, req_sat_i, req_rd_we_i, res_ready_i,
  input  logic [11:0]     br_kill_mask_i, br_resolve_mask_i, req_br_mask_i,
  input  logic [3:0]      req_op_i,
  input  logic [XLEN-1:0] req_src_a_i, req_src_b_i,
  input  logic [6:0]      req_rob_tag_i,
  input  logic [7:0]      req_pdst_i,
  output logic            ok,
  output logic bad            // = !ok (single property output for ABC)
);
  typedef struct packed {
    logic req_ready, fast_ready, mul_ready, res_valid, res_rd_we, res_illegal;
    logic [XLEN-1:0] res_data; logic [6:0] res_rob_tag; logic [7:0] res_pdst;
    logic [11:0] res_br_mask; logic [3:0] res_flags, res_flags_we;
  } o_t;
  o_t a, b;
`define TL_FV_ALU(MOD, NAME, O) \
  MOD #(.XLEN(XLEN), .MUL_STAGES(MUL_STAGES)) NAME ( \
    .clk_i(clk), .rst_ni(1'b1), .flush_i(flush_i), .br_kill_mask_i(br_kill_mask_i), \
    .br_resolve_mask_i(br_resolve_mask_i), .req_valid_i(req_valid_i), .req_ready_o(O.req_ready), \
    .fast_ready_o(O.fast_ready), .mul_ready_o(O.mul_ready), .req_op_i(req_op_i), .req_sat_i(req_sat_i), \
    .req_src_a_i(req_src_a_i), .req_src_b_i(req_src_b_i), .req_rob_tag_i(req_rob_tag_i), \
    .req_pdst_i(req_pdst_i), .req_rd_we_i(req_rd_we_i), .req_br_mask_i(req_br_mask_i), \
    .res_valid_o(O.res_valid), .res_ready_i(res_ready_i), .res_data_o(O.res_data), \
    .res_rob_tag_o(O.res_rob_tag), .res_pdst_o(O.res_pdst), .res_rd_we_o(O.res_rd_we), \
    .res_br_mask_o(O.res_br_mask), .res_illegal_o(O.res_illegal), .res_flags_o(O.res_flags), \
    .res_flags_we_o(O.res_flags_we));
  `TL_FV_ALU(sf_alu, u_ref, a)
  `TL_FV_ALU(sf_alu_mulcsa, u_dut, b)
  assign ok = (a == b);
  assign bad = ~ok;
endmodule
`default_nettype wire
