`default_nettype none
// =============================================================================
//  SilicaFlux TimingLab - sequential miter: upstream vector_engine
//  (EX_STAGES = 1) vs sf_vector_engine_pipe, bounded model check.
//
//  Both engines see the same free inputs every cycle (stall_i free; flush_i
//  tied to 0 - the flush contract is a speculation-window change and is
//  checked by simulation in tb/equiv/tb_eq_vector.sv). All state starts at its
//  reset value (every reset value in both designs is zero, so the proof uses
//  an all-zero initial state).
//
//  The upstream outputs pass through a two-entry delay line that advances on
//  non-stalled cycles only, because the pipelined engine presents packet k
//  two non-stalled clock edges after upstream does. `ok` compares, EVERY
//  cycle: res_valid, res_spec, res_tag, res_illegal, res_data, res_lane_we,
//  res_sat, res_scalar_wr, and res_scalar when res_scalar_wr = 1; plus the
//  combinational issue outputs iss_ready / iss_fpx. busy_o is excluded (it
//  legitimately covers the deeper pipeline).
// =============================================================================
module fv_vector_bmc #(
  parameter int unsigned LANES  = 4,
  parameter int unsigned LANE_W = 8,
  parameter int unsigned TAG_W  = 3
) (
  input  logic                         clk,
  input  logic                         stall,
  input  logic                         iss_valid, iss_spec, iss_mask_en, iss_mpol,
  input  logic [TAG_W-1:0]             iss_tag,
  input  logic [5:0]                   iss_op,
  input  logic [1:0]                   iss_bsrc,
  input  logic [LANES-1:0]             iss_mask,
  input  logic [$clog2(LANES+1)-1:0]   iss_vl,
  input  logic [LANES-1:0][LANE_W-1:0] iss_va, iss_vb, iss_vd, xlane_b,
  input  logic [LANE_W-1:0]            iss_scalar,
  output logic                         ok,
  output logic bad            // = !ok (single property output for ABC)
);
  typedef struct packed {
    logic                         valid, spec, illegal, sat, scalar_wr;
    logic [TAG_W-1:0]             tag;
    logic [LANES-1:0][LANE_W-1:0] data;
    logic [LANES-1:0]             lane_we;
    logic [LANE_W-1:0]            scalar;
  } o_t;

  o_t u, p;
  logic u_ready, p_ready, u_fpx, p_fpx, u_busy, p_busy;

`define TL_FV_ENGINE(MOD, PARAMS, NAME, O, RDY, FPX, BUSY) \
  MOD PARAMS NAME ( \
    .clk_i(clk), .rst_ni(1'b1), .stall_i(stall), .flush_i(1'b0), .iss_ready_o(RDY), .busy_o(BUSY), \
    .iss_valid_i(iss_valid), .iss_spec_i(iss_spec), .iss_tag_i(iss_tag), .iss_op_i(iss_op), \
    .iss_bsrc_i(iss_bsrc), .iss_mask_en_i(iss_mask_en), .iss_mask_i(iss_mask), .iss_vl_i(iss_vl), \
    .iss_mpol_i(iss_mpol), .iss_va_i(iss_va), .iss_vb_i(iss_vb), .iss_vd_i(iss_vd), \
    .iss_scalar_i(iss_scalar), .xlane_b_i(xlane_b), .iss_fpx_o(FPX), \
    .res_valid_o(O.valid), .res_spec_o(O.spec), .res_tag_o(O.tag), .res_illegal_o(O.illegal), \
    .res_data_o(O.data), .res_lane_we_o(O.lane_we), .res_sat_o(O.sat), \
    .res_scalar_wr_o(O.scalar_wr), .res_scalar_o(O.scalar));

  `TL_FV_ENGINE(vector_engine, #(.LANES(LANES), .LANE_W(LANE_W), .TAG_W(TAG_W), .EX_STAGES(1)), u_up, u, u_ready, u_fpx, u_busy)
  `TL_FV_ENGINE(sf_vector_engine_pipe, #(.LANES(LANES), .LANE_W(LANE_W), .TAG_W(TAG_W)), u_pipe, p, p_ready, p_fpx, p_busy)

  o_t d1, d2;
  always_ff @(posedge clk) begin
    if (!stall) begin
      d1 <= u;
      d2 <= d1;
    end
  end

  always_comb begin
    ok = (p.valid == d2.valid) && (p.spec == d2.spec) && (p.tag == d2.tag) && (p.illegal == d2.illegal) &&
         (p.data == d2.data) && (p.lane_we == d2.lane_we) && (p.sat == d2.sat) &&
         (p.scalar_wr == d2.scalar_wr) && (!p.scalar_wr || (p.scalar == d2.scalar)) &&
         (p_ready == u_ready) && (p_fpx == u_fpx);
  end
  assign bad = ~ok;
endmodule
`default_nettype wire
