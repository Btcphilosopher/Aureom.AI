// =============================================================================
//  SilicaFlux TimingLab - formal miters (Yosys `sat`) for the vector datapath
//
//  fv_mul_lo     : sf_mul_lo_csa  vs  (a * b) mod 2^W           (all inputs)
//  fv_csa        : sf_csa_tree    vs  sum of N rows mod 2^W      (all inputs)
//  fv_reduce     : sf_reduce_tree vs  the upstream heap-ordered reduction
//                  (vector_engine.sf lines 295-307, 530-554, ve_red_fn copied
//                  verbatim)                                       (all inputs)
//  Each miter drives `ok`; formal/run_formal.py proves ok == 1 for every
//  input assignment (sat -prove ok 1).
// =============================================================================
module fv_mul_lo #(parameter int unsigned W = 8) (
  input  logic [W-1:0] a, b,
  output logic         ok
);
  logic [W-1:0] s, c, ref_p;
  sf_mul_lo_csa #(.W(W)) u_dut (.a_i(a), .b_i(b), .sum_o(s), .carry_o(c));
  assign ref_p = a * b;
  assign ok = ((s + c) == ref_p);
endmodule

module fv_csa #(parameter int unsigned W = 32, parameter int unsigned N = 5) (
  input  logic [N-1:0][W-1:0] rows,
  output logic                ok
);
  logic [W-1:0] s, c, acc;
  sf_csa_tree #(.W(W), .N(N)) u_dut (.rows_i(rows), .sum_o(s), .carry_o(c));
  always_comb begin
    acc = '0;
    for (int i = 0; i < N; i++) acc = acc + rows[i];
  end
  assign ok = ((s + c) == acc);
endmodule

module fv_reduce #(parameter int unsigned W = 32, parameter int unsigned N = 4) (
  input  logic [1:0]          rop,
  input  logic [N-1:0][W-1:0] leaf,
  output logic                ok
);
  localparam int unsigned LV = $clog2(N);
  typedef logic [W-1:0] lane_t;

  // --- upstream reduction (vector_engine.sf ve_red_fn + heap tree) ---------
  function automatic lane_t ve_red_fn(input logic [1:0] r, input lane_t x, input lane_t y);
    case (r)
      2'd0 : return x + y;
      2'd1 : return x & y;
      2'd2 : return x | y;
      2'd3 : return x ^ y;
      default : return '0;
    endcase
  endfunction

  for (genvar lv = 0; lv < LV; lv++) begin : g_lvl
    localparam int unsigned NODES = N >> (lv + 1);
    lane_t node [NODES];
    for (genvar n = 0; n < NODES; n++) begin : g_node
      if (lv == 0) begin : g_from_leaf
        assign node[n] = ve_red_fn(rop, leaf[2 * n], leaf[(2 * n) + 1]);
      end else begin : g_from_lvl
        assign node[n] = ve_red_fn(rop, g_lvl[lv-1].node[2 * n], g_lvl[lv-1].node[(2 * n) + 1]);
      end
    end
  end

  lane_t dut;
  sf_reduce_tree #(.W(W), .N(N)) u_dut (.rop_i(rop), .leaf_i(leaf), .red_o(dut));
  assign ok = (dut == g_lvl[LV-1].node[0]);
endmodule

// ---------------------------------------------------------------------------
// Single-output wrappers for ABC (iprove proves the output is constant 0)
// ---------------------------------------------------------------------------
module fv_reduce_bad #(parameter int unsigned W = 32, parameter int unsigned N = 4) (
  input  logic [1:0]          rop,
  input  logic [N-1:0][W-1:0] leaf,
  output logic                bad
);
  logic ok;
  fv_reduce #(.W(W), .N(N)) u (.rop(rop), .leaf(leaf), .ok(ok));
  assign bad = ~ok;
endmodule

module fv_csa_bad #(parameter int unsigned W = 32, parameter int unsigned N = 5) (
  input  logic [N-1:0][W-1:0] rows,
  output logic                bad
);
  logic ok;
  fv_csa #(.W(W), .N(N)) u (.rows(rows), .ok(ok));
  assign bad = ~ok;
endmodule

module fv_mul_lo_bad #(parameter int unsigned W = 8) (
  input  logic [W-1:0] a, b,
  output logic         bad
);
  logic ok;
  fv_mul_lo #(.W(W)) u (.a(a), .b(b), .ok(ok));
  assign bad = ~ok;
endmodule
