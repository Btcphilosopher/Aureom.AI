// =============================================================================
//  SilicaFlux TimingLab - cycle-exact equivalence: sf_alu (upstream alu.sf)
//  vs sf_alu_mulcsa (TimingLab). Same inputs every cycle; EVERY output is
//  compared EVERY cycle after reset. MUL is issued with high probability so
//  the changed multiplier stage is exercised under back-pressure, flush and
//  branch kills. Upstream SVA stays active with --assert (stimulus obeys the
//  upstream assumptions: legal opcodes, req_sat_i only with SAT_EN).
//  Plusargs: +seed=<n> +cycles=<n>
// =============================================================================
`timescale 1ns/1ps
`ifndef TL_XLEN
  `define TL_XLEN 64
`endif
`ifndef TL_MUL_STAGES
  `define TL_MUL_STAGES 2
`endif
module tb_eq_alu;
  localparam int unsigned XLEN = `TL_XLEN;
  localparam int unsigned ROB_TAG_W = 7, PREG_W = 8, BR_MASK_W = 12;

  logic clk = 1'b0, rst_n;
  always #5 clk = ~clk;

  logic                 flush, req_valid, req_sat, req_rd_we, res_ready;
  logic [BR_MASK_W-1:0] br_kill, br_resolve, req_br_mask;
  logic [3:0]           req_op;
  logic [XLEN-1:0]      src_a, src_b;
  logic [ROB_TAG_W-1:0] rob_tag;
  logic [PREG_W-1:0]    pdst;

  typedef struct packed {
    logic                 req_ready, fast_ready, mul_ready, res_valid, res_rd_we, res_illegal;
    logic [XLEN-1:0]      res_data;
    logic [ROB_TAG_W-1:0] res_rob_tag;
    logic [PREG_W-1:0]    res_pdst;
    logic [BR_MASK_W-1:0] res_br_mask;
    logic [3:0]           res_flags, res_flags_we;
  } o_t;
  o_t o_ref, o_dut;

`define TL_ALU(MOD, NAME, O) \
  MOD #(.XLEN(XLEN), .MUL_STAGES(`TL_MUL_STAGES)) NAME ( \
    .clk_i(clk), .rst_ni(rst_n), .flush_i(flush), .br_kill_mask_i(br_kill), .br_resolve_mask_i(br_resolve), \
    .req_valid_i(req_valid), .req_ready_o(O.req_ready), .fast_ready_o(O.fast_ready), .mul_ready_o(O.mul_ready), \
    .req_op_i(req_op), .req_sat_i(req_sat), .req_src_a_i(src_a), .req_src_b_i(src_b), \
    .req_rob_tag_i(rob_tag), .req_pdst_i(pdst), .req_rd_we_i(req_rd_we), .req_br_mask_i(req_br_mask), \
    .res_valid_o(O.res_valid), .res_ready_i(res_ready), .res_data_o(O.res_data), .res_rob_tag_o(O.res_rob_tag), \
    .res_pdst_o(O.res_pdst), .res_rd_we_o(O.res_rd_we), .res_br_mask_o(O.res_br_mask), \
    .res_illegal_o(O.res_illegal), .res_flags_o(O.res_flags), .res_flags_we_o(O.res_flags_we));

  `TL_ALU(sf_alu, u_ref, o_ref)
  `TL_ALU(sf_alu_mulcsa, u_dut, o_dut)

  function automatic logic [XLEN-1:0] rnd_word();
    case ($urandom_range(0, 7))
      0: return '0;
      1: return '1;
      2: return {1'b0, {(XLEN-1){1'b1}}};
      3: return {1'b1, {(XLEN-1){1'b0}}};
      4: return XLEN'($urandom_range(0, 100));
      default: return XLEN'({$urandom(), $urandom(), $urandom()});
    endcase
  endfunction

  int unsigned seed, cycles;
  int errors = 0, compared = 0, n_mul_res = 0;

  always @(negedge clk) begin
    if (rst_n) begin
      compared++;
      if (o_ref !== o_dut) begin
        if (errors < 10) $display("ERROR cycle %0t: ref %h dut %h", $time, o_ref, o_dut);
        errors++;
      end
    end
  end

  initial begin
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("cycles=%d", cycles)) cycles = 50000;
    void'($urandom(seed));
    rst_n = 0; flush = 0; req_valid = 0; req_sat = 0; req_rd_we = 0; res_ready = 1; br_kill = '0;
    br_resolve = '0; req_br_mask = '0; req_op = '0; src_a = '0; src_b = '0; rob_tag = '0; pdst = '0;
    repeat (3) @(posedge clk);
    #1 rst_n = 1;
    for (int unsigned c = 0; c < cycles; c++) begin
      @(negedge clk);
      #1;
      req_valid  = ($urandom_range(0, 99) < 85);
      req_op     = ($urandom_range(0, 99) < 50) ? 4'h2 : 4'($urandom_range(0, 9));
      req_sat    = 1'b0;
      src_a      = rnd_word();
      src_b      = rnd_word();
      rob_tag    = ROB_TAG_W'($urandom());
      pdst       = PREG_W'($urandom());
      req_rd_we  = $urandom_range(0, 1);
      req_br_mask = ($urandom_range(0, 99) < 30) ? BR_MASK_W'(1 << $urandom_range(0, BR_MASK_W-1)) : '0;
      res_ready  = ($urandom_range(0, 99) < 75);
      flush      = ($urandom_range(0, 999) < 15);
      br_kill    = ($urandom_range(0, 99) < 3)  ? BR_MASK_W'(1 << $urandom_range(0, BR_MASK_W-1)) : '0;
      br_resolve = ($urandom_range(0, 99) < 5)  ? BR_MASK_W'(1 << $urandom_range(0, BR_MASK_W-1)) : '0;
    end
    @(negedge clk);
    $display("TL-RESULT %s seed=%0d cycles=%0d compared=%0d errors=%0d",
             (errors == 0) ? "PASS" : "FAIL", seed, cycles, compared, errors);
    $finish;
  end

  // count multiplier results reaching the port (coverage of the changed stage)
  always @(posedge clk) if (rst_n && u_ref.mul_tail_valid) n_mul_res++;
  final $display("coverage: multiplier tail results = %0d", n_mul_res);
endmodule
