// =============================================================================
//  SilicaFlux TimingLab - equivalence testbench: vector_engine (upstream,
//  SilicaFlux2.5/vector_engine.sf) vs sf_vector_engine_pipe (TimingLab).
//
//  Three engines receive the same stimulus every cycle:
//    u_ref    upstream vector_engine, EX_STAGES = `TL_REF_EX (default 1)
//    u_gold   upstream vector_engine with flush_i tied to 0 (golden payload
//             of every claimed issue packet)
//    u_dut    sf_vector_engine_pipe
//
//  Checks
//    1. Without flush (TL_FLUSH_PCT = 0): the sequence of consumed results
//       (res_valid_o & ~stall_i) of u_dut equals that of u_ref, field by field
//       (res_scalar_o compared when res_scalar_wr_o = 1, see DUT header).
//    2. With flush: for u_ref AND u_dut, the consumed results are an in-order
//       subsequence of u_gold's results; every skipped packet is speculative
//       and saw a flush while in flight; no result is invented or reordered.
//    2b. Exact kill contract: an occupancy model of the stage registers predicts
//       which issue packet each engine delivers on every non-stalled cycle;
//       u_ref and u_dut must deliver exactly the golden payloads of that list
//       (a speculative packet in flight during a flush MUST be dropped).
//    3. Upstream assertions stay active when compiled with --assert
//       (legal-opcode stimulus only, TL_ILLEGAL_PCT = 0).
//    4. Latency: without stalls, a packet issued at cycle t is presented at
//       t + LAT_DUT (3) by u_dut and t + `TL_REF_EX by u_ref.
//  Plusargs: +seed=<n> +cycles=<n>
// =============================================================================
`timescale 1ns/1ps
`ifndef TL_LANES
  `define TL_LANES 4
`endif
`ifndef TL_LANE_W
  `define TL_LANE_W 32
`endif
`ifndef TL_REF_EX
  `define TL_REF_EX 1
`endif
`ifndef TL_FLUSH_PCT
  `define TL_FLUSH_PCT 0
`endif
`ifndef TL_ILLEGAL_PCT
  `define TL_ILLEGAL_PCT 0
`endif
`ifndef TL_STALL_PCT
  `define TL_STALL_PCT 20
`endif

module tb_eq_vector;
  localparam int unsigned LANES  = `TL_LANES;
  localparam int unsigned LANE_W = `TL_LANE_W;
  localparam int unsigned TAG_W  = 6;
  localparam int unsigned VL_W   = $clog2(LANES + 1);
  localparam int unsigned LAT_DUT = 3;

  typedef logic [LANES-1:0][LANE_W-1:0] vec_t;

  logic clk = 1'b0;
  logic rst_n;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- stimulus
  logic             stall, flush, iss_valid, iss_spec, iss_mask_en, iss_mpol;
  logic [TAG_W-1:0] iss_tag;
  logic [5:0]       iss_op;
  logic [1:0]       iss_bsrc;
  logic [LANES-1:0] iss_mask;
  logic [VL_W-1:0]  iss_vl;
  vec_t             iss_va, iss_vb, iss_vd, xlane_b;
  logic [LANE_W-1:0] iss_scalar;

  // ---------------------------------------------------------------- outputs
  typedef struct packed {
    logic             spec;
    logic [TAG_W-1:0] tag;
    logic             illegal;
    vec_t             data;
    logic [LANES-1:0] lane_we;
    logic             sat;
    logic             scalar_wr;
    logic [LANE_W-1:0] scalar;
  } res_t;

  logic r_valid [3];
  res_t r_res   [3];
  logic r_busy  [3];
  logic r_ready [3];
  logic r_fpx   [3];

`define TL_ENGINE(MOD, PARAMS, NAME, IDX, FLUSH) \
  MOD PARAMS NAME ( \
    .clk_i(clk), .rst_ni(rst_n), .stall_i(stall), .flush_i(FLUSH), \
    .iss_ready_o(r_ready[IDX]), .busy_o(r_busy[IDX]), \
    .iss_valid_i(iss_valid), .iss_spec_i(iss_spec), .iss_tag_i(iss_tag), .iss_op_i(iss_op), \
    .iss_bsrc_i(iss_bsrc), .iss_mask_en_i(iss_mask_en), .iss_mask_i(iss_mask), .iss_vl_i(iss_vl), \
    .iss_mpol_i(iss_mpol), .iss_va_i(iss_va), .iss_vb_i(iss_vb), .iss_vd_i(iss_vd), \
    .iss_scalar_i(iss_scalar), .xlane_b_i(xlane_b), .iss_fpx_o(r_fpx[IDX]), \
    .res_valid_o(r_valid[IDX]), .res_spec_o(r_res[IDX].spec), .res_tag_o(r_res[IDX].tag), \
    .res_illegal_o(r_res[IDX].illegal), .res_data_o(r_res[IDX].data), \
    .res_lane_we_o(r_res[IDX].lane_we), .res_sat_o(r_res[IDX].sat), \
    .res_scalar_wr_o(r_res[IDX].scalar_wr), .res_scalar_o(r_res[IDX].scalar));

  `TL_ENGINE(vector_engine, #(.LANES(LANES), .LANE_W(LANE_W), .TAG_W(TAG_W), .EX_STAGES(`TL_REF_EX)), u_ref, 0, flush)
  `TL_ENGINE(vector_engine, #(.LANES(LANES), .LANE_W(LANE_W), .TAG_W(TAG_W), .EX_STAGES(`TL_REF_EX)), u_gold, 1, 1'b0)
  `TL_ENGINE(sf_vector_engine_pipe, #(.LANES(LANES), .LANE_W(LANE_W), .TAG_W(TAG_W)), u_dut, 2, flush)

  // ---------------------------------------------------------------- scoreboard
  res_t  q_cons  [3][$];      // consumed results per engine
  int    q_cycle [3][$];
  int    iss_cycle_of_tagseq [$];
  logic  iss_spec_of_seq     [$];
  int    flush_cycles        [$];
  int    cyc = 0;
  int    errors = 0;
  int    n_issued = 0;
  int    n_cmp = 0;

  function automatic bit res_eq(res_t a, res_t b);
    if (a.spec != b.spec || a.tag != b.tag || a.illegal != b.illegal || a.data != b.data ||
        a.lane_we != b.lane_we || a.sat != b.sat || a.scalar_wr != b.scalar_wr) return 1'b0;
    if (a.scalar_wr && (a.scalar != b.scalar)) return 1'b0;
    return 1'b1;
  endfunction

  function automatic logic [LANE_W-1:0] rnd_lane();
    int unsigned k = $urandom_range(0, 9);
    case (k)
      0: return '0;
      1: return '1;
      2: return {1'b0, {(LANE_W-1){1'b1}}};
      3: return {1'b1, {(LANE_W-1){1'b0}}};
      4: return LANE_W'($urandom_range(0, 40));
      default: return LANE_W'({$urandom(), $urandom()});
    endcase
  endfunction

  localparam logic [5:0] LEGAL_OPS [21] = '{6'o00, 6'o01, 6'o07, 6'o10, 6'o11, 6'o12, 6'o13, 6'o20, 6'o21,
                                           6'o22, 6'o30, 6'o31, 6'o40, 6'o50, 6'o51, 6'o52, 6'o53,
                                           6'o60, 6'o61, 6'o62, 6'o63};

  task automatic drive_random();
    stall       = ($urandom_range(0, 99) < `TL_STALL_PCT);
    flush       = ($urandom_range(0, 99) < `TL_FLUSH_PCT);
    iss_valid   = ($urandom_range(0, 99) < 80);
    iss_spec    = ($urandom_range(0, 99) < 40);
    if ($urandom_range(0, 99) < `TL_ILLEGAL_PCT) begin
      iss_op   = 6'($urandom());
      iss_bsrc = 2'($urandom());
    end else begin
      iss_op   = ($urandom_range(0, 99) < 4) ? (6'o70 | 6'($urandom_range(0, 7))) :   // FP fusion class
                 LEGAL_OPS[$urandom_range(0, 20)];
      iss_bsrc = 2'($urandom_range(0, 2));
    end
    iss_mask_en = $urandom_range(0, 1);
    iss_mask    = LANES'($urandom());
    iss_vl      = VL_W'($urandom_range(0, LANES));
    iss_mpol    = $urandom_range(0, 1);
    for (int l = 0; l < LANES; l++) begin
      iss_va[l] = rnd_lane(); iss_vb[l] = rnd_lane(); iss_vd[l] = rnd_lane(); xlane_b[l] = rnd_lane();
    end
    iss_scalar  = rnd_lane();
  endtask

  // ---------------------------------------------------------------------------
  // Exact occupancy model of the valid/spec/flush pipeline (the documented
  // upstream stage-register rules, vector_engine.sf lines 469-491 and 578-586):
  //   stall  : every stage keeps its packet, a held speculative packet dies on flush
  //   ~stall : stage k <= stage k-1 (masked by flush & spec), stage 0 <= the
  //            claimed issue packet (killed at issue by flush & spec)
  // Depth = latency: u_ref `TL_REF_EX, u_gold `TL_REF_EX (flush tied 0), u_dut 3.
  // pred[e] lists the issue sequence numbers engine e must deliver, in order.
  // ---------------------------------------------------------------------------
  localparam int DEPTH [3] = '{`TL_REF_EX, `TL_REF_EX, LAT_DUT};
  logic mv [3][4];
  logic ms [3][4];
  int   mq [3][4];
  int   pred [3][$];
  int   n_claim = 0;
  initial foreach (mv[e, k]) begin mv[e][k] = 1'b0; ms[e][k] = 1'b0; mq[e][k] = -1; end

  always @(posedge clk) begin
    if (rst_n) begin
      logic claim;
      claim = iss_valid && !r_fpx[1];
      for (int e = 0; e < 3; e++) begin
        logic fl;
        int   d;
        fl = (e == 1) ? 1'b0 : flush;
        d  = DEPTH[e];
        if (mv[e][d-1] && !stall) pred[e].push_back(mq[e][d-1]);
        if (stall) begin
          for (int k = 0; k < d; k++) mv[e][k] = mv[e][k] & ~(fl & ms[e][k]);
        end else begin
          for (int k = d - 1; k > 0; k--) begin
            mv[e][k] = mv[e][k-1] & ~(fl & ms[e][k-1]);
            ms[e][k] = ms[e][k-1];
            mq[e][k] = mq[e][k-1];
          end
          mv[e][0] = claim & ~(fl & iss_spec);
          ms[e][0] = iss_spec;
          mq[e][0] = n_claim;
        end
      end
      if (claim && !stall) n_claim++;
    end
  end

  // engine e must deliver exactly the golden payloads of pred[e], in order
  task automatic check_exact(int e, string name);
    if (q_cons[e].size() != pred[e].size()) begin
      $display("ERROR %s: delivered %0d results, occupancy model predicts %0d", name, q_cons[e].size(), pred[e].size());
      errors++;
    end
    for (int i = 0; i < q_cons[e].size() && i < pred[e].size(); i++) begin
      if (pred[e][i] >= q_cons[1].size() || !res_eq(q_cons[e][i], q_cons[1][pred[e][i]])) begin
        if (errors < 10) $display("ERROR %s: result %0d is not the golden result of issue #%0d", name, i, pred[e][i]);
        errors++;
      end else n_cmp++;
    end
  endtask

  // tag = issue sequence number mod 2^TAG_W, so results can be matched in order
  always @(posedge clk) begin
    if (rst_n) begin
      cyc <= cyc + 1;
      if (flush) flush_cycles.push_back(cyc);
      for (int e = 0; e < 3; e++) begin
        if (r_valid[e] && !stall) begin
          q_cons[e].push_back(r_res[e]);
          q_cycle[e].push_back(cyc);
        end
      end
      if (iss_valid && !stall && !r_fpx[1]) begin
        iss_cycle_of_tagseq.push_back(cyc);
        iss_spec_of_seq.push_back(iss_spec);
      end
    end
  end

  // check: engine e's consumed stream is an in-order subsequence of gold
  task automatic check_subsequence(int e, string name);
    int j = 0;
    for (int i = 0; i < q_cons[e].size(); i++) begin
      res_t r = q_cons[e][i];
      // advance over skipped (killed) gold entries
      while (j < q_cons[1].size() && !res_eq(q_cons[1][j], r)) begin
        bit saw_flush = 1'b0;
        if (!q_cons[1][j].spec) begin
          $display("ERROR %s: non-speculative packet #%0d (tag %0d) was dropped", name, j, q_cons[1][j].tag);
          errors++;
        end
        foreach (flush_cycles[f])
          if (flush_cycles[f] >= iss_cycle_of_tagseq[j] && flush_cycles[f] <= q_cycle[e][i]) saw_flush = 1'b1;
        if (!saw_flush) begin
          $display("ERROR %s: packet #%0d dropped without a flush while in flight", name, j);
          errors++;
        end
        j++;
      end
      if (j >= q_cons[1].size()) begin
        $display("ERROR %s: result %0d (tag %0d) does not match any remaining golden result", name, i, r.tag);
        errors++;
        return;
      end
      j++;
      n_cmp++;
    end
  endtask

  int unsigned seed;
  int unsigned cycles;
  int          lat_errors = 0;

  initial begin
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("cycles=%d", cycles)) cycles = 20000;
    void'($urandom(seed));
    rst_n = 1'b0;
    stall = 0; flush = 0; iss_valid = 0; iss_spec = 0; iss_tag = '0; iss_op = '0; iss_bsrc = '0;
    iss_mask_en = 0; iss_mask = '0; iss_vl = '0; iss_mpol = 0; iss_va = '0; iss_vb = '0; iss_vd = '0;
    xlane_b = '0; iss_scalar = '0;
    repeat (3) @(posedge clk);
    #1 rst_n = 1'b1;

    // ---------------- latency probe (no stall, no flush) ----------------
    @(negedge clk);
    iss_valid = 1; iss_spec = 0; iss_op = 6'o00; iss_bsrc = 0; iss_vl = VL_W'(LANES); iss_mask_en = 0;
    iss_tag = TAG_W'(n_issued); n_issued++;
    @(negedge clk);
    iss_valid = 0;
    begin
      int t_ref = -1, t_dut = -1;
      for (int t = 1; t <= 8; t++) begin
        if (r_valid[0] && t_ref < 0) t_ref = t;
        if (r_valid[2] && t_dut < 0) t_dut = t;
        @(negedge clk);
      end
      if (t_ref != `TL_REF_EX || t_dut != LAT_DUT) begin
        $display("ERROR latency: ref=%0d (expect %0d) dut=%0d (expect %0d)", t_ref, `TL_REF_EX, t_dut, LAT_DUT);
        lat_errors++;
      end else begin
        $display("latency: ref=%0d dut=%0d cycles", t_ref, t_dut);
      end
    end

    // ---------------- random phase ----------------
    for (int unsigned c = 0; c < cycles; c++) begin
      @(negedge clk);
      drive_random();
      iss_tag = TAG_W'(n_issued);
      if (iss_valid && !stall) n_issued++;
    end
    // drain
    @(negedge clk);
    iss_valid = 0; stall = 0; flush = 0;
    repeat (12) @(negedge clk);

    // ---------------- checks ----------------
    if (`TL_FLUSH_PCT == 0) begin
      if (q_cons[0].size() != q_cons[2].size()) begin
        $display("ERROR count: ref consumed %0d, dut consumed %0d", q_cons[0].size(), q_cons[2].size());
        errors++;
      end
      for (int i = 0; i < q_cons[0].size() && i < q_cons[2].size(); i++) begin
        if (!res_eq(q_cons[0][i], q_cons[2][i])) begin
          if (errors < 10)
            $display("ERROR mismatch #%0d: ref tag %0d data %h scalar %h | dut tag %0d data %h scalar %h", i,
                     q_cons[0][i].tag, q_cons[0][i].data, q_cons[0][i].scalar,
                     q_cons[2][i].tag, q_cons[2][i].data, q_cons[2][i].scalar);
          errors++;
        end else n_cmp++;
      end
    end else begin
      check_subsequence(0, "u_ref");
      check_subsequence(2, "u_dut");
    end
    // exact flush/kill contract, for the upstream reference (validates the model)
    // and for the pipelined engine; the golden engine must deliver every claim
    if (pred[1].size() != n_claim || q_cons[1].size() != n_claim) begin
      $display("ERROR gold: %0d claims, model %0d, delivered %0d", n_claim, pred[1].size(), q_cons[1].size());
      errors++;
    end
    check_exact(0, "u_ref");
    check_exact(2, "u_dut");
    errors += lat_errors;
    $display("TL-RESULT %s seed=%0d cycles=%0d issued=%0d gold=%0d ref=%0d dut=%0d compared=%0d errors=%0d",
             (errors == 0) ? "PASS" : "FAIL", seed, cycles, n_issued, q_cons[1].size(), q_cons[0].size(),
             q_cons[2].size(), n_cmp, errors);
    $finish;
  end
endmodule
