# =============================================================================
# SilicaFlux TimingLab - common timing reports.
#
# Sourced by flow/sta/sta.tcl (standalone OpenSTA) and flow/openroad/pnr.tcl
# (OpenROAD, which embeds OpenSTA), so every stage produces the same files:
#
#   paths.tsv       machine-readable worst paths, one per endpoint, with every
#                   timing point (pin, direction, cell, arrival, slew). Parsed
#                   by timinglab/parsers/sta.py. OpenSTA 2.5 has no JSON path
#                   report, so this is produced from the Tcl path API.
#   summary.tsv     WNS / TNS / worst slack per corner check and path group
#   paths_max.rpt   human-readable setup report (top paths)
#   paths_min.rpt   human-readable hold report
#   skew.rpt        clock skew (setup / hold)
#   drv.rpt         max slew / cap / fanout violators
#   power.rpt       report_power (default activity; indicative only)
# =============================================================================

proc tl_flags {} {
  # OpenSTA >= 2.6 spells the count options -group_path_count / -endpoint_path_count.
  if {[info exists ::tl_flag_cache]} { return $::tl_flag_cache }
  if {[catch {find_timing_paths -path_delay max -group_path_count 1 -endpoint_path_count 1}]} {
    set ::tl_flag_cache {-group_count -endpoint_count}
  } else {
    set ::tl_flag_cache {-group_path_count -endpoint_path_count}
  }
  return $::tl_flag_cache
}

proc tl_try {args} {
  if {[catch {uplevel 1 $args} err]} { puts "TL-WARN: [lindex $args 0]: $err" }
}

proc tl_pin_cell {pin} {
  # top-level ports have no instance (avoids STA-0321 noise in the logs)
  if {[string first "/" [get_full_name $pin]] < 0} { return "-" }
  if {[catch {set inst [get_cells -of_objects $pin]} err] || $inst eq ""} { return "-" }
  if {[catch {set ref [get_property $inst ref_name]}]} { return "-" }
  return "[get_full_name $inst]:$ref"
}

proc tl_ns {v} {
  # PathEnd methods return SI seconds; reports use ns.
  if {[string is double -strict $v]} { return [format %.6f [expr {$v * 1e9}]] }
  return $v
}

proc tl_dump_paths {file kind count groups} {
  # One record per endpoint (worst path), per path group. kind: max | min
  lassign [tl_flags] gflag eflag
  set fh [open $file a]
  foreach grp $groups {
    set args [list -path_delay $kind $gflag $count $eflag 1 -sort_by_slack]
    if {$grp ne "*"} { lappend args -path_group $grp }
    if {[catch {set ends [find_timing_paths {*}$args]} err]} {
      puts "TL-WARN: find_timing_paths $kind $grp: $err"
      continue
    }
    set rank 0
    foreach pe $ends {
      incr rank
      set sp [get_property $pe startpoint]
      set ep [get_property $pe endpoint]
      set slack [get_property $pe slack]
      set sclk "-"; set eclk "-"
      catch { set sclk [get_name [get_property $pe startpoint_clock]] }
      catch { set eclk [get_name [get_property $pe endpoint_clock]] }
      set arr "-"; set req "-"; set slat "-"; set tlat "-"; set marg "-"
      catch { set arr  [tl_ns [$pe data_arrival_time]] }
      catch { set req  [tl_ns [$pe data_required_time]] }
      catch { set slat [tl_ns [$pe source_clk_latency]] }
      catch { set tlat [tl_ns [$pe target_clk_delay]] }
      catch { set marg [tl_ns [$pe margin]] }
      puts $fh "PATH\t$kind\t$rank\t$grp\t$slack\t[get_full_name $sp]\t[get_full_name $ep]\t$sclk\t$eclk\t$arr\t$req\t$slat\t$tlat\t$marg"
      foreach pt [get_property $pe points] {
        set pin [get_property $pt pin]
        set dir "-"
        catch { set dir [get_property $pin direction] }
        set slew "-"
        catch { set slew [get_property $pt slew] }
        puts $fh "PT\t[get_full_name $pin]\t$dir\t[tl_pin_cell $pin]\t[get_property $pt arrival]\t$slew"
      }
    }
  }
  close $fh
}

proc tl_summary {file} {
  set fh [open $file w]
  foreach kind {max min} {
    # sta::*_cmd return SI seconds
    set ws "-"
    catch { set ws [tl_ns [sta::worst_slack_cmd $kind]] }
    puts $fh "worst_slack\t$kind\t$ws"
    set tns "-"
    catch { set tns [tl_ns [sta::total_negative_slack_cmd $kind]] }
    puts $fh "tns\t$kind\t$tns"
  }
  # per path group worst slack (setup and hold)
  lassign [tl_flags] gflag eflag
  foreach kind {max min} {
    set total 0
    foreach grp {reg2reg in2reg reg2out in2out} {
      if {[catch {set ends [find_timing_paths -path_delay $kind $gflag 1000000 $eflag 1 -path_group $grp]} err]} { continue }
      set w ""; set t 0.0; set n 0
      foreach pe $ends {
        set s [get_property $pe slack]
        if {![string is double -strict $s]} { continue }
        if {$w eq "" || $s < $w} { set w $s }
        if {$s < 0} { set t [expr {$t + $s}]; incr n }
      }
      if {$w eq ""} { set w "-" }
      puts $fh "group\t$kind\t$grp\t$w\t$t\t$n\t[llength $ends]"
      incr total [llength $ends]
    }
    puts $fh "endpoints\t$kind\t$total"
  }
  close $fh
}

proc tl_reports {outdir {npaths 200}} {
  file mkdir $outdir
  lassign [tl_flags] gflag eflag
  set fields {input_pins slew cap fanout}
  report_checks -path_delay max $gflag 20 $eflag 1 -fields $fields -digits 4 > $outdir/paths_max.rpt
  report_checks -path_delay min $gflag 10 $eflag 1 -fields $fields -digits 4 > $outdir/paths_min.rpt
  report_checks -path_delay max $gflag 5 $eflag 1 -format full_clock_expanded -digits 4 > $outdir/paths_max_clock.rpt
  report_checks -unconstrained -path_delay max $gflag 5 -format end > $outdir/unconstrained.rpt
  file delete -force $outdir/paths.tsv
  set groups {reg2reg in2reg reg2out in2out}
  tl_dump_paths $outdir/paths.tsv max $npaths $groups
  tl_dump_paths $outdir/paths.tsv min [expr {$npaths / 4}] $groups
  tl_summary $outdir/summary.tsv
  tl_try report_clock_skew -setup -digits 4 >  $outdir/skew.rpt
  tl_try report_clock_skew -hold  -digits 4 >> $outdir/skew.rpt
  tl_try report_check_types -max_slew -max_capacitance -max_fanout -violators > $outdir/drv.rpt
  tl_try report_power > $outdir/power.rpt
  puts "TL-REPORT: wrote $outdir"
}
