# =============================================================================
# SilicaFlux TimingLab - post-synthesis static timing analysis (OpenSTA).
#
# Environment (set by timinglab/flow/sta.py):
#   TL_FLOW_DIR TL_LIBS TL_NETLIST TL_TOP TL_SDC TL_OUTDIR TL_NPATHS
#   plus the TL_* variables the SDC reads (see constraints/block.sdc).
#
# Wires are ideal and high-fanout nets are not yet buffered at this stage, so
# these numbers are an early screen. The placed / CTS / global-route stages of
# flow/openroad/pnr.tcl are the first physically meaningful ones.
# =============================================================================
source [file join $::env(TL_FLOW_DIR) sta tl_report.tcl]
foreach lib $::env(TL_LIBS) { read_liberty $lib }
read_verilog $::env(TL_NETLIST)
link_design $::env(TL_TOP)
read_sdc $::env(TL_SDC)
set npaths 200
if {[info exists ::env(TL_NPATHS)]} { set npaths $::env(TL_NPATHS) }
tl_reports $::env(TL_OUTDIR) $npaths
exit
