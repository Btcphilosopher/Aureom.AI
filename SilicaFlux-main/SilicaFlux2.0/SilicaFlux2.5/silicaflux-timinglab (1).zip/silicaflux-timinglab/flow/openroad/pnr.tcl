# =============================================================================
# SilicaFlux TimingLab - OpenROAD placement / CTS / global-route experiment.
#
# Purpose: physically meaningful block timing (repaired electrical rules,
# placement- and global-route-based parasitics, propagated clocks with real
# skew) plus routing evidence (layer usage, overflow) for one synthesised
# block. It is a timing EXPERIMENT, not sign-off: no PDN, no detailed route,
# no RC extraction, no hold repair, no setup repair (repair_timing) unless
# TL_REPAIR_TIMING=1. Settings are identical for every design, so before/after
# comparisons isolate the RTL change.
#
# Environment (set by timinglab/flow/pnr.py):
#   TL_FLOW_DIR TL_TECH_LEF TL_SC_LEFS TL_LIBS TL_NETLIST TL_TOP TL_SDC TL_OUTDIR
#   TL_PLATFORM_DIR TL_SITE TL_DIE_SIDE TL_CORE_MARGIN TL_DENSITY TL_IO_H TL_IO_V
#   TL_MIN_LAYER TL_MAX_LAYER TL_MAKE_TRACKS TL_SET_RC TL_TAPCELL TL_DONT_USE
#   TL_GRT_ADJ TL_REPAIR_TIMING TL_NPATHS
# =============================================================================
source [file join $::env(TL_FLOW_DIR) sta tl_report.tcl]

proc env_or {k d} { if {[info exists ::env($k)] && $::env($k) ne ""} { return $::env($k) }; return $d }
proc tl_to_file {path args} {
  sta::redirect_file_begin $path
  if {[catch {uplevel 1 $args} err]} { puts "TL-WARN: [lindex $args 0]: $err" }
  sta::redirect_file_end
}
proc tl_stage {name} { puts "TL-STAGE: $name [clock format [clock seconds] -format %H:%M:%S]" }

set out $::env(TL_OUTDIR)
file mkdir $out
set npaths [env_or TL_NPATHS 200]

read_lef $::env(TL_TECH_LEF)
foreach l $::env(TL_SC_LEFS) { read_lef $l }
foreach l $::env(TL_LIBS)    { read_liberty $l }
read_verilog $::env(TL_NETLIST)
link_design $::env(TL_TOP)
read_sdc $::env(TL_SDC)
if {[env_or TL_SET_RC ""] ne ""} { source $::env(TL_SET_RC) }
foreach pat [env_or TL_DONT_USE ""] {
  set cells [get_lib_cells -quiet $pat]
  if {[llength $cells]} { set_dont_use $cells }
}

# Clock-root fix. Yosys `insbuf` turns the context wrapper's net alias
# clk_i -> u_dut.clk_i into a buffer cell. Left in place it sits at the clock
# root, and on libraries whose generic buffers double as clock buffers
# TritonCTS then skips the clock net (observed on ihp-sg13g2: "found 0 clock
# nets", i.e. no clock tree). Only buffers of the PDK's insbuf cell that are
# driven directly by the clock port are removed (loads reconnected to the
# clock net); all other synthesis / ABC buffers are kept, since this flow does
# not run repair_timing to restore them.
proc tl_unbuffer_clock {port bufcell} {
  set block [ord::get_db_block]
  set cnet [$block findNet $port]
  if {$cnet eq "NULL" || $cnet eq ""} { return 0 }
  set victims {}
  foreach it [$cnet getITerms] {
    set inst [$it getInst]
    if {[[$inst getMaster] getName] eq $bufcell && [$it isInputSignal]} { lappend victims $inst }
  }
  foreach inst $victims {
    foreach ot [$inst getITerms] {
      if {![$ot isOutputSignal]} { continue }
      set onet [$ot getNet]
      if {$onet eq "NULL" || $onet eq ""} { continue }
      set loads {}
      foreach lt [$onet getITerms] { if {[$lt getInst] ne $inst} { lappend loads $lt } }
      $ot disconnect
      foreach lt $loads { $lt disconnect; $lt connect $cnet }
      if {[llength [$onet getBTerms]] == 0} { odb::dbNet_destroy $onet }
    }
    foreach it [$inst getITerms] { $it disconnect }
    odb::dbInst_destroy $inst
  }
  return [llength $victims]
}
puts "TL-CLOCK-ROOT: removed [tl_unbuffer_clock $::env(TL_CLOCK_PORT) $::env(TL_MIN_BUF_CELL)] synthesis buffer(s) on $::env(TL_CLOCK_PORT)"

# ---------------------------------------------------------------- floorplan
tl_stage floorplan
set side $::env(TL_DIE_SIDE)
set m    $::env(TL_CORE_MARGIN)
initialize_floorplan -die_area [list 0 0 $side $side] \
                     -core_area [list $m $m [expr {$side - $m}] [expr {$side - $m}]] \
                     -site $::env(TL_SITE)
if {[env_or TL_MAKE_TRACKS ""] ne ""} { source $::env(TL_MAKE_TRACKS) } else { make_tracks }
if {[env_or TL_TAPCELL ""] ne ""} { source $::env(TL_TAPCELL) }
set_routing_layers -signal $::env(TL_MIN_LAYER)-$::env(TL_MAX_LAYER) \
                   -clock  $::env(TL_MIN_LAYER)-$::env(TL_MAX_LAYER)
set_global_routing_layer_adjustment $::env(TL_MIN_LAYER)-$::env(TL_MAX_LAYER) [env_or TL_GRT_ADJ 0.3]
place_pins -hor_layers $::env(TL_IO_H) -ver_layers $::env(TL_IO_V) -random -random_seed 42 \
           -min_distance 1 -min_distance_in_tracks
tl_to_file $out/floorplan_area.rpt report_design_area

# ---------------------------------------------------------------- placement
tl_stage global_placement
global_placement -density $::env(TL_DENSITY) -skip_io
place_pins -hor_layers $::env(TL_IO_H) -ver_layers $::env(TL_IO_V) -min_distance 1 -min_distance_in_tracks
global_placement -density $::env(TL_DENSITY)
estimate_parasitics -placement
tl_stage repair_design
repair_design
if {[env_or TL_REPAIR_TIMING 0]} { repair_timing -setup }
tl_stage detailed_placement
detailed_placement
check_placement -verbose
estimate_parasitics -placement
tl_to_file $out/area_place.rpt report_design_area
tl_reports $out/place $npaths

# ---------------------------------------------------------------- clock tree
tl_stage cts
clock_tree_synthesis -sink_clustering_enable
set_propagated_clock [all_clocks]
estimate_parasitics -placement
repair_design
detailed_placement
estimate_parasitics -placement
tl_to_file $out/cts.rpt report_cts
tl_reports $out/cts $npaths

# ---------------------------------------------------------------- global route
tl_stage global_route
# bounded rip-up-and-reroute effort: congestion is reported, not optimised away
global_route -congestion_report_file $out/congestion.rpt -allow_congestion -verbose \
             -congestion_iterations [env_or TL_GRT_ITERS 10]
estimate_parasitics -global_routing
tl_to_file $out/area_grt.rpt report_design_area
tl_reports $out/grt $npaths

# instance locations of the cells on the worst reg2reg paths (congestion correlation)
set fh [open $out/path_cells_xy.tsv w]
lassign [tl_flags] gflag eflag
set block [ord::get_db_block]
set dbu [[ord::get_db_tech] getDbUnitsPerMicron]
foreach pe [find_timing_paths -path_delay max $gflag 20 $eflag 1 -path_group reg2reg -sort_by_slack] {
  set ep [get_full_name [get_property $pe endpoint]]
  foreach pt [get_property $pe points] {
    set pin [get_property $pt pin]
    if {[catch {set inst [get_cells -of_objects $pin]}] || $inst eq ""} { continue }
    set n [get_full_name $inst]
    set dbi [$block findInst $n]
    if {$dbi eq "NULL" || $dbi eq ""} { continue }
    set bb [$dbi getBBox]
    puts $fh "$ep\t$n\t[expr {double([$bb xMin]) / $dbu}]\t[expr {double([$bb yMin]) / $dbu}]"
  }
}
close $fh
write_def $out/grt.def
puts "TL-PNR: done"
exit
