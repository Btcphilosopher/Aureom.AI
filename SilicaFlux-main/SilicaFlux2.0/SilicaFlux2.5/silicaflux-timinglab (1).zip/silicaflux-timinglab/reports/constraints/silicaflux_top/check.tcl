read_verilog reports/constraints/silicaflux_top/stub.v
link_design silicaflux_top
read_sdc constraints/silicaflux_top.sdc
report_clock_properties
puts TL-SDC-DONE
exit
