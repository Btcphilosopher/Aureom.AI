# Sample reports

Outputs of the run documented in `docs/RESULTS.md`, produced in this order by
`make all` (or the individual `python -m timinglab` commands):

| directory | produced by | contents |
|---|---|---|
| `discovery/` | `discover` | `discovery.json` (inventory, definitions, compile matrix, testbench checks, clock/reset view), `inventory.csv`, dependency graphs (`sf2_rtl_graph.svg` compact, `sf2_dependency_graph.svg` full incl. testbenches, `sf1_dependency_graph.svg` for v1.0) |
| `audit/<design>/` | `audit` | `rtl_audit.json` (hypotheses, register ranking, endpoints, fanout, arithmetic, muxes, CDC/RDC), Yosys scripts / logs / stats |
| `confirm/` | `confirm` | `<design>@<pdk>.json`: audit hypotheses vs. STA |
| `runs/<pdk>/<design>/` | `run` (copied by `scripts/package.py`) | `result.json` (slimmed), scripts (`elab*.ys`, `synth.ys`, generated wrapper `src/zz_tl_wrap.sv`), `synth_stat.txt`, `pnr.log`, and per stage (`sta_synth`, `pnr/place`, `pnr/cts`, `pnr/grt`) the OpenSTA reports `summary.tsv`, `paths_max.rpt`, `paths_min.rpt`, `paths_max_clock.rpt`, `skew.rpt`, `drv.rpt`, `power.rpt` |
| `verification/` | `lint`, `equiv`, `mutation` | `lint.json`, `equiv.json` (+ simulation logs), `mutation.json` |
| `formal/` | `formal` | `formal.json`, per check `prove.ys` / `prove.log` |
| `constraints/` | `sdc` | `constraints.json` (SDC lint, cluster SDC stub check), stub netlist and OpenSTA log |
| `dashboard/` | `report` | `dashboard.html`, `timinglab_results.json`, `summary.csv`, `critical_paths.csv`, `comparisons.csv`, `audit_candidates.csv`, `audit_calibration.csv` |
| `regression/` | `accept` | `acceptance.json`: the seven gates per optimisation |

`python -m timinglab report` regenerates `dashboard/` from these files even without the
full `runs/` directory (it falls back to `reports/runs/`).
