#!/usr/bin/env python3
"""Build the distributable zip.

* copies the key per-run reports from runs/ into reports/runs/<pdk>/<design>/
  (slimmed result.json, final-stage text reports, synthesis stats, scripts,
  logs) so the sample reports travel without the multi-GB run directories;
* zips the project without runs/, .cache/, third_party/, simulator build
  directories and other regenerable intermediates; paths recorded in reports/ are
  rewritten relative to the project root.
Usage: scripts/package.py [output.zip]
"""
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUNS = ROOT / "runs"
OUT_RUNS = ROOT / "reports" / "runs"

KEEP_RUN_FILES = ["sources.json", "elab.ys", "elab_wrap.ys", "synth.ys", "abc.constr", "synth_stat.txt",
                  "generic_stat.txt", "sta_env.json", "pnr_env.json", "pnr.log", "sta.log", "elab_wrap.log",
                  "elab.log", "src/zz_tl_wrap.sv"]
KEEP_STAGE_FILES = ["summary.tsv", "paths_max.rpt", "paths_min.rpt", "paths_max_clock.rpt", "skew.rpt", "drv.rpt",
                    "power.rpt", "unconstrained.rpt"]


def slim_result(r: dict) -> dict:
    def slim_timing(t: dict) -> dict:
        if not t:
            return t
        t = dict(t)
        paths = []
        for i, p in enumerate(t.get("paths", [])[:40]):
            p = dict(p)
            p["derived"] = {k: v for k, v in p.get("derived", {}).items() if k != "cells"}
            if i >= 5:
                p.pop("points", None)
            paths.append(p)
        t["paths"] = paths
        t["hold_paths"] = t.get("hold_paths", [])[:10]
        return t
    r = json.loads(json.dumps(r))
    st = r.get("stages", {})
    if "sta" in st and "timing" in st["sta"]:
        st["sta"]["timing"] = slim_timing(st["sta"]["timing"])
    pnr = st.get("pnr", {})
    for k, v in list(pnr.get("timing", {}).items()):
        pnr["timing"][k] = slim_timing(v)
    if "path_cells_xy" in pnr:
        pnr["path_cells_xy"] = pnr["path_cells_xy"][:200]
    if "elab" in st:
        st["elab"]["warnings"] = st["elab"].get("warnings", [])[:20]
    return r


def collect_runs() -> int:
    if OUT_RUNS.exists():
        shutil.rmtree(OUT_RUNS)
    n = 0
    for pdk in sorted(p for p in RUNS.iterdir() if p.is_dir() and not p.name.startswith("_")):
        for rd in sorted(p for p in pdk.iterdir() if p.is_dir()):
            if not (rd / "result.json").exists():
                continue
            dst = OUT_RUNS / pdk.name / rd.name
            dst.mkdir(parents=True)
            r = json.loads((rd / "result.json").read_text())
            (dst / "result.json").write_text(json.dumps(slim_result(r), indent=1))
            for f in KEEP_RUN_FILES:
                if (rd / f).exists():
                    (dst / f).parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy(rd / f, dst / f)
            for st in ("sta_synth", "pnr/place", "pnr/cts", "pnr/grt"):
                for f in KEEP_STAGE_FILES:
                    if (rd / st / f).exists():
                        (dst / st).mkdir(parents=True, exist_ok=True)
                        shutil.copy(rd / st / f, dst / st / f)
            if (rd / "pnr" / "congestion.rpt").exists():
                shutil.copy(rd / "pnr" / "congestion.rpt", dst / "pnr" / "congestion.rpt")
            n += 1
    return n


EXCLUDE_DIRS = {"runs", ".cache", "third_party", "__pycache__", ".pytest_cache", ".git"}


def excluded(rel: Path) -> bool:
    parts = rel.parts
    if parts[0] in EXCLUDE_DIRS or any(p in EXCLUDE_DIRS - {"runs"} for p in parts):
        return True                     # top-level runs/ only: reports/runs/ is the slim copy
    s = str(rel)
    if s.startswith("reports/verification/") and ("/obj" in s or "/src/" in s or "/mutants/" in s):
        return True
    if s.startswith("reports/audit/") and rel.suffix == ".json" and rel.name in ("gates.json", "coarse.json"):
        return True
    if s.startswith("reports/audit/") and ("/src/" in s or rel.suffix == ".il"):
        return True
    if s.startswith("reports/formal/") and (rel.suffix == ".il" or "/src/" in s):
        return True
    return False


TEXT_SUFFIXES = {".json", ".log", ".csv", ".html", ".txt", ".rpt", ".md", ".tsv", ".ys", ".tcl", ".sdc", ".out",
                 ".stdout", ".sv", ".v", ".dot", ".svg"}


def main() -> None:
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / "silicaflux-timinglab.zip"
    n = collect_runs()
    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(ROOT.rglob("*")):
            rel = p.relative_to(ROOT)
            if p.is_dir() or p.is_symlink() or excluded(rel):
                continue
            arc = Path("silicaflux-timinglab") / rel
            if rel.parts[0] == "reports" and p.suffix in TEXT_SUFFIXES:
                # make recorded paths relative to the project root (portable reports)
                text = p.read_text(errors="surrogateescape")
                text = text.replace(str(ROOT) + "/", "").replace(str(ROOT), ".")
                z.writestr(str(arc), text.encode(errors="surrogateescape"))
            else:
                z.write(p, arc)
            count += 1
    print(f"{n} runs collected, {count} files -> {out} ({out.stat().st_size / 1e6:.1f} MB)")


if __name__ == "__main__":
    main()
