#!/usr/bin/env python3
"""Run the full TimingLab flow for every design in flow/designs.toml on the
given PDKs (default: all), resuming finished runs. Usage:
    scripts/batch.py [--pdk sky130hd ...] [--design name ...] [--jobs N]"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from timinglab import config  # noqa: E402
from timinglab.flow import runner  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--pdk", nargs="*")
ap.add_argument("--design", nargs="*")
ap.add_argument("--jobs", type=int, default=3)
ap.add_argument("--no-resume", action="store_true")
ap.add_argument("--stages", nargs="*", default=["elab", "synth", "sta", "pnr"])
a = ap.parse_args()
cat = config.load()
pdks = a.pdk or cat.defaults.get("pdks", list(cat.pdks))
designs = a.design or list(cat.designs)
runner.run_many(cat, designs, pdks, tuple(a.stages), jobs=a.jobs, resume=not a.no_resume)
