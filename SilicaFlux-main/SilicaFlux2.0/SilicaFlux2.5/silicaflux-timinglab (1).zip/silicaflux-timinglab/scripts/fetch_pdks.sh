#!/usr/bin/env bash
# Download the public PDK platform files TimingLab uses (Liberty, LEF, RC, tracks,
# tapcell) for SKY130HD, GF180MCU (9t, 5LM_1TM) and IHP SG13G2 from
# OpenROAD-flow-scripts (Apache-2.0). Individual files are fetched from
# raw.githubusercontent.com, so no git clone is needed (~45 MB).
set -euo pipefail
DEST="${1:-$(cd "$(dirname "$0")/.." && pwd)/third_party/platforms}"
REF="${ORFS_REF:-master}"
BASE="https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/$REF/flow/platforms"
FILES=(
  sky130hd/config.mk sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib sky130hd/lef/sky130_fd_sc_hd.tlef
  sky130hd/lef/sky130_fd_sc_hd_merged.lef sky130hd/setRC.tcl sky130hd/make_tracks.tcl sky130hd/tapcell.tcl
  gf180/config.mk gf180/lib/gf180mcu_fd_sc_mcu9t5v0__tt_025C_5v00.lib.gz gf180/lef/gf180mcu_5LM_1TM_9K_9t_tech.lef
  gf180/lef/gf180mcu_5LM_1TM_9K_9t_sc.lef gf180/setRC.tcl gf180/openROAD/tapcell.tcl
  ihp-sg13g2/config.mk ihp-sg13g2/lib/sg13g2_stdcell_typ_1p20V_25C.lib ihp-sg13g2/lef/sg13g2_tech.lef
  ihp-sg13g2/lef/sg13g2_stdcell.lef ihp-sg13g2/setRC.tcl ihp-sg13g2/make_tracks.tcl ihp-sg13g2/tapcell.tcl
)
for f in "${FILES[@]}"; do
  mkdir -p "$DEST/$(dirname "$f")"
  [[ -s "$DEST/$f" ]] || curl -sSfL "$BASE/$f" -o "$DEST/$f"
  echo "ok $f"
done
echo "PDK platform files in $DEST  (export TL_PLATFORMS=$DEST)"
