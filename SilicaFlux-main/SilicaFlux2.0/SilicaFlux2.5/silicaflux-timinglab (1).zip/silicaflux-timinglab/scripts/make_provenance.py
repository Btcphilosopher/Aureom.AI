#!/usr/bin/env python3
"""Write upstream/PROVENANCE.md: every file of the upstream snapshot with its
SHA-256 and the repository path it was copied from."""
import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UP = ROOT / "upstream"
repo = Path(sys.argv[1]) if len(sys.argv) > 1 else None
commit = ""
if repo:
    try:
        commit = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True,
                                text=True).stdout.strip()
    except Exception:
        pass
rows = []
for p in sorted(UP.rglob("*")):
    if p.is_file() and p.name != "PROVENANCE.md":
        rel = p.relative_to(UP)
        sha = hashlib.sha256(p.read_bytes()).hexdigest()
        same = ""
        if repo and (repo / rel).exists():
            same = "identical" if hashlib.sha256((repo / rel).read_bytes()).hexdigest() == sha else "DIFFERS"
        rows.append(f"| `{rel}` | `{sha}` | {p.stat().st_size} | {same} |")
txt = f"""# Upstream snapshot provenance

The files under `upstream/` are byte-identical copies of the SilicaFlux RTL used by
TimingLab, taken from the Aureom.AI repository{f' at commit `{commit}`' if commit else ''}.
Paths are relative to the repository root, so `TL_SF_ROOT` may point at a real checkout
instead of this snapshot. TimingLab never modifies these files; optimised variants live in
`rtl/opt/` and state their upstream origin in their headers.

| file | sha256 | bytes | vs. repository |
|---|---|---|---|
""" + "\n".join(rows) + "\n"
(UP / "PROVENANCE.md").write_text(txt)
print(f"{len(rows)} files")
