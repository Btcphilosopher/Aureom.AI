#!/usr/bin/env bash
# Install the open-source tools TimingLab drives (Linux x86_64). The versions
# used for reports/ are listed in docs/TOOLING.md. Everything goes to $PREFIX
# (default /opt/tl); no system packages are modified except via pip.
set -euo pipefail
PREFIX="${PREFIX:-/opt/tl}"
mkdir -p "$PREFIX"
python3 -m pip install --upgrade "pyslang>=7" yowasp-yosys pytest     # SV front-end, Yosys+slang, tests
cd "$PREFIX"
if [[ ! -x bin/micromamba ]]; then
  curl -sSL https://conda.anaconda.org/conda-forge/linux-64/micromamba-2.10.0-0.tar.bz2 | tar -xj bin/micromamba
fi
export MAMBA_ROOT_PREFIX="$PREFIX/mamba"
# native Yosys (technology mapping), Verilator, Icarus, Graphviz
[[ -x eda-cf/bin/yosys ]] || bin/micromamba create -y -p "$PREFIX/eda-cf" -c conda-forge \
    "yosys=0.69" "verilator=5.054" "iverilog=13_0" graphviz
# OpenROAD (embeds OpenSTA; also ships the standalone `sta` binary)
[[ -x eda-or/bin/openroad ]] || bin/micromamba create -y -p "$PREFIX/eda-or" -c litex-hub -c anaconda -c conda-forge \
    "openroad=2.0_12381_g01bba3695" "python=3.10"
cat <<MSG
Done. TimingLab looks in $PREFIX/eda-cf/bin and $PREFIX/eda-or/bin automatically when PREFIX=/opt/tl;
otherwise export TL_YOSYS=$PREFIX/eda-cf/bin/yosys TL_STA=$PREFIX/eda-or/bin/sta \\
                  TL_OPENROAD=$PREFIX/eda-or/bin/openroad TL_VERILATOR=$PREFIX/eda-cf/bin/verilator
Verilator from conda builds simulators with the system g++ (TimingLab passes CXX=g++).
MSG
