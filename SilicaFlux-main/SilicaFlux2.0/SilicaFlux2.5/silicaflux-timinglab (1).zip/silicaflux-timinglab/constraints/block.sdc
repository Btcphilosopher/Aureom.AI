# =============================================================================
# SilicaFlux TimingLab - block-level timing constraints (all elaborable blocks)
#
# Parameterised through environment variables so one reviewed file serves every
# block and PDK (timinglab/flow/sta.py sets them from flow/designs.toml and
# flow/pdk/<pdk>.toml; they are echoed into each run's sta_env.json):
#
#   TL_CLOCK_PORT   clock input port (every SilicaFlux 2.x block: clk_i)
#   TL_RESET_PORT   active-low asynchronous reset (rst_ni)
#   TL_PERIOD       clock period [ns]
#   TL_UNC_SETUP    setup uncertainty [ns]  (jitter + pre-CTS skew allowance)
#   TL_UNC_HOLD     hold uncertainty [ns]
#   TL_CLK_SLEW     ideal clock transition before CTS [ns]
#   TL_IO_FRAC      fraction of the period consumed outside the block on every
#                   input and every output (block-to-block budget)
#   TL_DRIVER_CELL / TL_DRIVER_PIN / TL_LOAD_PF   I/O electrical environment
#
# Exceptions: NONE.  No false path and no multicycle path is applied to any
# SilicaFlux 2.x block (see docs/CONSTRAINTS.md for the evidence review):
#   * rst_ni is not a false path. In the 2.5 cluster (silicaflux_top.sf
#     lines 563-586, 853-861) every block reset is either a flop output in the
#     clk_core_i domain or the output of the sf_rst_sync reset synchroniser,
#     so de-assertion is synchronous to the block clock and recovery/removal
#     must be met. It is therefore given the same input budget as data.
#   * No functional evidence (source contract, assertion or proof) was found
#     that any block register is enabled at most every N>1 cycles, so no
#     multicycle path is justified.
# =============================================================================

proc tl_env {name default} {
  if {[info exists ::env($name)] && $::env($name) ne ""} { return $::env($name) }
  return $default
}

set tl_clk_port [tl_env TL_CLOCK_PORT clk_i]
set tl_period   [tl_env TL_PERIOD 10.0]
set tl_io_frac  [tl_env TL_IO_FRAC 0.30]

create_clock -name core_clk -period $tl_period [get_ports $tl_clk_port]
set_clock_uncertainty -setup [tl_env TL_UNC_SETUP 0.25] [get_clocks core_clk]
set_clock_uncertainty -hold  [tl_env TL_UNC_HOLD 0.05]  [get_clocks core_clk]
set_clock_transition [tl_env TL_CLK_SLEW 0.15] [get_clocks core_clk]

set tl_inputs [delete_from_list [all_inputs] [get_ports $tl_clk_port]]
set tl_io_delay [expr {$tl_io_frac * $tl_period}]
set_input_delay  -max $tl_io_delay -clock core_clk $tl_inputs
set_input_delay  -min 0.0          -clock core_clk $tl_inputs
set_output_delay -max $tl_io_delay -clock core_clk [all_outputs]
set_output_delay -min 0.0          -clock core_clk [all_outputs]

if {[tl_env TL_DRIVER_CELL ""] ne ""} {
  set_driving_cell -lib_cell $::env(TL_DRIVER_CELL) -pin [tl_env TL_DRIVER_PIN X] $tl_inputs
}
set_load [tl_env TL_LOAD_PF 0.01] [all_outputs]

# Path groups: reg2reg is the subject of every before/after comparison;
# I/O groups are reported separately because their budget is an assumption.
group_path -name reg2reg -from [all_registers] -to [all_registers]
group_path -name in2reg  -from $tl_inputs      -to [all_registers]
group_path -name reg2out -from [all_registers] -to [all_outputs]
group_path -name in2out  -from $tl_inputs      -to [all_outputs]
