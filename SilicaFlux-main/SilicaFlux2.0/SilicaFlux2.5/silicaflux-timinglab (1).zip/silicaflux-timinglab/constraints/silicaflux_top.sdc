# =============================================================================
# SilicaFlux TimingLab - cluster-level constraints for
#   SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf
#
# STATUS: example / ready-to-apply. silicaflux_top.sf does NOT elaborate in
# this repository (27 instantiated modules are missing, see
# docs/DISCOVERY.md), so this file cannot be timed. It is checked by
# `python -m timinglab sdc-check` against a port/instance stub generated from
# the source, which proves every object referenced below exists with the
# given name in silicaflux_top.sf.
#
# Every timing exception carries a "JUSTIFY:" line citing the source evidence
# (enforced by timinglab/sdc_lint.py). Clock periods are design targets, not
# library data: set them per PDK with the TL_* variables below.
# =============================================================================
proc tl_env {name default} {
  if {[info exists ::env($name)] && $::env($name) ne ""} { return $::env($name) }
  return $default
}
set T_CORE [tl_env TL_T_CORE 10.0]   ;# clk_core_i  : cores, coherent fabric, LLC, control plane
set T_MEM  [tl_env TL_T_MEM  10.0]   ;# clk_mem_i   : memory AXI master edge, DMA AXI slave edge
set T_HOST [tl_env TL_T_HOST 20.0]   ;# clk_host_i  : host APB control interface
set T_RTC  [tl_env TL_T_RTC  30517.578] ;# clk_rtc_i : architectural timer reference (32.768 kHz)
set T_TCK  [tl_env TL_T_TCK  100.0]  ;# jtag_tck_i  : debug transport (10 MHz)
set UNC    [tl_env TL_UNC_FRAC 0.03] ;# setup uncertainty as a fraction of each period
set IOF    [tl_env TL_IO_FRAC 0.40]  ;# off-chip budget fraction of each interface period

# ---------------------------------------------------------------- primary clocks
# silicaflux_top.sf lines 18-23 (domain list) and 76-79 (ports)
create_clock -name clk_core -period $T_CORE [get_ports clk_core_i]
create_clock -name clk_mem  -period $T_MEM  [get_ports clk_mem_i]
create_clock -name clk_host -period $T_HOST [get_ports clk_host_i]
create_clock -name clk_rtc  -period $T_RTC  [get_ports clk_rtc_i]
create_clock -name jtag_tck -period $T_TCK  [get_ports jtag_tck_i]

# ---------------------------------------------------------------- generated (gated) clocks
# u_clk_ctrl (sf_clk_ctrl, lines 618-635) gates clk_core_i per core, per
# vector complex, per LLC bank and for the tensor engine. Clock gating does not
# change frequency: divide_by 1, master clk_core.
foreach {name pin} {gclk_core core_clk_o gclk_vpu vpu_clk_o gclk_llc llc_clk_o gclk_tns tns_clk_o} {
  create_generated_clock -name $name -source [get_ports clk_core_i] -divide_by 1 \
      [get_pins u_clk_ctrl/$pin*]
}

foreach c [all_clocks] {
  set p [get_property $c period]
  set_clock_uncertainty -setup [expr {$UNC * $p}] $c
  set_clock_uncertainty -hold  [expr {0.01 * $p}] $c
}

# ---------------------------------------------------------------- clock groups
# JUSTIFY: silicaflux_top.sf lines 25-26: "All crossings are owned by
# dedicated CDC primitives (sf_sync, sf_rst_sync, sf_axi_cdc, sf_apb_cdc)".
# The four primary functional clocks and TCK are mutually asynchronous.
# CAVEAT: sf_axi_cdc / sf_apb_cdc / sf_sync are missing from the repository,
# so this contract is NOT yet verified structurally; re-run a CDC check
# (timinglab audit reports clock nets per block) when they are added.
set_clock_groups -asynchronous -name tl_async \
    -group [get_clocks {clk_core gclk_core gclk_vpu gclk_llc gclk_tns}] \
    -group [get_clocks clk_mem] -group [get_clocks clk_host] \
    -group [get_clocks clk_rtc] -group [get_clocks jtag_tck]

# ---------------------------------------------------------------- functional mode
# JUSTIFY: test_mode_i / scan_en_i are DFT controls (lines 83-85); this is the
# functional-mode constraint set, so both are held at 0 (clock-gate bypass and
# reset muxes at lines 574, 861 select the functional path).
set_case_analysis 0 [get_ports test_mode_i]
set_case_analysis 0 [get_ports scan_en_i]

# ---------------------------------------------------------------- asynchronous inputs
# JUSTIFY: por_rst_ni / sys_rst_ni enter u_rst_ctrl (sf_rst_ctrl, lines
# 542-560), which receives every domain clock and produces per-domain
# synchronised resets; assertion is asynchronous by design.
set_false_path -from [get_ports {por_rst_ni sys_rst_ni jtag_trst_ni}]
# JUSTIFY: ext_irq_i, cluster_en_i and dbg_ext_halt_i are re-timed by
# SYNC_STAGES-deep sf_sync synchronisers u_ext_irq_sync / u_ctrl_in_sync
# (lines 638-656) before any use.
set_false_path -from [get_ports {ext_irq_i* cluster_en_i dbg_ext_halt_i}]
# JUSTIFY: straps are "quasi-static and captured in reset" (line 26, port
# group comment line 86): cluster_id_i, boot_core_mask_i, boot_addr_i,
# boot_addr_ovr_i do not change while the cluster is out of reset.
set_false_path -from [get_ports {cluster_id_i* boot_core_mask_i* boot_addr_i* boot_addr_ovr_i}]

# ---------------------------------------------------------------- external interfaces
proc tl_io {clk period in_ports out_ports frac} {
  set d [expr {$frac * $period}]
  if {[llength $in_ports]}  { set_input_delay  -max $d -clock $clk $in_ports
                              set_input_delay  -min 0.0 -clock $clk $in_ports }
  if {[llength $out_ports]} { set_output_delay -max $d -clock $clk $out_ports
                              set_output_delay -min 0.0 -clock $clk $out_ports }
}
# memory AXI master + DMA AXI slave: clk_mem_i domain (lines 92-97)
tl_io clk_mem  $T_MEM  [get_ports {mem_axi_rsp_i* dma_axi_req_i*}] [get_ports {mem_axi_req_o* dma_axi_rsp_o*}] $IOF
# host control APB: clk_host_i domain (lines 98-100)
tl_io clk_host $T_HOST [get_ports host_apb_req_i*] [get_ports host_apb_rsp_o*] $IOF
# trace egress and status / telemetry: clk_core_i domain (lines 114-124)
tl_io clk_core $T_CORE [get_ports trace_ready_i] \
      [get_ports {trace_valid_o trace_pkt_o* fault_status_o* cluster_ready_o cluster_quiesced_o
                  cluster_contained_o core_active_o* host_irq_o fault_irq_o dbg_halted_o}] $IOF
# JTAG (IEEE 1149.1): TDI/TMS sampled on rising TCK, TDO launched on falling TCK
set_input_delay  -max [expr {0.25 * $T_TCK}] -clock jtag_tck [get_ports {jtag_tms_i jtag_tdi_i}]
set_input_delay  -min 0.0                    -clock jtag_tck [get_ports {jtag_tms_i jtag_tdi_i}]
set_output_delay -max [expr {0.25 * $T_TCK}] -clock jtag_tck -clock_fall [get_ports {jtag_tdo_o jtag_tdo_oe_o}]
set_output_delay -min 0.0                    -clock jtag_tck -clock_fall [get_ports {jtag_tdo_o jtag_tdo_oe_o}]

# ---------------------------------------------------------------- multicycle paths
# None. No source contract, assertion or proof in silicaflux_top.sf establishes
# a register that is enabled at most every N > 1 cycles of its clock.
