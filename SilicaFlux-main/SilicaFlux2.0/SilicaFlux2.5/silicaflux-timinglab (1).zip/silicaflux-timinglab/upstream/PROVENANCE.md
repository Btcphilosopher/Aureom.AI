# Upstream snapshot provenance

The files under `upstream/` are byte-identical copies of the SilicaFlux RTL used by
TimingLab, taken from the Aureom.AI repository at commit `36e0280036a3e353443cb2e775ff37a243f2ccb9`.
Paths are relative to the repository root, so `TL_SF_ROOT` may point at a real checkout
instead of this snapshot. TimingLab never modifies these files; optimised variants live in
`rtl/opt/` and state their upstream origin in their headers.

| file | sha256 | bytes | vs. repository |
|---|---|---|---|
| `SilicaFlux-main/README.md` | `efc239d9a78f477637b477fc6039870f3478c298fdb9108bbbc60e645ff6d696` | 12534 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/alu (1).sf` | `000b00f3788b28488c7097e1c22433fc8d09bcf31d7732f5fb2e78edc422a8d8` | 25046 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/compute_tile.sf` | `f6ee50b7965cccb1d35403f031c85215bb4b6cd485a7a9e9e996f1a91081f431` | 83148 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/dot_product_parallel (1).sfx` | `48812bc888bd83c0f33e404f6cd2e33fa671bec1cc5814705d2ba566828724e1` | 1566 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/dot_product_parallel.sfx` | `c9e6d012ed73567fc1b181341b3b53dd2d6cb20463d504ead9d3e0103b1a29a4` | 1626 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/fibonacci.sfx` | `24d4ecae7dbb6f6d338323184a392e999908eaaec562d79278c90369aedc74ec` | 1015 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/forwarding_unit (1).sf` | `7d5614eb991fd45bf8bf41ed110b97596a18a6be4c82d15b2d910320aa004bf0` | 23065 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/forwarding_unit.sf` | `a8472f84a9da5649b6756022166168cc3f34beffaadd66f93f2c1b606440cc59` | 23738 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/forwarding_unit.zip` | `5edd854fd80172e337d0236383530e5ed6b8d6fc728e3b3448f09c2bf2eca0be` | 8070 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/matmul_4x4.sfx` | `9349ada9685861c51ab39a2fc998a634979003fcb39f5aceacba4f85feda6ec3` | 4694 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/memory_controller.sf` | `76616365e7bb9e99fb235de08461922dcbe2ddc4ce22cbb20151574da5330dd5` | 60114 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/noc_interconnect.sf` | `f6c09b144aef77d999ce657e903f192acf5a6ae7e3a5e85290aa0ce91550c684` | 45708 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/register_bank.sf` | `6cd8dc5f0895d3b0a72bdecb5354ea640a0cb26bba58ff6ff0efd9d82be3bb6f` | 39751 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/run_sim.sh` | `bd58f46a663a9ba72fdf7d6e24e8b0acb83fd426be9ff90d179dec1d225a38c5` | 48960 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/scheduler.sf` | `de5cb9a9e1bcc3992e5bb739f871666221213c4a4b7eb5d67170a299675193f3` | 54764 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/sfx_asm.py` | `583f50ba8b92502c71e2f2730d4d1e76945329b7604cc202463c304bf5903fce` | 136644 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_alu.zip` | `e67c87ea28710652815c5acd786a039654e701f917a3be0abb040f8dc1fffbab` | 6960 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_pkg (1).sf` | `5db1081271f408f64ce555b73f4e2f0cb7e6c576702088d5c079b3d0068fbcfa` | 5440 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_rtl2.zip` | `6ed6bbd6ed9e24b09c4605a9fa2afd45fb01ff226d4ce98636d702b63fa5b3d7` | 43011 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf` | `39855c959903a5a6933c64f7a0cc562a8463bd73b0cf68edd3938c46dfdcccec` | 84021 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/tb_compute_tile.sf` | `d7e888f37f8cd28f1f266f09649320eeceddf8549955b173fc6a7a046d442f5a` | 152183 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/tb_memory_controller.sf` | `e2c4a7cf80411d90a2d10cdde5c88b587f942eac70ba404bac14944c1ffe5da2` | 95201 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/tb_noc_interconnect.sf` | `e177d8bf9177a08851425350d6473417c10bac3a1f2cef497f5fc63b16c89f26` | 117310 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/tb_scheduler.sf` | `31287feba7b0e7ab7bcd246ea04769d30ee0455ea3d443e1abaf5e772b91d2a1` | 144749 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/tb_silicaflux_top.sf` | `25b0411539b45410554c682866d3195b6fd7fe072607917bbaddc8288f747ce0` | 149330 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/tb_vector_engine.sf` | `222272274bf45f8ff5769a02654e7a620ec189cc99b49f13412c8518daeba1b9` | 53285 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/tile_interface.sf` | `51ce9e0d3d11a4805efcd535fefeb395398ea5716d6607a4bb11d5afcce991db` | 63116 | identical |
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/vector_engine.sf` | `acbc5762a170bcfac65fa2c48e9a3eb879f63088c0c03aa4510b54e2e491f5e6` | 31689 | identical |
| `SilicaFlux-main/SilicaFlux2.0/silicaflux_rtl.zip` | `1a68808804ece11b1eebfc0d462f2729199153e80cef88bf344a05d71aab48bb` | 30715 | identical |
| `SilicaFlux-main/alu.sf` | `1c313a593aeb9b57bbc6460a5e507989279db110860adbfc89eb738d76303c8d` | 24139 | identical |
| `SilicaFlux-main/decoder.sf` | `96d09bc85e375ae9dacbb3aae74a05a33a0453761e2746d42d98a171aaf7be9e` | 94715 | identical |
| `SilicaFlux-main/fetch_unit.sf` | `355479c82e891ff5d34444559f73dde1ac61e0971a287222b46709574b1b6c0f` | 27267 | identical |
| `SilicaFlux-main/forwarding_unit.sf` | `a8472f84a9da5649b6756022166168cc3f34beffaadd66f93f2c1b606440cc59` | 23738 | identical |
| `SilicaFlux-main/memory_controller.sf` | `76616365e7bb9e99fb235de08461922dcbe2ddc4ce22cbb20151574da5330dd5` | 60114 | identical |
| `SilicaFlux-main/register_bank (1).sf` | `0ec9b625479329bacff70b8690676e1e5046f9ac88aeb9ff5345d0c540510c75` | 50496 | identical |
| `SilicaFlux-main/sf_frontend_pkg.sf` | `d0960083846504a0be7f548314190266f55faa2265142b3240160f140bba65cb` | 8879 | identical |
| `SilicaFlux-main/silicaflux.zip` | `ccb055b8f292b1580a85523c921084fdcb62c3570060961758c79f93135e9876` | 72434 | identical |
| `SilicaFlux-main/silicaflux_pkg (1).sf` | `5db1081271f408f64ce555b73f4e2f0cb7e6c576702088d5c079b3d0068fbcfa` | 5440 | identical |
| `SilicaFlux-main/silicaflux_pkg.sf` | `e0debb1125daf3a13e65687d76fa4ce40c81ee2e209a4a23f550992a0b588eab` | 70891 | identical |
| `SilicaFlux-main/tb_compute_tile.sf` | `d7e888f37f8cd28f1f266f09649320eeceddf8549955b173fc6a7a046d442f5a` | 152183 | identical |
| `SilicaFlux-main/tb_noc_interconnect.sf` | `e177d8bf9177a08851425350d6473417c10bac3a1f2cef497f5fc63b16c89f26` | 117310 | identical |
| `SilicaFlux-main/tb_tensor_unit.sf` | `3e68ec33326575d2d44abb85a0ef867f005bc5dab84f6168c30a88c689c4cb4e` | 60551 | identical |
| `SilicaFlux-main/tensor_unit.sf` | `f8cfe485ca3c7958a1e8c0f18374dbfc64fd62382b14becbe148dbf4c509bd02` | 36599 | identical |
| `SilicaFlux-main/vector_engine (1).sf` | `d82af4ae24f5811997ae82b75c561e25a12a142287845eab874c3e4f3b12c5db` | 27451 | identical |
