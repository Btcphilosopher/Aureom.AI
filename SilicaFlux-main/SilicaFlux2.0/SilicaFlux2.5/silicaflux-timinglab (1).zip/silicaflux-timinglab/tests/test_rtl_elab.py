"""Gate 1 for every catalogue design: slang elaborates with zero errors."""
import pytest

from timinglab import config, discovery

CAT = config.load()


@pytest.mark.parametrize("name", sorted(CAT.designs))
def test_design_elaborates(name):
    d = CAT.design(name)
    texts = [config.resolve_source(s) for s in d.files]
    r = discovery.compile_set([(n, b.decode()) for n, b in texts], top=d.top)
    assert r["errors"] == 0, r["messages"]
