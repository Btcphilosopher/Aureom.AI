"""Catalogue, PDK configuration and constraint hygiene."""
import hashlib

from timinglab import config, sdc


def test_catalogue_sources_resolve_and_baselines_exist():
    cat = config.load()
    assert len(cat.designs) >= 10
    for name, d in cat.designs.items():
        for spec in d.files:
            disp, data = config.resolve_source(spec)
            assert data, (name, spec)
        if d.baseline:
            assert d.baseline in cat.designs, name


def test_upstream_snapshot_matches_provenance():
    prov = (config.ROOT / "upstream" / "PROVENANCE.md").read_text()
    for line in prov.splitlines():
        if line.startswith("| `") and "|" in line[3:]:
            cells = [c.strip().strip("`") for c in line.strip("|").split("|")]
            rel, sha = cells[0], cells[1]
            p = config.ROOT / "upstream" / rel
            if p.exists() and len(sha) == 64:
                assert hashlib.sha256(p.read_bytes()).hexdigest() == sha, rel


def test_pdk_configs_complete():
    cat = config.load()
    need = {"lib", "tech_lef", "sc_lef", "place_site", "tiehi", "tielo", "min_buf", "abc_driver_cell",
            "default_period_ns", "min_routing_layer", "max_routing_layer"}
    assert set(cat.pdks) >= {"sky130hd", "gf180mcu", "ihp-sg13g2"}
    for p in cat.pdks.values():
        assert need <= set(p.raw), p.name


def test_every_exception_is_justified():
    for r in sdc.lint_all():
        assert r["pass"], r


def test_block_sdc_has_no_exceptions():
    r = sdc.lint(config.ROOT / "constraints" / "block.sdc")
    assert r["exceptions"] == 0


def test_lint_rejects_unjustified_exception(tmp_path):
    f = config.ROOT / "constraints" / "_tmp_test.sdc"
    try:
        f.write_text("create_clock -period 1 [get_ports clk]\nset_false_path -from [get_ports a]\n")
        assert not sdc.lint(f)["pass"]
    finally:
        f.unlink()
