"""Formal status classification from solver logs (no solver runs).

A status must be exactly what the solver reported: a SAT timeout is never a
FAILED, an empty miter is never PROVEN, a bounded check is PROVEN only when the
reached depth covers the requested one, and a seeded-bug witness counts only
when it produced a counterexample.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

from timinglab import formal

AIG = "miter : i/o =   77/    1  lat =  254  and =   2695  lev = 31\n"


def _check(tmp: Path, name: str, log: str) -> Path:
    rd = tmp / name
    rd.mkdir()
    (rd / "elab.ys").write_text("")
    t = time.time()
    os.utime(rd / "elab.ys", (t - 10, t - 10))
    (rd / "prove.log").write_text(log)
    return rd


def _chk(**kw):
    return {"name": "x", "claim": "c", "kind": "seq", **kw}


def test_sat_timeout_is_not_failed(tmp_path):
    rd = _check(tmp_path, "a", "Solving problem with 1 variables..\nInterrupted SAT solver: TIMEOUT!\n"
                                "ERROR: Called with -verify and proof did time out!\n")
    assert formal._status_from_log(_chk(), rd)["status"] == "TIMEOUT"


def test_sat_counterexample_is_failed(tmp_path):
    rd = _check(tmp_path, "a", "SAT proof finished - model found: FAIL!\n"
                                "ERROR: Called with -verify and proof did fail!\n")
    assert formal._status_from_log(_chk(), rd)["status"] == "FAILED"


def test_sat_success(tmp_path):
    rd = _check(tmp_path, "a", "SAT proof finished - no model found: SUCCESS!\n")
    assert formal._status_from_log(_chk(), rd)["status"] == "PROVEN"


def test_bmc3_depth_must_cover_request(tmp_path):
    full = _check(tmp_path, "a", AIG + "No output asserted in 16 frames. Resource limit reached.\n")
    short = _check(tmp_path, "b", AIG + "No output asserted in 9 frames. Resource limit reached.\n")
    assert formal._status_from_log(_chk(engine="abc-bmc", depth=16), full)["status"] == "PROVEN"
    assert formal._status_from_log(_chk(engine="abc-bmc", depth=16), short)["status"] != "PROVEN"


def test_kind_needs_base_case_covering_induction_depth(tmp_path):
    step = "Completed 4 iterations and added 2 uniqueness constraints.\nNetworks are equivalent.\n"
    ok = _check(tmp_path, "a", AIG + "No output asserted in 8 frames.\n" + step)
    short = _check(tmp_path, "b", AIG + "No output asserted in 3 frames.\n" + step)
    nostep = _check(tmp_path, "c", AIG + "No output asserted in 8 frames.\nNetworks are UNDECIDED.\n")
    assert formal._status_from_log(_chk(engine="abc-kind", depth=8), ok)["status"] == "PROVEN"
    assert formal._status_from_log(_chk(engine="abc-kind", depth=8), short)["status"] != "PROVEN"
    assert formal._status_from_log(_chk(engine="abc-kind", depth=8), nostep)["status"] == "UNDECIDED"


def test_empty_aig_is_vacuous(tmp_path):
    rd = _check(tmp_path, "a", "miter : i/o =   77/    1  lat =    0  and =      0  lev = 0\nProperty proved.\n")
    assert formal._status_from_log(_chk(engine="pdr"), rd)["status"] == "VACUOUS"


def test_pdr_counterexample(tmp_path):
    rd = _check(tmp_path, "a", AIG + 'Output 0 of miter "miter" was asserted in frame 3.\n')
    assert formal._status_from_log(_chk(engine="pdr"), rd)["status"] == "FAILED"


def test_witness_summary():
    res = [{"name": "p", "status": "PROVEN", "gate": True},
           {"name": "w1", "status": "FAILED", "gate": False, "expect": "FAILED"},
           {"name": "w2", "status": "TIMEOUT/INCOMPLETE", "gate": False, "expect": "FAILED"}]
    s = formal._summary(res)
    assert (s["gating_proven"], s["gating_total"], s["proven"], s["total"]) == (1, 1, 1, 1)
    assert (s["witnesses_ok"], s["witnesses_total"]) == (1, 2)


def test_every_witness_mutation_applies():
    for c in formal.CHECKS:
        for target, old, _new in c.get("mutate", []):
            from timinglab import config
            assert config.resolve_source(target)[1].decode().count(old) == 1, (c["name"], old)
