"""Report parsers on real OpenSTA / OpenROAD output recorded in tests/data."""
from conftest import DATA
from timinglab.parsers import openroad, sta


def test_summary_groups():
    s = sta.parse_summary(DATA / "sta_grt" / "summary.tsv")
    assert s["groups"]["max"]["reg2reg"]["endpoints"] > 0
    assert s["worst_slack_max"] == min(g["wns"] for g in s["groups"]["max"].values() if g["wns"] is not None)


def test_paths_and_derived_quantities():
    paths = sta.parse_paths(DATA / "sta_grt" / "paths.tsv")
    assert paths and all(p["points"] for p in paths)
    p = next(p for p in paths if p["kind"] == "max" and p["group"] == "reg2reg")
    d = p["derived"]
    assert d["logic_depth"] >= 1
    assert abs(d["cell_delay"] + d["net_delay"] - d["path_delay"]) < 1e-3
    assert 0.0 <= d["wire_fraction"] <= 1.0
    assert d["clock_skew"] is not None          # propagated clocks after CTS


def test_stage_fmax_is_derived_from_reg2reg_wns():
    t = sta.parse_stage(DATA / "sta_grt", 10.0)
    assert abs(t["fmax_r2r_mhz"] - 1000.0 / (10.0 - t["reg2reg_wns"])) < 1e-2


def test_skew_report():
    sk = sta.parse_skew(DATA / "sta_grt" / "skew.rpt")
    assert "setup" in sk and "skew" in sk["setup"]


def test_derive_on_synthetic_path():
    p = {"points": [
        {"pin": "r1/CLK", "dir": "input", "inst": "r1", "ref": "dff", "arrival": 0.0, "slew": None},
        {"pin": "r1/Q", "dir": "output", "inst": "r1", "ref": "dff", "arrival": 0.3, "slew": None},
        {"pin": "u1/A", "dir": "input", "inst": "u1", "ref": "nand2", "arrival": 0.35, "slew": None},
        {"pin": "u1/Y", "dir": "output", "inst": "u1", "ref": "nand2", "arrival": 0.5, "slew": None},
        {"pin": "b1/A", "dir": "input", "inst": "b1", "ref": "sky130_fd_sc_hd__buf_4", "arrival": 0.6, "slew": None},
        {"pin": "b1/X", "dir": "output", "inst": "b1", "ref": "sky130_fd_sc_hd__buf_4", "arrival": 0.7, "slew": None},
        {"pin": "r2/D", "dir": "input", "inst": "r2", "ref": "dff", "arrival": 0.8, "slew": None}],
        "launch_clock_latency": 0.2, "capture_clock_latency": 0.25}
    d = sta.derive(p)["derived"]
    assert d["logic_depth"] == 2 and d["buffers"] == 1
    assert abs(d["net_delay"] - 0.25) < 1e-9 and abs(d["cell_delay"] - 0.55) < 1e-9
    assert abs(d["clock_skew"] - 0.05) < 1e-9


def test_congestion_table():
    c = openroad.parse_congestion(DATA / "missing.rpt", (DATA / "grt_congestion.log").read_text())
    assert c["total"]["layer"] == "Total" and c["total"]["usage_pct"] > 0
    assert {l["layer"] for l in c["layers"]} >= {"met1", "met2"}
