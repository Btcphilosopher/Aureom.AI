"""Syntax scanner and discovery helpers (pyslang only, fast)."""
from timinglab import discovery, svscan

SRC = """
module top import p::*; #(parameter int W = 4) (input logic clk_i, input logic rst_ni, output logic [W-1:0] q_o);
  logic [W-1:0] r;
  always_ff @(posedge clk_i or negedge rst_ni) if (!rst_ni) r <= '0; else r <= r + p::ONE;
  sub #(.A(1)) u_sub (.clk_i(clk_i), .d_i(r), .x_o());
  assign q_o = r;
endmodule
"""


def test_scan_definitions_ports_instances():
    fs = svscan.scan_text(SRC, "t.sv")
    assert fs.syntax_errors == 0
    d = fs.definitions[0]
    assert d.name == "top" and d.kind == "module"
    assert [p.name for p in d.ports] == ["clk_i", "rst_ni", "q_o"]
    assert d.ports[2].direction == "output"
    assert d.imports == ["p"] and d.scoped_refs == {"p": ["ONE"]}
    assert d.instances[0].module == "sub" and d.instances[0].names == ["u_sub"]
    assert set(d.instances[0].connections) == {"clk_i", "d_i", "x_o"}
    es = d.edge_signals()
    assert es["clocks"] == {"clk_i"} and es["async_resets"] == {"rst_ni"}


def test_compile_set_reports_missing_package_member():
    pkg = "package p; localparam int TWO = 2; endpackage"
    r = discovery.compile_set([("p.sv", pkg), ("t.sv", SRC)], top="top")
    assert r["errors"] >= 1
    assert r["categories"].get("missing_package_member", 0) + r["categories"].get("undeclared_identifier", 0) >= 1


def test_compile_set_clean():
    pkg = "package p; localparam logic [3:0] ONE = 1; endpackage"
    sub = "module sub #(parameter int A = 0) (input logic clk_i, input logic [3:0] d_i, output logic x_o); assign x_o = ^d_i; endmodule"
    r = discovery.compile_set([("p.sv", pkg), ("s.sv", sub), ("t.sv", SRC)], top="top")
    assert r["errors"] == 0 and r["top_instances"] == ["top"]


def test_testbench_interface_mismatch_detected():
    dut = svscan.scan_text("module dut(input logic clk_i, input logic a_i); endmodule", "d.sv")
    tb = svscan.scan_text("module tb_x; logic clk; dut u(.clk(clk), .a_i(1'b0)); endmodule", "tb_x.sv")
    s1 = discovery.Source("d.sv", "", "x", 0, "tree")
    s2 = discovery.Source("tb_x.sv", "", "y", 0, "tree")
    idx = {"dut": [discovery.DefRef(s1, dut.definitions[0])]}
    res = discovery.check_testbenches([discovery.DefRef(s2, tb.definitions[0])], idx)
    assert res[0]["status"] == "interface_mismatch" and res[0]["tb_ports_not_in_dut"] == ["clk"]


def test_non_sv_dot_sf_is_not_systemverilog():
    dsl = "package silicaflux.ml\nfixed Fixed16_16 { int_bits: 16 }\n"
    assert svscan.scan_text(dsl, "x.sf").syntax_errors > 0
