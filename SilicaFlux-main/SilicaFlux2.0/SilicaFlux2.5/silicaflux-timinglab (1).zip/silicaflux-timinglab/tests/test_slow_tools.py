"""Tool-driven checks (RUN_SLOW=1): synthesis + STA, equivalence, formal, SDC stub."""
from pathlib import Path

from conftest import slow
from timinglab import config, formal, sdc, verify
from timinglab.flow import runner


@slow
def test_synth_sta_forwarding_unit(tmp_path, monkeypatch):
    from timinglab.flow import common
    monkeypatch.setattr(common, "RUNS", tmp_path)
    cat = config.load()
    r = runner.run_one(cat, "forwarding_unit", "sky130hd", stages=("elab", "synth", "sta"))
    assert not r.get("error"), r.get("error")
    t = r["stages"]["sta"]["timing"]
    assert t["reg2reg_wns"] is not None and t["paths"]


@slow
def test_formal_small(tmp_path):
    for name in ("mul_lo_W8", "reduce_W32_N4"):
        chk = next(c for c in formal.CHECKS if c["name"] == name)
        assert formal.run_check(chk, tmp_path)["status"] == "PROVEN"


@slow
def test_equivalence_vector_quick(tmp_path):
    spec = verify.BENCHES["tb_eq_vector"]
    srcs = verify._stage(spec["files"], tmp_path / "src")
    b = verify._build(spec["top"], srcs, ["--assert"], tmp_path / "obj")
    assert b["ok"]
    assert verify._sim(b["binary"], 7, 3000, tmp_path / "sim.log")["status"] == "PASS"


@slow
def test_sdc_stub_check_catches_missing_object(tmp_path):
    good = sdc.stub_check(config.ROOT / "constraints" / "silicaflux_top.sdc",
                          "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf", "silicaflux_top",
                          ["u_clk_ctrl"], tmp_path / "good")
    assert good["pass"]
    bad_sdc = tmp_path / "bad.sdc"
    bad_sdc.write_text("create_clock -name c -period 1 [get_ports clk_does_not_exist_i]\n")
    bad = sdc.stub_check(bad_sdc, "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf",
                         "silicaflux_top", ["u_clk_ctrl"], tmp_path / "bad")
    assert not bad["pass"]
