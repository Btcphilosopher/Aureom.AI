"""Gate-level graph analysis and hypothesis confirmation maths."""
from timinglab import confirm
from timinglab.audit import netlist as NL


def _nl(cells, ports, netnames):
    return NL.Netlist({"modules": {"t": {"ports": ports, "cells": cells, "netnames": netnames}}}, "t")


def _gate(t, a, b, y):
    return {"type": t, "port_directions": {"A": "input", "B": "input", "Y": "output"},
            "connections": {"A": [a], "B": [b], "Y": [y]}, "attributes": {"src": "x.sv:%d.1" % y}}


def _ff(d, q, clk=2):
    return {"type": "$_DFF_P_", "port_directions": {"C": "input", "D": "input", "Q": "output"},
            "connections": {"C": [clk], "D": [d], "Q": [q]}, "attributes": {"src": "x.sv:1.1"}}


def test_depth_chain_and_naming():
    # in(3) -> ff q(10) -> 3 AND gates in series -> ff2 q(20)
    cells = {"f1": _ff(3, 10), "g1": _gate("$_AND_", 10, 10, 11), "g2": _gate("$_AND_", 11, 10, 12),
             "g3": _gate("$_AND_", 12, 10, 13), "f2": _ff(13, 20)}
    ports = {"a": {"direction": "input", "bits": [3]}, "clk": {"direction": "input", "bits": [2]},
             "y": {"direction": "output", "bits": [20]}}
    nets = {"a": {"bits": [3]}, "clk": {"bits": [2]}, "y": {"bits": [20]}, "r1": {"bits": [10]},
            "acc_q": {"bits": [20]}}
    nl = _nl(cells, ports, nets)
    dep = nl.depth_analysis()
    worst = dep["endpoints"][0]
    assert worst["levels"] == 3 and worst["startpoint"] == "ff:r1"
    assert worst["endpoint"] == "ff:acc_q.D"           # register name preferred over the port name
    assert dep["loops"] == []


def test_loop_detected():
    cells = {"g1": _gate("$_AND_", 5, 6, 7), "g2": _gate("$_OR_", 7, 5, 6)}
    ports = {"a": {"direction": "input", "bits": [5]}, "y": {"direction": "output", "bits": [7]}}
    nl = _nl(cells, ports, {"a": {"bits": [5]}, "y": {"bits": [7]}})
    assert nl.depth_analysis()["loops"]


def test_spearman_and_fit():
    assert confirm.spearman([1, 2, 3, 4], [10, 20, 30, 40]) == 1.0
    assert confirm.spearman([1, 2, 3, 4], [4, 3, 2, 1]) == -1.0
    f = confirm.fit([1.0, 2.0, 3.0], [0.5, 1.0, 1.5])
    assert abs(f["ns_per_unit"] - 0.5) < 1e-9 and f["r2"] == 1.0
