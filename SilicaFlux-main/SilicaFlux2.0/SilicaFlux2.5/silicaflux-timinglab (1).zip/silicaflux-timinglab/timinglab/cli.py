"""TimingLab command line.

  python -m timinglab tools
  python -m timinglab discover --repo <Aureom.AI checkout> [--out reports/discovery]
  python -m timinglab audit [design ...|--all]
  python -m timinglab run [design ...|--all] [--pdk P ...] [--stages elab synth sta pnr] [--jobs N] [--resume]
  python -m timinglab confirm
  python -m timinglab lint | equiv | mutation | formal
  python -m timinglab report
  python -m timinglab accept
  python -m timinglab sdc        (constraint lint + silicaflux_top.sdc stub check)
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import config, tools

ROOT = config.ROOT
REPORTS = ROOT / "reports"


def _designs(cat: config.Catalogue, names: list[str], all_: bool) -> list[str]:
    if all_ or not names:
        return list(cat.designs)
    for n in names:
        cat.design(n)
    return names


def cmd_tools(a: argparse.Namespace) -> int:
    inv = tools.inventory()
    for k, v in inv.items():
        print(f"{k:12s} {v['path'] or '-':45s} {v['version']}")
    print(f"read_slang available: {tools.has_read_slang()}")
    cat = config.load()
    for k, p in cat.pdks.items():
        ok, missing = p.available()
        print(f"PDK {k:11s} {'ok' if ok else 'MISSING ' + ', '.join(missing[:2])}")
    return 0


def cmd_discover(a: argparse.Namespace) -> int:
    from . import discovery
    r = discovery.discover(Path(a.repo), Path(a.out), compile_matrix=not a.no_matrix, reuse_matrix=a.reuse_matrix)
    print(json.dumps(r["summary"], indent=1))
    print("graph:", r.get("svg"))
    return 0


def cmd_audit(a: argparse.Namespace) -> int:
    from .audit import rtl_audit
    cat = config.load()
    rc = 0
    for n in _designs(cat, a.designs, a.all):
        try:
            r = rtl_audit.audit_design(cat, n, REPORTS / "audit")
            s = r["summary"]
            print(f"{n:22s} gates={s['generic_gates']:6d} levels={s['max_levels']:4d} latches={s['latches']} "
                  f"loops={s['comb_loops']} top: {r['candidates'][0]['title'] if r['candidates'] else '-'}")
        except Exception as e:
            print(f"{n:22s} AUDIT FAILED: {e}")
            rc = 1
    return rc


def cmd_run(a: argparse.Namespace) -> int:
    from .flow import runner
    cat = config.load()
    pdks = a.pdk or cat.defaults.get("pdks", list(cat.pdks))
    res = runner.run_many(cat, _designs(cat, a.designs, a.all), pdks, tuple(a.stages), jobs=a.jobs,
                          resume=a.resume)
    return 1 if any(r.get("error") for r in res) else 0


def cmd_confirm(a: argparse.Namespace) -> int:
    from . import confirm
    from .flow import common
    out = REPORTS / "confirm"
    out.mkdir(parents=True, exist_ok=True)
    for af in sorted((REPORTS / "audit").glob("*/rtl_audit.json")):
        audit = json.loads(af.read_text())
        for pdk_dir in sorted(common.RUNS.iterdir()):
            rd = pdk_dir / audit["design"]
            if pdk_dir.name.startswith("_") or not (rd / "result.json").exists():
                continue
            c = confirm.confirm(audit, rd)
            (out / f"{audit['design']}@{pdk_dir.name}.json").write_text(json.dumps(c, indent=1))
            print(f"{audit['design']:22s} {pdk_dir.name:11s} overlap {c['top_overlap']}/{c['top_n']} "
                  f"rho={c['spearman_est_vs_sta_delay']} {c['status_counts']}")
    return 0


def cmd_verify(a: argparse.Namespace) -> int:
    from . import verify
    out = REPORTS / "verification"
    out.mkdir(parents=True, exist_ok=True)
    if a.cmd == "lint":
        r = verify.run_lint(config.load(), out / "lint")
        for k, v in r.items():
            print(f"{k:22s} {v['gate']} errors={v['errors']} classes={v['warning_classes']}")
        (out / "lint.json").write_text(json.dumps(r, indent=1))
        return 0 if all(v["gate"] == "PASS" for v in r.values()) else 1
    if a.cmd == "equiv":
        r = verify.run_equiv(out / "equiv", seeds=tuple(a.seeds), cycles=a.cycles)
        (out / "equiv.json").write_text(json.dumps(r, indent=1))
        for b, cfgs in r.items():
            if isinstance(cfgs, dict):
                for c, v in cfgs.items():
                    print(f"{b:14s} {c:16s} {'PASS' if v['pass'] else 'FAIL'}")
        return 0 if r["all_pass"] else 1
    if a.cmd == "mutation":
        r = verify.run_mutation(out / "mutation", cycles=a.cycles)
        (out / "mutation.json").write_text(json.dumps(r, indent=1))
        for m in r["mutants"]:
            print(f"m{m['id']:02d} {m['status']:20s} {m['file']}: {m['to'][:70]}")
        print(f"killed {r['killed']}/{r['total']}")
        return 0 if r["killed"] == r["total"] else 1
    return 2


def cmd_formal(a: argparse.Namespace) -> int:
    from . import formal
    names = a.checks or None
    if a.gating:   # the acceptance set: every gating proof and every seeded-bug witness
        names = [c["name"] for c in formal.CHECKS if c.get("gate", True) or "expect" in c]
    r = formal.collect(REPORTS / "formal") if a.collect else formal.run_all(REPORTS / "formal", names)
    for c in r["checks"]:
        exp = f" (expected {c['expect']}: {'ok' if c['status'] == c['expect'] else 'NOT OK'})" if "expect" in c else ""
        print(f"{c['name']:26s} {c['status']:8s} {c['seconds']:8.1f}s  {c['claim']}{exp}")
    print(f"gating checks proven: {r['gating_proven']}/{r['gating_total']} (all proofs: {r['proven']}/{r['total']}; "
          f"seeded-bug witnesses: {r['witnesses_ok']}/{r['witnesses_total']})")
    return 0 if (r["gating_proven"] == r["gating_total"] and r["witnesses_ok"] == r["witnesses_total"]) else 1


def cmd_report(a: argparse.Namespace) -> int:
    from .flow import common
    from .report import dashboard, model
    cat = config.load()
    out = REPORTS / "dashboard"
    out.mkdir(parents=True, exist_ok=True)
    runs = common.RUNS
    if not runs.exists() or not any(runs.glob("*/*/result.json")):
        runs = REPORTS / "runs"          # packaged sample results (scripts/package.py)
        print(f"using packaged results in {runs}")
    m = model.build(runs, REPORTS, cat)
    print(dashboard.write_json(m, out))
    for p in dashboard.write_csvs(m, out):
        print(p)
    print(dashboard.write_html(m, out))
    return 0


def cmd_accept(a: argparse.Namespace) -> int:
    from . import regress
    r = regress.accept(config.load(), REPORTS)
    for n, v in r["alternatives"].items():
        print(f"{n:22s} {'ACCEPTED' if v['accepted'] else 'REJECTED'}")
        for g, res in v["gates"].items():
            flag = {True: "PASS", False: "FAIL", None: "n/a "}[res["pass"]]
            print(f"   {g:14s} {flag}  {res['detail'][:150]}")
    return 0 if all(v["accepted"] for v in r["alternatives"].values()) else 1


def cmd_sdc(a: argparse.Namespace) -> int:
    from . import sdc
    out = REPORTS / "constraints"
    out.mkdir(parents=True, exist_ok=True)
    lint = sdc.lint_all()
    chk = sdc.stub_check(ROOT / "constraints" / "silicaflux_top.sdc",
                         "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf", "silicaflux_top",
                         ["u_clk_ctrl"], out / "silicaflux_top")
    res = {"lint": lint, "silicaflux_top_stub_check": chk}
    (out / "constraints.json").write_text(json.dumps(res, indent=1))
    for l in lint:
        print(f"lint {l['file']:32s} exceptions={l['exceptions']} {'PASS' if l['pass'] else 'FAIL'} {l['findings']}")
    print(f"stub-check silicaflux_top.sdc: {'PASS' if chk['pass'] else 'FAIL'} unresolved={chk['unresolved_objects']}")
    return 0 if chk["pass"] and all(l["pass"] for l in lint) else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="timinglab", description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("tools").set_defaults(fn=cmd_tools)
    p = sub.add_parser("discover")
    p.add_argument("--repo", required=True)
    p.add_argument("--out", default=str(REPORTS / "discovery"))
    p.add_argument("--no-matrix", action="store_true", help="skip the package-compatibility compile matrix")
    p.add_argument("--reuse-matrix", action="store_true", help="reuse the compile matrix of a previous run")
    p.set_defaults(fn=cmd_discover)
    for name, fn in (("audit", cmd_audit), ("run", cmd_run)):
        p = sub.add_parser(name)
        p.add_argument("designs", nargs="*")
        p.add_argument("--all", action="store_true")
        if name == "run":
            p.add_argument("--pdk", nargs="*")
            p.add_argument("--stages", nargs="*", default=["elab", "synth", "sta", "pnr"])
            p.add_argument("--jobs", type=int, default=2)
            p.add_argument("--resume", action="store_true")
        p.set_defaults(fn=fn)
    sub.add_parser("confirm").set_defaults(fn=cmd_confirm)
    for name in ("lint", "equiv", "mutation"):
        p = sub.add_parser(name)
        p.add_argument("--seeds", type=int, nargs="*", default=[1, 2, 3])
        p.add_argument("--cycles", type=int, default=20000 if name == "equiv" else 5000)
        p.set_defaults(fn=cmd_verify)
    p = sub.add_parser("formal")
    p.add_argument("checks", nargs="*")
    p.add_argument("--collect", action="store_true", help="rebuild formal.json from existing check logs")
    p.add_argument("--gating", action="store_true",
                   help="run only the checks the acceptance gate needs (gating proofs + seeded-bug witnesses)")
    p.set_defaults(fn=cmd_formal)
    sub.add_parser("report").set_defaults(fn=cmd_report)
    sub.add_parser("accept").set_defaults(fn=cmd_accept)
    sub.add_parser("sdc").set_defaults(fn=cmd_sdc)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
