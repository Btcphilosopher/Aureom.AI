"""Collect flow, audit and verification outputs into one results model.

Every number in the model is copied from a tool report (via the parsers) or
computed from such numbers; computed values are listed in DERIVED below and
labelled in the dashboard."""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any

from .. import config, confirm as confirm_mod, tools

DERIVED = {
    "fmax_r2r_mhz": "1000 / (T - reg2reg WNS): reg2reg-limited clock rate with the same uncertainty/setup",
    "min_period_r2r_ns": "T - reg2reg WNS",
    "logic_depth": "combinational cells between launch and capture register on the STA path",
    "cell_delay / net_delay / wire_fraction": "split of the STA path arrival into cell arcs and net arcs. A net arc "
                                              "is only the RC propagation along the wire (estimated parasitics); the "
                                              "wire's capacitive load is part of the driving cell's delay, so "
                                              "wire_fraction is near 0 where wire resistance is low (e.g. GF180's thick "
                                              "metal with 5 V drivers), although wire load is included",
    "clock_skew": "capture clock latency - launch clock latency of the path (OpenSTA PathEnd)",
    "time_per_op_ns": "latency [cycles] x min_period_r2r_ns (isolated operation, no overlap)",
    "path_hpwl_um": "half-perimeter of the bounding box of the cells on the path (placement, GRT stage)",
}

STAGES = ("synth", "place", "cts", "grt")


def _metrics(t: dict[str, Any]) -> dict[str, Any]:
    if not t:
        return {}
    g = t.get("groups", {}).get("max", {})
    gm = t.get("groups", {}).get("min", {})
    return {
        "wns": t.get("wns"), "tns": t.get("tns"), "whs": t.get("whs"), "ths": t.get("ths"),
        "reg2reg_wns": t.get("reg2reg_wns"), "reg2reg_tns": t.get("reg2reg_tns"),
        "reg2reg_violators": g.get("reg2reg", {}).get("violators"),
        "reg2reg_endpoints": g.get("reg2reg", {}).get("endpoints"),
        "in2reg_wns": g.get("in2reg", {}).get("wns"),
        "hold_violators": sum((v.get("violators") or 0) for v in gm.values()),
        "fmax_r2r_mhz": t.get("fmax_r2r_mhz"), "min_period_r2r_ns": t.get("min_period_r2r_ns"),
        "skew_setup_ns": (t.get("skew", {}).get("setup") or {}).get("skew"),
        "skew_hold_ns": (t.get("skew", {}).get("hold") or {}).get("skew"),
        "clock_latency_ns": (t.get("skew", {}).get("setup") or {}).get("latency"),
        "power_total_w": (t.get("power") or {}).get("total_w"),
        "area_um2": (t.get("area") or {}).get("design_area_um2"),
        "utilization_pct": (t.get("area") or {}).get("utilization_pct"),
    }


def _paths(t: dict[str, Any], n: int = 25) -> list[dict[str, Any]]:
    out = []
    for i, p in enumerate([p for p in t.get("paths", []) if p.get("slack") is not None][:n]):
        d = p["derived"]
        out.append({"rank": i + 1, "group": p["group"], "slack": p["slack"], "startpoint": p["startpoint"],
                    "endpoint": p["endpoint"], "arrival": p.get("arrival"), "required": p.get("required"),
                    "logic_depth": d["logic_depth"], "buffers": d["buffers"], "path_delay": d["path_delay"],
                    "cell_delay": d["cell_delay"], "net_delay": d["net_delay"], "wire_fraction": d["wire_fraction"],
                    "clock_skew": d["clock_skew"]})
    return out


def _hpwl(rows: list[dict[str, Any]]) -> dict[str, float]:
    by: dict[str, list[tuple[float, float]]] = {}
    for r in rows:
        by.setdefault(r["endpoint"], []).append((r["x"], r["y"]))
    return {ep: round((max(x for x, _ in pts) - min(x for x, _ in pts)) + (max(y for _, y in pts) - min(y for _, y in pts)), 2)
            for ep, pts in by.items() if pts}


def collect_run(rd: Path, cat: config.Catalogue) -> dict[str, Any] | None:
    f = rd / "result.json"
    if not f.exists():
        return None
    r = json.loads(f.read_text())
    st = r.get("stages", {})
    synth = st.get("synth", {})
    pnr = st.get("pnr", {})
    pt = pnr.get("timing", {})
    stages = {"synth": _metrics(st.get("sta", {}).get("timing", {}))}
    for s in ("place", "cts", "grt"):
        stages[s] = _metrics(pt.get(s, {}))
    final = "grt" if pt.get("grt") else ("cts" if pt.get("cts") else ("place" if pt.get("place") else "synth"))
    final_t = pt.get(final) if final != "synth" else st.get("sta", {}).get("timing", {})
    d = cat.designs.get(r["design"])
    lat = d.raw.get("latency") if d else None
    paths = _paths(final_t or {})
    hp = _hpwl(pnr.get("path_cells_xy", []))
    for p in paths:
        p["path_hpwl_um"] = hp.get(p["endpoint"])
    # routing correlation over every reg2reg path with placement evidence (worst 20 endpoints)
    xs, ys, ws = [], [], []
    for q in (final_t or {}).get("paths", []):
        if q.get("group") == "reg2reg" and q["endpoint"] in hp:
            xs.append(hp[q["endpoint"]])
            ys.append(q["derived"]["net_delay"])
            ws.append(q["derived"]["wire_fraction"])
    cong = pnr.get("congestion", {})
    m = stages.get(final, {})
    tpo = None
    if isinstance(lat, int) and m.get("min_period_r2r_ns"):
        tpo = round(lat * m["min_period_r2r_ns"], 3)
    return {
        "design": r["design"], "pdk": r["pdk"], "top": r.get("top"), "category": r.get("category"),
        "role": r.get("role"), "alternative_of": r.get("alternative_of"), "period_ns": r.get("period_ns"),
        "params": r.get("params"), "latency": lat, "error": r.get("error"),
        "flow_fingerprint": r.get("flow_fingerprint"), "sources": r.get("sources", []),
        "tools": r.get("tools", {}), "started": r.get("started"), "finished": r.get("finished"),
        "synth": {k: synth.get(k) for k in ("area_um2", "cells", "flops", "latches", "abc_delay_target_ps", "seconds")},
        "generic_cells": (synth.get("generic") or {}).get("cells"),
        "stages": stages, "final_stage": final, "final": m, "time_per_op_ns": tpo,
        "floorplan": pnr.get("floorplan", {}), "port_bits": pnr.get("port_bits"),
        "pnr_seconds": pnr.get("seconds"), "pnr_log": pnr.get("log_summary", {}),
        "congestion": {"total": cong.get("total", {}), "layers": cong.get("layers", []),
                       "wirelength_um": cong.get("wirelength_um")},
        "critical_paths": paths,
        "routing_correlation": {"n": len(xs), "spearman_hpwl_vs_net_delay": confirm_mod.spearman(xs, ys),
                                "mean_wire_fraction": round(sum(ws) / len(ws), 4) if ws else None,
                                "grt_usage_pct": cong.get("total", {}).get("usage_pct"),
                                "grt_overflow": cong.get("total", {}).get("overflow")},
        "hold_note": "hold is not repaired in the experimental flow" if (m.get("whs") or 0) < 0 else "",
    }


def comparisons(runs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    idx = {(r["design"], r["pdk"]): r for r in runs}
    out = []
    for r in runs:
        b = r.get("alternative_of")
        if not b or (b, r["pdk"]) not in idx:
            continue
        base = idx[(b, r["pdk"])]
        fb, fa = base["final"], r["final"]

        def pct(a, bb):
            return round(100.0 * (a - bb) / bb, 2) if a is not None and bb not in (None, 0) else None
        out.append({
            "pdk": r["pdk"], "baseline": b, "alternative": r["design"], "role": r["role"],
            "period_ns": r["period_ns"], "stage": r["final_stage"],
            "r2r_wns_before": fb.get("reg2reg_wns"), "r2r_wns_after": fa.get("reg2reg_wns"),
            "r2r_tns_before": fb.get("reg2reg_tns"), "r2r_tns_after": fa.get("reg2reg_tns"),
            "fmax_before_mhz": fb.get("fmax_r2r_mhz"), "fmax_after_mhz": fa.get("fmax_r2r_mhz"),
            "fmax_delta_pct": pct(fa.get("fmax_r2r_mhz"), fb.get("fmax_r2r_mhz")),
            "area_before_um2": base["synth"]["area_um2"], "area_after_um2": r["synth"]["area_um2"],
            "area_delta_pct": pct(r["synth"]["area_um2"], base["synth"]["area_um2"]),
            "flops_before": base["synth"]["flops"], "flops_after": r["synth"]["flops"],
            "power_before_w": fb.get("power_total_w"), "power_after_w": fa.get("power_total_w"),
            "latency_before": base.get("latency"), "latency_after": r.get("latency"),
            "time_per_op_before_ns": base.get("time_per_op_ns"), "time_per_op_after_ns": r.get("time_per_op_ns"),
            "worst_path_before": (base["critical_paths"] or [{}])[0].get("endpoint"),
            "worst_path_after": (r["critical_paths"] or [{}])[0].get("endpoint"),
            "depth_before": (base["critical_paths"] or [{}])[0].get("logic_depth"),
            "depth_after": (r["critical_paths"] or [{}])[0].get("logic_depth"),
        })
    return out


def _load(p: Path) -> Any:
    return json.loads(p.read_text()) if p.exists() else None


def build(runs_dir: Path, reports: Path, cat: config.Catalogue) -> dict[str, Any]:
    runs = []
    for pdk_dir in sorted(p for p in runs_dir.iterdir() if p.is_dir() and not p.name.startswith('_')) if runs_dir.exists() else []:
        for rd in sorted(p for p in pdk_dir.iterdir() if p.is_dir()):
            c = collect_run(rd, cat)
            if c:
                runs.append(c)
    audit = {}
    for d in sorted((reports / "audit").glob("*/rtl_audit.json")):
        a = json.loads(d.read_text())
        audit[a["design"]] = {"summary": a["summary"], "candidates": a["candidates"][:25],
                              "register_ranking": a["register_ranking"][:15]}
    conf = {}
    for d in sorted((reports / "confirm").glob("*.json")):
        c = json.loads(d.read_text())
        conf[f"{c['design']}@{c['pdk']}"] = c
    # RTL register identity of each critical path (from the confirmation step, which maps
    # the path ends through the netlist's Q nets); joined by rank, checked by slack
    for r in runs:
        pr = {q["rank"]: q for q in conf.get(f"{r['design']}@{r['pdk']}", {}).get("path_registers", [])}
        for p in r["critical_paths"]:
            q = pr.get(p["rank"])
            if q and abs(q["slack"] - p["slack"]) < 1e-6:
                p["start_register"], p["end_register"] = q["start_register"], q["end_register"]
    model = {
        "generated": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "tools": tools.inventory(),
        "pdks": {k: v.raw.get("description") for k, v in cat.pdks.items()},
        "derived_quantities": DERIVED,
        "runs": runs, "comparisons": comparisons(runs),
        "audit": audit, "confirmation": conf,
        "verification": {
            "lint": _load(reports / "verification" / "lint.json"),
            "equiv": _load(reports / "verification" / "equiv.json"),
            "mutation": _load(reports / "verification" / "mutation.json"),
            "formal": _load(reports / "formal" / "formal.json"),
            "acceptance": _load(reports / "regression" / "acceptance.json"),
        },
        "discovery": (_load(reports / "discovery" / "discovery.json") or {}).get("summary"),
    }
    return model
