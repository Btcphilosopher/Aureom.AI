"""TimingLab dashboard: JSON + CSV + a self-contained HTML report.

The HTML has no external dependencies (inline CSS and SVG, native tooltips),
supports light and dark mode, and carries a table for every chart."""
from __future__ import annotations

import csv
import html
import json
from pathlib import Path
from typing import Any

E = html.escape


def _f(v: Any, nd: int = 3) -> str:
    if v is None:
        return "—"
    if isinstance(v, float):
        return f"{v:.{nd}f}"
    return str(v)


def write_json(model: dict[str, Any], out: Path) -> Path:
    p = out / "timinglab_results.json"
    p.write_text(json.dumps(model, indent=1))
    return p


def write_csvs(model: dict[str, Any], out: Path) -> list[Path]:
    paths = []

    def w(name: str, cols: list[str], rows: list[dict[str, Any]]) -> None:
        p = out / name
        with p.open("w", newline="") as fh:
            wr = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
            wr.writeheader()
            for r in rows:
                wr.writerow({k: r.get(k) for k in cols})
        paths.append(p)

    rows = []
    for r in model["runs"]:
        for st, m in r["stages"].items():
            if not m:
                continue
            rows.append({"design": r["design"], "pdk": r["pdk"], "stage": st, "role": r["role"],
                         "alternative_of": r["alternative_of"], "period_ns": r["period_ns"],
                         "latency": r["latency"], "synth_area_um2": r["synth"]["area_um2"],
                         "cells": r["synth"]["cells"], "flops": r["synth"]["flops"], **m,
                         "grt_usage_pct": r["congestion"]["total"].get("usage_pct") if st == "grt" else None,
                         "grt_overflow": r["congestion"]["total"].get("overflow") if st == "grt" else None})
    w("summary.csv", ["design", "pdk", "stage", "role", "alternative_of", "period_ns", "latency", "wns", "tns",
                      "whs", "ths", "reg2reg_wns", "reg2reg_tns", "reg2reg_violators", "fmax_r2r_mhz",
                      "min_period_r2r_ns", "skew_setup_ns", "skew_hold_ns", "clock_latency_ns", "power_total_w",
                      "area_um2", "utilization_pct", "synth_area_um2", "cells", "flops", "grt_usage_pct",
                      "grt_overflow"], rows)
    prow = []
    for r in model["runs"]:
        for p in r["critical_paths"]:
            prow.append({"design": r["design"], "pdk": r["pdk"], "stage": r["final_stage"], **p})
    w("critical_paths.csv", ["design", "pdk", "stage", "rank", "group", "slack", "start_register", "end_register",
                             "startpoint", "endpoint",
                             "arrival", "required", "logic_depth", "buffers", "path_delay", "cell_delay",
                             "net_delay", "wire_fraction", "clock_skew", "path_hpwl_um"], prow)
    w("comparisons.csv", list(model["comparisons"][0].keys()) if model["comparisons"] else ["pdk"],
      model["comparisons"])
    arows = []
    for d, a in model.get("audit", {}).items():
        for c in a["candidates"]:
            arows.append({"design": d, "id": c["id"], "category": c["category"], "score": c["score"],
                          "title": c["title"], "location": c["location"], "status": c["status"]})
    w("audit_candidates.csv", ["design", "id", "category", "score", "title", "location", "status"], arows)
    crows = []
    for k, c in model.get("confirmation", {}).items():
        crows.append({"design": c["design"], "pdk": c["pdk"], "stage": c["stage"], "top_overlap": c["top_overlap"],
                      "top_n": c["top_n"], "spearman": c["spearman_est_vs_sta_delay"],
                      "spearman_note": c.get("spearman_note", ""),
                      "matched_registers": c["matched_registers"],
                      "ns_per_unit": c["calibration"].get("ns_per_unit"), "r2": c["calibration"].get("r2"),
                      **{f"n_{s}": n for s, n in c["status_counts"].items()}})
    w("audit_calibration.csv", ["design", "pdk", "stage", "top_overlap", "top_n", "spearman", "spearman_note",
                                "matched_registers", "ns_per_unit", "r2", "n_confirmed", "n_top_ranked_meets_timing",
                                "n_not_critical", "n_not_observed", "n_not_on_critical_path", "n_n/a"], crows)
    return paths


# --------------------------------------------------------------------------- HTML

CSS = """
.tl { color-scheme: light;
  --surface-0:#f6f5f2; --surface-1:#fcfcfb; --border:#dddcd6; --grid:#e8e7e2;
  --text-primary:#0b0b0b; --text-secondary:#52514e; --text-muted:#76756f;
  --series-1:#2a78d6; --series-2:#eb6834; --series-3:#1baf7a;
  --good:#0ca30c; --critical:#d03b3b; --warning:#b47c00; }
@media (prefers-color-scheme: dark) { :root:where(:not([data-theme="light"])) .tl { color-scheme: dark;
  --surface-0:#121211; --surface-1:#1a1a19; --border:#383835; --grid:#2a2a28;
  --text-primary:#f0efec; --text-secondary:#c3c2b7; --text-muted:#9a998f;
  --series-1:#3987e5; --series-2:#d95926; --series-3:#199e70;
  --good:#0ca30c; --critical:#e05a5a; --warning:#fab219; } }
:root[data-theme="dark"] .tl { color-scheme: dark;
  --surface-0:#121211; --surface-1:#1a1a19; --border:#383835; --grid:#2a2a28;
  --text-primary:#f0efec; --text-secondary:#c3c2b7; --text-muted:#9a998f;
  --series-1:#3987e5; --series-2:#d95926; --series-3:#199e70;
  --good:#0ca30c; --critical:#e05a5a; --warning:#fab219; }
html, body { margin:0; background:var(--surface-0); }
.tl { background:var(--surface-0); color:var(--text-primary); font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;
  padding:24px 16px 64px; max-width:1240px; margin:0 auto; }
.tl h1 { font-size:24px; margin:0 0 4px; } .tl h2 { font-size:18px; margin:32px 0 8px; }
.tl h3 { font-size:15px; margin:18px 0 6px; }
.tl p, .tl li { color:var(--text-secondary); }
.tl .card { background:var(--surface-1); border:1px solid var(--border); border-radius:8px; padding:12px 14px; margin:10px 0; overflow-x:auto; }
.tl table { border-collapse:collapse; width:100%; font-size:12.5px; font-variant-numeric:tabular-nums; }
.tl th, .tl td { text-align:left; padding:4px 8px; border-bottom:1px solid var(--grid); vertical-align:top; }
.tl th { color:var(--text-secondary); font-weight:600; position:sticky; top:0; background:var(--surface-1); }
.tl td.num, .tl th.num { text-align:right; }
.tl .muted { color:var(--text-muted); } .tl code { font-size:12px; }
.tl .tiles { display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:10px; }
.tl .tile { background:var(--surface-1); border:1px solid var(--border); border-radius:8px; padding:10px 12px; }
.tl .tile .v { font-size:22px; font-weight:650; } .tl .tile .k { color:var(--text-secondary); font-size:12px; }
.tl .ok::before { content:"\\2714\\FE0E  "; color:var(--good); } .tl .bad::before { content:"\\2716\\FE0E  "; color:var(--critical); }
.tl .warn::before { content:"\\26A0\\FE0E  "; color:var(--warning); }
.tl .legend { display:flex; gap:16px; flex-wrap:wrap; font-size:12px; color:var(--text-secondary); margin:4px 0 6px; }
.tl .sw { display:inline-block; width:10px; height:10px; border-radius:2px; margin-right:6px; vertical-align:middle; }
.tl svg text { fill:var(--text-secondary); font-size:11px; } .tl svg .val { fill:var(--text-primary); }
.tl details summary { cursor:pointer; color:var(--text-secondary); }
.tl .bar:hover { opacity:.8; }
"""


def _bars(groups: list[tuple[str, list[tuple[str, float | None, str]]]], unit: str, width: int = 1100) -> str:
    """Horizontal grouped bars. groups: [(group label, [(series, value, color-var)])]."""
    vals = [v for _, s in groups for _, v, _ in s if v is not None]
    if not vals:
        return "<p class='muted'>no data</p>"
    vmax = max(vals) * 1.15
    bh, gap, ggap, left = 14, 2, 14, 250
    plot_w = width - left - 80
    y = 6
    parts = []
    for gname, series in groups:
        gh = len(series) * (bh + gap)
        parts.append(f"<text x='{left - 10}' y='{y + gh / 2 + 4}' text-anchor='end'>{E(gname)}</text>")
        for sname, v, col in series:
            if v is not None:
                w = max(1.0, plot_w * v / vmax)
                parts.append(f"<rect class='bar' x='{left}' y='{y}' width='{w:.1f}' height='{bh}' rx='3' "
                             f"fill='var({col})'><title>{E(gname)} - {E(sname)}: {v:.1f} {unit}</title></rect>")
                parts.append(f"<text class='val' x='{left + w + 6:.1f}' y='{y + bh - 3}'>{v:.1f}</text>")
            else:
                parts.append(f"<text x='{left + 4}' y='{y + bh - 3}'>n/a</text>")
            y += bh + gap
        y += ggap
    axis = f"<line x1='{left}' y1='0' x2='{left}' y2='{y - ggap}' stroke='var(--border)'/>"
    return f"<svg viewBox='0 0 {width} {y}' width='100%' role='img' aria-label='bar chart ({unit})'>{axis}{''.join(parts)}</svg>"


def _status(ok: bool | None, text: str) -> str:
    if ok is None:
        return f"<span class='warn'>{E(text)}</span>"
    return f"<span class='{'ok' if ok else 'bad'}'>{E(text)}</span>"


def write_html(model: dict[str, Any], out: Path) -> Path:
    runs = model["runs"]
    comps = model["comparisons"]
    by = {(r["design"], r["pdk"]): r for r in runs}
    pdks = sorted({r["pdk"] for r in runs})
    h: list[str] = []
    h.append("<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' "
             "content='width=device-width,initial-scale=1'><title>SilicaFlux TimingLab</title>"
             f"<style>{CSS}</style></head><body><main class='tl'>")
    h.append("<h1>SilicaFlux TimingLab</h1>")
    h.append(f"<p>Static timing analysis of the SilicaFlux 2.x <code>.sf</code> RTL. Generated {E(model['generated'])}. "
             "Every timing number is read from an OpenSTA / OpenROAD report or derived from one "
             "(derived quantities are defined at the end). RTL-audit items are hypotheses until confirmed by STA.</p>")

    # ---- headline tiles
    ok_runs = [r for r in runs if not r.get("error")]
    disc = model.get("discovery") or {}
    best = max(comps, key=lambda c: c.get("fmax_delta_pct") or -1e9) if comps else None
    h.append("<div class='tiles'>")
    for k, v in [("HDL files inventoried", disc.get("hdl_files")), (".sf modules that elaborate",
                 f"{disc.get('sf2_elaborable_modules')} / {disc.get('sf2_modules')}"),
                 ("flow runs (design x PDK)", f"{len(ok_runs)} / {len(runs)}"),
                 ("largest Fmax* gain", f"{best['fmax_delta_pct']:+.1f}%" if best and best.get('fmax_delta_pct') is not None else "—")]:
        h.append(f"<div class='tile'><div class='v'>{E(str(v))}</div><div class='k'>{E(k)}</div></div>")
    h.append("</div>")

    # ---- before / after
    h.append("<h2>Before / after: reg2reg Fmax* per PDK</h2>")
    h.append("<p>Fmax* = 1000 / (T − reg2reg WNS) after global route. Same flow settings, constraints and "
             "register context for every variant; only the RTL (or the upstream configuration parameter) differs.</p>")
    bases = sorted({c["baseline"] for c in comps})
    for b in bases:
        alts = sorted({c["alternative"] for c in comps if c["baseline"] == b},
                      key=lambda a: (by.get((a, pdks[0]), {}).get("role") != "upstream-config", a))
        series_names = [b] + alts
        cols = ["--series-1", "--series-2", "--series-3"]
        legend = "".join(f"<span><span class='sw' style='background:var({cols[i]})'></span>{E(n)}</span>"
                         for i, n in enumerate(series_names[:3]))
        groups = []
        for p in pdks:
            s = []
            for i, n in enumerate(series_names[:3]):
                r = by.get((n, p))
                s.append((n, r["final"].get("fmax_r2r_mhz") if r else None, cols[i]))
            groups.append((f"{p} (T = {_f(by.get((b, p), {}).get('period_ns'), 1)} ns)", s))
        h.append(f"<div class='card'><h3>{E(b)}</h3><div class='legend'>{legend}</div>{_bars(groups, 'MHz')}</div>")
    h.append("<div class='card'><table><tr><th>PDK</th><th>baseline → alternative</th><th class='num'>T [ns]</th>"
             "<th class='num'>r2r WNS before → after [ns]</th><th class='num'>Fmax* before → after [MHz]</th>"
             "<th class='num'>Δ Fmax*</th><th class='num'>area Δ</th><th class='num'>flops</th>"
             "<th class='num'>latency</th><th class='num'>time/op* [ns]</th><th class='num'>depth</th></tr>")
    for c in sorted(comps, key=lambda c: (c["baseline"], c["alternative"], c["pdk"])):
        h.append(f"<tr><td>{E(c['pdk'])}</td><td>{E(c['baseline'])} → {E(c['alternative'])}</td>"
                 f"<td class='num'>{_f(c['period_ns'], 1)}</td>"
                 f"<td class='num'>{_f(c['r2r_wns_before'])} → {_f(c['r2r_wns_after'])}</td>"
                 f"<td class='num'>{_f(c['fmax_before_mhz'], 1)} → {_f(c['fmax_after_mhz'], 1)}</td>"
                 f"<td class='num'><b>{_f(c['fmax_delta_pct'], 1)}%</b></td>"
                 f"<td class='num'>{_f(c['area_delta_pct'], 1)}%</td>"
                 f"<td class='num'>{_f(c['flops_before'])} → {_f(c['flops_after'])}</td>"
                 f"<td class='num'>{_f(c['latency_before'])} → {_f(c['latency_after'])}</td>"
                 f"<td class='num'>{_f(c['time_per_op_before_ns'], 1)} → {_f(c['time_per_op_after_ns'], 1)}</td>"
                 f"<td class='num'>{_f(c['depth_before'])} → {_f(c['depth_after'])}</td></tr>")
    h.append("</table></div>")

    # ---- all runs
    h.append("<h2>All runs (final stage = global route)</h2><div class='card'><table><tr><th>design</th><th>PDK</th>"
             "<th class='num'>T</th><th class='num'>WNS</th><th class='num'>TNS</th><th class='num'>r2r WNS</th>"
             "<th class='num'>Fmax*</th><th class='num'>WHS†</th><th class='num'>skew</th>"
             "<th class='num'>area µm²</th><th class='num'>util %</th><th class='num'>cells</th>"
             "<th class='num'>flops</th><th class='num'>GRT usage %</th><th class='num'>overflow</th>"
             "<th class='num'>power mW</th><th>status</th></tr>")
    for r in sorted(runs, key=lambda r: (r["design"], r["pdk"])):
        m = r["final"]
        pw = m.get("power_total_w")
        st = _status(None, "error: " + r["error"][:60]) if r.get("error") else \
            _status((m.get("reg2reg_wns") or 0) >= 0, "meets T" if (m.get("reg2reg_wns") or 0) >= 0 else "violates T")
        h.append(f"<tr><td>{E(r['design'])}</td><td>{E(r['pdk'])}</td><td class='num'>{_f(r['period_ns'], 1)}</td>"
                 f"<td class='num'>{_f(m.get('wns'))}</td><td class='num'>{_f(m.get('tns'), 1)}</td>"
                 f"<td class='num'>{_f(m.get('reg2reg_wns'))}</td><td class='num'>{_f(m.get('fmax_r2r_mhz'), 1)}</td>"
                 f"<td class='num'>{_f(m.get('whs'))}</td><td class='num'>{_f(m.get('skew_setup_ns'))}</td>"
                 f"<td class='num'>{_f(m.get('area_um2'), 0)}</td><td class='num'>{_f(m.get('utilization_pct'), 0)}</td>"
                 f"<td class='num'>{_f(r['synth']['cells'])}</td><td class='num'>{_f(r['synth']['flops'])}</td>"
                 f"<td class='num'>{_f(r['congestion']['total'].get('usage_pct'), 1)}</td>"
                 f"<td class='num'>{_f(r['congestion']['total'].get('overflow'))}</td>"
                 f"<td class='num'>{_f(pw * 1000 if pw else None, 2)}</td><td>{st}</td></tr>")
    h.append("</table><p class='muted'>† Hold is reported, not repaired, in the experimental PnR flow. "
             "Power uses OpenSTA default activity and is indicative only.</p></div>")

    # ---- critical paths
    h.append("<h2>Critical-path rankings</h2>")
    for r in sorted(runs, key=lambda r: (r["design"], r["pdk"])):
        if not r["critical_paths"]:
            continue
        rc = r["routing_correlation"]
        h.append(f"<details class='card'><summary><b>{E(r['design'])}</b> @ {E(r['pdk'])} — worst "
                 f"{_f(r['critical_paths'][0]['slack'])} ns, depth {r['critical_paths'][0]['logic_depth']}"
                 f" — routing correlation (HPWL vs net delay, top reg2reg paths): "
                 f"ρ = {_f(rc.get('spearman_hpwl_vs_net_delay'), 2)} (n = {rc.get('n')})</summary>"
                 "<table><tr><th>#</th><th>group</th><th class='num'>slack</th><th>start register</th><th>end register</th>"
                 "<th class='num'>depth</th><th class='num'>bufs</th><th class='num'>delay</th>"
                 "<th class='num'>cell</th><th class='num'>net</th><th class='num'>wire %</th>"
                 "<th class='num'>skew</th><th class='num'>HPWL µm</th></tr>")
        for p in r["critical_paths"][:15]:
            h.append(f"<tr><td>{p['rank']}</td><td>{E(p['group'])}</td><td class='num'>{_f(p['slack'])}</td>"
                     f"<td title='{E(p['startpoint'])}'><code>{E(p.get('start_register') or p['startpoint'][:70])}</code></td>"
                     f"<td title='{E(p['endpoint'])}'><code>{E(p.get('end_register') or p['endpoint'][:70])}</code></td>"
                     f"<td class='num'>{p['logic_depth']}</td><td class='num'>{p['buffers']}</td>"
                     f"<td class='num'>{_f(p['path_delay'])}</td><td class='num'>{_f(p['cell_delay'])}</td>"
                     f"<td class='num'>{_f(p['net_delay'])}</td><td class='num'>{_f(100 * p['wire_fraction'], 1)}</td>"
                     f"<td class='num'>{_f(p['clock_skew'])}</td><td class='num'>{_f(p.get('path_hpwl_um'), 1)}</td></tr>")
        h.append("</table></details>")

    # ---- audit vs STA
    h.append("<h2>RTL audit hypotheses and their confirmation</h2>")
    h.append("<p>The audit ranks timing-risk candidates from source and generic-gate structure (unit delay). "
             "Confirmation joins them to STA by RTL register identity.</p><div class='card'><table><tr>"
             "<th>design</th><th>PDK</th><th class='num'>top-10 overlap</th><th class='num'>Spearman ρ</th>"
             "<th class='num'>matched regs</th><th class='num'>ns / gate unit</th><th class='num'>R²</th>"
             "<th>worst STA register</th><th>audit #1 hypothesis → status</th></tr>")
    for k, c in sorted(model.get("confirmation", {}).items()):
        cs = c["candidate_status"][0] if c["candidate_status"] else {}
        h.append(f"<tr><td>{E(c['design'])}</td><td>{E(c['pdk'])}</td><td class='num'>{c['top_overlap']}/{c['top_n']}</td>"
                 f"<td class='num' title='{E(c.get('spearman_note', ''))}'>{_f(c['spearman_est_vs_sta_delay'], 2)}</td><td class='num'>{c['matched_registers']}</td>"
                 f"<td class='num'>{_f(c['calibration'].get('ns_per_unit'), 4)}</td><td class='num'>{_f(c['calibration'].get('r2'), 2)}</td>"
                 f"<td><code>{E((c['sta_top_registers'] or [{}])[0].get('register', '—'))}</code></td>"
                 f"<td>{E(cs.get('title', '—'))} → <b>{E(cs.get('status', '—'))}</b></td></tr>")
    h.append("</table></div>")
    for d, a in sorted(model.get("audit", {}).items()):
        h.append(f"<details class='card'><summary><b>{E(d)}</b>: {a['summary']['generic_gates']} generic gates, "
                 f"max {a['summary']['max_levels']} levels, {a['summary']['latches']} latches, "
                 f"{a['summary']['comb_loops']} loops, clocks {E(str(list(a['summary']['clock_nets'])))}</summary>"
                 "<table><tr><th class='num'>score</th><th>category</th><th>hypothesis</th><th>source</th></tr>")
        for c in a["candidates"][:15]:
            h.append(f"<tr><td class='num'>{c['score']}</td><td>{E(c['category'])}</td><td>{E(c['title'])}</td>"
                     f"<td><code>{E(c['location'])}</code></td></tr>")
        h.append("</table></details>")

    # ---- verification
    v = model.get("verification", {})
    h.append("<h2>Verification and acceptance</h2><div class='card'><table><tr><th>gate</th><th>result</th></tr>")
    acc = v.get("acceptance") or {}
    for alt, g in (acc.get("alternatives") or {}).items():
        for gate, res in g["gates"].items():
            h.append(f"<tr><td>{E(alt)}: {E(gate)}</td><td>{_status(res['pass'], res['detail'])}</td></tr>")
    f = v.get("formal") or {}
    if f:
        ftxt = "%s / %s gating proofs PROVEN; %s / %s seeded-bug witnesses detected" % (
            f.get("gating_proven"), f.get("gating_total"), f.get("witnesses_ok", 0), f.get("witnesses_total", 0))
        fok = f.get("gating_proven") == f.get("gating_total") and f.get("witnesses_ok", 0) == f.get("witnesses_total", 0)
        h.append(f"<tr><td>formal summary</td><td>{_status(fok, ftxt)}</td></tr>")
    for chk in f.get("checks", []):
        if "expect" in chk:
            ok: bool | None = chk["status"] == chk["expect"]
            role = "seeded-bug witness, expected " + chk["expect"]
        else:
            ok = chk["status"] == "PROVEN" or (None if not chk.get("gate", True) else False)
            role = "gating" if chk.get("gate", True) else "additional / stress probe"
        h.append(f"<tr><td>formal: {E(chk['name'])} <small>({E(role)})</small></td>"
                 f"<td>{_status(ok, chk['status'] + ' — ' + chk['claim'])}</td></tr>")
    mu = v.get("mutation") or {}
    if mu:
        txt = "%d / %d mutants killed" % (mu["killed"], mu["total"])
        h.append(f"<tr><td>mutation testing</td><td>{_status(mu['killed'] == mu['total'], txt)}</td></tr>")
    h.append("</table></div>")

    # ---- provenance
    h.append("<h2>Tools, PDKs and definitions</h2><div class='card'><table><tr><th>tool</th><th>version</th></tr>")
    for t, d in model["tools"].items():
        h.append(f"<tr><td>{E(t)}</td><td>{E(d['version'])}</td></tr>")
    h.append("</table><table><tr><th>PDK</th><th>library</th></tr>")
    for k, d in model["pdks"].items():
        h.append(f"<tr><td>{E(k)}</td><td>{E(d or '')}</td></tr>")
    h.append("</table><table><tr><th>derived quantity</th><th>definition</th></tr>")
    for k, d in model["derived_quantities"].items():
        h.append(f"<tr><td>{E(k)}</td><td>{E(d)}</td></tr>")
    h.append("</table></div></main></body></html>")
    p = out / "dashboard.html"
    p.write_text("\n".join(h))
    return p
