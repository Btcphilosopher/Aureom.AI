"""Repository discovery: inventory, definition index, dependency graph,
package-compatibility matrix and testbench/DUT interface checks.

Every fact written by this module is read from a file in the repository
(working tree or archive member) and carries the path, line and SHA-256 of the
file it came from.  Nothing is inferred from file names alone.

Usage:  python -m timinglab discover --repo <Aureom.AI checkout> --out reports/discovery
"""
from __future__ import annotations

import hashlib
import io
import itertools
import json
import os
import re
import shutil
import subprocess
import tarfile
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from . import svscan

HDL_EXT = (".sf", ".sv", ".svh", ".v", ".vh")
ARCHIVE_EXT = (".zip", ".tar.gz", ".tgz")

# Generations of SilicaFlux RTL found in the repository (decided by evidence:
# file extension + package contents, see classify_generation()).
GEN_SF2 = "silicaflux-2.x (.sf)"
GEN_SF1 = "silicaflux-1.0 (.sv)"
GEN_TL1 = "timinglab-v1 archive"
GEN_OTHER_SF = "silicaflux sub-project"
GEN_LIB = "standalone RTL library"
GEN_UNRELATED = "unrelated to SilicaFlux"


@dataclass
class Source:
    path: str               # repo-relative path, or "<archive>!<member>"
    text: str
    sha256: str
    size: int
    origin: str             # "tree" | "archive"
    archive: str = ""
    member: str = ""

    @property
    def ext(self) -> str:
        p = self.member or self.path
        for e in HDL_EXT:
            if p.lower().endswith(e):
                return e
        return ""

    @property
    def lines(self) -> int:
        return self.text.count("\n") + 1

    @property
    def dir(self) -> str:
        if self.origin == "archive":
            return self.archive + "!" + os.path.dirname(self.member)
        return os.path.dirname(self.path)


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _decode(data: bytes) -> str:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1")


def collect_sources(repo: Path, include_archives: bool = True) -> tuple[list[Source], list[dict]]:
    """All HDL files in the working tree and inside .zip / .tar.gz archives."""
    sources: list[Source] = []
    archives: list[dict] = []
    for root, dirs, files in os.walk(repo):
        dirs[:] = sorted(d for d in dirs if d != ".git")
        for f in sorted(files):
            full = Path(root) / f
            rel = str(full.relative_to(repo))
            low = f.lower()
            if low.endswith(HDL_EXT):
                data = full.read_bytes()
                sources.append(Source(rel, _decode(data), _sha(data), len(data), "tree"))
            elif include_archives and low.endswith(ARCHIVE_EXT):
                info = {"path": rel, "sha256": _sha(full.read_bytes()), "hdl_members": 0, "error": ""}
                try:
                    for member, data in _archive_members(full):
                        if member.lower().endswith(HDL_EXT):
                            sources.append(Source(f"{rel}!{member}", _decode(data), _sha(data), len(data),
                                                  "archive", archive=rel, member=member))
                            info["hdl_members"] += 1
                except Exception as e:  # corrupt / unsupported archive: record, do not guess
                    info["error"] = f"{type(e).__name__}: {e}"
                archives.append(info)
    return sources, archives


def _archive_members(path: Path) -> Iterable[tuple[str, bytes]]:
    low = path.name.lower()
    if low.endswith(".zip"):
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if n.endswith("/"):
                    continue
                if n.lower().endswith(HDL_EXT):
                    yield n, z.read(n)
    else:
        with tarfile.open(path) as t:
            for m in t.getmembers():
                if m.isfile() and m.name.lower().endswith(HDL_EXT):
                    fh = t.extractfile(m)
                    if fh is not None:
                        yield m.name, fh.read()


def classify_generation(src: Source) -> str:
    p = src.path.lower()
    if "silicaflux-timinglab.zip" in p:
        return GEN_TL1
    if "silicaflux" not in p and "silica" not in p:
        return GEN_UNRELATED
    if src.ext == ".sf":
        return GEN_SF2
    if "silicaflux.zip!silicaflux/" in p:
        return GEN_SF1
    if any(k in p for k in ("silicaflux-memoryflow", "silicaflux-testcore", "silicafluxai", "silicaflux-powerlink",
                            "silicafluxbitcoinasic", "silicafluxml")):
        return GEN_OTHER_SF
    return GEN_LIB


def is_testbench(defn: svscan.Definition, src: Source) -> bool:
    base = os.path.basename(src.member or src.path).lower()
    return base.startswith("tb_") or defn.name.startswith("tb_") or (
        defn.kind == "module" and not defn.ports and defn.processes and
        any(p.kind == "initial" for p in defn.processes) and not defn.instances == [])


# ---------------------------------------------------------------------------
# Compile matrix (needs full elaboration: pyslang Compilation)
# ---------------------------------------------------------------------------

def compile_set(texts: list[tuple[str, str]], top: str | None = None, max_msgs: int = 12) -> dict[str, Any]:
    import pyslang
    from pyslang import ast as A, syntax as S
    sm = pyslang.SourceManager()
    opts = A.CompilationOptions()
    if top:
        opts.topModules = {top}
    comp = A.Compilation(pyslang.Bag([opts]))
    for name, text in texts:
        comp.addSyntaxTree(S.SyntaxTree.fromText(text, sm, name, name))
    diags = list(comp.getAllDiagnostics())
    errs = [d for d in diags if d.isError()]
    rep = pyslang.DiagnosticEngine.reportAll(sm, errs[:400]) if errs else ""
    msgs = [l for l in rep.splitlines() if ": error:" in l]
    cats: Counter = Counter()
    for m in msgs:
        body = m.split(": error:", 1)[1].strip()
        if body.startswith("unknown module"):
            cats["unknown_module"] += 1
        elif "undeclared identifier" in body:
            cats["undeclared_identifier"] += 1
        elif "no member named" in body:
            cats["missing_package_member"] += 1
        elif "does not exist in" in body and body.startswith("port"):
            cats["port_mismatch"] += 1
        elif "time scale" in body:
            cats["timescale"] += 1
        else:
            cats["other"] += 1
    tops = [i.name for i in comp.getRoot().topInstances]
    return {"errors": len(errs), "categories": dict(cats), "messages": msgs[:max_msgs], "top_instances": tops}


@dataclass
class DefRef:
    src: Source
    defn: svscan.Definition

    @property
    def key(self) -> str:
        return f"{self.defn.kind}:{self.defn.name}@{self.src.path}:{self.defn.line}"


def _referenced_packages(d: svscan.Definition) -> set[str]:
    return set(d.imports) | set(d.scoped_refs)


def build_compile_matrix(defs: list[DefRef], index: dict[str, list[DefRef]], limit: int = 64) -> list[dict]:
    """For every non-testbench .sf module, try each combination of candidate
    package/sub-module definitions and record the slang error count."""
    results = []
    for dr in defs:
        d = dr.defn
        if d.kind != "module" or dr.src.ext != ".sf":
            continue
        # Transitive closure of required names, choosing among candidates.
        needed_pkgs = sorted(_referenced_packages(d))
        # packages defined in the module's own file may reference further packages
        for other in index.values():
            for c in other:
                if c.src is dr.src and c.defn.kind == "package":
                    needed_pkgs = sorted(set(needed_pkgs) | (_referenced_packages(c.defn) - {c.defn.name}))
        needed_mods = sorted({i.module for i in d.instances})
        pkg_cands = {p: [c for c in index.get(p, []) if c.defn.kind == "package" and c.src.ext == ".sf"]
                     for p in needed_pkgs}
        mod_cands = {m: [c for c in index.get(m, []) if c.defn.kind == "module" and c.src.ext == ".sf"]
                     for m in needed_mods}
        # Sub-modules may need further packages (e.g. compute_tile -> alu -> sf_alu_pkg).
        extra_pkgs: set[str] = set()
        for cands in mod_cands.values():
            for c in cands:
                extra_pkgs |= _referenced_packages(c.defn)
        for cands in list(pkg_cands.values()):
            for c in cands:
                extra_pkgs |= _referenced_packages(c.defn) - {c.defn.name}
        for p in sorted(extra_pkgs - set(needed_pkgs)):
            pkg_cands[p] = [c for c in index.get(p, []) if c.defn.kind == "package" and c.src.ext == ".sf"]
        missing = sorted([n for n, c in {**pkg_cands, **mod_cands}.items() if not c])
        axes = [(n, c) for n, c in sorted({**pkg_cands, **mod_cands}.items()) if c]
        combos = list(itertools.product(*[c for _, c in axes])) if axes else [()]
        trials = []
        for combo in combos[:limit]:
            chosen: dict[str, DefRef] = {axes[i][0]: combo[i] for i in range(len(axes))}
            # one file may hold several packages; one source per file
            files: dict[str, Source] = {}
            for c in chosen.values():
                files[c.src.path] = c.src
            files[dr.src.path] = dr.src
            ordered = sorted(files.values(), key=lambda s: (0 if any(
                x.defn.kind == "package" for x in chosen.values() if x.src is s) else 1, s.path))
            ordered = [s for s in ordered if s is not dr.src] + [dr.src]
            r = compile_set([(s.path, s.text) for s in ordered], top=d.name)
            trials.append({"files": [s.path for s in ordered],
                           "choice": {k: v.src.path for k, v in chosen.items()}, **r})
        trials.sort(key=lambda t: t["errors"])
        best = trials[0] if trials else None
        results.append({
            "module": d.name, "source": dr.src.path, "line": d.line,
            "needs_packages": sorted(pkg_cands), "needs_modules": needed_mods, "unresolved": missing,
            "combinations_tried": len(trials), "combinations_total": len(combos),
            "best": best, "elaborates": bool(best and best["errors"] == 0 and not missing),
            "trials": [{"choice": t["choice"], "errors": t["errors"], "categories": t["categories"]}
                       for t in trials],
        })
    return results


# ---------------------------------------------------------------------------
# Testbench / DUT interface check (syntax level, precise for named ports)
# ---------------------------------------------------------------------------

def check_testbenches(tbs: list[DefRef], index: dict[str, list[DefRef]]) -> list[dict]:
    out = []
    seen: set[tuple[str, str]] = set()
    for tb in tbs:
        if (tb.defn.name, tb.src.sha256) in seen:
            continue  # identical copy of a testbench already checked
        seen.add((tb.defn.name, tb.src.sha256))
        for inst in tb.defn.instances:
            if any(c.defn.kind == "interface" for c in index.get(inst.module, [])):
                continue  # testbench-local interface bundle, not a DUT
            cands = [c for c in index.get(inst.module, []) if c.defn.kind == "module"]
            if not cands:
                out.append({"testbench": tb.defn.name, "tb_source": tb.src.path, "line": inst.line,
                            "dut": inst.module, "instance": inst.names[0], "status": "dut_missing"})
                continue
            seen_dut: set[str] = set()
            for c in cands:
                if c.src.sha256 in seen_dut:
                    continue
                seen_dut.add(c.src.sha256)
                dut_ports = {p.name for p in c.defn.ports}
                dut_params = {p.name for p in c.defn.params if not p.local}
                conn = {k for k in inst.connections if not k.startswith("#")}
                unknown_ports = sorted(conn - dut_ports)
                unconnected = sorted(dut_ports - conn) if not inst.wildcard else []
                unknown_params = sorted(set(inst.params) - dut_params)
                status = "compatible" if not unknown_ports and not unknown_params else "interface_mismatch"
                out.append({"testbench": tb.defn.name, "tb_source": tb.src.path, "line": inst.line,
                            "dut": inst.module, "instance": inst.names[0], "dut_source": c.src.path,
                            "dut_line": c.defn.line, "status": status,
                            "tb_ports_not_in_dut": unknown_ports, "dut_ports_left_open": unconnected,
                            "tb_params_not_in_dut": unknown_params,
                            "port_overlap": len(conn & dut_ports), "tb_ports": len(conn),
                            "dut_ports": len(dut_ports)})
    return out


# ---------------------------------------------------------------------------
# Clock / reset architecture (syntax level, works on non-elaborable tops)
# ---------------------------------------------------------------------------

def clock_reset_view(dr: DefRef) -> dict[str, Any]:
    d = dr.defn
    es = d.edge_signals()
    clock_like = set(d.clock_ports()) | {re.split(r"[\[\.]", c)[0] for c in es["clocks"]}
    inst_clocks = []
    for inst in d.instances:
        clk_conns = {}
        rst_conns = {}
        for port, expr in inst.connections.items():
            ids = set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", expr))
            if svscan.CLOCK_RE.search(port) or ids & clock_like:
                if ids & clock_like or svscan.CLOCK_RE.search(expr):
                    clk_conns[port] = expr
            if svscan.RESET_RE.search(port) and not svscan.CLOCK_RE.search(port):
                rst_conns[port] = expr
        if clk_conns or rst_conns:
            inst_clocks.append({"instance": inst.names[0], "module": inst.module, "line": inst.line,
                                "clock_connections": clk_conns, "reset_connections": rst_conns})
    ff_by_clock: Counter = Counter()
    async_ff = 0
    for p in d.processes:
        if p.kind in ("always_ff", "always"):
            clks = [e for e in p.events if not svscan.RESET_RE.search(e.split()[-1]) or svscan.CLOCK_RE.search(e)]
            for c in clks:
                ff_by_clock[c] += 1
            if len(p.events) > len(clks):
                async_ff += 1
    return {"module": d.name, "source": dr.src.path, "clock_ports": d.clock_ports(),
            "reset_ports": d.reset_ports(), "edge_clocks": sorted(es["clocks"]),
            "edge_async_resets": sorted(es["async_resets"]), "processes_by_edge": dict(ff_by_clock),
            "async_reset_processes": async_ff, "instances": inst_clocks,
            "latch_processes": sum(1 for p in d.processes if p.kind == "always_latch")}


# ---------------------------------------------------------------------------
# Graph output
# ---------------------------------------------------------------------------

def _dot_id(s: str) -> str:
    return '"' + s.replace('"', r'\"') + '"'


def write_dot(path: Path, defs: list[DefRef], index: dict[str, list[DefRef]], tb_checks: list[dict],
              matrix: list[dict], title: str, rtl_only: bool = False) -> None:
    elab = {(m["module"], m["source"]): m for m in matrix}
    if rtl_only:
        # compact view: no testbenches, one node per distinct (name, content)
        seen: set[tuple[str, str]] = set()
        keep = []
        for dr in defs:
            if is_testbench(dr.defn, dr.src) or dr.defn.kind == "interface":
                continue
            k = (dr.defn.name, dr.src.sha256)
            if k in seen:
                continue
            seen.add(k)
            keep.append(dr)
        defs = keep
    lines = ["digraph silicaflux {", f'  label={_dot_id(title)}; labelloc=t; fontsize=18;',
             "  rankdir=LR; node [shape=box, fontname=Helvetica, fontsize=10]; edge [fontsize=8];"]
    by_dir: dict[str, list[DefRef]] = defaultdict(list)
    for dr in defs:
        by_dir[dr.src.dir or "."].append(dr)
    node_ids: dict[str, str] = {}
    for ci, (dname, items) in enumerate(sorted(by_dir.items())):
        lines.append(f"  subgraph cluster_{ci} {{ label={_dot_id(dname)}; style=rounded; color=gray60;")
        for dr in items:
            nid = f"n{len(node_ids)}"
            node_ids[dr.key] = nid
            d = dr.defn
            label = f"{d.kind} {d.name}\\n{os.path.basename(dr.src.member or dr.src.path)}:{d.line}"
            style = 'style=filled, fillcolor="#eef3fb"'
            if d.kind == "package":
                style = 'shape=folder, style=filled, fillcolor="#f6f0e0"'
            if d.name.startswith("tb_") or os.path.basename(dr.src.member or dr.src.path).startswith("tb_"):
                style = 'shape=note, style=filled, fillcolor="#f0f0f0"'
            m = elab.get((d.name, dr.src.path))
            if m is not None:
                if m["elaborates"]:
                    style = 'style="filled,bold", fillcolor="#d8f0d8"'
                    label += "\\n[elaborates]"
                else:
                    style = 'style=filled, fillcolor="#fbe3e3"'
                    label += f"\\n[{m['best']['errors'] if m['best'] else '?'} errors]"
            lines.append(f"    {nid} [label={_dot_id(label)}, {style}];")
        lines.append("  }")
    missing_nodes: dict[str, str] = {}
    for dr in defs:
        src_id = node_ids[dr.key]
        for inst in dr.defn.instances:
            cands = [c for c in index.get(inst.module, []) if c.defn.kind in ("module", "interface")
                     and c.key in node_ids]
            if not cands and any(c.defn.kind in ("module", "interface") for c in index.get(inst.module, [])):
                continue      # defined, but outside this (compact) view
            if not cands:
                if inst.module not in missing_nodes:
                    mid = f"miss{len(missing_nodes)}"
                    missing_nodes[inst.module] = mid
                    lines.append(f'  {mid} [label={_dot_id("MISSING module " + inst.module)}, '
                                 'shape=box, style="dashed,filled", fillcolor="#ffd6d6", color=red];')
                lines.append(f'  {src_id} -> {missing_nodes[inst.module]} [color=red, style=dashed, '
                             f'label={_dot_id(inst.names[0])}];')
            for c in cands:
                lab = inst.names[0] + (" (one of %d)" % len(cands) if len(cands) > 1 else "")
                tbc = [t for t in tb_checks if t["tb_source"] == dr.src.path and t.get("dut_source") == c.src.path
                       and t["instance"] == inst.names[0]]
                color = "black"
                if tbc and tbc[0]["status"] != "compatible":
                    color = "red"
                    lab += f"\\nports mismatch ({len(tbc[0]['tb_ports_not_in_dut'])})"
                lines.append(f"  {src_id} -> {node_ids[c.key]} [label={_dot_id(lab)}, color={color}];")
        for p in sorted(_referenced_packages(dr.defn)):
            cands = [c for c in index.get(p, []) if c.defn.kind == "package" and c.key in node_ids]
            for c in cands:
                lines.append(f"  {src_id} -> {node_ids[c.key]} [style=dotted, color=gray40, arrowhead=empty"
                             + (f", label={_dot_id('one of %d' % len(cands))}" if len(cands) > 1 else "") + "];")
            if not cands:
                key = "pkg:" + p
                if key not in missing_nodes:
                    mid = f"miss{len(missing_nodes)}"
                    missing_nodes[key] = mid
                    lines.append(f'  {mid} [label={_dot_id("MISSING package " + p)}, shape=folder, '
                                 'style="dashed,filled", fillcolor="#ffd6d6", color=red];')
                lines.append(f"  {src_id} -> {missing_nodes[key]} [style=dotted, color=red];")
    lines.append("}")
    path.write_text("\n".join(lines) + "\n")


def render_svg(dot_path: Path) -> str:
    dot = shutil.which("dot") or (os.environ.get("TL_DOT") or "")
    for cand in (dot, "/opt/tl/eda-cf/bin/dot"):
        if cand and Path(cand).exists():
            svg = dot_path.with_suffix(".svg")
            r = subprocess.run([cand, "-Tsvg", str(dot_path), "-o", str(svg)], capture_output=True, text=True)
            return str(svg) if r.returncode == 0 else f"dot failed: {r.stderr[:200]}"
    return "graphviz not found"


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def discover(repo: Path, out: Path, compile_matrix: bool = True, reuse_matrix: bool = False) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    sources, archives = collect_sources(repo)
    scans: dict[str, svscan.FileScan] = {}
    for s in sources:
        scans[s.path] = svscan.scan_text(s.text, s.path)

    by_sha: dict[str, list[str]] = defaultdict(list)
    for s in sources:
        by_sha[s.sha256].append(s.path)

    all_defs: list[DefRef] = []
    for s in sources:
        for d in scans[s.path].definitions:
            all_defs.append(DefRef(s, d))
    index: dict[str, list[DefRef]] = defaultdict(list)
    for dr in all_defs:
        index[dr.defn.name].append(dr)

    gen_of = {s.path: classify_generation(s) for s in sources}

    def dialect(s: Source) -> str:
        if s.ext != ".sf":
            return "systemverilog" if s.ext in (".sv", ".svh") else "verilog"
        fs = scans[s.path]
        if fs.syntax_errors == 0:
            return "systemverilog-2017"
        head = s.text[:3000]
        if "SilicaFlux-ML" in head or "DSL" in head:
            return "silicaflux-ml-dsl-sketch (self-declared non-parseable)"
        return "non-hdl-model (not SystemVerilog)"
    dialect_of = {s.path: dialect(s) for s in sources}
    for s in sources:
        if s.ext == ".sf" and not dialect_of[s.path].startswith("systemverilog"):
            gen_of[s.path] = GEN_UNRELATED if gen_of[s.path] == GEN_UNRELATED else GEN_OTHER_SF

    inventory = []
    for s in sources:
        fs = scans[s.path]
        inventory.append({
            "path": s.path, "origin": s.origin, "ext": s.ext, "sha256": s.sha256, "bytes": s.size,
            "lines": s.lines, "generation": gen_of[s.path], "dialect": dialect_of[s.path],
            "syntax_errors": fs.syntax_errors,
            "first_syntax_errors": fs.first_errors, "language_banner": fs.language_banner,
            "timescale": fs.timescale, "duplicates": [p for p in by_sha[s.sha256] if p != s.path],
            "definitions": [{"kind": d.kind, "name": d.name, "line": d.line, "end_line": d.end_line}
                            for d in fs.definitions],
        })

    sf2 = [dr for dr in all_defs if gen_of[dr.src.path] == GEN_SF2]
    sf2_index: dict[str, list[DefRef]] = defaultdict(list)
    for dr in sf2:
        sf2_index[dr.defn.name].append(dr)

    # Name collisions inside the .sf generation (same name, different content)
    collisions = []
    for name, drs in sorted(sf2_index.items()):
        shas = {dr.src.sha256 for dr in drs}
        if len(drs) > 1:
            collisions.append({"name": name, "kind": drs[0].defn.kind, "definitions": len(drs),
                               "distinct_files": len(shas),
                               "where": [f"{dr.src.path}:{dr.defn.line}" for dr in drs]})

    # Missing references in the .sf generation
    missing_modules: dict[str, list[str]] = defaultdict(list)
    for dr in sf2:
        for inst in dr.defn.instances:
            if not any(c.defn.kind in ("module", "interface") for c in sf2_index.get(inst.module, [])):
                elsewhere = sorted({c.src.path for c in index.get(inst.module, [])})
                missing_modules[inst.module].append(f"{dr.src.path}:{inst.line}" +
                                                    (f" (name exists only in: {', '.join(elsewhere)})" if elsewhere else ""))

    tbs = [dr for dr in sf2 if dr.defn.kind == "module" and is_testbench(dr.defn, dr.src)]
    tb_checks = check_testbenches(tbs, sf2_index)

    rtl_sf2 = [dr for dr in sf2 if dr.defn.kind == "module" and not is_testbench(dr.defn, dr.src)]
    # de-duplicate identical files for the matrix (same content => same result)
    seen: set[tuple[str, str]] = set()
    uniq = []
    for dr in rtl_sf2:
        k = (dr.defn.name, dr.src.sha256)
        if k not in seen:
            seen.add(k)
            uniq.append(dr)
    prev = out / "discovery.json"
    if reuse_matrix and prev.exists():
        matrix = json.loads(prev.read_text()).get("compile_matrix", [])
    else:
        matrix = build_compile_matrix(uniq, sf2_index) if compile_matrix else []

    clocking = [clock_reset_view(dr) for dr in uniq]

    modules = []
    for dr in uniq:
        d = dr.defn
        modules.append({
            "module": d.name, "source": dr.src.path, "line": d.line, "end_line": d.end_line,
            "sha256": dr.src.sha256, "duplicates": [p for p in by_sha[dr.src.sha256] if p != dr.src.path],
            "ports": [{"name": p.name, "dir": p.direction, "decl": p.decl} for p in d.ports],
            "params": [{"name": p.name, "default": p.default, "local": p.local} for p in d.params],
            "imports": d.imports, "scoped_refs": d.scoped_refs,
            "instances": [{"module": i.module, "name": i.names[0], "line": i.line} for i in d.instances],
            "process_counts": dict(Counter(p.kind for p in d.processes)),
            "generate_constructs": d.generate_blocks,
            "doc": d.doc[:3000],
        })

    gen_counts = Counter(gen_of.values())
    ext_counts = Counter(s.ext for s in sources)
    summary = {
        "repo": str(repo), "hdl_files": len(sources),
        "hdl_files_in_tree": sum(1 for s in sources if s.origin == "tree"),
        "hdl_files_in_archives": sum(1 for s in sources if s.origin == "archive"),
        "archives_scanned": len(archives), "by_extension": dict(ext_counts),
        "by_generation": dict(gen_counts),
        "unique_contents": len(by_sha),
        "sf_files": sum(1 for s in sources if s.ext == ".sf"),
        "sf_syntax_clean": sum(1 for s in sources if s.ext == ".sf" and scans[s.path].syntax_errors == 0),
        "sf_dialects": dict(Counter(dialect_of[s.path] for s in sources if s.ext == ".sf")),
        "sf_language_banners": dict(Counter(scans[s.path].language_banner for s in sources if s.ext == ".sf")),
        "sf2_modules": len(uniq), "sf2_elaborable_modules": sum(1 for m in matrix if m["elaborates"]),
        "sf2_testbench_instantiations": len(tb_checks),
        "sf2_testbench_compatible": sum(1 for t in tb_checks if t["status"] == "compatible"),
        "sf2_missing_modules": len(missing_modules),
        "sf2_name_collisions": len(collisions),
    }
    result = {"summary": summary, "archives": archives, "inventory": inventory, "modules": modules,
              "collisions": collisions, "missing_modules": dict(missing_modules),
              "testbench_checks": tb_checks, "compile_matrix": matrix, "clock_reset": clocking}
    (out / "discovery.json").write_text(json.dumps(result, indent=1))

    write_dot(out / "sf2_dependency_graph.dot", sf2, sf2_index, tb_checks, matrix,
              "SilicaFlux 2.x (.sf) - source-backed dependency graph (green: elaborates, red: does not)")
    result["svg"] = render_svg(out / "sf2_dependency_graph.dot")
    write_dot(out / "sf2_rtl_graph.dot", sf2, sf2_index, tb_checks, matrix,
              "SilicaFlux 2.x RTL (no testbenches, duplicates collapsed) - green: elaborates, red: does not",
              rtl_only=True)
    render_svg(out / "sf2_rtl_graph.dot")
    sf1 = [dr for dr in all_defs if gen_of[dr.src.path] == GEN_SF1]
    if sf1:
        sf1_index: dict[str, list[DefRef]] = defaultdict(list)
        for dr in sf1:
            sf1_index[dr.defn.name].append(dr)
        write_dot(out / "sf1_dependency_graph.dot", sf1, sf1_index, [], [],
                  "SilicaFlux 1.0 (.sv, silicaflux.zip) - dependency graph")
        render_svg(out / "sf1_dependency_graph.dot")
    _write_csv(out / "inventory.csv", inventory)
    return result


def _write_csv(path: Path, rows: list[dict]) -> None:
    import csv
    cols = ["path", "origin", "ext", "dialect", "generation", "lines", "bytes", "syntax_errors", "language_banner",
            "sha256", "definitions"]
    with path.open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in rows:
            w.writerow([r["path"], r["origin"], r["ext"], r["dialect"], r["generation"], r["lines"], r["bytes"],
                        r["syntax_errors"], r["language_banner"], r["sha256"],
                        ";".join(f"{d['kind']}:{d['name']}" for d in r["definitions"])])
