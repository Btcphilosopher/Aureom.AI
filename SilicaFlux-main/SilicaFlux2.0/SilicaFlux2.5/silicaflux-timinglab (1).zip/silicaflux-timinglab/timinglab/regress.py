"""Acceptance gates for every proposed optimisation (flow/designs.toml entries
with role = "timinglab" or "upstream-config" and an alternative_of baseline).

Gates, in order (task specification section 7):
  1 syntax_elab   slang elaborates the alternative with 0 errors (pyslang)
  2 lint          verilator -Wall: 0 errors, no warning class absent from the baseline
  3 functional    every equivalence-bench configuration PASSes (tb/equiv)
  4 formal        every required formal check of the alternative is PROVEN (the
                  combinational proofs of its building blocks and an UNBOUNDED
                  sequential equivalence proof against the upstream block, by
                  k-induction or PDR, whichever closes), and
                  every seeded-bug witness of its sequential miter FAILS
                  (n/a for upstream-config alternatives: same RTL as baseline)
  5 synthesis     synthesised on every PDK: no latches, no combinational loops
  6 timing        reg2reg WNS after global route improves on EVERY PDK
  7 ppa           comparison table complete, and synthesis is reproducible
                  (re-running Yosys on the same elaborated design gives a
                  byte-identical netlist)
"""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

from . import config, discovery, tools
from .flow import common, synth

FORMAL_FOR = {"vector_engine_pipe": ["mul_lo_W8", "csa_W32_N5", "csa_W8_N8", "reduce_W32_N4", "reduce_W8_N8",
                                     "reduce_W4_N16", "vector_kind_L4_W8"],
              "sf_alu_mulcsa": ["mul_lo_W8", "csa_W8_N8", "alu_pdr_X8"]}
# further evidence, reported in the gate detail but not required
FORMAL_EXTRA = {"vector_engine_pipe": ["vector_pdr_L4_W8", "vector_bmc_L4_W8"],
                "sf_alu_mulcsa": ["alu_kind_X8", "alu_abcbmc_X8", "alu_bmc_X8"]}
# seeded-bug witnesses: the sequential miter of the required unbounded proof, with one
# deliberate bug, must FAIL
WITNESS_FOR = {"vector_engine_pipe": ["vector_kind_L4_W8__bug"],
               "sf_alu_mulcsa": ["alu_pdr_X8__bug"]}
BENCH_FOR = {"vector_engine_pipe": "tb_eq_vector", "sf_alu_mulcsa": "tb_eq_alu"}


def gate_elab(d: config.Design) -> dict[str, Any]:
    texts = [config.resolve_source(s) for s in d.files]
    r = discovery.compile_set([(n, b.decode()) for n, b in texts], top=d.top)
    return {"pass": r["errors"] == 0, "detail": f"slang: {r['errors']} errors, top {r['top_instances']}"}


def reproducible_synth(cat: config.Catalogue, name: str, pdk: str) -> dict[str, Any]:
    rd = common.RUNS / pdk / name
    if not (rd / "netlist.v").exists():
        return {"pass": False, "detail": "no netlist"}
    tmp = common.RUNS / "_repro" / pdk / name
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    for f in ("elab.il", "top.txt", "sources.json"):
        shutil.copy(rd / f, tmp / f)
    d, p = cat.design(name), cat.pdk(pdk)
    r = synth.synthesize(d, p, tmp)
    h1 = hashlib.sha256((rd / "netlist.v").read_bytes()).hexdigest()
    h2 = hashlib.sha256((tmp / "netlist.v").read_bytes()).hexdigest() if r["ok"] else ""
    return {"pass": h1 == h2, "detail": f"netlist sha256 {h1[:12]} vs re-run {h2[:12]}", "sha256": h1}


def accept(cat: config.Catalogue, reports: Path, results: dict[str, Any] | None = None,
           repro_pdk: str = "sky130hd") -> dict[str, Any]:
    lint = json.loads((reports / "verification" / "lint.json").read_text()) \
        if (reports / "verification" / "lint.json").exists() else {}
    equiv = json.loads((reports / "verification" / "equiv.json").read_text()) \
        if (reports / "verification" / "equiv.json").exists() else {}
    formal = json.loads((reports / "formal" / "formal.json").read_text()) \
        if (reports / "formal" / "formal.json").exists() else {"checks": []}
    if results is None:
        results = json.loads((reports / "dashboard" / "timinglab_results.json").read_text())
    runs = {(r["design"], r["pdk"]): r for r in results["runs"]}
    comps = results["comparisons"]
    pdks = cat.defaults.get("pdks", list(cat.pdks))
    out: dict[str, Any] = {"alternatives": {}, "tools": {t: tools.version(t) for t in ("yosys", "verilator", "openroad")}}
    for name, d in cat.designs.items():
        if not d.baseline:
            continue
        g: dict[str, Any] = {}
        g["1_syntax_elab"] = gate_elab(d)
        li = lint.get(name)
        g["2_lint"] = {"pass": bool(li) and li.get("gate") == "PASS",
                       "detail": (f"{li['errors']} errors, new warning classes vs {d.baseline}: "
                                  f"{li.get('new_warning_classes_vs_baseline') or 'none'}") if li else "lint not run"}
        if d.role == "upstream-config":
            g["3_functional"] = {"pass": None, "detail": "same RTL as baseline (parameter change only); "
                                                        "exercised as the EX_STAGES=2 reference of tb_eq_vector"
                                 if name == "vector_engine_ex2" else "same RTL as baseline"}
            g["4_formal"] = {"pass": None, "detail": "n/a (upstream RTL unchanged)"}
        else:
            b = equiv.get(BENCH_FOR.get(name, ""), {})
            cfgs = {k: v for k, v in b.items()} if isinstance(b, dict) else {}
            ok = bool(cfgs) and all(v["pass"] for v in cfgs.values())
            nruns = sum(len(v["runs"]) for v in cfgs.values())
            g["3_functional"] = {"pass": ok, "detail": f"{BENCH_FOR.get(name)}: {len(cfgs)} configurations, "
                                                       f"{nruns} seeded runs, all PASS" if ok else
                                 f"{BENCH_FOR.get(name)}: FAILED or not run"}
            want = FORMAL_FOR.get(name, [])
            have = {c["name"]: c["status"] for c in formal.get("checks", [])}
            proven = [w for w in want if have.get(w) == "PROVEN"]
            extra = FORMAL_EXTRA.get(name, [])
            wit = WITNESS_FOR.get(name, [])
            wit_ok = [w for w in wit if have.get(w) == "FAILED"]
            g["4_formal"] = {"pass": len(proven) == len(want) and bool(want) and len(wit_ok) == len(wit),
                             "detail": f"{len(proven)}/{len(want)} required proofs PROVEN: " +
                                       ", ".join(f"{w}={have.get(w, 'not run')}" for w in want) +
                                       f"; seeded-bug witnesses {len(wit_ok)}/{len(wit)} found a counterexample" +
                                       ("; additional: " + ", ".join(f"{w}={have.get(w, 'not run')}" for w in extra)
                                        if extra else "")}
        syn = [runs.get((name, p)) for p in pdks]
        ok = all(r and not r.get("error") and (r["synth"].get("latches") or 0) == 0 for r in syn)
        g["5_synthesis"] = {"pass": ok, "detail": "; ".join(
            f"{p}: {'ok' if r and not r.get('error') else 'missing/failed'}, latches={r['synth'].get('latches') if r else '-'}"
            for p, r in zip(pdks, syn))}
        cs = [c for c in comps if c["alternative"] == name]
        better = [c for c in cs if c["r2r_wns_after"] is not None and c["r2r_wns_before"] is not None
                  and c["r2r_wns_after"] > c["r2r_wns_before"]]
        g["6_timing"] = {"pass": len(cs) == len(pdks) and len(better) == len(cs),
                         "detail": "; ".join(f"{c['pdk']}: {c['r2r_wns_before']:.3f} -> {c['r2r_wns_after']:.3f} ns "
                                             f"({c['fmax_delta_pct']:+.1f}% Fmax*)" for c in cs)}
        rep = reproducible_synth(cat, name, repro_pdk)
        g["7_ppa"] = {"pass": rep["pass"] and len(cs) == len(pdks),
                      "detail": f"{len(cs)} PDK comparisons; reproducible synthesis on {repro_pdk}: {rep['detail']}"}
        verdict = all(v["pass"] in (True, None) for v in g.values())
        out["alternatives"][name] = {"baseline": d.baseline, "role": d.role, "gates": g,
                                     "accepted": verdict}
    (reports / "regression").mkdir(parents=True, exist_ok=True)
    (reports / "regression" / "acceptance.json").write_text(json.dumps(out, indent=1))
    return out
