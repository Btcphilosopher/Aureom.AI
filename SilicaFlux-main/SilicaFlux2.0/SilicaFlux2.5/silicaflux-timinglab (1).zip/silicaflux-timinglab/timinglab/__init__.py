"""SilicaFlux TimingLab: static timing analysis and RTL optimisation for the
SilicaFlux 2.x (.sf, SystemVerilog-2017) architecture."""
__version__ = "2.0.0"
