"""Parsers for the files written by flow/sta/tl_report.tcl.

Only values present in the reports are returned; derived quantities (logic
depth, cell/wire split, Fmax*) are computed here from the per-point arrival
times and are labelled as derived in the output (`derived` key)."""
from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any

_REG_CLK_PINS = re.compile(r"/(CLK|CK|CLKN|GATE|GATE_N|E|G|CP|CLK_N)$")


def _f(x: str) -> float | None:
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def parse_paths(path: Path) -> list[dict[str, Any]]:
    paths: list[dict[str, Any]] = []
    cur: dict[str, Any] | None = None
    if not path.exists():
        return paths
    for line in path.read_text().splitlines():
        f = line.split("\t")
        if f[0] == "PATH":
            cur = {"kind": f[1], "rank": int(f[2]), "group": f[3], "slack": _f(f[4]),
                   "startpoint": f[5], "endpoint": f[6], "start_clock": f[7], "end_clock": f[8],
                   "arrival": _f(f[9]) if len(f) > 9 else None, "required": _f(f[10]) if len(f) > 10 else None,
                   "launch_clock_latency": _f(f[11]) if len(f) > 11 else None,
                   "capture_clock_latency": _f(f[12]) if len(f) > 12 else None,
                   "check_margin": _f(f[13]) if len(f) > 13 else None, "points": []}
            paths.append(cur)
        elif f[0] == "PT" and cur is not None:
            inst, _, ref = f[3].partition(":") if f[3] != "-" else ("", "", "")
            cur["points"].append({"pin": f[1], "dir": f[2], "inst": inst, "ref": ref,
                                  "arrival": _f(f[4]), "slew": _f(f[5]) if len(f) > 5 else None})
    for p in paths:
        p.update(derive(p))
    return paths


def derive(p: dict[str, Any]) -> dict[str, Any]:
    """Logic depth, cell vs. net delay, buffer count, clock skew for one path."""
    pts = p["points"]
    if not pts:
        return {"derived": {}}
    start_inst = pts[0]["inst"] if pts[0]["inst"] and "/" in pts[0]["pin"] else ""
    end_inst = pts[-1]["inst"] if pts[-1]["inst"] and "/" in pts[-1]["pin"] else ""
    cell_d = net_d = 0.0
    comb: list[str] = []
    bufs = 0
    for a, b in zip(pts, pts[1:]):
        if a["arrival"] is None or b["arrival"] is None:
            continue
        d = b["arrival"] - a["arrival"]
        if a["inst"] and a["inst"] == b["inst"]:
            cell_d += d
            if b["dir"] == "output" and b["inst"] not in (start_inst, end_inst):
                comb.append(b["ref"])
                if re.search(r"(^|_)(buf|clkbuf|inv|clkinv|dlygate|dlya|dly)", b["ref"].split("__")[-1]):
                    bufs += 1
        else:
            net_d += d
    t0 = pts[0]["arrival"] or 0.0
    t1 = pts[-1]["arrival"] or 0.0
    total = t1 - t0
    skew = None
    if p.get("launch_clock_latency") is not None and p.get("capture_clock_latency") is not None:
        skew = p["capture_clock_latency"] - p["launch_clock_latency"]
    return {"derived": {
        "logic_depth": len(comb),                       # combinational cells between launch and capture
        "logic_depth_excl_buffers": len(comb) - bufs,
        "buffers": bufs,
        "path_delay": round(total, 6),                  # launch point to endpoint
        "cell_delay": round(cell_d, 6),
        "net_delay": round(net_d, 6),
        "wire_fraction": round(net_d / total, 4) if total > 0 else 0.0,
        "clock_skew": round(skew, 6) if skew is not None else None,
        "cells": comb,
    }}


def parse_summary(path: Path) -> dict[str, Any]:
    out: dict[str, Any] = {"groups": {"max": {}, "min": {}}}
    if not path.exists():
        return out
    for line in path.read_text().splitlines():
        f = line.split("\t")
        if f[0] == "worst_slack":
            out[f"worst_slack_{f[1]}"] = _f(f[2])
        elif f[0] == "tns":
            out[f"tns_{f[1]}"] = _f(f[2])
        elif f[0] == "group":
            out["groups"][f[1]][f[2]] = {"wns": _f(f[3]), "tns": _f(f[4]), "violators": int(f[5]),
                                         "endpoints": int(f[6]) if len(f) > 6 else None}
        elif f[0] == "endpoints":
            out[f"endpoints_{f[1]}"] = int(f[2])
    return out


def parse_skew(path: Path) -> dict[str, Any]:
    """report_clock_skew: worst setup / hold skew per clock."""
    out: dict[str, Any] = {}
    if not path.exists():
        return out
    txt = path.read_text()
    vals = []
    for blk in re.split(r"(?=Clock\s+\S+)", txt):
        m = re.match(r"Clock\s+(\S+)", blk)
        if not m:
            continue
        nums = re.findall(r"^\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s*$", blk, re.M)
        if nums:
            lat, crpr, sk = (float(x) for x in nums[-1])
            vals.append({"clock": m.group(1), "latency": lat, "crpr": crpr, "skew": sk})
    if vals:
        out["setup"] = vals[0]
        if len(vals) > 1:
            out["hold"] = vals[1]
    return out


def parse_power(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    m = re.search(r"^Total\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)\s+([0-9.eE+-]+)", path.read_text(), re.M)
    if not m:
        return {}
    return {"internal_w": float(m.group(1)), "switching_w": float(m.group(2)),
            "leakage_w": float(m.group(3)), "total_w": float(m.group(4))}


def parse_drv(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    txt = path.read_text()
    out = {}
    for k in ("slew", "capacitance", "fanout"):
        m = re.search(rf"max {k} violations?\s*(?:count)?\s*[:=]?\s*(\d+)", txt, re.I)
        if m:
            out[f"max_{k}_violations"] = int(m.group(1))
    # fall back: count violator lines (pin  limit  value  slack VIOLATED)
    out.setdefault("violated_lines", len(re.findall(r"\(VIOLATED\)|VIOLATED", txt)))
    return out


def parse_stage(outdir: Path, period: float, keep_points: int = 25) -> dict[str, Any]:
    summ = parse_summary(outdir / "summary.tsv")
    paths = parse_paths(outdir / "paths.tsv")
    setup = [p for p in paths if p["kind"] == "max"]
    hold = [p for p in paths if p["kind"] == "min"]
    r2r = summ["groups"]["max"].get("reg2reg", {})
    wns_r2r = r2r.get("wns")
    res: dict[str, Any] = {
        "period_ns": period,
        "wns": summ.get("worst_slack_max"), "tns": summ.get("tns_max"),
        "whs": summ.get("worst_slack_min"), "ths": summ.get("tns_min"),
        "groups": summ["groups"],
        "reg2reg_wns": wns_r2r, "reg2reg_tns": r2r.get("tns"),
        "skew": parse_skew(outdir / "skew.rpt"),
        "power": parse_power(outdir / "power.rpt"),
        "drv": parse_drv(outdir / "drv.rpt"),
    }
    if wns_r2r is not None:
        # derived: minimum reg2reg period this netlist would meet with the same
        # uncertainty/setup assumptions
        res["fmax_r2r_mhz"] = round(1000.0 / (period - wns_r2r), 3) if period - wns_r2r > 0 else None
        res["min_period_r2r_ns"] = round(period - wns_r2r, 4)
    res["paths"] = []
    for p in sorted(setup, key=lambda x: (x["slack"] if x["slack"] is not None else 1e9)):
        q = {k: v for k, v in p.items() if k != "points"}
        q["points"] = p["points"] if len(res["paths"]) < keep_points else []
        res["paths"].append(q)
    res["hold_paths"] = [{k: v for k, v in p.items() if k != "points"}
                         for p in sorted(hold, key=lambda x: (x["slack"] if x["slack"] is not None else 1e9))[:50]]
    return res
