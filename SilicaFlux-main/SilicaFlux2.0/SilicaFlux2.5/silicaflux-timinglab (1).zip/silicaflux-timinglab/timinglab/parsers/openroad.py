"""Parsers for OpenROAD logs and reports (area, global-route congestion)."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def parse_area(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    m = re.search(r"Design area\s+([0-9.]+)\s+u\^2\s+([0-9.]+)%\s+utilization", path.read_text())
    return {"design_area_um2": float(m.group(1)), "utilization_pct": float(m.group(2))} if m else {}


def parse_areas_from_log(log: str) -> dict[str, dict[str, float]]:
    """report_design_area prints through the OpenROAD logger (not redirected to
    files), so take the values from the log, in stage order."""
    out: dict[str, dict[str, float]] = {}
    marks = [(m.start(), m.group(1)) for m in re.finditer(r"TL-STAGE: (\S+)", log)]
    for m in re.finditer(r"Design area\s+([0-9.]+)\s+u\^2\s+([0-9.]+)%\s+utilization", log):
        stage = "floorplan"
        for pos, name in marks:
            if pos < m.start():
                stage = name
        key = {"floorplan": "floorplan", "global_placement": "place", "repair_design": "place",
               "detailed_placement": "place", "cts": "cts", "global_route": "grt"}.get(stage, stage)
        out[key] = {"design_area_um2": float(m.group(1)), "utilization_pct": float(m.group(2))}
    return out


def parse_congestion(report: Path, log: str) -> dict[str, Any]:
    """Global-route resource usage per layer (from the GRT log table) and the
    number of overflowing GCells (congestion report file)."""
    out: dict[str, Any] = {"layers": [], "total": {}, "overflow_gcells": 0}
    # FastRoute prints:  Layer  Resource  Demand  Usage (%)  Max H / Max V / Total Overflow
    blk = None
    for m in re.finditer(r"Final congestion report:(.*?)(?:\n\s*\n|\[INFO GRT-0018\]|Total wirelength)", log, re.S):
        blk = m.group(1)
    if blk:
        for line in blk.splitlines():
            f = line.split()
            if len(f) >= 7 and re.match(r"^[0-9]+$", f[1] or "") and f[0] not in ("Layer", "----"):
                try:
                    rec = {"layer": f[0], "resource": int(f[1]), "demand": int(f[2]),
                           "usage_pct": float(f[3].rstrip("%")), "overflow": int(f[-1])}
                except ValueError:
                    continue
                (out["total"].update(rec) if f[0] == "Total" else out["layers"].append(rec))
    m = re.search(r"Total wirelength:\s*([0-9.]+)\s*um", log)
    if m:
        out["wirelength_um"] = float(m.group(1))
    if report.exists():
        txt = report.read_text()
        out["overflow_gcells"] = len(re.findall(r"violation type|Overflow|bbox", txt, re.I))
    return out


def parse_log(log: str) -> dict[str, Any]:
    out: dict[str, Any] = {}
    m = re.findall(r"Inserted (\d+) buffers", log)
    if m:
        out["buffers_inserted"] = sum(int(x) for x in m)
    m = re.search(r"\[INFO CTS-\d+\]\s+Number of sinks covered:\s*(\d+)", log) or \
        re.search(r"Total number of sinks:\s*(\d+)", log)
    if m:
        out["cts_sinks"] = int(m.group(1))
    m = re.findall(r"\[INFO CTS-\d+\]\s+(\d+) clock buffers? inserted", log) or \
        re.findall(r"Clock buffers? inserted:?\s*(\d+)", log, re.I)
    if m:
        out["cts_buffers"] = sum(int(x) for x in m)
    m = re.search(r"TritonCTS found (\d+) clock nets", log)
    if m:
        out["cts_clock_nets"] = int(m.group(1))
    m = re.search(r"Total number of Sinks:\s*(\d+)", log)
    if m:
        out["cts_total_sinks"] = int(m.group(1))
    m = re.search(r"Total number of Buffers Inserted:\s*(\d+)", log)
    if m:
        out["cts_buffers_inserted"] = int(m.group(1))
    m = re.search(r"TL-CLOCK-ROOT: removed (\d+)", log)
    if m:
        out["clock_root_buffers_removed"] = int(m.group(1))
    out["warnings"] = len(re.findall(r"^\[WARNING", log, re.M))
    out["errors"] = len(re.findall(r"^\[ERROR", log, re.M))
    stages = re.findall(r"TL-STAGE: (\S+) (\S+)", log)
    out["stage_times"] = stages
    return out


def parse_path_cells(path: Path) -> list[dict[str, Any]]:
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text().splitlines():
        f = line.split("\t")
        if len(f) == 4:
            rows.append({"endpoint": f[0], "inst": f[1], "x": float(f[2]), "y": float(f[3])})
    return rows
