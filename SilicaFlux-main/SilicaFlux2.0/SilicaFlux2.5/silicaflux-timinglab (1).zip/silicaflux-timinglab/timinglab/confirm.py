"""Confirm (or refute) RTL-audit hypotheses with STA results.

Join key: RTL register identity. Both the audit gate netlist and the mapped
netlist of a flow run are named by the same rule (audit/netlist.bit_label),
so an STA endpoint cell maps to the same register name the audit used.

Outputs per (design, pdk):
  * candidate status: confirmed / not_critical / not_observed / n/a
  * register-ranking agreement: top-10 overlap, Spearman rank correlation
  * calibration: least-squares ns-per-gate-unit factor and R^2 between the
    audit's unit-delay estimate and the STA path delay of the same endpoints
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

from .audit import netlist as NL


def _stage(res: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    pt = res.get("stages", {}).get("pnr", {}).get("timing", {})
    for st in ("grt", "cts", "place"):
        if st in pt:
            return st, pt[st]
    return "synth", res.get("stages", {}).get("sta", {}).get("timing", {})


def _rank(vals: list[float]) -> list[float]:
    order = sorted(range(len(vals)), key=lambda i: vals[i])
    r = [0.0] * len(vals)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and vals[order[j + 1]] == vals[order[i]]:
            j += 1
        for k in range(i, j + 1):
            r[order[k]] = (i + j) / 2.0
        i = j + 1
    return r


def spearman(x: list[float], y: list[float]) -> float | None:
    if len(x) < 3:
        return None
    rx, ry = _rank(x), _rank(y)
    mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = math.sqrt(sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry))
    return round(num / den, 4) if den else None


def _rho_note(x: list[float], y: list[float]) -> str:
    """Why a rank correlation is (un)defined - an undefined rho is not a weak rho."""
    if len(x) < 3:
        return f"undefined: only {len(x)} registers appear in both the audit and the reported STA paths"
    if len(set(x)) == 1:
        return (f"undefined: the audit gives all {len(x)} matched registers the same estimate "
                "(regular pipeline), so it cannot rank them")
    if len(set(y)) == 1:
        return "undefined: identical STA path delays"
    return f"{len(x)} matched registers, {len(set(x))} distinct audit estimates"


def fit(x: list[float], y: list[float]) -> dict[str, Any]:
    """y = k x through the origin (ns per gate unit) and R^2."""
    if len(x) < 3:
        return {}
    sxx = sum(a * a for a in x)
    if sxx == 0:
        return {}
    k = sum(a * b for a, b in zip(x, y)) / sxx
    my = sum(y) / len(y)
    ss_tot = sum((b - my) ** 2 for b in y)
    ss_res = sum((b - k * a) ** 2 for a, b in zip(x, y))
    return {"ns_per_unit": round(k, 5), "r2": round(1 - ss_res / ss_tot, 4) if ss_tot else None, "n": len(x)}


def sta_register_view(rd: Path, res: dict[str, Any], block_ports: set[str],
                      path_regs: list[dict[str, Any]] | None = None) -> tuple[str, dict[str, dict[str, Any]]]:
    stage, timing = _stage(res)
    top = res.get("stages", {}).get("synth", {}).get("top") or res["top"]
    nl = NL.load(rd / "netlist.json", top, mapped=True)
    wrapped = top == "tl_wrap"
    fmap = NL.ff_map(nl, strip_prefix="u_dut." if wrapped else "", avoid=block_ports)
    regs: dict[str, dict[str, Any]] = {}
    for p in timing.get("paths", []):
        if p.get("slack") is None:
            continue
        ep = p["endpoint"]
        cell = ep.rsplit("/", 1)[0] if "/" in ep else ""
        if cell in fmap:
            reg = fmap[cell]["reg"]
            if reg.startswith("ctx:"):
                # wrapper output flop <port>_q captures block output <port>
                name = reg[4:]
                base = NL.reg_group(name)
                port = base[:-2] if base.endswith("_q") else base
                key = "out:" + port
            else:
                key = NL.reg_group(reg)
        else:
            key = "out:" + NL.reg_group(ep) if "/" not in ep else "cell:" + cell
        sp = p["startpoint"]
        scell = sp.rsplit("/", 1)[0] if "/" in sp else ""
        start = fmap.get(scell, {}).get("reg", sp)
        if path_regs is not None and len(path_regs) < 40:
            # RTL register identity of the path ends (instance names from Yosys autoname
            # are derived from neighbouring nets and do not identify the register)
            path_regs.append({"rank": len(path_regs) + 1, "slack": p["slack"], "start_register": start,
                              "end_register": key})
        r = regs.setdefault(key, {"group": p["group"], "slack": p["slack"], "path_delay": p["derived"]["path_delay"],
                                  "logic_depth": p["derived"]["logic_depth"], "startpoint": start, "bits": 0})
        r["bits"] += 1
        if p["slack"] < r["slack"]:
            r.update(slack=p["slack"], path_delay=p["derived"]["path_delay"],
                     logic_depth=p["derived"]["logic_depth"], startpoint=start, group=p["group"])
    return stage, regs


def confirm(audit: dict[str, Any], rd: Path, top_n: int = 10) -> dict[str, Any]:
    res = json.loads((rd / "result.json").read_text())
    ports = {p["name"] for p in res.get("stages", {}).get("elab", {}).get("block_ports", [])}
    path_regs: list[dict[str, Any]] = []
    stage, sta_regs = sta_register_view(rd, res, ports, path_regs)
    aud = {}
    for g in audit["register_ranking"]:
        aud[g["register"]] = g     # output endpoints are already named "out:<port>"
    # Alias-aware join. One flop can carry several RTL names (`assign r2 = r2_q`); the
    # audit netlist and the mapped netlist may keep different ones, and the audit may
    # split one STA register into groups (r2 = data bits, r2_q = the valid bit, which
    # r2.vld redefines). An audit register therefore matches every STA register that has
    # its name or one of its aliases; its STA view is the worst of those.
    names_of = {k: [k] + [a for a in g.get("aliases", []) if a != k] for k, g in aud.items()}
    aud_of: dict[str, list[str]] = {}            # STA register -> audit registers it matches
    for k, ns in names_of.items():
        for n in ns:
            if n in sta_regs:
                aud_of.setdefault(n, []).append(k)

    def sta_for(k: str) -> tuple[str, dict[str, Any]] | None:
        hits = [(n, sta_regs[n]) for n in names_of.get(k, [k]) if n in sta_regs]
        return min(hits, key=lambda h: h[1]["slack"]) if hits else None

    sta_sorted = sorted(sta_regs.items(), key=lambda kv: kv[1]["slack"])
    sta_rank = {k: i + 1 for i, (k, _) in enumerate(sta_sorted)}
    aud_sorted = sorted(aud.items(), key=lambda kv: -kv[1]["worst_est_delay"])
    sta_top = [k for k, _ in sta_sorted[:top_n]]
    aud_top = [k for k, _ in aud_sorted[:top_n]]
    common = [k for k in aud if sta_for(k)]
    x = [aud[k]["worst_est_delay"] for k in common]
    y = [sta_for(k)[1]["path_delay"] for k in common]       # type: ignore[index]
    sta_top_as_aud = {a for s in sta_top for a in aud_of.get(s, [])}
    overlap = len(sta_top_as_aud & set(aud_top))
    period = float(res.get("period_ns") or 0.0)
    margin = 0.10 * period
    # "critical" = STA says the path limits timing: negative slack or within 10 % of T
    sta_crit_regs = {k for k, v in sta_regs.items() if v["slack"] < margin}
    crit_trails: dict[str, list[str]] = {}
    top_trails: dict[str, list[str]] = {}
    for sk in sta_top:
        for k in aud_of.get(sk, []):
            for s in aud[k]["src_trail"]:
                top_trails.setdefault(s, []).append(sk)
                if sk in sta_crit_regs:
                    crit_trails.setdefault(s, []).append(sk)

    statuses = []
    for c in audit["candidates"]:
        st, ev = "n/a", {}
        m = c.get("match", {})
        if c["category"] == "critical_path":
            hit = sta_for(m.get("endpoint_register", ""))
            if hit:
                sk, v = hit
                st = ("confirmed" if sk in sta_crit_regs else
                      "top_ranked_meets_timing" if sk in sta_top else "not_critical")
                ev = {"sta_register": sk, "sta_slack": v["slack"], "sta_rank": sta_rank[sk],
                      "sta_logic_depth": v["logic_depth"], "sta_path_delay": v["path_delay"]}
            else:
                st = "not_observed"
        elif m.get("src"):
            hits = crit_trails.get(m["src"], [])
            tops = top_trails.get(m["src"], [])
            st = "confirmed" if hits else ("top_ranked_meets_timing" if tops else "not_on_critical_path")
            ev = {"critical_registers_through_src": hits[:5], "top_registers_through_src": tops[:5]}
        elif m.get("net") is not None:
            base = NL.reg_group(m["net"].split("[")[0])
            tops = [k for k, v in sta_sorted[:top_n] if base and base in str(v.get("startpoint", ""))]
            hits = [k for k in tops if k in sta_crit_regs]
            st = "confirmed" if hits else ("top_ranked_meets_timing" if tops else "not_on_critical_path")
            ev = {"critical_registers_started_by_net": hits[:5], "top_registers_started_by_net": tops[:5]}
        statuses.append({"id": c["id"], "category": c["category"], "title": c["title"], "score": c["score"],
                         "status": st, "evidence": ev})
    counts: dict[str, int] = {}
    for s in statuses:
        counts[s["status"]] = counts.get(s["status"], 0) + 1
    return {
        "design": res["design"], "pdk": res["pdk"], "stage": stage,
        "sta_top_registers": [{"register": k, **v} for k, v in sta_sorted[:top_n]],
        "path_registers": path_regs,
        "audit_top_registers": [{"register": k, "est_delay": v["worst_est_delay"], "levels": v["worst_levels"]}
                                for k, v in aud_sorted[:top_n]],
        "top_overlap": overlap, "top_n": top_n, "critical_margin_ns": round(margin, 3),
        "sta_critical_registers": len(sta_crit_regs),
        "spearman_est_vs_sta_delay": spearman(x, y), "spearman_note": _rho_note(x, y),
        "matched_registers": len(common),
        "calibration": fit(x, y), "candidate_status": statuses, "status_counts": counts,
    }
