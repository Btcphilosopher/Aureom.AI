"""Source-level (syntax) timing-risk patterns, via pyslang.

Patterns are hypotheses about the logic synthesis will build:
  loop_reductions  for-loop that accumulates into one variable (x += ...,
                   x = x + ...): elaborates to a LINEAR chain of N adders
                   unless the tool rebalances it (Yosys does not).
  wide_cases       case statements with many items (wide multiplexers)
  ternary_chains   nested ?: (priority mux chains)
  multipliers      every '*' (informational; widths come from the netlist)
  latch_processes  always_latch
"""
from __future__ import annotations

import re
from typing import Any

import pyslang
from pyslang import syntax as S

from .. import config

SK = S.SyntaxKind
VA = pyslang.ast.VisitAction


def _txt(n) -> str:
    return re.sub(r"\s+", " ", re.sub(r"//[^\n]*|/\*.*?\*/", " ", str(n), flags=re.S)).strip()


def _ternary_depth(n) -> int:
    d = 0
    cur = n
    while cur is not None and cur.kind == SK.ConditionalExpression:
        d += 1
        nxt = None
        for child in (getattr(cur, "right", None), getattr(cur, "left", None)):
            if child is not None and getattr(child, "kind", None) == SK.ConditionalExpression:
                nxt = child
                break
            if child is not None and getattr(child, "kind", None) == SK.ParenthesizedExpression and \
                    getattr(child.expression, "kind", None) == SK.ConditionalExpression:
                nxt = child.expression
                break
        cur = nxt
    return d


def scan_text(text: str, path: str) -> dict[str, list[dict[str, Any]]]:
    sm = pyslang.SourceManager()
    tree = S.SyntaxTree.fromText(text, sm, path, path)

    def loc(n) -> str:
        try:
            return f"{path}:{sm.getLineNumber(n.sourceRange.start)}"
        except Exception:
            return path

    out: dict[str, list[dict[str, Any]]] = {"loop_reductions": [], "wide_cases": [], "ternary_chains": [],
                                            "multipliers": [], "latch_processes": []}
    seen_tern: set[str] = set()

    def in_comb_context(n) -> bool:
        p = n.parent
        while p is not None:
            k = p.kind
            if k in (SK.AlwaysCombBlock, SK.FunctionDeclaration, SK.AlwaysBlock, SK.AlwaysFFBlock,
                     SK.ContinuousAssign):
                return k != SK.AlwaysFFBlock
            p = p.parent
        return False

    def cb(n):
        k = n.kind
        if k == SK.ForLoopStatement and in_comb_context(n):
            body = n.statement
            acc = []

            def bcb(m):
                if m.kind == SK.AddAssignmentExpression or m.kind == SK.SubtractAssignmentExpression:
                    acc.append(("+=", _txt(m)))
                elif m.kind == SK.AssignmentExpression:
                    lhs = _txt(m.left)
                    rhs = _txt(m.right)
                    base = re.escape(re.split(r"[\[\.]", lhs)[0])
                    if re.search(rf"(^|[^A-Za-z0-9_]){base}\s*[\[\.]?.*[+\-]|[+\-].*(^|[^A-Za-z0-9_]){base}\b", rhs) \
                            and re.search(r"[+\-]", rhs):
                        acc.append(("x=x+", _txt(m)))
                return VA.Advance
            if body is not None:
                body.visit(bcb)
            if acc:
                hdr = _txt(n)[:160]
                out["loop_reductions"].append({"location": loc(n), "op": acc[0][0], "text": acc[0][1][:160],
                                               "loop": hdr.split(")")[0] + ")"})
        elif k == SK.CaseStatement:
            items = [i for i in n.items if getattr(i, "kind", None) in (SK.StandardCaseItem, SK.DefaultCaseItem,
                                                                         SK.PatternCaseItem)]
            nlabels = 0
            for i in items:
                exprs = getattr(i, "expressions", None)
                nlabels += len([e for e in exprs if hasattr(e, "kind")]) if exprs is not None else 1
            if nlabels >= 16:
                out["wide_cases"].append({"location": loc(n), "items": nlabels,
                                          "selector": _txt(n.expr)[:80]})
        elif k == SK.ConditionalExpression:
            d = _ternary_depth(n)
            l = loc(n)
            if d >= 4 and l not in seen_tern:
                seen_tern.add(l)
                out["ternary_chains"].append({"location": l, "depth": d, "text": _txt(n)[:160]})
        elif k == SK.MultiplyExpression:
            out["multipliers"].append({"location": loc(n), "text": _txt(n)[:120]})
        elif k == SK.AlwaysLatchBlock:
            out["latch_processes"].append({"location": loc(n)})
        return VA.Advance

    tree.root.visit(cb)
    return out


def scan_design_sources(design: config.Design) -> dict[str, list[dict[str, Any]]]:
    agg: dict[str, list[dict[str, Any]]] = {}
    for spec in design.files:
        disp, data = config.resolve_source(spec)
        r = scan_text(data.decode("utf-8", "replace"), disp)
        for k, v in r.items():
            agg.setdefault(k, []).extend(v)
    return agg
