"""Gate-level graph analysis of a Yosys JSON netlist.

Used twice:
  * on the technology-independent gate netlist produced by the RTL audit
    (unit-delay logic depth, fanout, loops, clock / reset structure), and
  * on the mapped netlist of a flow run, to map STA endpoint cells back to RTL
    register names (ff_map) for audit confirmation.
"""
from __future__ import annotations

import json
import math
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Relative delay of generic Yosys gates in "gate units" (a NAND2 ~ 1). These
# are deliberately coarse: the audit produces hypotheses that STA confirms.
GATE_DELAY = {
    "$_NOT_": 0.6, "$_BUF_": 0.6,
    "$_AND_": 1.2, "$_OR_": 1.2, "$_NAND_": 1.0, "$_NOR_": 1.0,
    "$_ANDNOT_": 1.2, "$_ORNOT_": 1.2,
    "$_XOR_": 1.8, "$_XNOR_": 1.8,
    "$_MUX_": 1.8, "$_NMUX_": 1.6,
    "$_AOI3_": 1.3, "$_OAI3_": 1.3, "$_AOI4_": 1.5, "$_OAI4_": 1.5,
}
SEQ_RE = re.compile(r"^\$_(S?DFF|DFFE|SDFF|SDFFE|SDFFCE|ALDFF|ALDFFE|DFFSR|DFFSRE|DLATCH|SR)_")
LATCH_RE = re.compile(r"^\$_DLATCH|^\$_SR_|^\$_DLATCHSR")
# mapped std cells: any cell with a pin named CLK/CK/CLK_N/CP/... is sequential
MAPPED_CLK_PINS = ("CLK", "CK", "CLK_N", "CP", "CPN", "GATE", "GATE_N", "G", "GN", "E")


def fanout_penalty(fo: int) -> float:
    return 0.25 * math.log2(fo) if fo > 1 else 0.0


@dataclass
class Gate:
    name: str
    type: str
    ins: list[int]
    outs: list[int]
    src: str
    pins_in: dict[str, list[int]] = field(default_factory=dict)
    pins_out: dict[str, list[int]] = field(default_factory=dict)


class Netlist:
    def __init__(self, data: dict[str, Any], top: str, mapped: bool = False):
        self.top = top
        mod = data["modules"][top]
        self.mapped = mapped
        self.ports = mod["ports"]
        self.netnames = mod["netnames"]
        self.bitname: dict[int, list[tuple[str, int]]] = defaultdict(list)
        for name, nn in self.netnames.items():
            for i, b in enumerate(nn["bits"]):
                if isinstance(b, int):
                    off = nn.get("offset", 0)
                    self.bitname[b].append((name, i + off if not nn.get("upto") else i))
        self.gates: list[Gate] = []
        self.driver: dict[int, int] = {}
        self.sinks: dict[int, list[tuple[int, str]]] = defaultdict(list)
        for cname, c in mod["cells"].items():
            dirs = c.get("port_directions", {})
            ins, outs, pin_in, pin_out = [], [], {}, {}
            for p, bits in c["connections"].items():
                ibits = [b for b in bits if isinstance(b, int)]
                d = dirs.get(p, "input")
                if d == "output":
                    outs += ibits
                    pin_out[p] = ibits
                else:
                    ins += ibits
                    pin_in[p] = ibits
            g = Gate(cname, c["type"], ins, outs, c.get("attributes", {}).get("src", ""), pin_in, pin_out)
            gi = len(self.gates)
            self.gates.append(g)
            for b in outs:
                self.driver[b] = gi
            for p, bits in pin_in.items():
                for b in bits:
                    self.sinks[b].append((gi, p))
        self.inputs = {b for p in self.ports.values() if p["direction"] == "input" for b in p["bits"] if isinstance(b, int)}
        self.outputs = {b for p in self.ports.values() if p["direction"] == "output" for b in p["bits"] if isinstance(b, int)}
        self.port_names = set(self.ports)

    # ------------------------------------------------------------------ naming
    def bit_label(self, b: int, prefer_prefix: str = "", avoid: set[str] | None = None) -> str:
        """Deterministic RTL name for a net bit.

        Preference: names under `prefer_prefix`; then names that are not in
        `avoid` (block port names, so a register is named after the register,
        not the output port it drives); public before generated ($) names;
        shorter; lexicographic."""
        names = self.bitname.get(b, [])
        if not names:
            return f"<bit{b}>"
        av = avoid or set()

        def key(t):
            n = t[0]
            base = n[len(prefer_prefix):] if prefer_prefix and n.startswith(prefer_prefix) else n
            return (0 if (not prefer_prefix or n.startswith(prefer_prefix)) else 1,
                    1 if base in av else 0, n.startswith("$"), "$" in n, len(n), n)
        n, i = sorted(names, key=key)[0]
        w = len(self.netnames[n]["bits"])
        return f"{n}[{i}]" if w > 1 else n

    def is_seq(self, g: Gate) -> bool:
        if self.mapped:
            return any(p in g.pins_in for p in MAPPED_CLK_PINS) and bool(g.outs)
        return bool(SEQ_RE.match(g.type))

    # ------------------------------------------------------------------ depth
    def depth_analysis(self, k_paths: int = 200) -> dict[str, Any]:
        """Unit-delay longest path to every timing endpoint (FF data/enable
        pins, primary outputs). Startpoints: FF outputs, primary inputs."""
        seq = [i for i, g in enumerate(self.gates) if self.is_seq(g)]
        seqset = set(seq)
        arr: dict[int, float] = {}
        lvl: dict[int, int] = {}
        pred: dict[int, int | None] = {}
        start_of: dict[int, str] = {}
        for b in self.inputs:
            arr[b], lvl[b], pred[b] = 0.0, 0, None
            start_of[b] = "in:" + self.bit_label(b)
        for gi in seq:
            for b in self.gates[gi].outs:
                arr[b], lvl[b], pred[b] = 1.0, 0, None    # clock-to-Q ~ 1 unit
                start_of[b] = "ff:" + self.bit_label(b)
        fo = {b: len(s) for b, s in self.sinks.items()}
        # iterative DFS topological evaluation over combinational gates
        state: dict[int, int] = {}   # 1 visiting, 2 done
        loops: list[list[str]] = []
        sys_limit = len(self.gates) + 10

        def eval_bit(b0: int) -> None:
            stack = [(b0, False)]
            while stack:
                b, expanded = stack.pop()
                if b in arr and state.get(b) != 1:
                    continue
                gi = self.driver.get(b)
                if gi is None or gi in seqset:
                    arr.setdefault(b, 0.0); lvl.setdefault(b, 0); pred.setdefault(b, None)
                    start_of.setdefault(b, "const/undriven")
                    continue
                g = self.gates[gi]
                if not expanded:
                    if state.get(b) == 1:
                        continue
                    state[b] = 1
                    stack.append((b, True))
                    for ib in g.ins:
                        if ib in arr:
                            continue
                        if state.get(ib) == 1:
                            loops.append([self.bit_label(ib), g.name])
                            continue
                        stack.append((ib, False))
                else:
                    best, bl, bp = 0.0, 0, None
                    for ib in g.ins:
                        a = arr.get(ib)
                        if a is None:
                            continue  # loop-breaking input
                        if a > best or bp is None:
                            best, bl, bp = a, lvl.get(ib, 0), ib
                    d = GATE_DELAY.get(g.type, 1.0) + fanout_penalty(fo.get(b, 1))
                    for ob in g.outs:
                        arr[ob] = best + d
                        lvl[ob] = bl + 1
                        pred[ob] = bp
                        start_of[ob] = start_of.get(bp, "const/undriven") if bp is not None else "const/undriven"
                        state[ob] = 2
                    state[b] = 2

        endpoints: list[tuple[str, int, str]] = []   # (kind, bit, label)
        for gi in seq:
            g = self.gates[gi]
            for p, bits in g.pins_in.items():
                if self.mapped and p in MAPPED_CLK_PINS:
                    continue
                if not self.mapped and p in ("C", "CLK"):
                    continue
                for b in bits:
                    endpoints.append((f"ff:{p}", b, g.name))
        for b in self.outputs:
            endpoints.append(("out", b, self.bit_label(b)))
        for _, b, _ in endpoints:
            if b not in arr:
                eval_bit(b)
        res = []
        for kind, b, owner in endpoints:
            if b not in arr:
                continue
            # reconstruct path
            path_bits, cur, guard = [], b, 0
            while cur is not None and guard < sys_limit:
                path_bits.append(cur)
                cur = pred.get(cur)
                guard += 1
            srcs = []
            for pb in path_bits:
                gi = self.driver.get(pb)
                if gi is not None and self.gates[gi].src:
                    s = self.gates[gi].src
                    if not srcs or srcs[-1] != s:
                        srcs.append(s)
            res.append({"kind": kind, "endpoint_bit": b, "endpoint_cell": owner if kind != "out" else "",
                        "endpoint": self._endpoint_label(kind, b, owner),
                        "est_delay": round(arr[b], 3), "levels": lvl.get(b, 0),
                        "startpoint": start_of.get(b, "?"), "src_trail": list(reversed(srcs))[:40]})
        res.sort(key=lambda r: -r["est_delay"])
        return {"endpoints": res, "loops": loops[:50], "n_seq": len(seq),
                "n_comb": len(self.gates) - len(seq)}

    def q_aliases(self, owner: str) -> list[str]:
        """Every public RTL name (register group) of the net driven by FF `owner`'s Q.
        RTL aliases such as `assign r2 = r2_q` give one flop several names; a later
        netlist (after ABC / opt_clean) may keep a different one, so confirmation
        matches on any of them."""
        if not hasattr(self, "_by_name"):
            self._by_name = {g.name: g for g in self.gates}
        g = self._by_name.get(owner)
        if g is None or not g.outs:
            return []
        q = g.pins_out.get("Q", g.outs)[0]
        return sorted({reg_group(n) for n, _ in self.bitname.get(q, [])
                       if not n.startswith("$") and "$" not in n and n not in self.port_names})

    def _endpoint_label(self, kind: str, b: int, owner: str) -> str:
        if kind == "out":
            return "out:" + self.bit_label(b)
        # name an FF endpoint after the register its Q drives
        if not hasattr(self, "_by_name"):
            self._by_name = {g.name: g for g in self.gates}
        g = self._by_name.get(owner)
        if g is not None and g.outs:
            q = g.pins_out.get("Q", g.outs)[0]
            return f"ff:{self.bit_label(q, avoid=self.port_names)}.{kind[3:]}"
        return f"ff:{owner}.{kind[3:]}"

    # ------------------------------------------------------------------ fanout
    def fanout(self, threshold: int = 32, top: int = 40) -> list[dict[str, Any]]:
        rows = []
        for b, s in self.sinks.items():
            n = len(s)
            if n < threshold:
                continue
            gi = self.driver.get(b)
            drv = self.gates[gi] if gi is not None else None
            scopes = set()
            lines = set()
            for si, _ in s:
                sg = self.gates[si]
                lab = self.bit_label(sg.outs[0]) if sg.outs else sg.name
                m = re.findall(r"([A-Za-z_][A-Za-z0-9_]*\[\d+\])\.", lab)
                scopes.add(".".join(m) if m else "-")
                if sg.src:
                    lines.add(sg.src.split("|")[0].split(".")[0])
            rows.append({"net": self.bit_label(b), "fanout": n,
                         "driver": ("in:" + self.bit_label(b)) if b in self.inputs else
                                   (f"{drv.type}:{drv.name}" if drv else "?"),
                         "driver_src": drv.src if drv else "", "driver_is_ff": bool(drv and self.is_seq(drv)),
                         "sink_scopes": len(scopes), "sink_src_lines": len(lines)})
        rows.sort(key=lambda r: -r["fanout"])
        return rows[:top]

    # ------------------------------------------------------------ clocks/resets
    def clock_reset(self) -> dict[str, Any]:
        clocks: dict[str, int] = defaultdict(int)
        resets: dict[str, int] = defaultdict(int)
        for g in self.gates:
            if not self.is_seq(g):
                continue
            for p in ("C", "CLK", "CK", "CLK_N"):
                for b in g.pins_in.get(p, []):
                    clocks[self.bit_label(b)] += 1
            for p in ("R", "S", "RESET_B", "SET_B", "RN", "SN", "AD"):
                if p in g.pins_in and (g.type.startswith(("$_DFF_P", "$_DFF_N", "$_DFFE_", "$_DFFSR", "$_ALDFF"))
                                       or self.mapped):
                    for b in g.pins_in[p]:
                        resets[self.bit_label(b)] += 1
        return {"clock_nets": dict(clocks), "async_reset_nets": dict(resets)}

    def cdc_crossings(self) -> list[dict[str, Any]]:
        """FF -> (comb) -> FF edges whose clocks differ (only meaningful when the
        block has more than one clock net)."""
        clk_of: dict[int, str] = {}
        for gi, g in enumerate(self.gates):
            if self.is_seq(g):
                for p in ("C", "CLK", "CK"):
                    if p in g.pins_in:
                        clk_of[gi] = self.bit_label(g.pins_in[p][0])
        if len(set(clk_of.values())) < 2:
            return []
        out = []
        for gi, g in enumerate(self.gates):
            if gi not in clk_of:
                continue
            for b in g.pins_in.get("D", []):
                # walk back through comb logic to source FFs
                seen, stack, srcs = set(), [b], set()
                while stack:
                    x = stack.pop()
                    if x in seen:
                        continue
                    seen.add(x)
                    d = self.driver.get(x)
                    if d is None:
                        continue
                    if d in clk_of:
                        srcs.add(d)
                        continue
                    stack.extend(self.gates[d].ins)
                for s in srcs:
                    if clk_of[s] != clk_of[gi]:
                        out.append({"from": self.gates[s].name, "from_clock": clk_of[s], "to": g.name,
                                    "to_clock": clk_of[gi], "direct": self.driver.get(b) == s})
        return out[:200]


def load(path: Path, top: str, mapped: bool = False) -> Netlist:
    return Netlist(json.loads(path.read_text()), top, mapped)


def ff_map(nl: Netlist, strip_prefix: str = "u_dut.", avoid: set[str] | None = None) -> dict[str, dict[str, Any]]:
    """mapped/generic FF cell name -> RTL register name, bit, src.
    Registers outside `strip_prefix` (the TimingLab context wrapper) are named
    'ctx:<name>'."""
    out = {}
    for g in nl.gates:
        if not nl.is_seq(g) or not g.outs:
            continue
        q = None
        for p in ("Q", "Q_N", "QN"):
            if p in g.pins_out:
                q = g.pins_out[p][0]
                break
        if q is None:
            q = g.outs[0]
        lab = nl.bit_label(q, prefer_prefix=strip_prefix, avoid=avoid)
        if strip_prefix and not lab.startswith(strip_prefix):
            reg = "ctx:" + lab
        else:
            reg = normalise_reg(lab, strip_prefix)
        out[g.name] = {"reg": reg, "src": g.src, "type": g.type}
    return out


def normalise_reg(label: str, strip_prefix: str = "u_dut.") -> str:
    lab = label
    if strip_prefix and lab.startswith(strip_prefix):
        lab = lab[len(strip_prefix):]
    return lab


def reg_group(label: str) -> str:
    """Register bus identity: 'u.foo_q[12]' and the bit-blasted mapped-netlist
    form 'u.foo_q_12_' (Yosys splitnets -format __) both become 'u.foo_q'."""
    return re.sub(r"(\[\d+\]|_\d+_)$", "", label)
