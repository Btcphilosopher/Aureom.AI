"""RTL timing-risk audit.

Produces reports/audit/<design>/rtl_audit.json: a ranked list of timing-risk
CANDIDATES. Every candidate carries status "hypothesis" until
timinglab.confirm matches it against OpenSTA / OpenROAD results.

Evidence layers
  1. source (pyslang syntax): loop-accumulated reductions (linear adder
     chains), wide case statements, deep ?: chains, multipliers, always_latch,
     clock / reset structure;
  2. coarse netlist (Yosys after alumacc/opt): arithmetic and mux operators
     with widths, arithmetic operators in series between registers;
  3. gate netlist (Yosys generic gates): unit-delay logic depth to every
     endpoint, fanout and sink spread, combinational loops, latches,
     clock / async-reset nets, clock-domain crossings, combinational
     input-to-output (handshake) paths.
The delay model is deliberately simple (audit/netlist.py GATE_DELAY).
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from .. import config, tools
from ..flow import common, synth
from . import netlist as NL
from . import source as SRC

AUDIT_YS = """# TimingLab RTL audit netlists for {top}
read_rtlil elab.il
hierarchy -top {top}
synth -flatten -top {top} -run begin:fine
opt_clean
tee -o coarse_stat.txt stat
write_json coarse.json
# fine-grain mapping WITHOUT abc: generic gates keep the src attribute of the
# RTL operator they came from, so every path can be traced to source lines
opt -fast -full
memory_map
opt -full
techmap
opt -fast
opt_clean
check
tee -o gates_stat.txt stat
write_json gates.json
"""


def _src_map(rd: Path) -> dict[str, str]:
    m = {}
    sj = rd / "sources.json"
    if sj.exists():
        for e in json.loads(sj.read_text()):
            m[e["staged"]] = e["source"]
            m[e["staged"].split("/", 1)[-1]] = e["source"]
    return m


def map_src(src: str, smap: dict[str, str]) -> str:
    """'src/01_alu.sv:123.5-130.9' -> 'SilicaFlux-main/alu.sf:123'"""
    if not src:
        return ""
    first = src.split("|")[0]
    m = re.match(r"(.+?):(\d+)", first)
    if not m:
        return first
    f = smap.get(m.group(1), m.group(1))
    return f"{f}:{m.group(2)}"


def coarse_analysis(path: Path, top: str, smap: dict[str, str]) -> dict[str, Any]:
    data = json.loads(path.read_text())
    mod = data["modules"][top]
    arith, muxes, shifts, mems = [], [], [], []
    cells = mod["cells"]
    for name, c in cells.items():
        t = c["type"]
        p = c.get("parameters", {})
        src = map_src(c.get("attributes", {}).get("src", ""), smap)

        def iv(k: str) -> int:
            v = p.get(k, "0")
            try:
                return int(v, 2) if isinstance(v, str) and set(v) <= {"0", "1"} else int(v)
            except ValueError:
                return 0
        if t in ("$alu", "$add", "$sub", "$neg", "$lcu", "$lt", "$le", "$gt", "$ge"):
            arith.append({"cell": name, "type": t, "width": max(iv("A_WIDTH"), iv("B_WIDTH"), iv("Y_WIDTH")),
                          "src": src})
        elif t in ("$mul", "$div", "$mod", "$divfloor", "$modfloor"):
            arith.append({"cell": name, "type": t, "width": max(iv("A_WIDTH"), iv("B_WIDTH"), iv("Y_WIDTH")),
                          "a_width": iv("A_WIDTH"), "b_width": iv("B_WIDTH"), "y_width": iv("Y_WIDTH"), "src": src})
        elif t in ("$macc", "$macc_v2"):
            # $macc_v2 packs operand widths into A_WIDTHS/B_WIDTHS; report the
            # result width and the number of product terms
            conn = c["connections"]
            arith.append({"cell": name, "type": t, "width": iv("Y_WIDTH"), "y_width": iv("Y_WIDTH"),
                          "a_width": len(conn.get("A", [])), "b_width": len(conn.get("B", [])),
                          "products": iv("NPRODUCTS") if "NPRODUCTS" in p else None, "src": src})
        elif t == "$pmux":
            muxes.append({"cell": name, "type": t, "width": iv("WIDTH"), "inputs": iv("S_WIDTH") + 1, "src": src})
        elif t in ("$mux", "$bmux"):
            muxes.append({"cell": name, "type": t, "width": iv("WIDTH"),
                          "inputs": 2 if t == "$mux" else 2 ** iv("S_WIDTH"), "src": src})
        elif t in ("$shiftx", "$shift", "$shl", "$shr", "$sshl", "$sshr"):
            shifts.append({"cell": name, "type": t, "width": iv("A_WIDTH"), "shift_bits": iv("B_WIDTH"),
                           "y_width": iv("Y_WIDTH"), "src": src})
        elif t.startswith("$mem"):
            mems.append({"cell": name, "type": t, "width": iv("WIDTH"), "size": iv("SIZE"), "src": src})
    # arithmetic operators in series (cell-level graph between sequential cells)
    driver: dict[int, str] = {}
    for name, c in cells.items():
        dirs = c.get("port_directions", {})
        for pn, bits in c["connections"].items():
            if dirs.get(pn) == "output":
                for b in bits:
                    if isinstance(b, int):
                        driver[b] = name
    is_arith = {a["cell"]: (2 if a["type"] in ("$mul", "$macc", "$macc_v2") else 1) for a in arith}
    seq = {n for n, c in cells.items() if re.match(r"\$(a|s|al)?dff|\$dffe|\$sdff|\$aldff|\$dlatch|\$mem", c["type"])}
    memo: dict[str, tuple[int, list[str]]] = {}

    def chain(n: str, depth: int = 0) -> tuple[int, list[str]]:
        if n in memo:
            return memo[n]
        if depth > 400:
            return (0, [])
        memo[n] = (0, [])  # loop guard
        c = cells[n]
        dirs = c.get("port_directions", {})
        best = (0, [])
        for pn, bits in c["connections"].items():
            if dirs.get(pn) == "output":
                continue
            for d in {driver.get(b) for b in bits if isinstance(b, int)} - {None}:
                if d in seq:
                    continue
                r = chain(d, depth + 1)
                if r[0] > best[0]:
                    best = r
        w = is_arith.get(n, 0)
        res = (best[0] + w, ([n] if w else []) + best[1])
        memo[n] = res
        return res

    chains = []
    for n in seq:
        c = cells[n]
        for pn, bits in c["connections"].items():
            if c.get("port_directions", {}).get(pn) == "output" or pn in ("CLK", "ARST", "SRST", "EN"):
                continue
            for d in {driver.get(b) for b in bits if isinstance(b, int)} - {None}:
                if d in seq:
                    continue
                k, cl = chain(d)
                if k >= 2:
                    chains.append({"endpoint_cell": n, "endpoint_src": map_src(c.get("attributes", {}).get("src", ""), smap),
                                   "arith_ops_in_series": k,
                                   "ops": [{"type": cells[x]["type"],
                                            "src": map_src(cells[x].get("attributes", {}).get("src", ""), smap)}
                                           for x in cl][:20]})
    # de-duplicate chains with identical op lists
    seen, uniq = set(), []
    for ch in sorted(chains, key=lambda c: -c["arith_ops_in_series"]):
        key = tuple(o["src"] for o in ch["ops"])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(ch)
    return {"arith": sorted(arith, key=lambda a: -a["width"]), "muxes": sorted(muxes, key=lambda m: -(m["inputs"] * m["width"])),
            "shifts": sorted(shifts, key=lambda s: -s["width"] * max(1, s["shift_bits"])), "memories": mems,
            "arith_chains": uniq[:40], "cell_counts": dict(Counter(c["type"] for c in cells.values()))}


def audit_design(cat: config.Catalogue, name: str, out_root: Path) -> dict[str, Any]:
    design = cat.design(name)
    rd = out_root / name
    rd.mkdir(parents=True, exist_ok=True)
    manifest = common.stage_sources(design, rd)
    files = " ".join(m["staged"] for m in manifest)
    r = synth._slang(rd, "elab.ys", files, design.top, synth._param_args(design.params))
    if r["rc"] != 0:
        raise RuntimeError(f"audit elaboration failed: {rd / 'elab.log'}")
    (rd / "audit.ys").write_text(AUDIT_YS.format(top=design.top))
    r2 = common.run([tools.require("yosys"), "-q", "-l", "audit.log", "-s", "audit.ys"], rd / "audit.stdout", cwd=rd)
    if r2["rc"] != 0:
        raise RuntimeError(f"audit synthesis failed: {rd / 'audit.log'}")
    smap = _src_map(rd)
    log = (rd / "audit.log").read_text()
    yosys_loops = [l.strip() for l in log.splitlines() if "logic loop" in l.lower()]
    coarse = coarse_analysis(rd / "coarse.json", design.top, smap)
    nl = NL.load(rd / "gates.json", design.top)
    dep = nl.depth_analysis()
    fo = nl.fanout()
    cr = nl.clock_reset()
    cdc = nl.cdc_crossings()
    latches = [g for g in nl.gates if NL.LATCH_RE.match(g.type)]
    src_metrics = SRC.scan_design_sources(design)

    # ----------------------------------------------------------- endpoints
    eps = dep["endpoints"]
    for e in eps:
        e["src_trail"] = [map_src(s, smap) for s in e["src_trail"]]
    ff_eps = [e for e in eps if e["kind"].startswith("ff:")]
    worst = eps[0]["est_delay"] if eps else 0.0
    # group endpoints by RTL register (bus)
    groups: dict[str, dict[str, Any]] = {}
    for e in eps:
        reg = NL.reg_group(e["endpoint"].split(":", 1)[1].rsplit(".", 1)[0]) if e["kind"] != "out" else \
            NL.reg_group(e["endpoint"])
        g = groups.setdefault(reg, {"register": reg, "kind": "out" if e["kind"] == "out" else "ff",
                                    "bits": 0, "worst_est_delay": 0.0, "worst_levels": 0, "startpoint": "",
                                    "src_trail": [], "aliases": []})
        if e["kind"] != "out" and e.get("endpoint_cell"):
            g["aliases"] = sorted(set(g["aliases"]) | set(nl.q_aliases(e["endpoint_cell"])))
        g["bits"] += 1
        if e["est_delay"] > g["worst_est_delay"]:
            g.update(worst_est_delay=e["est_delay"], worst_levels=e["levels"], startpoint=e["startpoint"],
                     src_trail=e["src_trail"])
    reg_rank = sorted(groups.values(), key=lambda g: -g["worst_est_delay"])

    # combinational input -> output paths (handshake / pipeline-hazard risk)
    io_paths = [e for e in eps if e["kind"] == "out" and e["startpoint"].startswith("in:")]

    # ----------------------------------------------------------- candidates
    cands: list[dict[str, Any]] = []

    def add(cat_: str, title: str, score: float, metric: dict[str, Any], loc: str = "",
            evidence: list[str] | None = None, match: dict[str, Any] | None = None) -> None:
        cands.append({"id": f"{name}:{cat_}:{len(cands)}", "category": cat_, "title": title,
                      "score": round(min(100.0, score), 1), "metric": metric, "location": loc,
                      "evidence": evidence or [], "match": match or {}, "status": "hypothesis"})

    for g in reg_rank[:12]:
        if worst <= 0:
            break
        rel = g["worst_est_delay"] / worst
        if rel < 0.5:
            break
        add("critical_path", f"deep logic into {g['register']} ({g['worst_levels']} gate levels)",
            100 * rel, {"est_delay_units": g["worst_est_delay"], "levels": g["worst_levels"], "bits": g["bits"],
                        "startpoint": g["startpoint"]},
            g["src_trail"][-1] if g["src_trail"] else "", g["src_trail"][:12],
            {"endpoint_register": g["register"], "kind": g["kind"]})
    for a in coarse["arith"][:30]:
        if a["type"] in ("$mul", "$macc", "$macc_v2"):
            add("multiplier", f"{a['type']} A[{a.get('a_width')}] x B[{a.get('b_width')}] -> Y[{a.get('y_width')}]",
                min(90, 30 + a["width"]), a, a["src"], [], {"src": a["src"]})
        elif a["width"] >= 32:
            add("wide_arith", f"{a['type']} width {a['width']}", min(60, a["width"]), a, a["src"], [], {"src": a["src"]})
    for ch in coarse["arith_chains"][:10]:
        add("arith_chain", f"{ch['arith_ops_in_series']} arithmetic operators in series into one register",
            min(95, 25 * ch["arith_ops_in_series"]), {"ops_in_series": ch["arith_ops_in_series"]},
            ch["endpoint_src"], [f"{o['type']} @ {o['src']}" for o in ch["ops"]], {"src": ch["endpoint_src"]})
    for m in coarse["muxes"][:15]:
        if m["inputs"] >= 8:
            add("wide_mux", f"{m['inputs']}:1 mux x {m['width']} bits", min(80, 8 * m["inputs"] ** 0.5 * 3),
                m, m["src"], [], {"src": m["src"]})
    for s in coarse["shifts"][:10]:
        if s["width"] >= 32 and s["shift_bits"] >= 4:
            add("barrel_shift", f"{s['type']} {s['width']} bits by {s['shift_bits']}-bit amount",
                min(60, s["width"] / 2), s, s["src"], [], {"src": s["src"]})
    special = set(cr["clock_nets"]) | set(cr["async_reset_nets"])
    for f in [f for f in fo if f["net"] not in special][:15]:
        sc = 20 + 15 * (f["fanout"] ** 0.5) / 10 + 2 * f["sink_scopes"]
        add("high_fanout", f"net {f['net']} drives {f['fanout']} loads across {f['sink_scopes']} scopes",
            sc, f, map_src(f["driver_src"], smap), [], {"net": f["net"], "driver": f["driver"]})
        if f["sink_scopes"] >= 8:
            add("routing_sensitive", f"net {f['net']} spreads to {f['sink_scopes']} generate scopes",
                min(70, 5 * f["sink_scopes"]), f, map_src(f["driver_src"], smap), [], {"net": f["net"]})
    for e in io_paths[:5]:
        add("comb_io_path", f"combinational input->output path to {e['endpoint']} ({e['levels']} levels)",
            30 + e["levels"], {"levels": e["levels"], "startpoint": e["startpoint"], "est_delay_units": e["est_delay"]},
            e["src_trail"][-1] if e["src_trail"] else "", e["src_trail"][:8], {"endpoint": e["endpoint"]})
    for lp in src_metrics.get("loop_reductions", []):
        add("loop_reduction", f"loop-accumulated reduction ({lp['op']}) - linear chain unless restructured",
            55, lp, lp["location"], [lp["text"]], {"src": lp["location"]})
    for cs in src_metrics.get("wide_cases", []):
        add("wide_case", f"case with {cs['items']} items", min(60, 2 * cs["items"]), cs, cs["location"], [], {})
    for t in src_metrics.get("ternary_chains", []):
        add("ternary_chain", f"?: chain depth {t['depth']}", 10 * t["depth"], t, t["location"], [t["text"]], {})
    for lp in dep["loops"] + [{"msg": l} for l in yosys_loops]:
        add("comb_loop", "combinational loop", 100, {"detail": lp}, "", [], {})
    for g in latches:
        add("latch", f"inferred latch {g.name}", 90, {"type": g.type}, map_src(g.src, smap), [], {})
    for l in src_metrics.get("latch_processes", []):
        add("latch", "always_latch process", 70, l, l["location"], [], {})
    if len(cr["clock_nets"]) > 1:
        add("cdc", f"{len(cr['clock_nets'])} clock nets in block", 80, {"clocks": cr["clock_nets"],
                                                                         "crossings": cdc[:20]}, "", [], {})
    if len(cr["async_reset_nets"]) > 1:
        add("rdc", f"{len(cr['async_reset_nets'])} asynchronous reset nets", 60, cr["async_reset_nets"], "", [], {})
    cands.sort(key=lambda c: -c["score"])

    result = {
        "design": name, "top": design.top, "params": design.params, "status": "hypotheses (not timing results)",
        "delay_model": {"unit": "generic gate delay (NAND2 ~ 1)", "gate_delay": NL.GATE_DELAY,
                        "fanout_penalty": "0.25*log2(fanout)", "clk_to_q": 1.0},
        "tools": {"yosys_slang": tools.version("yosys_slang"), "yosys": tools.version("yosys")},
        "summary": {
            "generic_gates": dep["n_comb"], "sequential": dep["n_seq"], "latches": len(latches),
            "endpoints": len(eps), "ff_endpoints": len(ff_eps),
            "max_levels": max((e["levels"] for e in eps), default=0),
            "max_est_delay": worst, "comb_loops": len(dep["loops"]) + len(yosys_loops),
            "clock_nets": cr["clock_nets"], "async_reset_nets": cr["async_reset_nets"],
            "cdc_crossings": len(cdc), "comb_io_paths": len(io_paths),
            "max_fanout": fo[0]["fanout"] if fo else 0,
            "multipliers": sum(1 for a in coarse["arith"] if a["type"] in ("$mul", "$macc", "$macc_v2")),
            "arith_ops": len(coarse["arith"]), "max_arith_in_series": max((c["arith_ops_in_series"] for c in coarse["arith_chains"]), default=0),
            "max_mux_inputs": max((m["inputs"] for m in coarse["muxes"]), default=0),
        },
        "candidates": cands,
        "register_ranking": reg_rank[:60],
        "endpoints": eps[:300],
        "fanout": fo, "coarse": {k: coarse[k] for k in ("arith", "muxes", "shifts", "memories", "arith_chains")},
        "coarse_cell_counts": coarse["cell_counts"], "clock_reset": cr, "cdc": cdc,
        "source_metrics": src_metrics,
    }
    (rd / "rtl_audit.json").write_text(json.dumps(result, indent=1))
    return result
