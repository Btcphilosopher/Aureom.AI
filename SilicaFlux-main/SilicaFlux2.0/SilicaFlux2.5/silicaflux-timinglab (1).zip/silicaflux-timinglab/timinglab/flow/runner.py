"""Run the TimingLab flow (elaborate -> synthesise -> STA -> PnR experiment)
for (design, PDK) pairs and collect one result.json per run."""
from __future__ import annotations

import concurrent.futures as cf
import datetime as dt
import json
import os
import platform
from pathlib import Path
from typing import Any

from .. import config, tools
from . import common, pnr, sta, synth

STAGES = ("elab", "synth", "sta", "pnr")


def flow_fingerprint() -> str:
    """Hash of everything that defines the flow (scripts, constraints, PDK
    configs, flow drivers). Stored in result.json; --resume skips runs whose
    fingerprint and source hashes are unchanged."""
    import hashlib
    h = hashlib.sha256()
    root = config.ROOT
    files = sorted([*root.glob("flow/**/*.tcl"), *root.glob("flow/pdk/*.toml"), *root.glob("constraints/*.sdc"),
                    *root.glob("timinglab/flow/*.py"), *root.glob("timinglab/parsers/*.py")])
    for f in files:
        h.update(str(f.relative_to(root)).encode())
        h.update(f.read_bytes())
    return h.hexdigest()[:16]


def source_hashes(design: config.Design) -> list[str]:
    import hashlib
    return [hashlib.sha256(config.resolve_source(s)[1]).hexdigest() for s in design.files]


def is_current(cat: config.Catalogue, design_name: str, pdk_name: str) -> bool:
    rd = common.RUNS / pdk_name / design_name
    try:
        r = json.loads((rd / "result.json").read_text())
    except Exception:
        return False
    d = cat.design(design_name)
    return (not r.get("error") and r.get("flow_fingerprint") == flow_fingerprint()
            and r.get("source_hashes") == source_hashes(d) and r.get("params") == d.params
            and r.get("stages", {}).get("pnr", {}).get("ok"))


def run_one(cat: config.Catalogue, design_name: str, pdk_name: str, stages: tuple[str, ...] = STAGES,
            npaths: int = 200) -> dict[str, Any]:
    design = cat.design(design_name)
    pdk = cat.pdk(pdk_name)
    ok, missing = pdk.available()
    rd = common.run_dir(pdk_name, design_name)
    res: dict[str, Any] = {
        "design": design_name, "top": design.top, "pdk": pdk_name, "category": design.raw.get("category", ""),
        "role": design.role, "alternative_of": design.baseline, "period_ns": design.period(pdk),
        "params": design.params, "started": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "host": platform.node(), "tools": {t: tools.version(t) for t in ("yosys_slang", "yosys", "sta", "openroad")},
        "pdk_files": [str(p) for p in [*pdk.libs, pdk.tech_lef, *pdk.sc_lefs]], "stages": {},
        "flow_fingerprint": flow_fingerprint(), "source_hashes": source_hashes(design),
    }
    if not ok:
        res["error"] = f"PDK files missing: {missing}"
        common.write_json(rd / "result.json", res)
        return res
    try:
        if "elab" in stages:
            res["stages"]["elab"] = synth.elaborate(design, rd)
            if not res["stages"]["elab"]["ok"]:
                raise RuntimeError("elaboration failed, see " + str(rd / "elab.log"))
        res["sources"] = common.read_json(rd / "sources.json") if (rd / "sources.json").exists() else []
        if "synth" in stages:
            res["stages"]["synth"] = synth.synthesize(design, pdk, rd)
            if not res["stages"]["synth"]["ok"]:
                raise RuntimeError("synthesis failed, see " + str(rd / "synth.log"))
        if "sta" in stages:
            res["stages"]["sta"] = sta.run_sta(design, pdk, rd, npaths)
            if not res["stages"]["sta"]["ok"]:
                raise RuntimeError("STA failed, see " + str(rd / "sta.log"))
        if "pnr" in stages:
            res["stages"]["pnr"] = pnr.run_pnr(design, pdk, rd, npaths)
            if not res["stages"]["pnr"]["ok"]:
                raise RuntimeError("PnR failed, see " + str(rd / "pnr.log"))
    except Exception as e:
        res["error"] = str(e)
    res["finished"] = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    # Merge with a previous result so a LATER stage can be re-run alone
    # (e.g. --stages pnr). Results of stages downstream of the earliest stage
    # run now are discarded: they no longer correspond to the netlist.
    prev = rd / "result.json"
    if prev.exists() and set(stages) != set(STAGES):
        try:
            old = json.loads(prev.read_text())
            first = min(STAGES.index(s) for s in stages)
            for k, v in old.get("stages", {}).items():
                if k in STAGES and STAGES.index(k) < first:
                    res["stages"].setdefault(k, v)
            if "sources" in old:
                res.setdefault("sources", old["sources"])
        except Exception:
            pass
    common.write_json(rd / "result.json", res)
    return res


def run_many(cat: config.Catalogue, designs: list[str], pdks: list[str], stages: tuple[str, ...] = STAGES,
             jobs: int = 2, npaths: int = 200, resume: bool = False) -> list[dict[str, Any]]:
    todo = [(d, p) for p in pdks for d in designs]
    if resume:
        skip = [(d, p) for d, p in todo if is_current(cat, d, p)]
        for d, p in skip:
            print(f"[{p:10s}] {d:28s} up to date (resume)", flush=True)
        todo = [t for t in todo if t not in skip]
    out = []
    with cf.ThreadPoolExecutor(max_workers=max(1, jobs)) as ex:
        futs = {ex.submit(run_one, cat, d, p, stages, npaths): (d, p) for d, p in todo}
        for f in cf.as_completed(futs):
            d, p = futs[f]
            r = f.result()
            status = "OK" if not r.get("error") else "FAIL " + r["error"][:100]
            t = r.get("stages", {}).get("pnr", {}).get("timing", {}).get("grt") or \
                r.get("stages", {}).get("sta", {}).get("timing", {})
            print(f"[{p:10s}] {d:28s} {status}  wns={t.get('wns')} r2r={t.get('reg2reg_wns')}", flush=True)
            out.append(r)
    return out
