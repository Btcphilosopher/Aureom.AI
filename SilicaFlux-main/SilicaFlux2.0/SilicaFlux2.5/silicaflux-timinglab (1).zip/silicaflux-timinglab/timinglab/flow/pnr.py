"""OpenROAD placement / CTS / global-route timing experiment."""
from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any

from .. import config, tools
from ..parsers import openroad as or_parse
from ..parsers import sta as sta_parse
from . import common
from .sta import sdc_env
from .synth import effective_top


def port_bits(rd: Path, top: str) -> int:
    nl = json.loads((rd / "netlist.json").read_text())
    mod = nl["modules"][top]
    return sum(len(p["bits"]) for p in mod["ports"].values())


def die_side(cell_area: float, n_bits: int, pdk: config.Pdk) -> tuple[float, dict[str, float]]:
    util = float(pdk.raw.get("core_utilization", 40)) / 100.0
    margin = float(pdk.raw.get("core_margin_um", 5.0))
    pitch = float(pdk.raw.get("pin_pitch_um", 0.6))
    core_side_area = math.sqrt(cell_area / util)
    core_side_pins = n_bits * pitch * 2.0 / 4.0          # every other track, four sides
    side = max(core_side_area, core_side_pins) + 2 * margin
    side = math.ceil(side)
    return side, {"target_util": util, "core_side_from_area_um": round(core_side_area, 1),
                  "core_side_from_pins_um": round(core_side_pins, 1), "die_side_um": side,
                  "pin_limited": core_side_pins > core_side_area, "margin_um": margin}


def run_pnr(design: config.Design, pdk: config.Pdk, rd: Path, npaths: int = 200) -> dict[str, Any]:
    out = rd / "pnr"
    out.mkdir(exist_ok=True)
    stat = synth_stat(rd)
    top = effective_top(rd, design)
    nbits = port_bits(rd, top)
    side, fp = die_side(stat["area_um2"], nbits, pdk)
    env = sdc_env(design, pdk)
    pd = pdk.platform_dir
    env.update({
        "TL_FLOW_DIR": str(config.ROOT / "flow"),
        "TL_TECH_LEF": str(pdk.tech_lef), "TL_SC_LEFS": " ".join(str(p) for p in pdk.sc_lefs),
        "TL_LIBS": " ".join(str(p) for p in pdk.libs), "TL_NETLIST": str(rd / "netlist.v"),
        "TL_TOP": top, "TL_SDC": str(config.ROOT / design.sdc), "TL_OUTDIR": str(out),
        "TL_PLATFORM_DIR": str(pd), "TL_SITE": pdk.place_site, "TL_DIE_SIDE": str(side),
        "TL_CORE_MARGIN": str(fp["margin_um"]), "TL_DENSITY": str(pdk.place_density),
        "TL_IO_H": pdk.io_layer_h, "TL_IO_V": pdk.io_layer_v,
        "TL_MIN_LAYER": pdk.min_routing_layer, "TL_MAX_LAYER": pdk.max_routing_layer,
        "TL_MAKE_TRACKS": str(pd / pdk.make_tracks) if pdk.make_tracks else "",
        "TL_SET_RC": str(pd / pdk.set_rc) if pdk.set_rc else "",
        "TL_TAPCELL": str(pd / pdk.tapcell) if pdk.tapcell else "",
        "TL_DONT_USE": " ".join(pdk.dont_use), "TL_GRT_ADJ": str(pdk.raw.get("grt_adjustment", 0.3)),
        "TL_REPAIR_TIMING": str(int(bool(design.raw.get("repair_timing", 0)))), "TL_NPATHS": str(npaths),
        "TL_MIN_BUF_CELL": pdk.min_buf[0],
    })
    common.write_json(rd / "pnr_env.json", env)
    r = common.run([tools.require("openroad"), "-no_init", "-no_splash", "-exit",
                    str(config.ROOT / "flow" / "openroad" / "pnr.tcl")], rd / "pnr.log", cwd=rd, env=env,
                   timeout=int(design.raw.get("pnr_timeout", 7200)))
    log = (rd / "pnr.log").read_text()
    r["ok"] = r["rc"] == 0 and "TL-PNR: done" in log
    if r["ok"] and "TritonCTS found 0 clock nets" in log:
        # a run without a clock tree is not a valid timing result
        r["ok"] = False
        r["error"] = "CTS built no clock tree (TritonCTS found 0 clock nets)"
    r["floorplan"] = fp
    r["port_bits"] = nbits
    r["log_summary"] = or_parse.parse_log(log)
    if (out / "grt" / "summary.tsv").exists() or r["ok"]:
        timing = {}
        areas = or_parse.parse_areas_from_log(log)
        for st in ("place", "cts", "grt"):
            if (out / st / "summary.tsv").exists():
                timing[st] = sta_parse.parse_stage(out / st, design.period(pdk))
                timing[st]["area"] = areas.get(st, {})
        r["floorplan"]["area"] = areas.get("floorplan", {})
        r["timing"] = timing
        r["congestion"] = or_parse.parse_congestion(out / "congestion.rpt", log)
        r["path_cells_xy"] = or_parse.parse_path_cells(out / "path_cells_xy.tsv")
    return r


def synth_stat(rd: Path) -> dict[str, Any]:
    from .synth import parse_stat
    return parse_stat(rd / "synth_stat.txt")
