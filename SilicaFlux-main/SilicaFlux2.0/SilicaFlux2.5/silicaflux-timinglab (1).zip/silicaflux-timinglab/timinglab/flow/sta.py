"""Post-synthesis static timing analysis with OpenSTA."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .. import config, tools
from ..parsers import sta as sta_parse
from . import common
from .synth import effective_top


def sdc_env(design: config.Design, pdk: config.Pdk) -> dict[str, str]:
    period = design.period(pdk)
    unc = float(pdk.raw.get("clock_uncertainty_ns", 0.02 * period))
    env = {
        "TL_CLOCK_PORT": design.clock,
        "TL_RESET_PORT": design.reset,
        "TL_PERIOD": f"{period:.4f}",
        "TL_UNC_SETUP": f"{unc:.4f}",
        "TL_UNC_HOLD": f"{min(0.05, unc):.4f}",
        "TL_CLK_SLEW": f"{float(pdk.raw.get('clock_slew_ns', 0.15)):.4f}",
        "TL_IO_FRAC": f"{float(design.raw.get('io_frac', 0.30)):.3f}",
        "TL_DRIVER_CELL": pdk.raw.get("sdc_driver_cell", ""),
        "TL_DRIVER_PIN": pdk.raw.get("sdc_driver_pin", ""),
        "TL_LOAD_PF": f"{float(pdk.raw.get('sdc_load_pf', 0.01)):.4f}",
    }
    env.update({k: str(v) for k, v in pdk.raw.get("env", {}).items()})
    return env


def run_sta(design: config.Design, pdk: config.Pdk, rd: Path, npaths: int = 200) -> dict[str, Any]:
    out = rd / "sta_synth"
    out.mkdir(exist_ok=True)
    env = sdc_env(design, pdk)
    env.update({
        "TL_FLOW_DIR": str(config.ROOT / "flow"),
        "TL_LIBS": " ".join(str(l) for l in pdk.libs),
        "TL_NETLIST": str(rd / "netlist.v"),
        "TL_TOP": effective_top(rd, design),
        "TL_SDC": str(config.ROOT / design.sdc),
        "TL_OUTDIR": str(out),
        "TL_NPATHS": str(npaths),
    })
    common.write_json(rd / "sta_env.json", env)
    r = common.run([tools.require("sta"), "-no_init", "-no_splash", "-exit",
                    str(config.ROOT / "flow" / "sta" / "sta.tcl")], rd / "sta.log", cwd=rd, env=env)
    r["ok"] = r["rc"] == 0 and (out / "summary.tsv").exists()
    if r["ok"]:
        r["timing"] = sta_parse.parse_stage(out, design.period(pdk))
    return r
