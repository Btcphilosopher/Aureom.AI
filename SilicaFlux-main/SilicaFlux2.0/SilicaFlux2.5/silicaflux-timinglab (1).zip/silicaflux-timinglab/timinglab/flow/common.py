"""Shared helpers for the flow stages: run directories, source staging,
subprocess execution with logs, Liberty preparation."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

from .. import config

RUNS = Path(os.environ.get("TL_RUNS", config.ROOT / "runs"))
CACHE = Path(os.environ.get("TL_CACHE", config.ROOT / ".cache"))


def run_dir(pdk: str, design: str) -> Path:
    d = RUNS / pdk / design
    d.mkdir(parents=True, exist_ok=True)
    return d


def sanitize(name: str) -> str:
    base = os.path.basename(name.split("!")[-1])
    base = re.sub(r"\.(sf|sv|v|svh)$", "", base)
    base = re.sub(r"[^A-Za-z0-9_]+", "_", base).strip("_")
    return base + ".sv"


def stage_sources(design: config.Design, dest: Path) -> list[dict[str, str]]:
    """Copy the design's sources into dest/src with shell- and WASI-safe names.
    Returns a manifest with the original path and SHA-256 of every file."""
    src = dest / "src"
    if src.exists():
        shutil.rmtree(src)
    src.mkdir(parents=True)
    manifest = []
    for i, spec in enumerate(design.files):
        disp, data = config.resolve_source(spec)
        name = f"{i:02d}_{sanitize(disp)}"
        (src / name).write_bytes(data)
        manifest.append({"spec": spec, "source": disp, "staged": f"src/{name}",
                         "sha256": hashlib.sha256(data).hexdigest()})
    (dest / "sources.json").write_text(json.dumps(manifest, indent=1))
    return manifest


def run(cmd: list[str], log: Path, cwd: Path, env: dict[str, str] | None = None,
        timeout: int = 7200) -> dict[str, Any]:
    t0 = time.time()
    e = dict(os.environ)
    if env:
        e.update({k: str(v) for k, v in env.items()})
    with log.open("w") as fh:
        fh.write("# " + " ".join(cmd) + "\n")
        fh.flush()
        try:
            p = subprocess.run(cmd, cwd=cwd, env=e, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout)
            rc = p.returncode
        except subprocess.TimeoutExpired:
            rc = -9
            fh.write(f"\nTL-ERROR: timeout after {timeout}s\n")
    return {"rc": rc, "seconds": round(time.time() - t0, 2), "log": str(log)}


def plain_liberty(lib: Path) -> Path:
    """Yosys' dfflibmap/abc need an uncompressed Liberty file."""
    if lib.suffix != ".gz":
        return lib
    out = CACHE / "lib" / lib.name[:-3]
    if not out.exists() or out.stat().st_mtime < lib.stat().st_mtime:
        out.parent.mkdir(parents=True, exist_ok=True)
        with gzip.open(lib, "rb") as fi, out.open("wb") as fo:
            shutil.copyfileobj(fi, fo)
    return out


def write_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, indent=1, sort_keys=False))


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())
