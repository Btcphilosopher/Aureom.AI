"""Syntax-level SystemVerilog scanner built on pyslang (slang).

Works on files that do *not* elaborate (missing modules or package members),
which is the normal state of much of the SilicaFlux tree, so discovery never
depends on a design compiling. Everything returned here is read directly from
the parse tree; nothing is inferred from file names.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Any

import pyslang
from pyslang import syntax as S

SK = S.SyntaxKind

_DECL_KINDS = {
    SK.ModuleDeclaration: "module",
    SK.PackageDeclaration: "package",
    SK.InterfaceDeclaration: "interface",
    SK.ProgramDeclaration: "program",
}

CLOCK_RE = re.compile(r"(^|_)(clk|clock|tck)(_|$)|clk", re.I)
RESET_RE = re.compile(r"(^|_)(rst|reset|trst|por)(_|n|$)|rst", re.I)


def _nodes(seq) -> list:
    """Drop separator tokens from a SeparatedSyntaxList."""
    out = []
    for x in seq:
        if isinstance(getattr(x, "kind", None), SK):
            out.append(x)
    return out


_COMMENT_RE = re.compile(r"//[^\n]*|/\*.*?\*/", re.S)


def _text(node) -> str:
    """Source text of a node without comments (leading trivia) or line breaks."""
    return re.sub(r"\s+", " ", _COMMENT_RE.sub(" ", str(node))).strip()


@dataclass
class Port:
    name: str
    direction: str
    decl: str


@dataclass
class Param:
    name: str
    default: str
    local: bool


@dataclass
class Instance:
    module: str
    names: list[str]
    line: int
    connections: dict[str, str] = field(default_factory=dict)  # port -> expression text
    wildcard: bool = False
    params: dict[str, str] = field(default_factory=dict)


@dataclass
class Process:
    kind: str           # always_ff / always_comb / always_latch / always / assign / initial
    line: int
    events: list[str] = field(default_factory=list)   # e.g. ["posedge clk_i", "negedge rst_ni"]


@dataclass
class Definition:
    kind: str
    name: str
    line: int
    end_line: int
    header_imports: list[str] = field(default_factory=list)
    body_imports: list[str] = field(default_factory=list)
    ports: list[Port] = field(default_factory=list)
    params: list[Param] = field(default_factory=list)
    instances: list[Instance] = field(default_factory=list)
    processes: list[Process] = field(default_factory=list)
    scoped_refs: dict[str, list[str]] = field(default_factory=dict)  # pkg -> [symbols]
    generate_blocks: int = 0
    doc: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    # ---- convenience views -------------------------------------------------
    @property
    def imports(self) -> list[str]:
        return sorted(set(self.header_imports) | set(self.body_imports))

    def clock_ports(self) -> list[str]:
        return [p.name for p in self.ports if p.direction == "input" and CLOCK_RE.search(p.name)]

    def reset_ports(self) -> list[str]:
        return [p.name for p in self.ports if p.direction == "input" and RESET_RE.search(p.name)
                and not CLOCK_RE.search(p.name)]

    def edge_signals(self) -> dict[str, set[str]]:
        """Signals used in edge-sensitive event controls, split clock / async-reset."""
        clocks, resets = set(), set()
        for pr in self.processes:
            if pr.kind not in ("always_ff", "always"):
                continue
            for ev in pr.events:
                m = re.match(r"(posedge|negedge)\s+(.+)", ev)
                if not m:
                    continue
                sig = m.group(2).strip()
                base = re.split(r"[\[\.]", sig)[0]
                (resets if RESET_RE.search(base) and not CLOCK_RE.search(base) else clocks).add(sig)
        return {"clocks": clocks, "async_resets": resets}


@dataclass
class FileScan:
    path: str
    syntax_errors: int
    first_errors: list[str]
    definitions: list[Definition]
    timescale: bool
    includes: list[str]
    language_banner: str

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return d


def _port_list(header) -> list[Port]:
    ports: list[Port] = []
    pl = header.ports
    if pl is None:
        return ports
    if pl.kind == SK.AnsiPortList:
        last_dir = "inout"
        for p in _nodes(pl.ports):
            txt = _text(p)
            m = re.match(r"(input|output|inout|ref)\b", txt)
            if m:
                last_dir = m.group(1)
            name = None
            decl = getattr(p, "declarator", None)
            if decl is not None and hasattr(decl, "name"):
                name = decl.name.valueText
            if not name:
                toks = re.findall(r"[A-Za-z_][A-Za-z0-9_$]*", txt)
                name = toks[-1] if toks else txt
            ports.append(Port(name=name, direction=last_dir, decl=txt))
    else:
        for p in _nodes(getattr(pl, "ports", [])):
            ports.append(Port(name=_text(p), direction="unknown", decl=_text(p)))
    return ports


def _param_list(header) -> list[Param]:
    out: list[Param] = []
    pp = header.parameters
    if pp is None:
        return out
    for d in _nodes(pp.declarations):
        txt = _text(d)
        local = txt.startswith("localparam")
        # one declaration may declare several names: parameter int A = 1, B = 2
        for m in re.finditer(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([^,]+?)(?=,\s*[A-Za-z_][A-Za-z0-9_]*\s*=|$)", txt):
            out.append(Param(name=m.group(1), default=m.group(2).strip(), local=local))
    return out


def _leading_comment(text: str, line: int, max_lines: int = 60) -> str:
    """Comment block that immediately precedes a definition (documentation)."""
    lines = text.splitlines()
    i = line - 2
    block: list[str] = []
    while i >= 0 and len(block) < max_lines:
        s = lines[i].strip()
        if s.startswith("//"):
            block.append(s.lstrip("/").rstrip())
            i -= 1
            continue
        if s == "" and block:
            break
        if s == "":
            i -= 1
            continue
        break
    return "\n".join(reversed(block)).strip()


def scan_text(text: str, path: str) -> FileScan:
    sm = pyslang.SourceManager()
    tree = S.SyntaxTree.fromText(text, sm, name=path, path=path) if _fromtext_supports_path() \
        else S.SyntaxTree.fromText(text, sm, path)
    diags = list(tree.diagnostics)
    errs = [d for d in diags if d.isError()]
    first = []
    if errs:
        rep = pyslang.DiagnosticEngine.reportAll(sm, errs[:5])
        first = [l for l in rep.splitlines() if ": error:" in l][:5]

    def line_of(node) -> int:
        try:
            return sm.getLineNumber(node.sourceRange.start)
        except Exception:
            return 0

    def end_line_of(node) -> int:
        try:
            return sm.getLineNumber(node.sourceRange.end)
        except Exception:
            return 0

    defs: list[Definition] = []
    includes: list[str] = re.findall(r'^\s*`include\s+"([^"]+)"', text, re.M)
    timescale = bool(re.search(r"^\s*`timescale", text, re.M))
    banner = ""
    mb = re.search(r"(Language|Standard)\s*:\s*(.+)", text[:4000])
    if mb:
        banner = mb.group(2).strip()

    def walk_definition(node) -> Definition:
        kind = _DECL_KINDS[node.kind]
        h = node.header
        d = Definition(kind=kind, name=h.name.valueText, line=line_of(node), end_line=end_line_of(node))
        d.doc = _leading_comment(text, d.line)
        for imp in getattr(h, "imports", []) or []:
            for it in _nodes(imp.items):
                d.header_imports.append(it.package.valueText)
        if kind in ("module", "interface", "program"):
            d.ports = _port_list(h)
            d.params = _param_list(h)

        def cb(n):
            k = n.kind
            if k in _DECL_KINDS and n is not node:
                return pyslang.ast.VisitAction.Skip  # nested definitions are scanned separately
            if k == SK.PackageImportDeclaration:
                for it in _nodes(n.items):
                    d.body_imports.append(it.package.valueText)
            elif k == SK.HierarchyInstantiation:
                params: dict[str, str] = {}
                pa = getattr(n, "parameters", None)
                if pa is not None:
                    for a in _nodes(pa.parameters):
                        t = _text(a)
                        mm = re.match(r"\.\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*$", t)
                        if mm:
                            params[mm.group(1)] = mm.group(2).strip()
                for inst in _nodes(n.instances):
                    if not hasattr(inst, "decl") or inst.decl is None:
                        continue
                    conns: dict[str, str] = {}
                    wild = False
                    for c in _nodes(inst.connections):
                        if c.kind == SK.WildcardPortConnection:
                            wild = True
                        elif c.kind == SK.NamedPortConnection:
                            conns[c.name.valueText] = _text(c.expr) if c.expr is not None else ""
                        else:
                            conns[f"#{len(conns)}"] = _text(c)
                    d.instances.append(Instance(module=n.type.valueText, names=[inst.decl.name.valueText],
                                                line=line_of(n), connections=conns, wildcard=wild,
                                                params=params))
            elif k in (SK.AlwaysFFBlock, SK.AlwaysCombBlock, SK.AlwaysLatchBlock, SK.AlwaysBlock,
                       SK.InitialBlock, SK.FinalBlock):
                pk = {SK.AlwaysFFBlock: "always_ff", SK.AlwaysCombBlock: "always_comb",
                      SK.AlwaysLatchBlock: "always_latch", SK.AlwaysBlock: "always",
                      SK.InitialBlock: "initial", SK.FinalBlock: "final"}[k]
                evs: list[str] = []
                st = n.statement
                if st is not None and st.kind == SK.TimingControlStatement:
                    tc = _text(st.timingControl)
                    for part in re.split(r"\bor\b|,", tc.strip("@() ")):
                        part = part.strip(" ()")
                        if part:
                            evs.append(part)
                d.processes.append(Process(kind=pk, line=line_of(n), events=evs))
            elif k == SK.ContinuousAssign:
                d.processes.append(Process(kind="assign", line=line_of(n)))
            elif k == SK.ScopedName:
                t = _text(n)
                mm = re.match(r"([A-Za-z_][A-Za-z0-9_]*)\s*::\s*([A-Za-z_][A-Za-z0-9_]*)", t)
                if mm and mm.group(1) not in ("$unit", "std", "local", "super"):
                    d.scoped_refs.setdefault(mm.group(1), [])
                    if mm.group(2) not in d.scoped_refs[mm.group(1)]:
                        d.scoped_refs[mm.group(1)].append(mm.group(2))
            elif k in (SK.LoopGenerate, SK.IfGenerate, SK.CaseGenerate, SK.GenerateRegion,
                       SK.GenerateBlock):
                d.generate_blocks += 1
            return pyslang.ast.VisitAction.Advance

        node.visit(cb)
        return d

    def find_defs(n):
        if n.kind in _DECL_KINDS:
            defs.append(walk_definition(n))
            # nested modules (rare) are still visited below
        return pyslang.ast.VisitAction.Advance

    tree.root.visit(find_defs)
    return FileScan(path=path, syntax_errors=len(errs), first_errors=first, definitions=defs,
                    timescale=timescale, includes=includes, language_banner=banner)


_FT = None


def _fromtext_supports_path() -> bool:
    global _FT
    if _FT is None:
        try:
            S.SyntaxTree.fromText("module x; endmodule", pyslang.SourceManager(), name="x", path="x")
            _FT = True
        except TypeError:
            _FT = False
    return _FT
