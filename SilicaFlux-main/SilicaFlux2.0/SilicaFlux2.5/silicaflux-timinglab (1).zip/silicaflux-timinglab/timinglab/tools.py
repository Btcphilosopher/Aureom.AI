"""Locate the EDA tools TimingLab drives and report their versions.

Override any tool with an environment variable:
  TL_YOSYS_SLANG  Yosys with the slang SystemVerilog front-end (read_slang); default yowasp-yosys
  TL_YOSYS        Yosys used for technology mapping (default: native yosys, else TL_YOSYS_SLANG)
  TL_STA          OpenSTA     TL_OPENROAD  OpenROAD
  TL_VERILATOR    Verilator   TL_IVERILOG  Icarus Verilog     TL_DOT  Graphviz dot
"""
from __future__ import annotations

import functools
import os
import shutil
import subprocess
from pathlib import Path

_FALLBACK_DIRS = ["/opt/tl/eda-cf/bin", "/opt/tl/eda-or/bin", "/usr/local/bin", "/usr/bin"]

_SPEC = {
    "yosys_slang": ("TL_YOSYS_SLANG", ["yowasp-yosys", "yosys"]),
    "yosys": ("TL_YOSYS", ["yosys"]),
    "sta": ("TL_STA", ["sta"]),
    "openroad": ("TL_OPENROAD", ["openroad"]),
    "verilator": ("TL_VERILATOR", ["verilator"]),
    "iverilog": ("TL_IVERILOG", ["iverilog"]),
    "vvp": ("TL_VVP", ["vvp"]),
    "dot": ("TL_DOT", ["dot"]),
}


@functools.lru_cache(maxsize=None)
def find(tool: str) -> str | None:
    env, names = _SPEC[tool]
    if os.environ.get(env):
        return os.environ[env]
    for n in names:
        # prefer the fallback install dirs for the native EDA binaries (newer than distro packages)
        for d in _FALLBACK_DIRS:
            p = Path(d) / n
            if p.exists() and os.access(p, os.X_OK):
                return str(p)
        w = shutil.which(n)
        if w:
            return w
    if tool == "yosys":
        return find("yosys_slang")
    return None


def require(tool: str) -> str:
    p = find(tool)
    if not p:
        env = _SPEC[tool][0]
        raise RuntimeError(f"{tool} not found: install it (scripts/install_tools.sh) or set {env}")
    return p


@functools.lru_cache(maxsize=None)
def version(tool: str) -> str:
    p = find(tool)
    if not p:
        return "not found"
    args = {"yosys_slang": ["-V"], "yosys": ["-V"], "sta": ["-version"], "openroad": ["-version"],
            "verilator": ["--version"], "iverilog": ["-V"], "vvp": ["-V"], "dot": ["-V"]}[tool]
    try:
        r = subprocess.run([p, *args], capture_output=True, text=True, timeout=120)
        out = (r.stdout + r.stderr).strip().splitlines()
        out = [l for l in out if l.strip() and "Preparing to run" not in l]
        return out[0][:160] if out else "unknown"
    except Exception as e:  # pragma: no cover
        return f"error: {e}"


def has_read_slang(binary: str | None = None) -> bool:
    b = binary or find("yosys_slang")
    if not b:
        return False
    try:
        r = subprocess.run([b, "-p", "help read_slang"], capture_output=True, text=True, timeout=300)
        return "--threads" in (r.stdout + r.stderr) and r.returncode == 0
    except Exception:
        return False


def inventory() -> dict[str, dict[str, str]]:
    return {t: {"path": find(t) or "", "version": version(t)} for t in _SPEC}
