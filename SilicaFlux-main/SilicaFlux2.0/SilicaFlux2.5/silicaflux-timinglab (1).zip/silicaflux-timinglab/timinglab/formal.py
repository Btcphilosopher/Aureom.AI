"""Formal checks with Yosys `sat` (no external solver needed).

Each check elaborates a miter from formal/*.sv with the slang front-end and
asks Yosys' built-in SAT solver to prove the miter output `ok` is 1:
  * combinational miters: for every input assignment (sat -prove ok 1)
  * sequential miter: for every input sequence of length DEPTH from the reset
    state (bounded model check, sat -seq DEPTH -prove ok 1 -set-init-zero)

ABC engines (iprove for combinational, pdr / bmc3 for sequential miters) run
on an AIGER export with one output bad = !ok; see docs/VERIFICATION.md.
Seeded-bug witnesses (`expect: FAILED`) re-run a sequential miter with one
deliberate RTL bug and must produce a counterexample.

Results go to reports/formal/formal.json. A status is exactly what the solver
reported (PROVEN / FAILED / TIMEOUT / ...); nothing is inferred.
"""
from __future__ import annotations

import json
import re
import shutil
import time
from pathlib import Path
from typing import Any

from . import config, tools
from .flow import common

UPSTREAM_VE = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/vector_engine.sf"
PKG = "SilicaFlux-main/silicaflux_pkg (1).sf"
OPT = ["tl:rtl/opt/sf_csa_tree.sv", "tl:rtl/opt/sf_mul_lo_csa.sv", "tl:rtl/opt/sf_reduce_tree.sv"]

CHECKS: list[dict[str, Any]] = [
    {"name": "mul_lo_W8", "top": "fv_mul_lo", "params": {"W": 8}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "claim": "sf_mul_lo_csa: (sum+carry) mod 2^8 == a*b mod 2^8 for all a, b"},
    {"name": "csa_W32_N5", "top": "fv_csa", "params": {"W": 32, "N": 5}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "claim": "sf_csa_tree: 5 x 32-bit rows, sum preserved mod 2^32"},
    {"name": "csa_W16_N8", "top": "fv_csa", "params": {"W": 16, "N": 8}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "timeout": 900, "gate": False,
     "claim": "stress probe: sf_csa_tree, 8 x 16-bit rows (3 compressor levels)"},
    {"name": "csa_W8_N8", "top": "fv_csa", "params": {"W": 8, "N": 8}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "timeout": 900, "claim": "sf_csa_tree: 8 x 8-bit rows (3 compressor levels), all inputs"},
    {"name": "reduce_W32_N4", "top": "fv_reduce", "params": {"W": 32, "N": 4}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "claim": "sf_reduce_tree == upstream heap reduction, 4 lanes x 32 bit, all 4 operators"},
    {"name": "reduce_W16_N8", "top": "fv_reduce", "params": {"W": 16, "N": 8}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "timeout": 900, "gate": False,
     "claim": "stress probe: sf_reduce_tree == upstream heap reduction, 8 lanes x 16 bit"},
    {"name": "reduce_W8_N8", "engine": "abc", "top": "fv_reduce", "params": {"W": 8, "N": 8}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "timeout": 900, "claim": "sf_reduce_tree == upstream heap reduction, 8 lanes x 8 bit, all inputs"},
    {"name": "reduce_W8_N16", "engine": "abc", "top": "fv_reduce", "params": {"W": 8, "N": 16},
     "files": OPT + ["tl:formal/fv_datapath.sv"], "kind": "comb", "timeout": 900, "gate": False,
     "claim": "stress probe: sf_reduce_tree == upstream heap reduction, 16 lanes x 8 bit"},
    {"name": "reduce_W4_N16", "engine": "abc", "top": "fv_reduce", "params": {"W": 4, "N": 16},
     "files": OPT + ["tl:formal/fv_datapath.sv"], "kind": "comb", "timeout": 1200,
     "claim": "sf_reduce_tree == upstream heap reduction, 16 lanes x 4 bit, all four operators"},
    {"name": "vector_bmc_L4_W8", "top": "fv_vector_bmc", "params": {"LANES": 4, "LANE_W": 8},
     "files": [PKG, UPSTREAM_VE] + OPT + ["tl:rtl/opt/sf_vector_engine_pipe.sv", "tl:formal/fv_vector_bmc.sv"],
     "gate": False, "kind": "bmc", "depth": 8, "timeout": 3000,
     "claim": "upstream vector_engine (EX_STAGES=1) and sf_vector_engine_pipe produce identical result streams "
              "(2 non-stalled edges apart) for every input/stall sequence of 8 cycles from reset, flush_i = 0, "
              "LANES=4, LANE_W=8"},
    {"name": "alu_bmc_X8", "top": "fv_alu_bmc", "params": {"XLEN": 8, "MUL_STAGES": 2},
     "files": [PKG, "SilicaFlux-main/alu.sf"] + OPT[:2] + ["tl:rtl/opt/sf_alu_mulcsa.sv", "tl:formal/fv_alu_bmc.sv"],
     "gate": False, "kind": "bmc", "depth": 8, "timeout": 3000,
     "claim": "sf_alu and sf_alu_mulcsa: every output identical in every cycle for every input sequence of 8 "
              "cycles from reset (XLEN=8, MUL_STAGES=2; flush, kills and back-pressure free)"},
    {"name": "alu_pdr_X8", "engine": "pdr", "top": "fv_alu_bmc", "params": {"XLEN": 8, "MUL_STAGES": 2},
     "files": [PKG, "SilicaFlux-main/alu.sf"] + OPT[:2] + ["tl:rtl/opt/sf_alu_mulcsa.sv", "tl:formal/fv_alu_bmc.sv"],
     "kind": "seq", "timeout": 1800,
     "claim": "UNBOUNDED (ABC PDR): sf_alu and sf_alu_mulcsa have identical outputs in every cycle of every input "
              "sequence from reset (XLEN=8, MUL_STAGES=2; flush, kills and back-pressure free)"},
    {"name": "vector_pdr_L4_W8", "engine": "pdr", "top": "fv_vector_bmc", "params": {"LANES": 4, "LANE_W": 8},
     "files": [PKG, UPSTREAM_VE] + OPT + ["tl:rtl/opt/sf_vector_engine_pipe.sv", "tl:formal/fv_vector_bmc.sv"],
     "gate": False, "kind": "seq", "timeout": 3000,
     "claim": "UNBOUNDED (ABC PDR): upstream vector_engine (EX_STAGES=1) and sf_vector_engine_pipe produce identical "
              "result streams for every input/stall sequence from reset (flush_i = 0, LANES=4, LANE_W=8)"},
    {"name": "vector_kind_L4_W8", "engine": "abc-kind", "depth": 8, "top": "fv_vector_bmc",
     "params": {"LANES": 4, "LANE_W": 8},
     "files": [PKG, UPSTREAM_VE] + OPT + ["tl:rtl/opt/sf_vector_engine_pipe.sv", "tl:formal/fv_vector_bmc.sv"],
     "kind": "seq", "timeout": 3000,
     "claim": "UNBOUNDED (k-induction: ABC bmc3 base case + ind -u inductive step): upstream vector_engine "
              "(EX_STAGES=1) and sf_vector_engine_pipe produce identical result streams, 2 non-stalled edges "
              "apart, for every input/stall sequence of any length from reset (flush_i = 0, LANES=4, LANE_W=8)"},
    {"name": "alu_kind_X8", "engine": "abc-kind", "depth": 8, "top": "fv_alu_bmc",
     "params": {"XLEN": 8, "MUL_STAGES": 2},
     "files": [PKG, "SilicaFlux-main/alu.sf"] + OPT[:2] + ["tl:rtl/opt/sf_alu_mulcsa.sv", "tl:formal/fv_alu_bmc.sv"],
     "kind": "seq", "timeout": 3000, "gate": False,
     "claim": "UNBOUNDED (k-induction: ABC bmc3 base case + ind -u inductive step): sf_alu and sf_alu_mulcsa "
              "identical outputs in every cycle of every input sequence from reset (XLEN=8, MUL_STAGES=2; "
              "flush, kills and back-pressure free)"},
    {"name": "alu_abcbmc_X8", "engine": "abc-bmc", "depth": 16, "top": "fv_alu_bmc",
     "params": {"XLEN": 8, "MUL_STAGES": 2},
     "files": [PKG, "SilicaFlux-main/alu.sf"] + OPT[:2] + ["tl:rtl/opt/sf_alu_mulcsa.sv", "tl:formal/fv_alu_bmc.sv"],
     "kind": "seq", "timeout": 3000,
     "gate": False,
     "claim": "bounded, 16 cycles from reset (ABC bmc3): sf_alu and sf_alu_mulcsa identical outputs (XLEN=8)"},
    {"name": "mul_lo_W10", "engine": "abc", "top": "fv_mul_lo", "params": {"W": 10}, "files": OPT + ["tl:formal/fv_datapath.sv"],
     "kind": "comb", "timeout": 1200, "gate": False,
     "claim": "stress probe: sf_mul_lo_csa at W=10, all inputs (SAT difficulty grows steeply with multiplier width)"},
]


def _witness(base: str, name: str, target: str, old: str, new: str, claim: str) -> dict[str, Any]:
    """Seeded-bug witness: `base` with one deliberate RTL bug. The engine must
    return a counterexample (status FAILED == expected); this shows that the
    miter really compares the datapath, i.e. that a PROVEN on `base` is not
    vacuous."""
    b = next(c for c in CHECKS if c["name"] == base)
    return {**b, "name": name, "gate": False, "expect": "FAILED", "mutate": [(target, old, new)], "timeout": 1200,
            "claim": f"seeded bug, counterexample expected: {claim}"}


_ALU_TAIL = "assign mul_tail_data = mul_pp_q[MUL_PP_N-1].s + mul_pp_q[MUL_PP_N-1].c;"
CHECKS += [
    _witness("vector_kind_L4_W8", "vector_kind_L4_W8__bug", "tl:rtl/opt/sf_reduce_tree.sv",
             "assign sum_res = s_row + c_row;", "assign sum_res = s_row | c_row;",
             "sf_reduce_tree SUM CPA replaced by OR inside sf_vector_engine_pipe (k-induction)"),
    _witness("alu_pdr_X8", "alu_pdr_X8__bug", "tl:rtl/opt/sf_alu_mulcsa.sv", _ALU_TAIL,
             _ALU_TAIL.replace(".s + ", ".s ^ "), "sf_alu_mulcsa multiplier CPA replaced by XOR (PDR)"),
]


class _D:
    """Minimal stand-in for config.Design so common.stage_sources can be reused."""

    def __init__(self, files: list[str]):
        self.files = files


def run_check(chk: dict[str, Any], out: Path) -> dict[str, Any]:
    rd = out / chk["name"]
    if rd.exists():
        shutil.rmtree(rd)
    rd.mkdir(parents=True)
    manifest = common.stage_sources(_D(chk["files"]), rd)  # type: ignore[arg-type]
    for target, old, new in chk.get("mutate", []):
        f = rd / next(m["staged"] for m in manifest if m["spec"] == target)
        text = f.read_text()
        if text.count(old) != 1:
            return {**chk, "status": "ERROR", "detail": "seeded bug not applied", "seconds": 0.0}
        f.write_text(text.replace(old, new))
    files = " ".join(m["staged"] for m in manifest)
    params = " ".join(f"-G {k}={v}" for k, v in chk["params"].items())
    (rd / "elab.ys").write_text(f"read_slang --threads 1 -D SYNTHESIS {params} {files} --top {chk['top']}\n"
                                f"hierarchy -top {chk['top']}\nwrite_rtlil elab.il\n")
    if chk.get("engine") == "abc":
        (rd / "elab.ys").write_text(f"read_slang --threads 1 -D SYNTHESIS {params} {files} --top {chk['top']}_bad\n"
                                    f"hierarchy -top {chk['top']}_bad\nwrite_rtlil elab.il\n")
    t0 = time.time()
    r1 = common.run([tools.require("yosys_slang"), "-q", "-l", "elab.log", "-s", "elab.ys"], rd / "elab.out", cwd=rd)
    if r1["rc"] != 0:
        return {**chk, "status": "ERROR", "detail": "elaboration failed", "seconds": round(time.time() - t0, 1)}
    if chk.get("engine") == "abc":
        return _run_abc(chk, rd, t0)
    if chk.get("engine") in ("pdr", "abc-bmc", "abc-kind"):
        return _run_pdr(chk, rd, t0)
    if chk["kind"] == "comb":
        sat = f"sat -prove ok 1 -verify -show-inputs -timeout {chk.get('timeout', 1800)}"
    else:
        sat = f"sat -seq {chk['depth']} -prove ok 1 -set-init-zero -verify -show-inputs -timeout {chk.get('timeout', 3000)}"
    (rd / "prove.ys").write_text(f"read_rtlil elab.il\nhierarchy -top {chk['top']}\nproc\nflatten\n"
                                 f"async2sync\nopt -fast\n{sat}\n")
    r2 = common.run([tools.require("yosys"), "-q", "-l", "prove.log", "-s", "prove.ys"], rd / "prove.out", cwd=rd,
                    timeout=4000)
    log = (rd / "prove.log").read_text() if (rd / "prove.log").exists() else ""
    if "SAT proof finished - no model found: SUCCESS!" in log:
        status = "PROVEN"
    elif "model found" in log:              # a counterexample, printed before "-verify ... did fail"
        status = "FAILED"
    elif re.search(r"time ?out|interrupted", log, re.I) or r2["rc"] == -9:
        status = "TIMEOUT"                    # "-verify and proof did time out" is not a counterexample
    else:
        status = "ERROR"
    return {**chk, "status": status, "seconds": round(time.time() - t0, 1), "log": str(rd / "prove.log"),
            "yosys": tools.version("yosys")}


def _run_abc(chk: dict[str, Any], rd: Path, t0: float) -> dict[str, Any]:
    top = chk["top"] + "_bad"
    (rd / "aig.ys").write_text(f"read_rtlil elab.il\nhierarchy -top {top}\nproc\nflatten\nopt -fast\ntechmap\n"
                               f"opt -fast\n# x constants (if any) are fixed to 0 on both sides of the miter\n"
                               f"setundef -zero\naigmap\nopt_clean\nwrite_aiger miter.aig\n")
    r = common.run([tools.require("yosys"), "-q", "-l", "aig.log", "-s", "aig.ys"], rd / "aig.out", cwd=rd)
    abc = str(Path(tools.require("yosys")).with_name("yosys-abc"))
    timeout = int(chk.get("timeout", 1800))
    r2 = common.run([abc, "-c", "read_aiger miter.aig; print_stats; strash; iprove"], rd / "prove.log", cwd=rd,
                    timeout=timeout)
    log = (rd / "prove.log").read_text()
    st = _aig_stats(log)
    if not st or st["outputs"] != 1 or st["ands"] == 0:
        status = "VACUOUS"
    elif "UNSATISFIABLE" in log:
        status = "PROVEN"
    elif "SATISFIABLE" in log:
        status = "FAILED"
    elif r2["rc"] == -9:
        status = "TIMEOUT"
    else:
        status = "ERROR" if r["rc"] else "UNDECIDED"
    return {**chk, "status": status, "seconds": round(time.time() - t0, 1), "log": str(rd / "prove.log"),
            "yosys": tools.version("yosys"), "engine": "abc iprove", "aig": st}


def _aig_stats(log: str) -> dict[str, int]:
    m = re.search(r"i/o =\s*(\d+)/\s*(\d+)\s+lat =\s*(\d+)\s+and =\s*(\d+)", log)
    return {"inputs": int(m.group(1)), "outputs": int(m.group(2)), "latches": int(m.group(3)),
            "ands": int(m.group(4))} if m else {}


def _run_pdr(chk: dict[str, Any], rd: Path, t0: float) -> dict[str, Any]:
    """Unbounded sequential proof: ABC PDR (IC3) on the miter's single `bad`
    output, from the all-zero reset state (both designs reset every register
    to 0). The AIG statistics are recorded; an empty miter is reported as
    VACUOUS, never as PROVEN."""
    top = chk["top"]
    (rd / "aig.ys").write_text(
        f"read_rtlil elab.il\nhierarchy -top {top}\nproc\nflatten\nasync2sync\nopt -fast\n"
        f"# keep only the property output\ndelete -port w:ok\ntechmap\nopt -fast\nsetundef -zero\n"
        f"# start from the reset state: every flop zero-initialised\nsetundef -init -zero\ndffunmap\n"
        f"aigmap\nopt_clean\nwrite_aiger -zinit miter.aig\n")
    r = common.run([tools.require("yosys"), "-q", "-l", "aig.log", "-s", "aig.ys"], rd / "aig.out", cwd=rd)
    abc = str(Path(tools.require("yosys")).with_name("yosys-abc"))
    eng = chk.get("engine")
    tlim = int(chk.get("timeout", 3000))
    rcs = []
    if eng == "pdr":
        cmds = [("prove", "pdr")]
    elif eng == "abc-bmc":
        # bmc3 -T: ABC stops itself at the limit and reports the depth it reached
        cmds = [("prove", f"bmc3 -F {chk['depth']} -T {tlim} -v")]
    else:
        # k-induction: base case = bmc3 to `depth` frames from reset; inductive step = `ind`
        # from an ARBITRARY state with on-demand state-uniqueness (simple-path) constraints
        cmds = [("base", f"bmc3 -F {chk['depth']} -T {tlim} -v"), ("step", f"ind -F {chk['depth']} -u -v")]
    logs = []
    for tag, cmd in cmds:
        r2 = common.run([abc, "-c", f"read_aiger miter.aig; print_stats; strash; {cmd}"], rd / f"{tag}.log", cwd=rd,
                        timeout=tlim + 300)
        rcs.append(r2["rc"])
        logs.append((rd / f"{tag}.log").read_text())
        if "was asserted" in logs[-1]:
            break                      # base case already has a counterexample
    if eng == "abc-kind":
        (rd / "prove.log").write_text("\n".join(logs))
    log = (rd / "prove.log").read_text()
    status, extra = _abc_seq_status(eng, chk, log)
    if status == "TIMEOUT/INCOMPLETE" and -9 in rcs:
        status = "TIMEOUT"
    if r["rc"] and status != "PROVEN":
        status = "ERROR"
    return {**chk, "status": status, "seconds": round(time.time() - t0, 1), "log": str(rd / "prove.log"),
            "yosys": tools.version("yosys"), "engine": "abc " + "; ".join(c for _, c in cmds), **extra}


def _abc_seq_status(eng: str, chk: dict[str, Any], log: str) -> tuple[str, dict[str, Any]]:
    """Status of a sequential ABC run, exactly as the solver reported it.
    PROVEN: pdr "Property proved"; bmc3 "No output asserted in N frames" with
    N >= depth; k-induction: "Networks are equivalent" from `ind` (inductive
    step at K frames) AND a clean bmc3 base case of at least K frames."""
    st = _aig_stats(log)
    extra: dict[str, Any] = {"aig": st}
    mb = re.search(r"No output asserted in (\d+) frames", log)
    if mb and eng in ("abc-bmc", "abc-kind"):
        extra["frames_reached"] = int(mb.group(1))
    k = None
    if eng == "abc-kind" and "Networks are equivalent" in log:
        mk = re.search(r"Completed (\d+) iterations", log)
        k = int(mk.group(1)) if mk else None
        extra["induction_frames"] = k
    if not st or st["outputs"] != 1 or st["ands"] == 0 or st["latches"] == 0:
        return ("VACUOUS" if st else "INCOMPLETE"), extra
    if "was asserted" in log:
        return "FAILED", extra
    if ((eng == "pdr" and "Property proved" in log) or
            (eng == "abc-bmc" and mb and int(mb.group(1)) >= chk["depth"]) or
            (eng == "abc-kind" and mb and k and int(mb.group(1)) >= k)):
        return "PROVEN", extra
    if eng == "abc-kind" and "Networks are UNDECIDED" in log:
        return "UNDECIDED", extra      # base case clean, but not k-inductive within `depth` frames
    return "TIMEOUT/INCOMPLETE", extra


def _status_from_log(chk: dict[str, Any], rd: Path) -> dict[str, Any]:
    """Recover the outcome of an earlier (possibly interrupted) run from its log."""
    log = (rd / "prove.log").read_text()
    eng = chk.get("engine", "sat")
    aig = _aig_stats(log)
    extra: dict[str, Any] = {}
    if eng in ("pdr", "abc-bmc", "abc-kind"):
        st, extra = _abc_seq_status(eng, chk, log)
        extra["engine"] = {"pdr": "abc pdr", "abc-bmc": "abc bmc3", "abc-kind": "abc bmc3 + ind -u"}[eng]
    elif eng == "abc":
        extra = {"engine": "abc iprove", "aig": aig}
        if not aig or aig["outputs"] != 1 or aig["ands"] == 0:
            st = "VACUOUS" if aig else "INCOMPLETE"
        elif "UNSATISFIABLE" in log:
            st = "PROVEN"
        elif "SATISFIABLE" in log:
            st = "FAILED"
        else:
            st = "TIMEOUT/INCOMPLETE"
    elif "SAT proof finished - no model found: SUCCESS!" in log:
        st = "PROVEN"
    elif "model found" in log:
        st = "FAILED"
    elif re.search(r"timeout|interrupt", log, re.I):
        st = "TIMEOUT"
    else:
        st = "INCOMPLETE"
    secs = round((rd / "prove.log").stat().st_mtime - (rd / "elab.ys").stat().st_mtime, 1)
    return {**chk, "status": st, "seconds": secs, "log": str(rd / "prove.log"), "yosys": tools.version("yosys"),
            **extra}


def _summary(res: list[dict[str, Any]]) -> dict[str, Any]:
    proofs = [r for r in res if "expect" not in r]
    wit = [r for r in res if "expect" in r]
    gating = [r for r in proofs if r["gate"]]
    return {"checks": res, "proven": sum(1 for r in proofs if r["status"] == "PROVEN"), "total": len(proofs),
            "gating_proven": sum(1 for r in gating if r["status"] == "PROVEN"), "gating_total": len(gating),
            "witnesses_ok": sum(1 for r in wit if r["status"] == r["expect"]), "witnesses_total": len(wit)}


def collect(out: Path) -> dict[str, Any]:
    """Rebuild formal.json from the per-check directories (no solver runs)."""
    res = []
    for c in CHECKS:
        rd = out / c["name"]
        if (rd / "prove.log").exists():
            res.append({**_status_from_log(c, rd), "gate": c.get("gate", True), "claim": c["claim"]})
    summary = _summary(res)
    (out / "formal.json").write_text(json.dumps(summary, indent=1))
    return summary


def run_all(out: Path, names: list[str] | None = None) -> dict[str, Any]:
    """Run the selected checks and merge them into reports/formal/formal.json."""
    out.mkdir(parents=True, exist_ok=True)
    prev = {}
    if (out / "formal.json").exists():
        prev = {c["name"]: c for c in json.loads((out / "formal.json").read_text()).get("checks", [])}
    for c in CHECKS:
        if not names or c["name"] in names:
            prev[c["name"]] = run_check(c, out)
        elif c["name"] not in prev and (out / c["name"] / "prove.log").exists():
            prev[c["name"]] = _status_from_log(c, out / c["name"])
    res = [{**prev[c["name"]], "gate": c.get("gate", True), "claim": c["claim"]} for c in CHECKS if c["name"] in prev]
    summary = _summary(res)
    (out / "formal.json").write_text(json.dumps(summary, indent=1))
    return summary
