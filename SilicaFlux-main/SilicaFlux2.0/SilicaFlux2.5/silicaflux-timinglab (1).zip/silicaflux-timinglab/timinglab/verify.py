"""Lint, equivalence simulation and mutation testing (Verilator).

* lint      : verilator --lint-only -Wall on every catalogue design. For a
              TimingLab alternative the gate is: no errors, and no warning
              class that its upstream baseline does not already produce.
* equiv     : builds tb/equiv/*.sv in several configurations and runs several
              seeds; parses the "TL-RESULT PASS|FAIL" line.
* mutation  : applies single-line mutations to the TimingLab RTL and requires
              the equivalence bench to FAIL for every mutant (proves the bench
              can see the bugs the optimisation could plausibly introduce).
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
from collections import Counter
from pathlib import Path
from typing import Any

from . import config, tools
from .flow import common

MAKEFLAGS = "CXX=g++ LINK=g++ AR=ar"

PKG = "SilicaFlux-main/silicaflux_pkg (1).sf"
VE = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/vector_engine.sf"
ALU = "SilicaFlux-main/alu.sf"
OPT = ["tl:rtl/opt/sf_csa_tree.sv", "tl:rtl/opt/sf_mul_lo_csa.sv", "tl:rtl/opt/sf_reduce_tree.sv"]

BENCHES: dict[str, dict[str, Any]] = {
    "tb_eq_vector": {
        "top": "tb_eq_vector",
        "files": [PKG, VE] + OPT + ["tl:rtl/opt/sf_vector_engine_pipe.sv", "tl:tb/equiv/tb_eq_vector.sv"],
        "dut": "tl:rtl/opt/sf_vector_engine_pipe.sv",
        "configs": {
            "exact_l4":        ["--assert"],
            "flush_l4":        ["--assert", "+define+TL_FLUSH_PCT=10"],
            "illegal_flush":   ["+define+SYNTHESIS", "+define+TL_ILLEGAL_PCT=15", "+define+TL_FLUSH_PCT=5"],
            "ref_ex2":         ["--assert", "+define+TL_REF_EX=2"],
            "flush_l8":        ["--assert", "+define+TL_LANES=8", "+define+TL_FLUSH_PCT=5"],
            "exact_l16_w16":   ["--assert", "+define+TL_LANES=16", "+define+TL_LANE_W=16"],
        },
        "mutation_config": ["+define+SYNTHESIS", "+define+TL_FLUSH_PCT=5"],
        "mutants": [
            ("assign raw     = r2.raw_nm[l] | ({LANE_W{r2.ctrl.unit.mul}} & mul_res);",
             "assign raw     = r2.raw_nm[l] | ({LANE_W{r2.ctrl.unit.add}} & mul_res);"),
            ("assign mul_res = r2.mul_s[l] + r2.mul_c[l];", "assign mul_res = r2.mul_s[l] ^ r2.mul_c[l];"),
            ("assign leaf[l] = r1.active[l] ? r1.a[l] : ident;", "assign leaf[l] = r1.a[l];"),
            ("r2_q.vld <= r2_q.vld & ~(flush_i & r2_q.spec);", "r2_q.vld <= r2_q.vld;"),
            ("r1.vld = r1_q.vld & ~(flush_i & r1_q.spec);", "r1.vld = r1_q.vld;"),
            ("exa_pkt.vd     = r1.vd;", "exa_pkt.vd     = r1.b;"),
            ("assign exb_sat = |(r2.sat & exb_lane_we);", "assign exb_sat = |(r2.sat);"),
            ("sat_evt   = r1.ctrl.sat & (r1.ctrl.sat_s ? ovf_s : ovf_u);",
             "sat_evt   = r1.ctrl.sat & (r1.ctrl.sat_s ? ovf_u : ovf_s);"),
            ("r1_q.vld <= r1_q.vld & ~(flush_i & r1_q.spec);", "r1_q.vld <= r1_q.vld;"),
        ],
    },
    "tb_eq_alu": {
        "top": "tb_eq_alu",
        "files": [PKG, ALU] + OPT[:2] + ["tl:rtl/opt/sf_alu_mulcsa.sv", "tl:tb/equiv/tb_eq_alu.sv"],
        "dut": "tl:rtl/opt/sf_alu_mulcsa.sv",
        "configs": {
            "x64_m2": ["--assert"],
            "x64_m3": ["--assert", "+define+TL_MUL_STAGES=3"],
            "x32_m2": ["--assert", "+define+TL_XLEN=32"],
        },
        "mutation_config": ["+define+SYNTHESIS"],
        "mutants": [
            ("assign mul_tail_data = mul_pp_q[MUL_PP_N-1].s + mul_pp_q[MUL_PP_N-1].c;",
             "assign mul_tail_data = mul_pp_q[MUL_PP_N-1].s + {mul_pp_q[MUL_PP_N-1].c[XLEN-2:0], 1'b0};"),
            ("assign mul_tail_data = mul_pp_q[MUL_PP_N-1].s + mul_pp_q[MUL_PP_N-1].c;",
             "assign mul_tail_data = mul_pp_q[MUL_PP_N-1].s;"),
            ("          .a_i     (mul_a_q),", "          .a_i     (mul_b_q),"),
        ],
    },
}

# Mutations of the shared building blocks, checked through the vector bench.
SHARED_MUTANTS = [
    ("tl:rtl/opt/sf_csa_tree.sv", "assign row[2*g+1] = {maj[W-2:0], 1'b0};", "assign row[2*g+1] = maj;"),
    ("tl:rtl/opt/sf_reduce_tree.sv", "assign sum_res = s_row + c_row;", "assign sum_res = s_row | c_row;"),
    ("tl:rtl/opt/sf_mul_lo_csa.sv", "assign pp[i] = gated << i;", "assign pp[i] = gated << (i ^ 1);"),
]


def _stage(files: list[str], dest: Path, overrides: dict[str, str] | None = None) -> list[str]:
    dest.mkdir(parents=True, exist_ok=True)
    out = []
    for i, spec in enumerate(files):
        disp, data = config.resolve_source(spec)
        name = f"{i:02d}_{common.sanitize(disp)}"
        text = data.decode()
        if overrides and spec in overrides:
            text = overrides[spec]
        (dest / name).write_text(text)
        out.append(str(dest / name))
    return out


def _build(top: str, srcs: list[str], flags: list[str], mdir: Path) -> dict[str, Any]:
    if mdir.exists():
        shutil.rmtree(mdir)
    cmd = [tools.require("verilator"), "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O2",
           "--top-module", top, "-Mdir", str(mdir), "-MAKEFLAGS", MAKEFLAGS, "-j", "4", *flags, *srcs]
    r = common.run(cmd, mdir.parent / f"{mdir.name}.build.log", cwd=mdir.parent, timeout=1800)
    r["binary"] = str(mdir / f"V{top}")
    r["ok"] = r["rc"] == 0 and Path(r["binary"]).exists()
    return r


def _sim(binary: str, seed: int, cycles: int, log: Path) -> dict[str, Any]:
    r = common.run([binary, f"+seed={seed}", f"+cycles={cycles}"], log, cwd=log.parent, timeout=1800)
    txt = log.read_text()
    m = re.search(r"TL-RESULT (PASS|FAIL)(.*)", txt)
    errs = [l for l in txt.splitlines() if l.startswith("ERROR") or "Assertion failed" in l][:5]
    return {"seed": seed, "cycles": cycles, "status": m.group(1) if m else "NO-RESULT",
            "detail": m.group(2).strip() if m else "", "errors": errs, "rc": r["rc"]}


def run_equiv(out: Path, seeds: tuple[int, ...] = (1, 2, 3), cycles: int = 20000) -> dict[str, Any]:
    res: dict[str, Any] = {}
    for bench, spec in BENCHES.items():
        bdir = out / bench
        srcs = _stage(spec["files"], bdir / "src")
        res[bench] = {}
        for cfg, flags in spec["configs"].items():
            b = _build(spec["top"], srcs, flags, bdir / f"obj_{cfg}")
            runs = [_sim(b["binary"], s, cycles, bdir / f"{cfg}_s{s}.log") for s in seeds] if b["ok"] else []
            res[bench][cfg] = {"flags": flags, "build_ok": b["ok"], "runs": runs,
                               "pass": b["ok"] and all(r["status"] == "PASS" for r in runs)}
    res["all_pass"] = all(c["pass"] for b in BENCHES for c in res[b].values())
    (out / "equiv.json").write_text(json.dumps(res, indent=1))
    return res


def run_mutation(out: Path, cycles: int = 5000) -> dict[str, Any]:
    res: list[dict[str, Any]] = []
    jobs: list[tuple[str, str, str, str]] = []
    for bench, spec in BENCHES.items():
        for old, new in spec["mutants"]:
            jobs.append((bench, spec["dut"], old, new))
    for f, old, new in SHARED_MUTANTS:
        jobs.append(("tb_eq_vector", f, old, new))
    for k, (bench, target, old, new) in enumerate(jobs):
        spec = BENCHES[bench]
        text = config.resolve_source(target)[1].decode()
        rec = {"id": k, "bench": bench, "file": target, "from": old, "to": new}
        if text.count(old) < 1:
            rec["status"] = "MUTANT-NOT-APPLIED"
            res.append(rec)
            continue
        mdir = out / "mutants" / f"m{k:02d}"
        srcs = _stage(spec["files"], mdir / "src", {target: text.replace(old, new, 1)})
        b = _build(spec["top"], srcs, spec["mutation_config"], mdir / "obj")
        if not b["ok"]:
            rec["status"] = "BUILD-FAILED"
        else:
            s = _sim(b["binary"], 1, cycles, mdir / "sim.log")
            rec["status"] = "KILLED" if s["status"] == "FAIL" else "SURVIVED"
            rec["sim"] = s
        shutil.rmtree(mdir / "obj", ignore_errors=True)
        res.append(rec)
    summary = {"mutants": res, "killed": sum(1 for r in res if r["status"] == "KILLED"), "total": len(res)}
    (out / "mutation.json").write_text(json.dumps(summary, indent=1))
    return summary


def lint_design(cat: config.Catalogue, name: str, out: Path) -> dict[str, Any]:
    d = cat.design(name)
    ldir = out / name
    srcs = _stage(d.files, ldir / "src")
    cmd = [tools.require("verilator"), "--lint-only", "-Wall", "-Wno-DECLFILENAME", "--top-module", d.top,
           *[f"-G{k}={int(v) if isinstance(v, bool) else v}" for k, v in d.params.items()], *srcs]
    r = common.run(cmd, ldir / "lint.log", cwd=ldir)
    txt = (ldir / "lint.log").read_text()
    msgs = re.findall(r"^%(Warning|Error)-?([A-Z0-9_]*)?: ([^:]+):(\d+):\d+: (.*)$", txt, re.M)
    classes = Counter(f"{k}-{c}" for k, c, *_ in msgs)
    errors = sum(1 for k, *_ in msgs if k == "Error") + (1 if "%Error:" in txt and not msgs else 0)
    return {"design": name, "rc": r["rc"], "errors": errors, "warning_classes": dict(classes),
            "messages": [f"{k}-{c} {f.split('/')[-1]}:{l} {m}" for k, c, f, l, m in msgs][:60]}


def run_lint(cat: config.Catalogue, out: Path) -> dict[str, Any]:
    res = {n: lint_design(cat, n, out) for n in cat.designs}
    for n, d in cat.designs.items():
        if d.baseline:
            base = set(res[d.baseline]["warning_classes"])
            new = sorted(set(res[n]["warning_classes"]) - base)
            res[n]["new_warning_classes_vs_baseline"] = new
            res[n]["gate"] = "PASS" if res[n]["errors"] == 0 and not new else "FAIL"
        else:
            res[n]["gate"] = "PASS" if res[n]["errors"] == 0 else "FAIL"
    (out / "lint.json").write_text(json.dumps(res, indent=1))
    return res


def netlist_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()
