"""Configuration: design catalogue (flow/designs.toml) and PDK descriptions
(flow/pdk/*.toml).  Paths may use ${VAR} and ${VAR:-default}."""
from __future__ import annotations

import os
import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent

_VAR = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")


def expand(s: str, extra: dict[str, str] | None = None) -> str:
    env = dict(DEFAULT_ENV())
    env.update(os.environ)
    if extra:
        env.update(extra)

    def rep(m: re.Match) -> str:
        v = env.get(m.group(1))
        if v is None or v == "":
            if m.group(2) is not None:
                return m.group(2)
            raise KeyError(f"environment variable {m.group(1)} is not set (needed by '{s}')")
        return v

    return _VAR.sub(rep, s)


def DEFAULT_ENV() -> dict[str, str]:
    return {
        "TL_ROOT": str(ROOT),
        "TL_SF_ROOT": str(ROOT / "upstream"),
        "TL_PLATFORMS": str(ROOT / "third_party" / "platforms"),
    }


@dataclass
class Pdk:
    name: str
    raw: dict[str, Any]

    @property
    def platform_dir(self) -> Path:
        return Path(expand(self.raw["platform_dir"]))

    def path(self, rel: str) -> Path:
        return self.platform_dir / rel if rel else Path()

    @property
    def libs(self) -> list[Path]:
        return [self.path(l) for l in self.raw["lib"]]

    @property
    def tech_lef(self) -> Path:
        return self.path(self.raw["tech_lef"])

    @property
    def sc_lefs(self) -> list[Path]:
        return [self.path(l) for l in self.raw["sc_lef"]]

    def __getattr__(self, item: str) -> Any:
        try:
            return self.raw[item]
        except KeyError:
            raise AttributeError(item) from None

    def available(self) -> tuple[bool, list[str]]:
        missing = [str(p) for p in [*self.libs, self.tech_lef, *self.sc_lefs] if not p.exists()]
        return (not missing, missing)


@dataclass
class Design:
    name: str
    raw: dict[str, Any]

    @property
    def top(self) -> str:
        return self.raw["top"]

    @property
    def files(self) -> list[str]:
        return list(self.raw["files"])

    @property
    def params(self) -> dict[str, Any]:
        return dict(self.raw.get("params", {}))

    @property
    def clock(self) -> str:
        return self.raw.get("clock", "clk_i")

    @property
    def reset(self) -> str:
        return self.raw.get("reset", "rst_ni")

    @property
    def sdc(self) -> str:
        return self.raw.get("sdc", "constraints/block.sdc")

    def period(self, pdk: Pdk) -> float:
        per = self.raw.get("period", {})
        return float(per.get(pdk.name, pdk.default_period_ns))

    @property
    def baseline(self) -> str | None:
        return self.raw.get("alternative_of")

    @property
    def role(self) -> str:
        return self.raw.get("role", "upstream")

    def __getattr__(self, item: str) -> Any:
        try:
            return self.raw[item]
        except KeyError:
            raise AttributeError(item) from None


@dataclass
class Catalogue:
    designs: dict[str, Design]
    pdks: dict[str, Pdk]
    defaults: dict[str, Any] = field(default_factory=dict)

    def design(self, name: str) -> Design:
        if name not in self.designs:
            raise KeyError(f"unknown design '{name}'; known: {', '.join(sorted(self.designs))}")
        return self.designs[name]

    def pdk(self, name: str) -> Pdk:
        if name not in self.pdks:
            raise KeyError(f"unknown PDK '{name}'; known: {', '.join(sorted(self.pdks))}")
        return self.pdks[name]

    def pairs(self) -> list[tuple[str, str]]:
        """(baseline, alternative) pairs declared in the catalogue."""
        return [(d.baseline, d.name) for d in self.designs.values() if d.baseline]


def load(root: Path = ROOT) -> Catalogue:
    data = tomllib.loads((root / "flow" / "designs.toml").read_text())
    designs = {k: Design(k, v) for k, v in data.get("design", {}).items()}
    pdks = {}
    for f in sorted((root / "flow" / "pdk").glob("*.toml")):
        raw = tomllib.loads(f.read_text())
        pdks[raw["name"]] = Pdk(raw["name"], raw)
    return Catalogue(designs, pdks, data.get("defaults", {}))


def resolve_source(spec: str) -> tuple[str, bytes]:
    """Resolve a designs.toml file entry to (display path, content).

    Forms:  "SilicaFlux-main/x.sf"          relative to ${TL_SF_ROOT}
            "archive.zip!member"            member of an archive under ${TL_SF_ROOT}
            "tl:rtl/opt/x.sv"               TimingLab's own sources
    """
    import zipfile
    if spec.startswith("tl:"):
        p = ROOT / spec[3:]
        return str(p), p.read_bytes()
    sf_root = Path(expand("${TL_SF_ROOT}"))
    if "!" in spec:
        arch, member = spec.split("!", 1)
        with zipfile.ZipFile(sf_root / arch) as z:
            return f"{arch}!{member}", z.read(member)
    p = sf_root / spec
    return spec, p.read_bytes()
