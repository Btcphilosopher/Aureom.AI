"""SDC hygiene.

lint(path)  : every timing exception (set_false_path, set_multicycle_path,
              set_clock_groups, set_max_delay, set_min_delay,
              set_disable_timing, set_case_analysis) must be preceded by a
              comment block containing "JUSTIFY:" that cites its evidence.
stub_check  : for a top that cannot be elaborated (silicaflux_top.sf), build
              a port / instance stub from the source with the syntax scanner
              and let OpenSTA read the SDC against it. Any object that is not
              in the source shows up as an OpenSTA "not found" warning.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from . import config, svscan, tools
from .flow import common

EXCEPTIONS = ("set_false_path", "set_multicycle_path", "set_clock_groups", "set_max_delay", "set_min_delay",
              "set_disable_timing", "set_case_analysis")


def lint(path: Path) -> dict[str, Any]:
    lines = path.read_text().splitlines()
    findings = []
    n_exc = 0
    for i, line in enumerate(lines):
        s = line.strip()
        cmd = s.split()[0] if s and not s.startswith("#") else ""
        if cmd in EXCEPTIONS:
            n_exc += 1
            j, block = i - 1, []
            while j >= 0 and (lines[j].strip().startswith("#") or lines[j].strip() == "" or
                              lines[j].strip().split()[0:1] in [[c] for c in EXCEPTIONS]) and len(block) < 25:
                block.append(lines[j])
                j -= 1
            if not any("JUSTIFY:" in b for b in block):
                findings.append({"line": i + 1, "command": cmd, "problem": "exception without JUSTIFY: comment"})
    return {"file": str(path.relative_to(config.ROOT)), "exceptions": n_exc, "findings": findings,
            "pass": not findings}


def lint_all() -> list[dict[str, Any]]:
    return [lint(p) for p in sorted((config.ROOT / "constraints").glob("*.sdc"))]


def stub_verilog(src_text: str, path: str, top: str, instances: list[str]) -> str:
    fs = svscan.scan_text(src_text, path)
    d = next(x for x in fs.definitions if x.name == top)
    mods = []
    inst_lines = []
    for inst in d.instances:
        if inst.names[0] not in instances:
            continue
        ports = [p for p in inst.connections if not p.startswith("#")]
        decl = ",\n  ".join(f"{'output' if p.endswith('_o') else 'input'} {p}" for p in ports)
        mods.append(f"module {inst.module} (\n  {decl}\n);\nendmodule\n")
        conns = ", ".join(f".{p}(tl_{inst.names[0]}_{p})" for p in ports)
        wires = " ".join(f"wire tl_{inst.names[0]}_{p};" for p in ports)
        inst_lines.append(f"  {wires}\n  {inst.module} {inst.names[0]} ({conns});")
    port_decl = ",\n  ".join(f"{p.direction if p.direction in ('input', 'output') else 'input'} {p.name}"
                             for p in d.ports)
    return "\n".join(mods) + f"module {top} (\n  {port_decl}\n);\n" + "\n".join(inst_lines) + "\nendmodule\n"


def stub_check(sdc: Path, src_spec: str, top: str, instances: list[str], out: Path) -> dict[str, Any]:
    out = out.resolve()
    sdc = sdc.resolve()
    out.mkdir(parents=True, exist_ok=True)
    disp, data = config.resolve_source(src_spec)
    (out / "stub.v").write_text(stub_verilog(data.decode(), disp, top, instances))
    (out / "check.tcl").write_text(f"read_verilog {out / 'stub.v'}\nlink_design {top}\n"
                                   f"read_sdc {sdc}\nreport_clock_properties\nputs TL-SDC-DONE\nexit\n")
    r = common.run([tools.require("sta"), "-no_init", "-no_splash", "-exit", str(out / "check.tcl")],
                   out / "check.log", cwd=out)
    log = (out / "check.log").read_text()
    warns = [l for l in log.splitlines() if re.search(r"(Warning|Error).*(not found|unknown|invalid)", l, re.I)]
    errs = [l for l in log.splitlines() if l.startswith("Error")]
    clocks = re.findall(r"^(\S+)\s+([0-9.]+)\s+", log, re.M)
    try:
        sdc_name = str(sdc.relative_to(config.ROOT))
    except ValueError:
        sdc_name = str(sdc)
    return {"sdc": sdc_name, "top": top, "source": disp, "rc": r["rc"],
            "completed": "TL-SDC-DONE" in log, "unresolved_objects": warns, "errors": errs,
            "clocks": [c for c in clocks if c[0] not in ("Clock",)][:20],
            "pass": "TL-SDC-DONE" in log and not warns and not errs}
