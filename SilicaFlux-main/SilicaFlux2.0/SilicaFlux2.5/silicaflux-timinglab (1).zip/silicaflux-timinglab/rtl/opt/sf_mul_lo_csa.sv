// =============================================================================
//  SilicaFlux TimingLab - sf_mul_lo_csa
//
//  Low W bits of the product a * b in carry-save form:
//
//      (sum_o + carry_o) mod 2^W == (a_i * b_i) mod 2^W
//
//  The low half of a two's-complement product equals the low half of the
//  unsigned product, so this serves signed and unsigned MUL (vector_engine.sf
//  line 429: mul_res = a * b, LANE_W bits).
//
//  Structure: W AND-gated partial products (row i = (a & b[i]) << i, truncated
//  to W bits) reduced by sf_csa_tree. The final carry-propagate add is left to
//  the caller so a pipeline register can sit between the compressor tree and
//  the CPA (sf_vector_engine_pipe does exactly that).
//
//  Why not rely on '*': the default Yosys mapping of $mul is an array
//  multiplier whose depth grows linearly with W (TimingLab measured 60+
//  levels for the 32-bit lane multiplier, reports/), whereas the compressor
//  tree here grows with log_{3/2}(W).
// =============================================================================
module sf_mul_lo_csa #(
  parameter int unsigned W = 32
) (
  input  logic [W-1:0] a_i,
  input  logic [W-1:0] b_i,
  output logic [W-1:0] sum_o,
  output logic [W-1:0] carry_o
);

  logic [W-1:0][W-1:0] pp;

  for (genvar i = 0; i < W; i++) begin : g_pp
    logic [W-1:0] gated;
    assign gated = a_i & {W{b_i[i]}};
    assign pp[i] = gated << i;               // truncated to W bits
  end

  sf_csa_tree #(.W(W), .N(W)) u_tree (
    .rows_i  (pp),
    .sum_o   (sum_o),
    .carry_o (carry_o)
  );

endmodule : sf_mul_lo_csa
