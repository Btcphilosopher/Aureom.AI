// =============================================================================
//  SilicaFlux TimingLab - sf_reduce_tree
//
//  Hierarchical cross-lane reduction network with the operator set of
//  vector_engine.sf (ROP_SUM / ROP_AND / ROP_OR / ROP_XOR, lines 193-198,
//  295-303):
//
//    SUM : N-operand carry-save tree (sf_csa_tree) + one carry-propagate add,
//          i.e. ONE CPA instead of log2(N) CPAs in series (upstream heap tree)
//    AND / OR / XOR : balanced binary tree, log2(N) gate levels
//
//  Results are identical (mod 2^W) to the upstream heap-ordered tree for every
//  input; operator selection is a final 4:1 mux instead of a mux at every
//  tree node. N must be a power of two (vector_engine.sf restricts LANES to
//  4 / 8 / 16).
// =============================================================================
module sf_reduce_tree #(
  parameter int unsigned W = 32,
  parameter int unsigned N = 4
) (
  input  logic [1:0]          rop_i,      // 0 SUM, 1 AND, 2 OR, 3 XOR
  input  logic [N-1:0][W-1:0] leaf_i,
  output logic [W-1:0]        red_o
);

  localparam int unsigned LV = $clog2(N);

  // ---------------------------------------------------------------- SUM
  logic [W-1:0] s_row, c_row, sum_res;
  sf_csa_tree #(.W(W), .N(N)) u_sum_csa (.rows_i(leaf_i), .sum_o(s_row), .carry_o(c_row));
  assign sum_res = s_row + c_row;

  // ---------------------------------------------------------------- bitwise
  for (genvar lv = 0; lv <= LV; lv++) begin : g_lvl
    localparam int unsigned NODES = N >> lv;
    logic [W-1:0] n_and [NODES];
    logic [W-1:0] n_or  [NODES];
    logic [W-1:0] n_xor [NODES];
    for (genvar n = 0; n < NODES; n++) begin : g_node
      if (lv == 0) begin : g_leaf
        assign n_and[n] = leaf_i[n];
        assign n_or[n]  = leaf_i[n];
        assign n_xor[n] = leaf_i[n];
      end else begin : g_inner
        assign n_and[n] = g_lvl[lv-1].n_and[2*n] & g_lvl[lv-1].n_and[2*n+1];
        assign n_or[n]  = g_lvl[lv-1].n_or[2*n]  | g_lvl[lv-1].n_or[2*n+1];
        assign n_xor[n] = g_lvl[lv-1].n_xor[2*n] ^ g_lvl[lv-1].n_xor[2*n+1];
      end
    end
  end

  always_comb begin
    case (rop_i)
      2'd0:    red_o = sum_res;
      2'd1:    red_o = g_lvl[LV].n_and[0];
      2'd2:    red_o = g_lvl[LV].n_or[0];
      default: red_o = g_lvl[LV].n_xor[0];
    endcase
  end

  // synthesis translate_off
  initial begin
    if (N < 2 || (N & (N - 1)) != 0) $fatal(1, "sf_reduce_tree: N must be a power of two >= 2");
  end
  // synthesis translate_on

endmodule : sf_reduce_tree
