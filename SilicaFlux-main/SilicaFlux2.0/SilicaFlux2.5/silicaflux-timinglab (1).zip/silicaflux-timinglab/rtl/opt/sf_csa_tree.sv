// =============================================================================
//  SilicaFlux TimingLab - sf_csa_tree
//
//  Wallace-style carry-save reduction of N W-bit rows to two rows using 3:2
//  compressors (full adders), modulo 2^W:
//
//      (sum_o + carry_o) mod 2^W  ==  (rows_i[0] + ... + rows_i[N-1]) mod 2^W
//
//  Depth is ceil(log_{3/2}(N/2)) full-adder levels and independent of W, so a
//  following carry-propagate adder (CPA) is the only W-dependent part. Each
//  level groups rows in threes; leftover rows pass to the next level.
//
//  Used by sf_mul_lo_csa (partial-product reduction) and sf_reduce_tree
//  (multi-operand lane reduction). Purely combinational; pipeline registers
//  are owned by the instantiating stage so stall / flush semantics stay in
//  one place.
// =============================================================================
module sf_csa_tree #(
  parameter int unsigned W = 32,
  parameter int unsigned N = 3
) (
  input  logic [N-1:0][W-1:0] rows_i,
  output logic [W-1:0]        sum_o,
  output logic [W-1:0]        carry_o
);

  function automatic int unsigned rows_after(input int unsigned n);
    return (n > 2) ? (n - n / 3) : n;
  endfunction

  function automatic int unsigned rows_at(input int unsigned lvl);
    int unsigned n;
    n = N;
    for (int unsigned i = 0; i < lvl; i++) begin
      n = rows_after(n);
    end
    return n;
  endfunction

  function automatic int unsigned n_levels();
    int unsigned n;
    int unsigned l;
    n = N;
    l = 0;
    while (n > 2) begin
      n = rows_after(n);
      l++;
    end
    return l;
  endfunction

  localparam int unsigned LEVELS = n_levels();

  for (genvar lv = 0; lv <= LEVELS; lv++) begin : g_lvl
    localparam int unsigned NR = rows_at(lv);
    logic [W-1:0] row [NR];

    if (lv == 0) begin : g_in
      for (genvar r = 0; r < NR; r++) begin : g_r
        assign row[r] = rows_i[r];
      end
    end else begin : g_csa
      localparam int unsigned NP = rows_at(lv - 1);
      localparam int unsigned NG = NP / 3;
      for (genvar g = 0; g < NG; g++) begin : g_fa
        logic [W-1:0] x, y, z;
        /* verilator lint_off UNUSEDSIGNAL */
        logic [W-1:0] maj;                        // maj[W-1] has weight 2^W: dropped (mod 2^W)
        /* verilator lint_on UNUSEDSIGNAL */
        assign x   = g_lvl[lv-1].row[3*g];
        assign y   = g_lvl[lv-1].row[3*g+1];
        assign z   = g_lvl[lv-1].row[3*g+2];
        assign maj = (x & y) | (x & z) | (y & z);
        assign row[2*g]   = x ^ y ^ z;
        assign row[2*g+1] = {maj[W-2:0], 1'b0};   // carry weight 2, mod 2^W
      end
      for (genvar k = 0; k < NP - 3 * NG; k++) begin : g_pass
        assign row[2*NG+k] = g_lvl[lv-1].row[3*NG+k];
      end
    end
  end

  if (N == 1) begin : g_out1
    assign sum_o   = g_lvl[LEVELS].row[0];
    assign carry_o = '0;
  end else begin : g_out2
    assign sum_o   = g_lvl[LEVELS].row[0];
    assign carry_o = g_lvl[LEVELS].row[1];
  end

  // synthesis translate_off
  initial begin
    if (W < 2) $fatal(1, "sf_csa_tree: W must be >= 2");
    if (N < 1) $fatal(1, "sf_csa_tree: N must be >= 1");
  end
  // synthesis translate_on

endmodule : sf_csa_tree
