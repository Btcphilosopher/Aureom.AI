// =============================================================================
//  SilicaFlux TimingLab - sf_vector_engine_pipe
//
//  Pipelined, port-compatible alternative to
//      SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/vector_engine.sf
//  (module vector_engine). Decode, operand selection, lane arithmetic, mask
//  merge and output-register logic are taken from the upstream source; only
//  the stage boundaries and the multiplier / reduction structure change.
//
//  Measured problem (TimingLab, reports/): with the upstream default
//  EX_STAGES=1, ISSUE+EX1+EX2 form a single cycle of ~60 mapped logic levels:
//  opcode decode -> 32x32 array multiplier -> one-hot AND-OR select -> two
//  32-bit adders of the REDSUM heap tree -> res_scalar_q.
//
//  Stage map (latency 3, throughput 1/cycle; upstream: latency 1)
//    ISS  (comb)  : decode, operand-B source select, lane activity  [upstream]
//    R1   (reg)   : issue register - decoded control word is broadcast to all
//                   lanes from flops (register placement around execution)
//    EXA  (comb)  : adder/saturator, comparator, logic, barrel shifter
//                   [upstream]; multiplier partial products reduced to two
//                   rows (sf_mul_lo_csa); cross-lane reduction (sf_reduce_tree,
//                   one CPA instead of a heap of CPAs)
//    R2   (reg)
//    EXB  (comb)  : multiplier carry-propagate add, one-hot AND-OR result
//                   select, mask/tail merge, saturation summary  [upstream]
//    OUT  (reg)   : result register  [upstream, unchanged]
//
//  Flow control / speculation: every stage register follows the upstream
//  EX_STAGES=2 boundary (vector_engine.sf lines 469-491): stall_i freezes it
//  while killing a held speculative packet on flush_i; packets read out of a
//  stage are masked by flush_i & spec. iss_ready_o = ~stall_i and
//  iss_fpx_o are unchanged (issue-time, combinational as upstream).
//  busy_o covers R1, R2 and the output register.
//
//  Observable-behaviour contract (checked by tb/equiv/tb_eq_vector.sv):
//    * Every consumed result (res_valid_o & ~stall_i) carries the same
//      res_spec/tag/illegal/data/lane_we/sat/scalar_wr as the upstream engine
//      for the same issue packet, in the same order.
//    * res_scalar_o is identical whenever res_scalar_wr_o = 1, i.e. for every
//      reduction result. For non-reduction ops it is not written by the
//      register file (qualified by res_scalar_wr_o, vector_engine.sf line
//      117-119) and is NOT guaranteed equal: upstream reduces the selected
//      lane result (raw, which for every legal REDxxx op equals operand a,
//      because reductions select unit.lgc with lop = LOP_PASS, lines 255,
//      277-280, 418), here the reduction reads operand a directly. This
//      removes the functionally false path multiplier -> reduction tree.
//    * Latency 3 instead of 1 (issue cycle t -> res_valid_o at t+3 without
//      stalls). The issuing control core must account for the deeper
//      pipeline when it computes speculative-kill windows (flush_i kills all
//      in-flight speculative packets, as upstream).
//  The EX_STAGES parameter is accepted for drop-in compatibility and ignored.
// =============================================================================
module sf_vector_engine_pipe
  import silicaflux_pkg::*;
#(
  parameter  int unsigned LANES        = 4,
  parameter  int unsigned LANE_W       = 32,
  parameter  bit          MUL_EN       = 1'b1,
  parameter  bit          SAT_EN       = 1'b1,
  parameter  bit          RED_EN       = 1'b1,
  /* verilator lint_off UNUSEDPARAM */
  parameter  int unsigned EX_STAGES    = 1,      // accepted for drop-in compatibility, ignored
  /* verilator lint_on UNUSEDPARAM */
  parameter  int unsigned TAG_W        = 6,
  /* verilator lint_off UNUSEDPARAM */
  localparam int unsigned VLEN         = LANES * LANE_W,
  /* verilator lint_on UNUSEDPARAM */
  localparam int unsigned VL_W         = $clog2(LANES + 1),
  localparam int unsigned VOP_W        = 6,
  localparam int unsigned VOP_FN_W     = 3,
  localparam int unsigned BSRC_W       = 2
) (
  input  logic                                  clk_i,
  input  logic                                  rst_ni,
  input  logic                                  stall_i,
  input  logic                                  flush_i,
  output logic                                  iss_ready_o,
  output logic                                  busy_o,
  input  logic                                  iss_valid_i,
  input  logic                                  iss_spec_i,
  input  logic [TAG_W-1:0]                      iss_tag_i,
  input  logic [VOP_W-1:0]                      iss_op_i,
  input  logic [BSRC_W-1:0]                     iss_bsrc_i,
  input  logic                                  iss_mask_en_i,
  input  logic [LANES-1:0]                      iss_mask_i,
  input  logic [VL_W-1:0]                       iss_vl_i,
  input  logic                                  iss_mpol_i,
  input  logic [LANES-1:0][LANE_W-1:0]          iss_va_i,
  input  logic [LANES-1:0][LANE_W-1:0]          iss_vb_i,
  input  logic [LANES-1:0][LANE_W-1:0]          iss_vd_i,
  input  logic [LANE_W-1:0]                     iss_scalar_i,
  input  logic [LANES-1:0][LANE_W-1:0]          xlane_b_i,
  output logic                                  iss_fpx_o,
  output logic                                  res_valid_o,
  output logic                                  res_spec_o,
  output logic [TAG_W-1:0]                      res_tag_o,
  output logic                                  res_illegal_o,
  output logic [LANES-1:0][LANE_W-1:0]          res_data_o,
  output logic [LANES-1:0]                      res_lane_we_o,
  output logic                                  res_sat_o,
  output logic                                  res_scalar_wr_o,
  output logic [LANE_W-1:0]                     res_scalar_o
);

  localparam int unsigned LANE_MSB = LANE_W - 1;
  localparam int unsigned SHAMT_W  = $clog2(LANE_W);
  /* verilator lint_off UNUSEDPARAM */
  localparam int unsigned LATENCY  = 3;   // documentation; checked by tb/equiv/tb_eq_vector.sv
  /* verilator lint_on UNUSEDPARAM */

  // ===========================================================================
  // Types (upstream lines 133-237)
  // ===========================================================================
  typedef int unsigned                  ve_uint_t;
  typedef logic [LANE_W-1:0]            lane_t;
  typedef logic [LANES-1:0][LANE_W-1:0] lane_vec_t;
  typedef logic [LANES-1:0]             lane_mask_t;
  typedef logic [SHAMT_W-1:0]           shamt_t;
  typedef logic [TAG_W-1:0]             tag_t;
  typedef logic [VOP_W-VOP_FN_W-1:0]    vop_class_t;

  typedef enum logic [VOP_W-1:0] {
    VOP_ADD    = 6'o00, VOP_SUB    = 6'o01, VOP_NOP    = 6'o07,
    VOP_AND    = 6'o10, VOP_OR     = 6'o11, VOP_XOR    = 6'o12, VOP_PASS   = 6'o13,
    VOP_SHL    = 6'o20, VOP_SHR    = 6'o21, VOP_SAR    = 6'o22,
    VOP_SLT    = 6'o30, VOP_SLTU   = 6'o31,
    VOP_MUL    = 6'o40,
    VOP_ADDS   = 6'o50, VOP_SUBS   = 6'o51, VOP_ADDUS  = 6'o52, VOP_SUBUS  = 6'o53,
    VOP_REDSUM = 6'o60, VOP_REDAND = 6'o61, VOP_REDOR  = 6'o62, VOP_REDXOR = 6'o63
  } ve_op_e;

  localparam vop_class_t VOP_CLASS_FPX = 3'o7;

  typedef enum logic [BSRC_W-1:0] { BSRC_VEC = 2'd0, BSRC_SCALAR = 2'd1, BSRC_XLANE = 2'd2 } ve_bsrc_e;
  typedef enum logic { MPOL_PASS = 1'b0, MPOL_ZERO = 1'b1 } ve_mpol_e;
  typedef enum logic [1:0] { LOP_AND = 2'd0, LOP_OR = 2'd1, LOP_XOR = 2'd2, LOP_PASS = 2'd3 } ve_lop_e;
  typedef enum logic [1:0] { ROP_SUM = 2'd0, ROP_AND = 2'd1, ROP_OR = 2'd2, ROP_XOR = 2'd3 } ve_rop_e;

  typedef struct packed { logic mul; logic cmp; logic shf; logic lgc; logic add; } ve_unit_t;

  typedef struct packed {
    logic     legal;
    logic     fpx;
    logic     vwr;
    logic     swr;
    ve_unit_t unit;
    logic     sub;
    logic     sat;
    logic     sat_s;
    ve_lop_e  lop;
    logic     sh_r;
    logic     sh_a;
    logic     cmp_s;
    ve_rop_e  rop;
  } ve_ctrl_t;

  // R1: issue register
  typedef struct packed {
    logic       vld;
    logic       spec;
    tag_t       tag;
    ve_ctrl_t   ctrl;
    ve_mpol_e   mpol;
    lane_mask_t active;
    lane_vec_t  a;
    lane_vec_t  b;
    lane_vec_t  vd;
  } ve_iss_pkt_t;

  // R2: after EXA
  typedef struct packed {
    logic       vld;
    logic       spec;
    tag_t       tag;
    ve_ctrl_t   ctrl;
    ve_mpol_e   mpol;
    lane_mask_t active;
    lane_mask_t sat;
    lane_vec_t  vd;
    lane_vec_t  raw_nm;     // AND-OR of all units except the multiplier
    lane_vec_t  mul_s;      // multiplier carry-save rows
    lane_vec_t  mul_c;
    lane_t      red;
  } ve_exa_pkt_t;

  localparam lane_t LANE_ZERO = '0;
  localparam lane_t LANE_ONES = '1;
  localparam lane_t LANE_UMAX = '1;
  localparam lane_t LANE_UMIN = '0;
  localparam lane_t LANE_SMAX = {1'b0, {(LANE_W-1){1'b1}}};
  localparam lane_t LANE_SMIN = {1'b1, {(LANE_W-1){1'b0}}};

  // ===========================================================================
  // Decode (upstream lines 252-290, verbatim)
  // ===========================================================================
  function automatic ve_ctrl_t ve_decode(input logic [VOP_W-1:0] op_raw);
    ve_ctrl_t c;
    c     = '0;
    c.lop = LOP_PASS;
    c.rop = ROP_SUM;
    case (ve_op_e'(op_raw))
      VOP_ADD    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.add = 1'b1;                                         end
      VOP_SUB    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.add = 1'b1; c.sub = 1'b1;                           end
      VOP_NOP    : begin c.legal = 1'b1;                                                                          end
      VOP_AND    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.lgc = 1'b1; c.lop = LOP_AND;                        end
      VOP_OR     : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.lgc = 1'b1; c.lop = LOP_OR;                         end
      VOP_XOR    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.lgc = 1'b1; c.lop = LOP_XOR;                        end
      VOP_PASS   : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.lgc = 1'b1; c.lop = LOP_PASS;                       end
      VOP_SHL    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.shf = 1'b1;                                         end
      VOP_SHR    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.shf = 1'b1; c.sh_r = 1'b1;                          end
      VOP_SAR    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.shf = 1'b1; c.sh_r = 1'b1; c.sh_a = 1'b1;           end
      VOP_SLT    : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.cmp = 1'b1; c.sub = 1'b1; c.cmp_s = 1'b1;           end
      VOP_SLTU   : begin c.legal = 1'b1; c.vwr = 1'b1; c.unit.cmp = 1'b1; c.sub = 1'b1;                           end
      VOP_MUL    : begin c.legal = MUL_EN; c.vwr = MUL_EN; c.unit.mul = MUL_EN;                                   end
      VOP_ADDS   : begin c.legal = SAT_EN; c.vwr = SAT_EN; c.unit.add = SAT_EN; c.sat = SAT_EN; c.sat_s = 1'b1;   end
      VOP_SUBS   : begin c.legal = SAT_EN; c.vwr = SAT_EN; c.unit.add = SAT_EN; c.sat = SAT_EN; c.sat_s = 1'b1;
                         c.sub   = 1'b1;                                                                          end
      VOP_ADDUS  : begin c.legal = SAT_EN; c.vwr = SAT_EN; c.unit.add = SAT_EN; c.sat = SAT_EN;                   end
      VOP_SUBUS  : begin c.legal = SAT_EN; c.vwr = SAT_EN; c.unit.add = SAT_EN; c.sat = SAT_EN; c.sub = 1'b1;     end
      VOP_REDSUM : begin c.legal = RED_EN; c.swr = RED_EN; c.unit.lgc = RED_EN; c.rop = ROP_SUM;                  end
      VOP_REDAND : begin c.legal = RED_EN; c.swr = RED_EN; c.unit.lgc = RED_EN; c.rop = ROP_AND;                  end
      VOP_REDOR  : begin c.legal = RED_EN; c.swr = RED_EN; c.unit.lgc = RED_EN; c.rop = ROP_OR;                   end
      VOP_REDXOR : begin c.legal = RED_EN; c.swr = RED_EN; c.unit.lgc = RED_EN; c.rop = ROP_XOR;                  end
      default    : begin
                     c     = '0;
                     c.lop = LOP_PASS;
                     c.rop = ROP_SUM;
                     c.fpx = (vop_class_t'(op_raw[VOP_W-1:VOP_FN_W]) == VOP_CLASS_FPX);
                   end
    endcase
    return c;
  endfunction

  function automatic lane_t ve_red_ident(input ve_rop_e rop);
    return (rop == ROP_AND) ? LANE_ONES : LANE_ZERO;
  endfunction

  // ===========================================================================
  // ISS (upstream lines 314-355)
  // ===========================================================================
  ve_ctrl_t   iss_ctrl;
  ve_bsrc_e   iss_bsrc;
  logic       iss_bsrc_ok;
  logic       iss_claim;
  lane_vec_t  iss_b;
  lane_mask_t iss_active;

  always_comb begin : p_issue_decode
    iss_ctrl    = ve_decode(iss_op_i);
    iss_bsrc    = ve_bsrc_e'(iss_bsrc_i);
    iss_bsrc_ok = 1'b1;
    case (iss_bsrc)
      BSRC_VEC    : iss_b = iss_vb_i;
      BSRC_SCALAR : for (int unsigned l = 0; l < LANES; l++) begin
                      iss_b[l] = iss_scalar_i;
                    end
      BSRC_XLANE  : iss_b = xlane_b_i;
      default     : begin
                      iss_b       = '0;
                      iss_bsrc_ok = 1'b0;
                    end
    endcase
    if (!iss_bsrc_ok) begin
      iss_ctrl.legal = 1'b0;
      iss_ctrl.vwr   = 1'b0;
      iss_ctrl.swr   = 1'b0;
      iss_ctrl.unit  = '0;
    end
    iss_claim = iss_valid_i & ~iss_ctrl.fpx;
    for (int unsigned l = 0; l < LANES; l++) begin
      iss_active[l] = (ve_uint_t'(iss_vl_i) > l) & (iss_mask_i[l] | ~iss_mask_en_i);
    end
  end

  assign iss_ready_o = ~stall_i;
  assign iss_fpx_o   = iss_valid_i & iss_ctrl.fpx;

  ve_iss_pkt_t iss_pkt;
  always_comb begin : p_iss_pkt
    iss_pkt        = '0;
    iss_pkt.vld    = iss_claim & ~(flush_i & iss_spec_i);
    iss_pkt.spec   = iss_spec_i;
    iss_pkt.tag    = iss_tag_i;
    iss_pkt.ctrl   = iss_ctrl;
    iss_pkt.mpol   = ve_mpol_e'(iss_mpol_i);
    iss_pkt.active = iss_active;
    iss_pkt.a      = iss_va_i;
    iss_pkt.b      = iss_b;
    iss_pkt.vd     = iss_vd_i;
  end

  // ===========================================================================
  // R1 - stage register (upstream EX_STAGES=2 boundary semantics)
  // ===========================================================================
  ve_iss_pkt_t r1_q, r1;
  always_ff @(posedge clk_i or negedge rst_ni) begin : p_r1
    if (!rst_ni) begin
      r1_q <= '0;
    end else if (stall_i) begin
      r1_q.vld <= r1_q.vld & ~(flush_i & r1_q.spec);
    end else begin
      r1_q <= iss_pkt;
    end
  end
  always_comb begin
    r1     = r1_q;
    r1.vld = r1_q.vld & ~(flush_i & r1_q.spec);
  end

  // ===========================================================================
  // EXA - lane compute (upstream lines 365-442) without the final AND-OR of
  // the multiplier term; multiplier reduced to carry-save rows.
  // ===========================================================================
  lane_vec_t  exa_raw_nm, exa_mul_s, exa_mul_c;
  lane_mask_t exa_sat;

  for (genvar l = 0; l < LANES; l++) begin : g_lane_exa
    lane_t           a, b, b_op, add_res, arith_res, lgc_res, shf_res, cmp_res, srl_res, sign_fill;
    logic [LANE_W:0] add_full;
    shamt_t          shamt;
    logic            ovf_s, ovf_u, lt_s, lt_u, sat_evt;

    always_comb begin : p_lane_compute
      a         = r1.a[l];
      b         = r1.b[l];
      b_op      = r1.ctrl.sub ? ~b : b;
      add_full  = {1'b0, a} + {1'b0, b_op} + {{LANE_W{1'b0}}, r1.ctrl.sub};
      add_res   = add_full[LANE_MSB:0];
      ovf_s     = ~(a[LANE_MSB] ^ b_op[LANE_MSB]) & (add_res[LANE_MSB] ^ a[LANE_MSB]);
      ovf_u     = add_full[LANE_W] ^ r1.ctrl.sub;
      sat_evt   = r1.ctrl.sat & (r1.ctrl.sat_s ? ovf_s : ovf_u);
      if (!sat_evt) begin
        arith_res = add_res;
      end else if (r1.ctrl.sat_s) begin
        arith_res = a[LANE_MSB] ? LANE_SMIN : LANE_SMAX;
      end else begin
        arith_res = r1.ctrl.sub ? LANE_UMIN : LANE_UMAX;
      end
      lt_s      = add_res[LANE_MSB] ^ ovf_s;
      lt_u      = ~add_full[LANE_W];
      cmp_res   = {{(LANE_W-1){1'b0}}, (r1.ctrl.cmp_s ? lt_s : lt_u)};
      case (r1.ctrl.lop)
        LOP_AND  : lgc_res = a & b;
        LOP_OR   : lgc_res = a | b;
        LOP_XOR  : lgc_res = a ^ b;
        LOP_PASS : lgc_res = a;
        default  : lgc_res = LANE_ZERO;
      endcase
      shamt     = b[SHAMT_W-1:0];
      srl_res   = a >> shamt;
      sign_fill = ~(LANE_ONES >> shamt) & {LANE_W{a[LANE_MSB] & r1.ctrl.sh_a}};
      shf_res   = r1.ctrl.sh_r ? (srl_res | sign_fill) : (a << shamt);
    end

    assign exa_raw_nm[l] = ({LANE_W{r1.ctrl.unit.add}} & arith_res)
                         | ({LANE_W{r1.ctrl.unit.lgc}} & lgc_res)
                         | ({LANE_W{r1.ctrl.unit.shf}} & shf_res)
                         | ({LANE_W{r1.ctrl.unit.cmp}} & cmp_res);
    assign exa_sat[l]    = sat_evt & r1.ctrl.unit.add;

    if (MUL_EN) begin : g_mul
      sf_mul_lo_csa #(.W(LANE_W)) u_mul (.a_i(a), .b_i(b), .sum_o(exa_mul_s[l]), .carry_o(exa_mul_c[l]));
    end else begin : g_no_mul
      assign exa_mul_s[l] = LANE_ZERO;
      assign exa_mul_c[l] = LANE_ZERO;
    end
  end

  // cross-lane reduction: leaf = operand a of active lanes (== raw for every
  // legal reduction op, see header), identity element otherwise
  lane_t exa_red;
  if (RED_EN) begin : g_red
    lane_vec_t leaf;
    lane_t     ident;
    assign ident = ve_red_ident(r1.ctrl.rop);
    for (genvar l = 0; l < LANES; l++) begin : g_leaf
      assign leaf[l] = r1.active[l] ? r1.a[l] : ident;
    end
    sf_reduce_tree #(.W(LANE_W), .N(LANES)) u_red (.rop_i(r1.ctrl.rop), .leaf_i(leaf), .red_o(exa_red));
  end else begin : g_no_red
    assign exa_red = LANE_ZERO;
  end

  ve_exa_pkt_t exa_pkt;
  always_comb begin : p_exa_pkt
    exa_pkt        = '0;
    exa_pkt.vld    = r1.vld;
    exa_pkt.spec   = r1.spec;
    exa_pkt.tag    = r1.tag;
    exa_pkt.ctrl   = r1.ctrl;
    exa_pkt.mpol   = r1.mpol;
    exa_pkt.active = r1.active;
    exa_pkt.sat    = exa_sat;
    exa_pkt.vd     = r1.vd;
    exa_pkt.raw_nm = exa_raw_nm;
    exa_pkt.mul_s  = exa_mul_s;
    exa_pkt.mul_c  = exa_mul_c;
    exa_pkt.red    = exa_red;
  end

  // ===========================================================================
  // R2 - stage register
  // ===========================================================================
  ve_exa_pkt_t r2_q, r2;
  always_ff @(posedge clk_i or negedge rst_ni) begin : p_r2
    if (!rst_ni) begin
      r2_q <= '0;
    end else if (stall_i) begin
      r2_q.vld <= r2_q.vld & ~(flush_i & r2_q.spec);
    end else begin
      r2_q <= exa_pkt;
    end
  end
  always_comb begin
    r2     = r2_q;
    r2.vld = r2_q.vld & ~(flush_i & r2_q.spec);
  end

  // ===========================================================================
  // EXB - multiplier CPA, result select, mask merge (upstream lines 432-525)
  // ===========================================================================
  lane_vec_t  exb_res;
  lane_mask_t exb_lane_we;
  logic       exb_sat;

  for (genvar l = 0; l < LANES; l++) begin : g_lane_exb
    lane_t mul_res, raw, merged;
    logic  we;
    assign mul_res = r2.mul_s[l] + r2.mul_c[l];
    assign raw     = r2.raw_nm[l] | ({LANE_W{r2.ctrl.unit.mul}} & mul_res);
    always_comb begin : p_lane_merge
      we = r2.active[l] & r2.ctrl.vwr;
      if (we) begin
        merged = raw;
      end else if (r2.mpol == MPOL_ZERO) begin
        merged = LANE_ZERO;
      end else begin
        merged = r2.vd[l];
      end
    end
    assign exb_lane_we[l] = we;
    assign exb_res[l]     = merged;
  end

  assign exb_sat = |(r2.sat & exb_lane_we);

  // ===========================================================================
  // Output register (upstream lines 568-620)
  // ===========================================================================
  logic       res_valid_q, res_spec_q, res_illegal_q, res_sat_q, res_scalar_wr_q;
  tag_t       res_tag_q;
  lane_vec_t  res_data_q;
  lane_mask_t res_lane_we_q;
  lane_t      res_scalar_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_out_valid
    if (!rst_ni) begin
      res_valid_q <= 1'b0;
    end else if (stall_i) begin
      res_valid_q <= res_valid_q & ~(flush_i & res_spec_q);
    end else begin
      res_valid_q <= r2.vld;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_out_payload
    if (!rst_ni) begin
      res_spec_q      <= 1'b0;
      res_tag_q       <= '0;
      res_illegal_q   <= 1'b0;
      res_data_q      <= '0;
      res_lane_we_q   <= '0;
      res_sat_q       <= 1'b0;
      res_scalar_wr_q <= 1'b0;
      res_scalar_q    <= '0;
    end else if (!stall_i && r2.vld) begin
      res_spec_q      <= r2.spec;
      res_tag_q       <= r2.tag;
      res_illegal_q   <= ~r2.ctrl.legal;
      res_data_q      <= exb_res;
      res_lane_we_q   <= exb_lane_we;
      res_sat_q       <= exb_sat;
      res_scalar_wr_q <= r2.ctrl.swr;
      res_scalar_q    <= r2.red;
    end
  end

  assign res_valid_o     = res_valid_q;
  assign res_spec_o      = res_spec_q;
  assign res_tag_o       = res_tag_q;
  assign res_illegal_o   = res_valid_q & res_illegal_q;
  assign res_data_o      = res_data_q;
  assign res_lane_we_o   = res_valid_q ? res_lane_we_q : '0;
  assign res_sat_o       = res_valid_q & res_sat_q;
  assign res_scalar_wr_o = res_valid_q & res_scalar_wr_q;
  assign res_scalar_o    = res_scalar_q;

  assign busy_o          = r1_q.vld | r2_q.vld | res_valid_q;

  // synthesis translate_off
  initial begin : p_param_check
    if (!(LANES == 4 || LANES == 8 || LANES == 16))
      $fatal(1, "sf_vector_engine_pipe: LANES must be 4, 8 or 16");
    if (LANE_W < 8 || (LANE_W & (LANE_W - 1)) != 0)
      $fatal(1, "sf_vector_engine_pipe: LANE_W must be a power of two >= 8");
  end
  // synthesis translate_on

endmodule : sf_vector_engine_pipe
