// =============================================================================
//  SilicaFlux TimingLab - harness package for noc_interconnect.sf
//
//  noc_interconnect.sf declares `parameter type pkt_t = noc_packet_t` and
//  imports silicaflux_pkg, but NO silicaflux_pkg variant in the repository
//  defines noc_packet_t (reports/discovery/discovery.json, compile_matrix:
//  "use of undeclared identifier 'noc_packet_t'").
//
//  This shim provides ONLY that type, built from the contract documented in
//  noc_interconnect.sf lines 45-51:
//      dst_id : destination tile ID {y, x}
//      src_id : source tile ID {y, x}
//      valid  : packet valid qualifier
//      qos    : priority class, MSB selects the high-priority class
//      all other fields are carried transparently and never inspected.
//
//  Harness choices (not architectural, stated here and in docs/DISCOVERY.md):
//      * tile-ID width 2 = {y[0], x[0]} for the default 2x2 mesh
//      * qos width 2
//      * transparent fields: 8-bit txn_id + 128-bit payload (one SilicaFlux
//        vector line, SF_VLEN = 128 in silicaflux_pkg (1).sf)
//  The router never inspects the payload, so its width only scales the
//  buffer / crossbar data width.
// =============================================================================
package silicaflux_pkg;

  localparam int unsigned TL_NOC_ID_W      = 2;
  localparam int unsigned TL_NOC_QOS_W     = 2;
  localparam int unsigned TL_NOC_TXN_W     = 8;
  localparam int unsigned TL_NOC_PAYLOAD_W = 128;

  typedef struct packed {
    logic [TL_NOC_ID_W-1:0]      dst_id;
    logic [TL_NOC_ID_W-1:0]      src_id;
    logic                        valid;
    logic [TL_NOC_QOS_W-1:0]     qos;
    logic [TL_NOC_TXN_W-1:0]     txn_id;
    logic [TL_NOC_PAYLOAD_W-1:0] payload;
  } noc_packet_t;

endpackage : silicaflux_pkg
