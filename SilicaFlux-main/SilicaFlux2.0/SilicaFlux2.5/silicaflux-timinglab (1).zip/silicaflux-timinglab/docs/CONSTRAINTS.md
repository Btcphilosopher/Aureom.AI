# Timing constraints

| file | applies to | checked by |
|---|---|---|
| `constraints/block.sdc` | every block run (`flow/designs.toml`) | OpenSTA / OpenROAD on every run |
| `constraints/silicaflux_top.sdc` | the 2.5 cluster (`silicaflux_top.sf`) | `python -m timinglab sdc`: OpenSTA reads it against a port / instance stub generated from the source |

Both pass `timinglab/sdc.py: lint`: every exception must be preceded by a `JUSTIFY:` comment
citing its evidence (`tests/test_config_constraints.py`).

## Block constraints (`block.sdc`)

Parameterised by environment variables set from the design and PDK configuration (values
are echoed into each run's `sta_env.json`):

| item | value |
|---|---|
| clock | `create_clock -name core_clk` on `clk_i`; T = 10 ns (sky130hd), 8 ns (ihp-sg13g2), 20 ns (gf180mcu) |
| uncertainty | setup 0.25 ns (sky130hd), 0.20 ns (ihp-sg13g2), 0.50 ns (gf180mcu) (jitter + pre-CTS skew allowance); hold 0.05 ns |
| clock transition (pre-CTS) | 0.15 ns; after CTS the clocks are propagated |
| I/O budget | 30 % of T outside the block on every input and output (`set_input_delay`/`set_output_delay -max`), 0 for `-min` |
| electrical | driving cell = PDK buffer (`sdc_driver_cell`), load 10-20 fF |
| path groups | reg2reg, in2reg, reg2out, in2out |
| exceptions | **none** |

Exception review for the blocks:

* **Reset is not a false path.** In the 2.5 cluster every block reset is either a flop in
  the `clk_core_i` domain (`silicaflux_top.sf` 853-861) or the output of the `sf_rst_sync`
  synchroniser (577-586), so de-assertion is synchronous and recovery/removal must be met.
  `rst_ni` therefore keeps a normal input budget (its recovery checks appear in `in2reg`).
* **No multicycle path.** A multicycle path needs functional evidence that the capturing
  register is enabled at most every N > 1 cycles. The block sources were searched for such
  contracts (quasi-static / stable / hold / every-other-cycle wording, enable assertions) and
  none was found: every pipeline register in the elaborable blocks may load on consecutive
  cycles (tensor_unit advances every cycle when the release buffer is free; the memory
  controller issues one access per bank per cycle). Adding one would only hide violations.
* **No false path between functional signals.** Each block has one clock.

## Cluster constraints (`silicaflux_top.sdc`)

| item | source evidence |
|---|---|
| 5 primary clocks: `clk_core_i`, `clk_mem_i`, `clk_host_i`, `clk_rtc_i` (32.768 kHz), `jtag_tck_i` | domain list lines 18-23, ports 76-79, 106 |
| 4 generated clocks (`divide_by 1`) on `u_clk_ctrl/{core,vpu,llc,tns}_clk_o*` | sf_clk_ctrl instance 618-635 |
| `set_clock_groups -asynchronous` between core(+gated), mem, host, rtc, tck | header 25-26: all crossings use sf_sync / sf_rst_sync / sf_axi_cdc / sf_apb_cdc. **Caveat:** those primitives are missing from the repository, so the contract cannot be verified structurally yet |
| `set_case_analysis 0` on `test_mode_i`, `scan_en_i` | DFT ports 83-85; functional-mode constraint set |
| false path from `por_rst_ni`, `sys_rst_ni`, `jtag_trst_ni` | u_rst_ctrl synchronises per domain (542-560) |
| false path from `ext_irq_i`, `cluster_en_i`, `dbg_ext_halt_i` | SYNC_STAGES synchronisers u_ext_irq_sync / u_ctrl_in_sync (638-656) |
| false path from straps `cluster_id_i`, `boot_core_mask_i`, `boot_addr_i`, `boot_addr_ovr_i` | "Straps are quasi-static and captured in reset" (26, 86) |
| I/O delays: memory AXI master + DMA AXI slave on `clk_mem`; host APB on `clk_host`; trace / status on `clk_core`; JTAG TDI/TMS on rising TCK, TDO on falling TCK | port groups 92-124 |
| multicycle paths | none (no evidence) |

`python -m timinglab sdc` builds a stub of `silicaflux_top` (all ports, plus the
`u_clk_ctrl` instance with its connected port names), reads the SDC in OpenSTA and fails on
any unresolved object. Result: `reports/constraints/constraints.json` (5 primary + 4
generated clocks, 0 unresolved objects). A negative test (`tests/test_slow_tools.py`) shows
the check fails for a port that does not exist.

## Setup and hold

Setup is checked at every stage; hold is reported at every stage (`paths_min.rpt`,
`summary.tsv`) and not repaired in the experimental PnR flow. Negative post-CTS hold
slack is therefore expected and reported, not hidden.
