# RTL timing-risk audit

`python -m timinglab audit --all` writes `reports/audit/<design>/rtl_audit.json`. Every
item is a **hypothesis** (`"status": "hypothesis"`) until `python -m timinglab confirm`
matches it against OpenSTA results.

## Evidence layers

| layer | tool | what it finds |
|---|---|---|
| source | pyslang syntax tree (`audit/source.py`) | loop-accumulated reductions (`x += ...` in a `for` inside comb logic → linear adder chain), `case` statements with ≥ 16 items, `?:` chains of depth ≥ 4, every `*`, `always_latch` |
| coarse netlist | Yosys after `alumacc` / `opt` (`coarse.json`) | multipliers / MACs with operand widths, adders ≥ 32 b, `$pmux` / `$bmux` widths, barrel shifters, memories, arithmetic operators in series between registers |
| gate netlist | Yosys `techmap` without ABC (`gates.json`) | unit-delay logic depth to every endpoint with the source trail of the worst path, high-fanout nets and their sink spread, combinational loops, latches, clock nets and async-reset nets per block, FF→FF clock-domain crossings, combinational input→output (handshake) paths |

The gate netlist is deliberately mapped **without ABC**: generic gates keep the `src`
attribute of the RTL operator they came from, so every predicted path is traced to source
lines (`src_trail`).

## Categories and scoring

`critical_path` (per RTL register, relative to the block's worst estimate), `multiplier`,
`arith_chain`, `wide_arith`, `wide_mux`, `barrel_shift`, `high_fanout`, `routing_sensitive`
(fanout spread over many generate scopes), `comb_io_path`, `loop_reduction`, `wide_case`,
`ternary_chain`, `comb_loop`, `latch`, `cdc`, `rdc`. Scores (0-100) only rank candidates
inside one block.

Delay model (`audit/netlist.py: GATE_DELAY`): NAND/NOR 1.0, AND/OR 1.2, XOR/MUX 1.8,
NOT/BUF 0.6, + 0.25·log2(fanout); clock-to-Q 1. It is calibrated against STA afterwards,
not before.

## Confirmation

`timinglab/confirm.py` joins audit and STA by **RTL register identity**: both netlists
name a register after the RTL signal driven by its Q pin, using the same deterministic rule
(`netlist.bit_label`: prefer internal register names over port names, public names, shorter,
lexicographic). Because one flop can carry several RTL names (`assign r2 = r2_q;`), and the
audit netlist and the mapped netlist may keep different ones, the audit also records every
public name of each register's Q net (`aliases`); an audit register matches every STA
register that has its name or one of its aliases. (Without this, the top audit candidate of
`sf_vector_engine_pipe` and of `vector_engine` EX_STAGES 2 was wrongly reported as
`not_observed`.) STA path ends are identified the same way, through the Q nets of the mapped
netlist, never through instance names: Yosys `autoname` derives instance names from
neighbouring nets, so a flop named `..mul_pp_q_63__..` can be a bit of `out_q`. Outputs per
(design, PDK) in `reports/confirm/*.json`:

* candidate status: `confirmed` (STA says the register's worst path limits timing:
  negative slack or within 10 % of the period), `top_ranked_meets_timing` (among the ten
  worst STA registers but comfortably meeting timing - a refuted risk), `not_critical`,
  `not_observed` (register optimised away or not reported); operator-level and fanout
  candidates inherit the status of the STA registers whose audit path runs through their
  source line / is launched by their net;
* agreement: top-10 overlap and Spearman ρ between the audit estimate and the STA path delay
  of the same registers (reported as undefined, with the reason, when fewer than three
  registers match or when the audit gives every matched register the same estimate - the
  tensor unit's regular 20-stage pipeline);
* calibration: least-squares ns per gate unit and R².

The dashboard section "RTL audit hypotheses and their confirmation" shows these numbers;
they are what "treat RTL predictions as hypotheses until confirmed" means in practice. In
this run, for example, the tensor unit's high-fanout pipeline-advance enable (tensor_unit.sf
"global pipeline advance is a flop output of the release buffer") was flagged by the audit
and **refuted** by STA: after `repair_design` buffering the tensor unit meets timing with
margin on every PDK (see RESULTS.md).
