# Findings about the upstream SilicaFlux 2.x sources

Issues found while building TimingLab. Each has a reproduction (report or command).
None of them is fixed in `upstream/` (TimingLab never edits upstream files).

## Integration / build

| # | finding | evidence |
|---|---|---|
| F1 | **The 2.5 cluster cannot be built.** `SilicaFlux2.5/silicaflux_top.sf` instantiates 27 modules defined nowhere in the repository (`sf_core`, `sf_clk_ctrl`, `sf_rst_ctrl`, `sf_axi_cdc`, `sf_coh_xbar`, ...). | `discovery.json: missing_modules`; DISCOVERY.md §3 |
| F2 | **Five incompatible `silicaflux_pkg` packages.** `memory_controller.sf` elaborates only with `silicaflux_pkg (1).sf` (136 lines); `scheduler.sf`, `compute_tile.sf`, `tile_interface.sf` need `sf_*` types that **no** version defines (`sf_fu_e`, `sf_ptag_t`, `sf_mem_req_t`, `sf_tile_pkt_t`, `sf_noc_flit_t`, ...). | `compile_matrix` (53 / 66 / 65 errors) |
| F3 | `noc_interconnect.sf` defaults `pkt_t` to `silicaflux_pkg::noc_packet_t`, which no package defines. | `compile_matrix` (1-2 errors); TimingLab shim `rtl/harness/tl_noc_pkt_pkg.sv` |
| F4 | `SilicaFlux2.5/alu (1).sf` uses `silicaflux_pkg::rob_tag_t`, defined nowhere. | `compile_matrix` (2 errors) |
| F5 | Both loose `forwarding_unit.sf` copies and `vector_engine (1).sf` do not elaborate with any package (29 / 44 / 37 errors); only the `forwarding_unit.zip` copy does. | `compile_matrix` |
| F6 | Same module name, different implementation: `register_bank`, `vector_engine`, `sf_alu`, `fetch_unit`, `forwarding_unit`, `silicaflux_top`. A file list cannot contain both. | `discovery.json: collisions` |

## Verification

| # | finding | evidence |
|---|---|---|
| F7 | **No `.sf` testbench matches its DUT** (0 / 9 instantiations). E.g. `tb_vector_engine.sf` drives `clk, rst_n, in_valid, in_op, ...`; `vector_engine.sf` has `clk_i, rst_ni, iss_*`. The upstream regression cannot run against the current RTL. | `discovery.json: testbench_checks`; slang: "port 'clk' does not exist in 'vector_engine'" |
| F8 | `run_sim.sh` / `sfx_asm.py` target the v1.0 `.sv` layout (`rtl/*.sv`, `tb/*.sv`). | `SilicaFlux2.5/run_sim.sh` |

## Timing (confirmed by STA; numbers in RESULTS.md)

| # | finding | evidence |
|---|---|---|
| F9 | `vector_engine` default `EX_STAGES = 1` puts decode, a 32×32 multiplier, the result select and a two-level adder reduction in one cycle (61 / 79 / 72 mapped levels on SKY130 / IHP / GF180). Reg2reg WNS after global route: −8.41 ns at 10 ns (SKY130), −6.74 ns at 8 ns (IHP), −9.95 ns at 20 ns (GF180) - the worst block on SKY130 and GF180, second to `sf_decoder` on IHP. | `reports/dashboard/critical_paths.csv`; RESULTS.md §2 |
| F10 | The vector reduction tree reads the selected lane result (`raw`), creating a **functionally false** multiplier → reduction path (reductions never select the multiplier, `ve_decode` 255 / 277-280, line 418). Reading operand `a` removes it without architectural change. | OPTIMISATIONS.md §1 |
| F11 | `sf_alu`'s `MUL_STAGES > 2` only adds delay registers after the first-stage partial products (`alu.sf` 449-460, comment "retiming registers"); without a retiming synthesis step they do not shorten the critical first stage (operand register → `mul_pp_q`: 50 / 72 / 57 levels, −3.62 / −3.68 / −7.46 ns on SKY130 / IHP / GF180). | `sf_alu` critical path; OPTIMISATIONS.md §3 |
| F12 | `sf_decoder`: the per-lane redirect computation into `redir_q` violates timing on every PDK: −7.78 ns at 10 ns (SKY130, 46 levels), −7.20 ns at 8 ns (IHP, the worst block there), −7.16 ns at 20 ns (GF180). | `sf_decoder` critical paths |
| F13 | `memory_controller` instantiates its storage inline (`g_bank[].mem_q`, line 979-1017) rather than through an SRAM wrapper; at the default 8×512×128 b it synthesises to 512 Kib of flip-flops. An ASIC implementation needs a macro hook there. | `memory_controller.sf` 976-1031; TimingLab uses BANK_DEPTH = 8 |

## Not a problem (hypotheses refuted)

| # | hypothesis | outcome |
|---|---|---|
| R1 | tensor_unit's single release-buffer flop driving the advance enable of every stage register is a fanout bottleneck (audit `high_fanout`) | refuted: after `repair_design` and CTS the tensor unit meets timing with margin on every PDK (WNS +4.19 ns at 10 ns, +3.74 ns at 8 ns, +10.16 ns at 20 ns). An earlier IHP result of −21 ns was a flow artefact (no clock tree, TIMING_FLOW.md "clock-root fix"), not a design property. |
| R2 | NoC switch allocation / crossbar (S2) limits the router | refuted at the measured periods: positive slack |
