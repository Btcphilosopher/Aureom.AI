# Optimisations

Only blocks whose criticality was **confirmed by STA** were changed. Measured numbers are
in [RESULTS.md](RESULTS.md) (generated from `reports/`); this page explains what changed
and why.

## Selection (SKY130, 10 ns, after global route, upstream RTL)

| block | reg2reg WNS | decision |
|---|---|---|
| `vector_engine` | most negative of all blocks | **optimised** (`sf_vector_engine_pipe`); upstream `EX_STAGES=2` knob measured as a second alternative |
| `sf_decoder` | negative | not optimised in this release - see "Investigated, not changed" |
| `sf_alu` | negative | **optimised** (`sf_alu_mulcsa`, cycle-exact) |
| `memory_controller`, `fetch_unit`, `forwarding_unit`, `register_bank` ×2, `noc_interconnect`, `tensor_unit` | positive | not changed (no confirmed problem) |

## 1. `sf_vector_engine_pipe` - register placement around vector execution, carry-save MAC datapath, balanced reduction

Upstream (`SilicaFlux2.5/vector_engine.sf`, default `EX_STAGES=1`): decode, operand-B
select, the 32-bit lane datapath (adder/saturator, shifter, comparator, **32×32
multiplier**), the one-hot AND-OR result select, the mask merge and a heap-ordered
reduction tree of 32-bit adders all sit between the issue inputs and the result register.
STA path: `iss_op_i` → decode → multiplier → AND-OR → reduction adders → `res_scalar_q`,
~60 mapped logic levels.

Two observations drove the design:

1. The multiplier → reduction-tree path is **functionally false**. Reductions select
   `unit.lgc` with `lop = LOP_PASS` (`ve_decode`, lines 255, 277-280), so for every legal
   REDxxx op the lane result `raw` equals operand `a` (line 418); the multiplier is never
   selected when a reduction executes. The reduction can therefore read operand `a`
   directly. `res_scalar_o` is qualified by `res_scalar_wr_o` (only set for reductions), so
   this is invisible to the architecture - the equivalence contract below states it.
2. The default Yosys mapping of `a * b` is an array multiplier whose depth grows linearly
   with the width.

Structure (`rtl/opt/sf_vector_engine_pipe.sv`, latency 3, throughput 1/cycle):

| stage | logic |
|---|---|
| ISS (comb) | upstream decode / operand select / lane activity, unchanged |
| **R1** | issue register: the decoded control word is broadcast to all lanes from flops |
| EXA | upstream adder / saturator / comparator / logic / shifter; multiplier partial products reduced to two rows by a 3:2 compressor tree (`sf_mul_lo_csa`); reduction by `sf_reduce_tree` (one carry-save tree + one CPA instead of log2(LANES) CPAs) |
| **R2** | stage register |
| EXB | multiplier CPA, one-hot AND-OR select, mask/tail merge, saturation summary (upstream logic) |
| OUT | upstream result register, unchanged |

Both stage registers follow the upstream EX_STAGES=2 boundary exactly (stall holds and kills
a held speculative packet on flush; read-out masks `flush & spec`).

Handshake impact: the engine has no valid/ready back-pressure beyond `stall_i`
(`iss_ready_o = ~stall_i`); `stall_i` freezes all stages, as upstream. Latency rises from
1 to 3, so (a) `busy_o` now covers R1/R2, and (b) the issuing control core must account for
the deeper speculation window (`flush_i` kills every in-flight speculative packet, as
upstream does for its EX_STAGES=2 option). Both are checked by `tb/equiv/tb_eq_vector.sv`.

## 2. Upstream knob `vector_engine` with `EX_STAGES = 2`

No RTL change: the upstream EX1/EX2 boundary register (lines 469-491). Measured as a second
alternative so the TimingLab RTL is compared with what the upstream already offers.

## 3. `sf_alu_mulcsa` - pipelined MAC stage without latency change

Upstream (`alu.sf`, XLEN = 64, MUL_STAGES = 2): stage 1 forms `lo = a × b[31:0]` (a 64×32
array multiplier) and `hi = a[31:0] × b[63:32]`, stage 2 adds `lo + {hi, 0}`. STA: the
stage-1 path multiplier operand register → partial products → `mul_pp_q` is the worst path
on IHP and GF180 (−3.68 / −7.46 ns, 72 / 57 levels) and the second worst on SKY130
(−3.62 ns, 50 levels). Raising MUL_STAGES does not help: the extra stages are plain delay
registers after the partial products (lines 449-460).

Change (`rtl/opt/sf_alu_mulcsa.sv`, derived from `alu.sf`, a 3-hunk diff in the header
comment): stage 1 computes the low 64 bits of `a × b` in carry-save form (`sf_mul_lo_csa`,
two 64-bit rows), stage 2 adds them. Both forms equal `a × b mod 2^64` for every operand
pair, registers load under the same enables and reset to zero, so `mul_tail_data` and
**every ALU output are identical in every cycle**. No handshake or latency changes. Cost:
the stage register grows from 96 to 128 bits.

Effect, per path (after global route, RTL register names from the netlist's Q nets):

| path | SKY130 (10 ns) | IHP (8 ns) | GF180 (20 ns) |
|---|---|---|---|
| multiplier stage 1 → `mul_pp_q` | −3.62 → **+2.85** | −3.68 → **+2.28** | −7.46 → **+7.27** |
| request `req_op_i` → result `out_q` (single-cycle ALU path, RTL unchanged) | −4.13 → −2.18 | −2.58 → −2.38 | −4.74 → −5.32 |
| block reg2reg WNS | −4.13 → −2.28 | −3.68 → −2.38 | −7.46 → −5.32 |

The multiplier stage is fixed on every PDK. What remains is mostly logic the change does not
touch. On SKY130 the baseline's worst path is already the single-cycle path into `out_q`;
it measures 1.95 ns better in the `sf_alu_mulcsa` run although its RTL is identical, so part
of the SKY130 block-level gain is synthesis / placement variation, not the optimisation. On
GF180 the same path is 0.57 ns worse in the alternative's run. The block-level numbers in
RESULTS.md are therefore read together with this table.

## What limits the alternatives now (after global route)

* `sf_vector_engine_pipe`: the worst path moved from the multiplier into stage EXA
  (`r1_q` → `r2_q`: the 33-bit lane adder + saturation, upstream logic, `vector_engine.sf`
  lines 392-406; 35 / 41 / 36 levels on SKY130 / IHP / GF180, slack −1.41 / +0.56 /
  +4.15 ns). ABC maps that adder as a chain of `maj3` cells because its own (wire-less)
  estimate meets the 0.7·T target; an explicit parallel-prefix adder, or a tighter ABC
  target, is the next lever. The multiplier and the reduction are no longer on the
  critical path.
* `sf_alu_mulcsa`: the worst endpoint on every PDK is the result register `out_q`. On
  SKY130 it is reached from the carry-save stage register (`mul_pp_q` → stage-2 CPA →
  result select → `out_q`, −2.28 ns, 40 levels), with the single-cycle request path close
  behind (−2.18 ns); on IHP and GF180 it is reached from `req_op_i` through the single-cycle
  ALU path (−2.38 / −5.32 ns). The stage-1 compressor tree has positive slack everywhere.
  The next levers are a parallel-prefix CPA in stage 2, and the upstream single-cycle
  result path, which is outside the multiplier and was not changed in this release.

## Building blocks (parameterised, reusable)

| module | function |
|---|---|
| `rtl/opt/sf_csa_tree.sv` | Wallace-style 3:2 reduction of N W-bit rows to two rows, `ceil(log_{3/2}(N/2))` levels |
| `rtl/opt/sf_mul_lo_csa.sv` | low W bits of a×b in carry-save form (W AND-gated partial products + `sf_csa_tree`) |
| `rtl/opt/sf_reduce_tree.sv` | hierarchical cross-lane reduction: SUM via carry-save tree + one CPA, AND/OR/XOR via balanced trees |

## Investigated, not changed

* **Tensor pipeline / fanout mitigation.** The audit flagged the tensor unit's global
  pipeline advance (a single release-buffer flop that enables every stage register of the
  16 lanes) as a high-fanout risk. STA after `repair_design` refutes it: the tensor unit has
  positive reg2reg slack on every PDK (RESULTS.md), the 20-stage pipeline already limits
  every stage to ≤ 11 generic gate levels, and the buffered enable tree is not on the worst
  path. Replicating the enable flop would add area for no measured benefit.
* **Registered NoC arbitration.** The router's switch allocation and crossbar already sit
  between registered links (S1/S2, lines 18-31); the NoC meets 10 ns on SKY130 with margin.
* **Memory controller arbitration.** Meets timing in the reduced-depth configuration;
  the storage array is modelled as flip-flops, so SRAM-macro timing is out of scope.
* **`sf_decoder`.** Confirmed critical (STA worst path `ctx_i` → `redir_q`, ~47 levels:
  the per-lane redirect computation `lane_redir`, qualified by the lane-liveness chain
  across the four decode lanes and merged by the AND-OR redirect select, decoder.sf
  2646-2699, captured in `redir_q` at 2743). Shortening it means re-timing the decode
  redirect, which changes the front-end redirect contract (`fetch_unit.sf` line 16: redirect
  priority TRAP > REPLAY > BRU > DEC > ...). It is the next candidate, deliberately not
  shipped without a front-end-level equivalence bench.
