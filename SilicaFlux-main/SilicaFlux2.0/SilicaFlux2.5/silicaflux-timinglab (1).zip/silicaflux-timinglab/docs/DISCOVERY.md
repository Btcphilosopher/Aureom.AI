# Repository discovery

Produced by `python -m timinglab discover --repo <Aureom.AI checkout>` over the whole
repository at commit `36e0280` (working tree **and** every `.zip` / `.tar.gz` archive).
Machine-readable output: `reports/discovery/discovery.json`, `reports/discovery/inventory.csv`,
graphs `reports/discovery/sf2_dependency_graph.{dot,svg}` (SilicaFlux 2.x) and
`sf1_dependency_graph.{dot,svg}` (SilicaFlux 1.0). Every statement below is backed by a file
path and line in those reports; nothing is inferred from file names.

## 1. Inventory

| | count |
|---|---|
| HDL files (`.sf .sv .svh .v .vh`) | **617** (32 in the working tree, 585 inside 315 scanned archives) |
| distinct contents (SHA-256) | 454 |
| `.sf` files | 48 (45 parse as SystemVerilog-2017 with zero slang syntax errors) |
| SilicaFlux 2.x `.sf` RTL modules (non-testbench, de-duplicated) | 23 |
| ... of which **elaborate** with a package found in the repository | **12** |
| testbench → DUT instantiations in the `.sf` tree | 9, **0 interface-compatible** |
| module names instantiated in the `.sf` tree but defined nowhere in it | **33** |
| names defined more than once in the `.sf` tree | 16 (e.g. `silicaflux_pkg`: 7 definitions, 5 different contents) |

Generations found (classification in `timinglab/discovery.py: classify_generation`):

| generation | files | where |
|---|---|---|
| SilicaFlux 2.x `.sf` RTL | 45 | `SilicaFlux-main/*.sf`, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/*.sf`, `silicaflux_rtl*.zip`, `silicaflux_alu.zip`, `forwarding_unit.zip` |
| SilicaFlux 1.0 `.sv` RTL | 23 | `SilicaFlux-main/silicaflux.zip!silicaflux/` (README: "SilicaFlux v1.0") |
| SilicaFlux sub-projects | 273 | memoryflow, testcore, silicaflux-ai, powerlink, bitcoin-asic, SilicaFluxML |
| stand-alone RTL libraries | 157 | FSM library, RISC-V CPU, cpu_core, pipelined_cpu, digital_lib, dsp_arithmetic, comm_protocols, memory_cache_repo, UVM-style FIFO, formal verification, soc_integration |
| earlier TimingLab archive | 50 | `SilicaFlux2.5/silicaflux-timinglab.zip` (targets the v1.0 `.sv` RTL; reviewed, none of its numbers reused) |
| unrelated | 69 | `Μετάλλιον Inc./`, `S.A. Aschombe & Sons./` |

## 2. What `.sf` means

`.sf` is used for three different things, distinguished by parsing, not by extension:

1. **SystemVerilog IEEE 1800-2017** (45 files). 32 files carry the banner
   `Language : Silica Flux-2017` (e.g. `silicaflux_pkg.sf:5`, `vector_engine.sf`,
   `noc_interconnect.sf:4`), two `Silica Flux-2017 verification subset (non-synthesizable)`
   (testbenches); all 45 parse with **zero** slang syntax errors and use ordinary SV-2017
   constructs (packages, `parameter type`, packed structs/unions, `always_ff/always_comb`,
   SVA). "Silica Flux-2017" is a branding of SystemVerilog-2017, so every tool in the flow
   reads `.sf` files as SystemVerilog.
2. **A DSL sketch** (`SilicaFluxML.zip!dsl/silicaflux_ml.sf`, two copies): self-declared
   "a plausible, strongly-typed, Chisel/Bluespec-flavoured surface syntax ... not a
   parseable/compiled language" (lines 6-13). 35 syntax errors as SV.
3. **A non-HDL reference model** (`S.A. Aschombe & Sons./Q2 2026.zip!Silica_Flux_Lighter.sf`,
   `#` comments, unrelated project). 548 syntax errors as SV.

`.sfx` files (`SilicaFlux2.5/*.sfx`) are SilicaFlux assembly programs for `sfx_asm.py`.

## 3. Which SilicaFlux 2.x blocks elaborate

`compile_matrix` in `discovery.json` tries every combination of candidate packages and
sub-modules for each module (pyslang full elaboration, module as top). Result:

| module (source) | elaborates | package used / reason it does not |
|---|---|---|
| `sf_alu` (`alu.sf`) | yes | any `silicaflux_pkg` (uses none of its members) |
| `sf_decoder` (`decoder.sf`) | yes | own `sf_decode_pkg` |
| `fetch_unit` (`fetch_unit.sf`) | yes | `sf_frontend_pkg.sf` |
| `memory_controller` (`memory_controller.sf`) | yes | **only** `silicaflux_pkg (1).sf` (memory transaction types) |
| `register_bank` (`register_bank (1).sf`, root) | yes | any |
| `register_bank` (`SilicaFlux2.5/register_bank.sf`) | yes | any (different implementation, same name) |
| `tensor_unit` (`tensor_unit.sf`) | yes | any |
| `vector_engine` (`SilicaFlux2.5/vector_engine.sf`) | yes | any |
| `forwarding_unit` (`forwarding_unit.zip!forwarding_unit/forwarding_unit.sf`) | yes | its `reference/silicaflux_pkg.sf` |
| `fetch_unit`, `alu`, `decoder` in `silicaflux_rtl*.zip` / `silicaflux_alu.zip` | yes | the archive's own `silicaflux_pkg.sf` |
| `noc_router`, `noc_interconnect` (`noc_interconnect.sf`) | **no** (1-2 errors) | `parameter type pkt_t = noc_packet_t`: no package defines `noc_packet_t`. TimingLab supplies the documented contract (lines 45-51) in `rtl/harness/tl_noc_pkt_pkg.sv` |
| `vector_engine` (`vector_engine (1).sf`, root) | no (37) | `SF_VELEN`, `sf_vex_ctrl_t`, ... undefined |
| `forwarding_unit` (root and 2.5 copies) | no (29 / 44) | `NUM_SRC_OPS`, `xlen_t`, ... undefined |
| `sf_alu` (`SilicaFlux2.5/alu (1).sf`) | no (2) | `silicaflux_pkg::rob_tag_t` undefined |
| `scheduler` (`scheduler.sf`) | no (53) | `sf_fu_e`, `sf_ptag_t`, `sf_wakeup_t`, ... undefined |
| `compute_tile` (`compute_tile.sf`) | no (66) | `sf_mem_req_t`, `sf_xword_t`, `SF_MEM_AW`, ... undefined |
| `tile_interface` (`tile_interface.sf`) | no (65) | `sf_vc_id_t`, `sf_tile_pkt_t`, `sf_noc_flit_t`, ... undefined |
| `silicaflux_top` (`SilicaFlux2.5/silicaflux_top.sf`) | no (65) | 27 instantiated modules exist nowhere (below) |
| `silicaflux_top` (`silicaflux_rtl*.zip`) | no (16) | 11 instantiated modules missing |

The elaborable set is exactly the TimingLab design catalogue (`flow/designs.toml`), and
`tests/test_rtl_elab.py` re-checks it on every run.

### Missing modules (instantiated, defined nowhere in the `.sf` tree)

From `SilicaFlux2.5/silicaflux_top.sf`: `sf_rst_ctrl` (542), `sf_rst_sync`, `sf_sync`,
`sf_clk_ctrl` (618), `sf_pwr_ctrl` (834), `sf_core` (889), `sf_l2_cache` (967),
`sf_reg_slice` (1008), `sf_sched_domain` (1032), `sf_vector_unit` (1061),
`sf_tlb_subsys` (1095), `sf_dispatch_fabric` (1140), `sf_tensor_engine` (1161),
`sf_axi_cdc` (1201), `sf_dma_bridge`, `sf_dbg_module` (1238), `sf_coh_xbar` (1389),
`sf_llc_bank`, `sf_coh_mgr` (1461), `sf_mem_fabric` (1494), `sf_axi_edge` (1518),
`sf_apb_cdc` (1557), `sf_cluster_csr` (1670), `sf_trace_agg` (1713), `sf_pmu` (1765),
`sf_fault_ctrl` (1830), `sf_irq_ctrl`; plus `sf_core_complex`, `sf_icg`, `sf_fifo`,
`sf_perf_monitor`, `sf_debug_module`, `sf_axi_mem_edge` from the `silicaflux_rtl*.zip` top.
`sf_rst_sync` and `sf_fifo` exist only as `.sv` files of other sub-projects
(`silicaflux-powerlink`, `silicaflux-memoryflow`) with different interfaces.

Consequence: **the 2.5 cluster cannot be synthesised or timed.** TimingLab therefore works
block by block on the 12 elaborable blocks and treats the cluster at syntax level (clock /
reset architecture, cluster SDC checked against a source-derived stub).

### Testbenches

`testbench_checks`: none of the 9 testbench→DUT instantiations of the `.sf` tree matches its
DUT. Examples: `tb_vector_engine.sf` connects `clk, rst_n, in_valid, in_ready, in_op, ...`
(12 ports, 0 in common with `vector_engine.sf`, whose ports are `clk_i, rst_ni, iss_*`);
`tb_tensor_unit.sf` 0/9; `tb_memory_controller.sf` 2/47; `tb_noc_interconnect.sf` 2/11
(it drives `inj_flit_i`/`FLIT_W` while the RTL has `tile_inj_pkt_i`/`pkt_t`). The testbenches
were evidently written for earlier, simpler interfaces. **No upstream testbench can verify
the current RTL**, so TimingLab verifies its alternatives against the upstream RTL itself
(`tb/equiv/`), not against upstream testbenches.

### Name collisions

`silicaflux_pkg` has 7 definitions with 5 different contents
(root `silicaflux_pkg.sf` v2.4 core package, 2081 lines; `silicaflux_pkg (1).sf` memory
transaction types, 136 lines; three archive versions; the `forwarding_unit.zip` reference).
They are mutually incompatible, so no single compilation can contain e.g. both
`memory_controller` and `scheduler`. Also duplicated: `register_bank`, `vector_engine`,
`sf_alu`, `fetch_unit`, `forwarding_unit`, `silicaflux_top` (different contents).

## 4. Architecture of the elaborable blocks (from source headers)

| block | category | structure (source) | clock / reset |
|---|---|---|---|
| `fetch_unit` | CPU front-end | F0 PC gen / redirect / I$ req → F1 BTB/BHT/RAS → FR response, fetch queue; OTB (fetch_unit.sf:1-30) | `clk_i`, async `rst_ni` |
| `sf_decoder` | CPU decode | N-wide (default 4) speculative decode, 4 formats R/I/M/X (decoder.sf:1-23) | `clk_i`, `rst_ni` |
| `register_bank` (×2) | CPU register file | 32×32b SRF (3R/2W) + 16×128b VRF (3R/1W), one-hot AND-OR read mux, WAW/RAW rules (register_bank*.sf headers) | `clk_i`, `rst_ni` |
| `forwarding_unit` | CPU hazard / bypass | combinational RAW detection + EX/MEM/WB bypass select (archive copy) | **no clock** (combinational) |
| `sf_alu` | CPU execute | fast path ADD..SLT, long MUL path `MUL_STAGES` deep, ROB-tagged out-of-order completion (alu.sf:1-14) | `clk_i`, `rst_ni` |
| `vector_engine` | vector | ISSUE / EX1 / EX2 / OUT; `EX_STAGES=1` → all in one cycle; lane adder+saturator, shifter, comparator, 32×32 multiplier, heap reduction tree (vector_engine.sf:1-37) | `clk_i`, `rst_ni` |
| `tensor_unit` | tensor MAC | 4×4 INT8 output-stationary MATMUL, radix-4 Booth, CSA, 20 pipeline stages S0..S19, release buffer drives the global advance (tensor_unit.sf:1-40) | `clk_i`, `rst_ni` |
| `memory_controller` | SRAM interface | 8 banks × 512 × 128 b scratchpad, per-bank arbitration of scalar/vector/burst, skid buffers, credit-reserved response FIFOs, parity (memory_controller.sf:1-90) | `clk_i`, `rst_ni` |
| `noc_interconnect` | interconnect / arbitration | 2×2 mesh of 5-port wormhole routers, XY routing, S1 buffer-write+RC, S2 round-robin switch allocation + one-hot AND-OR crossbar, registered links (noc_interconnect.sf:1-70) | `clk_i`, `rst_ni` |

Every elaborable block is single-clock with an active-low asynchronous reset (audit:
`clock_nets` and `async_reset_nets` per block in `reports/audit/*/rtl_audit.json`), so
intra-block CDC risk is nil; CDC and RDC live at cluster level.

## 5. Cluster clock and reset architecture (`SilicaFlux2.5/silicaflux_top.sf`, syntax level)

* Primary clocks (lines 18-23, 76-79, 106): `clk_core_i`, `clk_mem_i`, `clk_host_i`,
  `clk_rtc_i`, `jtag_tck_i`.
* Clock gating: `u_clk_ctrl` (sf_clk_ctrl, lines 618-635) produces `clk_core_gated[]`,
  `clk_vpu_gated[]`, `clk_llc_gated[]`, `clk_tns_gated` from `clk_core_i`; cores are
  clocked by `clk_core_gated[CI]` (line 895), the tensor engine by `clk_tns_gated` (1165).
* Resets: `u_rst_ctrl` (sf_rst_ctrl, 542-560) receives all four functional clocks and
  produces per-domain resets; `rst_uncore_n` is a test-mode mux of a sequencer flop (574);
  per-core resets are flops in `clk_core_i` (853-861); the memory-edge reset is the AND of
  `rst_mem_n` and a `clk_core_i` flop, re-synchronised into `clk_mem_i` by `sf_rst_sync`
  (577-586) and acknowledged back through `sf_sync` (589-596) - a reset-domain crossing that
  is handled by synchronisers, as the header promises (lines 25-26).
* CDC: `sf_axi_cdc` (1201), `sf_apb_cdc` (1557), `sf_sync` (ext IRQ, control inputs,
  638-656). All of these primitives are missing, so the "all crossings use CDC primitives"
  contract cannot be verified structurally yet - see `constraints/silicaflux_top.sdc`.

## 6. Build and verification infrastructure found

* `SilicaFlux2.5/run_sim.sh` (48 KB) and `sfx_asm.py` - Icarus Verilog runner and assembler,
  written for the v1.0 `.sv` layout (`rtl/*.sv`, `tb/*.sv`).
* `silicaflux.zip!silicaflux/synth/{silicaflux.sdc, vivado/, quartus/}` - FPGA flows for v1.0.
* No ASIC synthesis, STA or PnR scripts for the 2.x `.sf` RTL anywhere in the repository.

## 7. Dependency graph

`reports/discovery/sf2_dependency_graph.svg` (from the `.dot` beside it): one cluster per
directory / archive; green = elaborates, red = does not (with error count); solid edges are
instantiations (red when the testbench's port list does not match the DUT), dotted edges are
package imports ("one of N" where several definitions exist); dashed red boxes are missing
modules / packages.
