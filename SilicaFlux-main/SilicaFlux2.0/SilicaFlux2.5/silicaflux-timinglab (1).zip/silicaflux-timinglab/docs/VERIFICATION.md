# Verification and acceptance

Every proposed optimisation passes the seven gates of `timinglab/regress.py`
(`python -m timinglab accept`, result `reports/regression/acceptance.json`, shown in the
dashboard):

| # | gate | how |
|---|---|---|
| 1 | syntax and elaboration | pyslang full elaboration, 0 errors (`tests/test_rtl_elab.py` runs it for every catalogue design) |
| 2 | lint | `verilator --lint-only -Wall`; 0 errors and no warning class the upstream baseline does not already produce (`reports/verification/lint.json`) |
| 3 | functional simulation | equivalence benches against the **unmodified upstream RTL** (`tb/equiv/`), several configurations × 3 seeds × 20 000-50 000 cycles |
| 4 | formal equivalence | combinational datapath proofs and an unbounded sequential equivalence proof (k-induction) PROVEN; seeded-bug witnesses FAILED as expected (Yosys SAT, ABC iprove / bmc3 / ind / pdr; `formal/`, `reports/formal/formal.json`) |
| 5 | synthesis | synthesised on every PDK, no latches, no combinational loops |
| 6 | timing | reg2reg WNS after global route better than the baseline on every PDK |
| 7 | reproducible PPA | PPA comparison on every PDK; synthesis re-run from the same elaborated RTL yields a byte-identical netlist |

Upstream testbenches cannot be used: none of them matches the current RTL interfaces
(DISCOVERY.md §3). Equivalence is therefore checked RTL-against-RTL.

## Equivalence contracts

**`sf_vector_engine_pipe` vs `vector_engine` (tb_eq_vector).** Three engines see identical
random stimulus (random opcodes incl. FP-fusion class, masks, vector lengths, mask policy,
corner operands, 20 % stall, 40 % speculative issues):

* no flush: the consumed-result streams (`res_valid_o & ~stall_i`) are identical field by
  field (`res_scalar_o` when `res_scalar_wr_o`), in order;
* with flush, two checks: (a) for the upstream engine *and* the pipelined one, the consumed
  results are an in-order subsequence of a third, never-flushed upstream engine's results;
  every dropped packet is speculative and saw a flush while in flight; (b) **exact kill
  contract**: an occupancy model of the documented stage-register rules (stall holds and
  kills a held speculative packet on flush; a moving packet is masked by `flush & spec`)
  predicts which issue packet each engine must deliver on every non-stalled cycle; both
  engines must deliver exactly the golden payloads of that list. The model reproduces the
  upstream engine (EX_STAGES 1 and 2) exactly, which validates it. Check (b) was added after
  mutation testing showed that (a) alone does not catch a stage register that fails to kill
  a speculative packet;
* latency probe: 1 (upstream EX_STAGES=1), 2 (EX_STAGES=2), 3 (pipelined);
* configurations: LANES 4 / 8 / 16, LANE_W 32 / 16, reference EX_STAGES 1 and 2, legal
  stimulus with upstream SVA enabled (`--assert`), illegal-opcode stimulus with SVA off.

**`sf_alu_mulcsa` vs `sf_alu` (tb_eq_alu).** Cycle-exact: every output compared every cycle
for 50 000 cycles (≈ 25 000 multiplier results per run) with flush, branch kill / resolve
and result back-pressure; XLEN 64 and 32, MUL_STAGES 2 and 3; upstream SVA enabled.

## Formal

All engines are open source and run by `python -m timinglab formal`:

| engine | used for | PROVEN means |
|---|---|---|
| Yosys `sat` (MiniSat) | small combinational miters; 8-cycle bounded sequential miters (`sat -seq 8`, all-zero reset state) | "SAT proof finished - no model found: SUCCESS!" |
| ABC `iprove` (fraiging CEC) | multi-operand adder-tree miters that plain SAT does not finish | miter output proved constant 0 ("UNSATISFIABLE") |
| ABC `bmc3` + `ind -u` (k-induction) | **unbounded** sequential equivalence from reset | base case: `bmc3` finds no failure in the first 8 cycles from reset; inductive step: `ind` proves "Networks are equivalent" from an *arbitrary* state with state-uniqueness constraints; the base-case depth must cover the induction depth |
| ABC `pdr` (IC3) | **unbounded** sequential equivalence from reset | "Property proved" (ABC re-verifies the inductive invariant) |
| ABC `bmc3` | bounded sequential equivalence from reset, 16 cycles | "No output asserted in 16 frames" |

For the ABC engines the miter is exported as AIGER with one output `bad = !ok`; the AIG
size (inputs / latches / AND gates) is recorded and a trivial miter is reported as
VACUOUS, never as PROVEN. (This guard exists because an export mistake once produced an
empty AIG that "proved" instantly; and `write_aiger -zinit` without explicit zero init
values gives every flop a free initial value, which produced a spurious frame-0
counterexample - the flow now zero-initialises every flop, which is the reset state of both
designs.) Statuses are exactly what the solver printed: a Yosys `-verify` run that hits its
time limit is TIMEOUT, not FAILED (`tests/test_formal_status.py`).

### Why k-induction works for the vector-engine miter

The sequential miters (`formal/fv_vector_bmc.sv`, `formal/fv_alu_bmc.sv`) drive both
engines with the same free inputs every cycle and compare every output every cycle; the
upstream outputs of the vector engine pass through a two-entry delay line that advances only
on non-stalled cycles. The intuition for why the inductive step closes quickly: with
`flush_i` tied to 0, the stage registers of both engines and the delay line only advance on
non-stalled cycles, so the miter state is essentially a function of the last few accepted
issue packets, and a run of stalled cycles revisits states. Paths with a repeated state are
what the uniqueness (simple-path) constraints of `ind -u` exclude; ABC needed 2 of them and
4 frames. The proof does not rest on this argument - ABC checks the inductive step itself.
k-induction with simple-path constraints is sound: any reachable violation is reachable on a
loop-free path, which the base case and the step together cover.

Two other engines were tried on the vector miter and did not finish, which is why
k-induction carries the gate:
* `bmc3` alone: the run time per additional cycle grows about 2.5× (frame 5: 138 s, frame 7:
  1015 s cumulative), so a 16-cycle bound is out of reach. The structurally different
  datapaths are a large part of the cost: in an experiment that replaced the reference's
  `a * b` by the proven-equal carry-save multiplier, frame 7 dropped to 343 s, and to 215 s
  when the reduction tree was replaced as well, but the growth per cycle stayed above 2×.
  (The experiment is not part of the gate, which runs on the unmodified upstream RTL.)
  Unrolling the miter and proving it with `iprove` scaled the same way (6 frames: 161 s).
* PDR: no invariant within 50 minutes (465 latches; the invariant has to relate the
  pipelined engine's carry-save stage registers to the upstream result register word by
  word).

### Seeded-bug witnesses

Each unbounded sequential proof that gates an optimisation is re-run with one deliberate RTL bug
(`*__bug` checks, `expect: FAILED`), and the engine must return a counterexample. This shows
that the miter really compares the datapath outputs, so a PROVEN is not an artefact of the
miter construction:

| witness | seeded bug | result |
|---|---|---|
| `vector_kind_L4_W8__bug` | `sf_reduce_tree` inside `sf_vector_engine_pipe`: SUM CPA `s_row + c_row` → `s_row \| c_row` | counterexample in frame 3 (base case; frame 3 = the pipelined engine's latency) |
| `alu_pdr_X8__bug` | `sf_alu_mulcsa`: multiplier CPA `s + c` → `s ^ c` | counterexample in frame 3 (= multiplier latency) |

### What the formal gate requires

Gate 4 requires three things. First, the combinational proofs of every building block the
alternative uses. Second, an **unbounded** sequential equivalence proof of the whole
alternative against the unmodified upstream block, by whichever unbounded engine closes it.
Third, that proof's seeded-bug witness. The other sequential runs are reported as further
evidence, with the status the solver returned.

The two unbounded engines complement each other here. For the vector-engine miter PDR finds
no invariant in 50 minutes, while k-induction closes at 4 frames. For the ALU miter it is
the other way round: the inductive step stays UNDECIDED up to 8 frames (the property is not
k-inductive at that depth with free flush, kill and back-pressure inputs), while PDR finds
an inductive invariant in 9 s. The 16-cycle `bmc3` and the 8-cycle Yosys BMC of the ALU
agree with the PDR result.

| check | engine | role | claim |
|---|---|---|---|
| `mul_lo_W8` | sat | required (both) | `sf_mul_lo_csa`: (sum + carry) mod 2^8 = a·b mod 2^8 for **all** inputs |
| `csa_W32_N5`, `csa_W8_N8` | sat | required | `sf_csa_tree` preserves the sum of all rows mod 2^W (2 and 3 compressor levels) |
| `reduce_W32_N4` | sat | required (vector) | `sf_reduce_tree` equals the upstream heap reduction (ve_red_fn copied verbatim), 4 × 32 bit, all four operators |
| `reduce_W8_N8`, `reduce_W4_N16` | abc iprove | required (vector) | same, 8 lanes × 8 bit and 16 lanes × 4 bit |
| `vector_kind_L4_W8` | k-induction | required (vector) | **unbounded**: upstream `vector_engine` (EX_STAGES 1) and `sf_vector_engine_pipe` produce identical result streams, 2 non-stalled edges apart, for every input / stall sequence from reset (flush tied 0; LANES 4, LANE_W 8 - the smallest configuration the upstream allows). Base case 8 frames (1047 s), inductive step closes at 4 frames (14 s) |
| `alu_pdr_X8` | abc pdr | required (ALU) | **unbounded**: `sf_alu` and `sf_alu_mulcsa` identical outputs in every cycle of every input sequence from reset (XLEN 8; flush, kills, back-pressure free) |
| `alu_kind_X8` | k-induction | additional | the ALU property; base case clean, inductive step UNDECIDED at 8 frames |
| `alu_abcbmc_X8`, `alu_bmc_X8` | bmc3 / sat | additional | the ALU property, 16 and 8 cycles |
| `vector_pdr_L4_W8`, `vector_bmc_L4_W8` | abc pdr / sat | additional | the vector property with the two engines that do not finish (reported as TIMEOUT) |

Stress probes (reported, never gating): `csa_W16_N8`, `reduce_W16_N8`, `reduce_W8_N16`,
`mul_lo_W10`. They show where the solvers stop within 15-20 minutes on this machine.
Full-width (32 / 64-bit) designs are therefore verified by simulation (above). The status
of every check from the last run is in `reports/formal/formal.json`, in the dashboard and
in the generated table in [RESULTS.md](RESULTS.md) §7.

## Mutation testing

`python -m timinglab mutation` applies single-line mutations to the TimingLab RTL (wrong
unit select, XOR instead of CPA, missing lane masking, stage registers that ignore flush,
wrong pipeline field, saturation summary without lane qualification, broken compressor
carry, wrong partial-product shift, ...) and requires the equivalence bench to FAIL for each.
Result: `reports/verification/mutation.json`.

Two lessons from the first mutation run are kept in the suite: the original flush check
let "stage register does not kill on flush" mutants survive (fixed by the exact kill
contract above), and `exa_sat[l] = sat_evt` (dropping `& unit.add`) is an *equivalent*
mutant - saturation is only set by ADDS/SUBS/ADDUS/SUBUS, which always select `unit.add`,
and the flag is further masked by `lane_we`, which requires `vwr` - so it was replaced by a
non-equivalent mutant (swapped signed/unsigned overflow).

## Commands

```
python -m timinglab lint
python -m timinglab equiv
python -m timinglab mutation
python -m timinglab formal --gating  # what gate 4 needs (~35 min)
python -m timinglab formal           # + additional evidence and stress probes
python -m timinglab sdc
python -m timinglab accept
python -m pytest -q tests            # fast tier
RUN_SLOW=1 python -m pytest -q tests # + tool-driven tests
```
