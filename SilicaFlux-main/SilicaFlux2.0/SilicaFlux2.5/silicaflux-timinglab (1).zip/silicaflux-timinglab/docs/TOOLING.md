# Tooling

| tool | version used for `reports/` | obtained from | used for |
|---|---|---|---|
| Yosys + slang | 0.70 (git 28ba3cb92), YoWASP | `pip install yowasp-yosys` | `read_slang` elaboration of the SystemVerilog-2017 `.sf` sources |
| Yosys | 0.69+ (git 9f09efcdb) | conda-forge | technology mapping (ABC), audit netlists, formal (`sat`) |
| OpenSTA | 2.5.0 (2e59563717) | `sta` binary of the OpenROAD conda package | post-synthesis STA |
| OpenROAD | 2.0-12381-g01bba3695 | litex-hub conda channel | placement, CTS, global route, post-layout STA |
| Verilator | 5.054 | conda-forge (builds with system g++ 13) | lint, equivalence benches, mutation testing |
| Icarus Verilog | 13.0 | conda-forge | available; not needed by the benches |
| pyslang | 12.1.0 | PyPI | discovery, elaboration gate, source-level audit |
| Graphviz | 14.1.2 | conda-forge | dependency-graph SVG |
| Python | 3.13 (≥ 3.11 supported) | - | TimingLab itself (standard library + pyslang) |

`scripts/install_tools.sh` installs all of them under `/opt/tl`; `python -m timinglab tools`
prints what was found. Override with `TL_YOSYS_SLANG`, `TL_YOSYS`, `TL_STA`, `TL_OPENROAD`,
`TL_VERILATOR`, `TL_IVERILOG`, `TL_DOT`.

Not used: SymbiYosys / EQY (not installable from the sources reachable in this environment;
the formal checks use Yosys' built-in SAT solver), any commercial tool.
