# PDK support

| PDK | config | library / corner | site | routing | default T |
|---|---|---|---|---|---|
| SkyWater SKY130 | `flow/pdk/sky130hd.toml` | sky130_fd_sc_hd, tt_025C_1v80 | unithd | met1-met5 | 10 ns |
| GlobalFoundries GF180MCU | `flow/pdk/gf180mcu.toml` | gf180mcu_fd_sc_mcu9t5v0, tt_025C_5v00 | GF018hv5v_green_sc9 | Metal2-Metal5 (5LM_1TM) | 20 ns |
| IHP SG13G2 | `flow/pdk/ihp-sg13g2.toml` | sg13g2_stdcell, typ_1p20V_25C | CoreSite | Metal2-Metal5 | 8 ns |
| commercial 65 nm | `flow/pdk/commercial_65nm.toml.template` | **template only** | - | - | - |
| commercial 28 nm | `flow/pdk/commercial_28nm.toml.template` | **template only** | - | - | - |

All file and cell names of the three public PDKs mirror the `config.mk` of the
corresponding OpenROAD-flow-scripts platform (Apache-2.0); `scripts/fetch_pdks.sh`
downloads exactly those files into `third_party/platforms` (set `TL_PLATFORMS` to use
another location). Nothing is invented: dont-use lists, tie cells, minimum buffer, ABC
driver/load, place site, routing and I/O layers are copied from `config.mk`; the RC
values come from the platform's `setRC.tcl`.

TimingLab additions per PDK (not from ORFS): the clock period, uncertainty, I/O driver /
load for the SDC, core utilisation / placement density for the experiment, and
`abc_period_frac` (0.7). They are design choices, stated in each toml.

**Coverage in this release.** All 13 catalogue designs run the full flow on SKY130. On IHP
SG13G2 and GF180MCU the 7 designs that the comparisons and findings depend on are run:
`vector_engine`, `vector_engine_ex2`, `vector_engine_pipe`, `sf_alu`, `sf_alu_mulcsa`,
`sf_decoder` and `tensor_unit` (the audit's fanout hypothesis). The remaining blocks meet
timing with margin on SKY130 and were left out to fit the runtime of this environment;
`python scripts/batch.py --pdk ihp-sg13g2 gf180mcu` runs them all.

Only typical corners are used. Slow / fast Liberty files exist for all three PDKs and can be
added to `lib` for multi-corner analysis.

## Commercial PDKs

The templates list every field TimingLab needs with `<...>` placeholders and no vendor data.
Copy one to `flow/pdk/<name>.toml`, set `TL_C65_ROOT` / `TL_C28_ROOT`, fill in the fields
from your foundry documentation and run `python -m timinglab tools` to check the files
exist. TimingLab's flow is PDK-agnostic: every PDK-specific value is read from the toml.
