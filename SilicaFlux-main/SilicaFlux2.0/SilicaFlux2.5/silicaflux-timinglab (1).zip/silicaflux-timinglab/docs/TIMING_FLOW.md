# Timing flow

```
flow/designs.toml ─┐
upstream/*.sf ─────┤  stage (src/NN_*.sv, sources.json with SHA-256)
rtl/opt, rtl/harness┘
        │
        ▼  Yosys 0.70 + slang (YoWASP)           elab.ys     read_slang -G<params> ... --top <block>
   elab.il ──► register-context wrapper tl_wrap  (generated; one flop per non-clock input / output)
        │                                         elab_wrap.ys read_slang ... --top tl_wrap
        ▼  Yosys 0.69 (native) + ABC             synth.ys    synth -flatten; dfflibmap; abc -D 0.7T
   netlist.v / netlist.json / synth_stat.txt
        │
        ▼  OpenSTA 2.5                            flow/sta/sta.tcl + constraints/block.sdc
   sta_synth/   (ideal wires, unbuffered: early screen only)
        │
        ▼  OpenROAD 2.0                           flow/openroad/pnr.tcl
   pnr/place  (global + detailed placement, repair_design, placement parasitics)
   pnr/cts    (clock_tree_synthesis, propagated clocks)
   pnr/grt    (global route, global-route parasitics, congestion)   ← reference stage
        │
        ▼  timinglab.parsers → runs/<pdk>/<design>/result.json → reports/dashboard/
```

Run it with `python -m timinglab run <design ...> --pdk <pdk ...>` (or `make flow`).
Each run directory keeps every script, log and report; `result.json` records tool versions,
PDK files, the flow fingerprint (hash of all flow scripts / configs) and the SHA-256 of
every source, so `--resume` re-runs only what changed.

## Front-end: slang

Yosys' own Verilog parser cannot read the 2.x RTL (parameter types, packed struct ports,
package-scoped typedefs). The flow uses the slang front-end (`read_slang`) shipped in the
YoWASP build of Yosys 0.70 and hands the elaborated design to native Yosys 0.69 as RTLIL.
YoWASP runs under WASI and only sees its working directory, which is why sources are staged
into the run directory.

## Register context (`tl_wrap`)

Several blocks have long input→register or register→output paths whose slack would depend
entirely on an assumed I/O budget (e.g. the vector engine's issue operands feed a
single-cycle execute path; `forwarding_unit` is purely combinational). Every block is
therefore measured inside a generated wrapper that puts one flip-flop on each non-clock,
non-reset input and on each output (`timinglab/flow/synth.py: wrapper_sv`). The block is
not modified. All paths through the block become reg2reg paths of the wrapper, and the
`reg2reg` path group is the subject of every before/after comparison.

## Synthesis settings (identical for every design)

* `synth -flatten`, `dfflibmap` and `abc -D <0.7 × T>` against the PDK's typical Liberty,
  with `dont_use` lists, tie cells and a minimum buffer from the PDK config. ABC also gets
  the ORFS driver cell and load (`abc.constr`).
* **ABC delay target = 0.7 × clock period** (`abc_period_frac`). ABC sees gate delays only
  (no wires, setup or clock-to-Q) and recovers area until its own estimate meets `-D`.
  With `-D = T` it re-mapped parallel-prefix adders into ripple chains of `maj3` cells that
  then failed after placement (observed on `vector_engine_pipe`, sky130hd: the worst path was a
  chain of `maj3` cells). The same factor is applied to every design and PDK.
* Public RTL names are kept (`opt_clean` without `-purge`, `autoname`), so STA endpoints
  can be mapped back to RTL registers (`timinglab/confirm.py`).

## Static timing (OpenSTA)

`flow/sta/tl_report.tcl` is shared by the stand-alone OpenSTA step and all OpenROAD stages.
It writes text reports and `paths.tsv`, a machine-readable dump produced through the
OpenSTA Tcl path API (OpenSTA 2.5 has no JSON path report): for the worst path to every
endpoint, per path group, every timing point (pin, direction, instance, cell, arrival) plus
the PathEnd's data arrival / required time, launch and capture clock latency and check
margin. From these the parser derives logic depth, cell vs. net delay, buffer count and
per-path clock skew.

## Placement / CTS / global route (OpenROAD)

A timing experiment, not sign-off:

| step | setting |
|---|---|
| clock root | Yosys `insbuf` turns the wrapper's alias `clk_i` → `u_dut.clk_i` into a buffer at the clock root. On IHP SG13G2, whose generic buffers double as clock buffers, TritonCTS then skipped the clock ("found 0 clock nets"). Before floorplanning the flow deletes exactly the buffers of the PDK's insbuf cell driven by the clock port (loads reconnected). A blanket `remove_buffers` (the ORFS choice) was tried and rejected: it also strips ABC's timing-driven buffering, which this flow does not restore because it does not run `repair_timing`; every SKY130 block got slower. A run whose CTS builds no tree is marked failed |
| floorplan | square die; side = max(√(cell area / util), pin-limited side) + margin; `core_utilization` from the PDK config (35-40 %) |
| I/O | random pins, then placement-aware `place_pins` after a first global placement |
| placement | `global_placement -density <0.45-0.60>`, `repair_design` (max slew / cap / fanout buffering), `detailed_placement` |
| setup repair | **off** (`repair_timing` not run) - comparisons isolate the RTL |
| CTS | `clock_tree_synthesis -sink_clustering_enable`, propagated clocks, `repair_design` again |
| global route | layer adjustment 0.2, `-congestion_iterations 10`, `-allow_congestion`, `estimate_parasitics -global_routing` |
| not done | PDN, detailed routing, RC extraction, hold repair, multi-corner |

Hold is reported but not repaired, so post-CTS hold slack is negative on most blocks; setup
is the subject of every comparison.

## Path groups and derived quantities

`reg2reg`, `in2reg`, `reg2out`, `in2out` (constraints/block.sdc). With the register
context, the block's paths are all in `reg2reg`; `in2reg` holds the reset-recovery checks
of `rst_ni`.

* **Fmax\*** = 1000 / (T − reg2reg WNS) MHz: the reg2reg-limited clock with the same
  uncertainty and setup assumptions. Derived, labelled with `*`.
* **time/op\*** = latency × (T − reg2reg WNS): the isolated-operation time; a latency
  increase can make this worse even when Fmax\* improves.
* logic depth = combinational cells between launch and capture register on the STA path.

## Runtime (this environment, 4 cores)

Elaboration < 1 s, synthesis 5-60 s, STA 3-10 s, PnR 2-6 min per block and PDK.

### Log lines that look like errors but are expected

* `[ERROR STA-0563] find_timing_paths -group_path_count is not a known keyword or flag.` -
  printed once per run by the option-spelling probe in `flow/sta/tl_report.tcl` (`tl_flags`,
  inside `catch`): OpenSTA 2.6+ spells the path-count options `-group_path_count`, the
  OpenSTA in this OpenROAD build uses `-group_count`, which the probe then selects.
* `Using max wire length 195441um` on GF180MCU - the resizer's limit derived from the 5 V
  library's slew limits and the low wire resistance; it is not an RC set-up error (the
  platform's `setRC.tcl` is sourced, see `pnr_env.json: TL_SET_RC`).

