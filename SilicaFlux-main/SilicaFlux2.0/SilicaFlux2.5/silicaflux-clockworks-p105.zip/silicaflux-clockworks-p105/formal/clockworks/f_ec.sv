// =============================================================================
// Formal wrapper: sf_clock_enable_ctrl (NE = 1, small widths).  Free inputs.
//  E1  clk_en is EXACTLY the registered function  clk_run | rst_force | test_force | test_en | busy
//  E2  the clock enable never falls while the engine was busy, had outstanding work or a transfer offered
//  E3  the ledger equals  prev + issue - retire  (cleared under reset, clamped with an error on violation)
//  E4  the work gate is  accept_fsm & ~f_block
//  E5  quiet_o implies the raw quiescence condition held in the previous cycle, and for
//      quiet-cycle limits <= 3 the previous <limit> cycles (bounded window check)
// =============================================================================
module f_ec
  import sf_cw_pkg::*;
(
  input wire clk,
  input wire clk_run, accept_fsm, rst_force, test_force, test_en, f_block,
  input wire [7:0] qcyc, input wire [NQ-1:0] qmask,
  input wire e_idle, e_obuf, e_dma, e_mem, e_err, e_wake, stalled, offered,
  input wire [1:0] iss, ret,
  output wire [7:0] chk_o
);
  localparam int OW = 4, EVW = 2;
  reg f_past_valid = 1'b0;
  always @(posedge clk) f_past_valid <= 1'b1;
  wire rst_ni = f_past_valid;

  wire clk_en, accept_en, quiet, wake_ev, auto_idle, act, ilk;
  wire [OW-1:0] outs; wire [NQ-1:0] qv; wire [7:0] fev;
  sf_clock_enable_ctrl #(.NE(1), .OW(OW), .EVW(EVW), .LEDGER_EN(1'b1)) dut (
    .clk_i(clk), .rst_ni(rst_ni), .clk_run_i(clk_run), .accept_fsm_i(accept_fsm), .rst_clk_force_i(rst_force),
    .test_clk_force_i(test_force), .test_en_i(test_en), .f_block_i(f_block),
    .cfg_quiet_cyc_i(qcyc), .cfg_idle_thr_i(24'd0), .cfg_qmask_i(qmask), .cfg_auto_idle_en_i(1'b0), .cfg_wake_en_i(1'b1),
    .clk_loss_i(1'b0), .eng_idle_i(e_idle), .eng_obuf_empty_i(e_obuf), .eng_dma_idle_i(e_dma), .eng_mem_idle_i(e_mem),
    .eng_err_i(e_err), .eng_wake_req_i(e_wake), .up_stalled_i(stalled), .in_offered_i(offered),
    .issue_cnt_i(iss), .retire_cnt_i(ret),
    .clk_en_o(clk_en), .accept_en_o(accept_en), .quiet_o(quiet), .wake_ev_o(wake_ev), .auto_idle_o(auto_idle),
    .act_o(act), .outstanding_o(outs), .q_vec_o(qv), .fault_ev_o(fev), .ilk_hit_o(ilk));

  reg pclk_run, prf, ptf, pte, pidle, poffered, perr; reg [OW-1:0] pout; reg [1:0] piss, pret;
  reg praw, praw2, praw3, pq1, pq2;
  reg [7:0] pqcyc;
  // The first cycle is the reset cycle: the DUT ignores its inputs, so the history takes the
  // values that reproduce the reset state (clock enable 1, ledger 0).
  always @(posedge clk) begin
    pclk_run <= f_past_valid ? clk_run : 1'b1;      prf <= f_past_valid & rst_force;
    ptf <= f_past_valid & test_force;               pte <= f_past_valid & test_en;
    pidle <= f_past_valid ? e_idle : 1'b1;          poffered <= f_past_valid & offered;
    pout <= f_past_valid ? outs : {OW{1'b0}};       piss <= f_past_valid ? iss : 2'd0;
    pret <= f_past_valid ? ret : 2'd0;              perr <= e_err;
  end

  // raw quiescence in the current cycle, from the DUT's own q vector and its ledger-error flag
  wire lerr = fev[FC_LEDGER];
  wire raw  = (&(qv | ~qmask)) & ~lerr;
  always @(posedge clk) begin praw <= raw; praw2 <= praw; praw3 <= praw2; pqcyc <= qcyc; end
  wire [7:0] qlim = (qcyc == 8'd0) ? 8'd1 : qcyc;

  integer sum_m;
  reg [OW-1:0] exp_out; reg exp_err;
  always @* begin
    sum_m = $signed({{(32-OW){1'b0}}, pout}) + $signed({{(32-EVW){1'b0}}, piss}) - $signed({{(32-EVW){1'b0}}, pret});
    exp_err = 1'b0; exp_out = sum_m[OW-1:0];
    if (prf) exp_out = {OW{1'b0}};
    else if (sum_m < 0) begin exp_out = {OW{1'b0}}; exp_err = 1'b1; end
    else if (sum_m > 15) begin exp_out = {OW{1'b1}}; exp_err = 1'b1; end
  end

  reg [7:0] chk;
  assign chk_o = chk;
  always @* begin
    chk = 8'hFF;
    if (f_past_valid) begin
      // E1 exact registered enable function (the previous cycle's inputs and ledger value)
      chk[0] = (clk_en == (pclk_run | prf | ptf | pte | !pidle | (pout != 0) | poffered));
      // E2 the enable never falls on a busy engine
      chk[1] = !(f_prev_en && !clk_en) || (pidle && pout == 0 && !poffered);
      // E3 the ledger
      chk[2] = (outs == exp_out);
      // E4 the work gate
      chk[3] = (accept_en == (accept_fsm & ~f_block));
      // E5 quiet implies the raw condition held in the cycle before (and the whole window, for short windows)
      if (quiet) begin
        chk[4] = praw;
        if (qlim >= 2) chk[5] = praw2;
        if (qlim >= 3) chk[6] = praw3;
      end
      // E6 a ledger violation is reported as a fault event in the next cycle
      chk[7] = (fev[FC_LEDGER] == exp_err);
    end
  end
  reg f_prev_en = 1'b1;
  always @(posedge clk) f_prev_en <= clk_en;
  always @* assume(qcyc <= 8'd3);
  always @* assert(&chk);
endmodule
