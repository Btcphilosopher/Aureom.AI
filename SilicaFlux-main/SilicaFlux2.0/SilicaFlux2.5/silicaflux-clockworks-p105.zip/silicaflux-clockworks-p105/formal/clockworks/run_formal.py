#!/usr/bin/env python3
"""CLOCKWORKS formal driver: Yosys 0.33 + z3 (no SymbiYosys is available in this environment).

Jobs
  fsm_*      sf_power_state_fsm, 4 parameter sets   -> temporal induction (unbounded when it closes)
  ec         sf_clock_enable_ctrl                   -> temporal induction
  rs, rs_po  sf_reset_sequencer                     -> bounded model checking (counters make the step open)
  planted_*  the same proofs on a mutated copy       -> MUST FAIL (proves the properties are not vacuous)
             (planted_rs_*: reset-sequencer mutants against R1 / R3)

Result words: PROVED = base case + induction step closed (unbounded); BOUNDED = holds for N steps from
reset, induction did not close; FAILED = counterexample; for planted_* the expected result is FAILED.
usage: run_formal.py [--depth N] [--timeout S] [jobs...]
"""
import argparse, concurrent.futures as cf, pathlib, re, shutil, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
OUT = ROOT / "build/formal"
sys.path.insert(0, str(ROOT / "tools"))
import mutate  # noqa: E402  (mutant definitions are shared with the simulation mutation check)

PREP = ROOT / "formal/clockworks/yosys_prep.py"
RTL = lambda n: f"rtl/clockworks/{n}"

def prep(files, outdir):
    outdir.mkdir(parents=True, exist_ok=True)
    subprocess.run([sys.executable, "-I", str(PREP), str(outdir), str(ROOT / RTL("sf_cw_pkg.sv"))] + [str(f) for f in files], check=True)

def yosys(name, reads, top, depth, timeout, extra_defs=""):
    log = OUT / f"{name}.log"
    cmd = (f"read_verilog -sv -formal {' '.join(str(r) for r in reads)}; hierarchy -check -top {top}; proc; flatten; opt_expr; "
           f"opt_clean; async2sync; dffunmap; opt -fast; memory_map; opt -fast; "
           f"sat -tempinduct -prove-asserts -set-assumes -maxsteps {depth} -timeout {timeout} -show-ports -verify")
    t0 = time.time()
    try:
        subprocess.run(["yosys", "-q", "-l", str(log), "-p", cmd], capture_output=True, timeout=timeout * 3 + 60)
    except subprocess.TimeoutExpired:
        return "TIMEOUT", f"killed after {timeout*3+60} s", time.time() - t0
    txt = log.read_text() if log.exists() else ""
    dt = time.time() - t0
    if "Induction step proven: SUCCESS" in txt:
        m = re.findall(r"Induction step proven: SUCCESS", txt)
        k = re.findall(r"Trying induction with length (\d+)", txt)
        return "PROVED", f"unbounded: base case and induction step closed at k={k[-1] if k else '?'}", dt
    if re.search(rf"^Base case for induction length {depth} proven", txt, re.M) and "Reached maximum number of time steps" in txt:
        return "BOUNDED", f"all assertions hold for {depth} steps from reset; induction step did not close", dt
    if "model found for base case: FAIL" in txt or "proof failed" in txt or "failed" in txt.lower():
        k = re.findall(r"Trying induction with length (\d+)", txt)
        return "FAILED", f"counterexample at step {k[-1] if k else '?'} (see {log.relative_to(ROOT)})", dt
    return "INCONCLUSIVE", txt.strip().splitlines()[-1][:80] if txt.strip() else "no log", dt

FSM_CFG = {
    "plain":              (0, 0, 0, 0, 0),
    "save_cancel_sram":   (1, 1, 0, 1, 1),
    "cancel_rstwake":     (0, 1, 1, 0, 0),
    "sram_unqualified":   (0, 0, 0, 1, 0),
}

def fsm_top(name, cfg, fsm_dir):
    s, c, r, h, q = cfg
    f = OUT / f"top_{name}.sv"
    f.write_text(f"""module f_fsm_top(input wire clk, input wire [15:0] cfg_drain, cfg_cancel, cfg_wake, cfg_dep, cfg_minact, input wire [7:0] cfg_settle,
  input wire cfg_frst, input wire [3:0] cfg_maxrst, input wire fault_clr, input wire req_valid, input wire [2:0] req_state,
  input wire test_hold, auto_idle, wake_ev, rst_active, rst_done, rst_fail, rst_pend,
  input wire quiet, clk_en, clk_ok, prov_ready, deps_iso, eng_ready, fabric_ack, save_done, restore_done, input wire [7:0] fault_ev,
  output wire [23:0] chk_o, output wire [2:0] st_o, ws_o, pst_o, pws_o, output wire acc_o, pacc_o, pfa_o, output wire [7:0] inv_o);
  f_fsm #(.SAVE_EN({s}), .CAN_CANCEL({c}), .RST_ON_WAKE({r}), .HAS_SRAM({h}), .SRAM_QUAL({q})) u (.*);
endmodule
""")
    return f

def job_fsm(name, depth, timeout, mutant=None):
    d = OUT / f"rtl_{name}"
    src = ROOT / RTL("sf_power_state_fsm.sv")
    files = [src, ROOT / "formal/clockworks/f_fsm.sv"]
    if mutant:
        mid, desc, edits = mutant
        tmp = OUT / f"mut_{name}"; tmp.mkdir(parents=True, exist_ok=True)
        t = src.read_text()
        for rel, old, new in edits:
            if rel.endswith("sf_power_state_fsm.sv"):
                if t.count(old) != 1: return "ERROR", f"pattern not unique for {mid}", 0
                t = t.replace(old, new)
        (tmp / "sf_power_state_fsm.sv").write_text(t)
        files = [tmp / "sf_power_state_fsm.sv", ROOT / "formal/clockworks/f_fsm.sv"]
    prep(files, d)
    cfg = FSM_CFG["save_cancel_sram" if mutant and mutant[0] in ("M30",) else "plain"] if mutant else FSM_CFG[name]
    top = fsm_top(name, cfg, d)
    return yosys(name, [d / "sf_power_state_fsm.sv", d / "f_fsm.sv", top], "f_fsm_top", depth, timeout)

def job_ec(depth, timeout):
    d = OUT / "rtl_ec"
    prep([ROOT / RTL("sf_clock_enable_ctrl.sv"), ROOT / "formal/clockworks/f_ec.sv"], d)
    return yosys("ec", [d / "sf_clock_enable_ctrl.sv", d / "f_ec.sv"], "f_ec", depth, timeout)

def job_rs(name, po, depth, timeout, mutant=None):
    d = OUT / f"rtl_{name}"
    src = ROOT / RTL("sf_reset_sequencer.sv")
    if mutant:
        mid, desc, edits = mutant
        tmp = OUT / f"mut_{name}"; tmp.mkdir(parents=True, exist_ok=True)
        t = src.read_text()
        for rel, old, new in edits:
            if rel.endswith("sf_reset_sequencer.sv"):
                if t.count(old) != 1: return "ERROR", f"pattern not unique for {mid}", 0
                t = t.replace(old, new)
        (tmp / "sf_reset_sequencer.sv").write_text(t)
        src = tmp / "sf_reset_sequencer.sv"
    prep([src, ROOT / "third_party/silicaflux_p40/sf_reset_sync.sv", ROOT / "formal/clockworks/f_rs.sv"], d)
    top = OUT / f"top_{name}.sv"
    top.write_text(f"""module f_rs_top(input wire clk, input wire glob, input wire [1:0] sub, wdt, flt, input wire sys_wdt, test_hold,
  input wire [1:0] iso, eng_ready, clk_en_fb, input wire clk_ok, input wire [7:0] cfg_hold, input wire [15:0] cfg_rtmo,
  input wire [7:0] cfg_stable, input wire [15:0] cause_clr);
  f_rs #(.POWER_ON_ONLY({po})) u (.*);
endmodule
""")
    return yosys(name, [d / "sf_reset_sync.sv", d / "sf_reset_sequencer.sv", d / "f_rs.sv", top], "f_rs_top", depth, timeout)

PLANTED = ["M01", "M02", "M03", "M04", "M10", "M11", "M19", "M29", "M30"]
PLANTED_RS = ["M06", "M07", "M22"]       # reset-sequencer mutants: R3 (hold in delivered edges), R1 (rank order)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--depth", type=int, default=14)
    ap.add_argument("--rs-depth", type=int, default=24)
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("jobs_sel", nargs="*")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    jobs = {}
    for n in FSM_CFG:
        jobs[f"fsm_{n}"] = (lambda n=n: job_fsm(n, a.depth, a.timeout), "PROVED")
    jobs["ec"] = (lambda: job_ec(a.depth, a.timeout), "PROVED")
    jobs["rs_power_on"] = (lambda: job_rs("rs_power_on", 1, a.rs_depth, a.timeout), "BOUNDED")
    jobs["rs_requests"] = (lambda: job_rs("rs_requests", 0, a.rs_depth, a.timeout), "BOUNDED")
    muts = {m[0]: m for m in mutate.MUTANTS}
    for mid in PLANTED:
        jobs[f"planted_{mid}"] = (lambda mid=mid: job_fsm(f"planted_{mid}", a.depth, a.timeout, muts[mid]), "FAILED")
    for mid in PLANTED_RS:
        jobs[f"planted_rs_{mid}"] = (lambda mid=mid: job_rs(f"planted_rs_{mid}", 1 if mid == "M07" else 0, a.rs_depth, a.timeout, muts[mid]), "FAILED")
    sel = [j for j in jobs if not a.jobs_sel or any(j.startswith(s) for s in a.jobs_sel)]
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        fut = {ex.submit(jobs[j][0]): j for j in sel}
        for f in cf.as_completed(fut):
            j = fut[f]; st, det, dt = f.result()
            exp = jobs[j][1]
            ok = (st == exp) or (exp == "PROVED" and st in ("PROVED",)) or (exp == "BOUNDED" and st in ("BOUNDED", "PROVED"))
            res.append((j, st, det, dt, ok))
            print(f"FORMAL {j:24s} {st:8s} {det} [{dt:.0f}s]{'' if ok else '   <-- UNEXPECTED'}", flush=True)
    res.sort()
    lines = ["# Formal results (Yosys 0.33 + z3, no SymbiYosys available)", "",
             f"Depth {a.depth} (FSM, enable controller) / {a.rs_depth} (reset sequencer).", "",
             "| job | result | detail | time |", "|---|---|---|---|"]
    for j, st, det, dt, ok in res:
        lines.append(f"| {j} | {st}{'' if ok else ' (UNEXPECTED)'} | {det} | {dt:.0f} s |")
    lines += ["", "`planted_*` runs the same FSM properties on a deliberately broken copy; FAILED is the expected result and shows",
              "that the properties detect the defect (they are not vacuous). PROVED means the base case and the induction step",
              "both closed, i.e. the property holds for every reachable state under the stated environment assumptions;",
              "BOUNDED means it holds for the stated number of steps from reset only."]
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports/formal.md").write_text("\n".join(lines) + "\n")
    sys.exit(0 if all(r[4] for r in res) else 1)

if __name__ == "__main__":
    main()
