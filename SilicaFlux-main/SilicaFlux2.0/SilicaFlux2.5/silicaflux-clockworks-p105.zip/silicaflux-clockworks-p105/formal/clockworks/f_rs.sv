// =============================================================================
// Formal wrapper: sf_reset_sequencer, NE = 2 (engine 1 requires engine 0, rank 0 < rank 1).
// Pins: por_ni low for the first cycle only, ext_rst_ni high, no test mode.
//   R1  (power-on, no further requests) engine 1 is never released while engine 0 is in reset
//   R2  rst_done only after the engine's reset was released (acknowledged release)
//   R3  every reset is held for at least HOLD clock edges DELIVERED to the engine
//   R4  closure: a request on engine 0 takes engine 1 into reset iff engine 1 is not isolated
//   R5  a request taken in a cycle puts the engine under the sequencer's ownership (rst_active) in the next cycle
// =============================================================================
module f_rs
  import sf_cw_pkg::*;
#(parameter bit POWER_ON_ONLY = 1'b0)
(
  input wire clk,
  input wire glob, input wire [1:0] sub, wdt, flt, input wire sys_wdt, test_hold,
  input wire [1:0] iso, eng_ready, clk_en_fb, input wire clk_ok,
  input wire [7:0] cfg_hold, input wire [15:0] cfg_rtmo, input wire [7:0] cfg_stable,
  input wire [15:0] cause_clr
);
  reg f_past_valid = 1'b0;
  always @(posedge clk) f_past_valid <= 1'b1;

  wire sys_rst_n; wire [1:0] eng_rst_n, active, done, fail, force_, event_, pend; wire [15:0] cause; wire [31:0] cnt;
  sf_reset_sequencer #(.NE(2), .DEP_MASK(64'h0000_0000_0000_0100), .REL_RANK(16'h0004)) dut (
    .clk_i(clk), .por_ni(f_past_valid), .ext_rst_ni(1'b1), .test_mode_i(1'b0), .test_rst_ni(1'b1),
    .glob_rst_req_i(glob), .sub_rst_req_i(sub), .wdt_rst_req_i(wdt), .fault_rst_req_i(flt), .sys_wdt_rst_i(sys_wdt),
    .test_rst_hold_i(test_hold), .iso_i(iso), .eng_ready_i(eng_ready), .clk_en_fb_i(clk_en_fb), .clk_ok_i(clk_ok),
    .cfg_hold_i(cfg_hold), .cfg_ready_tmo_i(cfg_rtmo), .cfg_rdy_stable_i(cfg_stable), .cause_clr_i(cause_clr),
    .sys_rst_no(sys_rst_n), .eng_rst_no(eng_rst_n), .rst_active_o(active), .rst_done_o(done), .rst_fail_o(fail),
    .rst_clk_force_o(force_), .rst_event_o(event_), .rst_pend_o(pend), .cause_o(cause), .rst_cnt_o(cnt));

  // environment: hold time configuration is small and constant; optionally power-on only
  reg [7:0] h0 = 8'd0;
  always @(posedge clk) h0 <= f_past_valid ? h0 : cfg_hold;
  always @* begin
    assume(cfg_hold <= 8'd3);
    if (f_past_valid) assume(cfg_hold == h0);
    assume(cfg_rtmo <= 16'd6);
    assume(cfg_stable <= 8'd2);
    if (POWER_ON_ONLY) assume(!(glob || (|sub) || (|wdt) || (|flt) || sys_wdt || test_hold));
  end

  reg [1:0] prn, ppend; reg [3:0] ecnt0, ecnt1;
  always @(posedge clk) begin
    prn <= eng_rst_n; ppend <= pend & {2{f_past_valid}};
    ecnt0 <= (!eng_rst_n[0] && clk_en_fb[0]) ? ((ecnt0 == 4'hF) ? ecnt0 : ecnt0 + 4'd1) : (eng_rst_n[0] ? 4'd0 : ecnt0);
    ecnt1 <= (!eng_rst_n[1] && clk_en_fb[1]) ? ((ecnt1 == 4'hF) ? ecnt1 : ecnt1 + 4'd1) : (eng_rst_n[1] ? 4'd0 : ecnt1);
  end
  wire [7:0] hold_lim = (cfg_hold < 8'd2) ? 8'd2 : cfg_hold;

  reg [7:0] chk;
  always @* begin
    chk = 8'hFF;
    if (f_past_valid) begin
      // R1
      if (POWER_ON_ONLY) chk[0] = !(eng_rst_n[1] && !eng_rst_n[0]);
      // R2
      chk[1] = (!done[0] || eng_rst_n[0]) && (!done[1] || eng_rst_n[1]);
      // R3 at the release edge the delivered-edge count reached the hold time (counter value of the previous cycle)
      if (eng_rst_n[0] && !prn[0]) chk[2] = (ecnt0 >= hold_lim[3:0]);
      if (eng_rst_n[1] && !prn[1]) chk[3] = (ecnt1 >= hold_lim[3:0]);
      // R4 closure: a request on engine 0 reaches engine 1 exactly when engine 1 is not isolated
      if (sub[0] && !iso[1]) chk[4] = pend[1];
      if (pend[1] && !(glob || sub[1] || wdt[1] || flt[1] || sys_wdt || test_hold)) chk[5] = ((sub[0] || wdt[0] || flt[0]) && !iso[1]);
      // R5 a request taken now means the sequencer owns the engine next cycle
      chk[6] = (!ppend[0] || active[0]) && (!ppend[1] || active[1]);
    end
  end
  always @* assert(&chk);
endmodule
