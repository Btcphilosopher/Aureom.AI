#!/usr/bin/env python3
"""Rewrite CLOCKWORKS RTL for Yosys 0.33's native Verilog frontend.

Yosys 0.33 accepts `package` definitions but not a wildcard `import pkg::*`.  This script
performs exactly what the import means, mechanically:

  * the body of sf_cw_pkg (constants and functions) is copied into every module that imports it
  * constants used in module HEADERS (parameter widths / defaults) are replaced by their literal values
  * `import ...;` lines are removed, `default_nettype` directives are dropped

Nothing else changes: the formal proofs run on the same RTL text, mechanically rewritten.
usage: yosys_prep.py <out_dir> <sf_cw_pkg.sv> <files...>
"""
import pathlib, re, sys

HEADER_CONSTS = {            # used in module headers; literal values from sf_cw_pkg.sv
    "CW_MAXE": "8",
    "CW_REF_DEP": "64'h00_00_04_04_04_02_00_04",
    "CW_REF_RANK": "16'h0A93",
    "CW_REF_GRP": "16'h1002",
    "CW_REF_HAS_SRAM": "8'b0011_0011",
    "CW_REF_CAN_CANCEL": "8'b0000_1000",
}

def pkg_body(pkg_text: str) -> str:
    m = re.search(r"package\s+sf_cw_pkg\s*;(.*?)endpackage", pkg_text, re.S)
    return m.group(1)

def prep(text: str, body: str) -> str:
    text = text.replace("`default_nettype none", "").replace("`default_nettype wire", "")
    pat = re.compile(r"module\s+\w+\s*((?:\s*import\s+[\w:]+::\*\s*;)+)", re.S)
    m = pat.search(text)
    if not m:
        return text
    imports = re.findall(r"import\s+([\w:]+)::\*\s*;", m.group(1))
    # strip the imports from the header
    start = m.start(1)
    text = text[:start] + text[m.end(1):]
    # find the end of the header: first ';' at paren depth 0 after the module name
    mm = re.search(r"module\s+\w+", text)
    i, depth, started = mm.end(), 0, False
    while True:
        c = text[i]
        if c == "(":
            depth += 1; started = True
        elif c == ")":
            depth -= 1
        elif c == ";" and depth == 0 and started:
            break
        i += 1
    header, rest = text[:i + 1], text[i + 1:]
    for k, v in HEADER_CONSTS.items():
        header = re.sub(r"\b%s\b" % k, v, header)
    inline = body if "sf_cw_pkg" in imports else ""
    return header + "\n  // ---- sf_cw_pkg inlined by yosys_prep.py ----" + inline + "\n  // ---- end inline ----\n" + rest

if __name__ == "__main__":
    od = pathlib.Path(sys.argv[1]); od.mkdir(parents=True, exist_ok=True)
    body = pkg_body(pathlib.Path(sys.argv[2]).read_text())
    for f in sys.argv[3:]:
        p = pathlib.Path(f)
        (od / p.name).write_text(prep(p.read_text(), body))
