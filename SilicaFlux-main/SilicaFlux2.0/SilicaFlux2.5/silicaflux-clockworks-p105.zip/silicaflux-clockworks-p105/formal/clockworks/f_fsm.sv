// =============================================================================
// Formal wrapper: sf_power_state_fsm.  All inputs are free each cycle, subject to
// the environment assumptions below.  Properties F01..F15 are the safety rules S1..S6
// of the FSM header plus transition legality.  Proven by temporal induction
// (Yosys `sat -tempinduct`) where the result says UNBOUNDED, else bounded.
//
// The wrapper compiles the FSM with a parameter set chosen by the run script
// (SAVE_EN / CAN_CANCEL / RST_ON_WAKE / HAS_SRAM / SRAM_QUAL).
// =============================================================================
module f_fsm
  import sf_cw_pkg::*;
#(
  parameter bit SAVE_EN = 0, parameter bit CAN_CANCEL = 0, parameter bit RST_ON_WAKE = 0,
  parameter bit HAS_SRAM = 0, parameter bit SRAM_QUAL = 0
) (
  input  wire clk,
  input  wire [15:0] cfg_drain, cfg_cancel, cfg_wake, cfg_dep, cfg_minact,
  input  wire [7:0]  cfg_settle,
  input  wire cfg_frst, input wire [3:0] cfg_maxrst, input wire fault_clr,
  input  wire req_valid, input wire [2:0] req_state,
  input  wire test_hold, auto_idle, wake_ev,
  input  wire rst_active, rst_done, rst_fail, rst_pend,
  input  wire quiet, clk_en, clk_ok, prov_ready, deps_iso, eng_ready, fabric_ack, save_done, restore_done,
  input  wire [7:0] fault_ev,
  output wire [23:0] chk_o,
  output wire [2:0] st_o, ws_o, pst_o, pws_o,
  output wire acc_o, pacc_o, pfa_o, output wire [7:0] inv_o
);

  reg f_past_valid = 1'b0;
  always @(posedge clk) f_past_valid <= 1'b1;
  wire rst_ni = f_past_valid;                       // reset only in the first cycle

  wire req_ack, req_rej; wire [3:0] rej_code; wire rst_sw, rst_flt;
  wire [2:0] state, dstep, wstep, tfrom, tto;
  wire clk_run, accept, quiesce, cancel, save_req, restore_req, fabric_conn, iso, serving, trans;
  wire [7:0] fault_set, soft_set;

  sf_power_state_fsm #(.ALLOW_GATE(1'b1), .HAS_SRAM(HAS_SRAM), .SRAM_QUAL(SRAM_QUAL), .SAVE_EN(SAVE_EN),
                       .CAN_CANCEL(CAN_CANCEL), .RST_ON_WAKE(RST_ON_WAKE)) dut (
    .clk_i(clk), .rst_ni(rst_ni),
    .cfg_drain_tmo_i(cfg_drain), .cfg_cancel_tmo_i(cfg_cancel), .cfg_wake_tmo_i(cfg_wake), .cfg_dep_tmo_i(cfg_dep),
    .cfg_min_active_i(cfg_minact), .cfg_clk_settle_i(cfg_settle), .cfg_fault_rst_en_i(cfg_frst),
    .cfg_max_auto_rst_i(cfg_maxrst), .fault_clr_i(fault_clr),
    .req_valid_i(req_valid), .req_state_i(req_state), .test_hold_i(test_hold), .auto_idle_i(auto_idle), .wake_ev_i(wake_ev),
    .req_ack_o(req_ack), .req_rej_o(req_rej), .rej_code_o(rej_code),
    .rst_active_i(rst_active), .rst_done_i(rst_done), .rst_fail_i(rst_fail), .rst_pend_i(rst_pend),
    .rst_sw_req_o(rst_sw), .rst_fault_req_o(rst_flt),
    .quiet_i(quiet), .clk_en_i(clk_en), .clk_ok_i(clk_ok), .prov_ready_i(prov_ready), .deps_iso_i(deps_iso),
    .eng_ready_i(eng_ready), .fabric_ack_i(fabric_ack), .save_done_i(save_done), .restore_done_i(restore_done),
    .fault_ev_i(fault_ev),
    .state_o(state), .clk_run_o(clk_run), .accept_o(accept), .quiesce_o(quiesce), .cancel_o(cancel),
    .save_req_o(save_req), .restore_req_o(restore_req), .fabric_conn_o(fabric_conn), .isolated_o(iso), .serving_o(serving),
    .dstep_o(dstep), .wstep_o(wstep), .fault_set_o(fault_set), .soft_set_o(soft_set),
    .trans_o(trans), .trans_from_o(tfrom), .trans_to_o(tto));

  // ------------------------------ environment assumptions ------------------------------
  // a reset sequencer pulses done / fail only while it owns the engine, never both
  always @* if (f_past_valid) begin
    assume(!(rst_done && rst_fail));
    assume(!(rst_done || rst_fail) || rst_active);
  end

  // ------------------------------ history ------------------------------
  reg pprov, pclk_ok;
  reg [2:0] pst; reg pquiet, pacc, psave_done, pfabric_ack, pready, prst_pend, ptest_hold, preq_valid, pfab;
  reg [2:0] preq_state, pwstep; reg [7:0] pfault_set; reg prst_active, pclk_run;
  always @(posedge clk) begin
    pst <= state; pquiet <= quiet; pacc <= accept; psave_done <= save_done; pfabric_ack <= fabric_ack; pready <= eng_ready;
    pprov <= prov_ready; pclk_ok <= clk_ok;
    prst_pend <= rst_pend; ptest_hold <= test_hold; pwstep <= wstep;
    // inputs in the reset cycle are ignored by design, so the request history is gated
    preq_valid <= req_valid & f_past_valid; preq_state <= req_state;
    pfault_set <= fault_set; prst_active <= rst_active & f_past_valid; pfab <= fabric_conn; pclk_run <= clk_run;
  end

  localparam bit SRAM_OK = !HAS_SRAM || SRAM_QUAL || SAVE_EN;

  // each property is a bit of `chk` (1 = holds) so that a counterexample shows which one failed
  reg [23:0] chk;
  assign inv_o = inv;
  assign chk_o = chk; assign st_o = state; assign ws_o = wstep; assign pst_o = pst; assign pws_o = pwstep;
  assign acc_o = accept; assign pacc_o = pacc; assign pfa_o = pfabric_ack;
  always @* begin
    chk = 24'hFFFFFF;
    if (f_past_valid) begin
      // F01 the state code is never the unsupported code
      chk[0] = (state != ST_BAD);
      // F02 every state change is in the legal-transition table
      chk[1] = cw_legal(pst, state);
      // F03 (S1) the clock stops only in CLOCK_DISABLED
      chk[2] = (clk_run || state == ST_CLK_DIS);
      // F04 (S2) CLOCK_DISABLED is entered only from DRAINING with stable quiescence, gate closed (and state saved)
      if (state == ST_CLK_DIS && pst != ST_CLK_DIS)
        chk[3] = (pst == ST_DRAINING && pquiet && !pacc && (!SAVE_EN || psave_done));
      // F05 (S3) the new-work gate is open only in ACTIVE / IDLE_REQUESTED
      chk[4] = (!accept || state == ST_ACTIVE || state == ST_IDLE_REQ);
      // F06 (S3) it reopens only on entry to ACTIVE, with the fabric connected, never in a reset cycle
      if (accept && !pacc) begin
        chk[5] = (state == ST_ACTIVE && fabric_conn && !prst_pend);
        if (pst == ST_WAKE_REQ) chk[6] = (pwstep == W_FABRIC && pfabric_ack);
      end
      // F07 CLOCK_DISABLED: fabric cut, quiesce asserted, gate closed
      if (state == ST_CLK_DIS) chk[7] = (!fabric_conn && quiesce && !accept);
      // F08 (S4) FAULT and RESET keep the clock running, the gate closed, the fabric cut
      if (state == ST_FAULT || state == ST_RESET) chk[8] = (clk_run && !accept && !fabric_conn);
      // F09 DRAINING: gate closed, quiesce asserted
      if (state == ST_DRAINING) chk[9] = (!accept && quiesce);
      // F10 (S6) a request naming an unsupported state is rejected with a code
      if (preq_valid && !(preq_state == ST_ACTIVE || preq_state == ST_CLK_DIS || preq_state == ST_RESET))
        chk[10] = (req_rej && (rej_code == REJ_UNSUPPORTED || rej_code == REJ_STATE));
      // F11 every entry into FAULT records a cause
      if (state == ST_FAULT && pst != ST_FAULT) chk[11] = (pfault_set != 8'h00);
      // F12 (S4) a drain that ends in FAULT never stopped the clock
      if (pst == ST_DRAINING && state == ST_FAULT) chk[12] = (clk_run && pclk_run);
      // F13 the sequencer owning the engine forces RESET
      if (prst_active && pst != ST_RESET) chk[13] = (state == ST_RESET);
      // F14 RESET is left only through WAKE_REQUESTED (done) or FAULT (timeout)
      if (pst == ST_RESET && state != ST_RESET) chk[14] = (state == ST_WAKE_REQ || state == ST_FAULT);
      // F17 wake ordering: the fabric step is entered only after local readiness was seen
      if (state == ST_WAKE_REQ && wstep == W_FABRIC && pst == ST_WAKE_REQ && pwstep == W_READY) chk[16] = pready;
      // F18 wake ordering: the provider step is left only when providers were serving and the clock domain was healthy
      if (state == ST_WAKE_REQ && pst == ST_WAKE_REQ && pwstep == W_PROV && wstep != W_PROV) chk[17] = (pprov && pclk_ok);
      // F15 an engine whose SRAM retention is not qualified never enters IDLE_REQUESTED on its own account
      if (pst == ST_ACTIVE && state == ST_IDLE_REQ && !ptest_hold) chk[15] = SRAM_OK;
    end
  end
  always @* assert(&chk);
  // F16 a request is never both accepted and rejected
  always @* if (f_past_valid) assert(!(req_ack && req_rej));

  // ---------------- helper invariants (state-encoding lemmas, each proved too) ----------------
  // They relate the registered outputs to the state, so that the safety properties above are
  // inductive without enumerating unreachable register combinations.
  reg [7:0] inv;
  always @* begin
    inv = 8'hFF;
    if (f_past_valid) begin
      inv[0] = ((dstep != D_NONE) == (state == ST_DRAINING));
      inv[1] = ((wstep != W_NONE) == (state == ST_WAKE_REQ));
      inv[2] = (!save_req || (state == ST_DRAINING && dstep == D_SAVE)) &&
               (!restore_req || (state == ST_WAKE_REQ && wstep == W_RESTORE));
      inv[3] = (fabric_conn == (state == ST_ACTIVE || state == ST_IDLE_REQ || state == ST_DRAINING ||
                                (state == ST_WAKE_REQ && wstep == W_FABRIC)));
      inv[4] = (clk_run == (state != ST_CLK_DIS));
      inv[5] = (quiesce == (state == ST_DRAINING || state == ST_CLK_DIS || state == ST_WAKE_REQ ||
                            state == ST_RESET || state == ST_FAULT));
      inv[6] = (wstep != 3'd7) && (dstep <= D_SAVE);
    end
  end
  always @* assert(&inv);
endmodule
