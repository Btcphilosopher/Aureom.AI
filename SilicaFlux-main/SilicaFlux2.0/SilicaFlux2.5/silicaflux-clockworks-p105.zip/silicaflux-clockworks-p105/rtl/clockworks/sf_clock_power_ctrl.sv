// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_clock_power_ctrl   (PRIMARY RTL)
//
// Clock, reset, operating-state and test control of the SilicaFlux cloud-compute
// architecture, for ONE functional clock domain and NE engines (reference
// configuration NE = 6: ControlCore, MemoryMatrix, Meridian, StreamDMA,
// TensorCore, PacketForge).
//
//   registers  --> per-engine operating-state FSM  --> clock enable, work gate,
//   (sf_cw_regs)   (sf_power_state_fsm x NE)           quiesce / cancel / save,
//                        ^   |                           DataFabric connect
//        quiescence,     |   v
//        ledger, idle    |  sf_clock_enable_ctrl   --> clk_en_o (registered)
//                        |                              [--> sf_cw_icg_wrap, optional]
//   sf_reset_sequencer  --> eng_rst_no (owner of every engine reset)
//   sf_cw_wdt           --> progress + system watchdog
//   sf_clock_test_adapter <-> DFTGrid / TestCore / MemoryTest
//   sf_activity_counters  --> power-estimate inputs
//
// WHAT THIS IS
//   Portable, synthesizable control RTL.  The baseline mechanism is the
//   synchronous clock ENABLE (clk_en_o): engine flops are written
//   `if (clk_en) q <= d`.  USE_ICG = 1 additionally drives one library ICG per
//   engine through sf_cw_icg_wrap.
//
// WHAT THIS IS NOT
//   * not a clock tree, PLL or clock generator (clk_i is an input)
//   * not a power-gating network: there are NO power switches, isolation cells
//     or retention cells here.  save_req / restore_req are explicit-save HOOKS.
//     The power-domain controls of docs/clockworks/06_POWER_STATES_UPF.md and
//     physical/clockworks/*.upf are templates; PD_SUPPORT is hard-wired 0.
//   * not a scan / ATPG solution (see sf_clock_test_adapter)
//   * not timing- or CDC-signed-off
//
// Single-clock rule: every input other than the four asynchronous pins
// (por_ni, ext_rst_ni, test_rst_ni, pll_lock_i) is synchronous to clk_i.
// Those pins are single-bit and enter only synchronisers or reset
// synchronisers.  No multi-bit value crosses a domain in this block.
//
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_clock_power_ctrl
  import sf_cw_pkg::*;
#(
  parameter int                          NE        = 6,
  parameter int                          NG        = 2,
  parameter int                          OW        = 10,
  parameter int                          EVW       = 4,
  parameter bit                          USE_ICG   = 1'b0,   // 1: drive one ICG per engine (gclk_o)
  parameter bit                          PLL_LOCK_USED = 1'b0,
  // per-engine policy (bit e = engine e).  DEFAULTS ARE CONSERVATIVE: engines that
  // own SRAM may NOT be clock-disabled until the integrator qualifies the macros.
  parameter logic [NE-1:0]               ALLOW_GATE   = {NE{1'b1}},
  parameter logic [NE-1:0]               HAS_SRAM     = CW_REF_HAS_SRAM[NE-1:0],
  parameter logic [NE-1:0]               SRAM_QUAL    = {NE{1'b0}},
  parameter logic [NE-1:0]               SAVE_EN      = {NE{1'b0}},
  parameter logic [NE-1:0]               CAN_CANCEL   = CW_REF_CAN_CANCEL[NE-1:0],
  parameter logic [NE-1:0]               RST_ON_WAKE  = {NE{1'b0}},
  parameter logic [NE-1:0]               LEDGER_EN    = {NE{1'b1}},
  // topology
  parameter logic [CW_MAXE*CW_MAXE-1:0]  DEP_MASK  = CW_REF_DEP,
  parameter logic [2*CW_MAXE-1:0]        REL_RANK  = CW_REF_RANK,
  // test
  parameter logic [NG*CW_MAXE-1:0]       GRP_ENG   = CW_REF_GRP,
  parameter logic [CW_MAXE-1:0]          DIAG_ENG  = 8'h02,
  parameter bit                          TE_FOLLOWS_SCAN_EN = 1'b0,
  parameter int                          DAW       = 32,
  parameter int                          DDW       = 64
) (
  input  wire logic                 clk_i,
  // ---- asynchronous single-bit pins ------------------------------------------------
  input  wire logic                 por_ni,
  input  wire logic                 ext_rst_ni,
  input  wire logic                 pll_lock_i,
  // ---- clock-domain health, synchronous (e.g. P35 clock monitor, after its own CDC) ---
  input  wire logic                 clk_ok_i,

  // ---- register / command bus -----------------------------------------------------------
  input  wire logic                 reg_valid_i,
  input  wire logic                 reg_we_i,
  input  wire logic [11:0]          reg_addr_i,
  input  wire logic [31:0]          reg_wdata_i,
  output logic                      reg_ready_o,
  output logic [31:0]               reg_rdata_o,
  output logic                      reg_err_o,
  output logic                      irq_o,

  // ---- engine interface: status from the engines ---------------------------------------
  input  wire logic [NE-1:0]        eng_ready_i,       // local readiness (after reset / wake)
  input  wire logic [NE-1:0]        eng_idle_i,        // engine-internal idle
  input  wire logic [NE-1:0]        eng_obuf_empty_i,  // output buffers / response FIFOs empty
  input  wire logic [NE-1:0]        eng_dma_idle_i,    // no DMA / completion record outstanding
  input  wire logic [NE-1:0]        eng_mem_idle_i,    // memory interface idle
  input  wire logic [NE-1:0]        eng_err_i,         // fatal error
  input  wire logic [NE-1:0]        eng_wake_req_i,    // engine wants its clock (interrupt, timer)
  input  wire logic [NE-1:0]        eng_save_done_i,
  input  wire logic [NE-1:0]        eng_restore_done_i,
  input  wire logic [NE-1:0]        up_stalled_i,      // upstream valid held back by the closed gate
  input  wire logic [NE-1:0]        in_offered_i,      // transfer offered at the engine input
  input  wire logic [NE-1:0]        fabric_ack_i,      // DataFabric port connected
  input  wire logic [NE*EVW-1:0]    issue_cnt_i,
  input  wire logic [NE*EVW-1:0]    retire_cnt_i,

  // ---- engine interface: controls to the engines -----------------------------------------
  output logic [NE-1:0]             clk_en_o,          // synchronous clock enable (registered)
  output logic [NE-1:0]             gclk_o,            // gated clocks if USE_ICG, else clk_i
  output logic [NE-1:0]             accept_en_o,       // new-work gate
  output logic [NE-1:0]             quiesce_req_o,
  output logic [NE-1:0]             cancel_o,
  output logic [NE-1:0]             save_req_o,
  output logic [NE-1:0]             restore_req_o,
  output logic [NE-1:0]             fabric_connect_o,
  output logic [NE-1:0]             eng_rst_no,
  output logic [NE-1:0]             mem_inhibit_o,
  output logic [NE*3-1:0]           eng_state_o,

  // ---- test / DFT (TestCore P07, DFTGrid P39, MemoryTest P78) ----------------------------
  input  wire logic                 test_permit_i,
  input  wire logic                 scan_mode_i,
  input  wire logic                 scan_en_i,
  input  wire logic                 icg_te_i,
  input  wire logic                 test_rst_ni,
  input  wire logic                 mem_inhibit_i,
  input  wire logic [2:0]           tc_mode_i,
  input  wire logic [NG-1:0]        dft_quiesce_req_i,
  input  wire logic [NG-1:0]        dft_f_block_i,
  input  wire logic [NG-1:0]        dft_mbist_clk_req_i,
  output logic [NG-1:0]             dft_quiesce_ack_o,
  output logic [NG-1:0]             dft_f_busy_o,
  output logic [NG-1:0]             dft_f_req_o,
  output logic                      cg_test_en_o,
  output logic                      scan_en_o,
  output logic                      mbist_start_o,
  output logic                      mbist_abort_o,
  output logic                      mbist_test_mode_o,
  output logic                      mbist_permit_o,
  output logic                      mbist_cpu_halted_o,
  input  wire logic                 mbist_busy_i,
  input  wire logic                 mbist_done_i,
  input  wire logic                 mbist_pass_i,
  input  wire logic                 mbist_fail_i,
  input  wire logic                 mbist_err_i,
  input  wire logic                 diag_req_valid_i,
  input  wire logic                 diag_req_we_i,
  input  wire logic [DAW-1:0]       diag_req_addr_i,
  input  wire logic [DDW-1:0]       diag_req_wdata_i,
  output logic                      diag_req_ready_o,
  output logic                      diag_rsp_valid_o,
  output logic [DDW-1:0]            diag_rsp_rdata_o,
  output logic                      diag_rsp_err_o,
  output logic                      mem_diag_valid_o,
  output logic                      mem_diag_we_o,
  output logic [DAW-1:0]            mem_diag_addr_o,
  output logic [DDW-1:0]            mem_diag_wdata_o,
  input  wire logic                 mem_diag_ready_i,
  input  wire logic                 mem_diag_rvalid_i,
  input  wire logic [DDW-1:0]       mem_diag_rdata_i,
  input  wire logic                 mem_diag_rerr_i,

  // ---- status ---------------------------------------------------------------------------
  output logic [31:0]               jtag_status_o      // same layout as the STATUS register
);

  // ---------------------------------------------------------------------------
  // elaboration checks
  // ---------------------------------------------------------------------------
  generate
    if (NE > 8 || NE < 1) begin : g_chk_ne
      $error("sf_clock_power_ctrl: NE must be 1..8");
    end
    if (!cw_rank_consistent(DEP_MASK, REL_RANK)) begin : g_chk_rank
      $error("sf_clock_power_ctrl: REL_RANK must release every provider before its dependents");
    end
  endgenerate

  localparam logic [CW_MAXE*CW_MAXE-1:0] CLOS = cw_closure_all(DEP_MASK);

  // ---------------------------------------------------------------------------
  // clock-domain status
  // ---------------------------------------------------------------------------
  logic rst_n;               // controller reset, synchronous release (sequencer)
  logic pll_s, clk_dom_ok, clk_seen_q, clk_loss;

  sf_sync2 #(.RESET_VAL(1'b0)) u_pll_sync (.clk(clk_i), .rst_n(rst_n), .d(pll_lock_i), .q(pll_s));

  assign clk_dom_ok = (PLL_LOCK_USED ? pll_s : 1'b1) & clk_ok_i;
  assign clk_loss   = clk_seen_q & ~clk_dom_ok;

  always_ff @(posedge clk_i or negedge rst_n) begin
    if (!rst_n)           clk_seen_q <= 1'b0;
    else if (clk_dom_ok)  clk_seen_q <= 1'b1;
  end

  // ---------------------------------------------------------------------------
  // internal vectors
  // ---------------------------------------------------------------------------
  // register file
  logic                 r_en, r_wdt_en, r_wdt_rst_en, r_glob_rst, r_cnt_clr, r_snap, r_fclr, r_kick;
  logic [31:0]          r_wdt_lim;
  logic [7:0]           r_hold, r_stable, r_settle;
  logic [15:0]          r_rtmo;
  logic [NE-1:0]        r_auto_idle, r_fault_rst, r_wdt_e, r_wake_e;
  logic [NE*4-1:0]      r_max_arst;
  logic [NE*NQ-1:0]     r_qmask;
  logic [NE*8-1:0]      r_qcyc;
  logic [NE*16-1:0]     r_tdrain, r_tcancel, r_twake, r_tdep, r_minact;
  logic [NE*24-1:0]     r_idle_thr, r_wdt_limit;
  logic [NE-1:0]        r_req_v;
  logic [NE*3-1:0]      r_req_s;
  logic                 r_mb_start, r_mb_abort;
  logic [NE-1:0]        r_mb_mask;
  logic [15:0]          r_mb_tmo;
  logic [NE*8-1:0]      r_cause_clr;

  // FSMs
  logic [NE-1:0]        f_clk_run, f_accept, f_quiesce, f_cancel, f_save, f_restore, f_fabric;
  logic [NE-1:0]        f_iso, f_serving, f_trans, f_ack, f_rej, f_rst_sw, f_rst_fault;
  logic [NE*3-1:0]      f_state, f_dstep, f_wstep, f_from, f_to;
  logic [NE*4-1:0]      f_rejcode;
  logic [NE*8-1:0]      f_fault_set, f_soft_set;

  // enable controller
  logic [NE-1:0]        ec_clk_en, ec_accept, ec_quiet, ec_wake, ec_auto, ec_act, ec_ilk;
  logic [NE*OW-1:0]     ec_out;
  logic [NE*NQ-1:0]     ec_q;
  logic [NE*8-1:0]      ec_fault;

  // reset sequencer
  logic [NE-1:0]        rs_active, rs_done, rs_fail, rs_force, rs_event, rs_pend;
  logic [NE*8-1:0]      rs_cause;
  logic [NE*16-1:0]     rs_cnt;

  // watchdog
  logic [NE-1:0]        wd_exp;
  logic                 wd_sys_irq, wd_sys_rst;

  // test adapter
  logic                 ta_scan_eff, ta_scan_act, ta_cgte;
  logic [NE-1:0]        ta_hold, ta_force, ta_block, ta_inhibit;
  logic [3:0]           ta_mb_res;
  logic [2:0]           ta_mb_state;
  logic                 ta_mb_busy, ta_diag_mode;
  logic [7:0]           ta_ev;

  // counters
  logic [NE*NMET*32-1:0] ct_live, ct_snap;
  logic [63:0]          ct_cyc, ct_cyc_snap;

  // dependency-derived
  logic [NE-1:0]        prov_ready, deps_iso, casc, want_wake, hold_eff;
  always_comb begin
    for (int e = 0; e < NE; e++) begin
      want_wake[e] = (f_state[e*3 +: 3] == ST_WAKE_REQ);
      prov_ready[e] = 1'b1;
      deps_iso[e]   = 1'b1;
      casc[e]       = 1'b0;
      hold_eff[e]   = 1'b0;
    end
    for (int e = 0; e < NE; e++) begin
      for (int p = 0; p < NE; p++) begin
        // engine e requires provider p: e may only run while p is serving
        if (DEP_MASK[e*CW_MAXE + p]) begin
          prov_ready[e] = prov_ready[e] & f_serving[p];
          // p may only stop when every such e is isolated; a waking e wakes p
          deps_iso[p]   = deps_iso[p] & f_iso[e];
          casc[p]       = casc[p] | want_wake[e];
        end
        // a test hold on p is also a hold on everything that transitively requires p
        if (CLOS[p*CW_MAXE + e] && ta_hold[p]) hold_eff[e] = 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // register file
  // ---------------------------------------------------------------------------
  localparam logic [31:0] CAP_W   = {12'd0, 4'(OW), 4'(NG), 1'b1, (|SAVE_EN), 1'b0, USE_ICG, 8'(NE)};
  localparam logic [31:0] CAPS_W  = {8'(LEDGER_EN), 8'(SAVE_EN), 8'(SRAM_QUAL), 8'(HAS_SRAM)};
  localparam logic [31:0] CAPP_W  = {8'd0, 8'(RST_ON_WAKE), 8'(CAN_CANCEL), 8'(ALLOW_GATE)};

  sf_cw_regs #(.NE(NE), .OW(OW)) u_regs (
    .clk_i, .rst_ni(rst_n),
    .reg_valid_i, .reg_we_i, .reg_addr_i, .reg_wdata_i, .reg_ready_o, .reg_rdata_o, .reg_err_o, .irq_o,
    .cap_i(CAP_W), .cap_sram_i(CAPS_W), .cap_pol_i(CAPP_W),
    .en_o(r_en), .sys_wdt_en_o(r_wdt_en), .sys_wdt_rst_en_o(r_wdt_rst_en), .sys_wdt_limit_o(r_wdt_lim),
    .glob_rst_req_o(r_glob_rst), .cnt_clr_o(r_cnt_clr), .snap_o(r_snap), .fault_clr_o(r_fclr), .wdt_kick_o(r_kick),
    .cfg_hold_o(r_hold), .cfg_rdy_stable_o(r_stable), .cfg_ready_tmo_o(r_rtmo), .cfg_clk_settle_o(r_settle),
    .cfg_auto_idle_en_o(r_auto_idle), .cfg_fault_rst_en_o(r_fault_rst), .cfg_wdt_en_o(r_wdt_e), .cfg_wake_en_o(r_wake_e),
    .cfg_max_auto_rst_o(r_max_arst), .cfg_qmask_o(r_qmask), .cfg_quiet_cyc_o(r_qcyc),
    .cfg_drain_tmo_o(r_tdrain), .cfg_cancel_tmo_o(r_tcancel), .cfg_wake_tmo_o(r_twake), .cfg_dep_tmo_o(r_tdep),
    .cfg_min_active_o(r_minact), .cfg_idle_thr_o(r_idle_thr), .cfg_wdt_limit_o(r_wdt_limit),
    .req_valid_o(r_req_v), .req_state_o(r_req_s), .req_ack_i(f_ack), .req_rej_i(f_rej), .rej_code_i(f_rejcode),
    .state_i(f_state), .dstep_i(f_dstep), .wstep_i(f_wstep), .clk_en_i(ec_clk_en), .accept_i(ec_accept),
    .fabric_i(f_fabric), .quiet_i(ec_quiet), .quiesce_i(f_quiesce), .save_i(f_save), .restore_i(f_restore),
    .rst_active_i(rs_active), .rst_done_i(rs_done), .ilk_i(ec_ilk), .stalled_i(up_stalled_i), .ready_i(eng_ready_i),
    .qvec_i(ec_q), .out_i(ec_out), .fault_set_i(f_fault_set), .soft_set_i(f_soft_set),
    .rst_cause_i(rs_cause), .rst_cnt_i(rs_cnt), .rst_cause_clr_o(r_cause_clr),
    .clk_ok_i(clk_dom_ok), .pll_lock_i(pll_s), .clk_loss_seen_i(clk_loss), .scan_active_i(ta_scan_act),
    .mbist_busy_i(ta_mb_busy), .sys_wdt_irq_i(wd_sys_irq), .tc_mode_i, .mbist_result_i(ta_mb_res),
    .mbist_state_i(ta_mb_state), .test_ev_set_i(ta_ev),
    .mbist_start_o(r_mb_start), .mbist_abort_o(r_mb_abort), .mbist_mask_o(r_mb_mask), .mbist_tmo_o(r_mb_tmo),
    .snap_cnt_i(ct_snap), .cyc_snap_i(ct_cyc_snap)
  );

  // ---------------------------------------------------------------------------
  // per-engine operating-state FSMs
  // ---------------------------------------------------------------------------
  genvar e;
  generate
    for (e = 0; e < NE; e++) begin : g_fsm
      sf_power_state_fsm #(
        .ALLOW_GATE (ALLOW_GATE[e]),
        .HAS_SRAM   (HAS_SRAM[e]),
        .SRAM_QUAL  (SRAM_QUAL[e]),
        .SAVE_EN    (SAVE_EN[e]),
        .CAN_CANCEL (CAN_CANCEL[e]),
        .RST_ON_WAKE(RST_ON_WAKE[e])
      ) u_fsm (
        .clk_i, .rst_ni(rst_n),
        .cfg_drain_tmo_i (r_tdrain [e*16 +: 16]),
        .cfg_cancel_tmo_i(r_tcancel[e*16 +: 16]),
        .cfg_wake_tmo_i  (r_twake  [e*16 +: 16]),
        .cfg_dep_tmo_i   (r_tdep   [e*16 +: 16]),
        .cfg_min_active_i(r_minact [e*16 +: 16]),
        .cfg_clk_settle_i(r_settle),
        .cfg_fault_rst_en_i(r_fault_rst[e]),
        .cfg_max_auto_rst_i(r_max_arst[e*4 +: 4]),
        .fault_clr_i(r_fclr),
        .req_valid_i(r_req_v[e]), .req_state_i(r_req_s[e*3 +: 3]),
        .test_hold_i(hold_eff[e]),
        .auto_idle_i(ec_auto[e]),
        .wake_ev_i(ec_wake[e] | casc[e]),
        .req_ack_o(f_ack[e]), .req_rej_o(f_rej[e]), .rej_code_o(f_rejcode[e*4 +: 4]),
        .rst_active_i(rs_active[e]), .rst_done_i(rs_done[e]), .rst_fail_i(rs_fail[e]), .rst_pend_i(rs_pend[e]),
        .rst_sw_req_o(f_rst_sw[e]), .rst_fault_req_o(f_rst_fault[e]),
        .quiet_i(ec_quiet[e]), .clk_en_i(ec_clk_en[e]), .clk_ok_i(clk_dom_ok),
        .prov_ready_i(prov_ready[e]), .deps_iso_i(deps_iso[e]),
        .eng_ready_i(eng_ready_i[e]), .fabric_ack_i(fabric_ack_i[e]),
        .save_done_i(eng_save_done_i[e]), .restore_done_i(eng_restore_done_i[e]),
        .fault_ev_i(ec_fault[e*8 +: 8]),
        .state_o(f_state[e*3 +: 3]),
        .clk_run_o(f_clk_run[e]), .accept_o(f_accept[e]), .quiesce_o(f_quiesce[e]), .cancel_o(f_cancel[e]),
        .save_req_o(f_save[e]), .restore_req_o(f_restore[e]), .fabric_conn_o(f_fabric[e]),
        .isolated_o(f_iso[e]), .serving_o(f_serving[e]),
        .dstep_o(f_dstep[e*3 +: 3]), .wstep_o(f_wstep[e*3 +: 3]),
        .fault_set_o(f_fault_set[e*8 +: 8]), .soft_set_o(f_soft_set[e*8 +: 8]),
        .trans_o(f_trans[e]), .trans_from_o(f_from[e*3 +: 3]), .trans_to_o(f_to[e*3 +: 3])
      );
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // clock-enable controller
  // ---------------------------------------------------------------------------
  sf_clock_enable_ctrl #(.NE(NE), .OW(OW), .EVW(EVW), .LEDGER_EN(LEDGER_EN)) u_ec (
    .clk_i, .rst_ni(rst_n),
    .clk_run_i(f_clk_run), .accept_fsm_i(f_accept), .rst_clk_force_i(rs_force),
    .test_clk_force_i(ta_force), .test_en_i(ta_cgte), .f_block_i(ta_block),
    .cfg_quiet_cyc_i(r_qcyc), .cfg_idle_thr_i(r_idle_thr), .cfg_qmask_i(r_qmask),
    .cfg_auto_idle_en_i(r_auto_idle), .cfg_wake_en_i(r_wake_e), .clk_loss_i(clk_loss),
    .eng_idle_i, .eng_obuf_empty_i, .eng_dma_idle_i, .eng_mem_idle_i, .eng_err_i, .eng_wake_req_i,
    .up_stalled_i, .in_offered_i, .issue_cnt_i, .retire_cnt_i,
    .clk_en_o(ec_clk_en), .accept_en_o(ec_accept), .quiet_o(ec_quiet), .wake_ev_o(ec_wake),
    .auto_idle_o(ec_auto), .act_o(ec_act), .outstanding_o(ec_out), .q_vec_o(ec_q),
    .fault_ev_o(ec_fault), .ilk_hit_o(ec_ilk)
  );

  // ---------------------------------------------------------------------------
  // reset sequencer (owner of every engine reset)
  // ---------------------------------------------------------------------------
  sf_reset_sequencer #(.NE(NE), .DEP_MASK(DEP_MASK), .REL_RANK(REL_RANK)) u_rs (
    .clk_i, .por_ni, .ext_rst_ni, .test_mode_i(ta_scan_eff), .test_rst_ni,
    .glob_rst_req_i(r_glob_rst), .sub_rst_req_i(f_rst_sw), .wdt_rst_req_i(wd_exp),
    .fault_rst_req_i(f_rst_fault), .sys_wdt_rst_i(wd_sys_rst), .test_rst_hold_i(ta_scan_act),
    .iso_i(f_iso), .eng_ready_i, .clk_en_fb_i(ec_clk_en), .clk_ok_i(clk_dom_ok),
    .cfg_hold_i(r_hold), .cfg_ready_tmo_i(r_rtmo), .cfg_rdy_stable_i(r_stable), .cause_clr_i(r_cause_clr),
    .sys_rst_no(rst_n), .eng_rst_no,
    .rst_active_o(rs_active), .rst_done_o(rs_done), .rst_fail_o(rs_fail), .rst_clk_force_o(rs_force),
    .rst_event_o(rs_event), .rst_pend_o(rs_pend), .cause_o(rs_cause), .rst_cnt_o(rs_cnt)
  );

  // ---------------------------------------------------------------------------
  // watchdogs
  // ---------------------------------------------------------------------------
  logic [NE-1:0] wd_act, wd_prog;
  always_comb begin
    for (int i = 0; i < NE; i++) begin
      wd_act[i]  = (f_state[i*3 +: 3] == ST_ACTIVE) && ec_act[i];
      wd_prog[i] = |retire_cnt_i[i*EVW +: EVW];
    end
  end

  sf_cw_wdt #(.NE(NE)) u_wdt (
    .clk_i, .rst_ni(rst_n),
    .cfg_en_i(r_wdt_e), .cfg_limit_i(r_wdt_limit), .act_i(wd_act), .prog_i(wd_prog), .exp_o(wd_exp),
    .sys_en_i(r_wdt_en), .sys_limit_i(r_wdt_lim), .sys_kick_i(r_kick), .sys_rst_en_i(r_wdt_rst_en),
    .sys_irq_o(wd_sys_irq), .sys_rst_o(wd_sys_rst)
  );

  // ---------------------------------------------------------------------------
  // test adapter
  // ---------------------------------------------------------------------------
  logic [NE-1:0] ta_quiesced, ta_active, ta_bad, ta_stalled;
  always_comb begin
    for (int i = 0; i < NE; i++) begin
      ta_quiesced[i] = (f_state[i*3 +: 3] == ST_CLK_DIS);
      ta_active[i]   = (f_state[i*3 +: 3] == ST_ACTIVE);
      ta_bad[i]      = (f_state[i*3 +: 3] == ST_RESET) || (f_state[i*3 +: 3] == ST_FAULT);
      ta_stalled[i]  = up_stalled_i[i] | in_offered_i[i];
    end
  end

  sf_clock_test_adapter #(
    .NE(NE), .NG(NG), .GRP_ENG(GRP_ENG), .DIAG_ENG(DIAG_ENG), .TE_FOLLOWS_SCAN_EN(TE_FOLLOWS_SCAN_EN),
    .DAW(DAW), .DDW(DDW)
  ) u_ta (
    .clk_i, .rst_ni(rst_n),
    .test_permit_i, .scan_mode_i, .scan_en_i, .icg_te_i, .mem_inhibit_i, .tc_mode_i,
    .dft_quiesce_req_i, .dft_f_block_i, .dft_mbist_clk_req_i,
    .dft_quiesce_ack_o, .dft_f_busy_o, .dft_f_req_o,
    .scan_mode_eff_o(ta_scan_eff), .scan_active_o(ta_scan_act), .cg_test_en_o(ta_cgte), .scan_en_o,
    .test_hold_o(ta_hold), .test_clk_force_o(ta_force), .f_block_o(ta_block), .mem_inhibit_o(ta_inhibit),
    .eng_quiesced_i(ta_quiesced), .eng_active_i(ta_active), .eng_bad_i(ta_bad), .eng_busy_i(ec_act),
    .eng_stalled_i(ta_stalled),
    .mbist_cmd_start_i(r_mb_start), .mbist_cmd_abort_i(r_mb_abort), .mbist_eng_mask_i(r_mb_mask),
    .cfg_mbist_tmo_i(r_mb_tmo),
    .mbist_start_o, .mbist_abort_o, .mbist_test_mode_o, .mbist_permit_o, .mbist_cpu_halted_o,
    .mbist_busy_i, .mbist_done_i, .mbist_pass_i, .mbist_fail_i, .mbist_err_i,
    .mbist_result_o(ta_mb_res), .mbist_state_o(ta_mb_state), .mbist_busy_o(ta_mb_busy),
    .diag_req_valid_i, .diag_req_we_i, .diag_req_addr_i, .diag_req_wdata_i, .diag_req_ready_o,
    .diag_rsp_valid_o, .diag_rsp_rdata_o, .diag_rsp_err_o,
    .mem_diag_valid_o, .mem_diag_we_o, .mem_diag_addr_o, .mem_diag_wdata_o, .mem_diag_ready_i,
    .mem_diag_rvalid_i, .mem_diag_rdata_i, .mem_diag_rerr_i, .diag_mode_o(ta_diag_mode),
    .ev_o(ta_ev)
  );

  // ---------------------------------------------------------------------------
  // activity counters
  // ---------------------------------------------------------------------------
  sf_activity_counters #(.NE(NE), .OW(OW)) u_cnt (
    .clk_i, .rst_ni(rst_n), .clr_i(r_cnt_clr), .snap_i(r_snap),
    .clk_en_i(ec_clk_en), .act_i(ec_act), .trans_i(f_trans), .from_i(f_from), .to_i(f_to),
    .out_i(ec_out), .rst_event_i(rs_event), .cancel_i(f_cancel),
    .cnt_o(ct_live), .snap_o(ct_snap), .cyc_o(ct_cyc), .cyc_snap_o(ct_cyc_snap)
  );

  // ---------------------------------------------------------------------------
  // optional integrated clock gates (the ONLY place a clock is gated)
  // ---------------------------------------------------------------------------
  generate
    if (USE_ICG) begin : g_icg
      sf_cw_icg_wrap #(.NE(NE)) u_icg (.clk_i, .en_i(ec_clk_en), .te_i(ta_cgte), .gclk_o);
    end else begin : g_noicg
      assign gclk_o = {NE{clk_i}};
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // outputs
  // ---------------------------------------------------------------------------
  assign clk_en_o         = ec_clk_en;
  assign accept_en_o      = ec_accept;
  assign quiesce_req_o    = f_quiesce;
  assign cancel_o         = f_cancel;
  assign save_req_o       = f_save;
  assign restore_req_o    = f_restore;
  assign fabric_connect_o = f_fabric;
  assign mem_inhibit_o    = ta_inhibit;
  assign cg_test_en_o     = ta_cgte;
  assign eng_state_o      = f_state;

  logic [NE-1:0] any_fault_v;
  always_comb for (int i = 0; i < NE; i++) any_fault_v[i] = (f_state[i*3 +: 3] == ST_FAULT);
  assign jtag_status_o = {5'd0, tc_mode_i, 8'd0, 8'(ec_clk_en),
                          clk_seen_q & ~clk_dom_ok ? 1'b1 : 1'b0, wd_sys_irq, ta_mb_busy, ta_scan_act,
                          (|rs_active), (|any_fault_v), pll_s, clk_dom_ok};

  // Intentionally unused here: ta_diag_mode is informational; r_en is consumed inside
  // sf_cw_regs (policy gate); the live counters are for simulation probes / the
  // activity exporter (the register file reads the snapshot copy).
  logic unused_ok;
  assign unused_ok = &{1'b0, ta_diag_mode, r_en, (|ct_live), (|ct_cyc), 1'b0};

endmodule

`default_nettype wire
