// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_reset_sequencer
//
// OWNER of every reset in the controlled domain.  Nothing else may drive an
// engine reset input.  (docs/clockworks/04_RESET_ARCHITECTURE.md)
//
//   reset sources                    scope                         cause bit
//   por_ni, ext_rst_ni  (async pins) controller + all engines      RC_POR_EXT
//   glob_rst_req_i      (software)   all engines                   RC_GLOBAL_SW
//   sub_rst_req_i[e]    (FSM)        engine e (+closure)           RC_SUBSYS
//   wdt_rst_req_i[e]    (watchdog)   engine e (+closure)           RC_WDT
//   sys_wdt_rst_i       (watchdog)   all engines                   RC_SYS_WDT
//   fault_rst_req_i[e]  (FSM)        engine e (+closure)           RC_FAULT
//   test_rst_hold_i     (test, level)all engines                   RC_TEST
//   collateral                       dependents of a reset provider RC_CLOSURE
//
// Reset path discipline (docs 04, rules R1-R6):
//   R1  every engine reset is ONE flop (req_q) -> reset synchroniser: async
//       assertion, synchronous release; no decoded logic in a reset path
//       (the defect recorded as audit finding F-04 in P35)
//   R2  req_q is itself asynchronously SET by the controller reset, so POR /
//       external reset reaches every engine reset with no clock running
//   R3  the clock of an engine in reset is forced ON (rst_clk_force_o) and the
//       hold time counts clock edges DELIVERED to the engine (clk_en_fb_i)
//   R4  release is acknowledged: the sequencer observes the synchroniser output
//       (eng_rst_no) before it waits for local readiness
//   R5  release is ordered by rank (providers first); a failed provider blocks
//       its dependents, which then fail explicitly by timeout
//   R6  a forced reset also resets every NON-ISOLATED dependent (closure), so no
//       master is left holding a transaction to an engine that lost its state
//
// Per-engine sequence:  RUN -> ASSERT -> HOLD -> WAIT -> REL -> RDY -> DONE|FAIL
//
// Classification: SYNTHESIZABLE.  Uses the unmodified P40 sf_reset_sync.
// =============================================================================
`default_nettype none

module sf_reset_sequencer
  import sf_cw_pkg::*;
#(
  parameter int                                 NE       = 6,
  parameter logic [CW_MAXE*CW_MAXE-1:0]         DEP_MASK = CW_REF_DEP,
  parameter logic [2*CW_MAXE-1:0]               REL_RANK = CW_REF_RANK
) (
  input  wire logic                 clk_i,
  // ---- asynchronous single-bit pins (must be glitch-free) --------------------
  input  wire logic                 por_ni,
  input  wire logic                 ext_rst_ni,
  input  wire logic                 test_mode_i,      // static; reset synchronisers pass test_rst_ni
  input  wire logic                 test_rst_ni,
  // ---- synchronous requests (clk_i) -----------------------------------------
  input  wire logic                 glob_rst_req_i,
  input  wire logic [NE-1:0]        sub_rst_req_i,
  input  wire logic [NE-1:0]        wdt_rst_req_i,
  input  wire logic [NE-1:0]        fault_rst_req_i,
  input  wire logic                 sys_wdt_rst_i,
  input  wire logic                 test_rst_hold_i,
  input  wire logic [NE-1:0]        iso_i,            // engine isolated (CLOCK_DISABLED/RESET/FAULT)
  input  wire logic [NE-1:0]        eng_ready_i,
  input  wire logic [NE-1:0]        clk_en_fb_i,
  input  wire logic                 clk_ok_i,
  // ---- configuration ----------------------------------------------------------
  input  wire logic [7:0]           cfg_hold_i,       // clock edges with reset asserted (min 2)
  input  wire logic [15:0]          cfg_ready_tmo_i,  // 0 = 65535
  input  wire logic [7:0]           cfg_rdy_stable_i, // consecutive ready cycles (min 1)
  input  wire logic [NE*8-1:0]      cause_clr_i,      // W1C
  // ---- outputs -------------------------------------------------------------------
  output logic                      sys_rst_no,       // controller reset, released synchronously
  output logic [NE-1:0]             eng_rst_no,       // engine resets (to engines)
  output logic [NE-1:0]             rst_active_o,
  output logic [NE-1:0]             rst_done_o,       // pulse, last active cycle
  output logic [NE-1:0]             rst_fail_o,       // pulse, last active cycle
  output logic [NE-1:0]             rst_clk_force_o,
  output logic [NE-1:0]             rst_event_o,      // pulse: a new sequence started
  output logic [NE-1:0]             rst_pend_o,       // comb: a request is taken this cycle (engine reset asserts at the edge)
  output logic [NE*8-1:0]           cause_o,          // sticky RC_* bits
  output logic [NE*16-1:0]          rst_cnt_o
);

  // ---------------------------------------------------------------------------
  // controller reset: async assert (pins), synchronous release
  // ---------------------------------------------------------------------------
  logic sys_arst_n;
  assign sys_arst_n = test_mode_i ? test_rst_ni : (por_ni & ext_rst_ni);

  sf_reset_sync u_rs_sys (
    .clk       (clk_i),
    .arst_n    (sys_arst_n),
    .test_mode (test_mode_i),
    .rst_n_sync(sys_rst_no)
  );

  // closure[e] = e + everything that transitively requires e;  lower[e] = ranks released before e
  localparam logic [CW_MAXE*CW_MAXE-1:0] CLOS  = cw_closure_all(DEP_MASK);
  localparam logic [CW_MAXE*CW_MAXE-1:0] LOWER = cw_lower_all(REL_RANK);

  // ---------------------------------------------------------------------------
  // per-engine state
  // ---------------------------------------------------------------------------
  localparam logic [2:0] R_RUN = 3'd0, R_ASSERT = 3'd1, R_HOLD = 3'd2, R_WAIT = 3'd3,
                         R_REL = 3'd4, R_RDY = 3'd5, R_DONE = 3'd6, R_FAIL = 3'd7;

  logic [NE-1:0]  req_q, req_d;            // 1 = reset requested (the one flop of rule R1)
  logic [2:0]     rs_q [NE];
  logic [2:0]     rs_d [NE];
  logic [17:0]    rt_q [NE];
  logic [17:0]    rt_d [NE];
  logic [7:0]     rdy_q [NE];
  logic [7:0]     rdy_d [NE];
  logic [NE-1:0]  fail_q, fail_d;
  logic [NE-1:0]  ev_d;
  logic [7:0]     cause_q [NE];
  logic [15:0]    cnt_q [NE];
  logic [NE-1:0]  rst_n_fb;

  // ---------------------------------------------------------------------------
  // request collection
  // ---------------------------------------------------------------------------
  logic [NE-1:0] own_req;                  // requests that trigger closure
  logic [7:0]    rq_cause [NE];
  logic [NE-1:0] rq_any;

  always_comb begin
    for (int e = 0; e < NE; e++) own_req[e] = sub_rst_req_i[e] | wdt_rst_req_i[e] | fault_rst_req_i[e];
    for (int e = 0; e < NE; e++) begin
      rq_cause[e]               = 8'h00;
      rq_cause[e][RC_GLOBAL_SW] = glob_rst_req_i;
      rq_cause[e][RC_SUBSYS]    = sub_rst_req_i[e];
      rq_cause[e][RC_WDT]       = wdt_rst_req_i[e];
      rq_cause[e][RC_SYS_WDT]   = sys_wdt_rst_i;
      rq_cause[e][RC_FAULT]     = fault_rst_req_i[e];
      rq_cause[e][RC_TEST]      = test_rst_hold_i;
      // collateral (rule R6): dependents of a resetting engine that are not isolated
      for (int p = 0; p < NE; p++) begin
        if (p != e && own_req[p] && CLOS[p*CW_MAXE + e] && !iso_i[e])
          rq_cause[e][RC_CLOSURE] = 1'b1;
      end
      rq_any[e] = |rq_cause[e];
    end
  end

  // lower-rank engines still resetting, or failed, block the release of e
  logic [NE-1:0] blocked;
  always_comb begin
    for (int e = 0; e < NE; e++) begin
      blocked[e] = 1'b0;
      for (int k = 0; k < NE; k++)
        if (LOWER[e*CW_MAXE + k] && ((rs_q[k] != R_RUN) || fail_q[k])) blocked[e] = 1'b1;
    end
  end

  // ---------------------------------------------------------------------------
  // limits
  // ---------------------------------------------------------------------------
  logic [7:0]  hold_lim, stable_lim;
  logic [17:0] rdy_lim, wait_lim;
  assign hold_lim   = (cfg_hold_i < 8'd2) ? 8'd2 : cfg_hold_i;
  assign stable_lim = (cfg_rdy_stable_i == 8'd0) ? 8'd1 : cfg_rdy_stable_i;
  assign rdy_lim    = (cfg_ready_tmo_i == 16'd0) ? 18'd65535 : {2'b00, cfg_ready_tmo_i};
  assign wait_lim   = {rdy_lim[15:0], 2'b00};     // x4: a provider chain has to finish first

  // ---------------------------------------------------------------------------
  // next state
  // ---------------------------------------------------------------------------
  always_comb begin
    req_d  = req_q;
    fail_d = fail_q;
    ev_d   = '0;
    for (int e = 0; e < NE; e++) begin
      rs_d[e]  = rs_q[e];
      rt_d[e]  = (rt_q[e] == 18'h3FFFF) ? rt_q[e] : (rt_q[e] + 18'd1);
      rdy_d[e] = rdy_q[e];

      if (rq_any[e]) begin
        // (re)start; asserting again is idempotent
        ev_d[e]  = (rs_q[e] == R_RUN);
        rs_d[e]  = R_ASSERT;
        req_d[e] = 1'b1;
        rt_d[e]  = 18'd0;
        rdy_d[e] = 8'd0;
        fail_d[e]= 1'b0;
      end else begin
        case (rs_q[e])
          R_RUN: ;
          R_ASSERT: begin rs_d[e] = R_HOLD; rt_d[e] = 18'd0; end
          R_HOLD: begin
            // count clock edges delivered while the reset is really asserted (R3)
            if (!rst_n_fb[e] && clk_en_fb_i[e]) begin
              rt_d[e] = rt_q[e] + 18'd1;
              if (rt_q[e] + 18'd1 >= {10'd0, hold_lim}) begin rs_d[e] = R_WAIT; rt_d[e] = 18'd0; end
            end else rt_d[e] = rt_q[e];
            if (rt_q[e] >= wait_lim) begin rs_d[e] = R_FAIL; fail_d[e] = 1'b1; end
          end
          R_WAIT: begin
            if (!blocked[e] && clk_ok_i && !test_rst_hold_i) begin
              rs_d[e]  = R_REL;
              req_d[e] = 1'b0;                  // release the request flop; the synchroniser does the rest
              rt_d[e]  = 18'd0;
            end else if (rt_q[e] >= wait_lim) begin
              rs_d[e] = R_FAIL; fail_d[e] = 1'b1;   // engine stays in reset: explicit failure
            end
          end
          R_REL: begin
            if (rst_n_fb[e]) begin rs_d[e] = R_RDY; rt_d[e] = 18'd0; rdy_d[e] = 8'd0; end  // R4
            else if (rt_q[e] >= rdy_lim) begin rs_d[e] = R_FAIL; fail_d[e] = 1'b1; end
          end
          R_RDY: begin
            if (eng_ready_i[e]) rdy_d[e] = (rdy_q[e] == 8'hFF) ? rdy_q[e] : (rdy_q[e] + 8'd1);
            else                rdy_d[e] = 8'd0;
            if (eng_ready_i[e] && (rdy_q[e] + 8'd1 >= stable_lim)) rs_d[e] = R_DONE;
            else if (rt_q[e] >= rdy_lim) begin rs_d[e] = R_FAIL; fail_d[e] = 1'b1; end
          end
          R_DONE, R_FAIL: rs_d[e] = R_RUN;
          default: rs_d[e] = R_RUN;
        endcase
      end
    end
  end

  // ---------------------------------------------------------------------------
  // flops.  req_q is asynchronously SET by the controller reset (rule R2).
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge sys_rst_no) begin
    if (!sys_rst_no) req_q <= {NE{1'b1}};
    else             req_q <= req_d;
  end

  always_ff @(posedge clk_i or negedge sys_rst_no) begin
    if (!sys_rst_no) begin
      fail_q <= '0;
      for (int e = 0; e < NE; e++) begin
        rs_q[e]    <= R_ASSERT;           // power-on: the sequence starts by itself
        rt_q[e]    <= 18'd0;
        rdy_q[e]   <= 8'd0;
        cause_q[e] <= (8'h01 << RC_POR_EXT);
        cnt_q[e]   <= 16'd0;
      end
    end else begin
      fail_q <= fail_d;
      for (int e = 0; e < NE; e++) begin
        rs_q[e]    <= rs_d[e];
        rt_q[e]    <= rt_d[e];
        rdy_q[e]   <= rdy_d[e];
        cause_q[e] <= (cause_q[e] & ~cause_clr_i[e*8 +: 8]) | rq_cause[e];
        if (ev_d[e] && cnt_q[e] != 16'hFFFF) cnt_q[e] <= cnt_q[e] + 16'd1;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // per-engine reset synchronisers (async assert, sync release) -- unmodified P40 cell
  // ---------------------------------------------------------------------------
  genvar g;
  generate
    for (g = 0; g < NE; g++) begin : g_rs
      logic src_n;
      assign src_n = test_mode_i ? test_rst_ni : ~req_q[g];
      sf_reset_sync u_rs (
        .clk       (clk_i),
        .arst_n    (src_n),
        .test_mode (test_mode_i),
        .rst_n_sync(eng_rst_no[g])
      );
      assign rst_n_fb[g]       = eng_rst_no[g];
      assign rst_active_o[g]   = (rs_q[g] != R_RUN);
      assign rst_done_o[g]     = (rs_q[g] == R_DONE);
      assign rst_fail_o[g]     = (rs_q[g] == R_FAIL);
      assign rst_clk_force_o[g]= (rs_q[g] != R_RUN);
      assign rst_event_o[g]    = ev_d[g];
      assign rst_pend_o[g]     = rq_any[g];
      assign cause_o[g*8 +: 8] = cause_q[g];
      assign rst_cnt_o[g*16 +: 16] = cnt_q[g];
    end
  endgenerate

endmodule

`default_nettype wire
