// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_clock_enable_ctrl
//
// Clock-ENABLE generation, subsystem activity tracking, idle detection and the
// quiescence monitor, for NE engines on ONE functional clock.
//
//   * Transaction ledger   outstanding = sum(issue) - sum(retire), from event
//     counts.  Needed because some engines (Meridian P83/P102) have NO idle or
//     quiesce output at all: quiescence is derived from the handshakes.
//   * Quiescence vector    six named conditions (sf_cw_pkg Q_*); a per-engine
//     mask selects which are required; the vector must be stable for
//     cfg_quiet_cyc consecutive cycles before quiet_o rises.
//   * Idle detector        consecutive idle cycles -> auto_idle_o (policy only;
//     the FSM decides).
//   * Clock enable         clk_en_q is a FLOP in the functional clock domain,
//     so it changes only just after a rising edge: exactly what an ICG enable
//     input (latch transparent while CLK is low) or a synchronous CE needs.
//   * Hardware interlock   the enable can NEVER fall while the engine reports
//     busy, holds outstanding transactions, or has a transfer offered at its
//     input -- whatever the FSM asked for.  Any such disagreement is reported
//     as ilk_hit (fault FC_ILK): the interlock is a backstop, not a mechanism.
//
// Not done here: the gate itself.  clk_en_o drives either a synchronous
// `if (ce)` in the engine (portable baseline) or sf_cw_icg_wrap (real ICG).
//
// Classification: SYNTHESIZABLE, technology independent.
// =============================================================================
`default_nettype none

module sf_clock_enable_ctrl
  import sf_cw_pkg::*;
#(
  parameter int            NE        = 6,
  parameter int            OW        = 10,            // ledger width (max outstanding 2^OW - 1)
  parameter int            EVW       = 4,             // width of the per-cycle issue / retire event counts
  parameter logic [NE-1:0] LEDGER_EN = {NE{1'b1}}     // engines whose issue/retire events are wired
) (
  input  wire logic                 clk_i,
  input  wire logic                 rst_ni,

  // ---- from the per-engine FSMs / reset sequencer / test adapter --------------
  input  wire logic [NE-1:0]        clk_run_i,        // FSM: 0 only in CLOCK_DISABLED
  input  wire logic [NE-1:0]        accept_fsm_i,     // FSM new-work gate
  input  wire logic [NE-1:0]        rst_clk_force_i,  // reset sequencer: reset needs clock edges
  input  wire logic [NE-1:0]        test_clk_force_i, // MBIST / test: keep the clock on
  input  wire logic                 test_en_i,        // clock-gating test enable (scan): all on
  input  wire logic [NE-1:0]        f_block_i,        // DFT: functional requests blocked

  // ---- configuration -------------------------------------------------------------
  input  wire logic [NE*8-1:0]      cfg_quiet_cyc_i,
  input  wire logic [NE*24-1:0]     cfg_idle_thr_i,   // 0 = no auto idle
  input  wire logic [NE*NQ-1:0]     cfg_qmask_i,
  input  wire logic [NE-1:0]        cfg_auto_idle_en_i,
  input  wire logic [NE-1:0]        cfg_wake_en_i,
  input  wire logic                 clk_loss_i,       // functional clock lost (pulse or level)

  // ---- engine status ---------------------------------------------------------------
  input  wire logic [NE-1:0]        eng_idle_i,
  input  wire logic [NE-1:0]        eng_obuf_empty_i,
  input  wire logic [NE-1:0]        eng_dma_idle_i,
  input  wire logic [NE-1:0]        eng_mem_idle_i,
  input  wire logic [NE-1:0]        eng_err_i,
  input  wire logic [NE-1:0]        eng_wake_req_i,
  input  wire logic [NE-1:0]        up_stalled_i,     // upstream valid held back by the closed gate
  input  wire logic [NE-1:0]        in_offered_i,     // transfer offered at the engine input, not yet accepted
  input  wire logic [NE*EVW-1:0]    issue_cnt_i,      // transactions entering the engine this cycle (0..2^EVW-1)
  input  wire logic [NE*EVW-1:0]    retire_cnt_i,     // transactions leaving the engine this cycle

  // ---- outputs ---------------------------------------------------------------------
  output logic [NE-1:0]             clk_en_o,         // registered; THE enable
  output logic [NE-1:0]             accept_en_o,      // new work may be accepted
  output logic [NE-1:0]             quiet_o,
  output logic [NE-1:0]             wake_ev_o,
  output logic [NE-1:0]             auto_idle_o,
  output logic [NE-1:0]             act_o,            // engine active: busy or work outstanding
  output logic [NE*OW-1:0]          outstanding_o,
  output logic [NE*NQ-1:0]          q_vec_o,
  output logic [NE*8-1:0]           fault_ev_o,       // FC_ENG_ERR / FC_LEDGER / FC_ILK / FC_CLK_LOSS
  output logic [NE-1:0]             ilk_hit_o
);

  localparam logic [OW-1:0] OMAX = {OW{1'b1}};

  logic [NE-1:0]    clk_en_q, clk_en_d;
  logic [NE-1:0]    eng_err_q, ledger_err_q, ilk_q, clkloss_q;

  // -------------------------------------------------------------------------
  // activity accounting that does not depend on the engine index
  // -------------------------------------------------------------------------
  logic clk_loss_edge, clk_loss_prev_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) clk_loss_prev_q <= 1'b0;
    else         clk_loss_prev_q <= clk_loss_i;
  end
  assign clk_loss_edge = clk_loss_i && !clk_loss_prev_q;

  genvar e;
  generate
    for (e = 0; e < NE; e++) begin : g_eng
      // ---------------- transaction ledger --------------------------------------------------
      logic [OW-1:0]   out_q, out_d;
      integer          sum_i;
      logic            led_err_d;
      logic [EVW-1:0]  iss, ret;

      assign iss = issue_cnt_i [e*EVW +: EVW];
      assign ret = retire_cnt_i[e*EVW +: EVW];

      always_comb begin
        out_d     = out_q;
        led_err_d = 1'b0;
        sum_i     = $signed({{(32-OW){1'b0}}, out_q}) + $signed({{(32-EVW){1'b0}}, iss}) -
                    $signed({{(32-EVW){1'b0}}, ret});
        if (!LEDGER_EN[e] || rst_clk_force_i[e]) begin
          // An engine under reset has lost every transaction it held: its ledger is
          // cleared for the whole reset sequence.  (Providers still owe matching
          // retire events for the zombie responses; see docs/clockworks/03_QUIESCENCE.md.)
          out_d = '0;
        end else begin
          if (sum_i < 0) begin                          // underflow: retire without issue
            out_d     = '0;
            led_err_d = 1'b1;
          end else if (sum_i > $signed({{(32-OW){1'b0}}, OMAX})) begin  // overflow
            out_d     = OMAX;
            led_err_d = 1'b1;
          end else begin
            out_d     = sum_i[OW-1:0];
          end
        end
      end

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          out_q           <= '0;
          ledger_err_q[e] <= 1'b0;
        end else begin
          out_q           <= out_d;
          ledger_err_q[e] <= led_err_d;
        end
      end

      assign outstanding_o[e*OW +: OW] = out_q;

      // ---------------- quiescence vector ---------------------------------------------------
      logic [NQ-1:0] q;
      logic [NQ-1:0] qmask;
      logic          q_ok, quiet_raw;
      logic [7:0]    qcnt_q;
      logic [7:0]    qlim;

      assign accept_en_o[e] = accept_fsm_i[e] & ~f_block_i[e];

      assign q[Q_WORK_STOP]   = ~accept_en_o[e] & ~in_offered_i[e];
      assign q[Q_OUTSTANDING] = (out_q == '0);
      assign q[Q_OBUF]        = eng_obuf_empty_i[e];
      assign q[Q_DMA]         = eng_dma_idle_i[e];
      assign q[Q_MEM]         = eng_mem_idle_i[e];
      assign q[Q_IDLE]        = eng_idle_i[e];
      assign qmask            = cfg_qmask_i[e*NQ +: NQ];
      assign q_ok             = &(q | ~qmask);
      assign quiet_raw        = q_ok & ~ledger_err_q[e];
      assign qlim             = (cfg_quiet_cyc_i[e*8 +: 8] == 8'd0) ? 8'd1 : cfg_quiet_cyc_i[e*8 +: 8];
      assign q_vec_o[e*NQ +: NQ] = q;

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni)            qcnt_q <= 8'd0;
        else if (!quiet_raw)    qcnt_q <= 8'd0;
        else if (qcnt_q != 8'hFF) qcnt_q <= qcnt_q + 8'd1;
      end
      assign quiet_o[e] = (qcnt_q >= qlim);

      // ---------------- activity, idle detector --------------------------------------------
      logic          idle_now;
      logic [23:0]   icnt_q;
      logic [23:0]   ithr;

      assign idle_now = eng_idle_i[e] && (out_q == '0) && !in_offered_i[e] && !up_stalled_i[e];
      assign act_o[e] = !(eng_idle_i[e] && (out_q == '0));
      assign ithr     = cfg_idle_thr_i[e*24 +: 24];

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni)            icnt_q <= 24'd0;
        else if (!idle_now)     icnt_q <= 24'd0;
        else if (icnt_q != 24'hFFFFFF) icnt_q <= icnt_q + 24'd1;
      end
      assign auto_idle_o[e] = cfg_auto_idle_en_i[e] && (ithr != 24'd0) && (icnt_q >= ithr);

      // ---------------- wake ----------------------------------------------------------------
      assign wake_ev_o[e] = cfg_wake_en_i[e] & (eng_wake_req_i[e] | up_stalled_i[e]);

      // ---------------- clock enable and hardware interlock -------------------------------------
      logic ilk_busy, ilk_wanted_off;
      assign ilk_busy = !eng_idle_i[e] || (out_q != '0) || in_offered_i[e];
      assign clk_en_d[e] = clk_run_i[e] | rst_clk_force_i[e] | test_clk_force_i[e] | test_en_i | ilk_busy;
      // the FSM wants the clock off and nothing else forces it on, yet the engine is busy
      assign ilk_wanted_off = !clk_run_i[e] && !rst_clk_force_i[e] && !test_clk_force_i[e] &&
                              !test_en_i && ilk_busy;

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          clk_en_q[e] <= 1'b1;               // clocks are ON until the controller says otherwise
          ilk_q[e]    <= 1'b0;
          eng_err_q[e]<= 1'b0;
          clkloss_q[e]<= 1'b0;
        end else begin
          clk_en_q[e] <= clk_en_d[e];
          ilk_q[e]    <= ilk_wanted_off;
          eng_err_q[e]<= eng_err_i[e];
          clkloss_q[e]<= clk_loss_i | clk_loss_edge;
        end
      end

      assign clk_en_o[e]  = clk_en_q[e];
      assign ilk_hit_o[e] = ilk_q[e];

      // ---------------- fault events (FC_* bit positions) -----------------------------------------
      always_comb begin
        fault_ev_o[e*8 +: 8]            = 8'h00;
        fault_ev_o[e*8 + FC_ENG_ERR]    = eng_err_i[e] & ~eng_err_q[e];   // rising edge
        fault_ev_o[e*8 + FC_LEDGER]     = ledger_err_q[e];
        fault_ev_o[e*8 + FC_ILK]        = ilk_q[e];
        fault_ev_o[e*8 + FC_CLK_LOSS]   = clkloss_q[e];
      end
    end
  endgenerate

endmodule

`default_nettype wire
