// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_cw_pkg
//
// Shared constants, encodings and elaboration-time helper functions.
// Plain localparams and functions only (no structs, no interfaces): the same
// sources are read by Verilator, Icarus Verilog and Yosys.
//
// Terminology (docs/clockworks/01_ARCHITECTURE.md, section 2):
//   clock ENABLE      a synchronous enable bit; the flops of the engine are
//                     written `if (ce) q <= d`  (portable baseline)
//   clock GATING      the same enable drives a library ICG cell (sf_cw_icg_wrap)
//   power DOMAIN      a supply region; NOT implemented in this release
//   isolation, retention, power switch
//                     hooks only; NOT implemented in this release
// =============================================================================
`default_nettype none

package sf_cw_pkg;

  // ---------------------------------------------------------------------------
  // Engines of the reference configuration (NE = 6).  The ids index every
  // per-engine vector.  PacketForge is the repository's PacketCore (P62).
  // ---------------------------------------------------------------------------
  localparam int CW_MAXE = 8;               // hard upper bound on engines
  localparam int E_CC    = 0;               // ControlCore
  localparam int E_MM    = 1;               // MemoryMatrix
  localparam int E_MR    = 2;               // Meridian interconnect (DataFabric)
  localparam int E_DMA   = 3;               // StreamDMA
  localparam int E_TC    = 4;               // TensorCore
  localparam int E_PF    = 5;               // PacketForge (PacketCore)

  // ---------------------------------------------------------------------------
  // Operating states (per engine).  Code 7 is UNSUPPORTED and is rejected.
  // ---------------------------------------------------------------------------
  localparam logic [2:0] ST_ACTIVE   = 3'd0;
  localparam logic [2:0] ST_IDLE_REQ = 3'd1;   // IDLE_REQUESTED
  localparam logic [2:0] ST_DRAINING = 3'd2;
  localparam logic [2:0] ST_CLK_DIS  = 3'd3;   // CLOCK_DISABLED
  localparam logic [2:0] ST_WAKE_REQ = 3'd4;   // WAKE_REQUESTED
  localparam logic [2:0] ST_RESET    = 3'd5;
  localparam logic [2:0] ST_FAULT    = 3'd6;
  localparam logic [2:0] ST_BAD      = 3'd7;   // never a legal state

  // Legal state transitions (docs/clockworks/02_STATE_MACHINE.md, table 3).
  // f == t is a legal "stay".  Used by the FSM unit bench, the checker and the
  // formal wrapper; the FSM itself is not generated from this table, which is
  // exactly why the table is an independent oracle.
  function automatic logic cw_legal(input logic [2:0] f, input logic [2:0] t);
    if (f == t && f != ST_BAD) cw_legal = 1'b1;
    else begin
      case (f)
        ST_ACTIVE:   cw_legal = (t == ST_IDLE_REQ) || (t == ST_RESET) || (t == ST_FAULT);
        ST_IDLE_REQ: cw_legal = (t == ST_ACTIVE)   || (t == ST_DRAINING) ||
                                (t == ST_RESET)    || (t == ST_FAULT);
        ST_DRAINING: cw_legal = (t == ST_ACTIVE)   || (t == ST_CLK_DIS) ||
                                (t == ST_RESET)    || (t == ST_FAULT);
        ST_CLK_DIS:  cw_legal = (t == ST_WAKE_REQ) || (t == ST_RESET) || (t == ST_FAULT);
        ST_WAKE_REQ: cw_legal = (t == ST_ACTIVE)   || (t == ST_RESET) || (t == ST_FAULT);
        ST_RESET:    cw_legal = (t == ST_WAKE_REQ) || (t == ST_FAULT);
        ST_FAULT:    cw_legal = (t == ST_RESET);
        default:     cw_legal = 1'b0;
      endcase
    end
  endfunction

  // ---------------------------------------------------------------------------
  // Quiescence conditions (bit index into the per-engine q vector)
  // ---------------------------------------------------------------------------
  localparam int NQ            = 6;
  localparam int Q_WORK_STOP   = 0;  // acceptance gate closed and no transfer offered at the input
  localparam int Q_OUTSTANDING = 1;  // transaction ledger == 0
  localparam int Q_OBUF        = 2;  // output buffers / response FIFOs empty
  localparam int Q_DMA         = 3;  // no DMA / completion record outstanding
  localparam int Q_MEM         = 4;  // memory interface idle
  localparam int Q_IDLE        = 5;  // engine-internal idle

  // ---------------------------------------------------------------------------
  // Drain / wake sub-steps (visible in the per-engine STATE register)
  // ---------------------------------------------------------------------------
  localparam logic [2:0] D_NONE    = 3'd0;
  localparam logic [2:0] D_QUIESCE = 3'd1;   // waiting for the q vector
  localparam logic [2:0] D_CANCEL  = 3'd2;   // cancel pulsed, waiting again
  localparam logic [2:0] D_SAVE    = 3'd3;   // explicit architectural-state save

  localparam logic [2:0] W_NONE    = 3'd0;
  localparam logic [2:0] W_CLK     = 3'd1;   // clock-enable restored, settling
  localparam logic [2:0] W_PROV    = 3'd2;   // providers (DataFabric, memory) serving
  localparam logic [2:0] W_RST     = 3'd3;   // reset required by this engine on wake
  localparam logic [2:0] W_RESTORE = 3'd4;   // explicit state restore
  localparam logic [2:0] W_READY   = 3'd5;   // local readiness
  localparam logic [2:0] W_FABRIC  = 3'd6;   // DataFabric reconnection

  // ---------------------------------------------------------------------------
  // Fault causes (sticky per engine; a set bit means the engine entered FAULT)
  // ---------------------------------------------------------------------------
  localparam int FC_DRAIN_TMO     = 0;  // never reached quiescence (clock kept ON)
  localparam int FC_WAKE_TMO      = 1;
  localparam int FC_RST_TMO       = 2;  // not ready after reset release
  localparam int FC_ILLEGAL_STATE = 3;  // state register held an unsupported code
  localparam int FC_ENG_ERR       = 4;  // engine reported a fatal error
  localparam int FC_LEDGER        = 5;  // retire without issue / ledger overflow
  localparam int FC_ILK           = 6;  // sequencing tried to stop a busy clock
  localparam int FC_CLK_LOSS      = 7;  // functional clock reported lost

  // Non-fatal events (sticky bits, never change the state)
  localparam int SE_REJECT  = 0;  // a request was rejected
  localparam int SE_DEP_TMO = 1;  // idle request withdrawn: dependents never went quiet
  localparam int SE_CANCEL  = 2;  // outstanding work was cancelled to drain
  localparam int SE_WAKE    = 3;  // wake completed
  localparam int SE_QUIET   = 4;  // clock disabled

  // Request rejection codes
  localparam logic [3:0] REJ_NONE        = 4'd0;
  localparam logic [3:0] REJ_STATE       = 4'd1;  // request not legal in the current state
  localparam logic [3:0] REJ_UNSUPPORTED = 4'd2;  // target state is not requestable / code 7
  localparam logic [3:0] REJ_SRAM        = 4'd3;  // SRAM retention not qualified for clock stop
  localparam logic [3:0] REJ_POLICY      = 4'd4;  // engine is configured not to be gated
  localparam logic [3:0] REJ_TEST        = 4'd5;  // test/MBIST owns the engine
  localparam logic [3:0] REJ_DISABLED    = 4'd6;  // controller globally disabled

  // Idle-request origin
  localparam logic [1:0] ORG_SW   = 2'd0;
  localparam logic [1:0] ORG_AUTO = 2'd1;
  localparam logic [1:0] ORG_TEST = 2'd2;

  // ---------------------------------------------------------------------------
  // Reset causes (sticky bit per engine)
  // ---------------------------------------------------------------------------
  localparam int RC_POR_EXT   = 0;  // power-on or external reset pin
  localparam int RC_GLOBAL_SW = 1;  // software global reset
  localparam int RC_SUBSYS    = 2;  // subsystem reset (software or reset-on-wake)
  localparam int RC_WDT       = 3;  // engine progress watchdog
  localparam int RC_SYS_WDT   = 4;  // system watchdog
  localparam int RC_FAULT     = 5;  // fault-triggered reset
  localparam int RC_TEST      = 6;  // test / scan reset
  localparam int RC_CLOSURE   = 7;  // collateral: a provider was reset

  // TestCore mode codes (DFTGrid `mode`, docs/03_TEST_MODES_AND_ARBITRATION.md)
  localparam logic [2:0] TM_NORMAL       = 3'd0;
  localparam logic [2:0] TM_JTAG         = 3'd1;
  localparam logic [2:0] TM_DIAG         = 3'd2;
  localparam logic [2:0] TM_MBIST        = 3'd3;
  localparam logic [2:0] TM_SCAN_SHIFT   = 3'd4;
  localparam logic [2:0] TM_SCAN_CAPTURE = 3'd5;

  // MBIST result codes reported by the adapter
  localparam logic [3:0] MB_NOT_RUN  = 4'd0;
  localparam logic [3:0] MB_RUNNING  = 4'd1;
  localparam logic [3:0] MB_PASS     = 4'd2;
  localparam logic [3:0] MB_FAIL     = 4'd3;
  localparam logic [3:0] MB_ERROR    = 4'd4;
  localparam logic [3:0] MB_REFUSED  = 4'd5;
  localparam logic [3:0] MB_TIMEOUT  = 4'd6;
  localparam logic [3:0] MB_ABORTED  = 4'd7;

  // ---------------------------------------------------------------------------
  // Activity-counter metric indices (per engine, 32-bit saturating)
  // ---------------------------------------------------------------------------
  localparam int NMET             = 18;
  localparam int M_ACTIVE         = 0;   // clock running, engine busy or work outstanding
  localparam int M_IDLE           = 1;   // clock running, engine idle (candidate saving)
  localparam int M_DISABLED       = 2;   // clock enable low
  localparam int M_TRANS          = 3;   // state transitions
  localparam int M_WAKE_CNT       = 4;
  localparam int M_WAKE_SUM       = 5;
  localparam int M_WAKE_MAX       = 6;
  localparam int M_WAKE_LAST      = 7;
  localparam int M_QUI_CNT        = 8;
  localparam int M_QUI_SUM        = 9;
  localparam int M_QUI_MAX        = 10;
  localparam int M_QUI_LAST       = 11;
  localparam int M_RST_EVENTS     = 12;
  localparam int M_OUT_CHG_MAX    = 13;  // max outstanding seen at a state change
  localparam int M_OUT_CHG_SUM    = 14;
  localparam int M_CHG_WITH_OUT   = 15;  // state changes with outstanding > 0
  localparam int M_DIS_WITH_OUT   = 16;  // entries to CLOCK_DISABLED with outstanding > 0 (must be 0)
  localparam int M_CANCEL_CNT     = 17;

  // ---------------------------------------------------------------------------
  // Elaboration-time helpers over the dependency matrix.
  //   dep[e*8 + p] = 1  : engine e REQUIRES provider p (e sends transactions to p)
  // ---------------------------------------------------------------------------
  // engines that directly require provider p
  function automatic logic [CW_MAXE-1:0] cw_dependents(input logic [CW_MAXE*CW_MAXE-1:0] dep,
                                                       input int p);
    logic [CW_MAXE-1:0] r;
    r = '0;
    for (int d = 0; d < CW_MAXE; d++) r[d] = dep[d*CW_MAXE + p];
    cw_dependents = r;
  endfunction

  // provider mask of engine e
  function automatic logic [CW_MAXE-1:0] cw_providers(input logic [CW_MAXE*CW_MAXE-1:0] dep,
                                                      input int e);
    cw_providers = dep[e*CW_MAXE +: CW_MAXE];
  endfunction

  // e plus every engine that transitively requires e
  function automatic logic [CW_MAXE-1:0] cw_closure(input logic [CW_MAXE*CW_MAXE-1:0] dep,
                                                    input int e);
    logic [CW_MAXE-1:0] r;
    r    = '0;
    r[e] = 1'b1;
    for (int it = 0; it < CW_MAXE; it++)
      for (int d = 0; d < CW_MAXE; d++)
        if (|(dep[d*CW_MAXE +: CW_MAXE] & r)) r[d] = 1'b1;
    cw_closure = r;
  endfunction

  // engines released BEFORE e (strictly lower release rank), rank = 2 bits per engine
  function automatic logic [CW_MAXE-1:0] cw_lower_rank(input logic [2*CW_MAXE-1:0] rank,
                                                       input int e);
    logic [CW_MAXE-1:0] r;
    r = '0;
    for (int k = 0; k < CW_MAXE; k++)
      if (rank[2*k +: 2] < rank[2*e +: 2]) r[k] = 1'b1;
    cw_lower_rank = r;
  endfunction


  // matrix forms (row e at [e*8 +: 8]) so a module can index them as localparams.
  // Each is self-contained (no calls to other functions): Icarus Verilog 12 only accepts
  // such functions as constant functions.
  function automatic logic [CW_MAXE*CW_MAXE-1:0] cw_closure_all(input logic [CW_MAXE*CW_MAXE-1:0] dep);
    logic [CW_MAXE*CW_MAXE-1:0] m;
    logic [CW_MAXE-1:0] r;
    m = '0;
    for (int e = 0; e < CW_MAXE; e++) begin
      r    = '0;
      r[e] = 1'b1;
      for (int it = 0; it < CW_MAXE; it++)
        for (int d = 0; d < CW_MAXE; d++)
          if (|(dep[d*CW_MAXE +: CW_MAXE] & r)) r[d] = 1'b1;
      m[e*CW_MAXE +: CW_MAXE] = r;
    end
    cw_closure_all = m;
  endfunction

  function automatic logic [CW_MAXE*CW_MAXE-1:0] cw_lower_all(input logic [2*CW_MAXE-1:0] rank);
    logic [CW_MAXE*CW_MAXE-1:0] m;
    m = '0;
    for (int e = 0; e < CW_MAXE; e++)
      for (int k = 0; k < CW_MAXE; k++)
        if (rank[2*k +: 2] < rank[2*e +: 2]) m[e*CW_MAXE + k] = 1'b1;
    cw_lower_all = m;
  endfunction

  function automatic logic [CW_MAXE*CW_MAXE-1:0] cw_dependents_all(input logic [CW_MAXE*CW_MAXE-1:0] dep);
    logic [CW_MAXE*CW_MAXE-1:0] m;
    m = '0;
    for (int p = 0; p < CW_MAXE; p++)
      for (int d = 0; d < CW_MAXE; d++)
        m[p*CW_MAXE + d] = dep[d*CW_MAXE + p];
    cw_dependents_all = m;
  endfunction

  // 1 when every provider of every engine has a strictly lower release rank
  function automatic logic cw_rank_consistent(input logic [CW_MAXE*CW_MAXE-1:0] dep,
                                              input logic [2*CW_MAXE-1:0] rank);
    logic ok;
    ok = 1'b1;
    for (int e = 0; e < CW_MAXE; e++)
      for (int p = 0; p < CW_MAXE; p++)
        if (dep[e*CW_MAXE + p] && !(rank[2*p +: 2] < rank[2*e +: 2])) ok = 1'b0;
    cw_rank_consistent = ok;
  endfunction

  // ---------------------------------------------------------------------------
  // Reference integration parameters (used as defaults by sf_clock_power_ctrl)
  //   bit e of every per-engine mask = engine e; order {PF,TC,DMA,MR,MM,CC}
  //
  //   ControlCore and DMA/TC/PF send transactions through Meridian; Meridian
  //   forwards to the memory subsystem.  Stop order: masters, Meridian, memory.
  //   Wake order is the reverse.  This is a documented ASSUMPTION about the
  //   reference topology: change it with the DEP_MASK parameter.
  // ---------------------------------------------------------------------------
  localparam logic [CW_MAXE*CW_MAXE-1:0] CW_REF_DEP =
      64'h00_00_04_04_04_02_00_04;   // b0 CC<-MR  b1 MM<-none  b2 MR<-MM  b3 DMA<-MR  b4 TC<-MR  b5 PF<-MR
  localparam logic [CW_MAXE-1:0] CW_REF_HAS_SRAM   = 8'b0011_0011;  // CC, MM, TC, PF own SRAM; DMA buffer is a flop FIFO (P103, no macro found)
  localparam logic [CW_MAXE-1:0] CW_REF_CAN_CANCEL = 8'b0000_1000;  // DMA: ctl_abort
  localparam logic [2*CW_MAXE-1:0] CW_REF_GRP      = 16'h1002;      // DFTGrid group 0 = MM, group 1 = TC
  // Release rank: MM 0, MR 1, DMA/TC/PF 2, CC 3 (the controller boots last)
  localparam logic [2*CW_MAXE-1:0] CW_REF_RANK = 16'h0A93;

endpackage

`default_nettype wire
