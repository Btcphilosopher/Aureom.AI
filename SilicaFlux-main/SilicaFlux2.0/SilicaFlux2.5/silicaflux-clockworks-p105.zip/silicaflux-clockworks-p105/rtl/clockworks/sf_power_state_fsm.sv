// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_power_state_fsm
//
// Operating-state machine of ONE engine.
//
//   ACTIVE -> IDLE_REQUESTED -> DRAINING -> CLOCK_DISABLED -> WAKE_REQUESTED -> ACTIVE
//   any state -> RESET (the reset sequencer owns the engine) -> WAKE_REQUESTED
//   any state -> FAULT -> RESET
//
// Legal transitions are tabulated in sf_cw_pkg::cw_legal (an independent oracle)
// and in docs/clockworks/02_STATE_MACHINE.md.
//
// Safety rules enforced here (each is also an assertion in sf_cw_checker and a
// formal property in formal/clockworks):
//   S1  the clock is stopped (clk_run_o = 0) only in CLOCK_DISABLED
//   S2  CLOCK_DISABLED is entered only from DRAINING, in a cycle where the
//       quiescence vector has been stable for the configured number of cycles
//       (quiet_i), and, if configured, after the explicit state save completed
//   S3  the new-work gate (accept_o) is closed in every state except ACTIVE and
//       IDLE_REQUESTED, and is reopened only on entry to ACTIVE after local
//       readiness AND DataFabric reconnection
//   S4  a drain that does not converge never stops the clock: it ends in FAULT
//       with the clock still running
//   S5  a state register holding an unsupported code goes to FAULT
//   S6  a request that is not legal in the current state, or names a state that
//       cannot be requested, is rejected with a code and changes nothing
//
// Requests (req_valid_i with req_state_i) -- the only requestable targets are
//   ST_ACTIVE (wake / cancel idle), ST_CLK_DIS (go idle), ST_RESET.
// Anything else, including code 7, is rejected as UNSUPPORTED.
//
// Timeouts: a value of 0 means "use the maximum (65535 cycles)", never "off",
// so no wait is unbounded.
//
// Classification: SYNTHESIZABLE, technology independent.
// =============================================================================
`default_nettype none

module sf_power_state_fsm
  import sf_cw_pkg::*;
#(
  parameter bit ALLOW_GATE  = 1'b1,  // the engine may be put in CLOCK_DISABLED
  parameter bit HAS_SRAM    = 1'b0,  // the engine owns SRAM macros
  parameter bit SRAM_QUAL   = 1'b0,  // macros qualified (datasheet) for clock stop / CE hold
  parameter bit SAVE_EN     = 1'b0,  // explicit state save before disable, restore on wake
  parameter bit CAN_CANCEL  = 1'b0,  // the engine implements a safe cancel (e.g. DMA abort)
  parameter bit RST_ON_WAKE = 1'b0   // the engine must be reset on every wake
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,

  // ---- configuration (quasi-static, same clock) ------------------------------
  input  wire logic [15:0] cfg_drain_tmo_i,
  input  wire logic [15:0] cfg_cancel_tmo_i,
  input  wire logic [15:0] cfg_wake_tmo_i,
  input  wire logic [15:0] cfg_dep_tmo_i,
  input  wire logic [15:0] cfg_min_active_i,
  input  wire logic [7:0]  cfg_clk_settle_i,
  input  wire logic        cfg_fault_rst_en_i,
  input  wire logic [3:0]  cfg_max_auto_rst_i,
  input  wire logic        fault_clr_i,        // pulse: restore the auto-reset budget

  // ---- requests -------------------------------------------------------------
  input  wire logic        req_valid_i,        // one-cycle pulse
  input  wire logic [2:0]  req_state_i,
  input  wire logic        test_hold_i,        // test adapter: keep the engine quiesced
  input  wire logic        auto_idle_i,        // idle detector expired (already enabled)
  input  wire logic        wake_ev_i,          // work / interrupt / dependent needs this engine
  output logic             req_ack_o,          // pulse: request accepted
  output logic             req_rej_o,          // pulse: request rejected
  output logic [3:0]       rej_code_o,

  // ---- reset sequencer ------------------------------------------------------
  input  wire logic        rst_active_i,       // the sequencer owns this engine
  input  wire logic        rst_done_i,         // pulse, last cycle of the sequence
  input  wire logic        rst_fail_i,         // pulse, last cycle of a failed sequence
  input  wire logic        rst_pend_i,         // a reset request is being taken THIS cycle (the engine
                                               // reset asserts at the coming edge): never reopen the gate
  output logic             rst_sw_req_o,       // pulse: subsystem reset requested
  output logic             rst_fault_req_o,    // pulse: fault-triggered reset requested

  // ---- environment ----------------------------------------------------------
  input  wire logic        quiet_i,            // quiescence vector stable (sf_clock_enable_ctrl)
  input  wire logic        clk_en_i,           // actual enable at the engine (feedback)
  input  wire logic        clk_ok_i,           // functional clock domain healthy
  input  wire logic        prov_ready_i,       // every provider is serving
  input  wire logic        deps_iso_i,         // every dependent is isolated
  input  wire logic        eng_ready_i,        // local readiness
  input  wire logic        fabric_ack_i,       // DataFabric port connected
  input  wire logic        save_done_i,
  input  wire logic        restore_done_i,
  input  wire logic [7:0]  fault_ev_i,         // fault events (FC_* bits), level or pulse

  // ---- controls to the engine -----------------------------------------------
  output logic [2:0]       state_o,
  output logic             clk_run_o,          // 0 only in CLOCK_DISABLED
  output logic             accept_o,           // new-work gate: 1 = engine may accept work
  output logic             quiesce_o,          // engine must stop issuing / finish what it holds
  output logic             cancel_o,           // pulse: safely cancel outstanding work
  output logic             save_req_o,
  output logic             restore_req_o,
  output logic             fabric_conn_o,      // DataFabric port connect request
  output logic             isolated_o,         // CLOCK_DISABLED / RESET / FAULT
  output logic             serving_o,          // clock on and accepting (ACTIVE / IDLE_REQ)

  // ---- status / instrumentation ----------------------------------------------
  output logic [2:0]       dstep_o,
  output logic [2:0]       wstep_o,
  output logic [7:0]       fault_set_o,        // pulse bits: causes recorded this cycle
  output logic [7:0]       soft_set_o,         // pulse bits: non-fatal events
  output logic             trans_o,            // state changes at the next edge
  output logic [2:0]       trans_from_o,
  output logic [2:0]       trans_to_o
);

  // ---------------------------------------------------------------------------
  // registers
  // ---------------------------------------------------------------------------
  logic [2:0]  state_q, state_d;
  logic [2:0]  dstep_q, dstep_d, wstep_q, wstep_d;
  logic [15:0] tmr_q, tmr_d;
  logic [15:0] act_q, act_d;
  logic [7:0]  settle_q, settle_d;
  logic [1:0]  org_q, org_d;
  logic        wake_pend_q, wake_pend_d;
  logic        canc_q, canc_d;
  logic        post_rst_q, post_rst_d;
  logic        wake_rst_q, wake_rst_d;
  logic        rst_iss_q, rst_iss_d;
  logic        frst_iss_q, frst_iss_d;
  logic [3:0]  arst_q, arst_d;
  logic        clk_run_q, clk_run_d;
  logic        accept_q, accept_d;
  logic        quiesce_q, quiesce_d;
  logic        fabric_q, fabric_d;
  logic        save_q, save_d;
  logic        restore_q, restore_d;

  // ---------------------------------------------------------------------------
  // derived
  // ---------------------------------------------------------------------------
  logic req_wake, req_idle, req_reset, req_unsup;
  assign req_wake  = req_valid_i && (req_state_i == ST_ACTIVE);
  assign req_idle  = req_valid_i && (req_state_i == ST_CLK_DIS);
  assign req_reset = req_valid_i && (req_state_i == ST_RESET);
  assign req_unsup = req_valid_i && !(req_wake || req_idle || req_reset);

  localparam bit SRAM_OK = !HAS_SRAM || SRAM_QUAL || SAVE_EN;
  localparam bit GATE_OK = ALLOW_GATE && SRAM_OK;

  function automatic logic [15:0] lim(input logic [15:0] v);
    lim = (v == 16'd0) ? 16'hFFFF : v;
  endfunction

  logic [15:0] drain_lim, cancel_lim, wake_lim, dep_lim;
  assign drain_lim  = lim(cfg_drain_tmo_i);
  assign cancel_lim = lim(cfg_cancel_tmo_i);
  assign wake_lim   = lim(cfg_wake_tmo_i);
  assign dep_lim    = lim(cfg_dep_tmo_i);

  logic min_ok, test_owns;
  assign min_ok    = (act_q >= cfg_min_active_i);
  assign test_owns = (org_q == ORG_TEST) && test_hold_i;

  logic unsupported_state;
  assign unsupported_state = (state_q > ST_FAULT);

  // ---------------------------------------------------------------------------
  // next-state logic
  // ---------------------------------------------------------------------------
  logic        go_fault;
  logic [7:0]  go_fault_cause;
  logic        cancel_pulse, rst_sw_pulse, rst_fault_pulse;
  logic [7:0]  soft_d;
  logic        ack_d, rej_d;
  logic [3:0]  rej_code_d;
  logic        abort_idle;          // leave IDLE_REQUESTED / early DRAINING back to ACTIVE

  always_comb begin
    state_d    = state_q;
    dstep_d    = dstep_q;
    wstep_d    = wstep_q;
    tmr_d      = (tmr_q == 16'hFFFF) ? tmr_q : (tmr_q + 16'd1);
    // time since the engine last became ACTIVE; it keeps counting while an idle request waits
    // for its dependents (otherwise MIN_ACTIVE could never be met after the first cycle)
    act_d      = (state_q == ST_ACTIVE || state_q == ST_IDLE_REQ) ?
                 ((act_q == 16'hFFFF) ? act_q : (act_q + 16'd1)) : 16'd0;
    settle_d   = settle_q;
    org_d      = org_q;
    wake_pend_d= wake_pend_q;
    canc_d     = canc_q;
    post_rst_d = post_rst_q;
    wake_rst_d = wake_rst_q;
    rst_iss_d  = rst_iss_q;
    frst_iss_d = (state_q == ST_FAULT) ? frst_iss_q : 1'b0;
    arst_d     = arst_q;
    clk_run_d  = clk_run_q;
    accept_d   = accept_q;
    quiesce_d  = quiesce_q;
    fabric_d   = fabric_q;
    save_d     = save_q;
    restore_d  = restore_q;
    go_fault       = 1'b0;
    go_fault_cause = 8'h00;
    cancel_pulse   = 1'b0;
    rst_sw_pulse   = 1'b0;
    rst_fault_pulse= 1'b0;
    soft_d         = 8'h00;
    ack_d          = 1'b0;
    rej_d          = 1'b0;
    rej_code_d     = REJ_NONE;
    abort_idle     = 1'b0;

    if (fault_clr_i) arst_d = 4'd0;

    // =========================================================================
    // S5: unsupported state code
    // =========================================================================
    if (unsupported_state) begin
      go_fault       = 1'b1;
      go_fault_cause = (8'h01 << FC_ILLEGAL_STATE);
      if (req_valid_i) begin rej_d = 1'b1; rej_code_d = REJ_STATE; end

    // =========================================================================
    // the reset sequencer owns the engine: RESET wins over every state
    // =========================================================================
    end else if (rst_active_i && state_q != ST_RESET) begin
      state_d    = ST_RESET;
      clk_run_d  = 1'b1;
      accept_d   = 1'b0;
      quiesce_d  = 1'b1;
      fabric_d   = 1'b0;
      save_d     = 1'b0;
      restore_d  = 1'b0;
      dstep_d    = D_NONE;
      wstep_d    = W_NONE;
      org_d      = ORG_SW;
      wake_pend_d= 1'b0;
      if (req_valid_i) begin
        if (req_reset) ack_d = 1'b1;
        else begin rej_d = 1'b1; rej_code_d = req_unsup ? REJ_UNSUPPORTED : REJ_STATE; end
      end

    end else begin
      case (state_q)
        // ---------------------------------------------------------------------
        ST_ACTIVE: begin
          if (req_unsup)      begin rej_d = 1'b1; rej_code_d = REJ_UNSUPPORTED; end
          else if (req_wake)  ack_d = 1'b1;                    // already active: no-op
          else if (req_reset) begin ack_d = 1'b1; rst_sw_pulse = 1'b1; end
          else if (req_idle) begin
            if (test_hold_i)         ack_d = 1'b1;
            else if (!ALLOW_GATE)    begin rej_d = 1'b1; rej_code_d = REJ_POLICY; end
            else if (!SRAM_OK)       begin rej_d = 1'b1; rej_code_d = REJ_SRAM;   end
            else                     ack_d = 1'b1;
          end

          if (|fault_ev_i) begin
            go_fault = 1'b1; go_fault_cause = fault_ev_i;
          end else if (test_hold_i) begin
            state_d = ST_IDLE_REQ; org_d = ORG_TEST; tmr_d = 16'd0;
          end else if (req_idle && GATE_OK) begin
            state_d = ST_IDLE_REQ; org_d = ORG_SW;   tmr_d = 16'd0;
          end else if (auto_idle_i && GATE_OK && min_ok) begin
            state_d = ST_IDLE_REQ; org_d = ORG_AUTO; tmr_d = 16'd0;
          end
        end

        // ---------------------------------------------------------------------
        ST_IDLE_REQ: begin
          if (req_unsup)      begin rej_d = 1'b1; rej_code_d = REJ_UNSUPPORTED; end
          else if (req_reset) begin ack_d = 1'b1; rst_sw_pulse = 1'b1; end
          else if (req_idle)  ack_d = 1'b1;                    // already requested
          else if (req_wake) begin
            if (test_owns) begin rej_d = 1'b1; rej_code_d = REJ_TEST; end
            else ack_d = 1'b1;
          end

          abort_idle = (req_wake && !test_owns) ||
                       (org_q == ORG_AUTO && wake_ev_i) ||
                       (org_q == ORG_TEST && !test_hold_i);

          if (|fault_ev_i) begin
            go_fault = 1'b1; go_fault_cause = fault_ev_i;
          end else if (abort_idle) begin
            state_d = ST_ACTIVE; org_d = ORG_SW;
          end else if (deps_iso_i && (min_ok || org_q == ORG_TEST)) begin
            // S3: close the work gate; S2 is checked in DRAINING
            state_d   = ST_DRAINING;
            accept_d  = 1'b0;
            quiesce_d = 1'b1;
            dstep_d   = D_QUIESCE;
            tmr_d     = 16'd0;
            canc_d    = 1'b0;
          end else if (tmr_q >= dep_lim && org_q != ORG_TEST) begin
            state_d = ST_ACTIVE; org_d = ORG_SW;
            soft_d[SE_DEP_TMO] = 1'b1;
          end
        end

        // ---------------------------------------------------------------------
        ST_DRAINING: begin
          abort_idle = (dstep_q == D_QUIESCE || dstep_q == D_CANCEL) &&
                       ((req_wake && !test_owns) ||
                        (org_q == ORG_AUTO && wake_ev_i) ||
                        (org_q == ORG_TEST && !test_hold_i));

          if (req_unsup)      begin rej_d = 1'b1; rej_code_d = REJ_UNSUPPORTED; end
          else if (req_reset) begin ack_d = 1'b1; rst_sw_pulse = 1'b1; end
          else if (req_idle)  ack_d = 1'b1;
          else if (req_wake) begin
            if (test_owns) begin rej_d = 1'b1; rej_code_d = REJ_TEST; end
            else begin
              ack_d = 1'b1;
              if (!abort_idle) wake_pend_d = 1'b1;             // save in progress: wake after disable
            end
          end

          if (|fault_ev_i) begin
            go_fault = 1'b1; go_fault_cause = fault_ev_i;
          end else if (abort_idle) begin
            state_d = ST_ACTIVE; org_d = ORG_SW;
            accept_d = 1'b1; quiesce_d = 1'b0; dstep_d = D_NONE; save_d = 1'b0;
          end else begin
            case (dstep_q)
              D_QUIESCE: begin
                if (quiet_i) begin
                  if (SAVE_EN) begin dstep_d = D_SAVE; save_d = 1'b1; tmr_d = 16'd0; end
                  else begin
                    state_d = ST_CLK_DIS; clk_run_d = 1'b0; fabric_d = 1'b0; dstep_d = D_NONE;
                    soft_d[SE_QUIET] = 1'b1;
                  end
                end else if (tmr_q >= drain_lim) begin
                  if (CAN_CANCEL && !canc_q) begin
                    cancel_pulse = 1'b1; canc_d = 1'b1; dstep_d = D_CANCEL; tmr_d = 16'd0;
                    soft_d[SE_CANCEL] = 1'b1;
                  end else begin
                    go_fault = 1'b1; go_fault_cause = (8'h01 << FC_DRAIN_TMO);
                  end
                end
              end
              D_CANCEL: begin
                if (quiet_i) begin
                  if (SAVE_EN) begin dstep_d = D_SAVE; save_d = 1'b1; tmr_d = 16'd0; end
                  else begin
                    state_d = ST_CLK_DIS; clk_run_d = 1'b0; fabric_d = 1'b0; dstep_d = D_NONE;
                    soft_d[SE_QUIET] = 1'b1;
                  end
                end else if (tmr_q >= cancel_lim) begin
                  go_fault = 1'b1; go_fault_cause = (8'h01 << FC_DRAIN_TMO);
                end
              end
              D_SAVE: begin
                if (save_done_i && quiet_i) begin
                  state_d = ST_CLK_DIS; clk_run_d = 1'b0; fabric_d = 1'b0; dstep_d = D_NONE;
                  save_d = 1'b0; soft_d[SE_QUIET] = 1'b1;
                end else if (tmr_q >= drain_lim) begin
                  go_fault = 1'b1; go_fault_cause = (8'h01 << FC_DRAIN_TMO);
                end
              end
              default: begin
                go_fault = 1'b1; go_fault_cause = (8'h01 << FC_ILLEGAL_STATE);
              end
            endcase
          end
        end

        // ---------------------------------------------------------------------
        ST_CLK_DIS: begin
          if (req_unsup)      begin rej_d = 1'b1; rej_code_d = REJ_UNSUPPORTED; end
          else if (req_reset) begin ack_d = 1'b1; rst_sw_pulse = 1'b1; end
          else if (req_idle)  ack_d = 1'b1;
          else if (req_wake) begin
            if (test_owns) begin rej_d = 1'b1; rej_code_d = REJ_TEST; end
            else ack_d = 1'b1;
          end

          if (|fault_ev_i) begin
            go_fault = 1'b1; go_fault_cause = fault_ev_i;
          end else if ((req_wake && !test_owns) || wake_pend_q ||
                       (wake_ev_i && !test_owns) ||
                       (org_q == ORG_TEST && !test_hold_i)) begin
            state_d     = ST_WAKE_REQ;
            clk_run_d   = 1'b1;               // enable restored first
            wstep_d     = W_CLK;
            tmr_d       = 16'd0;
            settle_d    = 8'd0;
            wake_pend_d = 1'b0;
            post_rst_d  = 1'b0;
            wake_rst_d  = 1'b0;
            rst_iss_d   = 1'b0;
          end
        end

        // ---------------------------------------------------------------------
        ST_WAKE_REQ: begin
          if (req_unsup)      begin rej_d = 1'b1; rej_code_d = REJ_UNSUPPORTED; end
          else if (req_reset) begin ack_d = 1'b1; rst_sw_pulse = 1'b1; end
          else if (req_idle)  begin rej_d = 1'b1; rej_code_d = REJ_STATE; end
          else if (req_wake)  ack_d = 1'b1;

          if (|fault_ev_i) begin
            go_fault = 1'b1; go_fault_cause = fault_ev_i;
          end else if (tmr_q >= wake_lim) begin
            go_fault = 1'b1; go_fault_cause = (8'h01 << FC_WAKE_TMO);
          end else begin
            case (wstep_q)
              W_CLK: begin
                if (clk_en_i && clk_ok_i) begin
                  settle_d = (settle_q == 8'hFF) ? settle_q : (settle_q + 8'd1);
                  if (settle_q >= cfg_clk_settle_i) begin wstep_d = W_PROV; end
                end else settle_d = 8'd0;
              end
              W_PROV: begin
                if (prov_ready_i && clk_ok_i) begin
                  if (RST_ON_WAKE && !post_rst_q) begin
                    wstep_d = W_RST;
                  end else if (SAVE_EN && (!post_rst_q || wake_rst_q)) begin
                    wstep_d = W_RESTORE; restore_d = 1'b1; tmr_d = tmr_q;
                  end else begin
                    wstep_d = W_READY;
                  end
                end
              end
              W_RST: begin
                // one subsystem-reset request; the sequencer then takes the engine to RESET
                if (!rst_iss_q) begin
                  rst_sw_pulse = 1'b1; rst_iss_d = 1'b1; wake_rst_d = 1'b1;
                end
              end
              W_RESTORE: begin
                if (restore_done_i) begin restore_d = 1'b0; wstep_d = W_READY; end
              end
              W_READY: begin
                if (eng_ready_i) begin wstep_d = W_FABRIC; fabric_d = 1'b1; end
              end
              W_FABRIC: begin
                if (fabric_ack_i) begin
                  // S3: the gate opens only now, after readiness and reconnection
                  state_d   = ST_ACTIVE;
                  accept_d  = 1'b1;
                  quiesce_d = 1'b0;
                  wstep_d   = W_NONE;
                  org_d     = ORG_SW;
                  soft_d[SE_WAKE] = 1'b1;
                end
              end
              default: begin
                go_fault = 1'b1; go_fault_cause = (8'h01 << FC_ILLEGAL_STATE);
              end
            endcase
          end
        end

        // ---------------------------------------------------------------------
        ST_RESET: begin
          if (req_unsup)      begin rej_d = 1'b1; rej_code_d = REJ_UNSUPPORTED; end
          else if (req_reset) ack_d = 1'b1;                    // already in reset
          else if (req_valid_i) begin rej_d = 1'b1; rej_code_d = REJ_STATE; end

          if (rst_fail_i) begin
            go_fault = 1'b1; go_fault_cause = (8'h01 << FC_RST_TMO);
          end else if (rst_done_i) begin
            // reset released and engine ready (sequencer); finish bring-up here
            state_d    = ST_WAKE_REQ;
            wstep_d    = W_PROV;
            tmr_d      = 16'd0;
            post_rst_d = 1'b1;
          end
        end

        // ---------------------------------------------------------------------
        ST_FAULT: begin
          if (req_unsup)      begin rej_d = 1'b1; rej_code_d = REJ_UNSUPPORTED; end
          else if (req_reset) begin ack_d = 1'b1; rst_sw_pulse = 1'b1; end
          else if (req_valid_i) begin rej_d = 1'b1; rej_code_d = REJ_STATE; end

          if (cfg_fault_rst_en_i && !frst_iss_q && (arst_q < cfg_max_auto_rst_i)) begin
            rst_fault_pulse = 1'b1;
            frst_iss_d      = 1'b1;
            arst_d          = arst_q + 4'd1;
          end
        end

        default: begin
          go_fault = 1'b1; go_fault_cause = (8'h01 << FC_ILLEGAL_STATE);
        end
      endcase
    end

    // S3 (race closure): the gate is never REOPENED in the cycle in which a reset begins.
    // Without this, a wake that completes on the same edge as a reset request would
    // open the gate for one cycle on an engine that is already being reset.
    if (rst_pend_i && accept_d && !accept_q) accept_d = 1'b0;

    // =========================================================================
    // FAULT entry (S4: the clock is left RUNNING, the gate closed, the fabric cut)
    // =========================================================================
    if (go_fault) begin
      state_d   = ST_FAULT;
      clk_run_d = 1'b1;
      accept_d  = 1'b0;
      quiesce_d = 1'b1;
      fabric_d  = 1'b0;
      save_d    = 1'b0;
      restore_d = 1'b0;
      dstep_d   = D_NONE;
      wstep_d   = W_NONE;
      frst_iss_d= 1'b0;
    end
  end

  // events recorded as sticky causes even when the state does not change
  logic [7:0] fault_rec;
  // The cause of THIS cycle's transition into FAULT is always recorded (including
  // FC_RST_TMO, which is decided while the state is still RESET); stray external
  // events are ignored while the engine is in reset.
  assign fault_rec = (go_fault ? go_fault_cause : 8'h00) | ((state_q == ST_RESET) ? 8'h00 : fault_ev_i);

  // ---------------------------------------------------------------------------
  // state flops
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q     <= ST_RESET;
      dstep_q     <= D_NONE;
      wstep_q     <= W_NONE;
      tmr_q       <= 16'd0;
      act_q       <= 16'd0;
      settle_q    <= 8'd0;
      org_q       <= ORG_SW;
      wake_pend_q <= 1'b0;
      canc_q      <= 1'b0;
      post_rst_q  <= 1'b0;
      wake_rst_q  <= 1'b0;
      rst_iss_q   <= 1'b0;
      frst_iss_q  <= 1'b0;
      arst_q      <= 4'd0;
      clk_run_q   <= 1'b1;
      accept_q    <= 1'b0;
      quiesce_q   <= 1'b1;
      fabric_q    <= 1'b0;
      save_q      <= 1'b0;
      restore_q   <= 1'b0;
      req_ack_o   <= 1'b0;
      req_rej_o   <= 1'b0;
      rej_code_o  <= REJ_NONE;
      cancel_o    <= 1'b0;
      rst_sw_req_o    <= 1'b0;
      rst_fault_req_o <= 1'b0;
    end else begin
      state_q     <= state_d;
      dstep_q     <= dstep_d;
      wstep_q     <= wstep_d;
      tmr_q       <= tmr_d;
      act_q       <= act_d;
      settle_q    <= settle_d;
      org_q       <= org_d;
      wake_pend_q <= wake_pend_d;
      canc_q      <= canc_d;
      post_rst_q  <= post_rst_d;
      wake_rst_q  <= wake_rst_d;
      rst_iss_q   <= rst_iss_d;
      frst_iss_q  <= frst_iss_d;
      arst_q      <= arst_d;
      clk_run_q   <= clk_run_d;
      accept_q    <= accept_d;
      quiesce_q   <= quiesce_d;
      fabric_q    <= fabric_d;
      save_q      <= save_d;
      restore_q   <= restore_d;
      req_ack_o   <= ack_d;
      req_rej_o   <= rej_d;
      rej_code_o  <= rej_d ? rej_code_d : REJ_NONE;
      cancel_o    <= cancel_pulse;
      rst_sw_req_o    <= rst_sw_pulse;
      rst_fault_req_o <= rst_fault_pulse;
    end
  end

  // sticky-event pulses are combinational views of the *decision* (one cycle
  // before the state changes), registered in the consumer
  assign fault_set_o  = fault_rec;
  assign soft_set_o   = soft_d | {7'd0, rej_d};

  assign state_o      = state_q;
  assign clk_run_o    = clk_run_q;
  assign accept_o     = accept_q;
  assign quiesce_o    = quiesce_q;
  assign save_req_o   = save_q;
  assign restore_req_o= restore_q;
  assign fabric_conn_o= fabric_q;
  assign isolated_o   = (state_q == ST_CLK_DIS) || (state_q == ST_RESET) ||
                        (state_q == ST_FAULT)   || (state_q > ST_FAULT);
  assign serving_o    = (state_q == ST_ACTIVE) || (state_q == ST_IDLE_REQ);
  assign dstep_o      = dstep_q;
  assign wstep_o      = wstep_q;
  assign trans_o      = (state_d != state_q);
  assign trans_from_o = state_q;
  assign trans_to_o   = state_d;

endmodule

`default_nettype wire
