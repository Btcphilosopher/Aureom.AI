// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_cw_checker   (SIMULATION / FORMAL)
//
// Assertions that PREVENT-BY-DETECTION unsafe clock, state and reset changes
// at the level of sf_clock_power_ctrl.  Instantiate it next to the controller
// (tests/clockworks/tb_cw_system.sv does) and connect the controller's
// outputs plus the engine-side signals named below.  err_o counts violations;
// the bench fails if it is ever non-zero.
//
// Immediate assertions only (no concurrent SVA), so the same file runs in
// the three tools used here (Verilator, Icarus Verilog, Yosys).  With
// +define+FORMAL each check is an `assert`; otherwise it counts and prints.
//
// Properties (numbering used by docs/clockworks/11_VERIFICATION.md):
//   C01 state code is never the unsupported code 7
//   C02 every state change is in the legal-transition table (sf_cw_pkg::cw_legal)
//   C03 an engine clock is disabled only the cycle after CLOCK_DISABLED
//   C04 clk_en falls only when the engine reported idle, with no outstanding
//       transaction and no transfer offered in the cycle before
//   C05 the new-work gate is open only in ACTIVE / IDLE_REQUESTED
//   C06 CLOCK_DISABLED is entered only from DRAINING, with the gate already
//       closed, quiescence stable, and no outstanding transaction
//   C07 DataFabric port disconnected in CLOCK_DISABLED / RESET / FAULT
//   C08 the clock keeps running in FAULT and RESET
//   C09 the gate reopens only in ACTIVE, with the fabric connected AND
//       acknowledged, and the engine locally ready
//   C10 RESET is left only after the reset synchroniser released the engine
//   C11 CLOCK_DISABLED implies quiesce is requested; DRAINING implies gate closed
//   C12 the interlock backstop never fires (it would mean a sequencing bug)
//   C13 in scan mode every clock enable is on
//   (C14, the activity counter DIS_WITH_OUT staying 0, is checked by the bench
//    through the register file, not here)
// =============================================================================
`default_nettype none

`ifdef FORMAL
  `define CW_CHK(cond, id) assert(cond)
`else
  `define CW_CHK(cond, id) if (!(cond)) begin errs_q <= errs_q + 32'd1; \
      if (!mute_i) $display("CW_CHECK_FAIL %s engine=%0d t=%0t", id, e, $time); end
`endif

module sf_cw_checker
  import sf_cw_pkg::*;
#(
  parameter int NE         = 6,
  parameter int OW         = 10,
  parameter bit ALLOW_ILK  = 1'b0       // tests that inject interlock conditions on purpose set 1
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,          // controller reset (synchronously released)
  input  wire logic [NE*3-1:0]   state_i,
  input  wire logic [NE-1:0]     clk_en_i,
  input  wire logic [NE-1:0]     accept_i,
  input  wire logic [NE-1:0]     quiesce_i,
  input  wire logic [NE-1:0]     fabric_i,
  input  wire logic [NE-1:0]     eng_rst_n_i,
  input  wire logic [NE-1:0]     quiet_i,
  input  wire logic [NE-1:0]     ilk_i,
  input  wire logic [NE-1:0]     eng_idle_i,
  input  wire logic [NE-1:0]     in_offered_i,
  input  wire logic [NE-1:0]     eng_ready_i,
  input  wire logic [NE-1:0]     fabric_ack_i,
  input  wire logic [NE*OW-1:0]  outstanding_i,
  input  wire logic              scan_active_i,
  input  wire logic              mute_i,          // silence the console (violations are still counted)
  output logic [31:0]            err_o
);
  logic [31:0] errs_q;
  assign err_o = errs_q;

  logic [NE*3-1:0] pst_q;
  logic [NE-1:0]   pen_q, pacc_q, pquiet_q, pidle_q, poff_q, prst_q;
  logic [NE*OW-1:0] pout_q;
  logic            pscan_q, vld_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pst_q <= {NE{ST_RESET}}; pen_q <= '1; pacc_q <= '0; pquiet_q <= '0; pidle_q <= '0; poff_q <= '0;
      prst_q <= '0; pout_q <= '0; pscan_q <= 1'b0; vld_q <= 1'b0;
    end else begin
      pst_q <= state_i; pen_q <= clk_en_i; pacc_q <= accept_i; pquiet_q <= quiet_i; pidle_q <= eng_idle_i;
      poff_q <= in_offered_i; prst_q <= eng_rst_n_i; pout_q <= outstanding_i; pscan_q <= scan_active_i;
      vld_q <= 1'b1;
    end
  end

`ifndef FORMAL
  initial errs_q = 32'd0;
`endif

  genvar e_g;
  generate
    for (e_g = 0; e_g < NE; e_g++) begin : g_chk
      localparam int e = e_g;
      logic [2:0]    st, pst;
      logic [OW-1:0] pout;
      assign st   = state_i[e*3 +: 3];
      assign pst  = pst_q[e*3 +: 3];
      assign pout = pout_q[e*OW +: OW];

      // plain `always`: this module is a simulation / formal checker, never synthesized
      always @(posedge clk_i) begin
        if (vld_q) begin
          `CW_CHK(st != ST_BAD, "C01")
          `CW_CHK(cw_legal(pst, st), "C02")
          if (!clk_en_i[e] && !scan_active_i)
            `CW_CHK(pst == ST_CLK_DIS, "C03")
          if (pen_q[e] && !clk_en_i[e])
            `CW_CHK(pout == '0 && pidle_q[e] && !poff_q[e], "C04")
          if (accept_i[e])
            `CW_CHK(st == ST_ACTIVE || st == ST_IDLE_REQ, "C05")
          if (st == ST_CLK_DIS && pst != ST_CLK_DIS)
            `CW_CHK(pst == ST_DRAINING && pquiet_q[e] && !pacc_q[e] && pout == '0, "C06")
          if (st == ST_CLK_DIS || st == ST_RESET || st == ST_FAULT)
            `CW_CHK(!fabric_i[e], "C07")
          if ((st == ST_FAULT && pst == ST_FAULT) || (st == ST_RESET && pst == ST_RESET))
            `CW_CHK(clk_en_i[e], "C08")
          if (accept_i[e] && !pacc_q[e])
            `CW_CHK(st == ST_ACTIVE && fabric_i[e] && fabric_ack_i[e] && eng_ready_i[e], "C09")
          if (pst == ST_RESET && st == ST_WAKE_REQ)
            `CW_CHK(prst_q[e], "C10")
          if (st == ST_CLK_DIS)  `CW_CHK(quiesce_i[e], "C11")
          if (st == ST_DRAINING) `CW_CHK(!accept_i[e], "C11")
          if (!ALLOW_ILK)        `CW_CHK(!ilk_i[e], "C12")
          if (scan_active_i && pscan_q) `CW_CHK(clk_en_i[e], "C13")
        end
      end
    end
  endgenerate

endmodule

`default_nettype wire
