// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_cw_icg_wrap
//
// The ONLY place a clock is gated.  A clock is never gated with an AND/OR in
// RTL: a combinational gate glitches when its enable changes while the clock
// is high.  Select one implementation at build time (at most one define):
//
//   SF_CW_ICG_NANGATE45     Nangate45 CLKGATETST_X1 (P40 technology binding;
//                           educational, NON-manufacturable library)
//   SF_CW_ICG_LIB           integrator-supplied library ICG through
//                           sf_cw_icg_lib_cell (pins CK, E, SE, GCK; a
//                           blackbox is in physical/clockworks/)
//   SF_CW_ICG_XILINX_BUFGCE Xilinx BUFGCE (mapped, not validated on hardware)
//   (none) + simulation     behavioural latch + AND, equal to a library ICG
//   (none) + SYNTHESIS      FAILS TO ELABORATE ON PURPOSE
//
// en_i must be a flop output in the same clock domain (sf_clock_enable_ctrl
// guarantees this).  te_i forces the clock on (scan / clock-gating test).
//
// QUALIFICATION STATUS: no library cell has been qualified for this design.
// Cell name, setup/hold of E to CK, the clock-gating check in STA, minimum
// pulse widths and the scan-enable pin's behaviour must be taken from the
// real library (physical/clockworks/ICG_QUALIFICATION.md).
// =============================================================================
`default_nettype none

module sf_cw_clock_gate (
  input  wire logic clk_i,
  input  wire logic en_i,
  input  wire logic te_i,
  output logic      gclk_o
);
`ifdef SF_CW_ICG_NANGATE45
  CLKGATETST_X1 u_icg (.CK(clk_i), .E(en_i), .SE(te_i), .GCK(gclk_o));
`elsif SF_CW_ICG_LIB
  sf_cw_icg_lib_cell u_icg (.CK(clk_i), .E(en_i), .SE(te_i), .GCK(gclk_o));
`elsif SF_CW_ICG_XILINX_BUFGCE
  BUFGCE u_bufgce (.I(clk_i), .CE(en_i | te_i), .O(gclk_o));
`else
  `ifdef SYNTHESIS
  sf_cw_icg_target_not_selected u_select_SF_CW_ICG_NANGATE45_or_LIB_or_XILINX_BUFGCE ();
  assign gclk_o = clk_i;
  `else
  // Behavioural ICG: the enable is captured while the clock is LOW, so the gated
  // clock can only start or stop on a full low phase -> no runt pulses.
  logic en_l;
  always_latch begin
    if (!clk_i) en_l = en_i | te_i;
  end
  assign gclk_o = clk_i & en_l;
  `endif
`endif
endmodule

`default_nettype wire
