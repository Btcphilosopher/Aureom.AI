// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_cw_icg_wrap
// One sf_cw_clock_gate per engine.  See sf_cw_clock_gate.sv for the rules.
// =============================================================================
`default_nettype none

module sf_cw_icg_wrap #(
  parameter int NE = 6
) (
  input  wire logic          clk_i,
  input  wire logic [NE-1:0] en_i,      // clk_en from sf_clock_enable_ctrl (flop outputs)
  input  wire logic          te_i,
  output logic [NE-1:0]      gclk_o
);
  genvar e;
  generate
    for (e = 0; e < NE; e++) begin : g_icg
      sf_cw_clock_gate u_cg (.clk_i(clk_i), .en_i(en_i[e]), .te_i(te_i), .gclk_o(gclk_o[e]));
    end
  endgenerate
endmodule

`default_nettype wire
