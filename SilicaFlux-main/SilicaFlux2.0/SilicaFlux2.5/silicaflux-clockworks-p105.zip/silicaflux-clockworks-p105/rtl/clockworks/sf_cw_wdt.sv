// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_cw_wdt
//
// Watchdogs of the controlled domain (single functional clock).
//
//  * Per-engine PROGRESS watchdog: counts consecutive cycles in which the engine
//    is supposed to make progress (ACTIVE and busy / work outstanding) and no
//    transaction retired.  At the limit it raises exp_o (one pulse per episode),
//    which the reset sequencer turns into a forced reset with closure.
//    It cannot fire on an idle engine, in a drain, or while the clock is gated,
//    because act_i is 0 in those cases.
//  * SYSTEM watchdog: a two-stage heartbeat.  Stage 1 (limit) sets an interrupt
//    flag; stage 2 (a further limit) raises a global reset pulse if enabled.
//    Software kicks it.  The configuration lock lives in the register file.
//
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_cw_wdt #(
  parameter int NE = 6
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  // per-engine progress watchdog
  input  wire logic [NE-1:0]     cfg_en_i,
  input  wire logic [NE*24-1:0]  cfg_limit_i,      // cycles without progress; 0 = disabled
  input  wire logic [NE-1:0]     act_i,            // engine should be progressing
  input  wire logic [NE-1:0]     prog_i,           // a transaction retired this cycle
  output logic [NE-1:0]          exp_o,            // pulse
  // system watchdog
  input  wire logic              sys_en_i,
  input  wire logic [31:0]       sys_limit_i,      // 0 = disabled
  input  wire logic              sys_kick_i,
  input  wire logic              sys_rst_en_i,
  output logic                   sys_irq_o,        // stage 1 reached (sticky until kick)
  output logic                   sys_rst_o         // pulse: stage 2 reached
);

  genvar e;
  generate
    for (e = 0; e < NE; e++) begin : g_eng
      logic [23:0] cnt_q;
      logic        fired_q;
      logic [23:0] lim;
      logic        hit;
      assign lim = cfg_limit_i[e*24 +: 24];
      assign hit = cfg_en_i[e] && (lim != 24'd0) && (cnt_q >= lim) && !fired_q;

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          cnt_q   <= 24'd0;
          fired_q <= 1'b0;
        end else begin
          if (!act_i[e] || prog_i[e] || !cfg_en_i[e]) begin
            cnt_q   <= 24'd0;
            fired_q <= 1'b0;
          end else begin
            if (cnt_q != 24'hFFFFFF) cnt_q <= cnt_q + 24'd1;
            if (hit) fired_q <= 1'b1;
          end
        end
      end
      assign exp_o[e] = hit;
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // system watchdog
  // ---------------------------------------------------------------------------
  logic [32:0] s_cnt_q;
  logic        s_irq_q;
  logic [32:0] s_lim1, s_lim2;
  logic        s_on;
  assign s_on   = sys_en_i && (sys_limit_i != 32'd0);
  assign s_lim1 = {1'b0, sys_limit_i};
  assign s_lim2 = {sys_limit_i, 1'b0};

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      s_cnt_q   <= 33'd0;
      s_irq_q   <= 1'b0;
      sys_rst_o <= 1'b0;
    end else begin
      sys_rst_o <= 1'b0;
      if (!s_on || sys_kick_i) begin
        s_cnt_q <= 33'd0;
        s_irq_q <= 1'b0;
      end else begin
        s_cnt_q <= s_cnt_q + 33'd1;
        if (s_cnt_q + 33'd1 >= s_lim1) s_irq_q <= 1'b1;
        if (s_cnt_q + 33'd1 >= s_lim2) begin
          s_cnt_q   <= 33'd0;
          sys_rst_o <= sys_rst_en_i;
        end
      end
    end
  end
  assign sys_irq_o = s_irq_q;

endmodule

`default_nettype wire
