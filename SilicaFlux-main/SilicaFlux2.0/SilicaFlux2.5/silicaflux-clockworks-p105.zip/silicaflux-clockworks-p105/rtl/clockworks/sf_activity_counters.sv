// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_activity_counters
//
// Instrumentation for later power ESTIMATES.  These are RTL cycle counts, not
// power.  No watt, joule or percentage saving is produced here or anywhere in
// this package without library data (docs/clockworks/08_POWER_ANALYSIS.md).
//
// Per engine (32-bit saturating; metric indices in sf_cw_pkg):
//   ACTIVE / IDLE / DISABLED cycles   clock enable high & busy, high & idle, low
//                                     (ACTIVE + IDLE + DISABLED == total cycles)
//   TRANS                             state transitions
//   WAKE_*                            wake latency: cycles in WAKE_REQUESTED, for
//                                     wakes that started in CLOCK_DISABLED
//   QUI_*                             quiescence latency: cycles in DRAINING for
//                                     drains that ended in CLOCK_DISABLED
//   RST_EVENTS                        reset sequences started
//   OUT_CHG_MAX / SUM / CHG_WITH_OUT  outstanding transactions at state changes
//   DIS_WITH_OUT                      entries to CLOCK_DISABLED with outstanding
//                                     work -- a SAFETY counter, must stay 0
//   CANCEL_CNT                        cancels issued to drain
//
// All counters can be frozen coherently with snap_i: a shadow copy is taken in
// one cycle, so software reads a consistent set (same functional clock; no CDC).
//
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_activity_counters
  import sf_cw_pkg::*;
#(
  parameter int NE = 6,
  parameter int OW = 10
) (
  input  wire logic                 clk_i,
  input  wire logic                 rst_ni,
  input  wire logic                 clr_i,           // pulse: clear all counters
  input  wire logic                 snap_i,          // pulse: copy live -> shadow
  input  wire logic [NE-1:0]        clk_en_i,
  input  wire logic [NE-1:0]        act_i,
  input  wire logic [NE-1:0]        trans_i,         // state changes at the next edge
  input  wire logic [NE*3-1:0]      from_i,
  input  wire logic [NE*3-1:0]      to_i,
  input  wire logic [NE*OW-1:0]     out_i,           // ledger value in the decision cycle
  input  wire logic [NE-1:0]        rst_event_i,
  input  wire logic [NE-1:0]        cancel_i,
  output logic [NE*NMET*32-1:0]     cnt_o,           // live
  output logic [NE*NMET*32-1:0]     snap_o,          // shadow
  output logic [63:0]               cyc_o,
  output logic [63:0]               cyc_snap_o
);

  function automatic logic [31:0] sadd(input logic [31:0] a, input logic [31:0] b);
    logic [32:0] s;
    s = {1'b0, a} + {1'b0, b};
    sadd = s[32] ? 32'hFFFF_FFFF : s[31:0];
  endfunction

  logic [63:0] cyc_q, cyc_snap_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)       begin cyc_q <= 64'd0; cyc_snap_q <= 64'd0; end
    else begin
      if (clr_i)       cyc_q <= 64'd0;
      else if (cyc_q != 64'hFFFF_FFFF_FFFF_FFFF) cyc_q <= cyc_q + 64'd1;
      if (snap_i)      cyc_snap_q <= cyc_q;
    end
  end
  assign cyc_o      = cyc_q;
  assign cyc_snap_o = cyc_snap_q;

  genvar e;
  generate
    for (e = 0; e < NE; e++) begin : g_eng
      logic [31:0] m_q    [NMET];
      logic [31:0] m_snap [NMET];
      logic [31:0] wl_q, ql_q;
      logic        wl_run_q, ql_run_q;

      logic [2:0]  frm, to;
      logic [31:0] outv;
      logic        outnz;
      assign frm   = from_i[e*3 +: 3];
      assign to    = to_i[e*3 +: 3];
      assign outv  = {{(32-OW){1'b0}}, out_i[e*OW +: OW]};
      assign outnz = (out_i[e*OW +: OW] != '0);

      logic wake_start, wake_end, qui_start, qui_end;
      assign wake_start = trans_i[e] && (frm == ST_CLK_DIS)  && (to == ST_WAKE_REQ);
      assign wake_end   = trans_i[e] && (frm == ST_WAKE_REQ) && (to == ST_ACTIVE) && wl_run_q;
      assign qui_start  = trans_i[e] && (frm == ST_IDLE_REQ) && (to == ST_DRAINING);
      assign qui_end    = trans_i[e] && (frm == ST_DRAINING) && (to == ST_CLK_DIS) && ql_run_q;

      logic [31:0] wl_lat, ql_lat;
      assign wl_lat = sadd(wl_q, 32'd1);   // cycles spent in WAKE_REQUESTED
      assign ql_lat = sadd(ql_q, 32'd1);   // cycles spent in DRAINING

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          for (int m = 0; m < NMET; m++) begin m_q[m] <= 32'd0; m_snap[m] <= 32'd0; end
          wl_q <= 32'd0; ql_q <= 32'd0; wl_run_q <= 1'b0; ql_run_q <= 1'b0;
        end else begin
          // ---------------- latency timers ----------------
          if (wake_start)               begin wl_run_q <= 1'b1; wl_q <= 32'd0; end
          else if (wl_run_q) begin
            wl_q <= sadd(wl_q, 32'd1);
            if (trans_i[e]) wl_run_q <= 1'b0;                 // left WAKE_REQUESTED
          end
          if (qui_start)                begin ql_run_q <= 1'b1; ql_q <= 32'd0; end
          else if (ql_run_q) begin
            ql_q <= sadd(ql_q, 32'd1);
            if (trans_i[e]) ql_run_q <= 1'b0;                 // left DRAINING
          end

          if (clr_i) begin
            for (int m = 0; m < NMET; m++) m_q[m] <= 32'd0;
          end else begin
            // ---------------- residency ----------------
            if (clk_en_i[e]) begin
              if (act_i[e]) m_q[M_ACTIVE] <= sadd(m_q[M_ACTIVE], 32'd1);
              else          m_q[M_IDLE]   <= sadd(m_q[M_IDLE],   32'd1);
            end else        m_q[M_DISABLED] <= sadd(m_q[M_DISABLED], 32'd1);

            // ---------------- state changes ----------------
            if (trans_i[e]) begin
              m_q[M_TRANS]        <= sadd(m_q[M_TRANS], 32'd1);
              m_q[M_OUT_CHG_SUM]  <= sadd(m_q[M_OUT_CHG_SUM], outv);
              if (outv > m_q[M_OUT_CHG_MAX]) m_q[M_OUT_CHG_MAX] <= outv;
              if (outnz) m_q[M_CHG_WITH_OUT] <= sadd(m_q[M_CHG_WITH_OUT], 32'd1);
              if (outnz && to == ST_CLK_DIS)
                m_q[M_DIS_WITH_OUT] <= sadd(m_q[M_DIS_WITH_OUT], 32'd1);
            end
            if (wake_end) begin
              m_q[M_WAKE_CNT]  <= sadd(m_q[M_WAKE_CNT], 32'd1);
              m_q[M_WAKE_SUM]  <= sadd(m_q[M_WAKE_SUM], wl_lat);
              m_q[M_WAKE_LAST] <= wl_lat;
              if (wl_lat > m_q[M_WAKE_MAX]) m_q[M_WAKE_MAX] <= wl_lat;
            end
            if (qui_end) begin
              m_q[M_QUI_CNT]   <= sadd(m_q[M_QUI_CNT], 32'd1);
              m_q[M_QUI_SUM]   <= sadd(m_q[M_QUI_SUM], ql_lat);
              m_q[M_QUI_LAST]  <= ql_lat;
              if (ql_lat > m_q[M_QUI_MAX]) m_q[M_QUI_MAX] <= ql_lat;
            end
            if (rst_event_i[e]) m_q[M_RST_EVENTS] <= sadd(m_q[M_RST_EVENTS], 32'd1);
            if (cancel_i[e])    m_q[M_CANCEL_CNT] <= sadd(m_q[M_CANCEL_CNT], 32'd1);
          end

          if (snap_i) for (int m = 0; m < NMET; m++) m_snap[m] <= m_q[m];
        end
      end

      for (genvar m = 0; m < NMET; m++) begin : g_out
        assign cnt_o [(e*NMET + m)*32 +: 32] = m_q[m];
        assign snap_o[(e*NMET + m)*32 +: 32] = m_snap[m];
      end
    end
  endgenerate

endmodule

`default_nettype wire
