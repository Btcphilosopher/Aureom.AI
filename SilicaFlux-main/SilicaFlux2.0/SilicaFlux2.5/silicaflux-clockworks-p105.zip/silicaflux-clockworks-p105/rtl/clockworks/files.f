// CLOCKWORKS RTL file list, in compile order (paths relative to the package root)
rtl/clockworks/sf_cw_pkg.sv
rtl/clockworks/sf_cw_regs_pkg.sv
third_party/silicaflux_p40/sf_reset_sync.sv
third_party/silicaflux_p40/sf_sync2.sv
rtl/clockworks/sf_power_state_fsm.sv
rtl/clockworks/sf_clock_enable_ctrl.sv
rtl/clockworks/sf_reset_sequencer.sv
rtl/clockworks/sf_cw_wdt.sv
rtl/clockworks/sf_activity_counters.sv
rtl/clockworks/sf_clock_test_adapter.sv
rtl/clockworks/sf_cw_regs.sv
rtl/clockworks/sf_cw_clock_gate.sv
rtl/clockworks/sf_cw_icg_wrap.sv
rtl/clockworks/sf_clock_power_ctrl.sv
