// =============================================================================
// SilicaFlux Project 105 -- CLOCKWORKS :: sf_clock_test_adapter
//
// Interfaces between the clock / power / reset controller and the test
// infrastructure (TestCore P07, DFTGrid P39, MemoryTest P78).
//
// WHAT THIS BLOCK IS: control sequencing and signal conditioning for
//   * scan mode / scan enable / clock-gating test enable
//   * MBIST entry / start / status, and group quiesce for DFTGrid's MBIST
//   * JTAG / TestCore mode decode
//   * memory diagnostic access gating
//
// WHAT THIS BLOCK IS NOT: scan insertion, scan stitching, ATPG, a TAP, an
// MBIST engine or a test-pattern generator.  None of those exist in this
// package.  Asserting scan_mode_i here does not make a design scannable; it
// opens the clocks and holds the resets so that a scan flow CAN work, and the
// flow itself (insertion, DRC, ATPG, coverage) remains to be done
// (docs/clockworks/07_DFT_INTERFACES.md).
//
// Signal names and meanings follow DFTGrid P39 (dft_test_mode, dft_icg_te,
// dft_scan_en, dft_mem_inhibit, mbist_clk_req, quiesce_req / quiesce_ack,
// f_block, f_busy, f_req) and MemoryTest P78 (start_i, busy_o, done_o, pass_o,
// fail_o, error_o, test_mode_i, test_permit_i, cpu_halted_i).
//
// Rules:
//   T1  scan mode needs test_permit_i; without it the request is IGNORED and
//       logged (TEST_EV denied) -- scan can never be entered in the field
//   T2  during scan every clock is forced on, every reset is held, and engines
//       are not sequenced; leaving scan requires the full reset sequence
//   T3  MBIST starts only after every engine that can reach the memory is
//       CLOCK_DISABLED (quiesced) with its clock forced on
//   T4  a test never starts on an engine in RESET or FAULT (REFUSED)
//   T5  diagnostic memory access is allowed only in TestCore DIAGNOSTIC mode,
//       with permit, outside scan, and with the memory owner quiesced
//
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_clock_test_adapter
  import sf_cw_pkg::*;
#(
  parameter int                          NE       = 6,
  parameter int                          NG       = 2,   // DFTGrid memory groups
  parameter logic [NG*CW_MAXE-1:0]       GRP_ENG  = 16'h1002, // g0 = MM (bit1), g1 = TC (bit4)
  parameter logic [CW_MAXE-1:0]          DIAG_ENG = 8'h02,    // memory owner for diagnostic access
  parameter int                          CPU_ENG  = 0,        // engine that is the "CPU" for cpu_halted
  parameter bit                          TE_FOLLOWS_SCAN_EN = 1'b0,
  parameter int                          DAW      = 32,
  parameter int                          DDW      = 64
) (
  input  wire logic                 clk_i,
  input  wire logic                 rst_ni,

  // ---- test permission and mode (from DFTGrid / TestCore, functional clock) ----
  input  wire logic                 test_permit_i,
  input  wire logic                 scan_mode_i,
  input  wire logic                 scan_en_i,
  input  wire logic                 icg_te_i,
  input  wire logic                 mem_inhibit_i,
  input  wire logic [2:0]           tc_mode_i,

  // ---- DFTGrid memory-group handshake (names as in P39) ------------------------
  input  wire logic [NG-1:0]        dft_quiesce_req_i,
  input  wire logic [NG-1:0]        dft_f_block_i,
  input  wire logic [NG-1:0]        dft_mbist_clk_req_i,
  output logic [NG-1:0]             dft_quiesce_ack_o,
  output logic [NG-1:0]             dft_f_busy_o,
  output logic [NG-1:0]             dft_f_req_o,

  // ---- to the controller ----------------------------------------------------------
  output logic                      scan_mode_eff_o,   // combinational: pins & permit (reset-path safe)
  output logic                      scan_active_o,     // registered copy
  output logic                      cg_test_en_o,      // clock-gating test enable: all ICGs open
  output logic                      scan_en_o,
  output logic [NE-1:0]             test_hold_o,       // per engine: stay quiesced (test owns it)
  output logic [NE-1:0]             test_clk_force_o,  // per engine: keep the clock running
  output logic [NE-1:0]             f_block_o,         // per engine: block functional requests
  output logic [NE-1:0]             mem_inhibit_o,

  // ---- engine state in ------------------------------------------------------------
  input  wire logic [NE-1:0]        eng_quiesced_i,    // state == CLOCK_DISABLED
  input  wire logic [NE-1:0]        eng_active_i,      // state == ACTIVE
  input  wire logic [NE-1:0]        eng_bad_i,         // state == RESET or FAULT
  input  wire logic [NE-1:0]        eng_busy_i,
  input  wire logic [NE-1:0]        eng_stalled_i,

  // ---- MBIST command side (register file) ----------------------------------------
  input  wire logic                 mbist_cmd_start_i,
  input  wire logic                 mbist_cmd_abort_i,
  input  wire logic [NE-1:0]        mbist_eng_mask_i,
  input  wire logic [15:0]          cfg_mbist_tmo_i,

  // ---- MBIST engine side (MemoryTest P78 sf_sram_mbist) ------------------------------
  output logic                      mbist_start_o,
  output logic                      mbist_abort_o,
  output logic                      mbist_test_mode_o,
  output logic                      mbist_permit_o,
  output logic                      mbist_cpu_halted_o,
  input  wire logic                 mbist_busy_i,
  input  wire logic                 mbist_done_i,
  input  wire logic                 mbist_pass_i,
  input  wire logic                 mbist_fail_i,
  input  wire logic                 mbist_err_i,
  output logic [3:0]                mbist_result_o,
  output logic [2:0]                mbist_state_o,
  output logic                      mbist_busy_o,

  // ---- memory diagnostic access ----------------------------------------------------
  input  wire logic                 diag_req_valid_i,
  input  wire logic                 diag_req_we_i,
  input  wire logic [DAW-1:0]       diag_req_addr_i,
  input  wire logic [DDW-1:0]       diag_req_wdata_i,
  output logic                      diag_req_ready_o,
  output logic                      diag_rsp_valid_o,
  output logic [DDW-1:0]            diag_rsp_rdata_o,
  output logic                      diag_rsp_err_o,
  output logic                      mem_diag_valid_o,
  output logic                      mem_diag_we_o,
  output logic [DAW-1:0]            mem_diag_addr_o,
  output logic [DDW-1:0]            mem_diag_wdata_o,
  input  wire logic                 mem_diag_ready_i,
  input  wire logic                 mem_diag_rvalid_i,
  input  wire logic [DDW-1:0]       mem_diag_rdata_i,
  input  wire logic                 mem_diag_rerr_i,
  output logic                      diag_mode_o,

  // ---- events (pulse bits, same order as TEST_EV) -----------------------------------
  output logic [7:0]                ev_o
);

  // ---------------------------------------------------------------------------
  // scan / test-mode conditioning
  // ---------------------------------------------------------------------------
  logic scan_q, scan_prev_q, cgte_q, cgte_d;

  // Reset-path rule: this is a pure function of two pins, never of a flop that
  // the reset it controls would clear (sf_reset_sequencer takes it as test_mode_i).
  assign scan_mode_eff_o = scan_mode_i & test_permit_i;
  assign cgte_d = test_permit_i & (TE_FOLLOWS_SCAN_EN ? (scan_mode_i & scan_en_i) : icg_te_i);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      scan_q <= 1'b0; scan_prev_q <= 1'b0; cgte_q <= 1'b0;
    end else begin
      scan_q      <= scan_mode_eff_o;
      scan_prev_q <= scan_q;
      cgte_q      <= cgte_d;
    end
  end
  assign scan_active_o = scan_q;
  assign cg_test_en_o  = cgte_q | scan_q;
  assign scan_en_o     = scan_q & scan_en_i;

  logic scan_enter, scan_exit;
  assign scan_enter = scan_q & ~scan_prev_q;
  assign scan_exit  = ~scan_q & scan_prev_q;

  // ---------------------------------------------------------------------------
  // group <-> engine maps
  // ---------------------------------------------------------------------------
  logic [NE-1:0] grp_hold, grp_force, grp_block;
  always_comb begin
    grp_hold = '0; grp_force = '0; grp_block = '0;
    for (int g = 0; g < NG; g++)
      for (int e = 0; e < NE; e++)
        if (GRP_ENG[g*CW_MAXE + e]) begin
          grp_hold[e]  = grp_hold[e]  | dft_quiesce_req_i[g];
          grp_force[e] = grp_force[e] | dft_mbist_clk_req_i[g];
          grp_block[e] = grp_block[e] | dft_f_block_i[g];
        end
    for (int g = 0; g < NG; g++) begin
      dft_quiesce_ack_o[g] = dft_quiesce_req_i[g] && (&(eng_quiesced_i | ~GRP_ENG[g*CW_MAXE +: NE]));
      dft_f_busy_o[g]      = |(eng_busy_i    & GRP_ENG[g*CW_MAXE +: NE]);
      dft_f_req_o[g]       = |(eng_stalled_i & GRP_ENG[g*CW_MAXE +: NE]);
    end
  end

  // ---------------------------------------------------------------------------
  // MBIST sequencer
  // ---------------------------------------------------------------------------
  localparam logic [2:0] MB_S_IDLE = 3'd0, MB_S_HOLD = 3'd1, MB_S_START = 3'd2, MB_S_WBUSY = 3'd3,
                         MB_S_RUN  = 3'd4, MB_S_REL  = 3'd5;

  logic [2:0]  mb_q, mb_d;
  logic [3:0]  res_q, res_d;
  logic [15:0] tm_q, tm_d;
  logic        hold_q, hold_d;
  logic        start_p, abort_p;
  logic [7:0]  ev_d;
  logic        deny_take, deny_rsp;
  logic [NE-1:0] mask;
  logic [15:0] tlim;

  assign tlim = (cfg_mbist_tmo_i == 16'd0) ? 16'hFFFF : cfg_mbist_tmo_i;
  assign mask = mbist_eng_mask_i;

  logic all_quiet, all_active, any_bad;
  assign all_quiet  = &(eng_quiesced_i | ~mask);
  assign all_active = &(eng_active_i   | ~mask);
  assign any_bad    = |(eng_bad_i & mask);

  always_comb begin
    mb_d = mb_q; res_d = res_q; hold_d = hold_q; tm_d = (tm_q == 16'hFFFF) ? tm_q : tm_q + 16'd1;
    start_p = 1'b0; abort_p = 1'b0; ev_d = 8'h00;

    // T1 / mode conflict
    if (scan_mode_i && !test_permit_i) ev_d[0] = 1'b1;
    if (mbist_cmd_start_i && !test_permit_i) ev_d[0] = 1'b1;
    if (scan_enter) ev_d[3] = 1'b1;
    if (scan_exit)  ev_d[4] = 1'b1;

    case (mb_q)
      MB_S_IDLE: begin
        if (mbist_cmd_start_i) begin
          if (!test_permit_i || scan_q || mask == '0 || any_bad) begin
            res_d = MB_REFUSED; ev_d[1] = 1'b1;                       // T1, T4
          end else begin
            res_d = MB_RUNNING; hold_d = 1'b1; mb_d = MB_S_HOLD; tm_d = 16'd0;
          end
        end
      end
      MB_S_HOLD: begin
        if (scan_q)                 begin res_d = MB_ABORTED; ev_d[7] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0; end
        else if (mbist_cmd_abort_i) begin res_d = MB_ABORTED; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0; end
        else if (any_bad)           begin res_d = MB_REFUSED; ev_d[1] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0; end
        else if (all_quiet)         begin mb_d = MB_S_START; tm_d = 16'd0; end              // T3
        else if (tm_q >= tlim)      begin res_d = MB_TIMEOUT; ev_d[6] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0; end
      end
      MB_S_START: begin
        start_p = 1'b1; mb_d = MB_S_WBUSY; tm_d = 16'd0;
      end
      MB_S_WBUSY: begin
        if (scan_q)                 begin abort_p = 1'b1; res_d = MB_ABORTED; ev_d[7] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0; end
        else if (mbist_cmd_abort_i) begin abort_p = 1'b1; res_d = MB_ABORTED; mb_d = MB_S_RUN; tm_d = 16'd0; end
        else if (mbist_busy_i || mbist_done_i) begin mb_d = MB_S_RUN; tm_d = 16'd0; end
        else if (tm_q >= tlim)      begin abort_p = 1'b1; res_d = MB_TIMEOUT; ev_d[6] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0; end
      end
      MB_S_RUN: begin
        if (scan_q)                 begin abort_p = 1'b1; res_d = MB_ABORTED; ev_d[7] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0; end
        else if (mbist_cmd_abort_i && res_q != MB_ABORTED) begin abort_p = 1'b1; res_d = MB_ABORTED; end
        else if (mbist_done_i) begin
          if (res_q != MB_ABORTED)
            res_d = mbist_err_i ? MB_ERROR : (mbist_fail_i ? MB_FAIL : (mbist_pass_i ? MB_PASS : MB_ERROR));
          ev_d[5] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0;
        end else if (tm_q >= tlim && res_q != MB_ABORTED) begin
          abort_p = 1'b1; res_d = MB_TIMEOUT; ev_d[6] = 1'b1; hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0;
        end else if (tm_q >= tlim) begin
          hold_d = 1'b0; mb_d = MB_S_REL; tm_d = 16'd0;              // aborted and the engine never reported: give up
        end
      end
      MB_S_REL: begin
        hold_d = 1'b0;
        // engines return to ACTIVE after the hold drops; do not wait forever
        if (all_active || tm_q >= tlim) begin mb_d = MB_S_IDLE; tm_d = 16'd0; end
      end
      default: begin mb_d = MB_S_IDLE; hold_d = 1'b0; end
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mb_q <= MB_S_IDLE; res_q <= MB_NOT_RUN; tm_q <= 16'd0; hold_q <= 1'b0;
      mbist_start_o <= 1'b0; mbist_abort_o <= 1'b0; ev_o <= 8'h00;
    end else begin
      mb_q <= mb_d; res_q <= res_d; tm_q <= tm_d; hold_q <= hold_d;
      mbist_start_o <= start_p; mbist_abort_o <= abort_p; ev_o <= ev_d | {5'd0, deny_take, 2'd0};
    end
  end

  assign mbist_state_o      = mb_q;
  assign mbist_result_o     = res_q;
  assign mbist_busy_o       = (mb_q != MB_S_IDLE);
  assign mbist_test_mode_o  = (mb_q == MB_S_START) || (mb_q == MB_S_WBUSY) || (mb_q == MB_S_RUN);
  assign mbist_permit_o     = test_permit_i;
  assign mbist_cpu_halted_o = eng_quiesced_i[CPU_ENG];

  // ---------------------------------------------------------------------------
  // memory diagnostic access (T5)
  // ---------------------------------------------------------------------------
  logic diag_sel, diag_allow, deny_q, deny_d;
  logic [NE-1:0] diag_eng;
  assign diag_eng   = DIAG_ENG[NE-1:0];
  assign diag_sel   = test_permit_i && !scan_q && (tc_mode_i == TM_DIAG);
  assign diag_mode_o= diag_sel;
  assign diag_allow = diag_sel && (&(eng_quiesced_i | ~diag_eng));

  assign mem_diag_valid_o = diag_req_valid_i & diag_allow;
  assign mem_diag_we_o    = diag_req_we_i;
  assign mem_diag_addr_o  = diag_req_addr_i;
  assign mem_diag_wdata_o = diag_req_wdata_i;
  assign diag_req_ready_o = diag_allow ? mem_diag_ready_i : ~deny_q;

  assign deny_take = diag_req_valid_i & ~diag_allow & ~deny_q;
  assign deny_rsp  = deny_q & ~mem_diag_rvalid_i;

  always_comb begin
    deny_d = deny_q;
    if (deny_take) deny_d = 1'b1;
    else if (deny_rsp) deny_d = 1'b0;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) deny_q <= 1'b0;
    else         deny_q <= deny_d;
  end

  assign diag_rsp_valid_o = mem_diag_rvalid_i | deny_rsp;
  assign diag_rsp_rdata_o = mem_diag_rvalid_i ? mem_diag_rdata_i : {DDW{1'b0}};
  assign diag_rsp_err_o   = mem_diag_rvalid_i ? mem_diag_rerr_i : deny_rsp;

  // ---------------------------------------------------------------------------
  // outputs per engine
  // ---------------------------------------------------------------------------
  logic [NE-1:0] diag_hold;
  assign diag_hold = diag_sel ? diag_eng : '0;

  // an engine that depends on a held engine is quiesced first by the top-level
  // closure; here only the direct ownership is expressed
  assign test_hold_o      = (grp_hold | (hold_q ? mask : '0) | diag_hold) & {NE{~scan_q}};
  assign test_clk_force_o = grp_force | (hold_q ? mask : '0) | diag_hold | {NE{scan_q}};
  assign f_block_o        = grp_block;
  assign mem_inhibit_o    = {NE{scan_q | mem_inhibit_i}};

endmodule

`default_nettype wire
