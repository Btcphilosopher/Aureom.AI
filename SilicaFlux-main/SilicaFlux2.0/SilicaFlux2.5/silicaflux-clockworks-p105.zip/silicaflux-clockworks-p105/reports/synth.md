# Generic synthesis check (Yosys, technology-independent)

| module | synthesises | latch inferred | generic cells | flip-flops | note |
|---|---|---|---|---|---|
| sf_power_state_fsm | yes | no | 1161 | 70 |  |
| sf_clock_enable_ctrl | yes | no | 3043 | 277 |  |
| sf_reset_sequencer | yes | no | 3358 | 343 |  |
| sf_cw_wdt | yes | no | 2268 | 185 |  |
| sf_activity_counters | yes | no | 23938 | 7184 |  |
| sf_clock_test_adapter | yes | no | 550 | 38 |  |

## Clock-gate wrapper

* no ICG target selected + `SYNTHESIS`: **refuses to elaborate (sf_cw_icg_target_not_selected) - as intended**
* `SF_CW_ICG_LIB` with a library-cell blackbox: **elaborates, one library cell per engine**

`sf_cw_regs` and `sf_clock_power_ctrl` are not run through this script: the register file and the top level use SystemVerilog
features beyond Yosys 0.33's native frontend (unpacked arrays of packed vectors in ports of nested generates, wildcard imports of two packages).
They are covered by Verilator -Wall lint and by simulation; a full-chip synthesis needs the integrator's tool (Synopsys DC, Cadence Genus, or Yosys+slang).

Not shown: timing, real-library area, power, CDC / RDC signoff. See docs/clockworks/09_LIMITATIONS.md.
