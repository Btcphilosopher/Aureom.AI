# CLOCKWORKS power report

Activity source: RTL simulation (tb_cw_system), register-file snapshot (QUAL=1 SAVE=0 VOLATILE=0); total cycles 345.

## 1. Simulation activity (RTL cycle counts - NOT power)

| engine | cycles | active | idle (clock on) | disabled | enable duty | transitions | wake latency mean / max | quiesce latency mean | disable with outstanding |
|---|---|---|---|---|---|---|---|---|---|
| ControlCore | 345 | 0 | 197 | 148 | 0.571 | 10 | 12.5 / 13 | 5.0 | 0 |
| MemoryMatrix | 345 | 8 | 272 | 65 | 0.812 | 5 | 12.0 / 12 | 5.0 | 0 |
| Meridian | 345 | 0 | 268 | 77 | 0.777 | 10 | 16.0 / 20 | 5.0 | 0 |
| StreamDMA | 345 | 0 | 229 | 116 | 0.664 | 10 | 24.0 / 28 | 5.0 | 0 |
| TensorCore | 345 | 9 | 140 | 196 | 0.432 | 10 | 12.0 / 12 | 5.0 | 0 |
| PacketForge | 345 | 0 | 123 | 222 | 0.357 | 10 | 13.0 / 13 | 5.0 | 0 |

The enable duty is the fraction of cycles the clock ENABLE was high. It is an activity statistic of ONE simulation run;
it says nothing about energy until combined with real capacitance or library data below.

## 2. Analytical estimate

not computed (no --params given).

## 3. Library-based estimate

not computed (no --lib given). No library or PDK data exists in this repository for the SilicaFlux ASIC.

## 4. Measured hardware power

not available: no silicon or board measurement exists.

## Notes

* Savings are not stated: no comparison baseline with the same method was supplied.
