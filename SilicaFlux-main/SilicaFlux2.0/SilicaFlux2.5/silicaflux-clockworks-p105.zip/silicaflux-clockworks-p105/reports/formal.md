# Formal results (Yosys 0.33 + z3, no SymbiYosys available)

Depth 14 (FSM, enable controller) / 24 (reset sequencer).

| job | result | detail | time |
|---|---|---|---|
| ec | PROVED | unbounded: base case and induction step closed at k=3 | 0 s |
| fsm_cancel_rstwake | PROVED | unbounded: base case and induction step closed at k=1 | 2 s |
| fsm_plain | PROVED | unbounded: base case and induction step closed at k=1 | 2 s |
| fsm_save_cancel_sram | PROVED | unbounded: base case and induction step closed at k=1 | 2 s |
| fsm_sram_unqualified | PROVED | unbounded: base case and induction step closed at k=1 | 2 s |
| planted_M01 | FAILED | counterexample at step 9 (see build/formal/planted_M01.log) | 4 s |
| planted_M02 | FAILED | counterexample at step 8 (see build/formal/planted_M02.log) | 5 s |
| planted_M03 | FAILED | counterexample at step 6 (see build/formal/planted_M03.log) | 4 s |
| planted_M04 | FAILED | counterexample at step 4 (see build/formal/planted_M04.log) | 2 s |
| planted_M10 | FAILED | counterexample at step 10 (see build/formal/planted_M10.log) | 6 s |
| planted_M11 | FAILED | counterexample at step 4 (see build/formal/planted_M11.log) | 2 s |
| planted_M19 | FAILED | counterexample at step 5 (see build/formal/planted_M19.log) | 3 s |
| planted_M29 | FAILED | counterexample at step 4 (see build/formal/planted_M29.log) | 2 s |
| planted_M30 | FAILED | counterexample at step 10 (see build/formal/planted_M30.log) | 6 s |
| planted_rs_M06 | FAILED | counterexample at step 9 (see build/formal/planted_rs_M06.log) | 1 s |
| planted_rs_M07 | FAILED | counterexample at step 10 (see build/formal/planted_rs_M07.log) | 1 s |
| planted_rs_M22 | FAILED | counterexample at step 10 (see build/formal/planted_rs_M22.log) | 2 s |
| rs_power_on | BOUNDED | all assertions hold for 24 steps from reset; induction step did not close | 8 s |
| rs_requests | BOUNDED | all assertions hold for 24 steps from reset; induction step did not close | 9 s |

`planted_*` runs the same FSM properties on a deliberately broken copy; FAILED is the expected result and shows
that the properties detect the defect (they are not vacuous). PROVED means the base case and the induction step
both closed, i.e. the property holds for every reachable state under the stated environment assumptions;
BOUNDED means it holds for the stated number of steps from reset only.
