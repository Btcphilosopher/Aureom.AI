# CLOCKWORKS regression report

Generated 2026-11-19 12:20:04 by `tools/regress.py lint units sim_vl sim_ic power formal synth mutate`.

| stage | check | result | detail |
|---|---|---|---|
| lint | sf_power_state_fsm | PASS | clean |
| lint | sf_clock_enable_ctrl | PASS | clean |
| lint | sf_reset_sequencer | PASS | clean |
| lint | sf_cw_wdt | PASS | clean |
| lint | sf_activity_counters | PASS | clean |
| lint | sf_clock_test_adapter | PASS | clean |
| lint | sf_cw_regs | PASS | clean |
| lint | sf_cw_clock_gate | PASS | clean |
| lint | sf_cw_icg_wrap | PASS | clean |
| lint | sf_clock_power_ctrl | PASS | clean |
| lint | sf_cw_checker | PASS | clean |
| units | register map in sync | PASS | generated files match |
| units | vendored cells unmodified | PASS | SHA-256 match |
| units | power-tool self-checks | PASS | OK |
| units | unit_enable_ctrl | PASS | 2159986 checks |
| units | unit_power_state_fsm | PASS | 3656797 checks |
| units | unit_icg | PASS | 51072 checks |
| sim_vl | default seed 1 | PASS | 1088 checks |
| sim_vl | default seed 2 | PASS | 1076 checks |
| sim_vl | default seed 3 | PASS | 1074 checks |
| sim_vl | default seed 4 | PASS | 1081 checks |
| sim_vl | default seed 5 | PASS | 1082 checks |
| sim_vl | default seed 6 | PASS | 1071 checks |
| sim_vl | defpol seed 1 | PASS | 143 checks |
| sim_vl | save_volatile seed 1 | PASS | 1134 checks |
| sim_vl | neg_control seed 1 | PASS | 1134 checks (negative control: corruption detected as expected) |
| sim_ic | default seed 1 | PASS | 1075 checks |
| sim_ic | default seed 2 | PASS | 1088 checks |
| sim_ic | default seed 3 | PASS | 1072 checks |
| sim_ic | default seed 4 | PASS | 1072 checks |
| sim_ic | default seed 5 | PASS | 1071 checks |
| sim_ic | default seed 6 | PASS | 1075 checks |
| sim_ic | defpol seed 1 | PASS | 143 checks |
| sim_ic | save_volatile seed 1 | PASS | 1121 checks |
| sim_ic | neg_control seed 1 | PASS | 1121 checks (negative control: corruption detected as expected) |
| sim_ic | icg seed 1 | PASS | 1075 checks |
| power | activity export from simulation | PASS | reports/activity_demo.json |
| power | VCD -> activity / SAIF | PASS | tb_cw_system.clk_en [0] duty=0.774 toggles=4 [1] duty=0.901 toggles=2 [2] duty=0.883 toggl |
| power | report (no params: nothing invented) | PASS | reports/power_report_demo.md |
| formal | fsm_plain | PASS | PROVED unbounded: base case and induction step closed at k=1 [2s] |
| formal | fsm_cancel_rstwake | PASS | PROVED unbounded: base case and induction step closed at k=1 [2s] |
| formal | fsm_save_cancel_sram | PASS | PROVED unbounded: base case and induction step closed at k=1 [2s] |
| formal | ec | PASS | PROVED unbounded: base case and induction step closed at k=3 [0s] |
| formal | fsm_sram_unqualified | PASS | PROVED unbounded: base case and induction step closed at k=1 [2s] |
| formal | planted_M01 | PASS | FAILED counterexample at step 9 (see build/formal/planted_M01.log) [4s] |
| formal | rs_power_on | PASS | BOUNDED all assertions hold for 24 steps from reset; induction step did not close [8s] |
| formal | rs_requests | PASS | BOUNDED all assertions hold for 24 steps from reset; induction step did not close [9s] |
| formal | planted_M02 | PASS | FAILED counterexample at step 8 (see build/formal/planted_M02.log) [5s] |
| formal | planted_M04 | PASS | FAILED counterexample at step 4 (see build/formal/planted_M04.log) [2s] |
| formal | planted_M03 | PASS | FAILED counterexample at step 6 (see build/formal/planted_M03.log) [4s] |
| formal | planted_M11 | PASS | FAILED counterexample at step 4 (see build/formal/planted_M11.log) [2s] |
| formal | planted_M19 | PASS | FAILED counterexample at step 5 (see build/formal/planted_M19.log) [3s] |
| formal | planted_M10 | PASS | FAILED counterexample at step 10 (see build/formal/planted_M10.log) [6s] |
| formal | planted_M29 | PASS | FAILED counterexample at step 4 (see build/formal/planted_M29.log) [2s] |
| formal | planted_rs_M06 | PASS | FAILED counterexample at step 9 (see build/formal/planted_rs_M06.log) [1s] |
| formal | planted_rs_M07 | PASS | FAILED counterexample at step 10 (see build/formal/planted_rs_M07.log) [1s] |
| formal | planted_rs_M22 | PASS | FAILED counterexample at step 10 (see build/formal/planted_rs_M22.log) [2s] |
| formal | planted_M30 | PASS | FAILED counterexample at step 10 (see build/formal/planted_M30.log) [6s] |
| synth | generic synthesis, no latches, ICG refusal | PASS | reports/synth.md |
| mutate | mutation check | PASS | killed 33/33; survivors []; errors [] |

**60 / 60 checks passed.**
