# Mutation check

Configuration: default configuration (QUAL=1 SAVE=0). 33 mutants, **33 killed**, 0 survived, 0 errors (649 s, 3 parallel jobs).

| id | mutant | result | evidence |
|---|---|---|---|
| M01 | FSM leaves DRAINING without the quiescence vector | KILLED | CW_CHECK_FAIL C06 engine=5 t=2585000 |
| M02 | new-work gate not closed on entry to DRAINING | KILLED | CW_CHECK_FAIL C05 engine=5 t=2575000 |
| M03 | wake does not wait for DataFabric reconnection | KILLED | CW_CHECK_FAIL C09 engine=1 t=305000 |
| M04 | wake does not wait for providers | KILLED | FAIL @5046000: idle_wake: providers woken by cascade |
| M05 | ledger ignores retire events | KILLED | FAIL @67026000: dma: all 12 jobs complete |
| M06 | reset hold time collapses to zero edges | KILLED | FAIL @28936000: reset: every reset held >= HOLD clock edges delivered to the engine |
| M07 | reset release ignores provider rank | KILLED | FAIL @456000: boot: Meridian released only after MemoryMatrix completed its reset sequence |
| M08 | no closure: dependents not reset with their provider | KILLED | FAIL @68366000: reset: Meridian and its active masters return to ACTIVE |
| M09 | ledger not cleared while the engine is in reset | KILLED | FAIL @82376000: mbist: MM quiesced for the test |
| M10 | drain timeout disables the clock instead of faulting | KILLED | CW_CHECK_FAIL C06 engine=5 t=22445000 |
| M11 | illegal transition FAULT -> ACTIVE on a wake request | KILLED | CW_CHECK_FAIL C02 engine=0 t=109575000 |
| M12 | quiescence ignores the transaction ledger | KILLED | CW_CHECK_FAIL C06 engine=2 t=23225000 |
| M13 | MBIST starts without waiting for quiescence | KILLED | FAIL @82376000: mbist: MM quiesced for the test |
| M14 | scan mode does not force the clocks on | KILLED | CW_CHECK_FAIL C13 engine=4 t=77235000 |
| M15 | hysteresis counter restarts in IDLE_REQUESTED (the bug found during bring-up) | KILLED | FAIL @10886000: idle_wake: provider proceeds on its own once the masters are disabled |
| M16 | provider may stop while its dependents are active | KILLED | FAIL @2526000: idle_wake: provider asked first waits for its dependents |
| M17 | a waking dependent does not wake its providers | KILLED | FAIL @53046000: idle_wake: everything back |
| M18 | progress watchdog never fires | KILLED | FAIL @33796000: wdt: progress watchdog reset the hung engine |
| M19 | FSM gate reopens before local readiness | KILLED | by unit_power_state_fsm: FAIL cfg1 @1305000: S3: reopen after readiness and fabric reconnection |
| M20 | register file ignores CTRL.EN | KILLED | FAIL @1016000: regs: EN=0 rejects requests (REJ_DISABLED) |
| M21 | DISABLED counter does not count | KILLED | FAIL @117356000: counters: ACTIVE + IDLE + DISABLED equals the total cycle count |
| M22 | reset hold counts cycles without a delivered clock | KILLED | by formal reset-sequencer properties: FAILED (counterexample at step 10 (see build/formal/mut_rs_M22.log)) |
| M23 | double fault: FSM skips quiescence AND the enable interlock is removed | KILLED | CW_CHECK_FAIL C06 engine=5 t=2585000 |
| M24 | interlock alone removed (backstop: redundant with a correct FSM at system level) | KILLED | by unit_enable_ctrl: FAIL @230000: clock enable function |
| M25 | quiescence stability window ignored | KILLED | by unit_enable_ctrl: FAIL @50000: quiescence stability window |
| M26 | wake events do not wake a disabled engine | KILLED | FAIL @67026000: dma: all 12 jobs complete |
| M27 | SRAM retention rule not enforced | KILLED | by system regression with -GDEFPOL=1: FAIL @1676000: policy: engine with unqualified SRAM refused (REJ_SRAM) |
| M28 | system watchdog stage 2 does not reset | KILLED | FAIL @40726000: wdt: system watchdog stage 2 resets the engines |
| M29 | unsupported request codes accepted as no-ops | KILLED | FAIL @81056000: unsup: unsupported target state rejected with the right code |
| M30 | explicit save not waited for (SAVE_EN builds) | KILLED | by unit_power_state_fsm: FAIL cfg1 @9985000: S2: CLOCK_DISABLED only from DRAINING with quiescence (and save) |
| M31 | idle detector never requests an automatic idle | KILLED | FAIL @30656000: auto: the idle detector disables the engine by itself |
| M32 | ICG ignores the test enable | KILLED | by unit_icg: FAIL gated flop != enable flop |
| M33 | clock gated with a plain AND instead of a latch-based ICG | KILLED | by unit_icg: FAIL runt / truncated gated pulse: 0 |
