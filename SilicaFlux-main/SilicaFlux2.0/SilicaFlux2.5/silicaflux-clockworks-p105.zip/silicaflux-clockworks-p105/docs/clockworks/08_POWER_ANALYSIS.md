# 08 - Activity instrumentation and power analysis

> **This package contains no power figure.** It produces the *activity* that a power estimate needs, and tools that refuse to
> print a number whose inputs were not supplied.

## 1. Four kinds of number, never mixed

| Kind | What it is | Produced by | Available here |
|---|---|---|---|
| **Simulation activity** | cycle counts and toggle statistics from an RTL simulation | `sf_activity_counters` (register file), `tools/vcd_activity.py` (VCD, SAIF) | yes |
| **Analytical estimate** | `P = C V^2 f x duty` with **user-supplied** C, V, f | `tools/power_report.py --params` | only with your parameters; labelled with them |
| **Library-based estimate** | per-engine clock-tree power at 100 % enable from a power tool run on a real netlist with real library data, scaled by the simulated duty | `tools/power_report.py --lib` | only with that data; **none exists for this ASIC** |
| **Measured hardware power** | silicon / board measurement | outside this package (echoed from `--measured`, never computed) | no |

## 2. Counters (brief section 11)

Per engine, 32-bit saturating, coherent snapshot (`CMD = SNAPSHOT`), read through `0x400 + engine*0x80 + 4*metric`:

| Metric | Meaning |
|---|---|
| ACTIVE / IDLE / DISABLED | cycles with the clock enable high and the engine busy / high and idle / low. **ACTIVE + IDLE + DISABLED = total cycles** (checked in the regression) |
| TRANS | state transitions |
| WAKE_CNT / SUM / MAX / LAST | **wake latency**: cycles in WAKE_REQUESTED for wakes that started in CLOCK_DISABLED |
| QUI_CNT / SUM / MAX / LAST | **quiescence latency**: cycles in DRAINING for drains that ended in CLOCK_DISABLED |
| RST_EVENTS | **reset events** (sequences started) |
| OUT_CHG_MAX / SUM, CHG_WITH_OUT | **outstanding transactions at state changes** |
| DIS_WITH_OUT | entries to CLOCK_DISABLED with outstanding work - a safety counter, **must be 0** |
| CANCEL_CNT | cancels issued to drain |

Cost: the counters and their snapshot copy are about 7,200 flip-flops for six engines (`reports/synth.md`). That is
instrumentation area; an integrator who only needs a subset should narrow `NMET` / the counter width before tape-out.

## 3. Workflow

```
make power            # runs the idle_wake scenario, exports reports/activity_demo.json and a VCD,
                      #   VCD -> SAIF (reports/clk_en_demo.saif), report with NO parameters
python3 tools/power_report.py --activity reports/activity_demo.json            # sections 2-4 say "not computed"
python3 tools/power_report.py --activity act.json --params my_params.json      # + analytical (your assumptions)
python3 tools/power_report.py --activity act.json --lib lib_power.json         # + library-based (your tool run)
```
`params.json`: `{"assumptions": "...", "engines": {"StreamDMA": {"clock_cap_fF": ..., "V": ..., "f_MHz": ...}}}`.
`lib_power.json`: `{"provenance": "tool, netlist, corner, date", "engines": {"StreamDMA": {"clock_tree_mW_at_full_enable": ..., "leakage_mW": ..., "icg_overhead_mW": ...}}}`.

## 4. Rules the tools enforce

* No energy **saving** is ever printed: a saving needs a baseline produced by the same method, which the tools do not have.
* The enable duty is an activity statistic of one run, not an energy ratio: leakage, data-path switching and SRAM macros are
  not proportional to it, and the ICG itself costs power.
* `power_report.py` self-checks (`tests/clockworks/test_power_tools.py`) use **synthetic fixtures**, flagged as such, to verify
  the arithmetic and the refusal behaviour; they say nothing about any chip.

## 5. SAIF notes

`vcd_activity.py` writes T0 / T1 / TX / TC per net from the VCD. The net names are the RTL names found in the dump; map them to
the hierarchy of the synthesised netlist (`--design`, post-processing) before `read_saif`. A SAIF from RTL simulation is
*RTL-level* activity: gate-level glitching and clock-tree internals are not in it.
