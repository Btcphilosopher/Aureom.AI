# 09 - Limitations, blocked items, what is NOT claimed

## Not claimed

| Not claimed | Why / what exists instead |
|---|---|
| A physically qualified clock tree, PLL, or clock-gating network | no library, CTS or PLL exists; `physical/clockworks/` holds templates |
| A power-gating / low-power physical implementation | no power switch, isolation or retention cell, no UPF flow: `PD_SUPPORT = 0` |
| That SRAM data survives a clock stop or power-off | only the `SRAM_QUAL` / `SAVE_EN` flags, set by a human from the macro datasheet; the simulation array proves nothing |
| Any power figure, energy saving or percentage | none is produced (`08_POWER_ANALYSIS.md`) |
| Scan insertion, ATPG, fault coverage | the adapter conditions control signals only |
| Timing, CDC / RDC signoff, gate-level behaviour | no tools or libraries; templates only |
| That the real engines honour the quiescence contract | the bench models do; the real engines were not co-simulated (L1) |

## Open limitations

| # | Limitation | Consequence / mitigation |
|---|---|---|
| L1 | **Bench engine models, not the real engines.** MemoryMatrix, Meridian, StreamDMA, TensorCore, PacketCore, ControlCore were audited but not instantiated; the integration table is proposed. | Co-simulate each engine with the controller before relying on it; the contract (E1-E5) is the acceptance test. |
| L2 | **Reference topology is an assumption.** `DEP_MASK`: masters -> Meridian -> MemoryMatrix; ranks MM < MR < DMA/TC/PF < CC. | Change the parameters; the rank / dependency consistency is checked at elaboration. |
| L3 | **PacketForge** is PacketCore by assumption (audit F2). | Rename if another block is meant. |
| L4 | **Real-engine event wiring (E2/E3) is the integrator's work.** A missing retire, or an unqualified pulse, makes the ledger drift; the controller reports a ledger violation (`FC_LEDGER`, fault) and never silently ignores it, but cannot repair it. | `LEDGER_EN[e] = 0` for an engine whose events are not wired, **and** then rely on its own idle signal and a clear `QCFG.mask`. |
| L5 | **Single functional clock only.** A second domain needs the CDC treatment listed in `physical/clockworks/clock_domain_boundary.md`. | not implemented |
| L6 | **No clock-loss detector of its own.** | needs `clk_ok_i` from a reference-clock monitor (P35). |
| L7 | **Formal**: the FSM and enable-controller properties are *proved* (temporal induction) under stated environment assumptions; the reset sequencer is *bounded* (24 steps) because its counters keep the induction step open; no unbounded proof of the system. No SymbiYosys; Yosys `sat` + z3 only. | see `reports/formal.md` |
| L8 | **Mutation**: the campaign (33 mutants) lists the survivors and why (`reports/mutation.md`). One mutant (M22) is only observable through the formal properties, because the top-level clock-return feedback is the enable flop itself. | |
| L9 | **Counters area**: about 7,200 flops for 18 metrics x 6 engines (live + snapshot). | narrow before tape-out (`08_POWER_ANALYSIS.md`). |
| L10 | **`sf_cw_regs` has no privilege model**; `GLOBAL_RESET` needs a key only. | place behind the platform's access control. |
| L11 | **Synthesis smoke covers six modules in Yosys.** The register file and the top use SystemVerilog beyond Yosys 0.33's frontend; they are Verilator `-Wall` clean and simulated. | full-chip synthesis needs the integrator's tool. |
| L12 | **Gate-level simulation was not run.** | needs a netlist and SDF. |
| L13 | **ICG cell pin names for IHP / SKY130 / Nangate45 are copied from P35 / P40**, not re-verified here. | `ICG_QUALIFICATION.md`. |
| L14 | **Overflow of the ledger** (more than 1023 outstanding per engine at `OW = 10`) saturates and faults. | widen `OW`. |
| L15 | **Zombie retire accounting for providers** is a fabric obligation (E4); if the fabric does not retire discarded responses, the provider can never go quiet and will FAULT on its next drain (clock on). | by design: fail safe. |
| L16 | **Simulation differences**: Verilator is 2-state, Icarus 4-state; the bench counters ignore X pulses at time 0 so both agree. The random streams differ between the simulators, so cycle counts differ. | both pass every configuration. |

## Blocked in this environment

| Item | State | Why |
|---|---|---|
| STA, CTS, CDC / RDC, LEC, gate-level sim | **not run** | no tool / library / netlist |
| UPF validation | **not run** | no UPF tool |
| SymbiYosys | **not available** | not installable here; Yosys `sat` used |
| Real-engine co-simulation | **not done** | out of scope for this deliverable (L1) |
