# 10 - Physical implementation and signoff: what remains

Nothing in this list has been done. Each item names the input it needs.

| # | Step | Needs | Output expected | Check against |
|---|---|---|---|---|
| 1 | Qualify the ICG cell | Liberty, databook | filled `ICG_QUALIFICATION.md` (13 rows) | STA, gate-level `tb_cw_icg.sv` |
| 2 | Qualify every SRAM macro for clock stop / CE hold | macro datasheets | `SRAM_QUAL[e]` per engine | datasheet |
| 3 | Fill the SDCs, add scenarios (func / test x corners) | clock plan, IO plan | signed constraints | `timing_exceptions.md` |
| 4 | Multi-corner STA incl. clock-gating checks and recovery / removal | libs, netlist, SPEF | slack reports | `sta_clockworks.tcl` |
| 5 | CTS balancing of gated vs ungated sinks | placed design | skew report | row 9 of the ICG checklist |
| 6 | Structural CDC / RDC signoff | commercial tool | clean report | `clock_domain_boundary.md`, rules R1-R6 |
| 7 | RTL-vs-netlist equivalence | LEC tool | clean | |
| 8 | Gate-level simulation with SDF (reset, wake, ICG glitch-freedom) | netlist + SDF | pass | re-run the bench on the netlist |
| 9 | UPF flow (only if a power network is added) | UPF tool, low-power cells | validated power intent | `06_POWER_STATES_UPF.md` |
| 10 | DFT: scan insertion, ATPG, MBIST integration | DFT flow | coverage | `07_DFT_INTERFACES.md` |
| 11 | Power analysis with real activity | netlist, libs, SAIF from a real workload | library-based report | `08_POWER_ANALYSIS.md` |
| 12 | Real-engine co-simulation and contract review | engine owners | per-engine sign-off of E1-E5 | `INTEGRATION.md` |
| 13 | Narrow the activity counters | area budget | smaller `NMET` / width | |

Use the actual clock libraries and technology constraints when available; the periods and budgets in the SDC templates are
placeholders.
