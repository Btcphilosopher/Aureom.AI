# 03 - Quiescence: how an engine is safely stopped

> Never stop a clock while the engine holds unresolved transactions without a verified recovery mechanism.

## 1. The engine contract (what an engine must provide)

| # | Rule |
|---|---|
| E1 | The engine accepts new work only through a channel the integrator gates with `accept_en_o` (the `sf_cmd_gate` pattern: a transfer already offered is never torn, it completes). It reports a transfer *offered but not accepted* as `in_offered_i`, and work held back by the closed gate as `up_stalled_i` (that is the wake request). |
| E2 | Every transaction it issues to the fabric is counted: `issue_cnt_i` when it enters the engine / fabric, `retire_cnt_i` when its response is delivered **or discarded**. Each issue is matched by exactly one retire. |
| E3 | Event pulses are qualified with the engine's clock enable (or generated in an always-on domain). A registered pulse on a stopped clock stays high. The quiet condition guarantees every pulse is already low when the clock stops. |
| E4 | When the engine is reset, responses still owed to it are *discarded by the fabric and counted as retire events* (Meridian: `zomb_flush`). The controller clears the engine's own ledger for the whole reset sequence. |
| E5 | `eng_idle_i` is low whenever the engine holds work internally (queue, in-flight, output buffer). It must be a function of state that is frozen while the clock is off. |

The bench models (`tests/clockworks/cw_models.sv`) implement E1-E5 and freeze completely when `ce = 0`. They are
**models of the contract, not the real engines**; the real ports are mapped in `INTEGRATION.md` and have not been
co-simulated (`09_LIMITATIONS.md`).

## 2. The quiescence vector

`sf_clock_enable_ctrl` computes six named conditions per engine; `QCFG.mask` selects which are required (default: all)
and `QCFG.quiet_cyc` (default 4) is the number of consecutive cycles the required set must hold before `quiet` rises.

| Bit | Condition | Brief item | Source |
|---|---|---|---|
| Q_WORK_STOP | gate closed **and** no transfer offered at the input | stop accepting new work | `accept_en_o`, `in_offered_i` |
| Q_OUTSTANDING | transaction ledger == 0 | drain / cancel outstanding requests | `issue_cnt_i - retire_cnt_i` |
| Q_OBUF | output buffers / response FIFOs empty | confirm output buffers | `eng_obuf_empty_i` |
| Q_DMA | no DMA / completion record outstanding | confirm DMA completion | `eng_dma_idle_i` |
| Q_MEM | memory interface idle | confirm memory-interface state | `eng_mem_idle_i` |
| Q_IDLE | engine-internal idle | - | `eng_idle_i` |

An engine that lacks a signal ties it to 1 **and** says so by clearing the bit in its `QCFG.mask` - an unconnected
condition that is tied high and still required would be a claim the hardware does not support. Meridian is the example:
no idle port at all, so its mask is `Q_WORK_STOP | Q_OUTSTANDING` (0x03) and the ledger *is* its quiescence.

## 3. Cancel

An engine with a safe cancel (`CAN_CANCEL`, e.g. StreamDMA `ctl_abort`) gets one `cancel_o` pulse when the drain
timeout expires, then a second timeout (`cancel_tmo`). Queued work that had not started is dropped and counted
(`SE_CANCEL`, `CANCEL_CNT`); work already in flight completes normally. An engine without cancel goes to **FAULT with its
clock running**. Never "cancel by stopping the clock".

## 4. The hardware interlock (backstop, not mechanism)

`clk_en_d = clk_run | reset_force | test_force | test_en | busy`, with `busy = !eng_idle | ledger != 0 | in_offered`.
The enable therefore **cannot fall while the engine is busy**, whatever the FSM asked. If the FSM wanted the clock off
and the interlock disagrees, `ilk_hit` is raised as fault `FC_ILK` (the engine goes to FAULT, clock on): a disagreement
means a sequencing bug or a wrongly wired idle signal, and is never silently masked. The checker requires that the
interlock never fires in a correct run (C12). At system level the interlock is redundant with a correct FSM, so removing it
alone is not visible to the system regression; it is caught by the enable-controller unit bench (exact enable function,
mutant M24) and by the double fault "FSM skips quiescence **and** interlock removed" (M23), which every layer kills.

## 5. Architectural state and memory

* **Clock gating by itself**: flops hold their value (the engine is written `if (ce)`); SRAM macros hold data **if** the
  macro datasheet allows the clock / enable to stop. `SRAM_QUAL[e]` asserts that qualification, per engine. Without it
  (or `SAVE_EN`), the FSM refuses the idle request (`REJ_SRAM`). This rule is the only thing standing between the RTL
  simulation - where an array "retains" anything - and a real macro.
* **Explicit save / restore** (`SAVE_EN`): `save_req_o` in DRAINING and `restore_req_o` in WAKE_REQUESTED, each with a
  done handshake that needs the clock running. It is a hook for engines that will be power-gated; the bench proves the
  sequencing (state survives a bench-injected supply loss with `SAVE_EN = 1`, and is detected as lost with `SAVE_EN = 0`),
  not any real retention technology.

## 6. What the tests prove about quiescence

* Every entry to CLOCK_DISABLED: nothing inside the engine model, ledger zero (`DIS_WITH_OUT` counter and a bench monitor).
* Jobs are conserved: accepted = completed + cancelled + lost-to-reset + still inside, every cycle.
* A master stuck with transactions outstanding makes its provider **fault, not stop** (`pending_fabric`).
* Idle requested with a DMA transfer and a tensor operation in flight, and with pending DataFabric responses: no job lost.
