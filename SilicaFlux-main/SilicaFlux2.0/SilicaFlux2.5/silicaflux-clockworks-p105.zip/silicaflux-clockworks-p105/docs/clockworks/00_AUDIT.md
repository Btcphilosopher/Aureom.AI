# 00 - Repository audit

Scope: the SilicaFlux repository as delivered (`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/*.zip`). Every archive
below was extracted read-only and its RTL, README and documents read. Nothing in them was modified. Evidence is cited
as `archive :: path`.

## 1. What was inspected and what it gave

| Item (brief) | Archive | What it already provides | Consequence for CLOCKWORKS |
|---|---|---|---|
| **PowerClock** | `silicaflux-powerclock` (P27) | Power manager for ONE core with vector / tensor unit gates: state FSM, sequencer with acknowledged steps and timeouts, ICG wrapper that *fails synthesis* when no target is selected, `sf_cmd_gate` (never tears an offered transfer), 2-phase handshake CDC, activity monitor, thermal monitor. It was written WITHOUT access to this repository (its `docs/01_audit.md` says so). No power-off states. | Conventions reused (ICG wrapper rule, "enable = requested OR busy" interlock, acknowledged-step sequencing, timeouts that fault rather than wait). `sf_cmd_gate` reused in the bench. CLOCKWORKS generalises the per-engine layer to six engines with dependency ordering, a transaction ledger and reset closure. |
| **Clock / reset modules** | `silicaflux-clocktree` (P35), `silicaflux-p40-floorplanbuild` | P35: die-level reference clock, clock monitor, root ICG, reset sequencer with acknowledged releases, system watchdog, branch gates with a `clk_req` / wake contract, CDC library, SDC generator, CTS scripts; 9 negative CDC tests. P40: `sf_reset_sync`, `sf_sync2`, Nangate45 ICG binding. | `sf_reset_sync` and `sf_sync2` vendored **unmodified** (SHA-256 in `third_party/`). P35's rules adopted: reset path = one flop into a synchroniser (audit F-04), reset asserts without a clock, release is acknowledged, test-mode bypass. P35 stays the owner of the clock ROOT and the PLL boundary (see section 3). |
| **DataFabric** | `silicaflux-datafabric` (P03, SFB bus) , `silicaflux-meridian-p83`, `silicaflux-meridianqos-p102` | P03: bus + DMA. P83 / P102 Meridian: registered crossbar, tags, ownership, timeouts, `zomb_flush`, `o_iso` port isolation. | Meridian is the interconnect engine of the reference set. **It has no idle / quiesce output at all** (finding F1). "DataFabric reconnection" = Meridian port connect with an acknowledge. |
| **MemoryMatrix** | `silicaflux-memorymatrix-p101` | Banked SRAM subsystem with `quiesce_i`, `idle_o`, `flush_i` / `flush_busy_o`, `init_busy_o`, ECC scrub. `quiesce_i` blocks new master requests (`blocked = flushing \| flush_i \| quiesce_i`); `idle_o = inflight==0 & banks idle & master queues empty`. | The only engine with a ready-made quiesce / idle pair. Port mapping in `INTEGRATION.md`. |
| **ControlCore** | `silicaflux-controlcore` (P21) | RV32 control core, its own PMU `cc_pmu` (gates the ACCELERATOR clock: `acc_clk_en`, `acc_rst_req`, `acc_iso`; inputs `cpu_sleep`, `vec_busy`, `tsu_busy`, `ext_idle`), `cc_sysctrl` (soft / watchdog / host reset), watchdog. | CLOCKWORKS gates the ControlCore engine as a whole; `cc_pmu` keeps its accelerator sub-domain. Ownership rule: `cc_pmu.acc_rst_req` must not reset the ControlCore itself. |
| **TensorCore** | `silicaflux-tensorcore01..10` | 01-10 are pieces (PE, buffers, DMA adapter 07, benchmarks). TENSORCORE 07 `tensor_dma_adapter` has `busy`. | `eng_idle_i[TC]` <- the tile system's busy; output-buffer and DMA-completion conditions map to Q_OBUF / Q_DMA. |
| **StreamDMA** | `silicaflux-streamdma-p103-r2` | `busy`, `fenced`, `ctl_abort` (cancel), `ctl_soft_reset`, `soft_reset_pending/active`, completion port, bursts with IDs. Data buffer is a flop FIFO (no SRAM macro found). | `cancel_o[DMA]` -> `ctl_abort`; `busy` -> `!eng_idle`; completion queue -> Q_DMA. |
| **PacketForge** | *(no module of that name)* `silicaflux-packetcore-p62` | Meridian's README lists PacketForge as a master; the nearest implementation is the PacketCore packet engine `silicaflux_packet_engine` with an `idle` output. | Finding F2: PacketForge = PacketCore in the reference set. |
| **MemoryTest** | `silicaflux-memorytest-p78` | `sf_sram_mbist`: `start_i`, `abort_i`, `busy_o`, `done_o`, `pass_o`, `fail_o`, `error_o`, `test_mode_i`, `test_permit_i`, `cpu_halted_i`, `protect_i`. | Test adapter drives exactly these. |
| **TestCore / existing DFT** | `silicaflux-testcore(-p07)`, `silicaflux-dftgrid-p39` | DFTGrid already exports `quiesce_req / quiesce_ack`, `f_block`, `f_busy`, `f_req`, `mbist_clk_req`, `dft_test_mode`, `dft_icg_te`, `dft_scan_en`, `dft_test_rst_n`, `dft_mem_inhibit`, and TestCore `mode`. TestCore r1 had a root clock mux that is glitch-free only by protocol (P35 F-03). | The adapter speaks the DFTGrid dialect signal for signal. No clock mux is introduced. |
| **PowerFabric** | `silicaflux-powerfabric-p36` | Power-domain FSM, isolation, SRAM retention study, UPF validation. | Source of the retention / isolation vocabulary; the UPF here is a template pointing to it. |

## 2. Findings

| # | Severity | Finding | Disposition |
|---|---|---|---|
| F1 | High | **Meridian (P83 / P102) has no idle or quiesce port.** Whether it is quiet can only be derived from its handshakes. | `sf_clock_enable_ctrl` keeps a **transaction ledger** (issue minus retire events) per engine; quiescence of Meridian is the ledger alone (`QCFG.mask = 0x03`). |
| F2 | Medium | "PacketForge" does not exist by that name. | Treated as PacketCore P62 (`idle`). Recorded; rename in the integration if a different block is meant. |
| F3 | Medium | Three blocks already drive engine clock enables / resets: P27 `sf_pm_fsm`, P35 `sf_crt_seq` (+ branch gates), P40 stand-in `sf_power_mgr`, and `cc_pmu` inside ControlCore. Two owners of one reset or one enable is a bug. | Ownership rules in `01_ARCHITECTURE.md` section 5 and `INTEGRATION.md`: CLOCKWORKS owns the per-engine enables and resets of the six engines; P35 owns the clock root, PLL boundary and POR; P27's core gate must not coexist with the P35 root gate (P35 limitation 3, unchanged). |
| F4 | Medium | Engine event pulses on a gated clock freeze HIGH when the clock stops (a registered pulse does not clear). A ledger that counts them would drift. | Rule E3 in `03_QUIESCENCE.md`: qualify event pulses with the engine's clock enable; the quiet condition guarantees they are already low when the clock stops; the bench models do this. |
| F5 | Medium | A reset of a master with transactions in flight leaves the provider owing responses. | Reset clears the ledger of the engine under reset; providers must still retire the zombie responses (Meridian's `zomb_flush`). Rule E4. Exercised by the `pending_fabric` and `reset_activity` scenarios. |
| F6 | Low | No SymbiYosys in the environment. | Formal uses Yosys `sat` (temporal induction) directly; see `11_VERIFICATION.md`. Same tool versions as P35 / P83 (Verilator 5.020, Yosys 0.33). |
| F7 | Info | No ASIC library, PDK or STA tool is available for the SilicaFlux ASIC. | Everything physical is a template (`physical/clockworks/`). |

## 3. Reused components

| Reused | From | How |
|---|---|---|
| `sf_reset_sync.sv`, `sf_sync2.sv` | P40 | vendored, unmodified, instantiated (`third_party/silicaflux_p40/`, `PROVENANCE.md`, `SHA256SUMS`) |
| `sf_cmd_gate.sv` | P27 | vendored, bench only: models how an integrator applies `accept_en_o` to a valid/ready channel |
| ICG wrapper convention ("select a target or fail synthesis") | P27 / P35 | re-implemented as `sf_cw_clock_gate` (one define selects the cell) |
| ICG pin names for IHP SG13G2 / SKY130 / Nangate45 | P35 / P40 tech files | recorded in `physical/clockworks/tech/`, NOT re-verified here |
| Reset discipline R1-R6 | P35 `02_RESET_DOMAINS.md` | `sf_reset_sequencer` |
| `quiesce_req/ack`, `f_block`, `mbist_clk_req`, `dft_*` | P39 | `sf_clock_test_adapter` |
| MBIST start / status contract | P78 | `sf_clock_test_adapter` |
| Retention / isolation vocabulary, UPF structure | P36 | `docs/06`, `power_intent_template.upf` |

Not reused, with reason: P27's thermal monitor and operating-point (frequency) control - outside this brief's
scope (no DVFS, no thermal sensing); P35's clock monitor and root gate - they own the root (CLOCKWORKS takes
`clk_ok_i` from the monitor).
