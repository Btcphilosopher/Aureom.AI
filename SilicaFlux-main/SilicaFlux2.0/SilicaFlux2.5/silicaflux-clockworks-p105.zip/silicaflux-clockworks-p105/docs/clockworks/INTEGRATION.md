# Integration guide

> **Status of every mapping below:** proposed from the engines' published ports (`00_AUDIT.md`). None of the real
> engines was co-simulated with CLOCKWORKS; each connection must be confirmed by the owner of that engine
> (`09_LIMITATIONS.md`, L1). Where an engine lacks a signal, the table says so and what to do instead.

## 1. Per-engine connection table

| Signal (CLOCKWORKS) | ControlCore P21 | MemoryMatrix P101 | Meridian P83/P102 | StreamDMA P103 | TensorCore (07/tile system) | PacketForge = PacketCore P62 |
|---|---|---|---|---|---|---|
| `eng_idle_i` | `cpu_sleep` (WFI) and no outstanding bus transfer | `idle_o` | **none** (tie 1, clear the bit in `QCFG.mask`) | `~busy` | tile system / adapter `~busy` | `idle` |
| `eng_obuf_empty_i` | mailbox / console TX empty | master request queues empty (`&m_empty`, part of `idle_o`) | tie 1 | write-data FIFO empty | `tensor_output_buffer` empty | egress queues empty |
| `eng_dma_idle_i` | system-DMA idle (`cc` sys DMA) | tie 1 | tie 1 | completion queue empty (`~cpl_valid`) | adapter has no outstanding descriptor | tie 1 |
| `eng_mem_idle_i` | tie 1 | `idle_o & ~flush_busy_o & ~init_busy_o` | tie 1 | tie 1 | tie 1 | tie 1 |
| `eng_ready_i` | out of reset, ROM boot done | `~init_busy_o` | out of reset | `~soft_reset_active` | out of reset | out of reset |
| `quiesce_req_o` | halt request (debug halt / WFI) | `quiesce_i` (blocks new master requests) | - | - | pause tile issue | stop ingress admission |
| `cancel_o` | - | - | - | `ctl_abort` | (no safe cancel: leave `CAN_CANCEL = 0`) | - |
| `accept_en_o` | gate on the SFB master request | gate on the master request path | mask `m_req_valid` of every master port | gate on `desc_valid` / `desc_ready` | gate on descriptor / command accept | gate on ingress `valid` |
| `issue_cnt_i` / `retire_cnt_i` | SFB transactions issued / completed | requests accepted / responses delivered (cross-check) | **sum over master ports:** `m_req_valid & m_req_ready` / `m_rsp_valid & m_rsp_ready` (incl. discarded responses, `zomb_flush`) | AR/AW accepted / R-last, B delivered | SFB transactions | frames admitted / delivered or dropped |
| `fabric_connect_o` / `fabric_ack_i` | its bus port enable / ack | target port enable / ack | `iso_clear` / `o_iso` of that port | port enable / ack | port enable / ack | port enable / ack |
| `eng_wake_req_i` | interrupt pending, timer | - | - | completion interrupt | - | RX frame arrival |
| `up_stalled_i` / `in_offered_i` | from `sf_cmd_gate.stalled_o` and `dn_valid & ~dn_ready` | same | same | same | same | same |

Rules that apply to every column: event pulses are qualified with the engine's clock enable (rule E3); every issue has exactly
one retire (E2); `QCFG.mask` has a 1 only for conditions the engine really provides.

## 2. The gate

```
assign eng_in_valid = up_valid & (accept_en | committed);   // sf_cmd_gate (P27) does exactly this
assign up_ready     = eng_in_ready & (accept_en | committed);
assign up_stalled   = up_valid & ~(accept_en | committed);   // -> up_stalled_i (the wake request)
assign in_offered   = eng_in_valid & ~eng_in_ready;          // -> in_offered_i
```
A transfer already offered keeps going (never torn); a new one waits behind the closed gate and wakes the engine.

## 3. Clock enable on the engine side

Baseline: every state-holding flop of the engine is written `if (clk_en_o[e]) ... `. With `USE_ICG = 1`, connect `gclk_o[e]` as the engine clock
**instead** and drive the engine's enable to 1 - never both. SRAM wrappers: hold `CE` inactive while `clk_en` is low; set `SRAM_QUAL[e]`
only after the macro datasheet allows it.

## 4. Bring-up sequence (software)

1. Power-on: every engine is released in rank order and becomes ACTIVE; `STATUS` shows clock OK; `EO_RST.cause` has `RC_POR_EXT`.
2. Per engine: `QCFG` (Meridian: mask `0x03`), `TMO_DRAIN` / `TMO_WAKE` from the engine's real worst-case latencies, `MIN_ACTIVE`.
3. Optional policy: `IDLE_THR` + `CTRL.AUTO_IDLE_EN`; `WDT_LIMIT` + `CTRL.WDT_EN`; `CTRL.FAULT_RST_EN` for engines that tolerate an automatic reset.
4. Last: system watchdog (`SYSWDT_LIMIT`, `CTRL = EN | SYS_WDT_EN | SYS_WDT_RST_EN`), then `CTRL.SYS_WDT_LOCK` if the configuration is final.
5. Operation: idle a master with `EO_REQ = 3` (it drains and stops), wake with `EO_REQ = 0` (or let work / an interrupt wake it). Stop order is masters,
   interconnect, memory; waking a master wakes its providers first.
6. After a fault: read `EO_FAULT` / `EO_STATE`, then `EO_REQ = 5` (reset) - the only exit from FAULT.

## 5. Coexistence with P35 CLOCKTREE, P27 POWERCLOCK, P40 `sf_power_mgr`, ControlCore `cc_pmu`

| Block | Keeps | Must be disabled / disconnected for the six engines |
|---|---|---|
| P35 | clock monitor, PLL boundary, root ICG, POR distribution; supplies `clk_i` (`clk_core_o`), `clk_ok_i`, the `por_ni` / `ext_rst_ni` pins | its per-branch gates and fabric / ControlCore / branch resets for the engines CLOCKWORKS owns (two owners of one reset is a bug); its `br_clk_req` / `wake` contract maps onto `up_stalled_i` / `eng_wake_req_i` |
| P27 | thermal monitor and frequency-point control (outside this brief) | its core gate (`u_cg_core`) and unit gates, and its reset sequencer for the engines CLOCKWORKS owns |
| P40 stand-in | - | `sf_power_mgr` (a stand-in) is replaced |
| ControlCore `cc_pmu` | its accelerator-subdomain gating | `acc_rst_req` must never reset the ControlCore itself |

This combination has **not** been integrated or simulated together; it is a documented plan, not a result.
