# 07 - DFT and test interfaces

`sf_clock_test_adapter` provides control sequencing and signal conditioning. It is **not** scan insertion, scan
stitching, ATPG, a TAP, an MBIST engine or a pattern generator, and asserting `scan_mode_i` does not make a design
scannable: it opens the clocks and holds the resets so that a scan flow *can* work.

## 1. Interfaces (names follow DFTGrid P39 and MemoryTest P78)

| Brief item | Signals | Behaviour |
|---|---|---|
| Scan enable | `scan_en_i` -> `scan_en_o` | passed through only while scan mode is active |
| Test mode | `scan_mode_i & test_permit_i` -> `scan_mode_eff_o` (combinational, pins only) | forces every clock enable on, holds every engine reset under `test_rst_ni`, inhibits memory CE (`mem_inhibit_o`); requires `test_permit_i` (T1) |
| Clock-gating test enable | `icg_te_i` (or `scan_en` when `TE_FOLLOWS_SCAN_EN`) -> `cg_test_en_o` | forces every ICG / clock enable on **without** changing the FSM state (bench: TC stays CLOCK_DISABLED with its clock on) |
| MBIST start / status | `mbist_cmd_*` (registers) -> `mbist_start_o`, `mbist_abort_o`, `mbist_test_mode_o`, `mbist_permit_o`, `mbist_cpu_halted_o`; `mbist_busy/done/pass/fail/err_i` -> `TEST_STATUS.result` | sequencer: HOLD -> START -> WAIT_BUSY -> RUN -> RELEASE; results PASS / FAIL / ERROR / REFUSED / TIMEOUT / ABORTED |
| DFTGrid memory-group handshake | `dft_quiesce_req_i[g]` -> `dft_quiesce_ack_o[g]`, `dft_f_block_i[g]` (-> gate), `dft_f_busy_o[g]`, `dft_f_req_o[g]`, `dft_mbist_clk_req_i[g]` (keeps the clock on) | the group's engines (`GRP_ENG`) and their dependents are quiesced; `ack` = all CLOCK_DISABLED |
| JTAG / TestCore | `tc_mode_i[2:0]` (NORMAL, JTAG, DIAGNOSTIC, MBIST, SCAN_SHIFT, SCAN_CAPTURE); `jtag_status_o` (same layout as `STATUS`) | decoded for diagnostic access; status delivered in the `clk` domain, TestCore's own bridge crosses to TCK |
| Memory diagnostic access | `diag_req_*` -> `mem_diag_*`, response path | allowed only in DIAGNOSTIC mode, with permit, outside scan, **memory owner quiesced** (T5); otherwise an immediate error response and a logged `TEST_EV` |

## 2. Rules

| Rule | Statement | Verified by |
|---|---|---|
| T1 | scan / MBIST / diag need `test_permit_i`; without it the request is **ignored and logged** | scenarios `scan`, `mbist`, `diag` |
| T2 | scan: clocks on, resets held; **leaving scan requires the full reset sequence** (`RC_TEST`) | scenario `scan` |
| T3 | MBIST starts only after every engine that can reach the memory (the group **and its dependents**) is CLOCK_DISABLED with the clock forced on | scenario `mbist` + `cw_mbist_model` flags a start without quiet owners; mutant M13 |
| T4 | MBIST is refused on an engine in RESET or FAULT | scenario `mbist` (`REFUSED`) |
| T5 | diagnostic access only with the owner quiesced | scenario `diag` |
| T6 | the scan-mode signal used by the reset sequencer is a pure function of two pins, never of a flop that the reset it controls would clear | structural; `scan_mode_eff_o` |

MBIST is also protected from functional traffic by hold propagation: a hold on the memory (MM) holds MR and every master
that transitively requires it, so no functional write can reach the memory (`cw_mbist_model` flags any). Jobs presented
during the test wait at the closed gate and complete afterwards (scenario `mbist`: no job lost).

## 3. Reset and clock behaviour in test

`test_rst_ni` drives the controller reset and every engine reset directly through the P40 synchroniser bypass; in scan the
sequencer holds `rst_active` and cannot release. `por_ni` / `ext_rst_ni` are not used in scan mode.

## 4. Known limits (not done)

* No scan insertion, no ATPG, no coverage numbers. `docs/11_dft_readiness` of the repository's DFT projects lists what the
  commercial DFT flow still has to do; none of it is claimed here.
* ICG enable path vs scan capture: with `icg_te_i` static, capture does not exercise the functional enable logic (the same
  limitation P39 states). `TE_FOLLOWS_SCAN_EN = 1` is the one-line alternative if ATPG needs it.
* The MBIST sequencer coordinates the engines; the March algorithms, fault coverage and repair belong to P78 / P39.
* TestCore mode transitions are TestCore's (formally proven there); the adapter only consumes `tc_mode_i`.
