# 05 - Clock control, clock-domain status and timing integration

## 1. Synchronous clock enables (the baseline)

`clk_en_o[e]` is a flop on `clk_i`, so it changes only just after a rising edge. Engine flops are written
`if (clk_en) q <= d;` - the engine behaves exactly like a stopped clock when the enable is low. This is the
**portable** mechanism: it needs no library cell, no CTS change, and gives the same cycle behaviour as gating.
Its power effect is whatever the engine's enable logic saves (data-path and flop clock-enable power), **not** clock-tree power.

Enable timing: FSM state change at edge N -> `clk_run` flop -> `clk_en` flop at edge N+1 (disable); wake: `clk_run` and
`clk_en` rise one edge apart. The wake step `W_CLK` waits for the **actual** enable (feedback) plus `CLK_CFG.settle` cycles.

## 2. Integrated clock gating (optional, not qualified)

`USE_ICG = 1` instantiates one `sf_cw_clock_gate` per engine through `sf_cw_icg_wrap`:

* a clock is **never** gated with a combinational AND / OR; the bench `tb_cw_icg.sv` shows why (a plain `clk & en` produced
  4,998 truncated pulses in 20,000 cycles; the ICG produced none);
* the wrapper selects exactly one implementation with a define: `SF_CW_ICG_NANGATE45`, `SF_CW_ICG_LIB` (integrator wrapper
  `sf_cw_icg_lib_cell`), `SF_CW_ICG_XILINX_BUFGCE`, or the behavioural latch model (simulation only);
* with **no** target selected and `SYNTHESIS` defined the wrapper instantiates an undefined module and synthesis **fails
  on purpose** (`reports/synth.md` records the check);
* equivalence: an ICG passes edge n iff the enable was 1 in the low phase before edge n; a flop with enable `ce` samples
  `ce` at edge n - the same cycle. `tb_cw_icg.sv` checks this cycle by cycle (a gated LFSR vs an enable LFSR);
* the test enable forces the clock on (`cg_test_en_o` -> ICG `SE`).

Nothing about a specific library cell is qualified (`physical/clockworks/ICG_QUALIFICATION.md`).

## 3. Clock-domain status

| Input | Meaning | Handling |
|---|---|---|
| `clk_ok_i` | functional clock healthy, **synchronous** to `clk_i` (e.g. P35 clock monitor output) | direct |
| `pll_lock_i` | PLL lock, async single bit | `sf_sync2`; used if `PLL_LOCK_USED = 1` |

`clk_loss = (clock was OK at least once) & !(lock & clk_ok)`. It raises `FC_CLK_LOSS` in every engine (-> FAULT, clock on),
holds the reset sequencer in WAIT (no release while the clock is bad), and stalls wake steps (`W_CLK`, `W_PROV`). Status
registers: `STATUS.clk_ok`, `pll_lock`, `clk_loss_seen`. **If the clock actually stops, this block stops with it**: detecting
that needs a reference clock this block does not have (P35's job); `clk_ok_i` is how that result arrives.

## 4. What is not here

* no PLL, no clock multiplexer, no divider, no generated clock - so no `create_generated_clock` is needed or provided;
* no frequency or voltage control (no DVFS): no regulator or PLL interface exists in the repository (as in P27);
* no clock-tree synthesis: CTS must balance the gated and ungated sinks of an engine (`ICG_QUALIFICATION.md` row 9).

## 5. STA integration (templates, not run)

`physical/clockworks/clockworks_func.sdc` / `clockworks_test.sdc` define the single clock, the asynchronous pins, the case
analysis for functional vs test mode, IO budgets and the clock-gating checks; `timing_exceptions.md` justifies every
exception; `sta_clockworks.tcl` is the signoff script template; `clock_domain_boundary.md` is the boundary specification.
Use real libraries and technology constraints when they exist - every `@@...@@` is a placeholder, every period is a
requirement, not an achieved result.
