# 04 - Reset architecture

`sf_reset_sequencer` is the **owner of every reset** of the six engines. Nothing else drives an engine reset input.

## 1. Sources, scope, cause

| Source | Kind | Scope | Cause bit |
|---|---|---|---|
| `por_ni`, `ext_rst_ni` | async pins | controller **and** every engine | `RC_POR_EXT` |
| `glob_rst_req` (`CMD = GLOBAL_RESET`, key `0x5AFE`) | software | every engine (controller keeps its state) | `RC_GLOBAL_SW` |
| subsystem request (`EO_REQ = RESET`, or reset-on-wake) | software / FSM | the engine **plus closure** | `RC_SUBSYS` |
| progress watchdog expiry | hardware | the engine plus closure | `RC_WDT` |
| system watchdog stage 2 | hardware | every engine | `RC_SYS_WDT` |
| fault-triggered (FSM entered FAULT, `FAULT_RST_EN`) | hardware | the engine plus closure | `RC_FAULT` |
| scan / test reset (`ta_scan_act`, `test_rst_ni`) | test | every engine | `RC_TEST` |
| collateral | derived | dependents of a resetting provider that are **not isolated** | `RC_CLOSURE` |

Causes are sticky per engine (`EO_RST`, W1C) with a reset-sequence counter. They live in the controller domain, so they
survive engine resets; `RC_POR_EXT` records the power-on / external reset itself.

## 2. Reset path rules (adopted from P35, `02_RESET_DOMAINS.md`)

| Rule | Statement |
|---|---|
| R1 | Each engine reset is **one flop** (`req_q`) feeding a reset synchroniser (`sf_reset_sync`, unmodified P40 cell): asynchronous assertion, synchronous release. No decoded or combined logic in a reset path (P35 finding F-04). The only combinational reset logic is the pin pair `por_ni & ext_rst_ni`; use a reset-combine cell. |
| R2 | `req_q` is itself asynchronously **set** by the controller reset, so POR / external reset reaches every engine reset with **no clock running**. |
| R3 | While an engine is in reset its clock is **forced on** (`rst_clk_force`), and the hold time counts clock edges **delivered to the engine** (`clk_en` feedback), not elapsed time. Minimum 2, default 8 (`RST_CFG.hold`). |
| R4 | Release is **acknowledged**: after releasing the request the sequencer waits until the synchroniser output (`eng_rst_no`) is actually high, then waits for local readiness (stable for `RST_CFG.stable` cycles). |
| R5 | Release is **ordered by rank** (providers first): MM -> MR -> DMA / TC / PF -> CC. An engine waits until every lower-rank engine in a sequence is back to RUN; a *failed* provider blocks its dependents, which then fail explicitly by timeout (`rdy_tmo x 4`). The order is checked against `DEP_MASK` at elaboration. |
| R6 | A forced reset also resets every **non-isolated** dependent (closure), so no master is left holding a transaction to an engine that lost its state. An isolated (CLOCK_DISABLED) dependent holds no transaction and is left alone. |

## 3. Per-engine sequence

`RUN -> ASSERT -> HOLD -> WAIT -> REL -> RDY -> DONE | FAIL -> RUN`. A new request while a sequence runs restarts it at
ASSERT (idempotent). `rst_active` stays high through DONE / FAIL so the FSM sees the pulse; `RESET -> WAKE_REQUESTED` on
DONE (the wake tail then waits for providers, readiness and the fabric), `RESET -> FAULT` on FAIL (cause `FC_RST_TMO`).
The scan-mode **test bypass**: with `test_mode_i`, every synchroniser passes `test_rst_ni` straight through; leaving scan
requires the full reset sequence (`RC_TEST`).

## 4. Reset-domain crossing

* **One functional clock**: an engine reset is launched by a flop on that clock, so the assertion is a normal synchronous
  launch with an asynchronous effect; the release is a recovery / removal check on `clk_i`. There is no reset *crossing*
  between clock domains in this block.
* **Asynchronous pins** are single-bit and reach only synchroniser first stages (`sf_reset_sync`, `sf_sync2`). No multi-bit
  value crosses an asynchronous boundary anywhere in the block.
* **Reset-domain crossing inside the block** (engine A in reset while engine B runs): the engine boundary is protected by the
  protocol - the work gate is closed and the fabric port is cut (`fabric_conn = 0`) from the cycle the FSM sees the reset,
  and a reset that begins in the same cycle in which a wake would reopen the gate suppresses the reopen (formal F06,
  checker C09). Transactions that were in flight become zombie responses, retired by the fabric (rule E4).
* **Ledger vs reset**: the ledger of an engine is cleared for the whole of its reset sequence.
* **Not done**: structural CDC / RDC signoff with a commercial tool (`10_PHYSICAL_AND_SIGNOFF.md`).

## 5. Watchdogs

* **Progress watchdog** (per engine): counts consecutive cycles in which the engine is ACTIVE and busy (or has outstanding
  work) and no transaction retired. At `WDT_LIMIT` it fires one pulse per episode -> forced reset with closure. It cannot
  fire on an idle engine, during a drain, or on a gated clock (`act` is 0 there). `WDT_LIMIT = 0` disables it.
* **System watchdog**: two stages. Stage 1 (`SYSWDT_LIMIT` cycles without a kick) sets the stage-1 interrupt; stage 2 (a
  second equal period) raises a global reset if `CTRL.SYS_WDT_RST_EN`. `CTRL.SYS_WDT_LOCK` freezes the configuration.

## 6. Interplay with engine-internal resets

StreamDMA has `ctl_soft_reset` (reset the whole core, not the counters; `soft_reset_pending` until the MemoryGuard is quiet).
CLOCKWORKS' reset is a hard reset of the engine: it does not wait for `soft_reset_pending`. An engine-internal soft reset
requested by software while CLOCKWORKS holds the engine in drain is a software-ordering hazard; keep engine-internal resets
inside ACTIVE (documented in `INTEGRATION.md`).
