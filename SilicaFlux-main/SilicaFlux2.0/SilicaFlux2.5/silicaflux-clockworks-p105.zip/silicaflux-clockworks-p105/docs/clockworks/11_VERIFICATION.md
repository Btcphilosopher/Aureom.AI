# 11 - Verification

Exact, regenerated results are in `reports/` (`regression.md`, `formal.md`, `mutation.md`, `synth.md`); this document
explains what each layer proves and what it does not. Run everything with `make regress` (about 10 minutes) and the
mutation campaign with `make mutate`.

## 1. Layers

| Layer | Tool | What it checks | Strength |
|---|---|---|---|
| Lint | Verilator `-Wall` | all ten modules and the checker, zero warnings (waivers are justified in `rtl/clockworks/lint.vlt`) | static |
| System bench | Verilator **and** Icarus Verilog | `tests/clockworks/tb_cw_system.sv`: the controller with six bench engines, 20 scenarios (`boot` and 18 others in every build, plus `save_restore` in volatile builds), scoreboard, golden state, checker | simulation, 4 configurations x several seeds, 2 simulators |
| Unit benches | Icarus | enable controller vs an independent reference model (2.1 M checks), FSM vs the `cw_legal` oracle and rules S1-S6 over four parameter sets (3.6 M checks), ICG edge integrity and cycle equivalence | random simulation |
| Assertions | `sf_cw_checker.sv` | 13 properties C01-C13 on every cycle of every system run | simulation |
| Formal | Yosys `sat` (temporal induction) + z3 | FSM (4 parameter sets) and enable controller **proved for all reachable states**; reset sequencer bounded; 9 planted bugs all found | proof / bounded |
| Mutation | `tools/mutate.py` | 33 deliberate RTL defects against the whole suite | detection power |
| Synthesis smoke | Yosys | six modules, no latch; ICG wrapper refuses without a target | structural |

## 2. Brief section 13 - coverage matrix

| Required test | Scenario / evidence |
|---|---|
| Idle transitions | `idle_wake` (ordered stop chain, provider asked first, cascade wake), `clean_sleep`, `auto_idle`, `policy` |
| Active-to-idle | `idle_wake`, `dma_inflight`, `tensor_inflight`, `auto_idle`; FSM unit bench |
| Idle-to-active | `idle_wake` (software wake, cascade through providers), `clean_sleep` and `auto_idle` (arriving work wakes the engine, held jobs complete) |
| DMA in flight | `dma_inflight` (12 jobs, none lost, none cancelled), `cancel` (drain by cancel, `SE_CANCEL`) |
| Tensor operation in flight | `tensor_inflight` (background activity stops on `quiesce`), `cancel` (no safe cancel -> FAULT with the clock running) |
| Pending DataFabric responses | `pending_fabric` (hung master with transactions outstanding: its provider **faults, never stops**; recovery order; zombie responses retire) |
| Reset during activity | `reset_activity` (provider reset closes over active masters, isolated engine untouched, sleeping engine reset with its clock forced, release order, hold in delivered edges), stress |
| Watchdog | `watchdog` (progress watchdog resets a hung engine; idle engine never trips; system watchdog stage 1 interrupt, stage 2 global reset; kicking prevents it) |
| MBIST entry | `mbist` (owners and dependents quiesced first, clock forced, PASS / FAIL / TIMEOUT / REFUSED / no permit, DFTGrid group handshake, jobs held and completed afterwards) |
| Test-mode clock enable | `scan` (clock-gating test enable alone; scan with and without permit; all enables on; resets follow `test_rst_n`; exit requires the reset sequence), system ICG monitor |
| Unsupported state transitions | `unsupported` (200 random targets, every unsupported one rejected with the right code; FAULT leaves only through RESET; forced state code 7 -> FAULT), FSM unit bench, formal F01 / F02 / F10 |
| Clock-enable stability | checker C03 / C04 / C12, formal E1 / E2 (enable is exactly the registered function; never falls on a busy engine), `tb_cw_icg.sv`, system ICG monitor (gated edges == enabled edges through resets, MBIST, scan, faults) |
| Assertions preventing unsafe state changes | the FSM prevents by construction; formal F01-F18 **prove** the rules for all reachable states; the checker detects any violation in simulation (C01-C13) |

Additional scenarios: `regs` (ID, unmapped access, `CTRL.EN` rejection), `dep_timeout`, `diag`, `counters` (ACTIVE + IDLE + DISABLED = total,
wake / quiescence latency, `DIS_WITH_OUT = 0`), `save_restore` (VOLATILE builds), `stress` (random jobs, idle, wake, reset, wake events,
invalid requests for 30,000 cycles).

## 3. Scoreboard and golden models

* **Job conservation**, every cycle, per master: accepted = completed + cancelled + lost-to-reset + still inside.
* **Architectural state**: a golden model of each master's state register and of the memory contents, updated from completion events; compared at
  the end of every scenario. Resets re-initialise the golden state; a memory reset clears the golden array.
* **Violations** (sticky in the models): work in flight while a provider clock is off; work held or arriving while an engine's clock is off;
  a memory write while the memory clock is off; an MBIST start without quiet owners; a functional write during MBIST.
* **Disable entry monitor**: at every entry to CLOCK_DISABLED nothing is inside the engine model and both ledgers are zero.
* Both simulators, four configurations: `default` (qualified SRAM), `defpol` (the conservative default: engines with SRAM refuse to idle),
  `save_volatile` (explicit save / restore, bench power loss: **state preserved**), `neg_control` (volatile, no save: the loss **is detected** -
  proof that the controller makes no retention claim); and `icg` (Icarus: real gated clocks).

## 4. Assertions (`sf_cw_checker.sv`)

C01 state never 7; C02 legal transitions; C03 clock off only the cycle after CLOCK_DISABLED; C04 the enable never falls on a busy engine;
C05 gate open only in ACTIVE / IDLE_REQUESTED; C06 CLOCK_DISABLED only from DRAINING with stable quiescence, gate closed, ledger zero;
C07 fabric cut when isolated; C08 clock on in FAULT / RESET; C09 gate reopens only in ACTIVE with fabric connected **and acknowledged** and the
engine ready; C10 RESET left only after the synchroniser released; C11 CLOCK_DISABLED -> quiesce, DRAINING -> gate closed; C12 the interlock
never fires; C13 scan -> all enables on. With `+define+FORMAL` the same checks are `assert`s.

## 5. Formal

`formal/clockworks/run_formal.py` (Yosys 0.33 + z3; SymbiYosys is not available here). The Verilog frontend of Yosys 0.33 has no wildcard package
import, so `yosys_prep.py` inlines the package body into each module - the proofs run on a mechanical rewrite of the same RTL.

| Job | Properties | Result |
|---|---|---|
| `fsm_*` (4 parameter sets) | F01-F18: state range, legal transitions, S1-S4, S6, wake ordering, reset ownership, SRAM rule, fault cause recorded, no reopen in a reset cycle; plus 7 state-encoding lemmas | **PROVED** (base + induction) under the stated assumptions (a sequencer pulses done / fail only while it owns the engine, never both) |
| `ec` | E1-E6: enable is exactly the registered function; never falls on a busy engine; ledger equals prev + issue - retire (cleared in reset, clamped with an error); gate function; quiet implies the raw condition held in the previous 1-3 cycles | **PROVED** (quiet window <= 3 cycles) |
| `rs_power_on`, `rs_requests` | R1 provider released before dependent (power-on); R2 done only after release; R3 hold >= configured delivered edges; R4 closure iff the dependent is not isolated; R5 a request is owned next cycle | **BOUNDED** (24 steps from reset); counters keep the induction step open |
| `planted_*` | the FSM properties on a deliberately broken FSM (M01, M02, M03, M04, M10, M11, M19, M29, M30) | all **FAILED** with a counterexample, as required: the properties are not vacuous |
| `planted_rs_*` | the reset-sequencer properties on broken sequencers (M06 hold collapses, M07 rank ignored, M22 hold without delivered clock) | all **FAILED**, as required |

Environment assumptions are in the wrappers (`f_fsm.sv`, `f_ec.sv`, `f_rs.sv`) and are the only things the proofs rely on besides the RTL.
Not proved: the system as a whole, liveness (progress is checked by timeouts and simulation, not formally), the real engines.

## 6. Mutation

33 mutants (single defects, one double fault, one interlock-only backstop, two clock-gate mutants). Four stages, a mutant counts as killed at
the first one that sees it: (1) the system regression (Verilator); (2) the Icarus unit benches for the mutated file (enable controller, FSM, ICG);
(3) a second system configuration where the first cannot see the mutated feature (`DEFPOL` for the SRAM rule, `SAVE_ALL` for the save step);
(4) the formal reset-sequencer properties (the formal wrapper has a *free* clock-return feedback, which the system wiring does not: the top-level
feedback is the enable flop itself, so a sequencer that counts hold time without delivered clock edges (M22) is invisible to simulation and is caught
only by property R3). A survivor of all stages is listed with the reason in `reports/mutation.md`.

## 7. Defects found by this project's own verification (all fixed)

| Found by | Defect | Fix |
|---|---|---|
| system scenario `mbist` / `diag` | the hysteresis counter (`MIN_ACTIVE`) restarted when an engine left ACTIVE, so a provider asked to idle before its masters could never satisfy it (it only worked when the dependents were already isolated) | counter keeps running in IDLE_REQUESTED; test-origin holds bypass the hysteresis (mutant M15) |
| FSM unit bench (random) | the `FC_RST_TMO` cause was masked while the FSM was in RESET, so a reset-timeout FAULT recorded **no cause** | cause of the current transition is always recorded (formal F11) |
| design review of the reset-during-activity scenario | the ledger of an engine under reset kept the transactions it had lost, so it could never become quiet again | ledger cleared for the whole reset sequence (mutant M09); providers retire zombie responses (rule E4) |
| extended checker C09 in the stress run | a wake that completed in the same cycle as a reset request opened the work gate for one cycle on an engine already being reset | `rst_pend_i`: the gate is never reopened in a cycle in which a reset begins (formal F06) |
| cross-simulator run | Icarus' 4-state X on model pulses at time 0 corrupted the bench's own job counters (bench, not RTL) | X-safe event counting |

## 8. What the verification does NOT show

It does not show that the real engines honour the quiescence contract (L1), nothing about timing, gate-level behaviour, CDC / RDC
signoff, power, or any physical property (`09_LIMITATIONS.md`, `10_PHYSICAL_AND_SIGNOFF.md`).
