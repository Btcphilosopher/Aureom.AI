# 02 - Operating-state FSM and wake sequencing

One `sf_power_state_fsm` per engine. States are 3-bit codes; **code 7 is unsupported** and is never a legal state.

| Code | State | Clock enable | Work gate | Fabric | Meaning |
|---|---|---|---|---|---|
| 0 | ACTIVE | on | open | connected | normal operation |
| 1 | IDLE_REQUESTED | on | open | connected | an idle request is accepted; waiting for dependents to be isolated and `MIN_ACTIVE` |
| 2 | DRAINING | on | **closed** | connected | no new work; waiting for quiescence (optionally cancel, optionally save) |
| 3 | CLOCK_DISABLED | **off** | closed | cut | clock stopped (or stopped-unless-forced by test/reset) |
| 4 | WAKE_REQUESTED | on | closed | reconnecting | wake sequence in progress |
| 5 | RESET | on (forced) | closed | cut | the reset sequencer owns the engine |
| 6 | FAULT | **on** | closed | cut | failure; leaves only through RESET |

## 1. Legal transitions (oracle: `sf_cw_pkg::cw_legal`)

| From | To | When |
|---|---|---|
| ACTIVE | IDLE_REQUESTED | idle request (software), auto-idle expiry, or test hold |
| ACTIVE | RESET / FAULT | reset sequencer owns the engine / fault event |
| IDLE_REQUESTED | DRAINING | all dependents isolated and `MIN_ACTIVE` met (test hold bypasses the hysteresis) |
| IDLE_REQUESTED | ACTIVE | wake request, auto-idle origin + work arrived, test hold released, or **dependency timeout** (`SE_DEP_TMO`) |
| DRAINING | CLOCK_DISABLED | quiescence vector stable (`quiet_i`) **and**, if `SAVE_EN`, `save_done_i` |
| DRAINING | ACTIVE | abort: wake request or (auto origin) work arrived or test hold released - only before the save step |
| DRAINING | FAULT | drain timeout (after one cancel attempt if the engine can cancel) - **the clock is not stopped** |
| CLOCK_DISABLED | WAKE_REQUESTED | wake request, pending upstream work, engine wake request, dependent waking, test hold released |
| WAKE_REQUESTED | ACTIVE | all wake steps done (below) |
| any | RESET | the sequencer begins a reset of this engine |
| RESET | WAKE_REQUESTED | reset done (released, acknowledged, ready) |
| RESET | FAULT | reset sequence failed (`FC_RST_TMO`) |
| any but RESET | FAULT | fault event: `FC_DRAIN_TMO FC_WAKE_TMO FC_RST_TMO FC_ILLEGAL_STATE FC_ENG_ERR FC_LEDGER FC_ILK FC_CLK_LOSS` |
| FAULT | RESET | software reset request, or automatic fault-triggered reset (budget `MAX_AUTO_RST`) |

Anything else is an illegal transition; the checker (C02) and the formal property F02 forbid it.

## 2. Requests and rejection (S6)

Software requests a target state through `EO_REQ`. Only **ACTIVE (0, wake), CLOCK_DISABLED (3, idle), RESET (5)** are
requestable. Everything else - including the internal states 1, 2, 4, 6 and the code 7 - is **rejected** with
`REJ_UNSUPPORTED` and changes nothing. A request that is not legal in the current state is rejected with
`REJ_STATE` (e.g. wake or idle while in FAULT: FAULT leaves only through RESET). Other codes: `REJ_SRAM`
(retention not qualified), `REJ_POLICY` (`ALLOW_GATE = 0`), `REJ_TEST` (test owns the engine), `REJ_DISABLED`
(`CTRL.EN = 0`). Accepted no-ops (wake while ACTIVE, idle while already idling) are acknowledged.

## 3. Drain sub-steps (`STATE.drain_step`)

`D_QUIESCE` wait for `quiet_i` (the quiescence vector, `03_QUIESCENCE.md`) -> on drain timeout: if the engine can
cancel and has not been cancelled, pulse `cancel_o` and go to `D_CANCEL` (cancel timeout) -> else **FAULT with the
clock still running** -> `D_SAVE` (only if `SAVE_EN`): `save_req_o` until `save_done_i` and still quiet -> CLOCK_DISABLED.
A wake that arrives during `D_SAVE` is remembered and executed right after the disable.

## 4. Wake sequence (`STATE.wake_step`) - brief section 6

| Step | Waits for | Then |
|---|---|---|
| `W_CLK` | clock enable restored (`clk_en` feedback) for `CLK_CFG.settle` cycles and `clk_ok` | `W_PROV` |
| `W_PROV` | every provider **serving** (ACTIVE / IDLE_REQUESTED); a waking dependent also *wakes its providers* (cascade) | `W_RST` (if `RST_ON_WAKE`) / `W_RESTORE` (if `SAVE_EN`) / `W_READY` |
| `W_RST` | one subsystem-reset request; the sequencer takes the engine to RESET; on return `W_RESTORE` / `W_READY` | |
| `W_RESTORE` | `restore_req_o` until `restore_done_i` | `W_READY` |
| `W_READY` | local readiness `eng_ready_i` | `W_FABRIC`, `fabric_connect_o = 1` |
| `W_FABRIC` | DataFabric port connected (`fabric_ack_i`) | **ACTIVE, work gate opens now** (never earlier, and never in a cycle in which a reset begins) |

Completion is explicit (`SE_WAKE`, wake-latency counter) and so is failure (`FC_WAKE_TMO` -> FAULT). Every wait has a
timeout: 0 means 65535, **never "no timeout"**.

## 5. Policy inputs

* **Auto idle**: `IDLE_THR` consecutive idle cycles (engine idle, ledger zero, nothing offered or stalled), if
  `CTRL.AUTO_IDLE_EN`, `CTRL.EN` and `MIN_ACTIVE` allow. Work arriving during an auto-origin idle request cancels it.
* **Hysteresis**: `MIN_ACTIVE` cycles since the engine last became ACTIVE (the counter keeps running in IDLE_REQUESTED).
* **Dependencies**: a provider may only start draining when every engine that requires it is CLOCK_DISABLED / RESET / FAULT
  (isolated). A provider asked to idle first waits in IDLE_REQUESTED and proceeds by itself; if its dependents never
  stop, it returns to ACTIVE after `dep_tmo` with `SE_DEP_TMO` (non-fatal).
* **Test hold**: while the test adapter holds an engine, the engine - and everything that transitively requires it - is
  taken through the normal drain to CLOCK_DISABLED with its clock *forced on*, and cannot be woken by work or software.
* **Fault-triggered reset**: with `CTRL.FAULT_RST_EN`, an engine entering FAULT requests a reset (forced, with closure)
  up to `MAX_AUTO_RST` times (cleared by `CMD_CLEAR_FAULTS`).

## 6. Safety rules (each is a checker assertion and a formal property)

| Rule | Statement | Checker | Formal |
|---|---|---|---|
| S1 | the clock stops only in CLOCK_DISABLED | C03 | F03 |
| S2 | CLOCK_DISABLED is entered only from DRAINING with stable quiescence, gate already closed (and state saved) | C04, C06 | F04 |
| S3 | the work gate is open only in ACTIVE / IDLE_REQUESTED, reopens only on entry to ACTIVE after readiness **and** fabric reconnection, never in a reset cycle | C05, C09 | F05, F06, F17 |
| S4 | a drain that does not converge ends in FAULT with the clock running | C08 | F08, F12 |
| S5 | an unsupported state code goes to FAULT | C01 | F01 + sim (`unsupported`) |
| S6 | unsupported / illegal requests are rejected and change nothing | - | F10, F16 + sim |
