# 06 - Power states, SRAM behaviour and low-power (UPF / IEEE 1801) hooks

## 1. Vocabulary

| Term | Definition used here | Where it exists |
|---|---|---|
| clock enable | a synchronous enable bit; flops hold when low | `clk_en_o` (implemented) |
| clock gating | the enable drives a library ICG; the engine clock stops physically | `sf_cw_clock_gate` (wrapper; cell unqualified) |
| power domain | a supply region that can be powered independently | **not implemented** |
| isolation | clamp cells on the outputs of a powered-down domain | **not implemented**; `fabric_connect_o` is a *protocol* disconnect |
| retention | cells (or a save/restore protocol) preserving state across power-off | **hook only**: `save_req/restore_req` handshakes |
| physical power switch | header / footer cells and their acknowledge | **not implemented** |

A low-power *implementation* needs library cells (switches, isolation, retention, level shifters), a power-aware
verification flow and signoff. None of that exists here, so **this package claims no low-power physical
implementation.**

## 2. SRAM behaviour

| Situation | What preserves the data | What this RTL does |
|---|---|---|
| Enable only (`clk_en` low, memory wrapper holds CE inactive), supply on | the macro itself, **if** its datasheet says CE-inactive holds data | refuses to idle an engine with SRAM until `SRAM_QUAL[e] = 1` |
| ICG stops the macro clock, supply on | the macro, **if** its datasheet allows the clock to stop (some macros need clock activity for internal sequencing, scrubbing or BIST collars) | same flag; plus `ICG_QUALIFICATION.md` row 11 |
| Supply off (power gating) | retention cells, **or** an explicit save to non-volatile / always-on storage and restore | `SAVE_EN`: a save / restore **handshake**; the storage and the retention cells are the integrator's |

**The RTL memory array that "retains values in simulation" is not evidence of retention.** The only evidence the
package accepts is the engine's `SRAM_QUAL` / `SAVE_EN` flags, set by a human from the macro datasheet. Default: unqualified,
engines with SRAM refuse to be clock-disabled (`REJ_SRAM`, bench scenario `policy` with `DEFPOL = 1`). The negative control
(`VOLATILE = 1`, `SAVE_ALL = 0`) shows that a bench-injected supply loss **is** visible as corrupted state and memory
(25 mismatches detected) - nothing in the controller pretends otherwise.

## 3. Hooks for a future UPF flow

| RTL signal (exists) | Meaning | Future UPF object |
|---|---|---|
| `quiesce_req_o[e]`, `accept_en_o[e]` | no new work, drain | precondition for isolation |
| `fabric_connect_o[e]`, `fabric_ack_i[e]` | DataFabric port connect / disconnect handshake | isolation control sequencing (`set_isolation_control`) |
| `save_req_o[e]` / `save_done_i[e]` | architectural-state save | `set_retention_control -save_signal` (or an explicit save to AON memory) |
| `restore_req_o[e]` / `restore_done_i[e]` | state restore | `-restore_signal` |
| `RST_ON_WAKE[e]` | engine must be reset after power-up | reset after `power good` |
| state CLOCK_DISABLED | clock stopped, supply on | power state ON, clock gated |

Ports that do **not** exist yet (and must be added when a real power network exists): `pd_iso_en`, `pd_ret_save`,
`pd_ret_restore`, `pd_pwr_sw_en`, `pd_pwr_good`. `CAP.PD_SUPPORT` reads 0. `physical/clockworks/power_intent_template.upf` shows
the intended mapping; it has never been run through a UPF tool. Start from P36 POWERFABRIC (`upf/`, its UPF validation
report) for the supply-net structure.

A POWER_OFF operating state is deliberately **not** defined: it would be a state the hardware cannot reach.
