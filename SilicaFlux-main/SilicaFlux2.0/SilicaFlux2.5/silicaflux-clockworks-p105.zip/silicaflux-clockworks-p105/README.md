# SilicaFlux Project 105 - CLOCKWORKS

**Semiconductor clock, power and test control** - Aureom.AI / SilicaFlux Semiconductor Systems
Primary RTL: [`rtl/clockworks/sf_clock_power_ctrl.sv`](rtl/clockworks/sf_clock_power_ctrl.sv)

Delivered as this archive. **Nothing was committed to GitHub.**

CLOCKWORKS is synthesizable control RTL that coordinates **clock enables, subsystem quiescence, reset sequencing,
operating states and test modes** for the six engines of the SilicaFlux cloud-compute architecture (ControlCore,
MemoryMatrix, Meridian, StreamDMA, TensorCore, PacketForge) on **one functional clock domain**. Synchronous clock
enables and safe quiescence come first; a real integrated clock gate is an optional, *unqualified* wrapper; physical
power-domain support is a documented hook, not an implementation.

> ## Read this first - scope of every claim
>
> * **Not a clock tree, PLL or power-gating network.** `clk_i` is an input. There are no power switches, isolation or
>   retention cells; `CAP.PD_SUPPORT` reads 0. The UPF file is a *template*.
> * **No claim that memory is retained.** An engine that owns SRAM refuses to be clock-disabled until a human sets
>   `SRAM_QUAL[e]` from the macro datasheet (default: refuse). Explicit save / restore is a handshake hook. A bench-injected
>   power loss is *detected* as corruption when no save / restore is configured (negative control).
> * **No power or energy number anywhere.** The package produces *activity* (cycle counts, VCD, SAIF) and a report tool that
>   prints "not computed" unless you supply the data; simulation activity, analytical, library-based and measured power are
>   kept apart (`docs/clockworks/08_POWER_ANALYSIS.md`).
> * **The engines in the benches are models of the quiescence contract, not the real engines.** The real ports are mapped in
>   `docs/clockworks/INTEGRATION.md` and were **not** co-simulated.
> * **Physical files are templates, never run:** no library, STA / CDC / UPF tool or netlist exists here
>   (`physical/clockworks/README.md`, `docs/clockworks/10_PHYSICAL_AND_SIGNOFF.md`).
> * "PacketForge" has no module of that name in the repository; the nearest block, PacketCore P62, is assumed
>   (`docs/clockworks/00_AUDIT.md`, F2).

## What it does

| Brief item | Where |
|---|---|
| clock-domain status, clock-enable requests, activity tracking, idle detection | `sf_clock_enable_ctrl`, `sf_clock_power_ctrl` |
| safe quiescence (stop new work, drain or cancel, confirm output buffers / DMA / memory interface, preserve state) | `sf_power_state_fsm` + quiescence vector + transaction ledger (`docs/03`) |
| operating-state FSM, legal transitions, unsupported states rejected | `sf_power_state_fsm`, `cw_legal` oracle (`docs/02`) |
| wake: clock restore, reset where needed, local readiness, DataFabric reconnection, command acceptance, explicit completion / error | wake steps `W_CLK .. W_FABRIC` (`docs/02`) |
| reset architecture: global, subsystem, watchdog, fault-triggered, test; ownership, synchronisation | `sf_reset_sequencer`, `sf_cw_wdt` (`docs/04`) |
| SRAM behaviour that respects the memory technology | `SRAM_QUAL` / `SAVE_EN` policy (`docs/06`) |
| power-state vocabulary, UPF hooks | `docs/06`, `physical/clockworks/power_intent_template.upf` |
| DFT: scan enable, test mode, MBIST start / status, TestCore, clock-gating test enable, memory diagnostic access | `sf_clock_test_adapter` (`docs/07`) |
| activity instrumentation (active / idle / disabled cycles, wake and quiescence latency, reset events, outstanding at state changes) | `sf_activity_counters` (`docs/08`) |
| clock / reset constraints, exception documentation, domain boundary, STA integration | `physical/clockworks/` |
| verification of all 13 required scenarios, assertions, formal | `tests/clockworks/`, `formal/clockworks/`, `docs/11` |
| power-analysis export that separates simulation, analytical, library-based and measured | `tools/vcd_activity.py`, `tools/power_report.py` |

## Quick start

```
make regress          # lint, unit benches, system bench in Verilator AND Icarus (4 configs, 6 seeds), power demo, formal, synthesis smoke
make mutate           # 33 deliberate RTL defects against the suite (long)
make one TEST=mbist   # one scenario in Icarus (sub-second)
make regs             # regenerate register package / C header / docs from tools/gen_regs.py
```
Requires Verilator 5.x, Icarus Verilog 12, Yosys 0.33+ (z3 for the formal runs), Python 3, `make`.

## Layout

| Path | Contents |
|---|---|
| `rtl/clockworks/` | the RTL (12 modules and packages, compile order in `files.f`), `sf_cw_checker.sv` (assertions), `lint.vlt` |
| `third_party/` | `sf_reset_sync`, `sf_sync2` (P40) and `sf_cmd_gate` (P27), **unmodified**, SHA-256 + provenance |
| `tests/clockworks/` | models, system bench, unit benches, ICG bench, power-tool self-checks |
| `formal/clockworks/` | Yosys proofs (FSM, enable controller, reset sequencer) + planted-bug runs |
| `physical/clockworks/` | SDC (functional, test), STA script, UPF template, ICG qualification checklist and technology bindings, timing exceptions, domain boundary |
| `docs/clockworks/` | audit, architecture, FSM, quiescence, resets, clock control, power states / UPF, DFT, power analysis, limitations, signoff gaps, verification, register map, integration guide |
| `tools/` | register generator, regression driver, mutation runner, synthesis check, VCD / SAIF extraction, power report, vendor check |
| `reports/` | regression, formal, mutation, synthesis, power demo (regenerated by the make targets) |
| `sw/sf_cw_regs.h` | generated C register header |

## Results at delivery

All numbers below are regenerated by `make regress` / `make mutate` and recorded in `reports/`; **60 / 60 regression checks pass** (`reports/regression.md`).

| Evidence | Result |
|---|---|
| Lint, Verilator `-Wall` | 10 modules + the checker: **0 warnings** |
| System bench, Verilator | 20 scenarios, six bench engines: default configuration x 6 seeds (1,071-1,088 checks each), conservative default policy, explicit save/restore with a bench power loss (**state preserved**), negative control without save/restore (**power loss detected, no retention claimed**) - all PASS |
| System bench, Icarus Verilog (second simulator) | the same four configurations x the same seeds, plus a run with real gated clocks (gated edges == enabled edges through resets, MBIST, scan, faults) - all PASS |
| Unit benches (Icarus) | enable controller vs reference model: **2,159,986** checks; operating-state FSM vs the `cw_legal` oracle, four parameter sets: **3,656,797** checks; ICG: edge integrity and cycle equivalence over 20,000 cycles, and a negative control (a plain AND gate glitched 4,998 times) |
| Assertions | 13 checker properties on every cycle of every system run |
| Formal (Yosys + z3) | operating-state FSM, 4 parameter sets: **PROVED** (base case + induction step, all reachable states); enable controller: **PROVED**; reset sequencer: **BOUNDED** to 24 steps; **12 / 12 planted bugs found** by the proofs (not vacuous) |
| Mutation | **33 / 33** deliberate RTL defects killed (system regression, unit benches, second configuration, formal) - `reports/mutation.md` |
| Generic synthesis (Yosys) | six modules synthesise, **no latch**; the clock-gate wrapper **refuses to elaborate** when no ICG cell is selected |
| Defects found by the verification itself | four RTL defects found and fixed (hysteresis counter, missing reset-timeout cause, ledger not cleared under reset, gate reopened in a reset cycle) - `docs/clockworks/11_VERIFICATION.md` section 7 |
| Power | **none produced.** The demo run exports activity, a VCD-derived SAIF and a report that states "not computed" for every power category |
| Hardware / physical | none. No library, STA, CDC, UPF, DFT-flow or silicon result exists |

## Definition of done - status

> *Subsystems can enter and exit supported low-activity states without losing transactions or corrupting memory, and
> test / reset controls operate correctly under verified sequencing.*

**Met in RTL simulation, with bench engine models, for the supported low-activity states (clock enable, optionally ICG), and proved for
the FSM and enable controller.** "Supported" is deliberate: power-off states are not defined, engines whose SRAM is unqualified refuse to be
clock-disabled, and the real engines still need contract sign-off (`docs/clockworks/09_LIMITATIONS.md`).

## Not done (see `docs/clockworks/09_LIMITATIONS.md`)

Real-engine co-simulation; any physical implementation (library, CTS, STA, CDC / RDC, LEC, gate level, UPF); scan insertion and ATPG; power figures;
a second clock domain; ICG-cell and SRAM-macro qualification; narrowing of the activity counters.
