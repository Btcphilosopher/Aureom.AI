# Provenance (unmodified)

| File | Source archive | Path | Used for |
|---|---|---|---|
| `sf_cmd_gate.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-powerclock.zip` (Project 27) | `silicaflux-powerclock/rtl/sf_cmd_gate.sv` | TESTBENCH ONLY: the new-work gate on a valid/ready channel (never tears an offered transfer). It models how an integrator applies `accept_en_o` in front of an engine input. |
