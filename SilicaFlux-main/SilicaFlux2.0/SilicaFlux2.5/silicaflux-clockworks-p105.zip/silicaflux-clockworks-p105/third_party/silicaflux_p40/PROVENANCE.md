# Provenance of vendored SilicaFlux cells (unmodified)

| File | Source archive (this repository) | Path inside the archive | Used for |
|---|---|---|---|
| `sf_reset_sync.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-p40-floorplanbuild.zip` | `silicaflux-p40/rtl/common/sf_reset_sync.sv` | reset synchroniser: async assert, sync release, test-mode bypass (used by `sf_reset_sequencer`) |
| `sf_sync2.sv` | same | `silicaflux-p40/rtl/common/sf_sync2.sv` | 2-flop single-bit level synchroniser (PLL lock) |
| `sf_icg_behav.sv` | same | `silicaflux-p40/rtl/sim_models/sf_icg_behav.sv` | reference only: behavioural ICG (module `sf_icg`) |
| `sf_icg_nangate45.sv` | same | `silicaflux-p40/rtl/physical/tech/nangate45/sf_icg_nangate45.sv` | reference only: Nangate45 `CLKGATETST_X1` binding (module `sf_icg`) |

The files are byte-identical to the archive (`SHA256SUMS`, checked by `tools/check_vendor.py`).
`sf_icg_behav.sv` and `sf_icg_nangate45.sv` both define module `sf_icg`: they are alternatives and are
NOT in the compile list. CLOCKWORKS uses its own wrapper (`sf_cw_clock_gate`) so that the ICG choice is
one define and synthesis fails when none is selected.

If the integrated die already contains P40's `sf_reset_sync` / `sf_sync2`, compile them once.
