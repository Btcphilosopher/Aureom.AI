#!/usr/bin/env python3
"""CLOCKWORKS register-map generator.

One table -> rtl/clockworks/sf_cw_regs_pkg.sv, sw/sf_cw_regs.h and
docs/clockworks/REGISTER_MAP.md.  `--check` regenerates in memory and fails if
any committed output differs (used by `make regs-check`).

Addresses are BYTE addresses on a 32-bit register bus.
"""
import argparse
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

# (name, offset, access, reset, description)
GLOBAL = [
    ("ID",           0x000, "RO",   "0xC10C0105", "Block id. 0xC10C0105 = CLOCKWORKS (project 105), revision 1"),
    ("CAP",          0x004, "RO",   "build",      "[7:0] NE, [8] ICG built in (USE_ICG), [9] PD_SUPPORT (always 0), [10] any SAVE_EN, [11] test adapter, [15:12] NG, [19:16] OW (ledger width)"),
    ("CTRL",         0x008, "RW",   "0x00000001", "[0] EN policy enable (0: requests rejected REJ_DISABLED, auto idle off), [1] SYS_WDT_EN, [2] SYS_WDT_RST_EN, [3] SYS_WDT_LOCK (set-only: freezes SYS_WDT_EN, SYS_WDT_RST_EN and SYSWDT_LIMIT until the controller is reset; EN stays writable)"),
    ("STATUS",       0x00C, "RO",   "-",          "[0] clk_ok, [1] pll_lock, [2] any engine FAULT, [3] any reset active, [4] scan active, [5] MBIST busy, [6] system watchdog stage 1, [7] clock loss seen, [15:8] clk_en vector, [26:24] TestCore mode"),
    ("CMD",          0x010, "WO",   "-",          "[15:0] command, [31:16] key. 1 GLOBAL_RESET (key 0x5AFE), 2 CLEAR_COUNTERS, 3 SNAPSHOT, 4 CLEAR_FAULTS, 5 WDT_KICK"),
    ("IRQ_STATUS",   0x014, "RW1C", "0",          "[0] engine fault, [1] system watchdog stage 1, [2] MBIST done, [3] request rejected, [4] test event, [5] reset sequence done"),
    ("IRQ_EN",       0x018, "RW",   "0",          "interrupt enable, same bits as IRQ_STATUS"),
    ("RST_CFG",      0x01C, "RW",   "0x04000208", "[7:0] reset HOLD clock edges (reset 8, min 2 enforced), [15:8] ready-stable cycles (reset 2, min 1), [31:16] ready timeout cycles (reset 1024, 0 = 65535)"),
    ("SYSWDT_LIMIT", 0x020, "RW",   "0",          "system watchdog stage length in cycles; stage 1 = interrupt, stage 2 = global reset. 0 = off"),
    ("CLK_CFG",      0x024, "RW",   "0x00000004", "[7:0] clock settle cycles after a clock enable is restored"),
    ("TEST_STATUS",  0x028, "RO",   "-",          "[3:0] MBIST result (MB_*), [6:4] MBIST sequencer state, [7] MBIST busy"),
    ("TEST_EV",      0x02C, "RW1C", "0",          "sticky test events: [0] denied (no permit), [1] MBIST refused, [2] diagnostic access denied, [3] scan entered, [4] scan exited, [5] MBIST done, [6] MBIST timeout, [7] MBIST aborted by scan"),
    ("MBIST_CTRL",   0x030, "RW",   "0x00000200", "W: [0] start (pulse), [1] abort (pulse). R/W: [15:8] engines to quiesce for MBIST (their dependents are quiesced first automatically; reset 0x02 = MemoryMatrix)"),
    ("MBIST_TMO",    0x034, "RW",   "0x00001000", "[15:0] MBIST sequencer phase timeout in cycles"),
    ("CYC_LO",       0x038, "RO",   "-",          "total cycle counter, low word (value captured by SNAPSHOT)"),
    ("CYC_HI",       0x03C, "RO",   "-",          "total cycle counter, high word (captured by SNAPSHOT)"),
    ("CAP_SRAM",     0x040, "RO",   "build",      "[7:0] HAS_SRAM, [15:8] SRAM_QUAL, [23:16] SAVE_EN, [31:24] LEDGER_EN (per engine bit)"),
    ("CAP_POL",      0x044, "RO",   "build",      "[7:0] ALLOW_GATE, [15:8] CAN_CANCEL, [23:16] RST_ON_WAKE"),
]

E_BASE, E_STRIDE = 0x100, 0x40
ENGINE = [
    ("CTRL",      0x00, "RW",   "0x00000038", "[0] AUTO_IDLE_EN, [1] FAULT_RST_EN, [2] WDT_EN, [3] WAKE_EN (wake on pending input / engine wake request), [7:4] MAX_AUTO_RST fault resets before the engine stays in FAULT (reset 3)"),
    ("REQ",       0x04, "RW",   "-",          "W: [2:0] requested state; the write is the request. Requestable: 0 ACTIVE (wake), 3 CLOCK_DISABLED (idle), 5 RESET. Anything else is rejected. R: [3:0] last reject code, [8] last request accepted, [9] last request rejected, [31:16] reject count"),
    ("STATE",     0x08, "RO",   "-",          "[2:0] state, [5:3] drain step, [8:6] wake step, [9] clk_en, [10] accept, [11] fabric connect, [12] quiet, [13] quiesce req, [14] save req, [15] restore req, [16] reset active, [17] interlock hit, [18] upstream stalled, [19] engine ready"),
    ("FAULT",     0x0C, "RW1C", "0",          "[7:0] sticky fault causes FC_*, [15:8] sticky events SE_* (reject, dependency timeout, cancel, wake done, quiet)"),
    ("QSTAT",     0x10, "RO",   "-",          "[5:0] quiescence vector (Q_*), [25:16] outstanding transactions (ledger)"),
    ("QCFG",      0x14, "RW",   "0x0000043F", "[5:0] required quiescence conditions, bit per Q_* (reset: all six required), [15:8] cycles the vector must be stable (reset 4, 0 = 1)"),
    ("TMO_DRAIN", 0x18, "RW",   "0x00C803E8", "[15:0] drain timeout (reset 1000), [31:16] cancel timeout (reset 200). 0 = 65535"),
    ("TMO_WAKE",  0x1C, "RW",   "0x03E803E8", "[15:0] wake timeout (reset 1000), [31:16] idle-request dependency timeout (reset 1000). 0 = 65535"),
    ("IDLE_THR",  0x20, "RW",   "0",          "[23:0] consecutive idle cycles before an automatic idle request (0 = off; requires CTRL.AUTO_IDLE_EN)"),
    ("MIN_ACTIVE",0x24, "RW",   "0x00000010", "[15:0] minimum cycles in ACTIVE before any idle request is honoured (hysteresis)"),
    ("WDT_LIMIT", 0x28, "RW",   "0",          "[23:0] progress watchdog: cycles busy without a retired transaction (0 = off; requires CTRL.WDT_EN)"),
    ("RST",       0x2C, "RW1C", "-",          "[7:0] sticky reset causes RC_* (W1C), [31:16] reset sequences since controller reset"),
]

C_BASE, C_STRIDE = 0x400, 0x80
METRICS = ["ACTIVE", "IDLE", "DISABLED", "TRANS", "WAKE_CNT", "WAKE_SUM", "WAKE_MAX", "WAKE_LAST",
           "QUI_CNT", "QUI_SUM", "QUI_MAX", "QUI_LAST", "RST_EVENTS", "OUT_CHG_MAX", "OUT_CHG_SUM",
           "CHG_WITH_OUT", "DIS_WITH_OUT", "CANCEL_CNT"]

CMD_CODES = [("GLOBAL_RESET", 1), ("CLEAR_COUNTERS", 2), ("SNAPSHOT", 3), ("CLEAR_FAULTS", 4), ("WDT_KICK", 5)]


def render_pkg():
    o = ["// GENERATED by tools/gen_regs.py -- do not edit.", "`default_nettype none", "package sf_cw_regs_pkg;"]
    for n, off, *_ in GLOBAL:
        o.append(f"  localparam logic [11:0] R_{n} = 12'h{off:03X};")
    o.append(f"  localparam logic [11:0] E_BASE   = 12'h{E_BASE:03X};")
    o.append(f"  localparam logic [11:0] E_STRIDE = 12'h{E_STRIDE:03X};")
    for n, off, *_ in ENGINE:
        o.append(f"  localparam logic [11:0] EO_{n} = 12'h{off:03X};")
    o.append(f"  localparam logic [11:0] C_BASE   = 12'h{C_BASE:03X};")
    o.append(f"  localparam logic [11:0] C_STRIDE = 12'h{C_STRIDE:03X};")
    for n, v in CMD_CODES:
        o.append(f"  localparam logic [15:0] CMD_{n} = 16'd{v};")
    o.append("  localparam logic [15:0] CMD_KEY  = 16'h5AFE;")
    o.append("  localparam logic [31:0] CW_ID    = 32'hC10C0105;")
    o += ["endpackage", "`default_nettype wire", ""]
    return "\n".join(o)


def render_h():
    o = ["/* GENERATED by tools/gen_regs.py -- do not edit. */", "#ifndef SF_CW_REGS_H", "#define SF_CW_REGS_H"]
    for n, off, *_ in GLOBAL:
        o.append(f"#define SF_CW_R_{n:<14} 0x{off:03X}u")
    o.append(f"#define SF_CW_E_BASE           0x{E_BASE:03X}u")
    o.append(f"#define SF_CW_E_STRIDE         0x{E_STRIDE:03X}u")
    for n, off, *_ in ENGINE:
        o.append(f"#define SF_CW_EO_{n:<12} 0x{off:03X}u")
    o.append(f"#define SF_CW_C_BASE           0x{C_BASE:03X}u")
    o.append(f"#define SF_CW_C_STRIDE         0x{C_STRIDE:03X}u")
    for i, m in enumerate(METRICS):
        o.append(f"#define SF_CW_M_{m:<14} {i}u")
    for n, v in CMD_CODES:
        o.append(f"#define SF_CW_CMD_{n:<16} {v}u")
    o.append("#define SF_CW_CMD_KEY          0x5AFEu")
    o.append("#define SF_CW_E_ADDR(e, off)   (SF_CW_E_BASE + (e) * SF_CW_E_STRIDE + (off))")
    o.append("#define SF_CW_C_ADDR(e, m)     (SF_CW_C_BASE + (e) * SF_CW_C_STRIDE + 4u * (m))")
    o += ["#endif", ""]
    return "\n".join(o)


def render_md():
    o = ["# CLOCKWORKS register map", "",
         "_Generated by `tools/gen_regs.py` from the same table that produces `sf_cw_regs_pkg.sv` and `sw/sf_cw_regs.h`._", "",
         "Byte addresses, 32-bit bus in the functional clock domain. Unmapped addresses return `reg_err_o`. "
         "Engine order: 0 CC (ControlCore), 1 MM (MemoryMatrix), 2 MR (Meridian), 3 DMA (StreamDMA), 4 TC (TensorCore), 5 PF (PacketForge).", "",
         "## Global registers", "", "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
    for n, off, acc, rst, d in GLOBAL:
        o.append(f"| 0x{off:03X} | {n} | {acc} | {rst} | {d} |")
    o += ["", f"## Per-engine registers (base 0x{E_BASE:03X} + engine * 0x{E_STRIDE:02X})", "",
          "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
    for n, off, acc, rst, d in ENGINE:
        o.append(f"| +0x{off:02X} | {n} | {acc} | {rst} | {d} |")
    o += ["", f"## Activity counters (base 0x{C_BASE:03X} + engine * 0x{C_STRIDE:02X} + 4 * metric)", "",
          "Read-only, 32-bit saturating. Values are the SNAPSHOT copy: write `CMD = SNAPSHOT` first, then read; "
          "the whole set (and CYC_LO/CYC_HI) is captured in one cycle, so the readout is coherent. `CLEAR_COUNTERS` zeroes the live counters.", "",
          "| Index | Metric |", "|---|---|"]
    for i, m in enumerate(METRICS):
        o.append(f"| {i} | {m} |")
    o += ["", "`ACTIVE + IDLE + DISABLED` equals the total cycle count for every engine (checked by the regression).", ""]
    return "\n".join(o)


OUTS = {
    ROOT / "rtl/clockworks/sf_cw_regs_pkg.sv": render_pkg,
    ROOT / "sw/sf_cw_regs.h": render_h,
    ROOT / "docs/clockworks/REGISTER_MAP.md": render_md,
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    bad = 0
    for p, fn in OUTS.items():
        txt = fn()
        if a.check:
            if not p.exists() or p.read_text() != txt:
                print(f"MISMATCH {p}")
                bad += 1
        else:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(txt)
            print(f"wrote {p.relative_to(ROOT)}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
