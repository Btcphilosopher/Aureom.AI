#!/usr/bin/env python3
"""Verify that every vendored third-party file is byte-identical to the recorded SHA-256."""
import hashlib, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
bad = 0
for sums in sorted((ROOT / "third_party").glob("*/SHA256SUMS")):
    for line in sums.read_text().splitlines():
        h, name = line.split()
        f = sums.parent / name
        ok = f.exists() and hashlib.sha256(f.read_bytes()).hexdigest() == h
        print(("ok   " if ok else "FAIL ") + str(f.relative_to(ROOT)))
        bad += (not ok)
sys.exit(1 if bad else 0)
