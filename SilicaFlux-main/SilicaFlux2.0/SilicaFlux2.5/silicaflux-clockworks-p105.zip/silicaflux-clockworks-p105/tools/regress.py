#!/usr/bin/env python3
"""CLOCKWORKS regression driver.  One command, one report (reports/regression.md).

Stages: lint | units | sim_vl | sim_ic | power | formal | synth | mutate | all
  lint    Verilator -Wall on every module and the top (must be clean)
  units   Icarus unit benches (enable controller, FSM, ICG) + power-tool self-checks + register map + vendor check
  sim_vl  system bench in Verilator: 4 configurations, several stress seeds
  sim_ic  the same in Icarus Verilog (second simulator)
  power   end-to-end demo of the activity -> SAIF -> report tools
  formal  formal/clockworks (Yosys + z3)
  synth   generic Yosys synthesis smoke test (tools/synth_check.py)
  mutate  tools/mutate.py (long)
"""
import argparse, json, os, pathlib, re, shutil, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent.parent
B = ROOT / "build"
FILES = [l.strip() for l in (ROOT / "rtl/clockworks/files.f").read_text().splitlines() if l.strip() and not l.startswith("//")]
SYS = ["rtl/clockworks/sf_cw_checker.sv", "third_party/silicaflux_powerclock/sf_cmd_gate.sv",
       "tests/clockworks/cw_models.sv", "tests/clockworks/tb_cw_system.sv"]
RES = []

def sh(cmd, **kw):
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, **kw)

def record(stage, name, ok, detail):
    RES.append((stage, name, ok, detail))
    print(f"{'PASS' if ok else 'FAIL'} {stage:7s} {name:34s} {detail}", flush=True)

def tb(out):
    m = re.findall(r"TB_RESULT (PASS|FAIL) checks=(\d+) errors=(\d+)", out)
    return m[-1] if m else None

def lint():
    mods = ["sf_power_state_fsm", "sf_clock_enable_ctrl", "sf_reset_sequencer", "sf_cw_wdt", "sf_activity_counters",
            "sf_clock_test_adapter", "sf_cw_regs", "sf_cw_clock_gate", "sf_cw_icg_wrap", "sf_clock_power_ctrl"]
    for m in mods:
        r = sh(["verilator", "--lint-only", "-Wall", "--top-module", m, "rtl/clockworks/lint.vlt"] + FILES)
        warn = [l for l in r.stderr.splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
        record("lint", m, r.returncode == 0 and not warn, "clean" if not warn else warn[0][:90])
    r = sh(["verilator", "--lint-only", "-Wall", "--top-module", "sf_cw_checker", "rtl/clockworks/lint.vlt", "rtl/clockworks/sf_cw_pkg.sv", "rtl/clockworks/sf_cw_checker.sv"])
    record("lint", "sf_cw_checker", r.returncode == 0 and not r.stderr.strip(), "clean" if r.returncode == 0 else r.stderr[:90])

def units():
    r = sh([sys.executable, "-I", "tools/gen_regs.py", "--check"]); record("units", "register map in sync", r.returncode == 0, r.stdout.strip()[:80] or "generated files match")
    r = sh([sys.executable, "-I", "tools/check_vendor.py"]); record("units", "vendored cells unmodified", r.returncode == 0, "SHA-256 match")
    r = sh([sys.executable, "-I", "tests/clockworks/test_power_tools.py"]); record("units", "power-tool self-checks", r.returncode == 0, (r.stderr.strip().splitlines() or [""])[-1])
    for name, files, top in [("unit_enable_ctrl", ["rtl/clockworks/sf_cw_pkg.sv", "rtl/clockworks/sf_clock_enable_ctrl.sv", "tests/clockworks/tb_cw_unit_ec.sv"], "tb_cw_unit_ec"),
                             ("unit_power_state_fsm", ["rtl/clockworks/sf_cw_pkg.sv", "rtl/clockworks/sf_power_state_fsm.sv", "tests/clockworks/tb_cw_unit_fsm.sv"], "tb_cw_unit_fsm"),
                             ("unit_icg", ["rtl/clockworks/sf_cw_clock_gate.sv", "tests/clockworks/tb_cw_icg.sv"], "tb_cw_icg")]:
        exe = B / f"{name}.vvp"; B.mkdir(exist_ok=True)
        c = sh(["iverilog", "-g2012", "-s", top, "-o", str(exe)] + files)
        if not exe.exists():
            record("units", name, False, "compile failed: " + c.stderr[-80:]); continue
        r = sh(["vvp", str(exe)]); t = tb(r.stdout)
        record("units", name, bool(t and t[0] == "PASS"), f"{t[1]} checks" if t else "no result")

def sim_vl(seeds):
    cfgs = [("default", []), ("defpol", ["-GDEFPOL=1"]), ("save_volatile", ["-GSAVE_ALL=1", "-GVOLATILE=1"]), ("neg_control", ["-GVOLATILE=1"])]
    for name, g in cfgs:
        out = B / f"vl_{name}"
        b = sh(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-MULTIDRIVEN", "-Wno-UNOPTFLAT",
                "-Wno-PINMISSING", "-Wno-IMPLICIT", "-Wno-CASEINCOMPLETE", "--top-module", "tb_cw_system", "-Mdir", str(out), "--public-flat-rw",
                "rtl/clockworks/lint.vlt"] + FILES + SYS + g)
        exe = out / "Vtb_cw_system"
        if not exe.exists():
            record("sim_vl", name, False, "build failed: " + b.stderr[-100:]); continue
        for s in (seeds if name == "default" else [1]):
            r = sh([str(exe), f"+SEED={s}"]); t = tb(r.stdout)
            extra = " (negative control: corruption detected as expected)" if name == "neg_control" and "NEG_CONTROL" in r.stdout else ""
            record("sim_vl", f"{name} seed {s}", bool(t and t[0] == "PASS"), (f"{t[1]} checks" if t else "no result") + extra)

def sim_ic(seeds):
    cfgs = [("default", []), ("defpol", ["-Ptb_cw_system.DEFPOL=1"]), ("save_volatile", ["-Ptb_cw_system.SAVE_ALL=1", "-Ptb_cw_system.VOLATILE=1"]), ("neg_control", ["-Ptb_cw_system.VOLATILE=1"]), ("icg", ["-Ptb_cw_system.USE_ICG=1"])]
    for name, g in cfgs:
        exe = B / f"ic_{name}.vvp"
        c = sh(["iverilog", "-g2012", "-s", "tb_cw_system", "-o", str(exe)] + g + FILES + SYS)
        if not exe.exists():
            record("sim_ic", name, False, "compile failed: " + c.stderr[-100:]); continue
        for s in (seeds if name == "default" else [1]):
            r = sh(["vvp", str(exe), f"+SEED={s}"]); t = tb(r.stdout)
            extra = " (negative control: corruption detected as expected)" if name == "neg_control" and "NEG_CONTROL" in r.stdout else ""
            record("sim_ic", f"{name} seed {s}", bool(t and t[0] == "PASS"), (f"{t[1]} checks" if t else "no result") + extra)

def power():
    exe = B / "ic_default.vvp"
    if not exe.exists():
        sim_ic([1])
    (ROOT / "reports").mkdir(exist_ok=True)
    r = sh(["vvp", str(exe), "+TEST=idle_wake", f"+ACT={ROOT/'reports/activity_demo.json'}", f"+VCD={B/'demo.vcd'}"])
    ok = bool(tb(r.stdout) and tb(r.stdout)[0] == "PASS") and (ROOT / "reports/activity_demo.json").exists()
    record("power", "activity export from simulation", ok, "reports/activity_demo.json")
    r = sh([sys.executable, "-I", "tools/vcd_activity.py", str(B / "demo.vcd"), "--signals", "clk_en", "--scope", "tb_cw_system",
            "--saif", str(ROOT / "reports/clk_en_demo.saif"), "--json", str(ROOT / "reports/clk_en_demo.json")])
    record("power", "VCD -> activity / SAIF", r.returncode == 0, r.stdout.strip().splitlines()[0][:90] if r.stdout.strip() else r.stderr[-80:])
    r = sh([sys.executable, "-I", "tools/power_report.py", "--activity", "reports/activity_demo.json", "--out", "reports/power_report_demo.md"])
    record("power", "report (no params: nothing invented)", r.returncode == 0 and "not computed" in r.stdout, "reports/power_report_demo.md")

def formal():
    r = sh([sys.executable, "-I", "formal/clockworks/run_formal.py"])
    for line in r.stdout.splitlines():
        if line.startswith("FORMAL"):
            record("formal", line.split()[1], "UNEXPECTED" not in line, " ".join(line.split()[2:])[:110])
    if not any(x[0] == "formal" for x in RES):
        record("formal", "driver", False, r.stderr[-100:])

def synth():
    r = sh([sys.executable, "-I", "tools/synth_check.py"])
    record("synth", "generic synthesis, no latches, ICG refusal", r.returncode == 0, "reports/synth.md")

def mutate():
    r = sh([sys.executable, "-I", "tools/mutate.py", "--jobs", "3"])
    last = r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
    record("mutate", "mutation check", "killed" in last, last[:120])

def report(stages):
    lines = ["# CLOCKWORKS regression report", "", f"Generated {time.strftime('%Y-%m-%d %H:%M:%S')} by `tools/regress.py {' '.join(stages)}`.", "",
             "| stage | check | result | detail |", "|---|---|---|---|"]
    for s, n, ok, d in RES:
        lines.append(f"| {s} | {n} | {'PASS' if ok else '**FAIL**'} | {d.replace('|', '/')} |")
    npass = sum(1 for r in RES if r[2])
    lines += ["", f"**{npass} / {len(RES)} checks passed.**"]
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports/regression.md").write_text("\n".join(lines) + "\n")
    print(f"\n{npass}/{len(RES)} passed")
    return npass == len(RES)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("stages", nargs="*", default=["lint", "units", "sim_vl", "sim_ic", "power", "formal", "synth"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5, 6])
    a = ap.parse_args()
    st = a.stages if a.stages != ["all"] else ["lint", "units", "sim_vl", "sim_ic", "power", "formal", "synth", "mutate"]
    for s in st:
        {"lint": lint, "units": units, "sim_vl": lambda: sim_vl(a.seeds), "sim_ic": lambda: sim_ic(a.seeds), "power": power, "formal": formal, "synth": synth, "mutate": mutate}[s]()
    sys.exit(0 if report(st) else 1)
