#!/usr/bin/env python3
"""VCD -> switching-activity extraction and SAIF export for CLOCKWORKS.

SIMULATION ACTIVITY ONLY.  The numbers are time-at-0, time-at-1 and toggle counts of RTL signals
taken from a simulation.  They are the INPUT of a power-analysis tool (PrimePower, Voltus, OpenSTA
`read_saif` ...), not a power result.  The SAIF net names are the RTL names found in the VCD; they must
be mapped to the hierarchy and net names of the synthesised netlist before use (see the option
--prefix and docs/clockworks/08_POWER_ANALYSIS.md).

usage: vcd_activity.py sim.vcd --signals clk_en eng_state [--scope tb_cw_system] [--json out.json] [--saif out.saif]
"""
import argparse, json, re, sys, datetime

def parse_vcd(path):
    """Return ({id: (name, width, scope)}, {id: [(time, value_str)]}, timescale_ps, end_time)."""
    ids, changes, scope, ts, t = {}, {}, [], 1, 0
    unit = {"s": 10**12, "ms": 10**9, "us": 10**6, "ns": 10**3, "ps": 1, "fs": 1e-3}
    with open(path) as f:
        tokens = []
        in_defs = True
        for line in f:
            line = line.strip()
            if not line:
                continue
            if in_defs:
                if line.startswith("$timescale"):
                    m = re.search(r"(\d+)\s*(s|ms|us|ns|ps|fs)", line)
                    if m:
                        ts = int(m.group(1)) * unit[m.group(2)]
                elif line.startswith("$scope"):
                    scope.append(line.split()[2])
                elif line.startswith("$upscope"):
                    scope.pop()
                elif line.startswith("$var"):
                    p = line.split()
                    ids.setdefault(p[3], (p[4] + ("" if len(p) < 7 or p[5] == "$end" else p[5]), int(p[2]), ".".join(scope)))
                    changes.setdefault(p[3], [])
                elif line.startswith("$enddefinitions"):
                    in_defs = False
                continue
            if line.startswith("#"):
                t = int(line[1:])
            elif line[0] in "01xzXZ" and len(line) > 1:
                if line[1:] in changes:
                    changes[line[1:]].append((t, line[0].lower()))
            elif line[0] in "bB":
                v, i = line[1:].split()
                if i in changes:
                    changes[i].append((t, v.lower()))
    return ids, changes, ts, t

def per_bit_activity(width, evs, end):
    """T0/T1/TX durations and toggle counts for each bit of a signal, given its value-change list."""
    res = [dict(T0=0, T1=0, TX=0, TC=0) for _ in range(width)]
    if not evs:
        return res
    cur = ["x"] * width
    last = evs[0][0]
    for k, (tm, val) in enumerate(evs):
        dt = tm - last
        for b in range(width):
            c = cur[b]
            res[b]["T0" if c == "0" else "T1" if c == "1" else "TX"] += dt
        last = tm
        v = val if width == 1 else val.rjust(width, val[0] if val[0] in "xz" else "0")
        for b in range(width):
            nb = v if width == 1 else v[width - 1 - b]
            if cur[b] in "01" and nb in "01" and cur[b] != nb:
                res[b]["TC"] += 1
            cur[b] = nb
    dt = end - last
    for b in range(width):
        c = cur[b]
        res[b]["T0" if c == "0" else "T1" if c == "1" else "TX"] += dt
    return res

def extract(path, wanted, scope):
    ids, changes, ts, end = parse_vcd(path)
    out = {}
    for i, (name, width, sc) in ids.items():
        base = re.sub(r"\[.*\]$", "", name)
        if base in wanted and (scope is None or sc == scope or sc.endswith("." + scope) or sc.split(".")[-1] == scope):
            out[(sc, base)] = (width, per_bit_activity(width, changes[i], end))
    return out, ts, end

def write_saif(path, act, ts_ps, end, design):
    with open(path, "w") as f:
        f.write("(SAIFILE\n(SAIFVERSION \"2.0\")\n(DIRECTION \"backward\")\n")
        f.write(f"(DESIGN \"{design}\")\n(DATE \"{datetime.date.today().isoformat()}\")\n(VENDOR \"SilicaFlux CLOCKWORKS\")\n")
        f.write("(PROGRAM_NAME \"vcd_activity.py\")\n(VERSION \"1.0\")\n(DIVIDER /)\n")
        f.write(f"(TIMESCALE 1 ps)\n(DURATION {int(end * ts_ps)})\n")
        for (sc, base), (width, bits) in sorted(act.items()):
            f.write(f"(INSTANCE {sc.replace('.', '/') or design}\n  (NET\n")
            for b, a in enumerate(bits):
                n = base if width == 1 else f"{base}[{b}]"
                f.write(f"    ({n} (T0 {int(a['T0'] * ts_ps)}) (T1 {int(a['T1'] * ts_ps)}) (TX {int(a['TX'] * ts_ps)}) (TC {a['TC']}) (IG 0))\n")
            f.write("  )\n)\n")
        f.write(")\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("vcd")
    ap.add_argument("--signals", nargs="+", required=True)
    ap.add_argument("--scope", default=None)
    ap.add_argument("--json")
    ap.add_argument("--saif")
    ap.add_argument("--design", default="sf_clock_power_ctrl")
    a = ap.parse_args()
    act, ts, end = extract(a.vcd, set(a.signals), a.scope)
    if not act:
        print("no matching signals", file=sys.stderr); sys.exit(2)
    js = {"kind": "simulation-activity", "source": a.vcd, "duration_time_units": end, "timescale_ps": ts, "signals": {}}
    for (sc, base), (width, bits) in sorted(act.items()):
        js["signals"][f"{sc}.{base}"] = [dict(bit=b, duty=(x["T1"] / max(1, x["T0"] + x["T1"])), **x) for b, x in enumerate(bits)]
    if a.json:
        json.dump(js, open(a.json, "w"), indent=1)
    if a.saif:
        write_saif(a.saif, act, ts, end, a.design)
    for k, v in js["signals"].items():
        print(k, " ".join(f"[{x['bit']}] duty={x['duty']:.3f} toggles={x['TC']}" for x in v))

if __name__ == "__main__":
    main()
