#!/usr/bin/env python3
"""Generic (technology-independent) Yosys synthesis smoke test.  Writes reports/synth.md.

What it shows:  every CLOCKWORKS module synthesises to generic gates, with NO inferred latch (the only
latch in the package is the simulation-only ICG model, excluded by `SYNTHESIS`), and the clock-gate
wrapper REFUSES to elaborate when no real ICG cell is selected.
What it does NOT show: timing, area in a real library, power, CDC/RDC signoff, or physical feasibility.
"""
import pathlib, re, subprocess, sys, tempfile
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "formal/clockworks"))
OUT = ROOT / "build/synth"; OUT.mkdir(parents=True, exist_ok=True)
MODS = [("sf_power_state_fsm", []), ("sf_clock_enable_ctrl", []), ("sf_reset_sequencer", ["third_party/silicaflux_p40/sf_reset_sync.sv"]),
        ("sf_cw_wdt", []), ("sf_activity_counters", []), ("sf_clock_test_adapter", [])]

def prep(files, d):
    subprocess.run([sys.executable, "-I", str(ROOT / "formal/clockworks/yosys_prep.py"), str(d), str(ROOT / "rtl/clockworks/sf_cw_pkg.sv")] + [str(ROOT / f) for f in files], check=True)

rows = []
for m, extra in MODS:
    d = OUT / m
    prep([f"rtl/clockworks/{m}.sv"] + extra, d)
    rd = " ".join(str(d / pathlib.Path(f).name) for f in [f"rtl/clockworks/{m}.sv"] + extra)
    log = OUT / f"{m}.log"
    r = subprocess.run(["yosys", "-q", "-l", str(log), "-p", f"read_verilog -sv {rd}; hierarchy -check -top {m}; proc; flatten; opt; "
                        f"memory_map; opt; techmap; opt -fast; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX; opt_clean; stat"], capture_output=True, text=True)
    txt = log.read_text() if log.exists() else r.stderr
    ok = r.returncode == 0
    stat = txt.split("Printing statistics.")[-1] if "Printing statistics." in txt else ""
    latch = re.search(r"^\s+\$_?D?LATCH\w*\s+\d+|^\s+\$dlatch\w*\s+\d+|^\s+\$_DLATCH\w*\s+\d+", stat, re.M) is not None
    cm = re.findall(r"Number of cells:\s+(\d+)", stat)
    cells = cm[-1] if cm else "?"
    ffs = sum(int(n) for k, n in re.findall(r"^\s+(\$_(?:S?DFFE?|DFF)[A-Z0-9_]*)\s+(\d+)", stat, re.M))
    rows.append((m, ok, latch, cells, ffs, "" if ok else (r.stderr.strip().splitlines() or [""])[-1][:80]))

# ICG wrapper: with no target selected, synthesis must fail
d = OUT / "icg"; d.mkdir(exist_ok=True)
neg = subprocess.run(["yosys", "-q", "-p", f"read_verilog -sv -DSYNTHESIS {ROOT/'rtl/clockworks/sf_cw_clock_gate.sv'}; hierarchy -check -top sf_cw_clock_gate"], capture_output=True, text=True)
neg_ok = neg.returncode != 0 and "sf_cw_icg_target_not_selected" in (neg.stderr + neg.stdout)
(d / "bb.v").write_text("(* blackbox *) module sf_cw_icg_lib_cell(input CK, input E, input SE, output GCK); endmodule\n")
pos = subprocess.run(["yosys", "-p", f"read_verilog -sv -DSYNTHESIS -DSF_CW_ICG_LIB {d/'bb.v'} {ROOT/'rtl/clockworks/sf_cw_clock_gate.sv'} {ROOT/'rtl/clockworks/sf_cw_icg_wrap.sv'}; hierarchy -check -top sf_cw_icg_wrap; proc; flatten; opt; stat"], capture_output=True, text=True)
pos_ok = pos.returncode == 0 and re.search(r"sf_cw_icg_lib_cell\s+6", pos.stdout) is not None

L = ["# Generic synthesis check (Yosys, technology-independent)", "",
     "| module | synthesises | latch inferred | generic cells | flip-flops | note |", "|---|---|---|---|---|---|"]
for m, ok, latch, cells, ffs, note in rows:
    L.append(f"| {m} | {'yes' if ok else '**NO**'} | {'**YES**' if latch else 'no'} | {cells} | {ffs} | {note} |")
L += ["", "## Clock-gate wrapper", "",
      f"* no ICG target selected + `SYNTHESIS`: **{'refuses to elaborate (sf_cw_icg_target_not_selected) - as intended' if neg_ok else 'DID NOT FAIL - BUG'}**",
      f"* `SF_CW_ICG_LIB` with a library-cell blackbox: **{'elaborates, one library cell per engine' if pos_ok else 'FAILED'}**", "",
      "`sf_cw_regs` and `sf_clock_power_ctrl` are not run through this script: the register file and the top level use SystemVerilog",
      "features beyond Yosys 0.33's native frontend (unpacked arrays of packed vectors in ports of nested generates, wildcard imports of two packages).",
      "They are covered by Verilator -Wall lint and by simulation; a full-chip synthesis needs the integrator's tool (Synopsys DC, Cadence Genus, or Yosys+slang).", "",
      "Not shown: timing, real-library area, power, CDC / RDC signoff. See docs/clockworks/09_LIMITATIONS.md."]
(ROOT / "reports").mkdir(exist_ok=True)
(ROOT / "reports/synth.md").write_text("\n".join(L) + "\n")
print("\n".join(L))
sys.exit(0 if all(r[1] and not r[2] for r in rows) and neg_ok and pos_ok else 1)
