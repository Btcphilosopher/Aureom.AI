#!/usr/bin/env python3
"""Build the delivery archive:  tools/package.py <out.zip>
Writes MANIFEST.sha256 (SHA-256 of every file), then a zip with one top-level folder.
Excludes build products (build/), caches and any VCS metadata.  Nothing is committed anywhere."""
import hashlib, pathlib, sys, zipfile, os

ROOT = pathlib.Path(__file__).resolve().parent.parent
NAME = "silicaflux-clockworks-p105"
SKIP_DIRS = {"build", "__pycache__", ".git", ".pytest_cache"}
SKIP_SUFFIX = {".pyc", ".vvp"}

def files():
    for p in sorted(ROOT.rglob("*")):
        rel = p.relative_to(ROOT)
        if p.is_dir() or any(part in SKIP_DIRS for part in rel.parts) or p.suffix in SKIP_SUFFIX or rel.name == "MANIFEST.sha256":
            continue
        yield p, rel

def main(out):
    lines = []
    for p, rel in files():
        lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel.as_posix()}")
    (ROOT / "MANIFEST.sha256").write_text("\n".join(lines) + "\n")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p, rel in list(files()) + [(ROOT / "MANIFEST.sha256", pathlib.Path("MANIFEST.sha256"))]:
            zi = zipfile.ZipInfo(f"{NAME}/{rel.as_posix()}", date_time=(2026, 11, 19, 12, 0, 0))
            zi.external_attr = (0o755 if os.access(p, os.X_OK) else 0o644) << 16
            zi.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(zi, p.read_bytes())
    print(f"{out}: {len(lines) + 1} files")

if __name__ == "__main__":
    main(sys.argv[1])
