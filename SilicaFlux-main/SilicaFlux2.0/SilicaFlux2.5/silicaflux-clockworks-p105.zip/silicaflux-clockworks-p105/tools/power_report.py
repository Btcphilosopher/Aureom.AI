#!/usr/bin/env python3
"""CLOCKWORKS power report.  Keeps four kinds of number strictly apart and invents none.

  1. SIMULATION ACTIVITY   cycle counts and enable duty from an RTL simulation   (always available)
  2. ANALYTICAL ESTIMATE   only if you supply --params (capacitance, voltage, frequency per engine);
                           P_clock = C * V^2 * f * duty           labelled with the supplied assumptions
  3. LIBRARY-BASED         only if you supply --lib (per-engine clock-tree power at 100 % enable, taken
                           from a power tool run on a real netlist with real library data);
                           P = P_full * duty, leakage unchanged, ICG overhead only if supplied
  4. MEASURED HARDWARE     only echoed from --measured; never computed here

Without the corresponding input file the tool prints "not computed".  It never prints an energy saving
that is not derived from the supplied inputs, and the clock-enable duty it derives is an ACTIVITY
statistic, not a power or energy figure.

usage: power_report.py --activity act.json [--params p.json] [--lib l.json] [--measured m.json] [--out report.md]
"""
import argparse, json, sys

def load(p):
    return json.load(open(p)) if p else None

def duty(e):
    tot = e["ACTIVE"] + e["IDLE"] + e["DISABLED"]
    return (e["ACTIVE"] + e["IDLE"]) / tot if tot else float("nan"), tot

def build(act, params, lib, meas):
    rows, notes = [], []
    for name, e in act["engines"].items():
        d, tot = duty(e)
        r = {"engine": name, "cycles": tot, "active": e["ACTIVE"], "idle": e["IDLE"], "disabled": e["DISABLED"],
             "enable_duty": d, "idle_while_enabled": (e["IDLE"] / tot if tot else float("nan")),
             "transitions": e["TRANS"], "wake_latency_mean": (e["WAKE_SUM"] / e["WAKE_CNT"] if e["WAKE_CNT"] else None),
             "wake_latency_max": e["WAKE_MAX"] if e["WAKE_CNT"] else None,
             "quiesce_latency_mean": (e["QUI_SUM"] / e["QUI_CNT"] if e["QUI_CNT"] else None),
             "disable_with_outstanding": e["DIS_WITH_OUT"]}
        if params and name in params.get("engines", {}):
            p = params["engines"][name]
            full = p["clock_cap_fF"] * 1e-15 * p["V"] ** 2 * p["f_MHz"] * 1e6          # W at 100 % enable
            r["analytical_clock_mW_full"] = full * 1e3
            r["analytical_clock_mW"] = full * 1e3 * d
        if lib and name in lib.get("engines", {}):
            l = lib["engines"][name]
            full = l["clock_tree_mW_at_full_enable"]
            r["library_clock_mW_full"] = full
            r["library_clock_mW"] = full * d + l.get("icg_overhead_mW", 0.0)
            r["library_leakage_mW_unchanged"] = l.get("leakage_mW")
        rows.append(r)
    if params:
        notes.append("ANALYTICAL: assumptions supplied by the user: " + json.dumps(params.get("assumptions", params.get("engines"))))
    if lib:
        notes.append("LIBRARY-BASED: " + str(lib.get("provenance", "provenance NOT stated in the input file")) +
                     "; assumes clock-tree power proportional to enable duty, leakage unchanged, data-path switching not included.")
    return rows, notes

def render(act, rows, notes, params, lib, meas):
    L = ["# CLOCKWORKS power report", "",
         f"Activity source: {act.get('source')} ({act.get('config')}); total cycles {act.get('total_cycles')}.", "",
         "## 1. Simulation activity (RTL cycle counts - NOT power)", "",
         "| engine | cycles | active | idle (clock on) | disabled | enable duty | transitions | wake latency mean / max | quiesce latency mean | disable with outstanding |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    f = lambda x: "-" if x is None else (f"{x:.1f}" if isinstance(x, float) else str(x))
    for r in rows:
        L.append(f"| {r['engine']} | {r['cycles']} | {r['active']} | {r['idle']} | {r['disabled']} | {r['enable_duty']:.3f} | "
                 f"{r['transitions']} | {f(r['wake_latency_mean'])} / {f(r['wake_latency_max'])} | {f(r['quiesce_latency_mean'])} | {r['disable_with_outstanding']} |")
    L += ["", "The enable duty is the fraction of cycles the clock ENABLE was high. It is an activity statistic of ONE simulation run;",
          "it says nothing about energy until combined with real capacitance or library data below.", ""]
    L += ["## 2. Analytical estimate", ""]
    if params:
        L += ["ASSUMED parameters, supplied by the user. NOT library-based, NOT measured.", "",
              "| engine | P_clock at 100 % enable (mW) | P_clock at the simulated duty (mW) |", "|---|---|---|"]
        for r in rows:
            if "analytical_clock_mW" in r:
                L.append(f"| {r['engine']} | {r['analytical_clock_mW_full']:.4g} | {r['analytical_clock_mW']:.4g} |")
        L += ["", "Model: P = C V^2 f x duty (clock net charged and discharged once per enabled cycle). Leakage, data-path switching,",
              "ICG overhead and SRAM macros are not included.", ""]
    else:
        L += ["not computed (no --params given).", ""]
    L += ["## 3. Library-based estimate", ""]
    if lib:
        L += ["| engine | clock tree at 100 % enable (mW) | scaled by simulated duty (mW) | leakage (unchanged) |", "|---|---|---|---|"]
        for r in rows:
            if "library_clock_mW" in r:
                L.append(f"| {r['engine']} | {r['library_clock_mW_full']:.4g} | {r['library_clock_mW']:.4g} | {f(r['library_leakage_mW_unchanged'])} |")
        L.append("")
    else:
        L += ["not computed (no --lib given). No library or PDK data exists in this repository for the SilicaFlux ASIC.", ""]
    L += ["## 4. Measured hardware power", ""]
    L += [json.dumps(meas, indent=1) if meas else "not available: no silicon or board measurement exists."]
    L += ["", "## Notes", ""] + [f"* {n}" for n in notes] + ["* Savings are not stated: no comparison baseline with the same method was supplied."]
    return "\n".join(L) + "\n"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--activity", required=True)
    ap.add_argument("--params"); ap.add_argument("--lib"); ap.add_argument("--measured")
    ap.add_argument("--out")
    a = ap.parse_args()
    act, params, lib, meas = load(a.activity), load(a.params), load(a.lib), load(a.measured)
    rows, notes = build(act, params, lib, meas)
    txt = render(act, rows, notes, params, lib, meas)
    if a.out:
        open(a.out, "w").write(txt)
    print(txt)

if __name__ == "__main__":
    main()
