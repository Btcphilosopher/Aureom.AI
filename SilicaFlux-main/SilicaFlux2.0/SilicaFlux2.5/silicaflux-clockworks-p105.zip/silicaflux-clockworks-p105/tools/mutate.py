#!/usr/bin/env python3
"""CLOCKWORKS mutation check.

Each mutant is a deliberate single (or, where stated, double) defect injected into a COPY of
the RTL.  The system regression is rebuilt and run on the copy; the mutant is KILLED when the
bench reports a failure (TB_RESULT FAIL, a checker report, a timeout or a crash) and SURVIVES
when the regression still passes.  Stages: system regression; Icarus unit benches; a second system configuration; formal properties
(reset-sequencer mutants).  Survivors are listed honestly in reports/mutation.md.

usage: tools/mutate.py [--jobs N] [--only ID ...] [--out reports/mutation.md]
"""
import argparse, concurrent.futures as cf, pathlib, re, shutil, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent.parent
R = "rtl/clockworks/"

# id, description, [(file, old, new)]
MUTANTS = [
 ("M01", "FSM leaves DRAINING without the quiescence vector", [(R+"sf_power_state_fsm.sv",
    "D_QUIESCE: begin\n                if (quiet_i) begin", "D_QUIESCE: begin\n                if (1'b1) begin")]),
 ("M02", "new-work gate not closed on entry to DRAINING", [(R+"sf_power_state_fsm.sv",
    "state_d   = ST_DRAINING;\n            accept_d  = 1'b0;", "state_d   = ST_DRAINING;\n            accept_d  = accept_q;")]),
 ("M03", "wake does not wait for DataFabric reconnection", [(R+"sf_power_state_fsm.sv",
    "if (fabric_ack_i) begin", "if (1'b1) begin")]),
 ("M04", "wake does not wait for providers", [(R+"sf_power_state_fsm.sv",
    "if (prov_ready_i && clk_ok_i) begin", "if (clk_ok_i) begin")]),
 ("M05", "ledger ignores retire events", [(R+"sf_clock_enable_ctrl.sv",
    "$signed({{(32-EVW){1'b0}}, iss}) -\n                    $signed({{(32-EVW){1'b0}}, ret});", "$signed({{(32-EVW){1'b0}}, iss});")]),
 ("M06", "reset hold time collapses to zero edges", [(R+"sf_reset_sequencer.sv",
    "assign hold_lim   = (cfg_hold_i < 8'd2) ? 8'd2 : cfg_hold_i;", "assign hold_lim   = 8'd0;")]),
 ("M07", "reset release ignores provider rank", [(R+"sf_reset_sequencer.sv",
    "if (LOWER[e*CW_MAXE + k] && ((rs_q[k] != R_RUN) || fail_q[k])) blocked[e] = 1'b1;",
    "if (1'b0 && LOWER[e*CW_MAXE + k] && ((rs_q[k] != R_RUN) || fail_q[k])) blocked[e] = 1'b1;")]),
 ("M08", "no closure: dependents not reset with their provider", [(R+"sf_reset_sequencer.sv",
    "if (p != e && own_req[p] && CLOS[p*CW_MAXE + e] && !iso_i[e])", "if (1'b0 && p != e && own_req[p] && CLOS[p*CW_MAXE + e] && !iso_i[e])")]),
 ("M09", "ledger not cleared while the engine is in reset", [(R+"sf_clock_enable_ctrl.sv",
    "if (!LEDGER_EN[e] || rst_clk_force_i[e]) begin", "if (!LEDGER_EN[e]) begin")]),
 ("M10", "drain timeout disables the clock instead of faulting", [(R+"sf_power_state_fsm.sv",
    "end else begin\n                    go_fault = 1'b1; go_fault_cause = (8'h01 << FC_DRAIN_TMO);\n                  end",
    "end else begin\n                    state_d = ST_CLK_DIS; clk_run_d = 1'b0; fabric_d = 1'b0; dstep_d = D_NONE;\n                  end")]),
 ("M11", "illegal transition FAULT -> ACTIVE on a wake request", [(R+"sf_power_state_fsm.sv",
    "else if (req_valid_i) begin rej_d = 1'b1; rej_code_d = REJ_STATE; end\n\n          if (cfg_fault_rst_en_i",
    "else if (req_wake) begin ack_d = 1'b1; state_d = ST_ACTIVE; accept_d = 1'b1; end\n          else if (req_valid_i) begin rej_d = 1'b1; rej_code_d = REJ_STATE; end\n\n          if (cfg_fault_rst_en_i")]),
 ("M12", "quiescence ignores the transaction ledger", [(R+"sf_clock_enable_ctrl.sv",
    "assign q[Q_OUTSTANDING] = (out_q == '0);", "assign q[Q_OUTSTANDING] = 1'b1;")]),
 ("M13", "MBIST starts without waiting for quiescence", [(R+"sf_clock_test_adapter.sv",
    "else if (all_quiet)         begin mb_d = MB_S_START;", "else if (1'b1)             begin mb_d = MB_S_START;")]),
 ("M14", "scan mode does not force the clocks on", [(R+"sf_clock_test_adapter.sv",
    "assign cg_test_en_o  = cgte_q | scan_q;", "assign cg_test_en_o  = cgte_q;"),
    (R+"sf_clock_test_adapter.sv", "| diag_hold | {NE{scan_q}};", "| diag_hold;")]),
 ("M15", "hysteresis counter restarts in IDLE_REQUESTED (the bug found during bring-up)", [(R+"sf_power_state_fsm.sv",
    "act_d      = (state_q == ST_ACTIVE || state_q == ST_IDLE_REQ) ?", "act_d      = (state_q == ST_ACTIVE) ?")]),
 ("M16", "provider may stop while its dependents are active", [(R+"sf_clock_power_ctrl.sv",
    "deps_iso[p]   = deps_iso[p] & f_iso[e];", "deps_iso[p]   = deps_iso[p];")]),
 ("M17", "a waking dependent does not wake its providers", [(R+"sf_clock_power_ctrl.sv",
    "casc[p]       = casc[p] | want_wake[e];", "casc[p]       = casc[p];")]),
 ("M18", "progress watchdog never fires", [(R+"sf_cw_wdt.sv",
    "assign hit = cfg_en_i[e] && (lim != 24'd0) && (cnt_q >= lim) && !fired_q;", "assign hit = 1'b0;")]),
 ("M19", "FSM gate reopens before local readiness", [(R+"sf_power_state_fsm.sv",
    "if (eng_ready_i) begin wstep_d = W_FABRIC; fabric_d = 1'b1; end", "begin wstep_d = W_FABRIC; fabric_d = 1'b1; end")]),
 ("M20", "register file ignores CTRL.EN", [(R+"sf_cw_regs.sv",
    "if (ctrl_en_q) begin\n              req_v_q[e_ix]", "if (1'b1) begin\n              req_v_q[e_ix]")]),
 ("M21", "DISABLED counter does not count", [(R+"sf_activity_counters.sv",
    "end else        m_q[M_DISABLED] <= sadd(m_q[M_DISABLED], 32'd1);", "end else        m_q[M_DISABLED] <= m_q[M_DISABLED];")]),
 ("M22", "reset hold counts cycles without a delivered clock", [(R+"sf_reset_sequencer.sv",
    "if (!rst_n_fb[e] && clk_en_fb_i[e]) begin", "if (!rst_n_fb[e]) begin")]),
 ("M23", "double fault: FSM skips quiescence AND the enable interlock is removed", [(R+"sf_power_state_fsm.sv",
    "D_QUIESCE: begin\n                if (quiet_i) begin", "D_QUIESCE: begin\n                if (1'b1) begin"),
    (R+"sf_clock_enable_ctrl.sv", "| test_en_i | ilk_busy;", "| test_en_i;")]),
 ("M24", "interlock alone removed (backstop: redundant with a correct FSM at system level)", [(R+"sf_clock_enable_ctrl.sv",
    "| test_en_i | ilk_busy;", "| test_en_i;")]),
 ("M25", "quiescence stability window ignored", [(R+"sf_clock_enable_ctrl.sv",
    "assign quiet_o[e] = (qcnt_q >= qlim);", "assign quiet_o[e] = quiet_raw;")]),
 ("M26", "wake events do not wake a disabled engine", [(R+"sf_clock_enable_ctrl.sv",
    "assign wake_ev_o[e] = cfg_wake_en_i[e] & (eng_wake_req_i[e] | up_stalled_i[e]);", "assign wake_ev_o[e] = 1'b0;")]),
 ("M27", "SRAM retention rule not enforced", [(R+"sf_power_state_fsm.sv",
    "localparam bit SRAM_OK = !HAS_SRAM || SRAM_QUAL || SAVE_EN;", "localparam bit SRAM_OK = 1'b1;")]),
 ("M28", "system watchdog stage 2 does not reset", [(R+"sf_cw_wdt.sv",
    "sys_rst_o <= sys_rst_en_i;", "sys_rst_o <= 1'b0;")]),
 ("M29", "unsupported request codes accepted as no-ops", [(R+"sf_power_state_fsm.sv",
    "assign req_unsup = req_valid_i && !(req_wake || req_idle || req_reset);", "assign req_unsup = 1'b0;")]),
 ("M31", "idle detector never requests an automatic idle", [(R+"sf_power_state_fsm.sv",
    "end else if (auto_idle_i && GATE_OK && min_ok) begin", "end else if (1'b0 && auto_idle_i && GATE_OK && min_ok) begin")]),
 ("M32", "ICG ignores the test enable", [(R+"sf_cw_clock_gate.sv",
    "if (!clk_i) en_l = en_i | te_i;", "if (!clk_i) en_l = en_i;")]),
 ("M33", "clock gated with a plain AND instead of a latch-based ICG", [(R+"sf_cw_clock_gate.sv",
    "assign gclk_o = clk_i & en_l;", "assign gclk_o = clk_i & (en_i | te_i);")]),
 ("M30", "explicit save not waited for (SAVE_EN builds)", [(R+"sf_power_state_fsm.sv",
    "if (save_done_i && quiet_i) begin", "if (quiet_i) begin")]),
]

ALSO_CFG = {"M27": ["-GDEFPOL=1"], "M30": ["-GSAVE_ALL=1", "-GVOLATILE=1"]}
UNIT_BENCHES = [
    ("unit_enable_ctrl", ["rtl/clockworks/sf_cw_pkg.sv", "rtl/clockworks/sf_clock_enable_ctrl.sv", "tests/clockworks/tb_cw_unit_ec.sv"]),
    ("unit_power_state_fsm", ["rtl/clockworks/sf_cw_pkg.sv", "rtl/clockworks/sf_power_state_fsm.sv", "tests/clockworks/tb_cw_unit_fsm.sv"]),
    ("unit_icg", ["rtl/clockworks/sf_cw_clock_gate.sv", "tests/clockworks/tb_cw_icg.sv"]),
]

def run_unit(mut):
    """Stage 2: the Icarus unit benches (random stimulus against reference models)."""
    mid, desc, edits = mut
    work = ROOT / "build" / f"mutu_{mid}"
    if work.exists():
        shutil.rmtree(work)
    src = work / "src"
    for d in ("rtl", "third_party", "tests"):
        shutil.copytree(ROOT / d, src / d)
    for rel, old, new in edits:
        f = src / rel
        f.write_text(f.read_text().replace(old, new))
    for name, files in UNIT_BENCHES:
        used = [f for f in files if any(f.endswith(rel.split("/")[-1]) for rel, _, _ in edits)]
        if not used:
            continue
        exe = work / f"{name}.vvp"
        b = subprocess.run(["iverilog", "-g2012", "-o", str(exe)] + files, cwd=src, capture_output=True, text=True)
        if not exe.exists():
            continue
        try:
            r = subprocess.run(["vvp", str(exe)], cwd=src, capture_output=True, text=True, timeout=900)
        except subprocess.TimeoutExpired:
            shutil.rmtree(work, ignore_errors=True)
            return name, "timeout"
        m = re.search(r"TB_RESULT (PASS|FAIL) checks=(\d+) errors=(\d+)", r.stdout)
        if m is None or m.group(1) == "FAIL":
            first = next((l for l in r.stdout.splitlines() if l.startswith("FAIL")), "unit bench failed")
            shutil.rmtree(work, ignore_errors=True)
            return name, first[:90]
    shutil.rmtree(work, ignore_errors=True)
    return None

def run_formal_stage(mut):
    """Stage 4: a mutant of the reset sequencer that simulation cannot observe may still violate a formal
    property (the formal wrapper has a FREE clock-return feedback, which the system wiring does not)."""
    mid, desc, edits = mut
    if not any(rel.endswith("sf_reset_sequencer.sv") for rel, _, _ in edits):
        return None
    sys.path.insert(0, str(ROOT / "formal/clockworks"))
    import run_formal
    st, det, _ = run_formal.job_rs(f"mut_rs_{mid}", 1 if mid == "M07" else 0, 24, 600, mut)
    return (f"formal reset-sequencer properties: {st} ({det})") if st == "FAILED" else None

def run(mut, extra_cfg):
    mid, desc, edits = mut
    work = ROOT / "build" / f"mut_{mid}"
    if work.exists():
        shutil.rmtree(work)
    src = work / "src"
    for d in ("rtl", "third_party", "tests"):
        shutil.copytree(ROOT / d, src / d)
    for rel, old, new in edits:
        f = src / rel
        t = f.read_text()
        if t.count(old) != 1:
            return mid, desc, "ERROR", f"pattern not unique ({t.count(old)}) in {rel}"
        f.write_text(t.replace(old, new))
    flist = [l.strip() for l in (ROOT / "rtl/clockworks/files.f").read_text().splitlines() if l.strip() and not l.startswith("//")]
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-MULTIDRIVEN",
           "-Wno-UNOPTFLAT", "-Wno-PINMISSING", "-Wno-IMPLICIT", "-Wno-CASEINCOMPLETE", "--top-module", "tb_cw_system",
           "-Mdir", str(work / "obj"), "--public-flat-rw", "rtl/clockworks/lint.vlt"] + flist + \
          ["rtl/clockworks/sf_cw_checker.sv", "third_party/silicaflux_powerclock/sf_cmd_gate.sv",
           "tests/clockworks/cw_models.sv", "tests/clockworks/tb_cw_system.sv"] + extra_cfg
    b = subprocess.run(cmd, cwd=src, capture_output=True, text=True)
    exe = work / "obj" / "Vtb_cw_system"
    if not exe.exists():
        return mid, desc, "ERROR", "build failed: " + b.stderr[-300:]
    try:
        r = subprocess.run([str(exe)], cwd=src, capture_output=True, text=True, timeout=900)
        out = r.stdout + r.stderr
        rc = r.returncode
    except subprocess.TimeoutExpired:
        return mid, desc, "KILLED", "timeout (hang)"
    m = re.search(r"TB_RESULT (PASS|FAIL) checks=(\d+) errors=(\d+)", out)
    first = next((l for l in out.splitlines() if l.startswith("FAIL") or l.startswith("CW_CHECK_FAIL") or "CONSERVE FAIL" in l), "")
    shutil.rmtree(work, ignore_errors=True)
    if m is None or m.group(1) == "FAIL" or rc != 0:
        return mid, desc, "KILLED", first[:110] or "no result line / nonzero exit"
    surv = f"system regression still passes ({m.group(2)} checks)"
    u = run_unit(mut)
    if u:
        return mid, desc, "KILLED", f"by {u[0]}: {u[1]}"
    for cfg in ([ALSO_CFG[mid]] if mid in ALSO_CFG else []):
        r2 = run((mid + "x", desc, edits), cfg + [a for a in extra_cfg if a not in cfg])
        if r2[2] == "KILLED":
            return mid, desc, "KILLED", f"by system regression with {' '.join(cfg)}: {r2[3]}"
    fk = run_formal_stage(mut)
    if fk:
        return mid, desc, "KILLED", "by " + fk
    return mid, desc, "SURVIVED", surv

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--cfg", default="", help="extra verilator args, e.g. -GSAVE_ALL=1")
    ap.add_argument("--out", default="reports/mutation.md")
    ap.add_argument("--title", default="default configuration (QUAL=1 SAVE=0)")
    a = ap.parse_args()
    muts = [m for m in MUTANTS if not a.only or m[0] in a.only]
    extra = a.cfg.split() if a.cfg else []
    t0 = time.time()
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        futs = [ex.submit(run, m, extra) for m in muts]
        for f in cf.as_completed(futs):
            r = f.result(); res.append(r); print(f"{r[0]} {r[2]:8s} {r[3]}", flush=True)
    res.sort()
    killed = sum(1 for r in res if r[2] == "KILLED")
    surv = [r for r in res if r[2] == "SURVIVED"]
    err = [r for r in res if r[2] == "ERROR"]
    lines = ["# Mutation check", "",
             f"Configuration: {a.title}. {len(res)} mutants, **{killed} killed**, {len(surv)} survived, {len(err)} errors "
             f"({time.time()-t0:.0f} s, {a.jobs} parallel jobs).", "",
             "| id | mutant | result | evidence |", "|---|---|---|---|"]
    for mid, desc, st, ev in res:
        lines.append(f"| {mid} | {desc} | {st} | {ev.replace('|', '/')} |")
    out = ROOT / a.out
    out.parent.mkdir(exist_ok=True)
    out.write_text("\n".join(lines) + "\n")
    print(f"killed {killed}/{len(res)}; survivors {[s[0] for s in surv]}; errors {[e[0] for e in err]}")
    sys.exit(0)

if __name__ == "__main__":
    main()
