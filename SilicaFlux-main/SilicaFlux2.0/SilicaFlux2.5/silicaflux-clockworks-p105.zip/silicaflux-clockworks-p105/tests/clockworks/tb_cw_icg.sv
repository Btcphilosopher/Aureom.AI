// =============================================================================
// ICG bench (Icarus Verilog: event-driven, models real gating).
//   1. sf_cw_clock_gate (behavioural library-ICG equivalent):
//        - every gated edge coincides with a source edge, no runt / truncated pulse
//        - a flop on the gated clock == a flop with a synchronous enable, cycle for cycle
//        - the test enable forces the clock on
//   2. NEGATIVE CONTROL: clk & en (a plain AND gate) glitches when the enable
//      changes while the clock is high -- the checker must flag it.
// The enable is launched by a flop on clk, exactly as sf_clock_enable_ctrl does.
// =============================================================================
`timescale 1ns/1ps
module tb_cw_icg;
  logic clk = 0; always #5 clk = ~clk;
  logic en = 1, te = 0;
  logic gclk, bad;
  sf_cw_clock_gate dut (.clk_i(clk), .en_i(en), .te_i(te), .gclk_o(gclk));
  assign bad = clk & en;                           // the construct the wrapper replaces

  // enable launched by a flop (NBA) like the real controller
  always @(posedge clk) begin
    en <= ($urandom % 100) < 55;
    if (($urandom % 100) < 3) te <= ~te;
  end

  // ---------------- edge integrity ----------------
  integer errs = 0, checks = 0, bad_glitches = 0;
  time t_clk_rise, t_g_rise, t_g_fall, t_b_rise, t_b_fall;
  always @(posedge clk) t_clk_rise = $time;
  always @(posedge gclk) begin
    t_g_rise = $time;
    checks++; if (t_g_rise != t_clk_rise) begin errs++; $display("FAIL gated rise not on a source edge"); end
  end
  always @(negedge gclk) begin
    t_g_fall = $time;
    checks++; if (t_g_fall - t_g_rise != 5) begin errs++; $display("FAIL runt / truncated gated pulse: %0t", t_g_fall - t_g_rise); end
  end
  // the AND-gated clock: count pulses that are not a full clk-high width
  always @(posedge bad) t_b_rise = $time;
  always @(negedge bad) begin t_b_fall = $time; if (t_b_fall - t_b_rise != 5) bad_glitches++; end

  // ---------------- cycle equivalence ----------------
  integer cntA = 0, cntB = 0;
  logic [15:0] sA = 16'h1, sB = 16'h1;
  always @(posedge gclk) begin cntA <= cntA + 1; sA <= {sA[14:0], sA[15] ^ sA[13] ^ sA[12] ^ sA[10]}; end
  always @(posedge clk)  if (en | te) begin cntB <= cntB + 1; sB <= {sB[14:0], sB[15] ^ sB[13] ^ sB[12] ^ sB[10]}; end
  integer mism = 0;
  always @(negedge clk) begin checks++; if (cntA !== cntB || sA !== sB) begin mism++; errs++; if (mism < 4) $display("FAIL gated flop != enable flop"); end end

  // test enable forces the clock on
  integer te_cycles = 0, te_edges = 0;
  always @(posedge clk) if (te && !en) te_cycles++;
  always @(posedge gclk) if (te) te_edges++;

  initial begin
    #200000;                                       // 20k cycles
    checks++; if (te_edges < te_cycles) begin errs++; $display("FAIL test enable did not force the clock on"); end
    checks++; if (bad_glitches == 0) begin errs++; $display("FAIL negative control: plain AND gate showed no glitch (bench cannot see them)"); end
    if (errs == 0) $display("TB_RESULT PASS checks=%0d errors=0 unit=icg gated_edges=%0d te_forced=%0d AND_gate_glitches=%0d", checks, cntA, te_edges, bad_glitches);
    else           $display("TB_RESULT FAIL checks=%0d errors=%0d unit=icg", checks, errs);
    $finish;
  end
endmodule
