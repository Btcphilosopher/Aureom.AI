// =============================================================================
// CLOCKWORKS verification models (SIMULATION ONLY, not synthesizable).
//
// They are BENCH models of the engines' quiescence contract, NOT the real
// ControlCore / MemoryMatrix / Meridian / StreamDMA / TensorCore / PacketCore
// RTL.  What they show is that the controller's sequencing is safe for any
// engine that honours the contract in docs/clockworks/03_QUIESCENCE.md.  They
// do not show that the real engines honour it (docs/clockworks/09_LIMITATIONS.md).
//
// Every state-holding flop is written `if (ce)`: the synchronous-clock-enable
// methodology.  With ce = 0 the model is frozen, exactly as a stopped clock
// freezes it, so work still inside a model when the enable is removed stays
// stuck and the bench flags it.
//
// Integration rule modelled here: event pulses (issue / retire / accept / done)
// are qualified with ce.  A registered pulse on a stopped clock would stay
// high; the quiet condition guarantees it is already low when the clock stops,
// and the qualification makes the model robust when it is not.
// =============================================================================
`timescale 1ns/1ps

package cw_tb_pkg;
  function automatic [31:0] cw_xs(input [31:0] x);
  reg [31:0] y;
  begin y = x; y = y ^ (y << 13); y = y ^ (y >> 17); y = y ^ (y << 5); cw_xs = y; end
endfunction
  function automatic [31:0] cw_hash(input [31:0] d);
  begin cw_hash = (d * 32'h9E3779B1) ^ (d >> 7) ^ 32'hA5A5_0000; end
endfunction
  function automatic [31:0] cw_arch_next(input [31:0] a, input [31:0] d);
  begin cw_arch_next = a * 32'd1664525 + d + 32'd1013904223; end
endfunction

endpackage

// ---------------------------------------------------------------------------
// DataFabric connect handshake: ack follows connect after a random latency
// ---------------------------------------------------------------------------
module cw_fab_ack #(parameter int LAT = 2, parameter [31:0] SEED = 32'h1) (
  input  logic clk, input logic rst_n, input logic conn, output logic ack
);
  import cw_tb_pkg::*;
  reg [7:0]  cnt;
  reg [31:0] r;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ack <= 1'b0; cnt <= 8'd0; r <= SEED | 32'h1; end
    else begin
      r <= cw_xs(r);
      if (!conn) begin ack <= 1'b0; cnt <= 8'd0; end
      else if (!ack) begin
        if (cnt >= LAT + {7'd0, r[0]}) ack <= 1'b1; else cnt <= cnt + 8'd1;
      end
    end
  end
endmodule

// ---------------------------------------------------------------------------
// Master engine: ControlCore / StreamDMA / TensorCore / PacketForge stand-in
// ---------------------------------------------------------------------------
module cw_master_model #(
  parameter int ID = 0,
  parameter int MAXO = 2,
  parameter int JOB_LEN = 4,
  parameter int LAT_MIN = 2,
  parameter int LAT_MAX = 8,
  parameter int OBUF_DEPTH = 2,
  parameter int OBUF_RATE = 4,
  parameter int INIT_CYC = 6,
  parameter bit HAS_CANCEL = 1'b0,
  parameter bit VOLATILE = 1'b0,
  parameter int SAVE_LAT = 3,
  parameter bit BG = 1'b0,
  parameter int BG_PERIOD = 37,
  parameter [31:0] SEED = 32'h1
) (
  input  logic clk,
  input  logic rst_n,
  input  logic ce,
  input  logic quiesce,
  input  logic cancel,
  input  logic save_req,
  input  logic restore_req,
  input  logic fabric_conn,
  input  logic prov_ce,
  // work input (after the gate)
  input  logic in_valid,
  output logic in_ready,
  input  logic [31:0] in_data,
  // status to the controller
  output logic ready,
  output logic idle,
  output logic obuf_empty,
  output logic dma_idle,
  output logic mem_idle,
  output logic save_done,
  output logic restore_done,
  output logic [2:0] issue_cnt,
  output logic [2:0] retire_cnt,
  output logic wake_req,
  output logic err_o,
  // bench controls
  input  logic err_inject,
  input  logic hang,
  input  logic pwr_loss,
  input  logic wake_inject,
  // observability (all comb pulses qualified with ce)
  output logic ev_acc,
  output logic ev_done,
  output logic [2:0] ev_cancel_n,
  output logic [31:0] done_data,
  output logic wr_valid,
  output logic [7:0] wr_addr,
  output logic [31:0] wr_data,
  output logic [31:0] arch,
  output logic [31:0] pending,
  output logic [31:0] inflight,
  output logic viol_prov
);
  import cw_tb_pkg::*;
  localparam [31:0] ARCH0 = 32'h1ACE_0000 + ID;

  reg [31:0] jq [0:3];
  reg [2:0]  jq_n;
  reg [1:0]  jq_h;
  reg        cur_v;
  reg [31:0] cur_d;
  reg [7:0]  left, fin;
  reg        slot_v [0:3];
  reg [7:0]  slot_r [0:3];
  reg [31:0] rng;
  reg [3:0]  obuf_n;
  reg [7:0]  obuf_t, init_c;
  reg        cpl_pend;
  reg [1:0]  cpl_t;
  reg [7:0]  bg_c;
  reg [2:0]  bg_busy;
  reg        wk_q, err_q, viol_p;
  reg [7:0]  sv_c, rs_c;
  reg [31:0] shadow, ae;
  reg        shadow_v;
  reg [2:0]  iss_q, ret_q;
  reg        wr_q;
  reg [7:0]  wra_q;
  reg [31:0] wrd_q;

  integer i;
  reg [7:0] nin;
  always @* begin
    nin = 0;
    for (i = 0; i < 4; i = i + 1) if (slot_v[i]) nin = nin + 1;
  end

  wire will_done = cur_v && (fin == JOB_LEN) && (obuf_n < OBUF_DEPTH);
  wire acc       = in_valid && in_ready;

  assign in_ready    = ce && rst_n && (jq_n < 3'd4) && (init_c >= INIT_CYC);
  assign ready       = (init_c >= INIT_CYC);
  assign idle        = (jq_n == 0) && !cur_v && (nin == 0) && (bg_busy == 0);
  assign mem_idle    = (nin == 0);
  assign obuf_empty  = (obuf_n == 0);
  assign dma_idle    = !cpl_pend;
  assign arch        = ae;
  assign wake_req    = wk_q;
  assign err_o       = err_q;
  assign viol_prov   = viol_p;
  assign pending     = {29'd0, jq_n} + (cur_v ? 32'd1 : 32'd0);
  assign inflight    = {24'd0, nin};
  assign ev_acc      = ce && acc;
  assign ev_done     = ce && will_done;
  assign ev_cancel_n = (ce && cancel && HAS_CANCEL) ? jq_n : 3'd0;
  assign done_data   = cur_d;
  assign issue_cnt   = ce ? iss_q : 3'd0;
  assign retire_cnt  = ce ? ret_q : 3'd0;
  assign wr_valid    = ce && wr_q;
  assign wr_addr     = wra_q;
  assign wr_data     = wrd_q;

  // always-on observers (not gated by ce): wake request, error flag, violation flag
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin wk_q <= 1'b0; err_q <= 1'b0; viol_p <= 1'b0; end
    else begin
      if (wake_inject) wk_q <= 1'b1; else if (ce) wk_q <= 1'b0;
      if (err_inject) err_q <= 1'b1;
      if (nin != 0 && !prov_ce) viol_p <= 1'b1;     // work in flight while a provider clock is off
    end
  end

  // architectural state; power loss (bench injected) wipes volatile state whatever the enable
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) ae <= ARCH0;
    else if (VOLATILE && pwr_loss) ae <= 32'd0;
    else if (ce) begin
      if (restore_req && rs_c == SAVE_LAT && shadow_v) ae <= shadow;
      else if (will_done) ae <= cw_arch_next(ae, cur_d);
    end
  end

  reg [2:0]  rn, inn;
  reg [2:0]  jn;
  reg [1:0]  jh;
  reg        emp;
  reg [7:0]  nfree;
  reg        got_slot;
  reg [1:0]  fidx;
  reg [7:0]  lat;
  reg [31:0] r;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      jq_n <= 0; jq_h <= 0; cur_v <= 0; cur_d <= 0; left <= 0; fin <= 0;
      for (i = 0; i < 4; i = i + 1) begin slot_v[i] <= 0; slot_r[i] <= 0; end
      rng <= SEED | 32'h1; obuf_n <= 0; obuf_t <= 1; init_c <= 0; cpl_pend <= 0; cpl_t <= 0;
      bg_c <= 0; bg_busy <= 0; sv_c <= 0; rs_c <= 0; shadow <= 0; shadow_v <= 0;
      iss_q <= 0; ret_q <= 0; wr_q <= 0; wra_q <= 0; wrd_q <= 0; save_done <= 0; restore_done <= 0;
    end else if (ce) begin
      rng <= cw_xs(rng);
      r   = rng;
      iss_q <= 0; wr_q <= 0;

      if (init_c < INIT_CYC) init_c <= init_c + 1;

      // ---- job queue: cancel drops what was queued BEFORE this cycle; then accept; then start ----
      jn = jq_n; jh = jq_h;
      if (cancel && HAS_CANCEL) begin jh = jh + jn[1:0]; jn = 0; end
      emp = (jn == 0);
      if (acc) begin jq[(jh + jn[1:0]) & 2'd3] <= in_data; jn = jn + 1; end
      if (!cur_v && jn != 0) begin
        cur_v <= 1; cur_d <= (emp && acc) ? in_data : jq[jh & 2'd3];
        jh = jh + 1; jn = jn - 1; left <= JOB_LEN; fin <= 0;
      end
      jq_n <= jn; jq_h <= jh;

      // ---- retire sub-transactions (progress needs the provider clock) ----
      rn = 0;
      for (i = 0; i < 4; i = i + 1) begin
        if (slot_v[i] && !hang && prov_ce) begin
          if (slot_r[i] <= 1) begin slot_v[i] <= 0; rn = rn + 1; end
          else slot_r[i] <= slot_r[i] - 1;
        end
      end
      ret_q <= rn;
      if (cur_v) fin <= fin + rn;

      // ---- issue (needs the DataFabric port and the provider clock) ----
      inn = 0;
      if (cur_v && left != 0) begin
        got_slot = 0; fidx = 0;
        for (i = 0; i < 4; i = i + 1)
          if (!slot_v[i] && !got_slot && i < MAXO) begin got_slot = 1; fidx = i[1:0]; end
        if (got_slot && fabric_conn && prov_ce && r[2:0] != 3'd0) begin
          lat = LAT_MIN + (r[10:4] % (LAT_MAX - LAT_MIN + 1));
          slot_v[fidx] <= 1; slot_r[fidx] <= lat;
          left <= left - 1; inn = 1;
        end
      end
      iss_q <= inn;

      // ---- completion ----
      if (will_done) begin
        cur_v <= 0; obuf_n <= obuf_n + 1; cpl_pend <= 1; cpl_t <= 2;
        wr_q <= 1; wra_q <= ID * 8 + {5'd0, cur_d[2:0]}; wrd_q <= cw_hash(cur_d);
      end

      // ---- output buffer drain, completion record ----
      if (obuf_n != 0 && !will_done) begin
        if (obuf_t <= 1) begin obuf_n <= obuf_n - 1; obuf_t <= 1 + (r[15:12] % OBUF_RATE); end
        else obuf_t <= obuf_t - 1;
      end
      if (cpl_pend && !will_done) begin
        if (cpl_t == 0) cpl_pend <= 0; else cpl_t <= cpl_t - 1;
      end

      // ---- background work: stops when told to quiesce ----
      if (BG) begin
        if (bg_busy != 0) bg_busy <= bg_busy - 1;
        else if (!quiesce) begin
          if (bg_c >= BG_PERIOD) begin bg_c <= 0; bg_busy <= 3; end else bg_c <= bg_c + 1;
        end
      end

      // ---- explicit save / restore (needs the clock running) ----
      if (save_req) begin
        if (sv_c < SAVE_LAT) sv_c <= sv_c + 1;
        else begin save_done <= 1; shadow <= ae; shadow_v <= 1; end
      end else begin sv_c <= 0; save_done <= 0; end
      if (restore_req) begin
        if (rs_c < SAVE_LAT) rs_c <= rs_c + 1;
        else restore_done <= 1;
      end else begin rs_c <= 0; restore_done <= 0; end
    end
  end
endmodule

// ---------------------------------------------------------------------------
// Target engines: Meridian (event ledger only, NO idle port) and
// MemoryMatrix (memory + idle).  Four write ports, one per master.
// ---------------------------------------------------------------------------
module cw_target_model #(
  parameter bit HAS_MEM = 1'b0,
  parameter bit IDLE_REPORT = 1'b1,
  parameter int INIT_CYC = 4,
  parameter bit VOLATILE = 1'b0,
  parameter int SAVE_LAT = 3,
  parameter bit BG = 1'b0,
  parameter int BG_PERIOD = 53
) (
  input  logic clk,
  input  logic rst_n,
  input  logic ce,
  input  logic quiesce,
  input  logic save_req,
  input  logic restore_req,
  input  logic pwr_loss,
  input  logic [3:0] issue_cnt,
  input  logic [3:0] retire_cnt,
  input  logic [3:0] wr_valid,
  input  logic [31:0] wr_addr_flat,     // 4 x 8
  input  logic [127:0] wr_data_flat,    // 4 x 32
  output logic ready,
  output logic idle,
  output logic obuf_empty,
  output logic dma_idle,
  output logic mem_idle,
  output logic save_done,
  output logic restore_done,
  output logic [31:0] cnt,
  output logic viol_prov,
  output logic viol_wr
);
  reg [31:0] mem [0:31];
  reg [31:0] shadow [0:31];
  reg        shadow_v;
  reg [31:0] c;
  reg [7:0]  init_c, sv_c, rs_c, bg_c;
  reg [2:0]  bg_busy;
  reg        vp, vw;
  integer i, k;

  assign cnt        = c;
  assign ready      = (init_c >= INIT_CYC);
  assign idle       = IDLE_REPORT ? ((c == 0) && (bg_busy == 0)) : 1'b1;
  assign mem_idle   = IDLE_REPORT ? (c == 0) : 1'b1;
  assign obuf_empty = 1'b1;
  assign dma_idle   = 1'b1;
  assign viol_prov  = vp;
  assign viol_wr    = vw;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c <= 0; init_c <= 0; sv_c <= 0; rs_c <= 0; bg_c <= 0; bg_busy <= 0; vp <= 0; vw <= 0;
      save_done <= 0; restore_done <= 0; shadow_v <= 0;
      for (i = 0; i < 32; i = i + 1) begin mem[i] <= 32'd0; shadow[i] <= 32'd0; end
    end else begin
      // work arriving at, or held inside, an engine whose clock is off is a violation
      if (!ce && (issue_cnt != 0 || retire_cnt != 0 || c != 0)) vp <= 1'b1;
      if (!ce && HAS_MEM && (|wr_valid)) vw <= 1'b1;

      if (VOLATILE && HAS_MEM && pwr_loss) begin
        for (i = 0; i < 32; i = i + 1) mem[i] <= 32'd0;
      end else if (ce) begin
        c <= c + {28'd0, issue_cnt} - {28'd0, retire_cnt};
        if (init_c < INIT_CYC) init_c <= init_c + 1;
        if (HAS_MEM)
          for (k = 0; k < 4; k = k + 1)
            if (wr_valid[k]) mem[wr_addr_flat[k*8 +: 5]] <= wr_data_flat[k*32 +: 32];
        if (BG) begin
          if (bg_busy != 0) bg_busy <= bg_busy - 1;
          else if (!quiesce) begin
            if (bg_c >= BG_PERIOD) begin bg_c <= 0; bg_busy <= 2; end else bg_c <= bg_c + 1;
          end
        end
        if (save_req) begin
          if (sv_c < SAVE_LAT) sv_c <= sv_c + 1;
          else begin
            save_done <= 1; shadow_v <= 1;
            for (i = 0; i < 32; i = i + 1) shadow[i] <= mem[i];
          end
        end else begin sv_c <= 0; save_done <= 0; end
        if (restore_req) begin
          if (rs_c < SAVE_LAT) rs_c <= rs_c + 1;
          else begin
            restore_done <= 1;
            if (shadow_v) for (i = 0; i < 32; i = i + 1) mem[i] <= shadow[i];
          end
        end else begin rs_c <= 0; restore_done <= 0; end
      end
    end
  end
endmodule

// ---------------------------------------------------------------------------
// MemoryTest P78 stand-in: start / busy / done / pass.  Flags a violation if
// started while the memory owners are not quiet, or if a functional write
// reaches the memory during the test.
// ---------------------------------------------------------------------------
module cw_mbist_model #(parameter int RUN_CYC = 40) (
  input  logic clk,
  input  logic rst_n,
  input  logic start_i,
  input  logic abort_i,
  input  logic test_mode_i,
  input  logic permit_i,
  input  logic owners_quiet,
  input  logic func_write,
  input  logic force_fail,
  input  logic force_hang,
  output logic busy_o,
  output logic done_o,
  output logic pass_o,
  output logic fail_o,
  output logic error_o,
  output logic viol_o
);
  reg [7:0] c;
  reg       run;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin run <= 0; c <= 0; busy_o <= 0; done_o <= 0; pass_o <= 0; fail_o <= 0; error_o <= 0; viol_o <= 0; end
    else begin
      if (start_i) begin
        if (!owners_quiet || !test_mode_i || !permit_i) viol_o <= 1'b1;
        run <= 1; c <= 0; busy_o <= 1; done_o <= 0; pass_o <= 0; fail_o <= 0; error_o <= 0;
      end else if (run) begin
        if (func_write) viol_o <= 1'b1;
        if (abort_i) begin run <= 0; busy_o <= 0; done_o <= 1; error_o <= 1; end
        else if (!force_hang) begin
          c <= c + 1;
          if (c >= RUN_CYC) begin run <= 0; busy_o <= 0; done_o <= 1; pass_o <= !force_fail; fail_o <= force_fail; end
        end
      end
    end
  end
endmodule
