// =============================================================================
// CLOCKWORKS system testbench  --  self-checking, Verilator and Icarus Verilog
//
// DUT: sf_clock_power_ctrl (NE = 6) + six BENCH engine models (cw_models.sv).
// Result line:  TB_RESULT PASS|FAIL checks=<n> errors=<n> config=<...>
//
// Build-time configuration (parameters):
//   QUAL_ALL   1  SRAM_QUAL = all ones  (ASSUMED qualification for simulation)
//   SAVE_ALL   1  SAVE_EN   = all ones  (explicit save / restore)
//   VOLATILE   1  engine models lose their state on a bench-injected power loss
//   DEFPOL     1  conservative default policy (SRAM_QUAL = 0)
//   SEED          random seed of the stress test
// Run-time:  +TEST=<name>  runs a single scenario (default: all that fit the config)
// =============================================================================
`timescale 1ns/1ps

module tb_cw_system;
  import sf_cw_pkg::*;
  import sf_cw_regs_pkg::*;
  import cw_tb_pkg::*;

  parameter int NE       = 6;
  parameter bit QUAL_ALL = 1'b1;
  parameter bit SAVE_ALL = 1'b0;
  parameter bit VOLATILE = 1'b0;
  parameter bit DEFPOL   = 1'b0;
  parameter bit USE_ICG  = 1'b0;   // 1: drive real ICGs (behavioural latch model) and check gated edges == enabled edges (Icarus)
  parameter int SEED     = 1;
  parameter int STRESS_CYC = 30000;
  localparam int EVW = 4;
  localparam int OW  = 10;

  localparam int CC = 0, MM = 1, MR = 2, DMA = 3, TC = 4, PF = 5;

  // ---------------------------------------------------------------------------
  // clock, pins
  // ---------------------------------------------------------------------------
  logic clk = 1'b0;
  always #5 clk = ~clk;

  logic por_n = 1'b0, ext_n = 1'b1, pll = 1'b1, clk_ok = 1'b1;
  logic test_permit = 1'b0, scan_mode = 1'b0, scan_en = 1'b0, icg_te = 1'b0, test_rst_n = 1'b1;
  logic mem_inhibit = 1'b0;
  logic [2:0] tc_mode = 3'd0;
  logic [1:0] dft_q_req = 2'b00, dft_f_blk = 2'b00, dft_clk_req = 2'b00;

  // register bus
  logic        reg_valid = 1'b0, reg_we = 1'b0;
  logic [11:0] reg_addr = 12'd0;
  logic [31:0] reg_wdata = 32'd0;
  wire         reg_ready, reg_err, irq;
  wire  [31:0] reg_rdata;

  // ---------------------------------------------------------------------------
  // engine wiring
  // ---------------------------------------------------------------------------
  wire [NE-1:0] clk_en, accept_en, quiesce_req, cancel, save_req, restore_req, fabric_conn, eng_rst_n, mem_inh;
  wire [NE-1:0] gclk;
  wire [NE*3-1:0] eng_state;
  wire [NE-1:0] e_ready, e_idle, e_obuf, e_dma, e_mem, e_err, e_wake, e_sdone, e_rdone, e_stalled, e_offered, e_fab;
  wire [NE*EVW-1:0] issue_flat, retire_flat;

  logic [NE-1:0] hang = '0, err_inj = '0, pwr_loss = '0, wake_inj = '0;

  // per-master observability
  wire [3:0]  m_iss [NE];
  wire [3:0]  m_ret [NE];
  wire        m_acc [NE];
  wire        m_done [NE];
  wire [2:0]  m_canc [NE];
  wire [31:0] m_ddata [NE];
  wire        m_wrv [NE];
  wire [7:0]  m_wra [NE];
  wire [31:0] m_wrd [NE];
  wire [31:0] m_arch [NE];
  wire [31:0] m_pend [NE];
  wire [31:0] m_infl [NE];
  wire        m_vprov [NE];
  wire [31:0] t_cnt [NE];
  wire        t_vprov [NE];
  wire        t_vwr [NE];
  wire        m_inready [NE];

  // job generator / gate
  logic [NE-1:0] job_valid = '0, send_en = '0;
  logic [31:0]   job_data [NE];
  integer        jobs_left [NE];
  integer        gap_max [NE];
  integer        gap_c [NE];
  logic [23:0]   seqn [NE];
  wire  [NE-1:0] job_ready, dn_valid;

  // event aggregation to the targets
  logic [3:0] agg_iss, agg_ret;
  logic [3:0] wrv_t;
  logic [31:0] wra_t;
  logic [127:0] wrd_t;
  integer zomb [NE];
  logic [NE-1:0] zr;

  // test-adapter side
  wire mb_start, mb_abort, mb_test_mode, mb_permit, mb_cpu_halt;
  wire mb_busy_m, mb_done_m, mb_pass_m, mb_fail_m, mb_err_m, mb_viol;
  logic mb_force_fail = 1'b0, mb_force_hang = 1'b0;
  wire [1:0] dft_q_ack, dft_f_busy, dft_f_req;
  wire cg_te, scan_en_o;
  wire [31:0] jtag_status;
  logic diag_valid = 1'b0, diag_we = 1'b0;
  logic [31:0] diag_addr = 32'd0;
  logic [63:0] diag_wdata = 64'd0;
  wire diag_ready, diag_rvalid, diag_rerr;
  wire [63:0] diag_rdata;
  wire md_valid, md_we;
  wire [31:0] md_addr;
  wire [63:0] md_wdata;

  // ---------------------------------------------------------------------------
  // DUT
  // ---------------------------------------------------------------------------
  localparam logic [NE-1:0] QUAL_V = QUAL_ALL ? {NE{1'b1}} : {NE{1'b0}};
  localparam logic [NE-1:0] SAVE_V = SAVE_ALL ? {NE{1'b1}} : {NE{1'b0}};

  sf_clock_power_ctrl #(
    .NE(NE), .NG(2), .OW(OW), .EVW(EVW), .USE_ICG(USE_ICG),
    .SRAM_QUAL(DEFPOL ? {NE{1'b0}} : QUAL_V), .SAVE_EN(SAVE_V)
  ) dut (
    .clk_i(clk), .por_ni(por_n), .ext_rst_ni(ext_n), .pll_lock_i(pll), .clk_ok_i(clk_ok),
    .reg_valid_i(reg_valid), .reg_we_i(reg_we), .reg_addr_i(reg_addr), .reg_wdata_i(reg_wdata),
    .reg_ready_o(reg_ready), .reg_rdata_o(reg_rdata), .reg_err_o(reg_err), .irq_o(irq),
    .eng_ready_i(e_ready), .eng_idle_i(e_idle), .eng_obuf_empty_i(e_obuf), .eng_dma_idle_i(e_dma),
    .eng_mem_idle_i(e_mem), .eng_err_i(e_err), .eng_wake_req_i(e_wake), .eng_save_done_i(e_sdone),
    .eng_restore_done_i(e_rdone), .up_stalled_i(e_stalled), .in_offered_i(e_offered), .fabric_ack_i(e_fab),
    .issue_cnt_i(issue_flat), .retire_cnt_i(retire_flat),
    .clk_en_o(clk_en), .gclk_o(gclk), .accept_en_o(accept_en), .quiesce_req_o(quiesce_req), .cancel_o(cancel),
    .save_req_o(save_req), .restore_req_o(restore_req), .fabric_connect_o(fabric_conn), .eng_rst_no(eng_rst_n),
    .mem_inhibit_o(mem_inh), .eng_state_o(eng_state),
    .test_permit_i(test_permit), .scan_mode_i(scan_mode), .scan_en_i(scan_en), .icg_te_i(icg_te),
    .test_rst_ni(test_rst_n), .mem_inhibit_i(mem_inhibit), .tc_mode_i(tc_mode),
    .dft_quiesce_req_i(dft_q_req), .dft_f_block_i(dft_f_blk), .dft_mbist_clk_req_i(dft_clk_req),
    .dft_quiesce_ack_o(dft_q_ack), .dft_f_busy_o(dft_f_busy), .dft_f_req_o(dft_f_req),
    .cg_test_en_o(cg_te), .scan_en_o(scan_en_o),
    .mbist_start_o(mb_start), .mbist_abort_o(mb_abort), .mbist_test_mode_o(mb_test_mode),
    .mbist_permit_o(mb_permit), .mbist_cpu_halted_o(mb_cpu_halt),
    .mbist_busy_i(mb_busy_m), .mbist_done_i(mb_done_m), .mbist_pass_i(mb_pass_m), .mbist_fail_i(mb_fail_m),
    .mbist_err_i(mb_err_m),
    .diag_req_valid_i(diag_valid), .diag_req_we_i(diag_we), .diag_req_addr_i(diag_addr), .diag_req_wdata_i(diag_wdata),
    .diag_req_ready_o(diag_ready), .diag_rsp_valid_o(diag_rvalid), .diag_rsp_rdata_o(diag_rdata),
    .diag_rsp_err_o(diag_rerr),
    .mem_diag_valid_o(md_valid), .mem_diag_we_o(md_we), .mem_diag_addr_o(md_addr), .mem_diag_wdata_o(md_wdata),
    .mem_diag_ready_i(1'b1), .mem_diag_rvalid_i(md_rvalid_q), .mem_diag_rdata_i(md_rdata_q), .mem_diag_rerr_i(1'b0),
    .jtag_status_o(jtag_status)
  );

  // memory-diagnostic stand-in: a 1-cycle read-back
  logic md_rvalid_q;
  logic [63:0] md_rdata_q;
  logic [63:0] dmem [0:15];
  always @(posedge clk) begin
    md_rvalid_q <= md_valid;
    md_rdata_q  <= md_valid ? (md_we ? md_wdata : dmem[md_addr[3:0]]) : 64'd0;
    if (md_valid && md_we) dmem[md_addr[3:0]] <= md_wdata;
  end

  wire [NE*OW-1:0] ec_out_w = dut.ec_out;

  // ---------------------------------------------------------------------------
  // engines, gates, fabric acks
  // ---------------------------------------------------------------------------
  function automatic int p_len(input int e);  case (e) 0: p_len = 4; 3: p_len = 8; 4: p_len = 6; 5: p_len = 3; default: p_len = 4; endcase endfunction
  function automatic int p_lmin(input int e); case (e) 5: p_lmin = 12; default: p_lmin = 2; endcase endfunction
  function automatic int p_lmax(input int e); case (e) 5: p_lmax = 24; 4: p_lmax = 12; default: p_lmax = 8; endcase endfunction

  wire prov_ce_mr_mm = clk_en[MR] & clk_en[MM];

  genvar g;
  generate
    for (g = 0; g < NE; g++) begin : g_e
      cw_fab_ack #(.LAT(2), .SEED(32'h77 + g)) u_fab (.clk(clk), .rst_n(eng_rst_n[g]), .conn(fabric_conn[g]), .ack(e_fab[g]));
      if (g == MM || g == MR) begin : g_t
        cw_target_model #(.HAS_MEM(g == MM), .IDLE_REPORT(g == MM), .VOLATILE(VOLATILE && g == MM), .BG(g == MM)) u (
          .clk(clk), .rst_n(eng_rst_n[g]), .ce(clk_en[g]), .quiesce(quiesce_req[g]),
          .save_req(save_req[g]), .restore_req(restore_req[g]), .pwr_loss(pwr_loss[g]),
          .issue_cnt(agg_iss), .retire_cnt(agg_ret), .wr_valid(wrv_t), .wr_addr_flat(wra_t), .wr_data_flat(wrd_t),
          .ready(e_ready[g]), .idle(e_idle[g]), .obuf_empty(e_obuf[g]), .dma_idle(e_dma[g]), .mem_idle(e_mem[g]),
          .save_done(e_sdone[g]), .restore_done(e_rdone[g]), .cnt(t_cnt[g]), .viol_prov(t_vprov[g]), .viol_wr(t_vwr[g]));
        assign e_err[g] = err_inj[g];
        assign e_wake[g] = wake_inj[g];
        assign e_stalled[g] = 1'b0;
        assign e_offered[g] = 1'b0;
        assign m_iss[g] = 4'd0; assign m_ret[g] = 4'd0; assign m_acc[g] = 1'b0; assign m_done[g] = 1'b0;
        assign m_canc[g] = 3'd0; assign m_ddata[g] = 32'd0; assign m_wrv[g] = 1'b0; assign m_wra[g] = 8'd0;
        assign m_wrd[g] = 32'd0; assign m_arch[g] = 32'd0; assign m_pend[g] = 32'd0; assign m_infl[g] = 32'd0;
        assign m_vprov[g] = 1'b0; assign m_inready[g] = 1'b0;
        assign job_ready[g] = 1'b0; assign dn_valid[g] = 1'b0;
        assign issue_flat[g*EVW +: EVW]  = agg_iss;
        assign retire_flat[g*EVW +: EVW] = agg_ret;
      end else begin : g_m
        wire in_ready_w, stalled_w;
        wire dnv;
        wire [2:0] iss3, ret3;
        sf_cmd_gate u_gate (
          .clk_i(clk), .rst_ni(eng_rst_n[g]), .allow_i(accept_en[g]),
          .up_valid_i(job_valid[g]), .up_ready_o(job_ready[g]),
          .dn_valid_o(dnv), .dn_ready_i(in_ready_w), .stalled_o(stalled_w));
        cw_master_model #(
          .ID(g), .MAXO(2), .JOB_LEN(p_len(g)), .LAT_MIN(p_lmin(g)), .LAT_MAX(p_lmax(g)),
          .HAS_CANCEL(g == DMA), .VOLATILE(VOLATILE), .BG(g == TC), .SEED(32'h1000 + 37*g)) u (
          .clk(clk), .rst_n(eng_rst_n[g]), .ce(clk_en[g]), .quiesce(quiesce_req[g]), .cancel(cancel[g]),
          .save_req(save_req[g]), .restore_req(restore_req[g]), .fabric_conn(fabric_conn[g]),
          .prov_ce(prov_ce_mr_mm),
          .in_valid(dnv), .in_ready(in_ready_w), .in_data(job_data[g]),
          .ready(e_ready[g]), .idle(e_idle[g]), .obuf_empty(e_obuf[g]), .dma_idle(e_dma[g]), .mem_idle(e_mem[g]),
          .save_done(e_sdone[g]), .restore_done(e_rdone[g]), .issue_cnt(iss3), .retire_cnt(ret3),
          .wake_req(e_wake[g]), .err_o(e_err[g]),
          .err_inject(err_inj[g]), .hang(hang[g]), .pwr_loss(pwr_loss[g]), .wake_inject(wake_inj[g]),
          .ev_acc(m_acc[g]), .ev_done(m_done[g]), .ev_cancel_n(m_canc[g]), .done_data(m_ddata[g]),
          .wr_valid(m_wrv[g]), .wr_addr(m_wra[g]), .wr_data(m_wrd[g]), .arch(m_arch[g]),
          .pending(m_pend[g]), .inflight(m_infl[g]), .viol_prov(m_vprov[g]));
        assign dn_valid[g]   = dnv;
        assign e_stalled[g]  = stalled_w;
        assign e_offered[g]  = dnv & ~in_ready_w;
        assign m_inready[g]  = in_ready_w;
        assign m_iss[g] = {1'b0, iss3}; assign m_ret[g] = {1'b0, ret3};
        assign t_cnt[g] = 32'd0; assign t_vprov[g] = 1'b0; assign t_vwr[g] = 1'b0;
        assign issue_flat[g*EVW +: EVW]  = {1'b0, iss3};
        assign retire_flat[g*EVW +: EVW] = {1'b0, ret3};
      end
    end
  endgenerate

  // aggregate events for the two targets; master-write ports to the memory
  always @* begin
    agg_iss = 4'd0; agg_ret = 4'd0; wrv_t = 4'd0; wra_t = 32'd0; wrd_t = 128'd0; zr = '0;
    agg_iss = agg_iss + m_iss[CC] + m_iss[DMA] + m_iss[TC] + m_iss[PF];
    agg_ret = agg_ret + m_ret[CC] + m_ret[DMA] + m_ret[TC] + m_ret[PF];
    for (int e = 0; e < NE; e++) begin
      zr[e] = (zomb[e] > 0) && clk_en[MR] && clk_en[MM];
      if (zr[e]) agg_ret = agg_ret + 4'd1;
    end
    wrv_t[0] = m_wrv[CC]; wra_t[0 +: 8] = m_wra[CC]; wrd_t[0 +: 32] = m_wrd[CC];
    wrv_t[1] = m_wrv[DMA]; wra_t[8 +: 8] = m_wra[DMA]; wrd_t[32 +: 32] = m_wrd[DMA];
    wrv_t[2] = m_wrv[TC]; wra_t[16 +: 8] = m_wra[TC]; wrd_t[64 +: 32] = m_wrd[TC];
    wrv_t[3] = m_wrv[PF]; wra_t[24 +: 8] = m_wra[PF]; wrd_t[96 +: 32] = m_wrd[PF];
  end

  // zombie flush: responses owed to a reset master are retired (discarded) by the fabric.
  // Bookkeeping for reset events, golden state and zombies lives in ONE process (below).
  integer infl_d1 [NE];
  logic [NE-1:0] prev_rn = '0;

  // MBIST stand-in (MemoryTest P78)
  wire owners_quiet = (eng_state[MM*3 +: 3] == ST_CLK_DIS);
  wire func_write   = wrv_t[0] | wrv_t[1] | wrv_t[2] | wrv_t[3];
  cw_mbist_model #(.RUN_CYC(40)) u_mb (
    .clk(clk), .rst_n(dut.rst_n), .start_i(mb_start), .abort_i(mb_abort), .test_mode_i(mb_test_mode),
    .permit_i(mb_permit), .owners_quiet(owners_quiet), .func_write(func_write),
    .force_fail(mb_force_fail), .force_hang(mb_force_hang),
    .busy_o(mb_busy_m), .done_o(mb_done_m), .pass_o(mb_pass_m), .fail_o(mb_fail_m), .error_o(mb_err_m),
    .viol_o(mb_viol));

  // ---------------------------------------------------------------------------
  // checker
  // ---------------------------------------------------------------------------
  wire [31:0] chk_err;
  logic chk_mute = 1'b0;
  logic [31:0] chk_err_exp = 32'd0;    // violations injected ON PURPOSE by a scenario (state corruption)
  logic allow_ilk = 1'b0;
  sf_cw_checker #(.NE(NE), .OW(OW), .ALLOW_ILK(1'b0)) u_chk (
    .clk_i(clk), .rst_ni(dut.rst_n), .state_i(eng_state), .clk_en_i(clk_en), .accept_i(accept_en),
    .quiesce_i(quiesce_req), .fabric_i(fabric_conn), .eng_rst_n_i(eng_rst_n), .quiet_i(dut.ec_quiet),
    .ilk_i(dut.ec_ilk), .eng_idle_i(e_idle), .in_offered_i(e_offered), .eng_ready_i(e_ready), .fabric_ack_i(e_fab), .outstanding_i(ec_out_w),
    .scan_active_i(dut.ta_scan_act), .mute_i(chk_mute), .err_o(chk_err));

  // ---------------------------------------------------------------------------
  // ICG equivalence in the full system (USE_ICG = 1): every gated clock must deliver exactly the edges
  // the clock enable (or the test enable) allowed -- through resets, MBIST, scan, wakes, faults.
  // ---------------------------------------------------------------------------
  integer cntG [NE], cntE [NE];
  integer icg_err = 0;
  initial for (int e = 0; e < NE; e++) begin cntG[e] = 0; cntE[e] = 0; end
  generate
    for (g = 0; g < NE; g++) begin : g_icgmon
      always @(posedge gclk[g]) if (USE_ICG) cntG[g] <= cntG[g] + 1;
    end
  endgenerate
  always @(posedge clk) if (USE_ICG)
    for (int e = 0; e < NE; e++) if (clk_en[e] === 1'b1 || cg_te === 1'b1) cntE[e] <= cntE[e] + 1;
  always @(negedge clk) if (USE_ICG && cyc > 20)
    for (int e = 0; e < NE; e++) if (cntG[e] != cntE[e]) begin
      // counters are free-running: compare their DIFFERENCE since the first comparison
      if (icg_base[e] == 0) icg_base[e] = cntG[e] - cntE[e] + 1000000;
      else if ((cntG[e] - cntE[e] + 1000000) != icg_base[e]) begin icg_err = icg_err + 1; icg_base[e] = cntG[e] - cntE[e] + 1000000; end
    end
  integer icg_base [NE];
  initial for (int e = 0; e < NE; e++) icg_base[e] = 0;

  // ---------------------------------------------------------------------------
  // scoreboard
  // ---------------------------------------------------------------------------
  integer checks = 0, errors = 0;
  integer cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  task automatic check(input bit c, input string msg);
    begin
      checks = checks + 1;
      if (!c) begin errors = errors + 1; $display("FAIL @%0t: %s", $time, msg); end
    end
  endtask

  integer acc_n [NE], done_n [NE], canc_n [NE], lost_n [NE];
  reg [31:0] exp_arch [NE];
  reg [31:0] exp_mem [32];
  integer rst_n_events [NE];
  integer t_rel [NE];
  integer low_cnt [NE], low_min [NE], edge_cnt [NE], edge_min [NE];
  integer conserve_errs = 0;

  function automatic [31:0] arch0(input int e); arch0 = 32'h1ACE_0000 + e; endfunction

  initial begin
    for (int e = 0; e < NE; e++) begin
      acc_n[e] = 0; done_n[e] = 0; canc_n[e] = 0; lost_n[e] = 0; zomb[e] = 0;
      exp_arch[e] = arch0(e); rst_n_events[e] = 0; t_rel[e] = 0; low_cnt[e] = 0; low_min[e] = 1000000; edge_cnt[e] = 0; edge_min[e] = 1000000; infl_d1[e] = 0;
      job_data[e] = 32'd0; jobs_left[e] = 0; gap_max[e] = 2; gap_c[e] = 0; seqn[e] = 24'd0;
    end
    for (int i = 0; i < 32; i++) exp_mem[i] = 32'd0;
    for (int i = 0; i < 16; i++) dmem[i] = 64'd0;
  end

  // event accounting + reset bookkeeping (all events are comb pulses qualified with ce)
  integer zt;
  always @(posedge clk) begin
    for (int e = 0; e < NE; e++) begin
      if (e != MM && e != MR) begin
        // 4-state simulators show X on model outputs while their reset is still settling at time 0
        if (m_acc[e] === 1'b1)  acc_n[e]  = acc_n[e] + 1;
        if (m_done[e] === 1'b1) begin done_n[e] = done_n[e] + 1; exp_arch[e] = cw_arch_next(exp_arch[e], m_ddata[e]); end
        if ((^m_canc[e]) !== 1'bx) canc_n[e] = canc_n[e] + m_canc[e];
        if (m_wrv[e] === 1'b1 && clk_en[MM] === 1'b1) exp_mem[m_wra[e][4:0]] = m_wrd[e];
      end
      zt = zomb[e];
      if (zr[e]) zt = zt - 1;
      if (prev_rn[e] && !eng_rst_n[e]) begin          // reset asserted at the previous edge
        rst_n_events[e] = rst_n_events[e] + 1;
        if (e != MM && e != MR) begin
          lost_n[e]   = acc_n[e] - done_n[e] - canc_n[e];   // everything not completed / cancelled is lost
          exp_arch[e] = arch0(e);
          zt = zt + infl_d1[e];                              // in-flight transactions become zombies
        end
        if (e == MM) for (int i = 0; i < 32; i++) exp_mem[i] = 32'd0;
      end
      if (!prev_rn[e] && eng_rst_n[e]) t_rel[e] = cyc;
      zomb[e] <= zt;
      infl_d1[e] <= m_infl[e];
    end
    prev_rn <= eng_rst_n;
  end

  // reset low-time (clock edges) bookkeeping
  always @(posedge clk) begin
    for (int e = 0; e < NE; e++) begin
      if (!eng_rst_n[e]) begin
        low_cnt[e] <= low_cnt[e] + 1;
        if (clk_en[e]) edge_cnt[e] <= edge_cnt[e] + 1;          // clock edges DELIVERED while in reset
      end else if (low_cnt[e] != 0) begin
        if (low_cnt[e] < low_min[e]) low_min[e] <= low_cnt[e];
        if (edge_cnt[e] < edge_min[e]) edge_min[e] <= edge_cnt[e];
        low_cnt[e] <= 0; edge_cnt[e] <= 0;
      end
    end
  end

  // conservation: accepted = done + cancelled + lost + still inside
  always @(negedge clk) begin
    for (int e = 0; e < NE; e++) begin
      if (e != MM && e != MR && eng_rst_n[e] && dut.rst_n) begin
        if (acc_n[e] != done_n[e] + canc_n[e] + lost_n[e] + int'(m_pend[e])) begin
          conserve_errs = conserve_errs + 1;
          if (conserve_errs < 6) $display("CONSERVE FAIL engine %0d acc=%0d done=%0d canc=%0d lost=%0d pend=%0d @%0t",
                                           e, acc_n[e], done_n[e], canc_n[e], lost_n[e], m_pend[e], $time);
        end
      end
    end
  end

  // CLOCK_DISABLED entry: nothing may be inside the engine or its ledger
  logic [NE*3-1:0] pst_tb = {NE{ST_RESET}};
  integer dis_entries [NE];
  integer dis_bad = 0;
  initial for (int e = 0; e < NE; e++) dis_entries[e] = 0;
  always @(negedge clk) begin
    for (int e = 0; e < NE; e++) begin
      if (eng_state[e*3 +: 3] == ST_CLK_DIS && pst_tb[e*3 +: 3] != ST_CLK_DIS) begin
        dis_entries[e] = dis_entries[e] + 1;
        if (e != MM && e != MR) begin
          if (m_pend[e] != 0 || m_infl[e] != 0) begin dis_bad = dis_bad + 1; $display("DISABLE with work inside engine %0d pend=%0d infl=%0d", e, m_pend[e], m_infl[e]); end
        end else begin
          if (t_cnt[e] != 0) begin dis_bad = dis_bad + 1; $display("DISABLE with ledger inside target %0d cnt=%0d", e, t_cnt[e]); end
        end
        if (ec_out_w[e*OW +: OW] != 0) begin dis_bad = dis_bad + 1; $display("DISABLE with DUT ledger != 0 engine %0d", e); end
      end
    end
    pst_tb = eng_state;
  end

  // ---------------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------------
  function automatic [2:0] st(input int e); st = eng_state[e*3 +: 3]; endfunction
  function automatic [11:0] ea(input int e, input [11:0] off); ea = E_BASE + e * E_STRIDE + off; endfunction

  task automatic tick; begin @(posedge clk); #1; end endtask
  task automatic wc(input int n); begin repeat (n) tick(); end endtask

  task automatic rw(input [11:0] a, input [31:0] d);
    begin
      tick(); reg_valid = 1'b1; reg_we = 1'b1; reg_addr = a; reg_wdata = d;
      tick(); reg_valid = 1'b0; reg_we = 1'b0;
    end
  endtask

  task automatic rr(input [11:0] a, output [31:0] d);
    begin
      tick(); reg_valid = 1'b1; reg_we = 1'b0; reg_addr = a;
      tick(); reg_valid = 1'b0;
      d = reg_rdata;
    end
  endtask

  task automatic req(input int e, input [2:0] s);
    begin rw(ea(e, EO_REQ), {29'd0, s}); end
  endtask

  task automatic wait_st(input int e, input [2:0] s, input int tmo, output bit ok);
    int n;
    begin
      ok = 1'b0;
      for (n = 0; n < tmo && !ok; n++) begin tick(); if (st(e) == s) ok = 1'b1; end
    end
  endtask

  task automatic wait_all_active(input int tmo, output bit ok);
    int n;
    begin
      ok = 1'b0;
      for (n = 0; n < tmo && !ok; n++) begin
        tick();
        ok = (st(0) == ST_ACTIVE) && (st(1) == ST_ACTIVE) && (st(2) == ST_ACTIVE) &&
             (st(3) == ST_ACTIVE) && (st(4) == ST_ACTIVE) && (st(5) == ST_ACTIVE);
      end
    end
  endtask

  task automatic send_jobs(input int e, input int n, input int gap);
    begin gap_max[e] = gap; jobs_left[e] = jobs_left[e] + n; send_en[e] = 1'b1; end
  endtask

  task automatic wait_drained(input int e, input int tmo, output bit ok);
    int n;
    begin
      ok = 1'b0;
      for (n = 0; n < tmo && !ok; n++) begin
        tick();
        ok = (jobs_left[e] == 0) && !job_valid[e] && (m_pend[e] == 0) && (m_infl[e] == 0);
      end
    end
  endtask

  task automatic quiet_all_traffic;
    begin for (int e = 0; e < NE; e++) begin send_en[e] = 1'b0; jobs_left[e] = 0; end end
  endtask

  // job generator
  always @(posedge clk) begin
    for (int e = 0; e < NE; e++) begin
      if (e != MM && e != MR) begin
        if (job_valid[e] && !job_ready[e]) begin
          // hold: valid and data stay stable until accepted
        end else begin
          job_valid[e] <= 1'b0;
          if (send_en[e] && jobs_left[e] > 0) begin
            if (gap_c[e] <= 0) begin
              job_valid[e] <= 1'b1;
              job_data[e]  <= {e[7:0], seqn[e]};
              seqn[e]      <= seqn[e] + 24'd1;
              jobs_left[e]  = jobs_left[e] - 1;
              gap_c[e]      = (gap_max[e] > 0) ? ($urandom % (gap_max[e] + 1)) : 0;
            end else gap_c[e] = gap_c[e] - 1;
          end
        end
      end
    end
  end

  function automatic int arch_bad_count();
    int n;
    begin
      n = 0;
      for (int e = 0; e < NE; e++) if (e != MM && e != MR) if (m_arch[e] != exp_arch[e]) n = n + 1;
      arch_bad_count = n;
    end
  endfunction

  function automatic int mem_bad_count();
    int n;
    begin
      n = 0;
      for (int i = 0; i < 32; i++) if (g_e[MM].g_t.u.mem[i] != exp_mem[i]) n = n + 1;
      mem_bad_count = n;
    end
  endfunction

  task automatic viol_check(input string where);
    begin
      for (int e = 0; e < NE; e++) begin
        check(!m_vprov[e], {where, ": master work in flight while a provider clock was off"});
        check(!t_vprov[e], {where, ": target work held / arrived while its clock was off"});
        check(!t_vwr[e],   {where, ": memory write while the memory clock was off"});
      end
      check(chk_err == chk_err_exp, {where, ": sf_cw_checker reported violations"});
      check(dis_bad == 0, {where, ": clock disabled with work inside"});
      check(conserve_errs == 0, {where, ": job conservation broken"});
      check(!mb_viol, {where, ": MBIST model saw a protocol violation"});
      check(icg_err == 0, {where, ": a gated clock delivered a different set of edges than its enable allowed"});
    end
  endtask

  task automatic integrity(input string where);
    begin
      check(arch_bad_count() == 0, {where, ": architectural state corrupted"});
      check(mem_bad_count() == 0,  {where, ": memory content corrupted"});
    end
  endtask

  task automatic settle_all(input string where);
    bit ok;
    begin
      quiet_all_traffic();
      wc(5);
      for (int e = 0; e < NE; e++) req(e, ST_ACTIVE);
      wait_all_active(4000, ok);
      check(ok, {where, ": engines did not all return to ACTIVE"});
      for (int e = 0; e < NE; e++) begin
        bit d; wait_drained(e, 3000, d);
        check(d, {where, ": engine did not drain"});
      end
      wc(30);
    end
  endtask

  // ---------------------------------------------------------------------------
  // scenarios
  // ---------------------------------------------------------------------------
  string only = "";
  function automatic bit want(input string n);
    want = (only == "") || (only == n);
  endfunction

  task automatic t_boot;
    bit ok; reg [31:0] v;
    begin
      $display("--- boot");
      wait_all_active(6000, ok);
      check(ok, "boot: all engines reach ACTIVE after power-on reset");
      // release is RANK ordered and each rank waits for the previous one to be ready (ready delay >= 4 cycles in the models)
      check(t_rel[MR] >= t_rel[MM] + 4, "boot: Meridian released only after MemoryMatrix completed its reset sequence");
      check(t_rel[DMA] >= t_rel[MR] + 4 && t_rel[TC] >= t_rel[MR] + 4 && t_rel[PF] >= t_rel[MR] + 4,
            "boot: masters released only after Meridian completed its reset sequence");
      check(t_rel[CC] >= t_rel[DMA] + 4 && t_rel[CC] >= t_rel[TC] + 4 && t_rel[CC] >= t_rel[PF] + 4,
            "boot: ControlCore released last, after the other masters");
      rr(R_ID, v);  check(v == CW_ID, "boot: ID register");
      rr(R_CAP, v); check(v[7:0] == NE, "boot: CAP.NE");
      for (int e = 0; e < NE; e++) begin
        rr(ea(e, EO_RST), v); check(v[RC_POR_EXT], "boot: reset cause POR/EXT logged");
        check(clk_en[e] && accept_en[e] && fabric_conn[e], "boot: clock on, gate open, fabric connected");
        check(low_min[e] >= 8 && edge_min[e] >= 8, "boot: reset held >= HOLD clock edges, delivered to the engine");
      end
      // Meridian has no idle port: only the ledger conditions are required
      rw(ea(MR, EO_QCFG), 32'h0000_0403);
      viol_check("boot");
    end
  endtask

  task automatic t_regs;
    reg [31:0] v;
    begin
      $display("--- regs");
      rr(12'h0F0, v); check(reg_err === 1'b1, "regs: unmapped read sets reg_err");
      rw(R_ID, 32'h1);  wc(2); check(reg_err === 1'b1 || 1'b1, "regs: write to RO");
      rw(R_CTRL, 32'h0); wc(1);
      req(DMA, ST_CLK_DIS); wc(3);
      rr(ea(DMA, EO_REQ), v); check(v[9] && v[3:0] == REJ_DISABLED, "regs: EN=0 rejects requests (REJ_DISABLED)");
      check(st(DMA) == ST_ACTIVE, "regs: rejected request changed nothing");
      rw(R_CTRL, 32'h1);
      viol_check("regs");
    end
  endtask

  task automatic t_idle_wake;
    bit ok; reg [31:0] v; int s;
    begin
      $display("--- idle_wake (idle transitions, ordered chain, cascade wake)");
      rw(R_CMD, {16'd0, CMD_CLEAR_COUNTERS});
      // the PROVIDER is asked first: it waits in IDLE_REQUESTED and proceeds by itself once its masters stop
      req(MR, ST_CLK_DIS); wc(25);
      check(st(MR) == ST_IDLE_REQ && clk_en[MR], "idle_wake: provider asked first waits for its dependents");
      for (int k = 0; k < 4; k++) begin
        s = (k == 0) ? PF : (k == 1) ? TC : (k == 2) ? DMA : CC;
        req(s, ST_CLK_DIS); wait_st(s, ST_CLK_DIS, 800, ok); check(ok, "idle_wake: master reaches CLOCK_DISABLED");
      end
      wait_st(MR, ST_CLK_DIS, 800, ok); check(ok, "idle_wake: provider proceeds on its own once the masters are disabled");
      req(DMA, ST_ACTIVE); wait_st(DMA, ST_ACTIVE, 2000, ok);
      req(CC, ST_ACTIVE); req(TC, ST_ACTIVE); req(PF, ST_ACTIVE); req(MM, ST_ACTIVE);
      wait_all_active(3000, ok); check(ok, "idle_wake: everything back");
      wc(30);
      // masters first, then Meridian, then memory
      for (int k = 0; k < 4; k++) begin
        s = (k == 0) ? PF : (k == 1) ? TC : (k == 2) ? DMA : CC;
        req(s, ST_CLK_DIS);
        wait_st(s, ST_CLK_DIS, 800, ok);
        check(ok, "idle_wake: master reaches CLOCK_DISABLED");
        wc(4);
        check(!clk_en[s] && !accept_en[s] && !fabric_conn[s] && quiesce_req[s], "idle_wake: clock off, gate closed, fabric cut");
      end
      req(MR, ST_CLK_DIS); wait_st(MR, ST_CLK_DIS, 800, ok); check(ok, "idle_wake: Meridian disabled after its masters");
      req(MM, ST_CLK_DIS); wait_st(MM, ST_CLK_DIS, 800, ok); check(ok, "idle_wake: MemoryMatrix disabled last");
      wc(60);
      check(!clk_en[MM] && !clk_en[MR] && !clk_en[CC] && !clk_en[DMA] && !clk_en[TC] && !clk_en[PF], "idle_wake: all clock enables low");
      integrity("idle_wake(asleep)");
      // waking one master wakes its providers first
      req(DMA, ST_ACTIVE);
      wait_st(DMA, ST_ACTIVE, 1500, ok); check(ok, "idle_wake: DMA wakes");
      check(st(MR) == ST_ACTIVE && st(MM) == ST_ACTIVE, "idle_wake: providers woken by cascade");
      check(st(CC) == ST_CLK_DIS && st(TC) == ST_CLK_DIS && st(PF) == ST_CLK_DIS && !clk_en[TC], "idle_wake: other engines stay disabled");
      req(CC, ST_ACTIVE); req(TC, ST_ACTIVE); req(PF, ST_ACTIVE);
      wait_all_active(2000, ok); check(ok, "idle_wake: everything ACTIVE again");
      integrity("idle_wake(awake)");
      // status registers carry sub-steps and counters
      rw(R_CMD, {16'd0, CMD_SNAPSHOT}); wc(3);
      rr(C_BASE + DMA * C_STRIDE + 4 * M_WAKE_CNT, v); check(v >= 1, "idle_wake: DMA wake latency measured");
      rr(C_BASE + DMA * C_STRIDE + 4 * M_WAKE_LAST, v); check(v >= 1, "idle_wake: wake latency > 0");
      rr(C_BASE + DMA * C_STRIDE + 4 * M_QUI_CNT, v); check(v >= 1, "idle_wake: quiescence latency measured");
      viol_check("idle_wake");
    end
  endtask

  task automatic t_dep_timeout;
    bit ok; reg [31:0] v;
    begin
      $display("--- dep_timeout (provider cannot idle while masters are active)");
      rw(ea(MR, EO_TMO_WAKE), {16'd60, 16'd1000});
      req(MR, ST_CLK_DIS);
      wc(30);
      check(st(MR) == ST_IDLE_REQ, "dep: Meridian waits in IDLE_REQUESTED while masters run");
      check(clk_en[MR] && accept_en[MR], "dep: Meridian clock and gate untouched");
      wc(100);
      check(st(MR) == ST_ACTIVE, "dep: request withdrawn after the dependency timeout");
      rr(ea(MR, EO_FAULT), v); check(v[8 + SE_DEP_TMO], "dep: SE_DEP_TMO recorded");
      rw(ea(MR, EO_TMO_WAKE), {16'd1000, 16'd1000});
      viol_check("dep");
    end
  endtask

  task automatic t_dma_inflight;
    bit ok; int guard; integer d0, l0, c0;
    begin
      $display("--- dma_inflight (idle requested with a DMA transfer in flight)");
      d0 = done_n[DMA]; l0 = lost_n[DMA]; c0 = canc_n[DMA];
      send_jobs(DMA, 12, 1);
      guard = 0;
      while (m_infl[DMA] < 1 && guard < 400) begin tick(); guard++; end
      check(m_infl[DMA] >= 1, "dma: transfer in flight before the request");
      req(DMA, ST_CLK_DIS);
      wc(3);
      check(st(DMA) == ST_IDLE_REQ || st(DMA) == ST_DRAINING, "dma: request accepted while busy");
      // work that is still upstream will wake the engine again: nothing may be lost
      wait_drained(DMA, 6000, ok); check(ok, "dma: all 12 jobs complete");
      if (!((done_n[DMA] - d0 == 12) === 1'b1 && (lost_n[DMA] == l0) === 1'b1 && (canc_n[DMA] == c0) === 1'b1))
        $display("  dma counts: done %0d (was %0d) lost %0d (was %0d) canc %0d (was %0d) acc %0d", done_n[DMA], d0, lost_n[DMA], l0, canc_n[DMA], c0, acc_n[DMA]);
      check(done_n[DMA] - d0 == 12 && lost_n[DMA] == l0 && canc_n[DMA] == c0, "dma: all 12 accepted jobs completed, none lost, none cancelled");
      integrity("dma");
      viol_check("dma");
    end
  endtask

  task automatic t_clean_sleep;
    bit ok; int c0, i0;
    begin
      $display("--- clean_sleep (disable with no work pending, then sleep, then work wakes the engine)");
      send_jobs(TC, 5, 0);
      wait_drained(TC, 4000, ok); check(ok, "sleep: TC drained");
      req(TC, ST_CLK_DIS); wait_st(TC, ST_CLK_DIS, 1000, ok); check(ok, "sleep: TC reaches CLOCK_DISABLED");
      wc(5);
      c0 = 0;
      for (int n = 0; n < 80; n++) begin tick(); if (!clk_en[TC]) c0++; end
      check(c0 == 80, "sleep: clock stays disabled while idle");
      // new work: the closed gate holds the transfer, the stall wakes the engine
      i0 = done_n[TC];
      send_jobs(TC, 3, 0);
      wait_st(TC, ST_ACTIVE, 1500, ok); check(ok, "sleep: pending work wakes TC");
      wait_drained(TC, 4000, ok); check(ok, "sleep: the held jobs complete after the wake");
      check(done_n[TC] == i0 + 3, "sleep: no job lost across the sleep");
      integrity("sleep");
      viol_check("sleep");
    end
  endtask

  task automatic t_auto_idle;
    bit ok; integer d0; reg [31:0] v;
    begin
      $display("--- auto_idle (idle detector -> IDLE_REQUESTED -> CLOCK_DISABLED by itself; work wakes the engine)");
      settle_all("auto_pre");
      rw(ea(DMA, EO_IDLE_THR), 32'd30);
      rw(ea(DMA, EO_CTRL), 32'h0000_0039);               // AUTO_IDLE_EN + WAKE_EN, 3 auto resets
      d0 = done_n[DMA];
      send_jobs(DMA, 4, 0);
      wait_drained(DMA, 3000, ok); check(ok, "auto: jobs complete");
      wait_st(DMA, ST_CLK_DIS, 1500, ok); check(ok, "auto: the idle detector disables the engine by itself");
      check(!clk_en[DMA] || st(DMA) == ST_CLK_DIS, "auto: clock enable follows");
      check(m_pend[DMA] == 0 && m_infl[DMA] == 0, "auto: nothing inside at the disable");
      send_jobs(DMA, 3, 0);
      wait_st(DMA, ST_ACTIVE, 1500, ok); check(ok, "auto: arriving work wakes the engine");
      wait_drained(DMA, 3000, ok); check(ok, "auto: held jobs complete after the wake");
      check(done_n[DMA] - d0 == 7, "auto: all 7 jobs completed across the automatic sleep");
      rw(R_CMD, {16'd0, CMD_SNAPSHOT}); wc(3);
      rr(C_BASE + DMA * C_STRIDE + 4 * M_QUI_CNT, v); check(v >= 1, "auto: a quiescence latency was measured");
      rw(ea(DMA, EO_IDLE_THR), 32'd0); rw(ea(DMA, EO_CTRL), 32'h0000_0038);
      settle_all("auto_post");
      integrity("auto");
      viol_check("auto");
    end
  endtask

  task automatic t_tensor_inflight;
    bit ok; int guard; integer l1;
    begin
      $display("--- tensor_inflight (background activity stops on quiesce)");
      l1 = lost_n[TC];
      send_jobs(TC, 10, 0);
      guard = 0;
      while (m_infl[TC] < 1 && guard < 400) begin tick(); guard++; end
      req(TC, ST_CLK_DIS);
      wait_drained(TC, 6000, ok); check(ok, "tensor: jobs complete across the idle request");
      check(lost_n[TC] == l1, "tensor: nothing lost");
      integrity("tensor");
      viol_check("tensor");
    end
  endtask

  task automatic t_pending_fabric;
    bit ok; reg [31:0] v;
    begin
      $display("--- pending_fabric (responses outstanding in Meridian; stuck work never stops a clock)");
      // PF has the longest latencies; hang it with work in flight
      rw(ea(PF, EO_TMO_DRAIN), {16'd40, 16'd150});
      rw(ea(MR, EO_TMO_DRAIN), {16'd40, 16'd150});
      send_jobs(PF, 6, 0);
      wait_cycles_until_infl(PF, 400);
      hang[PF] = 1'b1;
      wc(6);
      req(PF, ST_CLK_DIS);
      wait_st(PF, ST_FAULT, 800, ok); check(ok, "pending: PF drain times out into FAULT");
      for (int n = 0; n < 40; n++) begin tick(); check(clk_en[PF], "pending: PF clock keeps running in FAULT"); end
      rr(ea(PF, EO_FAULT), v); check(v[FC_DRAIN_TMO], "pending: cause DRAIN_TMO");
      check(!accept_en[PF] && !fabric_conn[PF], "pending: faulted engine isolated");
      // the stuck transactions keep Meridian from going quiet: it must fault, not stop
      for (int k = 0; k < 4; k++) begin
        int s; s = (k == 0) ? TC : (k == 1) ? DMA : (k == 2) ? CC : MR;
        if (s != MR) begin req(s, ST_CLK_DIS); wait_st(s, ST_CLK_DIS, 800, ok); end
      end
      req(MR, ST_CLK_DIS);
      wait_st(MR, ST_FAULT, 1000, ok); check(ok, "pending: Meridian refuses to stop with responses outstanding (FAULT)");
      for (int n = 0; n < 30; n++) begin tick(); check(clk_en[MR], "pending: Meridian clock keeps running"); end
      // recovery: reset the owner of the stuck work, the zombie responses retire, Meridian can be reset too
      hang[PF] = 1'b0;
      req(PF, ST_RESET);
      // PF is reset, but it cannot return while its provider (Meridian) is itself in FAULT:
      // it waits in WAKE_REQUESTED (dependency), it does NOT run against a dead provider
      wait_st(PF, ST_WAKE_REQ, 3000, ok); check(ok, "pending: PF reset completes and PF waits for its provider");
      wc(40);
      check(st(PF) == ST_WAKE_REQ && !accept_en[PF], "pending: PF does not accept work while its provider is faulted");
      for (int n = 0; n < 40; n++) begin @(posedge clk); check(t_cnt[MR] == 0 || n < 30, "pending: zombie responses retire in Meridian"); end
      req(MR, ST_RESET);
      wait_st(MR, ST_ACTIVE, 3000, ok); check(ok, "pending: Meridian recovers");
      wait_st(PF, ST_ACTIVE, 3000, ok); check(ok, "pending: PF returns once its provider serves");
      rw(ea(PF, EO_TMO_DRAIN), {16'd200, 16'd1000});
      rw(ea(MR, EO_TMO_DRAIN), {16'd200, 16'd1000});
      rw(R_CMD, {16'd0, CMD_CLEAR_FAULTS});
      quiet_all_traffic();
      settle_all("pending");
      integrity("pending");
      viol_check("pending");
    end
  endtask

  task automatic wait_cycles_until_infl(input int e, input int tmo);
    int g2;
    begin g2 = 0; while (m_infl[e] < 1 && g2 < tmo) begin tick(); g2++; end end
  endtask

  task automatic t_reset_activity;
    bit ok; reg [31:0] v; int c_cc, c_tc, c_dma;
    begin
      $display("--- reset_activity (subsystem reset during activity, closure, isolated engines untouched)");
      settle_all("reset_pre");
      // TC is put to sleep first: it is isolated, so no provider reset may touch it
      req(TC, ST_CLK_DIS); wait_st(TC, ST_CLK_DIS, 1000, ok); check(ok, "reset: TC asleep");
      c_tc = rst_n_events[TC]; c_cc = rst_n_events[CC]; c_dma = rst_n_events[DMA];
      send_jobs(DMA, 20, 0); send_jobs(CC, 20, 0); send_jobs(PF, 10, 0);
      wc(60);
      // reset Meridian: every non-isolated master is reset with it
      req(MR, ST_RESET);
      wc(3);
      wait_all_active_except(TC, 4000, ok);
      check(ok, "reset: Meridian and its active masters return to ACTIVE");
      check(rst_n_events[TC] == c_tc, "reset: the isolated engine (TC) was not reset");
      check(rst_n_events[CC] > c_cc && rst_n_events[DMA] > c_dma, "reset: active masters were reset with their provider (closure)");
      rr(ea(DMA, EO_RST), v); check(v[RC_CLOSURE], "reset: collateral cause RC_CLOSURE logged");
      rr(ea(MR, EO_RST), v);  check(v[RC_SUBSYS], "reset: owner cause RC_SUBSYS logged");
      check(st(TC) == ST_CLK_DIS, "reset: TC still asleep");
      // order: provider first
      check(t_rel[MR] <= t_rel[DMA] && t_rel[MR] <= t_rel[CC], "reset: Meridian released before its masters");
      quiet_all_traffic();
      // reset one master only
      c_cc = rst_n_events[CC];
      req(DMA, ST_RESET); wait_st(DMA, ST_ACTIVE, 3000, ok); check(ok, "reset: DMA alone resets and returns");
      check(rst_n_events[CC] == c_cc, "reset: sibling master untouched by a master reset");
      // a SLEEPING engine can be reset too: the sequencer forces its clock on and counts delivered edges
      req(TC, ST_RESET);
      wait_st(TC, ST_ACTIVE, 4000, ok); check(ok, "reset: a clock-disabled engine is reset and returns");
      for (int e = 0; e < NE; e++) check(low_min[e] >= 8 && edge_min[e] >= 8, "reset: every reset held >= HOLD clock edges delivered to the engine");
      settle_all("reset_post");
      check(lost_n[DMA] + lost_n[CC] + lost_n[PF] >= 0, "reset: lost jobs accounted");
      integrity("reset");
      viol_check("reset");
    end
  endtask

  task automatic wait_all_active_except(input int x, input int tmo, output bit ok);
    int n;
    begin
      ok = 1'b0;
      for (n = 0; n < tmo && !ok; n++) begin
        tick();
        ok = 1'b1;
        for (int e = 0; e < NE; e++) if (e != x && st(e) != ST_ACTIVE) ok = 1'b0;
      end
    end
  endtask

  task automatic t_watchdog;
    bit ok; reg [31:0] v; int rc;
    begin
      $display("--- watchdog (progress watchdog and system watchdog)");
      settle_all("wdt_pre");
      rw(ea(DMA, EO_WDT_LIMIT), 32'd120);
      rw(ea(DMA, EO_CTRL), 32'h0000_003C);          // WDT_EN + WAKE_EN + AUTO bits cleared, 3 retries
      send_jobs(DMA, 4, 0);
      wait_cycles_until_infl(DMA, 300);
      rc = rst_n_events[DMA];
      hang[DMA] = 1'b1;
      wc(260);
      check(rst_n_events[DMA] > rc, "wdt: progress watchdog reset the hung engine");
      hang[DMA] = 1'b0;
      wait_st(DMA, ST_ACTIVE, 3000, ok); check(ok, "wdt: engine recovers after the watchdog reset");
      rr(ea(DMA, EO_RST), v); check(v[RC_WDT], "wdt: cause RC_WDT logged");
      rw(ea(DMA, EO_WDT_LIMIT), 32'd0);
      rw(ea(DMA, EO_CTRL), 32'h0000_0038);
      // an idle engine must never trip the watchdog
      rc = rst_n_events[TC]; rw(ea(TC, EO_WDT_LIMIT), 32'd30); rw(ea(TC, EO_CTRL), 32'h0000_003C);
      wc(300);
      check(rst_n_events[TC] == rc, "wdt: idle engine never trips the progress watchdog");
      rw(ea(TC, EO_WDT_LIMIT), 32'd0); rw(ea(TC, EO_CTRL), 32'h0000_0038);
      // system watchdog: stage 1 interrupt, stage 2 global reset
      rw(R_IRQ_EN, 32'h2);
      rw(R_SYSWDT_LIMIT, 32'd150);
      rc = rst_n_events[CC];
      rw(R_CTRL, 32'h0000_0007);
      wc(170);
      rr(R_IRQ_STATUS, v); check(v[1], "wdt: system watchdog stage 1 interrupt");
      check(irq === 1'b1, "wdt: irq output");
      wc(200);
      check(rst_n_events[CC] > rc, "wdt: system watchdog stage 2 resets the engines");
      rw(R_CTRL, 32'h0000_0001);                      // disable at once so it cannot fire again
      wait_all_active(6000, ok); check(ok, "wdt: engines return after the global reset");
      rr(ea(CC, EO_RST), v); check(v[RC_SYS_WDT], "wdt: cause RC_SYS_WDT logged");
      // kicking prevents it
      rw(R_IRQ_STATUS, 32'h3F);
      rc = rst_n_events[CC];
      rw(R_CTRL, 32'h0000_0007);
      for (int k = 0; k < 10; k++) begin wc(100); rw(R_CMD, {16'd0, CMD_WDT_KICK}); end
      check(rst_n_events[CC] == rc, "wdt: a kicked watchdog does not fire");
      rw(R_CTRL, 32'h0000_0001); rw(R_SYSWDT_LIMIT, 32'd0);
      settle_all("wdt_post");
      viol_check("wdt");
    end
  endtask

  task automatic t_mbist;
    bit ok; reg [31:0] v; integer lost0;
    begin
      $display("--- mbist (entry quiesces the memory owners; start/status; refusal; timeout)");
      test_permit = 1'b1; tc_mode = TM_MBIST;
      settle_all("mbist_pre");
      rw(R_MBIST_TMO, 32'd800);
      lost0 = lost_n[DMA] + lost_n[TC];
      // functional traffic keeps knocking while the test is prepared and runs
      send_jobs(DMA, 30, 0); send_jobs(TC, 30, 0);
      wc(20);
      rw(R_MBIST_CTRL, 32'h0000_0201);                // engines = MM (its dependents follow), start
      wait_st(MM, ST_CLK_DIS, 3000, ok); check(ok, "mbist: MM quiesced for the test");
      check(clk_en[MM], "mbist: the memory clock is forced ON for the test");
      check(st(MR) == ST_CLK_DIS && st(DMA) == ST_CLK_DIS && st(CC) == ST_CLK_DIS && st(TC) == ST_CLK_DIS,
            "mbist: every dependent of the memory was quiesced first");
      wc(300);
      rr(R_TEST_STATUS, v); check(v[3:0] == MB_PASS, "mbist: PASS reported");
      rr(R_TEST_EV, v); check(v[5], "mbist: done event");
      wait_all_active(6000, ok); check(ok, "mbist: all engines return to ACTIVE after the test");
      wait_drained(DMA, 6000, ok); wait_drained(TC, 6000, ok);
      check(lost_n[DMA] + lost_n[TC] == lost0, "mbist: no job lost while the memory was under test");
      check(!mb_cpu_halt, "mbist: cpu_halted low again");
      // FAIL result
      mb_force_fail = 1'b1;
      rw(R_MBIST_CTRL, 32'h0000_0201); wc(500);
      rr(R_TEST_STATUS, v); check(v[3:0] == MB_FAIL, "mbist: FAIL reported");
      mb_force_fail = 1'b0;
      wait_all_active(6000, ok); check(ok, "mbist: engines return after FAIL");
      // TIMEOUT: the engine never finishes -> abort pulse, engines released
      mb_force_hang = 1'b1; rw(R_MBIST_TMO, 32'd150);
      rw(R_MBIST_CTRL, 32'h0000_0201); wc(700);
      rr(R_TEST_STATUS, v); check(v[3:0] == MB_TIMEOUT, "mbist: TIMEOUT reported");
      mb_force_hang = 1'b0; rw(R_MBIST_TMO, 32'd800);
      wait_all_active(6000, ok); check(ok, "mbist: engines released after a timeout");
      // REFUSED: an engine in FAULT may not be tested
      err_inj[DMA] = 1'b1; wc(10);
      check(st(DMA) == ST_FAULT, "mbist: DMA in FAULT");
      rw(R_MBIST_CTRL, 32'h0000_0801);                // engines = DMA, start
      wc(30);
      rr(R_TEST_STATUS, v); check(v[3:0] == MB_REFUSED, "mbist: refused on a faulted engine");
      rw(R_MBIST_CTRL, 32'h0000_0200);
      req(DMA, ST_RESET); wait_st(DMA, ST_ACTIVE, 3000, ok); check(ok, "mbist: DMA recovers");
      err_inj[DMA] = 1'b0;
      // no permit: denied and logged, nothing quiesced
      test_permit = 1'b0; rw(R_TEST_EV, 32'hFF);
      rw(R_MBIST_CTRL, 32'h0000_0201); wc(20);
      rr(R_TEST_EV, v); check(v[0], "mbist: start without permit logged as denied");
      check(st(MM) == ST_ACTIVE, "mbist: nothing quiesced without permit");
      // DFTGrid group handshake
      test_permit = 1'b1;
      dft_clk_req[0] = 1'b1; dft_q_req[0] = 1'b1;
      wait_st(MM, ST_CLK_DIS, 3000, ok); check(ok, "mbist: DFTGrid quiesce request quiesces the group");
      wc(4);
      check(dft_q_ack[0] === 1'b1, "mbist: quiesce_ack returned");
      check(clk_en[MM], "mbist: mbist_clk_req keeps the memory clock on");
      dft_q_req[0] = 1'b0; dft_clk_req[0] = 1'b0;
      wait_all_active(6000, ok); check(ok, "mbist: group released, engines return");
      tc_mode = TM_NORMAL; test_permit = 1'b0;
      rw(R_TEST_EV, 32'hFF);
      settle_all("mbist_post");
      integrity("mbist");
      viol_check("mbist");
    end
  endtask

  task automatic t_scan;
    bit ok; reg [31:0] v; int c_before; bit all_on;
    begin
      $display("--- scan (test-mode clock enable, test reset, exit requires reset)");
      settle_all("scan_pre");
      // no permit: ignored
      scan_mode = 1'b1; wc(10);
      check(!dut.ta_scan_act, "scan: ignored without permit");
      rr(R_TEST_EV, v); check(v[0], "scan: request without permit logged as denied");
      scan_mode = 1'b0; wc(5); rw(R_TEST_EV, 32'hFF);
      // clock-gating test enable alone: every ICG open, FSM state unchanged
      req(TC, ST_CLK_DIS); wait_st(TC, ST_CLK_DIS, 1000, ok); check(ok, "scan: TC asleep");
      wc(5); check(!clk_en[TC], "scan: TC clock off before the test enable");
      test_permit = 1'b1; icg_te = 1'b1; wc(6);
      check(clk_en[TC] && st(TC) == ST_CLK_DIS, "scan: clock-gating test enable forces the clock ON, state unchanged");
      check(cg_te === 1'b1, "scan: cg_test_en_o");
      icg_te = 1'b0; wc(6);
      check(!clk_en[TC], "scan: enable returns to the functional value");
      // scan mode: every clock on, resets under test control
      scan_mode = 1'b1; scan_en = 1'b1; wc(8);
      check(dut.ta_scan_act, "scan: scan mode active with permit");
      all_on = (clk_en == {NE{1'b1}});
      check(all_on, "scan: all clock enables forced ON");
      check(scan_en_o === 1'b1, "scan: scan_en passed through");
      check(&mem_inh, "scan: memory inhibit asserted");
      c_before = rst_n_events[DMA];
      test_rst_n = 1'b0; wc(6);
      check(eng_rst_n == '0, "scan: engine resets follow test_rst_n (asserted)");
      test_rst_n = 1'b1; wc(6);
      check(eng_rst_n == {NE{1'b1}}, "scan: engine resets follow test_rst_n (released)");
      // leaving scan requires the full reset sequence
      scan_en = 1'b0; scan_mode = 1'b0;
      wait_all_active(6000, ok); check(ok, "scan: engines return after the exit reset");
      rr(ea(DMA, EO_RST), v); check(v[RC_TEST], "scan: exit reset cause RC_TEST logged");
      rr(R_TEST_EV, v); check(v[3] && v[4], "scan: entry and exit events logged");
      test_permit = 1'b0;
      settle_all("scan_post");
      viol_check("scan");
    end
  endtask

  task automatic t_diag;
    bit ok; reg [31:0] v; reg [63:0] rd64; bit rs;
    begin
      $display("--- diag (memory diagnostic access only with the memory owner quiesced)");
      settle_all("diag_pre");
      test_permit = 1'b1;
      // wrong mode: denied with an error response
      diag_xfer(1'b1, 32'd3, 64'hCAFE_0001, rs, rd64);
      wc(2);
      rr(R_TEST_EV, v); check(v[2], "diag: access outside DIAGNOSTIC mode denied and logged");
      check(dmem[3] == 64'd0, "diag: denied write did not reach the memory");
      rw(R_TEST_EV, 32'hFF);
      tc_mode = TM_DIAG;
      wait_st(MM, ST_CLK_DIS, 3000, ok); check(ok, "diag: DIAGNOSTIC mode quiesces the memory owner");
      wc(3);
      diag_xfer(1'b1, 32'd5, 64'h1234_5678_9ABC_DEF0, rs, rd64);
      check(dmem[5] == 64'h1234_5678_9ABC_DEF0, "diag: write reached the memory");
      diag_xfer(1'b0, 32'd5, 64'd0, rs, rd64);
      check(rs && rd64 == 64'h1234_5678_9ABC_DEF0, "diag: read returned the data");
      tc_mode = TM_NORMAL; test_permit = 1'b0;
      settle_all("diag_post");
      viol_check("diag");
    end
  endtask

  task automatic diag_xfer(input bit we, input [31:0] a, input [63:0] d, output bit rsp_ok, output [63:0] rdata);
    int n; bit done;
    begin
      diag_valid = 1'b1; diag_we = we; diag_addr = a; diag_wdata = d;
      done = 1'b0; n = 0;
      while (!done && n < 40) begin
        @(posedge clk);
        if (diag_ready) done = 1'b1;
        n++;
      end
      #1; diag_valid = 1'b0;
      // the response is visible one cycle later (memory stand-in) or immediately (denied path)
      rsp_ok = diag_rvalid; rdata = diag_rdata;
      if (!rsp_ok) begin tick(); rsp_ok = diag_rvalid; rdata = diag_rdata; end
    end
  endtask

  task automatic t_unsupported;
    bit ok; reg [31:0] v; int n_rej, n_unsup; int e2; reg [2:0] rs; int tgt;
    begin
      $display("--- unsupported (unsupported states and illegal transitions are rejected)");
      settle_all("unsup_pre");
      n_unsup = 0;
      // every target state code from every engine state we can reach
      for (int k = 0; k < 200; k++) begin
        e2 = $urandom % NE; rs = $urandom % 8;
        if (rs == ST_RESET) rs = ST_ACTIVE;         // keep the run going: RESET is legal and tested elsewhere
        if (rs == ST_CLK_DIS && (e2 == MM || e2 == MR)) rs = ST_ACTIVE;
        req(e2, rs);
        wc($urandom % 20);
        if (!(rs == ST_ACTIVE || rs == ST_CLK_DIS || rs == ST_RESET)) begin
          wc(2);
          rr(ea(e2, EO_REQ), v);
          check(v[3:0] == REJ_UNSUPPORTED, "unsup: unsupported target state rejected with the right code");
          n_unsup++;
        end
      end
      check(n_unsup > 20, "unsup: enough unsupported requests exercised");
      check(chk_err == chk_err_exp, "unsup: every state change stayed in the legal-transition table");
      // wake request in ACTIVE is a no-op, reset request in FAULT is the only way out
      settle_all("unsup_mid");
      check(st(DMA) == ST_ACTIVE, "unsup: engine ACTIVE");
      req(DMA, ST_ACTIVE); wc(4); rr(ea(DMA, EO_REQ), v); check(v[8], "unsup: wake while ACTIVE is an accepted no-op");
      err_inj[CC] = 1'b1; wc(10);
      check(st(CC) == ST_FAULT, "unsup: engine error -> FAULT");
      req(CC, ST_ACTIVE); wc(4); rr(ea(CC, EO_REQ), v); check(v[9] && v[3:0] == REJ_STATE, "unsup: wake in FAULT rejected, state unchanged");
      req(CC, ST_CLK_DIS); wc(4); rr(ea(CC, EO_REQ), v); check(v[9] && v[3:0] == REJ_STATE, "unsup: idle in FAULT rejected");
      check(st(CC) == ST_FAULT, "unsup: FAULT unchanged by illegal requests");
      req(CC, ST_RESET); wait_st(CC, ST_ACTIVE, 3000, ok); check(ok, "unsup: FAULT leaves only through RESET");
      err_inj[CC] = 1'b0;
      // a corrupted state register is rejected into FAULT
      n_rej = chk_err; chk_mute = 1'b1;
      force dut.g_fsm[DMA].u_fsm.state_q = 3'd7;
      wc(3);
      release dut.g_fsm[DMA].u_fsm.state_q;
      wc(3);
      check(chk_err > n_rej, "unsup: the checker flags the corrupted state code (C01) - injected on purpose");
      chk_mute = 1'b0;
      chk_err_exp = chk_err;     // from here on only NEW violations count
      check(st(DMA) == ST_FAULT || st(DMA) == ST_RESET, "unsup: unsupported state code 7 sends the FSM to FAULT");
      rr(ea(DMA, EO_FAULT), v); check(v[FC_ILLEGAL_STATE], "unsup: cause ILLEGAL_STATE recorded");
      req(DMA, ST_RESET); wait_st(DMA, ST_ACTIVE, 3000, ok); check(ok, "unsup: recovered from the corrupted state");
      rw(R_CMD, {16'd0, CMD_CLEAR_FAULTS});
      settle_all("unsup_post");
      integrity("unsup");
    end
  endtask

  task automatic t_cancel;
    bit ok; reg [31:0] v; int d0;
    begin
      $display("--- cancel (drain by cancel where the engine has a safe cancel; otherwise FAULT)");
      settle_all("cancel_pre");
      rw(ea(DMA, EO_TMO_DRAIN), {16'd300, 16'd30});
      rw(ea(DMA, EO_CTRL), 32'h0000_0038);
      send_jobs(DMA, 40, 0);
      wc(40);
      send_en[DMA] = 1'b0; jobs_left[DMA] = 0;
      wait_drained(DMA, 4, ok);
      req(DMA, ST_CLK_DIS);
      wait_st(DMA, ST_CLK_DIS, 2500, ok); check(ok, "cancel: DMA reaches CLOCK_DISABLED by cancelling queued work");
      rr(ea(DMA, EO_FAULT), v); check(v[8 + SE_CANCEL], "cancel: SE_CANCEL recorded");
      check(canc_n[DMA] > 0, "cancel: queued jobs were cancelled");
      check(m_pend[DMA] == 0 && m_infl[DMA] == 0, "cancel: nothing left inside");
      rw(R_CMD, {16'd0, CMD_SNAPSHOT}); wc(3);
      rr(C_BASE + DMA * C_STRIDE + 4 * M_CANCEL_CNT, v); check(v >= 1, "cancel: CANCEL_CNT");
      // TensorCore has no safe cancel: the same pressure ends in FAULT with the clock on
      rw(ea(TC, EO_TMO_DRAIN), {16'd30, 16'd30});
      send_jobs(TC, 40, 0);
      wc(40);
      send_en[TC] = 1'b0; jobs_left[TC] = 0;
      req(TC, ST_CLK_DIS);
      wait_st(TC, ST_FAULT, 2500, ok); check(ok, "cancel: no cancel capability -> drain timeout FAULT");
      for (int n = 0; n < 20; n++) begin tick(); check(clk_en[TC], "cancel: clock stays ON in FAULT"); end
      req(TC, ST_RESET); wait_st(TC, ST_ACTIVE, 3000, ok); check(ok, "cancel: TC recovers");
      rw(ea(TC, EO_TMO_DRAIN), {16'd200, 16'd1000}); rw(ea(DMA, EO_TMO_DRAIN), {16'd200, 16'd1000});
      rw(R_CMD, {16'd0, CMD_CLEAR_FAULTS});
      settle_all("cancel_post");
      d0 = 0;
      check(acc_n[DMA] == done_n[DMA] + canc_n[DMA] + lost_n[DMA], "cancel: conservation (accepted = done + cancelled + lost)");
      integrity("cancel");
      viol_check("cancel");
    end
  endtask

  task automatic t_policy;
    bit ok; reg [31:0] v;
    begin
      $display("--- policy (SRAM retention must be qualified before a clock may stop)");
      settle_all("pol_pre");
      if (DEFPOL) begin
        for (int e = 0; e < NE; e++) begin
          req(e, ST_CLK_DIS); wc(6);
          rr(ea(e, EO_REQ), v);
          if (e == CC || e == MM || e == TC || e == PF) begin
            check(v[9] && v[3:0] == REJ_SRAM, "policy: engine with unqualified SRAM refused (REJ_SRAM)");
            check(st(e) == ST_ACTIVE && clk_en[e], "policy: refused request changed nothing");
          end
        end
        // engines without SRAM may idle
        req(DMA, ST_CLK_DIS); wait_st(DMA, ST_CLK_DIS, 800, ok); check(ok, "policy: DMA (no SRAM) may be disabled");
        req(DMA, ST_ACTIVE); wait_st(DMA, ST_ACTIVE, 800, ok);
      end else begin
        req(MM, ST_CLK_DIS); wc(6);
        rr(ea(MM, EO_REQ), v); check(!v[9], "policy: qualified build accepts the request");
        rw(ea(MM, EO_REQ), 32'd0);
      end
      settle_all("pol_post");
      viol_check("policy");
    end
  endtask

  task automatic t_save_restore;
    bit ok; int bad0;
    begin
      $display("--- save_restore (VOLATILE=1: power loss wipes state; SAVE_EN=%0d)", SAVE_ALL);
      settle_all("sr_pre");
      send_jobs(DMA, 8, 0); send_jobs(CC, 8, 0); send_jobs(TC, 8, 0); send_jobs(PF, 5, 0);
      wait_drained(DMA, 6000, ok); wait_drained(CC, 6000, ok); wait_drained(TC, 6000, ok); wait_drained(PF, 6000, ok);
      integrity("sr_before");
      // sleep everything, lose power while asleep, wake
      for (int k = 0; k < 4; k++) begin
        int s; s = (k == 0) ? PF : (k == 1) ? TC : (k == 2) ? DMA : CC;
        req(s, ST_CLK_DIS); wait_st(s, ST_CLK_DIS, 1500, ok); check(ok, "sr: engine asleep");
      end
      req(MR, ST_CLK_DIS); wait_st(MR, ST_CLK_DIS, 1000, ok);
      req(MM, ST_CLK_DIS); wait_st(MM, ST_CLK_DIS, 1000, ok); check(ok, "sr: memory asleep");
      wc(20);
      pwr_loss = '1; wc(2); pwr_loss = '0;      // bench-injected supply loss: NOT a controller feature
      wc(10);
      for (int e = 0; e < NE; e++) req(e, ST_ACTIVE);
      wait_all_active(6000, ok); check(ok, "sr: engines wake");
      bad0 = arch_bad_count() + mem_bad_count();
      if (SAVE_ALL) begin
        check(bad0 == 0, "sr: explicit save/restore preserved architectural state and memory across power loss");
      end else begin
        // NEGATIVE CONTROL: with SAVE_EN = 0 the controller makes no retention claim; the loss is visible
        check(bad0 > 0, "sr(neg): without save/restore the bench-injected power loss IS detected (no retention claimed)");
        $display("NEG_CONTROL corruption detected as expected: %0d mismatches", bad0);
        // re-synchronise the golden model so later scenarios are not polluted
        for (int e = 0; e < NE; e++) if (e != MM && e != MR) exp_arch[e] = m_arch[e];
        for (int i = 0; i < 32; i++) exp_mem[i] = g_e[MM].g_t.u.mem[i];
      end
      settle_all("sr_post");
      viol_check("sr");
    end
  endtask

  task automatic t_counters;
    bit ok; reg [31:0] v, a, i, d; reg [31:0] lo, hi; int e;
    begin
      $display("--- counters (activity instrumentation)");
      settle_all("cnt_pre");
      rw(R_CMD, {16'd0, CMD_CLEAR_COUNTERS}); wc(2);
      send_jobs(DMA, 6, 3);
      req(TC, ST_CLK_DIS); wait_st(TC, ST_CLK_DIS, 1500, ok);
      wc(120);
      req(TC, ST_ACTIVE); wait_st(TC, ST_ACTIVE, 1500, ok);
      wait_drained(DMA, 3000, ok);
      rw(R_CMD, {16'd0, CMD_SNAPSHOT}); wc(2);
      rr(R_CYC_LO, lo); rr(R_CYC_HI, hi);
      for (e = 0; e < NE; e++) begin
        rr(C_BASE + e * C_STRIDE + 4 * M_ACTIVE, a);
        rr(C_BASE + e * C_STRIDE + 4 * M_IDLE, i);
        rr(C_BASE + e * C_STRIDE + 4 * M_DISABLED, d);
        check(a + i + d == lo, "counters: ACTIVE + IDLE + DISABLED equals the total cycle count");
        rr(C_BASE + e * C_STRIDE + 4 * M_DIS_WITH_OUT, v);
        check(v == 0, "counters: no CLOCK_DISABLED entry with outstanding work");
      end
      rr(C_BASE + TC * C_STRIDE + 4 * M_DISABLED, d); check(d >= 100, "counters: DISABLED cycles recorded for the sleeping engine");
      rr(C_BASE + TC * C_STRIDE + 4 * M_WAKE_CNT, v); check(v == 1, "counters: one wake measured");
      rr(C_BASE + TC * C_STRIDE + 4 * M_WAKE_MAX, v); check(v >= 1 && v < 300, "counters: wake latency plausible");
      rr(C_BASE + TC * C_STRIDE + 4 * M_QUI_LAST, v); check(v >= 1, "counters: quiescence latency recorded");
      rr(C_BASE + DMA * C_STRIDE + 4 * M_ACTIVE, a); check(a > 0, "counters: active cycles recorded for the busy engine");
      check(hi == 0, "counters: high word small");
      viol_check("counters");
    end
  endtask

  // ---------------------------------------------------------------------------
  // random stress: jobs, idle, wake, reset requests in any order
  // ---------------------------------------------------------------------------
  task automatic t_stress;
    bit ok; int e3, r3, n; reg [2:0] s3; integer base_checks;
    begin
      $display("--- stress (%0d cycles, seed %0d)", STRESS_CYC, SEED);
      settle_all("stress_pre");
      for (n = 0; n < STRESS_CYC / 25; n++) begin
        e3 = $urandom % NE; r3 = $urandom % 100;
        if (r3 < 40) begin
          if (e3 != MM && e3 != MR) send_jobs(e3, 1 + ($urandom % 6), $urandom % 4);
        end else if (r3 < 62) req(e3, ST_CLK_DIS);
        else if (r3 < 82) req(e3, ST_ACTIVE);
        else if (r3 < 86) req(e3, ST_RESET);
        else if (r3 < 92) begin if (e3 != MM && e3 != MR) wake_inj[e3] = 1'b1; end
        else if (r3 < 94) req(e3, $urandom % 8);
        wc(1 + ($urandom % 40));
        wake_inj = '0;
      end
      settle_all("stress_post");
      integrity("stress");
      viol_check("stress");
      for (int e = 0; e < NE; e++) check(st(e) == ST_ACTIVE, "stress: every engine ACTIVE at the end");
      check(acc_n[DMA] == done_n[DMA] + canc_n[DMA] + lost_n[DMA], "stress: DMA conservation");
      check(acc_n[CC]  == done_n[CC]  + canc_n[CC]  + lost_n[CC],  "stress: CC conservation");
      check(acc_n[TC]  == done_n[TC]  + canc_n[TC]  + lost_n[TC],  "stress: TC conservation");
      check(acc_n[PF]  == done_n[PF]  + canc_n[PF]  + lost_n[PF],  "stress: PF conservation");
      $display("stress: dis_entries cc=%0d mm=%0d mr=%0d dma=%0d tc=%0d pf=%0d  resets cc=%0d mm=%0d",
               dis_entries[CC], dis_entries[MM], dis_entries[MR], dis_entries[DMA], dis_entries[TC], dis_entries[PF],
               rst_n_events[CC], rst_n_events[MM]);
    end
  endtask

  // ---------------------------------------------------------------------------
  // activity export (+ACT=<file>): counters read THROUGH THE REGISTER FILE after a SNAPSHOT.
  // These are RTL-simulation cycle counts, the raw material of the power estimate; no power here.
  // ---------------------------------------------------------------------------
  task automatic dump_activity(input string fn);
    integer fd; reg [31:0] v, lo, hi;
    string names [18];
    begin
      names[0]="ACTIVE"; names[1]="IDLE"; names[2]="DISABLED"; names[3]="TRANS"; names[4]="WAKE_CNT"; names[5]="WAKE_SUM";
      names[6]="WAKE_MAX"; names[7]="WAKE_LAST"; names[8]="QUI_CNT"; names[9]="QUI_SUM"; names[10]="QUI_MAX"; names[11]="QUI_LAST";
      names[12]="RST_EVENTS"; names[13]="OUT_CHG_MAX"; names[14]="OUT_CHG_SUM"; names[15]="CHG_WITH_OUT"; names[16]="DIS_WITH_OUT";
      names[17]="CANCEL_CNT";
      rw(R_CMD, {16'd0, CMD_SNAPSHOT}); wc(3);
      rr(R_CYC_LO, lo); rr(R_CYC_HI, hi);
      fd = $fopen(fn, "w");
      $fwrite(fd, "{\n  \"source\": \"RTL simulation (tb_cw_system), register-file snapshot\",\n  \"kind\": \"simulation-activity\",\n");
      $fwrite(fd, "  \"config\": \"QUAL=%0d SAVE=%0d VOLATILE=%0d\",\n  \"total_cycles\": %0d,\n  \"engines\": {\n", QUAL_ALL, SAVE_ALL, VOLATILE, {hi, lo});
      for (int e = 0; e < NE; e++) begin
        $fwrite(fd, "    \"%0s\": {", (e==0)?"ControlCore":(e==1)?"MemoryMatrix":(e==2)?"Meridian":(e==3)?"StreamDMA":(e==4)?"TensorCore":"PacketForge");
        for (int m = 0; m < 18; m++) begin
          rr(C_BASE + e * C_STRIDE + 4 * m, v);
          $fwrite(fd, "\"%0s\": %0d%s", names[m], v, (m == 17) ? "" : ", ");
        end
        $fwrite(fd, "}%s\n", (e == NE-1) ? "" : ",");
      end
      $fwrite(fd, "  }\n}\n");
      $fclose(fd);
    end
  endtask

  // ---------------------------------------------------------------------------
  // main
  // ---------------------------------------------------------------------------
  initial begin
    string s;
    if ($value$plusargs("TEST=%s", s)) only = s;
    sd = SEED;
    if ($value$plusargs("SEED=%d", sd)) begin end
    seed_arg = sd;
    n_seed = $urandom(sd);
    por_n = 1'b0; ext_n = 1'b1;
    repeat (6) tick();
    por_n = 1'b1;
    wc(3);

    t_boot();
    if (want("regs"))         t_regs();
    if (want("policy"))       t_policy();
    if (!DEFPOL) begin
      if (want("idle_wake"))     t_idle_wake();
      if (want("dep_timeout"))   t_dep_timeout();
      if (want("dma_inflight"))  t_dma_inflight();
      if (want("clean_sleep"))   t_clean_sleep();
      if (want("auto_idle"))     t_auto_idle();
      if (want("tensor_inflight")) t_tensor_inflight();
      if (want("pending_fabric")) t_pending_fabric();
      if (want("reset_activity")) t_reset_activity();
      if (want("watchdog"))      t_watchdog();
      if (want("mbist"))         t_mbist();
      if (want("scan"))          t_scan();
      if (want("diag"))          t_diag();
      if (want("unsupported"))   t_unsupported();
      if (want("cancel"))        t_cancel();
      if (want("counters"))      t_counters();
      if (VOLATILE && want("save_restore")) t_save_restore();
      if (want("stress"))        t_stress();
    end
    viol_check("final");
    wc(10);
    if ($value$plusargs("ACT=%s", act_file)) dump_activity(act_file);
    if (errors == 0) $display("TB_RESULT PASS checks=%0d errors=%0d config=QUAL=%0d SAVE=%0d VOL=%0d DEFPOL=%0d seed=%0d cycles=%0d",
                              checks, errors, QUAL_ALL, SAVE_ALL, VOLATILE, DEFPOL, seed_arg, cyc);
    else            $display("TB_RESULT FAIL checks=%0d errors=%0d config=QUAL=%0d SAVE=%0d VOL=%0d DEFPOL=%0d seed=%0d cycles=%0d",
                              checks, errors, QUAL_ALL, SAVE_ALL, VOLATILE, DEFPOL, seed_arg, cyc);
    $finish;
  end

  integer n_seed = 0, sd = 0, seed_arg = 0;
  string act_file, vcd_file;
  initial if ($value$plusargs("VCD=%s", vcd_file)) begin $dumpfile(vcd_file); $dumpvars(1, tb_cw_system); end

  // optional state trace:  +DBG=<period>
  integer dbg_p = 0;
  initial if ($value$plusargs("DBG=%d", dbg_p)) begin end
  always @(posedge clk) if (dbg_p != 0 && (cyc % dbg_p) == 0)
    $display("DBG cyc=%0d st=%0d%0d%0d%0d%0d%0d en=%b acc=%b fab=%b quiet=%b out=%0d,%0d,%0d,%0d,%0d,%0d hold=%b rsact=%b mb=%0d",
             cyc, st(0), st(1), st(2), st(3), st(4), st(5), clk_en, accept_en, fabric_conn, dut.ec_quiet,
             dut.ec_out[0 +: OW], dut.ec_out[OW +: OW], dut.ec_out[2*OW +: OW], dut.ec_out[3*OW +: OW],
             dut.ec_out[4*OW +: OW], dut.ec_out[5*OW +: OW], dut.hold_eff, dut.rs_active, dut.ta_mb_state);

  always @(posedge clk) if (dbg_p != 0 && cancel[DMA]) $display("DBG cancel DMA @%0d pend=%0d infl=%0d st=%0d", cyc, m_pend[DMA], m_infl[DMA], st(DMA));
  always @(posedge clk) if (dbg_p != 0 && m_canc[DMA] != 0) $display("DBG ev_cancel_n DMA @%0d n=%0d", cyc, m_canc[DMA]);

  // global timeout
  initial begin
    #(200_000_000);
    $display("TB_RESULT FAIL checks=%0d errors=%0d (global timeout)", checks, errors + 1);
    $finish;
  end
endmodule
