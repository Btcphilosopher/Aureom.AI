// =============================================================================
// Unit bench: sf_clock_enable_ctrl against an independent reference model.
// Random issue/retire/idle/err stimulus (with deliberate protocol violations),
// every output compared every cycle.  Kills: ledger, quiescence window, mask,
// idle detector, interlock and enable-function mutants.
// =============================================================================
`timescale 1ns/1ps
module tb_cw_unit_ec;
  import sf_cw_pkg::*;
  localparam int NE = 2, OW = 6, EVW = 3;
  localparam [NE-1:0] LEDGER = 2'b11;

  logic clk = 0; always #5 clk = ~clk;
  logic rst_n = 0;
  logic [NE-1:0] clk_run, accept_fsm, rst_force, test_force, f_block, auto_en, wake_en, e_idle, e_obuf, e_dma, e_mem, e_err, e_wake, stalled, offered;
  logic test_en, clk_loss;
  logic [NE*8-1:0]  qcyc;
  logic [NE*24-1:0] ithr;
  logic [NE*NQ-1:0] qmask;
  logic [NE*EVW-1:0] iss, ret;
  wire [NE-1:0] clk_en, accept_en, quiet, wake_ev, auto_idle, act, ilk;
  wire [NE*OW-1:0] outs;
  wire [NE*NQ-1:0] qv;
  wire [NE*8-1:0]  fev;

  sf_clock_enable_ctrl #(.NE(NE), .OW(OW), .EVW(EVW), .LEDGER_EN(LEDGER)) dut (
    .clk_i(clk), .rst_ni(rst_n), .clk_run_i(clk_run), .accept_fsm_i(accept_fsm), .rst_clk_force_i(rst_force),
    .test_clk_force_i(test_force), .test_en_i(test_en), .f_block_i(f_block),
    .cfg_quiet_cyc_i(qcyc), .cfg_idle_thr_i(ithr), .cfg_qmask_i(qmask), .cfg_auto_idle_en_i(auto_en),
    .cfg_wake_en_i(wake_en), .clk_loss_i(clk_loss),
    .eng_idle_i(e_idle), .eng_obuf_empty_i(e_obuf), .eng_dma_idle_i(e_dma), .eng_mem_idle_i(e_mem),
    .eng_err_i(e_err), .eng_wake_req_i(e_wake), .up_stalled_i(stalled), .in_offered_i(offered),
    .issue_cnt_i(iss), .retire_cnt_i(ret),
    .clk_en_o(clk_en), .accept_en_o(accept_en), .quiet_o(quiet), .wake_ev_o(wake_ev), .auto_idle_o(auto_idle),
    .act_o(act), .outstanding_o(outs), .q_vec_o(qv), .fault_ev_o(fev), .ilk_hit_o(ilk));

  // ---------------- independent reference model ----------------
  integer m_out [NE], m_qcnt [NE], m_icnt [NE];
  reg m_lerr [NE], m_clken [NE], m_ilk [NE], m_errq [NE], m_loss [NE];
  reg m_lossprev;
  integer errors = 0, checks = 0, n_under = 0, n_quiet = 0, n_ilk = 0, n_auto = 0;

  task chk(input bit c, input string m);
    begin checks = checks + 1; if (!c) begin errors = errors + 1; if (errors < 10) $display("FAIL @%0t: %s", $time, m); end end
  endtask

  integer i1, r1, qlim, thr;
  reg [NQ-1:0] q, mk;
  reg qok, idle_now, busy, qraw, accept_e;
  integer sum;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int e = 0; e < NE; e++) begin m_out[e] = 0; m_qcnt[e] = 0; m_icnt[e] = 0; m_lerr[e] = 0; m_clken[e] = 1; m_ilk[e] = 0; m_errq[e] = 0; m_loss[e] = 0; end
      m_lossprev = 0;
    end else begin
      for (int e = 0; e < NE; e++) begin
        accept_e = accept_fsm[e] & ~f_block[e];
        i1 = iss[e*EVW +: EVW]; r1 = ret[e*EVW +: EVW];
        q[Q_WORK_STOP] = ~accept_e & ~offered[e];
        q[Q_OUTSTANDING] = (m_out[e] == 0);
        q[Q_OBUF] = e_obuf[e]; q[Q_DMA] = e_dma[e]; q[Q_MEM] = e_mem[e]; q[Q_IDLE] = e_idle[e];
        mk = qmask[e*NQ +: NQ];
        qok = ((q | ~mk) == {NQ{1'b1}});
        qraw = qok && !m_lerr[e];
        qlim = (qcyc[e*8 +: 8] == 0) ? 1 : qcyc[e*8 +: 8];
        idle_now = e_idle[e] && (m_out[e] == 0) && !offered[e] && !stalled[e];
        busy = !e_idle[e] || (m_out[e] != 0) || offered[e];
        // next state of the model (all registered quantities)
        m_ilk[e] = !clk_run[e] && !rst_force[e] && !test_force[e] && !test_en && busy;
        m_clken[e] = clk_run[e] | rst_force[e] | test_force[e] | test_en | busy;
        m_qcnt[e] = qraw ? ((m_qcnt[e] == 255) ? 255 : m_qcnt[e] + 1) : 0;
        m_icnt[e] = idle_now ? ((m_icnt[e] == 16777215) ? m_icnt[e] : m_icnt[e] + 1) : 0;
        sum = m_out[e] + i1 - r1;
        m_lerr[e] = 0;
        if (rst_force[e]) m_out[e] = 0;
        else if (sum < 0) begin m_out[e] = 0; m_lerr[e] = 1; end
        else if (sum > (1 << OW) - 1) begin m_out[e] = (1 << OW) - 1; m_lerr[e] = 1; end
        else m_out[e] = sum;
        m_errq[e] = e_err[e];
        m_loss[e] = clk_loss | (clk_loss & ~m_lossprev);
      end
      m_lossprev = clk_loss;
    end
  end

  // compare at the falling edge (after the DUT flops have settled)
  reg prev_err [NE];
  integer qlim2;
  always @(negedge clk) if (rst_n) begin
    for (int e = 0; e < NE; e++) begin
      chk(outs[e*OW +: OW] == m_out[e], "ledger value");
      chk(clk_en[e] == m_clken[e], "clock enable function");
      chk(ilk[e] == m_ilk[e], "interlock flag");
      qlim2 = (qcyc[e*8 +: 8] == 0) ? 1 : qcyc[e*8 +: 8];
      chk(quiet[e] == (m_qcnt[e] >= qlim2), "quiescence stability window");
      thr = ithr[e*24 +: 24];
      chk(auto_idle[e] == (auto_en[e] && thr != 0 && m_icnt[e] >= thr), "idle detector");
      chk(fev[e*8 + FC_LEDGER] == m_lerr[e], "ledger fault event");
      chk(fev[e*8 + FC_ILK] == m_ilk[e], "interlock fault event");
      chk(accept_en[e] == (accept_fsm[e] & ~f_block[e]), "accept gate");
      chk(wake_ev[e] == (wake_en[e] & (e_wake[e] | stalled[e])), "wake event");
      if (m_lerr[e]) n_under++;
      if (quiet[e]) n_quiet++;
      if (ilk[e]) n_ilk++;
      if (auto_idle[e]) n_auto++;
    end
  end

  // ---------------- stimulus ----------------
  integer cyc;
  integer mo [NE];
  always @(negedge clk) begin   // drive away from the sampling edge
    if (!rst_n) begin
      clk_run <= '1; accept_fsm <= '0; rst_force <= '0; test_force <= '0; f_block <= '0; auto_en <= '1; wake_en <= '1;
      e_idle <= '1; e_obuf <= '1; e_dma <= '1; e_mem <= '1; e_err <= '0; e_wake <= '0; stalled <= '0; offered <= '0;
      test_en <= 0; clk_loss <= 0; iss <= '0; ret <= '0;
      qcyc <= {8'd3, 8'd0}; ithr <= {24'd7, 24'd0}; qmask <= {NE*NQ{1'b1}};
    end else begin
      for (int e = 0; e < NE; e++) begin
        if ($urandom % 100 < 8)  clk_run[e] <= ~clk_run[e];
        if ($urandom % 100 < 10) accept_fsm[e] <= ~accept_fsm[e];
        if ($urandom % 100 < 1)  rst_force[e] <= ~rst_force[e];
        if ($urandom % 100 < 2)  test_force[e] <= ~test_force[e];
        if ($urandom % 100 < 3)  f_block[e] <= ~f_block[e];
        if ($urandom % 100 < 25) e_idle[e] <= ~e_idle[e];
        if ($urandom % 100 < 10) e_obuf[e] <= ~e_obuf[e];
        if ($urandom % 100 < 10) e_dma[e]  <= ~e_dma[e];
        if ($urandom % 100 < 10) e_mem[e]  <= ~e_mem[e];
        if ($urandom % 1000 < 3) e_err[e]  <= ~e_err[e];
        if ($urandom % 100 < 10) e_wake[e] <= ~e_wake[e];
        if ($urandom % 100 < 10) stalled[e] <= ~stalled[e];
        if ($urandom % 100 < 10) offered[e] <= ~offered[e];
        if ($urandom % 100 < 1)  qcyc[e*8 +: 8] <= $urandom % 7;
        if ($urandom % 100 < 1)  ithr[e*24 +: 24] <= $urandom % 12;
        if ($urandom % 200 < 1)  qmask[e*NQ +: NQ] <= $urandom;
        if ($urandom % 100 < 1)  auto_en[e] <= ~auto_en[e];
        if ($urandom % 100 < 1)  wake_en[e] <= ~wake_en[e];
        // issue / retire: mostly valid, occasionally violating the protocol
        iss[e*EVW +: EVW] <= ($urandom % 100 < 30) ? ($urandom % 3) : 0;
        if ($urandom % 100 < 45) ret[e*EVW +: EVW] <= ($urandom % 3);
        else                     ret[e*EVW +: EVW] <= 0;
      end
      if ($urandom % 100 < 1) test_en <= ~test_en;
      if ($urandom % 400 < 1) clk_loss <= ~clk_loss;
    end
  end

  initial begin
    repeat (4) @(negedge clk);
    rst_n = 1;
    repeat (120000) @(posedge clk);
    chk(n_under > 5,  "stimulus coverage: ledger violations exercised");
    chk(n_quiet > 1000, "stimulus coverage: quiescence reached");
    chk(n_ilk > 100,  "stimulus coverage: interlock exercised");
    chk(n_auto > 100, "stimulus coverage: idle detector exercised");
    if (errors == 0) $display("TB_RESULT PASS checks=%0d errors=0 unit=enable_ctrl under=%0d quiet=%0d ilk=%0d auto=%0d", checks, n_under, n_quiet, n_ilk, n_auto);
    else             $display("TB_RESULT FAIL checks=%0d errors=%0d unit=enable_ctrl", checks, errors);
    $finish;
  end
endmodule
