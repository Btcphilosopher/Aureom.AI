"""Self-checks of the power tools.  The numbers below are SYNTHETIC TEST FIXTURES, not data about
any silicon; they exist so that the arithmetic and the refusal behaviour can be verified."""
import json, pathlib, subprocess, sys, tempfile, unittest
ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import power_report, vcd_activity  # noqa: E402

ACT = {"source": "fixture", "config": "fixture", "total_cycles": 1000, "engines": {
    "E": {"ACTIVE": 300, "IDLE": 200, "DISABLED": 500, "TRANS": 4, "WAKE_CNT": 2, "WAKE_SUM": 30, "WAKE_MAX": 20, "WAKE_LAST": 10,
          "QUI_CNT": 2, "QUI_SUM": 12, "QUI_MAX": 8, "QUI_LAST": 4, "RST_EVENTS": 0, "OUT_CHG_MAX": 0, "OUT_CHG_SUM": 0,
          "CHG_WITH_OUT": 0, "DIS_WITH_OUT": 0, "CANCEL_CNT": 0}}}

VCD = """$timescale 1ns $end
$scope module tb $end
$var wire 1 ! clk_en $end
$var wire 2 " vec [1:0] $end
$upscope $end
$enddefinitions $end
#0
0!
b00 "
#10
1!
b01 "
#40
0!
b11 "
#100
"""

class T(unittest.TestCase):
    def test_duty_and_counts(self):
        rows, _ = power_report.build(ACT, None, None, None)
        r = rows[0]
        self.assertAlmostEqual(r["enable_duty"], 0.5)
        self.assertAlmostEqual(r["wake_latency_mean"], 15.0)
        self.assertNotIn("analytical_clock_mW", r)
        self.assertNotIn("library_clock_mW", r)

    def test_refuses_without_inputs(self):
        rows, notes = power_report.build(ACT, None, None, None)
        txt = power_report.render(ACT, rows, notes, None, None, None)
        self.assertIn("not computed (no --params given)", txt)
        self.assertIn("not computed (no --lib given)", txt)
        self.assertIn("Savings are not stated", txt)
        self.assertNotIn(" mW |", txt.split("## 2.")[1].split("## 3.")[0])

    def test_analytical_arithmetic(self):
        params = {"assumptions": "fixture", "engines": {"E": {"clock_cap_fF": 1000.0, "V": 1.0, "f_MHz": 100.0}}}
        rows, _ = power_report.build(ACT, params, None, None)
        # 1000 fF * 1 V^2 * 100 MHz = 1e-12 F * 1e8 Hz = 1e-4 W = 0.1 mW at 100 %, 0.05 mW at duty 0.5
        self.assertAlmostEqual(rows[0]["analytical_clock_mW_full"], 0.1)
        self.assertAlmostEqual(rows[0]["analytical_clock_mW"], 0.05)

    def test_library_scaling(self):
        lib = {"provenance": "fixture", "engines": {"E": {"clock_tree_mW_at_full_enable": 8.0, "icg_overhead_mW": 0.25, "leakage_mW": 3.0}}}
        rows, _ = power_report.build(ACT, None, lib, None)
        self.assertAlmostEqual(rows[0]["library_clock_mW"], 8.0 * 0.5 + 0.25)
        self.assertEqual(rows[0]["library_leakage_mW_unchanged"], 3.0)

    def test_vcd_activity(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / "t.vcd"; p.write_text(VCD)
            act, ts, end = vcd_activity.extract(str(p), {"clk_en", "vec"}, "tb")
            w, bits = act[("tb", "clk_en")]
            self.assertEqual(end, 100)
            self.assertEqual((bits[0]["T0"], bits[0]["T1"], bits[0]["TC"]), (70, 30, 2))   # 0..10 low, 10..40 high, 40..100 low
            w2, b2 = act[("tb", "vec")]
            self.assertEqual(w2, 2)
            self.assertEqual(b2[0]["TC"], 1)   # bit0: 0 -> 1 at #10, stays 1
            self.assertEqual(b2[1]["TC"], 1)   # bit1: 0 -> 1 at #40
            s = pathlib.Path(d) / "t.saif"
            vcd_activity.write_saif(str(s), act, ts, end, "dut")
            txt = s.read_text()
            self.assertIn("(DURATION 100000)", txt)
            self.assertIn("(clk_en (T0 70000) (T1 30000) (TX 0) (TC 2) (IG 0))", txt)
            self.assertEqual(txt.count("("), txt.count(")"))

if __name__ == "__main__":
    unittest.main()
