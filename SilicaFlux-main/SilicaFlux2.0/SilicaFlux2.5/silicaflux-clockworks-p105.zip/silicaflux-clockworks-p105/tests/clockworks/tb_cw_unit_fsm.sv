// =============================================================================
// Unit bench: sf_power_state_fsm, random stimulus, independent oracle.
//   * cw_legal (sf_cw_pkg) is the oracle for every state change
//   * rules S1..S6 of the FSM header are checked every cycle
//   * four parameter sets (SAVE / CANCEL / RESET-ON-WAKE / SRAM policy)
// =============================================================================
`timescale 1ns/1ps

module cw_fsm_bench #(
  parameter bit ALLOW_GATE = 1, parameter bit HAS_SRAM = 0, parameter bit SRAM_QUAL = 0,
  parameter bit SAVE_EN = 0, parameter bit CAN_CANCEL = 0, parameter bit RST_ON_WAKE = 0,
  parameter int ID = 0, parameter int CYCLES = 200000
) (
  input  logic clk,
  output logic done,
  output integer errors,
  output integer checks,
  output integer n_dis, n_wake, n_fault, n_rej, n_reset, n_cancel
);
  import sf_cw_pkg::*;
  logic rst_n = 0;
  logic req_valid = 0; logic [2:0] req_state = 0;
  logic test_hold = 0, auto_idle = 0, wake_ev = 0;
  logic rst_active = 0, rst_done = 0, rst_fail = 0;
  logic quiet = 0, clk_ok = 1, prov_ready = 1, deps_iso = 1, eng_ready = 0, fabric_ack = 0, save_done = 0, restore_done = 0;
  logic [7:0] fault_ev = 0;
  logic fault_clr = 0;
  wire req_ack, req_rej; wire [3:0] rej_code;
  wire rst_sw, rst_flt;
  wire [2:0] state; wire clk_run, accept, quiesce, cancel, save_req, restore_req, fabric_conn, iso, serving;
  wire [2:0] dstep, wstep; wire [7:0] fault_set, soft_set; wire trans; wire [2:0] tfrom, tto;
  logic clk_en_fb;

  sf_power_state_fsm #(.ALLOW_GATE(ALLOW_GATE), .HAS_SRAM(HAS_SRAM), .SRAM_QUAL(SRAM_QUAL), .SAVE_EN(SAVE_EN),
                       .CAN_CANCEL(CAN_CANCEL), .RST_ON_WAKE(RST_ON_WAKE)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cfg_drain_tmo_i(16'd60), .cfg_cancel_tmo_i(16'd30), .cfg_wake_tmo_i(16'd150), .cfg_dep_tmo_i(16'd80),
    .cfg_min_active_i(16'd8), .cfg_clk_settle_i(8'd2), .cfg_fault_rst_en_i(ID[0]), .cfg_max_auto_rst_i(4'd2), .fault_clr_i(fault_clr),
    .req_valid_i(req_valid), .req_state_i(req_state), .test_hold_i(test_hold), .auto_idle_i(auto_idle), .wake_ev_i(wake_ev),
    .req_ack_o(req_ack), .req_rej_o(req_rej), .rej_code_o(rej_code),
    .rst_active_i(rst_active), .rst_done_i(rst_done), .rst_fail_i(rst_fail), .rst_pend_i(1'b0),
    .rst_sw_req_o(rst_sw), .rst_fault_req_o(rst_flt),
    .quiet_i(quiet), .clk_en_i(clk_en_fb), .clk_ok_i(clk_ok), .prov_ready_i(prov_ready), .deps_iso_i(deps_iso),
    .eng_ready_i(eng_ready), .fabric_ack_i(fabric_ack), .save_done_i(save_done), .restore_done_i(restore_done),
    .fault_ev_i(fault_ev),
    .state_o(state), .clk_run_o(clk_run), .accept_o(accept), .quiesce_o(quiesce), .cancel_o(cancel),
    .save_req_o(save_req), .restore_req_o(restore_req), .fabric_conn_o(fabric_conn), .isolated_o(iso), .serving_o(serving),
    .dstep_o(dstep), .wstep_o(wstep), .fault_set_o(fault_set), .soft_set_o(soft_set),
    .trans_o(trans), .trans_from_o(tfrom), .trans_to_o(tto));

  integer cyc = 0;
  initial begin errors = 0; checks = 0; done = 0; n_dis = 0; n_wake = 0; n_fault = 0; n_rej = 0; n_reset = 0; n_cancel = 0; end

  task automatic chk(input bit c, input string m);
    begin checks = checks + 1; if (!c) begin errors = errors + 1; if (errors < 6) $display("FAIL cfg%0d @%0t: %s", ID, $time, m); end end
  endtask

  // ---------------- environment ----------------
  integer rs_cnt = 0, rs_len = 0, sv_cnt = 0, rv_cnt = 0, fb_cnt = 0;
  logic [2:0] pst = ST_RESET;
  logic pquiet = 0, pacc = 0, pclk_run = 1, psave_done = 0, preq_valid = 0, preq_unsup = 0, pbad = 0;
  logic [2:0] preq_state = 0;
  logic [2:0] pstate_for_rej;
  integer drain_cycles = 0;

  always @(posedge clk) begin
    cyc <= cyc + 1;
    clk_en_fb <= clk_run;                         // the enable follows the FSM one cycle later
    if (!rst_n) begin pst <= ST_RESET; end
    else begin
      // ---------------- oracle checks (previous vs current) ----------------
      chk(state != ST_BAD, "S5: state never 7");
      chk(cw_legal(pst, state), "C02: legal transition");
      chk(clk_run || state == ST_CLK_DIS, "S1: clock stops only in CLOCK_DISABLED");
      if (state == ST_CLK_DIS && pst != ST_CLK_DIS) begin
        chk(pst == ST_DRAINING && pquiet && !pacc && (SAVE_EN ? psave_done : 1'b1), "S2: CLOCK_DISABLED only from DRAINING with quiescence (and save)");
        n_dis = n_dis + 1;
      end
      chk(!accept || state == ST_ACTIVE || state == ST_IDLE_REQ, "S3: gate open only in ACTIVE / IDLE_REQUESTED");
      if (accept && !pacc) chk(state == ST_ACTIVE && fabric_conn && (pst == ST_WAKE_REQ || pst == ST_DRAINING || pst == ST_IDLE_REQ), "S3: gate reopens only on entry to ACTIVE");
      if (accept && !pacc && pst == ST_WAKE_REQ) chk(eng_ready_q && fabric_ack_q, "S3: reopen after readiness and fabric reconnection");
      if (state == ST_FAULT) chk(clk_run && !accept && !fabric_conn, "S4: FAULT keeps the clock running, gate closed, fabric cut");
      if (state == ST_RESET) chk(clk_run && !accept && !fabric_conn, "RESET: clock running, gate closed");
      if (state == ST_CLK_DIS) chk(!fabric_conn && quiesce && !accept, "CLOCK_DISABLED: fabric cut, quiesce asserted");
      if (state == ST_DRAINING) chk(!accept && quiesce, "DRAINING: gate closed");
      if (pst == ST_DRAINING && state == ST_FAULT) n_fault = n_fault + 1;
      if (pst != ST_WAKE_REQ && state == ST_WAKE_REQ && pst == ST_CLK_DIS) n_wake = n_wake + 1;
      if (pst != ST_RESET && state == ST_RESET) n_reset = n_reset + 1;
      if (cancel) n_cancel = n_cancel + 1;
      // a request that names an unsupported state is rejected, with the right code
      if (preq_valid && !(preq_state == ST_ACTIVE || preq_state == ST_CLK_DIS || preq_state == ST_RESET) && !pbad) begin
        chk(req_rej && (rej_code == REJ_UNSUPPORTED || rej_code == REJ_STATE), "S6: unsupported target state rejected");
        n_rej = n_rej + 1;
      end
      if (req_rej) chk(rej_code != REJ_NONE, "reject carries a code");
      // sticky causes: every transition into FAULT records a cause
      if (state == ST_FAULT && pst != ST_FAULT) chk(fault_set_q != 0, "FAULT entry records a cause");
      pst <= state; pquiet <= quiet; pacc <= accept; psave_done <= save_done;
      pbad <= (pst == ST_BAD);
    end
  end

  logic [7:0] fault_set_q;
  logic eng_ready_q, fabric_ack_q;
  always @(posedge clk) begin fault_set_q <= fault_set; eng_ready_q <= eng_ready; fabric_ack_q <= fabric_ack;
    preq_valid <= req_valid; preq_state <= req_state; end

  // ---------------- random stimulus (away from the sampling edge) ----------------
  integer busy_left = 0;
  always @(negedge clk) begin
    if (rst_n) begin
      req_valid <= ($urandom % 100) < 9;
      req_state <= $urandom % 8;
      if (($urandom % 100) < 2) test_hold <= ~test_hold;
      auto_idle <= (($urandom % 100) < 15);
      wake_ev   <= (($urandom % 100) < 4);
      fault_ev  <= (($urandom % 1000) < 3) ? (8'h01 << ($urandom % 8)) : 8'h00;
      fault_clr <= (($urandom % 500) < 1);
      // the engine: busy for a while after the gate is open, quiet otherwise
      if (busy_left > 0) busy_left = busy_left - 1;
      else if (accept && (($urandom % 100) < 4)) busy_left = 5 + ($urandom % 100);   // may outlast the drain timeout
      quiet <= (busy_left == 0) && !accept && (($urandom % 100) < 85);
      if (($urandom % 100) < 3) prov_ready <= ~prov_ready;
      if (($urandom % 100) < 3) deps_iso <= ~deps_iso;
      if (($urandom % 400) < 1) clk_ok <= ~clk_ok;
      // readiness is sticky once reached (until a reset); the fabric ack follows the connect request
      if (rst_active) eng_ready <= 1'b0; else if (!eng_ready) eng_ready <= (($urandom % 100) < 30);
      if (!fabric_conn) fabric_ack <= 1'b0; else if (!fabric_ack) fabric_ack <= (($urandom % 100) < 40);
      save_done <= save_req && (($urandom % 100) < 30);
      restore_done <= restore_req && (($urandom % 100) < 30);
      // reset sequencer stand-in: starts 2 cycles after a request (or randomly), lasts 6..20 cycles
      rst_done <= 1'b0; rst_fail <= 1'b0;
      if (rs_len == 0) begin
        rst_active <= 1'b0;
        if (rst_sw || rst_flt || (($urandom % 2000) < 3)) begin rs_len = 3 + ($urandom % 20); rst_active <= 1'b0; end
      end else begin
        rs_len = rs_len - 1;
        rst_active <= 1'b1;
        if (rs_len == 0) begin
          if (($urandom % 100) < 6) rst_fail <= 1'b1; else rst_done <= 1'b1;
        end
      end
    end
  end
  // rst_active must stay high in the cycle in which done/fail pulses
  always @(posedge clk) if (rst_n && rst_active == 1'b0 && (rst_done || rst_fail)) rst_active <= 1'b1;

  initial begin
    repeat (4) @(negedge clk); rst_n = 1;
    repeat (CYCLES) @(posedge clk);
    done = 1;
  end
endmodule

module tb_cw_unit_fsm;
  logic clk = 0; always #5 clk = ~clk;
  wire [3:0] d; integer e [4]; integer c [4]; integer nd [4], nw [4], nf [4], nr [4], nz [4], nc [4];
  genvar i;
  cw_fsm_bench #(.ID(0), .ALLOW_GATE(1), .HAS_SRAM(0), .SAVE_EN(0), .CAN_CANCEL(0), .RST_ON_WAKE(0)) b0 (clk, d[0], e[0], c[0], nd[0], nw[0], nf[0], nr[0], nz[0], nc[0]);
  cw_fsm_bench #(.ID(1), .ALLOW_GATE(1), .HAS_SRAM(1), .SRAM_QUAL(1), .SAVE_EN(1), .CAN_CANCEL(1), .RST_ON_WAKE(0)) b1 (clk, d[1], e[1], c[1], nd[1], nw[1], nf[1], nr[1], nz[1], nc[1]);
  cw_fsm_bench #(.ID(2), .ALLOW_GATE(1), .HAS_SRAM(0), .SAVE_EN(0), .CAN_CANCEL(1), .RST_ON_WAKE(1)) b2 (clk, d[2], e[2], c[2], nd[2], nw[2], nf[2], nr[2], nz[2], nc[2]);
  cw_fsm_bench #(.ID(3), .ALLOW_GATE(1), .HAS_SRAM(1), .SRAM_QUAL(0), .SAVE_EN(0), .CAN_CANCEL(0), .RST_ON_WAKE(0)) b3 (clk, d[3], e[3], c[3], nd[3], nw[3], nf[3], nr[3], nz[3], nc[3]);
  integer tot_e, tot_c;
  initial begin
    wait (&d);
    tot_e = e[0] + e[1] + e[2] + e[3]; tot_c = c[0] + c[1] + c[2] + c[3];
    // coverage of the random run
    for (int k = 0; k < 4; k++)
      $display("cfg%0d: checks=%0d errors=%0d disable-entries=%0d wakes=%0d faults(drain)=%0d resets=%0d rejects=%0d cancels=%0d", k, c[k], e[k], nd[k], nw[k], nf[k], nz[k], nr[k], nc[k]);
    if (nd[0] < 50 || nd[1] < 50 || nw[0] < 50 || nz[0] < 20 || nr[0] < 500 || nc[1] < 3 || nf[0] < 3)
      begin $display("FAIL: stimulus coverage too low"); tot_e = tot_e + 1; end
    if (tot_e == 0) $display("TB_RESULT PASS checks=%0d errors=0 unit=power_state_fsm", tot_c);
    else            $display("TB_RESULT FAIL checks=%0d errors=%0d unit=power_state_fsm", tot_c, tot_e);
    $finish;
  end
endmodule
