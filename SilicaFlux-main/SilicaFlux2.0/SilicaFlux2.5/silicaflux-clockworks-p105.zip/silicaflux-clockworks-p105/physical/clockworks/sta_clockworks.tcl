# =============================================================================
# SilicaFlux Project 105 CLOCKWORKS -- STA signoff script TEMPLATE (OpenSTA / PrimeTime syntax)
# NOT RUN.  Fill in the @@...@@ items; run once per corner and per mode.
# =============================================================================
set DESIGN   sf_clock_power_ctrl
set CORNERS  {@@SLOW_LIB@@ @@TYP_LIB@@ @@FAST_LIB@@}       ;# Liberty files, one per corner
set NETLIST  @@NETLIST.v@@
set MODE     func                                            ;# func | test
foreach lib $CORNERS { read_liberty $lib }
read_verilog $NETLIST
link_design $DESIGN
read_sdc physical/clockworks/clockworks_${MODE}.sdc          ;# clockworks_func.sdc / clockworks_test.sdc
## post-CTS: read_spef @@PARASITICS.spef@@

check_setup -verbose                    ;# unconstrained endpoints, loops, multiple clocks
report_clock_properties
report_checks -path_delay max -group_count 20 -format full_clock_expanded
report_checks -path_delay min -group_count 20 -format full_clock_expanded
## the three checks that matter for THIS block
report_checks -path_delay max -through [get_pins -hier *u_cg*/*]   ;# enable -> ICG (clock-gating setup)
report_checks -path_delay min -through [get_pins -hier *u_cg*/*]   ;# clock-gating hold
report_checks -path_delay max -to [get_pins -hier *u_rs*/*/D]      ;# reset synchroniser data pins
## reset release timing: recovery / removal of every engine reset synchroniser output
report_checks -path_delay max -format full_clock_expanded -unconstrained -group_count 5 -to [get_ports eng_rst_no*]
report_clock_skew
report_clock_gating_check               ;# PrimeTime; in OpenSTA the checks appear as the clock-gating path group
## sanity: no unexpected unconstrained / false-pathed endpoint count
report_exceptions
