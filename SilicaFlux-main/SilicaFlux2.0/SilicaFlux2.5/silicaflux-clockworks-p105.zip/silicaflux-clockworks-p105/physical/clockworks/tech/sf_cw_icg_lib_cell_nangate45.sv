// Binding of sf_cw_icg_lib_cell to the Nangate45 integrated clock gate (FreePDK45; EDUCATIONAL,
// non-manufacturable).  Same mapping as P40's `sf_icg_nangate45` (CLKGATETST_X1: CK E SE -> GCK).
// Select with +define+SF_CW_ICG_LIB and compile this file; or use +define+SF_CW_ICG_NANGATE45 to have
// sf_cw_clock_gate instantiate the cell directly.
module sf_cw_icg_lib_cell (input wire CK, input wire E, input wire SE, output wire GCK);
  (* keep, dont_touch = "true" *)
  CLKGATETST_X1 u_cell (.CK(CK), .E(E), .SE(SE), .GCK(GCK));
endmodule
