// Binding to IHP SG13G2 (130 nm, open PDK): sg13g2_slgcp_1, clock_gating_integrated_cell
// "latch_posedge_precontrol", pins CLK GATE SCE -> GCLK.  Pins as recorded and checked against the
// Liberty by the repository's P35 CLOCKTREE project (rtl/tech/ihp_sg13g2/sf_crt_tech_cells.sv).
// NOT re-verified in this package.  ORFS marks the cell DONT_USE for inference; explicit instantiation
// is legal.
module sf_cw_icg_lib_cell (input wire CK, input wire E, input wire SE, output wire GCK);
  (* keep, dont_touch = "true" *)
  sg13g2_slgcp_1 u_cell (.CLK(CK), .GATE(E), .SCE(SE), .GCLK(GCK));
endmodule
