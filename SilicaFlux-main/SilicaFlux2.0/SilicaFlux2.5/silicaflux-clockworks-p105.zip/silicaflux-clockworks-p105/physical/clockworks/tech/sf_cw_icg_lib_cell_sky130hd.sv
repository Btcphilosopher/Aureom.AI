// Binding to SKY130 sky130_fd_sc_hd: sdlclkp_1 (ICG with scan enable), pins CLK GATE SCE -> GCLK.
// Pins as recorded by P35 CLOCKTREE (rtl/tech/sky130hd/sf_crt_tech_cells.sv).  NOT re-verified here.
module sf_cw_icg_lib_cell (input wire CK, input wire E, input wire SE, output wire GCK);
  (* keep, dont_touch = "true" *)
  sky130_fd_sc_hd__sdlclkp_1 u_cell (.CLK(CK), .GATE(E), .SCE(SE), .GCLK(GCK));
endmodule
