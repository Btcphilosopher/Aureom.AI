// Blackbox of the library ICG wrapper, for synthesis / lint before the real cell is bound.
(* blackbox *)
module sf_cw_icg_lib_cell (input CK, input E, input SE, output GCK);
endmodule
