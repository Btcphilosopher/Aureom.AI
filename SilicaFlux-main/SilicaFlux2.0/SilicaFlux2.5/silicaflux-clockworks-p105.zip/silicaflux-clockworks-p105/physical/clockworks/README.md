# physical/clockworks - constraints, power intent and technology bindings (TEMPLATES)

**Status: not run.** No Liberty library, STA tool, UPF tool or PDK for the SilicaFlux ASIC exists in this
repository or in this environment, so nothing here has been executed against a netlist. Every file is a
reviewed template whose structure follows the repository's validated precedents (P35 ClockTree SDC, P36
PowerFabric UPF, P40 Nangate45 ICG binding). Replace every `@@...@@` placeholder with real data and run
the checks listed in `docs/clockworks/10_PHYSICAL_AND_SIGNOFF.md` before relying on any of it.

| File | Purpose | Real data needed |
|---|---|---|
| `clockworks_func.sdc` | functional-mode clocks, resets, async inputs, gating, documented exceptions | clock period, IO budgets, ICG instance names |
| `clockworks_test.sdc` | scan / test-mode constraints (case analysis, scan-enable, ICG test enable) | scan style, TCK / ATE timing |
| `timing_exceptions.md` | every exception with rationale and how it is verified | - |
| `clock_domain_boundary.md` | the clock-domain boundary specification | integration choices |
| `power_intent_template.upf` | IEEE 1801 TEMPLATE: domains, isolation, retention, switches (NOT enabled; `PD_SUPPORT = 0`) | supply nets, library cells |
| `sta_clockworks.tcl` | OpenSTA / PrimeTime style signoff script template | libs, netlist, corners |
| `ICG_QUALIFICATION.md` | what must be true before `SF_CW_ICG_*` is used in production | library data |
| `tech/*.sv` | `sf_cw_icg_lib_cell` bindings (Nangate45, IHP SG13G2, SKY130) and a blackbox | the real cell |

Clock gating policy of this package: **synchronous clock enables are the baseline** (`clk_en_o`);
`USE_ICG = 1` adds one library ICG per engine through `sf_cw_clock_gate`. A clock is never gated with an
AND/OR in RTL (negative control in `tests/clockworks/tb_cw_icg.sv`: 4,998 glitches on a plain AND gate).
