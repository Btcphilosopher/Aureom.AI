# Clock-domain boundary specification

## Domains

| Domain | Clock | Source | Contents | Reset |
|---|---|---|---|---|
| `clk_core` | `clk_i` | clock root: PLL output, or P35 `clk_core_o` | EVERYTHING in this package: FSMs, enable controller, reset sequencer, watchdogs, counters, register file, test adapter; and the six engines (enable-gated copies) | `rst_n` = controller reset (`por_ni & ext_rst_ni`, async assert, sync release); per-engine resets from `sf_reset_sequencer` |

There is **one functional clock domain**. The six engines' gated clocks (`gclk_o[e]`, if `USE_ICG = 1`) are
*copies* of `clk_core` behind an ICG, not new domains: same edges, one more clock-network level. They are
timed as one clock propagated through clock-gating cells (no generated clock).

## Signals that cross the boundary of the block

| Signal | Direction | Class | Mechanism | Requirement on the source |
|---|---|---|---|---|
| `por_ni`, `ext_rst_ni` | in | async, single bit, reset | `sf_reset_sync` (2 flops, async assert / sync release) | glitch-free; both are combined by a single AND for the pin pair - use a reset-combine cell in the library |
| `test_rst_ni` | in | async, single bit, reset | bypass mux through `sf_reset_sync` in scan mode | scan-controlled only |
| `pll_lock_i` | in | async, single bit, level | `sf_sync2` (2 flops) | level; a lock glitch is a clock-loss event by design |
| `clk_ok_i` | in | SYNCHRONOUS to `clk_i` | none (direct) | must already be synchronised by its producer (e.g. the P35 clock monitor output after its own CDC); if it is not, add `sf_sync2` |
| `scan_mode_i`, `scan_en_i`, `icg_te_i`, `mem_inhibit_i`, `test_permit_i`, `tc_mode_i`, `dft_*` | in | synchronous / quasi-static | none | DFTGrid P39 delivers them in its `clk` domain (the same clock); raw pins must be synchronised by the integrator |
| `eng_*_i`, `up_stalled_i`, `in_offered_i`, `fabric_ack_i`, `issue/retire_cnt_i` | in | synchronous | none | engines run on `clk_core` (or its gated copy, whose edges are a subset); event pulses must be qualified with the engine's clock enable (see 03_QUIESCENCE.md rule E3) |
| `reg_*` | in/out | synchronous | none | register bus master on `clk_core` |
| `clk_en_o`, `accept_en_o`, `quiesce_req_o`, `cancel_o`, `save_req_o`, `restore_req_o`, `fabric_connect_o`, `mem_inhibit_o` | out | synchronous (flop outputs) | none | consumed on `clk_core` |
| `eng_rst_no[e]` | out | reset, synchronous release | `sf_reset_sync` per engine | consumed as ASYNC reset by the engine; recovery/removal timed against the engine's clock |

## What the boundary does NOT contain

* no multi-bit signal crosses between asynchronous clocks;
* no clock multiplexer, divider or PLL (`clk_i` is an input);
* no clock-loss detection circuit of its own: loss of the functional clock must be detected by something
  that does not depend on that clock (P35 clock monitor on `clk_ref`), and delivered as `clk_ok_i` /
  `pll_lock_i`. If the clock stops, this block stops with it; its own `FC_CLK_LOSS` fault is raised when the
  clock RETURNS (or when the lock flag drops while the clock still runs).

## If the integrator splits an engine onto its own clock

Then that engine is a second domain. The per-engine interface (`clk_en`, `accept_en`, `quiesce`, `cancel`,
events, readiness) becomes a set of asynchronous crossings: single-bit levels through `sf_sync2`, the event
counts (`issue_cnt`, `retire_cnt`) through a handshake or FIFO (multi-bit), and the clock enable through the
destination domain's ICG enable synchroniser (P35 pattern). This is NOT implemented here.
