# Integrated clock-gate qualification checklist

`sf_cw_clock_gate` is the only place a clock is gated. Selecting `SF_CW_ICG_NANGATE45`, `SF_CW_ICG_LIB` or
`SF_CW_ICG_XILINX_BUFGCE` is a **build selection, not a qualification**. Production use needs every line below
answered from real library data. Unanswered = not qualified.

| # | Question | Answer source | Value | Verified by | Date |
|---|---|---|---|---|---|
| 1 | Exact library cell name and drive strength | Liberty / foundry databook | @@ | | |
| 2 | Cell is a latch-based ICG (`clock_gating_integrated_cell : latch_posedge_precontrol` or equivalent) | Liberty | @@ | | |
| 3 | Pin names: clock, enable, test/scan enable, output | Liberty | @@ (repo precedent: Nangate45 `CK E SE GCK`; IHP `CLK GATE SCE GCLK`; SKY130 `CLK GATE SCE GCLK`) | | |
| 4 | Enable-to-clock setup and hold (per corner, per slew/load) | Liberty `timing()` | @@ | STA `report_clock_gating_check` | |
| 5 | Minimum clock pulse width at the cell and at its output | Liberty `min_pulse_width` | @@ | STA `report_min_pulse_width` | |
| 6 | Test-enable pin behaviour: forces the output clock on while high? Needs to be stable for the whole session? | datasheet | @@ | gate-level sim of `tb_cw_icg.sv` against the cell | |
| 7 | Is the cell `DONT_USE` for synthesis inference (explicit instantiation required)? | PDK / flow config | @@ | netlist shows the instance, not an inferred latch | |
| 8 | Maximum fan-out / load of the gated net; need for CTS buffers behind the ICG | CTS report | @@ | CTS | |
| 9 | Clock-tree balancing: gated and ungated sinks balanced; ICG insertion delay in the skew budget | CTS | @@ | `report_clock_skew` post-CTS | |
| 10 | Enable launch: `clk_en_q` is a flop of the SAME clock with a short path to the ICG pin | physical | @@ | STA clock-gating setup slack at all corners | |
| 11 | SRAM macros behind a gated clock: do their datasheets allow the clock to stop? CE low sufficient? | macro datasheet | @@ per macro | set `SRAM_QUAL[e]` only after this | |
| 12 | Scan: ICG test enable connected to `cg_test_en_o` and covered by the DFT flow | DFT flow | @@ | DFT rule check, ATPG report | |
| 13 | Glitch-free behaviour confirmed at gate level (SDF) with the real cell | gate-level sim | @@ | `tb_cw_icg.sv` (edge integrity + equivalence) re-run on the netlist | |

Until rows 1-13 are answered, use the **clock-enable baseline** (`USE_ICG = 0`): engines take `clk_en_o` as a
synchronous `if (ce)` enable, every engine flop is written `if (ce) q <= d;`, nothing is gated, and the only
power effect is whatever the engines' own enable logic saves.
