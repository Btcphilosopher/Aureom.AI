## =============================================================================
## SilicaFlux Project 105 CLOCKWORKS -- functional-mode SDC TEMPLATE
## Top: sf_clock_power_ctrl (+ the engines behind clk_en_o / gclk_o)
## NOT RUN: no STA tool, library or netlist is available here.  Placeholders are @@...@@.
## Every period is a REQUIREMENT (an analysis target), never a measured or achieved result.
## =============================================================================
set sdc_version 2.1

## ---------------------------------------------------------------- clock
## ONE functional clock domain.  clk_i comes from the clock root (PLL / oscillator / P35 root gate);
## the PLL itself and its lock detection are integration boundaries, not part of this block.
create_clock -name clk_core -period @@CLK_PERIOD_NS@@ -waveform {0.000 @@CLK_HALF_NS@@} [get_ports clk_i]

## No create_generated_clock: nothing in this block divides, multiplies or muxes a clock.  The gated
## clocks gclk_o[*] are outputs of library ICG cells (see ICG_QUALIFICATION.md): the clock propagates
## THROUGH them and the tool infers the clock-gating setup/hold checks on their enable pins from the
## Liberty.  If a real clock generator (PLL output divider, clock mux) is ever added, it needs its own
## create_generated_clock with -source and -divide_by / -multiply_by.
set_propagated_clock [get_clocks clk_core]       ;# post-CTS; use ideal clocks pre-CTS
set_clock_uncertainty -setup @@SETUP_UNCERT_NS@@ [get_clocks clk_core]
set_clock_uncertainty -hold  @@HOLD_UNCERT_NS@@  [get_clocks clk_core]
set_clock_latency -source -early @@SRC_LAT_MIN_NS@@ [get_clocks clk_core]   ;# only if the root has a modelled latency
set_clock_latency -source -late  @@SRC_LAT_MAX_NS@@ [get_clocks clk_core]

## ---------------------------------------------------------------- mode (static case analysis)
## Functional mode: scan off, ICG test enable off.  The test SDC sets them to 1.
set_case_analysis 0 [get_ports scan_mode_i]
set_case_analysis 0 [get_ports icg_te_i]
set_case_analysis 0 [get_ports scan_en_i]

## ---------------------------------------------------------------- asynchronous single-bit pins
## por_ni, ext_rst_ni, test_rst_ni: only reach reset-synchroniser ASYNCHRONOUS pins (assert any time,
## release synchronised to clk_i).  pll_lock_i: only reaches the first stage of a 2-flop synchroniser.
## Justification is structural (every path from these ports ends in sf_reset_sync / sf_sync2 first
## stages) and must be confirmed by the CDC / RDC tool.  The release is timed as recovery / removal.
set_false_path -from [get_ports {por_ni ext_rst_ni test_rst_ni pll_lock_i}]

## ---------------------------------------------------------------- reset synchronisers
## The synchroniser first stage flops: keep them together and never retime / duplicate them.
set_dont_touch [get_cells -hier *u_rs*/r1_reg*]
set_dont_touch [get_cells -hier *u_pll_sync*]
## Recovery / removal of every engine reset synchroniser output is timed against clk_i by default
## (NOT false-pathed): this is the check that the reset really releases synchronously.

## ---------------------------------------------------------------- clock gating
## ICG enable pins: the enable is a FLOP in clk_i (sf_clock_enable_ctrl clk_en_q), launched at the rising
## edge and captured by the ICG latch while the clock is low.  Let the tool infer the clock-gating check
## from the cell's Liberty (clock_gating_integrated_cell).  Report it explicitly:
##   report_clock_gating_check -all  (PrimeTime: report_clock_gating_check ; OpenSTA: report_checks -path_group {**clock_gating_default**})
## If the library cell has no clock_gating_integrated_cell attribute, set the checks by hand:
# set_clock_gating_check -setup @@ICG_SETUP_NS@@ -hold @@ICG_HOLD_NS@@ [get_cells -hier *g_icg*u_cg*]

## ---------------------------------------------------------------- IO budgets (engine interface, same clock)
## Engine status inputs (eng_*, up_stalled_i, in_offered_i, fabric_ack_i, *_cnt_i) come from engines that run on clk_i.
set eng_in  [get_ports {eng_* up_stalled_i in_offered_i fabric_ack_i issue_cnt_i* retire_cnt_i* reg_*_i* clk_ok_i}]
set_input_delay  -max @@IN_MAX_NS@@ -clock clk_core $eng_in
set_input_delay  -min @@IN_MIN_NS@@ -clock clk_core $eng_in
set eng_out [get_ports {clk_en_o* accept_en_o* quiesce_req_o* cancel_o* save_req_o* restore_req_o* fabric_connect_o* reg_rdata_o* reg_ready_o reg_err_o irq_o eng_state_o*}]
set_output_delay -max @@OUT_MAX_NS@@ -clock clk_core $eng_out
set_output_delay -min @@OUT_MIN_NS@@ -clock clk_core $eng_out
## eng_rst_no[*] leave the sequencer as reset-synchroniser outputs: constrain them as clk_core outputs
## and let the ENGINE's recovery / removal checks be done in the engine's own timing context.
set_output_delay -max @@RST_OUT_MAX_NS@@ -clock clk_core [get_ports eng_rst_no*]
set_output_delay -min @@RST_OUT_MIN_NS@@ -clock clk_core [get_ports eng_rst_no*]

## ---------------------------------------------------------------- DFT / test controls (quasi-static)
## test-mode controls are static during a functional session; they are timed in the test SDC.
set_false_path -from [get_ports {scan_mode_i scan_en_i icg_te_i mem_inhibit_i test_permit_i}]
set_false_path -from [get_ports tc_mode_i*] -to [get_ports {cg_test_en_o scan_en_o mem_inhibit_o*}]

## ---------------------------------------------------------------- multi-corner note
## Run setup at the slowest corner and hold at the fastest, plus the clock-gating checks at both.
## Every period above must close in EVERY corner; a single-corner run is not signoff.
