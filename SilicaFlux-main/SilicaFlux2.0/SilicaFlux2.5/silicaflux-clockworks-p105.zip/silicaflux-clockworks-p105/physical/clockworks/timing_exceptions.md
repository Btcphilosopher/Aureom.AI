# Timing exception documentation

Every exception in `clockworks_func.sdc` / `clockworks_test.sdc`, why it is legal, and how that is verified.
An exception without a verification line is a defect. **None of these checks has been run on a netlist**
(no tool or library available); the "how verified" column says what the integrator must run.

| # | Exception | Where | Why it is legal | How it is verified | Status |
|---|---|---|---|---|---|
| X1 | `set_false_path -from {por_ni ext_rst_ni test_rst_ni pll_lock_i}` | func + test SDC | These four single-bit pins reach only (a) the asynchronous pin of `sf_reset_sync` flops, or (b) the first flop of a 2-flop synchroniser (`sf_sync2`). No other path exists. The reset RELEASE is still timed as recovery/removal. | structural CDC / RDC tool: rule "async port reaches only synchroniser first stages"; `report_exceptions`; recovery/removal slack on `eng_rst_no` synchroniser outputs | not run |
| X2 | `set_false_path -from {scan_mode_i scan_en_i icg_te_i mem_inhibit_i test_permit_i}` (func) | func SDC | Static during a functional session (case analysis 0 for the first three; DFTGrid derives the others from lifecycle + pins). They are timed in the test SDC. | case-analysis report must show them constant; test SDC run | not run |
| X3 | `set_false_path -from tc_mode_i* -to {cg_test_en_o scan_en_o mem_inhibit_o*}` | func SDC | `tc_mode_i` is a TestCore level that changes only between sessions; the listed outputs are test controls. | test-mode timing run | not run |
| X4 | `set_case_analysis` on `scan_mode_i`, `icg_te_i`, `scan_en_i`, `test_permit_i` | func/test SDC | Mode selection. | the two SDCs are run as separate scenarios (MCMM) | not run |
| X5 | `set_dont_touch` on reset-synchroniser and PLL-lock synchroniser first stages | func SDC | prevents synthesis from retiming / merging / duplicating the metastability-containing stage | netlist inspection; synchroniser cells identified by the CDC tool | not run |
| X6 | no `set_clock_groups`, no `create_generated_clock` | func SDC | one functional clock domain; the ICGs propagate the clock | `report_clock_properties`: exactly one clock `clk_core`, gated copies shown as clock network through ICG cells | not run |
| X7 | clock-gating check from the ICG cell's Liberty (no manual exception) | func SDC | the enable (`clk_en_q`) is launched by a flop on the same clock and captured by the ICG latch in the low phase; this is the intended, checkable path | `report_clock_gating_check` at all corners; if the library cell lacks `clock_gating_integrated_cell`, set `set_clock_gating_check` by hand from the datasheet | not run |

## What deliberately has NO exception

* **Multi-bit values** - there is no multi-bit asynchronous crossing in this block. Nothing needs a
  `set_max_delay -datapath_only`, and none is provided. If a second clock domain is ever added, multi-bit
  values cross through a handshake or FIFO (reuse P35 `sf_crt_handshake` / `sf_crt_async_fifo`), never a
  bare synchroniser, and the SDC then needs the bounded-delay pattern of P35's `05_SDC.md`.
* **Reset assertion paths** - the controller never decodes a reset: every engine reset is one flop (`req_q`)
  feeding a reset synchroniser (rule R1 of `sf_reset_sequencer`). No path is false-pathed because it "looks
  like a reset".
* **Clock-enable flops** - `clk_en_q -> ICG.E` is a normal synchronous path, timed.

## When the design gains a second clock

Re-derive this file: add `create_clock` for the new clock, `set_max_delay -ignore_clock_latency` bounds in both
directions (P35 pattern, because `set_clock_groups -asynchronous` can cancel a `set_max_delay` in some tools,
P35 finding F-05), hold false paths for the unrelated-phase crossings, and extend the CDC manifest.
