## =============================================================================
## SilicaFlux Project 105 CLOCKWORKS -- test-mode SDC TEMPLATE  (NOT RUN)
## Mode: scan shift and capture; ICGs forced open (cg_test_en_o); resets under test control.
## This constrains the CONTROL signals this block provides; scan insertion, scan chains and ATPG
## constraints belong to the DFT flow (docs/clockworks/07_DFT_INTERFACES.md) and are not provided here.
## =============================================================================
set sdc_version 2.1
create_clock -name clk_core -period @@TEST_CLK_PERIOD_NS@@ [get_ports clk_i]
set_propagated_clock [get_clocks clk_core]

set_case_analysis 1 [get_ports scan_mode_i]
set_case_analysis 1 [get_ports test_permit_i]
## ICG test enable: static 1 for the whole session (TE_FOLLOWS_SCAN_EN = 0) ...
set_case_analysis 1 [get_ports icg_te_i]
## ... or follows scan_en when the ATPG needs the enable logic exercised (TE_FOLLOWS_SCAN_EN = 1):
# remove the icg_te_i case analysis above and keep scan_en_i as a timed input:
# set_input_delay -max @@SCAN_EN_MAX_NS@@ -clock clk_core [get_ports scan_en_i]

## scan_en is a high-fanout static-per-phase net: treat its transitions as asynchronous to capture
set_false_path -from [get_ports scan_en_i]

## test_rst_ni drives every reset synchroniser DIRECTLY in scan mode (sf_reset_sync test bypass)
## -> it is a data-like control for the scan flops; constrain it like a scan-controlled reset
set_input_delay -max @@TEST_RST_MAX_NS@@ -clock clk_core [get_ports test_rst_ni]
set_input_delay -min @@TEST_RST_MIN_NS@@ -clock clk_core [get_ports test_rst_ni]
## por_ni / ext_rst_ni are not used in scan mode (the reset source is muxed to test_rst_ni)
set_false_path -from [get_ports {por_ni ext_rst_ni pll_lock_i}]

## ICG test-enable path: te -> ICG SE pin; checked by the clock-gating check at the SE pin
## (library-dependent). The enable path (clk_en_q -> E pin) is not exercised by capture: see
## docs/clockworks/07_DFT_INTERFACES.md section 4.
