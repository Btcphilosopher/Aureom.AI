# Verification report

Everything in this document was produced by commands in this repository
(`make test`, `make mutants`, `tools/final_regression.sh`); logs are in `results/`.
All simulation used **Verilator 5.020**.  No result below comes from Icarus
Verilog, a formal tool or a synthesis tool.

## 1. Strategy

| layer | what | against |
|---|---|---|
| L0 spec soundness | `OracleSim` (each thread alone) vs `SimtSim` (reconvergence stack) on random legal programs | each other |
| L1 unit | arbiters, divergence/stack-update unit | independent behavioural models, Python vectors |
| L2 directed | 45 directed tests (341 runs) over RTL configurations x downstream timing profiles | `SimtSim` + explicit micro-architectural expectations |
| L3 random | structured, race-free kernels with divergence, loops, early exits, barriers, shared memory | `SimtSim` (and `OracleSim`) |
| L4 assertions | 49 assertion sites (39 distinct checks) always on inside the RTL (`rtl/sfx_simt_checks.svh`) | the design's own invariants |
| L5 hostile downstream | spurious completions / fetch responses | refusal + unchanged state |
| L6 mutation | 32 injected bugs | does L1-L5 notice? |

### What "compare architectural state" means

For every run `tools/sfx_run.py` compares RTL and reference on

* the **per-warp issue trace**: the sequence of `(pc, active mask)` of every
  instruction that executed, for every warp of every workgroup (this exposes
  divergence/reconvergence order, not just final values);
* **final registers** of every thread (dumped when its warp retires);
* **final global memory** (all non-zero words);
* the **fault record** (code, workgroup, warp, pc) and which workgroups aborted;
* counters tied to architecture: issued instructions, divergent branches,
  barrier episodes, stack high-water mark;
* counter **invariants** (`cycles == issued + idle`, idle causes sum to idle,
  warp-cycle buckets partition the resident warps, `issued == retired`,
  `proto_err == 0`, per-warp counters sum to `issued`).

Timing is *not* compared (the reference has no clock); instead every program runs
under several downstream timing profiles and must produce identical architectural
state under all of them.

### Reference simulators

* `SimtSim` (`tools/sfx_ref.py`) is the executable form of
  `docs/divergence_model.md`.  `resolve_branch()` is the single definition of
  branch resolution and also generates the unit-test vectors for the RTL unit.
* `OracleSim` executes every thread independently with plain sequential
  semantics; threads of a workgroup meet only at `BAR`.  It shares no divergence
  code with `SimtSim`.  The random-program runner checks `OracleSim == SimtSim`
  before it trusts `SimtSim` as the reference for a program.
* Sanity of the fuzzer itself: three deliberately wrong stack models
  (drop the join entry / do not narrow the mask / wrong merge condition) are
  detected on 32/40, 35/40 and 21/40 programs respectively.

### Random legal programs (`tools/sfx_gen.py`)

Legal by construction: single `EXIT`; every branch is emitted with `auto`
reconvergence and completed by the post-dominator pass (`tools/sfx_cfg.py`) the
way a compiler would, *including* loop breaks and early exits; barriers only in
converged code (top level, uniform loops, workgroup-uniform `if`s) and never
after a data-dependent early exit; loops terminate; **race free** - global stores
go to thread-private slots, loads read read-only inputs or the thread's own
slots, shared memory is used in write phases (own slot) and read phases (any
slot) separated by barriers.  Constructs: `if/else`, `if`, data-dependent
`while` (0-7 iterations), `do-while`, `break`, divergent early exit to the
exit block, uniform branches, barrier phases in loops, warp-granular early
exit, partial warps, 1-4 workgroups, launch gaps.

## 2. Defects found by the verification effort (honest list)

**Design defects (RTL)**

1. **Starvation hole in both scheduling policies** (found late, by analysis,
   then confirmed with a directed test).  Candidate sets are gated by backend
   readiness.  With one round-robin pointer, grants to *other* classes move the
   pointer while a ready warp is out of the candidate set; a same-class sibling
   then wins every time the class becomes ready again.  Reproduced
   deterministically with `fairness_class_gating_no_starvation`: with a 6-cycle
   MEM busy window the earlier RTL issued **all 60 MEM instructions of warp 0
   before warp 1 issued any**; the age policy's guard failed the same test with a
   40-cycle window (warp 0: 40 MEM slots, warp 1: 2).  The random regression, the
   arbiter unit test of that time and assertion C1 had all missed it: C1 reset
   its counter whenever candidacy lapsed, and the unit test had no
   feedback from grants to candidacy.  Fix: round-robin per execution class plus
   round-robin across classes (`sfx_class_rr_arb`); age-guard counters count only
   cycles in which the warp was a candidate; C1 and the unit test redefined
   (candidate-cycle lag, feedback-driven stimulus).  Both fixes are protected by
   mutants (`rr_class_pointers_advance_on_any_grant`,
   `age_counts_class_busy_cycles`).
2. Structural (found by Verilator while building, not by simulation): two
   false combinational loops (`hazard`, `bar_mismatch`) caused by
   decoding and consuming in one `always_comb`; the barrier unit needed separate
   "arrival requested" and "arrival committed" inputs to avoid a real loop in
   strict mode.

**Test-bench / test defects (not design bugs, listed because they cost time and
show where the checks were blind)**

* Verilator does not re-evaluate combinational logic for variables written by
  `$fscanf`: the divergence unit appeared to fail on every vector until inputs
  were copied with ordinary assignments.
* An `initial`-block process observes values *after* the DUT's non-blocking
  updates whereas clocked `always` blocks observe pre-edge values; the launch
  handshake sampled `launch_ready` one edge too late and hung.  The launch
  driver is now a clocked block.
* Several test programs were wrong: memory offsets beyond +-1023; two write-write
  races (found only because multiple timing profiles disagreed with the
  sequential reference); a nested-divergence test whose join labels coincided
  (so the merge optimisation correctly used 1 entry, not 2); stall expectations
  that only hold when ALU latency exceeds fetch latency.
* A thread-safety hazard in the harness itself: concurrent rebuilds of one
  simulator directory could have produced spurious mutation "kills"; the build
  step is now locked and the mutation run was restarted from scratch.

## 3. Results

All numbers below are from running the **unzipped deliverable** in a clean
directory (`tools/final_regression.sh 500 1500`, `tools/mutate.py`); logs are in `results/`.

### 3.1 Lint
Verilator `-Wall` is clean for five parameter sets (default; age policy; 8 lanes x 4 warps
x 2 workgroups; strict barrier PC with `STACK_DEPTH=6` and 3 workgroups; 16 warps x 16 lanes with
`STARVE_LIMIT=32`).

### 3.2 Specification soundness: oracle vs stack model (pure Python)
3000 random programs (1500 seeds x {8, 32} lanes): **2998 agree on registers, memory and barrier
episode count**, 2 skipped (the generator nested deeper than `STACK_DEPTH`; a defined overflow
fault), 0 mismatches.  762,235 divergent branches executed, 31,455 barrier episodes.
Peak stack depth per program: `{0: 402, 1: 78, 2: 290, 3: 711, 4: 806, 5: 499, 6: 173, 7: 27, 8: 12}`.

### 3.3 Unit tests
* Arbiters, 9 geometries (class-RR N=2/4/8/16, age N=2/4/8/16 with `STARVE_LIMIT` 2..32), 75k-158k grants each against
  independent models with grant-driven candidate feedback: all pass; the observed worst-case lags
  reach the theoretical bounds (age: 22/24, 7/8, 46/48, 14/16, 2/4; class-RR 18/31, 9/15, 41/63, 5/7).
* Divergence unit vs `resolve_branch()`: 4 configurations x 40 000 vectors (LANES 32/8/16/32,
  `STACK_DEPTH` 8/4/6/2; ~40 000 faults, ~18 000 pops, ~40 000 divergences, ~10 000 merge/elision cases in total): 0 mismatches.

### 3.4 Directed tests: 45 tests, 341 runs, 0 failing

| directed test | configs | timing profiles | what it checks |
|---|---|---|---|
| `nop_exit` | rr32, age32 | 0,1,2,3 | smallest legal kernel |
| `alu_dependency_chain` | rr32, age32 | 1,2 | RAW chain on a single warp shows dependency stalls (visible once ALU latency exceeds fetch latency) |
| `waw_ordering` | rr32, age32 | 0,1,2,3 | back-to-back writes of one register: out-of-order completion must not reorder them |
| `memory_raw_in_order` | rr32, age32 | 1,2,3 | store->load to one address must be ordered; load use stalls on memory |
| `inflight_credit_cap` | rr32, age32 | 1,2,3 | 24 back-to-back stores exceed MAX_INFLIGHT=15: credit stalls, no loss |
| `diverge_if_else` | rr32, age32 | 0,1,2,3 | one divergent branch per warp: join + not-taken entry, reconverges at the join |
| `diverge_if_only` | rr32, age32 | 0,1,2,3 | taken target == reconvergence PC: empty-path elision, a single join entry |
| `uniform_branch_no_push` | rr32, age32 | 0,1,2,3 | branch outcome uniform across the warp: no stack traffic |
| `nested_4_levels_at_limit` | rr32, age32 | 0,1,2,3 | 4 nested divergent levels use exactly 8 = STACK_DEPTH entries |
| `nested_5_levels_overflow` | rr32, age32 | 0,1,2,3 | the 5th nested level needs 10 entries: precise overflow fault, workgroup aborted, kernel completes |
| `nested_4_plus_single_entry_overflow` | rr32, age32 | 0,1,2,3 | full stack (8) + a region that needs exactly ONE more entry: boundary at STACK_DEPTH+1 must fault |
| `nested_depth4_config` | d4 | 0,1,2,3 | STACK_DEPTH=4 build: 2 levels fit |
| `nested_depth4_overflow` | d4 | 0,1,2,3 | STACK_DEPTH=4 build: the 3rd level overflows |
| `loop_divergent_exit_constant_stack` | rr32, age32 | 0,1,2,3 | lanes leave a loop at different iterations: stack depth stays 1 however many iterations run |
| `do_while_divergent_latch` | rr32, age32 | 0,1,2,3 | backward conditional branch whose fall-through is the reconvergence point |
| `early_exit_merge` | rr32, age32 | 0,1,2,3 | 4 early-exit branches to the single exit block share one reconvergence PC: merge keeps depth 1 |
| `loop_break_nested_if` | rr32, age32 | 0,1,2,3 | if inside loop with a break: nested reconvergence points inside one loop region |
| `partial_warp_diverge` | rr32, age32 | 0,1,2,3 | partial last warp: lanes beyond the launch size never become active |
| `barrier_basic` | rr32, age32 | 0,1,2,3 | all warps of a workgroup meet at one barrier; neighbour data visible after it |
| `barrier_partial_warp` | rr32, age32 | 0,1,2,3 | a partial warp (fewer lanes than WARP_SIZE) counts as one participant |
| `barrier_back_to_back` | rr32, age32 | 0,1,2,3 | consecutive barriers: no warp may slip into the next episode early |
| `barrier_repeated_loop` | rr32, age32 | 0,1,2,3 | barriers inside a uniform loop: 2 episodes x 5 iterations |
| `barrier_many_workgroups_recycle` | rr32, age32, rr8 | 0,1,2,3 | more workgroups than slots: warp slots recycled; barriers of different workgroups stay isolated |
| `barrier_exited_warps_do_not_participate` | rr32, age32, rr8, age8 | 0,1,2,3 | warps that EXIT before any barrier are not counted as participants |
| `barrier_released_by_late_exit` | rr32, age32, rr8 | 0,1,2 | warps 0/1 wait at the barrier while warps 2/3 are still busy; their EXIT completes the episode |
| `barrier_after_divergence_reconverges` | rr32, age32 | 0,1,2,3 | a barrier AFTER the divergent region has reconverged is legal |
| `barrier_in_workgroup_uniform_if` | rr32, age32 | 0,1,2,3 | a barrier under a workgroup-uniform branch: only workgroup 1 arrives |
| `divergent_barrier_fault` | rr32, age32 | 0,1,2,3 | BAR executed while the warp is diverged: FLT_DIV_BARRIER, workgroup 0 aborted, workgroup 1 unaffected |
| `divergent_barrier_fault_multiwarp` | rr32, age32 | 0,1,2,3 | same, several warps fault; the whole workgroup is aborted without deadlock |
| `divergent_exit_fault` | rr32, age32 | 0,1,2,3 | EXIT while diverged (program violates the single-exit contract): FLT_DIV_EXIT |
| `illegal_instruction_fault` | rr32, age32 | 0,1,2,3 | undefined opcode |
| `fetch_fault_fall_off_end` | rr32, age32 | 0,1,2,3 | no EXIT: the fetch past the program end errors |
| `jump_out_of_range_fault` | rr32, age32 | 0,1,2,3 | jump target below 0 |
| `launch_zero_threads` | rr32, age32 | 0,1,2,3 | invalid launch (0 threads) is consumed, faulted, and does not hang kernel completion |
| `launch_too_many_threads` | rr32, age32 | 0,1,2,3 | invalid launch (more threads than warp slots) |
| `strict_barrier_pc_mismatch_fault` | strict32 | 0,1,2,3 | STRICT_BAR_PC=1: two different BAR instructions in one episode -> FLT_BAR_PC |
| `lenient_barrier_pc_pairing` | rr32, age32 | 0,1,2,3 | default mode: arrivals at different BAR instructions are one episode (counted by warps, not by pc) |
| `resource_recycle_12_workgroups` | rr32, age32, rr8, age8 | 0,1,2,3 | 12 workgroups through 4 workgroup slots: allocation is all-or-nothing, slots are reused, kernel_done after the last |
| `kernel_done_waits_for_stores` | rr32, age32 | 2,3 | kernel_done only after every store has committed |
| `two_kernels_back_to_back` | rr32, age32 | 0,1,2,3 | kernel_clear returns the unit to idle with cleared status/counters; a second kernel runs identically |
| `fairness_identical_warps` | rr32, age32 | 0,1 | eight identical warps: each issues exactly the same number of instructions |
| `hostile_downstream_spurious_completions_and_fetches` | rr32, age32 | 0,1,2 | backend/imem inject completions and fetch responses for contexts with nothing outstanding: they are refused (proto_err counted) and architectural state is unaffected |
| `hostile_downstream_barriers_loops` | rr32, age32 | 1,2 | same hostile downstream with barrier episodes and memory traffic in flight |
| `fairness_class_gating_no_starvation` | rr32, age32 | 4,5 | MEM class busy for a fixed window after every accept while ALU warps keep the issue slot busy: two MEM warps must share the MEM slots (class-gated candidacy must not let the pointer skip a ready warp) |
| `hostile_downstream_out_of_mask_branch_outcomes` | rr32, age32 | 0,1,2 | branches issued with a PARTIAL mask (nested divergence + partial warp) get outcomes that also name lanes outside the issued mask: the control unit must intersect with the active mask (BC7 is not trusted) |

### 3.5 Random legal programs vs the reference: 1,998 programs, 0 failing (2 skipped as over-nested)

Each program runs on the RTL under a random downstream timing profile and launch pattern and is
compared (trace, registers, memory, counters) with `SimtSim`, after `SimtSim == OracleSim` was checked.

| config | passed | warp-instructions | divergent branches | barrier episodes | max stack | max arbitration lag |
|---|---|---|---|---|---|---|
| `rr32` | 499/500 | 2,341,218 | 227,890 | 6,076 | 8 | 14 |
| `age32` | 499/500 | 2,341,218 | 227,890 | 6,076 | 8 | 20 |
| `rr8` | 500/500 | 1,359,185 | 87,991 | 6,638 | 7 | 6 |
| `age8` | 500/500 | 3,425,597 | 223,658 | 6,960 | 7 | 37 |
| **total** | **1,998** | **9,467,218** | **767,429** | **25,750** | | |

`rr32/age32`: 8 warps x 32 lanes, 4 workgroup slots; `rr8`: 4 warps x 8 lanes, 2 slots;
`age8`: 16 warps x 8 lanes, 8 slots, `STARVE_LIMIT=24`.  The assertions of `rtl/sfx_simt_checks.svh` were active in
every one of these simulations.

### 3.6 Mutation testing: 32/32 killed

16 by RTL assertions, 5 by the reference comparison,
11 by unit tests (the harness runs unit tests first; the second table repeats those
11 mutants with unit tests disabled).  Every mutant is a single, plausible design bug.

| mutant | cfg | injected bug | killed first by | checker |
|---|---|---|---|---|
| `sb_ignore_waw` | rr32 | WAW hazard not detected: two writes of one register may complete out of order | directed:waw_ordering | RTL-assertion |
| `sb_ignore_rs2` | rr32 | RAW hazard on the second source operand not detected | directed:memory_raw_in_order | reference-compare |
| `sb_clear_wrong_bit` | rr32 | completion clears the wrong scoreboard bit | directed:waw_ordering | RTL-assertion |
| `branch_predicate_hazard_ignored` | rr32 | a branch issues before its predicate register is written | directed:diverge_if_else | reference-compare |
| `stall_attr_swap_mem_dep` | rr32 | memory and dependency stalls attributed to each other | directed:alu_dependency_chain | reference-compare |
| `div_no_merge` | rr32 | merge optimisation removed: loops with divergent exits grow the stack | unit:diverge-vectors | unit-test |
| `div_no_empty_elision` | rr32 | empty-path elision removed: entries with pc == rpc are pushed | unit:diverge-vectors | unit-test |
| `div_taken_not_masked` | rr32 | taken mask not intersected with the active mask: inactive lanes wake up | unit:diverge-vectors | unit-test |
| `div_nt_mask_wrong` | rr32 | not-taken stack entry stores the taken lanes | unit:diverge-vectors | unit-test |
| `div_no_pop_on_uniform_nt` | rr32 | uniform not-taken branch landing on the reconvergence PC does not pop | unit:diverge-vectors | unit-test |
| `div_overflow_off_by_one` | rr32 | overflow detected one entry too late (writes beyond the stack) | unit:diverge-vectors | unit-test |
| `ctrl_no_pop_after_seq` | rr32 | sequential/JMP flow reaching the reconvergence PC does not pop the stack | directed:diverge_if_else | RTL-assertion |
| `bar_premature_release` | rr32 | barrier releases when ONE live warp is still missing | directed:barrier_basic | RTL-assertion |
| `bar_exit_not_removed` | rr32 | exited warps keep counting as participants (barrier never completes) | directed:memory_raw_in_order | RTL-assertion |
| `bar_arrived_not_cleared` | rr32 | arrival mask survives the release: the next episode releases immediately | directed:barrier_basic | RTL-assertion |
| `bar_no_memory_drain` | rr32 | BAR does not wait for outstanding stores: data not visible after the barrier | directed:barrier_basic | RTL-assertion |
| `bar_divergent_not_detected` | rr32 | a divergent BAR is accepted instead of faulting | directed:divergent_barrier_fault | RTL-assertion |
| `bar_strict_pc_inverted` | strict32 | strict-PC check inverted | directed:strict_barrier_pc_mismatch_fault | reference-compare |
| `bar_live_mask_partial_warp_lost` | rr32 | the lowest member warp is not a participant (premature release / lost warp) | directed:barrier_basic | RTL-assertion |
| `exit_no_drain` | rr32 | EXIT retires a warp that still has instructions in flight | directed:alu_dependency_chain | RTL-assertion |
| `duplicate_issue` | rr32 | warp stays READY after issuing: the same instruction issues again | directed:nop_exit | RTL-assertion |
| `retire_inactive_context` | rr32 | completions for a context with nothing in flight are accepted | directed:hostile_downstream_barriers_loops | RTL-assertion |
| `inflight_never_decrements` | rr32 | in-flight counter leaks: EXIT can never issue | directed:alu_dependency_chain | RTL-assertion |
| `partial_warp_mask_ignored` | rr32 | launch mask of a partial warp is all ones: phantom threads execute | directed:nop_exit | reference-compare |
| `abort_does_not_kill_siblings` | rr32 | a fault does not abort the other warps of the workgroup | directed:divergent_barrier_fault_multiwarp | RTL-assertion |
| `drain_ignores_inflight` | rr32 | an aborted slot is freed while completions are still in flight | directed:divergent_barrier_fault_multiwarp | RTL-assertion |
| `kernel_done_early` | rr32 | kernel_done asserts as soon as the last workgroup is launched | directed:nop_exit | RTL-assertion |
| `rr_pointer_sticks` | rr32 | round-robin pointer does not advance past the granted slot (greedy, starves others) | unit:arbiter | unit-test |
| `rr_class_pointers_advance_on_any_grant` | rr32 | per-class pointers move on every grant (single-pointer behaviour): a ready warp is skipped while its class is busy | unit:arbiter | unit-test |
| `age_counts_class_busy_cycles` | age32 | starvation counter also counts cycles in which the warp's class is busy: an older sibling re-becomes urgent between grants | unit:arbiter | unit-test |
| `age_guard_disabled` | age32 | starvation guard disabled: pure oldest-first | unit:arbiter | unit-test |
| `age_matrix_inverted` | age32 | a newly allocated slot is recorded as older than existing slots | unit:arbiter | unit-test |

System tests only (unit tests disabled) for the mutants above that were killed by a unit test first:
**11/11 killed.**

| mutant | killed by (system tests only, unit tests disabled) | checker |
|---|---|---|
| `div_no_merge` | directed:loop_divergent_exit_constant_stack | RTL-assertion |
| `div_no_empty_elision` | directed:diverge_if_only | reference-compare |
| `div_taken_not_masked` | directed:hostile_downstream_out_of_mask_branch_outcomes | RTL-assertion |
| `div_nt_mask_wrong` | directed:diverge_if_else | reference-compare |
| `div_no_pop_on_uniform_nt` | directed:do_while_divergent_latch | RTL-assertion |
| `div_overflow_off_by_one` | directed:nested_4_plus_single_entry_overflow | RTL-assertion |
| `rr_pointer_sticks` | directed:fairness_class_gating_no_starvation | RTL-assertion |
| `rr_class_pointers_advance_on_any_grant` | random:seed7035 | RTL-assertion |
| `age_counts_class_busy_cycles` | random:seed7008 | RTL-assertion |
| `age_guard_disabled` | directed:resource_recycle_12_workgroups | RTL-assertion |
| `age_matrix_inverted` | directed:uniform_branch_no_push | RTL-assertion |

A first version of this second pass left `div_taken_not_masked` alive: the backend model never returned
lanes outside the issued mask, so the control unit's defensive intersection could not be observed.  The
fix was a verification fix, not a design fix: contract item BC7 plus a hostile mode that injects out-of-mask lanes and a
test that issues branches with a partial mask.

## 4. What this verification does not show

* **No formal proof, no synthesis, no timing/area/power.**  Liveness is argued (`architecture.md` section 10) and checked as
  bounded-wait / bounded-progress assertions under assumptions the test-bench downstream satisfies by
  construction (and the assumption monitor enforces).  Yosys 0.33's open-source front end cannot parse this
  RTL, so there is no synthesis result; Icarus Verilog was not used.
* **No structural coverage metric** (line / toggle / FSM) was measured; the mutation score and the
  directed tests that target each mechanism are the evidence of coverage.
* The reference models, the RTL and the backend model were written by the same author from the same
  specification.  `OracleSim` is independent of the stack mechanism, but the ISA's ALU/memory semantics are
  implemented once in Python and once (separately) in the SystemVerilog backend model, so a shared misreading of the
  ISA text would pass.
* Configurations exercised: warps 4/8/16, lanes 8/16/32, workgroup slots 2/4/8, `STACK_DEPTH` 4/6/8 (unit level
  2/4/6/8), both policies, strict barrier PC.  Other parameter values are linted, not simulated.
* The generator never produces faulting programs, deadlocks or racy programs; faults are covered by directed
  tests (one faulting workgroup per test, so the fault record is deterministic).
* The age policy guarantees a bounded wait (`STARVE_LIMIT + NUM_WARPS` grants), **not** an equal share: against an
  always-ready older warp of the same class a younger warp gets about 1 slot in `STARVE_LIMIT+1`.
* Spurious completions are refused only when they target a warp with nothing in flight (the control unit cannot
  distinguish a bogus completion for a warp that does have work in flight; that would need transaction tags).

## 5. Directory of evidence

`results/lint.log`, `unit.log`, `models.log`, `directed.log`, `random.log`, `mutation.log`,
`mutation_system_only.log`, `test_tables.md` (generated test and mutant descriptions),
`worked_example.txt` (the divergence example of `divergence_model.md`).

## 6. Reproduce


```bash
make test N=200          # ~10 min on 4 cores: lint, unit, models, directed, random
make mutants             # ~10 min
tools/final_regression.sh 500 1500    # writes results/*.log
```
