#!/usr/bin/env python3
"""Regression driver.

  run_tests.py --directed                 directed tests (all configs x timing profiles)
  run_tests.py --random 200               200 random legal programs per RTL config
  run_tests.py --directed --random 100    both
  run_tests.py --repro rr32 1234          re-run one random case verbosely (keeps files)

Exit status is non-zero if anything fails.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import os
import random
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "tests"))

from sfx_isa import assemble, AsmError, FAULT_STACK_OVF
from sfx_cfg import lint_program, CfgError
from sfx_gen import gen_program, make_init_mem
from sfx_ref import OracleSim, SimtSim, compare_results, SimError
from sfx_run import RtlConfig, run_case, run_rtl, compare, ROOT
import directed

CONFIGS = {
    "rr32":     RtlConfig("rr32"),
    "age32":    RtlConfig("age32", sched_policy=1),
    "rr8":      RtlConfig("rr8", num_warps=4, num_wgs=2, warp_size=8),
    "age8":     RtlConfig("age8", num_warps=16, num_wgs=8, warp_size=8, sched_policy=1, starve_limit=24),
    "strict32": RtlConfig("strict32", strict_bar_pc=1),
    "d4":       RtlConfig("d4", stack_depth=4),
}
RANDOM_CFGS = ["rr32", "age32", "rr8", "age8"]


def build_all(names):
    t = time.time()
    with cf.ThreadPoolExecutor(max_workers=min(4, len(names))) as ex:
        list(ex.map(lambda n: CONFIGS[n].build(), names))
    print(f"[build] {len(names)} RTL configs ready in {time.time() - t:.0f}s")


# ------------------------------------------------------------------ directed
def run_directed_one(t, cfgname, prof, seed):
    cfg = CONFIGS[cfgname]
    lanes = cfg.warp_size
    try:
        prog = assemble(directed._asm(t, lanes))
    except (AsmError, CfgError) as e:
        return [f"assemble: {e}"]
    nth = directed._nth(t, lanes, cfg.num_warps)
    mem = make_init_mem(1234)
    errs, rtl, ref = run_case(cfg, prog.words, mem, nth, t.nwgs, prof, seed, t.launch_gap, t.reps,
                              fault_exact_warp=t.fault_exact_warp, check_counters=t.check_counters,
                              extra_args=t.extra_args, allow_proto=t.allow_proto)
    if rtl.ok and t.check:
        rtl.cfg = cfg
        errs += t.check(rtl.cnt, rtl, ref, lanes)
    return errs


def run_directed(only=None, jobs=4):
    tests = [t for t in directed.all_tests() if (not only or any(o in t.name for o in only))]
    cfgs = sorted({c for t in tests for c in t.cfgs})
    build_all(cfgs)
    work = []
    for t in tests:
        for c in t.cfgs:
            for p in t.profiles:
                work.append((t, c, p))
    fails = []
    per_test = {}
    t0 = time.time()
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(run_directed_one, t, c, p, 11 + p): (t, c, p) for (t, c, p) in work}
        for fu in cf.as_completed(futs):
            t, c, p = futs[fu]
            try:
                errs = fu.result()
            except Exception:
                errs = ["exception: " + traceback.format_exc(limit=3)]
            per_test.setdefault(t.name, []).append((c, p, errs))
            if errs:
                fails.append((t.name, c, p, errs))
    for t in tests:
        runs = per_test.get(t.name, [])
        bad = [r for r in runs if r[2]]
        print(f"  [{'FAIL' if bad else ' ok '}] {t.name:46s} {len(runs) - len(bad)}/{len(runs)} runs")
    for (n, c, p, errs) in fails:
        print(f"    FAIL {n} cfg={c} profile={p}")
        for e in errs[:6]:
            print("       ", e)
    print(f"[directed] {len(tests)} tests, {len(work)} runs, {len(fails)} failing, {time.time() - t0:.0f}s")
    return len(fails) == 0


# ------------------------------------------------------------------ random
def random_case(cfgname, seed, keep=False):
    cfg = CONFIGS[cfgname]
    lanes = cfg.warp_size
    rng = random.Random(seed * 1000003 + lanes * 17 + cfg.num_warps)
    max_threads = cfg.num_warps * lanes
    nthreads = rng.choice([1, lanes - 1, lanes, lanes + 1, 2 * lanes, 3 * lanes + 3,
                           rng.randint(1, max_threads), max_threads, rng.randint(1, max_threads)])
    nthreads = max(1, min(nthreads, max_threads))
    nwgs = rng.randint(1, 4)
    prof = rng.choice([0, 1, 1, 2, 2, 3])
    gap = rng.choice([0, 0, 3, 20])
    kw = dict(max_div_depth=rng.choice([2, 3, 3, 4]), size=rng.randint(0, 2))
    src = gen_program(seed, lanes, nthreads, **kw)
    prog = assemble(src)
    problems = lint_program(prog)
    if problems:
        return ["generator produced an illegal program: " + "; ".join(problems)], src
    mem = make_init_mem(seed)
    refcfg = cfg.ref_cfg()
    ref = SimtSim(prog.words, refcfg, mem).run(nthreads, nwgs)
    if ref.faults:
        if all(f[2] == FAULT_STACK_OVF for f in ref.faults):
            return [], src, "skipped: generator nested deeper than STACK_DEPTH (defined overflow fault)", None
        return [f"reference faulted: {ref.faults}"], src
    orc = OracleSim(prog.words, refcfg, mem).run(nthreads, nwgs)
    e0 = compare_results(orc, ref)
    if e0:
        return ["ORACLE vs SIMT model: " + "; ".join(e0)], src
    rtl = run_rtl(cfg, prog.words, mem, nthreads, nwgs, prof, seed, gap, 1,
                  workdir=(os.path.join(ROOT, "build", f"repro_{cfgname}_{seed}") if keep else None), keep=keep)
    if not rtl.ok:
        return [f"RTL run failed rc={rtl.returncode}: " + " | ".join(rtl.stdout.strip().splitlines()[-4:])], src
    errs = compare(rtl, ref, cfg, mem)
    info = f"cfg={cfgname} seed={seed} nthreads={nthreads} nwgs={nwgs} profile={prof} gap={gap} " \
           f"issued={rtl.cnt.get('issued')} div={rtl.cnt.get('div_branches')} bar={rtl.cnt.get('bar_episodes')} " \
           f"hwm={rtl.cnt.get('stack_hwm')} cycles={rtl.cycles}"
    return errs, src, info, rtl


def run_random(n, seed0, cfgs, jobs=4):
    build_all(cfgs)
    work = [(c, s) for c in cfgs for s in range(seed0, seed0 + n)]
    fails = []
    skipped = 0
    stats = {c: dict(n=0, issued=0, div=0, bars=0, hwm=0, cyc=0, wait=0) for c in cfgs}
    t0 = time.time()

    def go(w):
        return random_case(*w)

    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(go, w): w for w in work}
        for fu in cf.as_completed(futs):
            c, s = futs[fu]
            try:
                r = fu.result()
            except Exception:
                fails.append((c, s, ["exception: " + traceback.format_exc(limit=4)]))
                continue
            errs = r[0]
            if errs:
                fails.append((c, s, errs))
            elif len(r) > 2 and r[3] is None:
                skipped += 1
            elif len(r) > 2:
                rtl = r[3]
                st = stats[c]
                st["n"] += 1
                st["issued"] += rtl.cnt["issued"]
                st["div"] += rtl.cnt["div_branches"]
                st["bars"] += rtl.cnt["bar_episodes"]
                st["hwm"] = max(st["hwm"], rtl.cnt["stack_hwm"])
                st["cyc"] += rtl.cycles
                st["wait"] = max(st["wait"], rtl.extra.get("chk_max_wait", 0))
    for c in cfgs:
        st = stats[c]
        print(f"  [{c:9s}] passed {st['n']:4d}/{n}  warp-instrs={st['issued']:8d}  divergent-branches={st['div']:7d}  "
              f"barrier-episodes={st['bars']:5d}  max-stack-hwm={st['hwm']}  max-arb-wait={st['wait']}")
    for (c, s, errs) in sorted(fails)[:10]:
        print(f"    FAIL cfg={c} seed={s}   (repro: tools/run_tests.py --repro {c} {s})")
        for e in errs[:5]:
            print("       ", e)
    print(f"[random] {len(work)} programs ({skipped} skipped as over-nested), {len(fails)} failing, {time.time() - t0:.0f}s")
    return len(fails) == 0


def repro(cfgname, seed):
    build_all([cfgname])
    r = random_case(cfgname, seed, keep=True)
    print(r[1])
    print("errors:", r[0] or "none")
    print("files kept in", os.path.join(ROOT, "build", f"repro_{cfgname}_{seed}"))
    return not r[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--directed", action="store_true")
    ap.add_argument("--only", nargs="*", help="substring filter for directed tests")
    ap.add_argument("--random", type=int, default=0, help="random programs per config")
    ap.add_argument("--seed0", type=int, default=1)
    ap.add_argument("--cfgs", default=",".join(RANDOM_CFGS))
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--repro", nargs=2, metavar=("CFG", "SEED"))
    a = ap.parse_args()
    ok = True
    if a.repro:
        sys.exit(0 if repro(a.repro[0], int(a.repro[1])) else 1)
    if a.directed:
        ok &= run_directed(a.only, a.jobs)
    if a.random:
        ok &= run_random(a.random, a.seed0, a.cfgs.split(","), a.jobs)
    print("RESULT:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
