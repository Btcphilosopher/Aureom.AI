#!/bin/bash
# Full regression with logs in results/ (the numbers quoted in docs/verification.md).
#   tools/final_regression.sh [RANDOM_PER_CONFIG] [MODEL_FUZZ_PER_LANE_CONFIG]
set -u
cd "$(dirname "$0")/.."
NRAND=${1:-500}
NMODEL=${2:-1500}
mkdir -p results
rc=0
run() { name=$1; shift; echo "=== $name"; "$@" > "results/$name.log" 2>&1; r=$?; tail -3 "results/$name.log"; [ $r -ne 0 ] && rc=1; return 0; }
run lint            make lint
run unit            python3 tools/run_unit.py
run models          python3 tools/fuzz_models.py --n "$NMODEL" --seed0 1000
run directed        python3 tools/run_tests.py --directed
run random          python3 tools/run_tests.py --random "$NRAND" --seed0 1000 --jobs 4
python3 tools/gen_test_tables.py > results/test_tables.md
echo "FINAL REGRESSION: $([ $rc -eq 0 ] && echo PASS || echo FAIL)"
exit $rc
