# SilicaFlux warp scheduler and SIMT control unit

SystemVerilog RTL, reference simulators, a randomised co-simulation test-bench,
directed tests, assertions and a mutation-testing harness for a SIMT control
unit: resident warp state, program counters, ready/blocked states, register
dependency tracking, execution masks, branch divergence and reconvergence
(stack based), workgroup barriers and kernel completion.

* One instruction fetched and one issued per cycle; `NUM_WARPS` resident warps
  in up to `NUM_WGS` workgroups; backend (operand read, ALUs, load/store) is
  *outside* the unit and described by a contract.
* Scheduling: deterministic **round-robin** (default; two-level, per execution
  class) and an optional **age-based** policy with a starvation guard.
* Counters: issued instructions, idle cycles (with a cause breakdown),
  dependency / memory / barrier stalls (slot level and warp-cycle level).
* Verification compares architectural state (per-warp issue trace, registers,
  memory, fault record, counters) with a bit-exact reference simulator, plus an
  independent per-thread oracle, under randomised downstream timing.

**Read first:** `docs/divergence_model.md` (the precise reconvergence model:
stack entries, overflow, nesting limits, compiler contract),
`docs/architecture.md` (micro-architecture, barriers, interfaces, fairness
assumptions, assertions), `docs/verification.md` (what was run, results, bugs
found, limits).  `docs/isa.md` is the instruction set.

## Layout

```
rtl/    sfx_simt_ctrl.sv        top: warp table, fetch, issue, launch, faults, kernel completion
        sfx_simt_pkg.sv         opcodes, state/fault codes, decode
        sfx_warp_sched.sv       policy select -> sfx_class_rr_arb | sfx_age_arb  (sfx_rr_arb is the building block)
        sfx_scoreboard.sv       RAW/WAW tracking          sfx_barrier_unit.sv   workgroup barriers
        sfx_diverge_unit.sv     branch resolution / stack push-pop (combinational)
        sfx_perf_counters.sv    counters                  sfx_simt_checks.svh   assertions (-DSFX_CHECKS)
tb/     tb_simt_top.sv          system test-bench (host, dumps)    sfx_be_model.sv   backend model
        sfx_imem_model.sv       instruction memory model           sfx_assume_monitor.sv  downstream-assumption checker
        tb_unit_arb.sv, tb_unit_diverge.sv   unit tests
tools/  sfx_isa.py sfx_asm.py sfx_cfg.py     ISA, assembler, post-dominator ("compiler") pass
        sfx_ref.py              OracleSim (per-thread) + SimtSim (stack model, bit-exact reference)
        sfx_gen.py              random legal, race-free kernel generator
        sfx_run.py run_tests.py run_unit.py fuzz_models.py gen_diverge_vectors.py mutate.py
tests/  directed.py             directed test definitions (programs + expectations)
build/  build_sim.sh lint.sh    Verilator build / lint scripts (outputs go to build/<config>/)
docs/   architecture.md divergence_model.md isa.md verification.md
results/  logs of the runs reported in docs/verification.md
```

## Quick start

Needs `verilator` (>= 5.020) and `python3`.

```bash
make lint              # Verilator -Wall over five parameter sets
make unit              # arbiters + divergence unit vs models / Python vectors
make models            # Python only: per-thread oracle vs stack model
make directed          # all directed tests x RTL configurations x timing profiles
make random N=200      # 200 random legal programs per RTL configuration
make test              # everything above (N=100)
make mutants           # mutation testing (about 15 minutes)
```

Run one program on the RTL and compare with the reference:

```bash
python3 tools/sfx_asm.py prog.s --list --lint        # assemble, show reconvergence PCs, check the compiler contract
python3 tools/sfx_run.py prog.s --nthreads 96 --nwgs 2 --profile 2 --policy 1
python3 tools/run_tests.py --repro rr32 1234         # replay random case #1234 and keep the files
```

Downstream timing profiles (`+profile=`): 0 ideal, 1 moderate, 2 chaotic, 3
narrow memory + very long latencies, 4/5 deterministic MEM busy windows of 6 / 40
cycles (arbitration fairness).  `+spurious=<pct>` turns the backend and
instruction memory hostile (completions / fetch responses for contexts that
have nothing outstanding).

## Using the unit

Instantiate `sfx_simt_ctrl` (parameters in `docs/architecture.md`), connect an
instruction memory (`imem_*`), a backend that honours the contract BC1-BC7
(`be_*`, `cmp_*`) and a dispatcher (`launch_*`).  Everything the backend needs
for one instruction is in the `be_*` issue packet (warp slot, workgroup id, warp
index, pc, instruction word, active mask); it reads operands at that edge and
returns exactly one completion.  Compile with `-DSFX_CHECKS` in simulation to
enable the assertions.

## Limits (stated plainly)

* **Verilator only.**  The test-bench uses `--binary --timing`.  Icarus Verilog
  and Yosys were *not* used: Yosys 0.33's open-source front end cannot parse
  the SystemVerilog constructs used (so **no synthesis result is claimed**).
  The RTL is lint-clean (`-Wall`) and written in the synthesisable subset.
* The backend, instruction cache and dispatcher are behavioural models in the
  test-bench; the SilicaFlux dataflow core in the surrounding repository is not
  connected (this unit defines its own small SIMT ISA, `docs/isa.md`).
* Liveness is argued and checked by bounded-wait / bounded-progress assertions
  in simulation under stated downstream assumptions; there is no formal proof.
* Divergent `BAR`/`EXIT` and stack overflow are faults, not recoverable events;
  there is no stack spill and no lane-granular `EXIT`.
* Single issue, single fetch, single completion port per cycle.
