"""
Scenario definition shared by every system-level test path (cocotb, Verilator
scenario player, host API): a program, its memory image and engine
configuration, plus the reference-model execution and result comparison.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from golden_model.isa import MEM, FAULTS  # noqa: E402
from reference_model.isa_sim import FluxISASim, SimConfig  # noqa: E402


@dataclass
class Scenario:
    name: str
    words: list
    mem_init: dict = field(default_factory=dict)          # mid -> {row: (values, quals|None)}
    config: dict = field(default_factory=dict)
    compare: dict = field(default_factory=dict)           # mid -> rows to compare
    expect_halt: bool = False
    telemetry_frames: int = 0
    telemetry: list = field(default_factory=list)        # list of beat lists (one DMA S2T transfer each)
    timeout: int = 5_000_000
    pre_writes: list = field(default_factory=list)       # register writes issued before anything else
    ref_setup: object = None                             # callable(sim) mirroring pre_writes effects
    expect_regs: dict = field(default_factory=dict)      # register name -> expected value


def apply_config_to_sim(sim: FluxISASim, cfg: dict):
    st = sim.eng
    if "res_rtol" in cfg:
        st.res_rtol = cfg["res_rtol"]
    if "cons_atol" in cfg:
        st.cons_atol = cfg["cons_atol"]
    if "cons_rtol" in cfg:
        st.cons_rtol = cfg["cons_rtol"]
    if "fault_halt" in cfg:
        sim.fault_halt = cfg["fault_halt"]
    if "frm" in cfg:
        sim.frm = cfg["frm"]
    if "custom_tableau" in cfg:
        stages, A, b = cfg["custom_tableau"]
        st.custom_stages = stages if 1 <= stages <= 4 else 1
        from golden_model.engines import A_SLOTS
        st.custom_A = {slot: A[k] for k, slot in enumerate(A_SLOTS)}
        st.custom_b = list(b)
    if "sweep" in cfg:
        sw = cfg["sweep"]
        st.sw_dims = sw["dims"]
        st.sw_lo, st.sw_step, st.sw_count = list(sw["lo"]), list(sw["step"]), list(sw["count"])
    if "search" in cfg:
        ls = cfg["search"]
        st.ls_dims = ls["dims"]
        st.ls_max_iter = ls["max_iter"]
        st.ls_lo, st.ls_hi = list(ls["lo"]), list(ls["hi"])
        st.ls_center0, st.ls_step0, st.ls_min_step = list(ls["center0"]), list(ls["step0"]), list(ls["min_step"])
    for m, (p, s) in cfg.get("mem_prec", {}).items():
        sim.mem_prec[m] = p
        sim.mem_scale[m] = s


def run_reference(sc: Scenario, lanes: int, fp_mode: int) -> FluxISASim:
    sim = FluxISASim(SimConfig(lanes=lanes, fp_mode=fp_mode))
    apply_config_to_sim(sim, sc.config)
    for mid, rows in sc.mem_init.items():
        for row, (vals, quals) in rows.items():
            sim.load_row(mid, row, vals, quals)
    if sc.ref_setup is not None:
        sc.ref_setup(sim)
    frames = sc.telemetry_frames
    if sc.telemetry:
        from golden_model.telemetry import TelemetryModel
        tm = TelemetryModel(sim.fmt, lanes, sim.cfg.n_chan, sc.config.get("telemetry_max_gap", 0),
                            dict(sc.config.get("telemetry_bounds", {})))
        for beats in sc.telemetry:
            tm.run(beats)
        sim.telem = tm.table
        frames += tm.frames_pending
        for i in range(24):
            if tm.faults >> i & 1 and (sim.first_fault is None):
                pass
        if tm.faults:
            sim._fault_ordered(tm.faults, tm.first_fault, 0)
        sim.telemetry_model = tm
    sim.execute(sc.words, telemetry_frames=frames)
    return sim




def fault_names(bits: int) -> str:
    return ",".join(n for i, n in enumerate(FAULTS) if bits >> i & 1) or "-"


def compare_results(sim: FluxISASim, res: dict, sc: Scenario, lanes: int) -> list[str]:
    """bit-exact comparison of a VerilatorBackend result against the reference model"""
    errs = []
    if res.get("timeout"):
        return ["RTL did not finish (timeout)"]
    regs = res["regs"]
    if sim.halted_fault:
        # after a halting execution fault, younger instructions already in flight
        # may complete and add faults: the reference set must be contained
        if (regs["fault_status"] & sim.fault_status) != sim.fault_status:
            errs.append(f"fault status rtl={fault_names(regs['fault_status'])} ref={fault_names(sim.fault_status)}")
    elif regs["fault_status"] != sim.fault_status:
        errs.append(f"fault status rtl={fault_names(regs['fault_status'])} ref={fault_names(sim.fault_status)}")
    if sim.first_fault is not None:
        rid = regs["fault_first"] & 31
        if not (regs["fault_first"] >> 31) or rid != sim.first_fault[0] or regs["fault_pc"] != sim.first_fault[1]:
            errs.append(f"first fault rtl=({rid},{regs['fault_pc']}) ref={sim.first_fault}")
    if sim.halted_fault:
        for k, v in sc.expect_regs.items():
            if regs.get(k) != v:
                errs.append(f"register {k}: rtl={regs.get(k)} expected={v}")
        return errs
    if regs["fflags"] != sim.fflags:
        errs.append(f"fflags rtl={regs['fflags']:#x} ref={sim.fflags:#x}")
    if regs["retired"] != sim.retired:
        errs.append(f"retired rtl={regs['retired']} ref={sim.retired}")
    tm = getattr(sim, "telemetry_model", None)
    if tm is not None:
        for k in ("accepted", "dropped", "crc", "seq", "ts", "range", "malformed", "frames"):
            if regs.get("tl_" + k) != tm.counters[k]:
                errs.append(f"telemetry counter {k}: rtl={regs.get('tl_' + k)} ref={tm.counters[k]}")
    for k, v in sc.expect_regs.items():
        if regs.get(k) != v:
            errs.append(f"register {k}: rtl={regs.get(k)} expected={v}")
    for mid, nrows in sc.compare.items():
        ref = sim.dump_memory(mid)
        got = res["mem"].get(mid, [])
        if len(got) < nrows:
            errs.append(f"mem{mid}: only {len(got)} rows read back")
            continue
        for r in range(nrows):
            for l in range(lanes):
                gv, gq, gp = got[r][l]
                rv, rq, _ = ref[r][l]
                if gv != rv or gq != rq:
                    errs.append(f"mem{mid}[{r}][{l}] rtl={gv:#x}/q{gq} ref={rv:#x}/q{rq}")
                    if len(errs) > 24:
                        return errs
    return errs
