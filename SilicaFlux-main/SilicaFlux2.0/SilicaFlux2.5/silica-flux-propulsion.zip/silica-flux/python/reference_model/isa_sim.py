"""
Silica Flux instruction-accurate reference model (golden model for programs).

Executes Silica Flux programs one instruction at a time with exactly the
architectural semantics of the RTL: register metadata and precision checks,
per-element quality propagation, lane masks, every functional unit (via
golden_model.valu / engines / ieee / sfu), memories with ping-pong state
banks, fault derivation and in-order fault attribution.

For a program that does not halt on a fault, the final architectural state
(vector registers, mask, memories, engine status) is identical bit-for-bit
to the RTL: the RTL's scoreboard guarantees sequential semantics even though
it overlaps independent instructions.  When a halting fault occurs the RTL
may still complete instructions that were already in flight; the model
stops at the faulting instruction, so only the fault record is compared.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from golden_model import ieee, sfu, valu, engines  # noqa: E402
from golden_model.isa import (Instr, OPNAMES, FU_OF, FU, src_use, writes_vd, writes_vm, F, MEM,  # noqa: E402
                              Q_NAN, Q_OVF, Q_UNF, Q_SUSPECT)

PREC_FP32, PREC_FP64, PREC_SFIX, PREC_UFIX, PREC_INT = range(5)
NUM_MEMS = 7

HALT_DEFAULT = sum(1 << F[n] for n in ("WATCHDOG", "TIMEOUT", "ILLEGAL", "PRECISION", "NAN", "OVERFLOW",
                                       "DIVZERO", "PARITY", "MEMADDR", "PIPELINE", "STEP", "UNINIT", "HOST"))


@dataclass
class Meta:
    valid: bool = False
    prec: int = 0
    scale: int = 0
    source: int = 0


@dataclass
class SimConfig:
    lanes: int = 8
    fp_mode: int = 0
    rows: dict = field(default_factory=lambda: {"STATE": 64, "PARAM": 64, "COEFF": 64, "SCRATCH": 256,
                                                "RESULT": 128})
    n_chan: int = 32
    max_instructions: int = 2_000_000


class FluxISASim:
    def __init__(self, cfg: SimConfig | None = None):
        self.cfg = cfg or SimConfig()
        L = self.cfg.lanes
        self.fmt = ieee.FP64 if self.cfg.fp_mode else ieee.FP32
        self.native = PREC_FP64 if self.cfg.fp_mode else PREC_FP32
        self.W = self.fmt.width
        self.vreg = [[0] * L for _ in range(32)]
        self.vqual = [[0] * L for _ in range(32)]
        self.meta = [Meta() for _ in range(32)]
        self.vm = (1 << L) - 1
        self.areg = [0] * 8
        r = self.cfg.rows
        z = (0, 0, False)
        self.mem = {
            "STATE0": [[z] * L for _ in range(r["STATE"])], "STATE1": [[z] * L for _ in range(r["STATE"])],
            "PARAM": [[z] * L for _ in range(r["PARAM"])], "COEFF": [[z] * L for _ in range(r["COEFF"])],
            "SCRATCH": [[z] * L for _ in range(r["SCRATCH"])], "RESULT": [[z] * L for _ in range(r["RESULT"])],
        }
        trows = (self.cfg.n_chan + L - 1) // L
        self.telem = [[(0, Q_SUSPECT, False)] * L for _ in range(trows)]
        self.bank = 0
        self.mem_prec = [self.native] * NUM_MEMS
        self.mem_scale = [0] * NUM_MEMS
        self.frm = 0
        self.eng = engines.EngineState(self.fmt, L)
        self.fault_status = 0
        self.fault_enable = (1 << 24) - 1
        self.fault_halt = HALT_DEFAULT
        self.first_fault = None          # (id, pc)
        self.fault_count = 0
        self.fflags = 0
        self.retired = 0
        self.halted_fault = False
        self.done = False
        self.trace: list = []
        self.frames_pending = 0
        self.lane_ops = 0
        self.imem_corrupt: set = set()

    # ------------------------------------------------------------------ memory helpers
    def _bank_name(self, mid: int) -> str | None:
        if mid == MEM["STATE"]:
            return f"STATE{self.bank}"
        if mid == MEM["STATE_N"]:
            return f"STATE{1 - self.bank}"
        return {MEM["PARAM"]: "PARAM", MEM["COEFF"]: "COEFF", MEM["SCRATCH"]: "SCRATCH",
                MEM["RESULT"]: "RESULT"}.get(mid)

    def mem_rows(self, mid: int) -> int:
        if mid == MEM["TELEM"]:
            return len(self.telem)
        n = self._bank_name(mid)
        return len(self.mem[n]) if n else 0

    def write_element(self, mid: int, row: int, lane: int, value: int, qual: int = 0, corrupt: bool = False):
        n = self._bank_name(mid)
        self.mem[n][row][lane] = (value & self.fmt.mask, qual & 15, corrupt)

    def read_element(self, mid: int, row: int, lane: int):
        if mid == MEM["TELEM"]:
            return self.telem[row][lane]
        return self.mem[self._bank_name(mid)][row][lane]

    def load_row(self, mid: int, row: int, values, quals=None):
        for l, v in enumerate(values):
            self.write_element(mid, row, l, v, 0 if quals is None else quals[l])

    # ------------------------------------------------------------------ faults
    def _fault(self, bits: int, pc: int):
        bits &= self.fault_enable
        if not bits:
            return
        if self.first_fault is None:
            fid = (bits & -bits).bit_length() - 1
            self.first_fault = (fid, pc)
        self.fault_status |= bits
        self.fault_count += 1
        if bits & self.fault_halt:
            self.halted_fault = True

    def _fault_ordered(self, bits: int, first_id: int, pc: int):
        """record several simultaneous fault events whose 'first' id is known"""
        bits &= self.fault_enable
        if not bits:
            return
        if self.first_fault is None:
            self.first_fault = (first_id, pc)
        self.fault_status |= bits
        self.fault_count += 1
        if bits & self.fault_halt:
            self.halted_fault = True

    # ------------------------------------------------------------------ issue checks
    def _issue_check(self, i: Instr) -> int:
        L = self.cfg.lanes
        fu = FU_OF.get(i.opcode, 15)
        ctrl = fu == FU["CTRL"]
        is_fx = i.prec in (PREC_SFIX, PREC_UFIX, PREC_INT)
        rm_eff = self.frm if i.rm == 7 else i.rm
        name = OPNAMES.get(i.opcode, "")
        prec_ok = True
        if fu == FU["VALU"]:
            if i.prec != self.native and not is_fx:
                prec_ok = False
            if is_fx and name in ("VFMS", "VFNMA", "VFNMS", "VCLASS"):
                prec_ok = False
            if name == "VCVT":
                src = i.func & 7
                if i.prec == self.native:
                    prec_ok = src in (self.native, PREC_SFIX, PREC_UFIX, PREC_INT)
                else:
                    prec_ok = is_fx and src == self.native
        elif fu == FU["LSU"]:
            prec_ok = (i.func & 7) < NUM_MEMS and not (i.func & 8) and self.mem_prec[i.func & 7] == i.prec
        elif not ctrl:
            prec_ok = i.prec == self.native
        illegal = fu == 15 or (not ctrl and (i.vl > L or rm_eff > 4 or not prec_ok))
        if illegal:
            return 1 << F["ILLEGAL"]
        use = src_use(i)
        exp_prec = i.prec
        exp_scale = i.imm & 63 if i.prec in (PREC_SFIX, PREC_UFIX) else 0
        if name == "VCVT":
            exp_prec = i.func & 7
            exp_scale = (i.imm >> 6) & 63 if exp_prec in (PREC_SFIX, PREC_UFIX) else 0
        elif name == "VSTORE":
            exp_prec = self.mem_prec[i.func & 7]
            exp_scale = self.mem_scale[i.func & 7]
        elif name == "VMSET":
            exp_scale = self.meta[i.vs1].scale
        uninit = mismatch = False
        for bit, r, p in ((0, i.vs1, exp_prec), (1, i.vs2, exp_prec if name == "VCVT" else i.prec),
                          (2, i.vs3, i.prec)):
            if use >> bit & 1:
                m = self.meta[r]
                if not m.valid:
                    uninit = True
                elif m.prec != p or m.scale != exp_scale:
                    mismatch = True
        dest_prec = PREC_INT if name == "VCLASS" else i.prec
        partial = i.masked or (i.vl != 0 and i.vl < L)
        mix = writes_vd(i) and partial and self.meta[i.vd].valid and self.meta[i.vd].prec != dest_prec
        if uninit:
            return 1 << F["UNINIT"]
        if mismatch or mix:
            return 1 << F["PRECISION"]
        return 0

    # ------------------------------------------------------------------ write-back
    def _writeback(self, i: Instr, data, qual, wmask: int, vm_bits=None, ff: int = 0, faults: int = 0):
        L = self.cfg.lanes
        nan_written = False
        if writes_vd(i) and wmask:
            for l in range(L):
                if wmask >> l & 1:
                    self.vreg[i.vd][l] = data[l] & self.fmt.mask
                    self.vqual[i.vd][l] = qual[l]
                    if qual[l] & Q_NAN:
                        nan_written = True
            name = OPNAMES[i.opcode]
            prec = PREC_INT if name == "VCLASS" else i.prec
            if prec in (PREC_SFIX, PREC_UFIX):
                scale = self.mem_scale[i.func & 7] if FU_OF[i.opcode] == FU["LSU"] else i.imm & 63
            else:
                scale = 0
            self.meta[i.vd] = Meta(True, prec, scale, i.opcode)
        if writes_vm(i) and vm_bits is not None:
            for l in range(L):
                if wmask >> l & 1:
                    self.vm = (self.vm & ~(1 << l)) | ((vm_bits[l] & 1) << l)
        if ff & ieee.NV or nan_written:
            faults |= 1 << F["NAN"]
        if ff & ieee.OF:
            faults |= 1 << F["OVERFLOW"]
        if ff & ieee.UF:
            faults |= 1 << F["UNDERFLOW"]
        if ff & ieee.DZ:
            faults |= 1 << F["DIVZERO"]
        self.fflags |= ff
        if FU_OF[i.opcode] not in (FU["LSU"], FU["CTRL"]):
            self.lane_ops += bin(wmask).count("1")
        return faults

    # ------------------------------------------------------------------ execution
    def _lmask(self, i: Instr) -> int:
        L = self.cfg.lanes
        vl = (1 << L) - 1 if i.vl == 0 else (1 << i.vl) - 1
        return vl & (self.vm if i.masked else (1 << L) - 1)

    def execute(self, words: list[int], start_pc: int = 0, telemetry_frames: int = 0) -> "FluxISASim":
        self.frames_pending = telemetry_frames
        pc = start_pc
        n = 0
        while True:
            if pc >= len(words):
                raise RuntimeError(f"pc {pc} ran off the end of the program")
            i = Instr.decode(words[pc])
            n += 1
            if n > self.cfg.max_instructions:
                raise RuntimeError("instruction limit exceeded")
            self.trace.append(pc)
            fu = FU_OF.get(i.opcode, 15)
            if pc in self.imem_corrupt:
                self.retired += 1
                self._fault(1 << F["PARITY"], pc)
                if self.halted_fault:
                    return self
                pc += 1
                continue
            if fu == FU["CTRL"]:
                name = OPNAMES[i.opcode]
                self.retired += 1
                if name == "HALT":
                    self.done = True
                    return self
                if name == "SETA":
                    self.areg[i.vd & 7] = i.imm & 0xFFFFF
                elif name == "ADDA":
                    self.areg[i.vd & 7] = (self.areg[i.vd & 7] + i.simm) & 0xFFFFF
                elif name == "BNZ":
                    r = i.vs1 & 7
                    if self.areg[r] != 0:
                        self.areg[r] = (self.areg[r] - 1) & 0xFFFFF
                        off = i.imm & 0xFFFF
                        off = off - 0x10000 if off & 0x8000 else off
                        pc = (pc + off) & 0xFFFF
                        continue
                elif name == "BARRIER":
                    if i.func & 1:
                        if self.frames_pending <= 0:
                            # the core stalls; the progress watchdog fires and halts it
                            self.retired -= 1
                            self._fault(1 << F["WATCHDOG"], pc)
                            if self.halted_fault:
                                return self
                            raise RuntimeError("BARRIER TELEM starved with watchdog disabled")
                        self.frames_pending -= 1
                    if i.func & 4:
                        self.bank ^= 1
                pc += 1
                continue
            faults = self._issue_check(i)
            self.retired += 1
            if faults:
                self._fault(faults, pc)
            else:
                faults = self._exec_vector(i, pc)
                self._fault(faults, pc)
            if self.halted_fault:
                return self
            pc += 1

    def _exec_vector(self, i: Instr, pc: int) -> int:
        f, L = self.fmt, self.cfg.lanes
        name = OPNAMES[i.opcode]
        fu = FU_OF[i.opcode]
        rm = self.frm if i.rm == 7 else i.rm
        A, B, C = self.vreg[i.vs1], self.vreg[i.vs2], self.vreg[i.vs3]
        QA, QB, QC = self.vqual[i.vs1], self.vqual[i.vs2], self.vqual[i.vs3]
        lm = self._lmask(i)
        st = self.eng
        if fu == FU["VALU"]:
            d, q, mb, ff = valu.valu_vector(f, i, rm, A, B, C, QA, QB, QC, lm, self.vm, L)
            return self._writeback(i, d, q, lm, mb, ff)
        if fu in (FU["DIVSQRT"], FU["SFU"]):
            d, q, ff = [], [], 0
            for l in range(L):
                if name == "VDIV":
                    r, fl = ieee.div(f, A[l], B[l], rm)
                elif name == "VSQRT":
                    r, fl = ieee.sqrt(f, A[l], rm)
                else:
                    r, fl = sfu.SFU_FUNCS[{"VRECIP": "recip", "VEXP": "exp", "VLOG": "log"}[name]](f, A[l])
                qq = QA[l] | (QB[l] if name == "VDIV" else 0)
                if fl & ieee.NV or f.is_nan(r):
                    qq |= Q_NAN
                if fl & (ieee.OF | ieee.DZ) or f.is_inf(r):
                    qq |= Q_OVF
                if fl & ieee.UF:
                    qq |= Q_UNF
                d.append(r)
                q.append(qq)
                if lm >> l & 1:
                    ff |= fl
            return self._writeback(i, d, q, lm, None, ff)
        if fu == FU["RED"]:
            d, q, ff = engines.reduce(f, i.func, rm, A, B, QA, QB, lm, L)
            return self._writeback(i, d, q, (1 << L) - 1, None, ff)
        if fu == FU["POLY"]:
            if name == "VCUBE":
                d, q, ff = engines.cube(f, rm, A, QA, lm, L)
            else:
                d, q, ff = engines.poly(f, rm, i.imm & 15, A, B, QA, QB, lm, L)
            return self._writeback(i, d, q, lm, None, ff)
        if fu == FU["INTERP"]:
            d, q, ff = engines.interp(f, rm, A, B, C, QA, QB, QC, lm, L)
            return self._writeback(i, d, q, lm, None, ff)
        if fu == FU["LSU"]:
            return self._exec_lsu(i, lm)
        if fu == FU["STATE"]:
            if name == "TSCFG":
                bad = engines.tscfg(st, i.func, A[0])
                return (1 << F["STEP"]) if (bad and i.func != 15) else 0
            d, q, ff, fault, _ = engines.state_update(st, i.func, rm, A, QA, lm)
            return self._writeback(i, d, q, lm, None, ff, (1 << F["STEP"]) if fault else 0)
        if fu == FU["RESID"]:
            d, q, vm, ff, viol = engines.residual(st, i.func, rm, A, B, C, QA, QB, QC, lm)
            return self._writeback(i, d, q, lm, vm, ff, (1 << F["RESIDUAL"]) if viol else 0)
        if fu == FU["CONS"]:
            d, q, ff, viol = engines.conserve(st, i.func, rm, A, B, C, QA, QB, QC, lm)
            return self._writeback(i, d, q, (1 << L) - 1, None, ff, (1 << F["CONSERVATION"]) if viol else 0)
        if fu == FU["OBJ"]:
            d, q, ff = engines.objective(st, i.func, rm, A, B, C, QA, QB, QC, lm)
            wm = (1 << L) - 1 if (i.func >> 3) & 1 else lm
            return self._writeback(i, d, q, wm, None, ff)
        if fu == FU["CON"]:
            d, q, vm, ff, fail = engines.constraint(st, i.func, rm, A, B, C, QA, QB, QC, lm)
            return self._writeback(i, d, q, lm, vm, ff, (1 << F["CONSTRAINT"]) if fail else 0)
        if fu == FU["SWEEP"]:
            d, vm, q, ff, bad = engines.sweep(st, i.func, rm, i.imm & 3, lm)
            flt = (1 << F["SEARCH"]) if bad else 0
            if d is None:
                return flt
            return self._writeback(i, d, q, lm, vm, ff, flt)
        if fu == FU["SEARCH"]:
            d, vm, q, ff, bad = engines.search(st, i.func, rm, i.imm & 3, A, lm, self.vm)
            flt = (1 << F["SEARCH"]) if bad else 0
            if d is None:
                return flt
            return self._writeback(i, d, q, lm, vm, ff, flt)
        raise RuntimeError(f"unimplemented FU for {name}")

    def _exec_lsu(self, i: Instr, lm: int) -> int:
        L = self.cfg.lanes
        name = OPNAMES[i.opcode]
        mid = i.func & 7
        ea = (self.areg[i.vs2 & 7] + i.imm) & 0xFFFFF
        ea19 = ea & 0x7FFFF
        lw = (L - 1).bit_length()
        row = (ea19 >> lw) & 0xFFFF if name == "VLDBC" else ea19 & 0xFFFF
        ok = mid < NUM_MEMS and row < self.mem_rows(mid) and not (name == "VSTORE" and mid == MEM["TELEM"])
        if not ok:
            return 1 << F["MEMADDR"]
        if name == "VSTORE":
            for l in range(L):
                if lm >> l & 1:
                    self.write_element(mid, row, l, self.vreg[i.vs1][l], self.vqual[i.vs1][l])
            return 0
        elems = [self.read_element(mid, row, l) for l in range(L)]
        if name == "VLDBC":
            e = elems[ea19 & (L - 1)]
            elems = [e] * L
            perr_any = e[2]
        else:
            perr_any = any(elems[l][2] for l in range(L) if lm >> l & 1)
        d = [e[0] for e in elems]
        q = [e[1] | ((Q_NAN | Q_SUSPECT) if e[2] else 0) for e in elems]
        return self._writeback(i, d, q, lm, None, 0, (1 << F["PARITY"]) if perr_any else 0)

    # ------------------------------------------------------------------ results
    def dump_memory(self, mid: int):
        if mid == MEM["TELEM"]:
            return [list(r) for r in self.telem]
        return [list(r) for r in self.mem[self._bank_name(mid)]]
