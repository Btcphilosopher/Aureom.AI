#!/usr/bin/env python3
"""
System-level regression on the Verilator scenario player.

    python3 python/reference_model/system_regress.py --config fp32_l8 --suite directed
    python3 python/reference_model/system_regress.py --all

Every scenario runs on the compiled RTL (tb/tb_top.sv) and on the
instruction-accurate reference model; memories, quality bits, IEEE flags,
fault records and retired-instruction counts are compared bit-exactly.
Results: reports/system/<config>_<suite>.json
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))

from golden_model import ieee  # noqa: E402
from generators import programs  # noqa: E402
from reference_model.scenario import run_reference, compare_results, fault_names  # noqa: E402
from silica_flux.rtl_backend import VerilatorBackend  # noqa: E402

CONFIGS = {
    "fp32_l8": (8, 0, 4), "fp32_l16": (16, 0, 5), "fp32_l32": (32, 0, 4), "fp64_l8": (8, 1, 4), "fp64_l16": (16, 1, 6),
}


def suite(name: str, fmt, lanes: int, n_random: int, seed: int):
    if name == "directed":
        return programs.directed_suite(fmt, lanes)
    if name == "random":
        return [programs.random_program(fmt, lanes, seed=seed * 1000 + k, length=48) for k in range(n_random)]
    if name == "faults":
        return programs.fault_suite(fmt, lanes)
    if name == "telemetry":
        return programs.telemetry_suite(fmt, lanes)
    raise ValueError(name)


def run_config(cfg: str, suites: list[str], n_random: int, seed: int, verbose: bool) -> dict:
    lanes, fp_mode, depth = CONFIGS[cfg]
    fmt = ieee.FP64 if fp_mode else ieee.FP32
    be = VerilatorBackend(lanes, fp_mode, depth)
    out = {}
    for sname in suites:
        rec = {}
        for sc in suite(sname, fmt, lanes, n_random, seed):
            t0 = time.time()
            sim = run_reference(sc, lanes, fp_mode)
            res = be.run(sc)
            errs = compare_results(sim, res, sc, lanes)
            ok = not errs and (sc.expect_halt == sim.halted_fault)
            rec[sc.name] = {"match": ok, "errors": errs[:8], "regs": res["regs"], "wait_cycles": res["wait_cycles"],
                            "ref_retired": sim.retired, "ref_faults": fault_names(sim.fault_status),
                            "ref_lane_ops": sim.lane_ops, "seconds": round(time.time() - t0, 2)}
            tag = "PASS" if ok else "FAIL"
            print(f"[{cfg}/{sname}] {sc.name:<24} {tag}  cycles={res['regs'].get('cycles')} "
                  f"retired={res['regs'].get('retired')} faults={fault_names(sim.fault_status)}", flush=True)
            if verbose or not ok:
                for e in errs[:12]:
                    print("      " + e)
        (ROOT / "reports/system").mkdir(parents=True, exist_ok=True)
        (ROOT / f"reports/system/{cfg}_{sname}.json").write_text(json.dumps(rec, indent=2))
        out[sname] = rec
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", action="append")
    ap.add_argument("--suite", action="append")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--random", type=int, default=6)
    ap.add_argument("--seed", type=int, default=5)
    ap.add_argument("-v", action="store_true")
    a = ap.parse_args()
    cfgs = a.config or (list(CONFIGS) if a.all else ["fp32_l8"])
    suites = a.suite or ["directed", "random", "faults", "telemetry"]
    fails = 0
    for c in cfgs:
        res = run_config(c, suites, a.random, a.seed, a.v)
        fails += sum(1 for s in res.values() for r in s.values() if not r["match"])
    print(f"SYSTEM REGRESSION: {'PASS' if fails == 0 else f'FAIL ({fails})'}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
