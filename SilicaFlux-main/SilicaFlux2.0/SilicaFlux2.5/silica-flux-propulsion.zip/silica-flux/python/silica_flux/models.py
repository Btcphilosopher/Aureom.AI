"""
Host-side model description with explicit physical units.

The fabric never sees units -- it sees precision tags.  Units are enforced
here, before anything is loaded: every quantity carries a unit, quantities
are only combined when their dimensions agree, and a model is rejected if the
derivative it implies does not have the dimensions of (state / time).

The models are deliberately abstract engineering systems (lumped networks,
surrogates).  Nothing here encodes a particular engine, vehicle or control
law; Silica Flux is a numerical accelerator, not a flight computer.
"""
from __future__ import annotations

import re
from typing import Dict, List

from pydantic import BaseModel, Field, field_validator, model_validator

# ---------------------------------------------------------------- dimensions
_BASE = {"kg": "M", "m": "L", "s": "T", "K": "Th", "mol": "N"}
_DERIVED = {
    "J": {"M": 1, "L": 2, "T": -2}, "W": {"M": 1, "L": 2, "T": -3}, "N": {"M": 1, "L": 1, "T": -2},
    "Pa": {"M": 1, "L": -1, "T": -2}, "1": {},
}


def dims(unit: str) -> Dict[str, int]:
    """'W/K' -> {'M':1,'L':2,'T':-3,'Th':-1}.  Grammar: factors separated by '*'
    or '/', each factor 'sym' or 'sym^n'."""
    unit = unit.strip() or "1"
    out: Dict[str, int] = {}
    sign = 1
    for tok in re.split(r"(\*|/)", unit):
        tok = tok.strip()
        if tok == "*":
            sign = 1
            continue
        if tok == "/":
            sign = -1
            continue
        if not tok:
            continue
        sym, _, pw = tok.partition("^")
        p = int(pw) if pw else 1
        if sym in _BASE:
            d = {_BASE[sym]: 1}
        elif sym in _DERIVED:
            d = _DERIVED[sym]
        else:
            raise ValueError(f"unknown unit symbol {sym!r}")
        for k, v in d.items():
            out[k] = out.get(k, 0) + sign * p * v
    return {k: v for k, v in out.items() if v}


def same_dims(a: str, b: str) -> bool:
    return dims(a) == dims(b)


def div_dims(a: str, b: str) -> Dict[str, int]:
    da, db = dims(a), dims(b)
    out = dict(da)
    for k, v in db.items():
        out[k] = out.get(k, 0) - v
    return {k: v for k, v in out.items() if v}


class Quantity(BaseModel):
    values: List[float]
    unit: str

    @field_validator("unit")
    @classmethod
    def _known(cls, u):
        dims(u)
        return u

    def check(self, unit: str, name: str):
        if not same_dims(self.unit, unit):
            raise ValueError(f"{name}: expected dimensions of {unit!r}, got {self.unit!r}")
        return self


# ---------------------------------------------------------------- models
class ThermalNetworkModel(BaseModel):
    """Ring of N lumped thermal nodes (abstract thermal / process network).

        C_i dT_i/dt = F_i - F_{i-1} + q_i(t)
        F_i = Gs_i * k(Tbar_i) * (T_{i+1} - T_i),   Tbar_i = (T_i + T_{i+1}) / 2
        k(T) = c0 + c1 T + c2 T^2 + c3 T^3          (dimensionless correlation)
        q_i(t) = Q_i * profile(t / t_end)           (tabulated, interpolated)

    Invariant checked in hardware every step:  sum C_i T_i  changes only by
    sum q_i dt  (link fluxes cancel pairwise around the ring)."""
    capacity: Quantity                     # C_i  [J/K]
    link_conductance: Quantity             # Gs_i [W/K]
    heater_amplitude: Quantity             # Q_i  [W]
    k_coeffs: List[float] = Field(min_length=1, max_length=8)
    profile: List[float]                   # heater time profile, LANES points over [0, t_end]
    t_end: float                           # [s]
    t_max: Quantity                        # constraint upper bound [K]
    t_min: Quantity                        # constraint lower bound [K]
    target: Quantity                       # objective target [K]
    weights: List[float]
    residual_atol: Quantity                # [K]
    residual_rtol: float = 1e-3
    conservation_atol: float = 1e-3        # [J]
    conservation_rtol: float = 1e-5

    @model_validator(mode="after")
    def _units(self):
        self.capacity.check("J/K", "capacity")
        self.link_conductance.check("W/K", "link_conductance")
        self.heater_amplitude.check("W", "heater_amplitude")
        for n in ("t_max", "t_min", "target", "residual_atol"):
            getattr(self, n).check("K", n)
        # derivative dimensions: (W) / (J/K) must equal K/s
        if div_dims("W", "J/K") != dims("K/s"):
            raise ValueError("inconsistent derivative dimensions")
        return self


class SurrogateDesignModel(BaseModel):
    """0-D heated-element surrogate for design-space exploration (one candidate
    per lane):  C dT/dt = P - Gs k(T) (T - T_amb).
    P0 = conductance scale Gs [W/K], P1 = power P [W] are the swept parameters."""
    capacity: float                        # [J/K]
    t_ambient: float                       # [K]
    t_initial: float                       # [K]
    k_coeffs: List[float]
    steps: int = 40
    dt: float = 0.5                        # [s]
    target_temperature: float              # [K]
    t_limit: float                         # peak-temperature constraint [K]
    power_weight: float                    # objective weight on P / P_ref
    power_ref: float
    gs_range: tuple[float, float, int]     # lo, step, count
    p_range: tuple[float, float, int]
