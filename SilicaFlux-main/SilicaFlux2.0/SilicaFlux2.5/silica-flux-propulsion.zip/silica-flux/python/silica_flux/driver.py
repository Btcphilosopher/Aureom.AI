"""
Register-level host driver primitives (pure functions -> register writes).

Shared by the cocotb host (which performs the writes on the simulated AXI-Lite
bus), the Verilator scenario player command writer and, on hardware, a memory-
mapped I/O backend.  Keeping one implementation guarantees that every test
path configures the fabric identically.
"""
from __future__ import annotations

from silica_flux import regmap as R


def w64(addr: int, value: int):
    return [(addr, value & 0xFFFFFFFF), (addr + 4, (value >> 32) & 0xFFFFFFFF)]


def config_writes(cfg: dict) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    if "res_rtol" in cfg:
        out += w64(R.RES_RTOL, cfg["res_rtol"])
    if "cons_atol" in cfg:
        out += w64(R.CONS_ATOL, cfg["cons_atol"])
    if "cons_rtol" in cfg:
        out += w64(R.CONS_RTOL, cfg["cons_rtol"])
    if "fault_halt" in cfg:
        out.append((R.FAULT_HALT, cfg["fault_halt"]))
    if "fault_enable" in cfg:
        out.append((R.FAULT_ENABLE, cfg["fault_enable"]))
    if "frm" in cfg:
        out.append((R.FRM, cfg["frm"]))
    if "wdt_limit" in cfg:
        out.append((R.WDT_LIMIT, cfg["wdt_limit"]))
    if "custom_tableau" in cfg:
        stages, A, b = cfg["custom_tableau"]
        out.append((R.TS_STAGES, stages))
        for slot, v in enumerate(list(A) + list(b)):
            out.append((R.TS_TAB_SEL, slot))
            out += w64(R.TS_TAB, v)
    if "sweep" in cfg:
        sw = cfg["sweep"]
        out.append((R.SW_DIMS, sw["dims"]))
        for d in range(4):
            out.append((R.SW_DSEL, d))
            out += w64(R.SW_LO, sw["lo"][d])
            out += w64(R.SW_STEP, sw["step"][d])
            out.append((R.SW_COUNT, sw["count"][d]))
    if "search" in cfg:
        ls = cfg["search"]
        out.append((R.LS_DIMS, ls["dims"]))
        out.append((R.LS_MAX_ITER, ls["max_iter"]))
        for d in range(4):
            out.append((R.LS_DSEL, d))
            for fsel, key in ((R.LS_LO, "lo"), (R.LS_HI, "hi"), (R.LS_CENTER0, "center0"),
                              (R.LS_STEP0, "step0"), (R.LS_MIN_STEP, "min_step")):
                out.append((R.LS_FSEL, fsel))
                out += w64(R.LS_VAL, ls[key][d])
    for m, (p, s) in cfg.get("mem_prec", {}).items():
        out.append((R.MEM_PREC + 4 * m, p | (s << 8)))
    if "telemetry_bounds" in cfg:
        for ch, (lo, hi) in cfg["telemetry_bounds"].items():
            out.append((R.TL_BOUND_CHAN, ch))
            out += w64(R.TL_BOUND_LO, lo)
            out += w64(R.TL_BOUND_HI, hi)
    if "telemetry_max_gap" in cfg:
        out.append((R.TL_MAX_GAP, cfg["telemetry_max_gap"]))
    return out


def program_writes(words: list[int], base: int = 0) -> list[tuple[int, int]]:
    out = [(R.IMEM_ADDR, base)]
    for w in words:
        out.append((R.IMEM_WLO, w & 0xFFFFFFFF))
        out.append((R.IMEM_WHI, (w >> 32) & 0xFFFFFFFF))
    return out


def dma_setup(direction: int, mem: int, row: int, length: int) -> list[tuple[int, int]]:
    return [(R.DMA_MEM, mem), (R.DMA_ROW, row), (R.DMA_LEN, length), (R.DMA_CTRL, 1 | (direction << 1))]


def telemetry_packet(ts: int, seq: int, chan: int, value_bits: int, quality: int = 0,
                     frame_end: bool = False, corrupt_crc: bool = False) -> list[tuple[int, int, int]]:
    """three 64-bit beats (data, user, last) -- format in rtl/telemetry/telemetry_ingest.sv"""
    q = (quality & 0x7F) | (0x80 if frame_end else 0)
    b0 = ((ts & 0xFFFFFFFF) << 32) | ((seq & 0xFFFF) << 16) | ((chan & 0xFF) << 8) | q
    b1 = value_bits & 0xFFFFFFFFFFFFFFFF
    crc = crc16_ccitt(b0.to_bytes(8, "little") + b1.to_bytes(8, "little"))
    if corrupt_crc:
        crc ^= 0x0101
    return [(b0, 0, 0), (b1, 0, 0), (crc, 0, 1)]


def crc16_ccitt(data: bytes, crc: int = 0xFFFF) -> int:
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
    return crc
