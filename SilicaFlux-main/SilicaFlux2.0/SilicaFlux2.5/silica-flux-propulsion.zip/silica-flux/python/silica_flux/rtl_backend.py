"""
RTL execution backend: runs scenarios on the Verilator-compiled system
testbench (tb/tb_top.sv) and returns the architectural results.

    backend = VerilatorBackend(lanes=8, fp_mode=0)
    result  = backend.run(scenario)          # dict: memories, registers, cycles

Memory images are loaded with the DMA engine (AXI-Stream S2M) and read back
with DMA M2S, so every system test also exercises the DMA path, the
AXI-Stream slices and the internal bus arbitration.
"""
from __future__ import annotations

import hashlib
import os
import subprocess
import tempfile
from pathlib import Path

from silica_flux import regmap as R
from silica_flux.driver import config_writes, dma_setup, program_writes

ROOT = Path(__file__).resolve().parents[2]
REG_READBACK = {
    "fault_status": R.FAULT_STATUS, "fault_first": R.FAULT_FIRST, "fault_pc": R.FAULT_PC,
    "fault_count": R.FAULT_COUNT, "fflags": R.FFLAGS, "status": R.STATUS, "cycles": R.PERF_CYCLES,
    "retired": R.PERF_RETIRED, "issued": R.PERF_ISSUED, "stalls": R.PERF_STALLS, "lane_ops": R.PERF_LANE_OPS,
    "loads": R.PERF_LOADS, "stores": R.PERF_STORES, "state_updates": R.PERF_STATE_UPD,
    "bus_accesses": R.BUS_ACCESSES, "bus_conflicts": R.BUS_CONFLICTS, "ts_step": R.TS_STEP,
    "sw_base": R.SW_BASE, "sr_best_lo": R.SR_BEST, "sr_best_hi": R.SR_BEST + 4, "sr_best_idx": R.SR_BEST_IDX,
    "ls_iter": R.LS_ITER, "ls_status": R.LS_STATUS, "con_pass": R.CON_PASS, "con_fail": R.CON_FAIL,
    "cons_viol": R.CONS_VIOL, "res_viol": R.RES_VIOL, "tl_accepted": R.TL_ACCEPTED, "tl_crc": R.TL_CRC,
    "tl_seq": R.TL_SEQ, "tl_dropped": R.TL_DROPPED, "tl_ts": R.TL_TS, "tl_range": R.TL_RANGE,
    "tl_frames": R.TL_FRAMES, "tl_malformed": R.TL_MALFORMED, "tl_ovf": R.TL_OVF,
}
REG_READBACK.update({f"fu_busy_{f}": R.PERF_FU_BUSY + 4 * f for f in range(15)})

RTL_SOURCES = [ROOT / line.strip() for line in (ROOT / "rtl/sources.f").read_text().splitlines() if line.strip()]


def build_verilator(lanes: int, fp_mode: int, depth: int = 4, jobs: int = 4, quiet: bool = True) -> Path:
    name = f"tb_top_{'fp64' if fp_mode else 'fp32'}_l{lanes}_d{depth}"
    obj = ROOT / "build" / "verilator" / name
    exe = obj / "Vtb_top"
    # formal/assertions.sv: concurrent SVA checkers bound into the chip (checked every cycle)
    srcs = RTL_SOURCES + [ROOT / "formal/assertions.sv", ROOT / "tb/tb_top.sv"]
    stamp = hashlib.sha1("".join(str(p.stat().st_mtime_ns) for p in srcs).encode()).hexdigest()
    if exe.exists() and (obj / "stamp").exists() and (obj / "stamp").read_text() == stamp:
        return exe
    obj.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-j", str(jobs), "-Wno-fatal", "-Wno-lint", "-Wno-style",
           "-O2", "--x-assign", "fast", "--x-initial", "fast", "--assert", "+define+SF_SVA",
           "--top-module", "tb_top",
           f"-GLANES={lanes}", f"-GFP_MODE={fp_mode}", f"-GDEPTH={depth}",
           "-I" + str(ROOT / "rtl/core"), "-I" + str(ROOT / "rtl/math/generated"),
           "--Mdir", str(obj), "-o", "Vtb_top"] + [str(s) for s in srcs]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("verilator build failed:\n" + r.stdout[-4000:] + r.stderr[-4000:])
    (obj / "stamp").write_text(stamp)
    return exe


class VerilatorBackend:
    def __init__(self, lanes: int = 8, fp_mode: int = 0, depth: int = 4):
        self.lanes, self.fp_mode, self.depth = lanes, fp_mode, depth
        self.exe = build_verilator(lanes, fp_mode, depth)

    # ------------------------------------------------------------------ command generation
    def commands(self, sc) -> list[tuple]:
        L = self.lanes
        cmds: list[tuple] = []
        for a, d in getattr(sc, "pre_writes", []) or []:
            cmds.append((1, a, d, 0))
        for a, d in config_writes(sc.config) + program_writes(sc.words):
            cmds.append((1, a, d, 0))
        for mid, rows in sc.mem_init.items():
            if not rows:
                continue
            r0, r1 = min(rows), max(rows)
            n = (r1 - r0 + 1) * L
            for a, d in dma_setup(0, mid, r0, n):
                cmds.append((1, a, d, 0))
            k = 0
            for r in range(r0, r1 + 1):
                vals, quals = rows.get(r, ([0] * L, None))
                for l in range(L):
                    k += 1
                    q = 0 if quals is None else quals[l]
                    cmds.append((4, vals[l] & 0xFFFFFFFFFFFFFFFF, q, int(k == n)))
            cmds.append((9, 0, 0, 0))
        for beats in getattr(sc, "telemetry", []) or []:
            for a, d in dma_setup(2, 0, 0, len(beats) // 3):
                cmds.append((1, a, d, 0))
            for data, user, last in beats:
                cmds.append((4, data, user, last))
            cmds.append((9, 0, 0, 0))
        cmds += [(1, R.START_PC, 0, 0), (1, R.CTRL, R.CTRL_START, 0), (3, getattr(sc, "timeout", 5_000_000), 0, 0)]
        for _, addr in REG_READBACK.items():
            cmds.append((2, addr, 0, 0))
        for mid, nrows in sc.compare.items():
            cmds.append((7, mid, 0, 0))
            for a, d in dma_setup(1, mid, 0, nrows * L):
                cmds.append((1, a, d, 0))
            cmds.append((5, nrows * L, 0, 0))
            cmds.append((9, 0, 0, 0))
        cmds.append((6, 0, 0, 0))
        return cmds

    # ------------------------------------------------------------------ execution
    def run(self, sc, keep: bool = False) -> dict:
        with tempfile.TemporaryDirectory(prefix="sf_") as td:
            cf, of = Path(td) / "cmd.txt", Path(td) / "out.txt"
            cf.write_text("".join(f"{o:x} {a:x} {b:x} {c:x}\n" for o, a, b, c in self.commands(sc)))
            r = subprocess.run([str(self.exe), f"+SCENARIO={cf}", f"+OUT={of}"], capture_output=True, text=True,
                               cwd=td, timeout=3600)
            if r.returncode != 0 or not of.exists():
                raise RuntimeError(f"simulation failed: {r.stdout[-2000:]} {r.stderr[-2000:]}")
            return self.parse(of.read_text().splitlines(), sc)

    def parse(self, lines: list[str], sc) -> dict:
        regs, mems, cur, beats = {}, {}, None, []
        res = {"timeout": False, "wait_cycles": None}
        addr_name = {v: k for k, v in REG_READBACK.items()}
        for ln in lines:
            p = ln.split()
            if not p:
                continue
            if p[0] == "R":
                a, d = int(p[1], 16), int(p[2], 16)
                if a in addr_name:
                    regs[addr_name[a]] = d
            elif p[0] == "WAIT":
                res["wait_cycles"] = int(p[1])
            elif p[0] == "TIMEOUT":
                res["timeout"] = True
            elif p[0] == "MARK":
                if cur is not None:
                    mems[cur] = beats
                cur, beats = int(p[1]), []
            elif p[0] == "O":
                beats.append((int(p[1], 16), int(p[2], 16)))
            elif p[0] == "END":
                res["end_cycle"] = int(p[1])
        if cur is not None:
            mems[cur] = beats
        L = self.lanes
        mask = (1 << (64 if self.fp_mode else 32)) - 1
        res["regs"] = regs
        res["mem"] = {}
        for mid, bl in mems.items():
            rows = []
            for i in range(0, len(bl), L):
                rows.append([(d & mask, u & 0xF, (u >> 7) & 1) for d, u in bl[i:i + L]])
            res["mem"][mid] = rows
        return res
