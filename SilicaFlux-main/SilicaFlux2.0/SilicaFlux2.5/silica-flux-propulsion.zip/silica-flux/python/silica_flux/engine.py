"""
FluxEngine -- host API for Silica Flux.

    from silica_flux import FluxEngine
    engine = FluxEngine(lanes=8, precision="FP32", backend="reference")
    job = engine.create_job(state=state, parameters=parameters, timestep=dt)
    result = engine.run(job)

Backends
    "reference"  instruction-accurate golden model (python/reference_model)
    "rtl"        compiled RTL (Verilator scenario player, tb/tb_top.sv)
    "both"       runs both and verifies bit-exact agreement (default for
                 validation runs; result.verification reports MATCH/MISMATCH)

A job carries: STATE, PARAMETERS, MODEL COEFFICIENTS, INPUTS, TIMESTEP.
A result carries: NEW STATE, DERIVATIVES, OBJECTIVE, CONSTRAINT RESULTS,
RESIDUALS, DIAGNOSTICS -- each value with its quality flags, so a number is
never presented as physically meaningful merely because arithmetic succeeded.
"""
from __future__ import annotations

import time
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from golden_model import ieee
from golden_model.isa import MEM, FAULTS
from reference_model.scenario import run_reference, compare_results, fault_names
from silica_flux.models import ThermalNetworkModel, Quantity
from silica_flux import workloads

QUALITY_NAMES = {1: "NAN", 2: "OVERFLOW", 4: "UNDERFLOW", 8: "SUSPECT"}


class Job(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    state: Quantity
    parameters: Dict[str, Quantity] = Field(default_factory=dict)
    timestep: float
    steps: int = 24
    method: str = "RK4"
    model: Optional[ThermalNetworkModel] = None
    measured: Optional[List[float]] = None


class Value(BaseModel):
    values: List[float]
    quality: List[int]

    @property
    def clean(self) -> bool:
        return not any(self.quality)

    def flags(self) -> List[str]:
        out = set()
        for q in self.quality:
            for b, n in QUALITY_NAMES.items():
                if q & b:
                    out.add(n)
        return sorted(out)


class JobResult(BaseModel):
    new_state: Value
    trajectory: List[List[float]]
    derivatives: Value
    objective: Value
    constraint_margin_upper: Value
    constraint_margin_lower: Value
    constraints_pass: bool
    residuals: Value
    conservation: Dict[str, float]
    diagnostics: Dict[str, object]
    verification: Dict[str, object] = Field(default_factory=dict)


class FluxEngine:
    def __init__(self, lanes: int = 8, precision: str = "FP32", backend: str = "reference", depth: int = 4):
        if precision not in ("FP32", "FP64"):
            raise ValueError("precision must be FP32 or FP64 (one native format per fabric build)")
        self.lanes = lanes
        self.fp_mode = 1 if precision == "FP64" else 0
        self.fmt = ieee.FP64 if self.fp_mode else ieee.FP32
        self.backend_name = backend
        self.depth = depth
        self._rtl = None

    # ------------------------------------------------------------------ jobs
    def create_job(self, state, parameters: Optional[dict] = None, timestep: float = 1.0, steps: int = 24,
                   method: str = "RK4", model: Optional[ThermalNetworkModel] = None,
                   measured: Optional[List[float]] = None) -> Job:
        if not isinstance(state, Quantity):
            state = Quantity(values=list(state), unit="K")
        state.check("K", "state")
        if len(state.values) != self.lanes:
            raise ValueError(f"state vector must have {self.lanes} elements (one per lane)")
        if timestep <= 0:
            raise ValueError("timestep must be > 0")
        return Job(state=state, parameters=parameters or {}, timestep=timestep, steps=steps, method=method,
                   model=model or workloads.default_thermal_model(self.lanes), measured=measured)

    def _scenario(self, job: Job):
        m = job.model
        for name, q in job.parameters.items():          # parameter overrides (unit-checked)
            field = getattr(m, name)
            q.check(field.unit, name)
            setattr(m, name, q)
        return workloads.thermal_network_scenario(self.fmt, self.lanes, m, t0=job.state.values,
                                                  steps=job.steps, dt=job.timestep, method=job.method,
                                                  measured=job.measured)

    def _rtl_backend(self):
        if self._rtl is None:
            from silica_flux.rtl_backend import VerilatorBackend
            self._rtl = VerilatorBackend(self.lanes, self.fp_mode, self.depth)
        return self._rtl

    # ------------------------------------------------------------------ execution
    def run_scenario(self, sc):
        """run any Scenario on the configured backend(s) -> (memories, registers, verification)"""
        L = self.lanes
        out = {"reference": None, "rtl": None}
        t0 = time.time()
        sim = run_reference(sc, L, self.fp_mode) if self.backend_name in ("reference", "both") else None
        t1 = time.time()
        res = self._rtl_backend().run(sc) if self.backend_name in ("rtl", "both") else None
        t2 = time.time()
        ver = {}
        if sim is not None and res is not None:
            errs = compare_results(sim, res, sc, L)
            ver = {"status": "MATCH" if not errs else "MISMATCH", "errors": errs[:10]}
        if res is not None:
            mem = {mid: rows for mid, rows in res["mem"].items()}
            regs = res["regs"]
        else:
            mem = {mid: sim.dump_memory(mid) for mid in sc.compare}
            regs = {"fault_status": sim.fault_status, "retired": sim.retired, "cycles": None,
                    "state_updates": None, "lane_ops": sim.lane_ops, "ts_step": sim.eng.step}
        ver["reference_seconds"] = round(t1 - t0, 3)
        ver["rtl_seconds"] = round(t2 - t1, 3)
        return mem, regs, ver, sim

    def run(self, job: Job) -> JobResult:
        sc = self._scenario(job)
        mem, regs, ver, sim = self.run_scenario(sc)
        f, L = self.fmt, self.lanes
        rows = mem[MEM["RESULT"]]
        base = sc.meta["base"]

        def val(r):
            return Value(values=[f.to_float(rows[r][l][0]) for l in range(L)], quality=[rows[r][l][1] for l in range(L)])

        traj = [[f.to_float(rows[r][l][0]) for l in range(L)] for r in range(base)]
        names = sc.meta["rows"]
        get = {n: val(base + k) for k, n in enumerate(names)}
        cons = get["conservation"].values
        up, lo = get["margin_tmax"], get["margin_tmin"]
        fs = regs.get("fault_status", 0)
        return JobResult(
            new_state=get["final_T"], trajectory=traj, derivatives=get["derivative_last"],
            objective=Value(values=get["objective"].values[:1], quality=get["objective"].quality[:1]),
            constraint_margin_upper=up, constraint_margin_lower=lo,
            constraints_pass=all(v > 0 for v in up.values) and all(v > 0 for v in lo.values),
            residuals=get["residual"],
            conservation={"invariant": cons[0], "expected": cons[1], "residual": cons[2], "relative": cons[3],
                          "threshold": cons[4], "violation": cons[5]},
            diagnostics={"faults": fault_names(fs), "fault_bits": fs, "cycles": regs.get("cycles"),
                         "retired": regs.get("retired"), "lane_ops": regs.get("lane_ops"),
                         "state_updates": regs.get("state_updates"), "steps": regs.get("ts_step"),
                         "backend": self.backend_name, "instructions": sc.meta["instructions"]},
            verification=ver)
