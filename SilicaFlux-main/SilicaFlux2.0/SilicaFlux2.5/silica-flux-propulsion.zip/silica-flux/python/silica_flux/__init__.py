"""
Silica Flux host software.

    from silica_flux import FluxEngine
    engine = FluxEngine()
    job = engine.create_job(state=state, parameters=parameters, timestep=dt)
    result = engine.run(job)
"""
import sys
from pathlib import Path

_PY = Path(__file__).resolve().parents[1]
if str(_PY) not in sys.path:
    sys.path.insert(0, str(_PY))

from silica_flux.engine import FluxEngine, Job, JobResult, Value  # noqa: E402,F401
from silica_flux.models import Quantity, ThermalNetworkModel, SurrogateDesignModel  # noqa: E402,F401

__version__ = "1.0.0"
