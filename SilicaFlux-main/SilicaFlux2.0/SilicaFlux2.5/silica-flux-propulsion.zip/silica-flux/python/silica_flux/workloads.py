"""
Workload compilers: turn a host model into a Silica Flux program + memory image.

    thermal_network_scenario()  digital-twin transient (lanes = nodes)
        engineering state vector -> STATE memory
        parameters / coefficients -> PARAM / COEFF memory
        vector kernel (VSLIDE neighbour exchange, VPOLY property correlation,
        VINTERP input profile, FMA arithmetic) -> derivative k_s
        STATE_UPDATE (RK4) -> new state, ping-pong state banks
        CONSERVE (energy invariant) and CONSTRAINT (bounds) every step
        telemetry replay -> RESIDUAL (model vs measurement)
        OBJECTIVE (weighted squared error)  -> RESULT memory -> Python / R

    surrogate_sweep_scenario()  design-space exploration (lanes = candidates)
        SWEEP grid generation, Heun transient per candidate, peak tracking,
        CONSTRAINT feasibility, OBJECTIVE, SEARCH arg-min tracking

Memory map of the thermal-network workload (row = one vector):
    STATE  0           initial temperatures T0
    PARAM  0,1,2       C^-1, Gs, Q
    COEFF  0           k(T) correlation coefficients c0..c3
    COEFF  1,2         heater profile table y_j and slopes d_j
    COEFF  3           scalar constants (broadcast loads): dt, 0.5, 1/t_end*(L-1), 0
    COEFF  4           conservation weights C
    COEFF  5,6         T_max, T_min
    COEFF  7,8         objective target, weights
    COEFF  9           residual atol
    RESULT 0..S-1      temperature trajectory (one row per step)
    RESULT S..         final diagnostics (see THERMAL_RESULT_ROWS)
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from golden_model import ieee  # noqa: E402
from golden_model.isa import MEM  # noqa: E402
from generators.assembler import Program  # noqa: E402
from reference_model.scenario import Scenario  # noqa: E402
from silica_flux.driver import telemetry_packet  # noqa: E402
from silica_flux.models import ThermalNetworkModel, SurrogateDesignModel  # noqa: E402

THERMAL_RESULT_ROWS = ["final_T", "residual", "margin_tmax", "margin_tmin", "objective", "conservation",
                       "derivative_last", "time"]


def _row(fmt, vals, lanes):
    v = list(vals) + [0.0] * (lanes - len(vals))
    return ([fmt.from_float(float(x)) for x in v[:lanes]], None)


def default_thermal_model(lanes: int) -> ThermalNetworkModel:
    import math
    L = lanes
    return ThermalNetworkModel(
        capacity={"values": [900.0 + 40.0 * (i % 3) for i in range(L)], "unit": "J/K"},
        link_conductance={"values": [4.0 + 0.5 * math.cos(i) for i in range(L)], "unit": "W/K"},
        heater_amplitude={"values": [120.0 if i % 4 == 0 else 0.0 for i in range(L)], "unit": "W"},
        k_coeffs=[1.0, 1.5e-3, -2.0e-6, 1.0e-9],
        profile=[min(1.0, 2.0 * j / (L - 1)) * (1.0 if j < L - 2 else 0.4) for j in range(L)],
        t_end=60.0,
        t_max={"values": [340.0] * L, "unit": "K"},
        t_min={"values": [290.0] * L, "unit": "K"},
        target={"values": [305.0] * L, "unit": "K"},
        weights=[1.0] * L,
        residual_atol={"values": [0.05] * L, "unit": "K"},
    )


def thermal_network_scenario(fmt, lanes: int, model: ThermalNetworkModel | None = None, t0=None,
                             steps: int = 24, dt: float = 2.5, method: str = "RK4",
                             measured=None, record_trajectory: bool = True):
    L = lanes
    m = model or default_thermal_model(L)
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    T0 = list(t0) if t0 is not None else [300.0 + 0.5 * i for i in range(L)]
    p = Program(prec)
    # ---- constants and model data -------------------------------------------------------
    p.vldbc(20, "COEFF", 0, 3 * L + 0)        # dt
    p.vldbc(21, "COEFF", 0, 3 * L + 1)        # 0.5
    p.vldbc(22, "COEFF", 0, 3 * L + 2)        # (L-1)/t_end  (time -> table coordinate)
    p.vldbc(23, "COEFF", 0, 3 * L + 3)        # t = 0
    p.vload(24, "PARAM", 0, 0)                # C^-1
    p.vload(25, "PARAM", 0, 1)                # Gs
    p.vload(26, "PARAM", 0, 2)                # Q
    p.vload(27, "COEFF", 0, 0)                # k(T) coefficients
    p.vload(28, "COEFF", 0, 1)                # profile y
    p.vload(29, "COEFF", 0, 2)                # profile slopes
    p.vload(30, "COEFF", 0, 4)                # conservation weights C
    p.tscfg(20, method)
    p.vload(1, "STATE", 0, 0)
    p.conserve(31, 1, 30, mode="CAPTURE")     # reference invariant sum C T
    p.seta(1, steps - 1)
    p.seta(3, 0)                              # trajectory row pointer
    stages = {"RK4": 4, "HEUN": 2, "EULER": 1, "MIDPOINT": 2, "RALSTON": 2}[method]
    p.label("step")
    p.vload(1, "STATE", 0, 0)                 # x_n
    p.su_load(2, 1)                           # stage input register v2
    # heater input for this step: q = Q * profile(t * (L-1)/t_end)
    p.vmul(3, 23, 22)
    p.vinterp(4, 3, 28, 29)
    p.vmul(5, 26, 4)                          # q_i
    for s in range(stages):
        p.vslide(6, 2, 1)                     # T_{i+1}
        p.vmul(7, 21, 2)                      # 0.5 T_i
        p.vfma(7, 21, 6, 7)                   # Tbar = 0.5 T_{i+1} + 0.5 T_i
        p.vpoly(8, 7, 27, len(m.k_coeffs) - 1)  # k(Tbar)
        p.vmul(9, 25, 8)                      # G_i
        p.vsub(10, 6, 2)                      # T_{i+1} - T_i
        p.vmul(11, 9, 10)                     # F_i
        p.vslide(12, 11, L - 1)               # F_{i-1}
        p.vsub(13, 11, 12)                    # net link flux
        p.vadd(13, 13, 5)                     # + q_i
        p.vmul(14, 13, 24)                    # k_s = dT/dt
        p.su_stage(2, 14, s)
    # step complete: v2 = x_{n+1}
    p.vstore(2, "STATE_N", 0, 0)
    if record_trajectory:
        p.vstore(2, "RESULT", 3, 0)
        p.adda(3, 1)
    p.vmul(15, 5, 20)                         # sources over the step: q dt
    p.conserve(16, 2, 30, 15, mode="CHECK_ADV")
    p.vload(17, "COEFF", 0, 5)
    p.constraint(18, 2, 17, kind="LT")        # T < T_max
    p.vadd(23, 23, 20)                        # t += dt
    p.barrier(swap=True)
    p.bnz(1, "step")
    # ---- final analysis --------------------------------------------------------------------
    base = steps if record_trajectory else 0
    p.vload(1, "STATE", 0, 0)
    p.vload(9, "COEFF", 0, 9)                 # atol
    if measured is not None:
        p.barrier(telem=True)
        p.vload(10, "TELEM", 0, 0)            # measured temperatures (channels 0..L-1)
    else:
        p.vmov(10, 1)
    p.residual(11, 10, 1, 9, "SIGNED")        # measured - model
    p.vload(17, "COEFF", 0, 5).vload(19, "COEFF", 0, 6)
    p.constraint(12, 1, 17, kind="LT")        # margins to T_max
    p.constraint(13, 1, 19, kind="GT")        # margins to T_min
    p.vload(17, "COEFF", 0, 7).vload(19, "COEFF", 0, 8)
    p.objective(15, 1, 17, 19, "SQ", reduce=True)
    for k, r in enumerate((1, 11, 12, 13, 15, 16, 14, 23)):
        p.vstore(r, "RESULT", 0, base + k)
    p.halt()

    f = fmt
    mem = {
        MEM["STATE"]: {0: _row(f, T0, L)},
        MEM["PARAM"]: {0: _row(f, [1.0 / c for c in m.capacity.values], L),
                       1: _row(f, m.link_conductance.values, L), 2: _row(f, m.heater_amplitude.values, L)},
        MEM["COEFF"]: {0: _row(f, m.k_coeffs, L),
                       1: _row(f, m.profile, L),
                       2: _row(f, [m.profile[j + 1] - m.profile[j] if j + 1 < L else 0.0 for j in range(L)], L),
                       3: _row(f, [dt, 0.5, (L - 1) / m.t_end, 0.0], L),
                       4: _row(f, m.capacity.values, L), 5: _row(f, m.t_max.values, L),
                       6: _row(f, m.t_min.values, L), 7: _row(f, m.target.values, L),
                       8: _row(f, m.weights, L), 9: _row(f, m.residual_atol.values, L)},
    }
    cfg = {"fault_halt": 0, "res_rtol": f.from_float(m.residual_rtol),
           "cons_atol": f.from_float(m.conservation_atol), "cons_rtol": f.from_float(m.conservation_rtol)}
    telem = []
    if measured is not None:
        beats = []
        for c, v in enumerate(measured):
            beats += telemetry_packet(1000 + c, c, c, f.from_float(float(v)), frame_end=(c == len(measured) - 1))
        telem = [beats]
    sc = Scenario(name=f"thermal_network_{method.lower()}", words=p.assemble(), mem_init=mem, config=cfg,
                  compare={MEM["RESULT"]: base + len(THERMAL_RESULT_ROWS)}, telemetry=telem)
    sc.meta = {"steps": steps, "dt": dt, "method": method, "rows": THERMAL_RESULT_ROWS, "base": base,
               "instructions": len(sc.words)}
    return sc


def default_surrogate() -> SurrogateDesignModel:
    return SurrogateDesignModel(capacity=40.0, t_ambient=295.0, t_initial=295.0,
                                k_coeffs=[1.0, 2.0e-3, 0.0, 0.0], steps=60, dt=1.0,
                                target_temperature=330.0, t_limit=345.0, power_weight=0.25, power_ref=150.0,
                                gs_range=(0.25, 0.25, 8), p_range=(20.0, 10.0, 8))


def _surrogate_constants(p):
    p.vldbc(20, "COEFF", 0, 0)                # dt / C
    p.vldbc(21, "COEFF", 0, 1)                # T_amb
    p.vldbc(22, "COEFF", 0, 2)                # T_initial
    p.vldbc(23, "COEFF", 0, 3)                # target temperature
    p.vldbc(24, "COEFF", 0, 4)                # T_limit
    p.vldbc(25, "COEFF", 0, 5)                # 1 / P_ref
    p.vldbc(26, "COEFF", 0, 6)                # power weight
    p.vldbc(27, "COEFF", 0, 7)                # weight 1.0
    p.vload(28, "COEFF", 0, 2)                # k(T) coefficients (row 2)


def _surrogate_kernel(p, m, label: str):
    """v1 = Gs, v2 = P per lane, VM = valid candidates -> v10 = J, v3 = T, v4 = peak, v8 = margin"""
    p.vmov(3, 22)                             # T
    p.vmov(4, 22)                             # peak T
    p.seta(2, m.steps - 1)
    p.label(label)
    p.vsub(5, 3, 21)                          # T - T_amb
    p.vpoly(6, 3, 28, len(m.k_coeffs) - 1)    # k(T)
    p.vmul(6, 6, 1)                           # G = Gs k(T)
    p.vfnma(7, 6, 5, 2)                       # P - G (T - T_amb)
    p.vfma(3, 7, 20, 3)                       # explicit Euler: T += dt/C * rhs
    p.vmax(4, 4, 3)                           # peak tracking
    p.bnz(2, label)
    p.constraint(8, 4, 24, kind="LT", masked=1)          # peak < T_limit (valid candidates only)
    p.vmul(9, 2, 25)                                     # P / P_ref
    p.objective(10, 3, 23, 27, "SQ")                     # (T - T*)^2
    p.vmul(11, 9, 9)
    p.vfma(10, 26, 11, 10)                               # J = (T-T*)^2 + w (P/Pref)^2


def _surrogate_mem(f, m, L):
    return {MEM["COEFF"]: {0: _row(f, [m.dt / m.capacity, m.t_ambient, m.t_initial, m.target_temperature,
                                       m.t_limit, 1.0 / m.power_ref, m.power_weight, 1.0], L),
                           1: _row(f, [0.0] * L, L),
                           2: _row(f, m.k_coeffs, L)}}


def surrogate_local_search_scenario(fmt, lanes: int, center, step, model: SurrogateDesignModel | None = None,
                                    iters: int = 16):
    """bounded compass search around a grid optimum (SEARCH LS_GEN / LOCAL)"""
    L = lanes
    m = model or default_surrogate()
    f = fmt
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    p = Program(prec)
    _surrogate_constants(p)
    p.search("RESET")
    p.seta(1, iters - 1)
    p.seta(3, 0)
    p.label("it")
    p.search("LS_GEN", vd=1, dim=0)          # Gs candidates (VM <- inside bounds)
    p.search("LS_GEN", vd=2, dim=1)          # P candidates
    _surrogate_kernel(p, m, "lt")
    p.search("LOCAL", vs1=10)
    p.vstore(1, "RESULT", 3, 0).vstore(2, "RESULT", 3, 1).vstore(10, "RESULT", 3, 2)
    p.adda(3, 3)
    p.bnz(1, "it")
    p.halt()
    g0, gs, gn = m.gs_range
    p0, ps, pn = m.p_range
    ls = {"dims": 2, "max_iter": iters,
          "lo": [f.from_float(g0), f.from_float(p0), 0, 0],
          "hi": [f.from_float(g0 + gs * (gn - 1)), f.from_float(p0 + ps * (pn - 1)), 0, 0],
          "center0": [f.from_float(center[0]), f.from_float(center[1]), 0, 0],
          "step0": [f.from_float(step[0]), f.from_float(step[1]), 0, 0],
          "min_step": [f.from_float(gs / 64), f.from_float(ps / 64), 0, 0]}
    sc = Scenario(name="surrogate_local_search", words=p.assemble(), mem_init=_surrogate_mem(f, m, L),
                  config={"fault_halt": 0, "search": ls}, compare={MEM["RESULT"]: iters * 3})
    sc.meta = {"iters": iters, "model": m.model_dump()}
    return sc


def surrogate_sweep_scenario(fmt, lanes: int, model: SurrogateDesignModel | None = None):
    """grid sweep: P0 = Gs (dim 0), P1 = P (dim 1); one candidate per lane"""
    L = lanes
    m = model or default_surrogate()
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    f = fmt
    total = m.gs_range[2] * m.p_range[2]
    batches = (total + L - 1) // L
    p = Program(prec)
    _surrogate_constants(p)
    p.sweep("RESET").search("RESET")
    p.seta(1, batches - 1)
    p.seta(3, 0)
    p.label("batch")
    p.sweep("GEN", vd=1, dim=0)              # Gs per lane (VM <- valid candidates)
    p.sweep("GEN", vd=2, dim=1)              # P per lane
    _surrogate_kernel(p, m, "t")
    p.search("GRID", vs1=10)
    p.vstore(10, "RESULT", 3, 0)
    p.vstore(3, "RESULT", 3, 1)
    p.vstore(4, "RESULT", 3, 2)
    p.vstore(8, "RESULT", 3, 3)
    p.adda(3, 4)
    p.sweep("NEXT")
    p.bnz(1, "batch")
    p.halt()
    mem = _surrogate_mem(f, m, L)
    sw = {"dims": 2, "lo": [f.from_float(m.gs_range[0]), f.from_float(m.p_range[0]), 0, 0],
          "step": [f.from_float(m.gs_range[1]), f.from_float(m.p_range[1]), 0, 0],
          "count": [m.gs_range[2], m.p_range[2], 1, 1]}
    sc = Scenario(name="surrogate_design_sweep", words=p.assemble(), mem_init=mem,
                  config={"fault_halt": 0, "sweep": sw}, compare={MEM["RESULT"]: batches * 4})
    sc.meta = {"batches": batches, "total": total, "model": m.model_dump()}
    return sc
