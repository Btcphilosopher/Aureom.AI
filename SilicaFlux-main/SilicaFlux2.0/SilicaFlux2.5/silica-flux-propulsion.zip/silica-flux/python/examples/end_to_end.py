#!/usr/bin/env python3
"""
Silica Flux end-to-end example workload (abstract, non-flight-critical).

  engineering state vector -> parameter memory -> vector numerical kernel
  -> FMA / polynomial / interpolation -> RK4 state update -> conservation
  residual -> constraint evaluation -> objective -> result buffer
  -> Python / R analysis

Part 1  digital twin of a lumped thermal network (8 nodes on a ring) with a
        replayed telemetry snapshot; the model-vs-measurement residual flags a
        deliberately biased sensor channel.
Part 2  design-space exploration of a 0-D heated-element surrogate: 64
        candidates evaluated LANES at a time by the sweep/search engines.

Run:  python3 python/examples/end_to_end.py [--backend both|reference|rtl] [--lanes 8]
Outputs: reports/workload/*.csv, reports/workload/summary.json
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))

from silica_flux import FluxEngine  # noqa: E402
from silica_flux import workloads  # noqa: E402
from golden_model.isa import MEM  # noqa: E402

OUT = ROOT / "reports" / "workload"


def part1(engine: FluxEngine, lanes: int) -> dict:
    # reference trajectory, then a "measured" snapshot = reference + sensor effects
    ref_engine = FluxEngine(lanes=lanes, precision="FP32", backend="reference")
    t0 = [300.0 + 0.5 * i for i in range(lanes)]
    probe = ref_engine.run(ref_engine.create_job(state=t0, timestep=2.5, steps=24))
    measured = [v + (0.01 if i % 2 else -0.01) for i, v in enumerate(probe.new_state.values)]
    measured[3] += 0.8                                   # biased sensor on channel 3
    job = engine.create_job(state=t0, timestep=2.5, steps=24, method="RK4", measured=measured)
    r = engine.run(job)
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "thermal_trajectory.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["step", "time_s"] + [f"T{i}" for i in range(lanes)])
        for k, row in enumerate(r.trajectory):
            w.writerow([k + 1, 2.5 * (k + 1)] + row)
    with open(OUT / "thermal_final.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["node", "T_final", "residual", "residual_quality", "margin_tmax", "margin_tmin", "dTdt"])
        for i in range(lanes):
            w.writerow([i, r.new_state.values[i], r.residuals.values[i], r.residuals.quality[i],
                        r.constraint_margin_upper.values[i], r.constraint_margin_lower.values[i],
                        r.derivatives.values[i]])
    flagged = [i for i, q in enumerate(r.residuals.quality) if q & 8]
    print(f"[part 1] final T = {[round(v, 3) for v in r.new_state.values]}")
    print(f"[part 1] objective J = {r.objective.values[0]:.4f}  constraints pass = {r.constraints_pass}")
    print(f"[part 1] conservation residual = {r.conservation['residual']:.3e} J "
          f"(threshold {r.conservation['threshold']:.3e} J)")
    print(f"[part 1] residual-flagged sensor channels = {flagged}  faults = {r.diagnostics['faults']}")
    print(f"[part 1] verification = {r.verification.get('status', 'n/a')}  cycles = {r.diagnostics['cycles']}")
    return {"final_T": r.new_state.values, "objective": r.objective.values[0], "constraints_pass": r.constraints_pass,
            "conservation": r.conservation, "flagged_channels": flagged, "diagnostics": r.diagnostics,
            "verification": r.verification}


def part2(engine: FluxEngine, lanes: int) -> dict:
    sc = workloads.surrogate_sweep_scenario(engine.fmt, lanes)
    mem, regs, ver, sim = engine.run_scenario(sc)
    f = engine.fmt
    m = sc.meta["model"]
    rows = mem[MEM["RESULT"]]
    cands = []
    for b in range(sc.meta["batches"]):
        for l in range(lanes):
            idx = b * lanes + l
            if idx >= sc.meta["total"]:
                continue
            gi, pi = idx % m["gs_range"][2], idx // m["gs_range"][2]
            gs = m["gs_range"][0] + gi * m["gs_range"][1]
            pw = m["p_range"][0] + pi * m["p_range"][1]
            J, T, Tpk, margin = (f.to_float(rows[4 * b + k][l][0]) for k in range(4))
            cands.append({"index": idx, "Gs": gs, "P": pw, "J": J, "T_final": T, "T_peak": Tpk,
                          "margin": margin, "feasible": margin > 0})
    with open(OUT / "design_sweep.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(cands[0].keys()))
        w.writeheader()
        w.writerows(cands)
    best_idx = regs.get("sr_best_idx")
    if best_idx is None and sim is not None:
        best_idx = sim.eng.sr_best_idx
    best = next(c for c in cands if c["index"] == best_idx)
    feas = [c for c in cands if c["feasible"]]
    sw_best = min(feas, key=lambda c: c["J"])
    print(f"[part 2] {len(cands)} candidates, {len(feas)} feasible; hardware arg-min index {best_idx} "
          f"(Gs={best['Gs']}, P={best['P']}, J={best['J']:.4f}); host check index {sw_best['index']}")
    print(f"[part 2] verification = {ver.get('status', 'n/a')}  cycles = {regs.get('cycles')}")
    # bounded local search refinement around the grid optimum
    ls = workloads.surrogate_local_search_scenario(engine.fmt, lanes, (best["Gs"], best["P"]),
                                                   (m["gs_range"][1] / 2, m["p_range"][1] / 2))
    lmem, lregs, lver, lsim = engine.run_scenario(ls)
    lrows = lmem[MEM["RESULT"]]
    traj = []
    for it in range(ls.meta["iters"]):
        gsv = f.to_float(lrows[3 * it][lanes - 1][0])
        pv = f.to_float(lrows[3 * it + 1][lanes - 1][0])
        jv = f.to_float(lrows[3 * it + 2][lanes - 1][0])
        traj.append({"iter": it, "Gs_center": gsv, "P_center": pv, "J_center": jv})
    with open(OUT / "local_search.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(traj[0].keys()))
        w.writeheader()
        w.writerows(traj)
    print(f"[part 2] local search: J {traj[0]['J_center']:.4f} -> {traj[-1]['J_center']:.4f} at "
          f"Gs={traj[-1]['Gs_center']:.4f}, P={traj[-1]['P_center']:.3f}  verification = {lver.get('status', 'n/a')}")
    ver = {"status": "MATCH" if ver.get("status", "MATCH") == "MATCH" and lver.get("status", "MATCH") == "MATCH"
           else "MISMATCH", "grid": ver, "local": lver}
    return {"local_search_final": traj[-1],
            "best_index": best_idx, "best": best, "host_check_index": sw_best["index"],
            "feasible": len(feas), "candidates": len(cands), "verification": ver,
            "cycles": regs.get("cycles")}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", default="both")
    ap.add_argument("--lanes", type=int, default=8)
    a = ap.parse_args()
    eng = FluxEngine(lanes=a.lanes, precision="FP32", backend=a.backend)
    s = {"part1": part1(eng, a.lanes), "part2": part2(eng, a.lanes), "backend": a.backend, "lanes": a.lanes}
    (OUT / "summary.json").write_text(json.dumps(s, indent=2, default=str))
    ok = all(p.get("verification", {}).get("status", "MATCH") == "MATCH" for p in (s["part1"], s["part2"]))
    print("END-TO-END WORKLOAD:", "MATCH" if ok else "MISMATCH")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
