"""
Full-chip cocotb regression (rtl/top/silica_flux_top.sv).

Every test builds a program with the Python assembler, runs it on the RTL
through the AXI-Lite host driver AND on the instruction-accurate reference
model, and compares memories (values + quality bits), IEEE flags and the
fault record bit-exactly.
"""
from __future__ import annotations

import json
import random

import cocotb

from sf_cocotb import REPORT_DIR, env_int, start
from sf_host import FluxHost
from sf_scenario import Scenario, compare, run_reference, run_rtl, fault_names
from golden_model import ieee
from golden_model.isa import MEM, F
from generators.assembler import Program
from generators import programs
from silica_flux import regmap as R


def ctx():
    lanes = env_int("SF_LANES", 8)
    fp_mode = env_int("SF_FP_MODE", 0)
    fmt = ieee.FP64 if fp_mode else ieee.FP32
    return lanes, fp_mode, fmt


async def run_and_check(dut, host, sc: Scenario, lanes: int, fp_mode: int, record: dict | None = None):
    sim = run_reference(sc, lanes, fp_mode)
    await run_rtl(host, sc)
    errs = await compare(host, sim, sc, dut._log)
    perf = await host.perf()
    for e in errs:
        dut._log.error(f"[{sc.name}] {e}")
    dut._log.info(f"[{sc.name}] retired={perf['retired']} cycles={perf['cycles']} lane_ops={perf['lane_ops']} "
                  f"faults={fault_names(sim.fault_status)} -> {'MATCH' if not errs else 'MISMATCH'}")
    if record is not None:
        record[sc.name] = {"match": not errs, "errors": errs[:5], "perf": perf, "ref_retired": sim.retired,
                           "ref_faults": fault_names(sim.fault_status), "lane_ops_ref": sim.lane_ops}
    # clear faults for the next scenario
    await host.write(R.FAULT_STATUS, 0xFFFFFF)
    await host.write(R.FFLAGS, 0x1F)
    return errs


def save(name: str, rec: dict):
    (REPORT_DIR / "cocotb_top").mkdir(parents=True, exist_ok=True)
    (REPORT_DIR / "cocotb_top" / f"{name}.json").write_text(json.dumps(rec, indent=2, default=str))


@cocotb.test()
async def t01_identity(dut):
    lanes, fp_mode, fmt = ctx()
    await start(dut)
    h = FluxHost(dut, fp_mode, lanes)
    assert await h.read(R.ID) == 0x53464C58
    cfg = await h.read(R.CONFIG0)
    assert cfg & 0xFF == lanes and (cfg >> 8) & 0xFF == fmt.width and (cfg >> 16) & 1 == fp_mode
    dut._log.info(f"SILICA FLUX id ok: lanes={lanes} width={fmt.width} depth={(cfg >> 20) & 15}")


@cocotb.test()
async def t02_directed_programs(dut):
    lanes, fp_mode, fmt = ctx()
    await start(dut)
    h = FluxHost(dut, fp_mode, lanes)
    rec = {}
    bad = 0
    for sc in programs.directed_suite(fmt, lanes):
        errs = await run_and_check(dut, h, sc, lanes, fp_mode, rec)
        bad += bool(errs)
    save(f"directed_{fmt.name}_l{lanes}", rec)
    assert bad == 0, f"{bad} directed programs mismatched"


@cocotb.test()
async def t03_random_programs(dut):
    lanes, fp_mode, fmt = ctx()
    await start(dut)
    h = FluxHost(dut, fp_mode, lanes)
    rec = {}
    bad = 0
    n = env_int("SF_NPROG", 4)
    for k in range(n):
        sc = programs.random_program(fmt, lanes, seed=env_int("SF_SEED", 3) * 1000 + k, length=env_int("SF_PLEN", 40))
        errs = await run_and_check(dut, h, sc, lanes, fp_mode, rec)
        bad += bool(errs)
    save(f"random_{fmt.name}_l{lanes}", rec)
    assert bad == 0, f"{bad} random programs mismatched"


@cocotb.test()
async def t04_job_isolation(dut):
    """START initialises the job state: a register or mask left by an earlier
    job is not silently visible to the next one (reference: fresh state)."""
    lanes, fp_mode, fmt = ctx()
    await start(dut)
    h = FluxHost(dut, fp_mode, lanes)
    prec = "FP64" if fp_mode else "FP32"
    row = ([fmt.from_float(1.0 + l) for l in range(lanes)], None)
    init = {MEM["STATE"]: {0: row}}
    # job A: writes v5 and clears the vector mask
    a = Program(prec)
    a.vload(5, "STATE", 0, 0).vmset("NOT").vstore(5, "RESULT", 0, 0).halt()
    sa = Scenario(name="job_a_writes_v5_and_vm", words=a.assemble(), mem_init=init, config={"fault_halt": 0},
                  compare={MEM["RESULT"]: 1})
    # job B: a masked op relying on VM = all ones, then a read of v5 without writing it
    b = Program(prec)
    b.vload(1, "STATE", 0, 0).vneg(2, 1).vneg(2, 1, masked=1).vstore(2, "RESULT", 0, 1)
    b.vadd(3, 5, 1).vstore(3, "RESULT", 0, 2).halt()
    sb = Scenario(name="job_b_sees_fresh_state", words=b.assemble(), mem_init=init, compare={MEM["RESULT"]: 3},
                  expect_halt=True)
    rec = {}
    bad = 0
    for sc in (sa, sb):
        bad += bool(await run_and_check(dut, h, sc, lanes, fp_mode, rec))
    save(f"isolation_{fmt.name}_l{lanes}", rec)
    assert bad == 0, "job isolation mismatch"
