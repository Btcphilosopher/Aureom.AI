"""
Shared cocotb infrastructure for Silica Flux.

* ``start(dut)``              -- clock + synchronous active-low reset
* ``HandshakeHarness``        -- single-coroutine valid/ready driver + monitor
                                 with randomised back-pressure; records the
                                 accept and completion cycle of every
                                 transaction (latency distributions)
* ``ErrorStats``              -- absolute / relative / ULP error accumulation
                                 (max, mean, RMS, failure count) written as CSV
                                 and JSON for the R statistical layer.

Comparisons are always made on raw bit patterns and exact rationals, never on
decimal strings.
"""
from __future__ import annotations

import csv
import json
import math
import os
import random
import sys
from dataclasses import dataclass, field
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import cocotb  # noqa: E402
from cocotb.clock import Clock  # noqa: E402
from cocotb.triggers import ReadOnly, RisingEdge  # noqa: E402

REPORT_DIR = Path(os.environ.get("SF_REPORT_DIR", HERE.parent.parent / "reports"))


def env_int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


QUIET_INPUTS = ("in_valid", "out_ready", "req_valid", "rsp_ready", "s_axis_tvalid", "m_axis_tready",
                "awvalid", "wvalid", "arvalid", "bready", "rready", "push", "pop", "start")


async def start(dut, period_ns: int = 10, reset_cycles: int = 4, init: dict | None = None):
    """Start the clock and apply reset.  Handshake inputs are driven to 0 before
    reset is released (an undriven valid would otherwise be sampled as Z)."""
    Clock(dut.clk, period_ns, unit="ns").start(start_high=False)
    for name in QUIET_INPUTS:
        if hasattr(dut, name):
            getattr(dut, name).value = 0
    for name, v in (init or {}).items():
        getattr(dut, name).value = v
    dut.rst_n.value = 0
    for _ in range(reset_cycles):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


def uval(sig) -> int:
    return int(sig.value)


@dataclass
class Txn:
    fields: dict
    meta: object = None
    t_accept: int = -1
    t_done: int = -1
    out: dict = field(default_factory=dict)


class HandshakeHarness:
    """Drive `in_valid/in_ready` + payload, observe `out_valid/out_ready`.

    ``in_fields``  : name -> dut handle
    ``out_fields`` : name -> dut handle
    The DUT must preserve order (all Silica Flux pipelines do; the tag field is
    checked by the caller when present).
    """

    def __init__(self, dut, in_fields: dict, out_fields: dict,
                 in_valid="in_valid", in_ready="in_ready",
                 out_valid="out_valid", out_ready="out_ready",
                 seed: int = 7, backpressure: float = 0.2, gap: float = 0.1):
        self.dut = dut
        self.in_fields, self.out_fields = in_fields, out_fields
        self.iv, self.ir = getattr(dut, in_valid), getattr(dut, in_ready)
        self.ov, self.orr = getattr(dut, out_valid), getattr(dut, out_ready)
        self.rnd = random.Random(seed)
        self.bp, self.gap = backpressure, gap
        self.cycle = 0

    async def run(self, txns: list[Txn], timeout_per_txn: int = 400) -> list[Txn]:
        pending = list(txns)
        inflight: list[Txn] = []
        done: list[Txn] = []
        idx = 0
        limit = timeout_per_txn * max(1, len(txns)) + 1000
        self.iv.value = 0
        self.orr.value = 0
        while len(done) < len(txns):
            drive = idx < len(pending) and self.rnd.random() >= self.gap
            if drive:
                for k, h in self.in_fields.items():
                    h.value = pending[idx].fields[k]
            self.iv.value = 1 if drive else 0
            ordy = self.rnd.random() >= self.bp
            self.orr.value = 1 if ordy else 0
            await ReadOnly()
            if drive and int(self.ir.value):
                pending[idx].t_accept = self.cycle
                inflight.append(pending[idx])
                idx += 1
            if ordy and int(self.ov.value):
                t = inflight.pop(0)
                t.t_done = self.cycle
                t.out = {k: int(h.value) for k, h in self.out_fields.items()}
                done.append(t)
            await RisingEdge(self.dut.clk)
            self.cycle += 1
            if self.cycle > limit:
                raise TimeoutError(f"handshake timeout: {len(done)}/{len(txns)} complete")
        self.iv.value = 0
        return done


class ErrorStats:
    """Accumulates numerical error of RTL results against an exact reference."""

    def __init__(self, name: str):
        self.name = name
        self.n = 0
        self.fail = 0
        self.ulp = []          # finite comparisons only
        self.abs_err = []
        self.rel_err = []
        self.latency = []
        self.rows = []

    def add(self, *, ok: bool, ulp: float | None = None, abs_err: float | None = None,
            rel_err: float | None = None, latency: int | None = None, row: dict | None = None):
        self.n += 1
        if not ok:
            self.fail += 1
        if ulp is not None and math.isfinite(ulp):
            self.ulp.append(ulp)
        if abs_err is not None and math.isfinite(abs_err):
            self.abs_err.append(abs_err)
        if rel_err is not None and math.isfinite(rel_err):
            self.rel_err.append(rel_err)
        if latency is not None:
            self.latency.append(latency)
        if row is not None:
            self.rows.append(row)

    @staticmethod
    def _summ(v):
        if not v:
            return {"max": 0.0, "mean": 0.0, "rms": 0.0}
        return {"max": max(v), "mean": sum(v) / len(v), "rms": math.sqrt(sum(x * x for x in v) / len(v))}

    def summary(self) -> dict:
        lat = self.latency
        return {
            "name": self.name, "count": self.n, "failures": self.fail,
            "ulp": self._summ(self.ulp), "abs": self._summ(self.abs_err), "rel": self._summ(self.rel_err),
            "latency": {"min": min(lat) if lat else 0, "max": max(lat) if lat else 0,
                        "mean": (sum(lat) / len(lat)) if lat else 0.0},
        }

    def write(self):
        REPORT_DIR.mkdir(parents=True, exist_ok=True)
        (REPORT_DIR / "numerics").mkdir(exist_ok=True)
        with open(REPORT_DIR / "numerics" / f"{self.name}.json", "w") as f:
            json.dump(self.summary(), f, indent=2)
        if self.rows:
            keys = list(self.rows[0].keys())
            with open(REPORT_DIR / "numerics" / f"{self.name}.csv", "w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=keys)
                w.writeheader()
                w.writerows(self.rows)
        return self.summary()
