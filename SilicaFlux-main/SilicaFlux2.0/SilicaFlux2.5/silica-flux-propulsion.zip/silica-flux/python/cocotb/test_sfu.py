"""
cocotb regression for the special-function units:
    rtl/alu/reciprocal_unit.sv, rtl/math/exp_unit.sv, rtl/math/log_unit.sv

Two independent checks per vector:
  1. bit-exact agreement (value + flags) with the fixed-point golden model
     python/golden_model/sfu.py  -> proves the RTL implements the algorithm;
  2. ULP error of the RTL result against an 80-digit decimal reference
     -> characterises the algorithm's accuracy (reported, bounded by assert).
"""
from __future__ import annotations

import random

import cocotb

from sf_cocotb import ErrorStats, HandshakeHarness, Txn, env_int, start
from golden_model import ieee, sfu
from generators.gen_sfu_tables import ref_value, sample_inputs
from generators.stimulus import special_values

FUNCS = {0: "recip", 1: "exp", 2: "log"}


@cocotb.test()
async def sfu_regression(dut):
    fmt = ieee.FP64 if env_int("SF_EXP_W", 8) == 11 else ieee.FP32
    func = FUNCS[env_int("SF_FUNC", 0)]
    n = env_int("SF_N", 500)
    await start(dut)
    rnd = random.Random(env_int("SF_SEED", 31))
    xs = sample_inputs(func, fmt, n, rnd) + special_values(fmt)
    xs += [rnd.getrandbits(fmt.width) for _ in range(n // 4)]
    txns = [Txn({"a": x, "in_tag": i & 0xFF}, meta=x) for i, x in enumerate(xs)]
    h = HandshakeHarness(dut, {"a": dut.a, "in_tag": dut.in_tag},
                         {k: getattr(dut, k) for k in ("result", "fflags", "out_tag")},
                         seed=env_int("SF_SEED", 31), backpressure=0.25)
    done = await h.run(txns, timeout_per_txn=100)
    fn = sfu.SFU_FUNCS[func]
    st = ErrorStats(f"{func}_{fmt.name}")
    bad = []
    max_ulp_bound = 0.51
    for t in done:
        x = t.meta
        ref, rff = fn(fmt, x)
        got, gff = t.out["result"], t.out["fflags"]
        ok = got == ref and gff == rff and t.out["out_tag"] == t.fields["in_tag"]
        ulp = None
        if fmt.is_finite(got) and fmt.is_finite(x) and not fmt.is_zero(x) and not (func == "log" and fmt.sign(x)):
            exact = ref_value(func, fmt, x)
            if abs(exact) <= fmt.to_fraction(fmt.max_finite(0)):
                ulp = ieee.ulp_error(fmt, got, exact)
        st.add(ok=ok, ulp=ulp, latency=t.t_done - t.t_accept,
               row={"func": func, "x": hex(x), "rtl": hex(got), "ref": hex(ref), "rtl_flags": gff, "ref_flags": rff,
                    "x_float": fmt.to_float(x), "ulp_err": -1 if ulp is None else ulp,
                    "latency": t.t_done - t.t_accept, "match": int(ok)})
        if not ok and len(bad) < 10:
            bad.append(f"{func} x={x:#x} ({fmt.to_float(x)!r}) rtl={got:#x}/{ieee.flags_str(gff)} "
                       f"ref={ref:#x}/{ieee.flags_str(rff)}")
    s = st.write()
    for m in bad:
        dut._log.error(m)
    dut._log.info(f"{s['name']}: {s['count']} vectors, {s['failures']} failures, max ulp {s['ulp']['max']:.4f}, "
                  f"mean {s['ulp']['mean']:.4f}, latency {s['latency']}")
    assert s["failures"] == 0
    assert s["ulp"]["max"] <= max_ulp_bound
