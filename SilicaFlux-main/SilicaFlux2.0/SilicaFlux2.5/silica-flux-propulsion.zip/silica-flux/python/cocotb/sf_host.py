"""
cocotb host driver for silica_flux_top: an AXI4-Lite master plus the
high-level operations a host driver performs (program load, memory window,
engine configuration, run, fault/status readout, AXI-Stream DMA traffic).
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cocotb.triggers import ReadOnly, RisingEdge  # noqa: E402

from silica_flux import regmap as R  # noqa: E402
from golden_model.isa import MEM  # noqa: E402


class FluxHost:
    def __init__(self, dut, fp_mode: int = 0, lanes: int = 8):
        self.dut = dut
        self.fp_mode = fp_mode
        self.lanes = lanes
        self.W = 64 if fp_mode else 32
        self.axi_ops = 0
        for s in ("s_axil_awvalid", "s_axil_wvalid", "s_axil_bready", "s_axil_arvalid", "s_axil_rready",
                  "s_axis_tvalid", "m_axis_tready"):
            getattr(dut, s).value = 0
        dut.s_axil_wstrb.value = 0xF
        self._sel = self._row = self._lane = None

    async def _edge(self):
        await RisingEdge(self.dut.clk)

    # ------------------------------------------------------------------ AXI-Lite
    async def write(self, addr: int, data: int):
        d = self.dut
        d.s_axil_awaddr.value = addr
        d.s_axil_wdata.value = data & 0xFFFFFFFF
        d.s_axil_awvalid.value = 1
        d.s_axil_wvalid.value = 1
        aw = w = False
        while not (aw and w):
            await ReadOnly()
            aw_hit = (not aw) and int(d.s_axil_awready.value)
            w_hit = (not w) and int(d.s_axil_wready.value)
            await self._edge()
            if aw_hit:
                aw = True
                d.s_axil_awvalid.value = 0
            if w_hit:
                w = True
                d.s_axil_wvalid.value = 0
        d.s_axil_bready.value = 1
        while True:
            await ReadOnly()
            b = int(d.s_axil_bvalid.value)
            await self._edge()
            if b:
                break
        d.s_axil_bready.value = 0
        self.axi_ops += 1

    async def read(self, addr: int) -> int:
        d = self.dut
        d.s_axil_araddr.value = addr
        d.s_axil_arvalid.value = 1
        while True:
            await ReadOnly()
            r = int(d.s_axil_arready.value)
            await self._edge()
            if r:
                break
        d.s_axil_arvalid.value = 0
        d.s_axil_rready.value = 1
        while True:
            await ReadOnly()
            v = int(d.s_axil_rvalid.value)
            data = int(d.s_axil_rdata.value) if v else 0
            await self._edge()
            if v:
                break
        d.s_axil_rready.value = 0
        self.axi_ops += 1
        return data

    async def write64(self, addr: int, value: int):
        await self.write(addr, value & 0xFFFFFFFF)
        await self.write(addr + 4, (value >> 32) & 0xFFFFFFFF)

    async def read64(self, addr: int) -> int:
        lo = await self.read(addr)
        hi = await self.read(addr + 4) if self.W == 64 else 0
        return lo | (hi << 32)

    # ------------------------------------------------------------------ program / memory
    async def load_program(self, words: list[int], base: int = 0):
        await self.write(R.IMEM_ADDR, base)
        for w in words:
            await self.write(R.IMEM_WLO, w & 0xFFFFFFFF)
            await self.write(R.IMEM_WHI, (w >> 32) & 0xFFFFFFFF)

    async def _select(self, mem: int, row: int, lane: int):
        if self._sel != mem:
            await self.write(R.MEM_SEL, mem)
            self._sel = mem
        if self._row != row:
            await self.write(R.MEM_ROW, row)
            self._row = row
        if self._lane != lane:
            await self.write(R.MEM_LANE, lane)
            self._lane = lane

    async def write_element(self, mem: int, row: int, lane: int, value: int, qual: int = 0):
        await self._select(mem, row, lane)
        await self.write(R.MEM_WLO, value & 0xFFFFFFFF)
        if self.W == 64:
            await self.write(R.MEM_WHI, (value >> 32) & 0xFFFFFFFF)
        await self.write(R.MEM_WQUAL, qual)
        await self.write(R.MEM_CMD, 1)
        await self._wait_window()

    async def _wait_window(self):
        for _ in range(1000):
            st = await self.read(R.MEM_RSTATUS)
            if not st >> 31:
                return st
        raise TimeoutError("memory window stuck")

    async def read_element(self, mem: int, row: int, lane: int):
        await self._select(mem, row, lane)
        await self.write(R.MEM_CMD, 2)
        st = await self._wait_window()
        lo = await self.read(R.MEM_RLO)
        hi = await self.read(R.MEM_RHI) if self.W == 64 else 0
        return lo | (hi << 32), st & 0xF, (st >> 8) & 1, (st >> 9) & 1

    async def write_row(self, mem: int, row: int, values, quals=None):
        for l, v in enumerate(values):
            await self.write_element(mem, row, l, v, 0 if quals is None else quals[l])

    async def read_rows(self, mem: int, rows: int):
        out = []
        for r in range(rows):
            out.append([await self.read_element(mem, r, l) for l in range(self.lanes)])
        return out

    # ------------------------------------------------------------------ control
    async def start(self, pc: int = 0):
        await self.write(R.START_PC, pc)
        await self.write(R.CTRL, R.CTRL_START)

    async def wait_done(self, timeout_cycles: int = 2_000_000, poll: int = 64) -> int:
        n = 0
        while n < timeout_cycles:
            st = await self.read(R.STATUS)
            if st & R.ST_DONE and not st & R.ST_RUNNING:
                return st
            for _ in range(poll):
                await self._edge()
            n += poll + 6
        raise TimeoutError("program did not finish")

    async def faults(self) -> dict:
        return {"status": await self.read(R.FAULT_STATUS), "first": await self.read(R.FAULT_FIRST),
                "pc": await self.read(R.FAULT_PC), "count": await self.read(R.FAULT_COUNT),
                "fflags": await self.read(R.FFLAGS)}

    async def perf(self) -> dict:
        keys = {"cycles": R.PERF_CYCLES, "retired": R.PERF_RETIRED, "issued": R.PERF_ISSUED,
                "stalls": R.PERF_STALLS, "lane_ops": R.PERF_LANE_OPS, "loads": R.PERF_LOADS,
                "stores": R.PERF_STORES, "state_updates": R.PERF_STATE_UPD,
                "bus_accesses": R.BUS_ACCESSES, "bus_conflicts": R.BUS_CONFLICTS}
        out = {k: await self.read(a) for k, a in keys.items()}
        out["fu_busy"] = [await self.read(R.PERF_FU_BUSY + 4 * f) for f in range(15)]
        return out

    # ------------------------------------------------------------------ engine configuration
    async def set_fp(self, addr: int, bits: int):
        await self.write64(addr, bits)

    async def configure(self, cfg: dict):
        """cfg keys mirror reference_model.isa_sim engine fields."""
        if "res_rtol" in cfg:
            await self.set_fp(R.RES_RTOL, cfg["res_rtol"])
        if "cons_atol" in cfg:
            await self.set_fp(R.CONS_ATOL, cfg["cons_atol"])
        if "cons_rtol" in cfg:
            await self.set_fp(R.CONS_RTOL, cfg["cons_rtol"])
        if "fault_halt" in cfg:
            await self.write(R.FAULT_HALT, cfg["fault_halt"])
        if "frm" in cfg:
            await self.write(R.FRM, cfg["frm"])
        if "custom_tableau" in cfg:
            stages, A, b = cfg["custom_tableau"]
            await self.write(R.TS_STAGES, stages)
            for slot, v in enumerate(list(A) + list(b)):
                await self.write(R.TS_TAB_SEL, slot)
                await self.set_fp(R.TS_TAB, v)
        if "sweep" in cfg:
            sw = cfg["sweep"]
            await self.write(R.SW_DIMS, sw["dims"])
            for d in range(4):
                await self.write(R.SW_DSEL, d)
                await self.set_fp(R.SW_LO, sw["lo"][d])
                await self.set_fp(R.SW_STEP, sw["step"][d])
                await self.write(R.SW_COUNT, sw["count"][d])
        if "search" in cfg:
            ls = cfg["search"]
            await self.write(R.LS_DIMS, ls["dims"])
            await self.write(R.LS_MAX_ITER, ls["max_iter"])
            for d in range(4):
                await self.write(R.LS_DSEL, d)
                for fsel, key in ((R.LS_LO, "lo"), (R.LS_HI, "hi"), (R.LS_CENTER0, "center0"),
                                  (R.LS_STEP0, "step0"), (R.LS_MIN_STEP, "min_step")):
                    await self.write(R.LS_FSEL, fsel)
                    await self.set_fp(R.LS_VAL, ls[key][d])
        for m, (p, s) in cfg.get("mem_prec", {}).items():
            await self.write(R.MEM_PREC + 4 * m, p | (s << 8))

    # ------------------------------------------------------------------ AXI-Stream
    async def stream_in(self, beats):
        """beats: list of (data64, user8, last)"""
        d = self.dut
        for data, user, last in beats:
            d.s_axis_tdata.value = data
            d.s_axis_tuser.value = user
            d.s_axis_tlast.value = int(last)
            d.s_axis_tvalid.value = 1
            while True:
                await ReadOnly()
                r = int(d.s_axis_tready.value)
                await self._edge()
                if r:
                    break
        d.s_axis_tvalid.value = 0

    async def stream_out(self, n: int, max_cycles: int = 100000):
        d = self.dut
        out = []
        d.m_axis_tready.value = 1
        c = 0
        while len(out) < n and c < max_cycles:
            await ReadOnly()
            if int(d.m_axis_tvalid.value):
                out.append((int(d.m_axis_tdata.value), int(d.m_axis_tuser.value), int(d.m_axis_tlast.value)))
            await self._edge()
            c += 1
        d.m_axis_tready.value = 0
        return out
