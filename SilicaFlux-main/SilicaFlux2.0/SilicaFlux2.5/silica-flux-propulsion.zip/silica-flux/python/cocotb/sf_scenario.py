"""
cocotb glue for scenarios (see reference_model/scenario.py): load and run a
scenario through the AXI-Lite host driver and compare against the reference.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from reference_model.scenario import (Scenario, run_reference, apply_config_to_sim, fault_names)  # noqa: E402,F401
from golden_model.isa import MEM  # noqa: E402


async def load_rtl(host, sc: Scenario):
    await host.configure(sc.config)
    await host.load_program(sc.words)
    for mid, rows in sc.mem_init.items():
        for row, (vals, quals) in rows.items():
            await host.write_row(mid, row, vals, quals)


async def run_rtl(host, sc: Scenario, timeout: int = 4_000_000):
    await load_rtl(host, sc)
    await host.start(0)
    status = await host.wait_done(timeout_cycles=timeout)
    return status


async def compare(host, sim: FluxISASim, sc: Scenario, log) -> list[str]:
    errs = []
    f = await host.faults()
    rtl_status = f["status"]
    if rtl_status != sim.fault_status:
        errs.append(f"fault status rtl={fault_names(rtl_status)} ref={fault_names(sim.fault_status)}")
    if sim.first_fault is not None:
        rid = f["first"] & 31
        if not (f["first"] >> 31) or rid != sim.first_fault[0] or f["pc"] != sim.first_fault[1]:
            errs.append(f"first fault rtl=({rid},{f['pc']}) ref={sim.first_fault}")
    if sim.halted_fault:
        return errs          # architectural state after a halting fault is timing dependent
    if f["fflags"] != sim.fflags:
        errs.append(f"fflags rtl={f['fflags']:#x} ref={sim.fflags:#x}")
    for mid, nrows in sc.compare.items():
        ref = sim.dump_memory(mid)
        for r in range(nrows):
            for l in range(host.lanes):
                val, q, perr, aerr = await host.read_element(mid, r, l)
                rv, rq, _ = ref[r][l]
                if val != rv or q != rq:
                    errs.append(f"mem{mid}[{r}][{l}] rtl={val:#x}/q{q} ref={rv:#x}/q{rq}")
                    if len(errs) > 20:
                        return errs
    return errs
