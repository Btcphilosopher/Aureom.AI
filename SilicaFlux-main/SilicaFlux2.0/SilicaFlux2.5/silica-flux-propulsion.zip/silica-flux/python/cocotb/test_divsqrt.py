"""
cocotb regression for rtl/alu/divider.sv and rtl/alu/sqrt_unit.sv.

Both units claim *correct rounding*: the RTL result must equal the golden
model bit-for-bit in all five rounding modes, including subnormal operands and
results, and the exception flags must match exactly.
"""
from __future__ import annotations

from fractions import Fraction
import math

import cocotb

from sf_cocotb import ErrorStats, HandshakeHarness, Txn, env_int, start
from golden_model import ieee
from generators.stimulus import FPStimulus, special_values


@cocotb.test()
async def divsqrt_regression(dut):
    fmt = ieee.FP64 if env_int("SF_EXP_W", 8) == 11 else ieee.FP32
    is_div = env_int("SF_DIV", 1) == 1
    n = env_int("SF_N", 300)
    await start(dut)
    stim = FPStimulus(fmt, seed=env_int("SF_SEED", 23))
    txns = []
    sp = special_values(fmt)
    for rm in range(5):
        for _ in range(n):
            a, b = stim.pair()
            if not is_div and stim.rnd.random() < 0.7:
                a &= fmt.mask >> 1          # mostly positive radicands
            f = {"a": a, "rm": rm, "in_tag": len(txns) & 0xFF}
            if is_div:
                f["b"] = b
            txns.append(Txn(f, meta=(rm, a, b)))
    for a in sp:
        for b in (sp if is_div else [0]):
            f = {"a": a, "rm": 0, "in_tag": len(txns) & 0xFF}
            if is_div:
                f["b"] = b
            txns.append(Txn(f, meta=(0, a, b)))

    ins = ["a", "rm", "in_tag"] + (["b"] if is_div else [])
    h = HandshakeHarness(dut, {k: getattr(dut, k) for k in ins},
                         {k: getattr(dut, k) for k in ("result", "fflags", "out_tag")},
                         seed=env_int("SF_SEED", 23), backpressure=0.3)
    done = await h.run(txns, timeout_per_txn=200)

    name = f"{'div' if is_div else 'sqrt'}_{fmt.name}_bpc{env_int('SF_BPC', 1)}"   # bits per cycle
    st = ErrorStats(name)
    bad = []
    for t in done:
        rm, a, b = t.meta
        ref, rff = ieee.div(fmt, a, b, rm) if is_div else ieee.sqrt(fmt, a, rm)
        got, gff = t.out["result"], t.out["fflags"]
        ok = (got == ref) and (gff == rff) and t.out["out_tag"] == t.fields["in_tag"]
        ulp = None
        if fmt.is_finite(got) and not fmt.is_zero(got) and fmt.is_finite(a) and (not is_div or fmt.is_finite(b)):
            try:
                if is_div and not fmt.is_zero(b):
                    exact = fmt.to_fraction(a) / fmt.to_fraction(b)
                    if abs(exact) <= fmt.to_fraction(fmt.max_finite(0)):
                        ulp = ieee.ulp_error(fmt, got, exact)
                elif not is_div and not fmt.sign(a):
                    g = fmt.to_fraction(got)
                    x = fmt.to_fraction(a)
                    # |g - sqrt(x)| = |g^2 - x| / (g + sqrt(x)); bound with g
                    ulp_w = Fraction(2) ** (max(math.floor(math.log2(float(g))), fmt.emin) - fmt.man_bits)
                    ulp = float(abs(g * g - x) / (2 * g) / ulp_w)
            except (OverflowError, ValueError, ZeroDivisionError):
                ulp = None
        st.add(ok=ok, ulp=ulp, latency=t.t_done - t.t_accept,
               row={"rm": ieee.RM_NAMES[rm], "a": hex(a), "b": hex(b) if is_div else "",
                    "rtl": hex(got), "ref": hex(ref), "rtl_flags": gff, "ref_flags": rff,
                    "ulp_err": -1 if ulp is None else ulp, "latency": t.t_done - t.t_accept, "match": int(ok)})
        if not ok and len(bad) < 10:
            bad.append(f"{name} {ieee.RM_NAMES[rm]} a={a:#x} b={b:#x} rtl={got:#x}/{ieee.flags_str(gff)} "
                       f"ref={ref:#x}/{ieee.flags_str(rff)}")
    s = st.write()
    for m in bad:
        dut._log.error(m)
    dut._log.info(f"{name}: {s['count']} vectors, {s['failures']} failures, max ulp {s['ulp']['max']:.3f}, "
                  f"latency {s['latency']}")
    assert s["failures"] == 0
