"""
cocotb regression for the vector ALU functional unit (rtl/alu/vector_alu.sv).

Random instruction streams mixing every VALU opcode, every supported precision
(native FP, SFIX, UFIX, INT), random vector lengths / masks, broadcast, select,
compare-to-mask and conversions are pushed through the unit under random
back-pressure.  Each response is compared lane-by-lane (data, quality bits,
mask bits) and as a whole (IEEE flags, write mask, micro-op echo) against
python/golden_model/valu.py.
"""
from __future__ import annotations

import random

import cocotb

from sf_cocotb import ErrorStats, HandshakeHarness, Txn, env_int, start
from golden_model import ieee, valu
from golden_model.isa import Instr, OPCODES, pack_uop
from generators.stimulus import FPStimulus

FP_OPS = ["VADD", "VSUB", "VMUL", "VFMA", "VFMS", "VFNMA", "VFNMS", "VSQR", "VMIN", "VMAX", "VABS", "VNEG",
          "VCMP", "VSEL", "VMOV", "VCLASS", "VBCAST", "VLANEID", "VMSET", "VCVT", "VSLIDE"]
FIX_OPS = ["VADD", "VSUB", "VMUL", "VFMA", "VSQR", "VMIN", "VMAX", "VABS", "VNEG", "VCMP", "VSEL", "VMOV",
           "VBCAST", "VLANEID", "VCVT", "VSLIDE"]


def pack(vals, width):
    v = 0
    for i, x in enumerate(vals):
        v |= (x & ((1 << width) - 1)) << (i * width)
    return v


def unpack(v, width, n):
    return [(v >> (i * width)) & ((1 << width) - 1) for i in range(n)]


@cocotb.test()
async def valu_regression(dut):
    lanes = env_int("SF_LANES", 8)
    fmt = ieee.FP64 if env_int("SF_EXP_W", 8) == 11 else ieee.FP32
    fp_prec = 1 if fmt is ieee.FP64 else 0
    W = fmt.width
    n = env_int("SF_N", 300)
    rnd = random.Random(env_int("SF_SEED", 41))
    stim = FPStimulus(fmt, seed=env_int("SF_SEED", 41))
    await start(dut)

    def fix_operand(prec):
        r = rnd.random()
        if r < 0.15:
            return rnd.choice([0, 1, (1 << W) - 1, 1 << (W - 1), (1 << (W - 1)) - 1])
        if r < 0.5:
            return rnd.getrandbits(W // 2) if rnd.random() < 0.5 else (-rnd.getrandbits(W // 2)) & ((1 << W) - 1)
        return rnd.getrandbits(W)

    txns = []
    for k in range(n):
        prec = fp_prec if rnd.random() < 0.6 else rnd.choice([2, 3, 4])
        opn = rnd.choice(FP_OPS if prec == fp_prec else FIX_OPS)
        func = 0
        imm = 0
        if opn == "VCMP":
            func = rnd.choice([0, 1, 2])
        if opn == "VMSET":
            func = rnd.choice([0, 1, 2, 3])
            imm = rnd.getrandbits(19)
        if prec != fp_prec:
            imm = rnd.choice([0, 1, 8, 16, W // 2, W - 2, W - 1]) if prec != 4 else 0
        if opn in ("VBCAST", "VSLIDE"):
            imm |= rnd.randrange(lanes) << 12
        if opn == "VCVT":
            if prec == fp_prec:
                func = rnd.choice([2, 3, 4])               # FP <- fixed/int
                imm = rnd.randrange(0, W) << 6
            else:
                func = fp_prec                             # fixed/int <- FP
        rm = rnd.randrange(5)
        ins = Instr(OPCODES[opn], vd=rnd.randrange(32), vs1=1, vs2=2, vs3=3, prec=prec, rm=rm,
                    func=func, imm=imm, vl=0)
        if prec == fp_prec and not (opn == "VCVT"):
            A = [stim.value() for _ in range(lanes)]
            B = [stim.value(exp_center=fmt.efield(a), spread=2) if rnd.random() < 0.4 else stim.value() for a in A]
            C = [stim.value() for _ in range(lanes)]
        elif prec == fp_prec:
            A = [fix_operand(prec) for _ in range(lanes)]
            B = C = [0] * lanes
        elif opn == "VCVT":
            A = [stim.value() if rnd.random() < 0.6 else fmt.from_float(rnd.uniform(-1e6, 1e6)) for _ in range(lanes)]
            B = C = [0] * lanes
        else:
            A = [fix_operand(prec) for _ in range(lanes)]
            B = [fix_operand(prec) for _ in range(lanes)]
            C = [fix_operand(prec) for _ in range(lanes)]
        QA = [rnd.choice([0, 0, 0, 1, 2, 4, 8]) for _ in range(lanes)]
        QB = [rnd.choice([0, 0, 0, 1, 2, 4, 8]) for _ in range(lanes)]
        QC = [rnd.choice([0, 0, 0, 1, 2, 4, 8]) for _ in range(lanes)]
        lmask = (1 << lanes) - 1 if rnd.random() < 0.7 else rnd.getrandbits(lanes)
        vm = rnd.getrandbits(lanes)
        uop = pack_uop(ins, pc=k & 0xFFFF, tag=k & 15)
        txns.append(Txn({"req_uop": uop, "req_a": pack(A, W), "req_b": pack(B, W), "req_c": pack(C, W),
                         "req_qa": pack(QA, 4), "req_qb": pack(QB, 4), "req_qc": pack(QC, 4),
                         "req_lmask": lmask, "req_vm": vm},
                        meta=(ins, rm, A, B, C, QA, QB, QC, lmask, vm)))
    ins_names = ["req_uop", "req_a", "req_b", "req_c", "req_qa", "req_qb", "req_qc", "req_lmask", "req_vm"]
    out_names = ["rsp_uop", "rsp_data", "rsp_qual", "rsp_wmask", "rsp_vm", "rsp_fflags"]
    h = HandshakeHarness(dut, {k: getattr(dut, k) for k in ins_names}, {k: getattr(dut, k) for k in out_names},
                         in_valid="req_valid", in_ready="req_ready", out_valid="rsp_valid", out_ready="rsp_ready",
                         seed=env_int("SF_SEED", 41), backpressure=0.2)
    done = await h.run(txns, timeout_per_txn=50)

    st = ErrorStats(f"valu_{fmt.name}_l{lanes}")
    bad = []
    lane_ops = 0
    for t in done:
        ins, rm, A, B, C, QA, QB, QC, lmask, vm = t.meta
        d, q, mb, ff = valu.valu_vector(fmt, ins, rm, A, B, C, QA, QB, QC, lmask, vm, lanes)
        gd = unpack(t.out["rsp_data"], W, lanes)
        gq = unpack(t.out["rsp_qual"], 4, lanes)
        gm = t.out["rsp_vm"]
        ok = t.out["rsp_uop"] == t.fields["req_uop"] and t.out["rsp_wmask"] == lmask and t.out["rsp_fflags"] == ff
        why = "" if ok else f"uop/wmask/fflags rtl_ff={t.out['rsp_fflags']} ref_ff={ff}"
        for l in range(lanes):
            if not (lmask >> l) & 1:
                continue
            lane_ops += 1
            if gd[l] != d[l] or gq[l] != q[l] or ((gm >> l) & 1) != mb[l]:
                ok = False
                why = f"lane {l}: rtl={gd[l]:#x}/q{gq[l]}/m{(gm >> l) & 1} ref={d[l]:#x}/q{q[l]}/m{mb[l]} a={A[l]:#x} b={B[l]:#x} c={C[l]:#x}"
                break
        st.add(ok=ok, latency=t.t_done - t.t_accept)
        if not ok and len(bad) < 12:
            bad.append(f"{ins} :: {why}")
    s = st.write()
    for m in bad:
        dut._log.error(m)
    dut._log.info(f"{s['name']}: {s['count']} instructions ({lane_ops} lane-ops), {s['failures']} failures, "
                  f"latency {s['latency']}")
    assert s["failures"] == 0
