"""
cocotb regression for rtl/alu/fma_unit.sv

For every FMA-family operation (FMADD, FMSUB, FNMSUB, FNMADD, FMUL, FADD,
FSUB) and every rounding mode, biased-random and directed operands are pushed
through the elastic pipeline under random back-pressure.  Each RTL result is
compared bit-exactly (value AND exception flags) with the golden model; the
ULP error of the RTL result against the infinitely precise value is recorded.
"""
from __future__ import annotations

import os

import cocotb

from sf_cocotb import ErrorStats, HandshakeHarness, Txn, env_int, start
from golden_model import ieee
from generators.stimulus import FPStimulus, directed_triples


@cocotb.test()
async def fma_regression(dut):
    fmt = ieee.FP64 if env_int("SF_EXP_W", 8) == 11 else ieee.FP32
    n_rand = env_int("SF_N", 600)
    latency_cfg = env_int("SF_LATENCY", 4)
    await start(dut)
    stim = FPStimulus(fmt, seed=env_int("SF_SEED", 11))

    txns = []
    for op in range(7):
        for rm in range(5):
            for (a, b, c) in stim.stream(n_rand):
                txns.append(Txn({"op": op, "rm": rm, "a": a, "b": b, "c": c, "in_tag": len(txns) & 0xFF},
                                meta=(op, rm, a, b, c)))
    for i, (a, b, c) in enumerate(directed_triples(fmt)):
        op, rm = i % 7, (i // 7) % 5
        txns.append(Txn({"op": op, "rm": rm, "a": a, "b": b, "c": c, "in_tag": len(txns) & 0xFF},
                        meta=(op, rm, a, b, c)))

    h = HandshakeHarness(dut, {k: getattr(dut, k) for k in ("op", "rm", "a", "b", "c", "in_tag")},
                         {k: getattr(dut, k) for k in ("result", "fflags", "out_tag")},
                         seed=env_int("SF_SEED", 11))
    done = await h.run(txns)

    st = ErrorStats(f"fma_{fmt.name}_lat{latency_cfg}")
    mism = []
    for t in done:
        op, rm, a, b, c = t.meta
        exp_bits, exp_ff = ieee.fma_op(fmt, op, a, b, c, rm)
        got, gff = t.out["result"], t.out["fflags"]
        same_val = got == exp_bits
        ok = same_val and gff == exp_ff and t.out["out_tag"] == t.fields["in_tag"]
        ulp = None
        if fmt.is_finite(got) and fmt.is_finite(a) and fmt.is_finite(b) and (op == ieee.FMUL or fmt.is_finite(c)):
            # exact infinitely-precise result
            A, B = fmt.to_fraction(a), fmt.to_fraction(b)
            C = 0 if op == ieee.FMUL else fmt.to_fraction(c)
            if op in (ieee.FADD, ieee.FSUB):
                B = 1
            sgn_p = -1 if op in (ieee.FNMSUB, ieee.FNMADD) else 1
            sgn_c = -1 if op in (ieee.FMSUB, ieee.FNMADD, ieee.FSUB) else 1
            exact = sgn_p * A * B + sgn_c * C
            if abs(exact) <= fmt.to_fraction(fmt.max_finite(0)):
                ulp = ieee.ulp_error(fmt, got, exact)
        st.add(ok=ok, ulp=ulp, latency=t.t_done - t.t_accept,
               row={"op": ieee.FMA_OP_NAMES[op], "rm": ieee.RM_NAMES[rm], "a": hex(a), "b": hex(b), "c": hex(c),
                    "rtl": hex(got), "ref": hex(exp_bits), "rtl_flags": gff, "ref_flags": exp_ff,
                    "ulp_err": -1 if ulp is None else ulp, "latency": t.t_done - t.t_accept, "match": int(ok)})
        if not ok and len(mism) < 10:
            mism.append(f"{ieee.FMA_OP_NAMES[op]} {ieee.RM_NAMES[rm]} a={a:#x} b={b:#x} c={c:#x} "
                        f"rtl={got:#x}/{ieee.flags_str(gff)} ref={exp_bits:#x}/{ieee.flags_str(exp_ff)}")
    s = st.write()
    for m in mism:
        dut._log.error(m)
    dut._log.info(f"{s['name']}: {s['count']} vectors, {s['failures']} failures, "
                  f"max ulp {s['ulp']['max']:.3f}, latency {s['latency']}")
    assert s["failures"] == 0, f"{s['failures']} FMA mismatches"
    assert s["ulp"]["max"] <= 1.0
