#!/usr/bin/env python3
"""
Silica Flux cocotb regression runner.

    python3 python/cocotb/run_regression.py              # full regression
    python3 python/cocotb/run_regression.py fma_fp32     # selected configs
    python3 python/cocotb/run_regression.py --quick      # reduced vector counts
    SIM=verilator python3 ...                            # (requires Verilator >= 5.036)

Each configuration elaborates the RTL with its own parameters (lane count,
floating-point format, pipeline depth) so that one testbench verifies several
synthesis configurations.  Results are summarised in reports/cocotb_summary.json.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "python"))

from cocotb_tools.runner import get_runner  # noqa: E402


def rtl_sources() -> list[Path]:
    files = [ROOT / "rtl/core/flux_pkg.sv"]
    for p in sorted((ROOT / "rtl").rglob("*.sv")):
        if p not in files:
            files.append(p)
    return files


FP32 = {"EXP_W": 8, "MAN_W": 23}
FP64 = {"EXP_W": 11, "MAN_W": 52}

# name: (toplevel, test module, parameters, extra env, quick-N, full-N)
CONFIGS: dict[str, tuple] = {
    "fma_fp32":        ("fma_unit", "test_fma", {**FP32, "LATENCY": 4}, {"SF_EXP_W": 8, "SF_LATENCY": 4}, 120, 600),
    "fma_fp32_lat6":   ("fma_unit", "test_fma", {**FP32, "LATENCY": 6}, {"SF_EXP_W": 8, "SF_LATENCY": 6}, 60, 200),
    "fma_fp64":        ("fma_unit", "test_fma", {**FP64, "LATENCY": 4}, {"SF_EXP_W": 11, "SF_LATENCY": 4}, 120, 500),
    "div_fp32":        ("divider", "test_divsqrt", {**FP32, "BITS_PER_CYCLE": 1}, {"SF_EXP_W": 8, "SF_DIV": 1, "SF_BPC": 1}, 80, 400),
    "div_fp32_r4":     ("divider", "test_divsqrt", {**FP32, "BITS_PER_CYCLE": 2}, {"SF_EXP_W": 8, "SF_DIV": 1, "SF_BPC": 2}, 40, 200),
    "div_fp64":        ("divider", "test_divsqrt", {**FP64, "BITS_PER_CYCLE": 2}, {"SF_EXP_W": 11, "SF_DIV": 1, "SF_BPC": 2}, 60, 300),
    "sqrt_fp32":       ("sqrt_unit", "test_divsqrt", {**FP32, "BITS_PER_CYCLE": 1}, {"SF_EXP_W": 8, "SF_DIV": 0, "SF_BPC": 1}, 80, 400),
    "sqrt_fp64":       ("sqrt_unit", "test_divsqrt", {**FP64, "BITS_PER_CYCLE": 2}, {"SF_EXP_W": 11, "SF_DIV": 0, "SF_BPC": 2}, 60, 300),
    "recip_fp32":      ("reciprocal_unit", "test_sfu", FP32, {"SF_EXP_W": 8, "SF_FUNC": 0}, 150, 1500),
    "recip_fp64":      ("reciprocal_unit", "test_sfu", FP64, {"SF_EXP_W": 11, "SF_FUNC": 0}, 100, 600),
    "exp_fp32":        ("exp_unit", "test_sfu", FP32, {"SF_EXP_W": 8, "SF_FUNC": 1}, 150, 1500),
    "exp_fp64":        ("exp_unit", "test_sfu", FP64, {"SF_EXP_W": 11, "SF_FUNC": 1}, 100, 600),
    "log_fp32":        ("log_unit", "test_sfu", FP32, {"SF_EXP_W": 8, "SF_FUNC": 2}, 150, 1500),
    "log_fp64":        ("log_unit", "test_sfu", FP64, {"SF_EXP_W": 11, "SF_FUNC": 2}, 100, 600),
    "valu_fp32_l8":    ("vector_alu", "test_vector_alu", {**FP32, "LANES": 8, "LATENCY": 4}, {"SF_EXP_W": 8, "SF_LANES": 8}, 150, 800),
    "valu_fp32_l16":   ("vector_alu", "test_vector_alu", {**FP32, "LANES": 16, "LATENCY": 5}, {"SF_EXP_W": 8, "SF_LANES": 16}, 80, 400),
    "valu_fp32_l32":   ("vector_alu", "test_vector_alu", {**FP32, "LANES": 32, "LATENCY": 4}, {"SF_EXP_W": 8, "SF_LANES": 32}, 50, 200),
    "valu_fp64_l8":    ("vector_alu", "test_vector_alu", {**FP64, "LANES": 8, "LATENCY": 4}, {"SF_EXP_W": 11, "SF_LANES": 8}, 100, 500),
    "top_fp32_l8":     ("silica_flux_top", "test_top", {"VECTOR_LANES": 8, "FP_MODE": 0}, {"SF_LANES": 8, "SF_FP_MODE": 0, "SF_NPROG": 3}, 2, 6),
    "top_fp64_l8":     ("silica_flux_top", "test_top", {"VECTOR_LANES": 8, "FP_MODE": 1}, {"SF_LANES": 8, "SF_FP_MODE": 1, "SF_NPROG": 2}, 1, 4),
    "top_fp32_l16":    ("silica_flux_top", "test_top", {"VECTOR_LANES": 16, "FP_MODE": 0, "PIPELINE_DEPTH": 5}, {"SF_LANES": 16, "SF_FP_MODE": 0, "SF_NPROG": 2}, 1, 3),
}


TESTCASE = None   # optional --testcase=<name> filter


def run(names: list[str], quick: bool) -> dict:
    sim = os.environ.get("SIM", "icarus")
    results = {}
    for name in names:
        top, module, params, env, nq, nf = CONFIGS[name]
        build_dir = ROOT / "build" / "cocotb" / name
        runner = get_runner(sim)
        t0 = time.time()
        build_args = ["-g2012"] if sim == "icarus" else ["-Wno-fatal"]
        runner.build(sources=[str(s) for s in rtl_sources()], hdl_toplevel=top,
                     parameters=params, build_dir=str(build_dir), build_args=build_args,
                     includes=[str(ROOT / "rtl/math/generated"), str(ROOT / "rtl/core")], always=True, timescale=("1ns", "1ps"),
                     log_file=str(build_dir / "build.log"))
        envv = {k: str(v) for k, v in env.items()}
        envv["SF_N"] = str(nq if quick else nf)
        if module == "test_top":
            envv["SF_NPROG"] = str(nq if quick else nf)
        envv["SF_REPORT_DIR"] = str(ROOT / "reports")
        envv["PYTHONPATH"] = os.pathsep.join([str(HERE), str(ROOT / "python"), os.environ.get("PYTHONPATH", "")])
        xml = runner.test(hdl_toplevel=top, test_module=module, test_dir=str(HERE), build_dir=str(build_dir),
                          extra_env=envv, results_xml=str(build_dir / "results.xml"), testcase=TESTCASE,
                          log_file=str(build_dir / "sim.log"))
        from cocotb_tools.runner import get_results
        ntests, nfail = get_results(xml)
        results[name] = {"tests": ntests, "failures": nfail, "seconds": round(time.time() - t0, 1)}
        status = "PASS" if nfail == 0 else "FAIL"
        print(f"[cocotb] {name:<22} {status}  ({ntests} tests, {results[name]['seconds']} s)", flush=True)
    return results


def main(argv):
    global TESTCASE
    quick = "--quick" in argv
    for a in argv:
        if a.startswith("--testcase="):
            TESTCASE = a.split("=", 1)[1].split(",")
    names = [a for a in argv if not a.startswith("--")] or list(CONFIGS)
    res = run(names, quick)
    out = ROOT / "reports" / "cocotb_summary.json"
    out.parent.mkdir(exist_ok=True)
    prev = json.loads(out.read_text()) if out.exists() else {}
    prev.update(res)
    out.write_text(json.dumps(prev, indent=2))
    return 0 if all(r["failures"] == 0 for r in res.values()) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
