"""
Program generators for system-level verification.

directed_suite()  one scenario per functional-unit family, written by hand to
                  hit the interesting semantics (masks, partial vectors,
                  quality propagation, loops, state banks, engines)
random_program()  constrained-random instruction streams over the arithmetic
                  units, terminated by stores of every live register
"""
from __future__ import annotations

import math
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from golden_model import ieee  # noqa: E402
from golden_model.isa import MEM, PREC  # noqa: E402
from generators.assembler import Program  # noqa: E402
from generators.stimulus import FPStimulus  # noqa: E402

NO_HALT = 0  # fault_halt mask that records but never halts


def fp(fmt, v: float) -> int:
    return fmt.from_float(v)


def row(fmt, vals):
    return ([fp(fmt, v) for v in vals], None)


def _scenario(name, p: Program, mem_init, config=None, compare=None, frames=0):
    from reference_model.scenario import Scenario
    return Scenario(name=name, words=p.assemble(), mem_init=mem_init, config=config or {},
                    compare=compare or {MEM["RESULT"]: 8}, telemetry_frames=frames)


def directed_suite(fmt, lanes: int) -> list:
    L = lanes
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    rnd = random.Random(7)
    out = []
    lin = [float(i) for i in range(L)]
    mix = [(-1) ** i * (0.5 + i) for i in range(L)]
    smal = [1e-3 * (i + 1) for i in range(L)]

    # 1. vector ALU basics, partial vectors and masks --------------------------------------
    p = Program(prec)
    p.vload(1, "STATE", 0, 0).vload(2, "STATE", 0, 1).vload(3, "STATE", 0, 2)
    p.vadd(4, 1, 2).vsub(5, 1, 2).vmul(6, 1, 2).vfma(7, 1, 2, 3).vfms(8, 1, 2, 3, rm="RTZ")
    p.vmin(9, 1, 2).vmax(10, 1, 2).vabs(11, 2).vneg(12, 1).vsqr(13, 2, rm="RUP")
    p.vcmp(14, 1, 2, cmp="LT").vsel(15, 1, 2).vmov(16, 3, vl=L // 2)
    p.vbcast(17, 2, 3).vslide(18, 1, 1)
    p.vmset("ALL").vadd(19, 1, 3, masked=1)
    for k, r in enumerate(range(4, 20)):
        p.vstore(r, "RESULT", 0, k)
    p.halt()
    out.append(_scenario("valu_basic", p, {MEM["STATE"]: {0: row(fmt, mix), 1: row(fmt, lin), 2: row(fmt, smal)}},
                         compare={MEM["RESULT"]: 16}))

    # 2. fixed point and conversions ---------------------------------------------------------
    p = Program(prec)
    p.vload(1, "STATE", 0, 0)                                   # FP values
    p.vcvt(2, 1, dst="SFIX", dst_frac=16)                       # FP -> Q15.16
    p._v("VADD", 3, 2, 2, prec="SFIX", imm=16)
    p._v("VMUL", 4, 2, 2, prec="SFIX", imm=16, rm="RNE")
    p._v("VFMA", 5, 2, 3, 4, prec="SFIX", imm=16)
    p.vcvt(6, 5, dst=prec, src="SFIX", src_frac=16)             # back to FP
    p.vcvt(7, 1, dst="INT", rm="RDN")
    p._v("VMUL", 8, 7, 7, prec="INT")
    p.vcvt(9, 8, dst=prec, src="INT")
    p.vstore(6, "RESULT", 0, 0).vstore(9, "RESULT", 0, 1)
    p.halt()
    big = [(-1) ** i * (100.0 + 37.25 * i) for i in range(L)]
    out.append(_scenario("fixed_point", p, {MEM["STATE"]: {0: row(fmt, big)}}, {"fault_halt": NO_HALT},
                         compare={MEM["RESULT"]: 2}))

    # 3. divide, square root, special functions ----------------------------------------------
    p = Program(prec)
    p.vload(1, "STATE", 0, 0).vload(2, "STATE", 0, 1)
    p.vdiv(3, 1, 2).vsqrt(4, 2).vrecip(5, 2).vexp(6, 1).vlog(7, 2).vdiv(8, 2, 1, rm="RDN")
    for k, r in enumerate(range(3, 9)):
        p.vstore(r, "RESULT", 0, k)
    p.halt()
    out.append(_scenario("divsqrt_sfu", p, {MEM["STATE"]: {0: row(fmt, mix), 1: row(fmt, [0.75 + i for i in range(L)])}},
                         {"fault_halt": NO_HALT}, compare={MEM["RESULT"]: 6}))

    # 4. reductions (full and partial vectors) ----------------------------------------------------
    p = Program(prec)
    p.vload(1, "STATE", 0, 0).vload(2, "STATE", 0, 1)
    for k, fn in enumerate(("SUM", "MIN", "MAX", "SUMSQ", "DOT", "ARGMIN", "ARGMAX", "MAXABS")):
        p.vreduce(10 + k, 1, fn, b=2)
        p.vreduce(20 + k, 1, fn, b=2, vl=L - 3)
    for k in range(8):
        p.vstore(10 + k, "RESULT", 0, k)
        p.vstore(20 + k, "RESULT", 0, 8 + k)
    p.halt()
    vals = [rnd.uniform(-5, 5) for _ in range(L)]
    out.append(_scenario("reductions", p, {MEM["STATE"]: {0: row(fmt, vals), 1: row(fmt, mix)}},
                         compare={MEM["RESULT"]: 16}))

    # 5. polynomial, cube, interpolation ----------------------------------------------------------
    p = Program(prec)
    p.vload(1, "STATE", 0, 0)                     # x
    p.vload(2, "COEFF", 0, 0)                     # polynomial coefficients c0..c7
    p.vload(3, "COEFF", 0, 1)                     # table y
    p.vload(4, "COEFF", 0, 2)                     # table slopes d
    p.vload(5, "STATE", 0, 1)                     # normalised coordinates t
    p.vpoly(6, 1, 2, 3).vpoly(7, 1, 2, 0).vpoly(8, 1, 2, min(7, L - 1)).vcube(9, 1)
    p.vinterp(10, 5, 3, 4)
    for k, r in enumerate(range(6, 11)):
        p.vstore(r, "RESULT", 0, k)
    p.halt()
    ys = [math.sin(0.4 * i) for i in range(L)]
    ds = [ys[i + 1] - ys[i] if i + 1 < L else 0.0 for i in range(L)]
    ts = [-0.5, 0.0, 0.37, 1.99, L / 2 + 0.25, L - 1.0, L - 0.5, float("nan")] + [1.5] * (L - 8)
    out.append(_scenario("poly_interp", p, {
        MEM["STATE"]: {0: row(fmt, [0.1 * i - 0.3 for i in range(L)]), 1: row(fmt, ts[:L])},
        MEM["COEFF"]: {0: row(fmt, [1.0, -0.5, 0.25, 0.125, -0.0625, 0.03, 0.01, 0.002] + [0.0] * (L - 8)),
                       1: row(fmt, ys), 2: row(fmt, ds)}},
        {"fault_halt": NO_HALT}, compare={MEM["RESULT"]: 5}))

    # 6. state engine: RK4 / Heun / Euler on dx/dt = -k x (loops, BNZ, ping-pong banks) ---------
    for method, steps in (("RK4", 6), ("HEUN", 5), ("EULER", 4), ("MIDPOINT", 3), ("RALSTON", 3)):
        p = Program(prec)
        p.vload(1, "STATE", 0, 0)                 # x0
        p.vload(2, "PARAM", 0, 0)                 # -k per lane
        p.vldbc(3, "PARAM", 0, L)                 # dt broadcast (element L = row 1 lane 0)
        p.tscfg(3, method)
        p.seta(1, steps - 1)
        p.label("step")
        p.vload(1, "STATE", 0, 0)
        p.su_load(4, 1)
        stages = {"RK4": 4, "HEUN": 2, "MIDPOINT": 2, "RALSTON": 2, "EULER": 1}[method]
        for s in range(stages):
            p.vmul(5, 2, 4)                       # k_s = f(x_s) = -k x_s
            p.su_stage(4, 5, s)
        p.vstore(4, "STATE_N", 0, 0)
        p.barrier(swap=True)
        p.bnz(1, "step")
        p.vload(6, "STATE", 0, 0)
        p.vstore(6, "RESULT", 0, 0)
        p.halt()
        out.append(_scenario(f"state_{method.lower()}", p, {
            MEM["STATE"]: {0: row(fmt, [1.0 + 0.1 * i for i in range(L)])},
            MEM["PARAM"]: {0: row(fmt, [-0.5 - 0.25 * i for i in range(L)]), 1: row(fmt, [0.05] * L)}},
            compare={MEM["RESULT"]: 1, MEM["STATE"]: 1}))

    # 7. residual and conservation -------------------------------------------------------------
    p = Program(prec)
    p.vload(1, "STATE", 0, 0).vload(2, "STATE", 0, 1).vload(3, "STATE", 0, 2)
    p.vload(4, "COEFF", 0, 0).vload(5, "COEFF", 0, 1)
    p.residual(6, 1, 2, 3, "SIGNED").residual(7, 1, 2, 3, "ABS").residual(8, 1, 2, 3, "MARGIN")
    p.conserve(9, 1, 4, mode="CAPTURE")
    p.conserve(10, 2, 4, 5, mode="CHECK")
    p.conserve(11, 2, 4, 5, mode="CHECK_ADV")
    p.conserve(12, 1, 4, 5, mode="CHECK")
    for k, r in enumerate(range(6, 13)):
        p.vstore(r, "RESULT", 0, k)
    p.halt()
    e = [1.0 + i for i in range(L)]
    o = [v * (1.0 + (1e-3 if i % 3 == 0 else 1e-6)) for i, v in enumerate(e)]
    out.append(_scenario("residual_conservation", p, {
        MEM["STATE"]: {0: row(fmt, e), 1: row(fmt, o), 2: row(fmt, [1e-4] * L)},
        MEM["COEFF"]: {0: row(fmt, [1.0 + 0.5 * (i % 2) for i in range(L)]), 1: row(fmt, [1e-3] * L)}},
        {"fault_halt": NO_HALT, "res_rtol": fp(fmt, 1e-4), "cons_atol": fp(fmt, 1e-6), "cons_rtol": fp(fmt, 1e-5)},
        compare={MEM["RESULT"]: 7}))

    # 8. objective and constraints -------------------------------------------------------------
    p = Program(prec)
    p.vload(1, "STATE", 0, 0).vload(2, "STATE", 0, 1).vload(3, "COEFF", 0, 0).vload(4, "COEFF", 0, 1)
    for k, mode in enumerate(("WSUM", "ABS", "SQ", "PENALTY")):
        p.objective(10 + k, 1, 2, 3, mode)
        p.objective(14 + k, 1, 2, 3, mode, reduce=True)
    for k, kind in enumerate(("LT", "GT", "EQ", "TOL", "LE", "GE")):
        p.constraint(20 + k, 1, 2, 4, kind)
    for k in range(8):
        p.vstore(10 + k, "RESULT", 0, k)
    for k in range(6):
        p.vstore(20 + k, "RESULT", 0, 8 + k)
    p.halt()
    xv = [0.5 * i - 1.0 for i in range(L)]
    tv = [0.5 * i - 1.0 + (0.0 if i % 4 == 0 else 0.3 * (-1) ** i) for i in range(L)]
    out.append(_scenario("objective_constraint", p, {
        MEM["STATE"]: {0: row(fmt, xv), 1: row(fmt, tv)},
        MEM["COEFF"]: {0: row(fmt, [1.0 + 0.1 * i for i in range(L)]), 1: row(fmt, [0.25] * L)}},
        {"fault_halt": NO_HALT}, compare={MEM["RESULT"]: 14}))

    # 9. parameter sweep + grid search + bounded local search ------------------------------------
    sw = {"dims": 2, "lo": [fp(fmt, -1.0), fp(fmt, 0.5), 0, 0], "step": [fp(fmt, 0.25), fp(fmt, 0.5), 0, 0],
          "count": [5, 4, 1, 1]}
    ls = {"dims": 2, "max_iter": 12, "lo": [fp(fmt, -2.0), fp(fmt, -2.0), 0, 0],
          "hi": [fp(fmt, 2.0), fp(fmt, 2.0), 0, 0], "center0": [fp(fmt, 1.5), fp(fmt, -1.25), 0, 0],
          "step0": [fp(fmt, 0.5), fp(fmt, 0.5), 0, 0], "min_step": [fp(fmt, 1e-3), fp(fmt, 1e-3), 0, 0]}
    p = Program(prec)
    p.vload(30, "COEFF", 0, 0)                     # target (a, b) broadcast rows
    p.vload(31, "COEFF", 0, 1)
    p.vload(29, "COEFF", 0, 2)                     # weights = 1
    p.sweep("RESET").search("RESET")
    p.seta(1, (5 * 4 + L - 1) // L - 1)
    p.label("batch")
    p.sweep("GEN", vd=1, dim=0).sweep("GEN", vd=2, dim=1)
    p.vsub(3, 1, 30).vsub(4, 2, 31)
    p.vmul(5, 3, 3).vfma(5, 4, 4, 5)               # J = (a-a*)^2 + (b-b*)^2
    p.search("GRID", vs1=5)
    p.sweep("NEXT")
    p.bnz(1, "batch")
    p.seta(2, 11)
    p.label("ls")
    p.search("LS_GEN", vd=6, dim=0).search("LS_GEN", vd=7, dim=1)
    p.vsub(3, 6, 30).vsub(4, 7, 31).vmul(5, 3, 3).vfma(5, 4, 4, 5)
    p.search("LOCAL", vs1=5)
    p.bnz(2, "ls")
    p.vstore(6, "RESULT", 0, 0).vstore(7, "RESULT", 0, 1).vstore(5, "RESULT", 0, 2)
    p.halt()
    out.append(_scenario("sweep_search", p, {MEM["COEFF"]: {0: row(fmt, [0.3] * L), 1: row(fmt, [1.2] * L),
                                                              2: row(fmt, [1.0] * L)}},
                         {"fault_halt": NO_HALT, "sweep": sw, "search": ls}, compare={MEM["RESULT"]: 3}))

    # 10. load/store variants, scratchpad, masked store -----------------------------------------
    p = Program(prec)
    p.seta(3, 2)
    p.vload(1, "STATE", 3, 0)                      # row a3+0 = 2
    p.vldbc(2, "STATE", 0, 2 * L + 5)              # element (2, 5)
    p.vcmp(3, 1, 2, cmp="LE")
    p.vstore(1, "SCRATCH", 0, 7, masked=1)
    p.vload(4, "SCRATCH", 0, 7)
    p.adda(3, -1)
    p.vload(5, "STATE", 3, 0)
    p.vstore(4, "RESULT", 0, 0).vstore(5, "RESULT", 0, 1).vstore(2, "RESULT", 0, 2)
    p.halt()
    out.append(_scenario("lsu_variants", p, {MEM["STATE"]: {1: row(fmt, mix), 2: row(fmt, lin)}},
                         compare={MEM["RESULT"]: 3, MEM["SCRATCH"]: 8}))
    return out


# =============================================================================
ARITH_OPS = ["VADD", "VSUB", "VMUL", "VFMA", "VFMS", "VFNMA", "VFNMS", "VSQR", "VMIN", "VMAX", "VABS",
             "VNEG", "VSEL", "VMOV", "VCMP", "VDIV", "VSQRT", "VRECIP", "VEXP", "VLOG", "VREDUCE",
             "VPOLY", "VCUBE", "VINTERP", "VBCAST", "VSLIDE"]


def random_program(fmt, lanes: int, seed: int = 1, length: int = 40):
    """constrained-random arithmetic program, all registers FP, never halting"""
    from reference_model.scenario import Scenario
    rnd = random.Random(seed)
    stim = FPStimulus(fmt, seed=seed)
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    L = lanes
    p = Program(prec)
    nrows = 6
    live = list(range(1, 1 + nrows))
    for r in range(nrows):
        p.vload(1 + r, "STATE", 0, r)
    for _ in range(length):
        op = rnd.choice(ARITH_OPS)
        vd = rnd.randrange(1, 24)
        a, b, c = (rnd.choice(live) for _ in range(3))
        rm = rnd.choice(["RNE", "RTZ", "RDN", "RUP", "RMM"])
        vl = 0 if rnd.random() < 0.7 else rnd.randrange(1, L + 1)
        masked = int(rnd.random() < 0.15)
        kw = dict(rm=rm, vl=vl, masked=masked)
        if vd not in live and (vl or masked):
            kw["vl"], kw["masked"] = 0, 0          # never partially write a fresh register
        name = op.lower()
        if op in ("VFMA", "VFMS", "VFNMA", "VFNMS"):
            getattr(p, name)(vd, a, b, c, **kw)
        elif op in ("VSQR", "VABS", "VNEG", "VMOV", "VSQRT", "VRECIP", "VEXP", "VLOG", "VCUBE"):
            getattr(p, name)(vd, a, **kw)
        elif op == "VCMP":
            p.vcmp(vd, a, b, cmp=rnd.choice(["EQ", "LT", "LE"]), **kw)
        elif op == "VREDUCE":
            p.vreduce(vd, a, rnd.choice(["SUM", "MIN", "MAX", "SUMSQ", "DOT", "ARGMIN", "ARGMAX", "MAXABS"]),
                      b=b, rm=rm, vl=vl)
        elif op == "VPOLY":
            p.vpoly(vd, a, b, rnd.randrange(0, min(8, L)), **kw)
        elif op == "VINTERP":
            p.vinterp(vd, a, b, c, **kw)
        elif op == "VBCAST":
            p.vbcast(vd, a, rnd.randrange(L), **kw)
        elif op == "VSLIDE":
            p.vslide(vd, a, rnd.randrange(L), **kw)
        else:
            getattr(p, name)(vd, a, b, **kw)
        if vd not in live:
            live.append(vd)
    for k, r in enumerate(live):
        p.vstore(r, "RESULT", 0, k)
    p.halt()
    init = {}
    for r in range(nrows):
        vals = [stim.value() if rnd.random() < 0.6 else fmt.from_float(rnd.uniform(-4, 4)) for _ in range(L)]
        quals = [rnd.choice([0, 0, 0, 0, 8, 1]) for _ in range(L)]
        init[r] = (vals, quals)
    return Scenario(name=f"random_{seed}", words=p.assemble(), mem_init={MEM["STATE"]: init},
                    config={"fault_halt": NO_HALT}, compare={MEM["RESULT"]: len(live)})


# =============================================================================
# fault-injection suite
# =============================================================================
def fault_suite(fmt, lanes: int) -> list:
    from reference_model.scenario import Scenario
    from reference_model.isa_sim import HALT_DEFAULT
    from golden_model.isa import Instr, F
    from silica_flux import regmap as RG
    L = lanes
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    out = []

    def mk(name, p, init=None, config=None, compare=None, halt=True, pre=None, ref=None):
        sc = Scenario(name=name, words=p.assemble(), mem_init=init or {}, config=config or {},
                      compare=compare or {}, expect_halt=halt, pre_writes=pre or [], ref_setup=ref)
        return sc

    base = {MEM["STATE"]: {0: row(fmt, [1.0 + i for i in range(L)]), 1: row(fmt, [0.0] * L),
                           2: row(fmt, [3e38 if fmt is ieee.FP32 else 1.5e308] * L),
                           3: row(fmt, [1e-30 if fmt is ieee.FP32 else 1e-300] * L)}}

    p = Program(prec).vload(1, "STATE", 0, 0)
    p.items.append(Instr(0x7F, vd=2, vs1=1))
    p.halt()
    out.append(mk("illegal_opcode", p, base))

    p = Program(prec).vload(1, "STATE", 0, 0)
    p._v("VADD", 2, 1, 1, prec="SFIX", imm=16)
    p.halt()
    out.append(mk("precision_mismatch", p, base))

    p = Program(prec).vload(1, "STATE", 0, 0).vadd(2, 20, 1).halt()
    out.append(mk("uninitialised_read", p, base))

    p = Program(prec).vload(1, "STATE", 0, 1).vdiv(2, 1, 1).vstore(2, "RESULT", 0, 0).halt()
    out.append(mk("nan_invalid_operation", p, base))

    p = Program(prec).vload(1, "STATE", 0, 2).vmul(2, 1, 1).vstore(2, "RESULT", 0, 0).halt()
    out.append(mk("overflow", p, base))

    p = Program(prec).vload(1, "STATE", 0, 0).vload(2, "STATE", 0, 1).vdiv(3, 1, 2).halt()
    out.append(mk("divide_by_zero", p, base))

    p = Program(prec).vload(1, "STATE", 0, 3).vmul(2, 1, 1).vstore(2, "RESULT", 0, 0).halt()
    out.append(mk("underflow_recorded_not_halting", p, base, compare={MEM["RESULT"]: 1}, halt=False))

    p = Program(prec).vload(1, "STATE", 0, 1000).halt()
    out.append(mk("illegal_memory_address", p, base))

    p = Program(prec).vload(1, "STATE", 0, 0).vstore(1, "TELEM", 0, 0).halt()
    out.append(mk("write_to_readonly_telemetry", p, base))

    no_par = HALT_DEFAULT & ~(1 << F["PARITY"]) & ~(1 << F["NAN"])
    p = Program(prec).vload(1, "STATE", 0, 0).vadd(2, 1, 1).vreduce(3, 2, "SUM")
    p.vstore(1, "RESULT", 0, 0).vstore(2, "RESULT", 0, 1).vstore(3, "RESULT", 0, 2).halt()

    def corrupt_state(sim):
        v, q, _ = sim.mem["STATE0"][0][0]
        sim.mem["STATE0"][0][0] = (v, q, True)
    out.append(mk("memory_parity_corruption", p, base, {"fault_halt": no_par}, {MEM["RESULT"]: 3}, halt=False,
                  pre=[(RG.CTRL, RG.CTRL_INJ_MEM | (MEM["STATE"] << 8))], ref=corrupt_state))

    p = Program(prec).vload(1, "STATE", 0, 0).vadd(2, 1, 1).halt()

    def corrupt_imem(sim):
        sim.imem_corrupt = {0}
    out.append(mk("instruction_parity_error", p, base, pre=[(RG.CTRL, RG.CTRL_INJ_IMEM)], ref=corrupt_imem))

    p = Program(prec).vload(1, "STATE", 0, 0).barrier(telem=True).vstore(1, "RESULT", 0, 0).halt()
    out.append(mk("watchdog_starved_barrier", p, base, {"wdt_limit": 400}))

    p = Program(prec).vldbc(1, "STATE", 0, 0).vneg(2, 1).tscfg(2, "RK4").halt()
    out.append(mk("invalid_timestep", p, base))

    nanrow = [float("nan") if i % 3 == 0 else 1.0 + i for i in range(L)]
    p = Program(prec).vload(1, "STATE", 0, 4).vload(2, "STATE", 0, 0)
    p.vfma(3, 1, 2, 2).vexp(4, 3).vreduce(5, 4, "MAX").vstore(3, "RESULT", 0, 0).vstore(4, "RESULT", 0, 1)
    p.vstore(5, "RESULT", 0, 2).halt()
    init = dict(base)
    init[MEM["STATE"]] = dict(base[MEM["STATE"]])
    init[MEM["STATE"]][4] = row(fmt, nanrow)
    out.append(mk("nan_quality_propagation", p, init, {"fault_halt": NO_HALT}, {MEM["RESULT"]: 3}, halt=False))
    return out


# =============================================================================
# telemetry suite
# =============================================================================
def telemetry_suite(fmt, lanes: int) -> list:
    from reference_model.scenario import Scenario
    from silica_flux.driver import telemetry_packet
    L = lanes
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    rows = (32 + L - 1) // L
    out = []

    def readout(p):
        for r in range(rows):
            p.vload(1 + r, "TELEM", 0, r)
        for r in range(rows):
            p.vstore(1 + r, "RESULT", 0, r)

    # clean frame -----------------------------------------------------------------------------
    beats = []
    for c in range(16):
        beats += telemetry_packet(1000 + 10 * c, c, c, fp(fmt, 100.0 + 2.5 * c), frame_end=(c == 15))
    p = Program(prec).barrier(telem=True)
    readout(p)
    p.halt()
    out.append(Scenario(name="telemetry_clean_frame", words=p.assemble(), telemetry=[beats],
                        config={"fault_halt": NO_HALT}, compare={MEM["RESULT"]: rows}))

    # anomalies ---------------------------------------------------------------------------------
    bounds = {c: (fp(fmt, 0.0), fp(fmt, 100.0)) for c in range(4)}
    b = []
    b += telemetry_packet(100, 0, 0, fp(fmt, 10.0))
    b += telemetry_packet(110, 1, 1, fp(fmt, 20.0), corrupt_crc=True)          # CRC error -> dropped
    b += telemetry_packet(120, 3, 1, fp(fmt, 21.0))                            # gap: seq 1-2 missing
    b += telemetry_packet(130, 3, 2, fp(fmt, 30.0))                            # duplicate -> dropped
    b += telemetry_packet(125, 4, 2, fp(fmt, 31.0))                            # timestamp goes backwards
    b += telemetry_packet(140, 5, 3, fp(fmt, 250.0))                           # out of range
    b += telemetry_packet(150, 6, 4, fp(fmt, float("nan")))                    # NaN sample
    b += telemetry_packet(160, 7, 5, fp(fmt, 5.0), quality=1)                  # sensor-invalid flag
    b += telemetry_packet(9000, 8, 6, fp(fmt, 6.0))                            # gap > max_gap
    b += [b[0], (fp(fmt, 1.0), 0, 1)]                                          # 2-beat malformed packet
    b += [(0, 0, 1)]                                                           # 1-beat malformed packet
    b += telemetry_packet(9010, 9, 7, fp(fmt, 7.0), frame_end=True)
    p = Program(prec).barrier(telem=True)
    readout(p)
    p.vload(10, "TELEM", 0, 0).vadd(11, 10, 10).vstore(11, "RESULT", 0, rows)  # suspect values propagate
    p.halt()
    out.append(Scenario(name="telemetry_anomalies", words=p.assemble(), telemetry=[b],
                        config={"fault_halt": NO_HALT, "telemetry_bounds": bounds, "telemetry_max_gap": 1000},
                        compare={MEM["RESULT"]: rows + 1}))
    return out
