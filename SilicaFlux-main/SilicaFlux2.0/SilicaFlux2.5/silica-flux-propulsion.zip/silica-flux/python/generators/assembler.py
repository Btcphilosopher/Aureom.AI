"""
Silica Flux assembler.

Two front ends producing the same 64-bit instruction words:

1. ``Program`` -- a Python builder used by the host API, tests and benchmarks:

       p = Program(fp_prec="FP32")
       p.seta(0, 0)
       p.label("loop")
       p.vload(1, "STATE", areg=0, off=0)
       p.vfma(3, 1, 2, 3)
       p.bnz(1, "loop")
       p.halt()
       words = p.assemble()

2. ``assemble_text`` -- a line-oriented text syntax (firmware/*.sfa):

       loop:  VLOAD.FP32   v1, STATE[a0+0]
              VFMA.FP32.RNE v3, v1, v2, v3
              VREDUCE.SUM  v4, v3
              BNZ          a1, loop
              HALT

Encoding reference: firmware/instruction_set.md.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from golden_model.isa import (OPCODES, PREC, RM, MEM, CMP, VMS, RED, BAR, TS, SU_LOAD, RES, CONS, OBJ,  # noqa: E402
                              CON, SW, SR, Instr)


class Program:
    def __init__(self, fp_prec: str = "FP32"):
        self.fp = PREC[fp_prec]
        self.items: list = []          # Instr or ("BNZ", ...) placeholders
        self.labels: dict[str, int] = {}

    # ---------------------------------------------------------------- core
    def emit(self, op: str, **kw) -> "Program":
        kw.setdefault("prec", self.fp)
        self.items.append(Instr(OPCODES[op], **kw))
        return self

    def label(self, name: str) -> "Program":
        self.labels[name] = len(self.items)
        return self

    def here(self) -> int:
        return len(self.items)

    def assemble(self) -> list[int]:
        out = []
        for pc, it in enumerate(self.items):
            if isinstance(it, tuple):
                _, areg, target = it
                off = self.labels[target] - pc
                it = Instr(OPCODES["BNZ"], vs1=areg, imm=off & 0x7FFFF)
                self.items[pc] = it
            out.append(it.encode())
        return out

    def instrs(self) -> list[Instr]:
        self.assemble()
        return list(self.items)

    # ---------------------------------------------------------------- control
    def nop(self):
        return self.emit("NOP")

    def halt(self):
        return self.emit("HALT")

    def barrier(self, telem=False, dma=False, swap=False):
        return self.emit("BARRIER", func=(BAR["TELEM"] if telem else 0) | (BAR["DMA"] if dma else 0) |
                         (BAR["SWAP"] if swap else 0))

    def seta(self, a: int, v: int):
        return self.emit("SETA", vd=a, imm=v & 0x7FFFF)

    def adda(self, a: int, v: int):
        return self.emit("ADDA", vd=a, imm=v & 0x7FFFF)

    def bnz(self, a: int, target: str):
        self.items.append(("BNZ", a, target))
        return self

    # ---------------------------------------------------------------- vector ALU
    def _v(self, op, vd, vs1=0, vs2=0, vs3=0, rm="RNE", prec=None, vl=0, masked=0, func=0, imm=0):
        return self.emit(op, vd=vd, vs1=vs1, vs2=vs2, vs3=vs3, rm=RM[rm], prec=self.fp if prec is None else PREC[prec],
                         vl=vl, masked=masked, func=func, imm=imm)

    def vadd(self, vd, a, b, **k): return self._v("VADD", vd, a, b, **k)
    def vsub(self, vd, a, b, **k): return self._v("VSUB", vd, a, b, **k)
    def vmul(self, vd, a, b, **k): return self._v("VMUL", vd, a, b, **k)
    def vfma(self, vd, a, b, c, **k): return self._v("VFMA", vd, a, b, c, **k)
    def vfms(self, vd, a, b, c, **k): return self._v("VFMS", vd, a, b, c, **k)
    def vfnma(self, vd, a, b, c, **k): return self._v("VFNMA", vd, a, b, c, **k)
    def vfnms(self, vd, a, b, c, **k): return self._v("VFNMS", vd, a, b, c, **k)
    def vsqr(self, vd, a, **k): return self._v("VSQR", vd, a, **k)
    def vmin(self, vd, a, b, **k): return self._v("VMIN", vd, a, b, **k)
    def vmax(self, vd, a, b, **k): return self._v("VMAX", vd, a, b, **k)
    def vabs(self, vd, a, **k): return self._v("VABS", vd, a, **k)
    def vneg(self, vd, a, **k): return self._v("VNEG", vd, a, **k)
    def vmov(self, vd, a, **k): return self._v("VMOV", vd, a, **k)
    def vsel(self, vd, a, b, **k): return self._v("VSEL", vd, a, b, **k)
    def vcmp(self, vd, a, b, cmp="LT", **k): return self._v("VCMP", vd, a, b, func=CMP[cmp], **k)
    def vbcast(self, vd, a, lane, **k): return self._v("VBCAST", vd, a, imm=(lane & 0x7F) << 12, **k)
    def vlaneid(self, vd, **k): return self._v("VLANEID", vd, **k)
    def vslide(self, vd, a, shift, **k): return self._v("VSLIDE", vd, a, imm=(shift & 0x7F) << 12, **k)
    def vmset(self, mode="ALL", vs1=0, imm=0, **k): return self._v("VMSET", 0, vs1, func=VMS[mode], imm=imm, **k)
    def vdiv(self, vd, a, b, **k): return self._v("VDIV", vd, a, b, **k)
    def vsqrt(self, vd, a, **k): return self._v("VSQRT", vd, a, **k)
    def vrecip(self, vd, a, **k): return self._v("VRECIP", vd, a, **k)
    def vexp(self, vd, a, **k): return self._v("VEXP", vd, a, **k)
    def vlog(self, vd, a, **k): return self._v("VLOG", vd, a, **k)
    def vpoly(self, vd, x, coeffs, degree, **k): return self._v("VPOLY", vd, x, coeffs, imm=degree, **k)
    def vcube(self, vd, a, **k): return self._v("VCUBE", vd, a, **k)
    def vinterp(self, vd, t, y, d, **k): return self._v("VINTERP", vd, t, y, d, **k)
    def vreduce(self, vd, a, func="SUM", b=0, **k): return self._v("VREDUCE", vd, a, b, func=RED[func], **k)

    def vcvt(self, vd, a, dst="INT", src=None, dst_frac=0, src_frac=0, **k):
        srcp = self.fp if src is None else PREC[src]
        return self._v("VCVT", vd, a, func=srcp, imm=(dst_frac & 63) | ((src_frac & 63) << 6), prec=dst, **k)

    # ---------------------------------------------------------------- memory
    def vload(self, vd, mem, areg=0, off=0, prec=None, **k):
        return self.emit("VLOAD", vd=vd, vs2=areg, func=MEM[mem], imm=off & 0x7FFFF,
                         prec=self.fp if prec is None else PREC[prec], **k)

    def vstore(self, vs, mem, areg=0, off=0, prec=None, **k):
        return self.emit("VSTORE", vs1=vs, vs2=areg, func=MEM[mem], imm=off & 0x7FFFF,
                         prec=self.fp if prec is None else PREC[prec], **k)

    def vldbc(self, vd, mem, areg=0, elem=0, prec=None, **k):
        return self.emit("VLDBC", vd=vd, vs2=areg, func=MEM[mem], imm=elem & 0x7FFFF,
                         prec=self.fp if prec is None else PREC[prec], **k)

    # ---------------------------------------------------------------- engines
    def tscfg(self, dt_reg, method="RK4"):
        return self.emit("TSCFG", vs1=dt_reg, func=TS[method])

    def ts_reset(self):
        return self.emit("TSCFG", func=TS["RESET"])

    def su_load(self, vd, x):
        return self.emit("STATE_UPDATE", vd=vd, vs1=x, func=SU_LOAD)

    def su_stage(self, vd, k, stage, rm="RNE"):
        return self.emit("STATE_UPDATE", vd=vd, vs1=k, func=stage, rm=RM[rm])

    def residual(self, vd, expected, observed, atol, mode="SIGNED", **k):
        return self._v("RESIDUAL", vd, expected, observed, atol, func=RES[mode], **k)

    def conserve(self, vd, x, w, s=0, mode="CHECK", **k):
        return self._v("CONSERVE", vd, x, w, s, func=CONS[mode], **k)

    def objective(self, vd, x, target, weights, mode="SQ", reduce=False, **k):
        return self._v("OBJECTIVE", vd, x, target, weights, func=OBJ[mode] | (8 if reduce else 0), **k)

    def constraint(self, vd, x, bound, tol=0, kind="LT", **k):
        return self._v("CONSTRAINT", vd, x, bound, tol, func=CON[kind], **k)

    def sweep(self, mode="GEN", vd=0, dim=0, **k):
        return self._v("SWEEP", vd, func=SW[mode], imm=dim, **k)

    def search(self, mode="GRID", vs1=0, vd=0, dim=0, **k):
        return self._v("SEARCH", vd, vs1, func=SR[mode], imm=dim, **k)


# =============================================================================
# text assembler
# =============================================================================
_REG = re.compile(r"^[vV](\d+)$")
_AREG = re.compile(r"^[aA](\d)$")
_MEMREF = re.compile(r"^(\w+)\[\s*a(\d)\s*([+-]\s*\d+)?\s*\]$")


def _reg(t):
    m = _REG.match(t.strip())
    if not m:
        raise ValueError(f"expected vector register, got {t!r}")
    return int(m.group(1))


def _areg(t):
    m = _AREG.match(t.strip())
    if not m:
        raise ValueError(f"expected address register, got {t!r}")
    return int(m.group(1))


def assemble_text(src: str, fp_prec: str = "FP32") -> Program:
    p = Program(fp_prec)
    for lineno, raw in enumerate(src.splitlines(), 1):
        line = raw.split(";")[0].split("#")[0].strip()
        if not line:
            continue
        while ":" in line.split()[0]:
            lab, line = line.split(":", 1)
            p.label(lab.strip())
            line = line.strip()
            if not line:
                break
        if not line:
            continue
        mnem, _, rest = line.partition(" ")
        parts = mnem.upper().split(".")
        op = parts[0]
        prec, rm, sub = None, "RNE", None
        for q in parts[1:]:
            if q in PREC:
                prec = q
            elif q in RM:
                rm = q
            else:
                sub = q
        args = [a.strip() for a in rest.split(",")] if rest.strip() else []
        kw = {} if prec is None else {"prec": prec}
        try:
            if op in ("NOP", "HALT"):
                getattr(p, op.lower())()
            elif op == "BARRIER":
                flags = {a.upper() for a in args}
                p.barrier(telem="TELEM" in flags, dma="DMA" in flags, swap="SWAP" in flags)
            elif op in ("SETA", "ADDA"):
                getattr(p, op.lower())(_areg(args[0]), int(args[1], 0))
            elif op == "BNZ":
                p.bnz(_areg(args[0]), args[1])
            elif op in ("VLOAD", "VSTORE", "VLDBC"):
                m = _MEMREF.match(args[1])
                if not m:
                    raise ValueError(f"bad memory reference {args[1]!r}")
                off = int(m.group(3).replace(" ", "")) if m.group(3) else 0
                fn = {"VLOAD": p.vload, "VSTORE": p.vstore, "VLDBC": p.vldbc}[op]
                if op == "VLDBC":
                    fn(_reg(args[0]), m.group(1).upper(), int(m.group(2)), off, **kw)
                else:
                    fn(_reg(args[0]), m.group(1).upper(), int(m.group(2)), off, **kw)
            elif op in ("VREDUCE",):
                p.vreduce(_reg(args[0]), _reg(args[1]), func=sub or "SUM",
                          b=_reg(args[2]) if len(args) > 2 else 0, rm=rm, **kw)
            elif op == "VCMP":
                p.vcmp(_reg(args[0]), _reg(args[1]), _reg(args[2]), cmp=sub or "LT", rm=rm, **kw)
            elif op == "VPOLY":
                p.vpoly(_reg(args[0]), _reg(args[1]), _reg(args[2]), int(args[3], 0), rm=rm, **kw)
            else:
                regs = [_reg(a) for a in args]
                name = op.lower()
                getattr(p, name)(*regs, rm=rm, **kw)
        except (KeyError, IndexError, ValueError, AttributeError) as e:
            raise SyntaxError(f"line {lineno}: {raw.strip()} :: {e}") from None
    return p


if __name__ == "__main__":
    src = Path(sys.argv[1]).read_text()
    prog = assemble_text(src, sys.argv[2] if len(sys.argv) > 2 else "FP32")
    for w in prog.assemble():
        print(f"{w:016x}")
