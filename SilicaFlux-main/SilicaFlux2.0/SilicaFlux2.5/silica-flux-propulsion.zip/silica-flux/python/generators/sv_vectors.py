#!/usr/bin/env python3
"""
Vector files for the self-checking SystemVerilog unit testbenches (tb/*.sv).

    python3 python/generators/sv_vectors.py <out_dir> [--lanes 8] [--fp64]

Formats (hex, one transaction per line):
  fma.vec        op rm a b c | result fflags
  div.vec        a b rm | result fflags          sqrt.vec  a rm | result fflags
  recip/exp/log  a | result fflags
  <fu>.vec       uop a b c qa qb qc lmask vm | data qual wmask vm fflags faults
                 for vector_alu, interpolation_unit, state_update,
                 residual_engine, objective_eval, constraint_eval
Expected values come from the golden model; the testbenches compare bit-exactly.
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from golden_model import ieee, sfu, valu, engines  # noqa: E402
from golden_model.isa import Instr, OPCODES, pack_uop, F, writes_vm  # noqa: E402
from generators.stimulus import FPStimulus, directed_triples, special_values  # noqa: E402


def pk(vals, w):
    v = 0
    for i, x in enumerate(vals):
        v |= (x & ((1 << w) - 1)) << (i * w)
    return v


def fu_line(ins, rm, A, B, C, QA, QB, QC, lmask, vm, data, qual, wmask, vmo, ff, faults, W, L):
    uop = pack_uop(ins, pc=0, tag=0, rm=rm)
    return (f"{uop:x} {pk(A, W):x} {pk(B, W):x} {pk(C, W):x} {pk(QA, 4):x} {pk(QB, 4):x} {pk(QC, 4):x} "
            f"{lmask:x} {vm:x} {pk(data, W):x} {pk(qual, 4):x} {wmask:x} {pk(vmo, 1):x} {ff:x} {faults:x}")


def gen_scalar(out: Path, fmt, n: int, rnd: random.Random):
    st = FPStimulus(fmt, seed=101)
    with open(out / "fma.vec", "w") as f:
        trip = [t for t in directed_triples(fmt)][:600] + [st.triple() for _ in range(n)]
        for k, (a, b, c) in enumerate(trip):
            op, rm = k % 7, (k // 7) % 5
            r, ff = ieee.fma_op(fmt, op, a, b, c, rm)
            f.write(f"{op:x} {rm:x} {a:x} {b:x} {c:x} {r:x} {ff:x}\n")
    with open(out / "div.vec", "w") as f:
        for k in range(n // 2):
            a, b = st.pair()
            rm = k % 5
            r, ff = ieee.div(fmt, a, b, rm)
            f.write(f"{a:x} {b:x} {rm:x} {r:x} {ff:x}\n")
    with open(out / "sqrt.vec", "w") as f:
        for k in range(n // 2):
            a = st.value() & (fmt.mask >> 1) if rnd.random() < 0.8 else st.value()
            rm = k % 5
            r, ff = ieee.sqrt(fmt, a, rm)
            f.write(f"{a:x} {rm:x} {r:x} {ff:x}\n")
    from generators.gen_sfu_tables import sample_inputs
    for name in ("recip", "exp", "log"):
        xs = sample_inputs(name, fmt, n // 2, rnd) + special_values(fmt)
        with open(out / f"{name}.vec", "w") as f:
            for x in xs:
                r, ff = sfu.SFU_FUNCS[name](fmt, x)
                f.write(f"{x:x} {r:x} {ff:x}\n")


def gen_valu(out: Path, fmt, L: int, n: int, rnd: random.Random):
    st = FPStimulus(fmt, seed=202)
    fp = 1 if fmt is ieee.FP64 else 0
    W = fmt.width
    ops = ["VADD", "VSUB", "VMUL", "VFMA", "VFMS", "VFNMA", "VFNMS", "VSQR", "VMIN", "VMAX", "VABS", "VNEG",
           "VCMP", "VSEL", "VMOV", "VCLASS", "VBCAST", "VSLIDE", "VLANEID", "VMSET"]
    with open(out / f"vector_alu_l{L}.vec", "w") as f:
        for k in range(n):
            op = rnd.choice(ops)
            func = rnd.choice([0, 1, 2]) if op in ("VCMP", "VMSET") else 0
            imm = (rnd.randrange(L) << 12) if op in ("VBCAST", "VSLIDE") else (rnd.getrandbits(19) if op == "VMSET" else 0)
            rm = rnd.randrange(5)
            ins = Instr(OPCODES[op], vd=1, vs1=2, vs2=3, vs3=4, prec=fp, rm=rm, func=func, imm=imm)
            A = [st.value() for _ in range(L)]
            B = [st.value() for _ in range(L)]
            C = [st.value() for _ in range(L)]
            QA, QB, QC = ([rnd.choice([0, 0, 1, 8]) for _ in range(L)] for _ in range(3))
            lm = (1 << L) - 1 if rnd.random() < 0.7 else rnd.getrandbits(L)
            vm = rnd.getrandbits(L)
            d, q, mb, ff = valu.valu_vector(fmt, ins, rm, A, B, C, QA, QB, QC, lm, vm, L)
            f.write(fu_line(ins, rm, A, B, C, QA, QB, QC, lm, vm, d, q, lm, mb, ff, 0, W, L) + "\n")


def gen_engines(out: Path, fmt, L: int, n: int, rnd: random.Random):
    fp = 1 if fmt is ieee.FP64 else 0
    W = fmt.width
    fv = fmt.from_float
    full = (1 << L) - 1

    def vec(lo, hi):
        return [fv(rnd.uniform(lo, hi)) for _ in range(L)]

    # interpolation
    with open(out / f"interpolation_l{L}.vec", "w") as f:
        for k in range(n):
            T = [fv(rnd.choice([-1.0, L - 1.0, float("nan"), rnd.uniform(-0.5, L - 0.5)])) for _ in range(L)]
            Y, D = vec(-2, 2), vec(-1, 1)
            Q = [[rnd.choice([0, 0, 8]) for _ in range(L)] for _ in range(3)]
            rm = rnd.randrange(5)
            ins = Instr(OPCODES["VINTERP"], vd=1, vs1=2, vs2=3, vs3=4, prec=fp, rm=rm)
            lm = full if rnd.random() < 0.8 else rnd.getrandbits(L)
            d, q, ff = engines.interp(fmt, rm, T, Y, D, *Q, lm, L)
            f.write(fu_line(ins, rm, T, Y, D, *Q, lm, 0, d, q, lm, [0] * L, ff, 0, W, L) + "\n")
    # state engine: TSCFG + LOAD + stages for several methods (stateful sequence)
    st = engines.EngineState(fmt, L)
    with open(out / f"state_update_l{L}.vec", "w") as f:
        for method in (4, 1, 0, 2, 3):
            dt = [fv(0.05)] + [0] * (L - 1)
            ins = Instr(OPCODES["TSCFG"], vs1=2, prec=fp, func=method)
            bad = engines.tscfg(st, method, dt[0])
            f.write(fu_line(ins, 0, dt, [0] * L, [0] * L, [0] * L, [0] * L, [0] * L, full, 0, dt, [0] * L, full,
                            [0] * L, 0, (1 << F["STEP"]) if bad else 0, W, L) + "\n")
            x = vec(-1, 1)
            ins = Instr(OPCODES["STATE_UPDATE"], vd=1, vs1=2, prec=fp, func=8)
            d, q, ff, fault, _ = engines.state_update(st, 8, 0, x, [0] * L, full)
            f.write(fu_line(ins, 0, x, [0] * L, [0] * L, [0] * L, [0] * L, [0] * L, full, 0, d, q, full, [0] * L,
                            ff, 0, W, L) + "\n")
            for s in range(st.stages + 1):          # one extra stage -> F_STEP
                k = vec(-3, 3)
                rm = rnd.randrange(5)
                ins = Instr(OPCODES["STATE_UPDATE"], vd=1, vs1=2, prec=fp, func=s, rm=rm)
                d, q, ff, fault, _ = engines.state_update(st, s, rm, k, [0] * L, full)
                f.write(fu_line(ins, rm, k, [0] * L, [0] * L, [0] * L, [0] * L, [0] * L, full, 0, d, q, full,
                                [0] * L, ff, (1 << F["STEP"]) if fault else 0, W, L) + "\n")
    # residual / objective / constraint
    st = engines.EngineState(fmt, L)
    st.res_rtol = fv(1e-3)
    for name, op, funcs, fn in (("residual", "RESIDUAL", [0, 1, 2], engines.residual),
                                ("objective", "OBJECTIVE", [0, 1, 2, 3, 8, 9, 10, 11], engines.objective),
                                ("constraint", "CONSTRAINT", [0, 1, 2, 3, 4, 5], engines.constraint)):
        with open(out / f"{name}_l{L}.vec", "w") as f:
            for k in range(n):
                func = rnd.choice(funcs)
                A = vec(-2, 2)
                B = [a if rnd.random() < 0.3 else fv(rnd.uniform(-2, 2)) for a in A]
                C = vec(0, 1)
                Q = [[rnd.choice([0, 0, 0, 8, 1]) for _ in range(L)] for _ in range(3)]
                rm = rnd.randrange(5)
                lm = full if rnd.random() < 0.7 else rnd.getrandbits(L)
                ins = Instr(OPCODES[op], vd=1, vs1=2, vs2=3, vs3=4, prec=fp, rm=rm, func=func)
                vm_out, faults = [0] * L, 0
                if name == "residual":
                    d, q, vm_out, ff, viol = fn(st, func, rm, A, B, C, *Q, lm)
                    faults = (1 << F["RESIDUAL"]) if viol else 0
                    wm = lm
                elif name == "objective":
                    d, q, ff = fn(st, func, rm, A, B, C, *Q, lm)
                    wm = full if func & 8 else lm
                else:
                    d, q, vm_out, ff, fail = fn(st, func, rm, A, B, C, *Q, lm)
                    faults = (1 << F["CONSTRAINT"]) if fail else 0
                    wm = lm
                f.write(fu_line(ins, rm, A, B, C, *Q, lm, 0, d, q, wm, vm_out, ff, faults, W, L) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--lanes", type=int, default=8)
    ap.add_argument("--fp64", action="store_true")
    ap.add_argument("-n", type=int, default=300)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    fmt = ieee.FP64 if a.fp64 else ieee.FP32
    rnd = random.Random(99)
    gen_scalar(out, fmt, a.n, rnd)
    for L in sorted({8, 16, 32, a.lanes}):
        gen_valu(out, fmt, L, a.n, rnd)
    gen_engines(out, fmt, a.lanes, a.n // 2, rnd)
    print(f"vectors written to {out}")


if __name__ == "__main__":
    main()
