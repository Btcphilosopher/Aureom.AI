"""
Stimulus generation for numerical verification.

Pure uniform random bit patterns are a poor test of floating-point hardware:
they almost never exercise cancellation, subnormal boundaries, rounding ties
or overflow thresholds.  This generator mixes

  * directed special values (zeros, infinities, quiet/signalling NaNs,
    smallest/largest subnormal and normal, one, powers of two),
  * exponent-clustered operands (so that additions cancel and products land
    on the overflow / underflow boundaries),
  * near-tie significands (long runs of ones / zeros in the low bits),
  * uniform random encodings.

All generators take an explicit seed so every regression is reproducible.
"""
from __future__ import annotations

import random
from typing import Iterator

from golden_model.ieee import FPFormat


def special_values(fmt: FPFormat) -> list[int]:
    m, w = fmt.man_bits, fmt.width
    s = 1 << (w - 1)
    vals = [
        fmt.zero(0), fmt.zero(1), fmt.inf(0), fmt.inf(1), fmt.qnan(),
        fmt.qnan() | 1, (fmt.exp_mask << m) | 1,                  # qNaN payload, sNaN
        1, s | 1, fmt.man_mask, s | fmt.man_mask,                 # subnormal extremes
        1 << m, s | (1 << m),                                     # min normal
        fmt.max_finite(0), fmt.max_finite(1),
        fmt.one(), s | fmt.one(),
        fmt.one() | 1, fmt.one() - 1,                             # 1 +/- ulp
        (fmt.bias + 1) << m, (fmt.bias - 1) << m,                 # 2, 0.5
        ((fmt.bias + 1) << m) | (1 << (m - 1)),                   # 3
    ]
    return vals


class FPStimulus:
    def __init__(self, fmt: FPFormat, seed: int = 1):
        self.fmt = fmt
        self.rnd = random.Random(seed)
        self.specials = special_values(fmt)

    def _sig(self) -> int:
        f, r = self.fmt, self.rnd.random()
        m = f.man_bits
        if r < 0.15:   # near tie: ...0111111 or ...1000000 patterns
            k = self.rnd.randrange(1, m)
            base = self.rnd.getrandbits(m) & ~((1 << k) - 1)
            return base | (((1 << k) - 1) if self.rnd.random() < 0.5 else (1 << (k - 1)))
        if r < 0.25:
            return self.rnd.choice([0, f.man_mask, 1, 1 << (m - 1)])
        return self.rnd.getrandbits(m)

    def value(self, exp_center: int | None = None, spread: int = 3) -> int:
        f, r = self.fmt, self.rnd.random()
        sgn = self.rnd.getrandbits(1) << (f.width - 1)
        if r < 0.06:
            return self.rnd.choice(self.specials)
        if r < 0.14:                      # subnormal
            return sgn | self.rnd.getrandbits(f.man_bits)
        if r < 0.24:                      # range extremes
            e = self.rnd.choice([1, 2, 3, f.exp_mask - 3, f.exp_mask - 2, f.exp_mask - 1])
            return sgn | (e << f.man_bits) | self._sig()
        if exp_center is not None and r < 0.70:
            e = min(max(exp_center + self.rnd.randint(-spread, spread), 1), f.exp_mask - 1)
            return sgn | (e << f.man_bits) | self._sig()
        if r < 0.85:                      # moderate magnitudes
            e = f.bias + self.rnd.randint(-40, 40)
            return sgn | (e << f.man_bits) | self._sig()
        return self.rnd.getrandbits(f.width)

    def triple(self) -> tuple[int, int, int]:
        """(a, b, c) biased so that a*b and c are often of similar magnitude."""
        f = self.fmt
        a = self.value()
        b = self.value()
        ea, eb = f.efield(a), f.efield(b)
        center = ea + eb - f.bias
        if self.rnd.random() < 0.5 and 1 <= center < f.exp_mask:
            c = self.value(exp_center=center, spread=2)
        else:
            c = self.value()
        return a, b, c

    def pair(self) -> tuple[int, int]:
        a = self.value()
        if self.rnd.random() < 0.4:
            return a, self.value(exp_center=self.fmt.efield(a), spread=1)
        return a, self.value()

    def stream(self, n: int) -> Iterator[tuple[int, int, int]]:
        for _ in range(n):
            yield self.triple()

    def finite_in_range(self, lo: float, hi: float) -> int:
        v = self.rnd.uniform(lo, hi)
        return self.fmt.from_float(v)


def directed_triples(fmt: FPFormat) -> list[tuple[int, int, int]]:
    sp = special_values(fmt)
    out = []
    for a in sp:
        for b in sp:
            for c in (fmt.zero(0), fmt.zero(1), fmt.inf(0), fmt.inf(1), fmt.qnan(), fmt.one(), 1):
                out.append((a, b, c))
    return out
