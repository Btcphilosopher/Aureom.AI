#!/usr/bin/env python3
"""
Silica Flux final report.

Collects every machine-generated result under reports/ (nothing is typed in by
hand) and writes:
    reports/SILICA_FLUX_REPORT.md      the sign-off style summary
    reports/csv/numerics_summary.csv   input for r/validation.R
and prints the summary block (RTL TESTS / NUMERICAL VALIDATION / MAX NUMERICAL
ERROR / THROUGHPUT / PIPELINE LATENCY / RESOURCE ESTIMATE / FAULT TESTS).
A section with no data says NOT RUN -- it is never reported as PASS.
"""
from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
R = ROOT / "reports"


def jload(p: Path):
    try:
        return json.loads(Path(p).read_text())
    except (OSError, json.JSONDecodeError):
        return None


def cload(p: Path):
    try:
        with open(p) as f:
            return list(csv.DictReader(f))
    except OSError:
        return None


def section(title: str, status: str | None, body: list[str]) -> str:
    head = f"{title}: {status}" if status else title
    return head + "\n" + "-" * len(head) + "\n" + "\n".join("  " + b for b in body) + "\n"


def verdict(ok: bool, ran: bool = True) -> str:
    return "NOT RUN" if not ran else ("PASS" if ok else "FAIL")


def main() -> int:
    out: list[str] = []
    status_all = True

    # ================================================================ RTL TESTS
    coco = jload(R / "cocotb_summary.json") or {}
    unit = {k: v for k, v in coco.items() if not k.startswith("top_")}
    svv = jload(R / "sv_testbenches_verilator.json") or {}
    svi = jload(R / "sv_testbenches_icarus.json") or {}
    sysres = {}
    for p in sorted((R / "system").glob("*.json")):
        d = jload(p)
        if isinstance(d, dict) and d and all(isinstance(v, dict) and "match" in v for v in d.values()):
            sysres[p.stem] = d
    top = {p.stem: jload(p) or {} for p in sorted((R / "cocotb_top").glob("*.json"))}
    lint = jload(R / "lint.json") or {}
    sys_n = sum(len(v) for v in sysres.values())
    sys_ok = sum(r["match"] for v in sysres.values() for r in v.values())
    top_n = sum(len(v) for v in top.values())
    top_ok = sum(bool(r.get("match")) for v in top.values() for r in v.values())
    unit_ok = sum(v["failures"] == 0 for v in unit.values())
    svv_ok = sum(v["pass"] for v in svv.values())
    svi_ok = sum(v["pass"] for v in svi.values())
    cfgs = sorted({k.rsplit("_", 1)[0] for k in sysres})
    lines = [
        f"cocotb unit regressions (Icarus)          {unit_ok:>4} / {len(unit):<4} configurations",
        f"SV testbenches (Verilator, SVA enabled)   {svv_ok:>4} / {len(svv):<4} "
        f"({sum(v.get('vectors', 0) for v in svv.values()):,} vectors)",
        f"SV testbenches (Icarus)                   {svi_ok:>4} / {len(svi):<4} "
        f"({sum(v.get('vectors', 0) for v in svi.values()):,} vectors)",
        f"full-chip scenarios (Verilator, SVA)      {sys_ok:>4} / {sys_n:<4} bit-exact vs ISA reference, "
        f"configs: {', '.join(cfgs)}",
        f"full-chip programs (cocotb + Icarus)      {top_ok:>4} / {top_n:<4} bit-exact vs ISA reference",
        f"lint (Verilator -Wall)                    {lint.get('summary', 'NOT RUN')}",
    ]
    ok = (unit_ok == len(unit) > 0 and svv_ok == len(svv) > 0 and svi_ok == len(svi) > 0 and sys_ok == sys_n > 0
          and top_ok == top_n > 0 and lint.get("summary", "").startswith("PASS"))
    status_all &= ok
    out.append(section("RTL TESTS", verdict(ok, bool(svv or sysres)), lines))

    # ================================================================ NUMERICAL VALIDATION
    num = {p.stem: jload(p) for p in sorted((R / "numerics").glob("*.json")) if (jload(p) or {}).get("count")}
    golden = jload(R / "golden_selftest.json") or {}
    gres = golden.get("results", {})
    vec = sum(d["count"] for d in num.values())
    bad = sum(d["failures"] for d in num.values())
    sv_vec = sum(v.get("vectors", 0) for v in svv.values())
    g_n = sum(v["samples"] for v in gres.values())
    g_bad = golden.get("total_mismatches", None)
    lines = [
        f"golden model vs host FPU (RNE)            {g_n:,} operations, {g_bad} mismatches",
        f"RTL vs golden model (cocotb)              {vec:,} transactions, {bad} mismatches "
        f"(value + IEEE flags, under random back-pressure)",
        f"RTL vs golden model (SV testbenches)      {sv_vec:,} vectors x 2 simulators, "
        f"{len(svv) - svv_ok + len(svi) - svi_ok} failing benches",
        f"RTL vs reference (full chip)              every result word, quality bit, flag and fault record",
    ]
    ok = vec > 0 and bad == 0 and g_bad == 0
    status_all &= ok
    out.append(section("NUMERICAL VALIDATION", verdict(ok, vec > 0), lines))

    # ================================================================ MAX NUMERICAL ERROR
    acc = jload(R / "numerics" / "sfu_accuracy.json") or {}
    app = jload(R / "numerics" / "approx_accuracy.json") or {}
    lines = ["ADD SUB MUL FMA SQR DIV SQRT     correctly rounded: <= 0.5 ULP (RNE/RMM), <= 1 ULP (directed)"]
    for k in sorted(k for k in num if k.startswith(("fma_", "div_", "sqrt_"))):
        if k in num:
            u = num[k]["ulp"]
            lines.append(f"  measured on RTL {k:<15} max {u['max']:.4f}  mean {u['mean']:.4f}  RMS {u['rms']:.4f} ULP"
                         f"  (all modes, n={num[k]['count']:,})")
    for k in ("recip_fp32", "exp_fp32", "log_fp32", "recip_fp64", "exp_fp64", "log_fp64"):
        if k in acc:
            a = acc[k]
            lines.append(f"{k:<32} max {a['max_ulp']:.4f}  mean {a['mean_ulp']:.4f}  RMS {a['rms_ulp']:.4f} ULP"
                         f"  (n={a['samples']:,})")
    for fm in ("fp32", "fp64"):
        for k in ("cube", "poly5", "interp"):
            if k in app.get(fm, {}):
                a = app[fm][k]
                lines.append(f"{k + '_' + fm:<32} max {a['max_ulp']:.4f}  mean {a['mean_ulp']:.4f}  "
                             f"RMS {a['rms_ulp']:.4f} ULP  (n={a['samples']:,})")
    worst = max([a["max_ulp"] for a in acc.values()] or [float("nan")])
    lines.append(f"worst special function: {worst:.4f} ULP; worst composite: Horner degree 5 "
                 f"{max((app.get(f, {}).get('poly5', {}).get('max_ulp', 0) for f in ('fp32', 'fp64')), default=0):.4f} ULP")
    out.append(section("MAX NUMERICAL ERROR", None, lines))
    rows = []
    for k, a in acc.items():
        rows.append({"kind": "sfu", "name": k, "max_ulp": a["max_ulp"], "mean_ulp": a["mean_ulp"],
                     "rms_ulp": a["rms_ulp"], "samples": a["samples"]})
    for fm, d in app.items():
        for k, a in d.items():
            rows.append({"kind": "composite", "name": f"{k}_{fm}", "max_ulp": a["max_ulp"],
                         "mean_ulp": a["mean_ulp"], "rms_ulp": a["rms_ulp"], "samples": a["samples"]})
    for k, d in num.items():
        rows.append({"kind": "rtl", "name": k, "max_ulp": d["ulp"]["max"], "mean_ulp": d["ulp"]["mean"],
                     "rms_ulp": d["ulp"]["rms"], "samples": d["count"]})
    (R / "csv").mkdir(parents=True, exist_ok=True)
    if rows:
        with open(R / "csv" / "numerics_summary.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

    # ================================================================ THROUGHPUT
    bench = jload(R / "benchmark" / "benchmark.json") or {}
    lines = []
    for cfg, ks in bench.items():
        pk = ks.get("_peak", {})
        runs = {n: r for n, r in ks.items() if not n.startswith("_")}
        if not runs:
            continue
        best = max(runs.values(), key=lambda r: r["flops_per_cycle"])
        errs = [r["model_error_pct"] for r in runs.values()]
        lines.append(f"{cfg:<9} peak {pk.get('valu_flops_per_cycle')} FLOP/cycle; measured best "
                     f"{best['flops_per_cycle']:.2f} FLOP/cycle ({best['kernel']}), "
                     f"~{best['gflops_est_250MHz']:.2f} GFLOP/s @ 250 MHz assumed; "
                     f"model error {min(errs):+.1f}..{max(errs):+.1f}% "
                     f"({runs[next(iter(runs))].get('model_set', '')})")
        for n, r in runs.items():
            lines.append(f"    {n:<24} {r['cycles']:>7,} cycles  {r['flops_per_cycle']:>6.2f} FLOP/cycle  "
                         f"util {r['vector_utilisation']:.3f}  {'MATCH' if r['verified'] else 'MISMATCH'}")
    ok = bool(lines) and all(r["verified"] for ks in bench.values() for n, r in ks.items() if not n.startswith("_"))
    out.append(section("THROUGHPUT", verdict(ok, bool(lines)) + " (cycles measured on RTL; GFLOP/s = estimate)",
                       lines or ["NOT RUN"]))

    # ================================================================ PIPELINE LATENCY
    lines = ["nominal (normal operands, no back-pressure), cycles:",
             "  VALU / FMA                 PIPELINE_DEPTH (4 / 5 / 6 in the regression configurations), "
             "fully pipelined",
             "  DIV / SQRT (DIV_BPC = 1)   FP32 29, FP64 58  (DIV_BPC = 2: FP32 16, FP64 31)"]
    for k in ("recip", "exp", "log"):
        a32, a64 = acc.get(f"{k}_fp32", {}), acc.get(f"{k}_fp64", {})
        lines.append(f"  {k.upper():<26} FP32 {a32.get('latency_cycles', '?')}, FP64 {a64.get('latency_cycles', '?')}")
    lines.append("measured per transaction under random output back-pressure (min = special-operand fast path):")
    for k, d in num.items():
        lt = d["latency"]
        lines.append(f"  {k:<26} min {lt['min']:>3}  mean {lt['mean']:>6.1f}  max {lt['max']:>3}")
    out.append(section("PIPELINE LATENCY", None, lines))

    # ================================================================ RESOURCE ESTIMATE
    lines = []
    for p in sorted((R / "synth").glob("*.json")):
        d = jload(p)
        if not d:
            continue
        chk = d.get("check", {})
        tot = d.get("logic_total") or {}
        failed = d.get("blocks_failed", [])
        if d.get("target") == "xilinx":
            res = (f"LUT {tot.get('LUT', 0):,}  FF {tot.get('FF', 0):,}  DSP {tot.get('DSP', 0):,}  "
                   f"CARRY {tot.get('CARRY', 0):,}  BRAM36 ~{d.get('bram36_estimate', '?')}") if tot else "logic: not run"
        else:
            res = (f"{int(tot.get('cell_count', 0)):,} generic cells, ~{tot.get('transistors', 0):.3g} transistors, "
                   f"SRAM {d.get('sram_kbit', '?')} Kbit") if tot else "logic: not run"
        el = ("elaborates, " + str(chk.get("latches", "?")) + " latches, check -assert clean") if chk.get("elaborates") \
            else ("elaboration NOT RUN" if not chk else "elaboration FAILED")
        lines.append(f"{p.stem:<11} {d.get('description', '')}")
        lines.append(f"            {el}")
        lines.append(f"            {res}  (Yosys {d.get('target')}, pre-place-and-route ESTIMATE; "
                     f"clock {d.get('clock_mhz_assumed')} MHz assumed)")
        if d.get("method"):
            lines.append(f"            method: {d['method']}")
        sc = d.get("scaling_check") or {}
        if sc:
            lines.append("            scaling check vs full-width synthesis: " + ", ".join(
                f"{k} {v['ratio_full_over_scaled']:.2f}" for k, v in sc.items()) + " (full / scaled)")
        for n_ in d.get("notes", []):
            lines.append(f"            note: {n_}")
        if failed:
            lines.append(f"            excluded (timed out, not extrapolated): {', '.join(failed)}")
    out.append(section("RESOURCE ESTIMATE", None, lines or ["NOT RUN"]))

    # ================================================================ FORMAL
    fm = jload(R / "formal.json") or {}
    lines = [f"{k:<12} {v['result']:<22} {v['description']}" for k, v in fm.items()]
    fok = bool(fm) and all(v["result"].startswith(("PROVEN", "BMC PASS")) for v in fm.values())
    status_all &= fok
    out.append(section("FORMAL VERIFICATION", verdict(fok, bool(fm)), lines or ["NOT RUN"]))

    # ================================================================ FAULT TESTS
    ft = {k: v for k, v in sysres.items() if k.endswith("_faults") or k.endswith("_telemetry")}
    n = sum(len(v) for v in ft.values())
    k_ok = sum(r["match"] for v in ft.values() for r in v.values())
    tbf = svv.get("tb_faults", {}).get("pass")
    iso = [r for k, v in top.items() if k.startswith("isolation") for r in v.values()]
    ok = n > 0 and k_ok == n and bool(tbf) and (not iso or all(r.get("match") for r in iso))
    status_all &= ok
    names = sorted({s for v in ft.values() for s in v})
    lines = [f"{k_ok} / {n} full-chip fault and telemetry-anomaly scenarios ({len(ft) // 2 if ft else 0} configurations):",
             "  fault status, first fault id + PC, halt behaviour, quality bits, telemetry counters and memories",
             "  match the reference model bit-exactly",
             f"tb_faults (fault manager, watchdog, parity, range checker, FIFO): {verdict(bool(tbf), tbf is not None)}",
             f"job isolation across START (cocotb, Icarus): {sum(bool(r.get('match')) for r in iso)} / {len(iso)}",
             "scenarios: " + ", ".join(names)]
    out.append(section("FAULT TESTS", verdict(ok, n > 0), lines))

    # ================================================================ WORKLOAD
    wl = jload(R / "workload" / "summary.json")
    if wl:
        p1, p2 = wl["part1"], wl["part2"]
        lines = [f"thermal digital twin (8 nodes, RK4, {p1['diagnostics'].get('steps')} steps): RTL "
                 f"{p1['verification'].get('status')}, {p1['diagnostics']['cycles']:,} cycles, conservation residual "
                 f"{p1['conservation']['residual']:.3e} J, faults {p1['diagnostics']['faults']} on channel(s) "
                 f"{p1['flagged_channels']}",
                 f"design sweep: {p2['candidates']} candidates, {p2['feasible']} feasible, hardware arg-min "
                 f"#{p2['best_index']} (host check #{p2['host_check_index']}), compass search J "
                 f"{p2['best']['J']:.4g} -> {p2['local_search_final']['J_center']:.4g}; RTL "
                 f"{p2['verification'].get('status')}"]
        mc = cload(R / "r_monte_carlo.csv")
        if mc:
            m = mc[0]
            lines.append(f"Monte Carlo (R, {int(float(m['samples'])):,} samples, 5% tolerance): P(constraint violation) "
                         f"= {float(m['p_violation']):.4f}, margin p05 = {float(m['margin_p05_K']):.2f} K")
        out.append(section("END-TO-END WORKLOAD", None, lines))

    text = "\n".join(out)
    print(text)
    print(f"OVERALL: {'PASS' if status_all else 'ATTENTION REQUIRED'}")
    md = ["# Silica Flux -- verification and performance report", "",
          "_Generated by `python/analysis/report.py` from the result files in `reports/`. Cycle counts are "
          "measured on the RTL; figures at a clock frequency are estimates at an assumed clock; resource figures "
          "are pre-place-and-route Yosys estimates._", "", "```", text, f"OVERALL: {'PASS' if status_all else 'ATTENTION REQUIRED'}",
          "```", ""]
    if num:
        md += ["## Per-primitive RTL statistics", "",
               "| primitive | transactions | mismatches | max ULP | mean ULP | RMS ULP | latency min/mean/max |",
               "|---|---|---|---|---|---|---|"]
        for k, d in num.items():
            lt = d["latency"]
            md.append(f"| {k} | {d['count']:,} | {d['failures']} | {d['ulp']['max']:.4f} | {d['ulp']['mean']:.4f} | "
                      f"{d['ulp']['rms']:.4f} | {lt['min']}/{lt['mean']:.1f}/{lt['max']} |")
    (R / "SILICA_FLUX_REPORT.md").write_text("\n".join(md) + "\n")
    return 0 if status_all else 1


if __name__ == "__main__":
    sys.exit(main())
