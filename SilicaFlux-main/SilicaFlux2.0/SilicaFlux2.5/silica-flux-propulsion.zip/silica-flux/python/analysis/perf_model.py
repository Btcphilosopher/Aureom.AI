"""
Silica Flux analytical performance model.

Predicts the cycle count of a program from its executed instruction trace
(produced by the reference model) using the microarchitecture's timing
structure -- not by simulating the RTL:

  * front end: IMEM read (1 cycle) into a 2-entry decode queue; a fetch may
    start only once the instruction two places ahead has issued, so straight-
    line code sustains about 2 instructions per 3 cycles
  * in-order single issue; a unit sees an op DISPATCH cycles after issue
  * a result is usable AVAIL cycles after the unit completes (write-back
    arbitration + scoreboard release)
  * RAW / WAW: the consumer issues after the producer's result is usable
  * pipelined VALU (latency = PIPELINE_DEPTH); every other unit is busy until
    its operation completes (iterative engines; response buffering lets a
    unit accept the next op ENGINE_EARLY cycles before it completes)
  * taken BNZ: fetch restarts REDIRECT cycles after the branch issues;
    BARRIER / HALT drain the machine

The structural constants (TIMING below) were calibrated once against RTL
cycle counts of the FP32 8/16-lane and FP64 8-lane benchmark runs; the
32-lane configuration is held out and reported as an independent check by
python/analysis/benchmark.py.  Unit latencies are derived from the RTL
algorithms (docs/performance.md).  No figure here describes physical silicon.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from golden_model import sfu
from golden_model.isa import Instr, OPNAMES, FU_OF, FU, src_use, writes_vd, writes_vm


# calibrated structural timing constants (cycles) -- see module docstring
TIMING = {"fetch_to_issue": 2, "queue_release": 1, "redirect": 3, "dispatch": 1, "avail": 2,
          "engine_early": 2}


@dataclass
class Micro:
    lanes: int = 8
    fp_mode: int = 0
    depth: int = 4          # PIPELINE_DEPTH (FMA / VALU latency)
    div_bpc: int = 1

    @property
    def p(self):
        return 53 if self.fp_mode else 24

    def fma_pass(self) -> int:
        # one pass through the lockstep FMA array of an engine
        return self.depth

    def latency(self, ins: Instr) -> int:
        n = OPNAMES.get(ins.opcode, "")
        fu = FU_OF.get(ins.opcode, 15)
        L, F = self.lanes, self.fma_pass()
        lv = max(1, int(math.log2(L)))
        prm = sfu.SFU_PARAMS["fp64" if self.fp_mode else "fp32"]
        if fu == FU["VALU"]:
            return self.depth
        if n == "VDIV" or n == "VSQRT":
            return 3 + math.ceil((self.p + 2) / self.div_bpc)
        if n == "VRECIP":
            return 3 + 2 * prm["recip_iter"]
        if n == "VEXP":
            return 5 + prm["exp_deg"]
        if n == "VLOG":
            return 6 + prm["log_deg"]
        if fu == FU["LSU"]:
            return 4
        if fu == FU["RED"]:
            f = ins.func
            if f in (0,):
                return 2 + lv * F
            if f in (3, 4):
                return 2 + (lv + 1) * F
            return 3 + lv
        if n == "VPOLY":
            d = min(ins.imm & 15, L - 1)
            return 2 + max(d, 0) * F
        if n == "VCUBE":
            return 2 + 2 * F
        if fu == FU["INTERP"]:
            return 2 + 2 * F
        if n == "TSCFG":
            return 3 + 10 * F
        if n == "STATE_UPDATE":
            return 3 + 4 * F       # upper bound: tableau rows have <= 4 non-zero terms
        if fu == FU["RESID"]:
            return 2 + (3 if ins.func == 2 else 2) * F
        if fu == FU["CONS"]:
            red = 2 + (lv + 1) * F
            return red if ins.func == 0 else 2 * red + 3 * F + 3 + math.ceil((self.p + 2) / 2)
        if fu == FU["OBJ"]:
            passes = {0: 1, 1: 2, 2: 3, 3: 2}[ins.func & 3]
            return 2 + passes * F + ((2 + lv * F) if ins.func & 8 else 0)
        if fu == FU["CON"]:
            return 2 + (2 if ins.func == 3 else 1) * F
        if fu == FU["SWEEP"]:
            return {0: L + 1, 1: F + 1, 2: L + 1}.get(ins.func, F)
        if fu == FU["SEARCH"]:
            return {0: 2, 3: F + 1}.get(ins.func, 4 + lv + F)
        return 1


def flops(ins: Instr, active: int) -> int:
    """floating-point operation count (FMA = 2) of one executed instruction"""
    n = OPNAMES.get(ins.opcode, "")
    per = {"VADD": 1, "VSUB": 1, "VMUL": 1, "VSQR": 1, "VFMA": 2, "VFMS": 2, "VFNMA": 2, "VFNMS": 2,
           "VMIN": 1, "VMAX": 1, "VCMP": 1, "VDIV": 1, "VSQRT": 1, "VRECIP": 1, "VEXP": 1, "VLOG": 1,
           "VCUBE": 2, "VINTERP": 3, "RESIDUAL": 3, "CONSTRAINT": 2, "SWEEP": 2}.get(n, 0)
    if n == "VPOLY":
        per = 2 * (ins.imm & 15)
    elif n == "VREDUCE":
        per = 2 if ins.func in (3, 4) else 1
    elif n == "STATE_UPDATE":
        per = 0 if ins.func == 8 else 2 * (ins.func + 1)
    elif n == "OBJECTIVE":
        per = {0: 1, 1: 2, 2: 3, 3: 2}[ins.func & 3] + (1 if ins.func & 8 else 0)
    elif n == "CONSERVE":
        per = 2 if ins.func == 0 else 4
    return per * active


def predict(trace: list, words: list, m: Micro, timing: dict | None = None) -> dict:
    """trace: executed PCs (reference model) -> predicted cycles and statistics"""
    T = dict(TIMING, **(timing or {}))
    ready = [0] * 32            # cycle a register value is usable
    vm_ready = 0
    fu_free = {}
    last_complete = 0
    flop_total = 0
    prev_pc = None
    issued, fetch = [], []
    last_issue = -1
    redirect_at = 0
    for pc in trace:
        ins = Instr.decode(words[pc])
        n = OPNAMES.get(ins.opcode, "")
        fu = FU_OF.get(ins.opcode, 15)
        f = fetch[-1] + 1 if fetch else 0                   # front end
        if len(issued) >= 2:
            f = max(f, issued[-2] + T["queue_release"])
        if prev_pc is not None and pc != prev_pc + 1:
            f = max(f, redirect_at)                         # taken branch
        fetch.append(f)
        prev_pc = pc
        t = max(f + T["fetch_to_issue"], last_issue + 1)
        if fu == FU["CTRL"]:
            if n in ("BARRIER", "HALT"):
                t = max(t, last_complete)
            issued.append(t)
            last_issue = t
            if n == "BNZ":
                redirect_at = t + T["redirect"]
            continue
        use = src_use(ins)
        dep = t
        for bit, r in ((0, ins.vs1), (1, ins.vs2), (2, ins.vs3)):
            if use >> bit & 1:
                dep = max(dep, ready[r])
        if use & 8:
            dep = max(dep, vm_ready)
        if writes_vd(ins):
            dep = max(dep, ready[ins.vd])
        issue = max(dep, fu_free.get(fu, 0))
        done = issue + T["dispatch"] + m.latency(ins)
        if fu != FU["VALU"]:
            fu_free[fu] = done - T["engine_early"]
        avail = done + T["avail"]
        if writes_vd(ins):
            ready[ins.vd] = avail
        if writes_vm(ins):
            vm_ready = avail
        last_complete = max(last_complete, done + 1)
        flop_total += flops(ins, m.lanes if ins.vl == 0 else ins.vl)
        issued.append(issue)
        last_issue = issue
    return {"cycles": max(last_issue + 1, last_complete) + 1, "flops": flop_total}


def peak(m: Micro) -> dict:
    """architectural peak rates per cycle"""
    return {"valu_flops_per_cycle": 2 * m.lanes, "lane_ops_per_cycle": m.lanes,
            "memory_rows_per_cycle": 1, "memory_bytes_per_cycle": m.lanes * (8 if m.fp_mode else 4)}
