#!/usr/bin/env python3
"""
Accuracy characterisation of the composite approximation primitives.

    python3 python/analysis/approx_accuracy.py [-n 4000]

The RTL is verified bit-exact against the golden model, so the hardware error
equals the golden-model error measured here against exact rational
arithmetic (fractions.Fraction, no floating point in the reference):

  VSQR     x^2                   one rounding
  VCUBE    x^3 = (x*x)*x         two roundings
  VPOLY    degree-5 Horner p(x)  FMA chain (5 roundings), well-conditioned
           test polynomial (truncated exp series) on [-1, 1]
  VINTERP  linear interpolation  error of the arithmetic vs exact
           y_i + (t - i) * d_i on the same table (not the modelling error of
           approximating a function by a piecewise-linear table, which depends
           on the table and is reported separately for exp on 8 knots)

Output: reports/numerics/approx_accuracy.json (+ CSV of per-sample errors)
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sys
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))

from golden_model import ieee, engines  # noqa: E402


def stats(errs):
    e = [x for x in errs if math.isfinite(x)]
    return {"samples": len(errs), "max_ulp": max(e), "mean_ulp": sum(e) / len(e),
            "rms_ulp": math.sqrt(sum(x * x for x in e) / len(e)), "non_finite": len(errs) - len(e)}


def run(fmt, n, rnd, rows):
    L = 8
    out = {}
    fx = fmt.from_float
    fr = fmt.to_fraction
    # VSQR / VCUBE over a wide finite domain (no overflow / underflow region)
    lim = 1e12 if fmt is ieee.FP32 else 1e100
    xs = [fx(math.copysign(10 ** rnd.uniform(-math.log10(lim) / 3, math.log10(lim) / 3), rnd.choice([-1, 1])))
          for _ in range(n)]
    e2, e3 = [], []
    for x in xs:
        r, _ = ieee.mul(fmt, x, x, ieee.RNE)
        e2.append(ieee.ulp_error(fmt, r, fr(x) ** 2))
        d, _, _ = engines.cube(fmt, ieee.RNE, [x] * L, [0] * L, 1, L)
        e3.append(ieee.ulp_error(fmt, d[0], fr(x) ** 3))
        rows.append((fmt.name, "cube", float(fr(x)), e3[-1]))
    out["sqr"] = dict(stats(e2), operation="VSQR x*x", roundings=1, domain=f"|x| < {lim:.0e}^(1/3) (sampled)",
                      bound_ulp=0.5)
    out["cube"] = dict(stats(e3), operation="VCUBE (x*x)*x", roundings=2, domain="as VSQR",
                       bound_ulp=2.0, bound_note="two roundings, each <= 2^-p relative -> < 2 ULP")
    # VPOLY: c_k = 1/k!, degree 5, x in [-1, 1]
    coef = [fx(1.0 / math.factorial(k)) for k in range(6)]
    cf = [fr(c) for c in coef]
    ep = []
    for _ in range(n):
        x = fx(rnd.uniform(-1, 1))
        d, _, _ = engines.poly(fmt, ieee.RNE, 5, [x] * L, coef + [0] * (L - 6), [0] * L, [0] * L, 1, L)
        exact = sum(cf[k] * fr(x) ** k for k in range(6))
        ep.append(ieee.ulp_error(fmt, d[0], exact))
        rows.append((fmt.name, "poly5", float(fr(x)), ep[-1]))
    out["poly5"] = dict(stats(ep), operation="VPOLY degree 5 Horner (FMA chain)", roundings=5,
                        domain="x in [-1, 1], c_k = 1/k! (rounded)", note="error of evaluation vs exact p(x) "
                        "with the rounded coefficients")
    # VINTERP arithmetic error and modelling error for exp on [0, 1] with 8 knots
    knots = [fx(math.exp(i / (L - 1))) for i in range(L)]
    slopes = [ieee.sub(fmt, knots[i + 1], knots[i], ieee.RNE)[0] for i in range(L - 1)] + [fmt.zero(0)]
    ei, em = [], []
    for _ in range(n):
        t = fx(rnd.uniform(0, L - 1))
        d, _, _ = engines.interp(fmt, ieee.RNE, [t] * L, knots, slopes, [0] * L, [0] * L, [0] * L, 1, L)
        i = min(int(fr(t)), L - 2)
        exact = fr(knots[i]) + (fr(t) - i) * fr(slopes[i])
        ei.append(ieee.ulp_error(fmt, d[0], exact))
        em.append(abs(float(fr(d[0])) - math.exp(float(fr(t)) / (L - 1))) / math.exp(float(fr(t)) / (L - 1)))
        rows.append((fmt.name, "interp", float(fr(t)), ei[-1]))
    out["interp"] = dict(stats(ei), operation="VINTERP y_i + (t-i)*d_i", roundings=1, bound_ulp=0.5,
                         bound_note="t - i is exact (Sterbenz), the FMA rounds once",
                         domain="t in [0, LANES-1]; outside -> clamped + Q_SUSPECT",
                         table_model_error={"function": "exp(x) on [0,1], 8 knots",
                                            "max_rel": max(em), "mean_rel": sum(em) / len(em)})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-n", type=int, default=4000)
    a = ap.parse_args()
    rnd = random.Random(2024)
    rows = []
    res = {"fp32": run(ieee.FP32, a.n, rnd, rows), "fp64": run(ieee.FP64, a.n // 4, rnd, rows)}
    d = ROOT / "reports" / "numerics"
    d.mkdir(parents=True, exist_ok=True)
    (d / "approx_accuracy.json").write_text(json.dumps(res, indent=2))
    with open(d / "approx_accuracy.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["format", "primitive", "x", "ulp_error"])
        w.writerows(rows)
    for fm, r in res.items():
        for k, v in r.items():
            print(f"[approx] {fm} {k:<7} max {v['max_ulp']:.4f} ULP  mean {v['mean_ulp']:.4f}  "
                  f"RMS {v['rms_ulp']:.4f}  (n={v['samples']})")


if __name__ == "__main__":
    main()
