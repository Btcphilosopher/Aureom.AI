#!/usr/bin/env python3
"""
Silica Flux engineering display.

    python3 python/analysis/dashboard.py        -> reports/dashboard.html (+ terminal summary)

Every number on the page is read from a result file the simulators and
analysis scripts wrote under reports/ -- nothing is typed in or simulated
here.  A panel whose source file is missing says so instead of showing data.

Visual language: graphite / white / deep navy / engineering grey / steel,
muted blue and restrained amber as the two data colours (palette validated
for colour-vision deficiency in light and dark mode), red only where the
hardware recorded a fault.  Static HTML, inline SVG, no external resources.
"""
from __future__ import annotations

import csv
import html
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
R = ROOT / "reports"
E = html.escape


def jload(p):
    try:
        return json.loads(Path(p).read_text())
    except (OSError, json.JSONDecodeError):
        return None


def cload(p):
    try:
        with open(p) as f:
            return list(csv.DictReader(f))
    except OSError:
        return None


def fmt(v, nd=3):
    if isinstance(v, (int,)) or (isinstance(v, float) and v.is_integer() and abs(v) >= 100):
        return f"{int(v):,}"
    return f"{v:.{nd}g}" if isinstance(v, float) else str(v)


def table(head, rows, cls=""):
    h = "".join(f"<th>{E(str(x))}</th>" for x in head)
    b = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
    return f'<div class="tw"><table class="{cls}"><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table></div>'


def details(title, inner):
    return f'<details><summary>{E(title)}</summary>{inner}</details>'


def ok_label(ok, text_ok="PASS", text_bad="FAIL"):
    return (f'<span class="st ok">&#10003; {text_ok}</span>' if ok
            else f'<span class="st bad">&#9888; {text_bad}</span>')


def fault_chip(name):
    return f'<span class="chip fault" title="fault recorded by the fault manager">{E(name)}</span>'


# =============================================================================
# SVG helpers
# =============================================================================
class Plot:
    def __init__(self, w, h, ml=56, mr=16, mt=14, mb=36):
        self.w, self.h, self.ml, self.mr, self.mt, self.mb = w, h, ml, mr, mt, mb
        self.parts = []

    @property
    def iw(self):
        return self.w - self.ml - self.mr

    @property
    def ih(self):
        return self.h - self.mt - self.mb

    def sx(self, x, x0, x1):
        return self.ml + (x - x0) / (x1 - x0) * self.iw

    def sy(self, y, y0, y1):
        return self.mt + self.ih - (y - y0) / (y1 - y0) * self.ih

    def add(self, s):
        self.parts.append(s)

    def svg(self, label):
        return (f'<svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{E(label)}" '
                f'preserveAspectRatio="xMidYMid meet">{"".join(self.parts)}</svg>')


def nice_ticks(lo, hi, n=5):
    span = hi - lo if hi > lo else 1.0
    step = 10 ** math.floor(math.log10(span / n))
    for m in (1, 2, 2.5, 5, 10):
        if span / (step * m) <= n:
            step *= m
            break
    t = math.floor(lo / step) * step              # outer ticks enclose the data
    out = []
    while t < hi + step - 1e-9 * step:
        out.append(round(t, 10))
        t += step
    return out


def axes(p, x0, x1, y0, y1, xt, yt, xl, yl, xfmt=str, yfmt=str):
    for t in yt:
        y = p.sy(t, y0, y1)
        p.add(f'<line class="grid" x1="{p.ml}" x2="{p.ml + p.iw}" y1="{y:.1f}" y2="{y:.1f}"/>')
        p.add(f'<text class="tick" x="{p.ml - 6}" y="{y + 3.5:.1f}" text-anchor="end">{E(yfmt(t))}</text>')
    for t in xt:
        if not min(x0, x1) - 1e-9 <= t <= max(x0, x1) + 1e-9:
            continue
        x = p.sx(t, x0, x1)
        p.add(f'<text class="tick" x="{x:.1f}" y="{p.mt + p.ih + 15}" text-anchor="middle">{E(xfmt(t))}</text>')
    p.add(f'<line class="axis" x1="{p.ml}" x2="{p.ml + p.iw}" y1="{p.mt + p.ih}" y2="{p.mt + p.ih}"/>')
    p.add(f'<text class="axlabel" x="{p.ml + p.iw / 2}" y="{p.h - 4}" text-anchor="middle">{E(xl)}</text>')
    p.add(f'<text class="axlabel" transform="translate(12 {p.mt + p.ih / 2}) rotate(-90)" '
          f'text-anchor="middle">{E(yl)}</text>')


# =============================================================================
# panels
# =============================================================================
def panel_verification():
    coco = jload(R / "cocotb_summary.json") or {}
    svv = jload(R / "sv_testbenches_verilator.json") or {}
    svi = jload(R / "sv_testbenches_icarus.json") or {}
    golden = jload(R / "golden_selftest.json") or {}
    formal = jload(R / "formal.json") or {}
    lint = jload(R / "lint.json") or {}
    sysres = {}
    for p in sorted((R / "system").glob("*.json")):
        d = jload(p)
        if isinstance(d, dict) and d and all(isinstance(v, dict) and "match" in v for v in d.values()):
            sysres[p.stem] = d
    top = {}
    for p in sorted((R / "cocotb_top").glob("*.json")):
        d = jload(p) or {}
        top[p.stem] = d
    num = {p.stem: jload(p) for p in sorted((R / "numerics").glob("*.json")) if (jload(p) or {}).get("count")}
    synth = {p.stem: jload(p) for p in sorted((R / "synth").glob("*.json"))}
    rows = []

    def row(layer, tool, n_ok, n, detail):
        rows.append([E(layer), E(tool), f"{n_ok:,} / {n:,}", ok_label(n > 0 and n_ok == n) if n else
                     '<span class="st na">NOT RUN</span>', E(detail)])
    gm = golden.get("results", {})
    row("golden model vs host FPU", "Python", sum(v["samples"] - v["mismatches"] for v in gm.values()),
        sum(v["samples"] for v in gm.values()), "operations, bit-exact (RNE)")
    unit = {k: v for k, v in coco.items() if not k.startswith("top_")}
    row("unit regressions", "cocotb + Icarus", sum(v["failures"] == 0 for v in unit.values()), len(unit),
        f"configurations; {sum(d['count'] for d in num.values()):,} vectors, "
        f"{sum(d['failures'] for d in num.values())} mismatches")
    row("SV testbenches", "Verilator (+SVA)", sum(v["pass"] for v in svv.values()), len(svv),
        f"{sum(v.get('vectors', 0) for v in svv.values()):,} vectors")
    row("SV testbenches", "Icarus", sum(v["pass"] for v in svi.values()), len(svi),
        f"{sum(v.get('vectors', 0) for v in svi.values()):,} vectors")
    n = sum(len(v) for v in sysres.values())
    row("full-chip scenarios", "Verilator (+SVA)", sum(r["match"] for v in sysres.values() for r in v.values()), n,
        f"{len({k.rsplit('_', 1)[0] for k in sysres})} configurations, bit-exact vs ISA reference")
    tn = sum(len(v) for v in top.values())
    row("full-chip programs", "cocotb + Icarus", sum(bool(r.get("match")) for v in top.values() for r in v.values()),
        tn, "second simulator, same reference")
    row("formal harnesses", "SymbiYosys / Yosys SAT",
        sum(v["result"].startswith(("PROVEN", "BMC PASS")) for v in formal.values()), len(formal),
        f"{sum(v['result'].startswith('PROVEN') for v in formal.values())} proven by induction")
    row("lint", "Verilator -Wall", sum(c["pass"] for c in lint.get("configs", {}).values()),
        len(lint.get("configs", {})), "synthesis configurations, 0 functional warnings")
    chk = [v["check"] for v in synth.values() if v.get("check")]
    row("synthesis elaboration", "Yosys 0.71", sum(bool(c.get("elaborates")) for c in chk), len(chk),
        "check -assert, latch-free")
    return table(["layer", "tool", "passed", "status", "scope"], rows, "wide")


def panel_accuracy():
    acc = jload(R / "numerics" / "sfu_accuracy.json") or {}
    app = jload(R / "numerics" / "approx_accuracy.json") or {}
    items = []
    for k in ("recip_fp32", "exp_fp32", "log_fp32", "recip_fp64", "exp_fp64", "log_fp64"):
        if k in acc:
            a = acc[k]
            items.append((k.replace("_", " "), a["max_ulp"], a["mean_ulp"], a["rms_ulp"], a["samples"], 0.5))
    for fm in ("fp32", "fp64"):
        for k, b in (("sqr", 0.5), ("cube", 2.0), ("poly5", None), ("interp", 0.5)):
            if k in app.get(fm, {}):
                a = app[fm][k]
                items.append((f"{k} {fm}", a["max_ulp"], a["mean_ulp"], a["rms_ulp"], a["samples"], b))
    if not items:
        return '<p class="na">reports/numerics not found</p>'
    rowh = 22
    p = Plot(560, 24 + rowh * len(items) + 30, ml=96, mr=56, mt=10, mb=30)
    xmax = 2.0
    xt = [0, 0.5, 1.0, 1.5, 2.0]
    for t in xt:
        x = p.sx(t, 0, xmax)
        p.add(f'<line class="grid" x1="{x:.1f}" x2="{x:.1f}" y1="{p.mt}" y2="{p.mt + p.ih}"/>')
        p.add(f'<text class="tick" x="{x:.1f}" y="{p.mt + p.ih + 14}" text-anchor="middle">{t:g}</text>')
    p.add(f'<text class="axlabel" x="{p.ml + p.iw / 2}" y="{p.h - 4}" text-anchor="middle">maximum error (ULP)</text>')
    for i, (name, mx, mean, rms, n, bound) in enumerate(items):
        yc = p.mt + 8 + i * rowh
        x0, x1 = p.ml, p.sx(min(mx, xmax), 0, xmax)
        tip = f"{name}: max {mx:.4f} ULP, mean {mean:.4f}, RMS {rms:.4f}, n={n}" + \
              (f", bound {bound:g} ULP" if bound else "")
        p.add(f'<text class="lab" x="{p.ml - 8}" y="{yc + 4}" text-anchor="end">{E(name)}</text>')
        p.add(f'<path class="mA hov" data-tip="{E(tip)}" d="M{x0:.1f},{yc - 6} H{x1 - 4:.1f} '
              f'a4,4 0 0 1 4,4 v4 a4,4 0 0 1 -4,4 H{x0:.1f} Z"/>')
        p.add(f'<text class="val" x="{x1 + 5:.1f}" y="{yc + 4}">{mx:.3f}</text>')
        if bound:
            xb = p.sx(bound, 0, xmax)
            p.add(f'<line class="bound" x1="{xb:.1f}" x2="{xb:.1f}" y1="{yc - 8}" y2="{yc + 8}"/>')
    rows = [[E(n), f"{mx:.4f}", f"{mn:.4f}", f"{r:.4f}", f"{s:,}", "-" if b is None else f"{b:g}"]
            for n, mx, mn, r, s, b in items]
    return (p.svg("maximum ULP error per approximation") +
            '<p class="note">Bars: measured maximum error vs exact arithmetic. Tick: analytical bound where one '
            'exists. The RTL is bit-exact with the model these figures were measured on.</p>' +
            details("table", table(["primitive", "max ULP", "mean", "RMS", "samples", "bound"], rows)))


def panel_thermal():
    tr = cload(R / "workload" / "thermal_trajectory.csv")
    fin = cload(R / "workload" / "thermal_final.csv")
    summ = jload(R / "workload" / "summary.json") or {}
    if not tr or not fin:
        return '<p class="na">reports/workload not found -- run make workload</p>'
    p1 = summ.get("part1", {})
    flagged = set(p1.get("flagged_channels", []))
    nodes = [k for k in tr[0] if k.startswith("T")]
    t = [float(r["time_s"]) for r in tr]
    ys = {k: [float(r[k]) for r in tr] for k in nodes}
    lo = min(min(v) for v in ys.values())
    hi = max(max(v) for v in ys.values())
    yt = nice_ticks(lo, hi, 5)
    y0, y1 = yt[0], yt[-1]
    p = Plot(560, 260, ml=52, mr=60)
    axes(p, 0, t[-1], y0, y1, nice_ticks(0, t[-1], 6), yt, "simulated time (s)", "temperature (K)",
         xfmt=lambda v: f"{v:g}", yfmt=lambda v: f"{v:g}")
    hl = sorted(flagged)[0] if flagged else None
    for k in nodes:
        idx = int(k[1:])
        pts = " ".join(f"{p.sx(a, 0, t[-1]):.1f},{p.sy(b, y0, y1):.1f}" for a, b in zip(t, ys[k]))
        cls = "lA" if idx == hl else "lctx"
        p.add(f'<polyline class="{cls}" points="{pts}"/>')
        xe, ye = p.sx(t[-1], 0, t[-1]), p.sy(ys[k][-1], y0, y1)
        tip = f"node {idx}: T = {ys[k][-1]:.3f} K at t = {t[-1]:g} s"
        p.add(f'<circle class="{"dA" if idx == hl else "dctx"} hov" cx="{xe:.1f}" cy="{ye:.1f}" r="4" '
              f'data-tip="{E(tip)}"/>')
    if hl is not None:
        p.add(f'<text class="lab" x="{p.ml + p.iw + 8}" y="{p.sy(ys[f"T{hl}"][-1], y0, y1) + 4:.1f}">node {hl}</text>')
    # residual bars (model vs telemetry)
    res = [(int(r["node"]), float(r["residual"]), int(r["residual_quality"])) for r in fin]
    rmax = max(abs(v) for _, v, _ in res) or 1.0
    q = Plot(560, 170, ml=52, mr=16, mt=12, mb=34)
    lim = rmax * 1.15
    yt2 = nice_ticks(-lim, lim, 4)
    axes(q, -0.5, len(res) - 0.5, yt2[0], yt2[-1], [], yt2, "sensor channel", "residual (K)",
         yfmt=lambda v: f"{v:g}")
    bw = min(24, q.iw / len(res) * 0.6)
    for node, v, qual in res:
        xc = q.sx(node, -0.5, len(res) - 0.5)
        yb, yv = q.sy(0, yt2[0], yt2[-1]), q.sy(v, yt2[0], yt2[-1])
        bad = node in flagged
        cls = "mF" if bad else "mA"
        tip = f"channel {node}: residual {v:+.4f} K" + (" -- RESIDUAL fault recorded" if bad else " -- within tolerance")
        top, h = min(yb, yv), abs(yv - yb)
        p_ = (f'<rect class="{cls} hov" x="{xc - bw / 2:.1f}" y="{top:.1f}" width="{bw:.1f}" height="{max(h, 1):.1f}" '
              f'rx="2" data-tip="{E(tip)}"/>')
        q.add(p_)
        q.add(f'<text class="tick" x="{xc:.1f}" y="{q.mt + q.ih + 15}" text-anchor="middle">{node}</text>')
        if bad:
            q.add(f'<text class="lab" x="{xc:.1f}" y="{top - 4:.1f}" text-anchor="middle">fault</text>')
    q.add(f'<line class="axis" x1="{q.ml}" x2="{q.ml + q.iw}" y1="{q.sy(0, yt2[0], yt2[-1]):.1f}" '
          f'y2="{q.sy(0, yt2[0], yt2[-1]):.1f}"/>')
    cons = p1.get("conservation", {})
    diag = p1.get("diagnostics", {})
    facts = [("integrator", "RK4, explicit"), ("steps", diag.get("steps")), ("RTL cycles", f"{diag.get('cycles', 0):,}"),
             ("conservation residual", f"{cons.get('residual', float('nan')):.3e} J "
                                        f"(threshold {cons.get('threshold', float('nan')):.3g} J)"),
             ("faults recorded", " ".join(fault_chip(f) for f in str(diag.get("faults", "-")).split(",") if f and f != "-")
              or "none"),
             ("RTL vs reference", ok_label(p1.get("verification", {}).get("status") == "MATCH", "MATCH", "MISMATCH"))]
    rows = [[str(r["step"]), r["time_s"]] + [f"{float(r[k]):.3f}" for k in nodes] for r in tr]
    return (p.svg("node temperatures over time") +
            '<p class="note">Lumped 8-node thermal network propagated on the accelerator. Grey: all nodes; '
            f'blue: node {hl} whose sensor disagrees with the model.</p>' +
            q.svg("model minus telemetry residual per channel") +
            '<p class="note">Residual between the propagated state and injected telemetry; red marks the channel '
            'for which the residual engine recorded a fault.</p>' +
            table(["quantity", "value"], [[E(a), b if isinstance(b, str) and b.startswith("<") else E(str(b))]
                                          for a, b in facts]) +
            details("trajectory table", table(["step", "t (s)"] + nodes, rows)))


def panel_sweep():
    sw = cload(R / "workload" / "design_sweep.csv")
    ls = cload(R / "workload" / "local_search.csv")
    summ = (jload(R / "workload" / "summary.json") or {}).get("part2", {})
    if not sw:
        return '<p class="na">design sweep not found -- run make workload</p>'
    gs = sorted({float(r["Gs"]) for r in sw})
    pw = sorted({float(r["P"]) for r in sw})
    feas = [r for r in sw if r["feasible"] == "True"]
    jv = [float(r["J"]) for r in feas]
    lj0, lj1 = math.log10(min(jv)), math.log10(max(jv))
    cell = 34
    p = Plot(cell * len(gs) + 150, cell * len(pw) + 60, ml=60, mr=90, mt=10, mb=46)
    ramp = ["s0", "s1", "s2", "s3", "s4", "s5", "s6"]
    best = summ.get("best_index")
    for r in sw:
        i, j = gs.index(float(r["Gs"])), pw.index(float(r["P"]))
        x, y = p.ml + i * cell, p.mt + (len(pw) - 1 - j) * cell
        if r["feasible"] != "True":
            tip = f"Gs={float(r['Gs']):g} W/K, P={float(r['P']):g} W: infeasible (peak {float(r['T_peak']):.1f} K)"
            p.add(f'<rect class="infeas hov" x="{x + 1}" y="{y + 1}" width="{cell - 2}" height="{cell - 2}" rx="3" '
                  f'data-tip="{E(tip)}"/>')
            continue
        k = int(round((math.log10(float(r["J"])) - lj0) / max(lj1 - lj0, 1e-12) * (len(ramp) - 1)))
        tip = (f"Gs={float(r['Gs']):g} W/K, P={float(r['P']):g} W: J={float(r['J']):.4g}, "
               f"T_final={float(r['T_final']):.1f} K, margin={float(r['margin']):.1f} K")
        p.add(f'<rect class="{ramp[k]} hov" x="{x + 1}" y="{y + 1}" width="{cell - 2}" height="{cell - 2}" rx="3" '
              f'data-tip="{E(tip)}"/>')
        if best is not None and int(r["index"]) == best:
            p.add(f'<rect class="best" x="{x + 1}" y="{y + 1}" width="{cell - 2}" height="{cell - 2}" rx="3"/>')
    for i, g in enumerate(gs):
        p.add(f'<text class="tick" x="{p.ml + i * cell + cell / 2}" y="{p.mt + len(pw) * cell + 14}" '
              f'text-anchor="middle">{g:g}</text>')
    for j, v in enumerate(pw):
        p.add(f'<text class="tick" x="{p.ml - 6}" y="{p.mt + (len(pw) - 1 - j) * cell + cell / 2 + 4}" '
              f'text-anchor="end">{v:g}</text>')
    p.add(f'<text class="axlabel" x="{p.ml + len(gs) * cell / 2}" y="{p.h - 6}" text-anchor="middle">'
          f'conductance scale Gs (W/K)</text>')
    p.add(f'<text class="axlabel" transform="translate(14 {p.mt + len(pw) * cell / 2}) rotate(-90)" '
          f'text-anchor="middle">power P (W)</text>')
    # local search path (continuous coordinates mapped onto the grid)
    if ls:
        def gx(v):
            return p.ml + (v - gs[0]) / (gs[1] - gs[0]) * cell + cell / 2

        def gy(v):
            return p.mt + (len(pw) - 1 - (v - pw[0]) / (pw[1] - pw[0])) * cell + cell / 2
        pts = [(gx(float(r["Gs_center"])), gy(float(r["P_center"]))) for r in ls]
        p.add('<polyline class="lB" points="' + " ".join(f"{a:.1f},{b:.1f}" for a, b in pts) + '"/>')
        last = ls[-1]
        tip = (f"local search after {last['iter']} iterations: Gs={float(last['Gs_center']):.4f}, "
               f"P={float(last['P_center']):.3f}, J={float(last['J_center']):.4g}")
        p.add(f'<circle class="dB hov" cx="{pts[-1][0]:.1f}" cy="{pts[-1][1]:.1f}" r="4.5" data-tip="{E(tip)}"/>')
    # legend
    lx = p.ml + len(gs) * cell + 14
    p.add(f'<text class="lab" x="{lx}" y="{p.mt + 10}">J (log)</text>')
    for n, c in enumerate(ramp):
        p.add(f'<rect class="{c}" x="{lx}" y="{p.mt + 18 + n * 14}" width="14" height="12" rx="2"/>')
    p.add(f'<text class="tick" x="{lx + 18}" y="{p.mt + 28}">low</text>')
    p.add(f'<text class="tick" x="{lx + 18}" y="{p.mt + 18 + 6 * 14 + 10}">high</text>')
    yb = p.mt + 18 + 7 * 14 + 10
    p.add(f'<rect class="infeas" x="{lx}" y="{yb}" width="14" height="12" rx="2"/>'
          f'<text class="tick" x="{lx + 18}" y="{yb + 10}">infeasible</text>')
    p.add(f'<rect class="best" x="{lx}" y="{yb + 18}" width="14" height="12" rx="2"/>'
          f'<text class="tick" x="{lx + 18}" y="{yb + 28}">grid best</text>')
    p.add(f'<line class="lB" x1="{lx}" x2="{lx + 14}" y1="{yb + 42}" y2="{yb + 42}"/>'
          f'<text class="tick" x="{lx + 18}" y="{yb + 46}">search</text>')
    v = summ.get("verification", {})
    facts = [("candidates / feasible", f"{summ.get('candidates')} / {summ.get('feasible')}"),
             ("hardware arg-min (host check)", f"{summ.get('best_index')} ({summ.get('host_check_index')})"),
             ("grid best", f"Gs = {summ.get('best', {}).get('Gs')} W/K, P = {summ.get('best', {}).get('P')} W, "
                           f"J = {summ.get('best', {}).get('J', float('nan')):.4g}"),
             ("after compass search", f"Gs = {summ.get('local_search_final', {}).get('Gs_center', float('nan')):.4f}, "
                                      f"P = {summ.get('local_search_final', {}).get('P_center', float('nan')):.3f}, "
                                      f"J = {summ.get('local_search_final', {}).get('J_center', float('nan')):.4g}"),
             ("RTL vs reference", ok_label(v.get("status") == "MATCH", "MATCH", "MISMATCH"))]
    rows = [[r["index"], r["Gs"], r["P"], f"{float(r['J']):.5g}", f"{float(r['T_final']):.2f}",
             f"{float(r['margin']):.2f}", r["feasible"]] for r in sw]
    return (p.svg("design sweep objective heat map") +
            '<p class="note">64 candidates evaluated in parallel lanes (SWEEP / OBJECTIVE / CONSTRAINT / SEARCH '
            'GRID), then refined by the hardware compass search (SEARCH LOCAL).</p>' +
            table(["quantity", "value"], [[E(a), b if b.startswith("<") else E(b)] for a, b in facts]) +
            details("sweep table", table(["#", "Gs", "P", "J", "T_final", "margin", "feasible"], rows)))


def panel_benchmark():
    rows = cload(R / "benchmark" / "benchmark.csv")
    if not rows:
        return '<p class="na">reports/benchmark not found -- run make benchmark</p>'
    # model error dot plot
    p = Plot(560, 250, ml=150, mr=20, mt=12, mb=36)
    kernels = list(dict.fromkeys(r["kernel"] for r in rows))
    errs = [float(r["model_error_pct"]) for r in rows]
    lim = max(10.0, math.ceil(max(abs(e) for e in errs) / 5) * 5)
    xt = nice_ticks(-lim, lim, 6)
    for t in xt:
        x = p.sx(t, -lim, lim)
        p.add(f'<line class="grid" x1="{x:.1f}" x2="{x:.1f}" y1="{p.mt}" y2="{p.mt + p.ih}"/>')
        p.add(f'<text class="tick" x="{x:.1f}" y="{p.mt + p.ih + 14}" text-anchor="middle">{t:+g}%</text>')
    x0 = p.sx(0, -lim, lim)
    p.add(f'<line class="axis" x1="{x0:.1f}" x2="{x0:.1f}" y1="{p.mt}" y2="{p.mt + p.ih}"/>')
    p.add(f'<text class="axlabel" x="{p.ml + p.iw / 2}" y="{p.h - 4}" text-anchor="middle">'
          f'analytical model error vs RTL cycles</text>')
    band = p.ih / len(kernels)
    for i, k in enumerate(kernels):
        yc = p.mt + band * (i + 0.5)
        p.add(f'<text class="lab" x="{p.ml - 8}" y="{yc + 4:.1f}" text-anchor="end">{E(k)}</text>')
        ks = [r for r in rows if r["kernel"] == k]
        for n, r in enumerate(ks):
            held = r.get("model_set") == "held-out"
            yy = yc + (n - (len(ks) - 1) / 2) * 6
            tip = (f"{r['config']} {k}: RTL {int(r['cycles']):,} cycles, model {int(r['predicted_cycles']):,} "
                   f"({float(r['model_error_pct']):+.1f}%), {'held-out' if held else 'calibration'}")
            p.add(f'<circle class="{"dB" if held else "dA"} hov" cx="{p.sx(float(r["model_error_pct"]), -lim, lim):.1f}" '
                  f'cy="{yy:.1f}" r="4" data-tip="{E(tip)}"/>')
    # throughput vs lanes
    q = Plot(560, 230, ml=52, mr=110, mt=12, mb=36)
    fp32 = [r for r in rows if r["precision"] == "fp32"]
    lanes = sorted({int(r["lanes"]) for r in fp32})
    sel = ["fma_stream", "surrogate_design_sweep"]
    ymax = max(float(r["flops_per_cycle"]) for r in fp32 if r["kernel"] in sel) * 1.1
    yt = nice_ticks(0, ymax, 5)
    axes(q, lanes[0] - 2, lanes[-1] + 2, 0, yt[-1], lanes, yt, "vector lanes (FP32)", "FLOP / cycle",
         xfmt=lambda v: str(v), yfmt=lambda v: f"{v:g}")
    for cls, dcls, k in (("lA", "dA", sel[0]), ("lB", "dB", sel[1])):
        pts = []
        for L in lanes:
            r = next(x for x in fp32 if x["kernel"] == k and int(x["lanes"]) == L)
            pts.append((q.sx(L, lanes[0] - 2, lanes[-1] + 2), q.sy(float(r["flops_per_cycle"]), 0, yt[-1]),
                        r, L))
        q.add(f'<polyline class="{cls}" points="' + " ".join(f"{a:.1f},{b:.1f}" for a, b, _, _ in pts) + '"/>')
        for a, b, r, L in pts:
            tip = (f"{k}, {L} lanes: {float(r['flops_per_cycle']):.2f} FLOP/cycle measured; "
                   f"~{float(r['gflops_est_250MHz']):.2f} GFLOP/s at an assumed 250 MHz (estimate)")
            q.add(f'<circle class="{dcls} hov" cx="{a:.1f}" cy="{b:.1f}" r="4" data-tip="{E(tip)}"/>')
        q.add(f'<text class="lab" x="{pts[-1][0] + 8:.1f}" y="{pts[-1][1] + 4:.1f}">{E(k.replace("_", " "))}</text>')
    legend = ('<div class="legend"><span><i class="swA"></i>calibration configs</span>'
              '<span><i class="swB"></i>held-out config (FP32, 32 lanes)</span></div>')
    legend2 = ('<div class="legend"><span><i class="swA"></i>fma_stream</span>'
               '<span><i class="swB"></i>surrogate_design_sweep</span></div>')
    trows = [[r["config"], E(r["kernel"]), f"{int(r['cycles']):,}", f"{int(r['predicted_cycles']):,}",
              f"{float(r['model_error_pct']):+.1f}%", r["flops_per_cycle"], r["vector_utilisation"],
              r["gflops_est_250MHz"], ok_label(r["verified"] == "True", "MATCH", "MISMATCH")] for r in rows]
    return (legend + p.svg("model error per benchmark run") +
            '<p class="note">Cycle counts are measured on the RTL (hardware counters); the model predicts them '
            'from the executed instruction trace.</p>' + legend2 + q.svg("throughput versus lanes") +
            '<p class="note">FLOP/cycle is measured. GFLOP/s in the table assumes a 250 MHz clock that has '
            '<b>not</b> been closed in timing: an estimate, not a silicon figure.</p>' +
            details("benchmark table", table(["config", "kernel", "RTL cycles", "model", "error", "FLOP/cyc",
                                              "util.", "GFLOP/s est.", "result"], trows)))


FAULT_NAMES = ["WATCHDOG", "TIMEOUT", "ILLEGAL", "PRECISION", "NAN", "OVERFLOW", "UNDERFLOW", "DIVZERO",
               "RANGE", "PARITY", "MEMADDR", "TL_SEQ", "TL_CRC", "TL_TS", "TL_OVF", "CONSERVATION",
               "RESIDUAL", "PIPELINE", "STEP", "TL_MALFORMED", "UNINIT", "CONSTRAINT", "SEARCH", "HOST"]


def panel_faults():
    rows = []
    for suite in ("faults", "telemetry"):
        d = jload(R / "system" / f"fp32_l8_{suite}.json") or {}
        for name, r in d.items():
            g = r.get("regs", {})
            st = g.get("fault_status", 0)
            faults = [n for i, n in enumerate(FAULT_NAMES) if st >> i & 1]
            ff = g.get("fault_first", 0)
            first = (f"{FAULT_NAMES[ff & 31]} @ pc {g.get('fault_pc', 0)}" if ff >> 31 & 1 else "-")
            halted = bool(g.get("status", 0) & 4)
            tl = ""
            if suite == "telemetry":
                tl = (f"accepted {g.get('tl_accepted', 0)}, dropped {g.get('tl_dropped', 0)}, CRC {g.get('tl_crc', 0)}, "
                      f"seq {g.get('tl_seq', 0)}, ts {g.get('tl_ts', 0)}, range {g.get('tl_range', 0)}, "
                      f"malformed {g.get('tl_malformed', 0)}")
            rows.append([E(name), " ".join(fault_chip(f) for f in faults) or '<span class="muted">none</span>',
                         E(first), "halted" if halted else '<span class="muted">running to completion</span>',
                         E(tl) or '<span class="muted">-</span>', ok_label(r.get("match"), "MATCH", "MISMATCH")])
    if not rows:
        return '<p class="na">fault scenarios not found -- run make system</p>'
    return (table(["scenario (FP32, 8 lanes)", "faults recorded by the hardware", "first fault", "core",
                   "telemetry counters", "vs reference"], rows, "wide") +
            '<p class="note">Red chips are faults the fault manager actually recorded during each run (injected or '
            'provoked on purpose). Each record -- status bits, first fault, PC, halt, counters -- matched the '
            'reference model bit for bit.</p>')


def panel_resources():
    rows = []
    for p in sorted((R / "synth").glob("*.json")):
        d = jload(p) or {}
        chk = d.get("check", {})
        tot = d.get("logic_total") or {}
        failed = d.get("blocks_failed", [])
        if d.get("target") == "xilinx":
            res = (f"LUT {tot.get('LUT', 0):,} &middot; FF {tot.get('FF', 0):,} &middot; DSP {tot.get('DSP', 0):,} "
                   f"&middot; BRAM36 {d.get('bram36_estimate', '-')}") if tot else "not synthesized"
        else:
            res = (f"{int(tot.get('cell_count', 0)):,} cells &middot; {tot.get('transistors', 0):.3g} transistors "
                   f"&middot; SRAM {d.get('sram_kbit', '-')} Kbit") if tot else "not synthesized"
        if d.get("method"):
            sc = d.get("scaling_check") or {}
            res += (f'<br><span class="muted">lane-scaled: {E(d["method"])}' +
                    (" &middot; check (full/scaled): " + ", ".join(f"{E(k)} {v['ratio_full_over_scaled']:.2f}"
                                                              for k, v in sc.items()) if sc else "") + "</span>")
        if failed:
            res += f' <span class="muted">(excluded, timed out: {E(", ".join(failed))})</span>'
        rows.append([E(p.stem), E(d.get("description", "")),
                     ('<span class="st na">not run</span>' if not chk else
                      ok_label(chk.get("elaborates"), "elaborates", "fails") + f' <span class="muted">'
                      f'{chk.get("latches", "-")} latches</span>'), res, f"{d.get('clock_mhz_assumed', '-')} MHz (assumed)"])
    if not rows:
        return '<p class="na">reports/synth not found -- run make synth</p>'
    return (table(["config", "description", "Yosys check", "logic estimate", "clock"], rows, "wide") +
            '<p class="note">Yosys synthesis of each block at the configuration\'s parameters, summed; memories '
            'counted in bits. Estimates before place-and-route; no timing closure is claimed.</p>')


CSS = """
:root{--bg:#F7F7F5;--panel:#FFFFFF;--ink:#23262B;--muted:#5D6670;--line:#E2E4E6;--axis:#9AA3AD;--navy:#14284B;
--A:#2E5A94;--B:#A86A12;--ctx:#B4BBC3;--fault:#B3261E;--faultbg:#FBEAE8;--okc:#14284B;
--s0:#E4EAF2;--s1:#C9D6E7;--s2:#A9BFDB;--s3:#86A3CA;--s4:#5F84B5;--s5:#3B6399;--s6:#1F3F6B;--hatch:#C9CED4}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#1C1E22;--panel:#23262B;--ink:#E7E8EA;
--muted:#9AA3AD;--line:#33373D;--axis:#5D6670;--navy:#AFC3E3;--A:#5E8FD0;--B:#C98F2E;--ctx:#4A5058;--fault:#E5534B;
--faultbg:#3A2323;--okc:#AFC3E3;--s0:#26303D;--s1:#2C3D55;--s2:#33496A;--s3:#3E5D88;--s4:#4F76AA;--s5:#6E95C9;
--s6:#A3BFE4;--hatch:#3A3F46}}
:root[data-theme="dark"]{--bg:#1C1E22;--panel:#23262B;--ink:#E7E8EA;--muted:#9AA3AD;--line:#33373D;--axis:#5D6670;
--navy:#AFC3E3;--A:#5E8FD0;--B:#C98F2E;--ctx:#4A5058;--fault:#E5534B;--faultbg:#3A2323;--okc:#AFC3E3;--s0:#26303D;
--s1:#2C3D55;--s2:#33496A;--s3:#3E5D88;--s4:#4F76AA;--s5:#6E95C9;--s6:#A3BFE4;--hatch:#3A3F46}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);
font:14px/1.45 "IBM Plex Sans","Segoe UI",Helvetica,Arial,sans-serif}
header{background:var(--navy);color:#F2F4F7;padding:18px 24px}
:root[data-theme="dark"] header{color:#14284B}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) header{color:#14284B}}
header h1{margin:0;font-size:20px;letter-spacing:.08em;font-weight:600}
header p{margin:4px 0 0;font-size:12.5px;opacity:.85}
main{max-width:1240px;margin:0 auto;padding:16px;display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,560px),1fr));gap:16px}
section{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:14px 16px;min-width:0}
section.full{grid-column:1/-1}
h2{margin:0 0 10px;font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);font-weight:600}
svg{width:100%;height:auto;display:block;margin:4px 0}
.grid{stroke:var(--line);stroke-width:1}.axis{stroke:var(--axis);stroke-width:1}
.tick{fill:var(--muted);font-size:10.5px}.axlabel{fill:var(--muted);font-size:11px}.lab{fill:var(--ink);font-size:11px}
.val{fill:var(--ink);font-size:10.5px}
.mA{fill:var(--A)}.mF{fill:var(--fault)}.bound{stroke:var(--ink);stroke-width:2}
.lA,.lB,.lctx{fill:none;stroke-width:2;stroke-linejoin:round;stroke-linecap:round}
.lA{stroke:var(--A)}.lB{stroke:var(--B)}.lctx{stroke:var(--ctx);stroke-width:1.5}
.dA,.dB,.dctx{stroke:var(--panel);stroke-width:2}.dA{fill:var(--A)}.dB{fill:var(--B)}.dctx{fill:var(--ctx)}
.s0{fill:var(--s0)}.s1{fill:var(--s1)}.s2{fill:var(--s2)}.s3{fill:var(--s3)}.s4{fill:var(--s4)}.s5{fill:var(--s5)}.s6{fill:var(--s6)}
.infeas{fill:url(#hatch)}.best{fill:none;stroke:var(--B);stroke-width:2.5}
.hov{cursor:crosshair}.hov:hover{opacity:.8}
.tw{overflow-x:auto;max-width:100%}table{border-collapse:collapse;width:100%;font-size:12.5px;margin:6px 0}
th{text-align:left;color:var(--muted);font-weight:600;border-bottom:1px solid var(--line);padding:4px 6px}
td{border-bottom:1px solid var(--line);padding:4px 6px;font-variant-numeric:tabular-nums;vertical-align:top}
.wide td:last-child{color:var(--muted)}
.st{font-weight:600;white-space:nowrap}.st.ok{color:var(--okc)}.st.bad{color:var(--fault)}.st.na,.muted,.na{color:var(--muted)}
.chip{display:inline-block;padding:0 6px;margin:1px 2px;border-radius:3px;font-size:11px;font-weight:600;
letter-spacing:.03em}.chip.fault{color:var(--fault);background:var(--faultbg);border:1px solid var(--fault)}
.note{color:var(--muted);font-size:12px;margin:2px 0 8px}
details summary{cursor:pointer;color:var(--muted);font-size:12px}
.legend{display:flex;gap:16px;font-size:12px;color:var(--ink);margin:2px 0}
.legend i{display:inline-block;width:10px;height:10px;border-radius:5px;margin-right:6px;vertical-align:-1px}
.swA{background:var(--A)}.swB{background:var(--B)}
#tip{position:fixed;pointer-events:none;background:var(--panel);color:var(--ink);border:1px solid var(--axis);
border-radius:4px;padding:5px 8px;font-size:12px;max-width:340px;display:none;z-index:9;box-shadow:0 2px 6px rgba(0,0,0,.15)}
footer{max-width:1240px;margin:0 auto;padding:8px 16px 24px;color:var(--muted);font-size:11.5px}
button.theme{float:right;background:transparent;border:1px solid rgba(255,255,255,.5);color:inherit;border-radius:4px;
padding:3px 8px;font-size:12px;cursor:pointer}
"""

JS = """
const tip=document.getElementById('tip');
document.querySelectorAll('[data-tip]').forEach(el=>{
 el.addEventListener('mousemove',e=>{tip.textContent=el.getAttribute('data-tip');tip.style.display='block';
  const x=Math.min(e.clientX+14,window.innerWidth-tip.offsetWidth-8);tip.style.left=x+'px';tip.style.top=(e.clientY+14)+'px';});
 el.addEventListener('mouseleave',()=>{tip.style.display='none';});});
document.getElementById('theme').addEventListener('click',()=>{const r=document.documentElement;
 const dark=r.getAttribute('data-theme')==='dark'||(!r.getAttribute('data-theme')&&matchMedia('(prefers-color-scheme: dark)').matches);
 r.setAttribute('data-theme',dark?'light':'dark');});
"""


def main():
    summ = jload(R / "workload" / "summary.json") or {}
    sections = [
        ("full", "Verification status", panel_verification()),
        ("", "Thermal digital twin &mdash; propagated state and sensor residuals", panel_thermal()),
        ("", "Design-space exploration &mdash; surrogate sweep and search", panel_sweep()),
        ("", "Numerical accuracy of hardware approximations", panel_accuracy()),
        ("", "Performance &mdash; measured cycles and model validation", panel_benchmark()),
        ("full", "Fault and telemetry-anomaly handling", panel_faults()),
        ("full", "Resource estimates (pre-implementation)", panel_resources()),
    ]
    body = "".join(f'<section class="{c}"><h2>{t}</h2>{h}</section>' for c, t, h in sections)
    hatch = ('<svg width="0" height="0" style="position:absolute"><defs><pattern id="hatch" width="6" height="6" '
             'patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="6" height="6" '
             'fill="var(--panel)"/><line x1="0" y1="0" x2="0" y2="6" stroke="var(--hatch)" stroke-width="2.5"/>'
             '</pattern></defs></svg>')
    doc = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Silica Flux Engineering Display</title>
<style>{CSS}</style></head><body>{hatch}
<header><button class="theme" id="theme" type="button">light / dark</button><h1>SILICA FLUX</h1>
<p>Numerical accelerator for engineering simulation &mdash; results from the RTL simulators and analysis scripts
in reports/. Analysis tool, not a control system.</p></header>
<main>{body}</main>
<footer>Generated by python/analysis/dashboard.py from reports/*. Workload: {E(str(summ.get('part1', {}).get('diagnostics', {}).get('backend', '-')))} backend.
Hover any mark for its value; every chart has a table view.</footer>
<div id="tip" role="status"></div><script>{JS}</script></body></html>"""
    out = R / "dashboard.html"
    out.write_text(doc)
    print(f"dashboard written: {out.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
