#!/usr/bin/env python3
"""
Silica Flux benchmark: measured RTL performance vs the analytical model.

    python3 python/analysis/benchmark.py [--configs fp32_l8,fp32_l16,fp32_l32,fp64_l8]

For each configuration and kernel the program runs on
  * the instruction-accurate reference model (result check + executed trace),
  * the compiled RTL (cycle counts and hardware performance counters),
  * the analytical model (python/analysis/perf_model.py, predicted cycles).
Derived metrics: FLOP/cycle, lane-ops/cycle, vector-unit utilisation, memory
bandwidth (bytes/cycle), functional-unit busy fractions and GFLOP/s at the
clock ASSUMED for each synthesis target (an estimate -- clocks are not
signed-off timing results).
Outputs: reports/benchmark/benchmark.json and benchmark.csv (for r/benchmark.R)
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))

from golden_model import ieee  # noqa: E402
from golden_model.isa import MEM, FU  # noqa: E402
from generators.assembler import Program  # noqa: E402
from reference_model.scenario import Scenario, run_reference, compare_results  # noqa: E402
from silica_flux import workloads  # noqa: E402
from silica_flux.rtl_backend import VerilatorBackend  # noqa: E402
from analysis.perf_model import Micro, predict, peak  # noqa: E402

CONFIGS = {"fp32_l8": (8, 0, 4), "fp32_l16": (16, 0, 5), "fp32_l32": (32, 0, 4), "fp64_l8": (8, 1, 4)}
ASSUMED_CLOCK_MHZ = {"small FPGA (100 MHz)": 100, "large FPGA (250 MHz)": 250, "ASIC (1 GHz)": 1000}
FU_NAMES = {v: k for k, v in FU.items()}


def _row(fmt, vals, L):
    return ([fmt.from_float(v) for v in (list(vals) + [0.0] * L)[:L]], None)


def kernel_fma_stream(fmt, L, n=64):
    """independent FMAs on 8 accumulators: throughput bound (1 VALU op / cycle)"""
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    p = Program(prec)
    for r in range(4):
        p.vload(1 + r, "STATE", 0, r)
        p.vload(5 + r, "STATE", 0, (r + 1) % 4)
    for k in range(8):
        p.vmov(12 + k, 1 + (k % 4))
    p.seta(1, n // 8 - 1)
    p.label("l")
    for k in range(8):
        p.vfma(12 + k, 1 + (k % 4), 5 + (k % 4), 12 + k)
    p.bnz(1, "l")
    for k in range(8):
        p.vstore(12 + k, "RESULT", 0, k)
    p.halt()
    init = {MEM["STATE"]: {r: _row(fmt, [0.5 + 0.01 * (r + l) for l in range(L)], L) for r in range(4)}}
    return Scenario(name="fma_stream", words=p.assemble(), mem_init=init, config={"fault_halt": 0},
                    compare={MEM["RESULT"]: 8})


def kernel_fma_chain(fmt, L, n=32):
    """one dependent FMA chain: latency bound"""
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    p = Program(prec)
    p.vload(1, "STATE", 0, 0).vload(2, "STATE", 0, 1).vmov(3, 1)
    p.seta(1, n - 1)
    p.label("l")
    p.vfma(3, 3, 2, 1)
    p.bnz(1, "l")
    p.vstore(3, "RESULT", 0, 0).halt()
    init = {MEM["STATE"]: {0: _row(fmt, [0.1] * L, L), 1: _row(fmt, [0.5] * L, L)}}
    return Scenario(name="fma_chain", words=p.assemble(), mem_init=init, config={"fault_halt": 0},
                    compare={MEM["RESULT"]: 1})


def kernel_mixed(fmt, L, n=16):
    """reductions + polynomial + special functions + loads/stores"""
    prec = "FP64" if fmt is ieee.FP64 else "FP32"
    p = Program(prec)
    p.vload(1, "STATE", 0, 0).vload(2, "COEFF", 0, 0)
    p.seta(1, n - 1).seta(3, 0)
    p.label("l")
    p.vpoly(3, 1, 2, 5).vexp(4, 1).vreduce(5, 3, "SUM").vreduce(6, 4, "MAX").vfma(7, 3, 4, 5)
    p.vstore(7, "RESULT", 3, 0).adda(3, 1)
    p.bnz(1, "l")
    p.halt()
    init = {MEM["STATE"]: {0: _row(fmt, [0.05 * l for l in range(L)], L)},
            MEM["COEFF"]: {0: _row(fmt, [1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125], L)}}
    return Scenario(name="mixed_kernels", words=p.assemble(), mem_init=init, config={"fault_halt": 0},
                    compare={MEM["RESULT"]: n})


def kernels(fmt, L):
    th = workloads.thermal_network_scenario(fmt, L, steps=12)
    th.name = "rk4_thermal_network"
    sw = workloads.surrogate_sweep_scenario(fmt, L)
    return [kernel_fma_stream(fmt, L), kernel_fma_chain(fmt, L), kernel_mixed(fmt, L), th, sw]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="fp32_l8,fp32_l16,fp32_l32,fp64_l8")
    a = ap.parse_args()
    rows, out = [], {}
    for cfg in a.configs.split(","):
        L, fp, depth = CONFIGS[cfg]
        fmt = ieee.FP64 if fp else ieee.FP32
        be = VerilatorBackend(L, fp, depth)
        m = Micro(lanes=L, fp_mode=fp, depth=depth)
        pk = peak(m)
        for sc in kernels(fmt, L):
            sim = run_reference(sc, L, fp)
            res = be.run(sc)
            errs = compare_results(sim, res, sc, L)
            r = res["regs"]
            pred = predict(sim.trace, sc.words, m)
            cyc = max(r["cycles"], 1)
            busy = {FU_NAMES[f]: round(r.get(f"fu_busy_{f}", 0) / cyc, 4) for f in range(1, 15)}
            words_moved = (r["loads"] + r["stores"]) * L * (8 if fp else 4)
            rec = {
                "config": cfg, "lanes": L, "precision": fmt.name, "kernel": sc.name,
                "verified": not errs, "cycles": r["cycles"], "predicted_cycles": pred["cycles"],
                "model_error_pct": round(100.0 * (pred["cycles"] - r["cycles"]) / cyc, 2),
                # perf_model.TIMING was calibrated on fp32_l8/fp32_l16/fp64_l8; other configs are held out
                "model_set": "calibration" if cfg in ("fp32_l8", "fp32_l16", "fp64_l8") else "held-out",
                "retired": r["retired"], "ipc": round(r["retired"] / cyc, 4),
                "flops": pred["flops"], "flops_per_cycle": round(pred["flops"] / cyc, 3),
                "lane_ops_per_cycle": round(r["lane_ops"] / cyc, 3),
                "vector_utilisation": round(r["lane_ops"] / cyc / pk["lane_ops_per_cycle"], 4),
                "valu_busy": busy.get("VALU", 0), "memory_bytes_per_cycle": round(words_moved / cyc, 3),
                "memory_utilisation": round((r["loads"] + r["stores"]) / cyc, 4),
                "stall_fraction": round(r["stalls"] / cyc, 4), "state_updates": r["state_updates"],
                "fu_busy": busy,
            }
            for label, mhz in ASSUMED_CLOCK_MHZ.items():
                rec[f"gflops_est_{mhz}MHz"] = round(rec["flops_per_cycle"] * mhz / 1000.0, 3)
            rows.append(rec)
            out.setdefault(cfg, {})[sc.name] = rec
            print(f"[bench] {cfg:<9} {sc.name:<22} cycles={r['cycles']:<7} model={pred['cycles']:<7} "
                  f"({rec['model_error_pct']:+.1f}%)  flop/cyc={rec['flops_per_cycle']:<7} "
                  f"util={rec['vector_utilisation']:.3f}  {'MATCH' if not errs else 'MISMATCH'}", flush=True)
        out[cfg]["_peak"] = pk
    d = ROOT / "reports" / "benchmark"
    d.mkdir(parents=True, exist_ok=True)
    (d / "benchmark.json").write_text(json.dumps(out, indent=2))
    keys = [k for k in rows[0] if k != "fu_busy"]
    with open(d / "benchmark.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in keys})
    with open(d / "fu_utilisation.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["config", "kernel", "unit", "busy_fraction"])
        for r in rows:
            for u, v in r["fu_busy"].items():
                w.writerow([r["config"], r["kernel"], u, v])
    print("BENCHMARK:", "PASS" if all(r["verified"] for r in rows) else "FAIL (result mismatch)")


if __name__ == "__main__":
    main()
