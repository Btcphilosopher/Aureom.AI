"""
Silica Flux golden model -- per-element semantics of the vector ALU (VALU).

One function, ``valu_element``, defines the result of every VALU opcode for one
lane in every precision.  It is the single source of truth used by:
  * python/cocotb/test_vector_alu.py   (RTL lane-by-lane comparison)
  * python/reference_model/isa_sim.py  (instruction-accurate core model)

Precisions:  FP32 / FP64 (native FP of the build), SFIX / UFIX (fixed point,
F fractional bits given by imm[5:0]), INT (signed integer, F = 0).
Fixed-point and integer arithmetic saturates and raises OF ("never wrap
silently"); multiplications round per the instruction rounding mode.
"""
from __future__ import annotations

from golden_model import ieee
from golden_model.ieee import FPFormat, NV, OF, NX, RNE, round_int_div_pow2

PREC_FP32, PREC_FP64, PREC_SFIX, PREC_UFIX, PREC_INT = range(5)
PREC_NAMES = ["FP32", "FP64", "SFIX", "UFIX", "INT"]

# opcodes (must match rtl/core/flux_pkg.sv)
OP = dict(VADD=0x10, VSUB=0x11, VMUL=0x12, VFMA=0x13, VFMS=0x14, VFNMA=0x15, VFNMS=0x16, VSQR=0x17,
          VMIN=0x18, VMAX=0x19, VABS=0x1A, VNEG=0x1B, VCMP=0x1C, VSEL=0x1D, VMOV=0x1E, VCLASS=0x1F,
          VCVT=0x20, VBCAST=0x21, VLANEID=0x22, VMSET=0x23, VSLIDE=0x24)
CMP_EQ, CMP_LT, CMP_LE = 0, 1, 2

FMA_OPS = {OP["VADD"]: ieee.FADD, OP["VSUB"]: ieee.FSUB, OP["VMUL"]: ieee.FMUL, OP["VFMA"]: ieee.FMADD,
           OP["VFMS"]: ieee.FMSUB, OP["VFNMA"]: ieee.FNMSUB, OP["VFNMS"]: ieee.FNMADD, OP["VSQR"]: ieee.FMUL}


def is_fp(prec: int) -> bool:
    return prec in (PREC_FP32, PREC_FP64)


def fix_limits(width: int, prec: int):
    if prec == PREC_UFIX:
        return 0, (1 << width) - 1
    return -(1 << (width - 1)), (1 << (width - 1)) - 1


def to_signed(v: int, width: int) -> int:
    v &= (1 << width) - 1
    return v - (1 << width) if v >> (width - 1) else v


def fix_val(v: int, width: int, prec: int) -> int:
    return v & ((1 << width) - 1) if prec == PREC_UFIX else to_signed(v, width)


def saturate(v: int, width: int, prec: int):
    lo, hi = fix_limits(width, prec)
    if v > hi:
        return hi & ((1 << width) - 1), OF
    if v < lo:
        return lo & ((1 << width) - 1), OF
    return v & ((1 << width) - 1), 0


def fix_one(width: int, prec: int, frac: int) -> int:
    _, hi = fix_limits(width, prec)
    v = 1 << frac
    return (v if v <= hi else hi) & ((1 << width) - 1)


def valu_element(fmt: FPFormat, opcode: int, prec: int, func: int, rm: int, imm: int,
                 a: int, b: int, c: int, vm_bit: int, lane: int):
    """Returns (result_bits, fflags, mask_bit or None).

    mask_bit is the new VM bit for VCMP / VMSET, None otherwise."""
    W = fmt.width
    mask = (1 << W) - 1
    frac = imm & 0x3F
    # ----------------------------------------------------------------- moves
    if opcode in (OP["VMOV"], OP["VBCAST"], OP["VSLIDE"]):
        return a, 0, None
    if opcode == OP["VSEL"]:
        return (a if vm_bit else b), 0, None
    if opcode == OP["VLANEID"]:
        if is_fp(prec):
            return ieee.fix_to_fp(fmt, lane, W, 0, True, RNE)[0], 0, None
        return (lane << frac) & mask if prec != PREC_INT else lane, 0, None
    if opcode == OP["VMSET"]:
        if func == 1:   # NZ
            nz = (a & (mask >> 1)) != 0 if is_fp(prec) else a != 0
            return 0, 0, int(nz)
        if func == 2:   # NOT
            return 0, 0, int(not vm_bit)
        if func == 3:   # IMM
            return 0, 0, (imm >> lane) & 1
        return 0, 0, 1
    # ----------------------------------------------------------------- floating point
    if is_fp(prec):
        if opcode in FMA_OPS:
            bb = a if opcode == OP["VSQR"] else b
            cc = b if opcode in (OP["VADD"], OP["VSUB"]) else c
            return (*ieee.fma_op(fmt, FMA_OPS[opcode], a, bb, cc, rm), None)
        if opcode == OP["VMIN"]:
            return (*ieee.fmin(fmt, a, b), None)
        if opcode == OP["VMAX"]:
            return (*ieee.fmax(fmt, a, b), None)
        if opcode == OP["VABS"]:
            return a & (mask >> 1), 0, None
        if opcode == OP["VNEG"]:
            return a ^ (1 << (W - 1)), 0, None
        if opcode == OP["VCLASS"]:
            return ieee.fclass(fmt, a), 0, None
        if opcode == OP["VCMP"]:
            fn = {CMP_EQ: ieee.feq, CMP_LT: ieee.flt, CMP_LE: ieee.fle}.get(func, ieee.feq)
            r, fl = fn(fmt, a, b)
            return (fmt.one() if r else 0), fl, int(r)
        if opcode == OP["VCVT"]:
            # FP <- fixed / integer source (func = source precision)
            src = func & 7
            if src in (PREC_SFIX, PREC_UFIX, PREC_INT):
                fs = 0 if src == PREC_INT else (imm >> 6) & 0x3F
                return (*ieee.fix_to_fp(fmt, a, W, fs, src != PREC_UFIX, rm), None)
            return a, 0, None
        raise ValueError(f"opcode {opcode:#x} not a VALU FP op")
    # ----------------------------------------------------------------- fixed / integer
    if prec == PREC_INT:
        frac = 0
    if opcode == OP["VCVT"]:
        src = func & 7
        if is_fp(src):
            return (*ieee.fp_to_fix(fmt, a, rm, W, frac, prec != PREC_UFIX), None)
        raise ValueError("fixed<-fixed conversion is not supported")
    av, bv, cv = fix_val(a, W, prec), fix_val(b, W, prec), fix_val(c, W, prec)
    if opcode == OP["VADD"]:
        return (*saturate(av + bv, W, prec), None)
    if opcode == OP["VSUB"]:
        return (*saturate(av - bv, W, prec), None)
    if opcode in (OP["VMUL"], OP["VSQR"], OP["VFMA"]):
        bb = av if opcode == OP["VSQR"] else bv
        q, inexact = round_int_div_pow2(av * bb, frac, rm)
        fl = NX if inexact else 0
        if opcode == OP["VFMA"]:
            q += cv
        r, f2 = saturate(q, W, prec)
        return r, fl | f2, None
    if opcode == OP["VMIN"]:
        return (av if av <= bv else bv) & mask, 0, None
    if opcode == OP["VMAX"]:
        return (av if av >= bv else bv) & mask, 0, None
    if opcode == OP["VABS"]:
        return (*saturate(abs(av), W, prec), None)
    if opcode == OP["VNEG"]:
        return (*saturate(-av, W, prec), None)
    if opcode == OP["VCMP"]:
        r = {CMP_EQ: av == bv, CMP_LT: av < bv, CMP_LE: av <= bv}.get(func, av == bv)
        return (fix_one(W, prec, frac) if r else 0), 0, int(r)
    raise ValueError(f"opcode {opcode:#x} unsupported for precision {PREC_NAMES[prec]}")


# =============================================================================
# Whole-vector VALU semantics (one instruction, all lanes)
# =============================================================================
Q_NAN, Q_OVF, Q_UNF, Q_SUSPECT = 1, 2, 4, 8


def result_quality(fmt: FPFormat, fp_result: bool, r: int, ff: int, qin: int) -> int:
    q = qin
    if ff & ieee.NV:
        q |= Q_NAN
    if ff & ieee.OF:
        q |= Q_OVF
    if ff & ieee.UF:
        q |= Q_UNF
    if fp_result:
        if fmt.is_nan(r):
            q |= Q_NAN
        if fmt.is_inf(r):
            q |= Q_OVF
    return q


def valu_vector(fmt: FPFormat, ins, rm: int, A, B, C, QA, QB, QC, lmask: int, vm: int, lanes: int):
    """Returns (data[], qual[], vm_bits[], fflags) for one VALU instruction."""
    from golden_model.isa import src_use
    use = src_use(ins)
    data, qual, mb = [], [], []
    fflags = 0
    fp_res = is_fp(ins.prec) and ins.opcode != OP["VCLASS"]
    bsel = (ins.imm >> 12) % lanes
    for l in range(lanes):
        if ins.opcode == OP["VBCAST"]:
            a = A[bsel]
        elif ins.opcode == OP["VSLIDE"]:
            a = A[(l + bsel) % lanes]
        else:
            a = A[l]
        r, ff, m = valu_element(fmt, ins.opcode, ins.prec, ins.func, rm, ins.imm, a, B[l], C[l], (vm >> l) & 1, l)
        q = 0
        if use & 1:
            q |= QA[l]
        if use & 2:
            q |= QB[l]
        if use & 4:
            q |= QC[l]
        if ins.opcode == OP["VBCAST"]:
            q = QA[bsel]
        elif ins.opcode == OP["VSLIDE"]:
            q = QA[(l + bsel) % lanes]
        elif ins.opcode == OP["VSEL"]:
            q = QA[l] if (vm >> l) & 1 else QB[l]
        elif ins.opcode in (OP["VLANEID"], OP["VMSET"]):
            q = 0
        data.append(r)
        qual.append(result_quality(fmt, fp_res, r, ff, q))
        mb.append(m if m is not None else 0)
        if (lmask >> l) & 1:
            fflags |= ff
    return data, qual, mb, fflags
