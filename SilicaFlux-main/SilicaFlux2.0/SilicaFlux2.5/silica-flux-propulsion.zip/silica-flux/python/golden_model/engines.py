"""
Silica Flux golden model -- numerical engines.

Bit-exact definitions of the multi-step functional units.  Each function fixes
the *order* of every rounded operation, because the RTL is verified for exact
agreement, not for agreement within a tolerance:

  reduce        pairwise tree over active lanes (lane 2i with 2i+1, ...)
  poly          Horner, coefficient c_k broadcast from lane k of vs2
  interp        uniform-grid linear interpolation on normalised coordinate
  state_update  explicit Runge-Kutta stage combination (Butcher tableau)
  residual      lane residuals with absolute + relative tolerance
  conserve      scalar invariant  I = sum w_i x_i  against reference + sources
  objective     weighted / absolute / squared / penalty terms (+ tree sum)
  constraint    PASS / FAIL / MARGIN per lane
  sweep         mixed-radix grid candidate generation, LANES candidates/batch
  search        grid arg-min tracking and bounded compass (pattern) search

Quality bits (Q_*) are OR-propagated exactly as in the RTL.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from golden_model import ieee
from golden_model.ieee import FPFormat, RNE, NV, OF, UF

Q_NAN, Q_OVF, Q_UNF, Q_SUSPECT = 1, 2, 4, 8


def fq(fmt: FPFormat, r: int, ff: int) -> int:
    """quality raised by one FP result"""
    q = 0
    if ff & NV or fmt.is_nan(r):
        q |= Q_NAN
    if ff & OF or fmt.is_inf(r):
        q |= Q_OVF
    if ff & UF:
        q |= Q_UNF
    return q


def fp_int(fmt: FPFormat, v: int) -> int:
    """exact FP encoding of a small integer (|v| < 2^p)"""
    return ieee.fix_to_fp(fmt, v & ((1 << 32) - 1), 32, 0, True, RNE)[0]


def bits_of(lmask: int, lanes: int):
    return [(lmask >> l) & 1 for l in range(lanes)]


# =============================================================================
# reduction tree
# =============================================================================
RED_SUM, RED_MIN, RED_MAX, RED_SUMSQ, RED_DOT, RED_ARGMIN, RED_ARGMAX, RED_MAXABS = range(8)


def _argsel(fmt, a, b, want_max):
    """(value, idx) node select: NaN loses, ties keep the lower index (a)"""
    (va, ia), (vb, ib) = a, b
    if fmt.is_nan(va) and not fmt.is_nan(vb):
        return b
    if fmt.is_nan(vb):
        return a
    better = ieee.flt(fmt, va, vb)[0] if want_max else ieee.flt(fmt, vb, va)[0]
    return b if better else a


def tree_reduce(fmt: FPFormat, func: int, vals, valid, rm: int):
    """returns (value, flags, any_valid).  For ARG* the value is the index."""
    flags = 0
    if func in (RED_ARGMIN, RED_ARGMAX):
        level = [((v, i), bool(ok)) for i, (v, ok) in enumerate(zip(vals, valid))]
    else:
        level = [(v, bool(ok)) for v, ok in zip(vals, valid)]
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            (a, va), (b, vb) = level[i], level[i + 1]
            if va and vb:
                if func in (RED_SUM, RED_SUMSQ, RED_DOT):
                    r, f = ieee.add(fmt, a, b, rm)
                elif func == RED_MIN:
                    r, f = ieee.fmin(fmt, a, b)
                elif func in (RED_MAX, RED_MAXABS):
                    r, f = ieee.fmax(fmt, a, b)
                else:
                    r, f = _argsel(fmt, a, b, func == RED_ARGMAX), 0
                flags |= f
                nxt.append((r, True))
            elif va:
                nxt.append((a, True))
            elif vb:
                nxt.append((b, True))
            else:
                nxt.append((level[i][0], False))
        level = nxt
    (v, ok) = level[0]
    if func in (RED_ARGMIN, RED_ARGMAX):
        v = v[1]
    return v, flags, ok


def reduce(fmt: FPFormat, func: int, rm: int, A, B, QA, QB, lmask: int, lanes: int):
    """VREDUCE -> (data[], qual[], fflags)"""
    act = bits_of(lmask, lanes)
    flags = 0
    q = 0
    vals = list(A)
    for l in range(lanes):
        if act[l]:
            q |= QA[l] | (QB[l] if func == RED_DOT else 0)
    if func in (RED_SUMSQ, RED_DOT):
        pre = []
        for l in range(lanes):
            r, f = ieee.mul(fmt, A[l], A[l] if func == RED_SUMSQ else B[l], rm)
            if act[l]:
                flags |= f
            pre.append(r)
        vals = pre
    elif func == RED_MAXABS:
        vals = [v & (fmt.mask >> 1) for v in A]
    v, f, ok = tree_reduce(fmt, func, vals, act, rm)
    flags |= f
    if func in (RED_ARGMIN, RED_ARGMAX):
        res = fp_int(fmt, v if ok else -1)
        qq = q | (0 if ok else Q_SUSPECT)
    else:
        res = v if ok else fmt.zero(0)
        qq = q | fq(fmt, res, flags) | (0 if ok else Q_SUSPECT)
    return [res] * lanes, [qq] * lanes, flags


# =============================================================================
# polynomial / cube
# =============================================================================
def poly(fmt: FPFormat, rm: int, degree: int, X, Cv, QX, QC, lmask: int, lanes: int):
    D = min(degree, lanes - 1)
    act = bits_of(lmask, lanes)
    qc = 0
    for k in range(D + 1):
        qc |= QC[k]
    data, qual, flags = [], [], 0
    for l in range(lanes):
        acc, lf = Cv[D], 0
        for k in range(D - 1, -1, -1):
            acc, f = ieee.fma(fmt, acc, X[l], Cv[k], rm)
            lf |= f
        data.append(acc)
        qual.append(QX[l] | qc | fq(fmt, acc, lf) if D > 0 else qc | fq(fmt, acc, 0))
        if act[l]:
            flags |= lf
    return data, qual, flags


def cube(fmt: FPFormat, rm: int, X, QX, lmask: int, lanes: int):
    act = bits_of(lmask, lanes)
    data, qual, flags = [], [], 0
    for l in range(lanes):
        t, f1 = ieee.mul(fmt, X[l], X[l], rm)
        r, f2 = ieee.mul(fmt, t, X[l], rm)
        data.append(r)
        qual.append(QX[l] | fq(fmt, r, f1 | f2))
        if act[l]:
            flags |= f1 | f2
    return data, qual, flags


# =============================================================================
# interpolation  (table of LANES points y_i in vs2, slopes d_i = y_{i+1}-y_i in vs3)
# =============================================================================
def interp(fmt: FPFormat, rm: int, T, Y, Dt, QT, QY, QD, lmask: int, lanes: int):
    N = lanes
    nm1 = fp_int(fmt, N - 1)
    zero = fmt.zero(0)
    act = bits_of(lmask, lanes)
    data, qual, flags = [], [], 0
    for l in range(lanes):
        t = T[l]
        lo, _ = ieee.flt(fmt, t, zero)
        hi, _ = ieee.flt(fmt, nm1, t)
        eqn, _ = ieee.feq(fmt, t, nm1)
        if fmt.is_nan(t) or not (lo or hi or eqn):
            if fmt.is_nan(t):
                i = 0
            else:
                i = int(ieee.fp_to_fix(fmt, t, ieee.RDN, 32, 0, True)[0])
                i = min(max(i, 0), N - 2)
            fr, f1 = ieee.sub(fmt, t, fp_int(fmt, i), rm)
            r, f2 = ieee.fma(fmt, Dt[i], fr, Y[i], rm)
            lf = f1 | f2
            q = QT[l] | QY[i] | QD[i] | fq(fmt, r, lf)
        else:
            i = 0 if lo else N - 1
            r, lf = Y[i], 0
            q = QT[l] | QY[i] | (Q_SUSPECT if (lo or hi) else 0)
        data.append(r)
        qual.append(q)
        if act[l]:
            flags |= lf
    return data, qual, flags


# =============================================================================
# explicit Runge-Kutta state engine
# =============================================================================
def tableau(name: int):
    """Butcher tableaux as exact fractions -> rounded into the FP format"""
    from fractions import Fraction as Fr
    if name == 0:   # Euler
        return 1, {}, [Fr(1)]
    if name == 1:   # Heun
        return 2, {(1, 0): Fr(1)}, [Fr(1, 2), Fr(1, 2)]
    if name == 2:   # explicit midpoint
        return 2, {(1, 0): Fr(1, 2)}, [Fr(0), Fr(1)]
    if name == 3:   # Ralston
        return 2, {(1, 0): Fr(2, 3)}, [Fr(1, 4), Fr(3, 4)]
    if name == 4:   # classic RK4
        return 4, {(1, 0): Fr(1, 2), (2, 1): Fr(1, 2), (3, 2): Fr(1)}, [Fr(1, 6), Fr(1, 3), Fr(1, 3), Fr(1, 6)]
    raise ValueError(name)


def frac_to_fp(fmt: FPFormat, v) -> int:
    from fractions import Fraction
    v = Fraction(v)
    if v == 0:
        return fmt.zero(0)
    s = int(v < 0)
    v = abs(v)
    K = fmt.p + 8 + v.denominator.bit_length()
    n = (v.numerator << K) // v.denominator
    st = (v.numerator << K) % v.denominator != 0
    return ieee.round_pack(fmt, s, n, -K, st, RNE)[0]


A_SLOTS = [(1, 0), (2, 0), (2, 1), (3, 0), (3, 1), (3, 2)]


@dataclass
class EngineState:
    fmt: FPFormat
    lanes: int
    # timestep engine
    dt: int = 0
    t: int = 0
    step: int = 0
    stages: int = 1
    A: dict = field(default_factory=dict)       # (i,j) -> fp bits
    b: list = field(default_factory=list)
    ca: dict = field(default_factory=dict)      # dt*A
    cb: list = field(default_factory=list)      # dt*b
    ts_valid: bool = False
    x0: list = field(default_factory=list)
    qx0: list = field(default_factory=list)
    k: list = field(default_factory=list)
    qk: list = field(default_factory=list)
    custom_stages: int = 1
    custom_A: dict = field(default_factory=dict)
    custom_b: list = field(default_factory=list)
    # residual / conservation
    res_rtol: int = 0
    cons_atol: int = 0
    cons_rtol: int = 0
    cons_ref: int = 0
    cons_last_resid: int = 0
    cons_viol_count: int = 0
    res_viol_count: int = 0
    # constraints
    con_pass: int = 0
    con_fail: int = 0
    # sweep
    sw_dims: int = 1
    sw_lo: list = field(default_factory=list)
    sw_step: list = field(default_factory=list)
    sw_count: list = field(default_factory=list)
    sw_base: int = 0
    sw_digits: list = field(default_factory=list)
    sw_done: bool = False
    # search
    sr_best: int = 0
    sr_best_idx: int = 0xFFFFFFFF
    ls_dims: int = 1
    ls_lo: list = field(default_factory=list)
    ls_hi: list = field(default_factory=list)
    ls_center0: list = field(default_factory=list)
    ls_step0: list = field(default_factory=list)
    ls_min_step: list = field(default_factory=list)
    ls_max_iter: int = 64
    ls_center: list = field(default_factory=list)
    ls_step: list = field(default_factory=list)
    ls_iter: int = 0
    ls_conv: bool = False
    ls_fcenter: int = 0
    ls_cand: list = field(default_factory=list)

    def __post_init__(self):
        f, L = self.fmt, self.lanes
        z = f.zero(0)
        self.x0 = [z] * L
        self.qx0 = [0] * L
        self.k = [[z] * L for _ in range(4)]
        self.qk = [[0] * L for _ in range(4)]
        self.custom_b = [z] * 4
        self.custom_A = {s: z for s in A_SLOTS}
        nd = 4
        self.sw_lo = [z] * nd
        self.sw_step = [z] * nd
        self.sw_count = [1] * nd
        self.sw_digits = [[0] * nd for _ in range(L)]
        self.sr_best = f.inf(0)
        self.ls_lo = [f.inf(1)] * nd
        self.ls_hi = [f.inf(0)] * nd
        self.ls_center0 = [z] * nd
        self.ls_step0 = [f.one()] * nd
        self.ls_min_step = [z] * nd
        self.ls_center = [z] * nd
        self.ls_step = [f.one()] * nd
        self.ls_fcenter = f.inf(0)
        self.ls_cand = [z] * L
        self.t = z


def tscfg(st: EngineState, func: int, dt_bits: int):
    """TSCFG: returns fault-step flag"""
    f = st.fmt
    if func == 15:
        st.t, st.step = f.zero(0), 0
        return False
    if func == 7:
        S = st.custom_stages
        A = {k: v for k, v in st.custom_A.items() if k[0] < S}
        b = st.custom_b[:S]
    else:
        S, Af, bf = tableau(func)
        A = {k: frac_to_fp(f, v) for k, v in Af.items()}
        b = [frac_to_fp(f, v) for v in bf]
    st.stages = S
    st.A = A
    st.b = b
    st.dt = dt_bits
    ok = f.is_finite(dt_bits) and not f.is_zero(dt_bits) and not f.sign(dt_bits)
    st.ts_valid = ok
    st.ca = {k: ieee.mul(f, dt_bits, v, RNE)[0] for k, v in A.items()}
    st.cb = [ieee.mul(f, dt_bits, v, RNE)[0] for v in b]
    return not ok


def state_update(st: EngineState, func: int, rm: int, X, QX, lmask: int):
    """STATE_UPDATE -> (data[], qual[], fflags, fault_step, committed)"""
    f, L = st.fmt, st.lanes
    act = bits_of(lmask, L)
    if func == 8:   # load x0
        st.x0 = list(X)
        st.qx0 = list(QX)
        return list(X), list(QX), 0, False, False
    s = func
    fault = (not st.ts_valid) or s >= st.stages
    if s < 4:
        st.k[s] = list(X)
        st.qk[s] = list(QX)
    if fault:
        # invalid stage or invalid timestep: x0 is returned unchanged and marked suspect
        return list(st.x0), [q | Q_SUSPECT for q in st.qx0], 0, True, False
    last = (s == st.stages - 1)
    coefs = [st.cb[j] if last else st.ca.get((s + 1, j), f.zero(0)) for j in range(s + 1)]
    data, qual, flags = [], [], 0
    for l in range(L):
        acc, lf, q = st.x0[l], 0, st.qx0[l]
        for j in range(s + 1):
            cj = coefs[j]
            if f.is_zero(cj):
                continue
            acc, ff = ieee.fma(f, cj, st.k[j][l], acc, rm)
            lf |= ff
            q |= st.qk[j][l]
        q |= fq(f, acc, lf)
        data.append(acc)
        qual.append(q)
        if act[l]:
            flags |= lf
    if last:
        st.t = ieee.add(f, st.t, st.dt, RNE)[0]
        st.step += 1
    return data, qual, flags, False, last


# =============================================================================
# residual engine
# =============================================================================
RES_SIGNED, RES_ABS, RES_MARGIN = 0, 1, 2


def _le(fmt, a, b):
    return ieee.fle(fmt, a, b)[0]


def residual(st: EngineState, func: int, rm: int, E, O, AT, QE, QO, QA, lmask: int):
    f, L = st.fmt, st.lanes
    act = bits_of(lmask, L)
    data, qual, vm, flags, nviol = [], [], [], 0, 0
    for l in range(L):
        r, f1 = ieee.sub(f, E[l], O[l], rm)
        a = r & (f.mask >> 1)
        th, f2 = ieee.fma(f, st.res_rtol, E[l] & (f.mask >> 1), AT[l], rm)
        lf = f1 | f2
        viol = not _le(f, a, th)
        if func == RES_ABS:
            out = a
        elif func == RES_MARGIN:
            out, f3 = ieee.sub(f, th, a, rm)
            lf |= f3
        else:
            out = r
        q = QE[l] | QO[l] | QA[l] | fq(f, out, lf) | (Q_SUSPECT if viol else 0)
        data.append(out)
        qual.append(q)
        vm.append(int(viol))
        if act[l]:
            flags |= lf
            nviol += int(viol)
    st.res_viol_count += nviol
    return data, qual, vm, flags, nviol > 0


# =============================================================================
# conservation checker
# =============================================================================
CONS_CAPTURE, CONS_CHECK, CONS_CHECK_ADV = 0, 1, 2


def conserve(st: EngineState, func: int, rm: int, X, Wt, S, QX, QW, QS, lmask: int):
    f, L = st.fmt, st.lanes
    act = bits_of(lmask, L)
    flags = 0
    q = 0
    for l in range(L):
        if act[l]:
            q |= QX[l] | QW[l] | (QS[l] if func != CONS_CAPTURE else 0)
    prods = []
    for l in range(L):
        p, ff = ieee.mul(f, Wt[l], X[l], rm)
        if act[l]:
            flags |= ff
        prods.append(p)
    I, ff, ok = tree_reduce(f, RED_SUM, prods, act, rm)
    flags |= ff
    if not ok:
        I = f.zero(0)
    out = [f.zero(0)] * L
    if func == CONS_CAPTURE:
        st.cons_ref = I
        return [I] * L, [q | fq(f, I, flags)] * L, flags, False
    Ssum, ff, ok2 = tree_reduce(f, RED_SUM, S, act, rm)
    flags |= ff
    if not ok2:
        Ssum = f.zero(0)
    ref_before = st.cons_ref
    E, f1 = ieee.add(f, st.cons_ref, Ssum, rm)
    r, f2 = ieee.sub(f, I, E, rm)
    ar = r & (f.mask >> 1)
    aE = E & (f.mask >> 1)
    th, f3 = ieee.fma(f, st.cons_rtol, aE, st.cons_atol, rm)
    if f.is_zero(aE):
        rel = ar
    else:
        rel, _ = ieee.div(f, ar, aE, rm)
    flags |= f1 | f2 | f3
    viol = not _le(f, ar, th)
    vals = [I, E, r, rel, th, f.one() if viol else f.zero(0), ref_before, ar]
    out = (vals + [f.zero(0)] * L)[:L]
    st.cons_last_resid = r
    if viol:
        st.cons_viol_count += 1
    if func == CONS_CHECK_ADV:
        st.cons_ref = I
    qq = q | fq(f, r, flags) | (Q_SUSPECT if viol else 0)
    return out, [qq] * L, flags, viol


# =============================================================================
# objective
# =============================================================================
OBJ_WSUM, OBJ_ABS, OBJ_SQ, OBJ_PENALTY = 0, 1, 2, 3


def objective(st: EngineState, func: int, rm: int, X, T, Wt, QX, QT, QW, lmask: int):
    f, L = st.fmt, st.lanes
    act = bits_of(lmask, L)
    mode, red = func & 3, (func >> 3) & 1
    terms, qual, flags = [], [], 0
    for l in range(L):
        lf = 0
        if mode == OBJ_WSUM:
            term, f1 = ieee.mul(f, Wt[l], X[l], rm)
            lf |= f1
            qin = QX[l] | QW[l]
        elif mode == OBJ_ABS:
            d, f1 = ieee.sub(f, X[l], T[l], rm)
            term, f2 = ieee.mul(f, Wt[l], d & (f.mask >> 1), rm)
            lf |= f1 | f2
            qin = QX[l] | QT[l] | QW[l]
        elif mode == OBJ_SQ:
            d, f1 = ieee.sub(f, X[l], T[l], rm)
            e2, f2 = ieee.mul(f, d, d, rm)
            term, f3 = ieee.mul(f, Wt[l], e2, rm)
            lf |= f1 | f2 | f3
            qin = QX[l] | QT[l] | QW[l]
        else:  # penalty on margin x: (min(x,0))^2 * w
            m = X[l]
            neg = ieee.flt(f, m, f.zero(0))[0] or f.is_nan(m)
            v = m if neg else f.zero(0)
            p2, f1 = ieee.mul(f, v, v, rm)
            term, f2 = ieee.mul(f, Wt[l], p2, rm)
            lf |= f1 | f2
            qin = QX[l] | QW[l]
        terms.append(term)
        qual.append(qin | fq(f, term, lf))
        if act[l]:
            flags |= lf
    if not red:
        return terms, qual, flags
    J, ff, ok = tree_reduce(f, RED_SUM, terms, act, rm)
    flags |= ff
    if not ok:
        J = f.zero(0)
    qq = 0
    for l in range(L):
        if act[l]:
            qq |= qual[l]
    qq |= fq(f, J, ff) | (0 if ok else Q_SUSPECT)
    return [J] * L, [qq] * L, flags


# =============================================================================
# constraint
# =============================================================================
CON_LT, CON_GT, CON_EQ, CON_TOL, CON_LE, CON_GE = range(6)


def constraint(st: EngineState, func: int, rm: int, X, B, TL, QX, QB, QT, lmask: int):
    f, L = st.fmt, st.lanes
    act = bits_of(lmask, L)
    data, qual, vm, flags = [], [], [], 0
    npass = nfail = 0
    z = f.zero(0)
    for l in range(L):
        lf = 0
        if func in (CON_LT, CON_LE):
            m, lf = ieee.sub(f, B[l], X[l], rm)
        elif func in (CON_GT, CON_GE):
            m, lf = ieee.sub(f, X[l], B[l], rm)
        elif func == CON_EQ:
            d, lf = ieee.sub(f, X[l], B[l], rm)
            m = d | (1 << (f.width - 1)) if not f.is_nan(d) else d
        else:
            d, f1 = ieee.sub(f, X[l], B[l], rm)
            m, f2 = ieee.sub(f, TL[l], d & (f.mask >> 1), rm)
            lf = f1 | f2
        if func in (CON_LT, CON_GT, CON_TOL):
            ok = ieee.flt(f, z, m)[0]
        elif func in (CON_LE, CON_GE):
            ok = ieee.fle(f, z, m)[0]
        else:
            ok = ieee.feq(f, m, z)[0]
        data.append(m)
        qual.append(QX[l] | QB[l] | (QT[l] if func == CON_TOL else 0) | fq(f, m, lf))
        vm.append(int(ok))
        if act[l]:
            flags |= lf
            npass += int(ok)
            nfail += int(not ok)
    st.con_pass += npass
    st.con_fail += nfail
    return data, qual, vm, flags, nfail > 0


# =============================================================================
# parameter sweep
# =============================================================================
SW_RESET, SW_GEN, SW_NEXT = 0, 1, 2


def sweep_total(st: EngineState) -> int:
    t = 1
    for d in range(st.sw_dims):
        t *= st.sw_count[d]
    return t


def sweep_config_ok(st: EngineState) -> bool:
    f = st.fmt
    if not 1 <= st.sw_dims <= 4:
        return False
    for d in range(st.sw_dims):
        if not 1 <= st.sw_count[d] <= 65535 or not f.is_finite(st.sw_lo[d]) or not f.is_finite(st.sw_step[d]):
            return False
    return sweep_total(st) < (1 << 32)


def _inc_digits(st: EngineState, dg):
    for d in range(st.sw_dims):
        dg[d] += 1
        if dg[d] < st.sw_count[d]:
            return
        dg[d] = 0


def sweep(st: EngineState, func: int, rm: int, dim: int, lmask: int = 0):
    """returns (data[] or None, vm[] or None, qual[] or None, fflags, fault)"""
    f, L = st.fmt, st.lanes
    ok = sweep_config_ok(st)
    if func == SW_RESET:
        st.sw_base = 0
        st.sw_done = False
        st.sw_digits = [[0] * 4 for _ in range(L)]
        for l in range(L):
            for _ in range(l):
                _inc_digits(st, st.sw_digits[l])
        return None, None, None, 0, not ok
    if func == SW_NEXT:
        st.sw_base += L
        for l in range(L):
            for _ in range(L):
                _inc_digits(st, st.sw_digits[l])
        st.sw_done = st.sw_base >= sweep_total(st)
        return None, None, None, 0, not ok
    # GEN
    d = dim & 3
    total = sweep_total(st)
    data, vm, qual, flags = [], [], [], 0
    for l in range(L):
        v, ff = ieee.fma(f, fp_int(f, st.sw_digits[l][d]), st.sw_step[d], st.sw_lo[d], rm)
        data.append(v)
        qual.append(fq(f, v, ff))
        vm.append(int(st.sw_base + l < total and ok))
        if (lmask >> l) & 1:
            flags |= ff
    return data, vm, qual, flags, not ok


# =============================================================================
# search
# =============================================================================
SR_RESET, SR_GRID, SR_LOCAL, SR_LS_GEN = 0, 1, 2, 3


def _argmin_lanes(fmt, vals, valid):
    v, _, ok = tree_reduce(fmt, RED_ARGMIN, vals, valid, RNE)
    if not ok or fmt.is_nan(vals[v]):
        return None
    return v


def search_reset(st: EngineState):
    f = st.fmt
    st.sr_best = f.inf(0)
    st.sr_best_idx = 0xFFFFFFFF
    st.ls_center = list(st.ls_center0)
    st.ls_step = list(st.ls_step0)
    st.ls_iter = 0
    st.ls_conv = False
    st.ls_fcenter = f.inf(0)


def ls_perturbed(st: EngineState, lane: int):
    """center_k +/- step_k for compass lane (k = lane // 2) -> (value, flags)"""
    f = st.fmt
    k, plus = lane // 2, (lane % 2) == 0
    return (ieee.add if plus else ieee.sub)(f, st.ls_center[k], st.ls_step[k], RNE)


def ls_valid(st: EngineState, lane: int, v: int) -> bool:
    f, L = st.fmt, st.lanes
    if lane == L - 1:
        return True
    if lane >= 2 * st.ls_dims:
        return False
    k = lane // 2
    return ieee.fle(f, st.ls_lo[k], v)[0] and ieee.fle(f, v, st.ls_hi[k])[0]


def search(st: EngineState, func: int, rm: int, dim: int, OBJ, lmask: int, vm: int):
    """returns (data[] or None, vm[] or None, qual[] or None, fflags, fault)"""
    f, L = st.fmt, st.lanes
    if func == SR_RESET:
        search_reset(st)
        return None, None, None, 0, not (1 <= st.ls_dims <= min(4, (L - 1) // 2))
    if func == SR_LS_GEN:
        d = dim & 3
        data, vmo, qual, flags = [], [], [], 0
        for l in range(L):
            if l < 2 * st.ls_dims:
                v, ff = ls_perturbed(st, l)
                st.ls_cand[l] = v
                vmo.append(int(ls_valid(st, l, v)))
                if l // 2 == d:
                    data.append(v)
                    qual.append(fq(f, v, ff))
                    if (lmask >> l) & 1:
                        flags |= ff
                    continue
            else:
                vmo.append(int(l == L - 1))
            data.append(st.ls_center[d])
            qual.append(fq(f, st.ls_center[d], 0))
        return data, vmo, qual, flags, False
    feas = [((lmask >> l) & 1) and ((vm >> l) & 1) for l in range(L)]
    if func == SR_GRID:
        i = _argmin_lanes(f, OBJ, feas)
        if i is not None and ieee.flt(f, OBJ[i], st.sr_best)[0]:
            st.sr_best = OBJ[i]
            st.sr_best_idx = (st.sw_base + i) & 0xFFFFFFFF
        return None, None, None, 0, False
    # SR_LOCAL
    if st.ls_conv:
        return None, None, None, 0, False
    fc = OBJ[L - 1]
    fault = not feas[L - 1] or f.is_nan(fc)
    st.ls_fcenter = fc
    cand = [feas[l] if l < 2 * st.ls_dims else 0 for l in range(L)]
    i = _argmin_lanes(f, OBJ, cand)
    if i is not None and ieee.flt(f, OBJ[i], fc)[0]:
        k = i // 2
        st.ls_center[k] = st.ls_cand[i]
        st.ls_fcenter = OBJ[i]
    else:
        st.ls_step = [ieee.mul(f, s, frac_to_fp(f, 0.5), RNE)[0] for s in st.ls_step]
    st.sr_best = st.ls_fcenter
    st.ls_iter += 1
    small = all(ieee.flt(f, st.ls_step[d], st.ls_min_step[d])[0] for d in range(st.ls_dims))
    st.ls_conv = small or st.ls_iter >= st.ls_max_iter
    return None, None, None, 0, fault
