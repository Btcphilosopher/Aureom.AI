"""
Silica Flux golden model -- telemetry ingest, timestamp checking and buffer.

Bit-exact model of rtl/telemetry/{telemetry_ingest, timestamp_engine,
telemetry_buffer}.sv operating on the 64-bit AXI-Stream beats.  Produces the
channel table (value, quality), the frame count, the counters and the fault
events that the fabric reports.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from golden_model import ieee
from golden_model.isa import F, Q_NAN, Q_SUSPECT


def crc16_ccitt(data: bytes, crc: int = 0xFFFF) -> int:
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
    return crc


@dataclass
class TelemetryModel:
    fmt: ieee.FPFormat
    lanes: int
    n_chan: int = 32
    max_gap: int = 0
    bounds: dict = field(default_factory=dict)       # chan -> (lo_bits, hi_bits)
    counters: dict = field(default_factory=lambda: {k: 0 for k in (
        "rx", "accepted", "dropped", "crc", "seq", "ts", "range", "malformed", "frames", "ovf")})
    faults: int = 0
    first_fault: int | None = None
    table: list = field(default_factory=list)

    def __post_init__(self):
        rows = (self.n_chan + self.lanes - 1) // self.lanes
        self.table = [[(0, Q_SUSPECT, False)] * self.lanes for _ in range(rows)]
        self._seq_init = False
        self._seq_exp = 0
        self._ts_init = False
        self._ts_last = 0
        self._state = 0
        self._hdr = self._val = 0
        self.frames_pending = 0

    def _fault(self, name):
        self.faults |= 1 << F[name]
        if self.first_fault is None:
            self.first_fault = F[name]

    def beat(self, data: int, last: int):
        st = self._state
        if st == 3:                       # resync
            if last:
                self._state = 0
            return
        if st == 0:
            self._hdr = data
            if last:
                self.counters["malformed"] += 1
                self._fault("TL_MALFORMED")
            else:
                self._state = 1
            return
        if st == 1:
            self._val = data
            if last:
                self.counters["malformed"] += 1
                self._fault("TL_MALFORMED")
                self._state = 0
            else:
                self._state = 2
            return
        # third beat
        self.counters["rx"] += 1
        self._state = 0 if last else 3
        hdr, val = self._hdr, self._val
        chan = (hdr >> 8) & 0xFF
        seq = (hdr >> 16) & 0xFFFF
        ts = (hdr >> 32) & 0xFFFFFFFF
        crc = crc16_ccitt(hdr.to_bytes(8, "little") + val.to_bytes(8, "little"))
        if not last or chan >= self.n_chan:
            self.counters["malformed"] += 1
            self._fault("TL_MALFORMED")
            return
        if crc != (data & 0xFFFF):
            self.counters["crc"] += 1
            self._fault("TL_CRC")
            return
        diff = (seq - self._seq_exp) & 0xFFFF
        if self._seq_init and diff & 0x8000:
            self.counters["seq"] += 1
            self._fault("TL_SEQ")
            return
        q = 0
        events = []
        if hdr & 1:
            q |= Q_SUSPECT
        if self._ts_init and (ts <= self._ts_last or (self.max_gap and ((ts - self._ts_last) & 0xFFFFFFFF) > self.max_gap)):
            q |= Q_SUSPECT
            self.counters["ts"] += 1
            events.append("TL_TS")
        value = val & self.fmt.mask
        lo, hi = self.bounds.get(chan, (self.fmt.inf(1), self.fmt.inf(0)))
        nan = self.fmt.is_nan(value)
        in_rng = (not nan) and ieee.fle(self.fmt, lo, value)[0] and ieee.fle(self.fmt, value, hi)[0]
        if nan or not in_rng:
            q |= Q_SUSPECT | (Q_NAN if nan else 0)
            self.counters["range"] += 1
            events.append("RANGE")
        if self._seq_init and diff != 0:
            self.counters["dropped"] += diff
            self.counters["seq"] += 1
            events.append("TL_SEQ")
        # events of one packet are reported together; the lowest id is "first"
        for e in sorted(events, key=lambda n: F[n]):
            self._fault(e)
        self._seq_init, self._seq_exp = True, (seq + 1) & 0xFFFF
        self._ts_init, self._ts_last = True, ts
        self.counters["accepted"] += 1
        r, l = divmod(chan, self.lanes)
        self.table[r][l] = (value, q, False)
        if hdr & 0x80:
            self.counters["frames"] += 1
            self.frames_pending = 1

    def run(self, beats):
        for data, _user, last in beats:
            self.beat(data, last)
        return self
