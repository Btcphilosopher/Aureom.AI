#!/usr/bin/env python3
"""
Independent check of the golden model against the host CPU's IEEE-754
arithmetic (round-to-nearest-even only -- the mode the host exposes):

  FP64: ieee.add/sub/mul/div/sqrt/fma  vs  Python float and math.fma
  FP32: ieee.add/sub/mul/div/sqrt      vs  numpy.float32 (correctly rounded)

The golden model is pure integer arithmetic; agreement with an unrelated
implementation (the CPU's FPU) on random and special operands is the check
that the *specification* the RTL is verified against is itself right.
Directed rounding modes are checked against exact rational arithmetic in
golden_model/ieee.py's own definitions and by the RTL cross-checks.

    python3 python/golden_model/selftest.py [-n 200000]
Output: reports/golden_selftest.json
"""
from __future__ import annotations

import argparse
import json
import math
import random
import struct
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))

from golden_model import ieee  # noqa: E402
from generators.stimulus import FPStimulus  # noqa: E402


def f64(bits):
    return struct.unpack("<d", struct.pack("<Q", bits))[0]


def b64(x):
    return struct.unpack("<Q", struct.pack("<d", x))[0]


def f32(bits):
    return np.frombuffer(struct.pack("<I", bits), dtype=np.float32)[0]


def b32(x):
    return struct.unpack("<I", np.float32(x).tobytes())[0]


def same(fmt, a, b):
    """bit-exact, except that any NaN matches any NaN (the host does not canonicalise)"""
    return a == b or (fmt.is_nan(a) and fmt.is_nan(b))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-n", type=int, default=200000)
    a = ap.parse_args()
    np.seterr(all="ignore")
    res = {}
    st = FPStimulus(ieee.FP64, seed=7)
    ops64 = {
        "add": (lambda x, y, z: ieee.add(ieee.FP64, x, y, 0)[0], lambda x, y, z: b64(f64(x) + f64(y))),
        "sub": (lambda x, y, z: ieee.sub(ieee.FP64, x, y, 0)[0], lambda x, y, z: b64(f64(x) - f64(y))),
        "mul": (lambda x, y, z: ieee.mul(ieee.FP64, x, y, 0)[0], lambda x, y, z: b64(f64(x) * f64(y))),
        "fma": (lambda x, y, z: ieee.fma(ieee.FP64, x, y, z, 0)[0], lambda x, y, z: b64(math.fma(f64(x), f64(y), f64(z)))),
    }

    def host_div64(x, y):
        try:
            return b64(f64(x) / f64(y))
        except ZeroDivisionError:
            return b64(float(np.float64(f64(x)) / np.float64(f64(y))))

    def host_sqrt64(x):
        return b64(float(np.sqrt(np.float64(f64(x)))))

    for name, (g, h) in ops64.items():
        bad = 0
        for _ in range(a.n):
            x, y, z = st.triple()
            try:
                hv = h(x, y, z)
            except (OverflowError, ValueError):
                continue
            bad += not same(ieee.FP64, g(x, y, z), hv)
        res[f"fp64_{name}"] = {"samples": a.n, "mismatches": bad}
    for name, g, h in (("div", lambda x, y: ieee.div(ieee.FP64, x, y, 0)[0], host_div64),
                       ("sqrt", lambda x, y: ieee.sqrt(ieee.FP64, x, 0)[0], lambda x, y: host_sqrt64(x))):
        bad = 0
        for _ in range(a.n // 2):
            x, y = st.pair()
            bad += not same(ieee.FP64, g(x, y), h(x, y))
        res[f"fp64_{name}"] = {"samples": a.n // 2, "mismatches": bad}
    st = FPStimulus(ieee.FP32, seed=11)
    ops32 = {"add": np.add, "sub": np.subtract, "mul": np.multiply, "div": np.divide}
    for name, nf in ops32.items():
        g = getattr(ieee, name)
        bad = 0
        for _ in range(a.n // 2):
            x, y = st.pair()
            bad += not same(ieee.FP32, g(ieee.FP32, x, y, 0)[0], b32(nf(f32(x), f32(y))))
        res[f"fp32_{name}"] = {"samples": a.n // 2, "mismatches": bad}
    bad = 0
    for _ in range(a.n // 2):
        x = st.value()
        bad += not same(ieee.FP32, ieee.sqrt(ieee.FP32, x, 0)[0], b32(np.sqrt(f32(x))))
    res["fp32_sqrt"] = {"samples": a.n // 2, "mismatches": bad}
    total = sum(v["mismatches"] for v in res.values())
    out = ROOT / "reports" / "golden_selftest.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps({"results": res, "total_mismatches": total,
                               "oracle": "host FPU (Python float, math.fma, numpy.float32), RNE"}, indent=2))
    for k, v in res.items():
        print(f"[golden] {k:<9} {v['samples']:>7} samples  {v['mismatches']} mismatches")
    print("GOLDEN MODEL SELF-TEST:", "PASS" if total == 0 else "FAIL")
    return 0 if total == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
