"""
Silica Flux golden model -- exact IEEE 754 binary floating-point arithmetic.

Every operation here is computed with *exact* integer / rational arithmetic and
then rounded once, using the same conventions the RTL implements:

  * formats ............ binary32 (FP32) and binary64 (FP64), generic in (E, M)
  * rounding modes ..... RNE=0, RTZ=1, RDN=2, RUP=3, RMM=4 (RISC-V encoding)
  * exception flags .... NX=1, UF=2, OF=4, DZ=8, NV=16 (RISC-V fflags layout)
  * NaN policy ......... every NaN result is the canonical quiet NaN
                         (sign 0, exponent all ones, mantissa MSB set)
  * tininess ........... detected BEFORE rounding (IEEE 754-2019 sec. 7.5 permits
                         either); UF is raised when the result is tiny AND inexact
  * subnormals ......... fully supported on input and output (no flush-to-zero)
  * fma(inf, 0, qNaN) .. raises NV (as RISC-V)

This module is deliberately independent of the RTL algorithm: the RTL uses a
fixed-width alignment window, guard/sticky bits and leading-zero normalisation,
whereas this model uses unbounded Python integers.  Agreement between the two
is therefore evidence of correctness rather than a transliteration check.
"""
from __future__ import annotations

import math
import struct
from dataclasses import dataclass

RNE, RTZ, RDN, RUP, RMM = 0, 1, 2, 3, 4
RM_NAMES = {RNE: "RNE", RTZ: "RTZ", RDN: "RDN", RUP: "RUP", RMM: "RMM"}

NX, UF, OF, DZ, NV = 1, 2, 4, 8, 16
FLAG_NAMES = [(NV, "NV"), (DZ, "DZ"), (OF, "OF"), (UF, "UF"), (NX, "NX")]


def flags_str(f: int) -> str:
    return "|".join(n for b, n in FLAG_NAMES if f & b) or "-"


@dataclass(frozen=True)
class FPFormat:
    name: str
    exp_bits: int
    man_bits: int

    @property
    def width(self) -> int:
        return 1 + self.exp_bits + self.man_bits

    @property
    def p(self) -> int:  # precision incl. hidden bit
        return self.man_bits + 1

    @property
    def bias(self) -> int:
        return (1 << (self.exp_bits - 1)) - 1

    @property
    def emin(self) -> int:
        return 1 - self.bias

    @property
    def emax(self) -> int:
        return self.bias

    @property
    def exp_mask(self) -> int:
        return (1 << self.exp_bits) - 1

    @property
    def man_mask(self) -> int:
        return (1 << self.man_bits) - 1

    @property
    def mask(self) -> int:
        return (1 << self.width) - 1

    # ---- canonical encodings ------------------------------------------------
    def qnan(self) -> int:
        return (self.exp_mask << self.man_bits) | (1 << (self.man_bits - 1))

    def inf(self, sign: int) -> int:
        return (sign << (self.width - 1)) | (self.exp_mask << self.man_bits)

    def zero(self, sign: int) -> int:
        return sign << (self.width - 1)

    def max_finite(self, sign: int) -> int:
        return (sign << (self.width - 1)) | ((self.exp_mask - 1) << self.man_bits) | self.man_mask

    def one(self) -> int:
        return self.bias << self.man_bits

    # ---- field access -------------------------------------------------------
    def sign(self, x: int) -> int:
        return (x >> (self.width - 1)) & 1

    def efield(self, x: int) -> int:
        return (x >> self.man_bits) & self.exp_mask

    def mfield(self, x: int) -> int:
        return x & self.man_mask

    def is_nan(self, x: int) -> bool:
        return self.efield(x) == self.exp_mask and self.mfield(x) != 0

    def is_snan(self, x: int) -> bool:
        return self.is_nan(x) and not (self.mfield(x) >> (self.man_bits - 1)) & 1

    def is_inf(self, x: int) -> bool:
        return self.efield(x) == self.exp_mask and self.mfield(x) == 0

    def is_zero(self, x: int) -> bool:
        return (x & ((1 << (self.width - 1)) - 1)) == 0

    def is_subnormal(self, x: int) -> bool:
        return self.efield(x) == 0 and self.mfield(x) != 0

    def is_finite(self, x: int) -> bool:
        return self.efield(x) != self.exp_mask

    def unpack(self, x: int):
        """finite x -> (sign, sig, e_lsb) with value = (-1)^sign * sig * 2^e_lsb"""
        s, ef, mf = self.sign(x), self.efield(x), self.mfield(x)
        if ef == 0:
            return s, mf, self.emin - self.man_bits
        return s, mf | (1 << self.man_bits), ef - self.bias - self.man_bits

    # ---- host conversions -----------------------------------------------------
    def from_float(self, v: float) -> int:
        if self.width == 32:
            return struct.unpack("<I", struct.pack("<f", v))[0]
        if self.width == 64:
            return struct.unpack("<Q", struct.pack("<d", v))[0]
        raise ValueError("only binary32/binary64 have host floats")

    def to_float(self, x: int) -> float:
        if self.width == 32:
            return struct.unpack("<f", struct.pack("<I", x & 0xFFFFFFFF))[0]
        if self.width == 64:
            return struct.unpack("<d", struct.pack("<Q", x & 0xFFFFFFFFFFFFFFFF))[0]
        raise ValueError("only binary32/binary64 have host floats")

    def to_fraction(self, x: int):
        from fractions import Fraction
        s, m, e = self.unpack(x)
        v = Fraction(m) * (Fraction(2) ** e)
        return -v if s else v


FP32 = FPFormat("fp32", 8, 23)
FP64 = FPFormat("fp64", 11, 52)
FORMATS = {"fp32": FP32, "fp64": FP64}


def fmt_for_mode(fp_mode: int) -> FPFormat:
    return FP64 if fp_mode else FP32


# =============================================================================
# The single rounding primitive
# =============================================================================
def round_pack(fmt: FPFormat, sign: int, n: int, e: int, sticky: bool, rm: int):
    """Round (-1)^sign * (n + d) * 2^e, 0 <= d < 1 (d > 0 iff sticky) into fmt.

    When ``sticky`` is set the caller must supply at least two bits below the
    rounding position (asserted), which every producer in this model does.
    Returns (bits, flags)."""
    if n == 0:
        assert not sticky, "sticky without significant bits"
        return fmt.zero(sign), 0
    p = fmt.p
    msb_exp = e + n.bit_length() - 1
    tiny = msb_exp < fmt.emin
    q_lsb = (msb_exp - (p - 1)) if not tiny else (fmt.emin - (p - 1))
    shift = q_lsb - e
    if shift > 0:
        q = n >> shift
        rem = n - (q << shift)
        rbit = (rem >> (shift - 1)) & 1
        st = (rem & ((1 << (shift - 1)) - 1)) != 0 or sticky
        assert not sticky or shift >= 2, "insufficient guard bits for sticky"
    else:
        assert not sticky, "insufficient guard bits for sticky"
        q, rbit, st = n << (-shift), 0, False
    inexact = bool(rbit or st)
    if rm == RNE:
        inc = rbit and (st or (q & 1))
    elif rm == RTZ:
        inc = 0
    elif rm == RDN:
        inc = inexact and sign
    elif rm == RUP:
        inc = inexact and not sign
    elif rm == RMM:
        inc = rbit
    else:
        raise ValueError(f"bad rounding mode {rm}")
    q += 1 if inc else 0
    if q == (1 << p):
        q >>= 1
        q_lsb += 1
    flags = (NX if inexact else 0) | (UF if (tiny and inexact) else 0)
    if q >= (1 << (p - 1)):
        eres = q_lsb + (p - 1)
        if eres > fmt.emax:
            flags |= OF | NX
            if rm in (RNE, RMM) or (rm == RDN and sign) or (rm == RUP and not sign):
                return fmt.inf(sign), flags
            return fmt.max_finite(sign), flags
        bits = (sign << (fmt.width - 1)) | ((eres + fmt.bias) << fmt.man_bits) | (q - (1 << (p - 1)))
        return bits, flags
    assert q_lsb == fmt.emin - fmt.man_bits
    return (sign << (fmt.width - 1)) | q, flags


# =============================================================================
# Arithmetic
# =============================================================================
FMADD, FMSUB, FNMSUB, FNMADD, FMUL, FADD, FSUB = range(7)
FMA_OP_NAMES = ["FMADD", "FMSUB", "FNMSUB", "FNMADD", "FMUL", "FADD", "FSUB"]


def fma_op(fmt: FPFormat, op: int, a: int, b: int, c: int, rm: int):
    """The FMA unit's instruction semantics (matches rtl/alu/fma_unit.sv)."""
    if op == FMADD:
        return fma(fmt, a, b, c, rm, False, False)
    if op == FMSUB:
        return fma(fmt, a, b, c, rm, False, True)
    if op == FNMSUB:
        return fma(fmt, a, b, c, rm, True, False)
    if op == FNMADD:
        return fma(fmt, a, b, c, rm, True, True)
    if op == FMUL:
        return fma(fmt, a, b, 0, rm, False, False, mul_only=True)
    if op == FADD:
        return fma(fmt, a, fmt.one(), c, rm, False, False)
    if op == FSUB:
        return fma(fmt, a, fmt.one(), c, rm, False, True)
    raise ValueError(op)


def fma(fmt: FPFormat, a: int, b: int, c: int, rm: int,
        neg_prod: bool = False, neg_add: bool = False, mul_only: bool = False):
    """(-1)^neg_prod * a*b + (-1)^neg_add * c, rounded once."""
    sa, sb = fmt.sign(a), fmt.sign(b)
    sp = sa ^ sb ^ int(neg_prod)
    if mul_only:
        c = fmt.zero(sp)
        sc = sp
    else:
        sc = fmt.sign(c) ^ int(neg_add)
    nan_in = fmt.is_nan(a) or fmt.is_nan(b) or fmt.is_nan(c)
    snan = fmt.is_snan(a) or fmt.is_snan(b) or fmt.is_snan(c)
    inv_mul = (fmt.is_inf(a) and fmt.is_zero(b)) or (fmt.is_zero(a) and fmt.is_inf(b))
    if nan_in or inv_mul:
        return fmt.qnan(), (NV if (snan or inv_mul) else 0)
    prod_inf = fmt.is_inf(a) or fmt.is_inf(b)
    if prod_inf:
        if fmt.is_inf(c) and sc != sp:
            return fmt.qnan(), NV
        return fmt.inf(sp), 0
    if fmt.is_inf(c):
        return fmt.inf(sc), 0
    _, ma, ea = fmt.unpack(a)
    _, mb, eb = fmt.unpack(b)
    _, mc, ec = fmt.unpack(c)
    P, eP = ma * mb, ea + eb
    e0 = min(eP, ec)
    val = (-P if sp else P) * (1 << (eP - e0)) + (-mc if sc else mc) * (1 << (ec - e0))
    if val == 0:
        zs = sp if sp == sc else int(rm == RDN)
        return fmt.zero(zs), 0
    return round_pack(fmt, int(val < 0), abs(val), e0, False, rm)


def add(fmt, a, b, rm):
    return fma(fmt, a, fmt.one(), b, rm)


def sub(fmt, a, b, rm):
    return fma(fmt, a, fmt.one(), b, rm, False, True)


def mul(fmt, a, b, rm):
    return fma(fmt, a, b, 0, rm, mul_only=True)


def div(fmt: FPFormat, a: int, b: int, rm: int):
    s = fmt.sign(a) ^ fmt.sign(b)
    if fmt.is_nan(a) or fmt.is_nan(b):
        return fmt.qnan(), NV if (fmt.is_snan(a) or fmt.is_snan(b)) else 0
    if (fmt.is_inf(a) and fmt.is_inf(b)) or (fmt.is_zero(a) and fmt.is_zero(b)):
        return fmt.qnan(), NV
    if fmt.is_inf(a):
        return fmt.inf(s), 0
    if fmt.is_inf(b):
        return fmt.zero(s), 0
    if fmt.is_zero(b):
        return fmt.inf(s), DZ
    if fmt.is_zero(a):
        return fmt.zero(s), 0
    _, ma, ea = fmt.unpack(a)
    _, mb, eb = fmt.unpack(b)
    K = fmt.p + 3 + mb.bit_length()
    num = ma << K
    q, r = divmod(num, mb)
    return round_pack(fmt, s, q, ea - eb - K, r != 0, rm)


def sqrt(fmt: FPFormat, a: int, rm: int):
    if fmt.is_nan(a):
        return fmt.qnan(), NV if fmt.is_snan(a) else 0
    if fmt.is_zero(a):
        return a, 0
    if fmt.sign(a):
        return fmt.qnan(), NV
    if fmt.is_inf(a):
        return a, 0
    _, m, e = fmt.unpack(a)
    if e & 1:
        m <<= 1
        e -= 1
    K = fmt.p + 3
    m <<= 2 * K
    r = math.isqrt(m)
    return round_pack(fmt, 0, r, e // 2 - K, r * r != m, rm)


# ---- non-arithmetic / comparison ---------------------------------------------
def _total_lt(fmt, a, b):
    """a < b for non-NaN, with -0 < +0 (used by min/max)."""
    sa, sb = fmt.sign(a), fmt.sign(b)
    if sa != sb:
        return sa == 1
    mag_a, mag_b = a & ~(1 << (fmt.width - 1)), b & ~(1 << (fmt.width - 1))
    return mag_a > mag_b if sa else mag_a < mag_b


def fmin(fmt, a, b):
    """IEEE 754-2019 minimumNumber (RISC-V fmin.s semantics)."""
    fl = NV if (fmt.is_snan(a) or fmt.is_snan(b)) else 0
    if fmt.is_nan(a) and fmt.is_nan(b):
        return fmt.qnan(), fl
    if fmt.is_nan(a):
        return b, fl
    if fmt.is_nan(b):
        return a, fl
    return (a if _total_lt(fmt, a, b) or a == b else b), fl


def fmax(fmt, a, b):
    fl = NV if (fmt.is_snan(a) or fmt.is_snan(b)) else 0
    if fmt.is_nan(a) and fmt.is_nan(b):
        return fmt.qnan(), fl
    if fmt.is_nan(a):
        return b, fl
    if fmt.is_nan(b):
        return a, fl
    return (b if _total_lt(fmt, a, b) else a), fl


def _num_cmp(fmt, a, b):
    """-1/0/+1 for non-NaN operands, +0 == -0."""
    if fmt.is_zero(a) and fmt.is_zero(b):
        return 0
    if a == b:
        return 0
    return -1 if _total_lt(fmt, a, b) else 1


def feq(fmt, a, b):
    if fmt.is_nan(a) or fmt.is_nan(b):
        return False, NV if (fmt.is_snan(a) or fmt.is_snan(b)) else 0
    return _num_cmp(fmt, a, b) == 0, 0


def flt(fmt, a, b):
    if fmt.is_nan(a) or fmt.is_nan(b):
        return False, NV
    return _num_cmp(fmt, a, b) < 0, 0


def fle(fmt, a, b):
    if fmt.is_nan(a) or fmt.is_nan(b):
        return False, NV
    return _num_cmp(fmt, a, b) <= 0, 0


def fclass(fmt, a) -> int:
    """RISC-V fclass 10-bit mask."""
    s = fmt.sign(a)
    if fmt.is_nan(a):
        return 1 << 8 if fmt.is_snan(a) else 1 << 9
    if fmt.is_inf(a):
        return 1 << 0 if s else 1 << 7
    if fmt.is_zero(a):
        return 1 << 3 if s else 1 << 4
    if fmt.is_subnormal(a):
        return 1 << 2 if s else 1 << 5
    return 1 << 1 if s else 1 << 6


# ---- integer / fixed-point conversion ----------------------------------------
def round_int_div_pow2(v: int, f: int, rm: int):
    """Round the exact rational v / 2^f to an integer with mode rm.
    Returns (int, inexact)."""
    if f <= 0:
        return v << (-f), False
    q = v >> f                      # floor
    rem = v - (q << f)              # 0 <= rem < 2^f
    if rem == 0:
        return q, False
    half = 1 << (f - 1)
    if rm == RTZ:
        r = q + 1 if v < 0 else q
    elif rm == RDN:
        r = q
    elif rm == RUP:
        r = q + 1
    elif rm == RMM:
        r = q + 1 if (rem > half or (rem == half and v >= 0)) else q
    else:  # RNE
        r = q + 1 if (rem > half or (rem == half and (q & 1))) else q
    return r, True


def fp_to_fix(fmt: FPFormat, a: int, rm: int, width: int, frac: int, signed: bool):
    """Convert to a width-bit (un)signed fixed-point value with `frac` fractional
    bits (frac=0 -> integer). Saturates; NaN -> max positive (RISC-V)."""
    lo = -(1 << (width - 1)) if signed else 0
    hi = (1 << (width - 1)) - 1 if signed else (1 << width) - 1
    if fmt.is_nan(a):
        return hi & ((1 << width) - 1), NV
    if fmt.is_inf(a):
        return (lo if fmt.sign(a) else hi) & ((1 << width) - 1), NV
    s, m, e = fmt.unpack(a)
    v = -m if s else m
    r, inexact = round_int_div_pow2(v, -(e + frac), rm)
    if r > hi or r < lo:
        return (hi if r > hi else lo) & ((1 << width) - 1), NV
    return r & ((1 << width) - 1), NX if inexact else 0


def fix_to_fp(fmt: FPFormat, v: int, width: int, frac: int, signed: bool, rm: int):
    v &= (1 << width) - 1
    if signed and v >> (width - 1):
        v -= 1 << width
    if v == 0:
        return fmt.zero(0), 0
    return round_pack(fmt, int(v < 0), abs(v), -frac, False, rm)


# ---- convenience ---------------------------------------------------------------
def ulp_error(fmt: FPFormat, got: int, exact) -> float:
    """|got - exact| measured in ULPs of the exact value (exact: Fraction or float).
    Uses the ULP of the binade containing `exact` (subnormal ULP below 2^emin)."""
    from fractions import Fraction
    if fmt.is_nan(got) or fmt.is_inf(got):
        return math.inf
    g = fmt.to_fraction(got)
    x = Fraction(exact)
    if x == 0:
        return 0.0 if g == 0 else math.inf
    ax = abs(x)
    ex = ax.numerator.bit_length() - ax.denominator.bit_length()
    # correct floor(log2) for exact rationals near powers of two
    while Fraction(2) ** ex > ax:
        ex -= 1
    while Fraction(2) ** (ex + 1) <= ax:
        ex += 1
    ex = max(ex, fmt.emin)
    ulp = Fraction(2) ** (ex - fmt.man_bits)
    return float(abs(g - x) / ulp)


def ordered_int(fmt: FPFormat, x: int) -> int:
    """Map float bits to a monotone integer line (for bitwise ULP distance)."""
    s = fmt.sign(x)
    mag = x & ((1 << (fmt.width - 1)) - 1)
    return -mag if s else mag


def ulp_distance(fmt: FPFormat, a: int, b: int) -> int:
    return abs(ordered_int(fmt, a) - ordered_int(fmt, b))
