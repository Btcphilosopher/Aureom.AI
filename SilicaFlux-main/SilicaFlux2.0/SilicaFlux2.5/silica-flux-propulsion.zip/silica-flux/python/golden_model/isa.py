"""
Silica Flux ISA definition (Python mirror of rtl/core/flux_pkg.sv).

Instruction word (64 bits):
  63:56 opcode | 55:51 vd | 50:46 vs1 | 45:41 vs2 | 40:36 vs3 |
  35:33 prec   | 32:30 rm | 29 masked | 28:23 vl  | 22:19 func | 18:0 imm
"""
from __future__ import annotations

from dataclasses import dataclass, field

# ---------------------------------------------------------------- opcodes
OPCODES = {
    "NOP": 0x00, "HALT": 0x01, "BARRIER": 0x02, "SETA": 0x03, "ADDA": 0x04, "BNZ": 0x05,
    "VADD": 0x10, "VSUB": 0x11, "VMUL": 0x12, "VFMA": 0x13, "VFMS": 0x14, "VFNMA": 0x15, "VFNMS": 0x16,
    "VSQR": 0x17, "VMIN": 0x18, "VMAX": 0x19, "VABS": 0x1A, "VNEG": 0x1B, "VCMP": 0x1C, "VSEL": 0x1D,
    "VMOV": 0x1E, "VCLASS": 0x1F, "VCVT": 0x20, "VBCAST": 0x21, "VLANEID": 0x22, "VMSET": 0x23, "VSLIDE": 0x24,
    "VDIV": 0x30, "VSQRT": 0x31, "VRECIP": 0x32, "VEXP": 0x33, "VLOG": 0x34,
    "VPOLY": 0x38, "VCUBE": 0x39, "VINTERP": 0x3A, "VREDUCE": 0x3C,
    "VLOAD": 0x40, "VSTORE": 0x41, "VLDBC": 0x42,
    "STATE_UPDATE": 0x50, "TSCFG": 0x51, "RESIDUAL": 0x52, "CONSERVE": 0x53,
    "OBJECTIVE": 0x60, "CONSTRAINT": 0x61, "SWEEP": 0x62, "SEARCH": 0x63,
}
OPNAMES = {v: k for k, v in OPCODES.items()}

PREC = {"FP32": 0, "FP64": 1, "SFIX": 2, "UFIX": 3, "INT": 4}
RM = {"RNE": 0, "RTZ": 1, "RDN": 2, "RUP": 3, "RMM": 4, "DYN": 7}

FU = {"CTRL": 0, "VALU": 1, "DIVSQRT": 2, "SFU": 3, "LSU": 4, "RED": 5, "POLY": 6, "INTERP": 7,
      "STATE": 8, "RESID": 9, "CONS": 10, "OBJ": 11, "CON": 12, "SWEEP": 13, "SEARCH": 14}

FU_OF = {}
for n in ("NOP", "HALT", "BARRIER", "SETA", "ADDA", "BNZ"):
    FU_OF[OPCODES[n]] = FU["CTRL"]
for n in ("VADD", "VSUB", "VMUL", "VFMA", "VFMS", "VFNMA", "VFNMS", "VSQR", "VMIN", "VMAX", "VABS", "VNEG",
          "VCMP", "VSEL", "VMOV", "VCLASS", "VCVT", "VBCAST", "VLANEID", "VMSET", "VSLIDE"):
    FU_OF[OPCODES[n]] = FU["VALU"]
FU_OF.update({OPCODES["VDIV"]: FU["DIVSQRT"], OPCODES["VSQRT"]: FU["DIVSQRT"],
              OPCODES["VRECIP"]: FU["SFU"], OPCODES["VEXP"]: FU["SFU"], OPCODES["VLOG"]: FU["SFU"],
              OPCODES["VPOLY"]: FU["POLY"], OPCODES["VCUBE"]: FU["POLY"], OPCODES["VINTERP"]: FU["INTERP"],
              OPCODES["VREDUCE"]: FU["RED"], OPCODES["VLOAD"]: FU["LSU"], OPCODES["VSTORE"]: FU["LSU"],
              OPCODES["VLDBC"]: FU["LSU"], OPCODES["STATE_UPDATE"]: FU["STATE"], OPCODES["TSCFG"]: FU["STATE"],
              OPCODES["RESIDUAL"]: FU["RESID"], OPCODES["CONSERVE"]: FU["CONS"],
              OPCODES["OBJECTIVE"]: FU["OBJ"], OPCODES["CONSTRAINT"]: FU["CON"],
              OPCODES["SWEEP"]: FU["SWEEP"], OPCODES["SEARCH"]: FU["SEARCH"]})

# func sub-codes
CMP = {"EQ": 0, "LT": 1, "LE": 2}
VMS = {"ALL": 0, "NZ": 1, "NOT": 2, "IMM": 3}
RED = {"SUM": 0, "MIN": 1, "MAX": 2, "SUMSQ": 3, "DOT": 4, "ARGMIN": 5, "ARGMAX": 6, "MAXABS": 7}
BAR = {"TELEM": 1, "DMA": 2, "SWAP": 4}
TS = {"EULER": 0, "HEUN": 1, "MIDPOINT": 2, "RALSTON": 3, "RK4": 4, "CUSTOM": 7, "RESET": 15}
SU_LOAD = 8
RES = {"SIGNED": 0, "ABS": 1, "MARGIN": 2}
CONS = {"CAPTURE": 0, "CHECK": 1, "CHECK_ADV": 2}
OBJ = {"WSUM": 0, "ABS": 1, "SQ": 2, "PENALTY": 3}
CON = {"LT": 0, "GT": 1, "EQ": 2, "TOL": 3, "LE": 4, "GE": 5}
SW = {"RESET": 0, "GEN": 1, "NEXT": 2}
SR = {"RESET": 0, "GRID": 1, "LOCAL": 2, "LS_GEN": 3}
MEM = {"STATE": 0, "STATE_N": 1, "PARAM": 2, "COEFF": 3, "SCRATCH": 4, "RESULT": 5, "TELEM": 6}

# quality bits
Q_NAN, Q_OVF, Q_UNF, Q_SUSPECT = 1, 2, 4, 8

# fault ids
FAULTS = ["WATCHDOG", "TIMEOUT", "ILLEGAL", "PRECISION", "NAN", "OVERFLOW", "UNDERFLOW", "DIVZERO",
          "RANGE", "PARITY", "MEMADDR", "TL_SEQ", "TL_CRC", "TL_TS", "TL_OVF", "CONSERVATION",
          "RESIDUAL", "PIPELINE", "STEP", "TL_MALFORMED", "UNINIT", "CONSTRAINT", "SEARCH", "HOST"]
F = {n: i for i, n in enumerate(FAULTS)}


@dataclass
class Instr:
    opcode: int
    vd: int = 0
    vs1: int = 0
    vs2: int = 0
    vs3: int = 0
    prec: int = 0
    rm: int = 0
    masked: int = 0
    vl: int = 0
    func: int = 0
    imm: int = 0
    comment: str = field(default="", compare=False)

    def encode(self) -> int:
        imm = self.imm & 0x7FFFF
        return ((self.opcode & 0xFF) << 56 | (self.vd & 31) << 51 | (self.vs1 & 31) << 46 |
                (self.vs2 & 31) << 41 | (self.vs3 & 31) << 36 | (self.prec & 7) << 33 |
                (self.rm & 7) << 30 | (self.masked & 1) << 29 | (self.vl & 63) << 23 |
                (self.func & 15) << 19 | imm)

    @staticmethod
    def decode(w: int) -> "Instr":
        return Instr(opcode=(w >> 56) & 0xFF, vd=(w >> 51) & 31, vs1=(w >> 46) & 31, vs2=(w >> 41) & 31,
                     vs3=(w >> 36) & 31, prec=(w >> 33) & 7, rm=(w >> 30) & 7, masked=(w >> 29) & 1,
                     vl=(w >> 23) & 63, func=(w >> 19) & 15, imm=w & 0x7FFFF)

    @property
    def simm(self) -> int:
        return self.imm - (1 << 19) if self.imm >> 18 else self.imm

    def __str__(self):
        n = OPNAMES.get(self.opcode, f"OP{self.opcode:02x}")
        return (f"{n:<13} vd={self.vd:<2} vs1={self.vs1:<2} vs2={self.vs2:<2} vs3={self.vs3:<2} "
                f"prec={self.prec} rm={self.rm} m={self.masked} vl={self.vl} func={self.func} imm={self.imm}")


def src_use(i: Instr) -> int:
    """bit0 vs1, bit1 vs2, bit2 vs3, bit3 VM -- mirror of flux_pkg::src_use"""
    o = OPNAMES.get(i.opcode, "")
    u = 0
    if o in ("VADD", "VSUB", "VMUL", "VMIN", "VMAX", "VDIV", "VCMP", "VPOLY"):
        u = 0b0011
    elif o in ("VFMA", "VFMS", "VFNMA", "VFNMS", "VINTERP", "RESIDUAL"):
        u = 0b0111
    elif o == "OBJECTIVE":
        u = 0b0111 if (i.func & 3) in (OBJ["ABS"], OBJ["SQ"]) else 0b0101
    elif o == "CONSTRAINT":
        u = 0b0111 if i.func == CON["TOL"] else 0b0011
    elif o in ("VSQR", "VABS", "VNEG", "VMOV", "VCLASS", "VCVT", "VBCAST", "VSLIDE", "VSQRT", "VRECIP", "VEXP",
               "VLOG", "VCUBE", "TSCFG", "VSTORE", "STATE_UPDATE"):
        u = 0b0001
    elif o == "VSEL":
        u = 0b1011
    elif o == "VMSET":
        u = 0b0001 if i.func == VMS["NZ"] else (0b1000 if i.func == VMS["NOT"] else 0)
    elif o == "VREDUCE":
        u = 0b0011 if i.func == RED["DOT"] else 0b0001
    elif o == "CONSERVE":
        u = 0b0011 if i.func == CONS["CAPTURE"] else 0b0111
    elif o == "SEARCH":
        u = 0b1001 if i.func in (SR["GRID"], SR["LOCAL"]) else 0
    if i.masked:
        u |= 0b1000
    return u


def writes_vd(i: Instr) -> bool:
    o = OPNAMES.get(i.opcode, "")
    if o in ("NOP", "HALT", "BARRIER", "SETA", "ADDA", "BNZ", "VSTORE", "VMSET", "TSCFG", ""):
        return False
    if o == "SWEEP":
        return i.func == SW["GEN"]
    if o == "SEARCH":
        return i.func == SR["LS_GEN"]
    return True


def writes_vm(i: Instr) -> bool:
    o = OPNAMES.get(i.opcode, "")
    if o in ("VCMP", "VMSET", "CONSTRAINT", "RESIDUAL"):
        return True
    if o == "SWEEP":
        return i.func == SW["GEN"]
    if o == "SEARCH":
        return i.func == SR["LS_GEN"]
    return False


def pack_uop(i: Instr, pc: int = 0, tag: int = 0, rm: int | None = None) -> int:
    """flux_pkg::uop_t = {ins[64], pc[16], tag[4], fu[4], rm[3], wr_vd, wr_vm} (93 bits)"""
    fu = FU_OF.get(i.opcode, 15)
    rmv = i.rm if rm is None else rm
    return (i.encode() << 29 | (pc & 0xFFFF) << 13 | (tag & 15) << 9 | (fu & 15) << 5 |
            (rmv & 7) << 2 | int(writes_vd(i)) << 1 | int(writes_vm(i)))


def unpack_uop(u: int):
    return dict(ins=Instr.decode(u >> 29), pc=(u >> 13) & 0xFFFF, tag=(u >> 9) & 15, fu=(u >> 5) & 15,
                rm=(u >> 2) & 7, wr_vd=(u >> 1) & 1, wr_vm=u & 1)
