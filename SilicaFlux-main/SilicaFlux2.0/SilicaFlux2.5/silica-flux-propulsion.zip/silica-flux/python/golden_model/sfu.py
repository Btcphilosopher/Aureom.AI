"""
Silica Flux golden model -- special-function unit (SFU) approximations.

These are *bit-exact* models of the RTL algorithms in rtl/alu/reciprocal_unit.sv,
rtl/math/exp_unit.sv and rtl/math/log_unit.sv.  They use the same fixed-point
widths, the same tables (generated from this module) and the same rounding of
every intermediate product (round-half-up: (v + 2^(s-1)) >> s, floor semantics
for negative values -- identical to an arithmetic shift in the RTL).

Accuracy is NOT claimed by construction: python/generators/gen_sfu_tables.py
measures max / mean / RMS error against high-precision references and the
results are published in docs/numerical_model.md.  All SFU results are
rounded to nearest-even; the instruction rounding mode is ignored for these
approximate functions (documented ISA behaviour).

Algorithms
----------
reciprocal  table seed on the top TB fraction bits (midpoint reciprocal),
            then N Newton-Raphson iterations  y <- y (2 - m y)  in Q.F fixed
            point;  1/x = y 2^-F 2^-e.
exp         x -> fixed point (FX fractional bits);  y = x log2(e);
            y = k + f;  2^f = T[j] * P(t), j = top SEG bits of f, t the
            centred remainder;  P = Taylor series of 2^t (degree D, Horner);
            exp(x) = 2^k 2^f  (Tang's table-driven method).
log         x = 2^e m;  m in segment j with centre c_j;  u = (m - c_j)/c_j
            using a reciprocal table R_j;  log(x) = e ln2 + ln(c_j) + log(1+u),
            log(1+u) = u Q(u).  The two segments adjacent to x = 1 are
            centred exactly on 1 and 2 so that e ln2 + ln c_j cancels exactly
            and u Q(u) is evaluated in *relative* precision (no catastrophic
            cancellation near x = 1).
"""
from __future__ import annotations

from decimal import Decimal, getcontext

from golden_model.ieee import FP32, FP64, FPFormat, NV, DZ, OF, UF, NX, RNE, round_pack

getcontext().prec = 80

SFU_PARAMS = {
    "fp32": dict(recip_tb=7, recip_f=32, recip_iter=2,
                 exp_fx=34, exp_ib=7, exp_lf=36, exp_seg=5, exp_deg=3,
                 log_f=36, log_seg=6, log_deg=4),
    "fp64": dict(recip_tb=7, recip_f=62, recip_iter=3,
                 exp_fx=64, exp_ib=10, exp_lf=66, exp_seg=6, exp_deg=6,
                 log_f=68, log_seg=7, log_deg=7),
}


def rshr(v: int, s: int) -> int:
    """round-half-up arithmetic right shift (matches RTL '+ half, >>>')"""
    if s <= 0:
        return v << (-s)
    return (v + (1 << (s - 1))) >> s


def dround(d: Decimal) -> int:
    return int(d.to_integral_value(rounding="ROUND_HALF_EVEN"))


# =============================================================================
# Tables
# =============================================================================
class Tables:
    def __init__(self, fmt: FPFormat):
        p = SFU_PARAMS[fmt.name]
        self.p = p
        D2 = Decimal(2)
        ln2 = D2.ln()
        log2e = 1 / ln2
        # reciprocal seeds: 2^F / (1 + (i + 0.5)/2^TB)
        tb, F = p["recip_tb"], p["recip_f"]
        self.recip_T = [dround((D2 ** F) * (D2 ** (tb + 1)) / (D2 ** (tb + 1) + 2 * i + 1)) for i in range(1 << tb)]
        # exp
        fx, seg, deg = p["exp_fx"], p["exp_seg"], p["exp_deg"]
        self.exp_L = dround(log2e * D2 ** p["exp_lf"])
        self.exp_T = [dround((D2 ** ((Decimal(j) + Decimal("0.5")) / D2 ** seg)) * D2 ** fx) for j in range(1 << seg)]
        fact = 1
        self.exp_A = []
        for i in range(deg + 1):
            if i > 0:
                fact *= i
            self.exp_A.append(dround((ln2 ** i) / fact * D2 ** fx))
        # log
        F, seg, deg = p["log_f"], p["log_seg"], p["log_deg"]
        self.log_LN2 = dround(ln2 * D2 ** F)
        self.log_L, self.log_R = [], []
        for j in range(1 << seg):
            if j == 0:
                c = Decimal(1)
            elif j == (1 << seg) - 1:
                c = Decimal(2)
            else:
                c = 1 + (Decimal(2 * j + 1) / D2 ** (seg + 1))
            self.log_L.append(self.log_LN2 if j == (1 << seg) - 1 else dround(c.ln() * D2 ** F))
            self.log_R.append(dround(D2 ** F / c))
        self.log_Q = [dround(Decimal((-1) ** i) / (i + 1) * D2 ** F) for i in range(deg + 1)]


_TABLES: dict[str, Tables] = {}


def tables(fmt: FPFormat) -> Tables:
    if fmt.name not in _TABLES:
        _TABLES[fmt.name] = Tables(fmt)
    return _TABLES[fmt.name]


def _norm(fmt: FPFormat, x: int):
    """finite non-zero x -> (sign, m_n (MSB at bit M), e (exponent of MSB))"""
    s, m, e_lsb = fmt.unpack(x)
    sh = fmt.p - m.bit_length()
    return s, m << sh, e_lsb + fmt.man_bits - sh


# =============================================================================
# Reciprocal
# =============================================================================
def recip(fmt: FPFormat, x: int):
    if fmt.is_nan(x):
        return fmt.qnan(), NV if fmt.is_snan(x) else 0
    s = fmt.sign(x)
    if fmt.is_zero(x):
        return fmt.inf(s), DZ
    if fmt.is_inf(x):
        return fmt.zero(s), 0
    t = tables(fmt)
    p = t.p
    M, F, TB = fmt.man_bits, p["recip_f"], p["recip_tb"]
    s, mn, e = _norm(fmt, x)
    if mn == (1 << M):
        return round_pack(fmt, s, 1, -e, False, RNE)
    idx = (mn >> (M - TB)) & ((1 << TB) - 1)
    y = t.recip_T[idx]
    mf = mn << (F - M)
    for _ in range(p["recip_iter"]):
        tt = rshr(mf * y, F)
        d = (2 << F) - tt
        y = rshr(y * d, F)
    return round_pack(fmt, s, y, -F - e, True, RNE)


# =============================================================================
# Exponential
# =============================================================================
def exp(fmt: FPFormat, x: int):
    if fmt.is_nan(x):
        return fmt.qnan(), NV if fmt.is_snan(x) else 0
    s = fmt.sign(x)
    if fmt.is_inf(x):
        return (fmt.zero(0), 0) if s else (fmt.inf(0), 0)
    if fmt.is_zero(x):
        return fmt.one(), 0
    t = tables(fmt)
    p = t.p
    FX, IB, LF, SEG, DEG = p["exp_fx"], p["exp_ib"], p["exp_lf"], p["exp_seg"], p["exp_deg"]
    _, m, e_lsb = fmt.unpack(x)
    if e_lsb + m.bit_length() - 1 >= IB:          # |x| >= 2^IB
        return (fmt.zero(0), UF | NX) if s else (fmt.inf(0), OF | NX)
    X = rshr(m, -(e_lsb + FX))
    if s:
        X = -X
    Y = rshr(X * t.exp_L, LF)
    k = Y >> FX
    f = Y - (k << FX)
    j = f >> (FX - SEG)
    tt = (f & ((1 << (FX - SEG)) - 1)) - (1 << (FX - SEG - 1))
    acc = t.exp_A[DEG]
    for i in range(DEG - 1, -1, -1):
        acc = rshr(acc * tt, FX) + t.exp_A[i]
    mant = rshr(t.exp_T[j] * acc, FX)
    return round_pack(fmt, 0, mant, k - FX, True, RNE)


# =============================================================================
# Natural logarithm
# =============================================================================
def log(fmt: FPFormat, x: int):
    if fmt.is_nan(x):
        return fmt.qnan(), NV if fmt.is_snan(x) else 0
    if fmt.is_zero(x):
        return fmt.inf(1), DZ
    if fmt.sign(x):
        return fmt.qnan(), NV
    if fmt.is_inf(x):
        return x, 0
    t = tables(fmt)
    p = t.p
    M, F, SEG, DEG = fmt.man_bits, p["log_f"], p["log_seg"], p["log_deg"]
    _, mn, e = _norm(fmt, x)
    if mn == (1 << M) and e == 0:
        return fmt.zero(0), 0
    mf = mn << (F - M)
    j = (mn >> (M - SEG)) & ((1 << SEG) - 1)
    if j == 0:
        U = mf - (1 << F)
    elif j == (1 << SEG) - 1:
        U = (mf - (2 << F)) >> 1
    else:
        C = (1 << F) + ((2 * j + 1) << (F - SEG - 1))
        U = rshr((mf - C) * t.log_R[j], F)
    B = e * t.log_LN2 + t.log_L[j]
    acc = t.log_Q[DEG]
    for i in range(DEG - 1, -1, -1):
        acc = rshr(acc * U, F) + t.log_Q[i]
    if B == 0:
        prod = abs(U) * acc
        return round_pack(fmt, int(U < 0), prod, -2 * F, True, RNE)
    S = B + rshr(U * acc, F)
    return round_pack(fmt, int(S < 0), abs(S), -F, True, RNE)


SFU_FUNCS = {"recip": recip, "exp": exp, "log": log}
