# SILICA FLUX

**A synthesizable, verified numerical-computing fabric for engineering simulation and digital twins.**

Silica Flux is a SystemVerilog accelerator for the arithmetic at the heart of
propulsion-system analysis and other engineering simulation: explicit
integration of ODE systems, residual and conservation monitoring against
live telemetry, and design-space exploration. It provides correctly rounded
IEEE-754 arithmetic with first-class fused multiply-add, hardware
approximations with documented error, vector lanes with explicit precision
metadata, and a fault model in which nothing goes wrong silently.

> **Scope.** Silica Flux is an analysis tool, not a control computer. It
> contains no engine geometry, combustion chemistry or vehicle logic and
> commands no hardware. Physical models are host-supplied programs over
> abstract state vectors; the silicon evaluates them exactly as written and
> reports the quality of every number it produces.

```mermaid
flowchart LR
  subgraph Host
    API["Python API<br/>silica_flux.FluxEngine"]
  end
  subgraph Chip["silica_flux_top"]
    CSR["AXI4-Lite CSRs<br/>fault manager, watchdog"]
    CORE["flux_core<br/>in-order issue, 14 units,<br/>in-order retirement"]
    MEM[("STATE / PARAM / COEFF /<br/>SCRATCH / RESULT / TELEM")]
    TEL["telemetry ingest<br/>CRC, sequence, timestamp, range"]
    DMA["DMA<br/>AXI4-Stream"]
  end
  API -- programs, config --> CSR
  API -- data, telemetry --> DMA
  DMA --> MEM
  DMA --> TEL --> MEM
  CORE <--> MEM
  CORE -- faults --> CSR
  DMA -- results + quality --> API
```

## What is in the box

| Area | Content |
|---|---|
| Arithmetic | IEEE-754 FP32 / FP64 (one native format per build), five rounding modes, full subnormals, exact flags; FMA as the core primitive (single rounding); correctly rounded divide and square root; fixed-point and integer with saturation |
| Approximations | reciprocal, exp, log (≤ 0.51 ULP), x², x³, Horner polynomials, table interpolation — domain, range, max / mean / RMS error and latency documented in `docs/numerical_model.md` |
| Vector engine | 8 / 16 / 32 lanes, valid/ready on every stage, masks and partial vectors, deterministic reductions |
| Simulation engines | timestep engine (Euler, Heun, midpoint, Ralston, RK4, custom tableau), state update, residual, conservation checker |
| Optimisation engines | objective, constraint, parameter sweep, grid arg-min, compass search |
| Data model | 4 quality bits per element (NaN / overflow / underflow / suspect), register metadata (valid, precision, scale, source, timestamp), no implicit format conversion |
| Telemetry | 3-beat packets with CRC-16, per-channel sequence and timestamp checks, range bounds, drop/overflow accounting |
| Safety | 24 fault sources, first-fault capture with PC and timestamp, halt mask, parity on all memories, progress / DMA watchdogs; `START` re-initialises job state |
| Host | `from silica_flux import FluxEngine` with reference, RTL and cross-checking backends |

## Results

All figures below are produced by the flow in this repository
(`make test formal benchmark synth report`) and collected by
`python/analysis/report.py` into `reports/SILICA_FLUX_REPORT.md`. Clock
frequencies are **assumed** for estimation; no timing closure is claimed.

| Section | Status | Result |
|---|---|---|
| **RTL TESTS** | PASS | 18/18 cocotb unit configurations · 12/12 SV testbenches on Verilator (SVA on) and 12/12 on Icarus · 180/180 full-chip scenarios on Verilator (5 configurations, SVA on) · 61/61 full-chip programs on Icarus (cocotb) · lint: 0 functional warnings |
| **NUMERICAL VALIDATION** | PASS | 1.5 M golden-model operations vs host FPU, 75,067 RTL transactions + 5,026 SV vectors x 2 simulators: 0 mismatches (value, flags, quality) |
| **MAX NUMERICAL ERROR** |  | ADD/MUL/FMA/DIV/SQRT correctly rounded (≤ 0.5 ULP RNE); recip/exp/log ≤ 0.507 ULP; x³ ≤ 1.20 ULP; degree-5 Horner ≤ 1.63 ULP; interpolation ≤ 0.50 ULP |
| **THROUGHPUT** |  | FMA stream 5.2 / 10.4 / 20.8 FLOP/cycle at 8 / 16 / 32 lanes (measured; 36.5 % of peak) = 1.3 / 2.6 / 5.2 GFLOP/s at an *assumed* 250 MHz; analytical model within -8.4 … +6.6 % of measured cycles (32-lane config held out) |
| **PIPELINE LATENCY** |  | FMA/VALU = PIPELINE_DEPTH (4–6), one op/cycle; DIV/SQRT 29 (FP32) / 58 (FP64) cycles at 1 bit/cycle, 16 / 31 at 2 bits/cycle; recip 7/9, exp 8/11, log 9/12 (FP32/FP64) |
| **RESOURCE ESTIMATE** |  | small FPGA (8L FP32): 272 k LUT, 70 k FF, 431 DSP, 213 Kbit RAM · large FPGA (32L FP32, lane-scaled): 1,009 k LUT, 298 k FF, 1,700 DSP, 1,693 Kbit RAM · ASIC (16L FP64, lane-scaled): 8.29 M generic cells (≈ 59 M transistors), 1,031 Kbit SRAM — Yosys, pre-place-and-route |
| **FAULT TESTS** | PASS | 80/80 full-chip fault and telemetry-anomaly scenarios bit-exact incl. fault record · tb_faults PASS · job isolation 6/6 |
| **FORMAL** | PASS | 4 harnesses proven by k-induction, 4 bounded (depth 12–14) |

## Quick start

Requirements: Python ≥ 3.11 with `numpy scipy pandas pydantic matplotlib cocotb`,
Verilator ≥ 5.0, Icarus Verilog ≥ 12, `yowasp-yosys yowasp-sby` (or native
Yosys / SymbiYosys) and z3, R ≥ 4 (base packages only).

```bash
make quick        # golden self-test + Verilator SV testbenches + directed/fault full-chip scenarios
make test         # everything that simulates, then the report
make formal       # formal harnesses
make lint         # Verilator -Wall, all synthesis configurations
make benchmark    # measured performance + analytical model validation
make synth        # Yosys elaboration checks + resource estimates
make r            # R statistics and figures (reports/figures)
make dashboard    # engineering display -> reports/dashboard.html
make report       # final summary
```

### Python API

```python
import sys; sys.path.insert(0, "python")
from silica_flux import FluxEngine
from silica_flux.models import Quantity

engine = FluxEngine(lanes=8, precision="FP32", backend="both")   # reference model AND RTL, cross-checked
job = engine.create_job(state=Quantity(values=[300.0 + 0.5 * i for i in range(8)], unit="K"),
                        timestep=2.5, steps=24, method="RK4")
result = engine.run(job)

result.new_state.values        # propagated state
result.new_state.quality       # per-element quality bits (NaN / OVF / UNF / SUSPECT)
result.conservation            # invariant, expected, residual, threshold
result.diagnostics["faults"]   # faults recorded by the hardware
result.verification["status"]  # "MATCH": RTL bit-identical to the reference model
```

Units are checked (`Quantity`): a parameter with the wrong dimensions is
rejected before anything runs. The end-to-end example
(`python3 python/examples/end_to_end.py --backend both`) propagates an 8-node
thermal network with RK4, compares it with injected telemetry (one faulty
sensor), checks energy conservation every step, then runs a 64-candidate
design sweep and a hardware compass search — all bit-exact between the RTL
and the reference model.

## Repository layout

```
rtl/            synthesizable SystemVerilog
  top/ core/ alu/ math/ vector/ memory/ simulation/ optimisation/
  telemetry/ interconnect/ safety/          (rtl/sources.f lists the compile order)
tb/             self-checking SV testbenches (Verilator + Icarus) and the system testbench tb_top.sv
python/
  golden_model/       bit-exact IEEE, VALU, SFU, engine and telemetry models (+ selftest vs host FPU)
  reference_model/    instruction-accurate ISA simulator, scenarios, system regression
  generators/         stimulus, assembler, programs, SFU tables, SV vector files
  cocotb/             cocotb regressions (units and full chip) on Icarus
  silica_flux/        host API: FluxEngine, driver, register map, RTL backend, workloads
  analysis/           report, dashboard, benchmark, performance model, accuracy
  examples/           end_to_end.py
r/              statistics.R, validation.R (error, residuals, Monte Carlo, sensitivity), benchmark.R
formal/         properties.sv (formal harnesses), assertions.sv (bound SVA), run_formal.py
synthesis/      configs.json, constraints/, run_synth.py, reports/
verilator/      lint flow and waivers          iverilog/  full-chip compile script
firmware/       instruction_set.md, register_map.md
docs/           architecture, microarchitecture, numerical_model, verification, performance, synthesis
reports/        generated results (JSON / CSV / figures / dashboard)
```

## Documentation

| Document | Content |
|---|---|
| [docs/architecture.md](docs/architecture.md) | system organisation, data model, execution model |
| [docs/microarchitecture.md](docs/microarchitecture.md) | pipelines, scoreboard, FMA datapath, engines, memories |
| [docs/numerical_model.md](docs/numerical_model.md) | formats, rounding, error of every approximation |
| [firmware/instruction_set.md](firmware/instruction_set.md) | the Flux ISA |
| [firmware/register_map.md](firmware/register_map.md) | CSRs, faults, telemetry packet format |
| [docs/verification.md](docs/verification.md) | verification layers and coverage |
| [docs/performance.md](docs/performance.md) | measured performance and the analytical model |
| [docs/synthesis.md](docs/synthesis.md) | synthesis configurations and resource estimates |

## Licence

MIT — see [LICENSE](LICENSE).
