# Silica Flux — Synthesis

All RTL is written for synthesis: synchronous single-clock design, synchronous
active-low reset, no latches, no initial blocks in the synthesis path
(`` `ifndef SYNTHESIS `` guards simulation-only initialisation), memories in
row-organised single-port form that maps to block RAM / SRAM macros.

**Every figure in this document is a pre-implementation estimate** from Yosys
0.71 (YoWASP build). No vendor place-and-route, timing closure or power
analysis has been performed; clock frequencies are *targets*, not results.

## 1. Configurations (`synthesis/configs.json`)

| Config | VECTOR_LANES | FP_MODE | DATA_WIDTH | PIPELINE_DEPTH | SCRATCHPAD_SIZE | DIV_BPC | Target | Clock (target) | Constraints |
|---|---|---|---|---|---|---|---|---|---|
| `small_fpga` | 8 | 0 (FP32) | 32 | 4 | 128 | 1 | Xilinx 7-series / UltraScale | 100 MHz | `constraints/small_fpga.xdc` |
| `large_fpga` | 32 | 0 (FP32) | 32 | 6 | 1024 | 2 | Xilinx UltraScale+ | 250 MHz | `constraints/large_fpga.xdc` |
| `asic` | 16 | 1 (FP64) | 64 | 5 | 512 | 2 | generic CMOS | 1 GHz | `constraints/silica_flux_asic.sdc` |

## 2. Flow (`synthesis/run_synth.py`)

```mermaid
flowchart LR
  SRC["rtl/sources.f"] --> CHK["--check: full-chip read,<br/>hierarchy, proc, check -assert,<br/>latch detection"]
  SRC --> BLK["per block at the config's parameters:<br/>FPGA: synth_xilinx -flatten<br/>ASIC: synth -flatten; abc; stat -tech cmos"]
  BLK --> SUM["sum x instance count"]
  MEMS["memory depths x widths<br/>(value + quality + parity)"] --> BR["36 Kbit BRAM / SRAM Kbit"]
  SUM & BR --> REP["reports/synth/&lt;config&gt;.json<br/>synthesis/reports/"]
```

1. **Elaboration check** — the complete chip for each configuration passes
   `hierarchy -check`, `proc` and `check -assert` (no undriven or
   multiply-driven nets) with **zero inferred latches**.
2. **Logic estimate** — each functional block is synthesized on its own at the
   configuration's parameters and the results are summed. A block that
   exceeds the per-block time limit is listed as excluded; nothing is
   extrapolated.
3. **Memories** — counted in bits from the configuration and mapped to 36 Kbit
   block RAMs (FPGA) or SRAM macros (ASIC). The 3-read/1-write vector register
   file is synthesized as logic (LUT-RAM on FPGA).
4. **Lane scaling for the wide builds.** A 32-lane FP32 or 16-lane FP64
   block takes from tens of minutes to hours in the WebAssembly Yosys used
   here, so the wide configurations are synthesized narrower and scaled:
   every block keeps the configuration's number format, pipeline depth and
   divider radix; blocks whose logic is a per-lane datapath are multiplied by
   `VECTOR_LANES / lanes_synthesized`, control blocks are taken as measured.
   Exact commands:

   ```bash
   python3 synthesis/run_synth.py small_fpga                       # full width, no scaling
   python3 synthesis/run_synth.py large_fpga --lane-scale=8        # 8 lanes x 4
   python3 synthesis/run_synth.py asic --lane-scale=8              # FP64 8-lane blocks that finish in time
   python3 synthesis/run_synth.py asic --lane-scale=2 --prefer-lanes=8 --quick-abc=vector_alu,sfu_array
   python3 synthesis/run_synth.py --check                          # full-chip elaboration, all configs
   ```

   The scaling is checked against a block synthesized at full width
   (`scaling_check`: 1.00 for the 32-lane divide/sqrt array, 0.999 for the
   16-lane FP64 one) and, for the ASIC, between 8-lane and 2-lane syntheses
   (`linearity_check_8_vs_2_lanes`). The two largest FP64 blocks use a
   minimal ABC mapping that was measured at +10 % against the default flow.
5. Not included: top-level CSR/glue logic and AXI-Stream slices (small).

### Constructs fixed for synthesis

The elaboration check found two constructs that both simulators accepted but
Yosys mis-elaborated; both were rewritten and re-verified:

| Construct | Effect in Yosys | Fix |
|---|---|---|
| packed arrays of struct typedefs (`uop_t [N-1:0]`, `meta_t [N-1:0]`) in port connections | element select sized as one bit → 90 + 78 undriven µop bits | 2-D packed `logic [N-1:0][UOP_W-1:0]` |
| 2-D array declared inside a generate block, indexed by genvar (FMA output slices) | "failed to detect width" | module-scope flat vector with `+:` slices |

## 3. Results

### small_fpga (8 lanes, FP32)

| Block | LUT | FF | DSP |
|---|---|---|---|
| vector ALU (8 FMA lanes + compare/convert) | 32,650 | 4,904 | 96 |
| divide / square root array | 8,745 | 2,328 | 0 |
| special-function array (recip / exp / log) | 25,214 | 5,824 | 168 |
| reduction | 13,167 | 3,457 | 16 |
| polynomial | 14,107 | 4,070 | 16 |
| interpolation | 17,438 | 4,763 | 16 |
| state update + timestep engine | 17,000 | 4,994 | 18 |
| residual | 15,307 | 4,861 | 16 |
| conservation | 15,799 | 5,074 | 18 |
| objective | 22,193 | 6,095 | 16 |
| constraint | 13,973 | 4,195 | 0 |
| parameter sweep | 15,780 | 4,062 | 28 |
| search | 21,331 | 6,022 | 12 |
| telemetry buffer | 23,176 | 1,523 | 8 |
| telemetry ingest | 3,786 | 2,511 | 0 |
| retirement | 4,901 | 765 | 0 |
| register file (LUT-RAM) | 4,089 | 2,480 | 1 |
| scheduler, dispatch, LSU, bus, DMA, fault manager, AXI-Lite, timestamp | 3,447 | 1,895 | 2 |
| **total logic** | **272,103** | **69,733** | **431** |
| memories | 213 Kbit → ~10 × BRAM36 | | |

### large_fpga (32 lanes, FP32, depth 6, 2 bits/cycle divider) — lane-scaled

| Block | LUT as synthesized (8 lanes) | scale | LUT @ 32 lanes |
|---|---|---|---|
| vector_alu | 32,653 | x4 | 130,612 |
| div_sqrt_array | 9,839 | x4 | 39,356 |
| sfu_array | 25,164 | x4 | 100,656 |
| reduction | 13,231 | x4 | 52,924 |
| polynomial | 14,228 | x4 | 56,912 |
| interpolation | 17,520 | x4 | 70,080 |
| state_update | 17,034 | x4 | 68,136 |
| residual | 15,346 | x4 | 61,384 |
| conservation | 15,721 | x4 | 62,884 |
| objective | 22,077 | x4 | 88,308 |
| constraint | 14,036 | x4 | 56,144 |
| sweep | 15,843 | x4 | 63,372 |
| search | 21,376 | x4 | 85,504 |
| lsu | 439 | x4 | 1,756 |
| scheduler | 1,008 | x1 | 1,008 |
| retirement | 4,901 | x4 | 19,604 |
| telemetry_ingest | 3,786 | x1 | 3,786 |
| dma | 264 | x4 | 1,056 |
| fault_manager | 239 | x1 | 239 |
| axi_lite | 14 | x1 | 14 |
| register_file | 4,089 | x4 | 16,356 |
| dispatch | 40 | x1 | 40 |
| internal_bus | 1,312 | x4 | 5,248 |
| telemetry_buffer | 23,176 | x1 | 23,176 |
| timestamp | 131 | x1 | 131 |
| **total** | | | **1,008,686 LUT, 297,505 FF, 1,700 DSP, 61,089 CARRY** |

Memories: 1,693.0 Kbit (≈ 51 BRAM36; the 1024-row scratchpad dominates). Scaling check: `div_sqrt_array` full-width 39,344 vs scaled 39,356 (ratio 1.00).

### asic (16 lanes, FP64, depth 5, 2 bits/cycle divider) — lane-scaled

| Block | lanes synthesized | cells as synthesized | scale | cells @ 16 lanes |
|---|---|---|---|---|
| vector_alu * | 2 | 163,082 | x8 | 1,304,656 |
| div_sqrt_array | 8 | 66,354 | x2 | 132,708 |
| sfu_array * | 2 | 242,473 | x8 | 1,939,784 |
| reduction | 8 | 218,973 | x2 | 437,946 |
| polynomial | 8 | 227,927 | x2 | 455,854 |
| interpolation | 8 | 240,023 | x2 | 480,046 |
| state_update | 8 | 264,765 | x2 | 529,530 |
| residual | 2 | 59,466 | x8 | 475,728 |
| conservation | 2 | 84,200 | x8 | 673,600 |
| objective | 2 | 68,731 | x8 | 549,848 |
| constraint | 2 | 22,353 | x8 | 178,824 |
| sweep | 2 | 44,709 | x8 | 357,672 |
| search | 2 | 41,000 | x8 | 328,000 |
| lsu | 2 | 830 | x8 | 6,640 |
| scheduler | 2 | 3,894 | x1 | 3,894 |
| retirement | 2 | 12,164 | x8 | 97,312 |
| telemetry_ingest | 2 | 26,285 | x1 | 26,285 |
| dma | 2 | 1,092 | x8 | 8,736 |
| fault_manager | 2 | 768 | x1 | 768 |
| axi_lite | 2 | 108 | x1 | 108 |
| register_file | 2 | 30,277 | x8 | 242,216 |
| dispatch | 2 | 171 | x1 | 171 |
| internal_bus | 2 | 1,984 | x8 | 15,872 |
| telemetry_buffer | 2 | 46,978 | x1 | 46,978 |
| timestamp | 2 | 772 | x1 | 772 |
| **total** | | | | **8,293,948 generic cells, ≈ 59 M transistors (Yosys CMOS estimate)** |

\* minimal ABC mapping (`--quick-abc`), calibrated at +10 % against the default flow.

Linearity check (8-lane synthesis vs 2-lane synthesis x 4): div_sqrt_array 0.996, interpolation 1.038, polynomial 1.002, reduction 1.000, state_update 0.711. `state_update` (0.711) shows why blocks with scalar logic are taken from the 8-lane synthesis where available; `conservation` (2-lane data only, contains a scalar divider) is therefore an upper bound.

Memories: 1,031.0 Kbit of SRAM macros. Scaling check: `div_sqrt_array` full-width 132,610 vs scaled 132,708 (ratio 1.00). Cell counts are technology-independent Yosys gates (`stat -tech cmos` transistor estimate); a standard-cell library, area and timing are not part of this repository.


## 4. Reading the numbers

* **The engines dominate.** Each of the ten multi-cycle engines owns a full
  `VECTOR_LANES`-wide FMA array (≈ 13–22 k LUT each at 8 lanes) although at
  most a few are active at once (`fu_utilisation.csv`). The 8-lane FP32 build
  therefore needs ≈ 270 k LUT — a large Kintex-7 / UltraScale device, not an
  Artix-class part.
* **First area optimisation:** share two or three FMA arrays among the
  engines through an arbiter (the engines already drive their arrays through
  a valid/ready interface). As a rough guide, the constraint engine — little
  more than its array — is 14 k LUT, so reducing ten arrays to three would
  remove on the order of 70–100 k LUT (~30 % of the total). The cost is
  bounded by the measured unit utilisation (`reports/benchmark/fu_utilisation.csv`):
  reduction and polynomial units reach 45–50 % busy in the mixed kernel, every
  other engine stays below 17 % in all benchmark kernels.
* **Telemetry buffer:** the per-channel sample table is held in flip-flops
  with a wide read multiplexer (23 k LUT); mapping it to a block RAM is the
  second optimisation.
* DSP usage is low because Yosys maps only the significand multipliers to
  DSP48 blocks; the alignment / normalisation shifters stay in LUTs.
* **The 32-lane FPGA build (≈ 1.0 M LUT)** would fill the largest
  UltraScale+ parts; with shared engine FMA arrays it becomes a realistic
  VU9P-class design. The 1024-row scratchpad dominates its 1.7 Mbit of RAM.
* **The 16-lane FP64 ASIC build (≈ 8.3 M generic cells)** is dominated by the
  special-function array and the vector ALU (the 53-bit significand
  datapaths), followed by the engines' FMA arrays — the same sharing argument
  applies. Cell counts are technology-independent; no area or power figure
  is derived from them.

## 5. Timing intent

The constraint files describe the intended clocks; the RTL structures were
chosen for them (FMA split into four elastic stages plus optional retiming
slices via `PIPELINE_DEPTH`, digit-recurrence dividers, registered memory
outputs, skid buffers on the AXI4-Stream ports and a registered AXI4-Lite
slave). Whether a given device meets
100 / 250 MHz, or a given library meets 1 GHz, is **not** established by this
repository.
