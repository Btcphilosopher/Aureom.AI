# Silica Flux — Architecture

Silica Flux is a deterministic, synthesizable numerical-computing fabric for
engineering simulation and digital-twin workloads: explicit time integration
of ODE systems, residual and conservation monitoring against live telemetry,
and design-space exploration (parameter sweeps, constrained objectives,
pattern search).

**Scope.** Silica Flux is an *accelerator for analysis*, not a control
computer. It never commands hardware, contains no engine geometry, no
combustion chemistry and no vehicle-specific logic. Every physical model is a
host-supplied program over abstract state vectors; the silicon only provides
correctly-rounded arithmetic, integration, monitoring and search primitives.

## 1. Top-level organisation

```mermaid
flowchart TB
  subgraph HOST["Host (Python API, firmware)"]
    API["silica_flux.FluxEngine"]
  end
  subgraph CP["Control plane"]
    AXIL["AXI4-Lite CSRs<br/>axi_lite_slave"]
    FM["fault_manager<br/>24 fault sources"]
    WD["watchdog<br/>progress + DMA"]
    IRQ["interrupts"]
  end
  subgraph CF["Compute fabric: flux_core"]
    FE["fetch + decode queue"] --> SCH["scheduler<br/>legality, precision, RAW/WAW"]
    SCH --> RR["register read<br/>32 x L x (W+Q)"]
    RR --> DISP["dispatch"]
    DISP --> VP["vector_pipeline<br/>VALU, FMA, DIV/SQRT, SFU"]
    DISP --> LSU["LSU"]
    DISP --> MATH["reduction, polynomial,<br/>interpolation"]
    DISP --> SIM["state_update + timestep,<br/>residual, conservation"]
    DISP --> OPT["objective, constraint,<br/>sweep, search"]
    VP & LSU & MATH & SIM & OPT --> RET["retirement<br/>in-order commit, flags, faults"]
  end
  subgraph MS["Memory system"]
    BUS["internal_bus<br/>core > DMA > host"]
    ST[("STATE ping-pong")]
    PA[("PARAM")]
    CO[("COEFF")]
    SC[("SCRATCH")]
    RE[("RESULT")]
    TT[("TELEM table")]
  end
  subgraph TL["Telemetry path"]
    ING["telemetry_ingest<br/>CRC, sequence, range"] --> TS["timestamp_engine"] --> TB["telemetry_buffer"]
  end
  API -->|AXI4-Lite| AXIL
  API -->|AXI4-Stream| DMA["dma_engine"]
  DMA -->|S2T| ING
  TB --> TT
  DMA <--> BUS
  LSU <--> BUS
  AXIL -->|memory window| BUS
  BUS --- ST & PA & CO & SC & RE & TT
  RET --> FM
  WD --> FM
  ING --> FM
  FM -->|halt| CF
  FM --> IRQ
  DMA -->|AXI4-Stream out| API
```

| Block | RTL | Role |
|---|---|---|
| top | `rtl/top/silica_flux_top.sv` | parameters, CSRs, memories, DMA, telemetry, safety |
| core | `rtl/core/flux_core.sv`, `flux_scheduler.sv`, `flux_dispatch.sv`, `flux_retirement.sv`, `flux_lsu.sv` | in-order issue, out-of-order completion, in-order retirement |
| arithmetic | `rtl/alu/*` | FMA (IEEE-754, all rounding modes), divider, square root, reciprocal, scalar ALU, vector ALU |
| math | `rtl/math/*` | exp, log, reductions, polynomial, interpolation |
| vector | `rtl/vector/*` | lanes, the vector pipeline, the register file |
| simulation | `rtl/simulation/*` | timestep engine, state update (explicit RK), residual, conservation |
| optimisation | `rtl/optimisation/*` | objective, constraint, parameter sweep, search |
| memory | `rtl/memory/*` | row SRAMs, scratchpad, result RAM, DMA |
| telemetry | `rtl/telemetry/*` | packet validation, timestamps, sample table |
| interconnect | `rtl/interconnect/*` | AXI4-Lite, AXI4-Stream, internal bus, elastic primitives |
| safety | `rtl/safety/*` | parity, range checks, watchdog, fault manager |

## 2. Design parameters

| Parameter | Values | Effect |
|---|---|---|
| `VECTOR_LANES` | 8 / 16 / 32 | elements per vector, per memory row and per reduction tree |
| `FP_MODE` | 0 / 1 | native binary32 or binary64 fabric |
| `DATA_WIDTH` | 32 / 64 | element width (must agree with `FP_MODE`) |
| `PIPELINE_DEPTH` | ≥ 4 | FMA / VALU latency (extra register slices for timing closure) |
| `SCRATCHPAD_SIZE` | rows | scratchpad depth |
| `STATE_ROWS`, `PARAM_ROWS`, `COEFF_ROWS`, `RESULT_ROWS`, `IMEM_DEPTH` | rows / words | memory sizes |
| `N_CHAN`, `TL_FIFO_DEPTH` | | telemetry channels, ingest buffer |
| `DIV_BPC` | 1 / 2 | divider / square-root bits per cycle |

The synthesis configurations (`synthesis/configs.json`) instantiate three
points: a small FPGA (8 lanes FP32), a large FPGA (32 lanes FP32) and an ASIC
reference (16 lanes FP64). The regression runs FP32 at 8/16/32 lanes and FP64
at 8/16 lanes.

## 3. Data model

Every vector element carries **value + 4 quality bits** (NaN, overflow,
underflow, suspect), and every vector register carries **metadata**
(`valid`, `precision`, `scale`, `source`, `timestamp`):

```mermaid
classDiagram
  class Element {
    value : W bits (FP32 / FP64 / fixed / int)
    quality : Q_NAN | Q_OVF | Q_UNF | Q_SUSPECT
  }
  class RegisterMeta {
    valid : written since reset
    prec : FP32 | FP64 | SFIX | UFIX | INT
    scale : fixed-point fractional bits
    source : functional unit / memory of the last write
    tstamp : retirement timestamp
  }
  class MemoryRow {
    LANES x Element
    parity per element
  }
  RegisterMeta "1" -- "L" Element
  MemoryRow "1" -- "L" Element
```

* **Precision is explicit.** An instruction states its format; a source of a
  different format or scale is a `PRECISION` fault, a never-written source is
  `UNINIT`. Formats change only through `VCVT`.
* **Quality propagates.** Results inherit the OR of their sources' quality and
  add their own exceptions, so a suspect sensor sample or an out-of-table
  interpolation taints every downstream value — and the host sees it.
* **Faults are observable, never silent.** Every anomaly is recorded with its
  PC and timestamp; halting faults stop the machine and nothing restarts it
  except the host.

## 4. Execution model

1. The host loads memories (DMA S2M or the memory window), the program
   (IMEM window), engine configuration and fault policy, then writes `START`.
2. `flux_core` fetches in order, checks each instruction at issue (legality,
   precision, hazards), dispatches to one of 14 functional units, writes back
   out of order and retires in order. Control instructions (`SETA`, `ADDA`,
   `BNZ`, `BARRIER`, `HALT`) execute in the issue stage.
3. Telemetry arrives asynchronously through the DMA S2T path; `BARRIER TELEM`
   synchronises a program with complete telemetry frames.
4. On `HALT` (or a halting fault) the host reads results (DMA M2S),
   performance counters and the fault record.

There are no caches, no speculation and fixed-priority arbitration, so the
cycle count of a program depends only on its instruction stream and on the
arrival times of external stream data — the property that makes the
analytical performance model (`docs/performance.md`) accurate and the RTL
results reproducible bit-for-bit.

## 5. Numerical engines and how a workload maps onto them

```mermaid
sequenceDiagram
  participant H as Host
  participant C as flux_core
  participant T as Telemetry
  H->>C: STATE x0, PARAM p, COEFF A, program
  H->>C: START
  loop every step
    C->>C: f(x) = A x + B u (VALU / FMA)
    C->>C: STATE_UPDATE stage 0..S-1 (RK)
    T-->>C: frame (CRC / seq / range checked)
    C->>C: RESIDUAL model vs telemetry
    C->>C: CONSERVE energy / mass balance
  end
  C->>H: RESULT trajectory, residuals, quality, faults
```

| Task | Instructions |
|---|---|
| state propagation | `TSCFG`, `STATE_UPDATE` (Euler, Heun, midpoint, Ralston, RK4, custom ≤ 4 stages) |
| model evaluation | VALU / FMA, `VPOLY`, `VINTERP`, `VEXP`, `VLOG`, `VDIV`, `VSQRT`, `VREDUCE DOT` |
| monitoring | `RESIDUAL`, `CONSERVE`, telemetry table loads |
| design exploration | `SWEEP`, `OBJECTIVE`, `CONSTRAINT`, `SEARCH GRID / LOCAL` |

The end-to-end example (`python/examples/end_to_end.py`) uses all four rows:
a lumped thermal network propagated with RK4 and compared against noisy
telemetry, followed by a surrogate design sweep and a compass search.

## 6. Interfaces

| Interface | Protocol | Use |
|---|---|---|
| `s_axil_*` | AXI4-Lite, 16-bit address | configuration, status, memory / IMEM windows |
| `s_axis_*` | AXI4-Stream 64-bit + 8-bit TUSER | DMA S2M (memories) and S2T (telemetry) |
| `m_axis_*` | AXI4-Stream 64-bit + 8-bit TUSER | DMA M2S (results) |
| `irq` | level | done / fault |

## 7. Related documents

* `docs/microarchitecture.md` — pipelines, scoreboard, retirement, engines
* `docs/numerical_model.md` — arithmetic, rounding, approximation errors
* `firmware/instruction_set.md`, `firmware/register_map.md`
* `docs/verification.md`, `docs/performance.md`, `docs/synthesis.md`
