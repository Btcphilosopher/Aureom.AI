# Silica Flux — Numerical Model

Every numerical claim in this document is backed by a generated artefact in
`reports/`; the tables below quote those files (regenerate with `make test`).
The guiding rule: **the RTL is specified by an executable golden model and
verified for bit-exact agreement with it** — value, IEEE flags and quality
bits. Accuracy is therefore characterised once, on the golden model, against
exact rational arithmetic (`fractions.Fraction`), and holds for the hardware
by construction of the verification.

```mermaid
flowchart LR
  EX["exact arithmetic<br/>(Fraction)"] -->|accuracy: ULP error| GM["golden model<br/>python/golden_model"]
  GM -->|bit-exact compare:<br/>value + flags + quality| RTL["RTL<br/>(Icarus / Verilator)"]
  GM -->|same functions| REF["ISA reference model"]
  REF -->|bit-exact compare:<br/>memories, registers, faults| CHIP["full chip RTL"]
```

## 1. Number formats

| Format | Encoding | Range | Precision |
|---|---|---|---|
| FP32 | IEEE-754 binary32 | ±3.4e38, subnormals to 1.4e-45 | 24 bits (u = 2⁻²⁴) |
| FP64 | IEEE-754 binary64 | ±1.8e308, subnormals to 4.9e-324 | 53 bits (u = 2⁻⁵³) |
| SFIX(F) | two's complement, `DATA_WIDTH` bits, value = n·2⁻ᶠ | ±2^(W−1−F) | 2⁻ᶠ absolute |
| UFIX(F) | unsigned, value = n·2⁻ᶠ | [0, 2^(W−F)) | 2⁻ᶠ absolute |
| INT | two's complement | ±2^(W−1) | 1 |

* Subnormals are fully supported (no flush-to-zero); underflow is signalled
  with tininess detected **before** rounding.
* NaN results are the canonical quiet NaN; signalling NaN inputs raise NV.
* Fixed-point / integer results **saturate** and raise OF; multiplications
  round per the rounding mode (`round_int_div_pow2` in `ieee.py`).
* Conversions (`VCVT`) are correctly rounded and saturating; FP→fixed of NaN
  returns the maximum positive value with NV (RISC-V convention).

## 2. Rounding

All five IEEE-754-2019 modes are implemented for every FP operation: RNE,
RTZ, RDN, RUP, RMM; `rm = DYN` selects the `FRM` CSR. Rounding happens once
per architectural operation (FMA: once for `a·b+c`).

## 3. Correctly rounded primitives

| Operation | Error vs exact result | Verified |
|---|---|---|
| ADD, SUB, MUL, FMA (all variants), SQR | ≤ 0.5 ULP (RNE / RMM), ≤ 1 ULP (directed modes) | 24,388 FP32 + 20,888 FP64 + 10,388 FP32 (6-stage) cocotb transactions, 900 SV vectors per format, 0 mismatches |
| DIV, SQRT | correctly rounded, same bounds | 5,952 divide + 3,544 square-root cocotb transactions (1 and 2 bits/cycle) + 816 SV vectors per format, 0 mismatches |
| MIN, MAX, ABS, NEG, CMP, CLASS, SEL, MOV | exact | VALU vectors at 8/16/32 lanes |

Measured ULP error of the RTL against exact arithmetic over the cocotb
transactions (all five rounding modes mixed): max 1.00, mean 0.32, RMS 0.49
(FMA FP32, `reports/numerics/fma_fp32_lat4.json`); directed modes account for every
error above 0.5 ULP.

## 4. Hardware approximations

### 4.1 Special functions

From `reports/numerics/sfu_accuracy.json` (`python/generators/gen_sfu_tables.py`),
sampled over the stated domain, error vs exact (50-digit `Decimal`)
reference, round-to-nearest output:

| Function | Format | Domain | Range | Max ULP | Mean ULP | RMS ULP | Samples | Latency |
|---|---|---|---|---|---|---|---|---|
| 1/x | FP32 | all finite ≠ 0, incl. subnormals | finite; overflow for \|x\| < 2^−emax | 0.5027 | 0.2529 | 0.2910 | 3 882 | 7 |
| 1/x | FP64 | same | same | 0.5004 | 0.2499 | 0.2880 | 972 | 9 |
| e^x | FP32 | [−103.97, 88.72]; \|x\| ≥ 128 saturates | [0, +Inf] | 0.5070 | 0.2452 | 0.2857 | 4 000 | 8 |
| e^x | FP64 | [−745.13, 709.78]; \|x\| ≥ 1024 saturates | [0, +Inf] | 0.4986 | 0.2553 | 0.2938 | 1 000 | 11 |
| ln x | FP32 | (0, +Inf], incl. subnormals | [−103.3, 88.7] | 0.5000 | 0.2417 | 0.2846 | 4 000 | 9 |
| ln x | FP64 | (0, +Inf], incl. subnormals | [−745.2, 709.8] | 0.5000 | 0.2483 | 0.2884 | 1 000 | 12 |

Notes:
* The maximum *relative* error of e^x in the same file (0.32 FP32, 0.06 FP64)
  occurs only for **subnormal results**, whose precision is intrinsically
  reduced; the ULP figure is the meaningful bound there.
* Special cases are exact: 1/±0 = ±Inf (DZ), 1/±Inf = ±0, e^−Inf = 0,
  e^+Inf = +Inf, ln 0 = −Inf (DZ), ln x<0 = NaN (NV), ln 1 = +0 exactly.
* Precision bits: 24 (FP32), 53 (FP64). These are *not* correctly rounded
  (≈ 0.5 ULP + a small table/polynomial error); results are deterministic and
  identical on every run, configuration and simulator.

### 4.2 Composite approximations

From `reports/numerics/approx_accuracy.json` (`python/analysis/approx_accuracy.py`):

| Primitive | Construction | Roundings | Max ULP (FP32 / FP64) | Mean ULP | RMS ULP | Bound |
|---|---|---|---|---|---|---|
| x² (`VSQR`) | x·x | 1 | 0.4999 / 0.5000 | 0.250 | 0.289 | 0.5 |
| x³ (`VCUBE`) | (x·x)·x | 2 | 1.2041 / 1.0702 | 0.342 / 0.355 | 0.421 / 0.428 | < 2 |
| polynomial (`VPOLY`, degree 5) | Horner, FMA chain | 5 | 1.6288 / 1.4951 | 0.303 / 0.289 | 0.376 / 0.363 | condition-dependent |
| interpolation (`VINTERP`) | `y_i + (t−i)·d_i` (t−i exact, one FMA) | 1 | 0.4995 / 0.4995 | 0.248 / 0.256 | 0.286 / 0.294 | 0.5 |

The polynomial figure is for a well-conditioned test polynomial (truncated
exp series on [−1, 1], coefficients 1/k! rounded to the format); in general
the Horner error is bounded by `γ_2n · Σ|c_k||x|^k` (Higham, §5.1) and grows
with cancellation. Interpolation figures are the *arithmetic* error; the
*modelling* error of representing a function by a uniform table is the
user's choice of table — for exp on [0, 1] with 8 knots it is 0.26 % maximum
relative error (same file). Inputs outside the table are clamped to the end
value and marked `Q_SUSPECT`; NaN inputs propagate.

## 5. Determinism of multi-operation engines

Floating-point addition is not associative, so every engine fixes its
evaluation order in the golden model and the RTL implements exactly that
order:

| Engine | Fixed order |
|---|---|
| reductions | pairwise tree over active lanes: (0,1), (2,3), …, then pairs of pairs; inactive lanes are skipped, not zero-filled; ties in MIN/MAX/ARG* keep the lower lane; NaN loses |
| state update | `x0 + Σ_j c_j·k_j` as an FMA chain in ascending j; zero tableau entries skipped; tableau pre-scaled by dt once (`c = dt·A`, rounded) |
| conservation | products `w_i·x_i` (rounded), tree sum; `E = ref + Σs`; `r = I − E`; threshold `fma(rtol, |E|, atol)` |
| objective | per-lane term with fixed operation order, then tree sum |
| sweep | coordinate = `fma(i, step, lo)` with exact integer i |

Consequently a program produces **bit-identical results on every lane count
that holds its data, on every simulator, and in the reference model** — the
full-chip regression checks this for 5 configurations.

## 6. Error propagation in time integration

The integrator's local error per step is the method's truncation error plus
the rounding error of the stage combination. For an S-stage tableau with
pre-scaled coefficients the rounding contribution per step is bounded by
roughly `(S + 1)·u·(|x0| + Σ|c_j k_j|)`. Over N steps, rounding errors grow at
worst linearly (≈ N·u·‖x‖) while truncation error of RK4 scales as h⁴; for
the 60-step thermal-network workload in FP32 the end-to-end example reports
the conserved-energy residual directly (`reports/workload/summary.json`) and
the RTL trajectory is identical to the reference model's to the last bit.

## 7. Quality propagation rules

```mermaid
flowchart LR
  S1["source quality q1"] --> OR(("OR"))
  S2["source quality q2"] --> OR
  EXC["result exceptions:<br/>NV/NaN -> Q_NAN<br/>OF -> Q_OVF<br/>UF -> Q_UNF"] --> OR
  ENG["engine verdict:<br/>clamped / violation /<br/>refused step -> Q_SUSPECT"] --> OR
  OR --> R["result quality"]
```

* Masked-off lanes keep their previous value and quality.
* Reductions OR the quality of every active lane into the broadcast result.
* Memory stores keep quality; loads return it (and add `Q_NAN|Q_SUSPECT` on a
  parity error).
* The host API exposes quality per element (`Value.quality`) and refuses to
  present a suspect value as clean.

## 8. What the error figures do not cover

* Modelling error of the user's physical model (the accelerator evaluates
  the model exactly as programmed, it does not validate the physics).
* Discretisation error of the chosen integration method and step size.
* Telemetry measurement uncertainty (anomalies are detected and flagged, not
  corrected).
