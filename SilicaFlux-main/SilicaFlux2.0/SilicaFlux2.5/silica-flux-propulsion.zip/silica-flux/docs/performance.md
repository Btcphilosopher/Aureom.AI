# Silica Flux — Performance

**What is measured and what is estimated.** Cycle counts, instruction counts,
lane operations and unit busy cycles are *measured* on the RTL (Verilator,
hardware performance counters read over AXI4-Lite). FLOP counts come from the
executed instruction trace of the reference model. **GFLOP/s figures multiply
measured FLOP/cycle by a clock frequency that is assumed** for each synthesis
target (100 MHz small FPGA, 250 MHz large FPGA, 1 GHz ASIC); no timing
closure has been performed, so those are labelled *estimates* everywhere. No
figure describes fabricated silicon.

Sources: `reports/benchmark/benchmark.json`, `benchmark.csv`,
`fu_utilisation.csv` (`python/analysis/benchmark.py`); plots from
`r/benchmark.R` in `reports/figures/`.

## 1. Peak rates (architectural)

| Quantity | Per cycle |
|---|---|
| VALU FMA throughput | `VECTOR_LANES` FMAs = 2·L FLOP |
| memory | one row (L elements) per cycle on the internal bus |
| issue | 1 instruction; the front end sustains ≈ 2 instructions per 3 cycles on straight-line code |
| register-file write-back | 1 vector register per cycle (all units share the port) |

## 2. Measured kernels

| Config | Kernel | Cycles (RTL) | Model | Error | FLOP/cycle | Vector util. | Est. GFLOP/s @ 250 MHz |
|---|---|---|---|---|---|---|---|
| FP32 8L | fma_stream | 197 | 199 | +1.0 % | 5.20 | 0.365 | 1.30 |
| FP32 8L | fma_chain | 246 | 248 | +0.8 % | 2.08 | 0.134 | 0.52 |
| FP32 8L | mixed_kernels | 989 | 924 | −6.6 % | 1.94 | 0.081 | 0.49 |
| FP32 8L | rk4_thermal_network | 5 943 | 6 187 | +4.1 % | 1.52 | 0.114 | 0.38 |
| FP32 8L | surrogate_design_sweep | 22 237 | 22 128 | −0.5 % | 2.29 | 0.134 | 0.57 |
| FP32 16L | fma_stream | 197 | 199 | +1.0 % | 10.40 | 0.365 | 2.60 |
| FP32 16L | rk4_thermal_network | 6 891 | 7 230 | +4.9 % | 2.62 | 0.099 | 0.66 |
| FP32 16L | surrogate_design_sweep | 12 653 | 12 592 | −0.5 % | 4.02 | 0.117 | 1.01 |
| FP32 32L *(held out)* | fma_stream | 197 | 199 | +1.0 % | 20.79 | 0.365 | 5.20 |
| FP32 32L *(held out)* | mixed_kernels | 1 149 | 1 052 | −8.4 % | 6.68 | 0.070 | 1.67 |
| FP32 32L *(held out)* | rk4_thermal_network | 6 235 | 6 387 | +2.4 % | 5.79 | 0.109 | 1.45 |
| FP32 32L *(held out)* | surrogate_design_sweep | 5 673 | 5 634 | −0.7 % | 8.98 | 0.131 | 2.25 |
| FP64 8L | rk4_thermal_network | 5 973 | 6 367 | +6.6 % | 1.51 | 0.114 | 0.38 |

The complete table (20 runs, every result verified bit-exact against the
reference model) is in `reports/benchmark/benchmark.csv`; `make report`
prints it.

Kernels:
* **fma_stream** — 8 independent accumulators, 64 FMAs per lane: issue-bound.
* **fma_chain** — one dependent FMA chain: latency-bound (≈ 7.7 cycles per FMA
  incl. loop overhead with `PIPELINE_DEPTH = 4`).
* **mixed_kernels** — polynomial, exp, two reductions, FMA, store per iteration.
* **rk4_thermal_network** — 12 RK4 steps of an 8-node thermal network with
  derivative evaluation, residual and conservation checks (the workload of
  `python/examples/end_to_end.py`, shortened).
* **surrogate_design_sweep** — 64-candidate grid sweep, 60-step transient per
  candidate, objective, constraint, arg-min: scales with lanes because
  candidates map to lanes (8 → 32 lanes: 3.9× fewer cycles).

## 3. Analytical model

`python/analysis/perf_model.py` predicts cycles from the reference model's
executed trace using the microarchitecture's structure:

```mermaid
flowchart LR
  T["executed trace<br/>(reference model)"] --> FQ["front end:<br/>fetch + 2-entry queue,<br/>branch redirect"]
  FQ --> IS["issue: RAW / WAW on<br/>register-ready times"]
  IS --> FU["unit latency<br/>(algorithmic, per opcode)<br/>+ unit occupancy"]
  FU --> WB["result available<br/>done + AVAIL"]
  WB --> IS
  FU --> C["predicted cycles,<br/>FLOPs"]
```

| Constant | Value | Meaning |
|---|---|---|
| `fetch_to_issue` | 2 | IMEM read + decode-queue entry |
| `queue_release` | 1 | a fetch may start one cycle after the instruction two ahead issued |
| `redirect` | 3 | taken `BNZ` → first refetch |
| `dispatch` | 1 | issue → unit sees the µop |
| `avail` | 2 | unit completion → dependent issue (write-back + scoreboard release) |
| `engine_early` | 2 | iterative engines accept the next µop 2 cycles before completing |

Unit latencies are derived from the algorithms (e.g. divider
`3 + ceil((P+2)/DIV_BPC)`, reduction `2 + log2(L)·depth`, Horner
`2 + degree·depth`). The six structural constants were fitted once on the
FP32-8, FP32-16 and FP64-8 runs; the **FP32-32 configuration was held out**
and is predicted within **−8.4 % … +2.4 %**. Over all 20 runs the model error
is −8.4 % … +6.6 % (mean |error| ≈ 3 %). The largest errors come from
reductions and special functions, whose response arbitration the model does
not represent.

## 4. Bottlenecks and scaling

* **Front end.** Straight-line code issues at ≈ 0.67 IPC; `fma_stream`
  reaches 36.5 % of peak VALU throughput for that reason. A third decode-queue
  entry (or a prefetch buffer) is the first optimisation target.
* **Single write-back port.** All 14 units share one register-file write
  port; with many short engine results this, not arithmetic, limits
  throughput.
* **Iterative engines are not pipelined across instructions.** A unit accepts
  a new µop only near the end of the previous one; independent work on
  *different* engines overlaps, work on the same engine serialises.
* **Lane scaling.** Data-parallel workloads (sweeps, many candidates or
  many state elements per vector) scale with `VECTOR_LANES`; latency-bound
  kernels (`fma_chain`) do not.

## 5. Unit latencies (cycles, normal operands)

| Unit | FP32 | FP64 | Pipelined |
|---|---|---|---|
| VALU / FMA | `PIPELINE_DEPTH` (4–6) | same | yes, 1 / cycle |
| DIV / SQRT (`DIV_BPC` = 1) | 3 + 26 | 3 + 55 | no |
| reciprocal | 7 | 9 | no |
| exp | 8 | 11 | no |
| log | 9 | 12 | no |
| LSU load / store | 4 | 4 | one access / cycle on the bus |

Measured latency distributions under random back-pressure are recorded per
transaction in `reports/numerics/*.csv` and plotted by `r/benchmark.R`.

## 6. Resource cost

See `docs/synthesis.md`; area-normalised throughput is not quoted because the
resource figures are pre-implementation estimates.
