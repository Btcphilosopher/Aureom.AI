# Silica Flux — Microarchitecture

This document describes how the architecture of `docs/architecture.md` is
realised in RTL. Cycle numbers are those of the RTL; they are the ones the
analytical model (`python/analysis/perf_model.py`) is validated against.

## 1. Core pipeline

```mermaid
flowchart LR
  subgraph FE["Front end"]
    IM["IMEM<br/>64b + parity"] --> DQ["decode queue<br/>2 entries"]
  end
  DQ --> IS["ISSUE<br/>scheduler"]
  IS -->|ctrl| CT["SETA / ADDA / BNZ<br/>BARRIER / HALT"]
  IS -->|vector| RR["REGISTER READ<br/>3 ports"]
  RR --> DP["DISPATCH<br/>per-FU valid/ready"]
  DP --> FU1["VALU / FMA<br/>pipelined"] & FU2["DIV / SQRT<br/>iterative"] & FU3["SFU"] & FU4["LSU"] & FU5["engines x10"]
  FU1 & FU2 & FU3 & FU4 & FU5 --> WB["WRITE-BACK<br/>round-robin, 1 port"]
  WB --> ROB["RETIRE<br/>16-entry in-order queue"]
  ROB --> FLT["fault events<br/>(exact PC)"]
  WB -.->|release +1 cycle| IS
  CT -.->|redirect| IM
```

| Stage | Behaviour |
|---|---|
| Fetch | one IMEM read per cycle into a 2-entry decode queue; a fetch starts only when the queue (incl. the word in flight) has space — straight-line code therefore sustains ≈ 2 instructions every 3 cycles |
| Issue | `flux_scheduler`: illegal / precision / uninitialised checks against register metadata, RAW/WAW scoreboard (one busy bit per register + VM), SWEEP↔SEARCH serialisation, ROB space, register-read availability |
| Control | executes at issue; a taken `BNZ` flushes the queue and refetches (no speculation); `BARRIER`/`HALT` wait for every older instruction to retire |
| Register read | `vector_register_file`: 3 synchronous read ports, data held until the next read |
| Dispatch | `flux_dispatch`: holds the µop (`uop_t`: instruction, PC, ROB tag, FU, effective rounding mode, write flags) and operands until the target unit accepts it |
| Execute | 14 functional units, each with a valid/ready request and response port (`SF_FU_PORTS`) |
| Write-back | round-robin arbiter → single write port with per-lane mask; destination metadata rewritten; scoreboard released one cycle later |
| Retire | completion queue allocated at issue, completed by tag, retired from the head in program order; NV/OF/UF/DZ converted to fault events; flags accumulated |

**Precise attribution, imprecise writes.** A fault is reported in program
order with the exact PC. Instructions *younger* than a faulting one that are
already in flight complete their register writes (no rollback); since a
halting fault stops the machine and the host must inspect the fault record,
this never produces a silently wrong result. Issue-time faults (`ILLEGAL`,
`PRECISION`, `UNINIT`, `PARITY`) occupy a retirement slot without executing
and serialise the pipeline: nothing younger issues behind them.

### Hazard handling

```mermaid
stateDiagram-v2
  [*] --> Free
  Free --> Busy: issue writes vd
  Busy --> Busy: RAW/WAW consumer stalls
  Busy --> Releasing: write-back of vd
  Releasing --> Free: +1 cycle
```

A consumer of `vd` issues in the cycle after release, so the register file
needs no bypass and no write-before-read ordering. Metadata of a busy register
is stale; therefore even an instruction that will *fault* at issue waits for
its hazards to clear before its legality verdict is taken.

## 2. Vector pipeline (`rtl/vector/vector_pipeline.sv`)

`VECTOR_LANES` lanes operate in lockstep. Each lane (`vector_lane.sv`)
contains an FMA datapath (also used for ADD/SUB/MUL), comparison / class /
conversion logic and fixed-point arithmetic; the lanes share one elastic
control pipeline (`a_lockstep_*` assertions check that they never diverge).
Iterative units (divider, square root) and the special-function unit are
instantiated per lane and share the VALU response path.

### 2.1 Fused multiply-add (`rtl/alu/fma_unit.sv`)

| Stage | Work |
|---|---|
| S1 | unpack, classify, special cases; P×P significand multiply; addend alignment in a 3P+6-bit frame with a dedicated sticky bit; dominant-addend proxy when the product is < 1/8 ULP of the addend |
| S2 | signed add/subtract, magnitude, exact-zero detection |
| S3 | leading-zero count and normalisation, clamped at `emin` for subnormal results |
| S4 | rounding (RNE, RTZ, RDN, RUP, RMM), packing, exception flags (tininess before rounding) |
| S5… | optional register slices (`PIPELINE_DEPTH > 4`) for retiming |

Every stage is an elastic valid/ready register (`sf_pipe_reg`), so a stall
never requires a global enable. `fma(Inf, 0, qNaN)` raises NV; the result of
an invalid operation is the canonical quiet NaN.

### 2.2 Divider and square root

Radix-2 digit recurrence (`DIV_BPC` = 1 or 2 quotient bits per cycle) on
normalised significands with subnormal pre-normalisation; the remainder gives
an exact sticky bit, so results are correctly rounded in every mode.
Latency ≈ `3 + ceil((P+2)/DIV_BPC)` cycles.

### 2.3 Special-function unit

| Function | Algorithm | FP32 / FP64 parameters | Latency |
|---|---|---|---|
| reciprocal | 7-bit seed table + Newton–Raphson in fixed point | 2 / 3 iterations, 32 / 62 fraction bits | 7 / 9 |
| exp | `x·log2(e) = n + j/2^s + r`; `2^(j/2^s)` table (Tang) × polynomial in r | 32 / 64 entries, degree 3 / 6 | 8 / 11 |
| log | exponent / mantissa split, segment table + polynomial, cancellation-free formulation near 1 | 64 / 128 segments, degree 4 / 7 | 9 / 12 |

Tables are generated by `python/generators/gen_sfu_tables.py` into
`rtl/math/generated/sfu_tables.svh` from the same Python object that the
bit-exact model uses, so table and model can never diverge.

## 3. Multi-cycle engines

All engines reuse an `sf_fma_array` (one FMA per lane, `PIPELINE_DEPTH`
latency) driven by a small FSM. They fix the order of every rounded
operation, which is what makes bit-exact verification possible.

| Engine | FSM passes through the FMA array |
|---|---|
| `reduction_unit` | pre-pass (SUMSQ/DOT products) + log2(L) tree levels; lane 2i pairs with 2i+1 |
| `polynomial_unit` | Horner: one FMA pass per degree; `VCUBE` two passes |
| `interpolation_unit` | index/fraction computation + one FMA pass |
| `timestep_engine` | scales the 10 tableau entries by dt (10 scalar FMAs, once per `TSCFG`); `t += dt` at commit |
| `state_update` | one FMA pass per non-zero tableau term of the stage |
| `residual_engine` | `r = x − o`, `th = fma(rtol, |x|, atol)`, optional margin |
| `conservation_checker` | products, two tree reductions, `E = ref + S`, `r = I − E`, threshold, relative residual (divider) |
| `objective_eval` | 1–3 passes per term + optional tree sum |
| `constraint_eval` | 1–2 passes (margin, tolerance) + comparisons |
| `parameter_sweep` | mixed-radix digit counters per lane; one FMA pass `lo + i·step` per generated coordinate |
| `search_engine` | arg-min tree over feasible lanes; compass-search state (centre, steps, iteration, convergence) |

## 4. Memory system

```mermaid
flowchart LR
  LSU["core LSU<br/>(master 0)"] --> ARB
  DMA["DMA<br/>(master 1)"] --> ARB
  HW["host window<br/>(master 2)"] --> ARB
  ARB["internal_bus<br/>fixed priority, 1 row / cycle,<br/>address check"] --> S0[("STATE A/B")] & S2[("PARAM")] & S3[("COEFF")] & S4[("SCRATCH")] & S5[("RESULT")] & S6[("TELEM")]
```

* Every memory is **row-organised**: one row = `VECTOR_LANES` elements of
  `W + 4 quality + 1 parity` bits, so a vector load or store is one access.
* Read latency is one cycle; the bus has no response back-pressure; illegal
  addresses never reach a memory and are reported as `MEMADDR`.
* `STATE` and `STATE_N` are a ping-pong pair; `BARRIER SWAP` exchanges them so
  a step can read x_n while writing x_{n+1}.
* Parity is generated on write and checked on every read (LSU, DMA, host);
  a parity error marks the element `Q_NAN|Q_SUSPECT` and raises `PARITY`.
  Test hooks (`CTRL[4]`, `CTRL[5]`) inject IMEM and data-memory parity errors.

## 5. Telemetry path

`AXI4-Stream → DMA (S2T) → telemetry_ingest → timestamp_engine → telemetry_buffer → TELEM table`

The ingest stage validates framing, CRC-16/CCITT-FALSE, channel, per-channel
sequence numbers, timestamp monotonicity / maximum gap and per-channel range
bounds. Dropped packets are counted per cause; kept anomalous samples carry
`Q_SUSPECT`. A bounded FIFO absorbs bursts; overflow is counted and raises
`TL_OVF` (never a silent drop).

## 6. Safety

| Mechanism | RTL | Detects |
|---|---|---|
| parity | `parity_checker.sv`, `flux_core` | IMEM and data-memory corruption |
| range checker | `range_checker.sv` | telemetry outside bounds, NaN |
| watchdog | `watchdog.sv` | core without progress (starved barrier, deadlock), stalled DMA |
| lockstep / retirement assertions | `vector_lane.sv`, `flux_retirement.sv` | pipeline divergence (`PIPELINE`) |
| fault manager | `fault_manager.sv` | records every event: sticky status, first id / PC / timestamp, count, halt mask, interrupt |

## 7. Elastic primitives (`rtl/interconnect/sf_primitives.sv`)

| Primitive | Function | Formal status |
|---|---|---|
| `sf_pipe_reg` | full-throughput valid/ready register | proven (k-induction) |
| `sf_skid` | skid buffer with registered ready | BMC |
| `sf_fifo` | synchronous FIFO with occupancy and overflow flag | BMC |
| `sf_rr_arb` | round-robin arbiter | proven |

## 8. Clocking and reset

Single clock domain, synchronous active-low reset. All valid bits are cleared
by reset (checked in every formal harness); datapath registers are not reset.
