# Silica Flux — Verification

Verification is layered so that every layer checks the one below it against
an independent reference, and every comparison is **bit-exact** (value, IEEE
flags, quality bits, faults) — never "within tolerance".

```mermaid
flowchart TB
  CPU["host FPU<br/>(float, math.fma, numpy.float32)"] -->|selftest.py| GM
  EXACT["exact rationals<br/>(Fraction / Decimal)"] -->|accuracy| GM
  GM["golden model<br/>ieee / valu / sfu / engines / telemetry"] --> ISA["ISA reference model<br/>isa_sim.py"]
  GM -->|cocotb, Icarus| UNIT["unit RTL<br/>FMA, DIV, SQRT, SFU, VALU"]
  GM -->|vector files| SVTB["SV testbenches<br/>Verilator + Icarus"]
  ISA -->|scenarios| CHIP["full chip RTL<br/>Verilator, 5 configurations"]
  SVA["SVA checkers<br/>(bound + embedded)"] -.->|every cycle| SVTB & CHIP
  FORMAL["formal harnesses<br/>SymbiYosys + Yosys SAT"] -.-> PRIM["elastic primitives, AXI-Lite,<br/>watchdog, fault manager, FMA"]
  CHIP --> WL["end-to-end workload<br/>reference vs RTL"]
```

## 1. Layers

| # | Layer | Tool | Reference | Command |
|---|---|---|---|---|
| 0 | golden-model self-test | Python | host FPU (RNE) | `python3 python/golden_model/selftest.py` |
| 1 | special-function accuracy | Python | 50-digit `Decimal` | `python3 python/generators/gen_sfu_tables.py` |
| 2 | composite-approximation accuracy | Python | `Fraction` | `python3 python/analysis/approx_accuracy.py` |
| 3 | unit regressions | cocotb 2 + Icarus | golden model | `make cocotb` |
| 4 | self-checking SV testbenches | Verilator 5 **and** Icarus 12 | golden-model vector files | `make sv` |
| 5 | full-chip system regression | Verilator | ISA reference model | `make system` |
| 5b | full-chip programs on a second simulator | cocotb 2 + Icarus | ISA reference model | `make cocotb-top` |
| 6 | simulation assertions | Verilator `--assert` | SVA properties | part of 4 and 5 |
| 7 | formal | SymbiYosys (z3) / Yosys SAT | properties | `make formal` |
| 8 | synthesis checks | Yosys 0.71 | `check -assert`, latch detection | `make synth-check` |
| 9 | end-to-end workload | Verilator | reference model | `make workload` |

`make test` runs layers 0–6 and 9; `make report` collects every result into
`reports/SILICA_FLUX_REPORT.md`.

## 2. Unit level (cocotb)

`python/cocotb/sf_cocotb.py` provides a handshake harness that drives a unit
with random input valid gaps **and random output back-pressure**, tags every
transaction, and records value, flags and latency. `ErrorStats` computes per
transaction: absolute, relative and ULP error against the exact result,
bit-exact agreement with the golden model, and aggregates max / mean / RMS /
failure counts into `reports/numerics/<unit>.json` + `.csv` (the CSV feeds
the R analysis).

| Configuration | DUT | Stimulus |
|---|---|---|
| `fma_fp32`, `fma_fp64`, `fma_fp32_lat6` | `fma_unit` (all 7 ops, 5 rounding modes) | directed specials (±0, ±Inf, NaNs, min/max subnormal and normal, ties, cancellation, overflow/underflow boundaries) + random operands with exponent clustering |
| `div_fp32`, `div_fp32_r4`, `div_fp64` | `divider` (1 and 2 bits/cycle) | specials + random |
| `sqrt_fp32`, `sqrt_fp64` | `sqrt_unit` | specials + random incl. negative |
| `recip/exp/log_{fp32,fp64}` | SFU units | domain-sampled + specials |
| `valu_fp32_l{8,16,32}`, `valu_fp64_l8` | `vector_alu` | every VALU opcode, masks, fixed point, conversions |

## 3. SystemVerilog testbenches

Twelve self-checking testbenches (`tb/*.sv`) replay golden-model vector files
(`python/generators/sv_vectors.py`) and compare bit-exactly. They run on
**both** Verilator and Icarus; the Verilator builds additionally compile all
SVA checkers.

| Testbench | Covers |
|---|---|
| `tb_fma` (FP32, FP64) | FMA, all ops and rounding modes |
| `tb_math` (FP32, FP64) | divider, square root, reciprocal, exp, log |
| `tb_vector_alu` (8/16/32 lanes) | vector ALU incl. masks, broadcast, slide, compare |
| `tb_interpolation` | interpolation incl. clamping, NaN |
| `tb_simulation` | state engine (all methods, sequence faults), residual engine |
| `tb_optimisation` | objective, constraint, sweep |
| `tb_scheduler` | hazards, legality, precision / scale mismatch, uninitialised sources, dynamic rounding, fault-only issue, SWEEP/SEARCH serialisation, ROB full |
| `tb_faults` | fault manager (first-fault capture, halt mask, clear), watchdog, parity, range checker, FIFO overflow |

## 4. Full-chip system regression

`python/reference_model/system_regress.py` builds `tb/tb_top.sv` around
`silica_flux_top` with Verilator for each configuration and runs scenarios
through the real host interfaces: programs over AXI4-Lite, memory images and
telemetry over AXI4-Stream (DMA S2M / S2T), results back through DMA M2S. The
reference model (`isa_sim.py`) executes the same scenario; the comparison
covers **every word of every result memory, quality bits, fault status, first
fault id and PC, IEEE flags, retired-instruction count and telemetry
counters**.

| Suite | Scenarios per configuration | Content |
|---|---|---|
| directed | 14 | VALU, fixed point, div/sqrt/SFU, reductions, polynomial / interpolation, RK4 / Heun / Euler / midpoint / Ralston, residual + conservation, objective + constraint, sweep + search, LSU variants |
| random | 6 | constrained-random programs (dependency chains, mixed units, masks, partial vectors, loops) |
| faults | 14 | illegal opcode, precision mismatch, uninitialised read, NaN from an invalid operation, overflow, divide by zero, underflow (recorded, not halting), illegal memory address, write to the read-only telemetry table, data-memory parity corruption, instruction parity error, watchdog on a starved telemetry barrier, invalid timestep, NaN quality propagation |
| telemetry | 2 | a clean frame; a stream combining CRC errors, sequence gaps, timestamp discontinuities, range violations, malformed packets and sensor-invalid samples |

Configurations: FP32 × {8, 16, 32} lanes, FP64 × {8, 16} lanes, with
pipeline depths 4–6.

### Full chip on a second simulator (cocotb + Icarus)

`python/cocotb/test_top.py` drives `silica_flux_top` through its AXI4-Lite and
AXI4-Stream ports from Python (`sf_host.py`) and compares against the same
reference model: identity / configuration readback, the 14 directed
programs, constrained-random programs, and **job isolation** — two jobs
back-to-back without a reset, where the second must not see the first job's
registers or vector mask (it must raise `UNINIT`). Configurations: FP32 8 and
16 lanes, FP64 8 lanes.

## 5. Assertions (SVA)

* **Bound checkers** (`formal/assertions.sv`): valid/ready protocol
  (valid held, payload stable while stalled, no X) on every functional-unit
  response port, the AXI4-Lite B/R channels and the AXI4-Stream output;
  fault-manager invariants (halt backed by a recorded fault, first-fault
  record sticky, monotonic counter); retirement-buffer overflow.
* **Embedded assertions** (`` `ifdef SF_SVA `` in the RTL): scoreboard
  (never double-busy, only busy registers released), dispatch stability,
  retirement liveness, lane lockstep, AXI-Stream hold, fault manager never
  loses an event.

They are compiled into every Verilator build (unit testbenches and the full
chip) — a violation aborts the run and fails the test. Enabling them found
one testbench stimulus that drove an impossible scoreboard release
(`tb_scheduler`, fixed).

## 6. Formal verification

`formal/run_formal.py`, harnesses in `formal/properties.sv`:

| Harness | Property | Engine | Result |
|---|---|---|---|
| `f_pipe_reg` | ordering, no loss / duplication, occupancy, reset | k-induction (z3) | proven |
| `f_rr_arb` | one-hot grant ⊆ requests, work-conserving | k-induction | proven |
| `f_watchdog` | expiry exactly after LIMIT starved cycles | k-induction | proven |
| `f_fault_mgr` | no fault event lost, exact halt request | k-induction | proven |
| `f_skid` | valid/ready contract, ≤ 2 in flight | BMC depth 12 | pass |
| `f_fifo` | accounting, FIFO order, overflow never silent | BMC depth 14 | pass |
| `f_axil` | AXI4-Lite response stability, single outstanding write, no duplicate commit | BMC depth 12 | pass |
| `f_fma_comm` | `a·b = b·a`, `a+c = c+a` with identical flags, every encoding of a 1-4-3 mini-float, every rounding mode, through the generic FMA datapath | BMC depth 12 (Yosys SAT / MiniSat) + non-vacuity cover | pass |

Inductive proofs are reported as *proven* only when k-induction succeeds;
otherwise the bounded result is reported with its depth.

## 7. Synthesis-level checks

`synthesis/run_synth.py --check` elaborates the complete chip for each
synthesis configuration with Yosys and runs `check -assert` (no undriven or
multiply-driven nets) and latch detection. This layer found two constructs
that simulators accept but Yosys mis-elaborates — packed arrays of struct
typedefs in port connections (element selects sized as one bit) and a
genvar-indexed 2-D array declared inside a generate block — both rewritten
as flat packed vectors.

## 8. Defects found by the flow (and fixed)

| Found by | Defect | Fix |
|---|---|---|
| random system programs | reduction-tree flag accumulation kept only the last lane's flags | blocking accumulation |
| fault scenarios | fault-only issue used stale metadata of a busy register | fault-only issue also waits for RAW/WAW |
| Icarus SV testbench (hang) | `always_comb` with a loop-local temporary re-triggered itself at zero delay in `residual_engine` | per-lane continuous assignments |
| cocotb full chip on Icarus | vector mask and register metadata survived from one job to the next | `START` re-initialises job state; regression test `t04_job_isolation` |
| SVA in unit testbenches | testbench released a scoreboard entry for an instruction with no destination | stimulus corrected |
| Yosys `check -assert` | packed struct arrays / generate-scoped 2-D arrays mis-elaborated | flat packed vectors |

## 9. Known limitations

* The full-chip constrained-random volume is modest (6 programs per
  configuration on Verilator, up to 6 per configuration on Icarus); the
  regression is seeded and reproducible, and the seed set can be widened
  with `--random N --seed S`.
* Formal coverage is limited to control primitives and one arithmetic
  invariant; datapath correctness rests on the bit-exact simulation layers.
* Resource figures are Yosys estimates, not vendor place-and-route results
  (`docs/synthesis.md`).
