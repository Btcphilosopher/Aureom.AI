#!/usr/bin/env python3
"""
Silica Flux synthesis / resource estimation (Yosys 0.71, YoWASP build).

    python3 synthesis/run_synth.py --check            # full-chip elaboration (all configs)
    python3 synthesis/run_synth.py small_fpga asic    # resource estimates

Method -- stated plainly because these are ESTIMATES, not implementation
results:
  1. Full-chip synthesizability: every configuration is read, elaborated,
     processed (proc) and checked for latches / multi-driven nets with Yosys.
  2. Logic: each functional block is synthesized on its own at the
     configuration's parameters (FPGA: synth_xilinx -> LUT/FF/DSP/CARRY;
     ASIC: generic synth + abc -> cell counts and CMOS transistor estimate).
     Blocks are summed with their instance counts in silica_flux_top.
  3. Memories: counted in bits from the configuration (state x2 banks, param,
     coefficient, scratchpad, result, instruction memory) and mapped to
     36 Kbit block RAMs for FPGA targets / SRAM macros for ASIC.  The vector
     register file (3R1W) is synthesized as a logic block.
  Not included: the top-level CSR / glue logic of silica_flux_top and the
  AXI-Stream register slices (small next to the datapath).
  4. --lane-scale=N (used for the 32-lane FPGA and 16-lane FP64 ASIC builds,
     whose full-width blocks take hours in the WebAssembly Yosys): every
     block is synthesized at the configuration's format, depth and divider
     radix but with N lanes; blocks whose cost is proportional to the lane
     count (LANE_SCALED) are multiplied by LANES/N, the others are taken as
     measured.  The scaling is checked against blocks synthesized at full
     width (build/synth/<config>_full/) and the measured ratio is stored in
     the report ("scaling_check").
No timing closure, placement or routing is claimed.  Blocks run in parallel
(--jobs); a block that exceeds the per-block timeout is reported as such and
excluded from the totals -- never extrapolated.  YoWASP Yosys (WebAssembly)
only sees the working directory, so every path is relative to the repository
root.  Results: reports/synth/<config>.json
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
YOSYS = shutil.which("yowasp-yosys") or shutil.which("yosys")
SOURCES = [l.strip() for l in (ROOT / "rtl/sources.f").read_text().splitlines() if l.strip()]
CONFIGS = json.loads((ROOT / "synthesis/configs.json").read_text())


def blocks(p: dict):
    L, fp, d, bpc = p["VECTOR_LANES"], p["FP_MODE"], p["PIPELINE_DEPTH"], p["DIV_BPC"]
    e, m = (11, 52) if fp else (8, 23)
    fpp = {"LANES": L, "EXP_W": e, "MAN_W": m, "LATENCY": d}
    return [
        # name, module, parameters, instances
        ("vector_alu", "vector_alu", fpp, 1),
        ("div_sqrt_array", "vector_iter_array", {"LANES": L, "EXP_W": e, "MAN_W": m, "KIND": 0, "DIV_BPC": bpc}, 1),
        ("sfu_array", "vector_iter_array", {"LANES": L, "EXP_W": e, "MAN_W": m, "KIND": 1}, 1),
        ("reduction", "reduction_unit", fpp, 1),
        ("polynomial", "polynomial_unit", fpp, 1),
        ("interpolation", "interpolation_unit", fpp, 1),
        ("state_update", "state_update", fpp, 1),
        ("residual", "residual_engine", fpp, 1),
        ("conservation", "conservation_checker", fpp, 1),
        ("objective", "objective_eval", fpp, 1),
        ("constraint", "constraint_eval", fpp, 1),
        ("sweep", "parameter_sweep", fpp, 1),
        ("search", "search_engine", fpp, 1),
        ("lsu", "flux_lsu", {"LANES": L, "W": 1 + e + m}, 1),
        ("scheduler", "flux_scheduler", {"LANES": L, "FP_MODE": fp}, 1),
        ("retirement", "flux_retirement", {"LANES": L, "W": 1 + e + m}, 1),
        ("telemetry_ingest", "telemetry_ingest", {"EXP_W": e, "MAN_W": m}, 1),
        ("dma", "dma_engine", {"LANES": L, "W": 1 + e + m}, 1),
        ("fault_manager", "fault_manager", {"NSRC": 3}, 1),
        ("axi_lite", "axi_lite_slave", {}, 1),
        ("register_file", "vector_register_file", {"LANES": L, "W": 1 + e + m}, 1),
        ("dispatch", "flux_dispatch", {"LANES": L}, 1),
        ("internal_bus", "internal_bus", {"LANES": L, "EW": 1 + e + m + 4 + 1, "NM": 3}, 1),
        ("telemetry_buffer", "telemetry_buffer", {"LANES": L, "W": 1 + e + m, "N_CHAN": 32, "DEPTH": 16}, 1),
        ("timestamp", "timestamp_engine", {}, 1),
    ]


# silica_flux_top defaults for the memory depths not set by the configuration
TOP_DEFAULTS = {"STATE_ROWS": 64, "PARAM_ROWS": 64, "COEFF_ROWS": 64, "RESULT_ROWS": 128, "IMEM_DEPTH": 1024}


# blocks whose logic is a per-lane datapath (cost proportional to VECTOR_LANES)
LANE_SCALED = {"vector_alu", "div_sqrt_array", "sfu_array", "reduction", "polynomial", "interpolation",
               "state_update", "residual", "conservation", "objective", "constraint", "sweep", "search",
               "lsu", "retirement", "register_file", "internal_bus", "dma"}


def memory_bits(p: dict) -> dict:
    q = dict(TOP_DEFAULTS, **p)
    L = q["VECTOR_LANES"]
    W = 64 if q["FP_MODE"] else 32
    ew = W + 4 + 1                      # value + quality + parity
    rows = {"state (2 banks)": 2 * q["STATE_ROWS"], "param": q["PARAM_ROWS"], "coeff": q["COEFF_ROWS"],
            "scratchpad": q["SCRATCHPAD_SIZE"], "result": q["RESULT_ROWS"]}
    out = {k: r * L * ew for k, r in rows.items()}
    out["instruction"] = q["IMEM_DEPTH"] * 65
    return out


def _read_cmd() -> str:
    return f"read_verilog -sv -DSYNTHESIS -Irtl/core -Irtl/math/generated {' '.join(SOURCES)}\n"


def ys_script(module: str, params: dict, target: str, quick_abc: bool = False) -> str:
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    head = _read_cmd() + (f"chparam {chp} {module}\n" if params else "")
    if quick_abc:      # minimal ABC mapping: ~10 % more cells than the default flow, minutes instead of hours
        return head + f"synth -flatten -noabc -top {module}\nabc -script +strash;map\nopt_clean\nstat -tech cmos\n"
    if target == "xilinx":
        return head + f"synth_xilinx -flatten -top {module} -noiopad\nstat\n"
    return head + f"synth -flatten -top {module}\nopt_clean\nstat -tech cmos\n"


def _yosys(script: Path, log: Path, timeout: int):
    """run Yosys from the repository root with relative paths (WASI sandbox)"""
    return subprocess.run([YOSYS, "-q", "-s", str(script.relative_to(ROOT)), "-l", str(log.relative_to(ROOT))],
                          cwd=ROOT, capture_output=True, text=True, timeout=timeout)


def parse_stat(txt: str, target: str) -> dict:
    sec = txt[txt.rfind("Printing statistics"):]
    cells = {}
    for m in re.finditer(r"^\s+(\d+)\s+(?:[\d.]+\s+)?(\$?[\w$]+)\s*$", sec, re.M):
        cells[m.group(2)] = cells.get(m.group(2), 0) + int(m.group(1))
    for m in re.finditer(r"^\s+(\$?[\w$]+)\s+(\d+)\s*$", sec, re.M):
        cells[m.group(1)] = cells.get(m.group(1), 0) + int(m.group(2))
    out = {"cells": cells}
    tm = re.search(r"Estimated number of transistors:\s+([\d.]+)", sec)
    if tm:
        out["transistors"] = float(tm.group(1))
    if target == "xilinx":
        lut = sum(v for k, v in cells.items() if re.match(r"^LUT\d$", k))
        ff = sum(v for k, v in cells.items() if re.match(r"^FD[CPRSE]+$", k))
        out.update({"LUT": lut, "FF": ff, "DSP": cells.get("DSP48E1", 0) + cells.get("DSP48E2", 0),
                    "CARRY": cells.get("CARRY4", 0) + cells.get("CARRY8", 0),
                    "MUXF": cells.get("MUXF7", 0) + cells.get("MUXF8", 0)})
    else:
        tot = re.search(r"Number of cells:\s+(\d+)", sec) or re.search(r"^\s+(\d+)\s+cells\s*$", sec, re.M)
        out["cell_count"] = int(tot.group(1)) if tot else sum(cells.values())
    return out


def synth_block(cfg: str, name: str, module: str, params: dict, target: str, timeout: int,
                sub: str = "", quick_abc: bool = False) -> dict:
    wd = ROOT / "build" / "synth" / (cfg + sub)
    wd.mkdir(parents=True, exist_ok=True)
    cache = wd / f"{name}.json"
    if cache.exists():
        return json.loads(cache.read_text())
    (wd / f"{name}.ys").write_text(ys_script(module, params, target, quick_abc))
    t0 = time.time()
    try:
        r = _yosys(wd / f"{name}.ys", wd / f"{name}.log", timeout)
        txt = (wd / f"{name}.log").read_text() if (wd / f"{name}.log").exists() else r.stdout
        res = parse_stat(txt, target) if r.returncode == 0 else {"error": (r.stderr or r.stdout)[-800:]}
    except subprocess.TimeoutExpired:
        res = {"error": f"timeout after {timeout} s"}
    res["seconds"] = round(time.time() - t0, 1)
    if quick_abc:
        res["note"] = "minimal ABC mapping (strash; map)"
    cache.write_text(json.dumps(res, indent=2))
    return res


def check(cfg: str) -> dict:
    p = CONFIGS[cfg]["params"]
    chp = " ".join(f"-set {k} {v}" for k, v in p.items())
    script = (_read_cmd() + f"chparam {chp} silica_flux_top\nhierarchy -check -top silica_flux_top\nproc\n"
              f"check -assert\n")
    wd = ROOT / "build" / "synth" / cfg
    wd.mkdir(parents=True, exist_ok=True)
    (wd / "check.ys").write_text(script)
    t0 = time.time()
    r = _yosys(wd / "check.ys", wd / "check.log", 7200)
    log = (wd / "check.log").read_text() if (wd / "check.log").exists() else ""
    latches = len(re.findall(r"Latch inferred", log))
    return {"elaborates": r.returncode == 0, "latches": latches, "seconds": round(time.time() - t0, 1),
            "error": None if r.returncode == 0 else (r.stderr or "")[-600:]}


def mirror(cfg: str, rep: dict):
    """keep a copy next to the synthesis inputs (synthesis/reports/)"""
    d = ROOT / "synthesis" / "reports"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{cfg}.json").write_text(json.dumps(rep, indent=2))


def main(argv):
    if YOSYS is None:
        print("Yosys not found (pip install yowasp-yosys)")
        return 2
    do_check = "--check" in argv
    jobs = next((int(a.split("=")[1]) for a in argv if a.startswith("--jobs=")), 3)
    timeout = next((int(a.split("=")[1]) for a in argv if a.startswith("--timeout=")), 3600)
    lane_scale = next((int(a.split("=")[1]) for a in argv if a.startswith("--lane-scale=")), 0)
    # reuse wider lane-scaled syntheses of the same config where they exist (more accurate scaling)
    prefer = next((int(a.split("=")[1]) for a in argv if a.startswith("--prefer-lanes=")), 0)
    quick = set(next((a.split("=")[1].split(",") for a in argv if a.startswith("--quick-abc=")), []))
    names = [a for a in argv if not a.startswith("--")] or list(CONFIGS)
    out_dir = ROOT / "reports" / "synth"
    out_dir.mkdir(parents=True, exist_ok=True)
    for cfg in names:
        c = CONFIGS[cfg]
        rep = {"config": cfg, "description": c["description"], "params": c["params"], "target": c["target"],
               "clock_mhz_assumed": c["clock_mhz"], "estimate": True}
        if do_check:
            rep["check"] = check(cfg)
            print(f"[synth] {cfg}: full-chip elaboration {'OK' if rep['check']['elaborates'] else 'FAILED'} "
                  f"latches={rep['check']['latches']} ({rep['check']['seconds']} s)", flush=True)
            prev = out_dir / f"{cfg}.json"
            if prev.exists():
                old = json.loads(prev.read_text())
                old["check"] = rep["check"]
                rep = old
            (out_dir / f"{cfg}.json").write_text(json.dumps(rep, indent=2))
            mirror(cfg, rep)
            continue
        tot = {}
        rep["blocks"] = {}
        L = c["params"]["VECTOR_LANES"]
        n_syn = lane_scale if lane_scale and lane_scale < L else L
        p_syn = dict(c["params"], VECTOR_LANES=n_syn)
        factor = L / n_syn
        sub = f"_l{n_syn}" if n_syn != L else ""
        if n_syn != L:
            rep["method"] = (f"blocks synthesized at {n_syn} lanes (format, depth, divider radix as configured); "
                             f"lane-proportional blocks x{factor:g}")
        bl = blocks(p_syn)
        keys = ("LUT", "FF", "DSP", "CARRY") if c["target"] == "xilinx" else ("cell_count", "transistors")
        with ThreadPoolExecutor(max_workers=jobs) as ex:
            futs = {name: ex.submit(synth_block, cfg, name, mod, params, c["target"], timeout, sub, name in quick)
                    for name, mod, params, _ in bl}
            for name, mod, params, inst in bl:
                r = futs[name].result()
                sc = factor if name in LANE_SCALED else 1.0
                lanes_used = n_syn
                wide = ROOT / "build" / "synth" / f"{cfg}_l{prefer}" / f"{name}.json"
                if prefer > n_syn and name in LANE_SCALED and wide.exists():
                    rw = json.loads(wide.read_text())
                    if "error" not in rw:
                        r, sc, lanes_used = rw, L / prefer, prefer
                rep["blocks"][name] = dict(r, instances=inst, lane_scale=sc, synth_lanes=lanes_used)
                for k in keys:
                    if k in r:
                        tot[k] = tot.get(k, 0) + inst * sc * r[k]
                print(f"[synth] {cfg:<11} {name:<17} " + "  ".join(f"{k}={r.get(k)}" for k in keys) +
                      (f" x{sc:g}" if sc != 1 else "") +
                      (f"  ERROR {r['error'][:80]}" if "error" in r else "") + f"  ({r['seconds']} s)", flush=True)
        tot = {k: int(round(v)) if k != "transistors" else v for k, v in tot.items()}
        notes = []
        if quick:
            notes.append(f"{', '.join(sorted(quick))}: minimal ABC mapping (strash; map) -- measured 10 % above the "
                         "default flow on reduction (1.097) and objective (1.105) at 2 lanes FP64")
        if prefer > n_syn:
            used = sorted(n for n, v in rep["blocks"].items() if v.get("synth_lanes") == prefer)
            rep["method"] = (f"blocks synthesized at {prefer} lanes where available ({', '.join(used)}; x{L / prefer:g}), "
                             f"otherwise at {n_syn} lanes (x{factor:g}); control blocks as measured")
            lin = {}
            for f in sorted((ROOT / "build" / "synth" / f"{cfg}_l{prefer}").glob("*.json")):
                a_, b_ = json.loads(f.read_text()), ROOT / "build" / "synth" / f"{cfg}{sub}" / f.name
                k = keys[0]
                if b_.exists() and k in a_ and k in json.loads(b_.read_text()):
                    nb = json.loads(b_.read_text())[k]
                    lin[f.stem] = {f"{k}_{prefer}_lanes": a_[k], f"{k}_{n_syn}_lanes_x{prefer // n_syn}": nb * (prefer // n_syn),
                                   "ratio": round(a_[k] / (nb * (prefer // n_syn)), 3)}
            rep[f"linearity_check_{prefer}_vs_{n_syn}_lanes"] = lin
            if any(v["ratio"] < 0.9 for v in lin.values()):
                notes.append("scalar logic inside lane-scaled blocks (timestep FMA in state_update, relative-residual "
                             "divider in conservation) is multiplied with the lanes; blocks scaled from the narrow "
                             "synthesis that contain such logic are upper bounds")
        if notes:
            rep["notes"] = notes
        if n_syn != L:                                   # check the scaling against full-width syntheses
            chk = {}
            for f in sorted((ROOT / "build" / "synth" / f"{cfg}_full").glob("*.json")):
                full = json.loads(f.read_text())
                part = rep["blocks"].get(f.stem, {})
                k = keys[0]
                if k in full and k in part and part[k]:
                    sc_b = part.get("lane_scale", factor)
                    chk[f.stem] = {f"{k}_full_width": full[k], f"{k}_scaled": round(part[k] * sc_b),
                                   "scaled_from_lanes": part.get("synth_lanes", n_syn),
                                   "ratio_full_over_scaled": round(full[k] / (part[k] * sc_b), 3)}
            rep["scaling_check"] = chk
        rep["blocks_failed"] = sorted(n for n, r in rep["blocks"].items() if "error" in r)
        mem = memory_bits(c["params"])
        rep["memory_bits"] = mem
        rep["memory_total_kbit"] = round(sum(mem.values()) / 1024, 1)
        if c["target"] == "xilinx":
            rep["bram36_estimate"] = sum(-(-b // 36864) for k, b in mem.items() if "register file" not in k)
            rep["logic_total"] = tot
        else:
            rep["logic_total"] = tot
            rep["sram_kbit"] = rep["memory_total_kbit"]
        prev = out_dir / f"{cfg}.json"
        if prev.exists() and "check" in json.loads(prev.read_text()):
            rep["check"] = json.loads(prev.read_text())["check"]      # keep the elaboration result
        (out_dir / f"{cfg}.json").write_text(json.dumps(rep, indent=2))
        mirror(cfg, rep)
        print(f"[synth] {cfg}: {rep['logic_total']}  memory {rep['memory_total_kbit']} Kbit", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
