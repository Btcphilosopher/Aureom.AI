## Silica Flux -- small FPGA build (8 lanes, binary32), 100 MHz system clock
create_clock -name clk -period 10.000 [get_ports clk]
set_input_delay  -clock clk 2.000 [get_ports {s_axil_* s_axis_* rst_n}]
set_output_delay -clock clk 2.000 [get_ports {s_axil_* m_axis_* s_axis_tready irq}]
## reset is synchronous and synchronised externally; the AXI interfaces are
## register-sliced inside the fabric (axi_stream skid buffers, AXI-Lite slave)
set_false_path -from [get_ports rst_n]
