# Silica Flux -- ASIC-oriented build (16 lanes, binary64), 1.0 GHz target
# Generic SDC; library-specific derates and uncertainties belong to the
# implementation flow.  All memories are expected to be SRAM macros
# (sf_row_ram, vector_register_file -> 2R1W register-file compiler output).
create_clock -name clk -period 1.000 [get_ports clk]
set_clock_uncertainty 0.050 [get_clocks clk]
set_input_delay  -clock clk 0.200 [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay -clock clk 0.200 [all_outputs]
set_false_path -from [get_ports rst_n]
set_max_fanout 32 [current_design]
