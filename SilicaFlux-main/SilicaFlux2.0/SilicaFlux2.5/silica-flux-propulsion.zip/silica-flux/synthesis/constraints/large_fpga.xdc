## Silica Flux -- large FPGA build (32 lanes, binary32, PIPELINE_DEPTH 6), 250 MHz
create_clock -name clk -period 4.000 [get_ports clk]
set_input_delay  -clock clk 0.800 [get_ports {s_axil_* s_axis_* rst_n}]
set_output_delay -clock clk 0.800 [get_ports {s_axil_* m_axis_* s_axis_tready irq}]
set_false_path -from [get_ports rst_n]
## the two extra FMA output slices (PIPELINE_DEPTH > 4) exist for retiming:
## enable register balancing on the multiplier / alignment stages
## (Vivado: synth_design -retiming)
