# Verilator flow

| File | Purpose |
|---|---|
| `run_lint.py` | `verilator --lint-only -Wall` for every synthesis configuration; PASS = zero errors and zero functional-category warnings (`reports/lint.json`) |
| `lint_waivers.vlt` | file- and message-scoped waivers (style categories only) |
| `sources.f` | include paths + RTL file list (`verilator -f verilator/sources.f ...`) |

Simulation builds:

* full chip: `python/silica_flux/rtl_backend.py` (`make verilate`) builds
  `tb/tb_top.sv` + RTL + `formal/assertions.sv` with `--binary --timing --assert +define+SF_SVA`
  into `build/verilator/tb_top_<fp>_l<lanes>_d<depth>/`;
* unit testbenches: `tb/run_testbenches.py --sim verilator` (`make sv`).

Tested with Verilator 5.020.
