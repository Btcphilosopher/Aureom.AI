#!/usr/bin/env python3
"""
Verilator lint of the complete RTL (all synthesis configurations).

    python3 verilator/run_lint.py

`verilator --lint-only -Wall` with verilator/lint_waivers.vlt, for each
synthesis configuration's parameters.  PASS requires zero errors and zero
warnings in the *functional* categories (anything other than the style-only
UNUSED* / DECLFILENAME family).  Style-only warnings that remain after the
scoped waivers are counted and listed, not hidden.  Result: reports/lint.json
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STYLE = {"UNUSEDSIGNAL", "UNUSEDPARAM", "UNUSEDGENVAR", "DECLFILENAME", "UNUSED"}


def lint(params: dict) -> dict:
    srcs = [l.strip() for l in (ROOT / "rtl/sources.f").read_text().splitlines() if l.strip()]
    cmd = ["verilator", "--lint-only", "-Wall", "-Irtl/core", "-Irtl/math/generated",
           "--top-module", "silica_flux_top", "verilator/lint_waivers.vlt"] + \
          [f"-G{k}={v}" for k, v in params.items()] + srcs
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    txt = r.stdout + r.stderr
    cats = Counter(re.findall(r"%Warning-([A-Z_0-9]+):", txt))
    errors = [l for l in txt.splitlines() if l.startswith("%Error") and "Exiting due to" not in l]
    functional = {k: v for k, v in cats.items() if k not in STYLE}
    return {"params": params, "warnings": dict(cats), "functional_warnings": functional,
            "errors": errors[:10], "pass": not errors and not functional,
            "functional_detail": [l for l in txt.splitlines()
                                  if re.match(r"%Warning-([A-Z_0-9]+):", l)
                                  and re.match(r"%Warning-([A-Z_0-9]+):", l).group(1) not in STYLE][:20]}


def main():
    cfgs = json.loads((ROOT / "synthesis/configs.json").read_text())
    res = {}
    for name, c in cfgs.items():
        p = {k: v for k, v in c["params"].items()}
        res[name] = lint(p)
        r = res[name]
        print(f"[lint] {name:<11} {'PASS' if r['pass'] else 'FAIL'}  functional={sum(r['functional_warnings'].values())} "
              f"style={sum(v for k, v in r['warnings'].items() if k in STYLE)}  errors={len(r['errors'])}")
        for l in r["functional_detail"][:5]:
            print("      " + l)
    ok = all(r["pass"] for r in res.values())
    style = max(sum(v for k, v in r["warnings"].items() if k in STYLE) for r in res.values())
    summary = (f"PASS (0 errors, 0 functional warnings; {style} style-only UNUSED* warnings listed in reports/lint.json)"
               if ok else "FAIL")
    out = {"summary": summary, "configs": res}
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "lint.json").write_text(json.dumps(out, indent=2))
    print("LINT:", summary)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
