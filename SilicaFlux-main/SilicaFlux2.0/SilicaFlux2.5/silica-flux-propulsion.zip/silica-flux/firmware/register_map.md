# Silica Flux — Register Map

AXI4-Lite slave, 16-bit byte address, 32-bit registers. Implemented in
`rtl/top/silica_flux_top.sv`; mirrored in `python/silica_flux/regmap.py`
(the host driver and every test use that file, so the documentation, the
driver and the RTL cannot drift apart silently — the full-chip regression
reads most of these registers back and compares them with the reference model).

Access types: **RO** read-only, **RW** read/write, **WO** write-only (reads 0),
**W1C** write-1-to-clear, **W1P** write-1-pulse (self-clearing command).

**64-bit values** (tolerances, sweep bounds, tableau entries, ...) are written
as a LO/HI pair: writing LO stages the low word, writing HI commits
`{HI, LO}` atomically. FP32 builds use the low 32 bits but still require the
HI write to commit. Reads return the committed value.

```mermaid
flowchart TB
  subgraph CSR["AXI4-Lite register space"]
    A["0x000-0x05C<br/>identity, control, status,<br/>faults, watchdog, timestamp"]
    B["0x060-0x0D0<br/>performance counters"]
    C["0x100-0x144<br/>memory window + precision tags"]
    D["0x180-0x188<br/>instruction memory window"]
    E["0x200-0x2F8<br/>engine configuration / results"]
    F["0x300-0x31C<br/>DMA"]
    G["0x380-0x3C8<br/>telemetry"]
  end
  Host -->|AXI4-Lite| CSR
  Host -->|AXI4-Stream in| DMA[DMA / telemetry] --> MEM[(on-chip memories)]
  MEM -->|AXI4-Stream out| Host
```

## 1. Identity, control and status

| Addr | Name | Access | Description |
|---|---|---|---|
| 0x000 | `ID` | RO | `0x53464C58` ("SFLX") |
| 0x004 | `VERSION` | RO | `0x00010000` (1.0) |
| 0x008 | `CONFIG0` | RO | `[7:0]` VECTOR_LANES, `[15:8]` DATA_WIDTH, `[16]` FP_MODE, `[23:20]` PIPELINE_DEPTH, `[27:24]` DIV_BPC |
| 0x00C | `CONFIG1` | RO | `[15:0]` IMEM_DEPTH, `[31:16]` SCRATCHPAD_SIZE |
| 0x010 | `CTRL` | W1P | `[0]` START (clears abort, initialises the job state — `a0`–`a7` = 0, `VM` = all ones, every vector register marked unwritten — and starts at `START_PC`; register contents, memories and engine configuration persist), `[1]` ABORT, `[4]` inject IMEM parity error (test), `[5]` arm memory parity injection for memory `[10:8]` (test), `[6]` raise HOST fault |
| 0x014 | `STATUS` | RO | `[0]` RUNNING, `[1]` DONE, `[2]` HALTED (by fault), `[3]` DMA_BUSY, `[4]` telemetry FRAME pending, `[5]` SWEEP_DONE, `[6]` local search CONVERGED, `[7]` TS_VALID (integrator configured), `[8]` IRQ |
| 0x018 | `START_PC` | RW | `[15:0]` program entry point |
| 0x01C | `PC` | RO | current program counter |
| 0x020 | `FRM` | RW | `[2:0]` dynamic rounding mode (0 RNE, 1 RTZ, 2 RDN, 3 RUP, 4 RMM; 5–7 make DYN instructions ILLEGAL) |
| 0x024 | `IRQ_ENABLE` | RW | `[0]` done, `[1]` fault |
| 0x028 | `IRQ_STATUS` | W1C | `[0]` done (rising edge), `[1]` fault |
| 0x02C | `FFLAGS` | W1C | accumulated IEEE flags `[4]` NV `[3]` DZ `[2]` OF `[1]` UF `[0]` NX |

## 2. Faults

| Addr | Name | Access | Description |
|---|---|---|---|
| 0x030 | `FAULT_STATUS` | W1C | one sticky bit per fault id (table below) |
| 0x034 | `FAULT_ENABLE` | RW | events of disabled ids are not recorded (reset: all enabled) |
| 0x038 | `FAULT_HALT` | RW | recorded faults in this mask halt the core (reset: see below) |
| 0x03C | `FAULT_FIRST` | RO | `[31]` valid, `[4:0]` id of the first fault since the last full clear |
| 0x040 | `FAULT_PC` | RO | PC of the first fault |
| 0x044 | `FAULT_TIME` | RO | timestamp of the first fault |
| 0x048 | `FAULT_COUNT` | RO | number of fault events (monotonic) |
| 0x04C | `WDT_LIMIT` | RW | progress watchdog: cycles without issue / retirement while running before `WATCHDOG` (0 = off; reset 100000) |
| 0x050 | `DMA_TIMEOUT` | RW | cycles a busy DMA transfer may go without a beat before it is aborted with `TIMEOUT` (0 = off; reset 100000) |
| 0x054 | `TSTAMP` | RO | free-running timestamp |
| 0x058 | `TS_PRESCALE` | RW | `[15:0]` timestamp prescaler |

The first-fault record is released only when software clears **every** status
bit; until then later faults are counted and OR-ed into `FAULT_STATUS` but do
not overwrite the first record. There is no silent recovery path: a halted
core stays halted until the host clears the faults and restarts it.

### Fault identifiers

| Id | Name | Source | Halts by default |
|---|---|---|---|
| 0 | `WATCHDOG` | progress watchdog expired (e.g. `BARRIER TELEM` starved) | yes |
| 1 | `TIMEOUT` | DMA transfer stalled beyond `DMA_TIMEOUT` | yes |
| 2 | `ILLEGAL` | unknown opcode, reserved rm, unsupported precision, `vl > LANES` | yes |
| 3 | `PRECISION` | source format / fixed-point scale mismatch, mixed-format partial write | yes |
| 4 | `NAN` | invalid operation (NV) | yes |
| 5 | `OVERFLOW` | OF (FP) or saturation (fixed / int) | yes |
| 6 | `UNDERFLOW` | UF | no |
| 7 | `DIVZERO` | DZ | yes |
| 8 | `RANGE` | telemetry value outside its channel bounds | no |
| 9 | `PARITY` | instruction-memory or data-memory parity error | yes |
| 10 | `MEMADDR` | LSU / DMA address outside the memory, store to TELEM | yes |
| 11 | `TL_SEQ` | telemetry sequence gap / repeat on a channel | no |
| 12 | `TL_CRC` | telemetry CRC-16 mismatch (packet dropped) | no |
| 13 | `TL_TS` | telemetry timestamp not increasing, or gap > `TL_MAX_GAP` | no |
| 14 | `TL_OVF` | telemetry buffer overflow (packet dropped, counted) | no |
| 15 | `CONSERVATION` | conserved quantity outside tolerance | no |
| 16 | `RESIDUAL` | residual outside tolerance | no |
| 17 | `PIPELINE` | internal consistency check (lockstep / retirement) | yes |
| 18 | `STEP` | invalid dt or out-of-sequence integration stage | yes |
| 19 | `TL_MALFORMED` | telemetry framing error (bad length / TLAST) | no |
| 20 | `UNINIT` | read of a never-written vector register | yes |
| 21 | `CONSTRAINT` | constraint evaluation reported FAIL lanes (informational) | no |
| 22 | `SEARCH` | invalid sweep / search configuration, NaN objective at the search centre | no |
| 23 | `HOST` | raised by software (`CTRL[6]`) | yes |

## 3. Performance counters (RO)

| Addr | Name | Counts |
|---|---|---|
| 0x060 | `PERF_CYCLES` | cycles while running |
| 0x064 | `PERF_RETIRED` | retired instructions |
| 0x068 | `PERF_ISSUED` | issued vector instructions |
| 0x06C | `PERF_STALLS` | cycles with a valid head that could not issue |
| 0x070 | `PERF_LANE_OPS` | active lane-operations retired |
| 0x074 / 0x078 | `PERF_LOADS` / `PERF_STORES` | vector loads / stores |
| 0x07C | `PERF_STATE_UPD` | lane-state updates committed by the state engine |
| 0x080 + 4·fu | `PERF_FU_BUSY[fu]` | busy cycles of functional unit `fu` (0 CTRL … 14 SEARCH) |
| 0x0C0 / 0x0C4 | `BUS_ACCESSES` / `BUS_CONFLICTS` | internal-bus transactions / arbitration losses |
| 0x0C8 / 0x0CC | `RESULT_WRITES` / `RESULT_HWM` | result-memory writes / highest row written |
| 0x0D0 | `STATE_BANK` | active STATE ping-pong bank |

## 4. Memory window (host access to on-chip memories)

| Addr | Name | Access | Description |
|---|---|---|---|
| 0x100 | `MEM_SEL` | RW | memory id: 0 STATE, 1 STATE_N, 2 PARAM, 3 COEFF, 4 SCRATCH, 5 RESULT, 6 TELEM |
| 0x104 | `MEM_ROW` | RW | row |
| 0x108 | `MEM_LANE` | RW | lane |
| 0x10C / 0x110 | `MEM_WLO` / `MEM_WHI` | RW | element value to write |
| 0x114 | `MEM_WQUAL` | RW | `[3:0]` quality bits to write |
| 0x118 | `MEM_CMD` | W1P | `1` write element, `2` read element (ignored while pending) |
| 0x11C / 0x120 | `MEM_RLO` / `MEM_RHI` | RO | element read back |
| 0x124 | `MEM_RSTATUS` | RO | `[31]` pending, `[9]` address error, `[8]` parity error, `[3:0]` quality |
| 0x128 + 4·m | `MEM_PREC[m]` | RW | `[2:0]` precision tag, `[13:8]` fixed-point scale of memory `m`; loads set the register metadata from these tags |

Bulk transfers use the DMA (§7); the window is for configuration and debug.

## 5. Instruction memory

| Addr | Name | Access | Description |
|---|---|---|---|
| 0x180 | `IMEM_ADDR` | RW | word address |
| 0x184 | `IMEM_WLO` | WO | instruction bits [31:0] (staged) |
| 0x188 | `IMEM_WHI` | WO | instruction bits [63:32]; writes the word with parity and increments `IMEM_ADDR` |

## 6. Engine configuration and observability

| Addr | Name | Access | Description |
|---|---|---|---|
| 0x200/0x204 | `RES_RTOL` | RW (64) | residual relative tolerance |
| 0x208/0x20C | `CONS_ATOL` | RW (64) | conservation absolute tolerance |
| 0x210/0x214 | `CONS_RTOL` | RW (64) | conservation relative tolerance |
| 0x218 | `RES_VIOL` | RO | residual lane violations |
| 0x21C | `CONS_VIOL` | RO | conservation violations |
| 0x220/0x224 | `CONS_RESID` | RO (64) | last conservation residual `I − E` |
| 0x228/0x22C | `CONS_REF` | RO (64) | conservation reference |
| 0x230 / 0x234 | `CON_PASS` / `CON_FAIL` | RO | constraint lane pass / fail counts |
| 0x238 | `CON_MASK` | RO | last constraint pass mask |
| 0x240/0x244 | `TS_T` | RO (64) | simulated time t |
| 0x248/0x24C | `TS_DT` | RO (64) | dt |
| 0x250 | `TS_STEP` | RO | committed steps |
| 0x254 | `TS_STAGES` | RW | stages of the CUSTOM tableau (1–4) |
| 0x258 | `TS_TAB_SEL` | RW | CUSTOM tableau slot: 0–5 = A(1,0) A(2,0) A(2,1) A(3,0) A(3,1) A(3,2); 6–9 = b0..b3 |
| 0x25C/0x260 | `TS_TAB` | WO (64) | value of the selected slot |
| 0x280 | `SW_DIMS` | RW | sweep dimensions (1–4) |
| 0x284 | `SW_DSEL` | RW | dimension selector for the next three registers |
| 0x288/0x28C | `SW_LO` | WO (64) | lower bound of dimension `SW_DSEL` |
| 0x290/0x294 | `SW_STEP` | WO (64) | step of dimension `SW_DSEL` |
| 0x298 | `SW_COUNT` | RW | points of dimension `SW_DSEL` (1–65535) |
| 0x29C | `SW_BASE` | RO | index of the first candidate of the current batch |
| 0x2A0 | `SW_TOTAL` | RO | total candidates (< 2³²) |
| 0x2A4 | `SW_STATUS` | RO | `[0]` done, `[1]` configuration valid |
| 0x2C0 | `LS_DIMS` | RW | local-search dimensions (1 – min(4, (L−1)/2)) |
| 0x2C4 | `LS_DSEL` | RW | dimension selector |
| 0x2C8 | `LS_FSEL` | RW | field: 0 lower bound, 1 upper bound, 2 initial centre, 3 initial step, 4 minimum step |
| 0x2CC/0x2D0 | `LS_VAL` | WO (64) | value of the selected field / dimension |
| 0x2D4 | `LS_MAX_ITER` | RW | iteration limit (reset 64) |
| 0x2D8/0x2DC | `SR_BEST` | RO (64) | best objective found |
| 0x2E0 | `SR_BEST_IDX` | RO | sweep index of the best candidate (`0xFFFFFFFF` = none) |
| 0x2E4 | `LS_ITER` | RO | local-search iterations |
| 0x2E8 | `LS_STATUS` | RO | `[0]` converged |
| 0x2EC/0x2F0 | `LS_CENTER` | RO (64) | current centre of dimension `LS_DSEL` |
| 0x2F4/0x2F8 | `LS_STEP` | RO (64) | current step of dimension `LS_DSEL` |

## 7. DMA

| Addr | Name | Access | Description |
|---|---|---|---|
| 0x300 | `DMA_CTRL` | W1P | `[0]` start, `[2:1]` direction: 0 S2M (stream → memory), 1 M2S (memory → stream), 2 S2T (stream → telemetry ingest) |
| 0x304 | `DMA_MEM` | RW | memory id |
| 0x308 | `DMA_ROW` | RW | first row |
| 0x30C | `DMA_LEN` | RW | S2M / M2S: elements (row-major, one element per 64-bit beat); S2T: packets |
| 0x310 | `DMA_STATUS` | RO | `[0]` busy, `[1]` done, `[2]` error |
| 0x314 | `DMA_COUNT` | RO | elements / packets transferred |
| 0x318 / 0x31C | `DMA_IN_BEATS` / `DMA_OUT_BEATS` | RO | AXI-Stream beats accepted / emitted |

S2M beats carry the element in `TDATA[W-1:0]` and its quality in `TUSER[3:0]`;
M2S emits the same format with `TUSER = {parity_error, 3'b0, quality}` and TLAST on the final element.

## 8. Telemetry

| Addr | Name | Access | Description |
|---|---|---|---|
| 0x380 | `TL_STATUS` | RO | `[31]` frame pending, `[7:0]` buffer level |
| 0x384 | `TL_RX` | RO | packets received |
| 0x388 | `TL_ACCEPTED` | RO | packets accepted |
| 0x38C | `TL_DROPPED` | RO | packets dropped (CRC / malformed / overflow) |
| 0x390 … 0x3A4 | `TL_CRC`, `TL_SEQ`, `TL_TS`, `TL_OVF`, `TL_RANGE`, `TL_MALFORMED` | RO | anomaly counters |
| 0x3A8 | `TL_FRAMES` | RO | complete frames received |
| 0x3AC | `TL_LAST_DELTA` | RO | timestamp delta of the last accepted packet |
| 0x3B0 | `TL_MAX_GAP` | RW | maximum accepted timestamp gap (0 = unchecked) |
| 0x3B4 | `TL_BOUND_CHAN` | RW | channel whose range bounds are written next |
| 0x3B8/0x3BC | `TL_BOUND_LO` | WO (64) | lower bound |
| 0x3C0/0x3C4 | `TL_BOUND_HI` | WO (64) | upper bound; writing the HI word commits both bounds for the channel |
| 0x3C8 | `TL_CTRL` | W1P | `[0]` reset the telemetry state (sequence, timestamps, table, counters) |

### Telemetry packet format (3 × 64-bit AXI-Stream beats)

| Beat | Bits | Field |
|---|---|---|
| 0 | `[63:32]` | timestamp |
| 0 | `[31:16]` | sequence number (per channel) |
| 0 | `[15:8]` | channel |
| 0 | `[7:0]` | qualifier: `[0]` sensor-reported invalid, `[7]` frame end |
| 1 | `[63:0]` | value (FP32 builds use `[31:0]`) |
| 2 | `[15:0]` | CRC-16/CCITT-FALSE over the 16 bytes of beats 0–1 (little-endian) |

Validation order (`rtl/telemetry/telemetry_ingest.sv`):

| Check | Action |
|---|---|
| framing (TLAST position) | `TL_MALFORMED`, packet dropped |
| CRC | `TL_CRC`, packet dropped |
| channel ≥ N_CHAN | `TL_MALFORMED`, packet dropped |
| sequence gap | `TL_SEQ`, missing packets added to `TL_DROPPED`, sample kept |
| sequence duplicate / reorder | `TL_SEQ`, packet dropped |
| timestamp discontinuity | `TL_TS`, sample kept with `Q_SUSPECT` |
| value outside `[lo, hi]` or NaN | `RANGE`, sample kept with `Q_SUSPECT` (`|Q_NAN` for NaN) |
| sensor-invalid qualifier | sample kept with `Q_SUSPECT` |

Nothing is repaired or interpolated: an anomalous sample either is dropped
and counted, or is kept and carries its quality bits into every computation
that consumes it. Accepted samples are written into the
`TELEM` table (row `chan / L`, lane `chan mod L`) where programs read them
with `VLOAD`/`VLDBC`; a frame-end packet increments the frame counter that
`BARRIER TELEM` consumes.

## 9. Programming sequence

```text
1. read ID / CONFIG0 / CONFIG1                       identify the build
2. write MEM_PREC[*]                                  declare the data format of each memory
3. DMA S2M: STATE, PARAM, COEFF                       load model data (quality in TUSER)
4. IMEM_ADDR = 0; { IMEM_WLO, IMEM_WHI } x N          load the program
5. write tolerances, tableau, sweep / search config, telemetry bounds
6. FAULT_ENABLE / FAULT_HALT / WDT_LIMIT, IRQ_ENABLE
7. START_PC = 0; CTRL = START
8. poll STATUS (or wait for irq); on HALTED read FAULT_FIRST / FAULT_PC / FAULT_STATUS
9. DMA M2S: RESULT (+ STATE) -> host; read perf counters
```

`python/silica_flux/driver.py` implements exactly this sequence.
