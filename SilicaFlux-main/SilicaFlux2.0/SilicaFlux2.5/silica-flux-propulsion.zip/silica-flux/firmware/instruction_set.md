# Silica Flux — Instruction Set (Flux DSL ISA v1.0)

The Flux ISA is a small vector instruction set for **numerical computing**: it
describes *how* to evaluate a mathematical model, never *which* physical
system is being modelled. A program is a sequence of 64-bit words loaded into
the instruction memory (`IMEM`) by the host and executed by `flux_core`.

The single source of truth for the encoding is `rtl/core/flux_pkg.sv`, mirrored
bit-for-bit in `python/golden_model/isa.py`. Exact per-element semantics are
the executable golden model (`python/golden_model/{ieee,valu,sfu,engines}.py`);
the RTL is verified for **bit-exact** agreement with it.

```mermaid
flowchart LR
  H[Host / Python API] -->|assemble| A[generators/assembler.py]
  A -->|64-bit words| I[(IMEM)]
  I --> F[fetch + 2-entry decode queue]
  F --> S[scheduler: legality, precision,<br/>RAW/WAW scoreboard]
  S -->|uop| D[dispatch]
  D --> U1[VALU] & U2[DIV/SQRT] & U3[SFU] & U4[LSU] & U5[engines ...]
  U1 & U2 & U3 & U4 & U5 --> R[retirement: in-order commit,<br/>flags, faults, quality]
```

## 1. Programmer's model

| Resource | Size | Notes |
|---|---|---|
| `v0`–`v31` | 32 vector registers × `VECTOR_LANES` elements × `DATA_WIDTH` bits | each element carries a 4-bit **quality** field |
| register metadata | per register: `valid`, `prec`, `scale`, `source`, `tstamp` | checked at issue (see §5) |
| `VM` | 1 bit per lane | written by `VCMP`, `VMSET`, `RESIDUAL`, `CONSTRAINT`, `SWEEP`, `SEARCH` |
| `a0`–`a7` | 20-bit address / loop registers | `SETA`, `ADDA`, `BNZ`, LSU effective address |

**Job state.** Every `START` sets `a0`–`a7` to 0, `VM` to all ones and marks
all 32 vector registers *unwritten*: a program cannot silently consume a value
left behind by an earlier job (reading it raises `UNINIT`). Register
contents, memories and engine configuration (tableau, tolerances, sweep and
search set-up) persist across jobs.

| `FRM` | dynamic rounding mode (CSR) | used when an instruction encodes `rm = DYN (7)` |
| `FFLAGS` | sticky IEEE flags NV DZ OF UF NX (CSR) | accumulated at retirement |
| engine state | timestep (t, dt, step, tableau), conservation reference, sweep digits, search state | owned by the engines, observable via CSRs |

Element formats (`prec` field):

| `prec` | Name | Meaning |
|---|---|---|
| 0 | `FP32` | IEEE-754 binary32 (FP32 builds) |
| 1 | `FP64` | IEEE-754 binary64 (FP64 builds) |
| 2 | `SFIX` | signed fixed point, `DATA_WIDTH` bits, F fractional bits = `imm[5:0]` |
| 3 | `UFIX` | unsigned fixed point, F = `imm[5:0]` |
| 4 | `INT`  | two's-complement integer (fixed point with F = 0) |

A build implements **one** native floating-point format (`FP_MODE`); using the
other FP format is an `ILLEGAL` instruction, never a silent conversion.
Fixed-point and integer arithmetic **saturates** and raises OF — it never wraps.

### Quality bits (per element)

| Bit | Name | Set when |
|---|---|---|
| 0 | `Q_NAN` | result is NaN or the operation raised NV |
| 1 | `Q_OVF` | the operation overflowed (OF) or produced ±Inf from finite inputs |
| 2 | `Q_UNF` | the result underflowed (UF) |
| 3 | `Q_SUSPECT` | derived from suspect input: out-of-table interpolation, failed residual / constraint / conservation, refused integration step, parity error on load, flagged telemetry |

Quality is **OR-propagated** from every source element that contributes to a
result, stored with the element in every memory (protected by parity) and
returned to the host. A suspect value therefore cannot silently become a
clean one.

## 2. Encoding

```
 63      56 55  51 50  46 45  41 40  36 35 33 32 30  29   28   23 22  19 18              0
+----------+------+------+------+------+-----+-----+----+--------+------+-----------------+
|  opcode  |  vd  | vs1  | vs2  | vs3  |prec | rm  | m  |   vl   | func |      imm        |
+----------+------+------+------+------+-----+-----+----+--------+------+-----------------+
```

| Field | Bits | Meaning |
|---|---|---|
| `opcode` | 63:56 | operation (§3) |
| `vd` | 55:51 | destination register (also `aN` index for `SETA`/`ADDA`) |
| `vs1`,`vs2`,`vs3` | 50:36 | sources (`vs2[2:0]` is the LSU address register) |
| `prec` | 35:33 | element format (§1) |
| `rm` | 32:30 | rounding: 0 RNE, 1 RTZ, 2 RDN, 3 RUP, 4 RMM, 7 DYN (= `FRM`); 5,6 → `ILLEGAL` |
| `m` | 29 | masked: lane active only if `VM[lane] = 1` |
| `vl` | 28:23 | active lanes `0..vl-1`; `0` = all lanes |
| `func` | 22:19 | sub-operation |
| `imm` | 18:0 | immediate (sign-extended where stated) |

**Active lane mask** `lmask = (vl == 0 ? all : lanes < vl) & (m ? VM : all)`.
Inactive lanes of `vd` keep their old value (and quality); flags are only
accumulated from active lanes.

## 3. Instructions

Notation: `L` = `VECTOR_LANES`, `x[l]` = lane `l`, `∘` = correctly rounded
operation in the instruction's rounding mode.

### 3.1 Control (FU `CTRL`, executed at issue)

| Opcode | Mnemonic | Semantics |
|---|---|---|
| 0x00 | `NOP` | — |
| 0x01 | `HALT` | waits for all in-flight work to retire, sets `STATUS.DONE` |
| 0x02 | `BARRIER func` | drains the machine; `func` bit 0 `TELEM`: wait for one complete telemetry frame (watchdog-protected); bit 1 `DMA`: wait for DMA idle; bit 2 `SWAP`: swap the `STATE`/`STATE_N` ping-pong banks |
| 0x03 | `SETA aD, imm` | `a[vd&7] = imm` (19-bit, zero-extended) |
| 0x04 | `ADDA aD, simm` | `a[vd&7] += sign_extend(imm)` (mod 2²⁰) |
| 0x05 | `BNZ aS, off` | if `a[vs1&7] ≠ 0`: `a[vs1&7] -= 1`, `pc += sext(imm[15:0])`; no speculation, 2-cycle fetch bubble when taken |

### 3.2 Vector ALU (FU `VALU`, fully pipelined, latency `PIPELINE_DEPTH`)

| Opcode | Mnemonic | Lane semantics | Reads |
|---|---|---|---|
| 0x10 | `VADD` | `vd = vs1 ∘+ vs2` | vs1 vs2 |
| 0x11 | `VSUB` | `vd = vs1 ∘− vs2` | vs1 vs2 |
| 0x12 | `VMUL` | `vd = vs1 ∘× vs2` | vs1 vs2 |
| 0x13 | `VFMA` | `vd = fma(vs1, vs2, vs3)` = `vs1×vs2+vs3`, **one rounding** | vs1 vs2 vs3 |
| 0x14 | `VFMS` | `vs1×vs2−vs3`, one rounding | vs1 vs2 vs3 |
| 0x15 | `VFNMA` | `−(vs1×vs2)+vs3`, one rounding | vs1 vs2 vs3 |
| 0x16 | `VFNMS` | `−(vs1×vs2)−vs3`, one rounding | vs1 vs2 vs3 |
| 0x17 | `VSQR` | `vd = vs1 ∘× vs1` | vs1 |
| 0x18/0x19 | `VMIN`/`VMAX` | IEEE-754-2019 minimumNumber / maximumNumber (−0 < +0, a single NaN loses) | vs1 vs2 |
| 0x1A/0x1B | `VABS`/`VNEG` | sign-bit operations, no flags | vs1 |
| 0x1C | `VCMP func` | `VM = vs1 (EQ 0 / LT 1 / LE 2) vs2`; signalling rules per IEEE (LT/LE signal on NaN) | vs1 vs2 |
| 0x1D | `VSEL` | `vd = VM ? vs1 : vs2` | vs1 vs2 VM |
| 0x1E | `VMOV` | `vd = vs1` | vs1 |
| 0x1F | `VCLASS` | `vd` = IEEE class bitmap (INT result: −Inf, −norm, −sub, −0, +0, +sub, +norm, +Inf, sNaN, qNaN) | vs1 |
| 0x20 | `VCVT` | convert from `func` (source prec, source F = `imm[11:6]`) to `prec` (dest F = `imm[5:0]`), rounded per `rm`, saturating | vs1 |
| 0x21 | `VBCAST` | `vd[l] = vs1[imm[18:12] mod L]` | vs1 |
| 0x22 | `VLANEID` | `vd[l] = l` (in `prec`) | — |
| 0x23 | `VMSET func` | `VM =` ALL 0: all ones / NZ 1: `vs1 ≠ 0` / NOT 2: `~VM` / IMM 3: `imm` bits | per func |
| 0x24 | `VSLIDE` | `vd[l] = vs1[(l + imm[18:12]) mod L]` (rotate) | vs1 |

All VALU operations honour every rounding mode, produce correct subnormals
(tininess detected *before* rounding), return the canonical quiet NaN and raise
exact IEEE flags.

### 3.3 Iterative and special-function units

| Opcode | Mnemonic | FU | Semantics | Accuracy |
|---|---|---|---|---|
| 0x30 | `VDIV` | DIVSQRT | `vs1 ∘÷ vs2`, digit recurrence (`DIV_BPC` bits/cycle) | correctly rounded, all modes |
| 0x31 | `VSQRT` | DIVSQRT | `∘√vs1` | correctly rounded, all modes |
| 0x32 | `VRECIP` | SFU | `1/vs1` (table seed + Newton–Raphson) | ≤ 0.503 ULP (FP32), ≤ 0.501 ULP (FP64), RNE |
| 0x33 | `VEXP` | SFU | `e^vs1` (Tang table + polynomial) | ≤ 0.508 ULP (FP32), ≤ 0.499 ULP (FP64) |
| 0x34 | `VLOG` | SFU | `ln(vs1)` (segmented, cancellation-free near 1) | ≤ 0.500 ULP |
| 0x38 | `VPOLY` | POLY | `vd[l] = Σ_k c_k·x^k` by Horner (FMA chain), `x = vs1[l]`, `c_k = vs2[k]` (lane k), degree `imm[3:0]` (≤ L−1) | see NUMERICAL_MODEL |
| 0x39 | `VCUBE` | POLY | `(vs1×vs1)×vs1`, two roundings | < 2 ULP |
| 0x3A | `VINTERP` | INTERP | uniform-grid linear interpolation: `t = vs1[l]` in `[0, L−1]`, table `y = vs2`, slopes `d = vs3`: `y_i + (t−i)·d_i`; outside the table → clamped end value + `Q_SUSPECT` | ≤ 0.5 ULP (arithmetic) |
| 0x3C | `VREDUCE func` | RED | over active lanes, deterministic pairwise tree: SUM 0, MIN 1, MAX 2, SUMSQ 3, DOT 4 (vs1·vs2), ARGMIN 5, ARGMAX 6, MAXABS 7; result broadcast to every lane | tree order fixed (bit-reproducible) |

Special-function accuracy figures are measured over sampled domains by
`python/generators/gen_sfu_tables.py` (`reports/numerics/sfu_accuracy.json`)
and the RTL is bit-exact with the model that produced them.

### 3.4 Memory (FU `LSU`)

Effective address `EA = a[vs2 & 7] + imm` (computed at issue). Memory id = `func[2:0]`:
`STATE 0, STATE_N 1, PARAM 2, COEFF 3, SCRATCH 4, RESULT 5, TELEM 6`.

| Opcode | Mnemonic | Semantics |
|---|---|---|
| 0x40 | `VLOAD` | `vd = MEM[func][row = EA]` (all lanes, value + quality); a parity error marks the element `Q_NAN|Q_SUSPECT` and raises `PARITY` |
| 0x41 | `VSTORE` | `MEM[func][EA] = vs1` for active lanes; `TELEM` is read-only |
| 0x42 | `VLDBC` | broadcast one element: row `EA >> log2(L)`, lane `EA mod L` |

Out-of-range rows, unknown memories and stores to `TELEM` raise `MEMADDR`.
The telemetry table holds the latest accepted sample of channel `c` at row `c / L`, lane `c mod L`.

### 3.5 Simulation engines

| Opcode | Mnemonic | Semantics |
|---|---|---|
| 0x51 | `TSCFG func` | configure the integrator: `dt = vs1[0]`, method `func` = EULER 0, HEUN 1, MIDPOINT 2, RALSTON 3, RK4 4, CUSTOM 7 (CSR tableau), RESET 15 (t = 0, step = 0). The tableau is pre-scaled by dt (`ca = dt·A`, `cb = dt·b`). Invalid dt (≤ 0, Inf, NaN) → `STEP` fault and the engine refuses to integrate |
| 0x50 | `STATE_UPDATE func` | `func = LOAD (8)`: `x0 = vs1`. `func = s` (stage 0..S−1): `k_s = vs1`; returns the next stage input `x0 + Σ_{j≤s} ca[s+1][j]·k_j` or, at the last stage, `x_{n+1} = x0 + Σ_j cb[j]·k_j` and commits `t += dt`, `step += 1`. Each sum is an FMA chain in ascending j (zero tableau terms skipped). An out-of-sequence stage returns `x0` with `Q_SUSPECT` and raises `STEP` |
| 0x52 | `RESIDUAL func` | `r = vs1 − vs2` (SIGNED 0), `|r|` (ABS 1) or margin `th − |r|` (MARGIN 2), with `th = fma(RES_RTOL, |vs1|, vs3)` (vs3 = absolute tolerance). `VM` = violation; violation → `Q_SUSPECT` + `RESIDUAL` fault |
| 0x53 | `CONSERVE func` | invariant `I = Σ w_i·x_i` (vs2 weights × vs1 state, tree sum). CAPTURE 0: reference ← I. CHECK 1 / CHECK_ADV 2: `E = ref + Σ s_i` (vs3 sources), `r = I − E`, violation if `|r| > CONS_RTOL·|E| + CONS_ATOL` → `CONSERVATION` fault; CHECK_ADV then advances the reference. Lanes return `[I, E, r, |r|/|E|, th, viol, ref_before, |r|]` |

The program computes the model derivative `f(x, u, p)` between `STATE_UPDATE`
stages with ordinary vector instructions, so the same engine integrates any
explicit ODE system: thermal networks, structural modes, fluid-network lumped
models, chemical-kinetics surrogates, cryogenic boil-off budgets, etc.

### 3.6 Optimisation engines

| Opcode | Mnemonic | Semantics |
|---|---|---|
| 0x60 | `OBJECTIVE func` | per-lane term, `func[1:0]`: WSUM `w·x`; ABS `w·|x−t|`; SQ `w·(x−t)²`; PENALTY `w·min(x,0)²` (x = constraint margin) with x = vs1, t = vs2, w = vs3. `func[3]` REDUCE: tree-sum the active terms, broadcast |
| 0x61 | `CONSTRAINT func` | margin `m` per lane, PASS if: LT `b−x > 0`, GT `x−b > 0`, EQ `−|x−b| = 0`, TOL `tol − |x−b| > 0`, LE `b−x ≥ 0`, GE `x−b ≥ 0` (x = vs1, b = vs2, tol = vs3). `vd` = margin, `VM` = PASS; any active FAIL → `CONSTRAINT` (informational by default) |
| 0x62 | `SWEEP func` | mixed-radix grid of ≤ 4 dimensions (CSR `SW_*`): RESET 0, GEN 1 (`vd[l]` = coordinate `imm[1:0]` of candidate `base + l`, `lo + i·step` by FMA; `VM` = candidate exists), NEXT 2 (`base += L`). Invalid configuration → `SEARCH` fault |
| 0x63 | `SEARCH func` | RESET 0; GRID 1: arg-min of objective `vs1` over active ∧ feasible (`VM`) lanes, tracks global best and index; LOCAL 2: compass (pattern) search step — lanes `2k`, `2k+1` hold `f(center ± step_k e_k)`, lane L−1 holds `f(center)`; accept the best improving move or halve all steps; converges on `min step` or `max iter`; LS_GEN 3: emit coordinate `imm[1:0]` of the candidate points |

## 4. Rounding, flags and exceptions

* Every FP operation is IEEE-754-2019 compliant in all five rounding modes;
  `rm = DYN` selects `FRM`.
* Flags (NV, DZ, OF, UF, NX) are accumulated into `FFLAGS` at retirement in
  program order; NV / OF / DZ / UF also map to the fault sources
  `NAN`, `OVERFLOW`, `DIVZERO`, `UNDERFLOW` (enable / halt masks in §6 of the
  register map).
* `fma(±Inf, 0, qNaN)` raises NV (the invalid product is not masked by the NaN addend).
* Underflow uses tininess-before-rounding; subnormals are fully supported (no flush-to-zero).

## 5. Issue-time checks (no silent coercion)

| Check | Fault |
|---|---|
| unknown opcode, reserved rounding mode, FP format not implemented by the build, `vl > L` | `ILLEGAL` |
| a source register never written (`meta.valid = 0`) | `UNINIT` |
| source precision / fixed-point scale differs from the instruction's | `PRECISION` |
| partial write (masked / `vl < L`) into a register holding another format | `PRECISION` |
| instruction-memory parity error | `PARITY` |

A faulting instruction occupies a retirement slot without executing, so the
fault is reported with the exact PC, in program order, after every older
instruction has completed. Issue-time faults serialise the pipeline: no
younger instruction issues behind them.

## 6. Example — RK4 step of a generic linear system `dx/dt = A·x + u`

```text
        TSCFG        v31, RK4               ; v31[0] = dt
        VLOAD        v1, STATE, a0, 0       ; x
        STATE_UPDATE v1, v1, LOAD
loop:   ; ---- derivative f(x) = A x + u, A in COEFF rows 0..L-1 -------------
        VMOV         v10, v20               ; v20 = u
        VBCAST       v11, v1, lane 0
        VLOAD        v12, COEFF, a1, 0
        VFMA         v10, v12, v11, v10     ; ... repeated per column
        STATE_UPDATE v2, v10, stage 0       ; next stage input
        ...                                 ; stages 1..3 likewise
        RESIDUAL     v5, v1, v4, v6, ABS    ; optional: compare against telemetry
        BNZ          a2, loop
        VSTORE       v1, RESULT, a3, 0
        HALT
```

`python/silica_flux/workloads.py` builds complete programs of this form with
the assembler; `python/examples/end_to_end.py` runs one on the reference model
and on the RTL and compares every element bit-for-bit.
