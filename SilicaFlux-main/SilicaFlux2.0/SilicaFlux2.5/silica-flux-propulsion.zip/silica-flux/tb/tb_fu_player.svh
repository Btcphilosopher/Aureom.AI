// generic functional-unit vector player (see tb_common.svh)
task automatic play_fu(input string fname, input string name);
  int fd, code;
  logic [flux_pkg::UOP_W-1:0] u;
  logic [LANES*W-1:0]  a, b, c, ed;
  logic [LANES*4-1:0]  qa, qb, qc, eq;
  logic [LANES-1:0]    lm, vm, ewm, evm;
  logic [4:0]          eff;
  logic [flux_pkg::FAULT_W-1:0] eflt;
  bit ok;
  bit stop_;
  int guard;
  stop_ = 1'b0;
  fd = $fopen(fname, "r");
  if (fd == 0) begin $display("cannot open %s", fname); n_fail++; stop_ = 1'b1; end
  while (!$feof(fd) && !stop_) begin
    code = $fscanf(fd, "%h %h %h %h %h %h %h %h %h %h %h %h %h %h %h\n",
                   u, a, b, c, qa, qb, qc, lm, vm, ed, eq, ewm, evm, eff, eflt);
    if (code != 15) stop_ = 1'b1;
      else begin
    req_uop = u; req_a = a; req_b = b; req_c = c; req_qa = qa; req_qb = qb; req_qc = qc;
    req_lmask = lm; req_vm = vm; req_valid = 1'b1;
    guard = 0;
    do begin tick(); guard++; end while (!hs_req && guard < 20000);
    req_valid = 1'b0;
    rsp_ready = 1'b0;
    while (!rsp_valid && guard < 20000) begin tick(); guard++; end
    if (guard >= 20000) begin
      $display("[%s] TIMEOUT waiting for handshake (uop=%h)", name, u);
      n_fail++;
      stop_ = 1'b1;
    end
    while (coin(30)) tick();                      // random back-pressure
    ok = 1'b1;
    if (u[1]) begin                               // wr_vd
      if (rsp_wmask !== ewm) ok = 1'b0;
      for (int l = 0; l < LANES; l++)
        if (ewm[l] && (rsp_data[l*W +: W] !== ed[l*W +: W] || rsp_qual[l*4 +: 4] !== eq[l*4 +: 4])) ok = 1'b0;
    end
    if (u[0]) begin                               // wr_vm
      for (int l = 0; l < LANES; l++) if (ewm[l] && rsp_vm[l] !== evm[l]) ok = 1'b0;
    end
    if (rsp_fflags !== eff || rsp_faults !== eflt) ok = 1'b0;
    if (rsp_uop !== u) ok = 1'b0;
    rsp_ready = 1'b1;
    tick();
    rsp_ready = 1'b0;
    if (ok) n_pass++;
    else begin
      n_fail++;
      if (n_fail < 6) $display("[%s] MISMATCH uop=%h data=%h exp=%h ff=%h/%h flt=%h/%h", name, u,
                               rsp_data, ed, rsp_fflags, eff, rsp_faults, eflt);
    end
    end
    end
  $fclose(fd);
endtask
