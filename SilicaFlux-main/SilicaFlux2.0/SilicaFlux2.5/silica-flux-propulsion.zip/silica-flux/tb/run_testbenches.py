#!/usr/bin/env python3
"""
Build and run the self-checking SystemVerilog testbenches on Icarus Verilog
and/or Verilator.

    python3 tb/run_testbenches.py --sim verilator      # (make verilate)
    python3 tb/run_testbenches.py --sim icarus         # (make test)
    python3 tb/run_testbenches.py --sim both --only tb_fma

Vector files are generated from the golden model first.  Results are written
to reports/sv_testbenches_<sim>.json.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTL = [ROOT / l.strip() for l in (ROOT / "rtl/sources.f").read_text().splitlines() if l.strip()]
INC = [ROOT / "rtl/core", ROOT / "rtl/math/generated", ROOT / "tb"]

# name, top, parameters, vector set ("fp32" / "fp64" / None)
TBS = [
    ("tb_fma_fp32", "tb_fma", {}, "fp32", "+VEC={v}/fma.vec"),
    ("tb_fma_fp64", "tb_fma", {"EXP_W": 11, "MAN_W": 52}, "fp64", "+VEC={v}/fma.vec"),
    ("tb_math_fp32", "tb_math", {}, "fp32", "+VECDIR={v}"),
    ("tb_math_fp64", "tb_math", {"EXP_W": 11, "MAN_W": 52}, "fp64", "+VECDIR={v}"),
    ("tb_vector_alu_l8", "tb_vector_alu", {"LANES": 8}, "fp32", "+VECDIR={v}"),
    ("tb_vector_alu_l16", "tb_vector_alu", {"LANES": 16}, "fp32", "+VECDIR={v}"),
    ("tb_vector_alu_l32", "tb_vector_alu", {"LANES": 32}, "fp32", "+VECDIR={v}"),
    ("tb_interpolation", "tb_interpolation", {"LANES": 8}, "fp32", "+VECDIR={v}"),
    ("tb_simulation", "tb_simulation", {"LANES": 8}, "fp32", "+VECDIR={v}"),
    ("tb_optimisation", "tb_optimisation", {"LANES": 8}, "fp32", "+VECDIR={v}"),
    ("tb_scheduler", "tb_scheduler", {}, None, ""),
    ("tb_faults", "tb_faults", {}, None, ""),
]


def vectors(kind: str) -> Path:
    out = ROOT / "build" / "tbvec" / kind
    if not (out / "fma.vec").exists():
        cmd = [sys.executable, str(ROOT / "python/generators/sv_vectors.py"), str(out), "-n", "300"]
        if kind == "fp64":
            cmd.append("--fp64")
        subprocess.run(cmd, check=True, capture_output=True)
    return out


def build(sim: str, name: str, top: str, params: dict) -> list[str]:
    bdir = ROOT / "build" / sim / name
    bdir.mkdir(parents=True, exist_ok=True)
    srcs = [str(p) for p in RTL] + [str(ROOT / "tb" / f"{top}.sv")]
    if sim == "icarus":
        exe = bdir / "sim.vvp"
        cmd = ["iverilog", "-g2012", "-o", str(exe), "-s", top] + [f"-I{i}" for i in INC] + \
              [f"-P{top}.{k}={v}" for k, v in params.items()] + srcs
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            raise RuntimeError(r.stderr[-3000:])
        return ["vvp", "-n", str(exe)]
    # Verilator builds also compile the concurrent assertions (embedded `SF_SVA blocks and the
    # checkers bound by formal/assertions.sv); a failing assertion aborts the run.
    cmd = ["verilator", "--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O2",
           "--assert", "+define+SF_SVA", "--top-module", top, "--Mdir", str(bdir), "-o", "Vtb"] + \
          [f"-I{i}" for i in INC] + [f"-G{k}={v}" for k, v in params.items()] + \
          srcs[:-1] + [str(ROOT / "formal" / "assertions.sv"), srcs[-1]]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stdout[-3000:] + r.stderr[-3000:])
    return [str(bdir / "Vtb")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", default="verilator", choices=["verilator", "icarus", "both"])
    ap.add_argument("--only", action="append")
    a = ap.parse_args()
    sims = ["verilator", "icarus"] if a.sim == "both" else [a.sim]
    bad = 0
    for sim in sims:
        res = {}
        for name, top, params, vec, plus in TBS:
            if a.only and name not in a.only and top not in a.only:
                continue
            t0 = time.time()
            try:
                cmd = build(sim, name, top, params)
                if vec:
                    cmd.append(plus.format(v=vectors(vec)))
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=900, cwd=ROOT)
                out = r.stdout
                m = re.findall(r"\[(.+?)\] (\d+) vectors, (\d+) pass, (\d+) fail -> (PASS|FAIL)", out)
                ok = bool(m) and all(x[4] == "PASS" for x in m)
                vec_n = sum(int(x[1]) for x in m)
                fails = [l for l in out.splitlines() if "MISMATCH" in l or "FAIL:" in l or "TIMEOUT" in l][:6]
                if r.returncode != 0:                  # assertion abort / $fatal
                    ok = False
                    fails += [l for l in (out + r.stderr).splitlines() if "Assertion failed" in l or "%Error" in l][:4]
            except Exception as e:                       # build or run error
                ok, vec_n, fails = False, 0, [str(e)[:500]]
            res[name] = {"pass": ok, "vectors": vec_n, "seconds": round(time.time() - t0, 1), "details": fails}
            print(f"[{sim}] {name:<20} {'PASS' if ok else 'FAIL'}  vectors={vec_n:<6} {res[name]['seconds']} s",
                  flush=True)
            for f in fails:
                print("      " + f)
            bad += not ok
        (ROOT / "reports").mkdir(exist_ok=True)
        prev_p = ROOT / "reports" / f"sv_testbenches_{sim}.json"
        prev = json.loads(prev_p.read_text()) if prev_p.exists() else {}
        prev.update(res)
        prev_p.write_text(json.dumps(prev, indent=2))
    print("SV TESTBENCHES:", "PASS" if bad == 0 else f"FAIL ({bad})")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
