// =============================================================================
// tb_scheduler -- directed checks of the issue scheduler / scoreboard
//   RAW and WAW hazards, scoreboard release, illegal encodings, precision and
//   fixed-point scale mismatch, uninitialised source, dynamic rounding mode,
//   fault-only issue waiting for hazards, SWEEP/SEARCH serialisation.
// =============================================================================
`timescale 1ns/1ps
module tb_scheduler;
  localparam int LANES = 8;
  `include "tb_common.svh"
  flux_pkg::instr_t head;
  logic head_valid = 0, ext_fault = 0, rob_full = 0, rr_ready = 1;
  flux_pkg::meta_t [31:0] meta;
  logic [2:0] frm = 3'd0;
  logic clr_valid = 0, clr_wr_vd = 0, clr_wr_vm = 0;
  logic [4:0] clr_vd = 0;
  logic [3:0] clr_fu = 0;
  logic issue_fire = 0, can_issue, is_ctrl, fault_only, stall_hazard;
  logic [flux_pkg::FAULT_W-1:0] faults;
  logic [2:0] rm_eff;
  logic [flux_pkg::NUM_FU-1:0][7:0] inflight;
  flux_scheduler #(.LANES(LANES), .FP_MODE(0)) dut (
    .clk(clk), .rst_n(rst_n), .head_valid(head_valid), .head(head), .ext_fault(ext_fault), .meta(meta),
    .frm(frm), .mem_prec({7{3'd0}}), .mem_scale('0), .rob_full(rob_full), .rr_ready(rr_ready),
    .clr_valid(clr_valid), .clr_vd(clr_vd), .clr_wr_vd(clr_wr_vd), .clr_wr_vm(clr_wr_vm), .clr_fu(clr_fu),
    .issue_fire(issue_fire), .can_issue(can_issue), .is_ctrl(is_ctrl), .fault_only(fault_only),
    .issue_faults(faults), .rm_eff(rm_eff), .stall_hazard(stall_hazard), .inflight(inflight));

  function automatic flux_pkg::instr_t ins(input logic [7:0] op, input int vd, input int a, input int b,
                                           input logic [2:0] prec = 3'd0);
    flux_pkg::instr_t i;
    i = '0; i.opcode = op; i.vd = 5'(vd); i.vs1 = 5'(a); i.vs2 = 5'(b); i.prec = prec;
    return i;
  endfunction
  task automatic expect_(input string what, input bit cond);
    if (cond) n_pass++; else begin n_fail++; $display("FAIL: %s", what); end
  endtask
  task automatic issue();
    issue_fire = 1; tick(); issue_fire = 0;
  endtask
  // completion of an in-flight op; wr = 0 for ops that write no vector register
  task automatic release_(input int vd, input logic [3:0] fu, input bit wr = 1'b1);
    clr_valid = 1; clr_vd = 5'(vd); clr_wr_vd = wr; clr_fu = fu; tick(); clr_valid = 0; clr_wr_vd = 0;
  endtask

  initial begin
    meta = '0;
    meta[1].valid = 1; meta[2].valid = 1; meta[3].valid = 1; meta[4].valid = 1;
    meta[5].valid = 1; meta[6].valid = 1; meta[7].valid = 1;
    do_reset();
    head_valid = 1;
    // 1. independent op issues
    head = ins(flux_pkg::OP_VADD, 3, 1, 2); #1;
    expect_("VADD issues", can_issue && !fault_only && !is_ctrl);
    issue();
    // 2. RAW on v3
    head = ins(flux_pkg::OP_VMUL, 4, 3, 1); #1;
    expect_("RAW stalls", !can_issue && stall_hazard);
    // 3. WAW on v3
    head = ins(flux_pkg::OP_VSUB, 3, 1, 2); #1;
    expect_("WAW stalls", !can_issue);
    // 4. release v3 -> both may issue
    release_(3, flux_pkg::FU_VALU);
    head = ins(flux_pkg::OP_VMUL, 4, 3, 1); #1;
    expect_("RAW released", can_issue);
    // 5. illegal opcode
    head = ins(8'h7F, 5, 1, 2); #1;
    expect_("illegal opcode -> fault", can_issue && fault_only && faults[flux_pkg::F_ILLEGAL]);
    // 6. vector length beyond LANES
    head = ins(flux_pkg::OP_VADD, 5, 1, 2); head.vl = 6'd9; #1;
    expect_("vl > LANES illegal", fault_only && faults[flux_pkg::F_ILLEGAL]);
    // 7. FP64 op in an FP32 fabric
    head = ins(flux_pkg::OP_VADD, 5, 1, 2, flux_pkg::PREC_FP64); #1;
    expect_("unsupported precision illegal", fault_only && faults[flux_pkg::F_ILLEGAL]);
    // 8. precision mismatch: SFIX op on FP32 registers
    head = ins(flux_pkg::OP_VADD, 5, 1, 2, flux_pkg::PREC_SFIX); head.imm = 19'd16; #1;
    expect_("precision mismatch", fault_only && faults[flux_pkg::F_PRECISION]);
    // 9. fixed-point scale mismatch
    meta[6].prec = flux_pkg::PREC_SFIX; meta[6].scale = 6'd8;
    meta[7].prec = flux_pkg::PREC_SFIX; meta[7].scale = 6'd16;
    head = ins(flux_pkg::OP_VADD, 5, 6, 7, flux_pkg::PREC_SFIX); head.imm = 19'd16; #1;
    expect_("scale mismatch", fault_only && faults[flux_pkg::F_PRECISION]);
    // 10. uninitialised source
    head = ins(flux_pkg::OP_VADD, 5, 20, 1); #1;
    expect_("uninitialised source", fault_only && faults[flux_pkg::F_UNINIT]);
    // 11. dynamic rounding mode resolution and invalid FRM
    head = ins(flux_pkg::OP_VADD, 5, 1, 2); head.rm = flux_pkg::RM_DYN; frm = flux_pkg::RM_RUP; #1;
    expect_("RM_DYN uses FRM", rm_eff == flux_pkg::RM_RUP && !fault_only);
    frm = 3'd6; #1;
    expect_("invalid FRM illegal", fault_only && faults[flux_pkg::F_ILLEGAL]);
    frm = 3'd0;
    // 12. fault-only issue still waits for its hazards (stale metadata)
    head = ins(flux_pkg::OP_VADD, 4, 1, 2); #1; issue();          // v4 busy
    head = ins(flux_pkg::OP_VADD, 5, 4, 1, flux_pkg::PREC_SFIX); #1;
    expect_("fault-only waits for RAW", !can_issue);
    release_(4, flux_pkg::FU_VALU);
    #1;
    expect_("fault-only issues after release", can_issue && fault_only);
    // 13. SWEEP / SEARCH serialisation
    head = ins(flux_pkg::OP_SWEEP, 9, 0, 0); head.func = flux_pkg::SW_NEXT; #1;
    expect_("SWEEP issues", can_issue); issue();
    head = ins(flux_pkg::OP_SEARCH, 0, 1, 0); head.func = flux_pkg::SR_GRID; #1;
    expect_("SEARCH waits for in-flight SWEEP", !can_issue);
    release_(0, flux_pkg::FU_SWEEP, 1'b0);          // SWEEP NEXT writes no register
    head = ins(flux_pkg::OP_SEARCH, 0, 1, 0); head.func = flux_pkg::SR_GRID; #1;
    expect_("SEARCH issues after SWEEP", can_issue);
    // 14. structural: retirement queue full
    rob_full = 1; head = ins(flux_pkg::OP_VADD, 5, 1, 2); #1;
    expect_("ROB full blocks issue", !can_issue);
    rob_full = 0;
    // 15. control instruction is not a vector issue
    head = ins(flux_pkg::OP_SETA, 1, 0, 0); #1;
    expect_("SETA is control", is_ctrl && !can_issue);
    report("tb_scheduler");
    $finish;
  end
endmodule
