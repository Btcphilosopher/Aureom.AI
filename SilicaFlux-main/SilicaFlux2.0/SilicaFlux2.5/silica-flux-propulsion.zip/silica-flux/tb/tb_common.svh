// =============================================================================
// Silica Flux -- shared testbench infrastructure (testbench-only constructs)
// -----------------------------------------------------------------------------
// Clock / reset, an edge-sampled handshake helper and a generic functional-unit
// vector player.  Vector files are produced by python/generators/sv_vectors.py
// from the golden model; every comparison is bit-exact.  Includers declare:
//   parameter LANES, W   and the standard FU signals (req_* / rsp_*).
// =============================================================================
logic clk = 1'b0;
logic rst_n = 1'b0;
always #5 clk = ~clk;
int unsigned n_pass = 0;
int unsigned n_fail = 0;
int unsigned lfsr = 32'h1F2E3D4C;

task automatic tick();
  @(posedge clk);
  #1;
endtask

task automatic do_reset();
  rst_n = 1'b0;
  repeat (4) tick();
  rst_n = 1'b1;
  tick();
endtask

function automatic bit coin(input int pct);
  lfsr = {lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
  return (lfsr % 100) < pct;
endfunction

task automatic report(input string name);
  $display("[%s] %0d vectors, %0d pass, %0d fail -> %s", name, n_pass + n_fail, n_pass, n_fail,
           (n_fail == 0) ? "PASS" : "FAIL");
endtask
