// =============================================================================
// tb_simulation -- physical-system state engine and residual engine
//   state_update : TSCFG (RK4, Heun, Euler, Midpoint, Ralston), LOAD, every
//                  stage combination, invalid stage -> F_STEP (sequence-
//                  dependent: the engine is stateful)
//   residual     : SIGNED / ABS / MARGIN, violation mask, F_RESIDUAL
// =============================================================================
`timescale 1ns/1ps
module tb_simulation;
  parameter int LANES = 8;
  parameter int EXP_W = 8;
  parameter int MAN_W = 23;
  localparam int W = EXP_W + MAN_W + 1;
  localparam logic [W-1:0] RTOL = (EXP_W == 8) ? W'(32'h3a83126f) : W'(64'h3f50624dd2f1a9fc);   // 1e-3
  `include "tb_common.svh"
  `include "tb_fu_signals.svh"
  `include "tb_fu_player.svh"
  logic [1:0] sel;
  logic [1:0] rdy_v, val_v;
  flux_pkg::uop_t [1:0] uo_v;
  logic [1:0][LANES*W-1:0] d_v;
  logic [1:0][LANES*flux_pkg::QW-1:0] q_v;
  logic [1:0][LANES-1:0] wm_v, vm_v;
  logic [1:0][4:0] ff_v;
  logic [1:0][flux_pkg::FAULT_W-1:0] fl_v;
  logic [W-1:0] t_now, dt_now;
  logic [31:0] steps, upd, viol;
  logic ts_valid;
  state_update #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W)) u_su (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid && sel == 0), .req_ready(rdy_v[0]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm), .rsp_valid(val_v[0]), .rsp_ready(rsp_ready && sel == 0),
    .rsp_uop(uo_v[0]), .rsp_data(d_v[0]), .rsp_qual(q_v[0]), .rsp_wmask(wm_v[0]), .rsp_vm(vm_v[0]),
    .rsp_fflags(ff_v[0]), .rsp_faults(fl_v[0]), .custom_stages(3'd1), .custom_a('0), .custom_b('0),
    .t_now(t_now), .dt_now(dt_now), .step_count(steps), .ts_valid(ts_valid), .state_updates(upd));
  residual_engine #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W)) u_res (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid && sel == 1), .req_ready(rdy_v[1]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm), .rsp_valid(val_v[1]), .rsp_ready(rsp_ready && sel == 1),
    .rsp_uop(uo_v[1]), .rsp_data(d_v[1]), .rsp_qual(q_v[1]), .rsp_wmask(wm_v[1]), .rsp_vm(vm_v[1]),
    .rsp_fflags(ff_v[1]), .rsp_faults(fl_v[1]), .cfg_rtol(RTOL), .viol_count(viol));
  assign req_ready  = rdy_v[sel];
  assign rsp_valid  = val_v[sel];
  assign rsp_uop    = uo_v[sel];
  assign rsp_data   = d_v[sel];
  assign rsp_qual   = q_v[sel];
  assign rsp_wmask  = wm_v[sel];
  assign rsp_vm     = vm_v[sel];
  assign rsp_fflags = ff_v[sel];
  assign rsp_faults = fl_v[sel];
  initial begin
    string dir;
    if (!$value$plusargs("VECDIR=%s", dir)) dir = ".";
    sel = 0;
    do_reset();
    play_fu($sformatf("%s/state_update_l%0d.vec", dir, LANES), "state_update");
    sel = 1;
    play_fu($sformatf("%s/residual_l%0d.vec", dir, LANES), "residual");
    $display("[tb_simulation] integrated steps=%0d lane-updates=%0d residual violations=%0d", steps, upd, viol);
    report("tb_simulation");
    $finish;
  end
endmodule
