// standard FU interface signals for testbenches
flux_pkg::uop_t                req_uop, rsp_uop;
logic                          req_valid = 1'b0, req_ready, rsp_valid, rsp_ready = 1'b0;
logic [LANES*W-1:0]            req_a, req_b, req_c, rsp_data;
logic [LANES*flux_pkg::QW-1:0] req_qa, req_qb, req_qc, rsp_qual;
logic [LANES-1:0]              req_lmask, req_vm, rsp_wmask, rsp_vm;
logic [4:0]                    rsp_fflags;
logic [flux_pkg::FAULT_W-1:0]  rsp_faults;
logic                          hs_req;
always @(posedge clk) hs_req <= req_valid && req_ready;
