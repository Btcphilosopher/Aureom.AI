// =============================================================================
// tb_optimisation -- objective and constraint engines (vector files) plus a
// directed check of the parameter-sweep engine's mixed-radix candidate
// generation and batch advance.
// =============================================================================
`timescale 1ns/1ps
module tb_optimisation;
  parameter int LANES = 8;
  parameter int EXP_W = 8;
  parameter int MAN_W = 23;
  localparam int W = EXP_W + MAN_W + 1;
  localparam logic [W-1:0] ONE = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};
  `include "tb_common.svh"
  `include "tb_fu_signals.svh"
  `include "tb_fu_player.svh"
  logic [1:0] sel;
  logic [2:0] rdy_v, val_v;
  flux_pkg::uop_t [2:0] uo_v;
  logic [2:0][LANES*W-1:0] d_v;
  logic [2:0][LANES*flux_pkg::QW-1:0] q_v;
  logic [2:0][LANES-1:0] wm_v, vm_v;
  logic [2:0][4:0] ff_v;
  logic [2:0][flux_pkg::FAULT_W-1:0] fl_v;
  logic [31:0] pc, fc, base, total;
  logic [LANES-1:0] lp;
  logic done, cfg_ok;
  objective_eval #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W)) u_obj (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid && sel == 0), .req_ready(rdy_v[0]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm), .rsp_valid(val_v[0]), .rsp_ready(rsp_ready && sel == 0),
    .rsp_uop(uo_v[0]), .rsp_data(d_v[0]), .rsp_qual(q_v[0]), .rsp_wmask(wm_v[0]), .rsp_vm(vm_v[0]),
    .rsp_fflags(ff_v[0]), .rsp_faults(fl_v[0]));
  constraint_eval #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W)) u_con (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid && sel == 1), .req_ready(rdy_v[1]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm), .rsp_valid(val_v[1]), .rsp_ready(rsp_ready && sel == 1),
    .rsp_uop(uo_v[1]), .rsp_data(d_v[1]), .rsp_qual(q_v[1]), .rsp_wmask(wm_v[1]), .rsp_vm(vm_v[1]),
    .rsp_fflags(ff_v[1]), .rsp_faults(fl_v[1]), .pass_count(pc), .fail_count(fc), .last_pass(lp));
  // sweep: 2 dimensions, counts 3 x 2, lo = 1.0, step = 1.0 -> values 1.0 + digit
  parameter_sweep #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W)) u_sw (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid && sel == 2), .req_ready(rdy_v[2]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm), .rsp_valid(val_v[2]), .rsp_ready(rsp_ready && sel == 2),
    .rsp_uop(uo_v[2]), .rsp_data(d_v[2]), .rsp_qual(q_v[2]), .rsp_wmask(wm_v[2]), .rsp_vm(vm_v[2]),
    .rsp_fflags(ff_v[2]), .rsp_faults(fl_v[2]), .cfg_dims(3'd2), .cfg_lo({4{ONE}}), .cfg_step({4{ONE}}),
    .cfg_count({32'd1, 32'd1, 32'd2, 32'd3}), .base(base), .total(total), .done(done), .cfg_ok(cfg_ok));
  assign req_ready  = rdy_v[sel];
  assign rsp_valid  = val_v[sel];
  assign rsp_uop    = uo_v[sel];
  assign rsp_data   = d_v[sel];
  assign rsp_qual   = q_v[sel];
  assign rsp_wmask  = wm_v[sel];
  assign rsp_vm     = vm_v[sel];
  assign rsp_fflags = ff_v[sel];
  assign rsp_faults = fl_v[sel];

  // exact FP encoding of 1.0 + small integer
  function automatic logic [W-1:0] fp_int(input int v);
    logic [W-1:0] f;
    int msb;
    f = '0;
    msb = 0;
    for (int k = 0; k < 8; k++) if (v[k]) msb = k;
    f[W-2:MAN_W] = EXP_W'((1 << (EXP_W - 1)) - 1 + msb);
    f[MAN_W-1:0] = MAN_W'(v - (1 << msb)) << (MAN_W - msb);
    return f;
  endfunction

  task automatic sweep_op(input logic [3:0] func, input logic [1:0] dim);
    flux_pkg::instr_t i;
    i = '0;
    i.opcode = flux_pkg::OP_SWEEP; i.func = func; i.imm = 19'(dim); i.vd = 5'd1;
    i.prec = (EXP_W == 8) ? flux_pkg::PREC_FP32 : flux_pkg::PREC_FP64;
    req_uop = '0; req_uop.ins = i; req_uop.fu = flux_pkg::FU_SWEEP; req_uop.wr_vd = (func == flux_pkg::SW_GEN);
    req_uop.wr_vm = (func == flux_pkg::SW_GEN);
    req_lmask = '1; req_valid = 1;
    do tick(); while (!hs_req);
    req_valid = 0;
    while (!rsp_valid) tick();
  endtask

  initial begin
    string dir;
    if (!$value$plusargs("VECDIR=%s", dir)) dir = ".";
    sel = 0;
    do_reset();
    play_fu($sformatf("%s/objective_l%0d.vec", dir, LANES), "objective");
    sel = 1;
    play_fu($sformatf("%s/constraint_l%0d.vec", dir, LANES), "constraint");
    // ---- directed sweep check ------------------------------------------------------
    sel = 2;
    for (int batch = 0; batch < 2; batch++) begin
      if (batch == 0) begin sweep_op(flux_pkg::SW_RESET, 0); rsp_ready = 1; tick(); rsp_ready = 0; end
      for (int d = 0; d < 2; d++) begin
        sweep_op(flux_pkg::SW_GEN, 2'(d));
        for (int l = 0; l < LANES; l++) begin
          int idx, dig;
          idx = batch * LANES + l;
          dig = (d == 0) ? (idx % 3) : ((idx / 3) % 2);
          if (rsp_vm[l] !== (idx < 6)) begin n_fail++; $display("sweep valid mismatch lane %0d", l); end
          else if (idx < 6 && rsp_data[l*W +: W] !== fp_int(1 + dig)) begin
            n_fail++; $display("sweep value mismatch b%0d d%0d l%0d: %h vs %h", batch, d, l, rsp_data[l*W +: W], fp_int(1 + dig));
          end else n_pass++;
        end
        rsp_ready = 1; tick(); rsp_ready = 0;
      end
      sweep_op(flux_pkg::SW_NEXT, 0); rsp_ready = 1; tick(); rsp_ready = 0;
    end
    if (!(done && total == 6 && cfg_ok)) begin n_fail++; $display("sweep status mismatch done=%b total=%0d", done, total); end
    $display("[tb_optimisation] constraint pass=%0d fail=%0d", pc, fc);
    report("tb_optimisation");
    $finish;
  end
endmodule
