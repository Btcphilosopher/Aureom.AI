// =============================================================================
// tb_vector_alu -- vector ALU functional unit at 8 / 16 / 32 lanes
// (LANES parameter); every VALU opcode, lane masks, broadcast / slide, quality
// propagation and IEEE flags compared bit-exactly with golden_model/valu.py.
// =============================================================================
`timescale 1ns/1ps
module tb_vector_alu;
  parameter int LANES = 8;
  parameter int EXP_W = 8;
  parameter int MAN_W = 23;
  localparam int W = EXP_W + MAN_W + 1;
  `include "tb_common.svh"
  `include "tb_fu_signals.svh"
  `include "tb_fu_player.svh"
  vector_alu #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(4)) dut (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm), .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_uop(rsp_uop),
    .rsp_data(rsp_data), .rsp_qual(rsp_qual), .rsp_wmask(rsp_wmask), .rsp_vm(rsp_vm), .rsp_fflags(rsp_fflags),
    .rsp_faults(rsp_faults));
  initial begin
    string dir;
    if (!$value$plusargs("VECDIR=%s", dir)) dir = ".";
    do_reset();
    play_fu($sformatf("%s/vector_alu_l%0d.vec", dir, LANES), "vector_alu");
    report($sformatf("tb_vector_alu[%0d lanes]", LANES));
    $finish;
  end
endmodule
