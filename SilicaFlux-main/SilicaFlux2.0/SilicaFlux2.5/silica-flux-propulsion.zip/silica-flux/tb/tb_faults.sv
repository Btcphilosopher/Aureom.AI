// =============================================================================
// tb_faults -- safety infrastructure: fault manager (sticky status, enable
// mask, halt mask, first-fault capture, W1C), watchdog (expiry, kick),
// parity generation / checking with injection, FP range checker, FIFO
// overflow / underflow detection.  System-level fault injection (overflow,
// NaN, illegal instruction, memory / instruction parity, watchdog, dropped
// telemetry...) runs on the full chip: python/reference_model/system_regress.py
// --suite faults --suite telemetry.
// =============================================================================
`timescale 1ns/1ps
module tb_faults;
  `include "tb_common.svh"
  localparam int FW = flux_pkg::FAULT_W;
  task automatic expect_(input string what, input bit cond);
    if (cond) n_pass++; else begin n_fail++; $display("FAIL: %s", what); end
  endtask

  // ---- fault manager ------------------------------------------------------------------
  logic [2:0] src_v = 0;
  logic [2:0][FW-1:0] src_b = '0;
  logic [2:0][15:0] src_pc = '0;
  logic [FW-1:0] en = '1, hmask = '0, clr_bits = '0, status;
  logic clr_we = 0, fvalid, halt_req, irq;
  logic [4:0] fid;
  logic [15:0] fpc;
  logic [31:0] ftime, fcount;
  fault_manager #(.NSRC(3)) u_fm (.clk(clk), .rst_n(rst_n), .src_valid(src_v), .src_bits(src_b), .src_pc(src_pc),
    .tstamp(32'd77), .enable(en), .halt_mask(hmask), .clr_we(clr_we), .clr_bits(clr_bits), .status(status),
    .first_valid(fvalid), .first_id(fid), .first_pc(fpc), .first_time(ftime), .count(fcount),
    .halt_req(halt_req), .irq(irq));

  // ---- watchdog ---------------------------------------------------------------------------
  logic [1:0] wen = 0, wkick = 0, wexp, wtrip;
  watchdog #(.N(2)) u_wd (.clk(clk), .rst_n(rst_n), .enable(wen), .kick(wkick), .limit({32'd0, 32'd10}),
    .expired(wexp), .tripped(wtrip));

  // ---- parity -------------------------------------------------------------------------------
  logic [4*36-1:0] pdin, pdout;
  logic [4*37-1:0] pword;
  logic [3:0] perr;
  logic pinj = 0;
  parity_gen #(.LANES(4), .EW(36)) u_pg (.din(pdin), .inject(pinj), .dout(pword));
  parity_checker #(.LANES(4), .EW(36)) u_pc (.din(pword), .dout(pdout), .err(perr));

  // ---- range checker --------------------------------------------------------------------------
  logic [31:0] rx;
  logic rin, rnan;
  range_checker #(.EXP_W(8), .MAN_W(23)) u_rc (.x(rx), .lo(32'h00000000), .hi(32'h42c80000), .in_range(rin), .is_nan(rnan));

  // ---- FIFO ----------------------------------------------------------------------------------
  logic push = 0, pop = 0, fe, ff_, fovf, funf;
  logic [7:0] fd_o;
  logic [2:0] fcnt;
  sf_fifo #(.W(8), .DEPTH(4)) u_fifo (.clk(clk), .rst_n(rst_n), .push(push), .wdata(8'hA5), .pop(pop), .rdata(fd_o),
    .empty(fe), .full(ff_), .count(fcnt), .overflow(fovf), .underflow(funf), .clr_flags(1'b0));

  initial begin
    do_reset();
    // fault manager: event from source 1 (pc 0x40), then source 0 (pc 0x10)
    src_v = 3'b010; src_b[1] = FW'(1 << flux_pkg::F_TL_CRC) | FW'(1 << flux_pkg::F_RANGE); src_pc[1] = 16'h40; tick();
    src_v = 3'b001; src_b[0] = FW'(1 << flux_pkg::F_NAN); src_pc[0] = 16'h10; tick();
    src_v = 0; tick();
    expect_("status sticky", status[flux_pkg::F_TL_CRC] && status[flux_pkg::F_RANGE] && status[flux_pkg::F_NAN]);
    expect_("first fault = lowest id of first event", fvalid && fid == 5'(flux_pkg::F_RANGE) && fpc == 16'h40);
    expect_("count", fcount == 2);
    expect_("no halt without mask", !halt_req && irq);
    hmask[flux_pkg::F_NAN] = 1; tick();
    expect_("halt on masked fault", halt_req);
    clr_we = 1; clr_bits = '1; tick(); clr_we = 0; tick();
    expect_("W1C clears", status == '0 && !halt_req && !fvalid);
    en = '0; src_v = 3'b001; src_b[0] = FW'(1 << flux_pkg::F_OVERFLOW); tick(); src_v = 0; tick();
    expect_("disabled faults ignored", status == '0);
    en = '1;
    // watchdog
    wen = 2'b01;
    repeat (12) tick();
    expect_("watchdog trips", wtrip[0]);
    wkick = 2'b01; tick(); wkick = 0; tick();
    expect_("kick re-arms", !wtrip[0]);
    wen = 0;
    // parity
    pdin = {36'h123456789, 36'hFEDCBA987, 36'h000000001, 36'h0F0F0F0F0}; #1;
    expect_("parity clean", perr == 4'b0000 && pdout == pdin);
    pinj = 1; #1;
    expect_("parity injection detected on lane 0 only", perr == 4'b0001);
    pinj = 0;
    // range checker: [0, 100]
    rx = 32'h42480000; #1; expect_("50 in range", rin && !rnan);
    rx = 32'h43480000; #1; expect_("200 out of range", !rin);
    rx = 32'hBF800000; #1; expect_("-1 out of range", !rin);
    rx = 32'h7FC00000; #1; expect_("NaN never in range", !rin && rnan);
    // FIFO overflow / underflow
    pop = 1; tick(); pop = 0; tick();
    expect_("underflow flagged", funf);
    push = 1; repeat (5) tick(); push = 0; tick();
    expect_("overflow flagged when pushing a full FIFO", fovf && ff_ && fcnt == 3'd4);
    report("tb_faults");
    $finish;
  end
endmodule
