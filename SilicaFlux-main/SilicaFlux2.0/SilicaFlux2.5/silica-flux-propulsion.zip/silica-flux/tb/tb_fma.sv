// =============================================================================
// tb_fma -- self-checking testbench for rtl/alu/fma_unit.sv
// FMA-family operations x 5 rounding modes, directed IEEE special cases and
// biased-random operands; bit-exact value and flag comparison against
// python/golden_model/ieee.py; random output back-pressure.
// =============================================================================
`timescale 1ns/1ps
module tb_fma;
  parameter int EXP_W = 8;
  parameter int MAN_W = 23;
  parameter int LATENCY = 4;
  localparam int W = EXP_W + MAN_W + 1;
  `include "tb_common.svh"
  logic in_valid = 0, in_ready, out_valid, out_ready = 0;
  logic [2:0] op, rm;
  logic [W-1:0] a, b, c, res;
  logic [4:0] ff;
  logic [7:0] tag_o;
  fma_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) dut (
    .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(in_ready), .op(op), .rm(rm), .a(a), .b(b), .c(c),
    .in_tag(8'd0), .out_valid(out_valid), .out_ready(out_ready), .result(res), .fflags(ff), .out_tag(tag_o));
  logic hs_in;
  always @(posedge clk) hs_in <= in_valid && in_ready;
  initial begin
    string vf;
    int fd, code;
    logic [W-1:0] er;
    logic [4:0] ef;
    logic [2:0] vop, vrm;
    logic [W-1:0] va, vb, vc;
    bit stop_;
    stop_ = 1'b0;
    if (!$value$plusargs("VEC=%s", vf)) vf = "fma.vec";
    do_reset();
    fd = $fopen(vf, "r");
    while (!$feof(fd) && !stop_) begin
      code = $fscanf(fd, "%h %h %h %h %h %h %h\n", vop, vrm, va, vb, vc, er, ef);
      if (code != 7) stop_ = 1'b1;
      else begin
      op = vop; rm = vrm; a = va; b = vb; c = vc; in_valid = 1;
      do tick(); while (!hs_in);
      in_valid = 0;
      while (!out_valid) tick();
      while (coin(25)) tick();
      if (res === er && ff === ef) n_pass++;
      else begin
        n_fail++;
        if (n_fail < 6) $display("MISMATCH op=%0d rm=%0d a=%h b=%h c=%h rtl=%h/%b ref=%h/%b", vop, vrm, va, vb, vc, res, ff, er, ef);
      end
      out_ready = 1; tick(); out_ready = 0;
      end
    end
    report("tb_fma");
    $finish;
  end
endmodule
