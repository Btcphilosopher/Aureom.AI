// =============================================================================
// tb_interpolation -- table interpolation engine: interior points, exact end
// point, clamped out-of-range lanes (Q_SUSPECT), NaN coordinates, lane masks.
// =============================================================================
`timescale 1ns/1ps
module tb_interpolation;
  parameter int LANES = 8;
  parameter int EXP_W = 8;
  parameter int MAN_W = 23;
  localparam int W = EXP_W + MAN_W + 1;
  `include "tb_common.svh"
  `include "tb_fu_signals.svh"
  `include "tb_fu_player.svh"
  interpolation_unit #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W)) dut (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm), .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_uop(rsp_uop),
    .rsp_data(rsp_data), .rsp_qual(rsp_qual), .rsp_wmask(rsp_wmask), .rsp_vm(rsp_vm), .rsp_fflags(rsp_fflags),
    .rsp_faults(rsp_faults));
  initial begin
    string dir;
    if (!$value$plusargs("VECDIR=%s", dir)) dir = ".";
    do_reset();
    play_fu($sformatf("%s/interpolation_l%0d.vec", dir, LANES), "interpolation");
    report("tb_interpolation");
    $finish;
  end
endmodule
