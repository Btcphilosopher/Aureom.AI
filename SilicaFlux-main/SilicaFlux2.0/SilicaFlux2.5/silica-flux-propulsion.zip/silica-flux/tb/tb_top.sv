// =============================================================================
// Silica Flux -- system testbench / scenario player
// -----------------------------------------------------------------------------
// Drives silica_flux_top through its real AXI4-Lite and AXI4-Stream ports from
// a command file produced by python/silica_flux/rtl_backend.py:
//
//   <op> <a> <b> <c>          (hex)
//   1 addr data -             AXI-Lite write
//   2 addr -    -             AXI-Lite read            -> "R addr data"
//   3 timeout - -             wait for STATUS.done      -> "WAIT cycles status"
//   4 data user last          AXI-Stream input beat
//   5 n -    -                capture n output beats    -> "O data user last"
//   6 - - -                   end of scenario
//   7 id - -                  marker                    -> "MARK id"
//   8 cycles - -              idle cycles
//   9 - - -                   wait for DMA idle         -> "DMA status"
//
// Run with  +SCENARIO=<cmd file> +OUT=<result file>.  Parameters select the
// synthesis configuration (lanes, FP format, pipeline depth).  Testbench-only
// constructs (file I/O, delays) are confined to this file.
// =============================================================================
`timescale 1ns/1ps
module tb_top;
  parameter int LANES   = 8;
  parameter int FP_MODE = 0;
  parameter int DEPTH   = 4;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  logic [15:0] awaddr, araddr;
  logic        awvalid, awready, wvalid, wready, bvalid, bready, arvalid, arready, rvalid, rready;
  logic [31:0] wdata, rdata;
  logic [1:0]  bresp, rresp;
  logic [63:0] s_tdata, m_tdata;
  logic [7:0]  s_tuser, m_tuser;
  logic        s_tlast, s_tvalid, s_tready, m_tlast, m_tvalid, m_tready, irq;

  silica_flux_top #(.VECTOR_LANES(LANES), .FP_MODE(FP_MODE), .PIPELINE_DEPTH(DEPTH)) dut (
    .clk(clk), .rst_n(rst_n),
    .s_axil_awaddr(awaddr), .s_axil_awvalid(awvalid), .s_axil_awready(awready),
    .s_axil_wdata(wdata), .s_axil_wstrb(4'hF), .s_axil_wvalid(wvalid), .s_axil_wready(wready),
    .s_axil_bresp(bresp), .s_axil_bvalid(bvalid), .s_axil_bready(bready),
    .s_axil_araddr(araddr), .s_axil_arvalid(arvalid), .s_axil_arready(arready),
    .s_axil_rdata(rdata), .s_axil_rresp(rresp), .s_axil_rvalid(rvalid), .s_axil_rready(rready),
    .s_axis_tdata(s_tdata), .s_axis_tuser(s_tuser), .s_axis_tlast(s_tlast), .s_axis_tvalid(s_tvalid),
    .s_axis_tready(s_tready),
    .m_axis_tdata(m_tdata), .m_axis_tuser(m_tuser), .m_axis_tlast(m_tlast), .m_axis_tvalid(m_tvalid),
    .m_axis_tready(m_tready), .irq(irq));

  longint unsigned cycle = 0;
  // handshakes are sampled at the clock edge (pre-edge values) and inspected
  // 1 ns later, so the testbench never races the DUT's registered outputs
  logic        hs_aw, hs_w, hs_b, hs_ar, hs_r, hs_s, hs_m;
  logic [31:0] rdata_q;
  logic [63:0] m_tdata_q;
  logic [7:0]  m_tuser_q;
  logic        m_tlast_q;
  always @(posedge clk) begin
    cycle     <= cycle + 1;
    hs_aw     <= awvalid && awready;
    hs_w      <= wvalid && wready;
    hs_b      <= bvalid && bready;
    hs_ar     <= arvalid && arready;
    hs_r      <= rvalid && rready;
    hs_s      <= s_tvalid && s_tready;
    hs_m      <= m_tvalid && m_tready;
    rdata_q   <= rdata;
    m_tdata_q <= m_tdata;
    m_tuser_q <= m_tuser;
    m_tlast_q <= m_tlast;
  end

  task automatic tick();
    @(posedge clk);
    #1;
  endtask

  task automatic axi_write(input logic [15:0] a, input logic [31:0] d);
    logic aw_done, w_done;
    awaddr = a; wdata = d; awvalid = 1'b1; wvalid = 1'b1;
    aw_done = 1'b0; w_done = 1'b0;
    while (!(aw_done && w_done)) begin
      tick();
      if (hs_aw) begin aw_done = 1'b1; awvalid = 1'b0; end
      if (hs_w)  begin w_done  = 1'b1; wvalid  = 1'b0; end
    end
    bready = 1'b1;
    do tick(); while (!hs_b);
    bready = 1'b0;
  endtask

  task automatic axi_read(input logic [15:0] a, output logic [31:0] d);
    araddr = a; arvalid = 1'b1;
    do tick(); while (!hs_ar);
    arvalid = 1'b0;
    rready  = 1'b1;
    do tick(); while (!hs_r);
    d = rdata_q;
    rready = 1'b0;
  endtask

  initial begin
    string scen, outf;
    int fd, fo, code;
    logic [63:0] op, a, b, c;
    logic [31:0] d;
    longint unsigned t0;
    awvalid = 0; wvalid = 0; bready = 0; arvalid = 0; rready = 0;
    s_tvalid = 0; s_tdata = '0; s_tuser = '0; s_tlast = 0; m_tready = 0;
    awaddr = '0; araddr = '0; wdata = '0;
    if (!$value$plusargs("SCENARIO=%s", scen)) $fatal(1, "missing +SCENARIO");
    if (!$value$plusargs("OUT=%s", outf)) outf = "tb_top.out";
    fd = $fopen(scen, "r");
    fo = $fopen(outf, "w");
    if (fd == 0) $fatal(1, "cannot open %s", scen);
    repeat (5) tick();
    rst_n = 1'b1;
    repeat (2) tick();
    forever begin
      code = $fscanf(fd, "%h %h %h %h\n", op, a, b, c);
      if (code != 4 || op == 6) break;
      if (op != 4) $fflush(fo);
      case (op)
        1: axi_write(a[15:0], b[31:0]);
        2: begin axi_read(a[15:0], d); $fdisplay(fo, "R %h %h", a[15:0], d); end
        3: begin
          t0 = cycle;
          d = 0;
          while (!(d[1] && !d[0])) begin
            axi_read(16'h0014, d);
            if (cycle - t0 > a) begin $fdisplay(fo, "TIMEOUT"); break; end
            repeat (16) tick();
          end
          $fdisplay(fo, "WAIT %0d %h", cycle - t0, d);
        end
        4: begin
          s_tdata = a;  s_tuser = b[7:0]; s_tlast = c[0]; s_tvalid = 1'b1;
          do tick(); while (!hs_s);
          s_tvalid = 1'b0;
        end
        5: begin
          int n;
          n = 0;
          m_tready = 1'b1;
          t0 = cycle;
          while (n < int'(a)) begin
            tick();
            if (hs_m) begin
              $fdisplay(fo, "O %h %h %0d", m_tdata_q, m_tuser_q, m_tlast_q);
              n++;
            end
            if (cycle - t0 > 64'd1000000) begin $fdisplay(fo, "TIMEOUT"); break; end
          end
          m_tready = 1'b0;
        end
        7: $fdisplay(fo, "MARK %0d", a);
        8: repeat (int'(a)) tick();
        9: begin
          d = 32'h1;
          t0 = cycle;
          while (d[0]) begin
            axi_read(16'h0310, d);
            repeat (4) tick();
            if (cycle - t0 > 64'd2000000) begin $fdisplay(fo, "TIMEOUT DMA"); break; end
          end
          $fdisplay(fo, "DMA %h", d);
        end
        default: ;
      endcase
    end
    $fdisplay(fo, "END %0d", cycle);
    $fclose(fo);
    $fclose(fd);
    $finish;
  end
endmodule
