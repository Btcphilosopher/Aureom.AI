// =============================================================================
// tb_math -- divider, square root, reciprocal, exp and log units
// Correctly rounded units (div, sqrt) and approximation units (recip, exp,
// log) are compared bit-exactly with the golden model's algorithms.
// =============================================================================
`timescale 1ns/1ps
module tb_math;
  parameter int EXP_W = 8;
  parameter int MAN_W = 23;
  localparam int W = EXP_W + MAN_W + 1;
  `include "tb_common.svh"
  logic [4:0] iv;
  logic [4:0] ir, ov;
  logic       ordy = 0;
  logic [W-1:0] a, b, r0, r1, r2, r3, r4;
  logic [2:0] rm;
  logic [4:0] f0, f1, f2, f3, f4;
  logic [7:0] t0, t1, t2, t3, t4;
  logic       b0, b1, b2, b3, b4;
  divider #(.EXP_W(EXP_W), .MAN_W(MAN_W), .BITS_PER_CYCLE(2)) u_div (.clk(clk), .rst_n(rst_n), .in_valid(iv[0]),
    .in_ready(ir[0]), .a(a), .b(b), .rm(rm), .in_tag(8'd0), .out_valid(ov[0]), .out_ready(ordy), .result(r0),
    .fflags(f0), .out_tag(t0), .busy(b0));
  sqrt_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W), .BITS_PER_CYCLE(1)) u_sqrt (.clk(clk), .rst_n(rst_n), .in_valid(iv[1]),
    .in_ready(ir[1]), .a(a), .rm(rm), .in_tag(8'd0), .out_valid(ov[1]), .out_ready(ordy), .result(r1),
    .fflags(f1), .out_tag(t1), .busy(b1));
  reciprocal_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_rcp (.clk(clk), .rst_n(rst_n), .in_valid(iv[2]),
    .in_ready(ir[2]), .a(a), .in_tag(8'd0), .out_valid(ov[2]), .out_ready(ordy), .result(r2),
    .fflags(f2), .out_tag(t2), .busy(b2));
  exp_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_exp (.clk(clk), .rst_n(rst_n), .in_valid(iv[3]),
    .in_ready(ir[3]), .a(a), .in_tag(8'd0), .out_valid(ov[3]), .out_ready(ordy), .result(r3),
    .fflags(f3), .out_tag(t3), .busy(b3));
  log_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_log (.clk(clk), .rst_n(rst_n), .in_valid(iv[4]),
    .in_ready(ir[4]), .a(a), .in_tag(8'd0), .out_valid(ov[4]), .out_ready(ordy), .result(r4),
    .fflags(f4), .out_tag(t4), .busy(b4));

  task automatic run(input int k, input string fname, input string name);
    int fd, code, base_fail;
    logic [W-1:0] va, vb, er, res;
    logic [2:0] vrm;
    logic [4:0] ef, ff;
    bit stop_;
    stop_ = 1'b0;
    base_fail = n_fail;
    fd = $fopen(fname, "r");
    if (fd == 0) begin $display("cannot open %s", fname); n_fail++; stop_ = 1'b1; end
    while (!$feof(fd) && !stop_) begin
      vb = '0; vrm = '0;
      if (k == 0)      code = $fscanf(fd, "%h %h %h %h %h\n", va, vb, vrm, er, ef) - 2;
      else if (k == 1) code = $fscanf(fd, "%h %h %h %h\n", va, vrm, er, ef) - 1;
      else             code = $fscanf(fd, "%h %h %h\n", va, er, ef);
      if (code != 3) stop_ = 1'b1;
      else begin
      a = va; b = vb; rm = vrm;
      iv = 5'(1 << k);
      tick();
      iv = '0;
      while (!ov[k]) tick();
      case (k) 0: begin res = r0; ff = f0; end 1: begin res = r1; ff = f1; end
               2: begin res = r2; ff = f2; end 3: begin res = r3; ff = f3; end
               default: begin res = r4; ff = f4; end endcase
      if (res === er && ff === ef) n_pass++;
      else begin
        n_fail++;
        if (n_fail - base_fail < 4) $display("[%s] MISMATCH a=%h b=%h rtl=%h/%b ref=%h/%b", name, va, vb, res, ff, er, ef);
      end
      ordy = 1; tick(); ordy = 0;
      end
    end
    $fclose(fd);
  endtask

  initial begin
    string dir;
    if (!$value$plusargs("VECDIR=%s", dir)) dir = ".";
    iv = '0;
    do_reset();
    run(0, {dir, "/div.vec"}, "div");
    run(1, {dir, "/sqrt.vec"}, "sqrt");
    run(2, {dir, "/recip.vec"}, "recip");
    run(3, {dir, "/exp.vec"}, "exp");
    run(4, {dir, "/log.vec"}, "log");
    report("tb_math");
    $finish;
  end
endmodule
