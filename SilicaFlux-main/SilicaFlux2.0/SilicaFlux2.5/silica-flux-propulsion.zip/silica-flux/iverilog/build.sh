#!/bin/sh
# =============================================================================
# Silica Flux -- Icarus Verilog full-chip compile check
#   sh iverilog/build.sh [LANES] [FP_MODE]
# Compiles silica_flux_top with Icarus 12 (-g2012) for the given configuration.
# Icarus also runs the cocotb unit regressions (python/cocotb) and the SV
# testbenches (tb/run_testbenches.py --sim icarus); the full-chip regression
# uses Verilator for speed.
# =============================================================================
set -e
cd "$(dirname "$0")/.."
LANES=${1:-8}
FP=${2:-0}
mkdir -p build/iverilog
iverilog -g2012 -o build/iverilog/silica_flux_top_l${LANES}_fp${FP}.vvp \
  -s silica_flux_top -P silica_flux_top.VECTOR_LANES=${LANES} -P silica_flux_top.FP_MODE=${FP} \
  -c iverilog/sources.f 2>&1 | grep -v "sorry: constant selects in always_\* processes" || true
test -f build/iverilog/silica_flux_top_l${LANES}_fp${FP}.vvp
echo "iverilog: silica_flux_top (lanes=${LANES}, fp_mode=${FP}) compiled -> build/iverilog/"
