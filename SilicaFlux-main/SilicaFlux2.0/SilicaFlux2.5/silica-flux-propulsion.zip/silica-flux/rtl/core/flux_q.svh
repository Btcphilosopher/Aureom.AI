// =============================================================================
// Silica Flux -- quality raised by one floating-point result
//   Q_NAN  <- NV flag or NaN result      Q_OVF <- OF flag or infinite result
//   Q_UNF  <- UF flag
// Included at module scope; requires parameters W and MAN_W.
// =============================================================================
function automatic logic [flux_pkg::QW-1:0] qual_of(input logic [W-1:0] r, input logic [4:0] f);
  logic [flux_pkg::QW-1:0] q;
  logic e1, m0;
  e1 = (r[W-2:MAN_W] == '1);
  m0 = (r[MAN_W-1:0] == '0);
  q = '0;
  q[flux_pkg::Q_NAN] = f[flux_pkg::FF_NV] | (e1 & !m0);
  q[flux_pkg::Q_OVF] = f[flux_pkg::FF_OF] | (e1 & m0);
  q[flux_pkg::Q_UNF] = f[flux_pkg::FF_UF];
  qual_of = q;
endfunction

// sign-bit helpers (whole-element arguments keep Icarus Verilog happy with
// variable-indexed packed arrays)
function automatic logic [W-1:0] fabs(input logic [W-1:0] x);
  fabs = {1'b0, x[W-2:0]};
endfunction
function automatic logic [W-1:0] fnabs(input logic [W-1:0] x);
  fnabs = {1'b1, x[W-2:0]};
endfunction
function automatic logic [W-1:0] fneg(input logic [W-1:0] x);
  fneg = {~x[W-1], x[W-2:0]};
endfunction
