// =============================================================================
// Silica Flux -- issue scheduler / scoreboard
// -----------------------------------------------------------------------------
// In-order, single-issue.  For the instruction at the head of the decode queue
// the scheduler evaluates, in one cycle:
//
//   legality     opcode, vector length, rounding mode, precision support of
//                the target functional unit, memory precision tags
//   precision    every source register's metadata must be valid (F_UNINIT)
//                and carry exactly the precision / fixed-point scale the
//                instruction expects (F_PRECISION) -- representations are
//                never mixed silently; partial writes may not change the
//                precision of a live register
//   hazards      RAW and WAW on vector registers and the mask register via a
//                busy-bit scoreboard (WAR cannot occur: operands are read at
//                issue); structural: retirement queue space, register-read
//                stage free; cross-engine ordering SWEEP <-> SEARCH
//
// A legality or precision failure still "issues": it occupies a retirement
// slot that completes immediately with the fault bits, so faults are reported
// in program order with the exact PC.
// =============================================================================
module flux_scheduler #(
  parameter int LANES   = 8,
  parameter int FP_MODE = 0,
  parameter int NREG    = 32
) (
  input  logic                           clk,
  input  logic                           rst_n,
  // head of the decode queue
  input  logic                           head_valid,
  input  flux_pkg::instr_t               head,
  input  logic                           ext_fault,     // instruction parity error
  // state
  input  logic [NREG-1:0][flux_pkg::META_W-1:0] meta,   // meta_t per register
  input  logic [2:0]                     frm,
  input  logic [3*flux_pkg::NUM_MEMS-1:0] mem_prec,
  input  logic [6*flux_pkg::NUM_MEMS-1:0] mem_scale,
  input  logic                           rob_full,
  input  logic                           rr_ready,
  // scoreboard update from write-back (registered by the retirement unit)
  input  logic                           clr_valid,
  input  logic [4:0]                     clr_vd,
  input  logic                           clr_wr_vd,
  input  logic                           clr_wr_vm,
  input  logic [3:0]                     clr_fu,
  // issue decision
  input  logic                           issue_fire,    // core commits the issue
  output logic                           can_issue,     // vector op (or fault) may issue
  output logic                           is_ctrl,
  output logic                           fault_only,
  output logic [flux_pkg::FAULT_W-1:0]   issue_faults,
  output logic [2:0]                     rm_eff,
  output logic                           stall_hazard,
  output logic [flux_pkg::NUM_FU-1:0][7:0] inflight
);
  localparam logic [2:0] NATIVE_FP = (FP_MODE != 0) ? flux_pkg::PREC_FP64 : flux_pkg::PREC_FP32;

  logic [NREG-1:0] busy;
  logic            busy_vm;
  logic [flux_pkg::NUM_FU-1:0][7:0] inflight_q;

  logic [3:0] fu, use_src;
  logic       wvd, wvm;
  assign fu      = flux_pkg::fu_of(head.opcode);
  assign use_src = flux_pkg::src_use(head);
  assign wvd     = flux_pkg::writes_vd(head);
  assign wvm     = flux_pkg::writes_vm(head);
  assign is_ctrl = (fu == flux_pkg::FU_CTRL);

  // ---- rounding mode resolution --------------------------------------------------------
  logic rm_bad;
  always_comb begin
    rm_eff = (head.rm == flux_pkg::RM_DYN) ? frm : head.rm;
    rm_bad = (rm_eff > flux_pkg::RM_RMM);
  end

  // ---- legality ----------------------------------------------------------------------------
  logic is_fx, prec_ok, illegal;
  logic [2:0] cvt_src;
  assign is_fx   = (head.prec == flux_pkg::PREC_SFIX) || (head.prec == flux_pkg::PREC_UFIX) || (head.prec == flux_pkg::PREC_INT);
  assign cvt_src = head.func[2:0];
  always_comb begin
    prec_ok = 1'b1;
    case (fu)
      flux_pkg::FU_CTRL: prec_ok = 1'b1;
      flux_pkg::FU_VALU: begin
        if (head.prec != NATIVE_FP && !is_fx) prec_ok = 1'b0;
        if (is_fx && (head.opcode == flux_pkg::OP_VFMS || head.opcode == flux_pkg::OP_VFNMA || head.opcode == flux_pkg::OP_VFNMS ||
                      head.opcode == flux_pkg::OP_VCLASS)) prec_ok = 1'b0;
        if (head.opcode == flux_pkg::OP_VCVT) begin
          if (head.prec == NATIVE_FP)
            prec_ok = (cvt_src == NATIVE_FP) || (cvt_src == flux_pkg::PREC_SFIX) || (cvt_src == flux_pkg::PREC_UFIX) || (cvt_src == flux_pkg::PREC_INT);
          else
            prec_ok = is_fx && (cvt_src == NATIVE_FP);
        end
      end
      flux_pkg::FU_LSU: prec_ok = (head.func[2:0] < 3'(flux_pkg::NUM_MEMS)) && (head.func[3] == 1'b0) &&
                        (mem_prec[head.func[2:0]*3 +: 3] == head.prec);
      default: prec_ok = (head.prec == NATIVE_FP);
    endcase
    illegal = (fu == 4'hF) || (!is_ctrl && ((int'(head.vl) > LANES) || rm_bad || !prec_ok));
  end

  // ---- source precision / initialisation ------------------------------------------------
  logic [2:0] exp_prec;
  flux_pkg::meta_t m_vd, m_vs1;
  logic [5:0] exp_scale;
  always_comb begin
    m_vs1     = meta[head.vs1];
    exp_prec  = head.prec;
    exp_scale = (head.prec == flux_pkg::PREC_SFIX || head.prec == flux_pkg::PREC_UFIX) ? head.imm[5:0] : 6'd0;
    if (head.opcode == flux_pkg::OP_VCVT) begin
      exp_prec  = cvt_src;
      exp_scale = (cvt_src == flux_pkg::PREC_SFIX || cvt_src == flux_pkg::PREC_UFIX) ? head.imm[11:6] : 6'd0;
    end else if (head.opcode == flux_pkg::OP_VSTORE) begin
      exp_prec  = mem_prec[head.func[2:0]*3 +: 3];
      exp_scale = mem_scale[head.func[2:0]*6 +: 6];
    end else if (head.opcode == flux_pkg::OP_VMSET) begin
      exp_scale = m_vs1.scale;        // imm carries mask bits, not a scale
    end
  end

  function automatic logic [1:0] chk(input flux_pkg::meta_t m, input logic [2:0] p, input logic [5:0] s);
    // {uninit, mismatch}
    if (!m.valid)                       chk = 2'b10;
    else if (m.prec != p || m.scale != s) chk = 2'b01;
    else                                chk = 2'b00;
  endfunction

  logic [1:0] c1, c2, c3;
  logic       uninit, mismatch, partial, mix;
  logic [2:0] dest_prec;
  always_comb begin
    c1 = use_src[0] ? chk(meta[head.vs1], exp_prec, exp_scale) : 2'b00;
    c2 = use_src[1] ? chk(meta[head.vs2], (head.opcode == flux_pkg::OP_VCVT) ? exp_prec : head.prec,
                          (head.opcode == flux_pkg::OP_VCVT) ? exp_scale : exp_scale) : 2'b00;
    c3 = use_src[2] ? chk(meta[head.vs3], head.prec, exp_scale) : 2'b00;
    uninit    = c1[1] | c2[1] | c3[1];
    mismatch  = c1[0] | c2[0] | c3[0];
    dest_prec = (head.opcode == flux_pkg::OP_VCLASS) ? flux_pkg::PREC_INT : head.prec;
    partial   = head.masked || (head.vl != 6'd0 && int'(head.vl) < LANES);
    m_vd      = meta[head.vd];
    mix       = wvd && partial && m_vd.valid && (m_vd.prec != dest_prec);
  end

  always_comb begin
    issue_faults = '0;
    issue_faults[flux_pkg::F_ILLEGAL]   = illegal;
    issue_faults[flux_pkg::F_UNINIT]    = !illegal && uninit;
    issue_faults[flux_pkg::F_PRECISION] = !illegal && !uninit && (mismatch || mix);
    issue_faults[flux_pkg::F_PARITY]    = ext_fault;
    fault_only = |issue_faults;
  end

  // ---- hazards -----------------------------------------------------------------------------
  logic raw, waw, xfu;
  always_comb begin
    raw = (use_src[0] && busy[head.vs1]) || (use_src[1] && busy[head.vs2]) ||
          (use_src[2] && busy[head.vs3]) || (use_src[3] && busy_vm);
    waw = (wvd && busy[head.vd]) || (wvm && busy_vm);
    xfu = ((fu == flux_pkg::FU_SEARCH) && inflight_q[flux_pkg::FU_SWEEP] != '0) ||
          ((fu == flux_pkg::FU_SWEEP)  && inflight_q[flux_pkg::FU_SEARCH] != '0);
    // metadata of a busy register is stale: legality / precision verdicts are
    // only final once every RAW / WAW hazard of the instruction has cleared
    stall_hazard = head_valid && !is_ctrl && (raw || waw || (!fault_only && xfu));
    if (fault_only) can_issue = head_valid && !rob_full && !raw && !waw;
    else            can_issue = head_valid && !is_ctrl && !raw && !waw && !xfu && !rob_full && rr_ready;
  end

  // ---- scoreboard state ---------------------------------------------------------------------
  logic vec_issue;
  assign vec_issue = issue_fire && !fault_only;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      busy       <= '0;
      busy_vm    <= 1'b0;
      inflight_q <= '0;
    end else begin
      for (int r = 0; r < NREG; r++) begin
        logic set, clr;
        set = vec_issue && wvd && (head.vd == 5'(r));
        clr = clr_valid && clr_wr_vd && (clr_vd == 5'(r));
        if (set)      busy[r] <= 1'b1;
        else if (clr) busy[r] <= 1'b0;
      end
      if (vec_issue && wvm)          busy_vm <= 1'b1;
      else if (clr_valid && clr_wr_vm) busy_vm <= 1'b0;
      for (int f = 0; f < flux_pkg::NUM_FU; f++) begin
        logic inc, dec;
        inc = vec_issue && (fu == 4'(f));
        dec = clr_valid && (clr_fu == 4'(f));
        if (inc && !dec)      inflight_q[f] <= inflight_q[f] + 8'd1;
        else if (dec && !inc) inflight_q[f] <= inflight_q[f] - 8'd1;
      end
    end
  end
  assign inflight = inflight_q;

`ifdef SF_SVA
  // a register is never set busy twice (WAW is blocked) and never cleared when idle
  a_no_double_busy: assert property (@(posedge clk) disable iff (!rst_n)
    vec_issue && wvd |-> !busy[head.vd]);
  a_clear_only_busy: assert property (@(posedge clk) disable iff (!rst_n)
    clr_valid && clr_wr_vd |-> busy[clr_vd]);
`endif
endmodule
