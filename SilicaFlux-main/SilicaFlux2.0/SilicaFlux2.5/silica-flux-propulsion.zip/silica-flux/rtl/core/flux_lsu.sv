// =============================================================================
// Silica Flux -- load / store unit (FU_LSU)
// -----------------------------------------------------------------------------
//   VLOAD  vd, func=mem, vs2=areg, imm   vd   <- MEM[mem][row]          (row-wide)
//   VSTORE vs1, func=mem, vs2=areg, imm  MEM[mem][row] <- vs1 (active lanes)
//   VLDBC  vd, func=mem, vs2=areg, imm   vd   <- broadcast MEM element
// The effective address (A[areg] + imm) is computed in the issue stage and
// carried in uop.ins.imm, so the LSU never reads the scalar register file.
// Every element carries its quality bits and a parity bit through memory;
// a parity error marks the lane Q_NAN|Q_SUSPECT and raises F_PARITY, an
// out-of-range or read-only access raises F_MEMADDR and writes nothing.
// =============================================================================
`include "flux_fu_if.svh"
module flux_lsu #(
  parameter int LANES = 8,
  parameter int W     = 32
) (
  input  logic                              clk,
  input  logic                              rst_n,
  `SF_FU_PORTS,
  // internal-bus master port
  output logic                              mem_req_valid,
  input  logic                              mem_req_ready,
  output logic                              mem_req_we,
  output logic [2:0]                        mem_req_id,
  output logic [15:0]                       mem_req_row,
  output logic [LANES-1:0]                  mem_req_wmask,
  output logic [LANES*(W+flux_pkg::QW)-1:0] mem_req_wdata,
  input  logic                              mem_rsp_valid,
  input  logic [LANES*(W+flux_pkg::QW)-1:0] mem_rsp_rdata,
  input  logic                              mem_rsp_err_addr,
  input  logic [LANES-1:0]                  mem_rsp_err_parity,
  output logic [31:0]                       loads,
  output logic [31:0]                       stores
);
  localparam int EW = W + flux_pkg::QW;
  localparam int LW = (LANES > 1) ? $clog2(LANES) : 1;

  typedef enum logic [1:0] {S_IDLE, S_REQ, S_WAIT, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t                uop_q;
  logic [LANES-1:0]    lmask_q;
  logic [LANES*EW-1:0] wdata_q, rdata_q;
  logic                err_addr_q;
  logic [LANES-1:0]    err_par_q;
  logic [31:0]         ld_q, st_q;

  logic is_store, is_bc;
  assign is_store = (uop_q.ins.opcode == flux_pkg::OP_VSTORE);
  assign is_bc    = (uop_q.ins.opcode == flux_pkg::OP_VLDBC);

  logic [18:0] ea;
  assign ea = uop_q.ins.imm;

  assign mem_req_valid = (state == S_REQ);
  assign mem_req_we    = is_store;
  assign mem_req_id    = uop_q.ins.func[2:0];
  assign mem_req_row   = is_bc ? 16'(ea >> LW) : ea[15:0];
  assign mem_req_wmask = lmask_q;
  assign mem_req_wdata = wdata_q;
  assign req_ready     = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
      ld_q  <= '0;
      st_q  <= '0;
    end else begin
      case (state)
        S_IDLE: if (req_valid) state <= S_REQ;
        S_REQ:  if (mem_req_ready) state <= S_WAIT;
        S_WAIT: if (mem_rsp_valid) begin
          state <= S_RESP;
          if (is_store) st_q <= st_q + 32'd1;
          else          ld_q <= ld_q + 32'd1;
        end
        S_RESP: if (rsp_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    if (state == S_IDLE && req_valid) begin
      uop_q   <= req_uop;
      lmask_q <= req_lmask;
      for (int l = 0; l < LANES; l++)
        wdata_q[l*EW +: EW] <= {req_qa[l*flux_pkg::QW +: flux_pkg::QW], req_a[l*W +: W]};
    end
    if (state == S_WAIT && mem_rsp_valid) begin
      rdata_q    <= mem_rsp_rdata;
      err_addr_q <= mem_rsp_err_addr;
      err_par_q  <= mem_rsp_err_parity;
    end
  end

  // ---- response -------------------------------------------------------------------
  logic [LW-1:0] bl;
  assign bl = ea[LW-1:0];
  always_comb begin
    rsp_faults = '0;
    for (int l = 0; l < LANES; l++) begin
      logic [EW-1:0]  e;
      logic           pe;
      e  = is_bc ? rdata_q[bl*EW +: EW] : rdata_q[l*EW +: EW];
      pe = is_bc ? err_par_q[bl] : err_par_q[l];
      rsp_data[l*W +: W]   = e[W-1:0];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = e[W +: flux_pkg::QW] | (pe ? flux_pkg::QW'((1 << flux_pkg::Q_NAN) | (1 << flux_pkg::Q_SUSPECT)) : '0);
    end
    rsp_faults[flux_pkg::F_MEMADDR] = err_addr_q;
    rsp_faults[flux_pkg::F_PARITY]  = !is_store && !err_addr_q &&
                            (is_bc ? err_par_q[bl] : |(err_par_q & lmask_q));
  end
  assign rsp_valid  = (state == S_RESP);
  assign rsp_uop    = uop_q;
  assign rsp_wmask  = err_addr_q ? '0 : lmask_q;
  assign rsp_vm     = '0;
  assign rsp_fflags = '0;
  assign loads      = ld_q;
  assign stores     = st_q;
endmodule
