// =============================================================================
// Silica Flux -- architectural package
// -----------------------------------------------------------------------------
// Shared encodings for the whole fabric: numerical formats, rounding modes,
// exception flags, per-element quality bits, metadata, instruction format,
// opcodes, functional-unit identifiers and fault identifiers.
//
// Every encoding here is mirrored in python/golden_model/isa.py and documented
// in firmware/instruction_set.md / firmware/register_map.md.  Changing one
// without the others is a verification failure by construction (the Python
// ISA model is generated against the same tables and cross-checked in CI).
// =============================================================================
`ifndef FLUX_PKG_SV
`define FLUX_PKG_SV
package flux_pkg;

  // ---------------------------------------------------------------------------
  // Numerical representation
  // ---------------------------------------------------------------------------
  localparam logic [2:0] PREC_FP32 = 3'd0;
  localparam logic [2:0] PREC_FP64 = 3'd1;
  localparam logic [2:0] PREC_SFIX = 3'd2;   // signed two's complement Q(W-1-F).F
  localparam logic [2:0] PREC_UFIX = 3'd3;   // unsigned Q(W-F).F
  localparam logic [2:0] PREC_INT  = 3'd4;   // signed integer (F = 0)

  // Rounding modes (RISC-V encoding).  RM_DYN selects the FRM CSR.
  localparam logic [2:0] RM_RNE = 3'd0;
  localparam logic [2:0] RM_RTZ = 3'd1;
  localparam logic [2:0] RM_RDN = 3'd2;
  localparam logic [2:0] RM_RUP = 3'd3;
  localparam logic [2:0] RM_RMM = 3'd4;
  localparam logic [2:0] RM_DYN = 3'd7;

  // IEEE exception flag bit positions (RISC-V fflags layout)
  localparam int FF_NX = 0;
  localparam int FF_UF = 1;
  localparam int FF_OF = 2;
  localparam int FF_DZ = 3;
  localparam int FF_NV = 4;

  // Per-element quality bits.  They travel with every value through the
  // register file, the memories and the result stream, and are OR-propagated
  // through every operation: a value derived from a suspect value is suspect.
  localparam int QW        = 4;
  localparam int Q_NAN     = 0;   // invalid operation / NaN in the derivation
  localparam int Q_OVF     = 1;   // overflow / infinity / saturation
  localparam int Q_UNF     = 2;   // underflow: precision lost to subnormal range
  localparam int Q_SUSPECT = 3;   // range, residual, conservation, telemetry quality

  // FMA unit operation codes (also used by every engine that embeds an FMA)
  localparam logic [2:0] FMA_FMADD  = 3'd0;  //  a*b + c
  localparam logic [2:0] FMA_FMSUB  = 3'd1;  //  a*b - c
  localparam logic [2:0] FMA_FNMSUB = 3'd2;  // -a*b + c
  localparam logic [2:0] FMA_FNMADD = 3'd3;  // -a*b - c
  localparam logic [2:0] FMA_FMUL   = 3'd4;  //  a*b
  localparam logic [2:0] FMA_FADD   = 3'd5;  //  a + c
  localparam logic [2:0] FMA_FSUB   = 3'd6;  //  a - c

  // ---------------------------------------------------------------------------
  // Metadata carried by every vector register
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic        valid;     // register has been written since reset
    logic [2:0]  prec;      // PREC_*
    logic [5:0]  scale;     // fixed-point fractional bits (0 for FP/INT)
    logic [7:0]  source;    // opcode (or memory id | 0x80) that produced it
    logic [31:0] tstamp;    // fabric timestamp at write-back
  } meta_t;                 // 50 bits
  localparam int META_W = 1 + 3 + 6 + 8 + 32;   // $bits(meta_t), explicit for Yosys

  // ---------------------------------------------------------------------------
  // Instruction word (64 bits)
  //   63:56 opcode | 55:51 vd | 50:46 vs1 | 45:41 vs2 | 40:36 vs3 |
  //   35:33 prec   | 32:30 rm | 29 masked | 28:23 vl  | 22:19 func | 18:0 imm
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [7:0]  opcode;
    logic [4:0]  vd;
    logic [4:0]  vs1;
    logic [4:0]  vs2;
    logic [4:0]  vs3;
    logic [2:0]  prec;
    logic [2:0]  rm;
    logic        masked;
    logic [5:0]  vl;
    logic [3:0]  func;
    logic [18:0] imm;
  } instr_t;

  // ---------------------------------------------------------------------------
  // Opcodes
  // ---------------------------------------------------------------------------
  // control (executed in the issue stage)
  localparam logic [7:0] OP_NOP      = 8'h00;
  localparam logic [7:0] OP_HALT     = 8'h01;
  localparam logic [7:0] OP_BARRIER  = 8'h02;
  localparam logic [7:0] OP_SETA     = 8'h03;
  localparam logic [7:0] OP_ADDA     = 8'h04;
  localparam logic [7:0] OP_BNZ      = 8'h05;
  // vector ALU (fixed latency, fully pipelined)
  localparam logic [7:0] OP_VADD     = 8'h10;
  localparam logic [7:0] OP_VSUB     = 8'h11;
  localparam logic [7:0] OP_VMUL     = 8'h12;
  localparam logic [7:0] OP_VFMA     = 8'h13;
  localparam logic [7:0] OP_VFMS     = 8'h14;
  localparam logic [7:0] OP_VFNMA    = 8'h15;
  localparam logic [7:0] OP_VFNMS    = 8'h16;
  localparam logic [7:0] OP_VSQR     = 8'h17;
  localparam logic [7:0] OP_VMIN     = 8'h18;
  localparam logic [7:0] OP_VMAX     = 8'h19;
  localparam logic [7:0] OP_VABS     = 8'h1A;
  localparam logic [7:0] OP_VNEG     = 8'h1B;
  localparam logic [7:0] OP_VCMP     = 8'h1C;
  localparam logic [7:0] OP_VSEL     = 8'h1D;
  localparam logic [7:0] OP_VMOV     = 8'h1E;
  localparam logic [7:0] OP_VCLASS   = 8'h1F;
  localparam logic [7:0] OP_VCVT     = 8'h20;
  localparam logic [7:0] OP_VBCAST   = 8'h21;
  localparam logic [7:0] OP_VLANEID  = 8'h22;
  localparam logic [7:0] OP_VMSET    = 8'h23;
  localparam logic [7:0] OP_VSLIDE   = 8'h24;   // lane rotate: vd[l] = vs1[(l+k) mod LANES]
  // iterative divide / square root
  localparam logic [7:0] OP_VDIV     = 8'h30;
  localparam logic [7:0] OP_VSQRT    = 8'h31;
  // special-function unit (table + polynomial approximations)
  localparam logic [7:0] OP_VRECIP   = 8'h32;
  localparam logic [7:0] OP_VEXP     = 8'h33;
  localparam logic [7:0] OP_VLOG     = 8'h34;
  // math engines
  localparam logic [7:0] OP_VPOLY    = 8'h38;
  localparam logic [7:0] OP_VCUBE    = 8'h39;
  localparam logic [7:0] OP_VINTERP  = 8'h3A;
  localparam logic [7:0] OP_VREDUCE  = 8'h3C;
  // load / store
  localparam logic [7:0] OP_VLOAD    = 8'h40;
  localparam logic [7:0] OP_VSTORE   = 8'h41;
  localparam logic [7:0] OP_VLDBC    = 8'h42;
  // physical-system state engine
  localparam logic [7:0] OP_STATE_UPDATE = 8'h50;
  localparam logic [7:0] OP_TSCFG    = 8'h51;
  localparam logic [7:0] OP_RESIDUAL = 8'h52;
  localparam logic [7:0] OP_CONSERVE = 8'h53;
  // optimisation engines
  localparam logic [7:0] OP_OBJECTIVE  = 8'h60;
  localparam logic [7:0] OP_CONSTRAINT = 8'h61;
  localparam logic [7:0] OP_SWEEP      = 8'h62;
  localparam logic [7:0] OP_SEARCH     = 8'h63;

  // func sub-codes ------------------------------------------------------------
  localparam logic [3:0] CMP_EQ = 4'd0, CMP_LT = 4'd1, CMP_LE = 4'd2;
  localparam logic [3:0] VMS_ALL = 4'd0, VMS_NZ = 4'd1, VMS_NOT = 4'd2, VMS_IMM = 4'd3;
  localparam logic [3:0] RED_SUM = 4'd0, RED_MIN = 4'd1, RED_MAX = 4'd2, RED_SUMSQ = 4'd3,
                         RED_DOT = 4'd4, RED_ARGMIN = 4'd5, RED_ARGMAX = 4'd6, RED_MAXABS = 4'd7;
  localparam logic [3:0] BAR_TELEM = 4'd1, BAR_DMA = 4'd2, BAR_SWAP = 4'd4;  // bit flags
  localparam logic [3:0] SU_LOAD = 4'd8;          // STATE_UPDATE func: 0..3 stage, 8 load x0
  localparam logic [3:0] TS_EULER = 4'd0, TS_HEUN = 4'd1, TS_MIDPOINT = 4'd2,
                         TS_RALSTON = 4'd3, TS_RK4 = 4'd4, TS_CUSTOM = 4'd7, TS_RESET = 4'd15;
  localparam logic [3:0] RES_SIGNED = 4'd0, RES_ABS = 4'd1, RES_MARGIN = 4'd2;
  localparam logic [3:0] CONS_CAPTURE = 4'd0, CONS_CHECK = 4'd1, CONS_CHECK_ADV = 4'd2;
  localparam logic [3:0] OBJ_WSUM = 4'd0, OBJ_ABS = 4'd1, OBJ_SQ = 4'd2, OBJ_PENALTY = 4'd3;
  localparam logic [3:0] CON_LT = 4'd0, CON_GT = 4'd1, CON_EQ = 4'd2, CON_TOL = 4'd3,
                         CON_LE = 4'd4, CON_GE = 4'd5;
  localparam logic [3:0] SW_RESET = 4'd0, SW_GEN = 4'd1, SW_NEXT = 4'd2;
  localparam logic [3:0] SR_RESET = 4'd0, SR_GRID = 4'd1, SR_LOCAL = 4'd2, SR_LS_GEN = 4'd3;

  // Memory identifiers (VLOAD/VSTORE func field, host window, DMA)
  localparam logic [2:0] MEM_STATE   = 3'd0;  // current state bank
  localparam logic [2:0] MEM_STATE_N = 3'd1;  // next state bank (ping-pong)
  localparam logic [2:0] MEM_PARAM   = 3'd2;
  localparam logic [2:0] MEM_COEFF   = 3'd3;
  localparam logic [2:0] MEM_SCRATCH = 3'd4;
  localparam logic [2:0] MEM_RESULT  = 3'd5;
  localparam logic [2:0] MEM_TELEM   = 3'd6;  // telemetry channel table (read-only)
  localparam int         NUM_MEMS    = 7;

  // ---------------------------------------------------------------------------
  // Functional units
  // ---------------------------------------------------------------------------
  localparam logic [3:0] FU_CTRL    = 4'd0;
  localparam logic [3:0] FU_VALU    = 4'd1;
  localparam logic [3:0] FU_DIVSQRT = 4'd2;
  localparam logic [3:0] FU_SFU     = 4'd3;
  localparam logic [3:0] FU_LSU     = 4'd4;
  localparam logic [3:0] FU_RED     = 4'd5;
  localparam logic [3:0] FU_POLY    = 4'd6;
  localparam logic [3:0] FU_INTERP  = 4'd7;
  localparam logic [3:0] FU_STATE   = 4'd8;
  localparam logic [3:0] FU_RESID   = 4'd9;
  localparam logic [3:0] FU_CONS    = 4'd10;
  localparam logic [3:0] FU_OBJ     = 4'd11;
  localparam logic [3:0] FU_CON     = 4'd12;
  localparam logic [3:0] FU_SWEEP   = 4'd13;
  localparam logic [3:0] FU_SEARCH  = 4'd14;
  localparam int         NUM_FU     = 15;

  localparam int TAG_W = 4;               // retirement-queue tag (16 in flight)

  typedef struct packed {
    instr_t           ins;
    logic [15:0]      pc;
    logic [TAG_W-1:0] tag;
    logic [3:0]       fu;
    logic [2:0]       rm;       // resolved (never RM_DYN)
    logic             wr_vd;
    logic             wr_vm;
  } uop_t;
  localparam int UOP_W = 64 + 16 + TAG_W + 4 + 3 + 1 + 1;   // $bits(uop_t), kept explicit for Yosys

  // ---------------------------------------------------------------------------
  // Fault identifiers (bit positions in FAULT_STATUS)
  // ---------------------------------------------------------------------------
  localparam int FAULT_W        = 24;
  localparam int F_WATCHDOG     = 0;   // no retirement within WDT_LIMIT cycles
  localparam int F_TIMEOUT      = 1;   // DMA / bus transaction timeout
  localparam int F_ILLEGAL      = 2;   // illegal instruction encoding
  localparam int F_PRECISION    = 3;   // operand precision / scale mismatch
  localparam int F_NAN          = 4;   // a NaN was produced (NV or propagation)
  localparam int F_OVERFLOW     = 5;   // OF flag or fixed-point saturation
  localparam int F_UNDERFLOW    = 6;   // UF flag
  localparam int F_DIVZERO      = 7;   // DZ flag
  localparam int F_RANGE        = 8;   // range checker violation
  localparam int F_PARITY       = 9;   // memory / instruction parity error
  localparam int F_MEMADDR      = 10;  // illegal memory access
  localparam int F_TL_SEQ       = 11;  // telemetry dropped / duplicate packet
  localparam int F_TL_CRC       = 12;  // telemetry CRC failure
  localparam int F_TL_TS        = 13;  // telemetry timestamp discontinuity
  localparam int F_TL_OVF       = 14;  // telemetry buffer overflow
  localparam int F_CONSERVATION = 15;  // conservation residual above threshold
  localparam int F_RESIDUAL     = 16;  // lane residual above threshold
  localparam int F_PIPELINE     = 17;  // internal protocol / scoreboard violation
  localparam int F_STEP         = 18;  // invalid timestep (dt <= 0, NaN, Inf)
  localparam int F_TL_MALFORMED = 19;  // telemetry framing / channel error
  localparam int F_UNINIT       = 20;  // read of a never-written register
  localparam int F_CONSTRAINT   = 21;  // constraint failure (informational)
  localparam int F_SEARCH       = 22;  // search/sweep configuration invalid
  localparam int F_HOST         = 23;  // host-injected test fault

  // ---------------------------------------------------------------------------
  // Decode helpers
  // ---------------------------------------------------------------------------
  function automatic logic [3:0] fu_of(input logic [7:0] op);
    case (op)
      OP_NOP, OP_HALT, OP_BARRIER, OP_SETA, OP_ADDA, OP_BNZ: fu_of = FU_CTRL;
      OP_VADD, OP_VSUB, OP_VMUL, OP_VFMA, OP_VFMS, OP_VFNMA, OP_VFNMS, OP_VSQR,
      OP_VMIN, OP_VMAX, OP_VABS, OP_VNEG, OP_VCMP, OP_VSEL, OP_VMOV, OP_VCLASS,
      OP_VCVT, OP_VBCAST, OP_VLANEID, OP_VMSET, OP_VSLIDE:  fu_of = FU_VALU;
      OP_VDIV, OP_VSQRT:                                    fu_of = FU_DIVSQRT;
      OP_VRECIP, OP_VEXP, OP_VLOG:                          fu_of = FU_SFU;
      OP_VPOLY, OP_VCUBE:                                   fu_of = FU_POLY;
      OP_VINTERP:                                           fu_of = FU_INTERP;
      OP_VREDUCE:                                           fu_of = FU_RED;
      OP_VLOAD, OP_VSTORE, OP_VLDBC:                        fu_of = FU_LSU;
      OP_STATE_UPDATE, OP_TSCFG:                            fu_of = FU_STATE;
      OP_RESIDUAL:                                          fu_of = FU_RESID;
      OP_CONSERVE:                                          fu_of = FU_CONS;
      OP_OBJECTIVE:                                         fu_of = FU_OBJ;
      OP_CONSTRAINT:                                        fu_of = FU_CON;
      OP_SWEEP:                                             fu_of = FU_SWEEP;
      OP_SEARCH:                                            fu_of = FU_SEARCH;
      default:                                              fu_of = 4'hF;  // illegal
    endcase
  endfunction

  // source-register usage: {uses_vm, uses_vs3, uses_vs2, uses_vs1}
  function automatic logic [3:0] src_use(input instr_t i);
    logic [3:0] u;
    u = 4'b0000;
    case (i.opcode)
      OP_VADD, OP_VSUB, OP_VMUL, OP_VMIN, OP_VMAX, OP_VDIV:    u = 4'b0011;
      OP_VFMA, OP_VFMS, OP_VFNMA, OP_VFNMS:                    u = 4'b0111;
      OP_VSQR, OP_VABS, OP_VNEG, OP_VMOV, OP_VCLASS, OP_VCVT,
      OP_VBCAST, OP_VSLIDE, OP_VSQRT, OP_VRECIP, OP_VEXP, OP_VLOG,
      OP_VCUBE, OP_TSCFG:                                      u = 4'b0001;
      OP_VCMP:                                                 u = 4'b0011;
      OP_VSEL:                                                 u = 4'b1011;
      OP_VMSET:   u = (i.func == VMS_NZ) ? 4'b0001 : (i.func == VMS_NOT) ? 4'b1000 : 4'b0000;
      OP_VPOLY:                                                u = 4'b0011;
      OP_VINTERP:                                              u = 4'b0111;
      OP_VREDUCE: u = (i.func == RED_DOT) ? 4'b0011 : 4'b0001;
      OP_VSTORE:                                               u = 4'b0001;
      OP_STATE_UPDATE: u = 4'b0001;
      OP_RESIDUAL:                                             u = 4'b0111;
      OP_OBJECTIVE:  u = (i.func[1:0] == OBJ_ABS[1:0] || i.func[1:0] == OBJ_SQ[1:0]) ? 4'b0111 : 4'b0101;
      OP_CONSTRAINT: u = (i.func == CON_TOL) ? 4'b0111 : 4'b0011;
      OP_CONSERVE: u = (i.func == CONS_CAPTURE) ? 4'b0011 : 4'b0111;
      OP_SEARCH:  u = (i.func == SR_GRID || i.func == SR_LOCAL) ? 4'b1001 : 4'b0000;
      default:                                                 u = 4'b0000;
    endcase
    if (i.masked) u[3] = 1'b1;
    src_use = u;
  endfunction

  function automatic logic writes_vd(input instr_t i);
    case (i.opcode)
      OP_NOP, OP_HALT, OP_BARRIER, OP_SETA, OP_ADDA, OP_BNZ,
      OP_VSTORE, OP_VMSET, OP_TSCFG: writes_vd = 1'b0;
      OP_SWEEP:  writes_vd = (i.func == SW_GEN);
      OP_SEARCH: writes_vd = (i.func == SR_LS_GEN);
      default:  writes_vd = (fu_of(i.opcode) != 4'hF);
    endcase
  endfunction

  function automatic logic writes_vm(input instr_t i);
    case (i.opcode)
      OP_VCMP, OP_VMSET, OP_CONSTRAINT: writes_vm = 1'b1;
      OP_RESIDUAL: writes_vm = 1'b1;
      OP_SWEEP:    writes_vm = (i.func == SW_GEN);
      OP_SEARCH:   writes_vm = (i.func == SR_LS_GEN);
      default:     writes_vm = 1'b0;
    endcase
  endfunction

endpackage
`endif
