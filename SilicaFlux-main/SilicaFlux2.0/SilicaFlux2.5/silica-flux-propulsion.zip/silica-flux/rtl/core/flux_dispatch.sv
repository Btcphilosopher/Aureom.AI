// =============================================================================
// Silica Flux -- register-read / dispatch stage
// -----------------------------------------------------------------------------
// Holds one issued micro-op while the vector register file delivers its
// operands (synchronous read issued in the same cycle the op was accepted),
// forms the active-lane mask
//      lmask = (vl == 0 ? all : lanes < vl) & (masked ? VM : all)
// and presents the request to exactly one functional unit.  The stage frees
// itself when the target unit accepts (valid && ready); until then the VRF
// read latches hold the operands stable, satisfying the valid/ready rule.
// =============================================================================
module flux_dispatch #(
  parameter int LANES = 8
) (
  input  logic                       clk,
  input  logic                       rst_n,
  input  logic                       in_valid,      // issue fire (vector op)
  input  flux_pkg::uop_t             in_uop,
  output logic                       rr_ready,
  // VRF read data (valid the cycle after issue, held until next read)
  input  logic [LANES-1:0]           vrf_vm,
  // to functional units
  output logic [flux_pkg::NUM_FU-1:0] fu_req_valid,
  input  logic [flux_pkg::NUM_FU-1:0] fu_req_ready,
  output flux_pkg::uop_t             d_uop,
  output logic [LANES-1:0]           d_lmask,
  output logic [LANES-1:0]           d_vm,
  output logic                       busy
);
  logic  rr_valid;
  flux_pkg::uop_t  rr_uop;
  logic  fire;
  logic [LANES-1:0] vlmask;

  always_comb begin
    for (int l = 0; l < LANES; l++)
      vlmask[l] = (rr_uop.ins.vl == 6'd0) || (l < int'(rr_uop.ins.vl));
  end
  assign d_uop   = rr_uop;
  assign d_vm    = vrf_vm;
  assign d_lmask = vlmask & (rr_uop.ins.masked ? vrf_vm : {LANES{1'b1}});

  always_comb begin
    fu_req_valid = '0;
    if (rr_valid) fu_req_valid[rr_uop.fu] = 1'b1;
  end
  assign fire     = rr_valid && fu_req_ready[rr_uop.fu];
  assign rr_ready = !rr_valid || fire;
  assign busy     = rr_valid;

  always_ff @(posedge clk) begin
    if (!rst_n)        rr_valid <= 1'b0;
    else if (rr_ready) rr_valid <= in_valid;
  end
  always_ff @(posedge clk) begin
    if (rr_ready && in_valid) rr_uop <= in_uop;
  end

`ifdef SF_SVA
  a_req_stable: assert property (@(posedge clk) disable iff (!rst_n)
    rr_valid && !fire |=> rr_valid && $stable(rr_uop));
`endif
endmodule
