// =============================================================================
// Silica Flux -- functional-unit port convention
// -----------------------------------------------------------------------------
// Every execution unit in the compute fabric presents exactly this interface to
// the dispatch stage (request) and to the write-back arbiter (response).  Both
// sides are valid/ready channels; payloads are stable while valid && !ready.
//
//   request   req_uop      decoded micro-op (instruction, pc, tag, fu, rm, wr_*)
//             req_a/b/c    operands vs1/vs2/vs3, LANES x W
//             req_qa/qb/qc per-element quality of each operand
//             req_lmask    active lanes = (lane < vl) & (masked ? VM : 1)
//             req_vm       current mask register
//   response  rsp_data     result vector (written to vd when uop.wr_vd)
//             rsp_qual     result quality (propagated + newly raised)
//             rsp_wmask    lanes to write in vd / VM
//             rsp_vm       new mask bits (written when uop.wr_vm)
//             rsp_fflags   IEEE flags OR-ed over active lanes
//             rsp_faults   unit-detected fault events (flux_pkg::F_*)
//
// Modules using these macros must declare parameters LANES and W.
// =============================================================================
`ifndef FLUX_FU_IF_SVH
`define FLUX_FU_IF_SVH

`define SF_FU_PORTS \
  input  logic                          req_valid, \
  output logic                          req_ready, \
  input  flux_pkg::uop_t                req_uop, \
  input  logic [LANES*W-1:0]            req_a, \
  input  logic [LANES*W-1:0]            req_b, \
  input  logic [LANES*W-1:0]            req_c, \
  input  logic [LANES*flux_pkg::QW-1:0] req_qa, \
  input  logic [LANES*flux_pkg::QW-1:0] req_qb, \
  input  logic [LANES*flux_pkg::QW-1:0] req_qc, \
  input  logic [LANES-1:0]              req_lmask, \
  input  logic [LANES-1:0]              req_vm, \
  output logic                          rsp_valid, \
  input  logic                          rsp_ready, \
  output flux_pkg::uop_t                rsp_uop, \
  output logic [LANES*W-1:0]            rsp_data, \
  output logic [LANES*flux_pkg::QW-1:0] rsp_qual, \
  output logic [LANES-1:0]              rsp_wmask, \
  output logic [LANES-1:0]              rsp_vm, \
  output logic [4:0]                    rsp_fflags, \
  output logic [flux_pkg::FAULT_W-1:0]  rsp_faults

`define SF_FU_CONNECT(IDX) \
  .req_valid (fu_req_valid[IDX]), \
  .req_ready (fu_req_ready[IDX]), \
  .req_uop   (d_uop), \
  .req_a     (d_a), \
  .req_b     (d_b), \
  .req_c     (d_c), \
  .req_qa    (d_qa), \
  .req_qb    (d_qb), \
  .req_qc    (d_qc), \
  .req_lmask (d_lmask), \
  .req_vm    (d_vm), \
  .rsp_valid (fu_rsp_valid[IDX]), \
  .rsp_ready (fu_rsp_ready[IDX]), \
  .rsp_uop   (fu_rsp_uop[IDX]), \
  .rsp_data  (fu_rsp_data[IDX]), \
  .rsp_qual  (fu_rsp_qual[IDX]), \
  .rsp_wmask (fu_rsp_wmask[IDX]), \
  .rsp_vm    (fu_rsp_vm[IDX]), \
  .rsp_fflags(fu_rsp_fflags[IDX]), \
  .rsp_faults(fu_rsp_faults[IDX])

`endif
