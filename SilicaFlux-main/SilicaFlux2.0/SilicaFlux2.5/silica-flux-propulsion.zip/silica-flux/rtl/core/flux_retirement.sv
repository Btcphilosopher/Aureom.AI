// =============================================================================
// Silica Flux -- write-back and retirement
// -----------------------------------------------------------------------------
// Write-back: a round-robin arbiter grants one functional-unit response per
//   cycle to the single register-file write port.  Units hold their response
//   (valid/ready) until granted, so simultaneous completions never lose data.
//   Metadata of the destination is rewritten (precision, scale, producing
//   opcode, fabric timestamp); scoreboard bits are released one cycle later.
// Retirement: a 16-entry in-order completion queue (allocated at issue,
//   completed by tag at write-back, retired from the head).  Numerical
//   exceptions are converted to fault events here:
//       NV or a NaN written  -> F_NAN        OF -> F_OVERFLOW
//       UF                   -> F_UNDERFLOW  DZ -> F_DIVZERO
//   and every fault leaves the core in program order with its exact PC.
//   Register writes of younger instructions already in flight still complete
//   (imprecise writes, precise attribution) -- documented in
//   docs/microarchitecture.md.
// =============================================================================
module flux_retirement #(
  parameter int LANES = 8,
  parameter int W     = 32,
  parameter int DEPTH = 16
) (
  input  logic                                   clk,
  input  logic                                   rst_n,
  input  logic [31:0]                            tstamp,
  // functional-unit responses
  input  logic [flux_pkg::NUM_FU-1:0]            fu_rsp_valid,
  output logic [flux_pkg::NUM_FU-1:0]            fu_rsp_ready,
  input  logic [flux_pkg::NUM_FU-1:0][flux_pkg::UOP_W-1:0] fu_rsp_uop,   // uop_t per unit
  input  logic [flux_pkg::NUM_FU-1:0][LANES*W-1:0] fu_rsp_data,
  input  logic [flux_pkg::NUM_FU-1:0][LANES*flux_pkg::QW-1:0] fu_rsp_qual,
  input  logic [flux_pkg::NUM_FU-1:0][LANES-1:0] fu_rsp_wmask,
  input  logic [flux_pkg::NUM_FU-1:0][LANES-1:0] fu_rsp_vm,
  input  logic [flux_pkg::NUM_FU-1:0][4:0]       fu_rsp_fflags,
  input  logic [flux_pkg::NUM_FU-1:0][flux_pkg::FAULT_W-1:0] fu_rsp_faults,
  input  logic [6*flux_pkg::NUM_MEMS-1:0]        mem_scale,
  // register file write port
  output logic                                   vrf_we,
  output logic [4:0]                             vrf_wa,
  output logic [LANES-1:0]                       vrf_wmask,
  output logic [LANES*W-1:0]                     vrf_wd,
  output logic [LANES*flux_pkg::QW-1:0]          vrf_wq,
  output logic                                   meta_we,
  output flux_pkg::meta_t                        meta_wd,
  output logic                                   vm_we,
  output logic [LANES-1:0]                       vm_wd,
  // scoreboard release (registered)
  output logic                                   clr_valid,
  output logic [4:0]                             clr_vd,
  output logic                                   clr_wr_vd,
  output logic                                   clr_wr_vm,
  output logic [3:0]                             clr_fu,
  // allocation (issue)
  input  logic                                   alloc,
  input  logic [15:0]                            alloc_pc,
  input  logic                                   alloc_done,     // fault-only entry
  input  logic [flux_pkg::FAULT_W-1:0]           alloc_faults,
  output logic [flux_pkg::TAG_W-1:0]             alloc_tag,
  output logic                                   full,
  output logic                                   empty,
  // retirement
  output logic                                   retire_valid,
  output logic [15:0]                            retire_pc,
  output logic [flux_pkg::FAULT_W-1:0]           retire_faults,
  output logic [4:0]                             retire_fflags,
  // statistics
  output logic                                   wb_fire,
  output logic [3:0]                             wb_fu,
  output logic [7:0]                             wb_lanes
);
  localparam int FW = $clog2(flux_pkg::NUM_FU);

  // ---- write-back arbitration ------------------------------------------------------------
  logic [flux_pkg::NUM_FU-1:0] grant;
  logic [FW-1:0]     gidx;
  logic              any;
  sf_rr_arb #(.N(flux_pkg::NUM_FU)) u_arb (
    .clk(clk), .rst_n(rst_n), .req(fu_rsp_valid), .advance(1'b1),
    .grant(grant), .grant_idx(gidx), .any(any));
  assign fu_rsp_ready = grant;

  flux_pkg::uop_t                u;
  logic [LANES-1:0]    wm;
  logic [LANES*flux_pkg::QW-1:0] wq;
  logic [4:0]          ff;
  logic [flux_pkg::FAULT_W-1:0]  flt;
  assign u   = fu_rsp_uop[gidx];
  assign wm  = fu_rsp_wmask[gidx];
  assign wq  = fu_rsp_qual[gidx];
  assign ff  = fu_rsp_fflags[gidx];

  logic nan_written;
  always_comb begin
    nan_written = 1'b0;
    if (u.wr_vd)
      for (int l = 0; l < LANES; l++) if (wm[l] && wq[l*flux_pkg::QW + flux_pkg::Q_NAN]) nan_written = 1'b1;
    flt = fu_rsp_faults[gidx];
    flt[flux_pkg::F_NAN]       = flt[flux_pkg::F_NAN] | ff[flux_pkg::FF_NV] | nan_written;
    flt[flux_pkg::F_OVERFLOW]  = flt[flux_pkg::F_OVERFLOW] | ff[flux_pkg::FF_OF];
    flt[flux_pkg::F_UNDERFLOW] = flt[flux_pkg::F_UNDERFLOW] | ff[flux_pkg::FF_UF];
    flt[flux_pkg::F_DIVZERO]   = flt[flux_pkg::F_DIVZERO] | ff[flux_pkg::FF_DZ];
  end

  assign wb_fire  = any;
  assign wb_fu    = u.fu;
  assign wb_lanes = 8'($countones(wm));

  assign vrf_we    = any && u.wr_vd && (wm != '0);
  assign vrf_wa    = u.ins.vd;
  assign vrf_wmask = wm;
  assign vrf_wd    = fu_rsp_data[gidx];
  assign vrf_wq    = wq;
  assign meta_we   = any && u.wr_vd && (wm != '0);
  assign vm_we     = any && u.wr_vm;
  assign vm_wd     = fu_rsp_vm[gidx];

  always_comb begin
    meta_wd.valid  = 1'b1;
    meta_wd.prec   = (u.ins.opcode == flux_pkg::OP_VCLASS) ? flux_pkg::PREC_INT : u.ins.prec;
    meta_wd.scale  = (u.ins.prec == flux_pkg::PREC_SFIX || u.ins.prec == flux_pkg::PREC_UFIX)
                     ? ((u.fu == flux_pkg::FU_LSU) ? mem_scale[u.ins.func[2:0]*6 +: 6] : u.ins.imm[5:0]) : 6'd0;
    meta_wd.source = (u.fu == flux_pkg::FU_LSU) ? {5'b10000, u.ins.func[2:0]} : u.ins.opcode;
    meta_wd.tstamp = tstamp;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      clr_valid <= 1'b0;
    end else begin
      clr_valid <= any;
      clr_vd    <= u.ins.vd;
      clr_wr_vd <= u.wr_vd;
      clr_wr_vm <= u.wr_vm;
      clr_fu    <= u.fu;
    end
  end

  // ---- completion queue --------------------------------------------------------------------
  logic [DEPTH-1:0]               e_done;
  logic [DEPTH-1:0][15:0]         e_pc;
  logic [DEPTH-1:0][flux_pkg::FAULT_W-1:0]  e_flt;
  logic [DEPTH-1:0][4:0]          e_ff;
  logic [flux_pkg::TAG_W-1:0]               head_q, tail_q;
  logic [flux_pkg::TAG_W:0]                 count_q;
  logic                           retire;

  assign full      = (count_q == (flux_pkg::TAG_W+1)'(DEPTH));
  assign empty     = (count_q == '0);
  assign alloc_tag = tail_q;
  assign retire    = !empty && e_done[head_q];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      head_q  <= '0;
      tail_q  <= '0;
      count_q <= '0;
      e_done  <= '0;
    end else begin
      if (alloc) begin
        e_done[tail_q] <= alloc_done;
        e_pc[tail_q]   <= alloc_pc;
        e_flt[tail_q]  <= alloc_faults;
        e_ff[tail_q]   <= '0;
        tail_q         <= tail_q + 1'b1;
      end
      if (any) begin
        e_done[u.tag] <= 1'b1;
        e_flt[u.tag]  <= flt;
        e_ff[u.tag]   <= ff;
      end
      if (retire) head_q <= head_q + 1'b1;
      case ({alloc, retire})
        2'b10:   count_q <= count_q + 1'b1;
        2'b01:   count_q <= count_q - 1'b1;
        default: ;
      endcase
    end
  end

  assign retire_valid  = retire;
  assign retire_pc     = e_pc[head_q];
  assign retire_faults = e_flt[head_q];
  assign retire_fflags = e_ff[head_q];

`ifdef SF_SVA
  a_no_overflow:  assert property (@(posedge clk) disable iff (!rst_n) alloc |-> !full);
  a_complete_live: assert property (@(posedge clk) disable iff (!rst_n) any |-> !e_done[u.tag]);
`endif
endmodule
