// =============================================================================
// Silica Flux -- compute core
// -----------------------------------------------------------------------------
//   FETCH -> DECODE QUEUE -> ISSUE (scheduler) -> REGISTER READ (dispatch)
//         -> EXECUTE (14 functional units) -> WRITE-BACK -> RETIRE
//
//   * instruction memory: IMEM_DEPTH x (64 + parity), written by the host
//   * 8 scalar address / loop registers A0..A7 (SETA, ADDA, BNZ)
//   * control instructions (NOP, SETA, ADDA, BNZ, BARRIER, HALT) execute in
//     the issue stage; BNZ redirects fetch (2-cycle bubble, no speculation)
//   * independent instructions overlap freely across functional units; the
//     scoreboard enforces RAW/WAW; results write back out of order, faults
//     retire in order
//   * deterministic: no caches, no speculation, fixed arbitration
// =============================================================================
`include "flux_fu_if.svh"
module flux_core #(
  parameter int LANES      = 8,
  parameter int FP_MODE    = 0,
  parameter int LATENCY    = 4,
  parameter int DIV_BPC    = 1,
  parameter int IMEM_DEPTH = 1024,
  parameter int EXP_W      = (FP_MODE != 0) ? 11 : 8,
  parameter int MAN_W      = (FP_MODE != 0) ? 52 : 23,
  parameter int W          = EXP_W + MAN_W + 1
) (
  input  logic                              clk,
  input  logic                              rst_n,
  // ---- control / status
  input  logic                              start,
  input  logic [15:0]                       start_pc,
  input  logic                              halt_req,        // fault manager / host abort
  input  logic [2:0]                        frm,
  output logic                              running,
  output logic                              done,
  output logic                              halted_fault,
  output logic [15:0]                       pc_out,
  input  logic [31:0]                       tstamp,
  // ---- instruction memory host port
  input  logic                              imem_we,
  input  logic [$clog2(IMEM_DEPTH)-1:0]     imem_waddr,
  input  logic [63:0]                       imem_wdata,
  input  logic                              imem_inj_parity,  // fault injection
  // ---- memory bus master
  output logic                              mem_req_valid,
  input  logic                              mem_req_ready,
  output logic                              mem_req_we,
  output logic [2:0]                        mem_req_id,
  output logic [15:0]                       mem_req_row,
  output logic [LANES-1:0]                  mem_req_wmask,
  output logic [LANES*(W+flux_pkg::QW)-1:0] mem_req_wdata,
  input  logic                              mem_rsp_valid,
  input  logic [LANES*(W+flux_pkg::QW)-1:0] mem_rsp_rdata,
  input  logic                              mem_rsp_err_addr,
  input  logic [LANES-1:0]                  mem_rsp_err_parity,
  input  logic [3*flux_pkg::NUM_MEMS-1:0]   mem_prec,
  input  logic [6*flux_pkg::NUM_MEMS-1:0]   mem_scale,
  // ---- barrier sources / sinks
  input  logic                              telem_frame_pending,
  output logic                              telem_frame_ack,
  input  logic                              dma_busy,
  output logic                              state_swap,
  // ---- engine configuration (CSRs)
  input  logic [W-1:0]                      res_rtol,
  input  logic [W-1:0]                      cons_atol,
  input  logic [W-1:0]                      cons_rtol,
  input  logic [2:0]                        ts_custom_stages,
  input  logic [6*W-1:0]                    ts_custom_a,
  input  logic [4*W-1:0]                    ts_custom_b,
  input  logic [2:0]                        sw_dims,
  input  logic [4*W-1:0]                    sw_lo,
  input  logic [4*W-1:0]                    sw_step,
  input  logic [4*32-1:0]                   sw_count,
  input  logic [2:0]                        ls_dims,
  input  logic [4*W-1:0]                    ls_lo,
  input  logic [4*W-1:0]                    ls_hi,
  input  logic [4*W-1:0]                    ls_center0,
  input  logic [4*W-1:0]                    ls_step0,
  input  logic [4*W-1:0]                    ls_min_step,
  input  logic [15:0]                       ls_max_iter,
  // ---- engine status
  output logic [W-1:0]                      ts_t,
  output logic [W-1:0]                      ts_dt,
  output logic [31:0]                       ts_step,
  output logic                              ts_valid,
  output logic [31:0]                       st_updates,
  output logic [31:0]                       res_viol_count,
  output logic [W-1:0]                      cons_last_resid,
  output logic [W-1:0]                      cons_ref,
  output logic [31:0]                       cons_viol_count,
  output logic [31:0]                       con_pass,
  output logic [31:0]                       con_fail,
  output logic [LANES-1:0]                  con_last_mask,
  output logic [31:0]                       sw_base,
  output logic [31:0]                       sw_total,
  output logic                              sw_done,
  output logic                              sw_ok,
  output logic [W-1:0]                      sr_best,
  output logic [31:0]                       sr_best_idx,
  output logic [4*W-1:0]                    ls_center,
  output logic [4*W-1:0]                    ls_step,
  output logic [15:0]                       ls_iter,
  output logic                              ls_conv,
  // ---- events
  output logic                              fault_valid,
  output logic [flux_pkg::FAULT_W-1:0]      fault_bits,
  output logic [15:0]                       fault_pc,
  output logic [4:0]                        fflags_event,
  output logic                              progress,
  // ---- performance
  output logic [31:0]                       perf_retired,
  output logic [31:0]                       perf_stall,
  output logic [31:0]                       perf_lane_ops,
  output logic [31:0]                       perf_issued,
  output logic [31:0]                       perf_loads,
  output logic [31:0]                       perf_stores,
  output logic [flux_pkg::NUM_FU-1:0][31:0] perf_fu_busy
);
  localparam int IAW = $clog2(IMEM_DEPTH);

  // ===========================================================================
  // run control
  // ===========================================================================
  typedef enum logic [1:0] {R_IDLE, R_RUN, R_DONE, R_FAULT} run_t;
  run_t run_q;
  assign running      = (run_q == R_RUN);
  assign done         = (run_q == R_DONE) || (run_q == R_FAULT);
  assign halted_fault = (run_q == R_FAULT);

  // ===========================================================================
  // instruction memory (64-bit word + even parity)
  // ===========================================================================
  logic [64:0] imem [IMEM_DEPTH];
  logic [64:0] imem_q;
  logic        inj_arm;
`ifndef SYNTHESIS
  initial for (int i = 0; i < IMEM_DEPTH; i++) imem[i] = '0;
`endif
  always_ff @(posedge clk) begin
    if (!rst_n) inj_arm <= 1'b0;
    else if (imem_inj_parity) inj_arm <= 1'b1;
    else if (imem_we) inj_arm <= 1'b0;
  end
  always_ff @(posedge clk) begin
    if (imem_we) imem[imem_waddr] <= {(^imem_wdata) ^ inj_arm, imem_wdata};
  end

  // ===========================================================================
  // fetch + decode queue (2 entries)
  // ===========================================================================
  logic [15:0] pc_q;
  logic        redirect;
  logic [15:0] redirect_pc;
  logic        inflight_q;
  logic [15:0] inflight_pc_q;
  logic [1:0]  dq_count;
  logic [1:0][64:0] dq_word;
  logic [1:0][15:0] dq_pc;
  logic        dq_pop, dq_push, can_fetch;

  assign can_fetch = running && !halt_req && !redirect && (32'(dq_count) + 32'(inflight_q) < 2);
  always_ff @(posedge clk) begin
    if (can_fetch) imem_q <= imem[pc_q[IAW-1:0]];
  end
  assign dq_push = inflight_q && !redirect;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      pc_q       <= '0;
      inflight_q <= 1'b0;
      dq_count   <= '0;
    end else if (start && !running) begin
      pc_q       <= start_pc;
      inflight_q <= 1'b0;
      dq_count   <= '0;
    end else if (redirect) begin
      pc_q       <= redirect_pc;
      inflight_q <= 1'b0;
      dq_count   <= '0;
    end else begin
      inflight_q <= can_fetch;
      if (can_fetch) begin
        inflight_pc_q <= pc_q;
        pc_q          <= pc_q + 16'd1;
      end
      // queue: pop from slot 0, push behind
      case ({dq_push, dq_pop})
        2'b10: begin
          dq_word[dq_count[0]] <= imem_q;
          dq_pc[dq_count[0]]   <= inflight_pc_q;
          dq_count             <= dq_count + 2'd1;
        end
        2'b01: begin
          dq_word[0] <= dq_word[1];
          dq_pc[0]   <= dq_pc[1];
          dq_count   <= dq_count - 2'd1;
        end
        2'b11: begin
          if (dq_count == 2'd1) begin
            dq_word[0] <= imem_q;
            dq_pc[0]   <= inflight_pc_q;
          end else begin
            dq_word[0] <= dq_word[1];
            dq_pc[0]   <= dq_pc[1];
            dq_word[1] <= imem_q;
            dq_pc[1]   <= inflight_pc_q;
          end
        end
        default: ;
      endcase
    end
  end

  logic     head_valid;
  flux_pkg::instr_t   head;
  logic     head_parity_err;
  logic [15:0] head_pc;
  assign head_valid      = (dq_count != '0) && running;
  assign head            = dq_word[0][63:0];
  assign head_parity_err = ^dq_word[0];
  assign head_pc         = dq_pc[0];

  // ===========================================================================
  // scalar address registers
  // ===========================================================================
  logic [7:0][19:0] areg;
  logic [19:0]      ea;
  assign ea = areg[head.vs2[2:0]] + 20'(head.imm);

  // ===========================================================================
  // scheduler
  // ===========================================================================
  logic [31:0][flux_pkg::META_W-1:0] meta;              // meta_t per register
  logic                 rob_full, rob_empty, rr_ready, rr_busy;
  logic                 can_issue, is_ctrl, fault_only, stall_hazard;
  logic [flux_pkg::FAULT_W-1:0]   issue_faults;
  logic [2:0]           rm_eff;
  logic                 clr_valid, clr_wr_vd, clr_wr_vm;
  logic [4:0]           clr_vd;
  logic [3:0]           clr_fu;
  logic [flux_pkg::NUM_FU-1:0][7:0] inflight;
  logic                 issue_fire;

  flux_scheduler #(.LANES(LANES), .FP_MODE(FP_MODE)) u_sched (
    .clk(clk), .rst_n(rst_n), .head_valid(head_valid && !halt_req), .head(head), .ext_fault(head_parity_err),
    .meta(meta), .frm(frm), .mem_prec(mem_prec), .mem_scale(mem_scale),
    .rob_full(rob_full), .rr_ready(rr_ready),
    .clr_valid(clr_valid), .clr_vd(clr_vd), .clr_wr_vd(clr_wr_vd), .clr_wr_vm(clr_wr_vm), .clr_fu(clr_fu),
    .issue_fire(issue_fire), .can_issue(can_issue), .is_ctrl(is_ctrl), .fault_only(fault_only),
    .issue_faults(issue_faults), .rm_eff(rm_eff), .stall_hazard(stall_hazard), .inflight(inflight));

  logic [flux_pkg::FAULT_W-1:0] faults_eff;
  logic               fault_only_eff;
  assign faults_eff     = issue_faults;
  assign fault_only_eff = fault_only;

  logic       fdrain_q;
  logic [1:0] fdrain_tail_q;

  // ---- control instructions ----------------------------------------------------------
  logic ctrl_exec, ctrl_ok, bnz_taken;
  always_comb begin
    ctrl_ok   = 1'b0;
    bnz_taken = 1'b0;
    if (head_valid && !halt_req && is_ctrl && !fault_only && !fdrain_q) begin
      case (head.opcode)
        flux_pkg::OP_HALT:    ctrl_ok = rob_empty && !rr_busy;
        flux_pkg::OP_BARRIER: ctrl_ok = rob_empty && !rr_busy &&
                              (!head.func[0] || telem_frame_pending) && (!head.func[1] || !dma_busy);
        flux_pkg::OP_BNZ: begin
          ctrl_ok   = 1'b1;
          bnz_taken = (areg[head.vs1[2:0]] != '0);
        end
        default:    ctrl_ok = 1'b1;
      endcase
    end
  end
  assign ctrl_exec   = ctrl_ok;
  assign redirect    = ctrl_exec && bnz_taken;
  assign redirect_pc = head_pc + 16'(signed'(head.imm[15:0]));
  // issue-time faults serialise the pipeline: nothing younger issues until the
  // faulting entry has retired and the fault manager has had time to assert
  // halt_req -- issue-time faults are therefore precise
  assign issue_fire  = can_issue && !halt_req && !fdrain_q;
  always_ff @(posedge clk) begin
    if (!rst_n || (start && !running)) begin
      fdrain_q      <= 1'b0;
      fdrain_tail_q <= '0;
    end else if (issue_fire && fault_only_eff) begin
      fdrain_q      <= 1'b1;
      fdrain_tail_q <= 2'd2;
    end else if (fdrain_q && rob_empty) begin
      if (fdrain_tail_q == 2'd0) fdrain_q <= 1'b0;
      else                       fdrain_tail_q <= fdrain_tail_q - 2'd1;
    end
  end
  assign dq_pop      = (issue_fire || ctrl_exec) && !redirect;
  assign state_swap      = ctrl_exec && head.opcode == flux_pkg::OP_BARRIER && head.func[2];
  assign telem_frame_ack = ctrl_exec && head.opcode == flux_pkg::OP_BARRIER && head.func[0];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      areg <= '0;
    end else if (ctrl_exec) begin
      case (head.opcode)
        flux_pkg::OP_SETA: areg[head.vd[2:0]] <= 20'(head.imm);
        flux_pkg::OP_ADDA: areg[head.vd[2:0]] <= areg[head.vd[2:0]] + {{1{head.imm[18]}}, head.imm};
        flux_pkg::OP_BNZ:  if (bnz_taken) areg[head.vs1[2:0]] <= areg[head.vs1[2:0]] - 20'd1;
        default: ;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      run_q <= R_IDLE;
    end else begin
      case (run_q)
        R_IDLE, R_DONE, R_FAULT: if (start) run_q <= R_RUN;
        R_RUN: begin
          if (halt_req && rob_empty && !rr_busy)                 run_q <= R_FAULT;
          else if (ctrl_exec && head.opcode == flux_pkg::OP_HALT)          run_q <= R_DONE;
        end
        default: run_q <= R_IDLE;
      endcase
    end
  end
  assign pc_out = head_valid ? head_pc : pc_q;

  // ---- micro-op formation ----------------------------------------------------------------
  flux_pkg::uop_t           iss_uop;
  logic [flux_pkg::TAG_W-1:0] alloc_tag;
  always_comb begin
    iss_uop.ins   = head;
    if (flux_pkg::fu_of(head.opcode) == flux_pkg::FU_LSU) iss_uop.ins.imm = ea[18:0];
    iss_uop.pc    = head_pc;
    iss_uop.tag   = alloc_tag;
    iss_uop.fu    = flux_pkg::fu_of(head.opcode);
    iss_uop.rm    = rm_eff;
    iss_uop.wr_vd = flux_pkg::writes_vd(head);
    iss_uop.wr_vm = flux_pkg::writes_vm(head);
  end

  // ===========================================================================
  // register file
  // ===========================================================================
  logic [LANES*W-1:0]  d_a, d_b, d_c;
  logic [LANES*flux_pkg::QW-1:0] d_qa, d_qb, d_qc;
  logic [LANES-1:0]    vrf_vm, vm_cur, d_lmask, d_vm;
  logic                vrf_we, meta_we, vm_we;
  logic [4:0]          vrf_wa;
  logic [LANES-1:0]    vrf_wmask, vm_wd;
  logic [LANES*W-1:0]  vrf_wd;
  logic [LANES*flux_pkg::QW-1:0] vrf_wq;
  flux_pkg::meta_t               meta_wd;
  vector_register_file #(.LANES(LANES), .W(W)) u_vrf (
    .clk(clk), .rst_n(rst_n), .job_init(start && !running),
    .re(issue_fire && !fault_only_eff), .ra1(head.vs1), .ra2(head.vs2), .ra3(head.vs3),
    .rd1(d_a), .rd2(d_b), .rd3(d_c), .rq1(d_qa), .rq2(d_qb), .rq3(d_qc), .rvm(vrf_vm),
    .we(vrf_we), .wa(vrf_wa), .wmask(vrf_wmask), .wd(vrf_wd), .wq(vrf_wq),
    .meta_we(meta_we), .meta_wd(meta_wd), .vm_we(vm_we), .vm_wmask(vrf_wmask), .vm_wd(vm_wd),
    .meta(meta), .vm(vm_cur));

  // ===========================================================================
  // dispatch
  // ===========================================================================
  logic [flux_pkg::NUM_FU-1:0] fu_req_valid, fu_req_ready;
  flux_pkg::uop_t              d_uop;
  flux_dispatch #(.LANES(LANES)) u_disp (
    .clk(clk), .rst_n(rst_n), .in_valid(issue_fire && !fault_only_eff), .in_uop(iss_uop),
    .rr_ready(rr_ready), .vrf_vm(vrf_vm), .fu_req_valid(fu_req_valid), .fu_req_ready(fu_req_ready),
    .d_uop(d_uop), .d_lmask(d_lmask), .d_vm(d_vm), .busy(rr_busy));

  // ===========================================================================
  // functional units
  // ===========================================================================
  logic [flux_pkg::NUM_FU-1:0]                fu_rsp_valid, fu_rsp_ready;
  logic [flux_pkg::NUM_FU-1:0][flux_pkg::UOP_W-1:0]    fu_rsp_uop;   // uop_t per unit
  logic [flux_pkg::NUM_FU-1:0][LANES*W-1:0]   fu_rsp_data;
  logic [flux_pkg::NUM_FU-1:0][LANES*flux_pkg::QW-1:0]  fu_rsp_qual;
  logic [flux_pkg::NUM_FU-1:0][LANES-1:0]     fu_rsp_wmask, fu_rsp_vm;
  logic [flux_pkg::NUM_FU-1:0][4:0]           fu_rsp_fflags;
  logic [flux_pkg::NUM_FU-1:0][flux_pkg::FAULT_W-1:0]   fu_rsp_faults;

  // FU_CTRL has no execution unit
  assign fu_req_ready[flux_pkg::FU_CTRL]  = 1'b1;
  assign fu_rsp_valid[flux_pkg::FU_CTRL]  = 1'b0;
  assign fu_rsp_uop[flux_pkg::FU_CTRL]    = '0;
  assign fu_rsp_data[flux_pkg::FU_CTRL]   = '0;
  assign fu_rsp_qual[flux_pkg::FU_CTRL]   = '0;
  assign fu_rsp_wmask[flux_pkg::FU_CTRL]  = '0;
  assign fu_rsp_vm[flux_pkg::FU_CTRL]     = '0;
  assign fu_rsp_fflags[flux_pkg::FU_CTRL] = '0;
  assign fu_rsp_faults[flux_pkg::FU_CTRL] = '0;

  vector_pipeline #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY), .DIV_BPC(DIV_BPC)) u_vp (
    .clk(clk), .rst_n(rst_n),
    .req_valid(fu_req_valid[flux_pkg::FU_SFU:flux_pkg::FU_VALU]), .req_ready(fu_req_ready[flux_pkg::FU_SFU:flux_pkg::FU_VALU]), .req_uop(d_uop),
    .req_a(d_a), .req_b(d_b), .req_c(d_c), .req_qa(d_qa), .req_qb(d_qb), .req_qc(d_qc),
    .req_lmask(d_lmask), .req_vm(d_vm),
    .rsp_valid(fu_rsp_valid[flux_pkg::FU_SFU:flux_pkg::FU_VALU]), .rsp_ready(fu_rsp_ready[flux_pkg::FU_SFU:flux_pkg::FU_VALU]),
    .rsp_uop(fu_rsp_uop[flux_pkg::FU_SFU:flux_pkg::FU_VALU]), .rsp_data(fu_rsp_data[flux_pkg::FU_SFU:flux_pkg::FU_VALU]),
    .rsp_qual(fu_rsp_qual[flux_pkg::FU_SFU:flux_pkg::FU_VALU]), .rsp_wmask(fu_rsp_wmask[flux_pkg::FU_SFU:flux_pkg::FU_VALU]),
    .rsp_vm(fu_rsp_vm[flux_pkg::FU_SFU:flux_pkg::FU_VALU]), .rsp_fflags(fu_rsp_fflags[flux_pkg::FU_SFU:flux_pkg::FU_VALU]),
    .rsp_faults(fu_rsp_faults[flux_pkg::FU_SFU:flux_pkg::FU_VALU]));

  flux_lsu #(.LANES(LANES), .W(W)) u_lsu (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_LSU),
    .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_we(mem_req_we),
    .mem_req_id(mem_req_id), .mem_req_row(mem_req_row), .mem_req_wmask(mem_req_wmask),
    .mem_req_wdata(mem_req_wdata), .mem_rsp_valid(mem_rsp_valid), .mem_rsp_rdata(mem_rsp_rdata),
    .mem_rsp_err_addr(mem_rsp_err_addr), .mem_rsp_err_parity(mem_rsp_err_parity),
    .loads(perf_loads), .stores(perf_stores));

  reduction_unit #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_red (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_RED));
  polynomial_unit #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_poly (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_POLY));
  interpolation_unit #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_interp (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_INTERP));
  state_update #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_state (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_STATE),
    .custom_stages(ts_custom_stages), .custom_a(ts_custom_a), .custom_b(ts_custom_b),
    .t_now(ts_t), .dt_now(ts_dt), .step_count(ts_step), .ts_valid(ts_valid), .state_updates(st_updates));
  residual_engine #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_resid (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_RESID), .cfg_rtol(res_rtol), .viol_count(res_viol_count));
  conservation_checker #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_cons (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_CONS), .cfg_atol(cons_atol), .cfg_rtol(cons_rtol),
    .last_residual(cons_last_resid), .ref_value(cons_ref), .viol_count(cons_viol_count));
  objective_eval #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_obj (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_OBJ));
  constraint_eval #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_con (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_CON),
    .pass_count(con_pass), .fail_count(con_fail), .last_pass(con_last_mask));
  parameter_sweep #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_sweep (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_SWEEP),
    .cfg_dims(sw_dims), .cfg_lo(sw_lo), .cfg_step(sw_step), .cfg_count(sw_count),
    .base(sw_base), .total(sw_total), .done(sw_done), .cfg_ok(sw_ok));
  search_engine #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_search (
    .clk(clk), .rst_n(rst_n), `SF_FU_CONNECT(flux_pkg::FU_SEARCH),
    .cfg_dims(ls_dims), .cfg_lo(ls_lo), .cfg_hi(ls_hi), .cfg_center0(ls_center0), .cfg_step0(ls_step0),
    .cfg_min_step(ls_min_step), .cfg_max_iter(ls_max_iter), .sweep_base(sw_base),
    .best(sr_best), .best_index(sr_best_idx), .center(ls_center), .step(ls_step),
    .iter(ls_iter), .converged(ls_conv));

  // ===========================================================================
  // write-back / retirement
  // ===========================================================================
  logic               retire_valid;
  logic [15:0]        retire_pc;
  logic [flux_pkg::FAULT_W-1:0] retire_faults;
  logic [4:0]         retire_fflags;
  logic               wb_fire;
  logic [3:0]         wb_fu;
  logic [7:0]         wb_lanes;
  flux_retirement #(.LANES(LANES), .W(W)) u_ret (
    .clk(clk), .rst_n(rst_n), .tstamp(tstamp),
    .fu_rsp_valid(fu_rsp_valid), .fu_rsp_ready(fu_rsp_ready), .fu_rsp_uop(fu_rsp_uop),
    .fu_rsp_data(fu_rsp_data), .fu_rsp_qual(fu_rsp_qual), .fu_rsp_wmask(fu_rsp_wmask),
    .fu_rsp_vm(fu_rsp_vm), .fu_rsp_fflags(fu_rsp_fflags), .fu_rsp_faults(fu_rsp_faults),
    .mem_scale(mem_scale),
    .vrf_we(vrf_we), .vrf_wa(vrf_wa), .vrf_wmask(vrf_wmask), .vrf_wd(vrf_wd), .vrf_wq(vrf_wq),
    .meta_we(meta_we), .meta_wd(meta_wd), .vm_we(vm_we), .vm_wd(vm_wd),
    .clr_valid(clr_valid), .clr_vd(clr_vd), .clr_wr_vd(clr_wr_vd), .clr_wr_vm(clr_wr_vm), .clr_fu(clr_fu),
    .alloc(issue_fire), .alloc_pc(head_pc), .alloc_done(fault_only_eff), .alloc_faults(faults_eff),
    .alloc_tag(alloc_tag), .full(rob_full), .empty(rob_empty),
    .retire_valid(retire_valid), .retire_pc(retire_pc), .retire_faults(retire_faults),
    .retire_fflags(retire_fflags), .wb_fire(wb_fire), .wb_fu(wb_fu), .wb_lanes(wb_lanes));

  assign fault_valid  = retire_valid && (retire_faults != '0);
  assign fault_bits   = retire_faults;
  assign fault_pc     = retire_pc;
  assign fflags_event = retire_valid ? retire_fflags : 5'b0;
  assign progress     = issue_fire || ctrl_exec || retire_valid || !running;

  // ===========================================================================
  // performance counters
  // ===========================================================================
  logic [31:0] ret_q, stall_q, lops_q, iss_q;
  logic [flux_pkg::NUM_FU-1:0][31:0] busy_q;
  always_ff @(posedge clk) begin
    if (!rst_n || (start && !running)) begin
      ret_q <= '0; stall_q <= '0; lops_q <= '0; iss_q <= '0; busy_q <= '0;
    end else begin
      ret_q <= ret_q + 32'(retire_valid) + 32'(ctrl_exec);
      iss_q <= iss_q + 32'(issue_fire);
      if (running && head_valid && !issue_fire && !ctrl_exec) stall_q <= stall_q + 32'd1;
      if (wb_fire && wb_fu != flux_pkg::FU_LSU && wb_fu != flux_pkg::FU_CTRL) lops_q <= lops_q + 32'(wb_lanes);
      for (int f = 0; f < flux_pkg::NUM_FU; f++) if (inflight[f] != '0) busy_q[f] <= busy_q[f] + 32'd1;
    end
  end
  assign perf_retired  = ret_q;
  assign perf_stall    = stall_q;
  assign perf_lane_ops = lops_q;
  assign perf_issued   = iss_q;
  assign perf_fu_busy  = busy_q;
endmodule
