// =============================================================================
// Silica Flux -- telemetry ingest and validation
// -----------------------------------------------------------------------------
// Packet (three 64-bit beats, TLAST on the third):
//   beat 0  [63:32] timestamp  [31:16] sequence  [15:8] channel  [7:0] quality
//                  quality bit 0 = sensor-invalid, bit 7 = frame end
//   beat 1  value (FP, low W bits)
//   beat 2  [15:0] CRC-16/CCITT-FALSE over the 16 bytes of beats 0-1
//           (little-endian byte order), [63:16] reserved zero
// Checks, in order:   framing (TLAST position)        -> F_TL_MALFORMED, drop
//                     CRC                              -> F_TL_CRC, drop
//                     channel < N_CHAN                 -> F_TL_MALFORMED, drop
//                     sequence: gap -> dropped += gap, F_TL_SEQ, keep
//                               duplicate / reorder    -> F_TL_SEQ, drop
//                     timestamp discontinuity          -> F_TL_TS, Q_SUSPECT
//                     range [lo_c, hi_c] / NaN         -> F_RANGE, Q_SUSPECT(|Q_NAN)
//                     sensor-invalid flag              -> Q_SUSPECT
// Accepted samples go to the telemetry buffer with their quality bits; a bad
// sample therefore taints every computation that consumes it.
// =============================================================================
module telemetry_ingest #(
  parameter int EXP_W  = 8,
  parameter int MAN_W  = 23,
  parameter int N_CHAN = 32,
  parameter int W      = EXP_W + MAN_W + 1
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          s_valid,
  output logic          s_ready,
  input  logic [63:0]   s_data,
  input  logic          s_last,
  // configuration
  input  logic          reset_track,
  input  logic          bound_we,
  input  logic [7:0]    bound_chan,
  input  logic [W-1:0]  bound_lo,
  input  logic [W-1:0]  bound_hi,
  // timestamp checking (timestamp_engine)
  output logic          ts_chk_valid,
  output logic [31:0]   ts_chk_ts,
  input  logic          ts_disc,
  // accepted packet
  output logic          pkt_valid,
  output logic [7:0]    pkt_chan,
  output logic [W-1:0]  pkt_value,
  output logic [flux_pkg::QW-1:0] pkt_qual,
  output logic          pkt_frame_end,
  // events / counters
  output logic [flux_pkg::FAULT_W-1:0] fault_event,
  output logic [31:0]   cnt_rx,
  output logic [31:0]   cnt_accepted,
  output logic [31:0]   cnt_dropped,
  output logic [31:0]   cnt_crc,
  output logic [31:0]   cnt_seq,
  output logic [31:0]   cnt_ts,
  output logic [31:0]   cnt_range,
  output logic [31:0]   cnt_malformed
);
  localparam int CW = (N_CHAN > 1) ? $clog2(N_CHAN) : 1;

  function automatic logic [15:0] crc16_byte(input logic [15:0] c, input logic [7:0] b);
    logic [15:0] r;
    r = c ^ {b, 8'h00};
    for (int i = 0; i < 8; i++) r = r[15] ? ((r << 1) ^ 16'h1021) : (r << 1);
    crc16_byte = r;
  endfunction
  function automatic logic [15:0] crc16_beat(input logic [15:0] c, input logic [63:0] d);
    logic [15:0] r;
    r = c;
    for (int k = 0; k < 8; k++) r = crc16_byte(r, d[k*8 +: 8]);
    crc16_beat = r;
  endfunction

  // per-channel bounds (default: +-Inf, i.e. unbounded)
  localparam logic [W-1:0] PINF = {1'b0, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
  localparam logic [W-1:0] NINF = {1'b1, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
  logic [N_CHAN-1:0][W-1:0] lo_q, hi_q;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int c = 0; c < N_CHAN; c++) begin lo_q[c] <= NINF; hi_q[c] <= PINF; end
    end else if (bound_we && int'(bound_chan) < N_CHAN) begin
      lo_q[bound_chan[CW-1:0]] <= bound_lo;
      hi_q[bound_chan[CW-1:0]] <= bound_hi;
    end
  end

  typedef enum logic [1:0] {B0, B1, B2, RESYNC} beat_t;
  beat_t       st;
  logic [63:0] hdr_q, val_q;
  logic [15:0] crc_q;
  logic        seq_init_q;
  logic [15:0] seq_exp_q;
  assign s_ready = 1'b1;

  // ---- packet evaluation on the third beat ------------------------------------------
  logic        fire3, crc_ok, chan_ok, seq_gap, seq_dup, accept;
  logic [15:0] seq, seq_diff, crc_calc;
  logic [7:0]  chan;
  logic [W-1:0] value;
  logic        in_rng, v_nan;
  assign fire3    = s_valid && (st == B2);
  assign seq      = hdr_q[31:16];
  assign chan     = hdr_q[15:8];
  assign value    = val_q[W-1:0];
  assign crc_calc = crc16_beat(crc_q, val_q);
  assign crc_ok   = (crc_calc == s_data[15:0]);
  assign chan_ok  = (int'(chan) < N_CHAN);
  assign seq_diff = seq - seq_exp_q;
  assign seq_gap  = seq_init_q && (seq_diff != 16'd0) && !seq_diff[15];
  assign seq_dup  = seq_init_q && seq_diff[15];
  assign accept   = fire3 && s_last && crc_ok && chan_ok && !seq_dup;
  range_checker #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_rng (
    .x(value), .lo(lo_q[chan[CW-1:0]]), .hi(hi_q[chan[CW-1:0]]), .in_range(in_rng), .is_nan(v_nan));

  assign ts_chk_valid = accept;
  assign ts_chk_ts    = hdr_q[63:32];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= B0;
      cnt_rx <= '0; cnt_accepted <= '0; cnt_dropped <= '0; cnt_crc <= '0;
      cnt_seq <= '0; cnt_ts <= '0; cnt_range <= '0; cnt_malformed <= '0;
      seq_init_q <= 1'b0;
      seq_exp_q  <= '0;
      pkt_valid  <= 1'b0;
      fault_event <= '0;
    end else begin
      pkt_valid   <= 1'b0;
      fault_event <= '0;
      if (reset_track) seq_init_q <= 1'b0;
      if (s_valid) begin
        case (st)
          B0: begin
            hdr_q <= s_data;
            crc_q <= crc16_beat(16'hFFFF, s_data);
            if (s_last) begin
              cnt_malformed <= cnt_malformed + 32'd1;
              fault_event[flux_pkg::F_TL_MALFORMED] <= 1'b1;
            end else st <= B1;
          end
          B1: begin
            val_q <= s_data;
            if (s_last) begin
              cnt_malformed <= cnt_malformed + 32'd1;
              fault_event[flux_pkg::F_TL_MALFORMED] <= 1'b1;
              st <= B0;
            end else st <= B2;
          end
          B2: begin
            cnt_rx <= cnt_rx + 32'd1;
            st     <= s_last ? B0 : RESYNC;
            if (!s_last || !chan_ok) begin
              cnt_malformed <= cnt_malformed + 32'd1;
              fault_event[flux_pkg::F_TL_MALFORMED] <= 1'b1;
            end else if (!crc_ok) begin
              cnt_crc <= cnt_crc + 32'd1;
              fault_event[flux_pkg::F_TL_CRC] <= 1'b1;
            end else if (seq_dup) begin
              cnt_seq <= cnt_seq + 32'd1;
              fault_event[flux_pkg::F_TL_SEQ] <= 1'b1;
            end else begin
              // accepted
              logic [flux_pkg::QW-1:0] q;
              q = '0;
              if (hdr_q[0]) q[flux_pkg::Q_SUSPECT] = 1'b1;
              if (ts_disc) begin
                q[flux_pkg::Q_SUSPECT] = 1'b1;
                cnt_ts <= cnt_ts + 32'd1;
                fault_event[flux_pkg::F_TL_TS] <= 1'b1;
              end
              if (v_nan || !in_rng) begin
                q[flux_pkg::Q_SUSPECT] = 1'b1;
                if (v_nan) q[flux_pkg::Q_NAN] = 1'b1;
                cnt_range <= cnt_range + 32'd1;
                fault_event[flux_pkg::F_RANGE] <= 1'b1;
              end
              if (seq_gap) begin
                cnt_dropped <= cnt_dropped + 32'(seq_diff);
                cnt_seq     <= cnt_seq + 32'd1;
                fault_event[flux_pkg::F_TL_SEQ] <= 1'b1;
              end
              seq_init_q    <= 1'b1;
              seq_exp_q     <= seq + 16'd1;
              cnt_accepted  <= cnt_accepted + 32'd1;
              pkt_valid     <= 1'b1;
              pkt_chan      <= chan;
              pkt_value     <= value;
              pkt_qual      <= q;
              pkt_frame_end <= hdr_q[7];
            end
          end
          default: if (s_last) st <= B0;   // RESYNC: discard until end of packet
        endcase
      end
    end
  end
endmodule
