// =============================================================================
// Silica Flux -- timestamp engine
// -----------------------------------------------------------------------------
// * fabric time base: 32-bit counter advanced every (PRESCALE+1) clocks; it
//   stamps register metadata, fault records and telemetry arrival.
// * telemetry time checking: each accepted packet timestamp must be strictly
//   greater than the previous one and the increment must not exceed MAX_GAP
//   (0 disables the gap check).  A violation is a timestamp discontinuity:
//   the sample is kept but marked Q_SUSPECT and F_TL_TS is raised.
// =============================================================================
module timestamp_engine (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [15:0] prescale,
  output logic [31:0] tstamp,
  // packet timestamp check
  input  logic        chk_valid,
  input  logic [31:0] chk_ts,
  input  logic [31:0] max_gap,
  input  logic        reset_track,
  output logic        discontinuity,
  output logic [31:0] last_delta
);
  logic [15:0] div_q;
  logic [31:0] last_q;
  logic        init_q;
  logic [31:0] delta;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      div_q  <= '0;
      tstamp <= '0;
    end else if (div_q >= prescale) begin
      div_q  <= '0;
      tstamp <= tstamp + 32'd1;
    end else begin
      div_q <= div_q + 16'd1;
    end
  end
  assign delta         = chk_ts - last_q;
  assign discontinuity = init_q && ((chk_ts <= last_q) || (max_gap != '0 && delta > max_gap));
  always_ff @(posedge clk) begin
    if (!rst_n || reset_track) begin
      init_q     <= 1'b0;
      last_q     <= '0;
      last_delta <= '0;
    end else if (chk_valid) begin
      init_q     <= 1'b1;
      last_q     <= chk_ts;
      last_delta <= init_q ? delta : 32'd0;
    end
  end
endmodule
