// =============================================================================
// Silica Flux -- telemetry buffer
// -----------------------------------------------------------------------------
// * FIFO of validated samples; a push into a full FIFO drops the sample,
//   counts it and raises F_TL_OVF (buffer overflow is never silent).
// * Channel table: the FIFO drains one sample per cycle into a sample-and-hold
//   table (channel c -> row c / LANES, lane c % LANES).  Channels that have
//   never been received read as 0 with Q_SUSPECT.
// * Frame tracking: a sample flagged frame-end completes a frame; the core's
//   BARRIER func=TELEM waits for a pending frame and acknowledges it.
// The table is read by the core (VLOAD from MEM_TELEM) through the internal
// bus; it is read-only from the bus side.
// =============================================================================
module telemetry_buffer #(
  parameter int LANES  = 8,
  parameter int W      = 32,
  parameter int N_CHAN = 32,
  parameter int DEPTH  = 16
) (
  input  logic                          clk,
  input  logic                          rst_n,
  input  logic                          pkt_valid,
  input  logic [7:0]                    pkt_chan,
  input  logic [W-1:0]                  pkt_value,
  input  logic [flux_pkg::QW-1:0]       pkt_qual,
  input  logic                          pkt_frame_end,
  // bus read port
  input  logic                          rd_en,
  input  logic [15:0]                   rd_row,
  output logic [LANES*(W+flux_pkg::QW)-1:0] rd_data,
  // frame handshake
  output logic                          frame_pending,
  input  logic                          frame_ack,
  output logic [31:0]                   frames,
  // status
  output logic                          overflow_event,
  output logic [31:0]                   overflows,
  output logic [$clog2(DEPTH):0]        level
);
  localparam int EW   = W + flux_pkg::QW;
  localparam int ROWS = (N_CHAN + LANES - 1) / LANES;
  localparam int PW   = 1 + 8 + flux_pkg::QW + W;
  localparam int AWD  = (DEPTH > 1) ? $clog2(DEPTH) : 1;

  logic [PW-1:0] f_rd;
  logic          f_empty, f_full, f_ovf, f_unf;
  sf_fifo #(.W(PW), .DEPTH(DEPTH)) u_fifo (
    .clk(clk), .rst_n(rst_n), .push(pkt_valid), .wdata({pkt_frame_end, pkt_chan, pkt_qual, pkt_value}),
    .pop(!f_empty), .rdata(f_rd), .empty(f_empty), .full(f_full), .count(level),
    .overflow(f_ovf), .underflow(f_unf), .clr_flags(1'b0));

  logic [ROWS*LANES-1:0][EW-1:0] table_q;
  logic                          fe;
  logic [7:0]                    ch;
  logic [flux_pkg::QW-1:0]                 q;
  logic [W-1:0]                  v;
  assign {fe, ch, q, v} = f_rd;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int c = 0; c < ROWS * LANES; c++) table_q[c] <= {flux_pkg::QW'(1 << flux_pkg::Q_SUSPECT), {W{1'b0}}};
      frame_pending  <= 1'b0;
      frames         <= '0;
      overflows      <= '0;
      overflow_event <= 1'b0;
    end else begin
      overflow_event <= pkt_valid && f_full;
      if (pkt_valid && f_full) overflows <= overflows + 32'd1;
      if (!f_empty) begin
        if (int'(ch) < ROWS * LANES) table_q[ch] <= {q, v};
        if (fe) begin
          frames        <= frames + 32'd1;
          frame_pending <= 1'b1;
        end
      end
      if (frame_ack && !(!f_empty && fe)) frame_pending <= 1'b0;
    end
  end

  always_ff @(posedge clk) begin
    if (rd_en) begin
      for (int l = 0; l < LANES; l++)
        rd_data[l*EW +: EW] <= (int'(rd_row) < ROWS) ? table_q[int'(rd_row) * LANES + l] : '0;
    end
  end
endmodule
