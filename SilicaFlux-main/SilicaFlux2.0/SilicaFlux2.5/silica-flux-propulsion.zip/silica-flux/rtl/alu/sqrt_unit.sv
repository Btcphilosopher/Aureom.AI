// =============================================================================
// Silica Flux -- correctly rounded floating-point square root
// -----------------------------------------------------------------------------
// Restoring digit-recurrence square root (non-performing variant), generic in
// (EXP_W, MAN_W).  The significand is normalised, the exponent made even, and
// P+2 root bits are developed from a 2P+4-bit radicand, BITS_PER_CYCLE bits per
// clock.  A non-zero final remainder supplies the sticky bit, so the result is
// the correctly rounded square root in every rounding mode (max error 0.5 ULP
// in RNE).  Square roots of finite positive values never overflow or underflow.
//
// Latency (non-special): 2 + ceil((P+2)/BITS_PER_CYCLE) cycles.
// =============================================================================
module sqrt_unit #(
  parameter int EXP_W          = 8,
  parameter int MAN_W          = 23,
  parameter int BITS_PER_CYCLE = 1,
  parameter int TAG_W          = 8
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic [EXP_W+MAN_W:0] a,
  input  logic [2:0]           rm,
  input  logic [TAG_W-1:0]     in_tag,
  output logic                 out_valid,
  input  logic                 out_ready,
  output logic [EXP_W+MAN_W:0] result,
  output logic [4:0]           fflags,
  output logic [TAG_W-1:0]     out_tag,
  output logic                 busy
);
  localparam int W    = EXP_W + MAN_W + 1;
  localparam int P    = MAN_W + 1;
  localparam int EI_W = EXP_W + 4;
  localparam int NCYC = (P + 2 + BITS_PER_CYCLE - 1) / BITS_PER_CYCLE;
  localparam int RB   = NCYC * BITS_PER_CYCLE;     // developed root bits
  localparam int NW   = 2 * RB;                    // radicand bits
  localparam int CW   = $clog2(NCYC + 1);
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};

  typedef enum logic [1:0] {S_IDLE, S_ITER, S_ROUND, S_DONE} state_t;
  state_t state;

  logic sa, za, ia, na, sna, suba, nrma;
  logic signed [EI_W-1:0] ea;
  logic [P-1:0] ma;
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ua (
    .x(a), .sign(sa), .exp(ea), .sig(ma), .is_zero(za), .is_sub(suba),
    .is_inf(ia), .is_nan(na), .is_snan(sna), .is_norm(nrma));

  localparam int LZW = $clog2(P + 1);
  logic [LZW-1:0] lza;
  logic           lza_z;
  sf_lzc #(.W(P)) u_lza (.in(ma), .cnt(lza), .zero(lza_z));

  // radicand set-up --------------------------------------------------------------
  //   x = m * 2^(E-M), m normalised.  If E is odd use 2m and E-1.
  //   root = isqrt(m' << (2*RB - P - 1)) has RB bits, MSB at RB-1,
  //   value = root * 2^(E'/2 - (RB-1)).
  logic [P-1:0]           m_n;
  logic signed [EI_W-1:0] e_n, e_half_d;
  logic [NW-1:0]          rad_d;
  logic                   special_d, nv_d;
  logic [W-1:0]           special_val_d;

  always_comb begin
    m_n = ma << lza;
    e_n = ea - EI_W'(signed'({1'b0, lza}));
    if (e_n[0]) begin
      rad_d    = NW'({m_n, 1'b0}) << (NW - P - 1);
      e_half_d = (e_n - EI_W'(1)) >>> 1;
    end else begin
      rad_d    = NW'(m_n) << (NW - P - 1);
      e_half_d = e_n >>> 1;
    end
    special_d     = 1'b1;
    special_val_d = QNAN;
    nv_d          = 1'b0;
    if (na) begin
      nv_d = sna;
    end else if (za) begin
      special_val_d = a;                 // sqrt(+-0) = +-0
    end else if (sa) begin
      nv_d = 1'b1;                       // negative -> invalid
    end else if (ia) begin
      special_val_d = a;
    end else begin
      special_d = 1'b0;
    end
  end

  // iteration state ----------------------------------------------------------------
  logic [NW-1:0]          rad_q;
  logic [RB+1:0]          rem_q;
  logic [RB-1:0]          root_q;
  logic [CW-1:0]          cnt_q;
  logic signed [EI_W-1:0] exp_q;
  logic [2:0]             rm_q;
  logic [TAG_W-1:0]       tag_q;
  logic [W-1:0]           res_q;
  logic [4:0]             ff_q;

  logic [RB+1:0] rem_s  [BITS_PER_CYCLE+1];
  logic [RB-1:0] root_s [BITS_PER_CYCLE+1];
  logic [RB+1:0] trial;
  always_comb begin
    rem_s[0]  = rem_q;
    root_s[0] = root_q;
    trial     = '0;
    for (int k = 0; k < BITS_PER_CYCLE; k++) begin
      rem_s[k+1] = {rem_s[k][RB-1:0], rad_q[NW-1-2*k -: 2]};
      trial      = {root_s[k], 2'b01};
      if (rem_s[k+1] >= trial) begin
        rem_s[k+1]  = rem_s[k+1] - trial;
        root_s[k+1] = {root_s[k][RB-2:0], 1'b1};
      end else begin
        root_s[k+1] = {root_s[k][RB-2:0], 1'b0};
      end
    end
  end

  logic [W-1:0] r_res;
  logic [4:0]   r_ff;
  fp_round #(.EXP_W(EXP_W), .MAN_W(MAN_W), .SW(RB), .EI_W(EI_W)) u_round (
    .sign(1'b0), .sig(root_q), .exp(exp_q), .sticky_in(rem_q != '0), .tiny(1'b0),
    .rm(rm_q), .result(r_res), .fflags(r_ff));

  assign in_ready  = (state == S_IDLE);
  assign busy      = (state != S_IDLE);
  assign out_valid = (state == S_DONE);
  assign result    = res_q;
  assign fflags    = ff_q;
  assign out_tag   = tag_q;

  always_ff @(posedge clk) begin
    if (!rst_n) state <= S_IDLE;
    else begin
      case (state)
        S_IDLE:  if (in_valid) state <= special_d ? S_DONE : S_ITER;
        S_ITER:  if (cnt_q == CW'(NCYC - 1)) state <= S_ROUND;
        S_ROUND: state <= S_DONE;
        S_DONE:  if (out_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (in_valid) begin
        rad_q  <= rad_d;
        rem_q  <= '0;
        root_q <= '0;
        cnt_q  <= '0;
        exp_q  <= e_half_d;
        rm_q   <= rm;
        tag_q  <= in_tag;
        res_q  <= special_val_d;
        ff_q   <= {nv_d, 4'b0000};
      end
      S_ITER: begin
        rad_q  <= rad_q << (2 * BITS_PER_CYCLE);
        rem_q  <= rem_s[BITS_PER_CYCLE];
        root_q <= root_s[BITS_PER_CYCLE];
        cnt_q  <= cnt_q + CW'(1);
      end
      S_ROUND: begin
        res_q <= r_res;
        ff_q  <= r_ff;
      end
      default: ;
    endcase
  end
endmodule
