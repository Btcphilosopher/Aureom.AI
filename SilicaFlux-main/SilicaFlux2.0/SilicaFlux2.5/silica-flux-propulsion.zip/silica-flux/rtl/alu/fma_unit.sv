// =============================================================================
// Silica Flux -- fused multiply-add unit  (first-class arithmetic primitive)
// -----------------------------------------------------------------------------
// Computes  (-1)^np * a*b + (-1)^na * c  with a single rounding, for any IEEE
// binary format (EXP_W, MAN_W); FP32 and FP64 are verified bit-exactly against
// python/golden_model/ieee.py.  The same datapath provides MUL, ADD and SUB.
//
// Datapath (P = MAN_W+1, frame EF = 3P+6 bits incl. a dedicated sticky bit):
//
//   S1  unpack / classify / special cases / P x P multiply / addend alignment
//       - the product occupies frame bits [2P+2:3] (two guard bits below it);
//       - the addend is shifted relative to the product (shift in parallel with
//         the multiplier).  Bits shifted below the frame are OR-ed into the
//         sticky position (bit 0), which participates in the subtraction, so
//         the rounding decision is exact.
//       - if the addend dominates (product < 1/8 of the addend LSB) or the
//         product is zero, the addend is re-anchored and a non-zero product is
//         represented by a sticky "proxy" -- the classic 3P+6 window technique.
//   S2  signed add / subtract, magnitude, exact-zero detection
//   S3  leading-zero normalisation (with emin floor for subnormal results)
//   S4  rounding (RNE/RTZ/RDN/RUP/RMM), packing, exception flags
//
// LATENCY >= 4.  Stages beyond four are appended as output register slices so
// that synthesis retiming can balance the multiplier on high-frequency targets.
// Every stage is an elastic valid/ready register; there is no global stall.
// =============================================================================
module fma_unit #(
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int TAG_W   = 8
) (
  input  logic                   clk,
  input  logic                   rst_n,
  // request
  input  logic                   in_valid,
  output logic                   in_ready,
  input  logic [2:0]             op,       // flux_pkg::FMA_*
  input  logic [2:0]             rm,
  input  logic [EXP_W+MAN_W:0]   a,
  input  logic [EXP_W+MAN_W:0]   b,
  input  logic [EXP_W+MAN_W:0]   c,
  input  logic [TAG_W-1:0]       in_tag,
  // response
  output logic                   out_valid,
  input  logic                   out_ready,
  output logic [EXP_W+MAN_W:0]   result,
  output logic [4:0]             fflags,   // {NV, DZ, OF, UF, NX}
  output logic [TAG_W-1:0]       out_tag
);
  localparam int W    = EXP_W + MAN_W + 1;
  localparam int P    = MAN_W + 1;
  localparam int EI_W = EXP_W + 4;
  localparam int EF   = 3 * P + 6;
  localparam int SHW  = $clog2(EF + 1) + 1;

  localparam logic [W-1:0] ONE  = {1'b0, 1'b0, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};

  // ===========================================================================
  // S1 : unpack, classify, multiply, align
  // ===========================================================================
  logic             neg_prod, neg_add, mul_only, add_mode;
  logic [W-1:0]     b_eff;
  logic             sa, sb, sc_raw, sp, sc;
  logic signed [EI_W-1:0] ea, eb, ec;
  logic [P-1:0]     ma, mb, mc;
  logic za, zb, zc_raw, suba, subb, subc, ia, ib, ic_raw, na, nb, nc_raw, sna, snb, snc_raw;
  logic nrma, nrmb, nrmc;
  logic             c_zero, c_inf, c_nan, c_snan;

  assign neg_prod = (op == 3'd2) || (op == 3'd3);
  assign neg_add  = (op == 3'd1) || (op == 3'd3) || (op == 3'd6);
  assign mul_only = (op == 3'd4);
  assign add_mode = (op == 3'd5) || (op == 3'd6);
  assign b_eff    = add_mode ? ONE : b;

  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ua (
    .x(a), .sign(sa), .exp(ea), .sig(ma), .is_zero(za), .is_sub(suba),
    .is_inf(ia), .is_nan(na), .is_snan(sna), .is_norm(nrma));
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ub (
    .x(b_eff), .sign(sb), .exp(eb), .sig(mb), .is_zero(zb), .is_sub(subb),
    .is_inf(ib), .is_nan(nb), .is_snan(snb), .is_norm(nrmb));
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_uc (
    .x(c), .sign(sc_raw), .exp(ec), .sig(mc), .is_zero(zc_raw), .is_sub(subc),
    .is_inf(ic_raw), .is_nan(nc_raw), .is_snan(snc_raw), .is_norm(nrmc));

  assign sp     = sa ^ sb ^ neg_prod;
  assign sc     = mul_only ? sp : (sc_raw ^ neg_add);
  assign c_zero = mul_only | zc_raw;
  assign c_inf  = !mul_only & ic_raw;
  assign c_nan  = !mul_only & nc_raw;
  assign c_snan = !mul_only & snc_raw;
  logic [P-1:0] mc_eff;
  assign mc_eff = mul_only ? '0 : mc;

  // special cases -------------------------------------------------------------
  logic         inv_mul, any_nan, any_snan, prod_inf;
  logic         s1_special;
  logic [W-1:0] s1_special_val;
  logic         s1_special_nv;

  assign inv_mul  = (ia & zb) | (za & ib);
  assign any_nan  = na | nb | c_nan;
  assign any_snan = sna | snb | c_snan;
  assign prod_inf = ia | ib;

  always_comb begin
    s1_special     = 1'b1;
    s1_special_val = QNAN;
    s1_special_nv  = 1'b0;
    if (any_nan || inv_mul) begin
      s1_special_nv = any_snan | inv_mul;
    end else if (prod_inf) begin
      if (c_inf && (sc != sp)) s1_special_nv = 1'b1;
      else                     s1_special_val = {sp, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
    end else if (c_inf) begin
      s1_special_val = {sc, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
    end else begin
      s1_special = 1'b0;
    end
  end

  // multiply ------------------------------------------------------------------
  logic [2*P-1:0] prod;
  logic           prod_zero;
  assign prod      = ma * mb;
  assign prod_zero = za | zb;

  // alignment -----------------------------------------------------------------
  //   data frame bit 0 weight (non-dominated) = Ep_lsb - 2, Ep_lsb = ea+eb-2M
  //   pos_c = position of the addend LSB inside the data frame
  logic signed [EI_W+1:0] pos_c;
  logic                   dom;
  logic [EF-1:0]          pf, cf;
  logic signed [EI_W+1:0] s1_etop;     // exponent of frame bit EF-1
  logic [SHW-1:0]         rsh;
  logic [P-1:0]           c_lost_mask;

  assign pos_c = (EI_W+2)'(ec) - (EI_W+2)'(ea) - (EI_W+2)'(eb) + (EI_W+2)'(MAN_W + 2);
  // a zero addend (including the absent addend of FMUL) never dominates
  assign dom   = prod_zero || (!c_zero && (pos_c >= (EI_W+2)'(2 * P + 5)));

  always_comb begin
    pf          = '0;
    cf          = '0;
    rsh         = '0;
    c_lost_mask = '0;
    if (dom) begin
      pf[0]   = !prod_zero;                        // sticky proxy of the product
      cf      = EF'(mc_eff) << 4;                  // addend at data bits [P+2:3]
      s1_etop = (EI_W+2)'(ec) - (EI_W+2)'(MAN_W) - (EI_W+2)'(3) + (EI_W+2)'(EF - 2);
    end else begin
      pf      = EF'(prod) << 3;                    // product at data bits [2P+1:2]
      s1_etop = (EI_W+2)'(ea) + (EI_W+2)'(eb) - (EI_W+2)'(2 * MAN_W) - (EI_W+2)'(2)
                + (EI_W+2)'(EF - 2);
      if (pos_c >= 0) begin
        cf = EF'(mc_eff) << (pos_c[SHW-1:0] + SHW'(1));
      end else begin
        if (-pos_c >= (EI_W+2)'(P)) begin
          cf[0] = (mc_eff != '0);
        end else begin
          rsh         = SHW'(-pos_c);
          c_lost_mask = ~({P{1'b1}} << rsh);
          cf          = ((EF'(mc_eff) >> rsh) << 1) | EF'(|(mc_eff & c_lost_mask));
        end
      end
    end
  end

  // S1 register ----------------------------------------------------------------
  typedef struct packed {
    logic                   special;
    logic [W-1:0]           special_val;
    logic                   special_nv;
    logic                   sp;
    logic                   sc;
    logic [EF-1:0]          pf;
    logic [EF-1:0]          cf;
    logic signed [EI_W+1:0] etop;
    logic [2:0]             rm;
    logic [TAG_W-1:0]       tag;
  } s1_t;

  typedef struct packed {
    logic                   special;
    logic [W-1:0]           special_val;
    logic                   special_nv;
    logic                   zero;
    logic                   zsign;
    logic                   sign;
    logic [EF-1:0]          mag;
    logic signed [EI_W-1:0] etop;
    logic [2:0]             rm;
    logic [TAG_W-1:0]       tag;
  } s2_t;

  typedef struct packed {
    logic                   special;
    logic [W-1:0]           special_val;
    logic                   special_nv;
    logic                   zero;
    logic                   zsign;
    logic                   sign;
    logic [EF-1:0]          sig;
    logic signed [EI_W-1:0] exp;
    logic                   sticky;
    logic                   tiny;
    logic [2:0]             rm;
    logic [TAG_W-1:0]       tag;
  } s3_t;

  typedef struct packed {
    logic [W-1:0]     res;
    logic [4:0]       ff;
    logic [TAG_W-1:0] tag;
  } s4_t;

  s1_t s1_d, s1_q;
  s2_t s2_d, s2_q;
  s3_t s3_d, s3_q;
  s4_t s4_d, s4_q;
  logic v1, v2, v3, v4, r1, r2, r3, r4, tail_ready;

  always_comb begin
    s1_d.special     = s1_special;
    s1_d.special_val = s1_special_val;
    s1_d.special_nv  = s1_special_nv;
    s1_d.sp          = sp;
    s1_d.sc          = sc;
    s1_d.pf          = pf;
    s1_d.cf          = cf;
    s1_d.etop        = s1_etop;
    s1_d.rm          = rm;
    s1_d.tag         = in_tag;
  end

  // ===========================================================================
  // S2 : add / subtract
  // ===========================================================================
  logic          eff_sub;
  logic [EF:0]   sum;
  logic          neg;
  always_comb begin
    eff_sub = s1_q.sp ^ s1_q.sc;
    sum     = eff_sub ? ({1'b0, s1_q.pf} - {1'b0, s1_q.cf}) : ({1'b0, s1_q.pf} + {1'b0, s1_q.cf});
    neg     = eff_sub & sum[EF];
    s2_d.special     = s1_q.special;
    s2_d.special_val = s1_q.special_val;
    s2_d.special_nv  = s1_q.special_nv;
    s2_d.mag         = neg ? (~sum[EF-1:0] + EF'(1)) : sum[EF-1:0];
    s2_d.sign        = neg ? s1_q.sc : s1_q.sp;
    s2_d.zero        = (sum == '0);
    s2_d.zsign       = (s1_q.sp == s1_q.sc) ? s1_q.sp : (s1_q.rm == 3'd2);
    s2_d.etop        = EI_W'(s1_q.etop);
    s2_d.rm          = s1_q.rm;
    s2_d.tag         = s1_q.tag;
  end

  // ===========================================================================
  // S3 : normalise
  // ===========================================================================
  logic [EF-1:0]          n_sig;
  logic signed [EI_W-1:0] n_exp;
  logic                   n_sticky, n_tiny;
  fp_normalize #(.EXP_W(EXP_W), .SW(EF), .EI_W(EI_W)) u_norm (
    .sig_in(s2_q.mag), .exp_in(s2_q.etop), .sig_out(n_sig), .exp_out(n_exp),
    .sticky(n_sticky), .tiny(n_tiny));

  always_comb begin
    s3_d.special     = s2_q.special;
    s3_d.special_val = s2_q.special_val;
    s3_d.special_nv  = s2_q.special_nv;
    s3_d.zero        = s2_q.zero;
    s3_d.zsign       = s2_q.zsign;
    s3_d.sign        = s2_q.sign;
    s3_d.sig         = n_sig;
    s3_d.exp         = n_exp;
    s3_d.sticky      = n_sticky;
    s3_d.tiny        = n_tiny;
    s3_d.rm          = s2_q.rm;
    s3_d.tag         = s2_q.tag;
  end

  // ===========================================================================
  // S4 : round, pack, select
  // ===========================================================================
  logic [W-1:0] r_res;
  logic [4:0]   r_ff;
  fp_round #(.EXP_W(EXP_W), .MAN_W(MAN_W), .SW(EF), .EI_W(EI_W)) u_round (
    .sign(s3_q.sign), .sig(s3_q.sig), .exp(s3_q.exp), .sticky_in(s3_q.sticky),
    .tiny(s3_q.tiny), .rm(s3_q.rm), .result(r_res), .fflags(r_ff));

  always_comb begin
    s4_d.tag = s3_q.tag;
    if (s3_q.special) begin
      s4_d.res = s3_q.special_val;
      s4_d.ff  = {s3_q.special_nv, 4'b0000};
    end else if (s3_q.zero) begin
      s4_d.res = {s3_q.zsign, {(W-1){1'b0}}};
      s4_d.ff  = 5'b00000;
    end else begin
      s4_d.res = r_res;
      s4_d.ff  = r_ff;
    end
  end

  // ===========================================================================
  // elastic stage registers
  // ===========================================================================
  assign r4       = !v4 || tail_ready;
  assign r3       = !v3 || r4;
  assign r2       = !v2 || r3;
  assign r1       = !v1 || r2;
  assign in_ready = r1;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      v1 <= 1'b0; v2 <= 1'b0; v3 <= 1'b0; v4 <= 1'b0;
    end else begin
      if (r1) v1 <= in_valid;
      if (r2) v2 <= v1;
      if (r3) v3 <= v2;
      if (r4) v4 <= v3;
    end
  end
  always_ff @(posedge clk) begin
    if (r1 && in_valid) s1_q <= s1_d;
    if (r2 && v1)       s2_q <= s2_d;
    if (r3 && v2)       s3_q <= s3_d;
    if (r4 && v3)       s4_q <= s4_d;
  end

  // optional retiming slices ----------------------------------------------------
  // (slice storage is declared at module scope as flat vectors: Yosys cannot
  //  size 2-D arrays declared inside a generate block when indexed by genvar)
  localparam int EXTRA = (LATENCY > 4) ? (LATENCY - 4) : 0;
  localparam int SW4   = W + 5 + TAG_W;
  logic [EXTRA:0]           sl_v, sl_r;
  logic [(EXTRA+1)*SW4-1:0] sl_d;
  generate
    if (EXTRA == 0) begin : g_direct
      assign tail_ready = out_ready;
      assign out_valid  = v4;
      assign result     = s4_q.res;
      assign fflags     = s4_q.ff;
      assign out_tag    = s4_q.tag;
      assign sl_v = '0;
      assign sl_r = '0;
      assign sl_d = '0;
    end else begin : g_slices
      assign sl_v[0]          = v4;
      assign sl_d[0 +: SW4]   = s4_q;
      assign tail_ready       = sl_r[0];
      for (genvar k = 0; k < EXTRA; k++) begin : g_k
        sf_pipe_reg #(.W(SW4)) u_slice (
          .clk(clk), .rst_n(rst_n),
          .in_valid(sl_v[k]), .in_ready(sl_r[k]), .in_data(sl_d[k*SW4 +: SW4]),
          .out_valid(sl_v[k+1]), .out_ready(sl_r[k+1]), .out_data(sl_d[(k+1)*SW4 +: SW4]));
      end
      assign sl_r[EXTRA] = out_ready;
      assign out_valid   = sl_v[EXTRA];
      assign {result, fflags, out_tag} = sl_d[EXTRA*SW4 +: SW4];
    end
  endgenerate

endmodule

// =============================================================================
// sf_fma_array -- N fma_units in lockstep (shared op / rm / handshake)
// -----------------------------------------------------------------------------
// Used by every multi-step engine (polynomial, interpolation, state update,
// residual, conservation, objective, constraint, sweep, search, reduction).
// All units receive the same valid/ready, so their handshakes are identical
// and unit 0 represents the array.
// =============================================================================
module sf_fma_array #(
  parameter int N       = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic           clk,
  input  logic           rst_n,
  input  logic           in_valid,
  output logic           in_ready,
  input  logic [2:0]     op,
  input  logic [2:0]     rm,
  input  logic [N*W-1:0] a,
  input  logic [N*W-1:0] b,
  input  logic [N*W-1:0] c,
  output logic           out_valid,
  input  logic           out_ready,
  output logic [N*W-1:0] res,
  output logic [N*5-1:0] ff
);
  logic [N-1:0] ir, ov;
  for (genvar i = 0; i < N; i++) begin : g_u
    logic [0:0] t_unused;
    fma_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY), .TAG_W(1)) u_fma (
      .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(ir[i]),
      .op(op), .rm(rm), .a(a[i*W +: W]), .b(b[i*W +: W]), .c(c[i*W +: W]), .in_tag(1'b0),
      .out_valid(ov[i]), .out_ready(out_ready), .result(res[i*W +: W]), .fflags(ff[i*5 +: 5]),
      .out_tag(t_unused));
  end
  assign in_ready  = ir[0];
  assign out_valid = ov[0];
endmodule
