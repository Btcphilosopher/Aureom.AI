// =============================================================================
// Silica Flux -- fast approximate reciprocal  (table seed + Newton-Raphson)
// -----------------------------------------------------------------------------
//   seed   y0 = T[top TB fraction bits]        (midpoint reciprocal, ~2^-9 rel)
//   NR     y <- y * (2 - m*y)                  (quadratic convergence)
//   FP32   TB=7, F=32, 2 iterations            FP64  TB=7, F=62, 3 iterations
//
// Fixed-point products are rounded half-up (+2^(F-1), >> F) exactly as in
// python/golden_model/sfu.py; the final value is rounded to nearest-even.
// Measured error: <= 0.503 ULP (FP32), <= 0.501 ULP (FP64) -- see
// reports/numerics/sfu_accuracy.json.  The result is NOT guaranteed correctly
// rounded; use VDIV for that.  Exact for powers of two.
//
// One (F+2)x(F+2) multiplier, reused: latency 3 + 2*NIT cycles.
// =============================================================================
module reciprocal_unit #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23,
  parameter int TAG_W = 8
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic [EXP_W+MAN_W:0] a,
  input  logic [TAG_W-1:0]     in_tag,
  output logic                 out_valid,
  input  logic                 out_ready,
  output logic [EXP_W+MAN_W:0] result,
  output logic [4:0]           fflags,
  output logic [TAG_W-1:0]     out_tag,
  output logic                 busy
);
  `include "sfu_tables.svh"

  localparam bit IS64 = (EXP_W == 11);
  localparam int W    = EXP_W + MAN_W + 1;
  localparam int P    = MAN_W + 1;
  localparam int M    = MAN_W;
  localparam int EI_W = EXP_W + 4;
  localparam int TB   = 7;
  localparam int F    = IS64 ? 62 : 32;
  localparam int NIT  = IS64 ? 3 : 2;
  localparam int YW   = F + 2;
  localparam int PKW  = F + 2;
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};

  typedef enum logic [2:0] {S_IDLE, S_MULA, S_MULB, S_PACK, S_DONE} state_t;
  state_t state;

  // decode ----------------------------------------------------------------------
  logic sa, za, ia, na, sna, suba, nrma;
  logic signed [EI_W-1:0] ea;
  logic [P-1:0] ma;
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ua (
    .x(a), .sign(sa), .exp(ea), .sig(ma), .is_zero(za), .is_sub(suba),
    .is_inf(ia), .is_nan(na), .is_snan(sna), .is_norm(nrma));
  localparam int LZW = $clog2(P + 1);
  logic [LZW-1:0] lz;
  logic           lz_z;
  sf_lzc #(.W(P)) u_lz (.in(ma), .cnt(lz), .zero(lz_z));

  logic [P-1:0]           mn;
  logic signed [EI_W-1:0] en;
  logic [TB-1:0]          idx;
  logic [79:0]            seed80;
  assign mn     = ma << lz;
  assign en     = ea - EI_W'(signed'({1'b0, lz}));
  assign idx    = mn[M-1 -: TB];
  assign seed80 = IS64 ? sfu_fp64_recip_t(idx) : sfu_fp32_recip_t(idx);

  // state -------------------------------------------------------------------------
  logic [YW-1:0]          y_q, mf_q, d_q;
  logic [1:0]             it_q;
  logic                   sign_q, exact_q;
  logic signed [EI_W-1:0] e_q;
  logic [TAG_W-1:0]       tag_q;
  logic [W-1:0]           res_q;
  logic [4:0]             ff_q;

  logic [2*YW-1:0] prod;
  logic [YW-1:0]   mul_b;
  assign mul_b = (state == S_MULA) ? mf_q : d_q;
  assign prod  = y_q * mul_b;

  localparam logic [2*YW-1:0] HALF = (2*YW)'(1) << (F - 1);
  logic [2*YW-1:0] prod_r;
  assign prod_r = (prod + HALF) >> F;

  // pack ------------------------------------------------------------------------------
  logic [PKW-1:0]         pk_sig;
  logic signed [EI_W-1:0] pk_exp;
  logic [PKW-1:0]         n_sig;
  logic signed [EI_W-1:0] n_exp;
  logic                   n_st, n_tiny;
  logic [W-1:0]           r_res;
  logic [4:0]             r_ff;
  always_comb begin
    if (exact_q) begin
      pk_sig = {1'b1, {(PKW-1){1'b0}}};
      pk_exp = -e_q;
    end else begin
      pk_sig = y_q;                                   // value y * 2^-F * 2^-e
      pk_exp = EI_W'(signed'(1)) - e_q;               // exponent of bit F+1
    end
  end
  fp_normalize #(.EXP_W(EXP_W), .SW(PKW), .EI_W(EI_W)) u_norm (
    .sig_in(pk_sig), .exp_in(pk_exp), .sig_out(n_sig), .exp_out(n_exp), .sticky(n_st), .tiny(n_tiny));
  fp_round #(.EXP_W(EXP_W), .MAN_W(MAN_W), .SW(PKW), .EI_W(EI_W)) u_round (
    .sign(sign_q), .sig(n_sig), .exp(n_exp), .sticky_in(n_st | !exact_q), .tiny(n_tiny),
    .rm(3'd0), .result(r_res), .fflags(r_ff));

  assign in_ready  = (state == S_IDLE);
  assign busy      = (state != S_IDLE);
  assign out_valid = (state == S_DONE);
  assign result    = res_q;
  assign fflags    = ff_q;
  assign out_tag   = tag_q;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
    end else begin
      case (state)
        S_IDLE: if (in_valid) begin
          if (na || za || ia)          state <= S_DONE;
          else if (mn == (P'(1) << M)) state <= S_PACK;
          else                         state <= S_MULA;
        end
        S_MULA: state <= S_MULB;
        S_MULB: state <= (it_q == 2'(NIT - 1)) ? S_PACK : S_MULA;
        S_PACK: state <= S_DONE;
        S_DONE: if (out_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (in_valid) begin
        sign_q  <= sa;
        e_q     <= en;
        exact_q <= (mn == (P'(1) << M));
        y_q     <= seed80[YW-1:0];
        mf_q    <= YW'(mn) << (F - M);
        it_q    <= '0;
        tag_q   <= in_tag;
        if (na) begin
          res_q <= QNAN;  ff_q <= {sna, 4'b0000};
        end else if (za) begin
          res_q <= {sa, {EXP_W{1'b1}}, {MAN_W{1'b0}}};  ff_q <= 5'b01000;   // DZ
        end else begin
          res_q <= {sa, {(W-1){1'b0}}};  ff_q <= 5'b00000;                  // 1/inf
        end
      end
      S_MULA: d_q <= (YW'(2) << F) - prod_r[YW-1:0];
      S_MULB: begin
        y_q  <= prod_r[YW-1:0];
        it_q <= it_q + 2'd1;
      end
      S_PACK: begin
        res_q <= r_res;
        ff_q  <= r_ff;
      end
      default: ;
    endcase
  end
endmodule
