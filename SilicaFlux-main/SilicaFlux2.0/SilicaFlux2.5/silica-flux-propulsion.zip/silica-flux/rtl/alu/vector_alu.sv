// =============================================================================
// Silica Flux -- vector ALU functional unit (FU_VALU)
// -----------------------------------------------------------------------------
// LANES x vector_lane in lockstep plus a control pipeline of identical
// structure that carries the micro-op, the lane mask and the propagated
// operand quality.  Fixed latency = LATENCY (PIPELINE_DEPTH) for every VALU
// opcode; one instruction per cycle; full valid/ready back-pressure.
//
// Quality propagation (per lane):
//   q_out = OR(quality of every operand the opcode reads)
//         | {UF -> Q_UNF, OF or Inf result -> Q_OVF, NV or NaN result -> Q_NAN}
// =============================================================================
`include "flux_fu_if.svh"
module vector_alu #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic clk,
  input  logic rst_n,
  `SF_FU_PORTS
);
  localparam int LW = (LANES > 1) ? $clog2(LANES) : 1;

  flux_pkg::instr_t ins;
  assign ins = req_uop.ins;

  // ---- operand preparation -------------------------------------------------------
  logic [LW-1:0]  bsel;
  logic [W-1:0]   a_bc;
  logic [flux_pkg::QW-1:0]  qa_bc;
  logic [3:0]     use_src;
  assign bsel    = LW'(ins.imm[18:12]);       // VBCAST lane select (imm[5:0] stays the scale)
  assign a_bc    = req_a[bsel*W +: W];
  assign qa_bc   = req_qa[bsel*flux_pkg::QW +: flux_pkg::QW];
  assign use_src = flux_pkg::src_use(ins);

  logic [LANES*flux_pkg::QW-1:0] qin;
  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      logic [flux_pkg::QW-1:0] q;
      q = '0;
      if (use_src[0]) q |= req_qa[l*flux_pkg::QW +: flux_pkg::QW];
      if (use_src[1]) q |= req_qb[l*flux_pkg::QW +: flux_pkg::QW];
      if (use_src[2]) q |= req_qc[l*flux_pkg::QW +: flux_pkg::QW];
      case (ins.opcode)
        flux_pkg::OP_VBCAST:             q = qa_bc;
        flux_pkg::OP_VSLIDE: begin
          logic [LW-1:0] sl;
          sl = LW'(l) + bsel;
          q  = req_qa[sl*flux_pkg::QW +: flux_pkg::QW];
        end
        flux_pkg::OP_VSEL:               q = req_vm[l] ? req_qa[l*flux_pkg::QW +: flux_pkg::QW] : req_qb[l*flux_pkg::QW +: flux_pkg::QW];
        flux_pkg::OP_VLANEID, flux_pkg::OP_VMSET:  q = '0;
        default: ;
      endcase
      qin[l*flux_pkg::QW +: flux_pkg::QW] = q;
    end
  end

  // ---- lanes ------------------------------------------------------------------------
  logic [LANES-1:0]       l_in_ready, l_out_valid, l_mbit;
  logic [LANES*W-1:0]     l_res;
  logic [LANES*5-1:0]     l_ff;
  logic is_bcast, is_slide;
  assign is_bcast = (ins.opcode == flux_pkg::OP_VBCAST);
  assign is_slide = (ins.opcode == flux_pkg::OP_VSLIDE);
  for (genvar l = 0; l < LANES; l++) begin : g_lane
    logic [W-1:0]  a_l;
    logic [LW-1:0] src_l;
    assign src_l = LW'(l) + bsel;                       // VSLIDE source lane (mod LANES)
    assign a_l = is_bcast ? a_bc : (is_slide ? req_a[src_l*W +: W] : req_a[l*W +: W]);
    vector_lane #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY), .LANE(l)) u_lane (
      .clk(clk), .rst_n(rst_n),
      .in_valid(req_valid), .in_ready(l_in_ready[l]),
      .opcode(ins.opcode), .prec(ins.prec), .func(ins.func), .imm(ins.imm), .rm(req_uop.rm),
      .a(a_l),
      .b(req_b[l*W +: W]), .c(req_c[l*W +: W]), .vm_bit(req_vm[l]),
      .out_valid(l_out_valid[l]), .out_ready(rsp_ready),
      .res(l_res[l*W +: W]), .ff(l_ff[l*5 +: 5]), .mbit(l_mbit[l]));
  end

  // ---- control pipeline (same structure as the lanes) -----------------------------------
  localparam int UW = flux_pkg::UOP_W;
  localparam int CW = UW + LANES + LANES * flux_pkg::QW;
  logic [LATENCY:0]         cv, cr;
  logic [LATENCY:0][CW-1:0] cd;
  assign cv[0] = req_valid;
  assign cd[0] = {req_uop, req_lmask, qin};
  for (genvar k = 0; k < LATENCY; k++) begin : g_ctl
    sf_pipe_reg #(.W(CW)) u_ctl (
      .clk(clk), .rst_n(rst_n),
      .in_valid(cv[k]), .in_ready(cr[k]), .in_data(cd[k]),
      .out_valid(cv[k+1]), .out_ready(cr[k+1]), .out_data(cd[k+1]));
  end
  assign cr[LATENCY] = rsp_ready;

  flux_pkg::uop_t                o_uop;
  logic [LANES-1:0]    o_lmask;
  logic [LANES*flux_pkg::QW-1:0] o_qin;
  assign {o_uop, o_lmask, o_qin} = cd[LATENCY];

  assign req_ready = l_in_ready[0];
  assign rsp_valid = l_out_valid[0];
  assign rsp_uop   = o_uop;
  assign rsp_data  = l_res;
  assign rsp_wmask = o_lmask;
  assign rsp_vm    = l_mbit;
  assign rsp_faults = '0;

  // ---- output quality and flags ------------------------------------------------------------
  logic fp_result;
  assign fp_result = ((o_uop.ins.prec == flux_pkg::PREC_FP32) || (o_uop.ins.prec == flux_pkg::PREC_FP64))
                     && (o_uop.ins.opcode != flux_pkg::OP_VCLASS);
  always_comb begin
    rsp_fflags = '0;
    for (int l = 0; l < LANES; l++) begin
      logic [W-1:0]  r;
      logic [4:0]    f;
      logic [flux_pkg::QW-1:0] q;
      r = l_res[l*W +: W];
      f = l_ff[l*5 +: 5];
      q = o_qin[l*flux_pkg::QW +: flux_pkg::QW];
      q[flux_pkg::Q_NAN] = q[flux_pkg::Q_NAN] | f[flux_pkg::FF_NV] | (fp_result && (r[W-2:MAN_W] == '1) && (r[MAN_W-1:0] != '0));
      q[flux_pkg::Q_OVF] = q[flux_pkg::Q_OVF] | f[flux_pkg::FF_OF] | (fp_result && (r[W-2:MAN_W] == '1) && (r[MAN_W-1:0] == '0));
      q[flux_pkg::Q_UNF] = q[flux_pkg::Q_UNF] | f[flux_pkg::FF_UF];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = q;
      if (o_lmask[l]) rsp_fflags |= f;
    end
  end

`ifdef SF_SVA
  a_lanes_lockstep: assert property (@(posedge clk) disable iff (!rst_n)
    (&l_out_valid == |l_out_valid) && (&l_in_ready == |l_in_ready) && (cv[LATENCY] == l_out_valid[0]));
`endif
endmodule
