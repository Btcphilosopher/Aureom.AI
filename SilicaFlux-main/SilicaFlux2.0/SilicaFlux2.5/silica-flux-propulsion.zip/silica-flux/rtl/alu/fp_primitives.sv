// =============================================================================
// Silica Flux -- floating-point primitives shared by every arithmetic unit
// -----------------------------------------------------------------------------
//   sf_lzc        leading-zero counter (priority encoder)
//   fp_unpack     IEEE field decode + classification
//   fp_normalize  leading-zero normalisation with exponent floor at emin
//                 (produces subnormal alignment and the tininess indication)
//   fp_round      rounding (5 IEEE modes), packing, overflow / underflow
//
// All modules are purely combinational and generic in (EXP_W, MAN_W); the
// arithmetic units place pipeline registers between them.  Conventions:
//   * an exponent "e" attached to a significand denotes the unbiased exponent
//     of the significand's most-significant bit position;
//   * subnormal inputs are reported with e = emin and a cleared hidden bit;
//   * tininess is detected before rounding (IEEE 754-2019 sec. 7.5).
// =============================================================================

module sf_lzc #(
  parameter int W  = 32,
  parameter int CW = $clog2(W + 1)
) (
  input  logic [W-1:0]  in,
  output logic [CW-1:0] cnt,
  output logic          zero
);
  always_comb begin
    cnt = CW'(W);
    for (int i = 0; i < W; i++) begin
      if (in[i]) cnt = CW'(W - 1 - i);
    end
  end
  assign zero = (in == '0);
endmodule

// -----------------------------------------------------------------------------
module fp_unpack #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23,
  parameter int EI_W  = EXP_W + 4
) (
  input  logic [EXP_W+MAN_W:0]   x,
  output logic                   sign,
  output logic signed [EI_W-1:0] exp,     // unbiased exponent of hidden-bit position
  output logic [MAN_W:0]         sig,     // {hidden, mantissa}
  output logic                   is_zero,
  output logic                   is_sub,
  output logic                   is_inf,
  output logic                   is_nan,
  output logic                   is_snan,
  output logic                   is_norm
);
  localparam int BIAS = (1 << (EXP_W - 1)) - 1;
  logic [EXP_W-1:0] ef;
  logic [MAN_W-1:0] mf;
  logic             ef_zero, ef_ones;

  assign sign    = x[EXP_W+MAN_W];
  assign ef      = x[EXP_W+MAN_W-1:MAN_W];
  assign mf      = x[MAN_W-1:0];
  assign ef_zero = (ef == '0);
  assign ef_ones = (ef == '1);
  assign is_zero = ef_zero && (mf == '0);
  assign is_sub  = ef_zero && (mf != '0);
  assign is_inf  = ef_ones && (mf == '0);
  assign is_nan  = ef_ones && (mf != '0);
  assign is_snan = is_nan && !mf[MAN_W-1];
  assign is_norm = !ef_zero && !ef_ones;
  assign sig     = {!ef_zero, mf};
  assign exp     = ef_zero ? EI_W'(signed'(1 - BIAS))
                           : EI_W'(signed'({1'b0, ef})) - EI_W'(BIAS);
endmodule

// -----------------------------------------------------------------------------
module fp_normalize #(
  parameter int EXP_W = 8,
  parameter int SW    = 77,              // significand width being normalised
  parameter int EI_W  = EXP_W + 4
) (
  input  logic [SW-1:0]          sig_in,
  input  logic signed [EI_W-1:0] exp_in,  // exponent of sig_in[SW-1]
  output logic [SW-1:0]          sig_out, // MSB set unless result is subnormal
  output logic signed [EI_W-1:0] exp_out, // >= emin
  output logic                   sticky,  // bits lost in subnormal right shift
  output logic                   tiny     // exact value below 2^emin
);
  localparam int BIAS = (1 << (EXP_W - 1)) - 1;
  localparam int EMIN = 1 - BIAS;
  localparam int CW   = $clog2(SW + 1);

  logic [CW-1:0]          lz;
  logic                   all_zero;
  logic signed [EI_W-1:0] e_full, emin_s;
  logic signed [EI_W:0]   rshift_s;
  logic [SW-1:0]          lost_mask;

  sf_lzc #(.W(SW)) u_lzc (.in(sig_in), .cnt(lz), .zero(all_zero));

  assign emin_s = EI_W'(signed'(EMIN));
  assign e_full = exp_in - EI_W'(signed'({1'b0, lz}));

  always_comb begin
    sig_out   = sig_in;
    exp_out   = exp_in;
    sticky    = 1'b0;
    tiny      = 1'b0;
    rshift_s  = '0;
    lost_mask = '0;
    if (!all_zero) begin
      if (e_full >= emin_s) begin
        sig_out = sig_in << lz;
        exp_out = e_full;
      end else if (exp_in >= emin_s) begin
        // partial normalisation: stop at emin, result is subnormal
        sig_out = sig_in << (exp_in - emin_s);
        exp_out = emin_s;
        tiny    = 1'b1;
      end else begin
        // value lies below emin with the MSB above sig position: shift right
        rshift_s = (EI_W+1)'(emin_s) - (EI_W+1)'(exp_in);
        tiny     = 1'b1;
        exp_out  = emin_s;
        if (rshift_s >= (EI_W+1)'(SW)) begin
          sig_out = '0;
          sticky  = 1'b1;
        end else begin
          lost_mask = ~({SW{1'b1}} << rshift_s[CW-1:0]);
          sticky    = |(sig_in & lost_mask);
          sig_out   = sig_in >> rshift_s[CW-1:0];
        end
      end
    end
  end
endmodule

// -----------------------------------------------------------------------------
module fp_round #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23,
  parameter int SW    = 77,
  parameter int EI_W  = EXP_W + 4
) (
  input  logic                   sign,
  input  logic [SW-1:0]          sig,      // from fp_normalize
  input  logic signed [EI_W-1:0] exp,
  input  logic                   sticky_in,
  input  logic                   tiny,
  input  logic [2:0]             rm,
  output logic [EXP_W+MAN_W:0]   result,
  output logic [4:0]             fflags    // {NV, DZ, OF, UF, NX}
);
  localparam int P    = MAN_W + 1;
  localparam int BIAS = (1 << (EXP_W - 1)) - 1;
  localparam int EMAX_BIASED = (1 << EXP_W) - 2;

  logic [P-1:0]           kept;
  logic                   rbit, st, inexact, inc;
  logic [P:0]             q;
  logic signed [EI_W-1:0] e_r;
  logic signed [EI_W:0]   biased;
  logic                   normal, overflow, to_inf;

  assign kept = sig[SW-1 -: P];
  assign rbit = sig[SW-1-P];
  generate
    if (SW >= P + 2) begin : g_st
      assign st = (|sig[SW-2-P:0]) | sticky_in;
    end else begin : g_nost
      assign st = sticky_in;
    end
  endgenerate
  assign inexact = rbit | st;

  always_comb begin
    case (rm)
      3'd1:    inc = 1'b0;                          // RTZ
      3'd2:    inc = inexact & sign;                // RDN
      3'd3:    inc = inexact & ~sign;               // RUP
      3'd4:    inc = rbit;                          // RMM
      default: inc = rbit & (st | kept[0]);         // RNE
    endcase
  end

  always_comb begin
    q   = {1'b0, kept} + {{P{1'b0}}, inc};
    e_r = exp;
    if (q[P]) begin
      q   = q >> 1;
      e_r = exp + EI_W'(1);
    end
  end

  assign normal   = q[P-1];
  assign biased   = (EI_W+1)'(e_r) + (EI_W+1)'(BIAS);
  assign overflow = normal && (biased > (EI_W+1)'(EMAX_BIASED));
  assign to_inf   = (rm == 3'd0) || (rm == 3'd4) || (rm == 3'd2 && sign) || (rm == 3'd3 && !sign)
                    || (rm > 3'd4);

  always_comb begin
    if (overflow) begin
      if (to_inf) result = {sign, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
      else        result = {sign, {(EXP_W-1){1'b1}}, 1'b0, {MAN_W{1'b1}}};
    end else if (normal) begin
      result = {sign, biased[EXP_W-1:0], q[MAN_W-1:0]};
    end else begin
      result = {sign, {EXP_W{1'b0}}, q[MAN_W-1:0]};
    end
    fflags = {1'b0, 1'b0, overflow, tiny & inexact, inexact | overflow};
  end
endmodule

// -----------------------------------------------------------------------------
// fp_compare -- IEEE comparisons (quiet EQ, signalling LT/LE) and
//               minimumNumber / maximumNumber selection
// -----------------------------------------------------------------------------
module fp_compare #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23
) (
  input  logic [EXP_W+MAN_W:0] a,
  input  logic [EXP_W+MAN_W:0] b,
  output logic                 lt,        // a < b   (false if unordered)
  output logic                 le,        // a <= b
  output logic                 eq,        // a == b  (+0 == -0)
  output logic                 unordered, // either is NaN
  output logic                 snan,      // either is signalling NaN
  output logic [EXP_W+MAN_W:0] vmin,      // minimumNumber(a, b)
  output logic [EXP_W+MAN_W:0] vmax       // maximumNumber(a, b)
);
  localparam int W = EXP_W + MAN_W + 1;
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};
  logic na, nb, za, zb, tot_lt;
  assign na = (a[W-2:MAN_W] == '1) && (a[MAN_W-1:0] != '0);
  assign nb = (b[W-2:MAN_W] == '1) && (b[MAN_W-1:0] != '0);
  assign za = (a[W-2:0] == '0);
  assign zb = (b[W-2:0] == '0);
  assign snan = (na && !a[MAN_W-1]) || (nb && !b[MAN_W-1]);
  assign unordered = na || nb;
  always_comb begin
    if (a[W-1] != b[W-1]) tot_lt = a[W-1];
    else if (a[W-1])      tot_lt = (a[W-2:0] > b[W-2:0]);
    else                  tot_lt = (a[W-2:0] < b[W-2:0]);
  end
  assign eq = !unordered && ((za && zb) || (a == b));
  assign lt = !unordered && !eq && tot_lt;
  assign le = lt || eq;
  always_comb begin
    if (na && nb)      begin vmin = QNAN; vmax = QNAN; end
    else if (na)       begin vmin = b;    vmax = b;    end
    else if (nb)       begin vmin = a;    vmax = a;    end
    else begin
      vmin = (tot_lt || a == b) ? a : b;
      vmax = tot_lt ? b : a;
    end
  end
endmodule

// -----------------------------------------------------------------------------
// fp_from_int -- exact conversion of a small signed integer (|v| < 2^(MAN_W+1))
// -----------------------------------------------------------------------------
module fp_from_int #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23,
  parameter int IW    = 17
) (
  input  logic signed [IW-1:0] v,
  output logic [EXP_W+MAN_W:0] f
);
  localparam int BIAS = (1 << (EXP_W - 1)) - 1;
  logic [IW-1:0] mag;
  int            msb;
  always_comb begin
    mag = v[IW-1] ? IW'(-v) : IW'(v);
    msb = 0;
    for (int k = 0; k < IW; k++) if (mag[k]) msb = k;
    f = '0;
    if (mag != '0) begin
      f[EXP_W+MAN_W]          = v[IW-1];
      f[EXP_W+MAN_W-1:MAN_W]  = EXP_W'(BIAS + msb);
      f[MAN_W-1:0]            = MAN_W'((MAN_W+IW)'(mag) << (MAN_W - msb));
    end
  end
endmodule
