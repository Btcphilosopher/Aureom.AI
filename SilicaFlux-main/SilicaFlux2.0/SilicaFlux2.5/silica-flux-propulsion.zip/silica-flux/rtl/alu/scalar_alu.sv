// =============================================================================
// Silica Flux -- scalar (per-element) ALU
// -----------------------------------------------------------------------------
// Purely combinational; the vector ALU wraps it in delay-matched pipeline
// registers so that every VALU operation has the same fixed latency as the
// FMA path.  Handles everything in the VALU that is not an FP add/mul/fma:
//
//   floating point   MIN MAX (IEEE 754-2019 minimumNumber/maximumNumber),
//                    ABS NEG (sign-bit ops, no flags), CMP EQ/LT/LE,
//                    CLASS, VCVT  FP <- INT/SFIX/UFIX
//   fixed / integer  ADD SUB MUL SQR FMA (saturating, rounded per rm),
//                    MIN MAX ABS NEG CMP, VCVT INT/SFIX/UFIX <- FP
//   any              MOV BCAST SEL LANEID VMSET
//
// Fixed-point format: W-bit two's complement (SFIX, INT) or unsigned (UFIX)
// with F = imm[5:0] fractional bits.  Results never wrap: overflow saturates
// and raises OF.  Semantics are defined by python/golden_model/valu.py.
// =============================================================================
module scalar_alu #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23,
  parameter int LANE  = 0
) (
  input  logic [7:0]           opcode,
  input  logic [2:0]           prec,
  input  logic [3:0]           func,
  input  logic [18:0]          imm,
  input  logic [2:0]           rm,
  input  logic [EXP_W+MAN_W:0] a,
  input  logic [EXP_W+MAN_W:0] b,
  input  logic [EXP_W+MAN_W:0] c,
  input  logic                 vm_bit,
  output logic [EXP_W+MAN_W:0] res,
  output logic [4:0]           ff,
  output logic                 mbit
);
  localparam int W    = EXP_W + MAN_W + 1;
  localparam int P    = MAN_W + 1;
  localparam int M    = MAN_W;
  localparam int EI_W = EXP_W + 4;
  localparam int XW   = 2 * W + 3;                  // wide signed arithmetic
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};
  localparam logic [W-1:0] ONE  = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};

  // exact FP encoding of a small non-negative integer (the lane index)
  function automatic logic [W-1:0] i2f_lane(input int l);
    logic [W-1:0] v;
    logic [63:0]  lw;
    int msb;
    v = '0;
    msb = 0;
    for (int k = 0; k < 8; k++) if (l[k]) msb = k;
    lw = 64'(l) - (64'd1 << msb);
    v[W-2:MAN_W] = EXP_W'((1 << (EXP_W - 1)) - 1 + msb);
    v[MAN_W-1:0] = lw[MAN_W-1:0] << (MAN_W - msb);
    i2f_lane = v;
  endfunction

  logic imm_lane_bit;
  generate
    if (LANE < 19) begin : g_imm
      assign imm_lane_bit = imm[LANE];
    end else begin : g_noimm
      assign imm_lane_bit = 1'b0;
    end
  endgenerate

  logic is_fp, is_uf;
  logic [5:0] frac, frac_src;
  assign is_fp    = (prec == flux_pkg::PREC_FP32) || (prec == flux_pkg::PREC_FP64);
  assign is_uf    = (prec == flux_pkg::PREC_UFIX);
  assign frac     = (prec == flux_pkg::PREC_INT) ? 6'd0 : imm[5:0];
  assign frac_src = (func[2:0] == flux_pkg::PREC_INT) ? 6'd0 : imm[11:6];

  // ---------------------------------------------------------------------------
  // FP classification
  // ---------------------------------------------------------------------------
  logic sa, sb, za, zb, ia, ib, na, nb, sna, snb, suba, subb, nrma, nrmb;
  logic signed [EI_W-1:0] ea, eb;
  logic [P-1:0] ma, mb;
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ua (
    .x(a), .sign(sa), .exp(ea), .sig(ma), .is_zero(za), .is_sub(suba),
    .is_inf(ia), .is_nan(na), .is_snan(sna), .is_norm(nrma));
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ub (
    .x(b), .sign(sb), .exp(eb), .sig(mb), .is_zero(zb), .is_sub(subb),
    .is_inf(ib), .is_nan(nb), .is_snan(snb), .is_norm(nrmb));

  // total-order "a < b" for non-NaN operands, with -0 < +0
  logic a_lt_b_tot, a_eq_b_num, a_lt_b_num;
  always_comb begin
    if (sa != sb)  a_lt_b_tot = sa;
    else if (sa)   a_lt_b_tot = (a[W-2:0] > b[W-2:0]);
    else           a_lt_b_tot = (a[W-2:0] < b[W-2:0]);
    a_eq_b_num = (za && zb) || (a == b);
    a_lt_b_num = !a_eq_b_num && a_lt_b_tot;
  end

  logic [9:0] fclass;
  always_comb begin
    fclass = '0;
    if (na)        fclass[sna ? 8 : 9] = 1'b1;
    else if (ia)   fclass[sa ? 0 : 7]  = 1'b1;
    else if (za)   fclass[sa ? 3 : 4]  = 1'b1;
    else if (suba) fclass[sa ? 2 : 5]  = 1'b1;
    else           fclass[sa ? 1 : 6]  = 1'b1;
  end

  // ---------------------------------------------------------------------------
  // FP <- integer / fixed conversion
  // ---------------------------------------------------------------------------
  logic                   i2f_neg;
  logic [W-1:0]           i2f_mag, i2f_sig;
  logic signed [EI_W-1:0] i2f_exp_in, i2f_exp;
  logic                   i2f_st, i2f_tiny;
  logic [W-1:0]           i2f_res;
  logic [4:0]             i2f_ff;
  always_comb begin
    i2f_neg    = (func[2:0] != flux_pkg::PREC_UFIX) && a[W-1];
    i2f_mag    = i2f_neg ? (~a + W'(1)) : a;
    i2f_exp_in = EI_W'(W - 1) - EI_W'(signed'({1'b0, frac_src}));
  end
  fp_normalize #(.EXP_W(EXP_W), .SW(W), .EI_W(EI_W)) u_i2f_n (
    .sig_in(i2f_mag), .exp_in(i2f_exp_in), .sig_out(i2f_sig), .exp_out(i2f_exp),
    .sticky(i2f_st), .tiny(i2f_tiny));
  fp_round #(.EXP_W(EXP_W), .MAN_W(MAN_W), .SW(W), .EI_W(EI_W)) u_i2f_r (
    .sign(i2f_neg), .sig(i2f_sig), .exp(i2f_exp), .sticky_in(i2f_st), .tiny(i2f_tiny),
    .rm(rm), .result(i2f_res), .fflags(i2f_ff));

  // ---------------------------------------------------------------------------
  // integer / fixed <- FP conversion (saturating, rounded per rm)
  // ---------------------------------------------------------------------------
  logic [W-1:0]         f2i_res;
  logic [4:0]           f2i_ff;
  logic signed [EI_W:0] f2i_sh;
  logic [W+P:0]         f2i_q;
  logic                 f2i_r, f2i_st, f2i_inc, f2i_ovf;
  logic [P-1:0]         f2i_mask;
  logic [W-1:0]         f2i_hi, f2i_lo;
  always_comb begin
    f2i_hi   = is_uf ? {W{1'b1}} : {1'b0, {(W-1){1'b1}}};
    f2i_lo   = is_uf ? '0 : {1'b1, {(W-1){1'b0}}};
    f2i_sh   = (EI_W+1)'(ea) - (EI_W+1)'(M) + (EI_W+1)'(signed'({1'b0, frac}));
    f2i_q    = '0;
    f2i_r    = 1'b0;
    f2i_st   = 1'b0;
    f2i_ovf  = 1'b0;
    f2i_mask = '0;
    if (f2i_sh >= 0) begin
      if (f2i_sh > (EI_W+1)'(W)) f2i_ovf = !za;
      else                       f2i_q   = (W+P+1)'(ma) << f2i_sh;
    end else if (-f2i_sh > (EI_W+1)'(P)) begin
      f2i_st = !za;
    end else begin
      f2i_q    = (W+P+1)'(ma) >> (-f2i_sh);
      f2i_r    = ma[-f2i_sh - 1];
      f2i_mask = ~({P{1'b1}} << (-f2i_sh - 1));
      f2i_st   = |(ma & f2i_mask);
    end
    case (rm)
      flux_pkg::RM_RTZ:  f2i_inc = 1'b0;
      flux_pkg::RM_RDN:  f2i_inc = sa & (f2i_r | f2i_st);
      flux_pkg::RM_RUP:  f2i_inc = !sa & (f2i_r | f2i_st);
      flux_pkg::RM_RMM:  f2i_inc = f2i_r;
      default: f2i_inc = f2i_r & (f2i_st | f2i_q[0]);
    endcase
    f2i_q = f2i_q + (W+P+1)'(f2i_inc);
    if (is_uf) begin
      if (sa && f2i_q != '0)                          f2i_ovf = 1'b1;
      if (!sa && f2i_q > (W+P+1)'(f2i_hi))            f2i_ovf = 1'b1;
    end else begin
      if (!sa && f2i_q > (W+P+1)'(f2i_hi))            f2i_ovf = 1'b1;
      if (sa && f2i_q > ((W+P+1)'(1) << (W - 1)))     f2i_ovf = 1'b1;
    end
    if (na) begin
      f2i_res = f2i_hi;  f2i_ff = 5'b10000;
    end else if (ia || f2i_ovf) begin
      f2i_res = sa ? f2i_lo : f2i_hi;  f2i_ff = 5'b10000;
    end else begin
      f2i_res = sa ? (~f2i_q[W-1:0] + W'(1)) : f2i_q[W-1:0];
      f2i_ff  = {4'b0000, f2i_r | f2i_st};
    end
  end

  // ---------------------------------------------------------------------------
  // fixed-point / integer arithmetic
  // ---------------------------------------------------------------------------
  logic signed [XW-1:0] xa, xb, xc, xr, prod, pq, sat_hi, sat_lo;
  logic [63:0]          remmask;
  logic                 p_half, p_rest, p_exact, p_inc;
  always_comb begin
    xa = is_uf ? signed'(XW'(a)) : XW'(signed'(a));
    xb = is_uf ? signed'(XW'(b)) : XW'(signed'(b));
    xc = is_uf ? signed'(XW'(c)) : XW'(signed'(c));
    sat_hi = is_uf ? signed'(XW'({W{1'b1}})) : signed'(XW'({1'b0, {(W-1){1'b1}}}));
    sat_lo = is_uf ? '0 : -(XW'(1) <<< (W - 1));
    prod   = xa * ((opcode == flux_pkg::OP_VSQR) ? xa : xb);
    pq     = prod >>> frac;
    remmask = (64'd1 << frac) - 64'd1;
    p_exact = ((prod[63:0] & remmask) == '0);
    p_half  = (frac != 0) && prod[frac - 1];
    p_rest  = (frac > 1) && ((prod[63:0] & (remmask >> 1)) != '0);
    case (rm)
      flux_pkg::RM_RTZ:  p_inc = prod[XW-1] && !p_exact;
      flux_pkg::RM_RDN:  p_inc = 1'b0;
      flux_pkg::RM_RUP:  p_inc = !p_exact;
      flux_pkg::RM_RMM:  p_inc = p_half && (p_rest || !prod[XW-1]);
      default: p_inc = p_half && (p_rest || pq[0]);
    endcase
    case (opcode)
      flux_pkg::OP_VADD:                   xr = xa + xb;
      flux_pkg::OP_VSUB:                   xr = xa - xb;
      flux_pkg::OP_VMUL, flux_pkg::OP_VSQR:          xr = pq + XW'(p_inc);
      flux_pkg::OP_VFMA:                   xr = pq + XW'(p_inc) + xc;
      flux_pkg::OP_VABS:                   xr = xa[XW-1] ? -xa : xa;
      flux_pkg::OP_VNEG:                   xr = -xa;
      default:                   xr = xa;
    endcase
  end

  // ---------------------------------------------------------------------------
  // result selection
  // ---------------------------------------------------------------------------
  logic cmp_r, cmp_nv;
  logic [W-1:0] fix_one;
  always_comb begin
    fix_one = (32'(frac) >= 32'(W - (is_uf ? 0 : 1))) ? sat_hi[W-1:0] : (W'(1) << frac);
    // comparisons
    if (is_fp) begin
      case (func)
        flux_pkg::CMP_LT:  begin cmp_r = !(na || nb) && a_lt_b_num; cmp_nv = na || nb; end
        flux_pkg::CMP_LE:  begin cmp_r = !(na || nb) && (a_lt_b_num || a_eq_b_num); cmp_nv = na || nb; end
        default: begin cmp_r = !(na || nb) && a_eq_b_num; cmp_nv = sna || snb; end
      endcase
    end else begin
      cmp_nv = 1'b0;
      case (func)
        flux_pkg::CMP_LT:  cmp_r = (xa < xb);
        flux_pkg::CMP_LE:  cmp_r = (xa <= xb);
        default: cmp_r = (xa == xb);
      endcase
    end

    res  = a;
    ff   = '0;
    mbit = 1'b0;
    case (opcode)
      flux_pkg::OP_VMOV, flux_pkg::OP_VBCAST, flux_pkg::OP_VSLIDE: res = a;
      flux_pkg::OP_VSEL:            res = vm_bit ? a : b;
      flux_pkg::OP_VLANEID: begin
        if (is_fp)                  res = (LANE == 0) ? '0 : i2f_lane(LANE);
        else if (prec == flux_pkg::PREC_INT)  res = W'(LANE);
        else                        res = W'(LANE) << frac;
      end
      flux_pkg::OP_VMSET: begin
        res = '0;
        case (func)
          flux_pkg::VMS_NZ:  mbit = is_fp ? (a[W-2:0] != '0) : (a != '0);
          flux_pkg::VMS_NOT: mbit = !vm_bit;
          flux_pkg::VMS_IMM: mbit = imm_lane_bit;
          default: mbit = 1'b1;
        endcase
      end
      flux_pkg::OP_VCMP: begin
        mbit = cmp_r;
        ff   = {cmp_nv, 4'b0000};
        res  = cmp_r ? (is_fp ? ONE : fix_one) : '0;
      end
      default: begin
        if (is_fp) begin
          case (opcode)
            flux_pkg::OP_VMIN: begin
              ff = {sna | snb, 4'b0000};
              if (na && nb)      res = QNAN;
              else if (na)       res = b;
              else if (nb)       res = a;
              else               res = (a_lt_b_tot || a == b) ? a : b;
            end
            flux_pkg::OP_VMAX: begin
              ff = {sna | snb, 4'b0000};
              if (na && nb)      res = QNAN;
              else if (na)       res = b;
              else if (nb)       res = a;
              else               res = a_lt_b_tot ? b : a;
            end
            flux_pkg::OP_VABS:   res = {1'b0, a[W-2:0]};
            flux_pkg::OP_VNEG:   res = {~a[W-1], a[W-2:0]};
            flux_pkg::OP_VCLASS: res = W'(fclass);
            flux_pkg::OP_VCVT: begin
              if (func[2:0] == flux_pkg::PREC_SFIX || func[2:0] == flux_pkg::PREC_UFIX || func[2:0] == flux_pkg::PREC_INT) begin
                res = (i2f_mag == '0) ? '0 : i2f_res;
                ff  = (i2f_mag == '0) ? '0 : i2f_ff;
              end else begin
                res = a;
              end
            end
            default: res = a;
          endcase
        end else begin
          case (opcode)
            flux_pkg::OP_VCVT: begin res = f2i_res; ff = f2i_ff; end
            flux_pkg::OP_VMIN: res = (xa <= xb) ? a : b;
            flux_pkg::OP_VMAX: res = (xa >= xb) ? a : b;
            flux_pkg::OP_VADD, flux_pkg::OP_VSUB, flux_pkg::OP_VMUL, flux_pkg::OP_VSQR, flux_pkg::OP_VFMA, flux_pkg::OP_VABS, flux_pkg::OP_VNEG: begin
              if (xr > sat_hi)      begin res = sat_hi[W-1:0]; ff[flux_pkg::FF_OF] = 1'b1; end
              else if (xr < sat_lo) begin res = sat_lo[W-1:0]; ff[flux_pkg::FF_OF] = 1'b1; end
              else                  res = xr[W-1:0];
              if ((opcode == flux_pkg::OP_VMUL || opcode == flux_pkg::OP_VSQR || opcode == flux_pkg::OP_VFMA) && !p_exact)
                ff[flux_pkg::FF_NX] = 1'b1;
            end
            default: res = a;
          endcase
        end
      end
    endcase
  end

endmodule
