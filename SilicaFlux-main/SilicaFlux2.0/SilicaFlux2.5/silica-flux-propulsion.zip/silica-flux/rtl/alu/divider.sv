// =============================================================================
// Silica Flux -- correctly rounded floating-point divider
// -----------------------------------------------------------------------------
// Digit-recurrence (restoring) division on normalised significands, generic in
// (EXP_W, MAN_W).  BITS_PER_CYCLE quotient bits are retired per clock (1, 2 or
// 4 are typical; the recurrence is unrolled combinationally).  The quotient is
// developed to P+2 bits (+padding), the partial remainder supplies the sticky
// bit, and the shared fp_normalize/fp_round back end produces an IEEE result
// identical to an infinitely precise division followed by a single rounding.
//
// Latency (non-special operands):  2 + ceil((P+2)/BITS_PER_CYCLE) cycles.
// FP32, 1 bit/cycle: 28 cycles.  FP64, 2 bits/cycle: 30 cycles.
// The unit is not pipelined: in_ready is low while an operation is in flight.
// =============================================================================
module divider #(
  parameter int EXP_W          = 8,
  parameter int MAN_W          = 23,
  parameter int BITS_PER_CYCLE = 1,
  parameter int TAG_W          = 8
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic [EXP_W+MAN_W:0] a,          // dividend
  input  logic [EXP_W+MAN_W:0] b,          // divisor
  input  logic [2:0]           rm,
  input  logic [TAG_W-1:0]     in_tag,
  output logic                 out_valid,
  input  logic                 out_ready,
  output logic [EXP_W+MAN_W:0] result,
  output logic [4:0]           fflags,
  output logic [TAG_W-1:0]     out_tag,
  output logic                 busy
);
  localparam int W    = EXP_W + MAN_W + 1;
  localparam int P    = MAN_W + 1;
  localparam int EI_W = EXP_W + 4;
  localparam int NCYC = (P + 2 + BITS_PER_CYCLE - 1) / BITS_PER_CYCLE;
  localparam int QB   = NCYC * BITS_PER_CYCLE;     // developed quotient bits
  localparam int CW   = $clog2(NCYC + 1);
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};

  typedef enum logic [1:0] {S_IDLE, S_ITER, S_ROUND, S_DONE} state_t;
  state_t state;

  // ---------------------------------------------------------------------------
  // operand decode (combinational on the request)
  // ---------------------------------------------------------------------------
  logic sa, sb, za, zb, ia, ib, na, nb, sna, snb, suba, subb, nrma, nrmb;
  logic signed [EI_W-1:0] ea, eb;
  logic [P-1:0] ma, mb;
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ua (
    .x(a), .sign(sa), .exp(ea), .sig(ma), .is_zero(za), .is_sub(suba),
    .is_inf(ia), .is_nan(na), .is_snan(sna), .is_norm(nrma));
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ub (
    .x(b), .sign(sb), .exp(eb), .sig(mb), .is_zero(zb), .is_sub(subb),
    .is_inf(ib), .is_nan(nb), .is_snan(snb), .is_norm(nrmb));

  // normalise subnormal significands
  localparam int LZW = $clog2(P + 1);
  logic [LZW-1:0] lza, lzb;
  logic           lza_z, lzb_z;
  sf_lzc #(.W(P)) u_lza (.in(ma), .cnt(lza), .zero(lza_z));
  sf_lzc #(.W(P)) u_lzb (.in(mb), .cnt(lzb), .zero(lzb_z));

  logic [P-1:0]           na_sig, nb_sig;
  logic signed [EI_W-1:0] q_exp_d;
  logic [P:0]             rem0;
  logic                   special_d, nv_d, dz_d;
  logic [W-1:0]           special_val_d;
  logic                   qsign_d;

  always_comb begin
    na_sig  = ma << lza;
    nb_sig  = mb << lzb;
    qsign_d = sa ^ sb;
    // quotient exponent; pre-shift the dividend when A < B so q in [1,2)
    q_exp_d = (ea - EI_W'(signed'({1'b0, lza}))) - (eb - EI_W'(signed'({1'b0, lzb})));
    if (na_sig < nb_sig) begin
      rem0    = {na_sig, 1'b0};
      q_exp_d = q_exp_d - EI_W'(1);
    end else begin
      rem0    = {1'b0, na_sig};
    end
    special_d     = 1'b1;
    special_val_d = QNAN;
    nv_d          = 1'b0;
    dz_d          = 1'b0;
    if (na || nb) begin
      nv_d = sna | snb;
    end else if ((ia && ib) || (za && zb)) begin
      nv_d = 1'b1;
    end else if (ia) begin
      special_val_d = {qsign_d, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
    end else if (ib) begin
      special_val_d = {qsign_d, {(W-1){1'b0}}};
    end else if (zb) begin
      special_val_d = {qsign_d, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
      dz_d          = 1'b1;
    end else if (za) begin
      special_val_d = {qsign_d, {(W-1){1'b0}}};
    end else begin
      special_d = 1'b0;
    end
  end

  // ---------------------------------------------------------------------------
  // iteration state
  // ---------------------------------------------------------------------------
  logic [P:0]             rem_q;      // partial remainder (< 2B)
  logic [P-1:0]           div_q;
  logic [QB-1:0]          quo_q;
  logic [CW-1:0]          cnt_q;
  logic signed [EI_W-1:0] exp_q;
  logic                   sign_q;
  logic [2:0]             rm_q;
  logic [TAG_W-1:0]       tag_q;
  logic [W-1:0]           res_q;
  logic [4:0]             ff_q;

  // unrolled restoring recurrence: BITS_PER_CYCLE quotient bits
  logic [P+1:0]          r_step [BITS_PER_CYCLE+1];
  logic [BITS_PER_CYCLE-1:0] qbits;
  always_comb begin
    r_step[0] = {1'b0, rem_q};
    for (int k = 0; k < BITS_PER_CYCLE; k++) begin
      if (r_step[k] >= {2'b00, div_q}) begin
        qbits[BITS_PER_CYCLE-1-k] = 1'b1;
        r_step[k+1] = (r_step[k] - {2'b00, div_q}) << 1;
      end else begin
        qbits[BITS_PER_CYCLE-1-k] = 1'b0;
        r_step[k+1] = r_step[k] << 1;
      end
    end
  end

  // rounding back end (combinational on the final iteration state)
  logic [QB-1:0]          n_sig;
  logic signed [EI_W-1:0] n_exp;
  logic                   n_sticky, n_tiny;
  logic [W-1:0]           r_res;
  logic [4:0]             r_ff;
  fp_normalize #(.EXP_W(EXP_W), .SW(QB), .EI_W(EI_W)) u_norm (
    .sig_in(quo_q), .exp_in(exp_q), .sig_out(n_sig), .exp_out(n_exp),
    .sticky(n_sticky), .tiny(n_tiny));
  fp_round #(.EXP_W(EXP_W), .MAN_W(MAN_W), .SW(QB), .EI_W(EI_W)) u_round (
    .sign(sign_q), .sig(n_sig), .exp(n_exp), .sticky_in(n_sticky | (rem_q != '0)),
    .tiny(n_tiny), .rm(rm_q), .result(r_res), .fflags(r_ff));

  assign in_ready  = (state == S_IDLE);
  assign busy      = (state != S_IDLE);
  assign out_valid = (state == S_DONE);
  assign result    = res_q;
  assign fflags    = ff_q;
  assign out_tag   = tag_q;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
    end else begin
      case (state)
        S_IDLE: if (in_valid) state <= special_d ? S_DONE : S_ITER;
        S_ITER: if (cnt_q == CW'(NCYC - 1)) state <= S_ROUND;
        S_ROUND: state <= S_DONE;
        S_DONE: if (out_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (in_valid) begin
        rem_q  <= rem0;
        div_q  <= nb_sig;
        quo_q  <= '0;
        cnt_q  <= '0;
        exp_q  <= q_exp_d;
        sign_q <= qsign_d;
        rm_q   <= rm;
        tag_q  <= in_tag;
        res_q  <= special_val_d;
        ff_q   <= {nv_d, dz_d, 3'b000};
      end
      S_ITER: begin
        rem_q <= r_step[BITS_PER_CYCLE][P:0];
        quo_q <= {quo_q[QB-1-BITS_PER_CYCLE:0], qbits};
        cnt_q <= cnt_q + CW'(1);
      end
      S_ROUND: begin
        res_q <= r_res;
        ff_q  <= r_ff;
      end
      default: ;
    endcase
  end
endmodule
