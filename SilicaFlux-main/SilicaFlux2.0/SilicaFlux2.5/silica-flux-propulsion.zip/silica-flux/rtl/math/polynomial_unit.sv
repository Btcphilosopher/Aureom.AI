// =============================================================================
// Silica Flux -- polynomial evaluation engine (FU_POLY)
// -----------------------------------------------------------------------------
//   VPOLY vd, vs1, vs2, imm=D   vd = c_0 + x(c_1 + x(c_2 + ... + x c_D))
//                               c_k is broadcast from lane k of vs2 (loaded from
//                               coefficient memory); Horner with one FMA per
//                               step, so every step is rounded once.
//                               D = min(imm[3:0], LANES-1).
//   VCUBE vd, vs1               vd = (x*x)*x   (two rounded multiplies)
//
// Typical use: property correlations (cp(T), viscosity, NASA-style
// polynomials), surrogate response surfaces, series approximations.
// One sf_fma_array (LANES units); D steps of LATENCY+2 cycles.
// =============================================================================
`include "flux_fu_if.svh"
module polynomial_unit #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic clk,
  input  logic rst_n,
  `SF_FU_PORTS
);
  `include "flux_q.svh"

  typedef enum logic [1:0] {S_IDLE, S_ISSUE, S_WAIT, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t                     uop_q;
  logic [LANES-1:0][W-1:0]  x_q, c_q, acc_q;
  logic [LANES-1:0][flux_pkg::QW-1:0] qx_q;
  logic [flux_pkg::QW-1:0]            qc_q;
  logic [LANES-1:0][4:0]    lf_q;
  logic [LANES-1:0]         lmask_q;
  logic [3:0]               k_q, deg_q;
  logic                     cube_q;

  logic [3:0] deg_d;
  always_comb begin
    deg_d = req_uop.ins.imm[3:0];
    if (int'(deg_d) > LANES - 1) deg_d = 4'(LANES - 1);
  end

  // ---- FMA array ------------------------------------------------------------------
  logic               a_iv, a_ir, a_ov, a_or;
  logic [2:0]         a_op;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(a_op), .rm(uop_q.rm),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  always_comb begin
    a_op = cube_q ? flux_pkg::FMA_FMUL : flux_pkg::FMA_FMADD;
    for (int l = 0; l < LANES; l++) begin
      a_a[l*W +: W] = acc_q[l];
      a_b[l*W +: W] = x_q[l];
      a_c[l*W +: W] = c_q[k_q];
    end
  end
  assign a_iv = (state == S_ISSUE);
  assign a_or = (state == S_WAIT);

  assign req_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
    end else begin
      case (state)
        S_IDLE: if (req_valid) begin
          if (req_uop.ins.opcode == flux_pkg::OP_VCUBE || deg_d != 4'd0) state <= S_ISSUE;
          else                                                 state <= S_RESP;
        end
        S_ISSUE: if (a_ir) state <= S_WAIT;
        S_WAIT:  if (a_ov) state <= (k_q == 4'd0) ? S_RESP : S_ISSUE;
        S_RESP:  if (rsp_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (req_valid) begin
        logic [flux_pkg::QW-1:0] qc;
        uop_q   <= req_uop;
        lmask_q <= req_lmask;
        cube_q  <= (req_uop.ins.opcode == flux_pkg::OP_VCUBE);
        deg_q   <= deg_d;
        qc = '0;
        for (int k = 0; k < LANES; k++) if (k <= int'(deg_d)) qc |= req_qb[k*flux_pkg::QW +: flux_pkg::QW];
        qc_q <= qc;
        for (int l = 0; l < LANES; l++) begin
          x_q[l]  <= req_a[l*W +: W];
          c_q[l]  <= req_b[l*W +: W];
          qx_q[l] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW];
          lf_q[l] <= '0;
          acc_q[l] <= (req_uop.ins.opcode == flux_pkg::OP_VCUBE) ? req_a[l*W +: W] : req_b[int'(deg_d)*W +: W];
        end
        k_q <= (req_uop.ins.opcode == flux_pkg::OP_VCUBE) ? 4'd1 : (deg_d - 4'd1);
      end
      S_WAIT: if (a_ov) begin
        for (int l = 0; l < LANES; l++) begin
          acc_q[l] <= a_res[l*W +: W];
          lf_q[l]  <= lf_q[l] | a_ff[l*5 +: 5];
        end
        if (k_q != 4'd0) k_q <= k_q - 4'd1;
      end
      default: ;
    endcase
  end

  // ---- response ------------------------------------------------------------------------
  always_comb begin
    rsp_fflags = '0;
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W] = acc_q[l];
      if (!cube_q && deg_q == 4'd0)
        rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qc_q | qual_of(acc_q[l], 5'b0);
      else
        rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qx_q[l] | (cube_q ? '0 : qc_q) | qual_of(acc_q[l], lf_q[l]);
      if (lmask_q[l]) rsp_fflags |= lf_q[l];
    end
  end
  assign rsp_valid  = (state == S_RESP);
  assign rsp_uop    = uop_q;
  assign rsp_wmask  = lmask_q;
  assign rsp_vm     = '0;
  assign rsp_faults = '0;
endmodule
