// =============================================================================
// Silica Flux -- exp(x)  (table-driven, Tang's method, fixed-point core)
// -----------------------------------------------------------------------------
//   1. range check:  |x| >= 2^IB  ->  +Inf (OF) or +0 (UF)
//   2. X  = round(x * 2^FX)                         fixed point, FX fraction bits
//   3. Y  = round(X * log2(e))   = k + f            k integer, f in [0,1)
//   4. j  = top SEG bits of f,  t = centred remainder, |t| <= 2^-(SEG+1)
//   5. 2^f = T[j] * P(t),  P = sum (t ln2)^i / i!   degree DEG, Horner
//   6. exp(x) = 2^k * 2^f    -> normalise / round-to-nearest-even
//
//                FX   IB   SEG  DEG   max error (measured)
//   FP32         34    7    5    3    0.507 ULP
//   FP64         64   10    6    6    0.499 ULP
//
// Every fixed-point product is rounded half-up exactly as the golden model
// (python/golden_model/sfu.py).  One signed multiplier is reused for all
// DEG+2 products: latency DEG+5 cycles; the unit accepts a new operand when
// idle (in_ready).  Subnormal results are produced (with UF) by the shared
// IEEE back end.  The rounding-mode operand is not used (RNE always).
// =============================================================================
module exp_unit #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23,
  parameter int TAG_W = 8
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic [EXP_W+MAN_W:0] a,
  input  logic [TAG_W-1:0]     in_tag,
  output logic                 out_valid,
  input  logic                 out_ready,
  output logic [EXP_W+MAN_W:0] result,
  output logic [4:0]           fflags,
  output logic [TAG_W-1:0]     out_tag,
  output logic                 busy
);
  `include "sfu_tables.svh"

  localparam bit IS64 = (EXP_W == 11);
  localparam int W    = EXP_W + MAN_W + 1;
  localparam int P    = MAN_W + 1;
  localparam int M    = MAN_W;
  localparam int EI_W = EXP_W + 4;
  localparam int FX   = IS64 ? 64 : 34;
  localparam int IB   = IS64 ? 10 : 7;
  localparam int LF   = IS64 ? 66 : 36;
  localparam int SEG  = IS64 ? 6 : 5;
  localparam int DEG  = IS64 ? 6 : 3;
  localparam int XW   = IB + FX + 2;
  localparam int AW   = FX + 3;
  localparam int MA   = (XW > AW) ? XW : AW;
  localparam int MB   = LF + 2;                 // >= FX+2 and >= FX-SEG+1
  localparam int PW   = MA + MB;
  localparam int PKW  = FX + 2;
  localparam int CW   = 4;
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};
  localparam logic [W-1:0] ONE  = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};
  localparam logic [W-1:0] PINF = {1'b0, {EXP_W{1'b1}}, {MAN_W{1'b0}}};

  localparam logic [79:0] SFU_L = IS64 ? SFU_FP64_EXP_L : SFU_FP32_EXP_L;
  localparam logic signed [PW-1:0] HALF_LF = PW'(1) <<< (LF - 1);
  localparam logic signed [PW-1:0] HALF_FX = PW'(1) <<< (FX - 1);

  typedef enum logic [2:0] {S_IDLE, S_MULL, S_HORNER, S_MULT, S_PACK, S_DONE} state_t;
  state_t state;

  function automatic logic [79:0] coef_a(input int i);
    coef_a = IS64 ? sfu_fp64_exp_a(i) : sfu_fp32_exp_a(i);
  endfunction
  function automatic logic [79:0] tab_t(input logic [SEG-1:0] j);
    tab_t = IS64 ? sfu_fp64_exp_t(6'(j)) : sfu_fp32_exp_t(5'(j));
  endfunction

  // ---------------------------------------------------------------------------
  // decode + fixed-point conversion
  // ---------------------------------------------------------------------------
  logic sa, za, ia, na, sna, suba, nrma;
  logic signed [EI_W-1:0] ea;
  logic [P-1:0] ma;
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ua (
    .x(a), .sign(sa), .exp(ea), .sig(ma), .is_zero(za), .is_sub(suba),
    .is_inf(ia), .is_nan(na), .is_snan(sna), .is_norm(nrma));

  logic                   big;
  logic signed [EI_W:0]   sh;
  logic [XW-1:0]          xmag;
  logic signed [XW-1:0]   x_fix;
  logic [P+1:0]           rsum;
  always_comb begin
    big  = nrma && (ea >= EI_W'(IB));
    sh   = (EI_W+1)'(ea) - (EI_W+1)'(M) + (EI_W+1)'(FX);
    xmag = '0;
    rsum = '0;
    if (sh >= 0) begin
      xmag = XW'(ma) << sh;
    end else if (-sh <= (EI_W+1)'(P + 1)) begin
      rsum = (P+2)'(ma) + ((P+2)'(1) << (-sh - 1));
      xmag = XW'(rsum) >> (-sh);
    end
    x_fix = sa ? -signed'(xmag) : signed'(xmag);
  end

  // ---------------------------------------------------------------------------
  // iteration state and shared multiplier
  // ---------------------------------------------------------------------------
  logic signed [XW-1:0]   x_q;
  logic signed [AW-1:0]   acc_q;
  logic signed [MB-1:0]   t_q;          // centred remainder (sign-extended)
  logic [SEG-1:0]         j_q;
  logic signed [EI_W-1:0] k_q;
  logic [CW-1:0]          i_q;
  logic [TAG_W-1:0]       tag_q;
  logic [W-1:0]           res_q;
  logic [4:0]             ff_q;
  logic [PKW-1:0]         mant_q;

  logic signed [MA-1:0]   mul_a;
  logic signed [MB-1:0]   mul_b;
  logic signed [PW-1:0]   prod;
  always_comb begin
    case (state)
      S_MULL:   begin mul_a = MA'(x_q);   mul_b = signed'(MB'(SFU_L[LF:0])); end
      S_HORNER: begin mul_a = MA'(acc_q); mul_b = t_q; end
      default:  begin mul_a = MA'(acc_q); mul_b = signed'(MB'(tab_t(j_q) & ((80'd1 << (FX + 1)) - 80'd1))); end
    endcase
    prod = PW'(mul_a) * PW'(mul_b);
  end


  logic signed [PW-1:0] y_full, h_full;
  logic signed [EI_W-1:0] k_d;
  logic [FX-1:0]          f_d;
  logic signed [MB-1:0]   t_d;
  assign y_full = (prod + HALF_LF) >>> LF;
  assign h_full = (prod + HALF_FX) >>> FX;
  assign k_d    = EI_W'(y_full >>> FX);
  assign f_d    = y_full[FX-1:0];
  assign t_d    = signed'(MB'({1'b0, f_d[FX-SEG-1:0]})) - (MB'(1) <<< (FX - SEG - 1));

  // ---------------------------------------------------------------------------
  // IEEE back end
  // ---------------------------------------------------------------------------
  logic [PKW-1:0]         n_sig;
  logic signed [EI_W-1:0] n_exp, pk_exp;
  logic                   n_st, n_tiny;
  logic [W-1:0]           r_res;
  logic [4:0]             r_ff;
  assign pk_exp = k_q + EI_W'(1);
  fp_normalize #(.EXP_W(EXP_W), .SW(PKW), .EI_W(EI_W)) u_norm (
    .sig_in(mant_q), .exp_in(pk_exp), .sig_out(n_sig), .exp_out(n_exp), .sticky(n_st), .tiny(n_tiny));
  fp_round #(.EXP_W(EXP_W), .MAN_W(MAN_W), .SW(PKW), .EI_W(EI_W)) u_round (
    .sign(1'b0), .sig(n_sig), .exp(n_exp), .sticky_in(1'b1), .tiny(n_tiny),
    .rm(3'd0), .result(r_res), .fflags(r_ff));

  assign in_ready  = (state == S_IDLE);
  assign busy      = (state != S_IDLE);
  assign out_valid = (state == S_DONE);
  assign result    = res_q;
  assign fflags    = ff_q;
  assign out_tag   = tag_q;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
    end else begin
      case (state)
        S_IDLE:   if (in_valid) state <= (na || ia || za || big) ? S_DONE : S_MULL;
        S_MULL:   state <= S_HORNER;
        S_HORNER: if (i_q == '0) state <= S_MULT;
        S_MULT:   state <= S_PACK;
        S_PACK:   state <= S_DONE;
        S_DONE:   if (out_ready) state <= S_IDLE;
        default:  state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (in_valid) begin
        x_q   <= x_fix;
        tag_q <= in_tag;
        if (na)      begin res_q <= QNAN; ff_q <= {sna, 4'b0000}; end
        else if (ia) begin res_q <= sa ? '0 : PINF; ff_q <= 5'b00000; end
        else if (za) begin res_q <= ONE;  ff_q <= 5'b00000; end
        else         begin res_q <= sa ? '0 : PINF; ff_q <= sa ? 5'b00011 : 5'b00101; end
      end
      S_MULL: begin
        k_q   <= k_d;
        j_q   <= f_d[FX-1 -: SEG];
        t_q   <= t_d;
        acc_q <= signed'(AW'(coef_a(DEG)));
        i_q   <= CW'(DEG - 1);
      end
      S_HORNER: begin
        acc_q <= AW'(h_full) + signed'(AW'(coef_a(int'(i_q))));
        if (i_q != '0) i_q <= i_q - CW'(1);
      end
      S_MULT: mant_q <= PKW'(h_full);
      S_PACK: begin
        res_q <= r_res;
        ff_q  <= r_ff;
      end
      default: ;
    endcase
  end
endmodule
