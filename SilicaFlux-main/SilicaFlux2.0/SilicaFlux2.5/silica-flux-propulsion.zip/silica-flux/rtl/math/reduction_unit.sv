// =============================================================================
// Silica Flux -- reduction engine
// -----------------------------------------------------------------------------
//   reduction_core   deterministic pairwise tree over the active lanes
//                    SUM / SUMSQ / DOT  : FP adds (optional per-lane product
//                                         pre-pass), one tree level per pass
//                    MIN / MAX / MAXABS : minimumNumber / maximumNumber nodes
//                    ARGMIN / ARGMAX    : (value, index) nodes, NaN loses,
//                                         ties keep the lower lane index
//                    A node with one inactive input forwards the other input
//                    unchanged, so the summation order -- and therefore the
//                    rounded result -- depends only on the lane mask.
//                    Pairwise summation bounds the rounding error growth to
//                    O(log2 LANES) ulp rather than O(LANES).
//   reduction_unit   FU_RED wrapper (VREDUCE): broadcasts the scalar result,
//                    OR-propagates quality of every active operand.
//
// The core is also instantiated inside the conservation checker and the
// objective engine.  Bit-exact reference: golden_model/engines.py tree_reduce.
// Latency: SUM ~ log2(LANES)*(L+2) cycles, MIN/MAX log2(LANES)+2 cycles.
// =============================================================================
module reduction_core #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               in_valid,
  output logic               in_ready,
  input  logic [3:0]         func,
  input  logic [2:0]         rm,
  input  logic [LANES*W-1:0] a,
  input  logic [LANES*W-1:0] b,
  input  logic [LANES-1:0]   valid,
  output logic               out_valid,
  input  logic               out_ready,
  output logic [W-1:0]       value,       // reduced value (MIN/MAX/SUM...)
  output logic [15:0]        index,       // ARG* lane index
  output logic               any,         // at least one active lane
  output logic [4:0]         fflags
);
  localparam int LV = $clog2(LANES);
  localparam int IW = (LV > 0) ? LV : 1;

  typedef enum logic [2:0] {S_IDLE, S_PRE_I, S_PRE_W, S_LVL_I, S_LVL_W, S_CMP, S_DONE} state_t;
  state_t state;

  logic [LANES-1:0][W-1:0]  v_q;
  logic [LANES-1:0]         ok_q;
  logic [LANES-1:0][IW-1:0] ix_q;
  logic [3:0]               func_q;
  logic [2:0]               rm_q;
  logic [4:0]               ff_q;
  logic [$clog2(LV+1)-1:0]  lvl_q;
  logic                     is_sum;
  assign is_sum = (func_q == flux_pkg::RED_SUM) || (func_q == flux_pkg::RED_SUMSQ) || (func_q == flux_pkg::RED_DOT);

  // ---- FMA array: products (all lanes) and level adds (first LANES/2) -------------
  logic               arr_iv, arr_ir, arr_ov, arr_or;
  logic [2:0]         arr_op;
  logic [LANES*W-1:0] arr_a, arr_b, arr_c, arr_res;
  logic [LANES*5-1:0] arr_ff;
  localparam logic [W-1:0] ONE = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(arr_iv), .in_ready(arr_ir), .op(arr_op), .rm(rm_q),
    .a(arr_a), .b(arr_b), .c(arr_c), .out_valid(arr_ov), .out_ready(arr_or), .res(arr_res), .ff(arr_ff));

  logic [LANES*W-1:0] b_q;
  always_comb begin
    arr_a = '0; arr_b = '0; arr_c = '0;
    arr_op = flux_pkg::FMA_FADD;
    if (state == S_PRE_I || state == S_PRE_W) begin
      arr_op = flux_pkg::FMA_FMUL;
      for (int l = 0; l < LANES; l++) begin
        arr_a[l*W +: W] = v_q[l];
        arr_b[l*W +: W] = (func_q == flux_pkg::RED_DOT) ? b_q[l*W +: W] : v_q[l];
      end
    end else begin
      for (int j = 0; j < LANES / 2; j++) begin
        arr_a[j*W +: W] = v_q[2*j];
        arr_b[j*W +: W] = ONE;
        arr_c[j*W +: W] = v_q[2*j+1];
      end
    end
  end
  assign arr_iv = (state == S_PRE_I) || (state == S_LVL_I);
  assign arr_or = (state == S_PRE_W) || (state == S_LVL_W);

  // ---- comparison nodes (MIN / MAX / ARG*) ------------------------------------------
  logic [LANES/2-1:0][W-1:0]  c_val;
  logic [LANES/2-1:0][IW-1:0] c_idx;
  logic [LANES/2-1:0]         c_nv;
  for (genvar j = 0; j < LANES / 2; j++) begin : g_cmp
    logic lt, le, eq, un, sn, b_better;
    logic [W-1:0] mn, mx;
    logic na_, nb_;
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_c (
      .a(v_q[2*j]), .b(v_q[2*j+1]), .lt(lt), .le(le), .eq(eq), .unordered(un), .snan(sn),
      .vmin(mn), .vmax(mx));
    logic lt_ba, le_ba, eq_ba, un_ba, sn_ba;
    logic [W-1:0] mn_ba, mx_ba;
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_c2 (
      .a(v_q[2*j+1]), .b(v_q[2*j]), .lt(lt_ba), .le(le_ba), .eq(eq_ba), .unordered(un_ba),
      .snan(sn_ba), .vmin(mn_ba), .vmax(mx_ba));
    assign na_ = (v_q[2*j][W-2:MAN_W] == '1) && (v_q[2*j][MAN_W-1:0] != '0);
    assign nb_ = (v_q[2*j+1][W-2:MAN_W] == '1) && (v_q[2*j+1][MAN_W-1:0] != '0);
    always_comb begin
      c_nv[j]  = 1'b0;
      c_idx[j] = ix_q[2*j];
      b_better = 1'b0;
      case (func_q)
        flux_pkg::RED_MIN:                begin c_val[j] = mn; c_nv[j] = sn; end
        flux_pkg::RED_MAX, flux_pkg::RED_MAXABS:    begin c_val[j] = mx; c_nv[j] = sn; end
        default: begin   // ARGMIN / ARGMAX
          if (na_ && !nb_)      b_better = 1'b1;
          else if (nb_)         b_better = 1'b0;
          else                  b_better = (func_q == flux_pkg::RED_ARGMAX) ? lt : lt_ba;
          c_val[j] = b_better ? v_q[2*j+1] : v_q[2*j];
          c_idx[j] = b_better ? ix_q[2*j+1] : ix_q[2*j];
        end
      endcase
    end
  end

  assign in_ready  = (state == S_IDLE);
  assign out_valid = (state == S_DONE);
  assign value     = v_q[0];
  assign index     = 16'(ix_q[0]);
  assign any       = ok_q[0];
  assign fflags    = ff_q;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
    end else begin
      case (state)
        S_IDLE: if (in_valid) begin
          if (LANES == 1)                                state <= S_DONE;
          else if (func == flux_pkg::RED_SUMSQ || func == flux_pkg::RED_DOT) state <= S_PRE_I;
          else if (func == flux_pkg::RED_SUM)                      state <= S_LVL_I;
          else                                           state <= S_CMP;
        end
        S_PRE_I: if (arr_ir) state <= S_PRE_W;
        S_PRE_W: if (arr_ov) state <= S_LVL_I;
        S_LVL_I: if (arr_ir) state <= S_LVL_W;
        S_LVL_W: if (arr_ov) state <= (lvl_q == ($clog2(LV+1))'(LV - 1)) ? S_DONE : S_LVL_I;
        S_CMP:   if (lvl_q == ($clog2(LV+1))'(LV - 1)) state <= S_DONE;
        S_DONE:  if (out_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (in_valid) begin
        func_q <= func;
        rm_q   <= rm;
        ff_q   <= '0;
        lvl_q  <= '0;
        b_q    <= b;
        ok_q   <= valid;
        for (int l = 0; l < LANES; l++) begin
          v_q[l]  <= (func == flux_pkg::RED_MAXABS) ? {1'b0, a[l*W +: W-1]} : a[l*W +: W];
          ix_q[l] <= IW'(l);
        end
      end
      S_PRE_W: if (arr_ov) begin
        logic [4:0] acc;
        acc = ff_q;
        for (int l = 0; l < LANES; l++) begin
          v_q[l] <= arr_res[l*W +: W];
          if (ok_q[l]) acc = acc | arr_ff[l*5 +: 5];
        end
        ff_q <= acc;
      end
      S_LVL_W: if (arr_ov) begin
        logic [4:0] acc;
        acc = ff_q;
        for (int j = 0; j < LANES / 2; j++) begin
          if (j >= (LANES >> (lvl_q + 1))) begin
            // node not live at this level
          end else if (ok_q[2*j] && ok_q[2*j+1]) begin
            v_q[j] <= arr_res[j*W +: W];
            acc    = acc | arr_ff[j*5 +: 5];
          end else if (ok_q[2*j+1]) begin
            v_q[j] <= v_q[2*j+1];
          end else begin
            v_q[j] <= v_q[2*j];
          end
          if (j < (LANES >> (lvl_q + 1))) ok_q[j] <= ok_q[2*j] | ok_q[2*j+1];
        end
        ff_q  <= acc;
        lvl_q <= lvl_q + 1'b1;
      end
      S_CMP: begin
        logic [4:0] acc;
        acc = ff_q;
        for (int j = 0; j < LANES / 2; j++) begin
          if (j >= (LANES >> (lvl_q + 1))) begin
            // node not live at this level
          end else if (ok_q[2*j] && ok_q[2*j+1]) begin
            v_q[j]  <= c_val[j];
            ix_q[j] <= c_idx[j];
            if (c_nv[j]) acc[flux_pkg::FF_NV] = 1'b1;
          end else if (ok_q[2*j+1]) begin
            v_q[j]  <= v_q[2*j+1];
            ix_q[j] <= ix_q[2*j+1];
          end else begin
            v_q[j]  <= v_q[2*j];
            ix_q[j] <= ix_q[2*j];
          end
          if (j < (LANES >> (lvl_q + 1))) ok_q[j] <= ok_q[2*j] | ok_q[2*j+1];
        end
        ff_q  <= acc;
        lvl_q <= lvl_q + 1'b1;
      end
      default: ;
    endcase
  end
endmodule

// -----------------------------------------------------------------------------
`include "flux_fu_if.svh"
module reduction_unit #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic clk,
  input  logic rst_n,
  `SF_FU_PORTS
);
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};

  logic         busy_q;
  flux_pkg::uop_t         uop_q;
  logic [LANES-1:0] lmask_q;
  logic [flux_pkg::QW-1:0] qin_q;
  logic         c_iv, c_ir, c_ov, c_or, c_any;
  logic [W-1:0] c_val;
  logic [15:0]  c_idx;
  logic [4:0]   c_ff;

  logic [3:0] u_func;
  logic [2:0] u_rm;
  assign u_func = req_uop.ins.func;
  assign u_rm   = req_uop.rm;
  assign req_ready = !busy_q && c_ir;
  assign c_iv      = req_valid && !busy_q;

  reduction_core #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_core (
    .clk(clk), .rst_n(rst_n), .in_valid(c_iv), .in_ready(c_ir), .func(u_func),
    .rm(u_rm), .a(req_a), .b(req_b), .valid(req_lmask),
    .out_valid(c_ov), .out_ready(c_or), .value(c_val), .index(c_idx), .any(c_any), .fflags(c_ff));

  always_ff @(posedge clk) begin
    if (!rst_n) busy_q <= 1'b0;
    else if (req_valid && req_ready) busy_q <= 1'b1;
    else if (rsp_valid && rsp_ready) busy_q <= 1'b0;
  end
  always_ff @(posedge clk) begin
    if (req_valid && req_ready) begin
      logic [flux_pkg::QW-1:0] q;
      q = '0;
      for (int l = 0; l < LANES; l++)
        if (req_lmask[l])
          q |= req_qa[l*flux_pkg::QW +: flux_pkg::QW] | ((req_uop.ins.func == flux_pkg::RED_DOT) ? req_qb[l*flux_pkg::QW +: flux_pkg::QW] : '0);
      uop_q   <= req_uop;
      lmask_q <= req_lmask;
      qin_q   <= q;
    end
  end

  logic is_arg;
  assign is_arg = (uop_q.ins.func == flux_pkg::RED_ARGMIN) || (uop_q.ins.func == flux_pkg::RED_ARGMAX);
  logic [W-1:0] idx_fp, res_v;
  fp_from_int #(.EXP_W(EXP_W), .MAN_W(MAN_W), .IW(17)) u_i2f (
    .v(c_any ? signed'({1'b0, c_idx}) : -17'sd1), .f(idx_fp));

  logic [flux_pkg::QW-1:0] q_out;
  always_comb begin
    res_v = is_arg ? idx_fp : (c_any ? c_val : '0);
    q_out = qin_q;
    if (!c_any) q_out[flux_pkg::Q_SUSPECT] = 1'b1;
    if (!is_arg) begin
      q_out[flux_pkg::Q_NAN] = q_out[flux_pkg::Q_NAN] | c_ff[flux_pkg::FF_NV] | ((res_v[W-2:MAN_W] == '1) && (res_v[MAN_W-1:0] != '0));
      q_out[flux_pkg::Q_OVF] = q_out[flux_pkg::Q_OVF] | c_ff[flux_pkg::FF_OF] | ((res_v[W-2:MAN_W] == '1) && (res_v[MAN_W-1:0] == '0));
      q_out[flux_pkg::Q_UNF] = q_out[flux_pkg::Q_UNF] | c_ff[flux_pkg::FF_UF];
    end
  end

  assign rsp_valid  = busy_q && c_ov;
  assign c_or       = rsp_ready && busy_q;
  assign rsp_uop    = uop_q;
  assign rsp_data   = {LANES{res_v}};
  assign rsp_qual   = {LANES{q_out}};
  assign rsp_wmask  = {LANES{1'b1}};
  assign rsp_vm     = '0;
  assign rsp_fflags = c_ff;
  assign rsp_faults = '0;
endmodule
