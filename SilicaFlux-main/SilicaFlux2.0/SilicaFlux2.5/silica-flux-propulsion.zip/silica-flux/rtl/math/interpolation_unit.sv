// =============================================================================
// Silica Flux -- table interpolation engine (FU_INTERP)
// -----------------------------------------------------------------------------
//   VINTERP vd, vs1, vs2, vs3
//     vs1  t   normalised table coordinate, t = (x - x0) / dx  (one VFMA)
//     vs2  y   table values y_0 .. y_{N-1}       (N = LANES breakpoints)
//     vs3  d   segment slopes d_i = y_{i+1} - y_i (precomputed on the host)
//
//   0 <= t < N-1   i = floor(t), f = t - i (exact), vd = fma(d_i, f, y_i)
//   t == N-1       vd = y_{N-1}
//   t < 0, t > N-1 vd = y_0 / y_{N-1}  and the lane is marked Q_SUSPECT:
//                  the engine never extrapolates silently.
//   t NaN          NaN result (quality Q_NAN).
//
// Each lane gathers its own segment from the table registers through an
// N:1 crossbar.  Two FMA passes; latency 2*(LATENCY+2)+2 cycles.
// =============================================================================
`include "flux_fu_if.svh"
module interpolation_unit #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic clk,
  input  logic rst_n,
  `SF_FU_PORTS
);
  `include "flux_q.svh"
  localparam int LW   = (LANES > 1) ? $clog2(LANES) : 1;
  localparam int BIAS = (1 << (EXP_W - 1)) - 1;

  typedef enum logic [2:0] {S_IDLE, S_I1, S_W1, S_I2, S_W2, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t                     uop_q;
  logic [LANES-1:0]         lmask_q;
  logic [LANES-1:0][W-1:0]  t_q, y_q, d_q, fr_q, r_q, ifp_q;
  logic [LANES-1:0][flux_pkg::QW-1:0] qt_q, qy_q, qd_q;
  logic [LANES-1:0][LW-1:0] i_q;
  logic [LANES-1:0]         clamp_q, susp_q;
  logic [LANES-1:0][4:0]    lf_q;

  // ---- per-lane classification at accept -------------------------------------------
  logic [W-1:0] nm1;
  fp_from_int #(.EXP_W(EXP_W), .MAN_W(MAN_W), .IW(17)) u_nm1 (.v(17'(LANES - 1)), .f(nm1));

  logic [LANES-1:0]         c_clamp, c_susp;
  logic [LANES-1:0][LW-1:0] c_idx;
  logic [LANES-1:0][W-1:0]  c_ifp;
  for (genvar l = 0; l < LANES; l++) begin : g_cls
    logic [W-1:0] t;
    logic lt0, le0, eq0, un0, sn0, ltn, len, eqn, unn, snn;
    logic [W-1:0] mn0, mx0, mnn, mxn;
    logic is_nan;
    logic signed [EXP_W+1:0] e;
    logic [MAN_W:0] sig;
    logic [LW:0]    fl;
    assign t = req_a[l*W +: W];
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_c0 (
      .a(t), .b({W{1'b0}}), .lt(lt0), .le(le0), .eq(eq0), .unordered(un0), .snan(sn0), .vmin(mn0), .vmax(mx0));
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_cn (
      .a(nm1), .b(t), .lt(ltn), .le(len), .eq(eqn), .unordered(unn), .snan(snn), .vmin(mnn), .vmax(mxn));
    assign is_nan = un0;
    assign e   = signed'({2'b00, t[W-2:MAN_W]}) - (EXP_W+2)'(BIAS);
    assign sig = {1'b1, t[MAN_W-1:0]};
    always_comb begin
      // floor(t) for 0 <= t < N-1 (exponent in [-?, LW])
      if (is_nan || t[W-2:MAN_W] == '0 || e < 0) fl = '0;
      else                                      fl = (LW+1)'(sig >> (MAN_W - int'(e)));
      if (fl > (LW+1)'(LANES - 2)) fl = (LW+1)'(LANES - 2);
      c_clamp[l] = !is_nan && (lt0 || ltn || eqn);
      c_susp[l]  = !is_nan && (lt0 || ltn);
      if (c_clamp[l]) c_idx[l] = lt0 ? '0 : LW'(LANES - 1);
      else            c_idx[l] = fl[LW-1:0];
    end
    fp_from_int #(.EXP_W(EXP_W), .MAN_W(MAN_W), .IW(17)) u_ifp (.v(17'(c_idx[l])), .f(c_ifp[l]));
  end

  // ---- FMA array ---------------------------------------------------------------------
  logic               a_iv, a_ir, a_ov, a_or;
  logic [2:0]         a_op;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  localparam logic [W-1:0] ONE = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(a_op), .rm(uop_q.rm),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  always_comb begin
    a_op = (state == S_I1 || state == S_W1) ? flux_pkg::FMA_FSUB : flux_pkg::FMA_FMADD;
    for (int l = 0; l < LANES; l++) begin
      if (state == S_I1 || state == S_W1) begin
        a_a[l*W +: W] = t_q[l];
        a_b[l*W +: W] = ONE;
        a_c[l*W +: W] = ifp_q[l];
      end else begin
        a_a[l*W +: W] = d_q[i_q[l]];
        a_b[l*W +: W] = fr_q[l];
        a_c[l*W +: W] = y_q[i_q[l]];
      end
    end
  end
  assign a_iv = (state == S_I1) || (state == S_I2);
  assign a_or = (state == S_W1) || (state == S_W2);
  assign req_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) state <= S_IDLE;
    else begin
      case (state)
        S_IDLE: if (req_valid) state <= S_I1;
        S_I1:   if (a_ir) state <= S_W1;
        S_W1:   if (a_ov) state <= S_I2;
        S_I2:   if (a_ir) state <= S_W2;
        S_W2:   if (a_ov) state <= S_RESP;
        S_RESP: if (rsp_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (req_valid) begin
        uop_q   <= req_uop;
        lmask_q <= req_lmask;
        clamp_q <= c_clamp;
        susp_q  <= c_susp;
        for (int l = 0; l < LANES; l++) begin
          t_q[l]   <= req_a[l*W +: W];
          y_q[l]   <= req_b[l*W +: W];
          d_q[l]   <= req_c[l*W +: W];
          qt_q[l]  <= req_qa[l*flux_pkg::QW +: flux_pkg::QW];
          qy_q[l]  <= req_qb[l*flux_pkg::QW +: flux_pkg::QW];
          qd_q[l]  <= req_qc[l*flux_pkg::QW +: flux_pkg::QW];
          i_q[l]   <= c_idx[l];
          ifp_q[l] <= c_ifp[l];
          lf_q[l]  <= '0;
        end
      end
      S_W1: if (a_ov) begin
        for (int l = 0; l < LANES; l++) begin
          fr_q[l] <= a_res[l*W +: W];
          lf_q[l] <= a_ff[l*5 +: 5];
        end
      end
      S_W2: if (a_ov) begin
        for (int l = 0; l < LANES; l++) begin
          r_q[l]  <= a_res[l*W +: W];
          lf_q[l] <= lf_q[l] | a_ff[l*5 +: 5];
        end
      end
      default: ;
    endcase
  end

  always_comb begin
    rsp_fflags = '0;
    for (int l = 0; l < LANES; l++) begin
      if (clamp_q[l]) begin
        rsp_data[l*W +: W]   = y_q[i_q[l]];
        rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qt_q[l] | qy_q[i_q[l]] | (susp_q[l] ? flux_pkg::QW'(1 << flux_pkg::Q_SUSPECT) : '0);
      end else begin
        rsp_data[l*W +: W]   = r_q[l];
        rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qt_q[l] | qy_q[i_q[l]] | qd_q[i_q[l]] | qual_of(r_q[l], lf_q[l]);
        if (lmask_q[l]) rsp_fflags |= lf_q[l];
      end
    end
  end
  assign rsp_valid  = (state == S_RESP);
  assign rsp_uop    = uop_q;
  assign rsp_wmask  = lmask_q;
  assign rsp_vm     = '0;
  assign rsp_faults = '0;
endmodule
