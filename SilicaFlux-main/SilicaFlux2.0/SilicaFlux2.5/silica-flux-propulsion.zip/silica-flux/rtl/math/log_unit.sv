// =============================================================================
// Silica Flux -- natural logarithm  (table-driven, cancellation-free near 1)
// -----------------------------------------------------------------------------
//   x = 2^e * m,  m in [1,2) split into 2^SEG segments with centre c_j.
//   log x = e ln2 + ln c_j + log(1 + u),   u = (m - c_j) / c_j   (u = t * R_j)
//   log(1+u) = u * Q(u),   Q(u) = sum (-1)^i u^i / (i+1)   (degree DEG, Horner)
//
//   The first segment is centred on c = 1 and the last on c = 2 (u computed
//   exactly, no multiply).  For x in [1-2^-(SEG+1), 1+2^-SEG) the constant
//   part e ln2 + ln c_j cancels *exactly* (B == 0) and the result u*Q(u) is
//   formed as a full-width product, i.e. in relative rather than absolute
//   precision -- so log(1 + tiny) keeps full accuracy.
//
//                F    SEG  DEG   max error (measured)
//   FP32         36    6    4    0.500 ULP
//   FP64         68    7    7    0.500 ULP
//
// Bit-exact with python/golden_model/sfu.py.  Latency DEG+5 cycles (interior
// segments) / DEG+4 (segments adjacent to 1).  Rounding: nearest-even.
// =============================================================================
module log_unit #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23,
  parameter int TAG_W = 8
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic [EXP_W+MAN_W:0] a,
  input  logic [TAG_W-1:0]     in_tag,
  output logic                 out_valid,
  input  logic                 out_ready,
  output logic [EXP_W+MAN_W:0] result,
  output logic [4:0]           fflags,
  output logic [TAG_W-1:0]     out_tag,
  output logic                 busy
);
  `include "sfu_tables.svh"

  localparam bit IS64 = (EXP_W == 11);
  localparam int W    = EXP_W + MAN_W + 1;
  localparam int P    = MAN_W + 1;
  localparam int M    = MAN_W;
  localparam int EI_W = EXP_W + 4;
  localparam int F    = IS64 ? 68 : 36;
  localparam int SEG  = IS64 ? 7 : 6;
  localparam int DEG  = IS64 ? 7 : 4;
  localparam int AW   = F + 3;                 // Horner accumulator (signed)
  localparam int MB   = F + 3;                 // second multiplier operand (signed)
  localparam int PW   = AW + MB;
  localparam int BW   = EI_W + F + 3;          // e*ln2 + L_j
  localparam int PKW  = 2 * F + 2;
  localparam int CW   = 4;
  localparam logic [W-1:0] QNAN = {1'b0, {EXP_W{1'b1}}, 1'b1, {(MAN_W-1){1'b0}}};
  localparam logic [W-1:0] PINF = {1'b0, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
  localparam logic [W-1:0] NINF = {1'b1, {EXP_W{1'b1}}, {MAN_W{1'b0}}};
  localparam logic [79:0]  LN2_80 = IS64 ? SFU_FP64_LOG_LN2 : SFU_FP32_LOG_LN2;
  localparam logic signed [PW-1:0] HALF_F = PW'(1) <<< (F - 1);

  function automatic logic [79:0] coef_q(input int i);
    coef_q = IS64 ? sfu_fp64_log_q(i) : sfu_fp32_log_q(i);
  endfunction
  function automatic logic [79:0] tab_l(input logic [SEG-1:0] j);
    tab_l = IS64 ? sfu_fp64_log_l(7'(j)) : sfu_fp32_log_l(6'(j));
  endfunction
  function automatic logic [79:0] tab_r(input logic [SEG-1:0] j);
    tab_r = IS64 ? sfu_fp64_log_r(7'(j)) : sfu_fp32_log_r(6'(j));
  endfunction

  typedef enum logic [2:0] {S_IDLE, S_MULU, S_HORNER, S_FINAL, S_PACK, S_DONE} state_t;
  state_t state;

  // ---------------------------------------------------------------------------
  // decode, segment selection, exact reductions
  // ---------------------------------------------------------------------------
  logic sa, za, ia, na, sna, suba, nrma;
  logic signed [EI_W-1:0] ea;
  logic [P-1:0] ma;
  fp_unpack #(.EXP_W(EXP_W), .MAN_W(MAN_W), .EI_W(EI_W)) u_ua (
    .x(a), .sign(sa), .exp(ea), .sig(ma), .is_zero(za), .is_sub(suba),
    .is_inf(ia), .is_nan(na), .is_snan(sna), .is_norm(nrma));
  localparam int LZW = $clog2(P + 1);
  logic [LZW-1:0] lz;
  logic           lz_z;
  sf_lzc #(.W(P)) u_lz (.in(ma), .cnt(lz), .zero(lz_z));

  logic [P-1:0]           mn;
  logic signed [EI_W-1:0] en;
  logic [SEG-1:0]         j_d;
  logic                   seg_lo, seg_hi, is_one;
  logic signed [MB-1:0]   mf_s, u_d, t_d;
  logic signed [BW-1:0]   b_d;
  logic [79:0]            ltab;
  always_comb begin
    mn     = ma << lz;
    en     = ea - EI_W'(signed'({1'b0, lz}));
    j_d    = mn[M-1 -: SEG];
    seg_lo = (j_d == '0);
    seg_hi = (j_d == '1);
    is_one = (mn == (P'(1) << M)) && (en == '0);
    mf_s   = signed'(MB'(mn) << (F - M));
    if (seg_lo)      u_d = mf_s - (MB'(1) <<< F);
    else if (seg_hi) u_d = (mf_s - (MB'(1) <<< (F + 1))) >>> 1;
    else             u_d = '0;
    t_d    = mf_s - ((MB'(1) <<< F) + (MB'({j_d, 1'b1}) <<< (F - SEG - 1)));
    ltab   = tab_l(j_d) & ((80'd1 << (F + 1)) - 80'd1);
    b_d    = BW'(en) * signed'(BW'(LN2_80[F:0])) + signed'(BW'(ltab));
  end

  // ---------------------------------------------------------------------------
  // iteration state, shared multiplier
  // ---------------------------------------------------------------------------
  logic signed [MB-1:0]   u_q, t_q;
  logic signed [AW-1:0]   acc_q;
  logic signed [BW-1:0]   b_q;
  logic [SEG-1:0]         j_q;
  logic [CW-1:0]          i_q;
  logic [TAG_W-1:0]       tag_q;
  logic [W-1:0]           res_q;
  logic [4:0]             ff_q;
  logic [PKW-1:0]         pk_q;
  logic signed [EI_W-1:0] pkexp_q;
  logic                   pksign_q;

  logic signed [AW-1:0] mul_a;
  logic signed [MB-1:0] mul_b;
  logic signed [PW-1:0] prod, prod_r, s_sum;
  always_comb begin
    if (state == S_MULU) begin
      mul_a = AW'(t_q);
      mul_b = signed'(MB'(tab_r(j_q) & ((80'd1 << (F + 1)) - 80'd1)));
    end else begin
      mul_a = acc_q;
      mul_b = u_q;
    end
    prod   = PW'(mul_a) * PW'(mul_b);
    prod_r = (prod + HALF_F) >>> F;
    s_sum  = PW'(b_q) + prod_r;
  end

  // ---------------------------------------------------------------------------
  // IEEE back end
  // ---------------------------------------------------------------------------
  logic [PKW-1:0]         n_sig;
  logic signed [EI_W-1:0] n_exp;
  logic                   n_st, n_tiny;
  logic [W-1:0]           r_res;
  logic [4:0]             r_ff;
  fp_normalize #(.EXP_W(EXP_W), .SW(PKW), .EI_W(EI_W)) u_norm (
    .sig_in(pk_q), .exp_in(pkexp_q), .sig_out(n_sig), .exp_out(n_exp), .sticky(n_st), .tiny(n_tiny));
  fp_round #(.EXP_W(EXP_W), .MAN_W(MAN_W), .SW(PKW), .EI_W(EI_W)) u_round (
    .sign(pksign_q), .sig(n_sig), .exp(n_exp), .sticky_in(1'b1), .tiny(n_tiny),
    .rm(3'd0), .result(r_res), .fflags(r_ff));

  assign in_ready  = (state == S_IDLE);
  assign busy      = (state != S_IDLE);
  assign out_valid = (state == S_DONE);
  assign result    = res_q;
  assign fflags    = ff_q;
  assign out_tag   = tag_q;

  logic special_d;
  assign special_d = na || za || sa || ia || is_one;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
    end else begin
      case (state)
        S_IDLE:   if (in_valid) state <= special_d ? S_DONE : ((seg_lo || seg_hi) ? S_HORNER : S_MULU);
        S_MULU:   state <= S_HORNER;
        S_HORNER: if (i_q == '0) state <= S_FINAL;
        S_FINAL:  state <= S_PACK;
        S_PACK:   state <= S_DONE;
        S_DONE:   if (out_ready) state <= S_IDLE;
        default:  state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (in_valid) begin
        u_q   <= u_d;
        t_q   <= t_d;
        b_q   <= b_d;
        j_q   <= j_d;
        acc_q <= signed'(AW'(coef_q(DEG)));
        i_q   <= CW'(DEG - 1);
        tag_q <= in_tag;
        if (na)          begin res_q <= QNAN; ff_q <= {sna, 4'b0000}; end
        else if (za)     begin res_q <= NINF; ff_q <= 5'b01000; end        // DZ
        else if (sa)     begin res_q <= QNAN; ff_q <= 5'b10000; end        // NV
        else if (ia)     begin res_q <= PINF; ff_q <= 5'b00000; end
        else             begin res_q <= '0;   ff_q <= 5'b00000; end        // log(1) = +0
      end
      S_MULU: u_q <= MB'(prod_r);
      S_HORNER: begin
        acc_q <= AW'(prod_r) + signed'(AW'(coef_q(int'(i_q))));
        if (i_q != '0) i_q <= i_q - CW'(1);
      end
      S_FINAL: begin
        if (b_q == '0) begin
          pk_q     <= PKW'(prod[PW-1] ? -prod : prod);
          pkexp_q  <= EI_W'(PKW - 1 - 2 * F);
          pksign_q <= prod[PW-1];
        end else begin
          pk_q     <= PKW'(s_sum[PW-1] ? -s_sum : s_sum);
          pkexp_q  <= EI_W'(PKW - 1 - F);
          pksign_q <= s_sum[PW-1];
        end
      end
      S_PACK: begin
        res_q <= r_res;
        ff_q  <= r_ff;
      end
      default: ;
    endcase
  end
endmodule
