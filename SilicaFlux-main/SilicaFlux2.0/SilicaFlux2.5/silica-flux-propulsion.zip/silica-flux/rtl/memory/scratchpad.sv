// =============================================================================
// Silica Flux -- scratchpad memory
// -----------------------------------------------------------------------------
// General-purpose row memory for kernel temporaries (stage vectors,
// intermediate fields, spill space).  Size = SCRATCHPAD_SIZE rows, a top-level
// synthesis parameter.  Deterministic single-cycle access; no caching.
// =============================================================================
module scratchpad #(
  parameter int ROWS  = 256,
  parameter int LANES = 8,
  parameter int EW    = 36,
  parameter int AW    = (ROWS > 1) ? $clog2(ROWS) : 1
) (
  input  logic                clk,
  input  logic                en,
  input  logic                we,
  input  logic [AW-1:0]       addr,
  input  logic [LANES-1:0]    wmask,
  input  logic                inject,
  input  logic [LANES*EW-1:0] wdata,
  output logic [LANES*EW-1:0] rdata,
  output logic [LANES-1:0]    perr
);
  sf_row_ram #(.ROWS(ROWS), .LANES(LANES), .EW(EW)) u_ram (
    .clk(clk), .en(en), .we(we), .addr(addr), .wmask(wmask), .inject(inject),
    .wdata(wdata), .rdata(rdata), .perr(perr));
endmodule
