// =============================================================================
// Silica Flux -- DMA engine
// -----------------------------------------------------------------------------
//   DIR 0  S2M  AXI-Stream in  -> memory    one element per beat; TDATA[W-1:0]
//                                           = value, TUSER[3:0] = quality
//   DIR 1  M2S  memory -> AXI-Stream out    one element per beat; TUSER =
//                                           {parity_err, 3'b0, quality}, TLAST
//                                           on the final element
//   DIR 2  S2T  AXI-Stream in  -> telemetry ingest (LEN packets of 3 beats)
// Element i of a transfer maps to row ROW + i / LANES, lane i % LANES.
// Errors (illegal address, aborted transfer) set STATUS.error; stalls are
// timed out by the watchdog (F_TIMEOUT) through the abort input.
// =============================================================================
module dma_engine #(
  parameter int LANES = 8,
  parameter int W     = 32
) (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              start,
  input  logic [1:0]                        dir,
  input  logic [2:0]                        mem_id,
  input  logic [15:0]                       row0,
  input  logic [31:0]                       len,
  input  logic                              abort,
  output logic                              busy,
  output logic                              done,
  output logic                              error,
  output logic [31:0]                       count,
  output logic                              activity,
  // stream in
  input  logic                              s_valid,
  output logic                              s_ready,
  input  logic [63:0]                       s_data,
  input  logic [7:0]                        s_user,
  input  logic                              s_last,
  // stream out
  output logic                              m_valid,
  input  logic                              m_ready,
  output logic [63:0]                       m_data,
  output logic [7:0]                        m_user,
  output logic                              m_last,
  // telemetry path
  output logic                              t_valid,
  input  logic                              t_ready,
  output logic [63:0]                       t_data,
  output logic                              t_last,
  // bus master
  output logic                              req_valid,
  input  logic                              req_ready,
  output logic                              req_we,
  output logic [2:0]                        req_id,
  output logic [15:0]                       req_row,
  output logic [LANES-1:0]                  req_wmask,
  output logic [LANES*(W+flux_pkg::QW)-1:0] req_wdata,
  input  logic                              rsp_valid,
  input  logic [LANES*(W+flux_pkg::QW)-1:0] rsp_rdata,
  input  logic                              rsp_err_addr,
  input  logic [LANES-1:0]                  rsp_err_parity
);
  localparam int EW = W + flux_pkg::QW;
  localparam int LW = (LANES > 1) ? $clog2(LANES) : 1;

  typedef enum logic [2:0] {D_IDLE, D_S2M_BEAT, D_S2M_REQ, D_S2M_WAIT, D_M2S_REQ, D_M2S_WAIT,
                            D_M2S_EMIT, D_S2T} state_t;
  state_t st;

  logic [31:0]         idx_q, len_q;
  logic [2:0]          mem_q;
  logic [15:0]         row0_q;
  logic [W-1:0]        val_q;
  logic [flux_pkg::QW-1:0]       q_q;
  logic [LANES*EW-1:0] rowbuf_q;
  logic [LANES-1:0]    perr_q;

  logic [15:0]   cur_row;
  logic [LW-1:0] cur_lane;
  assign cur_row  = row0_q + 16'(idx_q >> LW);
  assign cur_lane = idx_q[LW-1:0];

  assign busy     = (st != D_IDLE);
  assign count    = idx_q;
  assign s_ready  = (st == D_S2M_BEAT) || ((st == D_S2T) && t_ready);
  assign t_valid  = (st == D_S2T) && s_valid;
  assign t_data   = s_data;
  assign t_last   = s_last;
  assign activity = (s_valid && s_ready) || (m_valid && m_ready) || rsp_valid;

  assign req_valid = (st == D_S2M_REQ) || (st == D_M2S_REQ);
  assign req_we    = (st == D_S2M_REQ);
  assign req_id    = mem_q;
  assign req_row   = cur_row;
  always_comb begin
    req_wmask = '0;
    req_wmask[cur_lane] = 1'b1;
    for (int l = 0; l < LANES; l++) req_wdata[l*EW +: EW] = {q_q, val_q};
  end

  assign m_valid = (st == D_M2S_EMIT);
  assign m_data  = 64'(rowbuf_q[cur_lane*EW +: W]);
  assign m_user  = {perr_q[cur_lane], 3'b000, rowbuf_q[cur_lane*EW + W +: flux_pkg::QW]};
  assign m_last  = (idx_q + 32'd1 >= len_q);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st    <= D_IDLE;
      done  <= 1'b0;
      error <= 1'b0;
      idx_q <= '0;
    end else if (abort && st != D_IDLE) begin
      st    <= D_IDLE;
      error <= 1'b1;
      done  <= 1'b1;
    end else begin
      case (st)
        D_IDLE: if (start) begin
          idx_q  <= '0;
          len_q  <= len;
          mem_q  <= mem_id;
          row0_q <= row0;
          done   <= 1'b0;
          error  <= 1'b0;
          if (len == 32'd0) begin
            done <= 1'b1;
          end else begin
            case (dir)
              2'd0:    st <= D_S2M_BEAT;
              2'd1:    st <= D_M2S_REQ;
              default: begin st <= D_S2T; len_q <= len * 32'd3; end
            endcase
          end
        end
        D_S2M_BEAT: if (s_valid) begin
          val_q <= s_data[W-1:0];
          q_q   <= s_user[flux_pkg::QW-1:0];
          st    <= D_S2M_REQ;
        end
        D_S2M_REQ:  if (req_ready) st <= D_S2M_WAIT;
        D_S2M_WAIT: if (rsp_valid) begin
          if (rsp_err_addr) begin
            error <= 1'b1; done <= 1'b1; st <= D_IDLE;
          end else if (idx_q + 32'd1 >= len_q) begin
            idx_q <= idx_q + 32'd1; done <= 1'b1; st <= D_IDLE;
          end else begin
            idx_q <= idx_q + 32'd1; st <= D_S2M_BEAT;
          end
        end
        D_M2S_REQ:  if (req_ready) st <= D_M2S_WAIT;
        D_M2S_WAIT: if (rsp_valid) begin
          if (rsp_err_addr) begin
            error <= 1'b1; done <= 1'b1; st <= D_IDLE;
          end else begin
            rowbuf_q <= rsp_rdata;
            perr_q   <= rsp_err_parity;
            st       <= D_M2S_EMIT;
          end
        end
        D_M2S_EMIT: if (m_ready) begin
          idx_q <= idx_q + 32'd1;
          if (idx_q + 32'd1 >= len_q) begin
            done <= 1'b1; st <= D_IDLE;
          end else if (cur_lane == LW'(LANES - 1)) begin
            st <= D_M2S_REQ;
          end
        end
        D_S2T: if (s_valid && t_ready) begin
          idx_q <= idx_q + 32'd1;
          if (idx_q + 32'd1 >= len_q) begin done <= 1'b1; st <= D_IDLE; end
        end
        default: st <= D_IDLE;
      endcase
    end
  end
endmodule
