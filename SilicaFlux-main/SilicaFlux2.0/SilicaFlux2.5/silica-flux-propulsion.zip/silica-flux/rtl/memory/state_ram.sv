// =============================================================================
// Silica Flux -- state memory (ping-pong)
// -----------------------------------------------------------------------------
// Two banks hold x_n and x_{n+1}.  The core addresses them as MEM_STATE
// (current) and MEM_STATE_N (next); BARRIER func=SWAP exchanges the roles in
// one cycle, so a timestep reads one bank while writing the other and no
// state vector is ever partially overwritten.
// =============================================================================
module state_ram #(
  parameter int ROWS  = 64,
  parameter int LANES = 8,
  parameter int EW    = 36,
  parameter int AW    = (ROWS > 1) ? $clog2(ROWS) : 1
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic                swap,
  output logic                bank_sel,
  input  logic                en,
  input  logic                next_bank,     // 0: MEM_STATE, 1: MEM_STATE_N
  input  logic                we,
  input  logic [AW-1:0]       addr,
  input  logic [LANES-1:0]    wmask,
  input  logic                inject,
  input  logic [LANES*EW-1:0] wdata,
  output logic [LANES*EW-1:0] rdata,
  output logic [LANES-1:0]    perr
);
  logic sel_q, rd_bank_q;
  logic [LANES*EW-1:0] rd0, rd1;
  logic [LANES-1:0]    pe0, pe1;
  logic                bank;
  assign bank = sel_q ^ next_bank;
  always_ff @(posedge clk) begin
    if (!rst_n) sel_q <= 1'b0;
    else if (swap) sel_q <= !sel_q;
    if (en && !we) rd_bank_q <= bank;
  end
  sf_row_ram #(.ROWS(ROWS), .LANES(LANES), .EW(EW)) u_b0 (
    .clk(clk), .en(en && !bank), .we(we), .addr(addr), .wmask(wmask), .inject(inject),
    .wdata(wdata), .rdata(rd0), .perr(pe0));
  sf_row_ram #(.ROWS(ROWS), .LANES(LANES), .EW(EW)) u_b1 (
    .clk(clk), .en(en && bank), .we(we), .addr(addr), .wmask(wmask), .inject(inject),
    .wdata(wdata), .rdata(rd1), .perr(pe1));
  assign rdata    = rd_bank_q ? rd1 : rd0;
  assign perr     = rd_bank_q ? pe1 : pe0;
  assign bank_sel = sel_q;
endmodule
