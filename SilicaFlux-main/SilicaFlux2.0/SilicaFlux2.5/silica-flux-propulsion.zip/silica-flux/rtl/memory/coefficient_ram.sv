// =============================================================================
// Silica Flux -- coefficient / parameter memory
// -----------------------------------------------------------------------------
// Read-mostly storage for model coefficients, interpolation tables, objective
// weights, constraint bounds and parameter sets (two instances: MEM_COEFF and
// MEM_PARAM).  Written by the host (window or DMA) and by VSTORE; every element
// keeps its quality bits so a coefficient loaded from suspect data stays
// suspect.  A write counter supports host-side configuration auditing.
// =============================================================================
module coefficient_ram #(
  parameter int ROWS  = 64,
  parameter int LANES = 8,
  parameter int EW    = 36,
  parameter int AW    = (ROWS > 1) ? $clog2(ROWS) : 1
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic                en,
  input  logic                we,
  input  logic [AW-1:0]       addr,
  input  logic [LANES-1:0]    wmask,
  input  logic                inject,
  input  logic [LANES*EW-1:0] wdata,
  output logic [LANES*EW-1:0] rdata,
  output logic [LANES-1:0]    perr,
  output logic [31:0]         writes
);
  sf_row_ram #(.ROWS(ROWS), .LANES(LANES), .EW(EW)) u_ram (
    .clk(clk), .en(en), .we(we), .addr(addr), .wmask(wmask), .inject(inject),
    .wdata(wdata), .rdata(rdata), .perr(perr));
  always_ff @(posedge clk) begin
    if (!rst_n) writes <= '0;
    else if (en && we) writes <= writes + 32'd1;
  end
endmodule
