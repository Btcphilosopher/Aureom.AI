// =============================================================================
// Silica Flux -- result memory
// -----------------------------------------------------------------------------
// Destination of VSTORE results (new state, derivatives, objectives, margins,
// residuals, diagnostics) read back by the host window or streamed out by
// DMA with the per-element quality bits in TUSER.  Tracks the number of row
// writes and the highest row written (result-buffer high-water mark).
// =============================================================================
module result_ram #(
  parameter int ROWS  = 64,
  parameter int LANES = 8,
  parameter int EW    = 36,
  parameter int AW    = (ROWS > 1) ? $clog2(ROWS) : 1
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic                en,
  input  logic                we,
  input  logic [AW-1:0]       addr,
  input  logic [LANES-1:0]    wmask,
  input  logic                inject,
  input  logic [LANES*EW-1:0] wdata,
  output logic [LANES*EW-1:0] rdata,
  output logic [LANES-1:0]    perr,
  output logic [31:0]         writes,
  output logic [AW:0]         high_water
);
  sf_row_ram #(.ROWS(ROWS), .LANES(LANES), .EW(EW)) u_ram (
    .clk(clk), .en(en), .we(we), .addr(addr), .wmask(wmask), .inject(inject),
    .wdata(wdata), .rdata(rdata), .perr(perr));
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      writes     <= '0;
      high_water <= '0;
    end else if (en && we) begin
      writes <= writes + 32'd1;
      if ((AW+1)'(addr) + 1'b1 > high_water) high_water <= (AW+1)'(addr) + 1'b1;
    end
  end
endmodule
