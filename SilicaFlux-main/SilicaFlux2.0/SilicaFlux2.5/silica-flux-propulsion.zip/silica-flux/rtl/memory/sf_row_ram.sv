// =============================================================================
// Silica Flux -- row-organised single-port SRAM with lane write enables
// -----------------------------------------------------------------------------
// One row = LANES elements, so a vector load/store is one access.  Read data
// is registered (synchronous, 1 cycle) -- maps to FPGA block RAM / ASIC SRAM
// macros with byte-lane (here element-lane) write enables.  Parity is added on
// write and checked on read by the wrapper.
// =============================================================================
module sf_row_ram #(
  parameter int ROWS  = 64,
  parameter int LANES = 8,
  parameter int EW    = 36,
  parameter int AW    = (ROWS > 1) ? $clog2(ROWS) : 1
) (
  input  logic                      clk,
  input  logic                      en,
  input  logic                      we,
  input  logic [AW-1:0]             addr,
  input  logic [LANES-1:0]          wmask,
  input  logic                      inject,
  input  logic [LANES*EW-1:0]       wdata,
  output logic [LANES*EW-1:0]       rdata,
  output logic [LANES-1:0]          perr
);
  logic [LANES*(EW+1)-1:0] mem [ROWS];
  logic [LANES*(EW+1)-1:0] wp, rq;
`ifndef SYNTHESIS
  initial for (int r = 0; r < ROWS; r++) mem[r] = '0;
`endif
  parity_gen #(.LANES(LANES), .EW(EW)) u_pg (.din(wdata), .inject(inject), .dout(wp));
  always_ff @(posedge clk) begin
    if (en && we) begin
      for (int l = 0; l < LANES; l++)
        if (wmask[l]) mem[addr][l*(EW+1) +: EW+1] <= wp[l*(EW+1) +: EW+1];
    end
    if (en && !we) rq <= mem[addr];
  end
  parity_checker #(.LANES(LANES), .EW(EW)) u_pc (.din(rq), .dout(rdata), .err(perr));
endmodule
