// =============================================================================
// Silica Flux -- multi-channel watchdog / timeout detector
// -----------------------------------------------------------------------------
// Channel c counts cycles while enable[c] is high and kick[c] is low; reaching
// limit[c] (non-zero) raises expired[c] for one cycle and latches
// tripped[c] until the channel is kicked or disabled.  Channels used:
//   0  core progress   (no issue / retire while running)  -> F_WATCHDOG
//   1  DMA stream      (no beat while a transfer is busy)  -> F_TIMEOUT
//   2  host window     (bus grant starvation)              -> F_TIMEOUT
// =============================================================================
module watchdog #(
  parameter int N = 3
) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic [N-1:0]     enable,
  input  logic [N-1:0]     kick,
  input  logic [N*32-1:0]  limit,
  output logic [N-1:0]     expired,
  output logic [N-1:0]     tripped
);
  logic [N-1:0][31:0] cnt;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      cnt     <= '0;
      tripped <= '0;
      expired <= '0;
    end else begin
      for (int c = 0; c < N; c++) begin
        expired[c] <= 1'b0;
        if (!enable[c] || kick[c] || limit[c*32 +: 32] == '0) begin
          cnt[c]     <= '0;
          tripped[c] <= 1'b0;
        end else if (!tripped[c]) begin
          if (cnt[c] + 32'd1 >= limit[c*32 +: 32]) begin
            expired[c] <= 1'b1;
            tripped[c] <= 1'b1;
          end
          cnt[c] <= cnt[c] + 32'd1;
        end
      end
    end
  end
endmodule
