// =============================================================================
// Silica Flux -- fault manager
// -----------------------------------------------------------------------------
// Aggregates every fault source in the fabric into one observable state:
//   status    sticky, write-1-to-clear, gated by the enable mask
//   first     identity, PC and timestamp of the first fault since clear
//   count     number of fault events
//   halt_req  status & halt_mask != 0: the core stops issuing and drains
//   irq       fault interrupt
// Numerical exceptions are never recovered silently: they are recorded here
// whether or not they halt the fabric.  F_HOST lets the host inject a fault
// to test the reporting path end to end.
// =============================================================================
module fault_manager #(
  parameter int NSRC = 4
) (
  input  logic                                 clk,
  input  logic                                 rst_n,
  input  logic [NSRC-1:0]                      src_valid,
  input  logic [NSRC-1:0][flux_pkg::FAULT_W-1:0] src_bits,
  input  logic [NSRC-1:0][15:0]                src_pc,
  input  logic [31:0]                          tstamp,
  input  logic [flux_pkg::FAULT_W-1:0]         enable,
  input  logic [flux_pkg::FAULT_W-1:0]         halt_mask,
  input  logic                                 clr_we,
  input  logic [flux_pkg::FAULT_W-1:0]         clr_bits,
  output logic [flux_pkg::FAULT_W-1:0]         status,
  output logic                                 first_valid,
  output logic [4:0]                           first_id,
  output logic [15:0]                          first_pc,
  output logic [31:0]                          first_time,
  output logic [31:0]                          count,
  output logic                                 halt_req,
  output logic                                 irq
);
  logic [flux_pkg::FAULT_W-1:0] ev;
  logic [15:0]        ev_pc;
  logic               ev_any;
  always_comb begin
    ev     = '0;
    ev_pc  = '0;
    ev_any = 1'b0;
    for (int s = NSRC - 1; s >= 0; s--) begin
      if (src_valid[s] && ((src_bits[s] & enable) != '0)) begin
        ev     = ev | (src_bits[s] & enable);
        ev_pc  = src_pc[s];
        ev_any = 1'b1;
      end
    end
  end
  function automatic logic [4:0] lowest(input logic [flux_pkg::FAULT_W-1:0] v);
    logic found;
    lowest = 5'd0;
    found  = 1'b0;
    for (int i = 0; i < flux_pkg::FAULT_W; i++) if (v[i] && !found) begin lowest = 5'(i); found = 1'b1; end
  endfunction
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      status      <= '0;
      first_valid <= 1'b0;
      first_id    <= '0;
      first_pc    <= '0;
      first_time  <= '0;
      count       <= '0;
    end else begin
      status <= (status & ~(clr_we ? clr_bits : '0)) | ev;
      if (ev_any) count <= count + 32'd1;
      if (ev_any && (!first_valid || (clr_we && (status & ~clr_bits) == '0))) begin
        first_valid <= 1'b1;
        first_id    <= lowest(ev);
        first_pc    <= ev_pc;
        first_time  <= tstamp;
      end else if (clr_we && (status & ~clr_bits) == '0) begin
        first_valid <= 1'b0;
      end
    end
  end
  assign halt_req = (status & halt_mask) != '0;
  assign irq      = (status != '0);

`ifdef SF_SVA
  // a fault is never lost: an enabled event is visible in status next cycle
  a_sticky: assert property (@(posedge clk) disable iff (!rst_n) ev_any |=> ((status & $past(ev)) == $past(ev)));
`endif
endmodule
