// =============================================================================
// Silica Flux -- floating-point range checker
// -----------------------------------------------------------------------------
// lo <= x <= hi with IEEE comparison semantics.  NaN is never in range.  An
// infinite bound disables that side.  Used on every telemetry sample (per
// channel bounds) before it can reach the compute fabric.
// =============================================================================
module range_checker #(
  parameter int EXP_W = 8,
  parameter int MAN_W = 23
) (
  input  logic [EXP_W+MAN_W:0] x,
  input  logic [EXP_W+MAN_W:0] lo,
  input  logic [EXP_W+MAN_W:0] hi,
  output logic                 in_range,
  output logic                 is_nan
);
  logic l_lt, l_le, l_eq, l_un, l_sn, h_lt, h_le, h_eq, h_un, h_sn;
  logic [EXP_W+MAN_W:0] m0, m1, m2, m3;
  fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_lo (
    .a(lo), .b(x), .lt(l_lt), .le(l_le), .eq(l_eq), .unordered(l_un), .snan(l_sn), .vmin(m0), .vmax(m1));
  fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_hi (
    .a(x), .b(hi), .lt(h_lt), .le(h_le), .eq(h_eq), .unordered(h_un), .snan(h_sn), .vmin(m2), .vmax(m3));
  assign is_nan   = (x[EXP_W+MAN_W-1:MAN_W] == '1) && (x[MAN_W-1:0] != '0);
  assign in_range = l_le && h_le;
endmodule
