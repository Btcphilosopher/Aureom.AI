// =============================================================================
// Silica Flux -- per-element parity generation and checking
// -----------------------------------------------------------------------------
// Every memory element is stored as {parity, quality[3:0], data[W-1:0]} with
// even parity over quality and data.  parity_gen produces the stored word,
// parity_checker strips and verifies it on read.  A single injection input
// flips the parity of lane 0 on the next write (fault-injection test hook,
// synthesizable, controlled from the CTRL register).
// =============================================================================
module parity_gen #(
  parameter int LANES = 8,
  parameter int EW    = 36            // data + quality bits per element
) (
  input  logic [LANES*EW-1:0]     din,
  input  logic                    inject,
  output logic [LANES*(EW+1)-1:0] dout
);
  always_comb begin
    for (int l = 0; l < LANES; l++)
      dout[l*(EW+1) +: EW+1] = {(^din[l*EW +: EW]) ^ (inject && l == 0), din[l*EW +: EW]};
  end
endmodule

module parity_checker #(
  parameter int LANES = 8,
  parameter int EW    = 36
) (
  input  logic [LANES*(EW+1)-1:0] din,
  output logic [LANES*EW-1:0]     dout,
  output logic [LANES-1:0]        err
);
  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      dout[l*EW +: EW] = din[l*(EW+1) +: EW];
      err[l]           = ^din[l*(EW+1) +: EW+1];
    end
  end
endmodule
