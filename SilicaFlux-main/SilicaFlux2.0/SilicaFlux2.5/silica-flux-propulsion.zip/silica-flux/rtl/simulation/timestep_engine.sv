// =============================================================================
// Silica Flux -- timestep engine
// -----------------------------------------------------------------------------
// Scalar control for explicit Runge-Kutta integration:
//   * holds dt, simulated time t and the step counter;
//   * selects a Butcher tableau: EULER, HEUN, MIDPOINT, RALSTON, RK4 (ROM) or
//     CUSTOM (host-programmed, up to 4 stages);
//   * pre-scales the tableau by dt once per configuration
//         ca[i][j] = dt * A[i][j],   cb[j] = dt * b[j]       (RNE)
//     so every stage combination is a pure FMA chain;
//   * validates dt: finite and > 0, otherwise F_STEP and the engine refuses
//     to integrate (STATE_UPDATE returns x0 marked Q_SUSPECT);
//   * commits a step: t <- t + dt (RNE), step <- step + 1.
//
// The engine contains no model physics: the derivative f(x, u, p) is computed
// by the host-supplied instruction program between STATE_UPDATE stages.
// =============================================================================
module timestep_engine #(
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic             clk,
  input  logic             rst_n,
  // configuration request (TSCFG)
  input  logic             cfg_valid,
  output logic             cfg_ready,
  input  logic [3:0]       cfg_func,
  input  logic [W-1:0]     cfg_dt,
  output logic             cfg_done,     // pulse
  output logic             cfg_fault,    // with cfg_done: invalid dt
  // step commit
  input  logic             commit_valid,
  output logic             commit_done,  // pulse
  // host-programmed custom tableau
  input  logic [2:0]       custom_stages,
  input  logic [6*W-1:0]   custom_a,     // slots (1,0)(2,0)(2,1)(3,0)(3,1)(3,2)
  input  logic [4*W-1:0]   custom_b,
  // state
  output logic [2:0]       stages,
  output logic [6*W-1:0]   ca,
  output logic [4*W-1:0]   cb,
  output logic             ts_valid,
  output logic [W-1:0]     t_now,
  output logic [W-1:0]     dt_now,
  output logic [31:0]      step_count
);
  localparam bit IS64 = (EXP_W == 11);
  // FP constants (exactly rounded, see golden_model/engines.py frac_to_fp)
  localparam logic [W-1:0] C_ONE  = IS64 ? W'(64'h3ff0000000000000) : W'(32'h3f800000);
  localparam logic [W-1:0] C_HALF = IS64 ? W'(64'h3fe0000000000000) : W'(32'h3f000000);
  localparam logic [W-1:0] C_2_3  = IS64 ? W'(64'h3fe5555555555555) : W'(32'h3f2aaaab);
  localparam logic [W-1:0] C_1_4  = IS64 ? W'(64'h3fd0000000000000) : W'(32'h3e800000);
  localparam logic [W-1:0] C_3_4  = IS64 ? W'(64'h3fe8000000000000) : W'(32'h3f400000);
  localparam logic [W-1:0] C_1_6  = IS64 ? W'(64'h3fc5555555555555) : W'(32'h3e2aaaab);
  localparam logic [W-1:0] C_1_3  = IS64 ? W'(64'h3fd5555555555555) : W'(32'h3eaaaaab);

  typedef enum logic [2:0] {S_IDLE, S_MUL_I, S_MUL_W, S_ADD_I, S_ADD_W} state_t;
  state_t state;

  logic [9:0][W-1:0] coef_q;       // A slots 0..5, b 6..9 (unscaled)
  logic [9:0][W-1:0] scaled_q;
  logic [3:0]        slot_q;
  logic [W-1:0]      dt_q, t_q;
  logic [31:0]       step_q;
  logic [2:0]        stages_q;
  logic              valid_q;

  // ---- tableau ROM ----------------------------------------------------------------
  logic [9:0][W-1:0] rom;
  logic [2:0]        rom_st;
  always_comb begin
    rom    = '0;
    rom_st = 3'd1;
    case (cfg_func)
      flux_pkg::TS_EULER:    begin rom_st = 3'd1; rom[6] = C_ONE; end
      flux_pkg::TS_HEUN:     begin rom_st = 3'd2; rom[0] = C_ONE;  rom[6] = C_HALF; rom[7] = C_HALF; end
      flux_pkg::TS_MIDPOINT: begin rom_st = 3'd2; rom[0] = C_HALF; rom[7] = C_ONE; end
      flux_pkg::TS_RALSTON:  begin rom_st = 3'd2; rom[0] = C_2_3;  rom[6] = C_1_4;  rom[7] = C_3_4; end
      flux_pkg::TS_RK4:      begin rom_st = 3'd4; rom[0] = C_HALF; rom[2] = C_HALF; rom[5] = C_ONE;
                         rom[6] = C_1_6; rom[7] = C_1_3; rom[8] = C_1_3; rom[9] = C_1_6; end
      default: begin   // TS_CUSTOM
        rom_st = (custom_stages == 3'd0 || custom_stages > 3'd4) ? 3'd1 : custom_stages;
        for (int s = 0; s < 6; s++) rom[s] = custom_a[s*W +: W];
        for (int s = 0; s < 4; s++) rom[6+s] = (s < int'(rom_st)) ? custom_b[s*W +: W] : '0;
        // slots belonging to rows >= stages are unused (python: k[0] < S)
        if (rom_st < 3'd4) begin rom[3] = '0; rom[4] = '0; rom[5] = '0; end
        if (rom_st < 3'd3) begin rom[1] = '0; rom[2] = '0; end
        if (rom_st < 3'd2) begin rom[0] = '0; end
      end
    endcase
  end

  logic dt_ok;
  assign dt_ok = (cfg_dt[W-2:MAN_W] != '1) && (cfg_dt[W-2:0] != '0) && !cfg_dt[W-1];

  // ---- scalar FMA ----------------------------------------------------------------------
  logic         f_iv, f_ir, f_ov, f_or;
  logic [2:0]   f_op;
  logic [W-1:0] f_a, f_b, f_c, f_res;
  logic [4:0]   f_ff;
  logic [0:0]   f_tag;
  fma_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY), .TAG_W(1)) u_fma (
    .clk(clk), .rst_n(rst_n), .in_valid(f_iv), .in_ready(f_ir), .op(f_op), .rm(3'(flux_pkg::RM_RNE)),
    .a(f_a), .b(f_b), .c(f_c), .in_tag(1'b0), .out_valid(f_ov), .out_ready(f_or),
    .result(f_res), .fflags(f_ff), .out_tag(f_tag));
  always_comb begin
    if (state == S_ADD_I || state == S_ADD_W) begin
      f_op = flux_pkg::FMA_FADD; f_a = t_q; f_b = C_ONE; f_c = dt_q;
    end else begin
      f_op = flux_pkg::FMA_FMUL; f_a = dt_q; f_b = coef_q[slot_q]; f_c = '0;
    end
  end
  assign f_iv = (state == S_MUL_I) || (state == S_ADD_I);
  assign f_or = (state == S_MUL_W) || (state == S_ADD_W);

  assign cfg_ready = (state == S_IDLE) && !commit_valid;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state    <= S_IDLE;
      t_q      <= '0;
      dt_q     <= '0;
      step_q   <= '0;
      stages_q <= 3'd1;
      valid_q  <= 1'b0;
      coef_q   <= '0;
      scaled_q <= '0;
      slot_q   <= '0;
    end else begin
      case (state)
        S_IDLE: begin
          if (commit_valid) begin
            state <= S_ADD_I;
          end else if (cfg_valid) begin
            if (cfg_func == flux_pkg::TS_RESET) begin
              t_q    <= '0;
              step_q <= '0;
            end else begin
              coef_q   <= rom;
              stages_q <= rom_st;
              dt_q     <= cfg_dt;
              valid_q  <= dt_ok;
              slot_q   <= '0;
              state    <= S_MUL_I;
            end
          end
        end
        S_MUL_I: if (f_ir) state <= S_MUL_W;
        S_MUL_W: if (f_ov) begin
          scaled_q[slot_q] <= f_res;
          if (slot_q == 4'd9) state <= S_IDLE;
          else begin
            slot_q <= slot_q + 4'd1;
            state  <= S_MUL_I;
          end
        end
        S_ADD_I: if (f_ir) state <= S_ADD_W;
        S_ADD_W: if (f_ov) begin
          t_q    <= f_res;
          step_q <= step_q + 32'd1;
          state  <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  assign cfg_done    = ((state == S_IDLE) && cfg_valid && !commit_valid && cfg_func == flux_pkg::TS_RESET) ||
                       ((state == S_MUL_W) && f_ov && slot_q == 4'd9);
  assign cfg_fault   = !valid_q && (cfg_func != flux_pkg::TS_RESET);
  assign commit_done = (state == S_ADD_W) && f_ov;
  assign stages      = stages_q;
  assign ts_valid    = valid_q;
  assign t_now       = t_q;
  assign dt_now      = dt_q;
  assign step_count  = step_q;
  for (genvar s = 0; s < 6; s++) begin : g_ca
    assign ca[s*W +: W] = scaled_q[s];
  end
  for (genvar s = 0; s < 4; s++) begin : g_cb
    assign cb[s*W +: W] = scaled_q[6+s];
  end
endmodule
