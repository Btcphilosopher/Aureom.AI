// =============================================================================
// Silica Flux -- conservation checker (FU_CONS)
// -----------------------------------------------------------------------------
// Checks a scalar invariant of the state vector, e.g. total mass, energy or
// momentum of a set of control volumes:
//
//     I = sum_i w_i x_i          (pairwise tree over active lanes)
//
//   CONSERVE vd, vs1=x, vs2=w, func=CAPTURE       I_ref <- I            vd = I
//   CONSERVE vd, vs1=x, vs2=w, vs3=s, func=CHECK  (CHECK_ADV also I_ref <- I)
//       S   = sum_i s_i                 sources / boundary fluxes over the step
//       E   = I_ref + S                 expected invariant
//       r   = I - E                     conservation residual
//       th  = rtol*|E| + atol           (CONS_ATOL / CONS_RTOL CSRs)
//       rel = |r| / |E|                 exact division (|r| when E == 0)
//       violation = NOT(|r| <= th)  -> F_CONSERVATION, all lanes Q_SUSPECT
//   vd lanes: [I, E, r, rel, th, violation(1.0/0.0), I_ref(before), |r|, 0...]
//
// A drift that is invisible lane by lane (each update locally plausible) is
// detected here -- typically the first symptom of an unstable timestep.
// =============================================================================
`include "flux_fu_if.svh"
module conservation_checker #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic          clk,
  input  logic          rst_n,
  `SF_FU_PORTS,
  input  logic [W-1:0]  cfg_atol,
  input  logic [W-1:0]  cfg_rtol,
  output logic [W-1:0]  last_residual,
  output logic [W-1:0]  ref_value,
  output logic [31:0]   viol_count
);
  `include "flux_q.svh"
  localparam logic [W-1:0] ONE = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};

  typedef enum logic [3:0] {S_IDLE, S_DOT, S_DOTW, S_SUM, S_SUMW, S_E_I, S_E_W, S_R_I, S_R_W,
                            S_T_I, S_T_W, S_DIV_I, S_DIV_W, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t             uop_q;
  logic [LANES-1:0] lmask_q;
  logic [LANES*W-1:0] x_q, w_q, s_q;
  logic [flux_pkg::QW-1:0]    qin_q;
  logic [W-1:0]     i_q, sum_q, e_q, r_q, th_q, rel_q, ref_q, refb_q, lastr_q;
  logic [4:0]       ff_q;
  logic             viol_q;
  logic [31:0]      cnt_q;

  // ---- reduction core (DOT then SUM) -------------------------------------------------
  logic         rc_iv, rc_ir, rc_ov, rc_or, rc_any;
  logic [W-1:0] rc_val;
  logic [15:0]  rc_idx;
  logic [4:0]   rc_ff;
  logic [3:0]         rc_func;
  logic [LANES*W-1:0] rc_a;
  assign rc_func = (state == S_DOT) ? flux_pkg::RED_DOT : flux_pkg::RED_SUM;
  assign rc_a    = (state == S_DOT) ? x_q : s_q;
  reduction_core #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_red (
    .clk(clk), .rst_n(rst_n), .in_valid(rc_iv), .in_ready(rc_ir),
    .func(rc_func), .rm(uop_q.rm),
    .a(rc_a), .b(w_q), .valid(lmask_q),
    .out_valid(rc_ov), .out_ready(rc_or), .value(rc_val), .index(rc_idx), .any(rc_any), .fflags(rc_ff));
  assign rc_iv = (state == S_DOT) || (state == S_SUM);
  assign rc_or = (state == S_DOTW) || (state == S_SUMW);

  // ---- scalar FMA and divider ----------------------------------------------------------
  logic         f_iv, f_ir, f_ov, f_or;
  logic [2:0]   f_op;
  logic [W-1:0] f_a, f_b, f_c, f_res;
  logic [4:0]   f_ff;
  logic [0:0]   f_tag;
  fma_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY), .TAG_W(1)) u_fma (
    .clk(clk), .rst_n(rst_n), .in_valid(f_iv), .in_ready(f_ir), .op(f_op), .rm(uop_q.rm),
    .a(f_a), .b(f_b), .c(f_c), .in_tag(1'b0), .out_valid(f_ov), .out_ready(f_or),
    .result(f_res), .fflags(f_ff), .out_tag(f_tag));
  always_comb begin
    case (state)
      S_E_I, S_E_W: begin f_op = flux_pkg::FMA_FADD;  f_a = ref_q;    f_b = ONE; f_c = sum_q; end
      S_R_I, S_R_W: begin f_op = flux_pkg::FMA_FSUB;  f_a = i_q;      f_b = ONE; f_c = e_q; end
      default:      begin f_op = flux_pkg::FMA_FMADD; f_a = cfg_rtol; f_b = {1'b0, e_q[W-2:0]}; f_c = cfg_atol; end
    endcase
  end
  assign f_iv = (state == S_E_I) || (state == S_R_I) || (state == S_T_I);
  assign f_or = (state == S_E_W) || (state == S_R_W) || (state == S_T_W);

  logic         d_iv, d_ir, d_ov, d_or, d_busy;
  logic [W-1:0] d_res;
  logic [4:0]   d_ff;
  logic [7:0]   d_tag;
  divider #(.EXP_W(EXP_W), .MAN_W(MAN_W), .BITS_PER_CYCLE(2)) u_div (
    .clk(clk), .rst_n(rst_n), .in_valid(d_iv), .in_ready(d_ir),
    .a({1'b0, r_q[W-2:0]}), .b({1'b0, e_q[W-2:0]}), .rm(uop_q.rm), .in_tag(8'd0),
    .out_valid(d_ov), .out_ready(d_or), .result(d_res), .fflags(d_ff), .out_tag(d_tag), .busy(d_busy));
  assign d_iv = (state == S_DIV_I);
  assign d_or = (state == S_DIV_W);

  logic e_zero;
  assign e_zero = (e_q[W-2:0] == '0);
  logic c_lt, c_le, c_eq, c_un, c_sn;
  logic [W-1:0] c_mn, c_mx;
  fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_cmp (
    .a({1'b0, r_q[W-2:0]}), .b(th_q), .lt(c_lt), .le(c_le), .eq(c_eq), .unordered(c_un), .snan(c_sn),
    .vmin(c_mn), .vmax(c_mx));

  assign req_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state   <= S_IDLE;
      ref_q   <= '0;
      lastr_q <= '0;
      cnt_q   <= '0;
    end else begin
      case (state)
        S_IDLE: if (req_valid) state <= S_DOT;
        S_DOT:  if (rc_ir) state <= S_DOTW;
        S_DOTW: if (rc_ov) begin
          if (uop_q.ins.func == flux_pkg::CONS_CAPTURE) begin
            ref_q <= rc_any ? rc_val : '0;
            state <= S_RESP;
          end else begin
            state <= S_SUM;
          end
        end
        S_SUM:  if (rc_ir) state <= S_SUMW;
        S_SUMW: if (rc_ov) state <= S_E_I;
        S_E_I:  if (f_ir) state <= S_E_W;
        S_E_W:  if (f_ov) state <= S_R_I;
        S_R_I:  if (f_ir) state <= S_R_W;
        S_R_W:  if (f_ov) state <= S_T_I;
        S_T_I:  if (f_ir) state <= S_T_W;
        S_T_W:  if (f_ov) state <= e_zero ? S_RESP : S_DIV_I;
        S_DIV_I: if (d_ir) state <= S_DIV_W;
        S_DIV_W: if (d_ov) state <= S_RESP;
        S_RESP: if (rsp_ready) begin
          state <= S_IDLE;
          if (uop_q.ins.func != flux_pkg::CONS_CAPTURE) begin
            lastr_q <= r_q;
            if (!c_le) cnt_q <= cnt_q + 32'd1;
            if (uop_q.ins.func == flux_pkg::CONS_CHECK_ADV) ref_q <= i_q;
          end
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (req_valid) begin
        logic [flux_pkg::QW-1:0] q;
        q = '0;
        for (int l = 0; l < LANES; l++)
          if (req_lmask[l])
            q |= req_qa[l*flux_pkg::QW +: flux_pkg::QW] | req_qb[l*flux_pkg::QW +: flux_pkg::QW] |
                 ((req_uop.ins.func != flux_pkg::CONS_CAPTURE) ? req_qc[l*flux_pkg::QW +: flux_pkg::QW] : '0);
        qin_q   <= q;
        uop_q   <= req_uop;
        lmask_q <= req_lmask;
        x_q     <= req_a;
        w_q     <= req_b;
        s_q     <= req_c;
        ff_q    <= '0;
        refb_q  <= ref_q;
      end
      S_DOTW: if (rc_ov) begin i_q <= rc_any ? rc_val : '0; ff_q <= ff_q | rc_ff; end
      S_SUMW: if (rc_ov) begin sum_q <= rc_any ? rc_val : '0; ff_q <= ff_q | rc_ff; end
      S_E_W:  if (f_ov) begin e_q <= f_res;  ff_q <= ff_q | f_ff; end
      S_R_W:  if (f_ov) begin r_q <= f_res;  ff_q <= ff_q | f_ff; end
      S_T_W:  if (f_ov) begin th_q <= f_res; ff_q <= ff_q | f_ff; rel_q <= {1'b0, r_q[W-2:0]}; end
      S_DIV_W: if (d_ov) rel_q <= d_res;
      default: ;
    endcase
  end

  logic is_cap;
  assign is_cap = (uop_q.ins.func == flux_pkg::CONS_CAPTURE);
  logic [7:0][W-1:0] cv;
  always_comb begin
    logic [flux_pkg::QW-1:0] q;
    cv[0] = i_q; cv[1] = e_q; cv[2] = r_q; cv[3] = rel_q; cv[4] = th_q;
    cv[5] = c_le ? '0 : ONE; cv[6] = refb_q; cv[7] = {1'b0, r_q[W-2:0]};
    if (is_cap) q = qin_q | qual_of(i_q, ff_q);
    else        q = qin_q | qual_of(r_q, ff_q) | (c_le ? '0 : flux_pkg::QW'(1 << flux_pkg::Q_SUSPECT));
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W]   = is_cap ? i_q : ((l < 8) ? cv[l % 8] : '0);
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = q;
    end
    rsp_faults = '0;
    rsp_faults[flux_pkg::F_CONSERVATION] = !is_cap && !c_le;
  end
  assign rsp_valid     = (state == S_RESP);
  assign rsp_uop       = uop_q;
  assign rsp_wmask     = {LANES{1'b1}};
  assign rsp_vm        = '0;
  assign rsp_fflags    = ff_q;
  assign last_residual = lastr_q;
  assign ref_value     = ref_q;
  assign viol_count    = cnt_q;
endmodule
