// =============================================================================
// Silica Flux -- lane residual engine (FU_RESID)
// -----------------------------------------------------------------------------
//   RESIDUAL vd, vs1=expected e, vs2=observed o, vs3=atol, func
//     r         = e - o
//     threshold = rtol * |e| + atol         (one FMA; rtol from RES_RTOL CSR)
//     violation = NOT(|r| <= threshold)      (a NaN residual is a violation)
//     vd        = r | |r| | threshold-|r|    (func SIGNED / ABS / MARGIN)
//     VM        = violation mask
//
// The relative test is formed without division (hardware friendly), and a
// violating lane is marked Q_SUSPECT so every value later derived from it
// carries the warning.  Any violation raises F_RESIDUAL.
// =============================================================================
`include "flux_fu_if.svh"
module residual_engine #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic          clk,
  input  logic          rst_n,
  `SF_FU_PORTS,
  input  logic [W-1:0]  cfg_rtol,
  output logic [31:0]   viol_count
);
  `include "flux_q.svh"

  typedef enum logic [2:0] {S_IDLE, S_I1, S_W1, S_I2, S_W2, S_I3, S_W3, S_RESP} state_t;
  state_t state;
  flux_pkg::uop_t                     uop_q;
  logic [LANES-1:0]         lmask_q;
  logic [LANES-1:0][W-1:0]  e_q, o_q, at_q, r_q, th_q, m_q;
  logic [LANES-1:0][flux_pkg::QW-1:0] qin_q;
  logic [LANES-1:0][4:0]    lf_q;
  logic [31:0]              cnt_q;

  logic               a_iv, a_ir, a_ov, a_or;
  logic [2:0]         a_op;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  localparam logic [W-1:0] ONE = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(a_op), .rm(uop_q.rm),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      case (state)
        S_I1, S_W1: begin a_a[l*W +: W] = e_q[l];   a_b[l*W +: W] = ONE;                 a_c[l*W +: W] = o_q[l]; end
        S_I2, S_W2: begin a_a[l*W +: W] = cfg_rtol; a_b[l*W +: W] = fabs(e_q[l]); a_c[l*W +: W] = at_q[l]; end
        default:    begin a_a[l*W +: W] = th_q[l];  a_b[l*W +: W] = ONE;                 a_c[l*W +: W] = fabs(r_q[l]); end
      endcase
    end
    a_op = (state == S_I2 || state == S_W2) ? flux_pkg::FMA_FMADD : flux_pkg::FMA_FSUB;
  end
  assign a_iv = (state == S_I1) || (state == S_I2) || (state == S_I3);
  assign a_or = (state == S_W1) || (state == S_W2) || (state == S_W3);
  assign req_ready = (state == S_IDLE);

  // violation per lane
  logic [LANES-1:0] viol;
  for (genvar l = 0; l < LANES; l++) begin : g_v
    logic lt, le, eq, un, sn;
    logic [W-1:0] mn, mx;
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_c (
      .a(fabs(r_q[l])), .b(th_q[l]), .lt(lt), .le(le), .eq(eq), .unordered(un), .snan(sn),
      .vmin(mn), .vmax(mx));
    assign viol[l] = !le;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
      cnt_q <= '0;
    end else begin
      case (state)
        S_IDLE: if (req_valid) state <= S_I1;
        S_I1: if (a_ir) state <= S_W1;
        S_W1: if (a_ov) state <= S_I2;
        S_I2: if (a_ir) state <= S_W2;
        S_W2: if (a_ov) state <= (uop_q.ins.func == flux_pkg::RES_MARGIN) ? S_I3 : S_RESP;
        S_I3: if (a_ir) state <= S_W3;
        S_W3: if (a_ov) state <= S_RESP;
        S_RESP: if (rsp_ready) begin
          state <= S_IDLE;
          cnt_q <= cnt_q + 32'($countones(viol & lmask_q));
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (req_valid) begin
        uop_q   <= req_uop;
        lmask_q <= req_lmask;
        for (int l = 0; l < LANES; l++) begin
          e_q[l]   <= req_a[l*W +: W];
          o_q[l]   <= req_b[l*W +: W];
          at_q[l]  <= req_c[l*W +: W];
          qin_q[l] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW] | req_qb[l*flux_pkg::QW +: flux_pkg::QW] | req_qc[l*flux_pkg::QW +: flux_pkg::QW];
          lf_q[l]  <= '0;
        end
      end
      S_W1: if (a_ov) for (int l = 0; l < LANES; l++) begin
        r_q[l] <= a_res[l*W +: W]; lf_q[l] <= a_ff[l*5 +: 5];
      end
      S_W2: if (a_ov) for (int l = 0; l < LANES; l++) begin
        th_q[l] <= a_res[l*W +: W]; lf_q[l] <= lf_q[l] | a_ff[l*5 +: 5];
      end
      S_W3: if (a_ov) for (int l = 0; l < LANES; l++) begin
        m_q[l] <= a_res[l*W +: W]; lf_q[l] <= lf_q[l] | a_ff[l*5 +: 5];
      end
      default: ;
    endcase
  end

  // per-lane output selection (continuous, so no process-local temporaries)
  logic [LANES-1:0][W-1:0] out_w;
  for (genvar l = 0; l < LANES; l++) begin : g_out
    assign out_w[l] = (uop_q.ins.func == flux_pkg::RES_ABS)    ? fabs(r_q[l]) :
                      (uop_q.ins.func == flux_pkg::RES_MARGIN) ? m_q[l] : r_q[l];
  end
  always_comb begin
    rsp_fflags = '0;
    rsp_faults = '0;
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W]   = out_w[l];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qin_q[l] | qual_of(out_w[l], lf_q[l]) | (viol[l] ? flux_pkg::QW'(1 << flux_pkg::Q_SUSPECT) : '0);
      if (lmask_q[l]) rsp_fflags |= lf_q[l];
    end
    rsp_faults[flux_pkg::F_RESIDUAL] = |(viol & lmask_q);
  end
  assign rsp_valid  = (state == S_RESP);
  assign rsp_uop    = uop_q;
  assign rsp_wmask  = lmask_q;
  assign rsp_vm     = viol;
  assign viol_count = cnt_q;
endmodule
