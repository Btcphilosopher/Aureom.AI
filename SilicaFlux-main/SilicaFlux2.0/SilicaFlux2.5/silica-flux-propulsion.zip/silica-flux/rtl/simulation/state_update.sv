// =============================================================================
// Silica Flux -- physical-system state engine (FU_STATE)
// -----------------------------------------------------------------------------
// Generic explicit integrator for  dx/dt = f(x, u, p):
//
//   TSCFG        vs1[0] = dt, func = method     configure the timestep engine
//   STATE_UPDATE vd, vs1, func=LOAD (8)        x0 <- vs1           (vd = vs1)
//   STATE_UPDATE vd, vs1, func=s   (0..3)      k_s <- vs1  (derivative at stage s)
//        s < S-1 : vd = x0 + sum_{j<=s} dt*A[s+1][j] * k_j   (next stage input)
//        s = S-1 : vd = x0 + sum_j     dt*b[j]      * k_j   (x_{n+1}, commits t, step)
//
// The program evaluates f() between stages with ordinary vector instructions,
// so the same engine integrates propulsion, cryogenic, thermal, structural or
// process models -- nothing about any particular physical system is encoded
// in hardware.  Each stage combination is an FMA chain in ascending j with
// zero tableau entries skipped (deterministic, bit-exact with
// golden_model/engines.py state_update).
// =============================================================================
`include "flux_fu_if.svh"
module state_update #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic             clk,
  input  logic             rst_n,
  `SF_FU_PORTS,
  // custom tableau (CSR)
  input  logic [2:0]       custom_stages,
  input  logic [6*W-1:0]   custom_a,
  input  logic [4*W-1:0]   custom_b,
  // observability
  output logic [W-1:0]     t_now,
  output logic [W-1:0]     dt_now,
  output logic [31:0]      step_count,
  output logic             ts_valid,
  output logic [31:0]      state_updates    // lane-state updates performed
);
  `include "flux_q.svh"

  typedef enum logic [2:0] {S_IDLE, S_CFG, S_ISSUE, S_WAIT, S_COMMIT, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t                          uop_q;
  logic [LANES-1:0]              lmask_q;
  logic [LANES-1:0][W-1:0]       x0_q, acc_q;
  logic [LANES-1:0][flux_pkg::QW-1:0]      qx0_q, q_q;
  logic [LANES*W-1:0]            k_q  [4];
  logic [LANES*flux_pkg::QW-1:0]           qk_q [4];
  logic [LANES-1:0][4:0]         lf_q;
  logic [2:0]                    j_q;
  logic [1:0]                    s_q;
  logic                          last_q, fault_q, cfg_fault_q;
  logic [31:0]                   upd_q;

  logic [3:0] cfg_func_w;
  assign cfg_func_w = uop_q.ins.func;

  // ---- timestep engine ------------------------------------------------------------
  logic             te_cfg_ready, te_cfg_done, te_cfg_fault, te_commit_done, te_valid;
  logic [2:0]       te_stages;
  logic [6*W-1:0]   te_ca;
  logic [4*W-1:0]   te_cb;
  timestep_engine #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_ts (
    .clk(clk), .rst_n(rst_n),
    .cfg_valid(state == S_CFG), .cfg_ready(te_cfg_ready), .cfg_func(cfg_func_w),
    .cfg_dt(acc_q[0]), .cfg_done(te_cfg_done), .cfg_fault(te_cfg_fault),
    .commit_valid(state == S_COMMIT), .commit_done(te_commit_done),
    .custom_stages(custom_stages), .custom_a(custom_a), .custom_b(custom_b),
    .stages(te_stages), .ca(te_ca), .cb(te_cb), .ts_valid(te_valid),
    .t_now(t_now), .dt_now(dt_now), .step_count(step_count));
  assign ts_valid = te_valid;

  // ---- coefficient for term j of the current stage -----------------------------------
  function automatic logic [2:0] slot(input logic [2:0] i, input logic [2:0] j);
    slot = 3'((int'(i) * (int'(i) - 1)) / 2 + int'(j));
  endfunction
  logic [W-1:0] coef_j;
  always_comb begin
    if (last_q) coef_j = te_cb[j_q[1:0]*W +: W];
    else        coef_j = te_ca[slot(3'(s_q) + 3'd1, j_q)*W +: W];
  end
  logic coef_zero;
  assign coef_zero = (coef_j[W-2:0] == '0);

  // ---- FMA array -----------------------------------------------------------------------
  logic               a_iv, a_ir, a_ov, a_or;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(3'(flux_pkg::FMA_FMADD)), .rm(uop_q.rm),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      a_a[l*W +: W] = coef_j;
      a_b[l*W +: W] = k_q[j_q[1:0]][l*W +: W];
      a_c[l*W +: W] = acc_q[l];
    end
  end
  assign a_iv = (state == S_ISSUE) && !coef_zero;
  assign a_or = (state == S_WAIT);

  assign req_ready = (state == S_IDLE);

  // ---- control --------------------------------------------------------------------------
  logic [3:0] f_in;
  assign f_in = req_uop.ins.func;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE;
      upd_q <= '0;
    end else begin
      case (state)
        S_IDLE: if (req_valid) begin
          if (req_uop.ins.opcode == flux_pkg::OP_TSCFG)       state <= S_CFG;
          else if (f_in == flux_pkg::SU_LOAD || f_in[3])      state <= S_RESP;
          else if (!te_valid || (f_in[2:0] >= te_stages)) state <= S_RESP;
          else                                      state <= S_ISSUE;
        end
        S_CFG: if (te_cfg_done) state <= S_RESP;
        S_ISSUE: begin
          if (coef_zero) begin
            if (j_q == 3'(s_q)) state <= last_q ? S_COMMIT : S_RESP;
          end else if (a_ir) begin
            state <= S_WAIT;
          end
        end
        S_WAIT: if (a_ov) state <= (j_q == 3'(s_q)) ? (last_q ? S_COMMIT : S_RESP) : S_ISSUE;
        S_COMMIT: if (te_commit_done) state <= S_RESP;
        S_RESP: if (rsp_ready) begin
          state <= S_IDLE;
          if (uop_q.ins.opcode == flux_pkg::OP_STATE_UPDATE && !fault_q && uop_q.ins.func != flux_pkg::SU_LOAD && last_q)
            upd_q <= upd_q + 32'(LANES);
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (req_valid) begin
        uop_q   <= req_uop;
        lmask_q <= req_lmask;
        j_q     <= '0;
        s_q     <= f_in[1:0];
        last_q  <= (3'(f_in[1:0]) == te_stages - 3'd1) && !f_in[2] && !f_in[3];
        fault_q <= (req_uop.ins.opcode == flux_pkg::OP_STATE_UPDATE) && (f_in != flux_pkg::SU_LOAD) &&
                   (f_in[3] || f_in[2] || !te_valid || (f_in[2:0] >= te_stages));
        for (int l = 0; l < LANES; l++) begin
          lf_q[l] <= '0;
          if (req_uop.ins.opcode == flux_pkg::OP_TSCFG) begin
            acc_q[l] <= req_a[l*W +: W];
            q_q[l]   <= req_qa[l*flux_pkg::QW +: flux_pkg::QW];
          end else if (f_in == flux_pkg::SU_LOAD) begin
            x0_q[l]  <= req_a[l*W +: W];
            qx0_q[l] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW];
            acc_q[l] <= req_a[l*W +: W];
            q_q[l]   <= req_qa[l*flux_pkg::QW +: flux_pkg::QW];
          end else begin
            if (!f_in[3] && !f_in[2]) begin
              k_q[f_in[1:0]][l*W +: W]    <= req_a[l*W +: W];
              qk_q[f_in[1:0]][l*flux_pkg::QW +: flux_pkg::QW] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW];
            end
            acc_q[l] <= x0_q[l];
            q_q[l]   <= qx0_q[l];
          end
        end
      end
      S_CFG: if (te_cfg_done) cfg_fault_q <= te_cfg_fault;
      S_ISSUE: if (coef_zero && j_q != 3'(s_q)) j_q <= j_q + 3'd1;
      S_WAIT: if (a_ov) begin
        for (int l = 0; l < LANES; l++) begin
          acc_q[l] <= a_res[l*W +: W];
          lf_q[l]  <= lf_q[l] | a_ff[l*5 +: 5];
          q_q[l]   <= q_q[l] | qk_q[j_q[1:0]][l*flux_pkg::QW +: flux_pkg::QW];
        end
        if (j_q != 3'(s_q)) j_q <= j_q + 3'd1;
      end
      default: ;
    endcase
  end

  // ---- response ---------------------------------------------------------------------------
  logic is_cfg, is_load;
  assign is_cfg  = (uop_q.ins.opcode == flux_pkg::OP_TSCFG);
  assign is_load = (uop_q.ins.func == flux_pkg::SU_LOAD);
  always_comb begin
    rsp_fflags = '0;
    rsp_faults = '0;
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W] = acc_q[l];
      if (is_cfg || is_load)  rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = q_q[l];
      else if (fault_q)       rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qx0_q[l] | flux_pkg::QW'(1 << flux_pkg::Q_SUSPECT);
      else                    rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = q_q[l] | qual_of(acc_q[l], lf_q[l]);
      if (lmask_q[l] && !is_cfg) rsp_fflags |= lf_q[l];
    end
    if (fault_q || (is_cfg && cfg_fault_q && uop_q.ins.func != flux_pkg::TS_RESET)) rsp_faults[flux_pkg::F_STEP] = 1'b1;
  end
  assign rsp_valid     = (state == S_RESP);
  assign rsp_uop       = uop_q;
  assign rsp_wmask     = lmask_q;
  assign rsp_vm        = '0;
  assign state_updates = upd_q;
endmodule
