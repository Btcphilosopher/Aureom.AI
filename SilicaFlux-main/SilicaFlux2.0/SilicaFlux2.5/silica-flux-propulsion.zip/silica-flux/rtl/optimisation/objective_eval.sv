// =============================================================================
// Silica Flux -- objective engine (FU_OBJ)
// -----------------------------------------------------------------------------
//   OBJECTIVE vd, vs1=x, vs2=target t, vs3=weights w, func = {REDUCE, -, mode[1:0]}
//     WSUM     term = w * x
//     ABS      term = w * |x - t|
//     SQ       term = w * ((x - t)^2)          normalised error: fold 1/scale^2 into w
//     PENALTY  term = w * min(x, 0)^2          x = constraint margin (CONSTRAINT vd)
//   REDUCE=0  vd = per-lane terms   (multi-objective vector / one objective per
//                                    candidate lane in a parameter sweep)
//   REDUCE=1  vd = sum of terms over active lanes (pairwise tree), broadcast
//
// Weights come from configuration memory; the engine encodes no preference
// about what a "good" design is -- it evaluates whatever objective the host
// specifies.
// =============================================================================
`include "flux_fu_if.svh"
module objective_eval #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic clk,
  input  logic rst_n,
  `SF_FU_PORTS
);
  `include "flux_q.svh"
  localparam logic [W-1:0] ONE = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};

  typedef enum logic [3:0] {S_IDLE, S_I1, S_W1, S_I2, S_W2, S_I3, S_W3, S_RED, S_REDW, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t                     uop_q;
  logic [LANES-1:0]         lmask_q;
  logic [LANES-1:0][W-1:0]  x_q, t_q, w_q, v_q;
  logic [LANES-1:0][flux_pkg::QW-1:0] qin_q;
  logic [LANES-1:0][4:0]    lf_q;
  logic [1:0]               mode_q;
  logic                     red_q;
  logic [W-1:0]             j_q;
  logic [4:0]               jff_q;
  logic                     jany_q;

  // number of FMA passes per mode: WSUM 1, ABS 2, SQ 3, PENALTY 2
  logic [1:0] pass_q;
  logic [1:0] npass;
  always_comb begin
    case (mode_q)
      flux_pkg::OBJ_WSUM[1:0]: npass = 2'd1;
      flux_pkg::OBJ_SQ[1:0]:   npass = 2'd3;
      default:       npass = 2'd2;
    endcase
  end

  logic               a_iv, a_ir, a_ov, a_or;
  logic [2:0]         a_op;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(a_op), .rm(uop_q.rm),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  always_comb begin
    a_op = flux_pkg::FMA_FMUL;
    for (int l = 0; l < LANES; l++) begin
      a_a[l*W +: W] = w_q[l];
      a_b[l*W +: W] = v_q[l];
      a_c[l*W +: W] = '0;
      // first pass of ABS / SQ: d = x - t ; second pass of SQ: e2 = d*d
      if ((mode_q == flux_pkg::OBJ_ABS[1:0] || mode_q == flux_pkg::OBJ_SQ[1:0]) && pass_q == 2'd0) begin
        a_op = flux_pkg::FMA_FSUB; a_a[l*W +: W] = x_q[l]; a_b[l*W +: W] = ONE; a_c[l*W +: W] = t_q[l];
      end else if ((mode_q == flux_pkg::OBJ_SQ[1:0] && pass_q == 2'd1) || (mode_q == flux_pkg::OBJ_PENALTY[1:0] && pass_q == 2'd0)) begin
        a_op = flux_pkg::FMA_FMUL; a_a[l*W +: W] = v_q[l]; a_b[l*W +: W] = v_q[l];
      end else if (mode_q == flux_pkg::OBJ_ABS[1:0] && pass_q == 2'd1) begin
        a_b[l*W +: W] = fabs(v_q[l]);
      end
    end
  end
  assign a_iv = (state == S_I1);
  assign a_or = (state == S_W1);

  // ---- tree sum for REDUCE -------------------------------------------------------------
  logic         rc_iv, rc_ir, rc_ov, rc_or, rc_any;
  logic [W-1:0] rc_val;
  logic [15:0]  rc_idx;
  logic [4:0]   rc_ff;
  logic [LANES*W-1:0] terms;
  always_comb for (int l = 0; l < LANES; l++) terms[l*W +: W] = v_q[l];
  reduction_core #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_red (
    .clk(clk), .rst_n(rst_n), .in_valid(rc_iv), .in_ready(rc_ir), .func(4'(flux_pkg::RED_SUM)), .rm(uop_q.rm),
    .a(terms), .b('0), .valid(lmask_q), .out_valid(rc_ov), .out_ready(rc_or),
    .value(rc_val), .index(rc_idx), .any(rc_any), .fflags(rc_ff));
  assign rc_iv = (state == S_RED);
  assign rc_or = (state == S_REDW);

  assign req_ready = (state == S_IDLE);

  // penalty pre-selection: v = (m < 0 or NaN) ? m : +0
  function automatic logic [W-1:0] pen(input logic [W-1:0] m);
    logic is_nan, neg;
    is_nan = (m[W-2:MAN_W] == '1) && (m[MAN_W-1:0] != '0);
    neg    = m[W-1] && (m[W-2:0] != '0);
    pen = (is_nan || neg) ? m : '0;
  endfunction

  always_ff @(posedge clk) begin
    if (!rst_n) state <= S_IDLE;
    else begin
      case (state)
        S_IDLE: if (req_valid) state <= S_I1;
        S_I1:   if (a_ir) state <= S_W1;
        S_W1:   if (a_ov) begin
          if (pass_q == npass - 2'd1) state <= red_q ? S_RED : S_RESP;
          else                        state <= S_I1;
        end
        S_RED:  if (rc_ir) state <= S_REDW;
        S_REDW: if (rc_ov) state <= S_RESP;
        S_RESP: if (rsp_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (req_valid) begin
        uop_q   <= req_uop;
        lmask_q <= req_lmask;
        mode_q  <= req_uop.ins.func[1:0];
        red_q   <= req_uop.ins.func[3];
        pass_q  <= '0;
        for (int l = 0; l < LANES; l++) begin
          x_q[l]  <= req_a[l*W +: W];
          t_q[l]  <= req_b[l*W +: W];
          w_q[l]  <= req_c[l*W +: W];
          lf_q[l] <= '0;
          v_q[l]  <= (req_uop.ins.func[1:0] == flux_pkg::OBJ_PENALTY[1:0]) ? pen(req_a[l*W +: W]) : req_a[l*W +: W];
          case (req_uop.ins.func[1:0])
            flux_pkg::OBJ_ABS[1:0], flux_pkg::OBJ_SQ[1:0]: qin_q[l] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW] | req_qb[l*flux_pkg::QW +: flux_pkg::QW] | req_qc[l*flux_pkg::QW +: flux_pkg::QW];
            default:                   qin_q[l] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW] | req_qc[l*flux_pkg::QW +: flux_pkg::QW];
          endcase
        end
      end
      S_W1: if (a_ov) begin
        for (int l = 0; l < LANES; l++) begin
          v_q[l]  <= a_res[l*W +: W];
          lf_q[l] <= lf_q[l] | a_ff[l*5 +: 5];
        end
        pass_q <= pass_q + 2'd1;
      end
      S_REDW: if (rc_ov) begin
        j_q    <= rc_any ? rc_val : '0;
        jff_q  <= rc_ff;
        jany_q <= rc_any;
      end
      default: ;
    endcase
  end

  always_comb begin
    logic [flux_pkg::QW-1:0] qall;
    logic [4:0]    fl;
    qall = '0;
    fl   = '0;
    for (int l = 0; l < LANES; l++) begin
      if (lmask_q[l]) begin
        qall |= qin_q[l] | qual_of(v_q[l], lf_q[l]);
        fl   |= lf_q[l];
      end
    end
    if (red_q) begin
      qall |= qual_of(j_q, jff_q) | (jany_q ? '0 : flux_pkg::QW'(1 << flux_pkg::Q_SUSPECT));
      fl   |= jff_q;
    end
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W]   = red_q ? j_q : v_q[l];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = red_q ? qall : (qin_q[l] | qual_of(v_q[l], lf_q[l]));
    end
    rsp_fflags = fl;
  end
  assign rsp_valid  = (state == S_RESP);
  assign rsp_uop    = uop_q;
  assign rsp_wmask  = red_q ? {LANES{1'b1}} : lmask_q;
  assign rsp_vm     = '0;
  assign rsp_faults = '0;
endmodule
