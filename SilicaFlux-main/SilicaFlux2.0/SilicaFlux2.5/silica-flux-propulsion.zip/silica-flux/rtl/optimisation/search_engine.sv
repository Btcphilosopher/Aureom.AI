// =============================================================================
// Silica Flux -- bounded search engine (FU_SEARCH)
// -----------------------------------------------------------------------------
// Deterministic numerical search infrastructure (no physical-system control):
//
//   SEARCH func=RESET            best <- +Inf, center <- C0, step <- S0, iter <- 0
//   SEARCH vs1, func=GRID         arg-min of vs1 over (active & VM) lanes; if it
//                                 improves on best: best, best_index <- sweep
//                                 base + lane          (grid / sweep tracking)
//   SEARCH vd, func=LS_GEN, imm=d compass candidates for dimension d:
//                                 lane 2k   = center + step_k e_k
//                                 lane 2k+1 = center - step_k e_k
//                                 lane L-1  = center
//                                 VM = candidate inside [lo, hi] (bounded search)
//   SEARCH vs1, func=LOCAL        vs1 = objective of the LS_GEN candidates; if the
//                                 best feasible candidate beats f(center) the
//                                 center moves there, otherwise every step is
//                                 halved.  Converged when all steps < min_step
//                                 or iter >= max_iter.
//
// Arg-min uses the reduction core (NaN never wins, ties -> lowest lane), so the
// search trajectory is bit-reproducible.  Reference: golden_model/engines.py.
// =============================================================================
`include "flux_fu_if.svh"
module search_engine #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic             clk,
  input  logic             rst_n,
  `SF_FU_PORTS,
  input  logic [2:0]       cfg_dims,
  input  logic [4*W-1:0]   cfg_lo,
  input  logic [4*W-1:0]   cfg_hi,
  input  logic [4*W-1:0]   cfg_center0,
  input  logic [4*W-1:0]   cfg_step0,
  input  logic [4*W-1:0]   cfg_min_step,
  input  logic [15:0]      cfg_max_iter,
  input  logic [31:0]      sweep_base,
  output logic [W-1:0]     best,
  output logic [31:0]      best_index,
  output logic [4*W-1:0]   center,
  output logic [4*W-1:0]   step,
  output logic [15:0]      iter,
  output logic             converged
);
  `include "flux_q.svh"
  localparam int LSMAX = ((LANES - 1) / 2 < 4) ? (LANES - 1) / 2 : 4;
  localparam int LW_IDX = (LANES > 1) ? $clog2(LANES) : 1;
  localparam logic [W-1:0] ONE  = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};
  localparam logic [W-1:0] HALF = {2'b00, {(EXP_W-2){1'b1}}, 1'b0, {MAN_W{1'b0}}};
  localparam logic [W-1:0] PINF = {1'b0, {EXP_W{1'b1}}, {MAN_W{1'b0}}};

  typedef enum logic [3:0] {S_IDLE, S_GEN_I, S_GEN_W, S_RED, S_RED_W, S_HALF_I, S_HALF_W,
                            S_CONV, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t                     uop_q;
  logic [LANES-1:0]         lmask_q, feas_q, vm_q;
  logic [LANES-1:0][W-1:0]  obj_q, cand_q, out_q;
  logic [LANES-1:0][4:0]    lf_q;
  logic [3:0][W-1:0]        center_q, step_q;
  logic [W-1:0]             best_q, fc_q;
  logic [31:0]              bidx_q;
  logic [15:0]              iter_q;
  logic                     conv_q, fault_q;
  logic [1:0]               dim_q;
  logic                     dims_ok;
  assign dims_ok = (cfg_dims >= 3'd1) && (int'(cfg_dims) <= LSMAX);

  // ---- FMA array: candidates (center +/- step) and step halving ---------------------------
  logic               a_iv, a_ir, a_ov, a_or;
  logic [2:0]         a_op;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(a_op), .rm(3'(flux_pkg::RM_RNE)),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  always_comb begin
    a_op = (state == S_HALF_I || state == S_HALF_W) ? flux_pkg::FMA_FMUL : flux_pkg::FMA_FADD;
    for (int l = 0; l < LANES; l++) begin
      if (state == S_HALF_I || state == S_HALF_W) begin
        a_a[l*W +: W] = (l < 4) ? step_q[l % 4] : '0;
        a_b[l*W +: W] = HALF;
        a_c[l*W +: W] = '0;
      end else begin
        a_a[l*W +: W] = center_q[(l / 2) % 4];
        a_b[l*W +: W] = ONE;
        a_c[l*W +: W] = (l % 2 == 0) ? step_q[(l / 2) % 4] : fneg(step_q[(l / 2) % 4]);
      end
    end
  end
  assign a_iv = (state == S_GEN_I) || (state == S_HALF_I);
  assign a_or = (state == S_GEN_W) || (state == S_HALF_W);

  // ---- bounds of each candidate lane ---------------------------------------------------------
  logic [LANES-1:0] in_bounds;
  for (genvar l = 0; l < LANES; l++) begin : g_b
    localparam int K = (l / 2) % 4;
    logic lt1, le1, eq1, un1, sn1, lt2, le2, eq2, un2, sn2;
    logic [W-1:0] m1, x1, m2, x2;
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_lo (
      .a(cfg_lo[K*W +: W]), .b(a_res[l*W +: W]), .lt(lt1), .le(le1), .eq(eq1), .unordered(un1), .snan(sn1), .vmin(m1), .vmax(x1));
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_hi (
      .a(a_res[l*W +: W]), .b(cfg_hi[K*W +: W]), .lt(lt2), .le(le2), .eq(eq2), .unordered(un2), .snan(sn2), .vmin(m2), .vmax(x2));
    assign in_bounds[l] = le1 && le2;
  end

  // ---- arg-min ------------------------------------------------------------------------------
  logic         rc_iv, rc_ir, rc_ov, rc_or, rc_any;
  logic [W-1:0] rc_val;
  logic [15:0]  rc_idx;
  logic [4:0]   rc_ff;
  logic [LANES-1:0]   rvalid;
  logic [LANES*W-1:0] objv;
  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      objv[l*W +: W] = obj_q[l];
      rvalid[l] = (uop_q.ins.func == flux_pkg::SR_LOCAL) ? (feas_q[l] && (l < 2 * int'(cfg_dims))) : feas_q[l];
    end
  end
  reduction_core #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_red (
    .clk(clk), .rst_n(rst_n), .in_valid(rc_iv), .in_ready(rc_ir), .func(4'(flux_pkg::RED_ARGMIN)), .rm(3'(flux_pkg::RM_RNE)),
    .a(objv), .b('0), .valid(rvalid), .out_valid(rc_ov), .out_ready(rc_or),
    .value(rc_val), .index(rc_idx), .any(rc_any), .fflags(rc_ff));
  assign rc_iv = (state == S_RED);
  assign rc_or = (state == S_RED_W);

  // comparisons on the arg-min result
  logic val_nan, lt_best, lt_fc;
  logic c1_le, c1_eq, c1_un, c1_sn, c2_le, c2_eq, c2_un, c2_sn;
  logic [W-1:0] c1_mn, c1_mx, c2_mn, c2_mx;
  assign val_nan = (rc_val[W-2:MAN_W] == '1) && (rc_val[MAN_W-1:0] != '0);
  fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_cb (
    .a(rc_val), .b(best_q), .lt(lt_best), .le(c1_le), .eq(c1_eq), .unordered(c1_un), .snan(c1_sn), .vmin(c1_mn), .vmax(c1_mx));
  fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_cf (
    .a(rc_val), .b(obj_q[LANES-1]), .lt(lt_fc), .le(c2_le), .eq(c2_eq), .unordered(c2_un), .snan(c2_sn), .vmin(c2_mn), .vmax(c2_mx));

  // convergence: all active steps below their minimum
  logic [3:0] below;
  for (genvar d = 0; d < 4; d++) begin : g_cv
    logic le, eq, un, sn;
    logic [W-1:0] mn, mx;
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_c (
      .a(step_q[d]), .b(cfg_min_step[d*W +: W]), .lt(below[d]), .le(le), .eq(eq), .unordered(un), .snan(sn), .vmin(mn), .vmax(mx));
  end
  logic all_below;
  always_comb begin
    all_below = 1'b1;
    for (int d = 0; d < 4; d++) if (d < int'(cfg_dims) && !below[d]) all_below = 1'b0;
  end

  assign req_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state    <= S_IDLE;
      best_q   <= PINF;
      bidx_q   <= '1;
      iter_q   <= '0;
      conv_q   <= 1'b0;
      fc_q     <= PINF;
      center_q <= '0;
      step_q   <= '0;
      cand_q   <= '0;
    end else begin
      case (state)
        S_IDLE: if (req_valid) begin
          uop_q   <= req_uop;
          lmask_q <= req_lmask;
          dim_q   <= req_uop.ins.imm[1:0];
          fault_q <= 1'b0;
          for (int l = 0; l < LANES; l++) begin
            obj_q[l]  <= req_a[l*W +: W];
            feas_q[l] <= req_lmask[l] && req_vm[l];
            lf_q[l]   <= '0;
          end
          case (req_uop.ins.func)
            flux_pkg::SR_RESET: begin
              best_q  <= PINF;
              bidx_q  <= '1;
              iter_q  <= '0;
              conv_q  <= 1'b0;
              fc_q    <= PINF;
              fault_q <= !dims_ok;
              for (int d = 0; d < 4; d++) begin
                center_q[d] <= cfg_center0[d*W +: W];
                step_q[d]   <= cfg_step0[d*W +: W];
              end
              state <= S_RESP;
            end
            flux_pkg::SR_GRID:  state <= S_RED;
            flux_pkg::SR_LOCAL: state <= conv_q ? S_RESP : S_RED;
            default:  state <= S_GEN_I;      // SR_LS_GEN
          endcase
        end
        S_GEN_I: if (a_ir) state <= S_GEN_W;
        S_GEN_W: if (a_ov) begin
          for (int l = 0; l < LANES; l++) begin
            if (l < 2 * int'(cfg_dims)) begin
              cand_q[l] <= a_res[l*W +: W];
              vm_q[l]   <= in_bounds[l];
              out_q[l]  <= ((l / 2) == int'(dim_q)) ? a_res[l*W +: W] : center_q[dim_q];
              lf_q[l]   <= ((l / 2) == int'(dim_q)) ? a_ff[l*5 +: 5] : '0;
            end else begin
              vm_q[l]   <= (l == LANES - 1);
              out_q[l]  <= center_q[dim_q];
            end
          end
          state <= S_RESP;
        end
        S_RED: if (rc_ir) state <= S_RED_W;
        S_RED_W: if (rc_ov) begin
          if (uop_q.ins.func == flux_pkg::SR_GRID) begin
            if (rc_any && !val_nan && lt_best) begin
              best_q <= rc_val;
              bidx_q <= sweep_base + 32'(rc_idx);
            end
            state <= S_RESP;
          end else begin
            fault_q <= !feas_q[LANES-1] ||
                       ((obj_q[LANES-1][W-2:MAN_W] == '1) && (obj_q[LANES-1][MAN_W-1:0] != '0));
            if (rc_any && !val_nan && lt_fc) begin
              center_q[2'(rc_idx >> 1)] <= cand_q[rc_idx[LW_IDX-1:0]];
              fc_q  <= rc_val;
              state <= S_CONV;
            end else begin
              fc_q  <= obj_q[LANES-1];
              state <= S_HALF_I;
            end
          end
        end
        S_HALF_I: if (a_ir) state <= S_HALF_W;
        S_HALF_W: if (a_ov) begin
          for (int d = 0; d < 4; d++) step_q[d] <= a_res[d*W +: W];
          state <= S_CONV;
        end
        S_CONV: begin
          best_q <= fc_q;
          iter_q <= iter_q + 16'd1;
          conv_q <= all_below || ((iter_q + 16'd1) >= cfg_max_iter);
          state  <= S_RESP;
        end
        S_RESP: if (rsp_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end
  always_comb begin
    rsp_fflags = '0;
    rsp_faults = '0;
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W]   = out_q[l];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qual_of(out_q[l], lf_q[l]);
      if (lmask_q[l] && uop_q.ins.func == flux_pkg::SR_LS_GEN) rsp_fflags |= lf_q[l];
    end
    rsp_faults[flux_pkg::F_SEARCH] = fault_q;
  end
  assign rsp_valid  = (state == S_RESP);
  assign rsp_uop    = uop_q;
  assign rsp_wmask  = lmask_q;
  assign rsp_vm     = vm_q;
  assign best       = best_q;
  assign best_index = bidx_q;
  assign iter       = iter_q;
  assign converged  = conv_q;
  for (genvar d = 0; d < 4; d++) begin : g_o
    assign center[d*W +: W] = center_q[d];
    assign step[d*W +: W]   = step_q[d];
  end
endmodule
