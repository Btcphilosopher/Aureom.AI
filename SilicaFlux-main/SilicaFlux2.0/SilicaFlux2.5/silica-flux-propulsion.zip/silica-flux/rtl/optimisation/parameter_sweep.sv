// =============================================================================
// Silica Flux -- parameter-sweep engine (FU_SWEEP)
// -----------------------------------------------------------------------------
// Generates a full-factorial grid over up to four abstract parameters
// P_d = lo_d + i_d * step_d,  i_d in [0, count_d), and evaluates LANES grid
// candidates concurrently: lane l of a batch holds candidate  base + l.
//
//   SWEEP func=RESET          base <- 0, lane l <- mixed-radix digits of l
//   SWEEP vd, func=GEN, imm=d vd[l] = fma(i_d(l), step_d, lo_d),  VM = valid
//   SWEEP func=NEXT           base += LANES (digit counters advance LANES)
//
// Mixed-radix digit counters are kept per lane and advanced by repeated
// increment (LANES cycles per NEXT), so no divider is required to map a
// candidate index to its grid coordinates.  The engine is generic numerical
// infrastructure: the parameters have no physical meaning in hardware.
// =============================================================================
`include "flux_fu_if.svh"
module parameter_sweep #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic             clk,
  input  logic             rst_n,
  `SF_FU_PORTS,
  input  logic [2:0]       cfg_dims,
  input  logic [4*W-1:0]   cfg_lo,
  input  logic [4*W-1:0]   cfg_step,
  input  logic [4*32-1:0]  cfg_count,
  output logic [31:0]      base,
  output logic [31:0]      total,
  output logic             done,
  output logic             cfg_ok
);
  `include "flux_q.svh"
  localparam int CW = $clog2(LANES + 1);

  typedef enum logic [2:0] {S_IDLE, S_INC, S_ISSUE, S_WAIT, S_RESP} state_t;
  state_t state;

  flux_pkg::uop_t                          uop_q;
  logic [LANES-1:0]              lmask_q;
  logic [63:0]                   dg_q [LANES];   // 4 x 16-bit digits per lane
  logic [31:0]                   base_q;
  logic                          done_q;
  logic [CW-1:0]                 cnt_q;
  logic                          reset_mode_q;
  logic [LANES-1:0][W-1:0]       v_q;
  logic [LANES-1:0][4:0]         lf_q;

  // ---- configuration check / grid size --------------------------------------------
  logic [63:0] tot64;
  always_comb begin
    tot64  = 64'd1;
    cfg_ok = (cfg_dims >= 3'd1) && (cfg_dims <= 3'd4);
    for (int d = 0; d < 4; d++) begin
      logic [31:0] c;
      c = cfg_count[d*32 +: 32];
      if (d < int'(cfg_dims)) begin
        if (c == 32'd0 || c > 32'd65535) cfg_ok = 1'b0;
        if (cfg_lo[d*W + W-2 -: EXP_W] == '1 || cfg_step[d*W + W-2 -: EXP_W] == '1) cfg_ok = 1'b0;
        tot64 = tot64 * {48'd0, c[15:0]};
      end
    end
    if (tot64 >= 64'h1_0000_0000) cfg_ok = 1'b0;
  end
  assign total = tot64[31:0];

  // ---- mixed-radix increment of one lane ----------------------------------------------------
  function automatic logic [63:0] inc(input logic [63:0] d_in);
    logic [63:0] d;
    logic carry;
    d = d_in;
    carry = 1'b1;
    for (int k = 0; k < 4; k++) begin
      if (carry && k < int'(cfg_dims)) begin
        if (32'(d[k*16 +: 16]) + 32'd1 >= cfg_count[k*32 +: 32]) d[k*16 +: 16] = '0;
        else begin d[k*16 +: 16] = d[k*16 +: 16] + 16'd1; carry = 1'b0; end
      end
    end
    inc = d;
  endfunction

  // ---- FMA array: lo + digit * step ---------------------------------------------------------
  logic               a_iv, a_ir, a_ov, a_or;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  logic [1:0]         dim_q;
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(3'(flux_pkg::FMA_FMADD)), .rm(uop_q.rm),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  for (genvar l = 0; l < LANES; l++) begin : g_d
    logic [W-1:0] dfp;
    logic [16:0] dv;
    assign dv = {1'b0, dg_q[l][dim_q*16 +: 16]};
    fp_from_int #(.EXP_W(EXP_W), .MAN_W(MAN_W), .IW(17)) u_i2f (.v(dv), .f(dfp));
    assign a_a[l*W +: W] = dfp;
    assign a_b[l*W +: W] = cfg_step[dim_q*W +: W];
    assign a_c[l*W +: W] = cfg_lo[dim_q*W +: W];
  end
  assign a_iv = (state == S_ISSUE);
  assign a_or = (state == S_WAIT);
  assign req_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state  <= S_IDLE;
      base_q <= '0;
      done_q <= 1'b0;
      for (int l = 0; l < LANES; l++) dg_q[l] <= '0;
    end else begin
      case (state)
        S_IDLE: if (req_valid) begin
          uop_q   <= req_uop;
          lmask_q <= req_lmask;
          dim_q   <= req_uop.ins.imm[1:0];
          cnt_q   <= '0;
          case (req_uop.ins.func)
            flux_pkg::SW_RESET: begin
              for (int l = 0; l < LANES; l++) dg_q[l] <= '0;
              base_q       <= '0;
              done_q       <= 1'b0;
              reset_mode_q <= 1'b1;
              state        <= (LANES > 1) ? S_INC : S_RESP;
            end
            flux_pkg::SW_NEXT: begin
              reset_mode_q <= 1'b0;
              state        <= S_INC;
            end
            default: state <= S_ISSUE;
          endcase
        end
        S_INC: begin
          for (int l = 0; l < LANES; l++)
            if (!reset_mode_q || l > int'(cnt_q)) dg_q[l] <= inc(dg_q[l]);
          if (cnt_q == CW'(reset_mode_q ? LANES - 2 : LANES - 1)) begin
            state <= S_RESP;
            if (!reset_mode_q) begin
              base_q <= base_q + 32'(LANES);
              done_q <= (base_q + 32'(LANES)) >= total;
            end
          end
          cnt_q <= cnt_q + CW'(1);
        end
        S_ISSUE: if (a_ir) state <= S_WAIT;
        S_WAIT:  if (a_ov) begin
          for (int l = 0; l < LANES; l++) begin
            v_q[l]  <= a_res[l*W +: W];
            lf_q[l] <= a_ff[l*5 +: 5];
          end
          state <= S_RESP;
        end
        S_RESP: if (rsp_ready) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end

  always_comb begin
    rsp_fflags = '0;
    rsp_faults = '0;
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W]   = v_q[l];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qual_of(v_q[l], lf_q[l]);
      rsp_vm[l]            = cfg_ok && ((64'(base_q) + 64'(l)) < tot64);
      if (lmask_q[l] && uop_q.ins.func == flux_pkg::SW_GEN) rsp_fflags |= lf_q[l];
    end
    rsp_faults[flux_pkg::F_SEARCH] = !cfg_ok;
  end
  assign rsp_valid = (state == S_RESP);
  assign rsp_uop   = uop_q;
  assign rsp_wmask = lmask_q;
  assign base      = base_q;
  assign done      = done_q;
endmodule
