// =============================================================================
// Silica Flux -- constraint engine (FU_CON)
// -----------------------------------------------------------------------------
//   CONSTRAINT vd, vs1=x, vs2=bound/target b, vs3=tolerance, func=kind
//     LT   x <  b     margin = b - x          PASS iff margin >  0
//     LE   x <= b     margin = b - x          PASS iff margin >= 0
//     GT   x >  b     margin = x - b          PASS iff margin >  0
//     GE   x >= b     margin = x - b          PASS iff margin >= 0
//     EQ   x == b     margin = -|x - b|       PASS iff margin == 0
//     TOL  |x-b|<tol  margin = tol - |x - b|  PASS iff margin >  0
//   vd = MARGIN, VM = PASS mask; FAIL = active & !PASS.
//   A NaN anywhere yields a NaN margin and FAIL -- never a silent PASS.
//
// Independent of the objective engine.  Pass / fail counters are exported to
// CSRs; a failure raises the informational fault F_CONSTRAINT.
// =============================================================================
`include "flux_fu_if.svh"
module constraint_eval #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic         clk,
  input  logic         rst_n,
  `SF_FU_PORTS,
  output logic [31:0]  pass_count,
  output logic [31:0]  fail_count,
  output logic [LANES-1:0] last_pass
);
  `include "flux_q.svh"
  localparam logic [W-1:0] ONE = {2'b00, {(EXP_W-1){1'b1}}, {MAN_W{1'b0}}};

  typedef enum logic [2:0] {S_IDLE, S_I1, S_W1, S_I2, S_W2, S_RESP} state_t;
  state_t state;
  flux_pkg::uop_t                     uop_q;
  logic [LANES-1:0]         lmask_q;
  logic [LANES-1:0][W-1:0]  x_q, b_q, tl_q, m_q;
  logic [LANES-1:0][flux_pkg::QW-1:0] qin_q;
  logic [LANES-1:0][4:0]    lf_q;
  logic [3:0]               kind_q;
  logic [31:0]              pc_q, fc_q;
  logic [LANES-1:0]         lp_q;

  logic               a_iv, a_ir, a_ov, a_or;
  logic [LANES*W-1:0] a_a, a_b, a_c, a_res;
  logic [LANES*5-1:0] a_ff;
  sf_fma_array #(.N(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_arr (
    .clk(clk), .rst_n(rst_n), .in_valid(a_iv), .in_ready(a_ir), .op(3'(flux_pkg::FMA_FSUB)), .rm(uop_q.rm),
    .a(a_a), .b(a_b), .c(a_c), .out_valid(a_ov), .out_ready(a_or), .res(a_res), .ff(a_ff));
  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      a_b[l*W +: W] = ONE;
      if (state == S_I2 || state == S_W2) begin          // TOL: tol - |d|
        a_a[l*W +: W] = tl_q[l];
        a_c[l*W +: W] = fabs(m_q[l]);
      end else if (kind_q == flux_pkg::CON_LT || kind_q == flux_pkg::CON_LE) begin
        a_a[l*W +: W] = b_q[l];
        a_c[l*W +: W] = x_q[l];
      end else begin
        a_a[l*W +: W] = x_q[l];
        a_c[l*W +: W] = b_q[l];
      end
    end
  end
  assign a_iv = (state == S_I1) || (state == S_I2);
  assign a_or = (state == S_W1) || (state == S_W2);
  assign req_ready = (state == S_IDLE);

  // pass evaluation on the final margin
  logic [LANES-1:0]        pass;
  logic [LANES-1:0][W-1:0] mfin;
  for (genvar l = 0; l < LANES; l++) begin : g_p
    logic lt, le, eq, un, sn;
    logic [W-1:0] mn, mx, m;
    logic m_nan;
    assign m_nan = (m_q[l][W-2:MAN_W] == '1) && (m_q[l][MAN_W-1:0] != '0);
    assign m = (kind_q == flux_pkg::CON_EQ && !m_nan) ? fnabs(m_q[l]) : m_q[l];
    assign mfin[l] = m;
    fp_compare #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_c (
      .a({W{1'b0}}), .b(m), .lt(lt), .le(le), .eq(eq), .unordered(un), .snan(sn), .vmin(mn), .vmax(mx));
    always_comb begin
      case (kind_q)
        flux_pkg::CON_LE, flux_pkg::CON_GE: pass[l] = le;
        flux_pkg::CON_EQ:         pass[l] = eq;
        default:        pass[l] = lt;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      state <= S_IDLE; pc_q <= '0; fc_q <= '0; lp_q <= '0;
    end else begin
      case (state)
        S_IDLE: if (req_valid) state <= S_I1;
        S_I1:   if (a_ir) state <= S_W1;
        S_W1:   if (a_ov) state <= (kind_q == flux_pkg::CON_TOL) ? S_I2 : S_RESP;
        S_I2:   if (a_ir) state <= S_W2;
        S_W2:   if (a_ov) state <= S_RESP;
        S_RESP: if (rsp_ready) begin
          state <= S_IDLE;
          pc_q  <= pc_q + 32'($countones(pass & lmask_q));
          fc_q  <= fc_q + 32'($countones(~pass & lmask_q));
          lp_q  <= pass & lmask_q;
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (state)
      S_IDLE: if (req_valid) begin
        uop_q   <= req_uop;
        lmask_q <= req_lmask;
        kind_q  <= req_uop.ins.func;
        for (int l = 0; l < LANES; l++) begin
          x_q[l]   <= req_a[l*W +: W];
          b_q[l]   <= req_b[l*W +: W];
          tl_q[l]  <= req_c[l*W +: W];
          lf_q[l]  <= '0;
          qin_q[l] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW] | req_qb[l*flux_pkg::QW +: flux_pkg::QW] |
                      ((req_uop.ins.func == flux_pkg::CON_TOL) ? req_qc[l*flux_pkg::QW +: flux_pkg::QW] : '0);
        end
      end
      S_W1: if (a_ov) for (int l = 0; l < LANES; l++) begin
        m_q[l] <= a_res[l*W +: W]; lf_q[l] <= a_ff[l*5 +: 5];
      end
      S_W2: if (a_ov) for (int l = 0; l < LANES; l++) begin
        m_q[l] <= a_res[l*W +: W]; lf_q[l] <= lf_q[l] | a_ff[l*5 +: 5];
      end
      default: ;
    endcase
  end

  always_comb begin
    rsp_fflags = '0;
    rsp_faults = '0;
    for (int l = 0; l < LANES; l++) begin
      rsp_data[l*W +: W]   = mfin[l];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = qin_q[l] | qual_of(mfin[l], lf_q[l]);
      if (lmask_q[l]) rsp_fflags |= lf_q[l];
    end
    rsp_faults[flux_pkg::F_CONSTRAINT] = |(~pass & lmask_q);
  end
  assign rsp_valid  = (state == S_RESP);
  assign rsp_uop    = uop_q;
  assign rsp_wmask  = lmask_q;
  assign rsp_vm     = pass;
  assign pass_count = pc_q;
  assign fail_count = fc_q;
  assign last_pass  = lp_q;
endmodule
