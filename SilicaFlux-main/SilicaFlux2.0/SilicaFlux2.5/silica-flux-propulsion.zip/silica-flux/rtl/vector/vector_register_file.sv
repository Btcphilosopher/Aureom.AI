// =============================================================================
// Silica Flux -- vector register file
// -----------------------------------------------------------------------------
//   NREG registers x LANES elements x (W data + QW quality bits)
//   3 synchronous read ports (vs1, vs2, vs3) -- read on issue, data held stable
//     until the next read enable (models an SRAM macro with output latches)
//   1 write port with per-lane write mask (write-back stage)
//   per-register metadata (meta_t: valid, precision, scale, source, timestamp)
//     readable combinationally by the scheduler for precision checking
//   the vector mask register VM (LANES bits) with per-lane write mask
//
// Write-before-read is not required: the scoreboard releases a destination
// one cycle after its write, so a dependent read always sees the new value.
// =============================================================================
module vector_register_file #(
  parameter int LANES = 8,
  parameter int W     = 32,
  parameter int NREG  = 32
) (
  input  logic                          clk,
  input  logic                          rst_n,
  input  logic                          job_init, // START: VM = all ones, every register unwritten
  // read
  input  logic                          re,
  input  logic [4:0]                    ra1,
  input  logic [4:0]                    ra2,
  input  logic [4:0]                    ra3,
  output logic [LANES*W-1:0]            rd1,
  output logic [LANES*W-1:0]            rd2,
  output logic [LANES*W-1:0]            rd3,
  output logic [LANES*flux_pkg::QW-1:0] rq1,
  output logic [LANES*flux_pkg::QW-1:0] rq2,
  output logic [LANES*flux_pkg::QW-1:0] rq3,
  output logic [LANES-1:0]              rvm,      // VM sampled with the operands
  // write
  input  logic                          we,
  input  logic [4:0]                    wa,
  input  logic [LANES-1:0]              wmask,
  input  logic [LANES*W-1:0]            wd,
  input  logic [LANES*flux_pkg::QW-1:0] wq,
  input  logic                          meta_we,
  input  flux_pkg::meta_t               meta_wd,
  input  logic                          vm_we,
  input  logic [LANES-1:0]              vm_wmask,
  input  logic [LANES-1:0]              vm_wd,
  // metadata (combinational)
  output logic [NREG-1:0][flux_pkg::META_W-1:0] meta,   // meta_t per register
  output logic [LANES-1:0]              vm
);
  localparam int EW = W + flux_pkg::QW;

  logic [LANES*EW-1:0] regs [NREG];
  logic [NREG-1:0][flux_pkg::META_W-1:0] meta_q;
  logic [LANES-1:0]    vm_q;

`ifndef SYNTHESIS
  // simulation only: deterministic power-up contents (reads of never-written
  // registers are rejected by the scheduler with F_UNINIT in any case)
  initial for (int r = 0; r < NREG; r++) regs[r] = '0;
`endif

  // ---- write -------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (we) begin
      for (int l = 0; l < LANES; l++)
        if (wmask[l]) regs[wa][l*EW +: EW] <= {wq[l*flux_pkg::QW +: flux_pkg::QW], wd[l*W +: W]};
    end
  end
  // Job state is (re)initialised by reset and by every START: a program can
  // never silently consume a register or mask left behind by an earlier job
  // (reading such a register raises F_UNINIT).  Register contents persist.
  always_ff @(posedge clk) begin
    if (!rst_n || job_init) begin
      meta_q <= '0;
      vm_q   <= '1;
    end else begin
      if (meta_we) meta_q[wa] <= meta_wd;
      if (vm_we) begin
        for (int l = 0; l < LANES; l++) if (vm_wmask[l]) vm_q[l] <= vm_wd[l];
      end
    end
  end

  // ---- read ---------------------------------------------------------------------
  logic [LANES*EW-1:0] r1, r2, r3;
  always_ff @(posedge clk) begin
    if (re) begin
      r1  <= regs[ra1];
      r2  <= regs[ra2];
      r3  <= regs[ra3];
      rvm <= vm_q;
    end
  end
  always_comb begin
    for (int l = 0; l < LANES; l++) begin
      rd1[l*W +: W] = r1[l*EW +: W];  rq1[l*flux_pkg::QW +: flux_pkg::QW] = r1[l*EW + W +: flux_pkg::QW];
      rd2[l*W +: W] = r2[l*EW +: W];  rq2[l*flux_pkg::QW +: flux_pkg::QW] = r2[l*EW + W +: flux_pkg::QW];
      rd3[l*W +: W] = r3[l*EW +: W];  rq3[l*flux_pkg::QW +: flux_pkg::QW] = r3[l*EW + W +: flux_pkg::QW];
    end
  end
  assign meta = meta_q;
  assign vm   = vm_q;
endmodule
