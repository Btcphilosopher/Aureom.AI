// =============================================================================
// Silica Flux -- one lane of the vector ALU
// -----------------------------------------------------------------------------
// Two datapaths in lockstep, both LATENCY elastic stages deep:
//   * fma_unit   : FP ADD / SUB / MUL / FMA / FMS / FNMA / FNMS / SQR
//   * scalar_alu : everything else (combinational) followed by a delay line
//                  with exactly the FMA's stage structure.
// Every request enters both paths; the result is selected at the output.
// Because the two pipelines share in_valid / out_ready and have identical
// stage-ready logic, their valid bits are identical by construction
// (asserted in formal/assertions.sv), so the lane has one fixed latency.
// =============================================================================
module vector_lane #(
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int LANE    = 0,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          in_valid,
  output logic          in_ready,
  input  logic [7:0]    opcode,
  input  logic [2:0]    prec,
  input  logic [3:0]    func,
  input  logic [18:0]   imm,
  input  logic [2:0]    rm,
  input  logic [W-1:0]  a,
  input  logic [W-1:0]  b,
  input  logic [W-1:0]  c,
  input  logic          vm_bit,
  output logic          out_valid,
  input  logic          out_ready,
  output logic [W-1:0]  res,
  output logic [4:0]    ff,
  output logic          mbit
);

  // ---- routing -------------------------------------------------------------------
  logic       is_fp, use_fma;
  logic [2:0] fop;
  logic [W-1:0] fa, fb, fc;
  always_comb begin
    is_fp   = (prec == flux_pkg::PREC_FP32) || (prec == flux_pkg::PREC_FP64);
    use_fma = 1'b1;
    fa = a; fb = b; fc = c;
    case (opcode)
      flux_pkg::OP_VADD:  begin fop = flux_pkg::FMA_FADD;   fc = b; end
      flux_pkg::OP_VSUB:  begin fop = flux_pkg::FMA_FSUB;   fc = b; end
      flux_pkg::OP_VMUL:  fop = flux_pkg::FMA_FMUL;
      flux_pkg::OP_VSQR:  begin fop = flux_pkg::FMA_FMUL;   fb = a; end
      flux_pkg::OP_VFMA:  fop = flux_pkg::FMA_FMADD;
      flux_pkg::OP_VFMS:  fop = flux_pkg::FMA_FMSUB;
      flux_pkg::OP_VFNMA: fop = flux_pkg::FMA_FNMSUB;
      flux_pkg::OP_VFNMS: fop = flux_pkg::FMA_FNMADD;
      default:  begin fop = flux_pkg::FMA_FMUL; use_fma = 1'b0; end
    endcase
    if (!is_fp) use_fma = 1'b0;
  end

  // ---- FMA path ----------------------------------------------------------------------
  logic         f_in_ready, f_out_valid;
  logic [W-1:0] f_res;
  logic [4:0]   f_ff;
  logic [0:0]   f_tag;
  fma_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY), .TAG_W(1)) u_fma (
    .clk(clk), .rst_n(rst_n),
    .in_valid(in_valid), .in_ready(f_in_ready),
    .op(fop), .rm(rm), .a(fa), .b(fb), .c(fc), .in_tag(use_fma),
    .out_valid(f_out_valid), .out_ready(out_ready),
    .result(f_res), .fflags(f_ff), .out_tag(f_tag));

  // ---- ALU path ------------------------------------------------------------------------
  logic [W-1:0] s_res;
  logic [4:0]   s_ff;
  logic         s_mbit;
  scalar_alu #(.EXP_W(EXP_W), .MAN_W(MAN_W), .LANE(LANE)) u_alu (
    .opcode(opcode), .prec(prec), .func(func), .imm(imm), .rm(rm),
    .a(a), .b(b), .c(c), .vm_bit(vm_bit), .res(s_res), .ff(s_ff), .mbit(s_mbit));

  localparam int DW = W + 5 + 1;
  logic [LATENCY:0]         dv, dr;
  logic [LATENCY:0][DW-1:0] dd;
  assign dv[0] = in_valid;
  assign dd[0] = {s_res, s_ff, s_mbit};
  for (genvar k = 0; k < LATENCY; k++) begin : g_dl
    sf_pipe_reg #(.W(DW)) u_dl (
      .clk(clk), .rst_n(rst_n),
      .in_valid(dv[k]), .in_ready(dr[k]), .in_data(dd[k]),
      .out_valid(dv[k+1]), .out_ready(dr[k+1]), .out_data(dd[k+1]));
  end
  assign dr[LATENCY] = out_ready;

  // ---- output ----------------------------------------------------------------------------
  logic [W-1:0] d_res;
  logic [4:0]   d_ff;
  logic         d_mbit;
  assign {d_res, d_ff, d_mbit} = dd[LATENCY];
  assign in_ready  = f_in_ready;        // == dr[0] by construction
  assign out_valid = f_out_valid;       // == dv[LATENCY] by construction
  assign res       = f_tag[0] ? f_res : d_res;
  assign ff        = f_tag[0] ? f_ff  : d_ff;
  assign mbit      = d_mbit;

`ifdef SF_SVA
  // the two lockstep pipelines must never diverge
  a_lockstep_valid: assert property (@(posedge clk) disable iff (!rst_n) f_out_valid == dv[LATENCY]);
  a_lockstep_ready: assert property (@(posedge clk) disable iff (!rst_n) f_in_ready == dr[0]);
`endif
endmodule
