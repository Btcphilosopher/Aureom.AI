// =============================================================================
// Silica Flux -- vector arithmetic pipeline cluster
// -----------------------------------------------------------------------------
//   vector_pipeline      bundles the three arithmetic functional units
//                        FU 0  VALU     (vector_alu, fixed latency, pipelined)
//                        FU 1  DIVSQRT  (LANES x {divider, sqrt_unit}, iterative)
//                        FU 2  SFU      (LANES x {reciprocal, exp, log}, iterative)
//   vector_iter_array    generic lockstep array of iterative per-lane units:
//                        all active lanes start together; the response is
//                        presented when every active lane has finished, so
//                        operand-dependent latencies (special cases finish
//                        early) never reorder lanes.
// =============================================================================
`include "flux_fu_if.svh"
module vector_iter_array #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int KIND    = 0,           // 0 = DIV/SQRT, 1 = SFU
  parameter int DIV_BPC = 1,           // divider / sqrt bits per cycle
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic clk,
  input  logic rst_n,
  `SF_FU_PORTS
);

  logic                busy_q;
  flux_pkg::uop_t                uop_q;
  logic [LANES-1:0]    lmask_q;
  logic [LANES*flux_pkg::QW-1:0] qin_q;
  logic [1:0]          sel_q;           // which unit within the lane
  logic [1:0]          sel_d;
  logic                accept, deliver;

  always_comb begin
    case (req_uop.ins.opcode)
      flux_pkg::OP_VSQRT, flux_pkg::OP_VEXP: sel_d = 2'd1;
      flux_pkg::OP_VLOG:           sel_d = 2'd2;
      default:           sel_d = 2'd0;   // VDIV, VRECIP
    endcase
  end

  assign req_ready = !busy_q;
  assign accept    = req_valid && req_ready;

  logic [LANES-1:0]   done;
  logic [LANES*W-1:0] res;
  logic [LANES*5-1:0] ffl;
  assign rsp_valid = busy_q && (&done);
  assign deliver   = rsp_valid && rsp_ready;

  for (genvar l = 0; l < LANES; l++) begin : g_lane
    logic [W-1:0] a_l, b_l;
    logic         go;
    assign a_l = req_a[l*W +: W];
    assign b_l = req_b[l*W +: W];
    assign go  = accept && req_lmask[l];
    logic         uv0, uv1, uv2, ur0, ur1, ur2, ub0, ub1, ub2;
    logic [W-1:0] ures0, ures1, ures2;
    logic [4:0]   uff0, uff1, uff2;
    logic [7:0]   ut0, ut1, ut2;
    if (KIND == 0) begin : g_ds
      divider #(.EXP_W(EXP_W), .MAN_W(MAN_W), .BITS_PER_CYCLE(DIV_BPC)) u_div (
        .clk(clk), .rst_n(rst_n), .in_valid(go && sel_d == 2'd0), .in_ready(ur0),
        .a(a_l), .b(b_l), .rm(req_uop.rm), .in_tag(8'd0),
        .out_valid(uv0), .out_ready(deliver), .result(ures0), .fflags(uff0), .out_tag(ut0), .busy(ub0));
      sqrt_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W), .BITS_PER_CYCLE(DIV_BPC)) u_sqrt (
        .clk(clk), .rst_n(rst_n), .in_valid(go && sel_d == 2'd1), .in_ready(ur1),
        .a(a_l), .rm(req_uop.rm), .in_tag(8'd0),
        .out_valid(uv1), .out_ready(deliver), .result(ures1), .fflags(uff1), .out_tag(ut1), .busy(ub1));
      assign uv2 = 1'b0; assign ures2 = '0; assign uff2 = '0; assign ur2 = 1'b0; assign ut2 = '0; assign ub2 = 1'b0;
    end else begin : g_sfu
      reciprocal_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_rcp (
        .clk(clk), .rst_n(rst_n), .in_valid(go && sel_d == 2'd0), .in_ready(ur0),
        .a(a_l), .in_tag(8'd0), .out_valid(uv0), .out_ready(deliver), .result(ures0),
        .fflags(uff0), .out_tag(ut0), .busy(ub0));
      exp_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_exp (
        .clk(clk), .rst_n(rst_n), .in_valid(go && sel_d == 2'd1), .in_ready(ur1),
        .a(a_l), .in_tag(8'd0), .out_valid(uv1), .out_ready(deliver), .result(ures1),
        .fflags(uff1), .out_tag(ut1), .busy(ub1));
      log_unit #(.EXP_W(EXP_W), .MAN_W(MAN_W)) u_log (
        .clk(clk), .rst_n(rst_n), .in_valid(go && sel_d == 2'd2), .in_ready(ur2),
        .a(a_l), .in_tag(8'd0), .out_valid(uv2), .out_ready(deliver), .result(ures2),
        .fflags(uff2), .out_tag(ut2), .busy(ub2));
    end
    logic         uv_s;
    logic [W-1:0] ures_s;
    logic [4:0]   uff_s;
    always_comb begin
      case (sel_q)
        2'd1:    begin uv_s = uv1; ures_s = ures1; uff_s = uff1; end
        2'd2:    begin uv_s = uv2; ures_s = ures2; uff_s = uff2; end
        default: begin uv_s = uv0; ures_s = ures0; uff_s = uff0; end
      endcase
    end
    assign done[l]          = !lmask_q[l] || uv_s;
    assign res[l*W +: W]    = lmask_q[l] ? ures_s : '0;
    assign ffl[l*5 +: 5]    = lmask_q[l] ? uff_s : '0;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) busy_q <= 1'b0;
    else if (accept) busy_q <= 1'b1;
    else if (deliver) busy_q <= 1'b0;
  end
  always_ff @(posedge clk) begin
    if (accept) begin
      uop_q   <= req_uop;
      lmask_q <= req_lmask;
      sel_q   <= sel_d;
      for (int l = 0; l < LANES; l++)
        qin_q[l*flux_pkg::QW +: flux_pkg::QW] <= req_qa[l*flux_pkg::QW +: flux_pkg::QW] |
                             ((req_uop.ins.opcode == flux_pkg::OP_VDIV) ? req_qb[l*flux_pkg::QW +: flux_pkg::QW] : '0);
    end
  end

  assign rsp_uop    = uop_q;
  assign rsp_data   = res;
  assign rsp_wmask  = lmask_q;
  assign rsp_vm     = '0;
  assign rsp_faults = '0;
  always_comb begin
    rsp_fflags = '0;
    for (int l = 0; l < LANES; l++) begin
      logic [W-1:0]  r;
      logic [4:0]    f;
      logic [flux_pkg::QW-1:0] q;
      r = res[l*W +: W];
      f = ffl[l*5 +: 5];
      q = qin_q[l*flux_pkg::QW +: flux_pkg::QW];
      q[flux_pkg::Q_NAN] = q[flux_pkg::Q_NAN] | f[flux_pkg::FF_NV] | ((r[W-2:MAN_W] == '1) && (r[MAN_W-1:0] != '0));
      q[flux_pkg::Q_OVF] = q[flux_pkg::Q_OVF] | f[flux_pkg::FF_OF] | f[flux_pkg::FF_DZ] | ((r[W-2:MAN_W] == '1) && (r[MAN_W-1:0] == '0));
      q[flux_pkg::Q_UNF] = q[flux_pkg::Q_UNF] | f[flux_pkg::FF_UF];
      rsp_qual[l*flux_pkg::QW +: flux_pkg::QW] = lmask_q[l] ? q : '0;
      rsp_fflags |= f;
    end
  end
endmodule

// -----------------------------------------------------------------------------
module vector_pipeline #(
  parameter int LANES   = 8,
  parameter int EXP_W   = 8,
  parameter int MAN_W   = 23,
  parameter int LATENCY = 4,
  parameter int DIV_BPC = 1,
  parameter int W       = EXP_W + MAN_W + 1
) (
  input  logic                          clk,
  input  logic                          rst_n,
  input  logic [2:0]                    req_valid,
  output logic [2:0]                    req_ready,
  input  flux_pkg::uop_t                req_uop,
  input  logic [LANES*W-1:0]            req_a,
  input  logic [LANES*W-1:0]            req_b,
  input  logic [LANES*W-1:0]            req_c,
  input  logic [LANES*flux_pkg::QW-1:0] req_qa,
  input  logic [LANES*flux_pkg::QW-1:0] req_qb,
  input  logic [LANES*flux_pkg::QW-1:0] req_qc,
  input  logic [LANES-1:0]              req_lmask,
  input  logic [LANES-1:0]              req_vm,
  output logic [2:0]                    rsp_valid,
  input  logic [2:0]                    rsp_ready,
  output logic [2:0][flux_pkg::UOP_W-1:0] rsp_uop,     // uop_t per sub-unit
  output logic [2:0][LANES*W-1:0]       rsp_data,
  output logic [2:0][LANES*flux_pkg::QW-1:0] rsp_qual,
  output logic [2:0][LANES-1:0]         rsp_wmask,
  output logic [2:0][LANES-1:0]         rsp_vm,
  output logic [2:0][4:0]               rsp_fflags,
  output logic [2:0][flux_pkg::FAULT_W-1:0] rsp_faults
);
  vector_alu #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .LATENCY(LATENCY)) u_valu (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid[0]), .req_ready(req_ready[0]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm),
    .rsp_valid(rsp_valid[0]), .rsp_ready(rsp_ready[0]), .rsp_uop(rsp_uop[0]), .rsp_data(rsp_data[0]),
    .rsp_qual(rsp_qual[0]), .rsp_wmask(rsp_wmask[0]), .rsp_vm(rsp_vm[0]), .rsp_fflags(rsp_fflags[0]),
    .rsp_faults(rsp_faults[0]));
  vector_iter_array #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .KIND(0), .DIV_BPC(DIV_BPC)) u_divsqrt (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid[1]), .req_ready(req_ready[1]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm),
    .rsp_valid(rsp_valid[1]), .rsp_ready(rsp_ready[1]), .rsp_uop(rsp_uop[1]), .rsp_data(rsp_data[1]),
    .rsp_qual(rsp_qual[1]), .rsp_wmask(rsp_wmask[1]), .rsp_vm(rsp_vm[1]), .rsp_fflags(rsp_fflags[1]),
    .rsp_faults(rsp_faults[1]));
  vector_iter_array #(.LANES(LANES), .EXP_W(EXP_W), .MAN_W(MAN_W), .KIND(1)) u_sfu (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid[2]), .req_ready(req_ready[2]), .req_uop(req_uop),
    .req_a(req_a), .req_b(req_b), .req_c(req_c), .req_qa(req_qa), .req_qb(req_qb), .req_qc(req_qc),
    .req_lmask(req_lmask), .req_vm(req_vm),
    .rsp_valid(rsp_valid[2]), .rsp_ready(rsp_ready[2]), .rsp_uop(rsp_uop[2]), .rsp_data(rsp_data[2]),
    .rsp_qual(rsp_qual[2]), .rsp_wmask(rsp_wmask[2]), .rsp_vm(rsp_vm[2]), .rsp_fflags(rsp_fflags[2]),
    .rsp_faults(rsp_faults[2]));
endmodule
