// =============================================================================
// Silica Flux -- internal memory interconnect
// -----------------------------------------------------------------------------
// Masters (fixed priority, lowest index wins -- deterministic core timing):
//   0  core load/store unit      1  DMA engine      2  host memory window
// Slaves: the seven row memories (flux_pkg::MEM_*).  One row access per
// cycle; read data and error status return exactly one cycle after the grant
// (masters always accept responses, so no response back-pressure exists).
// Illegal accesses -- unknown memory, row beyond the instantiated depth, or a
// write to the read-only telemetry table -- are blocked and reported with
// err_addr; they never reach a memory.
// =============================================================================
module internal_bus #(
  parameter int LANES = 8,
  parameter int EW    = 36,
  parameter int NM    = 3
) (
  input  logic                                 clk,
  input  logic                                 rst_n,
  // masters
  input  logic [NM-1:0]                        m_valid,
  output logic [NM-1:0]                        m_ready,
  input  logic [NM-1:0]                        m_we,
  input  logic [NM-1:0][2:0]                   m_id,
  input  logic [NM-1:0][15:0]                  m_row,
  input  logic [NM-1:0][LANES-1:0]             m_wmask,
  input  logic [NM-1:0][LANES*EW-1:0]          m_wdata,
  output logic [NM-1:0]                        m_rsp_valid,
  output logic [LANES*EW-1:0]                  rsp_rdata,
  output logic                                 rsp_err_addr,
  output logic [LANES-1:0]                     rsp_err_parity,
  // slaves
  input  logic [flux_pkg::NUM_MEMS-1:0][15:0]  s_rows,
  output logic [flux_pkg::NUM_MEMS-1:0]        s_en,
  output logic                                 s_we,
  output logic [15:0]                          s_row,
  output logic [LANES-1:0]                     s_wmask,
  output logic [LANES*EW-1:0]                  s_wdata,
  input  logic [flux_pkg::NUM_MEMS-1:0][LANES*EW-1:0] s_rdata,
  input  logic [flux_pkg::NUM_MEMS-1:0][LANES-1:0]    s_perr,
  // statistics
  output logic [31:0]                          accesses,
  output logic [31:0]                          conflicts
);
  logic [$clog2(NM+1)-1:0] g;
  logic                    any, ok;
  always_comb begin
    any = 1'b0;
    g   = '0;
    for (int m = NM - 1; m >= 0; m--) if (m_valid[m]) begin any = 1'b1; g = ($clog2(NM+1))'(m); end
    m_ready = '0;
    if (any) m_ready[g] = 1'b1;
    ok = any && (m_id[g] < 3'(flux_pkg::NUM_MEMS)) && (m_row[g] < s_rows[m_id[g]]) &&
         !(m_we[g] && m_id[g] == flux_pkg::MEM_TELEM);
    s_en = '0;
    if (ok) s_en[m_id[g]] = 1'b1;
  end
  assign s_we    = m_we[g];
  assign s_row   = m_row[g];
  assign s_wmask = m_wmask[g];
  assign s_wdata = m_wdata[g];

  logic [NM-1:0] rsp_q;
  logic [2:0]    id_q;
  logic          ok_q, we_q;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      rsp_q     <= '0;
      accesses  <= '0;
      conflicts <= '0;
    end else begin
      rsp_q <= m_ready;
      if (any) accesses <= accesses + 32'd1;
      if ($countones(m_valid) > 1) conflicts <= conflicts + 32'd1;
    end
    id_q <= m_id[g];
    ok_q <= ok;
    we_q <= m_we[g];
  end
  assign m_rsp_valid    = rsp_q;
  assign rsp_rdata      = s_rdata[id_q];
  assign rsp_err_addr   = !ok_q;
  assign rsp_err_parity = (ok_q && !we_q) ? s_perr[id_q] : '0;
endmodule
