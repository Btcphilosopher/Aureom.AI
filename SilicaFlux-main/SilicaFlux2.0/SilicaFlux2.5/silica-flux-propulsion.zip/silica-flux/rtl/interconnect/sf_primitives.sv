// =============================================================================
// Silica Flux -- generic flow-control primitives
// -----------------------------------------------------------------------------
//   sf_pipe_reg   elastic pipeline register (valid/ready, full throughput)
//   sf_skid       two-entry skid buffer (registered ready, breaks the ready path)
//   sf_fifo       synchronous FIFO with occupancy, overflow/underflow sticky flags
//   sf_rr_arb     round-robin arbiter
//
// Protocol (used everywhere in the fabric): a transfer occurs on a cycle where
// valid && ready.  Once valid is asserted the payload must stay stable until
// the transfer completes (checked in formal/properties.sv).
// =============================================================================

module sf_pipe_reg #(
  parameter int W = 32
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         in_valid,
  output logic         in_ready,
  input  logic [W-1:0] in_data,
  output logic         out_valid,
  input  logic         out_ready,
  output logic [W-1:0] out_data
);
  assign in_ready = !out_valid || out_ready;
  always_ff @(posedge clk) begin
    if (!rst_n)        out_valid <= 1'b0;
    else if (in_ready) out_valid <= in_valid;
  end
  always_ff @(posedge clk) begin
    if (in_ready && in_valid) out_data <= in_data;
  end
endmodule

// -----------------------------------------------------------------------------
module sf_skid #(
  parameter int W = 32
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         in_valid,
  output logic         in_ready,   // driven from a flop: no combinational ready path
  input  logic [W-1:0] in_data,
  output logic         out_valid,
  input  logic         out_ready,
  output logic [W-1:0] out_data
);
  logic         skid_valid;
  logic [W-1:0] skid_data;

  assign in_ready = !skid_valid;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      out_valid  <= 1'b0;
      skid_valid <= 1'b0;
    end else if (out_valid && out_ready) begin
      if (skid_valid) begin
        out_valid  <= 1'b1;
        skid_valid <= 1'b0;
      end else begin
        out_valid  <= in_valid;
      end
    end else if (!out_valid) begin
      out_valid <= in_valid;
    end else if (in_valid && !skid_valid) begin
      skid_valid <= 1'b1;
    end
  end

  always_ff @(posedge clk) begin
    if (out_valid && out_ready) begin
      out_data <= skid_valid ? skid_data : in_data;
    end else if (!out_valid) begin
      out_data <= in_data;
    end else if (in_valid && !skid_valid) begin
      skid_data <= in_data;
    end
  end
endmodule

// -----------------------------------------------------------------------------
module sf_fifo #(
  parameter int W     = 32,
  parameter int DEPTH = 8,
  parameter int AW    = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         push,
  input  logic [W-1:0] wdata,
  input  logic         pop,
  output logic [W-1:0] rdata,
  output logic         empty,
  output logic         full,
  output logic [AW:0]  count,
  output logic         overflow,   // sticky: push while full (data dropped)
  output logic         underflow,  // sticky: pop while empty (ignored)
  input  logic         clr_flags
);
  logic [W-1:0]  mem [DEPTH];
  logic [AW-1:0] wptr, rptr;
  logic          do_push, do_pop;

  assign empty   = (count == '0);
  assign full    = (count == (AW+1)'(DEPTH));
  assign do_push = push && !full;
  assign do_pop  = pop && !empty;
  assign rdata   = mem[rptr];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wptr <= '0; rptr <= '0; count <= '0;
      overflow <= 1'b0; underflow <= 1'b0;
    end else begin
      if (do_push) wptr <= (wptr == AW'(DEPTH-1)) ? '0 : wptr + AW'(1);
      if (do_pop)  rptr <= (rptr == AW'(DEPTH-1)) ? '0 : rptr + AW'(1);
      case ({do_push, do_pop})
        2'b10:   count <= count + (AW+1)'(1);
        2'b01:   count <= count - (AW+1)'(1);
        default: count <= count;
      endcase
      if (clr_flags) begin
        overflow <= 1'b0; underflow <= 1'b0;
      end else begin
        if (push && full)  overflow  <= 1'b1;
        if (pop && empty)  underflow <= 1'b1;
      end
    end
  end
  always_ff @(posedge clk) begin
    if (do_push) mem[wptr] <= wdata;
  end
endmodule

// -----------------------------------------------------------------------------
module sf_rr_arb #(
  parameter int N = 4
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,
  input  logic         advance,    // grant consumed this cycle
  output logic [N-1:0] grant,
  output logic [$clog2(N)-1:0] grant_idx,
  output logic         any
);
  logic [$clog2(N)-1:0] last;
  always_comb begin
    grant     = '0;
    grant_idx = '0;
    any       = 1'b0;
    for (int k = 1; k <= N; k++) begin
      int idx;
      idx = (int'(last) + k) % N;
      if (!any && req[idx]) begin
        any        = 1'b1;
        grant[idx] = 1'b1;
        grant_idx  = idx[$clog2(N)-1:0];
      end
    end
  end
  always_ff @(posedge clk) begin
    if (!rst_n)              last <= $clog2(N)'(N - 1);
    else if (advance && any) last <= grant_idx;
  end
endmodule
