// =============================================================================
// Silica Flux -- AXI4-Stream register slice
// -----------------------------------------------------------------------------
// Two-entry skid buffer on TDATA/TUSER/TLAST: full throughput, and TREADY on
// the upstream side comes from a flop, which breaks the combinational ready
// path between the fabric and the host stream infrastructure.  Used on the
// DMA input stream (host -> fabric) and the result stream (fabric -> host).
// =============================================================================
module axi_stream #(
  parameter int DW = 64,
  parameter int UW = 8
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic [DW-1:0] s_tdata,
  input  logic [UW-1:0] s_tuser,
  input  logic          s_tlast,
  input  logic          s_tvalid,
  output logic          s_tready,
  output logic [DW-1:0] m_tdata,
  output logic [UW-1:0] m_tuser,
  output logic          m_tlast,
  output logic          m_tvalid,
  input  logic          m_tready,
  output logic [31:0]   beats
);
  sf_skid #(.W(DW + UW + 1)) u_skid (
    .clk(clk), .rst_n(rst_n),
    .in_valid(s_tvalid), .in_ready(s_tready), .in_data({s_tdata, s_tuser, s_tlast}),
    .out_valid(m_tvalid), .out_ready(m_tready), .out_data({m_tdata, m_tuser, m_tlast}));
  always_ff @(posedge clk) begin
    if (!rst_n) beats <= '0;
    else if (m_tvalid && m_tready) beats <= beats + 32'd1;
  end
`ifdef SF_SVA
  a_hold: assert property (@(posedge clk) disable iff (!rst_n)
    m_tvalid && !m_tready |=> m_tvalid && $stable({m_tdata, m_tuser, m_tlast}));
`endif
endmodule
