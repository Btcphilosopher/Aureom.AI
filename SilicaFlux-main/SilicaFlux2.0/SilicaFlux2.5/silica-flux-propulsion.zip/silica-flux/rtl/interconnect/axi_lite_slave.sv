// =============================================================================
// Silica Flux -- AXI4-Lite slave (configuration bus)
// -----------------------------------------------------------------------------
// 32-bit data, one outstanding read and one outstanding write.  AW and W may
// arrive in either order.  Produces single-cycle register-file strobes:
//   reg_we/reg_waddr/reg_wdata  on a completed write (response OKAY)
//   reg_re/reg_raddr            on an accepted read; reg_rdata is sampled the
//                               following cycle and returned on R.
// Valid/ready handshake rules are asserted in formal/properties.sv.
// =============================================================================
module axi_lite_slave #(
  parameter int AW = 16
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic [AW-1:0] s_awaddr,
  input  logic          s_awvalid,
  output logic          s_awready,
  input  logic [31:0]   s_wdata,
  input  logic [3:0]    s_wstrb,
  input  logic          s_wvalid,
  output logic          s_wready,
  output logic [1:0]    s_bresp,
  output logic          s_bvalid,
  input  logic          s_bready,
  input  logic [AW-1:0] s_araddr,
  input  logic          s_arvalid,
  output logic          s_arready,
  output logic [31:0]   s_rdata,
  output logic [1:0]    s_rresp,
  output logic          s_rvalid,
  input  logic          s_rready,
  output logic          reg_we,
  output logic [AW-1:0] reg_waddr,
  output logic [31:0]   reg_wdata,
  output logic [3:0]    reg_wstrb,
  output logic          reg_re,
  output logic [AW-1:0] reg_raddr,
  input  logic [31:0]   reg_rdata
);
  logic          aw_full, w_full, rd_pend;
  logic [AW-1:0] aw_q;
  logic [31:0]   w_q;
  logic [3:0]    ws_q;

  assign s_awready = !aw_full && !s_bvalid;
  assign s_wready  = !w_full && !s_bvalid;
  assign s_arready = !rd_pend && !s_rvalid;
  assign s_bresp   = 2'b00;
  assign s_rresp   = 2'b00;

  assign reg_we    = aw_full && w_full && !s_bvalid;
  assign reg_waddr = aw_q;
  assign reg_wdata = w_q;
  assign reg_wstrb = ws_q;
  assign reg_re    = s_arvalid && s_arready;
  assign reg_raddr = s_araddr;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      aw_full  <= 1'b0;
      w_full   <= 1'b0;
      s_bvalid <= 1'b0;
      rd_pend  <= 1'b0;
      s_rvalid <= 1'b0;
    end else begin
      if (s_awvalid && s_awready) begin aw_full <= 1'b1; aw_q <= s_awaddr; end
      if (s_wvalid && s_wready)   begin w_full <= 1'b1; w_q <= s_wdata; ws_q <= s_wstrb; end
      if (reg_we) begin
        aw_full  <= 1'b0;
        w_full   <= 1'b0;
        s_bvalid <= 1'b1;
      end else if (s_bvalid && s_bready) begin
        s_bvalid <= 1'b0;
      end
      if (reg_re) rd_pend <= 1'b1;
      if (rd_pend) begin
        rd_pend  <= 1'b0;
        s_rvalid <= 1'b1;
        s_rdata  <= reg_rdata;
      end else if (s_rvalid && s_rready) begin
        s_rvalid <= 1'b0;
      end
    end
  end
endmodule
