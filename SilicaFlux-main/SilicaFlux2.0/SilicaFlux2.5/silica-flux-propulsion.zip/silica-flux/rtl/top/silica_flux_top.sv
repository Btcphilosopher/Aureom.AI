// =============================================================================
// SILICA FLUX -- numerical-computing fabric, top level
// -----------------------------------------------------------------------------
//                             SILICA FLUX
//                                  |
//            +---------------------+----------------------+
//      CONTROL PLANE                                 COMPUTE FABRIC
//   AXI-Lite CSRs, command (start/abort),       flux_core: vector ALU, FMA,
//   DMA, interrupts, fault manager,             div/sqrt, SFU, reduction,
//   watchdog                                    polynomial, interpolation,
//            |                                  state, residual, conservation,
//            |                                  objective, constraint, sweep,
//            |                                  search
//            +---------------------+----------------------+
//                         internal_bus (core > DMA > host)
//        STATE (ping-pong) | PARAM | COEFF | SCRATCH | RESULT | TELEM table
//                                  |
//                   telemetry ingest -> timestamp -> buffer
//
// Parameters (synthesis configuration):
//   VECTOR_LANES     8 / 16 / 32 lanes
//   FP_MODE          0 = binary32 fabric, 1 = binary64 fabric
//   DATA_WIDTH       32 / 64 (must agree with FP_MODE)
//   PIPELINE_DEPTH   FMA / vector-ALU latency (>= 4)
//   SCRATCHPAD_SIZE  scratchpad rows
// The register map is documented in firmware/register_map.md and mirrored in
// python/silica_flux/regmap.py.
// =============================================================================
module silica_flux_top #(
  parameter int VECTOR_LANES    = 8,
  parameter int FP_MODE         = 0,
  parameter int DATA_WIDTH      = (FP_MODE != 0) ? 64 : 32,
  parameter int PIPELINE_DEPTH  = 4,
  parameter int SCRATCHPAD_SIZE = 256,
  parameter int STATE_ROWS      = 64,
  parameter int PARAM_ROWS      = 64,
  parameter int COEFF_ROWS      = 64,
  parameter int RESULT_ROWS     = 128,
  parameter int IMEM_DEPTH      = 1024,
  parameter int N_CHAN          = 32,
  parameter int TL_FIFO_DEPTH   = 16,
  parameter int DIV_BPC         = 1
) (
  input  logic        clk,
  input  logic        rst_n,
  // AXI4-Lite configuration slave
  input  logic [15:0] s_axil_awaddr,
  input  logic        s_axil_awvalid,
  output logic        s_axil_awready,
  input  logic [31:0] s_axil_wdata,
  input  logic [3:0]  s_axil_wstrb,
  input  logic        s_axil_wvalid,
  output logic        s_axil_wready,
  output logic [1:0]  s_axil_bresp,
  output logic        s_axil_bvalid,
  input  logic        s_axil_bready,
  input  logic [15:0] s_axil_araddr,
  input  logic        s_axil_arvalid,
  output logic        s_axil_arready,
  output logic [31:0] s_axil_rdata,
  output logic [1:0]  s_axil_rresp,
  output logic        s_axil_rvalid,
  input  logic        s_axil_rready,
  // AXI4-Stream in (DMA / telemetry)
  input  logic [63:0] s_axis_tdata,
  input  logic [7:0]  s_axis_tuser,
  input  logic        s_axis_tlast,
  input  logic        s_axis_tvalid,
  output logic        s_axis_tready,
  // AXI4-Stream out (results)
  output logic [63:0] m_axis_tdata,
  output logic [7:0]  m_axis_tuser,
  output logic        m_axis_tlast,
  output logic        m_axis_tvalid,
  input  logic        m_axis_tready,
  // interrupt
  output logic        irq
);
  localparam int LANES = VECTOR_LANES;
  localparam int EXP_W = (FP_MODE != 0) ? 11 : 8;
  localparam int MAN_W = (FP_MODE != 0) ? 52 : 23;
  localparam int W     = EXP_W + MAN_W + 1;
  localparam int EW    = W + flux_pkg::QW;
  localparam int IAW   = $clog2(IMEM_DEPTH);
  localparam logic [2:0] NATIVE = (FP_MODE != 0) ? flux_pkg::PREC_FP64 : flux_pkg::PREC_FP32;
  localparam logic [flux_pkg::FAULT_W-1:0] HALT_DEFAULT =
      (1 << flux_pkg::F_WATCHDOG) | (1 << flux_pkg::F_TIMEOUT) | (1 << flux_pkg::F_ILLEGAL) | (1 << flux_pkg::F_PRECISION) | (1 << flux_pkg::F_NAN) |
      (1 << flux_pkg::F_OVERFLOW) | (1 << flux_pkg::F_DIVZERO) | (1 << flux_pkg::F_PARITY) | (1 << flux_pkg::F_MEMADDR) | (1 << flux_pkg::F_PIPELINE) |
      (1 << flux_pkg::F_STEP) | (1 << flux_pkg::F_UNINIT) | (1 << flux_pkg::F_HOST);

`ifndef SYNTHESIS
  initial begin
    if (DATA_WIDTH != W) $fatal(1, "DATA_WIDTH (%0d) must match FP_MODE (%0d bits)", DATA_WIDTH, W);
    if (PIPELINE_DEPTH < 4) $fatal(1, "PIPELINE_DEPTH must be >= 4");
    if (LANES < 8 || (LANES & (LANES - 1)) != 0) $fatal(1, "VECTOR_LANES must be a power of two >= 8");
  end
`endif

  function automatic logic [W-1:0] mk64(input logic [31:0] lo, input logic [31:0] hi);
    logic [63:0] v;
    v = {hi, lo};
    mk64 = W'(v);
  endfunction
  function automatic logic [31:0] hi32(input logic [W-1:0] v);
    logic [63:0] x;
    x = 64'(v);
    hi32 = x[63:32];
  endfunction

  // ===========================================================================
  // configuration bus
  // ===========================================================================
  logic        reg_we, reg_re;
  logic [15:0] reg_waddr, reg_raddr;
  logic [31:0] reg_wdata, reg_rdata;
  logic [3:0]  reg_wstrb;
  axi_lite_slave #(.AW(16)) u_axil (
    .clk(clk), .rst_n(rst_n),
    .s_awaddr(s_axil_awaddr), .s_awvalid(s_axil_awvalid), .s_awready(s_axil_awready),
    .s_wdata(s_axil_wdata), .s_wstrb(s_axil_wstrb), .s_wvalid(s_axil_wvalid), .s_wready(s_axil_wready),
    .s_bresp(s_axil_bresp), .s_bvalid(s_axil_bvalid), .s_bready(s_axil_bready),
    .s_araddr(s_axil_araddr), .s_arvalid(s_axil_arvalid), .s_arready(s_axil_arready),
    .s_rdata(s_axil_rdata), .s_rresp(s_axil_rresp), .s_rvalid(s_axil_rvalid), .s_rready(s_axil_rready),
    .reg_we(reg_we), .reg_waddr(reg_waddr), .reg_wdata(reg_wdata), .reg_wstrb(reg_wstrb),
    .reg_re(reg_re), .reg_raddr(reg_raddr), .reg_rdata(reg_rdata));

  // ===========================================================================
  // CSR state
  // ===========================================================================
  logic [15:0] start_pc_q;
  logic [2:0]  frm_q;
  logic [1:0]  irq_en_q, irq_st_q;
  logic [4:0]  fflags_q;
  logic [flux_pkg::FAULT_W-1:0] fault_en_q, fault_halt_q;
  logic [31:0] wdt_limit_q, dma_timeout_q;
  logic [15:0] ts_prescale_q;
  logic        abort_q;
  // memory window
  logic [2:0]  mw_sel_q;
  logic [15:0] mw_row_q;
  logic [7:0]  mw_lane_q;
  logic [31:0] mw_wlo_q, mw_whi_q, mw_rlo_q, mw_rhi_q;
  logic [3:0]  mw_wq_q, mw_rq_q;
  logic        mw_pend_q, mw_we_q, mw_wait_q, mw_perr_q, mw_aerr_q;
  logic [flux_pkg::NUM_MEMS-1:0][2:0] mem_prec_q;
  logic [flux_pkg::NUM_MEMS-1:0][5:0] mem_scale_q;
  // instruction memory window
  logic [IAW-1:0] im_addr_q;
  logic [31:0]    im_wlo_q;
  // engine configuration
  logic [31:0]    stage_lo_q;                      // LO staging for 64-bit writes
  logic [W-1:0]   res_rtol_q, cons_atol_q, cons_rtol_q;
  logic [2:0]     ts_stages_q;
  logic [3:0]     ts_tab_sel_q;
  logic [9:0][W-1:0] ts_tab_q;
  logic [2:0]     sw_dims_q, ls_dims_q;
  logic [1:0]     sw_dsel_q, ls_dsel_q;
  logic [2:0]     ls_fsel_q;
  logic [3:0][W-1:0]  sw_lo_q, sw_step_q, ls_lo_q, ls_hi_q, ls_c0_q, ls_s0_q, ls_min_q;
  logic [3:0][31:0]   sw_count_q;
  logic [15:0]    ls_maxit_q;
  // DMA
  logic [2:0]  dma_mem_q;
  logic [15:0] dma_row_q;
  logic [31:0] dma_len_q;
  // telemetry
  logic [31:0] tl_gap_q;
  logic [7:0]  tl_bchan_q;
  logic [W-1:0] tl_blo_q;
  logic        tl_bound_we, tl_reset;

  // pulses
  logic start_p, imem_we_p, inj_imem_p, host_fault_p, dma_start_p;
  logic [1:0] dma_dir_p;
  logic [flux_pkg::NUM_MEMS-1:0] inj_mem_arm_q;
  logic clr_fault_we;
  logic [flux_pkg::FAULT_W-1:0] clr_fault_bits;

  // ---------------------------------------------------------------------------
  // forward declarations of status
  // ---------------------------------------------------------------------------
  logic core_running, core_done, core_halted, halt_req, fm_irq, dma_busy, dma_done, dma_err;
  logic [4:0]          fflags_ev;
  logic [flux_pkg::NUM_MEMS-1:0] inj_consumed;
  logic [15:0] core_pc;
  logic [31:0] tstamp;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      start_pc_q <= '0; frm_q <= '0; irq_en_q <= '0; fflags_q <= '0;
      fault_en_q <= '1; fault_halt_q <= HALT_DEFAULT;
      wdt_limit_q <= 32'd100000; dma_timeout_q <= 32'd100000; ts_prescale_q <= '0;
      abort_q <= 1'b0;
      mw_sel_q <= '0; mw_row_q <= '0; mw_lane_q <= '0; mw_wlo_q <= '0; mw_whi_q <= '0; mw_wq_q <= '0;
      for (int m = 0; m < flux_pkg::NUM_MEMS; m++) begin mem_prec_q[m] <= NATIVE; mem_scale_q[m] <= '0; end
      im_addr_q <= '0; im_wlo_q <= '0; stage_lo_q <= '0;
      res_rtol_q <= '0; cons_atol_q <= '0; cons_rtol_q <= '0;
      ts_stages_q <= 3'd1; ts_tab_sel_q <= '0; ts_tab_q <= '0;
      sw_dims_q <= 3'd1; ls_dims_q <= 3'd1; sw_dsel_q <= '0; ls_dsel_q <= '0; ls_fsel_q <= '0;
      sw_lo_q <= '0; sw_step_q <= '0; sw_count_q <= {4{32'd1}};
      ls_lo_q <= '0; ls_hi_q <= '0; ls_c0_q <= '0; ls_s0_q <= '0; ls_min_q <= '0; ls_maxit_q <= 16'd64;
      dma_mem_q <= '0; dma_row_q <= '0; dma_len_q <= '0;
      tl_gap_q <= '0; tl_bchan_q <= '0; tl_blo_q <= '0;
      inj_mem_arm_q <= '0;
    end else begin
      if (reg_we) begin
        case (reg_waddr)
          16'h0010: begin
            if (reg_wdata[1]) abort_q <= 1'b1;
            if (reg_wdata[0]) abort_q <= 1'b0;
            if (reg_wdata[5]) inj_mem_arm_q[reg_wdata[10:8]] <= 1'b1;
          end
          16'h0018: start_pc_q <= reg_wdata[15:0];
          16'h0020: frm_q <= reg_wdata[2:0];
          16'h0024: irq_en_q <= reg_wdata[1:0];
          16'h002C: fflags_q <= fflags_q & ~reg_wdata[4:0];
          16'h0034: fault_en_q <= reg_wdata[flux_pkg::FAULT_W-1:0];
          16'h0038: fault_halt_q <= reg_wdata[flux_pkg::FAULT_W-1:0];
          16'h004C: wdt_limit_q <= reg_wdata;
          16'h0050: dma_timeout_q <= reg_wdata;
          16'h0058: ts_prescale_q <= reg_wdata[15:0];
          16'h0100: mw_sel_q <= reg_wdata[2:0];
          16'h0104: mw_row_q <= reg_wdata[15:0];
          16'h0108: mw_lane_q <= reg_wdata[7:0];
          16'h010C: mw_wlo_q <= reg_wdata;
          16'h0110: mw_whi_q <= reg_wdata;
          16'h0114: mw_wq_q <= reg_wdata[3:0];
          16'h0180: im_addr_q <= reg_wdata[IAW-1:0];
          16'h0184: im_wlo_q <= reg_wdata;
          16'h0188: im_addr_q <= im_addr_q + 1'b1;
          // 64-bit staging (LO) and commits (HI)
          16'h0200, 16'h0208, 16'h0210, 16'h025C, 16'h0288, 16'h0290, 16'h02CC, 16'h03B8, 16'h03C0:
            stage_lo_q <= reg_wdata;
          16'h0204: res_rtol_q  <= mk64(stage_lo_q, reg_wdata);
          16'h020C: cons_atol_q <= mk64(stage_lo_q, reg_wdata);
          16'h0214: cons_rtol_q <= mk64(stage_lo_q, reg_wdata);
          16'h0254: ts_stages_q <= reg_wdata[2:0];
          16'h0258: ts_tab_sel_q <= reg_wdata[3:0];
          16'h0260: if (ts_tab_sel_q < 4'd10) ts_tab_q[ts_tab_sel_q] <= mk64(stage_lo_q, reg_wdata);
          16'h0280: sw_dims_q <= reg_wdata[2:0];
          16'h0284: sw_dsel_q <= reg_wdata[1:0];
          16'h028C: sw_lo_q[sw_dsel_q]   <= mk64(stage_lo_q, reg_wdata);
          16'h0294: sw_step_q[sw_dsel_q] <= mk64(stage_lo_q, reg_wdata);
          16'h0298: sw_count_q[sw_dsel_q] <= reg_wdata;
          16'h02C0: ls_dims_q <= reg_wdata[2:0];
          16'h02C4: ls_dsel_q <= reg_wdata[1:0];
          16'h02C8: ls_fsel_q <= reg_wdata[2:0];
          16'h02D0: case (ls_fsel_q)
                      3'd0: ls_lo_q[ls_dsel_q]  <= mk64(stage_lo_q, reg_wdata);
                      3'd1: ls_hi_q[ls_dsel_q]  <= mk64(stage_lo_q, reg_wdata);
                      3'd2: ls_c0_q[ls_dsel_q]  <= mk64(stage_lo_q, reg_wdata);
                      3'd3: ls_s0_q[ls_dsel_q]  <= mk64(stage_lo_q, reg_wdata);
                      default: ls_min_q[ls_dsel_q] <= mk64(stage_lo_q, reg_wdata);
                    endcase
          16'h02D4: ls_maxit_q <= reg_wdata[15:0];
          16'h0304: dma_mem_q <= reg_wdata[2:0];
          16'h0308: dma_row_q <= reg_wdata[15:0];
          16'h030C: dma_len_q <= reg_wdata;
          16'h03B0: tl_gap_q <= reg_wdata;
          16'h03B4: tl_bchan_q <= reg_wdata[7:0];
          16'h03BC: tl_blo_q <= mk64(stage_lo_q, reg_wdata);
          default: begin
            if (reg_waddr >= 16'h0128 && reg_waddr < 16'h0128 + 16'(4 * flux_pkg::NUM_MEMS)) begin
              mem_prec_q[(reg_waddr - 16'h0128) >> 2]  <= reg_wdata[2:0];
              mem_scale_q[(reg_waddr - 16'h0128) >> 2] <= reg_wdata[13:8];
            end
          end
        endcase
      end
      if (fflags_ev != '0) fflags_q <= fflags_q | fflags_ev;
      for (int m = 0; m < flux_pkg::NUM_MEMS; m++) if (inj_consumed[m]) inj_mem_arm_q[m] <= 1'b0;
    end
  end

  assign start_p      = reg_we && reg_waddr == 16'h0010 && reg_wdata[0];
  assign inj_imem_p   = reg_we && reg_waddr == 16'h0010 && reg_wdata[4];
  assign host_fault_p = reg_we && reg_waddr == 16'h0010 && reg_wdata[6];
  assign imem_we_p    = reg_we && reg_waddr == 16'h0188;
  assign dma_start_p  = reg_we && reg_waddr == 16'h0300 && reg_wdata[0];
  assign dma_dir_p    = reg_wdata[2:1];
  assign tl_bound_we  = reg_we && reg_waddr == 16'h03C4;
  assign tl_reset     = reg_we && reg_waddr == 16'h03C8 && reg_wdata[0];
  assign clr_fault_we   = reg_we && reg_waddr == 16'h0030;
  assign clr_fault_bits = reg_wdata[flux_pkg::FAULT_W-1:0];

  // ===========================================================================
  // compute core
  // ===========================================================================
  logic                    c_req_valid, c_req_ready, c_req_we, c_rsp_valid;
  logic [2:0]              c_req_id;
  logic [15:0]             c_req_row;
  logic [LANES-1:0]        c_req_wmask;
  logic [LANES*EW-1:0]     c_req_wdata;
  logic [LANES*EW-1:0]     bus_rdata;
  logic                    bus_err_addr;
  logic [LANES-1:0]        bus_err_parity;
  logic                    frame_pending, frame_ack, state_swap;
  logic                    core_fault_valid, core_progress;
  logic [flux_pkg::FAULT_W-1:0]      core_fault_bits;
  logic [15:0]             core_fault_pc;
  logic [W-1:0]            ts_t, ts_dt, cons_resid, cons_ref, sr_best;
  logic [31:0]             ts_step, st_upd, res_viol, cons_viol, con_pass, con_fail, sw_base, sw_total, sr_bidx;
  logic                    ts_valid, sw_done, sw_ok, ls_conv;
  logic [LANES-1:0]        con_mask;
  logic [4*W-1:0]          ls_center, ls_step;
  logic [15:0]             ls_iter;
  logic [31:0]             p_ret, p_stall, p_lops, p_iss, p_ld, p_st;
  logic [flux_pkg::NUM_FU-1:0][31:0] p_fu;
  logic [6*W-1:0]          ts_ca;
  logic [4*W-1:0]          ts_cb;
  logic [4*W-1:0]          sw_lo_f, sw_step_f, ls_lo_f, ls_hi_f, ls_c0_f, ls_s0_f, ls_min_f;
  logic [4*32-1:0]         sw_count_f;
  logic [3*flux_pkg::NUM_MEMS-1:0]   mem_prec_f;
  logic [6*flux_pkg::NUM_MEMS-1:0]   mem_scale_f;
  always_comb begin
    for (int s = 0; s < 6; s++) ts_ca[s*W +: W] = ts_tab_q[s];
    for (int s = 0; s < 4; s++) begin
      ts_cb[s*W +: W]      = ts_tab_q[6+s];
      sw_lo_f[s*W +: W]    = sw_lo_q[s];
      sw_step_f[s*W +: W]  = sw_step_q[s];
      sw_count_f[s*32 +: 32] = sw_count_q[s];
      ls_lo_f[s*W +: W]    = ls_lo_q[s];
      ls_hi_f[s*W +: W]    = ls_hi_q[s];
      ls_c0_f[s*W +: W]    = ls_c0_q[s];
      ls_s0_f[s*W +: W]    = ls_s0_q[s];
      ls_min_f[s*W +: W]   = ls_min_q[s];
    end
    for (int m = 0; m < flux_pkg::NUM_MEMS; m++) begin
      mem_prec_f[m*3 +: 3]  = mem_prec_q[m];
      mem_scale_f[m*6 +: 6] = mem_scale_q[m];
    end
  end

  flux_core #(.LANES(LANES), .FP_MODE(FP_MODE), .LATENCY(PIPELINE_DEPTH), .DIV_BPC(DIV_BPC),
              .IMEM_DEPTH(IMEM_DEPTH)) u_core (
    .clk(clk), .rst_n(rst_n),
    .start(start_p), .start_pc(start_pc_q), .halt_req(halt_req || abort_q), .frm(frm_q),
    .running(core_running), .done(core_done), .halted_fault(core_halted), .pc_out(core_pc), .tstamp(tstamp),
    .imem_we(imem_we_p), .imem_waddr(im_addr_q), .imem_wdata({reg_wdata, im_wlo_q}), .imem_inj_parity(inj_imem_p),
    .mem_req_valid(c_req_valid), .mem_req_ready(c_req_ready), .mem_req_we(c_req_we), .mem_req_id(c_req_id),
    .mem_req_row(c_req_row), .mem_req_wmask(c_req_wmask), .mem_req_wdata(c_req_wdata),
    .mem_rsp_valid(c_rsp_valid), .mem_rsp_rdata(bus_rdata), .mem_rsp_err_addr(bus_err_addr),
    .mem_rsp_err_parity(bus_err_parity), .mem_prec(mem_prec_f), .mem_scale(mem_scale_f),
    .telem_frame_pending(frame_pending), .telem_frame_ack(frame_ack), .dma_busy(dma_busy), .state_swap(state_swap),
    .res_rtol(res_rtol_q), .cons_atol(cons_atol_q), .cons_rtol(cons_rtol_q),
    .ts_custom_stages(ts_stages_q), .ts_custom_a(ts_ca), .ts_custom_b(ts_cb),
    .sw_dims(sw_dims_q), .sw_lo(sw_lo_f), .sw_step(sw_step_f), .sw_count(sw_count_f),
    .ls_dims(ls_dims_q), .ls_lo(ls_lo_f), .ls_hi(ls_hi_f), .ls_center0(ls_c0_f), .ls_step0(ls_s0_f),
    .ls_min_step(ls_min_f), .ls_max_iter(ls_maxit_q),
    .ts_t(ts_t), .ts_dt(ts_dt), .ts_step(ts_step), .ts_valid(ts_valid), .st_updates(st_upd),
    .res_viol_count(res_viol), .cons_last_resid(cons_resid), .cons_ref(cons_ref), .cons_viol_count(cons_viol),
    .con_pass(con_pass), .con_fail(con_fail), .con_last_mask(con_mask),
    .sw_base(sw_base), .sw_total(sw_total), .sw_done(sw_done), .sw_ok(sw_ok),
    .sr_best(sr_best), .sr_best_idx(sr_bidx), .ls_center(ls_center), .ls_step(ls_step),
    .ls_iter(ls_iter), .ls_conv(ls_conv),
    .fault_valid(core_fault_valid), .fault_bits(core_fault_bits), .fault_pc(core_fault_pc),
    .fflags_event(fflags_ev), .progress(core_progress),
    .perf_retired(p_ret), .perf_stall(p_stall), .perf_lane_ops(p_lops), .perf_issued(p_iss),
    .perf_loads(p_ld), .perf_stores(p_st), .perf_fu_busy(p_fu));

  // ===========================================================================
  // memories and interconnect
  // ===========================================================================
  logic [2:0]                    m_valid, m_ready, m_we, m_rsp_valid;
  logic [2:0][2:0]               m_id;
  logic [2:0][15:0]              m_row;
  logic [2:0][LANES-1:0]         m_wmask;
  logic [2:0][LANES*EW-1:0]      m_wdata;
  logic [flux_pkg::NUM_MEMS-1:0][15:0]     s_rows;
  logic [flux_pkg::NUM_MEMS-1:0]           s_en;
  logic                          s_we;
  logic [15:0]                   s_row;
  logic [LANES-1:0]              s_wmask;
  logic [LANES*EW-1:0]           s_wdata;
  logic [flux_pkg::NUM_MEMS-1:0][LANES*EW-1:0] s_rdata;
  logic [flux_pkg::NUM_MEMS-1:0][LANES-1:0]    s_perr;
  logic [31:0]                   bus_acc, bus_conf;

  // master 1: DMA, master 2: host window
  logic                d_req_valid, d_req_ready, d_req_we;
  logic [2:0]          d_req_id;
  logic [15:0]         d_req_row;
  logic [LANES-1:0]    d_req_wmask;
  logic [LANES*EW-1:0] d_req_wdata;

  assign m_valid = {mw_pend_q && !mw_wait_q, d_req_valid, c_req_valid};
  assign m_we    = {mw_we_q, d_req_we, c_req_we};
  assign m_id    = {mw_sel_q, d_req_id, c_req_id};
  assign m_row   = {mw_row_q, d_req_row, c_req_row};
  always_comb begin
    m_wmask[0] = c_req_wmask;
    m_wmask[1] = d_req_wmask;
    m_wmask[2] = '0;
    m_wmask[2][mw_lane_q[$clog2(LANES)-1:0]] = 1'b1;
    m_wdata[0] = c_req_wdata;
    m_wdata[1] = d_req_wdata;
    for (int l = 0; l < LANES; l++) m_wdata[2][l*EW +: EW] = {mw_wq_q, mk64(mw_wlo_q, mw_whi_q)};
  end
  assign c_req_ready = m_ready[0];
  assign d_req_ready = m_ready[1];
  assign c_rsp_valid = m_rsp_valid[0];

  internal_bus #(.LANES(LANES), .EW(EW), .NM(3)) u_bus (
    .clk(clk), .rst_n(rst_n),
    .m_valid(m_valid), .m_ready(m_ready), .m_we(m_we), .m_id(m_id), .m_row(m_row), .m_wmask(m_wmask),
    .m_wdata(m_wdata), .m_rsp_valid(m_rsp_valid), .rsp_rdata(bus_rdata), .rsp_err_addr(bus_err_addr),
    .rsp_err_parity(bus_err_parity),
    .s_rows(s_rows), .s_en(s_en), .s_we(s_we), .s_row(s_row), .s_wmask(s_wmask), .s_wdata(s_wdata),
    .s_rdata(s_rdata), .s_perr(s_perr), .accesses(bus_acc), .conflicts(bus_conf));

  always_comb begin
    s_rows[flux_pkg::MEM_STATE]   = 16'(STATE_ROWS);
    s_rows[flux_pkg::MEM_STATE_N] = 16'(STATE_ROWS);
    s_rows[flux_pkg::MEM_PARAM]   = 16'(PARAM_ROWS);
    s_rows[flux_pkg::MEM_COEFF]   = 16'(COEFF_ROWS);
    s_rows[flux_pkg::MEM_SCRATCH] = 16'(SCRATCHPAD_SIZE);
    s_rows[flux_pkg::MEM_RESULT]  = 16'(RESULT_ROWS);
    s_rows[flux_pkg::MEM_TELEM]   = 16'((N_CHAN + LANES - 1) / LANES);
    for (int m = 0; m < flux_pkg::NUM_MEMS; m++) inj_consumed[m] = s_en[m] && s_we && inj_mem_arm_q[m];
  end

  logic [LANES*EW-1:0] st_rd;
  logic [LANES-1:0]    st_pe;
  logic                bank_sel;
  logic [31:0]         coeff_writes, param_writes, result_writes;
  logic [$clog2(RESULT_ROWS):0] result_hw;
  state_ram #(.ROWS(STATE_ROWS), .LANES(LANES), .EW(EW)) u_state_ram (
    .clk(clk), .rst_n(rst_n), .swap(state_swap), .bank_sel(bank_sel),
    .en(s_en[flux_pkg::MEM_STATE] || s_en[flux_pkg::MEM_STATE_N]), .next_bank(s_en[flux_pkg::MEM_STATE_N]), .we(s_we),
    .addr(s_row[$clog2(STATE_ROWS)-1:0]), .wmask(s_wmask),
    .inject(inj_mem_arm_q[flux_pkg::MEM_STATE] || inj_mem_arm_q[flux_pkg::MEM_STATE_N]),
    .wdata(s_wdata), .rdata(st_rd), .perr(st_pe));
  assign s_rdata[flux_pkg::MEM_STATE] = st_rd;  assign s_perr[flux_pkg::MEM_STATE] = st_pe;
  assign s_rdata[flux_pkg::MEM_STATE_N] = st_rd; assign s_perr[flux_pkg::MEM_STATE_N] = st_pe;
  coefficient_ram #(.ROWS(PARAM_ROWS), .LANES(LANES), .EW(EW)) u_param_ram (
    .clk(clk), .rst_n(rst_n), .en(s_en[flux_pkg::MEM_PARAM]), .we(s_we), .addr(s_row[$clog2(PARAM_ROWS)-1:0]),
    .wmask(s_wmask), .inject(inj_mem_arm_q[flux_pkg::MEM_PARAM]), .wdata(s_wdata),
    .rdata(s_rdata[flux_pkg::MEM_PARAM]), .perr(s_perr[flux_pkg::MEM_PARAM]), .writes(param_writes));
  coefficient_ram #(.ROWS(COEFF_ROWS), .LANES(LANES), .EW(EW)) u_coeff_ram (
    .clk(clk), .rst_n(rst_n), .en(s_en[flux_pkg::MEM_COEFF]), .we(s_we), .addr(s_row[$clog2(COEFF_ROWS)-1:0]),
    .wmask(s_wmask), .inject(inj_mem_arm_q[flux_pkg::MEM_COEFF]), .wdata(s_wdata),
    .rdata(s_rdata[flux_pkg::MEM_COEFF]), .perr(s_perr[flux_pkg::MEM_COEFF]), .writes(coeff_writes));
  scratchpad #(.ROWS(SCRATCHPAD_SIZE), .LANES(LANES), .EW(EW)) u_scratch (
    .clk(clk), .en(s_en[flux_pkg::MEM_SCRATCH]), .we(s_we), .addr(s_row[$clog2(SCRATCHPAD_SIZE)-1:0]),
    .wmask(s_wmask), .inject(inj_mem_arm_q[flux_pkg::MEM_SCRATCH]), .wdata(s_wdata),
    .rdata(s_rdata[flux_pkg::MEM_SCRATCH]), .perr(s_perr[flux_pkg::MEM_SCRATCH]));
  result_ram #(.ROWS(RESULT_ROWS), .LANES(LANES), .EW(EW)) u_result (
    .clk(clk), .rst_n(rst_n), .en(s_en[flux_pkg::MEM_RESULT]), .we(s_we), .addr(s_row[$clog2(RESULT_ROWS)-1:0]),
    .wmask(s_wmask), .inject(inj_mem_arm_q[flux_pkg::MEM_RESULT]), .wdata(s_wdata),
    .rdata(s_rdata[flux_pkg::MEM_RESULT]), .perr(s_perr[flux_pkg::MEM_RESULT]), .writes(result_writes), .high_water(result_hw));

  // ===========================================================================
  // host memory window (bus master 2)
  // ===========================================================================
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      mw_pend_q <= 1'b0;
      mw_wait_q <= 1'b0;
      mw_we_q   <= 1'b0;
      mw_perr_q <= 1'b0;
      mw_aerr_q <= 1'b0;
      mw_rlo_q  <= '0;
      mw_rhi_q  <= '0;
      mw_rq_q   <= '0;
    end else begin
      if (reg_we && reg_waddr == 16'h0118 && !mw_pend_q && (reg_wdata[1:0] != 2'd0)) begin
        mw_pend_q <= 1'b1;
        mw_we_q   <= (reg_wdata[1:0] == 2'd1);
      end
      if (mw_pend_q && !mw_wait_q && m_ready[2]) mw_wait_q <= 1'b1;
      if (m_rsp_valid[2]) begin
        logic [EW-1:0] e;
        logic [63:0]   v;
        e = bus_rdata[mw_lane_q[$clog2(LANES)-1:0]*EW +: EW];
        v = 64'(e[W-1:0]);
        mw_pend_q <= 1'b0;
        mw_wait_q <= 1'b0;
        mw_aerr_q <= bus_err_addr;
        mw_perr_q <= bus_err_parity[mw_lane_q[$clog2(LANES)-1:0]];
        if (!mw_we_q) begin
          mw_rlo_q <= v[31:0];
          mw_rhi_q <= v[63:32];
          mw_rq_q  <= e[W +: flux_pkg::QW];
        end
      end
    end
  end

  // ===========================================================================
  // telemetry path:  stream -> DMA(S2T) -> ingest -> timestamp -> buffer
  // ===========================================================================
  logic [63:0] si_data;
  logic [7:0]  si_user;
  logic        si_last, si_valid, si_ready;
  logic [31:0] si_beats, so_beats;
  axi_stream #(.DW(64), .UW(8)) u_sin (
    .clk(clk), .rst_n(rst_n),
    .s_tdata(s_axis_tdata), .s_tuser(s_axis_tuser), .s_tlast(s_axis_tlast), .s_tvalid(s_axis_tvalid),
    .s_tready(s_axis_tready), .m_tdata(si_data), .m_tuser(si_user), .m_tlast(si_last),
    .m_tvalid(si_valid), .m_tready(si_ready), .beats(si_beats));

  logic [63:0] so_data;
  logic [7:0]  so_user;
  logic        so_last, so_valid, so_ready;
  axi_stream #(.DW(64), .UW(8)) u_sout (
    .clk(clk), .rst_n(rst_n),
    .s_tdata(so_data), .s_tuser(so_user), .s_tlast(so_last), .s_tvalid(so_valid), .s_tready(so_ready),
    .m_tdata(m_axis_tdata), .m_tuser(m_axis_tuser), .m_tlast(m_axis_tlast), .m_tvalid(m_axis_tvalid),
    .m_tready(m_axis_tready), .beats(so_beats));

  logic        t_valid, t_ready, t_last;
  logic [63:0] t_data;
  logic [31:0] dma_count;
  logic        dma_act, dma_abort;
  dma_engine #(.LANES(LANES), .W(W)) u_dma (
    .clk(clk), .rst_n(rst_n), .start(dma_start_p), .dir(dma_dir_p), .mem_id(dma_mem_q),
    .row0(dma_row_q), .len(dma_len_q), .abort(dma_abort), .busy(dma_busy), .done(dma_done), .error(dma_err),
    .count(dma_count), .activity(dma_act),
    .s_valid(si_valid), .s_ready(si_ready), .s_data(si_data), .s_user(si_user), .s_last(si_last),
    .m_valid(so_valid), .m_ready(so_ready), .m_data(so_data), .m_user(so_user), .m_last(so_last),
    .t_valid(t_valid), .t_ready(t_ready), .t_data(t_data), .t_last(t_last),
    .req_valid(d_req_valid), .req_ready(d_req_ready), .req_we(d_req_we), .req_id(d_req_id), .req_row(d_req_row),
    .req_wmask(d_req_wmask), .req_wdata(d_req_wdata), .rsp_valid(m_rsp_valid[1]), .rsp_rdata(bus_rdata),
    .rsp_err_addr(bus_err_addr), .rsp_err_parity(bus_err_parity));

  logic        ts_chk_valid, ts_disc;
  logic [31:0] ts_chk_ts, ts_last_delta;
  timestamp_engine u_ts (
    .clk(clk), .rst_n(rst_n), .prescale(ts_prescale_q), .tstamp(tstamp),
    .chk_valid(ts_chk_valid), .chk_ts(ts_chk_ts), .max_gap(tl_gap_q), .reset_track(tl_reset),
    .discontinuity(ts_disc), .last_delta(ts_last_delta));

  logic                pk_valid, pk_fe;
  logic [7:0]          pk_chan;
  logic [W-1:0]        pk_value;
  logic [flux_pkg::QW-1:0]       pk_qual;
  logic [flux_pkg::FAULT_W-1:0]  tl_fault;
  logic [31:0] tl_rx, tl_acc, tl_drop, tl_crc, tl_seq, tl_tse, tl_rng, tl_mal, tl_frames, tl_ovf;
  logic        tl_ovf_ev;
  logic [$clog2(TL_FIFO_DEPTH):0] tl_level;
  telemetry_ingest #(.EXP_W(EXP_W), .MAN_W(MAN_W), .N_CHAN(N_CHAN)) u_ingest (
    .clk(clk), .rst_n(rst_n), .s_valid(t_valid), .s_ready(t_ready), .s_data(t_data), .s_last(t_last),
    .reset_track(tl_reset), .bound_we(tl_bound_we), .bound_chan(tl_bchan_q), .bound_lo(tl_blo_q),
    .bound_hi(mk64(stage_lo_q, reg_wdata)),
    .ts_chk_valid(ts_chk_valid), .ts_chk_ts(ts_chk_ts), .ts_disc(ts_disc),
    .pkt_valid(pk_valid), .pkt_chan(pk_chan), .pkt_value(pk_value), .pkt_qual(pk_qual), .pkt_frame_end(pk_fe),
    .fault_event(tl_fault), .cnt_rx(tl_rx), .cnt_accepted(tl_acc), .cnt_dropped(tl_drop), .cnt_crc(tl_crc),
    .cnt_seq(tl_seq), .cnt_ts(tl_tse), .cnt_range(tl_rng), .cnt_malformed(tl_mal));
  telemetry_buffer #(.LANES(LANES), .W(W), .N_CHAN(N_CHAN), .DEPTH(TL_FIFO_DEPTH)) u_tbuf (
    .clk(clk), .rst_n(rst_n), .pkt_valid(pk_valid), .pkt_chan(pk_chan), .pkt_value(pk_value),
    .pkt_qual(pk_qual), .pkt_frame_end(pk_fe),
    .rd_en(s_en[flux_pkg::MEM_TELEM]), .rd_row(s_row), .rd_data(s_rdata[flux_pkg::MEM_TELEM]),
    .frame_pending(frame_pending), .frame_ack(frame_ack), .frames(tl_frames),
    .overflow_event(tl_ovf_ev), .overflows(tl_ovf), .level(tl_level));
  assign s_perr[flux_pkg::MEM_TELEM] = '0;

  // ===========================================================================
  // safety: watchdog + fault manager
  // ===========================================================================
  logic [1:0] wd_exp, wd_trip;
  watchdog #(.N(2)) u_wdt (
    .clk(clk), .rst_n(rst_n), .enable({dma_busy, core_running}), .kick({dma_act, core_progress}),
    .limit({dma_timeout_q, wdt_limit_q}), .expired(wd_exp), .tripped(wd_trip));
  assign dma_abort = wd_exp[1];

  logic [2:0]               fm_valid;
  logic [2:0][flux_pkg::FAULT_W-1:0]  fm_bits;
  logic [2:0][15:0]         fm_pc;
  logic [flux_pkg::FAULT_W-1:0]       fault_status;
  logic                     ff_valid;
  logic [4:0]               ff_id;
  logic [15:0]              ff_pc;
  logic [31:0]              ff_time, fault_count;
  always_comb begin
    fm_valid[0] = core_fault_valid;
    fm_bits[0]  = core_fault_bits;
    fm_pc[0]    = core_fault_pc;
    fm_bits[1]  = tl_fault;
    fm_bits[1][flux_pkg::F_TL_OVF] = tl_ovf_ev;
    fm_valid[1] = (fm_bits[1] != '0);
    fm_pc[1]    = '0;
    fm_bits[2]  = '0;
    fm_bits[2][flux_pkg::F_WATCHDOG] = wd_exp[0];
    fm_bits[2][flux_pkg::F_TIMEOUT]  = wd_exp[1];
    fm_bits[2][flux_pkg::F_HOST]     = host_fault_p;
    fm_bits[2][flux_pkg::F_PARITY]   = (m_rsp_valid[1] || m_rsp_valid[2]) && (bus_err_parity != '0);
    fm_bits[2][flux_pkg::F_MEMADDR]  = (m_rsp_valid[1] || m_rsp_valid[2]) && bus_err_addr;
    fm_valid[2] = (fm_bits[2] != '0);
    fm_pc[2]    = core_pc;
  end
  fault_manager #(.NSRC(3)) u_fm (
    .clk(clk), .rst_n(rst_n), .src_valid(fm_valid), .src_bits(fm_bits), .src_pc(fm_pc), .tstamp(tstamp),
    .enable(fault_en_q), .halt_mask(fault_halt_q), .clr_we(clr_fault_we), .clr_bits(clr_fault_bits),
    .status(fault_status), .first_valid(ff_valid), .first_id(ff_id), .first_pc(ff_pc), .first_time(ff_time),
    .count(fault_count), .halt_req(halt_req), .irq(fm_irq));

  // interrupts: done (rising) and fault
  logic done_d;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      done_d   <= 1'b0;
      irq_st_q <= '0;
    end else begin
      done_d <= core_done;
      if (core_done && !done_d) irq_st_q[0] <= 1'b1;
      if (fm_irq) irq_st_q[1] <= 1'b1;
      if (reg_we && reg_waddr == 16'h0028) irq_st_q <= irq_st_q & ~reg_wdata[1:0];
    end
  end
  assign irq = |(irq_st_q & irq_en_q);

  // running-cycle counter
  logic [31:0] cycles_q;
  always_ff @(posedge clk) begin
    if (!rst_n || start_p) cycles_q <= '0;
    else if (core_running) cycles_q <= cycles_q + 32'd1;
  end

  // ===========================================================================
  // register read mux
  // ===========================================================================
  always_ff @(posedge clk) begin
    if (reg_re) begin
      logic [31:0] r;
      r = 32'h0;
      case (reg_raddr)
        16'h0000: r = 32'h53464C58;
        16'h0004: r = 32'h00010000;
        16'h0008: r = {4'b0, 4'(DIV_BPC), 4'(PIPELINE_DEPTH), 3'b0, 1'(FP_MODE), 8'(W), 8'(LANES)};
        16'h000C: r = {16'(SCRATCHPAD_SIZE), 16'(IMEM_DEPTH)};
        16'h0014: r = {23'b0, irq, ts_valid, ls_conv, sw_done, frame_pending, dma_busy, core_halted, core_done, core_running};
        16'h0018: r = 32'(start_pc_q);
        16'h001C: r = 32'(core_pc);
        16'h0020: r = 32'(frm_q);
        16'h0024: r = 32'(irq_en_q);
        16'h0028: r = 32'(irq_st_q);
        16'h002C: r = 32'(fflags_q);
        16'h0030: r = 32'(fault_status);
        16'h0034: r = 32'(fault_en_q);
        16'h0038: r = 32'(fault_halt_q);
        16'h003C: r = {ff_valid, 26'b0, ff_id};
        16'h0040: r = 32'(ff_pc);
        16'h0044: r = ff_time;
        16'h0048: r = fault_count;
        16'h004C: r = wdt_limit_q;
        16'h0050: r = dma_timeout_q;
        16'h0054: r = tstamp;
        16'h0058: r = 32'(ts_prescale_q);
        16'h0060: r = cycles_q;
        16'h0064: r = p_ret;
        16'h0068: r = p_iss;
        16'h006C: r = p_stall;
        16'h0070: r = p_lops;
        16'h0074: r = p_ld;
        16'h0078: r = p_st;
        16'h007C: r = st_upd;
        16'h00C0: r = bus_acc;
        16'h00C4: r = bus_conf;
        16'h00C8: r = result_writes;
        16'h00CC: r = 32'(result_hw);
        16'h00D0: r = 32'(bank_sel);
        16'h0100: r = 32'(mw_sel_q);
        16'h0104: r = 32'(mw_row_q);
        16'h0108: r = 32'(mw_lane_q);
        16'h011C: r = mw_rlo_q;
        16'h0120: r = mw_rhi_q;
        16'h0124: r = {mw_pend_q, 21'b0, mw_aerr_q, mw_perr_q, 4'b0, mw_rq_q};
        16'h0180: r = 32'(im_addr_q);
        16'h0204: r = hi32(res_rtol_q);   16'h0200: r = res_rtol_q[31:0];
        16'h0218: r = res_viol;
        16'h021C: r = cons_viol;
        16'h0220: r = cons_resid[31:0];   16'h0224: r = hi32(cons_resid);
        16'h0228: r = cons_ref[31:0];     16'h022C: r = hi32(cons_ref);
        16'h0230: r = con_pass;
        16'h0234: r = con_fail;
        16'h0238: r = 32'(con_mask);
        16'h0240: r = ts_t[31:0];         16'h0244: r = hi32(ts_t);
        16'h0248: r = ts_dt[31:0];        16'h024C: r = hi32(ts_dt);
        16'h0250: r = ts_step;
        16'h0254: r = 32'(ts_stages_q);
        16'h0280: r = 32'(sw_dims_q);
        16'h0298: r = sw_count_q[sw_dsel_q];
        16'h029C: r = sw_base;
        16'h02A0: r = sw_total;
        16'h02A4: r = {30'b0, sw_ok, sw_done};
        16'h02C0: r = 32'(ls_dims_q);
        16'h02D4: r = 32'(ls_maxit_q);
        16'h02D8: r = sr_best[31:0];      16'h02DC: r = hi32(sr_best);
        16'h02E0: r = sr_bidx;
        16'h02E4: r = 32'(ls_iter);
        16'h02E8: r = 32'(ls_conv);
        16'h02EC: r = ls_center[ls_dsel_q*W +: 32];
        16'h02F0: r = hi32(ls_center[ls_dsel_q*W +: W]);
        16'h02F4: r = ls_step[ls_dsel_q*W +: 32];
        16'h02F8: r = hi32(ls_step[ls_dsel_q*W +: W]);
        16'h0304: r = 32'(dma_mem_q);
        16'h0308: r = 32'(dma_row_q);
        16'h030C: r = dma_len_q;
        16'h0310: r = {29'b0, dma_err, dma_done, dma_busy};
        16'h0314: r = dma_count;
        16'h0318: r = si_beats;
        16'h031C: r = so_beats;
        16'h0380: r = {frame_pending, 23'b0, 8'(tl_level)};
        16'h0384: r = tl_rx;
        16'h0388: r = tl_acc;
        16'h038C: r = tl_drop;
        16'h0390: r = tl_crc;
        16'h0394: r = tl_seq;
        16'h0398: r = tl_tse;
        16'h039C: r = tl_ovf;
        16'h03A0: r = tl_rng;
        16'h03A4: r = tl_mal;
        16'h03A8: r = tl_frames;
        16'h03AC: r = ts_last_delta;
        16'h03B0: r = tl_gap_q;
        default: begin
          if (reg_raddr >= 16'h0080 && reg_raddr < 16'h0080 + 16'(4 * flux_pkg::NUM_FU))
            r = p_fu[(reg_raddr - 16'h0080) >> 2];
          else if (reg_raddr >= 16'h0128 && reg_raddr < 16'h0128 + 16'(4 * flux_pkg::NUM_MEMS))
            r = {18'b0, mem_scale_q[(reg_raddr - 16'h0128) >> 2], 5'b0, mem_prec_q[(reg_raddr - 16'h0128) >> 2]};
        end
      endcase
      reg_rdata <= r;
    end
  end
endmodule
