# =============================================================================
# Silica Flux -- numerical validation statistics
# -----------------------------------------------------------------------------
#   Rscript r/validation.R
# Inputs  reports/numerics/*.csv           (per-vector RTL vs reference records
#                                           written by the cocotb regressions)
#         reports/csv/numerics_summary.csv  (python/analysis/report.py)
#         reports/workload/*.csv            (end-to-end workload)
# Outputs reports/figures/validation_*.png, reports/r_validation.csv
#   * error histograms (ULP vs infinitely precise result) per primitive
#   * RTL / reference bit-exact agreement per primitive
#   * FP32 vs FP64 precision comparison (relative error)
#   * Monte Carlo validation: bootstrap confidence intervals of mean error
#   * residual plots and design-space sensitivity of the workload
# =============================================================================
source(file.path(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))), "statistics.R"))
root <- sf_root()
nd <- file.path(root, "reports", "numerics")
fig <- file.path(root, "reports", "figures")
files <- list.files(nd, pattern = "\\.csv$", full.names = TRUE)
rows <- list()
for (f in files) {
  d <- read_sf(f)
  name <- sub("\\.csv$", "", basename(f))
  m <- if ("match" %in% names(d)) d$match else rep(1, nrow(d))
  u <- if ("ulp_err" %in% names(d)) d$ulp_err[d$ulp_err >= 0] else numeric(0)
  s <- sf_summary(u)
  ci <- if (length(u) > 10) sf_bootstrap(u) else c(estimate = NA, lo = NA, hi = NA)
  rows[[name]] <- data.frame(primitive = name, vectors = nrow(d), bit_exact = mean(m), failures = sum(m == 0),
                             ulp_max = s[["max"]], ulp_mean = s[["mean"]], ulp_rms = s[["rms"]],
                             ulp_p99 = s[["p99"]], mean_ci_lo = ci[["lo"]], mean_ci_hi = ci[["hi"]])
  if (length(u) > 10) {
    sf_png(file.path(fig, paste0("validation_hist_", name, ".png")))
    sf_hist(u, paste("ULP error vs exact result --", name), "error [ULP]")
    dev.off()
  }
}
tab <- do.call(rbind, rows)
sf_write_table(tab, file.path(root, "reports", "r_validation.csv"))
print(tab[, c("primitive", "vectors", "bit_exact", "failures", "ulp_max", "ulp_mean", "ulp_rms")], row.names = FALSE)

# agreement chart
sf_png(file.path(fig, "validation_agreement.png"), 1000, 520)
graphics::par(mar = c(9, 4.6, 3.2, 1.2))
b <- graphics::barplot(100 * tab$bit_exact, names.arg = tab$primitive, las = 2, col = SF$navy, border = NA,
                       ylim = c(0, 105), ylab = "bit-exact agreement [%]",
                       main = "RTL / golden-model agreement per primitive (value + IEEE flags)")
graphics::text(b, 100 * tab$bit_exact + 3, labels = tab$vectors, cex = 0.7, col = SF$graphite)
dev.off()

# FP32 vs FP64 precision comparison from the SFU characterisation
sp <- file.path(root, "reports", "csv", "numerics_summary.csv")
if (file.exists(sp)) {
  s <- read_sf(sp)
  s <- s[s$kind == "sfu", ]
  if (nrow(s) > 0) {
    sf_png(file.path(fig, "validation_precision.png"), 900, 520)
    m <- rbind(s$max_ulp, s$mean_ulp)
    graphics::barplot(m, beside = TRUE, names.arg = s$name, col = c(SF$steel, SF$blue), border = NA,
                      ylab = "error [ULP of the target format]", ylim = c(0, 0.6),
                      main = "Special-function accuracy, FP32 vs FP64 (max and mean ULP)")
    graphics::abline(h = 0.5, col = SF$amber, lty = 2)
    graphics::legend("topright", c("max", "mean", "0.5 ULP (correct rounding)"), fill = c(SF$steel, SF$blue, NA),
                     border = NA, lty = c(NA, NA, 2), col = c(NA, NA, SF$amber), bty = "n")
    dev.off()
  }
}

# workload residuals and design-space sensitivity
wd <- file.path(root, "reports", "workload")
if (file.exists(file.path(wd, "thermal_final.csv"))) {
  f <- read_sf(file.path(wd, "thermal_final.csv"))
  sf_png(file.path(fig, "workload_residuals.png"), 900, 480)
  cols <- ifelse(f$residual_quality >= 8, SF$red, SF$steel)
  graphics::barplot(f$residual, names.arg = f$node, col = cols, border = NA, ylab = "measured - model [K]",
                    xlab = "node / telemetry channel", main = "Digital-twin residuals (red: flagged Q_SUSPECT)")
  graphics::abline(h = 0, col = SF$graphite)
  dev.off()
  t <- read_sf(file.path(wd, "thermal_trajectory.csv"))
  sf_png(file.path(fig, "workload_trajectory.png"), 900, 520)
  tc <- grep("^T", names(t))
  graphics::matplot(t$time_s, as.matrix(t[, tc]), type = "l", lty = 1, lwd = 1.6,
                    col = grDevices::colorRampPalette(c(SF$navy, SF$blue, SF$steel))(length(tc)),
                    xlab = "time [s]", ylab = "temperature [K]", main = "Thermal network transient (RK4, hardware)")
  sf_grid()
  dev.off()
}
if (file.exists(file.path(wd, "design_sweep.csv"))) {
  s <- read_sf(file.path(wd, "design_sweep.csv"))
  gs <- sort(unique(s$Gs)); pw <- sort(unique(s$P))
  z <- matrix(NA, length(gs), length(pw))
  for (i in seq_len(nrow(s))) z[match(s$Gs[i], gs), match(s$P[i], pw)] <- log10(s$J[i])
  sf_png(file.path(fig, "workload_design_space.png"), 820, 620)
  graphics::image(gs, pw, z, col = grDevices::colorRampPalette(c(SF$navy, SF$blue, SF$grey, SF$paper))(64),
                  xlab = "Gs [W/K]", ylab = "P [W]", main = "Design sweep: log10 objective (x = infeasible)")
  inf <- s[!as.logical(s$feasible), ]
  graphics::points(inf$Gs, inf$P, pch = 4, col = SF$grey, lwd = 2)
  b <- s[which.min(ifelse(as.logical(s$feasible), s$J, Inf)), ]
  graphics::points(b$Gs, b$P, pch = 21, bg = SF$amber, col = SF$paper, cex = 1.6, lwd = 2)
  dev.off()

  # bilinear interpolation of a hardware-computed grid quantity at (g, p)
  grid_of <- function(col) {
    m <- matrix(NA, length(gs), length(pw))
    for (i in seq_len(nrow(s))) m[match(s$Gs[i], gs), match(s$P[i], pw)] <- col[i]
    m
  }
  interp2 <- function(m, g, p) {
    i <- pmin(pmax(findInterval(g, gs), 1), length(gs) - 1)
    j <- pmin(pmax(findInterval(p, pw), 1), length(pw) - 1)
    u <- (g - gs[i]) / (gs[i + 1] - gs[i]); v <- (p - pw[j]) / (pw[j + 1] - pw[j])
    (1 - u) * (1 - v) * m[cbind(i, j)] + u * (1 - v) * m[cbind(i + 1, j)] +
      (1 - u) * v * m[cbind(i, j + 1)] + u * v * m[cbind(i + 1, j + 1)]
  }
  logJ <- grid_of(log(s$J)); marg <- grid_of(s$margin)

  # local sensitivity: central differences of log J and of the thermal margin
  # with respect to log(parameter) at the hardware arg-min
  h <- 0.05
  sens <- data.frame(
    parameter = c("Gs", "P"),
    dlogJ_dlog = c((interp2(logJ, b$Gs * (1 + h), b$P) - interp2(logJ, b$Gs * (1 - h), b$P)) / (2 * h),
                   (interp2(logJ, b$Gs, b$P * (1 + h)) - interp2(logJ, b$Gs, b$P * (1 - h))) / (2 * h)),
    dmargin_dlog_K = c((interp2(marg, b$Gs * (1 + h), b$P) - interp2(marg, b$Gs * (1 - h), b$P)) / (2 * h),
                       (interp2(marg, b$Gs, b$P * (1 + h)) - interp2(marg, b$Gs, b$P * (1 - h))) / (2 * h)))
  sf_write_table(sens, file.path(root, "reports", "r_sensitivity.csv"))

  # Monte Carlo: as-built tolerance of the design (Gs, P ~ independent normal,
  # 5 % relative standard deviation) propagated through the hardware-computed
  # design surface.  Output: distribution of the objective and the probability
  # of violating the peak-temperature constraint (margin < 0).
  set.seed(2026)
  n <- 20000
  g <- pmin(pmax(stats::rnorm(n, b$Gs, 0.05 * b$Gs), min(gs)), max(gs))
  p <- pmin(pmax(stats::rnorm(n, b$P, 0.05 * b$P), min(pw)), max(pw))
  Jmc <- exp(interp2(logJ, g, p)); Mmc <- interp2(marg, g, p)
  ci <- sf_bootstrap(Mmc < 0, stat = mean)
  mc <- data.frame(samples = n, sigma_rel = 0.05, J_nominal = b$J, J_mean = mean(Jmc),
                   J_p05 = stats::quantile(Jmc, 0.05), J_p95 = stats::quantile(Jmc, 0.95),
                   margin_mean_K = mean(Mmc), margin_p05_K = stats::quantile(Mmc, 0.05),
                   p_violation = mean(Mmc < 0), p_violation_lo = ci[["lo"]], p_violation_hi = ci[["hi"]])
  sf_write_table(mc, file.path(root, "reports", "r_monte_carlo.csv"))
  sf_png(file.path(fig, "workload_monte_carlo.png"), 900, 480)
  graphics::par(mfrow = c(1, 2))
  sf_hist(log10(Jmc), "Objective under 5 % parameter tolerance", "log10 J")
  sf_hist(Mmc, "Peak-temperature margin", "margin [K]")
  graphics::abline(v = 0, col = SF$graphite, lwd = 2, lty = 2)   # constraint limit (not a fault)
  dev.off()
}
cat("R validation complete:", nrow(tab), "primitives\n")
