# =============================================================================
# Silica Flux -- statistical laboratory: shared functions
# -----------------------------------------------------------------------------
# Base R only (no CRAN dependencies) so the analysis runs on any R >= 4.0.
# Sourced by validation.R and benchmark.R; also usable interactively:
#   source("r/statistics.R"); sf_summary(read_sf("reports/numerics/fma_fp32_lat4.csv")$ulp_err)
# Palette: graphite, navy, engineering grey, steel, muted blue; amber for
# warnings, red only for genuine faults.
# =============================================================================

SF <- list(
  graphite = "#2B2F36", navy = "#1F3A5F", grey = "#8A9099", steel = "#5E7A94",
  blue = "#4F7CAC", amber = "#C8963E", red = "#B23A3A", paper = "#FAFAF8", rule = "#D5D8DC"
)

sf_root <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", args[grep("^--file=", args)])
  if (length(f) == 1) normalizePath(file.path(dirname(f), "..")) else normalizePath(".")
}

read_sf <- function(path) {
  if (!file.exists(path)) stop(paste("missing input:", path))
  utils::read.csv(path, stringsAsFactors = FALSE)
}

sf_summary <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) == 0) return(c(n = 0, max = NA, mean = NA, rms = NA, p50 = NA, p99 = NA))
  c(n = length(x), max = max(x), mean = mean(x), rms = sqrt(mean(x^2)),
    p50 = unname(stats::quantile(x, 0.5)), p99 = unname(stats::quantile(x, 0.99)))
}

# bootstrap confidence interval of a statistic (Monte Carlo validation)
sf_bootstrap <- function(x, stat = mean, n = 2000, conf = 0.95, seed = 7) {
  x <- x[is.finite(x)]
  set.seed(seed)
  b <- replicate(n, stat(sample(x, length(x), replace = TRUE)))
  q <- stats::quantile(b, c((1 - conf) / 2, 1 - (1 - conf) / 2))
  c(estimate = stat(x), lo = unname(q[1]), hi = unname(q[2]))
}

sf_png <- function(path, w = 900, h = 560) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  grDevices::png(path, width = w, height = h, type = "cairo", bg = SF$paper)
  graphics::par(family = "sans", col.axis = SF$graphite, col.lab = SF$graphite, col.main = SF$graphite,
                fg = SF$grey, mar = c(4.2, 4.6, 3.2, 1.2), las = 1, cex.main = 1.05, font.main = 1)
}

sf_hist <- function(x, main, xlab, col = SF$steel, breaks = 40) {
  x <- x[is.finite(x)]
  graphics::hist(x, breaks = breaks, main = main, xlab = xlab, col = col, border = SF$paper)
  graphics::abline(v = mean(x), col = SF$navy, lwd = 2)
  graphics::abline(v = max(x), col = SF$amber, lwd = 2, lty = 2)
  graphics::legend("topright", c(sprintf("mean %.4g", mean(x)), sprintf("max %.4g", max(x))),
                   col = c(SF$navy, SF$amber), lty = c(1, 2), lwd = 2, bty = "n", text.col = SF$graphite)
}

sf_grid <- function() graphics::grid(col = SF$rule, lty = 1)

sf_write_table <- function(df, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(df, path, row.names = FALSE)
}
