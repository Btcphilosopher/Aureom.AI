# =============================================================================
# Silica Flux -- benchmark analysis
# -----------------------------------------------------------------------------
#   Rscript r/benchmark.R
# Inputs  reports/benchmark/benchmark.csv, fu_utilisation.csv
#         reports/numerics/*.csv (per-transaction latency of every primitive)
# Outputs reports/figures/bench_*.png, reports/r_benchmark.csv
#   * latency distributions per functional unit
#   * throughput (FLOP / cycle) versus lane count, per kernel
#   * analytical model vs measured cycles
#   * functional-unit utilisation
# Clock-scaled figures are estimates at assumed clocks, never measurements.
# =============================================================================
source(file.path(dirname(sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE))), "statistics.R"))
root <- sf_root()
fig <- file.path(root, "reports", "figures")
b <- read_sf(file.path(root, "reports", "benchmark", "benchmark.csv"))

# latency distributions
nd <- file.path(root, "reports", "numerics")
lat <- list()
for (f in list.files(nd, pattern = "\\.csv$", full.names = TRUE)) {
  d <- read_sf(f)
  if ("latency" %in% names(d)) lat[[sub("\\.csv$", "", basename(f))]] <- d$latency
}
if (length(lat)) {
  sf_png(file.path(fig, "bench_latency.png"), 1100, 560)
  graphics::par(mar = c(9, 4.6, 3.2, 1.2))
  graphics::boxplot(lat, las = 2, col = SF$steel, border = SF$graphite, outline = TRUE, pch = 20,
                    ylab = "cycles (accept -> result, incl. back-pressure)",
                    main = "Pipeline / unit latency distributions (cocotb, random back-pressure)")
  dev.off()
  ls <- do.call(rbind, lapply(names(lat), function(n) data.frame(unit = n, min = min(lat[[n]]),
                  median = stats::median(lat[[n]]), mean = mean(lat[[n]]), max = max(lat[[n]]))))
  sf_write_table(ls, file.path(root, "reports", "r_latency.csv"))
}

# throughput curves: FLOP/cycle vs lanes (FP32 builds)
f32 <- b[b$precision == "fp32", ]
ks <- unique(f32$kernel)
sf_png(file.path(fig, "bench_throughput.png"), 900, 560)
cols <- c(SF$navy, SF$blue, SF$steel, SF$grey, SF$amber)
plot(NA, xlim = range(f32$lanes), ylim = c(0, max(2 * f32$lanes)), log = "", xlab = "vector lanes",
     ylab = "FLOP per cycle", main = "Sustained throughput vs lanes (binary32, measured on RTL)", xaxt = "n")
graphics::axis(1, at = sort(unique(f32$lanes)))
sf_grid()
graphics::lines(sort(unique(f32$lanes)), 2 * sort(unique(f32$lanes)), lty = 2, col = SF$graphite)
for (i in seq_along(ks)) {
  k <- f32[f32$kernel == ks[i], ]
  k <- k[order(k$lanes), ]
  graphics::lines(k$lanes, k$flops_per_cycle, type = "b", pch = 19, lwd = 2, col = cols[(i - 1) %% 5 + 1])
}
graphics::legend("topleft", c("VALU peak (2 x lanes)", ks), lty = c(2, rep(1, length(ks))), pch = c(NA, rep(19, length(ks))),
                 col = c(SF$graphite, cols[seq_along(ks)]), bty = "n", cex = 0.85)
dev.off()

# model vs measured
sf_png(file.path(fig, "bench_model_vs_measured.png"), 760, 620)
lim <- range(c(b$cycles, b$predicted_cycles))
plot(b$cycles, b$predicted_cycles, log = "xy", pch = 19, col = SF$navy, xlim = lim, ylim = lim,
     xlab = "measured RTL cycles", ylab = "analytical model cycles", main = "Performance model vs RTL")
graphics::abline(0, 1, col = SF$amber, lty = 2)
sf_grid()
dev.off()

# utilisation
u <- read_sf(file.path(root, "reports", "benchmark", "fu_utilisation.csv"))
u8 <- u[u$config == "fp32_l8", ]
if (nrow(u8)) {
  m <- tapply(u8$busy_fraction, list(u8$unit, u8$kernel), mean)
  sf_png(file.path(fig, "bench_utilisation.png"), 1100, 560)
  graphics::par(mar = c(6, 4.6, 3.2, 1.2))
  graphics::barplot(m, beside = TRUE, col = grDevices::colorRampPalette(c(SF$navy, SF$steel, SF$grey))(nrow(m)),
                    border = NA, ylab = "busy fraction", las = 1, main = "Functional-unit busy fraction per kernel (8 lanes)",
                    legend.text = rownames(m), args.legend = list(x = "topright", bty = "n", cex = 0.65, ncol = 2))
  dev.off()
}
s <- aggregate(cbind(model_error_pct, flops_per_cycle, vector_utilisation) ~ config, data = b, FUN = mean)
sf_write_table(s, file.path(root, "reports", "r_benchmark.csv"))
print(s, row.names = FALSE)
cat("R benchmark analysis complete\n")
