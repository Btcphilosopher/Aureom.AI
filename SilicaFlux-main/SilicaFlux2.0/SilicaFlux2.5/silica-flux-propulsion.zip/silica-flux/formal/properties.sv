// =============================================================================
// Silica Flux -- formal property harnesses (SymbiYosys / yosys-smtbmc)
// -----------------------------------------------------------------------------
// Each harness instantiates one RTL block, constrains its environment with
// assume(), and states the block's contract with assert().  Proven by
// bounded model checking and k-induction (formal/*.sby, run by
// formal/run_formal.py).  Written in the immediate-assertion style accepted by
// the open-source Yosys front end; formal/assertions.sv holds the equivalent
// concurrent SVA checkers for simulation and commercial formal tools.
//
//   f_pipe_reg     valid/ready stability, no loss / duplication / reordering
//   f_skid         same contract for the 2-entry skid buffer, registered ready
//   f_fifo         occupancy accounting, ordering, overflow/underflow safety
//   f_rr_arb       grant one-hot, grant subset of request, no lost request
//   f_axil         AXI4-Lite response stability, one outstanding transaction
//   f_watchdog     expiry exactly when starved for LIMIT cycles
//   f_fault_mgr    no fault event is ever lost; halt request is exact
//   f_fma_comm     arithmetic invariant: a*b == b*a, a+c == c+a (all
//                  rounding modes, all encodings) on a mini-float FMA
//   reset          every harness proves all valid bits clear after reset
// =============================================================================

// -----------------------------------------------------------------------------
module f_pipe_reg (input logic clk);
  localparam int W = 8;
  logic rst_n, in_valid, in_ready, out_valid, out_ready;
  logic [W-1:0] in_data, out_data;
  logic [W-1:0] seq_in, seq_out;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  sf_pipe_reg #(.W(W)) dut (.clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(in_ready),
    .in_data(in_data), .out_valid(out_valid), .out_ready(out_ready), .out_data(out_data));
  // the environment presents a sequence number and holds it while not accepted
  always @(*) assume (in_data == seq_in);
  always @(posedge clk) begin
    if (!rst_n) begin
      seq_in <= '0; seq_out <= '0;
    end else begin
      if (in_valid && in_ready) seq_in <= seq_in + 1'b1;
      if (out_valid && out_ready) seq_out <= seq_out + 1'b1;
    end
  end
  always @(posedge clk) if (!init && $past(rst_n) && $past(in_valid && !in_ready)) assume (in_valid);
  always @(posedge clk) begin
    if (!init) begin
      if (!$past(rst_n)) assert (!out_valid);                                  // reset clears valid
      if ($past(rst_n) && rst_n && $past(out_valid && !out_ready)) begin
        assert (out_valid);                                                    // valid held
        assert (out_data == $past(out_data));                                  // payload stable
      end
      if (rst_n && out_valid) assert (out_data == seq_out);                    // in order, no loss/dup
      if (rst_n) assert ((seq_in - seq_out) == (out_valid ? 8'd1 : 8'd0));     // occupancy
    end
  end
endmodule

// -----------------------------------------------------------------------------
module f_skid (input logic clk);
  localparam int W = 8;
  logic rst_n, in_valid, in_ready, out_valid, out_ready;
  logic [W-1:0] in_data, out_data, seq_in, seq_out;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  sf_skid #(.W(W)) dut (.clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(in_ready),
    .in_data(in_data), .out_valid(out_valid), .out_ready(out_ready), .out_data(out_data));
  always @(*) assume (in_data == seq_in);
  always @(posedge clk) begin
    if (!rst_n) begin
      seq_in <= '0; seq_out <= '0;
    end else begin
      if (in_valid && in_ready) seq_in <= seq_in + 1'b1;
      if (out_valid && out_ready) seq_out <= seq_out + 1'b1;
    end
  end
  always @(posedge clk) begin
    if (!init) begin
      if (!$past(rst_n)) assert (!out_valid);
      if ($past(rst_n) && rst_n && $past(out_valid && !out_ready)) begin
        assert (out_valid);
        assert (out_data == $past(out_data));
      end
      if (rst_n && out_valid) assert (out_data == seq_out);
      if (rst_n) assert ((seq_in - seq_out) <= 8'd2);                          // at most two in flight
      if (rst_n && !in_ready) assert (out_valid);                              // stall only when holding data
    end
  end
endmodule

// -----------------------------------------------------------------------------
module f_fifo (input logic clk);
  localparam int W = 8, DEPTH = 4;
  logic rst_n, push, pop, empty, full, overflow, underflow;
  logic [W-1:0] wdata, rdata, seq_in, seq_out;
  logic [2:0] count;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  sf_fifo #(.W(W), .DEPTH(DEPTH)) dut (.clk(clk), .rst_n(rst_n), .push(push), .wdata(wdata), .pop(pop),
    .rdata(rdata), .empty(empty), .full(full), .count(count), .overflow(overflow), .underflow(underflow),
    .clr_flags(1'b0));
  always @(*) assume (wdata == seq_in);
  always @(posedge clk) begin
    if (!rst_n) begin
      seq_in <= '0; seq_out <= '0;
    end else begin
      if (push && !full) seq_in <= seq_in + 1'b1;
      if (pop && !empty) seq_out <= seq_out + 1'b1;
    end
  end
  always @(posedge clk) begin
    if (!init) begin
      if (!$past(rst_n)) assert (empty && !full && count == 0);
      if (rst_n) begin
        assert (count <= DEPTH);
        assert (empty == (count == 0));
        assert (full == (count == DEPTH));
        assert ((seq_in - seq_out) == 8'(count));                              // exact accounting
        if (!empty) assert (rdata == seq_out);                                 // FIFO order
      end
      if ($past(rst_n) && rst_n && $past(push && full)) assert (overflow);     // overflow is never silent
      if ($past(rst_n) && rst_n && $past(overflow)) assert (overflow);         // sticky
    end
  end
endmodule

// -----------------------------------------------------------------------------
module f_rr_arb (input logic clk);
  localparam int N = 4;
  logic rst_n, advance, any;
  logic [N-1:0] req, grant;
  logic [1:0] gidx;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  sf_rr_arb #(.N(N)) dut (.clk(clk), .rst_n(rst_n), .req(req), .advance(advance), .grant(grant),
    .grant_idx(gidx), .any(any));
  always @(*) begin
    assert ((grant & (grant - 1'b1)) == '0);                                   // one-hot or zero
    assert ((grant & ~req) == '0);                                             // only requesters
    assert (any == (req != '0));                                               // work conserving
    if (any) assert (grant[gidx]);
  end
endmodule

// -----------------------------------------------------------------------------
module f_axil (input logic clk);
  logic rst_n;
  logic [7:0] awaddr, araddr, reg_waddr, reg_raddr;
  logic awvalid, awready, wvalid, wready, bvalid, bready, arvalid, arready, rvalid, rready, reg_we, reg_re;
  logic [31:0] wdata, rdata, reg_wdata, reg_rdata;
  logic [3:0] wstrb, reg_wstrb;
  logic [1:0] bresp, rresp;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  axi_lite_slave #(.AW(8)) dut (.clk(clk), .rst_n(rst_n), .s_awaddr(awaddr), .s_awvalid(awvalid),
    .s_awready(awready), .s_wdata(wdata), .s_wstrb(wstrb), .s_wvalid(wvalid), .s_wready(wready),
    .s_bresp(bresp), .s_bvalid(bvalid), .s_bready(bready), .s_araddr(araddr), .s_arvalid(arvalid),
    .s_arready(arready), .s_rdata(rdata), .s_rresp(rresp), .s_rvalid(rvalid), .s_rready(rready),
    .reg_we(reg_we), .reg_waddr(reg_waddr), .reg_wdata(reg_wdata), .reg_wstrb(reg_wstrb),
    .reg_re(reg_re), .reg_raddr(reg_raddr), .reg_rdata(reg_rdata));
  // master obeys AXI: valid held until ready
  always @(posedge clk) if (!init && $past(rst_n) && rst_n) begin
    if ($past(awvalid && !awready)) assume (awvalid && awaddr == $past(awaddr));
    if ($past(wvalid && !wready)) assume (wvalid && wdata == $past(wdata));
    if ($past(arvalid && !arready)) assume (arvalid && araddr == $past(araddr));
  end
  logic [2:0] wr_out, wr_resp;
  always @(posedge clk) begin
    if (!rst_n) begin wr_out <= 0; wr_resp <= 0; end
    else begin
      if (reg_we) wr_out <= wr_out + 1'b1;
      if (bvalid && bready) wr_resp <= wr_resp + 1'b1;
    end
  end
  always @(posedge clk) begin
    if (!init) begin
      if (!$past(rst_n)) assert (!bvalid && !rvalid);
      if ($past(rst_n) && rst_n) begin
        if ($past(bvalid && !bready)) assert (bvalid);                         // response held
        if ($past(rvalid && !rready)) assert (rvalid && rdata == $past(rdata)); // read data stable
        if ($past(reg_we)) assert (bvalid);                                    // every write answered
      end
      if (rst_n) assert ((wr_out - wr_resp) <= 3'd1);                          // one outstanding write
      if (rst_n) assert (!(reg_we && bvalid));                                 // no duplicate commit
      assert (bresp == 2'b00 && rresp == 2'b00);
    end
  end
endmodule

// -----------------------------------------------------------------------------
module f_watchdog (input logic clk);
  logic rst_n;
  logic [0:0] en, kick, expired, tripped;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  watchdog #(.N(1)) dut (.clk(clk), .rst_n(rst_n), .enable(en), .kick(kick), .limit(32'd5),
    .expired(expired), .tripped(tripped));
  logic [5:0] hist;            // hist[k] = cycle t-1-k was enabled, un-kicked and out of reset
  always @(posedge clk) hist <= {hist[4:0], rst_n && en[0] && !kick[0]};
  logic [3:0] age;
  always @(posedge clk) age <= init ? 4'd0 : ((age == 4'hF) ? age : age + 1'b1);
  always @(posedge clk) begin
    if (!init && rst_n && age >= 4'd6) begin
      if (expired[0]) assert (&hist[4:0]);                                     // >= LIMIT starved cycles
      if ($past(rst_n && kick[0] && en[0])) assert (!tripped[0]);               // kicking re-arms
      if ($past(rst_n && !en[0])) assert (!tripped[0] && !expired[0]);          // disabled never fires
    end
  end
endmodule

// -----------------------------------------------------------------------------
module f_fault_mgr (input logic clk);
  localparam int FW = 24;
  logic rst_n, clr_we, first_valid, halt_req, irq;
  logic [1:0] src_valid;
  logic [1:0][FW-1:0] src_bits;
  logic [1:0][15:0] src_pc;
  logic [FW-1:0] enable, halt_mask, clr_bits, status;
  logic [4:0] first_id;
  logic [15:0] first_pc;
  logic [31:0] first_time, count;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  fault_manager #(.NSRC(2)) dut (.clk(clk), .rst_n(rst_n), .src_valid(src_valid), .src_bits(src_bits),
    .src_pc(src_pc), .tstamp(32'd0), .enable(enable), .halt_mask(halt_mask), .clr_we(clr_we),
    .clr_bits(clr_bits), .status(status), .first_valid(first_valid), .first_id(first_id),
    .first_pc(first_pc), .first_time(first_time), .count(count), .halt_req(halt_req), .irq(irq));
  logic [FW-1:0] ev;
  always @(*) ev = ((src_valid[0] ? src_bits[0] : '0) | (src_valid[1] ? src_bits[1] : '0)) & enable;
  always @(posedge clk) begin
    if (!init) begin
      if (!$past(rst_n)) assert (status == '0 && !first_valid);
      if ($past(rst_n) && rst_n) assert ((status & $past(ev)) == $past(ev));   // no event lost
      if ($past(rst_n) && rst_n && !$past(clr_we)) assert ((status & $past(status)) == $past(status)); // sticky
      assert (halt_req == ((status & halt_mask) != '0));                       // exact halt
      assert (irq == (status != '0));
    end
  end
endmodule

// -----------------------------------------------------------------------------
module f_fma_comm (input logic clk);
  // mini-float: 1 sign, 4 exponent, 3 mantissa bits -- exhaustive over every
  // encoding and rounding mode, so the proof covers subnormals, infinities,
  // NaNs and every rounding path of the generic datapath.
  localparam int E = 4, M = 3, W = E + M + 1;
  logic rst_n;
  logic [W-1:0] a, b, c, r1, r2;
  logic [2:0] op, rm;
  logic [4:0] f1, f2;
  logic v1, v2, ir1, ir2;
  logic [0:0] t1, t2;
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  always @(*) assume (op == 3'd4 || op == 3'd5);           // FMUL (a*b) or FADD (a+c)
  always @(*) assume (rm <= 3'd4);
  fma_unit #(.EXP_W(E), .MAN_W(M), .LATENCY(4), .TAG_W(1)) u1 (.clk(clk), .rst_n(rst_n), .in_valid(1'b1),
    .in_ready(ir1), .op(op), .rm(rm), .a(a), .b(b), .c(c), .in_tag(1'b0), .out_valid(v1), .out_ready(1'b1),
    .result(r1), .fflags(f1), .out_tag(t1));
  // swapped operands: FMUL(b, a), FADD(c, a)
  fma_unit #(.EXP_W(E), .MAN_W(M), .LATENCY(4), .TAG_W(1)) u2 (.clk(clk), .rst_n(rst_n), .in_valid(1'b1),
    .in_ready(ir2), .op(op), .rm(rm), .a((op == 3'd4) ? b : c), .b((op == 3'd4) ? a : b),
    .c((op == 3'd4) ? c : a), .in_tag(1'b0), .out_valid(v2), .out_ready(1'b1), .result(r2), .fflags(f2),
    .out_tag(t2));
  always @(posedge clk) begin
    if (!init) begin
      assert (v1 == v2);                                     // identical pipelines
      if (v1) assert (r1 == r2 && f1 == f2);                 // commutativity incl. flags
      if (!$past(rst_n)) assert (!v1);                       // reset clears the pipeline
    end
  end
endmodule
