#!/usr/bin/env python3
"""
Run the formal property harnesses (formal/properties.sv) with SymbiYosys.

    python3 formal/run_formal.py            # all harnesses
    python3 formal/run_formal.py f_fifo

Tooling: YoWASP Yosys/SymbiYosys (pip install yowasp-yosys yowasp-sby) with
the z3 SMT solver (smtbmc engine).  For each control harness the script
attempts an unbounded proof (k-induction, mode prove); if induction is
inconclusive the bounded result (BMC to the stated depth) is reported
instead -- never silently upgraded to a proof.

Datapath harnesses (f_fma_comm) bit-blast multipliers and shifters, which the
SMT flow handles poorly; they run as bounded model checks with Yosys' built-in
SAT solver (MiniSat, `sat -seq N -prove-asserts`), followed by a non-vacuity
check: the same solver must find a trace in which the checked output is valid
within the bound, otherwise the harness is reported as VACUOUS.
Results: reports/formal.json
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SBY = shutil.which("yowasp-sby") or shutil.which("sby")
FILES_BASE = ["rtl/core/flux_pkg.sv", "rtl/interconnect/sf_primitives.sv"]
HARNESSES = {
    "f_pipe_reg":  (FILES_BASE, 12, "sf_pipe_reg valid/ready contract, ordering, occupancy, reset"),
    "f_skid":      (FILES_BASE, 12, "sf_skid contract, <=2 in flight, registered ready, reset"),
    "f_fifo":      (FILES_BASE, 14, "sf_fifo accounting, FIFO order, overflow never silent, reset"),
    "f_rr_arb":    (FILES_BASE, 8, "arbiter grant one-hot, subset of requests, work conserving"),
    "f_axil":      (FILES_BASE + ["rtl/interconnect/axi_lite_slave.sv"], 12,
                    "AXI4-Lite response stability, single outstanding write, no duplicate commit"),
    "f_watchdog":  (FILES_BASE + ["rtl/safety/watchdog.sv"], 14, "expiry only after LIMIT starved cycles"),
    "f_fault_mgr": (FILES_BASE + ["rtl/safety/fault_manager.sv"], 8, "no fault event lost, exact halt request"),
    "f_fma_comm":  (FILES_BASE + ["rtl/alu/fp_primitives.sv", "rtl/alu/fma_unit.sv"], 12,
                    "FMA arithmetic invariant a*b==b*a, a+c==c+a (all encodings, all rounding modes)"),
}
# harnesses checked with the Yosys SAT engine: name -> output-valid signal for the vacuity check
SAT_HARNESSES = {"f_fma_comm": "v1"}
YOSYS = shutil.which("yowasp-yosys") or shutil.which("yosys")


def run_sat(top: str) -> dict:
    """bounded model check with Yosys `sat` (MiniSat) + non-vacuity check"""
    files, depth, desc = HARNESSES[top]
    work = ROOT / "build" / "formal" / "sat"
    work.mkdir(parents=True, exist_ok=True)
    head = "\n".join(f"read -formal -sv -DFORMAL -Irtl/core {f}" for f in files) + \
        f"\nread -formal -sv formal/properties.sv\nprep -top {top}\nflatten\nopt -fast\nasync2sync\ndffunmap\n"
    out = {"description": desc, "depth": depth, "engine": "yosys sat (MiniSat)"}
    checks = {"bmc": f"sat -seq {depth} -prove-asserts -set-assumes -verify -timeout 3000",
              "cover": f"sat -seq {depth} -set-assumes -prove {SAT_HARNESSES[top]} 0 -timeout 3000"}
    for name, cmd in checks.items():
        ys = work / f"{top}_{name}.ys"
        ys.write_text(head + cmd + "\n")
        log = work / f"{top}_{name}.log"
        t0 = time.time()
        # paths are relative: the YoWASP (WebAssembly) build only sees the working directory
        subprocess.run([YOSYS, "-q", "-l", str(log.relative_to(ROOT)), str(ys.relative_to(ROOT))], cwd=ROOT,
                       capture_output=True, text=True, timeout=3600)
        txt = log.read_text() if log.exists() else ""
        if "no model found: SUCCESS" in txt:
            st = "PASS" if name == "bmc" else "VACUOUS"
        elif "model found: FAIL" in txt:
            st = "FAIL" if name == "bmc" else "PASS"      # cover: a trace with valid output exists
        else:
            st = "ERROR"
        out[name] = {"status": st, "seconds": round(time.time() - t0, 1)}
    if out["bmc"]["status"] == "PASS" and out["cover"]["status"] == "PASS":
        out["result"] = f"BMC PASS (depth {depth})"
    elif out["bmc"]["status"] == "PASS":
        out["result"] = "VACUOUS" if out["cover"]["status"] == "VACUOUS" else "ERROR"
    else:
        out["result"] = "FAIL" if out["bmc"]["status"] == "FAIL" else "ERROR"
    return out


def sby_text(top: str, files: list[str], depth: int, mode: str) -> str:
    reads = "\n".join(f"read -formal -sv -DFORMAL -I{ROOT}/rtl/core {Path(f).name}" for f in files)
    return f"""[options]
mode {mode}
depth {depth}

[engines]
smtbmc z3

[script]
{reads}
read -formal -sv properties.sv
prep -top {top}

[files]
{chr(10).join(str(ROOT / f) for f in files)}
{ROOT / 'formal/properties.sv'}
"""


def run(top: str) -> dict:
    if top in SAT_HARNESSES:
        return run_sat(top)
    files, depth, desc = HARNESSES[top]
    work = ROOT / "build" / "formal"
    work.mkdir(parents=True, exist_ok=True)
    out = {"description": desc, "depth": depth}
    for mode in ("prove", "bmc"):
        cfg = work / f"{top}_{mode}.sby"
        cfg.write_text(sby_text(top, files, depth, mode))
        t0 = time.time()
        cmd = [SBY, "-f"]
        if "yowasp" in SBY:   # use the YoWASP Yosys build, not an older system Yosys on PATH
            cmd += ["--yosys", shutil.which("yowasp-yosys"), "--smtbmc", shutil.which("yowasp-yosys-smtbmc")]
        r = subprocess.run(cmd + [str(cfg)], cwd=work, capture_output=True, text=True, timeout=3600)
        txt = r.stdout + r.stderr
        status = "PASS" if "DONE (PASS" in txt else ("FAIL" if "DONE (FAIL" in txt else "ERROR")
        out[mode] = {"status": status, "seconds": round(time.time() - t0, 1)}
        if status != "PASS":
            out[mode]["log_tail"] = txt[-1500:]
        if mode == "prove" and status == "PASS":
            out["result"] = "PROVEN (k-induction)"
            return out
    out["result"] = f"BMC PASS (depth {depth})" if out["bmc"]["status"] == "PASS" else "FAIL"
    return out


def main(argv):
    if SBY is None:
        print("SymbiYosys not found (pip install yowasp-yosys)")
        return 2
    names = argv or list(HARNESSES)
    res = {}
    fail = 0
    for n in names:
        res[n] = run(n)
        ok = res[n]["result"].startswith(("PROVEN", "BMC PASS"))
        fail += not ok
        print(f"[formal] {n:<12} {res[n]['result']:<24} {res[n]['description']}", flush=True)
    rep = ROOT / "reports" / "formal.json"
    rep.parent.mkdir(exist_ok=True)
    prev = json.loads(rep.read_text()) if rep.exists() else {}
    prev.update(res)
    rep.write_text(json.dumps(prev, indent=2))
    print("FORMAL:", "PASS" if fail == 0 else f"FAIL ({fail})")
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
