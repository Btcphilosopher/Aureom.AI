// =============================================================================
// Silica Flux -- concurrent SVA checkers, bound into the design
// -----------------------------------------------------------------------------
// formal/properties.sv holds the self-contained *formal* harnesses (proved or
// bounded-model-checked with SymbiYosys / Yosys SAT).  This file holds
// *simulation-time* assertions that watch the integrated chip: they are
// compiled into the Verilator system testbench (python/silica_flux/
// rtl_backend.py, `--assert`) so every full-chip regression scenario also
// checks the protocol rules below on every cycle.  A violation stops the
// simulation and fails the scenario -- nothing is reported as a warning only.
//
//   sf_sva_handshake   valid/ready: valid held until accepted, payload stable
//                      while stalled, valid never X after reset
//                      -> every functional-unit response port, the DMA/AXIS
//                         output, the AXI4-Lite B and R channels
//   sf_sva_fault_mgr   a halt request is always backed by a recorded fault;
//                      the first-fault record is sticky; the fault counter
//                      never decreases;
//                      the status register; the built-in a_sticky check in
//                      fault_manager.sv (`SF_SVA) proves no event is lost
//   sf_sva_rob         no allocation into a full retirement buffer; retired
//                      faults always carry a PC inside the program image
// =============================================================================

module sf_sva_handshake #(
  parameter int    DW   = 32,
  parameter string NAME = "handshake"
) (
  input logic          clk,
  input logic          rst_n,
  input logic          valid,
  input logic          ready,
  input logic [DW-1:0] data
);
  // valid must stay asserted until the transfer happens
  a_hold: assert property (@(posedge clk) disable iff (!rst_n)
                           valid && !ready |=> valid)
    else $error("[SVA %s] valid dropped before ready", NAME);
  // the payload must not change while the transfer is stalled
  a_stable: assert property (@(posedge clk) disable iff (!rst_n)
                             valid && !ready |=> $stable(data))
    else $error("[SVA %s] payload changed while stalled", NAME);
  // no unknown control after reset
  a_known: assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(valid))
    else $error("[SVA %s] valid is X", NAME);
endmodule

module sf_sva_fault_mgr #(parameter int W = flux_pkg::FAULT_W) (
  input logic         clk,
  input logic         rst_n,
  input logic [W-1:0] status,
  input logic [W-1:0] enable,
  input logic [W-1:0] halt_mask,
  input logic         first_valid,
  input logic [4:0]   first_id,
  input logic [31:0]  count,
  input logic         halt_req,
  input logic         clr_we
);
  // a halt request is always explained by a recorded, halting fault
  a_halt_backed: assert property (@(posedge clk) disable iff (!rst_n)
                                  halt_req |-> (status & halt_mask) != '0)
    else $error("[SVA fault_manager] halt without a recorded halting fault");
  // the first-fault record cannot be overwritten without an explicit clear
  a_first_sticky: assert property (@(posedge clk) disable iff (!rst_n)
                                   first_valid && !clr_we |=> first_valid && $stable(first_id))
    else $error("[SVA fault_manager] first-fault record changed without clear");
  // the event counter is monotonic (it is never cleared by software)
  a_count_mono: assert property (@(posedge clk) disable iff (!rst_n)
                                 1'b1 |=> count >= $past(count))
    else $error("[SVA fault_manager] fault counter decreased");
  // a valid first-fault record implies at least one recorded fault (the record
  // is released only when software clears every status bit)
  a_first_backed: assert property (@(posedge clk) disable iff (!rst_n)
                                   first_valid |-> status != '0)
    else $error("[SVA fault_manager] first-fault record without any recorded fault");
endmodule

module sf_sva_rob (
  input logic        clk,
  input logic        rst_n,
  input logic        alloc,
  input logic        full,
  input logic        retire_valid,
  input logic [15:0] retire_pc
);
  a_no_overflow: assert property (@(posedge clk) disable iff (!rst_n) alloc |-> !full)
    else $error("[SVA retirement] allocation into a full reorder buffer");
  a_retire_known: assert property (@(posedge clk) disable iff (!rst_n)
                                   retire_valid |-> !$isunknown(retire_pc))
    else $error("[SVA retirement] retired PC is X");
endmodule

// -----------------------------------------------------------------------------
// binds
// -----------------------------------------------------------------------------
`define SF_BIND_FU(MOD) \
  bind MOD sf_sva_handshake #(.DW(LANES*W), .NAME(`"MOD`")) u_sva_rsp ( \
    .clk(clk), .rst_n(rst_n), .valid(rsp_valid), .ready(rsp_ready), .data(rsp_data));

`SF_BIND_FU(vector_pipeline)
`SF_BIND_FU(reduction_unit)
`SF_BIND_FU(polynomial_unit)
`SF_BIND_FU(interpolation_unit)
`SF_BIND_FU(state_update)
`SF_BIND_FU(residual_engine)
`SF_BIND_FU(conservation_checker)
`SF_BIND_FU(objective_eval)
`SF_BIND_FU(constraint_eval)
`SF_BIND_FU(parameter_sweep)
`SF_BIND_FU(search_engine)
`SF_BIND_FU(flux_lsu)

bind axi_lite_slave sf_sva_handshake #(.DW(2), .NAME("axil_b")) u_sva_b (
  .clk(clk), .rst_n(rst_n), .valid(s_bvalid), .ready(s_bready), .data(s_bresp));
bind axi_lite_slave sf_sva_handshake #(.DW(34), .NAME("axil_r")) u_sva_r (
  .clk(clk), .rst_n(rst_n), .valid(s_rvalid), .ready(s_rready), .data({s_rresp, s_rdata}));
bind silica_flux_top sf_sva_handshake #(.DW(73), .NAME("m_axis")) u_sva_maxis (
  .clk(clk), .rst_n(rst_n), .valid(m_axis_tvalid), .ready(m_axis_tready),
  .data({m_axis_tlast, m_axis_tuser, m_axis_tdata}));
bind fault_manager sf_sva_fault_mgr u_sva_fm (
  .clk(clk), .rst_n(rst_n), .status(status), .enable(enable), .halt_mask(halt_mask),
  .first_valid(first_valid), .first_id(first_id), .count(count), .halt_req(halt_req), .clr_we(clr_we));
bind flux_retirement sf_sva_rob u_sva_rob (
  .clk(clk), .rst_n(rst_n), .alloc(alloc), .full(full), .retire_valid(retire_valid), .retire_pc(retire_pc));
