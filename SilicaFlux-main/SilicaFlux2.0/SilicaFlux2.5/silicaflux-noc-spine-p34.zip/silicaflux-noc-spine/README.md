# SilicaFlux NoC Spine — Project 34: physically aware on-chip interconnect

**Primary RTL:** [`rtl/spine/silicaflux_noc_spine.sv`](rtl/spine/silicaflux_noc_spine.sv) · Aureom.AI | SilicaFlux-HPC

The central communication spine of the SilicaFlux die floorplan: **one central routing stage** in the middle of
the spine, a **local attachment node** in every die region (ControlCore, host I/O, DMA, four vector clusters, two
tensor clusters, four scratchpad SRAM regions, the shared-SRAM subsystem, the die registers, the external-memory
interface), and **register stages on the long attachment links chosen from timing evidence**. It is built on the
verified DataFabric-NoC (Project 22): same SFB3 protocol and ports, P22's per-master front end, crossbar, FIFO and
counter page reused unmodified — a drop-in replacement for the P31 die's fabric, not a second interconnect.

> **Status — read first.** RTL simulation (Verilator 5.020), formal (Yosys 0.33 + ABC + yosys-smtbmc/z3), Yosys
> synthesis to the SkyWater sky130 HD liberty with ABC static timing **of the logic only**. **No placement, routing,
> extraction or sign-off STA was run** (OpenROAD could not be installed here), so every clock frequency is a
> synthesis-level estimate combined with a wire-delay model on **conceptual** distances taken from the floorplan
> illustration. Delivered as an archive; nothing was committed. Details: [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

## Definition of done

*Every required die region communicates correctly across the NoC, and the architecture has measured simulation
performance under realistic contention.*

* **Every die region communicates across the spine — on the real endpoints.** P31's own die-level regression, with
  only its `datafabric.sv` replaced by the spine drop-in (`integration/p31/datafabric.sv`): **SILICAFLUX_HPC 4 / 4 runs
  pass**, including the **unmodified ControlCore firmware** (boot, 188 / 188 on-die self-test checks, 21 / 21 host
  checks, 2.7 M cycles) — ControlCore, host bridge, both die DMA channels, four vector tiles, two tensor units, four
  shared-SRAM slices, four scratchpads, die registers and the external-memory bridge all through the spine with the
  placement-evidence link stages. V2 and MINEXT (spine, one stage per link): 5 / 6 pass; the one failure is P31's
  held-request **coverage** point, which P31 already waives for its other buffering fabric (details and extra seeds:
  [reports/p31_integration.md](reports/p31_integration.md)). 3,675 P31 checks, **0 functional check failures, 0 spine
  assertion messages**.
* **Contention, measured.** 47 / 47 fully checked benchmark runs ([reports/bench.md](reports/bench.md),
  [docs/PERFORMANCE.md](docs/PERFORMANCE.md)): tensor operand loads, vector scratchpad traffic, DMA output writes and
  ControlCore MMIO together — cycles per transaction by class, throughput, buffer occupancy, stall cycles, link
  utilisation and arbitration delays, every counter cross-checked against the testbench.

| Check | Result | Report |
|---|---|---|
| Spine testbench: HPC floorplan (single / evidence / deep pipelining, BUF 1, RR, master QoS, P22 central stage, P31 limits) + 8 synthetic configurations (0–15 stages, 64-bit data, 48-bit address, 3-bit IDs, SFB2 targets, sparse access) | **349 / 349** as expected, **7.05 M transactions** checked | [regression](reports/regression.md) |
| P22's testbench **unmodified** on the spine (P22's crossbar test matrix verbatim; 0 and 2 link stages) | **420 / 420**, 3.95 M transactions | [regression](reports/regression.md) |
| Cycle identity with P22's crossbar (0 stages, P22 testbench, same seeds, `sfs_xbar` and `sfn_xbar` central stage) | **24 / 24 byte-identical traces** (391 k transactions) | [regression](reports/regression.md) |
| P31 die regression with the spine (HPC firmware + host tests, V2, MINEXT) | **9 / 10** (HPC 4 / 4); the miss is a coverage point, 0 functional failures | [p31_integration](reports/p31_integration.md) |
| Formal | **27 / 27 jobs as expected**: **16 unbounded proofs** (link pipeline ×6, traffic-class map ×3, QoS arbiter ≡ P22 ×4, central stage ≡ P22 crossbar ×2, 2 × 2 spine without link stages incl. bounded liveness); 2 × 2 spines **with** link stages ×3 **bounded only** (13–16 cycles); **8 / 8 mutants caught** | [formal](reports/formal.md) |
| Lint / elaboration: Verilator `-Wall`, Icarus, Yosys | **9 / 9** legal sets with **0 warnings**; **12 / 12** illegal sets refused | [lint](reports/lint.md) |
| Synthesis (Yosys 0.33; generic + sky130 HD with ABC timing, no wires) | 21 designs, 0 latches | [synth](reports/synth.md) |
| Benchmark | **47 / 47** runs passed their checks | [bench](reports/bench.md) |

Headline numbers (cycles measured; ns / MHz = synthesis-level estimates, [reports/placement.md](reports/placement.md)):

| | Value |
|---|---|
| Single central stage, no link registers: worst path HOST → EXTCSR 36.3 mm | **13.1 ns (76 MHz)** estimated |
| Central stage with P22's QoS arbiter / with the proved-equivalent `sfs_qos_arbiter` (ABC, sky130, no wires) | 10.5 ns / **3.4 ns** |
| Evidence pipelining (HOST, DMA0, DMA1 2 stages; all other links 1) | **5.1 ns (196 MHz)** estimated; 48 link stages |
| Die workload, full load: single stage vs evidence | 4.11 vs **6.17 B/cycle**; 5.1 vs 11.9 cycles mean latency; **0.31 vs 1.21 GB/s**, 67 vs 61 ns |
| Same pipelining with P31's outstanding limits | 2.41 B/cycle — limits must be sized to the round trip |
| Worst central-stage wait of control traffic: classes vs round robin | **4** vs 23 cycles; fairness bound STARVE + NM − 1 = 17 held in every run |
| Spine vs P22 4×3 mesh (registered multistage) on the die workload | 5.73 vs 4.92 B/cycle, 13.4 vs 23.0 cycles; 38 k vs 123 k NAND2-eq |
| Spine logic (HPC, evidence, no counters) | 38.4 k NAND2-eq, 6.9 k flops, 342 k µm² sky130 cells; 3.7 ns ABC logic delay |

**Architecture decision:** a **segmented crossbar** — one central routing stage (P22's crossbar) at the middle of
the spine, point-to-point links with register stages only where the wire needs them — is the smallest solution that
meets the requirements; P22's registered 2-D mesh, mapped onto the same floorplan, needs 3.2× the logic and delivers
less bandwidth ([docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) §2, [docs/PHYSICAL.md](docs/PHYSICAL.md)).

Problems found and fixed on the way (all by the flow, none left open): P22's QoS arbiter was the critical path
(restructured, proved equivalent); the new SPINE_PERF class statistics were a 12.5 ns path (registered, now 2.7 ns);
P22's fault-injection and fairness measurement assumed a combinational crossbar (adapted in the derived testbench,
documented); a scoreboard reset-release race in Verilator (fixed in the derived testbench).

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit; reuse verified routers, crossbars, adapters; no incompatible second interconnect | [docs/AUDIT.md](docs/AUDIT.md): P22 `sfn_mst_port`, `sfn_xbar`, `sfn_fifo`, `sfn_perf`, DataFabric arbiter/decoder, SFB2 bridges reused unmodified (SHA-256 manifest); the one restructured block (`sfs_qos_arbiter`) is **proved equivalent** to P22's |
| 2 | Spine with attachment nodes for ControlCore, vector, tensor, SRAM regions, shared memory, DMA, external memory, host I/O; segmented crossbar vs registered multistage NoC; smallest sufficient | [docs/PHYSICAL.md](docs/PHYSICAL.md) §1–2, [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) §2; both built, simulated, synthesized ([reports/synth.md](reports/synth.md), [reports/bench.md](reports/bench.md) E4) |
| 3 | `silicaflux_noc_spine.sv`, parameterised ports, data / address / ID width, buffer depth, pipeline stages | `rtl/spine/silicaflux_noc_spine.sv` (`NM NT AW DW IDW BUF_DEPTH MST_PIPE TGT_PIPE …`), [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) §5 |
| 4 | Read/write, routing, payloads, tagging, ownership, errors, ordering, backpressure; nothing lost during stalls | [docs/PROTOCOL.md](docs/PROTOCOL.md) |
| 5 | Registered boundaries where needed; latency / length / registers / buffers / clock balanced; ready/valid correct | [docs/PHYSICAL.md](docs/PHYSICAL.md) §3–5, `rtl/spine/sfs_link.sv` (formal K1–K5), [reports/placement.md](reports/placement.md) |
| 6 | Control, read, write, completion/error classes; fairness guarantee; control cannot block memory indefinitely | [docs/PROTOCOL.md](docs/PROTOCOL.md) §6, `sfs_tc_map.sv`, `sfs_qos_arbiter.sv`; bound STARVE + NM − 1 checked in every run; [reports/bench.md](reports/bench.md) E3, E6 |
| 7 | Vector / tensor access patterns; tensor loads + vector scratchpad + DMA writes + ControlCore MMIO together; bottlenecks | `tb/sfs_tb_master.sv` profiles, [reports/bench.md](reports/bench.md) E5 |
| 8 | Connectivity graph; region coordinates from the floorplan; inter-block distances | `config/silicaflux_floorplan.yaml`, [reports/connectivity.md](reports/connectivity.md), `reports/connectivity.{json,dot}`, `reports/img/connectivity.png` |
| 9 | Assertions | `rtl/spine/sfs_spine_assert.sv`, [docs/VERIFICATION.md](docs/VERIFICATION.md) §1, `formal/` |
| 10 | Deterministic and random tests: low load, saturation, hotspot, mixed R/W, many masters, long bursts, errors, reset, backpressure | [docs/VERIFICATION.md](docs/VERIFICATION.md) §2, [reports/regression.md](reports/regression.md) |
| 11 | Cycles per transaction, throughput, occupancy, stalls, link utilisation, arbitration delays; physical timing only if tools ran | [reports/bench.md](reports/bench.md), [docs/PERFORMANCE.md](docs/PERFORMANCE.md); every number from simulation, counters cross-checked; no physical timing claimed |
| 12 | Deliverables | below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_noc_spine.sv` | `rtl/spine/silicaflux_noc_spine.sv` |
| Attachment nodes, links, central stage | `rtl/spine/sfs_mnode.sv`, `sfs_tnode.sv`, `sfs_link.sv`, `sfs_xbar.sv`, `sfs_qos_arbiter.sv`, `sfs_tc_map.sv`, `sfs_perf.sv`, `sfs_spine_assert.sv` |
| Interconnect adapters | SFB2 ↔ SFB3 bridges (P22, `third_party/.../sfn_sfb2_{mst,tgt}_bridge.sv`); the P31 die drop-in `integration/p31/datafabric.sv`; P22-name compatibility shim `tb/compat/silicaflux_noc_spine_shim.sv` |
| Routing / configuration package | `rtl/spine/sfs_pkg.sv`, generated `rtl/cfg/sfs_cfg_pkg.sv` from `config/silicaflux_floorplan.yaml` (`scripts/gen_cfg.py`), configured top `rtl/cfg/silicaflux_noc_spine_hpc.sv` |
| Verification suite | `tb/tb_spine.sv`, `tb/sfs_tb_target.sv`, `tb/compat/`, `formal/*.sv` + `formal/run_formal.py`, `scripts/regress.py`, `scripts/lint.py`, `scripts/p31_integration.py` |
| Traffic generator | `tb/sfs_tb_master.sv` (P22 modes + die-workload profiles: tensor_load, vec_spm, dma_write, cc_mmio, host) |
| Connectivity graph | `reports/connectivity.{md,json,dot}`, `reports/img/connectivity.png` |
| Placement-aware analysis | `scripts/placement.py` → `reports/placement.{md,json}`; [docs/PHYSICAL.md](docs/PHYSICAL.md) |
| Synthesis and timing reports | `scripts/synth.py` → `reports/synth.{md,json}`, `build/synth/*/sky130/critical_path.txt` (regenerated) |
| Performance reports | `scripts/bench.py` → `reports/bench.{md,json}`, `reports/img/bench_*.png`; [docs/PERFORMANCE.md](docs/PERFORMANCE.md) |
| Documentation | `docs/AUDIT.md`, `ARCHITECTURE.md`, `PROTOCOL.md`, `PHYSICAL.md`, `VERIFICATION.md`, `PERFORMANCE.md`, `LIMITATIONS.md`; `reports/SUMMARY.md` |
| Reused sources | `third_party/silicaflux-datafabric-noc/` (byte-identical subset of the P22 archive, `SHA256SUMS`) |

## Quick start

Ubuntu 24.04 packages: Verilator 5.020, Icarus 12, Yosys 0.33; `pip install z3-solver pyyaml matplotlib`; the sky130
HD liberty at `SKY130_LIB` (default `/opt/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib`, from OpenROAD-flow-scripts
`flow/platforms/sky130hd/lib/`).

```bash
make config
```

```bash
make quick
```

```bash
make regress
```

```bash
make formal
```

```bash
make bench
```

```bash
make all
```

`make help` lists every target. One configuration by hand (HPC floorplan, evidence pipelining, die workload):

```bash
mkdir -p build
```

```bash
verilator --binary --timing --timescale 1ns/1ps -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Itb -Ithird_party/silicaflux-datafabric-noc/tb -f files_sim.f -f files_tb.f --top-module tb_spine -GCFG=1 -GNM=10 -GNT=11 -GMAXO=8 -GPIPE_SEL=1 -GMAXO_SEL=1 --Mdir build/one -o sim
```

```bash
build/one/sim +seed=1 +amode=6 +n=3000
```

## Layout

```
config/          silicaflux_floorplan.yaml (regions, coordinates, ports, address map, access matrix, timing model)
rtl/spine/       the spine (new RTL)          rtl/cfg/  generated configuration package, configured tops
integration/p31/ drop-in datafabric.sv for the P31 die (+ the P31 original for comparison)
tb/              tb_spine, traffic generator, target model, compat shim
formal/          harnesses + runner
scripts/         gen_cfg, synth, placement, lint, regress, bench, p31_integration, report
docs/            architecture, protocol, physical, verification, performance, audit, limitations
reports/         every number quoted anywhere (JSON + Markdown; SUMMARY.md)
third_party/     P22 DataFabric-NoC subset (unmodified, SHA256SUMS)
```
