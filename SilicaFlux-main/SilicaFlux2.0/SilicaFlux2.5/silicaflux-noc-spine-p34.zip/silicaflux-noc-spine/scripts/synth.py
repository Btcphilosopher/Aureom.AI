#!/usr/bin/env python3
"""SilicaFlux NoC Spine -- synthesis and synthesis-level timing.

Two Yosys 0.33 flows per design (results merged into reports/synth.json, summary in reports/synth.md):

  generic   the P22 / DataFabric method, for comparability with earlier SilicaFlux reports:
            synth -flatten; techmap; abc -g cmos2; stat -tech cmos (NAND2-eq = transistors / 4);
            ltp -noff (longest topological path in gates: a logic-depth PROXY)
  sky130    SkyWater sky130_fd_sc_hd, TT corner 1.80 V 25 C liberty (OpenROAD-flow-scripts copy):
            synth -flatten; dfflibmap; abc -liberty with  strash; dch; map -D 2000; buffer -p;
            upsize; dnsize; stime -p   -> standard-cell area (um^2), cell / flop counts and
            ABC's static timing of the mapped combinational logic: the longest
            register/port-to-register/port path in ps with liberty cell delays and fan-out loads.
            NOT included: wires, placement, clock tree, flop clk->Q / setup (added from the liberty
            by scripts/placement.py), parasitic extraction.  This is synthesis-level evidence,
            not sign-off timing; no physical tool (place & route, STA with parasitics) was run.

usage: synth.py [components|spine|refs|all|<job> ...]
"""
import json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "build", "synth")
REP = os.path.join(ROOT, "reports")
LIB = os.environ.get("SKY130_LIB", "/opt/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib")
TP = "third_party/silicaflux-datafabric-noc"

def rtl_files():
    fl = [l.strip() for l in open(os.path.join(ROOT, "files_rtl.f")) if l.strip()]
    return [os.path.join(ROOT, f) for f in fl]

CFG_FILES = ["rtl/cfg/sfs_cfg_pkg.sv"]
REF_FILES = [f"{TP}/rtl/noc/{f}" for f in ("sfn_sbus.sv", "sfn_router.sv", "sfn_ni.sv", "sfn_mesh.sv", "silicaflux_noc.sv")]

def hpc_literals():
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    import gen_cfg
    c = gen_cfg.load()
    ts, ms = c["targets"], c["masters"]
    aw = c["fabric"]["aw"]
    base = gen_cfg.sv_vec([t["base"] for t in ts], aw)
    mask = gen_cfg.sv_vec([((1 << aw) - 1) & ~(t["size"] - 1) for t in ts], aw)
    en_host = "".join("1" for _ in ts)
    en = "".join(str(1 if t["cls"] in c["access"][m["cls"]] else 0) for m in reversed(ms) for t in reversed(ts))
    mmio = "".join(str(t["mmio"]) for t in reversed(ts))
    return dict(base=base, mask=mask, en_host=f"{len(ts)}'b{en_host}", en=f"{len(ms) * len(ts)}'b{en}",
                mmio=f"{len(ts)}'b{mmio}", nm=len(ms), nt=len(ts))

def jobs():
    L = hpc_literals()
    nm, nt = L["nm"], L["nt"]
    qpw = 2 + 4 + 3 + 2 + 3 + 32 + 32 + 4
    J = {}
    # ---- components (timing model inputs)
    J["c_mst_port"] = ("sfn_mst_port (P22), NT 11, IDW 2, MAXO 8, HPC windows", "sfn_mst_port",
                       dict(NT=nt, IDW=2, MAXO_MAX=8, MAXO=8, TGT_BASE=L["base"], TGT_MASK=L["mask"], EN=L["en_host"]), [])
    J["c_tc_map"] = ("sfs_tc_map, NT 11, HPC windows", "sfs_tc_map",
                     dict(NT=nt, TGT_BASE=L["base"], TGT_MASK=L["mask"], EN=L["en_host"], TGT_MMIO=L["mmio"]), [])
    J["c_mnode_p1"] = ("sfs_mnode, 1 stage per direction (node logic + link)", "sfs_mnode",
                       dict(NT=nt, IDW=2, MAXO_MAX=8, MAXO=8, TGT_BASE=L["base"], TGT_MASK=L["mask"], EN=L["en_host"],
                            TGT_MMIO=L["mmio"], PIPE=1), [])
    J["c_link_stage"] = (f"one link register stage: sfn_fifo W {qpw} DEPTH 2", "sfn_fifo", dict(W=qpw, DEPTH=2), [])
    J["c_link_stage_d1"] = (f"one link register stage: sfn_fifo W {qpw} DEPTH 1", "sfn_fifo", dict(W=qpw, DEPTH=1), [])
    J["c_link_stage_d4"] = (f"one link register stage: sfn_fifo W {qpw} DEPTH 4", "sfn_fifo", dict(W=qpw, DEPTH=4), [])
    J["c_xbar_qos"] = ("central routing stage: sfn_xbar 10x11, QoS arbitration (default)", "sfn_xbar",
                       dict(NM=nm, NT=nt, ARB_MODE=2, MST_TGT_EN=L["en"]), [])
    J["c_xbar_qos_fast"] = ("central routing stage: sfs_xbar 10x11, QoS, parallel-level arbiter (spine default)", "sfs_xbar",
                            dict(NM=nm, NT=nt, ARB_MODE=2, MST_TGT_EN=L["en"]), [])
    J["c_qos_arb_p22"] = ("sfn_qos_arbiter (P22), N 10, STARVE 8", "sfn_qos_arbiter", dict(N=nm, STARVE=8), [])
    J["c_qos_arb_fast"] = ("sfs_qos_arbiter (parallel levels), N 10, STARVE 8", "sfs_qos_arbiter", dict(N=nm, STARVE=8), [])
    J["c_xbar_rr"] = ("central routing stage: sfn_xbar 10x11, round robin", "sfn_xbar",
                      dict(NM=nm, NT=nt, ARB_MODE=1, MST_TGT_EN=L["en"]), [])
    J["c_spine_perf"] = ("sfs_perf counter page (SPINE_PERF), 10x11", "sfs_perf", dict(NM=nm, NT=nt, OCCW=8), [])
    J["c_noc_perf"] = ("sfn_perf counter page (P22 NOC_PERF), 10x11", "sfn_perf", dict(NM=nm, NT=nt, MAXO_MAX=8), [])
    # ---- full spine (HPC configuration)
    for sel, nm_ in ((0, "single"), (1, "evidence"), (2, "deep")):
        J[f"spine_{nm_}"] = (f"silicaflux_noc_spine HPC, {nm_} link pipelining, QoS+classes, no counters",
                             "silicaflux_noc_spine_hpc", dict(PIPE_SEL=sel, PERF=0), CFG_FILES + ["rtl/cfg/silicaflux_noc_spine_hpc.sv"])
    J["spine_evidence_rr"] = ("silicaflux_noc_spine HPC, evidence pipelining, round robin, no counters",
                              "silicaflux_noc_spine_hpc", dict(PIPE_SEL=1, PERF=0, ARB_MODE=1),
                              CFG_FILES + ["rtl/cfg/silicaflux_noc_spine_hpc.sv"])
    J["spine_evidence_buf1"] = ("silicaflux_noc_spine HPC, evidence pipelining, BUF_DEPTH 1, no counters",
                                "silicaflux_noc_spine_hpc", dict(PIPE_SEL=1, PERF=0, BUF_DEPTH=1),
                                CFG_FILES + ["rtl/cfg/silicaflux_noc_spine_hpc.sv"])
    J["spine_evidence_perf"] = ("silicaflux_noc_spine HPC, evidence pipelining, both counter pages",
                                "silicaflux_noc_spine_hpc", dict(PIPE_SEL=1, PERF=1), CFG_FILES + ["rtl/cfg/silicaflux_noc_spine_hpc.sv"])
    # ---- references (same configuration)
    J["ref_p22_xbar"] = ("P22 silicaflux_noc crossbar (= P31 HPC fabric), same HPC configuration, no counters",
                         "sfs_ref_noc_hpc", dict(TOPOLOGY=1), CFG_FILES + REF_FILES + ["rtl/cfg/sfs_ref_noc_hpc.sv"])
    J["ref_p22_mesh4x3"] = ("P22 silicaflux_noc 4x3 mesh (registered multistage), same HPC configuration",
                            "sfs_ref_noc_hpc", dict(TOPOLOGY=2), CFG_FILES + REF_FILES + ["rtl/cfg/sfs_ref_noc_hpc.sv"])
    return J

GROUPS = {
    "components": ["c_mst_port", "c_tc_map", "c_mnode_p1", "c_link_stage", "c_link_stage_d1", "c_link_stage_d4",
                   "c_xbar_qos", "c_xbar_qos_fast", "c_xbar_rr", "c_qos_arb_p22", "c_qos_arb_fast", "c_spine_perf", "c_noc_perf"],
    "spine": ["spine_single", "spine_evidence", "spine_deep", "spine_evidence_rr", "spine_evidence_buf1",
              "spine_evidence_perf"],
    "refs": ["ref_p22_xbar", "ref_p22_mesh4x3"],
}

ABC_SCR = "strash\ndch\nmap -D 2000\ntopo\nbuffer -p\ntopo\nupsize\ntopo\ndnsize\ntopo\nstime -p\n"

def run(name, flow, J):
    desc, top, params, extra = J[name]
    d = os.path.join(OUT, name, flow)
    os.makedirs(d, exist_ok=True)
    files = rtl_files() + [os.path.join(ROOT, f) for f in extra]
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    pre = f"read_verilog -sv -DSYNTHESIS {' '.join(files)}; {ch}hierarchy -check -top {top}; "
    if flow == "generic":
        script = (pre + f"synth -flatten -top {top}; techmap; opt -fast; abc -g cmos2; opt_clean; "
                  f"tee -o {d}/stat.txt stat -tech cmos; tee -o {d}/ltp.txt ltp -noff")
    else:
        open(os.path.join(d, "abc.scr"), "w").write(ABC_SCR)
        script = (f"read_liberty -lib {LIB}; " + pre + f"synth -flatten -top {top}; dfflibmap -liberty {LIB}; "
                  f"abc -liberty {LIB} -script {d}/abc.scr; opt_clean; check -assert; "
                  f"tee -o {d}/stat.txt stat -liberty {LIB}")
    r = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys.log"), "-p", script], capture_output=True, text=True,
                       timeout=7200)
    if r.returncode:
        return dict(ok=False, detail=(r.stderr or r.stdout)[-600:])
    st = open(os.path.join(d, "stat.txt")).read()
    num = lambda pat, txt: (lambda m: m.group(1) if m else None)(re.search(pat, txt))
    res = dict(ok=True)
    if flow == "generic":
        tr = num(r"Estimated number of transistors:\s+(\d+)", st)
        lt = open(os.path.join(d, "ltp.txt")).read()
        res.update(cells=int(num(r"Number of cells:\s+(\d+)", st) or 0),
                   flops=sum(int(n) for n in re.findall(r"\$_\w*DFF\w*\s+(\d+)", st)),
                   latches=sum(int(n) for n in re.findall(r"\$_\w*(?:DLATCH|SR)\w*\s+(\d+)", st)),
                   nand2_eq=round(int(tr) / 4) if tr else None,
                   logic_depth=int(num(r"Longest topological path in \S+ \(length=(\d+)\)", lt) or 0))
    else:
        log = open(os.path.join(d, "yosys.log")).read()
        dl = re.findall(r"Delay =\s+([\d.]+) ps", log)
        res.update(cells=int(num(r"Number of cells:\s+(\d+)", st) or 0),
                   flops=sum(int(n) for n in re.findall(r"sky130_fd_sc_hd__\w*df\w*\s+(\d+)", st)),
                   area_um2=float(num(r"Chip area for module '\S+':\s+([\d.]+)", st) or 0),
                   abc_delay_ps=float(dl[-1]) if dl else None)
        # keep ABC's critical-path printout (stime -p) for the record
        m = re.findall(r"ABC: Critical path:.*?(?=ABC: \+|\Z)", log, re.S)
        if m:
            open(os.path.join(d, "critical_path.txt"), "w").write(m[-1])
    return res

def main():
    J = jobs()
    sel = []
    for a in (sys.argv[1:] or ["all"]):
        if a == "all":
            sel += [j for g in GROUPS.values() for j in g]
        elif a in GROUPS:
            sel += GROUPS[a]
        elif a in J:
            sel.append(a)
        else:
            sys.exit(f"unknown job/group {a}")
    path = os.path.join(REP, "synth.json")
    data = json.load(open(path)) if os.path.exists(path) else {}
    tasks = [(n, f) for n in sel for f in ("generic", "sky130")]
    with ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        res = list(ex.map(lambda nf: (nf, run(nf[0], nf[1], J)), tasks))
    for (n, f), r in res:
        data.setdefault(n, dict(description=J[n][0], top=J[n][1],
                                params={k: v for k, v in J[n][2].items() if not str(v).startswith(("352'", "110'", "11'"))}))
        data[n][f] = r
        print(f"{n:22s} {f:8s} " + (" ".join(f"{k}={v}" for k, v in r.items() if k != "ok") if r["ok"] else "FAILED " + r["detail"]))
    data["_meta"] = dict(yosys=subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip(),
                         liberty=os.path.basename(LIB),
                         note="generic: P22 method (cmos2, NAND2-eq = transistors/4, ltp = logic depth proxy); "
                              "sky130: ABC stime of mapped logic, no wires / placement / clk-to-q / setup")
    json.dump(data, open(path, "w"), indent=1)
    write_md(data)

def write_md(data):
    L = ["# Synthesis report (generated by scripts/synth.py)", "",
         f"Tools: {data['_meta']['yosys']}; liberty `{data['_meta']['liberty']}` (SkyWater sky130_fd_sc_hd, TT 1.80 V 25 C).", "",
         "* **generic** = P22 method for comparability: `abc -g cmos2`, NAND2-eq = transistors / 4, depth = `ltp -noff` (gates).",
         "* **sky130** = mapped to sky130 HD cells; area = sum of cell areas (no placement utilisation, no routing); "
         "**ABC delay** = ABC `stime -p` static timing of the mapped combinational logic: longest path between "
         "registers / ports with liberty cell delays and fan-out loads. **No wire delay, no placement, no clk->Q/setup, "
         "no parasitics: this is synthesis-level evidence, not sign-off timing.** No physical design tool was run.", "",
         "| Design | NAND2-eq | depth (gates) | flops | sky130 cells | sky130 area (um^2) | ABC delay (ps) | Description |",
         "|---|---|---|---|---|---|---|---|"]
    order = [j for g in GROUPS.values() for j in g]
    for n in order + sorted(k for k in data if k not in order and not k.startswith("_")):
        if n not in data:
            continue
        g, s = data[n].get("generic", {}), data[n].get("sky130", {})
        L.append(f"| {n} | {g.get('nand2_eq', '-')} | {g.get('logic_depth', '-')} | {s.get('flops', g.get('flops', '-'))} | "
                 f"{s.get('cells', '-')} | {s.get('area_um2', '-')} | {s.get('abc_delay_ps', '-')} | {data[n]['description']} |")
    lat = [n for n in data if not n.startswith("_") and data[n].get("generic", {}).get("latches")]
    L += ["", f"Latches: {'none in any design' if not lat else ', '.join(lat)} (generic flow `stat`); "
          "every sky130 netlist passed `check -assert`.", ""]
    open(os.path.join(REP, "synth.md"), "w").write("\n".join(L))

if __name__ == "__main__":
    main()
