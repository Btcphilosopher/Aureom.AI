#!/usr/bin/env python3
"""SilicaFlux NoC Spine -- lint and elaboration in three tools.

Legal parameter sets: Verilator 5.020 --lint-only -Wall on the synthesizable RTL (SYNTHESIS defined,
0 warnings required), Verilator -Wall on the simulation build (assertion module included, 0 warnings
required), Icarus 12 elaboration, Yosys 0.33 elaboration + `proc; check -assert` (no latches).
Illegal parameter sets: elaboration must stop with $fatal (Verilator and Icarus).
Writes reports/lint.{json,md}.
"""
import json, os, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "build", "lint")


def files(f):
    out = []
    for l in open(os.path.join(ROOT, f)):
        l = l.strip()
        if l.startswith("-f"):
            out += files(l.split()[1])
        elif l:
            out.append(os.path.join(ROOT, l))
    return out


RTL = files("files_rtl.f")
SIM = files("files_sim.f")
CFGF = [os.path.join(ROOT, "rtl/cfg/sfs_cfg_pkg.sv"), os.path.join(ROOT, "rtl/cfg/silicaflux_noc_spine_hpc.sv")]

LEGAL = {
    "default_4x4":     ("silicaflux_noc_spine", dict(NM=4, NT=4, TGT_BASE="128'h10300000102000001010000010000000",
                                                     TGT_MASK="128'hfff00000fff00000fff00000fff00000")),
    "mixed_pipes":     ("silicaflux_noc_spine", dict(NM=3, NT=2, MST_PIPE="12'h0f3", TGT_PIPE="8'h21", BUF_DEPTH=3,
                                                     TGT_BASE="64'h1010000010000000", TGT_MASK="64'hfff00000fff00000")),
    "wide_d256_a64_id8": ("silicaflux_noc_spine", dict(NM=2, NT=2, DW=256, AW=64, IDW=8, MAXO_MAX=8, MST_MAXO="16'h0808",
                                                       MST_PIPE="8'h12", TGT_PIPE="8'h21",
                                                       TGT_BASE="128'h00000000101000000000000010000000",
                                                       TGT_MASK="128'hfffffffffff00000fffffffffff00000")),
    "single_port":     ("silicaflux_noc_spine", dict(NM=1, NT=1, MST_PIPE="4'h2", TGT_PIPE="4'h0", MST_MAXO="8'h04",
                                                     TGT_BASE="32'h10000000", TGT_MASK="32'hf0000000")),
    "rr_buf16_p15":    ("silicaflux_noc_spine", dict(NM=2, NT=2, ARB_MODE=1, BUF_DEPTH=16, MST_PIPE="8'hff", TGT_PIPE="8'hf1",
                                                     TGT_BASE="64'h1010000010000000", TGT_MASK="64'hfff00000fff00000")),
    "p22_central_noperf": ("silicaflux_noc_spine", dict(NM=3, NT=3, CENTRAL=0, PERF=0, TC_MODE=0,
                                                        TGT_BASE="96'h102000001010000010000000",
                                                        TGT_MASK="96'hfff00000fff00000fff00000")),
    "hpc_evidence":    ("silicaflux_noc_spine_hpc", dict(PIPE_SEL=1)),
    "hpc_single":      ("silicaflux_noc_spine_hpc", dict(PIPE_SEL=0, MAXO_SEL=0)),
    "hpc_deep":        ("silicaflux_noc_spine_hpc", dict(PIPE_SEL=2)),
}
BASE2 = dict(NM=2, NT=2, TGT_BASE="64'h1010000010000000", TGT_MASK="64'hfff00000fff00000")
ILLEGAL = {
    "overlap":      dict(BASE2, TGT_BASE="64'h1000000010000000"),
    "base_outside": dict(BASE2, TGT_BASE="64'h1010000110000000"),
    "buf0":         dict(BASE2, BUF_DEPTH=0),
    "buf17":        dict(BASE2, BUF_DEPTH=17),
    "maxo0":        dict(BASE2, MST_MAXO="16'h0400"),
    "maxo_over":    dict(BASE2, MST_MAXO="16'h0904"),
    "dw48":         dict(BASE2, DW=48),
    "aw7":          dict(BASE2, AW=7),
    "idw9":         dict(BASE2, IDW=9),
    "tc_mode2":     dict(BASE2, TC_MODE=2),
    "arb3":         dict(BASE2, ARB_MODE=3),
    "nm33":         dict(NM=33, NT=1, TGT_BASE="32'h10000000", TGT_MASK="32'hf0000000"),
}


def sh(cmd, log, timeout=1800):
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT, timeout=timeout)
    open(log, "w").write(" ".join(cmd) + "\n\n" + r.stdout + r.stderr)
    return r.returncode, r.stdout + r.stderr


def legal(name):
    top, p = LEGAL[name]
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    extra = CFGF if top.endswith("_hpc") else []
    g = [f"-G{k}={v}" for k, v in p.items()]
    res = dict(config=name, top=top, params=p)
    rc, out = sh(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-DSYNTHESIS"] + RTL + extra +
                 ["--top-module", top] + g, os.path.join(d, "verilator_syn.log"))
    res["verilator_rtl"] = dict(rc=rc, warnings=out.count("%Warning"))
    rc, out = sh(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME"] + SIM + extra + ["--top-module", top] + g,
                 os.path.join(d, "verilator_sim.log"))
    res["verilator_sim"] = dict(rc=rc, warnings=out.count("%Warning"))
    ig = [f"-P{top}.{k}={v}" for k, v in p.items()]
    rc, out = sh(["iverilog", "-g2012", "-o", os.path.join(d, "a.vvp"), "-s", top] + ig + SIM + extra,
                 os.path.join(d, "icarus.log"))
    res["icarus"] = dict(rc=rc)
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in p.items())
    rc, out = sh(["yosys", "-q", "-p", f"read_verilog -sv -DSYNTHESIS {' '.join(RTL + extra)}; {ch}hierarchy -check -top {top}; "
                  f"proc; opt_clean; check -assert; select -assert-none t:$dlatch t:$sr"], os.path.join(d, "yosys.log"))
    res["yosys"] = dict(rc=rc)
    res["ok"] = (res["verilator_rtl"]["rc"] == 0 and res["verilator_rtl"]["warnings"] == 0 and
                 res["verilator_sim"]["rc"] == 0 and res["verilator_sim"]["warnings"] == 0 and
                 res["icarus"]["rc"] == 0 and res["yosys"]["rc"] == 0)
    return res


def illegal(name):
    p = ILLEGAL[name]
    d = os.path.join(OUT, "illegal_" + name); os.makedirs(d, exist_ok=True)
    top = "silicaflux_noc_spine"
    # Verilator: --binary elaboration executes the initial-block checks at time 0
    g = [f"-G{k}={v}" for k, v in p.items()]
    rc, out = sh(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN"] + SIM +
                 ["--top-module", top, "--Mdir", os.path.join(d, "vl"), "-o", "sim"] + g, os.path.join(d, "verilator_build.log"))
    v_ref = rc != 0
    if rc == 0:
        rc2, out2 = sh([os.path.join(d, "vl", "sim")], os.path.join(d, "verilator_run.log"), timeout=120)
        v_ref = rc2 != 0 and ("fatal" in out2.lower() or "%Error" in out2)
    ig = [f"-P{top}.{k}={v}" for k, v in p.items()]
    rc, out = sh(["iverilog", "-g2012", "-o", os.path.join(d, "a.vvp"), "-s", top] + ig + SIM, os.path.join(d, "icarus.log"))
    i_ref = rc != 0
    if rc == 0:
        rc2, out2 = sh(["vvp", "-n", os.path.join(d, "a.vvp")], os.path.join(d, "icarus_run.log"), timeout=120)
        i_ref = rc2 != 0 or "FATAL" in out2.upper()
    return dict(config=name, params=p, verilator_refused=v_ref, icarus_refused=i_ref, ok=v_ref and i_ref)


def main():
    with ThreadPoolExecutor(max_workers=int(os.environ.get("JOBS", "4"))) as ex:
        L = list(ex.map(legal, LEGAL))
        I = list(ex.map(illegal, ILLEGAL))
    vv = lambda c: subprocess.run(c, capture_output=True, text=True).stdout.strip().splitlines()[0]
    tools = dict(verilator=vv(["verilator", "--version"]), icarus=subprocess.run(["iverilog", "-V"], capture_output=True,
                 text=True).stdout.splitlines()[0], yosys=vv(["yosys", "-V"]))
    json.dump(dict(tools=tools, legal=L, illegal=I), open(os.path.join(ROOT, "reports", "lint.json"), "w"), indent=1)
    M = ["# Lint and elaboration (generated by scripts/lint.py)", "", f"Tools: {tools['verilator']}; {tools['icarus']}; {tools['yosys']}.", "",
         f"**Legal parameter sets: {sum(r['ok'] for r in L)} / {len(L)} clean** (Verilator `-Wall` 0 warnings on the "
         "synthesizable RTL and on the simulation build with assertions, Icarus elaborates, Yosys `check -assert`, no latch).", "",
         "| Configuration | Top | Verilator RTL (rc / warnings) | Verilator sim (rc / warnings) | Icarus | Yosys | OK |", "|---|---|---|---|---|---|---|"]
    for r in L:
        M.append(f"| {r['config']} | {r['top']} | {r['verilator_rtl']['rc']} / {r['verilator_rtl']['warnings']} | "
                 f"{r['verilator_sim']['rc']} / {r['verilator_sim']['warnings']} | {r['icarus']['rc']} | {r['yosys']['rc']} | {'yes' if r['ok'] else '**no**'} |")
    M += ["", f"**Illegal parameter sets refused: {sum(r['ok'] for r in I)} / {len(I)}** (both simulators).", "",
          "| Illegal set | Parameters | Verilator refuses | Icarus refuses |", "|---|---|---|---|"]
    for r in I:
        M.append(f"| {r['config']} | `{json.dumps(r['params'])}` | {r['verilator_refused']} | {r['icarus_refused']} |")
    open(os.path.join(ROOT, "reports", "lint.md"), "w").write("\n".join(M) + "\n")
    print(f"legal {sum(r['ok'] for r in L)}/{len(L)}, illegal refused {sum(r['ok'] for r in I)}/{len(I)}")
    for r in L + I:
        if not r["ok"]:
            print("  NOT OK", r["config"])
    sys.exit(0 if all(r["ok"] for r in L + I) else 1)


if __name__ == "__main__":
    main()
