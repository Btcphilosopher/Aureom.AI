#!/usr/bin/env python3
"""SilicaFlux NoC Spine -- regression runner (Verilator 5.020).

usage: regress.py [spine|compat|identity|all] [--quick]

  spine     tb/tb_spine.sv (derived from P22 tb_noc) on the HPC floorplan configuration (CFG 1:
            single / evidence / deep pipelining, BUF_DEPTH 1, round robin, TC_MODE 0, P22 sfn_xbar
            central stage, P31 outstanding limits) and on synthetic configurations (CFG 0: mixed
            0..15 stages, wide data / address, SFB2 targets, 8 masters x 8 targets ...).
            Every run: end-to-end scoreboard, protocol checkers, in-RTL assertions (link shadow
            FIFOs etc.), fairness bound at the central stage, every NOC_PERF and SPINE_PERF counter.
  compat    P22's tb/tb_noc.sv, UNMODIFIED, against the spine through tb/compat/silicaflux_noc_spine_shim.sv
            (P22's crossbar configurations and test list; 0 and 2 link stages)
  identity  same seeds on P22's own silicaflux_noc crossbar and on the spine (0 stages): the
            per-transaction traces must be byte-identical (cycle-for-cycle equivalence)
Writes reports/regression.{json,md}.  Exit 1 if any run is not as expected.
"""
import filecmp, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
B = os.path.join(ROOT, "build", "sim")
TP = "third_party/silicaflux-datafabric-noc"
JOBS = int(os.environ.get("JOBS", "4"))
VFLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN",
          "-O3", "--x-assign", "fast", "-j", "2"]

HPC = dict(DUT=0, CFG=1, NM=10, NT=11, MAXO=8)
CONFIGS = {
    # ---- SilicaFlux HPC floorplan configuration (P31 port set)
    "hpc_single":      dict(HPC, PIPE_SEL=0, MAXO_SEL=0),
    "hpc_evidence":    dict(HPC, PIPE_SEL=1, MAXO_SEL=1),
    "hpc_ev_p31maxo":  dict(HPC, PIPE_SEL=1, MAXO_SEL=0),
    "hpc_deep":        dict(HPC, PIPE_SEL=2, MAXO_SEL=1),
    "hpc_ev_buf1":     dict(HPC, PIPE_SEL=1, MAXO_SEL=1, BUF_DEPTH=1),
    "hpc_ev_rr":       dict(HPC, PIPE_SEL=1, MAXO_SEL=1, ARB_MODE=1),
    "hpc_ev_tc0":      dict(HPC, PIPE_SEL=1, MAXO_SEL=1, TC_MODE=0),
    "hpc_ev_p22c":     dict(HPC, PIPE_SEL=1, MAXO_SEL=1, CENTRAL=0),
    "hpc_mesh":        dict(HPC, DUT=1, TOPOLOGY=2, MESH_X=4, MESH_Y=3, MAXO_SEL=1),
    "hpc_p22xbar":     dict(HPC, DUT=1, TOPOLOGY=1, MAXO_SEL=0, ARB_MODE=2),
    # ---- synthetic configurations (P22 address map)
    "syn_m4t4_mix3":   dict(DUT=0, CFG=0, NM=4, NT=4, MAXO=4, PIPE_SEL=4, PIPE_N=3),
    "syn_m6t5_u2":     dict(DUT=0, CFG=0, NM=6, NT=5, MAXO=4, PIPE_SEL=3, PIPE_N=2),
    "syn_m3t3_d64_aw48": dict(DUT=0, CFG=0, NM=3, NT=3, MAXO=4, DW=64, AW=48, PIPE_SEL=4, PIPE_N=2),
    "syn_m8t8_id3_rr_b1": dict(DUT=0, CFG=0, NM=8, NT=8, MAXO=8, IDW=3, ARB_MODE=1, BUF_DEPTH=1, PIPE_SEL=3, PIPE_N=1),
    "syn_m5t6_sfb2":   dict(DUT=0, CFG=0, NM=5, NT=6, MAXO=4, TGT_SFB2=1, QCAP=2, PIPE_SEL=4, PIPE_N=2),
    "syn_m4t4_p15":    dict(DUT=0, CFG=0, NM=4, NT=4, MAXO=4, PIPE_SEL=3, PIPE_N=15, BUF_DEPTH=1),
    "syn_m6t4_tc0_d4": dict(DUT=0, CFG=0, NM=6, NT=4, MAXO=4, TC_MODE=0, BUF_DEPTH=4, PIPE_SEL=4, PIPE_N=2),
    "syn_m3t5_sparse": dict(DUT=0, CFG=0, NM=3, NT=5, MAXO=4, EN_SPARSE=1, PIPE_SEL=4, PIPE_N=2),
}

# P22 test definitions (scripts/regress.py of Project 22), reused verbatim
P22_TESTS = {
    "smoke":     "+n=600",
    "random":    "+n=3000 +ooo=1 +lat_min=1 +lat_max=8 +tbp=200 +rbp=200 +p_err=30 +p_bad=20 +errwin=1",
    "routes":    "+amode=5 +n=64",
    "raw_fence": "+amode=3 +ooo=1 +lat_max=16 +tbp=150 +rbp=150 +n=2000",
    "hotspot":   "+amode=1 +rate=1000 +lat_max=2 +n=3000",
    "bursts":    "+amode=2 +burst=256 +rate=1000 +p_fence=0 +n=2048",
    "perm":      "+amode=4 +shift=1 +rate=1000 +n=3000",
    "backpress": "+tbp=500 +rbp=500 +ooo=1 +lat_max=10 +n=2500",
    "resets":    "+resets=6 +ooo=1 +lat_max=8 +tbp=200 +rbp=200 +n=4000",
    "errors":    "+p_err=200 +p_bad=100 +errwin=1 +p_post=400 +n=3000",
    "spurious":  "+spur=80 +ooo=1 +lat_max=6 +rbp=300 +n=3000",
    "spur_bad":  "+spur=80 +spur_badsrc=1 +ooo=1 +lat_max=6 +n=3000",
    "qos_levels": "+amode=1 +rate=1000 +qos_idx=1 +qos_check=1 +lat_max=2 +n=3000",
    "maxload":   "+rate=1000 +ooo=1 +lat_min=4 +lat_max=16 +rbp=600 +tbp=300 +n=4000 +wd=20000",
    "nofence_neg": "+amode=3 +ooo=1 +lat_max=16 +nofence=1 +n=2000",
}
# die-workload tests (HPC configuration)
DIE_TESTS = {
    "die":          "+amode=6 +n=3000",
    "die_low":      "+amode=6 +load=100 +n=600",
    "die_sat":      "+amode=6 +load=4000 +n=4000",
    "die_bursts":   "+amode=6 +burst=128 +n=4000",
    "die_bp":       "+amode=6 +tbp=400 +rbp=400 +n=2500",
    "die_errors":   "+amode=6 +p_err=40 +errwin=1 +n=3000",
    "die_resets":   "+amode=6 +resets=4 +n=4000",
    "die_spur":     "+amode=6 +spur=40 +ooo=1 +n=3000",
    "hotspot_sram": "+amode=1 +hot=0 +p_hot=900 +rate=1000 +n=3000",
    "ctrl_vs_mem":  "+amode=1 +hot=0 +p_hot=1000 +rate=1000 +n=3000",
    "routes":       "+amode=5 +n=64",
    "random":       "+n=3000 +ooo=1 +tbp=200 +rbp=200 +p_err=30 +p_bad=20 +errwin=1",
    "raw_fence":    "+amode=3 +ooo=1 +tbp=150 +rbp=150 +n=2000",
    "perm":         "+amode=4 +shift=1 +rate=1000 +n=3000",
    "bursts":       "+amode=2 +burst=256 +rate=1000 +p_fence=0 +n=2048",
}
TESTS = dict(P22_TESTS, **{k: v for k, v in DIE_TESTS.items() if k not in P22_TESTS})
EXPECT_FAIL = {"nofence_neg"}

SYN_TESTS = [t for t in P22_TESTS if t != "qos_levels"]
HPC_TESTS = list(DIE_TESTS)


def plan(quick=False):
    runs = []
    add = lambda cfgs, tests, seeds: runs.extend((c, t, s) for c in cfgs for t in tests for s in seeds)
    if quick:
        add(["hpc_evidence"], ["die", "die_resets", "ctrl_vs_mem", "random"], [1])
        add(["syn_m4t4_mix3"], ["random", "resets", "raw_fence"], [1])
        return runs
    add(["hpc_evidence"], HPC_TESTS, [1, 2, 3])
    add(["hpc_single", "hpc_deep", "hpc_ev_p31maxo"], HPC_TESTS, [1, 2])
    add(["hpc_ev_buf1", "hpc_ev_rr", "hpc_ev_tc0", "hpc_ev_p22c"], HPC_TESTS, [1])
    add(["hpc_mesh", "hpc_p22xbar"], ["die", "die_low", "die_sat", "die_bursts", "hotspot_sram", "random", "routes"], [1])
    add(["syn_m4t4_mix3", "syn_m6t5_u2"], SYN_TESTS, [1, 2])
    add(["syn_m3t3_d64_aw48", "syn_m8t8_id3_rr_b1", "syn_m4t4_p15", "syn_m3t5_sparse"], SYN_TESTS, [1])
    # SFB2 targets answer in order: the read-after-write negative test cannot fail there (P22 PROTOCOL sec. 5)
    add(["syn_m5t6_sfb2"], [t for t in SYN_TESTS if t != "nofence_neg"], [1])
    add(["syn_m6t4_tc0_d4"], SYN_TESTS + ["qos_levels"], [1])
    return runs


def build(name, params, files, top, extra=()):
    d = os.path.join(B, name)
    exe = os.path.join(d, "sim")
    stamp = os.path.join(d, "params.json")
    key = json.dumps(dict(params=params, files=files, extra=list(extra)), sort_keys=True)
    if os.path.exists(exe) and os.path.exists(stamp) and open(stamp).read() == key and \
            os.path.getmtime(exe) > max(os.path.getmtime(os.path.join(ROOT, f)) for f in files_of(files)):
        return exe, 0.0
    t0 = time.time()
    os.makedirs(d, exist_ok=True)
    cmd = (["verilator"] + VFLAGS + [f"-I{ROOT}/tb", f"-I{ROOT}/{TP}/tb"] + list(extra) +
           [x for f in files for x in ("-f", os.path.join(ROOT, f))] +
           ["--top-module", top, "--Mdir", d, "-o", "sim"] + [f"-G{k}={v}" for k, v in params.items()])
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    if r.returncode:
        raise RuntimeError(f"build {name} failed:\n{r.stderr[-3000:]}")
    open(stamp, "w").write(key)
    return exe, time.time() - t0


def files_of(fl):
    out = []
    for f in fl:
        for l in open(os.path.join(ROOT, f)):
            l = l.strip()
            if l.startswith("-f"):
                out += files_of([l.split()[1]])
            elif l:
                out.append(l)
    return out


def run(exe, args, timeout=900):
    t0 = time.time()
    try:
        r = subprocess.run([exe] + args, capture_output=True, text=True, timeout=timeout, cwd=ROOT)
        out, rc = r.stdout + r.stderr, r.returncode
    except subprocess.TimeoutExpired as e:
        out, rc = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), -9
    res, sp = None, None
    for l in out.splitlines():
        if l.startswith("RESULT "):
            try: res = json.loads(l[7:])
            except ValueError: pass
        if l.startswith("SPINE "):
            try: sp = json.loads(l[6:])
            except ValueError: pass
    asserts = sum(1 for l in out.splitlines() if l.startswith("ASSERT ") or l.startswith("SPINE_ASSERT_ERRORS"))
    passed = rc == 0 and "TEST PASSED" in out and asserts == 0
    return dict(passed=passed, rc=rc, secs=round(time.time() - t0, 2), result=res, spine=sp, asserts=asserts,
                tail="" if passed else "\n".join(out.splitlines()[-12:]))


SPINE_FILES = ["files_sim.f", "files_tb.f"]
P22_FILES_SHIM = ["files_sim.f", "tb/compat/files_compat.f"]
P22_FILES_ORIG = ["tb/compat/files_p22.f"]


def spine_mode(quick):
    runs = plan(quick)
    cfgs = sorted({c for c, _, _ in runs})
    with ThreadPoolExecutor(max_workers=max(1, JOBS // 2)) as ex:
        built = dict(zip(cfgs, ex.map(lambda c: build(c, CONFIGS[c], SPINE_FILES, "tb_spine"), cfgs)))
    def one(r):
        c, t, s = r
        exe, _ = built[c]
        args = [f"+seed={s}", f"+test={c}/{t}"] + TESTS[t].split()
        o = run(exe, args)
        exp = "FAIL" if t in EXPECT_FAIL else "PASS"
        ok = (o["passed"] if exp == "PASS" else (not o["passed"] and o["rc"] != -9))
        return dict(kind="spine", config=c, params=CONFIGS[c], test=t, seed=s, expect=exp, ok=ok,
                    cmd=f"build/sim/{c}/sim " + " ".join(args), **o)
    with ThreadPoolExecutor(max_workers=JOBS) as ex:
        return list(ex.map(one, runs)), {c: round(v[1], 1) for c, v in built.items()}


COMPAT_CFGS = {
    "xb_m4t4":        dict(TOPOLOGY=1, NM=4, NT=4),
    "xb_m5t6":        dict(TOPOLOGY=1, NM=5, NT=6),
    "xb_m3t5_sparse": dict(TOPOLOGY=1, NM=3, NT=5, EN_SPARSE=1),
    "xb_m1t1":        dict(TOPOLOGY=1, NM=1, NT=1, MAXO0=4),
    "xb_m2t1":        dict(TOPOLOGY=1, NM=2, NT=1),
    "xb_m8t8_id3":    dict(TOPOLOGY=1, NM=8, NT=8, IDW=3, MAXO=8),
    "xb_qos_m5t4":    dict(TOPOLOGY=1, NM=5, NT=4, ARB_MODE=2, STARVE=4),
    "xb_qos_s1_m4t2": dict(TOPOLOGY=1, NM=4, NT=2, ARB_MODE=2, STARVE=1),
    "xb_fixed_m4t4":  dict(TOPOLOGY=1, NM=4, NT=4, ARB_MODE=0),
    "xb_d64":         dict(TOPOLOGY=1, NM=4, NT=4, DW=64),
    "xb_d128_id1":    dict(TOPOLOGY=1, NM=3, NT=3, DW=128, IDW=1, MAXO=2),
    "xb_aw48":        dict(TOPOLOGY=1, NM=4, NT=4, AW=48),
    "xb_maxo1":       dict(TOPOLOGY=1, NM=4, NT=4, MAXO=1, MAXO0=1),
    "xb_noperf":      dict(TOPOLOGY=1, NM=4, NT=4, PERF=0),
    "xb_noalign":     dict(TOPOLOGY=1, NM=4, NT=4, CHECK_ALIGN=0),
    "xb_sfb2tgt":     dict(TOPOLOGY=1, NM=4, NT=4, TGT_SFB2=1),
    "xb_sfb2tgt_m5t6": dict(TOPOLOGY=1, NM=5, NT=6, TGT_SFB2=1, QCAP=2),
}
# P22's crossbar regression matrix (P22 scripts/regress.py), verbatim; the RETIRE_BYPASS = 1 configurations
# (xb_m5t6_byp, xb_maxo1_byp, xb_qos_byp) are not offered by the spine (registered eligibility only)
XB_TESTS = ["smoke", "random", "routes", "raw_fence", "hotspot", "bursts", "perm", "backpress", "resets",
            "errors", "spurious", "maxload", "nofence_neg"]
def p22_matrix():
    rows = []
    def add(cfgs, tests, seeds):
        rows.extend((c, t, s) for c in cfgs for t in tests for s in seeds)
    add(["xb_m4t4", "xb_m5t6"], XB_TESTS, [1, 2, 3])
    add(["xb_m3t5_sparse", "xb_m8t8_id3", "xb_qos_m5t4", "xb_d64", "xb_aw48"], XB_TESTS, [1, 2])
    add(["xb_maxo1"], [t for t in XB_TESTS if t != "nofence_neg"], [1, 2])
    add(["xb_m1t1", "xb_m2t1", "xb_d128_id1", "xb_noperf", "xb_noalign"],
        ["smoke", "random", "routes", "raw_fence", "resets", "errors", "spurious", "maxload"], [1, 2])
    add(["xb_sfb2tgt", "xb_sfb2tgt_m5t6"], ["smoke", "random", "routes", "raw_fence", "hotspot", "bursts", "backpress",
                                           "resets", "errors", "maxload"], [1, 2])
    add(["xb_qos_m5t4"], ["qos_levels"], [1, 2, 3])
    add(["xb_qos_s1_m4t2"], ["smoke", "random", "hotspot", "backpress", "maxload"], [1, 2])
    add(["xb_fixed_m4t4"], ["smoke", "random", "routes", "raw_fence", "backpress", "resets", "errors", "maxload"], [1, 2])
    return rows
# with link stages, P22's testbench measures fairness and QoS at the master port, which is no longer the switch
# (hotspot / bursts / perm / maxload / qos_levels), and its fault injector assumes "pending at the target" equals
# "outstanding at the target" (spurious) -- both true only for a combinational crossbar (docs/VERIFICATION.md sec. 3)
PIPE_SKIP = {"hotspot", "bursts", "perm", "maxload", "qos_levels", "spurious", "spur_bad"}
PIPE_CFGS = ["xb_m4t4", "xb_m5t6", "xb_m8t8_id3", "xb_sfb2tgt", "xb_d64"]


def compat_mode(quick):
    rows0 = [("xb_m4t4", t, 1) for t in XB_TESTS[:3]] if quick else p22_matrix()
    rows2 = [] if quick else [(c, t, s) for (c, t, s) in p22_matrix() if c in PIPE_CFGS and t not in PIPE_SKIP and s == 1]
    builds = sorted({(c, 0) for c, _, _ in rows0} | {(c, 2) for c, _, _ in rows2})
    def b(cp):
        c, pipe = cp
        return build(f"compat_{c}_p{pipe}", COMPAT_CFGS[c], P22_FILES_SHIM, "tb_noc", extra=(f"+define+SPINE_PIPE={pipe}",))
    with ThreadPoolExecutor(max_workers=max(1, JOBS // 2)) as ex:
        built = dict(zip(builds, ex.map(b, builds)))
    runs = [(c, 0, t, s) for c, t, s in rows0] + [(c, 2, t, s) for c, t, s in rows2]
    def one(r):
        c, pipe, t, s = r
        exe, _ = built[(c, pipe)]
        args = [f"+seed={s}", f"+test=compat/{c}/p{pipe}/{t}"] + P22_TESTS[t].split()
        o = run(exe, args)
        exp = "FAIL" if t in EXPECT_FAIL else "PASS"
        ok = (o["passed"] if exp == "PASS" else (not o["passed"] and o["rc"] != -9))
        return dict(kind="compat", config=c, params=dict(COMPAT_CFGS[c], SPINE_PIPE=pipe), test=t, seed=s, expect=exp,
                    ok=ok, cmd=f"build/sim/compat_{c}_p{pipe}/sim " + " ".join(args), **o)
    with ThreadPoolExecutor(max_workers=JOBS) as ex:
        return list(ex.map(one, runs)), {f"compat_{c}_p{p}": round(v[1], 1) for (c, p), v in built.items()}


def identity_mode(quick):
    cfgs = ["xb_m5t6", "xb_qos_m5t4"] if quick else ["xb_m5t6", "xb_qos_m5t4", "xb_m8t8_id3", "xb_fixed_m4t4"]
    tests = ["random", "resets"] if quick else ["random", "resets", "hotspot", "bursts", "errors", "spurious"]
    builds = [(c, k) for c in cfgs for k in ("p22", "spine", "spine_c0")]
    def b(ck):
        c, k = ck
        if k == "p22":
            return build(f"id_{c}_p22", COMPAT_CFGS[c], P22_FILES_ORIG, "tb_noc")
        return build(f"id_{c}_{k}", COMPAT_CFGS[c], P22_FILES_SHIM, "tb_noc",
                     extra=("+define+SPINE_PIPE=0", f"+define+SPINE_CENTRAL={0 if k == 'spine_c0' else 1}"))
    with ThreadPoolExecutor(max_workers=max(1, JOBS // 2)) as ex:
        built = dict(zip(builds, ex.map(b, builds)))
    rows = []
    def one(ct):
        c, t = ct
        traces = {}
        res = {}
        for k in ("p22", "spine", "spine_c0"):
            tr = os.path.join(B, f"id_{c}_{k}", f"{t}.csv")
            args = ["+seed=7", f"+trace={tr}"] + P22_TESTS[t].split()
            res[k] = run(built[(c, k)][0], args)
            traces[k] = tr
        same = all(os.path.exists(traces[k]) for k in traces) and \
            filecmp.cmp(traces["p22"], traces["spine"], shallow=False) and \
            filecmp.cmp(traces["p22"], traces["spine_c0"], shallow=False)
        lines = sum(1 for _ in open(traces["p22"])) - 1 if os.path.exists(traces["p22"]) else 0
        ok = same and all(r["passed"] for r in res.values())
        return dict(kind="identity", config=c, test=t, seed=7, expect="IDENTICAL", ok=ok, transactions=lines,
                    passed=ok, secs=sum(r["secs"] for r in res.values()), params=COMPAT_CFGS[c],
                    tail="" if ok else "traces differ or a run failed", cmd=f"compare build/sim/id_{c}_*/{t}.csv")
    with ThreadPoolExecutor(max_workers=JOBS) as ex:
        rows = list(ex.map(one, [(c, t) for c in cfgs for t in tests]))
    return rows, {f"id_{c}_{k}": round(v[1], 1) for (c, k), v in built.items()}


def write(rows, builds, mode, quick=False):
    # --quick runs report separately: they must never replace the full regression report
    base = "regression_quick" if quick else "regression"
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    path = os.path.join(ROOT, "reports", base + ".json")
    prev = json.load(open(path)) if os.path.exists(path) else {}
    kinds = {r["kind"] for r in rows}
    keep = [r for r in prev.get("runs", []) if r["kind"] not in kinds]
    allrows = keep + rows
    ver = subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip()
    json.dump(dict(tool=ver, runs=allrows, builds=dict(prev.get("builds", {}), **builds)), open(path, "w"), indent=1)
    L = ["# Regression (generated by scripts/regress.py" + (" --quick" if quick else "") + ")", "", f"Simulator: {ver}.", ""]
    for kind, title in (("spine", "Spine testbench (tb/tb_spine.sv)"), ("compat", "P22 testbench, unmodified, on the spine"),
                        ("identity", "Cycle identity: P22 crossbar vs spine (0 stages), same seeds")):
        rs = [r for r in allrows if r["kind"] == kind]
        if not rs:
            continue
        n_ok = sum(r["ok"] for r in rs)
        txn = sum((r.get("result") or {}).get("txns", 0) for r in rs) + sum(r.get("transactions", 0) for r in rs)
        L += [f"## {title}: **{n_ok} / {len(rs)} as expected**", "",
              f"Transactions checked: {txn:,}." if txn else "", ""]
        cfgs = sorted({r["config"] for r in rs})
        L += ["| Configuration | Runs | As expected | Tests | Parameters |", "|---|---|---|---|---|"]
        for c in cfgs:
            cr = [r for r in rs if r["config"] == c]
            L.append(f"| {c} | {len(cr)} | {sum(r['ok'] for r in cr)} | {len({r['test'] for r in cr})} | "
                     f"`{json.dumps(cr[0]['params'])}` |")
        bad = [r for r in rs if not r["ok"]]
        if bad:
            L += ["", "### Not as expected", ""]
            for r in bad:
                L += [f"* `{r['cmd']}` (expect {r['expect']})", "", "```", r.get("tail", ""), "```"]
        neg = [r for r in rs if r["expect"] == "FAIL"]
        if neg:
            L += ["", f"Negative tests (`nofence_neg`: FENCE removed from read-after-write traffic with out-of-order "
                  f"targets, must fail): {sum(r['ok'] for r in neg)} / {len(neg)} failed as required.", ""]
        L.append("")
    open(os.path.join(ROOT, "reports", base + ".md"), "w").write("\n".join(L))
    return all(r["ok"] for r in rows)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    quick = "--quick" in sys.argv
    modes = args or ["all"]
    if "all" in modes:
        modes = ["spine", "compat", "identity"]
    rows, builds = [], {}
    for m in modes:
        r, b = {"spine": spine_mode, "compat": compat_mode, "identity": identity_mode}[m](quick)
        rows += r
        builds.update(b)
        print(f"{m}: {sum(x['ok'] for x in r)} / {len(r)} as expected")
        for x in r:
            if not x["ok"]:
                print("  NOT OK:", x["cmd"], "\n   ", x.get("tail", "")[-600:])
    ok = write(rows, builds, modes, quick)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
