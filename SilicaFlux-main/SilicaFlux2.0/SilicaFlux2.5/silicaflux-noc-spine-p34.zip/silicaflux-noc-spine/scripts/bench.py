#!/usr/bin/env python3
"""SilicaFlux NoC Spine -- performance benchmark (RTL simulation, Verilator).

Every benchmark run is also a fully checked test run (scoreboard, assertions, counters).
Uses the HPC builds of scripts/regress.py (build/sim/hpc_*).  For each run it keeps the
testbench's SPINE / RESULT lines (link transfers, stalls, occupancy, central-stage waits,
per-class counts, all cross-checked against the RTL counter pages) and the per-transaction
trace (latency per class: cycles from master acceptance to response, or to completion at the
target for posted writes).

Experiments (docs/PERFORMANCE.md):
  E1 pipelining: single central stage vs evidence vs deep, die workload, load 10 %..100 %;
     cycles AND time (the evidence clock comes from reports/placement.json -- synthesis-level)
  E2 buffer depth: 1 vs 2 entries per stage
  E3 arbitration / traffic classes: QoS + classes vs round robin vs master QoS (TC_MODE 0)
  E4 topology: spine vs P22 4x3 mesh (registered multistage) vs P22 crossbar
  E5 simultaneous operation: each workload alone vs all together (contention, bottlenecks)
  E6 hotspot / long bursts / control-vs-memory flood
Writes reports/bench.{json,md} and reports/img/*.png.
"""
import csv, json, math, os, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
B = os.path.join(ROOT, "build", "sim")
OUT = os.path.join(ROOT, "build", "bench")
REP = os.path.join(ROOT, "reports")
JOBS = int(os.environ.get("JOBS", "4"))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import gen_cfg  # noqa: E402

CFG = gen_cfg.load()
MS, TS = CFG["masters"], CFG["targets"]
NM, NT = len(MS), len(TS)
MNAMES = [m["name"] for m in MS]
TNAMES = [t["name"] for t in TS]
CTRL = [m["ctrl"] for m in MS]
MMIO = [t["mmio"] for t in TS]
GROUP = {"CC": [0], "HOST": [1], "DMA": [2, 3], "VEC": [4, 5, 6, 7], "TSU": [8, 9]}


def tclass(m, t, op):
    if CTRL[m] or (t >= 0 and MMIO[t]):
        return "CTRL"
    return "RD" if op == 0 else "WR"


def pct(xs, p):
    if not xs:
        return 0
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(math.ceil(p / 100.0 * len(xs))) - 1)]


def run(name, cfg, args):
    d = os.path.join(OUT, name)
    os.makedirs(d, exist_ok=True)
    tr = os.path.join(d, "trace.csv")
    exe = os.path.join(B, cfg, "sim")
    r = subprocess.run([exe, f"+trace={tr}"] + args, capture_output=True, text=True, cwd=ROOT, timeout=1800)
    out = r.stdout + r.stderr
    res = sp = None
    for l in out.splitlines():
        if l.startswith("RESULT "):
            res = json.loads(l[7:])
        elif l.startswith("SPINE "):
            sp = json.loads(l[6:])
    passed = r.returncode == 0 and "TEST PASSED" in out and not any(l.startswith("ASSERT") for l in out.splitlines())
    lat = {}
    per_m = {m: [] for m in range(NM)}
    if os.path.exists(tr):
        with open(tr) as f:
            for row in csv.DictReader(f):
                m, t, op = int(row["master"]), int(row["target"]), int(row["op"])
                if op == 3 or t < 0:
                    continue                      # FENCE / fabric-local responses
                c = tclass(m, t, op)
                lat.setdefault(c, []).append(int(row["latency"]))
                per_m[m].append(int(row["latency"]))
    stats = {c: dict(n=len(v), mean=round(sum(v) / len(v), 2), p50=pct(v, 50), p99=pct(v, 99), max=max(v))
             for c, v in lat.items() if v}
    mstats = {MNAMES[m]: dict(n=len(v), mean=round(sum(v) / len(v), 2) if v else 0, p99=pct(v, 99), max=max(v) if v else 0)
              for m, v in per_m.items()}
    return dict(name=name, config=cfg, args=args, passed=passed, result=res, spine=sp, lat=stats, mlat=mstats,
                tail="" if passed else out[-1500:])


def derived(r):
    """Link utilisation, occupancy, stalls and waits from the (counter-checked) SPINE line."""
    sp, res = r.get("spine"), r.get("result")
    if not res:
        return {}
    d = dict(cycles=res["cycles"], txns=res["txns"], bytes=res["bytes"], bpc=res["bytes_per_cycle"],
             avg_lat=res["avg_lat"], max_lat=res["max_lat"])
    if sp:
        cyc = max(1, sp["cycles"])
        util = [x / cyc for x in sp["mq_xfer"]] + [x / cyc for x in sp["tq_xfer"]]
        d.update(
            link_util_max=round(max(util), 3),
            link_util_max_name=(MNAMES + TNAMES)[util.index(max(util))],
            mlink_util=[round(x / cyc, 3) for x in sp["mq_xfer"]],
            tlink_util=[round(x / cyc, 3) for x in sp["tq_xfer"]],
            tlink_rsp_util=[round(x / cyc, 3) for x in sp["tr_xfer"]],
            mq_occ_avg=[round(x / cyc, 2) for x in sp["mq_occ_sum"]], mq_occ_max=sp["mq_occ_max"],
            tq_occ_avg=[round(x / cyc, 2) for x in sp["tq_occ_sum"]], tq_occ_max=sp["tq_occ_max"],
            node_stall=sp["mq_stall"], tgt_stall=sp["tq_stall"], m_req_stall=sp["m_req_stall"],
            c_wait=sp["c_wait"], c_wait_max=sp["c_wait_max"], c_loss=sp["c_loss"], c_tgt_bp=sp["c_tgt_bp"],
            cls_acc=sp["cls_acc"], cls_wait_avg=[round(w / a, 2) if a else 0 for w, a in zip(sp["cls_wait"], sp["cls_acc"])],
            cls_wait_max=sp["cls_wait_max"], m_occ_max=sp["m_occ_max"], mpipe=sp["mpipe"], tpipe=sp["tpipe"], maxo=sp["maxo"],
            m_acc=sp["m_acc"])
    return d


BASE_RATE = {"cc_mmio": 40, "host": 25, "dma_write": 1000, "vec_spm": 700, "tensor_load": 1000}
P31_QOS = {"CTRL": 3, "DMA": 0, "VECTOR": 2, "TENSOR": 1}


def die(load=1000, n=2500, seed=1):
    """Die workload; every master's transaction count is scaled to its profile rate so that all roles run
    concurrently for the whole measurement (the slow ControlCore / host profiles do not stretch the run)."""
    a = ["+amode=6", f"+load={load}", f"+n={n}", f"+seed={seed}"]
    for i, m in enumerate(MS):
        a.append(f"+n{i}={max(20, round(n * BASE_RATE[m['profile']] / 1000))}")
    return a


def p31_qos():
    return [f"+qos{i}={P31_QOS[m['qos']]}" for i, m in enumerate(MS)]


def experiments():
    E = []
    for load in (100, 300, 600, 1000):
        for cfg in ("hpc_single", "hpc_evidence", "hpc_ev_p31maxo", "hpc_deep"):
            E.append(("E1", f"E1_{cfg}_l{load}", cfg, die(load, 2500, 1)))
    for cfg in ("hpc_evidence", "hpc_ev_buf1"):
        E.append(("E2", f"E2_{cfg}_sat", cfg, die(1000, 3000, 1)))
        E.append(("E2", f"E2_{cfg}_bursts", cfg, ["+amode=2", "+burst=256", "+rate=1000", "+p_fence=0", "+n=2048", "+seed=1"]))
    for cfg in ("hpc_evidence", "hpc_ev_rr", "hpc_ev_tc0"):
        q = p31_qos() if cfg == "hpc_ev_tc0" else []
        E.append(("E3", f"E3_{cfg}_die", cfg, die(1000, 3000, 2) + q))
        E.append(("E3", f"E3_{cfg}_flood", cfg, ["+amode=1", "+hot=0", "+p_hot=1000", "+rate=1000", "+n=3000", "+seed=2"] + q))
    for cfg in ("hpc_evidence", "hpc_ev_p31maxo", "hpc_mesh", "hpc_p22xbar"):
        E.append(("E4", f"E4_{cfg}_die", cfg, die(1000, 3000, 3)))
        E.append(("E4", f"E4_{cfg}_hot", cfg, ["+amode=1", "+hot=0", "+p_hot=900", "+rate=1000", "+n=3000", "+seed=3"]))
        E.append(("E4", f"E4_{cfg}_perm", cfg, ["+amode=4", "+shift=1", "+rate=1000", "+n=3000", "+seed=3"]))
    for grp, ms in GROUP.items():
        silence = [f"+active{m}=0" for m in range(NM) if m not in ms]
        E.append(("E5", f"E5_alone_{grp}", "hpc_evidence", die(1000, 2500, 4) + silence))
    E.append(("E5", "E5_all", "hpc_evidence", die(1000, 2500, 4)))
    E.append(("E6", "E6_hot_sram0", "hpc_evidence", ["+amode=1", "+hot=0", "+p_hot=900", "+rate=1000", "+n=3000", "+seed=5"]))
    E.append(("E6", "E6_bursts256", "hpc_evidence", ["+amode=2", "+burst=256", "+rate=1000", "+p_fence=0", "+n=4096", "+seed=5"]))
    E.append(("E6", "E6_ctrl_flood", "hpc_evidence", ["+amode=1", "+hot=0", "+p_hot=1000", "+rate=1000", "+n=3000", "+seed=5"]))
    return E


def main():
    E = experiments()
    with ThreadPoolExecutor(max_workers=JOBS) as ex:
        rows = list(ex.map(lambda e: dict(exp=e[0], **run(e[1], e[2], e[3])), E))
    for r in rows:
        r["d"] = derived(r)
    pl = json.load(open(os.path.join(REP, "placement.json")))
    clocks = {"hpc_single": pl["single"]["period_ps"], "hpc_evidence": pl["evidence"]["period_ps"],
              "hpc_ev_p31maxo": pl["evidence"]["period_ps"], "hpc_ev_buf1": pl["evidence"]["period_ps"],
              "hpc_ev_tc0": pl["evidence"]["period_ps"], "hpc_p22xbar": pl["single"]["period_ps"]}
    json.dump(dict(runs=rows, clocks_ps=clocks), open(os.path.join(REP, "bench.json"), "w"), indent=1)
    write_md(rows, clocks, pl)
    plots(rows, clocks)
    bad = [r for r in rows if not r["passed"]]
    print(f"bench: {len(rows) - len(bad)} / {len(rows)} runs passed their checks")
    for r in bad:
        print("  FAILED", r["name"], r["tail"][-400:])
    sys.exit(1 if bad else 0)


def g(rows, name):
    return next(r for r in rows if r["name"] == name)


def write_md(rows, clocks, pl):
    L = ["# Performance benchmark (generated by scripts/bench.py)", "",
         "RTL simulation (Verilator 5.020) of the HPC floorplan configuration, 10 masters x 11 targets. Every run "
         f"is a fully checked test (scoreboard, in-RTL assertions, both counter pages): **{sum(r['passed'] for r in rows)} / "
         f"{len(rows)} passed**. Cycle numbers are measured. Nanosecond numbers multiply measured cycles by the clock "
         "period of reports/placement.md, a synthesis-level estimate (sky130 HD, ABC, conceptual wires), not sign-off.", "",
         "Latency = cycles from acceptance at the master port to the response at the master (posted writes: to the "
         "completion at the target). Classes: CTRL = from a control master or to a register target, RD, WR.", ""]
    # ---- E1
    L += ["## E1 -- pipelining: single central stage vs placement evidence vs deep", "",
          "| Config | Load | Cycles | B/cycle | Mean lat (cyc) | CTRL mean / p99 | RD mean / p99 | WR mean / p99 | Max link util | Clock (ns) | Mean lat (ns) | GB/s |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for load in (100, 300, 600, 1000):
        for cfg in ("hpc_single", "hpc_evidence", "hpc_ev_p31maxo", "hpc_deep"):
            r = g(rows, f"E1_{cfg}_l{load}")
            d = r["d"]
            ck = clocks.get(cfg)
            lat = lambda c: f"{r['lat'].get(c, {}).get('mean', '-')} / {r['lat'].get(c, {}).get('p99', '-')}"
            L.append(f"| {cfg} | {load / 10:.0f} % | {d.get('cycles')} | {d.get('bpc')} | {d.get('avg_lat')} | {lat('CTRL')} | "
                     f"{lat('RD')} | {lat('WR')} | {d.get('link_util_max', '-')} ({d.get('link_util_max_name', '')}) | "
                     f"{round(ck / 1000, 2) if ck else 'n/a'} | {round(d.get('avg_lat', 0) * ck / 1000, 1) if ck else 'n/a'} | "
                     f"{round(d.get('bpc', 0) * 1e3 / ck, 3) if ck else 'n/a'} |")
    L += ["", "Transaction counts are scaled to each profile's rate (ControlCore 100, host 62, vector 1750, DMA and tensor "
          "2500 at n = 2500) so that every role is active for the whole run.", "",
          "`hpc_ev_p31maxo` = evidence pipelining with P31's outstanding limits (CC 1, HOST 1, DMA 2, VEC 1, TSU 4); "
          "`hpc_evidence` uses the limits sized against the pipelined round trip (CC 2, HOST 2, DMA 8, VEC 4, TSU 8). "
          "`hpc_deep` is the 4 mm-per-cycle sensitivity point: its clock is not derived here (n/a).", ""]
    # ---- detailed evidence run
    r = g(rows, "E1_hpc_evidence_l1000")
    d = r["d"]
    L += ["## Detailed report: recommended configuration (evidence), die workload, full load", "",
          f"{d['cycles']} cycles, {d['txns']} transactions, {d['bytes']} bytes, {d['bpc']} bytes/cycle.", "",
          "| Master link | Stages | MAXO | Requests | Mean lat | p99 | Link util | Occ avg / max | Node stall cyc | Central wait | Wait max | Arb loss | Tgt busy |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for m in range(NM):
        ml = r["mlat"][MNAMES[m]]
        L.append(f"| {MNAMES[m]} | {d['mpipe'][m]} | {d['maxo'][m]} | {d['m_acc'][m]} | {ml['mean']} | {ml['p99']} | "
                 f"{d['mlink_util'][m]} | {d['mq_occ_avg'][m]} / {d['mq_occ_max'][m]} | {d['node_stall'][m]} | "
                 f"{d['c_wait'][m]} | {d['c_wait_max'][m]} | {d['c_loss'][m]} | {d['c_tgt_bp'][m]} |")
    L += ["", "| Target link | Stages | Req util | Rsp util | Occ avg / max | Stall (target busy) cyc |", "|---|---|---|---|---|---|"]
    for t in range(NT):
        L.append(f"| {TNAMES[t]} | {d['tpipe'][t]} | {d['tlink_util'][t]} | {d['tlink_rsp_util'][t]} | "
                 f"{d['tq_occ_avg'][t]} / {d['tq_occ_max'][t]} | {d['tgt_stall'][t]} |")
    L += ["", "| Class | Accepted at central stage | Mean wait (cyc) | Max wait (cyc) |", "|---|---|---|---|"]
    for i, c in enumerate(("CTRL", "RD", "WR")):
        L.append(f"| {c} | {d['cls_acc'][i]} | {d['cls_wait_avg'][i]} | {d['cls_wait_max'][i]} |")
    # ---- E2
    L += ["", "## E2 -- buffer depth per link stage", "", "| Config | Workload | Cycles | B/cycle | Mean lat | Max link util |",
          "|---|---|---|---|---|---|"]
    for cfg in ("hpc_evidence", "hpc_ev_buf1"):
        for w in ("sat", "bursts"):
            d = g(rows, f"E2_{cfg}_{w}")["d"]
            L.append(f"| {cfg} | {w} | {d['cycles']} | {d['bpc']} | {d['avg_lat']} | {d.get('link_util_max')} |")
    # ---- E3
    L += ["", "## E3 -- arbitration and traffic classes", "",
          "| Config | Workload | Cycles | B/cycle | CTRL mean / p99 / max | RD mean | WR mean | Class wait max CTRL / RD / WR | Fairness: max other acceptances while waiting |",
          "|---|---|---|---|---|---|---|---|---|"]
    for cfg in ("hpc_evidence", "hpc_ev_rr", "hpc_ev_tc0"):
        for w in ("die", "flood"):
            r = g(rows, f"E3_{cfg}_{w}")
            d = r["d"]
            c = r["lat"].get("CTRL", {})
            L.append(f"| {cfg} | {w} | {d['cycles']} | {d['bpc']} | {c.get('mean')} / {c.get('p99')} / {c.get('max')} | "
                     f"{r['lat'].get('RD', {}).get('mean')} | {r['lat'].get('WR', {}).get('mean')} | "
                     f"{'/'.join(str(x) for x in d['cls_wait_max'])} | {max(r['result']['wait_max'])} |")
    L += ["", "`hpc_ev_tc0`: TC_MODE 0 with P31's per-master QoS levels (CC/HOST 3, VEC 2, TSU 1, DMA 0) instead of the "
          "class levels; `hpc_ev_rr`: round robin (no priority).", "",
          f"Bound checked in every run: QoS STARVE + NM - 1 = {CFG['fabric']['starve'] + NM - 1} other acceptances, "
          f"round robin NM - 1 = {NM - 1}.", ""]
    # ---- E4
    L += ["## E4 -- topology: spine vs registered multistage mesh vs P22 crossbar", "",
          "| Config | Workload | Cycles | B/cycle | Mean lat (cyc) | Max lat | Clock (ns) | Mean lat (ns) | GB/s |", "|---|---|---|---|---|---|---|---|---|"]
    for cfg in ("hpc_evidence", "hpc_ev_p31maxo", "hpc_mesh", "hpc_p22xbar"):
        for w in ("die", "hot", "perm"):
            d = g(rows, f"E4_{cfg}_{w}")["d"]
            ck = clocks.get(cfg)
            L.append(f"| {cfg} | {w} | {d['cycles']} | {d['bpc']} | {d['avg_lat']} | {d['max_lat']} | "
                     f"{round(ck / 1000, 2) if ck else 'n/a'} | {round(d['avg_lat'] * ck / 1000, 1) if ck else 'n/a'} | "
                     f"{round(d['bpc'] * 1e3 / ck, 3) if ck else 'n/a'} |")
    L += ["", "The mesh is P22's verified 2-D mesh (4 x 3 routers spread over the die, one master and one target per "
          "router); its clock is not derived (its hops are registered but each is 7-8 mm long, see docs/ARCHITECTURE.md).", ""]
    # ---- E5
    L += ["## E5 -- simultaneous operation and bottlenecks", "",
          "| Run | Cycles | B/cycle | Tensor mean lat | Vector mean lat | DMA mean lat | CC mean lat | Busiest link | Busiest central waits |",
          "|---|---|---|---|---|---|---|---|---|"]
    def grp_mean(r, ms):
        v = [r["mlat"][MNAMES[m]] for m in ms if r["mlat"][MNAMES[m]]["n"]]
        return round(sum(x["mean"] * x["n"] for x in v) / max(1, sum(x["n"] for x in v)), 2) if v else "-"
    for name in ["E5_alone_TSU", "E5_alone_VEC", "E5_alone_DMA", "E5_alone_CC", "E5_alone_HOST", "E5_all"]:
        r = g(rows, name)
        d = r["d"]
        w = d["c_wait"]
        top = sorted(range(NM), key=lambda m: -w[m])[:2]
        L.append(f"| {name} | {d['cycles']} | {d['bpc']} | {grp_mean(r, GROUP['TSU'])} | {grp_mean(r, GROUP['VEC'])} | "
                 f"{grp_mean(r, GROUP['DMA'])} | {grp_mean(r, GROUP['CC'])} | {d['link_util_max_name']} {d['link_util_max']} | "
                 f"{', '.join(f'{MNAMES[m]} {w[m]}' for m in top)} |")
    # ---- E6
    L += ["", "## E6 -- hotspot, long bursts, control flood", "", "| Run | Cycles | B/cycle | Mean lat | Max lat | Max link util | Fairness max |",
          "|---|---|---|---|---|---|---|"]
    for name in ("E6_hot_sram0", "E6_bursts256", "E6_ctrl_flood"):
        r = g(rows, name)
        d = r["d"]
        L.append(f"| {name} | {d['cycles']} | {d['bpc']} | {d['avg_lat']} | {d['max_lat']} | {d['link_util_max']} ({d['link_util_max_name']}) | "
                 f"{max(r['result']['wait_max'])} |")
    L += ["", "![latency vs load](img/bench_latency_load.png)", "", "![link utilisation](img/bench_link_util.png)", ""]
    open(os.path.join(REP, "bench.md"), "w").write("\n".join(L))


def plots(rows, clocks):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    os.makedirs(os.path.join(REP, "img"), exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    for cfg, mk in (("hpc_single", "o-"), ("hpc_evidence", "s-"), ("hpc_ev_p31maxo", "^-"), ("hpc_deep", "d-")):
        loads = [100, 300, 600, 1000]
        lat = [g(rows, f"E1_{cfg}_l{l}")["d"]["avg_lat"] for l in loads]
        bpc = [g(rows, f"E1_{cfg}_l{l}")["d"]["bpc"] for l in loads]
        ax[0].plot([l / 10 for l in loads], lat, mk, label=cfg)
        ck = clocks.get(cfg)
        if ck:
            ax[1].plot([l / 10 for l in loads], [b * 1e3 / ck for b in bpc], mk, label=cfg)
    ax[0].set_xlabel("offered load (% of each profile's rate)"); ax[0].set_ylabel("mean latency (cycles)")
    ax[0].set_title("Latency vs load (die workload)"); ax[0].legend(fontsize=8)
    ax[1].set_xlabel("offered load (%)"); ax[1].set_ylabel("GB/s (cycles x estimated clock)")
    ax[1].set_title("Delivered bandwidth in time units"); ax[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(REP, "img", "bench_latency_load.png"), dpi=120); plt.close(fig)
    d = g(rows, "E1_hpc_evidence_l1000")["d"]
    fig, ax = plt.subplots(figsize=(11, 3.6))
    names = MNAMES + TNAMES
    vals = d["mlink_util"] + d["tlink_util"]
    ax.bar(range(len(names)), vals, color=["#c0392b"] * NM + ["#1f618d"] * NT)
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=60, fontsize=8)
    ax.set_ylabel("request transfers / cycle"); ax.set_ylim(0, 1)
    ax.set_title("Link utilisation, evidence configuration, die workload at full load (red: master links, blue: target links)")
    fig.tight_layout(); fig.savefig(os.path.join(REP, "img", "bench_link_util.png"), dpi=120); plt.close(fig)


if __name__ == "__main__":
    main()
