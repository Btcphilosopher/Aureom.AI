#!/usr/bin/env python3
"""SilicaFlux NoC Spine -- floorplan / fabric configuration generator.

Reads config/silicaflux_floorplan.yaml, validates it and writes
  rtl/cfg/sfs_cfg_pkg.sv                 SystemVerilog configuration package
  reports/connectivity.json / .dot / .md connectivity graph with conceptual distances
  reports/img/connectivity.png           floorplan + spine + attachment links

Register stages per link come from reports/placement.json (scripts/placement.py, which
needs the synthesis delays of scripts/synth.py).  Without it the package is written
with the single-central-stage configuration only and a note.

Validation rules (each violation is an error, exit 1):
  V1 regions inside the die, no overlapping regions
  V2 every attachment point on (or inside) the boundary of its region
  V3 target windows: size a power of two, base aligned, no overlap, unmapped probe unmapped
  V4 access-matrix classes exist; every master reaches at least one target
  V5 maxo / maxo_spine within 1..maxo_max; port counts within the RTL limits (NM <= 32, NT <= 64)
"""
import json, math, os, sys
import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CFG = os.path.join(ROOT, "config", "silicaflux_floorplan.yaml")
REP = os.path.join(ROOT, "reports")


def load(path=CFG):
    with open(path) as f:
        return yaml.safe_load(f)


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def validate(c):
    err = []
    W, H = c["die"]["w"], c["die"]["h"]
    regs = c["regions"]
    for n, r in regs.items():
        if not (0 <= r["x0"] < r["x1"] <= W and 0 <= r["y0"] < r["y1"] <= H):
            err.append(f"V1 region {n} outside the die or empty")
    names = list(regs)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            ra, rb = regs[a], regs[b]
            if ra["x0"] < rb["x1"] and rb["x0"] < ra["x1"] and ra["y0"] < rb["y1"] and rb["y0"] < ra["y1"]:
                err.append(f"V1 regions {a} and {b} overlap")
    tol = 0.05
    for p in c["masters"] + c["targets"]:
        r = regs.get(p["region"])
        if r is None:
            err.append(f"V2 {p['name']}: unknown region {p['region']}")
            continue
        x, y = p["attach"]
        if not (r["x0"] - tol <= x <= r["x1"] + tol and r["y0"] - tol <= y <= r["y1"] + tol):
            err.append(f"V2 {p['name']}: attachment point {p['attach']} not on region {p['region']}")
    ts = c["targets"]
    for t in ts:
        s, b = t["size"], t["base"]
        if s & (s - 1):
            err.append(f"V3 {t['name']}: size {s:#x} not a power of two")
        if b & (s - 1):
            err.append(f"V3 {t['name']}: base {b:#x} not aligned to its size")
    for i, a in enumerate(ts):
        for bb in ts[i + 1:]:
            if a["base"] < bb["base"] + bb["size"] and bb["base"] < a["base"] + a["size"]:
                err.append(f"V3 windows {a['name']} and {bb['name']} overlap")
    u = c["unmapped_probe"]
    for t in ts:
        if t["base"] <= u < t["base"] + t["size"]:
            err.append(f"V3 unmapped probe {u:#x} falls into {t['name']}")
    tcls = {t["cls"] for t in ts}
    for mc, lst in c["access"].items():
        for tc in lst:
            if tc not in tcls:
                err.append(f"V4 access {mc} -> unknown target class {tc}")
    for m in c["masters"]:
        if not c["access"].get(m["cls"]):
            err.append(f"V4 master {m['name']} reaches no target")
        for k in ("maxo", "maxo_spine"):
            if not 1 <= m[k] <= c["fabric"]["maxo_max"]:
                err.append(f"V5 {m['name']}.{k}={m[k]} outside 1..maxo_max")
    if len(c["masters"]) > 32 or len(ts) > 64:
        err.append("V5 port counts beyond the RTL limits")
    return err


def model(c):
    """Ports, distances and the connectivity graph."""
    cen = (c["spine"]["central"]["x"], c["spine"]["central"]["y"])
    det = c["timing"]["route_detour"]
    ms, ts = c["masters"], c["targets"]
    for p in ms + ts:
        p["manhattan_mm"] = round(manhattan(p["attach"], cen), 3)
        p["route_mm"] = round(p["manhattan_mm"] * det, 3)
    edges = []
    for i, m in enumerate(ms):
        for j, t in enumerate(ts):
            if t["cls"] in c["access"][m["cls"]]:
                edges.append(dict(m=i, t=j, master=m["name"], target=t["name"],
                                  path_mm=round(m["route_mm"] + t["route_mm"], 3),
                                  direct_mm=round(manhattan(m["attach"], t["attach"]) * det, 3)))
    return cen, edges


def mesh_place(c, mx=4, my=3):
    """Registered multistage alternative (P22 sfn_mesh): MX x MY routers spread over the die,
    node index y*MX + x (y = 0 at the top edge, P22 convention N = y-1).  Each port goes to the
    nearest free node (one master and one target per node, the sfn_mesh rule), greedy by distance."""
    W, H = c["die"]["w"], c["die"]["h"]
    nodes = [((x + 0.5) * W / mx, H - (y + 0.5) * H / my) for y in range(my) for x in range(mx)]
    def assign(ports):
        pairs = sorted((manhattan(p["attach"], nodes[n]), i, n) for i, p in enumerate(ports) for n in range(len(nodes)))
        got, used = {}, set()
        for d, i, n in pairs:
            if i in got or n in used:
                continue
            got[i] = n
            used.add(n)
        a = [got[i] for i in range(len(ports))]
        # local improvement: swap two ports' nodes or move a port to a free node while the total shrinks
        cost = lambda i, n: manhattan(ports[i]["attach"], nodes[n])
        improved = True
        while improved:
            improved = False
            for i in range(len(ports)):
                for n in range(len(nodes)):
                    if n == a[i]:
                        continue
                    if n in a:
                        j = a.index(n)
                        if cost(i, n) + cost(j, a[i]) + 1e-9 < cost(i, a[i]) + cost(j, n):
                            a[i], a[j] = n, a[i]
                            improved = True
                    elif cost(i, n) + 1e-9 < cost(i, a[i]):
                        a[i] = n
                        improved = True
        return a
    return dict(mx=mx, my=my, nodes=nodes, mst=assign(c["masters"]), tgt=assign(c["targets"]),
                pitch_mm=[W / mx, H / my])


def sv_vec(vals, w):
    """Packed SV literal, element 0 in the least significant position."""
    n = len(vals)
    hexw = (w + 3) // 4
    body = "".join(f"{v:0{hexw}x}" for v in reversed(vals)) if w % 4 == 0 else None
    if body is None:
        bits = "".join(format(v, f"0{w}b") for v in reversed(vals))
        return f"{n * w}'b{bits}"
    return f"{n * w}'h{body}"


def write_pkg(c, edges, pipes):
    ms, ts = c["masters"], c["targets"]
    NM, NT = len(ms), len(ts)
    AW = c["fabric"]["aw"]
    base = [t["base"] for t in ts]
    mask = [((1 << AW) - 1) & ~(t["size"] - 1) for t in ts]
    en = []
    for m in ms:
        for t in ts:
            en.append(1 if t["cls"] in c["access"][m["cls"]] else 0)
    # bit m*NT+t: element order m-major -> build LSB-first list
    en_bits = "".join(str(b) for b in reversed(en))
    qmap = {"DMA": 0, "TENSOR": 1, "VECTOR": 2, "CTRL": 3, "EVENT": 4}
    L = []
    L.append("// =============================================================================")
    L.append("// SilicaFlux NoC Spine (Project 34) :: sfs_cfg_pkg -- GENERATED, do not edit")
    L.append(f"// Source: config/silicaflux_floorplan.yaml ({c['name']}) by scripts/gen_cfg.py")
    L.append("// Port order = P31 SILICAFLUX_HPC: masters " + " ".join(m["name"] for m in ms))
    L.append("//                                    targets " + " ".join(t["name"] for t in ts))
    L.append("// Distances are CONCEPTUAL (floorplan illustration), in micrometres, Manhattan x route_detour.")
    L.append("// =============================================================================")
    L.append("package sfs_cfg_pkg;")
    L.append("  /* verilator lint_off UNUSEDPARAM */")
    L.append(f"  localparam int NM = {NM};")
    L.append(f"  localparam int NT = {NT};")
    L.append(f"  localparam int AW = {AW};")
    L.append(f"  localparam int DW = {c['fabric']['dw']};")
    L.append(f"  localparam int IDW = {c['fabric']['idw']};")
    L.append(f"  localparam int MAXO_MAX = {c['fabric']['maxo_max']};")
    L.append(f"  localparam int BUF_DEPTH = {c['fabric']['buf_depth']};")
    L.append(f"  localparam int STARVE = {c['fabric']['starve']};")
    L.append(f"  localparam int ARB_MODE = {c['fabric']['arb_mode']};")
    L.append(f"  localparam int TC_MODE = {c['fabric']['tc_mode']};")
    L.append(f"  localparam logic [AW-1:0] UNMAPPED = {AW}'h{c['unmapped_probe']:08x};")
    L.append(f"  localparam logic [NT*AW-1:0] TGT_BASE = {sv_vec(base, AW)};")
    L.append(f"  localparam logic [NT*AW-1:0] TGT_MASK = {sv_vec(mask, AW)};")
    L.append(f"  localparam logic [NM*NT-1:0] MST_TGT_EN = {NM * NT}'b{en_bits};")
    L.append(f"  localparam logic [NM*8-1:0] MST_MAXO_P31 = {sv_vec([m['maxo'] for m in ms], 8)};")
    L.append(f"  localparam logic [NM*8-1:0] MST_MAXO_SPINE = {sv_vec([m['maxo_spine'] for m in ms], 8)};")
    L.append(f"  localparam logic [NM-1:0] MST_CTRL = {sv_vec([m['ctrl'] for m in ms], 1)};")
    L.append(f"  localparam logic [NT-1:0] TGT_MMIO = {sv_vec([t['mmio'] for t in ts], 1)};")
    L.append(f"  localparam logic [NM*3-1:0] MST_QOS = {sv_vec([qmap[m['qos']] for m in ms], 3)};")
    L.append(f"  localparam logic [NT*16-1:0] TGT_LAT_MIN = {sv_vec([t['lat'][0] for t in ts], 16)};")
    L.append(f"  localparam logic [NT*16-1:0] TGT_LAT_MAX = {sv_vec([t['lat'][1] for t in ts], 16)};")
    L.append(f"  localparam logic [NM*32-1:0] MST_DIST_UM = {sv_vec([int(round(m['route_mm'] * 1000)) for m in ms], 32)};")
    L.append(f"  localparam logic [NT*32-1:0] TGT_DIST_UM = {sv_vec([int(round(t['route_mm'] * 1000)) for t in ts], 32)};")
    prof = {"cc_mmio": 0, "host": 1, "dma_write": 2, "vec_spm": 3, "tensor_load": 4}
    L.append("  // workload profile per master (tb/sfs_tb_master): 0 cc_mmio 1 host 2 dma_write 3 vec_spm 4 tensor_load")
    L.append(f"  localparam logic [NM*4-1:0] MST_PROFILE = {sv_vec([prof[m['profile']] for m in ms], 4)};")
    tcls = {"SRAM": 0, "SPM": 1, "REGS": 2, "EXT": 3, "EXTCSR": 4}
    L.append("  // target class: 0 SRAM 1 SPM 2 REGS 3 EXT 4 EXTCSR")
    L.append(f"  localparam logic [NT*4-1:0] TGT_CLASS = {sv_vec([tcls[t['cls']] for t in ts], 4)};")
    mp = mesh_place(c)
    L.append(f"  // ---- registered multistage alternative: P22 sfn_mesh {mp['mx']}x{mp['my']}, nearest-node placement")
    L.append(f"  localparam int MESH_X = {mp['mx']};")
    L.append(f"  localparam int MESH_Y = {mp['my']};")
    L.append(f"  localparam logic [NM*8-1:0] MESH_MST_NODE = {sv_vec(mp['mst'], 8)};")
    L.append(f"  localparam logic [NT*8-1:0] MESH_TGT_NODE = {sv_vec(mp['tgt'], 8)};")
    L.append("  // ---- register stages per link direction (scripts/placement.py)")
    for name, (mpp, tp, why) in pipes.items():
        L.append(f"  // {name}: {why}")
        L.append(f"  localparam logic [NM*4-1:0] MST_PIPE_{name.upper()} = {sv_vec(mpp, 4)};")
        L.append(f"  localparam logic [NT*4-1:0] TGT_PIPE_{name.upper()} = {sv_vec(tp, 4)};")
    L.append("  /* verilator lint_on UNUSEDPARAM */")
    L.append("endpackage")
    os.makedirs(os.path.join(ROOT, "rtl", "cfg"), exist_ok=True)
    path = os.path.join(ROOT, "rtl", "cfg", "sfs_cfg_pkg.sv")
    txt = "\n".join(L) + "\n"
    if not os.path.exists(path) or open(path).read() != txt:      # write only on change (build caches use mtimes)
        with open(path, "w") as f:
            f.write(txt)


def draw(c, cen, edges, pipes, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    colors = {"control": "#d8b45a", "io": "#8fa3c8", "security": "#d8b45a", "ras": "#d8b45a", "test": "#d8b45a",
              "vector": "#5fc4c4", "tensor": "#a77de0", "sram": "#7fd8c8", "shared_mem": "#7fd8c8", "dma": "#5fc4c4",
              "extmem": "#8fa3c8", "power": "#e0cf8f"}
    fig, ax = plt.subplots(figsize=(11, 9.6))
    W, H = c["die"]["w"], c["die"]["h"]
    ax.add_patch(Rectangle((0, 0), W, H, fill=False, lw=1.5, ec="#444"))
    for n, r in c["regions"].items():
        ax.add_patch(Rectangle((r["x0"], r["y0"]), r["x1"] - r["x0"], r["y1"] - r["y0"],
                               fc=colors.get(r["kind"], "#ccc"), ec="#555", lw=0.6, alpha=0.55))
        ax.text((r["x0"] + r["x1"]) / 2, r["y1"] - 0.35, n, ha="center", va="top", fontsize=7, color="#222")
    sc = c["spine"]["corridor"]
    ax.add_patch(Rectangle((sc["x0"], sc["y0"]), sc["x1"] - sc["x0"], sc["y1"] - sc["y0"], fc="#bbbbbb", ec="#666",
                           hatch="///", alpha=0.5))
    ax.text(sc["x0"] + 0.2, sc["y1"] + 0.05, "DataFabric NoC spine", fontsize=7, va="bottom")
    evid = pipes.get("evidence", pipes.get("single"))
    allp = c["masters"] + c["targets"]
    for k, p in enumerate(allp):
        is_m = k < len(c["masters"])
        x, y = p["attach"]
        col = "#c0392b" if is_m else "#1f618d"
        st = (evid[0][k] if is_m else evid[1][k - len(c["masters"])]) if evid else 0
        ax.plot([x, x, cen[0]], [y, cen[1], cen[1]], color=col, lw=0.9, alpha=0.75)
        ax.plot([x], [y], marker="o" if is_m else "s", color=col, ms=5)
        # neighbours closer than 1.5 mm on the same edge: alternate the label height
        near = [j for j, q in enumerate(allp) if j < k and abs(q["attach"][1] - y) < 0.3 and abs(q["attach"][0] - x) < 1.5]
        dy = (0.25 if y > cen[1] else -0.45) + (0.0 if not near else (0.9 if y > cen[1] else -0.9))
        ax.text(x + 0.12, y + dy, f"{p['name']}\n{p['route_mm']:.1f} mm" + (f", {st} st" if st else ""), fontsize=6, color=col)
    ax.plot([cen[0]], [cen[1]], marker="D", color="black", ms=9)
    ax.text(cen[0] + 0.25, cen[1] - 0.75, "central routing stage", fontsize=7)
    ax.set_xlim(-0.5, W + 0.5)
    ax.set_ylim(-0.5, H + 0.5)
    ax.set_aspect("equal")
    ax.set_xlabel("x (mm, conceptual)")
    ax.set_ylabel("y (mm, conceptual)")
    ax.set_title("SilicaFlux NoC spine: attachment links on the conceptual die floorplan\n"
                 "(red = master nodes, blue = target nodes; route = Manhattan x detour; st = register stages)",
                 fontsize=9)
    fig.tight_layout()
    fig.savefig(out, dpi=130)
    plt.close(fig)


def main():
    c = load()
    err = validate(c)
    if err:
        for e in err:
            print("ERROR", e)
        sys.exit(1)
    cen, edges = model(c)
    ms, ts = c["masters"], c["targets"]
    NM, NT = len(ms), len(ts)
    pipes = {"single": ([0] * NM, [0] * NT, "one central routing stage, no link registers (starting point)")}
    pj = os.path.join(REP, "placement.json")
    if os.path.exists(pj):
        p = json.load(open(pj))
        for name, cfg in p["configs"].items():
            pipes[name] = (cfg["mst_pipe"], cfg["tgt_pipe"], cfg["why"])
    else:
        print("note: reports/placement.json not found -- EVIDENCE / DEEP are PLACEHOLDERS (run scripts/placement.py)")
        pipes["evidence"] = ([1] * NM, [1] * NT, "PLACEHOLDER: scripts/placement.py has not been run")
        pipes["deep"] = ([2] * NM, [2] * NT, "PLACEHOLDER: scripts/placement.py has not been run")
    write_pkg(c, edges, pipes)
    os.makedirs(os.path.join(REP, "img"), exist_ok=True)
    mp = mesh_place(c)
    graph = dict(mesh=dict(mx=mp["mx"], my=mp["my"], nodes=mp["nodes"], mst_node=mp["mst"], tgt_node=mp["tgt"],
                           pitch_mm=mp["pitch_mm"]),
                 name=c["name"], source_floorplan=c["source_floorplan"], die_mm=c["die"],
                 central=dict(x=cen[0], y=cen[1]), route_detour=c["timing"]["route_detour"],
                 nodes=[dict(kind="master", index=i, name=m["name"], region=m["region"], attach=m["attach"],
                             manhattan_mm=m["manhattan_mm"], route_mm=m["route_mm"]) for i, m in enumerate(ms)] +
                       [dict(kind="target", index=j, name=t["name"], region=t["region"], attach=t["attach"],
                             manhattan_mm=t["manhattan_mm"], route_mm=t["route_mm"],
                             window=[hex(t["base"]), hex(t["base"] + t["size"] - 1)]) for j, t in enumerate(ts)],
                 edges=edges,
                 pipes={k: dict(mst_pipe=v[0], tgt_pipe=v[1], why=v[2]) for k, v in pipes.items()})
    json.dump(graph, open(os.path.join(REP, "connectivity.json"), "w"), indent=1)
    # DOT
    D = ["digraph spine {", "  graph [layout=neato, overlap=false, splines=true];",
         f'  central [label="central routing stage\\n(sfn_xbar)", shape=box, pos="{cen[0]},{cen[1]}!"];']
    for m in ms:
        D.append(f'  {m["name"]} [label="{m["name"]}\\n{m["region"]}", shape=ellipse, color=red, '
                 f'pos="{m["attach"][0]},{m["attach"][1]}!"];')
        D.append(f'  {m["name"]} -> central [label="{m["route_mm"]:.1f} mm"];')
    for t in ts:
        D.append(f'  {t["name"]} [label="{t["name"]}\\n{t["region"]}", shape=box, color=blue, '
                 f'pos="{t["attach"][0]},{t["attach"][1]}!"];')
        D.append(f'  central -> {t["name"]} [label="{t["route_mm"]:.1f} mm"];')
    D.append("  // logical connectivity (access matrix)")
    for e in edges:
        D.append(f'  {e["master"]} -> {e["target"]} [style=dotted, constraint=false, color=gray];')
    D.append("}")
    open(os.path.join(REP, "connectivity.dot"), "w").write("\n".join(D) + "\n")
    # Markdown
    M = ["# Connectivity graph (generated by scripts/gen_cfg.py)", "",
         f"Source: `config/silicaflux_floorplan.yaml`, floorplan illustration `{c['source_floorplan']}` "
         f"({c['die']['w']} mm x {c['die']['h']} mm). **Conceptual coordinates**: route length = Manhattan distance "
         f"between the attachment point and the central routing stage x {c['timing']['route_detour']} (assumed detour). "
         "No placement or routing exists; see docs/PHYSICAL.md.", "",
         f"Central routing stage at ({cen[0]}, {cen[1]}) mm.", "",
         "## Attachment nodes", "", "| Port | Kind | Region | Attach (mm) | Manhattan (mm) | Route (mm) |",
         "|---|---|---|---|---|---|"]
    for m in ms:
        M.append(f"| {m['name']} | master | {m['region']} | ({m['attach'][0]}, {m['attach'][1]}) | {m['manhattan_mm']:.2f} | {m['route_mm']:.2f} |")
    for t in ts:
        M.append(f"| {t['name']} | target | {t['region']} | ({t['attach'][0]}, {t['attach'][1]}) | {t['manhattan_mm']:.2f} | {t['route_mm']:.2f} |")
    M += ["", f"## Logical connections (access matrix): {len(edges)} master-target pairs", "",
          "Path = master link + target link through the central stage; direct = Manhattan between the two attachment "
          "points (what a point-to-point wire would need).", "",
          "| Master | Targets (path mm / direct mm) |", "|---|---|"]
    for i, m in enumerate(ms):
        cells = [f"{e['target']} {e['path_mm']:.1f}/{e['direct_mm']:.1f}" for e in edges if e["m"] == i]
        M.append(f"| {m['name']} | {', '.join(cells)} |")
    lm = max(edges, key=lambda e: e["path_mm"])
    M += ["", f"Longest path: {lm['master']} -> {lm['target']} = {lm['path_mm']:.1f} mm. "
          f"Total link length (one direction, all {NM + NT} links): "
          f"{sum(p['route_mm'] for p in ms + ts):.1f} mm.", "", "![connectivity](img/connectivity.png)", ""]
    open(os.path.join(REP, "connectivity.md"), "w").write("\n".join(M))
    try:
        draw(c, cen, edges, pipes, os.path.join(REP, "img", "connectivity.png"))
    except ImportError:
        print("note: matplotlib not available -- PNG not drawn")
    print(f"ok: {NM} masters, {NT} targets, {len(edges)} connections, pipeline configs: {', '.join(pipes)}")


if __name__ == "__main__":
    main()
