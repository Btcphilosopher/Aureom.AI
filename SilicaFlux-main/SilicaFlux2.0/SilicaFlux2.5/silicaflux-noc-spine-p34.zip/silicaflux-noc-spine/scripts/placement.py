#!/usr/bin/env python3
"""SilicaFlux NoC Spine -- placement-aware link pipelining.

"Start with one central routing stage; add physical pipelining based on timing evidence."

Inputs (all recorded in reports/placement.json):
  * TOOL RESULTS (reports/synth.json, scripts/synth.py): ABC static timing of the sky130 HD
    mapped logic of the master attachment node (sfs_mnode, 1 stage), one link register stage
    (sfn_fifo), and the central routing stage (sfn_xbar 10x11) -- no wires.
  * LIBERTY (sky130_fd_sc_hd TT 1.80 V 25 C): flop clk->Q and setup; repeater (buffer) input
    capacitance, intrinsic delay and drive resistance, fitted from the NLDM tables.
  * LAYER RC (OpenROAD-flow-scripts sky130hd setRC.tcl): met4 / met5 r and c per um.
  * CONCEPTUAL DISTANCES (reports/connectivity.json): Manhattan x detour, from the floorplan
    illustration.  No placement, routing or extraction exists -- the wire part is an ESTIMATE.

Model (docs/PHYSICAL.md sec. 3):
  repeated wire: Elmore delay of a buffer-driven segment l,
      t(l) = d0 + Rd (c l + Cin) + 0.38 r c l^2 + 0.69 r l Cin,
  minimised per mm over l and the buffer size -> v ps/mm.
  A link with P >= 1 stages has its last stage AT the central stage (the central routing logic
  is the longest logic path, so no wire is put in series with it); the other P-1 stages are
  spaced along the wire.  Segment budget: T (1 - margin) - (clk->Q + setup) - logic.
  P = 0 puts node logic, both wires and the central logic in one cycle.

Outputs: reports/placement.{json,md}; configurations `evidence` (stages required at the clock
the central stage allows) and `deep` (a stated sensitivity point, reach 4 mm per cycle) are
picked up by scripts/gen_cfg.py.
"""
import itertools, json, math, os, re, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
REP = os.path.join(ROOT, "reports")
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import gen_cfg  # noqa: E402

LIB = os.environ.get("SKY130_LIB", "/opt/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib")


# ---------------------------------------------------------------- liberty helpers
def lib_cell(txt, name):
    i = txt.index(f'cell ("{name}")')
    depth, j = 0, txt.index("{", i)
    for k in range(j, len(txt)):
        if txt[k] == "{":
            depth += 1
        elif txt[k] == "}":
            depth -= 1
            if depth == 0:
                return txt[i:k + 1]
    raise ValueError(name)


def block(txt, head):
    """All { } blocks whose header matches the regex `head`."""
    out = []
    for m in re.finditer(head, txt):
        j = txt.index("{", m.end() - 1)
        depth = 0
        for k in range(j, len(txt)):
            if txt[k] == "{":
                depth += 1
            elif txt[k] == "}":
                depth -= 1
                if depth == 0:
                    out.append(txt[m.start():k + 1])
                    break
    return out


def table(tb):
    i1 = [float(x) for x in re.search(r'index_1\s*\(\s*"([^"]+)"', tb).group(1).split(",")]
    i2m = re.search(r'index_2\s*\(\s*"([^"]+)"', tb)
    i2 = [float(x) for x in i2m.group(1).split(",")] if i2m else [0.0]
    vals = re.search(r'values\s*\((.*?)\)\s*;', tb, re.S).group(1)
    rows = [[float(x) for x in r.split(",")] for r in re.findall(r'"([^"]+)"', vals)]
    return i1, i2, rows


def buf_model(txt, name, slew=0.1):
    """d0 (ns) and Rd (kOhm = ns/pF) from a linear fit of the rise/fall delay over load at the
    input-slew index nearest `slew`; Cin (pF) of pin A."""
    cell = lib_cell(txt, name)
    pa = block(cell, r'pin\s*\(\s*"A"\s*\)\s*\{')[0]
    cin = float(re.search(r"\bcapacitance\s*:\s*([\d.eE+-]+)", pa).group(1))
    px = block(cell, r'pin\s*\(\s*"X"\s*\)\s*\{')[0]
    fits = []
    for kind in ("cell_rise", "cell_fall"):
        tb = block(px, kind + r'\s*\([^)]*\)\s*\{')[0]
        i1, i2, rows = table(tb)
        r = min(range(len(i1)), key=lambda k: abs(i1[k] - slew))
        xs, ys = i2[:5], rows[r][:5]              # light-to-moderate loads: the repeater regime
        n = len(xs)
        mx, my = sum(xs) / n, sum(ys) / n
        rd = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
        fits.append((my - rd * mx, rd))
    d0 = sum(f[0] for f in fits) / 2
    rd = sum(f[1] for f in fits) / 2
    return dict(cell=name, cin_pf=cin, d0_ns=d0, rd_kohm=rd)


def ff_model(txt, name):
    cell = lib_cell(txt, name)
    pq = block(cell, r'pin\s*\(\s*"Q"\s*\)\s*\{')[0]
    vals = []
    for kind in ("cell_rise", "cell_fall"):
        i1, i2, rows = table(block(pq, kind + r'\s*\([^)]*\)\s*\{')[0])
        r = min(range(len(i1)), key=lambda k: abs(i1[k] - 0.1))
        c = min(range(len(i2)), key=lambda k: abs(i2[k] - 0.01))
        vals.append(rows[r][c])
    clkq = max(vals)
    pd = block(cell, r'pin\s*\(\s*"D"\s*\)\s*\{')[0]
    setup = 0.0
    for t in block(pd, r'timing\s*\(\s*\)\s*\{'):
        if "setup_rising" in t:
            for kind in ("rise_constraint", "fall_constraint"):
                b = block(t, kind + r'\s*\([^)]*\)\s*\{')
                if b:
                    i1, i2, rows = table(b[0])
                    r = min(range(len(i1)), key=lambda k: abs(i1[k] - 0.1))
                    c = min(range(len(i2)), key=lambda k: abs(i2[k] - 0.1))
                    setup = max(setup, rows[r][c])
    return dict(cell=name, clk_to_q_ns=clkq, setup_ns=setup)


def repeated_wire(bufs, r_kohm_per_mm, c_pf_per_mm):
    """Best ps/mm over buffer types and segment lengths (Elmore, 50 % points)."""
    best = None
    for b in bufs:
        for i in range(1, 1200):
            l = i * 0.025                        # mm
            t = (b["d0_ns"] + b["rd_kohm"] * (c_pf_per_mm * l + b["cin_pf"]) +
                 0.38 * r_kohm_per_mm * c_pf_per_mm * l * l + 0.69 * r_kohm_per_mm * l * b["cin_pf"])
            v = t / l * 1000.0                   # ps / mm
            if best is None or v < best["ps_per_mm"]:
                best = dict(ps_per_mm=v, seg_mm=l, cell=b["cell"])
    return best


# ---------------------------------------------------------------- stage model
def stages_for(L, reach_first, reach_mid):
    """Minimum P >= 1 so that a link of length L fits: the first segment (from the logic at the
    far end) reaches reach_first, every further segment reach_mid."""
    if L <= reach_first:
        return 1
    if reach_mid <= 0:
        return None
    return 1 + math.ceil((L - reach_first) / reach_mid - 1e-9)


def main():
    c = gen_cfg.load()
    cen, edges = gen_cfg.model(c)
    ms, ts = c["masters"], c["targets"]
    NM, NT = len(ms), len(ts)
    syn = json.load(open(os.path.join(REP, "synth.json")))
    need = ["c_mnode_p1", "c_link_stage", "c_xbar_qos", "c_xbar_qos_fast", "c_xbar_rr", "c_mst_port", "c_tc_map"]
    for n in need:
        if not syn.get(n, {}).get("sky130", {}).get("ok"):
            sys.exit(f"reports/synth.json lacks a sky130 result for {n}: run scripts/synth.py components")
    d = lambda n: syn[n]["sky130"]["abc_delay_ps"]
    # central stage = sfs_xbar (QoS, parallel-level arbiter, proved equal to P22's sfn_xbar)
    t_node, t_stage, t_xbar, t_xbar_rr = d("c_mnode_p1"), d("c_link_stage"), d("c_xbar_qos_fast"), d("c_xbar_rr")
    t_xbar_p22 = d("c_xbar_qos")

    txt = open(LIB).read()
    tm = c["timing"]
    bufs = [buf_model(txt, b) for b in tm["repeater_cells"]]
    ff = ff_model(txt, tm["ff_cell"])
    t_ff = (ff["clk_to_q_ns"] + ff["setup_ns"]) * 1000.0
    wires = {}
    for layer, rc in tm["layer_rc"].items():
        r = rc["r_kohm_per_um"] * 1000.0          # kOhm / mm
        cc = rc["c_pf_per_um"] * 1000.0           # pF / mm
        w = repeated_wire(bufs, r, cc)
        w.update(r_ohm_per_mm=r * 1000.0, c_ff_per_mm=cc * 1000.0)
        wires[layer] = w
    v = wires[tm["wire_layer"]]["ps_per_mm"]
    margin = tm["clock_margin"]
    Lm = [m["route_mm"] for m in ms]
    Lt = [t["route_mm"] for t in ts]
    pairs = [(e["m"], e["t"]) for e in edges]

    def period_for(logic_ps):
        return (logic_ps + t_ff) / (1.0 - margin)

    # ---- (1) single central routing stage, no link registers: one cycle from master node to target
    def single_path(m, t):
        return t_node + v * (Lm[m] + Lt[t]) + t_xbar
    worst = max(pairs, key=lambda p: single_path(*p))
    T_single = period_for(single_path(*worst))
    T_single_nowire = period_for(t_node + t_xbar)
    # ---- (2) every link registered at the central stage: the central stage alone limits the clock
    T_central = period_for(t_stage + t_xbar)
    T_ev = math.ceil(T_central / 100.0) * 100.0  # chosen clock: next 0.1 ns above the central-stage limit
    budget = T_ev * (1 - margin) - t_ff
    reach_node = (budget - t_node) / v
    reach_mid = (budget - t_stage) / v
    mp_ev = [stages_for(L, reach_node, reach_mid) for L in Lm]
    tp_ev = [stages_for(L, reach_mid, reach_mid) for L in Lt]

    # ---- (3) selective pipelining between the two limits: minimum number of registered links
    # (one stage at the central stage) for a clock T, exhaustive over link subsets (numpy-free bit search)
    def feasible(T, regm, regt):
        bud = T * (1 - margin) - t_ff
        for m, t in pairs:
            rm, rt = (regm >> m) & 1, (regt >> t) & 1
            if not rm and not rt:
                if t_node + v * (Lm[m] + Lt[t]) + t_xbar > bud: return False
            elif rm and not rt:
                if t_node + v * Lm[m] > bud or t_stage + t_xbar + v * Lt[t] > bud: return False
            elif rt and not rm:
                if t_node + v * Lm[m] + t_xbar > bud or t_stage + v * Lt[t] > bud: return False
            else:
                if t_node + v * Lm[m] > bud or t_stage + t_xbar > bud or t_stage + v * Lt[t] > bud: return False
        return True

    def min_cover(T):
        nl = NM + NT
        for k in range(0, nl + 1):
            best = None
            for comb in itertools.combinations(range(nl), k):
                regm = sum(1 << i for i in comb if i < NM)
                regt = sum(1 << (i - NM) for i in comb if i >= NM)
                if feasible(T, regm, regt):
                    # tie-break: fewest registered request+response stages on frequently used links
                    best = (regm, regt)
                    break
            if best:
                return k, best
            if k > 6:          # beyond 6 links the search grows; report as "all" region
                return None, None
        return None, None

    pareto = []
    steps = sorted(set([round(T_single, -1)] + [round(T_central + i * (T_single - T_central) / 8, -1) for i in range(9)]),
                   reverse=True)
    for T in steps:
        k, sel = min_cover(T)
        if k is None:
            pareto.append(dict(period_ps=T, mhz=round(1e6 / T, 1), registered_links="> 6 (all links: evidence configuration)"))
        else:
            regm, regt = sel
            pareto.append(dict(period_ps=T, mhz=round(1e6 / T, 1), registered_links=k,
                               links=[ms[i]["name"] for i in range(NM) if regm >> i & 1] +
                                     [ts[j]["name"] for j in range(NT) if regt >> j & 1]))

    # ---- (4) sensitivity: required stages vs reach per cycle (technology / clock independent view)
    sens = []
    for R in (2.0, 3.0, 4.0, 6.0, 8.0, 12.0, 20.0, 40.0):
        mp = [max(1, math.ceil(L / R - 1e-9)) for L in Lm]
        tp = [max(1, math.ceil(L / R - 1e-9)) for L in Lt]
        sens.append(dict(reach_mm=R, max_stages=max(mp + tp), link_registers=2 * (sum(mp) + sum(tp)),
                         worst_pair_added_rtt=max(2 * (mp[m] + tp[t]) for m, t in pairs),
                         mst_pipe=mp, tgt_pipe=tp))
    R_deep = 4.0
    deep = next(s for s in sens if s["reach_mm"] == R_deep)

    configs = {
        "evidence": dict(mst_pipe=mp_ev, tgt_pipe=tp_ev,
                         why=f"sky130 evidence: clock {T_ev / 1000:.1f} ns set by the central stage; stages so every "
                             f"segment fits (reach {reach_node:.1f} mm from a node, {reach_mid:.1f} mm between stages)"),
        "deep": dict(mst_pipe=deep["mst_pipe"], tgt_pipe=deep["tgt_pipe"],
                     why=f"SENSITIVITY point, not a timing result: reach {R_deep:.0f} mm per cycle (e.g. a faster "
                         "process or clock); measures the latency / buffering cost of multi-stage links"),
    }
    # round trip (cycles added by link registers, request + response) for the evidence config
    res = dict(
        inputs=dict(liberty=os.path.basename(LIB), t_node_ps=t_node, t_stage_ps=t_stage, t_xbar_qos_ps=t_xbar,
                    t_xbar_qos_p22_ps=t_xbar_p22,
                    t_xbar_rr_ps=t_xbar_rr, t_mst_port_ps=d("c_mst_port"), t_tc_map_ps=d("c_tc_map"),
                    flop=ff, t_ff_ps=t_ff, repeaters=bufs, wires=wires, wire_layer=tm["wire_layer"],
                    v_ps_per_mm=v, clock_margin=margin, route_detour=tm["route_detour"]),
        single=dict(period_ps=T_single, mhz=1e6 / T_single, worst_pair=[ms[worst[0]]["name"], ts[worst[1]]["name"]],
                    worst_path_mm=Lm[worst[0]] + Lt[worst[1]], period_without_wires_ps=T_single_nowire),
        central_limit=dict(period_ps=T_central, mhz=1e6 / T_central),
        evidence=dict(period_ps=T_ev, mhz=1e6 / T_ev, reach_node_mm=reach_node, reach_mid_mm=reach_mid,
                      mst_pipe=mp_ev, tgt_pipe=tp_ev,
                      link_registers=2 * (sum(mp_ev) + sum(tp_ev)),
                      added_rtt_cycles=dict((f"{ms[m]['name']}->{ts[t]['name']}", 2 * (mp_ev[m] + tp_ev[t])) for m, t in pairs)),
        pareto=pareto, sensitivity=sens, configs=configs,
        note="Synthesis-level evidence (ABC on sky130 HD, no wires) + repeated-wire ESTIMATE on conceptual distances. "
             "No placement, routing, extraction or sign-off STA was run.")
    json.dump(res, open(os.path.join(REP, "placement.json"), "w"), indent=1)
    write_md(c, res)
    print(f"single-stage: {T_single / 1000:.2f} ns ({1e6 / T_single:.1f} MHz), central limit {T_central / 1000:.2f} ns, "
          f"evidence clock {T_ev / 1000:.1f} ns: mst {mp_ev} tgt {tp_ev}; wire {v:.0f} ps/mm on {tm['wire_layer']}")


def write_md(c, r):
    ms, ts = c["masters"], c["targets"]
    i = r["inputs"]
    L = ["# Placement-aware pipelining (generated by scripts/placement.py)", "",
         "> **Evidence class.** Logic delays are tool results (ABC static timing after Yosys synthesis to the "
         "SkyWater sky130_fd_sc_hd TT 1.80 V 25 C liberty, no wires). Flop and buffer data are read from the same "
         "liberty; layer RC is the OpenROAD-flow-scripts sky130hd setting. **Wire delays are an Elmore estimate on "
         "conceptual distances from the floorplan illustration.** No placement, routing, parasitic extraction or "
         "sign-off STA has been run, so no number here is a timing sign-off.", "",
         "## 1. Inputs", "",
         "| Quantity | Value | Source |", "|---|---|---|",
         f"| master node logic (tc map + sfn_mst_port + link entry) | {i['t_node_ps']:.0f} ps | ABC, `c_mnode_p1` |",
         f"| one link stage (sfn_fifo depth 2, output mux) | {i['t_stage_ps']:.0f} ps | ABC, `c_link_stage` |",
         f"| central routing stage, QoS, **sfs_xbar** (parallel-level arbiter; used) | {i['t_xbar_qos_ps']:.0f} ps | ABC, `c_xbar_qos_fast` |",
         f"| central routing stage, QoS, P22 sfn_xbar (sequential level chain) | {i['t_xbar_qos_p22_ps']:.0f} ps | ABC, `c_xbar_qos` |",
         f"| central routing stage, round robin | {i['t_xbar_rr_ps']:.0f} ps | ABC, `c_xbar_rr` |",
         f"| flop {i['flop']['cell']}: clk->Q + setup | {i['flop']['clk_to_q_ns'] * 1000:.0f} + {i['flop']['setup_ns'] * 1000:.0f} ps | liberty |",
         f"| clock margin (skew, jitter, OCV) | {i['clock_margin'] * 100:.0f} % of the period | assumption (config) |",
         f"| route detour over Manhattan | x{i['route_detour']} | assumption (config) |"]
    for layer, w in i["wires"].items():
        L.append(f"| repeated wire, {layer} (r {w['r_ohm_per_mm']:.1f} ohm/mm, c {w['c_ff_per_mm']:.0f} fF/mm) | "
                 f"**{w['ps_per_mm']:.0f} ps/mm** ({w['cell']} every {w['seg_mm']:.2f} mm) | Elmore estimate"
                 f"{' (used)' if layer == i['wire_layer'] else ''} |")
    L += ["", f"With P22's QoS arbiter the central stage alone would need {(i['t_xbar_qos_p22_ps'] + i['t_stage_ps'] + i['t_ff_ps']) / (1 - i['clock_margin']) / 1000:.1f} ns; "
          "sfs_xbar is proved cycle-identical to sfn_xbar (reports/formal.md), so the spine keeps P22's QoS behaviour "
          "and guarantee at the faster structure.", "", "Repeaters fitted from the liberty (linear delay over load at 0.1 ns input slew):", "",
          "| Cell | Cin (fF) | d0 (ps) | Rd (ohm) |", "|---|---|---|---|"]
    for b in i["repeaters"]:
        L.append(f"| {b['cell']} | {b['cin_pf'] * 1000:.2f} | {b['d0_ns'] * 1000:.0f} | {b['rd_kohm'] * 1000:.0f} |")
    s, e, cl = r["single"], r["evidence"], r["central_limit"]
    L += ["", "## 2. Starting point: one central routing stage, no link registers", "",
          f"Every transfer crosses master node logic, the master wire, the central stage and the target wire in one "
          f"cycle. Worst pair **{s['worst_pair'][0]} -> {s['worst_pair'][1]}** ({s['worst_path_mm']:.1f} mm): "
          f"period **{s['period_ps'] / 1000:.2f} ns ({s['mhz']:.1f} MHz)**. Without any wire the same logic would "
          f"allow {s['period_without_wires_ps'] / 1000:.2f} ns, so the conceptual wires cost "
          f"{(s['period_ps'] - s['period_without_wires_ps']) / 1000:.2f} ns of the cycle.", "",
          "## 3. Evidence: register every link at the central stage", "",
          f"With a register stage at the central stage on both sides, the central routing logic alone limits the "
          f"clock: **{cl['period_ps'] / 1000:.2f} ns ({cl['mhz']:.1f} MHz)**. The chosen clock is "
          f"**{e['period_ps'] / 1000:.1f} ns ({e['mhz']:.1f} MHz)**. At this clock a wire can run "
          f"{e['reach_node_mm']:.1f} mm after the node logic and {e['reach_mid_mm']:.1f} mm between stages, so the "
          f"required stages per link direction are:", "",
          "| Link | Route (mm) | Stages | | Link | Route (mm) | Stages |", "|---|---|---|---|---|---|---|"]
    rows = max(len(ms), len(ts))
    for k in range(rows):
        a = f"| {ms[k]['name']} | {ms[k]['route_mm']:.1f} | {e['mst_pipe'][k]} |" if k < len(ms) else "| | | |"
        b = f" | {ts[k]['name']} | {ts[k]['route_mm']:.1f} | {e['tgt_pipe'][k]} |" if k < len(ts) else " | | | |"
        L.append(a + b)
    L += ["", f"{e['link_registers']} link register stages in total (request + response). Each stage adds one "
          f"cycle per direction: a master->target round trip grows by 2 x (master stages + target stages) cycles.", "",
          "## 4. Between the two limits: selective pipelining", "",
          "Minimum number of links that need a register (at the central stage) for a given clock, exhaustive search "
          "over link subsets of up to 6 links:", "",
          "| Period (ns) | MHz | Registered links | Which |", "|---|---|---|---|"]
    for p in r["pareto"]:
        L.append(f"| {p['period_ps'] / 1000:.2f} | {p['mhz']} | {p['registered_links']} | {', '.join(p.get('links', [])) or '-'} |")
    L += ["", "## 5. Sensitivity: reach per cycle", "",
          "The stage count depends only on how far a signal travels in one cycle. For a faster process or clock the "
          "reach shrinks; this table is technology-neutral (P = ceil(route / reach), at least 1):", "",
          "| Reach (mm/cycle) | Max stages on a link | Link registers (all links, both directions) | Worst added round trip (cycles) |",
          "|---|---|---|---|"]
    for x in r["sensitivity"]:
        L.append(f"| {x['reach_mm']} | {x['max_stages']} | {x['link_registers']} | {x['worst_pair_added_rtt']} |")
    L += ["", f"The **deep** configuration simulated in reports/bench.md is the {r['configs']['deep']['why']}", ""]
    open(os.path.join(REP, "placement.md"), "w").write("\n".join(L))


if __name__ == "__main__":
    main()
