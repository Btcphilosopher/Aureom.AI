#!/usr/bin/env python3
"""Put the spine on the real SilicaFlux die endpoints: Project 31's die-level regression.

  1. stage Project 31 (DieTop) from its archive (SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/
     silicaflux-dietop-p31.zip, or P31_DIR = an extracted tree) into build/p31/;
  2. copy the spine RTL into the staged tree (third_party/silicaflux-noc-spine/) and add it to
     rtl/files_die.f;
  3. replace rtl/subsys/datafabric.sv by integration/p31/datafabric.sv -- the ONLY changed P31 file:
     the crossbar topology (HPC, V2, MINEXT) becomes silicaflux_noc_spine with traffic classes and
     link register stages (evidence stages for the HPC port set, 1 stage per link otherwise);
  4. run P31's own scripts/regress.py (its testbench, its checks, its firmware run) for the crossbar
     configurations, and scan every log for the spine's in-RTL assertion messages ("ASSERT ...").
Writes reports/p31_integration.{json,md}; P31's own report is copied to reports/p31_regression.md.
usage: p31_integration.py [--cfg HPC V2 MINEXT] [--quick]
"""
import argparse, glob, json, os, re, shutil, subprocess, sys, zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
STAGE = os.path.join(ROOT, "build", "p31")
SPINE_RTL = ["rtl/spine/sfs_pkg.sv", "rtl/cfg/sfs_cfg_pkg.sv", "rtl/spine/sfs_qos_arbiter.sv", "rtl/spine/sfs_xbar.sv",
             "rtl/spine/sfs_link.sv", "rtl/spine/sfs_tc_map.sv", "rtl/spine/sfs_mnode.sv", "rtl/spine/sfs_tnode.sv",
             "rtl/spine/sfs_perf.sv", "rtl/spine/sfs_spine_assert.sv", "rtl/spine/silicaflux_noc_spine.sv"]


def find_p31():
    if os.environ.get("P31_DIR"):
        return os.environ["P31_DIR"], None
    if os.environ.get("P31_ZIP"):
        return None, os.environ["P31_ZIP"]
    cands = glob.glob(os.path.join(ROOT, "..", "**", "silicaflux-dietop-p31.zip"), recursive=True)
    cands += glob.glob(os.path.join(os.getcwd(), "**", "silicaflux-dietop-p31.zip"), recursive=True)
    if not cands:
        sys.exit("P31 archive not found: set P31_DIR to an extracted silicaflux-dietop tree or P31_ZIP to the archive")
    return None, cands[0]


def stage():
    d, z = find_p31()
    if os.path.exists(STAGE):
        shutil.rmtree(STAGE)
    os.makedirs(STAGE)
    if z:
        with zipfile.ZipFile(z) as f:
            f.extractall(STAGE)
        top = os.path.join(STAGE, "silicaflux-dietop")
        src = z
    else:
        top = os.path.join(STAGE, "silicaflux-dietop")
        shutil.copytree(d, top)
        src = d
    # P31's archived results were produced with P22's fabric: remove them so that every result below is new
    for f in glob.glob(os.path.join(top, "reports", "sim", "*.log")) + [os.path.join(top, "reports", "regression.json"),
                                                                         os.path.join(top, "reports", "regression.md")]:
        if os.path.exists(f):
            os.remove(f)
    tp = os.path.join(top, "third_party", "silicaflux-noc-spine")
    os.makedirs(tp)
    for f in SPINE_RTL:
        shutil.copy(os.path.join(ROOT, f), tp)
    orig = open(os.path.join(top, "rtl", "subsys", "datafabric.sv")).read()
    ref = open(os.path.join(ROOT, "integration", "p31", "datafabric_p31_original.sv")).read()
    if orig != ref:
        sys.exit("P31 datafabric.sv differs from integration/p31/datafabric_p31_original.sv -- not the audited version")
    shutil.copy(os.path.join(ROOT, "integration", "p31", "datafabric.sv"), os.path.join(top, "rtl", "subsys", "datafabric.sv"))
    fl = os.path.join(top, "rtl", "files_die.f")
    txt = open(fl).read()
    anchor = "third_party/silicaflux-datafabric-noc/rtl/noc/sfn_sfb2_tgt_bridge.sv\n"
    assert anchor in txt
    add = "// ---- SilicaFlux NoC Spine (Project 34)\n" + "".join(
        f"third_party/silicaflux-noc-spine/{os.path.basename(f)}\n" for f in SPINE_RTL)
    open(fl, "w").write(txt.replace(anchor, anchor + add))
    return top, src


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", nargs="*", default=["HPC", "V2", "MINEXT"])
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--report-only", action="store_true", help="re-read the staged tree's results")
    a = ap.parse_args()
    top = os.path.join(STAGE, "silicaflux-dietop")
    if a.report_only:
        prev = json.load(open(os.path.join(ROOT, "reports", "p31_integration.json")))
        src, rc = prev["source"], prev["p31_exit"]
        r = type("R", (), dict(returncode=rc))()
    else:
        top, src = stage()
        cmd = ["python3", "scripts/regress.py", "--cfg"] + a.cfg + (["--quick"] if a.quick else [])
        r = subprocess.run(cmd, cwd=top, capture_output=True, text=True)
        open(os.path.join(ROOT, "build", "p31_regress.log"), "w").write(r.stdout + r.stderr)
    logs = sorted(glob.glob(os.path.join(top, "reports", "sim", "*.log")))
    asserts = {}
    fails = {}
    for l in logs:
        fl = [x.strip() for x in open(l, errors="replace") if "CHECK FAIL" in x]
        if fl:
            fails[os.path.basename(l)] = fl
        n = sum(1 for x in open(l, errors="replace") if x.startswith("ASSERT "))
        if n:
            asserts[os.path.basename(l)] = n
    rj = os.path.join(top, "reports", "regression.json")
    data = json.load(open(rj)) if os.path.exists(rj) else {}
    res = data.get("results", [])
    if os.path.exists(os.path.join(top, "reports", "regression.md")):
        shutil.copy(os.path.join(top, "reports", "regression.md"), os.path.join(ROOT, "reports", "p31_regression.md"))
    os.makedirs(os.path.join(ROOT, "reports", "p31_logs"), exist_ok=True)
    for l in logs:
        shutil.copy(l, os.path.join(ROOT, "reports", "p31_logs"))
    ok_runs = [x for x in res if x.get("pass")]
    out = dict(source=os.path.relpath(src, ROOT) if os.path.isabs(src) else src, configs=a.cfg, p31_exit=r.returncode,
               runs=len(res), passed=len(ok_runs), assert_lines=asserts, failing_checks=fails, results=res)
    json.dump(out, open(os.path.join(ROOT, "reports", "p31_integration.json"), "w"), indent=1)
    M = ["# P31 die-level regression with the spine (generated by scripts/p31_integration.py)", "",
         "Project 31's own testbench (`tb/tb_die_top.sv`), checks and firmware, unchanged; the only changed P31 file is "
         "`rtl/subsys/datafabric.sv` (integration/p31/datafabric.sv): the crossbar topology is `silicaflux_noc_spine` "
         "with traffic classes and link register stages — the placement-evidence stages for the HPC port set (HOST, DMA0, "
         "DMA1 two stages, every other link one), one stage per link for V2 and MINEXT.", "",
         f"* P31 regression exit status: **{r.returncode}**",
         f"* runs reported by P31's regression: **{len(ok_runs)} / {len(res)} PASS**",
         f"* spine in-RTL assertion messages in all logs: **{sum(asserts.values())}**",
         f"* checks: **{sum(x.get('checks', 0) for x in res)}** in total, **{sum(max(0, x.get('fails', 0)) for x in res)}** failed", ""]
    noncov = [x for v in fails.values() for x in v if "coverage" not in x]
    if fails:
        M += ["Every failing check, verbatim from the logs:", ""]
        for k, v in fails.items():
            M += [f"* `{k}`: " + "; ".join(f"`{x}`" for x in v)]
        M += ["", "The `[accreset] coverage` point requires that one of up to 160 accelerator resets lands on a request "
              "*held* by the fabric. P31's testbench already waives it for its buffered fabric (the mesh, "
              "`tb_die_top.sv`: \"on the mesh the network interfaces buffer requests, so a fabric-held request at the "
              "instant of reset is rare -- reported there, not required\"). The spine's link stages buffer requests in "
              "the same way, so the point is hit only on some seeds. It is a coverage requirement, not a functional "
              "check. P31's testbench was not modified to waive it.", ""]
        M += [f"Failing checks that are not coverage points: **{len(noncov)}**.", ""]
    extra = sorted(glob.glob(os.path.join(top, "reports", "sim", "*_extra.log")))
    if extra:
        M += ["Additional seeds of the configuration that missed the coverage point (same binary, run by hand with "
              "`build/sim_V2/vtb +test=all +bp=40 +seed=S +mcbp=60`):", "", "| Log | Result | Held-request coverage |", "|---|---|---|"]
        for l in extra:
            t = open(l, errors="replace").read()
            res_ = re.search(r"TB RESULT (\w+) .*checks=(\d+) fails=(\d+)", t)
            cov = re.search(r"reset landed on a request held by the fabric after (\d+) tries \(held_at_reset = (\d+)\)", t)
            M.append(f"| `{os.path.basename(l)}` | {res_.group(1) if res_ else '?'} ({res_.group(2) if res_ else '?'} checks, "
                     f"{res_.group(3) if res_ else '?'} failed) | {'hit after ' + cov.group(1) + ' tries' if cov and cov.group(2) != '0' else 'not hit in ' + (cov.group(1) if cov else '?') + ' tries'} |")
        M.append("")
    M += [
         "P31's report (copied: reports/p31_regression.md):", ""]
    if os.path.exists(os.path.join(ROOT, "reports", "p31_regression.md")):
        M += ["```", open(os.path.join(ROOT, "reports", "p31_regression.md")).read()[:6000], "```"]
    open(os.path.join(ROOT, "reports", "p31_integration.md"), "w").write("\n".join(M) + "\n")
    print(f"P31 regression exit {r.returncode}; {len(ok_runs)}/{len(res)} PASS; assertion lines {sum(asserts.values())}")
    sys.exit(0 if r.returncode == 0 and not asserts else 1)


if __name__ == "__main__":
    main()
