# Physical topology, pipelining and placement

> **What kind of evidence this is.** Logic delays are **tool results**: Yosys 0.33 synthesis to the SkyWater
> `sky130_fd_sc_hd` TT 1.80 V 25 °C liberty, then ABC static timing of the mapped netlist (`stime`). Flop, buffer and
> layer-RC data come from that liberty and from the OpenROAD-flow-scripts sky130hd platform. **Distances are
> conceptual** (measured off the floorplan illustration) and **wire delays are an Elmore estimate**. No placement,
> routing, parasitic extraction or sign-off STA was run — OpenROAD could not be installed in this environment — so
> no frequency below is a timing sign-off. Generated tables: reports/placement.md, reports/connectivity.md,
> reports/synth.md.

## 1. Topology on the die

The floorplan illustration has a horizontal **DataFabric NoC / Interconnect Spine** across the middle of a
28.0 × 24.0 mm die, compute above and below it, I/O and memory interfaces on the rows above and below those
(config/silicaflux_floorplan.yaml, reports/img/connectivity.png). The spine RTL mirrors it:

```
                 HOST_IO        CTRL (CC)              RAS (REGS)
                    │              │                      │
   SRAM_A  VE0      │       TC_U (TSU0)                VE1  SRAM_B
   (SPM0) (VEC0)    │          │                     (VEC1) (SPM1)
 ═══╪════════╪══════╪══════════╪═════[central routing stage]═══╪══════╪═══   <- spine corridor
   SRAM_C  VE2             TC_L (TSU1)                VE3  SRAM_D
   (SPM2) (VEC2)                                     (VEC3) (SPM3)
      DMA (DMA0, DMA1)     SHMEM (SRAM0..3)         EXTMEM (EXT, EXTCSR)
```

* **One central routing stage** — `sfs_xbar`, the P22 crossbar (with the proved-equivalent fast QoS arbiter) —
  at the middle of the spine, (14.0, 11.8) mm.
* **21 attachment nodes**, one per port, on the edge of each region facing the spine: a master node holds the
  traffic-class map and P22's `sfn_mst_port`; a target node is wiring plus its link stages.
* **Point-to-point links** from every node to the central stage along the spine corridor, each with `PIPE`
  register stages per direction.

Distances: Manhattan from the attachment point to the central stage × 1.15 detour (assumption):
1.4 mm (TSU1) to 18.6 mm (HOST); 68 legal master→target pairs, the longest HOST → EXTCSR = 36.3 mm through the
centre (reports/connectivity.md).

## 2. Segmented crossbar vs registered multistage NoC

Both candidates exist as verified RTL and were built, simulated and synthesized on the same configuration:

| | Segmented crossbar (**this spine**) | Registered multistage NoC (P22 2-D mesh, 4 × 3 routers on the die) |
|---|---|---|
| switching | one central stage, full crossbar, any disjoint pairs in parallel | 12 routers, XY routing, separate request / response networks |
| register boundaries | `PIPE` stages per link, placed where the wire needs them | one per hop (router input FIFOs), whether the hop needs it or not |
| logical hops | 1 | 1..6 (+ NI packetising) |
| attachment constraint | none | one master and one target per router: the four shared-SRAM slices (one block) must spread over routers up to 18 mm away (reports/connectivity.json `mesh`) |
| area, latency, bandwidth | reports/synth.md, reports/bench.md E4 | same |

**Choice: the segmented crossbar.** It meets every functional requirement with one routing stage and adds registers
only on links whose length needs them. The mesh registers every hop, but its hops are 7–8 mm long, so on this die
they would need link pipelining too; it costs several times the logic (P22 measured 45 k vs 8 k NAND2-eq at 4 × 6;
this configuration: reports/synth.md), delivers less bandwidth under the measured die traffic (reports/bench.md E4)
and forces long attachment wires for co-located targets. The mesh remains the verified scale-out option if the port
count grows well beyond ~16 per side (crossbar cost grows with NM × NT).

## 3. Timing model

A link with `P ≥ 1` stages places its **last stage at the central stage** — so no long wire is ever in series with the
central routing logic, the longest logic path — and the other `P − 1` stages along the wire:

```
 master node logic ── wire ──[st]── wire ──[st]── ... ──[st@centre]── central stage ──[st@centre]── wire ──[st]── target
   segment: t_node + v·w      t_stage + v·w           t_stage + t_xbar                     t_stage + v·w
```

Every segment must satisfy `clk→Q + setup + logic + v·wire ≤ T·(1 − 10 % margin)`.

| Input | Value | Source |
|---|---|---|
| master node logic (tc map + `sfn_mst_port` + link entry) | 2.31 ns | ABC, `c_mnode_p1` |
| link stage (2-entry `sfn_fifo` output mux) | 0.71 ns | ABC, `c_link_stage` |
| central stage, QoS, `sfs_xbar` 10 × 11 | **3.40 ns** | ABC, `c_xbar_qos_fast` |
| central stage, QoS, P22 `sfn_xbar` | 10.49 ns | ABC, `c_xbar_qos` |
| central stage, round robin | 3.11 ns | ABC, `c_xbar_rr` |
| flop `dfxtp_1` clk→Q + setup | 0.37 + 0.10 ns | liberty |
| repeated wire, met4 (168 Ω/mm, 148 fF/mm), `buf_16` every 3.6 mm | **154 ps/mm** | Elmore estimate |
| repeated wire, met5 (18 Ω/mm, 154 fF/mm) | 111 ps/mm | Elmore estimate |

## 4. Start with one central routing stage; add pipelining from the evidence

| Step | Evidence | Result |
|---|---|---|
| 0. single central stage, no link registers | worst path HOST → EXTCSR: node 2.31 + 36.3 mm × 154 ps + central 3.40 ns | **13.1 ns (76 MHz)**; without wires the same logic would allow 6.9 ns — the wires cost 6.2 ns |
| 1. P22 QoS arbiter as central logic | 10.5 ns alone | the central stage, not the wire, limits the clock: restructured (`sfs_qos_arbiter`, proved equal) → 3.4 ns |
| 2. register every link at the central stage | central segment = 0.71 + 3.40 ns | **5.1 ns (196 MHz)** |
| 3. stages along the wire at 5.1 ns | reach 11.7 mm after a node, 22.1 mm between stages | HOST, DMA0, DMA1 (17–19 mm) need **2** stages, every other link **1** (48 link stages in all) |

The selected configuration is `evidence` (`sfs_cfg_pkg::MST_PIPE_EVIDENCE` / `TGT_PIPE_EVIDENCE`). Between the two
limits, reports/placement.md §4 lists the fewest links that must be registered for a given clock (e.g. 3 links —
HOST, DMA0, DMA1 — reach 12.1 ns).

**Sensitivity.** The required stages depend only on the reach per cycle. At 4 mm per cycle (a faster process or
clock) the longest links need 5 stages and a worst round trip gains 20 cycles; at 20 mm one stage suffices
everywhere (reports/placement.md §5). The `deep` configuration simulates the 4 mm point to measure the cost of
multi-stage links (reports/bench.md E1).

## 5. Balancing latency, routing length, register overhead, buffer capacity and clock

| Lever | Effect (measured or derived) |
|---|---|
| **Added latency** | each stage adds 1 cycle per direction: the evidence configuration adds 4 cycles to a round trip (6 for HOST and DMA). In time units it is still faster: 76 → 196 MHz (reports/bench.md E1 reports both cycles and ns) |
| **Routing length** | determines stages; placing the central stage at the spine centre minimises the longest link (18.6 mm); a second central stage near SHMEM would shorten DMA→SRAM (31 mm via the centre vs 6 mm direct) — §6 |
| **Register overhead** | a master-link stage holds 2 × 82 request bits + 2 × 43 response bits, a target-link stage 2 × 80 + 2 × 43 (HPC widths); the 24 stage positions (48 stages counting both directions) hold ≈ 6.0 kbit of flops; area in reports/synth.md (`spine_single` vs `spine_evidence` vs `spine_deep`) |
| **Buffer capacity** | `BUF_DEPTH = 2` is the minimum for one transfer per cycle per stage; `BUF_DEPTH = 1` halves link throughput (formal K5 property and reports/bench.md E2); deeper buffers add capacity but no bandwidth |
| **Outstanding limits** | a master issues one beat per cycle only if `MAXO ≥ round trip`; P31's limits (VEC 1, DMA 2) were sized for a combinational crossbar. The spine configuration raises them (CC 2, HOST 2, DMA 8, VEC 4, TSU 8, `maxo_spine` in the config); E1 shows the throughput lost with P31's limits on the pipelined spine |
| **Clock** | set by the central stage once links are registered; a faster central stage moves wire-driven stages from 3 links (12.1 ns) to all links (5.1 ns) |
| **Counter pages** | NOC_PERF + SPINE_PERF (`PERF = 1`) are the largest block: 159 k vs 38 k NAND2-eq, 20.0 k vs 6.9 k flops (`spine_evidence_perf` vs `spine_evidence`). The SPINE_PERF class statistics were first a 12.5 ns path; registered in three stages they are 2.7 ns, and the whole spine with counters synthesises at 3.6 ns — the counters do not limit the clock. A production die can build with `PERF = 0` |

## 6. Placement observations and recommendations

1. **Central stage at the spine centre** (as in the illustration) minimises the worst link and keeps both tensor
   arrays — the heaviest SRAM readers — 1.4–1.5 mm from it.
2. **Shared SRAM far from the spine.** The illustration puts the four SRAM slices in one block at the bottom centre:
   every SRAM access crosses 8–13 mm, and DMA→SRAM goes through the centre (31 mm vs 6 mm direct). Moving the slices
   next to the spine (or adding a second, local routing stage for DMA/SHMEM/EXTMEM traffic) would shorten these
   links; the per-link pipelining parameters absorb either choice.
3. **Mesh attachment.** With one target per router, the co-located SRAM slices land on routers up to 18 mm away —
   a structural mismatch between a uniform mesh and this floorplan.
4. **Wide parallel buses.** 21 links × ≈ 125 payload bits + valid/ready ≈ 2,700 wires converge on the central stage; the corridor
   in the illustration (≈ 1.4 mm high, 23 mm long) is the routing resource for them. With a real routing grid this
   is the first thing to check (congestion map) once OpenROAD can run (§7).

## 7. What would replace the estimates

With a working OpenROAD + sky130 (or the target PDK) flow: place the spine with the node pins at the conceptual
attachment points, global-route, extract (or estimate) parasitics and run STA. Replace `v_ps_per_mm` and the
distances by routed wire lengths and extracted RC, and rerun `scripts/placement.py` — the stage selection, the
configuration package and every simulation are driven from those numbers, so nothing else changes.
