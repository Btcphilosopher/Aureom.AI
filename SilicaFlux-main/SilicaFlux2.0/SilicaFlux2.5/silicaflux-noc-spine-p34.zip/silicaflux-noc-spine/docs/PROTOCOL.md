# Request / response protocol of the spine

The spine speaks **SFB3**, the DataFabric-NoC protocol of Project 22, unchanged. The normative definition is P22's
`docs/PROTOCOL.md` (vendored: `third_party/silicaflux-datafabric-noc/docs/PROTOCOL.md`); this page states what an
attachment node sees, what the spine adds (link pipelining, traffic classes) and why none of P22's guarantees change.

## 1. Ports

Every attachment port is an SFB3 master or target port with two independent valid/ready channels.

| Channel | Fields (width) |
|---|---|
| master request | `opcode` (3), `id` (`IDW`), `qos` (3), `addr` (`AW`), `wdata` (`DW`), `wstrb` (`DW/8`) |
| master response | `id`, `opcode` (the answered request's), `status` (2), `rdata` |
| target request | as the master request + `src` (`clog2 NM`, stamped by the central stage: no spoofing) |
| target response | `src`, `id`, `opcode` (echoed), `status`, `rdata` |

Parameters: `NM`, `NT` (attachment ports), `AW` 8..64, `DW` 32..256, `IDW` 1..8, `BUF_DEPTH` 1..16,
`MST_PIPE[m]` / `TGT_PIPE[t]` 0..15 register stages per link direction, `MST_MAXO[m]`. No field is ever narrowed:
every link carries the full payload (regression: `syn_m3t3_d64_aw48`, `syn_m8t8_id3_rr_b1`).

## 2. Transactions

| Item | Rule |
|---|---|
| **Read / write requests** | `OP_READ`, `OP_WRITE` (acknowledged: response after the write is performed), `OP_WRITE_POSTED` (no response to the master; the target's completion retires it inside the fabric), `OP_FENCE` (answered by the master's node when all earlier transactions are complete), 4..7 reserved |
| **Address routing** | decoded **once, at the master's node** (DataFabric `sfb_addr_decoder`: base/mask windows, access matrix, alignment). The target index travels with the request through the link; the central stage routes by it. A request that does not decode never leaves the node (local `ST_DECERR`). |
| **Data payloads** | one `DW`-bit beat per transaction with byte enables; bursts are sequences of transactions (§5) |
| **Transaction tagging** | `id` from the master; `src` added by the central stage; targets echo `(src, id, opcode)` |
| **Response ownership** | the central stage steers a response by its `src` to that master's response link; the master node accepts it only if `(id, target)` matches an outstanding transaction (else: orphan, consumed, never delivered, counted). A `src` that is out of range or not allowed for that target is consumed at the central stage (`bad_src`). |
| **Error signalling** | `ST_DECERR` from the node (unmapped, access-matrix denied, misaligned, reserved opcode — no side effect); `ST_SLVERR` from targets; a posted write that fails is reported by event + NOC_PERF `ERR_STATUS` + `irq_err` (no response exists to carry it); orphan and bad-source responses set their own `ERR_STATUS` bits |
| **Backpressure** | valid/ready on every channel and at every link register stage; nothing is ever dropped to relieve pressure |

## 3. Ordering guarantees

| Relation | Guarantee | Why it survives pipelining |
|---|---|---|
| requests of one master to one target | arrive in issue order | the master link is one FIFO chain; the central stage moves one request per master per cycle |
| responses of one master, same ID | in request order | O2 (one target per outstanding ID, enforced at the node) + targets answer one (src, id) in order + every response link is a FIFO |
| responses, different IDs | no order | as in P22 |
| read after write, same ID | sees the write | same target, in order |
| across masters / different IDs | no ordering, no coherence: use acknowledged writes or FENCE | as in P22 |

## 4. No request may disappear during stalls

* A link stage accepts only with `in_valid && in_ready` and releases only with `out_valid && out_ready`; its
  outputs come from registers, so a stalled entry is presented unchanged (formal `fv_sfs_link` K1–K4, unbounded).
* The central stage's grant lock keeps a granted request on its target link input until accepted (P22 R2; formal
  `fv_sfs_xbar_equiv` proves `sfs_xbar` = `sfn_xbar`, so P22's proofs of the crossbar apply).
* The master node counts a transaction as outstanding when the link accepts it and retires it only on its response
  (or posted completion): in simulation `sfs_spine_assert` S4 checks `outstanding == accepted − retired` every cycle,
  and the system harness `fv_sfs_spine` E1/E2 checks end-to-end that every request reaches its target unchanged and
  every response its owner.
* Reset (asynchronous assert, synchronous release) cancels every transaction including those held in link stages
  (P22 R11); the testbench resets mid-traffic (`resets`, `die_resets`).

## 5. Bursts and vector / tensor access patterns

SFB3 is single-beat; bursts are streams of independent transactions. The node keeps up to `MST_MAXO[m]` of them in
flight, which is what sustains bandwidth over a pipelined link: a master needs `MAXO ≥ round trip` to issue one
beat per cycle (docs/PHYSICAL.md §5). Tensor operand loads rotate IDs over consecutive beats (`tensor_load`
profile), so several reads are outstanding; DMA output writes are posted (`dma_write`). Long bursts (256 beats)
and hotspots are regression tests.

## 6. Traffic classes

| Class | Which requests | Where it matters |
|---|---|---|
| `TC_CTRL` (0) | from a control master (`MST_CTRL`: ControlCore, host) **or** to a register target (`TGT_MMIO`: die registers, external-memory CSR) | arbitration level 3 |
| `TC_RD` (1) | other reads | level 2 |
| `TC_WR` (2) | other writes (acknowledged or posted) | level 1 |
| `TC_CPL` (3) | completions and errors | travel on the **response network**, which is physically separate from the request network: a completion never waits behind a request, and no request can block a completion |

The class is computed at the master node (`sfs_tc_map`) and travels with the request (2 bits). With `TC_MODE = 1`
(default) it sets the request's arbitration level (`TC_QOS`, default CTRL 3 / RD 2 / WR 1); `TC_MODE = 0` keeps the
master's own `qos` (P22 behaviour).

**Fairness guarantee (arbitration policy).** Each target port of the central stage is arbitrated by the QoS arbiter
(`ARB_MODE = ARB_QOS`): highest level first, round robin inside a level, grant lock while the target stalls, and
**aging**: a requester that has seen `STARVE` acceptances of others becomes URGENT, above every level. Hence a request
waiting at the head of its link is accepted after **at most `STARVE + NM − 1` acceptances of other requests** at that
target (proved unbounded for P22's `sfn_qos_arbiter`; `sfs_qos_arbiter` is proved output-identical). Control
traffic therefore cannot block memory operations indefinitely: the bound holds whatever the control load — it is
checked at the central stage in every regression run and measured in reports/bench.md (E3, E6 `ctrl_flood`).
`ARB_MODE = ARB_RR` gives plain round robin (bound `NM − 1`, no class priority). Priority is latency preference,
not a bandwidth reservation.

## 7. Counter pages

`NOC_PERF` (P22 `sfn_perf`, unchanged map, the page P31's die register window exposes) and `SPINE_PERF`
(`sfs_perf`, `rb_sel_spine`): link transfers, stalls, occupancy (sum / max) per link and direction, central-stage
waits per master (total, longest, lost arbitration, target busy) and per class. A CTRL write to either page applies
to both (one freeze point). Register map: header of `rtl/spine/sfs_perf.sv`. Every counter is compared with the
testbench's own count at the end of every regression run.
