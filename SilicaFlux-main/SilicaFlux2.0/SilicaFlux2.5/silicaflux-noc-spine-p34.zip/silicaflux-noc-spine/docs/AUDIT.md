# Audit — existing DataFabric RTL, NoC project and floorplan

Brief §1: inspect the existing DataFabric RTL and NoC project, reuse verified routers, crossbars and protocol
adapters, and do not build an incompatible second interconnect without justification.

## 1. What exists in the repository

| Project (archive in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`) | Relevant content | Verification status (from its own reports) |
|---|---|---|
| **P22 DataFabric-NoC** (`silicaflux-datafabric-noc.zip`) | SFB3 protocol, `sfn_mst_port` (per-master rules), `sfn_xbar` (crossbar), `sfn_sbus`, `sfn_mesh` + `sfn_router` + `sfn_ni`, `sfn_qos_arbiter`, `sfn_fifo`, `sfn_perf`, SFB2 bridges, `tb_noc` scoreboard, formal harnesses | 782 regression runs, 38/38 formal jobs (21 unbounded proofs), 35/35 mutants, real-endpoint runs 99/99 |
| DataFabric (`silicaflux-datafabric.zip`) | SFB2, `sfb_arbiter`, `sfb_addr_decoder`, `sfb_skid_buffer`, DMA | vendored by P22, unbounded arbiter proofs |
| **P31 DieTop** (`silicaflux-dietop-p31.zip`) | `silicaflux_die_top`, `config/silicaflux_die.yaml` (address map, access matrix, outstanding limits), `datafabric.sv` (NoC + SFB2 bridges), HPC configuration: 10 masters × 11 targets on P22's crossbar | 17/17 integration runs, firmware 188/188 |
| P32 ComputeCluster | vector / tensor cluster regions, region constraints (no coordinates in RTL) | 85/85 |
| FloorplanLab | OpenROAD flow scripts (not runnable here), sky130 experiments | — |
| Floorplan illustration `SilicaFlux-main/7b06044c-3b1f-4301-8472-8da3aaeebf97.png` | "SilicaFlux Die Floorplan — Conceptual", 28 × 24 mm, horizontal **DataFabric NoC / Interconnect Spine** | conceptual drawing |

The spine was built **on P22 and P31**, not beside them.

## 2. Reuse decisions

| Block | Decision | Why |
|---|---|---|
| SFB3 protocol (`sfn_pkg`) | reused unmodified | P31 already attaches every die endpoint through it; a second protocol would be the "incompatible second interconnect" the brief forbids |
| `sfn_mst_port` | reused unmodified, placed in each **master attachment node** | it owns every per-master rule (decode, access matrix, O1 outstanding limit, O2 one-target-per-ID, O3 FENCE, local DECERR responder, orphan containment), proved in P22 |
| `sfn_xbar` | reused as the **central routing stage** (`CENTRAL = 0`) and as the source of `sfs_xbar` (`CENTRAL = 1`, default) | P22 measured the crossbar as the best of its three topologies at this port count |
| `sfn_qos_arbiter` | function reused; **structure replaced** in `sfs_qos_arbiter`, **proved equivalent** | timing evidence: its sequential level comparison is 132 gate levels, 10.5 ns in sky130 (reports/synth.md), the critical path of the whole spine; the parallel-level version gives identical outputs in every cycle (unbounded proofs, reports/formal.md) at 3.4 ns |
| `sfn_fifo` | reused unmodified as **every link register stage** | proved unbounded in P22 (count, no overflow / underflow, order, integrity) |
| `sfn_perf` | reused unmodified (NOC_PERF page, P31-compatible) | P31's die register window maps this page |
| `sfb_arbiter`, `sfb_addr_decoder` | reused unmodified | via `sfn_mst_port` / `sfn_xbar`; the traffic-class map uses the same decoder |
| SFB2 bridges `sfn_sfb2_mst_bridge` / `sfn_sfb2_tgt_bridge` | reused unmodified (interconnect adapters) | P31 endpoints are SFB2 |
| `sfn_mesh` (+ router, NI) | reused unmodified as the **registered multistage NoC candidate** in the comparison | verified; no reason to write another |
| `tb_noc` (P22 testbench) | run **unmodified** against the spine (compatibility shim), and **derived** into `tb_spine` | the strongest available independent scoreboard |
| `sfn_tb_master` / `sfn_tb_target` | derived (`sfs_tb_master` adds the die-workload profiles; `sfs_tb_target` per-target latency) | the die traffic needs roles and latencies |
| P22 formal runner | derived (`formal/run_formal.py`) | same method (ABC bmc3, yosys-smtbmc + z3, ABC PDR) |
| P31 `datafabric.sv` | one modified copy in `integration/p31/` | the drop-in that puts the spine on the real die endpoints |

Every vendored file is byte-identical to its origin: `third_party/silicaflux-datafabric-noc/SHA256SUMS`
(34 files from the P22 archive, which itself vendors DataFabric).

## 3. What the spine adds (all new RTL)

| File | Purpose |
|---|---|
| `rtl/spine/silicaflux_noc_spine.sv` | primary RTL: nodes + central stage + counters + assertions |
| `rtl/spine/sfs_link.sv` | link pipeline: `STAGES` × `sfn_fifo` of `BUF_DEPTH` entries |
| `rtl/spine/sfs_mnode.sv`, `sfs_tnode.sv` | master / target attachment nodes |
| `rtl/spine/sfs_tc_map.sv` | request traffic class and arbitration level |
| `rtl/spine/sfs_qos_arbiter.sv`, `sfs_xbar.sv` | faster, proved-equivalent QoS arbitration (central stage) |
| `rtl/spine/sfs_perf.sv` | SPINE_PERF counter page |
| `rtl/spine/sfs_spine_assert.sv` | in-RTL assertions (simulation) |
| `rtl/cfg/sfs_cfg_pkg.sv` (generated), `silicaflux_noc_spine_hpc.sv`, `sfs_ref_noc_hpc.sv` | HPC floorplan configuration, configured top, reference fabrics |

## 4. Floorplan → ports

The illustration's regions map one-to-one onto P31's SILICAFLUX_HPC port set (config/silicaflux_floorplan.yaml):

| Floorplan region | Attachment node(s) | P31 port(s) |
|---|---|---|
| ControlCore CPU (top centre) | master | CC |
| PCIe / Host Interface (top left) | master | HOST |
| DMA / Data Movement Engine (bottom left) | 2 masters | DMA0, DMA1 |
| FP32 Vector Engine VE0..VE3 | master each | VEC0..VEC3 (tile DMA: scratchpad fill / drain) |
| TensorCore Array TC0-15 / TC16-31 | master each | TSU0, TSU1 |
| SRAM Bank A / B / C / D columns | target each | SPM0..SPM3 (the 4 scratchpad banks of VE0..VE3 — P32's "tile + 4 SPM banks") |
| Shared SRAM Memory Subsystem (bottom centre) | 4 targets | SRAM0..SRAM3 (4 slices × 4 banks, P31 HPC) |
| RAS / ECC / Reliability (top) | target | REGS (die registers, error log, NOC_PERF, DMA registers) |
| External Memory Interface (bottom right) | 2 targets | EXT (data), EXTCSR (bridge registers) |
| DataFabric NoC spine (middle band) | central routing stage | `sfs_xbar` |

The illustration's capacities and TOPS (2 nm class, 256 MB SRAM, 4096 TOPS) are illustration-scale and are **not**
claimed for the RTL: the endpoints are P31's (4 FP32 vector tiles, 2 INT8 4×4 tensor units, 4 MiB SRAM).

## 5. Findings during the audit that shaped the design

1. The P31 HPC fabric (P22 crossbar) is a single combinational stage from every master port to every target port
   (P22 docs/PROTOCOL.md §2). On a 28 × 24 mm die that path spans up to 36 mm of wire: a physical design needs
   registered link boundaries — the core of this project.
2. P22's QoS arbiter is functionally right but structurally slow (sequential maximum over the requesters); found by
   synthesis, fixed by a proved-equivalent restructuring rather than by changing the policy.
3. P22's testbench measures fairness at the master port; with link registers the master port is no longer the
   switch, so the derived testbench measures it at the central stage (docs/VERIFICATION.md §3).
4. The illustration places all four shared-SRAM slices in one bottom-centre block, so DMA→SRAM traffic travels to
   the spine centre and back (31 mm instead of 6 mm direct, reports/connectivity.md) — a placement recommendation,
   docs/PHYSICAL.md §6.
