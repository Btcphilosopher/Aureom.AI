# Verification

Four independent layers; every result is in `reports/` and reproducible with the Makefile.

| Layer | What | Report |
|---|---|---|
| Formal | link pipeline, traffic-class map, QoS-arbiter and crossbar **equivalence with P22**, a 2 × 2 spine with pipelined links (integrity, ownership, order, stability, bounded liveness), non-vacuity mutants | reports/formal.md |
| Simulation, spine testbench | `tb/tb_spine.sv` (derived from P22's `tb_noc`) on the HPC floorplan configuration and synthetic ones, deterministic and random tests | reports/regression.md |
| Simulation, P22 testbench | P22's `tb_noc.sv` **unmodified** against the spine (compat shim), and byte-identical transaction traces vs P22's own crossbar (identity) | reports/regression.md |
| Integration | P31's die-level testbench with the spine in its `datafabric.sv`: real ControlCore firmware, vector tiles, tensor units, DMA, shared SRAM, external-memory bridge, host | reports/p31_integration.md |
| Lint / elaboration | Verilator `-Wall`, Icarus, Yosys; illegal parameter sets refused | reports/lint.md |

## 1. Assertions (brief §9)

| Property | In-RTL assertion (`sfs_spine_assert`, every simulation) | Testbench scoreboard | Formal |
|---|---|---|---|
| **No lost transactions** | L1 per link: shadow FIFO count = link occupancy; S4 per master: outstanding = accepted − retired | every accepted request appears exactly once at its target; every response once at its master; end-of-test: nothing pending | `fv_sfs_link` K1, `fv_sfs_spine` E1, E2 (the fabric's orphan / bad-source discard never fires on legal traffic: no completion is lost — a safety property, checked at every BMC depth), E5 |
| **No duplicated responses** | L2 (nothing leaves a link that did not enter); S5 per (master, ID): no retirement without an outstanding transaction | response with nothing expected = failure | `fv_sfs_spine` E2 |
| **FIFO safety** | L4 occupancy ≤ STAGES × BUF_DEPTH | — | `fv_sfs_link` K1 (and P22's `sfn_fifo` proofs) |
| **Stable payload under stall** | L5 at every link output; S3 at every central→target, target and master-response port | P22 protocol checker on every master and target port (R2 / R4) | `fv_sfs_link` K4, `fv_sfs_spine` E3 |
| **Legal destination** | S1 at the central stage (index < NT, access matrix, address in the window, forwarded opcode); S2 at every target port (source < NM, allowed, window) | independent reference decoder; requests checked against what the master sent | `fv_sfs_spine` E1 |
| **Response ID consistency** | S5; posted completions never reach a master | per (master, ID) expected queue: opcode, status, data, owner | `fv_sfs_spine` E2 |
| **Correct ordering** | L3 (each link delivers in entry order, bit-exact) | per (master, target) request order; per (master, ID) response order; RAW checks with FENCE (`raw_fence`), negative test without FENCE (`nofence_neg` must fail) | `fv_sfs_link` K3, `fv_sfs_spine` E1/E2 |
| **Deadlock / liveness** (under docs/ARCHITECTURE.md §4 assumptions) | — | watchdog: no handshake for 4000 cycles with work pending = failure; completion of every run | `fv_sfs_spine` E5 (bounded response under fairness) |
| Outstanding limit (O1), reset (R11) | S6, S7 | O1/O2/O3 shadows; no transfer during reset | `fv_sfs_spine` E4 |
| Fairness bound | — | **at the central stage**: other acceptances at the same target while a link head waits ≤ STARVE + NM − 1 (QoS) / NM − 1 (RR) | P22 `sfn_qos_arbiter` proof + equivalence `fv_sfs_qos_equiv` |
| Counters | — | every NOC_PERF and SPINE_PERF counter equals the testbench's own count | — |

## 2. Tests (brief §10)

`tb_spine` runs every test with an independent scoreboard, all assertions, the fairness check and the counter
comparison. Deterministic tests use fixed patterns; random tests are seeded (xorshift, identical in every simulator).

| Brief item | Tests (scripts/regress.py) |
|---|---|
| deterministic | `routes` (every master writes then reads back every target, denied routes give DECERR), `raw_fence` (read-after-write with FENCE phases), `smoke` |
| randomised | `random`, `errors`, `spurious`, `backpress`, `maxload`, `die*` (all seeded, 1–3 seeds) |
| low utilisation | `die_low` (10 % of every profile's rate), `smoke` |
| saturation | `die_sat`, `maxload`, `hotspot`, `perm` (rate 100 %) |
| hotspot destinations | `hotspot` (P22), `hotspot_sram` (90 % to SRAM0), `ctrl_vs_mem` (100 % to SRAM0, control and memory classes mixed) |
| mixed read / write | `random`, `die` (reads, acknowledged and posted writes, FENCE) |
| multiple masters | every test (all 10 HPC masters active unless silenced) |
| long bursts | `bursts` (256-beat sequential), `die_bursts` (128-beat profile bursts) |
| error propagation | `errors` / `die_errors` (unmapped, misaligned, denied, reserved opcodes → DECERR; target SLVERR windows; posted-write errors → event + ERR_STATUS + IRQ), `spurious` / `spur_bad` / `die_spur` (target fault injection: orphans and bad sources contained, never delivered) |
| reset | `resets` (6 resets during traffic), `die_resets` |
| backpressure | `backpress` (50 % target and master back-pressure), `die_bp` (40 %), every test with stalls through link stages |
| simultaneous tensor / vector / DMA / ControlCore traffic | `die*` tests: `tensor_load`, `vec_spm`, `dma_write`, `cc_mmio`, `host` profiles together (sfs_tb_master amode 6); reports/bench.md E5 compares each alone with all together |

Configurations: HPC floorplan with single / evidence / deep pipelining, P31 vs spine outstanding limits,
BUF_DEPTH 1, round robin, TC_MODE 0, P22 central stage; P22 mesh and crossbar as reference fabrics; synthetic
4×4 mixed 0–3 stages, 6×5 uniform 2, 3×3 with 64-bit data and 48-bit addresses, 8×8 with 3-bit IDs + round robin +
BUF_DEPTH 1, 5×6 with SFB2 targets behind P22's bridge, 4×4 with 15 stages per link, 6×4 TC_MODE 0 with 4-entry
stages (QoS-level effectiveness), 3×5 sparse access matrix.

## 3. Why fairness is measured at the central stage

P22's testbench counts other masters' acceptances while a master waits **at its master port**. With link registers
the master port is no longer the switch: a request can be accepted into the link while another of the same master
waits at the central stage for a different target, so the P22 count is no longer the arbiter's bound. `tb_spine`
measures at the central stage (`obs_c_*`: head of each master link, its target, accepted or not), which is where
the guarantee lives. The unmodified P22 testbench therefore runs on the spine with 0 link stages (all its tests)
and with 2 stages for the tests that do not depend on that measurement.

## 4. Mutation / non-vacuity

The formal campaign includes deliberately broken RTL (`expect FAIL`): link accepting while full, output taken from the
wrong stage, MMIO not classified as control, arbiter search starting one past the pointer, arbiter level comparison
reduced to one level, a target link corrupting the response owner, a master link losing the responding target (its completions are then discarded as orphans), a
flipped request payload bit. Each must produce a counterexample; reports/formal.md lists them.

## 5. Fault-injection model with link stages

P22's target model injects a *spurious* response for any (source, ID) with nothing outstanding **at that target**.
With a combinational crossbar that is a real fault the fabric must drop. With link register stages a request for
the same (source, ID) can be in flight towards the target; the "spurious" response then becomes indistinguishable
from a legitimate early answer (no fabric can tell them apart without target-side state). The derived target model
(`tb/sfs_tb_target.sv`, `SPUR_SAFE = 1` for every spine with stages) therefore injects only sources that can never
reach that target (access matrix column `EN_COL[src] = 0`) or are out of range — faults that are unambiguous at any
depth. The spine must contain them (S2 / central-stage checks, P22 error event); the scoreboard checks none reaches a
master.

Consequence, stated plainly: in configurations where every master may reach every target **and** the master count is
a power of two (no out-of-range source encodings), no such fault exists, and the `spurious` / `spur_bad` tests inject
nothing. That is the case in `syn_m4t4_mix3`, `syn_m4t4_p15`, `syn_m8t8_id3_rr_b1`, and in `syn_m5t6_sfb2` (the SFB2
targets behind P22's bridge do not inject). Those runs still check all traffic, but not fault containment. Fault
containment is exercised by every HPC configuration (`die_spur`: 31 k – 52 k injected faults per run, all
contained), by `syn_m6t5_u2`, `syn_m3t3_d64_aw48`, `syn_m3t5_sparse`, `syn_m6t4_tc0_d4` (965 – 3,431 per run), and
by P22's unmodified testbench with its original fault model on the spine with 0 link stages (dense configurations
included).

## 6. Results

| Layer | Result |
|---|---|
| Spine testbench | **349 / 349 runs as expected** (340 passing tests + 9 / 9 `nofence_neg` negative tests failing as required), 7,052,711 transactions checked, 0 assertion failures, every counter equal to the testbench's count |
| P22 testbench, unmodified | **420 / 420**, 3,954,518 transactions (0 and 2 link stages) |
| Cycle identity with P22's crossbar | **24 / 24** byte-identical transaction traces (`sfs_xbar` and `sfn_xbar` as the central stage) |
| P31 die regression with the spine | **9 / 10** runs; HPC (firmware boot + 188 on-die and 21 host checks) 4 / 4. The one miss is P31's held-request coverage point (`accreset`), which P31 itself waives for its other buffering fabric; 0 functional check failures in 3,675 checks; 0 spine assertion messages |
| Lint | 9 / 9 legal parameter sets with 0 warnings (Verilator `-Wall`, Icarus, Yosys); 12 / 12 illegal sets refused at elaboration |
| Formal | **27 / 27 jobs as expected**: **16 unbounded proofs** (link pipeline ×6, traffic-class map ×3, QoS arbiter ≡ P22 ×4, central stage ≡ P22 crossbar ×2, 2 × 2 spine without link stages incl. bounded liveness); 2 × 2 spines **with** link stages ×3 **bounded only** (13–16 cycles); **8 / 8 mutants caught** |

Per-job formal results: reports/formal.md. The P22 crossbar and the P22 QoS arbiter keep their P22 proofs; the spine's
re-timed arbiter and crossbar are **proved equivalent** to them (unbounded), so those proofs carry over.

What the system proofs do and do not cover. The 2 × 2 spine **without** link stages (`spine_single`) is proved
unbounded for E1–E5, including the bounded-liveness property E5 (every request accepted and every non-posted request
answered within B = 48 cycles under the stated environment assumptions). With link stages (`spine_mixed`,
`spine_all1`, `spine_buf1`) PDR did not converge within its 1200 s budget, so E1–E4 and the new "no completion
discarded" check hold to the BMC depth (13–16 cycles bit level, 6 word level). E5 cannot fail before cycle 48, so for
these three jobs liveness rests on simulation (watchdog in every run, every run completing) and on the composition
argument: every link is proved unbounded to be a lossless, in-order, non-blocking ready/valid channel (K1–K5) and the
spine with stages differs from the proved 0-stage spine only by those links. That composition is an argument, not a
machine-checked proof.

