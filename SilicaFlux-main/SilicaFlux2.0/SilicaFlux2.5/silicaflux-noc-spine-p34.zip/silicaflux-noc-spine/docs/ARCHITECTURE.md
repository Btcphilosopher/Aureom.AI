# Architecture of the DataFabric spine

## 1. Block diagram

```
                    ┌──────────────────────────── silicaflux_noc_spine ─────────────────────────────┐
 SFB3 master m ───► │ sfs_mnode[m]                      central routing stage        sfs_tnode[t]  │ ───► SFB3 target t
                    │  sfs_tc_map ─► sfn_mst_port ─► sfs_link (MST_PIPE[m]) ─► ┌─────────┐ ─► sfs_link (TGT_PIPE[t]) │
                    │  (class,      (decode, O1-O3,                             │ sfs_xbar│                          │
                    │   level)       FENCE, DECERR,  ◄─ sfs_link (MST_PIPE[m]) ◄│ (P22    │◄─ sfs_link (TGT_PIPE[t]) │ ◄─── responses
 responses     ◄─── │               orphans)                                    │ crossbar)│                         │
                    │                                                           └─────────┘                          │
                    │  sfn_perf (NOC_PERF page) + sfs_perf (SPINE_PERF page) + sfs_spine_assert (simulation)         │
                    └────────────────────────────────────────────────────────────────────────────────────────────────┘
```

* **Master attachment node** (`sfs_mnode`): every per-master rule happens next to the master, before the long
  wires — classification (`sfs_tc_map`), then P22's `sfn_mst_port` unmodified (address decode with the access
  matrix, outstanding limit O1, one-target-per-ID O2, FENCE O3, local DECERR/FENCE responder, posted-write
  retirement, orphan containment), then the request link. Responses come back through the response link into
  `sfn_mst_port`.
* **Central routing stage** (`sfs_xbar`, or P22's `sfn_xbar` with `CENTRAL = 0`): one QoS arbiter per target over
  the masters whose link head addresses it, one round-robin arbiter per master over the responding targets,
  one-hot multiplexers. Any set of disjoint master→target pairs moves in the same cycle.
* **Target attachment node** (`sfs_tnode`): the target's request and response links.
* **Links** (`sfs_link`): `STAGES` × P22 `sfn_fifo` (`BUF_DEPTH` entries) per direction; 0 stages = wires.

With all `PIPE = 0` the spine is P22's crossbar exactly (same RTL, proved-equivalent arbiter; byte-identical
transaction traces under P22's own testbench: reports/regression.md "identity").

## 2. Why a segmented crossbar and not a registered multistage NoC

See docs/PHYSICAL.md §2 for the physical side. In summary, against the brief's "smallest solution that meets the
functional requirements":

| Requirement | Segmented crossbar (spine) | Registered mesh |
|---|---|---|
| every region reaches every target it may | yes (access matrix) | yes |
| contention handling, fairness bound | per-target QoS arbiter, STARVE + NM − 1 | per-router arbitration; bound per hop, compounded over hops |
| registered boundaries where needed | per link, as many as the wire needs | at every hop |
| logic (reports/synth.md) | smaller | several times larger |
| bandwidth under die traffic (reports/bench.md E4) | higher | lower |
| fits the floorplan's co-located SRAM slices | yes | no (one target per router) |

## 3. Clocking and reset

One clock domain, as P31's fabric: asynchronous reset assertion, synchronous release by the SoC reset
synchroniser; reset cancels all in-flight transactions including link contents (P22 R11). The external-memory
bridge's own CDC (P31 `EXTMEM_ASYNC`) is outside the spine. Link stages are plain flops in the same domain:
pipelining is used instead of mesochronous or asynchronous links, which would need CDC FIFOs and are not justified
by the evidence (the whole spine closes as one synchronous domain at the central-stage-limited clock).

## 4. Deadlock freedom and liveness

**Assumptions** (the same as P22's, docs/DEADLOCK.md there):

* A1 masters accept every response within finite time, independent of their own requests (P22 M1);
* A2 targets answer every accepted request within finite time and accept requests within finite time once their
  responses drain (P22 R5);
* A3 one clock, reset applied to the whole fabric.

**Argument.**

1. *Separate networks.* Requests and responses never share a buffer, a link stage or an arbiter. The response
   network's progress depends only on masters draining (A1): every response stage drains into the next, the central
   response arbiters are round robin with grant lock (bound NT − 1), and the master node always accepts a legitimate
   response or consumes an orphan. Hence every response in the network reaches its master in bounded time.
2. *Requests.* A request at the head of a master link waits at the central stage for (a) its arbitration turn —
   bounded by STARVE + NM − 1 acceptances at that target — and (b) a free entry in the target link, which frees when
   the target accepts, which happens (A2) once the target's responses drain, which they do by 1. Every link stage
   moves its head entry when the next stage has room (`sfn_fifo`), so no request waits forever.
3. *No cyclic dependency.* The only dependency from the response side to the request side is the node's outstanding
   accounting (a request may wait for an earlier transaction to retire, O1/O2/O3) — and retirement depends only on
   the response network (1). There is no dependency from requests back into responses except through targets (A2).
4. *Pipelining cannot create a deadlock.* Link stages are FIFOs with ready/valid on both sides: they add buffering
   but no new dependency edge, and the outstanding count is taken at the node, so a full link can never hold the only
   copy of a retirement the node is waiting for (a response is never queued behind a request).

**Checked:** formally (`fv_sfs_spine` E5: under A1/A2 with fairness bounds `K`/`LAT`, every presented request is
accepted and every accepted non-posted request is answered within `B` cycles — unbounded proof or BMC depth as in
reports/formal.md) and in simulation by a watchdog in every run (no handshake for 4000 cycles with work pending =
failure), including saturation, hotspot, 15-stage links, BUF_DEPTH 1 and reset during traffic.

## 5. Parameters and limits

| Parameter | Range | Default (HPC) |
|---|---|---|
| `NM`, `NT` | 1..32, 1..64 | 10, 11 |
| `AW`, `DW`, `IDW` | 8..64, 32/64/128/256, 1..8 | 32, 32, 2 |
| `BUF_DEPTH` | 1..16 | 2 |
| `MST_PIPE[m]`, `TGT_PIPE[t]` | 0..15 | from placement evidence |
| `MAXO_MAX`, `MST_MAXO[m]` | ≥ 1 | 8; CC 2, HOST 2, DMA 8, VEC 4, TSU 8 |
| `ARB_MODE` | 0 fixed (may starve), 1 round robin, 2 QoS + aging | 2 |
| `STARVE` | 0..255 | 8 |
| `TC_MODE`, `TC_QOS` | 0/1, 3 × 3 bits | 1, CTRL 3 / RD 2 / WR 1 |
| `MST_CTRL`, `TGT_MMIO` | bit masks | CC, HOST / REGS, EXTCSR |
| `CENTRAL` | 0 P22 `sfn_xbar`, 1 `sfs_xbar` | 1 |
| `PERF` | 0/1 | 1 |

Illegal parameter sets stop elaboration (`$fatal` in simulation: overlapping windows, base outside its mask, MAXO
out of range, stages > 15, …).
