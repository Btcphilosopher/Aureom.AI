# Limitations and honest status

* **No physical design was run.** OpenROAD could not be installed in this environment (the conda package
  install was refused by the session's permission policy). There is no placement, routing, parasitic extraction,
  clock tree or sign-off STA. Every frequency in this project is a **synthesis-level estimate**: ABC static timing of
  the sky130 HD mapped logic (a real tool result, but without wires) plus an Elmore estimate of repeated wires on
  **conceptual** distances read off the floorplan illustration. docs/PHYSICAL.md §7 says what replaces the estimate
  once the flow runs; `scripts/placement.py` takes the routed numbers as inputs.
* **Technology.** sky130 HD is the only liberty available. The floorplan illustration is labelled "2 nm class";
  nothing is claimed for that node. The stage counts are therefore valid for sky130 at the estimated clock; the
  reach-per-cycle sensitivity table (reports/placement.md §5) shows how they scale.
* **Area** numbers are sums of sky130 standard-cell areas from synthesis (no utilisation, no routing, no
  SRAM). Generic NAND2-equivalents (P22 method) are given for comparison with earlier SilicaFlux reports.
* **Floorplan coordinates** are read off an illustration (≈0.1 mm), the route detour (×1.15) and the clock margin
  (10 %) are assumptions stated in config/silicaflux_floorplan.yaml.
* **Endpoints in the spine testbench are models** (`sfs_tb_target`: memories with configured latency,
  back-pressure, out-of-order answers, error windows, fault injection). The real endpoints are exercised by
  P31's die-level regression with the spine dropped in (reports/p31_integration.md); P31's own limitations
  apply there (simulation host bridge, behavioural external-memory controller model, no PHYs).
* **Formal scope.** Link pipeline, class map and the equivalence of the central stage with P22 are proved
  unbounded. The system harness is a 2 × 2 spine with 8-bit data / addresses and 1-bit IDs: **without** link stages
  it is proved unbounded (including liveness); **with** link stages (3 variants) the proofs did not converge
  (PDR budget 1200 s) and hold only to 13–16 cycles of BMC — too short to exercise the 48-cycle liveness bound, so
  liveness with link stages rests on simulation plus the per-link proofs (docs/VERIFICATION.md §6). Liveness is a
  bounded-response property under explicit fairness assumptions on the environment, not an unconditional temporal
  property.
* **Fault injection with link stages** is restricted to unambiguous faults (sources that can never reach the target,
  or out-of-range sources; docs/VERIFICATION.md §5). In four dense synthetic configurations (`syn_m4t4_mix3`,
  `syn_m4t4_p15`, `syn_m8t8_id3_rr_b1`, `syn_m5t6_sfb2`) no such fault exists, so their `spurious` / `spur_bad` runs
  inject nothing; containment is covered by the HPC configurations, four other synthetic ones and P22's testbench at
  0 stages.
* **P31 coverage point.** One P31 V2 run (seed 2) misses P31's `accreset` coverage point (one of up to 160
  accelerator resets must land on a request held by the fabric) — a timing coincidence that buffering fabrics shift;
  P31 waives the same point for its own buffered mesh. Of the extra seeds run by hand, seed 5 hits it and seed 4
  misses it; no functional check failed (reports/p31_integration.md).
* **Counter pages** observe the datapath through registers: SPINE_PERF counts link events one cycle and class events
  two / three cycles after they happen (exactly modelled by the testbench). The NOC_PERF latency sample is P22's
  (one transaction per master at a time).
* **Not implemented:** multicast and coherence (shown in the illustration's spine label) — SFB3 has no coherence and
  P22 documented none; mesochronous / asynchronous links; virtual channels; bursts as single transactions (bursts are
  streams of single-beat transactions with several outstanding).
* **Icarus** elaborates the spine RTL (with assertions), but the testbench uses `$sformatf` in parameters
  (inherited from P22's testbench), which Icarus 12 cannot evaluate, so simulation runs use Verilator 5.020 only.
* Delivered as an archive; **nothing was committed** to the repository.
