// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_qos_arbiter -- QoS arbiter, parallel levels
//
// SAME FUNCTION as P22's sfn_qos_arbiter (cycle for cycle, every output): the
// equivalence is proved unbounded in formal/fv_sfs_qos_equiv.sv (miter against the
// unmodified P22 module).  Only the structure differs -- the timing evidence of
// reports/synth.md showed the P22 arbiter's sequential "highest level" comparator
// chain to be the critical path of the central routing stage:
//   * P22: top = max over requesters, computed by an N-long chain of compare / select;
//          elig[i] = req[i] && lvl[i] == top; round robin by rotate, find, add, modulo;
//   * here: per-level request vectors are formed in parallel, a requester is eligible
//          when no requester is present at a strictly higher level (suffix OR over the
//          9 levels); the round-robin choice is "first eligible at or after the pointer,
//          else first eligible" (two priority encoders, no adder / modulo).
// Selection rules, guarantee and ports: see sfn_qos_arbiter (lock while stalled; aging to
// URGENT after STARVE acceptances of others; bound STARVE + N - 1 acceptances).
// =============================================================================
`default_nettype none

module sfs_qos_arbiter #(
  parameter int N      = 4,
  parameter int STARVE = 8,
  localparam int QW    = sfn_pkg::QOSW,
  localparam int IW    = sfn_pkg::clog2c(N),
  localparam int AGW   = sfn_pkg::clog2c(STARVE + 1),
  localparam int NL    = (1 << QW) + 1          // levels 0..7 + URGENT
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic [N-1:0]    req,
  input  wire logic [N*QW-1:0] qos,
  input  wire logic            stall,
  input  wire logic            accept,
  output logic      [N-1:0]    grant,
  output logic      [IW-1:0]   grant_idx,
  output logic                 grant_valid,
  output logic      [N-1:0]    urgent
);
  logic [IW-1:0]    prio_q;
  logic             lock_q;
  logic [IW-1:0]    lock_idx_q;
  logic [N*AGW-1:0] age_q;

  logic [N*NL-1:0]  lvl_oh;       // requester i at level L (masked by req)
  logic [NL-1:0]    any_lvl;      // some requester at level L
  logic [NL-1:0]    higher;       // some requester above level L
  logic [N-1:0]     elig, elig_hi;
  logic [IW-1:0]    idx_hi, idx_any;
  logic             f_hi, f_any;

  always_comb begin
    for (int i = 0; i < N; i++) begin
      urgent[i] = (age_q[i*AGW +: AGW] >= AGW'(STARVE));
      for (int l = 0; l < NL; l++)
        lvl_oh[i*NL + l] = req[i] && (urgent[i] ? (l == NL - 1) : (32'(qos[i*QW +: QW]) == l));
    end
    for (int l = 0; l < NL; l++) begin
      any_lvl[l] = 1'b0;
      for (int i = 0; i < N; i++) any_lvl[l] = any_lvl[l] | lvl_oh[i*NL + l];
    end
    higher[NL-1] = 1'b0;
    for (int l = NL - 2; l >= 0; l--) higher[l] = higher[l+1] | any_lvl[l+1];
    for (int i = 0; i < N; i++) begin
      elig[i] = 1'b0;
      for (int l = 0; l < NL; l++) elig[i] = elig[i] | (lvl_oh[i*NL + l] & ~higher[l]);
      elig_hi[i] = elig[i] && (IW'(i) >= prio_q);
    end
    // first eligible at or after the pointer, else first eligible overall
    f_hi = 1'b0; idx_hi = '0;
    f_any = 1'b0; idx_any = '0;
    for (int i = N - 1; i >= 0; i--) begin
      if (elig_hi[i]) begin f_hi = 1'b1;  idx_hi = IW'(i);  end
      if (elig[i])    begin f_any = 1'b1; idx_any = IW'(i); end
    end
    if (lock_q && req[lock_idx_q]) begin
      grant_valid = 1'b1;
      grant_idx   = lock_idx_q;
    end else begin
      grant_valid = f_any;
      // nothing eligible: P22 yields the pointer itself (rotate-find-add with offset 0);
      // reproduced so that every output, valid or not, is identical (t_req_src of an idle port)
      grant_idx   = f_hi ? idx_hi : (f_any ? idx_any : prio_q);
    end
    grant = grant_valid ? (N'(1) << grant_idx) : '0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      prio_q     <= '0;
      lock_q     <= 1'b0;
      lock_idx_q <= '0;
      age_q      <= '0;
    end else begin
      lock_q     <= grant_valid && stall && !accept;
      lock_idx_q <= grant_idx;
      if (accept && grant_valid)
        prio_q <= (grant_idx == IW'(N - 1)) ? '0 : grant_idx + IW'(1);
      for (int i = 0; i < N; i++) begin
        if (!req[i] || (accept && grant_valid && grant_idx == IW'(i)))
          age_q[i*AGW +: AGW] <= '0;
        else if (accept && grant_valid && age_q[i*AGW +: AGW] < AGW'(STARVE))
          age_q[i*AGW +: AGW] <= age_q[i*AGW +: AGW] + AGW'(1);
      end
    end
  end
endmodule

`default_nettype wire
