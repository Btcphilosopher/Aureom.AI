// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_tc_map -- request traffic class
//
// Classifies every request at its master attachment node (docs/PROTOCOL.md sec. 6):
//   TC_CTRL : the master is a control master (MST_CTRL, e.g. ControlCore, host)
//             OR the address decodes to a register (MMIO) target (TGT_MMIO);
//   TC_RD   : otherwise OP_READ;
//   TC_WR   : otherwise (OP_WRITE, OP_WRITE_POSTED; FENCE / reserved opcodes and
//             decode misses never reach the central stage, the class is unused).
// The class travels with the request (2 bits) to the central routing stage, where
// it is counted, and -- with TC_MODE = 1 -- selects the arbitration level
// qos_out = TC_QOS[class] used by sfn_qos_arbiter (ARB_MODE = ARB_QOS).
// TC_MODE = 0 passes the master's own req_qos (P22 behaviour).
// The decoder is DataFabric's sfb_addr_decoder, the same instance type that
// sfn_mst_port uses (vendored unmodified); purely combinational.
// =============================================================================
`default_nettype none

module sfs_tc_map #(
  parameter int               NT        = 4,
  parameter int               AW        = 32,
  parameter int               DW        = 32,
  parameter logic [NT*AW-1:0] TGT_BASE  = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK  = {(NT*AW){1'b0}},
  parameter logic [NT-1:0]    EN        = {NT{1'b1}},
  parameter logic [NT-1:0]    TGT_MMIO  = {NT{1'b0}},
  parameter logic             MST_CTRL  = 1'b0,
  parameter int               TC_MODE   = 1,
  parameter logic [8:0]       TC_QOS    = sfs_pkg::TC_QOS_DEFAULT,
  localparam int              SW        = (NT > 1) ? $clog2(NT) : 1
) (
  input  wire logic [2:0]    opcode,
  input  wire logic [AW-1:0] addr,
  input  wire logic [2:0]    qos_in,
  output logic      [1:0]    tc,
  output logic      [2:0]    qos_out
);
  logic          hit;
  logic [SW-1:0] sel;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NT-1:0] oh_unused;
  logic          mis_unused;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_addr_decoder #(
    .NS(NT), .AW(AW), .DW(DW), .CHECK_ALIGN(0), .SLV_BASE(TGT_BASE), .SLV_MASK(TGT_MASK), .EN(EN)
  ) u_dec (
    .addr, .hit, .sel, .sel_oh(oh_unused), .misaligned(mis_unused)
  );

  always_comb begin
    if (MST_CTRL || (hit && TGT_MMIO[sel]))  tc = sfs_pkg::TC_CTRL;
    else if (opcode == sfn_pkg::OP_READ)     tc = sfs_pkg::TC_RD;
    else                                      tc = sfs_pkg::TC_WR;
    if (TC_MODE == 0)                qos_out = qos_in;
    else if (tc == sfs_pkg::TC_CTRL) qos_out = TC_QOS[2:0];
    else if (tc == sfs_pkg::TC_RD)   qos_out = TC_QOS[5:3];
    else                             qos_out = TC_QOS[8:6];
  end
endmodule

`default_nettype wire
