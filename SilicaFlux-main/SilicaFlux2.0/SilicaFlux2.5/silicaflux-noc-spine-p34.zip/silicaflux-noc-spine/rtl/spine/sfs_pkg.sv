// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_pkg -- spine constants
//
// The transaction protocol is SFB3 (DataFabric-NoC, Project 22): every opcode,
// status code and QoS constant comes from sfn_pkg (vendored unmodified).  This
// package only adds what the spine itself introduces:
//   * traffic classes (docs/PROTOCOL.md sec. 6) and their default arbitration
//     levels,
//   * limits on the physical pipelining parameters.
// Tool rules inherited from P22: localparams and "assign to the function name"
// functions only, so Verilator 5.020, Icarus 12 and Yosys 0.33 agree.
// =============================================================================
package sfs_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ------------------------------------------------------------------ traffic classes
  // Request classes are carried with every request from the master attachment
  // node to the central routing stage (2 bits); completion / error traffic is the
  // whole response network, which is physically separate from the request network.
  localparam int          TCW      = 2;
  localparam logic [1:0]  TC_CTRL  = 2'd0;   // MMIO: request to a register target, or from a control master
  localparam logic [1:0]  TC_RD    = 2'd1;   // memory read
  localparam logic [1:0]  TC_WR    = 2'd2;   // memory write (acknowledged or posted)
  localparam logic [1:0]  TC_CPL   = 2'd3;   // completion / error (response network) -- never on a request
  localparam int          NTC      = 3;      // request classes counted at the central stage

  // default class -> arbitration level map (sfn_qos_arbiter: larger = more urgent; ages to urgent
  // after STARVE acceptances of others, so no class can block another indefinitely)
  // packed {WR, RD, CTRL} : CTRL 3 (QOS_CTRL), RD 2, WR 1
  localparam logic [8:0]  TC_QOS_DEFAULT = {3'd1, 3'd2, 3'd3};

  // ------------------------------------------------------------------ physical pipelining limits
  localparam int          MAX_STAGES   = 15;   // register stages per link direction
  localparam int          MAX_BUF      = 16;   // entries per stage

  // width of an index into n things (at least 1 bit) -- same rule as sfn_pkg::clog2c
  function automatic integer clog2c(input integer n);
    begin
      if (n > 1) clog2c = $clog2(n);
      else       clog2c = 1;
    end
  endfunction

  /* verilator lint_on UNUSEDPARAM */
endpackage
