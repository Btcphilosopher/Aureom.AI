// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_perf -- spine counter page (SPINE_PERF)
//
// Second 4 KiB register page next to P22's NOC_PERF page (sfn_perf, unmodified),
// same register-bus style (rb_*: combinational read, write on rb_sel && rb_we),
// byte offsets, 32-bit saturating counters:
//   0x000 CTRL      bit0 ENABLE (reset 1), bit1 CLEAR (write 1)  -- the spine writes
//                   CTRL of both pages together (one freeze point, docs/PERFORMANCE.md)
//   0x004 CYCLES    cycles counted while enabled
//   0x008 CONFIG    [7:0] NM [15:8] NT [20:16] BUF_DEPTH [27:24] max stages [29:28] TC_MODE
//   0x00C ID        "SPN1" 0x5350_4E31
//   0x040 + c*0x10  request class c (0 CTRL, 1 RD, 2 WR) at the central routing stage:
//                   +0 ACC  requests accepted   +4 WAIT cycles waiting at the stage
//                   +8 WAIT_MAX longest wait of one request   +C ARB_LOSS cycles lost to another master
//   0x100 + m*0x20  master link m (m < 32):
//                   +0 Q_XFER  requests delivered into the central stage
//                   +4 Q_STALL cycles the node presented and the link was full
//                   +8 Q_OCC_SUM  +C Q_OCC_MAX  request-link entries (sum per cycle / maximum)
//                   +10 R_XFER responses entering the link at the central stage
//                   +14 R_STALL cycles the central stage presented and the link was full
//                   +18 R_OCC_SUM +1C R_OCC_MAX
//   0x600 + m*0x10  central-stage wait of master m: +0 WAIT +4 WAIT_MAX +8 ARB_LOSS
//                   +C TGT_BP (waiting while not losing arbitration: target link full)
//   0x800 + t*0x20  target link t (t < 64): as master links, request direction from the
//                   central stage to the target, response direction from the target
// WAIT counts cycles c_req_valid && !c_req_ready at the central stage (arbitration
// delay); WAIT_MAX is the longest such run ended by an acceptance (16-bit, saturating).
// Unmapped offsets: rb_err.  PERF = 0 in silicaflux_noc_spine removes the page.
//
// TIMING: the page observes the datapath through registers only.  Stage 1 registers every
// observed event (link and port handshakes, stalls, occupancies, the head's class and its
// current wait run); stage 2 reduces stage 1 to per-class counts and per-class maxima of
// groups of four masters; stage 3 takes the maximum over the groups.  Link / port /
// per-master counters therefore count an event one cycle after it happens, per-class
// counts two cycles after, the per-class WAIT_MAX three cycles after; the testbench models
// exactly that (tb_spine).  Without these stages the per-class maximum was a sequential 32-bit
// compare chain over the masters, 12.5 ns in sky130 (reports/synth.md history, docs/PERFORMANCE.md).
// =============================================================================
`default_nettype none

module sfs_perf #(
  parameter int  NM        = 2,
  parameter int  NT        = 2,
  parameter int  OCCW      = 4,
  parameter int  BUF_DEPTH = 2,
  parameter int  MAXST     = 0,
  parameter int  TC_MODE   = 1,
  localparam int NLC       = 8,    // counters per link
  localparam int NWC       = 4,    // counters per master (central-stage wait)
  localparam int NCC       = 4     // counters per class
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              rb_sel,
  input  wire logic              rb_we,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [11:0]       rb_addr,         // word addressed: [1:0] ignored
  input  wire logic [31:0]       rb_wdata,        // only the control bits are used
  /* verilator lint_on UNUSEDSIGNAL */
  output logic      [31:0]       rb_rdata,
  output logic                   rb_err,
  // master links
  input  wire logic [NM-1:0]     mn_req_valid,    // node side
  input  wire logic [NM-1:0]     mn_req_ready,
  input  wire logic [NM-1:0]     mc_req_valid,    // central side
  input  wire logic [NM-1:0]     mc_req_ready,
  input  wire logic [NM*2-1:0]   mc_req_tc,
  input  wire logic [NM-1:0]     mc_arb_loss,
  input  wire logic [NM-1:0]     mc_rsp_valid,    // central side, response link entry
  input  wire logic [NM-1:0]     mc_rsp_ready,
  input  wire logic [NM*OCCW-1:0] m_q_occ,
  input  wire logic [NM*OCCW-1:0] m_r_occ,
  // target links
  input  wire logic [NT-1:0]     tx_req_valid,    // central side
  input  wire logic [NT-1:0]     tx_req_ready,
  input  wire logic [NT-1:0]     tt_rsp_valid,    // target side, response link entry
  input  wire logic [NT-1:0]     tt_rsp_ready,
  input  wire logic [NT*OCCW-1:0] t_q_occ,
  input  wire logic [NT*OCCW-1:0] t_r_occ
);
  localparam int L_QX = 0, L_QS = 1, L_QOS = 2, L_QOM = 3, L_RX = 4, L_RS = 5, L_ROS = 6, L_ROM = 7;
  localparam int W_WAIT = 0, W_MAX = 1, W_LOSS = 2, W_TBP = 3;
  localparam int C_ACC = 0, C_WAIT = 1, C_MAX = 2, C_LOSS = 3;
  localparam int RW  = 16;                              // wait-run width (saturating)
  localparam int PCW = sfs_pkg::clog2c(NM + 1);         // per-class count of one cycle
  localparam int NG  = (NM + 3) / 4;                     // groups of four masters (class maximum)

  logic        en_q;
  logic [31:0] cyc_q;
  logic [NM*NLC*32-1:0] ml_q;
  logic [NT*NLC*32-1:0] tl_q;
  logic [NM*NWC*32-1:0] mw_q;
  logic [3*NCC*32-1:0]  cc_q;
  logic [NM*RW-1:0]     run_q;      // current wait run per master (always tracked)

  // stage 1: registered observations
  logic [NM-1:0]      s1_mqx, s1_mqs, s1_mrx, s1_mrs, s1_wait, s1_lossw;
  logic [NM*2-1:0]    s1_tc;
  logic [NM*RW-1:0]   s1_run;
  logic [NM*OCCW-1:0] s1_mqo, s1_mro;
  logic [NT-1:0]      s1_tqx, s1_tqs, s1_trx, s1_trs;
  logic [NT*OCCW-1:0] s1_tqo, s1_tro;
  // stage 2: per-class reductions of stage 1
  logic [3*PCW-1:0]   s2_acc, s2_wait, s2_loss;
  logic [3*NG*RW-1:0] s2_gmx;        // per class, per group of four masters
  // stage 3: per-class maximum over the groups
  logic [3*RW-1:0]    s3_mx;

  wire ctrl_wr = rb_sel && rb_we && (rb_addr[11:2] == 10'h000);
  wire clear   = ctrl_wr && rb_wdata[1];

  function automatic logic [31:0] sat_add(input logic [31:0] a, input logic [31:0] b);
    logic [32:0] s;
    begin
      s = {1'b0, a} + {1'b0, b};
      sat_add = s[32] ? 32'hFFFF_FFFF : s[31:0];
    end
  endfunction

  function automatic logic [RW-1:0] max4(input logic [4*RW-1:0] v);
    logic [RW-1:0] a, b;
    begin
      a = (v[0 +: RW] >= v[RW +: RW]) ? v[0 +: RW] : v[RW +: RW];
      b = (v[2*RW +: RW] >= v[3*RW +: RW]) ? v[2*RW +: RW] : v[3*RW +: RW];
      max4 = (a >= b) ? a : b;
    end
  endfunction

  function automatic logic [RW-1:0] gmax(input logic [NG*RW-1:0] v);
    logic [32*RW-1:0] a;
    begin
      a = '0;
      for (int i = 0; i < NG; i++) a[i*RW +: RW] = v[i*RW +: RW];
      for (int l = 0; l < 3; l++)
        for (int i = 0; i < (4 >> l); i++)
          a[i*RW +: RW] = (a[(2*i)*RW +: RW] >= a[(2*i+1)*RW +: RW]) ? a[(2*i)*RW +: RW] : a[(2*i+1)*RW +: RW];
      gmax = a[0 +: RW];
    end
  endfunction

  function automatic logic [PCW-1:0] popc(input logic [NM-1:0] v);
    begin
      popc = '0;
      for (int i = 0; i < NM; i++) popc = popc + PCW'(v[i]);
    end
  endfunction

  // ---------------------------------------------------------------- read mux
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_addr[11:6] == 6'd0) begin
      case (rb_addr[5:2])
        4'd0: rb_rdata = {31'd0, en_q};
        4'd1: rb_rdata = cyc_q;
        4'd2: rb_rdata = {2'd0, 2'(TC_MODE), 4'(MAXST), 3'd0, 5'(BUF_DEPTH), 8'(NT), 8'(NM)};
        4'd3: rb_rdata = 32'h5350_4E31;
        default: rb_err = rb_sel;
      endcase
    end else if (rb_addr[11:8] == 4'h0) begin
      // classes: 0x040 + c*0x10, c < 3
      if (rb_addr[7:4] >= 4'd4 && rb_addr[7:4] < 4'd7)
        rb_rdata = cc_q[((32'(rb_addr[7:4]) - 32'd4) * NCC + 32'(rb_addr[3:2])) * 32 +: 32];
      else
        rb_err = rb_sel;
    end else if (rb_addr[11] == 1'b0 && rb_addr[10:9] != 2'b11) begin
      // master links: 0x100 + m*0x20  (0x100 .. 0x5FF)
      if (rb_addr[10:5] >= 6'd8 && (32'(rb_addr[10:5]) - 32'd8) < NM)
        rb_rdata = ml_q[((32'(rb_addr[10:5]) - 32'd8) * NLC + 32'(rb_addr[4:2])) * 32 +: 32];
      else
        rb_err = rb_sel;
    end else if (rb_addr[11] == 1'b0) begin
      // master central-stage wait: 0x600 + m*0x10  (0x600 .. 0x7FF)
      if (32'(rb_addr[8:4]) < NM)
        rb_rdata = mw_q[(32'(rb_addr[8:4]) * NWC + 32'(rb_addr[3:2])) * 32 +: 32];
      else
        rb_err = rb_sel;
    end else begin
      // target links: 0x800 + t*0x20
      if (32'(rb_addr[10:5]) < NT)
        rb_rdata = tl_q[(32'(rb_addr[10:5]) * NLC + 32'(rb_addr[4:2])) * 32 +: 32];
      else
        rb_err = rb_sel;
    end
  end

  // ---------------------------------------------------------------- stage 2 inputs (from stage 1 registers)
  logic [3*PCW-1:0]  cls_acc, cls_wait, cls_loss;
  logic [3*NG*RW-1:0] cls_gmx;
  logic [3*RW-1:0]    cls_mx;
  logic [3*NM-1:0]   acc_m, wait_m, loss_m;
  logic [3*NG*4*RW-1:0] runs;          // per class, NG*4 slots (unused slots 0)
  always_comb begin
    runs = '0;
    for (int c = 0; c < 3; c++) begin
      for (int m = 0; m < NM; m++) begin
        acc_m[c*NM + m]  = s1_mqx[m]   && (32'(s1_tc[m*2 +: 2]) == c);
        wait_m[c*NM + m] = s1_wait[m]  && (32'(s1_tc[m*2 +: 2]) == c);
        loss_m[c*NM + m] = s1_lossw[m] && (32'(s1_tc[m*2 +: 2]) == c);
        runs[(c*NG*4 + m)*RW +: RW] = acc_m[c*NM + m] ? s1_run[m*RW +: RW] : '0;
      end
      cls_acc[c*PCW +: PCW]  = popc(acc_m[c*NM +: NM]);
      cls_wait[c*PCW +: PCW] = popc(wait_m[c*NM +: NM]);
      cls_loss[c*PCW +: PCW] = popc(loss_m[c*NM +: NM]);
      for (int g = 0; g < NG; g++)
        cls_gmx[(c*NG + g)*RW +: RW] = max4(runs[(c*NG*4 + g*4)*RW +: 4*RW]);
      cls_mx[c*RW +: RW]     = gmax(s2_gmx[c*NG*RW +: NG*RW]);      // stage 3 input
    end
  end

  // ---------------------------------------------------------------- pipeline + counters
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q   <= 1'b1;
      cyc_q  <= '0;
      ml_q   <= '0;
      tl_q   <= '0;
      mw_q   <= '0;
      cc_q   <= '0;
      run_q  <= '0;
      s1_mqx <= '0; s1_mqs <= '0; s1_mrx <= '0; s1_mrs <= '0; s1_wait <= '0; s1_lossw <= '0;
      s1_tc  <= '0; s1_run <= '0; s1_mqo <= '0; s1_mro <= '0;
      s1_tqx <= '0; s1_tqs <= '0; s1_trx <= '0; s1_trs <= '0; s1_tqo <= '0; s1_tro <= '0;
      s2_acc <= '0; s2_wait <= '0; s2_loss <= '0; s2_gmx <= '0; s3_mx <= '0;
    end else begin
      if (ctrl_wr) en_q <= rb_wdata[0];
      // ---- wait runs (state) and stage 1: every cycle
      for (int m = 0; m < NM; m++) begin
        if (mc_req_valid[m] && !mc_req_ready[m])
          run_q[m*RW +: RW] <= (run_q[m*RW +: RW] == {RW{1'b1}}) ? run_q[m*RW +: RW] : run_q[m*RW +: RW] + RW'(1);
        else
          run_q[m*RW +: RW] <= '0;
      end
      s1_mqx   <= mc_req_valid & mc_req_ready;
      s1_mqs   <= mn_req_valid & ~mn_req_ready;
      s1_mrx   <= mc_rsp_valid & mc_rsp_ready;
      s1_mrs   <= mc_rsp_valid & ~mc_rsp_ready;
      s1_wait  <= mc_req_valid & ~mc_req_ready;
      s1_lossw <= mc_req_valid & ~mc_req_ready & mc_arb_loss;
      s1_tc    <= mc_req_tc;
      s1_run   <= run_q;
      s1_mqo   <= m_q_occ;
      s1_mro   <= m_r_occ;
      s1_tqx   <= tx_req_valid & tx_req_ready;
      s1_tqs   <= tx_req_valid & ~tx_req_ready;
      s1_trx   <= tt_rsp_valid & tt_rsp_ready;
      s1_trs   <= tt_rsp_valid & ~tt_rsp_ready;
      s1_tqo   <= t_q_occ;
      s1_tro   <= t_r_occ;
      // ---- stage 2: every cycle
      s2_acc   <= cls_acc;
      s2_wait  <= cls_wait;
      s2_loss  <= cls_loss;
      s2_gmx   <= cls_gmx;
      s3_mx    <= cls_mx;
      if (clear) begin
        cyc_q <= '0;
        ml_q  <= '0;
        tl_q  <= '0;
        mw_q  <= '0;
        cc_q  <= '0;
      end else if (en_q) begin
        cyc_q <= sat_add(cyc_q, 32'd1);
        for (int m = 0; m < NM; m++) begin
          // ---- link (events of the previous cycle)
          if (s1_mqx[m]) ml_q[(m*NLC+L_QX)*32 +: 32] <= sat_add(ml_q[(m*NLC+L_QX)*32 +: 32], 32'd1);
          if (s1_mqs[m]) ml_q[(m*NLC+L_QS)*32 +: 32] <= sat_add(ml_q[(m*NLC+L_QS)*32 +: 32], 32'd1);
          ml_q[(m*NLC+L_QOS)*32 +: 32] <= sat_add(ml_q[(m*NLC+L_QOS)*32 +: 32], 32'(s1_mqo[m*OCCW +: OCCW]));
          if (32'(s1_mqo[m*OCCW +: OCCW]) > ml_q[(m*NLC+L_QOM)*32 +: 32])
            ml_q[(m*NLC+L_QOM)*32 +: 32] <= 32'(s1_mqo[m*OCCW +: OCCW]);
          if (s1_mrx[m]) ml_q[(m*NLC+L_RX)*32 +: 32] <= sat_add(ml_q[(m*NLC+L_RX)*32 +: 32], 32'd1);
          if (s1_mrs[m]) ml_q[(m*NLC+L_RS)*32 +: 32] <= sat_add(ml_q[(m*NLC+L_RS)*32 +: 32], 32'd1);
          ml_q[(m*NLC+L_ROS)*32 +: 32] <= sat_add(ml_q[(m*NLC+L_ROS)*32 +: 32], 32'(s1_mro[m*OCCW +: OCCW]));
          if (32'(s1_mro[m*OCCW +: OCCW]) > ml_q[(m*NLC+L_ROM)*32 +: 32])
            ml_q[(m*NLC+L_ROM)*32 +: 32] <= 32'(s1_mro[m*OCCW +: OCCW]);
          // ---- central-stage wait
          if (s1_wait[m]) begin
            mw_q[(m*NWC+W_WAIT)*32 +: 32] <= sat_add(mw_q[(m*NWC+W_WAIT)*32 +: 32], 32'd1);
            if (s1_lossw[m]) mw_q[(m*NWC+W_LOSS)*32 +: 32] <= sat_add(mw_q[(m*NWC+W_LOSS)*32 +: 32], 32'd1);
            else             mw_q[(m*NWC+W_TBP)*32 +: 32]  <= sat_add(mw_q[(m*NWC+W_TBP)*32 +: 32], 32'd1);
          end
          if (s1_mqx[m] && 32'(s1_run[m*RW +: RW]) > mw_q[(m*NWC+W_MAX)*32 +: 32])
            mw_q[(m*NWC+W_MAX)*32 +: 32] <= 32'(s1_run[m*RW +: RW]);
        end
        // ---- classes (counts: events of two cycles ago; maximum: three cycles ago)
        for (int c = 0; c < 3; c++) begin
          cc_q[(c*NCC+C_ACC)*32 +: 32]  <= sat_add(cc_q[(c*NCC+C_ACC)*32 +: 32], 32'(s2_acc[c*PCW +: PCW]));
          cc_q[(c*NCC+C_WAIT)*32 +: 32] <= sat_add(cc_q[(c*NCC+C_WAIT)*32 +: 32], 32'(s2_wait[c*PCW +: PCW]));
          if (32'(s3_mx[c*RW +: RW]) > cc_q[(c*NCC+C_MAX)*32 +: 32]) cc_q[(c*NCC+C_MAX)*32 +: 32] <= 32'(s3_mx[c*RW +: RW]);
          cc_q[(c*NCC+C_LOSS)*32 +: 32] <= sat_add(cc_q[(c*NCC+C_LOSS)*32 +: 32], 32'(s2_loss[c*PCW +: PCW]));
        end
        for (int t = 0; t < NT; t++) begin
          if (s1_tqx[t]) tl_q[(t*NLC+L_QX)*32 +: 32] <= sat_add(tl_q[(t*NLC+L_QX)*32 +: 32], 32'd1);
          if (s1_tqs[t]) tl_q[(t*NLC+L_QS)*32 +: 32] <= sat_add(tl_q[(t*NLC+L_QS)*32 +: 32], 32'd1);
          tl_q[(t*NLC+L_QOS)*32 +: 32] <= sat_add(tl_q[(t*NLC+L_QOS)*32 +: 32], 32'(s1_tqo[t*OCCW +: OCCW]));
          if (32'(s1_tqo[t*OCCW +: OCCW]) > tl_q[(t*NLC+L_QOM)*32 +: 32])
            tl_q[(t*NLC+L_QOM)*32 +: 32] <= 32'(s1_tqo[t*OCCW +: OCCW]);
          if (s1_trx[t]) tl_q[(t*NLC+L_RX)*32 +: 32] <= sat_add(tl_q[(t*NLC+L_RX)*32 +: 32], 32'd1);
          if (s1_trs[t]) tl_q[(t*NLC+L_RS)*32 +: 32] <= sat_add(tl_q[(t*NLC+L_RS)*32 +: 32], 32'd1);
          tl_q[(t*NLC+L_ROS)*32 +: 32] <= sat_add(tl_q[(t*NLC+L_ROS)*32 +: 32], 32'(s1_tro[t*OCCW +: OCCW]));
          if (32'(s1_tro[t*OCCW +: OCCW]) > tl_q[(t*NLC+L_ROM)*32 +: 32])
            tl_q[(t*NLC+L_ROM)*32 +: 32] <= 32'(s1_tro[t*OCCW +: OCCW]);
        end
      end
    end
  end

`ifndef SYNTHESIS
  initial begin
    if (NM > 32) $fatal(1, "sfs_perf: NM=%0d > 32 does not fit the register page", NM);
    if (NT > 64) $fatal(1, "sfs_perf: NT=%0d > 64 does not fit the register page", NT);
  end
`endif
endmodule

`default_nettype wire
