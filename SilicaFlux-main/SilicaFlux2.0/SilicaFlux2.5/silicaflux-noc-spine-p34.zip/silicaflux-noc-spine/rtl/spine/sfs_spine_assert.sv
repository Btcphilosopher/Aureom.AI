// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: in-RTL assertions (simulation only)
//
// Instantiated by silicaflux_noc_spine under `ifndef SYNTHESIS.  Immediate
// checks in clocked blocks (identical behaviour in Verilator 5.020 and Icarus 12,
// which has no concurrent assertions); every failure prints $display("ASSERT ...")
// and increments `errors`, which the testbench requires to be 0.
//
//   sfs_link_check  (one per link and direction, 2*(NM+NT) instances) -- an
//                   independent shadow FIFO of the link:
//     L1 no lost transaction : shadow count == link occupancy every cycle
//     L2 no duplicate        : an entry leaves only if one entered and is pending
//     L3 order + integrity   : the leaving entry equals the oldest pending one, bit for bit
//     L4 FIFO safety         : occupancy <= STAGES * BUF_DEPTH
//     L5 stable under stall  : out_valid && !out_ready -> same entry presented next cycle
//   sfs_spine_assert
//     S1 legal destination at the central stage: target index < NT, access matrix,
//        address inside the target's window, opcode forwarded to targets only
//     S2 legal destination at every target port: source < NM, access matrix, window
//     S3 stable payload under stall on every fabric-driven port: central -> target link,
//        target port, master response port
//     S4 conservation per master: outstanding == accepted (tracked) - retired
//     S5 no duplicated / unexpected response: per (master, ID) retirements never
//        exceed tracked acceptances; posted completions never reach a master
//     S6 outstanding limit per master (O1)
//     S7 reset: no fabric output valid and nothing accepted while reset is asserted
// =============================================================================
`default_nettype none
/* verilator lint_off BLKSEQ */
/* verilator lint_off UNUSEDSIGNAL */
/* verilator lint_off SYNCASYNCNET */

module sfs_link_check #(
  parameter int  W    = 8,
  parameter int  CAP  = 2,
  parameter int  OCCW = 8,
  parameter int  KIND = 0,         // 0 master request link, 1 master response link, 2 target request, 3 target response
  parameter int  IDX  = 0          // port index (numeric: Icarus 12 cannot format strings in parameters)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            in_valid,
  input  wire logic            in_ready,
  input  wire logic [W-1:0]    in_data,
  input  wire logic            out_valid,
  input  wire logic            out_ready,
  input  wire logic [W-1:0]    out_data,
  input  wire logic [OCCW-1:0] occ,
  output int                   errors
);
  localparam int N = (CAP > 0) ? CAP + 1 : 1;
  function automatic string nm();
    nm = $sformatf("%s%0d.%s_link", (KIND < 2) ? "m" : "t", IDX, (KIND % 2 == 0) ? "req" : "rsp");
  endfunction
  logic [W-1:0] sh [N];
  int           rd, wr, n;
  logic         held;
  logic [W-1:0] held_d;

  initial errors = 0;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd = 0; wr = 0; n = 0;
      held <= 1'b0;
    end else if (CAP == 0) begin
      // a wire: the two ends must be identical
      if (in_valid !== out_valid || in_ready !== out_ready || (in_valid && in_data !== out_data)) begin
        $display("ASSERT %s: wire link ends differ", nm());
        errors <= errors + 1;
      end
    end else begin
      if (n != int'(occ)) begin
        $display("ASSERT %s L1: shadow holds %0d entries, link reports %0d (lost or invented entry)", nm(), n, occ);
        errors <= errors + 1;
      end
      if (n > CAP) begin
        $display("ASSERT %s L4: %0d entries > capacity %0d", nm(), n, CAP);
        errors <= errors + 1;
      end
      if (held && (!out_valid || out_data !== held_d)) begin
        $display("ASSERT %s L5: presented entry withdrawn or changed while stalled", nm());
        errors <= errors + 1;
      end
      if (out_valid && out_ready) begin
        if (n == 0) begin
          $display("ASSERT %s L2: entry delivered with nothing pending (duplicate)", nm());
          errors <= errors + 1;
        end else begin
          if (out_data !== sh[rd]) begin
            $display("ASSERT %s L3: delivered entry differs from the oldest pending one (order / integrity)", nm());
            errors <= errors + 1;
          end
          rd = (rd + 1) % N;
          n  = n - 1;
        end
      end
      if (in_valid && in_ready) begin
        sh[wr] = in_data;
        wr = (wr + 1) % N;
        n  = n + 1;
      end
      held   <= out_valid && !out_ready;
      held_d <= out_data;
    end
  end
endmodule

module sfs_spine_assert #(
  parameter int               NM         = 2,
  parameter int               NT         = 2,
  parameter int               AW         = 32,
  parameter int               DW         = 32,
  parameter int               IDW        = 2,
  parameter int               CW         = 3,
  parameter int               OCCW       = 8,
  parameter logic [NT*AW-1:0] TGT_BASE   = '0,
  parameter logic [NT*AW-1:0] TGT_MASK   = '0,
  parameter logic [NM*NT-1:0] MST_TGT_EN = '1,
  parameter logic [NM*8-1:0]  MST_MAXO   = '0,
  parameter logic [NM*4-1:0]  MST_PIPE   = '0,
  parameter logic [NT*4-1:0]  TGT_PIPE   = '0,
  parameter int               BUF_DEPTH  = 2,
  localparam int              SB         = DW / 8,
  localparam int              TW         = sfn_pkg::clog2c(NT + 1),
  localparam int              SRCW       = sfn_pkg::clog2c(NM),
  localparam int              NID        = 1 << IDW,
  localparam int              QPW        = 2 + TW + 3 + IDW + 3 + AW + DW + SB,
  localparam int              RPW        = TW + IDW + 3 + 2 + DW,
  localparam int              TQW        = 3 + SRCW + IDW + 3 + AW + DW + SB,
  localparam int              TRW        = SRCW + IDW + 3 + 2 + DW
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic [NM-1:0]      m_req_valid,
  input  wire logic [NM-1:0]      m_req_ready,
  input  wire logic [NM*3-1:0]    m_req_opcode,
  input  wire logic [NM*IDW-1:0]  m_req_id,
  input  wire logic [NM*AW-1:0]   m_req_addr,
  input  wire logic [NM*DW-1:0]   m_req_wdata,
  input  wire logic [NM*SB-1:0]   m_req_wstrb,
  input  wire logic [NM-1:0]      m_rsp_valid,
  input  wire logic [NM-1:0]      m_rsp_ready,
  input  wire logic [NM*IDW-1:0]  m_rsp_id,
  input  wire logic [NM*3-1:0]    m_rsp_opcode,
  input  wire logic [NM*2-1:0]    m_rsp_status,
  input  wire logic [NM*DW-1:0]   m_rsp_rdata,
  input  wire logic [NM-1:0]      n_req_valid,
  input  wire logic [NM-1:0]      n_req_ready,
  input  wire logic [NM*QPW-1:0]  n_req_data,
  input  wire logic [NM-1:0]      n_rsp_valid,
  input  wire logic [NM-1:0]      n_rsp_ready,
  input  wire logic [NM*RPW-1:0]  n_rsp_data,
  input  wire logic [NM-1:0]      c_req_valid,
  input  wire logic [NM-1:0]      c_req_ready,
  input  wire logic [NM*TW-1:0]   c_req_tgt,
  input  wire logic [NM*2-1:0]    c_req_tc,
  input  wire logic [NM*3-1:0]    c_req_opcode,
  input  wire logic [NM*IDW-1:0]  c_req_id,
  input  wire logic [NM*3-1:0]    c_req_qos,
  input  wire logic [NM*AW-1:0]   c_req_addr,
  input  wire logic [NM*DW-1:0]   c_req_wdata,
  input  wire logic [NM*SB-1:0]   c_req_wstrb,
  input  wire logic [NM-1:0]      c_rsp_valid,
  input  wire logic [NM-1:0]      c_rsp_ready,
  input  wire logic [NM*TW-1:0]   c_rsp_tgt,
  input  wire logic [NM*IDW-1:0]  c_rsp_id,
  input  wire logic [NM*3-1:0]    c_rsp_opcode,
  input  wire logic [NM*2-1:0]    c_rsp_status,
  input  wire logic [NM*DW-1:0]   c_rsp_rdata,
  input  wire logic [NT-1:0]      x_req_valid,
  input  wire logic [NT-1:0]      x_req_ready,
  input  wire logic [NT*3-1:0]    x_req_opcode,
  input  wire logic [NT*SRCW-1:0] x_req_src,
  input  wire logic [NT*IDW-1:0]  x_req_id,
  input  wire logic [NT*3-1:0]    x_req_qos,
  input  wire logic [NT*AW-1:0]   x_req_addr,
  input  wire logic [NT*DW-1:0]   x_req_wdata,
  input  wire logic [NT*SB-1:0]   x_req_wstrb,
  input  wire logic [NT-1:0]      x_rsp_valid,
  input  wire logic [NT-1:0]      x_rsp_ready,
  input  wire logic [NT*SRCW-1:0] x_rsp_src,
  input  wire logic [NT*IDW-1:0]  x_rsp_id,
  input  wire logic [NT*3-1:0]    x_rsp_opcode,
  input  wire logic [NT*2-1:0]    x_rsp_status,
  input  wire logic [NT*DW-1:0]   x_rsp_rdata,
  input  wire logic [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  input  wire logic [NT*3-1:0]    t_req_opcode,
  input  wire logic [NT*SRCW-1:0] t_req_src,
  input  wire logic [NT*IDW-1:0]  t_req_id,
  input  wire logic [NT*3-1:0]    t_req_qos,
  input  wire logic [NT*AW-1:0]   t_req_addr,
  input  wire logic [NT*DW-1:0]   t_req_wdata,
  input  wire logic [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  input  wire logic [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  input  wire logic [NM*CW-1:0]   out_cnt,
  input  wire logic [NM-1:0]      ev_decerr,
  input  wire logic [NM-1:0]      ev_posted_done,
  input  wire logic [NM*OCCW-1:0] mq_occ,
  input  wire logic [NM*OCCW-1:0] mr_occ,
  input  wire logic [NT*OCCW-1:0] tq_occ,
  input  wire logic [NT*OCCW-1:0] tr_occ,
  output int                      errors
);
  // ================================================================ link checkers
  int le_mq [NM], le_mr [NM], le_tq [NT], le_tr [NT];
  for (genvar m = 0; m < NM; m++) begin : g_ml
    localparam int CAP = 32'(MST_PIPE[m*4 +: 4]) * BUF_DEPTH;
    sfs_link_check #(.W(QPW), .CAP(CAP), .OCCW(OCCW), .KIND(0), .IDX(m)) u_q (
      .clk, .rst_n, .in_valid(n_req_valid[m]), .in_ready(n_req_ready[m]), .in_data(n_req_data[m*QPW +: QPW]),
      .out_valid(c_req_valid[m]), .out_ready(c_req_ready[m]),
      .out_data({c_req_tc[m*2 +: 2], c_req_tgt[m*TW +: TW], c_req_opcode[m*3 +: 3], c_req_id[m*IDW +: IDW],
                 c_req_qos[m*3 +: 3], c_req_addr[m*AW +: AW], c_req_wdata[m*DW +: DW], c_req_wstrb[m*SB +: SB]}),
      .occ(mq_occ[m*OCCW +: OCCW]), .errors(le_mq[m]));
    sfs_link_check #(.W(RPW), .CAP(CAP), .OCCW(OCCW), .KIND(1), .IDX(m)) u_r (
      .clk, .rst_n, .in_valid(c_rsp_valid[m]), .in_ready(c_rsp_ready[m]),
      .in_data({c_rsp_tgt[m*TW +: TW], c_rsp_id[m*IDW +: IDW], c_rsp_opcode[m*3 +: 3], c_rsp_status[m*2 +: 2],
                c_rsp_rdata[m*DW +: DW]}),
      .out_valid(n_rsp_valid[m]), .out_ready(n_rsp_ready[m]), .out_data(n_rsp_data[m*RPW +: RPW]),
      .occ(mr_occ[m*OCCW +: OCCW]), .errors(le_mr[m]));
  end
  for (genvar t = 0; t < NT; t++) begin : g_tl
    localparam int CAP = 32'(TGT_PIPE[t*4 +: 4]) * BUF_DEPTH;
    sfs_link_check #(.W(TQW), .CAP(CAP), .OCCW(OCCW), .KIND(2), .IDX(t)) u_q (
      .clk, .rst_n, .in_valid(x_req_valid[t]), .in_ready(x_req_ready[t]),
      .in_data({x_req_opcode[t*3 +: 3], x_req_src[t*SRCW +: SRCW], x_req_id[t*IDW +: IDW], x_req_qos[t*3 +: 3],
                x_req_addr[t*AW +: AW], x_req_wdata[t*DW +: DW], x_req_wstrb[t*SB +: SB]}),
      .out_valid(t_req_valid[t]), .out_ready(t_req_ready[t]),
      .out_data({t_req_opcode[t*3 +: 3], t_req_src[t*SRCW +: SRCW], t_req_id[t*IDW +: IDW], t_req_qos[t*3 +: 3],
                 t_req_addr[t*AW +: AW], t_req_wdata[t*DW +: DW], t_req_wstrb[t*SB +: SB]}),
      .occ(tq_occ[t*OCCW +: OCCW]), .errors(le_tq[t]));
    sfs_link_check #(.W(TRW), .CAP(CAP), .OCCW(OCCW), .KIND(3), .IDX(t)) u_r (
      .clk, .rst_n, .in_valid(t_rsp_valid[t]), .in_ready(t_rsp_ready[t]),
      .in_data({t_rsp_src[t*SRCW +: SRCW], t_rsp_id[t*IDW +: IDW], t_rsp_opcode[t*3 +: 3], t_rsp_status[t*2 +: 2],
                t_rsp_rdata[t*DW +: DW]}),
      .out_valid(x_rsp_valid[t]), .out_ready(x_rsp_ready[t]),
      .out_data({x_rsp_src[t*SRCW +: SRCW], x_rsp_id[t*IDW +: IDW], x_rsp_opcode[t*3 +: 3], x_rsp_status[t*2 +: 2],
                 x_rsp_rdata[t*DW +: DW]}),
      .occ(tr_occ[t*OCCW +: OCCW]), .errors(le_tr[t]));
  end

  // ================================================================ spine-level checks
  function automatic int win(input logic [AW-1:0] a);
    win = -1;
    for (int t = NT - 1; t >= 0; t--)
      if ((a & TGT_MASK[t*AW +: AW]) == TGT_BASE[t*AW +: AW]) win = t;
  endfunction

  int own_err;
  int acc_n [NM], ret_n [NM];
  int idc [NM*NID];
  logic [NT-1:0]  xh, th;
  logic [NM-1:0]  mh;
  logic [NT*(3+SRCW+IDW+3+AW+DW+SB)-1:0] xh_d, th_d;
  logic [NM*(IDW+3+2+DW)-1:0] mh_d;
  initial begin
    own_err = 0;
    for (int m = 0; m < NM; m++) begin acc_n[m] = 0; ret_n[m] = 0; end
    for (int i = 0; i < NM*NID; i++) idc[i] = 0;
  end

  task automatic bad(input string msg);
    $display("ASSERT %s", msg);
    own_err = own_err + 1;
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int m = 0; m < NM; m++) begin acc_n[m] = 0; ret_n[m] = 0; end
      for (int i = 0; i < NM*NID; i++) idc[i] = 0;
      xh <= '0; th <= '0; mh <= '0;
    end else begin
      // ---------------------------------------------------- S1 legal destination at the central stage
      for (int m = 0; m < NM; m++) if (c_req_valid[m]) begin
        int tg;
        tg = int'(c_req_tgt[m*TW +: TW]);
        if (tg >= NT) bad($sformatf("S1 m%0d: request at the central stage for target index %0d >= NT", m, tg));
        else begin
          if (!MST_TGT_EN[m*NT + tg]) bad($sformatf("S1 m%0d: request for t%0d denied by the access matrix", m, tg));
          if (win(c_req_addr[m*AW +: AW]) != tg)
            bad($sformatf("S1 m%0d: address %h is not in the window of t%0d", m, c_req_addr[m*AW +: AW], tg));
        end
        if (!sfn_pkg::op_to_target(c_req_opcode[m*3 +: 3]))
          bad($sformatf("S1 m%0d: opcode %0d is not forwarded to targets", m, c_req_opcode[m*3 +: 3]));
      end
      // ---------------------------------------------------- S2 legal destination at every target port
      for (int t = 0; t < NT; t++) if (t_req_valid[t]) begin
        int s;
        s = int'(t_req_src[t*SRCW +: SRCW]);
        if (s >= NM) bad($sformatf("S2 t%0d: source %0d >= NM", t, s));
        else if (!MST_TGT_EN[s*NT + t]) bad($sformatf("S2 t%0d: source m%0d not allowed here", t, s));
        if (win(t_req_addr[t*AW +: AW]) != t) bad($sformatf("S2 t%0d: address %h outside its window", t, t_req_addr[t*AW +: AW]));
        if (!sfn_pkg::op_to_target(t_req_opcode[t*3 +: 3])) bad($sformatf("S2 t%0d: illegal opcode", t));
      end
      // ---------------------------------------------------- S3 stability of fabric-driven ports
      for (int t = 0; t < NT; t++) begin
        if (xh[t] && (!x_req_valid[t] || xh_d[t*TQW +: TQW] !== {x_req_opcode[t*3 +: 3], x_req_src[t*SRCW +: SRCW],
            x_req_id[t*IDW +: IDW], x_req_qos[t*3 +: 3], x_req_addr[t*AW +: AW], x_req_wdata[t*DW +: DW], x_req_wstrb[t*SB +: SB]}))
          bad($sformatf("S3 central stage -> t%0d link: request withdrawn or changed while stalled", t));
        if (th[t] && (!t_req_valid[t] || th_d[t*TQW +: TQW] !== {t_req_opcode[t*3 +: 3], t_req_src[t*SRCW +: SRCW],
            t_req_id[t*IDW +: IDW], t_req_qos[t*3 +: 3], t_req_addr[t*AW +: AW], t_req_wdata[t*DW +: DW], t_req_wstrb[t*SB +: SB]}))
          bad($sformatf("S3 target port t%0d: request withdrawn or changed while stalled", t));
        xh[t] <= x_req_valid[t] && !x_req_ready[t];
        th[t] <= t_req_valid[t] && !t_req_ready[t];
        xh_d[t*TQW +: TQW] <= {x_req_opcode[t*3 +: 3], x_req_src[t*SRCW +: SRCW], x_req_id[t*IDW +: IDW], x_req_qos[t*3 +: 3],
                               x_req_addr[t*AW +: AW], x_req_wdata[t*DW +: DW], x_req_wstrb[t*SB +: SB]};
        th_d[t*TQW +: TQW] <= {t_req_opcode[t*3 +: 3], t_req_src[t*SRCW +: SRCW], t_req_id[t*IDW +: IDW], t_req_qos[t*3 +: 3],
                               t_req_addr[t*AW +: AW], t_req_wdata[t*DW +: DW], t_req_wstrb[t*SB +: SB]};
      end
      for (int m = 0; m < NM; m++) begin
        if (mh[m] && (!m_rsp_valid[m] || mh_d[m*(IDW+3+2+DW) +: (IDW+3+2+DW)] !==
            {m_rsp_id[m*IDW +: IDW], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2], m_rsp_rdata[m*DW +: DW]}))
          bad($sformatf("S3 master port m%0d: response withdrawn or changed while stalled", m));
        mh[m] <= m_rsp_valid[m] && !m_rsp_ready[m];
        mh_d[m*(IDW+3+2+DW) +: (IDW+3+2+DW)] <= {m_rsp_id[m*IDW +: IDW], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2],
                                                 m_rsp_rdata[m*DW +: DW]};
      end
      // ---------------------------------------------------- S4 / S5 / S6 per-master conservation
      for (int m = 0; m < NM; m++) begin
        logic post_drop;
        if (int'(out_cnt[m*CW +: CW]) != acc_n[m] - ret_n[m])
          bad($sformatf("S4 m%0d: %0d outstanding, but %0d tracked acceptances - %0d retirements", m,
                        out_cnt[m*CW +: CW], acc_n[m], ret_n[m]));
        if (int'(out_cnt[m*CW +: CW]) > 32'(MST_MAXO[m*8 +: 8]))
          bad($sformatf("S6 m%0d: %0d outstanding > limit %0d", m, out_cnt[m*CW +: CW], MST_MAXO[m*8 +: 8]));
        if (m_rsp_valid[m] && m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED)
          bad($sformatf("S5 m%0d: posted-write completion presented to the master", m));
        // retirements this cycle: a delivered response, or a posted completion retired at the node
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          int i;
          i = m * NID + int'(m_rsp_id[m*IDW +: IDW]);
          if (idc[i] == 0) bad($sformatf("S5 m%0d: response for ID %0d with nothing outstanding (duplicate)", m, m_rsp_id[m*IDW +: IDW]));
          idc[i] = idc[i] - 1;
          ret_n[m] = ret_n[m] + 1;
        end
        if (ev_posted_done[m]) begin
          int i;
          i = m * NID + int'(n_rsp_data[m*RPW + 2 + 3 + DW +: IDW]);
          if (idc[i] == 0) bad($sformatf("S5 m%0d: posted completion for ID with nothing outstanding", m));
          idc[i] = idc[i] - 1;
          ret_n[m] = ret_n[m] + 1;
        end
        post_drop = ev_decerr[m] && (m_req_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED);
        if (m_req_valid[m] && m_req_ready[m] && !post_drop) begin
          idc[m * NID + int'(m_req_id[m*IDW +: IDW])] = idc[m * NID + int'(m_req_id[m*IDW +: IDW])] + 1;
          acc_n[m] = acc_n[m] + 1;
        end
      end
    end
  end

  // ---------------------------------------------------- S7 reset
  int rst_err;
  initial rst_err = 0;
  always @(posedge clk) begin
    if (!rst_n && ((|t_req_valid) || (|m_rsp_valid) || (|(m_req_valid & m_req_ready)) || (|c_req_valid) || (|x_req_valid))) begin
      $display("ASSERT S7 fabric output valid or transfer during reset");
      rst_err = rst_err + 1;
    end
  end

  always_comb begin
    errors = own_err + rst_err;
    for (int m = 0; m < NM; m++) errors = errors + le_mq[m] + le_mr[m];
    for (int t = 0; t < NT; t++) errors = errors + le_tq[t] + le_tr[t];
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = &{1'b0, m_req_addr, m_req_wdata, m_req_wstrb, m_rsp_status, m_rsp_rdata, c_rsp_status};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

/* verilator lint_on SYNCASYNCNET */
/* verilator lint_on UNUSEDSIGNAL */
/* verilator lint_on BLKSEQ */
`default_nettype wire
