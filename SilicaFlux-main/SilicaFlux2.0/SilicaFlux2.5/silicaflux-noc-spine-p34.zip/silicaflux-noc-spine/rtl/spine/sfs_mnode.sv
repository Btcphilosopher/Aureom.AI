// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_mnode -- master attachment node
//
// Placed in the master's floorplan region (ControlCore, host I/O, DMA, vector or
// tensor cluster).  Everything that belongs to ONE master is done here, next to
// the master, before the long wires of the spine:
//
//   SFB3 master ──► sfs_tc_map (class, arbitration level)
//               ──► sfn_mst_port (P22, UNMODIFIED: decode, access matrix,
//                   alignment, outstanding limit O1, one-target-per-ID O2,
//                   FENCE O3, local DECERR / FENCE responder, posted-write
//                   retirement, orphan containment)
//               ──► sfs_link  request, PIPE stages ──► central routing stage
//   SFB3 master ◄── sfn_mst_port ◄── sfs_link response, PIPE stages ◄──┘
//
// Because the per-master rules are enforced at the node (before the pipeline),
// pipelining the link cannot change them: outstanding transactions are counted
// at acceptance into the link, and a response can only reach the node after the
// request it answers was counted (no false orphan, no lost retirement).
// =============================================================================
`default_nettype none

module sfs_mnode #(
  parameter int               NT          = 4,
  parameter int               AW          = 32,
  parameter int               DW          = 32,
  parameter int               IDW         = 2,
  parameter int               MAXO_MAX    = 4,
  parameter int               MAXO        = 4,
  parameter int               CHECK_ALIGN = 1,
  parameter logic [NT*AW-1:0] TGT_BASE    = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK    = {(NT*AW){1'b0}},
  parameter logic [NT-1:0]    EN          = {NT{1'b1}},
  parameter logic [NT-1:0]    TGT_MMIO    = {NT{1'b0}},
  parameter logic             MST_CTRL    = 1'b0,
  parameter int               TC_MODE     = 1,
  parameter logic [8:0]       TC_QOS      = sfs_pkg::TC_QOS_DEFAULT,
  parameter int               PIPE        = 0,       // register stages per link direction
  parameter int               BUF_DEPTH   = 2,       // entries per stage
  localparam int              SB          = DW / 8,
  localparam int              TW          = sfn_pkg::clog2c(NT + 1),
  localparam int              CW          = sfn_pkg::clog2c(MAXO_MAX + 1),
  localparam int              QPW         = 2 + TW + 3 + IDW + 3 + AW + DW + SB,  // request link payload
  localparam int              RPW         = TW + IDW + 3 + 2 + DW,                // response link payload
  localparam int              OCCW        = sfs_pkg::clog2c(PIPE * BUF_DEPTH + 1)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // ------------------------------------------------------------ SFB3 master port
  input  wire logic           m_req_valid,
  output logic                m_req_ready,
  input  wire logic [2:0]     m_req_opcode,
  input  wire logic [IDW-1:0] m_req_id,
  input  wire logic [2:0]     m_req_qos,
  input  wire logic [AW-1:0]  m_req_addr,
  input  wire logic [DW-1:0]  m_req_wdata,
  input  wire logic [SB-1:0]  m_req_wstrb,
  output logic                m_rsp_valid,
  input  wire logic           m_rsp_ready,
  output logic [IDW-1:0]      m_rsp_id,
  output logic [2:0]          m_rsp_opcode,
  output logic [1:0]          m_rsp_status,
  output logic [DW-1:0]       m_rsp_rdata,
  // ------------------------------------------------------------ central-stage side of the link
  output logic                c_req_valid,
  input  wire logic           c_req_ready,
  output logic [TW-1:0]       c_req_tgt,
  output logic [1:0]          c_req_tc,
  output logic [2:0]          c_req_opcode,
  output logic [IDW-1:0]      c_req_id,
  output logic [2:0]          c_req_qos,
  output logic [AW-1:0]       c_req_addr,
  output logic [DW-1:0]       c_req_wdata,
  output logic [SB-1:0]       c_req_wstrb,
  input  wire logic           c_rsp_valid,
  output logic                c_rsp_ready,
  input  wire logic [TW-1:0]  c_rsp_tgt,
  input  wire logic [IDW-1:0] c_rsp_id,
  input  wire logic [2:0]     c_rsp_opcode,
  input  wire logic [1:0]     c_rsp_status,
  input  wire logic [DW-1:0]  c_rsp_rdata,
  // ------------------------------------------------------------ status / events (node side)
  output logic                n_req_valid,     // request presented to the link at the node
  output logic                n_req_ready,     // ... and accepted by it
  output logic [QPW-1:0]      n_req_data,      // link input payload (observation / assertions)
  output logic                n_rsp_valid,     // response leaving the link at the node
  output logic                n_rsp_ready,
  output logic [RPW-1:0]      n_rsp_data,
  output logic [CW-1:0]       out_cnt,
  output logic                id_idle,
  output logic                ev_blk_out,
  output logic                ev_blk_id,
  output logic                ev_blk_fence,
  output logic                ev_decerr,
  output logic                ev_posted_done,
  output logic                ev_posted_err,
  output logic                ev_orphan,
  output logic [OCCW-1:0]     q_occ,           // request-link entries
  output logic [OCCW-1:0]     r_occ            // response-link entries
);
  // ================================================================ traffic class
  logic [1:0] tc;
  logic [2:0] qos;
  sfs_tc_map #(
    .NT(NT), .AW(AW), .DW(DW), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .EN(EN), .TGT_MMIO(TGT_MMIO),
    .MST_CTRL(MST_CTRL), .TC_MODE(TC_MODE), .TC_QOS(TC_QOS)
  ) u_tc (
    .opcode(m_req_opcode), .addr(m_req_addr), .qos_in(m_req_qos), .tc, .qos_out(qos)
  );

  // ================================================================ per-master front end (P22, unmodified)
  logic           fq_valid, fq_ready, fr_valid, fr_ready;
  logic [TW-1:0]  fq_tgt, fr_tgt;
  logic [2:0]     fq_opcode, fr_opcode, fq_qos;
  logic [IDW-1:0] fq_id, fr_id;
  logic [AW-1:0]  fq_addr;
  logic [DW-1:0]  fq_wdata, fr_rdata;
  logic [SB-1:0]  fq_wstrb;
  logic [1:0]     fr_status;

  sfn_mst_port #(
    .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .MAXO_MAX(MAXO_MAX), .MAXO(MAXO), .CHECK_ALIGN(CHECK_ALIGN),
    .RETIRE_BYPASS(0), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .EN(EN)
  ) u_mp (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos(qos), .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .fq_valid, .fq_ready, .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
    .fr_valid, .fr_ready, .fr_tgt, .fr_id, .fr_opcode, .fr_status, .fr_rdata,
    .out_cnt, .id_idle, .ev_blk_out, .ev_blk_id, .ev_blk_fence, .ev_decerr, .ev_posted_done, .ev_posted_err, .ev_orphan
  );

  // the class follows the request that the port presents: sfn_mst_port forwards m_req_* unchanged
  // (fq_opcode = m_req_opcode, fq_addr = m_req_addr), so tc is that request's class
  assign n_req_valid = fq_valid;
  assign n_req_ready = fq_ready;
  assign n_req_data  = {tc, fq_tgt, fq_opcode, fq_id, fq_qos, fq_addr, fq_wdata, fq_wstrb};
  assign n_rsp_valid = fr_valid;
  assign n_rsp_ready = fr_ready;
  assign n_rsp_data  = {fr_tgt, fr_id, fr_opcode, fr_status, fr_rdata};

  // ================================================================ request link
  sfs_link #(.W(QPW), .STAGES(PIPE), .DEPTH(BUF_DEPTH)) u_qlink (
    .clk, .rst_n,
    .in_valid(fq_valid), .in_ready(fq_ready),
    .in_data(n_req_data),
    .out_valid(c_req_valid), .out_ready(c_req_ready),
    .out_data({c_req_tc, c_req_tgt, c_req_opcode, c_req_id, c_req_qos, c_req_addr, c_req_wdata, c_req_wstrb}),
    .occ(q_occ)
  );

  // ================================================================ response link
  sfs_link #(.W(RPW), .STAGES(PIPE), .DEPTH(BUF_DEPTH)) u_rlink (
    .clk, .rst_n,
    .in_valid(c_rsp_valid), .in_ready(c_rsp_ready),
    .in_data({c_rsp_tgt, c_rsp_id, c_rsp_opcode, c_rsp_status, c_rsp_rdata}),
    .out_valid(fr_valid), .out_ready(fr_ready),
    .out_data({fr_tgt, fr_id, fr_opcode, fr_status, fr_rdata}),
    .occ(r_occ)
  );
endmodule

`default_nettype wire
