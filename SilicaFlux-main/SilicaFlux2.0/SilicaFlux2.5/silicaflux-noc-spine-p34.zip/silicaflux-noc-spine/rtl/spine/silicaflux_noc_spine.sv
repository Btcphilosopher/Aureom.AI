// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: silicaflux_noc_spine -- DataFabric spine
//
// The central communication spine of the SilicaFlux die floorplan
// ("DataFabric NoC / Interconnect Spine", docs/ARCHITECTURE.md): ONE central
// routing stage on the spine, local attachment nodes in every die region, and
// register stages on the long attachment links where the floorplan needs them.
//
//   master region                       spine                         target region
//   ┌──────────────┐  MST_PIPE[m]  ┌──────────────────┐  TGT_PIPE[t]  ┌──────────────┐
//   │ sfs_mnode    │══ stages ════►│ sfs_xbar (= P22  │══ stages ════►│ sfs_tnode    │
//   │  tc map      │               │ sfn_xbar, proved)│               │  (links)     │
//   │  sfn_mst_port│◄═ stages ═════│ arbiter / target │◄═ stages ═════│              │
//   └──────────────┘               │ arbiter / master │               └──────────────┘
//                                  └──────────────────┘
//
// Reuse: sfn_mst_port, sfn_fifo, sfn_perf (P22 DataFabric-NoC) and sfb_arbiter /
// sfb_addr_decoder (DataFabric) are instantiated UNMODIFIED; the central stage is
// sfs_xbar (P22's sfn_xbar with the parallel-level QoS arbiter sfs_qos_arbiter, both
// proved cycle-equivalent to P22's, formal/fv_sfs_*_equiv.sv) or, with CENTRAL = 0,
// sfn_xbar itself.  The spine adds the link pipeline (sfs_link), the traffic-class map
// (sfs_tc_map), the attachment nodes and a second counter page (sfs_perf).
// With every MST_PIPE / TGT_PIPE = 0 the spine is the P22 crossbar, cycle for
// cycle (byte-identical transaction traces: reports/regression.md, "identity").
//
// Protocol: SFB3 (docs/PROTOCOL.md).  Same master / target ports as P22's
// silicaflux_noc, so it is a drop-in replacement (P31 datafabric.sv).
// Parameters:
//   NM, NT          attachment ports (masters, targets)
//   AW, DW, IDW     address, data, transaction-ID width
//   BUF_DEPTH       entries per link register stage (2 = full rate, 1 = half rate)
//   MST_PIPE[m], TGT_PIPE[t]   register stages per link direction (0..15), from the
//                   placement analysis (scripts/placement.py -> sfs_cfg_pkg)
//   MST_MAXO[m]     outstanding limit per master (sized against the round trip)
//   ARB_MODE        P22 arbitration (default ARB_QOS: class levels + aging)
//   CENTRAL         1: sfs_xbar (default), 0: P22 sfn_xbar
//   PERF            1: NOC_PERF (P22) + SPINE_PERF counter pages
//   TC_MODE         1: arbitration level from the request's traffic class
//   MST_CTRL, TGT_MMIO   control masters / register targets (class TC_CTRL)
// One clock domain; asynchronous reset assert, synchronous release; reset
// cancels every transaction in flight, including those held in link stages (R11).
// =============================================================================
`default_nettype none

module silicaflux_noc_spine #(
  parameter int               NM          = 4,
  parameter int               NT          = 4,
  parameter int               AW          = 32,
  parameter int               DW          = 32,
  parameter int               IDW         = 2,
  parameter int               ARB_MODE    = 2,     // sfn_pkg::ARB_QOS
  parameter int               STARVE      = 8,
  parameter int               CHECK_ALIGN = 1,
  parameter logic [NT*AW-1:0] TGT_BASE    = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK    = {(NT*AW){1'b0}},
  parameter logic [NM*NT-1:0] MST_TGT_EN  = {(NM*NT){1'b1}},  // bit m*NT+t
  parameter int               MAXO_MAX    = 4,
  parameter logic [NM*8-1:0]  MST_MAXO    = {NM{8'd4}},
  parameter logic [NM-1:0]    MST_CTRL    = {NM{1'b0}},
  parameter logic [NT-1:0]    TGT_MMIO    = {NT{1'b0}},
  parameter int               TC_MODE     = 1,
  parameter logic [8:0]       TC_QOS      = sfs_pkg::TC_QOS_DEFAULT,
  parameter int               BUF_DEPTH   = 2,
  parameter logic [NM*4-1:0]  MST_PIPE    = {(NM*4){1'b0}},
  parameter logic [NT*4-1:0]  TGT_PIPE    = {(NT*4){1'b0}},
  parameter int               PERF        = 1,
  parameter int               CENTRAL     = 1,     // 1: sfs_xbar (parallel-level QoS arbiter, proved equal),
                                                   // 0: P22 sfn_xbar unmodified
  localparam int              SB          = DW / 8,
  localparam int              TW          = sfn_pkg::clog2c(NT + 1),
  localparam int              SRCW        = sfn_pkg::clog2c(NM),
  localparam int              QW          = sfn_pkg::QOSW,
  localparam int              CW          = sfn_pkg::clog2c(MAXO_MAX + 1),
  localparam int              OCCW        = sfs_pkg::clog2c(sfs_pkg::MAX_STAGES * sfs_pkg::MAX_BUF + 1),
  localparam int              QPW         = 2 + TW + 3 + IDW + 3 + AW + DW + SB,
  localparam int              RPW         = TW + IDW + 3 + 2 + DW
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------------- SFB3 master ports
  input  wire logic [NM-1:0]      m_req_valid,
  output logic      [NM-1:0]      m_req_ready,
  input  wire logic [NM*3-1:0]    m_req_opcode,
  input  wire logic [NM*IDW-1:0]  m_req_id,
  input  wire logic [NM*QW-1:0]   m_req_qos,
  input  wire logic [NM*AW-1:0]   m_req_addr,
  input  wire logic [NM*DW-1:0]   m_req_wdata,
  input  wire logic [NM*SB-1:0]   m_req_wstrb,
  output logic      [NM-1:0]      m_rsp_valid,
  input  wire logic [NM-1:0]      m_rsp_ready,
  output logic      [NM*IDW-1:0]  m_rsp_id,
  output logic      [NM*3-1:0]    m_rsp_opcode,
  output logic      [NM*2-1:0]    m_rsp_status,
  output logic      [NM*DW-1:0]   m_rsp_rdata,
  // ---------------------------------------------------------------- SFB3 target ports
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  // ---------------------------------------------------------------- counter pages / error interrupt
  input  wire logic               rb_sel,          // NOC_PERF page (P22 sfn_perf, unchanged map)
  input  wire logic               rb_sel_spine,    // SPINE_PERF page (sfs_perf)
  input  wire logic               rb_we,
  input  wire logic [11:0]        rb_addr,
  input  wire logic [31:0]        rb_wdata,
  output logic      [31:0]        rb_rdata,
  output logic                    rb_err,
  output logic                    irq_err,
  // ---------------------------------------------------------------- observation (P22 names, node side)
  output logic      [NM-1:0]      obs_sw_valid,    // request presented to the spine at the node
  output logic      [NM-1:0]      obs_sw_ready,    // ... and accepted by the link
  output logic      [NM*CW-1:0]   obs_out_cnt,
  output logic      [NM-1:0]      obs_decerr,
  output logic      [NM-1:0]      obs_posted_err,
  output logic      [NM-1:0]      obs_orphan,
  output logic      [NT-1:0]      obs_bad_src,
  // ---------------------------------------------------------------- observation (central routing stage)
  output logic      [NM-1:0]      obs_c_valid,     // request at the head of master link m, at the stage
  output logic      [NM-1:0]      obs_c_ready,     // ... accepted (granted, target link ready)
  output logic      [NM*TW-1:0]   obs_c_tgt,       // its target
  output logic      [NM*2-1:0]    obs_c_tc,        // its traffic class
  output logic      [NM-1:0]      obs_c_loss,      // presented, another master won its target
  output logic      [NM*OCCW-1:0] obs_mq_occ,      // link occupancies (entries)
  output logic      [NM*OCCW-1:0] obs_mr_occ,
  output logic      [NT*OCCW-1:0] obs_tq_occ,
  output logic      [NT*OCCW-1:0] obs_tr_occ,
  output logic      [NT-1:0]      obs_x_valid,     // central stage -> target link handshake
  output logic      [NT-1:0]      obs_x_ready,
  output logic      [NM-1:0]      obs_cr_valid,    // central stage -> master response link handshake
  output logic      [NM-1:0]      obs_cr_ready,
  output logic      [31:0]        assert_errors    // in-RTL assertion failures (simulation; 0 in synthesis)
);
  genvar gm, gt;

  function automatic int pipe_m(input int m);
    pipe_m = 32'(MST_PIPE[m*4 +: 4]);
  endfunction
  function automatic int pipe_t(input int t);
    pipe_t = 32'(TGT_PIPE[t*4 +: 4]);
  endfunction
  function automatic int max_pipe();
    max_pipe = 0;
    for (int m = 0; m < NM; m++) if (32'(MST_PIPE[m*4 +: 4]) > max_pipe) max_pipe = 32'(MST_PIPE[m*4 +: 4]);
    for (int t = 0; t < NT; t++) if (32'(TGT_PIPE[t*4 +: 4]) > max_pipe) max_pipe = 32'(TGT_PIPE[t*4 +: 4]);
  endfunction

  // ================================================================ master attachment nodes
  logic [NM-1:0]     c_req_valid, c_req_ready, c_rsp_valid, c_rsp_ready;
  logic [NM*TW-1:0]  c_req_tgt, c_rsp_tgt;
  logic [NM*2-1:0]   c_req_tc, c_rsp_status;
  logic [NM*3-1:0]   c_req_opcode, c_rsp_opcode, c_req_qos;
  logic [NM*IDW-1:0] c_req_id, c_rsp_id;
  logic [NM*AW-1:0]  c_req_addr;
  logic [NM*DW-1:0]  c_req_wdata, c_rsp_rdata;
  logic [NM*SB-1:0]  c_req_wstrb;
  logic [NM-1:0]     n_req_valid, n_req_ready;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM*QPW-1:0] n_req_data;      // observation for the assertions (no logic in synthesis)
  logic [NM-1:0]     n_rsp_valid, n_rsp_ready;
  logic [NM*RPW-1:0] n_rsp_data;
  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]     ev_blk_out, ev_blk_id, ev_blk_fence, ev_decerr, ev_posted_done, ev_posted_err, ev_orphan, id_idle;
  /* verilator lint_on UNUSEDSIGNAL */

  for (gm = 0; gm < NM; gm++) begin : g_mn
    localparam int P = pipe_m(gm);
    localparam int LOW = sfs_pkg::clog2c(P * BUF_DEPTH + 1);
    logic [LOW-1:0] qo, ro;
    sfs_mnode #(
      .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .MAXO_MAX(MAXO_MAX), .MAXO(32'(MST_MAXO[gm*8 +: 8])),
      .CHECK_ALIGN(CHECK_ALIGN), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .EN(MST_TGT_EN[gm*NT +: NT]),
      .TGT_MMIO(TGT_MMIO), .MST_CTRL(MST_CTRL[gm]), .TC_MODE(TC_MODE), .TC_QOS(TC_QOS),
      .PIPE(P), .BUF_DEPTH(BUF_DEPTH)
    ) u_node (
      .clk, .rst_n,
      .m_req_valid(m_req_valid[gm]), .m_req_ready(m_req_ready[gm]), .m_req_opcode(m_req_opcode[gm*3 +: 3]),
      .m_req_id(m_req_id[gm*IDW +: IDW]), .m_req_qos(m_req_qos[gm*QW +: QW]), .m_req_addr(m_req_addr[gm*AW +: AW]),
      .m_req_wdata(m_req_wdata[gm*DW +: DW]), .m_req_wstrb(m_req_wstrb[gm*SB +: SB]),
      .m_rsp_valid(m_rsp_valid[gm]), .m_rsp_ready(m_rsp_ready[gm]), .m_rsp_id(m_rsp_id[gm*IDW +: IDW]),
      .m_rsp_opcode(m_rsp_opcode[gm*3 +: 3]), .m_rsp_status(m_rsp_status[gm*2 +: 2]),
      .m_rsp_rdata(m_rsp_rdata[gm*DW +: DW]),
      .c_req_valid(c_req_valid[gm]), .c_req_ready(c_req_ready[gm]), .c_req_tgt(c_req_tgt[gm*TW +: TW]),
      .c_req_tc(c_req_tc[gm*2 +: 2]), .c_req_opcode(c_req_opcode[gm*3 +: 3]), .c_req_id(c_req_id[gm*IDW +: IDW]),
      .c_req_qos(c_req_qos[gm*3 +: 3]), .c_req_addr(c_req_addr[gm*AW +: AW]), .c_req_wdata(c_req_wdata[gm*DW +: DW]),
      .c_req_wstrb(c_req_wstrb[gm*SB +: SB]),
      .c_rsp_valid(c_rsp_valid[gm]), .c_rsp_ready(c_rsp_ready[gm]), .c_rsp_tgt(c_rsp_tgt[gm*TW +: TW]),
      .c_rsp_id(c_rsp_id[gm*IDW +: IDW]), .c_rsp_opcode(c_rsp_opcode[gm*3 +: 3]),
      .c_rsp_status(c_rsp_status[gm*2 +: 2]), .c_rsp_rdata(c_rsp_rdata[gm*DW +: DW]),
      .n_req_valid(n_req_valid[gm]), .n_req_ready(n_req_ready[gm]), .n_req_data(n_req_data[gm*QPW +: QPW]),
      .n_rsp_valid(n_rsp_valid[gm]), .n_rsp_ready(n_rsp_ready[gm]), .n_rsp_data(n_rsp_data[gm*RPW +: RPW]),
      .out_cnt(obs_out_cnt[gm*CW +: CW]), .id_idle(id_idle[gm]),
      .ev_blk_out(ev_blk_out[gm]), .ev_blk_id(ev_blk_id[gm]), .ev_blk_fence(ev_blk_fence[gm]),
      .ev_decerr(ev_decerr[gm]), .ev_posted_done(ev_posted_done[gm]), .ev_posted_err(ev_posted_err[gm]),
      .ev_orphan(ev_orphan[gm]), .q_occ(qo), .r_occ(ro)
    );
    assign obs_mq_occ[gm*OCCW +: OCCW] = OCCW'(qo);
    assign obs_mr_occ[gm*OCCW +: OCCW] = OCCW'(ro);
  end

  // ================================================================ central routing stage (CENTRAL: sfs_xbar / P22 sfn_xbar)
  logic [NT-1:0]      x_req_valid, x_req_ready, x_rsp_valid, x_rsp_ready;
  logic [NT*3-1:0]    x_req_opcode, x_req_qos, x_rsp_opcode;
  logic [NT*SRCW-1:0] x_req_src, x_rsp_src;
  logic [NT*IDW-1:0]  x_req_id, x_rsp_id;
  logic [NT*AW-1:0]   x_req_addr;
  logic [NT*DW-1:0]   x_req_wdata, x_rsp_rdata;
  logic [NT*SB-1:0]   x_req_wstrb;
  logic [NT*2-1:0]    x_rsp_status;
  logic [NM-1:0]      ev_arb_loss;
  logic [NT-1:0]      ev_bad_src;

  if (CENTRAL != 0) begin : g_c1
    sfs_xbar #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE), .MST_TGT_EN(MST_TGT_EN)
    ) u_central (
      .clk, .rst_n,
      .fq_valid(c_req_valid), .fq_ready(c_req_ready), .fq_tgt(c_req_tgt), .fq_opcode(c_req_opcode), .fq_id(c_req_id),
      .fq_qos(c_req_qos), .fq_addr(c_req_addr), .fq_wdata(c_req_wdata), .fq_wstrb(c_req_wstrb),
      .fr_valid(c_rsp_valid), .fr_ready(c_rsp_ready), .fr_tgt(c_rsp_tgt), .fr_id(c_rsp_id), .fr_opcode(c_rsp_opcode),
      .fr_status(c_rsp_status), .fr_rdata(c_rsp_rdata),
      .t_req_valid(x_req_valid), .t_req_ready(x_req_ready), .t_req_opcode(x_req_opcode), .t_req_src(x_req_src),
      .t_req_id(x_req_id), .t_req_qos(x_req_qos), .t_req_addr(x_req_addr), .t_req_wdata(x_req_wdata),
      .t_req_wstrb(x_req_wstrb), .t_rsp_valid(x_rsp_valid), .t_rsp_ready(x_rsp_ready), .t_rsp_src(x_rsp_src),
      .t_rsp_id(x_rsp_id), .t_rsp_opcode(x_rsp_opcode), .t_rsp_status(x_rsp_status), .t_rsp_rdata(x_rsp_rdata),
      .ev_arb_loss, .ev_bad_src
    );

  end else begin : g_c0
    sfn_xbar #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE), .MST_TGT_EN(MST_TGT_EN)
    ) u_central (
      .clk, .rst_n,
      .fq_valid(c_req_valid), .fq_ready(c_req_ready), .fq_tgt(c_req_tgt), .fq_opcode(c_req_opcode), .fq_id(c_req_id),
      .fq_qos(c_req_qos), .fq_addr(c_req_addr), .fq_wdata(c_req_wdata), .fq_wstrb(c_req_wstrb),
      .fr_valid(c_rsp_valid), .fr_ready(c_rsp_ready), .fr_tgt(c_rsp_tgt), .fr_id(c_rsp_id), .fr_opcode(c_rsp_opcode),
      .fr_status(c_rsp_status), .fr_rdata(c_rsp_rdata),
      .t_req_valid(x_req_valid), .t_req_ready(x_req_ready), .t_req_opcode(x_req_opcode), .t_req_src(x_req_src),
      .t_req_id(x_req_id), .t_req_qos(x_req_qos), .t_req_addr(x_req_addr), .t_req_wdata(x_req_wdata),
      .t_req_wstrb(x_req_wstrb), .t_rsp_valid(x_rsp_valid), .t_rsp_ready(x_rsp_ready), .t_rsp_src(x_rsp_src),
      .t_rsp_id(x_rsp_id), .t_rsp_opcode(x_rsp_opcode), .t_rsp_status(x_rsp_status), .t_rsp_rdata(x_rsp_rdata),
      .ev_arb_loss, .ev_bad_src
    );

  end

  // ================================================================ target attachment nodes
  for (gt = 0; gt < NT; gt++) begin : g_tn
    localparam int P = pipe_t(gt);
    localparam int LOW = sfs_pkg::clog2c(P * BUF_DEPTH + 1);
    logic [LOW-1:0] qo, ro;
    sfs_tnode #(.NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .PIPE(P), .BUF_DEPTH(BUF_DEPTH)) u_node (
      .clk, .rst_n,
      .x_req_valid(x_req_valid[gt]), .x_req_ready(x_req_ready[gt]), .x_req_opcode(x_req_opcode[gt*3 +: 3]),
      .x_req_src(x_req_src[gt*SRCW +: SRCW]), .x_req_id(x_req_id[gt*IDW +: IDW]), .x_req_qos(x_req_qos[gt*3 +: 3]),
      .x_req_addr(x_req_addr[gt*AW +: AW]), .x_req_wdata(x_req_wdata[gt*DW +: DW]), .x_req_wstrb(x_req_wstrb[gt*SB +: SB]),
      .x_rsp_valid(x_rsp_valid[gt]), .x_rsp_ready(x_rsp_ready[gt]), .x_rsp_src(x_rsp_src[gt*SRCW +: SRCW]),
      .x_rsp_id(x_rsp_id[gt*IDW +: IDW]), .x_rsp_opcode(x_rsp_opcode[gt*3 +: 3]), .x_rsp_status(x_rsp_status[gt*2 +: 2]),
      .x_rsp_rdata(x_rsp_rdata[gt*DW +: DW]),
      .t_req_valid(t_req_valid[gt]), .t_req_ready(t_req_ready[gt]), .t_req_opcode(t_req_opcode[gt*3 +: 3]),
      .t_req_src(t_req_src[gt*SRCW +: SRCW]), .t_req_id(t_req_id[gt*IDW +: IDW]), .t_req_qos(t_req_qos[gt*QW +: QW]),
      .t_req_addr(t_req_addr[gt*AW +: AW]), .t_req_wdata(t_req_wdata[gt*DW +: DW]), .t_req_wstrb(t_req_wstrb[gt*SB +: SB]),
      .t_rsp_valid(t_rsp_valid[gt]), .t_rsp_ready(t_rsp_ready[gt]), .t_rsp_src(t_rsp_src[gt*SRCW +: SRCW]),
      .t_rsp_id(t_rsp_id[gt*IDW +: IDW]), .t_rsp_opcode(t_rsp_opcode[gt*3 +: 3]), .t_rsp_status(t_rsp_status[gt*2 +: 2]),
      .t_rsp_rdata(t_rsp_rdata[gt*DW +: DW]),
      .q_occ(qo), .r_occ(ro)
    );
    assign obs_tq_occ[gt*OCCW +: OCCW] = OCCW'(qo);
    assign obs_tr_occ[gt*OCCW +: OCCW] = OCCW'(ro);
  end

  // ================================================================ observation
  assign obs_sw_valid   = n_req_valid;
  assign obs_sw_ready   = n_req_ready;
  assign obs_decerr     = ev_decerr;
  assign obs_posted_err = ev_posted_err;
  assign obs_orphan     = ev_orphan;
  assign obs_bad_src    = ev_bad_src;
  assign obs_c_valid    = c_req_valid;
  assign obs_c_ready    = c_req_ready;
  assign obs_c_tgt      = c_req_tgt;
  assign obs_c_tc       = c_req_tc;
  assign obs_c_loss     = ev_arb_loss;
  assign obs_x_valid    = x_req_valid;
  assign obs_x_ready    = x_req_ready;
  assign obs_cr_valid   = c_rsp_valid;
  assign obs_cr_ready   = c_rsp_ready;

  // ================================================================ counter pages
  // A CTRL write (offset 0) to either page is applied to both: one enable / clear point.
  if (PERF != 0) begin : g_perf
    logic        p_rb_err, s_rb_err;
    logic [31:0] p_rb_rdata, s_rb_rdata;
    wire ctrl_wr = rb_we && (rb_addr[11:2] == 10'h000) && (rb_sel || rb_sel_spine);
    sfn_perf #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .MAXO_MAX(MAXO_MAX), .TOPOLOGY(sfn_pkg::TOPO_CROSSBAR)
    ) u_noc_perf (
      .clk, .rst_n, .rb_sel(rb_sel || ctrl_wr), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(p_rb_rdata), .rb_err(p_rb_err),
      .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_addr, .m_req_wstrb, .m_id_idle(id_idle),
      .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status,
      .m_fq_stall(n_req_valid & ~n_req_ready), .m_blk(ev_blk_out | ev_blk_id | ev_blk_fence), .m_out_cnt(obs_out_cnt),
      .m_decerr(ev_decerr), .m_posted_err(ev_posted_err), .m_orphan(ev_orphan),
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_bad_src(ev_bad_src),
      .irq_err
    );
    sfs_perf #(
      .NM(NM), .NT(NT), .OCCW(OCCW), .BUF_DEPTH(BUF_DEPTH), .MAXST(max_pipe()), .TC_MODE(TC_MODE)
    ) u_spine_perf (
      .clk, .rst_n, .rb_sel(rb_sel_spine || ctrl_wr), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(s_rb_rdata),
      .rb_err(s_rb_err),
      .mn_req_valid(n_req_valid), .mn_req_ready(n_req_ready), .mc_req_valid(c_req_valid), .mc_req_ready(c_req_ready),
      .mc_req_tc(c_req_tc), .mc_arb_loss(ev_arb_loss), .mc_rsp_valid(c_rsp_valid), .mc_rsp_ready(c_rsp_ready),
      .m_q_occ(obs_mq_occ), .m_r_occ(obs_mr_occ),
      .tx_req_valid(x_req_valid), .tx_req_ready(x_req_ready), .tt_rsp_valid(t_rsp_valid), .tt_rsp_ready(t_rsp_ready),
      .t_q_occ(obs_tq_occ), .t_r_occ(obs_tr_occ)
    );
    assign rb_rdata = rb_sel_spine ? s_rb_rdata : p_rb_rdata;
    assign rb_err   = (rb_sel && p_rb_err) || (rb_sel_spine && s_rb_err) || (rb_sel && rb_sel_spine);
  end else begin : g_noperf
    assign rb_rdata = 32'd0;
    assign rb_err   = rb_sel || rb_sel_spine;
    assign irq_err  = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_perf = &{1'b0, rb_we, rb_addr, rb_wdata, id_idle, ev_posted_done, ev_blk_out, ev_blk_id, ev_blk_fence};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ================================================================ assertions (simulation only)
`ifndef SYNTHESIS
  sfs_spine_assert #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .CW(CW), .OCCW(OCCW), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK),
    .MST_TGT_EN(MST_TGT_EN), .MST_MAXO(MST_MAXO), .MST_PIPE(MST_PIPE), .TGT_PIPE(TGT_PIPE), .BUF_DEPTH(BUF_DEPTH)
  ) u_assert (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .n_req_valid, .n_req_ready, .n_req_data, .n_rsp_valid, .n_rsp_ready, .n_rsp_data,
    .c_req_valid, .c_req_ready, .c_req_tgt, .c_req_tc, .c_req_opcode, .c_req_id, .c_req_qos, .c_req_addr,
    .c_req_wdata, .c_req_wstrb,
    .c_rsp_valid, .c_rsp_ready, .c_rsp_tgt, .c_rsp_id, .c_rsp_opcode, .c_rsp_status, .c_rsp_rdata,
    .x_req_valid, .x_req_ready, .x_req_opcode, .x_req_src, .x_req_id, .x_req_qos, .x_req_addr, .x_req_wdata,
    .x_req_wstrb,
    .x_rsp_valid, .x_rsp_ready, .x_rsp_src, .x_rsp_id, .x_rsp_opcode, .x_rsp_status, .x_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
    .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
    .out_cnt(obs_out_cnt), .ev_decerr, .ev_posted_done,
    .mq_occ(obs_mq_occ), .mr_occ(obs_mr_occ), .tq_occ(obs_tq_occ), .tr_occ(obs_tr_occ),
    .errors(assert_errors)
  );
`else
  assign assert_errors = 32'd0;
`endif

`ifndef SYNTHESIS
  // ================================================================ elaboration checks
  initial begin
    if (NM < 1 || NT < 1)             $fatal(1, "silicaflux_noc_spine: NM and NT must be >= 1");
    if (NM > 32)                      $fatal(1, "silicaflux_noc_spine: NM=%0d > 32", NM);
    if (NT > 64)                      $fatal(1, "silicaflux_noc_spine: NT=%0d > 64", NT);
    if (AW < 8 || AW > 64)            $fatal(1, "silicaflux_noc_spine: AW=%0d outside 8..64", AW);
    if (DW != 32 && DW != 64 && DW != 128 && DW != 256)
                                      $fatal(1, "silicaflux_noc_spine: DW=%0d not in {32,64,128,256}", DW);
    if (IDW < 1 || IDW > 8)           $fatal(1, "silicaflux_noc_spine: IDW=%0d outside 1..8", IDW);
    if (ARB_MODE < 0 || ARB_MODE > 2) $fatal(1, "silicaflux_noc_spine: ARB_MODE=%0d not in 0..2", ARB_MODE);
    if (STARVE < 0 || STARVE > 255)   $fatal(1, "silicaflux_noc_spine: STARVE=%0d outside 0..255", STARVE);
    if (TC_MODE < 0 || TC_MODE > 1)   $fatal(1, "silicaflux_noc_spine: TC_MODE=%0d not in 0..1", TC_MODE);
    if (TC_MODE == 1 && ARB_MODE != sfn_pkg::ARB_QOS)
      $display("silicaflux_noc_spine: note: TC_MODE=1 sets arbitration levels; they act only with ARB_MODE=ARB_QOS");
    if (BUF_DEPTH < 1 || BUF_DEPTH > sfs_pkg::MAX_BUF)
                                      $fatal(1, "silicaflux_noc_spine: BUF_DEPTH=%0d outside 1..%0d", BUF_DEPTH, sfs_pkg::MAX_BUF);
    for (int m = 0; m < NM; m++) begin
      if (32'(MST_MAXO[m*8 +: 8]) < 1 || 32'(MST_MAXO[m*8 +: 8]) > MAXO_MAX)
        $fatal(1, "silicaflux_noc_spine: MST_MAXO[%0d]=%0d outside 1..MAXO_MAX=%0d", m, MST_MAXO[m*8 +: 8], MAXO_MAX);
      if (32'(MST_PIPE[m*4 +: 4]) > sfs_pkg::MAX_STAGES)
        $fatal(1, "silicaflux_noc_spine: MST_PIPE[%0d] > %0d", m, sfs_pkg::MAX_STAGES);
    end
    for (int a = 0; a < NT; a++)
      for (int b = a + 1; b < NT; b++)
        if ((((TGT_BASE[a*AW +: AW] ^ TGT_BASE[b*AW +: AW]) & TGT_MASK[a*AW +: AW] & TGT_MASK[b*AW +: AW]) == '0))
          $fatal(1, "silicaflux_noc_spine: target windows %0d and %0d overlap", a, b);
    for (int t = 0; t < NT; t++)
      if ((TGT_BASE[t*AW +: AW] & ~TGT_MASK[t*AW +: AW]) != '0)
        $fatal(1, "silicaflux_noc_spine: TGT_BASE[%0d] has bits outside its mask", t);
  end
`endif
endmodule

`default_nettype wire
