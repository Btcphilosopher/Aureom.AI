// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_link -- physical link pipeline
//
// One direction of one attachment link: STAGES register stages between two
// physically separated places (an attachment node and the central routing
// stage).  Each stage is the DataFabric-NoC FIFO sfn_fifo (vendored unmodified,
// proved unbounded in P22: count == pushes - pops, no overflow / underflow, data
// leave in order and unchanged) with DEPTH = BUF_DEPTH entries, PASS_FULL = 0:
//
//   in ──► [stage 0] ──► [stage 1] ──► ... ──► [stage STAGES-1] ──► out
//
//   * forward : out_valid / out_data of a stage come from registers only;
//   * backward: in_ready of a stage is (count != DEPTH), a register compare;
//   so every stage is a complete timing boundary in BOTH directions and no
//   combinational path crosses a stage (ready/valid correctness is preserved:
//   valid never depends on ready, held data stay unchanged -- sfn_fifo).
//   * DEPTH >= 2 sustains one transfer per cycle per stage; DEPTH = 1 halves the
//     link throughput (measured: docs/PHYSICAL.md, reports/bench.md).
//   * STAGES = 0 is a wire (the single-central-stage starting point).
//   * latency: +1 cycle per stage; capacity: STAGES * DEPTH entries.
// occ = entries currently held (sum over stages), for counters and assertions.
// No request can disappear: an entry leaves a stage only with out_valid &&
// out_ready, and enters only with in_valid && in_ready (formal/fv_sfs_link.sv).
// =============================================================================
`default_nettype none

module sfs_link #(
  parameter int  W      = 8,
  parameter int  STAGES = 1,
  parameter int  DEPTH  = 2,
  localparam int OCCW   = sfs_pkg::clog2c(STAGES * DEPTH + 1),
  localparam int CNTW   = sfn_pkg::clog2c(DEPTH + 1)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            in_valid,
  output logic                 in_ready,
  input  wire logic [W-1:0]    in_data,
  output logic                 out_valid,
  input  wire logic            out_ready,
  output logic      [W-1:0]    out_data,
  output logic      [OCCW-1:0] occ
);
  if (STAGES == 0) begin : g_wire
    assign out_valid = in_valid;
    assign in_ready  = out_ready;
    assign out_data  = in_data;
    assign occ       = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_clk = &{1'b0, clk, rst_n};
    /* verilator lint_on UNUSEDSIGNAL */
  end else begin : g_pipe
    logic [STAGES:0]       v, r;
    logic [(STAGES+1)*W-1:0] d;
    logic [STAGES*CNTW-1:0]  cnt;

    assign v[0]             = in_valid;
    assign in_ready         = r[0];
    assign d[0 +: W]        = in_data;
    assign out_valid        = v[STAGES];
    assign r[STAGES]        = out_ready;
    assign out_data         = d[STAGES*W +: W];

    for (genvar s = 0; s < STAGES; s++) begin : g_st
      sfn_fifo #(.W(W), .DEPTH(DEPTH), .PASS_FULL(0)) u_st (
        .clk, .rst_n,
        .in_valid(v[s]), .in_ready(r[s]), .in_data(d[s*W +: W]),
        .out_valid(v[s+1]), .out_ready(r[s+1]), .out_data(d[(s+1)*W +: W]),
        .count(cnt[s*CNTW +: CNTW])
      );
    end

    always_comb begin
      occ = '0;
      for (int s = 0; s < STAGES; s++) occ = occ + OCCW'(cnt[s*CNTW +: CNTW]);
    end
  end

`ifndef SYNTHESIS
  initial begin
    if (W < 1)                                    $fatal(1, "sfs_link: W=%0d must be >= 1", W);
    if (STAGES < 0 || STAGES > sfs_pkg::MAX_STAGES) $fatal(1, "sfs_link: STAGES=%0d outside 0..%0d", STAGES, sfs_pkg::MAX_STAGES);
    if (DEPTH < 1 || DEPTH > sfs_pkg::MAX_BUF)      $fatal(1, "sfs_link: DEPTH=%0d outside 1..%0d", DEPTH, sfs_pkg::MAX_BUF);
  end
`endif
endmodule

`default_nettype wire
