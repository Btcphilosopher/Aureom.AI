// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_tnode -- target attachment node
//
// Placed in the target's floorplan region (SRAM region, shared memory, register
// window, external-memory interface).  It carries one SFB3 target port across
// the spine with PIPE register stages per direction:
//
//   central routing stage ──► sfs_link request  ──► SFB3 target
//   central routing stage ◄── sfs_link response ◄── SFB3 target
//
// The source identifier stamped by the central stage (x_req_src) and the target's
// echoed tags (t_rsp_src / id / opcode) travel unchanged: response ownership is
// decided at the central stage from t_rsp_src, after this link.
// With PIPE = 0 the node is wiring only (single central routing stage).
// =============================================================================
`default_nettype none

module sfs_tnode #(
  parameter int  NM        = 4,
  parameter int  AW        = 32,
  parameter int  DW        = 32,
  parameter int  IDW       = 2,
  parameter int  PIPE      = 0,
  parameter int  BUF_DEPTH = 2,
  localparam int SB        = DW / 8,
  localparam int SRCW      = sfn_pkg::clog2c(NM),
  localparam int QPW       = 3 + SRCW + IDW + 3 + AW + DW + SB,
  localparam int RPW       = SRCW + IDW + 3 + 2 + DW,
  localparam int OCCW      = sfs_pkg::clog2c(PIPE * BUF_DEPTH + 1)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // ------------------------------------------------------------ central-stage side
  input  wire logic            x_req_valid,
  output logic                 x_req_ready,
  input  wire logic [2:0]      x_req_opcode,
  input  wire logic [SRCW-1:0] x_req_src,
  input  wire logic [IDW-1:0]  x_req_id,
  input  wire logic [2:0]      x_req_qos,
  input  wire logic [AW-1:0]   x_req_addr,
  input  wire logic [DW-1:0]   x_req_wdata,
  input  wire logic [SB-1:0]   x_req_wstrb,
  output logic                 x_rsp_valid,
  input  wire logic            x_rsp_ready,
  output logic [SRCW-1:0]      x_rsp_src,
  output logic [IDW-1:0]       x_rsp_id,
  output logic [2:0]           x_rsp_opcode,
  output logic [1:0]           x_rsp_status,
  output logic [DW-1:0]        x_rsp_rdata,
  // ------------------------------------------------------------ SFB3 target port
  output logic                 t_req_valid,
  input  wire logic            t_req_ready,
  output logic [2:0]           t_req_opcode,
  output logic [SRCW-1:0]      t_req_src,
  output logic [IDW-1:0]       t_req_id,
  output logic [2:0]           t_req_qos,
  output logic [AW-1:0]        t_req_addr,
  output logic [DW-1:0]        t_req_wdata,
  output logic [SB-1:0]        t_req_wstrb,
  input  wire logic            t_rsp_valid,
  output logic                 t_rsp_ready,
  input  wire logic [SRCW-1:0] t_rsp_src,
  input  wire logic [IDW-1:0]  t_rsp_id,
  input  wire logic [2:0]      t_rsp_opcode,
  input  wire logic [1:0]      t_rsp_status,
  input  wire logic [DW-1:0]   t_rsp_rdata,
  // ------------------------------------------------------------ status
  output logic [OCCW-1:0]      q_occ,
  output logic [OCCW-1:0]      r_occ
);
  sfs_link #(.W(QPW), .STAGES(PIPE), .DEPTH(BUF_DEPTH)) u_qlink (
    .clk, .rst_n,
    .in_valid(x_req_valid), .in_ready(x_req_ready),
    .in_data({x_req_opcode, x_req_src, x_req_id, x_req_qos, x_req_addr, x_req_wdata, x_req_wstrb}),
    .out_valid(t_req_valid), .out_ready(t_req_ready),
    .out_data({t_req_opcode, t_req_src, t_req_id, t_req_qos, t_req_addr, t_req_wdata, t_req_wstrb}),
    .occ(q_occ)
  );

  sfs_link #(.W(RPW), .STAGES(PIPE), .DEPTH(BUF_DEPTH)) u_rlink (
    .clk, .rst_n,
    .in_valid(t_rsp_valid), .in_ready(t_rsp_ready),
    .in_data({t_rsp_src, t_rsp_id, t_rsp_opcode, t_rsp_status, t_rsp_rdata}),
    .out_valid(x_rsp_valid), .out_ready(x_rsp_ready),
    .out_data({x_rsp_src, x_rsp_id, x_rsp_opcode, x_rsp_status, x_rsp_rdata}),
    .occ(r_occ)
  );
endmodule

`default_nettype wire
