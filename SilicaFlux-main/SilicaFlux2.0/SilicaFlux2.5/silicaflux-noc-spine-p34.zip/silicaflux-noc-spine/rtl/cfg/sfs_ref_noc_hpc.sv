// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_ref_noc_hpc -- reference fabrics, same configuration
//
// P22's silicaflux_noc (UNMODIFIED) bound to the same HPC floorplan configuration as
// silicaflux_noc_spine_hpc, for the topology comparison (docs/ARCHITECTURE.md sec. 2):
//   TOPOLOGY 1  P22 crossbar = the spine with every link at 0 stages (P31 HPC fabric)
//   TOPOLOGY 2  P22 2-D mesh, MESH_X x MESH_Y routers placed on the die
//               (sfs_cfg_pkg MESH_*_NODE, nearest-node placement): the registered multistage NoC
// Synthesis only (scripts/synth.py); the testbench instantiates silicaflux_noc directly.
// =============================================================================
`default_nettype none

module sfs_ref_noc_hpc #(
  parameter int  TOPOLOGY = 1,
  parameter int  ARB_MODE = sfs_cfg_pkg::ARB_MODE,
  parameter int  PERF     = 0,
  localparam int NM   = sfs_cfg_pkg::NM,
  localparam int NT   = sfs_cfg_pkg::NT,
  localparam int AW   = sfs_cfg_pkg::AW,
  localparam int DW   = sfs_cfg_pkg::DW,
  localparam int IDW  = sfs_cfg_pkg::IDW,
  localparam int SB   = DW / 8,
  localparam int SRCW = sfn_pkg::clog2c(NM),
  localparam int QW   = sfn_pkg::QOSW,
  localparam int CW   = sfn_pkg::clog2c(sfs_cfg_pkg::MAXO_MAX + 1)
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic [NM-1:0]      m_req_valid,
  output logic      [NM-1:0]      m_req_ready,
  input  wire logic [NM*3-1:0]    m_req_opcode,
  input  wire logic [NM*IDW-1:0]  m_req_id,
  input  wire logic [NM*QW-1:0]   m_req_qos,
  input  wire logic [NM*AW-1:0]   m_req_addr,
  input  wire logic [NM*DW-1:0]   m_req_wdata,
  input  wire logic [NM*SB-1:0]   m_req_wstrb,
  output logic      [NM-1:0]      m_rsp_valid,
  input  wire logic [NM-1:0]      m_rsp_ready,
  output logic      [NM*IDW-1:0]  m_rsp_id,
  output logic      [NM*3-1:0]    m_rsp_opcode,
  output logic      [NM*2-1:0]    m_rsp_status,
  output logic      [NM*DW-1:0]   m_rsp_rdata,
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  input  wire logic               rb_sel,
  input  wire logic               rb_we,
  input  wire logic [11:0]        rb_addr,
  input  wire logic [31:0]        rb_wdata,
  output logic      [31:0]        rb_rdata,
  output logic                    rb_err,
  output logic                    irq_err
);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]    o_sw_v, o_sw_r, o_dec, o_perr, o_orph;
  logic [NM*CW-1:0] o_out;
  logic [NT-1:0]    o_bsrc;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_noc #(
    .TOPOLOGY(TOPOLOGY), .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE),
    .STARVE(sfs_cfg_pkg::STARVE), .CHECK_ALIGN(1), .RETIRE_BYPASS(0), .TGT_BASE(sfs_cfg_pkg::TGT_BASE),
    .TGT_MASK(sfs_cfg_pkg::TGT_MASK), .MST_TGT_EN(sfs_cfg_pkg::MST_TGT_EN), .MAXO_MAX(sfs_cfg_pkg::MAXO_MAX),
    .MST_MAXO(sfs_cfg_pkg::MST_MAXO_SPINE), .MESH_X(sfs_cfg_pkg::MESH_X), .MESH_Y(sfs_cfg_pkg::MESH_Y),
    .MST_NODE(sfs_cfg_pkg::MESH_MST_NODE), .TGT_NODE(sfs_cfg_pkg::MESH_TGT_NODE), .FIFO_DEPTH(4), .PERF(PERF)
  ) u_noc (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
    .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
    .obs_sw_valid(o_sw_v), .obs_sw_ready(o_sw_r), .obs_out_cnt(o_out), .obs_decerr(o_dec), .obs_posted_err(o_perr),
    .obs_orphan(o_orph), .obs_bad_src(o_bsrc)
  );
endmodule

`default_nettype wire
