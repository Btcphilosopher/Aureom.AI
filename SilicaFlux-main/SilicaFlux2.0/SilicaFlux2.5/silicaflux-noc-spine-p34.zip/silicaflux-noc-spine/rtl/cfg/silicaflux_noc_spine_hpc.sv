// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: silicaflux_noc_spine_hpc -- configured spine
//
// The spine bound to the SilicaFlux HPC floorplan configuration (rtl/cfg/sfs_cfg_pkg.sv,
// generated from config/silicaflux_floorplan.yaml): P31 SILICAFLUX_HPC ports
// (10 masters x 11 targets), address map, access matrix, traffic classes.
//   PIPE_SEL 0 single central routing stage (no link registers)
//            1 EVIDENCE: register stages chosen by scripts/placement.py from the synthesis
//              timing of the blocks and the conceptual link lengths (docs/PHYSICAL.md)
//            2 DEEP: sensitivity point (shorter reach per cycle), used to measure the cost
//              of multi-stage links
//   MAXO_SEL 0 P31 outstanding limits, 1 limits sized against the pipelined round trip
// Used by synthesis (scripts/synth.py) and as the drop-in instance for the P31 die.
// =============================================================================
`default_nettype none

module silicaflux_noc_spine_hpc #(
  parameter int  PIPE_SEL = 1,
  parameter int  MAXO_SEL = 1,
  parameter int  ARB_MODE = sfs_cfg_pkg::ARB_MODE,
  parameter int  TC_MODE  = sfs_cfg_pkg::TC_MODE,
  parameter int  BUF_DEPTH = sfs_cfg_pkg::BUF_DEPTH,
  parameter int  PERF     = 1,
  localparam int NM   = sfs_cfg_pkg::NM,
  localparam int NT   = sfs_cfg_pkg::NT,
  localparam int AW   = sfs_cfg_pkg::AW,
  localparam int DW   = sfs_cfg_pkg::DW,
  localparam int IDW  = sfs_cfg_pkg::IDW,
  localparam int SB   = DW / 8,
  localparam int SRCW = sfn_pkg::clog2c(NM),
  localparam int QW   = sfn_pkg::QOSW,
  localparam int TW   = sfn_pkg::clog2c(NT + 1),
  localparam int CW   = sfn_pkg::clog2c(sfs_cfg_pkg::MAXO_MAX + 1),
  localparam int OCCW = sfs_pkg::clog2c(sfs_pkg::MAX_STAGES * sfs_pkg::MAX_BUF + 1)
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic [NM-1:0]      m_req_valid,
  output logic      [NM-1:0]      m_req_ready,
  input  wire logic [NM*3-1:0]    m_req_opcode,
  input  wire logic [NM*IDW-1:0]  m_req_id,
  input  wire logic [NM*QW-1:0]   m_req_qos,
  input  wire logic [NM*AW-1:0]   m_req_addr,
  input  wire logic [NM*DW-1:0]   m_req_wdata,
  input  wire logic [NM*SB-1:0]   m_req_wstrb,
  output logic      [NM-1:0]      m_rsp_valid,
  input  wire logic [NM-1:0]      m_rsp_ready,
  output logic      [NM*IDW-1:0]  m_rsp_id,
  output logic      [NM*3-1:0]    m_rsp_opcode,
  output logic      [NM*2-1:0]    m_rsp_status,
  output logic      [NM*DW-1:0]   m_rsp_rdata,
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  input  wire logic               rb_sel,
  input  wire logic               rb_sel_spine,
  input  wire logic               rb_we,
  input  wire logic [11:0]        rb_addr,
  input  wire logic [31:0]        rb_wdata,
  output logic      [31:0]        rb_rdata,
  output logic                    rb_err,
  output logic                    irq_err
);
  localparam logic [NM*4-1:0] MPIPE = (PIPE_SEL == 1) ? sfs_cfg_pkg::MST_PIPE_EVIDENCE :
                                      (PIPE_SEL == 2) ? sfs_cfg_pkg::MST_PIPE_DEEP : sfs_cfg_pkg::MST_PIPE_SINGLE;
  localparam logic [NT*4-1:0] TPIPE = (PIPE_SEL == 1) ? sfs_cfg_pkg::TGT_PIPE_EVIDENCE :
                                      (PIPE_SEL == 2) ? sfs_cfg_pkg::TGT_PIPE_DEEP : sfs_cfg_pkg::TGT_PIPE_SINGLE;
  localparam logic [NM*8-1:0] MAXO  = (MAXO_SEL == 1) ? sfs_cfg_pkg::MST_MAXO_SPINE : sfs_cfg_pkg::MST_MAXO_P31;

  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]      o_sw_v, o_sw_r, o_dec, o_perr, o_orph, o_cv, o_cr, o_cl, o_crv, o_crr;
  logic [NM*CW-1:0]   o_out;
  logic [NT-1:0]      o_bsrc, o_xv, o_xr;
  logic [NM*TW-1:0]   o_ct;
  logic [NM*2-1:0]    o_ctc;
  logic [NM*OCCW-1:0] o_mq, o_mr;
  logic [NT*OCCW-1:0] o_tq, o_tr;
  logic [31:0]        o_ae;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_noc_spine #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(sfs_cfg_pkg::STARVE),
    .CHECK_ALIGN(1), .TGT_BASE(sfs_cfg_pkg::TGT_BASE), .TGT_MASK(sfs_cfg_pkg::TGT_MASK),
    .MST_TGT_EN(sfs_cfg_pkg::MST_TGT_EN), .MAXO_MAX(sfs_cfg_pkg::MAXO_MAX), .MST_MAXO(MAXO),
    .MST_CTRL(sfs_cfg_pkg::MST_CTRL), .TGT_MMIO(sfs_cfg_pkg::TGT_MMIO), .TC_MODE(TC_MODE),
    .BUF_DEPTH(BUF_DEPTH), .MST_PIPE(MPIPE), .TGT_PIPE(TPIPE), .PERF(PERF)
  ) u_spine (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
    .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
    .rb_sel, .rb_sel_spine, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
    .obs_sw_valid(o_sw_v), .obs_sw_ready(o_sw_r), .obs_out_cnt(o_out), .obs_decerr(o_dec), .obs_posted_err(o_perr),
    .obs_orphan(o_orph), .obs_bad_src(o_bsrc), .obs_c_valid(o_cv), .obs_c_ready(o_cr), .obs_c_tgt(o_ct),
    .obs_c_tc(o_ctc), .obs_c_loss(o_cl), .obs_mq_occ(o_mq), .obs_mr_occ(o_mr), .obs_tq_occ(o_tq), .obs_tr_occ(o_tr),
    .obs_x_valid(o_xv), .obs_x_ready(o_xr), .obs_cr_valid(o_crv), .obs_cr_ready(o_crr), .assert_errors(o_ae)
  );
endmodule

`default_nettype wire
