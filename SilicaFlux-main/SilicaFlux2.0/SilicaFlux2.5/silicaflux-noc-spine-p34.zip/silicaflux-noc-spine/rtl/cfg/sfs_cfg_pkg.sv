// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_cfg_pkg -- GENERATED, do not edit
// Source: config/silicaflux_floorplan.yaml (silicaflux_spine_hpc) by scripts/gen_cfg.py
// Port order = P31 SILICAFLUX_HPC: masters CC HOST DMA0 DMA1 VEC0 VEC1 VEC2 VEC3 TSU0 TSU1
//                                    targets SRAM0 SRAM1 SRAM2 SRAM3 SPM0 SPM1 SPM2 SPM3 REGS EXT EXTCSR
// Distances are CONCEPTUAL (floorplan illustration), in micrometres, Manhattan x route_detour.
// =============================================================================
package sfs_cfg_pkg;
  /* verilator lint_off UNUSEDPARAM */
  localparam int NM = 10;
  localparam int NT = 11;
  localparam int AW = 32;
  localparam int DW = 32;
  localparam int IDW = 2;
  localparam int MAXO_MAX = 8;
  localparam int BUF_DEPTH = 2;
  localparam int STARVE = 8;
  localparam int ARB_MODE = 2;
  localparam int TC_MODE = 1;
  localparam logic [AW-1:0] UNMAPPED = 32'h28000000;
  localparam logic [NT*AW-1:0] TGT_BASE = 352'h3f000000380000003e0000003030000030200000301000003000000020300000202000002010000020000000;
  localparam logic [NT*AW-1:0] TGT_MASK = 352'hfffff000fc000000ffff0000ffff0000ffff0000ffff0000ffff0000fff00000fff00000fff00000fff00000;
  localparam logic [NM*NT-1:0] MST_TGT_EN = 110'b00000001111000000011110100000111101000001111010000011110100000111101011111111010111111111111111111111111111111;
  localparam logic [NM*8-1:0] MST_MAXO_P31 = 80'h04040101010102020101;
  localparam logic [NM*8-1:0] MST_MAXO_SPINE = 80'h08080404040408080202;
  localparam logic [NM-1:0] MST_CTRL = 10'b0000000011;
  localparam logic [NT-1:0] TGT_MMIO = 11'b10100000000;
  localparam logic [NM*3-1:0] MST_QOS = 30'b001001010010010010000000011011;
  localparam logic [NT*16-1:0] TGT_LAT_MIN = 176'h0002000c000100010001000100010001000100010001;
  localparam logic [NT*16-1:0] TGT_LAT_MAX = 176'h00020028000100030003000300030002000200020002;
  localparam logic [NM*32-1:0] MST_DIST_UM = 320'h00000564000005d7000025bc000025490000262f000025bc000043d500004853000048c600002aad;
  localparam logic [NT*32-1:0] TGT_DIST_UM = 352'h0000452e00003c32000042090000341c000033a90000348f0000341c0000271500001fe5000028e1000031dd;
  // workload profile per master (tb/sfs_tb_master): 0 cc_mmio 1 host 2 dma_write 3 vec_spm 4 tensor_load
  localparam logic [NM*4-1:0] MST_PROFILE = 40'h4433332210;
  // target class: 0 SRAM 1 SPM 2 REGS 3 EXT 4 EXTCSR
  localparam logic [NT*4-1:0] TGT_CLASS = 44'h43211110000;
  // ---- registered multistage alternative: P22 sfn_mesh 4x3, nearest-node placement
  localparam int MESH_X = 4;
  localparam int MESH_Y = 3;
  localparam logic [NM*8-1:0] MESH_MST_NODE = 80'h06050b04070109080002;
  localparam logic [NT*8-1:0] MESH_TGT_NODE = 88'h0b0602070803040a010509;
  // ---- register stages per link direction (scripts/placement.py)
  // single: one central routing stage, no link registers (starting point)
  localparam logic [NM*4-1:0] MST_PIPE_SINGLE = 40'h0000000000;
  localparam logic [NT*4-1:0] TGT_PIPE_SINGLE = 44'h00000000000;
  // evidence: sky130 evidence: clock 5.1 ns set by the central stage; stages so every segment fits (reach 11.7 mm from a node, 22.1 mm between stages)
  localparam logic [NM*4-1:0] MST_PIPE_EVIDENCE = 40'h1111112221;
  localparam logic [NT*4-1:0] TGT_PIPE_EVIDENCE = 44'h11111111111;
  // deep: SENSITIVITY point, not a timing result: reach 4 mm per cycle (e.g. a faster process or clock); measures the latency / buffering cost of multi-stage links
  localparam logic [NM*4-1:0] MST_PIPE_DEEP = 40'h1133335553;
  localparam logic [NT*4-1:0] TGT_PIPE_DEEP = 44'h54544443334;
  /* verilator lint_on UNUSEDPARAM */
endpackage
