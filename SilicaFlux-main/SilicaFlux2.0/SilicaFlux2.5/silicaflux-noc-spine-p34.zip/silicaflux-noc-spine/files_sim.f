-f files_rtl.f
rtl/spine/sfs_spine_assert.sv
