# Formal results

Yosys 0.33 (git sha1 2584903a060); BMC with ABC bmc3 (bit level) and, as an independent second engine, yosys-smtbmc + Z3 version 5.4.1 - 64 bit (word level, shorter depth); unbounded proofs with ABC PDR (yosys-abc, budget 1200 s).  `expect FAIL` rows are non-vacuity checks: the same harness on one deliberately broken RTL file must give a counterexample.  UNKNOWN = PDR budget reached: the property then holds only to the BMC depth.  BMC depth = frames completed (bit-level BMC stops at its 1800 s limit, so a depth below the requested one means the limit was reached, not that a frame failed).

**27 / 27 jobs as expected: 16 unbounded proofs, 3 bounded only, 8 mutants caught.**

| job | harness | params | BMC (abc bmc3) | BMC (smtbmc+z3) | unbounded | expect | verdict | note | s |
|---|---|---|---|---|---|---|---|---|---|
| qos_equiv_n5_s3 | fv_sfs_qos_equiv | {'N': 5, 'STARVE': 3} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 11.3 |
| qos_equiv_n10_s8 | fv_sfs_qos_equiv | {'N': 10, 'STARVE': 8} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 29.2 |
| qos_equiv_n3_s0 | fv_sfs_qos_equiv | {'N': 3, 'STARVE': 0} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 1.0 |
| qos_equiv_n4_s1 | fv_sfs_qos_equiv | {'N': 4, 'STARVE': 1} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 3.2 |
| xbar_equiv_qos | fv_sfs_xbar_equiv | {'ARB': 2} | PASS depth 12 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 16.1 |
| xbar_equiv_rr | fv_sfs_xbar_equiv | {'ARB': 1} | PASS depth 12 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 3.3 |
| link_s1_d2 | fv_sfs_link | {'STAGES': 1, 'DEPTH': 2} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 0.9 |
| link_s2_d2 | fv_sfs_link | {'STAGES': 2, 'DEPTH': 2} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 2.6 |
| link_s3_d2 | fv_sfs_link | {'STAGES': 3, 'DEPTH': 2} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 15.2 |
| link_s2_d1 | fv_sfs_link | {'STAGES': 2, 'DEPTH': 1} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 0.7 |
| link_s2_d3 | fv_sfs_link | {'STAGES': 2, 'DEPTH': 3} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 15.8 |
| link_s4_d2 | fv_sfs_link | {'STAGES': 4, 'DEPTH': 2} | PASS depth 24 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 439.6 |
| tc_map_mode1 | fv_sfs_tc_map | {'TC_MODE': 1} | PASS depth 2 | PASS depth 2 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 0.7 |
| tc_map_ctrl | fv_sfs_tc_map | {'TC_MODE': 1, 'MST_CTRL': "1'b1"} | PASS depth 2 | PASS depth 2 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 0.7 |
| tc_map_mode0 | fv_sfs_tc_map | {'TC_MODE': 0} | PASS depth 2 | PASS depth 2 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 0.4 |
| spine_single | fv_sfs_spine | {'MP0': 0, 'MP1': 0, 'TP0': 0, 'TP1': 0} | PASS depth 16 | PASS depth 6 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 2833.7 |
| spine_mixed | fv_sfs_spine | {'MP0': 1, 'MP1': 0, 'TP0': 2, 'TP1': 1} | PASS depth 14 | PASS depth 6 | UNKNOWN (PDR budget 1200 s, frame 11) | PASS | OK, **bounded only** |  | 3491.1 |
| spine_all1 | fv_sfs_spine | {'MP0': 1, 'MP1': 1, 'TP0': 1, 'TP1': 1} | PASS depth 13 | PASS depth 6 | UNKNOWN (PDR budget 1200 s, frame 12) | PASS | OK, **bounded only** |  | 3410.4 |
| spine_buf1 | fv_sfs_spine | {'MP0': 1, 'MP1': 2, 'TP0': 1, 'TP1': 0, 'BUF': 1} | PASS depth 16 | PASS depth 6 | UNKNOWN (PDR budget 1200 s, frame 24) | PASS | OK, **bounded only** |  | 3354.3 |
| mut_link_overflow | fv_sfs_link | {'STAGES': 2, 'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | link accepts while its first stage is full (loss) | 0.8 |
| mut_link_skip_stage | fv_sfs_link | {'STAGES': 2, 'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | output taken from the wrong stage (integrity / order) | 0.6 |
| mut_qos_equiv_ptr | fv_sfs_qos_equiv | {'N': 5, 'STARVE': 3} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | round-robin search starts one past the pointer | 1.3 |
| mut_qos_equiv_level | fv_sfs_qos_equiv | {'N': 5, 'STARVE': 3} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | only the next level up is considered higher | 1.3 |
| mut_tc_mmio | fv_sfs_tc_map | {'TC_MODE': 1} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | MMIO targets not classified as control traffic | 0.3 |
| mut_tnode_src | fv_sfs_spine | {'MP0': 1, 'MP1': 0, 'TP0': 1, 'TP1': 1} | FAIL (counterexample) | PASS depth 6 | - | FAIL | OK | target link corrupts the response owner (misrouted completions) | 386.6 |
| mut_mnode_rsp_tgt | fv_sfs_spine | {'MP0': 1, 'MP1': 0, 'TP0': 1, 'TP1': 1} | FAIL (counterexample) | PASS depth 6 | - | FAIL | OK | master link loses the responding target (completions discarded as orphans: lost responses) | 397.7 |
| mut_mnode_tc_swap | fv_sfs_spine | {'MP0': 1, 'MP1': 1, 'TP0': 1, 'TP1': 1} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | request link flips a payload bit (integrity) | 53.9 |
