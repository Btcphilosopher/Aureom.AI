// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: tb_spine -- self-checking testbench
//
// DERIVED from P22 tb/tb_noc.sv (vendored unmodified in third_party/; it is also run
// UNMODIFIED against the spine, scripts/compat.py).  Spine additions:
//   * DUT = 0 silicaflux_noc_spine (link pipelining PIPE_SEL: 0 single central stage,
//     1 placement-evidence stages, 2 deep sensitivity point, 3 uniform PIPE_N, 4 mixed 0..PIPE_N)
//     DUT = 1 P22 silicaflux_noc (TOPOLOGY 1 crossbar / 2 mesh) as the reference fabric;
//   * CFG = 1 the SilicaFlux HPC floorplan configuration (rtl/cfg/sfs_cfg_pkg.sv: P31 address
//     map, access matrix, outstanding limits, per-target latency, per-master workload profile),
//     CFG = 0 the synthetic P22 map (NM x NT, 1 MiB windows);
//   * fairness measured at the CENTRAL routing stage (head of every master link);
//   * every SPINE_PERF counter (link transfers, stalls, occupancy, central-stage waits,
//     per-class counts) recomputed here from the ports and compared exactly;
//   * the in-RTL assertion count (sfs_spine_assert) must be 0;
//   * a SPINE {...} result line with link utilisation, occupancy and arbitration delays.
// The P22 description below still applies.
//
// Same testbench for every topology (shared bus, crossbar, mesh).  NM traffic
// generators (sfn_tb_master), NT memory targets (sfn_tb_target), a protocol
// checker on every port and an INDEPENDENT scoreboard:
//   * reference decoder (address map, access matrix, alignment, opcode) -- it
//     does not use any RTL decoder;
//   * conservation: every master acceptance routed to a target appears exactly
//     once at that target with the identical payload and source, in per-(master,
//     target) order; nothing appears at a target that no master sent;
//   * responses: every target response (and every fabric-local FENCE / DECERR
//     response) reaches exactly the master and ID it belongs to, with identical
//     data/status/opcode, in per-ID order; posted-write completions never reach
//     a master; spurious (fault-injected) responses are never delivered;
//   * fabric rules: outstanding <= MST_MAXO (O1), one target per outstanding ID
//     (O2), FENCE accepted only with nothing outstanding (O3), no transfer and no
//     fabric output during reset, decode-error / posted-error / orphan events;
//   * fairness: other-master acceptances while a master waits at the switch
//     (bound NM-1 round robin, STARVE+NM-1 QoS; shared bus and crossbar);
//   * liveness: a watchdog fails the run if no handshake happens for WD cycles
//     while work is pending (deadlock / livelock);
//   * performance counters: read back over the register bus and compared with
//     counts computed here from the ports.
// Plusargs: see sfn_tb_master / sfn_tb_target, plus +resets=K, +maxcyc=C,
// +wd=C, +trace=FILE, +test=NAME (label only).
// Output: "RESULT {...json...}" line; exit status via $fatal on failure.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module tb_spine #(
  parameter int DUT         = 0,      // 0 spine, 1 P22 silicaflux_noc
  parameter int CFG         = 0,      // 0 synthetic map, 1 SilicaFlux HPC floorplan configuration
  parameter int PIPE_SEL    = 0,
  parameter int PIPE_N      = 1,
  parameter int BUF_DEPTH   = 2,
  parameter int TC_MODE     = 1,
  parameter int MAXO_SEL    = 0,      // CFG 1: 0 P31 outstanding limits, 1 spine-recommended limits
  parameter int CENTRAL     = 1,      // spine central stage: 1 sfs_xbar, 0 P22 sfn_xbar
  parameter int TOPOLOGY    = 1,
  parameter int NM          = 4,
  parameter int NT          = 4,
  parameter int AW          = 32,
  parameter int DW          = 32,
  parameter int IDW         = 2,
  parameter int ARB_MODE    = 2,
  parameter int STARVE      = 8,
  parameter int MAXO        = 4,
  parameter int MAXO0       = 1,      // master 0 (ControlCore-like) limit
  parameter int CHECK_ALIGN = 1,
  parameter int EN_SPARSE   = 0,      // 1: some master/target pairs denied
  parameter int QCAP        = 8,
  parameter int PERF        = 1,
  parameter int TGT_SFB2    = 0,      // 1: every target is an SFB2 slave behind sfn_sfb2_tgt_bridge
  parameter int RETIRE_BYPASS = 0,
  parameter int MESH_X      = 2,
  parameter int MESH_Y      = 2,
  parameter int FIFO_DEPTH  = 4
);
`include "sfn_tb_common.svh"

  localparam int SB   = DW / 8;
  localparam int OFF  = $clog2(SB);
  localparam int SRCW = sfn_pkg::clog2c(NM);
  localparam int TW   = sfn_pkg::clog2c(NT + 1);
  localparam int NID  = 1 << IDW;
  localparam int QW   = sfn_pkg::QOSW;
  localparam int CW   = sfn_pkg::clog2c(MAXO + 1);
  localparam int NN   = MESH_X * MESH_Y;
  localparam logic [AW-1:0] BASE0    = AW'(1) << (AW - 4);
  localparam logic [AW-1:0] UNMAPPED = (CFG == 1) ? AW'(sfs_cfg_pkg::UNMAPPED) : (AW'(1) << (AW - 2));
  localparam int OCCW = sfs_pkg::clog2c(sfs_pkg::MAX_STAGES * sfs_pkg::MAX_BUF + 1);

  function automatic logic [NT*AW-1:0] f_base();
    for (int t = 0; t < NT; t++) f_base[t*AW +: AW] = BASE0 + (AW'(t) << 20);
  endfunction
  function automatic logic [NT*AW-1:0] f_mask();
    for (int t = 0; t < NT; t++) f_mask[t*AW +: AW] = ~((AW'(1) << 20) - AW'(1));
  endfunction
  function automatic logic [NM*NT-1:0] f_en();
    for (int m = 0; m < NM; m++)
      for (int t = 0; t < NT; t++)
        f_en[m*NT + t] = (EN_SPARSE == 0) || (t == m % NT) || (((m + 2 * t) % 5) != 4);
  endfunction
  function automatic logic [NM*8-1:0] f_maxo();
    for (int m = 0; m < NM; m++) f_maxo[m*8 +: 8] = (m == 0) ? 8'(MAXO0) : 8'(MAXO);
  endfunction
  function automatic logic [NM*8-1:0] f_mnode();
    for (int m = 0; m < NM; m++) f_mnode[m*8 +: 8] = 8'(m % NN);
  endfunction
  function automatic logic [NT*8-1:0] f_tnode();
    for (int t = 0; t < NT; t++) f_tnode[t*8 +: 8] = 8'((NN - 1 - t % NN));
  endfunction

  // ---------------------------------------------------------------- configuration selection
  function automatic logic [NM*4-1:0] f_mpipe();
    for (int m = 0; m < NM; m++)
      if (PIPE_SEL == 3)      f_mpipe[m*4 +: 4] = 4'(PIPE_N);
      else if (PIPE_SEL == 4) f_mpipe[m*4 +: 4] = 4'((m * 7 + 3) % (PIPE_N + 1));
      else                    f_mpipe[m*4 +: 4] = 4'd0;
  endfunction
  function automatic logic [NT*4-1:0] f_tpipe();
    for (int t = 0; t < NT; t++)
      if (PIPE_SEL == 3)      f_tpipe[t*4 +: 4] = 4'(PIPE_N);
      else if (PIPE_SEL == 4) f_tpipe[t*4 +: 4] = 4'((t * 5 + 1) % (PIPE_N + 1));
      else                    f_tpipe[t*4 +: 4] = 4'd0;
  endfunction
  function automatic logic [NM-1:0] f_encol(input int t);
    for (int m = 0; m < NM; m++) f_encol[m] = EN[m*NT + t];
  endfunction
  function automatic logic [NM-1:0] f_ctrl();
    for (int m = 0; m < NM; m++) f_ctrl[m] = (m == 0);
  endfunction
  function automatic logic [NT-1:0] f_mmio();
    for (int t = 0; t < NT; t++) f_mmio[t] = (t == NT - 1);
  endfunction
  function automatic logic [NM*4-1:0] f_prof();
    for (int m = 0; m < NM; m++) f_prof[m*4 +: 4] = 4'(m % 5);
  endfunction
  function automatic logic [NT*4-1:0] f_tcls();
    for (int t = 0; t < NT; t++) f_tcls[t*4 +: 4] = 4'(t % 5);
  endfunction
  localparam logic [NT*AW-1:0] TBASE  = (CFG == 1) ? (NT*AW)'(sfs_cfg_pkg::TGT_BASE) : f_base();
  localparam logic [NT*AW-1:0] TMASK  = (CFG == 1) ? (NT*AW)'(sfs_cfg_pkg::TGT_MASK) : f_mask();
  localparam logic [NM*NT-1:0] EN     = (CFG == 1) ? (NM*NT)'(sfs_cfg_pkg::MST_TGT_EN) : f_en();
  localparam logic [NM*8-1:0]  MMAXO  = (CFG == 1) ? ((MAXO_SEL == 1) ? (NM*8)'(sfs_cfg_pkg::MST_MAXO_SPINE)
                                                                       : (NM*8)'(sfs_cfg_pkg::MST_MAXO_P31)) : f_maxo();
  localparam logic [NM*4-1:0]  MPIPE  = (CFG == 1 && PIPE_SEL == 1) ? (NM*4)'(sfs_cfg_pkg::MST_PIPE_EVIDENCE) :
                                        (CFG == 1 && PIPE_SEL == 2) ? (NM*4)'(sfs_cfg_pkg::MST_PIPE_DEEP) : f_mpipe();
  localparam logic [NT*4-1:0]  TPIPE  = (CFG == 1 && PIPE_SEL == 1) ? (NT*4)'(sfs_cfg_pkg::TGT_PIPE_EVIDENCE) :
                                        (CFG == 1 && PIPE_SEL == 2) ? (NT*4)'(sfs_cfg_pkg::TGT_PIPE_DEEP) : f_tpipe();
  localparam logic [NM-1:0]    MCTRL  = (CFG == 1) ? NM'(sfs_cfg_pkg::MST_CTRL) : f_ctrl();
  localparam logic [NT-1:0]    TMMIO  = (CFG == 1) ? NT'(sfs_cfg_pkg::TGT_MMIO) : f_mmio();
  localparam logic [NM*4-1:0]  MPROF  = (CFG == 1) ? (NM*4)'(sfs_cfg_pkg::MST_PROFILE) : f_prof();
  localparam logic [NT*4-1:0]  TCLS   = (CFG == 1) ? (NT*4)'(sfs_cfg_pkg::TGT_CLASS) : f_tcls();
  localparam logic [NM*8-1:0]  MNODE  = (CFG == 1) ? (NM*8)'(sfs_cfg_pkg::MESH_MST_NODE) : f_mnode();
  localparam logic [NT*8-1:0]  TNODE  = (CFG == 1) ? (NT*8)'(sfs_cfg_pkg::MESH_TGT_NODE) : f_tnode();

  // ================================================================ clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ================================================================ DUT
  logic [NM-1:0]      m_req_valid, m_req_ready, m_rsp_valid, m_rsp_ready;
  logic [NM*3-1:0]    m_req_opcode, m_rsp_opcode;
  logic [NM*IDW-1:0]  m_req_id, m_rsp_id;
  logic [NM*QW-1:0]   m_req_qos;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0]   m_req_wstrb;
  logic [NM*2-1:0]    m_rsp_status;
  logic [NT-1:0]      t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready;
  logic [NT*3-1:0]    t_req_opcode, t_rsp_opcode;
  logic [NT*SRCW-1:0] t_req_src, t_rsp_src;
  logic [NT*IDW-1:0]  t_req_id, t_rsp_id;
  logic [NT*QW-1:0]   t_req_qos;
  logic [NT*AW-1:0]   t_req_addr;
  logic [NT*DW-1:0]   t_req_wdata, t_rsp_rdata;
  logic [NT*SB-1:0]   t_req_wstrb;
  logic [NT*2-1:0]    t_rsp_status;
  logic               rb_sel, rb_we, rb_err, irq_err;
  logic [11:0]        rb_addr;
  logic [31:0]        rb_wdata, rb_rdata;
  logic [NM-1:0]      obs_sw_valid, obs_sw_ready, obs_decerr, obs_posted_err, obs_orphan;
  logic [NM*CW-1:0]   obs_out_cnt;
  logic [NT-1:0]      obs_bad_src;

  logic               rb_sel_spine;
  logic [31:0]        assert_errors;
  logic [NM-1:0]      obs_c_valid, obs_c_ready, obs_c_loss, obs_cr_valid, obs_cr_ready;
  logic [NM*TW-1:0]   obs_c_tgt;
  logic [NM*2-1:0]    obs_c_tc;
  logic [NM*OCCW-1:0] obs_mq_occ, obs_mr_occ;
  logic [NT*OCCW-1:0] obs_tq_occ, obs_tr_occ;
  logic [NT-1:0]      obs_x_valid, obs_x_ready;

  if (DUT == 0) begin : g_spine
    silicaflux_noc_spine #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE), .CHECK_ALIGN(CHECK_ALIGN),
      .TGT_BASE(TBASE), .TGT_MASK(TMASK), .MST_TGT_EN(EN), .MAXO_MAX(MAXO), .MST_MAXO(MMAXO), .MST_CTRL(MCTRL),
      .TGT_MMIO(TMMIO), .TC_MODE(TC_MODE), .BUF_DEPTH(BUF_DEPTH), .MST_PIPE(MPIPE), .TGT_PIPE(TPIPE), .PERF(PERF),
      .CENTRAL(CENTRAL)
    ) dut (
      .clk, .rst_n,
      .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos, .m_req_addr, .m_req_wdata, .m_req_wstrb,
      .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
      .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
      .rb_sel, .rb_sel_spine, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
      .obs_sw_valid, .obs_sw_ready, .obs_out_cnt, .obs_decerr, .obs_posted_err, .obs_orphan, .obs_bad_src,
      .obs_c_valid, .obs_c_ready, .obs_c_tgt, .obs_c_tc, .obs_c_loss, .obs_mq_occ, .obs_mr_occ, .obs_tq_occ,
      .obs_tr_occ, .obs_x_valid, .obs_x_ready, .obs_cr_valid, .obs_cr_ready, .assert_errors
    );
  end else begin : g_ref
    silicaflux_noc #(
      .TOPOLOGY(TOPOLOGY), .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE),
      .CHECK_ALIGN(CHECK_ALIGN), .RETIRE_BYPASS(RETIRE_BYPASS), .TGT_BASE(TBASE), .TGT_MASK(TMASK), .MST_TGT_EN(EN), .MAXO_MAX(MAXO),
      .MST_MAXO(MMAXO), .MESH_X(MESH_X), .MESH_Y(MESH_Y), .MST_NODE(MNODE), .TGT_NODE(TNODE),
      .FIFO_DEPTH(FIFO_DEPTH), .PERF(PERF)
    ) dut (
      .clk, .rst_n,
      .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos, .m_req_addr, .m_req_wdata, .m_req_wstrb,
      .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
      .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
      .rb_sel(rb_sel || rb_sel_spine), .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
      .obs_sw_valid, .obs_sw_ready, .obs_out_cnt, .obs_decerr, .obs_posted_err, .obs_orphan, .obs_bad_src
    );
    assign assert_errors = '0;
    assign obs_c_valid = '0; assign obs_c_ready = '0; assign obs_c_loss = '0; assign obs_c_tgt = '0; assign obs_c_tc = '0;
    assign obs_cr_valid = '0; assign obs_cr_ready = '0; assign obs_x_valid = '0; assign obs_x_ready = '0;
    assign obs_mq_occ = '0; assign obs_mr_occ = '0; assign obs_tq_occ = '0; assign obs_tr_occ = '0;
  end

  // ================================================================ agents
  logic [NM-1:0] m_done;
  logic          quiesce = 1'b0;     // end of test: targets stop injecting faults, links drain
  int            m_issued [NM], m_chk_err [NM], m_chk_ok [NM];
  logic [NT-1:0] t_spur;
  int            t_pend [NT], t_spur_sent [NT];
  int            viol_m [NM], viol_t [NT];

  for (genvar gm = 0; gm < NM; gm++) begin : g_m
    sfs_tb_master #(
      .M(gm), .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .CHECK_ALIGN(CHECK_ALIGN), .TBASE(TBASE),
      .EN(EN[gm*NT +: NT]), .UNMAPPED(UNMAPPED), .PROFILE(32'(MPROF[gm*4 +: 4])), .TCLASS(TCLS)
    ) u_m (
      .clk, .rst_n,
      .req_valid(m_req_valid[gm]), .req_ready(m_req_ready[gm]), .req_opcode(m_req_opcode[gm*3 +: 3]),
      .req_id(m_req_id[gm*IDW +: IDW]), .req_qos(m_req_qos[gm*QW +: QW]), .req_addr(m_req_addr[gm*AW +: AW]),
      .req_wdata(m_req_wdata[gm*DW +: DW]), .req_wstrb(m_req_wstrb[gm*SB +: SB]),
      .rsp_valid(m_rsp_valid[gm]), .rsp_ready(m_rsp_ready[gm]), .rsp_id(m_rsp_id[gm*IDW +: IDW]),
      .rsp_opcode(m_rsp_opcode[gm*3 +: 3]), .rsp_status(m_rsp_status[gm*2 +: 2]), .rsp_rdata(m_rsp_rdata[gm*DW +: DW]),
      .done(m_done[gm]), .n_issued(m_issued[gm]), .n_check_err(m_chk_err[gm]), .n_check_ok(m_chk_ok[gm])
    );
    sfn_protocol_checker #(.QW(3 + IDW + QW + AW + DW + SB), .RW(IDW + 3 + 2 + DW), .NAME($sformatf("m%0d", gm))) u_pc (
      .clk, .rst_n,
      .req_valid(m_req_valid[gm]), .req_ready(m_req_ready[gm]),
      .req_payload({m_req_opcode[gm*3 +: 3], m_req_id[gm*IDW +: IDW], m_req_qos[gm*QW +: QW], m_req_addr[gm*AW +: AW],
                    m_req_wdata[gm*DW +: DW], m_req_wstrb[gm*SB +: SB]}),
      .rsp_valid(m_rsp_valid[gm]), .rsp_ready(m_rsp_ready[gm]),
      .rsp_payload({m_rsp_id[gm*IDW +: IDW], m_rsp_opcode[gm*3 +: 3], m_rsp_status[gm*2 +: 2], m_rsp_rdata[gm*DW +: DW]}),
      .violations(viol_m[gm])
    );
  end

  for (genvar gt = 0; gt < NT; gt++) begin : g_t
    if (TGT_SFB2 == 0) begin : g_sfb3
      sfs_tb_target #(.T(gt), .NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .QCAP(QCAP),
                      .LMIN((CFG == 1) ? 32'(sfs_cfg_pkg::TGT_LAT_MIN[gt*16 +: 16]) : 0),
                      .LMAX((CFG == 1) ? 32'(sfs_cfg_pkg::TGT_LAT_MAX[gt*16 +: 16]) : 0),
                      .EN_COL(f_encol(gt)), .SPUR_SAFE((DUT == 0) && ((|MPIPE) || (|TPIPE)))) u_t (
        .clk, .rst_n,
        .t_req_valid(t_req_valid[gt]), .t_req_ready(t_req_ready[gt]), .t_req_opcode(t_req_opcode[gt*3 +: 3]),
        .t_req_src(t_req_src[gt*SRCW +: SRCW]), .t_req_id(t_req_id[gt*IDW +: IDW]), .t_req_qos(t_req_qos[gt*QW +: QW]),
        .t_req_addr(t_req_addr[gt*AW +: AW]), .t_req_wdata(t_req_wdata[gt*DW +: DW]), .t_req_wstrb(t_req_wstrb[gt*SB +: SB]),
        .t_rsp_valid(t_rsp_valid[gt]), .t_rsp_ready(t_rsp_ready[gt]), .t_rsp_src(t_rsp_src[gt*SRCW +: SRCW]),
        .t_rsp_id(t_rsp_id[gt*IDW +: IDW]), .t_rsp_opcode(t_rsp_opcode[gt*3 +: 3]), .t_rsp_status(t_rsp_status[gt*2 +: 2]),
        .t_rsp_rdata(t_rsp_rdata[gt*DW +: DW]), .quiesce(quiesce), .rsp_spurious(t_spur[gt]), .n_pending(t_pend[gt]),
        .n_spur_sent(t_spur_sent[gt])
      );
    end else begin : g_sfb2
      // SFB2 slave behind the SFB3 -> SFB2 bridge (the bridge is part of the checked path)
      logic          s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
      logic [AW-1:0] s_req_addr;
      logic [DW-1:0] s_req_wdata, s_rsp_rdata;
      logic [SB-1:0] s_req_wstrb;
      sfn_sfb2_tgt_bridge #(.NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .DEPTH(QCAP)) u_br (
        .clk, .rst_n,
        .t_req_valid(t_req_valid[gt]), .t_req_ready(t_req_ready[gt]), .t_req_opcode(t_req_opcode[gt*3 +: 3]),
        .t_req_src(t_req_src[gt*SRCW +: SRCW]), .t_req_id(t_req_id[gt*IDW +: IDW]), .t_req_qos(t_req_qos[gt*QW +: QW]),
        .t_req_addr(t_req_addr[gt*AW +: AW]), .t_req_wdata(t_req_wdata[gt*DW +: DW]), .t_req_wstrb(t_req_wstrb[gt*SB +: SB]),
        .t_rsp_valid(t_rsp_valid[gt]), .t_rsp_ready(t_rsp_ready[gt]), .t_rsp_src(t_rsp_src[gt*SRCW +: SRCW]),
        .t_rsp_id(t_rsp_id[gt*IDW +: IDW]), .t_rsp_opcode(t_rsp_opcode[gt*3 +: 3]), .t_rsp_status(t_rsp_status[gt*2 +: 2]),
        .t_rsp_rdata(t_rsp_rdata[gt*DW +: DW]),
        .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
        .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error
      );
      sfn_tb_sfb2_mem #(.T(gt), .AW(AW), .DW(DW), .Q(QCAP)) u_mem (
        .clk, .rst_n, .req_valid(s_req_valid), .req_ready(s_req_ready), .req_write(s_req_write), .req_addr(s_req_addr),
        .req_wdata(s_req_wdata), .req_wstrb(s_req_wstrb), .rsp_valid(s_rsp_valid), .rsp_ready(s_rsp_ready),
        .rsp_rdata(s_rsp_rdata), .rsp_error(s_rsp_error), .n_pending(t_pend[gt])
      );
      assign t_spur[gt] = 1'b0;
      assign t_spur_sent[gt] = 0;
    end
    sfn_protocol_checker #(.QW(3 + SRCW + IDW + QW + AW + DW + SB), .RW(SRCW + IDW + 3 + 2 + DW),
                           .NAME($sformatf("t%0d", gt))) u_pc (
      .clk, .rst_n,
      .req_valid(t_req_valid[gt]), .req_ready(t_req_ready[gt]),
      .req_payload({t_req_opcode[gt*3 +: 3], t_req_src[gt*SRCW +: SRCW], t_req_id[gt*IDW +: IDW], t_req_qos[gt*QW +: QW],
                    t_req_addr[gt*AW +: AW], t_req_wdata[gt*DW +: DW], t_req_wstrb[gt*SB +: SB]}),
      .rsp_valid(t_rsp_valid[gt]), .rsp_ready(t_rsp_ready[gt]),
      .rsp_payload({t_rsp_src[gt*SRCW +: SRCW], t_rsp_id[gt*IDW +: IDW], t_rsp_opcode[gt*3 +: 3],
                    t_rsp_status[gt*2 +: 2], t_rsp_rdata[gt*DW +: DW]}),
      .violations(viol_t[gt])
    );
  end

  // ================================================================ link monitor (utilisation)
  // crossbar / shared bus: request and response transfers per target port (t_nreq / t_nrsp below);
  // mesh: flits per router output link of both networks (hierarchical probe, mesh builds only)
  longint mesh_q_flits, mesh_s_flits;
  int     mesh_link_max, mesh_links_used;
  initial begin mesh_q_flits = 0; mesh_s_flits = 0; mesh_link_max = 0; mesh_links_used = 0; end
  if (DUT == 1 && TOPOLOGY == 2) begin : g_meshmon
    localparam int NL = MESH_X * MESH_Y * 5;
    int lq [NL], ls [NL];
    initial for (int i = 0; i < NL; i++) begin lq[i] = 0; ls[i] = 0; end
    always @(posedge clk) if (rst_n && sb_count) begin
      for (int i = 0; i < NL; i++) begin
        if (g_ref.dut.g_mesh.u_core.q_out_v[i]) begin lq[i] = lq[i] + 1; mesh_q_flits = mesh_q_flits + 1; end
        if (g_ref.dut.g_mesh.u_core.s_out_v[i]) begin ls[i] = ls[i] + 1; mesh_s_flits = mesh_s_flits + 1; end
      end
      mesh_link_max = 0; mesh_links_used = 0;
      for (int i = 0; i < NL; i++) begin
        if (lq[i] > mesh_link_max) mesh_link_max = lq[i];
        if (ls[i] > mesh_link_max) mesh_link_max = ls[i];
        if (lq[i] > 0) mesh_links_used = mesh_links_used + 1;
        if (ls[i] > 0) mesh_links_used = mesh_links_used + 1;
      end
    end
  end

  // ================================================================ reference decoder
  // returns target index, or -1 FENCE (local OKAY), -2 DECERR, -3 posted write dropped
  function automatic int ref_decode(input int m, input logic [2:0] op, input logic [AW-1:0] a);
    int hit;
    begin
      if (op == sfn_pkg::OP_FENCE) return -1;
      if (op > 3'd2) return -2;
      hit = -1;
      for (int t = NT - 1; t >= 0; t--)
        if ((a & TMASK[t*AW +: AW]) == TBASE[t*AW +: AW]) hit = t;
      if ((CHECK_ALIGN != 0 && OFF > 0 && (a & AW'(SB - 1)) != '0) || hit < 0 || !EN[m*NT + hit])
        return (op == sfn_pkg::OP_WRITE_POSTED) ? -3 : -2;
      return hit;
    end
  endfunction

  // reference traffic-class map (docs/PROTOCOL.md sec. 6), independent of sfs_tc_map:
  // CTRL if the master is a control master or the target is a register target, else RD / WR;
  // level from sfs_pkg::TC_QOS_DEFAULT {WR, RD, CTRL}.  The P22 reference fabric (DUT 1) and
  // TC_MODE 0 forward the master's own QoS.
  function automatic logic [2:0] ref_qos(input int m, input logic [2:0] op, input int d, input logic [2:0] q);
    logic [8:0] tbl;
    begin
      tbl = sfs_pkg::TC_QOS_DEFAULT;
      if (DUT != 0 || TC_MODE == 0)                ref_qos = q;
      else if (MCTRL[m] || (d >= 0 && TMMIO[d]))   ref_qos = tbl[2:0];
      else if (op == sfn_pkg::OP_READ)             ref_qos = tbl[5:3];
      else                                         ref_qos = tbl[8:6];
    end
  endfunction

  function automatic int popc(input logic [SB-1:0] v);
    popc = 0;
    for (int i = 0; i < SB; i++) popc = popc + int'(v[i]);
  endfunction

  // ================================================================ scoreboard storage
  localparam int QD = 64;
  // expected at target, per (m,t): index m*NT+t
  logic [2:0]    tq_op   [NM*NT][QD];
  logic [IDW-1:0] tq_id  [NM*NT][QD];
  logic [2:0]    tq_qos  [NM*NT][QD];
  logic [AW-1:0] tq_addr [NM*NT][QD];
  logic [DW-1:0] tq_wd   [NM*NT][QD];
  logic [SB-1:0] tq_ws   [NM*NT][QD];
  int            tq_acc  [NM*NT][QD];
  int            tq_pres [NM*NT][QD];
  int            tq_rd [NM*NT], tq_wr [NM*NT];
  // pending at target, per (t,src,id): index (t*NM+src)*NID+id
  logic [2:0]    tp_op   [NT*NM*NID][QD];
  int            tp_acc  [NT*NM*NID][QD];
  int            tp_pres [NT*NM*NID][QD];
  int            tp_tacc [NT*NM*NID][QD];
  logic [AW-1:0] tp_addr [NT*NM*NID][QD];
  int            tp_bytes[NT*NM*NID][QD];
  int            tp_rd [NT*NM*NID], tp_wr [NT*NM*NID];
  // expected master response, per (m,id): index m*NID+id
  logic [2:0]    rq_op   [NM*NID][QD];
  logic [1:0]    rq_st   [NM*NID][QD];
  logic [DW-1:0] rq_data [NM*NID][QD];
  int            rq_tgt  [NM*NID][QD];
  int            rq_acc  [NM*NID][QD];
  int            rq_pres [NM*NID][QD];
  int            rq_tacc [NM*NID][QD];
  logic [AW-1:0] rq_addr [NM*NID][QD];
  int            rq_bytes[NM*NID][QD];
  int            rq_rd [NM*NID], rq_wr [NM*NID];
  // fabric-rule shadows
  int            sb_out [NM];          // outstanding per master (posted retired at target response)
  int            sb_idc [NM*NID];
  int            sb_idt [NM*NID];

  // ================================================================ statistics
  int    cyc, errors, last_prog, first_acc, last_done;
  int    n_acc [NM], n_rsp [NM], n_posted_done [NM], n_drop [NM], acc_bytes [NM], rd_bytes [NM];
  int    req_stall [NM], rsp_stall [NM], sw_stall [NM], occ_max [NM], err_cyc [NM];
  longint lat_sum [NM], alat_sum [NM];
  int    pres_cyc [NM];
  logic  held [NM];
  int    lat_n [NM], lat_max [NM], lat_min [NM];
  int    t_nreq [NT], t_wr_bytes [NT], t_req_bp [NT], t_nrsp [NT], t_rsp_bp [NT];
  int    n_posted_err_exp, n_posted_err_seen, n_orphan_seen, n_badsrc_seen, n_spur_acc;
  int    wcnt [NM], wmax [NM];
  logic  decerr_flag, posted_flag, orphan_flag, badsrc_flag;   // sticky, since the last reset
  longint total_bytes;
  logic  sb_count;
  int    n_count_cyc;
  int    trace_fd;
  int    c_wd, c_maxcyc, c_resets, n_resets_done;
  string c_test;
  // spine statistics (DUT 0), recomputed from the ports and compared with SPINE_PERF
  int     sp_mqx [NM], sp_mqs [NM], sp_mqo_max [NM], sp_mrx [NM], sp_mrs [NM], sp_mro_max [NM];
  longint sp_mqo_sum [NM], sp_mro_sum [NM];
  int     sp_wait [NM], sp_wmax [NM], sp_loss [NM], sp_tbp [NM], sp_run [NM];
  int     sp_cacc [3], sp_cwait [3], sp_cmax [3], sp_closs [3];
  int     sp_tqx [NT], sp_tqs [NT], sp_tqo_max [NT], sp_trx [NT], sp_trs [NT], sp_tro_max [NT];
  longint sp_tqo_sum [NT], sp_tro_sum [NT];
  // SPINE_PERF counts through registered stages: link / port / per-master events one cycle late,
  // per-class counts two cycles late, the per-class maximum three cycles late (rtl/spine/sfs_perf.sv)
  int     p1_mqx [NM], p1_mqs [NM], p1_mqo [NM], p1_mrx [NM], p1_mrs [NM], p1_mro [NM];
  int     p1_wait [NM], p1_loss [NM], p1_accrun [NM];
  int     p1_tqx [NT], p1_tqs [NT], p1_tqo [NT], p1_trx [NT], p1_trs [NT], p1_tro [NT];
  int     ca_d1 [3], ca_d2 [3], cw_d1 [3], cw_d2 [3], cl_d1 [3], cl_d2 [3], cm_d1 [3], cm_d2 [3], cm_d3 [3];

  task automatic fail(input string msg);
    $error("[cyc %0d] %s", cyc, msg);
    errors = errors + 1;
  endtask

  task automatic sb_flush();
    for (int i = 0; i < NM*NT; i++) begin tq_rd[i] = 0; tq_wr[i] = 0; end
    for (int i = 0; i < NT*NM*NID; i++) begin tp_rd[i] = 0; tp_wr[i] = 0; end
    for (int i = 0; i < NM*NID; i++) begin rq_rd[i] = 0; rq_wr[i] = 0; sb_idc[i] = 0; sb_idt[i] = -9; end
    for (int m = 0; m < NM; m++) begin
      sb_out[m] = 0; n_acc[m] = 0; n_rsp[m] = 0; n_posted_done[m] = 0; n_drop[m] = 0; acc_bytes[m] = 0;
      rd_bytes[m] = 0; req_stall[m] = 0; rsp_stall[m] = 0; sw_stall[m] = 0; occ_max[m] = 0; err_cyc[m] = 0;
      lat_sum[m] = 0; alat_sum[m] = 0; held[m] = 1'b0; lat_n[m] = 0; lat_max[m] = 0; lat_min[m] = 32'h7fff_ffff; wcnt[m] = 0;
    end
    for (int t = 0; t < NT; t++) begin
      t_nreq[t] = 0; t_wr_bytes[t] = 0; t_req_bp[t] = 0; t_nrsp[t] = 0; t_rsp_bp[t] = 0;
    end
    n_posted_err_exp = 0; n_posted_err_seen = 0; n_orphan_seen = 0; n_badsrc_seen = 0; n_spur_acc = 0;
    for (int m = 0; m < NM; m++) begin
      sp_mqx[m] = 0; sp_mqs[m] = 0; sp_mqo_max[m] = 0; sp_mrx[m] = 0; sp_mrs[m] = 0; sp_mro_max[m] = 0;
      sp_mqo_sum[m] = 0; sp_mro_sum[m] = 0; sp_wait[m] = 0; sp_wmax[m] = 0; sp_loss[m] = 0; sp_tbp[m] = 0; sp_run[m] = 0;
    end
    for (int c = 0; c < 3; c++) begin
      sp_cacc[c] = 0; sp_cwait[c] = 0; sp_cmax[c] = 0; sp_closs[c] = 0;
      ca_d1[c] = 0; ca_d2[c] = 0; cw_d1[c] = 0; cw_d2[c] = 0; cl_d1[c] = 0; cl_d2[c] = 0; cm_d1[c] = 0; cm_d2[c] = 0; cm_d3[c] = 0;
    end
    for (int m = 0; m < NM; m++) begin
      p1_mqx[m] = 0; p1_mqs[m] = 0; p1_mqo[m] = 0; p1_mrx[m] = 0; p1_mrs[m] = 0; p1_mro[m] = 0;
      p1_wait[m] = 0; p1_loss[m] = 0; p1_accrun[m] = -1;
    end
    for (int t = 0; t < NT; t++) begin p1_tqx[t] = 0; p1_tqs[t] = 0; p1_tqo[t] = 0; p1_trx[t] = 0; p1_trs[t] = 0; p1_tro[t] = 0; end
    for (int t = 0; t < NT; t++) begin
      sp_tqx[t] = 0; sp_tqs[t] = 0; sp_tqo_max[t] = 0; sp_trx[t] = 0; sp_trs[t] = 0; sp_tro_max[t] = 0;
      sp_tqo_sum[t] = 0; sp_tro_sum[t] = 0;
    end
    decerr_flag = 1'b0; posted_flag = 1'b0; orphan_flag = 1'b0; badsrc_flag = 1'b0;
    sb_count = 1'b1;
    n_count_cyc = 0;
  endtask

  initial begin
    errors = 0; cyc = 0; last_prog = 0; first_acc = -1; last_done = 0; total_bytes = 0; n_resets_done = 0;
    for (int m = 0; m < NM; m++) wmax[m] = 0;
    sb_flush();
    c_wd = 4000;        void'($value$plusargs("wd=%d", c_wd));
    c_maxcyc = 2000000; void'($value$plusargs("maxcyc=%d", c_maxcyc));
    c_resets = 0;       void'($value$plusargs("resets=%d", c_resets));
    c_test = "unnamed"; void'($value$plusargs("test=%s", c_test));
    trace_fd = 0;
    begin
      string tf;
      if ($value$plusargs("trace=%s", tf)) begin
        trace_fd = $fopen(tf, "w");
        $fwrite(trace_fd, "master,id,op,addr,target,qos,issue_cycle,accept_cycle,target_cycle,done_cycle,status,bytes,latency,access_latency\n");
      end
    end
  end

  // ================================================================ per-cycle checking
  always @(posedge clk) begin
    int ri, qi, pi, k, t, m, lat;
    logic any_hs, any_pending;
    if (!rst_n) begin
      // R11: nothing transfers during reset, and the fabric drives no valid outputs
      if ((|(m_req_valid & m_req_ready)) || (|t_req_valid) || (|m_rsp_valid))
        fail("fabric transfer or valid output during reset");
    end else begin
      cyc = cyc + 1;
      if (sb_count) n_count_cyc = n_count_cyc + 1;
      any_hs = 1'b0;
      // ------------------------------------------------------------ 1. target responses
      for (t = 0; t < NT; t++) begin
        if (t_rsp_valid[t] && t_rsp_ready[t]) begin
          any_hs = 1'b1;
          if (sb_count) t_nrsp[t] = t_nrsp[t] + 1;
          if (t_spur[t]) begin
            n_spur_acc = n_spur_acc + 1;
          end else begin
            m  = int'(t_rsp_src[t*SRCW +: SRCW]);
            pi = (t * NM + m) * NID + int'(t_rsp_id[t*IDW +: IDW]);
            if (tp_rd[pi] == tp_wr[pi]) fail($sformatf("t%0d responded for src %0d id %0d with nothing pending", t, m,
                                                       t_rsp_id[t*IDW +: IDW]));
            else begin
              qi = tp_rd[pi] % QD;
              if (tp_op[pi][qi] != t_rsp_opcode[t*3 +: 3]) fail($sformatf("t%0d response opcode mismatch", t));
              ri = m * NID + int'(t_rsp_id[t*IDW +: IDW]);
              if (tp_op[pi][qi] == sfn_pkg::OP_WRITE_POSTED) begin
                // posted completion: retired by the fabric, never delivered
                sb_out[m] = sb_out[m] - 1;
                sb_idc[ri] = sb_idc[ri] - 1;
                n_posted_done[m] = n_posted_done[m] + 1;
                if (t_rsp_status[t*2 +: 2] != sfn_pkg::ST_OKAY) n_posted_err_exp = n_posted_err_exp + 1;
                if (trace_fd != 0)
                  $fwrite(trace_fd, "%0d,%0d,%0d,%h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n", m, t_rsp_id[t*IDW +: IDW],
                          tp_op[pi][qi], tp_addr[pi][qi], t, 0, tp_pres[pi][qi], tp_acc[pi][qi], tp_tacc[pi][qi], cyc - 1,
                          t_rsp_status[t*2 +: 2], tp_bytes[pi][qi], cyc - 1 - tp_acc[pi][qi], cyc - 1 - tp_pres[pi][qi]);
                if (cyc > last_done) last_done = cyc;
              end else begin
                if (rq_wr[ri] - rq_rd[ri] >= QD) fail("response queue overflow");
                k = rq_wr[ri] % QD;
                rq_op[ri][k]    = tp_op[pi][qi];
                rq_st[ri][k]    = t_rsp_status[t*2 +: 2];
                rq_data[ri][k]  = t_rsp_rdata[t*DW +: DW];
                rq_tgt[ri][k]   = t;
                rq_acc[ri][k]   = tp_acc[pi][qi];
                rq_pres[ri][k]  = tp_pres[pi][qi];
                rq_tacc[ri][k]  = tp_tacc[pi][qi];
                rq_addr[ri][k]  = tp_addr[pi][qi];
                rq_bytes[ri][k] = tp_bytes[pi][qi];
                rq_wr[ri] = rq_wr[ri] + 1;
              end
              tp_rd[pi] = tp_rd[pi] + 1;
            end
          end
        end
        if (sb_count && t_rsp_valid[t] && !t_rsp_ready[t]) t_rsp_bp[t] = t_rsp_bp[t] + 1;
      end
      // ------------------------------------------------------------ 2. master responses
      for (m = 0; m < NM; m++) begin
        if (m_rsp_valid[m] && m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED)
          fail($sformatf("m%0d received a posted-write completion", m));
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          any_hs = 1'b1;
          ri = m * NID + int'(m_rsp_id[m*IDW +: IDW]);
          if (rq_rd[ri] == rq_wr[ri]) fail($sformatf("m%0d got a response for id %0d with none expected (misroute/duplicate)",
                                                     m, m_rsp_id[m*IDW +: IDW]));
          else begin
            k = rq_rd[ri] % QD;
            if (rq_op[ri][k] != m_rsp_opcode[m*3 +: 3] || rq_st[ri][k] != m_rsp_status[m*2 +: 2] ||
                rq_data[ri][k] != m_rsp_rdata[m*DW +: DW])
              fail($sformatf("m%0d id %0d response mismatch: got op %0d st %0d data %h, expected op %0d st %0d data %h (tgt %0d)",
                             m, m_rsp_id[m*IDW +: IDW], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2],
                             m_rsp_rdata[m*DW +: DW], rq_op[ri][k], rq_st[ri][k], rq_data[ri][k], rq_tgt[ri][k]));
            lat = cyc - 1 - rq_acc[ri][k];
            if (sb_count) begin
              n_rsp[m] = n_rsp[m] + 1;
              lat_sum[m] = lat_sum[m] + longint'(lat);
              alat_sum[m] = alat_sum[m] + longint'(cyc - 1 - rq_pres[ri][k]);
              lat_n[m] = lat_n[m] + 1;
              if (lat > lat_max[m]) lat_max[m] = lat;
              if (lat < lat_min[m]) lat_min[m] = lat;
              if (m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_READ && m_rsp_status[m*2 +: 2] == sfn_pkg::ST_OKAY)
                rd_bytes[m] = rd_bytes[m] + SB;
            end
            if (rq_op[ri][k] == sfn_pkg::OP_READ && m_rsp_status[m*2 +: 2] == sfn_pkg::ST_OKAY)
              total_bytes = total_bytes + SB;
            if (trace_fd != 0)
              $fwrite(trace_fd, "%0d,%0d,%0d,%h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n", m, m_rsp_id[m*IDW +: IDW],
                      rq_op[ri][k], rq_addr[ri][k], rq_tgt[ri][k], 0, rq_pres[ri][k], rq_acc[ri][k], rq_tacc[ri][k], cyc - 1,
                      m_rsp_status[m*2 +: 2], rq_bytes[ri][k], lat, cyc - 1 - rq_pres[ri][k]);
            if (cyc > last_done) last_done = cyc;
            rq_rd[ri] = rq_rd[ri] + 1;
            sb_out[m] = sb_out[m] - 1;
            sb_idc[ri] = sb_idc[ri] - 1;
          end
        end
        if (sb_count && m_rsp_valid[m] && !m_rsp_ready[m]) rsp_stall[m] = rsp_stall[m] + 1;
      end
      // ------------------------------------------------------------ 3. master requests
      for (m = 0; m < NM; m++) begin
        logic [2:0] op;
        logic [AW-1:0] a;
        int d, id;
        op = m_req_opcode[m*3 +: 3];
        a  = m_req_addr[m*AW +: AW];
        id = int'(m_req_id[m*IDW +: IDW]);
        d  = ref_decode(m, op, a);
        if (m_req_valid[m] && !held[m]) pres_cyc[m] = cyc - 1;     // first cycle this request is presented
        held[m] = m_req_valid[m] && !m_req_ready[m];
        if (obs_decerr[m] != (m_req_valid[m] && m_req_ready[m] && d <= -2))
          fail($sformatf("m%0d decode-error event %0d, expected %0d", m, obs_decerr[m], m_req_valid[m] && m_req_ready[m] && d <= -2));
        if (sb_count && m_req_valid[m] && !m_req_ready[m]) req_stall[m] = req_stall[m] + 1;
        if (sb_count && obs_sw_valid[m] && !obs_sw_ready[m]) sw_stall[m] = sw_stall[m] + 1;
        if (m_req_valid[m] && m_req_ready[m]) begin
          any_hs = 1'b1;
          if (first_acc < 0) first_acc = cyc;
          if (sb_count) begin
            n_acc[m] = n_acc[m] + 1;
            if (op == sfn_pkg::OP_READ) acc_bytes[m] = acc_bytes[m] + SB;
            else if (sfn_pkg::op_is_write(op)) acc_bytes[m] = acc_bytes[m] + popc(m_req_wstrb[m*SB +: SB]);
          end
          ri = m * NID + id;
          if (op == sfn_pkg::OP_FENCE && sb_out[m] != 0)
            fail($sformatf("m%0d FENCE accepted with %0d transactions outstanding (O3)", m, sb_out[m]));
          if (d == -3) begin
            n_drop[m] = n_drop[m] + 1;
            posted_flag = 1'b1;
          end else begin
            // O2: one target per outstanding ID (-1 = local responder)
            if (sb_idc[ri] > 0 && sb_idt[ri] != ((d >= 0) ? d : -1))
              fail($sformatf("m%0d id %0d sent to %0d while outstanding at %0d (O2)", m, id, d, sb_idt[ri]));
            sb_idc[ri] = sb_idc[ri] + 1;
            sb_idt[ri] = (d >= 0) ? d : -1;
            sb_out[m] = sb_out[m] + 1;
            if (sb_out[m] > int'(MMAXO[m*8 +: 8]))
              fail($sformatf("m%0d has %0d outstanding > MAXO %0d (O1)", m, sb_out[m], MMAXO[m*8 +: 8]));
            if (d >= 0) begin
              qi = m * NT + d;
              if (tq_wr[qi] - tq_rd[qi] >= QD) fail("target expectation queue overflow");
              k = tq_wr[qi] % QD;
              tq_op[qi][k] = op; tq_id[qi][k] = IDW'(id); tq_qos[qi][k] = ref_qos(m, op, d, m_req_qos[m*QW +: QW]);
              tq_addr[qi][k] = a; tq_wd[qi][k] = m_req_wdata[m*DW +: DW]; tq_ws[qi][k] = m_req_wstrb[m*SB +: SB];
              tq_acc[qi][k] = cyc - 1;
              tq_pres[qi][k] = pres_cyc[m];
              tq_wr[qi] = tq_wr[qi] + 1;
            end else begin
              // fabric-local response: FENCE -> OKAY, everything else -> DECERR
              k = rq_wr[ri] % QD;
              rq_op[ri][k]    = op;
              rq_st[ri][k]    = (d == -1) ? sfn_pkg::ST_OKAY : sfn_pkg::ST_DECERR;
              rq_data[ri][k]  = '0;
              rq_tgt[ri][k]   = -1;
              rq_acc[ri][k]   = cyc - 1;
              rq_pres[ri][k]  = pres_cyc[m];
              rq_tacc[ri][k]  = -1;
              rq_addr[ri][k]  = a;
              rq_bytes[ri][k] = 0;
              rq_wr[ri] = rq_wr[ri] + 1;
            end
          end
        end
        if (int'(obs_out_cnt[m*CW +: CW]) > int'(MMAXO[m*8 +: 8]))
          fail($sformatf("m%0d fabric outstanding count %0d > MAXO (O1)", m, obs_out_cnt[m*CW +: CW]));
        if (sb_count && int'(obs_out_cnt[m*CW +: CW]) > occ_max[m]) occ_max[m] = int'(obs_out_cnt[m*CW +: CW]);
        if (obs_posted_err[m]) begin n_posted_err_seen = n_posted_err_seen + 1; posted_flag = 1'b1; end
        if (obs_orphan[m])     begin n_orphan_seen = n_orphan_seen + 1; orphan_flag = 1'b1; end
        if (obs_decerr[m])     decerr_flag = 1'b1;
        if (sb_count)
          err_cyc[m] = err_cyc[m] + int'(m_rsp_valid[m] && m_rsp_ready[m] && m_rsp_status[m*2 +: 2] != sfn_pkg::ST_OKAY)
                                  + int'(obs_posted_err[m])
                                  + int'(obs_decerr[m] && m_req_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED);
      end
      for (t = 0; t < NT; t++) if (obs_bad_src[t]) begin n_badsrc_seen = n_badsrc_seen + 1; badsrc_flag = 1'b1; end
      // ------------------------------------------------------------ 4. target requests
      for (t = 0; t < NT; t++) begin
        if (sb_count && t_req_valid[t] && !t_req_ready[t]) t_req_bp[t] = t_req_bp[t] + 1;
        if (t_req_valid[t] && t_req_ready[t]) begin
          logic [2:0] op;
          any_hs = 1'b1;
          m  = int'(t_req_src[t*SRCW +: SRCW]);
          op = t_req_opcode[t*3 +: 3];
          if (sb_count) begin
            t_nreq[t] = t_nreq[t] + 1;
            if (sfn_pkg::op_is_write(op)) t_wr_bytes[t] = t_wr_bytes[t] + popc(t_req_wstrb[t*SB +: SB]);
          end
          if (m >= NM || !EN[m*NT + t]) fail($sformatf("t%0d request from illegal source %0d", t, m));
          else begin
            qi = m * NT + t;
            if (tq_rd[qi] == tq_wr[qi]) fail($sformatf("t%0d got a request from m%0d that was never sent (duplicate/misroute)", t, m));
            else begin
              k = tq_rd[qi] % QD;
              if (tq_op[qi][k] != op || tq_id[qi][k] != t_req_id[t*IDW +: IDW] || tq_qos[qi][k] != t_req_qos[t*QW +: QW] ||
                  tq_addr[qi][k] != t_req_addr[t*AW +: AW] ||
                  (sfn_pkg::op_is_write(op) && (tq_wd[qi][k] != t_req_wdata[t*DW +: DW] || tq_ws[qi][k] != t_req_wstrb[t*SB +: SB])))
                fail($sformatf("t%0d request from m%0d differs from the master's (order/corruption): op %0d/%0d addr %h/%h",
                               t, m, op, tq_op[qi][k], t_req_addr[t*AW +: AW], tq_addr[qi][k]));
              pi = (t * NM + m) * NID + int'(t_req_id[t*IDW +: IDW]);
              if (tp_wr[pi] - tp_rd[pi] >= QD) fail("target pending queue overflow");
              qi = tp_wr[pi] % QD;
              tp_op[pi][qi]    = op;
              tp_acc[pi][qi]   = tq_acc[m * NT + t][k];
              tp_pres[pi][qi]  = tq_pres[m * NT + t][k];
              tp_tacc[pi][qi]  = cyc - 1;
              tp_addr[pi][qi]  = t_req_addr[t*AW +: AW];
              tp_bytes[pi][qi] = (op == sfn_pkg::OP_READ) ? SB : popc(t_req_wstrb[t*SB +: SB]);
              tp_wr[pi] = tp_wr[pi] + 1;
              if (sfn_pkg::op_is_write(op)) total_bytes = total_bytes + longint'(popc(t_req_wstrb[t*SB +: SB]));
              tq_rd[m * NT + t] = tq_rd[m * NT + t] + 1;
            end
          end
        end
      end
      // ------------------------------------------------------------ 5. fairness
      // spine: at the central routing stage -- while the head of master link m waits for its
      // target, count the acceptances of other masters at the same target
      if (DUT == 0) begin
        for (m = 0; m < NM; m++) begin
          if (obs_c_valid[m] && !obs_c_ready[m]) begin
            for (int j = 0; j < NM; j++)
              if (j != m && obs_c_valid[j] && obs_c_ready[j] && obs_c_tgt[j*TW +: TW] == obs_c_tgt[m*TW +: TW])
                wcnt[m] = wcnt[m] + 1;
          end else begin
            if (wcnt[m] > wmax[m]) wmax[m] = wcnt[m];
            wcnt[m] = 0;
          end
        end
      end else if (TOPOLOGY != sfn_pkg::TOPO_MESH) begin
        for (m = 0; m < NM; m++) begin
          if (obs_sw_valid[m] && !obs_sw_ready[m]) begin
            for (int j = 0; j < NM; j++) begin
              if (j != m && obs_sw_valid[j] && obs_sw_ready[j] &&
                  (TOPOLOGY == sfn_pkg::TOPO_SHARED_BUS ||
                   ref_decode(j, m_req_opcode[j*3 +: 3], m_req_addr[j*AW +: AW]) ==
                   ref_decode(m, m_req_opcode[m*3 +: 3], m_req_addr[m*AW +: AW])))
                wcnt[m] = wcnt[m] + 1;
            end
          end else begin
            if (wcnt[m] > wmax[m]) wmax[m] = wcnt[m];
            wcnt[m] = 0;
          end
        end
      end
      // ------------------------------------------------------------ 6. liveness watchdog
      any_pending = 1'b0;
      for (m = 0; m < NM; m++) if (sb_out[m] > 0 || m_req_valid[m]) any_pending = 1'b1;
      if (any_hs) last_prog = cyc;
      else if (any_pending && (cyc - last_prog) > c_wd) begin
        fail($sformatf("no progress for %0d cycles with work pending: DEADLOCK/LIVELOCK", c_wd));
        finish_run();
      end
      if (cyc > c_maxcyc) begin
        fail("maximum cycle count reached");
        finish_run();
      end
      // ------------------------------------------------------------ 7. spine statistics (SPINE_PERF model)
      if (DUT == 0) begin
        int cacc [3], cwait [3], closs [3], cmx [3];
        // (a) count what the RTL counts at this edge: last cycle's link / port events, the class counts of
        //     two cycles ago and the class maximum of three cycles ago
        if (sb_count) begin
          for (m = 0; m < NM; m++) begin
            sp_mqx[m] = sp_mqx[m] + p1_mqx[m];
            sp_mqs[m] = sp_mqs[m] + p1_mqs[m];
            sp_mqo_sum[m] = sp_mqo_sum[m] + longint'(p1_mqo[m]);
            if (p1_mqo[m] > sp_mqo_max[m]) sp_mqo_max[m] = p1_mqo[m];
            sp_mrx[m] = sp_mrx[m] + p1_mrx[m];
            sp_mrs[m] = sp_mrs[m] + p1_mrs[m];
            sp_mro_sum[m] = sp_mro_sum[m] + longint'(p1_mro[m]);
            if (p1_mro[m] > sp_mro_max[m]) sp_mro_max[m] = p1_mro[m];
            if (p1_wait[m] != 0) begin
              sp_wait[m] = sp_wait[m] + 1;
              if (p1_loss[m] != 0) sp_loss[m] = sp_loss[m] + 1; else sp_tbp[m] = sp_tbp[m] + 1;
            end
            if (p1_accrun[m] > sp_wmax[m]) sp_wmax[m] = p1_accrun[m];
          end
          for (t = 0; t < NT; t++) begin
            sp_tqx[t] = sp_tqx[t] + p1_tqx[t];
            sp_tqs[t] = sp_tqs[t] + p1_tqs[t];
            sp_tqo_sum[t] = sp_tqo_sum[t] + longint'(p1_tqo[t]);
            if (p1_tqo[t] > sp_tqo_max[t]) sp_tqo_max[t] = p1_tqo[t];
            sp_trx[t] = sp_trx[t] + p1_trx[t];
            sp_trs[t] = sp_trs[t] + p1_trs[t];
            sp_tro_sum[t] = sp_tro_sum[t] + longint'(p1_tro[t]);
            if (p1_tro[t] > sp_tro_max[t]) sp_tro_max[t] = p1_tro[t];
          end
          for (int c = 0; c < 3; c++) begin
            sp_cacc[c] = sp_cacc[c] + ca_d2[c];
            sp_cwait[c] = sp_cwait[c] + cw_d2[c];
            sp_closs[c] = sp_closs[c] + cl_d2[c];
            if (cm_d3[c] > sp_cmax[c]) sp_cmax[c] = cm_d3[c];
          end
        end
        // (b) this cycle's observations
        for (int c = 0; c < 3; c++) begin cacc[c] = 0; cwait[c] = 0; closs[c] = 0; cmx[c] = 0; end
        for (m = 0; m < NM; m++) begin
          int cl;
          cl = int'(obs_c_tc[m*2 +: 2]);
          if (obs_c_valid[m] && cl > 2) fail($sformatf("m%0d request at the central stage with class %0d", m, cl));
          p1_mqx[m]    = int'(obs_c_valid[m] && obs_c_ready[m]);
          p1_mqs[m]    = int'(obs_sw_valid[m] && !obs_sw_ready[m]);
          p1_mqo[m]    = int'(obs_mq_occ[m*OCCW +: OCCW]);
          p1_mrx[m]    = int'(obs_cr_valid[m] && obs_cr_ready[m]);
          p1_mrs[m]    = int'(obs_cr_valid[m] && !obs_cr_ready[m]);
          p1_mro[m]    = int'(obs_mr_occ[m*OCCW +: OCCW]);
          p1_wait[m]   = int'(obs_c_valid[m] && !obs_c_ready[m]);
          p1_loss[m]   = int'(obs_c_valid[m] && !obs_c_ready[m] && obs_c_loss[m]);
          p1_accrun[m] = (obs_c_valid[m] && obs_c_ready[m]) ? sp_run[m] : -1;
          if (cl < 3) begin
            if (obs_c_valid[m] && obs_c_ready[m]) begin
              cacc[cl] = cacc[cl] + 1;
              if (sp_run[m] > cmx[cl]) cmx[cl] = sp_run[m];
            end
            if (obs_c_valid[m] && !obs_c_ready[m]) begin
              cwait[cl] = cwait[cl] + 1;
              if (obs_c_loss[m]) closs[cl] = closs[cl] + 1;
            end
          end
          // wait run (16-bit saturating in the RTL; never reached here)
          if (obs_c_valid[m] && !obs_c_ready[m]) sp_run[m] = sp_run[m] + 1; else sp_run[m] = 0;
        end
        for (t = 0; t < NT; t++) begin
          p1_tqx[t] = int'(obs_x_valid[t] && obs_x_ready[t]);
          p1_tqs[t] = int'(obs_x_valid[t] && !obs_x_ready[t]);
          p1_tqo[t] = int'(obs_tq_occ[t*OCCW +: OCCW]);
          p1_trx[t] = int'(t_rsp_valid[t] && t_rsp_ready[t]);
          p1_trs[t] = int'(t_rsp_valid[t] && !t_rsp_ready[t]);
          p1_tro[t] = int'(obs_tr_occ[t*OCCW +: OCCW]);
        end
        for (int c = 0; c < 3; c++) begin
          ca_d2[c] = ca_d1[c]; ca_d1[c] = cacc[c];
          cw_d2[c] = cw_d1[c]; cw_d1[c] = cwait[c];
          cl_d2[c] = cl_d1[c]; cl_d1[c] = closs[c];
          cm_d3[c] = cm_d2[c]; cm_d2[c] = cm_d1[c]; cm_d1[c] = cmx[c];
        end
      end
      // perf freeze point (see end-of-test sequence)
      if (rb_sel && rb_we && rb_addr == 12'h000 && !rb_wdata[0]) sb_count = 1'b0;
    end
  end

  // ================================================================ reset driver
  initial begin
    logic [31:0] r;
    int s;
    s = 1; void'($value$plusargs("seed=%d", s));
    r = seed_mix(32'(s), 32'd777);
    rst_n = 1'b0;
    rb_sel = 1'b0; rb_we = 1'b0; rb_addr = '0; rb_wdata = '0; rb_sel_spine = 1'b0;
    repeat (4) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;               // release between edges: no race with the clocked blocks
    for (int i = 0; i < c_resets; i++) begin
      r = xs32(r);
      repeat (300 + int'(r % 32'd1500)) @(posedge clk);
      #3 rst_n = 1'b0;                         // asynchronous assertion, mid-cycle
      sb_flush();
      n_resets_done = n_resets_done + 1;
      r = xs32(r);
      repeat (2 + int'(r % 32'd3)) @(posedge clk);
      @(negedge clk) rst_n = 1'b1;             // synchronous release (between edges: race-free in every simulator)
    end
  end

  // ================================================================ end of test
  logic finishing = 1'b0;
  task automatic rb_read(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a;
    #1 d = rb_rdata;
    if (rb_err) fail($sformatf("perf read 0x%03h reported rb_err", a));
    @(negedge clk);
    rb_sel = 1'b0;
  endtask

  task automatic rb_read_sp(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk);
    rb_sel_spine = 1'b1; rb_we = 1'b0; rb_addr = a;
    #1 d = rb_rdata;
    if (rb_err) fail($sformatf("spine perf read 0x%03h reported rb_err", a));
    @(negedge clk);
    rb_sel_spine = 1'b0;
  endtask

  task automatic chk(input string what, input int got, input int exp);
    if (got != exp) fail($sformatf("perf counter %s = %0d, expected %0d", what, got, exp));
  endtask

  task automatic finish_run();
    int nv, sum_ok, sum_err, n_txn, lmax, lsum, ln;
    longint ls;
    real thr;
    if (finishing) return;
    finishing = 1'b1;
    // drained?
    for (int i = 0; i < NM*NT; i++) if (tq_rd[i] != tq_wr[i]) fail($sformatf("lost request(s) for m%0d->t%0d", i / NT, i % NT));
    for (int i = 0; i < NT*NM*NID; i++) if (tp_rd[i] != tp_wr[i]) fail("request(s) never answered by a target");
    for (int i = 0; i < NM*NID; i++) if (rq_rd[i] != rq_wr[i]) fail($sformatf("lost response(s) for m%0d id %0d", i / NID, i % NID));
    for (int m = 0; m < NM; m++) if (sb_out[m] != 0) fail($sformatf("m%0d still has %0d outstanding", m, sb_out[m]));
    if (n_posted_err_seen != n_posted_err_exp)
      fail($sformatf("posted-error events %0d, expected %0d", n_posted_err_seen, n_posted_err_exp));
    if (n_orphan_seen + n_badsrc_seen != n_spur_acc)
      fail($sformatf("orphan %0d + bad-source %0d events != %0d spurious responses accepted", n_orphan_seen, n_badsrc_seen, n_spur_acc));
    nv = 0;
    for (int m = 0; m < NM; m++) nv = nv + viol_m[m];
    for (int t = 0; t < NT; t++) nv = nv + viol_t[t];
    if (nv != 0) fail($sformatf("%0d protocol violations", nv));
    sum_ok = 0; sum_err = 0;
    for (int m = 0; m < NM; m++) begin sum_ok = sum_ok + m_chk_ok[m]; sum_err = sum_err + m_chk_err[m]; end
    // fairness bound
    if (TOPOLOGY != sfn_pkg::TOPO_MESH && ARB_MODE != sfn_pkg::ARB_FIXED)
      for (int m = 0; m < NM; m++)
        if (wmax[m] > ((ARB_MODE == sfn_pkg::ARB_QOS) ? STARVE + NM - 1 : NM - 1))
          fail($sformatf("m%0d waited %0d other acceptances (> fairness bound)", m, wmax[m]));
    // QoS effectiveness (+qos_check=1 with +qos_idx=1: QoS level = master index): the top level must
    // wait clearly less at the switch than a lower level with the same outstanding limit (master 1)
    // spine: the arbitration wait is measured at the central stage (link stages absorb node stalls)
    if ($test$plusargs("qos_check") && NM >= 3 && DUT != 0 && !(sw_stall[NM-1] * 4 < sw_stall[1] * 3))
      fail($sformatf("QoS ineffective: top-level master waited %0d switch cycles vs %0d for level 1", sw_stall[NM-1], sw_stall[1]));
    if ($test$plusargs("qos_check") && NM >= 3 && DUT == 0 && !(sp_wait[NM-1] * 4 < sp_wait[1] * 3))
      fail($sformatf("QoS ineffective: top-level master waited %0d central-stage cycles vs %0d for level 1", sp_wait[NM-1], sp_wait[1]));
    // performance counters (counted since the last reset, frozen at the same edge)
    if (PERF != 0 && errors == 0) begin
      logic [31:0] v;
      @(negedge clk);
      rb_sel = 1'b1; rb_we = 1'b1; rb_addr = 12'h000; rb_wdata = 32'd0;     // ENABLE = 0
      @(negedge clk);
      rb_sel = 1'b0; rb_we = 1'b0;
      for (int m = 0; m < NM; m++) begin
        logic [11:0] b;
        b = 12'(32'h100 + m * 32'h40);
        rb_read(b + 12'd0,  v); chk($sformatf("m%0d.REQ", m), int'(v), n_acc[m]);
        rb_read(b + 12'd4,  v); chk($sformatf("m%0d.ACC_BYTES", m), int'(v), acc_bytes[m]);
        rb_read(b + 12'd8,  v); chk($sformatf("m%0d.RSP", m), int'(v), n_rsp[m]);
        rb_read(b + 12'd12, v); chk($sformatf("m%0d.RD_BYTES", m), int'(v), rd_bytes[m]);
        rb_read(b + 12'd16, v); chk($sformatf("m%0d.REQ_STALL", m), int'(v), req_stall[m]);
        rb_read(b + 12'd20, v); chk($sformatf("m%0d.ARB_STALL", m), int'(v), sw_stall[m]);
        rb_read(b + 12'd28, v); chk($sformatf("m%0d.RSP_STALL", m), int'(v), rsp_stall[m]);
        rb_read(b + 12'd36, v); chk($sformatf("m%0d.OCC_MAX", m), int'(v), occ_max[m]);
        rb_read(b + 12'd52, v); chk($sformatf("m%0d.ERR", m), int'(v), err_cyc[m]);
        rb_read(b + 12'd44, v); ln = int'(v);
        rb_read(b + 12'd40, v); lsum = int'(v);
        rb_read(b + 12'd48, v); lmax = int'(v);
        if (ln > n_rsp[m]) fail($sformatf("m%0d sampled latency count %0d > responses %0d", m, ln, n_rsp[m]));
        if (ln > 0 && (lmax > lat_max[m] || lsum < ln * lat_min[m] || lsum > ln * lat_max[m]))
          fail($sformatf("m%0d sampled latency (n %0d sum %0d max %0d) outside measured [%0d,%0d]", m, ln, lsum, lmax,
                         lat_min[m], lat_max[m]));
      end
      for (int t = 0; t < NT; t++) begin
        logic [11:0] b;
        b = 12'(32'h800 + t * 32'h20);
        rb_read(b + 12'd0,  v); chk($sformatf("t%0d.REQ", t), int'(v), t_nreq[t]);
        rb_read(b + 12'd4,  v); chk($sformatf("t%0d.WR_BYTES", t), int'(v), t_wr_bytes[t]);
        rb_read(b + 12'd8,  v); chk($sformatf("t%0d.REQ_BP", t), int'(v), t_req_bp[t]);
        rb_read(b + 12'd12, v); chk($sformatf("t%0d.RSP", t), int'(v), t_nrsp[t]);
        rb_read(b + 12'd16, v); chk($sformatf("t%0d.RSP_BP", t), int'(v), t_rsp_bp[t]);
      end
      rb_read(12'h008, v);
      chk("ERR_STATUS", int'(v[3:0]), int'({badsrc_flag, orphan_flag, posted_flag, decerr_flag}));
      if (DUT == 0) begin
        rb_read_sp(12'h004, v); chk("SPINE.CYCLES", int'(v), n_count_cyc);
        rb_read_sp(12'h00C, v); chk("SPINE.ID", int'(v), 32'h5350_4E31);
        for (int c = 0; c < 3; c++) begin
          logic [11:0] b;
          b = 12'(32'h040 + c * 32'h10);
          rb_read_sp(b + 12'd0,  v); chk($sformatf("class%0d.ACC", c), int'(v), sp_cacc[c]);
          rb_read_sp(b + 12'd4,  v); chk($sformatf("class%0d.WAIT", c), int'(v), sp_cwait[c]);
          rb_read_sp(b + 12'd8,  v); chk($sformatf("class%0d.WAIT_MAX", c), int'(v), sp_cmax[c]);
          rb_read_sp(b + 12'd12, v); chk($sformatf("class%0d.ARB_LOSS", c), int'(v), sp_closs[c]);
        end
        for (int m = 0; m < NM; m++) begin
          logic [11:0] b;
          b = 12'(32'h100 + m * 32'h20);
          rb_read_sp(b + 12'h00, v); chk($sformatf("mlink%0d.Q_XFER", m), int'(v), sp_mqx[m]);
          rb_read_sp(b + 12'h04, v); chk($sformatf("mlink%0d.Q_STALL", m), int'(v), sp_mqs[m]);
          rb_read_sp(b + 12'h08, v); chk($sformatf("mlink%0d.Q_OCC_SUM", m), int'(v), int'(sp_mqo_sum[m]));
          rb_read_sp(b + 12'h0C, v); chk($sformatf("mlink%0d.Q_OCC_MAX", m), int'(v), sp_mqo_max[m]);
          rb_read_sp(b + 12'h10, v); chk($sformatf("mlink%0d.R_XFER", m), int'(v), sp_mrx[m]);
          rb_read_sp(b + 12'h14, v); chk($sformatf("mlink%0d.R_STALL", m), int'(v), sp_mrs[m]);
          rb_read_sp(b + 12'h18, v); chk($sformatf("mlink%0d.R_OCC_SUM", m), int'(v), int'(sp_mro_sum[m]));
          rb_read_sp(b + 12'h1C, v); chk($sformatf("mlink%0d.R_OCC_MAX", m), int'(v), sp_mro_max[m]);
          b = 12'(32'h600 + m * 32'h10);
          rb_read_sp(b + 12'h0, v); chk($sformatf("central%0d.WAIT", m), int'(v), sp_wait[m]);
          rb_read_sp(b + 12'h4, v); chk($sformatf("central%0d.WAIT_MAX", m), int'(v), sp_wmax[m]);
          rb_read_sp(b + 12'h8, v); chk($sformatf("central%0d.ARB_LOSS", m), int'(v), sp_loss[m]);
          rb_read_sp(b + 12'hC, v); chk($sformatf("central%0d.TGT_BP", m), int'(v), sp_tbp[m]);
        end
        for (int t = 0; t < NT; t++) begin
          logic [11:0] b;
          b = 12'(32'h800 + t * 32'h20);
          rb_read_sp(b + 12'h00, v); chk($sformatf("tlink%0d.Q_XFER", t), int'(v), sp_tqx[t]);
          rb_read_sp(b + 12'h04, v); chk($sformatf("tlink%0d.Q_STALL", t), int'(v), sp_tqs[t]);
          rb_read_sp(b + 12'h08, v); chk($sformatf("tlink%0d.Q_OCC_SUM", t), int'(v), int'(sp_tqo_sum[t]));
          rb_read_sp(b + 12'h0C, v); chk($sformatf("tlink%0d.Q_OCC_MAX", t), int'(v), sp_tqo_max[t]);
          rb_read_sp(b + 12'h10, v); chk($sformatf("tlink%0d.R_XFER", t), int'(v), sp_trx[t]);
          rb_read_sp(b + 12'h14, v); chk($sformatf("tlink%0d.R_STALL", t), int'(v), sp_trs[t]);
          rb_read_sp(b + 12'h18, v); chk($sformatf("tlink%0d.R_OCC_SUM", t), int'(v), int'(sp_tro_sum[t]));
          rb_read_sp(b + 12'h1C, v); chk($sformatf("tlink%0d.R_OCC_MAX", t), int'(v), sp_tro_max[t]);
        end
      end
    end
    if (assert_errors != 0) fail($sformatf("%0d in-RTL assertion failures (ASSERT lines above)", assert_errors));
    // summary
    n_txn = 0; ls = 0; ln = 0; lmax = 0;
    for (int m = 0; m < NM; m++) begin
      n_txn = n_txn + n_acc[m];
      ls = ls + lat_sum[m]; ln = ln + lat_n[m];
      if (lat_max[m] > lmax) lmax = lat_max[m];
    end
    thr = (last_done > first_acc && first_acc >= 0) ? real'(total_bytes) / real'(last_done - first_acc + 1) : 0.0;
    begin
      longint als;
      als = 0;
      for (int m = 0; m < NM; m++) als = als + alat_sum[m];
      $display("RESULT {\"test\":\"%s\",\"pass\":%0d,\"errors\":%0d,\"cycles\":%0d,\"txns\":%0d,\"resets\":%0d,\"self_checks\":%0d,\"self_check_err\":%0d,\"avg_lat\":%0.2f,\"avg_access_lat\":%0.2f,\"max_lat\":%0d,\"bytes\":%0d,\"bytes_per_cycle\":%0.3f,\"spurious\":%0d,\"posted_err\":%0d,\"wait_max\":[%s],\"sw_stall\":[%s]}",
               c_test, (errors == 0 && sum_err == 0) ? 1 : 0, errors + sum_err, cyc, n_txn, n_resets_done, sum_ok, sum_err,
               (ln > 0) ? real'(ls) / real'(ln) : 0.0, (ln > 0) ? real'(als) / real'(ln) : 0.0, lmax, total_bytes, thr,
               n_spur_acc, n_posted_err_seen, wmax_str(), swst_str());
      begin
        int tmax;
        tmax = 0;
        for (int t = 0; t < NT; t++) begin
          if (t_nreq[t] > tmax) tmax = t_nreq[t];
          if (t_nrsp[t] > tmax) tmax = t_nrsp[t];
        end
        $display("LINKS {\"cycles_counted\":%0d,\"tgt_link_max_transfers\":%0d,\"tgt_req\":[%s],\"mesh_req_flits\":%0d,\"mesh_rsp_flits\":%0d,\"mesh_link_max_flits\":%0d,\"mesh_links_used\":%0d}",
                 n_count_cyc, tmax, treq_str(), mesh_q_flits, mesh_s_flits, mesh_link_max, mesh_links_used);
      end
      if (DUT == 0) $display("SPINE {\"cycles\":%0d,\"mq_xfer\":[%s],\"mq_stall\":[%s],\"mq_occ_sum\":[%s],\"mq_occ_max\":[%s],\"mr_xfer\":[%s],\"mr_stall\":[%s],\"mr_occ_sum\":[%s],\"mr_occ_max\":[%s],\"c_wait\":[%s],\"c_wait_max\":[%s],\"c_loss\":[%s],\"c_tgt_bp\":[%s],\"cls_acc\":[%s],\"cls_wait\":[%s],\"cls_wait_max\":[%s],\"cls_loss\":[%s],\"tq_xfer\":[%s],\"tq_stall\":[%s],\"tq_occ_sum\":[%s],\"tq_occ_max\":[%s],\"tr_xfer\":[%s],\"tr_stall\":[%s],\"tr_occ_sum\":[%s],\"tr_occ_max\":[%s],\"m_acc\":[%s],\"m_rsp\":[%s],\"m_lat_sum\":[%s],\"m_lat_max\":[%s],\"m_req_stall\":[%s],\"m_occ_max\":[%s],\"mpipe\":[%s],\"tpipe\":[%s],\"maxo\":[%s]}",
                 n_count_cyc, ia(sp_mqx, NM), ia(sp_mqs, NM), la(sp_mqo_sum, NM), ia(sp_mqo_max, NM), ia(sp_mrx, NM),
                 ia(sp_mrs, NM), la(sp_mro_sum, NM), ia(sp_mro_max, NM), ia(sp_wait, NM), ia(sp_wmax, NM), ia(sp_loss, NM),
                 ia(sp_tbp, NM), ia3(sp_cacc), ia3(sp_cwait), ia3(sp_cmax), ia3(sp_closs), iat(sp_tqx), iat(sp_tqs),
                 lat_(sp_tqo_sum), iat(sp_tqo_max), iat(sp_trx), iat(sp_trs), lat_(sp_tro_sum), iat(sp_tro_max),
                 ia(n_acc, NM), ia(n_rsp, NM), la(lat_sum, NM), ia(lat_max, NM), ia(req_stall, NM), ia(occ_max, NM),
                 pstr(MPIPE, NM), pstr(TPIPE, NT), mstr());
    end
    for (int m = 0; m < NM; m++)
      $display("  m%0d: acc %0d rsp %0d posted %0d drops %0d lat avg %0.1f max %0d  req_stall %0d sw_stall %0d occ_max %0d wait_max %0d",
               m, n_acc[m], n_rsp[m], n_posted_done[m], n_drop[m], (lat_n[m] > 0) ? real'(lat_sum[m]) / real'(lat_n[m]) : 0.0,
               lat_max[m], req_stall[m], sw_stall[m], occ_max[m], wmax[m]);
    if (trace_fd != 0) $fclose(trace_fd);
    if (errors != 0 || sum_err != 0) $fatal(1, "TEST FAILED: %0d errors", errors + sum_err);
    $display("TEST PASSED");
    $finish;
  endtask

  function automatic string ia(input int a [NM], input int n);
    string s; s = "";
    for (int i = 0; i < n; i++) s = {s, $sformatf("%s%0d", (i == 0) ? "" : ",", a[i])};
    return s;
  endfunction
  function automatic string la(input longint a [NM], input int n);
    string s; s = "";
    for (int i = 0; i < n; i++) s = {s, $sformatf("%s%0d", (i == 0) ? "" : ",", a[i])};
    return s;
  endfunction
  function automatic string iat(input int a [NT]);
    string s; s = "";
    for (int i = 0; i < NT; i++) s = {s, $sformatf("%s%0d", (i == 0) ? "" : ",", a[i])};
    return s;
  endfunction
  function automatic string lat_(input longint a [NT]);
    string s; s = "";
    for (int i = 0; i < NT; i++) s = {s, $sformatf("%s%0d", (i == 0) ? "" : ",", a[i])};
    return s;
  endfunction
  function automatic string ia3(input int a [3]);
    return $sformatf("%0d,%0d,%0d", a[0], a[1], a[2]);
  endfunction
  function automatic string pstr(input logic [255:0] v, input int n);
    string s; s = "";
    for (int i = 0; i < n; i++) s = {s, $sformatf("%s%0d", (i == 0) ? "" : ",", v[i*4 +: 4])};
    return s;
  endfunction
  function automatic string mstr();
    string s; s = "";
    for (int i = 0; i < NM; i++) s = {s, $sformatf("%s%0d", (i == 0) ? "" : ",", MMAXO[i*8 +: 8])};
    return s;
  endfunction

  function automatic string treq_str();
    string s;
    s = "";
    for (int t = 0; t < NT; t++) s = {s, $sformatf("%s%0d", (t == 0) ? "" : ",", t_nreq[t])};
    return s;
  endfunction

  function automatic string swst_str();
    string s;
    s = "";
    for (int m = 0; m < NM; m++) s = {s, $sformatf("%s%0d", (m == 0) ? "" : ",", sw_stall[m])};
    return s;
  endfunction

  function automatic string wmax_str();
    string s;
    s = "";
    for (int m = 0; m < NM; m++) s = {s, $sformatf("%s%0d", (m == 0) ? "" : ",", wmax[m])};
    return s;
  endfunction

  // completion detector
  initial begin
    @(posedge rst_n);
    forever begin
      @(posedge clk);
      if (rst_n && n_resets_done >= c_resets && (&m_done)) begin
        int busy;
        busy = 0;
        for (int m = 0; m < NM; m++) if (sb_out[m] != 0) busy = 1;
        for (int t = 0; t < NT; t++) if (t_pend[t] != 0 || t_rsp_valid[t]) busy = 1;
        if (busy == 0) begin
          // targets inject spurious responses whenever idle: stop that, then let every link drain
          // (with link stages an injected response accepted by the fabric is still in flight for a
          // few cycles before it is contained), so that the end-of-test totals compare like with like
          quiesce = 1'b1;
          repeat (20) @(posedge clk);
          for (int w = 0; w < 4000; w++) begin
            if (!(|t_rsp_valid) && !(|obs_mq_occ) && !(|obs_mr_occ) && !(|obs_tq_occ) && !(|obs_tr_occ)) break;
            @(posedge clk);
          end
          repeat (4) @(posedge clk);
          finish_run();
        end
      end
    end
  end
endmodule

`default_nettype wire
