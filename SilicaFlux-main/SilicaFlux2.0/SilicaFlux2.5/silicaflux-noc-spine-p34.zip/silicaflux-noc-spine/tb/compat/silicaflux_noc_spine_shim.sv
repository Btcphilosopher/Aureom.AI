// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: compatibility shim (verification only)
//
// Presents silicaflux_noc_spine under P22's module name and parameter list, so that P22's
// testbench tb/tb_noc.sv (vendored UNMODIFIED in third_party/) runs against the spine
// without a single change.  Compiled INSTEAD of P22's silicaflux_noc.sv (scripts/regress.py
// compat).  Mapping: TOPOLOGY must be 1 (crossbar = one central routing stage), every link
// has `SPINE_PIPE stages (default 0: the spine must then be cycle-identical to P22, which
// scripts/regress.py checks by comparing transaction traces), TC_MODE 0 (P22's testbench
// checks that the master's QoS reaches the target), CENTRAL = `SPINE_CENTRAL (default 1).
// =============================================================================
`default_nettype none
`ifndef SPINE_PIPE
`define SPINE_PIPE 0
`endif
`ifndef SPINE_CENTRAL
`define SPINE_CENTRAL 1
`endif

module silicaflux_noc #(
  parameter int               TOPOLOGY    = 1,
  parameter int               NM          = 4,
  parameter int               NT          = 4,
  parameter int               AW          = 32,
  parameter int               DW          = 32,
  parameter int               IDW         = 2,
  parameter int               ARB_MODE    = 1,
  parameter int               STARVE      = 8,
  parameter int               CHECK_ALIGN = 1,
  parameter int               RETIRE_BYPASS = 0,
  parameter logic [NT*AW-1:0] TGT_BASE    = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK    = {(NT*AW){1'b0}},
  parameter logic [NM*NT-1:0] MST_TGT_EN  = {(NM*NT){1'b1}},
  parameter int               MAXO_MAX    = 4,
  parameter logic [NM*8-1:0]  MST_MAXO    = {NM{8'd4}},
  parameter int               MESH_X      = 2,
  parameter int               MESH_Y      = 2,
  parameter logic [NM*8-1:0]  MST_NODE    = {NM{8'd0}},
  parameter logic [NT*8-1:0]  TGT_NODE    = {NT{8'd0}},
  parameter int               FIFO_DEPTH  = 4,
  parameter int               PERF        = 1,
  localparam int              SB          = DW / 8,
  localparam int              SRCW        = sfn_pkg::clog2c(NM),
  localparam int              QW          = sfn_pkg::QOSW,
  localparam int              CW          = sfn_pkg::clog2c(MAXO_MAX + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [NM-1:0]      m_req_valid,
  output logic      [NM-1:0]      m_req_ready,
  input  wire logic [NM*3-1:0]    m_req_opcode,
  input  wire logic [NM*IDW-1:0]  m_req_id,
  input  wire logic [NM*QW-1:0]   m_req_qos,
  input  wire logic [NM*AW-1:0]   m_req_addr,
  input  wire logic [NM*DW-1:0]   m_req_wdata,
  input  wire logic [NM*SB-1:0]   m_req_wstrb,
  output logic      [NM-1:0]      m_rsp_valid,
  input  wire logic [NM-1:0]      m_rsp_ready,
  output logic      [NM*IDW-1:0]  m_rsp_id,
  output logic      [NM*3-1:0]    m_rsp_opcode,
  output logic      [NM*2-1:0]    m_rsp_status,
  output logic      [NM*DW-1:0]   m_rsp_rdata,
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  input  wire logic               rb_sel,
  input  wire logic               rb_we,
  input  wire logic [11:0]        rb_addr,
  input  wire logic [31:0]        rb_wdata,
  output logic      [31:0]        rb_rdata,
  output logic                    rb_err,
  output logic                    irq_err,
  output logic      [NM-1:0]      obs_sw_valid,
  output logic      [NM-1:0]      obs_sw_ready,
  output logic      [NM*CW-1:0]   obs_out_cnt,
  output logic      [NM-1:0]      obs_decerr,
  output logic      [NM-1:0]      obs_posted_err,
  output logic      [NM-1:0]      obs_orphan,
  output logic      [NT-1:0]      obs_bad_src
);
  localparam int TW   = sfn_pkg::clog2c(NT + 1);
  localparam int OCCW = sfs_pkg::clog2c(sfs_pkg::MAX_STAGES * sfs_pkg::MAX_BUF + 1);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]      u_cv, u_cr, u_cl, u_crv, u_crr;
  logic [NM*TW-1:0]   u_ct;
  logic [NM*2-1:0]    u_ctc;
  logic [NM*OCCW-1:0] u_mq, u_mr;
  logic [NT*OCCW-1:0] u_tq, u_tr;
  logic [NT-1:0]      u_xv, u_xr;
  logic [31:0]        assert_errors;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_noc_spine #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE), .CHECK_ALIGN(CHECK_ALIGN),
    .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .MST_TGT_EN(MST_TGT_EN), .MAXO_MAX(MAXO_MAX), .MST_MAXO(MST_MAXO),
    .MST_CTRL({NM{1'b0}}), .TGT_MMIO({NT{1'b0}}), .TC_MODE(0), .BUF_DEPTH(2),
    .MST_PIPE({NM{4'(`SPINE_PIPE)}}), .TGT_PIPE({NT{4'(`SPINE_PIPE)}}), .PERF(PERF), .CENTRAL(`SPINE_CENTRAL)
  ) u_spine (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
    .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
    .rb_sel, .rb_sel_spine(1'b0), .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
    .obs_sw_valid, .obs_sw_ready, .obs_out_cnt, .obs_decerr, .obs_posted_err, .obs_orphan, .obs_bad_src,
    .obs_c_valid(u_cv), .obs_c_ready(u_cr), .obs_c_tgt(u_ct), .obs_c_tc(u_ctc), .obs_c_loss(u_cl),
    .obs_mq_occ(u_mq), .obs_mr_occ(u_mr), .obs_tq_occ(u_tq), .obs_tr_occ(u_tr), .obs_x_valid(u_xv), .obs_x_ready(u_xr),
    .obs_cr_valid(u_crv), .obs_cr_ready(u_crr), .assert_errors
  );
  // in-RTL assertion failures must fail P22's testbench too: they print "ASSERT ..." lines,
  // which scripts/regress.py treats as a failure; and the run stops here at the end
  final if (assert_errors != 0) $display("SPINE_ASSERT_ERRORS %0d", assert_errors);
`ifndef SYNTHESIS
  initial begin
    if (TOPOLOGY != 1)      $fatal(1, "spine shim: TOPOLOGY=%0d -- the spine is the crossbar topology", TOPOLOGY);
    if (RETIRE_BYPASS != 0) $fatal(1, "spine shim: RETIRE_BYPASS=1 is not offered by the spine (registered eligibility)");
  end
`endif
  // name-only scope for P22's mesh link monitor (tb_noc.sv: dut.g_mesh.u_core.*_out_v), which
  // is elaborated only for TOPOLOGY 2 -- never here (the shim refuses TOPOLOGY != 1)
  if (TOPOLOGY == 2) begin : g_mesh
    sfs_shim_mesh_stub #(.NL(MESH_X * MESH_Y * 5)) u_core ();
  end
  /* verilator lint_off UNUSEDPARAM */
  localparam int UNUSED_MESH = MESH_X + MESH_Y + FIFO_DEPTH + int'(|MST_NODE) + int'(|TGT_NODE);
  /* verilator lint_on UNUSEDPARAM */
endmodule

module sfs_shim_mesh_stub #(parameter int NL = 20) ();
  logic [NL-1:0] q_out_v = '0;
  logic [NL-1:0] s_out_v = '0;
endmodule

`default_nettype wire
