// =============================================================================
// SilicaFlux NoC Spine (Project 34) :: sfs_tb_master -- SFB3 traffic generator (verification only)
// DERIVED from P22 tb/sfn_tb_master.sv (vendored unmodified in third_party/).  Added:
//   +amode=6     DIE WORKLOAD: each master behaves as its floorplan role (PROFILE parameter,
//                from config/silicaflux_floorplan.yaml):
//                  0 cc_mmio     ControlCore: sparse acknowledged MMIO reads/writes to the die
//                                registers, ext-memory CSR, scratchpads and SRAM (one ID, in order)
//                  1 host        host I/O: sparse reads / writes / posted writes, any allowed target
//                  2 dma_write   DMA: read burst from a source (external memory or SRAM), posted-write
//                                burst to a destination (SRAM, scratchpad, external memory), FENCE,
//                                acknowledged completion-flag write -- the DataFabric DMA pattern
//                  3 vec_spm     vector cluster DMA: scratchpad fill (SRAM read bursts, own slice
//                                preferred) and drain (SRAM write bursts); occasional external memory
//                  4 tensor_load tensor operand loads: long sequential read bursts over the SRAM slices
//                                (slice rotates per burst, IDs rotate per beat), result write bursts
//                +burst=L sets the burst length of profiles 2-4 (default 32); +load=P scales every
//                profile's default request rate by P/1000 (low utilisation .. saturation);
//                +rate<m>= still overrides one master.
//   TCLASS       target classes (0 SRAM 1 SPM 2 REGS 3 EXT 4 EXTCSR) for the profile choices.
//
// One instance per master port.  Behaviour is chosen by plusargs (shared, with
// per-master overrides written <name><m>, e.g. +qos2=3 +rate0=50):
//   +n=N         transactions to issue (default 2000); +active<m>=0 silences a master
//   +rate=P      probability/1000 of presenting a new request in a free cycle
//   +p_rd +p_wr +p_post +p_fence +p_bad   opcode mix (/1000; remainder = read)
//   +p_err=P     probability/1000 of a deliberately bad address (unmapped,
//                misaligned or access-matrix denied)
//   +amode=M     0 uniform  1 hotspot (+hot=t, +p_hot)  2 bursts (+burst=L)
//                3 own-region read-after-write checking with FENCE phases
//                  (+nofence=1 removes the FENCEs: negative test)
//                4 permutation (target = (m + +shift) % NT)
//                5 all routes: write then read back, every target in turn
//   +ids=K       IDs used: 0..K-1 (default all)
//   +rbp=P       response back-pressure: rsp_ready low with probability P/1000
//   +qos<m>=Q    QoS class (default sfn_pkg::QOS_DMA)
// Self-checks (amode 3 and 5): every read returns the value predicted from
// this master's own writes, and responses of one ID return in issue order.
// =============================================================================
`default_nettype none

module sfs_tb_master #(
  parameter int               M           = 0,
  parameter int               NM          = 2,
  parameter int               NT          = 2,
  parameter int               AW          = 32,
  parameter int               DW          = 32,
  parameter int               IDW         = 2,
  parameter int               CHECK_ALIGN = 1,
  parameter logic [NT*AW-1:0] TBASE       = '0,
  parameter logic [NT-1:0]    EN          = '1,
  parameter logic [AW-1:0]    UNMAPPED    = '0,
  parameter int               PROFILE     = 1,
  parameter logic [NT*4-1:0]  TCLASS      = '0,
  localparam int              SB          = DW / 8,
  localparam int              NID         = 1 << IDW,
  localparam int              OFF         = $clog2(SB)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  output logic                req_valid,
  input  wire logic           req_ready,
  output logic [2:0]          req_opcode,
  output logic [IDW-1:0]      req_id,
  output logic [2:0]          req_qos,
  output logic [AW-1:0]       req_addr,
  output logic [DW-1:0]       req_wdata,
  output logic [SB-1:0]       req_wstrb,
  input  wire logic           rsp_valid,
  output logic                rsp_ready,
  input  wire logic [IDW-1:0] rsp_id,
  input  wire logic [2:0]     rsp_opcode,
  input  wire logic [1:0]     rsp_status,
  input  wire logic [DW-1:0]  rsp_rdata,
  output logic                done,           // issued all, every non-posted response received
  output int                  n_issued,
  output int                  n_check_err,    // self-check mismatches
  output int                  n_check_ok
);
`include "sfn_tb_common.svh"

  function automatic logic [DW-1:0] tb_mem_init(input int t, input int w);
    logic [DW-1:0] v;
    begin
      for (int k = 0; k < DW / 32; k++)
        v[k*32 +: 32] = seed_mix(32'(t * 4096 + w), 32'(k + 7));
      tb_mem_init = v;
    end
  endfunction

  // ---------------------------------------------------------------- configuration
  int c_n, c_rate, c_rd, c_wr, c_post, c_fence, c_bad, c_err, c_amode, c_hot, c_phot, c_burst;
  int c_nofence, c_shift, c_ids, c_rbp, c_qos, c_active;
  logic [31:0] rng;
  initial begin
    int s;
    s = 1;            void'($value$plusargs("seed=%d", s));
    rng = seed_mix(32'(s), 32'(M));
    c_n = 2000;       void'($value$plusargs("n=%d", c_n));
    c_rate = 600;     void'($value$plusargs("rate=%d", c_rate));
    if ($test$plusargs($sformatf("rate%0d=", M))) void'($value$plusargs($sformatf("rate%0d=%%d", M), c_rate));
    c_rd = 450;       void'($value$plusargs("p_rd=%d", c_rd));
    c_wr = 250;       void'($value$plusargs("p_wr=%d", c_wr));
    c_post = 200;     void'($value$plusargs("p_post=%d", c_post));
    c_fence = 30;     void'($value$plusargs("p_fence=%d", c_fence));
    c_bad = 0;        void'($value$plusargs("p_bad=%d", c_bad));
    c_err = 0;        void'($value$plusargs("p_err=%d", c_err));
    c_amode = 0;      void'($value$plusargs("amode=%d", c_amode));
    c_hot = 0;        void'($value$plusargs("hot=%d", c_hot));
    c_phot = 1000;    void'($value$plusargs("p_hot=%d", c_phot));
    c_burst = 16;     void'($value$plusargs("burst=%d", c_burst));
    c_nofence = 0;    void'($value$plusargs("nofence=%d", c_nofence));
    c_shift = 0;      void'($value$plusargs("shift=%d", c_shift));
    c_ids = NID;      void'($value$plusargs("ids=%d", c_ids));
    c_rbp = 0;        void'($value$plusargs("rbp=%d", c_rbp));
    if ($test$plusargs($sformatf("rbp%0d=", M))) void'($value$plusargs($sformatf("rbp%0d=%%d", M), c_rbp));
    c_qos = 0;        void'($value$plusargs($sformatf("qos%0d=%%d", M), c_qos));
    begin
      int qi;
      qi = 0; void'($value$plusargs("qos_idx=%d", qi));     // +qos_idx=1: QoS level = master index (mod 8)
      if (qi != 0) c_qos = M % 8;
    end
    c_burst = 16;     void'($value$plusargs("burst=%d", c_burst));
    if (c_amode == 6) begin
      int ld;
      if (!$test$plusargs("burst=")) c_burst = 32;
      case (PROFILE)
        0: c_rate = 40;
        1: c_rate = 25;
        2: c_rate = 1000;
        3: c_rate = 700;
        default: c_rate = 1000;
      endcase
      ld = 1000; void'($value$plusargs("load=%d", ld));
      c_rate = (c_rate * ld) / 1000;
      if (c_rate < 1) c_rate = 1;
      if (c_rate > 1000) c_rate = 1000;
      if ($test$plusargs($sformatf("rate%0d=", M))) void'($value$plusargs($sformatf("rate%0d=%%d", M), c_rate));
    end
    c_active = 1;     void'($value$plusargs($sformatf("active%0d=%%d", M), c_active));
    if ($test$plusargs($sformatf("n%0d=", M))) void'($value$plusargs($sformatf("n%0d=%%d", M), c_n));
    if (c_active == 0) c_n = 0;
    if (c_ids < 1 || c_ids > NID) c_ids = NID;
    if (c_burst < 1) c_burst = 1;
  end

  function automatic int rnd(input int n);
    begin
      rng = xs32(rng);
      rnd = (n <= 1) ? 0 : int'(rng % 32'(n));
    end
  endfunction

  // ---------------------------------------------------------------- own-region shadow (amode 3/5)
  localparam int RW = 16;                      // words per master per target
  logic [DW-1:0] shadow [NT][RW];
  initial for (int t = 0; t < NT; t++) for (int w = 0; w < RW; w++) shadow[t][w] = tb_mem_init(t, M * RW + w);

  // expected responses per ID (in issue order): {check, opcode, expected data}
  localparam int ED = 64;
  logic          e_chk  [NID][ED];
  logic [2:0]    e_op   [NID][ED];
  logic [DW-1:0] e_data [NID][ED];
  int            e_rd [NID], e_wr [NID];
  int            n_nonposted_out;

  // ---------------------------------------------------------------- generator state
  int  phase, phase_cnt, burst_left, burst_t, burst_w, route_k;
  logic [AW-1:0] tb_addr;

  function automatic logic [AW-1:0] taddr(input int t, input int w);
    begin
      taddr = TBASE[t*AW +: AW] + AW'(w << OFF);
    end
  endfunction

  // a target this master may reach (falls back to 0 if none)
  function automatic int pick_target();
    int t, n, i;
    begin
      n = 0;
      for (i = 0; i < NT; i++) if (EN[i]) n = n + 1;
      t = 0;
      if (n > 0) begin
        n = rnd(n);
        for (i = 0; i < NT; i++) if (EN[i]) begin
          if (n == 0) t = i;
          n = n - 1;
        end
      end
      pick_target = t;
    end
  endfunction

  // a reachable target of class c chosen with the random value r (falls back to any reachable
  // target).  No nested side-effect calls: Verilator 5.020 faults on a function that calls rnd().
  function automatic int pick_class(input int c, input int r);
    int n, t, i, k;
    begin
      n = 0;
      for (i = 0; i < NT; i++) if (EN[i] && 32'(TCLASS[i*4 +: 4]) == c) n = n + 1;
      t = 0;
      if (n == 0) begin
        for (i = 0; i < NT; i++) if (EN[i]) n = n + 1;
        k = (n > 0) ? (r % n) : 0;
        for (i = 0; i < NT; i++) if (EN[i]) begin
          if (k == 0) t = i;
          k = k - 1;
        end
      end else begin
        k = r % n;
        for (i = 0; i < NT; i++) if (EN[i] && 32'(TCLASS[i*4 +: 4]) == c) begin
          if (k == 0) t = i;
          k = k - 1;
        end
      end
      pick_class = t;
    end
  endfunction

  // the k-th reachable target of class c (wraps), -1 if none
  function automatic int nth_class(input int c, input int k);
    int n, i, t, kk;
    begin
      n = 0;
      for (i = 0; i < NT; i++) if (EN[i] && 32'(TCLASS[i*4 +: 4]) == c) n = n + 1;
      if (n == 0) nth_class = -1;
      else begin
        kk = k % n;
        t = -1;
        for (i = 0; i < NT; i++) if (EN[i] && 32'(TCLASS[i*4 +: 4]) == c) begin
          if (kk == 0 && t < 0) t = i;
          kk = kk - 1;
        end
        nth_class = t;
      end
    end
  endfunction

  // profile state (amode 6)
  int pf_left, pf_t, pf_w, pf_step, pf_seq, pf_id;
  logic [2:0] pf_op;

  task automatic gen_request();
    int r, t, w, kind;
    logic [2:0] op;
    logic [DW-1:0] d;
    logic [SB-1:0] s;
    begin
      d = '0;
      for (int k = 0; k < DW / 32; k++) begin
        rng = xs32(rng);
        d[k*32 +: 32] = rng;
      end
      rng = xs32(rng);
      s = SB'(rng);
      if (rnd(4) == 0) s = '1;
      if (s == '0) s[0] = 1'b1;
      req_qos  <= 3'(c_qos);
      t = 0; w = 0;
      // ------------------------------------------------ opcode
      r = rnd(1000);
      if      (r < c_bad)                             op = 3'(4 + rnd(4));
      else if (r < c_bad + c_fence)                   op = sfn_pkg::OP_FENCE;
      else if (r < c_bad + c_fence + c_post)          op = sfn_pkg::OP_WRITE_POSTED;
      else if (r < c_bad + c_fence + c_post + c_wr)   op = sfn_pkg::OP_WRITE;
      else                                            op = sfn_pkg::OP_READ;
      // ------------------------------------------------ address
      case (c_amode)
        1: begin
             t = (rnd(1000) < c_phot) ? (c_hot % NT) : rnd(NT);
             w = rnd(1024);
           end
        2: begin
             if (burst_left == 0) begin
               burst_left = c_burst;
               burst_t    = pick_target();
               burst_w    = rnd(1024);
             end
             t = burst_t;
             w = burst_w;
             burst_w    = (burst_w + 1) % 1024;
             burst_left = burst_left - 1;
           end
        4: begin
             t = (M + c_shift) % NT;
             w = rnd(1024);
           end
        default: begin
             t = rnd(NT);
             w = rnd(1024);
           end
      endcase
      tb_addr = taddr(t, w);
      // deliberate errors
      if (c_err > 0 && rnd(1000) < c_err) begin
        kind = rnd(3);
        if (kind == 0)                           tb_addr = UNMAPPED + AW'(rnd(256) << OFF);
        else if (kind == 1 && CHECK_ALIGN != 0)  tb_addr = tb_addr + AW'(1 + rnd(SB - 1));
        else                                     tb_addr = UNMAPPED + AW'(4096);
      end
      // ------------------------------------------------ own-region / route modes override
      if (c_amode == 3) begin
        // phases: 0 = writes, 1 = fence, 2 = reads, 3 = fence
        t = pick_target();
        w = rnd(RW);
        tb_addr = taddr(t, M * RW + w);
        case (phase)
          // same word -> same ID: writes to one word stay ordered even at out-of-order targets
          0: begin
               op = (rnd(2) == 0) ? sfn_pkg::OP_WRITE : sfn_pkg::OP_WRITE_POSTED;
               req_id_next = IDW'((t * RW + w) % c_ids);
             end
          2: op = sfn_pkg::OP_READ;
          default: op = sfn_pkg::OP_FENCE;
        endcase
        if (op == sfn_pkg::OP_WRITE || op == sfn_pkg::OP_WRITE_POSTED)
          for (int b = 0; b < SB; b++) if (s[b]) shadow[t][w][b*8 +: 8] = d[b*8 +: 8];
        if (op == sfn_pkg::OP_READ) d = shadow[t][w];
        phase_cnt = phase_cnt + 1;
        if ((phase == 0 || phase == 2) && phase_cnt >= 8) begin
          phase = (c_nofence != 0) ? ((phase + 2) % 4) : (phase + 1);
          phase_cnt = 0;
        end else if (phase == 1 || phase == 3) begin
          phase = (phase + 1) % 4;
          phase_cnt = 0;
        end
      end else if (c_amode == 5) begin
        // k = 2*t + {0: write, 1: read back}; one ID => in order
        t = (route_k / 2) % NT;
        w = rnd(RW);
        tb_addr = taddr(t, M * RW + w);
        if ((route_k % 2) == 0) begin
          op = sfn_pkg::OP_WRITE;
          burst_w = w;
          for (int b = 0; b < SB; b++) if (s[b]) shadow[t][w][b*8 +: 8] = d[b*8 +: 8];
        end else begin
          op = sfn_pkg::OP_READ;
          tb_addr = taddr(t, M * RW + burst_w);
          d = shadow[t][burst_w];
        end
        route_k = route_k + 1;
      end
      else if (c_amode == 6) begin
        // ---------------------------------------------- die workload profiles
        int r6, k;
        r6 = rnd(1000);
        case (PROFILE)
          0: begin   // cc_mmio: one ID, acknowledged accesses, mostly registers
               if      (r6 < 350) t = pick_class(2, rnd(1 << 20));
               else if (r6 < 500) t = pick_class(4, rnd(1 << 20));
               else if (r6 < 750) t = pick_class(1, rnd(1 << 20));
               else               t = pick_class(0, rnd(1 << 20));
               op = (rnd(10) < 6) ? sfn_pkg::OP_READ : sfn_pkg::OP_WRITE;
               w  = rnd(1024);
               req_id_next = '0;
             end
          1: begin   // host: any reachable target, mixed opcodes
               t  = pick_target();
               w  = rnd(1024);
               if      (r6 < 500) op = sfn_pkg::OP_READ;
               else if (r6 < 800) op = sfn_pkg::OP_WRITE;
               else               op = sfn_pkg::OP_WRITE_POSTED;
               req_id_next = '0;
             end
          2: begin   // dma_write: read burst -> posted-write burst -> FENCE -> flag write
               if (pf_left == 0) begin
                 pf_step = (pf_step + 1) % 4;
                 pf_w    = rnd(1024 - c_burst);
                 if (pf_step == 0) begin            // source read burst
                   pf_op = sfn_pkg::OP_READ; pf_left = c_burst;
                   pf_t  = (rnd(2) == 0) ? pick_class(3, rnd(1 << 20)) : pick_class(0, rnd(1 << 20));
                 end else if (pf_step == 1) begin   // destination posted-write burst
                   pf_op = sfn_pkg::OP_WRITE_POSTED; pf_left = c_burst;
                   k = rnd(100);
                   pf_t  = (k < 60) ? pick_class(0, rnd(1 << 20)) : ((k < 80) ? pick_class(1, rnd(1 << 20)) : pick_class(3, rnd(1 << 20)));
                 end else if (pf_step == 2) begin   // make the data visible
                   pf_op = sfn_pkg::OP_FENCE; pf_left = 1;
                 end else begin                     // completion flag (acknowledged)
                   pf_op = sfn_pkg::OP_WRITE; pf_left = 1;
                   pf_t  = nth_class(0, 0);
                   if (pf_t < 0) pf_t = pick_target();
                   pf_w  = 1008 + (M % 16);
                 end
               end
               op = pf_op; t = pf_t; w = pf_w % 1024;
               pf_w = pf_w + 1;
               pf_left = pf_left - 1;
               req_id_next = IDW'(pf_seq % c_ids);
               pf_seq = pf_seq + 1;
             end
          3: begin   // vec_spm: fill (read) / drain (write) bursts, own SRAM slice preferred
               if (pf_left == 0) begin
                 pf_left = (c_burst > 16) ? 16 : c_burst;
                 pf_w    = rnd(1024 - pf_left);
                 k = rnd(100);
                 if (k < 5) pf_t = pick_class(3, rnd(1 << 20));
                 else if (k < 75) begin
                   pf_t = nth_class(0, M);
                   if (pf_t < 0) pf_t = pick_target();
                 end else pf_t = pick_class(0, rnd(1 << 20));
                 pf_op = (rnd(10) < 6) ? sfn_pkg::OP_READ : ((rnd(2) == 0) ? sfn_pkg::OP_WRITE : sfn_pkg::OP_WRITE_POSTED);
               end
               op = pf_op; t = pf_t; w = pf_w % 1024;
               pf_w = pf_w + 1;
               pf_left = pf_left - 1;
               req_id_next = IDW'(pf_seq % c_ids);
               pf_seq = pf_seq + 1;
             end
          default: begin   // tensor_load: operand read bursts rotating over the SRAM slices, result writes
               if (pf_left == 0) begin
                 pf_step = pf_step + 1;
                 pf_left = c_burst;
                 pf_w    = rnd(1024 - c_burst);
                 pf_t    = nth_class(0, pf_step + M);
                 if (pf_t < 0) pf_t = pick_target();
                 pf_op   = ((pf_step % 8) == 7) ? sfn_pkg::OP_WRITE_POSTED : sfn_pkg::OP_READ;
               end
               op = pf_op; t = pf_t; w = pf_w % 1024;
               pf_w = pf_w + 1;
               pf_left = pf_left - 1;
               req_id_next = IDW'(pf_seq % c_ids);
               pf_seq = pf_seq + 1;
             end
        endcase
        tb_addr = taddr(t, w);
        if (c_err > 0 && rnd(1000) < c_err) tb_addr = UNMAPPED + AW'(rnd(256) << OFF);
      end
      req_opcode <= op;
      req_addr   <= tb_addr;
      req_wdata  <= (op == sfn_pkg::OP_READ) ? '0 : d;
      req_wstrb  <= (op == sfn_pkg::OP_READ) ? '0 : s;
      // expectation for the self-checking modes (issue order per ID)
      if (op != sfn_pkg::OP_WRITE_POSTED) begin
        int id;
        id = (c_amode == 5) ? 0 : int'(req_id_next);
        e_chk[id][e_wr[id] % ED]  = (c_amode == 3 || c_amode == 5) && (op == sfn_pkg::OP_READ) && EN[t];
        e_op[id][e_wr[id] % ED]   = op;
        e_data[id][e_wr[id] % ED] = d;
      end
    end
  endtask

  // the ID chosen for the request being generated (req_id is assigned with <=)
  logic [IDW-1:0] req_id_next;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      req_valid  <= 1'b0;
      req_opcode <= '0;
      req_id     <= '0;
      req_qos    <= '0;
      req_addr   <= '0;
      req_wdata  <= '0;
      req_wstrb  <= '0;
      rsp_ready  <= 1'b0;
      phase = 0; phase_cnt = 0; burst_left = 0; route_k = 0;
      pf_left = 0; pf_t = 0; pf_w = 0; pf_step = -1; pf_seq = 0; pf_id = 0; pf_op = '0;
      n_nonposted_out = 0;
      for (int i = 0; i < NID; i++) begin e_rd[i] = 0; e_wr[i] = 0; end
    end else begin
      // ------------------------------------------------ responses (self-check + ordering)
      if (rsp_valid && rsp_ready) begin
        int id;
        id = int'(rsp_id);
        if (e_rd[id] == e_wr[id]) begin
          $error("master%0d: response for ID %0d with nothing expected", M, id);
          n_check_err <= n_check_err + 1;
        end else begin
          if (e_op[id][e_rd[id] % ED] != rsp_opcode) begin
            $error("master%0d: ID %0d response opcode %0d, expected %0d (order)", M, id, rsp_opcode,
                   e_op[id][e_rd[id] % ED]);
            n_check_err <= n_check_err + 1;
          end else if (e_chk[id][e_rd[id] % ED]) begin
            if (rsp_status != sfn_pkg::ST_OKAY || rsp_rdata != e_data[id][e_rd[id] % ED]) begin
              $error("master%0d: read-after-write mismatch ID %0d: got %h st %0d, expected %h", M, id, rsp_rdata,
                     rsp_status, e_data[id][e_rd[id] % ED]);
              n_check_err <= n_check_err + 1;
            end else n_check_ok <= n_check_ok + 1;
          end
          e_rd[id] = e_rd[id] + 1;
          n_nonposted_out = n_nonposted_out - 1;
        end
      end
      rsp_ready <= (rnd(1000) >= c_rbp);
      // ------------------------------------------------ requests
      if (req_valid && req_ready) begin
        n_issued <= n_issued + 1;
        if (req_opcode != sfn_pkg::OP_WRITE_POSTED) begin
          int id;
          id = int'(req_id);
          e_wr[id] = e_wr[id] + 1;
          n_nonposted_out = n_nonposted_out + 1;
          if (e_wr[id] - e_rd[id] > ED) $fatal(1, "master%0d: expectation ring overflow", M);
        end
      end
      if (!req_valid || req_ready) begin
        if ((n_issued + ((req_valid && req_ready) ? 1 : 0)) < c_n && rnd(1000) < c_rate) begin
          req_id_next = IDW'(rnd(c_ids));
          gen_request();
          req_id    <= (c_amode == 5) ? '0 : req_id_next;
          req_valid <= 1'b1;
        end else begin
          req_valid <= 1'b0;
        end
      end
    end
  end

  initial begin n_check_err = 0; n_check_ok = 0; n_issued = 0; end   // kept across mid-test resets
  assign done = (n_issued >= c_n) && !req_valid && (n_nonposted_out == 0);
endmodule

`default_nettype wire
