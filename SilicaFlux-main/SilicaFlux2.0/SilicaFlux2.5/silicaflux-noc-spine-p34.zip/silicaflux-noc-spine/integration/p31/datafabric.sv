// =============================================================================
// SilicaFlux DieTop :: datafabric -- central on-die fabric
// >>> Project 34 drop-in: the crossbar topology (TOPOLOGY 1, used by SILICAFLUX_HPC, V2 and MINEXT)
// >>> is now silicaflux_noc_spine -- the same SFB3 ports, traffic classes on, link register stages from
// >>> the placement evidence for the HPC port set (sfs_cfg_pkg::*_PIPE_EVIDENCE) and one stage per link
// >>> for other port counts.  TOPOLOGY 0 (shared bus) and 2 (mesh) keep P22's silicaflux_noc.
// >>> Only this file differs from P31 (integration/p31/datafabric_p31_original.sv is the original).
//
//   NM SFB2 masters ─► sfn_sfb2_mst_bridge ─┐                 ┌─► sfn_sfb2_tgt_bridge ─► NT SFB2 targets
//                                           ├─ silicaflux_noc ─┤
//                                           │  (DataFabric-NoC, UNMODIFIED)
//                                           │  TOPOLOGY 0 shared bus (MIN), 1 crossbar (HPC), 2 mesh
//   rb page NOC_PERF ─► sfn_perf (counters, first decode error)
//
// Generic: the die top supplies the target windows, access matrix, per-master
// outstanding limits / traffic classes and per-target bridge depths, all derived
// from config/silicaflux_die.yaml through silicaflux_config_pkg.  No protocol is
// connected to an SFB2 port except through the NoC's own SFB2 bridges.
// Decode errors (unmapped address or access-matrix refusal) are answered by the
// NoC with DECERR (rsp_error = 1) and reported here with the master index and
// the exact request address (captured on the acceptance cycle).
// Classification: SYNTHESIZABLE (new wrapper, Project 31)
// =============================================================================
`default_nettype none

module datafabric #(
  parameter int                 TOPOLOGY   = 1,
  parameter int                 NM         = 4,
  parameter int                 NT         = 4,
  parameter logic [NT*32-1:0]   TGT_BASE   = {(NT*32){1'b0}},
  parameter logic [NT*32-1:0]   TGT_MASK   = {(NT*32){1'b0}},
  parameter logic [NM*NT-1:0]   MST_TGT_EN = {(NM*NT){1'b1}},
  parameter logic [NM*8-1:0]    MST_MAXO   = {NM{8'd1}},
  parameter logic [NM*3-1:0]    MST_QOS    = {NM{3'd0}},
  parameter logic [NT*8-1:0]    TGT_DEPTH  = {NT{8'd1}},
  parameter int                 MAXO_MAX   = 4,
  localparam int                IDW        = 1,
  localparam int                SRCW       = (NM > 1) ? $clog2(NM) : 1,
  localparam int                MW         = (NM > 1) ? $clog2(NM) : 1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // SFB2 masters
  input  wire logic [NM-1:0]    m_req_valid,
  output logic [NM-1:0]         m_req_ready,
  input  wire logic [NM-1:0]    m_req_write,
  input  wire logic [NM*32-1:0] m_req_addr,
  input  wire logic [NM*32-1:0] m_req_wdata,
  input  wire logic [NM*4-1:0]  m_req_wstrb,
  output logic [NM-1:0]         m_rsp_valid,
  input  wire logic [NM-1:0]    m_rsp_ready,
  output logic [NM*32-1:0]      m_rsp_rdata,
  output logic [NM-1:0]         m_rsp_error,
  // SFB2 targets
  output logic [NT-1:0]         t_req_valid,
  input  wire logic [NT-1:0]    t_req_ready,
  output logic [NT-1:0]         t_req_write,
  output logic [NT*32-1:0]      t_req_addr,
  output logic [NT*32-1:0]      t_req_wdata,
  output logic [NT*4-1:0]       t_req_wstrb,
  input  wire logic [NT-1:0]    t_rsp_valid,
  output logic [NT-1:0]         t_rsp_ready,
  input  wire logic [NT*32-1:0] t_rsp_rdata,
  input  wire logic [NT-1:0]    t_rsp_error,
  // NOC_PERF register page
  input  wire logic             rb_sel,
  input  wire logic             rb_we,
  input  wire logic [11:0]      rb_addr,
  input  wire logic [31:0]      rb_wdata,
  output logic [31:0]           rb_rdata,
  output logic                  rb_err,
  // events
  output logic                  irq_err,
  output logic                  dec_err_evt,     // a request was answered with DECERR
  output logic [MW-1:0]         dec_err_master,
  output logic [31:0]           dec_err_addr,
  output logic [NM-1:0]         req_accept,      // per-master acceptance (telemetry)
  output logic                  busy             // any master has a request presented
);
  // ---------------------------------------------------------------- SFB2 -> SFB3 master bridges
  logic [NM-1:0]     n_req_valid, n_req_ready, n_rsp_valid, n_rsp_ready;
  logic [NM*3-1:0]   n_req_opcode, n_req_qos, n_rsp_opcode;
  logic [NM*IDW-1:0] n_req_id, n_rsp_id;
  logic [NM*32-1:0]  n_req_addr, n_req_wdata, n_rsp_rdata;
  logic [NM*4-1:0]   n_req_wstrb;
  logic [NM*2-1:0]   n_rsp_status;
  for (genvar gm = 0; gm < NM; gm++) begin : g_mb
    sfn_sfb2_mst_bridge #(.AW(32), .DW(32), .IDW(IDW), .ID(1'b0), .QOS(MST_QOS[gm*3 +: 3])) u_mb (
      .s_req_valid(m_req_valid[gm]), .s_req_ready(m_req_ready[gm]), .s_req_write(m_req_write[gm]),
      .s_req_addr(m_req_addr[gm*32 +: 32]), .s_req_wdata(m_req_wdata[gm*32 +: 32]), .s_req_wstrb(m_req_wstrb[gm*4 +: 4]),
      .s_rsp_valid(m_rsp_valid[gm]), .s_rsp_ready(m_rsp_ready[gm]), .s_rsp_rdata(m_rsp_rdata[gm*32 +: 32]),
      .s_rsp_error(m_rsp_error[gm]),
      .m_req_valid(n_req_valid[gm]), .m_req_ready(n_req_ready[gm]), .m_req_opcode(n_req_opcode[gm*3 +: 3]),
      .m_req_id(n_req_id[gm*IDW +: IDW]), .m_req_qos(n_req_qos[gm*3 +: 3]), .m_req_addr(n_req_addr[gm*32 +: 32]),
      .m_req_wdata(n_req_wdata[gm*32 +: 32]), .m_req_wstrb(n_req_wstrb[gm*4 +: 4]),
      .m_rsp_valid(n_rsp_valid[gm]), .m_rsp_ready(n_rsp_ready[gm]), .m_rsp_id(n_rsp_id[gm*IDW +: IDW]),
      .m_rsp_opcode(n_rsp_opcode[gm*3 +: 3]), .m_rsp_status(n_rsp_status[gm*2 +: 2]),
      .m_rsp_rdata(n_rsp_rdata[gm*32 +: 32]));
  end

  // ---------------------------------------------------------------- the NoC
  // mesh placement (TOPOLOGY 2 only).  The mesh hosts at most ONE master and ONE target per node
  // (sfn_mesh rule), so the mesh is sized from the port counts: nodes >= max(NM, NT), MESH_X =
  // ceil(sqrt(nodes)), MESH_Y = ceil(nodes / MESH_X).  Master m on node m; target t on node
  // NN-1-t (the two populations start from opposite corners to spread traffic).
  localparam int MNODES = (NM > NT) ? NM : NT;
  function automatic int f_mesh_x();
    f_mesh_x = 0;
    for (int x = 1; x <= 64; x++) if (f_mesh_x == 0 && x * x >= MNODES) f_mesh_x = x;
  endfunction
  localparam int MESH_X = f_mesh_x();
  localparam int MESH_Y = (MNODES + MESH_X - 1) / MESH_X;
  localparam int NN     = MESH_X * MESH_Y;
  function automatic logic [NM*8-1:0] f_mst_node();
    for (int m = 0; m < NM; m++) f_mst_node[m*8 +: 8] = 8'(m);
  endfunction
  function automatic logic [NT*8-1:0] f_tgt_node();
    for (int t = 0; t < NT; t++) f_tgt_node[t*8 +: 8] = 8'(NN - 1 - t);
  endfunction
  localparam logic [NM*8-1:0] MST_NODE = f_mst_node();
  localparam logic [NT*8-1:0] TGT_NODE = f_tgt_node();

  logic [NT-1:0]      x_req_valid, x_req_ready, x_rsp_valid, x_rsp_ready;
  logic [NT*3-1:0]    x_req_opcode, x_req_qos, x_rsp_opcode;
  logic [NT*SRCW-1:0] x_req_src, x_rsp_src;
  logic [NT*IDW-1:0]  x_req_id, x_rsp_id;
  logic [NT*32-1:0]   x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [NT*4-1:0]    x_req_wstrb;
  logic [NT*2-1:0]    x_rsp_status;
  localparam int CW = $clog2(MAXO_MAX + 1);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]      sw_valid_u, sw_ready_u, pe_u, or_u;
  logic [NM*CW-1:0]   out_cnt_u;
  logic [NT-1:0]      bs_u;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NM-1:0]      decerr;
  // ---------------------------------------------------------------- Project 34 spine (crossbar topology)
  localparam bit HPC_PORTS = (NM == sfs_cfg_pkg::NM) && (NT == sfs_cfg_pkg::NT);
  function automatic logic [NM*4-1:0] f_mpipe();
    for (int m = 0; m < NM; m++) f_mpipe[m*4 +: 4] = HPC_PORTS ? sfs_cfg_pkg::MST_PIPE_EVIDENCE[m*4 +: 4] : 4'd1;
  endfunction
  function automatic logic [NT*4-1:0] f_tpipe();
    for (int t = 0; t < NT; t++) f_tpipe[t*4 +: 4] = HPC_PORTS ? sfs_cfg_pkg::TGT_PIPE_EVIDENCE[t*4 +: 4] : 4'd1;
  endfunction
  function automatic logic [NM-1:0] f_ctrl();
    for (int m = 0; m < NM; m++) f_ctrl[m] = (MST_QOS[m*3 +: 3] == sfn_pkg::QOS_CTRL);
  endfunction
  function automatic logic [NT-1:0] f_mmio();      // register windows: DIE_REGS and EXTMEM_CSR (0x3E.. / 0x3F..)
    for (int t = 0; t < NT; t++) f_mmio[t] = (TGT_BASE[t*32 +: 32] >= 32'h3E00_0000) && (TGT_BASE[t*32 +: 32] < 32'h4000_0000);
  endfunction
  if (TOPOLOGY == 1) begin : g_spine
    localparam int TW_ = (NT + 1 > 1) ? $clog2(NT + 1) : 1;
    localparam int OW_ = sfs_pkg::clog2c(sfs_pkg::MAX_STAGES * sfs_pkg::MAX_BUF + 1);
    /* verilator lint_off UNUSEDSIGNAL */
    logic [NM-1:0]     s_cv, s_cr, s_cl, s_crv, s_crr;
    logic [NM*TW_-1:0] s_ct;
    logic [NM*2-1:0]   s_ctc;
    logic [NM*OW_-1:0] s_mq, s_mr;
    logic [NT*OW_-1:0] s_tq, s_tr;
    logic [NT-1:0]     s_xv, s_xr;
    logic [31:0]       s_ae;
    /* verilator lint_on UNUSEDSIGNAL */
    silicaflux_noc_spine #(
      .NM(NM), .NT(NT), .AW(32), .DW(32), .IDW(IDW), .ARB_MODE(2), .STARVE(8), .CHECK_ALIGN(1),
      .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .MST_TGT_EN(MST_TGT_EN), .MAXO_MAX(MAXO_MAX), .MST_MAXO(MST_MAXO),
      .MST_CTRL(f_ctrl()), .TGT_MMIO(f_mmio()), .TC_MODE(1), .BUF_DEPTH(2), .MST_PIPE(f_mpipe()), .TGT_PIPE(f_tpipe()),
      .PERF(1), .CENTRAL(1)
    ) u_noc (
      .clk, .rst_n,
      .m_req_valid(n_req_valid), .m_req_ready(n_req_ready), .m_req_opcode(n_req_opcode), .m_req_id(n_req_id),
      .m_req_qos(n_req_qos), .m_req_addr(n_req_addr), .m_req_wdata(n_req_wdata), .m_req_wstrb(n_req_wstrb),
      .m_rsp_valid(n_rsp_valid), .m_rsp_ready(n_rsp_ready), .m_rsp_id(n_rsp_id), .m_rsp_opcode(n_rsp_opcode),
      .m_rsp_status(n_rsp_status), .m_rsp_rdata(n_rsp_rdata),
      .t_req_valid(x_req_valid), .t_req_ready(x_req_ready), .t_req_opcode(x_req_opcode), .t_req_src(x_req_src),
      .t_req_id(x_req_id), .t_req_qos(x_req_qos), .t_req_addr(x_req_addr), .t_req_wdata(x_req_wdata),
      .t_req_wstrb(x_req_wstrb), .t_rsp_valid(x_rsp_valid), .t_rsp_ready(x_rsp_ready), .t_rsp_src(x_rsp_src),
      .t_rsp_id(x_rsp_id), .t_rsp_opcode(x_rsp_opcode), .t_rsp_status(x_rsp_status), .t_rsp_rdata(x_rsp_rdata),
      .rb_sel, .rb_sel_spine(1'b0), .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
      .obs_sw_valid(sw_valid_u), .obs_sw_ready(sw_ready_u), .obs_out_cnt(out_cnt_u), .obs_decerr(decerr),
      .obs_posted_err(pe_u), .obs_orphan(or_u), .obs_bad_src(bs_u),
      .obs_c_valid(s_cv), .obs_c_ready(s_cr), .obs_c_tgt(s_ct), .obs_c_tc(s_ctc), .obs_c_loss(s_cl),
      .obs_mq_occ(s_mq), .obs_mr_occ(s_mr), .obs_tq_occ(s_tq), .obs_tr_occ(s_tr), .obs_x_valid(s_xv), .obs_x_ready(s_xr),
      .obs_cr_valid(s_crv), .obs_cr_ready(s_crr), .assert_errors(s_ae));

  end else begin : g_p22
    silicaflux_noc #(
      .TOPOLOGY(TOPOLOGY), .NM(NM), .NT(NT), .AW(32), .DW(32), .IDW(IDW), .ARB_MODE(1), .STARVE(8),
      .CHECK_ALIGN(1), .RETIRE_BYPASS(0), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .MST_TGT_EN(MST_TGT_EN),
      .MAXO_MAX(MAXO_MAX), .MST_MAXO(MST_MAXO), .MESH_X(MESH_X), .MESH_Y(MESH_Y), .MST_NODE(MST_NODE),
      .TGT_NODE(TGT_NODE), .FIFO_DEPTH(4), .PERF(1)
    ) u_noc (
      .clk, .rst_n,
      .m_req_valid(n_req_valid), .m_req_ready(n_req_ready), .m_req_opcode(n_req_opcode), .m_req_id(n_req_id),
      .m_req_qos(n_req_qos), .m_req_addr(n_req_addr), .m_req_wdata(n_req_wdata), .m_req_wstrb(n_req_wstrb),
      .m_rsp_valid(n_rsp_valid), .m_rsp_ready(n_rsp_ready), .m_rsp_id(n_rsp_id), .m_rsp_opcode(n_rsp_opcode),
      .m_rsp_status(n_rsp_status), .m_rsp_rdata(n_rsp_rdata),
      .t_req_valid(x_req_valid), .t_req_ready(x_req_ready), .t_req_opcode(x_req_opcode), .t_req_src(x_req_src),
      .t_req_id(x_req_id), .t_req_qos(x_req_qos), .t_req_addr(x_req_addr), .t_req_wdata(x_req_wdata),
      .t_req_wstrb(x_req_wstrb), .t_rsp_valid(x_rsp_valid), .t_rsp_ready(x_rsp_ready), .t_rsp_src(x_rsp_src),
      .t_rsp_id(x_rsp_id), .t_rsp_opcode(x_rsp_opcode), .t_rsp_status(x_rsp_status), .t_rsp_rdata(x_rsp_rdata),
      .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
      .obs_sw_valid(sw_valid_u), .obs_sw_ready(sw_ready_u), .obs_out_cnt(out_cnt_u), .obs_decerr(decerr),
      .obs_posted_err(pe_u), .obs_orphan(or_u), .obs_bad_src(bs_u));

  end

  // ---------------------------------------------------------------- SFB3 -> SFB2 target bridges
  for (genvar gt = 0; gt < NT; gt++) begin : g_tb
    sfn_sfb2_tgt_bridge #(.NM(NM), .AW(32), .DW(32), .IDW(IDW), .DEPTH(32'(TGT_DEPTH[gt*8 +: 8]))) u_tb (
      .clk, .rst_n,
      .t_req_valid(x_req_valid[gt]), .t_req_ready(x_req_ready[gt]), .t_req_opcode(x_req_opcode[gt*3 +: 3]),
      .t_req_src(x_req_src[gt*SRCW +: SRCW]), .t_req_id(x_req_id[gt*IDW +: IDW]), .t_req_qos(x_req_qos[gt*3 +: 3]),
      .t_req_addr(x_req_addr[gt*32 +: 32]), .t_req_wdata(x_req_wdata[gt*32 +: 32]), .t_req_wstrb(x_req_wstrb[gt*4 +: 4]),
      .t_rsp_valid(x_rsp_valid[gt]), .t_rsp_ready(x_rsp_ready[gt]), .t_rsp_src(x_rsp_src[gt*SRCW +: SRCW]),
      .t_rsp_id(x_rsp_id[gt*IDW +: IDW]), .t_rsp_opcode(x_rsp_opcode[gt*3 +: 3]),
      .t_rsp_status(x_rsp_status[gt*2 +: 2]), .t_rsp_rdata(x_rsp_rdata[gt*32 +: 32]),
      .s_req_valid(t_req_valid[gt]), .s_req_ready(t_req_ready[gt]), .s_req_write(t_req_write[gt]),
      .s_req_addr(t_req_addr[gt*32 +: 32]), .s_req_wdata(t_req_wdata[gt*32 +: 32]), .s_req_wstrb(t_req_wstrb[gt*4 +: 4]),
      .s_rsp_valid(t_rsp_valid[gt]), .s_rsp_ready(t_rsp_ready[gt]), .s_rsp_rdata(t_rsp_rdata[gt*32 +: 32]),
      .s_rsp_error(t_rsp_error[gt]));
  end

  // ---------------------------------------------------------------- decode-error report (lowest master first)
  always_comb begin
    dec_err_evt    = |decerr;
    dec_err_master = '0;
    dec_err_addr   = 32'd0;
    for (int m = NM - 1; m >= 0; m--) if (decerr[m]) begin
      dec_err_master = MW'(m);
      dec_err_addr   = m_req_addr[m*32 +: 32];
    end
  end
  assign req_accept = m_req_valid & m_req_ready;
  assign busy       = |m_req_valid;
endmodule

`default_nettype wire
