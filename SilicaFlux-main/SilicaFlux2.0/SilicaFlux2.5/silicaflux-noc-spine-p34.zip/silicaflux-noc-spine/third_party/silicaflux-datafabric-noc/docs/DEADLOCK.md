# Deadlock and liveness analysis

Scope: protocol deadlock (request/response dependency), routing deadlock (cyclic channel dependencies in the
mesh), buffer overflow / loss, and starvation. Each claim lists how it is verified; "proved" means an
unbounded ABC PDR proof (reports/formal.md), "simulated" means the self-checking testbench with its
deadlock watchdog (reports/regression_*.md).

## 1. Assumptions (the supported traffic)

| # | Assumption | Where it is stated |
|---|---|---|
| A1 | Masters drain responses: a master accepts every response within finite time, independent of its own requests (PROTOCOL.md M1). | protocol rule; every SilicaFlux master obeys it (SFB2 masters tie `rsp_ready` or accept unconditionally) |
| A2 | Targets eventually accept requests and eventually present a response for each accepted request (R5) once their own response can leave. | protocol rule |
| A3 | Target responses do not wait for other requests to be accepted by the fabric (a target's `rsp_valid` never depends on `req_ready`). | R4/R5 |
| A4 | Every request uses a mapped target or is answered locally; posted writes count as outstanding until completed. | fabric rule (decoder + O1) |

A slave that never responds (violating A2) blocks the transactions that depend on it: there is **no
watchdog/timeout** in the fabric (as in DataFabric; listed in docs/ISSUES.md).

## 2. Protocol (message-dependent) deadlock

The classic deadlock in request/response fabrics is a cycle *request channel → target → response channel →
master → request channel*: a target cannot accept requests because it cannot send responses, because the
master will not take responses until its request is accepted.

The dependency graph of SFB3 is acyclic:

```
 master request ──► fabric request path ──► target ──► fabric response path ──► master response sink
                                                                                   │
                                     (A1: the sink never waits on the request path) ┘ — no edge back
```

* **Crossbar / shared bus:** the response path is combinational from the target's `rsp_valid` to the master's
  `rsp_ready`; the only state is the per-master response arbiter (lock while the master stalls). By A1 every
  presented response is eventually accepted, so every target's response channel drains, so (A2) targets keep
  accepting requests. The master front end makes `fr_ready` depend only on `m_rsp_ready` (or consumes orphans and
  posted completions unconditionally) — never on the request side (proved property M4/M5 context; structural).
* **Mesh:** requests and responses travel on **two physically separate networks** — the response network has
  its own routers, links and buffers, so a response can never wait behind a request in any buffer. The master
  network interface's response FIFO drains into `sfn_mst_port`, whose response side never waits for its
  request side (A1 applies at the master port). Hence the response network always drains, targets keep
  accepting, and the request network drains.

The fabric-local responder (FENCE / decode errors) is a sink on the same response path (one entry, freed when
the master accepts the response) and adds no back edge.

## 3. Routing deadlock (mesh)

Within each network, packets use XY dimension-order routing. The channel-dependency graph (an edge from link
*a* to link *b* when a packet can hold *a* while waiting for *b*) is acyclic because a packet only waits for
links in increasing order of the (X-phase, then Y-phase) ordering:

* X phase: a packet travelling East waits only for East links further East (strictly increasing x), and the
  same for West; it may then turn into Y — never back into X (turn restriction, Dally & Seitz / turn model).
* Y phase: South links only further South, North links only further North; then Local.
* The Local output (ejection) is a sink by §2.

So within a network no cycle of waiting packets can form. The restriction "never turn from Y into X" is
checked every cycle in simulation (`obs_turn_err`) and proved for the router under XY-legal inputs (formal job
`router_d2/d3`, property W4); a mutant router routing Y before X is caught by both the formal non-vacuity job
`mut_router_yx` and the testbench (`rt_yx_routing`).

Wormhole switching keeps a packet's flits contiguous on every link (proved W1). A packet holds at most the
links of its path; with 1- and 2-flit packets and `FIFO_DEPTH ≥ 2`, a whole packet fits in one input FIFO.

## 4. No overflow, loss or duplication

| Hazard | Mechanism | Verification |
|---|---|---|
| router / NI buffer overflow | credits: `credits + downstream occupancy = FIFO_DEPTH` | proved (C1, C2, N1); simulation `$error` on any flit arriving at a full FIFO |
| flit loss / duplication inside a router | `flits in − flits out = flits buffered` | proved (W3) |
| message loss / reorder / corruption across a link | NI pair order + integrity | proved (N2) |
| transaction loss / duplication end to end | testbench conservation scoreboard (every master acceptance appears exactly once at its target, every response once at its master) | simulated, all topologies, all tests |
| target-side buffer overflow | target `req_ready` / bridge `DEPTH` | bridge FIFO proved (fifo_*_pass) |
| response misrouting | response carries `src, id`; master port accepts only a response matching an outstanding ID at that target | proved (M4/M5); simulated with 211,001 injected spurious responses, all contained (`spurious`, `spur_bad` tests) |

## 5. Starvation and fairness

| Arbiter | Guarantee | Verification |
|---|---|---|
| round robin (`ARB_RR`, DataFabric `sfb_arbiter`) | a waiting requester is accepted after ≤ N−1 other acceptances | proved in DataFabric (A4); re-checked here in simulation (fairness monitor, every crossbar/shared-bus test) |
| QoS + aging (`ARB_QOS`) | ≤ STARVE + N − 1 other acceptances, for any QoS pattern | proved (Q4, N=3..5, STARVE 0..4); simulated (`qos_levels`, `hotspot`) |
| fixed priority (`ARB_FIXED`) | **none** — lower ports can starve | documented; used only where the high-priority masters are rate-limited |
| mesh | each router output is round robin / QoS among its inputs (local bound as above); the end-to-end share is **not** equal (parking-lot effect: a master merging late gets a smaller share) | measured: Jain index in reports/bench.md |

Fairness is a bound on *waiting*, not a bandwidth share; priority is latency preference, not bandwidth
(docs/QOS.md).

## 6. Liveness tests (simulation)

Every testbench run has a watchdog: if no handshake happens anywhere for `+wd` cycles while any master has an
outstanding transaction or a pending request, the run fails with "DEADLOCK/LIVELOCK". The following stress the
dependency cycles:

| Test | What it stresses |
|---|---|
| `maxload` | every master at 100 % offered load, maximum outstanding, 4–16-cycle out-of-order targets with 30 % request back-pressure, masters refusing 60 % of responses — the response path is congested and back-pressures targets, which back-pressure requests |
| `hotspot` | all masters on one target (cyclic back-pressure into every master's request path) |
| `perm` | every master streams to a different target; in the mesh this loads the X and Y links of crossing paths simultaneously |
| `backpress` | 50 % request and 50 % response back-pressure on every port |
| `resets` | asynchronous reset while all of the above are in flight; traffic resumes cleanly |

All pass on every configuration of all three topologies (reports/regression_crossbar.md, _sbus.md, _mesh.md).
These are bounded simulations under the stated assumptions, **not** a liveness proof.
