# SFB3 — SilicaFlux Bus, revision 3 (DataFabric-NoC transaction interface)

SFB3 is the transaction interface of `silicaflux_noc`. It is the **additive extension of SFB2** that
DataFabric's PROTOCOL.md §8 planned ("add `req_id`/`rsp_id`, replace the per-port one-transaction rule by
counters, keep rev-2.0 components legal"). The shared package `rtl/noc/sfn_pkg.sv` holds every constant
quoted here; nothing in this document is defined anywhere else.

SFB2 endpoints connect **unmodified** through two bridges:

| Bridge | Direction | What it does |
|---|---|---|
| `sfn_sfb2_mst_bridge` | SFB2 master → SFB3 master port | `write → OP_WRITE / OP_READ`, constant ID (in-order responses), constant QoS class; `rsp_error = (status != OKAY)` |
| `sfn_sfb2_tgt_bridge` | SFB3 target port → SFB2 slave | tag FIFO `{src, id, opcode}` of `DEPTH` entries restores response tags from the in-order SFB2 slave; posted writes become normal writes whose response is the posted completion |

## 1. Signals

### 1.1 Master port (master → fabric, per master; flattened `NM×` in `silicaflux_noc`)

| Signal | Width | Dir | Meaning |
|---|---|---|---|
| `m_req_valid` | 1 | in | request valid |
| `m_req_ready` | 1 | out | request accepted this cycle |
| `m_req_opcode` | 3 (`OPW`) | in | `OP_READ`=0, `OP_WRITE`=1 (acknowledged), `OP_WRITE_POSTED`=2, `OP_FENCE`=3; 4..7 reserved → `ST_DECERR` |
| `m_req_id` | `IDW` (1..8, default 2) | in | transaction identifier |
| `m_req_qos` | 3 (`QOSW`) | in | traffic class / priority level (§6) |
| `m_req_addr` | `AW` (8..64, default 32) | in | byte address, DW-aligned |
| `m_req_wdata` | `DW` (32/64/128/256) | in | write data (don't care for reads) |
| `m_req_wstrb` | `DW/8` | in | byte enables (don't care for reads) |
| `m_rsp_valid` | 1 | out | response valid |
| `m_rsp_ready` | 1 | in | response accepted this cycle |
| `m_rsp_id` | `IDW` | out | ID of the transaction answered |
| `m_rsp_opcode` | 3 | out | opcode of the transaction answered (READ / WRITE / FENCE / the reserved opcode) — the **read/write status** of the response |
| `m_rsp_status` | 2 (`STW`) | out | `ST_OKAY`=0, `ST_SLVERR`=1 (target error), `ST_DECERR`=2 (fabric decode error); 3 reserved |
| `m_rsp_rdata` | `DW` | out | read data; 0 for writes, FENCE and every error |

The **source identifier is not a master signal**: the fabric stamps it from the port index on the target side,
so a master cannot spoof another master's identity.

### 1.2 Target port (fabric → target, per target)

| Signal | Width | Dir | Meaning |
|---|---|---|---|
| `t_req_valid` / `t_req_ready` | 1 / 1 | out / in | request handshake |
| `t_req_opcode` | 3 | out | only `OP_READ`, `OP_WRITE`, `OP_WRITE_POSTED` ever reach a target |
| `t_req_src` | `SRCW = clog2(NM)` (min 1) | out | **source identifier** (master index) |
| `t_req_id` | `IDW` | out | transaction identifier, unchanged |
| `t_req_qos` | 3 | out | traffic class (targets may use it for their own scheduling) |
| `t_req_addr`, `t_req_wdata`, `t_req_wstrb` | `AW`, `DW`, `DW/8` | out | unchanged from the master |
| `t_rsp_valid` / `t_rsp_ready` | 1 / 1 | in / out | response handshake |
| `t_rsp_src`, `t_rsp_id`, `t_rsp_opcode` | `SRCW`, `IDW`, 3 | in | echoed from the request: they route the response |
| `t_rsp_status`, `t_rsp_rdata` | 2, `DW` | in | completion status and read data |

Widths come from the parameters; **no field is ever narrowed** inside the fabric. In the mesh the flit
payload width is derived from the same parameters (`sfn_pkg::req_hdr_w`), so a 48-bit address, an 8-bit ID or
16 masters travel unchanged (verified: `xb_aw48`, `mesh_2x2_d64_aw48`, `xb_m8t8_id3`, `mesh_3x3_m8t8` in the
regression; the reference decoder of the testbench checks every target-side field against the master's).

## 2. Handshake rules

| # | Rule |
|---|---|
| R1 | A request transfers on a rising edge with `req_valid && req_ready`; a response with `rsp_valid && rsp_ready`. |
| R2 | A presented request stays valid with an unchanged payload until accepted (**no withdrawal**). The fabric keeps this rule on its own outputs: a request presented to a target is held (grant lock) until accepted. |
| R3 | `req_valid` must not depend combinationally on `req_ready`. `req_ready` may depend on `req_valid` and the payload. |
| R4 | `rsp_valid` must not depend on `rsp_ready`; a held response stays valid and unchanged. `rsp_ready` may depend on `rsp_valid` but **not on `req_ready`**. A target's `req_ready` may depend on its own `rsp_ready` (accept-while-retiring). |
| M1 | **Masters always drain responses.** A master must accept every response within finite time, whatever happens to its own requests (its `rsp_ready` may not wait for one of its requests to be accepted). This is the one assumption the deadlock argument needs (docs/DEADLOCK.md). |
| R5 | **Targets:** exactly one response per accepted request — a posted write included (its *completion*) — never in the acceptance cycle. Responses of one `(src, id)` pair leave in acceptance order; different pairs may be answered in any order (out-of-order targets are legal). |
| R11 | **Reset:** asynchronous assertion, synchronous release by the SoC synchroniser; masters, fabric and targets in one reset domain. Every transaction in flight is cancelled; no response is delivered for it; a write already accepted by a target may or may not have been performed. The fabric accepts nothing and presents nothing during reset **and in the first cycle after it** (registered `run_q` gate in every master port). |

Combinational paths through the crossbar: `m_req_* → t_req_*`, `t_req_ready → m_req_ready`, `t_rsp_* → m_rsp_*`,
`m_rsp_ready → t_rsp_ready`, and — only with `RETIRE_BYPASS = 1` — `m_rsp_ready, t_rsp_* → m_req_ready` (a slot
freed by a response retiring this cycle is reused in the same cycle, SFB2's accept-while-retiring). The default
`RETIRE_BYPASS = 0` keeps the request side on registered state (shorter paths, one bubble per back-to-back
transaction at a master's limit; docs/ARCHITECTURE.md §6). With R3/R4 none of these forms a loop. The mesh breaks every path at the network
interfaces (registered FIFOs and credit counters).

## 3. Opcodes, completion and errors

| Opcode | Reaches | Response to the master | Completion means |
|---|---|---|---|
| `OP_READ` | target | data + status | data read |
| `OP_WRITE` (acknowledged) | target | status, `rdata = 0` | **write performed** at the target (SFB2 R7) |
| `OP_WRITE_POSTED` | target | **none** | the target's completion returns to the fabric, which retires it (outstanding count, FENCE); a failing completion raises `ev_posted_err` and ERR_STATUS bit 1 |
| `OP_FENCE` | fabric (local) | `ST_OKAY`, 1 cycle after acceptance | every earlier transaction of this master has completed (O3) |
| 4..7 | fabric (local) | `ST_DECERR` | — |

Errors (`ST_DECERR` from the fabric, `ST_SLVERR` from targets) **never have a side effect**.

| Cause | Detected by | Response |
|---|---|---|
| unmapped address, access-matrix denial (`MST_TGT_EN`), misaligned address (`CHECK_ALIGN = 1`), reserved opcode | `sfn_mst_port` (DataFabric `sfb_addr_decoder`, unmodified) | `ST_DECERR` from the local responder; nothing reaches any target. A **posted** write that fails decode is accepted and dropped (no response exists to carry the error): `ev_decerr` + ERR_STATUS bit 1, first error captured in `ERR_INFO / ERR_ADDR` |
| target error | target | `ST_SLVERR`, `rdata = 0`, write not performed |
| response that matches no outstanding transaction (wrong ID, wrong target, illegal source) | `sfn_mst_port` (orphan), core (bad source) | consumed, **never delivered**, `ev_orphan` / `ev_bad_src`, ERR_STATUS bits 2/3 |

## 4. Outstanding transactions — explicit limits

| # | Limit |
|---|---|
| O1 | Each master has at most `MST_MAXO[m]` transactions outstanding (1..`MAXO_MAX`): issued, not yet retired. Posted writes count until their completion is retired. The limit is enforced by the fabric (`sfn_mst_port`), not trusted to the master. |
| O2 | **One target per outstanding ID.** A request of ID *i* to target *T* is held back while ID *i* is outstanding at another target (or at the local responder). Consequence: responses of one ID are returned in request order. |
| O3 | FENCE is accepted only when the master has nothing outstanding (with `RETIRE_BYPASS = 1`: or the last transaction retires in the same cycle). |
| O4 | Each target bounds what it accepts with `t_req_ready`; behind `sfn_sfb2_tgt_bridge` the bound is the bridge `DEPTH` (1 for SFB2 slaves designed for one transaction per port; the SRAM Wrapper Library adapters support `READ_LATENCY + 1`). |
| O5 (mesh) | Every router input and network-interface FIFO holds `FIFO_DEPTH` flits; credit-based flow control guarantees no flit is ever sent to a full buffer (proved, `formal/fv_sfn_router.sv`, `fv_sfn_ni.sv`). |

With `MST_MAXO = 1`, target `DEPTH = 1` and `RETIRE_BYPASS = 1` the fabric has exactly SFB2's limits: on the
real SilicaFlux endpoints it then reproduces DataFabric's cycle counts (reports/endpoints.md, `noc_xbar_sfb2eq`).

## 5. Ordering

| Relation | Guarantee |
|---|---|
| requests of one master to one target | delivered to the target in issue order (crossbar: same cycle; mesh: one deterministic XY path through FIFO links) |
| responses of one master, same ID | in request order (O2 + target rule R5) |
| responses of one master, different IDs | **no order**: they may return in any order (out-of-order targets, different targets) |
| a read after a write, same address, same ID | sees the write (same target, in order) |
| a read after a write, different IDs | **no guarantee** unless separated by FENCE (or the write was acknowledged before the read was issued) |
| across masters | no ordering, no coherence: SFB3 has no caches and introduces no coherence. Producers make data visible by completing writes (acknowledged write response, or FENCE after posted writes) before signalling the consumer. |

The negative test `nofence_neg` shows the rule is real: with out-of-order targets and FENCE removed, a
read-after-write check fails in every topology (and passes with FENCE, or with in-order targets).

**Posted vs acknowledged writes.** Use `OP_WRITE` when the master needs to know the write has been performed
(or failed). Use `OP_WRITE_POSTED` for streaming writes: no response traffic towards the master, no
response-buffer space at the master, errors reported through the error capture registers / interrupt, and a
FENCE when the data must be visible. Both kinds obey O1 (posted writes are outstanding until their target
completes them).

## 6. Traffic classes (QoS) — see docs/QOS.md

`req_qos` carries the class: `QOS_DMA` 0, `QOS_TENSOR` 1, `QOS_VECTOR` 2, `QOS_CTRL` 3, `QOS_EVENT` 4
(5..7 legal, unnamed). It is a **priority level**, used only when `ARB_MODE = ARB_QOS`; it never reserves
bandwidth.

## 7. Compatibility with SFB2

* SFB2 masters/slaves attach through the two bridges; the SilicaFlux tensor unit, HPC FP32 tile (with the
  DataFabric DMA engine inside), SRAM and scratchpad window run unmodified on the NoC (reports/endpoints.md).
* SFB2's R6 (one transaction per crossbar port) is replaced by O1–O4; setting `MST_MAXO = 1` and bridge
  `DEPTH = 1` restores it.
* Tool rules inherited from DataFabric (PROTOCOL.md §9): sized fill literals in parameters, no `int'()`
  casts, no variable declarations in unnamed blocks, package functions written as assignments to the
  function name — all three tools (Verilator 5.020, Icarus 12, Yosys 0.33) elaborate the same RTL.
