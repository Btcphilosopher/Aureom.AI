# Arbitration and QoS

## 1. Arbitration modes (`ARB_MODE`, one value for the whole fabric)

| Mode | Implementation | Guarantee | Use |
|---|---|---|---|
| `ARB_FIXED` (0) | DataFabric `sfb_arbiter`, unmodified (port 0 highest) | none: lower ports **can starve** under sustained contention | only with rate-limited high-priority ports (e.g. a debug port) |
| `ARB_RR` (1, default) | DataFabric `sfb_arbiter`, unmodified: pointer moves past the winner only on acceptance; grant lock while the target back-pressures | a waiting requester is accepted after **≤ N−1** other acceptances (DataFabric's unbounded proof; checked again by this project's fairness monitor in every crossbar/shared-bus simulation) | the baseline: deterministic and fair |
| `ARB_QOS` (2) | `sfn_qos_arbiter` (new) | **≤ STARVE + N − 1** other acceptances for any QoS pattern (unbounded proof, N = 3..5, STARVE = 0..4) | when latency-sensitive classes share targets with bulk traffic |

Where arbitration happens:

| Topology | Request arbitration | Response arbitration |
|---|---|---|
| crossbar | one arbiter per target port among the masters requesting it | one round-robin arbiter per master among the targets responding to it |
| shared bus | one arbiter for the whole bus | one round-robin arbiter for the whole response bus |
| mesh | one arbiter per router output among the input ports whose head flit wants it (request network: QoS from the head flit; response network: round robin) | — (responses are routed, not arbitrated, at the master) |

Inside each master front end a 2-way round-robin arbiter merges fabric responses with the local responder
(FENCE / decode errors).

## 2. `sfn_qos_arbiter`

Per requester: QoS level (the request's `qos`), an **age** counter of consecutive acceptances of *other*
requesters while it waits (saturating at `STARVE`). Selection:

1. grant lock (a granted request presented and not accepted is granted again — payload stability, R2);
2. requesters whose age reached `STARVE` are **urgent** and form the top level;
3. otherwise the highest QoS level present wins;
4. ties inside the winning level: round robin, pointer moved past the winner on acceptance.

Proved properties (reports/formal.md, `qos_arb_*`): one-hot grant only to requesters (Q1), work conserving
(Q2), lock (Q3), bounded waiting STARVE + N − 1 (Q4), urgent requesters win (Q5), without urgency the
highest QoS level wins (Q6). Non-vacuity: removing aging, the lock or the pointer update each produces a
counterexample.

## 3. Traffic classes

| `qos` | Name | Intended traffic | SilicaFlux endpoint (integration) |
|---|---|---|---|
| 4 | `QOS_EVENT` | error / status events (small posted writes to a mailbox / log) | — (class defined; exercised by the testbench) |
| 3 | `QOS_CTRL` | latency-sensitive ControlCore loads / stores / MMIO | host CPU port |
| 2 | `QOS_VECTOR` | vector-tile transfers | HPC FP32 tile DMA |
| 1 | `QOS_TENSOR` | TensorCore operand / result transfers | tensor unit DMA |
| 0 | `QOS_DMA` | bulk DMA copies | system DMA |

Levels 5–7 are legal and unnamed. The class travels with every request (and in every request head flit of
the mesh); targets see it on `t_req_qos`.

## 4. Priority is not bandwidth

* QoS arbitration **reorders who goes first**; it never reserves capacity. Under saturation a lower level gets
  what the higher levels leave, down to the aging floor of one acceptance per `STARVE + N − 1` acceptances at
  that arbiter. There is no rate limiter, token bucket or guaranteed-throughput reservation in this fabric.
* With `STARVE` small, aging dominates and the arbiter approaches round robin; with `STARVE` large, high
  levels get stronger latency preference and low levels a longer (but bounded) wait.
* Measured (reports/bench.md, QoS table): on the crossbar, a ControlCore-class master doing sparse reads into a
  target saturated by three bulk masters sees a lower mean / p99 access latency with `ARB_QOS` than with round
  robin, while the bulk masters' total bandwidth is unchanged — the latency moves to the bulk masters' tail.

## 5. QoS in the mesh — measured limitation

In the wormhole mesh, priority acts only when a router allocates an output to a **head flit**. Flits already
queued in the in-order input FIFOs ahead of a high-priority packet cannot be overtaken (no virtual channels).
Measured on the 2×2 mesh with the same hot-spot pattern: the ControlCore-class latency is the same with
`ARB_QOS` and round robin (reports/bench.md). Latency QoS in a mesh needs per-class virtual channels or
separate networks per class — not implemented (docs/ISSUES.md NOC-05).

## 6. Starvation where fairness is promised

Round robin and QoS promise bounded waiting at every arbiter, and both bounds are proved. The testbench
checks the bound in every crossbar and shared-bus run (`wait_max` in every RESULT line, failure if exceeded);
a mutant that freezes the QoS round-robin pointer is caught by simulation and formal. The mesh promises the
bound **per router output**, not end to end: a master whose packets merge late into a congested path gets a
smaller share (parking-lot effect), reported as the Jain index in reports/bench.md.
