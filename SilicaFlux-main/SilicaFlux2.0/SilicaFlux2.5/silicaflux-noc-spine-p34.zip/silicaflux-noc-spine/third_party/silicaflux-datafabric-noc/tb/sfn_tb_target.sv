// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_tb_target -- SFB3 target model (verification only)
//
// A 1024-word memory behind an SFB3 target port.  Behaviour (plusargs, shared
// by all targets, streams decorrelated by the target index):
//   +seed=S       RNG seed
//   +tbp=P        request back-pressure: t_req_ready low with probability P/1000
//   +lat_min=A +lat_max=B   latency, uniform in [A,B]: cycles from request acceptance to the
//                 earliest response handshake (A >= 1; 1 = single-cycle SRAM)
//   +ooo=1        out-of-order: any ready request may be answered first, except
//                 that responses of one (src,id) pair stay in acceptance order
//                 (the SFB3 target rule); default in order
//   +errwin=1     words 1008..1023 answer SLVERR (no side effect)
//   +spur=P       fault injection: when idle, with probability P/1000 send a
//                 spurious response for a (src,id) with nothing outstanding here
//   +spur_badsrc=1  spurious responses only with an out-of-range source
// Memory content is initialised to tb_mem_init(T, word) and NOT reset (SRAM).
// Writes take effect when their response is produced (before the response
// is visible: SFB3 R7).  QCAP bounds the requests held (explicit target limit).
// =============================================================================
`default_nettype none

module sfn_tb_target #(
  parameter int  T    = 0,
  parameter int  NM   = 2,
  parameter int  AW   = 32,
  parameter int  DW   = 32,
  parameter int  IDW  = 2,
  parameter int  QCAP = 8,
  localparam int SB   = DW / 8,
  localparam int SRCW = sfn_pkg::clog2c(NM),
  localparam int OFF  = $clog2(SB)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            t_req_valid,
  output logic                 t_req_ready,
  input  wire logic [2:0]      t_req_opcode,
  input  wire logic [SRCW-1:0] t_req_src,
  input  wire logic [IDW-1:0]  t_req_id,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [2:0]      t_req_qos,
  input  wire logic [AW-1:0]   t_req_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [DW-1:0]   t_req_wdata,
  input  wire logic [SB-1:0]   t_req_wstrb,
  output logic                 t_rsp_valid,
  input  wire logic            t_rsp_ready,
  output logic [SRCW-1:0]      t_rsp_src,
  output logic [IDW-1:0]       t_rsp_id,
  output logic [2:0]           t_rsp_opcode,
  output logic [1:0]           t_rsp_status,
  output logic [DW-1:0]        t_rsp_rdata,
  output logic                 rsp_spurious,    // the response now presented is an injected fault
  output int                   n_pending,
  output int                   n_spur_sent      // spurious responses accepted by the fabric
);
`include "sfn_tb_common.svh"

  function automatic logic [DW-1:0] tb_mem_init(input int t, input int w);
    logic [DW-1:0] v;
    begin
      for (int k = 0; k < DW / 32; k++)
        v[k*32 +: 32] = seed_mix(32'(t * 4096 + w), 32'(k + 7));
      tb_mem_init = v;
    end
  endfunction

  logic [DW-1:0] mem [1024];
  initial for (int w = 0; w < 1024; w++) mem[w] = tb_mem_init(T, w);

  // configuration
  int  c_bp, c_lmin, c_lmax, c_ooo, c_errwin, c_spur, c_badsrc;
  logic [31:0] rng;
  initial begin
    int s;
    s = 1;
    void'($value$plusargs("seed=%d", s));
    rng = seed_mix(32'(s), 32'(1000 + T));
    c_bp = 0;     void'($value$plusargs("tbp=%d", c_bp));
    c_lmin = 1;   void'($value$plusargs("lat_min=%d", c_lmin));
    c_lmax = 1;   void'($value$plusargs("lat_max=%d", c_lmax));
    c_ooo = 0;    void'($value$plusargs("ooo=%d", c_ooo));
    c_errwin = 0; void'($value$plusargs("errwin=%d", c_errwin));
    c_spur = 0;   void'($value$plusargs("spur=%d", c_spur));
    c_badsrc = 0; void'($value$plusargs("spur_badsrc=%d", c_badsrc));
    if (c_lmin < 1) c_lmin = 1;
    if (c_lmax < c_lmin) c_lmax = c_lmin;
  end

  function automatic int rnd(input int n);   // 0..n-1, advances rng
    begin
      rng = xs32(rng);
      rnd = (n <= 1) ? 0 : int'(rng % 32'(n));
    end
  endfunction

  // pending requests
  logic            p_v    [QCAP];
  logic [SRCW-1:0] p_src  [QCAP];
  logic [IDW-1:0]  p_id   [QCAP];
  logic [2:0]      p_op   [QCAP];
  logic [9:0]      p_w    [QCAP];
  logic [DW-1:0]   p_wd   [QCAP];
  logic [SB-1:0]   p_ws   [QCAP];
  int              p_rdy  [QCAP];
  int              p_seq  [QCAP];
  int              cyc, seq, npend;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < QCAP; i++) p_v[i] = 1'b0;
      npend         = 0;
      cyc           = 0;
      seq           = 0;
      t_req_ready  <= 1'b0;
      t_rsp_valid  <= 1'b0;
      t_rsp_src    <= '0;
      t_rsp_id     <= '0;
      t_rsp_opcode <= '0;
      t_rsp_status <= '0;
      t_rsp_rdata  <= '0;
      rsp_spurious <= 1'b0;
      n_spur_sent  <= 0;
    end else begin
      int  pick, ncand, k;
      logic sel_ok, busy_pair, spur_next;
      cyc = cyc + 1;
      // ---------------------------------------------------- accept
      if (t_req_valid && t_req_ready) begin
        k = -1;
        for (int i = QCAP - 1; i >= 0; i--) if (!p_v[i]) k = i;
        if (k < 0) $fatal(1, "sfn_tb_target%0d: accepted beyond QCAP", T);
        p_v[k]   = 1'b1;
        p_src[k] = t_req_src;
        p_id[k]  = t_req_id;
        p_op[k]  = t_req_opcode;
        p_w[k]   = t_req_addr[OFF +: 10];
        p_wd[k]  = t_req_wdata;
        p_ws[k]  = t_req_wstrb;
        p_rdy[k] = cyc + c_lmin - 1 + rnd(c_lmax - c_lmin + 1);   // L = 1: answered in the next cycle
        p_seq[k] = seq;
        seq      = seq + 1;
        npend    = npend + 1;
      end
      // ---------------------------------------------------- respond
      if (t_rsp_valid && t_rsp_ready && rsp_spurious) n_spur_sent <= n_spur_sent + 1;
      spur_next = t_rsp_valid && !t_rsp_ready && rsp_spurious;     // still held
      if (!t_rsp_valid || t_rsp_ready) begin
        t_rsp_valid  <= 1'b0;
        rsp_spurious <= 1'b0;
        // candidates: ready, and oldest of their (src,id); in-order mode: globally oldest only
        ncand = 0;
        pick  = -1;
        for (int i = 0; i < QCAP; i++) begin
          sel_ok = p_v[i] && (p_rdy[i] <= cyc);
          for (int j = 0; j < QCAP; j++) begin
            if (p_v[j] && j != i && p_seq[j] < p_seq[i]) begin
              if (c_ooo == 0) sel_ok = 1'b0;
              else if (p_src[j] == p_src[i] && p_id[j] == p_id[i]) sel_ok = 1'b0;
            end
          end
          if (sel_ok) begin
            ncand = ncand + 1;
            if (rnd(ncand) == 0) pick = i;      // reservoir sampling: uniform among candidates
          end
        end
        if (pick >= 0) begin
          logic [DW-1:0] rd;
          logic [1:0]    st;
          st = (c_errwin != 0 && p_w[pick] >= 10'd1008) ? sfn_pkg::ST_SLVERR : sfn_pkg::ST_OKAY;
          rd = '0;
          if (st == sfn_pkg::ST_OKAY) begin
            if (p_op[pick] == sfn_pkg::OP_READ) rd = mem[p_w[pick]];
            else
              for (int b = 0; b < SB; b++)
                if (p_ws[pick][b]) mem[p_w[pick]][b*8 +: 8] = p_wd[pick][b*8 +: 8];
          end
          t_rsp_valid  <= 1'b1;
          t_rsp_src    <= p_src[pick];
          t_rsp_id     <= p_id[pick];
          t_rsp_opcode <= p_op[pick];
          t_rsp_status <= st;
          t_rsp_rdata  <= rd;
          p_v[pick]     = 1'b0;
          npend         = npend - 1;
        end else if (c_spur > 0 && rnd(1000) < c_spur) begin
          // spurious response for a (src,id) with nothing outstanding at this target
          logic [SRCW-1:0] s_src;
          logic [IDW-1:0]  s_id;
          s_src = SRCW'(rnd(1 << SRCW));
          s_id  = IDW'(rnd(1 << IDW));
          busy_pair = 1'b0;
          for (int i = 0; i < QCAP; i++)
            if (p_v[i] && p_src[i] == s_src && p_id[i] == s_id) busy_pair = 1'b1;
          if (c_badsrc != 0 && 32'(s_src) < NM) busy_pair = 1'b1;
          if (!busy_pair) begin
            spur_next     = 1'b1;
            t_rsp_valid  <= 1'b1;
            rsp_spurious <= 1'b1;
            t_rsp_src    <= s_src;
            t_rsp_id     <= s_id;
            t_rsp_opcode <= (rnd(2) == 0) ? sfn_pkg::OP_READ : sfn_pkg::OP_WRITE;
            t_rsp_status <= sfn_pkg::ST_OKAY;
            t_rsp_rdata  <= DW'(rng);
          end
        end
      end
      // ---------------------------------------------------- next-cycle request readiness
      // while a spurious response is held, accept nothing: a new request with the same
      // (src,id) would make the injected response indistinguishable from a real one
      t_req_ready <= (npend < QCAP) && (rnd(1000) >= c_bp) && !spur_next;
    end
  end
  assign n_pending = npend;
endmodule

`default_nettype wire
