// =============================================================================
// SilicaFlux DataFabric-NoC :: testbench helpers (included inside TB modules)
// Tool-independent: xorshift32 generators (identical sequences under Verilator
// and Icarus), no $urandom, no classes, no queues.
// =============================================================================
// included once per module (functions are module-scoped): no include guard

// one xorshift32 step; never returns 0 for a non-zero state
function automatic logic [31:0] xs32(input logic [31:0] x);
  logic [31:0] y;
  begin
    y = x;
    y = y ^ (y << 13);
    y = y ^ (y >> 17);
    y = y ^ (y << 5);
    xs32 = y;
  end
endfunction

// seed mixing (splitmix-like, 32-bit) so that streams of different agents differ
function automatic logic [31:0] seed_mix(input logic [31:0] s, input logic [31:0] k);
  logic [31:0] z;
  begin
    z = s + 32'h9E37_79B9 * (k + 32'd1);
    z = (z ^ (z >> 16)) * 32'h85EB_CA6B;
    z = (z ^ (z >> 13)) * 32'hC2B2_AE35;
    z = z ^ (z >> 16);
    if (z == 32'd0) z = 32'h1234_5678;
    seed_mix = z;
  end
endfunction

