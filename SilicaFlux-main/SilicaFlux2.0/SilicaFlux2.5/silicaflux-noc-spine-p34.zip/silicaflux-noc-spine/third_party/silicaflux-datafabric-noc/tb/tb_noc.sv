// =============================================================================
// SilicaFlux DataFabric-NoC :: tb_noc -- self-checking testbench for silicaflux_noc
//
// Same testbench for every topology (shared bus, crossbar, mesh).  NM traffic
// generators (sfn_tb_master), NT memory targets (sfn_tb_target), a protocol
// checker on every port and an INDEPENDENT scoreboard:
//   * reference decoder (address map, access matrix, alignment, opcode) -- it
//     does not use any RTL decoder;
//   * conservation: every master acceptance routed to a target appears exactly
//     once at that target with the identical payload and source, in per-(master,
//     target) order; nothing appears at a target that no master sent;
//   * responses: every target response (and every fabric-local FENCE / DECERR
//     response) reaches exactly the master and ID it belongs to, with identical
//     data/status/opcode, in per-ID order; posted-write completions never reach
//     a master; spurious (fault-injected) responses are never delivered;
//   * fabric rules: outstanding <= MST_MAXO (O1), one target per outstanding ID
//     (O2), FENCE accepted only with nothing outstanding (O3), no transfer and no
//     fabric output during reset, decode-error / posted-error / orphan events;
//   * fairness: other-master acceptances while a master waits at the switch
//     (bound NM-1 round robin, STARVE+NM-1 QoS; shared bus and crossbar);
//   * liveness: a watchdog fails the run if no handshake happens for WD cycles
//     while work is pending (deadlock / livelock);
//   * performance counters: read back over the register bus and compared with
//     counts computed here from the ports.
// Plusargs: see sfn_tb_master / sfn_tb_target, plus +resets=K, +maxcyc=C,
// +wd=C, +trace=FILE, +test=NAME (label only).
// Output: "RESULT {...json...}" line; exit status via $fatal on failure.
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module tb_noc #(
  parameter int TOPOLOGY    = 1,
  parameter int NM          = 4,
  parameter int NT          = 4,
  parameter int AW          = 32,
  parameter int DW          = 32,
  parameter int IDW         = 2,
  parameter int ARB_MODE    = 1,
  parameter int STARVE      = 8,
  parameter int MAXO        = 4,
  parameter int MAXO0       = 1,      // master 0 (ControlCore-like) limit
  parameter int CHECK_ALIGN = 1,
  parameter int EN_SPARSE   = 0,      // 1: some master/target pairs denied
  parameter int QCAP        = 8,
  parameter int PERF        = 1,
  parameter int TGT_SFB2    = 0,      // 1: every target is an SFB2 slave behind sfn_sfb2_tgt_bridge
  parameter int RETIRE_BYPASS = 0,
  parameter int MESH_X      = 2,
  parameter int MESH_Y      = 2,
  parameter int FIFO_DEPTH  = 4
);
`include "sfn_tb_common.svh"

  localparam int SB   = DW / 8;
  localparam int OFF  = $clog2(SB);
  localparam int SRCW = sfn_pkg::clog2c(NM);
  localparam int TW   = sfn_pkg::clog2c(NT + 1);
  localparam int NID  = 1 << IDW;
  localparam int QW   = sfn_pkg::QOSW;
  localparam int CW   = sfn_pkg::clog2c(MAXO + 1);
  localparam int NN   = MESH_X * MESH_Y;
  localparam logic [AW-1:0] BASE0    = AW'(1) << (AW - 4);
  localparam logic [AW-1:0] UNMAPPED = AW'(1) << (AW - 2);

  function automatic logic [NT*AW-1:0] f_base();
    for (int t = 0; t < NT; t++) f_base[t*AW +: AW] = BASE0 + (AW'(t) << 20);
  endfunction
  function automatic logic [NT*AW-1:0] f_mask();
    for (int t = 0; t < NT; t++) f_mask[t*AW +: AW] = ~((AW'(1) << 20) - AW'(1));
  endfunction
  function automatic logic [NM*NT-1:0] f_en();
    for (int m = 0; m < NM; m++)
      for (int t = 0; t < NT; t++)
        f_en[m*NT + t] = (EN_SPARSE == 0) || (t == m % NT) || (((m + 2 * t) % 5) != 4);
  endfunction
  function automatic logic [NM*8-1:0] f_maxo();
    for (int m = 0; m < NM; m++) f_maxo[m*8 +: 8] = (m == 0) ? 8'(MAXO0) : 8'(MAXO);
  endfunction
  function automatic logic [NM*8-1:0] f_mnode();
    for (int m = 0; m < NM; m++) f_mnode[m*8 +: 8] = 8'(m % NN);
  endfunction
  function automatic logic [NT*8-1:0] f_tnode();
    for (int t = 0; t < NT; t++) f_tnode[t*8 +: 8] = 8'((NN - 1 - t % NN));
  endfunction

  localparam logic [NT*AW-1:0] TBASE  = f_base();
  localparam logic [NT*AW-1:0] TMASK  = f_mask();
  localparam logic [NM*NT-1:0] EN     = f_en();
  localparam logic [NM*8-1:0]  MMAXO  = f_maxo();
  localparam logic [NM*8-1:0]  MNODE  = f_mnode();
  localparam logic [NT*8-1:0]  TNODE  = f_tnode();

  // ================================================================ clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ================================================================ DUT
  logic [NM-1:0]      m_req_valid, m_req_ready, m_rsp_valid, m_rsp_ready;
  logic [NM*3-1:0]    m_req_opcode, m_rsp_opcode;
  logic [NM*IDW-1:0]  m_req_id, m_rsp_id;
  logic [NM*QW-1:0]   m_req_qos;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0]   m_req_wstrb;
  logic [NM*2-1:0]    m_rsp_status;
  logic [NT-1:0]      t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready;
  logic [NT*3-1:0]    t_req_opcode, t_rsp_opcode;
  logic [NT*SRCW-1:0] t_req_src, t_rsp_src;
  logic [NT*IDW-1:0]  t_req_id, t_rsp_id;
  logic [NT*QW-1:0]   t_req_qos;
  logic [NT*AW-1:0]   t_req_addr;
  logic [NT*DW-1:0]   t_req_wdata, t_rsp_rdata;
  logic [NT*SB-1:0]   t_req_wstrb;
  logic [NT*2-1:0]    t_rsp_status;
  logic               rb_sel, rb_we, rb_err, irq_err;
  logic [11:0]        rb_addr;
  logic [31:0]        rb_wdata, rb_rdata;
  logic [NM-1:0]      obs_sw_valid, obs_sw_ready, obs_decerr, obs_posted_err, obs_orphan;
  logic [NM*CW-1:0]   obs_out_cnt;
  logic [NT-1:0]      obs_bad_src;

  silicaflux_noc #(
    .TOPOLOGY(TOPOLOGY), .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE),
    .CHECK_ALIGN(CHECK_ALIGN), .RETIRE_BYPASS(RETIRE_BYPASS), .TGT_BASE(TBASE), .TGT_MASK(TMASK), .MST_TGT_EN(EN), .MAXO_MAX(MAXO),
    .MST_MAXO(MMAXO), .MESH_X(MESH_X), .MESH_Y(MESH_Y), .MST_NODE(MNODE), .TGT_NODE(TNODE),
    .FIFO_DEPTH(FIFO_DEPTH), .PERF(PERF)
  ) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
    .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_err,
    .obs_sw_valid, .obs_sw_ready, .obs_out_cnt, .obs_decerr, .obs_posted_err, .obs_orphan, .obs_bad_src
  );

  // ================================================================ agents
  logic [NM-1:0] m_done;
  int            m_issued [NM], m_chk_err [NM], m_chk_ok [NM];
  logic [NT-1:0] t_spur;
  int            t_pend [NT], t_spur_sent [NT];
  int            viol_m [NM], viol_t [NT];

  for (genvar gm = 0; gm < NM; gm++) begin : g_m
    sfn_tb_master #(
      .M(gm), .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .CHECK_ALIGN(CHECK_ALIGN), .TBASE(TBASE),
      .EN(EN[gm*NT +: NT]), .UNMAPPED(UNMAPPED)
    ) u_m (
      .clk, .rst_n,
      .req_valid(m_req_valid[gm]), .req_ready(m_req_ready[gm]), .req_opcode(m_req_opcode[gm*3 +: 3]),
      .req_id(m_req_id[gm*IDW +: IDW]), .req_qos(m_req_qos[gm*QW +: QW]), .req_addr(m_req_addr[gm*AW +: AW]),
      .req_wdata(m_req_wdata[gm*DW +: DW]), .req_wstrb(m_req_wstrb[gm*SB +: SB]),
      .rsp_valid(m_rsp_valid[gm]), .rsp_ready(m_rsp_ready[gm]), .rsp_id(m_rsp_id[gm*IDW +: IDW]),
      .rsp_opcode(m_rsp_opcode[gm*3 +: 3]), .rsp_status(m_rsp_status[gm*2 +: 2]), .rsp_rdata(m_rsp_rdata[gm*DW +: DW]),
      .done(m_done[gm]), .n_issued(m_issued[gm]), .n_check_err(m_chk_err[gm]), .n_check_ok(m_chk_ok[gm])
    );
    sfn_protocol_checker #(.QW(3 + IDW + QW + AW + DW + SB), .RW(IDW + 3 + 2 + DW), .NAME($sformatf("m%0d", gm))) u_pc (
      .clk, .rst_n,
      .req_valid(m_req_valid[gm]), .req_ready(m_req_ready[gm]),
      .req_payload({m_req_opcode[gm*3 +: 3], m_req_id[gm*IDW +: IDW], m_req_qos[gm*QW +: QW], m_req_addr[gm*AW +: AW],
                    m_req_wdata[gm*DW +: DW], m_req_wstrb[gm*SB +: SB]}),
      .rsp_valid(m_rsp_valid[gm]), .rsp_ready(m_rsp_ready[gm]),
      .rsp_payload({m_rsp_id[gm*IDW +: IDW], m_rsp_opcode[gm*3 +: 3], m_rsp_status[gm*2 +: 2], m_rsp_rdata[gm*DW +: DW]}),
      .violations(viol_m[gm])
    );
  end

  for (genvar gt = 0; gt < NT; gt++) begin : g_t
    if (TGT_SFB2 == 0) begin : g_sfb3
      sfn_tb_target #(.T(gt), .NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .QCAP(QCAP)) u_t (
        .clk, .rst_n,
        .t_req_valid(t_req_valid[gt]), .t_req_ready(t_req_ready[gt]), .t_req_opcode(t_req_opcode[gt*3 +: 3]),
        .t_req_src(t_req_src[gt*SRCW +: SRCW]), .t_req_id(t_req_id[gt*IDW +: IDW]), .t_req_qos(t_req_qos[gt*QW +: QW]),
        .t_req_addr(t_req_addr[gt*AW +: AW]), .t_req_wdata(t_req_wdata[gt*DW +: DW]), .t_req_wstrb(t_req_wstrb[gt*SB +: SB]),
        .t_rsp_valid(t_rsp_valid[gt]), .t_rsp_ready(t_rsp_ready[gt]), .t_rsp_src(t_rsp_src[gt*SRCW +: SRCW]),
        .t_rsp_id(t_rsp_id[gt*IDW +: IDW]), .t_rsp_opcode(t_rsp_opcode[gt*3 +: 3]), .t_rsp_status(t_rsp_status[gt*2 +: 2]),
        .t_rsp_rdata(t_rsp_rdata[gt*DW +: DW]), .rsp_spurious(t_spur[gt]), .n_pending(t_pend[gt]),
        .n_spur_sent(t_spur_sent[gt])
      );
    end else begin : g_sfb2
      // SFB2 slave behind the SFB3 -> SFB2 bridge (the bridge is part of the checked path)
      logic          s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
      logic [AW-1:0] s_req_addr;
      logic [DW-1:0] s_req_wdata, s_rsp_rdata;
      logic [SB-1:0] s_req_wstrb;
      sfn_sfb2_tgt_bridge #(.NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .DEPTH(QCAP)) u_br (
        .clk, .rst_n,
        .t_req_valid(t_req_valid[gt]), .t_req_ready(t_req_ready[gt]), .t_req_opcode(t_req_opcode[gt*3 +: 3]),
        .t_req_src(t_req_src[gt*SRCW +: SRCW]), .t_req_id(t_req_id[gt*IDW +: IDW]), .t_req_qos(t_req_qos[gt*QW +: QW]),
        .t_req_addr(t_req_addr[gt*AW +: AW]), .t_req_wdata(t_req_wdata[gt*DW +: DW]), .t_req_wstrb(t_req_wstrb[gt*SB +: SB]),
        .t_rsp_valid(t_rsp_valid[gt]), .t_rsp_ready(t_rsp_ready[gt]), .t_rsp_src(t_rsp_src[gt*SRCW +: SRCW]),
        .t_rsp_id(t_rsp_id[gt*IDW +: IDW]), .t_rsp_opcode(t_rsp_opcode[gt*3 +: 3]), .t_rsp_status(t_rsp_status[gt*2 +: 2]),
        .t_rsp_rdata(t_rsp_rdata[gt*DW +: DW]),
        .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
        .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error
      );
      sfn_tb_sfb2_mem #(.T(gt), .AW(AW), .DW(DW), .Q(QCAP)) u_mem (
        .clk, .rst_n, .req_valid(s_req_valid), .req_ready(s_req_ready), .req_write(s_req_write), .req_addr(s_req_addr),
        .req_wdata(s_req_wdata), .req_wstrb(s_req_wstrb), .rsp_valid(s_rsp_valid), .rsp_ready(s_rsp_ready),
        .rsp_rdata(s_rsp_rdata), .rsp_error(s_rsp_error), .n_pending(t_pend[gt])
      );
      assign t_spur[gt] = 1'b0;
      assign t_spur_sent[gt] = 0;
    end
    sfn_protocol_checker #(.QW(3 + SRCW + IDW + QW + AW + DW + SB), .RW(SRCW + IDW + 3 + 2 + DW),
                           .NAME($sformatf("t%0d", gt))) u_pc (
      .clk, .rst_n,
      .req_valid(t_req_valid[gt]), .req_ready(t_req_ready[gt]),
      .req_payload({t_req_opcode[gt*3 +: 3], t_req_src[gt*SRCW +: SRCW], t_req_id[gt*IDW +: IDW], t_req_qos[gt*QW +: QW],
                    t_req_addr[gt*AW +: AW], t_req_wdata[gt*DW +: DW], t_req_wstrb[gt*SB +: SB]}),
      .rsp_valid(t_rsp_valid[gt]), .rsp_ready(t_rsp_ready[gt]),
      .rsp_payload({t_rsp_src[gt*SRCW +: SRCW], t_rsp_id[gt*IDW +: IDW], t_rsp_opcode[gt*3 +: 3],
                    t_rsp_status[gt*2 +: 2], t_rsp_rdata[gt*DW +: DW]}),
      .violations(viol_t[gt])
    );
  end

  // ================================================================ link monitor (utilisation)
  // crossbar / shared bus: request and response transfers per target port (t_nreq / t_nrsp below);
  // mesh: flits per router output link of both networks (hierarchical probe, mesh builds only)
  longint mesh_q_flits, mesh_s_flits;
  int     mesh_link_max, mesh_links_used;
  initial begin mesh_q_flits = 0; mesh_s_flits = 0; mesh_link_max = 0; mesh_links_used = 0; end
  if (TOPOLOGY == 2) begin : g_meshmon
    localparam int NL = MESH_X * MESH_Y * 5;
    int lq [NL], ls [NL];
    initial for (int i = 0; i < NL; i++) begin lq[i] = 0; ls[i] = 0; end
    always @(posedge clk) if (rst_n && sb_count) begin
      for (int i = 0; i < NL; i++) begin
        if (dut.g_mesh.u_core.q_out_v[i]) begin lq[i] = lq[i] + 1; mesh_q_flits = mesh_q_flits + 1; end
        if (dut.g_mesh.u_core.s_out_v[i]) begin ls[i] = ls[i] + 1; mesh_s_flits = mesh_s_flits + 1; end
      end
      mesh_link_max = 0; mesh_links_used = 0;
      for (int i = 0; i < NL; i++) begin
        if (lq[i] > mesh_link_max) mesh_link_max = lq[i];
        if (ls[i] > mesh_link_max) mesh_link_max = ls[i];
        if (lq[i] > 0) mesh_links_used = mesh_links_used + 1;
        if (ls[i] > 0) mesh_links_used = mesh_links_used + 1;
      end
    end
  end

  // ================================================================ reference decoder
  // returns target index, or -1 FENCE (local OKAY), -2 DECERR, -3 posted write dropped
  function automatic int ref_decode(input int m, input logic [2:0] op, input logic [AW-1:0] a);
    int hit;
    begin
      if (op == sfn_pkg::OP_FENCE) return -1;
      if (op > 3'd2) return -2;
      hit = -1;
      for (int t = NT - 1; t >= 0; t--)
        if ((a & TMASK[t*AW +: AW]) == TBASE[t*AW +: AW]) hit = t;
      if ((CHECK_ALIGN != 0 && OFF > 0 && (a & AW'(SB - 1)) != '0) || hit < 0 || !EN[m*NT + hit])
        return (op == sfn_pkg::OP_WRITE_POSTED) ? -3 : -2;
      return hit;
    end
  endfunction

  function automatic int popc(input logic [SB-1:0] v);
    popc = 0;
    for (int i = 0; i < SB; i++) popc = popc + int'(v[i]);
  endfunction

  // ================================================================ scoreboard storage
  localparam int QD = 64;
  // expected at target, per (m,t): index m*NT+t
  logic [2:0]    tq_op   [NM*NT][QD];
  logic [IDW-1:0] tq_id  [NM*NT][QD];
  logic [2:0]    tq_qos  [NM*NT][QD];
  logic [AW-1:0] tq_addr [NM*NT][QD];
  logic [DW-1:0] tq_wd   [NM*NT][QD];
  logic [SB-1:0] tq_ws   [NM*NT][QD];
  int            tq_acc  [NM*NT][QD];
  int            tq_pres [NM*NT][QD];
  int            tq_rd [NM*NT], tq_wr [NM*NT];
  // pending at target, per (t,src,id): index (t*NM+src)*NID+id
  logic [2:0]    tp_op   [NT*NM*NID][QD];
  int            tp_acc  [NT*NM*NID][QD];
  int            tp_pres [NT*NM*NID][QD];
  int            tp_tacc [NT*NM*NID][QD];
  logic [AW-1:0] tp_addr [NT*NM*NID][QD];
  int            tp_bytes[NT*NM*NID][QD];
  int            tp_rd [NT*NM*NID], tp_wr [NT*NM*NID];
  // expected master response, per (m,id): index m*NID+id
  logic [2:0]    rq_op   [NM*NID][QD];
  logic [1:0]    rq_st   [NM*NID][QD];
  logic [DW-1:0] rq_data [NM*NID][QD];
  int            rq_tgt  [NM*NID][QD];
  int            rq_acc  [NM*NID][QD];
  int            rq_pres [NM*NID][QD];
  int            rq_tacc [NM*NID][QD];
  logic [AW-1:0] rq_addr [NM*NID][QD];
  int            rq_bytes[NM*NID][QD];
  int            rq_rd [NM*NID], rq_wr [NM*NID];
  // fabric-rule shadows
  int            sb_out [NM];          // outstanding per master (posted retired at target response)
  int            sb_idc [NM*NID];
  int            sb_idt [NM*NID];

  // ================================================================ statistics
  int    cyc, errors, last_prog, first_acc, last_done;
  int    n_acc [NM], n_rsp [NM], n_posted_done [NM], n_drop [NM], acc_bytes [NM], rd_bytes [NM];
  int    req_stall [NM], rsp_stall [NM], sw_stall [NM], occ_max [NM], err_cyc [NM];
  longint lat_sum [NM], alat_sum [NM];
  int    pres_cyc [NM];
  logic  held [NM];
  int    lat_n [NM], lat_max [NM], lat_min [NM];
  int    t_nreq [NT], t_wr_bytes [NT], t_req_bp [NT], t_nrsp [NT], t_rsp_bp [NT];
  int    n_posted_err_exp, n_posted_err_seen, n_orphan_seen, n_badsrc_seen, n_spur_acc;
  int    wcnt [NM], wmax [NM];
  logic  decerr_flag, posted_flag, orphan_flag, badsrc_flag;   // sticky, since the last reset
  longint total_bytes;
  logic  sb_count;
  int    n_count_cyc;
  int    trace_fd;
  int    c_wd, c_maxcyc, c_resets, n_resets_done;
  string c_test;

  task automatic fail(input string msg);
    $error("[cyc %0d] %s", cyc, msg);
    errors = errors + 1;
  endtask

  task automatic sb_flush();
    for (int i = 0; i < NM*NT; i++) begin tq_rd[i] = 0; tq_wr[i] = 0; end
    for (int i = 0; i < NT*NM*NID; i++) begin tp_rd[i] = 0; tp_wr[i] = 0; end
    for (int i = 0; i < NM*NID; i++) begin rq_rd[i] = 0; rq_wr[i] = 0; sb_idc[i] = 0; sb_idt[i] = -9; end
    for (int m = 0; m < NM; m++) begin
      sb_out[m] = 0; n_acc[m] = 0; n_rsp[m] = 0; n_posted_done[m] = 0; n_drop[m] = 0; acc_bytes[m] = 0;
      rd_bytes[m] = 0; req_stall[m] = 0; rsp_stall[m] = 0; sw_stall[m] = 0; occ_max[m] = 0; err_cyc[m] = 0;
      lat_sum[m] = 0; alat_sum[m] = 0; held[m] = 1'b0; lat_n[m] = 0; lat_max[m] = 0; lat_min[m] = 32'h7fff_ffff; wcnt[m] = 0;
    end
    for (int t = 0; t < NT; t++) begin
      t_nreq[t] = 0; t_wr_bytes[t] = 0; t_req_bp[t] = 0; t_nrsp[t] = 0; t_rsp_bp[t] = 0;
    end
    n_posted_err_exp = 0; n_posted_err_seen = 0; n_orphan_seen = 0; n_badsrc_seen = 0; n_spur_acc = 0;
    decerr_flag = 1'b0; posted_flag = 1'b0; orphan_flag = 1'b0; badsrc_flag = 1'b0;
    sb_count = 1'b1;
    n_count_cyc = 0;
  endtask

  initial begin
    errors = 0; cyc = 0; last_prog = 0; first_acc = -1; last_done = 0; total_bytes = 0; n_resets_done = 0;
    for (int m = 0; m < NM; m++) wmax[m] = 0;
    sb_flush();
    c_wd = 4000;        void'($value$plusargs("wd=%d", c_wd));
    c_maxcyc = 2000000; void'($value$plusargs("maxcyc=%d", c_maxcyc));
    c_resets = 0;       void'($value$plusargs("resets=%d", c_resets));
    c_test = "unnamed"; void'($value$plusargs("test=%s", c_test));
    trace_fd = 0;
    begin
      string tf;
      if ($value$plusargs("trace=%s", tf)) begin
        trace_fd = $fopen(tf, "w");
        $fwrite(trace_fd, "master,id,op,addr,target,qos,issue_cycle,accept_cycle,target_cycle,done_cycle,status,bytes,latency,access_latency\n");
      end
    end
  end

  // ================================================================ per-cycle checking
  always @(posedge clk) begin
    int ri, qi, pi, k, t, m, lat;
    logic any_hs, any_pending;
    if (!rst_n) begin
      // R11: nothing transfers during reset, and the fabric drives no valid outputs
      if ((|(m_req_valid & m_req_ready)) || (|t_req_valid) || (|m_rsp_valid))
        fail("fabric transfer or valid output during reset");
    end else begin
      cyc = cyc + 1;
      if (sb_count) n_count_cyc = n_count_cyc + 1;
      any_hs = 1'b0;
      // ------------------------------------------------------------ 1. target responses
      for (t = 0; t < NT; t++) begin
        if (t_rsp_valid[t] && t_rsp_ready[t]) begin
          any_hs = 1'b1;
          if (sb_count) t_nrsp[t] = t_nrsp[t] + 1;
          if (t_spur[t]) begin
            n_spur_acc = n_spur_acc + 1;
          end else begin
            m  = int'(t_rsp_src[t*SRCW +: SRCW]);
            pi = (t * NM + m) * NID + int'(t_rsp_id[t*IDW +: IDW]);
            if (tp_rd[pi] == tp_wr[pi]) fail($sformatf("t%0d responded for src %0d id %0d with nothing pending", t, m,
                                                       t_rsp_id[t*IDW +: IDW]));
            else begin
              qi = tp_rd[pi] % QD;
              if (tp_op[pi][qi] != t_rsp_opcode[t*3 +: 3]) fail($sformatf("t%0d response opcode mismatch", t));
              ri = m * NID + int'(t_rsp_id[t*IDW +: IDW]);
              if (tp_op[pi][qi] == sfn_pkg::OP_WRITE_POSTED) begin
                // posted completion: retired by the fabric, never delivered
                sb_out[m] = sb_out[m] - 1;
                sb_idc[ri] = sb_idc[ri] - 1;
                n_posted_done[m] = n_posted_done[m] + 1;
                if (t_rsp_status[t*2 +: 2] != sfn_pkg::ST_OKAY) n_posted_err_exp = n_posted_err_exp + 1;
                if (trace_fd != 0)
                  $fwrite(trace_fd, "%0d,%0d,%0d,%h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n", m, t_rsp_id[t*IDW +: IDW],
                          tp_op[pi][qi], tp_addr[pi][qi], t, 0, tp_pres[pi][qi], tp_acc[pi][qi], tp_tacc[pi][qi], cyc - 1,
                          t_rsp_status[t*2 +: 2], tp_bytes[pi][qi], cyc - 1 - tp_acc[pi][qi], cyc - 1 - tp_pres[pi][qi]);
                if (cyc > last_done) last_done = cyc;
              end else begin
                if (rq_wr[ri] - rq_rd[ri] >= QD) fail("response queue overflow");
                k = rq_wr[ri] % QD;
                rq_op[ri][k]    = tp_op[pi][qi];
                rq_st[ri][k]    = t_rsp_status[t*2 +: 2];
                rq_data[ri][k]  = t_rsp_rdata[t*DW +: DW];
                rq_tgt[ri][k]   = t;
                rq_acc[ri][k]   = tp_acc[pi][qi];
                rq_pres[ri][k]  = tp_pres[pi][qi];
                rq_tacc[ri][k]  = tp_tacc[pi][qi];
                rq_addr[ri][k]  = tp_addr[pi][qi];
                rq_bytes[ri][k] = tp_bytes[pi][qi];
                rq_wr[ri] = rq_wr[ri] + 1;
              end
              tp_rd[pi] = tp_rd[pi] + 1;
            end
          end
        end
        if (sb_count && t_rsp_valid[t] && !t_rsp_ready[t]) t_rsp_bp[t] = t_rsp_bp[t] + 1;
      end
      // ------------------------------------------------------------ 2. master responses
      for (m = 0; m < NM; m++) begin
        if (m_rsp_valid[m] && m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED)
          fail($sformatf("m%0d received a posted-write completion", m));
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          any_hs = 1'b1;
          ri = m * NID + int'(m_rsp_id[m*IDW +: IDW]);
          if (rq_rd[ri] == rq_wr[ri]) fail($sformatf("m%0d got a response for id %0d with none expected (misroute/duplicate)",
                                                     m, m_rsp_id[m*IDW +: IDW]));
          else begin
            k = rq_rd[ri] % QD;
            if (rq_op[ri][k] != m_rsp_opcode[m*3 +: 3] || rq_st[ri][k] != m_rsp_status[m*2 +: 2] ||
                rq_data[ri][k] != m_rsp_rdata[m*DW +: DW])
              fail($sformatf("m%0d id %0d response mismatch: got op %0d st %0d data %h, expected op %0d st %0d data %h (tgt %0d)",
                             m, m_rsp_id[m*IDW +: IDW], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2],
                             m_rsp_rdata[m*DW +: DW], rq_op[ri][k], rq_st[ri][k], rq_data[ri][k], rq_tgt[ri][k]));
            lat = cyc - 1 - rq_acc[ri][k];
            if (sb_count) begin
              n_rsp[m] = n_rsp[m] + 1;
              lat_sum[m] = lat_sum[m] + longint'(lat);
              alat_sum[m] = alat_sum[m] + longint'(cyc - 1 - rq_pres[ri][k]);
              lat_n[m] = lat_n[m] + 1;
              if (lat > lat_max[m]) lat_max[m] = lat;
              if (lat < lat_min[m]) lat_min[m] = lat;
              if (m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_READ && m_rsp_status[m*2 +: 2] == sfn_pkg::ST_OKAY)
                rd_bytes[m] = rd_bytes[m] + SB;
            end
            if (rq_op[ri][k] == sfn_pkg::OP_READ && m_rsp_status[m*2 +: 2] == sfn_pkg::ST_OKAY)
              total_bytes = total_bytes + SB;
            if (trace_fd != 0)
              $fwrite(trace_fd, "%0d,%0d,%0d,%h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n", m, m_rsp_id[m*IDW +: IDW],
                      rq_op[ri][k], rq_addr[ri][k], rq_tgt[ri][k], 0, rq_pres[ri][k], rq_acc[ri][k], rq_tacc[ri][k], cyc - 1,
                      m_rsp_status[m*2 +: 2], rq_bytes[ri][k], lat, cyc - 1 - rq_pres[ri][k]);
            if (cyc > last_done) last_done = cyc;
            rq_rd[ri] = rq_rd[ri] + 1;
            sb_out[m] = sb_out[m] - 1;
            sb_idc[ri] = sb_idc[ri] - 1;
          end
        end
        if (sb_count && m_rsp_valid[m] && !m_rsp_ready[m]) rsp_stall[m] = rsp_stall[m] + 1;
      end
      // ------------------------------------------------------------ 3. master requests
      for (m = 0; m < NM; m++) begin
        logic [2:0] op;
        logic [AW-1:0] a;
        int d, id;
        op = m_req_opcode[m*3 +: 3];
        a  = m_req_addr[m*AW +: AW];
        id = int'(m_req_id[m*IDW +: IDW]);
        d  = ref_decode(m, op, a);
        if (m_req_valid[m] && !held[m]) pres_cyc[m] = cyc - 1;     // first cycle this request is presented
        held[m] = m_req_valid[m] && !m_req_ready[m];
        if (obs_decerr[m] != (m_req_valid[m] && m_req_ready[m] && d <= -2))
          fail($sformatf("m%0d decode-error event %0d, expected %0d", m, obs_decerr[m], m_req_valid[m] && m_req_ready[m] && d <= -2));
        if (sb_count && m_req_valid[m] && !m_req_ready[m]) req_stall[m] = req_stall[m] + 1;
        if (sb_count && obs_sw_valid[m] && !obs_sw_ready[m]) sw_stall[m] = sw_stall[m] + 1;
        if (m_req_valid[m] && m_req_ready[m]) begin
          any_hs = 1'b1;
          if (first_acc < 0) first_acc = cyc;
          if (sb_count) begin
            n_acc[m] = n_acc[m] + 1;
            if (op == sfn_pkg::OP_READ) acc_bytes[m] = acc_bytes[m] + SB;
            else if (sfn_pkg::op_is_write(op)) acc_bytes[m] = acc_bytes[m] + popc(m_req_wstrb[m*SB +: SB]);
          end
          ri = m * NID + id;
          if (op == sfn_pkg::OP_FENCE && sb_out[m] != 0)
            fail($sformatf("m%0d FENCE accepted with %0d transactions outstanding (O3)", m, sb_out[m]));
          if (d == -3) begin
            n_drop[m] = n_drop[m] + 1;
            posted_flag = 1'b1;
          end else begin
            // O2: one target per outstanding ID (-1 = local responder)
            if (sb_idc[ri] > 0 && sb_idt[ri] != ((d >= 0) ? d : -1))
              fail($sformatf("m%0d id %0d sent to %0d while outstanding at %0d (O2)", m, id, d, sb_idt[ri]));
            sb_idc[ri] = sb_idc[ri] + 1;
            sb_idt[ri] = (d >= 0) ? d : -1;
            sb_out[m] = sb_out[m] + 1;
            if (sb_out[m] > int'(MMAXO[m*8 +: 8]))
              fail($sformatf("m%0d has %0d outstanding > MAXO %0d (O1)", m, sb_out[m], MMAXO[m*8 +: 8]));
            if (d >= 0) begin
              qi = m * NT + d;
              if (tq_wr[qi] - tq_rd[qi] >= QD) fail("target expectation queue overflow");
              k = tq_wr[qi] % QD;
              tq_op[qi][k] = op; tq_id[qi][k] = IDW'(id); tq_qos[qi][k] = m_req_qos[m*QW +: QW];
              tq_addr[qi][k] = a; tq_wd[qi][k] = m_req_wdata[m*DW +: DW]; tq_ws[qi][k] = m_req_wstrb[m*SB +: SB];
              tq_acc[qi][k] = cyc - 1;
              tq_pres[qi][k] = pres_cyc[m];
              tq_wr[qi] = tq_wr[qi] + 1;
            end else begin
              // fabric-local response: FENCE -> OKAY, everything else -> DECERR
              k = rq_wr[ri] % QD;
              rq_op[ri][k]    = op;
              rq_st[ri][k]    = (d == -1) ? sfn_pkg::ST_OKAY : sfn_pkg::ST_DECERR;
              rq_data[ri][k]  = '0;
              rq_tgt[ri][k]   = -1;
              rq_acc[ri][k]   = cyc - 1;
              rq_pres[ri][k]  = pres_cyc[m];
              rq_tacc[ri][k]  = -1;
              rq_addr[ri][k]  = a;
              rq_bytes[ri][k] = 0;
              rq_wr[ri] = rq_wr[ri] + 1;
            end
          end
        end
        if (int'(obs_out_cnt[m*CW +: CW]) > int'(MMAXO[m*8 +: 8]))
          fail($sformatf("m%0d fabric outstanding count %0d > MAXO (O1)", m, obs_out_cnt[m*CW +: CW]));
        if (sb_count && int'(obs_out_cnt[m*CW +: CW]) > occ_max[m]) occ_max[m] = int'(obs_out_cnt[m*CW +: CW]);
        if (obs_posted_err[m]) begin n_posted_err_seen = n_posted_err_seen + 1; posted_flag = 1'b1; end
        if (obs_orphan[m])     begin n_orphan_seen = n_orphan_seen + 1; orphan_flag = 1'b1; end
        if (obs_decerr[m])     decerr_flag = 1'b1;
        if (sb_count)
          err_cyc[m] = err_cyc[m] + int'(m_rsp_valid[m] && m_rsp_ready[m] && m_rsp_status[m*2 +: 2] != sfn_pkg::ST_OKAY)
                                  + int'(obs_posted_err[m])
                                  + int'(obs_decerr[m] && m_req_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED);
      end
      for (t = 0; t < NT; t++) if (obs_bad_src[t]) begin n_badsrc_seen = n_badsrc_seen + 1; badsrc_flag = 1'b1; end
      // ------------------------------------------------------------ 4. target requests
      for (t = 0; t < NT; t++) begin
        if (sb_count && t_req_valid[t] && !t_req_ready[t]) t_req_bp[t] = t_req_bp[t] + 1;
        if (t_req_valid[t] && t_req_ready[t]) begin
          logic [2:0] op;
          any_hs = 1'b1;
          m  = int'(t_req_src[t*SRCW +: SRCW]);
          op = t_req_opcode[t*3 +: 3];
          if (sb_count) begin
            t_nreq[t] = t_nreq[t] + 1;
            if (sfn_pkg::op_is_write(op)) t_wr_bytes[t] = t_wr_bytes[t] + popc(t_req_wstrb[t*SB +: SB]);
          end
          if (m >= NM || !EN[m*NT + t]) fail($sformatf("t%0d request from illegal source %0d", t, m));
          else begin
            qi = m * NT + t;
            if (tq_rd[qi] == tq_wr[qi]) fail($sformatf("t%0d got a request from m%0d that was never sent (duplicate/misroute)", t, m));
            else begin
              k = tq_rd[qi] % QD;
              if (tq_op[qi][k] != op || tq_id[qi][k] != t_req_id[t*IDW +: IDW] || tq_qos[qi][k] != t_req_qos[t*QW +: QW] ||
                  tq_addr[qi][k] != t_req_addr[t*AW +: AW] ||
                  (sfn_pkg::op_is_write(op) && (tq_wd[qi][k] != t_req_wdata[t*DW +: DW] || tq_ws[qi][k] != t_req_wstrb[t*SB +: SB])))
                fail($sformatf("t%0d request from m%0d differs from the master's (order/corruption): op %0d/%0d addr %h/%h",
                               t, m, op, tq_op[qi][k], t_req_addr[t*AW +: AW], tq_addr[qi][k]));
              pi = (t * NM + m) * NID + int'(t_req_id[t*IDW +: IDW]);
              if (tp_wr[pi] - tp_rd[pi] >= QD) fail("target pending queue overflow");
              qi = tp_wr[pi] % QD;
              tp_op[pi][qi]    = op;
              tp_acc[pi][qi]   = tq_acc[m * NT + t][k];
              tp_pres[pi][qi]  = tq_pres[m * NT + t][k];
              tp_tacc[pi][qi]  = cyc - 1;
              tp_addr[pi][qi]  = t_req_addr[t*AW +: AW];
              tp_bytes[pi][qi] = (op == sfn_pkg::OP_READ) ? SB : popc(t_req_wstrb[t*SB +: SB]);
              tp_wr[pi] = tp_wr[pi] + 1;
              if (sfn_pkg::op_is_write(op)) total_bytes = total_bytes + longint'(popc(t_req_wstrb[t*SB +: SB]));
              tq_rd[m * NT + t] = tq_rd[m * NT + t] + 1;
            end
          end
        end
      end
      // ------------------------------------------------------------ 5. fairness (shared bus / crossbar)
      if (TOPOLOGY != sfn_pkg::TOPO_MESH) begin
        for (m = 0; m < NM; m++) begin
          if (obs_sw_valid[m] && !obs_sw_ready[m]) begin
            for (int j = 0; j < NM; j++) begin
              if (j != m && obs_sw_valid[j] && obs_sw_ready[j] &&
                  (TOPOLOGY == sfn_pkg::TOPO_SHARED_BUS ||
                   ref_decode(j, m_req_opcode[j*3 +: 3], m_req_addr[j*AW +: AW]) ==
                   ref_decode(m, m_req_opcode[m*3 +: 3], m_req_addr[m*AW +: AW])))
                wcnt[m] = wcnt[m] + 1;
            end
          end else begin
            if (wcnt[m] > wmax[m]) wmax[m] = wcnt[m];
            wcnt[m] = 0;
          end
        end
      end
      // ------------------------------------------------------------ 6. liveness watchdog
      any_pending = 1'b0;
      for (m = 0; m < NM; m++) if (sb_out[m] > 0 || m_req_valid[m]) any_pending = 1'b1;
      if (any_hs) last_prog = cyc;
      else if (any_pending && (cyc - last_prog) > c_wd) begin
        fail($sformatf("no progress for %0d cycles with work pending: DEADLOCK/LIVELOCK", c_wd));
        finish_run();
      end
      if (cyc > c_maxcyc) begin
        fail("maximum cycle count reached");
        finish_run();
      end
      // perf freeze point (see end-of-test sequence)
      if (rb_sel && rb_we && rb_addr == 12'h000 && !rb_wdata[0]) sb_count = 1'b0;
    end
  end

  // ================================================================ reset driver
  initial begin
    logic [31:0] r;
    int s;
    s = 1; void'($value$plusargs("seed=%d", s));
    r = seed_mix(32'(s), 32'd777);
    rst_n = 1'b0;
    rb_sel = 1'b0; rb_we = 1'b0; rb_addr = '0; rb_wdata = '0;
    repeat (4) @(posedge clk);
    rst_n <= 1'b1;
    for (int i = 0; i < c_resets; i++) begin
      r = xs32(r);
      repeat (300 + int'(r % 32'd1500)) @(posedge clk);
      #3 rst_n = 1'b0;                         // asynchronous assertion, mid-cycle
      sb_flush();
      n_resets_done = n_resets_done + 1;
      r = xs32(r);
      repeat (2 + int'(r % 32'd3)) @(posedge clk);
      rst_n <= 1'b1;                           // synchronous release
    end
  end

  // ================================================================ end of test
  logic finishing = 1'b0;
  task automatic rb_read(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a;
    #1 d = rb_rdata;
    if (rb_err) fail($sformatf("perf read 0x%03h reported rb_err", a));
    @(negedge clk);
    rb_sel = 1'b0;
  endtask

  task automatic chk(input string what, input int got, input int exp);
    if (got != exp) fail($sformatf("perf counter %s = %0d, expected %0d", what, got, exp));
  endtask

  task automatic finish_run();
    int nv, sum_ok, sum_err, n_txn, lmax, lsum, ln;
    longint ls;
    real thr;
    if (finishing) return;
    finishing = 1'b1;
    // drained?
    for (int i = 0; i < NM*NT; i++) if (tq_rd[i] != tq_wr[i]) fail($sformatf("lost request(s) for m%0d->t%0d", i / NT, i % NT));
    for (int i = 0; i < NT*NM*NID; i++) if (tp_rd[i] != tp_wr[i]) fail("request(s) never answered by a target");
    for (int i = 0; i < NM*NID; i++) if (rq_rd[i] != rq_wr[i]) fail($sformatf("lost response(s) for m%0d id %0d", i / NID, i % NID));
    for (int m = 0; m < NM; m++) if (sb_out[m] != 0) fail($sformatf("m%0d still has %0d outstanding", m, sb_out[m]));
    if (n_posted_err_seen != n_posted_err_exp)
      fail($sformatf("posted-error events %0d, expected %0d", n_posted_err_seen, n_posted_err_exp));
    if (n_orphan_seen + n_badsrc_seen != n_spur_acc)
      fail($sformatf("orphan %0d + bad-source %0d events != %0d spurious responses accepted", n_orphan_seen, n_badsrc_seen, n_spur_acc));
    nv = 0;
    for (int m = 0; m < NM; m++) nv = nv + viol_m[m];
    for (int t = 0; t < NT; t++) nv = nv + viol_t[t];
    if (nv != 0) fail($sformatf("%0d protocol violations", nv));
    sum_ok = 0; sum_err = 0;
    for (int m = 0; m < NM; m++) begin sum_ok = sum_ok + m_chk_ok[m]; sum_err = sum_err + m_chk_err[m]; end
    // fairness bound
    if (TOPOLOGY != sfn_pkg::TOPO_MESH && ARB_MODE != sfn_pkg::ARB_FIXED)
      for (int m = 0; m < NM; m++)
        if (wmax[m] > ((ARB_MODE == sfn_pkg::ARB_QOS) ? STARVE + NM - 1 : NM - 1))
          fail($sformatf("m%0d waited %0d other acceptances (> fairness bound)", m, wmax[m]));
    // QoS effectiveness (+qos_check=1 with +qos_idx=1: QoS level = master index): the top level must
    // wait clearly less at the switch than a lower level with the same outstanding limit (master 1)
    if ($test$plusargs("qos_check") && NM >= 3 && !(sw_stall[NM-1] * 4 < sw_stall[1] * 3))
      fail($sformatf("QoS ineffective: top-level master waited %0d switch cycles vs %0d for level 1", sw_stall[NM-1], sw_stall[1]));
    // performance counters (counted since the last reset, frozen at the same edge)
    if (PERF != 0 && errors == 0) begin
      logic [31:0] v;
      @(negedge clk);
      rb_sel = 1'b1; rb_we = 1'b1; rb_addr = 12'h000; rb_wdata = 32'd0;     // ENABLE = 0
      @(negedge clk);
      rb_sel = 1'b0; rb_we = 1'b0;
      for (int m = 0; m < NM; m++) begin
        logic [11:0] b;
        b = 12'(32'h100 + m * 32'h40);
        rb_read(b + 12'd0,  v); chk($sformatf("m%0d.REQ", m), int'(v), n_acc[m]);
        rb_read(b + 12'd4,  v); chk($sformatf("m%0d.ACC_BYTES", m), int'(v), acc_bytes[m]);
        rb_read(b + 12'd8,  v); chk($sformatf("m%0d.RSP", m), int'(v), n_rsp[m]);
        rb_read(b + 12'd12, v); chk($sformatf("m%0d.RD_BYTES", m), int'(v), rd_bytes[m]);
        rb_read(b + 12'd16, v); chk($sformatf("m%0d.REQ_STALL", m), int'(v), req_stall[m]);
        rb_read(b + 12'd20, v); chk($sformatf("m%0d.ARB_STALL", m), int'(v), sw_stall[m]);
        rb_read(b + 12'd28, v); chk($sformatf("m%0d.RSP_STALL", m), int'(v), rsp_stall[m]);
        rb_read(b + 12'd36, v); chk($sformatf("m%0d.OCC_MAX", m), int'(v), occ_max[m]);
        rb_read(b + 12'd52, v); chk($sformatf("m%0d.ERR", m), int'(v), err_cyc[m]);
        rb_read(b + 12'd44, v); ln = int'(v);
        rb_read(b + 12'd40, v); lsum = int'(v);
        rb_read(b + 12'd48, v); lmax = int'(v);
        if (ln > n_rsp[m]) fail($sformatf("m%0d sampled latency count %0d > responses %0d", m, ln, n_rsp[m]));
        if (ln > 0 && (lmax > lat_max[m] || lsum < ln * lat_min[m] || lsum > ln * lat_max[m]))
          fail($sformatf("m%0d sampled latency (n %0d sum %0d max %0d) outside measured [%0d,%0d]", m, ln, lsum, lmax,
                         lat_min[m], lat_max[m]));
      end
      for (int t = 0; t < NT; t++) begin
        logic [11:0] b;
        b = 12'(32'h800 + t * 32'h20);
        rb_read(b + 12'd0,  v); chk($sformatf("t%0d.REQ", t), int'(v), t_nreq[t]);
        rb_read(b + 12'd4,  v); chk($sformatf("t%0d.WR_BYTES", t), int'(v), t_wr_bytes[t]);
        rb_read(b + 12'd8,  v); chk($sformatf("t%0d.REQ_BP", t), int'(v), t_req_bp[t]);
        rb_read(b + 12'd12, v); chk($sformatf("t%0d.RSP", t), int'(v), t_nrsp[t]);
        rb_read(b + 12'd16, v); chk($sformatf("t%0d.RSP_BP", t), int'(v), t_rsp_bp[t]);
      end
      rb_read(12'h008, v);
      chk("ERR_STATUS", int'(v[3:0]), int'({badsrc_flag, orphan_flag, posted_flag, decerr_flag}));
    end
    // summary
    n_txn = 0; ls = 0; ln = 0; lmax = 0;
    for (int m = 0; m < NM; m++) begin
      n_txn = n_txn + n_acc[m];
      ls = ls + lat_sum[m]; ln = ln + lat_n[m];
      if (lat_max[m] > lmax) lmax = lat_max[m];
    end
    thr = (last_done > first_acc && first_acc >= 0) ? real'(total_bytes) / real'(last_done - first_acc + 1) : 0.0;
    begin
      longint als;
      als = 0;
      for (int m = 0; m < NM; m++) als = als + alat_sum[m];
      $display("RESULT {\"test\":\"%s\",\"pass\":%0d,\"errors\":%0d,\"cycles\":%0d,\"txns\":%0d,\"resets\":%0d,\"self_checks\":%0d,\"self_check_err\":%0d,\"avg_lat\":%0.2f,\"avg_access_lat\":%0.2f,\"max_lat\":%0d,\"bytes\":%0d,\"bytes_per_cycle\":%0.3f,\"spurious\":%0d,\"posted_err\":%0d,\"wait_max\":[%s],\"sw_stall\":[%s]}",
               c_test, (errors == 0 && sum_err == 0) ? 1 : 0, errors + sum_err, cyc, n_txn, n_resets_done, sum_ok, sum_err,
               (ln > 0) ? real'(ls) / real'(ln) : 0.0, (ln > 0) ? real'(als) / real'(ln) : 0.0, lmax, total_bytes, thr,
               n_spur_acc, n_posted_err_seen, wmax_str(), swst_str());
      begin
        int tmax;
        tmax = 0;
        for (int t = 0; t < NT; t++) begin
          if (t_nreq[t] > tmax) tmax = t_nreq[t];
          if (t_nrsp[t] > tmax) tmax = t_nrsp[t];
        end
        $display("LINKS {\"cycles_counted\":%0d,\"tgt_link_max_transfers\":%0d,\"tgt_req\":[%s],\"mesh_req_flits\":%0d,\"mesh_rsp_flits\":%0d,\"mesh_link_max_flits\":%0d,\"mesh_links_used\":%0d}",
                 n_count_cyc, tmax, treq_str(), mesh_q_flits, mesh_s_flits, mesh_link_max, mesh_links_used);
      end
    end
    for (int m = 0; m < NM; m++)
      $display("  m%0d: acc %0d rsp %0d posted %0d drops %0d lat avg %0.1f max %0d  req_stall %0d sw_stall %0d occ_max %0d wait_max %0d",
               m, n_acc[m], n_rsp[m], n_posted_done[m], n_drop[m], (lat_n[m] > 0) ? real'(lat_sum[m]) / real'(lat_n[m]) : 0.0,
               lat_max[m], req_stall[m], sw_stall[m], occ_max[m], wmax[m]);
    if (trace_fd != 0) $fclose(trace_fd);
    if (errors != 0 || sum_err != 0) $fatal(1, "TEST FAILED: %0d errors", errors + sum_err);
    $display("TEST PASSED");
    $finish;
  endtask

  function automatic string treq_str();
    string s;
    s = "";
    for (int t = 0; t < NT; t++) s = {s, $sformatf("%s%0d", (t == 0) ? "" : ",", t_nreq[t])};
    return s;
  endfunction

  function automatic string swst_str();
    string s;
    s = "";
    for (int m = 0; m < NM; m++) s = {s, $sformatf("%s%0d", (m == 0) ? "" : ",", sw_stall[m])};
    return s;
  endfunction

  function automatic string wmax_str();
    string s;
    s = "";
    for (int m = 0; m < NM; m++) s = {s, $sformatf("%s%0d", (m == 0) ? "" : ",", wmax[m])};
    return s;
  endfunction

  // completion detector
  initial begin
    @(posedge rst_n);
    forever begin
      @(posedge clk);
      if (rst_n && n_resets_done >= c_resets && (&m_done)) begin
        int busy;
        busy = 0;
        for (int m = 0; m < NM; m++) if (sb_out[m] != 0) busy = 1;
        for (int t = 0; t < NT; t++) if (t_pend[t] != 0 || t_rsp_valid[t]) busy = 1;
        if (busy == 0) begin
          repeat (20) @(posedge clk);
          finish_run();
        end
      end
    end
  end
endmodule

`default_nettype wire
