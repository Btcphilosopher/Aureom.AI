// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_protocol_checker -- SFB3 port handshake checks
//
// Generic (payloads passed as flat vectors) so one module watches master ports,
// target ports and network-interface channels.  Checked every cycle after reset:
//   R2  a request held (valid && !ready) stays valid with an unchanged payload
//   R4  a response held (valid && !ready) stays valid with an unchanged payload
//   X   valid / ready never X or Z
// `violations` counts failures; each also prints $error.  Verification only.
// =============================================================================
`default_nettype none

module sfn_protocol_checker #(
  parameter int QW   = 8,
  parameter int RW   = 8,
  parameter     NAME = "port"
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          req_valid,
  input  wire logic          req_ready,
  input  wire logic [QW-1:0] req_payload,
  input  wire logic          rsp_valid,
  input  wire logic          rsp_ready,
  input  wire logic [RW-1:0] rsp_payload,
  output int                 violations
);
  logic          q_hold, r_hold;
  logic [QW-1:0] q_pay;
  logic [RW-1:0] r_pay;

  initial violations = 0;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_hold <= 1'b0;
      r_hold <= 1'b0;
    end else begin
      if ($isunknown({req_valid, req_ready, rsp_valid, rsp_ready})) begin
        $error("%s: X/Z on a handshake signal", NAME);
        violations <= violations + 1;
      end
      if (q_hold && (!req_valid || req_payload !== q_pay)) begin
        $error("%s: R2 request changed or withdrawn while held", NAME);
        violations <= violations + 1;
      end
      if (r_hold && (!rsp_valid || rsp_payload !== r_pay)) begin
        $error("%s: R4 response changed or withdrawn while held", NAME);
        violations <= violations + 1;
      end
      q_hold <= req_valid && !req_ready;
      q_pay  <= req_payload;
      r_hold <= rsp_valid && !rsp_ready;
      r_pay  <= rsp_payload;
    end
  end
endmodule

`default_nettype wire
