// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_tb_sfb2_mem -- SFB2 slave memory model (verification only)
//
// A pipelined, strictly in-order SFB2 slave (SFB2 R5): up to Q requests in
// flight, each answered no earlier than its latency, responses held under
// back-pressure.  Same plusargs and memory initialisation as sfn_tb_target
// (+tbp, +lat_min, +lat_max, +errwin, +seed).  Used behind sfn_sfb2_tgt_bridge
// to verify the bridge in the full testbench (tb_noc -GTGT_SFB2=1).
// =============================================================================
`default_nettype none

module sfn_tb_sfb2_mem #(
  parameter int  T  = 0,
  parameter int  AW = 32,
  parameter int  DW = 32,
  parameter int  Q  = 4,
  localparam int SB  = DW / 8,
  localparam int OFF = $clog2(SB)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          req_valid,
  output logic               req_ready,
  input  wire logic          req_write,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [AW-1:0] req_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [DW-1:0] req_wdata,
  input  wire logic [SB-1:0] req_wstrb,
  output logic               rsp_valid,
  input  wire logic          rsp_ready,
  output logic [DW-1:0]      rsp_rdata,
  output logic               rsp_error,
  output int                 n_pending
);
`include "sfn_tb_common.svh"

  function automatic logic [DW-1:0] tb_mem_init(input int t, input int w);
    logic [DW-1:0] v;
    begin
      for (int k = 0; k < DW / 32; k++)
        v[k*32 +: 32] = seed_mix(32'(t * 4096 + w), 32'(k + 7));
      tb_mem_init = v;
    end
  endfunction

  logic [DW-1:0] mem [1024];
  initial for (int w = 0; w < 1024; w++) mem[w] = tb_mem_init(T, w);

  int c_bp, c_lmin, c_lmax, c_errwin;
  logic [31:0] rng;
  initial begin
    int s;
    s = 1; void'($value$plusargs("seed=%d", s));
    rng = seed_mix(32'(s), 32'(2000 + T));
    c_bp = 0;     void'($value$plusargs("tbp=%d", c_bp));
    c_lmin = 1;   void'($value$plusargs("lat_min=%d", c_lmin));
    c_lmax = 1;   void'($value$plusargs("lat_max=%d", c_lmax));
    c_errwin = 0; void'($value$plusargs("errwin=%d", c_errwin));
    if (c_lmin < 1) c_lmin = 1;
    if (c_lmax < c_lmin) c_lmax = c_lmin;
  end
  function automatic int rnd(input int n);
    begin
      rng = xs32(rng);
      rnd = (n <= 1) ? 0 : int'(rng % 32'(n));
    end
  endfunction

  // in-order FIFO of accepted requests
  logic          f_w   [Q];
  logic [9:0]    f_a   [Q];
  logic [DW-1:0] f_d   [Q];
  logic [SB-1:0] f_s   [Q];
  int            f_rdy [Q];
  int            rd, wr, cnt, cyc;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd = 0; wr = 0; cnt = 0; cyc = 0;
      req_ready <= 1'b0;
      rsp_valid <= 1'b0;
      rsp_rdata <= '0;
      rsp_error <= 1'b0;
    end else begin
      cyc = cyc + 1;
      if (req_valid && req_ready) begin
        f_w[wr]   = req_write;
        f_a[wr]   = req_addr[OFF +: 10];
        f_d[wr]   = req_wdata;
        f_s[wr]   = req_wstrb;
        f_rdy[wr] = cyc + c_lmin - 1 + rnd(c_lmax - c_lmin + 1);
        wr = (wr + 1) % Q;
        cnt = cnt + 1;
      end
      if (rsp_valid && rsp_ready) begin
        rd = (rd + 1) % Q;
        cnt = cnt - 1;
      end
      if (!rsp_valid || rsp_ready) begin
        rsp_valid <= 1'b0;
        // the head entry (the oldest not yet answered) is at rd once the previous response retired
        if (cnt > 0 && f_rdy[rd] <= cyc) begin
          logic err;
          err = (c_errwin != 0) && (f_a[rd] >= 10'd1008);
          rsp_valid <= 1'b1;
          rsp_error <= err;
          rsp_rdata <= (!f_w[rd] && !err) ? mem[f_a[rd]] : '0;
          if (f_w[rd] && !err)
            for (int b = 0; b < SB; b++) if (f_s[rd][b]) mem[f_a[rd]][b*8 +: 8] = f_d[rd][b*8 +: 8];
        end
      end
      req_ready <= (cnt < Q) && (rnd(1000) >= c_bp);
    end
  end
  assign n_pending = cnt;
endmodule

`default_nettype wire
