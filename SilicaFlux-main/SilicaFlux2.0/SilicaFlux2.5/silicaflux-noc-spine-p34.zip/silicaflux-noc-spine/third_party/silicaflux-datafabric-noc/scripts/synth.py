#!/usr/bin/env python3
"""Technology-independent synthesis (same method as DataFabric, for comparability).

Yosys 0.33 generic flow: synth -flatten, techmap, `abc -g cmos2` (NAND/NOR/NOT + flops),
`stat -tech cmos` (transistor estimate; NAND2-eq = transistors / 4), `ltp -noff`
(longest topological path in gates: a logic-depth PROXY, not a timing number).
No PDK / Liberty is available: no area in um^2, no frequency, no power is claimed.
Writes reports/synth.{json,md}.
"""
import json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RTL = [os.path.join(ROOT, l.strip()) for l in open(os.path.join(ROOT, "files_rtl.f")) if l.strip()]
TP = os.path.join(ROOT, "third_party", "datafabric", "rtl", "interconnect")
DF = [os.path.join(TP, f) for f in ("sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv",
                                    "sfb_error_slave.sv", "sfb_crossbar.sv", "sfb_shared_bus.sv")]
OUT = os.path.join(ROOT, "build", "synth")

def windows(nt, aw=32):
    base = "".join(f"{(1 << (aw - 4)) + (t << 20):0{aw // 4}x}" for t in reversed(range(nt)))
    mask = "".join(f"{((1 << aw) - 1) & ~((1 << 20) - 1):0{aw // 4}x}" for t in reversed(range(nt)))
    return f"{aw*nt}'h{base}", f"{aw*nt}'h{mask}"

def noc(topo, nm, nt, dw=32, idw=2, maxo=4, arb=1, perf=0, mx=None, my=None, fd=4, aw=32, byp=0):
    b, m = windows(nt, aw)
    p = dict(TOPOLOGY=topo, NM=nm, NT=nt, AW=aw, DW=dw, IDW=idw, ARB_MODE=arb, PERF=perf, TGT_BASE=b, TGT_MASK=m,
             RETIRE_BYPASS=byp,
             MAXO_MAX=maxo, MST_MAXO=f"{8*nm}'h" + "".join(f"{maxo:02x}" for _ in range(nm)))
    if topo == 2:
        nn = mx * my
        p.update(MESH_X=mx, MESH_Y=my, FIFO_DEPTH=fd,
                 MST_NODE=f"{8*nm}'h" + "".join(f"{m % nn:02x}" for m in reversed(range(nm))),
                 TGT_NODE=f"{8*nt}'h" + "".join(f"{(nn - 1 - t % nn):02x}" for t in reversed(range(nt))))
    return ("silicaflux_noc", p, RTL)

def sfb(kind, nm, ns, dw=32):
    b, m = windows(ns)
    if kind == "xbar":
        return ("sfb_crossbar", dict(NM=nm, NS=ns, AW=32, DW=dw, ARB_MODE=1, SLV_BASE=b, SLV_MASK=m), DF)
    return ("sfb_shared_bus", dict(NM=nm, NS=ns, AW=32, DW=dw, ARB_MODE=1, SLV_BASE=b, SLV_MASK=m), DF)

def comp(top, params, files):
    return (top, params, [os.path.join(ROOT, "rtl", "noc", "sfn_pkg.sv"),
                          os.path.join(TP, "sfb_arbiter.sv"), os.path.join(TP, "sfb_addr_decoder.sv")] +
            [os.path.join(ROOT, "rtl", "noc", f) for f in files])

JOBS = {
    # ---- SilicaFlux-HPC endpoint set: 4 masters (ControlCore, vector, tensor, DMA) x 6 targets (4 SRAM banks, SPM, periph)
    "ref_sfb2_xbar_m4t6":   ("DataFabric sfb_crossbar 4x6 (SFB2, 1 outstanding/port) -- reference", sfb("xbar", 4, 6)),
    "ref_sfb2_sbus_m4t6":   ("DataFabric sfb_shared_bus 4x6 (SFB2) -- reference", sfb("sbus", 4, 6)),
    "sbus_m4t6":            ("NoC shared bus 4x6, RR, MAXO 4, no counters", noc(0, 4, 6)),
    "xbar_m4t6":            ("NoC crossbar 4x6, RR, MAXO 4, RETIRE_BYPASS 0, no counters  (recommended baseline)", noc(1, 4, 6)),
    "xbar_m4t6_qos":        ("NoC crossbar 4x6, QoS arbitration", noc(1, 4, 6, arb=2)),
    "xbar_m4t6_byp":        ("NoC crossbar 4x6, RETIRE_BYPASS 1 (accept-while-retiring)", noc(1, 4, 6, byp=1)),
    "xbar_m4t6_qos_byp":    ("NoC crossbar 4x6, QoS, RETIRE_BYPASS 1", noc(1, 4, 6, arb=2, byp=1)),
    "xbar_m4t6_maxo1_byp":  ("NoC crossbar 4x6, MAXO 1, RETIRE_BYPASS 1 (SFB2-equivalent)", noc(1, 4, 6, maxo=1, byp=1)),
    "sbus_m4t6_byp":        ("NoC shared bus 4x6, RETIRE_BYPASS 1", noc(0, 4, 6, byp=1)),
    "xbar_m8t8_byp":        ("NoC crossbar 8x8, RETIRE_BYPASS 1", noc(1, 8, 8, byp=1)),
    "xbar_m4t6_maxo1":      ("NoC crossbar 4x6, MAXO 1 (SFB2-like limits)", noc(1, 4, 6, maxo=1)),
    "xbar_m4t6_perf":       ("NoC crossbar 4x6 + counter page", noc(1, 4, 6, perf=1)),
    "mesh3x2_m4t6":         ("NoC 3x2 mesh 4x6, FIFO 4, no counters", noc(2, 4, 6, mx=3, my=2)),
    "mesh3x2_m4t6_fd2":     ("NoC 3x2 mesh 4x6, FIFO 2", noc(2, 4, 6, mx=3, my=2, fd=2)),
    # ---- scaling (endpoints NxN)
    "xbar_m2t2":            ("NoC crossbar 2x2", noc(1, 2, 2)),
    "xbar_m8t8":            ("NoC crossbar 8x8", noc(1, 8, 8)),
    "xbar_m16t16":          ("NoC crossbar 16x16", noc(1, 16, 16)),
    "sbus_m2t2":            ("NoC shared bus 2x2", noc(0, 2, 2)),
    "sbus_m4t4":            ("NoC shared bus 4x4", noc(0, 4, 4)),
    "sbus_m8t8":            ("NoC shared bus 8x8", noc(0, 8, 8)),
    "sbus_m16t16":          ("NoC shared bus 16x16", noc(0, 16, 16)),
    "mesh2x2_m4t4":         ("NoC 2x2 mesh 4x4", noc(2, 4, 4, mx=2, my=2)),
    "xbar_m4t4":            ("NoC crossbar 4x4", noc(1, 4, 4)),
    "mesh3x3_m8t8":         ("NoC 3x3 mesh 8x8", noc(2, 8, 8, mx=3, my=3)),
    "mesh4x4_m16t16":       ("NoC 4x4 mesh 16x16", noc(2, 16, 16, mx=4, my=4)),
    "ref_sfb2_xbar_m8t8":   ("DataFabric sfb_crossbar 8x8 -- reference", sfb("xbar", 8, 8)),
    # ---- data width
    "xbar_m4t6_d64":        ("NoC crossbar 4x6, 64-bit", noc(1, 4, 6, dw=64)),
    "xbar_m4t6_d128":       ("NoC crossbar 4x6, 128-bit", noc(1, 4, 6, dw=128)),
    "mesh3x2_m4t6_d128":    ("NoC 3x2 mesh 4x6, 128-bit", noc(2, 4, 6, mx=3, my=2, dw=128)),
    # ---- components
    "c_mst_port_maxo1":     ("sfn_mst_port, NT 6, IDW 2, MAXO 1", comp("sfn_mst_port", dict(NT=6, MAXO_MAX=1, MAXO=1), ["sfn_mst_port.sv"])),
    "c_mst_port_maxo4":     ("sfn_mst_port, NT 6, IDW 2, MAXO 4", comp("sfn_mst_port", dict(NT=6, MAXO_MAX=4, MAXO=4), ["sfn_mst_port.sv"])),
    "c_mst_port_maxo8_id3": ("sfn_mst_port, NT 6, IDW 3, MAXO 8", comp("sfn_mst_port", dict(NT=6, IDW=3, MAXO_MAX=8, MAXO=8), ["sfn_mst_port.sv"])),
    "c_qos_arbiter_n5":     ("sfn_qos_arbiter, 5 requesters, STARVE 8", comp("sfn_qos_arbiter", dict(N=5, STARVE=8), ["sfn_qos_arbiter.sv"])),
    "c_router_fd4":         ("sfn_router, 5 ports, 53-bit flits, FIFO 4", comp("sfn_router", dict(X=1, Y=1, XW=2, YW=2, FW=51, DST_LSB=47, QOS_LSB=36, DEPTH=4),
                                                                              ["sfn_fifo.sv", "sfn_qos_arbiter.sv", "sfn_arbiter.sv", "sfn_router.sv"])),
    "c_router_fd2":         ("sfn_router, 5 ports, 53-bit flits, FIFO 2", comp("sfn_router", dict(X=1, Y=1, XW=2, YW=2, FW=51, DST_LSB=47, QOS_LSB=36, DEPTH=2),
                                                                              ["sfn_fifo.sv", "sfn_qos_arbiter.sv", "sfn_arbiter.sv", "sfn_router.sv"])),
    "c_ni_tx":              ("sfn_ni_tx (request packetiser)", comp("sfn_ni_tx", dict(FW=51, DW=32, DEPTH=4), ["sfn_fifo.sv", "sfn_ni.sv"])),
    "c_ni_rx":              ("sfn_ni_rx (request depacketiser, FIFO 4)", comp("sfn_ni_rx", dict(FW=51, DW=32, DEPTH=4), ["sfn_fifo.sv", "sfn_ni.sv"])),
    "c_sfb2_tgt_bridge_d4": ("sfn_sfb2_tgt_bridge, DEPTH 4", comp("sfn_sfb2_tgt_bridge", dict(NM=4, DEPTH=4), ["sfn_fifo.sv", "sfn_sfb2_tgt_bridge.sv"])),
    "c_perf_m4t6":          ("sfn_perf counter page, 4 masters x 6 targets", comp("sfn_perf", dict(NM=4, NT=6), ["sfn_perf.sv"])),
}

def parse(txt):
    num = lambda pat: (lambda m: int(m.group(1)) if m else None)(re.search(pat, txt))
    tr = num(r"Estimated number of transistors:\s+(\d+)")
    cells = num(r"Number of cells:\s+(\d+)")
    depth = num(r"Longest topological path in \S+ \(length=(\d+)\)")
    ff = sum(int(n) for n in re.findall(r"\$_\w*DFF\w*\s+(\d+)", txt))
    lat = sum(int(n) for n in re.findall(r"\$_\w*(?:DLATCH|SR)\w*\s+(\d+)", txt))
    return dict(cells=cells, flops=ff, transistors=tr, nand2_eq=round(tr / 4) if tr else None, logic_depth=depth, latches=lat)

def one(name):
    desc, (top, params, files) = JOBS[name]
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    script = (f"read_verilog -sv -DSYNTHESIS {' '.join(files)}; {ch}hierarchy -top {top}; "
              f"synth -flatten -top {top}; techmap; opt -fast; abc -g cmos2; opt_clean; "
              f"tee -o {d}/stat.txt stat -tech cmos; tee -o {d}/ltp.txt ltp -noff")
    r = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys.log"), "-p", script], capture_output=True, text=True,
                       timeout=7200)
    if r.returncode:
        return dict(config=name, description=desc, ok=False, detail=(r.stderr or r.stdout)[-800:])
    res = parse(open(os.path.join(d, "stat.txt")).read() + open(os.path.join(d, "ltp.txt")).read())
    return dict(config=name, description=desc, top=top, params=params, ok=True, **res)

def main():
    sel = sys.argv[1:] or list(JOBS)
    with ThreadPoolExecutor(int(os.environ.get("SYNTH_JOBS", "3"))) as ex:
        res = list(ex.map(one, sel))
    ver = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    if not sys.argv[1:]:
        json.dump(dict(tool=ver, results=res), open(os.path.join(ROOT, "reports", "synth.json"), "w"), indent=1)
        with open(os.path.join(ROOT, "reports", "synth.md"), "w") as f:
            f.write(f"# Synthesis (technology independent)\n\n{ver}; `synth -flatten`, `abc -g cmos2` (NAND/NOR/NOT); "
                    "transistors from `stat -tech cmos`; NAND2-eq = transistors / 4; logic depth = `ltp -noff` gate levels "
                    "(a **proxy, not timing**).  FIFO storage is mapped to flip-flops.  No PDK or Liberty was available: no "
                    "area in um^2, no frequency and no power are claimed.  Generated by `scripts/synth.py`.\n\n"
                    "| config | description | cells | flops | NAND2-eq | logic depth | latches |\n|---|---|---|---|---|---|---|\n")
            for r in res:
                if r["ok"]:
                    f.write(f"| {r['config']} | {r['description']} | {r['cells']} | {r['flops']} | {r['nand2_eq']} | "
                            f"{r['logic_depth']} | {r['latches']} |\n")
                else:
                    f.write(f"| {r['config']} | {r['description']} | **FAILED** | | | | |\n")
    for r in res:
        print(f"{r['config']:24s} " + (f"cells {r['cells']:7d} flops {r['flops']:6d} NAND2-eq {r['nand2_eq']:7d} depth {r['logic_depth']} latches {r['latches']}"
                                      if r["ok"] else "FAILED " + r["detail"][-300:]))
    return 0 if all(r["ok"] for r in res) else 1

if __name__ == "__main__":
    sys.exit(main())
