// Formal harness: sfn_xbar / sfn_sbus switching core, NM = 2, NT = 2, DW = 8, AW = 8, IDW = 1.
// TOPO = 1 crossbar, 0 shared bus; ARB = sfn_pkg::ARB_*.
// Environment: master front ends obey R2 (a presented request is held with its
// payload until accepted; fq_tgt < NT); targets obey R4 (a held response keeps
// its payload); everything else is free (targets may respond at any time with
// any source, including out of range).  Properties:
//   X1 a target request is exactly the presented request of the master named by
//      t_req_src (same payload, that master addresses this target)        -- no corruption / misroute
//   X2 a master is told "accepted" iff exactly one target accepted its request -- conservation, no duplication
//   X3 a response presented to master m comes from a target whose response names m,
//      unchanged, with fr_tgt = that target
//   X4 a target response is consumed iff it is delivered to the master it names,
//      or that source is illegal (bad_src) -- no loss, no duplication
//   X5 R2 at every target port and R4 at every master response channel
module fv_sfn_xbar #(
  parameter int TOPO = 1,
  parameter int ARB  = 1
) (
  input logic        clk,
  input logic [1:0]  fq_valid,
  input logic [1:0]  fq_tgt_lo,          // one bit per master: target index (NT = 2)
  input logic [5:0]  fq_opcode,
  input logic [1:0]  fq_id,
  input logic [5:0]  fq_qos,
  input logic [15:0] fq_addr,
  input logic [15:0] fq_wdata,
  input logic [1:0]  fq_wstrb,
  input logic [1:0]  fr_ready,
  input logic [1:0]  t_req_ready,
  input logic [1:0]  t_rsp_valid,
  input logic [1:0]  t_rsp_src,
  input logic [1:0]  t_rsp_id,
  input logic [5:0]  t_rsp_opcode,
  input logic [3:0]  t_rsp_status,
  input logic [15:0] t_rsp_rdata
);
  localparam int NM = 2, NT = 2, DW = 8, AW = 8, IDW = 1, SB = 1, TW = 2, SRCW = 1;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  wire [3:0] fq_tgt = {1'b0, fq_tgt_lo[1], 1'b0, fq_tgt_lo[0]};
  logic [1:0]  fq_ready, fr_valid, fr_id, t_req_valid, t_req_src, t_req_id, t_rsp_ready, ev_arb_loss, ev_bad_src;
  logic [3:0]  fr_tgt, fr_status;
  logic [5:0]  fr_opcode, t_req_opcode, t_req_qos;
  logic [15:0] fr_rdata, t_req_addr, t_req_wdata;
  logic [1:0]  t_req_wstrb;

  if (TOPO == 1) begin : g_x
    sfn_xbar #(.NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB), .STARVE(2)) dut (
      .clk, .rst_n, .fq_valid, .fq_ready, .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
      .fr_valid, .fr_ready, .fr_tgt, .fr_id, .fr_opcode, .fr_status, .fr_rdata,
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
      .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
      .ev_arb_loss, .ev_bad_src);
  end else begin : g_s
    sfn_sbus #(.NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB), .STARVE(2)) dut (
      .clk, .rst_n, .fq_valid, .fq_ready, .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
      .fr_valid, .fr_ready, .fr_tgt, .fr_id, .fr_opcode, .fr_status, .fr_rdata,
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
      .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
      .ev_arb_loss, .ev_bad_src);
  end

`ifdef FORMAL
  // ------------------------------------------------------------------ history
  logic        v_q;
  logic [1:0]  mq_hold, tr_hold, tq_hold, fr_hold;
  logic [1:0]  q_tgt;   logic [5:0] q_op, q_qos;  logic [1:0] q_id;  logic [15:0] q_addr, q_wd;  logic [1:0] q_ws;
  logic [1:0]  r_src, r_id;  logic [5:0] r_op;  logic [3:0] r_st;  logic [15:0] r_rd;
  logic [5:0]  tq_op_q; logic [1:0] tq_src_q, tq_id_q; logic [15:0] tq_a_q, tq_wd_q;
  logic [3:0]  fr_t_q; logic [1:0] fr_id_q; logic [5:0] fr_op_q; logic [15:0] fr_rd_q;
  initial begin v_q = 1'b0; mq_hold = '0; tr_hold = '0; tq_hold = '0; fr_hold = '0; end
  always_ff @(posedge clk) begin
    v_q <= rst_n;
    mq_hold <= rst_n ? (fq_valid & ~fq_ready) : 2'b00;
    tr_hold <= rst_n ? (t_rsp_valid & ~t_rsp_ready) : 2'b00;
    tq_hold <= rst_n ? (t_req_valid & ~t_req_ready) : 2'b00;
    fr_hold <= rst_n ? (fr_valid & ~fr_ready) : 2'b00;
    q_tgt <= fq_tgt_lo; q_op <= fq_opcode; q_qos <= fq_qos; q_id <= fq_id; q_addr <= fq_addr; q_wd <= fq_wdata; q_ws <= fq_wstrb;
    r_src <= t_rsp_src; r_id <= t_rsp_id; r_op <= t_rsp_opcode; r_st <= t_rsp_status; r_rd <= t_rsp_rdata;
    tq_op_q <= t_req_opcode; tq_src_q <= t_req_src; tq_id_q <= t_req_id; tq_a_q <= t_req_addr; tq_wd_q <= t_req_wdata;
    fr_t_q <= fr_tgt; fr_id_q <= fr_id; fr_op_q <= fr_opcode; fr_rd_q <= fr_rdata;
  end
  // ------------------------------------------------------------------ environment
  always_comb if (rst_n && v_q)
    for (int m = 0; m < 2; m++) begin
      if (mq_hold[m]) assume (fq_valid[m] && fq_tgt_lo[m] == q_tgt[m] && fq_opcode[m*3 +: 3] == q_op[m*3 +: 3] &&
                              fq_qos[m*3 +: 3] == q_qos[m*3 +: 3] && fq_id[m] == q_id[m] && fq_addr[m*8 +: 8] == q_addr[m*8 +: 8] &&
                              fq_wdata[m*8 +: 8] == q_wd[m*8 +: 8] && fq_wstrb[m] == q_ws[m]);
      if (tr_hold[m]) assume (t_rsp_valid[m] && t_rsp_src[m] == r_src[m] && t_rsp_id[m] == r_id[m] &&
                              t_rsp_opcode[m*3 +: 3] == r_op[m*3 +: 3] && t_rsp_status[m*2 +: 2] == r_st[m*2 +: 2] &&
                              t_rsp_rdata[m*8 +: 8] == r_rd[m*8 +: 8]);
    end
  // ------------------------------------------------------------------ properties
  always_comb if (rst_n) begin
    for (int t = 0; t < 2; t++) begin
      if (t_req_valid[t]) begin                                                           // X1
        assert (fq_valid[t_req_src[t]] && fq_tgt_lo[t_req_src[t]] == 1'(t));
        assert (t_req_opcode[t*3 +: 3] == fq_opcode[t_req_src[t]*3 +: 3] && t_req_id[t] == fq_id[t_req_src[t]] &&
                t_req_qos[t*3 +: 3] == fq_qos[t_req_src[t]*3 +: 3] && t_req_addr[t*8 +: 8] == fq_addr[t_req_src[t]*8 +: 8] &&
                t_req_wdata[t*8 +: 8] == fq_wdata[t_req_src[t]*8 +: 8] && t_req_wstrb[t] == fq_wstrb[t_req_src[t]]);
      end
      // X4: consumed iff delivered to the named master (both sources are legal here: NM = 2^SRCW)
      if (t_rsp_valid[t] && t_rsp_ready[t])
        assert (fr_valid[t_rsp_src[t]] && fr_ready[t_rsp_src[t]] && fr_tgt[t_rsp_src[t]*2 +: 2] == 2'(t));
      assert (!ev_bad_src[t]);
    end
    for (int m = 0; m < 2; m++) begin
      // X2: accepted iff exactly one target accepted this master's request
      assert (fq_ready[m] == ((t_req_valid[0] && t_req_ready[0] && t_req_src[0] == 1'(m)) ||
                              (t_req_valid[1] && t_req_ready[1] && t_req_src[1] == 1'(m))));
      assert (!(t_req_valid[0] && t_req_ready[0] && t_req_src[0] == 1'(m) &&
                t_req_valid[1] && t_req_ready[1] && t_req_src[1] == 1'(m)));
      if (fq_valid[m] && fq_ready[m]) assert (t_req_valid[fq_tgt_lo[m]] && t_req_src[fq_tgt_lo[m]] == 1'(m));
      // X3
      if (fr_valid[m]) begin
        assert (fr_tgt[m*2 +: 2] < 2'd2);
        assert (t_rsp_valid[fr_tgt[m*2]] && t_rsp_src[fr_tgt[m*2]] == 1'(m) && fr_id[m] == t_rsp_id[fr_tgt[m*2]] &&
                fr_opcode[m*3 +: 3] == t_rsp_opcode[fr_tgt[m*2]*3 +: 3] && fr_status[m*2 +: 2] == t_rsp_status[fr_tgt[m*2]*2 +: 2] &&
                fr_rdata[m*8 +: 8] == t_rsp_rdata[fr_tgt[m*2]*8 +: 8]);
      end
      if (fr_valid[m] && fr_ready[m]) assert (t_rsp_ready[fr_tgt[m*2]]);
    end
  end
  always_ff @(posedge clk) if (rst_n && v_q)
    for (int i = 0; i < 2; i++) begin                                                       // X5
      if (tq_hold[i]) assert (t_req_valid[i] && t_req_opcode[i*3 +: 3] == tq_op_q[i*3 +: 3] && t_req_src[i] == tq_src_q[i] &&
                              t_req_id[i] == tq_id_q[i] && t_req_addr[i*8 +: 8] == tq_a_q[i*8 +: 8] &&
                              t_req_wdata[i*8 +: 8] == tq_wd_q[i*8 +: 8]);
      if (fr_hold[i]) assert (fr_valid[i] && fr_tgt[i*2 +: 2] == fr_t_q[i*2 +: 2] && fr_id[i] == fr_id_q[i] &&
                              fr_opcode[i*3 +: 3] == fr_op_q[i*3 +: 3] && fr_rdata[i*8 +: 8] == fr_rd_q[i*8 +: 8]);
    end
`endif
endmodule
