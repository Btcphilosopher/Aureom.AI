// Formal harness: sfn_mst_port (NT = 2, IDW = 1, MAXO = 2, DW = 16, AW = 8).
// Target 0 = 0x40/0xC0, target 1 = 0x80/0xC0, access matrix EN, alignment check.
// Environment: the master obeys R2 (a held request keeps valid and payload);
// the switching core obeys R4 on its response channel and is otherwise
// UNCONSTRAINED -- it may present any target index, ID, opcode and status at
// any time (orphans, wrong targets, posted completions for reads ...).
// A reference decoder and a shadow tracker (per ID count + target) are built
// from the port's own handshakes.  Properties:
//   M1 out_cnt == shadow count <= MAXO                                      (O1)
//   M2 a tracked request of ID i goes to the target ID i is outstanding at  (O2)
//   M3 FENCE accepted only with nothing outstanding after this cycle        (O3)
//   M4 a response reaches the master only for an outstanding ID, from the
//      target that ID is outstanding at (or the local responder), never as a
//      posted-write completion; local responses carry 0 data and OKAY for
//      FENCE / DECERR otherwise; a delivered switch response is unchanged
//   M5 a posted completion is retired only for an outstanding ID at its target
//   M6 the request presented to the core is the master's request, decoded as
//      the reference decoder does, and held stable under back-pressure (R2)
//   M7 a held master response is stable (R4)
//   M8 a master handshake to a target coincides with the core handshake
module fv_sfn_mst_port #(
  parameter logic [1:0] EN = 2'b11,
  parameter int         BYP = 0
) (
  input logic        clk,
  input logic        m_req_valid,
  input logic [2:0]  m_req_opcode,
  input logic        m_req_id,
  input logic [2:0]  m_req_qos,
  input logic [7:0]  m_req_addr,
  input logic [15:0] m_req_wdata,
  input logic [1:0]  m_req_wstrb,
  input logic        m_rsp_ready,
  input logic        fq_ready,
  input logic        fr_valid,
  input logic [1:0]  fr_tgt,
  input logic        fr_id,
  input logic [2:0]  fr_opcode,
  input logic [1:0]  fr_status,
  input logic [15:0] fr_rdata
);
  localparam logic [1:0] LOCAL = 2'd2;
  localparam int MAXO = 2;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic        m_req_ready, m_rsp_valid, fq_valid, fr_ready;
  logic        m_rsp_id, fq_id;
  logic [2:0]  m_rsp_opcode, fq_opcode, fq_qos;
  logic [1:0]  m_rsp_status, fq_tgt, out_cnt;
  logic [15:0] m_rsp_rdata, fq_wdata;
  logic [7:0]  fq_addr;
  logic [1:0]  fq_wstrb;
  logic        id_idle, ev_blk_out, ev_blk_id, ev_blk_fence, ev_decerr, ev_posted_done, ev_posted_err, ev_orphan;

  sfn_mst_port #(
    .NT(2), .AW(8), .DW(16), .IDW(1), .MAXO_MAX(MAXO), .MAXO(MAXO), .CHECK_ALIGN(1), .RETIRE_BYPASS(BYP),
    .TGT_BASE({8'h80, 8'h40}), .TGT_MASK({8'hC0, 8'hC0}), .EN(EN)
  ) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_qos, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .fq_valid, .fq_ready, .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
    .fr_valid, .fr_ready, .fr_tgt, .fr_id, .fr_opcode, .fr_status, .fr_rdata,
    .out_cnt, .id_idle, .ev_blk_out, .ev_blk_id, .ev_blk_fence, .ev_decerr, .ev_posted_done, .ev_posted_err,
    .ev_orphan
  );

`ifdef FORMAL
  // ------------------------------------------------------------------ reference decoder
  logic [1:0] ref_tgt;
  always_comb begin
    ref_tgt = LOCAL;
    if ((m_req_opcode == sfn_pkg::OP_READ || m_req_opcode == sfn_pkg::OP_WRITE ||
         m_req_opcode == sfn_pkg::OP_WRITE_POSTED) && !m_req_addr[0]) begin
      if ((m_req_addr & 8'hC0) == 8'h40 && EN[0]) ref_tgt = 2'd0;
      else if ((m_req_addr & 8'hC0) == 8'h80 && EN[1]) ref_tgt = 2'd1;
    end
  end
  wire post_drop = (ref_tgt == LOCAL) && (m_req_opcode == sfn_pkg::OP_WRITE_POSTED);
  wire req_hs    = m_req_valid && m_req_ready;
  wire track     = req_hs && !post_drop;
  wire rsp_hs    = m_rsp_valid && m_rsp_ready;
  wire fr_deliv  = fr_valid && fr_ready && !ev_orphan && !ev_posted_done;   // switch response delivered now
  wire ret       = rsp_hs || ev_posted_done;
  wire ret_id    = rsp_hs ? m_rsp_id : fr_id;

  // ------------------------------------------------------------------ shadow tracker
  logic [1:0] s_cnt [2];
  logic [1:0] s_tgt [2];
  logic [2:0] s_out;
  // ------------------------------------------------------------------ history for R2 / R4
  logic        v_q, mq_hold, fr_hold, fq_hold, mr_hold;
  logic [2:0]  mq_op;  logic mq_id;  logic [2:0] mq_qos;  logic [7:0] mq_addr;  logic [15:0] mq_wd;  logic [1:0] mq_ws;
  logic [1:0]  fr_t_q; logic fr_id_q; logic [2:0] fr_op_q; logic [1:0] fr_st_q; logic [15:0] fr_rd_q;
  logic [1:0]  fq_t_q; logic [2:0] fq_op_q; logic fq_id_q; logic [7:0] fq_a_q; logic [15:0] fq_wd_q;
  logic        mr_id_q; logic [2:0] mr_op_q; logic [1:0] mr_st_q; logic [15:0] mr_rd_q;
  initial begin
    s_cnt[0] = '0; s_cnt[1] = '0; s_tgt[0] = '0; s_tgt[1] = '0; s_out = '0;
    v_q = 1'b0; mq_hold = 1'b0; fr_hold = 1'b0; fq_hold = 1'b0; mr_hold = 1'b0;
  end
  always_ff @(posedge clk) begin
    v_q <= rst_n;
    if (!rst_n) begin
      s_cnt[0] <= '0; s_cnt[1] <= '0; s_out <= '0;
      mq_hold <= 1'b0; fr_hold <= 1'b0; fq_hold <= 1'b0; mr_hold <= 1'b0;
    end else begin
      for (int i = 0; i < 2; i++)
        s_cnt[i] <= s_cnt[i] + 2'(track && m_req_id == 1'(i)) - 2'(ret && ret_id == 1'(i));
      if (track) s_tgt[m_req_id] <= ref_tgt;
      s_out <= s_out + 3'(track) - 3'(ret);
      mq_hold <= m_req_valid && !m_req_ready;
      mq_op <= m_req_opcode; mq_id <= m_req_id; mq_qos <= m_req_qos; mq_addr <= m_req_addr; mq_wd <= m_req_wdata; mq_ws <= m_req_wstrb;
      fr_hold <= fr_valid && !fr_ready;
      fr_t_q <= fr_tgt; fr_id_q <= fr_id; fr_op_q <= fr_opcode; fr_st_q <= fr_status; fr_rd_q <= fr_rdata;
      fq_hold <= fq_valid && !fq_ready;
      fq_t_q <= fq_tgt; fq_op_q <= fq_opcode; fq_id_q <= fq_id; fq_a_q <= fq_addr; fq_wd_q <= fq_wdata;
      mr_hold <= m_rsp_valid && !m_rsp_ready;
      mr_id_q <= m_rsp_id; mr_op_q <= m_rsp_opcode; mr_st_q <= m_rsp_status; mr_rd_q <= m_rsp_rdata;
    end
  end

  // ------------------------------------------------------------------ environment
  always_comb if (rst_n && v_q) begin
    if (mq_hold) assume (m_req_valid && m_req_opcode == mq_op && m_req_id == mq_id && m_req_qos == mq_qos &&
                         m_req_addr == mq_addr && m_req_wdata == mq_wd && m_req_wstrb == mq_ws);
    if (fr_hold) assume (fr_valid && fr_tgt == fr_t_q && fr_id == fr_id_q && fr_opcode == fr_op_q &&
                         fr_status == fr_st_q && fr_rdata == fr_rd_q);
  end

  // ------------------------------------------------------------------ properties
  logic [1:0] c_after;
  always_comb begin
    c_after = s_cnt[m_req_id] - 2'(ret && ret_id == m_req_id);
  end
  always_comb if (rst_n) begin
    assert (3'(out_cnt) == s_out && s_out <= 3'(MAXO));                               // M1
    assert (!(rsp_hs && ev_posted_done));
    if (track && c_after != '0) assert (s_tgt[m_req_id] == ref_tgt);                  // M2
    if (req_hs && m_req_opcode == sfn_pkg::OP_FENCE) assert (s_out - 3'(ret) == '0);  // M3
    if (m_rsp_valid) assert (m_rsp_opcode != sfn_pkg::OP_WRITE_POSTED);               // M4
    if (rsp_hs) begin
      assert (s_cnt[m_rsp_id] != '0);
      if (fr_deliv) begin
        assert (s_tgt[fr_id] == fr_tgt && m_rsp_id == fr_id && m_rsp_opcode == fr_opcode &&
                m_rsp_status == fr_status && m_rsp_rdata == fr_rdata);
      end else begin
        assert (s_tgt[m_rsp_id] == LOCAL && m_rsp_rdata == '0);
        assert (m_rsp_status == ((m_rsp_opcode == sfn_pkg::OP_FENCE) ? sfn_pkg::ST_OKAY : sfn_pkg::ST_DECERR));
      end
    end
    if (ev_posted_done) assert (s_cnt[fr_id] != '0 && s_tgt[fr_id] == fr_tgt && fr_tgt != LOCAL);   // M5
    if (fq_valid) assert (fq_tgt == ref_tgt && ref_tgt != LOCAL && fq_opcode == m_req_opcode &&      // M6
                          fq_id == m_req_id && fq_addr == m_req_addr && fq_wdata == m_req_wdata && m_req_valid);
    if (req_hs && ref_tgt != LOCAL) assert (fq_valid && fq_ready);                                   // M8
    if (fq_valid && fq_ready) assert (req_hs);
  end
  always_ff @(posedge clk) if (rst_n && v_q) begin
    if (fq_hold) assert (fq_valid && fq_tgt == fq_t_q && fq_opcode == fq_op_q && fq_id == fq_id_q &&
                         fq_addr == fq_a_q && fq_wdata == fq_wd_q);                                  // M6 (R2)
    if (mr_hold) assert (m_rsp_valid && m_rsp_id == mr_id_q && m_rsp_opcode == mr_op_q &&
                         m_rsp_status == mr_st_q && m_rsp_rdata == mr_rd_q);                          // M7 (R4)
  end
`endif
endmodule
