// Formal harness: sfn_qos_arbiter (N requesters, STARVE).
// Environment: a requester keeps requesting, with an unchanged QoS level, until
// its grant is accepted (SFB3 R2); accept / stall only for a valid grant and
// mutually exclusive.  QoS levels are otherwise free.  Properties:
//   Q1 grant one-hot or zero, only to a requester, consistent with grant_idx
//   Q2 work conserving: some request -> some grant
//   Q3 grant lock: a stalled grant is repeated while still requested
//   Q4 bounded waiting: while requester i waits, at most STARVE + N - 1
//      acceptances go to other requesters (no starvation, any QoS pattern)
//   Q5 urgent (aged) requesters win over non-urgent ones
//   Q6 without urgency or lock, the winner has the highest QoS level requesting
module fv_sfn_qos_arbiter #(
  parameter int N      = 3,
  parameter int STARVE = 2
) (
  input logic                         clk,
  input logic [N-1:0]                 req,
  input logic [N*sfn_pkg::QOSW-1:0]   qos,
  input logic                         stall_in,
  input logic                         accept_in
);
  localparam int QW = sfn_pkg::QOSW;
  localparam int IW = sfn_pkg::clog2c(N);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic [N-1:0]  grant, urgent;
  logic [IW-1:0] grant_idx;
  logic          grant_valid;
  wire stall  = grant_valid && stall_in && !accept_in;
  wire accept = grant_valid && accept_in;

  sfn_qos_arbiter #(.N(N), .STARVE(STARVE)) dut (
    .clk, .rst_n, .req, .qos, .stall, .accept, .grant, .grant_idx, .grant_valid, .urgent);

`ifdef FORMAL
  logic [N-1:0]    req_q, grant_q;
  logic [N*QW-1:0] qos_q;
  logic            acc_q, stall_q, valid_q;
  logic [5:0]      others [0:N-1];
  initial begin req_q = '0; acc_q = 1'b0; stall_q = 1'b0; valid_q = 1'b0; grant_q = '0; qos_q = '0; end
  always_ff @(posedge clk) begin
    req_q <= req; acc_q <= accept; stall_q <= stall; valid_q <= rst_n; grant_q <= grant; qos_q <= qos;
    for (int i = 0; i < N; i++) begin
      if (!rst_n || !req[i] || (accept && grant[i])) others[i] <= 6'd0;
      else if (accept && !grant[i] && others[i] != 6'h3F) others[i] <= others[i] + 6'd1;
    end
  end
  // environment: requests (and their QoS) held until accepted
  always_comb if (valid_q)
    for (int i = 0; i < N; i++)
      if (req_q[i] && !(acc_q && grant_q[i])) begin
        assume (req[i]);
        assume (qos[i*QW +: QW] == qos_q[i*QW +: QW]);
      end

  wire lock_now = valid_q && stall_q && ((req & grant_q) != '0);
  logic [QW-1:0] top;
  always_comb begin
    top = '0;
    for (int i = 0; i < N; i++) if (req[i] && qos[i*QW +: QW] > top) top = qos[i*QW +: QW];
  end

  always_comb if (rst_n) begin
    assert ((grant & ~req) == '0);                                       // Q1
    assert ((grant & (grant - 1'b1)) == '0);
    assert (grant_valid == (grant != '0));
    if (grant_valid) assert (grant == (N'(1) << grant_idx));
    assert ((req == '0) || grant_valid);                                 // Q2
    for (int i = 0; i < N; i++) assert (others[i] <= 6'(STARVE + N - 1));  // Q4
    if (grant_valid && !lock_now && ((urgent & req) != '0))
      assert ((urgent & grant) != '0);                                   // Q5
    if (grant_valid && !lock_now && ((urgent & req) == '0))
      assert (qos[grant_idx*QW +: QW] == top);                           // Q6
  end
  always_ff @(posedge clk) if (rst_n && valid_q)
    if (stall_q && (req & grant_q) != '0) assert (grant == grant_q);      // Q3
`endif
endmodule
