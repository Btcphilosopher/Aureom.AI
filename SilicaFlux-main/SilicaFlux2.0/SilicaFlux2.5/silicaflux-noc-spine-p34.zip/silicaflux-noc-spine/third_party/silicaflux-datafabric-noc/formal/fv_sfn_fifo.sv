// Formal harness: sfn_fifo (any DEPTH, including non-powers of two).
// Environment: none (inputs are free; a push without in_ready / pop without
// out_valid simply does not happen).  Properties:
//   F1 count equals pushes - pops (shadow counter), never above DEPTH
//   F2 in_ready <=> not full (or, PASS_FULL, full with the head leaving), out_valid <=>
//      not empty -- no overflow / underflow
//   F3 order and integrity: an arbitrarily chosen pushed element reaches the head
//      after exactly the elements ahead of it, with its data unchanged
//   F4 head stability: a held head (out_valid && !out_ready) is unchanged next cycle
module fv_sfn_fifo #(
  parameter int W         = 4,
  parameter int DEPTH     = 3,
  parameter int PASS_FULL = 0
) (
  input logic         clk,
  input logic         in_valid,
  input logic [W-1:0] in_data,
  input logic         out_ready,
  input logic         track
);
  localparam int CNTW = sfn_pkg::clog2c(DEPTH + 1);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic            in_ready, out_valid;
  logic [W-1:0]    out_data;
  logic [CNTW-1:0] count;
  sfn_fifo #(.W(W), .DEPTH(DEPTH), .PASS_FULL(PASS_FULL)) dut (
    .clk, .rst_n, .in_valid, .in_ready, .in_data, .out_valid, .out_ready, .out_data, .count);

`ifdef FORMAL
  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;
  logic [CNTW:0]   m_cnt;
  logic            trk_v;
  logic [W-1:0]    trk_d;
  logic [CNTW:0]   trk_pos;
  logic            held_q;
  logic [W-1:0]    head_q;
  initial begin m_cnt = '0; trk_v = 1'b0; trk_d = '0; trk_pos = '0; held_q = 1'b0; head_q = '0; end
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      m_cnt <= '0; trk_v <= 1'b0; held_q <= 1'b0;
    end else begin
      m_cnt <= m_cnt + (CNTW+1)'(push) - (CNTW+1)'(pop);
      if (trk_v && pop) begin
        if (trk_pos == '0) trk_v <= 1'b0;
        else               trk_pos <= trk_pos - 1'b1;
      end
      if (!trk_v && push && track) begin
        trk_v   <= 1'b1;
        trk_d   <= in_data;
        trk_pos <= m_cnt - (CNTW+1)'(pop);
      end
      held_q <= out_valid && !out_ready;
      head_q <= out_data;
    end
  end
  always_comb if (rst_n) begin
    assert ((CNTW+1)'(count) == m_cnt);                       // F1
    assert (m_cnt <= (CNTW+1)'(DEPTH));
    assert (in_ready == ((m_cnt < (CNTW+1)'(DEPTH)) || (PASS_FULL != 0 && out_ready && m_cnt != '0)));  // F2
    assert (out_valid == (m_cnt != '0));
    if (trk_v) assert (trk_pos < m_cnt);                        // the tracked element is inside the FIFO
    if (trk_v && trk_pos == '0) assert (out_valid && out_data == trk_d);   // F3
  end
  always_ff @(posedge clk) if (rst_n && held_q) assert (out_valid && out_data == head_q);   // F4
`endif
endmodule
