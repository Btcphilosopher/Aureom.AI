#!/usr/bin/env python3
"""DataFabric-NoC formal runner (no SymbiYosys needed; same method as DataFabric).

For every job: Yosys (read -formal, prep, flatten, async2sync, dffunmap), then
  * BMC  : yosys-smtbmc + z3 to the given depth
  * prove: AIGER + ABC PDR (unbounded)
`expect FAIL` jobs are non-vacuity checks: the same harness on one deliberately
broken RTL file must produce a counterexample.
Writes reports/formal.{json,md}; exit 1 if any job is not as expected.
usage: run_formal.py [job ...]
"""
import json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(ROOT, "build", "formal")
R = lambda *f: [os.path.join(ROOT, "rtl", "noc", x) for x in f]
TP = lambda *f: [os.path.join(ROOT, "third_party", "datafabric", "rtl", "interconnect", x) for x in f]
H = lambda f: os.path.join(HERE, f)
SOLVER = os.environ.get("SMT_SOLVER", "z3")
# z3 from PyPI (z3-solver, 5.x) works with yosys-smtbmc 0.33; the Ubuntu z3 4.8.12 package hangs.
# Put the directory of the preferred binary first on PATH (override with Z3_DIR).
Z3_DIR = os.environ.get("Z3_DIR", "/usr/local/bin")
ENV = dict(os.environ, PATH=Z3_DIR + os.pathsep + os.environ.get("PATH", ""))
PDR_TIMEOUT = int(os.environ.get("PDR_TIMEOUT", "1200"))

PKG = R("sfn_pkg.sv")
FIFO = PKG + R("sfn_fifo.sv") + [H("fv_sfn_fifo.sv")]
QARB = PKG + R("sfn_qos_arbiter.sv") + [H("fv_sfn_qos_arbiter.sv")]
MPORT = PKG + TP("sfb_arbiter.sv", "sfb_addr_decoder.sv") + R("sfn_mst_port.sv") + [H("fv_sfn_mst_port.sv")]
CORE = PKG + TP("sfb_arbiter.sv") + R("sfn_onehot_mux.sv", "sfn_qos_arbiter.sv", "sfn_arbiter.sv", "sfn_xbar.sv",
                                       "sfn_sbus.sv") + [H("fv_sfn_xbar.sv")]

# name, top, files, params, bmc depth, prove, options
JOBS = [
    ("fifo_d1", "fv_sfn_fifo", FIFO, {"W": 4, "DEPTH": 1}, 16, True, {}),
    ("fifo_d3", "fv_sfn_fifo", FIFO, {"W": 4, "DEPTH": 3}, 20, True, {}),
    ("fifo_d4", "fv_sfn_fifo", FIFO, {"W": 4, "DEPTH": 4}, 20, True, {}),
    ("fifo_d1_pass", "fv_sfn_fifo", FIFO, {"W": 4, "DEPTH": 1, "PASS_FULL": 1}, 16, True, {}),
    ("fifo_d3_pass", "fv_sfn_fifo", FIFO, {"W": 4, "DEPTH": 3, "PASS_FULL": 1}, 20, True, {}),
    ("qos_arb_n3_s2", "fv_sfn_qos_arbiter", QARB, {"N": 3, "STARVE": 2}, 24, True, {}),
    ("qos_arb_n4_s1", "fv_sfn_qos_arbiter", QARB, {"N": 4, "STARVE": 1}, 20, True, {}),
    ("qos_arb_n3_s0", "fv_sfn_qos_arbiter", QARB, {"N": 3, "STARVE": 0}, 20, True, {}),
    ("qos_arb_n5_s4", "fv_sfn_qos_arbiter", QARB, {"N": 5, "STARVE": 4}, 16, True, {}),
    ("mst_port_full", "fv_sfn_mst_port", MPORT, {"EN": "2'b11"}, 16, True, {}),
    ("mst_port_denied", "fv_sfn_mst_port", MPORT, {"EN": "2'b01"}, 16, True, {}),
    ("mst_port_bypass", "fv_sfn_mst_port", MPORT, {"EN": "2'b11", "BYP": 1}, 16, True, {}),
    ("xbar_rr", "fv_sfn_xbar", CORE, {"TOPO": 1, "ARB": 1}, 12, True, {}),
    ("xbar_fixed", "fv_sfn_xbar", CORE, {"TOPO": 1, "ARB": 0}, 12, True, {}),
    ("xbar_qos", "fv_sfn_xbar", CORE, {"TOPO": 1, "ARB": 2}, 12, True, {}),
    ("sbus_rr", "fv_sfn_xbar", CORE, {"TOPO": 0, "ARB": 1}, 12, True, {}),
    ("sbus_qos", "fv_sfn_xbar", CORE, {"TOPO": 0, "ARB": 2}, 12, True, {}),
    # ---------------------------------------------------------------- non-vacuity (expect a counterexample)
    ("mut_fifo_overflow", "fv_sfn_fifo", FIFO, {"W": 4, "DEPTH": 3}, 12, False,
     {"expect": "FAIL", "mutate": ("sfn_fifo.sv", "assign in_ready  = (cnt_q != CNTW'(DEPTH)) || ((PASS_FULL != 0) && out_ready);",
                                    "assign in_ready  = 1'b1;"),
      "note": "FIFO accepts when full"}),
    ("mut_fifo_rd_ptr", "fv_sfn_fifo", FIFO, {"W": 4, "DEPTH": 3}, 12, False,
     {"expect": "FAIL", "mutate": ("sfn_fifo.sv", "if (p == PW'(DEPTH - 1)) inc = '0;", "if (p == PW'(DEPTH)) inc = '0;"),
      "note": "pointer wraps one entry late (non-power-of-two depth)"}),
    ("mut_qos_frozen_ptr", "fv_sfn_qos_arbiter", QARB, {"N": 3, "STARVE": 1}, 16, False,
     {"expect": "FAIL", "mutate": ("sfn_qos_arbiter.sv", "prio_q <= (grant_idx == IW'(N - 1)) ? '0 : grant_idx + IW'(1);",
                                   "prio_q <= prio_q;"), "note": "round-robin pointer frozen -> starvation"}),
    ("mut_qos_no_aging", "fv_sfn_qos_arbiter", QARB, {"N": 3, "STARVE": 2}, 16, False,
     {"expect": "FAIL", "mutate": ("sfn_qos_arbiter.sv", "urgent[i] = (age_q[i*AGW +: AGW] >= AGW'(STARVE));", "urgent[i] = 1'b0;"),
      "note": "aging removed -> low QoS level starves"}),
    ("mut_qos_no_lock", "fv_sfn_qos_arbiter", QARB, {"N": 3, "STARVE": 2}, 12, False,
     {"expect": "FAIL", "mutate": ("sfn_qos_arbiter.sv", "if (lock_q && req[lock_idx_q]) begin", "if (1'b0) begin"),
      "note": "grant lock removed"}),
    ("mut_port_no_id_rule", "fv_sfn_mst_port", MPORT, {"EN": "2'b11"}, 12, False,
     {"expect": "FAIL", "mutate": ("sfn_mst_port.sv", "wire id_ok    = (r_idc == '0) ||", "wire id_ok    = 1'b1 || (r_idc == '0) ||"),
      "note": "O2 removed"}),
    ("mut_port_orphan", "fv_sfn_mst_port", MPORT, {"EN": "2'b11"}, 12, False,
     {"expect": "FAIL", "mutate": ("sfn_mst_port.sv", "(fr_idc != '0) && (fr_idt == fr_tgt)", "(fr_idc != '0)"),
      "note": "orphan check ignores the target"}),
    ("mut_port_fence", "fv_sfn_mst_port", MPORT, {"EN": "2'b11"}, 12, False,
     {"expect": "FAIL", "mutate": ("sfn_mst_port.sv", "wire fence_ok = !is_fence ||", "wire fence_ok = 1'b1 || !is_fence ||"),
      "note": "O3 removed"}),
    ("mut_xbar_rsp_src", "fv_sfn_xbar", CORE, {"TOPO": 1, "ARB": 1}, 8, False,
     {"expect": "FAIL", "mutate": ("sfn_xbar.sv", "t_rsp_valid[gt] && (t_rsp_src[gt*SRCW +: SRCW] == SRCW'(gm))", "t_rsp_valid[gt]"),
      "note": "response steered regardless of source"}),
    ("mut_xbar_no_lock", "fv_sfn_xbar", CORE, {"TOPO": 1, "ARB": 1}, 10, False,
     {"expect": "FAIL", "mutate": ("sfn_xbar.sv", ".stall(t_req_valid[gt] && !t_req_ready[gt]),", ".stall(1'b0),"),
      "note": "arbiter not told about target back-pressure (no grant lock)"}),
    ("mut_sbus_ready", "fv_sfn_xbar", CORE, {"TOPO": 0, "ARB": 1}, 8, False,
     {"expect": "FAIL", "mutate": ("sfn_sbus.sv", "if (sel_t == TW'(t)) sel_ready = t_req_ready[t];", "if (t == 0) sel_ready = t_req_ready[t];"),
      "note": "shared bus uses the wrong target ready"}),
]
EXTRA = os.path.join(HERE, "jobs_mesh.py")
if os.path.exists(EXTRA):
    exec(open(EXTRA).read())


def apply_mutation(name, files, mut):
    if not mut:
        return files
    d = os.path.join(OUT, name, "mut"); os.makedirs(d, exist_ok=True)
    out = []
    for f in files:
        if os.path.basename(f) == mut[0]:
            src = open(f).read(); assert mut[1] in src, (name, mut[1])
            g = os.path.join(d, mut[0]); open(g, "w").write(src.replace(mut[1], mut[2], 1)); out.append(g)
        else:
            out.append(f)
    return out


def yosys_prep(name, top, files, params):
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    common = (f"read_verilog -sv -formal -DFORMAL -DSYNTHESIS {' '.join(files)}; {ch}prep -top {top}; "
              f"flatten; async2sync; dffunmap; setundef -undriven -zero; opt_clean; ")
    smt, aig = os.path.join(d, "model.smt2"), os.path.join(d, "model.aig")
    r1 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_smt.log"), "-p", common + f"write_smt2 -wires {smt}"],
                        capture_output=True, text=True)
    r2 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_aig.log"), "-p",
                         common + "memory_map; opt -full -nosdff -nodffe; techmap; opt -fast -nosdff -nodffe; dffunmap; "
                         f"abc -g AND -fast; opt_clean; write_aiger -I -B -zinit -no-startoffset -map {d}/model.aim {aig}"],
                        capture_output=True, text=True)
    return d, smt, aig, r1, r2


def run_job(job):
    try:
        return run_job_(job)
    except Exception as e:  # a broken job must not abort the whole campaign
        return dict(job=job[0], top=job[1], params=job[3], expect=job[6].get("expect", "PASS"), note=job[6].get("note", ""),
                    bmc="ERROR", smtbmc="ERROR", prove="ERROR", ok=False, secs=0, detail=repr(e)[-600:])


def run_job_(job):
    name, top, files, params, depth, prove, opt = job
    t0 = time.time()
    files = apply_mutation(name, files, opt.get("mutate"))
    d, smt, aig, r1, r2 = yosys_prep(name, top, files, params)
    row = dict(job=name, top=top, params=params, expect=opt.get("expect", "PASS"), note=opt.get("note", ""))
    if r1.returncode or r2.returncode:
        row.update(bmc="ERROR", prove="ERROR", ok=False, secs=0, detail=(r1.stderr + r2.stderr)[-1500:])
        return row
    # BMC, engine 1: ABC bmc3 (bit level, on the same AIGER model PDR proves) to the full depth
    try:
        b = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; bmc3 -F {depth} -T 1800 -v"],
                           capture_output=True, text=True, cwd=d, timeout=2400)
        open(os.path.join(d, "bmc.log"), "w").write(b.stdout + b.stderr)
        m = re.search(r"No output asserted in (\d+) frames", b.stdout)
        row["bmc"] = ("FAIL (counterexample)" if "was asserted" in b.stdout else
                      f"PASS depth {m.group(1)}" if m else "ERROR")
        if row["bmc"] == "ERROR":
            row["detail"] = (b.stdout + b.stderr)[-800:]
    except subprocess.TimeoutExpired:
        row["bmc"] = f"TIMEOUT depth {depth}"
    # BMC, engine 2: yosys-smtbmc + z3 (word level, independent tool chain), shorter depth
    sdepth = min(depth, opt.get("smt_depth", 8))
    try:
        b = subprocess.run(["yosys-smtbmc", "-s", SOLVER, "--presat", "-t", str(sdepth), smt],
                           capture_output=True, text=True, cwd=d, timeout=opt.get("smt_timeout", 900), env=ENV)
        open(os.path.join(d, "smtbmc.log"), "w").write(b.stdout + b.stderr)
        row["smtbmc"] = (f"PASS depth {sdepth}" if b.returncode == 0 and "Status: PASSED" in b.stdout else
                         "FAIL (counterexample)" if "Status: FAILED" in b.stdout else "ERROR")
    except subprocess.TimeoutExpired:
        row["smtbmc"] = f"TIMEOUT (depth {sdepth})"
    if prove:
        try:
            p = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; pdr -T {PDR_TIMEOUT}"],
                               capture_output=True, text=True, cwd=d, timeout=PDR_TIMEOUT + 120)
            open(os.path.join(d, "pdr.log"), "w").write(p.stdout + p.stderr)
            row["prove"] = ("PROVED (unbounded, ABC PDR)" if "Property proved" in p.stdout else
                            "FAIL (counterexample)" if "was asserted" in p.stdout else "UNKNOWN")
            m = re.search(r"Reached timeout \((\d+) seconds\) in frame (\d+)", p.stdout)
            if m:
                row["prove"] = f"UNKNOWN (PDR budget {m.group(1)} s, frame {m.group(2)})"
        except subprocess.TimeoutExpired:
            row["prove"] = "UNKNOWN (timeout)"
    else:
        row["prove"] = "-"
    if row["expect"] == "FAIL":
        row["ok"] = "FAIL" in row["bmc"] or "FAIL" in row["prove"] or "FAIL" in row["smtbmc"]
    else:
        row["ok"] = (row["bmc"].startswith("PASS") and not row["smtbmc"].startswith(("FAIL", "ERROR")) and
                     (row["prove"] in ("-",) or row["prove"].startswith("PROVED") or row["prove"].startswith("UNKNOWN")))
    row["secs"] = round(time.time() - t0, 1)
    json.dump(row, open(os.path.join(d, "result.json"), "w"), indent=1)
    return row


def write_report(res):
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    ver = lambda c: (subprocess.run(c, capture_output=True, text=True, env=ENV).stdout.strip().splitlines() or ["n/a"])[0]
    tools = {"yosys": ver(["yosys", "-V"]), SOLVER: ver([SOLVER, "--version"])}
    json.dump(dict(tools=tools, jobs=res), open(os.path.join(ROOT, "reports", "formal.json"), "w"), indent=1)
    np = sum(1 for r in res if r["expect"] == "PASS" and r["prove"].startswith("PROVED"))
    nb = sum(1 for r in res if r["expect"] == "PASS" and not r["prove"].startswith("PROVED"))
    nm = sum(1 for r in res if r["expect"] == "FAIL" and r["ok"])
    with open(os.path.join(ROOT, "reports", "formal.md"), "w") as f:
        f.write(f"# Formal results\n\n{tools['yosys']}; BMC with ABC bmc3 (bit level) and, as an independent second "
                f"engine, yosys-smtbmc + {tools[SOLVER]} (word level, shorter depth); unbounded proofs with "
                f"ABC PDR (yosys-abc, budget {PDR_TIMEOUT} s).  `expect FAIL` rows are non-vacuity checks: the same harness on "
                "one deliberately broken RTL file must give a counterexample.  UNKNOWN = PDR budget reached: the property then "
                "holds only to the BMC depth.\n\n"
                f"**{sum(r['ok'] for r in res)} / {len(res)} jobs as expected: {np} unbounded proofs, {nb} bounded only, "
                f"{nm} mutants caught.**\n\n"
                "| job | harness | params | BMC (abc bmc3) | BMC (smtbmc+z3) | unbounded | expect | verdict | note | s |\n"
                "|---|---|---|---|---|---|---|---|---|---|\n")
        for r in res:
            v = "OK" if r["ok"] else "**NOT OK**"
            if r["ok"] and r["expect"] == "PASS" and not r["prove"].startswith("PROVED") and r["prove"] != "-":
                v = "OK, **bounded only**"
            f.write(f"| {r['job']} | {r['top']} | {r['params']} | {r['bmc']} | {r.get('smtbmc','-')} | {r['prove']} | {r['expect']} | {v} | "
                    f"{r.get('note','')} | {r.get('secs','')} |\n")


def main():
    sel = sys.argv[1:]
    jobs = [j for j in JOBS if not sel or j[0] in sel]
    with ThreadPoolExecutor(max_workers=int(os.environ.get("FORMAL_JOBS", "4"))) as ex:
        res = list(ex.map(run_job, jobs))
    for r in res:
        print(f"{r['job']:24s} bmc={r['bmc']:18s} smt={r.get('smtbmc','-'):18s} prove={r['prove']:30s} {'OK' if r['ok'] else 'NOT OK'} {r.get('detail','')[-300:]}")
    if not sel:
        write_report(res)
    return 0 if all(r["ok"] for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
