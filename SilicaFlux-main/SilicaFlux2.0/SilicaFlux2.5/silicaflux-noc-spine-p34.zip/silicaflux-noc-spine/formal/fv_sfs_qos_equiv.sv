// Formal miter: sfs_qos_arbiter (spine, parallel levels) == sfn_qos_arbiter (P22, unmodified).
// Both start from reset and see the same free inputs every cycle (req, qos, stall, accept --
// including combinations no switch produces).  Q1: every output is identical in every cycle
// (grant, grant_idx -- also when no grant is given --, grant_valid, urgent).  Unbounded proof => the spine's arbiter inherits
// P22's proved guarantee (STARVE + N - 1) and every P22 arbiter verification result.
module fv_sfs_qos_equiv #(
  parameter int N      = 5,
  parameter int STARVE = 3
) (
  input logic           clk,
  input logic [N-1:0]   req,
  input logic [N*3-1:0] qos,
  input logic           stall,
  input logic           accept
);
  localparam int IW = sfn_pkg::clog2c(N);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [N-1:0]  g_a, g_b, u_a, u_b;
  logic [IW-1:0] i_a, i_b;
  logic          v_a, v_b;
  sfn_qos_arbiter #(.N(N), .STARVE(STARVE)) ref_arb (
    .clk, .rst_n, .req, .qos, .stall, .accept, .grant(g_a), .grant_idx(i_a), .grant_valid(v_a), .urgent(u_a));
  sfs_qos_arbiter #(.N(N), .STARVE(STARVE)) new_arb (
    .clk, .rst_n, .req, .qos, .stall, .accept, .grant(g_b), .grant_idx(i_b), .grant_valid(v_b), .urgent(u_b));
`ifdef FORMAL
  always_comb if (rst_n) begin
    assert (v_a == v_b);
    assert (g_a == g_b);
    assert (i_a == i_b);
    assert (u_a == u_b);
  end
`endif
endmodule
