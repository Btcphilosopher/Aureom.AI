// Formal harness: sfs_tc_map, NT = 3, AW = 8 (windows 0x00-0x3F, 0x40-0x7F, 0x80-0xBF; 0xC0-0xFF unmapped),
// access matrix 3'b011 (t2 not reachable), t1 is a register (MMIO) target.  Properties (all inputs free):
//   C1 class = CTRL iff the master is a control master or the address decodes to a reachable MMIO target
//   C2 otherwise class = RD for OP_READ and WR for every other opcode; never TC_CPL
//   C3 TC_MODE 1: level = TC_QOS[class]; TC_MODE 0: level = the master's own QoS
module fv_sfs_tc_map #(
  parameter logic MST_CTRL = 1'b0,
  parameter int   TC_MODE  = 1
) (
  input logic       clk,                   // only to make the model sequential for ABC bmc3 / pdr
  input logic [2:0] opcode,
  input logic [7:0] addr,
  input logic [2:0] qos_in
);
  logic [1:0] tc;
  logic [2:0] qos_out;
  sfs_tc_map #(.NT(3), .AW(8), .DW(32), .TGT_BASE(24'h80_40_00), .TGT_MASK(24'hC0_C0_C0), .EN(3'b011),
               .TGT_MMIO(3'b010), .MST_CTRL(MST_CTRL), .TC_MODE(TC_MODE), .TC_QOS(9'b001_010_011)) dut (
    .opcode, .addr, .qos_in, .tc, .qos_out);
  logic seen = 1'b0;
  always_ff @(posedge clk) seen <= 1'b1;
`ifdef FORMAL
  wire mmio = (addr[7:6] == 2'b01);                    // t1, reachable and MMIO
  always_comb if (seen) begin              // inputs are free in every cycle: every combination is checked
    assert ((tc == sfs_pkg::TC_CTRL) == (MST_CTRL || mmio));                                   // C1
    if (!(MST_CTRL || mmio)) assert (tc == ((opcode == sfn_pkg::OP_READ) ? sfs_pkg::TC_RD : sfs_pkg::TC_WR));  // C2
    assert (tc != sfs_pkg::TC_CPL);
    if (TC_MODE == 0) assert (qos_out == qos_in);                                               // C3
    else assert (qos_out == ((tc == sfs_pkg::TC_CTRL) ? 3'd3 : (tc == sfs_pkg::TC_RD) ? 3'd2 : 3'd1));
  end
`endif
endmodule
