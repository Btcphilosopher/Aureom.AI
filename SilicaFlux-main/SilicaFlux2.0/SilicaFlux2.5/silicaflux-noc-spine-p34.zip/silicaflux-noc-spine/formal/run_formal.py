#!/usr/bin/env python3
"""SilicaFlux NoC Spine formal runner -- DERIVED from P22 formal/run_formal.py (same method:
no SymbiYosys needed; Yosys prep, ABC bmc3, yosys-smtbmc + z3, ABC PDR).  Job list: the spine.

For every job: Yosys (read -formal, prep, flatten, async2sync, dffunmap), then
  * BMC  : yosys-smtbmc + z3 to the given depth
  * prove: AIGER + ABC PDR (unbounded)
`expect FAIL` jobs are non-vacuity checks: the same harness on one deliberately
broken RTL file must produce a counterexample.
Writes reports/formal.{json,md}; exit 1 if any job is not as expected.
usage: run_formal.py [job ...]
"""
import json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(ROOT, "build", "formal")
TPN = lambda *f: [os.path.join(ROOT, "third_party", "silicaflux-datafabric-noc", "rtl", "noc", x) for x in f]
TPD = lambda *f: [os.path.join(ROOT, "third_party", "silicaflux-datafabric-noc", "third_party", "datafabric", "rtl",
                                "interconnect", x) for x in f]
SP = lambda *f: [os.path.join(ROOT, "rtl", "spine", x) for x in f]
H = lambda f: os.path.join(HERE, f)
SOLVER = os.environ.get("SMT_SOLVER", "z3")
Z3_DIR = os.environ.get("Z3_DIR", "/usr/local/bin")
ENV = dict(os.environ, PATH=Z3_DIR + os.pathsep + os.environ.get("PATH", ""))
PDR_TIMEOUT = int(os.environ.get("PDR_TIMEOUT", "1200"))

PKG = TPN("sfn_pkg.sv") + SP("sfs_pkg.sv")
LINK = PKG + TPN("sfn_fifo.sv") + SP("sfs_link.sv") + [H("fv_sfs_link.sv")]
TCM = PKG + TPD("sfb_addr_decoder.sv") + SP("sfs_tc_map.sv") + [H("fv_sfs_tc_map.sv")]
SPINE = (PKG + TPD("sfb_arbiter.sv", "sfb_addr_decoder.sv") +
         TPN("sfn_onehot_mux.sv", "sfn_fifo.sv", "sfn_qos_arbiter.sv", "sfn_arbiter.sv", "sfn_mst_port.sv", "sfn_xbar.sv",
             "sfn_perf.sv") +
         SP("sfs_qos_arbiter.sv", "sfs_xbar.sv", "sfs_link.sv", "sfs_tc_map.sv", "sfs_mnode.sv", "sfs_tnode.sv", "sfs_perf.sv",
            "silicaflux_noc_spine.sv") +
         [H("fv_sfs_spine.sv")])

QEQ = PKG + TPN("sfn_qos_arbiter.sv") + SP("sfs_qos_arbiter.sv") + [H("fv_sfs_qos_equiv.sv")]
XEQ = (PKG + TPD("sfb_arbiter.sv") + TPN("sfn_onehot_mux.sv", "sfn_qos_arbiter.sv", "sfn_arbiter.sv", "sfn_xbar.sv") +
       SP("sfs_qos_arbiter.sv", "sfs_xbar.sv") + [H("fv_sfs_xbar_equiv.sv")])

# name, top, files, params, bmc depth, prove, options
JOBS = [
    ("qos_equiv_n5_s3", "fv_sfs_qos_equiv", QEQ, {"N": 5, "STARVE": 3}, 20, True, {}),
    ("qos_equiv_n10_s8", "fv_sfs_qos_equiv", QEQ, {"N": 10, "STARVE": 8}, 16, True, {}),
    ("qos_equiv_n3_s0", "fv_sfs_qos_equiv", QEQ, {"N": 3, "STARVE": 0}, 16, True, {}),
    ("qos_equiv_n4_s1", "fv_sfs_qos_equiv", QEQ, {"N": 4, "STARVE": 1}, 16, True, {}),
    ("xbar_equiv_qos", "fv_sfs_xbar_equiv", XEQ, {"ARB": 2}, 12, True, {"smt_depth": 8}),
    ("xbar_equiv_rr", "fv_sfs_xbar_equiv", XEQ, {"ARB": 1}, 12, True, {"smt_depth": 8}),
    ("link_s1_d2", "fv_sfs_link", LINK, {"STAGES": 1, "DEPTH": 2}, 20, True, {}),
    ("link_s2_d2", "fv_sfs_link", LINK, {"STAGES": 2, "DEPTH": 2}, 20, True, {}),
    ("link_s3_d2", "fv_sfs_link", LINK, {"STAGES": 3, "DEPTH": 2}, 20, True, {}),
    ("link_s2_d1", "fv_sfs_link", LINK, {"STAGES": 2, "DEPTH": 1}, 20, True, {}),
    ("link_s2_d3", "fv_sfs_link", LINK, {"STAGES": 2, "DEPTH": 3}, 20, True, {}),
    ("link_s4_d2", "fv_sfs_link", LINK, {"STAGES": 4, "DEPTH": 2}, 24, True, {}),
    ("tc_map_mode1", "fv_sfs_tc_map", TCM, {"TC_MODE": 1}, 2, True, {}),
    ("tc_map_ctrl", "fv_sfs_tc_map", TCM, {"TC_MODE": 1, "MST_CTRL": "1'b1"}, 2, True, {}),
    ("tc_map_mode0", "fv_sfs_tc_map", TCM, {"TC_MODE": 0}, 2, True, {}),
    ("spine_single", "fv_sfs_spine", SPINE, {"MP0": 0, "MP1": 0, "TP0": 0, "TP1": 0}, 20, True, {"smt_depth": 6, "smt_timeout": 1800}),
    ("spine_mixed", "fv_sfs_spine", SPINE, {"MP0": 1, "MP1": 0, "TP0": 2, "TP1": 1}, 20, True, {"smt_depth": 6, "smt_timeout": 1800}),
    ("spine_all1", "fv_sfs_spine", SPINE, {"MP0": 1, "MP1": 1, "TP0": 1, "TP1": 1}, 20, True, {"smt_depth": 6, "smt_timeout": 1800}),
    ("spine_buf1", "fv_sfs_spine", SPINE, {"MP0": 1, "MP1": 2, "TP0": 1, "TP1": 0, "BUF": 1}, 20, True, {"smt_depth": 6, "smt_timeout": 1800}),
    # ---------------------------------------------------------------- non-vacuity (expect a counterexample)
    ("mut_link_overflow", "fv_sfs_link", LINK, {"STAGES": 2, "DEPTH": 2}, 12, False,
     {"expect": "FAIL", "mutate": ("sfs_link.sv", "assign in_ready         = r[0];", "assign in_ready         = 1'b1;"),
      "note": "link accepts while its first stage is full (loss)"}),
    ("mut_link_skip_stage", "fv_sfs_link", LINK, {"STAGES": 2, "DEPTH": 2}, 12, False,
     {"expect": "FAIL", "mutate": ("sfs_link.sv", "assign out_data         = d[STAGES*W +: W];", "assign out_data         = d[(STAGES-1)*W +: W];"),
      "note": "output taken from the wrong stage (integrity / order)"}),
    ("mut_qos_equiv_ptr", "fv_sfs_qos_equiv", QEQ, {"N": 5, "STARVE": 3}, 12, False,
     {"expect": "FAIL", "mutate": ("sfs_qos_arbiter.sv", "elig_hi[i] = elig[i] && (IW'(i) >= prio_q);",
                                   "elig_hi[i] = elig[i] && (IW'(i) > prio_q);"),
      "note": "round-robin search starts one past the pointer"}),
    ("mut_qos_equiv_level", "fv_sfs_qos_equiv", QEQ, {"N": 5, "STARVE": 3}, 12, False,
     {"expect": "FAIL", "mutate": ("sfs_qos_arbiter.sv", "for (int l = NL - 2; l >= 0; l--) higher[l] = higher[l+1] | any_lvl[l+1];",
                                   "for (int l = NL - 2; l >= 0; l--) higher[l] = any_lvl[l+1];"),
      "note": "only the next level up is considered higher"}),
    ("mut_tc_mmio", "fv_sfs_tc_map", TCM, {"TC_MODE": 1}, 2, False,
     {"expect": "FAIL", "mutate": ("sfs_tc_map.sv", "if (MST_CTRL || (hit && TGT_MMIO[sel]))", "if (MST_CTRL)"),
      "note": "MMIO targets not classified as control traffic"}),
    ("mut_tnode_src", "fv_sfs_spine", SPINE, {"MP0": 1, "MP1": 0, "TP0": 1, "TP1": 1}, 16, False,
     {"expect": "FAIL", "smt_depth": 6, "mutate": ("sfs_tnode.sv", ".in_data({t_rsp_src, t_rsp_id,", ".in_data({~t_rsp_src, t_rsp_id,"),
      "note": "target link corrupts the response owner (misrouted completions)"}),
    ("mut_mnode_rsp_tgt", "fv_sfs_spine", SPINE, {"MP0": 1, "MP1": 0, "TP0": 1, "TP1": 1}, 16, False,
     {"expect": "FAIL", "smt_depth": 6, "mutate": ("sfs_mnode.sv", ".in_data({c_rsp_tgt, c_rsp_id,", ".in_data({{TW{1'b0}}, c_rsp_id,"),
      "note": "master link loses the responding target (completions discarded as orphans: lost responses)"}),
    ("mut_mnode_tc_swap", "fv_sfs_spine", SPINE, {"MP0": 1, "MP1": 1, "TP0": 1, "TP1": 1}, 20, False,
     {"expect": "FAIL", "smt_depth": 6, "mutate": ("sfs_mnode.sv", ".in_data(n_req_data),", ".in_data({n_req_data[QPW-1:1], ~n_req_data[0]}),"),
      "note": "request link flips a payload bit (integrity)"}),
]


def apply_mutation(name, files, mut):
    if not mut:
        return files
    d = os.path.join(OUT, name, "mut"); os.makedirs(d, exist_ok=True)
    out = []
    for f in files:
        if os.path.basename(f) == mut[0]:
            src = open(f).read(); assert mut[1] in src, (name, mut[1])
            g = os.path.join(d, mut[0]); open(g, "w").write(src.replace(mut[1], mut[2], 1)); out.append(g)
        else:
            out.append(f)
    return out


def yosys_prep(name, top, files, params):
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    common = (f"read_verilog -sv -formal -DFORMAL -DSYNTHESIS {' '.join(files)}; {ch}prep -top {top}; "
              f"flatten; async2sync; dffunmap; setundef -undriven -zero; opt_clean; ")
    smt, aig = os.path.join(d, "model.smt2"), os.path.join(d, "model.aig")
    r1 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_smt.log"), "-p", common + f"write_smt2 -wires {smt}"],
                        capture_output=True, text=True)
    r2 = subprocess.run(["yosys", "-q", "-l", os.path.join(d, "yosys_aig.log"), "-p",
                         common + "memory_map; opt -full -nosdff -nodffe; techmap; opt -fast -nosdff -nodffe; dffunmap; "
                         f"abc -g AND -fast; opt_clean; write_aiger -I -B -zinit -no-startoffset -map {d}/model.aim {aig}"],
                        capture_output=True, text=True)
    return d, smt, aig, r1, r2


def run_job(job):
    try:
        return run_job_(job)
    except Exception as e:  # a broken job must not abort the whole campaign
        return dict(job=job[0], top=job[1], params=job[3], expect=job[6].get("expect", "PASS"), note=job[6].get("note", ""),
                    bmc="ERROR", smtbmc="ERROR", prove="ERROR", ok=False, secs=0, detail=repr(e)[-600:])


def run_job_(job):
    name, top, files, params, depth, prove, opt = job
    t0 = time.time()
    files = apply_mutation(name, files, opt.get("mutate"))
    d, smt, aig, r1, r2 = yosys_prep(name, top, files, params)
    row = dict(job=name, top=top, params=params, expect=opt.get("expect", "PASS"), note=opt.get("note", ""))
    if r1.returncode or r2.returncode:
        row.update(bmc="ERROR", prove="ERROR", ok=False, secs=0, detail=(r1.stderr + r2.stderr)[-1500:])
        return row
    # BMC, engine 1: ABC bmc3 (bit level, on the same AIGER model PDR proves) to the full depth
    try:
        b = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; bmc3 -F {depth} -T 1800 -v"],
                           capture_output=True, text=True, cwd=d, timeout=2400)
        open(os.path.join(d, "bmc.log"), "w").write(b.stdout + b.stderr)
        m = re.search(r"No output asserted in (\d+) frames", b.stdout)
        row["bmc"] = ("FAIL (counterexample)" if "was asserted" in b.stdout else
                      f"PASS depth {m.group(1)}" if m else "ERROR")
        if row["bmc"] == "ERROR":
            row["detail"] = (b.stdout + b.stderr)[-800:]
    except subprocess.TimeoutExpired:
        row["bmc"] = f"TIMEOUT depth {depth}"
    # BMC, engine 2: yosys-smtbmc + z3 (word level, independent tool chain), shorter depth
    sdepth = min(depth, opt.get("smt_depth", 8))
    try:
        b = subprocess.run(["yosys-smtbmc", "-s", SOLVER, "--presat", "-t", str(sdepth), smt],
                           capture_output=True, text=True, cwd=d, timeout=opt.get("smt_timeout", 900), env=ENV)
        open(os.path.join(d, "smtbmc.log"), "w").write(b.stdout + b.stderr)
        row["smtbmc"] = (f"PASS depth {sdepth}" if b.returncode == 0 and "Status: PASSED" in b.stdout else
                         "FAIL (counterexample)" if "Status: FAILED" in b.stdout else "ERROR")
    except subprocess.TimeoutExpired:
        row["smtbmc"] = f"TIMEOUT (depth {sdepth})"
    if prove:
        try:
            p = subprocess.run(["yosys-abc", "-c", f"read_aiger {aig}; fold; strash; pdr -T {PDR_TIMEOUT}"],
                               capture_output=True, text=True, cwd=d, timeout=PDR_TIMEOUT + 120)
            open(os.path.join(d, "pdr.log"), "w").write(p.stdout + p.stderr)
            row["prove"] = ("PROVED (unbounded, ABC PDR)" if "Property proved" in p.stdout else
                            "FAIL (counterexample)" if "was asserted" in p.stdout else "UNKNOWN")
            m = re.search(r"Reached timeout \((\d+) seconds\) in frame (\d+)", p.stdout)
            if m:
                row["prove"] = f"UNKNOWN (PDR budget {m.group(1)} s, frame {m.group(2)})"
        except subprocess.TimeoutExpired:
            row["prove"] = "UNKNOWN (timeout)"
    else:
        row["prove"] = "-"
    if row["expect"] == "FAIL":
        row["ok"] = "FAIL" in row["bmc"] or "FAIL" in row["prove"] or "FAIL" in row["smtbmc"]
    else:
        row["ok"] = (row["bmc"].startswith("PASS") and not row["smtbmc"].startswith(("FAIL", "ERROR")) and
                     (row["prove"] in ("-",) or row["prove"].startswith("PROVED") or row["prove"].startswith("UNKNOWN")))
    row["secs"] = round(time.time() - t0, 1)
    json.dump(row, open(os.path.join(d, "result.json"), "w"), indent=1)
    return row


def write_report(res):
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    ver = lambda c: (subprocess.run(c, capture_output=True, text=True, env=ENV).stdout.strip().splitlines() or ["n/a"])[0]
    tools = {"yosys": ver(["yosys", "-V"]), SOLVER: ver([SOLVER, "--version"])}
    json.dump(dict(tools=tools, jobs=res), open(os.path.join(ROOT, "reports", "formal.json"), "w"), indent=1)
    np = sum(1 for r in res if r["expect"] == "PASS" and r["prove"].startswith("PROVED"))
    nb = sum(1 for r in res if r["expect"] == "PASS" and not r["prove"].startswith("PROVED"))
    nm = sum(1 for r in res if r["expect"] == "FAIL" and r["ok"])
    with open(os.path.join(ROOT, "reports", "formal.md"), "w") as f:
        f.write(f"# Formal results\n\n{tools['yosys']}; BMC with ABC bmc3 (bit level) and, as an independent second "
                f"engine, yosys-smtbmc + {tools[SOLVER]} (word level, shorter depth); unbounded proofs with "
                f"ABC PDR (yosys-abc, budget {PDR_TIMEOUT} s).  `expect FAIL` rows are non-vacuity checks: the same harness on "
                "one deliberately broken RTL file must give a counterexample.  UNKNOWN = PDR budget reached: the property then "
                "holds only to the BMC depth.  BMC depth = frames completed (bit-level BMC stops at its 1800 s limit, so a "
                "depth below the requested one means the limit was reached, not that a frame failed).\n\n"
                f"**{sum(r['ok'] for r in res)} / {len(res)} jobs as expected: {np} unbounded proofs, {nb} bounded only, "
                f"{nm} mutants caught.**\n\n"
                "| job | harness | params | BMC (abc bmc3) | BMC (smtbmc+z3) | unbounded | expect | verdict | note | s |\n"
                "|---|---|---|---|---|---|---|---|---|---|\n")
        for r in res:
            v = "OK" if r["ok"] else "**NOT OK**"
            if r["ok"] and r["expect"] == "PASS" and not r["prove"].startswith("PROVED") and r["prove"] != "-":
                v = "OK, **bounded only**"
            f.write(f"| {r['job']} | {r['top']} | {r['params']} | {r['bmc']} | {r.get('smtbmc','-')} | {r['prove']} | {r['expect']} | {v} | "
                    f"{r.get('note','')} | {r.get('secs','')} |\n")


def main():
    sel = sys.argv[1:]
    jobs = [j for j in JOBS if not sel or j[0] in sel]
    with ThreadPoolExecutor(max_workers=int(os.environ.get("FORMAL_JOBS", "4"))) as ex:
        res = list(ex.map(run_job, jobs))
    for r in res:
        print(f"{r['job']:24s} bmc={r['bmc']:18s} smt={r.get('smtbmc','-'):18s} prove={r['prove']:30s} {'OK' if r['ok'] else 'NOT OK'} {r.get('detail','')[-300:]}")
    if not sel:
        write_report(res)
    else:   # partial rerun: merge into the existing report
        path = os.path.join(ROOT, "reports", "formal.json")
        if os.path.exists(path):
            old = json.load(open(path))["jobs"]
            names = [j[0] for j in JOBS]
            merged = {r["job"]: r for r in old}
            merged.update({r["job"]: r for r in res})
            write_report([merged[n] for n in names if n in merged])
    return 0 if all(r["ok"] for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
