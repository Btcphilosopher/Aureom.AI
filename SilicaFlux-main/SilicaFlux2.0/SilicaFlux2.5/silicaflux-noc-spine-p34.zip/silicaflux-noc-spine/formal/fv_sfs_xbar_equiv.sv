// Formal miter: sfs_xbar (spine central stage) == sfn_xbar (P22, unmodified), NM = 3, NT = 2,
// AW = DW = 8, IDW = 1, QoS arbitration, sparse access matrix.  All switch inputs are free every
// cycle (no protocol assumption).  X1: every output of the two cores is identical in every cycle.
module fv_sfs_xbar_equiv #(
  parameter int ARB = 2
) (
  input logic        clk,
  input logic [2:0]  fq_valid,
  input logic [5:0]  fq_tgt,
  input logic [8:0]  fq_opcode,
  input logic [2:0]  fq_id,
  input logic [8:0]  fq_qos,
  input logic [23:0] fq_addr,
  input logic [23:0] fq_wdata,
  input logic [2:0]  fq_wstrb,
  input logic [2:0]  fr_ready,
  input logic [1:0]  t_req_ready,
  input logic [1:0]  t_rsp_valid,
  input logic [3:0]  t_rsp_src,
  input logic [1:0]  t_rsp_id,
  input logic [5:0]  t_rsp_opcode,
  input logic [3:0]  t_rsp_status,
  input logic [15:0] t_rsp_rdata
);
  localparam int NM = 3, NT = 2;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [2:0]  a_fq_ready, b_fq_ready, a_fr_valid, b_fr_valid, a_fr_id, b_fr_id, a_loss, b_loss;
  logic [5:0]  a_fr_tgt, b_fr_tgt, a_fr_status, b_fr_status;
  logic [8:0]  a_fr_opcode, b_fr_opcode;
  logic [23:0] a_fr_rdata, b_fr_rdata;
  logic [1:0]  a_tv, b_tv, a_tid, b_tid, a_trr, b_trr, a_bad, b_bad, a_tw, b_tw;
  logic [3:0]  a_src, b_src;
  logic [5:0]  a_top, b_top, a_tq, b_tq;
  logic [15:0] a_ta, b_ta, a_twd, b_twd;
  sfn_xbar #(.NM(NM), .NT(NT), .AW(8), .DW(8), .IDW(1), .ARB_MODE(ARB), .STARVE(2), .MST_TGT_EN(6'b011111)) ref_x (
    .clk, .rst_n, .fq_valid, .fq_ready(a_fq_ready), .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
    .fr_valid(a_fr_valid), .fr_ready, .fr_tgt(a_fr_tgt), .fr_id(a_fr_id), .fr_opcode(a_fr_opcode), .fr_status(a_fr_status),
    .fr_rdata(a_fr_rdata), .t_req_valid(a_tv), .t_req_ready, .t_req_opcode(a_top), .t_req_src(a_src), .t_req_id(a_tid),
    .t_req_qos(a_tq), .t_req_addr(a_ta), .t_req_wdata(a_twd), .t_req_wstrb(a_tw), .t_rsp_valid, .t_rsp_ready(a_trr),
    .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata, .ev_arb_loss(a_loss), .ev_bad_src(a_bad));
  sfs_xbar #(.NM(NM), .NT(NT), .AW(8), .DW(8), .IDW(1), .ARB_MODE(ARB), .STARVE(2), .MST_TGT_EN(6'b011111)) new_x (
    .clk, .rst_n, .fq_valid, .fq_ready(b_fq_ready), .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
    .fr_valid(b_fr_valid), .fr_ready, .fr_tgt(b_fr_tgt), .fr_id(b_fr_id), .fr_opcode(b_fr_opcode), .fr_status(b_fr_status),
    .fr_rdata(b_fr_rdata), .t_req_valid(b_tv), .t_req_ready, .t_req_opcode(b_top), .t_req_src(b_src), .t_req_id(b_tid),
    .t_req_qos(b_tq), .t_req_addr(b_ta), .t_req_wdata(b_twd), .t_req_wstrb(b_tw), .t_rsp_valid, .t_rsp_ready(b_trr),
    .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata, .ev_arb_loss(b_loss), .ev_bad_src(b_bad));
`ifdef FORMAL
  always_comb if (rst_n) begin
    assert (a_fq_ready == b_fq_ready && a_loss == b_loss && a_bad == b_bad && a_trr == b_trr);
    assert (a_tv == b_tv && a_top == b_top && a_src == b_src && a_tid == b_tid && a_tq == b_tq && a_ta == b_ta &&
            a_twd == b_twd && a_tw == b_tw);
    assert (a_fr_valid == b_fr_valid && a_fr_tgt == b_fr_tgt && a_fr_id == b_fr_id && a_fr_opcode == b_fr_opcode &&
            a_fr_status == b_fr_status && a_fr_rdata == b_fr_rdata);
  end
`endif
endmodule
