// Formal harness: sfs_link (STAGES register stages of sfn_fifo, DEPTH entries each).
// Environment: none -- in_valid, in_data and out_ready are free every cycle (a source may
// even withdraw; the link must still never lose, invent, reorder or corrupt an entry).
// Properties:
//   K1 occupancy == pushes - pops (shadow counter) and <= STAGES * DEPTH   (no loss, FIFO safety)
//   K2 out_valid only if an entry is held                                    (no duplication)
//   K3 an arbitrarily chosen accepted entry leaves after exactly the entries ahead of it,
//      with unchanged data                                                    (order, integrity)
//   K4 a presented entry that is not accepted is presented unchanged next cycle (stable under stall)
//   K5 full throughput (DEPTH >= 2): after STAGES consecutive cycles with in_valid and
//      out_ready both high, an entry is delivered in every further such cycle
// (No combinational in->out path exists by construction: every stage is sfn_fifo with
//  PASS_FULL = 0, whose in_ready / out_valid / out_data depend on registers only.)
module fv_sfs_link #(
  parameter int W      = 4,
  parameter int STAGES = 2,
  parameter int DEPTH  = 2
) (
  input logic         clk,
  input logic         in_valid,
  input logic [W-1:0] in_data,
  input logic         out_ready,
  input logic         track
);
  localparam int CAP  = STAGES * DEPTH;
  localparam int OCCW = sfs_pkg::clog2c(CAP + 1);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic            in_ready, out_valid;
  logic [W-1:0]    out_data;
  logic [OCCW-1:0] occ;
  sfs_link #(.W(W), .STAGES(STAGES), .DEPTH(DEPTH)) dut (
    .clk, .rst_n, .in_valid, .in_ready, .in_data, .out_valid, .out_ready, .out_data, .occ);

`ifdef FORMAL
  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;
  logic [OCCW:0] m_cnt;
  logic          trk_v;
  logic [W-1:0]  trk_d;
  logic [OCCW:0] trk_pos;
  logic          held_q;
  logic [W-1:0]  head_q;
  initial begin m_cnt = '0; trk_v = 1'b0; trk_d = '0; trk_pos = '0; held_q = 1'b0; head_q = '0; end
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      m_cnt <= '0; trk_v <= 1'b0; held_q <= 1'b0;
    end else begin
      m_cnt <= m_cnt + (OCCW+1)'(push) - (OCCW+1)'(pop);
      if (trk_v && pop) begin
        if (trk_pos == '0) trk_v <= 1'b0;
        else               trk_pos <= trk_pos - 1'b1;
      end
      if (!trk_v && push && track) begin
        trk_v   <= 1'b1;
        trk_d   <= in_data;
        trk_pos <= m_cnt - (OCCW+1)'(pop);
      end
      held_q <= out_valid && !out_ready;
      head_q <= out_data;
    end
  end
  always_comb if (rst_n) begin
    assert ((OCCW+1)'(occ) == m_cnt);                                   // K1
    assert (m_cnt <= (OCCW+1)'(CAP));
    if (m_cnt == '0) assert (!out_valid);                                // K2
    if (trk_v) assert (trk_pos < m_cnt);
    if (trk_v && trk_pos == '0 && out_valid) assert (out_data == trk_d);  // K3 (head reached: it is the tracked one)
  end
  // K3 (order): the tracked entry is at the head exactly when trk_pos == 0 -- if anything else
  // left while it was at position 0, the check above fails on the data; position never underflows
  always_ff @(posedge clk) if (rst_n && held_q) assert (out_valid && out_data == head_q);   // K4
  // K5: streak = consecutive cycles (saturating) with in_valid && out_ready
  logic [4:0] streak;
  initial streak = '0;
  always_ff @(posedge clk) begin
    if (!rst_n || !(in_valid && out_ready)) streak <= '0;
    else if (streak != 5'd31)              streak <= streak + 5'd1;
  end
  always_comb if (rst_n && DEPTH >= 2 && in_valid && out_ready && streak >= 5'(STAGES)) assert (out_valid && in_ready);
`endif
endmodule
