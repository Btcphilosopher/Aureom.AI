// Formal harness: silicaflux_noc_spine, NM = 2, NT = 2, AW = DW = 8, IDW = 1, MAXO 2,
// QoS arbitration with traffic classes, pipelined links (MP0, MP1, TP0, TP1 stages, BUF entries).
//   address map  t0 = 0x00..0x7F, t1 = 0x80..0xFF;  access matrix: m1 may not reach t1 (DECERR);
//   m0 is a control master, t1 a register (MMIO) target.
// Environment (the stated assumptions of docs/DEADLOCK.md, nothing else):
//   * masters: a request is held unchanged until accepted (R2) -- the master model is a
//     register loaded only when empty or accepted; any opcode, including FENCE and reserved;
//     a master drains its responses: rsp_ready is free but forced high after K stalled cycles (M1);
//   * targets: one pending request; respond with the echoed (src, id, opcode) and free
//     status / data, never in the acceptance cycle (R5), within LAT cycles once pending;
//     req_ready is free but forced high after K refused cycles (targets make progress).
// Properties:
//   E1 integrity and order of requests: every request accepted by a target is the oldest
//      outstanding request of that (master, target) pair, bit for bit (no loss, duplication,
//      reordering, corruption, misrouting); its source is legal and allowed (legal destination)
//   E2 response ownership and order: every response accepted by master m with ID i is the
//      oldest expected one of (m, i), with the opcode of that request and the status / data the
//      target produced (or OKAY / DECERR from the fabric for FENCE / decode errors); posted
//      completions never reach a master (no duplicated or unexpected responses); the fabric's
//      containment (orphan / bad-source discard) never fires on this legal traffic, i.e. no
//      completion a target produced is ever discarded (no lost responses, as a safety property)
//   E3 stability: held target requests and held master responses do not change (R2 / R4)
//   E4 outstanding limit per master (O1)
//   E5 LIVENESS (bounded): a presented request is accepted within B cycles and every accepted
//      non-posted request is answered within B cycles -- no deadlock, no starvation
module fv_sfs_spine #(
  parameter int MP0 = 1,
  parameter int MP1 = 0,
  parameter int TP0 = 2,
  parameter int TP1 = 1,
  parameter int BUF = 2,
  parameter int K   = 2,
  parameter int LAT = 3,
  parameter int B   = 48
) (
  input logic        clk,
  input logic [1:0]  nv,
  input logic [5:0]  nop,
  input logic [1:0]  nid,
  input logic [15:0] naddr,
  input logic [15:0] nwd,
  input logic [1:0]  nws,
  input logic [1:0]  rrdy,
  input logic [1:0]  trdy,
  input logic [1:0]  tgo,
  input logic [1:0]  tst,
  input logic [15:0] trd
);
  localparam int NM = 2, NT = 2, AW = 8, DW = 8, IDW = 1, SB = 1, SRCW = 1, CW = 2, TW = 2;
  localparam logic [15:0] TBASE = 16'h8000;          // t1 = 0x80, t0 = 0x00
  localparam logic [15:0] TMASK = 16'h8080;
  localparam logic [3:0]  EN    = 4'b0111;           // bit m*NT+t: m1->t1 denied
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  // ================================================================ master models
  logic [1:0]  mv;
  logic [5:0]  mop;
  logic [1:0]  mid;
  logic [15:0] maddr, mwd;
  logic [1:0]  mws;
  logic [1:0]  m_req_ready, m_rsp_valid, m_rsp_ready;
  logic [1:0]  m_rsp_id;
  logic [5:0]  m_rsp_opcode;
  logic [3:0]  m_rsp_status;
  logic [15:0] m_rsp_rdata;
  logic [3:0]  mstall;                                   // 2 x 2-bit stall counters
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      mv <= '0; mop <= '0; mid <= '0; maddr <= '0; mwd <= '0; mws <= '0; mstall <= '0;
    end else begin
      for (int m = 0; m < NM; m++) begin
        if (!mv[m] || m_req_ready[m]) begin
          mv[m] <= nv[m]; mop[m*3 +: 3] <= nop[m*3 +: 3]; mid[m] <= nid[m];
          maddr[m*8 +: 8] <= naddr[m*8 +: 8]; mwd[m*8 +: 8] <= nwd[m*8 +: 8]; mws[m] <= nws[m];
        end
        if (m_rsp_valid[m] && !m_rsp_ready[m]) mstall[m*2 +: 2] <= mstall[m*2 +: 2] + ((mstall[m*2 +: 2] != 2'd3) ? 2'd1 : 2'd0);
        else                                   mstall[m*2 +: 2] <= '0;
      end
    end
  end
  for (genvar m = 0; m < NM; m++) begin : g_rr
    assign m_rsp_ready[m] = rrdy[m] || (32'(mstall[m*2 +: 2]) >= K);
  end

  // ================================================================ target models
  logic [1:0]  t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready;
  logic [5:0]  t_req_opcode, t_req_qos, t_rsp_opcode;
  logic [1:0]  t_req_src, t_req_id, t_rsp_src, t_rsp_id;
  logic [15:0] t_req_addr, t_req_wdata, t_rsp_rdata;
  logic [1:0]  t_req_wstrb;
  logic [3:0]  t_rsp_status;
  logic [1:0]  pv;
  logic [1:0]  psrc, pid;
  logic [5:0]  pop;
  logic [7:0]  pwait;                                    // 2 x 4-bit
  logic [3:0]  trefuse;                                  // 2 x 2-bit
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      pv <= '0; psrc <= '0; pid <= '0; pop <= '0; pwait <= '0; trefuse <= '0;
      t_rsp_valid <= '0; t_rsp_src <= '0; t_rsp_id <= '0; t_rsp_opcode <= '0; t_rsp_status <= '0; t_rsp_rdata <= '0;
    end else begin
      for (int t = 0; t < NT; t++) begin
        if (t_rsp_valid[t] && t_rsp_ready[t]) t_rsp_valid[t] <= 1'b0;
        if (pv[t]) pwait[t*4 +: 4] <= pwait[t*4 +: 4] + ((pwait[t*4 +: 4] != 4'd15) ? 4'd1 : 4'd0);
        if (pv[t] && (!t_rsp_valid[t] || t_rsp_ready[t]) && (tgo[t] || 32'(pwait[t*4 +: 4]) >= LAT)) begin
          t_rsp_valid[t] <= 1'b1;
          t_rsp_src[t] <= psrc[t]; t_rsp_id[t] <= pid[t]; t_rsp_opcode[t*3 +: 3] <= pop[t*3 +: 3];
          t_rsp_status[t*2 +: 2] <= {1'b0, tst[t]};
          t_rsp_rdata[t*8 +: 8] <= (pop[t*3 +: 3] == sfn_pkg::OP_READ && !tst[t]) ? trd[t*8 +: 8] : 8'd0;
          pv[t] <= 1'b0;
        end
        if (t_req_valid[t] && t_req_ready[t]) begin
          pv[t] <= 1'b1; psrc[t] <= t_req_src[t]; pid[t] <= t_req_id[t]; pop[t*3 +: 3] <= t_req_opcode[t*3 +: 3];
          pwait[t*4 +: 4] <= '0;
        end
        if (t_req_valid[t] && !t_req_ready[t]) trefuse[t*2 +: 2] <= trefuse[t*2 +: 2] + ((trefuse[t*2 +: 2] != 2'd3) ? 2'd1 : 2'd0);
        else                                   trefuse[t*2 +: 2] <= '0;
      end
    end
  end
  for (genvar t = 0; t < NT; t++) begin : g_tr
    assign t_req_ready[t] = !pv[t] && (trdy[t] || (32'(trefuse[t*2 +: 2]) >= K));
  end

  // ================================================================ DUT
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] rb_rdata, ae;
  logic        rb_err, irq_err;
  logic [1:0]  o_sw_v, o_sw_r, o_dec, o_perr, o_orph, o_bsrc, o_cv, o_cr, o_cl, o_xv, o_xr, o_crv, o_crr;
  logic [3:0]  o_out, o_ct, o_ctc;
  logic [15:0] o_mq, o_mr, o_tq, o_tr;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_noc_spine #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(2), .STARVE(2), .CHECK_ALIGN(1),
    .TGT_BASE(TBASE), .TGT_MASK(TMASK), .MST_TGT_EN(EN), .MAXO_MAX(2), .MST_MAXO(16'h0202),
    .MST_CTRL(2'b01), .TGT_MMIO(2'b10), .TC_MODE(1), .BUF_DEPTH(BUF),
    .MST_PIPE({4'(MP1), 4'(MP0)}), .TGT_PIPE({4'(TP1), 4'(TP0)}), .PERF(0)
  ) dut (
    .clk, .rst_n,
    .m_req_valid(mv), .m_req_ready, .m_req_opcode(mop), .m_req_id(mid), .m_req_qos(6'd0), .m_req_addr(maddr),
    .m_req_wdata(mwd), .m_req_wstrb(mws),
    .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status, .m_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
    .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
    .rb_sel(1'b0), .rb_sel_spine(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_rdata, .rb_err, .irq_err,
    .obs_sw_valid(o_sw_v), .obs_sw_ready(o_sw_r), .obs_out_cnt(o_out), .obs_decerr(o_dec), .obs_posted_err(o_perr),
    .obs_orphan(o_orph), .obs_bad_src(o_bsrc), .obs_c_valid(o_cv), .obs_c_ready(o_cr), .obs_c_tgt(o_ct), .obs_c_tc(o_ctc),
    .obs_c_loss(o_cl), .obs_mq_occ(o_mq), .obs_mr_occ(o_mr), .obs_tq_occ(o_tq), .obs_tr_occ(o_tr),
    .obs_x_valid(o_xv), .obs_x_ready(o_xr), .obs_cr_valid(o_crv), .obs_cr_ready(o_crr), .assert_errors(ae)
  );

`ifdef FORMAL
  // ================================================================ reference model
  // decode: -1 FENCE (local OKAY), -2 DECERR (local), -3 posted write dropped, else target
  function automatic int ref_dec(input int m, input logic [2:0] op, input logic [7:0] a);
    int t;
    begin
      t = 32'(a[7]);
      if (op == sfn_pkg::OP_FENCE)                       ref_dec = -1;
      else if (op > 3'd2)                                ref_dec = -2;
      else if (!EN[m*NT + t])                            ref_dec = (op == sfn_pkg::OP_WRITE_POSTED) ? -3 : -2;
      else                                               ref_dec = t;
    end
  endfunction

  // expected requests per (m,t) i = m*2+t: up to 3 entries of 21 bits {op[20:18], id[17], addr[16:9], wdata[8:1], wstrb[0]}
  // expected responses per (m,id) i = m*2+id: 2 entries of 15 bits {local[14], filled[13], op[12:10], status[9:8], data[7:0]}
  localparam int QE = 21, RE = 15;
  logic [4*3*QE-1:0] qe_q, qe_f, qe_n;
  logic [4*2-1:0]    qn_q, qn_f, qn_n;
  logic [4*2*RE-1:0] re_q, re_f, re_n;
  logic [4*2-1:0]    rn_q, rn_f, rn_n;
  logic [4*2*7-1:0]  ra_q, ra_n;
  logic [2*7-1:0]    pres_q;
  logic              ovf;
  initial begin qe_q = '0; qn_q = '0; re_q = '0; rn_q = '0; ra_q = '0; pres_q = '0; end

  wire [1:0] macc = mv & m_req_ready;
  wire [1:0] mrhs = m_rsp_valid & m_rsp_ready;
  wire [1:0] tqhs = t_req_valid & t_req_ready;
  wire [1:0] trhs = t_rsp_valid & t_rsp_ready;

  int          i_, m_, t_, d_;
  logic [QE-1:0] nq;
  logic [RE-1:0] nr;
  always_comb begin
    ovf = 1'b0;
    nq = '0; nr = '0; i_ = 0; d_ = 0; m_ = 0; t_ = 0;
    // ---- requests: append this cycle's acceptances (state *_f is checked), then remove deliveries
    qe_f = qe_q; qn_f = qn_q;
    for (m_ = 0; m_ < NM; m_++) begin
      d_ = ref_dec(m_, mop[m_*3 +: 3], maddr[m_*8 +: 8]);
      if (macc[m_] && d_ >= 0) begin
        i_ = m_ * 2 + d_;
        nq = {mop[m_*3 +: 3], mid[m_], maddr[m_*8 +: 8], mwd[m_*8 +: 8], mws[m_]};
        if (qn_f[i_*2 +: 2] == 2'd3) ovf = 1'b1;
        else begin
          qe_f[(i_*3 + 32'(qn_f[i_*2 +: 2]))*QE +: QE] = nq;
          qn_f[i_*2 +: 2] = qn_f[i_*2 +: 2] + 2'd1;
        end
      end
    end
    qe_n = qe_f; qn_n = qn_f;
    for (t_ = 0; t_ < NT; t_++) if (tqhs[t_]) begin
      i_ = 32'(t_req_src[t_]) * 2 + t_;
      if (qn_n[i_*2 +: 2] != 2'd0) begin
        qe_n[i_*3*QE +: 2*QE] = qe_n[(i_*3 + 1)*QE +: 2*QE];
        qn_n[i_*2 +: 2] = qn_n[i_*2 +: 2] - 2'd1;
      end
    end
    // ---- responses: age, fill with this cycle's target responses (state *_f is checked), pop, push
    ra_n = ra_q;
    for (i_ = 0; i_ < 4; i_++) begin
      if (rn_q[i_*2 +: 2] > 2'd0 && ra_n[(i_*2)*7 +: 7] != 7'd127)     ra_n[(i_*2)*7 +: 7]     = ra_n[(i_*2)*7 +: 7] + 7'd1;
      if (rn_q[i_*2 +: 2] > 2'd1 && ra_n[(i_*2 + 1)*7 +: 7] != 7'd127) ra_n[(i_*2 + 1)*7 +: 7] = ra_n[(i_*2 + 1)*7 +: 7] + 7'd1;
    end
    re_f = re_q; rn_f = rn_q;
    for (t_ = 0; t_ < NT; t_++) if (trhs[t_] && t_rsp_opcode[t_*3 +: 3] != sfn_pkg::OP_WRITE_POSTED) begin
      i_ = 32'(t_rsp_src[t_]) * 2 + 32'(t_rsp_id[t_]);
      if (rn_f[i_*2 +: 2] > 2'd0 && !re_f[(i_*2)*RE + 13]) begin
        re_f[(i_*2)*RE + 13] = 1'b1;
        re_f[(i_*2)*RE +: 10] = {t_rsp_status[t_*2 +: 2], t_rsp_rdata[t_*8 +: 8]};
      end else if (rn_f[i_*2 +: 2] > 2'd1 && !re_f[(i_*2 + 1)*RE + 13]) begin
        re_f[(i_*2 + 1)*RE + 13] = 1'b1;
        re_f[(i_*2 + 1)*RE +: 10] = {t_rsp_status[t_*2 +: 2], t_rsp_rdata[t_*8 +: 8]};
      end else ovf = 1'b1;                  // a target answered something nobody expects
    end
    re_n = re_f; rn_n = rn_f;
    for (m_ = 0; m_ < NM; m_++) if (mrhs[m_]) begin
      i_ = m_ * 2 + 32'(m_rsp_id[m_]);
      if (rn_n[i_*2 +: 2] != 2'd0) begin
        re_n[(i_*2)*RE +: RE] = re_n[(i_*2 + 1)*RE +: RE];
        ra_n[(i_*2)*7 +: 7]   = ra_n[(i_*2 + 1)*7 +: 7];
        rn_n[i_*2 +: 2] = rn_n[i_*2 +: 2] - 2'd1;
      end
    end
    for (m_ = 0; m_ < NM; m_++) begin
      d_ = ref_dec(m_, mop[m_*3 +: 3], maddr[m_*8 +: 8]);
      if (macc[m_] && mop[m_*3 +: 3] != sfn_pkg::OP_WRITE_POSTED) begin
        i_ = m_ * 2 + 32'(mid[m_]);
        nr = {d_ < 0, d_ < 0, mop[m_*3 +: 3], (d_ == -1) ? sfn_pkg::ST_OKAY : sfn_pkg::ST_DECERR, 8'd0};
        if (rn_n[i_*2 +: 2] == 2'd2) ovf = 1'b1;
        else begin
          re_n[(i_*2 + 32'(rn_n[i_*2 +: 2]))*RE +: RE] = nr;
          ra_n[(i_*2 + 32'(rn_n[i_*2 +: 2]))*7 +: 7]   = '0;
          rn_n[i_*2 +: 2] = rn_n[i_*2 +: 2] + 2'd1;
        end
      end
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      qe_q <= '0; qn_q <= '0; re_q <= '0; rn_q <= '0; ra_q <= '0; pres_q <= '0;
    end else begin
      qe_q <= qe_n; qn_q <= qn_n; re_q <= re_n; rn_q <= rn_n; ra_q <= ra_n;
      for (int m = 0; m < NM; m++)
        pres_q[m*7 +: 7] <= (mv[m] && !m_req_ready[m]) ? pres_q[m*7 +: 7] + ((pres_q[m*7 +: 7] != 7'd127) ? 7'd1 : 7'd0) : '0;
    end
  end

  // ================================================================ properties
  logic [1:0]  th_q, mh_q;
  logic [23:0] th_d;
  logic [11:0] mh_d;
  initial begin th_q = '0; mh_q = '0; th_d = '0; mh_d = '0; end
  always_ff @(posedge clk) begin
    th_q <= t_req_valid & ~t_req_ready;
    mh_q <= m_rsp_valid & ~m_rsp_ready;
    for (int t = 0; t < NT; t++) th_d[t*12 +: 12] <= {t_req_opcode[t*3 +: 3], t_req_src[t], t_req_addr[t*8 +: 8]};
    for (int m = 0; m < NM; m++) mh_d[m*6 +: 6] <= {m_rsp_id[m], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2]};
  end

  int ia, ib;
  always_comb begin
    ia = 0; ib = 0;
    if (rst_n) begin
    assert (!ovf);                                                                      // E4 (model capacity) / E2
    for (ia = 0; ia < NT; ia++) assert (!o_bsrc[ia]);                                 // E2 no completion discarded
    for (ia = 0; ia < NT; ia++) if (t_req_valid[ia]) begin
      ib = 32'(t_req_src[ia]) * 2 + ia;
      assert (EN[32'(t_req_src[ia])*NT + ia]);                                         // E1 legal source
      assert (32'(t_req_addr[ia*8 + 7]) == ia);                                        // E1 legal window
      assert (t_req_opcode[ia*3 +: 3] <= 3'd2);
      // queue checks on the handshake: with 0 link stages a request is presented to the target in the
      // cycle it is presented by the master, and neither side has accepted it while the target refuses
      if (tqhs[ia]) begin
        assert (qn_f[ib*2 +: 2] != 2'd0);                                               // E1 nothing invented
        assert ({t_req_opcode[ia*3 +: 3], t_req_id[ia], t_req_addr[ia*8 +: 8]} == qe_f[ib*3*QE + 9 +: 12]);   // E1 order
        if (t_req_opcode[ia*3 +: 3] != sfn_pkg::OP_READ)
          assert ({t_req_wdata[ia*8 +: 8], t_req_wstrb[ia]} == qe_f[ib*3*QE +: 9]);    // E1 integrity
      end
    end
    for (ia = 0; ia < NM; ia++) begin
      assert (32'(o_out[ia*2 +: 2]) <= 2);                                             // E4
      assert (pres_q[ia*7 +: 7] < 7'(B));                                               // E5 acceptance
      if (m_rsp_valid[ia]) assert (m_rsp_opcode[ia*3 +: 3] != sfn_pkg::OP_WRITE_POSTED);   // E2 posted never delivered
      assert (!o_orph[ia]);                                                             // E2 no completion discarded
      if (mrhs[ia]) begin                                                               // (same reason: handshake)
        ib = ia * 2 + 32'(m_rsp_id[ia]);
        assert (rn_f[ib*2 +: 2] != 2'd0);                                               // E2 nothing unexpected
        assert (m_rsp_opcode[ia*3 +: 3] == re_f[(ib*2)*RE + 10 +: 3]);                  // E2 ownership + order
        assert (re_f[(ib*2)*RE + 13]);                                                  // answered (target or fabric)
        assert ({m_rsp_status[ia*2 +: 2], m_rsp_rdata[ia*8 +: 8]} == re_f[(ib*2)*RE +: 10]);   // E2 data / status
      end
    end
    for (ia = 0; ia < 4; ia++) begin
      if (rn_q[ia*2 +: 2] > 2'd0) assert (ra_q[(ia*2)*7 +: 7] < 7'(B));                 // E5 response
      if (rn_q[ia*2 +: 2] > 2'd1) assert (ra_q[(ia*2 + 1)*7 +: 7] < 7'(B));
    end
    end
  end
  always_ff @(posedge clk) if (rst_n) begin
    for (int t = 0; t < NT; t++)
      if (th_q[t]) assert (t_req_valid[t] && th_d[t*12 +: 12] == {t_req_opcode[t*3 +: 3], t_req_src[t], t_req_addr[t*8 +: 8]});  // E3
    for (int m = 0; m < NM; m++)
      if (mh_q[m]) assert (m_rsp_valid[m] && mh_d[m*6 +: 6] == {m_rsp_id[m], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2]});    // E3
  end
`endif
endmodule
