// =============================================================================
// SilicaFlux SRAMController :: fv_sramc_arb   (formal harness, Yosys read_verilog -formal)
// Properties of sf_sramc_arb for ALL request sequences from reset:
//   P1  grant is a subset of req, at most one grant                       (no double-booking)
//   P2  work conserving: any request  =>  exactly one grant
//   P3  bounded waiting (NO STARVATION): a requester that keeps `req` asserted is granted after
//         PRIO_EN=0 : at most N-1 grants to others
//         PRIO_EN=1 : HIGH requester: <= (NH-1) + 1 + (NH-1)/HP_LIMIT others;  LOW: <= (NL-1) + HP_LIMIT*NL
// Environment assumption (the ONLY one): a request stays asserted until it is granted.  It is
// realised constructively (req = req_in | pend_q), not as an assume.
// =============================================================================
`default_nettype none
module fv_sramc_arb #(
  parameter int          N        = 3,
  parameter int          PRIO     = 0,
  parameter logic [15:0] HPM      = 16'h0001,
  parameter int          HPL      = 2
) (
  input wire clk,
  input wire [N-1:0] req_in
);
  reg init_q = 1'b1;
  always @(posedge clk) init_q <= 1'b0;
  wire rst_n = ~init_q;

  reg  [N-1:0] pend_q;
  wire [N-1:0] req = req_in | pend_q;
  wire [N-1:0] grant;
  wire [$clog2(N > 1 ? N : 2)-1:0] gidx;
  wire any;

  sf_sramc_arb #(.N(N), .PRIO_EN(PRIO), .HP_MASK(HPM), .HP_LIMIT(HPL)) dut (
    .clk(clk), .rst_n(rst_n), .req(req), .grant(grant), .grant_idx(gidx), .any(any)
  );

  always @(posedge clk) begin
    if (init_q) pend_q <= {N{1'b0}};
    else        pend_q <= req & ~grant;
  end

  // bound for requester i
  function automatic integer bound_of(input integer i);
    integer nh, nl, k;
    begin
      nh = 0; nl = 0;
      for (k = 0; k < N; k = k + 1) begin
        if (PRIO != 0 && HPM[k]) nh = nh + 1; else nl = nl + 1;
      end
      if (PRIO == 0)      bound_of = N - 1;
      else if (HPM[i])    bound_of = (nh - 1) + 1 + (nh - 1) / HPL;
      else                bound_of = (nl - 1) + HPL * nl;
    end
  endfunction

  reg [7:0] w [0:N-1];       // consecutive waiting cycles
  integer i;
  always @(posedge clk) begin
    if (init_q) begin
      for (i = 0; i < N; i = i + 1) w[i] <= 8'd0;
    end else begin
      assert((grant & ~req) == {N{1'b0}});
      assert((grant & (grant - 1'b1)) == {N{1'b0}});
      assert(any == (|req));
      assert((|grant) == any);
      for (i = 0; i < N; i = i + 1) begin
        if (req[i] && !grant[i]) begin
          assert(w[i] < bound_of(i));
          w[i] <= w[i] + 8'd1;
        end else begin
          w[i] <= 8'd0;
        end
      end
    end
  end
endmodule
`default_nettype wire
