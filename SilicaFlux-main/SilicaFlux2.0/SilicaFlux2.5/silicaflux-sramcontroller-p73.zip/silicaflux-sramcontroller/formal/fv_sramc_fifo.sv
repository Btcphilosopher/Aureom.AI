// =============================================================================
// SilicaFlux SRAMController :: fv_sramc_fifo   (formal harness)
// sf_sramc_fifo against an independent reference queue, for ALL push/pop sequences (no environment
// assumption at all -- including push-when-full and pop-when-empty):
//   F1 count / empty / full always match the reference
//   F2 the head is the oldest accepted entry (FIFO order, no loss, no duplication, no corruption)
//   F3 overflow pulses exactly when a push meets a full FIFO that is not popped in that cycle;
//      such a push is dropped and changes nothing; underflow pulses exactly on pop-when-empty
//   F4 the head is stable while there is no pop (response stability under back-pressure)
// =============================================================================
`default_nettype none
module fv_sramc_fifo #(
  parameter int WIDTH = 2,
  parameter int DEPTH = 3
) (
  input wire             clk,
  input wire             push_in,
  input wire [WIDTH-1:0] din,
  input wire             pop_in
);
  reg init_q = 1'b1;
  always @(posedge clk) init_q <= 1'b0;
  wire rst_n = ~init_q;

  wire [WIDTH-1:0] head;
  wire empty, full, ovf, udf;
  wire [$clog2(DEPTH+1)-1:0] count;

  sf_sramc_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (
    .clk(clk), .rst_n(rst_n), .push(push_in), .push_data(din), .pop(pop_in),
    .pop_data(head), .empty(empty), .full(full), .count(count), .overflow(ovf), .underflow(udf)
  );

  // reference: shift queue, element 0 = oldest
  reg [WIDTH-1:0] q [0:DEPTH-1];
  reg [7:0]       n;
  reg             prev_hold;
  reg [WIDTH-1:0] prev_head;
  integer k;
  wire r_empty = (n == 0);
  wire r_full  = (n == DEPTH);
  wire r_pop   = pop_in && !r_empty;
  wire r_push  = push_in && (!r_full || r_pop);

  always @(posedge clk) begin
    if (init_q) begin
      n <= 8'd0; prev_hold <= 1'b0; prev_head <= {WIDTH{1'b0}};
      for (k = 0; k < DEPTH; k = k + 1) q[k] <= {WIDTH{1'b0}};
    end else begin
      // checks on the cycle that just started
      assert(count == n);
      assert(empty == r_empty);
      assert(full == r_full);
      if (!r_empty) assert(head == q[0]);
      assert(ovf == (push_in && r_full && !r_pop));
      assert(udf == (pop_in && r_empty));
      if (prev_hold && !r_empty) assert(head == prev_head);       // F4
      // reference update
      if (r_pop) begin
        for (k = 0; k < DEPTH - 1; k = k + 1) q[k] <= q[k + 1];
      end
      if (r_push) q[n - (r_pop ? 8'd1 : 8'd0)] <= din;
      n <= n + (r_push ? 8'd1 : 8'd0) - (r_pop ? 8'd1 : 8'd0);
      prev_hold <= !r_empty && !pop_in;
      prev_head <= head;
    end
  end
endmodule
`default_nettype wire
