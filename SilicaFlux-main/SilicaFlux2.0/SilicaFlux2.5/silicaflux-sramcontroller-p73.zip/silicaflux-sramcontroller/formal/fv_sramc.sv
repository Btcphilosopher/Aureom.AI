// =============================================================================
// SilicaFlux SRAMController :: fv_sramc   (formal harness, Yosys read_verilog -formal)
//
// DUT: sf_sram_controller with ABSTRACT banks (any in-order bank: free ready, free completion
// timing, free data/error) and FREE masters.  Environment assumptions (the only ones):
//   E1  master request stability, SFB2 R2 (embedded SFC_ASM; disabled with -DSFC_NO_STABILITY)
//   E2  bank contract: a completion only for an access that is outstanding (embedded SFC_ASM)
//   E3  the marked-transaction selection (K_M, K_N) is constant
//   (LIVE=1 only)  bounded environment: banks respond within BL cycles, bk_req_ready at least every BR cycles,
//                  response-ready within RL cycles, no flush.
// Properties
//   * every embedded SFC_CHK of the controller (grants, trackers, credits, FIFO safety, in-order rule,
//     response stability, ID/type routing against the independent order queue, fairness, ...)
//   * MARKED TRANSACTION (independent scoreboard, written from the specification, not from the RTL):
//     the (K_N+1)-th request accepted from master K_M is followed through the design using only the
//     interface signals; its response must carry the right ID / type / source / status / data, exactly once,
//     in order, to the right master.  This is "no accepted request loss, no duplicate completion, correct
//     response routing" for an arbitrary transaction, arbitrary master, arbitrary interleaving.
//   * per-master accounting: a response is transferred only while a request is outstanding; idle <=> nothing
//     outstanding.
//   * LIVE=1: bounded completion -- the marked transaction is delivered within TL cycles (BMC-bounded).
// PROBE=k>0 : reachability probe k is asserted NOT to happen; a counter-example proves the scenario is reachable
//   (non-vacuity of the proof).  See PROBES in docs/03.
// =============================================================================
`include "sf_sramc_defs.svh"
`default_nettype none

module fv_sramc #(
  parameter int          NM     = 2,
  parameter int          NB     = 2,
  parameter int          DW     = 16,
  parameter int          BD     = 2,
  parameter int          IDW    = 1,
  parameter int          MAXOUT = 2,
  parameter int          BOUT   = 2,
  parameter int          PRIO   = 0,
  parameter logic [15:0] HPM    = 16'h0001,
  parameter int          HPL    = 2,
  parameter int          IDCHK  = 1,
  parameter int          LIVE   = 0,
  parameter int          TL     = 24,
  parameter int          BL     = 2,
  parameter int          RL     = 2,
  parameter int          BR     = 2,
  parameter int          PROBE  = 0,
  parameter int          KN_MAX = 2,
  parameter int          UNI    = 0,       // 1: banks are FIXED-latency (every access completes exactly UL cycles after issue)
  parameter int          UL     = 2,
  parameter int          DUTUNI = 0,       // value of the controller's UNIFORM_LAT parameter
  localparam int NBYTE = DW / 8,
  localparam int MW    = (NM > 1) ? $clog2(NM) : 1,
  localparam int SRCW  = MW,
  localparam int AW    = 8,
  localparam int RAW   = (BD > 1) ? $clog2(BD) : 1,
  localparam int TOTAL = NB * BD * NBYTE
) (
  input wire                 clk,
  input wire [NM-1:0]        m_req_valid, m_req_we, m_req_err, m_rsp_ready, src_en,
  input wire [NM*AW-1:0]     m_req_addr,
  input wire [NM*DW-1:0]     m_req_wdata,
  input wire [NM*NBYTE-1:0]  m_req_wstrb,
  input wire [NM*IDW-1:0]    m_req_id,
  input wire [NM*SRCW-1:0]   m_req_src,
  input wire                 flush,
  input wire [NB-1:0]        bk_req_ready, bk_rsp_valid_in, bk_rsp_err_in,
  input wire [NB*DW-1:0]     bk_rsp_rdata_in,
  input wire [MW-1:0]        K_M_in,
  input wire [1:0]           K_N_in
);
  reg init_q = 1'b1;
  always @(posedge clk) init_q <= 1'b0;
  wire rst_n = ~init_q;
  wire ok = ~init_q;

  // ---------------------------------------------------------------- DUT
  wire [NM-1:0]        m_req_ready, m_rsp_valid, m_rsp_we, m_rsp_err;
  wire [NM*DW-1:0]     m_rsp_rdata;
  wire [NM*IDW-1:0]    m_rsp_id;
  wire [NM*SRCW-1:0]   m_rsp_src;
  wire [NM*4-1:0]      m_rsp_status;
  wire                 idle, sts_ovf, sts_proto;
  wire [NB-1:0]        bk_req_valid, bk_req_we;
  wire [NB*RAW-1:0]    bk_req_addr;
  wire [NB*DW-1:0]     bk_req_wdata;
  wire [NB*NBYTE-1:0]  bk_req_wstrb;
  wire [31:0]          perf_val_unused;
  // bank completions: free (any in-order bank) or a FIXED-latency pipeline of UL stages
  wire [NB-1:0]        bk_rsp_valid, bk_rsp_err;
  wire [NB*DW-1:0]     bk_rsp_rdata;
  generate if (UNI != 0) begin : g_unibank
    reg [UL*NB-1:0]       pvf;
    reg [UL*NB-1:0]       pef;
    reg [UL*NB*DW-1:0]    pdf;
    integer ub, uk;
    always @(posedge clk) begin
      for (ub = 0; ub < NB; ub = ub + 1) begin
        if (init_q) begin
          pvf[ub*UL +: UL] <= {UL{1'b0}};
        end else begin
          pvf[ub*UL] <= bk_req_valid[ub];
          pef[ub*UL] <= bk_rsp_err_in[ub];
          pdf[(ub*UL)*DW +: DW] <= bk_rsp_rdata_in[ub*DW +: DW];
          for (uk = 1; uk < UL; uk = uk + 1) begin
            pvf[ub*UL + uk] <= pvf[ub*UL + uk - 1];
            pef[ub*UL + uk] <= pef[ub*UL + uk - 1];
            pdf[(ub*UL + uk)*DW +: DW] <= pdf[(ub*UL + uk - 1)*DW +: DW];
          end
        end
      end
    end
    genvar gb;
    for (gb = 0; gb < NB; gb = gb + 1) begin : g_b
      assign bk_rsp_valid[gb]          = pvf[gb*UL + UL - 1];
      assign bk_rsp_err[gb]            = pef[gb*UL + UL - 1];
      assign bk_rsp_rdata[gb*DW +: DW] = pdf[(gb*UL + UL - 1)*DW +: DW];
    end
  end else begin : g_freebank
    assign bk_rsp_valid = bk_rsp_valid_in;
    assign bk_rsp_err   = bk_rsp_err_in;
    assign bk_rsp_rdata = bk_rsp_rdata_in;
  end endgenerate

  sf_sram_controller #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .BANK_DEPTH(BD), .ADDR_WIDTH(AW), .ID_WIDTH(IDW),
    .MAX_OUT(MAXOUT), .BANK_OUT(BOUT), .UNIFORM_LAT(DUTUNI), .INTERLEAVE(`SFC_ILV_LOW), .ID_CHECK(IDCHK), .SRC_CHECK(1),
    .MASK_MODE(`SFC_MASK_ANY), .PRIO_EN(PRIO), .HP_MASK(HPM), .HP_LIMIT(HPL), .PERF_EN(0), .CNT_W(32)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_req_id(m_req_id), .m_req_src(m_req_src),
    .m_req_err(m_req_err), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata),
    .m_rsp_id(m_rsp_id), .m_rsp_src(m_rsp_src), .m_rsp_we(m_rsp_we), .m_rsp_err(m_rsp_err),
    .m_rsp_status(m_rsp_status), .src_en(src_en), .flush(flush), .idle(idle),
    .sts_rsp_overflow(sts_ovf), .sts_bank_proto(sts_proto),
    .bk_req_valid(bk_req_valid), .bk_req_ready(bk_req_ready), .bk_req_we(bk_req_we), .bk_req_addr(bk_req_addr),
    .bk_req_wdata(bk_req_wdata), .bk_req_wstrb(bk_req_wstrb),
    .bk_rsp_valid(bk_rsp_valid), .bk_rsp_rdata(bk_rsp_rdata), .bk_rsp_err(bk_rsp_err),
    .perf_clr(1'b0), .perf_sel(6'd0), .perf_val(perf_val_unused)
  );

  // ---------------------------------------------------------------- E3: constant selection (+ bank contract from the interface)
  // (the embedded SFC_ASM states the same contract on the DUT's internal tracker; this one uses interface events only)
  reg [MW-1:0] k_m_q;
  reg [1:0]    k_n_q;
  always @(posedge clk) begin
    k_m_q <= K_M_in;
    k_n_q <= K_N_in;
    if (ok) begin
      assume(K_M_in == k_m_q);
      assume(K_N_in == k_n_q);
    end
  end
  wire [MW-1:0] K_M = K_M_in;
  wire [1:0]    K_N = K_N_in;
  always @(posedge clk) begin
    assume(K_M_in < NM);
    assume(K_N_in <= KN_MAX);        // the marked request is one of the first KN_MAX+1 requests of its master
  end

  // ---------------------------------------------------------------- shadow state (interface events only)
  reg [3:0] acc_cnt [0:NM-1];
  reg [3:0] rsp_cnt [0:NM-1];
  reg [3:0] infl    [0:NB-1];
  reg [1:0] idc     [0:NM*(1<<IDW)-1];
  reg [3:0] bwait   [0:NB-1];
  reg [3:0] bnr     [0:NB-1];
  reg [3:0] rwait   [0:NM-1];

  wire [NM-1:0] acc  = m_req_valid & m_req_ready;
  wire [NM-1:0] xfer = m_rsp_valid & m_rsp_ready;

  function automatic integer bank_of(input [AW-1:0] a);
    integer w;
    begin
      w = a >> $clog2(NBYTE);
      bank_of = (NB == 1) ? 0 : (w % NB);
    end
  endfunction

  function automatic [RAW-1:0] row_of(input [AW-1:0] a);
    integer w;
    begin
      w = a >> $clog2(NBYTE);
      row_of = (NB == 1) ? w : (w / NB);
    end
  endfunction

  function automatic [3:0] xstatus(input integer m, input [AW-1:0] a, input we, input [NBYTE-1:0] ws,
                                   input [IDW-1:0] id, input [SRCW-1:0] src, input perr, input srcen, input idhit);
    reg [3:0] st;
    begin
      st = `SFC_ST_OK;
      if (we && ws == {NBYTE{1'b0}})   st = `SFC_ST_MASK;
      if ((a & (NBYTE - 1)) != 0)      st = `SFC_ST_ALIGN;
      if (a >= TOTAL)                  st = `SFC_ST_RANGE;
      if (idhit)                       st = `SFC_ST_ID;
      if (perr)                        st = `SFC_ST_POISON;
      if (!srcen || src != m)          st = `SFC_ST_SRC;
      xstatus = st;
    end
  endfunction

  // fields of the master that is under observation (K_M)
  wire [AW-1:0]    k_addr = m_req_addr[K_M*AW +: AW];
  wire             k_we   = m_req_we[K_M];
  wire [NBYTE-1:0] k_ws   = m_req_wstrb[K_M*NBYTE +: NBYTE];
  wire [IDW-1:0]   k_id   = m_req_id[K_M*IDW +: IDW];
  wire [SRCW-1:0]  k_src  = m_req_src[K_M*SRCW +: SRCW];
  // expected status of the request currently presented by EVERY master (independent re-implementation of the spec)
  wire [3:0] est_w [0:NM-1];
  genvar ge;
  generate for (ge = 0; ge < NM; ge = ge + 1) begin : g_est
    wire [IDW-1:0] pid  = m_rsp_id[ge*IDW +: IDW];
    wire [IDW-1:0] rid  = m_req_id[ge*IDW +: IDW];
    wire           hit  = (IDCHK != 0) && ((idc[ge*(1<<IDW) + rid] - ((xfer[ge] && pid == rid) ? 2'd1 : 2'd0)) != 2'd0);
    assign est_w[ge] = xstatus(ge, m_req_addr[ge*AW +: AW], m_req_we[ge], m_req_wstrb[ge*NBYTE +: NBYTE], rid,
                               m_req_src[ge*SRCW +: SRCW], m_req_err[ge], src_en[ge], hit);
  end endgenerate
  wire [3:0]       k_est   = est_w[K_M];

  reg              mk_acc, mk_we, mk_bank_t, mk_inbank, mk_cdone, mk_berr, mk_cancel, mk_done;
  reg [IDW-1:0]    mk_id;
  reg [3:0]        mk_st;
  reg [3:0]        mk_ahead;
  reg [MW-1:0]     mk_b_idx_unused;
  reg [31:0]       mk_b;
  reg [DW-1:0]     mk_data;
  reg [7:0]        mk_age;

  wire mk_sel_acc = ok && acc[K_M] && (acc_cnt[K_M] == {2'b00, K_N}) && !mk_acc;
  wire mk_complete_now = mk_inbank && bk_rsp_valid[mk_b] && (mk_ahead == 4'd0);
  wire [3:0] r_st  = m_rsp_status[K_M*4 +: 4];
  wire       r_xfer_marked = ok && xfer[K_M] && (rsp_cnt[K_M] == {2'b00, K_N}) && mk_acc && !mk_done;

  integer m, b, i;
  always @(posedge clk) begin
    if (init_q) begin
      for (m = 0; m < NM; m = m + 1) begin acc_cnt[m] <= 4'd0; rsp_cnt[m] <= 4'd0; rwait[m] <= 4'd0; end
      for (b = 0; b < NB; b = b + 1) begin infl[b] <= 4'd0; bwait[b] <= 4'd0; bnr[b] <= 4'd0; end
      for (i = 0; i < NM*(1<<IDW); i = i + 1) idc[i] <= 2'd0;
      mk_acc <= 1'b0; mk_we <= 1'b0; mk_bank_t <= 1'b0; mk_inbank <= 1'b0; mk_cdone <= 1'b0; mk_berr <= 1'b0;
      mk_cancel <= 1'b0; mk_done <= 1'b0; mk_id <= {IDW{1'b0}}; mk_st <= 4'd0; mk_ahead <= 4'd0; mk_b <= 32'd0;
      mk_data <= {DW{1'b0}}; mk_age <= 8'd0;
    end else begin
      // ---- counters
      for (m = 0; m < NM; m = m + 1) begin
        if (acc[m])  acc_cnt[m] <= acc_cnt[m] + 4'd1;
        if (xfer[m]) rsp_cnt[m] <= rsp_cnt[m] + 4'd1;
        rwait[m] <= (m_rsp_valid[m] && !m_rsp_ready[m]) ? ((rwait[m] == 4'd15) ? 4'd15 : rwait[m] + 4'd1) : 4'd0;
      end
      for (b = 0; b < NB; b = b + 1) begin
        infl[b] <= infl[b] + (bk_req_valid[b] ? 4'd1 : 4'd0) - (bk_rsp_valid[b] ? 4'd1 : 4'd0);
        bwait[b] <= (infl[b] != 4'd0 && !bk_rsp_valid[b]) ? ((bwait[b] == 4'd15) ? 4'd15 : bwait[b] + 4'd1) : 4'd0;
        bnr[b] <= (!bk_req_ready[b]) ? ((bnr[b] == 4'd15) ? 4'd15 : bnr[b] + 4'd1) : 4'd0;
      end
      // ---- ID shadow: every accepted request (any status) holds its ID until its response is transferred
      for (m = 0; m < NM; m = m + 1) begin
        if (acc[m] && !(xfer[m] && m_rsp_id[m*IDW +: IDW] == m_req_id[m*IDW +: IDW]))
          idc[m*(1<<IDW) + m_req_id[m*IDW +: IDW]] <= idc[m*(1<<IDW) + m_req_id[m*IDW +: IDW]] + 2'd1;
        if (xfer[m] && !(acc[m] && m_rsp_id[m*IDW +: IDW] == m_req_id[m*IDW +: IDW]))
          idc[m*(1<<IDW) + m_rsp_id[m*IDW +: IDW]] <= idc[m*(1<<IDW) + m_rsp_id[m*IDW +: IDW]] - 2'd1;
      end
      // ---- marked transaction
      if (mk_sel_acc) begin
        mk_acc <= 1'b1; mk_we <= k_we; mk_id <= k_id; mk_st <= k_est; mk_bank_t <= (k_est == `SFC_ST_OK);
        if (k_est == `SFC_ST_OK) begin
          mk_inbank <= 1'b1;
          mk_b <= bank_of(k_addr);
          mk_ahead <= infl[bank_of(k_addr)] - (bk_rsp_valid[bank_of(k_addr)] ? 4'd1 : 4'd0);
        end
      end
      if (mk_inbank) begin
        if (flush && !mk_complete_now) mk_cancel <= 1'b1;
        if (bk_rsp_valid[mk_b]) begin
          if (mk_ahead == 4'd0) begin
            mk_inbank <= 1'b0; mk_cdone <= 1'b1; mk_data <= bk_rsp_rdata[mk_b*DW +: DW]; mk_berr <= bk_rsp_err[mk_b];
          end else mk_ahead <= mk_ahead - 4'd1;
        end
      end
      if (r_xfer_marked) mk_done <= 1'b1;
      if (mk_acc && !mk_done) mk_age <= (mk_age == 8'd255) ? 8'd255 : mk_age + 8'd1;
    end
  end

  // ---------------------------------------------------------------- liveness environment (LIVE=1)
  generate if (LIVE != 0) begin : g_live
    always @(posedge clk) begin
      assume(!flush);
      for (b = 0; b < NB; b = b + 1) begin
        if (infl[b] != 4'd0 && bwait[b] >= BL - 1) assume(bk_rsp_valid[b]);
        if (bnr[b] >= BR - 1) assume(bk_req_ready[b]);
      end
      for (m = 0; m < NM; m = m + 1)
        if (rwait[m] >= RL - 1) assume(m_rsp_ready[m] || !m_rsp_valid[m]);
    end
  end endgenerate

  // ---------------------------------------------------------------- properties
  reg [31:0] mk_exp_st;
  always @(posedge clk) begin
    if (ok) begin
      // accounting: a response is transferred only while a request is outstanding; idle <=> nothing outstanding
      for (m = 0; m < NM; m = m + 1) begin
        if (xfer[m]) assert(acc_cnt[m] != rsp_cnt[m]);
        assert(m_rsp_valid[m] == 1'b0 || acc_cnt[m] != rsp_cnt[m]);
      end
      begin : idle_chk
        reg any_out;
        any_out = 1'b0;
        for (m = 0; m < NM; m = m + 1) if (acc_cnt[m] != rsp_cnt[m]) any_out = 1'b1;
        assert(idle == !any_out);
      end
      assert(!sts_ovf && !sts_proto);
      // bank side: every accepted error-free request issues EXACTLY ONE bank access, errors issue none
      begin : issue_chk
        integer n_issue, n_ok;
        n_issue = 0; n_ok = 0;
        for (b = 0; b < NB; b = b + 1) if (bk_req_valid[b]) n_issue = n_issue + 1;
        for (m = 0; m < NM; m = m + 1) if (acc[m] && est_w[m] == `SFC_ST_OK) n_ok = n_ok + 1;
        assert(n_issue == n_ok);
      end
      // ... and the marked request reaches its bank with the right row, direction, data and strobes
      if (mk_sel_acc && k_est == `SFC_ST_OK) begin
        assert(bk_req_valid[bank_of(k_addr)]);
        assert(bk_req_we[bank_of(k_addr)] == k_we);
        assert(bk_req_addr[bank_of(k_addr)*RAW +: RAW] == row_of(k_addr));
        if (k_we) begin
          assert(bk_req_wdata[bank_of(k_addr)*DW +: DW] == m_req_wdata[K_M*DW +: DW]);
          assert(bk_req_wstrb[bank_of(k_addr)*NBYTE +: NBYTE] == k_ws);
        end
      end
      // the marked transaction's response
      if (r_xfer_marked) begin
        assert(m_rsp_id[K_M*IDW +: IDW] == mk_id);
        assert(m_rsp_we[K_M] == mk_we);
        assert(m_rsp_src[K_M*SRCW +: SRCW] == K_M);
        assert(m_rsp_err[K_M] == (r_st != `SFC_ST_OK));
        if (!mk_bank_t) begin
          assert(r_st == mk_st);
          assert(m_rsp_rdata[K_M*DW +: DW] == {DW{1'b0}});
        end else begin
          assert(mk_cdone);
          if (mk_cancel)      assert(r_st == `SFC_ST_CANCEL);
          else if (mk_berr)   assert(r_st == `SFC_ST_BANK);
          else                assert(r_st == `SFC_ST_OK);
          if (r_st == `SFC_ST_OK && !mk_we) assert(m_rsp_rdata[K_M*DW +: DW] == mk_data);
          else                              assert(m_rsp_rdata[K_M*DW +: DW] == {DW{1'b0}});
        end
      end
      // bounded completion (LIVE)
      if (LIVE != 0) assert(!(mk_acc && !mk_done && mk_age >= TL));
    end
  end

  // ---------------------------------------------------------------- reachability probes
  wire [NM-1:0] outstanding2;
  genvar gi;
  generate for (gi = 0; gi < NM; gi = gi + 1) begin : g_o2
    assign outstanding2[gi] = ((acc_cnt[gi] - rsp_cnt[gi]) == 4'd2);
  end endgenerate
  reg probe_hit;
  reg prev_stall0;
  always @(posedge clk) begin
    prev_stall0 <= m_rsp_valid[0] && !m_rsp_ready[0];
    probe_hit = 1'b0;
    case (PROBE)
      1:  probe_hit = (NB > 1) && (bk_req_valid == {NB{1'b1}});                       // every bank accessed in one cycle
      2:  probe_hit = (NM > 1) && m_req_valid[0] && m_req_valid[1] && (m_req_ready == 2'b01 || m_req_ready == 2'b10) &&
                      (bank_of(m_req_addr[AW-1:0]) == bank_of(m_req_addr[2*AW-1:AW])) &&
                      xstatus(0, m_req_addr[AW-1:0], m_req_we[0], m_req_wstrb[NBYTE-1:0], m_req_id[IDW-1:0], m_req_src[SRCW-1:0], m_req_err[0], src_en[0], 1'b0) == `SFC_ST_OK &&
                      xstatus(1, m_req_addr[2*AW-1:AW], m_req_we[1], m_req_wstrb[2*NBYTE-1:NBYTE], m_req_id[2*IDW-1:IDW], m_req_src[2*SRCW-1:SRCW], m_req_err[1], src_en[1], 1'b0) == `SFC_ST_OK;  // two masters, same bank, one loses
      3:  probe_hit = prev_stall0 && m_rsp_valid[0] && !m_rsp_ready[0];                // response held for 2+ cycles
      4:  probe_hit = r_xfer_marked && mk_bank_t && !mk_we && !mk_cancel && !mk_berr && (m_rsp_rdata[K_M*DW +: DW] != {DW{1'b0}});
      5:  probe_hit = r_xfer_marked && r_st == `SFC_ST_ID;
      6:  probe_hit = r_xfer_marked && r_st == `SFC_ST_CANCEL;
      7:  probe_hit = r_xfer_marked && r_st == `SFC_ST_BANK;
      8:  probe_hit = r_xfer_marked && r_st == `SFC_ST_RANGE;
      9:  probe_hit = r_xfer_marked && r_st == `SFC_ST_ALIGN;
      10: probe_hit = r_xfer_marked && r_st == `SFC_ST_MASK;
      11: probe_hit = r_xfer_marked && r_st == `SFC_ST_SRC;
      12: probe_hit = r_xfer_marked && r_st == `SFC_ST_POISON;
      13: probe_hit = |outstanding2;                                                    // a master with two outstanding
      14: probe_hit = r_xfer_marked && mk_bank_t && mk_we && r_st == `SFC_ST_OK;        // marked write completed OK
      15: probe_hit = r_xfer_marked && mk_bank_t && !mk_we && r_st == `SFC_ST_OK;       // marked read completed OK
      default: probe_hit = 1'b0;
    endcase
    if (ok && PROBE != 0) assert(!probe_hit);
  end
endmodule
`default_nettype wire
