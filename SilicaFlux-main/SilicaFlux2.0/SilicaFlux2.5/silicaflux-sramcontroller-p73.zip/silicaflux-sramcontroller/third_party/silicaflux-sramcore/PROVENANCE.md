# Provenance

`rtl/sram/sf_sram_core.sv`, `sf_sram_array.sv`, `sf_sram_defs.svh` are **SilicaFlux SRAMCore (Project 71)** files copied **unmodified** from
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramcore-p71.zip` (`silicaflux-sramcore/rtl/sram/`).
Their SHA-256 equals the entries in that archive's own `SHA256SUMS`:

```
2f19335dc35b7a353d0b91a20cbea4cc244cf506dbb071c54a1e8bea8c831751  rtl/sram/sf_sram_array.sv
6516d1b5ee90ddc38f16e847746188cf1dce158cb7276f11232fa51a9a251068  rtl/sram/sf_sram_core.sv
ad933db0a02c0af1d218faea690641d4d031958b693f5acf370ee1ad21406776  rtl/sram/sf_sram_defs.svh
```
Verification evidence for these files is that project's own (`reports/SUMMARY.md` there: 50 simulation runs, mutation 22/22, Yosys synthesis, gate-level simulation); it is not repeated here.
