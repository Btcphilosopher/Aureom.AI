#!/usr/bin/env python3
"""Mutation sanity: inject RTL bugs, run the self-checking simulations, every mutant must be KILLED
(testbench failure or embedded-assertion firing).  A survivor is reported honestly as SURVIVED.
usage: run_mutants.py [--only REGEX] [--jobs N]"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import *   # noqa

C = "rtl/sramc/sf_sram_controller.sv"
A = "rtl/sramc/sf_sramc_arb.sv"
F = "rtl/sramc/sf_sramc_fifo.sv"
P = "rtl/sramc/sf_sramc_perf.sv"
B = "rtl/sramc/sf_sramc_bank.sv"

# (id, file, old, new, description, ordered list of configurations to try)
D = ["s3_4x4_o2", "v_4x4_o4", "s3_4x4_lat_o2", "s1_1x1", "s3_4x4_prio", "s3_4x4_mask1", "s3_4x4_idchk0", "v_4x4_bout1", "s3_4x4_high_o4"]
MUT = [
 ("M01", C, "bank_ok[m]   = (UNIFORM_LAT != 0) || (bf_q[m] == '0) || (lkb_q[m] == d_bank[m]);", "bank_ok[m]   = 1'b1;", "in-order (bank-lock) rule removed: a master may overtake itself across banks", ["s3_4x4_lat_o2", "v_4x4_o4"]),
 ("M02", C, "can_take[m] && (bf_q[m] == '0);", "can_take[m];", "error response may overtake older accesses still inside a bank", ["s3_4x4_lat_o2", "v_4x4_o4"]),
 ("M03", C, "{MW'(m), m_req_id[m*ID_WIDTH +: ID_WIDTH], m_req_we[m]};", "{MW'((m + 1) % NUM_MASTERS), m_req_id[m*ID_WIDTH +: ID_WIDTH], m_req_we[m]};", "response routed to the next master", D),
 ("M04", C, "b_ent[b] = {dat, h_we, h_id, st};", "b_ent[b] = {dat, h_we, h_id ^ {{(ID_WIDTH-1){1'b0}}, 1'b1}, st};", "response ID corrupted", D),
 ("M05", C, "b_ent[b] = {dat, h_we, h_id, st};", "b_ent[b] = {dat, ~h_we, h_id, st};", "response read/write type inverted", D),
 ("M06", C, "dat = (h_we || st != `SFC_ST_OK) ? {DATA_WIDTH{1'b0}} : bk_rsp_rdata[b*DATA_WIDTH +: DATA_WIDTH];", "dat = (st != `SFC_ST_OK) ? {DATA_WIDTH{1'b0}} : bk_rsp_rdata[b*DATA_WIDTH +: DATA_WIDTH];", "write responses carry bank garbage instead of 0", ["v_4x4_o4", "v_1x1"]),
 ("M07", C, "assign pop_now = ~rf_empty & m_rsp_ready;", "assign pop_now = ~rf_empty;", "response dropped when the master is not ready (no back-pressure)", D),
 ("M08", C, "can_take[m]  = (cnt_q[m] != OW'(MAX_OUT)) || pop_now[m];", "can_take[m]  = 1'b1;", "outstanding limit (credit) removed: response FIFO can overflow", D),
 ("M09", A, "ptr_l_q  <= (pick_l == IW'(N - 1)) ? '0 : pick_l + 1'b1;", "ptr_l_q  <= ptr_l_q;", "round-robin pointer never advances (fixed priority): starvation", ["s3_4x4_o2", "s3_4x4_prio"]),
 ("M10", A, "assign grant     = any ? ({{(N-1){1'b0}}, 1'b1} << pick_sel) : {N{1'b0}};", "assign grant     = req;", "all eligible masters granted: bank double-booking", D),
 ("M11", A, "assign use_hp = (hp_req != {N{1'b0}}) &&\n                  !((streak_q == SW'(HP_LIMIT)) && (lp_req != {N{1'b0}}));", "assign use_hp = (hp_req != {N{1'b0}});", "HIGH class never yields: LOW class starves", ["s3_4x4_prio", "s3_4x4_prio2"]),
 ("M12", C, "d_aln[m]    = ((m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH] & ADDR_WIDTH'(NBYTE - 1)) == '0);", "d_aln[m]    = 1'b1;", "alignment check removed", D),
 ("M13", C, "{1'b0, m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH]} < TOTAL_W);", "{1'b0, m_req_addr[m*ADDR_WIDTH +: ADDR_WIDTH]} <= TOTAL_W);", "range check off by one", D),
 ("M14", C, "d_mskbad[m] = m_req_we[m] && ((m_req_wstrb[m*NBYTE +: NBYTE] == '0) ||", "d_mskbad[m] = m_req_we[m] && ((1'b0) ||", "zero write strobes accepted", D),
 ("M15", C, "d_srcbad[m] = !src_en[m] || ((SRC_CHECK != 0) && (m_req_src[m*SRCW +: SRCW] != SRCW'(m)));", "d_srcbad[m] = !src_en[m];", "source-ID mismatch not detected", D),
 ("M16", C, "if (oq_v_q[m][k] && !(pop_now[m] && oh_q[m] == OPW'(k)) &&", "if (oq_v_q[m][k] &&", "ID reuse flagged against the entry whose response is being transferred this cycle", D),
 ("M17", C, "      if (ID_CHECK != 0) begin\n        for (int k = 0; k < MAX_OUT; k++)", "      if (1'b0) begin\n        for (int k = 0; k < MAX_OUT; k++)", "ID-reuse detection disabled", D),
 ("M18", C, "if (m_req_err[m]) d_st[m] = `SFC_ST_POISON;", "if (1'b0) d_st[m] = `SFC_ST_POISON;", "poisoned request not detected", D),
 ("M19", C, "      if (!d_aln[m])    d_st[m] = `SFC_ST_ALIGN;\n      if (!d_inrng[m])  d_st[m] = `SFC_ST_RANGE;", "      if (!d_inrng[m])  d_st[m] = `SFC_ST_RANGE;\n      if (!d_aln[m])    d_st[m] = `SFC_ST_ALIGN;", "error precedence changed (ALIGN above RANGE)", D),
 ("M20", C, "e_vb[m]      = m_req_valid[m] && live && !flush && !d_err[m] && can_take[m];", "e_vb[m]      = m_req_valid[m] && live && !d_err[m] && can_take[m];", "requests accepted during flush", ["s3_4x4_lat_o2", "v_4x4_o4"]),
 ("M21", C, "if (flush)                              cx_q[b] <= tk_count[b*TW +: TW] - (tk_pop[b] ? TW'(1) : TW'(0));", "if (flush)                              cx_q[b] <= tk_count[b*TW +: TW];", "flush cancels an access that completes in the flush cycle", ["s3_4x4_lat_o2", "v_4x4_o4"]),
 ("M22", C, "else if (tk_pop[b] && cx_q[b] != '0)    cx_q[b] <= cx_q[b] - 1'b1;", "else if (tk_pop[b] && cx_q[b] != '0)    cx_q[b] <= cx_q[b];", "cancel counter never decrements: later responses wrongly cancelled", ["s3_4x4_lat_o2", "v_4x4_o4"]),
 ("M23", C, "bk_req_wstrb[b*NBYTE +: NBYTE]           = m_req_wstrb[m*NBYTE +: NBYTE];", "bk_req_wstrb[b*NBYTE +: NBYTE]           = {NBYTE{1'b1}};", "byte strobes dropped: partial writes overwrite the word", D),
 ("M24", C, "bk_req_wdata[b*DATA_WIDTH +: DATA_WIDTH] = m_req_wdata[m*DATA_WIDTH +: DATA_WIDTH];", "bk_req_wdata[b*DATA_WIDTH +: DATA_WIDTH] = m_req_wdata[m*DATA_WIDTH +: DATA_WIDTH] ^ {{(DATA_WIDTH-1){1'b0}}, 1'b1};", "write data bit 0 corrupted", D),
 ("M25", C, "bk_req_addr[b*RAW +: RAW]                = d_row[m];", "bk_req_addr[b*RAW +: RAW]                = d_row[m] ^ RAW'(1);", "bank row address corrupted", D),
 ("M26", C, "if (gnt_flat[b*NUM_MASTERS + m]) lkb_q[m] <= BW'(b);", "if (gnt_flat[b*NUM_MASTERS + m]) lkb_q[m] <= lkb_q[m];", "locked bank never recorded", ["s3_4x4_lat_o2", "v_4x4_o4"]),
 ("M27", C, "&& (d_bank[m] == BW'(b)) && bk_req_ready[b] && !tk_full[b];", "&& (d_bank[m] == BW'(b)) && !tk_full[b];", "bank issue ignores bank not-ready", ["v_4x4_o1", "v_4x4_o4"]),
 ("M28", C, "&& (d_bank[m] == BW'(b)) && bk_req_ready[b] && !tk_full[b];", "&& (d_bank[m] == BW'(b)) && bk_req_ready[b];", "bank issue ignores tracker full", ["v_4x4_bout1", "v_4x4_o4"]),
 ("M29", F, "wire do_push = push && (!full || do_pop);", "wire do_push = push && !full;", "FIFO drops a push into a full FIFO that is popped in the same cycle", D),
 ("M30", C, "      for (int m = 0; m < NUM_MASTERS; m++) begin\n        cnt_q[m]  <= '0;", "      for (int m = 0; m < NUM_MASTERS; m++) begin\n        cnt_q[m]  <= cnt_q[m];", "outstanding counter survives reset", D),
 ("M31", C, "assign live = rst_n;", "assign live = 1'b1;", "requests accepted while rst_n=0", D),
 ("M32", B, "assign wa_d = wa_q[LAT-2];", "assign wa_d = c_wr_ack;", "bank adapter: write completion not aligned to the read latency (out-of-order completions)", ["s3_4x4_lat_o2", "s1_1x1_o4_lat3"]),
 ("M33", C, "m_rsp_id[m*ID_WIDTH +: ID_WIDTH]        = rf_head[m*RSP_W + 4 +: ID_WIDTH];", "m_rsp_id[m*ID_WIDTH +: ID_WIDTH]        = rf_head[m*RSP_W + 5 +: ID_WIDTH];", "response ID taken from the wrong bit slice", D),
 ("M34", C, "m_rsp_src[m*SRCW +: SRCW]               = SRCW'(m);", "m_rsp_src[m*SRCW +: SRCW]               = '0;", "response source ID not preserved", D),
 ("M35", C, "m_rsp_err[m]                            = (rf_head[m*RSP_W +: 4] != `SFC_ST_OK);", "m_rsp_err[m]                            = (rf_head[m*RSP_W +: 4] == `SFC_ST_OK);", "1-bit error flag inverted", D),
 ("M36", C, "if (cnt_q[m] != '0) idle = 1'b0;", "if (bf_q[m] != '0) idle = 1'b0;", "idle ignores responses waiting in the FIFOs", D),
 ("M37", C, "if (bk_rsp_err[b])    st = `SFC_ST_BANK;", "if (1'b0)              st = `SFC_ST_BANK;", "bank error status not propagated", ["v_4x4_o1", "v_1x1"]),
 ("M38", P, "ev_wait[m]   = p_req_valid[m] && !p_req_ready[m];", "ev_wait[m]   = !p_req_ready[m];", "performance counter: arbitration wait counts idle cycles", D),
 ("M39", P, "m_c[m*16 + `SFC_PM_LAT_SUM]" if False else "`SFC_M(m, `SFC_PM_LAT_SUM) <= `SFC_M(m, `SFC_PM_LAT_SUM) + `SFC_O(m);", "`SFC_M(m, `SFC_PM_LAT_SUM) <= `SFC_M(m, `SFC_PM_LAT_SUM) + `SFC_O(m) + ONE;", "performance counter: latency integral off by one per cycle", D),
 ("M41", "rtl/sramc/sf_sram_subsystem.sv", "localparam int UNIFORM_EFF = (UNIFORM_LAT < 0) ? ((MIN_LAT == MAX_LAT) ? 1 : 0) : UNIFORM_LAT;", "localparam int UNIFORM_EFF = 1;", "UNIFORM_LAT forced on although the banks have different latencies (bank-lock dropped wrongly)", ["s3_4x4_lat_o2", "s3_4x4_high_o4", "s2_1x4_o4_lat"]),
 ("M40", C, "lkb_q[m]  <= '0;\n        oh_q[m]   <= '0;", "lkb_q[m]  <= '0;\n        oh_q[m]   <= oh_q[m];", "order-queue head survives reset", D),
]


def build_and_run(mid, cfgname, mdir: Path):
    cfg = next(c for c in CONFIGS if c["name"] == cfgname)
    out = mdir / "build" / cfgname
    shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True)
    rtl = [str(mdir / f) for f in FILES_F]
    incs = [f"-I{mdir / 'rtl/sramc'}", f"-I{mdir / 'third_party/silicaflux-sramcore/rtl/sram'}", f"-I{mdir / 'tb'}"]
    flags = [x for x in VL_SIM if x != "-j"]
    flags = flags[:-1] if flags[-1] == "4" else flags
    r0 = sh(["verilator", *flags, "-j", "2", *incs, *rtl, str(mdir / "tb/sf_sramc_bankmodel.sv"), str(mdir / f"tb/{cfg['top']}.sv"),
             "--top-module", cfg["top"], *vl_gargs(cfg["p"], cfg["top"]), "-Mdir", str(out / "obj"), "-o", cfg["top"]], cwd=mdir, timeout=1800)
    if r0["rc"] != 0:
        return "invalid", "build failed: " + r0["out"][-300:]
    r = sh([out / "obj" / cfg["top"], "+seed=1"], cwd=mdir, timeout=900)
    o = r["out"]
    if r["rc"] != 0 or "SFC_ASSERT" in o or "SFC_ENV" in o or "SRAMC_RESULT FAIL" in o or "SRAMC_RESULT PASS" not in o:
        why = next((l for l in o.splitlines() if "SFC_ASSERT" in l or "SFC_ENV" in l or "SRAMC_ERROR" in l or "SRAMC_RESULT FAIL" in l), o[-200:])
        return "killed", f"{cfgname}: {why.strip()[:220]}"
    return "survived", cfgname


def run_one(m):
    mid, f, old, new, desc, cfgs = m
    mdir = BUILD / "mut" / mid
    shutil.rmtree(mdir, ignore_errors=True)
    for d in ("rtl", "tb", "third_party"):
        shutil.copytree(ROOT / d, mdir / d)
    path = mdir / f
    text = path.read_text()
    if text.count(old) != 1:
        return dict(id=mid, desc=desc, verdict="invalid", detail=f"pattern occurs {text.count(old)} times in {f}")
    path.write_text(text.replace(old, new))
    seen = []
    for c in cfgs:
        v, d = build_and_run(mid, c, mdir)
        if v == "killed":
            return dict(id=mid, desc=desc, verdict="killed", detail=d, tried=seen + [c])
        if v == "invalid":
            return dict(id=mid, desc=desc, verdict="invalid", detail=d)
        seen.append(c)
    return dict(id=mid, desc=desc, verdict="survived", detail="passed on: " + ", ".join(seen), tried=seen)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    muts = [m for m in MUT if not a.only or re.search(a.only, m[0])]
    res = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(run_one, muts):
            print(f"{r['id']} {r['verdict'].upper():9s} {r['desc']}  [{r['detail'][:110]}]", flush=True)
            res.append(r)
    write_json(REPORTS / "mutants.json", dict(provenance=provenance(), results=res))
    k = sum(r["verdict"] == "killed" for r in res)
    s = sum(r["verdict"] == "survived" for r in res)
    i = sum(r["verdict"] == "invalid" for r in res)
    print(f"mutants: {k} killed / {s} survived / {i} invalid of {len(res)}")
    sys.exit(1 if (s or i) else 0)


if __name__ == "__main__":
    main()
