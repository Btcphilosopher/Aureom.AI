#!/bin/bash
# Build the delivery archive (outside git; nothing is committed).  usage: scripts/package.sh [output.zip]
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME="$(basename "$ROOT")"
OUT="${1:-$ROOT/../silicaflux-sramcontroller-p73.zip}"
cd "$ROOT"
# strip the build machine's absolute paths from the generated reports
if ls reports/* >/dev/null 2>&1; then sed -i "s#$ROOT#<pkg>#g" reports/*; fi
find . -type f \( -path './build/*' -o -name '__pycache__' -o -name '*.pyc' -o -name SHA256SUMS \) -prune -o -type f -print | sed 's#^\./##' | sort | grep -v '^SHA256SUMS$' | xargs sha256sum > SHA256SUMS
cd "$ROOT/.."
rm -f "$OUT"
zip -qr "$OUT" "$NAME" -x "$NAME/build/*" "*/__pycache__/*" "*.pyc"
echo "$OUT"
unzip -l "$OUT" | tail -1
