#!/usr/bin/env python3
"""Gate-level lockstep equivalence: synthesise the controller with Yosys to a generic gate netlist, then co-simulate the
RTL and the netlist with identical random stimulus (tb/tb_sramc_gls.sv); every output must match every cycle.
usage: run_gls.py [--only REGEX]"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import *   # noqa

SRCS = " ".join(str(f) for f in RTL_FILES)
CFG = [
    ("gls_1x1_o1",   dict(NM=1, NB=1, MAXOUT=1, BOUT=2), "primary 1 master / 1 bank"),
    ("gls_4x4_o2",   dict(NM=4, NB=4, MAXOUT=2, BOUT=4), "4x4, 2 outstanding, counters"),
    ("gls_4x4_prio", dict(NM=4, NB=4, MAXOUT=4, BOUT=4, PRIO=1, HPM=1, HPL=3), "4x4, 4 outstanding, priority classes"),
    ("gls_3x2_high", dict(NM=3, NB=2, MAXOUT=3, BOUT=3, ILV=1, MASKM=1, DW=64), "3 masters x 2 banks, HIGH interleave, MASK_MODE=ALIGNED, 64-bit"),
]
TOP2RTL = dict(NM="NUM_MASTERS", NB="NUM_BANKS", MAXOUT="MAX_OUT", BOUT="BANK_OUT", ILV="INTERLEAVE", MASKM="MASK_MODE",
               PRIO="PRIO_EN", HPM="HP_MASK", HPL="HP_LIMIT", DW="DATA_WIDTH", IDW="ID_WIDTH", BD="BANK_DEPTH")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    res = []
    for name, p, note in CFG:
        if a.only and not re.search(a.only, name):
            continue
        d = BUILD / "gls" / name
        d.mkdir(parents=True, exist_ok=True)
        rp = {"ADDR_WIDTH": 32, "PERF_EN": 1, "CNT_W": 32, "BANK_DEPTH": 64, "ID_WIDTH": 4, "DATA_WIDTH": 32, "MAX_OUT": 2, "BANK_OUT": 4}
        for k, v in p.items():
            rp[TOP2RTL[k]] = v
        chp = "\n".join(f"chparam -set {k} {v if k != 'HP_MASK' else chr(49)+chr(54)+chr(39)+'h%x' % v} sf_sram_controller" for k, v in rp.items())
        script = f"""read_verilog -sv -I{RTL} {RTL}/sf_sramc_fifo.sv {RTL}/sf_sramc_arb.sv {RTL}/sf_sramc_perf.sv {RTL}/sf_sram_controller.sv
{chp}
hierarchy -check -top sf_sram_controller
synth -flatten -top sf_sram_controller
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean -purge
rename sf_sram_controller sf_sram_controller_gl
write_verilog -noattr {d}/netlist.v
tee -o {d}/stat.txt stat
"""
        (d / "s.ys").write_text(script)
        ry = sh(["yosys", "-q", "-l", str(d / "yosys.log"), str(d / "s.ys")], cwd=ROOT, timeout=1800)
        row = dict(name=name, note=note, params=p)
        if ry["rc"] != 0:
            row.update(ok=False, why="synthesis failed", log=ry["out"][-500:])
            res.append(row)
            print(name, "SYNTH FAIL")
            continue
        gargs = [f"-G{k}={v}" for k, v in p.items() if k != "HPM"] + ([f"-GHPM={p['HPM']}"] if "HPM" in p else [])
        out = d / "obj"
        rb = sh(["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-DECLFILENAME", "-Wno-MULTITOP",
                 "--x-assign", "unique", "--x-initial", "unique", "-j", "4", f"-I{RTL}", f"-I{LIB}", f"-I{TB}",
                 str(RTL / "sf_sramc_fifo.sv"), str(RTL / "sf_sramc_arb.sv"), str(RTL / "sf_sramc_perf.sv"), str(RTL / "sf_sram_controller.sv"),
                 str(TB / "sf_sramc_bankmodel.sv"), str(d / "netlist.v"), str(TB / "tb_sramc_gls.sv"), "--top-module", "tb_sramc_gls", *gargs,
                 "-Mdir", str(out), "-o", "gls"], cwd=ROOT, timeout=3000)
        if rb["rc"] != 0:
            row.update(ok=False, why="build failed", log=rb["out"][-800:])
            res.append(row)
            print(name, "BUILD FAIL", rb["out"][-400:])
            continue
        oks = []
        for seed in (1, 2):
            r = sh([out / "gls", f"+seed={seed}"], cwd=ROOT, timeout=3000)
            m = re.search(r"SRAMC_GLS (PASS|FAIL) cycles=(\d+) compares=(\d+) accepted=(\d+) responses=(\d+)", r["out"])
            oks.append(dict(seed=seed, ok=bool(m and m.group(1) == "PASS"), line=m.group(0) if m else r["out"][-300:]))
        stat = (d / "stat.txt").read_text()
        cells = re.findall(r"Number of cells:\s+(\d+)", stat)
        row.update(ok=all(o["ok"] for o in oks), runs=oks, netlist_cells=int(cells[-1]) if cells else None)
        res.append(row)
        print(name, "PASS" if row["ok"] else "FAIL", [o["line"] for o in oks])
    write_json(REPORTS / "gls.json", dict(provenance=provenance(), results=res))
    sys.exit(0 if all(r["ok"] for r in res) else 1)


if __name__ == "__main__":
    main()
