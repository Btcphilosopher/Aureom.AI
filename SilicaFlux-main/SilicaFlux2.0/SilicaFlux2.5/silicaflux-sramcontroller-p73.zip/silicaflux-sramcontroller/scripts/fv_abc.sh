#!/bin/bash
# usage: fv_abc.sh <model.aig> <bmc-depth> <pdr-seconds|0>   -> prints one verdict line each for BMC and PDR
AIG="$1"; DEPTH="$2"; PDR="$3"
OUT=$(timeout $(( ${FV_BMC_T:-900} + 300 )) yosys-abc -c "read_aiger $AIG; fold; bmc3 -F $DEPTH -T ${FV_BMC_T:-900}" 2>&1)
if echo "$OUT" | grep -q "asserted in frame"; then echo "BMC FAIL $(echo "$OUT" | grep -o 'asserted in frame [0-9]*' | head -1)"
elif echo "$OUT" | grep -q "No output asserted"; then echo "BMC PASS depth $DEPTH"
else echo "BMC UNKNOWN $(echo "$OUT" | tail -1)"; fi
if [ "$PDR" != "0" ]; then
  OUT=$(timeout $((PDR+120)) yosys-abc -c "read_aiger $AIG; fold; pdr -T $PDR" 2>&1)
  if echo "$OUT" | grep -q "Property proved"; then echo "PDR PROVED"
  elif echo "$OUT" | grep -q "asserted in frame"; then echo "PDR FAIL $(echo "$OUT" | grep -o 'asserted in frame [0-9]*' | head -1)"
  else echo "PDR UNDECIDED"; fi
fi
