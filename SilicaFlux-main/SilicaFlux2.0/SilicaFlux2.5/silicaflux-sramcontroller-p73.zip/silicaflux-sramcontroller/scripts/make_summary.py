#!/usr/bin/env python3
"""Aggregate reports/*.json into reports/{lint,regression,formal,mutants,synth,gls,perf}.md, reports/SUMMARY.md and the README results block."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import *   # noqa


def load(n):
    p = REPORTS / f"{n}.json"
    return json.loads(p.read_text()) if p.exists() else None


def tools_line(prov):
    t = prov["tools"]
    return (f"Tools: {t['verilator']}; {t['iverilog']}; {t['yosys']}; python {t['python']}. "
            f"Not installed: vivado={t['vivado']}, quartus={t['quartus']}, openroad={t['openroad']}.  RTL sha256 `{prov['rtl_sha256'][:16]}…`.")


def md_lint(d, neg):
    out = ["# Lint and negative tests", ""]
    if d:
        r = d["results"]
        out += [f"Verilator `-Wall` / Icarus `-Wall`: **{sum(x['ok'] for x in r)}/{len(r)} pass** (zero warnings required).", ""]
        out += ["| check | result |", "|---|---|"] + [f"| {x['name']} | {'pass' if x['ok'] else 'FAIL ' + str(x.get('warnings'))} |" for x in r]
    if neg:
        r = neg["results"]
        out += ["", f"Illegal parameterisations rejected by Verilator + Icarus + Yosys: **{sum(x['ok'] for x in r)}/{len(r)}**", "",
                "| case | top | override | Verilator | Icarus | Yosys |", "|---|---|---|---|---|---|"]
        out += [f"| {x['name']} | {x['top']} | `{x['overrides']}` | {x['verilator']} | {x['icarus']} | {x['yosys']} |" for x in r]
    (REPORTS / "lint.md").write_text("\n".join(out) + "\n")


def md_sim(sim, xsim):
    r = sim["results"]
    out = ["# Self-checking simulation", "", tools_line(sim["provenance"]), "",
           f"**{sum(x['ok'] for x in r)}/{len(r)} runs pass**, {sum(x.get('checks', 0) for x in r):,} scoreboard checks. Cross-simulator (same seed, Verilator vs Icarus): "
           + (f"**{sum(x['ok'] for x in xsim['results'])}/{len(xsim['results'])} identical** (metric line and check count)." if xsim else "n/a"), "",
           "| config | sim | seed | result | checks | accepted | completed | cancelled by reset | parallel-bank cycles | secs |", "|---|---|---|---|---|---|---|---|---|---|"]
    for x in r:
        m = x.get("metrics", {})
        out.append(f"| {x['name']} | {x['sim']} | {x['seed']} | {'PASS' if x['ok'] else 'FAIL'} | {x.get('checks', 0):,} | {m.get('accepted', '')} | {m.get('completed', '')} | {m.get('cancelled_by_reset', '')} | {m.get('parallel_bank_cycles', '')} | {x.get('secs', '')} |")
    out += ["", "## Functional coverage seen (per run; every required scenario must be non-zero)", "",
            "| config | seed | OK | RANGE | ALIGN | MASK | SRC | ID | POISON | CANCEL | BANK | conflicts | order stalls | rsp stall cycles | max outstanding |", "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for x in r:
        if x["sim"] == "verilator" and x.get("cov"):
            c = x["cov"]
            out.append(f"| {x['name']} | {x['seed']} | {c['ok']} | {c['range']} | {c['align']} | {c['mask']} | {c['src']} | {c['idreuse']} | {c['poison']} | {c['cancel']} | {c.get('bank', 0)} | {c['conflicts']} | {c['order_stalls']} | {c['rsp_stall_cycles']} | {c['max_outstanding']} |")
    (REPORTS / "regression.md").write_text("\n".join(out) + "\n")


def md_formal(f):
    r = f["results"]
    import hashlib
    core = [RTL / "sf_sram_controller.sv", RTL / "sf_sramc_arb.sv", RTL / "sf_sramc_fifo.sv", RTL / "sf_sramc_perf.sv", RTL / "sf_sramc_defs.svh",
            FORMAL / "fv_sramc.sv", FORMAL / "fv_sramc_arb.sv", FORMAL / "fv_sramc_fifo.sv"]
    hashes = "; ".join(f"`{p.name}` {hashlib.sha256(p.read_bytes()).hexdigest()[:12]}" for p in core)
    out = ["# Formal results", "", tools_line(f["provenance"]), "",
           "Files under proof (the formal flow reads exactly these; SHA-256 prefixes at report time — `sf_sram_subsystem.sv`/`sf_sramc_bank.sv`/`sf_sramc_soc4.sv` are not part of any harness): " + hashes, "",
           "Yosys `read_verilog -formal` -> AIGER (zero-init) -> ABC. `bmc3` = bounded model check to the stated depth from reset; `pdr` = **unbounded proof** (property holds for ALL reachable states).",
           "A PDR verdict of *undecided / blank* means no unbounded proof was obtained: the claim is then ONLY the BMC depth. `expect FAIL` rows are non-vacuity checks (reachability probes, mutants, negative controls).", "",
           "| job | harness | parameters | BMC | unbounded (PDR) | expect | verdict | note |", "|---|---|---|---|---|---|---|---|"]
    for x in r:
        out.append(f"| {x['name']} | {x.get('top','')} | `{x.get('params','')}` | {x.get('bmc','').replace('BMC ','')} | {x.get('pdr','').replace('PDR ','') or '-'} | {x['expect']} | **{x['verdict']}**{'' if x['ok'] else ' (UNEXPECTED)'} | {x['note']} |")
    (REPORTS / "formal.md").write_text("\n".join(out) + "\n")


def md_mut(m):
    r = m["results"]
    k = sum(x["verdict"] == "killed" for x in r)
    out = ["# Mutation sanity", "", tools_line(m["provenance"]), "",
           f"Injected RTL bugs: **{k} killed / {sum(x['verdict'] == 'survived' for x in r)} survived / {sum(x['verdict'] == 'invalid' for x in r)} invalid** of {len(r)}.", "",
           "| id | injected bug | verdict | caught by |", "|---|---|---|---|"]
    for x in r:
        out.append(f"| {x['id']} | {x['desc']} | {x['verdict'].upper()} | {x['detail'][:160].replace('|', '/')} |")
    (REPORTS / "mutants.md").write_text("\n".join(out) + "\n")


def md_synth(s):
    out = ["# Synthesis results (Yosys)", "", tools_line(s["provenance"]), "",
           "**No timing, frequency, area-in-um2 or power figure is claimed anywhere**: no liberty file, STA tool or PDK is available. Cell/LUT/FF counts are Yosys technology-mapped counts;",
           "`logic depth` is the longest *topological* path in generic gate levels (a structural proxy, NOT a delay). All runs: `check -assert` (no combinational loops, no multiple drivers), latches = 0.", "",
           "## Generic gate-level synthesis (AND/NAND/OR/NOR/XOR/XNOR/MUX + flip-flops)", "",
           "| case | parameters | cells | flip-flops | gates | latches | logic depth | note |", "|---|---|---|---|---|---|---|---|"]
    for row in s["results"]:
        for x in row["results"]:
            if x["flow"].startswith("generic"):
                out.append(f"| {row['name']} | `{row['params']}` | {x.get('cells')} | {x.get('flipflops')} | {x.get('gates')} | {x.get('latches')} | {x.get('logic_depth_levels')} | {row['note']} |")
    out += ["", "## FPGA technology mapping (controller + banks, evidence of block-RAM inference)", "",
            "| case | family | cells | LUTs | FFs | block RAM | LUT RAM | note |", "|---|---|---|---|---|---|---|---|"]
    for row in s["results"]:
        for x in row["results"]:
            if not x["flow"].startswith("generic"):
                out.append(f"| {row['name']} | {x['flow']} | {x.get('cells')} | {x.get('luts')} | {x.get('ffs')} | {x.get('brams')} | {x.get('lutram')} | {row['note']} |")
    (REPORTS / "synth.md").write_text("\n".join(out) + "\n")


def md_gls(g):
    r = g["results"]
    out = ["# Gate-level lock-step equivalence", "", tools_line(g["provenance"]), "",
           f"**{sum(x['ok'] for x in r)}/{len(r)} configurations identical** to the synthesised generic gate netlist, every output, every cycle.", "",
           "| config | description | netlist cells | seed 1 | seed 2 |", "|---|---|---|---|---|"]
    for x in r:
        runs = x.get("runs", [])
        out.append(f"| {x['name']} | {x['note']} | {x.get('netlist_cells')} | " + " | ".join(f"{'PASS' if o['ok'] else 'FAIL'} — {o['line'].replace('SRAMC_GLS ', '')}" for o in runs) + " |")
    (REPORTS / "gls.md").write_text("\n".join(out) + "\n")


def results_block(lint, neg, sim, xsim, formal, mut, synth, gls, ifr=None):
    rows = ["| Check | Result | Notes |", "|---|---|---|"]
    if lint:
        r = lint["results"]
        rows.append(f"| Lint: Verilator `-Wall` + Icarus `-Wall` | {sum(x['ok'] for x in r)} pass / {sum(not x['ok'] for x in r)} fail | zero warnings, every top and parameter variant, with and without embedded assertions |")
    if neg:
        r = neg["results"]
        rows.append(f"| Illegal parameterisations rejected | {sum(x['ok'] for x in r)} pass / {sum(not x['ok'] for x in r)} fail | Verilator + Icarus + Yosys |")
    if sim:
        r = sim["results"]
        stage = {1: 0, 2: 0, 3: 0}
        rows.append(f"| Self-checking simulation | {sum(x['ok'] for x in r)} pass / {sum(not x['ok'] for x in r)} fail | {len(r)} runs, {sum(x.get('checks', 0) for x in r):,} scoreboard checks; 1x1 -> 1xN -> 4x4, MAX_OUT 1/2/4, 3 and 8 masters, 8..128-bit, priority classes, random-latency banks |")
    if ifr:
        r = ifr["results"]
        rows.append(f"| Reference transaction interface + four-master SoC wrapper tests | {sum(x['ok'] for x in r)} pass / {sum(not x['ok'] for x in r)} fail | `sf_sramc_if` connect test + protocol checker (lint clean); `sf_sramc_soc4` wiring test (4 masters in parallel, cross-master reads, errors, disabled source) |")
    if xsim:
        r = xsim["results"]
        rows.append(f"| Same seed = same behaviour, Verilator vs Icarus | {sum(x['ok'] for x in r)} pass / {sum(not x['ok'] for x in r)} fail | metric line and check count compared |")
    if formal:
        r = formal["results"]
        pr = [x for x in r if x["verdict"] == "PROVED"]
        bd = [x for x in r if x["verdict"] == "BOUNDED"]
        pb = [x for x in r if x["expect"] == "FAIL"]
        rows.append(f"| Formal (Yosys + ABC) | {sum(x['ok'] for x in r)} as expected / {sum(not x['ok'] for x in r)} unexpected | **{len(pr)} unbounded proofs (PDR)**, {len(bd)} bounded (BMC depth in `reports/formal.md`), {len(pb)} non-vacuity checks (probes, mutants, negative control) |")
    if mut:
        r = mut["results"]
        rows.append(f"| Mutation sanity | {sum(x['verdict'] == 'killed' for x in r)} killed / {sum(x['verdict'] == 'survived' for x in r)} survived | of {len(r)} injected RTL bugs |")
    if gls:
        r = gls["results"]
        rows.append(f"| Gate-level lock-step (RTL vs Yosys gate netlist) | {sum(x['ok'] for x in r)} pass / {sum(not x['ok'] for x in r)} fail | {len(r)} configurations x 2 seeds x 60 000 cycles, every output every cycle |")
    if synth:
        for row in synth["results"]:
            if row["name"] in ("ctl_1x1_o1", "ctl_4x4_o1", "ctl_4x4_o4_perf"):
                x = row["results"][0]
                rows.append(f"| Synthesis: {row['name']} | {x.get('cells')} cells, {x.get('flipflops')} FF, 0 latches | {row['note']} (generic gates; no timing claim) |")
        for row in synth["results"]:
            if row["name"] == "sub_4x4_o1":
                x = row["results"][0]
                rows.append(f"| Synthesis: full subsystem, xc7 | {x.get('luts')} LUT, {x.get('ffs')} FF, {x.get('brams')} block RAM | 4 x 1024 x 32-bit (16 KiB) banks + controller (Yosys inference evidence only) |")
    prov = (sim or formal or mut or synth)["provenance"]
    return "\n".join(rows) + "\n\n" + tools_line(prov)


def main():
    lint, neg, sim, xsim, formal, mut, synth, gls, perf, ifr = (load(n) for n in ("lint", "neg", "sim", "xsim", "formal", "mutants", "synth", "gls", "perf", "if"))
    if lint or neg:
        md_lint(lint, neg)
    if sim:
        md_sim(sim, xsim)
    if formal:
        md_formal(formal)
    if mut:
        md_mut(mut)
    if synth:
        md_synth(synth)
    if gls:
        md_gls(gls)
    block = results_block(lint, neg, sim, xsim, formal, mut, synth, gls, ifr)
    out = ["# SRAMController — summary (generated from the JSON reports of the final run)", "", block, "",
           "Detail: `lint.md`, `regression.md`, `formal.md`, `mutants.md`, `synth.md`, `gls.md`, `perf.md`."]
    (REPORTS / "SUMMARY.md").write_text("\n".join(out) + "\n")
    rd = ROOT / "README.md"
    if rd.exists():
        t = rd.read_text()
        t2 = re.sub(r"<!--RESULTS-->.*<!--/RESULTS-->", lambda m: "<!--RESULTS-->\n" + block + "\n<!--/RESULTS-->", t, flags=re.S)
        rd.write_text(t2)
    print((REPORTS / "SUMMARY.md").read_text())


if __name__ == "__main__":
    main()
