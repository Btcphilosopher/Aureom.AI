#!/usr/bin/env python3
"""Performance benchmark: saturating traffic patterns x MAX_OUT x bank latency, figures read from the controller's own
counters (tb/tb_sramc_perf.sv).  Writes reports/perf.json and reports/perf.md.   usage: run_perf.py"""
from __future__ import annotations

import concurrent.futures as cf
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import *   # noqa

NM, NB = 4, 4
PATTERNS = {0: "1 master, 1 bank", 1: "1 master, sequential (banks rotate)", 2: "4 masters, ONE bank", 3: "4 masters, private banks",
            4: "4 masters, random R/W", 5: "4 masters, sequential streams", 6: "4 masters, private-bank writes", 7: "private banks, rsp_ready 50%"}


def build(maxout, lat, uni=-1):
    d = BUILD / "perf" / f"o{maxout}_l{lat}_u{uni}"
    d.mkdir(parents=True, exist_ok=True)
    lats = int("".join(str(lat) for _ in range(16)), 16)
    r = sh(["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-DECLFILENAME", "-Wno-MULTITOP",
            "-j", "2", *(f"-I{x}" for x in (RTL, LIB)), *[str(f) for f in RTL_FILES], str(TB / "tb_sramc_perf.sv"), "--top-module", "tb_sramc_perf",
            f"-GMAXOUT={maxout}", f"-GLATS=64'h{lats:x}", f"-GUNI={uni}", "-Mdir", str(d / "obj"), "-o", "perf"], cwd=ROOT, timeout=1800)
    assert r["rc"] == 0, r["out"][-500:]
    return d / "obj" / "perf"


def run(exe, pat):
    r = sh([exe, f"+pattern={pat}"], cwd=ROOT, timeout=600)
    c = {int(a): int(b) for a, b in re.findall(r"^PERF (\d+) (\d+)$", r["out"], re.M)}
    return c


def derive(c):
    cyc = c[0]
    acc = c[2]
    cmp_ = c[3]
    wait = sum(c[16 + 16 * m + 5] for m in range(NM))
    lat = sum(c[16 + 16 * m + 7] for m in range(NM))
    macc = sum(c[16 + 16 * m + 1] for m in range(NM))
    acc_b = sum(c[16 + 16 * NM + 8 * b + 0] for b in range(NB))
    busy_b = sum(c[16 + 16 * NM + 8 * b + 3] for b in range(NB))
    per = [c[16 + 16 * m + 1] for m in range(NM)]
    return dict(cycles=cyc, completed=cmp_, throughput=round(cmp_ / cyc, 3), rd_per_cycle=round(c[4] / cyc, 3), wr_per_cycle=round(c[5] / cyc, 3),
                avg_arb_wait=round(wait / max(acc, 1), 2), avg_latency=round(lat / max(macc, 1), 2), conflicts_per_cycle=round(c[7] / cyc, 3),
                busy_pct=round(100 * c[1] / cyc, 1), bank_util_pct=round(100 * acc_b / (cyc * NB), 1), bank_busy_pct=round(100 * busy_b / (cyc * NB), 1),
                max_outstanding=max(c[16 + 16 * m + 8] for m in range(NM)), per_master_completed=per, order_stalls=c[8], rsp_stall_cycles=c[11])


def main():
    combos = [(o, l) for o in (1, 2, 4) for l in (1, 2, 4)]
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        exes = dict(zip(combos, ex.map(lambda t: build(*t), combos)))
    rows = []
    for (o, l), exe in exes.items():
        for p in PATTERNS:
            rows.append(dict(max_out=o, bank_latency=l, pattern=p, desc=PATTERNS[p], **derive(run(exe, p))))
    # bank-lock (UNIFORM_LAT forced off) versus automatic uniform mode, equal-latency banks, MAX_OUT = 4
    cmp_rows = []
    for lat in (1, 2, 4):
        exe0 = build(4, lat, 0)
        exeu = exes[(4, lat)]
        for pat in (1, 5):
            a = derive(run(exe0, pat))
            b = derive(run(exeu, pat))
            cmp_rows.append(dict(bank_latency=lat, pattern=pat, desc=PATTERNS[pat], bank_lock_throughput=a["throughput"], uniform_throughput=b["throughput"],
                                 bank_lock_order_stalls=a["order_stalls"], uniform_order_stalls=b["order_stalls"]))
    write_json(REPORTS / "perf.json", dict(provenance=provenance(), results=rows, uniform_vs_bank_lock=cmp_rows))
    md = ["# Performance (from the controller's hardware counters)", "",
          "4 masters x 4 word-interleaved banks, 32-bit, `sf_sram_core` banks, always-ready masters unless stated, 20 000 cycles per row.",
          "`throughput` = completed transactions per cycle (peak = number of banks = 4); `avg arb wait` = cycles a request waited before acceptance;",
          "`avg latency` = acceptance -> response transfer (accept + bank latency + 1 response-register cycle when uncontended); `conflicts/cycle` = requesters that lost a bank grant.", "",
          "| MAX_OUT | bank lat | pattern | thr (txn/cyc) | rd/cyc | wr/cyc | avg arb wait | avg latency | conflicts/cyc | busy % | bank util % | per-master completed |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['max_out']} | {r['bank_latency']} | {r['pattern']}: {r['desc']} | {r['throughput']} | {r['rd_per_cycle']} | {r['wr_per_cycle']} | {r['avg_arb_wait']} | {r['avg_latency']} | {r['conflicts_per_cycle']} | {r['busy_pct']} | {r['bank_util_pct']} | {r['per_master_completed']} |")
    md += ["", "## Bank-lock rule versus `UNIFORM_LAT` (equal-latency banks, MAX_OUT = 4, one master / four masters streaming across word-interleaved banks)", "",
           "| bank lat | pattern | throughput with bank-lock (`UNIFORM_LAT=0`) | throughput with `UNIFORM_LAT` (automatic) | order-stall master-cycles (lock / uniform) |", "|---|---|---|---|---|"]
    for r in cmp_rows:
        md.append(f"| {r['bank_latency']} | {r['pattern']}: {r['desc']} | {r['bank_lock_throughput']} | {r['uniform_throughput']} | {r['bank_lock_order_stalls']} / {r['uniform_order_stalls']} |")
    (REPORTS / "perf.md").write_text("\n".join(md) + "\n")
    print("perf:", len(rows), "rows")


if __name__ == "__main__":
    main()
