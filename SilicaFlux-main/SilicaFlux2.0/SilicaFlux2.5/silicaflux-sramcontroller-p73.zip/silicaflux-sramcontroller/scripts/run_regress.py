#!/usr/bin/env python3
"""SRAMController regression: lint, negative elaboration, self-checking simulation sweep (Verilator + Icarus),
cross-simulator stimulus equivalence.  Writes reports/<suite>.json and reports/<suite>.md.
usage: run_regress.py --suite lint,neg,sim,xsim [--only REGEX] [--stage N] [--out NAME] [--jobs N]"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import *   # noqa

RESULT_RE = re.compile(r"SRAMC_RESULT (PASS|FAIL) tb=(\S+) seed=(\d+) checks=(\d+) errors=(\d+)")
INFO_RE = re.compile(r"SRAMC_INFO total accepted=(\d+) completed=(\d+) cancelled-by-reset=(\d+) error-cases=(\d+) parallel-bank-cycles=(\d+)")
COV_RE = re.compile(r"SRAMC_COV (.*)")


def expected_uniform(cfg):
    """sf_sram_subsystem enables UNIFORM_LAT automatically iff every EXISTING bank has the same latency"""
    if cfg["top"] != "tb_sramc_sub":
        return 0 if cfg["top"] == "tb_sramc_var" else None
    p = cfg["p"]
    nb = p.get("NB", 4)
    lats = int(str(p.get("LATS", "0x1111111111111111")), 0)
    ls = [((lats >> (4 * b)) & 0xF) or 1 for b in range(nb)]
    return 1 if len(set(ls)) == 1 else 0


def coverage_holes(cfg, cv):
    """every scenario that the brief lists must actually have happened (non-vacuity)"""
    p = cfg["p"]
    nm, nb, maxout = p.get("NM", 4), p.get("NB", 4), p.get("MAXOUT", 1)
    need = ["ok", "range", "mask", "src", "poison", "rsp_stall_cycles"]
    # CANCEL (flush) needs an access that is still inside a bank when flush is sampled: impossible with 1-cycle banks,
    # because flush blocks acceptance in the cycle it is sampled.  Required whenever some bank latency is >= 2.
    lats = int(str(p.get("LATS", "0x1111111111111111")), 0)
    max_lat = max(((lats >> (4 * b)) & 0xF) or 1 for b in range(nb))
    if (cfg["top"] == "tb_sramc_var" and p.get("BMAX", 6) >= 2) or (cfg["top"] == "tb_sramc_sub" and max_lat >= 2):
        need.append("cancel")
    if p.get("DW", 32) > 8:
        need.append("align")
    if cfg["top"] == "tb_sramc_var" and p.get("BADROW", -1) >= 0:
        need.append("bank")
    if p.get("IDCHK", 1) and maxout > 1:
        need.append("idreuse")
    if nm > 1:
        need.append("conflicts")
    uniform = cfg["top"] == "tb_sramc_sub" and max_lat == min(((lats >> (4 * b)) & 0xF) or 1 for b in range(nb))
    if maxout > 1 and nb > 1 and not uniform:       # the bank-lock rule only exists with non-uniform bank latency
        need.append("order_stalls")
    miss = [k for k in need if cv.get(k, 0) == 0]
    if cv.get("max_outstanding", 0) < min(maxout, 2) and nm >= 1:
        miss.append("max_outstanding")
    return miss


def run_vl_sim(cfg, seed, nrand=None):
    name = cfg["name"]
    out = BUILD / "sim" / name
    p = dict(cfg["p"])
    if cfg.get("nrand") or nrand:
        p["NRAND"] = cfg.get("nrand") or nrand
    out.mkdir(parents=True, exist_ok=True)
    exe = out / cfg["top"]
    r0 = None
    if not exe.exists():
        r0 = sh(["verilator", *VL_SIM, *(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES], str(TB / "sf_sramc_bankmodel.sv"),
                 str(TB / f"{cfg['top']}.sv"), "--top-module", cfg["top"], *vl_gargs(p, cfg["top"]), "-Mdir", str(out / "obj"), "-o", cfg["top"]],
                cwd=ROOT, timeout=1800)
        if r0["rc"] != 0:
            return dict(name=name, sim="verilator", seed=seed, ok=False, why="build failed", log=r0["out"][-3000:], cmd=r0["cmd"])
        (out / "obj" / cfg["top"]).replace(exe)
    r = sh([exe, f"+seed={seed}"], cwd=ROOT, timeout=3600)
    return parse_run(cfg, "verilator", seed, r, r0)


def run_ic_sim(cfg, seed, nrand=None):
    name = cfg["name"]
    out = BUILD / "icarus" / name
    p = dict(cfg["p"])
    if cfg.get("nrand") or nrand:
        p["NRAND"] = cfg.get("nrand") or nrand
    out.mkdir(parents=True, exist_ok=True)
    exe = out / "sim.vvp"
    r0 = None
    if not exe.exists():
        r0 = sh(["iverilog", "-g2012", "-DSFC_ASSERT", "-DSF_SRAM_POISON", *(f"-I{d}" for d in INC), "-s", cfg["top"], "-o", str(exe),
                 *ic_pargs(p, cfg["top"]), *[str(f) for f in RTL_FILES], str(TB / "sf_sramc_bankmodel.sv"), str(TB / f"{cfg['top']}.sv")], cwd=ROOT, timeout=1800)
        if r0["rc"] != 0:
            return dict(name=name, sim="icarus", seed=seed, ok=False, why="build failed", log=r0["out"][-3000:], cmd=r0["cmd"])
    r = sh(["vvp", exe, f"+seed={seed}"], cwd=ROOT, timeout=3600)
    return parse_run(cfg, "icarus", seed, r, r0)


def parse_run(cfg, sim, seed, r, r0):
    m = RESULT_RE.search(r["out"])
    info = INFO_RE.search(r["out"])
    ok = bool(m and m.group(1) == "PASS" and r["rc"] == 0 and "SFC_ASSERT" not in r["out"] and "SFC_ENV" not in r["out"])
    d = dict(name=cfg["name"], sim=sim, seed=seed, ok=ok, rc=r["rc"], secs=r["secs"], cmd=r["cmd"],
             checks=int(m.group(4)) if m else 0, errors=int(m.group(5)) if m else -1)
    if info:
        d["metrics"] = dict(zip(["accepted", "completed", "cancelled_by_reset", "error_cases", "parallel_bank_cycles"], map(int, info.groups())))
    um = re.search(r"SRAMC_INFO uniform_lat=(\d+)", r["out"])
    if um:
        d["uniform_lat"] = int(um.group(1))
        want = expected_uniform(cfg)
        if want is not None and d["uniform_lat"] != want:
            d["ok"] = False
            d["why"] = f"UNIFORM_LAT is {d['uniform_lat']}, expected {want} for these bank latencies"
    cov = COV_RE.search(r["out"])
    if cov:
        d["cov"] = dict((kv.split("=")[0], int(kv.split("=")[1])) for kv in cov.group(1).split())
        miss = coverage_holes(cfg, d["cov"])
        if miss:
            d["ok"] = False
            d["why"] = "coverage holes (vacuous test): " + ", ".join(miss)
    elif ok:
        d["ok"] = False
        d["why"] = "no SRAMC_COV line"
    for line in r["out"].splitlines():
        if line.startswith("SRAMC_INFO fairness"):
            d["fairness"] = line.split("fairness one-bank:")[-1].strip()
    if not ok:
        d["log"] = r["out"][-3000:]
    return d


def suite_sim(args):
    cfgs = [c for c in CONFIGS if (not args.only or re.search(args.only, c["name"])) and (not args.stage or c["stage"] == args.stage)]
    # 1. build every binary exactly once (parallel across configurations)
    def build(c, sim):
        d = BUILD / ("sim" if sim == "verilator" else "icarus") / c["name"]
        shutil.rmtree(d, ignore_errors=True)
        return (c["name"], sim, (run_vl_sim if sim == "verilator" else run_ic_sim)(c, c["seeds"][0]))
    builds = {}
    with cf.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        futs = [ex.submit(build, c, "verilator") for c in cfgs] + [ex.submit(build, c, "icarus") for c in cfgs if c["ic"]]
        for f in cf.as_completed(futs):
            n, sim, r = f.result()
            builds[(n, sim)] = r
    res = list(builds.values())
    # 2. remaining seeds
    jobs = []
    for c in cfgs:
        for s in c["seeds"][1:]:
            if builds[(c["name"], "verilator")].get("why") != "build failed":
                jobs.append((c, s, "verilator"))
    with cf.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        futs = [ex.submit(lambda c=c, s=s, sim=sim: (run_vl_sim if sim == "verilator" else run_ic_sim)(c, s)) for c, s, sim in jobs]
        for f in cf.as_completed(futs):
            res.append(f.result())
    res.sort(key=lambda d: (d["name"], d["sim"], d["seed"]))
    return res


def suite_xsim(sim_results):
    """same seed => identical stimulus and DUT behaviour in Verilator and Icarus: metric lines + check counts must match"""
    out = []
    by = {}
    for r in sim_results:
        by.setdefault((r["name"], r["seed"]), {})[r["sim"]] = r
    for (name, seed), d in sorted(by.items()):
        if "verilator" in d and "icarus" in d:
            a, b = d["verilator"], d["icarus"]
            same = a.get("metrics") == b.get("metrics") and a.get("checks") == b.get("checks") and a["ok"] and b["ok"]
            out.append(dict(name=name, seed=seed, ok=same, verilator=a.get("metrics"), icarus=b.get("metrics"),
                            checks=(a.get("checks"), b.get("checks"))))
    return out


def suite_lint(args):
    res = []
    tops = [("sf_sram_controller", {}), ("sf_sram_subsystem", {}), ("sf_sramc_soc4", {}),
            ("sf_sram_controller", dict(NUM_MASTERS=1, NUM_BANKS=1)), ("sf_sram_controller", dict(NUM_MASTERS=3, NUM_BANKS=2, MAX_OUT=3, PRIO_EN=1)),
            ("sf_sram_subsystem", dict(NUM_MASTERS=1, NUM_BANKS=1)), ("sf_sram_subsystem", dict(NUM_BANKS=8, MAX_OUT=4, DATA_WIDTH=64)),
            ("sf_sram_subsystem", dict(DATA_WIDTH=8, MASK_MODE=1, INTERLEAVE=1)), ("sf_sram_subsystem", dict(DATA_WIDTH=128, PERF_EN=0)),
            ("sf_sramc_arb", {}), ("sf_sramc_arb", dict(N=1)), ("sf_sramc_arb", dict(N=5, PRIO_EN=1, HP_MASK="16'h0006", HP_LIMIT=2)), ("sf_sramc_fifo", {}), ("sf_sramc_fifo", dict(DEPTH=1)),
            ("sf_sramc_bank", {}), ("sf_sramc_bank", dict(LAT=3)), ("sf_sramc_perf", {})]
    for top, ov in tops:
        for assertion in (False, True):
            if top in ("sf_sramc_perf", "sf_sramc_arb", "sf_sramc_fifo", "sf_sramc_bank") and assertion:
                continue
            tag = f"{top} {ov} {'+SFC_ASSERT' if assertion else ''}".strip()
            g = [f"-G{k}={v}" for k, v in ov.items()]
            r = sh(["verilator", *VL_LINT, *(["-DSFC_ASSERT"] if assertion else []), *(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES],
                    "--top-module", top, *g], cwd=ROOT)
            warn = [l for l in r["out"].splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
            res.append(dict(name=f"verilator -Wall: {tag}", ok=(r["rc"] == 0 and not warn), warnings=warn[:5]))
    for top, ov in [("sf_sram_subsystem", {}), ("sf_sramc_soc4", {}), ("sf_sram_controller", {}), ("sf_sramc_arb", {}), ("sf_sramc_fifo", {}), ("sf_sramc_perf", {})]:
        r = sh(["iverilog", "-g2012", "-Wall", "-o", "/dev/null", "-s", top, *(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES]], cwd=ROOT)
        bad = [l for l in r["out"].splitlines() if l and "sorry: constant selects" not in l]
        res.append(dict(name=f"icarus -Wall elaborate: {top}", ok=(r["rc"] == 0 and not bad), warnings=bad[:5]))
    return res


def suite_if(args):
    """reference transaction interface: connect test + its protocol checker"""
    out = BUILD / "if"
    out.mkdir(parents=True, exist_ok=True)
    flags = [x for x in VL_SIM]
    r0 = sh(["verilator", *flags, *(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES], str(RTL / "sf_sramc_txn.sv"), str(TB / "tb_sramc_if.sv"),
             "--top-module", "tb_sramc_if", "-Mdir", str(out / "obj"), "-o", "tb_sramc_if"], cwd=ROOT, timeout=1800)
    # four named masters on sf_sramc_soc4: wiring test
    o2 = BUILD / "soc4"
    o2.mkdir(parents=True, exist_ok=True)
    rs = sh(["verilator", *VL_SIM, *(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES], str(TB / "tb_sramc_soc4.sv"),
             "--top-module", "tb_sramc_soc4", "-Mdir", str(o2 / "obj"), "-o", "tb_sramc_soc4"], cwd=ROOT, timeout=1800)
    soc = dict(name="tb_sramc_soc4 (four named masters on sf_sramc_soc4)", ok=False, line=rs["out"][-300:])
    if rs["rc"] == 0:
        r = sh([o2 / "obj" / "tb_sramc_soc4"], cwd=ROOT, timeout=600)
        soc["ok"] = "SRAMC_RESULT PASS" in r["out"] and "SFC_ASSERT" not in r["out"]
        soc["line"] = next((l for l in r["out"].splitlines() if "SRAMC_RESULT" in l), r["out"][-200:])
    row = dict(name="tb_sramc_if (sf_sramc_if + packed transaction structs)", ok=False)
    if r0["rc"] == 0:
        r = sh([out / "obj" / "tb_sramc_if"], cwd=ROOT, timeout=600)
        row["ok"] = ("SRAMC_RESULT PASS" in r["out"]) and ("SFC_" not in r["out"] or "SFC_ASSERT" not in r["out"])
        row["line"] = next((l for l in r["out"].splitlines() if "SRAMC_RESULT" in l), r["out"][-200:])
    else:
        row["line"] = r0["out"][-300:]
    lint = sh(["verilator", *VL_LINT, str(RTL / "sf_sramc_txn.sv"), "--top-module", "sf_sramc_if"], cwd=ROOT)
    row["lint_clean"] = lint["rc"] == 0 and not [l for l in lint["out"].splitlines() if l.startswith("%Warning")]
    row["ok"] = row["ok"] and row["lint_clean"]
    return [row, soc]


def suite_neg(args):
    res = []
    for name, top, ov, frag in NEGATIVE:
        row = dict(name=name, top=top, overrides=ov, expect=frag)
        g = [f"-G{k}={v}" for k, v in ov.items()]
        rv = sh(["verilator", "--lint-only", "-Wno-DECLFILENAME", *(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES], "--top-module", top, *g], cwd=ROOT)
        row["verilator"] = (rv["rc"] != 0)
        row["verilator_message"] = frag.lower() in rv["out"].lower()
        p = [f"-P{top}.{k}={v}" for k, v in ov.items()]
        ri = sh(["iverilog", "-g2012", "-o", str(BUILD / "neg.vvp"), "-s", top, *p, *(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES]], cwd=ROOT)
        row["icarus"] = (ri["rc"] != 0) or ("fatal" in ri["out"].lower())
        if ri["rc"] == 0:   # Icarus defers $fatal to time 0 of the simulation
            rr = sh(["vvp", str(BUILD / "neg.vvp")], cwd=ROOT)
            row["icarus"] = (rr["rc"] != 0) or ("fatal" in rr["out"].lower())
        ys = "; ".join([f"read_verilog -sv -I{RTL} -I{LIB} " + " ".join(str(f) for f in RTL_FILES)] +
                       [f"chparam -set {k} {v} {top}" for k, v in ov.items()] + [f"hierarchy -check -top {top}", "proc"])
        ry = sh(["yosys", "-q", "-p", ys], cwd=ROOT)
        row["yosys"] = ry["rc"] != 0
        row["ok"] = row["verilator"] and row["icarus"] and row["yosys"]
        res.append(row)
    return res


def write_md(path, title, header, rows, fmt):
    lines = [f"# {title}", "", *header, "", *fmt(rows)]
    path.write_text("\n".join(lines) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", default="sim")
    ap.add_argument("--only", default="")
    ap.add_argument("--stage", type=int, default=0)
    ap.add_argument("--out", default="")
    ap.add_argument("--jobs", type=int, default=4)
    args = ap.parse_args()
    suites = args.suite.split(",")
    BUILD.mkdir(parents=True, exist_ok=True)
    rc = 0
    sim_res = None
    for s in suites:
        name = args.out or s
        if s == "lint":
            res = suite_lint(args)
            write_json(REPORTS / f"{name}.json", dict(provenance=provenance(), results=res))
            n_ok = sum(r["ok"] for r in res)
            print(f"lint: {n_ok}/{len(res)} pass")
            for r in res:
                if not r["ok"]:
                    print("  FAIL", r["name"], r.get("warnings"))
            rc |= (n_ok != len(res))
        elif s == "if":
            res = suite_if(args)
            write_json(REPORTS / "if.json", dict(provenance=provenance(), results=res))
            print(f"if: {sum(r['ok'] for r in res)}/{len(res)} pass  " + " | ".join(r['line'] for r in res))
            rc |= not all(r["ok"] for r in res)
        elif s == "neg":
            res = suite_neg(args)
            write_json(REPORTS / f"{name}.json", dict(provenance=provenance(), results=res))
            n_ok = sum(r["ok"] for r in res)
            print(f"neg: {n_ok}/{len(res)} illegal parameterisations rejected by Verilator + Icarus + Yosys")
            for r in res:
                if not r["ok"]:
                    print("  FAIL", r["name"], {k: r[k] for k in ("verilator", "icarus", "yosys")})
            rc |= (n_ok != len(res))
        elif s in ("sim", "xsim"):
            if sim_res is None:
                sim_res = suite_sim(args)
                write_json(REPORTS / f"{name if s == 'sim' else 'sim'}.json", dict(provenance=provenance(), results=sim_res))
                n_ok = sum(r["ok"] for r in sim_res)
                chk = sum(r.get("checks", 0) for r in sim_res)
                print(f"sim: {n_ok}/{len(sim_res)} runs pass, {chk} scoreboard checks")
                for r in sim_res:
                    if not r["ok"]:
                        print("  FAIL", r["name"], r["sim"], r["seed"], "\n", r.get("log", "")[-1500:])
                rc |= (n_ok != len(sim_res))
            if s == "xsim":
                xr = suite_xsim(sim_res)
                write_json(REPORTS / "xsim.json", dict(provenance=provenance(), results=xr))
                print(f"xsim: {sum(r['ok'] for r in xr)}/{len(xr)} identical Verilator vs Icarus")
                rc |= any(not r["ok"] for r in xr)
    sys.exit(1 if rc else 0)


if __name__ == "__main__":
    main()
