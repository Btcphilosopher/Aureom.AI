#!/usr/bin/env python3
"""Yosys synthesis evidence: generic logic synthesis (latch / loop / multi-driver checks, cell counts, structural logic depth),
FPGA mapping (xc7 incl. block-RAM inference, iCE40, ECP5) of the controller and of the full banked subsystem.
NO timing, frequency, area-in-um2 or power claim is made anywhere: no liberty file, no STA tool and no PDK is available.
usage: run_synth.py [--only REGEX]"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import *   # noqa

SRCS = " ".join(str(f) for f in RTL_FILES)
RD = f"read_verilog -sv -I{RTL} -I{LIB} {SRCS}"

# name, top, chparam list, kind ("generic" | "fpga" | "all"), note
CASES = [
    ("ctl_1x1_o1",        "sf_sram_controller", dict(NUM_MASTERS=1, NUM_BANKS=1, MAX_OUT=1, BANK_OUT=2, BANK_DEPTH=64, PERF_EN=0), "generic", "primary: 1 master, 1 bank, no counters"),
    ("ctl_1x1_o1_perf",   "sf_sram_controller", dict(NUM_MASTERS=1, NUM_BANKS=1, MAX_OUT=1, BANK_OUT=2, BANK_DEPTH=64, PERF_EN=1), "generic", "same + performance counters"),
    ("ctl_4x4_o1",        "sf_sram_controller", dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=1, BANK_OUT=2, BANK_DEPTH=64, PERF_EN=0), "generic", "4 masters x 4 banks, 1 outstanding, no counters"),
    ("ctl_4x4_o1_perf",   "sf_sram_controller", dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=1, BANK_OUT=2, BANK_DEPTH=64, PERF_EN=1), "generic", "4x4, 1 outstanding, counters"),
    ("ctl_4x4_o4_perf",   "sf_sram_controller", dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=4, BANK_OUT=4, BANK_DEPTH=64, PERF_EN=1), "generic", "4x4, 4 outstanding, counters"),
    ("ctl_4x4_o4_prio",   "sf_sram_controller", dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=4, BANK_OUT=4, BANK_DEPTH=64, PERF_EN=0, PRIO_EN=1), "generic", "4x4, 4 outstanding, priority classes, no counters"),
    ("ctl_4x4_o1_perf16", "sf_sram_controller", dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=1, BANK_OUT=2, BANK_DEPTH=64, PERF_EN=1, CNT_W=16), "generic", "4x4, 1 outstanding, 16-bit counters"),
    ("ctl_8x8_o2_perf",   "sf_sram_controller", dict(NUM_MASTERS=8, NUM_BANKS=8, MAX_OUT=2, BANK_OUT=4, BANK_DEPTH=64, PERF_EN=1), "generic", "8x8, 2 outstanding, counters"),
    ("ctl_4x4_o4_dw64",   "sf_sram_controller", dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=4, BANK_OUT=4, BANK_DEPTH=64, DATA_WIDTH=64, PERF_EN=0), "generic", "4x4, 64-bit data"),
    ("arb_n4",            "sf_sramc_arb",       dict(N=4), "generic", "one-bank round-robin arbiter, N=4"),
    ("fifo_w22_d4",       "sf_sramc_fifo",      dict(WIDTH=22, DEPTH=4), "generic", "response FIFO (22 bits x 4)"),
    ("perf_4x4",          "sf_sramc_perf",      dict(NUM_MASTERS=4, NUM_BANKS=4), "generic", "performance counters alone"),
    ("sub_4x4_o1",        "sf_sram_subsystem",  dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=1, BANK_DEPTH=1024), "fpga", "FULL subsystem: 4 masters x 4 x 1024 x 32-bit banks (16 KiB), 1 outstanding"),
    ("sub_4x4_o4_lat",    "sf_sram_subsystem",  dict(NUM_MASTERS=4, NUM_BANKS=4, MAX_OUT=4, BANK_DEPTH=1024, BANK_LATS="64'h0000000000004321"), "fpga", "FULL subsystem, 4 outstanding, bank latencies 1..4"),
    ("soc4",              "sf_sramc_soc4",      dict(), "fpga", "four-master SoC wrapper (ControlCore, DMA, Vector, TensorCore), defaults"),
]


def ys(script: str, tag: str):
    f = BUILD / "synth" / f"{tag}.ys"
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(script)
    return sh(["yosys", "-q", "-l", str(BUILD / "synth" / f"{tag}.log"), str(f)], cwd=ROOT, timeout=3000)


def chp(top, p):
    return "\n".join(f"chparam -set {k} {v} {top}" for k, v in p.items())


def parse_stat(txt: str) -> dict:
    """Yosys 0.33 `stat` format:  'Number of cells:  N' followed by '     <type>   <count>' lines (top module block)."""
    d = {"cells": 0, "types": {}, "memories": 0, "memory_bits": 0}
    blocks = re.split(r"=== (?:\S+) ===", txt)
    blk = blocks[-1] if len(blocks) > 1 else txt
    m = re.search(r"Number of cells:\s+(\d+)", blk)
    if m:
        d["cells"] = int(m.group(1))
    m = re.search(r"Number of memories:\s+(\d+)", blk)
    if m:
        d["memories"] = int(m.group(1))
    m = re.search(r"Number of memory bits:\s+(\d+)", blk)
    if m:
        d["memory_bits"] = int(m.group(1))
    for t, n in re.findall(r"^\s{4,}(\$?[\w$\\.]+)\s+(\d+)\s*$", blk, re.M):
        d["types"][t] = d["types"].get(t, 0) + int(n)
    return d


def last_stat_block(log: str) -> str:
    i = log.rfind("Printing statistics")
    return log[i:] if i >= 0 else log


def count(types: dict, pats) -> int:
    return sum(v for k, v in types.items() if any(re.search(p, k) for p in pats))


def generic(name, top, p):
    s = f"""{RD}
{chp(top, p)}
hierarchy -check -top {top}
synth -flatten -top {top}
opt_clean -purge
check -assert
tee -o {BUILD}/synth/{name}.ltp.txt ltp -noff
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean -purge
tee -o {BUILD}/synth/{name}.stat.txt stat
"""
    r = ys(s, name + "_generic")
    row = dict(flow="generic gates (AND/NAND/OR/NOR/XOR/XNOR/MUX + FFs)", rc=r["rc"], err=r["out"][-300:] if r["rc"] else "")
    if r["rc"] == 0:
        stat = (BUILD / "synth" / f"{name}.stat.txt").read_text()
        d = parse_stat(stat)
        t = d["types"]
        row.update(cells=d["cells"],
                   flipflops=count(t, [r"DFF", r"SDFF", r"\$_DFFE"]),
                   latches=count(t, [r"LATCH", r"dlatch"]),
                   gates=sum(v for k, v in t.items() if re.search(r"\$_(AND|NAND|OR|NOR|XOR|XNOR|MUX|NOT)_", k)),
                   mux=count(t, [r"\$_MUX_"]), types=t)
        ltp = (BUILD / "synth" / f"{name}.ltp.txt").read_text()
        m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", ltp)
        row["logic_depth_levels"] = int(m.group(1)) if m else None
        row["check_assert"] = "pass (no combinational loops, no multiple drivers, no undriven used wires)"
    return row


def fpga(name, top, p, family):
    cmd = {"xc7": f"synth_xilinx -family xc7 -flatten -top {top}", "ice40": f"synth_ice40 -flatten -top {top}", "ecp5": f"synth_ecp5 -flatten -top {top}"}[family]
    s = f"""{RD}
{chp(top, p)}
hierarchy -check -top {top}
{cmd}
tee -o {BUILD}/synth/{name}.{family}.stat.txt stat
"""
    r = ys(s, f"{name}_{family}")
    row = dict(flow=family, rc=r["rc"], err=r["out"][-300:] if r["rc"] else "")
    if r["rc"] == 0:
        stat = (BUILD / "synth" / f"{name}.{family}.stat.txt").read_text()
        d = parse_stat(stat)
        t = d["types"]
        row.update(cells=d["cells"], types=t,
                   luts=count(t, [r"^LUT\d$", r"SB_LUT4", r"TRELLIS_COMB"]),
                   ffs=count(t, [r"^FD", r"SB_DFF", r"TRELLIS_FF"]),
                   brams=count(t, [r"RAMB", r"SB_RAM", r"DP16KD", r"TDP", r"PDPW"]),
                   lutram=count(t, [r"RAM32", r"RAM64", r"RAMD", r"RAM256", r"TRELLIS_DPR"]),
                   carry=count(t, [r"CARRY"]))
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    res = []
    for name, top, p, kind, note in CASES:
        if a.only and not re.search(a.only, name):
            continue
        row = dict(name=name, top=top, params=p, note=note, results=[])
        if kind in ("generic", "all"):
            row["results"].append(generic(name, top, p))
        if kind in ("fpga", "all"):
            for fam in ("xc7", "ice40", "ecp5"):
                row["results"].append(fpga(name, top, p, fam))
        res.append(row)
        for r in row["results"]:
            print(name, r["flow"][:12], "rc=%s" % r["rc"], {k: r.get(k) for k in ("cells", "flipflops", "latches", "gates", "luts", "ffs", "brams", "logic_depth_levels")}, flush=True)
    write_json(REPORTS / "synth.json", dict(provenance=provenance(), results=res))
    bad = [(r["name"], x["flow"]) for r in res for x in r["results"] if x["rc"] != 0 or x.get("latches")]
    print("synth failures:", bad if bad else "none")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
