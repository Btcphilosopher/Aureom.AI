"""Shared helpers for the SRAMController scripts: paths, tool versions, configuration table,
command runner with provenance (every report records commands, exit codes and tool versions).
Python >= 3.10, standard library only."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import platform
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "rtl/sramc"
TB = ROOT / "tb"
LIB = ROOT / "third_party/silicaflux-sramcore/rtl/sram"
BUILD = Path(os.environ.get("SRAMC_BUILD", ROOT / "build"))
REPORTS = ROOT / "reports"
FORMAL = ROOT / "formal"

FILES_F = [l.strip() for l in (RTL / "files.f").read_text().splitlines() if l.strip() and not l.startswith("#")]
RTL_FILES = [ROOT / f for f in FILES_F]
INC = [RTL, LIB, TB]

VL_LINT = ["--lint-only", "-Wall", "-Wno-DECLFILENAME"]
VL_SIM = ["--binary", "--timing", "--timescale", "1ns/1ps", "--assert", "-DSFC_ASSERT", "-DSF_SRAM_POISON",
          "--x-assign", "unique", "--x-initial", "unique", "-Wno-fatal", "-Wno-DECLFILENAME", "-Wno-MULTITOP",
          "-Wno-UNUSEDSIGNAL", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-Wno-UNUSEDPARAM", "-Wno-CASEINCOMPLETE",
          "-Wno-INITIALDLY", "-Wno-BLKSEQ", "-Wno-IMPLICITSTATIC", "-Wno-PINCONNECTEMPTY", "-Wno-SYNCASYNCNET",
          "-Wno-CMPCONST", "-Wno-UNOPTFLAT", "-j", "4"]

# --------------------------------------------------------------------------- simulation configurations
# TB parameters: NM NB DW BD IDW MAXOUT ILV IDCHK SRCCHK MASKM PRIO HPM HPL LATS NRAND (+ BMIN BMAX BRDY BOUT for 'var')
# "stage": 1 = one master / one bank, 2 = one master / several banks, 3 = several masters (the brief's order).
CONFIGS = [
    # ---- stage 1: one master, one bank (the primary configuration)
    dict(name="s1_1x1",            top="tb_sramc_sub", p=dict(NM=1, NB=1),                                    seeds=[1, 2, 3], ic=True,  stage=1, note="ONE MASTER, ONE BANK (primary)"),
    dict(name="s1_1x1_o4_lat3",    top="tb_sramc_sub", p=dict(NM=1, NB=1, MAXOUT=4, LATS="3"),               seeds=[1],       ic=True,  stage=1, note="1x1, 4 outstanding, bank latency 3"),
    # ---- stage 2: one master, several banks
    dict(name="s2_1x4",            top="tb_sramc_sub", p=dict(NM=1, NB=4),                                    seeds=[1, 2],    ic=True,  stage=2, note="1 master, 4 banks"),
    dict(name="s2_1x4_o4_lat",     top="tb_sramc_sub", p=dict(NM=1, NB=4, MAXOUT=4, LATS="0x4231"),          seeds=[1],       ic=False, stage=2, note="1 master, 4 banks, mixed latencies, 4 outstanding"),
    dict(name="s2_1x2_high",       top="tb_sramc_sub", p=dict(NM=1, NB=2, MAXOUT=2, ILV=1),                  seeds=[1],       ic=True,  stage=2, note="HIGH interleave"),
    # ---- stage 3: several masters, round-robin per bank
    dict(name="s3_4x4",            top="tb_sramc_sub", p=dict(NM=4, NB=4),                                    seeds=[1, 2, 3], ic=True,  stage=3, note="FOUR MASTERS x FOUR BANKS, 1 outstanding"),
    dict(name="s3_4x4_o2",         top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=2),                          seeds=[1, 2],    ic=False, stage=3, note="2 outstanding per master"),
    dict(name="s3_4x4_o4",         top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=4),                          seeds=[1, 2],    ic=True,  stage=3, note="4 outstanding per master"),
    dict(name="s3_4x4_lat_o2",     top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=2, LATS="0x4321"),          seeds=[1, 2],    ic=False, stage=3, note="banks with latency 1,2,3,4"),
    dict(name="s3_4x4_uni_lat3_o4", top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=4, LATS="0x3333"),          seeds=[1, 2],    ic=True,  stage=3, note="UNIFORM_LAT (auto): equal bank latency 3, no bank-lock"),
    dict(name="s2_1x4_uni_o4",     top="tb_sramc_sub", p=dict(NM=1, NB=4, MAXOUT=4, LATS="0x2222"),          seeds=[1],       ic=False, stage=2, note="1 master streaming across 4 equal-latency banks"),
    dict(name="s3_4x4_high_o4",    top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=4, LATS="0x2413", ILV=1),   seeds=[1],       ic=False, stage=3, note="HIGH interleave, mixed latency"),
    dict(name="s3_4x1",            top="tb_sramc_sub", p=dict(NM=4, NB=1, MAXOUT=2),                          seeds=[1, 2],    ic=True,  stage=3, note="4 masters, a single bank: pure arbitration"),
    dict(name="s3_4x2",            top="tb_sramc_sub", p=dict(NM=4, NB=2, MAXOUT=2, LATS="0x21"),            seeds=[1],       ic=False, stage=3, note="4 masters, 2 banks"),
    dict(name="s3_3x4",            top="tb_sramc_sub", p=dict(NM=3, NB=4, MAXOUT=2),                          seeds=[1],       ic=False, stage=3, note="3 masters (non power of two)"),
    dict(name="s3_8x8_o2",         top="tb_sramc_sub", p=dict(NM=8, NB=8, MAXOUT=2, LATS="0x32121212"),      seeds=[1],       ic=False, stage=3, note="8 masters x 8 banks", nrand=8000),
    dict(name="s3_4x4_dw64",       top="tb_sramc_sub", p=dict(NM=4, NB=4, DW=64, MAXOUT=2),                  seeds=[1],       ic=False, stage=3, note="64-bit data"),
    dict(name="s3_4x4_dw128",      top="tb_sramc_sub", p=dict(NM=4, NB=2, DW=128, MAXOUT=2),                 seeds=[1],       ic=False, stage=3, note="128-bit data"),
    dict(name="s3_4x4_dw16",       top="tb_sramc_sub", p=dict(NM=4, NB=4, DW=16, MAXOUT=2),                  seeds=[1],       ic=False, stage=3, note="16-bit data"),
    dict(name="s3_4x4_dw8",        top="tb_sramc_sub", p=dict(NM=4, NB=4, DW=8, MAXOUT=2),                   seeds=[1],       ic=False, stage=3, note="8-bit data (byte addressing)"),
    dict(name="s3_4x4_mask1",      top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=2, MASKM=1),                seeds=[1],       ic=False, stage=3, note="MASK_MODE=ALIGNED"),
    dict(name="s3_4x4_idchk0",     top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=4, IDCHK=0),                seeds=[1],       ic=False, stage=3, note="ID_CHECK=0 (reuse allowed)"),
    dict(name="s3_4x4_srcchk0",    top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=2, SRCCHK=0),               seeds=[1],       ic=False, stage=3, note="SRC_CHECK=0 (only src_en gates)"),
    dict(name="s3_4x4_prio",       top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=2, PRIO=1, HPM=1, HPL=4),   seeds=[1, 2],    ic=False, stage=3, note="two priority classes: ControlCore HIGH"),
    dict(name="s3_4x4_prio2",      top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=4, PRIO=1, HPM=3, HPL=1),   seeds=[1],       ic=False, stage=3, note="two HIGH masters, HP_LIMIT=1"),
    dict(name="s3_4x4_idw2",       top="tb_sramc_sub", p=dict(NM=4, NB=4, MAXOUT=2, IDW=2),                  seeds=[1],       ic=False, stage=3, note="2-bit IDs (4 IDs, 2 outstanding)"),
    dict(name="s3_4x4_bd2",        top="tb_sramc_sub", p=dict(NM=4, NB=4, BD=2, MAXOUT=2),                   seeds=[1],       ic=False, stage=3, note="minimum bank depth"),
    dict(name="s3_4x4_bd100",      top="tb_sramc_sub", p=dict(NM=4, NB=4, BD=100, MAXOUT=2),                 seeds=[1],       ic=False, stage=3, note="non-power-of-two bank depth"),
    # ---- variable latency / random bank-busy models (controller proven against the BANK CONTRACT)
    dict(name="v_1x1",             top="tb_sramc_var", p=dict(NM=1, NB=1, MAXOUT=2, BADROW=3),                          seeds=[1, 2],    ic=True,  stage=1, note="1x1 random-latency bank"),
    dict(name="v_4x4_o1",          top="tb_sramc_var", p=dict(NM=4, NB=4, BADROW=5),                                    seeds=[1, 2],    ic=True,  stage=3, note="random latency 1..6, 75% ready"),
    dict(name="v_4x4_o4",          top="tb_sramc_var", p=dict(NM=4, NB=4, MAXOUT=4, BMAX=9, BADROW=7),                  seeds=[1, 2],    ic=False, stage=3, note="random latency 1..9, 4 outstanding"),
    dict(name="v_4x4_slow",        top="tb_sramc_var", p=dict(NM=4, NB=4, MAXOUT=4, BMIN=3, BMAX=14, BRDY=40, BOUT=16), seeds=[1], ic=False, stage=3, note="slow, busy banks"),
    dict(name="v_4x4_fast",        top="tb_sramc_var", p=dict(NM=4, NB=4, MAXOUT=4, BMIN=1, BMAX=1, BRDY=100, BOUT=2),  seeds=[1], ic=False, stage=3, note="fastest banks, shallow tracker"),
    dict(name="v_4x4_bout1",       top="tb_sramc_var", p=dict(NM=4, NB=4, MAXOUT=4, BOUT=1),                  seeds=[1],       ic=False, stage=3, note="tracker depth 1 (one access in flight per bank)"),
    dict(name="v_8x4_o2_prio",     top="tb_sramc_var", p=dict(NM=8, NB=4, MAXOUT=2, PRIO=1, HPM=5, HPL=2),    seeds=[1],       ic=False, stage=3, note="8 masters, random banks, priority classes"),
]

# illegal parameterisations: (name, top, overrides, expected message fragment)
NEGATIVE = [
    ("masters_zero",        "sf_sram_controller", dict(NUM_MASTERS=0),            "NUM_MASTERS"),
    ("masters_17",          "sf_sram_controller", dict(NUM_MASTERS=17),           "NUM_MASTERS"),
    ("banks_3",             "sf_sram_controller", dict(NUM_BANKS=3),              "NUM_BANKS"),
    ("banks_32",            "sf_sram_controller", dict(NUM_BANKS=32),             "NUM_BANKS"),
    ("data_width_12",       "sf_sram_controller", dict(DATA_WIDTH=12),            "DATA_WIDTH"),
    ("data_width_24",       "sf_sram_controller", dict(DATA_WIDTH=24),            "DATA_WIDTH"),
    ("data_width_256",      "sf_sram_controller", dict(DATA_WIDTH=256),           "DATA_WIDTH"),
    ("bank_depth_1",        "sf_sram_controller", dict(BANK_DEPTH=1),             "BANK_DEPTH"),
    ("interleave_5",        "sf_sram_controller", dict(INTERLEAVE=5),             "INTERLEAVE"),
    ("high_needs_pow2",     "sf_sram_controller", dict(INTERLEAVE=1, BANK_DEPTH=100), "INTERLEAVE=HIGH"),
    ("max_out_zero",        "sf_sram_controller", dict(MAX_OUT=0),                "MAX_OUT"),
    ("max_out_17",          "sf_sram_controller", dict(MAX_OUT=17),               "MAX_OUT"),
    ("bank_out_zero",       "sf_sram_controller", dict(BANK_OUT=0),               "BANK_OUT"),
    ("id_width_zero",       "sf_sram_controller", dict(ID_WIDTH=0),               "ID_WIDTH"),
    ("addr_width_4",        "sf_sram_controller", dict(ADDR_WIDTH=4),             "ADDR_WIDTH"),
    ("capacity_overflow",   "sf_sram_controller", dict(ADDR_WIDTH=12),            "capacity"),
    ("mask_mode_3",         "sf_sram_controller", dict(MASK_MODE=3),              "MASK_MODE"),
    ("id_check_2",          "sf_sram_controller", dict(ID_CHECK=2),               "ID_CHECK"),
    ("arb_n_zero",          "sf_sramc_arb",       dict(N=0),                      "N must be"),
    ("arb_hp_limit_zero",   "sf_sramc_arb",       dict(HP_LIMIT=0),               "HP_LIMIT"),
    ("fifo_depth_zero",     "sf_sramc_fifo",      dict(DEPTH=0),                  "DEPTH"),
    ("bank_lat_zero",       "sf_sramc_bank",      dict(LAT=0),                    "LAT"),
]


def sh(cmd, cwd=None, timeout=3600, env=None) -> dict:
    t0 = time.time()
    try:
        p = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        rc, out = p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        rc, out = -9, f"TIMEOUT after {timeout}s\n{(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout, bytes) else (e.stdout or '')}"
    return {"cmd": " ".join(str(c) for c in cmd), "rc": rc, "out": out, "secs": round(time.time() - t0, 2)}


def tool_versions() -> dict:
    def first_line(cmd):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return (r.stdout + r.stderr).strip().splitlines()[0]
        except Exception:
            return "NOT INSTALLED"
    return {
        "verilator": first_line(["verilator", "--version"]),
        "iverilog": first_line(["iverilog", "-V"]),
        "yosys": first_line(["yosys", "-V"]),
        "z3": first_line(["z3", "--version"]),
        "python": platform.python_version(),
        "vivado": "NOT INSTALLED" if not shutil.which("vivado") else "present",
        "quartus": "NOT INSTALLED" if not shutil.which("quartus_sh") else "present",
        "openroad": "NOT INSTALLED" if not shutil.which("openroad") else "present",
    }


def src_hash(files) -> str:
    h = hashlib.sha256()
    for f in sorted(str(x) for x in files):
        h.update(f.encode())
        h.update(Path(f).read_bytes())
    return h.hexdigest()


def provenance(extra=None) -> dict:
    d = {"generated": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
         "tools": tool_versions(),
         "rtl_sha256": src_hash([*RTL.glob("*.sv"), *RTL.glob("*.svh")])}
    if extra:
        d.update(extra)
    return d


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, sort_keys=False) + "\n")


def vl_gargs(p: dict, top: str) -> list:
    out = []
    for k, v in p.items():
        if k == "LATS":
            v = f"64'h{int(str(v), 0):x}" if not str(v).startswith("64'h") else v
        out.append(f"-G{k}={v}")
    return out


def ic_pargs(p: dict, top: str) -> list:
    out = []
    for k, v in p.items():
        if k == "LATS":
            v = int(str(v), 0)
        out.append(f"-P{top}.{k}={v}")
    return out


def rtl_args():
    return [*(f"-I{d}" for d in INC), *[str(f) for f in RTL_FILES]]
