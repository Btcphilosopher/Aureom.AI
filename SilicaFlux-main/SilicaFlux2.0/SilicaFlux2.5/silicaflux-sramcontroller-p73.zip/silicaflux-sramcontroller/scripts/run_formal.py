#!/usr/bin/env python3
"""Formal runs: Yosys 0.33 (read_verilog -formal) -> AIGER -> ABC bmc3 (bounded) and pdr (unbounded proof).
Every `expect FAIL` row is a NON-VACUITY check: the same harness on a mutated design or a reachability probe
must produce a counter-example.  A PDR verdict of UNDECIDED means the engine hit its time budget: the claim
is then only the BMC depth.   usage: run_formal.py [--only REGEX] [--jobs N] [--quick]"""
from __future__ import annotations

import argparse
import json
import concurrent.futures as cf
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import *   # noqa
from run_mutants import MUT   # noqa

SYS = dict(DW=8)
J = []   # (name, top, params, defines, bmc_depth, pdr_seconds, expect, note, mutant_id or None)


def add(name, top, params, bmc, pdr, expect="PASS", defs="", note="", mut=None):
    J.append(dict(name=name, top=top, params=params, defs=defs, bmc=bmc, pdr=pdr, expect=expect, note=note, mut=mut))


# ---------------------------------------------------------------- FIFO (unbounded)
for w, d in [(2, 1), (2, 2), (2, 3), (3, 4)]:
    add(f"fifo_w{w}_d{d}", "fv_sramc_fifo", f"WIDTH={w} DEPTH={d}", 30, 120, note="F1-F4 vs reference queue, no environment assumption")
# ---------------------------------------------------------------- arbiter (unbounded)
for n in (2, 3, 4, 5):
    add(f"arb_rr_n{n}", "fv_sramc_arb", f"N={n}", 30, 120, note="exclusive grant, work conserving, bounded waiting N-1")
for n, hpm, hpl in [(3, "16'h1", 2), (4, "16'h3", 1), (4, "16'h5", 3), (5, "16'h6", 2), (4, "16'h1", 4)]:
    add(f"arb_prio_n{n}_hpm{hpm[4:]}_l{hpl}", "fv_sramc_arb", f"N={n} PRIO=1 HPM={hpm} HPL={hpl}", 30, 120, note="two classes, starvation guard bounds")
# ---------------------------------------------------------------- system: base policy (1 outstanding per master)
M1 = "DW=8 MAXOUT=1 BOUT=1"
add("sys_2x2_o1", "fv_sramc", M1, 40, 700, note="2 masters x 2 banks, 1 outstanding: ALL embedded checks + marked-transaction scoreboard")
add("sys_2x2_o1_bout2", "fv_sramc", "DW=8 MAXOUT=1 BOUT=2", 20, 300, note="deeper bank tracker")
add("sys_2x2_o1_prio", "fv_sramc", M1 + " PRIO=1 HPM=16'h1 HPL=2", 20, 300, note="priority classes")
add("sys_2x2_o1_dw16", "fv_sramc", "DW=16 MAXOUT=1 BOUT=1", 20, 300, note="16-bit data: alignment errors reachable")
add("sys_2x2_o1_nostab", "fv_sramc", M1, 20, 300, defs="-DSFC_NO_STABILITY", note="masters may WITHDRAW requests: safety does not rely on request stability")
add("sys_2x2_o1_live", "fv_sramc", M1 + " LIVE=1 TL=14", 24, 0, note="bounded completion (<= 14 cycles after acceptance) under a bounded environment")
# ---------------------------------------------------------------- system: expanded concurrency
add("sys_1x2_o2", "fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2", 24, 900, note="1 master, 2 banks, 2 outstanding: in-order rule across banks")
add("sys_2x1_o2", "fv_sramc", "NM=2 NB=1 DW=8 MAXOUT=2 BOUT=2", 24, 900, note="2 masters, 1 bank, 2 outstanding: arbitration with outstanding limits")
add("sys_2x2_o2", "fv_sramc", "DW=8 MAXOUT=2 BOUT=2", 14, 0, note="2 masters x 2 banks, 2 outstanding (bounded: depth 14)")
add("sys_1x2_o2_uni", "fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=3 UNI=1 UL=2 DUTUNI=1", 24, 900, note="UNIFORM_LAT=1 with FIXED-latency banks (latency 2): no bank-lock, still in order")
add("sys_2x2_o2_uni", "fv_sramc", "DW=8 MAXOUT=2 BOUT=3 UNI=1 UL=2 DUTUNI=1", 16, 0, note="2x2, UNIFORM_LAT=1, fixed-latency banks (bounded)")
add("sys_1x2_o2_uni_l1", "fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2 UNI=1 UL=1 DUTUNI=1", 24, 900, note="UNIFORM_LAT=1, fixed latency 1")
add("sys_1x2_o2_uni_live", "fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=3 UNI=1 UL=2 DUTUNI=1 LIVE=1 TL=16", 24, 0, note="bounded completion with UNIFORM_LAT")
add("neg_uniform_free_banks", "fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2 UNI=0 DUTUNI=1", 20, 0, expect="FAIL", note="NEGATIVE CONTROL: UNIFORM_LAT=1 on free-latency banks violates its contract -> counter-example (the option is NOT free)")
add("sys_1x2_o2_bout1", "fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=1", 24, 600, note="tracker depth 1 with 2 outstanding")
add("sys_1x2_o2_live", "fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2 LIVE=1 TL=20", 24, 0, note="bounded completion with 2 outstanding")
# ---------------------------------------------------------------- reachability probes (expect FAIL = reachable)
PROBES = {1: "all banks accessed in one cycle", 2: "two masters, same bank, one loses arbitration", 3: "response held 2+ cycles (back-pressure)",
          4: "marked read delivered with non-zero data", 5: "marked request answered SFC_ST_ID", 6: "marked request answered SFC_ST_CANCEL",
          7: "marked request answered SFC_ST_BANK", 8: "answered SFC_ST_RANGE", 9: "answered SFC_ST_ALIGN", 10: "answered SFC_ST_MASK",
          11: "answered SFC_ST_SRC", 12: "answered SFC_ST_POISON", 13: "a master with 2 outstanding", 14: "marked write completed OK",
          15: "marked read completed OK"}
for k, why in PROBES.items():
    dw = 16 if k == 9 else 8
    add(f"probe{k:02d}", "fv_sramc", f"DW={dw} MAXOUT=2 BOUT=2 PROBE={k}", 18, 0, expect="FAIL", note=f"reachable: {why}")
# ---------------------------------------------------------------- formal mutants (expect FAIL)
FM = {  # mutant id -> (top, params)
    "M01": ("fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2"), "M02": ("fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2"),
    "M03": ("fv_sramc", M1), "M04": ("fv_sramc", M1), "M05": ("fv_sramc", M1), "M06": ("fv_sramc", M1), "M07": ("fv_sramc", M1),
    "M08": ("fv_sramc", M1), "M09": ("fv_sramc_arb", "N=3"), "M10": ("fv_sramc_arb", "N=3"),
    "M11": ("fv_sramc_arb", "N=3 PRIO=1 HPM=16'h1 HPL=2"), "M12": ("fv_sramc", "DW=16 MAXOUT=1 BOUT=1"), "M13": ("fv_sramc", M1),
    "M14": ("fv_sramc", M1), "M15": ("fv_sramc", M1), "M16": ("fv_sramc", M1), "M17": ("fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2"),
    "M18": ("fv_sramc", M1), "M19": ("fv_sramc", "DW=16 MAXOUT=1 BOUT=1"), "M20": ("fv_sramc", M1),
    "M21": ("fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2"), "M22": ("fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2"),
    "M23": ("fv_sramc", "DW=16 MAXOUT=1 BOUT=1"), "M24": ("fv_sramc", M1), "M25": ("fv_sramc", M1), "M26": ("fv_sramc", "NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2"),
    "M27": ("fv_sramc", M1), "M28": ("fv_sramc", "NM=2 NB=1 DW=8 MAXOUT=2 BOUT=1"), "M30": ("fv_sramc", M1),   # M31 (accept during rst_n=0) is simulation-only: the harness models reset only in cycle 0
    
    "M33": ("fv_sramc", M1), "M34": ("fv_sramc", M1), "M35": ("fv_sramc", M1), "M36": ("fv_sramc", M1), "M37": ("fv_sramc", M1),
    "M40": ("fv_sramc", M1),
}
for mid, (top, pr) in FM.items():
    m = next(x for x in MUT if x[0] == mid)
    add(f"mut_{mid}", top, pr, 24, 0, expect="FAIL", note=m[4], mut=mid)
add("mut_FIFO_full_pop", "fv_sramc_fifo", "WIDTH=2 DEPTH=2", 20, 0, expect="FAIL", note="FIFO drops a push into a full FIFO that is popped in the same cycle (M29)", mut="M29")


def run_job(j):
    name = j["name"]
    d = BUILD / "formal" / name
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True)
    env = dict(os.environ)
    if j["mut"]:
        m = next(x for x in MUT if x[0] == j["mut"])
        src = d / "src"
        (src / "rtl").mkdir(parents=True)
        shutil.copytree(ROOT / "rtl/sramc", src / "rtl/sramc")
        f = src / m[1]
        t = f.read_text()
        if t.count(m[2]) != 1:
            return dict(name=name, ok=False, verdict="INVALID", detail=f"mutation pattern occurs {t.count(m[2])} times", **{k: j[k] for k in ("expect", "note")})
        f.write_text(t.replace(m[2], m[3]))
        env["FV_SRC"] = str(src)
    r = sh([ROOT / "scripts/fv_flow.sh", d, j["top"], j["params"], j["defs"]], env=env, timeout=1800)
    if r["rc"] != 0 or not (d / "model.aig").exists():
        return dict(name=name, ok=False, verdict="BUILD-FAIL", detail=r["out"][-400:], **{k: j[k] for k in ("expect", "note")})
    r = sh([ROOT / "scripts/fv_abc.sh", d / "model.aig", j["bmc"], j["pdr"]], timeout=j["pdr"] + 3000)
    lines = [l for l in r["out"].splitlines() if l.startswith(("BMC", "PDR"))]
    bmc = next((l for l in lines if l.startswith("BMC")), "BMC ?")
    pdr = next((l for l in lines if l.startswith("PDR")), "")
    failed = "FAIL" in bmc or "FAIL" in pdr
    if j["expect"] == "FAIL":
        ok = failed
        verdict = "REACHED/KILLED" if failed else "NOT-REACHED"
    else:
        ok = (not failed) and "PASS" in bmc
        verdict = "PROVED" if "PROVED" in pdr else ("BOUNDED" if ok else ("TIMEOUT" if "UNKNOWN" in bmc else "FAILED"))
    st = (d / "model.aig").stat().st_size
    return dict(name=name, ok=ok, verdict=verdict, bmc=bmc, pdr=pdr, expect=j["expect"], note=j["note"], top=j["top"],
                params=j["params"] + (" " + j["defs"] if j["defs"] else ""), secs=r["secs"], aig_bytes=st)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default="formal")
    ap.add_argument("--merge", action="store_true", help="replace the named jobs inside an existing reports/<out>.json instead of rewriting it")
    a = ap.parse_args()
    jobs = [j for j in J if not a.only or re.search(a.only, j["name"])]
    res = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = [ex.submit(run_job, j) for j in jobs]
        for f in cf.as_completed(futs):
            r = f.result()
            print(f"{'OK ' if r['ok'] else 'BAD'} {r['name']:28s} {r['verdict']:15s} {r.get('bmc','')} {r.get('pdr','')} [{r.get('secs','')}s]", flush=True)
            res.append(r)
    order = {j["name"]: i for i, j in enumerate(J)}
    res.sort(key=lambda r: order.get(r["name"], 0))
    if a.merge and (REPORTS / f"{a.out}.json").exists():
        old = json.loads((REPORTS / f"{a.out}.json").read_text())
        byname = {r["name"]: r for r in old["results"]}
        for r in res:
            byname[r["name"]] = r
        keep = [n for n in order if n in byname]       # drops jobs that no longer exist (e.g. mut_M31)
        res = [byname[n] for n in keep]
    write_json(REPORTS / f"{a.out}.json", dict(provenance=provenance(), results=res))
    bad = [r for r in res if not r["ok"]]
    print(f"formal: {len(res) - len(bad)}/{len(res)} as expected")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
