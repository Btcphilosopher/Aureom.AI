#!/bin/bash
# usage: vl_build.sh <top> <outdir> [verilator -G... args]   (builds a Verilator binary of a testbench)
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOP="$1"; OUT="$2"; shift 2
cd "$ROOT"
verilator --binary --timing --timescale 1ns/1ps --assert -DSFC_ASSERT -DSF_SRAM_POISON --x-assign unique --x-initial unique \
  -Wno-fatal -Wno-DECLFILENAME -Wno-MULTITOP -Wno-UNUSEDSIGNAL -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -Wno-UNUSEDPARAM -Wno-CASEINCOMPLETE \
  -Wno-INITIALDLY -Wno-BLKSEQ -Wno-IMPLICITSTATIC -Wno-PINCONNECTEMPTY -Wno-SYNCASYNCNET -Wno-CMPCONST -Wno-UNOPTFLAT \
  -Irtl/sramc -Ithird_party/silicaflux-sramcore/rtl/sram -Itb $(grep -v '^#' rtl/sramc/files.f | tr '\n' ' ') \
  tb/sf_sramc_bankmodel.sv tb/$TOP.sv --top-module $TOP "$@" -Mdir "$OUT" -o "$TOP" -j 4 > "$OUT.log" 2>&1 || { tail -40 "$OUT.log"; exit 1; }
