#!/bin/bash
# usage: fv_flow.sh <outdir> <top> "<chparam list: NAME=VAL ...>" "<extra read_verilog defines>" [extra yosys commands]
# Builds an AIGER model of a formal harness (Yosys 0.33 read_verilog -formal -> AIGER, zero-init) for ABC.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="${FV_SRC:-$ROOT}"
OUT="$1"; TOP="$2"; PARAMS="$3"; DEFS="$4"; EXTRA="$5"
mkdir -p "$OUT"
CH=""
for p in $PARAMS; do CH="$CH
chparam -set ${p%%=*} ${p#*=} $TOP"; done
cat > "$OUT/model.ys" <<EOS
read_verilog -formal -sv -DFORMAL -DSFC_ASSERT $DEFS -I$SRC/rtl/sramc $SRC/rtl/sramc/sf_sramc_fifo.sv $SRC/rtl/sramc/sf_sramc_arb.sv $SRC/rtl/sramc/sf_sramc_perf.sv $SRC/rtl/sramc/sf_sram_controller.sv $ROOT/formal/fv_sramc_arb.sv $ROOT/formal/fv_sramc_fifo.sv $ROOT/formal/fv_sramc.sv
$CH
hierarchy -check -top $TOP
proc; flatten; opt_clean
async2sync
setundef -anyseq
dffunmap
memory_map
opt -fast
techmap
dfflegalize -cell \$_DFF_P_ 01
abc -fast -g AND
opt_clean
write_aiger -zinit $OUT/model.aig
EOS
yosys -q -l "$OUT/yosys.log" "$OUT/model.ys" 2>&1 | grep -v "Replacing memory" | head -5
