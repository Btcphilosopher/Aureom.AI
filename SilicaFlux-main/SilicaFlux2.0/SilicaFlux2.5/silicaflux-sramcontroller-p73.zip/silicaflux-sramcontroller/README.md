# SilicaFlux SRAMController (`silicaflux-sramcontroller`) — multi-master banked SRAM access controller

**Primary RTL:** `rtl/sramc/sf_sram_controller.sv` · Project 73 · Aureom.AI | SilicaFlux Semiconductor Systems

Schedules requests from several masters (ControlCore, DMA, Vector Engine, TensorCore) onto the SilicaFlux banked SRAM: independent **round-robin arbitration per bank**,
**per-bank completion tracking** (variable and out-of-order bank latency), **credit-based response buffering** (a response is never dropped), explicit **error status**,
**flush/cancel**, an optional **two-class priority with a starvation bound**, and **hardware performance counters**.
Interface = SilicaFlux **SFB2** + request ID + status. Banks = the verified `sf_sram_core` (Project 71, vendored unmodified) or anything that honours the bank contract.

> **Not committed to GitHub** — delivered as a plain archive, like the other SilicaFlux modules. Evidence is simulation (Verilator 5.020, Icarus 12.0) and Yosys 0.33 / ABC only:
> no vendor FPGA tool, no board, no silicon, **no timing, frequency, area-in-µm² or power claim anywhere**.

## Quick start

```
make ctl-primary   # ONE master, ONE bank first (lint + simulation, Verilator + Icarus)
make ctl-quick     # lint + 1x1, 1x4, 4x4 (MAX_OUT 1 and 4), random-latency banks
make ctl-all       # lint, negative tests, sweep, mutants, formal, synthesis, gate-level, performance, summary
make package       # ../silicaflux-sramcontroller-p73.zip
```
Requirements: Verilator ≥ 5.020, Icarus Verilog 12, Yosys 0.33 (with `yosys-abc`), Python ≥ 3.10 (standard library only). Start reading at `reports/SUMMARY.md`, then `docs/01_interface_and_semantics.md`.

## The controller in one screen

```systemverilog
sf_sram_subsystem #(.NUM_MASTERS(4), .NUM_BANKS(4), .BANK_DEPTH(1024), .DATA_WIDTH(32), .MAX_OUT(4)) u_sram (   // 4 masters x 16 KiB
  .clk, .rst_n,
  .m_req_valid, .m_req_ready, .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb, .m_req_id, .m_req_src, .m_req_err,   // masters (flat vectors)
  .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_id, .m_rsp_src, .m_rsp_we, .m_rsp_err, .m_rsp_status,
  .src_en, .flush, .idle, .sts_rsp_overflow, .sts_bank_proto, .perf_clr, .perf_sel, .perf_val);
```

| | |
|---|---|
| Accept | `m_req_valid && m_req_ready`; for an error-free request the bank access is **issued in the same cycle** |
| Complete | `m_rsp_valid && m_rsp_ready`; one response per accepted request, never dropped, payload stable until taken |
| Latency (uncontended) | read/write: accept + bank latency + 1; rejected request: accept + 1 |
| Ordering | per master **in order**; per bank in order; globally **not ordered** (any completion order across banks/masters) |
| Concurrency | `MAX_OUT` outstanding per master (default **1**; 2/4 verified); bank-lock rule, or `UNIFORM_LAT` for equal-latency banks |
| Arbitration | per bank, round robin over eligible masters; optional HIGH/LOW classes with `HP_LIMIT` guard — **no starvation** (proven) |
| Errors | `RANGE ALIGN MASK SRC ID POISON CANCEL BANK`, no side effect, `rsp_rdata = 0` |
| Reset / flush | hard reset: silent cancel (SFB2 R11); `flush`: explicit `CANCEL` responses for accesses inside a bank |
| Counters | arbitration wait, latency, conflicts, busy, completed, outstanding, R/W throughput — exact (verified against a shadow) |

## Deliverables → location

| Brief item | Where |
|---|---|
| `sf_sram_controller.sv` | `rtl/sramc/sf_sram_controller.sv` |
| Arbitration logic | `rtl/sramc/sf_sramc_arb.sv` (per-bank RR, optional two-class priority) |
| Request/response buffers | `rtl/sramc/sf_sramc_fifo.sv` (bounded FIFO: per-master response, per-bank tracker) |
| Transaction tracking | per-bank tracker + per-master order queue inside `sf_sram_controller.sv` |
| Performance counters | `rtl/sramc/sf_sramc_perf.sv` |
| Assertions | embedded `SFC_CHK` / `SFC_ASM` (`-DSFC_ASSERT`), harnesses in `formal/` |
| Self-checking testbench | `tb/tb_sramc_sub.sv`, `tb/tb_sramc_var.sv` + `tb/sramc_tb_body.svh`; `tb/tb_sramc_gls.sv`; `tb/tb_sramc_perf.sv` |
| Synthesis results | `reports/synth.md` (+ `reports/gls.md`) |
| Integrated subsystem / four named masters | `rtl/sramc/sf_sram_subsystem.sv`, `rtl/sramc/sf_sramc_soc4.sv`, bank adapter `rtl/sramc/sf_sramc_bank.sv` |
| Repository audit | `docs/00_repository_audit.md` |

## Layout

```
rtl/sramc/       sf_sram_controller.sv  sf_sramc_arb.sv  sf_sramc_fifo.sv  sf_sramc_perf.sv  sf_sramc_bank.sv  sf_sram_subsystem.sv  sf_sramc_soc4.sv  sf_sramc_defs.svh  files.f
third_party/     silicaflux-sramcore/   sf_sram_core / array / defs (Project 71) vendored unmodified (PROVENANCE.md, SHA256SUMS)
tb/              tb_sramc_sub.sv  tb_sramc_var.sv  sramc_tb_body.svh  sramc_tb_common.svh  sf_sramc_bankmodel.sv  tb_sramc_gls.sv  tb_sramc_perf.sv
formal/          fv_sramc.sv (system + marked-transaction scoreboard)  fv_sramc_arb.sv  fv_sramc_fifo.sv
scripts/         common.py  run_regress.py  run_mutants.py  run_formal.py  run_synth.py  run_gls.py  run_perf.py  make_summary.py  package.sh  fv_flow.sh  fv_abc.sh  vl_build.sh
docs/            00 audit · 01 interface and semantics · 02 arbitration, ordering, performance · 03 verification · 04 integration · 05 status and next actions
reports/         SUMMARY.md  lint.md  regression.md  formal.md  mutants.md  synth.md  gls.md  perf.md  (+ .json with commands, seeds, tool versions)
SHA256SUMS       every delivered file
```

## Results (generated from the JSON reports of the final run)

<!--RESULTS-->
| Check | Result | Notes |
|---|---|---|
| Lint: Verilator `-Wall` + Icarus `-Wall` | 32 pass / 0 fail | zero warnings, every top and parameter variant, with and without embedded assertions |
| Illegal parameterisations rejected | 22 pass / 0 fail | Verilator + Icarus + Yosys |
| Self-checking simulation | 59 pass / 0 fail | 59 runs, 81,978,390 scoreboard checks; 1x1 -> 1xN -> 4x4, MAX_OUT 1/2/4, 3 and 8 masters, 8..128-bit, priority classes, random-latency banks |
| Reference transaction interface + four-master SoC wrapper tests | 2 pass / 0 fail | `sf_sramc_if` connect test + protocol checker (lint clean); `sf_sramc_soc4` wiring test (4 masters in parallel, cross-master reads, errors, disabled source) |
| Same seed = same behaviour, Verilator vs Icarus | 10 pass / 0 fail | metric line and check count compared |
| Formal (Yosys + ABC) | 80 as expected / 0 unexpected | **23 unbounded proofs (PDR)**, 5 bounded (BMC depth in `reports/formal.md`), 52 non-vacuity checks (probes, mutants, negative control) |
| Mutation sanity | 41 killed / 0 survived | of 41 injected RTL bugs |
| Gate-level lock-step (RTL vs Yosys gate netlist) | 4 pass / 0 fail | 4 configurations x 2 seeds x 60 000 cycles, every output every cycle |
| Synthesis: ctl_1x1_o1 | 259 cells, 67 FF, 0 latches | primary: 1 master, 1 bank, no counters (generic gates; no timing claim) |
| Synthesis: ctl_4x4_o1 | 3688 cells, 294 FF, 0 latches | 4 masters x 4 banks, 1 outstanding, no counters (generic gates; no timing claim) |
| Synthesis: ctl_4x4_o4_perf | 22769 cells, 3679 FF, 0 latches | 4x4, 4 outstanding, counters (generic gates; no timing claim) |
| Synthesis: full subsystem, xc7 | 6245 LUT, 2770 FF, 4 block RAM | 4 x 1024 x 32-bit (16 KiB) banks + controller (Yosys inference evidence only) |

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (); Yosys 0.33 (git sha1 2584903a060); python 3.13.18. Not installed: vivado=NOT INSTALLED, quartus=NOT INSTALLED, openroad=NOT INSTALLED.  RTL sha256 `da5b4eae35469c90…`.
<!--/RESULTS-->

## Honest limits

* Simulation + Yosys/ABC only. **Formal proofs are for small instances**: arbiter, FIFO, the whole controller at 2 masters × 2 banks with `MAX_OUT = 1`, and at `MAX_OUT = 2` for 1×2 and 2×1 are *unbounded* proofs; **2×2 at `MAX_OUT = 2` is bounded** (BMC depth 14). Larger configurations rest on simulation, mutation and gate-level lock-step (`reports/formal.md` lists every verdict).
* With **non-uniform bank latencies** a master streaming across word-interleaved banks is limited by the in-order rule; equal-latency banks (`UNIFORM_LAT`, automatic) or `INTERLEAVE = HIGH` avoid it (measured 2–4× streaming throughput, `reports/perf.md`). Out-of-order completion is not implemented.
* The 32-bit performance counters cost ~5× the controller's own logic (18 697 vs 3 688 generic cells for 4×4); `PERF_EN = 0` or `CNT_W = 16` shrink it.
* MemoryFlow's ECC `sf_sram_bank` satisfies the bank contract on paper but was not instantiated; only `sf_sram_core` and contract-conformant models were simulated.
* No timing, frequency, area or power figure; no ASIC macro flow; hard reset mid-run is simulation-only evidence.
