# Compile order (paths relative to the package root).  Include dirs: rtl/sramc third_party/silicaflux-sramcore/rtl/sram
third_party/silicaflux-sramcore/rtl/sram/sf_sram_array.sv
third_party/silicaflux-sramcore/rtl/sram/sf_sram_core.sv
rtl/sramc/sf_sramc_fifo.sv
rtl/sramc/sf_sramc_arb.sv
rtl/sramc/sf_sramc_perf.sv
rtl/sramc/sf_sram_controller.sv
rtl/sramc/sf_sramc_bank.sv
rtl/sramc/sf_sram_subsystem.sv
rtl/sramc/sf_sramc_soc4.sv
