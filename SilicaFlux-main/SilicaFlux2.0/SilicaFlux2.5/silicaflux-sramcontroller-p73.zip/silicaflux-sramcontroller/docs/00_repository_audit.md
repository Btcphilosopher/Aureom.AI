# 00 — Repository audit

Scope: everything in the repository that touches SRAM cores and banks, memory controllers, arbitration, DataFabric, DMA, TensorCore, Vector Engine and ControlCore — read **before** writing RTL.

## 1. Method, and what was run versus only read

The repository (`Btcphilosopher/Aureom.AI`) is a collection of delivered archives; the SilicaFlux material is under `SilicaFlux-main/…` as `.zip` files (the `.sf` extension is SystemVerilog). The relevant archives were extracted into
a scratch directory and read; nothing in the repository was modified and nothing is committed (the deliverable is this archive).

| Activity | Status |
|---|---|
| Archives located, extracted, READMEs/RTL of the SRAM, memory-controller, fabric, scratchpad, DMA and master stand-in modules read | done |
| `sf_sram_core.sv`, `sf_sram_array.sv`, `sf_sram_defs.svh` (Project 71) read in full; **vendored unmodified**, SHA-256 equal to the archive's own `SHA256SUMS` | done |
| `sram_bank_controller.sv`, `sf_sram_bank.sv`, `sf_spm_banked.sv`, `sfb_arbiter.sv`, `sfb_skid_buffer.sv`, `PROTOCOL.md` (SFB2), `hpc_spm_bank_arb.sv`, p40 stand-in masters read | done |
| Other packages' regression / synthesis claims | read, **not** re-run |
| The tool chain of the earlier packages (Verilator 5.020, Icarus 12.0, Yosys 0.33) was reproduced here | done |

## 2. What exists (paths inside `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` unless noted)

| Area | Where | Finding | Decision |
|---|---|---|---|
| **`sf_sram_core.sv`** | `silicaflux-sramcore-p71.zip` → `rtl/sram/` | Verified single-port synchronous SRAM: `READ_LATENCY`, byte enables, write ack, explicit bounds policy, storage never reset. Always accepts, no ready, fixed timing | **reused unmodified** as the bank storage (`sf_sramc_bank` adds the controller's bank contract on top) |
| **`sf_sram_bank.sv`** | `silicaflux-memoryflow-v2.0.0.zip` → `rtl/sram/` | Protected bank (parity / SECDED, MBIST, error injection). `req_ready` drops for the SECDED read-modify-write cycle; fixed 2-cycle response with a tag | **not instantiated**; it satisfies the bank contract as is (`req_ready`/`rsp_valid`/`rsp_rdata`, `rsp_uncorr` → `bk_rsp_err`), see `04` |
| **Existing memory controllers** | `sf_spm_banked.sv` (MemoryFlow), `sram_bank_controller.sv` + `sram_rsp_path.sv` (`silicaflux-sramlib.zip`), `hpc_spm_bank_arb.sv` (`silicaflux-hpc-m04-scratchpad.zip`) | N masters × B banks, per-bank round robin, per-master response FIFO + credits, in-order per port. **All assume every access takes one identical fixed latency** (so completions are in order by construction), have no byte-address errors beyond "out of range", no source / ID-reuse / strobe checks, no variable latency or busy banks, no cancel, and no counters for arbitration wait or latency | their *ideas* are reused (per-bank RR, credit = FIFO depth, error answered not dropped, "the first requester is always granted" pointer rule from `hpc_spm_bank_arb`); the new controller removes the fixed-latency assumption |
| **DataFabric** | `silicaflux-datafabric.zip` | SFB2 protocol (valid/ready both ways, R1–R12), `sfb_arbiter` (RR with grant lock, PDR-proven), `sfb_skid_buffer`, `sfb_sram_slave` (SRAM slave over `sram_sp`), one-outstanding crossbar. PROTOCOL.md §8 *plans* `req_id/rsp_id` and multiple outstanding | **extended as planned**: SFB2-compatible master ports + ID + status; rules R1–R12 carried over (`01` §3) |
| **DMA** | `silicaflux-datafabric.zip` → `rtl/dma`, `silicaflux-clouddma-p64.zip`, p40 `sf_dma` stand-in | masters with `req/rsp` (stand-in: no `rsp_ready`, 16-bit word-window address, no strobes) | master #1 of the SoC wrapper; adapter notes in `04` |
| **TensorCore / Vector Engine** | `silicaflux-tensorcore0*.zip`, `silicaflux-hpc-m03-vector-array.zip`, p40 `sf_tensor_cluster`, `sf_vector_cluster` | request/response memory ports of the same shape (`req_valid/ready/we/addr[15:0]/wdata`, `rsp_valid/err/rdata`) | masters #2 (Vector Engine) and #3 (TensorCore) of the SoC wrapper |
| **ControlCore** | `silicaflux-controlcore.zip`, p40 `sf_control_core` | `m_req_*`/`m_rsp_*` master port (and a slave port) | master #0; natural candidate for the HIGH priority class |
| **Fabric stand-in** | p40 `sf_data_fabric`, `sf_scratchpad` | the stand-in scratchpad is a single bank behind the fabric (window `0x3000–0x3FFF`) | the new subsystem replaces it (`04`) |
| **Reusable test infrastructure** | `sram_defs.svh`, `tb_common.svh` (PRNG), `scripts/run_regress.py` pattern, `SRAM_RESULT` line | | adopted (`SRAMC_RESULT`, same PRNG, provenance-carrying JSON reports) |
| **House RTL rules** | `RTL_CODING_RULES.md` cited by the fabric docs | flat ports, no interfaces/structs/package imports, no `int'()` casts, sized literals in parameter overrides (Yosys 0.33), storage not reset | followed |

## 3. Gaps this package fills

1. Variable- and data-dependent bank latency, busy banks, per-bank completion tracking — completions in any order across banks.
2. Multiple outstanding transactions per master with a **proven** per-master ordering rule.
3. Byte addressing with explicit `RANGE / ALIGN / MASK / SRC / ID / POISON / CANCEL / BANK` status and no side effect on error.
4. A cancellation (`flush`) semantic distinct from hard reset.
5. Two-class priority with a starvation bound; unbounded proofs of the arbiter and FIFO and of the whole controller at 2×2 / `MAX_OUT = 1`.
6. Hardware counters for arbitration wait, latency, conflicts, busy cycles, throughput, outstanding.
