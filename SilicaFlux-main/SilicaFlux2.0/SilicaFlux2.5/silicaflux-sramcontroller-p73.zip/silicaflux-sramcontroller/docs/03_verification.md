# 03 — Verification

Order followed (as the brief asks): **one master / one bank first** (`s1_1x1`: lint, simulation, formal `sys_2x2_o1` is the smallest closed system), **then several banks** (`s2_*`),
**then four masters with per-bank round robin** (`s3_*`), then concurrency (`MAX_OUT` 2, 4), priority classes, wider data, variable latency.
All numbers are generated: `reports/SUMMARY.md` (and the README table) come from the JSON reports of the final run; nothing in this file is a hand-typed result.

## 1. Test plan → what exercises it

| Brief §11 test | Where (`tb_sramc_sub` / `tb_sramc_var`, one phase each) | Notes |
|---|---|---|
| Single master | `s1_*`, `v_1x1`; phases 0–2 with only master 0 active | 1 master × 1 bank is the primary configuration |
| Four masters | `s3_4x4*`; phases 3–15 | 4×4 at MAX_OUT 1/2/4; also 3, 8 masters |
| All masters → one bank | phase 4 (`all_masters_one_bank`), `s3_4x1` | saturating; fairness check: shares equal within `2·MAX_OUT+2` (priority runs: per-class equality + LOW floor) |
| Independent bank accesses | phase 5 (`independent_banks`) | requires cycles with ≥ 2 simultaneous bank accesses; per-master completion = solo rate |
| Random stalls | phase 6 (`random_stalls`): slow issue, 30–60 % `rsp_ready`, gaps; `tb_sramc_var`: random bank latency 1–14 and random bank-busy | |
| Simultaneous reads/writes | phase 7: even masters write, odd masters read, same hot words | plus phase 1 (RAW / WAR / WAW / RAR back-to-back, per-lane strobes) |
| Response backpressure | phase 8: master 0 withholds `rsp_ready` 600 cycles; others must complete > 100 each (isolation); `rsp_stall_cycles` coverage | response stability checked every cycle |
| Reset | phases 13/14: random hard resets (also while responses are held back), masters keep presenting through reset | after reset: no stale response, memory model unchanged |
| Invalid requests | phase 9: range / align / mask / source / poison / ID-reuse mixed with valid traffic; phase 11 source-enable toggling | each status code must be *seen* (coverage guard) |
| Request-ID reuse rules | phase 10: random IDs, constant ID, reuse attempts at 1–4 outstanding; `ID_CHECK = 0` config; same-cycle exemption | the model implements the rule independently |
| (extra) flush / cancellation | phase 12, cycle-exact with real banks, either-or with random banks | |

## 2. Simulation architecture

* **One deterministic clocked engine** per testbench (a single `always @(posedge clk)`), PRNG = xorshift64* from the SRAM library's `tb_common.svh`.
  Same seed ⇒ **identical stimulus and identical DUT behaviour in Verilator and Icarus** (`xsim` compares the final metric line and the check count of every run; the first attempt exposed a real
  testbench flaw — Verilator hoists side-effecting function calls out of `?:`/`&&` — now fixed by keeping every random draw in its own statement).
* **Reference model** (written from the spec, independent of the RTL): at every acceptance edge it computes the expected response — status by the §6 rules (own implementation, incl. the ID-reuse
  rule with its same-cycle exemption), read data from a byte-granular memory model (updated at the acceptance edge, which is when the controller touches the array), write effects.
  Unwritten bytes are *unknown*, never assumed zero. Every response transfer is compared (ID, type, source, status, `rsp_err`, data under the known-byte mask, zero data for writes/errors/cancel, exact
  latency for isolated accesses, flush cancel rule) with the **oldest expected response of that master**; a response with nothing outstanding is an error (no duplicate / phantom completion);
  at the end `accepted = completed + cancelled-by-reset` (nothing lost).
* **Monitors:** at most one bank access per bank per cycle (from the accepted requests, not from the DUT's own signals); response stability under back-pressure; `idle ⇔ nothing outstanding` every cycle;
  `req_ready = rsp_valid = 0` in reset; no acceptance during flush; outstanding ≤ `MAX_OUT`; sticky flags 0.
* **Bank models:** `sf_sramc_bank` over the real `sf_sram_core` with per-bank latency 1–4, and `sf_sramc_bankmodel` (random latency, random busy, **garbage on the data bus for writes and failed accesses**, optional
  failing row) — the latter proves the controller against the *contract* instead of one memory, and makes zero-masking of write data and `SFC_ST_BANK` testable.
* **Coverage guard** (`run_regress.py`): every run must have *seen* each status it can produce, bank conflicts, order stalls (when the bank-lock exists), back-pressure and — with bank latency ≥ 2 — cancellations;
  a passing run that never exercised a scenario is reported as a failure ("vacuous test"). (It caught a false assumption of mine: with 1-cycle banks `CANCEL` is unreachable, see `01` §8.)

## 3. Embedded assertions (`SFC_ASSERT`, same text in simulation and formal)

`SFC_CHK` = a property of the design, `SFC_ASM` = an obligation on the environment (simulation: `$error`; formal: `assert` / `assume`).

| Property | Name in the source |
|---|---|
| no bank double-booking; grant ⊆ eligible; work conserving | `grant without eligibility`, `bank granted to two masters`, `bank idle although a master is eligible` |
| no issue to a busy bank / full tracker | `bank access issued while bank not ready / tracker full` |
| FIFO / tracker safety (no overflow, no underflow, counts ≤ depth) | `response FIFO overflow/underflow`, `tracker overflow/underflow`, `… count above …` |
| response space reservation (no drop possible) | `response space reservation violated (FIFO + in-bank > outstanding)` |
| in-order rule; error vs bank push exclusion; one bank pushes per master per cycle | `in-order rule violated`, `bank response and error response pushed…`, `two banks completed for the same master…` |
| **correct response routing / no duplicate completion** | `response ID differs from the oldest outstanding request ID`, `response type differs …`, `response present with no outstanding transaction` |
| response stability (R4) | `response withdrawn…`, `response payload changed while held` |
| no accept during flush / reset | `request accepted during flush`, `… during reset` |
| fairness of the composed system | `fairness: eligible master waited more than the arbiter bound` |
| environment: request stability (R2), bank contract (completion only for an outstanding access) | `SFC_ENV_ASSUMPTION …` |

## 4. Formal (`formal/`, `scripts/run_formal.py`)

Engine: Yosys 0.33 `read_verilog -formal` → AIGER (zero-init) → ABC `bmc3` (bounded) and `pdr` (**unbounded** proof). SymbiYosys is not available in this environment; the flow is the same one the repository's earlier
packages use. A PDR result of `UNDECIDED` means the time budget was hit: the claim is then only the BMC depth.

| Harness | What it proves, for ALL input sequences from reset |
|---|---|
| `fv_sramc_arb` | exclusive grant, work conserving, **bounded waiting ≤ bound (no starvation)** for round robin and for both priority classes — unbounded |
| `fv_sramc_fifo` | count/empty/full = independent reference queue; FIFO order, no loss/duplication/corruption; overflow/underflow exactly as defined; head stable without pop — unbounded, **no environment assumption** |
| `fv_sramc` | the whole controller with **abstract banks** (any in-order bank: free `ready`, free completion timing, free data/error) and **free masters**: every embedded `SFC_CHK`; plus an **independent marked-transaction scoreboard**: the (K_N+1)-th request of an arbitrary master `K_M` is followed through the design using only interface events and must be answered with the right ID, type, source, status, data — exactly once, in order, to the right master; every accepted error-free request issues exactly one bank access with the right row/direction/data/strobes and an erroneous one issues none; a response is transferred only while a request is outstanding; `idle ⇔` nothing outstanding |

Environment assumptions (the only ones): E1 master request stability (turned off in the `nostab` run), E2 the bank contract, E3 the marked-transaction selection is constant; for `LIVE` runs additionally a bounded environment.
**Non-vacuity:** 15 reachability probes (`probe01…15`) show every scenario the properties talk about is reachable (every bank used in one cycle, same-bank conflict with a loser, held response, every status code delivered
for the marked transaction, 2 outstanding, read/write completing OK, a CANCEL, a BANK error); 36 formal **mutants** (`mut_M*`; the sim-only bug M31, "accept while `rst_n = 0`", is outside the harness, which models reset only in cycle 0) must yield a counter-example.
`UNIFORM_LAT=1` is proven with *fixed-latency* banks; the negative control `neg_uniform_free_banks` shows it fails (as it must) on free-latency banks. In simulation the regression checks that `sf_sram_subsystem` enabled the mode exactly when all banks have equal latency (`uniform_lat` guard; it caught a real bug in my first auto-detection, which ignored equal latencies greater than 1).

**What is and is not proven** (generated detail: `reports/formal.md`):

* **Unbounded (PDR), 23 proofs:** FIFO (4 sizes); arbiter (round robin N = 2…5; five priority-class configurations); the **whole controller** at 2 masters × 2 banks, `MAX_OUT = 1` (also with tracker depth 2, with priority classes, with 16-bit data, and with masters that withdraw requests);
  at `MAX_OUT = 2`: **1 master × 2 banks** (the in-order rule across banks; also tracker depth 1) and **2 masters × 1 bank** (arbitration with outstanding limits); and `UNIFORM_LAT = 1` on fixed-latency banks (latency 1 and 2, 1 master × 2 banks).
* **Bounded only (BMC):** 2 masters × 2 banks at `MAX_OUT = 2` (depth 14; with `UNIFORM_LAT` depth 16) — the model was too large for PDR within the time budget — and the *bounded-completion* runs (depth 24).
* Sizes are small by necessity (state explosion: 8/16-bit data, 1-bit IDs, ≤ 2 masters or ≤ 2 banks for `MAX_OUT = 2`); larger configurations rest on simulation, mutation and gate-level lock-step, not on proof.

## 5. Mutation sanity (`scripts/run_mutants.py`, `reports/mutants.md`)

41 injected RTL bugs — in-order rule removed, error overtaking, misrouted/ID-corrupted/type-inverted responses, garbage write data, dropped responses, credit removed, stuck round robin, all-granted arbiter, HIGH never yields,
every error check removed or off by one, strobes/data/row corrupted, flush/cancel arithmetic, bank-ready/tracker-full ignored, FIFO push-when-full-and-popped dropped, reset not clearing state, bank-adapter write alignment,
perf-counter errors, `UNIFORM_LAT` forced on mixed-latency banks. **Every mutant must be killed** by a testbench failure or an embedded assertion; a survivor is reported as `SURVIVED`. Most are killed within a few hundred cycles; the formal
runner kills the subset whose property it covers (`mut_M*` rows).

## 6. Gate level (`scripts/run_gls.py`)

The controller is synthesised to a generic gate netlist (Yosys `synth -flatten; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX`) for four configurations and co-simulated **in lock-step** with the RTL (`tb_sramc_gls`): identical random masters,
response-ready, flush, source enables, hard resets, counter selects and a shared random-latency bank model; **every output compared every cycle** for 60 000 cycles × 2 seeds. Corrupting a single gate in the netlist is detected immediately
(performed once by hand while developing the check).

## 7. Lint, negative tests

Verilator 5.020 `-Wall` with **zero warnings** on every top-level and parameter variant (with and without `SFC_ASSERT`), Icarus 12 `-Wall` elaboration, and 22 illegal parameterisations that must be rejected by
Verilator, Icarus and Yosys.

## 8. Honest limits

* Simulation (Verilator 5.020, Icarus 12.0) and Yosys 0.33 / ABC only. No vendor FPGA tool, no commercial simulator, no silicon.
* Formal proofs are for **small instances**; the unbounded results are listed in the report; the rest are bounded.
* The reference model shares the author's reading of the specification (it is independent *code*, not an independent *reading*); the formal marked-transaction scoreboard is a second implementation of the same reading.
* Not covered: bank error *injection other than a fixed failing row*, multi-clock operation, X-propagation behaviour of the unreset storage in gate level (payloads are compared only while valid), power.
