# 05 — Status, limits, next actions

## 1. Definition of done

> *Every accepted supported memory request receives the correct response, regardless of contention or backpressure.*

| Claim | Evidence |
|---|---|
| every accepted request gets **exactly one** response, to the right master, with the right ID / type / source | formal marked-transaction scoreboard on abstract banks (unbounded at 2×2 `MAX_OUT = 1`, bounded for `MAX_OUT = 2`), simulation scoreboard on every response of ~10⁸ checks, embedded order-queue assertion, mutants M01–M05/M33/M34 |
| the response carries the **correct data / status** | read data vs a byte-granular memory model; every status code produced and checked (coverage guard); formal status + data association |
| under **contention** | per-bank round robin: bounded waiting proven unbounded for the arbiter, asserted on the composed system; phase 4 shares equal within 1; no double-booking (embedded + testbench + formal) |
| under **back-pressure** | a response slot is reserved at acceptance (`FIFO depth = MAX_OUT`): proven `FIFO + in-bank ≤ outstanding ≤ depth`; the FIFO is proven by itself; a stalled master blocks only itself (phase 8) |
| under **reset / flush / invalid requests / variable latency** | phases 9–14, random-latency + random-busy banks, cycle-exact flush rule |
| **supported** | the supported set is defined: error-free, aligned, in range, supported strobes, valid source, non-reused ID, not poisoned. Everything else is answered with an explicit status and has no side effect |

## 2. Acceptance checklist of the brief

| Brief item | Status |
|---|---|
| §1 repository audit | done — `00` |
| §2 transaction structure, acceptance/completion documented | done — `01` (SFB2 + ID + status) |
| §3 parameterised `NUM_MASTERS`, four named masters | done — `sf_sram_controller`, `sf_sramc_soc4`; all four submit requests (tests with 4 masters active) |
| §4 per-bank RR, independent banks in parallel, single-port exclusivity, priority classes defined, no starvation | done — `02`; proven |
| §5 tracking: source, ID, type, destination, error; out-of-order completions associated correctly | done — per-bank tracker, random-latency bank tests |
| §6 actual read latency; back-to-back R/W, RAW, WAR, buffering, back-pressure, never drop | done — phases 1, 8; credit-based FIFO |
| §7 ordering defined; start with one outstanding | done — `02` §3; `MAX_OUT = 1` default, 2/4 verified, bounded formal at 2 |
| §8 errors: range, alignment, mask, response overflow, invalid source, reset cancellation | done — `01` §6, §8 (`CANCEL` = explicit flush cancellation; hard reset = silent per SFB2 R11) |
| §9 performance counters (wait, latency, conflicts, busy, completed, outstanding, R/W throughput) | done — `sf_sramc_perf`, exactly verified, `reports/perf.md` |
| §10 assertions + formal (stability, no loss, no duplicate, no double-booking, routing, FIFO safety, fairness) | done — `03` §3–4 |
| §11 verification list | done — `03` §1 |
| §12 deliverables: `sf_sram_controller.sv`, arbitration, buffers, tracking, counters, assertions, testbench, synthesis | done — README table |

## 3. Known limits and honest caveats

1. **Throughput of one master across banks with *non-uniform* latency.** The in-order rule (bank-lock) lets a master have several accesses outstanding only inside one bank at a time. With equal-latency banks (`UNIFORM_LAT`, automatic in `sf_sram_subsystem`) or
   `INTERLEAVE = HIGH` this is no limit (streaming throughput 2–4× higher: `reports/perf.md`); with a word-interleaved array of banks that have *different* latencies a streaming master runs close to one access in flight. The remedy — ID-tagged out-of-order completion with a per-master
   reorder buffer — is **not implemented** (the ID is plumbed through).
2. **Formal size.** Proofs are for small instances (8/16-bit data, ID width 1). Unbounded: the arbiter, the FIFO, the whole controller at 2×2 with `MAX_OUT = 1`, and at `MAX_OUT = 2` for 1 master × 2 banks and 2 masters × 1 bank. **2×2 at `MAX_OUT = 2` is only bounded (BMC depth 14)**, as are the bounded-completion runs.
   Larger configurations (4 masters, 4 banks, 32-bit data, `MAX_OUT` 4) are covered by simulation, mutation and gate-level lock-step, not by proof.
3. **Counters cost area.** 32-bit counters are ~5× the controller's own logic (4×4, 1 outstanding: 18 697 vs 3 688 generic cells, `reports/synth.md`); use `PERF_EN = 0` / `CNT_W = 16`. Counters wrap.
4. **No timing, frequency, area-in-µm² or power claim.** No STA tool, liberty file or PDK exists here. Acceptance equals bank issue, so there is a combinational path *master request → decode → arbiter → bank request*
   (and `m_rsp_ready → m_req_ready`); at high clock rates register it (`sfb_reg_slice` on the master port: one extra cycle, and the master then sees one more transaction in flight than the controller — account for it in `MAX_OUT`).
5. **Real MemoryFlow `sf_sram_bank` not instantiated.** It matches the bank contract on paper (`04` §4); only the contract (random-latency/busy model) and `sf_sram_core` banks were simulated.
6. **Hard reset in the middle of a run is exercised in simulation only**; the formal harnesses start from reset.
7. **`CANCEL` needs bank latency ≥ 2.** With 1-cycle banks a flush can never find an access still inside a bank (acceptance is blocked in the sampling cycle).
8. **Limits of the parameter space:** `NUM_MASTERS ≤ 16`, `NUM_BANKS` a power of two ≤ 16, `DATA_WIDTH` 8…128 (power-of-two bytes), `ADDR_WIDTH` 8…32, capacity < 2 GiB, `MAX_OUT ≤ 16`, `BANK_OUT ≤ 32`; `INTERLEAVE = HIGH` needs a power-of-two `BANK_DEPTH`.
9. No ECC, no coherence, no MBIST path (use the SRAM library's `sram_mbist_*` beside this controller), single clock domain.
10. The bank-side `bk_req_ready` must not depend combinationally on `bk_req_valid` (contract; not checkable by a simulation assertion).

## 4. Prioritised next actions

1. **Out-of-order completion within a master** (ID-matched response channel or reorder buffer) to lift limit 1 for mixed-latency banks; extend `fv_sramc` with the tag-ordering property; keep `MAX_OUT = 1` as the proven base.
2. **Instantiate MemoryFlow `sf_sram_bank` (ECC) behind the contract** and add it to the regression (RMW busy cycles, uncorrectable → `SFC_ST_BANK`).
3. **Register slices** at the master/bank boundaries (parameter `REG_REQ`, `REG_BANK`) once a target frequency and a timing tool exist; re-verify with the same harnesses.
4. **Prove 2×2 at `MAX_OUT = 2` unbounded** (stronger abstraction of the data path, or an inductive strengthening of the FIFO/tracker occupancy invariants), and 3+ masters.
5. **Wire into the p40 floorplan stand-in** (`sf_scratchpad` → `sf_sramc_soc4`) and run its system testbench.
6. A CSR wrapper for the counters (`perf_sel/val`) and `flush`/`src_en`.
