# 01 — Interface and semantics (normative)

`sf_sram_controller` accepts transactions from `NUM_MASTERS` masters and schedules them onto `NUM_BANKS` single-port banks.
Every statement in this file is checked by the testbench, an embedded assertion or a formal property; section 11 maps each rule to its check.

"Cycle *t*" is the clock cycle in which a signal has a value; a transfer happens at the rising edge that **ends** the cycle.
The interface is the SilicaFlux **SFB2** request/response protocol (`silicaflux-datafabric/docs/datafabric/PROTOCOL.md`, rules R1–R12) with the
two additive extensions that document already plans in its §8: a request **ID** echoed in the response, and an explicit **status**.
A plain SFB2 master (tie `req_id = 0`, `req_src = port`, `req_err = 0`, `rsp_ready` as needed) connects unchanged.

## 1. Master-side ports (flat vectors, master `m` uses slice `m`)

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `m_req_valid` / `m_req_ready` | in / out | 1 | request handshake. **Accepted** at the edge where both are 1 |
| `m_req_we` | in | 1 | 1 write, 0 read |
| `m_req_addr` | in | `ADDR_WIDTH` (32) | **byte** address, SRAM-local offset (the fabric decoder strips the window base) |
| `m_req_wdata` | in | `DATA_WIDTH` | write data (don't care for reads) |
| `m_req_wstrb` | in | `DATA_WIDTH/8` | byte strobes, lane `l` = bits `[8l+7:8l]`, little-endian (don't care for reads) |
| `m_req_id` | in | `ID_WIDTH` (4) | request ID — opaque, echoed in the response (§5) |
| `m_req_src` | in | `clog2(NUM_MASTERS)` | **source ID**; must equal the port index (§5) |
| `m_req_err` | in | 1 | request **error status**: the upstream flagged this request as poisoned |
| `m_rsp_valid` / `m_rsp_ready` | out / in | 1 | response handshake. **Completed** at the edge where both are 1 |
| `m_rsp_rdata` | out | `DATA_WIDTH` | read data; **0** for writes, errors and cancelled requests |
| `m_rsp_id` | out | `ID_WIDTH` | the request's ID |
| `m_rsp_src` | out | `clog2(NUM_MASTERS)` | the request's source = the master the response is delivered to |
| `m_rsp_we` | out | 1 | the request's type |
| `m_rsp_err` | out | 1 | `m_rsp_status != OK` (the 1-bit SFB2 view) |
| `m_rsp_status` | out | 4 | `SFC_ST_*` (§6) |

Control / status: `src_en[m]` (source enable), `flush` (soft reset, §8), `idle` (nothing outstanding anywhere), `sts_rsp_overflow`
and `sts_bank_proto` (sticky, proven unreachable, §9), `perf_clr`, `perf_sel`, `perf_val` (counters, `02_arbitration_ordering_performance.md`).

## 2. Bank-side ports — the BANK CONTRACT (flat vectors, bank `b` uses slice `b`)

| Port | Dir | Meaning |
|---|---|---|
| `bk_req_valid[b]` / `bk_req_ready[b]` | out / in | one access per cycle. The controller asserts `valid` **only in cycles where `ready` is 1**, so a bank-side request is never stalled. `ready` must not depend combinationally on `valid` |
| `bk_req_we`, `bk_req_addr` (ROW inside the bank), `bk_req_wdata`, `bk_req_wstrb` | out | the access |
| `bk_rsp_valid[b]`, `bk_rsp_rdata`, `bk_rsp_err` | in | **exactly one completion per accepted access, in acceptance order per bank, at most one per cycle, any latency ≥ 1, no back-pressure** (the controller reserved the space) |

Latency may be **variable and data-dependent**, and a bank may be busy (`ready = 0`) — e.g. MemoryFlow's `sf_sram_bank` drops `req_ready` for the
SECDED read-modify-write cycle. The completion's data is only meaningful for a good read; for a write or a failed access it is *don't care*
(the controller masks it). `bk_rsp_err = 1` is reported as `SFC_ST_BANK`.
`sf_sramc_bank` adapts the verified `sf_sram_core` (Project 71) to this contract; it delays the core's 1-cycle write acknowledge by `LAT-1` cycles so
every access of a bank completes exactly `LAT` cycles after issue (otherwise a write following a read would complete first when `LAT > 1`).

## 3. Transaction acceptance and completion — precisely

**Acceptance (SFB2 R1).** A request is accepted at the edge ending cycle *t* iff `m_req_valid[m] && m_req_ready[m]` in cycle *t*.
At that edge the controller commits to answering it **exactly once**, and:

* for an error-free request the **bank access is issued in the same cycle** (`bk_req_valid` for the target bank is 1 in cycle *t*): acceptance **is**
  issue. The array is read / written at that edge. A request accepted at an edge therefore observes every write accepted at an earlier edge to the same bank
  (bank ordering), and is observed by every later one;
* for a request that fails a check (§6) **no bank is accessed**; it is accepted when the master can take a response and everything older is already in its
  response FIFO, so the error answer cannot overtake an older answer.

**Completion (SFB2 R1).** A transaction completes at the edge where `m_rsp_valid[m] && m_rsp_ready[m]`. That edge also returns the outstanding credit, and a
new request may be accepted in the same cycle (`m_req_ready` depends on `m_rsp_ready`, permitted by SFB2 R4).

**Rules.**

| # | Rule |
|---|---|
| T1 | **R2 (master obligation):** once `m_req_valid` is 1 it stays 1, with `we/addr/id/src/err` (and `wdata/wstrb` for writes) unchanged, until accepted. The controller *tolerates* a violation (nothing is sampled before acceptance) — proven in `sys_2x2_o1_nostab`; only the fairness bound assumes persistence |
| T2 | **R5:** exactly one response per accepted request, in the order the master's requests were accepted (§7), never in the acceptance cycle |
| T3 | **R4:** a response that is not taken stays valid with unchanged payload. It is **never dropped and never overwritten**: its slot was reserved at acceptance (§9) |
| T4 | **R7:** a write is answered only after its bank reported completion; with `sf_sram_core` the array was written at the acceptance edge |
| T5 | **R8:** `rsp_status != OK` ⇒ `rsp_rdata = 0`; an erroneous request has **no side effect** (no bank access) |
| T6 | at most `MAX_OUT` (default **1**) transactions per master are accepted and not yet completed |
| T7 | `req_ready` is 0 and `rsp_valid` is 0 during reset (R11) |

## 4. Timing (uncontended; `L` = bank latency, 1 for a default `sf_sram_core`)

```
cycle            t        t+1            t+2           t+3
m_req_valid      1(A)     .              .             .
m_req_ready      1        .              .             .          A accepted at the end of t, bank access issued in t
bk_req_valid     1        .              .             .
bk_rsp_valid     .        1 (L=1)        .             .          bank completion
m_rsp_valid      .        .              1             .          response register (one cycle after the completion)
m_rsp_ready      .        .              1             .          completion at the end of t+2
```

| Case | Response valid |
|---|---|
| read or write, error-free | cycle *t* + `L` + 1 |
| rejected request (§6) | cycle *t* + 1 (no older answer in flight) |
| response back-pressured | stays valid until `m_rsp_ready`; the credit is returned only then |

`tb_sramc_sub` phase 1 checks these latencies exactly (accept → response = `L+1` / `1`) for isolated accesses of every bank latency.
Back-to-back reads, back-to-back writes, read-after-write (accepted in consecutive cycles, same word → the read returns the new data),
write-after-read (the read returns the old data) and write-after-write are exercised in phase 1 and, with several masters, in phases 3/7 (see `03_verification.md`).

## 5. Identity: source ID and transaction ID

* **Source ID** = the master port. `m_req_src` must equal the port index; with `SRC_CHECK = 1` a mismatch — or `src_en[m] = 0` — is answered `SFC_ST_SRC`. The response
  destination is the port the request came in on (`m_rsp_src` echoes it); it is held in the bank tracker next to the ID and type, so it cannot be mis-routed even when
  completions of different banks arrive in any order.
* **Transaction (request) ID** is opaque and echoed. **Reuse rule** (`ID_CHECK = 1`, default): a request whose ID equals the ID of a transaction of the *same master*
  that is accepted and **not yet completed** is answered `SFC_ST_ID` (no side effect). The entry whose response is transferred *in the same cycle* no longer counts, so a master
  that always uses ID 0 with `MAX_OUT = 1` (every SFB2 master) works. IDs of different masters are independent. `ID_CHECK = 0` disables the rule (the master then
  identifies responses by order). Because responses are in order per master, ID reuse never endangers correctness; the rule exists to catch master bugs.

## 6. Errors — explicit, never silent

`rsp_status` (`sf_sramc_defs.svh`). A request with several faults is reported with the first of this list.

| Code | Name | Condition | Side effect |
|---|---|---|---|
| 4 | `SRC` | `src_en = 0`, or `m_req_src != port` (`SRC_CHECK`) | none |
| 6 | `POISON` | `m_req_err = 1` | none |
| 5 | `ID` | ID reuse (§5) | none |
| 1 | `RANGE` | `addr >= NUM_BANKS * BANK_DEPTH * DATA_WIDTH/8` | none |
| 2 | `ALIGN` | `addr % (DATA_WIDTH/8) != 0` | none |
| 3 | `MASK` | write with `wstrb = 0`; with `MASK_MODE = ALIGNED` also a write whose strobes are not one naturally aligned run of 1, 2, 4 … bytes | none |
| 7 | `CANCEL` | cancelled by `flush` (§8) | read data discarded; a write already issued **was performed** |
| 8 | `BANK` | the bank reported an error for this access | none (data 0) |
| 0 | `OK` | | |

*Response overflow* (a response with no free slot) is **unreachable by construction** (§9) and proven so; it is detected anyway: the FIFO drops the push,
`sts_rsp_overflow` sets and `SFC_CHK` fires in simulation. `sts_bank_proto` flags a bank completion with nothing outstanding or a tracker overflow.
*Reset cancellation* is §8.

## 7. Ordering (summary; full text in `02_arbitration_ordering_performance.md`)

Per master: **in order** (responses in acceptance order). Per bank: in order. Globally: **not ordered** — masters on different banks progress independently and
completions across masters/banks occur in any order; each completion is matched to its request by the per-bank tracking queue, never by timing.

## 8. Reset and flush

* **Hard reset** (`rst_n`, async assert, synchronous release — the SilicaFlux convention; storage is never reset). Cancels every transaction in flight **without a response** (SFB2 R11): all
  FIFOs, trackers, credits and counters clear. A write accepted at an earlier edge **was performed** (acceptance = issue; the array survives reset), so memory contents are
  never half-updated. `req_ready` and `rsp_valid` are 0 while `rst_n = 0`. A master may keep presenting a request through reset; it is accepted after release.
* **Flush** (`flush`, level, sampled each cycle) — an *explicit* cancellation. While `flush = 1` no request is accepted. Every access that is still inside a bank when `flush` is
  sampled in cycle *f* — i.e. whose bank completion comes **after** cycle *f* — is answered `SFC_ST_CANCEL` with `rdata = 0` instead of its normal response (its bank completion is
  consumed and its data discarded); responses already in a master's FIFO are delivered unchanged. Software asserts `flush`, keeps accepting responses, waits for `idle`,
  then deasserts. With a 1-cycle bank nothing can be cancelled (acceptance is blocked in the same cycle the flush is sampled): `CANCEL` needs `L ≥ 2`.
  Exact rule, checked cycle-exactly by `tb_sramc_sub`: cancelled ⇔ (accept cycle + `L`) > *f*.

## 9. Why a response can never be dropped

A master has `MAX_OUT` outstanding credits and a response FIFO of exactly `MAX_OUT` entries. A credit is taken at acceptance and returned when the response is **transferred**.
Hence `FIFO occupancy + accesses still inside a bank ≤ outstanding ≤ MAX_OUT = FIFO depth` at all times: the bank completion that pushes into the FIFO always finds space,
whatever the back-pressure. A stalled master therefore only ever blocks **itself** (it runs out of credits); other masters and the banks keep running
(`tb_sramc_sub` phase 8 checks that masters 1…N−1 each complete > 100 transactions while master 0 withholds `rsp_ready` for 600 cycles).
This invariant is an embedded assertion (`response space reservation violated`) and is proven for all inputs.

## 10. Combinational paths

`m_req_ready` ← `m_req_valid`, address/ID/strobe decode, `m_rsp_ready` (credit), `src_en`, `flush`, `bk_req_ready`, tracker state, arbiter state.
`bk_req_*` ← the masters' request fields (grant mux). `m_rsp_*` ← registers only. **No path from any `bk_rsp_*` or `m_rsp_ready` to a bank request or to `m_rsp_*`.**
Verilator `-Wall` reports no combinational loop (`UNOPTFLAT` clean) and Yosys `check -assert` passes for every synthesised configuration.

## 11. Rule → check map

| Rule | Enforced by |
|---|---|
| T1 request stability | `SFC_ASM` driver check in every simulation; `sys_2x2_o1_nostab` formal (tolerance) |
| T2 exactly one response, in order, correct routing | scoreboard (every response vs the oldest expected one of that master: ID, type, source, status, data); embedded order-queue assertion; formal marked-transaction scoreboard; mutants M01–M05, M33, M34 |
| T3 response stability | scoreboard + `SFC_CHK` stability assertion; formal FIFO F4; mutant M07 |
| T4/T5 write completion, no side effect on error | scoreboard memory model (a later read must see exactly the performed writes); formal `issue_chk` (an error issues no bank access) |
| T6 outstanding limit | `MAX_OUT` assertion; mutant M08 |
| T7 reset | `tb` reset phases + `req_ready === 0` check; mutants M30, M31, M40 |
| §6 errors | phase 9; mutants M12–M19, M37; formal marked status |
| §8 flush | phase 12 (cycle-exact in `tb_sramc_sub`); mutants M20–M22 |
| §9 no drop | FIFO proof F1–F4 (unbounded), embedded space-reservation assertion, mutants M07, M08, M29 |
