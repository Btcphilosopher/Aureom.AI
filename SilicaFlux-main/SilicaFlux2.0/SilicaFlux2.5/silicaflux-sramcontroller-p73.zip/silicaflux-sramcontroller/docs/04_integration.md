# 04 — Integration

## 1. Pick a module

| Module | Use |
|---|---|
| `sf_sramc_soc4` | the four SilicaFlux masters on 4 banks, named ports (`cc_*` ControlCore, `dma_*`, `vec_*` Vector Engine, `tc_*` TensorCore); 32-bit, 4 × 1024 words = 16 KiB, word-interleaved, `MAX_OUT = 4`, source IDs tied to the port |
| `sf_sram_subsystem` | generic `NUM_MASTERS × NUM_BANKS` controller + `sf_sram_core` banks with per-bank latency (`BANK_LATS`); `UNIFORM_LAT` automatic |
| `sf_sram_controller` | the scheduler alone: bring your own banks (anything that honours the bank contract of `01` §2) |

Master index map (`sf_sramc_defs.svh`): `0` ControlCore, `1` DMA, `2` Vector Engine, `3` TensorCore. With `PRIO_EN = 1` ControlCore is the HIGH class.

Recommended parameters: `MAX_OUT = 1` first (proven unbounded at 2×2); `MAX_OUT = 2…4` for streaming masters (pipeline depth ≈ bank latency + 2); equal-latency banks so that `UNIFORM_LAT` removes the bank-lock;
`INTERLEAVE = HIGH` (contiguous region per bank) when a master streams and the banks have *different* latencies; `PERF_EN = 0` or `CNT_W = 16` when area matters (`reports/synth.md`).

## 2. Connecting the existing masters

| Stand-in master port | to the controller |
|---|---|
| `req_valid / req_ready / req_we` | `m_req_valid / m_req_ready / m_req_we` |
| `req_addr[15:0]` (window offset) | `m_req_addr = {16'b0, req_addr}` — byte address; word-aligned for 32-bit data |
| `req_wdata` | `m_req_wdata`; **`m_req_wstrb = '1`** (the stand-ins write whole words) |
| `rsp_valid / rsp_err / rsp_rdata` | `m_rsp_valid / m_rsp_err / m_rsp_rdata`; **`m_rsp_ready = 1`** (they cannot back-pressure) |
| — | `m_req_id = 0` with `MAX_OUT = 1`, or `ID_CHECK = 0` (or distinct IDs) with `MAX_OUT > 1`; `m_req_src = port index`; `m_req_err = 0` |

Rules the master must follow: hold `req_valid` and the payload until `req_ready` (SFB2 R2); answer-order is request order. A master that cannot take a response for a long time stalls only itself.
A `rsp_err` master sees `rsp_status` for the cause if it wires the 4-bit status.

**Behind a fabric** the SFB2 crossbar presents one request per slave port and strips the window base; connect the crossbar slave port to one controller master port (or several crossbar outputs to several ports).
If the fabric forwards absolute addresses, subtract the window base before `m_req_addr` (the controller addresses `[0, capacity)` and answers anything above `RANGE`).

## 4. Banks

* `sf_sramc_bank` + `sf_sram_core` (default): fixed latency `LAT`, always ready.
* MemoryFlow `sf_sram_bank` (ECC): `bk_req_valid/ready/we/addr/wdata/wstrb` ↔ `req_valid/req_ready/req_we/req_addr/req_wdata/req_wstrb`; `bk_rsp_valid` ↔ `rsp_valid`; `bk_rsp_rdata` ↔ `rsp_rdata`; `bk_rsp_err` ↔ `rsp_uncorr`;
  leave its `req_tag` unused (the controller tracks identity itself). Its `req_ready` drops during the RMW cycle — the controller handles that (tested with the random-busy bank model). It completes reads *and* write acks after a fixed 2 cycles, so
  `UNIFORM_LAT = 1` is valid if all banks are such banks. **Not instantiated or simulated in this package** (see `05`).
* A macro-based or FPGA block-RAM bank: wrap it to the contract (`01` §2); declare `UNIFORM_LAT` only if *every* access of *every* bank completes after the same fixed number of cycles.

## 5. Software / firmware view of the counters

`perf_sel` selects a counter, `perf_val` returns it (combinational read of a register), `perf_clr` clears all. Wire them to a CSR block; index map and derived figures: `02` §4 and `sf_sramc_defs.svh`.
`flush` / `idle` / `src_en[]` / `sts_*` are plain control and status bits (`01` §1, §8).

## 6. Files

`rtl/sramc/files.f` lists the compile order; add `-Irtl/sramc -Ithird_party/silicaflux-sramcore/rtl/sram`. Define `SFC_ASSERT` (simulation) to enable the embedded checkers; never define it for synthesis.
`sf_sram_core` is vendored under `third_party/silicaflux-sramcore/` with its SHA-256 (`SHA256SUMS`, `PROVENANCE.md`).
