# 02 — Arbitration, ordering, response buffering, performance

## 1. Per-bank arbitration

Every bank has its **own** arbiter (`sf_sramc_arb`); banks are independent.
A master `m` is **eligible** for bank `b` in a cycle iff *all* of:

1. `m_req_valid[m]`, the controller is out of reset and `flush = 0`;
2. the request passes every check of `01` §6 (error requests never reach a bank);
3. the request maps to bank `b`;
4. `m` has a free outstanding credit (`outstanding < MAX_OUT`, or its response is being transferred this cycle);
5. the in-order rule allows it (§3);
6. `bk_req_ready[b] = 1` and the bank's tracker has a free entry.

The arbiter picks **exactly one** eligible master per bank per cycle (work-conserving — an idle bank with an eligible master is a bug, asserted) and the grant is
**always consumed** (it is issued to the bank in the same cycle), so the round-robin pointer advances on every grant.
Filtering *before* arbitration is essential: a master that cannot issue (no credit, wrong bank for the in-order rule) never wastes the bank's slot.

* Two masters on **different** free banks are both granted in the same cycle (`tb_sramc_*` phase 5 counts such cycles; `PG_CONFLICT`/`PB_*` counters show it in hardware).
* Two masters on the **same** single-port bank: one wins, the other loses and waits (`bank consumed by 2 masters` assertion in the testbench, `bank granted to two masters`
  embedded assertion, formal property P1, probe 2 shows the situation is reachable).

### Round robin, no starvation

`PRIO_EN = 0` (default): **one class, plain round robin** over the `NUM_MASTERS` request lines. After a grant to `g` the search restarts at `g+1`.
*Theorem (proven with PDR, unbounded, `arb_rr_n2..n5`):* a requester that keeps `req` asserted is granted after at most `N−1` grants to others.
The composed system carries the same bound as an embedded assertion on the real eligibility signals (`fairness: eligible master waited more than the arbiter bound`,
checked in every simulation and in the system formal proofs): a master that stays **eligible** for a bank is granted within `N−1` other grants.
The measured effect (phase 4, four masters saturating one bank, 4 010 accepted requests): per-master counts 1002–1003 — shares equal within one transaction (8 masters × 8 banks: 502–503).

### Priority classes (explicit, optional)

Default: **there are no priority classes** — all masters are equal. `PRIO_EN = 1` defines exactly two:

| Class | Members | Rule |
|---|---|---|
| HIGH | masters set in `HP_MASK` (e.g. ControlCore: `HP_MASK = 16'h0001`) | preferred |
| LOW | all other masters | granted when no HIGH master requests, **or** when HIGH has just taken `HP_LIMIT` consecutive grants while a LOW master was waiting |

Each class has its own round-robin pointer; a streak counter forces one LOW grant after `HP_LIMIT` HIGH grants while a LOW requester waits. So **neither class starves**:

| Requester | Grants to others before it is granted (proven, PDR, `arb_prio_*`) |
|---|---|
| HIGH, with `NH` HIGH masters | ≤ `(NH−1) + 1 + (NH−1)/HP_LIMIT` |
| LOW, with `NL` LOW masters | ≤ `(NL−1) + HP_LIMIT·NL` |

LOW keeps at least `1/(HP_LIMIT+1)` of the grants of a saturated bank (measured, ControlCore HIGH, `HP_LIMIT = 4`: ControlCore 3202 of 4010 accepted, the three LOW masters 269–270 each = 808 in total = 20.1 % = 1/(`HP_LIMIT`+1); the
regression asserts the floor). Strict (unbounded) priority is deliberately **not** offered: it starves.

### Fairness assumptions (stated once)

1. Round-robin bound: the requester must keep its request asserted until it is granted (SFB2 R2). If it withdraws, its wait counter restarts — safety is unaffected.
2. The bound is in **grants of the same bank**. A master can also wait for a credit (its own outstanding responses must be taken) or for the in-order rule; those waits depend on *its own*
   transactions, not on other masters, and are bounded by the bank latency and by how soon the master accepts responses (`PM_WAIT_*`, `PM_ORDER_STALL` counters).
3. Time bounds additionally need a bounded bank (every access completes within `BL` cycles, `bk_req_ready` at least every `BR` cycles) and a bounded master (`rsp_ready` within `RL` cycles).
   Under those, the formal runs `sys_*_live` prove that any accepted request is answered within the stated number of cycles (BMC-bounded, see `03`).

## 2. Response buffering

Per master: a response FIFO of exactly `MAX_OUT` entries (`{rdata, we, id, status}`) with first-word-fall-through output. Per bank: a **tracker** FIFO (`BANK_OUT` entries,
`{master, id, we}`) holding the accesses in flight in acceptance order; a bank completion pops the tracker head and pushes into the owning master's FIFO. The tracker is what associates every completion with its originating
request, so completions may arrive in any order **across** banks. If the tracker is full the bank is not eligible (no issue) — `BANK_OUT` below the bank latency only costs throughput, never correctness (`v_4x4_bout1`).
Credits make overflow impossible (`01` §9); `sf_sramc_fifo` is nevertheless safe by itself (formal F1–F4: it ignores a push into a full FIFO and flags it).

## 3. Ordering policy

| Scope | Policy |
|---|---|
| per master | **responses in request order.** Up to `MAX_OUT` outstanding (default 1) |
| per bank | accesses are performed and completed in acceptance order |
| globally | **not ordered**: completions across masters and banks occur in any order |

How per-master order is guaranteed with several outstanding transactions:

* **Bank-lock (default).** While a master still has an access *inside a bank* it may only issue to **that** bank; completions of different banks could otherwise overtake each other.
  Once all its accesses have left the banks (their responses sit in its FIFO) it may switch bank freely. A rejected request is queued only when nothing of that master is inside a bank.
  The rule is the "block a master from a second slave while one is outstanding" step of SFB2 §8.
* **`UNIFORM_LAT = 1`** (automatic in `sf_sram_subsystem` when every bank has the same latency, as with a default `sf_sram_core` array). If *every* bank completes *every* access exactly the same fixed
  number of cycles after issue, two accesses of one master complete in issue order whichever banks they use, so the bank-lock is dropped and a master can stream across all banks.
  The option is conditional on that stronger bank contract: **forcing it onto banks with different latencies violates the contract** — mutant M41 and the formal negative control
  `neg_uniform_free_banks` show it is caught (counter-example after 4 cycles).
* **Not implemented:** out-of-order, ID-tagged completion within one master. It would need a per-master reorder buffer or an ID-matched response channel; `m_req_id`/`m_rsp_id`
  are already plumbed for it (`docs/05`). Per the brief, concurrency was expanded only as far as ordering and completion could be proven: `MAX_OUT = 1`, then 2 and 4 in simulation, 1 and 2 formally.

Request IDs and ordering: because responses are in order, the ID adds a *check* (`rsp_id == ID of the oldest outstanding request`, an embedded assertion) rather than being needed for matching.

## 4. Performance counters (`sf_sramc_perf`)

Observers only; `CNT_W` bits (default 32, **wrap**, `perf_clr` clears); read through `perf_sel`/`perf_val`; index map in `sf_sramc_defs.svh`.

| Requirement | Counter(s) | Derived figure |
|---|---|---|
| average arbitration wait | `PM_WAIT_SUM`, `PM_ACC` (+ `PM_WAIT_MAX`, `PG_WAIT`) | `WAIT_SUM / ACC` cycles per accepted request |
| access latency | `PM_LAT_SUM` (integral of the outstanding count), `PM_CMP` | `LAT_SUM / CMP` = accept → response transfer (exact once drained: Little's law, no timestamps) |
| bank conflicts | `PG_CONFLICT`, `PB_LOSERS`, `PB_CONF_CYC` | requesters that were eligible but lost the grant |
| busy cycles | `PG_BUSY` (any outstanding), `PB_BUSY` (bank has an access in flight) | `/ PG_CYCLES` |
| completed transactions | `PG_COMPLETED`, `PG_RD_DONE`, `PG_WR_DONE`, `PG_ERR_DONE`, `PM_CMP` | |
| outstanding requests | `PM_OUT_MAX`, `PG_OUT_MAX` (high-water marks) | |
| read/write throughput | `PG_RD_DONE`, `PG_WR_DONE`, `PG_CYCLES` | transactions per cycle (× `DATA_WIDTH/8` for bytes) |
| also | `PG_ORDER_STALL`, `PM_RSP_STALL`, `PG_CANCELLED`, `PB_ACCESS/RD/WR` | |

Every counter (except the two that observe internal arbitration, `PG_CONFLICT`/`PG_ORDER_STALL`, which are sanity-checked) is verified **exactly** against an independent
shadow in the testbench at the end of a 12 000-cycle mixed soak that includes errors, flushes and back-pressure (mutants M38, M39 prove the check can fail).

**Cost, measured:** the counters are not free. For a 4×4, 1-outstanding controller Yosys generic synthesis gives 3 688 cells without counters and 18 697 with 32-bit counters (5×; 12 257 with `CNT_W = 16`);
`PERF_EN = 0` removes them (`reports/synth.md`).

### Measured throughput and latency (`reports/perf.md`, 4 masters × 4 banks, from the hardware counters)

See `reports/perf.md` for the full table (MAX_OUT 1/2/4 × bank latency 1/2/4 × 8 traffic patterns). Representative rows (bank latency 1):

| MAX_OUT | pattern | throughput (txn/cycle) | avg arbitration wait | avg latency |
|---|---|---|---|---|
| 1 | 1 master, 1 bank | 0.50 | 1.0 | 2.0 |
| 1 | 4 masters, one bank | 1.00 (bank saturated) | 3.0 | 2.0 |
| 1 | 4 masters, private banks | 2.00 (= 4 × 0.5) | 1.0 | 2.0 |
| 4 | 4 masters, private banks | ≈3.99 (peak 4) | 0.0 | 2.0 |

Latency 2.0 = accept → response transfer with an uncontended 1-cycle bank (1 bank cycle + 1 response-register cycle).

**What the bank-lock costs, and what `UNIFORM_LAT` buys** (measured, equal-latency banks, MAX_OUT = 4, streaming across word-interleaved banks; `UNIFORM_LAT=0` forces the bank-lock):

| bank latency | pattern | with bank-lock | with `UNIFORM_LAT` (automatic) |
|---|---|---|---|
| 1 | one master, sequential words | 0.499 txn/cycle | **0.998** |
| 2 | one master, sequential words | 0.333 | **0.998** |
| 4 | one master, sequential words | 0.200 | **0.799** (= MAX_OUT / (L+1), the credit limit) |
| 4 | four masters, sequential streams | 0.799 | **3.195** |

With *non-uniform* banks the bank-lock remains (it is the proven rule); see `05` §3 item 1.
