# Formal results

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (); Yosys 0.33 (git sha1 2584903a060); python 3.13.18. Not installed: vivado=NOT INSTALLED, quartus=NOT INSTALLED, openroad=NOT INSTALLED.  RTL sha256 `da5b4eae35469c90…`.

Files under proof (the formal flow reads exactly these; SHA-256 prefixes at report time — `sf_sram_subsystem.sv`/`sf_sramc_bank.sv`/`sf_sramc_soc4.sv` are not part of any harness): `sf_sram_controller.sv` 771db3ed5686; `sf_sramc_arb.sv` 92edfc2fda2b; `sf_sramc_fifo.sv` a66e318d5fcb; `sf_sramc_perf.sv` f225a8176a7a; `sf_sramc_defs.svh` efa606732fdf; `fv_sramc.sv` 116f05796a28; `fv_sramc_arb.sv` c27ac6a70ea7; `fv_sramc_fifo.sv` 613c78fc60cb

Yosys `read_verilog -formal` -> AIGER (zero-init) -> ABC. `bmc3` = bounded model check to the stated depth from reset; `pdr` = **unbounded proof** (property holds for ALL reachable states).
A PDR verdict of *undecided / blank* means no unbounded proof was obtained: the claim is then ONLY the BMC depth. `expect FAIL` rows are non-vacuity checks (reachability probes, mutants, negative controls).

| job | harness | parameters | BMC | unbounded (PDR) | expect | verdict | note |
|---|---|---|---|---|---|---|---|
| fifo_w2_d1 | fv_sramc_fifo | `WIDTH=2 DEPTH=1` | PASS depth 30 | PROVED | PASS | **PROVED** | F1-F4 vs reference queue, no environment assumption |
| fifo_w2_d2 | fv_sramc_fifo | `WIDTH=2 DEPTH=2` | PASS depth 30 | PROVED | PASS | **PROVED** | F1-F4 vs reference queue, no environment assumption |
| fifo_w2_d3 | fv_sramc_fifo | `WIDTH=2 DEPTH=3` | PASS depth 30 | PROVED | PASS | **PROVED** | F1-F4 vs reference queue, no environment assumption |
| fifo_w3_d4 | fv_sramc_fifo | `WIDTH=3 DEPTH=4` | PASS depth 30 | PROVED | PASS | **PROVED** | F1-F4 vs reference queue, no environment assumption |
| arb_rr_n2 | fv_sramc_arb | `N=2` | PASS depth 30 | PROVED | PASS | **PROVED** | exclusive grant, work conserving, bounded waiting N-1 |
| arb_rr_n3 | fv_sramc_arb | `N=3` | PASS depth 30 | PROVED | PASS | **PROVED** | exclusive grant, work conserving, bounded waiting N-1 |
| arb_rr_n4 | fv_sramc_arb | `N=4` | PASS depth 30 | PROVED | PASS | **PROVED** | exclusive grant, work conserving, bounded waiting N-1 |
| arb_rr_n5 | fv_sramc_arb | `N=5` | PASS depth 30 | PROVED | PASS | **PROVED** | exclusive grant, work conserving, bounded waiting N-1 |
| arb_prio_n3_hpm1_l2 | fv_sramc_arb | `N=3 PRIO=1 HPM=16'h1 HPL=2` | PASS depth 30 | PROVED | PASS | **PROVED** | two classes, starvation guard bounds |
| arb_prio_n4_hpm3_l1 | fv_sramc_arb | `N=4 PRIO=1 HPM=16'h3 HPL=1` | PASS depth 30 | PROVED | PASS | **PROVED** | two classes, starvation guard bounds |
| arb_prio_n4_hpm5_l3 | fv_sramc_arb | `N=4 PRIO=1 HPM=16'h5 HPL=3` | PASS depth 30 | PROVED | PASS | **PROVED** | two classes, starvation guard bounds |
| arb_prio_n5_hpm6_l2 | fv_sramc_arb | `N=5 PRIO=1 HPM=16'h6 HPL=2` | PASS depth 30 | PROVED | PASS | **PROVED** | two classes, starvation guard bounds |
| arb_prio_n4_hpm1_l4 | fv_sramc_arb | `N=4 PRIO=1 HPM=16'h1 HPL=4` | PASS depth 30 | PROVED | PASS | **PROVED** | two classes, starvation guard bounds |
| sys_2x2_o1 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | PASS depth 40 | PROVED | PASS | **PROVED** | 2 masters x 2 banks, 1 outstanding: ALL embedded checks + marked-transaction scoreboard |
| sys_2x2_o1_bout2 | fv_sramc | `DW=8 MAXOUT=1 BOUT=2` | PASS depth 20 | PROVED | PASS | **PROVED** | deeper bank tracker |
| sys_2x2_o1_prio | fv_sramc | `DW=8 MAXOUT=1 BOUT=1 PRIO=1 HPM=16'h1 HPL=2` | PASS depth 20 | PROVED | PASS | **PROVED** | priority classes |
| sys_2x2_o1_dw16 | fv_sramc | `DW=16 MAXOUT=1 BOUT=1` | PASS depth 20 | PROVED | PASS | **PROVED** | 16-bit data: alignment errors reachable |
| sys_2x2_o1_nostab | fv_sramc | `DW=8 MAXOUT=1 BOUT=1 -DSFC_NO_STABILITY` | PASS depth 20 | PROVED | PASS | **PROVED** | masters may WITHDRAW requests: safety does not rely on request stability |
| sys_2x2_o1_live | fv_sramc | `DW=8 MAXOUT=1 BOUT=1 LIVE=1 TL=14` | PASS depth 24 | - | PASS | **BOUNDED** | bounded completion (<= 14 cycles after acceptance) under a bounded environment |
| sys_1x2_o2 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2` | PASS depth 24 | PROVED | PASS | **PROVED** | 1 master, 2 banks, 2 outstanding: in-order rule across banks |
| sys_2x1_o2 | fv_sramc | `NM=2 NB=1 DW=8 MAXOUT=2 BOUT=2` | PASS depth 24 | PROVED | PASS | **PROVED** | 2 masters, 1 bank, 2 outstanding: arbitration with outstanding limits |
| sys_2x2_o2 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2` | PASS depth 14 | - | PASS | **BOUNDED** | 2 masters x 2 banks, 2 outstanding (bounded: depth 14) |
| sys_1x2_o2_uni | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=3 UNI=1 UL=2 DUTUNI=1` | PASS depth 24 | PROVED | PASS | **PROVED** | UNIFORM_LAT=1 with FIXED-latency banks (latency 2): no bank-lock, still in order |
| sys_2x2_o2_uni | fv_sramc | `DW=8 MAXOUT=2 BOUT=3 UNI=1 UL=2 DUTUNI=1` | PASS depth 16 | - | PASS | **BOUNDED** | 2x2, UNIFORM_LAT=1, fixed-latency banks (bounded) |
| sys_1x2_o2_uni_l1 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2 UNI=1 UL=1 DUTUNI=1` | PASS depth 24 | PROVED | PASS | **PROVED** | UNIFORM_LAT=1, fixed latency 1 |
| sys_1x2_o2_uni_live | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=3 UNI=1 UL=2 DUTUNI=1 LIVE=1 TL=16` | PASS depth 24 | - | PASS | **BOUNDED** | bounded completion with UNIFORM_LAT |
| neg_uniform_free_banks | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2 UNI=0 DUTUNI=1` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | NEGATIVE CONTROL: UNIFORM_LAT=1 on free-latency banks violates its contract -> counter-example (the option is NOT free) |
| sys_1x2_o2_bout1 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=1` | PASS depth 24 | PROVED | PASS | **PROVED** | tracker depth 1 with 2 outstanding |
| sys_1x2_o2_live | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2 LIVE=1 TL=20` | PASS depth 24 | - | PASS | **BOUNDED** | bounded completion with 2 outstanding |
| probe01 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | reachable: all banks accessed in one cycle |
| probe02 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=2` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | reachable: two masters, same bank, one loses arbitration |
| probe03 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=3` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | reachable: response held 2+ cycles (back-pressure) |
| probe04 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=4` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | reachable: marked read delivered with non-zero data |
| probe05 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=5` | FAIL asserted in frame 5 | - | FAIL | **REACHED/KILLED** | reachable: marked request answered SFC_ST_ID |
| probe06 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=6` | FAIL asserted in frame 5 | - | FAIL | **REACHED/KILLED** | reachable: marked request answered SFC_ST_CANCEL |
| probe07 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=7` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | reachable: marked request answered SFC_ST_BANK |
| probe08 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=8` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | reachable: answered SFC_ST_RANGE |
| probe09 | fv_sramc | `DW=16 MAXOUT=2 BOUT=2 PROBE=9` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | reachable: answered SFC_ST_ALIGN |
| probe10 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=10` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | reachable: answered SFC_ST_MASK |
| probe11 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=11` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | reachable: answered SFC_ST_SRC |
| probe12 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=12` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | reachable: answered SFC_ST_POISON |
| probe13 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=13` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | reachable: a master with 2 outstanding |
| probe14 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=14` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | reachable: marked write completed OK |
| probe15 | fv_sramc | `DW=8 MAXOUT=2 BOUT=2 PROBE=15` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | reachable: marked read completed OK |
| mut_M01 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | in-order (bank-lock) rule removed: a master may overtake itself across banks |
| mut_M02 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | error response may overtake older accesses still inside a bank |
| mut_M03 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | response routed to the next master |
| mut_M04 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | response ID corrupted |
| mut_M05 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | response read/write type inverted |
| mut_M06 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | write responses carry bank garbage instead of 0 |
| mut_M07 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | response dropped when the master is not ready (no back-pressure) |
| mut_M08 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | outstanding limit (credit) removed: response FIFO can overflow |
| mut_M09 | fv_sramc_arb | `N=3` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | round-robin pointer never advances (fixed priority): starvation |
| mut_M10 | fv_sramc_arb | `N=3` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | all eligible masters granted: bank double-booking |
| mut_M11 | fv_sramc_arb | `N=3 PRIO=1 HPM=16'h1 HPL=2` | FAIL asserted in frame 7 | - | FAIL | **REACHED/KILLED** | HIGH class never yields: LOW class starves |
| mut_M12 | fv_sramc | `DW=16 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | alignment check removed |
| mut_M13 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | range check off by one |
| mut_M14 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | zero write strobes accepted |
| mut_M15 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | source-ID mismatch not detected |
| mut_M16 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | ID reuse flagged against the entry whose response is being transferred this cycle |
| mut_M17 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | ID-reuse detection disabled |
| mut_M18 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | poisoned request not detected |
| mut_M19 | fv_sramc | `DW=16 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | error precedence changed (ALIGN above RANGE) |
| mut_M20 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | requests accepted during flush |
| mut_M21 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | flush cancels an access that completes in the flush cycle |
| mut_M22 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2` | FAIL asserted in frame 5 | - | FAIL | **REACHED/KILLED** | cancel counter never decrements: later responses wrongly cancelled |
| mut_M23 | fv_sramc | `DW=16 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | byte strobes dropped: partial writes overwrite the word |
| mut_M24 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | write data bit 0 corrupted |
| mut_M25 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | bank row address corrupted |
| mut_M26 | fv_sramc | `NM=1 NB=2 DW=8 MAXOUT=2 BOUT=2` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | locked bank never recorded |
| mut_M27 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | bank issue ignores bank not-ready |
| mut_M28 | fv_sramc | `NM=2 NB=1 DW=8 MAXOUT=2 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | bank issue ignores tracker full |
| mut_M30 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 2 | - | FAIL | **REACHED/KILLED** | outstanding counter survives reset |
| mut_M33 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | response ID taken from the wrong bit slice |
| mut_M34 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | response source ID not preserved |
| mut_M35 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | 1-bit error flag inverted |
| mut_M36 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | idle ignores responses waiting in the FIFOs |
| mut_M37 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 4 | - | FAIL | **REACHED/KILLED** | bank error status not propagated |
| mut_M40 | fv_sramc | `DW=8 MAXOUT=1 BOUT=1` | FAIL asserted in frame 3 | - | FAIL | **REACHED/KILLED** | order-queue head survives reset |
| mut_FIFO_full_pop | fv_sramc_fifo | `WIDTH=2 DEPTH=2` | FAIL asserted in frame 5 | - | FAIL | **REACHED/KILLED** | FIFO drops a push into a full FIFO that is popped in the same cycle (M29) |
