# Gate-level lock-step equivalence

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (); Yosys 0.33 (git sha1 2584903a060); python 3.13.18. Not installed: vivado=NOT INSTALLED, quartus=NOT INSTALLED, openroad=NOT INSTALLED.  RTL sha256 `da5b4eae35469c90…`.

**4/4 configurations identical** to the synthesised generic gate netlist, every output, every cycle.

| config | description | netlist cells | seed 1 | seed 2 |
|---|---|---|---|---|
| gls_1x1_o1 | primary 1 master / 1 bank | 5634 | PASS — PASS cycles=60000 compares=59938 accepted=21876 responses=21854 | PASS — PASS cycles=60000 compares=59930 accepted=22033 responses=22009 |
| gls_4x4_o2 | 4x4, 2 outstanding, counters | 21498 | PASS — PASS cycles=60000 compares=59924 accepted=102712 responses=102546 | PASS — PASS cycles=60000 compares=59944 accepted=96602 responses=96475 |
| gls_4x4_prio | 4x4, 4 outstanding, priority classes | 20832 | PASS — PASS cycles=60000 compares=59934 accepted=101224 responses=101058 | PASS — PASS cycles=60000 compares=59926 accepted=103917 responses=103734 |
| gls_3x2_high | 3 masters x 2 banks, HIGH interleave, MASK_MODE=ALIGNED, 64-bit | 16781 | PASS — PASS cycles=60000 compares=59944 accepted=86339 responses=86248 | PASS — PASS cycles=60000 compares=59926 accepted=84755 responses=84610 |
