# SRAMController — summary (generated from the JSON reports of the final run)

| Check | Result | Notes |
|---|---|---|
| Lint: Verilator `-Wall` + Icarus `-Wall` | 32 pass / 0 fail | zero warnings, every top and parameter variant, with and without embedded assertions |
| Illegal parameterisations rejected | 22 pass / 0 fail | Verilator + Icarus + Yosys |
| Self-checking simulation | 59 pass / 0 fail | 59 runs, 81,978,390 scoreboard checks; 1x1 -> 1xN -> 4x4, MAX_OUT 1/2/4, 3 and 8 masters, 8..128-bit, priority classes, random-latency banks |
| Reference transaction interface + four-master SoC wrapper tests | 2 pass / 0 fail | `sf_sramc_if` connect test + protocol checker (lint clean); `sf_sramc_soc4` wiring test (4 masters in parallel, cross-master reads, errors, disabled source) |
| Same seed = same behaviour, Verilator vs Icarus | 10 pass / 0 fail | metric line and check count compared |
| Formal (Yosys + ABC) | 80 as expected / 0 unexpected | **23 unbounded proofs (PDR)**, 5 bounded (BMC depth in `reports/formal.md`), 52 non-vacuity checks (probes, mutants, negative control) |
| Mutation sanity | 41 killed / 0 survived | of 41 injected RTL bugs |
| Gate-level lock-step (RTL vs Yosys gate netlist) | 4 pass / 0 fail | 4 configurations x 2 seeds x 60 000 cycles, every output every cycle |
| Synthesis: ctl_1x1_o1 | 259 cells, 67 FF, 0 latches | primary: 1 master, 1 bank, no counters (generic gates; no timing claim) |
| Synthesis: ctl_4x4_o1 | 3688 cells, 294 FF, 0 latches | 4 masters x 4 banks, 1 outstanding, no counters (generic gates; no timing claim) |
| Synthesis: ctl_4x4_o4_perf | 22769 cells, 3679 FF, 0 latches | 4x4, 4 outstanding, counters (generic gates; no timing claim) |
| Synthesis: full subsystem, xc7 | 6245 LUT, 2770 FF, 4 block RAM | 4 x 1024 x 32-bit (16 KiB) banks + controller (Yosys inference evidence only) |

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (); Yosys 0.33 (git sha1 2584903a060); python 3.13.18. Not installed: vivado=NOT INSTALLED, quartus=NOT INSTALLED, openroad=NOT INSTALLED.  RTL sha256 `da5b4eae35469c90…`.

Detail: `lint.md`, `regression.md`, `formal.md`, `mutants.md`, `synth.md`, `gls.md`, `perf.md`.
