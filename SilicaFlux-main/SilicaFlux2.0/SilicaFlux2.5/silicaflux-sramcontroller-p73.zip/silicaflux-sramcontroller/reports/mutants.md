# Mutation sanity

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (); Yosys 0.33 (git sha1 2584903a060); python 3.13.18. Not installed: vivado=NOT INSTALLED, quartus=NOT INSTALLED, openroad=NOT INSTALLED.  RTL sha256 `da5b4eae35469c90…`.

Injected RTL bugs: **41 killed / 0 survived / 0 invalid** of 41.

| id | injected bug | verdict | caught by |
|---|---|---|---|
| M01 | in-order (bank-lock) rule removed: a master may overtake itself across banks | KILLED | s3_4x4_lat_o2: [85000] %Error: sf_sram_controller.sv:608: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unn |
| M02 | error response may overtake older accesses still inside a bank | KILLED | s3_4x4_lat_o2: [297075000] %Error: sf_sram_controller.sv:613: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl |
| M03 | response routed to the next master | KILLED | s3_4x4_o2: [95000] %Error: sf_sram_controller.sv:601: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unnamed |
| M04 | response ID corrupted | KILLED | s3_4x4_o2: [95000] %Error: sf_sram_controller.sv:613: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unnamed |
| M05 | response read/write type inverted | KILLED | s3_4x4_o2: [95000] %Error: sf_sram_controller.sv:614: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unnamed |
| M06 | write responses carry bank garbage instead of 0 | KILLED | v_4x4_o4: SRAMC_ERROR t=165000 m0: rdata not zero for write/error/cancel (status 0) |
| M07 | response dropped when the master is not ready (no back-pressure) | KILLED | s3_4x4_o2: [34335000] %Error: sf_sram_controller.sv:619: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unna |
| M08 | outstanding limit (credit) removed: response FIFO can overflow | KILLED | s3_4x4_o2: [34335000] %Error: sf_sram_controller.sv:599: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unna |
| M09 | round-robin pointer never advances (fixed priority): starvation | KILLED | s3_4x4_o2: [34415000] %Error: sf_sram_controller.sv:656: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk35.unnamedblk36: SFC_ASSERT TOP.tb_sramc_sub.d |
| M10 | all eligible masters granted: bank double-booking | KILLED | s3_4x4_o2: [34305000] %Error: sf_sram_controller.sv:591: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk30: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unna |
| M11 | HIGH class never yields: LOW class starves | KILLED | s3_4x4_prio: [94505000] %Error: sf_sram_controller.sv:656: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk35.unnamedblk36: SFC_ASSERT TOP.tb_sramc_sub |
| M12 | alignment check removed | KILLED | s3_4x4_o2: SRAMC_ERROR t=289835000 m3: status exp 2 got 0 (id 10) |
| M13 | range check off by one | KILLED | s3_4x4_o2: SRAMC_ERROR t=3715000 m0: status exp 1 got 0 (id 10) |
| M14 | zero write strobes accepted | KILLED | s3_4x4_o2: SRAMC_ERROR t=289835000 m0: status exp 3 got 0 (id 0) |
| M15 | source-ID mismatch not detected | KILLED | s3_4x4_o2: SRAMC_ERROR t=289865000 m2: status exp 4 got 0 (id 15) |
| M16 | ID reuse flagged against the entry whose response is being transferred this cycle | KILLED | s3_4x4_o2: SRAMC_ERROR t=289815000 bank 3 consumed by 2 masters in one cycle |
| M17 | ID-reuse detection disabled | KILLED | s3_4x4_o2: SRAMC_ERROR t=289975000 m1: status exp 5 got 0 (id 12) |
| M18 | poisoned request not detected | KILLED | s3_4x4_o2: SRAMC_ERROR t=289815000 m3: status exp 6 got 0 (id 3) |
| M19 | error precedence changed (ALIGN above RANGE) | KILLED | s3_4x4_o2: SRAMC_ERROR t=289975000 m3: status exp 1 got 2 (id 10) |
| M20 | requests accepted during flush | KILLED | s3_4x4_lat_o2: [428345000] %Error: sf_sram_controller.sv:605: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl |
| M21 | flush cancels an access that completes in the flush cycle | KILLED | s3_4x4_lat_o2: [428355000] %Error: sf_sram_controller.sv:595: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk30: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl |
| M22 | cancel counter never decrements: later responses wrongly cancelled | KILLED | s3_4x4_lat_o2: [433175000] %Error: sf_sram_controller.sv:595: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk30: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl |
| M23 | byte strobes dropped: partial writes overwrite the word | KILLED | s3_4x4_o2: SRAMC_ERROR t=4065000 m0: read data exp c501ac01 got c50b2f03 mask ffffffff (id 3) |
| M24 | write data bit 0 corrupted | KILLED | s3_4x4_o2: SRAMC_ERROR t=2965000 m0: read data exp e1111ce9 got e1111ce8 mask ffffffff (id 12) |
| M25 | bank row address corrupted | KILLED | v_4x4_o4: SRAMC_ERROR t=1585000 m0: status exp 0 got 8 (id 10) |
| M26 | locked bank never recorded | KILLED | s3_4x4_lat_o2: [195000] %Error: sf_sram_controller.sv:613: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.un |
| M27 | bank issue ignores bank not-ready | KILLED | v_4x4_o1: [75000] %Error: sf_sram_controller.sv:592: Assertion failed in TOP.tb_sramc_var.dut.unnamedblk30: SFC_ASSERT TOP.tb_sramc_var.dut.unnamedblk30: bank a |
| M28 | bank issue ignores tracker full | KILLED | v_4x4_bout1: [13865000] %Error: sf_sram_controller.sv:592: Assertion failed in TOP.tb_sramc_var.dut.unnamedblk30: SFC_ASSERT TOP.tb_sramc_var.dut.unnamedblk30:  |
| M29 | FIFO drops a push into a full FIFO that is popped in the same cycle | KILLED | s3_4x4_o2: [289875000] %Error: sf_sram_controller.sv:613: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unn |
| M30 | outstanding counter survives reset | KILLED | s3_4x4_o2: SRAMC_ERROR t=480585000 idle=0 but outstanding=0 |
| M31 | requests accepted while rst_n=0 | KILLED | s3_4x4_o2: SRAMC_ERROR t=480555000 reset: req_ready must be 0 while rst_n=0 |
| M32 | bank adapter: write completion not aligned to the read latency (out-of-order completions) | KILLED | s3_4x4_lat_o2: SRAMC_ERROR t=5765000 m0: latency 2 exp 3 |
| M33 | response ID taken from the wrong bit slice | KILLED | s3_4x4_o2: [105000] %Error: sf_sram_controller.sv:613: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unname |
| M34 | response source ID not preserved | KILLED | s3_4x4_o2: SRAMC_ERROR t=34325000 m1: response source 0 |
| M35 | 1-bit error flag inverted | KILLED | s3_4x4_o2: SRAMC_ERROR t=95000 m0: rsp_err 1 inconsistent with status 0 |
| M36 | idle ignores responses waiting in the FIFOs | KILLED | s3_4x4_o2: SRAMC_ERROR t=2645000 idle=1 but outstanding=1 |
| M37 | bank error status not propagated | KILLED | v_4x4_o1: SRAMC_ERROR t=1235000 m0: status exp 8 got 0 (id 8) |
| M38 | performance counter: arbitration wait counts idle cycles | KILLED | s3_4x4_o2: SRAMC_ERROR t=702065000 perf[12] exp 12242 got 24310 |
| M39 | performance counter: latency integral off by one per cycle | KILLED | s3_4x4_o2: SRAMC_ERROR t=702175000 perf[23] exp 15879 got 27911 |
| M41 | UNIFORM_LAT forced on although the banks have different latencies (bank-lock dropped wrongly) | KILLED | s3_4x4_lat_o2: [155000] %Error: sf_sram_controller.sv:613: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.un |
| M40 | order-queue head survives reset | KILLED | s3_4x4_o2: [480605000] %Error: sf_sram_controller.sv:613: Assertion failed in TOP.tb_sramc_sub.dut.u_ctl.unnamedblk31: SFC_ASSERT TOP.tb_sramc_sub.dut.u_ctl.unn |
