# Lint and negative tests

Verilator `-Wall` / Icarus `-Wall`: **32/32 pass** (zero warnings required).

| check | result |
|---|---|
| verilator -Wall: sf_sram_controller {} | pass |
| verilator -Wall: sf_sram_controller {} +SFC_ASSERT | pass |
| verilator -Wall: sf_sram_subsystem {} | pass |
| verilator -Wall: sf_sram_subsystem {} +SFC_ASSERT | pass |
| verilator -Wall: sf_sramc_soc4 {} | pass |
| verilator -Wall: sf_sramc_soc4 {} +SFC_ASSERT | pass |
| verilator -Wall: sf_sram_controller {'NUM_MASTERS': 1, 'NUM_BANKS': 1} | pass |
| verilator -Wall: sf_sram_controller {'NUM_MASTERS': 1, 'NUM_BANKS': 1} +SFC_ASSERT | pass |
| verilator -Wall: sf_sram_controller {'NUM_MASTERS': 3, 'NUM_BANKS': 2, 'MAX_OUT': 3, 'PRIO_EN': 1} | pass |
| verilator -Wall: sf_sram_controller {'NUM_MASTERS': 3, 'NUM_BANKS': 2, 'MAX_OUT': 3, 'PRIO_EN': 1} +SFC_ASSERT | pass |
| verilator -Wall: sf_sram_subsystem {'NUM_MASTERS': 1, 'NUM_BANKS': 1} | pass |
| verilator -Wall: sf_sram_subsystem {'NUM_MASTERS': 1, 'NUM_BANKS': 1} +SFC_ASSERT | pass |
| verilator -Wall: sf_sram_subsystem {'NUM_BANKS': 8, 'MAX_OUT': 4, 'DATA_WIDTH': 64} | pass |
| verilator -Wall: sf_sram_subsystem {'NUM_BANKS': 8, 'MAX_OUT': 4, 'DATA_WIDTH': 64} +SFC_ASSERT | pass |
| verilator -Wall: sf_sram_subsystem {'DATA_WIDTH': 8, 'MASK_MODE': 1, 'INTERLEAVE': 1} | pass |
| verilator -Wall: sf_sram_subsystem {'DATA_WIDTH': 8, 'MASK_MODE': 1, 'INTERLEAVE': 1} +SFC_ASSERT | pass |
| verilator -Wall: sf_sram_subsystem {'DATA_WIDTH': 128, 'PERF_EN': 0} | pass |
| verilator -Wall: sf_sram_subsystem {'DATA_WIDTH': 128, 'PERF_EN': 0} +SFC_ASSERT | pass |
| verilator -Wall: sf_sramc_arb {} | pass |
| verilator -Wall: sf_sramc_arb {'N': 1} | pass |
| verilator -Wall: sf_sramc_arb {'N': 5, 'PRIO_EN': 1, 'HP_MASK': "16'h0006", 'HP_LIMIT': 2} | pass |
| verilator -Wall: sf_sramc_fifo {} | pass |
| verilator -Wall: sf_sramc_fifo {'DEPTH': 1} | pass |
| verilator -Wall: sf_sramc_bank {} | pass |
| verilator -Wall: sf_sramc_bank {'LAT': 3} | pass |
| verilator -Wall: sf_sramc_perf {} | pass |
| icarus -Wall elaborate: sf_sram_subsystem | pass |
| icarus -Wall elaborate: sf_sramc_soc4 | pass |
| icarus -Wall elaborate: sf_sram_controller | pass |
| icarus -Wall elaborate: sf_sramc_arb | pass |
| icarus -Wall elaborate: sf_sramc_fifo | pass |
| icarus -Wall elaborate: sf_sramc_perf | pass |

Illegal parameterisations rejected by Verilator + Icarus + Yosys: **22/22**

| case | top | override | Verilator | Icarus | Yosys |
|---|---|---|---|---|---|
| masters_zero | sf_sram_controller | `{'NUM_MASTERS': 0}` | True | True | True |
| masters_17 | sf_sram_controller | `{'NUM_MASTERS': 17}` | True | True | True |
| banks_3 | sf_sram_controller | `{'NUM_BANKS': 3}` | True | True | True |
| banks_32 | sf_sram_controller | `{'NUM_BANKS': 32}` | True | True | True |
| data_width_12 | sf_sram_controller | `{'DATA_WIDTH': 12}` | True | True | True |
| data_width_24 | sf_sram_controller | `{'DATA_WIDTH': 24}` | True | True | True |
| data_width_256 | sf_sram_controller | `{'DATA_WIDTH': 256}` | True | True | True |
| bank_depth_1 | sf_sram_controller | `{'BANK_DEPTH': 1}` | True | True | True |
| interleave_5 | sf_sram_controller | `{'INTERLEAVE': 5}` | True | True | True |
| high_needs_pow2 | sf_sram_controller | `{'INTERLEAVE': 1, 'BANK_DEPTH': 100}` | True | True | True |
| max_out_zero | sf_sram_controller | `{'MAX_OUT': 0}` | True | True | True |
| max_out_17 | sf_sram_controller | `{'MAX_OUT': 17}` | True | True | True |
| bank_out_zero | sf_sram_controller | `{'BANK_OUT': 0}` | True | True | True |
| id_width_zero | sf_sram_controller | `{'ID_WIDTH': 0}` | True | True | True |
| addr_width_4 | sf_sram_controller | `{'ADDR_WIDTH': 4}` | True | True | True |
| capacity_overflow | sf_sram_controller | `{'ADDR_WIDTH': 12}` | True | True | True |
| mask_mode_3 | sf_sram_controller | `{'MASK_MODE': 3}` | True | True | True |
| id_check_2 | sf_sram_controller | `{'ID_CHECK': 2}` | True | True | True |
| arb_n_zero | sf_sramc_arb | `{'N': 0}` | True | True | True |
| arb_hp_limit_zero | sf_sramc_arb | `{'HP_LIMIT': 0}` | True | True | True |
| fifo_depth_zero | sf_sramc_fifo | `{'DEPTH': 0}` | True | True | True |
| bank_lat_zero | sf_sramc_bank | `{'LAT': 0}` | True | True | True |
