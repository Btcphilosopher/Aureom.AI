# Synthesis results (Yosys)

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (); Yosys 0.33 (git sha1 2584903a060); python 3.13.18. Not installed: vivado=NOT INSTALLED, quartus=NOT INSTALLED, openroad=NOT INSTALLED.  RTL sha256 `da5b4eae35469c90…`.

**No timing, frequency, area-in-um2 or power figure is claimed anywhere**: no liberty file, STA tool or PDK is available. Cell/LUT/FF counts are Yosys technology-mapped counts;
`logic depth` is the longest *topological* path in generic gate levels (a structural proxy, NOT a delay). All runs: `check -assert` (no combinational loops, no multiple drivers), latches = 0.

## Generic gate-level synthesis (AND/NAND/OR/NOR/XOR/XNOR/MUX + flip-flops)

| case | parameters | cells | flip-flops | gates | latches | logic depth | note |
|---|---|---|---|---|---|---|---|
| ctl_1x1_o1 | `{'NUM_MASTERS': 1, 'NUM_BANKS': 1, 'MAX_OUT': 1, 'BANK_OUT': 2, 'BANK_DEPTH': 64, 'PERF_EN': 0}` | 259 | 67 | 192 | 0 | 20 | primary: 1 master, 1 bank, no counters |
| ctl_1x1_o1_perf | `{'NUM_MASTERS': 1, 'NUM_BANKS': 1, 'MAX_OUT': 1, 'BANK_OUT': 2, 'BANK_DEPTH': 64, 'PERF_EN': 1}` | 5685 | 965 | 4720 | 0 | 30 | same + performance counters |
| ctl_4x4_o1 | `{'NUM_MASTERS': 4, 'NUM_BANKS': 4, 'MAX_OUT': 1, 'BANK_OUT': 2, 'BANK_DEPTH': 64, 'PERF_EN': 0}` | 3688 | 294 | 3394 | 0 | 33 | 4 masters x 4 banks, 1 outstanding, no counters |
| ctl_4x4_o1_perf | `{'NUM_MASTERS': 4, 'NUM_BANKS': 4, 'MAX_OUT': 1, 'BANK_OUT': 2, 'BANK_DEPTH': 64, 'PERF_EN': 1}` | 18697 | 2989 | 15708 | 0 | 103 | 4x4, 1 outstanding, counters |
| ctl_4x4_o4_perf | `{'NUM_MASTERS': 4, 'NUM_BANKS': 4, 'MAX_OUT': 4, 'BANK_OUT': 4, 'BANK_DEPTH': 64, 'PERF_EN': 1}` | 22769 | 3679 | 19090 | 0 | 103 | 4x4, 4 outstanding, counters |
| ctl_4x4_o4_prio | `{'NUM_MASTERS': 4, 'NUM_BANKS': 4, 'MAX_OUT': 4, 'BANK_OUT': 4, 'BANK_DEPTH': 64, 'PERF_EN': 0, 'PRIO_EN': 1}` | 5552 | 986 | 4566 | 0 | 39 | 4x4, 4 outstanding, priority classes, no counters |
| ctl_4x4_o1_perf16 | `{'NUM_MASTERS': 4, 'NUM_BANKS': 4, 'MAX_OUT': 1, 'BANK_OUT': 2, 'BANK_DEPTH': 64, 'PERF_EN': 1, 'CNT_W': 16}` | 12257 | 1645 | 10612 | 0 | 103 | 4x4, 1 outstanding, 16-bit counters |
| ctl_8x8_o2_perf | `{'NUM_MASTERS': 8, 'NUM_BANKS': 8, 'MAX_OUT': 2, 'BANK_OUT': 4, 'BANK_DEPTH': 64, 'PERF_EN': 1}` | 43349 | 6215 | 37134 | 0 | 197 | 8x8, 2 outstanding, counters |
| ctl_4x4_o4_dw64 | `{'NUM_MASTERS': 4, 'NUM_BANKS': 4, 'MAX_OUT': 4, 'BANK_OUT': 4, 'BANK_DEPTH': 64, 'DATA_WIDTH': 64, 'PERF_EN': 0}` | 8559 | 1486 | 7073 | 0 | 38 | 4x4, 64-bit data |
| arb_n4 | `{'N': 4}` | 37 | 2 | 35 | 0 | 11 | one-bank round-robin arbiter, N=4 |
| fifo_w22_d4 | `{'WIDTH': 22, 'DEPTH': 4}` | 195 | 95 | 100 | 0 | 10 | response FIFO (22 bits x 4) |
| perf_4x4 | `{'NUM_MASTERS': 4, 'NUM_BANKS': 4}` | 17264 | 2710 | 14554 | 0 | 103 | performance counters alone |

## FPGA technology mapping (controller + banks, evidence of block-RAM inference)

| case | family | cells | LUTs | FFs | block RAM | LUT RAM | note |
|---|---|---|---|---|---|---|---|
| sub_4x4_o1 | xc7 | 13284 | 6245 | 2770 | 4 | 8 | FULL subsystem: 4 masters x 4 x 1024 x 32-bit banks (16 KiB), 1 outstanding |
| sub_4x4_o1 | ice40 | 12794 | 7346 | 2834 | 32 | 0 | FULL subsystem: 4 masters x 4 x 1024 x 32-bit banks (16 KiB), 1 outstanding |
| sub_4x4_o1 | ecp5 | 19861 | 12084 | 2777 | 8 | 8 | FULL subsystem: 4 masters x 4 x 1024 x 32-bit banks (16 KiB), 1 outstanding |
| sub_4x4_o4_lat | xc7 | 14636 | 6888 | 3036 | 4 | 36 | FULL subsystem, 4 outstanding, bank latencies 1..4 |
| sub_4x4_o4_lat | ice40 | 15334 | 8583 | 3912 | 32 | 0 | FULL subsystem, 4 outstanding, bank latencies 1..4 |
| sub_4x4_o4_lat | ecp5 | 19423 | 12151 | 3132 | 8 | 52 | FULL subsystem, 4 outstanding, bank latencies 1..4 |
| soc4 | xc7 | 13944 | 6615 | 2762 | 4 | 36 | four-master SoC wrapper (ControlCore, DMA, Vector, TensorCore), defaults |
| soc4 | ice40 | 14379 | 8261 | 3432 | 32 | 0 | four-master SoC wrapper (ControlCore, DMA, Vector, TensorCore), defaults |
| soc4 | ecp5 | 20035 | 12350 | 2762 | 8 | 52 | four-master SoC wrapper (ControlCore, DMA, Vector, TensorCore), defaults |
