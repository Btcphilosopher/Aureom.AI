// =============================================================================
// SilicaFlux SRAMController :: tb_sramc_soc4   (directed wiring test of sf_sramc_soc4)
// The four named masters (ControlCore cc, DMA dma, Vector Engine vec, TensorCore tc) submit requests at the same time; each response must come
// back on the right port with the right ID, a master reads what ANOTHER master wrote, a disabled source is answered SFC_ST_SRC, errors are explicit.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_sramc_soc4;
  logic clk = 1'b0; always #5 clk = ~clk;
  logic rst_n = 1'b0;
  logic cc_req_valid = 1'b0, cc_req_ready, cc_req_we = 1'b0, cc_rsp_valid, cc_rsp_ready = 1'b1, cc_rsp_we, cc_rsp_err;
  logic [31:0] cc_req_addr = '0, cc_req_wdata = '0, cc_rsp_rdata; logic [3:0] cc_req_wstrb = '0, cc_req_id = '0, cc_rsp_id, cc_rsp_status;
  logic dma_req_valid = 1'b0, dma_req_ready, dma_req_we = 1'b0, dma_rsp_valid, dma_rsp_ready = 1'b1, dma_rsp_we, dma_rsp_err;
  logic [31:0] dma_req_addr = '0, dma_req_wdata = '0, dma_rsp_rdata; logic [3:0] dma_req_wstrb = '0, dma_req_id = '0, dma_rsp_id, dma_rsp_status;
  logic vec_req_valid = 1'b0, vec_req_ready, vec_req_we = 1'b0, vec_rsp_valid, vec_rsp_ready = 1'b1, vec_rsp_we, vec_rsp_err;
  logic [31:0] vec_req_addr = '0, vec_req_wdata = '0, vec_rsp_rdata; logic [3:0] vec_req_wstrb = '0, vec_req_id = '0, vec_rsp_id, vec_rsp_status;
  logic tc_req_valid = 1'b0, tc_req_ready, tc_req_we = 1'b0, tc_rsp_valid, tc_rsp_ready = 1'b1, tc_rsp_we, tc_rsp_err;
  logic [31:0] tc_req_addr = '0, tc_req_wdata = '0, tc_rsp_rdata; logic [3:0] tc_req_wstrb = '0, tc_req_id = '0, tc_rsp_id, tc_rsp_status;
  logic [3:0] src_en = 4'hF;
  logic flush = 1'b0, idle, ovf, proto, perf_clr = 1'b0; logic [5:0] perf_sel = '0; logic [31:0] perf_val;
  sf_sramc_soc4 #(.MAX_OUT(2), .BANK_DEPTH(16)) dut (
    .clk, .rst_n,
    .cc_req_valid(cc_req_valid), .cc_req_ready(cc_req_ready), .cc_req_we(cc_req_we), .cc_req_addr(cc_req_addr), .cc_req_wdata(cc_req_wdata), .cc_req_wstrb(cc_req_wstrb), .cc_req_id(cc_req_id),
    .cc_rsp_valid(cc_rsp_valid), .cc_rsp_ready(cc_rsp_ready), .cc_rsp_rdata(cc_rsp_rdata), .cc_rsp_id(cc_rsp_id), .cc_rsp_we(cc_rsp_we), .cc_rsp_err(cc_rsp_err), .cc_rsp_status(cc_rsp_status),
    .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr), .dma_req_wdata(dma_req_wdata), .dma_req_wstrb(dma_req_wstrb), .dma_req_id(dma_req_id),
    .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(dma_rsp_ready), .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_id(dma_rsp_id), .dma_rsp_we(dma_rsp_we), .dma_rsp_err(dma_rsp_err), .dma_rsp_status(dma_rsp_status),
    .vec_req_valid(vec_req_valid), .vec_req_ready(vec_req_ready), .vec_req_we(vec_req_we), .vec_req_addr(vec_req_addr), .vec_req_wdata(vec_req_wdata), .vec_req_wstrb(vec_req_wstrb), .vec_req_id(vec_req_id),
    .vec_rsp_valid(vec_rsp_valid), .vec_rsp_ready(vec_rsp_ready), .vec_rsp_rdata(vec_rsp_rdata), .vec_rsp_id(vec_rsp_id), .vec_rsp_we(vec_rsp_we), .vec_rsp_err(vec_rsp_err), .vec_rsp_status(vec_rsp_status),
    .tc_req_valid(tc_req_valid), .tc_req_ready(tc_req_ready), .tc_req_we(tc_req_we), .tc_req_addr(tc_req_addr), .tc_req_wdata(tc_req_wdata), .tc_req_wstrb(tc_req_wstrb), .tc_req_id(tc_req_id),
    .tc_rsp_valid(tc_rsp_valid), .tc_rsp_ready(tc_rsp_ready), .tc_rsp_rdata(tc_rsp_rdata), .tc_rsp_id(tc_rsp_id), .tc_rsp_we(tc_rsp_we), .tc_rsp_err(tc_rsp_err), .tc_rsp_status(tc_rsp_status),
    .src_en, .flush, .idle, .sts_rsp_overflow(ovf), .sts_bank_proto(proto), .perf_clr, .perf_sel, .perf_val);

  // ---- master cc
  task automatic x_cc(input bit we, input logic [31:0] a, input logic [31:0] d, input logic [3:0] id, output logic [31:0] rd, output logic [3:0] st, output logic [3:0] rid);
    @(negedge clk); cc_req_valid = 1'b1; cc_req_we = we; cc_req_addr = a; cc_req_wdata = d; cc_req_wstrb = 4'hF; cc_req_id = id;
    #1;
    while (!cc_req_ready) begin @(negedge clk); #1; end
    @(negedge clk); cc_req_valid = 1'b0;
    #1;
    while (!cc_rsp_valid) begin @(negedge clk); #1; end
    rd = cc_rsp_rdata; st = cc_rsp_status; rid = cc_rsp_id;
  endtask

  // ---- master dma
  task automatic x_dma(input bit we, input logic [31:0] a, input logic [31:0] d, input logic [3:0] id, output logic [31:0] rd, output logic [3:0] st, output logic [3:0] rid);
    @(negedge clk); dma_req_valid = 1'b1; dma_req_we = we; dma_req_addr = a; dma_req_wdata = d; dma_req_wstrb = 4'hF; dma_req_id = id;
    #1;
    while (!dma_req_ready) begin @(negedge clk); #1; end
    @(negedge clk); dma_req_valid = 1'b0;
    #1;
    while (!dma_rsp_valid) begin @(negedge clk); #1; end
    rd = dma_rsp_rdata; st = dma_rsp_status; rid = dma_rsp_id;
  endtask

  // ---- master vec
  task automatic x_vec(input bit we, input logic [31:0] a, input logic [31:0] d, input logic [3:0] id, output logic [31:0] rd, output logic [3:0] st, output logic [3:0] rid);
    @(negedge clk); vec_req_valid = 1'b1; vec_req_we = we; vec_req_addr = a; vec_req_wdata = d; vec_req_wstrb = 4'hF; vec_req_id = id;
    #1;
    while (!vec_req_ready) begin @(negedge clk); #1; end
    @(negedge clk); vec_req_valid = 1'b0;
    #1;
    while (!vec_rsp_valid) begin @(negedge clk); #1; end
    rd = vec_rsp_rdata; st = vec_rsp_status; rid = vec_rsp_id;
  endtask

  // ---- master tc
  task automatic x_tc(input bit we, input logic [31:0] a, input logic [31:0] d, input logic [3:0] id, output logic [31:0] rd, output logic [3:0] st, output logic [3:0] rid);
    @(negedge clk); tc_req_valid = 1'b1; tc_req_we = we; tc_req_addr = a; tc_req_wdata = d; tc_req_wstrb = 4'hF; tc_req_id = id;
    #1;
    while (!tc_req_ready) begin @(negedge clk); #1; end
    @(negedge clk); tc_req_valid = 1'b0;
    #1;
    while (!tc_rsp_valid) begin @(negedge clk); #1; end
    rd = tc_rsp_rdata; st = tc_rsp_status; rid = tc_rsp_id;
  endtask

  int errors = 0, checks = 0;
  function automatic void chk(input bit c, input string w);
    checks++; if (!c) begin errors++; $display("SRAMC_ERROR %s", w); end
  endfunction
  logic [31:0] rd [4]; logic [3:0] st [4]; logic [3:0] rid [4];
  logic [31:0] val [4];
  initial begin
    repeat (4) @(negedge clk); rst_n = 1;
    for (int i = 0; i < 4; i++) val[i] = 32'hA5A50000 + i * 32'h111;
    // 1. all four masters write their own word (word i -> bank i) at the same time
    fork
      x_cc (1, 32'h00, val[0], 4'h1, rd[0], st[0], rid[0]);
      x_dma(1, 32'h04, val[1], 4'h2, rd[1], st[1], rid[1]);
      x_vec(1, 32'h08, val[2], 4'h3, rd[2], st[2], rid[2]);
      x_tc (1, 32'h0C, val[3], 4'h4, rd[3], st[3], rid[3]);
    join
    for (int i = 0; i < 4; i++) begin chk(st[i] == 0, $sformatf("write %0d status %0d", i, st[i])); chk(rid[i] == i + 1, $sformatf("write %0d id %0d", i, rid[i])); end
    // 2. every master reads the word written by the NEXT master (cross-master visibility), concurrently
    fork
      x_cc (0, 32'h04, 0, 4'h5, rd[0], st[0], rid[0]);
      x_dma(0, 32'h08, 0, 4'h6, rd[1], st[1], rid[1]);
      x_vec(0, 32'h0C, 0, 4'h7, rd[2], st[2], rid[2]);
      x_tc (0, 32'h00, 0, 4'h8, rd[3], st[3], rid[3]);
    join
    for (int i = 0; i < 4; i++) begin
      chk(st[i] == 0, $sformatf("read %0d status %0d", i, st[i]));
      chk(rid[i] == i + 5, $sformatf("read %0d id %0d", i, rid[i]));
      chk(rd[i] === val[(i + 1) % 4], $sformatf("read %0d data %h exp %h", i, rd[i], val[(i + 1) % 4]));
    end
    // 3. all four on the SAME bank (word 0..): contention, still correct and routed to the right port
    fork
      x_cc (0, 32'h00, 0, 4'h9, rd[0], st[0], rid[0]);
      x_dma(0, 32'h10, 0, 4'hA, rd[1], st[1], rid[1]);
      x_vec(0, 32'h20, 0, 4'hB, rd[2], st[2], rid[2]);
      x_tc (0, 32'h00, 0, 4'hC, rd[3], st[3], rid[3]);
    join
    chk(st[0] == 0 && rid[0] == 4'h9 && rd[0] === val[0], "contention cc");
    chk(st[3] == 0 && rid[3] == 4'hC && rd[3] === val[0], "contention tc");
    chk(rid[1] == 4'hA && rid[2] == 4'hB, "contention ids");
    // 4. explicit errors: out of range from the DMA, misaligned from the Vector Engine; disabled source (TensorCore) -> SFC_ST_SRC
    src_en[3] = 1'b0;
    fork
      x_dma(0, 32'h4000, 0, 4'hD, rd[1], st[1], rid[1]);
      x_vec(0, 32'h02, 0, 4'hE, rd[2], st[2], rid[2]);
      x_tc (0, 32'h00, 0, 4'hF, rd[3], st[3], rid[3]);
    join
    chk(st[1] == 4'd1 && rid[1] == 4'hD, $sformatf("range error %0d", st[1]));
    chk(st[2] == 4'd2 && rid[2] == 4'hE, $sformatf("align error %0d", st[2]));
    chk(st[3] == 4'd4 && rid[3] == 4'hF && rd[3] === 32'h0, $sformatf("source error %0d", st[3]));
    src_en[3] = 1'b1;
    repeat (6) @(negedge clk);
    chk(idle === 1'b1, "idle after drain");
    chk(ovf === 1'b0 && proto === 1'b0, "sticky status clean");
    if (errors == 0) $display("SRAMC_RESULT PASS tb=tb_sramc_soc4 seed=1 checks=%0d errors=0", checks);
    else             $display("SRAMC_RESULT FAIL tb=tb_sramc_soc4 seed=1 checks=%0d errors=%0d", checks, errors);
    $finish;
  end
endmodule
`default_nettype wire
