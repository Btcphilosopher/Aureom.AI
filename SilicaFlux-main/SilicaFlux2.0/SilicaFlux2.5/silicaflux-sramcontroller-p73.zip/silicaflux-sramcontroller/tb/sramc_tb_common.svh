// =============================================================================
// SilicaFlux SRAMController :: sramc_tb_common.svh   (testbench only)
// Deterministic xorshift PRNG (same stream in Verilator and Icarus for the same
// +seed), check counters, and the single result line parsed by the regression:
//   SRAMC_RESULT <PASS|FAIL> tb=<name> seed=<n> checks=<n> errors=<n>
// Adapted from the SRAM Wrapper Library's tb_common.svh (same generator).
// =============================================================================
longint unsigned tb_rng_state = 64'h9E37_79B9_7F4A_7C15;
int unsigned     tb_seed      = 1;
int              tb_errors    = 0;
longint          tb_checks    = 0;
int              tb_max_print = 25;

task automatic tb_seed_init();
  if (!$value$plusargs("seed=%d", tb_seed)) tb_seed = 1;
  tb_rng_state = 64'h9E37_79B9_7F4A_7C15 ^ (64'(tb_seed) * 64'hBF58_476D_1CE4_E5B9);
  if (tb_rng_state == 0) tb_rng_state = 64'h1;
  $display("SRAMC_INFO seed=%0d", tb_seed);
endtask

function automatic logic [31:0] rnd32();
  logic [63:0] x;
  x = tb_rng_state;
  x = x ^ (x >> 12);
  x = x ^ (x << 25);
  x = x ^ (x >> 27);
  tb_rng_state = x;
  rnd32 = 32'((x * 64'h2545_F491_4F6C_DD1D) >> 32);
endfunction

// uniform in [0, n)  (n >= 1)
function automatic int unsigned rnd_below(input int unsigned n);
  if (n <= 1) rnd_below = 0;
  else        rnd_below = rnd32() % n;
endfunction

function automatic bit rnd_pct(input int unsigned pct);
  rnd_pct = (rnd_below(100) < pct);
endfunction

// random vector of up to 128 bits
function automatic logic [127:0] rnd_vec();
  logic [127:0] v;
  for (int i = 0; i < 4; i++) v[i*32 +: 32] = rnd32();
  rnd_vec = v;
endfunction

task automatic tb_check(input bit cond, input string what);
  tb_checks++;
  if (!cond) begin
    tb_errors++;
    if (tb_errors <= tb_max_print) $display("SRAMC_ERROR t=%0t %s", $time, what);
  end
endtask

task automatic tb_finish(input string name);
  if (tb_errors == 0 && tb_checks > 0)
    $display("SRAMC_RESULT PASS tb=%s seed=%0d checks=%0d errors=0", name, tb_seed, tb_checks);
  else
    $display("SRAMC_RESULT FAIL tb=%s seed=%0d checks=%0d errors=%0d", name, tb_seed, tb_checks, tb_errors);
  $finish;
endtask
