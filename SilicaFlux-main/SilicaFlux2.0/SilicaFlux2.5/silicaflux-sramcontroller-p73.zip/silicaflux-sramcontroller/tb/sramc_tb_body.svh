// =============================================================================
// SilicaFlux SRAMController :: sramc_tb_body.svh   (testbench only)
// Self-checking testbench body, included by tb_sramc_sub.sv (controller + real
// sf_sram_core banks, per-bank latencies) and tb_sramc_var.sv (controller + random
// latency / random busy bank models).  The including wrapper declares the DUT
// signals, the parameters and instantiates the DUT.
//
// ONE cycle engine (a single clocked process => fully deterministic):
//   at every rising edge it
//     1. samples what happened in the cycle that just ended (cycle t):
//          response transfers  -> compared with the oldest expected response of that master
//          request acceptances -> reference model computes the expected response
//                                 (status, read data from the memory model, write effects)
//          back-pressure / idle / ID / reset / flush monitors
//     2. drives the inputs of cycle t+1 (request queues, response-ready, reset, flush)
//   Memory model: updated at the ACCEPTANCE edge, which is when the controller
//   performs the array access.  Per-byte "known" bits: unwritten SRAM is never
//   assumed to hold any value.
//   Phases (each: generate -> drain -> checks): see ph_start().
// =============================================================================
`include "sramc_tb_common.svh"

localparam int NBYTE       = DW / 8;
localparam int OFFB        = $clog2(NBYTE);
localparam int TOTAL_WORDS = NB * BD;
localparam int TOTAL_BYTES = TOTAL_WORDS * NBYTE;
localparam int IDS         = 1 << IDW;
localparam int SRCW        = (NM > 1) ? $clog2(NM) : 1;
localparam int ED          = 32;     // expected-response queue depth per master
localparam int QD          = 64;     // request queue depth per master
localparam int NPH         = 16;
localparam int NHOT        = 4;

localparam logic [3:0] ST_BANK = 4'd8;
localparam logic [3:0] ST_OK = 4'd0, ST_RANGE = 4'd1, ST_ALIGN = 4'd2, ST_MASK = 4'd3, ST_SRC = 4'd4,
                       ST_ID = 4'd5, ST_POISON = 4'd6, ST_CANCEL = 4'd7;

// ------------------------------------------------------------------ clock / reset
initial clk = 1'b0;
always #5 clk = ~clk;

// ------------------------------------------------------------------ model state
logic [DW-1:0]    mdat [TOTAL_WORDS];
logic [NBYTE-1:0] mkn  [TOTAL_WORDS];

// expected responses (flat index m*ED + i)
logic [IDW-1:0]   e_id   [NM*ED];
logic             e_we   [NM*ED];
logic [3:0]       e_st   [NM*ED];
logic [DW-1:0]    e_dat  [NM*ED];
logic [DW-1:0]    e_msk  [NM*ED];
int               e_acyc [NM*ED];
int               e_bank [NM*ED];
bit               e_fl   [NM*ED];      // marked by a flush
bit               e_ex   [NM*ED];      // accepted into an empty master: latency is exactly predictable
int               e_fcyc [NM*ED];
int               e_h [NM], e_t [NM], e_n [NM];
int               id_cnt [NM*IDS];

// request queues (flat index m*QD + i)
logic [31:0]      q_addr [NM*QD];
logic             q_we   [NM*QD];
logic [DW-1:0]    q_wd   [NM*QD];
logic [NBYTE-1:0] q_ws   [NM*QD];
int               q_id   [NM*QD];      // -1 = choose at presentation
int               q_src  [NM*QD];
logic             q_err  [NM*QD];
int               q_gap  [NM*QD];
int               q_h [NM], q_t [NM], q_n [NM];
int               hold_cnt [NM];
bit               head_wait [NM];
bit               id_blocked [NM];

// knobs (set per phase)
bit               gen_on [NM];
int               k_issue_pct [NM];
int               k_rdy_pct [NM];
int               k_gap_pct, k_gap_max, k_rd_pct, k_amode, k_bank, k_err_pct, k_wfull_pct;
int               k_reset_pm, k_flush_pm, k_srcen_pm, k_exact, k_gen_n, gen_left;
int               k_rdpct_m [NM];
int               k_idm [NM];
longint           tot_rstcancel;
int               rdy_block_until [NM];
int               hot [NHOT];
int               seq_ptr [NM];

// engine state
int               cyc, rst_cnt, phase, ph_cyc, ph_len, ph_state, ph_start_cyc, flush_cnt, flush_len;
int               next_id_ctr [NM];
bit               prev_rv [NM], prev_rr [NM];
logic [DW+IDW+8:0] prev_pl [NM];
int               ph_acc0 [NM], ph_cmp0 [NM];
longint           tot_acc, tot_cmp;
int               n_err_cases, n_par_cycles;
int               fair_min, fair_max;
bit               done_flag;

// performance-counter shadows
longint s_cycles, s_busy, s_acc, s_cmp, s_rd, s_wr, s_err, s_cancel, s_wait, s_rstall, s_outmax;
longint s_m_acc [NM], s_m_cmp [NM], s_m_rd [NM], s_m_wr [NM], s_m_err [NM], s_m_wait [NM], s_m_waitmax [NM];
longint s_m_run [NM], s_m_lat [NM], s_m_outmax [NM], s_m_rstall [NM], s_m_cancel [NM];
longint s_b_acc [NB], s_b_rd [NB], s_b_wr [NB], s_b_busy [NB];
int     b_until [NB];
int     pv_idx, pv_state, pv_cnt;
bit     pv_known;
longint pv_exp;
int     bank_hits [NB];
int     cov_st [16];
longint cov_conf, cov_ost;

localparam int NPERF = 16 + 16 * NM + 8 * NB;

// ------------------------------------------------------------------ helpers
function automatic int tb_lat(input int b);
  int v;
  if (MODE != 0) tb_lat = 0;
  else begin
    v = 32'(LATS[4*b +: 4]);
    tb_lat = (v == 0) ? 1 : v;
  end
endfunction

function automatic int tb_bank_of(input logic [31:0] a);
  int w;
  w = a >> OFFB;
  if (NB == 1) tb_bank_of = 0;
  else if (ILV == 0) tb_bank_of = w % NB;
  else tb_bank_of = w / BD;
endfunction

function automatic int tb_row_of(input logic [31:0] a);
  int w;
  w = a >> OFFB;
  if (ILV == 0) tb_row_of = w / NB;
  else          tb_row_of = w % BD;
endfunction

function automatic int mk_word(input int b, input int row);
  if (ILV == 0) mk_word = row * NB + b;
  else          mk_word = b * BD + row;
endfunction

function automatic bit tb_mask_ok(input logic [NBYTE-1:0] w);
  int p, r;
  bit ok;
  ok = 1'b0;
  if (w != '0) begin
    p = 0;
    while (!w[p]) p = p + 1;
    r = 0;
    while (p + r < NBYTE && w[p + r]) r = r + 1;
    // w must be exactly `r` ones at position p, r a power of two, p a multiple of r
    ok = (w == ((({NBYTE{1'b0}} | ((1 << r) - 1)) << p))) && ((r & (r - 1)) == 0) && ((p % r) == 0);
  end
  tb_mask_ok = ok;
endfunction

// reference model of the request checks (independent of the RTL)
function automatic logic [3:0] tb_status(input int m, input logic [31:0] a, input bit we, input logic [NBYTE-1:0] ws,
                                         input int id, input int src, input bit perr);
  logic [3:0] st;
  bit idhit;
  idhit = (IDCHK != 0) && (id_cnt[m*IDS + id] != 0);
  st = ST_OK;
  if (we && (ws == '0 || (MASKM == 1 && !tb_mask_ok(ws)))) st = ST_MASK;
  if ((a & (NBYTE - 1)) != 0) st = ST_ALIGN;
  if (a >= TOTAL_BYTES) st = ST_RANGE;
  if (idhit) st = ST_ID;
  if (perr) st = ST_POISON;
  if (!src_en[m] || (SRCCHK != 0 && src != m)) st = ST_SRC;
  tb_status = st;
endfunction

function automatic logic [DW-1:0] byte_mask(input logic [NBYTE-1:0] k);
  logic [DW-1:0] r;
  r = '0;
  for (int l = 0; l < NBYTE; l++) if (k[l]) r[l*8 +: 8] = 8'hFF;
  byte_mask = r;
endfunction

task automatic err(input string s);
  tb_check(1'b0, s);
endtask

// ------------------------------------------------------------------ request queue
task automatic qpush(input int m, input logic [31:0] a, input bit we, input logic [DW-1:0] wd, input logic [NBYTE-1:0] ws,
                     input int id, input int src, input bit perr, input int gap);
  int i;
  if (q_n[m] >= QD) begin
    err("TB: request queue overflow");
  end else begin
    i = m * QD + q_t[m];
    q_addr[i] = a; q_we[i] = we; q_wd[i] = wd; q_ws[i] = ws; q_id[i] = id; q_src[i] = src; q_err[i] = perr; q_gap[i] = gap;
    q_t[m] = (q_t[m] + 1) % QD;
    q_n[m] = q_n[m] + 1;
  end
endtask

function automatic logic [NBYTE-1:0] gen_strobe();
  logic [NBYTE-1:0] s;
  int k, sz, pos;
  if (rnd_pct(k_wfull_pct)) s = '1;
  else if (MASKM == 1) begin
    k = rnd_below($clog2(NBYTE) + 1);
    sz = 1 << k;
    pos = rnd_below(NBYTE / sz) * sz;
    s = '0;
    for (int j = 0; j < sz; j++) s[pos + j] = 1'b1;
  end else begin
    s = rnd32();
    if (s == '0) s = 1;
  end
  gen_strobe = s;
endfunction

// an ID that is (very probably) still outstanding: the ID of the youngest expected response
function automatic int m_rsp_id_hint(input int m);
  int i;
  if (e_n[m] > 0) begin
    i = m * ED + ((e_t[m] + ED - 1) % ED);
    m_rsp_id_hint = e_id[i];
  end else m_rsp_id_hint = rnd_below(IDS);
endfunction

task automatic gen_req(input int m);
  int w, b, row, gap, kind, k2, k3;
  logic [31:0] a;
  logic        we, perr;
  logic [NBYTE-1:0] ws;
  logic [DW-1:0] wd;
  int id, src;
  logic [31:0] r32;
  logic [127:0] rv;
  bit  hit, hit2;
  case (k_amode)
    1: w = mk_word(k_bank, rnd_below(BD));
    2: w = mk_word(m % NB, rnd_below(BD));
    3: w = hot[rnd_below(NHOT)];
    4: begin w = seq_ptr[m]; seq_ptr[m] = (seq_ptr[m] + 1) % TOTAL_WORDS; end
    default: w = rnd_below(TOTAL_WORDS);
  endcase
  a   = w * NBYTE;
  we  = !rnd_pct((k_rdpct_m[m] >= 0) ? k_rdpct_m[m] : k_rd_pct);
  if (we) ws = gen_strobe();
  else begin r32 = rnd32(); ws = r32[NBYTE-1:0]; end
  rv  = rnd_vec();
  wd  = rv[DW-1:0];
  perr = 1'b0;
  src = m;
  id  = (k_idm[m] == 2) ? 0 : -1;
  hit = rnd_pct(k_err_pct);
  if (hit) begin
    kind = rnd_below(6);
    case (kind)
      0: begin                                                                                       // range
           a = TOTAL_BYTES + rnd_below(4096) * NBYTE;
           k2 = rnd_below(2);
           if (k2 == 1) begin k3 = rnd_below(NBYTE); a = a + k3; end
         end
      1: if (NBYTE > 1) a = a + 1 + rnd_below(NBYTE - 1); else a = TOTAL_BYTES;                      // alignment
      2: begin we = 1'b1; ws = (MASKM == 1 && NBYTE >= 4) ? ({NBYTE{1'b0}} | 3'b101) : '0; end     // unsupported strobes
      3: src = (m + 1 + rnd_below((NM > 1) ? NM - 1 : 1)) % ((NM > 1) ? NM : 2);                      // invalid source
      4: perr = 1'b1;                                                                                // poisoned
      default: id = m_rsp_id_hint(m);                                                                // id reuse attempt
    endcase
  end
  hit2 = rnd_pct(k_gap_pct);
  gap = 0;
  if (hit2) gap = rnd_below(k_gap_max + 1);
  qpush(m, a, we, wd, ws, id, src, perr, gap);
  if (gen_left > 0) gen_left = gen_left - 1;
endtask

// ------------------------------------------------------------------ scoreboard
task automatic reset_model_state();
  for (int m = 0; m < NM; m++) begin
    e_h[m] = 0; e_t[m] = 0; e_n[m] = 0;
    q_h[m] = 0; q_t[m] = 0; q_n[m] = 0;
    hold_cnt[m] = 0; head_wait[m] = 1'b0;
    for (int k = 0; k < IDS; k++) id_cnt[m*IDS + k] = 0;
  end
endtask

task automatic shadows_clear(input bit keep_busy);
  s_cycles = 0; s_busy = 0; s_acc = 0; s_cmp = 0; s_rd = 0; s_wr = 0; s_err = 0; s_cancel = 0; s_wait = 0; s_rstall = 0; s_outmax = 0;
  for (int m = 0; m < NM; m++) begin
    s_m_acc[m] = 0; s_m_cmp[m] = 0; s_m_rd[m] = 0; s_m_wr[m] = 0; s_m_err[m] = 0; s_m_wait[m] = 0; s_m_waitmax[m] = 0;
    s_m_run[m] = 0; s_m_lat[m] = 0; s_m_outmax[m] = 0; s_m_rstall[m] = 0; s_m_cancel[m] = 0;
  end
  for (int b = 0; b < NB; b++) begin
    s_b_acc[b] = 0; s_b_rd[b] = 0; s_b_wr[b] = 0; s_b_busy[b] = 0;
    if (!keep_busy) b_until[b] = 0;
  end
endtask

// process the transfer of one response of master m (compare with the oldest expected one)
task automatic check_response(input int m);
  int i;
  logic [3:0] st;
  logic [DW-1:0] exp_d;
  bit cancel_ok;
  if (e_n[m] == 0) begin
    err($sformatf("m%0d: response transferred with no outstanding request (spurious / duplicate)", m));
  end else begin
    i = m * ED + e_h[m];
    st = m_rsp_status[m*4 +: 4];
    cancel_ok = 1'b0;
    // flush: a request that was inside a bank when flush was sampled is answered CANCEL.
    if (e_fl[i] && (e_st[i] == ST_OK || e_st[i] == ST_BANK)) begin
      if (MODE == 0) cancel_ok = ((e_acyc[i] + tb_lat(e_bank[i])) > e_fcyc[i]);
      else           cancel_ok = 1'b1;
    end
    if (MODE == 0 && e_fl[i] && e_st[i] == ST_OK) begin
      tb_check(st == (cancel_ok ? ST_CANCEL : ST_OK), $sformatf("m%0d: flush: expected status %0d got %0d (accept@%0d lat %0d flush@%0d)", m, cancel_ok ? ST_CANCEL : ST_OK, st, e_acyc[i], tb_lat(e_bank[i]), e_fcyc[i]));
    end else if (e_fl[i] && (e_st[i] == ST_OK || e_st[i] == ST_BANK)) begin
      tb_check(st == e_st[i] || st == ST_CANCEL, $sformatf("m%0d: flush: status %0d is neither the normal status nor CANCEL", m, st));
    end else begin
      tb_check(st == e_st[i], $sformatf("m%0d: status exp %0d got %0d (id %0d)", m, e_st[i], st, e_id[i]));
    end
    tb_check(m_rsp_id[m*IDW +: IDW] == e_id[i], $sformatf("m%0d: response ID exp %0d got %0d (misrouted / reordered)", m, e_id[i], m_rsp_id[m*IDW +: IDW]));
    tb_check(m_rsp_we[m] == e_we[i], $sformatf("m%0d: response type exp %0d got %0d", m, e_we[i], m_rsp_we[m]));
    tb_check(m_rsp_src[m*SRCW +: SRCW] == SRCW'(m), $sformatf("m%0d: response source %0d", m, m_rsp_src[m*SRCW +: SRCW]));
    tb_check(m_rsp_err[m] == (st != ST_OK), $sformatf("m%0d: rsp_err %0b inconsistent with status %0d", m, m_rsp_err[m], st));
    if (st == ST_OK && !e_we[i]) begin
      exp_d = e_dat[i];
      tb_check(((m_rsp_rdata[m*DW +: DW] ^ exp_d) & e_msk[i]) == '0,
               $sformatf("m%0d: read data exp %h got %h mask %h (id %0d)", m, exp_d, m_rsp_rdata[m*DW +: DW], e_msk[i], e_id[i]));
    end else begin
      tb_check(m_rsp_rdata[m*DW +: DW] == '0, $sformatf("m%0d: rdata not zero for write/error/cancel (status %0d)", m, st));
    end
    if (e_ex[i] && MODE == 0 && !e_fl[i]) begin
      tb_check((cyc - e_acyc[i]) == ((e_st[i] != ST_OK) ? 1 : tb_lat(e_bank[i]) + 1),
               $sformatf("m%0d: latency %0d exp %0d", m, cyc - e_acyc[i], (e_st[i] != ST_OK) ? 1 : tb_lat(e_bank[i]) + 1));
    end
    cov_st[st] = cov_st[st] + 1;
    id_cnt[m*IDS + e_id[i]] = id_cnt[m*IDS + e_id[i]] - 1;
    e_h[m] = (e_h[m] + 1) % ED;
    e_n[m] = e_n[m] - 1;
    tot_cmp = tot_cmp + 1;
  end
endtask

// process the acceptance of the request currently presented by master m
task automatic do_accept(input int m);
  int i, w, b, k;
  logic [31:0] a;
  logic        we;
  logic [NBYTE-1:0] ws;
  logic [DW-1:0] wd, bm;
  logic [3:0] st;
  int id, src;
  a   = m_req_addr[m*32 +: 32];
  we  = m_req_we[m];
  ws  = m_req_wstrb[m*NBYTE +: NBYTE];
  wd  = m_req_wdata[m*DW +: DW];
  id  = m_req_id[m*IDW +: IDW];
  src = m_req_src[m*SRCW +: SRCW];
  st  = tb_status(m, a, we, ws, id, src, m_req_err[m]);
  if (e_n[m] >= ED) begin
    err("TB: expected queue overflow");
  end else begin
    i = m * ED + e_t[m];
    e_id[i] = id[IDW-1:0]; e_we[i] = we; e_st[i] = st; e_dat[i] = '0; e_msk[i] = '0; e_acyc[i] = cyc;
    e_fl[i] = 1'b0; e_fcyc[i] = 0; e_bank[i] = 0; e_ex[i] = (k_exact != 0) && (e_n[m] == 0);
    if (st == ST_OK) begin
      w = a >> OFFB;
      b = tb_bank_of(a);
      e_bank[i] = b;
      bank_hits[b] = bank_hits[b] + 1;
      if (MODE == 1 && BADROW >= 0 && tb_row_of(a) == BADROW) begin
        e_st[i] = ST_BANK;                  // the bank fails this access: no side effect, data 0
      end else if (we) begin
        for (k = 0; k < NBYTE; k++)
          if (ws[k]) begin mdat[w][k*8 +: 8] = wd[k*8 +: 8]; mkn[w][k] = 1'b1; end
      end else begin
        e_dat[i] = mdat[w];
        e_msk[i] = byte_mask(mkn[w]);
      end
      // shadows
      s_b_acc[b] = s_b_acc[b] + 1;
      if (we) s_b_wr[b] = s_b_wr[b] + 1; else s_b_rd[b] = s_b_rd[b] + 1;
      b_until[b] = (b_until[b] > cyc + tb_lat(b)) ? b_until[b] : cyc + tb_lat(b);
    end else begin
      n_err_cases = n_err_cases + 1;
    end
    id_cnt[m*IDS + id] = id_cnt[m*IDS + id] + 1;
    e_t[m] = (e_t[m] + 1) % ED;
    e_n[m] = e_n[m] + 1;
    tot_acc = tot_acc + 1;
  end
endtask

// ------------------------------------------------------------------ phases
function automatic bit drained();
  bit d;
  d = 1'b1;
  for (int m = 0; m < NM; m++)
    if (q_n[m] != 0 || m_req_valid[m] || e_n[m] != 0) d = 1'b0;
  drained = d;
endfunction

task automatic knobs_default();
  for (int m = 0; m < NM; m++) begin
    gen_on[m] = 1'b0; k_issue_pct[m] = 100; k_rdy_pct[m] = 100; rdy_block_until[m] = 0;
  end
  k_gap_pct = 0; k_gap_max = 0; k_rd_pct = 50; k_amode = 0; k_bank = 0; k_err_pct = 0; k_wfull_pct = 50;
  k_reset_pm = 0; k_flush_pm = 0; k_srcen_pm = 0; k_exact = 0; k_gen_n = -1; gen_left = -1;
  for (int m = 0; m < NM; m++) begin k_rdpct_m[m] = -1; k_idm[m] = 0; end
  for (int h = 0; h < NHOT; h++) hot[h] = mk_word(h % NB, rnd_below(BD));
endtask

// phase names (for the log)
function automatic string ph_name(input int p);
  case (p)
    0: ph_name = "init_sweep";
    1: ph_name = "directed_hazards";
    2: ph_name = "single_master_random";
    3: ph_name = "multi_master_random";
    4: ph_name = "all_masters_one_bank";
    5: ph_name = "independent_banks";
    6: ph_name = "random_stalls";
    7: ph_name = "simultaneous_rw";
    8: ph_name = "response_backpressure";
    9: ph_name = "invalid_requests";
    10: ph_name = "id_rules";
    11: ph_name = "source_enable";
    12: ph_name = "flush_cancel";
    13: ph_name = "hard_reset";
    14: ph_name = "reset_under_backpressure";
    15: ph_name = "soak_random";
    default: ph_name = "end";
  endcase
endfunction

task automatic ph_start(input int p);
  int m, k, w;
  knobs_default();
  ph_cyc = 0; ph_len = 0; ph_state = 0; ph_start_cyc = cyc;
  for (m = 0; m < NM; m++) begin ph_acc0[m] = 0; ph_cmp0[m] = 0; end
  for (m = 0; m < NM; m++) begin ph_acc0[m] = s_m_acc[m]; ph_cmp0[m] = s_m_cmp[m]; end
  case (p)
    0: begin   // init sweep: master 0 writes every word (full strobes), sequential => all banks, back-to-back writes
      k_amode = 4; seq_ptr[0] = 0; gen_on[0] = 1'b1; k_rd_pct = 0; k_wfull_pct = 100;
      k_gen_n = TOTAL_WORDS; gen_left = TOTAL_WORDS;
      ph_len = 100000000;
    end
    1: begin   // directed hazards, master 0, widely spaced so the exact latency can be checked first
      k_exact = 1;
      begin : dir
        logic [31:0] a0, a1;
        logic [DW-1:0] d1, d2, d3, d4;
        logic [NBYTE-1:0] fs;
        int b0;
        fs = '1;
        a0 = mk_word(0, 3) * NBYTE;
        a1 = mk_word((NB > 1) ? 1 : 0, 5) * NBYTE;
        d1 = rnd_vec(); d2 = rnd_vec(); d3 = rnd_vec(); d4 = rnd_vec();
        // isolated accesses: exact latency (gap 24 > any response time)
        qpush(0, a0, 1'b1, d1, fs, -1, 0, 1'b0, 4);
        qpush(0, a0, 1'b0, d1, fs, -1, 0, 1'b0, 24);
        qpush(0, a1, 1'b1, d2, fs, -1, 0, 1'b0, 24);
        qpush(0, a1, 1'b0, d2, fs, -1, 0, 1'b0, 24);
        qpush(0, TOTAL_BYTES, 1'b0, d2, fs, -1, 0, 1'b0, 24);       // out of range: error latency 1
        // back-to-back (gap 0): read-after-write, write-after-read, write-after-write, read-after-read
        qpush(0, a0, 1'b1, d3, fs, -1, 0, 1'b0, 24);                 // W a0 = d3
        qpush(0, a0, 1'b0, d3, fs, -1, 0, 1'b0, 0);                  // R a0 (RAW) -> d3
        qpush(0, a0, 1'b0, d3, fs, -1, 0, 1'b0, 0);                  // R a0 (RAR)
        qpush(0, a0, 1'b1, d4, fs, -1, 0, 1'b0, 0);                  // W a0 = d4 (WAR vs previous read)
        qpush(0, a0, 1'b1, d1, fs, -1, 0, 1'b0, 0);                  // W a0 = d1 (WAW)
        qpush(0, a0, 1'b0, d1, fs, -1, 0, 1'b0, 0);                  // R a0 -> d1
        // partial strobes then read
        for (k = 0; k < NBYTE; k++) begin
          qpush(0, a1, 1'b1, rnd_vec(), (1 << k), -1, 0, 1'b0, 0);   // single-lane writes
        end
        qpush(0, a1, 1'b0, d1, fs, -1, 0, 1'b0, 0);
        // back-to-back reads / writes across consecutive words (different banks with LOW interleave)
        for (k = 0; k < 2 * NB + 2; k++) qpush(0, ((mk_word(0, 8) + k) % TOTAL_WORDS) * NBYTE, 1'b1, rnd_vec(), fs, -1, 0, 1'b0, 0);
        for (k = 0; k < 2 * NB + 2; k++) qpush(0, ((mk_word(0, 8) + k) % TOTAL_WORDS) * NBYTE, 1'b0, d1, fs, -1, 0, 1'b0, 0);
      end
      ph_len = 0;
    end
    2: begin   // random, single master
      gen_on[0] = 1'b1; k_amode = 0; k_rd_pct = 55; k_wfull_pct = 40; k_gap_pct = 30; k_gap_max = 3;
      ph_len = 3000;
    end
    3: begin   // all masters, random mixed
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_issue_pct[m] = 80; k_rdy_pct[m] = 90; end
      k_amode = 0; k_rd_pct = 50; k_wfull_pct = 40; k_gap_pct = 20; k_gap_max = 2;
      ph_len = 6000;
    end
    4: begin   // all masters hammer ONE bank, saturating
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; end
      k_amode = 1; k_bank = (NB > 1) ? 1 : 0; k_rd_pct = 50; k_wfull_pct = 50;
      ph_len = 4000;
    end
    5: begin   // each master on its own bank (private), saturating
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; end
      k_amode = 2; k_rd_pct = 50; k_wfull_pct = 50;
      ph_len = 4000;
      n_par_cycles = 0;
    end
    6: begin   // random stalls: slow masters, low response-ready, gaps
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_issue_pct[m] = 35; k_rdy_pct[m] = 30 + 10 * (m % 4); end
      k_amode = 0; k_rd_pct = 50; k_gap_pct = 60; k_gap_max = 8; k_wfull_pct = 30;
      ph_len = 6000;
    end
    7: begin   // simultaneous reads and writes: even masters write, odd masters read, hot words shared
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_rdpct_m[m] = (m % 2 == 0) ? 0 : 100; end
      k_amode = 3; k_wfull_pct = 35;
      ph_len = 4000;
    end
    8: begin   // response back-pressure: master 0 does not accept responses for a long window, others run free
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; end
      rdy_block_until[0] = cyc + 600;
      k_amode = 0; k_rd_pct = 60; k_wfull_pct = 40;
      ph_len = 1500;
    end
    9: begin   // invalid requests of every kind mixed with valid traffic
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_issue_pct[m] = 70; k_rdy_pct[m] = 85; end
      k_amode = 0; k_rd_pct = 50; k_err_pct = 35; k_wfull_pct = 40;
      ph_len = 5000;
    end
    10: begin  // ID rules: random IDs, reuse attempts while outstanding, constant ID, all on a few hot words
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_issue_pct[m] = 90; k_rdy_pct[m] = 60; end
      for (m = 0; m < NM; m++) k_idm[m] = (m % 3 == 0) ? 1 : ((m % 3 == 1) ? 2 : 0);
      k_amode = 3; k_rd_pct = 50; k_err_pct = 6;
      ph_len = 4000;
    end
    11: begin  // source-enable toggling: disabled masters get SFC_ST_SRC
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_issue_pct[m] = 70; end
      k_amode = 0; k_srcen_pm = 15; k_err_pct = 10;
      ph_len = 4000;
    end
    12: begin  // flush (soft reset) in the middle of traffic
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_rdy_pct[m] = 85; end
      k_amode = 0; k_flush_pm = 8; k_rd_pct = 60; k_err_pct = 5;
      ph_len = 6000;
    end
    13: begin  // hard reset at random times
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_rdy_pct[m] = 80; end
      k_amode = 0; k_reset_pm = 6; k_rd_pct = 55; k_err_pct = 5;
      ph_len = 6000;
    end
    14: begin  // reset while responses are being held back
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_rdy_pct[m] = 10; end
      k_amode = 0; k_reset_pm = 10; k_rd_pct = 60;
      ph_len = 4000;
    end
    15: begin  // long soak, performance counters verified at the end
      for (m = 0; m < NM; m++) begin gen_on[m] = 1'b1; k_issue_pct[m] = 85; k_rdy_pct[m] = 70; end
      k_amode = 0; k_rd_pct = 50; k_wfull_pct = 40; k_gap_pct = 25; k_gap_max = 4; k_err_pct = 8;
      ph_len = NRAND;
      perf_clr <= 1'b1;
    end
    default: ;
  endcase
endtask

task automatic ph_end(input int p);
  int m, mn, mx, tot;
  $display("SRAMC_PHASE %0d %-26s cycles=%0d accepted=%0d completed=%0d errs_seen=%0d", p, ph_name(p), cyc - ph_start_cyc, tot_acc, tot_cmp, n_err_cases);
  if (p == 4 && NM > 1 && MODE == 0) begin
    // fairness with every master saturating one bank.
    //   PRIO_EN=0 : shares equal within a small bound (round robin)
    //   PRIO_EN=1 : equal inside each class, and the LOW class keeps at least 1/(HP_LIMIT+1) of all grants
    //               (starvation guard) -- never zero
    int tot_all, tot_lp, mnl, mxl, mnh, mxh, nh, nl, share;
    mnl = 1 << 30; mxl = 0; mnh = 1 << 30; mxh = 0; tot_all = 0; tot_lp = 0; nh = 0; nl = 0;
    for (m = 0; m < NM; m++) begin
      share = s_m_acc[m] - ph_acc0[m];
      tot_all = tot_all + share;
      tb_check(share > 0, $sformatf("fairness: master %0d was starved in the one-bank phase", m));
      if (PRIO != 0 && HPM[m]) begin
        nh = nh + 1; if (share < mnh) mnh = share; if (share > mxh) mxh = share;
      end else begin
        nl = nl + 1; tot_lp = tot_lp + share; if (share < mnl) mnl = share; if (share > mxl) mxl = share;
      end
    end
    if (nl > 0) tb_check((mxl - mnl) <= (2 * MAXOUT + 2), $sformatf("fairness: unequal shares inside the LOW class min %0d max %0d", mnl, mxl));
    if (nh > 1) tb_check((mxh - mnh) <= (2 * MAXOUT + 2), $sformatf("fairness: unequal shares inside the HIGH class min %0d max %0d", mnh, mxh));
    if (PRIO != 0 && nh > 0 && nl > 0)
      tb_check(tot_lp * (HPL + 1) + NM * (MAXOUT + 2) * (HPL + 1) >= tot_all, $sformatf("priority: LOW class got %0d of %0d (< 1/(HP_LIMIT+1))", tot_lp, tot_all));
    $display("SRAMC_INFO fairness one-bank: per-master accepted min=%0d max=%0d (LOW class min=%0d max=%0d, LOW total %0d of %0d)", (nh > 0 && mnh < mnl) ? mnh : mnl, (mxh > mxl) ? mxh : mxl, mnl, mxl, tot_lp, tot_all);
  end
  if (p == 5 && NM > 1 && NB > 1) begin
    tb_check(n_par_cycles > 0, "independent banks: no cycle with two simultaneous bank accesses");
    $display("SRAMC_INFO independent banks: cycles with >=2 simultaneous bank accesses = %0d", n_par_cycles);
  end
  if (p == 8 && NM > 1) begin
    for (m = 1; m < NM; m++) begin
      tb_check((s_m_cmp[m] - ph_cmp0[m]) > 100, $sformatf("isolation: master %0d only completed %0d while master 0 held its responses", m, s_m_cmp[m] - ph_cmp0[m]));
    end
  end
  tb_check(sts_rsp_overflow === 1'b0, "sticky: response overflow");
  tb_check(sts_bank_proto === 1'b0, "sticky: bank protocol error");
endtask

// ------------------------------------------------------------------ the cycle engine
bit   trace_on;
bit   xfer [NM];
bit   acc  [NM];
int   nacc_bank, bank_cnt [NB];
logic [NM-1:0]             nx_valid, nx_we, nx_err, nx_rdy;
logic [NM*32-1:0]          nx_addr;
logic [NM*DW-1:0]          nx_wd;
logic [NM*NBYTE-1:0]       nx_ws;
logic [NM*IDW-1:0]         nx_id;
logic [NM*SRCW-1:0]        nx_src;
logic [NM-1:0]             nx_srcen;
bit   nx_flush;
bit   reset_event;
int   o_tot, found, tries, nid, k2;
logic [127:0] rv_tmp;
logic [31:0]  r32_tmp;
bit   rb_tmp;

// shadow value of counter `idx`, as the counter must read in the CURRENT cycle (events of earlier cycles only)
function automatic longint pv_shadow(input int idx);
  longint v;
  int m, b, k;
  v = 0; pv_known = 1'b1;
  if (idx < 16) begin
    case (idx)
      0:  v = s_cycles;
      1:  v = s_busy;
      2:  v = s_acc;
      3:  v = s_cmp;
      4:  v = s_rd;
      5:  v = s_wr;
      6:  v = s_err;
      9:  v = s_cancel;
      10: v = s_outmax;
      11: v = s_rstall;
      12: v = s_wait;
      default: pv_known = 1'b0;     // conflict / order-stall counters observe internal arbitration: sanity only
    endcase
  end else if (idx < 16 + 16 * NM) begin
    m = (idx - 16) / 16; k = (idx - 16) % 16;
    case (k)
      0: v = s_m_acc[m];
      1: v = s_m_cmp[m];
      2: v = s_m_rd[m];
      3: v = s_m_wr[m];
      4: v = s_m_err[m];
      5: v = s_m_wait[m];
      6: v = s_m_waitmax[m];
      7: v = s_m_lat[m];
      8: v = s_m_outmax[m];
      9: v = s_m_rstall[m];
      11: v = s_m_cancel[m];
      default: pv_known = 1'b0;
    endcase
  end else begin
    b = (idx - 16 - 16 * NM) / 8; k = (idx - 16 - 16 * NM) % 8;
    case (k)
      0: v = s_b_acc[b];
      1: v = s_b_rd[b];
      2: v = s_b_wr[b];
      3: begin v = s_b_busy[b]; if (MODE != 0) pv_known = 1'b0; end
      default: pv_known = 1'b0;
    endcase
  end
  pv_shadow = v;
endfunction

initial begin
  tb_seed_init();
  trace_on = $test$plusargs("trace");
  rst_n = 1'b0; flush = 1'b0; perf_clr = 1'b0; perf_sel = '0;
  m_req_valid = '0; m_req_we = '0; m_req_addr = '0; m_req_wdata = '0; m_req_wstrb = '0; m_req_id = '0; m_req_src = '0; m_req_err = '0;
  m_rsp_ready = '0; src_en = '1;
  cyc = 0; rst_cnt = 6; phase = -1; tot_acc = 0; tot_cmp = 0; tot_rstcancel = 0; n_err_cases = 0; n_par_cycles = 0; done_flag = 1'b0;
  flush_cnt = 0; flush_len = 0; pv_state = 0; pv_idx = 0; pv_cnt = 0;
  for (int w = 0; w < TOTAL_WORDS; w++) begin mdat[w] = '0; mkn[w] = '0; end
  for (int m = 0; m < NM; m++) begin seq_ptr[m] = 0; next_id_ctr[m] = 0; prev_rv[m] = 1'b0; prev_rr[m] = 1'b1; prev_pl[m] = '0; id_blocked[m] = 1'b0; end
  for (int b = 0; b < NB; b++) bank_hits[b] = 0;
  for (int k = 0; k < 16; k++) cov_st[k] = 0;
  cov_conf = 0; cov_ost = 0;
  reset_model_state();
  shadows_clear(1'b0);
  knobs_default();
end

always @(posedge clk) begin : engine
  int m, b, i;
  bit any_out;
  logic [3:0] stx;
  cyc = cyc + 1;
  if (trace_on && (cyc % 50) == 0 || (trace_on && cyc < 12)) $display("SRAMC_TRACE cyc=%0d phase=%0d acc=%0d cmp=%0d rng=%h", cyc, phase, tot_acc, tot_cmp, tb_rng_state);
  nacc_bank = 0;
  for (b = 0; b < NB; b++) bank_cnt[b] = 0;

  if (!rst_n) begin
    // ---------------- in reset: nothing may be accepted or answered (SFB2 R11)
    if (cyc > 3) begin
      tb_check(m_req_ready === '0, "reset: req_ready must be 0 while rst_n=0");
      tb_check(m_rsp_valid === '0, "reset: rsp_valid must be 0 while rst_n=0");
    end
    if (rst_cnt > 0) rst_cnt = rst_cnt - 1;
    if (rst_cnt == 0) begin
      rst_n <= 1'b1;
      if (phase < 0) begin
        phase = 0;
        ph_start(0);
      end
    end
    // masters keep presenting a request through reset (it is simply not accepted until reset is released)
    m_rsp_ready <= '0;
    flush       <= 1'b0;
    for (m = 0; m < NM; m++) begin prev_rv[m] = 1'b0; prev_rr[m] = 1'b1; end
  end else begin
    // ---------------- performance-counter read-out (final): the select was driven in the previous cycle
    if (pv_state == 2) begin
      pv_exp = pv_shadow(pv_idx);
      if (pv_idx == 7) cov_conf = perf_val;
      if (pv_idx == 8) cov_ost = perf_val;
      if (pv_known) tb_check(perf_val == CNT_W'(pv_exp), $sformatf("perf[%0d] exp %0d got %0d", pv_idx, pv_exp, perf_val));
      pv_idx = pv_idx + 1;
      if (pv_idx >= NPERF) pv_state = 3;
      else perf_sel <= PSW'(pv_idx);
    end

    // ---------------- sample the cycle that just ended
    any_out = 1'b0;
    o_tot = 0;
    for (m = 0; m < NM; m++) begin
      if (e_n[m] != 0) any_out = 1'b1;
      o_tot = o_tot + e_n[m];
    end
    tb_check(idle === !any_out, $sformatf("idle=%0b but outstanding=%0b", idle, any_out));
    // shadows that use the state of the ended cycle
    s_cycles = s_cycles + 1;
    if (any_out) s_busy = s_busy + 1;
    if (o_tot > s_outmax) s_outmax = o_tot;
    for (m = 0; m < NM; m++) begin
      s_m_lat[m] = s_m_lat[m] + e_n[m];
      if (e_n[m] > s_m_outmax[m]) s_m_outmax[m] = e_n[m];
      if (m_req_valid[m] && !m_req_ready[m]) begin
        s_m_wait[m] = s_m_wait[m] + 1; s_wait = s_wait + 1;
        s_m_run[m] = s_m_run[m] + 1;
        if (s_m_run[m] > s_m_waitmax[m]) s_m_waitmax[m] = s_m_run[m];
      end else s_m_run[m] = 0;
      if (m_rsp_valid[m] && !m_rsp_ready[m]) begin s_m_rstall[m] = s_m_rstall[m] + 1; s_rstall = s_rstall + 1; end
    end
    for (b = 0; b < NB; b++) if (cyc <= b_until[b]) s_b_busy[b] = s_b_busy[b] + 1;

    // protocol monitors
    for (m = 0; m < NM; m++) begin
      tb_check(!(m_rsp_valid[m] && e_n[m] == 0), $sformatf("m%0d: rsp_valid with nothing outstanding", m));
      tb_check(e_n[m] <= MAXOUT, $sformatf("m%0d: more than MAX_OUT outstanding (%0d)", m, e_n[m]));
      // R4: a response that was not taken stays, unchanged
      if (prev_rv[m] && !prev_rr[m]) begin
        tb_check(m_rsp_valid[m] === 1'b1, $sformatf("m%0d: response withdrawn before it was accepted", m));
        tb_check(prev_pl[m] == {m_rsp_rdata[m*DW +: DW], m_rsp_id[m*IDW +: IDW], m_rsp_we[m], m_rsp_status[m*4 +: 4], 4'b0},
                 $sformatf("m%0d: response payload changed under back-pressure", m));
      end
      prev_rv[m] = m_rsp_valid[m];
      prev_rr[m] = m_rsp_ready[m];
      prev_pl[m] = {m_rsp_rdata[m*DW +: DW], m_rsp_id[m*IDW +: IDW], m_rsp_we[m], m_rsp_status[m*4 +: 4], 4'b0};
    end

    // flush bookkeeping: entries accepted before this cycle are marked with the first flush cycle
    if (flush) begin
      for (m = 0; m < NM; m++)
        for (i = 0; i < e_n[m]; i++)
          if (!e_fl[m*ED + ((e_h[m] + i) % ED)]) begin
            e_fl[m*ED + ((e_h[m] + i) % ED)] = 1'b1;
            e_fcyc[m*ED + ((e_h[m] + i) % ED)] = cyc;
          end
      for (m = 0; m < NM; m++)
        tb_check(!(m_req_valid[m] && m_req_ready[m]), $sformatf("m%0d: request accepted during flush", m));
    end

    // response transfers first (they free ID slots), then acceptances
    for (m = 0; m < NM; m++) begin
      xfer[m] = m_rsp_valid[m] && m_rsp_ready[m];
      acc[m]  = m_req_valid[m] && m_req_ready[m];
    end
    for (m = 0; m < NM; m++) begin
      if (xfer[m]) begin
        stx = m_rsp_status[m*4 +: 4];
        s_cmp = s_cmp + 1; s_m_cmp[m] = s_m_cmp[m] + 1;
        if (stx != ST_OK) begin s_err = s_err + 1; s_m_err[m] = s_m_err[m] + 1; end
        else if (m_rsp_we[m]) begin s_wr = s_wr + 1; s_m_wr[m] = s_m_wr[m] + 1; end
        else begin s_rd = s_rd + 1; s_m_rd[m] = s_m_rd[m] + 1; end
        if (stx == ST_CANCEL) begin s_cancel = s_cancel + 1; s_m_cancel[m] = s_m_cancel[m] + 1; end
        check_response(m);
      end
    end
    for (m = 0; m < NM; m++) begin
      if (acc[m]) begin
        s_acc = s_acc + 1; s_m_acc[m] = s_m_acc[m] + 1;
        // no bank double-booking: at most one accepted bank access per bank per cycle
        if (tb_status(m, m_req_addr[m*32 +: 32], m_req_we[m], m_req_wstrb[m*NBYTE +: NBYTE], m_req_id[m*IDW +: IDW], m_req_src[m*SRCW +: SRCW], m_req_err[m]) == ST_OK) begin
          bank_cnt[tb_bank_of(m_req_addr[m*32 +: 32])] = bank_cnt[tb_bank_of(m_req_addr[m*32 +: 32])] + 1;
          nacc_bank = nacc_bank + 1;
        end
        do_accept(m);
      end
    end
    for (b = 0; b < NB; b++) tb_check(bank_cnt[b] <= 1, $sformatf("bank %0d consumed by %0d masters in one cycle", b, bank_cnt[b]));
    if (nacc_bank >= 2) n_par_cycles = n_par_cycles + 1;
    // a counter clear that was driven in the cycle that just ended wipes this cycle's events (the DUT clears at this edge)
    if (perf_clr) shadows_clear(1'b1);
    perf_clr <= 1'b0;

    // ---------------- phase control
    if (phase >= 0 && phase < NPH) begin
      ph_cyc = ph_cyc + 1;
      if (ph_state == 0 && (ph_cyc >= ph_len || (k_gen_n >= 0 && gen_left == 0))) begin
        for (m = 0; m < NM; m++) gen_on[m] = 1'b0;
        k_reset_pm = 0; k_flush_pm = 0; k_srcen_pm = 0;
        ph_state = 1;
      end
      if (ph_state == 1) begin
        for (m = 0; m < NM; m++) rdy_block_until[m] = 0;
        if (drained() && !flush && rst_n) begin
          ph_end(phase);
          phase = phase + 1;
          if (phase >= NPH) begin pv_state = 1; pv_idx = 0; end
          else ph_start(phase);
        end else if (ph_cyc > ph_len + 40000 && ph_len < 100000) begin
          err($sformatf("phase %0d: drain timeout (e_n[0]=%0d q_n[0]=%0d)", phase, e_n[0], q_n[0]));
          phase = NPH; pv_state = 3;
        end else if (ph_cyc > 600000) begin
          err($sformatf("phase %0d: drain timeout (e_n[0]=%0d q_n[0]=%0d)", phase, e_n[0], q_n[0]));
          phase = NPH; pv_state = 3;
        end
      end
    end

    // ---------------- generate stimulus
    for (m = 0; m < NM; m++)
      if (gen_on[m] && q_n[m] < 2 && (k_gen_n < 0 || gen_left > 0)) begin
        rb_tmp = rnd_pct(k_issue_pct[m]);
        if (rb_tmp) gen_req(m);
      end

    // ---------------- drive the next cycle: request channel
    nx_valid = m_req_valid; nx_we = m_req_we; nx_err = m_req_err; nx_addr = m_req_addr; nx_wd = m_req_wdata;
    nx_ws = m_req_wstrb; nx_id = m_req_id; nx_src = m_req_src;
    for (m = 0; m < NM; m++) begin
      if (m_req_valid[m] && !m_req_ready[m]) begin
        // hold: SFB2 R2 -- unchanged until accepted
      end else begin
        nx_valid[m] = 1'b0;
        if (q_n[m] > 0) begin
          i = m * QD + q_h[m];
          if (!head_wait[m]) begin head_wait[m] = 1'b1; hold_cnt[m] = q_gap[i]; end
          if (hold_cnt[m] > 0) hold_cnt[m] = hold_cnt[m] - 1;
          else begin
            // choose the ID at presentation
            nid = q_id[i];
            if (nid < 0) begin
              if (k_idm[m] == 1) nid = rnd_below(IDS);
              else begin
                // an ID that is not outstanding
                found = 0; tries = 0; nid = rnd_below(IDS);
                while (!found && tries < IDS) begin
                  if (id_cnt[m*IDS + nid] == 0) found = 1;
                  else begin nid = (nid + 1) % IDS; tries = tries + 1; end
                end
                if (!found) nid = -2;
              end
            end
            if (nid != -2) begin
              nx_valid[m] = 1'b1;
              nx_we[m] = q_we[i]; nx_err[m] = q_err[i];
              nx_addr[m*32 +: 32] = q_addr[i];
              if (q_we[i]) begin
                nx_wd[m*DW +: DW] = q_wd[i];
                nx_ws[m*NBYTE +: NBYTE] = q_ws[i];
              end else begin                                          // read: wdata/wstrb are don't-care (noise)
                rv_tmp = rnd_vec();
                nx_wd[m*DW +: DW] = rv_tmp[DW-1:0];
                r32_tmp = rnd32();
                nx_ws[m*NBYTE +: NBYTE] = r32_tmp[NBYTE-1:0];
              end
              nx_id[m*IDW +: IDW] = nid[IDW-1:0];
              nx_src[m*SRCW +: SRCW] = SRCW'(q_src[i]);
              q_h[m] = (q_h[m] + 1) % QD; q_n[m] = q_n[m] - 1; head_wait[m] = 1'b0;
            end
          end
        end
      end
    end
    // response-ready
    for (m = 0; m < NM; m++) begin
      if (cyc < rdy_block_until[m]) nx_rdy[m] = 1'b0;
      else begin
        rb_tmp = rnd_pct(k_rdy_pct[m]);
        nx_rdy[m] = rb_tmp;
      end
    end
    // source enables
    nx_srcen = src_en;
    if (k_srcen_pm != 0) begin
      for (m = 0; m < NM; m++) begin
        k2 = rnd_below(1000);
        if (k2 < k_srcen_pm * 4) nx_srcen[m] = ~src_en[m];
      end
    end else nx_srcen = '1;
    // flush
    nx_flush = flush;
    if (flush_len > 0) begin
      flush_len = flush_len - 1;
      if (flush_len == 0) nx_flush = 1'b0;
    end else if (k_flush_pm != 0 && !flush) begin
      k2 = rnd_below(1000);
      if (k2 < k_flush_pm) begin
        nx_flush = 1'b1; flush_len = 1 + rnd_below(6);
      end
    end
    // hard reset
    reset_event = 1'b0;
    if (k_reset_pm != 0) begin
      k2 = rnd_below(1000);
      reset_event = (k2 < k_reset_pm);
    end
    if (reset_event) begin
      // everything in flight is cancelled silently (SFB2 R11); the memory array survives
      k2 = rnd_below(3);
      rst_n <= 1'b0; rst_cnt = 1 + k2;
      for (m = 0; m < NM; m++) tot_rstcancel = tot_rstcancel + e_n[m];
      reset_model_state();
      nx_flush = 1'b0; flush_len = 0;
      for (m = 0; m < NM; m++) begin prev_rv[m] = 1'b0; prev_rr[m] = 1'b1; end
      shadows_clear(1'b0);
    end

    m_req_valid <= nx_valid; m_req_we <= nx_we; m_req_err <= nx_err; m_req_addr <= nx_addr; m_req_wdata <= nx_wd;
    m_req_wstrb <= nx_ws; m_req_id <= nx_id; m_req_src <= nx_src;
    m_rsp_ready <= nx_rdy;
    src_en <= nx_srcen;
    flush <= nx_flush;

    if (pv_state == 1) begin
      perf_sel <= PSW'(pv_idx);
      pv_state = 2;
    end else if (pv_state == 3) begin
      if (!done_flag) begin
        done_flag = 1'b1;
        $display("SRAMC_INFO total accepted=%0d completed=%0d cancelled-by-reset=%0d error-cases=%0d parallel-bank-cycles=%0d", tot_acc, tot_cmp, tot_rstcancel, n_err_cases, n_par_cycles);
        $display("SRAMC_COV bank=%0d ok=%0d range=%0d align=%0d mask=%0d src=%0d idreuse=%0d poison=%0d cancel=%0d conflicts=%0d order_stalls=%0d rsp_stall_cycles=%0d max_outstanding=%0d",
                 cov_st[8], cov_st[0], cov_st[1], cov_st[2], cov_st[3], cov_st[4], cov_st[5], cov_st[6], cov_st[7], cov_conf, cov_ost, s_rstall, s_outmax);
        tb_check(tot_acc == tot_cmp + tot_rstcancel, "accepted != completed + cancelled-by-reset at end (a transaction was lost or duplicated)");
        tb_finish(TBNAME);
      end
    end
  end
end

// timeout guard
initial begin
  #(400000000);
  $display("SRAMC_ERROR global timeout");
  tb_errors++;
  tb_finish(TBNAME);
end
