// =============================================================================
// SilicaFlux SRAMController :: tb_sramc_var   (self-checking)
// sf_sram_controller + randomised bank models (variable latency BMIN..BMAX, random
// bank-busy).  Proves the controller against the BANK CONTRACT rather than against one
// particular memory: completions across banks arrive in arbitrary order.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sramc_var;
  parameter int          NM     = 4;
  parameter int          NB     = 4;
  parameter int          DW     = 32;
  parameter int          BD     = 64;
  parameter int          IDW    = 4;
  parameter int          MAXOUT = 1;
  parameter int          ILV    = 0;
  parameter int          IDCHK  = 1;
  parameter int          SRCCHK = 1;
  parameter int          MASKM  = 0;
  parameter int          PRIO   = 0;
  parameter logic [15:0] HPM    = 16'h0001;
  parameter int          HPL    = 4;
  parameter int          BMIN   = 1;
  parameter int          BMAX   = 6;
  parameter int          BRDY   = 75;
  parameter int          BOUT   = 8;
  parameter int          BADROW = -1;        // >= 0: bank row that always fails (exercises SFC_ST_BANK)
  parameter logic [63:0] LATS   = 64'h0;      // unused here (kept so both wrappers take the same -G set)
  parameter int          NRAND  = 12000;
  localparam int MODE   = 1;
  localparam int CNT_W  = 32;
  localparam int NBYTE_ = DW / 8;
  localparam int SRCW_  = (NM > 1) ? $clog2(NM) : 1;
  localparam int RAW    = (BD > 1) ? $clog2(BD) : 1;
  localparam int PSW    = $clog2(16 + 16 * NM + 8 * NB);
  localparam string TBNAME = "tb_sramc_var";

  logic                    clk;
  logic                    rst_n;
  logic [NM-1:0]           m_req_valid, m_req_we, m_req_err, m_rsp_ready, src_en;
  logic [NM-1:0]           m_req_ready, m_rsp_valid, m_rsp_we, m_rsp_err;
  logic [NM*32-1:0]        m_req_addr;
  logic [NM*DW-1:0]        m_req_wdata, m_rsp_rdata;
  logic [NM*NBYTE_-1:0]    m_req_wstrb;
  logic [NM*IDW-1:0]       m_req_id, m_rsp_id;
  logic [NM*SRCW_-1:0]     m_req_src, m_rsp_src;
  logic [NM*4-1:0]         m_rsp_status;
  logic                    flush, idle, sts_rsp_overflow, sts_bank_proto, perf_clr;
  logic [PSW-1:0]          perf_sel;
  logic [CNT_W-1:0]        perf_val;

  logic [NB-1:0]            bk_req_valid, bk_req_ready, bk_req_we, bk_rsp_valid, bk_rsp_err;
  logic [NB*RAW-1:0]        bk_req_addr;
  logic [NB*DW-1:0]         bk_req_wdata, bk_rsp_rdata;
  logic [NB*NBYTE_-1:0]     bk_req_wstrb;

  sf_sram_controller #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .BANK_DEPTH(BD), .ADDR_WIDTH(32), .ID_WIDTH(IDW),
    .MAX_OUT(MAXOUT), .BANK_OUT(BOUT), .INTERLEAVE(ILV), .ID_CHECK(IDCHK), .SRC_CHECK(SRCCHK), .MASK_MODE(MASKM),
    .PRIO_EN(PRIO), .HP_MASK(HPM), .HP_LIMIT(HPL), .PERF_EN(1), .CNT_W(CNT_W)
  ) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb, .m_req_id, .m_req_src, .m_req_err,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_id, .m_rsp_src, .m_rsp_we, .m_rsp_err, .m_rsp_status,
    .src_en, .flush, .idle, .sts_rsp_overflow, .sts_bank_proto,
    .bk_req_valid, .bk_req_ready, .bk_req_we, .bk_req_addr, .bk_req_wdata, .bk_req_wstrb,
    .bk_rsp_valid, .bk_rsp_rdata, .bk_rsp_err,
    .perf_clr, .perf_sel, .perf_val
  );

  for (genvar b = 0; b < NB; b++) begin : g_bank
    sf_sramc_bankmodel #(.DW(DW), .DEPTH(BD), .LMIN(BMIN), .LMAX(BMAX), .RDY_PCT(BRDY), .SEED(b + 1), .BADROW(BADROW)) u_bank (
      .clk(clk), .rst_n(rst_n),
      .req_valid(bk_req_valid[b]), .req_ready(bk_req_ready[b]), .req_we(bk_req_we[b]),
      .req_addr(bk_req_addr[b*RAW +: RAW]), .req_wdata(bk_req_wdata[b*DW +: DW]), .req_wstrb(bk_req_wstrb[b*NBYTE_ +: NBYTE_]),
      .rsp_valid(bk_rsp_valid[b]), .rsp_rdata(bk_rsp_rdata[b*DW +: DW]), .rsp_err(bk_rsp_err[b])
    );
  end

  initial $display("SRAMC_INFO uniform_lat=%0d", 0);

  `include "sramc_tb_body.svh"
endmodule

`default_nettype wire
