// =============================================================================
// SilicaFlux SRAMController :: tb_sramc_perf   (performance benchmark, no scoreboard)
// Saturating masters on controller + sf_sram_core banks; the figures are READ FROM THE CONTROLLER'S OWN HARDWARE
// COUNTERS (the counters themselves are proven exact against an independent shadow in tb_sramc_*).
//   +pattern=<n>  0 one master, one bank        1 one master, sequential words (banks rotate)
//                 2 all masters, ONE bank       3 masters on PRIVATE banks      4 random reads/writes, all masters
//                 5 sequential streams          6 private-bank writes           7 private banks, response-ready 50 %
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_sramc_perf;
  parameter int          NM     = 4;
  parameter int          NB     = 4;
  parameter int          DW     = 32;
  parameter int          BD     = 64;
  parameter int          MAXOUT = 1;
  parameter int          PRIO   = 0;
  parameter logic [15:0] HPM    = 16'h0001;
  parameter logic [63:0] LATS   = 64'h1111_1111_1111_1111;
  parameter int          NCYC   = 20000;
  parameter int          UNI    = -1;       // UNIFORM_LAT: -1 automatic, 0 force the bank-lock rule
  localparam int IDW   = 4;
  localparam int NBYTE = DW / 8;
  localparam int SRCW  = (NM > 1) ? $clog2(NM) : 1;
  localparam int NPERF = 16 + 16 * NM + 8 * NB;
  localparam int PSW   = $clog2(NPERF);

  logic clk = 1'b0; always #5 clk = ~clk;
  logic rst_n = 1'b0;
  logic [NM-1:0] m_req_valid = '0, m_req_we = '0, m_rsp_ready = '1, m_req_ready, m_rsp_valid, m_rsp_we, m_rsp_err;
  logic [NM*32-1:0] m_req_addr = '0;
  logic [NM*DW-1:0] m_req_wdata = '0, m_rsp_rdata;
  logic [NM*NBYTE-1:0] m_req_wstrb = '1;
  logic [NM*IDW-1:0] m_req_id = '0, m_rsp_id;
  logic [NM*SRCW-1:0] m_req_src, m_rsp_src;
  logic [NM*4-1:0] m_rsp_status;
  logic idle, ovf, proto, perf_clr = 1'b0;
  logic [PSW-1:0] perf_sel = '0;
  logic [31:0] perf_val;

  for (genvar m = 0; m < NM; m++) begin : g_src
    assign m_req_src[m*SRCW +: SRCW] = SRCW'(m);
  end

  sf_sram_subsystem #(.NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .BANK_DEPTH(BD), .ID_WIDTH(IDW), .MAX_OUT(MAXOUT),
                      .PRIO_EN(PRIO), .HP_MASK(HPM), .BANK_LATS(LATS), .UNIFORM_LAT(UNI), .INIT_MODE(1)) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb, .m_req_id, .m_req_src, .m_req_err('0),
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_id, .m_rsp_src, .m_rsp_we, .m_rsp_err, .m_rsp_status,
    .src_en('1), .flush(1'b0), .idle, .sts_rsp_overflow(ovf), .sts_bank_proto(proto), .perf_clr, .perf_sel, .perf_val
  );

  int pattern, cyc = 0, rst_cnt = 5;
  int seqp [NM];
  logic [31:0] x = 32'h1357_9BDF;
  logic [3:0] idc [NM];
  function automatic logic [31:0] rnd();
    x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rnd = x;
  endfunction
  function automatic int word_of(input int m, input int k);   // word index for master m, access k
    int row;
    logic [31:0] r_loc;
    case (pattern)
      0: word_of = 0 + (k % BD) * NB;                      // bank 0 only
      1: word_of = k % (NB * BD);                           // sequential
      2: word_of = ((m * 3 + k) % BD) * NB;                  // all in bank 0, different rows
      3, 6, 7: word_of = (k % BD) * NB + (m % NB);           // private bank m
      4: begin r_loc = rnd(); row = r_loc % (NB * BD); word_of = row; end
      default: word_of = (m * 17 + k) % (NB * BD);          // sequential streams, different offsets
    endcase
  endfunction

  int ctr [NM];
  int ri = 0;
  logic [31:0] r0, r1;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (rst_cnt > 0) begin rst_cnt <= rst_cnt - 1; if (rst_cnt == 1) rst_n <= 1'b1; end
    else if (cyc < NCYC + 20) begin
      for (int m = 0; m < NM; m++) begin
        bit active, acc, hold;
        active = (pattern == 0 || pattern == 1) ? (m == 0) : 1'b1;
        acc  = m_req_valid[m] && m_req_ready[m];
        hold = m_req_valid[m] && !m_req_ready[m];
        if (acc) begin ctr[m] = ctr[m] + 1; idc[m] = idc[m] + 1'b1; end
        if (!hold) begin
          if (active && cyc < NCYC) begin
            r0 = rnd(); r1 = rnd();
            m_req_valid[m] <= 1'b1;
            m_req_we[m] <= (pattern == 6) ? 1'b1 : ((pattern == 4) ? r0[0] : 1'b0);
            m_req_addr[m*32 +: 32] <= 32'(word_of(m, ctr[m]) * NBYTE);
            m_req_wdata[m*DW +: DW] <= {DW{1'b0}} | r1;
            m_req_id[m*IDW +: IDW] <= idc[m];
          end else m_req_valid[m] <= 1'b0;
        end
        if (pattern == 7) begin r0 = rnd(); m_rsp_ready[m] <= r0[3]; end
        else m_rsp_ready[m] <= 1'b1;
      end
    end
    // read out all counters after the run (perf_sel set in the previous cycle selects the value seen now)
    if (cyc == NCYC + 30) begin perf_sel <= '0; ri = 0; end
    if (cyc > NCYC + 30 && ri < NPERF) begin
      $display("PERF %0d %0d", ri, perf_val);
      ri = ri + 1;
      perf_sel <= PSW'(ri);
    end
    if (ri >= NPERF && cyc > NCYC + 30) begin
      $display("PERFDONE ovf=%0b proto=%0b", ovf, proto);
      $finish;
    end
  end
  initial begin
    if (!$value$plusargs("pattern=%d", pattern)) pattern = 3;
    for (int m = 0; m < NM; m++) begin ctr[m] = 0; idc[m] = '0; seqp[m] = 0; end
  end
endmodule
`default_nettype wire
