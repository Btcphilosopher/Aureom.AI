// =============================================================================
// SilicaFlux SRAMController :: tb_sramc_gls   (gate-level lockstep equivalence)
// The RTL controller and the Yosys-synthesised gate netlist of the SAME configuration (module renamed
// sf_sram_controller_gl) are driven by identical random inputs -- masters (hold-until-accept), response-ready,
// flush, source enables, hard resets, performance-counter selects -- and a shared randomised bank model that is
// driven by the RTL's bank outputs.  Every output of the two is compared every cycle (payloads only while their
// valid is high: unreset storage legitimately differs).  Any difference fails.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sramc_gls;
  parameter int          NM     = 4;
  parameter int          NB     = 4;
  parameter int          DW     = 32;
  parameter int          BD     = 64;
  parameter int          IDW    = 4;
  parameter int          MAXOUT = 2;
  parameter int          BOUT   = 4;
  parameter int          ILV    = 0;
  parameter int          IDCHK  = 1;
  parameter int          SRCCHK = 1;
  parameter int          MASKM  = 0;
  parameter int          PRIO   = 0;
  parameter logic [15:0] HPM    = 16'h0001;
  parameter int          HPL    = 4;
  parameter int          PERF   = 1;
  parameter int          NCYC   = 60000;
  localparam int NBYTE = DW / 8;
  localparam int SRCW  = (NM > 1) ? $clog2(NM) : 1;
  localparam int RAW   = (BD > 1) ? $clog2(BD) : 1;
  localparam int NPERF = 16 + 16 * NM + 8 * NB;
  localparam int PSW   = $clog2(NPERF);
  localparam int TOTAL_BYTES = NB * BD * NBYTE;

  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n = 1'b0;

  logic [NM-1:0]          m_req_valid = '0, m_req_we = '0, m_req_err = '0, m_rsp_ready = '0, src_en = '1;
  logic [NM*32-1:0]       m_req_addr = '0;
  logic [NM*DW-1:0]       m_req_wdata = '0;
  logic [NM*NBYTE-1:0]    m_req_wstrb = '0;
  logic [NM*IDW-1:0]      m_req_id = '0;
  logic [NM*SRCW-1:0]     m_req_src = '0;
  logic                   flush = 1'b0, perf_clr = 1'b0;
  logic [PSW-1:0]         perf_sel = '0;

  // shared bank side
  logic [NB-1:0]          bk_rsp_valid, bk_rsp_err, bk_req_ready;
  logic [NB*DW-1:0]       bk_rsp_rdata;

  // ---- RTL
  logic [NM-1:0] r_req_ready, r_rsp_valid, r_rsp_we, r_rsp_err;
  logic [NM*DW-1:0] r_rsp_rdata; logic [NM*IDW-1:0] r_rsp_id; logic [NM*SRCW-1:0] r_rsp_src; logic [NM*4-1:0] r_rsp_status;
  logic r_idle, r_ovf, r_proto; logic [31:0] r_perf;
  logic [NB-1:0] r_bk_valid, r_bk_we; logic [NB*RAW-1:0] r_bk_addr; logic [NB*DW-1:0] r_bk_wdata; logic [NB*NBYTE-1:0] r_bk_wstrb;
  // ---- gate level
  logic [NM-1:0] g_req_ready, g_rsp_valid, g_rsp_we, g_rsp_err;
  logic [NM*DW-1:0] g_rsp_rdata; logic [NM*IDW-1:0] g_rsp_id; logic [NM*SRCW-1:0] g_rsp_src; logic [NM*4-1:0] g_rsp_status;
  logic g_idle, g_ovf, g_proto; logic [31:0] g_perf;
  logic [NB-1:0] g_bk_valid, g_bk_we; logic [NB*RAW-1:0] g_bk_addr; logic [NB*DW-1:0] g_bk_wdata; logic [NB*NBYTE-1:0] g_bk_wstrb;

  sf_sram_controller #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .BANK_DEPTH(BD), .ADDR_WIDTH(32), .ID_WIDTH(IDW), .MAX_OUT(MAXOUT),
    .BANK_OUT(BOUT), .INTERLEAVE(ILV), .ID_CHECK(IDCHK), .SRC_CHECK(SRCCHK), .MASK_MODE(MASKM), .PRIO_EN(PRIO), .HP_MASK(HPM),
    .HP_LIMIT(HPL), .PERF_EN(PERF), .CNT_W(32)
  ) rtl (
    .clk, .rst_n, .m_req_valid, .m_req_ready(r_req_ready), .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb, .m_req_id, .m_req_src, .m_req_err,
    .m_rsp_valid(r_rsp_valid), .m_rsp_ready, .m_rsp_rdata(r_rsp_rdata), .m_rsp_id(r_rsp_id), .m_rsp_src(r_rsp_src), .m_rsp_we(r_rsp_we),
    .m_rsp_err(r_rsp_err), .m_rsp_status(r_rsp_status), .src_en, .flush, .idle(r_idle), .sts_rsp_overflow(r_ovf), .sts_bank_proto(r_proto),
    .bk_req_valid(r_bk_valid), .bk_req_ready, .bk_req_we(r_bk_we), .bk_req_addr(r_bk_addr), .bk_req_wdata(r_bk_wdata), .bk_req_wstrb(r_bk_wstrb),
    .bk_rsp_valid, .bk_rsp_rdata, .bk_rsp_err, .perf_clr, .perf_sel, .perf_val(r_perf)
  );

  sf_sram_controller_gl gl (
    .clk, .rst_n, .m_req_valid, .m_req_ready(g_req_ready), .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb, .m_req_id, .m_req_src, .m_req_err,
    .m_rsp_valid(g_rsp_valid), .m_rsp_ready, .m_rsp_rdata(g_rsp_rdata), .m_rsp_id(g_rsp_id), .m_rsp_src(g_rsp_src), .m_rsp_we(g_rsp_we),
    .m_rsp_err(g_rsp_err), .m_rsp_status(g_rsp_status), .src_en, .flush, .idle(g_idle), .sts_rsp_overflow(g_ovf), .sts_bank_proto(g_proto),
    .bk_req_valid(g_bk_valid), .bk_req_ready, .bk_req_we(g_bk_we), .bk_req_addr(g_bk_addr), .bk_req_wdata(g_bk_wdata), .bk_req_wstrb(g_bk_wstrb),
    .bk_rsp_valid, .bk_rsp_rdata, .bk_rsp_err, .perf_clr, .perf_sel, .perf_val(g_perf)
  );

  for (genvar b = 0; b < NB; b++) begin : g_bank
    sf_sramc_bankmodel #(.DW(DW), .DEPTH(BD), .LMIN(1), .LMAX(5), .RDY_PCT(80), .SEED(b + 7), .BADROW(3)) u_bank (
      .clk(clk), .rst_n(rst_n), .req_valid(r_bk_valid[b]), .req_ready(bk_req_ready[b]), .req_we(r_bk_we[b]),
      .req_addr(r_bk_addr[b*RAW +: RAW]), .req_wdata(r_bk_wdata[b*DW +: DW]), .req_wstrb(r_bk_wstrb[b*NBYTE +: NBYTE]),
      .rsp_valid(bk_rsp_valid[b]), .rsp_rdata(bk_rsp_rdata[b*DW +: DW]), .rsp_err(bk_rsp_err[b])
    );
  end

  // ---- stimulus / compare
  logic [63:0] st = 64'h1234_5678_9ABC_DEF1;
  function automatic logic [31:0] rnd();
    logic [63:0] x;
    x = st; x = x ^ (x >> 12); x = x ^ (x << 25); x = x ^ (x >> 27); st = x;
    rnd = 32'((x * 64'h2545_F491_4F6C_DD1D) >> 32);
  endfunction
  function automatic bit pct(input int p);
    logic [31:0] r;
    r = rnd();
    pct = ((r % 100) < p);
  endfunction

  int cycle = 0, errors = 0, compares = 0, accepts = 0, rsp_xfers = 0, rst_cnt = 6, flush_len = 0;
  int seed_arg;
  logic [31:0] r1, r2, r3;
  bit  hit;

  initial begin
    if (!$value$plusargs("seed=%d", seed_arg)) seed_arg = 1;
    st = st ^ (64'(seed_arg) * 64'h9E37_79B9_7F4A_7C15);
  end

  always @(posedge clk) begin : eng
    int m, b;
    cycle = cycle + 1;
    if (rst_n) begin
      // ---------------- compare (cycle that just ended)
      compares = compares + 1;
      if ({r_req_ready, r_rsp_valid, r_idle, r_ovf, r_proto, r_bk_valid} !== {g_req_ready, g_rsp_valid, g_idle, g_ovf, g_proto, g_bk_valid}) begin
        errors = errors + 1; if (errors < 10) $display("SRAMC_GLS_ERROR cyc=%0d control outputs differ rtl=%b/%b/%b gl=%b/%b/%b", cycle, r_req_ready, r_rsp_valid, r_bk_valid, g_req_ready, g_rsp_valid, g_bk_valid);
      end
      if (PERF != 0 && r_perf !== g_perf) begin errors = errors + 1; if (errors < 10) $display("SRAMC_GLS_ERROR cyc=%0d perf_val rtl=%0d gl=%0d (sel %0d)", cycle, r_perf, g_perf, perf_sel); end
      for (m = 0; m < NM; m++) begin
        if (r_rsp_valid[m]) begin
          if ({r_rsp_rdata[m*DW +: DW], r_rsp_id[m*IDW +: IDW], r_rsp_src[m*SRCW +: SRCW], r_rsp_we[m], r_rsp_err[m], r_rsp_status[m*4 +: 4]} !==
              {g_rsp_rdata[m*DW +: DW], g_rsp_id[m*IDW +: IDW], g_rsp_src[m*SRCW +: SRCW], g_rsp_we[m], g_rsp_err[m], g_rsp_status[m*4 +: 4]}) begin
            errors = errors + 1; if (errors < 10) $display("SRAMC_GLS_ERROR cyc=%0d master %0d response payload differs", cycle, m);
          end
        end
        if (m_req_valid[m] && r_req_ready[m]) accepts = accepts + 1;
        if (r_rsp_valid[m] && m_rsp_ready[m]) rsp_xfers = rsp_xfers + 1;
      end
      for (b = 0; b < NB; b++) begin
        if (r_bk_valid[b]) begin
          if ({r_bk_we[b], r_bk_addr[b*RAW +: RAW], r_bk_wdata[b*DW +: DW], r_bk_wstrb[b*NBYTE +: NBYTE]} !==
              {g_bk_we[b], g_bk_addr[b*RAW +: RAW], g_bk_wdata[b*DW +: DW], g_bk_wstrb[b*NBYTE +: NBYTE]}) begin
            errors = errors + 1; if (errors < 10) $display("SRAMC_GLS_ERROR cyc=%0d bank %0d request payload differs", cycle, b);
          end
        end
      end
    end

    // ---------------- drive the next cycle
    if (rst_cnt > 0) begin
      rst_cnt = rst_cnt - 1;
      if (rst_cnt == 0) rst_n <= 1'b1;
    end else begin
      for (m = 0; m < NM; m++) begin
        if (m_req_valid[m] && r_req_ready[m]) m_req_valid[m] <= 1'b0;      // accepted
        if (!m_req_valid[m] || r_req_ready[m]) begin
          hit = pct(60);
          if (hit) begin
            r1 = rnd(); r2 = rnd(); r3 = rnd();
            m_req_valid[m] <= 1'b1;
            m_req_we[m]    <= r1[0];
            m_req_err[m]   <= ((r1 % 100) < 3);
            if ((r1[15:8] % 100) < 85) m_req_addr[m*32 +: 32] <= 32'((r2 % (TOTAL_BYTES / NBYTE)) * NBYTE);
            else                       m_req_addr[m*32 +: 32] <= r2;
            m_req_wdata[m*DW +: DW] <= {r3, r2, r1, r3 ^ r2};
            m_req_wstrb[m*NBYTE +: NBYTE] <= ((r1[23:16] % 100) < 6) ? '0 : r3[NBYTE-1:0];
            m_req_id[m*IDW +: IDW] <= r3[IDW+7:8];
            m_req_src[m*SRCW +: SRCW] <= ((r1[31:24] % 100) < 5) ? r2[SRCW+3:4] : SRCW'(m);
          end else if (r_req_ready[m] || !m_req_valid[m]) begin
            m_req_valid[m] <= 1'b0;
          end
        end
        m_rsp_ready[m] <= pct(70);
      end
      if (flush_len > 0) begin flush_len = flush_len - 1; if (flush_len == 0) flush <= 1'b0; end
      else if (pct(1) && pct(30)) begin flush <= 1'b1; flush_len = 1 + (rnd() % 4); end
      if (pct(2) && pct(20)) src_en <= src_en ^ ({NM{1'b0}} | (32'd1 << (rnd() % NM)));
      if (cycle > 300 && pct(1) && pct(5)) begin rst_n <= 1'b0; rst_cnt = 2; end        // hard reset in the middle of traffic
      perf_sel <= (perf_sel == PSW'(NPERF - 1)) ? '0 : perf_sel + 1'b1;
      perf_clr <= (cycle % 7919 == 0);
    end

    if (cycle >= NCYC) begin
      if (errors == 0 && accepts > 100 && rsp_xfers > 100)
        $display("SRAMC_GLS PASS cycles=%0d compares=%0d accepted=%0d responses=%0d", cycle, compares, accepts, rsp_xfers);
      else
        $display("SRAMC_GLS FAIL cycles=%0d compares=%0d accepted=%0d responses=%0d errors=%0d", cycle, compares, accepts, rsp_xfers, errors);
      $finish;
    end
  end
endmodule
`default_nettype wire
