// Compile/connect check of the reference transaction interface: one master port of sf_sram_subsystem driven through sf_sramc_if,
// a few directed transactions, the interface's protocol checker watching.  (SRAMC_RESULT line like the other benches.)
`timescale 1ns/1ps
`default_nettype none
module tb_sramc_if;
  logic clk = 1'b0; always #5 clk = ~clk;
  logic rst_n = 1'b0;
  sf_sramc_if #(.AW(32), .DW(32), .IDW(4), .SRCW(1)) p (.clk, .rst_n);
  logic idle, ovf, proto;
  logic [31:0] pv;
  sf_sram_subsystem #(.NUM_MASTERS(1), .NUM_BANKS(1), .BANK_DEPTH(16), .MAX_OUT(1), .INIT_MODE(1)) dut (
    .clk, .rst_n, .m_req_valid(p.req_valid), .m_req_ready(p.req_ready), .m_req_we(p.req_we), .m_req_addr(p.req_addr),
    .m_req_wdata(p.req_wdata), .m_req_wstrb(p.req_wstrb), .m_req_id(p.req_id), .m_req_src(p.req_src), .m_req_err(p.req_err),
    .m_rsp_valid(p.rsp_valid), .m_rsp_ready(p.rsp_ready), .m_rsp_rdata(p.rsp_rdata), .m_rsp_id(p.rsp_id), .m_rsp_src(p.rsp_src),
    .m_rsp_we(p.rsp_we), .m_rsp_err(p.rsp_err), .m_rsp_status(p.rsp_status), .src_en(1'b1), .flush(1'b0), .idle,
    .sts_rsp_overflow(ovf), .sts_bank_proto(proto), .perf_clr(1'b0), .perf_sel('0), .perf_val(pv));
  int errors = 0, checks = 0;
  // drive at the falling edge, sample mid-cycle: no race with the rising edge
  task automatic xact(input bit we, input logic [31:0] a, input logic [31:0] d, input logic [3:0] id, input logic [3:0] exp_st, input logic [31:0] exp_d);
    @(negedge clk); p.req_valid = 1'b1; p.req_we = we; p.req_addr = a; p.req_wdata = d; p.req_wstrb = 4'hF; p.req_id = id; p.req_src = 1'b0; p.req_err = 1'b0;
    #1;
    while (!p.req_ready) begin @(negedge clk); #1; end       // held until accepted (R2)
    @(negedge clk); p.req_valid = 1'b0;                      // accepted at the rising edge in between
    #1;
    while (!p.rsp_valid) begin @(negedge clk); #1; end
    checks++;
    if (p.rsp_status !== exp_st || p.rsp_id !== id || (exp_st == 0 && !we && p.rsp_rdata !== exp_d)) begin errors++; $display("SRAMC_ERROR status %0d id %0d data %h", p.rsp_status, p.rsp_id, p.rsp_rdata); end
  endtask
  initial begin
    p.req_valid = 0; p.rsp_ready = 1; p.req_we = 0; p.req_addr = 0; p.req_wdata = 0; p.req_wstrb = 0; p.req_id = 0; p.req_src = 0; p.req_err = 0;
    repeat (4) @(negedge clk); rst_n = 1;
    xact(1, 32'h8, 32'hCAFE_F00D, 4'h3, 0, 0);
    xact(0, 32'h8, 0, 4'h4, 0, 32'hCAFE_F00D);
    xact(0, 32'h1000, 0, 4'h5, 4'd1, 0);            // out of range
    xact(0, 32'h9, 0, 4'h6, 4'd2, 0);               // misaligned
    repeat (3) @(posedge clk);
    if (errors == 0 && checks == 4) $display("SRAMC_RESULT PASS tb=tb_sramc_if seed=1 checks=%0d errors=0", checks);
    else $display("SRAMC_RESULT FAIL tb=tb_sramc_if seed=1 checks=%0d errors=%0d", checks, errors);
    $finish;
  end
endmodule
`default_nettype wire
