// =============================================================================
// SilicaFlux SRAMController :: tb_sramc_sub   (self-checking)
// sf_sram_subsystem: controller + real sf_sram_core banks with per-bank READ_LATENCY
// (LATS, 4 bits per bank).  All checking lives in sramc_tb_body.svh; the
// configuration is chosen with -G / -P parameter overrides (scripts/run_regress.py).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sramc_sub;
  parameter int          NM     = 4;
  parameter int          NB     = 4;
  parameter int          DW     = 32;
  parameter int          BD     = 64;
  parameter int          IDW    = 4;
  parameter int          MAXOUT = 1;
  parameter int          ILV    = 0;
  parameter int          IDCHK  = 1;
  parameter int          SRCCHK = 1;
  parameter int          MASKM  = 0;
  parameter int          PRIO   = 0;
  parameter logic [15:0] HPM    = 16'h0001;
  parameter int          HPL    = 4;
  parameter logic [63:0] LATS   = 64'h1111_1111_1111_1111;
  parameter int          NRAND  = 12000;
  localparam int MODE   = 0;
  localparam int BADROW = -1;
  localparam int CNT_W  = 32;
  localparam int NBYTE_ = DW / 8;
  localparam int SRCW_  = (NM > 1) ? $clog2(NM) : 1;
  localparam int PSW    = $clog2(16 + 16 * NM + 8 * NB);
  localparam string TBNAME = "tb_sramc_sub";

  logic                    clk;
  logic                    rst_n;
  logic [NM-1:0]           m_req_valid, m_req_we, m_req_err, m_rsp_ready, src_en;
  logic [NM-1:0]           m_req_ready, m_rsp_valid, m_rsp_we, m_rsp_err;
  logic [NM*32-1:0]        m_req_addr;
  logic [NM*DW-1:0]        m_req_wdata, m_rsp_rdata;
  logic [NM*NBYTE_-1:0]    m_req_wstrb;
  logic [NM*IDW-1:0]       m_req_id, m_rsp_id;
  logic [NM*SRCW_-1:0]     m_req_src, m_rsp_src;
  logic [NM*4-1:0]         m_rsp_status;
  logic                    flush, idle, sts_rsp_overflow, sts_bank_proto, perf_clr;
  logic [PSW-1:0]          perf_sel;
  logic [CNT_W-1:0]        perf_val;

  sf_sram_subsystem #(
    .NUM_MASTERS(NM), .NUM_BANKS(NB), .DATA_WIDTH(DW), .BANK_DEPTH(BD), .ADDR_WIDTH(32), .ID_WIDTH(IDW),
    .MAX_OUT(MAXOUT), .BANK_OUT(0), .INTERLEAVE(ILV), .ID_CHECK(IDCHK), .SRC_CHECK(SRCCHK), .MASK_MODE(MASKM),
    .PRIO_EN(PRIO), .HP_MASK(HPM), .HP_LIMIT(HPL), .PERF_EN(1), .CNT_W(CNT_W), .INIT_MODE(0), .BANK_LATS(LATS)
  ) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_we, .m_req_addr, .m_req_wdata, .m_req_wstrb, .m_req_id, .m_req_src, .m_req_err,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_id, .m_rsp_src, .m_rsp_we, .m_rsp_err, .m_rsp_status,
    .src_en, .flush, .idle, .sts_rsp_overflow, .sts_bank_proto, .perf_clr, .perf_sel, .perf_val
  );

  initial $display("SRAMC_INFO uniform_lat=%0d", dut.UNIFORM_EFF);

  `include "sramc_tb_body.svh"
endmodule

`default_nettype wire
