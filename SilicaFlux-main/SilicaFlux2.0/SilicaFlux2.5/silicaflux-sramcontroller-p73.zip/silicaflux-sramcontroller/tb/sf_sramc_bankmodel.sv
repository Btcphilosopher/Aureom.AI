// =============================================================================
// SilicaFlux SRAMController :: sf_sramc_bankmodel   (testbench only)
// A bank that honours the controller's BANK CONTRACT with RANDOM behaviour:
//   * req_ready is a random registered bit (RDY_PCT %), never depending on req_valid,
//   * every accepted access completes after a random latency in [LMIN, LMAX] cycles,
//     in acceptance order, at most one completion per cycle,
//   * the array is read / written at the acceptance edge (data sampled at issue).
// Used to prove the controller with variable, data-independent memory latency and
// bank busy phases; no relation to any physical SRAM timing.
// =============================================================================
`default_nettype none
module sf_sramc_bankmodel #(
  parameter int DW      = 32,
  parameter int DEPTH   = 64,
  parameter int LMIN    = 1,
  parameter int LMAX    = 4,
  parameter int RDY_PCT = 80,
  parameter int SEED    = 1,
  parameter int BADROW  = -1,          // >= 0: accesses to this row fail (rsp_err, write ignored, read data garbage)
  localparam int NBYTE  = DW / 8,
  localparam int AW     = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int QN     = 64
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            req_valid,
  output logic                 req_ready,
  input  wire logic            req_we,
  input  wire logic [AW-1:0]   req_addr,
  input  wire logic [DW-1:0]   req_wdata,
  input  wire logic [NBYTE-1:0] req_wstrb,
  output logic                 rsp_valid,
  output logic      [DW-1:0]   rsp_rdata,
  output logic                 rsp_err
);
  logic [DW-1:0]      mem  [DEPTH];
  logic [DW-1:0]      qd   [QN];
  logic               qe   [QN];
  logic [31:0]        qdue [QN];
  logic [31:0]        qh, qt, qn, now, last_due;
  logic [31:0]        lfsr;
  logic               rdy_q;

  function automatic logic [31:0] step(input logic [31:0] x);
    logic [31:0] y;
    y = x ^ (x << 13);
    y = y ^ (y >> 17);
    y = y ^ (y << 5);
    step = y;
  endfunction

  assign req_ready = rdy_q;
  assign rsp_valid = (qn != 0) && (qdue[qh] <= now);
  // data is only meaningful for a good read: writes and failed accesses return GARBAGE (the contract says
  // don't-care), so the controller must not rely on the bank returning zero
  assign rsp_rdata = rsp_valid ? qd[qh] : '0;
  assign rsp_err   = rsp_valid && qe[qh];

  logic [31:0] r1, r2;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      qh <= 32'd0; qt <= 32'd0; qn <= 32'd0; now <= 32'd0; last_due <= 32'd0;
      lfsr <= 32'(SEED) * 32'h9E3779B1 + 32'h1;
      rdy_q <= 1'b0;
    end else begin
      now <= now + 32'd1;
      r1 = step(lfsr);
      r2 = step(r1);
      lfsr <= r2;
      rdy_q <= ((r1 % 100) < RDY_PCT) && (qn < (QN - 2));
      begin : blk
        logic [31:0] dn, due, lat, span;
        dn = 0;
        if (rsp_valid) begin
          qh <= (qh + 1) % QN;
          dn = 1;
        end
        if (req_valid && req_ready) begin
          span = (LMAX > LMIN) ? (LMAX - LMIN + 1) : 1;
          lat = LMIN + (r2 % span);
          if (lat < 1) lat = 1;
          due = now + lat;
          if (qn != 0 || dn != 0) begin
            if (due < last_due + 1) due = last_due + 1;
          end
          last_due <= due;
          qdue[qt] <= due;
          qe[qt] <= (BADROW >= 0) && (32'(req_addr) == BADROW);
          if ((BADROW >= 0) && (32'(req_addr) == BADROW)) begin
            qd[qt] <= {r2, r1, r2 ^ r1, r2 + r1};                                   // failed access: garbage, no side effect
          end else if (req_we) begin
            for (int l = 0; l < NBYTE; l++)
              if (req_wstrb[l]) mem[req_addr][l*8 +: 8] <= req_wdata[l*8 +: 8];
            qd[qt] <= {r1, r2, r1 ^ r2, r1 + r2};                                   // write: garbage on the data bus
          end else begin
            qd[qt] <= mem[req_addr];
          end
          qt <= (qt + 32'd1) % QN;
        end
        qn <= qn + ((req_valid && req_ready) ? 32'd1 : 32'd0) - dn;
      end
    end
  end
endmodule
`default_nettype wire
