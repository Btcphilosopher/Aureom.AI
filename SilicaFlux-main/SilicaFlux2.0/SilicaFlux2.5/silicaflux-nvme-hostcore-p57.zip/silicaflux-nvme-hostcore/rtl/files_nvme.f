// NVMe HostCore front end (Project 57) -- compile order, paths relative to the project root.
// The back-end boundary uses the P51 StorageCore protocol package (vendored unmodified).
+incdir+third_party/silicaflux-storagecore-p51/rtl/generated
third_party/silicaflux-storagecore-p51/rtl/generated/sfs_map_pkg.sv
third_party/silicaflux-storagecore-p51/rtl/silicaflux_storage_pkg.sv
rtl/silicaflux_nvme_pkg.sv
rtl/sfn_ep_adapter.sv
rtl/sfn_regs.sv
rtl/sfn_queue_mgr.sv
rtl/sfn_irq.sv
rtl/sfn_hostwin.sv
rtl/sfn_admin_data.sv
rtl/silicaflux_nvme_controller.sv
