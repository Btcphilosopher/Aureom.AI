// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_regs -- NVMe controller register file (BAR0)
//
//   00h CAP    RO  capabilities (value supplied by the controller top, docs/02)
//   08h VS     RO  1.4.0
//   0Ch INTMS  RW1S interrupt mask set     } pin-based / MSI only; current
//   10h INTMC  RW1C interrupt mask clear   } mask kept in sfn_irq, read here
//   14h CC     RW  EN CSS MPS AMS SHN IOSQES IOCQES (other bits RsvdZ)
//   1Ch CSTS   RO  RDY CFS SHST (NSSRO / PP read 0: no NVM subsystem reset, no pause)
//   20h NSSR   reserved (CAP.NSSRS = 0): reads 0, writes ignored
//   24h AQA    RW  ASQS[11:0] ACQS[27:16]
//   28h ASQ    RW  [63:12] (bits 11:0 RsvdZ)
//   30h ACQ    RW  [63:12]
//   38h..FFFh  reserved / optional features not implemented (CMB, BP, PMR): read 0
//   1000h+     doorbells (stride 4: CAP.DSTRD = 0): SQyTDBL at 1000h + 8y,
//              CQyHDBL at 1004h + 8y; write-only, read 0.  Every full-DW write
//              is forwarded (db_*) for validation by sfn_queue_mgr; partial
//              doorbell writes are ignored and flagged.
// Byte enables are honoured on all RW registers.  Register reads have no side
// effects.  soft_clr (controller reset completed) clears CC; flr_clr (function
// level reset) also clears AQA / ASQ / ACQ.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfn_regs
  import silicaflux_nvme_pkg::*;
#(
  parameter int BAR_AW = 14
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              soft_clr,
  input  wire logic              flr_clr,
  // register port from sfn_ep_adapter
  input  wire logic              mm_valid,
  input  wire logic              mm_write,
  input  wire logic [BAR_AW-1:2] mm_addr,
  input  wire logic [31:0]       mm_wdata,
  input  wire logic [3:0]        mm_be,
  output logic [31:0]            mm_rdata,
  // values owned elsewhere
  input  wire logic [63:0]       cap,
  input  wire logic [31:0]       csts,
  input  wire logic [31:0]       intms,
  // host-written registers
  output logic [31:0]            cc_q,
  output logic [31:0]            aqa_q,
  output logic [63:0]            asq_q,
  output logic [63:0]            acq_q,
  output logic                   cc_wr,           // CC written this cycle (new value visible next cycle)
  // interrupt mask set / clear
  output logic                   im_set_v,
  output logic                   im_clr_v,
  output logic [31:0]            im_wdata,
  // doorbells
  output logic                   db_valid,
  output logic                   db_cq,
  output logic [10:0]            db_qid,
  output logic [31:0]            db_val,
  output logic                   ev_db_partial
);
  wire [BAR_AW-1:0] a   = {mm_addr, 2'b00};
  wire [31:0]       bem = {{8{mm_be[3]}}, {8{mm_be[2]}}, {8{mm_be[1]}}, {8{mm_be[0]}}};
  wire              wr  = mm_valid && mm_write;
  wire              is_db = (a >= BAR_AW'(R_DB_BASE));
  wire [BAR_AW-1:0] dbo = a - BAR_AW'(R_DB_BASE);

  function automatic logic [31:0] merge(input logic [31:0] old, input logic [31:0] nw, input logic [31:0] m,
                                        input logic [31:0] wmask);
    merge = ((old & ~m) | (nw & m)) & wmask;
  endfunction

  // ---------------------------------------------------------------- reads (combinational, no side effects)
  always_comb begin
    mm_rdata = 32'h0;
    if (!is_db) begin
      case (14'(a))
        R_CAP_LO: mm_rdata = cap[31:0];
        R_CAP_HI: mm_rdata = cap[63:32];
        R_VS:     mm_rdata = SFN_NVME_VS;
        R_INTMS:  mm_rdata = intms;
        R_INTMC:  mm_rdata = intms;
        R_CC:     mm_rdata = cc_q;
        R_CSTS:   mm_rdata = csts;
        R_AQA:    mm_rdata = aqa_q;
        R_ASQ_LO: mm_rdata = asq_q[31:0];
        R_ASQ_HI: mm_rdata = asq_q[63:32];
        R_ACQ_LO: mm_rdata = acq_q[31:0];
        R_ACQ_HI: mm_rdata = acq_q[63:32];
        default:  mm_rdata = 32'h0;
      endcase
    end
  end

  // ---------------------------------------------------------------- writes
  assign cc_wr    = wr && !is_db && (14'(a) == R_CC);
  assign im_set_v = wr && !is_db && (14'(a) == R_INTMS);
  assign im_clr_v = wr && !is_db && (14'(a) == R_INTMC);
  assign im_wdata = mm_wdata & bem;
  assign db_valid = wr && is_db && (mm_be == 4'hF);
  assign db_cq    = dbo[2];
  assign db_qid   = 11'(dbo >> 3);
  assign db_val   = mm_wdata;
  assign ev_db_partial = wr && is_db && (mm_be != 4'hF);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cc_q <= '0; aqa_q <= '0; asq_q <= '0; acq_q <= '0;
    end else begin
      if (wr && !is_db) begin
        case (14'(a))
          R_CC:     cc_q          <= merge(cc_q, mm_wdata, bem, CC_WMASK);
          R_AQA:    aqa_q         <= merge(aqa_q, mm_wdata, bem, AQA_WMASK);
          R_ASQ_LO: asq_q[31:0]   <= merge(asq_q[31:0], mm_wdata, bem, 32'hFFFF_F000);
          R_ASQ_HI: asq_q[63:32]  <= merge(asq_q[63:32], mm_wdata, bem, 32'hFFFF_FFFF);
          R_ACQ_LO: acq_q[31:0]   <= merge(acq_q[31:0], mm_wdata, bem, 32'hFFFF_F000);
          R_ACQ_HI: acq_q[63:32]  <= merge(acq_q[63:32], mm_wdata, bem, 32'hFFFF_FFFF);
          default: ;
        endcase
      end
      if (soft_clr || flr_clr) cc_q <= '0;
      if (flr_clr) begin aqa_q <= '0; asq_q <= '0; acq_q <= '0; end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^dbo[1:0];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
