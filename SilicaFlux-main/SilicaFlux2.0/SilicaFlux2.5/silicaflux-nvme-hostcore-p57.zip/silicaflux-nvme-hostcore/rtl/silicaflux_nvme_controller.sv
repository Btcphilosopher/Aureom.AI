// =============================================================================
// SilicaFlux-STORE (Project 57) :: silicaflux_nvme_controller -- NVMe HostCore
//
// NVMe storage-command front end for SilicaFlux-STORE.  Implements a documented
// SUBSET of the NVM Express Base / NVM Command Set / PCIe Transport
// specifications (docs/03_COMMANDS.md, docs/10_LIMITATIONS.md); it is not an
// NVMe-conformant controller.
//
//   PCIe endpoint (vendor IP or simulation model)
//     │ SFN-TL: completer req/cpl, requester req/cpl, cfg status, MSI/INTx
//   sfn_ep_adapter ── MMIO ──► sfn_regs (CAP VS INTMS INTMC CC CSTS AQA ASQ ACQ, doorbells)
//     │  DMA read/write ▲                │ doorbells
//     │                 │          sfn_queue_mgr (SQ/CQ state, phase, validation)
//     │   ┌─────────────┴──────────────┐ │
//     │   fetch ─► decode ─► PRP lists ─► back-end dispatch (sfs_cmd_t) ─► storage back end / FTL
//     │                 └─► admin engine (Identify, queues, logs, features)      │ data via
//     │   completion engine (CQE, phase, SQHD, AER) ◄── status ◄──────────────────┘ sfn_hostwin
//     └── sfn_irq (pin-based / MSI)
//
// Storage back end boundary = P51 StorageCore command channel (sfs_cmd_t /
// sfs_cpl_t, silicaflux_storage_pkg) + an SFB2 "host memory window" that the
// back end's DMA uses (sfn_hostwin translates it through the PRPs) + the
// controller-enable handshake (fe_en / be_rdy / fe_resetting / fe_reset_done,
// fe_shn / be_shst) that P51's HIF firmware page already defines.
// One clock domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_nvme_controller
  import silicaflux_nvme_pkg::*;
  import silicaflux_storage_pkg::*;
#(
  parameter int          NUM_IOQ          = 1,      // I/O SQ/CQ pairs (1..8)
  parameter int          NCTX             = 8,      // commands in flight (power of two, 2..32)
  parameter int          MQES             = 1023,   // CAP.MQES (0's based)
  parameter int          NUM_VEC          = 8,      // interrupt vectors (1..32)
  parameter int          MAX_XFER_LOG2    = 15,     // front-end transfer limit (bytes, log2; 13..17)
  parameter int          NTAG             = 8,
  parameter int          RSLOT_BYTES      = 512,
  parameter int          MPS_CAP          = 256,
  parameter int          CPL_TIMEOUT      = 65536,
  parameter int          PF_BYTES         = 1024,     // window read-ahead (covers ~latency x bandwidth)
  parameter int          PF_CHUNK         = 256,      // window prefetch read size
  parameter int          PF_INF           = 4,        // window prefetch reads in flight
  parameter int          WC_BYTES         = 256,
  parameter int          WC_IDLE          = 16,
  parameter int          FETCH_OUT        = 4,      // SQE reads in flight
  parameter int          ENABLE_EXT_ADMIN = 1,      // Set/Get Features, Abort, AER (phase 2 commands)
  parameter int          NERR             = 4,      // error-log entries
  parameter int          AERL             = 1,      // 0's based
  parameter logic [7:0]  CAP_TO           = 8'd15,  // CAP.TO, 500 ms units
  parameter logic [63:0] BUSY_CYC_PER_MIN = 64'd6_000_000_000,
  parameter logic [15:0] PCI_VID          = 16'hFFFE,   // placeholder, not an assigned Vendor ID
  parameter logic [15:0] PCI_SSVID        = 16'hFFFE,
  localparam int NQ    = NUM_IOQ + 1,
  localparam int QIW   = $clog2(NQ),
  localparam int CW    = $clog2(NCTX),
  localparam int MAXP  = (1 << (MAX_XFER_LOG2 - 12)) + 1,
  localparam int PW    = $clog2(MAXP),
  localparam int XLW   = MAX_XFER_LOG2 + 1,
  localparam int BAR_AW = 14,
  localparam int WIN_LOG2 = 20,
  localparam int NPERF = 32
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ================================================================ SFN-TL (to the PCIe endpoint)
  input  wire logic              cq_valid,
  output logic                   cq_ready,
  input  wire logic              cq_write,
  input  wire logic [2:0]        cq_bar,
  input  wire logic [63:0]       cq_addr,
  input  wire logic [10:0]       cq_len_dw,
  input  wire logic [3:0]        cq_first_be,
  input  wire logic [3:0]        cq_last_be,
  input  wire logic [7:0]        cq_tag,
  input  wire logic [15:0]       cq_req_id,
  input  wire logic [31:0]       cq_data,
  input  wire logic              cq_last,
  output logic                   cc_valid,
  input  wire logic              cc_ready,
  output logic [7:0]             cc_tag,
  output logic [15:0]            cc_req_id,
  output logic [2:0]             cc_status,
  output logic [12:0]            cc_byte_count,
  output logic [6:0]             cc_lower_addr,
  output logic [10:0]            cc_len_dw,
  output logic [31:0]            cc_data,
  output logic                   cc_last,
  output logic                   rq_valid,
  input  wire logic              rq_ready,
  output logic                   rq_write,
  output logic [63:0]            rq_addr,
  output logic [10:0]            rq_len_dw,
  output logic [3:0]             rq_first_be,
  output logic [3:0]             rq_last_be,
  output logic [7:0]             rq_tag,
  output logic [31:0]            rq_data,
  output logic                   rq_last,
  input  wire logic              rc_valid,
  output logic                   rc_ready,
  input  wire logic [7:0]        rc_tag,
  input  wire logic [2:0]        rc_status,
  input  wire logic [12:0]       rc_byte_count,
  input  wire logic [6:0]        rc_lower_addr,
  input  wire logic [10:0]       rc_len_dw,
  input  wire logic [31:0]       rc_data,
  input  wire logic              rc_last,
  // endpoint configuration status
  input  wire logic              cfg_bme,
  input  wire logic [2:0]        cfg_mps,
  input  wire logic [2:0]        cfg_mrrs,
  input  wire logic              cfg_msi_en,
  input  wire logic [2:0]        cfg_msi_mme,
  input  wire logic              cfg_intx_dis,
  input  wire logic              cfg_flr,          // function-level reset request (pulse)
  // interrupts to the endpoint
  output logic                   msi_valid,
  input  wire logic              msi_ready,
  output logic [4:0]             msi_vector,
  output logic                   intx_assert,
  // ================================================================ storage back end
  output logic                   be_cmd_valid,
  input  wire logic              be_cmd_ready,
  output sfs_cmd_t               be_cmd,
  input  wire logic              be_cpl_valid,
  output logic                   be_cpl_ready,
  input  wire sfs_cpl_t          be_cpl,
  input  wire logic [63:0]       be_capacity,      // logical blocks (512 B)
  input  wire logic [15:0]       be_mdts,          // blocks per command
  input  wire logic              be_idle,          // no command owned by the back end
  input  wire logic              be_rdy,           // back end ready (firmware raised RDY)
  input  wire logic [1:0]        be_shst,          // shutdown status from the back end
  input  wire logic              be_cfs,           // back-end fatal
  output logic                   fe_en,            // controller enabled (CC.EN with a valid configuration)
  output logic                   fe_shn,           // shutdown notification (CC.SHN != 0)
  output logic                   fe_resetting,     // controller reset in progress
  output logic                   fe_reset_done,    // pulse: reset complete, queues cleared
  output logic                   fe_db_err,        // pulse: invalid doorbell write
  // back-end DMA: host-memory window (SFB2 slave, 32-bit)
  input  wire logic              hw_req_valid,
  output logic                   hw_req_ready,
  input  wire logic              hw_req_write,
  input  wire logic [31:0]       hw_req_addr,
  input  wire logic [31:0]       hw_req_wdata,
  input  wire logic [3:0]        hw_req_wstrb,
  output logic                   hw_rsp_valid,
  input  wire logic              hw_rsp_ready,
  output logic [31:0]            hw_rsp_rdata,
  output logic                   hw_rsp_error,
  // ================================================================ status
  output logic [2:0]             dbg_state,
  output logic [NPERF*32-1:0]    perf
);
  // ================================================================ elaboration checks
  // illegal parameter sets refuse to elaborate in every tool (simulators, lint, Yosys): the module
  // below is deliberately not defined anywhere
  localparam bit PARAM_BAD = (NUM_IOQ < 1) || (NUM_IOQ > 8) || (NCTX < 2) || (NCTX > 32) || ((1 << CW) != NCTX) ||
                             (MAX_XFER_LOG2 < 13) || (MAX_XFER_LOG2 > 17) || (NUM_VEC < 1) || (NUM_VEC > 32) ||
                             (MQES < 1) || (MQES > 65535) || (FETCH_OUT < 2) || (NERR < 2) ||
                             (PF_BYTES < 2 * PF_CHUNK) || (PF_INF < 1) || (PF_INF > 7) || (AERL < 0) || (AERL > 7);
  generate
    if (PARAM_BAD) begin : g_illegal_parameters
      sfn_illegal_parameter_set u_reject ();
    end
  endgenerate
`ifndef SYNTHESIS
  initial begin
    if (NUM_IOQ < 1 || NUM_IOQ > 8) $fatal(1, "NUM_IOQ must be 1..8");
    if (NCTX < 2 || NCTX > 32 || (1 << CW) != NCTX) $fatal(1, "NCTX must be a power of two, 2..32");
    if (MAX_XFER_LOG2 < 13 || MAX_XFER_LOG2 > 17) $fatal(1, "MAX_XFER_LOG2 must be 13..17");
    if (NUM_VEC < 1 || NUM_VEC > 32) $fatal(1, "NUM_VEC must be 1..32");
    if (MQES < 1 || MQES > 65535) $fatal(1, "MQES must be 1..65535");
    if (FETCH_OUT < 2 || NERR < 2) $fatal(1, "FETCH_OUT and NERR must be >= 2");
  end
`endif

  logic [31:0] now;                                            // free-running cycle counter

  // ================================================================ endpoint adapter
  localparam int ID_FETCH = 0, ID_PRP = 1, ID_WIN = 2;
  logic        mm_valid, mm_write;
  logic [BAR_AW-1:2] mm_addr;
  logic [31:0] mm_wdata, mm_rdata;
  logic [3:0]  mm_be;
  logic        ard_valid, ard_ready, ard_rsp_valid, ard_rsp_last, ard_rsp_err;
  logic [63:0] ard_addr;
  logic [12:0] ard_len;
  logic [1:0]  ard_id, ard_rsp_id;
  logic [31:0] ard_rsp_data;
  logic        awr_valid, awr_ready;
  logic [63:0] awr_addr;
  logic [12:0] awr_len;
  logic [31:0] awr_data;
  logic        ad_rd_idle, ad_wr_idle, ev_rd_dw, ev_wr_dw, ev_cpl_err, ev_cpl_tmo, ev_cpl_unexp, ev_bme, ev_mmio_bad;

  sfn_ep_adapter #(.BAR_AW(BAR_AW), .NTAG(NTAG), .RSLOT_BYTES(RSLOT_BYTES), .MPS_CAP(MPS_CAP),
                   .CPL_TIMEOUT(CPL_TIMEOUT), .ID_W(2)) u_ep (
    .clk, .rst_n,
    .cq_valid, .cq_ready, .cq_write, .cq_bar, .cq_addr, .cq_len_dw, .cq_first_be, .cq_last_be, .cq_tag, .cq_req_id,
    .cq_data, .cq_last,
    .cc_valid, .cc_ready, .cc_tag, .cc_req_id, .cc_status, .cc_byte_count, .cc_lower_addr, .cc_len_dw, .cc_data, .cc_last,
    .rq_valid, .rq_ready, .rq_write, .rq_addr, .rq_len_dw, .rq_first_be, .rq_last_be, .rq_tag, .rq_data, .rq_last,
    .rc_valid, .rc_ready, .rc_tag, .rc_status, .rc_byte_count, .rc_lower_addr, .rc_len_dw, .rc_data, .rc_last,
    .cfg_bme, .cfg_mps, .cfg_mrrs,
    .mm_valid, .mm_write, .mm_addr, .mm_wdata, .mm_be, .mm_rdata,
    .rd_req_valid(ard_valid), .rd_req_ready(ard_ready), .rd_req_addr(ard_addr), .rd_req_len(ard_len), .rd_req_id(ard_id),
    .rd_rsp_valid(ard_rsp_valid), .rd_rsp_ready(1'b1), .rd_rsp_data(ard_rsp_data), .rd_rsp_id(ard_rsp_id),
    .rd_rsp_last(ard_rsp_last), .rd_rsp_err(ard_rsp_err),
    .wr_valid(awr_valid), .wr_ready(awr_ready), .wr_addr(awr_addr), .wr_len(awr_len), .wr_data(awr_data),
    .rd_idle(ad_rd_idle), .wr_idle(ad_wr_idle), .ev_rd_dw, .ev_wr_dw, .ev_cpl_err, .ev_cpl_tmo, .ev_cpl_unexp,
    .ev_bme_block(ev_bme), .ev_mmio_bad
  );

  // ---------------------------------------------------------------- DMA read arbiter (round robin, request granularity)
  logic [2:0]  rq_v;
  logic [63:0] rq_a [3];
  logic [12:0] rq_l [3];
  logic [2:0]  rq_g;                 // grant (one-hot) this cycle
  logic [1:0]  rr_rd;
  always_comb begin
    rq_g = '0;
    for (int k = 2; k >= 0; k--)
      if (rq_v[(32'(rr_rd) + 32'(k)) % 32'd3]) rq_g = 3'(32'd1 << ((32'(rr_rd) + 32'(k)) % 32'd3));
    ard_valid = |rq_v;
    ard_id    = rq_g[2] ? 2'd2 : (rq_g[1] ? 2'd1 : 2'd0);
    ard_addr  = rq_a[ard_id];
    ard_len   = rq_l[ard_id];
  end
  wire [2:0] rq_ack = ard_ready ? rq_g : 3'b000;

  // ---------------------------------------------------------------- DMA write arbiter (grant held for a whole request)
  localparam int WR_WIN = 0, WR_ADM = 1, WR_CPL = 2;
  logic [2:0]  wq_v, wq_last;
  logic [63:0] wq_a [3];
  logic [12:0] wq_l [3];
  logic [31:0] wq_d [3];
  logic [1:0]  wg;                   // 3 = none
  logic [1:0]  rr_wr;
  logic [1:0]  wg_next;
  always_comb begin
    wg_next = 2'd3;
    for (int k = 2; k >= 0; k--)
      if (wq_v[(32'(rr_wr) + 32'(k)) % 32'd3]) wg_next = 2'((32'(rr_wr) + 32'(k)) % 32'd3);
  end
  assign awr_valid = (wg != 2'd3) && wq_v[wg];
  assign awr_addr  = (wg != 2'd3) ? wq_a[wg] : 64'h0;
  assign awr_len   = (wg != 2'd3) ? wq_l[wg] : 13'h0;
  assign awr_data  = (wg != 2'd3) ? wq_d[wg] : 32'h0;
  wire [2:0] wq_ack = (awr_valid && awr_ready) ? 3'(1 << wg) : 3'b000;
  wire       wr_rel = awr_valid && awr_ready && wq_last[wg];

  // ================================================================ registers
  logic [31:0] cc_q, aqa_q, csts, intms, im_wdata;
  logic [63:0] asq_q, acq_q, cap;
  logic        cc_wr, im_set_v, im_clr_v, rdb_valid, rdb_cq, ev_db_partial, soft_clr, flr_clr;
  logic [10:0] rdb_qid;
  logic [31:0] rdb_val;
  sfn_regs #(.BAR_AW(BAR_AW)) u_regs (
    .clk, .rst_n, .soft_clr, .flr_clr,
    .mm_valid, .mm_write, .mm_addr, .mm_wdata, .mm_be, .mm_rdata,
    .cap, .csts, .intms,
    .cc_q, .aqa_q, .asq_q, .acq_q, .cc_wr, .im_set_v, .im_clr_v, .im_wdata,
    .db_valid(rdb_valid), .db_cq(rdb_cq), .db_qid(rdb_qid), .db_val(rdb_val), .ev_db_partial
  );
  // CAP: MQES, CQR = 1, AMS = 0 (round robin only), TO, DSTRD = 0, NSSRS = 0, CSS = NVM command set,
  //      BPS = 0, MPSMIN = MPSMAX = 0 (4 KiB), PMRS = CMBS = 0
  assign cap = {8'h00, 4'h0, 4'h0, 2'b00, 1'b0, 8'b0000_0001, 1'b0, 4'h0, CAP_TO, 5'b0, 2'b00, 1'b1, 16'(MQES)};

  // ================================================================ queues
  logic              qm_clear, qm_admin_init, db_bad_reg, db_bad_val, db_sq_ok, db_cq_ok;
  logic              cr_valid, cr_cq, cr_ien, dl_valid, dl_cq, sd_valid, fi_valid, fd_valid, po_valid;
  logic [QIW-1:0]    cr_qid, cr_cqid, dl_qid, sd_qid, fi_qid, fd_qid, po_qid;
  logic [63:12]      cr_base;
  logic [15:0]       cr_size;
  logic [4:0]        cr_iv;
  logic [NQ-1:0]     sq_v, sq_del, cq_v, cq_ph, cq_ien;
  logic [NQ*52-1:0]  sq_base, cq_base;
  logic [NQ*16-1:0]  sq_size, sq_tail, sq_head, sq_fptr, cq_size, cq_tail, cq_head;
  logic [NQ*QIW-1:0] sq_cqid;
  logic [NQ*5-1:0]   cq_iv;
  sfn_queue_mgr #(.NQ(NQ)) u_qm (
    .clk, .rst_n, .clear(qm_clear),
    .admin_init(qm_admin_init), .asq_base(asq_q[63:12]), .acq_base(acq_q[63:12]),
    .asqs({4'h0, aqa_q[11:0]}), .acqs({4'h0, aqa_q[27:16]}),
    .db_valid(rdb_valid), .db_cq(rdb_cq), .db_qid(rdb_qid), .db_val(rdb_val),
    .db_bad_reg, .db_bad_val, .db_sq_ok, .db_cq_ok,
    .cr_valid, .cr_cq, .cr_qid, .cr_base, .cr_size, .cr_cqid, .cr_ien, .cr_iv,
    .dl_valid, .dl_cq, .dl_qid, .sd_valid, .sd_qid,
    .fi_valid, .fi_qid, .fd_valid, .fd_qid, .po_valid, .po_qid,
    .sq_v, .sq_del, .sq_base, .sq_size, .sq_tail, .sq_head, .sq_fptr, .sq_cqid,
    .cq_v, .cq_ph, .cq_ien, .cq_base, .cq_size, .cq_tail, .cq_head, .cq_iv
  );
  function automatic logic [15:0] q16(input logic [NQ*16-1:0] v, input int i);
    q16 = v[i*16 +: 16];
  endfunction
  logic [NQ-1:0] sq_pend, cq_full, cq_pend;
  always_comb begin
    for (int i = 0; i < NQ; i++) begin
      sq_pend[i] = sq_v[i] && !sq_del[i] && (q16(sq_fptr, i) != q16(sq_tail, i));
      cq_full[i] = ((q16(cq_tail, i) == q16(cq_size, i)) ? 16'd0 : q16(cq_tail, i) + 16'd1) == q16(cq_head, i);
      cq_pend[i] = cq_v[i] && (q16(cq_tail, i) != q16(cq_head, i));
    end
  end

  // ================================================================ controller state
  localparam logic [2:0] CS_DIS = 3'd0, CS_ENB = 3'd1, CS_RDY = 3'd2, CS_RST = 3'd3, CS_ERR = 3'd4;
  logic [2:0] cs;
  logic       rdy_q, fatal_q, flr_pend, vwc_wce;
  wire        cc_en  = cc_q[0] && !flr_pend;
  wire [1:0]  cc_shn = cc_q[15:14];
  assign dbg_state = cs;
  assign csts = {28'h0, be_shst, fatal_q || be_cfs, rdy_q};
  assign fe_en        = (cs == CS_ENB) || (cs == CS_RDY);
  assign fe_shn       = fe_en && (cc_shn != 2'b00);
  assign fe_resetting = (cs == CS_RST);
  wire   resetting    = (cs == CS_RST);

  // enable-time configuration check
  wire [64:0] asq_end = {1'b0, asq_q[63:12], 12'h000} + 65'({aqa_q[11:0], 6'd0}) + 65'd63;
  wire [64:0] acq_end = {1'b0, acq_q[63:12], 12'h000} + 65'({aqa_q[27:16], 4'd0}) + 65'd15;
  wire cfg_ok = (aqa_q[11:0] != 12'd0) && (aqa_q[27:16] != 12'd0) && (cc_q[10:7] == 4'd0) &&
                (cc_q[6:4] == 3'd0) && (cc_q[13:11] == 3'd0) && !asq_end[64] && !acq_end[64];

  // effective transfer limit: min(front end, back end); MDTS = log2(bytes) - 12
  function automatic logic [4:0] flog2(input logic [15:0] v);
    flog2 = 5'd0;
    for (int i = 0; i < 16; i++) if (v[i]) flog2 = 5'(i);
  endfunction
  wire [4:0]  be_log2   = flog2(be_mdts) + 5'd9;
  wire [4:0]  xfer_log2 = (be_mdts == 16'd0 || be_log2 > 5'(MAX_XFER_LOG2)) ? 5'(MAX_XFER_LOG2) :
                          ((be_log2 < 5'd13) ? 5'd13 : be_log2);
  wire [7:0]  mdts_f    = {3'd0, xfer_log2} - 8'd12;
  wire [XLW:0] max_bytes = (XLW+1)'(1) << xfer_log2;

  // ================================================================ command contexts
  logic [3:0]      cx_st   [NCTX];
  logic [511:0]    cx_sqe  [NCTX];
  logic [QIW-1:0]  cx_sq   [NCTX];
  logic [7:0]      cx_seq  [NCTX];
  logic [7:0]      cx_gen  [NCTX];
  logic [11:0]     cx_stat [NCTX];
  logic [31:0]     cx_dw0  [NCTX];
  logic [15:0]     cx_ploc [NCTX];
  logic [XLW-1:0]  cx_xlen [NCTX];
  logic [PW:0]     cx_npg  [NCTX];
  logic            cx_adm  [NCTX];
  logic            cx_win  [NCTX];
  logic            cx_toh  [NCTX];
  logic [31:0]     cx_tf   [NCTX];
  logic [31:0]     cx_tb   [NCTX];
  logic [51:0]     prp_tab [NCTX * MAXP];
  logic [7:0]      seq_next;

  function automatic logic [31:0] dw(input logic [511:0] e, input int i);
    dw = e[32*i +: 32];
  endfunction

  // free context (lowest index)
  logic          have_free;
  logic [CW-1:0] free_c;
  always_comb begin
    have_free = 1'b0;
    free_c    = '0;
    for (int i = NCTX - 1; i >= 0; i--) if (cx_st[i] == CX_FREE) begin have_free = 1'b1; free_c = CW'(i); end
  end

  // ================================================================ fetch engine
  logic                f_req_v;
  logic [63:0]         f_req_a;
  logic [CW-1:0]       f_fifo_c [FETCH_OUT];
  logic [$clog2(FETCH_OUT+1)-1:0] f_out;
  logic [$clog2(FETCH_OUT)-1:0]   f_wp, f_rp;
  logic [3:0]          f_beat;
  logic                f_err;
  logic [QIW-1:0]      rr_f;
  logic                f_pick_v;
  logic [QIW-1:0]      f_pick_q;
  always_comb begin
    f_pick_v = 1'b0;
    f_pick_q = '0;
    for (int k = NQ - 1; k >= 0; k--)
      if (sq_pend[(32'(rr_f) + 32'(k)) % NQ]) begin
        f_pick_v = 1'b1; f_pick_q = QIW'((32'(rr_f) + 32'(k)) % NQ);
      end
  end
  wire f_go = (cs == CS_RDY) && !fatal_q && (be_shst != 2'b10) && !f_req_v && have_free &&
              (32'(f_out) < FETCH_OUT) && f_pick_v;
  assign rq_v[ID_FETCH] = f_req_v;
  assign rq_a[ID_FETCH] = f_req_a;
  assign rq_l[ID_FETCH] = 13'd64;
  wire f_beat_v = ard_rsp_valid && (ard_rsp_id == 2'(ID_FETCH));
  wire [CW-1:0] f_head_c = f_fifo_c[f_rp];

  // ================================================================ decode
  logic          dec_v;
  logic [CW-1:0] dec_c;
  always_comb begin
    dec_v = 1'b0;
    dec_c = '0;
    for (int i = NCTX - 1; i >= 0; i--) if (cx_st[i] == CX_DECODE) begin dec_v = 1'b1; dec_c = CW'(i); end
  end
  wire [511:0] d_sqe   = cx_sqe[dec_c];
  wire [7:0]   d_opc   = d_sqe[7:0];
  wire [1:0]   d_fuse  = d_sqe[9:8];
  wire [1:0]   d_psdt  = d_sqe[15:14];
  wire [15:0]  d_cid   = d_sqe[31:16];
  wire [31:0]  d_nsid  = dw(d_sqe, 1);
  wire [63:0]  d_prp1  = {dw(d_sqe, 7), dw(d_sqe, 6)};
  wire [63:0]  d_prp2  = {dw(d_sqe, 9), dw(d_sqe, 8)};
  wire [31:0]  d_c10   = dw(d_sqe, 10);
  wire [31:0]  d_c11   = dw(d_sqe, 11);
  wire [31:0]  d_c12   = dw(d_sqe, 12);
  wire         d_adm   = (cx_sq[dec_c] == '0);
  wire [63:0]  d_slba  = {d_c11, d_c10};
  wire [64:0]  d_lend  = {1'b0, d_slba} + {49'd0, d_c12[15:0]} + 65'd1;
  wire [33:0]  d_numd  = {2'b00, d_c11[15:0], d_c10[31:16]};
  logic        d_conf;                          // command identifier conflict
  always_comb begin
    d_conf = 1'b0;
    for (int i = 0; i < NCTX; i++)
      if (CW'(i) != dec_c && cx_st[i] != CX_FREE && cx_st[i] != CX_FETCH && cx_sq[i] == cx_sq[dec_c] &&
          cx_sqe[i][31:16] == d_cid) d_conf = 1'b1;
  end
  logic        d_sup, d_data, d_io_rw;
  logic [35:0] d_bytes;                          // transfer length
  always_comb begin
    d_sup = 1'b0; d_data = 1'b0; d_io_rw = 1'b0; d_bytes = '0;
    if (d_adm) begin
      case (d_opc)
        ADM_DELETE_SQ, ADM_CREATE_SQ, ADM_DELETE_CQ, ADM_CREATE_CQ: d_sup = 1'b1;
        ADM_IDENTIFY: begin d_sup = 1'b1; d_data = 1'b1; d_bytes = 36'd4096; end
        ADM_GET_LOG:  begin d_sup = 1'b1; d_data = 1'b1; d_bytes = {d_numd, 2'b00} + 36'd4; end
        ADM_ABORT, ADM_SET_FEAT, ADM_GET_FEAT, ADM_AER: d_sup = (ENABLE_EXT_ADMIN != 0);
        default: d_sup = 1'b0;
      endcase
    end else begin
      case (d_opc)
        IO_FLUSH: d_sup = 1'b1;
        IO_READ, IO_WRITE: begin d_sup = 1'b1; d_data = 1'b1; d_io_rw = 1'b1; d_bytes = {11'd0, d_c12[15:0], 9'd0} + 36'd512; end
        default: d_sup = 1'b0;
      endcase
    end
  end
  wire [XLW:0]  d_len   = (XLW+1)'(d_bytes);
  wire [XLW+1:0] d_last = (XLW+2)'(d_prp1[11:0]) + (XLW+2)'(d_bytes) - (XLW+2)'(1);
  wire [PW:0]   d_npg   = (PW+1)'(d_last >> 12) + (PW+1)'(1);
  logic [11:0]  d_st;
  logic [15:0]  d_ploc;
  logic [3:0]   d_next;
  always_comb begin
    d_st = ST_OK; d_ploc = 16'hFFFF; d_next = CX_DONE;
    if (!d_sup)                                          begin d_st = st(1, SCT_GEN, SC_INVALID_OPCODE); d_ploc = 16'h0000; end
    else if (d_fuse != 2'b00)                            begin d_st = st(1, SCT_GEN, SC_INVALID_FIELD);  d_ploc = 16'h0001; end
    else if (d_psdt != 2'b00)                            begin d_st = st(1, SCT_GEN, SC_INVALID_FIELD);  d_ploc = 16'h0601; end
    else if (d_conf)                                     begin d_st = st(1, SCT_GEN, SC_CID_CONFLICT);   d_ploc = 16'h0002; end
    else if (!d_adm && d_opc == IO_FLUSH && !(d_nsid == 32'd1 || d_nsid == 32'hFFFF_FFFF))
                                                         begin d_st = st(1, SCT_GEN, SC_INVALID_NS);     d_ploc = 16'h0004; end
    else if (d_io_rw && d_nsid != 32'd1)                 begin d_st = st(1, SCT_GEN, SC_INVALID_NS);     d_ploc = 16'h0004; end
    else if (d_io_rw && d_c12[23:20] != 4'd0)            begin d_st = st(1, SCT_GEN, SC_INVALID_FIELD);  d_ploc = 16'h0432; end
    else if (d_data && (d_bytes > 36'(max_bytes)))       begin d_st = st(1, SCT_GEN, SC_INVALID_FIELD);
                                                               d_ploc = d_io_rw ? 16'h0030 : 16'h0042; end
    else if (d_io_rw && d_lend > {1'b0, be_capacity})    begin d_st = st(1, SCT_GEN, SC_LBA_RANGE);      d_ploc = 16'h0028; end
    else if (d_data && d_prp1[1:0] != 2'b00)             begin d_st = st(1, SCT_GEN, SC_PRP_OFFSET);     d_ploc = 16'h0018; end
    else if (d_data && d_npg == (PW+1)'(2) && d_prp2[11:0] != 12'h0)
                                                         begin d_st = st(1, SCT_GEN, SC_PRP_OFFSET);     d_ploc = 16'h0020; end
    else if (d_data && d_npg > (PW+1)'(2) && d_prp2[2:0] != 3'h0)
                                                         begin d_st = st(1, SCT_GEN, SC_PRP_OFFSET);     d_ploc = 16'h0020; end
    else if (d_data && d_npg > (PW+1)'(2))               d_next = CX_PRP;
    else if (d_adm)                                      d_next = CX_ADM_RDY;
    else                                                 d_next = CX_BE_RDY;
  end

  // ================================================================ PRP-list engine
  logic          pe_busy, pe_rq, pe_half, pe_chain, pe_lp_bad;
  logic [CW-1:0] pe_c;
  logic [63:0]   pe_lp, pe_next_lp;
  logic [PW:0]   pe_need, pe_k;
  logic [9:0]    pe_cnt, pe_j;
  logic [31:0]   pe_lo;
  logic [11:0]   pe_st;
  logic          pick_prp_v;
  logic [CW-1:0] pick_prp_c;
  always_comb begin
    pick_prp_v = 1'b0;
    pick_prp_c = '0;
    for (int i = NCTX - 1; i >= 0; i--) if (cx_st[i] == CX_PRP) begin pick_prp_v = 1'b1; pick_prp_c = CW'(i); end
  end
  wire [9:0] pe_slots = 10'((13'd4096 - {1'b0, pe_lp[11:0]}) >> 3);
  wire       pe_more  = (10'(pe_need) > pe_slots);
  wire [9:0] pe_rcnt  = pe_more ? pe_slots : 10'(pe_need);
  assign rq_v[ID_PRP] = pe_rq;
  assign rq_a[ID_PRP] = pe_lp;
  assign rq_l[ID_PRP] = {pe_cnt, 3'b000};
  wire        pe_beat  = ard_rsp_valid && (ard_rsp_id == 2'(ID_PRP));
  wire [63:0] pe_entry = {ard_rsp_data, pe_lo};
  wire        pe_is_chain = pe_chain && (pe_j == pe_cnt - 10'd1);

  // ================================================================ back-end dispatch
  logic          bd_v;
  logic [CW-1:0] bd_c;
  always_comb begin
    bd_v = 1'b0;
    bd_c = '0;
    for (int i = NCTX - 1; i >= 0; i--) if (cx_st[i] == CX_BE_RDY) begin bd_v = 1'b1; bd_c = CW'(i); end
  end
  wire [511:0] b_sqe = cx_sqe[bd_c];
  wire [7:0]   b_opc = b_sqe[7:0];
  wire         bd_go = bd_v && !be_cmd_valid && !resetting;
  sfs_cmd_t    bd_cmd;
  always_comb begin
    bd_cmd = '0;
    bd_cmd.addr_type = 1'b0;                                     // logical (LBA)
    bd_cmd.tid       = {cx_gen[bd_c] + 8'd0, 8'(bd_c)};
    bd_cmd.host_addr = 64'(bd_c) << WIN_LOG2;
    case (b_opc)
      IO_READ: begin
        bd_cmd.opcode = 8'(SFS_OP_READ);  bd_cmd.dir = 2'(SFS_DIR_TO_HOST);
        bd_cmd.addr = {dw(b_sqe, 11), dw(b_sqe, 10)}; bd_cmd.len = 32'(dw(b_sqe, 12) & 32'h0000_FFFF) + 32'd1;
      end
      IO_WRITE: begin
        bd_cmd.opcode = 8'(SFS_OP_WRITE); bd_cmd.dir = 2'(SFS_DIR_FROM_HOST);
        bd_cmd.addr = {dw(b_sqe, 11), dw(b_sqe, 10)}; bd_cmd.len = 32'(dw(b_sqe, 12) & 32'h0000_FFFF) + 32'd1;
        bd_cmd.flags = {6'd0, b_sqe[32*12 + 30] || !vwc_wce, 1'b0};   // FUA, or every write when WCE = 0
      end
      default: begin
        bd_cmd.opcode = 8'(SFS_OP_FLUSH); bd_cmd.dir = 2'(SFS_DIR_NONE);
      end
    endcase
  end
  // completion from the back end
  wire [CW-1:0] bc_c   = be_cpl.tid[CW-1:0];
  wire          bc_ok  = be_cpl_valid && (be_cpl.tid[7:0] < 8'(NCTX)) && (cx_st[bc_c] == CX_BE_WAIT) &&
                         (cx_gen[bc_c] == be_cpl.tid[15:8]);
  assign be_cpl_ready = 1'b1;
  function automatic logic [11:0] map_be(input logic [6:0] s, input logic [7:0] opc);
    case (s)
      7'(SFS_ST_SUCCESS):        map_be = ST_OK;
      7'(SFS_ST_INVALID_FIELD):  map_be = st(1, SCT_GEN, SC_INVALID_FIELD);
      7'(SFS_ST_DATA_XFER_ERR):  map_be = st(0, SCT_GEN, SC_DATA_XFER_ERR);
      7'(SFS_ST_ABORT_PWR_LOSS): map_be = st(0, SCT_GEN, SC_ABORT_PWR_LOSS);
      7'(SFS_ST_LBA_RANGE):      map_be = st(1, SCT_GEN, SC_LBA_RANGE);
      7'(SFS_ST_CAPACITY):       map_be = st(1, SCT_GEN, SC_CAP_EXCEEDED);
      7'(SFS_ST_ACCESS_DENIED):  map_be = st(1, SCT_MEDIA, SC_ACCESS_DENIED);
      7'(SFS_ST_MEDIA_UNREC):    map_be = st(1, SCT_MEDIA, SC_UNREC_READ);
      7'(SFS_ST_MEDIA_WRITE),
      7'(SFS_ST_MEDIA_ERASE):    map_be = st(1, SCT_MEDIA, SC_WRITE_FAULT);
      7'(SFS_ST_MEDIA_TIMEOUT):  map_be = (opc == IO_READ) ? st(0, SCT_MEDIA, SC_UNREC_READ) : st(0, SCT_MEDIA, SC_WRITE_FAULT);
      default:                   map_be = st(0, SCT_GEN, SC_INTERNAL);
    endcase
  endfunction

  // ================================================================ admin engine
  localparam logic [1:0] AE_IDLE = 2'd0, AE_EXEC = 2'd1, AE_DATA = 2'd2, AE_WSQ = 2'd3;
  logic [1:0]    ae_st;
  logic [CW-1:0] ae_c;
  logic [XLW-1:0] ae_off;            // bytes sent
  logic [31:0]   ae_w;               // generator DW index
  logic [10:0]   ae_beat;
  logic [2:0]    ae_sel;
  logic [10:0]   ae_size_dw;         // structure size, DWs
  logic          ae_pick_v;
  logic [CW-1:0] ae_pick_c;
  always_comb begin
    logic [7:0] best;
    ae_pick_v = 1'b0;
    ae_pick_c = '0;
    best      = '0;
    for (int i = 0; i < NCTX; i++)
      if (cx_st[i] == CX_ADM_RDY && (!ae_pick_v || 8'(seq_next - cx_seq[i]) > best)) begin
        ae_pick_v = 1'b1; ae_pick_c = CW'(i); best = 8'(seq_next - cx_seq[i]);
      end
  end
  wire [511:0] a_sqe  = cx_sqe[ae_c];
  wire [7:0]   a_opc  = a_sqe[7:0];
  wire [31:0]  a_nsid = dw(a_sqe, 1);
  wire [63:0]  a_prp1 = {dw(a_sqe, 7), dw(a_sqe, 6)};
  wire [31:0]  a_c10  = dw(a_sqe, 10);
  wire [31:0]  a_c11  = dw(a_sqe, 11);
  wire [63:0]  a_lpo  = {dw(a_sqe, 13), dw(a_sqe, 12)};
  wire [15:0]  a_qid  = a_c10[15:0];
  wire [15:0]  a_qsz  = a_c10[31:16];
  wire [QIW-1:0] a_q  = a_qid[QIW-1:0];
  wire         a_qid_ok  = (a_qid != 16'd0) && (a_qid <= 16'(NUM_IOQ));
  wire         a_qsz_ok  = (a_qsz != 16'd0) && (a_qsz <= 16'(MQES));
  wire [15:0]  a_cqid    = a_c11[31:16];
  wire [15:0]  a_iv      = a_c11[31:16];
  wire [64:0]  a_cq_end  = {1'b0, a_prp1} + 65'({a_qsz, 4'h0}) + 65'd15;
  wire [64:0]  a_sq_end  = {1'b0, a_prp1} + 65'({a_qsz, 6'h0}) + 65'd63;
  wire         a_any_ioq = |sq_v[NQ-1:1] || |cq_v[NQ-1:1];
  logic        a_sq_uses_cq;
  always_comb begin
    a_sq_uses_cq = 1'b0;
    for (int i = 1; i < NQ; i++) if (sq_v[i] && sq_cqid[i*QIW +: QIW] == a_q) a_sq_uses_cq = 1'b1;
  end
  logic        a_sq_busy;                       // commands of the SQ being deleted still in flight
  always_comb begin
    a_sq_busy = 1'b0;
    for (int i = 0; i < NCTX; i++) if (CW'(i) != ae_c && cx_st[i] != CX_FREE && cx_sq[i] == a_q) a_sq_busy = 1'b1;
  end
  // log-page geometry
  logic        a_log_ok;
  logic [10:0] a_log_dw;
  logic [2:0]  a_log_sel;
  always_comb begin
    a_log_ok = 1'b1; a_log_dw = 11'd128; a_log_sel = 3'd5;
    case (a_c10[7:0])
      LID_ERROR:   begin a_log_dw = 11'(NERR * 16); a_log_sel = 3'd4; end
      LID_SMART:   a_log_sel = 3'd5;
      LID_FW_SLOT: a_log_sel = 3'd6;
      LID_VS_PERF: a_log_sel = 3'd7;
      default:     a_log_ok = 1'b0;
    endcase
  end
  // AER bookkeeping
  localparam int NAER = AERL + 1;
  logic [15:0] aer_cid [NAER];
  logic [$clog2(NAER+1)-1:0] aer_n;
  logic        ev_pend, ev_masked;
  logic [7:0]  ev_info;

  // admin execution result (combinational on ae_c, evaluated in AE_EXEC)
  logic [11:0] ax_st;
  logic [31:0] ax_dw0;
  logic        ax_data, ax_cr, ax_dl, ax_sd, ax_aer, ax_vwc_set, ax_clr_mask;
  logic [2:0]  ax_sel;
  logic [10:0] ax_size;
  logic [31:0] ax_w0;
  always_comb begin
    ax_st = ST_OK; ax_dw0 = '0; ax_data = 1'b0; ax_cr = 1'b0; ax_dl = 1'b0; ax_sd = 1'b0; ax_aer = 1'b0;
    ax_vwc_set = 1'b0; ax_clr_mask = 1'b0; ax_sel = 3'd3; ax_size = 11'd1024; ax_w0 = '0;
    case (a_opc)
      ADM_IDENTIFY: begin
        case (a_c10[7:0])
          CNS_NS:      if (a_nsid == 32'd1) begin ax_data = 1'b1; ax_sel = 3'd1; end
                       else ax_st = st(1, SCT_GEN, SC_INVALID_NS);
          CNS_CTRL:    begin ax_data = 1'b1; ax_sel = 3'd0; end
          CNS_NS_LIST: if (a_nsid < 32'hFFFF_FFFE) begin ax_data = 1'b1; ax_sel = 3'd2; end
                       else ax_st = st(1, SCT_GEN, SC_INVALID_NS);
          CNS_NS_DESC: if (a_nsid == 32'd1) begin ax_data = 1'b1; ax_sel = 3'd3; end
                       else ax_st = st(1, SCT_GEN, SC_INVALID_NS);
          default:     ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        endcase
      end
      ADM_GET_LOG: begin
        if (!a_log_ok)                                          ax_st = st(1, SCT_CMD, SC_INVALID_LOG);
        else if (!(a_nsid == 32'd0 || a_nsid == 32'hFFFF_FFFF)) ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        else if (a_lpo[1:0] != 2'b00 || a_lpo >= 64'({a_log_dw, 2'b00}))
                                                                ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        else begin
          ax_data = 1'b1; ax_sel = a_log_sel; ax_size = a_log_dw; ax_w0 = 32'(a_lpo >> 2);
          ax_clr_mask = (a_c10[7:0] == LID_ERROR) && !a_c10[15];          // RAE = 0
        end
      end
      ADM_CREATE_CQ: begin
        if (!a_qid_ok || cq_v[a_q])                    ax_st = st(1, SCT_CMD, SC_INVALID_QID);
        else if (!a_qsz_ok)                            ax_st = st(1, SCT_CMD, SC_INVALID_QSIZE);
        else if (!a_c11[0] || cc_q[23:20] != 4'd4)     ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        else if (a_iv >= 16'(NUM_VEC))                 ax_st = st(1, SCT_CMD, SC_INVALID_IV);
        else if (a_prp1[11:0] != 12'h0)                ax_st = st(1, SCT_GEN, SC_PRP_OFFSET);
        else if (a_cq_end[64])                         ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        else ax_cr = 1'b1;
      end
      ADM_CREATE_SQ: begin
        if (!a_qid_ok || sq_v[a_q])                    ax_st = st(1, SCT_CMD, SC_INVALID_QID);
        else if (!a_qsz_ok)                            ax_st = st(1, SCT_CMD, SC_INVALID_QSIZE);
        else if (!a_c11[0] || cc_q[19:16] != 4'd6)     ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        else if (a_cqid == 16'd0 || a_cqid > 16'(NUM_IOQ) || !cq_v[a_cqid[QIW-1:0]])
                                                       ax_st = st(1, SCT_CMD, SC_CQ_INVALID);
        else if (a_prp1[11:0] != 12'h0)                ax_st = st(1, SCT_GEN, SC_PRP_OFFSET);
        else if (a_sq_end[64])                         ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        else ax_cr = 1'b1;
      end
      ADM_DELETE_SQ: begin
        if (!a_qid_ok || !sq_v[a_q])                   ax_st = st(1, SCT_CMD, SC_INVALID_QID);
        else ax_sd = 1'b1;
      end
      ADM_DELETE_CQ: begin
        if (!a_qid_ok || !cq_v[a_q])                   ax_st = st(1, SCT_CMD, SC_INVALID_QID);
        else if (a_sq_uses_cq)                         ax_st = st(1, SCT_CMD, SC_INVALID_QDEL);
        else ax_dl = 1'b1;
      end
      ADM_SET_FEAT: begin
        if (a_c10[31])                                 ax_st = st(1, SCT_CMD, SC_FEAT_NOT_SAVE);
        else if (a_c10[7:0] == FID_NUM_Q) begin
          if (a_any_ioq)                               ax_st = st(1, SCT_GEN, SC_CMD_SEQ_ERR);
          else if (a_c11[15:0] == 16'hFFFF || a_c11[31:16] == 16'hFFFF) ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
          else ax_dw0 = {16'(NUM_IOQ - 1), 16'(NUM_IOQ - 1)};
        end else if (a_c10[7:0] == FID_VWC) ax_vwc_set = 1'b1;
        else                                           ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
      end
      ADM_GET_FEAT: begin
        if (a_c10[10:8] > 3'd3)                        ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
        else if (a_c10[7:0] == FID_NUM_Q)
          ax_dw0 = (a_c10[10:8] == 3'd3) ? 32'h0 : {16'(NUM_IOQ - 1), 16'(NUM_IOQ - 1)};
        else if (a_c10[7:0] == FID_VWC)
          ax_dw0 = (a_c10[10:8] == 3'd3) ? 32'h4 : ((a_c10[10:8] == 3'd0) ? {31'd0, vwc_wce} : 32'd1);
        else                                           ax_st = st(1, SCT_GEN, SC_INVALID_FIELD);
      end
      ADM_ABORT: ax_dw0 = 32'd1;                                  // best effort: command not aborted
      ADM_AER: begin
        if (32'(aer_n) >= NAER)                        ax_st = st(1, SCT_CMD, SC_AER_LIMIT);
        else ax_aer = 1'b1;
      end
      default: ax_st = st(1, SCT_GEN, SC_INVALID_OPCODE);
    endcase
  end
  // admin data segment (current page)
  wire [XLW:0]   ae_pos  = (XLW+1)'(a_prp1[11:0]) + (XLW+1)'(ae_off);
  wire [11:0]    ae_inpg = ae_pos[11:0];
  wire [PW-1:0]  ae_page = PW'(ae_pos >> 12);
  wire [XLW-1:0] ae_rem  = cx_xlen[ae_c] - ae_off;
  wire [12:0]    ae_tpg  = 13'd4096 - {1'b0, ae_inpg};
  wire [12:0]    ae_seg  = ((XLW+1)'(ae_rem) < (XLW+1)'(ae_tpg)) ? 13'(ae_rem) : ae_tpg;
  logic [31:0]   gen_word;
  assign wq_v[WR_ADM]    = (ae_st == AE_DATA);
  assign wq_a[WR_ADM]    = {prp_tab[32'(ae_c) * MAXP + 32'(ae_page)], ae_inpg};
  assign wq_l[WR_ADM]    = ae_seg;
  assign wq_d[WR_ADM]    = (ae_w < 32'(ae_size_dw)) ? gen_word : 32'h0;
  assign wq_last[WR_ADM] = (ae_beat == ae_seg[12:2] - 11'd1);

  // ================================================================ completion engine
  localparam logic [1:0] CE_IDLE = 2'd0, CE_WR = 2'd1, CE_POST = 2'd2;
  logic [1:0]     ce_st;
  logic [CW-1:0]  ce_c;
  logic           ce_aer;
  logic [QIW-1:0] ce_q;
  logic [63:0]    ce_addr;
  logic [31:0]    ce_w [4];
  logic [1:0]     ce_beat;
  logic [CW-1:0]  rr_ce;
  logic           wc_empty, win_idle;
  logic           cp_v;
  logic [CW-1:0]  cp_c;
  function automatic logic [QIW-1:0] cq_of(input logic [QIW-1:0] sq, input logic [NQ*QIW-1:0] map);
    cq_of = map[sq*QIW +: QIW];
  endfunction
  always_comb begin
    cp_v = 1'b0;
    cp_c = '0;
    for (int k = NCTX - 1; k >= 0; k--) begin
      logic [CW-1:0]  i;
      logic [QIW-1:0] q;
      i = rr_ce + CW'(k);
      q = cq_of(cx_sq[i], sq_cqid);
      if (cx_st[i] == CX_DONE && cq_v[q] && !cq_full[q] && (!cx_win[i] || wc_empty)) begin cp_v = 1'b1; cp_c = i; end
    end
  end
  wire aer_go   = (ENABLE_EXT_ADMIN != 0) && (aer_n != '0) && ev_pend && cq_v[0] && !cq_full[0];
  wire ce_start = (ce_st == CE_IDLE) && !resetting && (aer_go || cp_v);
  wire [QIW-1:0] cp_q = cq_of(cx_sq[cp_c], sq_cqid);
  assign wq_v[WR_CPL]    = (ce_st == CE_WR);
  assign wq_a[WR_CPL]    = ce_addr;
  assign wq_l[WR_CPL]    = 13'd16;
  assign wq_d[WR_CPL]    = ce_w[ce_beat];
  assign wq_last[WR_CPL] = (ce_beat == 2'd3);
  logic win_flush;
  always_comb begin
    win_flush = 1'b0;
    for (int i = 0; i < NCTX; i++) if (cx_st[i] == CX_DONE && cx_win[i]) win_flush = 1'b1;
  end

  // ================================================================ host-memory window
  logic [CW-1:0] lk_slot, lk2_slot;
  logic [PW-1:0] lk_page, lk2_page;
  logic          w_rd_v, w_wr_v, w_wr_last, w_ev_rd, w_ev_wr, w_ev_ref, bc_inval;
  logic [63:0]   w_rd_a, w_wr_a;
  logic [12:0]   w_rd_l, w_wr_l;
  logic [31:0]   w_wr_d;
  wire  [31:0]   lk_idx  = 32'(lk_slot) * MAXP + ((32'(lk_page) < MAXP) ? 32'(lk_page) : 32'd0);
  wire  [31:0]   lk2_idx = 32'(lk2_slot) * MAXP + ((32'(lk2_page) < MAXP) ? 32'(lk2_page) : 32'd0);
  sfn_hostwin #(.CW(CW), .WIN_LOG2(WIN_LOG2), .XLW(XLW), .PW(PW), .PF_BYTES(PF_BYTES), .PF_CHUNK(PF_CHUNK), .PF_INF(PF_INF),
                .WC_BYTES(WC_BYTES), .WC_IDLE(WC_IDLE)) u_win (
    .clk, .rst_n,
    .s_req_valid(hw_req_valid), .s_req_ready(hw_req_ready), .s_req_write(hw_req_write), .s_req_addr(hw_req_addr),
    .s_req_wdata(hw_req_wdata), .s_req_wstrb(hw_req_wstrb), .s_rsp_valid(hw_rsp_valid), .s_rsp_ready(hw_rsp_ready),
    .s_rsp_rdata(hw_rsp_rdata), .s_rsp_error(hw_rsp_error),
    .lk_slot, .lk_page,
    .lk_ok(cx_st[lk_slot] == CX_BE_WAIT && cx_win[lk_slot]), .lk_to_host(cx_toh[lk_slot]),
    .lk_len(cx_xlen[lk_slot]), .lk_off1(cx_sqe[lk_slot][32*6 +: 12]), .lk_paddr(prp_tab[lk_idx]),
    .lk2_slot, .lk2_page, .lk2_paddr(prp_tab[lk2_idx]),
    .rd_req_valid(w_rd_v), .rd_req_ready(rq_ack[ID_WIN]), .rd_req_addr(w_rd_a), .rd_req_len(w_rd_l),
    .rd_rsp_valid(ard_rsp_valid && ard_rsp_id == 2'(ID_WIN)), .rd_rsp_data(ard_rsp_data), .rd_rsp_err(ard_rsp_err),
    .rd_rsp_last(ard_rsp_last),
    .wr_valid(w_wr_v), .wr_ready(wq_ack[WR_WIN]), .wr_addr(w_wr_a), .wr_len(w_wr_l), .wr_data(w_wr_d), .wr_last(w_wr_last),
    .flush_req(win_flush), .kill(resetting), .inval_v(bc_inval), .inval_slot(bc_c),
    .wc_empty, .idle(win_idle), .ev_rd_word(w_ev_rd), .ev_wr_word(w_ev_wr), .ev_refused(w_ev_ref)
  );
  assign rq_v[ID_WIN]    = w_rd_v;
  assign rq_a[ID_WIN]    = w_rd_a;
  assign rq_l[ID_WIN]    = w_rd_l;
  assign wq_v[WR_WIN]    = w_wr_v;
  assign wq_a[WR_WIN]    = w_wr_a;
  assign wq_l[WR_WIN]    = w_wr_l;
  assign wq_d[WR_WIN]    = w_wr_d;
  assign wq_last[WR_WIN] = w_wr_last;
  assign bc_inval = bc_ok;

  // ================================================================ statistics, error log, performance counters
  localparam int EW = 64 + 16 + 16 + 12 + 16 + 64 + 32;
  logic [EW-1:0]  elog_r [NERR];
  logic [$clog2(NERR)-1:0] elog_wp;
  logic [63:0]    err_cnt, s_hrc, s_hwc, s_busy, s_media, dur_k, duw_k;
  logic [9:0]     dur_r, duw_r;
  logic [63:0]    busy_cyc;
  logic [NERR*EW-1:0] elog_flat;
  always_comb begin
    for (int e = 0; e < NERR; e++)
      elog_flat[e*EW +: EW] = elog_r[$clog2(NERR)'(elog_wp - $clog2(NERR)'(e + 1))];
  end
  logic [31:0] pc [NPERF];
  always_comb for (int i = 0; i < NPERF; i++) perf[i*32 +: 32] = pc[i];
  logic intx_q;

  sfn_admin_data #(.NERR(NERR), .NPERF(NPERF), .PCI_VID(PCI_VID), .PCI_SSVID(PCI_SSVID), .VS(SFN_NVME_VS)) u_data (
    .sel(ae_sel), .widx(ae_w[9:0]), .nsid_field(a_nsid), .nsze(be_capacity), .mdts(mdts_f),
    .aerl((ENABLE_EXT_ADMIN != 0) ? 8'(AERL) : 8'd0), .elog(elog_flat),
    .s_dur(dur_k + {63'd0, dur_r != 10'd0}), .s_duw(duw_k + {63'd0, duw_r != 10'd0}), .s_hrc, .s_hwc,
    .s_busy, .s_media, .s_errs(err_cnt), .perf, .word(gen_word)
  );

  // ================================================================ interrupts
  logic ev_msi;
  sfn_irq #(.NQ(NQ), .NVEC(NUM_VEC)) u_irq (
    .clk, .rst_n, .clear(soft_clr),
    .cq_v, .cq_ien, .cq_iv, .cq_pend,
    .post_evt(ce_st == CE_POST), .post_qid(ce_q), .head_evt(db_cq_ok), .head_qid(rdb_qid[QIW-1:0]),
    .im_set_v, .im_clr_v, .im_wdata,
    .cfg_msi_en, .cfg_msi_mme, .cfg_intx_dis,
    .msi_valid, .msi_ready, .msi_vector, .intx_assert, .intms, .ev_msi
  );
  assign fe_db_err = db_bad_reg || db_bad_val;

  // ================================================================ reset quiescence
  logic all_free;
  always_comb begin
    all_free = 1'b1;
    for (int i = 0; i < NCTX; i++) if (cx_st[i] != CX_FREE) all_free = 1'b0;
  end
  wire quiet = all_free && (f_out == '0) && !f_req_v && !pe_busy && (ae_st == AE_IDLE) && (ce_st == CE_IDLE) &&
               !be_cmd_valid && win_idle && ad_rd_idle && ad_wr_idle && (wg == 2'd3) && be_idle;
  wire rst_done = resetting && quiet;
  assign soft_clr      = rst_done;
  assign flr_clr       = rst_done && flr_pend;
  assign qm_clear      = rst_done;
  assign fe_reset_done = rst_done;
  assign qm_admin_init = (cs == CS_DIS) && cc_en && cfg_ok;

  // io busy (controller busy time)
  logic io_busy;
  always_comb begin
    io_busy = 1'b0;
    for (int i = 0; i < NCTX; i++) if (cx_st[i] != CX_FREE && cx_st[i] != CX_FETCH && !cx_adm[i]) io_busy = 1'b1;
  end

  // ================================================================ queue-manager control (combinational pulses)
  assign fi_valid = f_go;
  assign fi_qid   = f_pick_q;
  assign fd_valid = f_beat_v && (f_beat == 4'd15) && !f_err && !ard_rsp_err && !resetting;
  assign fd_qid   = cx_sq[f_head_c];
  assign po_valid = (ce_st == CE_POST);
  assign po_qid   = ce_q;
  assign cr_valid = (ae_st == AE_EXEC) && !resetting && ax_cr;
  assign cr_cq    = (a_opc == ADM_CREATE_CQ);
  assign cr_qid   = a_q;
  assign cr_base  = a_prp1[63:12];
  assign cr_size  = a_qsz;
  assign cr_cqid  = a_cqid[QIW-1:0];
  assign cr_ien   = a_c11[1];
  assign cr_iv    = a_iv[4:0];
  assign sd_valid = (ae_st == AE_EXEC) && !resetting && ax_sd;
  assign sd_qid   = a_q;
  assign dl_valid = ((ae_st == AE_EXEC) && !resetting && ax_dl) || ((ae_st == AE_WSQ) && !a_sq_busy && !resetting);
  assign dl_cq    = (ae_st == AE_EXEC);
  assign dl_qid   = a_q;

  // ================================================================ PRP table storage (no reset: written before use)
  always_ff @(posedge clk) begin
    if (dec_v && !resetting && d_data) begin
      prp_tab[32'(dec_c) * MAXP]     <= d_prp1[63:12];
      prp_tab[32'(dec_c) * MAXP + 1] <= d_prp2[63:12];
    end
    if (pe_beat && pe_half && !pe_is_chain && 32'(pe_k) < MAXP) prp_tab[32'(pe_c) * MAXP + 32'(pe_k)] <= pe_entry[63:12];
  end

  // ================================================================ sequential
  wire ae_seg_end = (ae_st == AE_DATA) && wq_ack[WR_ADM] && wq_last[WR_ADM];
  wire ae_all_end = ae_seg_end && (ae_off + XLW'(ae_seg) == cx_xlen[ae_c]);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      now <= '0; cs <= CS_DIS; rdy_q <= 1'b0; fatal_q <= 1'b0; flr_pend <= 1'b0; vwc_wce <= 1'b1;
      rr_rd <= '0; rr_wr <= '0; wg <= 2'd3; seq_next <= '0;
      for (int i = 0; i < NCTX; i++) begin
        cx_st[i] <= CX_FREE; cx_sqe[i] <= '0; cx_sq[i] <= '0; cx_seq[i] <= '0; cx_gen[i] <= '0; cx_stat[i] <= '0;
        cx_dw0[i] <= '0; cx_ploc[i] <= '0; cx_xlen[i] <= '0; cx_npg[i] <= '0; cx_adm[i] <= 1'b0; cx_win[i] <= 1'b0;
        cx_toh[i] <= 1'b0; cx_tf[i] <= '0; cx_tb[i] <= '0;
      end
      f_req_v <= 1'b0; f_req_a <= '0; f_out <= '0; f_wp <= '0; f_rp <= '0; f_beat <= '0; f_err <= 1'b0; rr_f <= '0;
      for (int i = 0; i < FETCH_OUT; i++) f_fifo_c[i] <= '0;
      pe_busy <= 1'b0; pe_rq <= 1'b0; pe_half <= 1'b0; pe_chain <= 1'b0; pe_lp_bad <= 1'b0; pe_c <= '0; pe_lp <= '0;
      pe_next_lp <= '0; pe_need <= '0; pe_k <= '0; pe_cnt <= '0; pe_j <= '0; pe_lo <= '0; pe_st <= ST_OK;
      be_cmd_valid <= 1'b0; be_cmd <= '0;
      ae_st <= AE_IDLE; ae_c <= '0; ae_off <= '0; ae_w <= '0; ae_beat <= '0; ae_sel <= '0; ae_size_dw <= '0;
      for (int i = 0; i < NAER; i++) aer_cid[i] <= '0;
      aer_n <= '0; ev_pend <= 1'b0; ev_masked <= 1'b0; ev_info <= '0;
      ce_st <= CE_IDLE; ce_c <= '0; ce_aer <= 1'b0; ce_q <= '0; ce_addr <= '0; ce_beat <= '0; rr_ce <= '0;
      for (int i = 0; i < 4; i++) ce_w[i] <= '0;
      for (int i = 0; i < NERR; i++) elog_r[i] <= '0;
      elog_wp <= '0; err_cnt <= '0; s_hrc <= '0; s_hwc <= '0; s_busy <= '0; s_media <= '0; dur_k <= '0; duw_k <= '0;
      dur_r <= '0; duw_r <= '0; busy_cyc <= '0;
      for (int i = 0; i < NPERF; i++) pc[i] <= '0;
      intx_q <= 1'b0;
    end else begin
      now <= now + 32'd1;
      // ============================================ controller state machine
      if (cfg_flr) flr_pend <= 1'b1;
      case (cs)
        CS_DIS: if (cfg_flr || flr_pend) cs <= CS_RST;
                else if (cc_en) begin
                  if (cfg_ok) cs <= CS_ENB;
                  else begin cs <= CS_ERR; fatal_q <= 1'b1; end
                end
        CS_ENB: if (!cc_en) cs <= CS_RST;
                else if (be_rdy) begin cs <= CS_RDY; rdy_q <= 1'b1; end
        CS_RDY: if (!cc_en) cs <= CS_RST;
        CS_ERR: if (!cc_en) cs <= CS_RST;
        CS_RST: if (quiet) begin
                  cs <= CS_DIS; rdy_q <= 1'b0; fatal_q <= 1'b0;
                  if (flr_pend && !cfg_flr) begin
                    flr_pend <= 1'b0; vwc_wce <= 1'b1;
                    for (int i = 0; i < NERR; i++) elog_r[i] <= '0;
                    elog_wp <= '0; err_cnt <= '0; s_hrc <= '0; s_hwc <= '0; s_busy <= '0; s_media <= '0;
                    dur_k <= '0; duw_k <= '0; dur_r <= '0; duw_r <= '0; busy_cyc <= '0;
                  end
                end
        default: cs <= CS_DIS;
      endcase

      // ============================================ read / write arbiters
      if (ard_valid && ard_ready) rr_rd <= 2'((32'(ard_id) + 1) % 3);
      if (wg == 2'd3) begin
        if (wg_next != 2'd3) begin wg <= wg_next; rr_wr <= 2'((32'(wg_next) + 1) % 3); end
      end else if (wr_rel) wg <= 2'd3;

      // ============================================ fetch
      if (f_go) begin
        f_req_v  <= 1'b1;
        f_req_a  <= {sq_base[f_pick_q*52 +: 52], 12'h000} + {42'd0, q16(sq_fptr, 32'(f_pick_q)), 6'd0};
        cx_st[free_c]  <= CX_FETCH;
        cx_sq[free_c]  <= f_pick_q;
        cx_seq[free_c] <= seq_next;
        cx_gen[free_c] <= cx_gen[free_c] + 8'd1;
        cx_tf[free_c]  <= now;
        seq_next       <= seq_next + 8'd1;
        f_fifo_c[f_wp] <= free_c;
        f_wp           <= f_wp + 1'b1;
        rr_f           <= QIW'((32'(f_pick_q) + 1) % NQ);
        pc[1]          <= pc[1] + 32'd1;
      end
      if (rq_ack[ID_FETCH]) f_req_v <= 1'b0;
      if (f_beat_v) begin
        cx_sqe[f_head_c][32*f_beat +: 32] <= ard_rsp_data;
        f_beat <= f_beat + 4'd1;
        if (ard_rsp_err) f_err <= 1'b1;
        if (f_beat == 4'd15) begin
          f_rp  <= f_rp + 1'b1;
          f_err <= 1'b0;
          if (f_err || ard_rsp_err || resetting) begin
            cx_st[f_head_c] <= CX_FREE;
            if (!resetting) begin fatal_q <= 1'b1; pc[31] <= pc[31] + 32'd1; end
          end else begin
            cx_st[f_head_c] <= CX_DECODE;
            pc[24] <= pc[24] + (now - cx_tf[f_head_c]);
            if (now - cx_tf[f_head_c] > pc[25]) pc[25] <= now - cx_tf[f_head_c];
          end
        end
      end
      f_out <= f_out + $bits(f_out)'(f_go) - $bits(f_out)'(f_beat_v && f_beat == 4'd15);

      // ============================================ decode
      if (dec_v) begin
        if (resetting) cx_st[dec_c] <= CX_FREE;
        else begin
          cx_st[dec_c]   <= d_next;
          cx_stat[dec_c] <= d_st;
          cx_ploc[dec_c] <= d_ploc;
          cx_dw0[dec_c]  <= '0;
          cx_adm[dec_c]  <= d_adm;
          cx_win[dec_c]  <= d_io_rw;
          cx_toh[dec_c]  <= !d_adm && (d_opc == IO_READ);
          cx_xlen[dec_c] <= XLW'(d_len);
          cx_npg[dec_c]  <= d_npg;
        end
      end

      // ============================================ PRP-list engine
      if (!pe_busy && pick_prp_v && !resetting) begin
        pe_busy <= 1'b1; pe_c <= pick_prp_c; pe_lp <= {dw(cx_sqe[pick_prp_c], 9), dw(cx_sqe[pick_prp_c], 8)};
        pe_need <= cx_npg[pick_prp_c] - (PW+1)'(1); pe_k <= (PW+1)'(1); pe_st <= ST_OK; pe_rq <= 1'b0;
        pe_j <= '0; pe_half <= 1'b0; pe_cnt <= '0;           // context stays CX_PRP, owned via pe_c
      end else if (pe_busy && !pe_rq && pe_cnt == 10'd0 && resetting) begin
        cx_st[pe_c] <= CX_FREE; pe_busy <= 1'b0;              // between list reads: stop
      end else if (pe_busy && !pe_rq && pe_cnt == 10'd0) begin
        // issue one list read: entries up to the end of the list page
        pe_rq <= 1'b1; pe_cnt <= pe_rcnt; pe_chain <= pe_more; pe_j <= '0; pe_half <= 1'b0;
      end
      if (rq_ack[ID_PRP]) pe_rq <= 1'b0;
      if (pe_beat) begin
        if (!pe_half) begin
          pe_lo <= ard_rsp_data; pe_half <= 1'b1;
        end else begin
          pe_half <= 1'b0;
          pe_j    <= pe_j + 10'd1;
          if (pe_is_chain) begin
            pe_next_lp <= pe_entry;
            if (pe_entry[2:0] != 3'b000 && pe_st == ST_OK) pe_st <= st(1, SCT_GEN, SC_PRP_OFFSET);
          end else begin
            if (pe_entry[11:0] != 12'h000 && pe_st == ST_OK) pe_st <= st(1, SCT_GEN, SC_PRP_OFFSET);
            pe_k    <= pe_k + (PW+1)'(1);
            pe_need <= pe_need - (PW+1)'(1);
          end
        end
        if (ard_rsp_err && pe_st == ST_OK) pe_st <= st(0, SCT_GEN, SC_DATA_XFER_ERR);
        if (ard_rsp_last) begin
          pe_cnt <= '0;
          if (resetting) begin
            cx_st[pe_c] <= CX_FREE; pe_busy <= 1'b0;
          end else if (ard_rsp_err || pe_st != ST_OK ||
                       (pe_is_chain ? (pe_entry[2:0] != 3'b000) : (pe_entry[11:0] != 12'h000))) begin
            cx_st[pe_c]   <= CX_DONE;
            cx_stat[pe_c] <= ard_rsp_err ? st(0, SCT_GEN, SC_DATA_XFER_ERR) :
                             ((pe_st != ST_OK) ? pe_st : st(1, SCT_GEN, SC_PRP_OFFSET));
            cx_ploc[pe_c] <= 16'h0020;
            pe_busy       <= 1'b0;
          end else if (pe_is_chain) begin
            pe_lp <= pe_entry;                                  // next list page; pe_cnt = 0 issues it
          end else begin
            cx_st[pe_c] <= cx_adm[pe_c] ? CX_ADM_RDY : CX_BE_RDY;
            pe_busy     <= 1'b0;
          end
        end
      end

      // ============================================ back-end dispatch / completion
      if (bd_go) begin
        be_cmd_valid <= 1'b1;
        be_cmd       <= bd_cmd;
        cx_st[bd_c]  <= CX_BE_WAIT;
        cx_tb[bd_c]  <= now;
      end else if (be_cmd_valid && be_cmd_ready) be_cmd_valid <= 1'b0;
      if (bc_ok) begin
        cx_st[bc_c]   <= resetting ? CX_FREE : CX_DONE;
        cx_stat[bc_c] <= map_be(be_cpl.status, cx_sqe[bc_c][7:0]);
        cx_ploc[bc_c] <= 16'hFFFF;
        pc[17] <= pc[17] + (now - cx_tb[bc_c]);
        if (now - cx_tb[bc_c] > pc[18]) pc[18] <= now - cx_tb[bc_c];
      end else if (be_cpl_valid) pc[27] <= pc[27] + 32'd1;

      // ============================================ admin engine
      case (ae_st)
        AE_IDLE: if (ae_pick_v && !resetting) begin
          ae_c <= ae_pick_c; cx_st[ae_pick_c] <= CX_ADM_RUN; ae_st <= AE_EXEC;
        end
        AE_EXEC: begin
          if (resetting) begin
            cx_st[ae_c] <= CX_FREE; ae_st <= AE_IDLE;
          end else if (ax_data && ax_st == ST_OK) begin
            ae_st <= AE_DATA; ae_off <= '0; ae_w <= ax_w0; ae_beat <= '0; ae_sel <= ax_sel; ae_size_dw <= ax_size;
          end else if (ax_sd) begin
            ae_st <= AE_WSQ;
          end else if (ax_aer) begin
            cx_st[ae_c]    <= CX_FREE;                          // AER: no completion until an event
            ae_st          <= AE_IDLE;
          end else begin
            if (ax_vwc_set) vwc_wce <= a_c11[0];
            cx_st[ae_c] <= CX_DONE; cx_stat[ae_c] <= ax_st; cx_dw0[ae_c] <= ax_dw0;
            cx_ploc[ae_c] <= (ax_st == ST_OK) ? 16'hFFFF : 16'h0028;
            ae_st <= AE_IDLE;
          end
        end
        AE_DATA: begin
          if (wq_ack[WR_ADM]) begin
            ae_w <= ae_w + 32'd1;
            ae_beat <= wq_last[WR_ADM] ? 11'd0 : ae_beat + 11'd1;
          end
          if (ae_seg_end) begin
            ae_off <= ae_off + XLW'(ae_seg);
            if (ae_all_end || resetting) begin
              cx_st[ae_c] <= resetting ? CX_FREE : CX_DONE; cx_stat[ae_c] <= ST_OK; cx_dw0[ae_c] <= '0;
              ae_st <= AE_IDLE;
            end
          end
        end
        AE_WSQ: begin
          if (resetting) begin cx_st[ae_c] <= CX_FREE; ae_st <= AE_IDLE; end
          else if (!a_sq_busy) begin
            cx_st[ae_c] <= CX_DONE; cx_stat[ae_c] <= ST_OK; cx_dw0[ae_c] <= '0; ae_st <= AE_IDLE;
          end
        end
        default: ae_st <= AE_IDLE;
      endcase


      // ============================================ completion engine
      case (ce_st)
        CE_IDLE: if (ce_start) begin
          ce_st   <= CE_WR;
          ce_beat <= '0;
          if (aer_go) begin
            ce_aer  <= 1'b1;
            ce_q    <= '0;
            ce_addr <= {cq_base[51:0], 12'h000} + {44'd0, q16(cq_tail, 0), 4'h0};
            ce_w[0] <= {8'h00, LID_ERROR, ev_info, 5'd0, 3'd0};          // AET 0 (error status)
            ce_w[1] <= '0;
            ce_w[2] <= {16'h0000, q16(sq_head, 0)};
            ce_w[3] <= cqe_dw3(ST_OK, cq_ph[0], aer_cid[0]);
          end else begin
            ce_aer  <= 1'b0;
            ce_c    <= cp_c;
            ce_q    <= cp_q;
            ce_addr <= {cq_base[cp_q*52 +: 52], 12'h000} + {44'd0, q16(cq_tail, 32'(cp_q)), 4'h0};
            ce_w[0] <= cx_dw0[cp_c];
            ce_w[1] <= '0;
            ce_w[2] <= {16'(cx_sq[cp_c]), q16(sq_head, 32'(cx_sq[cp_c]))};
            ce_w[3] <= cqe_dw3(cx_stat[cp_c], cq_ph[cp_q], cx_sqe[cp_c][31:16]);
            cx_st[cp_c] <= CX_POST;
            rr_ce   <= cp_c + 1'b1;
          end
        end
        CE_WR: if (wq_ack[WR_CPL]) begin
          ce_beat <= ce_beat + 2'd1;
          if (ce_beat == 2'd3) ce_st <= CE_POST;
        end
        CE_POST: begin
          ce_st <= CE_IDLE;
          pc[2] <= pc[2] + 32'd1;
          if (!ce_aer) begin
            cx_st[ce_c] <= CX_FREE;
            pc[15] <= pc[15] + (now - cx_tf[ce_c]);
            if (now - cx_tf[ce_c] > pc[16]) pc[16] <= now - cx_tf[ce_c];
            if (cx_adm[ce_c]) pc[6] <= pc[6] + 32'd1;
            if (cx_stat[ce_c] == ST_OK) begin
              if (!cx_adm[ce_c] && cx_sqe[ce_c][7:0] == IO_READ) begin
                pc[3] <= pc[3] + 32'd1; s_hrc <= s_hrc + 64'd1;
                // 11-bit sum: remainder (<= 999) + blocks (<= 256) must not wrap
                if ({1'b0, dur_r} + 11'(cx_xlen[ce_c] >> 9) >= 11'd1000) begin
                  dur_k <= dur_k + 64'd1; dur_r <= 10'({1'b0, dur_r} + 11'(cx_xlen[ce_c] >> 9) - 11'd1000);
                end else dur_r <= 10'({1'b0, dur_r} + 11'(cx_xlen[ce_c] >> 9));
              end
              if (!cx_adm[ce_c] && cx_sqe[ce_c][7:0] == IO_WRITE) begin
                pc[4] <= pc[4] + 32'd1; s_hwc <= s_hwc + 64'd1;
                // 11-bit sum: remainder (<= 999) + blocks (<= 256) must not wrap
                if ({1'b0, duw_r} + 11'(cx_xlen[ce_c] >> 9) >= 11'd1000) begin
                  duw_k <= duw_k + 64'd1; duw_r <= 10'({1'b0, duw_r} + 11'(cx_xlen[ce_c] >> 9) - 11'd1000);
                end else duw_r <= 10'({1'b0, duw_r} + 11'(cx_xlen[ce_c] >> 9));
              end
              if (!cx_adm[ce_c] && cx_sqe[ce_c][7:0] == IO_FLUSH) pc[5] <= pc[5] + 32'd1;
            end else begin
              pc[7]   <= pc[7] + 32'd1;
              err_cnt <= err_cnt + 64'd1;
              if (cx_stat[ce_c][10:8] == SCT_MEDIA) s_media <= s_media + 64'd1;
              elog_r[elog_wp] <= {err_cnt + 64'd1, 16'(cx_sq[ce_c]), cx_sqe[ce_c][31:16], cx_stat[ce_c],
                                  cx_ploc[ce_c],
                                  (!cx_adm[ce_c] && (cx_sqe[ce_c][7:0] == IO_READ || cx_sqe[ce_c][7:0] == IO_WRITE)) ?
                                    {dw(cx_sqe[ce_c], 11), dw(cx_sqe[ce_c], 10)} : 64'd0,
                                  dw(cx_sqe[ce_c], 1)};
              elog_wp <= elog_wp + 1'b1;
            end
          end
        end
        default: ce_st <= CE_IDLE;
      endcase

      // ============================================ asynchronous event requests and events (one place)
      begin
        logic aer_push, aer_pop;
        aer_push = (ae_st == AE_EXEC) && !resetting && ax_aer;
        aer_pop  = (ce_st == CE_POST) && ce_aer;
        if (aer_pop) for (int i = 0; i < NAER - 1; i++) aer_cid[i] <= aer_cid[i + 1];
        if (aer_push) aer_cid[32'(aer_n) - 32'(aer_pop)] <= a_sqe[31:16];
        aer_n <= aer_n + $bits(aer_n)'(aer_push) - $bits(aer_n)'(aer_pop);
        if (aer_pop) begin
          ev_pend <= 1'b0; ev_masked <= 1'b1;                   // error-type events masked until log 01h is read
        end else if ((ENABLE_EXT_ADMIN != 0) && (db_bad_reg || db_bad_val) && !ev_pend && !ev_masked && fe_en) begin
          ev_pend <= 1'b1;
          ev_info <= db_bad_reg ? 8'h01 : 8'h02;                // invalid doorbell register / write value
        end
        if ((ae_st == AE_EXEC) && !resetting && ax_data && ax_st == ST_OK && ax_clr_mask) ev_masked <= 1'b0;
        if (rst_done) begin aer_n <= '0; ev_pend <= 1'b0; ev_masked <= 1'b0; end
      end

      // ============================================ controller reset: release contexts nobody is working on
      if (resetting) begin
        for (int i = 0; i < NCTX; i++)
          if (cx_st[i] == CX_DECODE || cx_st[i] == CX_BE_RDY || cx_st[i] == CX_ADM_RDY || cx_st[i] == CX_DONE ||
              (cx_st[i] == CX_PRP && !(pe_busy && pe_c == CW'(i))))
            cx_st[i] <= CX_FREE;
      end

      // ============================================ statistics / performance
      if (io_busy) begin
        if (busy_cyc == BUSY_CYC_PER_MIN - 64'd1) begin busy_cyc <= '0; s_busy <= s_busy + 64'd1; end
        else busy_cyc <= busy_cyc + 64'd1;
      end
      intx_q <= intx_assert;
      if (cs == CS_RDY) pc[0] <= pc[0] + 32'd1;
      if (ev_rd_dw)     pc[8]  <= pc[8]  + 32'd1;
      if (ev_wr_dw)     pc[9]  <= pc[9]  + 32'd1;
      if (ev_msi)       pc[10] <= pc[10] + 32'd1;
      if (intx_assert && !intx_q) pc[11] <= pc[11] + 32'd1;
      if (db_sq_ok)     pc[12] <= pc[12] + 32'd1;
      if (db_cq_ok)     pc[13] <= pc[13] + 32'd1;
      if (db_bad_reg || db_bad_val || ev_db_partial) pc[14] <= pc[14] + 32'd1;
      begin
        logic stall;
        stall = 1'b0;
        for (int i = 0; i < NCTX; i++)
          if (cx_st[i] == CX_DONE && cq_full[cq_of(cx_sq[i], sq_cqid)]) stall = 1'b1;
        if (stall) pc[19] <= pc[19] + 32'd1;
      end
      if (ev_cpl_tmo)   pc[20] <= pc[20] + 32'd1;
      if (ev_cpl_err)   pc[21] <= pc[21] + 32'd1;
      if (ev_cpl_unexp) pc[22] <= pc[22] + 32'd1;
      if (ev_bme)       pc[23] <= pc[23] + 32'd1;
      if (w_ev_ref)     pc[26] <= pc[26] + 32'd1;
      if (ev_mmio_bad)  pc[28] <= pc[28] + 32'd1;
      if (w_ev_rd)      pc[29] <= pc[29] + 32'd1;
      if (w_ev_wr)      pc[30] <= pc[30] + 32'd1;
      if (cs == CS_DIS && cc_en && !cfg_ok) pc[31] <= pc[31] + 32'd1;
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^pe_next_lp ^ pe_lp_bad ^ ^cc_wr ^ ^be_cpl.err ^ ^be_cpl.result0 ^ ^be_cpl.result1 ^
                ^cc_q[31:24] ^ ^cc_q[3:1] ^ ^aqa_q[31:28] ^ ^aqa_q[15:12] ^ ^asq_q[11:0] ^ ^acq_q[11:0] ^ ^sq_size ^
                ^asq_end[63:0] ^ ^acq_end[63:0] ^ ^d_c12[31:24] ^ ^d_c12[19:16] ^ d_len[XLW] ^ ^a_cq_end[63:0] ^
                ^a_sq_end[63:0] ^ ^lk_idx ^ ^lk2_idx;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
