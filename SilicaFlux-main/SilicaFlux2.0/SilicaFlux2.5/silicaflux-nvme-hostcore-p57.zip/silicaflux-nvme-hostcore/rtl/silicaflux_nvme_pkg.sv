// =============================================================================
// SilicaFlux-STORE (Project 57) :: silicaflux_nvme_pkg -- NVMe HostCore constants
//
// Register offsets, opcodes, status codes and SQE / CQE helpers for the NVMe
// command front end.  Values follow the published NVM Express specifications
// (NVMe Base Specification -- controller registers, admin commands, status
// codes; NVM Command Set Specification -- Read / Write / Flush; NVMe over PCIe
// Transport Specification -- BAR0 register mapping, doorbells, PRPs,
// interrupts).  Only the subset listed in docs/03_COMMANDS.md is implemented;
// nothing here is a conformance claim.
//
// Internal status encoding (12 bits): {DNR, SCT[2:0], SC[7:0]}.
// CQE DW3 = {DNR, M=0, CRD=00, SCT, SC, P, CID}.
// Classification: SYNTHESIZABLE (package)
// =============================================================================
`default_nettype none

package silicaflux_nvme_pkg;
  /* verilator lint_off UNUSEDPARAM */
  /* verilator lint_off UNUSEDSIGNAL */

  // ---------------------------------------------------------------- versions
  localparam logic [31:0] SFN_NVME_VS   = 32'h0001_0400;   // VS register: 1.4.0 (see docs/02 sec. 1)
  localparam logic [31:0] SFN_HW_VER    = 32'h0057_0100;   // Project 57, front end 1.0

  // ---------------------------------------------------------------- controller registers (BAR0 byte offsets)
  localparam logic [13:0] R_CAP_LO  = 14'h000;
  localparam logic [13:0] R_CAP_HI  = 14'h004;
  localparam logic [13:0] R_VS      = 14'h008;
  localparam logic [13:0] R_INTMS   = 14'h00C;
  localparam logic [13:0] R_INTMC   = 14'h010;
  localparam logic [13:0] R_CC      = 14'h014;
  localparam logic [13:0] R_CSTS    = 14'h01C;
  localparam logic [13:0] R_NSSR    = 14'h020;               // reserved here: CAP.NSSRS = 0
  localparam logic [13:0] R_AQA     = 14'h024;
  localparam logic [13:0] R_ASQ_LO  = 14'h028;
  localparam logic [13:0] R_ASQ_HI  = 14'h02C;
  localparam logic [13:0] R_ACQ_LO  = 14'h030;
  localparam logic [13:0] R_ACQ_HI  = 14'h034;
  localparam logic [13:0] R_DB_BASE = 14'h1000;              // SQyTDBL = 1000h + 2y*4, CQyHDBL = 1000h + (2y+1)*4 (DSTRD 0)

  // CC writable field mask (EN, CSS, MPS, AMS, SHN, IOSQES, IOCQES); everything else RsvdZ
  localparam logic [31:0] CC_WMASK  = 32'h00FF_FFF1;
  localparam logic [31:0] AQA_WMASK = 32'h0FFF_0FFF;

  // ---------------------------------------------------------------- opcodes
  localparam logic [7:0] ADM_DELETE_SQ = 8'h00;
  localparam logic [7:0] ADM_CREATE_SQ = 8'h01;
  localparam logic [7:0] ADM_GET_LOG   = 8'h02;
  localparam logic [7:0] ADM_DELETE_CQ = 8'h04;
  localparam logic [7:0] ADM_CREATE_CQ = 8'h05;
  localparam logic [7:0] ADM_IDENTIFY  = 8'h06;
  localparam logic [7:0] ADM_ABORT     = 8'h08;
  localparam logic [7:0] ADM_SET_FEAT  = 8'h09;
  localparam logic [7:0] ADM_GET_FEAT  = 8'h0A;
  localparam logic [7:0] ADM_AER       = 8'h0C;

  localparam logic [7:0] IO_FLUSH = 8'h00;
  localparam logic [7:0] IO_WRITE = 8'h01;
  localparam logic [7:0] IO_READ  = 8'h02;

  // Identify CNS, log identifiers, feature identifiers
  localparam logic [7:0] CNS_NS        = 8'h00;
  localparam logic [7:0] CNS_CTRL      = 8'h01;
  localparam logic [7:0] CNS_NS_LIST   = 8'h02;
  localparam logic [7:0] CNS_NS_DESC   = 8'h03;
  localparam logic [7:0] LID_ERROR     = 8'h01;
  localparam logic [7:0] LID_SMART     = 8'h02;
  localparam logic [7:0] LID_FW_SLOT   = 8'h03;
  localparam logic [7:0] LID_VS_PERF   = 8'hC0;               // vendor specific: front-end performance counters
  localparam logic [7:0] FID_VWC       = 8'h06;
  localparam logic [7:0] FID_NUM_Q     = 8'h07;

  // ---------------------------------------------------------------- status codes
  localparam logic [2:0] SCT_GEN   = 3'd0;
  localparam logic [2:0] SCT_CMD   = 3'd1;
  localparam logic [2:0] SCT_MEDIA = 3'd2;
  // generic command status (SCT 0)
  localparam logic [7:0] SC_SUCCESS        = 8'h00;
  localparam logic [7:0] SC_INVALID_OPCODE = 8'h01;
  localparam logic [7:0] SC_INVALID_FIELD  = 8'h02;
  localparam logic [7:0] SC_CID_CONFLICT   = 8'h03;
  localparam logic [7:0] SC_DATA_XFER_ERR  = 8'h04;
  localparam logic [7:0] SC_ABORT_PWR_LOSS = 8'h05;
  localparam logic [7:0] SC_INTERNAL       = 8'h06;
  localparam logic [7:0] SC_ABORT_SQ_DEL   = 8'h08;
  localparam logic [7:0] SC_INVALID_NS     = 8'h0B;
  localparam logic [7:0] SC_CMD_SEQ_ERR    = 8'h0C;
  localparam logic [7:0] SC_PRP_OFFSET     = 8'h13;
  localparam logic [7:0] SC_LBA_RANGE      = 8'h80;
  localparam logic [7:0] SC_CAP_EXCEEDED   = 8'h81;
  localparam logic [7:0] SC_NS_NOT_READY   = 8'h82;
  // command specific status (SCT 1)
  localparam logic [7:0] SC_CQ_INVALID     = 8'h00;
  localparam logic [7:0] SC_INVALID_QID    = 8'h01;
  localparam logic [7:0] SC_INVALID_QSIZE  = 8'h02;
  localparam logic [7:0] SC_AER_LIMIT      = 8'h05;
  localparam logic [7:0] SC_INVALID_IV     = 8'h08;
  localparam logic [7:0] SC_INVALID_LOG    = 8'h09;
  localparam logic [7:0] SC_INVALID_QDEL   = 8'h0C;
  localparam logic [7:0] SC_FEAT_NOT_SAVE  = 8'h0D;
  // media and data integrity errors (SCT 2)
  localparam logic [7:0] SC_WRITE_FAULT    = 8'h80;
  localparam logic [7:0] SC_UNREC_READ     = 8'h81;
  localparam logic [7:0] SC_ACCESS_DENIED  = 8'h86;

  // 12-bit internal status {DNR, SCT, SC}
  function automatic logic [11:0] st(input logic dnr, input logic [2:0] sct, input logic [7:0] sc);
    st = {dnr, sct, sc};
  endfunction
  localparam logic [11:0] ST_OK = 12'h000;

  // CQE dword 3: status field [31:17] = {DNR, M, CRD[1:0], SCT[2:0], SC[7:0]}, P [16], CID [15:0]
  function automatic logic [31:0] cqe_dw3(input logic [11:0] s, input logic phase, input logic [15:0] cid);
    cqe_dw3 = {s[11], 1'b0, 2'b00, s[10:8], s[7:0], phase, cid};
  endfunction

  // ---------------------------------------------------------------- SQE field access (512-bit, DW i = bits [32i+31:32i])
  function automatic logic [31:0] sqe_dw(input logic [511:0] e, input int i);
    sqe_dw = e[32*i +: 32];
  endfunction

  // ---------------------------------------------------------------- PCIe completion status (TLP Cpl Status)
  localparam logic [2:0] CPL_SC = 3'b000;
  localparam logic [2:0] CPL_UR = 3'b001;
  localparam logic [2:0] CPL_CA = 3'b100;

  // ---------------------------------------------------------------- command context states
  localparam logic [3:0] CX_FREE    = 4'd0;   // unused
  localparam logic [3:0] CX_FETCH   = 4'd1;   // SQE read in flight
  localparam logic [3:0] CX_DECODE  = 4'd2;   // SQE received, waiting for the decoder
  localparam logic [3:0] CX_PRP     = 4'd3;   // waiting for / in the PRP-list engine
  localparam logic [3:0] CX_BE_RDY  = 4'd4;   // ready to dispatch to the storage back end
  localparam logic [3:0] CX_BE_WAIT = 4'd5;   // owned by the storage back end
  localparam logic [3:0] CX_ADM_RDY = 4'd6;   // waiting for the admin engine
  localparam logic [3:0] CX_ADM_RUN = 4'd7;   // in the admin engine
  localparam logic [3:0] CX_DONE    = 4'd8;   // status known, waiting for the completion engine
  localparam logic [3:0] CX_POST    = 4'd9;   // CQE write in progress

  // ---------------------------------------------------------------- byte-enable helpers (PCIe CplD byte count / lower address)
  function automatic logic [1:0] be_lo(input logic [3:0] be);       // lowest enabled byte (0 when none)
    if (be[0]) be_lo = 2'd0; else if (be[1]) be_lo = 2'd1; else if (be[2]) be_lo = 2'd2; else if (be[3]) be_lo = 2'd3;
    else be_lo = 2'd0;
  endfunction
  function automatic logic [1:0] be_hi(input logic [3:0] be);       // highest enabled byte (3 when none)
    if (be[3]) be_hi = 2'd3; else if (be[2]) be_hi = 2'd2; else if (be[1]) be_hi = 2'd1; else if (be[0]) be_hi = 2'd0;
    else be_hi = 2'd3;
  endfunction

  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_on UNUSEDPARAM */
endpackage

`default_nettype wire
