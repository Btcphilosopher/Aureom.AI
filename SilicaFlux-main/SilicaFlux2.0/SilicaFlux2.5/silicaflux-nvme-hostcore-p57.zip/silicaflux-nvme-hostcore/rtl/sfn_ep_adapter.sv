// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_ep_adapter -- PCIe endpoint adapter
//
// Sits between a PCIe endpoint's transaction-layer USER interface ("SFN-TL",
// docs/06_PCIE_TRANSPORT.md) and the NVMe controller.  It contains NO physical,
// data-link or link-training logic and no configuration space: those belong to
// the endpoint (vendor hard IP, or the transaction-level simulation model in
// tb/common/sfn_tb_pcie_host.sv).  SFN-TL follows the role split that hard-IP
// user interfaces use (completer request / completer completion / requester
// request / requester completion, 32-bit data beats, header held for every beat
// of a TLP).
//
//   Completer  : memory reads / writes that hit BAR0 -> 32-bit register port.
//                1..2 DW requests are served (NVMe registers are 32/64 bit);
//                longer reads -> Completer Abort, other BARs -> Unsupported
//                Request; longer / other-BAR writes are dropped (counted).
//                Zero-length reads return one DW without a register access.
//   Requester  : internal DMA reads (any DW-aligned length <= 4 KiB) are split
//                into MRd TLPs <= min(MRRS, RSLOT_BYTES) that never cross a
//                4 KiB boundary, one tag each (NTAG tags, ring allocation).
//                Completions may be split (RCB) and may arrive out of order
//                across tags; data is reassembled per tag and delivered to the
//                requesting engine IN REQUEST ORDER on rd_rsp_*.  UR / CA
//                status, malformed completions and completion timeout mark the
//                request failed: its beats are still delivered (data 0,
//                rd_rsp_err = 1) so consumers always see len/4 beats.  A
//                timed-out tag is quarantined for another CPL_TIMEOUT cycles;
//                a late completion for it is dropped (counted).
//                Internal DMA writes are split into MWr TLPs <= min(MPS,
//                MPS_CAP) that never cross a 4 KiB boundary.  Writes are posted
//                and emitted in acceptance order; nothing reorders them.
//   Bus master : with Bus Master Enable clear no request TLP is emitted; reads
//                fail immediately, write data is consumed and dropped (counted).
// One clock domain (the endpoint user clock).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfn_ep_adapter
  import silicaflux_nvme_pkg::*;
#(
  parameter int BAR_AW      = 14,       // BAR0 = 2^BAR_AW bytes
  parameter int NTAG        = 8,        // non-posted tags (power of two, 2..32)
  parameter int RSLOT_BYTES = 512,      // reassembly buffer per tag = largest MRd issued
  parameter int MPS_CAP     = 256,      // largest MWr payload issued
  parameter int CPL_TIMEOUT = 65536,    // completion timeout, cycles
  parameter int ID_W        = 2,        // internal requester id width
  localparam int TW  = $clog2(NTAG),
  localparam int SDW = RSLOT_BYTES / 4,
  localparam int SAW = $clog2(SDW),
  localparam int TMW = $clog2(CPL_TIMEOUT + 1)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ================================================================ SFN-TL: completer request (host -> device)
  input  wire logic              cq_valid,
  output logic                   cq_ready,
  input  wire logic              cq_write,
  input  wire logic [2:0]        cq_bar,
  input  wire logic [63:0]       cq_addr,
  input  wire logic [10:0]       cq_len_dw,
  input  wire logic [3:0]        cq_first_be,
  input  wire logic [3:0]        cq_last_be,
  input  wire logic [7:0]        cq_tag,
  input  wire logic [15:0]       cq_req_id,
  input  wire logic [31:0]       cq_data,
  input  wire logic              cq_last,
  // ================================================================ SFN-TL: completer completion (device -> host)
  output logic                   cc_valid,
  input  wire logic              cc_ready,
  output logic [7:0]             cc_tag,
  output logic [15:0]            cc_req_id,
  output logic [2:0]             cc_status,
  output logic [12:0]            cc_byte_count,
  output logic [6:0]             cc_lower_addr,
  output logic [10:0]            cc_len_dw,
  output logic [31:0]            cc_data,
  output logic                   cc_last,
  // ================================================================ SFN-TL: requester request (device -> host)
  output logic                   rq_valid,
  input  wire logic              rq_ready,
  output logic                   rq_write,
  output logic [63:0]            rq_addr,
  output logic [10:0]            rq_len_dw,
  output logic [3:0]             rq_first_be,
  output logic [3:0]             rq_last_be,
  output logic [7:0]             rq_tag,
  output logic [31:0]            rq_data,
  output logic                   rq_last,
  // ================================================================ SFN-TL: requester completion (host -> device)
  input  wire logic              rc_valid,
  output logic                   rc_ready,
  input  wire logic [7:0]        rc_tag,
  input  wire logic [2:0]        rc_status,
  input  wire logic [12:0]       rc_byte_count,
  input  wire logic [6:0]        rc_lower_addr,
  input  wire logic [10:0]       rc_len_dw,
  input  wire logic [31:0]       rc_data,
  input  wire logic              rc_last,
  // ================================================================ endpoint configuration status
  input  wire logic              cfg_bme,
  input  wire logic [2:0]        cfg_mps,        // Max_Payload_Size encoding (128 << n)
  input  wire logic [2:0]        cfg_mrrs,       // Max_Read_Request_Size encoding (128 << n)
  // ================================================================ internal: register port (one DW, same-cycle read data)
  output logic                   mm_valid,
  output logic                   mm_write,
  output logic [BAR_AW-1:2]      mm_addr,
  output logic [31:0]            mm_wdata,
  output logic [3:0]             mm_be,
  input  wire logic [31:0]       mm_rdata,
  // ================================================================ internal: DMA read
  input  wire logic              rd_req_valid,
  output logic                   rd_req_ready,
  input  wire logic [63:0]       rd_req_addr,
  input  wire logic [12:0]       rd_req_len,     // bytes, multiple of 4, 4..4096
  input  wire logic [ID_W-1:0]   rd_req_id,
  output logic                   rd_rsp_valid,
  input  wire logic              rd_rsp_ready,
  output logic [31:0]            rd_rsp_data,
  output logic [ID_W-1:0]        rd_rsp_id,
  output logic                   rd_rsp_last,
  output logic                   rd_rsp_err,
  // ================================================================ internal: DMA write (addr / len sampled with the first beat)
  input  wire logic              wr_valid,
  output logic                   wr_ready,
  input  wire logic [63:0]       wr_addr,
  input  wire logic [12:0]       wr_len,         // bytes, multiple of 4, 4..4096
  input  wire logic [31:0]       wr_data,
  // ================================================================ status / events
  output logic                   rd_idle,        // no internal read pending or undelivered
  output logic                   wr_idle,
  output logic                   ev_rd_dw,       // one read data DW received
  output logic                   ev_wr_dw,       // one write data DW emitted
  output logic                   ev_cpl_err,     // UR / CA / malformed completion
  output logic                   ev_cpl_tmo,     // completion timeout
  output logic                   ev_cpl_unexp,   // completion for no outstanding tag (dropped)
  output logic                   ev_bme_block,   // request suppressed because Bus Master Enable is clear
  output logic                   ev_mmio_bad     // completer request answered UR / CA or write dropped
);
  // ================================================================ helpers
  function automatic logic [12:0] min13(input logic [12:0] a, input logic [12:0] b);
    min13 = (a < b) ? a : b;
  endfunction
  wire [12:0] mps_bytes  = 13'd128 << cfg_mps;
  wire [12:0] mrrs_bytes = 13'd128 << cfg_mrrs;
  wire [12:0] mps_eff    = min13((cfg_mps  > 3'd5) ? 13'd128 : mps_bytes,  13'(MPS_CAP));
  wire [12:0] mrrs_eff   = min13((cfg_mrrs > 3'd5) ? 13'd128 : mrrs_bytes, 13'(RSLOT_BYTES));

  // ================================================================ completer
  localparam logic [1:0] C_IDLE = 2'd0, C_READ = 2'd1, C_CPL = 2'd2;
  logic [1:0]  c_state;
  logic [10:0] c_beat;                   // write beat index inside the current request
  logic [7:0]  c_tag;
  logic [15:0] c_rid;
  logic [BAR_AW-1:2] c_dwaddr;
  logic [10:0] c_len;
  logic [3:0]  c_fbe, c_lbe;
  logic [6:0]  c_la;
  logic [2:0]  c_st;
  logic [12:0] c_bc;
  logic        c_zlr;                    // zero-length read
  logic        c_idx;                    // register DW being read / completion beat
  logic [31:0] c_buf0, c_buf1;

  wire cq_hs   = cq_valid && cq_ready;
  wire cq_ok   = (cq_bar == 3'd0) && (cq_len_dw >= 11'd1) && (cq_len_dw <= 11'd2);
  wire [BAR_AW-1:2] cq_dw = cq_addr[BAR_AW-1:2];
  assign cq_ready = (c_state == C_IDLE);

  // byte count of a 1..2 DW read (PCIe byte-count rules for memory reads)
  function automatic logic [12:0] rd_bytes(input logic [10:0] len, input logic [3:0] fbe, input logic [3:0] lbe);
    if (len == 11'd1) rd_bytes = (fbe == 4'h0) ? 13'd1 : 13'(be_hi(fbe)) - 13'(be_lo(fbe)) + 13'd1;
    else              rd_bytes = 13'({len, 2'b00}) - 13'(be_lo(fbe)) - (13'd3 - 13'(be_hi(lbe)));
  endfunction

  always_comb begin
    mm_valid = 1'b0;
    mm_write = 1'b0;
    mm_addr  = cq_dw;
    mm_wdata = cq_data;
    mm_be    = 4'h0;
    if (c_state == C_IDLE && cq_valid && cq_write && cq_ok) begin
      mm_valid = 1'b1;
      mm_write = 1'b1;
      mm_addr  = cq_dw + (BAR_AW-2)'(c_beat);
      mm_be    = (c_beat == 11'd0) ? cq_first_be : cq_last_be;
    end else if (c_state == C_READ && !c_zlr) begin
      mm_valid = 1'b1;
      mm_addr  = c_dwaddr + (BAR_AW-2)'(c_idx);
      mm_be    = c_idx ? c_lbe : c_fbe;
    end
  end

  assign cc_valid      = (c_state == C_CPL);
  assign cc_tag        = c_tag;
  assign cc_req_id     = c_rid;
  assign cc_status     = c_st;
  assign cc_byte_count = c_bc;
  assign cc_lower_addr = c_la;
  assign cc_len_dw     = (c_st == CPL_SC) ? c_len : 11'd0;
  assign cc_data       = c_idx ? c_buf1 : c_buf0;
  assign cc_last       = (c_st != CPL_SC) || (c_len == 11'd1) || c_idx;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c_state <= C_IDLE; c_beat <= '0; c_tag <= '0; c_rid <= '0; c_dwaddr <= '0; c_len <= '0;
      c_fbe <= '0; c_lbe <= '0; c_la <= '0; c_st <= CPL_SC; c_bc <= '0; c_zlr <= 1'b0; c_idx <= 1'b0;
      c_buf0 <= '0; c_buf1 <= '0;
    end else begin
      case (c_state)
        C_IDLE: if (cq_hs) begin
          if (cq_write) begin
            c_beat <= cq_last ? 11'd0 : c_beat + 11'd1;
          end else begin
            c_tag    <= cq_tag;
            c_rid    <= cq_req_id;
            c_dwaddr <= cq_dw;
            c_len    <= cq_len_dw;
            c_fbe    <= cq_first_be;
            c_lbe    <= cq_last_be;
            c_zlr    <= (cq_len_dw == 11'd1) && (cq_first_be == 4'h0);
            c_la     <= {cq_addr[6:2], be_lo(cq_first_be)};
            c_idx    <= 1'b0;
            c_buf0   <= '0;
            c_buf1   <= '0;
            if (cq_bar != 3'd0)          begin c_st <= CPL_UR; c_bc <= 13'd4; c_state <= C_CPL; end
            else if (!cq_ok)             begin c_st <= CPL_CA; c_bc <= 13'd4; c_state <= C_CPL; end
            else begin
              c_st    <= CPL_SC;
              c_bc    <= rd_bytes(cq_len_dw, cq_first_be, cq_last_be);
              c_state <= C_READ;
            end
          end
        end
        C_READ: begin
          if (c_idx) c_buf1 <= c_zlr ? 32'h0 : mm_rdata;
          else       c_buf0 <= c_zlr ? 32'h0 : mm_rdata;
          if (c_idx || c_len == 11'd1) begin c_state <= C_CPL; c_idx <= 1'b0; end
          else c_idx <= 1'b1;
        end
        C_CPL: if (cc_ready) begin
          if (cc_last) begin c_state <= C_IDLE; c_idx <= 1'b0; end
          else c_idx <= 1'b1;
        end
        default: c_state <= C_IDLE;
      endcase
    end
  end
  assign ev_mmio_bad = cq_hs && !cq_ok && (!cq_write || cq_last);

  // ================================================================ requester: read issue (split + tag allocation)
  localparam logic [1:0] T_FREE = 2'd0, T_PEND = 2'd1, T_DONE = 2'd2, T_QUAR = 2'd3;
  logic [1:0]     t_state [NTAG];
  logic           t_err   [NTAG];
  logic           t_to    [NTAG];
  logic           t_lastc [NTAG];      // last chunk of its internal request
  logic [ID_W-1:0] t_id   [NTAG];
  logic [10:0]    t_exp   [NTAG];      // DWs expected
  logic [10:0]    t_rcv   [NTAG];      // DWs received
  logic [TMW-1:0] t_tmr   [NTAG];

  logic           ri_busy;
  logic [63:0]    ri_addr;
  logic [12:0]    ri_rem;
  logic [ID_W-1:0] ri_id;
  logic [TW-1:0]  ap, dp;              // allocate / deliver pointers (ring)

  wire [12:0] ri_to4k  = 13'd4096 - {1'b0, ri_addr[11:0]};
  wire [12:0] ri_chunk = min13(min13(ri_rem, mrrs_eff), ri_to4k);
  wire        ri_lastc = (ri_rem == ri_chunk);
  wire        tag_free = (t_state[ap] == T_FREE);
  assign rd_req_ready = !ri_busy;

  // ================================================================ requester: write split
  logic        w_busy;
  logic [63:0] w_addr;
  logic [12:0] w_rem;
  logic [10:0] w_beat;                 // beat inside the current TLP (0 = TLP boundary)
  logic        w_drop;                 // current TLP is dropped (BME clear when it started)
  wire [12:0]  w_to4k  = 13'd4096 - {1'b0, w_addr[11:0]};
  wire [12:0]  w_chunk = min13(min13(w_rem, mps_eff), w_to4k);
  wire [10:0]  w_cdw   = w_chunk[12:2];
  wire         w_tlast = (w_beat == w_cdw - 11'd1);

  // ================================================================ rq arbitration (TLP granularity)
  logic        prio_wr;
  wire rd_cand   = ri_busy && tag_free && cfg_bme;
  wire wr_cand   = w_busy && wr_valid;
  wire wr_mid    = w_busy && (w_beat != 11'd0);
  logic sel_rd, sel_wr;
  always_comb begin
    sel_rd = 1'b0;
    sel_wr = 1'b0;
    if (wr_mid)                    sel_wr = 1'b1;
    else if (rd_cand && wr_cand)   begin sel_wr = prio_wr; sel_rd = !prio_wr; end
    else if (rd_cand)              sel_rd = 1'b1;
    else if (wr_cand)              sel_wr = 1'b1;
  end
  wire w_drop_now = (w_beat == 11'd0) ? !cfg_bme : w_drop;    // drop decision for this beat's TLP

  always_comb begin
    rq_valid    = 1'b0;
    rq_write    = 1'b0;
    rq_addr     = ri_addr;
    rq_len_dw   = ri_chunk[12:2];
    rq_first_be = 4'hF;
    rq_last_be  = (ri_chunk[12:2] == 11'd1) ? 4'h0 : 4'hF;
    rq_tag      = 8'(ap);
    rq_data     = 32'h0;
    rq_last     = 1'b1;
    wr_ready    = 1'b0;
    if (sel_wr) begin
      rq_write    = 1'b1;
      rq_addr     = w_addr;
      rq_len_dw   = w_cdw;
      rq_last_be  = (w_cdw == 11'd1) ? 4'h0 : 4'hF;
      rq_tag      = 8'h00;
      rq_data     = wr_data;
      rq_last     = w_tlast;
      rq_valid    = wr_valid && !w_drop_now;
      wr_ready    = w_drop_now ? 1'b1 : rq_ready;
    end else if (sel_rd) begin
      rq_valid    = 1'b1;
    end
  end
  wire rd_issue  = sel_rd && rq_ready;                        // MRd accepted by the endpoint
  wire rd_nobme  = ri_busy && tag_free && !cfg_bme;           // fail without a TLP
  wire wr_beat   = sel_wr && wr_valid && wr_ready;
  assign ev_wr_dw     = wr_beat && !w_drop_now;
  assign ev_bme_block = rd_nobme || (wr_beat && w_drop_now && w_beat == 11'd0);

  // ================================================================ completion receive
  assign rc_ready = 1'b1;              // completions are never back-pressured (buffer reserved per tag)
  wire [TW-1:0] rt = rc_tag[TW-1:0];
  wire rc_tag_ok   = (rc_tag < 8'(NTAG)) && (t_state[rt] == T_PEND);
  wire rc_is_err   = rc_status != CPL_SC;
  wire rc_data_bt  = rc_valid && rc_tag_ok && !rc_is_err && (rc_len_dw != 11'd0);
  wire rc_overrun  = rc_data_bt && (t_rcv[rt] >= t_exp[rt]);
  wire rc_final    = rc_data_bt && !rc_overrun && (t_rcv[rt] + 11'd1 == t_exp[rt]);
  // a CplD whose byte count says "last completion" while data is still missing is malformed
  wire rc_short    = rc_data_bt && !rc_overrun && rc_last && (rc_byte_count == {rc_len_dw, 2'b00}) &&
                     (t_rcv[rt] + 11'd1 != t_exp[rt]);
  wire rc_fail     = rc_valid && rc_tag_ok && ((rc_is_err && rc_last) || (!rc_is_err && rc_len_dw == 11'd0) ||
                                               rc_overrun || rc_short);
  assign ev_cpl_unexp = rc_valid && rc_last && !rc_tag_ok;
  assign ev_cpl_err   = rc_fail;
  assign ev_rd_dw     = rc_data_bt && !rc_overrun;

  // reassembly buffer: NTAG x SDW words, one write port (completions), one read port (delivery)
  logic [31:0] rbuf [NTAG * SDW];
  logic [31:0] rbuf_q;
  logic        rb_re;
  logic [TW+SAW-1:0] rb_raddr;
  always_ff @(posedge clk) begin
    if (rc_data_bt && !rc_overrun) rbuf[{rt, t_rcv[rt][SAW-1:0]}] <= rc_data;
    if (rb_re) rbuf_q <= rbuf[rb_raddr];
  end

  // ================================================================ delivery (request order), 2-entry output FIFO
  logic [SAW:0]  dk;                   // next DW of tag dp to read
  logic          inf_v;                // RAM read issued last cycle
  logic          inf_err, inf_last;
  logic [ID_W-1:0] inf_id;
  logic [1:0]    of_cnt;
  logic [31:0]   of_data [2];
  logic [ID_W-1:0] of_id [2];
  logic          of_last [2], of_err [2];
  logic          of_rp, of_wp;
  wire  can_rd  = (t_state[dp] == T_DONE) && ({1'b0, of_cnt} + {1'b0, 1'b0, inf_v} < 3'd2);
  wire  dk_fin  = (11'(dk) + 11'd1 == t_exp[dp]);
  assign rb_re    = can_rd;
  assign rb_raddr = {dp, dk[SAW-1:0]};
  wire  of_pop  = rd_rsp_valid && rd_rsp_ready;
  assign rd_rsp_valid = (of_cnt != 2'd0);
  assign rd_rsp_data  = of_data[of_rp];
  assign rd_rsp_id    = of_id[of_rp];
  assign rd_rsp_last  = of_last[of_rp];
  assign rd_rsp_err   = of_err[of_rp];

  // ================================================================ sequential: tags, issue, write split, delivery
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NTAG; i++) begin
        t_state[i] <= T_FREE; t_err[i] <= 1'b0; t_to[i] <= 1'b0; t_lastc[i] <= 1'b0; t_id[i] <= '0;
        t_exp[i] <= '0; t_rcv[i] <= '0; t_tmr[i] <= '0;
      end
      ri_busy <= 1'b0; ri_addr <= '0; ri_rem <= '0; ri_id <= '0; ap <= '0; dp <= '0;
      w_busy <= 1'b0; w_addr <= '0; w_rem <= '0; w_beat <= '0; w_drop <= 1'b0; prio_wr <= 1'b0;
      dk <= '0; inf_v <= 1'b0; inf_err <= 1'b0; inf_last <= 1'b0; inf_id <= '0;
      of_cnt <= '0; of_rp <= 1'b0; of_wp <= 1'b0;
      for (int i = 0; i < 2; i++) begin of_data[i] <= '0; of_id[i] <= '0; of_last[i] <= 1'b0; of_err[i] <= 1'b0; end
    end else begin
      // ---------------------------------------------- accept an internal read request
      if (rd_req_valid && rd_req_ready) begin
        ri_busy <= 1'b1; ri_addr <= rd_req_addr; ri_rem <= rd_req_len; ri_id <= rd_req_id;
      end
      // ---------------------------------------------- issue one chunk (TLP, or immediate failure without BME)
      if (rd_issue || rd_nobme) begin
        t_state[ap] <= rd_issue ? T_PEND : T_DONE;
        t_err[ap]   <= !rd_issue;
        t_to[ap]    <= 1'b0;
        t_lastc[ap] <= ri_lastc;
        t_id[ap]    <= ri_id;
        t_exp[ap]   <= ri_chunk[12:2];
        t_rcv[ap]   <= '0;
        t_tmr[ap]   <= '0;
        ap          <= ap + TW'(1);
        ri_addr     <= ri_addr + 64'(ri_chunk);
        ri_rem      <= ri_rem - ri_chunk;
        if (ri_lastc) ri_busy <= 1'b0;
        if (rd_issue) prio_wr <= 1'b1;
      end
      // ---------------------------------------------- completions
      if (rc_data_bt && !rc_overrun) t_rcv[rt] <= t_rcv[rt] + 11'd1;
      if (rc_final) t_state[rt] <= T_DONE;
      if (rc_fail) begin t_state[rt] <= T_DONE; t_err[rt] <= 1'b1; end
      // ---------------------------------------------- timers: completion timeout, quarantine
      for (int i = 0; i < NTAG; i++) begin
        if (t_state[i] == T_PEND && !(rc_valid && rc_tag_ok && rt == TW'(i))) begin
          if (t_tmr[i] == TMW'(CPL_TIMEOUT - 1)) begin
            t_state[i] <= T_DONE; t_err[i] <= 1'b1; t_to[i] <= 1'b1;
          end else t_tmr[i] <= t_tmr[i] + TMW'(1);
        end else if (t_state[i] == T_QUAR) begin
          if (t_tmr[i] == TMW'(CPL_TIMEOUT - 1)) t_state[i] <= T_FREE;
          else t_tmr[i] <= t_tmr[i] + TMW'(1);
        end
      end
      // ---------------------------------------------- write split
      if (!w_busy && wr_valid) begin
        w_busy <= 1'b1; w_addr <= wr_addr; w_rem <= wr_len; w_beat <= '0;
      end
      if (wr_beat) begin
        if (w_beat == 11'd0) w_drop <= !cfg_bme;
        if (w_tlast) begin
          w_beat  <= '0;
          w_addr  <= w_addr + 64'(w_chunk);
          w_rem   <= w_rem - w_chunk;
          prio_wr <= 1'b0;
          if (w_rem == w_chunk) w_busy <= 1'b0;
        end else w_beat <= w_beat + 11'd1;
      end
      // ---------------------------------------------- delivery
      inf_v <= can_rd;
      if (can_rd) begin
        inf_err  <= t_err[dp];
        inf_id   <= t_id[dp];
        inf_last <= dk_fin && t_lastc[dp];
        if (dk_fin) begin
          dk <= '0;
          dp <= dp + TW'(1);
          t_state[dp] <= t_to[dp] ? T_QUAR : T_FREE;
          t_tmr[dp]   <= '0;
        end else dk <= dk + (SAW+1)'(1);
      end
      if (inf_v) begin
        of_data[of_wp] <= inf_err ? 32'h0 : rbuf_q;
        of_err[of_wp]  <= inf_err;
        of_id[of_wp]   <= inf_id;
        of_last[of_wp] <= inf_last;
        of_wp          <= ~of_wp;
      end
      if (of_pop) of_rp <= ~of_rp;
      of_cnt <= of_cnt + 2'(inf_v) - 2'(of_pop);
    end
  end

  // ================================================================ status
  logic any_open;
  always_comb begin
    any_open = 1'b0;
    for (int i = 0; i < NTAG; i++) if (t_state[i] == T_PEND || t_state[i] == T_DONE) any_open = 1'b1;
  end
  assign rd_idle = !ri_busy && !any_open && !inf_v && (of_cnt == 2'd0);
  assign wr_idle = !w_busy;
  logic tmo_any;
  assign ev_cpl_tmo = tmo_any;
  always_comb begin
    tmo_any = 1'b0;
    for (int i = 0; i < NTAG; i++)
      if (t_state[i] == T_PEND && t_tmr[i] == TMW'(CPL_TIMEOUT - 1) && !(rc_valid && rc_tag_ok && rt == TW'(i)))
        tmo_any = 1'b1;
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^cq_addr[63:BAR_AW] ^ ^cq_addr[1:0] ^ ^rc_lower_addr ^ ^cq_req_id[0] ^ ^rc_byte_count[0];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
