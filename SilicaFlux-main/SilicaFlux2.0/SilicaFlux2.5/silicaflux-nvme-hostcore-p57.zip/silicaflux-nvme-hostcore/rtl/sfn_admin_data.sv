// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_admin_data -- Identify / log page data generator
//
// Combinational: returns DW `widx` of the selected data structure, built from
// parameters and live controller state (no ROM image).  Every field that is
// not listed below reads 0.  Field-by-field rationale: docs/03_COMMANDS.md.
//
//   SEL_ID_CTRL  Identify Controller (CNS 01h), 4096 B:
//                VID/SSVID, SN, MN, FR, MDTS, VER, CNTRLTYPE = 1 (I/O),
//                ACL = 0, AERL, FRMW = 03h (1 slot, slot 1 read-only),
//                LPA = 04h (extended Get Log Page data), ELPE = NERR-1,
//                NPSS = 0, SQES = 66h, CQES = 44h, NN = 1, ONCS = 0,
//                VWC = 07h (present; Flush with NSID FFFFFFFFh supported),
//                SGLS = 0, SUBNQN, power state 0 all-zero (not characterised)
//   SEL_ID_NS    Identify Namespace (CNS 00h, NSID 1): NSZE = NCAP = NUSE =
//                back-end capacity, NLBAF = 0, FLBAS = 0, LBAF0 = 512 B, no metadata
//   SEL_NS_LIST  Active Namespace ID list (CNS 02h): {1} if NSID field < 1
//   SEL_ZERO     zero structure (CNS 03h for NSID 1: no identifiers reported)
//   SEL_LOG_ERR  Error Information (01h): NERR x 64 B, newest first
//   SEL_LOG_SMART SMART / Health (02h): data units read / written (thousands
//                of 512 B, rounded up), host read / write commands, controller
//                busy time, media errors, error-log entries; temperature,
//                spare, wear, power-cycle and power-on fields are NOT measured
//                and read 0
//   SEL_LOG_FW   Firmware Slot Information (03h): active slot 1, FRS1 = FR
//   SEL_LOG_PERF vendor-specific C0h: NPERF 64-bit counters (upper 32 bits 0)
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfn_admin_data #(
  parameter int          NERR     = 4,
  parameter int          NPERF    = 32,
  parameter logic [15:0] PCI_VID  = 16'hFFFE,
  parameter logic [15:0] PCI_SSVID = 16'hFFFE,
  parameter logic [8*20-1:0]  SN  = "SFP57-SIM-0000000001",
  parameter logic [8*40-1:0]  MN  = "SilicaFlux NVMe HostCore P57 (sim)      ",
  parameter logic [8*8-1:0]   FR  = "P57-0100",
  parameter int          NQN_LEN  = 46,
  parameter logic [8*NQN_LEN-1:0] NQN = "nqn.2026-11.ai.aureom:silicaflux-p57:sim-00001",
  parameter logic [31:0] VS       = 32'h0001_0400,
  localparam int EW = 64 + 16 + 16 + 12 + 16 + 64 + 32          // error-log entry bits
) (
  input  wire logic [2:0]          sel,
  input  wire logic [9:0]          widx,
  input  wire logic [31:0]         nsid_field,
  input  wire logic [63:0]         nsze,
  input  wire logic [7:0]          mdts,
  input  wire logic [7:0]          aerl,
  // error log, entry 0 = newest: {count, sqid, cid, status, ploc, lba, nsid}
  input  wire logic [NERR*EW-1:0]  elog,
  // SMART counters
  input  wire logic [63:0]         s_dur,
  input  wire logic [63:0]         s_duw,
  input  wire logic [63:0]         s_hrc,
  input  wire logic [63:0]         s_hwc,
  input  wire logic [63:0]         s_busy,
  input  wire logic [63:0]         s_media,
  input  wire logic [63:0]         s_errs,
  input  wire logic [NPERF*32-1:0] perf,
  output logic [31:0]              word
);
  localparam logic [2:0] SEL_ID_CTRL = 3'd0, SEL_ID_NS = 3'd1, SEL_NS_LIST = 3'd2, SEL_ZERO = 3'd3,
                         SEL_LOG_ERR = 3'd4, SEL_LOG_SMART = 3'd5, SEL_LOG_FW = 3'd6, SEL_LOG_PERF = 3'd7;

  function automatic logic [7:0] ctrl_byte(input logic [11:0] a);
    ctrl_byte = 8'h00;
    if      (a == 12'd0)                   ctrl_byte = PCI_VID[7:0];
    else if (a == 12'd1)                   ctrl_byte = PCI_VID[15:8];
    else if (a == 12'd2)                   ctrl_byte = PCI_SSVID[7:0];
    else if (a == 12'd3)                   ctrl_byte = PCI_SSVID[15:8];
    else if (a >= 12'd4  && a < 12'd24)    ctrl_byte = SN[8*(19 - (32'(a) - 4)) +: 8];
    else if (a >= 12'd24 && a < 12'd64)    ctrl_byte = MN[8*(39 - (32'(a) - 24)) +: 8];
    else if (a >= 12'd64 && a < 12'd72)    ctrl_byte = FR[8*(7 - (32'(a) - 64)) +: 8];
    else if (a == 12'd77)                  ctrl_byte = mdts;
    else if (a >= 12'd80 && a < 12'd84)    ctrl_byte = VS[8*(32'(a) - 80) +: 8];
    else if (a == 12'd111)                 ctrl_byte = 8'h01;                     // CNTRLTYPE: I/O controller
    else if (a == 12'd259)                 ctrl_byte = aerl;                      // AERL (0's based)
    else if (a == 12'd260)                 ctrl_byte = 8'h03;                     // FRMW: 1 slot, slot 1 RO
    else if (a == 12'd261)                 ctrl_byte = 8'h04;                     // LPA: extended data
    else if (a == 12'd262)                 ctrl_byte = 8'(NERR - 1);              // ELPE
    else if (a == 12'd512)                 ctrl_byte = 8'h66;                     // SQES
    else if (a == 12'd513)                 ctrl_byte = 8'h44;                     // CQES
    else if (a == 12'd516)                 ctrl_byte = 8'h01;                     // NN
    else if (a == 12'd525)                 ctrl_byte = 8'h07;                     // VWC
    else if (a >= 12'd768 && a < 12'(768 + NQN_LEN)) ctrl_byte = NQN[8*(NQN_LEN - 1 - (32'(a) - 768)) +: 8];
  endfunction

  function automatic logic [7:0] ns_byte(input logic [11:0] a, input logic [63:0] sz);
    ns_byte = 8'h00;
    if (a < 12'd24)        ns_byte = sz[8*32'(a[2:0]) +: 8];                  // NSZE, NCAP, NUSE
    else if (a == 12'd130) ns_byte = 8'd9;                                         // LBAF0.LBADS = 9 (512 B)
  endfunction

  logic [EW-1:0] ent;
  logic [11:0]   b0;
  always_comb begin
    word = 32'h0;
    b0   = {widx, 2'b00};
    ent  = '0;
    case (sel)
      SEL_ID_CTRL: word = {ctrl_byte(b0 + 12'd3), ctrl_byte(b0 + 12'd2), ctrl_byte(b0 + 12'd1), ctrl_byte(b0)};
      SEL_ID_NS:   word = {ns_byte(b0 + 12'd3, nsze), ns_byte(b0 + 12'd2, nsze), ns_byte(b0 + 12'd1, nsze),
                           ns_byte(b0, nsze)};
      SEL_NS_LIST: word = (widx == 10'd0 && nsid_field == 32'd0) ? 32'd1 : 32'd0;
      SEL_LOG_ERR: begin
        if (32'(widx[9:4]) < NERR) begin
          ent = elog[32'(widx[9:4])*EW +: EW];
          case (widx[3:0])
            4'd0: word = ent[EW-33 -: 32];                                                // count[31:0]
            4'd1: word = ent[EW-1 -: 32];                                                // count[63:32]
            4'd2: word = {ent[EW-81 -: 16], ent[EW-65 -: 16]};                           // CID : SQID
            4'd3: word = {ent[EW-109 -: 16], ent[EW-97], 1'b0, 2'b00, ent[EW-98 -: 11], 1'b0}; // PLOC : status
            4'd4: word = ent[63:32];                                                     // LBA[31:0]
            4'd5: word = ent[95:64];                                                     // LBA[63:32]
            4'd6: word = ent[31:0];                                                      // NSID
            default: word = 32'h0;
          endcase
        end
      end
      SEL_LOG_SMART: begin
        case (widx)
          10'd8:  word = s_dur[31:0];   10'd9:  word = s_dur[63:32];
          10'd12: word = s_duw[31:0];   10'd13: word = s_duw[63:32];
          10'd16: word = s_hrc[31:0];   10'd17: word = s_hrc[63:32];
          10'd20: word = s_hwc[31:0];   10'd21: word = s_hwc[63:32];
          10'd24: word = s_busy[31:0];  10'd25: word = s_busy[63:32];
          10'd40: word = s_media[31:0]; 10'd41: word = s_media[63:32];
          10'd44: word = s_errs[31:0];  10'd45: word = s_errs[63:32];
          default: word = 32'h0;
        endcase
      end
      SEL_LOG_FW: begin
        if (widx == 10'd0)      word = 32'h0000_0001;                                    // AFI: slot 1 active
        else if (widx == 10'd2) word = {FR[39:32], FR[47:40], FR[55:48], FR[63:56]};
        else if (widx == 10'd3) word = {FR[7:0], FR[15:8], FR[23:16], FR[31:24]};
      end
      SEL_LOG_PERF: begin
        if (!widx[0] && 32'(widx[9:1]) < NPERF) word = perf[32'(widx[9:1])*32 +: 32];
      end
      SEL_ZERO: word = 32'h0;
      default:  word = 32'h0;
    endcase
  end
endmodule

`default_nettype wire
