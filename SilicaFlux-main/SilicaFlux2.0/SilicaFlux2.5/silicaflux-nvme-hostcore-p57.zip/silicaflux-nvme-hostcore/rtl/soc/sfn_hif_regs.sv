// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_hif_regs -- P51 HIF firmware page, NVMe-driven
//
// The P51 StorageCore firmware talks to its host interface only through the HIF
// register page (ControlCore accelerator page 14, docs/MEMORY_MAP.md of P51):
//   HIF_STATE        RO  [0] EN [1] SHN [2] RDY [3] RESETTING [4] CFS [7:6] SHST
//                        [15:8] SQ head [23:16] SQ tail [31:24] CQ tail
//   HIF_CTRL         RW  [0] RDY [1] CFS [3:2] SHST (firmware -> host status)
//   HIF_EVT_STATUS   W1C EN_RISE, EN_FALL, SHN, DB_ERR, RESET_DONE
//   HIF_EVT_EN       RW  -> irq_hif
//   HIF_DB_ERR_INFO  RO  last invalid doorbell
//   HIF_CQ_STALLS    RO  completion stall cycles
// This block reproduces that page register for register, but the host side
// is the NVMe front end instead of P51's own SQ/CQ rings:
//   EN        = NVMe controller enabled with a valid configuration (fe_en)
//   SHN       = CC.SHN != 00b (fe_shn)
//   RESETTING = NVMe controller reset in progress (fe_resetting)
//   RESET_DONE event when the front end finished its reset (fe_reset_done):
//               RDY and SHST are cleared, exactly as sfs_host_if did
// so the UNMODIFIED P51 firmware raises RDY (-> CSTS.RDY), aborts its tags on
// EN 1->0, checkpoints on SHN and reports SHST (-> CSTS.SHST).  The queue
// pointer fields of HIF_STATE are 0 (NVMe queues live in host memory and are
// owned by the front end); the firmware only prints them.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfn_hif_regs
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  // firmware page
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             irq_hif,
  // NVMe front end
  input  wire logic        fe_en,
  input  wire logic        fe_shn,
  input  wire logic        fe_resetting,
  input  wire logic        fe_reset_done,
  input  wire logic        fe_db_err,
  input  wire logic [15:0] fe_db_info,
  input  wire logic        cq_stall,
  // to the front end
  output logic             rdy_o,
  output logic             cfs_o,
  output logic [1:0]       shst_o
);
  logic        rdy, cfs, en_q, shn_q;
  logic [1:0]  shst;
  logic [4:0]  evt_status, evt_en;
  logic [16:0] db_err_info;
  logic [31:0] cq_stalls;

  wire fw_wr = rb_sel && rb_we;
  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    case (rb_addr)
      SFS_HIF_STATE:       rb_rdata = {8'h00, 8'h00, 8'h00, shst, 1'b0, cfs, fe_resetting, rdy, fe_shn, fe_en};
      SFS_HIF_CTRL:        rb_rdata = {28'h0, shst, cfs, rdy};
      SFS_HIF_EVT_STATUS:  rb_rdata = {27'h0, evt_status};
      SFS_HIF_EVT_EN:      rb_rdata = {27'h0, evt_en};
      SFS_HIF_DB_ERR_INFO: rb_rdata = {15'h0, db_err_info};
      SFS_HIF_CQ_STALLS:   rb_rdata = cq_stalls;
      default:             rb_err = 1'b1;
    endcase
    if (rb_we && (rb_addr == SFS_HIF_STATE || rb_addr == SFS_HIF_DB_ERR_INFO || rb_addr == SFS_HIF_CQ_STALLS))
      rb_err = 1'b1;
  end
  assign irq_hif = |(evt_status & evt_en);

  logic [4:0] evt_set, evt_clr;
  always_comb begin
    evt_set = (5'(fe_en && !en_q) << SFS_HEVT_EN_RISE) | (5'(!fe_en && en_q) << SFS_HEVT_EN_FALL) |
              (5'(fe_shn && !shn_q) << SFS_HEVT_SHN) | (5'(fe_db_err) << SFS_HEVT_DB_ERR) |
              (5'(fe_reset_done) << SFS_HEVT_RESET_DONE);
    evt_clr = (fw_wr && rb_addr == SFS_HIF_EVT_STATUS) ? rb_wdata[4:0] : 5'd0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rdy <= 1'b0; cfs <= 1'b0; shst <= 2'b00; en_q <= 1'b0; shn_q <= 1'b0; evt_status <= '0; evt_en <= '0;
      db_err_info <= '0; cq_stalls <= '0;
    end else begin
      en_q  <= fe_en;
      shn_q <= fe_shn;
      evt_status <= (evt_status & ~evt_clr) | evt_set;
      if (fe_db_err) db_err_info <= {1'b0, fe_db_info};
      if (cq_stall && cq_stalls != 32'hFFFF_FFFF) cq_stalls <= cq_stalls + 32'd1;
      if (fw_wr && rb_addr == SFS_HIF_CTRL) begin
        // RDY can only be raised while enabled and not resetting (as in sfs_host_if)
        if (rb_wdata[0] && fe_en && !fe_resetting && !rdy) rdy <= 1'b1;
        else if (!rb_wdata[0] && rdy) rdy <= 1'b0;
        cfs  <= rb_wdata[1];
        shst <= rb_wdata[3:2];
      end
      if (fw_wr && rb_addr == SFS_HIF_EVT_EN) evt_en <= rb_wdata[4:0];
      if (fe_reset_done) begin rdy <= 1'b0; shst <= 2'b00; end
    end
  end
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^rb_wdata[31:5];
  /* verilator lint_on UNUSEDSIGNAL */
  assign rdy_o  = rdy;
  assign cfs_o  = cfs;
  assign shst_o = shst;
endmodule

`default_nettype wire
