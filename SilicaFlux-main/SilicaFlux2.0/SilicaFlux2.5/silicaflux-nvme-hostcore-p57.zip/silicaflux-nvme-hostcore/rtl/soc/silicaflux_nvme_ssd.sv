// =============================================================================
// SilicaFlux-STORE (Project 57) :: silicaflux_nvme_ssd -- NVMe front end on the StorageCore SoC
//
//   PCIe endpoint (vendor IP / simulation model)
//     │ SFN-TL (completer + requester), cfg status, MSI / INTx
//   silicaflux_nvme_controller (P57) ── sfs_cmd_t / sfs_cpl_t ──► sfn_storage_backend
//     ▲ host-memory window (SFB2) ◄── storage DMA                   │ sfs_cmd_ctrl, DataFabric, buffer SRAM
//     │ fe_en / fe_resetting / fe_shn ─► HIF page (sfn_hif_regs)    │ (SECDED), storage DMA, NAND channel(s)
//   ControlCore (P21, UNMODIFIED) running the P51 storage firmware (UNMODIFIED): FTL, NAND, PLP
//
// The ControlCore host-access port is exposed as a separate management port
// (mg_*): it models the boot-image loader (SPI flash / debug) that a product
// would use.  It is NOT reachable through PCIe.  The firmware image is loaded
// through it by the ControlCore boot-ROM flow (header + CRC32 check).
//
// Resets: rst_ni = power-on reset (whole device; NAND media keep their
// contents); ep_rst_ni = endpoint user reset (hot reset / link down): resets the
// NVMe front end only.  One functional clock.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module silicaflux_nvme_ssd
  import silicaflux_nvme_pkg::*;
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
#(
  parameter int NUM_IOQ            = 1,
  parameter int NUM_VEC            = 8,
  parameter int CPL_TIMEOUT        = 65536,
  parameter int ENABLE_EXT_ADMIN   = 1,
  parameter int NUM_NAND_CHANNELS  = 1,
  parameter int CHANNEL_DATA_WIDTH = 8,
  parameter int BUFFER_SIZE_BYTES  = 16384,
  parameter int ADDRESS_WIDTH      = 32,
  parameter int CMD_QUEUE_DEPTH    = 8,
  parameter int ENABLE_ECC         = 1,
  parameter int ENABLE_RAS         = 1,
  parameter int NAND_PAGE_BYTES    = 512,
  parameter int SRAM_BACKEND       = `SRAM_BACKEND_GENERIC,
  localparam int NCH = NUM_NAND_CHANNELS,
  localparam int CDW = CHANNEL_DATA_WIDTH,
  localparam int DW  = 32
) (
  input  wire logic               clk,
  input  wire logic               rst_ni,
  input  wire logic               ep_rst_ni,
  input  wire logic               test_mode,
  input  wire logic [1:0]         boot_mode_i,
  input  wire logic               pwr_fail_ni,
  // ---------------------------------------------------------------- SFN-TL (PCIe endpoint user interface)
  input  wire logic               cq_valid,
  output logic                    cq_ready,
  input  wire logic               cq_write,
  input  wire logic [2:0]         cq_bar,
  input  wire logic [63:0]        cq_addr,
  input  wire logic [10:0]        cq_len_dw,
  input  wire logic [3:0]         cq_first_be,
  input  wire logic [3:0]         cq_last_be,
  input  wire logic [7:0]         cq_tag,
  input  wire logic [15:0]        cq_req_id,
  input  wire logic [31:0]        cq_data,
  input  wire logic               cq_last,
  output logic                    cc_valid,
  input  wire logic               cc_ready,
  output logic [7:0]              cc_tag,
  output logic [15:0]             cc_req_id,
  output logic [2:0]              cc_status,
  output logic [12:0]             cc_byte_count,
  output logic [6:0]              cc_lower_addr,
  output logic [10:0]             cc_len_dw,
  output logic [31:0]             cc_data,
  output logic                    cc_last,
  output logic                    rq_valid,
  input  wire logic               rq_ready,
  output logic                    rq_write,
  output logic [63:0]             rq_addr,
  output logic [10:0]             rq_len_dw,
  output logic [3:0]              rq_first_be,
  output logic [3:0]              rq_last_be,
  output logic [7:0]              rq_tag,
  output logic [31:0]             rq_data,
  output logic                    rq_last,
  input  wire logic               rc_valid,
  output logic                    rc_ready,
  input  wire logic [7:0]         rc_tag,
  input  wire logic [2:0]         rc_status,
  input  wire logic [12:0]        rc_byte_count,
  input  wire logic [6:0]         rc_lower_addr,
  input  wire logic [10:0]        rc_len_dw,
  input  wire logic [31:0]        rc_data,
  input  wire logic               rc_last,
  input  wire logic               cfg_bme,
  input  wire logic [2:0]         cfg_mps,
  input  wire logic [2:0]         cfg_mrrs,
  input  wire logic               cfg_msi_en,
  input  wire logic [2:0]         cfg_msi_mme,
  input  wire logic               cfg_intx_dis,
  input  wire logic               cfg_flr,
  output logic                    msi_valid,
  input  wire logic               msi_ready,
  output logic [4:0]              msi_vector,
  output logic                    intx_assert,
  // ---------------------------------------------------------------- management / boot port (SFB2 slave, not PCIe)
  input  wire logic               mg_req_valid,
  output logic                    mg_req_ready,
  input  wire logic               mg_req_write,
  input  wire logic [31:0]        mg_req_addr,
  input  wire logic [31:0]        mg_req_wdata,
  input  wire logic [3:0]         mg_req_wstrb,
  output logic                    mg_rsp_valid,
  input  wire logic               mg_rsp_ready,
  output logic [31:0]             mg_rsp_rdata,
  output logic                    mg_rsp_error,
  output logic                    mgmt_irq_o,
  output logic                    host_ready_o,
  output logic                    cmdproc_ready_o,
  output logic                    ras_fatal_o,
  // ---------------------------------------------------------------- NAND channels
  output logic [NCH-1:0]          nand_ce_n,
  output logic [NCH-1:0]          nand_cle,
  output logic [NCH-1:0]          nand_ale,
  output logic [NCH-1:0]          nand_we_n,
  output logic [NCH-1:0]          nand_re_n,
  output logic [NCH-1:0]          nand_wp_n,
  output logic [NCH*CDW-1:0]      nand_dq_o,
  output logic [NCH-1:0]          nand_dq_oe,
  input  wire logic [NCH*CDW-1:0] nand_dq_i,
  input  wire logic [NCH-1:0]     nand_rb_n,
  // ---------------------------------------------------------------- diagnostics
  output logic                    diag_valid_o,
  output logic [7:0]              diag_char_o,
  output logic                    test_done_o,
  output logic                    test_fail_o,
  output logic [15:0]             test_code_o,
  output logic                    cpu_sleep_o,
  output logic [2:0]              nvme_state_o,
  output logic [32*32-1:0]        nvme_perf_o
);
  // ================================================================ resets
  logic sys_rst_n, fe_rst_n;
  sfv_rst_sync u_rs_sys (.clk, .rst_ni(rst_ni), .test_mode, .test_rst_ni(rst_ni), .rst_no(sys_rst_n));
  wire fe_rst_raw = rst_ni && ep_rst_ni;
  sfv_rst_sync u_rs_fe (.clk, .rst_ni(fe_rst_raw), .test_mode, .test_rst_ni(rst_ni), .rst_no(fe_rst_n));

  // ================================================================ management port -> gate -> ControlCore host port
  logic        mgmt_lock, sec_viol;
  logic        hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error;
  logic [31:0] hs_req_addr, hs_req_wdata, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        mg_idle;
  /* verilator lint_on UNUSEDSIGNAL */
  wire mg_storage_page = (mg_req_addr >= SFS_SYS_BASE) && (mg_req_addr < SFS_SYS_BASE + 32'h6000);
  cc_sfb_gate u_mgmt_gate (
    .clk, .rst_n(sys_rst_n),
    .s_req_valid(mg_req_valid), .s_req_ready(mg_req_ready), .s_req_write(mg_req_write), .s_req_addr(mg_req_addr),
    .s_req_wdata(mg_req_wdata), .s_req_wstrb(mg_req_wstrb), .s_rsp_valid(mg_rsp_valid), .s_rsp_ready(mg_rsp_ready),
    .s_rsp_rdata(mg_rsp_rdata), .s_rsp_error(mg_rsp_error),
    .m_req_valid(hs_req_valid), .m_req_ready(hs_req_ready), .m_req_write(hs_req_write), .m_req_addr(hs_req_addr),
    .m_req_wdata(hs_req_wdata), .m_req_wstrb(hs_req_wstrb), .m_rsp_valid(hs_rsp_valid), .m_rsp_ready(hs_rsp_ready),
    .m_rsp_rdata(hs_rsp_rdata), .m_rsp_error(hs_rsp_error),
    .refuse(mgmt_lock && mg_storage_page), .refused_evt(sec_viol), .idle(mg_idle)
  );

  // ================================================================ ControlCore (unmodified)
  logic        acc_rb_sel, acc_rb_we, acc_rb_err;
  logic [15:0] acc_rb_addr;
  logic [31:0] acc_rb_wdata, acc_rb_rdata;
  logic        ext_req_valid, ext_req_ready, ext_req_write, ext_rsp_valid, ext_rsp_ready, ext_rsp_error;
  logic [31:0] ext_req_addr, ext_req_wdata, ext_rsp_rdata;
  logic [3:0]  ext_req_wstrb;
  logic        stor_rst_n, irq_io, irq_evt, busy_nand, busy_io, ext_warn, ext_fatal;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        acc_clk_unused;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_control_core #(.RV32M(1), .SRAM_PARITY(1), .SRAM_BACKEND(SRAM_BACKEND),
                            .MIMPID(32'h0057_0001)) u_cc (
    .clk, .rst_ni, .test_mode, .boot_mode_i, .host_rst_req_i(1'b0),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(mgmt_irq_o), .host_ready_o, .cmdproc_ready_o, .ras_fatal_o,
    .acc_rb_sel, .acc_rb_we, .acc_rb_addr, .acc_rb_wdata, .acc_rb_rdata, .acc_rb_err,
    .ext_req_valid, .ext_req_ready, .ext_req_write, .ext_req_addr, .ext_req_wdata, .ext_req_wstrb,
    .ext_rsp_valid, .ext_rsp_ready, .ext_rsp_rdata, .ext_rsp_error,
    .acc_clk_o(acc_clk_unused), .acc_rst_no(stor_rst_n),
    .acc_vec_irq_i(irq_evt), .acc_tsu_irq_i(irq_io),
    .acc_vec_busy_i(busy_nand), .acc_tsu_busy_i(busy_io), .acc_tsu_halted_i(1'b0),
    .ext_warn_i(ext_warn), .ext_fatal_i(ext_fatal),
    .diag_valid_o, .diag_char_o, .test_done_o, .test_fail_o, .test_code_o, .cpu_sleep_o
  );

  // ================================================================ storage back end (P51 subsystem without sfs_host_if)
  logic        be_cmd_valid, be_cmd_ready, be_cpl_valid, be_cpl_ready, be_idle, be_rdy, be_cfs;
  sfs_cmd_t    be_cmd;
  sfs_cpl_t    be_cpl;
  logic [63:0] be_capacity;
  logic [15:0] be_mdts;
  logic [1:0]  be_shst;
  logic        fe_en, fe_shn, fe_resetting, fe_reset_done, fe_db_err;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr, hm_req_wdata, hm_rsp_rdata;
  logic [3:0]  hm_req_wstrb;
  sfn_storage_backend #(
    .NUM_NAND_CHANNELS(NUM_NAND_CHANNELS), .CHANNEL_DATA_WIDTH(CHANNEL_DATA_WIDTH),
    .BUFFER_SIZE_BYTES(BUFFER_SIZE_BYTES), .DMA_DATA_WIDTH(DW), .ADDRESS_WIDTH(ADDRESS_WIDTH),
    .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .ENABLE_ECC(ENABLE_ECC), .ENABLE_RAS(ENABLE_RAS),
    .NAND_PAGE_BYTES(NAND_PAGE_BYTES), .SRAM_BACKEND(SRAM_BACKEND)
  ) u_be (
    .clk, .rst_n(stor_rst_n),
    .x_req_valid(ext_req_valid), .x_req_ready(ext_req_ready), .x_req_write(ext_req_write), .x_req_addr(ext_req_addr),
    .x_req_wdata(ext_req_wdata), .x_req_wstrb(ext_req_wstrb), .x_rsp_valid(ext_rsp_valid),
    .x_rsp_ready(ext_rsp_ready), .x_rsp_rdata(ext_rsp_rdata), .x_rsp_error(ext_rsp_error),
    .rb_sel(acc_rb_sel), .rb_we(acc_rb_we), .rb_addr(acc_rb_addr), .rb_wdata(acc_rb_wdata),
    .rb_rdata(acc_rb_rdata), .rb_err(acc_rb_err),
    .cmd_valid(be_cmd_valid), .cmd_ready(be_cmd_ready), .cmd(be_cmd), .cpl_valid(be_cpl_valid),
    .cpl_ready(be_cpl_ready), .cpl(be_cpl), .capacity(be_capacity), .mdts(be_mdts), .outstanding_zero(be_idle),
    .fe_en, .fe_shn, .fe_resetting, .fe_reset_done, .fe_db_err, .fe_cq_stall(1'b0),
    .be_rdy, .be_cfs, .be_shst,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .nand_ce_n, .nand_cle, .nand_ale, .nand_we_n, .nand_re_n, .nand_wp_n, .nand_dq_o, .nand_dq_oe, .nand_dq_i,
    .nand_rb_n,
    .pwr_fail_ni, .ev_sec_viol(sec_viol), .mgmt_lock,
    .irq_io, .irq_evt, .busy_nand, .busy_io, .ext_warn, .ext_fatal
  );

  // ================================================================ NVMe front end
  // NCTX = back-end tags; MAX_XFER 8 KiB = P51 MDTS (16 x 512 B); the front end's MDTS follows the back end anyway.
  silicaflux_nvme_controller #(
    .NUM_IOQ(NUM_IOQ), .NCTX(CMD_QUEUE_DEPTH), .NUM_VEC(NUM_VEC), .MAX_XFER_LOG2(13), .CPL_TIMEOUT(CPL_TIMEOUT),
    .ENABLE_EXT_ADMIN(ENABLE_EXT_ADMIN)
  ) u_nvme (
    .clk, .rst_n(fe_rst_n),
    .cq_valid, .cq_ready, .cq_write, .cq_bar, .cq_addr, .cq_len_dw, .cq_first_be, .cq_last_be, .cq_tag, .cq_req_id,
    .cq_data, .cq_last,
    .cc_valid, .cc_ready, .cc_tag, .cc_req_id, .cc_status, .cc_byte_count, .cc_lower_addr, .cc_len_dw, .cc_data, .cc_last,
    .rq_valid, .rq_ready, .rq_write, .rq_addr, .rq_len_dw, .rq_first_be, .rq_last_be, .rq_tag, .rq_data, .rq_last,
    .rc_valid, .rc_ready, .rc_tag, .rc_status, .rc_byte_count, .rc_lower_addr, .rc_len_dw, .rc_data, .rc_last,
    .cfg_bme, .cfg_mps, .cfg_mrrs, .cfg_msi_en, .cfg_msi_mme, .cfg_intx_dis, .cfg_flr,
    .msi_valid, .msi_ready, .msi_vector, .intx_assert,
    .be_cmd_valid, .be_cmd_ready, .be_cmd, .be_cpl_valid, .be_cpl_ready, .be_cpl, .be_capacity, .be_mdts,
    .be_idle, .be_rdy, .be_shst, .be_cfs, .fe_en, .fe_shn, .fe_resetting, .fe_reset_done, .fe_db_err,
    .hw_req_valid(hm_req_valid), .hw_req_ready(hm_req_ready), .hw_req_write(hm_req_write), .hw_req_addr(hm_req_addr),
    .hw_req_wdata(hm_req_wdata), .hw_req_wstrb(hm_req_wstrb), .hw_rsp_valid(hm_rsp_valid),
    .hw_rsp_ready(hm_rsp_ready), .hw_rsp_rdata(hm_rsp_rdata), .hw_rsp_error(hm_rsp_error),
    .dbg_state(nvme_state_o), .perf(nvme_perf_o)
  );
endmodule

`default_nettype wire
