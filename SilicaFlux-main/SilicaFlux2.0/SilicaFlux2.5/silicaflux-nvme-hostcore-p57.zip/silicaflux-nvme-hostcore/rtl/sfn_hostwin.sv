// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_hostwin -- PRP-translated host-memory window
//
// The storage back end (P51 storage DMA, or the unit-test BFM) moves command
// data through an SFB2 slave port ("host memory window").  The NVMe front end
// gives every command context c a private, contiguous window slot:
//
//     window address = c * 2^WIN_LOG2 + byte offset inside the command's data
//
// and this block translates each access through the command's PRP table:
//     pos  = (PRP1 & FFFh) + offset ;  page = pos >> 12
//     host = PRPtable[c][page] (page 0 = PRP1's page) + (pos & FFFh)
// so the back end never sees PRPs, page boundaries or 64-bit host addresses.
//
// Every access is checked: the slot must belong to a command the back end
// currently owns, the direction must match (Read command: back end WRITES to
// the window; Write command: back end READS), the word must lie inside the
// command's transfer length, and writes must be full words.  Anything else
// gets rsp_error and has no host-side effect -- the host only ever sees
// accesses inside its buffer.
//
//   Reads  (streaming prefetch): a miss (re)starts a stream at the accessed
//            offset.  The stream keeps up to PF_BYTES of data requested ahead
//            of the consumer, in reads of up to PF_CHUNK bytes (at most
//            PF_INF in flight) that never cross a memory page and never run past the
//            transfer length.  Words land in a circular buffer; an access
//            completes when its word has arrived.  A failed read (UR / CA /
//            timeout) poisons the stream: accesses answer rsp_error.
//   Writes (double-buffered combining, posted): sequential full words are
//            collected (up to WC_BYTES, never across a memory page) in one
//            buffer while the other is being emitted.  A buffer is closed when
//            full, at a page or transfer end, when the next write is not
//            sequential, after WC_IDLE idle cycles, or on flush_req; closed
//            buffers are emitted strictly in close order.  The write is
//            ACKNOWLEDGED when buffered (SFB2 R7 deviation: posted semantics);
//            ordering is restored by the completion engine, which posts a
//            command's CQE only when wc_empty = 1 (all of its data handed to
//            the endpoint, which keeps posted writes in order).
//   kill   : (controller reset) every new access is refused; buffered write
//            data that has not started to flush is dropped.
// One SFB2 transaction accepted per cycle (R6); 32-bit data only.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfn_hostwin #(
  parameter int CW       = 3,            // context index bits
  parameter int WIN_LOG2 = 20,           // window slot size (bytes) log2
  parameter int XLW      = 16,           // transfer-length width (bytes)
  parameter int PW       = 4,            // page-index width
  parameter int PF_BYTES = 256,          // read-ahead window (power of two)
  parameter int PF_CHUNK = 128,          // bytes per prefetch read
  parameter int PF_INF   = 2,            // prefetch reads in flight (1..7)
  parameter int WC_BYTES = 256,          // per write-combining buffer
  parameter int WC_IDLE  = 16,
  localparam int PFD = PF_BYTES / 4,
  localparam int PFA = $clog2(PFD),
  localparam int WCD = WC_BYTES / 4,
  localparam int WCA = $clog2(WCD),
  localparam int OW  = WIN_LOG2 + 1      // offset arithmetic width
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // ---------------------------------------------------------------- SFB2 slave (back-end DMA)
  input  wire logic            s_req_valid,
  output logic                 s_req_ready,
  input  wire logic            s_req_write,
  input  wire logic [31:0]     s_req_addr,
  input  wire logic [31:0]     s_req_wdata,
  input  wire logic [3:0]      s_req_wstrb,
  output logic                 s_rsp_valid,
  input  wire logic            s_rsp_ready,
  output logic [31:0]          s_rsp_rdata,
  output logic                 s_rsp_error,
  // ---------------------------------------------------------------- command-context lookup (combinational)
  output logic [CW-1:0]        lk_slot,        // port 1: the current access
  output logic [PW-1:0]        lk_page,
  input  wire logic            lk_ok,          // slot owned by the back end and carries data
  input  wire logic            lk_to_host,     // 1: Read command (data to host)
  input  wire logic [XLW-1:0]  lk_len,         // transfer length, bytes
  input  wire logic [11:0]     lk_off1,        // PRP1 offset
  input  wire logic [51:0]     lk_paddr,       // host page address [63:12] of lk_page
  output logic [CW-1:0]        lk2_slot,       // port 2: the prefetch stream
  output logic [PW-1:0]        lk2_page,
  input  wire logic [51:0]     lk2_paddr,
  // ---------------------------------------------------------------- DMA read request / data (id = window)
  output logic                 rd_req_valid,
  input  wire logic            rd_req_ready,
  output logic [63:0]          rd_req_addr,
  output logic [12:0]          rd_req_len,
  input  wire logic            rd_rsp_valid,
  input  wire logic [31:0]     rd_rsp_data,
  input  wire logic            rd_rsp_err,
  input  wire logic            rd_rsp_last,
  // ---------------------------------------------------------------- DMA write
  output logic                 wr_valid,
  input  wire logic            wr_ready,
  output logic [63:0]          wr_addr,
  output logic [12:0]          wr_len,
  output logic [31:0]          wr_data,
  output logic                 wr_last,
  // ---------------------------------------------------------------- control / status
  input  wire logic            flush_req,
  input  wire logic            kill,
  input  wire logic            inval_v,        // context freed: drop prefetched data of that slot
  input  wire logic [CW-1:0]   inval_slot,
  output logic                 wc_empty,
  output logic                 idle,
  output logic                 ev_rd_word,
  output logic                 ev_wr_word,
  output logic                 ev_refused
);
  // ================================================================ request decode
  wire [CW-1:0]         slot  = s_req_addr[WIN_LOG2 +: CW];
  wire [WIN_LOG2-1:0]   off   = s_req_addr[WIN_LOG2-1:0];
  wire                  hi_ok = ((s_req_addr >> (WIN_LOG2 + CW)) == 32'd0) && (s_req_addr[1:0] == 2'b00);
  wire [OW-1:0]         pos   = OW'(lk_off1) + OW'(off);
  assign lk_slot = slot;
  assign lk_page = PW'(pos >> 12);
  wire [11:0]           inpg  = pos[11:0];
  wire [63:0]           phys  = {lk_paddr, inpg};
  wire                  in_len = (OW'(off) + OW'(4)) <= OW'(lk_len);
  wire                  base_ok = !kill && hi_ok && lk_ok && in_len;
  wire                  w_ok  = base_ok && lk_to_host && (s_req_wstrb == 4'hF);
  wire                  r_ok  = base_ok && !lk_to_host;

  // ================================================================ response register
  logic        rsp_v, rsp_e;
  logic [31:0] rsp_d;
  assign s_rsp_valid = rsp_v;
  assign s_rsp_rdata = rsp_d;
  assign s_rsp_error = rsp_e;
  wire   rsp_free = !rsp_v || s_rsp_ready;

  // ================================================================ streaming prefetch
  logic                pf_v, pf_err;
  logic [CW-1:0]       pf_slot;
  logic [11:0]         pf_off1;
  logic [OW-1:0]       pf_lo, pf_hi, pf_rq, pf_end;   // consumed-from, received-to, requested-to, stream limit
  logic [2:0]          pf_inf;                        // reads in flight
  logic                pf_iss;                        // read request presented
  logic [63:0]         pf_addr;
  logic [12:0]         pf_bytes;
  logic [31:0]         pf_buf [PFD];
  wire                 pf_same  = pf_v && (pf_slot == slot);
  wire                 pf_hit   = pf_same && (OW'(off) >= pf_lo) && (OW'(off) < pf_hi);
  // requested but not arrived, or the very next offset the stream will request (sequential consumer)
  wire                 pf_cover = pf_same && !pf_err && (OW'(off) >= pf_lo) &&
                                  ((OW'(off) < pf_rq) || (OW'(off) == pf_rq && pf_rq < pf_end));
  // next prefetch read: translate pf_rq through lookup port 2
  wire [OW-1:0]        p2pos    = OW'(pf_off1) + pf_rq;
  assign lk2_slot = pf_slot;
  assign lk2_page = PW'(p2pos >> 12);
  wire [11:0]          p2inpg   = p2pos[11:0];
  wire [12:0]          p2to_pg  = 13'd4096 - {1'b0, p2inpg};
  wire [OW-1:0]        p2rem    = pf_end - pf_rq;
  logic [12:0]         p2len;
  always_comb begin
    p2len = 13'(PF_CHUNK);
    if (OW'(p2len) > p2rem) p2len = 13'(p2rem);
    if (p2len > p2to_pg) p2len = p2to_pg;
  end
  wire pf_room   = (pf_rq - pf_lo + OW'(p2len)) <= OW'(PF_BYTES);
  wire pf_more   = pf_v && !pf_err && (pf_rq < pf_end) && pf_room && (pf_inf < 3'(PF_INF)) && !pf_iss && !kill;
  assign rd_req_valid = pf_iss;
  assign rd_req_addr  = pf_addr;
  assign rd_req_len   = pf_bytes;

  // ================================================================ double-buffered write combining
  logic                wv   [2];                    // buffer holds data
  logic                wcl  [2];                    // buffer closed (waiting to be / being emitted)
  logic [CW-1:0]       wslot[2];
  logic [WIN_LOG2-1:0] woff [2];
  logic [10:0]         wn   [2];
  logic [63:0]         wphys[2];
  logic [31:0]         wbuf0 [WCD];
  logic [31:0]         wbuf1 [WCD];
  logic                wf;                          // buffer being filled
  logic                wo;                          // next buffer to emit (close order = fill order)
  logic                fl;                          // emitting buffer wo
  logic [10:0]         fl_i;
  logic [7:0]          widle;
  wire                 f_open   = wv[wf] && !wcl[wf];
  wire                 wc_seq   = f_open && (wslot[wf] == slot) &&
                                  (OW'(off) == OW'(woff[wf]) + OW'({wn[wf], 2'b00}));
  wire                 can_app  = wc_seq && (wn[wf] < 11'(WCD)) && (inpg != 12'd0);
  wire                 other_free = !wv[~wf];
  wire                 app_end  = (inpg == 12'hFFC) || (OW'(off) + OW'(4) == OW'(lk_len));

  assign wr_valid = fl;
  assign wr_addr  = wphys[wo];
  assign wr_len   = {wn[wo], 2'b00};
  assign wr_data  = wo ? wbuf1[fl_i[WCA-1:0]] : wbuf0[fl_i[WCA-1:0]];
  assign wr_last  = (fl_i == wn[wo] - 11'd1);
  assign wc_empty = !wv[0] && !wv[1];

  // ================================================================ decisions
  wire is_rd = s_req_valid && !s_req_write;
  wire is_wr = s_req_valid && s_req_write;
  wire rd_err_now = is_rd && !r_ok;
  wire wr_err_now = is_wr && !w_ok;
  wire rd_hit_now = is_rd && r_ok && pf_hit;
  // append into the open buffer, or open a new one (current buffer empty, or closable and the other free)
  wire wr_new_ok  = !wv[wf] || (f_open && !can_app && other_free);
  wire wr_app_now = is_wr && w_ok && (can_app || wr_new_ok);
  assign s_req_ready = rsp_free && (rd_err_now || wr_err_now || rd_hit_now || wr_app_now);
  wire acc = s_req_valid && s_req_ready;
  // a read that misses everything (re)starts the stream once nothing is in flight
  wire start_pf = is_rd && r_ok && !pf_hit && !pf_cover && (pf_inf == 3'd0) && !pf_iss;
  assign ev_rd_word = acc && rd_hit_now;
  assign ev_wr_word = acc && wr_app_now;
  assign ev_refused = acc && (rd_err_now || wr_err_now);
  assign idle = (pf_inf == 3'd0) && !pf_iss && wc_empty;

  // close the open buffer (it is then emitted after the older one)
  wire close_idle = f_open && !(is_wr && w_ok) && (flush_req || widle == 8'(WC_IDLE));
  wire close_new  = acc && wr_app_now && !can_app && f_open;           // non-sequential write opened the other buffer
  wire app_now    = acc && wr_app_now;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_v <= 1'b0; rsp_e <= 1'b0; rsp_d <= '0;
      pf_v <= 1'b0; pf_err <= 1'b0; pf_slot <= '0; pf_off1 <= '0; pf_lo <= '0; pf_hi <= '0; pf_rq <= '0;
      pf_end <= '0; pf_inf <= '0; pf_iss <= 1'b0; pf_addr <= '0; pf_bytes <= '0;
      for (int b = 0; b < 2; b++) begin
        wv[b] <= 1'b0; wcl[b] <= 1'b0; wslot[b] <= '0; woff[b] <= '0; wn[b] <= '0; wphys[b] <= '0;
      end
      wf <= 1'b0; wo <= 1'b0; fl <= 1'b0; fl_i <= '0; widle <= '0;
    end else begin
      // ---------------------------------------------- response
      if (acc) begin
        rsp_v <= 1'b1;
        rsp_e <= rd_err_now || wr_err_now || (rd_hit_now && pf_err);
        rsp_d <= (rd_hit_now && !pf_err) ? pf_buf[off[PFA+1:2]] : 32'h0;
      end else if (s_rsp_ready) rsp_v <= 1'b0;
      // ---------------------------------------------- prefetch stream
      if (start_pf) begin
        pf_v <= 1'b1; pf_err <= 1'b0; pf_slot <= slot; pf_off1 <= lk_off1;
        pf_lo <= OW'(off); pf_hi <= OW'(off); pf_rq <= OW'(off); pf_end <= OW'(lk_len);
      end else begin
        if (acc && rd_hit_now) pf_lo <= OW'(off);                  // sequential consumer: older data may be overwritten
        if (pf_more) begin
          pf_iss <= 1'b1; pf_addr <= {lk2_paddr, p2inpg}; pf_bytes <= p2len; pf_rq <= pf_rq + OW'(p2len);
        end
      end
      if (pf_iss && rd_req_ready) pf_iss <= 1'b0;
      pf_inf <= pf_inf + ((pf_iss && rd_req_ready) ? 3'd1 : 3'd0) - ((rd_rsp_valid && rd_rsp_last) ? 3'd1 : 3'd0);
      if (rd_rsp_valid) begin
        pf_buf[pf_hi[PFA+1:2]] <= rd_rsp_data;
        pf_hi <= pf_hi + OW'(4);
        if (rd_rsp_err) pf_err <= 1'b1;
      end
      if ((inval_v && inval_slot == pf_slot) || kill) pf_v <= 1'b0;
      // ---------------------------------------------- write combining
      if (app_now) begin
        widle <= '0;
        if (can_app) begin
          if (wf) wbuf1[wn[wf][WCA-1:0]] <= s_req_wdata; else wbuf0[wn[wf][WCA-1:0]] <= s_req_wdata;
          wn[wf] <= wn[wf] + 11'd1;
          if (app_end || wn[wf] + 11'd1 == 11'(WCD)) begin wcl[wf] <= 1'b1; wf <= ~wf; end
        end else begin
          // new buffer: the current one (if it holds data) is closed first, in fill order
          logic nb;
          nb = wv[wf] ? ~wf : wf;
          if (wv[wf]) wcl[wf] <= 1'b1;
          if (nb) wbuf1[0] <= s_req_wdata; else wbuf0[0] <= s_req_wdata;
          wv[nb] <= 1'b1; wslot[nb] <= slot; woff[nb] <= off; wphys[nb] <= phys; wn[nb] <= 11'd1;
          wcl[nb] <= app_end || (WCD == 1);
          wf <= (app_end || (WCD == 1)) ? ~nb : nb;
        end
      end else if (close_idle) begin
        wcl[wf] <= 1'b1; wf <= ~wf; widle <= '0;
      end else if (f_open) begin
        widle <= widle + 8'd1;
      end
      // emit closed buffers in order
      if (!fl && !kill && wv[wo] && wcl[wo]) begin fl <= 1'b1; fl_i <= '0; end
      if (fl && wr_ready) begin
        if (wr_last) begin
          fl <= 1'b0; wv[wo] <= 1'b0; wcl[wo] <= 1'b0; wn[wo] <= '0; wo <= ~wo;
        end else fl_i <= fl_i + 11'd1;
      end
      // controller reset: drop data that is not being emitted
      if (kill) begin
        for (int b = 0; b < 2; b++)
          if (wv[b] && !(fl && wo == 1'(b))) begin wv[b] <= 1'b0; wcl[b] <= 1'b0; wn[b] <= '0; end
        if (!fl) begin wo <= wf; end
      end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^pos[OW-1:12] ^ ^p2pos[OW-1:12] ^ close_new ^ ^off[1:0];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
