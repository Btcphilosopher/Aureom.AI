// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_queue_mgr -- NVMe submission / completion queue state
//
// Queue 0 is the Admin SQ / CQ pair (from AQA / ASQ / ACQ at enable), queues
// 1..NQ-1 are I/O queues created and deleted by admin commands.  Queues live in
// host memory and are physically contiguous (CAP.CQR = 1); this block keeps
// only their state:
//
//   SQ: valid, base, size (0's based), tail (host doorbell), fetch pointer
//       (next entry to read), head (entries fully received; reported as SQHD),
//       associated CQ, "deleting" (no further fetches).
//   CQ: valid, base, size, tail (next slot the controller writes), phase tag
//       (starts at 1, inverts on every wrap), head (host doorbell), IEN, IV.
//
// Doorbell validation (one write per cycle):
//   * queue does not exist (or index beyond the implemented queues)
//         -> db_bad_reg ("Invalid Doorbell Register" asynchronous-event class)
//   * value >= queue entries, upper 16 bits set, or a CQ head that would pass
//     the entries the controller has posted
//         -> db_bad_val ("Invalid Doorbell Write Value")
//   An invalid write is ignored (state unchanged).
// The SQ head is advanced only when an entry's data has ARRIVED, so a CQE can
// never tell the host it may reuse a slot whose read is still in flight.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfn_queue_mgr #(
  parameter int NQ = 2,                          // queues per direction incl. admin (2..9)
  localparam int QIW = (NQ > 1) ? $clog2(NQ) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,          // controller reset: delete every queue
  // ---------------------------------------------------------------- admin queues (CC.EN 0 -> 1)
  input  wire logic              admin_init,
  input  wire logic [63:12]      asq_base,
  input  wire logic [63:12]      acq_base,
  input  wire logic [15:0]       asqs,           // 0's based
  input  wire logic [15:0]       acqs,
  // ---------------------------------------------------------------- doorbells
  input  wire logic              db_valid,
  input  wire logic              db_cq,
  input  wire logic [10:0]       db_qid,
  input  wire logic [31:0]       db_val,
  output logic                   db_bad_reg,
  output logic                   db_bad_val,
  output logic                   db_sq_ok,
  output logic                   db_cq_ok,
  // ---------------------------------------------------------------- create / delete (admin engine)
  input  wire logic              cr_valid,
  input  wire logic              cr_cq,
  input  wire logic [QIW-1:0]    cr_qid,
  input  wire logic [63:12]      cr_base,
  input  wire logic [15:0]       cr_size,
  input  wire logic [QIW-1:0]    cr_cqid,
  input  wire logic              cr_ien,
  input  wire logic [4:0]        cr_iv,
  input  wire logic              dl_valid,
  input  wire logic              dl_cq,
  input  wire logic [QIW-1:0]    dl_qid,
  input  wire logic              sd_valid,       // SQ enters "deleting": no further fetches
  input  wire logic [QIW-1:0]    sd_qid,
  // ---------------------------------------------------------------- fetch / post
  input  wire logic              fi_valid,       // SQE read issued: fetch pointer + 1
  input  wire logic [QIW-1:0]    fi_qid,
  input  wire logic              fd_valid,       // SQE received: head + 1
  input  wire logic [QIW-1:0]    fd_qid,
  input  wire logic              po_valid,       // CQE written: tail + 1 (phase flips on wrap)
  input  wire logic [QIW-1:0]    po_qid,
  // ---------------------------------------------------------------- state (flattened, queue i at [i*W +: W])
  output logic [NQ-1:0]          sq_v,
  output logic [NQ-1:0]          sq_del,
  output logic [NQ*52-1:0]       sq_base,
  output logic [NQ*16-1:0]       sq_size,
  output logic [NQ*16-1:0]       sq_tail,
  output logic [NQ*16-1:0]       sq_head,
  output logic [NQ*16-1:0]       sq_fptr,
  output logic [NQ*QIW-1:0]      sq_cqid,
  output logic [NQ-1:0]          cq_v,
  output logic [NQ-1:0]          cq_ph,
  output logic [NQ-1:0]          cq_ien,
  output logic [NQ*52-1:0]       cq_base,
  output logic [NQ*16-1:0]       cq_size,
  output logic [NQ*16-1:0]       cq_tail,
  output logic [NQ*16-1:0]       cq_head,
  output logic [NQ*5-1:0]        cq_iv
);
  function automatic logic [15:0] inc(input logic [15:0] p, input logic [15:0] size);
    inc = (p == size) ? 16'd0 : p + 16'd1;
  endfunction
  // (b - a) modulo (size + 1), for a, b <= size
  function automatic logic [15:0] qdist(input logic [15:0] a, input logic [15:0] b, input logic [15:0] size);
    qdist = (b >= a) ? b - a : 16'(({1'b0, b} + {1'b0, size} + 17'd1) - {1'b0, a});
  endfunction

  // ---------------------------------------------------------------- doorbell validation
  wire [QIW-1:0] dq     = db_qid[QIW-1:0];
  wire           in_rng = (db_qid < 11'(NQ));
  wire           reg_ok = in_rng && (db_cq ? cq_v[dq] : sq_v[dq]);
  wire [15:0]    dsize  = db_cq ? cq_size[dq*16 +: 16] : sq_size[dq*16 +: 16];
  wire [15:0]    dval   = db_val[15:0];
  wire           rng_ok = (db_val[31:16] == 16'h0) && (dval <= dsize);
  wire [15:0]    cq_adv  = qdist(cq_head[dq*16 +: 16], dval, dsize);
  wire [15:0]    cq_used = qdist(cq_head[dq*16 +: 16], cq_tail[dq*16 +: 16], dsize);
  wire           val_ok = rng_ok && (!db_cq || cq_adv <= cq_used);
  assign db_bad_reg = db_valid && !reg_ok;
  assign db_bad_val = db_valid && reg_ok && !val_ok;
  assign db_sq_ok   = db_valid && reg_ok && val_ok && !db_cq;
  assign db_cq_ok   = db_valid && reg_ok && val_ok && db_cq;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sq_v <= '0; sq_del <= '0; sq_base <= '0; sq_size <= '0; sq_tail <= '0; sq_head <= '0; sq_fptr <= '0;
      sq_cqid <= '0; cq_v <= '0; cq_ph <= '0; cq_ien <= '0; cq_base <= '0; cq_size <= '0; cq_tail <= '0;
      cq_head <= '0; cq_iv <= '0;
    end else if (clear) begin
      sq_v <= '0; sq_del <= '0; sq_tail <= '0; sq_head <= '0; sq_fptr <= '0;
      cq_v <= '0; cq_ph <= '0; cq_tail <= '0; cq_head <= '0;
    end else begin
      if (admin_init) begin
        sq_v[0] <= 1'b1; sq_del[0] <= 1'b0; sq_base[0 +: 52] <= asq_base; sq_size[0 +: 16] <= asqs;
        sq_tail[0 +: 16] <= '0; sq_head[0 +: 16] <= '0; sq_fptr[0 +: 16] <= '0; sq_cqid[0 +: QIW] <= '0;
        cq_v[0] <= 1'b1; cq_ph[0] <= 1'b1; cq_ien[0] <= 1'b1; cq_base[0 +: 52] <= acq_base;
        cq_size[0 +: 16] <= acqs; cq_tail[0 +: 16] <= '0; cq_head[0 +: 16] <= '0; cq_iv[0 +: 5] <= '0;
      end
      if (db_sq_ok) sq_tail[dq*16 +: 16] <= dval;
      if (db_cq_ok) cq_head[dq*16 +: 16] <= dval;
      if (fi_valid) sq_fptr[fi_qid*16 +: 16] <= inc(sq_fptr[fi_qid*16 +: 16], sq_size[fi_qid*16 +: 16]);
      if (fd_valid) sq_head[fd_qid*16 +: 16] <= inc(sq_head[fd_qid*16 +: 16], sq_size[fd_qid*16 +: 16]);
      if (po_valid) begin
        cq_tail[po_qid*16 +: 16] <= inc(cq_tail[po_qid*16 +: 16], cq_size[po_qid*16 +: 16]);
        if (cq_tail[po_qid*16 +: 16] == cq_size[po_qid*16 +: 16]) cq_ph[po_qid] <= ~cq_ph[po_qid];
      end
      if (cr_valid) begin
        if (cr_cq) begin
          cq_v[cr_qid] <= 1'b1; cq_ph[cr_qid] <= 1'b1; cq_ien[cr_qid] <= cr_ien; cq_base[cr_qid*52 +: 52] <= cr_base;
          cq_size[cr_qid*16 +: 16] <= cr_size; cq_tail[cr_qid*16 +: 16] <= '0; cq_head[cr_qid*16 +: 16] <= '0;
          cq_iv[cr_qid*5 +: 5] <= cr_iv;
        end else begin
          sq_v[cr_qid] <= 1'b1; sq_del[cr_qid] <= 1'b0; sq_base[cr_qid*52 +: 52] <= cr_base;
          sq_size[cr_qid*16 +: 16] <= cr_size; sq_tail[cr_qid*16 +: 16] <= '0; sq_head[cr_qid*16 +: 16] <= '0;
          sq_fptr[cr_qid*16 +: 16] <= '0; sq_cqid[cr_qid*QIW +: QIW] <= cr_cqid;
        end
      end
      if (sd_valid) sq_del[sd_qid] <= 1'b1;
      if (dl_valid) begin
        if (dl_cq) cq_v[dl_qid] <= 1'b0;
        else begin sq_v[dl_qid] <= 1'b0; sq_del[dl_qid] <= 1'b0; end
      end
    end
  end
endmodule

`default_nettype wire
