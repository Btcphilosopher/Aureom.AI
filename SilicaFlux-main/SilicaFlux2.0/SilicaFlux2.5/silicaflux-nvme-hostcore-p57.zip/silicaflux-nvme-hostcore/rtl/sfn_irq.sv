// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_irq -- NVMe interrupt vectors (pin-based and MSI)
//
// Vector v is PENDING while any valid CQ with IEN = 1 and IV = v holds entries
// the host has not consumed (CQ tail != CQ head).  INTMS / INTMC set / clear the
// per-vector mask (pin-based and MSI modes; MSI-X is not implemented).
//
//   Pin-based (MSI disabled):  intx_assert = |(pending & ~mask), unless the
//     endpoint's INTx Disable bit is set.  The endpoint turns the level into
//     Assert_INTA / Deassert_INTA messages.
//   MSI (single or multiple message): a message for vector v is REQUESTED when
//     a CQE is posted to one of v's CQs, when a CQ-head doorbell leaves v's CQs
//     with unconsumed entries (so an entry posted while the host was reaping is
//     not lost), and when v is unmasked; it is SENT when requested, unmasked and
//     still pending.  Requests made while a message is outstanding merge.  With
//     2^MME messages allocated, vector v uses message v if v < 2^MME, else 0.
// The endpoint must emit an accepted MSI after every posted write accepted
// before it (it carries the CQE); sfn_ep_adapter emits writes in order.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfn_irq #(
  parameter int NQ   = 2,
  parameter int NVEC = 8,                 // 1..32
  localparam int QIW = (NQ > 1) ? $clog2(NQ) : 1
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           clear,      // controller reset: masks and requests cleared
  // CQ state
  input  wire logic [NQ-1:0]  cq_v,
  input  wire logic [NQ-1:0]  cq_ien,
  input  wire logic [NQ*5-1:0] cq_iv,
  input  wire logic [NQ-1:0]  cq_pend,
  // triggers
  input  wire logic           post_evt,
  input  wire logic [QIW-1:0] post_qid,
  input  wire logic           head_evt,
  input  wire logic [QIW-1:0] head_qid,
  input  wire logic           im_set_v,
  input  wire logic           im_clr_v,
  input  wire logic [31:0]    im_wdata,
  // endpoint configuration
  input  wire logic           cfg_msi_en,
  input  wire logic [2:0]     cfg_msi_mme,
  input  wire logic           cfg_intx_dis,
  // to the endpoint
  output logic                msi_valid,
  input  wire logic           msi_ready,
  output logic [4:0]          msi_vector,
  output logic                intx_assert,
  // state
  output logic [31:0]         intms,
  output logic                ev_msi
);
  localparam logic [31:0] VMASK = (NVEC >= 32) ? 32'hFFFF_FFFF : ((32'd1 << NVEC) - 32'd1);
  logic [31:0] mask, need, pend;       // bits >= NVEC are always 0
  always_comb begin
    pend = '0;
    for (int q = 0; q < NQ; q++)
      if (cq_v[q] && cq_ien[q] && cq_pend[q]) pend[cq_iv[q*5 +: 5]] = 1'b1;
    pend = pend & VMASK;
  end
  // requests raised this cycle
  logic [31:0] req;
  always_comb begin
    req = '0;
    if (post_evt && cq_ien[post_qid]) req[cq_iv[post_qid*5 +: 5]] = 1'b1;
    if (head_evt && cq_ien[head_qid]) req[cq_iv[head_qid*5 +: 5]] = 1'b1;
    if (im_clr_v) req = req | (im_wdata & mask);
    req = req & VMASK;
  end

  // message selection (lowest eligible vector), held stable until accepted
  logic       sel_v;
  logic [4:0] sel;
  always_comb begin
    sel_v = 1'b0;
    sel   = '0;
    for (int v = 31; v >= 0; v--)
      if (need[v] && !mask[v] && pend[v]) begin sel_v = 1'b1; sel = 5'(v); end
  end
  logic       out_v;
  logic [4:0] out_vec;                   // internal vector being signalled
  wire  [5:0] nalloc = 6'd1 << cfg_msi_mme;
  assign msi_valid  = out_v;
  assign msi_vector = ({1'b0, out_vec} < nalloc) ? out_vec : 5'd0;
  assign ev_msi     = out_v && msi_ready;
  assign intx_assert = !cfg_msi_en && !cfg_intx_dis && |(pend & ~mask);
  assign intms = mask;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mask <= '0; need <= '0; out_v <= 1'b0; out_vec <= '0;
    end else if (clear) begin
      mask <= '0; need <= '0;
      if (out_v && msi_ready) out_v <= 1'b0;   // a message already offered is completed, never withdrawn
    end else begin
      if (im_set_v) mask <= (mask | im_wdata) & VMASK;
      else if (im_clr_v) mask <= mask & ~im_wdata;
      // keep a request while its vector is pending; drop it once nothing is left to signal
      need <= (need & pend) | req;
      if (out_v) begin
        if (msi_ready) out_v <= 1'b0;
      end else if (cfg_msi_en && sel_v) begin
        out_v   <= 1'b1;
        out_vec <= sel;
        need[sel] <= 1'b0;
        if (req[sel]) need[sel] <= 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
