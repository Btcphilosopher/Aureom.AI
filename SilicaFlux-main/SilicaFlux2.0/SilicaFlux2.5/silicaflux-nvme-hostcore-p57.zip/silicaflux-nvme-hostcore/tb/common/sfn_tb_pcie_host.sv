// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_tb_pcie_host -- transaction-level PCIe transport model
//
// SIMULATION ONLY.  Stands in for "root complex + host memory + IOMMU + the
// endpoint's hard-IP functions" at the SFN-TL user interface of the NVMe
// controller.  There is NO physical layer, data-link layer, link training,
// flow-control credit or 8b/10b / 128b/130b model here, and nothing in this
// file is evidence about real PCIe hardware (docs/06_PCIE_TRANSPORT.md).
//
// What it models:
//   * Endpoint configuration space (Type 0): IDs, class code 01 08 02h, Command
//     (MSE / BME / INTx Disable), 64-bit BAR0 (16 KiB, sizing), MSI capability
//     (64-bit, up to 32 vectors), PCI Express capability (MPS / MRRS / FLR).
//     Configuration requests are applied directly (as hard IP does internally);
//     cfg_* outputs give the controller the resulting state.
//   * Host MMIO: memory read / write TLPs to BAR0 on the completer interface,
//     completions checked (status, byte count, lower address, length).
//     MSE = 0 or an address outside BAR0 -> the endpoint answers UR itself.
//   * Host memory (HMEM_DW x 32 bit) behind an IOMMU: IOVA regions with R/W
//     permissions.  Device reads of unmapped / unreadable addresses complete
//     with UR; device writes to unmapped / read-only addresses are dropped and
//     logged as IOMMU faults (posted writes have no completion).
//   * Device read requests: completions after a random latency, optionally
//     split at RCB boundaries and interleaved across tags; fault injection by
//     address range: Completer Abort, no completion (timeout), late completion.
//   * Posted traffic (device memory writes, MSI messages, INTx assert /
//     deassert) goes through ONE ordered queue with a latency, so anything the
//     controller emits out of order becomes visible out of order.
//   * TLP rule checker: MWr <= MPS, MRd <= MRRS, no 4 KiB crossing, DW-aligned,
//     byte enables, no 64-bit wrap, tag reuse while outstanding, no requests
//     with BME = 0, no MSI while MSI disabled, no INTx while MSI enabled.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfn_tb_pcie_host #(
  parameter int HMEM_DW = 1 << 20                    // 4 MiB host memory
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // completer request (host -> device)
  output logic             cq_valid,
  input  wire logic        cq_ready,
  output logic             cq_write,
  output logic [2:0]       cq_bar,
  output logic [63:0]      cq_addr,
  output logic [10:0]      cq_len_dw,
  output logic [3:0]       cq_first_be,
  output logic [3:0]       cq_last_be,
  output logic [7:0]       cq_tag,
  output logic [15:0]      cq_req_id,
  output logic [31:0]      cq_data,
  output logic             cq_last,
  // completer completion (device -> host)
  input  wire logic        cc_valid,
  output logic             cc_ready,
  input  wire logic [7:0]  cc_tag,
  input  wire logic [15:0] cc_req_id,
  input  wire logic [2:0]  cc_status,
  input  wire logic [12:0] cc_byte_count,
  input  wire logic [6:0]  cc_lower_addr,
  input  wire logic [10:0] cc_len_dw,
  input  wire logic [31:0] cc_data,
  input  wire logic        cc_last,
  // requester request (device -> host)
  input  wire logic        rq_valid,
  output logic             rq_ready,
  input  wire logic        rq_write,
  input  wire logic [63:0] rq_addr,
  input  wire logic [10:0] rq_len_dw,
  input  wire logic [3:0]  rq_first_be,
  input  wire logic [3:0]  rq_last_be,
  input  wire logic [7:0]  rq_tag,
  input  wire logic [31:0] rq_data,
  input  wire logic        rq_last,
  // requester completion (host -> device)
  output logic             rc_valid,
  input  wire logic        rc_ready,
  output logic [7:0]       rc_tag,
  output logic [2:0]       rc_status,
  output logic [12:0]      rc_byte_count,
  output logic [6:0]       rc_lower_addr,
  output logic [10:0]      rc_len_dw,
  output logic [31:0]      rc_data,
  output logic             rc_last,
  // configuration status
  output logic             cfg_bme,
  output logic [2:0]       cfg_mps,
  output logic [2:0]       cfg_mrrs,
  output logic             cfg_msi_en,
  output logic [2:0]       cfg_msi_mme,
  output logic             cfg_intx_dis,
  output logic             cfg_flr,
  // interrupts
  input  wire logic        msi_valid,
  output logic             msi_ready,
  input  wire logic [4:0]  msi_vector,
  input  wire logic        intx_assert
);
  // ================================================================ time
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ================================================================ knobs (set by the test)
  int rd_lat_min = 20, rd_lat_max = 60;     // cycles until a read's first completion may be sent
  int post_lat   = 8;                       // posted-write visibility latency
  int rq_bp_pct  = 0;                       // % of cycles rq_ready = 0
  int msi_bp_pct = 0;
  int cpl_split  = 1;                       // split completions at RCB boundaries
  int cpl_reorder = 1;                      // interleave completions of different tags
  int rcb        = 64;
  logic [63:0] ca_base = 64'hFFFF_FFFF_FFFF_FFFF, ca_size = 0;     // completer abort range
  logic [63:0] drop_base = 64'hFFFF_FFFF_FFFF_FFFF, drop_size = 0; // never completed
  logic [63:0] late_base = 64'hFFFF_FFFF_FFFF_FFFF, late_size = 0; // completed after late_lat
  int late_lat = 100000;

  // ================================================================ statistics / checker results
  int viol = 0, iommu_faults = 0, n_mrd = 0, n_mwr = 0, n_ur = 0, n_ca = 0, n_drop = 0;
  longint unsigned rd_bytes = 0, wr_bytes = 0;
  int msi_total = 0, msi_cnt [32];
  longint unsigned msi_last [32];
  int intx_level = 0, intx_edges = 0;
  longint unsigned last_dev_req = 0;        // cycle of the last request TLP from the device
  int mmio_ur = 0;
  // watch ranges (latency measurements): first device access inside [base, base+len) after arming
  logic [63:0] w_base [4];
  longint unsigned w_len [4], w_hit [4];
  initial for (int i = 0; i < 4; i++) begin w_base[i] = 0; w_len[i] = 0; w_hit[i] = 0; end
  initial for (int i = 0; i < 32; i++) begin msi_cnt[i] = 0; msi_last[i] = 0; end

  task automatic report_viol(input string what);
    viol++;
    if (viol <= 20) $display("[%0d] PCIE-RULE VIOLATION: %s", cyc, what);
  endtask

  // ================================================================ host memory + IOMMU
  logic [31:0] hmem [HMEM_DW];
  localparam int NREG = 16;
  bit          rg_v [NREG];
  logic [63:0] rg_base [NREG];
  logic [63:0] rg_size [NREG];
  int          rg_off  [NREG];             // DW index into hmem
  bit          rg_r [NREG], rg_w [NREG];
  initial for (int i = 0; i < NREG; i++) begin rg_v[i] = 0; rg_base[i] = 0; rg_size[i] = 0; rg_off[i] = 0; rg_r[i] = 0; rg_w[i] = 0; end

  task automatic map(input int slot, input logic [63:0] base, input logic [63:0] size, input int off_dw,
                     input bit r, input bit w);
    rg_v[slot] = 1; rg_base[slot] = base; rg_size[slot] = size; rg_off[slot] = off_dw; rg_r[slot] = r; rg_w[slot] = w;
  endtask
  task automatic unmap(input int slot);
    rg_v[slot] = 0;
  endtask
  // IOVA -> DW index; -1 when unmapped or the permission is missing (need: 0 any, 1 read, 2 write)
  int nreg_scan = NREG;                     // runtime loop bound: keeps Verilator from unrolling the lookup
  function automatic int xlate(input logic [63:0] a, input int need);
    xlate = -1;
    for (int i = 0; i < nreg_scan; i++)
      if (rg_v[i] && a >= rg_base[i] && (a - rg_base[i]) < rg_size[i]) begin
        if (need == 0 || (need == 1 && rg_r[i]) || (need == 2 && rg_w[i]))
          xlate = rg_off[i] + int'((a - rg_base[i]) >> 2);
      end
  endfunction
  // host CPU accesses (no permission check)
  task automatic hw32(input logic [63:0] a, input logic [31:0] v);
    int i;
    i = xlate(a, 0);
    if (i < 0) $display("[%0d] TB ERROR: host write to unmapped IOVA %h", cyc, a);
    else hmem[i] = v;
  endtask
  function automatic logic [31:0] hr32(input logic [63:0] a);
    int i;
    i = xlate(a, 0);
    hr32 = (i < 0) ? 32'hDEAD_BEEF : hmem[i];
  endfunction

  // ================================================================ configuration space
  logic [15:0] c_cmd = 0;                   // Command
  logic [63:0] c_bar = 0;                   // BAR0/1 (64-bit)
  bit          c_bar_sizing = 0;
  logic [15:0] c_msictl = 16'h0080 | 16'h000A;   // 64-bit capable, MMC = 5 (32 vectors)
  logic [63:0] c_msi_addr = 0;
  logic [15:0] c_msi_data = 0;
  logic [15:0] c_devctl = 16'h2000 | 16'h0000;   // MRRS 512 B (010b), MPS 128 B
  localparam logic [15:0] VID = 16'hFFFE, DID = 16'h0057;
  localparam int BAR_SIZE = 16384;
  assign cfg_bme      = c_cmd[2];
  assign cfg_intx_dis = c_cmd[10];
  assign cfg_mps      = c_devctl[7:5];
  assign cfg_mrrs     = c_devctl[14:12];
  assign cfg_msi_en   = c_msictl[0];
  assign cfg_msi_mme  = c_msictl[6:4];
  logic flr_q = 1'b0;
  assign cfg_flr = flr_q;

  function automatic logic [31:0] cfg_rd(input int off);
    case (off)
      'h00: cfg_rd = {DID, VID};
      'h04: cfg_rd = {16'h0010, c_cmd};                        // status: capabilities list
      'h08: cfg_rd = {8'h01, 8'h08, 8'h02, 8'h00};             // class 01h / 08h / 02h, revision 0
      'h0C: cfg_rd = 32'h0000_0000;                            // header type 0
      'h10: cfg_rd = c_bar_sizing ? (~32'(BAR_SIZE - 1) | 32'h4) : (c_bar[31:0] | 32'h4);
      'h14: cfg_rd = c_bar_sizing ? 32'hFFFF_FFFF : c_bar[63:32];
      'h2C: cfg_rd = {DID, VID};                               // subsystem
      'h34: cfg_rd = 32'h50;                                   // capabilities pointer
      'h3C: cfg_rd = 32'h0000_0100;                            // interrupt pin INTA
      'h50: cfg_rd = {c_msictl, 8'h70, 8'h05};                 // MSI capability -> next 70h
      'h54: cfg_rd = c_msi_addr[31:0];
      'h58: cfg_rd = c_msi_addr[63:32];
      'h5C: cfg_rd = {16'h0, c_msi_data};
      'h70: cfg_rd = {16'h0002, 8'h00, 8'h10};                 // PCIe capability, endpoint
      'h74: cfg_rd = 32'h1000_0001;                            // DevCap: FLR capable, MPS supported 256 B
      'h78: cfg_rd = {16'h0, c_devctl};
      default: cfg_rd = 32'h0;
    endcase
  endfunction
  task automatic cfg_wr(input int off, input logic [31:0] v);
    case (off)
      'h04: c_cmd = v[15:0] & 16'h0406;                        // MSE, BME, INTx Disable
      'h10: if (v == 32'hFFFF_FFFF) c_bar_sizing = 1; else begin c_bar_sizing = 0; c_bar[31:0] = v & ~32'(BAR_SIZE - 1); end
      'h14: if (v != 32'hFFFF_FFFF) c_bar[63:32] = v;
      'h50: c_msictl = (c_msictl & ~16'h0071) | (v[31:16] & 16'h0071);
      'h54: c_msi_addr[31:0] = v & 32'hFFFF_FFFC;
      'h58: c_msi_addr[63:32] = v;
      'h5C: c_msi_data = v[15:0];
      'h78: begin
        c_devctl = v[15:0] & 16'h70E0;
        if (v[15]) begin                                       // Initiate Function Level Reset
          c_cmd = 0; c_msictl = c_msictl & ~16'h0071; c_devctl = 16'h2000;
          @(posedge clk); flr_q <= 1'b1; @(posedge clk); flr_q <= 1'b0;
        end
      end
      default: ;
    endcase
  endtask

  // ================================================================ posted queue (device MWr DWs, MSI, INTx) -- strictly ordered
  localparam int PQN = 32768;
  int          pq_kind [PQN];               // 0 data DW, 1 MSI, 2 INTx assert, 3 INTx deassert
  logic [63:0] pq_addr [PQN];
  logic [31:0] pq_data [PQN];
  longint unsigned pq_t [PQN];
  int pq_h = 0, pq_tl = 0;
  longint unsigned pq_last_t = 0;
  task automatic pq_push(input int kind, input logic [63:0] a, input logic [31:0] d);
    longint unsigned t;
    t = cyc + longint'(post_lat);
    if (t < pq_last_t) t = pq_last_t;
    pq_last_t = t;
    pq_kind[pq_tl] = kind; pq_addr[pq_tl] = a; pq_data[pq_tl] = d; pq_t[pq_tl] = t;
    pq_tl = (pq_tl + 1) % PQN;
    if (pq_tl == pq_h) $display("[%0d] TB ERROR: posted queue overflow", cyc);
  endtask
  always @(posedge clk) begin
    while (pq_h != pq_tl && pq_t[pq_h] <= cyc) begin
      case (pq_kind[pq_h])
        0: begin
          int i;
          i = xlate(pq_addr[pq_h], 2);
          if (i < 0) begin
            iommu_faults++;
            if (iommu_faults <= 8) $display("[%0d] IOMMU: device write to %h refused", cyc, pq_addr[pq_h]);
          end else hmem[i] = pq_data[pq_h];
        end
        1: begin
          msi_total++;
          msi_cnt[pq_data[pq_h][4:0]]++;
          msi_last[pq_data[pq_h][4:0]] = cyc;
        end
        2: intx_level = 1;
        3: intx_level = 0;
        default: ;
      endcase
      pq_h = (pq_h + 1) % PQN;
    end
  end

  // ================================================================ device request sink + rule checker
  localparam int RPN = 64;
  bit          rp_v [RPN];
  logic [7:0]  rp_tag [RPN];
  logic [63:0] rp_addr [RPN];               // next byte to complete
  int          rp_rem [RPN];                // bytes remaining
  int          rp_mode [RPN];               // 0 ok, 1 UR, 2 CA, 4 late
  longint unsigned rp_t [RPN];
  longint unsigned rp_seq [RPN];
  longint unsigned seq_ctr = 0;
  initial for (int i = 0; i < RPN; i++) begin rp_v[i] = 0; rp_tag[i] = 0; rp_addr[i] = 0; rp_rem[i] = 0; rp_mode[i] = 0; rp_t[i] = 0; rp_seq[i] = 0; end

  int          rq_beat = 0;
  logic [63:0] rq_haddr;
  bit          in_range;
  function automatic bit in_rng(input logic [63:0] a, input logic [63:0] base, input logic [63:0] size);
    in_rng = (size != 0) && (a >= base) && (a - base < size);
  endfunction
  function automatic int mps_bytes();  mps_bytes  = 128 << c_devctl[7:5];   endfunction
  function automatic int mrrs_bytes(); mrrs_bytes = 128 << c_devctl[14:12]; endfunction

  initial rq_ready = 1'b1;
  always @(posedge clk) begin
    if (rq_valid && rq_ready) begin
      last_dev_req = cyc;
      if (rq_beat == 0) begin
        int bytes;
        bytes = int'(rq_len_dw) * 4;
        rq_haddr = rq_addr;
        if (!cfg_bme) report_viol($sformatf("request with Bus Master Enable clear (addr %h)", rq_addr));
        if (rq_len_dw == 0) report_viol("zero length");
        if (rq_addr[1:0] != 2'b00) report_viol("address not DW aligned");
        if (int'(rq_addr[11:0]) + bytes > 4096) report_viol($sformatf("TLP crosses 4 KiB: %h + %0d", rq_addr, bytes));
        if ({1'b0, rq_addr} + 65'(bytes) > 65'h1_0000_0000_0000_0000) report_viol("64-bit address wrap");
        if (rq_first_be != 4'hF) report_viol("first BE != Fh");
        if ((rq_len_dw == 1 && rq_last_be != 4'h0) || (rq_len_dw > 1 && rq_last_be != 4'hF)) report_viol("last BE");
        for (int k = 0; k < 4; k++)
          if (w_len[k] != 0 && w_hit[k] == 0 && rq_addr >= w_base[k] && rq_addr - w_base[k] < w_len[k]) w_hit[k] = cyc;
        if (rq_write) begin
          n_mwr++;
          if (bytes > mps_bytes()) report_viol($sformatf("MWr %0d B > MPS %0d", bytes, mps_bytes()));
        end else begin
          int slot, need_ok;
          n_mrd++;
          if (bytes > mrrs_bytes()) report_viol($sformatf("MRd %0d B > MRRS %0d", bytes, mrrs_bytes()));
          for (int i = 0; i < RPN; i++) if (rp_v[i] && rp_tag[i] == rq_tag) report_viol($sformatf("tag %0d reused while outstanding", rq_tag));
          slot = -1;
          for (int i = RPN - 1; i >= 0; i--) if (!rp_v[i]) slot = i;
          need_ok = 1;
          for (int k = 0; k < int'(rq_len_dw); k++) if (xlate(rq_addr + 64'(4 * k), 1) < 0) need_ok = 0;
          if (slot < 0) $display("[%0d] TB ERROR: read table full", cyc);
          else if (in_rng(rq_addr, drop_base, drop_size)) n_drop++;
          else begin
            rp_v[slot] = 1; rp_tag[slot] = rq_tag; rp_addr[slot] = rq_addr; rp_rem[slot] = bytes;
            rp_seq[slot] = seq_ctr++;
            rp_mode[slot] = in_rng(rq_addr, ca_base, ca_size) ? 2 : (!need_ok ? 1 : (in_rng(rq_addr, late_base, late_size) ? 4 : 0));
            rp_t[slot] = cyc + longint'(rd_lat_min + ((rd_lat_max > rd_lat_min) ? ($urandom % (rd_lat_max - rd_lat_min + 1)) : 0));
            if (rp_mode[slot] == 4) rp_t[slot] = cyc + longint'(late_lat);
            if (rp_mode[slot] == 1) n_ur++;
            if (rp_mode[slot] == 2) n_ca++;
            rd_bytes += longint'(bytes);
          end
        end
      end
      if (rq_write) begin
        pq_push(0, rq_haddr + 64'(4 * rq_beat), rq_data);
        wr_bytes += 4;
      end
      if (rq_last) begin
        if (rq_beat + 1 != int'(rq_len_dw) && rq_write) report_viol("MWr beat count != length");
        rq_beat = 0;
      end else rq_beat++;
    end
    rq_ready <= (rq_bp_pct == 0) || (($urandom % 100) >= rq_bp_pct);
  end

  // ================================================================ completion generator
  int  cg_slot = -1, cg_beat = 0, cg_len = 0;
  logic [63:0] cg_addr;
  initial begin rc_valid = 0; rc_tag = 0; rc_status = 0; rc_byte_count = 0; rc_lower_addr = 0; rc_len_dw = 0; rc_data = 0; rc_last = 0; end
  always @(posedge clk) begin
    if (rc_valid && rc_ready) begin
      if (rc_last) begin
        rc_valid <= 1'b0;
        if (rc_status != 3'b000) begin rp_v[cg_slot] = 0; end
        else begin
          rp_rem[cg_slot] -= cg_len;
          rp_addr[cg_slot] += 64'(cg_len);
          if (rp_rem[cg_slot] == 0) rp_v[cg_slot] = 0;
        end
        cg_slot = -1;
      end else begin
        cg_beat++;
        rc_data <= hmem[xlate(cg_addr + 64'(4 * cg_beat), 1)];
        rc_last <= (cg_beat + 1) * 4 == cg_len;
      end
    end
    if (cg_slot < 0 && !(rc_valid && !rc_last)) begin
      // choose a ready request: oldest, or (reorder) a random ready one
      int pick, start, best;
      pick = -1; best = -1;
      start = cpl_reorder ? ($urandom % RPN) : 0;
      for (int k = 0; k < RPN; k++) begin
        int i;
        i = (start + k) % RPN;
        if (rp_v[i] && rp_t[i] <= cyc) begin
          if (cpl_reorder) begin if (pick < 0) pick = i; end
          else if (pick < 0 || rp_seq[i] < rp_seq[pick]) pick = i;
        end
      end
      if (pick >= 0) begin
        cg_slot = pick; cg_beat = 0;
        cg_addr = rp_addr[pick];
        rc_tag <= rp_tag[pick];
        rc_lower_addr <= rp_addr[pick][6:0];
        rc_byte_count <= 13'(rp_rem[pick]);
        rc_valid <= 1'b1;
        if (rp_mode[pick] == 1 || rp_mode[pick] == 2) begin
          rc_status <= (rp_mode[pick] == 1) ? 3'b001 : 3'b100;
          rc_len_dw <= 0; rc_data <= 0; rc_last <= 1'b1; cg_len = 0;
        end else begin
          int to_b;
          to_b = rcb - int'(rp_addr[pick] % 64'(rcb));
          cg_len = rp_rem[pick];
          if (cpl_split && cg_len > to_b) cg_len = to_b + (($urandom % 2) ? rcb : 0);
          if (cg_len > rp_rem[pick]) cg_len = rp_rem[pick];
          rc_status <= 3'b000;
          rc_len_dw <= 11'(cg_len / 4);
          rc_data <= hmem[xlate(cg_addr, 1)];
          rc_last <= (cg_len == 4);
        end
      end
    end
  end

  // ================================================================ MSI / INTx (endpoint functions) -> posted queue
  initial msi_ready = 1'b1;
  logic intx_q = 1'b0;
  always @(posedge clk) begin
    if (msi_valid && msi_ready) begin
      if (!cfg_msi_en) report_viol("MSI requested while MSI is disabled");
      else begin
        logic [4:0] m;
        m = msi_vector & 5'((32'd1 << c_msictl[6:4]) - 1);
        if (c_msi_addr == 64'd0) report_viol("MSI with no message address programmed");
        pq_push(1, c_msi_addr, {27'd0, m});             // message data = MSI Data | m (vector kept for checking)
      end
    end
    msi_ready <= (msi_bp_pct == 0) || (($urandom % 100) >= msi_bp_pct);
    if (intx_assert != intx_q) begin
      if (cfg_msi_en && intx_assert) report_viol("INTx asserted while MSI is enabled");
      pq_push(intx_assert ? 2 : 3, 64'd0, 32'd0);
      if (intx_assert) intx_edges++;
    end
    intx_q <= intx_assert;
  end

  // ================================================================ host MMIO (completer request driver)
  // One clocked process drives every MMIO TLP; tasks only post a request into this mailbox.
  bit          m_req = 0, m_ack = 0;
  bit          m_wr;
  logic [63:0] m_a;
  int          m_ndw;
  logic [3:0]  m_fbe, m_lbe;
  logic [31:0] m_wd [2];
  logic [31:0] m_rd [2];
  logic [2:0]  m_st;
  logic [12:0] m_bc;
  logic [6:0]  m_la;
  int          m_state = 0, m_beat = 0, m_rbeat = 0;
  logic [7:0]  m_tag = 0;
  initial begin
    cq_valid = 0; cq_write = 0; cq_bar = 0; cq_addr = 0; cq_len_dw = 0; cq_first_be = 0; cq_last_be = 0;
    cq_tag = 0; cq_req_id = 16'h0100; cq_data = 0; cq_last = 0; cc_ready = 1;
  end
  always @(posedge clk) begin
    case (m_state)
      0: if (m_req && !m_ack) begin
        bit hit;
        hit = c_cmd[1] && (m_a >= c_bar) && (m_a - c_bar < BAR_SIZE);
        if (!hit) begin
          // the endpoint itself answers UR (reads) / drops (writes)
          m_st <= 3'b001; m_rd[0] <= 32'hFFFF_FFFF; m_rd[1] <= 32'hFFFF_FFFF; mmio_ur++;
          m_ack <= 1'b1; m_state <= 3;
        end else begin
          cq_valid <= 1'b1; cq_write <= m_wr; cq_addr <= m_a; cq_len_dw <= 11'(m_ndw); cq_first_be <= m_fbe;
          cq_last_be <= m_lbe; cq_tag <= m_tag; cq_data <= m_wd[0]; cq_last <= m_wr ? (m_ndw == 1) : 1'b1;
          cq_bar <= 3'd0; m_beat <= 0; m_rbeat <= 0; m_state <= 1;
        end
      end
      1: if (cq_valid && cq_ready) begin
        if (cq_last) begin
          cq_valid <= 1'b0;
          if (m_wr) begin m_st <= 3'b000; m_ack <= 1'b1; m_state <= 3; end
          else m_state <= 2;
        end else begin
          m_beat <= m_beat + 1;
          cq_data <= m_wd[m_beat + 1];
          cq_last <= (m_beat + 2 == m_ndw);
        end
      end
      2: if (cc_valid && cc_ready) begin
        if (cc_tag != m_tag) report_viol("completion tag mismatch");
        m_st <= cc_status; m_bc <= cc_byte_count; m_la <= cc_lower_addr;
        if (m_rbeat < 2) m_rd[m_rbeat] <= cc_data;
        m_rbeat <= m_rbeat + 1;
        if (cc_last) begin m_ack <= 1'b1; m_state <= 3; m_tag <= m_tag + 8'd1; end
      end
      3: if (!m_req) begin m_ack <= 1'b0; m_state <= 0; end
      default: m_state <= 0;
    endcase
  end
  task automatic mmio(input bit wr, input logic [63:0] off, input int ndw, input logic [3:0] fbe, input logic [3:0] lbe,
                      input logic [31:0] d0, input logic [31:0] d1);
    m_wr = wr; m_a = c_bar + off; m_ndw = ndw; m_fbe = fbe; m_lbe = lbe; m_wd[0] = d0; m_wd[1] = d1;
    m_req = 1;
    @(posedge clk); while (!m_ack) @(posedge clk);
    m_req = 0;
    @(posedge clk); while (m_ack) @(posedge clk);
  endtask
  task automatic wr32(input logic [63:0] off, input logic [31:0] v);
    mmio(1, off, 1, 4'hF, 4'h0, v, 0);
  endtask
  task automatic rd32(input logic [63:0] off, output logic [31:0] v);
    mmio(0, off, 1, 4'hF, 4'h0, 0, 0);
    v = m_rd[0];
  endtask
  task automatic rd64(input logic [63:0] off, output logic [63:0] v);
    mmio(0, off, 2, 4'hF, 4'hF, 0, 0);
    v = {m_rd[1], m_rd[0]};
  endtask
  task automatic wr64(input logic [63:0] off, input logic [63:0] v);
    mmio(1, off, 2, 4'hF, 4'hF, v[31:0], v[63:32]);
  endtask

  // ================================================================ helpers for tests
  function automatic int pq_pending(); pq_pending = (pq_tl - pq_h + PQN) % PQN; endfunction
  function automatic int reads_pending();
    reads_pending = 0;
    for (int i = 0; i < RPN; i++) if (rp_v[i]) reads_pending++;
  endfunction
endmodule

`default_nettype wire
