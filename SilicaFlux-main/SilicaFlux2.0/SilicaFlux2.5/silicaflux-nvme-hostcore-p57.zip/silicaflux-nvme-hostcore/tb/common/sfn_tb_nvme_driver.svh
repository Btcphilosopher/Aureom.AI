// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_tb_nvme_driver.svh -- NVMe host driver (test side)
//
// Included into a testbench module that provides: clk, `host` (sfn_tb_pcie_host),
// check() / check_true(), grp, CAPB (media blocks).  Implements what a host NVMe
// driver does: PCIe enumeration (BAR sizing, MSE / BME, MPS / MRRS, MSI),
// controller enable / disable (AQA / ASQ / ACQ / CC, CSTS.RDY polling), SQ
// submission with tail doorbells, CQ reaping with phase tracking and head
// doorbells, queue creation / deletion, PRP construction (PRP1 offset, PRP2
// entry, PRP lists with chaining across list pages, scattered pages), and a
// reference model of the media contents for read checking.
// =============================================================================
  // ================================================================ host memory layout (IOVA)
  localparam logic [63:0] HB    = 64'h0000_0001_0000_0000;   // host memory window (4 MiB, above 4 GiB)
  localparam logic [63:0] ASQ_A = HB + 64'h0000;
  localparam logic [63:0] ACQ_A = HB + 64'h1000;
  function automatic logic [63:0] sq_addr(input int q); sq_addr = HB + 64'h10000 + 64'(q) * 64'h10000; endfunction
  function automatic logic [63:0] cq_addr_f(input int q); cq_addr_f = HB + 64'h0B0000 + 64'(q) * 64'h4000; endfunction
  localparam logic [63:0] LIST_A = HB + 64'h0E0000;           // PRP lists (64 KiB)
  localparam logic [63:0] DATA_A = HB + 64'h100000;           // data pages (3 MiB)

  // ================================================================ NVMe host driver
  logic [63:0] h_sqb [9], h_cqb [9];
  int          h_sqn [9], h_cqn [9], h_sqt [9], h_cqh [9], h_s2c [9], h_sqh [9];
  bit          h_cqp [9];
  bit          h_sq_live [9], h_cq_live [9];       // I/O queues the host believes exist
  logic [31:0] sqe [16];
  logic [15:0] cid_ctr = 16'h0100;
  // last completion
  logic [31:0] c_dw0, c_dw2, c_dw3;
  logic [15:0] c_cid, c_sqhd, c_sqid;
  logic [11:0] c_st;                         // {DNR, SCT, SC}
  bit          c_to;                         // timed out

  int sqe_n = 16;                           // runtime loop bound (see sfn_tb_pcie_host nreg_scan)
  task automatic sqe_clear();
    for (int i = 0; i < sqe_n; i++) sqe[i] = 32'h0;
  endtask
  task automatic sqe_set(input logic [7:0] opc, input logic [31:0] nsid);
    sqe_clear();
    cid_ctr = cid_ctr + 16'd1;
    sqe[0] = {cid_ctr, 8'h00, opc};
    sqe[1] = nsid;
  endtask
  task automatic sqe_prp(input logic [63:0] p1, input logic [63:0] p2);
    sqe[6] = p1[31:0]; sqe[7] = p1[63:32]; sqe[8] = p2[31:0]; sqe[9] = p2[63:32];
  endtask
  // place the SQE in SQ q and ring its tail doorbell
  task automatic submit_nodb(input int q);
    for (int i = 0; i < sqe_n; i++) host.hw32(h_sqb[q] + 64'(h_sqt[q] * 64 + i * 4), sqe[i]);
    h_sqt[q] = (h_sqt[q] + 1) % h_sqn[q];
  endtask
  task automatic ring_sq(input int q);
    host.wr32(64'h1000 + 64'(8 * q), 32'(h_sqt[q]));
  endtask
  task automatic submit(input int q);
    submit_nodb(q);
    ring_sq(q);
  endtask
  task automatic ring_cq(input int c);
    host.wr32(64'h1004 + 64'(8 * c), 32'(h_cqh[c]));
  endtask
  // wait for the next CQE of CQ c; optionally ring the head doorbell
  task automatic reap_impl(input int c, input int max_cyc, input bit ring);
    logic [31:0] w3;
    int n;
    n = 0;
    c_to = 0;
    w3 = host.hr32(h_cqb[c] + 64'(h_cqh[c] * 16 + 12));
    while (w3[16] != h_cqp[c] && n < max_cyc) begin
      @(posedge clk); n++;
      w3 = host.hr32(h_cqb[c] + 64'(h_cqh[c] * 16 + 12));
    end
    if (w3[16] != h_cqp[c]) begin
      c_to = 1; c_st = 12'hFFF; c_cid = 16'hFFFF;
      $display("[%0d] reap timeout on CQ %0d (head %0d)", host.cyc, c, h_cqh[c]);
    end else begin
      c_dw0 = host.hr32(h_cqb[c] + 64'(h_cqh[c] * 16));
      c_dw2 = host.hr32(h_cqb[c] + 64'(h_cqh[c] * 16 + 8));
      c_dw3 = w3;
      c_cid = w3[15:0]; c_sqhd = c_dw2[15:0]; c_sqid = c_dw2[31:16];
      c_st  = {w3[31], w3[27:25], w3[24:17]};
      if (int'(c_sqid) < 9) h_sqh[c_sqid] = int'(c_sqhd);
      h_cqh[c] = h_cqh[c] + 1;
      if (h_cqh[c] == h_cqn[c]) begin h_cqh[c] = 0; h_cqp[c] = !h_cqp[c]; end
      if (ring) ring_cq(c);
    end
  endtask
  int tb_units_r = 0, tb_units_w = 0, tb_reads = 0, tb_writes = 0;   // successful NVMe I/O seen by the host
  // submit the staged SQE on SQ q, wait for its completion, check CID / SQID
  task automatic exec_impl(input int q);
    logic [15:0] cid;
    cid = sqe[0][31:16];
    submit(q);
    reap_impl(h_s2c[q], 200000, 1);
    if (!c_to) begin
      check("CQE CID", c_cid, cid);
      check("CQE SQID", c_sqid, 16'(q));
      if (q != 0 && c_st == 12'h0 && sqe[0][7:0] == IO_READ)  begin tb_reads++;  tb_units_r += int'(sqe[12][15:0]) + 1; end
      if (q != 0 && c_st == 12'h0 && sqe[0][7:0] == IO_WRITE) begin tb_writes++; tb_units_w += int'(sqe[12][15:0]) + 1; end
    end
  endtask
  function automatic logic [11:0] S(input int dnr, input int sct, input int sc);
    S = {1'(dnr), 3'(sct), 8'(sc)};
  endfunction

  // ---------------------------------------------------------------- PCIe enumeration and controller enable
  task automatic pcie_enumerate(input int msi_vecs);   // msi_vecs 0: pin-based interrupts
    logic [31:0] v;
    v = host.cfg_rd('h00); check("cfg VID/DID", v, 32'h0057_FFFE);
    v = host.cfg_rd('h08); check("cfg class code 010802h", v[31:8], 24'h010802);
    host.cfg_wr('h10, 32'hFFFF_FFFF); host.cfg_wr('h14, 32'hFFFF_FFFF);
    v = host.cfg_rd('h10); check("BAR0 size 16 KiB, 64-bit memory", v, 32'hFFFF_C004);
    host.cfg_wr('h10, 32'hF7F0_0000); host.cfg_wr('h14, 32'h0000_0080);   // BAR0 = 0x80_F7F0_0000 (above 4 GiB)
    host.cfg_wr('h78, 32'h0000_2020);                                      // MRRS 512 B, MPS 256 B
    host.cfg_wr('h04, 32'h0000_0006);                                      // MSE | BME
    if (msi_vecs > 0) begin
      host.cfg_wr('h54, 32'hFEE0_0000); host.cfg_wr('h58, 32'h0); host.cfg_wr('h5C, 32'h4000);
      host.cfg_wr('h50, {9'd0, 3'($clog2(msi_vecs)), 3'd0, 1'b1, 16'h0});
    end else host.cfg_wr('h50, 32'h0);
  endtask

  task automatic wait_rdy(input bit want, input int max_cyc, output bit ok);
    logic [31:0] cs;
    int n;
    n = 0;
    host.rd32(R_CSTS, cs);
    while (cs[0] != want && n < max_cyc) begin
      repeat (16) @(posedge clk);
      n += 16;
      host.rd32(R_CSTS, cs);
    end
    ok = (cs[0] == want);
  endtask

  task automatic nvme_disable();
    bit ok;
    logic [31:0] cc;
    host.rd32(R_CC, cc);
    host.wr32(R_CC, cc & ~32'h1);
    wait_rdy(0, 100000, ok);
    check_true("CSTS.RDY -> 0 after CC.EN = 0", ok);
  endtask

  task automatic nvme_enable(input int asqn, input int acqn);
    bit ok;
    nvme_disable();
    h_sqb[0] = ASQ_A; h_cqb[0] = ACQ_A; h_sqn[0] = asqn; h_cqn[0] = acqn; h_sqt[0] = 0; h_cqh[0] = 0; h_cqp[0] = 1;
    h_sqh[0] = 0;
    for (int i = 0; i < 9; i++) begin h_sq_live[i] = 0; h_cq_live[i] = 0; end   // controller reset deletes I/O queues
    h_s2c[0] = 0;
    for (int i = 0; i < acqn * 4; i++) host.hw32(ACQ_A + 64'(4 * i), 32'h0);
    host.wr32(R_AQA, {4'h0, 12'(acqn - 1), 4'h0, 12'(asqn - 1)});
    host.wr64(R_ASQ_LO, ASQ_A);
    host.wr64(R_ACQ_LO, ACQ_A);
    host.wr32(R_CC, 32'h0046_0001);                    // IOCQES 4, IOSQES 6, MPS 0, CSS 0, AMS 0, EN
    wait_rdy(1, 100000, ok);
    check_true("CSTS.RDY -> 1 after CC.EN = 1", ok);
  endtask

  task automatic create_cq(input int q, input int n, input int iv, input bit ien, input logic [11:0] exp_st);
    sqe_set(ADM_CREATE_CQ, 0);
    sqe_prp(cq_addr_f(q), 0);
    sqe[10] = {16'(n - 1), 16'(q)};
    sqe[11] = {16'(iv), 14'd0, ien, 1'b1};
    for (int i = 0; i < n * 4; i++) host.hw32(cq_addr_f(q) + 64'(4 * i), 32'h0);
    exec(0);
    check($sformatf("create CQ %0d status", q), c_st, exp_st);
    if (c_st == 12'h0) begin h_cqb[q] = cq_addr_f(q); h_cqn[q] = n; h_cqh[q] = 0; h_cqp[q] = 1; h_cq_live[q] = 1; end
  endtask
  task automatic create_sq(input int q, input int n, input int cq, input logic [11:0] exp_st);
    sqe_set(ADM_CREATE_SQ, 0);
    sqe_prp(sq_addr(q), 0);
    sqe[10] = {16'(n - 1), 16'(q)};
    sqe[11] = {16'(cq), 13'd0, 2'b00, 1'b1};
    exec(0);
    check($sformatf("create SQ %0d status", q), c_st, exp_st);
    if (c_st == 12'h0) begin h_sqb[q] = sq_addr(q); h_sqn[q] = n; h_sqt[q] = 0; h_sqh[q] = 0; h_s2c[q] = cq; h_sq_live[q] = 1; end
  endtask
  task automatic delete_q(input bit is_cq, input int q, input logic [11:0] exp_st);
    sqe_set(is_cq ? ADM_DELETE_CQ : ADM_DELETE_SQ, 0);
    sqe[10] = 32'(q);
    exec(0);
    check($sformatf("delete %s %0d status", is_cq ? "CQ" : "SQ", q), c_st, exp_st);
    if (c_st == 12'h0 && q > 0 && q < 9) begin if (is_cq) h_cq_live[q] = 0; else h_sq_live[q] = 0; end
  endtask

  // ---------------------------------------------------------------- data buffers + PRPs
  logic [63:0] bp [40];                      // data page IOVAs of the current buffer
  int          b_off;                        // PRP1 offset
  logic [63:0] b_list;                       // PRP list location
  logic [63:0] b_lpage, b_cpage;             // list page, chained list page
  logic [63:0] prp1_v, prp2_v;
  int          pg_next = 0;                  // simple page allocator in DATA_A (768 pages)
  function automatic logic [63:0] alloc_page();
    alloc_page = DATA_A + 64'(pg_next) * 64'h1000;
    pg_next = (pg_next + 1) % 700;
  endfunction
  function automatic logic [63:0] boff(input int k);  // IOVA of byte k of the buffer
    boff = bp[(b_off + k) >> 12] + 64'((b_off + k) & 12'hFFF);
  endfunction
  // set up a buffer of `bytes` at offset `off`; pages scattered unless contig; PRP list at list page offset lofs
  task automatic make_buf_impl(input int bytes, input int off, input bit contig, input int lofs);
    int npg, k, slots, li;
    logic [63:0] la;
    b_off = off;
    npg = (off + bytes + 4095) / 4096;
    if (contig) begin
      if (pg_next + npg > 700) pg_next = 0;                       // keep the buffer physically contiguous
      bp[0] = alloc_page();
      for (int i = 1; i < npg; i++) bp[i] = alloc_page();         // allocator is sequential: contiguous
    end else begin
      for (int i = 0; i < npg; i++) begin bp[i] = alloc_page(); void'(alloc_page()); end   // every other page
    end
    for (int i = 0; i < npg; i++) for (int w = 0; w < 1024; w++) host.hw32(bp[i] + 64'(4 * w), 32'hA5A5_0000 | 32'(w));
    prp1_v = bp[0] + 64'(off);
    prp2_v = 64'h0;
    if (npg == 2) prp2_v = bp[1];
    else if (npg > 2) begin
      // PRP list (own pages per buffer) starting at page offset lofs; chain to a fresh page when a page runs out
      b_lpage = alloc_page(); b_cpage = alloc_page();
      b_list = b_lpage + 64'(lofs);
      prp2_v = b_list;
      la = b_list; k = 1;
      while (k < npg) begin
        slots = (4096 - int'(la[11:0])) / 8;
        if (npg - k > slots) begin
          for (li = 0; li < slots - 1; li++) begin host.hw32(la, bp[k][31:0]); host.hw32(la + 4, bp[k][63:32]); la += 8; k++; end
          host.hw32(la, b_cpage[31:0]); host.hw32(la + 4, b_cpage[63:32]);                          // chain pointer
          la = b_cpage;
        end else begin
          while (k < npg) begin host.hw32(la, bp[k][31:0]); host.hw32(la + 4, bp[k][63:32]); la += 8; k++; end
        end
      end
    end
  endtask

  // reference media model (what a read must return)
  logic [31:0] ref_mem [CAPB * 128];
  initial for (int i = 0; i < CAPB * 128; i++) ref_mem[i] = 32'h0;
  function automatic logic [31:0] pat(input int lba, input int w, input int salt);
    pat = {8'(salt), 8'(lba >> 8), 8'(lba), 8'(w)} ^ 32'h3C00_0000;
  endfunction
  task automatic fill_buf(input int bytes, input int lba0, input int salt);
    for (int k = 0; k < bytes / 4; k++) host.hw32(boff(4 * k), pat(lba0 + k / 128, k % 128, salt));
  endtask
  task automatic io_rw(input int q, input bit wr, input logic [63:0] slba, input int nlb, input bit fua,
                       input logic [11:0] exp_st);
    sqe_set(wr ? IO_WRITE : IO_READ, 1);
    sqe_prp(prp1_v, prp2_v);
    sqe[10] = slba[31:0]; sqe[11] = slba[63:32];
    sqe[12] = {1'b0, fua, 14'd0, 16'(nlb - 1)};
    exec(q);
    check($sformatf("%s LBA %0d x%0d status", wr ? "WRITE" : "READ", slba, nlb), c_st, exp_st);
  endtask
  // write nlb blocks with a pattern, update the reference
  task automatic do_write(input int q, input int lba, input int nlb, input int off, input bit contig, input int salt,
                          input bit fua);
    make_buf(nlb * 512, off, contig, 4096 - 16);
    fill_buf(nlb * 512, lba, salt);
    io_rw(q, 1, 64'(lba), nlb, fua, 12'h0);
    if (c_st == 12'h0) for (int k = 0; k < nlb * 128; k++) ref_mem[lba * 128 + k] = pat(lba + k / 128, k % 128, salt);
  endtask
  // read nlb blocks, compare with the reference, check guard bytes around the buffer
  int data_err = 0;
  task automatic do_read(input int q, input int lba, input int nlb, input int off, input bit contig);
    int errs, gerr, npg;
    make_buf(nlb * 512, off, contig, 4096 - 24);
    io_rw(q, 0, 64'(lba), nlb, 0, 12'h0);
    errs = 0; gerr = 0;
    for (int k = 0; k < nlb * 128; k++) if (host.hr32(boff(4 * k)) !== ref_mem[lba * 128 + k]) errs++;
    npg = (off + nlb * 512 + 4095) / 4096;
    for (int w = 0; w < off / 4; w++) if (host.hr32(bp[0] + 64'(4 * w)) !== (32'hA5A5_0000 | 32'(w))) gerr++;
    for (int b = off + nlb * 512; b < npg * 4096; b += 4)
      if (host.hr32(bp[b >> 12] + 64'(b & 12'hFFF)) !== (32'hA5A5_0000 | 32'((b & 12'hFFF) >> 2))) gerr++;
    check($sformatf("READ LBA %0d x%0d data", lba, nlb), 64'(errs), 0);
    check($sformatf("READ LBA %0d x%0d guard bytes untouched", lba, nlb), 64'(gerr), 0);
    data_err += errs;
  endtask


  // ---------------------------------------------------------------- driver server
  // exec / reap / make_buf bodies run in ONE process; the tasks the tests call only hand
  // over arguments and wait.  (Verilator inlines every timed task at every call site;
  // without this the generated C++ grows past 100 MB.  Same technique as P51's BAR BFM.)
  int dsv_op = 0, dsv_a0, dsv_a1, dsv_a2;
  bit dsv_req = 0, dsv_ack = 0, dsv_b0;
  always begin : drv_server
    @(posedge clk);
    if (dsv_req && !dsv_ack) begin
      case (dsv_op)
        1: exec_impl(dsv_a0);
        2: reap_impl(dsv_a0, dsv_a1, dsv_b0);
        3: make_buf_impl(dsv_a0, dsv_a1, dsv_b0, dsv_a2);
        default: ;
      endcase
      dsv_ack = 1;
    end else if (!dsv_req && dsv_ack) dsv_ack = 0;
  end
  task automatic dsv_call(input int op);
    dsv_op = op; dsv_req = 1;
    while (!dsv_ack) @(posedge clk);
    dsv_req = 0;
    while (dsv_ack) @(posedge clk);
  endtask
  task automatic exec(input int q);
    dsv_a0 = q; dsv_call(1);
  endtask
  task automatic reap(input int c, input int max_cyc, input bit ring);
    dsv_a0 = c; dsv_a1 = max_cyc; dsv_b0 = ring; dsv_call(2);
  endtask
  task automatic make_buf(input int bytes, input int off, input bit contig, input int lofs);
    dsv_a0 = bytes; dsv_a1 = off; dsv_b0 = contig; dsv_a2 = lofs; dsv_call(3);
  endtask

  // delete every I/O queue the host created (SQs first: a CQ cannot be deleted while an SQ uses it)
  task automatic teardown_io();
    for (int q = 1; q < 9; q++) if (h_sq_live[q]) delete_q(0, q, 12'h0);
    for (int q = 1; q < 9; q++) if (h_cq_live[q]) delete_q(1, q, 12'h0);
  endtask

  // ---------------------------------------------------------------- random traffic engine (all I/O queues)
  localparam int OTN = 64;
  bit          ot_v [OTN];
  logic [15:0] ot_cid [OTN];
  int          ot_q [OTN], ot_op [OTN], ot_lba [OTN], ot_nlb [OTN], ot_salt [OTN], ot_off [OTN];
  logic [63:0] ot_buf [OTN];
  bit          lba_busy [CAPB];
  task automatic random_traffic(input int ncmd, input int qd, input int lba_lo, input int lba_hi, input int max_nlb);
    int issued, done, out, q, op, nlb, lba, slot, errs, guard;
    logic [63:0] base;
    for (int i = 0; i < OTN; i++) ot_v[i] = 0;
    for (int i = 0; i < CAPB; i++) lba_busy[i] = 0;
    issued = 0; done = 0; out = 0; errs = 0; guard = 0;
    while (done < ncmd && guard < 4000000) begin
      guard++;
      // submit
      if (issued < ncmd && out < qd) begin
        q = 1 + ($urandom % NIOQ);
        op = $urandom % 20;                                            // 0..8 write, 9..17 read, 18..19 flush
        nlb = 1 + ($urandom % ((($urandom % 4) == 0) ? max_nlb : ((max_nlb < 8) ? max_nlb : 8)));
        lba = lba_lo + ($urandom % (lba_hi - lba_lo - nlb));
        for (int k = 0; k < nlb; k++) if (lba_busy[lba + k]) op = 18;   // overlap: flush instead
        slot = -1;
        for (int i = OTN - 1; i >= 0; i--) if (!ot_v[i]) slot = i;
        if (slot >= 0 && ((h_sqt[q] + 1) % h_sqn[q]) != h_sqh[q]) begin          // never fill the SQ
          ot_v[slot] = 1; ot_q[slot] = q; ot_op[slot] = (op < 9) ? 1 : ((op < 18) ? 2 : 0);
          ot_lba[slot] = lba; ot_nlb[slot] = nlb; ot_salt[slot] = $urandom % 256;
          ot_off[slot] = (($urandom % 3) == 0) ? 0 : 4 * ($urandom % 1024);
          make_buf(nlb * 512, ot_off[slot], 1, (($urandom % 2) == 0) ? 0 : 4096 - 8 * (1 + ($urandom % 4)));
          ot_buf[slot] = bp[0];
          if (ot_op[slot] == 1) fill_buf(nlb * 512, lba, ot_salt[slot]);
          if (ot_op[slot] != 0) for (int k = 0; k < nlb; k++) lba_busy[lba + k] = 1;
          sqe_set(ot_op[slot] == 1 ? IO_WRITE : (ot_op[slot] == 2 ? IO_READ : IO_FLUSH), 1);
          if (ot_op[slot] != 0) begin
            sqe_prp(prp1_v, prp2_v); sqe[10] = lba; sqe[12] = nlb - 1;
            if (ot_op[slot] == 1 && ($urandom % 8) == 0) sqe[12][30] = 1'b1;
          end
          ot_cid[slot] = sqe[0][31:16];
          submit(q);
          issued++; out++;
        end
      end
      // reap whatever has completed
      for (int c = 1; c <= NIOQ; c++) begin
        logic [31:0] w3;
        w3 = host.hr32(h_cqb[c] + 64'(h_cqh[c] * 16 + 12));
        if (w3[16] == h_cqp[c]) begin
          reap(c, 10, ($urandom % 3) != 0);
          slot = -1;
          for (int i = 0; i < OTN; i++) if (ot_v[i] && ot_cid[i] == c_cid && ot_q[i] == int'(c_sqid)) slot = i;
          if (slot < 0) begin errs++; $display("[%0d] random: unknown completion CID %h SQ %0d", host.cyc, c_cid, c_sqid); end
          else begin
            if (c_st != 0) begin errs++; $display("[%0d] random: CID %h status %h", host.cyc, c_cid, c_st); end
            else if (ot_op[slot] == 1) begin
              for (int k = 0; k < ot_nlb[slot] * 128; k++)
                ref_mem[ot_lba[slot] * 128 + k] = pat(ot_lba[slot] + k / 128, k % 128, ot_salt[slot]);
              tb_writes++; tb_units_w += ot_nlb[slot];
            end else if (ot_op[slot] == 2) begin
              for (int k = 0; k < ot_nlb[slot] * 128; k++) begin
                logic [63:0] a;
                a = ot_buf[slot] + 64'(ot_off[slot] + 4 * k);
                if (host.hr32(a) !== ref_mem[ot_lba[slot] * 128 + k]) begin
                  if (errs < 4) $display("[%0d] random: READ CID %h LBA %0d+%0d off %h buf %h word %0d: got %h exp %h",
                                         host.cyc, c_cid, ot_lba[slot], ot_nlb[slot], ot_off[slot], ot_buf[slot], k,
                                         host.hr32(a), ref_mem[ot_lba[slot] * 128 + k]);
                  errs++;
                end
              end
              tb_reads++; tb_units_r += ot_nlb[slot];
            end
            if (ot_op[slot] != 0) for (int k = 0; k < ot_nlb[slot]; k++) lba_busy[ot_lba[slot] + k] = 0;
            ot_v[slot] = 0; done++; out--;
          end
        end
      end
      // ring any CQ heads not yet rung, then let time pass
      if (($urandom % 4) == 0) for (int c = 1; c <= NIOQ; c++) ring_cq(c);
      @(posedge clk);
    end
    for (int c = 1; c <= NIOQ; c++) ring_cq(c);
    check("random: all commands completed", done, ncmd);
    check("random: data / status errors", errs, 0);
  endtask

  // ---------------------------------------------------------------- convenience
  task automatic setup_io(input int sqn, input int cqn);
    for (int q = 1; q <= NIOQ; q++) begin
      create_cq(q, cqn, (q < NVEC) ? q : 0, 1'b1, 12'h0);
      create_sq(q, sqn, q, 12'h0);
    end
  endtask
  task automatic simple_cmd(input int q, input logic [7:0] opc, input logic [31:0] nsid, input logic [11:0] exp_st,
                            input string what);
    sqe_set(opc, nsid);
    exec(q);
    check(what, c_st, exp_st);
  endtask

  // ---------------------------------------------------------------- performance engine
  // Keeps `qd` commands in flight on I/O queue 1 (batched SQ doorbell, batched CQ head doorbell),
  // measures per-command latency from the SQ doorbell write to the CQE becoming visible in host
  // memory, the controller's reaction time (doorbell -> first SQE read TLP, QD 1 only), MSIs per
  // command, TLP payload bytes per cycle, and the front end's back-end service counters.
  // Prints one line: PERF <tag> op=.. bytes=.. qd=.. n=.. cyc=.. cyc_per_cmd=.. lat_avg=.. ...
  logic [63:0] pf_p1 [64], pf_p2 [64];
  bit          pf_busy [64];
  logic [15:0] pf_cid [64];
  longint unsigned pf_tsub [64];
  task automatic perf_run(input string tag, input int op, input int nlb, input int qd, input int n, input int lba0,
                          input int span, input real mhz);
    int issued, done, out, k, slot, msi0, ub;
    longint unsigned t0, t1, lat, lat_sum, lat_max, lat_min, react_sum, be0, be0n, rdb0, wrb0, tdb;
    int nreact;
    logic [31:0] w3;
    real cyc_cmd, iops, mbps, bpc;
    for (int s = 0; s < qd; s++) begin
      make_buf((nlb > 0 ? nlb : 1) * 512, 0, 1, 0);
      pf_p1[s] = prp1_v; pf_p2[s] = prp2_v; pf_busy[s] = 0;
    end
    issued = 0; done = 0; out = 0; lat_sum = 0; lat_max = 0; lat_min = 64'hFFFF_FFFF; react_sum = 0; nreact = 0;
    msi0 = host.msi_total; rdb0 = host.rd_bytes; wrb0 = host.wr_bytes;
    be0 = 64'(perf[17*32 +: 32]); be0n = 64'(perf[3*32 +: 32]) + 64'(perf[4*32 +: 32]) + 64'(perf[5*32 +: 32]);
    t0 = host.cyc;
    while (done < n) begin
      k = 0;
      while (out < qd && issued < n) begin
        slot = -1;
        for (int s = qd - 1; s >= 0; s--) if (!pf_busy[s]) slot = s;
        sqe_set(op == 0 ? IO_FLUSH : (op == 1 ? IO_WRITE : IO_READ), 1);
        if (op != 0) begin
          sqe_prp(pf_p1[slot], pf_p2[slot]);
          sqe[10] = lba0 + ((issued * nlb) % span);
          sqe[12] = nlb - 1;
        end
        pf_cid[slot] = sqe[0][31:16]; pf_busy[slot] = 1;
        submit_nodb(1);
        issued++; out++; k++;
      end
      if (k > 0) begin
        if (qd == 1) begin host.w_base[0] = h_sqb[1]; host.w_len[0] = 64'(h_sqn[1] * 64); host.w_hit[0] = 0; end
        tdb = host.cyc;
        ring_sq(1);
        for (int s = 0; s < qd; s++) if (pf_busy[s] && pf_tsub[s] == 0) pf_tsub[s] = tdb;
      end
      ub = 0;
      w3 = host.hr32(h_cqb[1] + 64'(h_cqh[1] * 16 + 12));
      while (w3[16] == h_cqp[1]) begin
        slot = -1;
        for (int s = 0; s < qd; s++) if (pf_busy[s] && pf_cid[s] == w3[15:0]) slot = s;
        if (slot < 0) check_true("perf: completion for an outstanding command", 0);
        else begin
          if (w3[31:17] != 15'h0) check(tag, w3[31:17], 0);
          lat = host.cyc - pf_tsub[slot];
          lat_sum += lat; if (lat > lat_max) lat_max = lat; if (lat < lat_min) lat_min = lat;
          if (qd == 1 && host.w_hit[0] != 0) begin react_sum += host.w_hit[0] - pf_tsub[slot]; nreact++; end
          pf_busy[slot] = 0; pf_tsub[slot] = 0;
        end
        h_cqh[1] = h_cqh[1] + 1;
        if (h_cqh[1] == h_cqn[1]) begin h_cqh[1] = 0; h_cqp[1] = !h_cqp[1]; end
        out--; done++; ub++;
        w3 = host.hr32(h_cqb[1] + 64'(h_cqh[1] * 16 + 12));
      end
      if (ub > 0) ring_cq(1);
      else @(posedge clk);
    end
    t1 = host.cyc;
    cyc_cmd = real'(t1 - t0) / real'(n);
    iops    = mhz * 1.0e6 / cyc_cmd;
    bpc     = real'((host.rd_bytes - rdb0) + (host.wr_bytes - wrb0)) / real'(t1 - t0);
    mbps    = real'(n) * real'(nlb * 512) / (real'(t1 - t0) / mhz);           // bytes per microsecond = MB/s
    $display("PERF %s op=%s bytes=%0d qd=%0d n=%0d cyc=%0d cyc_per_cmd=%0.1f kiops=%0.1f MBps=%0.1f lat_avg=%0.1f lat_min=%0d lat_max=%0d react=%0.1f be_svc_avg=%0.1f msi_per_cmd=%0.2f tlp_bytes_per_cyc=%0.3f clk_mhz=%0.0f",
             tag, op == 0 ? "flush" : (op == 1 ? "write" : "read_"), nlb * 512, qd, n, t1 - t0, cyc_cmd, iops / 1000.0, mbps,
             real'(lat_sum) / real'(n), lat_min, lat_max, (nreact > 0) ? real'(react_sum) / real'(nreact) : 0.0,
             real'(64'(perf[17*32 +: 32]) - be0) / real'((64'(perf[3*32 +: 32]) + 64'(perf[4*32 +: 32]) + 64'(perf[5*32 +: 32]) - be0n) > 0 ?
                    (64'(perf[3*32 +: 32]) + 64'(perf[4*32 +: 32]) + 64'(perf[5*32 +: 32]) - be0n) : 1),
             real'(host.msi_total - msi0) / real'(n), bpc, mhz);
  endtask
