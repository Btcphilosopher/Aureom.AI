// =============================================================================
// SilicaFlux-STORE (Project 57) :: scenarios for tb_nvme_ssd (included into the module)
// =============================================================================

  // ---------------------------------------------------------------- initialisation (a host driver's bring-up)
  task automatic s_init();
    logic [31:0] w;
    grp = "init";
    pcie_enumerate(8);                                   // MSI, 8 vectors
    nvme_enable(8, 8);                                   // RDY is raised by the P51 firmware (HIF page)
    make_buf(4096, 0, 1, 0);
    sqe_set(ADM_IDENTIFY, 0); sqe_prp(prp1_v, 0); sqe[10] = 1; exec(0);
    check("Identify Controller", c_st, 0);
    w = host.hr32(boff(4 * 19));
    check("MDTS = 1 (8 KiB: P51 MDTS 16 x 512 B)", (w >> 8) & 32'hFF, 1);
    check("VER", host.hr32(boff(4 * 20)), 32'h0001_0400);
    check("VWC present", (host.hr32(boff(4 * 131)) >> 8) & 32'h1, 1);
    make_buf(4096, 0, 1, 0);
    sqe_set(ADM_IDENTIFY, 1); sqe_prp(prp1_v, 0); sqe[10] = 0; exec(0);
    check("Identify Namespace", c_st, 0);
    check("NSZE = FTL capacity published by the firmware", {host.hr32(boff(4)), host.hr32(boff(0))}, 64'(CAPB));
    check("LBA format 512 B", host.hr32(boff(4 * 32)), 32'h0009_0000);
    setup_io(16, 16);
  endtask

  // ---------------------------------------------------------------- definition of done
  task automatic s_dod();
    int f0;
    grp = "DoD";
    f0 = n_fail;
    do_write(1, 0, 4, 0, 1, 8'h51, 0);                  // host -> PRP -> buffer -> SECDED -> NAND program -> FTL commit
    do_read(1, 0, 4, 32'h200, 0);                        // FTL lookup -> NAND read -> ECC -> host
    simple_cmd(1, IO_FLUSH, 1, 12'h0, "FLUSH (FTL checkpoint)");
    do_read(1, 0, 4, 0, 1);
    if (n_fail == f0)
      $display("TB DoD: simulated NVMe host initialised the controller, wrote, read and flushed blocks through the FTL / NAND back end with correct data and completion status -- MET");
    else $display("TB DoD: NOT met");
  endtask

  // ---------------------------------------------------------------- PRP layouts on the real back end
  task automatic s_prp();
    grp = "prp";
    do_write(1, 16, 16, 32'h400, 0, 8'h52, 0);          // 8 KiB, 3 pages: PRP list (+ chained list page)
    do_read(1, 16, 16, 32'hE00, 1);
    do_write(1, 32, 1, 32'hF00, 0, 8'h53, 0);           // 512 B across a page boundary: PRP2 entry
    do_read(1, 32, 1, 32'hF00, 0);
    do_write(1, 40, 8, 32'h0, 0, 8'h54, 1);             // 4 KiB FUA
    do_read(1, 40, 8, 32'h7FC, 0);
  endtask

  // ---------------------------------------------------------------- errors detected by the front end / back end
  task automatic s_errors();
    grp = "errors";
    do_read(1, 200, 2, 0, 1);                            // never written: the FTL returns zeros
    make_buf(4096, 0, 1, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[10] = CAPB; exec(1);
    check("READ beyond the namespace -> LBA Out of Range", c_st, S(1, 0, 'h80));
    sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[10] = CAPB - 1; sqe[12] = 1; exec(1);
    check("WRITE crossing the end -> LBA Out of Range", c_st, S(1, 0, 'h80));
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[12] = 16; exec(1);
    check("17 blocks > MDTS -> Invalid Field", c_st, S(1, 0, 'h02));
    simple_cmd(1, 8'h05, 1, S(1, 0, 1), "I/O opcode 05h (Compare, not supported)");
    simple_cmd(0, 8'h80, 0, S(1, 0, 1), "admin opcode 80h (Format NVM, not supported)");
  endtask

  // ---------------------------------------------------------------- queue wrap on the real back end
  task automatic s_wrap();
    grp = "wrap";
    teardown_io();
    create_cq(1, 2, 1, 1, 12'h0);
    create_sq(1, 3, 1, 12'h0);
    for (int i = 0; i < 16; i++) begin
      if (i % 2 == 0) do_write(1, 48 + (i % 4), 1, 0, 1, 8'h60 + i, 0);
      else do_read(1, 48 + (i % 4), 1, 0, 1);
      check("SQHD == host tail", c_sqhd, 16'(h_sqt[1]));
    end
    check("16 commands through a 2-entry CQ: 8 phase inversions", h_cqp[1], 1);
    teardown_io();
    setup_io(16, 16);
  endtask

  // ---------------------------------------------------------------- concurrency: 8 commands in flight, out-of-order completion
  task automatic s_random();
    grp = "random";
    random_traffic(80, NCTX, 64, CAPB - 8, 16);
  endtask

  // ---------------------------------------------------------------- NAND page ECC through the NVMe status path
  task automatic s_ecc();
    int row;
    grp = "ecc";
    do_write(1, 100, 1, 0, 1, 8'h77, 0);
    row = flash.find_page(pat(100, 0, 8'h77), 0);
    check_true("written page located in the NAND model", row >= 0);
    if (row >= 0) begin
      flash.flip_bit(row / PPB, row % PPB, 5 * 5 + 1, 4);                 // one bit in word 5
      do_read(1, 100, 1, 0, 1);                                           // corrected by SECDED: success + data
      flash.flip_bit(row / PPB, row % PPB, 9 * 5 + 0, 0);                 // two bits in word 9
      flash.flip_bit(row / PPB, row % PPB, 9 * 5 + 2, 6);
      make_buf(512, 0, 1, 0);
      io_rw(1, 0, 100, 1, 0, S(1, 2, 'h81));                              // Unrecovered Read Error (media)
      do_write(1, 100, 1, 0, 1, 8'h78, 0);                                // rewrite heals (new page)
      do_read(1, 100, 1, 0, 1);
    end
  endtask

  // ---------------------------------------------------------------- controller reset with commands in flight
  task automatic s_reset();
    bit ok;
    longint last, t_rdy0;
    grp = "reset";
    for (int i = 0; i < 6; i++) begin
      make_buf(4096, 0, 1, 0); fill_buf(4096, 120 + 8 * (i % 2), 9);
      sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[10] = 120 + 8 * (i % 2); sqe[12] = 7; submit_nodb(1);
    end
    ring_sq(1);
    repeat (3000) @(posedge clk);
    host.wr32(R_CC, 32'h0046_0000);                     // CC.EN = 0: firmware aborts its tags (HIF EN_FALL)
    wait_rdy(0, 2_000_000, ok);
    t_rdy0 = host.cyc;
    check_true("CSTS.RDY -> 0 after the back end quiesced", ok);
    last = host.last_dev_req;
    repeat (5000) @(posedge clk);
    check_true("no device requests after RDY = 0", host.last_dev_req == last && last <= t_rdy0);
    for (int k = 0; k < 16 * 128; k++) ref_mem[120 * 128 + k] = 32'hx;   // contents undefined after the abort
    nvme_enable(8, 8);
    setup_io(16, 16);
    do_write(1, 120, 16, 0, 1, 8'h5A, 0);
    do_read(1, 120, 16, 0, 1);
  endtask

  // ---------------------------------------------------------------- shutdown notification -> firmware checkpoint
  task automatic s_shutdown();
    logic [31:0] v;
    int n;
    grp = "shutdown";
    do_write(1, 130, 2, 0, 1, 8'h61, 0);
    host.wr32(R_CC, 32'h0046_4001);                     // SHN = 01b
    n = 0;
    host.rd32(R_CSTS, v);
    while (v[3:2] != 2'b10 && n < 5000) begin repeat (64) @(posedge clk); host.rd32(R_CSTS, v); n++; end
    check("CSTS.SHST = 10b after the firmware checkpoint", v[3:2], 2'b10);
    nvme_enable(8, 8);
    setup_io(16, 16);
    do_read(1, 130, 2, 0, 1);
  endtask

  // ---------------------------------------------------------------- power failure: abrupt (no warning), then with PLP warning
  logic [31:0] pre_b [4 * 128];
  task automatic s_power();
    longint t0;
    grp = "power abrupt";
    do_write(1, 140, 4, 0, 1, 8'hA1, 0);
    simple_cmd(1, IO_FLUSH, 1, 12'h0, "FLUSH before the power cut");
    for (int k = 0; k < 4 * 128; k++) pre_b[k] = ref_mem[150 * 128 + k];   // last checkpointed contents
    do_write(1, 150, 4, 0, 1, 8'hB2, 0);               // acknowledged, not flushed
    power_cycle(0);
    pcie_enumerate(8);
    nvme_enable(8, 8);
    setup_io(16, 16);
    do_read(1, 140, 4, 0, 1);                            // flushed: intact
    for (int k = 0; k < 4 * 128; k++) ref_mem[150 * 128 + k] = pre_b[k];
    do_read(1, 150, 4, 0, 1);                            // not flushed: P51 FTL returns the last checkpointed data
    grp = "power PLP";
    do_write(1, 160, 4, 0, 1, 8'hC3, 0);               // acknowledged, not flushed
    pwr_fail_n = 1'b0;                                   // power-fail warning: firmware drains + checkpoints
    repeat (2000) @(posedge clk);
    make_buf(512, 0, 1, 0); fill_buf(512, 170, 1);
    io_rw(1, 1, 170, 1, 0, S(0, 0, 5));                  // new command during quiescence: aborted (power loss)
    t0 = host.cyc;
    while (wp_n && host.cyc - t0 < 3_000_000) @(posedge clk);
    check("firmware reached FW_SAFE (NAND WP# asserted)", wp_n, 0);
    power_cycle(1);
    pcie_enumerate(8);
    nvme_enable(8, 8);
    setup_io(16, 16);
    do_read(1, 160, 4, 0, 1);                            // saved by the PLP checkpoint
    do_read(1, 140, 4, 0, 1);
    do_read(1, 170, 1, 0, 1);                            // aborted write never applied (previous contents)
  endtask

  // ---------------------------------------------------------------- log pages on the SoC
  task automatic s_logs();
    grp = "logs";
    make_buf(512, 0, 1, 0);
    sqe_set(ADM_GET_LOG, 32'hFFFF_FFFF); sqe_prp(prp1_v, 0); sqe[10] = {16'd127, 8'h00, LID_SMART}; exec(0);
    check("SMART log", c_st, 0);
    check("SMART host reads since power-on", host.hr32(boff(64)), tb_reads);
    check("SMART host writes since power-on", host.hr32(boff(80)), tb_writes);
  endtask

  // ---------------------------------------------------------------- firmware self-verdict (P51 mailbox SHUTDOWN)
  task automatic s_fw_verdict();
    longint t0;
    grp = "firmware";
    mbox_cmd(CC_MBOX_CMD_SHUTDOWN, 32'(n_fail), 4_000_000);
    t0 = host.cyc;
    while (!test_done && host.cyc - t0 < 1_000_000) @(posedge clk);
    check("firmware TEST_CTRL done", test_done, 1);
    check("firmware verdict (no firmware errors)", test_fail, 0);
  endtask

  // ---------------------------------------------------------------- performance (real back end)
  // Real back end: P51 firmware FTL on the ControlCore, P51 DMA (one word per transaction), NAND model
  // (tR 2 us, tPROG 4 us at 100 MHz).  The P51 FTL has no garbage collection: 63 x 16 data pages per
  // channel, so the sweep writes at most ~600 pages in total.
  task automatic s_perf();
    int qds [4];
    qds[0] = 1; qds[1] = 2; qds[2] = 4; qds[3] = 8;
    grp = "perf";
    pcie_enumerate(8);
    nvme_enable(8, 8);
    setup_io(64, 64);
    host.rd_lat_min = 40; host.rd_lat_max = 40; host.cpl_split = 1; host.cpl_reorder = 0; host.post_lat = 6;
    perf_run("soc", 0, 0, 1, 20, 0, 1, 100.0);
    for (int q = 0; q < 4; q++) perf_run("soc", 1, 1, qds[q], 24, 0, 128, 100.0);
    for (int q = 0; q < 4; q++) perf_run("soc", 2, 1, qds[q], 24, 0, 128, 100.0);
    for (int q = 0; q < 4; q++) perf_run("soc", 1, 8, qds[q], 12, 0, 128, 100.0);
    for (int q = 0; q < 4; q++) perf_run("soc", 2, 8, qds[q], 12, 0, 128, 100.0);
    perf_run("soc", 1, 16, 1, 6, 128, 96, 100.0);
    perf_run("soc", 2, 16, 1, 6, 128, 96, 100.0);
    perf_run("soc", 0, 0, 1, 10, 0, 1, 100.0);
    $display("PERF counters: fetched=%0d completed=%0d msi=%0d be_svc_max=%0d lat_max=%0d fetch_lat_max=%0d",
             perf[1*32 +: 32], perf[2*32 +: 32], perf[10*32 +: 32], perf[18*32 +: 32], perf[16*32 +: 32],
             perf[25*32 +: 32]);
  endtask
