// =============================================================================
// SilicaFlux-STORE (Project 57) :: tb_nvme_ssd -- NVMe host against the full StorageCore SoC
//
// DUT  : silicaflux_nvme_ssd = NVMe front end (P57) + UNMODIFIED ControlCore CPU (P21)
//        running the UNMODIFIED P51 storage firmware (FTL, NAND, PLP) + P51 storage
//        hardware (command controller, DMA, buffer SRAM with SECDED, NAND controller
//        with page ECC)
// Host : sfn_tb_pcie_host (transaction-level PCIe transport) + the shared NVMe
//        host driver (tb/common/sfn_tb_nvme_driver.svh)
// Media: P51 behavioural NAND model (state survives SoC resets = power cycles)
// Boot : firmware image loaded through the management port by the ControlCore
//        boot-ROM flow (header + CRC32), as P51's own SoC testbench does.
//
// Scenarios (+scenario=dod|full, default full) -- see docs/08_VERIFICATION.md.
// Plusargs: +fw=<hex> +con (echo firmware console) +perf (performance sweep)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_nvme_ssd;
  import silicaflux_nvme_pkg::*;
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
  import cc_memmap_pkg::*;

  localparam int NIOQ  = 1;
  localparam int NCTX  = 8;
  localparam int NVEC  = 8;
  localparam int EXT   = 1;
  localparam int CAPB  = 256;              // P51 FTL: 256 LBAs per channel
  localparam int PAGE  = 512;
  localparam int PPB   = 16;
  localparam int RAW_PAGE = PAGE * 3 / 2;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;                    // 100 MHz, as the P51 SoC testbench

  // ================================================================ wiring
  logic        cq_valid, cq_ready, cq_write, cq_last, cc_valid, cc_ready, cc_last, rq_valid, rq_ready, rq_write, rq_last;
  logic        rc_valid, rc_ready, rc_last;
  logic [2:0]  cq_bar, cc_status, rc_status;
  logic [63:0] cq_addr, rq_addr;
  logic [10:0] cq_len_dw, cc_len_dw, rq_len_dw, rc_len_dw;
  logic [3:0]  cq_first_be, cq_last_be, rq_first_be, rq_last_be;
  logic [7:0]  cq_tag, cc_tag, rq_tag, rc_tag;
  logic [15:0] cq_req_id, cc_req_id;
  logic [31:0] cq_data, cc_data, rq_data, rc_data;
  logic [12:0] cc_byte_count, rc_byte_count;
  logic [6:0]  cc_lower_addr, rc_lower_addr;
  logic        cfg_bme, cfg_msi_en, cfg_intx_dis, cfg_flr, msi_valid, msi_ready, intx_assert;
  logic [2:0]  cfg_mps, cfg_mrrs, cfg_msi_mme;
  logic [4:0]  msi_vector;
  logic        mg_req_valid = 0, mg_req_ready, mg_req_write = 0, mg_rsp_valid, mg_rsp_error;
  logic [31:0] mg_req_addr = 0, mg_req_wdata = 0, mg_rsp_rdata;
  logic        mgmt_irq, host_ready, cmdproc_ready, ras_fatal;
  logic        ce_n, cle, ale, we_n, re_n, wp_n, dq_oe, rb_n;
  logic [7:0]  dq_o, dq_i;
  logic        pwr_fail_n = 1'b1, ep_rst_n = 1'b1;
  logic        diag_valid, test_done, test_fail, cpu_sleep;
  logic [7:0]  diag_char;
  logic [15:0] test_code;
  logic [2:0]  nvme_state;
  logic [32*32-1:0] perf;

  silicaflux_nvme_ssd #(.NUM_IOQ(NIOQ), .NUM_VEC(NVEC), .CPL_TIMEOUT(65536), .ENABLE_EXT_ADMIN(EXT)) dut (
    .clk, .rst_ni(rst_n), .ep_rst_ni(ep_rst_n), .test_mode(1'b0), .boot_mode_i(2'(CC_BOOT_MODE_HOST)),
    .pwr_fail_ni(pwr_fail_n),
    .cq_valid, .cq_ready, .cq_write, .cq_bar, .cq_addr, .cq_len_dw, .cq_first_be, .cq_last_be, .cq_tag, .cq_req_id,
    .cq_data, .cq_last,
    .cc_valid, .cc_ready, .cc_tag, .cc_req_id, .cc_status, .cc_byte_count, .cc_lower_addr, .cc_len_dw, .cc_data, .cc_last,
    .rq_valid, .rq_ready, .rq_write, .rq_addr, .rq_len_dw, .rq_first_be, .rq_last_be, .rq_tag, .rq_data, .rq_last,
    .rc_valid, .rc_ready, .rc_tag, .rc_status, .rc_byte_count, .rc_lower_addr, .rc_len_dw, .rc_data, .rc_last,
    .cfg_bme, .cfg_mps, .cfg_mrrs, .cfg_msi_en, .cfg_msi_mme, .cfg_intx_dis, .cfg_flr,
    .msi_valid, .msi_ready, .msi_vector, .intx_assert,
    .mg_req_valid, .mg_req_ready, .mg_req_write, .mg_req_addr, .mg_req_wdata, .mg_req_wstrb(4'hF),
    .mg_rsp_valid, .mg_rsp_ready(1'b1), .mg_rsp_rdata, .mg_rsp_error,
    .mgmt_irq_o(mgmt_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready), .ras_fatal_o(ras_fatal),
    .nand_ce_n(ce_n), .nand_cle(cle), .nand_ale(ale), .nand_we_n(we_n), .nand_re_n(re_n), .nand_wp_n(wp_n),
    .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(dq_i), .nand_rb_n(rb_n),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep), .nvme_state_o(nvme_state), .nvme_perf_o(perf)
  );

  sfn_tb_pcie_host host (
    .clk, .rst_n,
    .cq_valid, .cq_ready, .cq_write, .cq_bar, .cq_addr, .cq_len_dw, .cq_first_be, .cq_last_be, .cq_tag, .cq_req_id,
    .cq_data, .cq_last,
    .cc_valid, .cc_ready, .cc_tag, .cc_req_id, .cc_status, .cc_byte_count, .cc_lower_addr, .cc_len_dw, .cc_data, .cc_last,
    .rq_valid, .rq_ready, .rq_write, .rq_addr, .rq_len_dw, .rq_first_be, .rq_last_be, .rq_tag, .rq_data, .rq_last,
    .rc_valid, .rc_ready, .rc_tag, .rc_status, .rc_byte_count, .rc_lower_addr, .rc_len_dw, .rc_data, .rc_last,
    .cfg_bme, .cfg_mps, .cfg_mrrs, .cfg_msi_en, .cfg_msi_mme, .cfg_intx_dis, .cfg_flr,
    .msi_valid, .msi_ready, .msi_vector, .intx_assert
  );

  wire [7:0] dq;
  assign dq   = dq_oe ? dq_o : 8'bz;
  assign dq_i = dq;
  sfs_nand_flash_model #(.DQW(8), .RAW_PAGE(RAW_PAGE), .PAGES_PER_BLOCK(PPB), .BLOCKS(64), .CH(0)) flash (
    .ce_n, .cle, .ale, .we_n, .re_n, .wp_n, .dq, .rb_n
  );

  // ================================================================ firmware console
  string con_line = "";
  bit con_echo;
  initial con_echo = $test$plusargs("con");
  always @(posedge clk) if (diag_valid) begin
    if (diag_char == 8'h0A) begin if (con_echo) $display("FW| %s", con_line); con_line = ""; end
    else con_line = {con_line, string'(diag_char)};
  end

  // ================================================================ scoreboard
  int n_pass = 0, n_fail = 0;
  string grp = "";
  task automatic check(input string what, input logic [63:0] got, input logic [63:0] exp);
    if (got === exp) n_pass++;
    else begin
      n_fail++;
      $display("[%0d] FAIL %s / %s: got 0x%0h expected 0x%0h", host.cyc, grp, what, got, exp);
    end
  endtask
  task automatic check_true(input string what, input bit c);
    check(what, 64'(c), 64'd1);
  endtask

  // ================================================================ NVMe host driver (shared with the unit testbench)
`include "sfn_tb_nvme_driver.svh"

  // ================================================================ management port BFM (boot loader / mailbox)
  bit          mg_go = 0, mg_done = 0, mg_wr = 0, mg_e = 0;
  logic [31:0] mg_a = 0, mg_wd = 0, mg_rd = 0;
  int          mg_st = 0;
  always @(posedge clk) begin
    case (mg_st)
      0: if (mg_go && !mg_done) begin
        mg_req_valid <= 1'b1; mg_req_write <= mg_wr; mg_req_addr <= mg_a; mg_req_wdata <= mg_wd; mg_st <= 1;
      end
      1: if (mg_req_ready) begin mg_req_valid <= 1'b0; mg_st <= 2; end
      2: if (mg_rsp_valid) begin mg_rd <= mg_rsp_rdata; mg_e <= mg_rsp_error; mg_done <= 1'b1; mg_st <= 3; end
      3: if (!mg_go) begin mg_done <= 1'b0; mg_st <= 0; end
      default: mg_st <= 0;
    endcase
  end
  task automatic mgacc(input bit wr, input logic [31:0] a, input logic [31:0] d, output logic [31:0] r);
    mg_wr = wr; mg_a = a; mg_wd = d; mg_go = 1;
    @(posedge clk); while (!mg_done) @(posedge clk);
    r = mg_rd; mg_go = 0;
    @(posedge clk); while (mg_done) @(posedge clk);
  endtask
  task automatic mw(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r;
    mgacc(1, a, d, r);
  endtask
  task automatic mr(input logic [31:0] a, output logic [31:0] d);
    mgacc(0, a, 0, d);
  endtask

  // ---------------------------------------------------------------- boot (ControlCore host-load flow, management port)
  logic [31:0] img [16384];
  int          img_n = 0;
  logic [31:0] rsp [8];
  task automatic mbox_wait(input longint tmo);
    longint t0;
    t0 = host.cyc;
    while (!mgmt_irq && host.cyc - t0 < tmo) @(posedge clk);
    check_true("mailbox answered", mgmt_irq);
    for (int i = 0; i < 8; i++) begin logic [31:0] v; mr(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 32'(4 * i), v); rsp[i] = v; end
    mw(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
  endtask
  task automatic mbox_cmd(input logic [31:0] cmd, input logic [31:0] a1, input longint tmo);
    mw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, a1);
    mw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd);
    mw(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd);
    mbox_wait(tmo);
  endtask
  task automatic load_image();
    string fw;
    int fd;
    logic [31:0] w;
    if (!$value$plusargs("fw=%s", fw)) fw = "build/fw/sfs_fw.hex";
    fd = $fopen(fw, "r");
    if (fd == 0) $fatal(1, "cannot open firmware image %s", fw);
    img_n = 0;
    while ($fscanf(fd, "%h\n", w) == 1 && img_n < 16384) begin img[img_n] = w; img_n++; end
    $fclose(fd);
    $display("TB host: firmware image %s, %0d words", fw, img_n);
  endtask
  longint t_boot;
  task automatic boot();
    logic [31:0] v;
    longint t0;
    grp = "boot";
    t0 = host.cyc;
    mr(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v);
    while (v != CC_BOOT_STAGE_WAIT_IMAGE && host.cyc - t0 < 2_000_000) mr(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v);
    check("boot ROM waits for the image", v, CC_BOOT_STAGE_WAIT_IMAGE);
    for (int i = 0; i < img_n; i++) mw(CC_IMEM_BASE + 32'(4 * i), img[i]);
    mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 0, 3_000_000);
    check("boot ROM accepted the image (CRC32)", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    t0 = host.cyc;
    while (!host_ready && host.cyc - t0 < 4_000_000) @(posedge clk);
    check_true("firmware HOST_READY", host_ready);
    mbox_wait(1000);
    t_boot = host.cyc - t0;
    $display("TB host: firmware HOST READY at cycle %0d: capacity %0d LBAs, checkpoint seq %0d", host.cyc, rsp[2], rsp[6]);
    check("firmware-published capacity", rsp[2], CAPB);
  endtask

  // power cycle: everything in the SoC loses state, the NAND model keeps its contents
  task automatic power_cycle(input bit plp_pin_low);
    rst_n = 1'b0;
    host.cfg_wr('h04, 32'h0); host.cfg_wr('h50, 32'h0);
    repeat (50) @(posedge clk);
    pwr_fail_n = 1'b1;
    if (plp_pin_low) repeat (10) @(posedge clk);
    rst_n = 1'b1;
    repeat (20) @(posedge clk);
    boot();
    tb_units_r = 0; tb_units_w = 0; tb_reads = 0; tb_writes = 0;
  endtask

  // ================================================================ scenarios
`include "tb_nvme_ssd_scenarios.svh"

  // ================================================================ main
  string scenario;
  initial begin
    if (!$value$plusargs("scenario=%s", scenario)) scenario = "full";
    host.map(0, HB, 64'h40_0000, 0, 1, 1);
    host.rd_lat_min = 10; host.rd_lat_max = 40; host.post_lat = 6;
    load_image();
    repeat (10) @(posedge clk);
    rst_n = 1'b1;
    boot();
    if ($test$plusargs("perf")) s_perf();
    else begin
      s_init();
      s_dod();
      if (scenario == "full") begin
        s_prp();
        s_errors();
        s_wrap();
        s_random();
        s_ecc();
        s_reset();
        s_shutdown();
        s_power();
        s_logs();
      end
      s_fw_verdict();
    end
    grp = "global";
    check("PCIe TLP rule violations", 64'(host.viol), 0);
    check("IOMMU faults", 64'(host.iommu_faults), 0);
    $display("tb_nvme_ssd %s: %0d checks, %0d failures, %0d cycles -> %s", scenario, n_pass + n_fail, n_fail, host.cyc,
             (n_fail == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin
    #3_000_000_000;
    $display("tb_nvme_ssd: global timeout -> FAIL");
    $finish;
  end
endmodule

`default_nettype wire
