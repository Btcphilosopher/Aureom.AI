// =============================================================================
// SilicaFlux-STORE (Project 57) :: sfn_tb_backend -- storage back-end model (unit tests)
//
// SIMULATION ONLY.  Implements the P51 StorageCore command contract that the
// NVMe front end drives (sfs_cmd_t / sfs_cpl_t ready/valid, TID echoed in the
// completion), so the front end can be verified in seconds without the
// ControlCore CPU.  The full SoC test (tb/soc) uses the real P51 back end.
//
//   * up to NT commands held; out-of-order completion after a random delay
//   * data moved through the front end's host-memory window (SFB2 master,
//     one transaction at a time, 32-bit words) exactly as the P51 DMA does
//   * media: durable store + volatile write cache.  WRITE goes to the cache,
//     WRITE with FUA goes to durable media, FLUSH / shutdown commit the cache,
//     power_cut() discards it -- the persistence contract of the P51 FTL
//     (FLUSH = checkpoint) in miniature
//   * injectable unrecoverable-read LBAs; window errors -> DATA_XFER_ERR
//   * controller-enable handshake as P51 firmware does it on the HIF page:
//     EN rise -> RDY after rdy_delay; reset done -> RDY = 0; SHN -> SHST 01,
//     cache committed, SHST 10; commands arriving while resetting -> ABORT_RESET
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfn_tb_backend
  import silicaflux_storage_pkg::*;
#(
  parameter int CAPB = 2048,                         // media blocks (512 B)
  parameter int NT   = 8
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        cmd_valid,
  output logic             cmd_ready,
  input  wire sfs_cmd_t    cmd,
  output logic             cpl_valid,
  input  wire logic        cpl_ready,
  output sfs_cpl_t         cpl,
  output logic [63:0]      capacity,
  output logic [15:0]      mdts,
  output logic             idle,
  output logic             rdy,
  output logic [1:0]       shst,
  output logic             cfs,
  input  wire logic        fe_en,
  input  wire logic        fe_shn,
  input  wire logic        fe_resetting,
  input  wire logic        fe_reset_done,
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error
);
  longint unsigned now = 0;
  always @(posedge clk) now <= now + 1;

  // ---------------------------------------------------------------- knobs
  int cap_blocks  = CAPB;
  int mdts_blocks = 64;
  int lat_min = 0, lat_max = 40;            // completion delay after the data phase
  int cmd_bp_pct = 0;
  int rdy_delay = 40, shn_delay = 200;
  bit hold_cmds = 0;                        // stall the worker (keeps commands in flight)
  bit burst = 1;                            // pipelined SFB2 transfers (1 word / cycle when the window allows)
  bit bad [CAPB];
  initial for (int i = 0; i < CAPB; i++) bad[i] = 0;
  assign capacity = 64'(cap_blocks);
  assign mdts     = 16'(mdts_blocks);
  initial cfs = 1'b0;

  // ---------------------------------------------------------------- statistics
  int n_cmd = 0, n_read = 0, n_write = 0, n_flush = 0, n_fua = 0, n_abort = 0, n_dma_err = 0, n_media_err = 0;
  int n_commit = 0;

  // ---------------------------------------------------------------- media
  logic [31:0] dur [CAPB * 128];
  logic [31:0] vol [CAPB * 128];
  bit          volv [CAPB];
  initial for (int i = 0; i < CAPB; i++) volv[i] = 0;
  initial for (int i = 0; i < CAPB * 128; i++) begin dur[i] = 32'h0; vol[i] = 32'h0; end
  task automatic commit_cache();
    for (int b = 0; b < CAPB; b++) if (volv[b]) begin
      for (int w = 0; w < 128; w++) dur[b * 128 + w] = vol[b * 128 + w];
      volv[b] = 0;
      n_commit++;
    end
  endtask
  function automatic logic [31:0] media_word(input int lba, input int w);   // what a read returns
    media_word = volv[lba] ? vol[lba * 128 + w] : dur[lba * 128 + w];
  endfunction

  // ---------------------------------------------------------------- command slots
  bit        s_v [NT];
  int        s_state [NT];                  // 0 pending, 1 active, 2 done
  sfs_cmd_t  s_cmd [NT];
  logic [6:0] s_status [NT];
  logic [7:0] s_err [NT];
  longint unsigned s_t [NT], s_seq [NT];
  longint unsigned seq_ctr = 0;
  initial for (int i = 0; i < NT; i++) begin s_v[i] = 0; s_state[i] = 0; s_status[i] = 0; s_err[i] = 0; s_t[i] = 0; s_seq[i] = 0; end
  function automatic int free_slot();
    free_slot = -1;
    for (int i = NT - 1; i >= 0; i--) if (!s_v[i]) free_slot = i;
  endfunction
  initial idle = 1'b1;
  always @(posedge clk) begin                  // evaluated every cycle (one cycle late is harmless)
    bit any;
    any = 0;
    for (int i = 0; i < NT; i++) if (s_v[i]) any = 1;
    idle <= !any;
  end

  // ---------------------------------------------------------------- acceptor
  initial cmd_ready = 1'b0;
  always @(posedge clk) begin
    if (cmd_valid && cmd_ready) begin
      int s;
      s = free_slot();
      s_v[s] = 1; s_cmd[s] = cmd; s_seq[s] = seq_ctr++; n_cmd++;
      if (fe_resetting) begin
        s_state[s] = 2; s_status[s] = 7'(SFS_ST_ABORT_RESET); s_err[s] = 8'(SFS_ERR_NOT_READY); s_t[s] = now; n_abort++;
      end else s_state[s] = 0;
    end
    if (fe_resetting)                         // like P51 firmware on EN 1->0: abort what has not started
      for (int i = 0; i < NT; i++)
        if (s_v[i] && s_state[i] == 0) begin
          s_state[i] = 2; s_status[i] = 7'(SFS_ST_ABORT_RESET); s_err[i] = 8'(SFS_ERR_NOT_READY); s_t[i] = now; n_abort++;
        end
    cmd_ready <= rst_n && (free_slot() >= 0) && ((cmd_bp_pct == 0) || (($urandom % 100) >= cmd_bp_pct)) &&
                 !(cmd_valid && cmd_ready && free_slot() < 0);
  end

  // ---------------------------------------------------------------- SFB2 master (one transaction at a time)
  initial begin m_req_valid = 0; m_req_write = 0; m_req_addr = 0; m_req_wdata = 0; m_req_wstrb = 4'hF; m_rsp_ready = 1; end
  task automatic sfb(input bit wr, input logic [31:0] a, input logic [31:0] d, output logic [31:0] q, output bit err);
    @(negedge clk);
    m_req_valid = 1; m_req_write = wr; m_req_addr = a; m_req_wdata = d; m_req_wstrb = 4'hF;
    @(posedge clk); while (!m_req_ready) @(posedge clk);
    @(negedge clk); m_req_valid = 0;
    @(posedge clk); while (!m_rsp_valid) @(posedge clk);
    q = m_rsp_rdata; err = m_rsp_error;
  endtask

  logic [31:0] blk [128];
  // pipelined block transfer: next request presented while the previous response is pending (SFB2 R6),
  // payload held until accepted (R2); one response per request, in order (R5)
  task automatic sfb_block(input bit wr, input logic [31:0] a0, output bit err);
    int issued, got;
    issued = 0; got = 0; err = 0;
    @(negedge clk);
    m_req_valid = 1; m_req_write = wr; m_req_addr = a0; m_req_wdata = blk[0]; m_req_wstrb = 4'hF;
    while (got < 128) begin
      @(posedge clk);
      if (m_rsp_valid) begin
        if (!wr) blk[got] = m_rsp_rdata;
        if (m_rsp_error) err = 1;
        got++;
      end
      if (m_req_valid && m_req_ready) issued++;
      @(negedge clk);
      if (issued < 128) begin m_req_valid = 1; m_req_addr = a0 + 32'(4 * issued); m_req_wdata = blk[issued]; end
      else m_req_valid = 0;
    end
  endtask

  // ---------------------------------------------------------------- worker: data phase, one command at a time
  always begin
    int s;
    @(posedge clk);
    s = -1;
    if (!hold_cmds && !fe_resetting)
      for (int i = 0; i < NT; i++) if (s_v[i] && s_state[i] == 0 && (s < 0 || s_seq[i] < s_seq[s])) s = i;
    if (s >= 0) begin
      logic [6:0] st;
      logic [7:0] er;
      logic [31:0] q;
      bit e;
      int lba, len;
      sfs_cmd_t cur;
      cur = s_cmd[s];
      s_state[s] = 1;
      st = 7'(SFS_ST_SUCCESS); er = 8'(SFS_ERR_NONE);
      lba = int'(cur.addr); len = int'(cur.len);
      if (cur.opcode == 8'(SFS_OP_FLUSH)) begin
        n_flush++;
        commit_cache();
      end else if (cur.addr + 64'(cur.len) > 64'(cap_blocks)) begin
        st = 7'(SFS_ST_LBA_RANGE);
      end else if (cur.opcode == 8'(SFS_OP_READ)) begin
        n_read++;
        for (int b = 0; b < len && st == 7'(SFS_ST_SUCCESS); b++) begin
          if (bad[lba + b]) begin st = 7'(SFS_ST_MEDIA_UNREC); er = 8'(SFS_ERR_NAND_ECC_UE); n_media_err++; end
          else if (burst) begin
            for (int w = 0; w < 128; w++) blk[w] = media_word(lba + b, w);
            sfb_block(1, cur.host_addr[31:0] + 32'(b * 512), e);
            if (e) begin st = 7'(SFS_ST_DATA_XFER_ERR); er = 8'(SFS_ERR_DMA_WRITE); n_dma_err++; end
          end else for (int w = 0; w < 128 && st == 7'(SFS_ST_SUCCESS); w++) begin
            sfb(1, cur.host_addr[31:0] + 32'((b * 128 + w) * 4), media_word(lba + b, w), q, e);
            if (e) begin st = 7'(SFS_ST_DATA_XFER_ERR); er = 8'(SFS_ERR_DMA_WRITE); n_dma_err++; end
          end
        end
      end else if (cur.opcode == 8'(SFS_OP_WRITE)) begin
        n_write++;
        if (cur.flags[1]) n_fua++;
        for (int b = 0; b < len && st == 7'(SFS_ST_SUCCESS); b++) begin
          if (burst) begin
            sfb_block(0, cur.host_addr[31:0] + 32'(b * 512), e);
            if (e) begin st = 7'(SFS_ST_DATA_XFER_ERR); er = 8'(SFS_ERR_DMA_READ); n_dma_err++; end
          end else for (int w = 0; w < 128 && st == 7'(SFS_ST_SUCCESS); w++) begin
            sfb(0, cur.host_addr[31:0] + 32'((b * 128 + w) * 4), 32'h0, q, e);
            if (e) begin st = 7'(SFS_ST_DATA_XFER_ERR); er = 8'(SFS_ERR_DMA_READ); n_dma_err++; end
            blk[w] = q;
          end
          if (st == 7'(SFS_ST_SUCCESS)) begin
            for (int w = 0; w < 128; w++) begin
              if (cur.flags[1]) dur[(lba + b) * 128 + w] = blk[w];
              else                   vol[(lba + b) * 128 + w] = blk[w];
            end
            volv[lba + b] = !cur.flags[1];
          end
        end
      end else st = 7'(SFS_ST_INVALID_OPCODE);
      if (s_v[s]) begin
        s_status[s] = st; s_err[s] = er; s_state[s] = 2;
        s_t[s] = now + longint'(lat_min + ((lat_max > lat_min) ? ($urandom % (lat_max - lat_min + 1)) : 0));
      end
    end
  end

  // ---------------------------------------------------------------- completer (ready ones, random order)
  int c_slot = -1;
  initial begin cpl_valid = 0; cpl = '0; end
  always @(posedge clk) begin
    if (cpl_valid && cpl_ready) begin
      s_v[c_slot] = 0;
      c_slot = -1;
      cpl_valid <= 1'b0;
    end else if (!cpl_valid) begin
      int start;
      start = $urandom % NT;
      for (int k = 0; k < NT; k++) begin
        int i;
        i = (start + k) % NT;
        if (c_slot < 0 && s_v[i] && s_state[i] == 2 && s_t[i] <= now) c_slot = i;
      end
      if (c_slot >= 0) begin
        cpl_valid <= 1'b1;
        begin
          sfs_cpl_t t;
          sfs_cmd_t c;
          t = '0;
          c = s_cmd[c_slot];
          t.tid = c.tid; t.status = s_status[c_slot]; t.err = s_err[c_slot];
          t.result0 = c.len; t.result1 = 32'd0;
          cpl <= t;
        end
      end
    end
  end

  // ---------------------------------------------------------------- controller-enable handshake (HIF page behaviour)
  logic en_q = 0, shn_q = 0;
  int rdy_cnt = -1, shn_cnt = -1;
  initial begin rdy = 0; shst = 0; end
  always @(posedge clk) begin
    en_q <= fe_en; shn_q <= fe_shn;
    if (fe_en && !en_q && !rdy) rdy_cnt = rdy_delay;
    if (rdy_cnt > 0) rdy_cnt--;
    else if (rdy_cnt == 0) begin if (fe_en) rdy <= 1'b1; rdy_cnt = -1; end
    if (fe_reset_done) begin rdy <= 1'b0; shst <= 2'b00; rdy_cnt = -1; shn_cnt = -1; end
    if (fe_shn && !shn_q && shst == 2'b00) begin shst <= 2'b01; shn_cnt = shn_delay; end
    if (shn_cnt > 0) shn_cnt--;
    else if (shn_cnt == 0) begin commit_cache(); shst <= 2'b10; shn_cnt = -1; end
  end

  // ---------------------------------------------------------------- power cut: volatile state lost
  task automatic power_cut();
    for (int b = 0; b < CAPB; b++) volv[b] = 0;
    for (int i = 0; i < NT; i++) s_v[i] = 0;
    rdy = 0; shst = 0; rdy_cnt = -1; shn_cnt = -1;
  endtask

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^m_rsp_rdata;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
