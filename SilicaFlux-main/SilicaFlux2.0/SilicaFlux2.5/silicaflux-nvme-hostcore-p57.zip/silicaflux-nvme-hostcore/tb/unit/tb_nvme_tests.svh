// =============================================================================
// SilicaFlux-STORE (Project 57) :: test groups for tb_nvme_ctrl (included into the module)
// =============================================================================


  // ---------------------------------------------------------------- admin command with a data buffer
  task automatic adm_data(input logic [7:0] opc, input logic [31:0] nsid, input logic [31:0] c10, input logic [31:0] c11,
                          input logic [31:0] c12, input logic [31:0] c13, input int bytes, input int off);
    make_buf(bytes, off, 1, 0);
    sqe_set(opc, nsid);
    sqe_prp(prp1_v, prp2_v);
    sqe[10] = c10; sqe[11] = c11; sqe[12] = c12; sqe[13] = c13;
    exec(0);
  endtask
  function automatic logic [31:0] bw(input int k);  // DW k of the current buffer
    bw = host.hr32(boff(4 * k));
  endfunction
  task automatic wait_cqe_visible(input int c);
    logic [31:0] w3;
    int n;
    n = 0;
    w3 = host.hr32(h_cqb[c] + 64'(h_cqh[c] * 16 + 12));
    while (w3[16] != h_cqp[c] && n < 50000) begin @(posedge clk); n++; w3 = host.hr32(h_cqb[c] + 64'(h_cqh[c] * 16 + 12)); end
    check_true("CQE became visible", w3[16] == h_cqp[c]);
  endtask
  function automatic bit want(input string g);
    want = (groups == "all") || $test$plusargs({"only_", g});
  endfunction

  // ================================================================ 1. PCIe enumeration + register interface
  task automatic t_regs();
    logic [63:0] cap;
    logic [31:0] v, lo, hi;
    grp = "regs";
    pcie_enumerate(0);
    host.rd64(R_CAP_LO, cap);
    check("CAP.MQES", cap[15:0], 16'd1023);
    check("CAP.CQR", cap[16], 1);
    check("CAP.AMS (round robin only)", cap[18:17], 0);
    check("CAP.TO", cap[31:24], 15);
    check("CAP.DSTRD", cap[35:32], 0);
    check("CAP.NSSRS", cap[36], 0);
    check("CAP.CSS (NVM command set only)", cap[44:37], 8'h01);
    check("CAP.BPS", cap[45], 0);
    check("CAP.MPSMIN", cap[51:48], 0);
    check("CAP.MPSMAX", cap[55:52], 0);
    check("CAP.PMRS/CMBS/CRMS", cap[63:56], 0);
    host.rd32(R_CAP_LO, lo); host.rd32(R_CAP_HI, hi);
    check("CAP 2x32 == 64-bit read", {hi, lo}, cap);
    host.rd32(R_VS, v);    check("VS", v, 32'h0001_0400);
    host.rd32(R_CC, v);    check("CC reset", v, 0);
    host.rd32(R_CSTS, v);  check("CSTS reset", v, 0);
    host.rd32(R_AQA, v);   check("AQA reset", v, 0);
    host.rd32(R_INTMS, v); check("INTMS reset", v, 0);
    host.rd32(14'h038, v); check("CMBLOC (not implemented) reads 0", v, 0);
    host.rd32(14'hF00, v); check("reserved F00h reads 0", v, 0);
    host.rd32(14'h1000, v); check("doorbell reads 0", v, 0);
    // RW masks / reserved bits
    host.wr32(R_CC, 32'hFF0F_FFFE);
    host.rd32(R_CC, v);    check("CC reserved bits RsvdZ", v, 32'h000F_FFF0);
    host.wr32(R_CC, 32'h0);
    host.wr32(R_AQA, 32'hFFFF_FFFF);
    host.rd32(R_AQA, v);   check("AQA reserved bits", v, 32'h0FFF_0FFF);
    host.mmio(1, R_AQA, 1, 4'b0001, 4'h0, 32'h0000_0012, 0);
    host.rd32(R_AQA, v);   check("AQA byte-enable write", v, 32'h0FFF_0F12);
    host.wr32(R_AQA, 32'h0);
    host.wr64(R_ASQ_LO, 64'hFFFF_FFFF_FFFF_FFFF);
    host.rd64(R_ASQ_LO, cap); check("ASQ bits 11:0 RsvdZ", cap, 64'hFFFF_FFFF_FFFF_F000);
    host.wr64(R_ASQ_LO, 64'h0);
    host.wr32(R_CAP_LO, 32'h0); host.wr32(R_VS, 32'h0);
    host.rd32(R_VS, v);    check("VS read-only", v, 32'h0001_0400);
    host.rd32(R_CAP_LO, v); check("CAP read-only", v[15:0], 16'd1023);
    // completer rules
    host.mmio(0, R_VS, 1, 4'h0, 4'h0, 0, 0);
    check("zero-length read: SC", host.m_st, 3'b000);
    check("zero-length read: byte count 1", host.m_bc, 1);
    host.mmio(0, R_CC, 1, 4'b0100, 4'h0, 0, 0);
    check("1-byte read: byte count", host.m_bc, 1);
    check("1-byte read: lower address", host.m_la, 7'h16);
    host.mmio(0, 14'h0, 4, 4'hF, 4'hF, 0, 0);
    check("4-DW register read -> Completer Abort", host.m_st, 3'b100);
    host.cfg_wr('h04, 32'h0000_0004);                              // MSE off
    host.mmio(0, R_VS, 1, 4'hF, 4'h0, 0, 0);
    check("MMIO with MSE = 0 -> UR from endpoint", host.m_st, 3'b001);
    host.cfg_wr('h04, 32'h0000_0006);
  endtask

  // ================================================================ 2. enable / disable / fatal configuration
  task automatic t_enable();
    logic [31:0] v;
    bit ok;
    grp = "enable";
    host.wr32(R_AQA, 32'h0);
    host.wr32(R_CC, 32'h0046_0001);
    repeat (50) @(posedge clk);
    host.rd32(R_CSTS, v); check("AQA = 0 -> CSTS.CFS, not ready", v[1:0], 2'b10);
    host.wr32(R_CC, 32'h0046_0000);
    wait_rdy(0, 1000, ok);
    host.rd32(R_CSTS, v); check("CC.EN = 0 clears CFS", v[1:0], 2'b00);
    host.wr32(R_AQA, 32'h0003_0003); host.wr64(R_ASQ_LO, ASQ_A); host.wr64(R_ACQ_LO, ACQ_A);
    host.wr32(R_CC, 32'h0046_0081);                                // MPS = 1 (8 KiB) not supported
    repeat (50) @(posedge clk);
    host.rd32(R_CSTS, v); check("unsupported CC.MPS -> CFS", v[1:0], 2'b10);
    host.wr32(R_CC, 32'h0);
    repeat (50) @(posedge clk);
    host.wr32(R_AQA, 32'h0003_0003); host.wr64(R_ASQ_LO, ASQ_A); host.wr64(R_ACQ_LO, ACQ_A);
    host.wr32(R_CC, 32'h0046_0071);                                // CSS = 111b (admin only) not supported
    repeat (50) @(posedge clk);
    host.rd32(R_CSTS, v); check("unsupported CC.CSS -> CFS", v[1:0], 2'b10);
    host.wr32(R_CC, 32'h0);
    repeat (50) @(posedge clk);
    host.wr64(R_ASQ_LO, 64'hFFFF_FFFF_FFFF_F000); host.wr32(R_AQA, 32'h0003_0FFF);   // 4096 x 64 B from ...F000
    host.wr32(R_CC, 32'h0046_0001);                                // admin SQ would wrap 2^64
    repeat (50) @(posedge clk);
    host.rd32(R_CSTS, v); check("ASQ + size overflow -> CFS", v[1:0], 2'b10);
    host.wr32(R_CC, 32'h0);
    repeat (50) @(posedge clk);
    nvme_enable(8, 8);
    host.rd32(R_CSTS, v); check("CSTS after enable: RDY, SHST 00", v[3:0], 4'b0001);
    nvme_disable();
    nvme_enable(8, 8);
  endtask

  // ================================================================ 3. Identify
  task automatic t_identify();
    logic [31:0] v;
    grp = "identify";
    adm_data(ADM_IDENTIFY, 0, 32'h1, 0, 0, 0, 4096, 0);
    check("Identify Controller status", c_st, 0);
    check("VID / SSVID", bw(0), 32'hFFFE_FFFE);
    check("SN[0..3] 'SFP5'", bw(1), 32'h3550_4653);
    check("MN[0..3] 'Sili'", bw(6), 32'h696C_6953);
    check("FR 'P57-0100'", {bw(17), bw(16)}, 64'h3030_3130_2D37_3550);
    check("MDTS (32 KiB = 2^3 x 4 KiB)", ((bw(19) >> 8) & 32'hFF), 8'd3);
    check("VER", bw(20), 32'h0001_0400);
    check("CNTRLTYPE = I/O controller", (bw(27) >> 24), 8'h01);
    check("OACS / ACL / AERL", bw(64), (EXT != 0) ? 32'h0100_0000 : 32'h0);
    check("FRMW / LPA / ELPE / NPSS", bw(65), 32'h0003_0403);
    check("SQES / CQES", bw(128), 32'h0000_4466);
    check("NN", bw(129), 32'd1);
    check("ONCS / FUSES", bw(130), 32'd0);
    check("VWC present + flush-all", ((bw(131) >> 8) & 32'hFF), 8'h07);
    check("SGLS = 0 (no SGL)", bw(134), 32'd0);
    check("SUBNQN 'nqn.'", bw(192), 32'h2E6E_716E);
    check("power state 0 not characterised", bw(512), 32'd0);
    adm_data(ADM_IDENTIFY, 1, 32'h0, 0, 0, 0, 4096, 0);
    check("Identify Namespace status", c_st, 0);
    check("NSZE", {bw(1), bw(0)}, 64'(CAPB));
    check("NCAP", {bw(3), bw(2)}, 64'(CAPB));
    check("NUSE", {bw(5), bw(4)}, 64'(CAPB));
    check("NSFEAT/NLBAF/FLBAS/MC", bw(6), 32'h0);
    check("LBAF0 = 512 B, no metadata", bw(32), 32'h0009_0000);
    adm_data(ADM_IDENTIFY, 0, 32'h0, 0, 0, 0, 4096, 0);
    check("Identify NS, NSID 0 -> Invalid Namespace", c_st, S(1, 0, 'h0B));
    adm_data(ADM_IDENTIFY, 2, 32'h0, 0, 0, 0, 4096, 0);
    check("Identify NS, NSID 2 -> Invalid Namespace", c_st, S(1, 0, 'h0B));
    adm_data(ADM_IDENTIFY, 32'hFFFF_FFFF, 32'h0, 0, 0, 0, 4096, 0);
    check("Identify NS, NSID FFFFFFFFh -> Invalid Namespace", c_st, S(1, 0, 'h0B));
    adm_data(ADM_IDENTIFY, 0, 32'h2, 0, 0, 0, 4096, 0);
    check("active NS list (NSID 0) status", c_st, 0);
    check("active NS list = {1}", {bw(1), bw(0)}, 64'h1);
    adm_data(ADM_IDENTIFY, 1, 32'h2, 0, 0, 0, 4096, 0);
    check("active NS list after NSID 1 empty", bw(0), 0);
    adm_data(ADM_IDENTIFY, 1, 32'h3, 0, 0, 0, 4096, 0);
    check("NS ID descriptor list status", c_st, 0);
    check("NS ID descriptor list empty", bw(0), 0);
    adm_data(ADM_IDENTIFY, 5, 32'h3, 0, 0, 0, 4096, 0);
    check("NS ID descriptor list NSID 5 -> Invalid Namespace", c_st, S(1, 0, 'h0B));
    adm_data(ADM_IDENTIFY, 0, 32'h10, 0, 0, 0, 4096, 0);
    check("CNS 10h (not supported) -> Invalid Field", c_st, S(1, 0, 'h02));
    // PRP1 with an offset: the structure spans two pages through PRP2, nothing outside is written
    adm_data(ADM_IDENTIFY, 0, 32'h1, 0, 0, 0, 4096, 32'h800);
    check("Identify with PRP1 offset 800h status", c_st, 0);
    check("  DW0 at PRP1", host.hr32(bp[0] + 64'h800), 32'hFFFE_FFFE);
    check("  DW512 at start of PRP2 page", host.hr32(bp[1]), 32'd0);
    check("  DW129 (NN) in first page", host.hr32(bp[0] + 64'h800 + 64'd516), 32'd1);
    check("  guard below PRP1 offset", host.hr32(bp[0] + 64'h7FC), 32'hA5A5_01FF);
    check("  guard after the end", host.hr32(bp[1] + 64'h800), 32'hA5A5_0200);
    // PRP errors
    make_buf(4096, 0, 1, 0);
    sqe_set(ADM_IDENTIFY, 0); sqe_prp(prp1_v + 2, 0); sqe[10] = 1; exec(0);
    check("PRP1 not DW aligned -> PRP Offset Invalid", c_st, S(1, 0, 'h13));
    make_buf(4096, 32'h800, 1, 0);
    sqe_set(ADM_IDENTIFY, 0); sqe_prp(prp1_v, prp2_v + 64'h10); sqe[10] = 1; exec(0);
    check("PRP2 with offset -> PRP Offset Invalid", c_st, S(1, 0, 'h13));
    check("  nothing written on PRP error", host.hr32(bp[0] + 64'h800), 32'hA5A5_0200);
  endtask

  // ================================================================ 4. queue management
  task automatic create_raw(input bit cq, input logic [31:0] c10, input logic [31:0] c11, input logic [63:0] p1,
                            input logic [11:0] exp, input string what);
    sqe_set(cq ? ADM_CREATE_CQ : ADM_CREATE_SQ, 0);
    sqe_prp(p1, 0); sqe[10] = c10; sqe[11] = c11;
    exec(0);
    check(what, c_st, exp);
  endtask
  task automatic t_queues();
    grp = "queues";
    create_raw(1, {16'd15, 16'd0}, 32'h0000_0003, cq_addr_f(1), S(1, 1, 1), "create CQ QID 0 -> Invalid QID");
    create_raw(1, {16'd15, 16'(NIOQ + 1)}, 32'h3, cq_addr_f(1), S(1, 1, 1), "create CQ QID > max -> Invalid QID");
    create_raw(1, {16'd0, 16'd1}, 32'h3, cq_addr_f(1), S(1, 1, 2), "create CQ 1 entry -> Invalid Queue Size");
    create_raw(1, {16'd1024, 16'd1}, 32'h3, cq_addr_f(1), S(1, 1, 2), "create CQ > MQES -> Invalid Queue Size");
    create_raw(1, {16'd15, 16'd1}, 32'h2, cq_addr_f(1), S(1, 0, 2), "create CQ PC = 0 -> Invalid Field");
    create_raw(1, {16'd15, 16'd1}, {16'(NVEC), 16'h3}, cq_addr_f(1), S(1, 1, 8), "create CQ IV >= vectors -> Invalid IV");
    create_raw(1, {16'd15, 16'd1}, 32'h3, cq_addr_f(1) + 64'h40, S(1, 0, 'h13), "create CQ unaligned -> PRP Offset Invalid");
    create_raw(1, {16'd1023, 16'd1}, 32'h3, 64'hFFFF_FFFF_FFFF_F000, S(1, 0, 2), "create CQ wrapping 2^64 -> Invalid Field");
    create_raw(0, {16'd15, 16'd1}, {16'd1, 16'h1}, sq_addr(1), S(1, 1, 0), "create SQ, CQ 1 missing -> CQ Invalid");
    create_cq(1, 16, 0, 1, 12'h0);
    create_raw(1, {16'd15, 16'd1}, 32'h3, cq_addr_f(1), S(1, 1, 1), "create CQ that exists -> Invalid QID");
    create_raw(0, {16'd15, 16'd1}, {16'd0, 16'h1}, sq_addr(1), S(1, 1, 0), "create SQ CQID 0 -> CQ Invalid");
    create_raw(0, {16'd15, 16'd1}, {16'(NIOQ + 1), 16'h1}, sq_addr(1), S(1, 1, 0), "create SQ CQID > max -> CQ Invalid");
    create_raw(0, {16'd15, 16'd1}, {16'd1, 16'h0}, sq_addr(1), S(1, 0, 2), "create SQ PC = 0 -> Invalid Field");
    create_raw(0, {16'd0, 16'd1}, {16'd1, 16'h1}, sq_addr(1), S(1, 1, 2), "create SQ 1 entry -> Invalid Queue Size");
    create_sq(1, 16, 1, 12'h0);
    create_raw(0, {16'd15, 16'd1}, {16'd1, 16'h1}, sq_addr(1), S(1, 1, 1), "create SQ that exists -> Invalid QID");
    delete_q(1, 1, S(1, 1, 'h0C));                                   // CQ still used by SQ 1
    delete_q(0, 0, S(1, 1, 1));                                      // admin SQ cannot be deleted
    delete_q(0, 1, 12'h0);
    delete_q(0, 1, S(1, 1, 1));
    delete_q(1, 1, 12'h0);
    delete_q(1, 1, S(1, 1, 1));
    setup_io(16, 16);
    simple_cmd(1, IO_FLUSH, 1, 12'h0, "flush on recreated queue");
  endtask

  // ================================================================ 5. I/O: write, read, flush, FUA
  task automatic t_io();
    int nf;
    grp = "io";
    do_write(1, 0, 1, 0, 1, 8'h11, 0);
    do_read(1, 0, 1, 0, 1);
    check_true("write went to the volatile cache", be.volv[0]);
    do_write(1, 8, 8, 0, 1, 8'h12, 0);
    do_read(1, 8, 8, 32'h200, 0);
    nf = be.n_flush;
    simple_cmd(1, IO_FLUSH, 1, 12'h0, "FLUSH NSID 1");
    check("back end executed FLUSH", be.n_flush, nf + 1);
    check_true("FLUSH committed the cache", !be.volv[0] && !be.volv[8]);
    check("durable data after FLUSH", be.dur[8 * 128 + 5], ref_mem[8 * 128 + 5]);
    simple_cmd(1, IO_FLUSH, 32'hFFFF_FFFF, 12'h0, "FLUSH NSID FFFFFFFFh");
    simple_cmd(1, IO_FLUSH, 2, S(1, 0, 'h0B), "FLUSH NSID 2 -> Invalid Namespace");
    simple_cmd(1, IO_FLUSH, 0, S(1, 0, 'h0B), "FLUSH NSID 0 -> Invalid Namespace");
    nf = be.n_fua;
    do_write(1, 40, 2, 0, 1, 8'h13, 1);
    check("FUA reached the back end", be.n_fua, nf + 1);
    check_true("FUA data durable immediately", !be.volv[40] && be.dur[40 * 128 + 1] == ref_mem[40 * 128 + 1]);
    do_read(1, 40, 2, 0, 1);
    do_read(1, 100, 4, 0, 1);   // never written: zeros
  endtask

  // ================================================================ 6. PRP layouts and errors
  task automatic prp_case(input int lba, input int nlb, input int off, input bit contig, input string what);
    grp = {"prp ", what};
    do_write(1, lba, nlb, off, contig, lba & 8'hFF, 0);
    do_read(1, lba, nlb, (off + 1024) % 4096, !contig);
  endtask
  task automatic t_prp();
    prp_case(200, 1, 0,      1, "512 B, 1 page");
    prp_case(202, 1, 'hE00,  0, "512 B ending at page end");
    prp_case(204, 1, 'hF00,  0, "512 B across a page (PRP2 entry)");
    prp_case(210, 8, 0,      1, "4 KiB, 1 page");
    prp_case(220, 8, 'h200,  0, "4 KiB, 2 pages");
    prp_case(230, 16, 0,     0, "8 KiB, 2 pages");
    prp_case(250, 16, 'h400, 0, "8 KiB, 3 pages (PRP list)");
    prp_case(300, 64, 0,     0, "32 KiB, 8 pages (list + chain)");
    prp_case(400, 64, 'hE00, 0, "32 KiB, 9 pages (list + chain)");
    prp_case(500, 37, 'h1FC, 1, "18.5 KiB, odd offset");
    grp = "prp errors";
    // list without chaining (list at page offset 0)
    make_buf(64 * 512, 0, 0, 0);
    fill_buf(64 * 512, 600, 8'h66);
    io_rw(1, 1, 600, 64, 0, 12'h0);
    if (c_st == 0) for (int k = 0; k < 64 * 128; k++) ref_mem[600 * 128 + k] = pat(600 + k / 128, k % 128, 8'h66);
    do_read(1, 600, 64, 0, 1);
    // errors
    make_buf(4096, 0, 1, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v + 1, 0); sqe[12] = 7; exec(1);
    check("PRP1 not DW aligned", c_st, S(1, 0, 'h13));
    make_buf(4096, 'h200, 0, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, prp2_v + 64'h8); sqe[12] = 7; exec(1);
    check("PRP2 data pointer with offset", c_st, S(1, 0, 'h13));
    make_buf(16 * 512, 'h400, 0, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, prp2_v + 64'h4); sqe[12] = 15; exec(1);
    check("PRP list pointer not QW aligned", c_st, S(1, 0, 'h13));
    make_buf(16 * 512, 'h400, 0, 0);
    host.hw32(b_list + 64'h8, host.hr32(b_list + 64'h8) | 32'h10);  // second list entry gets an offset
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, prp2_v); sqe[12] = 15; exec(1);
    check("PRP list entry with offset", c_st, S(1, 0, 'h13));
    check("  no data written on PRP error", host.hr32(bp[0] + 64'h400), 32'hA5A5_0100);
    make_buf(32 * 512, 'h400, 0, 0);                                  // 5 pages: 4 list entries
    host.hw32(b_list, host.hr32(b_list) | 32'h20);                    // FIRST list entry (not the last) gets an offset
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, prp2_v); sqe[12] = 31; exec(1);
    check("PRP list entry (not the last) with offset", c_st, S(1, 0, 'h13));
    make_buf(64 * 512, 'h200, 0, 4096 - 16);                          // chain: 1 entry + chain pointer, then a list page
    host.hw32(b_cpage + 64'h8, host.hr32(b_cpage + 64'h8) | 32'h4);   // entry in the chained page
    sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, prp2_v); sqe[12] = 63; exec(1);
    check("entry with offset in a chained list page", c_st, S(1, 0, 'h13));
    make_buf(4096, 0, 1, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[12] = 64; exec(1);   // 65 blocks = 32.5 KiB > MDTS
    check("transfer > MDTS -> Invalid Field", c_st, S(1, 0, 'h02));
  endtask

  // ================================================================ 7. invalid commands, LBA range, CID conflict
  task automatic t_invalid();
    logic [15:0] cid1, cid2, got1, got2;
    logic [11:0] st1, st2;
    grp = "invalid";
    simple_cmd(1, 8'h7F, 1, S(1, 0, 1), "I/O opcode 7Fh -> Invalid Opcode");
    simple_cmd(1, 8'h04, 1, S(1, 0, 1), "I/O opcode 04h (Write Uncorrectable, not supported)");
    simple_cmd(1, 8'h09, 1, S(1, 0, 1), "I/O opcode 09h (Dataset Management, not supported)");
    simple_cmd(0, 8'h7F, 0, S(1, 0, 1), "admin opcode 7Fh -> Invalid Opcode");
    simple_cmd(0, 8'h10, 0, S(1, 0, 1), "admin opcode 10h (Firmware Commit, not supported)");
    if (EXT == 0) begin
      simple_cmd(0, ADM_GET_FEAT, 0, S(1, 0, 1), "baseline build: Get Features -> Invalid Opcode");
      simple_cmd(0, ADM_AER, 0, S(1, 0, 1), "baseline build: AER -> Invalid Opcode");
    end
    make_buf(512, 0, 1, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[0][9:8] = 2'b01; exec(1);
    check("FUSE != 0 -> Invalid Field", c_st, S(1, 0, 2));
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[0][15:14] = 2'b01; exec(1);
    check("PSDT = SGL -> Invalid Field", c_st, S(1, 0, 2));
    sqe_set(IO_READ, 0); sqe_prp(prp1_v, 0); exec(1);
    check("READ NSID 0 -> Invalid Namespace", c_st, S(1, 0, 'h0B));
    sqe_set(IO_READ, 2); sqe_prp(prp1_v, 0); exec(1);
    check("READ NSID 2 -> Invalid Namespace", c_st, S(1, 0, 'h0B));
    sqe_set(IO_WRITE, 32'hFFFF_FFFF); sqe_prp(prp1_v, 0); exec(1);
    check("WRITE NSID FFFFFFFFh -> Invalid Namespace", c_st, S(1, 0, 'h0B));
    sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[12] = 32'h0010_0000; exec(1);
    check("DTYPE != 0 (no directives) -> Invalid Field", c_st, S(1, 0, 2));
    grp = "lba range";
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[10] = CAPB - 1; exec(1);
    check("last LBA readable", c_st, 0);
    begin
      int nc;
      nc = be.n_cmd;
      sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[10] = CAPB; exec(1);
      check("SLBA = capacity -> LBA Out of Range", c_st, S(1, 0, 'h80));
      check("  rejected by the front end (back end never saw it)", be.n_cmd, nc);
    end
    begin
      int nc;
      nc = be.n_cmd;
      sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[10] = CAPB - 1; sqe[12] = 1; exec(1);
      check("last block + 1 -> LBA Out of Range", c_st, S(1, 0, 'h80));
      check("  rejected by the front end", be.n_cmd, nc);
    end
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[10] = 32'hFFFF_FFFF; sqe[11] = 32'hFFFF_FFFF; sqe[12] = 1; exec(1);
    check("SLBA + NLB wraps 2^64 -> LBA Out of Range", c_st, S(1, 0, 'h80));
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[11] = 32'h1; exec(1);
    check("SLBA >= 2^32 -> LBA Out of Range", c_st, S(1, 0, 'h80));
    grp = "cid conflict";
    be.hold_cmds = 1;
    make_buf(512, 0, 1, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); cid1 = sqe[0][31:16]; submit(1);
    repeat (300) @(posedge clk);
    sqe[0][31:16] = cid1; submit(1);                                   // same CID while the first is in flight
    reap(1, 20000, 1); got1 = c_cid; st1 = c_st;
    be.hold_cmds = 0;
    reap(1, 20000, 1); got2 = c_cid; st2 = c_st;
    check("conflicting CID completed first", got1, cid1);
    check("  with Command ID Conflict", st1, S(1, 0, 3));
    check("original command completes", got2, cid1);
    check("  successfully", st2, 0);
  endtask

  // ================================================================ 8. queue wrap, phase, CQ full
  task automatic t_wrap();
    logic [31:0] w3;
    int lba;
    grp = "wrap";
    teardown_io();
    create_cq(1, 2, 0, 1, 12'h0);                                      // 2 entries: one usable slot
    create_sq(1, 3, 1, 12'h0);
    for (int i = 0; i < 24; i++) begin
      lba = 700 + (i % 6);
      if (i % 2 == 0) begin do_write(1, lba, 1, 0, 1, i, 0); end
      else begin do_read(1, lba, 1, 0, 1); end
      check("SQHD == host tail after each command", c_sqhd, 16'(h_sqt[1]));
    end
    check("24 commands through a 2-entry CQ: 12 phase inversions", h_cqp[1], 1);
    // CQ full: four commands, CQ head not advanced -> only one CQE may be written
    delete_q(0, 1, 12'h0); delete_q(1, 1, 12'h0);
    create_cq(1, 2, 0, 1, 12'h0);
    create_sq(1, 8, 1, 12'h0);
    begin
      logic [15:0] cids [4];
      int stall0;
      stall0 = perf[19*32 +: 32];
      for (int i = 0; i < 4; i++) begin
        make_buf(512, 0, 1, 0);
        sqe_set(IO_FLUSH, 1); cids[i] = sqe[0][31:16]; submit_nodb(1);
      end
      ring_sq(1);
      repeat (2000) @(posedge clk);
      w3 = host.hr32(h_cqb[1] + 12);      check("CQ slot 0 written", w3[16], 1);
      w3 = host.hr32(h_cqb[1] + 16 + 12); check("CQ slot 1 not written while full", w3[16], 0);
      check_true("CQ-full stall counted", perf[19*32 +: 32] > stall0);
      for (int i = 0; i < 4; i++) begin
        reap(1, 20000, 1);
        check($sformatf("held completion %0d status", i), c_st, 0);
      end
    end
    teardown_io();
    setup_io(16, 16);
  endtask

  // ================================================================ 9. DMA errors and host mapping
  task automatic t_dma();
    int f0, u0;
    logic [31:0] v;
    grp = "dma";
    // Max_Read_Request_Size 128 B (seed-independent; the random group only sometimes draws it): every read request --
    // SQE fetch, PRP list, 256-byte window read-ahead -- must be split at 128 B (rule checker counts violations)
    begin
      int v0, r0;
      host.cfg_wr('h78, 32'h0000_0000);                                  // MRRS 128 B, MPS 128 B
      check("MRRS programmed to 128 B", host.mrrs_bytes(), 128);
      v0 = host.viol; r0 = host.n_mrd;
      do_write(1, 1720, 16, 'h200, 0, 5, 0);                              // 8 KiB through a PRP list, page offset
      check("MRRS 128 B: 8 KiB WRITE", c_st, 0);
      do_read(1, 1720, 16, 0, 0);
      check_true("MRRS 128 B: at least 64 read requests for 8 KiB", host.n_mrd - r0 >= 64);
      check("MRRS 128 B: no TLP rule violation (MRd split at MRRS)", host.viol, v0);
      host.cfg_wr('h78, 32'h0000_2000);                                  // restore MRRS 512 B, MPS 128 B
    end
    // WRITE whose data page is not mapped in the IOMMU: read completes UR
    make_buf(512, 0, 1, 0);
    sqe_set(IO_WRITE, 1); sqe_prp(64'h0000_0002_0000_0000, 0); sqe[10] = 900; exec(1);
    check("WRITE from unmapped page -> Data Transfer Error", c_st, S(0, 0, 4));
    // READ into an unmapped page: posted writes are refused by the IOMMU; the device cannot know
    f0 = host.iommu_faults;
    sqe_set(IO_READ, 1); sqe_prp(64'h0000_0002_0000_0000, 0); sqe[10] = 0; exec(1);
    check("READ to unmapped page completes (posted writes)", c_st, 0);
    check_true("  IOMMU logged the refused writes", host.iommu_faults > f0);
    // read-only page as READ destination
    f0 = host.iommu_faults;
    host.map(1, 64'h0000_0003_0000_0000, 64'h1000, (3 << 20) / 4, 1, 0);
    sqe_set(IO_READ, 1); sqe_prp(64'h0000_0003_0000_0000, 0); sqe[10] = 0; exec(1);
    check_true("READ into read-only page: IOMMU faults", host.iommu_faults > f0);
    host.unmap(1);
    // read-ahead stays inside the buffer: data page mapped alone, the next page unmapped
    begin
      int ur0;
      ur0 = host.n_ur;
      host.map(1, 64'h0000_0004_0000_0000, 64'h1000, (3 << 20) / 4, 1, 1);
      for (int w = 0; w < 1024; w++) host.hw32(64'h0000_0004_0000_0000 + 64'(4 * w), pat(930 + w / 128, w % 128, 8'h44));
      sqe_set(IO_WRITE, 1); sqe_prp(64'h0000_0004_0000_0000, 0); sqe[10] = 930; sqe[12] = 7; exec(1);
      check("WRITE of a page whose neighbour is unmapped", c_st, 0);
      check("  no read beyond the buffer (no UR)", host.n_ur, ur0);
      if (c_st == 0) for (int k = 0; k < 1024; k++) ref_mem[930 * 128 + k] = pat(930 + k / 128, k % 128, 8'h44);
      sqe_set(IO_WRITE, 1); sqe_prp(64'h0000_0004_0000_0000 + 64'h800, 0); sqe[10] = 940; sqe[12] = 3; exec(1);
      check("WRITE of the upper half page (ends at the unmapped page)", c_st, 0);
      check("  no read beyond the buffer (no UR)", host.n_ur, ur0);
      if (c_st == 0) for (int k = 0; k < 512; k++) ref_mem[940 * 128 + k] = pat(930 + (k + 512) / 128, (k + 512) % 128, 8'h44);
      host.unmap(1);
      do_read(1, 930, 8, 0, 1);
      do_read(1, 940, 4, 0, 1);
    end
    // Completer Abort on data read
    make_buf(1024, 0, 1, 0);
    host.ca_base = bp[0]; host.ca_size = 64'h1000;
    sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[10] = 901; sqe[12] = 1; exec(1);
    check("WRITE data read CA -> Data Transfer Error", c_st, S(0, 0, 4));
    host.ca_size = 0;
    // no completion at all -> completion timeout
    make_buf(512, 0, 1, 0);
    host.drop_base = bp[0]; host.drop_size = 64'h1000;
    sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[10] = 902; exec(1);
    check("WRITE data read timeout -> Data Transfer Error", c_st, S(0, 0, 4));
    check_true("  completion timeout counted", perf[20*32 +: 32] != 0);
    host.drop_size = 0;
    // late completion (after the timeout): dropped, tag quarantined (rule checker: no reuse while outstanding)
    u0 = perf[22*32 +: 32];
    make_buf(512, 0, 1, 0);
    host.late_base = bp[0]; host.late_size = 64'h1000; host.late_lat = CPLTO + CPLTO / 2;
    sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[10] = 903; exec(1);
    check("late completion -> Data Transfer Error", c_st, S(0, 0, 4));
    host.late_size = 0;
    for (int i = 0; i < 6; i++) begin do_write(1, 910 + i, 1, 0, 1, i, 0); end
    repeat (CPLTO) @(posedge clk);
    check_true("late completion dropped as unexpected", perf[22*32 +: 32] > u0);
    do_read(1, 910, 6, 0, 1);
    // PRP list in unmapped memory
    make_buf(16 * 512, 'h400, 0, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 64'h0000_0002_0000_0000); sqe[12] = 15; exec(1);
    check("PRP list unreadable -> Data Transfer Error", c_st, S(0, 0, 4));
    check("  no data written", host.hr32(bp[0] + 64'h400), 32'hA5A5_0100);
    host.rd32(R_CSTS, v); check("controller still healthy", v[1:0], 2'b01);
  endtask

  // ================================================================ 10. fatal: SQE fetch failures (bus error, Bus Master Enable)
  task automatic t_fatal();
    logic [31:0] v;
    bit ok;
    grp = "fatal";
    nvme_disable();
    host.wr32(R_AQA, 32'h0003_0003); host.wr64(R_ASQ_LO, 64'h0000_0002_0000_0000); host.wr64(R_ACQ_LO, ACQ_A);
    host.wr32(R_CC, 32'h0046_0001);
    wait_rdy(1, 10000, ok);
    host.wr32(64'h1000, 32'd1);                                         // admin SQ entry in unmapped memory
    repeat (500) @(posedge clk);
    host.rd32(R_CSTS, v); check("SQE fetch UR -> CSTS.CFS", v[1], 1);
    nvme_enable(8, 8);
    host.rd32(R_CSTS, v); check("reset clears CFS", v[1:0], 2'b01);
    host.cfg_wr('h04, 32'h0000_0002);                                   // BME off
    sqe_set(ADM_IDENTIFY, 0); submit(0);
    repeat (500) @(posedge clk);
    host.rd32(R_CSTS, v); check("fetch with BME = 0 -> CFS", v[1], 1);
    check_true("no TLP issued without BME", perf[23*32 +: 32] != 0);
    host.cfg_wr('h04, 32'h0000_0006);
    nvme_enable(8, 8);
    setup_io(16, 16);
  endtask

  // ================================================================ 11. controller reset with commands in flight
  task automatic t_reset();
    logic [31:0] snap [64];
    longint unsigned t_rdy0, last;
    bit ok;
    grp = "reset";
    be.hold_cmds = 1;
    for (int i = 0; i < 6; i++) begin
      make_buf(4096, 0, 1, 0); fill_buf(4096, 800 + 8 * i, 9);
      sqe_set(IO_WRITE, 1); sqe_prp(prp1_v, 0); sqe[10] = 800 + 8 * i; sqe[12] = 7; submit_nodb(1);
    end
    ring_sq(1);
    repeat (600) @(posedge clk);
    for (int i = 0; i < 64; i++) snap[i] = host.hr32(h_cqb[1] + 64'(4 * i));
    host.wr32(R_CC, 32'h0046_0000);
    wait_rdy(0, 50000, ok);
    t_rdy0 = host.cyc;
    check_true("RDY -> 0 with commands in flight", ok);
    be.hold_cmds = 0;
    last = host.last_dev_req;
    repeat (3000) @(posedge clk);
    check_true("no device requests after RDY = 0", host.last_dev_req == last && last <= t_rdy0);
    begin
      int changed;
      changed = 0;
      for (int i = 0; i < 64; i++) if (host.hr32(h_cqb[1] + 64'(4 * i)) !== snap[i]) changed++;
      check("no CQE posted for aborted commands", changed, 0);
    end
    check_true("back end saw the aborts", be.n_abort > 0);
    nvme_enable(8, 8);
    setup_io(16, 16);
    do_write(1, 820, 2, 0, 1, 5, 0);
    do_read(1, 820, 2, 0, 1);
  endtask

  // ================================================================ 12. function-level reset
  task automatic t_flr();
    logic [31:0] v;
    grp = "flr";
    host.cfg_wr('h78, 32'h0000_A020);                                   // Initiate FLR (+ MRRS/MPS rewrite)
    repeat (400) @(posedge clk);
    check("FLR cleared Command register (MSE/BME)", host.cfg_rd('h04) & 32'h6, 0);
    pcie_enumerate(0);
    host.rd32(R_CC, v);   check("FLR: CC reset", v, 0);
    host.rd32(R_AQA, v);  check("FLR: AQA reset", v, 0);
    host.rd32(R_CSTS, v); check("FLR: CSTS reset", v, 0);
    nvme_enable(8, 8);
    setup_io(16, 16);
    do_read(1, 820, 2, 0, 1);
  endtask

  // ================================================================ 13. shutdown notification
  task automatic t_shutdown();
    logic [31:0] v;
    int n;
    grp = "shutdown";
    do_write(1, 1000, 4, 0, 1, 8'h77, 0);
    check_true("data in volatile cache before shutdown", be.volv[1000]);
    host.wr32(R_CC, 32'h0046_4001);                                     // SHN = 01b (normal)
    n = 0;
    host.rd32(R_CSTS, v);
    while (v[3:2] != 2'b10 && n < 200) begin repeat (16) @(posedge clk); host.rd32(R_CSTS, v); n++; end
    check("CSTS.SHST = shutdown complete", v[3:2], 2'b10);
    check_true("cache committed by shutdown", !be.volv[1000] && be.dur[1000 * 128] == ref_mem[1000 * 128]);
    nvme_enable(8, 8);
    host.rd32(R_CSTS, v); check("SHST cleared by reset", v[3:2], 2'b00);
    setup_io(16, 16);
  endtask

  // ================================================================ 14. power failure: flushed data survives, unflushed may not
  task automatic t_power();
    grp = "power";
    do_write(1, 1100, 4, 0, 1, 8'hA1, 0);
    simple_cmd(1, IO_FLUSH, 1, 12'h0, "FLUSH before power cut");
    do_write(1, 1200, 4, 0, 1, 8'hB2, 0);   // acknowledged, not flushed
    do_write(1, 1300, 2, 0, 1, 8'hC3, 1);   // FUA
    // power cut: volatile back-end state and the whole controller lost; host re-enumerates
    be.power_cut();
    rst_n = 1'b0;
    host.cfg_wr('h04, 32'h0); host.cfg_wr('h50, 32'h0);
    repeat (20) @(posedge clk);
    rst_n = 1'b1;
    tb_units_r = 0; tb_units_w = 0; tb_reads = 0; tb_writes = 0;         // SMART counters restart with the controller
    repeat (20) @(posedge clk);
    pcie_enumerate(0);
    nvme_enable(8, 8);
    setup_io(16, 16);
    for (int k = 0; k < 4 * 128; k++) ref_mem[1200 * 128 + k] = 32'h0;   // unflushed write lost (allowed: VWC = 1)
    do_read(1, 1100, 4, 0, 1);              // flushed: intact
    do_read(1, 1300, 2, 0, 1);              // FUA: intact
    do_read(1, 1200, 4, 0, 1);              // unflushed: previous contents
  endtask

  // ================================================================ 15. interrupts
  task automatic t_irq();
    logic [31:0] v, w3;
    int m0;
    grp = "irq pin";
    pcie_enumerate(0);
    nvme_enable(4, 4);
    sqe_set(ADM_IDENTIFY, 0); make_buf(4096, 0, 1, 0); sqe_prp(prp1_v, 0); sqe[10] = 2; submit(0);
    wait_cqe_visible(0);
    repeat (40) @(posedge clk);
    check("INTx asserted with CQE pending", host.intx_level, 1);
    host.wr32(R_INTMS, 32'h1);
    repeat (40) @(posedge clk);
    check("INTMS masks INTx", host.intx_level, 0);
    host.rd32(R_INTMS, v); check("INTMS reads mask", v, 32'h1);
    host.rd32(R_INTMC, v); check("INTMC reads mask", v, 32'h1);
    host.wr32(R_INTMC, 32'h1);
    repeat (40) @(posedge clk);
    check("INTMC unmasks INTx", host.intx_level, 1);
    reap(0, 1000, 1);
    repeat (40) @(posedge clk);
    check("CQ head doorbell deasserts INTx", host.intx_level, 0);
    host.cfg_wr('h04, 32'h0000_0406);                                   // INTx Disable
    sqe_set(ADM_IDENTIFY, 0); sqe_prp(prp1_v, 0); sqe[10] = 2; submit(0);
    wait_cqe_visible(0);
    repeat (40) @(posedge clk);
    check("INTx Disable suppresses INTx", host.intx_level, 0);
    reap(0, 1000, 1);
    host.cfg_wr('h04, 32'h0000_0006);
    // ---------------- MSI
    grp = "irq msi";
    pcie_enumerate(8);
    host.post_lat = 60;                                                  // long posted latency: ordering matters
    nvme_enable(8, 8);
    create_cq(1, 16, 1, 1, 12'h0);
    create_sq(1, 16, 1, 12'h0);
    m0 = host.msi_cnt[1];
    make_buf(4096, 0, 1, 0);
    sqe_set(IO_READ, 1); sqe_prp(prp1_v, 0); sqe[12] = 7; submit(1);
    begin
      int n;
      n = 0;
      while (host.msi_cnt[1] == m0 && n < 20000) begin @(posedge clk); n++; end
      w3 = host.hr32(h_cqb[1] + 12);
    end
    check("MSI vector 1 received", host.msi_cnt[1], m0 + 1);
    check("CQE visible when the MSI arrives (ordering)", w3[16], 1);
    check("data visible when the MSI arrives", host.hr32(bp[0] + 64'h4), ref_mem[1]);
    reap(1, 100, 1);
    if (c_st == 12'h0) begin tb_reads++; tb_units_r += 8; end
    // masked vector: no message until unmasked
    host.wr32(R_INTMS, 32'h2);
    m0 = host.msi_cnt[1];
    sqe_set(IO_FLUSH, 1); submit(1);
    repeat (1500) @(posedge clk);
    check("no MSI while vector masked", host.msi_cnt[1], m0);
    host.wr32(R_INTMC, 32'h2);
    repeat (300) @(posedge clk);
    check("MSI on unmask with entry pending", host.msi_cnt[1], m0 + 1);
    reap(1, 100, 1);
    // entries left after the head doorbell -> another message
    m0 = host.msi_cnt[1];
    sqe_set(IO_FLUSH, 1); submit_nodb(1); sqe_set(IO_FLUSH, 1); submit_nodb(1); ring_sq(1);
    repeat (1500) @(posedge clk);
    reap(1, 100, 0);
    host.wr32(64'h1004 + 8, 32'(h_cqh[1]));                              // consume one of two
    repeat (300) @(posedge clk);
    check_true("MSI re-sent while entries remain after head doorbell", host.msi_cnt[1] >= m0 + 2);
    reap(1, 100, 1);
    // IEN = 0
    teardown_io();
    create_cq(1, 16, 1, 0, 12'h0); create_sq(1, 16, 1, 12'h0);
    m0 = host.msi_total;
    simple_cmd(1, IO_FLUSH, 1, 12'h0, "flush on IEN = 0 CQ");
    repeat (300) @(posedge clk);
    check("IEN = 0: no interrupt", host.msi_total, m0);
    // one allocated message: vector 1 uses message 0
    pcie_enumerate(1);
    teardown_io();
    create_cq(1, 16, 1, 1, 12'h0); create_sq(1, 16, 1, 12'h0);
    m0 = host.msi_cnt[0];
    sqe_set(IO_FLUSH, 1); submit(1);
    repeat (1500) @(posedge clk);
    check_true("1 MSI vector allocated: IV 1 -> message 0", host.msi_cnt[0] > m0);
    reap(1, 100, 1);
    host.post_lat = 8;
    teardown_io();
    setup_io(16, 16);
  endtask

  // ================================================================ 16. random traffic (engine in sfn_tb_nvme_driver.svh)
  task automatic t_random();
    grp = "random";
    // randomise the transport and the back end
    host.rd_lat_min = 8 + ($urandom % 30); host.rd_lat_max = host.rd_lat_min + ($urandom % 200);
    host.cpl_split = $urandom % 2; host.cpl_reorder = $urandom % 2; host.rq_bp_pct = $urandom % 30;
    host.post_lat = 2 + ($urandom % 40); host.msi_bp_pct = $urandom % 50;
    be.lat_min = 0; be.lat_max = $urandom % 400; be.cmd_bp_pct = $urandom % 40;
    // random Max_Payload_Size (128 / 256 B) and Max_Read_Request_Size (128 / 256 / 512 B): exercises TLP splitting
    host.cfg_wr('h78, {16'h0, 1'b0, 3'($urandom % 3), 4'h0, 3'($urandom % 2), 5'h0});
    $display("[%0d] random: MPS %0d B, MRRS %0d B", host.cyc, host.mps_bytes(), host.mrrs_bytes());
    if (NIOQ > 1) begin
      teardown_io();
      for (int q = 1; q <= NIOQ; q++) create_cq(q, 4 + 4 * q, q, 1, 12'h0);
      for (int q = 1; q <= NIOQ; q++) create_sq(q, 3 + 5 * q, (q == NIOQ) ? 1 : q, 12'h0);   // last SQ shares CQ 1
      for (int q = 1; q <= NIOQ; q++) h_s2c[q] = (q == NIOQ) ? 1 : q;
    end
    random_traffic(400, NCTX + 4, 1400, CAPB, 64);
    host.cfg_wr('h78, 32'h0000_2020);
    host.rd_lat_min = 20; host.rd_lat_max = 60; host.rq_bp_pct = 0; host.post_lat = 8; host.msi_bp_pct = 0;
    be.lat_max = 40; be.cmd_bp_pct = 0;
    if (NIOQ > 1) begin
      teardown_io();
      setup_io(16, 16);
    end
  endtask

  // ================================================================ 17. Set/Get Features, Abort, AER (phase-2 admin commands)
  task automatic t_ext();
    logic [31:0] v;
    int nfua;
    grp = "ext admin";
    teardown_io();
    sqe_set(ADM_SET_FEAT, 0); sqe[10] = FID_NUM_Q; sqe[11] = 32'h0003_0003; exec(0);
    check("Set Features NQ status", c_st, 0);
    check("Set Features NQ allocated", c_dw0, {16'(NIOQ - 1), 16'(NIOQ - 1)});
    sqe_set(ADM_GET_FEAT, 0); sqe[10] = FID_NUM_Q; exec(0);
    check("Get Features NQ", c_dw0, {16'(NIOQ - 1), 16'(NIOQ - 1)});
    sqe_set(ADM_SET_FEAT, 0); sqe[10] = FID_NUM_Q; sqe[11] = 32'hFFFF_0000; exec(0);
    check("Set NQ 65536 -> Invalid Field", c_st, S(1, 0, 2));
    sqe_set(ADM_SET_FEAT, 0); sqe[10] = 32'h8000_0007; sqe[11] = 0; exec(0);
    check("Set Features SV = 1 -> not saveable", c_st, S(1, 1, 'h0D));
    sqe_set(ADM_GET_FEAT, 0); sqe[10] = 32'h0000_0306; exec(0);
    check("Get Features VWC supported capabilities", c_dw0, 32'h4);
    sqe_set(ADM_GET_FEAT, 0); sqe[10] = 32'h0000_0001; exec(0);
    check("Get Features Arbitration (not implemented) -> Invalid Field", c_st, S(1, 0, 2));
    setup_io(16, 16);
    sqe_set(ADM_SET_FEAT, 0); sqe[10] = FID_NUM_Q; sqe[11] = 0; exec(0);
    check("Set NQ after queue creation -> Command Sequence Error", c_st, S(1, 0, 'h0C));
    // volatile write cache disable: every write becomes FUA in the back end
    sqe_set(ADM_SET_FEAT, 0); sqe[10] = FID_VWC; sqe[11] = 0; exec(0);
    check("Set VWC WCE = 0", c_st, 0);
    sqe_set(ADM_GET_FEAT, 0); sqe[10] = FID_VWC; exec(0);
    check("Get VWC current = 0", c_dw0, 0);
    nfua = be.n_fua;
    do_write(1, 1500, 1, 0, 1, 3, 0);
    check("WCE = 0: write forced to FUA", be.n_fua, nfua + 1);
    check_true("  data durable", !be.volv[1500]);
    sqe_set(ADM_SET_FEAT, 0); sqe[10] = FID_VWC; sqe[11] = 1; exec(0);
    // Abort: best effort, command not aborted
    sqe_set(ADM_ABORT, 0); sqe[10] = {16'h1234, 16'd1}; exec(0);
    check("Abort status", c_st, 0);
    check("Abort DW0 bit 0 = not aborted", c_dw0, 1);
    // Asynchronous events
    grp = "aer";
    begin
      logic [15:0] aer1;
      sqe_set(ADM_AER, 0); aer1 = sqe[0][31:16]; submit(0);
      repeat (200) @(posedge clk);
      host.wr32(64'h1000 + 64'(8 * 7), 32'd1);                         // doorbell of a queue that does not exist
      reap(0, 5000, 1);
      check("AER completes on invalid doorbell register", c_cid, aer1);
      check("  AER DW0 {LID 01, AEI 01, AET 0}", c_dw0, 32'h0001_0100);
      sqe_set(ADM_AER, 0); aer1 = sqe[0][31:16]; submit(0);
      repeat (100) @(posedge clk);
      host.wr32(64'h1008, 32'd9999);                                   // SQ1 tail beyond the queue: masked
      repeat (300) @(posedge clk);
      v = host.hr32(h_cqb[0] + 64'(h_cqh[0] * 16 + 12));
      check("second error event masked until the log is read", v[16], !h_cqp[0]);
      adm_data(ADM_GET_LOG, 32'hFFFF_FFFF, {16'd15, 8'h00, LID_ERROR}, 0, 0, 0, 64, 0);   // RAE = 0
      check("error log read", c_st, 0);
      host.wr32(64'h1008, 32'd9999);
      reap(0, 5000, 1);
      check("AER after the log was read", c_cid, aer1);
      check("  AEI 02 invalid doorbell value", c_dw0, 32'h0001_0200);
      for (int i = 0; i <= 1; i++) begin sqe_set(ADM_AER, 0); submit(0); end
      repeat (200) @(posedge clk);
      sqe_set(ADM_AER, 0); exec(0);
      check("AER beyond AERL + 1 -> AER Limit Exceeded", c_st, S(1, 1, 5));
    end
    // outstanding AERs are dropped by the controller reset
    nvme_enable(8, 8);
    setup_io(16, 16);
  endtask

  // ================================================================ 18. log pages
  task automatic t_logs();
    logic [15:0] ecid;
    grp = "logs";
    // a known error first
    sqe_set(IO_READ, 2); ecid = sqe[0][31:16]; exec(1);
    adm_data(ADM_GET_LOG, 32'hFFFF_FFFF, {16'd255, 8'h80, LID_ERROR}, 0, 0, 0, 1024, 0);
    check("Error log status", c_st, 0);
    check_true("  newest entry has an error count", bw(0) != 0);
    check("  newest entry SQID / CID", bw(2), {ecid, 16'd1});
    check("  newest entry status (Invalid NS, DNR) + param location (NSID byte 4)", bw(3), 32'h0004_8016);
    check("  newest entry NSID", bw(6), 2);
    check_true("  older entry has a smaller count", bw(16) < bw(0));
    adm_data(ADM_GET_LOG, 32'hFFFF_FFFF, {16'd127, 8'h00, LID_SMART}, 0, 0, 0, 512, 0);
    check("SMART status", c_st, 0);
    $display("[%0d] SMART check: host counted reads %0d (%0d blocks) writes %0d (%0d blocks); controller DUR k=%0d r=%0d DUW k=%0d r=%0d",
             host.cyc, tb_reads, tb_units_r, tb_writes, tb_units_w, dut.dur_k, dut.dur_r, dut.duw_k, dut.duw_r);
    check("SMART host read commands", {bw(17), bw(16)}, 64'(tb_reads));
    check("SMART host write commands", {bw(21), bw(20)}, 64'(tb_writes));
    check("SMART data units read (1000 x 512 B, rounded up)", {bw(9), bw(8)}, 64'((tb_units_r + 999) / 1000));
    check("SMART data units written", {bw(13), bw(12)}, 64'((tb_units_w + 999) / 1000));
    check_true("SMART error-log entries counted", {bw(45), bw(44)} != 0);
    check("SMART temperature / spare not measured: 0", bw(0), 0);
    adm_data(ADM_GET_LOG, 0, {16'd127, 8'h00, LID_FW_SLOT}, 0, 0, 0, 512, 0);
    check("FW slot status", c_st, 0);
    check("FW slot AFI = slot 1", bw(0), 1);
    check("FW slot FRS1 'P57-'", bw(2), 32'h2D37_3550);
    adm_data(ADM_GET_LOG, 0, {16'd1, 8'h00, LID_FW_SLOT}, 0, 32'd8, 0, 8, 0);
    check("log page offset 8 returns FRS1", bw(0), 32'h2D37_3550);
    adm_data(ADM_GET_LOG, 0, {16'd127, 8'h00, LID_VS_PERF}, 0, 0, 0, 512, 0);
    check("vendor perf log status", c_st, 0);
    check_true("perf: SQEs fetched counted", bw(2) > 0);
    check("perf log equals live counter (fetched)", bw(2) <= perf[1*32 +: 32], 1);
    adm_data(ADM_GET_LOG, 0, {16'd127, 8'h00, 8'h05}, 0, 0, 0, 512, 0);
    check("unsupported log 05h -> Invalid Log Page", c_st, S(1, 1, 9));
    adm_data(ADM_GET_LOG, 0, {16'd127, 8'h00, LID_SMART}, 0, 32'd512, 0, 512, 0);
    check("offset beyond log -> Invalid Field", c_st, S(1, 0, 2));
    adm_data(ADM_GET_LOG, 0, {16'd127, 8'h00, LID_SMART}, 0, 32'd2, 0, 512, 0);
    check("offset not DW aligned -> Invalid Field", c_st, S(1, 0, 2));
    adm_data(ADM_GET_LOG, 1, {16'd127, 8'h00, LID_SMART}, 0, 0, 0, 512, 0);
    check("NSID 1 (no per-namespace SMART) -> Invalid Field", c_st, S(1, 0, 2));
    adm_data(ADM_GET_LOG, 0, {16'hFFFF, 8'h00, LID_SMART}, 32'h0000_0001, 0, 0, 4096, 0);
    check("NUMD beyond MDTS -> Invalid Field", c_st, S(1, 0, 2));
    adm_data(ADM_GET_LOG, 0, {16'd2047, 8'h00, LID_SMART}, 0, 0, 0, 8192, 0);
    check("8 KiB SMART read (zero-filled beyond 512 B)", c_st, 0);
    check("  zero fill", bw(1000), 0);
  endtask

  // ================================================================ group runner
  task automatic run_all(input string g);
    if (want("regs"))     t_regs();
    else pcie_enumerate(0);
    if (want("enable"))   t_enable();
    nvme_enable(8, 8);
    if (want("identify")) t_identify();
    if (want("queues"))   t_queues(); else setup_io(16, 16);
    if (want("io"))       t_io();
    if (want("prp"))      t_prp();
    if (want("invalid"))  t_invalid();
    if (want("wrap"))     t_wrap();
    if (want("dma"))      t_dma();
    if (want("fatal"))    t_fatal();
    if (want("reset"))    t_reset();
    if (want("flr"))      t_flr();
    if (want("shutdown")) t_shutdown();
    if (want("power"))    t_power();
    if (want("irq"))      t_irq();
    if (want("random"))   t_random();
    if (EXT != 0 && want("ext")) t_ext();
    if (want("logs"))     t_logs();
  endtask

  // ================================================================ performance sweep (+perf)
  // Front end with a zero-latency back end (BFM, pipelined window transfers): what the NVMe front end itself
  // sustains.  Host read-completion latency fixed at 100 cycles (400 ns at 250 MHz), posted latency 8.
  task automatic run_perf();
    int qds [4];
    qds[0] = 1; qds[1] = 2; qds[2] = 4; qds[3] = 8;
    grp = "perf";
    pcie_enumerate(8);
    nvme_enable(8, 8);
    setup_io(64, 64);
    be.lat_min = 0; be.lat_max = 0; be.rdy_delay = 1;
    host.rd_lat_min = 100; host.rd_lat_max = 100; host.cpl_split = 1; host.cpl_reorder = 0; host.post_lat = 8;
    for (int q = 0; q < 4; q++) perf_run("unit", 0, 0, qds[q], 200, 0, 1, 250.0);
    for (int q = 0; q < 4; q++) perf_run("unit", 2, 1, qds[q], 200, 0, 1024, 250.0);
    for (int q = 0; q < 4; q++) perf_run("unit", 1, 1, qds[q], 200, 0, 1024, 250.0);
    for (int q = 0; q < 4; q++) perf_run("unit", 2, 8, qds[q], 100, 0, 1024, 250.0);
    for (int q = 0; q < 4; q++) perf_run("unit", 1, 8, qds[q], 100, 0, 1024, 250.0);
    for (int q = 0; q < 4; q++) perf_run("unit", 2, 64, qds[q], 40, 0, 1024, 250.0);
    for (int q = 0; q < 4; q++) perf_run("unit", 1, 64, qds[q], 40, 0, 1024, 250.0);
    host.rd_lat_min = 400; host.rd_lat_max = 400;                     // 1.6 us host read latency
    perf_run("unit_lat1600ns", 2, 8, 1, 50, 0, 1024, 250.0);
    perf_run("unit_lat1600ns", 1, 8, 1, 50, 0, 1024, 250.0);
    perf_run("unit_lat1600ns", 1, 8, 8, 50, 0, 1024, 250.0);
    $display("PERF counters: fetched=%0d completed=%0d msi=%0d cq_full_stall=%0d be_svc_max=%0d lat_max=%0d fetch_lat_max=%0d",
             perf[1*32 +: 32], perf[2*32 +: 32], perf[10*32 +: 32], perf[19*32 +: 32], perf[18*32 +: 32],
             perf[16*32 +: 32], perf[25*32 +: 32]);
  endtask
