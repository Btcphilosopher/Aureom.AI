// =============================================================================
// SilicaFlux-STORE (Project 57) :: tb_nvme_ctrl -- self-checking unit testbench
//
// DUT  : silicaflux_nvme_controller (front end only)
// Host : sfn_tb_pcie_host (transaction-level PCIe transport, host memory, IOMMU,
//        configuration space, MSI / INTx, TLP rule checker) + the NVMe host
//        driver written as tasks below
// Back : sfn_tb_backend (P51 command contract, durable + volatile media)
//
// Configurations (+define+): default 1 I/O queue pair; CFG_MULTI 4 pairs;
// CFG_NOEXT baseline admin set only (Set/Get Features, Abort, AER -> Invalid Opcode).
// Plusargs: +seed=<n> +groups=<comma list | all> +perf (performance sweep only) +v (verbose)
// Every check increments PASS or FAIL; the last line is the verdict.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_nvme_ctrl;
  import silicaflux_nvme_pkg::*;
  import silicaflux_storage_pkg::*;

`ifdef CFG_MULTI
  localparam int NIOQ = 4;
`else
  localparam int NIOQ = 1;
`endif
`ifdef CFG_NOEXT
  localparam int EXT = 0;
`else
  localparam int EXT = 1;
`endif
  localparam int NCTX  = 8;
  localparam int MAXL2 = 15;               // 32 KiB front-end transfer limit
  localparam int CPLTO = 3000;             // short completion timeout for the tests
  localparam int NVEC  = 8;
  localparam int CAPB  = 2048;             // back-end media blocks
  localparam int NQ    = NIOQ + 1;

  logic clk = 1'b0, rst_n = 1'b0;
  always #2 clk = ~clk;                    // 250 MHz endpoint user clock (4 ns)

  // ================================================================ wiring
  logic        cq_valid, cq_ready, cq_write, cq_last, cc_valid, cc_ready, cc_last, rq_valid, rq_ready, rq_write, rq_last;
  logic        rc_valid, rc_ready, rc_last;
  logic [2:0]  cq_bar, cc_status, rc_status;
  logic [63:0] cq_addr, rq_addr;
  logic [10:0] cq_len_dw, cc_len_dw, rq_len_dw, rc_len_dw;
  logic [3:0]  cq_first_be, cq_last_be, rq_first_be, rq_last_be;
  logic [7:0]  cq_tag, cc_tag, rq_tag, rc_tag;
  logic [15:0] cq_req_id, cc_req_id;
  logic [31:0] cq_data, cc_data, rq_data, rc_data;
  logic [12:0] cc_byte_count, rc_byte_count;
  logic [6:0]  cc_lower_addr, rc_lower_addr;
  logic        cfg_bme, cfg_msi_en, cfg_intx_dis, cfg_flr, msi_valid, msi_ready, intx_assert;
  logic [2:0]  cfg_mps, cfg_mrrs, cfg_msi_mme;
  logic [4:0]  msi_vector;
  logic        be_cmd_valid, be_cmd_ready, be_cpl_valid, be_cpl_ready, be_idle, be_rdy, be_cfs;
  sfs_cmd_t    be_cmd;
  sfs_cpl_t    be_cpl;
  logic [63:0] be_capacity;
  logic [15:0] be_mdts;
  logic [1:0]  be_shst;
  logic        fe_en, fe_shn, fe_resetting, fe_reset_done, fe_db_err;
  logic        hw_req_valid, hw_req_ready, hw_req_write, hw_rsp_valid, hw_rsp_ready, hw_rsp_error;
  logic [31:0] hw_req_addr, hw_req_wdata, hw_rsp_rdata;
  logic [3:0]  hw_req_wstrb;
  logic [2:0]  dbg_state;
  logic [32*32-1:0] perf;

  silicaflux_nvme_controller #(.NUM_IOQ(NIOQ), .NCTX(NCTX), .NUM_VEC(NVEC), .MAX_XFER_LOG2(MAXL2),
                               .CPL_TIMEOUT(CPLTO), .ENABLE_EXT_ADMIN(EXT)) dut (
    .clk, .rst_n,
    .cq_valid, .cq_ready, .cq_write, .cq_bar, .cq_addr, .cq_len_dw, .cq_first_be, .cq_last_be, .cq_tag, .cq_req_id,
    .cq_data, .cq_last,
    .cc_valid, .cc_ready, .cc_tag, .cc_req_id, .cc_status, .cc_byte_count, .cc_lower_addr, .cc_len_dw, .cc_data, .cc_last,
    .rq_valid, .rq_ready, .rq_write, .rq_addr, .rq_len_dw, .rq_first_be, .rq_last_be, .rq_tag, .rq_data, .rq_last,
    .rc_valid, .rc_ready, .rc_tag, .rc_status, .rc_byte_count, .rc_lower_addr, .rc_len_dw, .rc_data, .rc_last,
    .cfg_bme, .cfg_mps, .cfg_mrrs, .cfg_msi_en, .cfg_msi_mme, .cfg_intx_dis, .cfg_flr,
    .msi_valid, .msi_ready, .msi_vector, .intx_assert,
    .be_cmd_valid, .be_cmd_ready, .be_cmd, .be_cpl_valid, .be_cpl_ready, .be_cpl, .be_capacity, .be_mdts, .be_idle,
    .be_rdy, .be_shst, .be_cfs, .fe_en, .fe_shn, .fe_resetting, .fe_reset_done, .fe_db_err,
    .hw_req_valid, .hw_req_ready, .hw_req_write, .hw_req_addr, .hw_req_wdata, .hw_req_wstrb,
    .hw_rsp_valid, .hw_rsp_ready, .hw_rsp_rdata, .hw_rsp_error,
    .dbg_state, .perf
  );

  sfn_tb_pcie_host host (
    .clk, .rst_n,
    .cq_valid, .cq_ready, .cq_write, .cq_bar, .cq_addr, .cq_len_dw, .cq_first_be, .cq_last_be, .cq_tag, .cq_req_id,
    .cq_data, .cq_last,
    .cc_valid, .cc_ready, .cc_tag, .cc_req_id, .cc_status, .cc_byte_count, .cc_lower_addr, .cc_len_dw, .cc_data, .cc_last,
    .rq_valid, .rq_ready, .rq_write, .rq_addr, .rq_len_dw, .rq_first_be, .rq_last_be, .rq_tag, .rq_data, .rq_last,
    .rc_valid, .rc_ready, .rc_tag, .rc_status, .rc_byte_count, .rc_lower_addr, .rc_len_dw, .rc_data, .rc_last,
    .cfg_bme, .cfg_mps, .cfg_mrrs, .cfg_msi_en, .cfg_msi_mme, .cfg_intx_dis, .cfg_flr,
    .msi_valid, .msi_ready, .msi_vector, .intx_assert
  );

  sfn_tb_backend #(.CAPB(CAPB), .NT(NCTX)) be (
    .clk, .rst_n,
    .cmd_valid(be_cmd_valid), .cmd_ready(be_cmd_ready), .cmd(be_cmd), .cpl_valid(be_cpl_valid), .cpl_ready(be_cpl_ready),
    .cpl(be_cpl), .capacity(be_capacity), .mdts(be_mdts), .idle(be_idle), .rdy(be_rdy), .shst(be_shst), .cfs(be_cfs),
    .fe_en, .fe_shn, .fe_resetting, .fe_reset_done,
    .m_req_valid(hw_req_valid), .m_req_ready(hw_req_ready), .m_req_write(hw_req_write), .m_req_addr(hw_req_addr),
    .m_req_wdata(hw_req_wdata), .m_req_wstrb(hw_req_wstrb), .m_rsp_valid(hw_rsp_valid), .m_rsp_ready(hw_rsp_ready),
    .m_rsp_rdata(hw_rsp_rdata), .m_rsp_error(hw_rsp_error)
  );

  // ================================================================ scoreboard
  int n_pass = 0, n_fail = 0;
  string grp = "";
  bit verbose = 0;
  task automatic check(input string what, input logic [63:0] got, input logic [63:0] exp);
    if (got === exp) n_pass++;
    else begin
      n_fail++;
      $display("[%0d] FAIL %s / %s: got 0x%0h expected 0x%0h", host.cyc, grp, what, got, exp);
    end
  endtask
  task automatic check_true(input string what, input bit c);
    check(what, 64'(c), 64'd1);
  endtask

  // ================================================================ NVMe host driver (shared with the SoC testbench)
`include "sfn_tb_nvme_driver.svh"

  // ================================================================ test groups
`include "tb_nvme_tests.svh"

  // ================================================================ main
  string groups;
  int seed, seed0;
  initial begin
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    seed0 = seed;
    void'($urandom(seed));
    if (!$value$plusargs("groups=%s", groups)) groups = "all";
    verbose = $test$plusargs("v");
    host.map(0, HB, 64'h40_0000, 0, 1, 1);                      // 4 MiB read/write
    repeat (10) @(posedge clk);
    rst_n = 1'b1;
    repeat (10) @(posedge clk);
    if ($test$plusargs("perf")) run_perf();
    else run_all(groups);
    // global checks
    grp = "global";
    repeat (200) @(posedge clk);
    check("PCIe TLP rule violations", 64'(host.viol), 0);
    $display("tb_nvme_ctrl NIOQ=%0d EXT=%0d seed=%0d: %0d checks, %0d failures, %0d cycles -> %s",
             NIOQ, EXT, seed0, n_pass + n_fail, n_fail, host.cyc, (n_fail == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin
    #400_000_000;
    $display("tb_nvme_ctrl: global timeout -> FAIL");
    $finish;
  end
endmodule

`default_nettype wire
