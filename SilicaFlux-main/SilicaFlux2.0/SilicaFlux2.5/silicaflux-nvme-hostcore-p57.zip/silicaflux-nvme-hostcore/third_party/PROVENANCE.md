# Third-party (reused SilicaFlux) sources

| Directory | Origin | Modified? |
|---|---|---|
| `silicaflux-storagecore-p51/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip` in `btcphilosopher/Aureom.AI` (commit `4173a23`): P51 RTL, generated map / enums, firmware sources, generated C header, NAND and host-memory models, P51's own vendored ControlCore (P21), DataFabric, MCU-I, SilicaFlux-V, SRAM library and RAS (P26) sources, P51 README (as `README_P51.md`) and four P51 docs | **No** — 103 / 103 files byte-identical (`third_party/SHA256SUMS`; `make vendor-check REPO=<checkout>` re-verifies against the archive) |

What P57 compiles from it: every P51 leaf module and the ControlCore (`rtl/files_soc.f`), the P51 protocol package
(`rtl/files_nvme.f`), the NAND model (SoC testbench), and the firmware (built unmodified with
`make -C third_party/silicaflux-storagecore-p51/firmware B=build/fw`; image CRC32 `f7d46dd3`, identical to P51's).
Not compiled: `sfs_host_if.sv`, `sfs_storage_subsys.sv`, `silicaflux_storage_soc.sv` — replaced by
`rtl/soc/sfn_storage_backend.sv` (derived from `sfs_storage_subsys.sv`, diff in docs/07 §2), `rtl/soc/sfn_hif_regs.sv`
and `rtl/soc/silicaflux_nvme_ssd.sv`.

No licence file exists in the repository; the same terms as the rest of the repository apply.
