#ifndef CC_CRC32_H
#define CC_CRC32_H
#include <stdint.h>
uint32_t cc_crc32(const void *data, uint32_t len);
#endif
