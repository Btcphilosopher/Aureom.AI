// =============================================================================
// SilicaFlux ControlCore :: cc_ras -- error collection, severity, injection
//
// Register page CC_PG_RAS (block cc_ras).  Sources (CC_RAS_SRC_*):
//   warning class  [7:0]   0 BUS_DECODE  crossbar decode / access-matrix / alignment error of a
//                                        data-side master (CPU data, host, DMA) (pulse)
//                          1 PERIPH_ERR  a register page refused an access (pulse)
//                          2 DMA_ERR     system DMA transfer ended in error (pulse)
//                          3 HOST_VIOL   host write refused by the host write lock (pulse)
//                          4 ISO_ACCESS  access to the isolated accelerator domain refused (pulse)
//                          5 EXT_WARN    SoC warning input (level)
//                          6 SW_WARN     firmware-reported warning (SW_REPORT)
//   fatal class   [15:8]   8 MEM_PARITY  IMEM/DMEM parity error on a read (pulse)
//                          9 TSU_HALTED  tensor unit halted: only a reset recovers (level)
//                         10 EXT_FATAL   SoC fatal input (level)
//                         11 SW_FATAL    firmware-reported fatal error (SW_REPORT)
// STATUS is sticky and W1C; a level source re-sets its bit every cycle it is
// active (clear it at the cause, then W1C).  Counters count events (pulses and
// rising edges of level sources), one per source per cycle, saturating.
// irq_warn  = |(STATUS[7:0]  & WARN_EN)  -> INTC source RAS_WARN
// irq_fatal = |(STATUS[15:8] & FATAL_EN) -> INTC source FATAL
// fatal_pin = CTRL.FATAL_TO_HOST & |STATUS[15:8] (host-visible)
// fatal_iso = CTRL.FATAL_ISOLATE & |STATUS[15:8] (PMU isolates the accelerators)
// Parity test support: PAR_INJECT arms a one-shot inversion of the parity of
// the next accepted IMEM/DMEM write; PAR_CHK_EN gates parity checking (the boot
// ROM enables it after scrubbing both banks).
// =============================================================================
`default_nettype none

module cc_ras
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // sources
  input  wire logic        ev_bus_decode,
  input  wire logic [31:0] ev_bus_decode_addr,
  input  wire logic        ev_periph_err,
  input  wire logic [31:0] ev_periph_err_addr,
  input  wire logic        ev_dma_err,
  input  wire logic        ev_host_viol,
  input  wire logic [31:0] ev_host_viol_addr,
  input  wire logic        ev_iso_access,
  input  wire logic        ev_parity,
  input  wire logic [31:0] ev_parity_addr,
  input  wire logic        lv_ext_warn,
  input  wire logic        lv_ext_fatal,
  input  wire logic        lv_tsu_halted,
  input  wire logic        mem_write,          // an IMEM/DMEM write was accepted this cycle
  // outputs
  output logic             irq_warn,
  output logic             irq_fatal,
  output logic             fatal_pin,
  output logic             fatal_iso,
  output logic             par_inject,
  output logic             par_chk_en
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  wire wr = rb_sel && rb_we;

  logic [15:0] st_q;
  logic [7:0]  wen_q, fen_q;
  logic [31:0] wcnt_q, fcnt_q, first_addr_q, last_addr_q, sw_code_q;
  logic [4:0]  first_src_q, last_src_q;
  logic        first_v_q, last_v_q, ctl_host_q, ctl_iso_q, pinj_q, pchk_q;
  logic [2:0]  lv_q;

  // ------------------------------------------------------------ event vectors
  wire [2:0] lv      = {lv_tsu_halted, lv_ext_fatal, lv_ext_warn};
  wire [2:0] lv_rise = lv & ~lv_q;
  wire sw_wr    = wr && rb_addr == CC_RAS_SW_REPORT;
  wire inj_wr   = wr && rb_addr == CC_RAS_INJECT;
  wire [15:0] inj = inj_wr ? (rb_wdata[15:0] & 16'h0F7F) : 16'd0;

  logic [15:0] pulse, level, events, setv;
  always_comb begin
    pulse = '0;
    pulse[CC_RAS_SRC_BUS_DECODE] = ev_bus_decode;
    pulse[CC_RAS_SRC_PERIPH_ERR] = ev_periph_err;
    pulse[CC_RAS_SRC_DMA_ERR]    = ev_dma_err;
    pulse[CC_RAS_SRC_HOST_VIOL]  = ev_host_viol;
    pulse[CC_RAS_SRC_ISO_ACCESS] = ev_iso_access;
    pulse[CC_RAS_SRC_SW_WARN]    = sw_wr && !rb_wdata[31];
    pulse[CC_RAS_SRC_MEM_PARITY] = ev_parity;
    pulse[CC_RAS_SRC_SW_FATAL]   = sw_wr && rb_wdata[31];
    level = '0;
    level[CC_RAS_SRC_EXT_WARN]   = lv[0];
    level[CC_RAS_SRC_EXT_FATAL]  = lv[1];
    level[CC_RAS_SRC_TSU_HALTED] = lv[2];
    events = pulse | inj;
    events[CC_RAS_SRC_EXT_WARN]   = events[CC_RAS_SRC_EXT_WARN]   | lv_rise[0];
    events[CC_RAS_SRC_EXT_FATAL]  = events[CC_RAS_SRC_EXT_FATAL]  | lv_rise[1];
    events[CC_RAS_SRC_TSU_HALTED] = events[CC_RAS_SRC_TSU_HALTED] | lv_rise[2];
    setv = pulse | level | inj;
  end

  function automatic logic [31:0] src_addr(input logic [4:0] s);
    case ({27'd0, s})
      CC_RAS_SRC_BUS_DECODE: src_addr = ev_bus_decode_addr;
      CC_RAS_SRC_PERIPH_ERR: src_addr = ev_periph_err_addr;
      CC_RAS_SRC_HOST_VIOL:  src_addr = ev_host_viol_addr;
      CC_RAS_SRC_MEM_PARITY: src_addr = ev_parity_addr;
      CC_RAS_SRC_SW_WARN, CC_RAS_SRC_SW_FATAL: src_addr = {1'b0, rb_wdata[30:0]};
      default:               src_addr = 32'd0;
    endcase
  endfunction

  // lowest / highest active event index and the number of events
  logic [4:0] lo_idx, hi_idx;
  logic [4:0] wn, fn;
  always_comb begin
    lo_idx = '0; hi_idx = '0;
    for (int i = 15; i >= 0; i--) if (events[i]) lo_idx = 5'(i);
    for (int i = 0; i < 16; i++)  if (events[i]) hi_idx = 5'(i);
    wn = '0; fn = '0;
    for (int i = 0; i < 8; i++) begin
      wn = wn + 5'(events[i]);
      fn = fn + 5'(events[8 + i]);
    end
  end

  function automatic logic [31:0] sat_add(input logic [31:0] a, input logic [4:0] b);
    logic [32:0] s;
    s = {1'b0, a} + 33'(b);
    sat_add = s[32] ? 32'hFFFF_FFFF : s[31:0];
  endfunction

  wire clr_first  = wr && rb_addr == CC_RAS_CTRL && rb_wdata[2];
  wire clr_counts = wr && rb_addr == CC_RAS_CTRL && rb_wdata[3];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= '0; wen_q <= '0; fen_q <= '0; wcnt_q <= '0; fcnt_q <= '0;
      first_addr_q <= '0; last_addr_q <= '0; sw_code_q <= '0;
      first_src_q <= '0; last_src_q <= '0; first_v_q <= 1'b0; last_v_q <= 1'b0;
      ctl_host_q <= CC_RAS_CTRL_RST[0]; ctl_iso_q <= CC_RAS_CTRL_RST[1];
      pinj_q <= 1'b0; pchk_q <= 1'b0; lv_q <= '0;
    end else begin
      lv_q <= lv;
      // STATUS: W1C, then set (a new event wins)
      st_q <= (st_q & ~((wr && rb_addr == CC_RAS_STATUS) ? rb_wdata[15:0] : 16'd0)) | setv;
      if (wr && rb_addr == CC_RAS_WARN_EN)  wen_q <= rb_wdata[7:0];
      if (wr && rb_addr == CC_RAS_FATAL_EN) fen_q <= rb_wdata[7:0];
      if (wr && rb_addr == CC_RAS_CTRL) begin
        ctl_host_q <= rb_wdata[0];
        ctl_iso_q  <= rb_wdata[1];
      end
      if (sw_wr) sw_code_q <= {1'b0, rb_wdata[30:0]};
      // counters
      if (clr_counts) begin
        wcnt_q <= '0; fcnt_q <= '0;
      end else begin
        wcnt_q <= sat_add(wcnt_q, wn);
        fcnt_q <= sat_add(fcnt_q, fn);
      end
      // first / last event
      if (clr_first) first_v_q <= 1'b0;
      if (events != 16'd0) begin
        if (!first_v_q || clr_first) begin
          first_v_q <= 1'b1; first_src_q <= lo_idx; first_addr_q <= src_addr(lo_idx);
        end
        last_v_q <= 1'b1; last_src_q <= hi_idx; last_addr_q <= src_addr(hi_idx);
      end
      // parity test controls
      if (wr && rb_addr == CC_RAS_PAR_INJECT) pinj_q <= rb_wdata[0];
      else if (mem_write)                     pinj_q <= 1'b0;
      if (wr && rb_addr == CC_RAS_PAR_CHK_EN) pchk_q <= rb_wdata[0];
    end
  end

  assign irq_warn   = |(st_q[7:0] & wen_q);
  assign irq_fatal  = |(st_q[15:8] & fen_q);
  assign fatal_pin  = ctl_host_q && |st_q[15:8];
  assign fatal_iso  = ctl_iso_q && |st_q[15:8];
  assign par_inject = pinj_q;
  assign par_chk_en = pchk_q;

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      CC_RAS_STATUS:      rb_rdata = {16'd0, st_q};
      CC_RAS_WARN_EN:     rb_rdata = {24'd0, wen_q};
      CC_RAS_FATAL_EN:    rb_rdata = {24'd0, fen_q};
      CC_RAS_WARN_COUNT:  begin rb_rdata = wcnt_q; rb_err = rb_we; end
      CC_RAS_FATAL_COUNT: begin rb_rdata = fcnt_q; rb_err = rb_we; end
      CC_RAS_FIRST_SRC:   begin rb_rdata = {first_v_q, 26'd0, first_src_q}; rb_err = rb_we; end
      CC_RAS_FIRST_ADDR:  begin rb_rdata = first_addr_q; rb_err = rb_we; end
      CC_RAS_LAST_SRC:    begin rb_rdata = {last_v_q, 26'd0, last_src_q}; rb_err = rb_we; end
      CC_RAS_LAST_ADDR:   begin rb_rdata = last_addr_q; rb_err = rb_we; end
      CC_RAS_INJECT:      rb_err = !rb_we;
      CC_RAS_SW_REPORT:   rb_err = !rb_we;
      CC_RAS_SW_CODE:     begin rb_rdata = sw_code_q; rb_err = rb_we; end
      CC_RAS_CTRL:        rb_rdata = {30'd0, ctl_iso_q, ctl_host_q};
      CC_RAS_PAR_INJECT:  rb_rdata = {31'd0, pinj_q};
      CC_RAS_PAR_CHK_EN:  rb_rdata = {31'd0, pchk_q};
      CC_RAS_RAW:         begin rb_rdata = {29'd0, lv}; rb_err = rb_we; end
      default:            rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
