#!/usr/bin/env python3
"""SilicaFlux ControlCore -- build a bootable firmware image.

    mkimage.py <fw.elf> <fw.payload.bin> <out_prefix> [--version 0x00010000] [--name NAME]

Layout (loaded at CC_IMEM_BASE, checked by the boot ROM, docs/BOOT.md):
    [0x000 .. CC_IMAGE_HDR_BYTES)  header: magic, header version, image size, entry,
                                   load address, CRC32(payload), fw version, flags, name[32]
    [CC_IMAGE_HDR_BYTES .. size)   payload = objcopy -O binary of the ELF (code starts here)
Outputs <out_prefix>.img (binary), <out_prefix>.hex (one little-endian 32-bit word
per line, for $readmemh / the testbench host loader) and <out_prefix>.json.
CRC32 = zlib.crc32 (IEEE 802.3, reflected) -- the same function as firmware/common/crc32.c.
It detects corruption; it does not authenticate the image.
"""
import argparse
import json
import os
import struct
import sys
import zlib

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "generated"))
import cc_memmap as M  # noqa: E402


def elf_entry(path):
    with open(path, "rb") as f:
        hdr = f.read(52)
    if hdr[:4] != b"\x7fELF" or hdr[4] != 1:
        sys.exit("mkimage: not an ELF32 file")
    return struct.unpack_from("<I", hdr, 0x18)[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("elf")
    ap.add_argument("payload")
    ap.add_argument("out")
    ap.add_argument("--version", type=lambda x: int(x, 0), default=0x00010000)
    ap.add_argument("--name", default="controlcore_fw")
    a = ap.parse_args()
    payload = open(a.payload, "rb").read()
    payload += b"\0" * ((-len(payload)) % 4)
    hb = M.CC_IMAGE_HDR_BYTES
    size = hb + len(payload)
    entry = elf_entry(a.elf)
    if size > M.CC_IMEM_SIZE:
        sys.exit(f"mkimage: image {size} B exceeds IMEM {M.CC_IMEM_SIZE} B")
    if not (M.CC_IMEM_BASE + hb <= entry < M.CC_IMEM_BASE + size):
        sys.exit(f"mkimage: entry 0x{entry:08x} outside the image payload")
    crc = zlib.crc32(payload) & 0xFFFFFFFF
    name = a.name.encode()[:31]
    hdr = struct.pack("<8I", M.CC_IMAGE_MAGIC, M.CC_IMAGE_HDR_VERSION, size, entry, M.CC_IMEM_BASE, crc,
                      a.version, 0) + name + b"\0" * (32 - len(name))
    hdr += b"\0" * (hb - len(hdr))
    img = hdr + payload
    with open(a.out + ".img", "wb") as f:
        f.write(img)
    with open(a.out + ".hex", "w") as f:
        for i in range(0, len(img), 4):
            f.write("%08x\n" % struct.unpack_from("<I", img, i)[0])
    info = {"size": size, "entry": f"0x{entry:08x}", "crc32": f"0x{crc:08x}", "load": f"0x{M.CC_IMEM_BASE:08x}",
            "version": f"0x{a.version:08x}", "words": len(img) // 4}
    with open(a.out + ".json", "w") as f:
        json.dump(info, f, indent=1)
    print(f"mkimage: {a.out}.img {size} B ({size * 100 // M.CC_IMEM_SIZE}% of IMEM) entry 0x{entry:08x} "
          f"crc32 0x{crc:08x}")


if __name__ == "__main__":
    main()
