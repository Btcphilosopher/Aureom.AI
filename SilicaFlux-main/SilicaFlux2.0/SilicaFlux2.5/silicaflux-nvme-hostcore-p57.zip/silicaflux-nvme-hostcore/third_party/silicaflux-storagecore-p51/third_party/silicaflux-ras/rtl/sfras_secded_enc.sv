// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_secded_enc
// Combinational extended-Hamming SECDED encoder, K data bits -> N = K+R+1.
//
//   cw_o[K-1:0]   = data_i                                  (systematic)
//   cw_o[K+R-1:K] = Hamming check bits  c[j] = XOR of data bits whose Hamming
//                   position has bit j set           (j = 0 .. R-1)
//   cw_o[K+R]     = overall parity  p = ^data_i ^ ^c  (even over the code)
//   then cw_o[K+R:K] ^= INV (inversion mask, R+1 bits; 0 = plain code)
//
// Bit ordering, positions and INV: rtl/sfras_ecc_funcs.svh and
// docs/01_ecc_architecture.md.  Depth: one XOR tree per check bit (about
// K/2 inputs each) plus the parity tree.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_secded_enc #(
  parameter int K   = 64,
  parameter int INV = 0,                         // check/parity inversion mask (R+1 bits used)
  // ---- derived, do not override ----
  parameter int R   = $clog2(K + $clog2(K + 1) + 1),   // = smallest r with 2^r >= K+r+1
  parameter int N   = K + R + 1
) (
  input  wire logic [K-1:0] data_i,
  output logic      [N-1:0] cw_o
);
  `include "sfras_ecc_funcs.svh"

  if (K < 1) begin : g_err_k_lt_1
    `SFRAS_CFG_FATAL("sfras_secded_enc: K must be >= 1")
  end
  if (R != sfras_ecc_r(K) || N != K + sfras_ecc_r(K) + 1) begin : g_err_derived_overridden
    `SFRAS_CFG_FATAL("sfras_secded_enc: R / N are derived parameters and must not be overridden")
  end

  logic [R-1:0] chk;

  for (genvar j = 0; j < R; j++) begin : g_chk
    logic [K-1:0] cov;                           // data bits covered by check bit j
    for (genvar i = 0; i < K; i++) begin : g_cov
      localparam int P = sfras_ecc_dpos(i);
      if (((P >> j) & 1) == 1) begin : g_on
        assign cov[i] = data_i[i];
      end else begin : g_off
        assign cov[i] = 1'b0;
      end
    end
    assign chk[j] = ^cov;
  end

  localparam logic [R:0] INV_V = INV[R:0];

  wire par = (^data_i) ^ (^chk);

  assign cw_o = {par ^ INV_V[R], chk ^ INV_V[R-1:0], data_i};

endmodule

`default_nettype wire
