/* =============================================================================
 * SilicaFlux ControlCore -- boot ROM (mask ROM at CC_BOOTROM_BASE, 8 KiB)
 *
 * Boot sequence (docs/BOOT.md), every stage published in SYSCTRL.BOOT_STAGE:
 *   ROM_START   reset released, DMEM scrubbed (rom_start.S)
 *   ROM_INIT    peripherals to a known state, DMEM pattern test
 *               warm boot (cause SOFT/WDT): IMEM kept; if its image still passes
 *               the header + CRC32 check it is restarted without the host
 *               cold boot: IMEM scrubbed (parity), parity checking enabled
 *   WAIT_IMAGE  BOOT_MODE_HOST: the host writes the image into IMEM through the
 *               host port, then H2F_MSG0 = IMAGE_READY + H2F_RING
 *   IMAGE_CHECK BOOT_MODE_EXT: the system DMA copies the image from device memory
 *               (H2F_MSG1 or CC_EXT_IMAGE_DEFAULT) into IMEM.  Then: magic, header
 *               version, size, load address, entry, CRC32 of the payload.
 *   FW_START    SECURITY.BOOT_MEASURE = CRC32 (write-once), fence.i, jump to entry
 *   BOOT_ERROR  BOOT_STATUS = CC_BOOT_ERR_*; the host is told (F2H_RING) and may
 *               load a corrected image (no reset needed)
 * The CRC32 is an integrity check against corruption.  It is NOT authentication:
 * anyone who can write IMEM can produce a matching CRC.  Firmware authentication
 * is outside this project (Project 28); SECURITY.STATUS reports it as absent.
 * ===========================================================================*/
#include "cc_hw.h"
#include "cc_crc32.h"

extern uint32_t __bss_end[], __stack_top[];

#define BOOT_STATUS_WARM 0x100u

static void rputc(char c) { MBOX(CC_MBOX_DIAG_TX) = (uint8_t)c; }
static void rputs(const char *s) { while (*s) rputc(*s++); }
static void rhex(uint32_t v) {
  for (int i = 28; i >= 0; i -= 4) rputc("0123456789abcdef"[(v >> i) & 15u]);
}

static void reply(uint32_t cmd, uint32_t sts, uint32_t detail) {
  MBOX_F2H(1) = detail;
  MBOX_F2H(0) = sts | (cmd << 8);
  MBOX(CC_MBOX_F2H_RING) = cmd;
}

static void boot_error(uint32_t code) {
  SYSCTRL(CC_SYSCTRL_BOOT_STATUS) = code;
  boot_stage(CC_BOOT_STAGE_BOOT_ERROR);
  rputs("ROM: boot error ");
  rhex(code);
  rputc('\n');
  reply(CC_MBOX_CMD_IMAGE_READY, CC_MBOX_STS_BAD_CMD, code);
}

void rom_trap_c(uint32_t cause, uint32_t epc, uint32_t tval) {
  MBOX_F2H(1) = cause;
  MBOX_F2H(2) = epc;
  MBOX_F2H(3) = tval;
  SYSCTRL(CC_SYSCTRL_BOOT_STATUS) = CC_BOOT_ERR_TRAP;
  boot_stage(CC_BOOT_STAGE_BOOT_ERROR);
  rputs("ROM: trap ");
  rhex(cause);
  rputc(' ');
  rhex(epc);
  rputc('\n');
}

/* DMEM pattern test between the ROM's .bss and its stack (the whole bank was
 * zeroed by rom_start.S, so every word has valid parity). */
static int memtest_dmem(void) {
  volatile uint32_t *lo = (volatile uint32_t *)(uintptr_t)__bss_end;
  volatile uint32_t *hi = (volatile uint32_t *)((uintptr_t)__stack_top - 4096u);   /* keep 4 KiB of stack */
  int bad = 0;
  for (volatile uint32_t *p = lo; p < hi; p++) *p = (uint32_t)(uintptr_t)p ^ 0xA5A55A5Au;
  for (volatile uint32_t *p = lo; p < hi; p++) if (*p != ((uint32_t)(uintptr_t)p ^ 0xA5A55A5Au)) bad++;
  for (volatile uint32_t *p = lo; p < hi; p++) *p = 0u;
  return bad;
}

static void scrub_imem(void) {
  volatile uint32_t *p = (volatile uint32_t *)CC_IMEM_BASE;
  volatile uint32_t *e = (volatile uint32_t *)(CC_IMEM_BASE + CC_IMEM_SIZE);
  while (p < e) { p[0] = 0u; p[1] = 0u; p[2] = 0u; p[3] = 0u; p += 4; }
}

static int dma_copy(uint32_t src, uint32_t dst, uint32_t len) {
  DMA(CC_DMA_INT_ENABLE) = 0u;
  DMA(CC_DMA_SRC_ADDR) = src;
  DMA(CC_DMA_DST_ADDR) = dst;
  DMA(CC_DMA_LENGTH) = len;
  DMA(CC_DMA_MODE) = 0u;
  DMA(CC_DMA_INT_STATUS) = CC_DMA_INT_DONE | CC_DMA_INT_ERROR;
  DMA(CC_DMA_CONTROL) = CC_DMA_CONTROL_START;
  while (DMA(CC_DMA_STATUS) & CC_DMA_STATUS_BUSY) {}
  return (DMA(CC_DMA_STATUS) & CC_DMA_STATUS_ERROR) ? -1 : 0;
}

static uint32_t check_header(void) {
  const volatile cc_image_hdr_t *h = (const volatile cc_image_hdr_t *)CC_IMEM_BASE;
  if (h->magic != CC_IMAGE_MAGIC) return CC_BOOT_ERR_MAGIC;
  if (h->hdr_version != CC_IMAGE_HDR_VERSION) return CC_BOOT_ERR_HDR_VERSION;
  if (h->image_size <= CC_IMAGE_HDR_BYTES || h->image_size > CC_IMEM_SIZE || (h->image_size & 3u) ||
      h->load_addr != CC_IMEM_BASE)
    return CC_BOOT_ERR_SIZE;
  if (h->entry < CC_IMEM_BASE + CC_IMAGE_HDR_BYTES || h->entry >= CC_IMEM_BASE + h->image_size || (h->entry & 3u))
    return CC_BOOT_ERR_ENTRY;
  return CC_BOOT_ERR_NONE;
}

static uint32_t check_image(void) {
  const volatile cc_image_hdr_t *h = (const volatile cc_image_hdr_t *)CC_IMEM_BASE;
  uint32_t e = check_header();
  if (e) return e;
  uint32_t crc = cc_crc32((const void *)(CC_IMEM_BASE + CC_IMAGE_HDR_BYTES), h->image_size - CC_IMAGE_HDR_BYTES);
  return (crc == h->crc32) ? CC_BOOT_ERR_NONE : CC_BOOT_ERR_CRC;
}

static void start_image(uint32_t warm) {
  const volatile cc_image_hdr_t *h = (const volatile cc_image_hdr_t *)CC_IMEM_BASE;
  SEC(CC_SEC_BOOT_MEASURE) = h->crc32;
  SYSCTRL(CC_SYSCTRL_BOOT_STATUS) = warm ? BOOT_STATUS_WARM : 0u;
  boot_stage(CC_BOOT_STAGE_FW_START);
  rputs(warm ? "ROM: warm start " : "ROM: start ");
  rhex(h->entry);
  rputs(" crc ");
  rhex(h->crc32);
  rputc('\n');
  fence_i();
  ((void (*)(void))(uintptr_t)h->entry)();
}

void rom_main(void) {
  boot_stage(CC_BOOT_STAGE_ROM_START);
  rputs("\nSFCC boot ROM v1.0\n");
  uint32_t cause = SYSCTRL(CC_SYSCTRL_RESET_CAUSE);
  uint32_t mode = SYSCTRL(CC_SYSCTRL_BOOT_MODE) & 3u;

  /* ---- ROM_INIT: known peripheral state, memory test */
  boot_stage(CC_BOOT_STAGE_ROM_INIT);
  INTC(CC_INTC_ENABLE) = 0u;
  INTC(CC_INTC_THRESHOLD) = 0u;
  DMA(CC_DMA_INT_ENABLE) = 0u;
  RAS(CC_RAS_WARN_EN) = 0u;
  RAS(CC_RAS_FATAL_EN) = 0u;
  if (memtest_dmem()) {
    boot_error(CC_BOOT_ERR_MEMTEST);
    for (;;) wfi();
  }

  /* ---- warm boot: the image in IMEM survived a soft / watchdog reset */
  if (cause & (CC_RESET_CAUSE_SOFT | CC_RESET_CAUSE_WDT)) {
    RAS(CC_RAS_PAR_CHK_EN) = 1u;
    if (check_image() == CC_BOOT_ERR_NONE) start_image(1u);
    rputs("ROM: retained image invalid, cold boot\n");
  }

  /* ---- cold boot */
  scrub_imem();
  RAS(CC_RAS_PAR_CHK_EN) = 1u;

  if (mode == CC_BOOT_MODE_EXT) {
    uint32_t src = MBOX_H2F(1) ? MBOX_H2F(1) : CC_EXT_IMAGE_DEFAULT;
    uint32_t e;
    boot_stage(CC_BOOT_STAGE_IMAGE_CHECK);
    rputs("ROM: image from ");
    rhex(src);
    rputc('\n');
    if (dma_copy(src, CC_IMEM_BASE, CC_IMAGE_HDR_BYTES)) {
      e = CC_BOOT_ERR_DMA;
    } else if ((e = check_header()) == CC_BOOT_ERR_NONE) {
      uint32_t size = ((const volatile cc_image_hdr_t *)CC_IMEM_BASE)->image_size;
      if (dma_copy(src + CC_IMAGE_HDR_BYTES, CC_IMEM_BASE + CC_IMAGE_HDR_BYTES, size - CC_IMAGE_HDR_BYTES))
        e = CC_BOOT_ERR_DMA;
      else
        e = check_image();
    }
    if (e == CC_BOOT_ERR_NONE) start_image(0u);
    boot_error(e);
    scrub_imem();              /* fall back to host loading */
  }

  for (;;) {
    boot_stage(CC_BOOT_STAGE_WAIT_IMAGE);
    for (;;) {
      if (MBOX(CC_MBOX_DB_STATUS) & 1u) {
        uint32_t cmd = MBOX_H2F(0);
        MBOX(CC_MBOX_H2F_ACK) = 0u;
        if (cmd == CC_MBOX_CMD_IMAGE_READY) break;
        reply(cmd, CC_MBOX_STS_BUSY, 0u);           /* not ready for commands yet */
      }
    }
    boot_stage(CC_BOOT_STAGE_IMAGE_CHECK);
    uint32_t e = check_image();
    if (e == CC_BOOT_ERR_NONE) {
      reply(CC_MBOX_CMD_IMAGE_READY, CC_MBOX_STS_OK, 0u);
      start_image(0u);
    }
    boot_error(e);
  }
}
