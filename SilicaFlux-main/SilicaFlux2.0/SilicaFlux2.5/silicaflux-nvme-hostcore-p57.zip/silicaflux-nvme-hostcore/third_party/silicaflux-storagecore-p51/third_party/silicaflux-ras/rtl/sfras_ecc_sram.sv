// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_ecc_sram
// SECDED-protected single-port SRAM: the silicaflux-sramlib sram_sp request /
// response contract on the functional side, an N-bit raw macro underneath
// (sram_backend_1rw: GENERIC / FPGA / ASIC macro), plus a scrub port, an
// initialisation engine, a raw MBIST test port, poison handling, a RAS event
// output and an (optionally compiled-in) fault-injection port.
//
// ---------------------------------------------------------------- code
//   KC = K (+1 when POISON_MODE = BIT: the poison flag is data bit K of the
//   code, so it is itself single-error-corrected).  N = KC + R + 1 stored bits
//   (sfras_ecc_funcs.svh).  K=64, POISON_MODE=SIG -> (72,64); K=64,
//   POISON_MODE=BIT -> 73 bits; K=32, SIG -> (39,32).  The macro is written
//   with MASK_WIDTH = 1: a stored word is always replaced as a whole, so the
//   check bits can never be out of step with the data (no macro byte enables;
//   a macro with its own ECC must NOT be put under this wrapper).
//   INV_SEL < 0 selects the default check-bit inversion: the all-zero (and,
//   where possible, all-ones) stored word decodes as UNCORRECTABLE, so a dead
//   row or an un-initialised/zeroed macro is never read as valid data.
//
// ---------------------------------------------------------------- functional port
//   Identical to sram_sp (docs/mem/01_interface_spec.md of silicaflux-sramlib)
//   plus rsp_ce / rsp_poison:
//   * read      : response READ_LATENCY + DEC_PIPE + 1 cycles after acceptance,
//                 rsp_rdata = corrected data.  rsp_ce = 1 iff a bit was
//                 corrected.  Uncorrectable or poisoned word: rsp_err = 1 and
//                 rsp_poison = 1, rsp_rdata = the stored (uncorrected) data
//                 bits (UE_ZERO = 0) or 0 (UE_ZERO = 1) -- never "valid zero".
//   * full write: wmask all ones (or MASK_W = 1): encoded and written at the
//                 acceptance edge, one cycle of array time.
//   * partial   : BYTE_EN = 1 -> read-modify-write: the word is read, decoded
//     write       and corrected, the written bytes are merged, the word is
//                 re-encoded and written back.  The port is LOCKED from the
//                 read to the write-back (READ_LATENCY + DEC_PIPE + 1 cycles):
//                 no other access can observe or modify the word in between,
//                 so there is no read-after-write hazard.  If the old word is
//                 uncorrectable or poisoned the bytes it contributes are
//                 unknown: POISON_MODE NONE aborts the write (word left as
//                 found, still uncorrectable), SIG / BIT store the merged word
//                 POISONED; in every case the write response has rsp_err = 1.
//                 BYTE_EN = 0 -> a partial strobe is refused (rsp_err = 1, no
//                 side effect).  wmask = 0 -> acknowledged no-op.
//   * invalid address (non-power-of-two DEPTH): rsp_err = 1, no access.
//   * WRITE_ACK = 0: writes are posted; an RMW error is then visible only as
//                 a RAS event (there is no response to carry it).
//
// ---------------------------------------------------------------- scrub port
//   scr_req_* (valid/ready, op CHECK / FIX / VERIFY, address); scr_rsp_* one
//   cycle per request, READ_LATENCY + DEC_PIPE cycles after acceptance, no
//   back-pressure.  CHECK and VERIFY are plain reads (one cycle of array time,
//   no lock).  FIX is a locked read; a correctable word is written back
//   corrected (the stored codeword with the one bit flipped back, poison flag
//   preserved).  Arbitration: functional requests first; a scrub request that
//   has waited SCRUB_MAX_WAIT cycles takes the next slot (no starvation).
//
// ---------------------------------------------------------------- init / test
//   Initialisation writes encode(0) to every word, one per cycle, after reset
//   (INIT_ON_RESET), on init_req_i, and after the MBIST test port is released
//   (REINIT_AFTER_TEST: MBIST leaves patterns with arbitrary check bits).  No
//   functional or scrub request is accepted while it runs.
//   Test port: tst_active requests the array; tst_ready = 1 once nothing is in
//   flight (a pending write-back is never dropped).  While tst_ready the MBIST
//   bus drives raw N-bit words (data AND check bits are tested); tst_rdata is
//   the raw word READ_LATENCY cycles after a test read.
//
// ---------------------------------------------------------------- RAS events
//   ev_valid pulses (at most one per cycle) when a read observed an error:
//   ev_ce (a bit was corrected), ev_ue (uncorrectable), ev_poison (the word
//   carries poison), ev_org (SFRAS_ORG_*), ev_addr, ev_syn {pe, s}, ev_idx.
//   A CE is reported only when the decoder actually flipped a bit back.
//   FIX reads report only an UE (their CE was reported by the preceding CHECK).
//
// ---------------------------------------------------------------- fault injection
//   FI_EN = 0 removes it.  fi_arm_i (pulse) arms one injection: mode
//   (SFRAS_FI_*), N-bit XOR mask, optional address match.  fi_fired_o pulses
//   when it fires; fi_armed_o stays high until the mask has been fully applied
//   (an arm while fi_armed_o = 1 is ignored).  Access control is NOT here: the RAS controller's
//   sfras_fi_ctrl decides whether fi_arm_i may ever be asserted.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_ecc_sram #(
  parameter int K              = 64,
  parameter int DEPTH          = 1024,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int BYTE_EN        = 1,
  parameter int WRITE_ACK      = 1,
  parameter int ID_W           = 1,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 3,
  parameter int DEC_PIPE       = 0,
  parameter int POISON_MODE    = `SFRAS_POISON_BIT,
  parameter int UE_ZERO        = 0,
  parameter int INV_SEL        = -1,
  parameter int INIT_ON_RESET  = 1,
  parameter int REINIT_AFTER_TEST = 1,
  parameter int TEST_EN        = 1,
  parameter int SCRUB_MAX_WAIT = 16,
  parameter int FI_EN          = 0,
  // ---- derived, do not override ----
  localparam int KC   = K + ((POISON_MODE == `SFRAS_POISON_BIT) ? 1 : 0),
  localparam int R    = $clog2(KC + $clog2(KC + 1) + 1),
  localparam int N    = KC + R + 1,
  localparam int IW   = $clog2(N),
  localparam int MW   = (BYTE_EN != 0 && (K % 8) == 0) ? K / 8 : 1,
  localparam int AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // functional request / response (sram_sp contract)
  input  wire logic            req_valid,
  output logic                 req_ready,
  input  wire logic            req_we,
  input  wire logic [AW-1:0]   req_addr,
  input  wire logic [K-1:0]    req_wdata,
  input  wire logic [MW-1:0]   req_wmask,
  input  wire logic [ID_W-1:0] req_id,
  output logic                 rsp_valid,
  input  wire logic            rsp_ready,
  output logic [K-1:0]         rsp_rdata,
  output logic                 rsp_err,
  output logic                 rsp_ce,
  output logic                 rsp_poison,
  output logic                 rsp_we,
  output logic [ID_W-1:0]      rsp_id,
  // scrub port
  input  wire logic            scr_req_valid,
  output logic                 scr_req_ready,
  input  wire logic [1:0]      scr_req_op,
  input  wire logic [AW-1:0]   scr_req_addr,
  output logic                 scr_rsp_valid,
  output logic [1:0]           scr_rsp_op,
  output logic [AW-1:0]        scr_rsp_addr,
  output logic                 scr_rsp_ce,
  output logic                 scr_rsp_ue,
  output logic                 scr_rsp_poison,
  output logic                 scr_rsp_wb,       // FIX: a corrected word was written back
  // initialisation
  input  wire logic            init_req_i,
  output logic                 init_busy_o,
  output logic                 init_done_o,
  // MBIST test port (raw N-bit stored words)
  input  wire logic            tst_active,
  output logic                 tst_ready,
  input  wire logic            tst_ce,
  input  wire logic            tst_we,
  input  wire logic [AW-1:0]   tst_addr,
  input  wire logic [N-1:0]    tst_wdata,
  output logic [N-1:0]         tst_rdata,
  // RAS events
  output logic                 ev_valid,
  output logic                 ev_ce,
  output logic                 ev_ue,
  output logic                 ev_poison,
  output logic [2:0]           ev_org,
  output logic [AW-1:0]        ev_addr,
  output logic [R:0]           ev_syn,
  output logic [IW-1:0]        ev_idx,
  // fault injection (gated by the RAS fault-injection controller)
  input  wire logic            fi_arm_i,
  input  wire logic [1:0]      fi_mode_i,
  input  wire logic [N-1:0]    fi_mask_i,
  input  wire logic            fi_addr_en_i,
  input  wire logic [AW-1:0]   fi_addr_i,
  output logic                 fi_armed_o,
  output logic                 fi_fired_o,
  output logic [AW-1:0]        fi_fired_addr_o,
  // status / performance
  output logic                 busy,
  output logic                 perf_lock_o,      // the port is locked (RMW / FIX / in-place injection) this cycle
  output logic                 perf_rmw_o        // a partial write was accepted (RMW started)
);
  `include "sfras_ecc_funcs.svh"

  localparam int INV = (INV_SEL < 0) ? sfras_ecc_default_inv(KC) : INV_SEL;
  localparam bit POW2 = (DEPTH == (1 << AW));
  localparam logic [AW:0] DEPTH_W = (AW+1)'(DEPTH);
  // POISON_MODE = SIG: two check bits inverted on top of the code = a fixed double-error signature
  localparam logic [R-1:0] SIG_C  = R'((1 << (R - 1)) | (1 << (R - 2)));
  localparam logic [N-1:0] SIG_CW = N'(SIG_C) << KC;
  localparam int CNT_W = $clog2(RSP_FIFO_DEPTH + 1) + 1;
  localparam int WAIT_W = $clog2(SCRUB_MAX_WAIT + 2) + 1;

  // ---------------------------------------------------------------- configuration checks
  if (READ_LATENCY < 1) begin : g_err_read_latency_lt_1
    `SFRAS_CFG_FATAL("sfras_ecc_sram: READ_LATENCY must be >= 1")
  end
  if (DEC_PIPE != 0 && DEC_PIPE != 1) begin : g_err_dec_pipe
    `SFRAS_CFG_FATAL("sfras_ecc_sram: DEC_PIPE must be 0 or 1")
  end
  if (POISON_MODE != `SFRAS_POISON_NONE && POISON_MODE != `SFRAS_POISON_SIG && POISON_MODE != `SFRAS_POISON_BIT) begin : g_err_poison_mode
    `SFRAS_CFG_FATAL("sfras_ecc_sram: unknown POISON_MODE")
  end
  if (RSP_FIFO_DEPTH < 1) begin : g_err_fifo
    `SFRAS_CFG_FATAL("sfras_ecc_sram: RSP_FIFO_DEPTH must be >= 1 (the ECC wrapper always buffers responses)")
  end
  if (R < 3) begin : g_err_k_too_small
    `SFRAS_CFG_FATAL("sfras_ecc_sram: K too small for the poison signature (needs R >= 3)")
  end
  if (DEPTH < 2) begin : g_err_depth
    `SFRAS_CFG_FATAL("sfras_ecc_sram: DEPTH must be >= 2")
  end
  if (WRITE_ACK != 0 && WRITE_ACK != 1) begin : g_err_write_ack
    `SFRAS_CFG_FATAL("sfras_ecc_sram: WRITE_ACK must be 0 or 1")
  end

  // ---------------------------------------------------------------- op kinds
  localparam logic [2:0] KD_RD = 3'd0, KD_WR = 3'd1, KD_RMW = 3'd2, KD_ERR = 3'd3,
                         KD_SCHK = 3'd4, KD_SFIX = 3'd5, KD_SVER = 3'd6, KD_FINJ = 3'd7;

  // pipeline tag (packed vector, no struct: Yosys 0.33 asserts when re-deriving a
  // module that declares a typedef, and Icarus 12 cannot select members of an
  // unpacked array of structs).  Layout, MSB first:
  //   {v, kind[2:0], rsp (produces a functional response), we, rinj (read-path
  //    injection applies), id[ID_W-1:0], addr[AW-1:0]}

  // ---------------------------------------------------------------- state
  logic            rst_live_q;
  logic            lock_q, wb_q;
  logic [AW-1:0]   wb_addr_q;
  logic [N-1:0]    wb_cw_q;
  logic            wb_scrub_q;                       // the pending write-back is a scrub FIX
  logic [K-1:0]    rmw_wdata_q;
  logic [MW-1:0]   rmw_wmask_q;
  logic            init_q, init_pend_q, init_done_q;
  logic [AW-1:0]   init_addr_q;
  logic            t_own_q;
  logic [WAIT_W-1:0] scr_wait_q;
  logic [CNT_W-1:0]  cnt_q;
  localparam int   TW = 7 + ID_W + AW;              // tag width; v is the MSB
  logic [TW-1:0]   tg [READ_LATENCY];               // tag pipeline (packed: Icarus 12 cannot select
                                                     // members of an unpacked array of structs)
  logic [TW-1:0]   dtag;                             // tag at the decode stage
  /* verilator lint_off UNUSEDSIGNAL */
  logic [N-1:0]    raw_q;                            // DEC_PIPE = 1 only
  logic [TW-1:0]   dtag_q;
  /* verilator lint_on UNUSEDSIGNAL */

  // fault injection state
  logic            fi_armed_q;
  logic [1:0]      fi_mode_q;
  logic [N-1:0]    fi_mask_q;
  logic            fi_aen_q;
  logic [AW-1:0]   fi_addr_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rst_live_q <= 1'b0;
    else        rst_live_q <= 1'b1;
  end

  // ---------------------------------------------------------------- array
  logic          a_ce, a_we;
  logic [AW-1:0] a_addr;
  logic [N-1:0]  a_wdata, a_rdata;

  sram_backend_1rw #(
    .DATA_WIDTH(N), .DEPTH(DEPTH), .MASK_WIDTH(1), .READ_LATENCY(READ_LATENCY),
    .BACKEND(BACKEND), .MACRO(MACRO)
  ) u_array (
    .clk, .ce(a_ce), .we(a_we), .wmask(1'b1), .addr(a_addr), .wdata(a_wdata), .rdata(a_rdata)
  );

  // ---------------------------------------------------------------- encoders
  // write path: functional full write
  logic [N-1:0] enc_w_cw, enc_m_cw, enc_init_cw;
  logic [KC-1:0] enc_w_in, enc_m_in;
  if (KC > K) begin : g_pbit_w
    assign enc_w_in = {1'b0, req_wdata};
  end else begin : g_nopbit_w
    assign enc_w_in = req_wdata;
  end
  sfras_secded_enc #(.K(KC), .INV(INV)) u_enc_w    (.data_i(enc_w_in), .cw_o(enc_w_cw));
  sfras_secded_enc #(.K(KC), .INV(INV)) u_enc_m    (.data_i(enc_m_in), .cw_o(enc_m_cw));
  sfras_secded_enc #(.K(KC), .INV(INV)) u_enc_init (.data_i('0),       .cw_o(enc_init_cw));

  // ---------------------------------------------------------------- pipeline / decode stage
  logic        any_tag;
  always_comb begin
    any_tag = 1'b0;
    for (int i = 0; i < READ_LATENCY; i++) any_tag = any_tag | tg[i][TW-1];
  end

  logic [N-1:0] dec_raw;
  if (DEC_PIPE != 0) begin : g_decpipe
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) dtag_q <= '0;
      else        dtag_q <= tg[READ_LATENCY-1];
    end
    always_ff @(posedge clk) raw_q <= a_rdata;
    assign dtag    = dtag_q;
    assign dec_raw = raw_q;
  end else begin : g_nodecpipe
    assign dtag    = tg[READ_LATENCY-1];
    assign dec_raw = a_rdata;
    assign dtag_q = '0;
    assign raw_q  = '0;
  end

  wire            dt_v    = dtag[TW-1];
  wire [2:0]      dt_kind = dtag[TW-2 -: 3];
  wire            dt_rsp  = dtag[AW+ID_W+2];
  wire            dt_we   = dtag[AW+ID_W+1];
  wire            dt_rinj = dtag[AW+ID_W];
  wire [ID_W-1:0] dt_id   = dtag[AW +: ID_W];
  wire [AW-1:0]   dt_addr = dtag[0 +: AW];

  wire dec_isrd = dt_v && (dt_kind == KD_RD || dt_kind == KD_RMW || dt_kind == KD_SCHK ||
                             dt_kind == KD_SFIX || dt_kind == KD_SVER || dt_kind == KD_FINJ);
  wire [N-1:0] dec_in = dec_raw ^ ((FI_EN != 0 && dt_rinj) ? fi_mask_q : '0);

  logic [KC-1:0] d_data;
  logic [N-1:0]  d_cwc;
  logic          d_ce, d_ue;
  /* verilator lint_off UNUSEDSIGNAL */
  logic          d_none, d_inval, d_cedata;          // assertions / debug only
  /* verilator lint_on UNUSEDSIGNAL */
  logic [IW-1:0] d_idx;
  logic [R:0]    d_syn;
  sfras_secded_dec #(.K(KC), .INV(INV)) u_dec (
    .cw_i(dec_in), .data_o(d_data), .cw_corr_o(d_cwc), .none_o(d_none), .ce_o(d_ce), .ue_o(d_ue),
    .ue_inval_o(d_inval), .ce_data_o(d_cedata), .err_idx_o(d_idx), .syn_o(d_syn)
  );

  // poison flag of the word as read
  logic d_pois;
  always_comb begin
    if (POISON_MODE == `SFRAS_POISON_BIT)      d_pois = !d_ue && d_data[KC-1];
    else if (POISON_MODE == `SFRAS_POISON_SIG) d_pois = d_ue && (d_syn == {1'b0, SIG_C});
    else                                       d_pois = 1'b0;
  end
  wire d_bad = d_ue || d_pois;                       // the data bits are not valid

  // RMW merge (old bytes corrected; the new bytes from the hold registers)
  logic [K-1:0] merged;
  always_comb begin
    for (int l = 0; l < MW; l++)
      merged[l*(K/MW) +: (K/MW)] = rmw_wmask_q[l] ? rmw_wdata_q[l*(K/MW) +: (K/MW)] : d_data[l*(K/MW) +: (K/MW)];
  end
  if (KC > K) begin : g_pbit_m
    assign enc_m_in = {d_bad, merged};               // BIT mode: the merged word inherits poison
  end else begin : g_nopbit_m
    assign enc_m_in = merged;
  end

  // ---------------------------------------------------------------- decode-stage actions
  logic         wb_set;                              // a write-back is generated this cycle
  logic [N-1:0] wb_cw_d;
  logic         push;                                // functional response pushed this cycle
  logic [K-1:0] push_rdata;
  logic         push_err, push_ce, push_pois;
  always_comb begin
    wb_set = 1'b0; wb_cw_d = '0;
    push = 1'b0; push_rdata = '0; push_err = 1'b0; push_ce = 1'b0; push_pois = 1'b0;
    if (dt_v) begin
      case (dt_kind)
        KD_RD: begin
          push       = dt_rsp;
          push_rdata = (d_bad && UE_ZERO != 0) ? '0 : d_data[K-1:0];
          push_err   = d_bad;
          push_ce    = d_ce;
          push_pois  = d_bad;
        end
        KD_WR: begin
          push = dt_rsp;
        end
        KD_ERR: begin
          push = dt_rsp; push_err = 1'b1;
        end
        KD_RMW: begin
          push     = dt_rsp;
          push_ce  = d_ce;
          push_err = d_bad;
          if (!d_bad) begin
            wb_set = 1'b1; wb_cw_d = enc_m_cw;
          end else if (POISON_MODE == `SFRAS_POISON_BIT) begin
            wb_set = 1'b1; wb_cw_d = enc_m_cw;         // poison flag = 1 inside the code
          end else if (POISON_MODE == `SFRAS_POISON_SIG) begin
            wb_set = 1'b1; wb_cw_d = enc_m_cw ^ SIG_CW;
          end
          // POISON_NONE: no write-back; the word stays uncorrectable
        end
        KD_SFIX: begin
          if (d_ce) begin wb_set = 1'b1; wb_cw_d = d_cwc; end
        end
        KD_FINJ: begin
          wb_set = 1'b1; wb_cw_d = dec_raw ^ fi_mask_q;  // raw stored word, NOT corrected
        end
        default: ;
      endcase
    end
  end

  // ---------------------------------------------------------------- issue arbitration
  wire t_req   = (TEST_EN != 0) && tst_active;
  wire arr_busy = any_tag || (DEC_PIPE != 0 && dtag_q[TW-1]) || lock_q || wb_q || init_q;
  wire t_on    = t_req && t_own_q;
  wire can_op  = rst_live_q && !t_req && !init_q && !init_pend_q && !lock_q && !wb_q;
  wire credit  = (cnt_q < CNT_W'(RSP_FIFO_DEPTH));
  wire fi_inpl = (FI_EN != 0) && fi_armed_q && (fi_mode_q == `SFRAS_FI_INPLACE);
  wire scr_prio = (scr_wait_q >= WAIT_W'(SCRUB_MAX_WAIT));

  assign req_ready     = can_op && credit && !fi_inpl && !(scr_req_valid && scr_prio);
  assign scr_req_ready = can_op && !fi_inpl && (scr_prio || !req_valid || !credit);
  wire f_go   = req_valid && req_ready;
  wire s_go   = scr_req_valid && scr_req_ready;
  wire fi_go  = fi_inpl && can_op;                  // in-place injection takes the slot

  // functional request decode
  wire addr_ok = POW2 ? 1'b1 : ({1'b0, req_addr} < DEPTH_W);
  wire m_full  = (req_wmask == '1);
  wire m_zero  = (req_wmask == '0);
  logic [2:0] f_kind;
  logic       f_rsp, f_arr, f_awe, f_lock;
  always_comb begin
    if (!addr_ok)                       f_kind = KD_ERR;
    else if (!req_we)                   f_kind = KD_RD;
    else if (m_full || m_zero)          f_kind = KD_WR;
    else if (BYTE_EN != 0 && MW > 1)    f_kind = KD_RMW;
    else                                f_kind = KD_ERR;   // partial strobe without byte support
    f_rsp  = (f_kind == KD_RD) || (f_kind == KD_ERR) || (WRITE_ACK != 0);
    f_arr  = (f_kind == KD_RD) || (f_kind == KD_RMW) || (f_kind == KD_WR && !m_zero);
    f_awe  = (f_kind == KD_WR);
    f_lock = (f_kind == KD_RMW);
  end

  // fault injection: does it apply to this functional access?
  wire fi_amatch_f = !fi_aen_q || (fi_addr_q == req_addr);
  wire fi_w_now = (FI_EN != 0) && fi_armed_q && fi_mode_q == `SFRAS_FI_WRITE && f_go && f_kind == KD_WR && !m_zero && fi_amatch_f;
  wire fi_r_now = (FI_EN != 0) && fi_armed_q && fi_mode_q == `SFRAS_FI_READ  && f_go && f_kind == KD_RD && fi_amatch_f;
  // write-path injection into an RMW write-back: applied when the RMW was accepted with a match
  logic fi_rmw_q;
  wire fi_rmw_now = (FI_EN != 0) && fi_armed_q && fi_mode_q == `SFRAS_FI_WRITE && f_go && f_kind == KD_RMW && fi_amatch_f;
  wire fi_swb_now = (FI_EN != 0) && fi_armed_q && fi_mode_q == `SFRAS_FI_SCRUB_WB && wb_q && wb_scrub_q &&
                    (!fi_aen_q || fi_addr_q == wb_addr_q);
  wire fi_wbm_now = (FI_EN != 0) && wb_q && fi_rmw_q;

  // array port mux (priority: write-back, test, init, in-place FI, scrub, functional)
  logic   s_lock;
  logic [2:0] s_kind;
  always_comb begin
    case (scr_req_op)
      `SFRAS_SCR_FIX:    s_kind = KD_SFIX;
      `SFRAS_SCR_VERIFY: s_kind = KD_SVER;
      default:           s_kind = KD_SCHK;
    endcase
    s_lock = (s_kind == KD_SFIX);
  end

  always_comb begin
    a_ce = 1'b0; a_we = 1'b0; a_addr = '0; a_wdata = '0;
    if (wb_q) begin
      a_ce = 1'b1; a_we = 1'b1; a_addr = wb_addr_q;
      a_wdata = wb_cw_q ^ ((fi_swb_now || fi_wbm_now) ? fi_mask_q : '0);
    end else if (t_on) begin
      a_ce = tst_ce && (POW2 || ({1'b0, tst_addr} < DEPTH_W)); a_we = tst_we; a_addr = tst_addr; a_wdata = tst_wdata;
    end else if (init_q) begin
      a_ce = 1'b1; a_we = 1'b1; a_addr = init_addr_q; a_wdata = enc_init_cw;
    end else if (fi_go) begin
      a_ce = 1'b1; a_we = 1'b0; a_addr = fi_addr_q;
    end else if (s_go) begin
      a_ce = 1'b1; a_we = 1'b0; a_addr = scr_req_addr;
    end else if (f_go && f_arr) begin
      a_ce = 1'b1; a_we = f_awe; a_addr = req_addr;
      a_wdata = enc_w_cw ^ (fi_w_now ? fi_mask_q : '0);
    end
  end
  assign tst_rdata = (TEST_EN != 0) ? a_rdata : '0;
  assign tst_ready = t_on;

  // tag entering the pipeline
  logic            ti_v, ti_rsp, ti_we, ti_rinj;
  logic [2:0]      ti_kind;
  logic [ID_W-1:0] ti_id;
  logic [AW-1:0]   ti_addr;
  always_comb begin
    ti_v = 1'b0; ti_kind = KD_RD; ti_rsp = 1'b0; ti_we = 1'b0; ti_rinj = 1'b0; ti_id = '0; ti_addr = '0;
    if (fi_go) begin
      ti_v = 1'b1; ti_kind = KD_FINJ; ti_addr = fi_addr_q;
    end else if (s_go) begin
      ti_v = 1'b1; ti_kind = s_kind; ti_addr = scr_req_addr;
    end else if (f_go && (f_rsp || f_kind == KD_RMW)) begin
      ti_v = 1'b1; ti_kind = f_kind; ti_rsp = f_rsp; ti_we = req_we;
      ti_rinj = fi_r_now; ti_id = req_id; ti_addr = req_addr;
    end
  end
  wire [TW-1:0] tg_in = {ti_v, ti_kind, ti_rsp, ti_we, ti_rinj, ti_id, ti_addr};

  // ---------------------------------------------------------------- response FIFO (credit based)
  localparam int FW = K + 4 + ID_W;
  localparam int PW = (RSP_FIFO_DEPTH > 1) ? $clog2(RSP_FIFO_DEPTH) : 1;
  logic [FW-1:0] fifo [RSP_FIFO_DEPTH];
  logic [PW-1:0] wp_q, rp_q;
  logic [CNT_W-1:0] occ_q;
  wire pop = rsp_valid && rsp_ready;
  assign rsp_valid = (occ_q != '0);
  assign {rsp_rdata, rsp_err, rsp_ce, rsp_poison, rsp_we, rsp_id} = fifo[rp_q];

  function automatic logic [PW-1:0] ptr_inc(input logic [PW-1:0] p);
    ptr_inc = (p == PW'(RSP_FIFO_DEPTH - 1)) ? '0 : p + 1'b1;
  endfunction

  always_ff @(posedge clk) begin
    if (push) fifo[wp_q] <= {push_rdata, push_err, push_ce, push_pois, dt_we, dt_id};
  end

  // ---------------------------------------------------------------- sequential control
  wire issue_rsp = f_go && f_rsp;
  wire init_start = init_req_i || (REINIT_AFTER_TEST != 0 && t_own_q && !t_req);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < READ_LATENCY; i++) tg[i] <= '0;
      lock_q <= 1'b0; wb_q <= 1'b0; wb_addr_q <= '0; wb_cw_q <= '0; wb_scrub_q <= 1'b0;
      rmw_wdata_q <= '0; rmw_wmask_q <= '0;
      init_q <= 1'b0; init_pend_q <= (INIT_ON_RESET != 0); init_done_q <= 1'b0; init_addr_q <= '0;
      t_own_q <= 1'b0; scr_wait_q <= '0; cnt_q <= '0;
      wp_q <= '0; rp_q <= '0; occ_q <= '0;
      fi_rmw_q <= 1'b0;
    end else begin
      // tag pipeline
      tg[0] <= tg_in;
      for (int i = 1; i < READ_LATENCY; i++) tg[i] <= tg[i-1];
      // locked operations
      if (f_go && f_lock) begin
        lock_q <= 1'b1; rmw_wdata_q <= req_wdata; rmw_wmask_q <= req_wmask;
      end
      if (s_go && s_lock) lock_q <= 1'b1;
      if (fi_go)          lock_q <= 1'b1;
      if (f_go && f_lock) fi_rmw_q <= fi_rmw_now;
      // decode stage: write-back or release
      if (dt_v && (dt_kind == KD_RMW || dt_kind == KD_SFIX || dt_kind == KD_FINJ)) begin
        if (wb_set) begin
          wb_q <= 1'b1; wb_addr_q <= dt_addr; wb_cw_q <= wb_cw_d; wb_scrub_q <= (dt_kind == KD_SFIX);
        end else begin
          lock_q <= 1'b0;
          fi_rmw_q <= 1'b0;
        end
      end
      if (wb_q) begin
        wb_q <= 1'b0; lock_q <= 1'b0; wb_scrub_q <= 1'b0; fi_rmw_q <= 1'b0;
      end
      // test ownership
      if (!t_req)                 t_own_q <= 1'b0;
      else if (!arr_busy)         t_own_q <= 1'b1;
      // initialisation
      if (init_start) begin
        init_pend_q <= 1'b1; init_done_q <= 1'b0;
      end
      if (init_pend_q && !init_q && !arr_busy && !t_req) begin
        init_pend_q <= 1'b0; init_q <= 1'b1; init_addr_q <= '0;
      end
      if (init_q) begin
        if (init_addr_q == AW'(DEPTH - 1)) begin
          init_q <= 1'b0; init_done_q <= !init_start && !init_pend_q;
        end
        init_addr_q <= init_addr_q + 1'b1;
      end
      // scrub starvation guard
      if (s_go || !scr_req_valid) scr_wait_q <= '0;
      else if (!scr_prio)         scr_wait_q <= scr_wait_q + 1'b1;
      // credits and FIFO
      cnt_q <= cnt_q + CNT_W'(issue_rsp) - CNT_W'(pop);
      if (push) wp_q <= ptr_inc(wp_q);
      if (pop)  rp_q <= ptr_inc(rp_q);
      occ_q <= occ_q + CNT_W'(push) - CNT_W'(pop);
    end
  end

  assign init_busy_o = init_q || init_pend_q;
  assign init_done_o = init_done_q;
  assign busy        = arr_busy || init_pend_q || (cnt_q != '0) || (occ_q != '0);
  assign perf_lock_o = lock_q;
  assign perf_rmw_o  = f_go && f_lock;

  // ---------------------------------------------------------------- fault injection state
  // fi_use_q: a fired injection whose mask is applied LATER (read path at the decode
  // stage, in-place / RMW write-back after the locked read).  A new arm is refused
  // until that use is complete, so fi_mask_q cannot change under a pending use
  // (bug found by tb_ecc_sram at READ_LATENCY >= 2).  fi_armed_o covers both.
  logic fi_use_q;
  /* verilator lint_off UNUSEDSIGNAL */
  logic fi_use_lk_q;                                 // FI_EN = 1 only
  /* verilator lint_on UNUSEDSIGNAL */
  if (FI_EN != 0) begin : g_fi
    wire fired = fi_w_now || fi_r_now || fi_rmw_now || fi_swb_now || fi_go;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        fi_armed_q <= 1'b0; fi_mode_q <= '0; fi_mask_q <= '0; fi_aen_q <= 1'b0; fi_addr_q <= '0;
        fi_use_q <= 1'b0; fi_use_lk_q <= 1'b0;
      end else begin
        if (fi_arm_i && !fi_armed_q && !fi_use_q) begin
          fi_armed_q <= 1'b1; fi_mode_q <= fi_mode_i; fi_mask_q <= fi_mask_i;
          fi_aen_q <= fi_addr_en_i; fi_addr_q <= fi_addr_i;
        end else if (fired) begin
          fi_armed_q <= 1'b0;
        end
        if (fi_r_now) begin
          fi_use_q <= 1'b1; fi_use_lk_q <= 1'b0;
        end else if (fi_go || fi_rmw_now) begin
          fi_use_q <= 1'b1; fi_use_lk_q <= 1'b1;
        end else if (fi_use_q && ((!fi_use_lk_q && dt_v && dt_rinj) || (fi_use_lk_q && !lock_q))) begin
          fi_use_q <= 1'b0; fi_use_lk_q <= 1'b0;
        end
      end
    end
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        fi_fired_o <= 1'b0; fi_fired_addr_o <= '0;
      end else begin
        fi_fired_o <= fired;
        if (fired) fi_fired_addr_o <= fi_go ? fi_addr_q : (fi_swb_now ? wb_addr_q : req_addr);
      end
    end
  end else begin : g_no_fi
    always_comb begin
      fi_armed_q = 1'b0; fi_mode_q = '0; fi_mask_q = '0; fi_aen_q = 1'b0; fi_addr_q = '0;
      fi_fired_o = 1'b0; fi_fired_addr_o = '0; fi_use_q = 1'b0; fi_use_lk_q = 1'b0;
    end
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_fi = fi_arm_i ^ (^fi_mode_i) ^ (^fi_mask_i) ^ fi_addr_en_i ^ (^fi_addr_i);
    /* verilator lint_on UNUSEDSIGNAL */
  end
  assign fi_armed_o = fi_armed_q || fi_use_q;

  // ---------------------------------------------------------------- events and scrub responses
  always_comb begin
    ev_valid = 1'b0; ev_ce = d_ce; ev_ue = d_ue; ev_poison = d_pois; ev_org = `SFRAS_ORG_READ;
    ev_addr = dt_addr; ev_syn = d_syn; ev_idx = d_idx;
    case (dt_kind)
      KD_RMW:  ev_org = `SFRAS_ORG_RMW;
      KD_SCHK: ev_org = `SFRAS_ORG_SCRUB;
      KD_SFIX: ev_org = `SFRAS_ORG_SCRUB_FIX;
      KD_SVER: ev_org = `SFRAS_ORG_SCRUB_VERIFY;
      KD_FINJ: ev_org = `SFRAS_ORG_FI;
      default: ev_org = `SFRAS_ORG_READ;
    endcase
    if (dec_isrd && dt_kind != KD_FINJ) begin
      if (dt_kind == KD_SFIX) ev_valid = d_ue;
      else                      ev_valid = d_ce || d_ue || d_pois;
    end
  end

  assign scr_rsp_valid  = dt_v && (dt_kind == KD_SCHK || dt_kind == KD_SFIX || dt_kind == KD_SVER);
  assign scr_rsp_op     = (dt_kind == KD_SFIX) ? `SFRAS_SCR_FIX : (dt_kind == KD_SVER) ? `SFRAS_SCR_VERIFY : `SFRAS_SCR_CHECK;
  assign scr_rsp_addr   = dt_addr;
  assign scr_rsp_ce     = d_ce;
  assign scr_rsp_ue     = d_ue;
  assign scr_rsp_poison = d_pois;
  assign scr_rsp_wb     = (dt_kind == KD_SFIX) && d_ce;

  // ---------------------------------------------------------------- assertions
`ifdef SFRAS_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n && rst_live_q) begin
      assert (!(push && occ_q == CNT_W'(RSP_FIFO_DEPTH) && !pop)) else $error("%m: response FIFO overflow");
      assert (!(f_go && s_go)) else $error("%m: functional and scrub issued together");
      assert (!(wb_q && (f_go || s_go || fi_go))) else $error("%m: issue during write-back");
      assert (!(lock_q && (f_go || s_go || fi_go))) else $error("%m: issue while locked");
      assert (!(t_on && (f_go || s_go || fi_go || init_q || wb_q))) else $error("%m: test port shared");
      assert (!(TEST_EN != 0 && tst_ce && !t_on)) else $error("%m: tst_ce while the test port is not granted");
      assert (!(push && !dt_v)) else $error("%m: push without tag");
      if (dt_v && dec_isrd) assert ($onehot({d_none, d_ce, d_ue})) else $error("%m: decoder class not one-hot");
    end
  end
`endif

endmodule

`default_nettype wire
