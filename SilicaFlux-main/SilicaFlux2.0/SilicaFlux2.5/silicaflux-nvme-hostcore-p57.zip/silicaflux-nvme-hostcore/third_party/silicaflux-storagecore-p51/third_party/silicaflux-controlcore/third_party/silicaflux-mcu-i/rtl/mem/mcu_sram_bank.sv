// =============================================================================
// SilicaFlux MCU-I :: mcu_sram_bank -- SFB2 slave on one SilicaFlux SRAM
// Wrapper Library single-port SRAM (third_party/silicaflux-sramlib sram_sp,
// vendored unmodified), with optional per-byte odd parity.
//
// Derived from third_party/silicaflux-datafabric rtl/mem/sfb_sram_slave.sv
// (same request/response mapping, WRITE_ACK = 1 so a write is acknowledged
// only after the array was written).  Additions for MCU-I:
//   PARITY = 1: the array is DATA 36 bits wide = 4 lanes of {p, byte}; a write
//     stores p = ~^byte (odd parity: an all-zero word is NOT valid, so a dead
//     or unwritten word is detected); `inject` inverts p of the written lanes
//     (test only).  A read with chk_en = 1 and any lane with even parity is
//     answered with rsp_error = 1 (rdata = 0, SFB2 rule R8) and reported on
//     par_evt/par_addr for the fault log.  Parity is checked on all four
//     lanes of every read because every SFB2 read returns the full word.
//   MBIST port: sfv_mbist-compatible raw array port (tst_*): all lanes, data
//     bits only; with PARITY = 1 parity bits are written as {4{~^byte}} and
//     not compared by MBIST (coverage gap, docs/DFT.md).
// Reset: control state only; the array is never reset (SRAM contents are
// undefined after power-up: firmware must initialise SRAM before enabling
// the parity check -- the boot ROM scrubs it).
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module mcu_sram_bank #(
  parameter int DEPTH        = 4096,          // words
  parameter int PARITY       = 0,
  parameter int READ_LATENCY = 1,
  parameter int BACKEND      = `SRAM_BACKEND_GENERIC,
  parameter int MACRO        = 0,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int MW          = (PARITY != 0) ? 36 : 32
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // SFB2 slave
  input  wire logic          req_valid,
  output logic               req_ready,
  input  wire logic          req_write,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]   req_addr,        // upper bits decoded by the crossbar
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0]   req_wdata,
  input  wire logic [3:0]    req_wstrb,
  output logic               rsp_valid,
  input  wire logic          rsp_ready,
  output logic [31:0]        rsp_rdata,
  output logic               rsp_error,
  // parity control / events
  input  wire logic          chk_en,
  input  wire logic          inject,
  output logic               par_evt,         // a read response with a parity error was accepted
  output logic [31:0]        par_addr,
  // MBIST raw port (sfv_mbist contract, 1-cycle read latency)
  input  wire logic          tst_active,
  input  wire logic          tst_ce,
  input  wire logic          tst_we,
  input  wire logic [AW-1:0] tst_addr,
  input  wire logic [31:0]   tst_wdata,
  output logic [31:0]        tst_rdata
);
  // ------------------------------------------------------------ data packing
  function automatic logic [MW-1:0] pack(input logic [31:0] d, input logic inv);
    pack = '0;
    if (PARITY != 0) begin
      for (int l = 0; l < 4; l++) pack[l*9 +: 9] = {(~^d[l*8 +: 8]) ^ inv, d[l*8 +: 8]};
    end else begin
      pack[31:0] = d;
    end
  endfunction
  function automatic logic [31:0] unpack(input logic [MW-1:0] w);
    unpack = w[31:0];
    if (PARITY != 0) begin
      for (int l = 0; l < 4; l++) unpack[l*8 +: 8] = w[l*9 +: 8];
    end
  endfunction
  function automatic logic par_bad(input logic [MW-1:0] w);
    par_bad = 1'b0;
    if (PARITY != 0)
      for (int l = 0; l < 4; l++) par_bad = par_bad | !(^w[l*9 +: 9]);   // odd parity expected
  endfunction

  logic [MW-1:0] m_rdata, m_tst_rdata;
  logic          m_rsp_err, m_rsp_we, busy_unused;
  logic [0:0]    rsp_id_unused;

  sram_sp #(
    .DATA_WIDTH(MW), .DEPTH(DEPTH), .MASK_WIDTH(4), .READ_LATENCY(READ_LATENCY),
    .BACKEND(BACKEND), .MACRO(MACRO), .RSP_FIFO_DEPTH(READ_LATENCY + 1), .WRITE_ACK(1),
    .ID_WIDTH(1), .TEST_EN(1)
  ) u_sram (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_we(req_write), .req_addr(req_addr[2 +: AW]),
    .req_wdata(pack(req_wdata, inject)), .req_wmask(req_wstrb), .req_id(1'b0),
    .rsp_valid, .rsp_ready, .rsp_rdata(m_rdata), .rsp_err(m_rsp_err), .rsp_we(m_rsp_we),
    .rsp_id(rsp_id_unused),
    .tst_active, .tst_ce, .tst_we, .tst_addr, .tst_wdata(pack(tst_wdata, 1'b0)),
    .tst_rdata(m_tst_rdata), .busy(busy_unused)
  );

  // address of the outstanding read (the crossbar allows one transaction per
  // slave port, so one register is exact)
  logic [31:0] raddr_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                                    raddr_q <= '0;
    else if (req_valid && req_ready && !req_write) raddr_q <= req_addr;
  end

  wire perr     = (PARITY != 0) && chk_en && rsp_valid && !m_rsp_we && par_bad(m_rdata);
  assign rsp_error = m_rsp_err || perr;
  assign rsp_rdata = rsp_error ? 32'd0 : unpack(m_rdata);
  assign par_evt   = perr && rsp_ready;
  assign par_addr  = raddr_q;
  assign tst_rdata = unpack(m_tst_rdata);
endmodule

`default_nettype wire
