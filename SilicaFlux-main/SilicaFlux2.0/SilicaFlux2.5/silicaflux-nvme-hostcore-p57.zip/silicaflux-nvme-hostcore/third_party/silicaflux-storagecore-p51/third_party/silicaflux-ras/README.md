# SilicaFlux RAS — Project 26: error correction, fault monitoring and recovery

Aureom.AI / SilicaFlux-HPC. Primary RTL: **`rtl/silicaflux_ras.sv`**.

RASCore detects, classifies and reports hardware faults, corrects single-bit memory errors with a configurable
SECDED code, and keeps known-corrupted data from being treated as valid results: uncorrectable data is tagged
(poison) or rejected (error response) at every boundary, and every fault becomes a timestamped, counted event for
the ControlCore and the host.

## Definition of done — status

| Criterion | Status | Evidence |
|---|---|---|
| Injected single-bit errors are corrected | **met** for every stored-bit position (data, check, parity, poison bit), every configured width | `tb_secded` (all positions; full input space for K = 8, 11), `tb_ecc_sram` P3, `tb_ras_system` T4 |
| Supported double-bit errors are detected | **met** for every bit pair enumerated (all pairs for 4–8 data words per K; all pairs through the memory for N ≤ 40) | `tb_secded`, `tb_ecc_sram` P4, `tb_ras_system` T5 |
| Uncorrectable errors are reported, not silently propagated | **met at the protected boundaries**: error response + poison flag + event; DMA aborts, destination untouched past the fault | `tb_ecc_sram` P4/P6/P8, `tb_ras_system` T5/T6 |
| …and where it is **not** met | ≥ 3-bit errors can miscorrect (exact rates in `docs/09`); unprotected storage and SFB2 segments without parity remain single points of failure (demonstrated in T10) | `docs/09` §2, §6 |

Regression: **39 runs pass** (Icarus 12 + Verilator 5.020 with assertions + firmware/RTL co-simulation);
**22/22 mutants killed**; all 18 synthesizable blocks synthesize in Yosys 0.33; lint clean in 24 configurations.
See `reports/`.

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_ras.sv` (RASCore top: register page, event aggregation, scrub engines, watchdog, thermal, FI control) | `rtl/silicaflux_ras.sv` |
| ECC encoder / decoder / classifier | `rtl/sfras_secded_enc.sv`, `rtl/sfras_secded_dec.sv`, `rtl/sfras_ecc_funcs.svh` |
| ECC SRAM wrapper (RMW, init, MBIST port, poison, scrub port, injection) | `rtl/sfras_ecc_sram.sv`; SFB2 slave `rtl/sfras_sfb_ecc_slave.sv` |
| Scrub engine (optional, per memory) | `rtl/sfras_scrub.sv` |
| RAS event controller | `rtl/sfras_event_ctrl.sv` |
| Event sources | `rtl/sfras_watchdog.sv`, `rtl/sfras_thermal_mon.sv`, `rtl/sfras_timeout_mon.sv`, `rtl/sfras_dma_mon.sv`, `rtl/sfras_bus_parity.sv` |
| Fault-injection framework | `rtl/sfras_fi_ctrl.sv` (access control), datapaths in the wrapper, `rtl/sfras_sfb_fault_inj.sv`, parity-link injection |
| Tests | `tb/tb_secded.sv`, `tb/tb_ecc_sram.sv`, `tb/tb_event_ctrl.sv`, `tb/tb_ras_system.sv`, `tb/sw_cosim.cpp`, `model/` (independent reference), `scripts/run_regress.py`, `scripts/run_mutation.py` |
| Firmware register API | `sw/silicaflux_ras_regs.h` (generated), `sw/silicaflux_ras.h`, `sw/silicaflux_ras.c`, `docs/10_firmware_api.md`, `docs/08_register_map.md` |
| RAS coverage report | `docs/09_ras_coverage_report.md` (+ `reports/ras_coverage.json`) |

## Documents

| | |
|---|---|
| `docs/00_audit.md` | audit of the existing RTL: what was protected, what was not (SECDED was reserved for this project) |
| `docs/01_ecc_architecture.md` | code, bit ordering, check-bit placement, syndrome, classification, invalid syndromes |
| `docs/02_memory_integration.md` | wrapper, partial writes / RMW, initialisation, MBIST, latency, integration points |
| `docs/03_scrubbing.md` | scrub engine, arbitration, measured interference, UE policy |
| `docs/04_event_architecture.md` | fault classes, event interface, severity, aggregation, interrupts, ControlCore / host exposure |
| `docs/05_poison_containment.md` | poison modes, containment boundaries, where containment does not hold |
| `docs/06_fault_injection.md` | injection mechanisms and the production lock-down |
| `docs/07_verification.md` | testbenches, requirement → test map, mutation evidence, defects found |
| `docs/08_register_map.md` | generated register map |
| `docs/09_ras_coverage_report.md` | capacity, coverage for the implemented fault model, injection results, recovery, SPOFs |
| `docs/10_firmware_api.md` | driver usage |

## Running

Requirements: Icarus Verilog 12, Verilator 5.020, Yosys 0.33, Python 3.10+, GCC (the versions the existing
SilicaFlux repositories target).

```bash
make all          # regs, lint, regression (both simulators + co-simulation), synthesis, mutation, report
make test         # regression only  ->  reports/regression.md
make cosim        # firmware driver against the Verilated RTL
```

## Integration summary

* **Into the fabric**: `sfras_sfb_ecc_slave` replaces DataFabric's `sfb_sram_slave` (verified with the real
  DataFabric DMA, vendored unmodified). `sfras_dma_mon` / `sfras_timeout_mon` observe any SFB2 master port;
  `sfras_sfb_par_link` protects a chosen SFB2 segment.
* **Into ControlCore**: map the `silicaflux_ras` page like `CC_PG_RAS`; connect `irq_ctrl_o` to the INTC and
  `cc_warn_o` / `cc_fatal_o` to the existing `cc_ras` `EXT_WARN` / `EXT_FATAL` inputs; `fi_allow_i` from TestCore test
  mode / the secure monitor; `contain_o` to the accelerator isolation.
* **Into the memory core, HPC scratchpad, ControlCore SRAMs**: the encode/decode hook points those repositories
  reserved for Project 26 are mapped in `docs/02` §6 — specified here, **not yet applied** to those repositories.

## Third-party (vendored, unmodified)

`third_party/silicaflux-sramlib/` (raw 1RW backends, Project 01) and `third_party/silicaflux-datafabric/rtl/dma/`
(DMA, used by the system testbench), with `SHA256SUMS`. Taken from the archives in `Aureom.AI/SilicaFlux-main/`.

## What this project does not claim

No FIT rate, soft-error rate or field reliability: that needs device, process, package and environment data. No
timing, area or power numbers beyond technology-neutral cell counts. No formal proofs. See `docs/07` §5 and
`docs/09` §6.
