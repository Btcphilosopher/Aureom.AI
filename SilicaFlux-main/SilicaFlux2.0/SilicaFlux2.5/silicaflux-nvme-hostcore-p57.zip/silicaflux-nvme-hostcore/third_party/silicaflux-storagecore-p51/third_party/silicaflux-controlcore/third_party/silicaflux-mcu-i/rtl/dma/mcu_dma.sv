// =============================================================================
// SilicaFlux MCU-I :: mcu_dma -- single-channel DMA with peripheral pacing
//
// DERIVED FROM third_party/silicaflux-datafabric rtl/dma/dma_transfer_engine.sv
// + dma_control_regs.sv + dma_validate.sv (state machine, one-transaction-in-
// flight discipline, validation-before-access, error/abort semantics and the
// register offsets 0x00..0x2C are kept).  Added for MCU-I (closes DataFabric
// issue DF-06 for the reviewed cases):
//   * MODE.SRC_FIXED / DST_FIXED: non-incrementing side (peripheral data
//     register);
//   * MODE.BYTE: 8-bit elements (byte lane extraction/replication; the fixed
//     side is accessed as a full 32-bit register, value in bits [7:0]);
//   * MODE.DREQ_SEL: before every element the engine waits for the selected
//     request line (peripheral data-valid / space-available level);
//   * peripheral rule (hardware access restriction): an address inside the
//     peripheral window is legal only on a FIXED side with DREQ_SEL != 0, so
//     the DMA can never sweep registers with side effects (an incrementing
//     side is checked over its whole range);
//   * word mode requires LENGTH to be a multiple of 4 (no tail strobes).
// Unchanged guarantees (DataFabric): no bus access before validation passes;
// exactly one SFB2 transaction in flight; payload stable until accepted; a
// write only with data of an error-free read of the same element; DONE only
// after the last write response; bytes_done counts completed elements;
// abort acts at the next element boundary (no request is withdrawn; an abort
// while waiting for DREQ acts immediately because nothing is in flight).
// DREQ handshake: the level is re-sampled only after the previous element's
// write response, i.e. >= 2 cycles after the peripheral access, so a request
// line that drops after one pop/push is never double-served.
// Throughput: 4 cycles per element with 1-cycle slaves and no pacing.
// =============================================================================
`default_nettype none

module mcu_dma #(
  parameter int          MAX_LEN_LOG2 = 16,
  parameter logic [15:0] DREQ_MASK    = 16'h0000,      // implemented request lines (bit 0 unused)
  parameter logic [31:0] PER_BASE     = 32'h4000_0000,
  parameter logic [31:0] PER_MASK     = 32'hFFFE_0000
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // register bus slave
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             irq,
  input  wire logic [15:0] dreq,
  // SFB2 master
  output logic             req_valid,
  input  wire logic        req_ready,
  output logic             req_write,
  output logic [31:0]      req_addr,
  output logic [31:0]      req_wdata,
  output logic [3:0]       req_wstrb,
  input  wire logic        rsp_valid,
  output logic             rsp_ready,
  input  wire logic [31:0] rsp_rdata,
  input  wire logic        rsp_error,
  // status
  output logic             busy,
  output logic             err_evt                 // transfer ended with an error (pulse)
);
  localparam logic [11:0] A_CONTROL = mcu_memmap_pkg::DMA_CONTROL;
  localparam logic [11:0] A_STATUS  = mcu_memmap_pkg::DMA_STATUS;
  localparam logic [11:0] A_SRC     = mcu_memmap_pkg::DMA_SRC_ADDR;
  localparam logic [11:0] A_DST     = mcu_memmap_pkg::DMA_DST_ADDR;
  localparam logic [11:0] A_LEN     = mcu_memmap_pkg::DMA_LENGTH;
  localparam logic [11:0] A_BDONE   = mcu_memmap_pkg::DMA_BYTES_DONE;
  localparam logic [11:0] A_IE      = mcu_memmap_pkg::DMA_INT_ENABLE;
  localparam logic [11:0] A_IS      = mcu_memmap_pkg::DMA_INT_STATUS;
  localparam logic [11:0] A_ECODE   = mcu_memmap_pkg::DMA_ERROR_CODE;
  localparam logic [11:0] A_EADDR   = mcu_memmap_pkg::DMA_ERROR_ADDR;
  localparam logic [11:0] A_INFO    = mcu_memmap_pkg::DMA_INFO;
  localparam logic [11:0] A_ID      = mcu_memmap_pkg::DMA_ID;
  localparam logic [11:0] A_MODE    = mcu_memmap_pkg::DMA_MODE;

  localparam logic [3:0] S_IDLE = 4'd0, S_VALIDATE = 4'd1, S_ISSUE_READ = 4'd2, S_WAIT_READ = 4'd3,
                         S_ISSUE_WRITE = 4'd4, S_WAIT_WRITE = 4'd5, S_COMPLETE = 4'd6,
                         S_ERROR = 4'd7, S_WAIT_DREQ = 4'd8;
  localparam logic [3:0] E_NONE = 4'd0, E_ZERO = 4'd1, E_LEN = 4'd2, E_SALIGN = 4'd3, E_DALIGN = 4'd4,
                         E_SOVF = 4'd5, E_DOVF = 4'd6, E_OVERLAP = 4'd7, E_RBUS = 4'd8, E_WBUS = 4'd9,
                         E_ABORT = 4'd10, E_PERIPH = 4'd11, E_LALIGN = 4'd12, E_DREQ = 4'd13;

  // ------------------------------------------------------------ configuration registers
  logic [31:0] cfg_src, cfg_dst, cfg_len;
  logic        m_sfix, m_dfix, m_byte;
  logic [3:0]  m_sel;
  logic [1:0]  ie_q, is_q;
  logic        st_done_q, st_err_q, st_abt_q;

  // ------------------------------------------------------------ engine state
  logic [3:0]  st_q;
  logic [31:0] src_q, dst_q, rem_q, bytes_done;
  logic        sfix_q, dfix_q, byte_q, abort_q;
  logic [3:0]  sel_q;
  logic [3:0]  err_code;
  logic [31:0] err_addr;

  wire wr        = rb_sel && rb_we;
  assign busy    = (st_q != S_IDLE);
  wire start     = wr && rb_addr == A_CONTROL && rb_wdata[0] && !busy;
  wire abort_req = wr && rb_addr == A_CONTROL && rb_wdata[1];
  wire cfg_wr    = wr && (rb_addr == A_SRC || rb_addr == A_DST || rb_addr == A_LEN || rb_addr == A_MODE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cfg_src <= '0; cfg_dst <= '0; cfg_len <= '0;
      m_sfix <= 1'b0; m_dfix <= 1'b0; m_byte <= 1'b0; m_sel <= '0;
      ie_q <= '0;
    end else begin
      if (wr && !busy) begin
        case (rb_addr)
          A_SRC:  cfg_src <= rb_wdata;
          A_DST:  cfg_dst <= rb_wdata;
          A_LEN:  cfg_len <= rb_wdata;
          A_MODE: begin m_sfix <= rb_wdata[0]; m_dfix <= rb_wdata[1]; m_byte <= rb_wdata[2]; m_sel <= rb_wdata[11:8]; end
          default: ;
        endcase
      end
      if (wr && rb_addr == A_IE) ie_q <= rb_wdata[1:0];
    end
  end

  // ------------------------------------------------------------ validation (combinational, VALIDATE state)
  wire [32:0] s_end = {1'b0, src_q} + {1'b0, rem_q};
  wire [32:0] d_end = {1'b0, dst_q} + {1'b0, rem_q};
  // peripheral-window test: a fixed side is one address; an incrementing side
  // is the whole range [addr, addr+len) -- a transfer starting below the
  // window must not run into it (found by formal property P5)
  localparam logic [32:0] PER_LO = {1'b0, PER_BASE};
  localparam logic [32:0] PER_HI = {1'b0, PER_BASE} + {1'b0, ~PER_MASK} + 33'd1;   // exclusive
  wire s_per = sfix_q ? ((src_q & PER_MASK) == PER_BASE) : (({1'b0, src_q} < PER_HI) && (s_end > PER_LO));
  wire d_per = dfix_q ? ((dst_q & PER_MASK) == PER_BASE) : (({1'b0, dst_q} < PER_HI) && (d_end > PER_LO));
  logic [3:0] vcode;
  always_comb begin
    vcode = E_NONE;
    if (rem_q == 32'd0)                                         vcode = E_ZERO;
    else if ({1'b0, rem_q} > (33'd1 << MAX_LEN_LOG2))           vcode = E_LEN;
    else if (!byte_q && rem_q[1:0] != 2'b00)                    vcode = E_LALIGN;
    else if ((!byte_q || sfix_q) && src_q[1:0] != 2'b00)        vcode = E_SALIGN;
    else if ((!byte_q || dfix_q) && dst_q[1:0] != 2'b00)        vcode = E_DALIGN;
    else if (sel_q != 4'd0 && !DREQ_MASK[sel_q])                vcode = E_DREQ;
    else if ((s_per && !(sfix_q && sel_q != 4'd0)) ||
             (d_per && !(dfix_q && sel_q != 4'd0)))             vcode = E_PERIPH;
    else if (!sfix_q && s_end > 33'h1_0000_0000)                vcode = E_SOVF;
    else if (!dfix_q && d_end > 33'h1_0000_0000)                vcode = E_DOVF;
    else if (!sfix_q && !dfix_q &&
             ({1'b0, src_q} < d_end) && ({1'b0, dst_q} < s_end)) vcode = E_OVERLAP;
  end

  // ------------------------------------------------------------ element datapath
  wire [31:0] es      = byte_q ? 32'd1 : 32'd4;
  wire        last_el = (rem_q <= es);
  wire        dreq_ok = (sel_q == 4'd0) || dreq[sel_q];
  wire [7:0]  rbyte   = rsp_rdata[{src_q[1:0], 3'b000} +: 8];
  wire [31:0] wd_nx   = byte_q ? {4{rbyte}} : rsp_rdata;
  wire [3:0]  ws_nx   = (byte_q && !dfix_q) ? (4'b0001 << dst_q[1:0]) : 4'b1111;
  wire        next_dreq = (sel_q != 4'd0);
  wire [31:0] src_nx  = src_q + es;

  assign rsp_ready = (st_q == S_WAIT_READ) || (st_q == S_WAIT_WRITE);
  wire done = (st_q == S_COMPLETE);
  wire fail = (st_q == S_ERROR);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; src_q <= '0; dst_q <= '0; rem_q <= '0; bytes_done <= '0;
      sfix_q <= 1'b0; dfix_q <= 1'b0; byte_q <= 1'b0; sel_q <= '0; abort_q <= 1'b0;
      req_valid <= 1'b0; req_write <= 1'b0; req_addr <= '0; req_wstrb <= '0;
      err_code <= E_NONE; err_addr <= '0;
    end else begin
      if (abort_req && busy) abort_q <= 1'b1;
      case (st_q)
        S_IDLE: begin
          abort_q <= 1'b0;
          if (start) begin
            src_q <= cfg_src; dst_q <= cfg_dst; rem_q <= cfg_len; bytes_done <= '0;
            sfix_q <= m_sfix; dfix_q <= m_dfix; byte_q <= m_byte; sel_q <= m_sel;
            err_code <= E_NONE; err_addr <= '0;
            st_q <= S_VALIDATE;
          end
        end
        S_VALIDATE: begin
          if (vcode != E_NONE) begin
            err_code <= vcode; st_q <= S_ERROR;
          end else if (abort_q || abort_req) begin
            err_code <= E_ABORT; st_q <= S_ERROR;
          end else if (next_dreq) begin
            st_q <= S_WAIT_DREQ;
          end else begin
            req_valid <= 1'b1; req_write <= 1'b0; req_addr <= {src_q[31:2], 2'b00}; req_wstrb <= 4'b1111;
            st_q <= S_ISSUE_READ;
          end
        end
        S_WAIT_DREQ: begin
          if (abort_q || abort_req) begin
            err_code <= E_ABORT; st_q <= S_ERROR;
          end else if (dreq_ok) begin
            req_valid <= 1'b1; req_write <= 1'b0; req_addr <= {src_q[31:2], 2'b00}; req_wstrb <= 4'b1111;
            st_q <= S_ISSUE_READ;
          end
        end
        S_ISSUE_READ: if (req_ready) begin req_valid <= 1'b0; st_q <= S_WAIT_READ; end
        S_WAIT_READ: if (rsp_valid) begin
          if (rsp_error) begin
            err_code <= E_RBUS; err_addr <= src_q; st_q <= S_ERROR;
          end else if (abort_q) begin
            err_code <= E_ABORT; st_q <= S_ERROR;
          end else begin
            req_valid <= 1'b1; req_write <= 1'b1; req_addr <= {dst_q[31:2], 2'b00}; req_wstrb <= ws_nx;
            st_q <= S_ISSUE_WRITE;
          end
        end
        S_ISSUE_WRITE: if (req_ready) begin req_valid <= 1'b0; st_q <= S_WAIT_WRITE; end
        S_WAIT_WRITE: if (rsp_valid) begin
          if (rsp_error) begin
            err_code <= E_WBUS; err_addr <= dst_q; st_q <= S_ERROR;
          end else begin
            bytes_done <= bytes_done + es;
            rem_q      <= rem_q - es;
            if (!sfix_q) src_q <= src_nx;
            if (!dfix_q) dst_q <= dst_q + es;
            if (last_el) begin
              st_q <= S_COMPLETE;
            end else if (abort_q) begin
              err_code <= E_ABORT; st_q <= S_ERROR;
            end else if (next_dreq) begin
              st_q <= S_WAIT_DREQ;
            end else begin
              req_valid <= 1'b1; req_write <= 1'b0;
              req_addr  <= sfix_q ? {src_q[31:2], 2'b00} : {src_nx[31:2], 2'b00};
              req_wstrb <= 4'b1111;
              st_q <= S_ISSUE_READ;
            end
          end
        end
        S_COMPLETE: st_q <= S_IDLE;
        default:    st_q <= S_IDLE;                  // S_ERROR
      endcase
    end
  end

  // write-data register (datapath, not reset)
  always_ff @(posedge clk) begin
    if (st_q == S_WAIT_READ && rsp_valid && !rsp_error) req_wdata <= wd_nx;
  end

  // ------------------------------------------------------------ status / interrupts
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_done_q <= 1'b0; st_err_q <= 1'b0; st_abt_q <= 1'b0; is_q <= '0;
    end else begin
      if (start) begin st_done_q <= 1'b0; st_err_q <= 1'b0; st_abt_q <= 1'b0; end
      if (done) st_done_q <= 1'b1;
      if (fail) begin st_err_q <= 1'b1; st_abt_q <= (err_code == E_ABORT); end
      is_q <= (is_q & ~((wr && rb_addr == A_IS) ? rb_wdata[1:0] : 2'b00)) | {fail, done};
    end
  end
`ifdef FORMAL
  // embedded checker (formal/run_formal.py job "dma"; port-level protocol
  // properties P1/P2/P4 are in formal/fv_dma.sv):
  // P3 rsp_ready only in the WAIT states; P5 a peripheral-window request is
  // only issued on a fixed, DREQ-paced side; P6 no request while idle or
  // validating
  wire f_per = ((req_addr & PER_MASK) == PER_BASE);
  always_comb begin
    if (rst_n) begin
      if (rsp_ready) assert (st_q == S_WAIT_READ || st_q == S_WAIT_WRITE);
      if (req_valid && f_per) assert ((req_write ? dfix_q : sfix_q) && sel_q != 4'd0);
      if (st_q == S_IDLE || st_q == S_VALIDATE) assert (!req_valid);
    end
  end
`endif

  assign irq     = |(is_q & ie_q);
  assign err_evt = fail && (err_code != E_ABORT);

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_CONTROL: begin rb_rdata = 32'd0; rb_err = rb_we && rb_wdata[0] && busy; end
      A_STATUS:  begin rb_rdata = {20'd0, (busy ? st_q : 4'd0), 4'd0, st_abt_q, st_err_q, st_done_q, busy}; rb_err = rb_we; end
      A_SRC:     begin rb_rdata = cfg_src; rb_err = rb_we && busy; end
      A_DST:     begin rb_rdata = cfg_dst; rb_err = rb_we && busy; end
      A_LEN:     begin rb_rdata = cfg_len; rb_err = rb_we && busy; end
      A_MODE:    begin rb_rdata = {20'd0, m_sel, 5'd0, m_byte, m_dfix, m_sfix}; rb_err = rb_we && busy; end
      A_BDONE:   begin rb_rdata = bytes_done; rb_err = rb_we; end
      A_IE:      rb_rdata = {30'd0, ie_q};
      A_IS:      rb_rdata = {30'd0, is_q};
      A_ECODE:   begin rb_rdata = {28'd0, err_code}; rb_err = rb_we; end
      A_EADDR:   begin rb_rdata = err_addr; rb_err = rb_we; end
      A_INFO:    begin rb_rdata = {8'd1, DREQ_MASK, 8'(MAX_LEN_LOG2)}; rb_err = rb_we; end
      A_ID:      begin rb_rdata = mcu_memmap_pkg::DMA_ID_VALUE; rb_err = rb_we; end
      default:   rb_err = 1'b1;
    endcase
  end
  wire unused_ok = cfg_wr;
endmodule

`default_nettype wire
