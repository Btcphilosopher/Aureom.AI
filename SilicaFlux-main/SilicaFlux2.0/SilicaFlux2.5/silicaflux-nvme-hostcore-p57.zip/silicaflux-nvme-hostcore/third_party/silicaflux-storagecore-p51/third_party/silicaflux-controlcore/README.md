# SilicaFlux-HPC · Project 21 — ControlCore: embedded processor and accelerator orchestration

**Primary RTL:** `rtl/silicaflux_control_core.sv` · Aureom.AI / SilicaFlux-HPC

ControlCore is a small, deterministic control subsystem for the SilicaFlux-HPC chip. It contains:

* an RV32IM_Zicsr control processor (machine mode);
* an 8 KiB boot ROM;
* 64 KiB instruction and 32 KiB data control SRAM, both with byte parity;
* an SFB2 control bus;
* an interrupt controller, a timer and a watchdog;
* a system DMA engine;
* host mailbox and console, performance counters, power management, RAS and security-status blocks.

It boots, loads and checks firmware, and discovers and drives the **real** SilicaFlux FP32 vector tile and INT8
tensor unit through their **real** command ABIs. It completes accelerator commands by interrupt, recovers from
supported errors, and gives the host a status and command interface.

> **Status.** Everything below is RTL simulation, synthesis and place-and-route estimates. Nothing ran on an FPGA
> board or silicon. RISC-V compliance is **not** claimed (riscv-tests only). Firmware **authentication is not
> implemented** (CRC32 integrity only; Project 28 must supply it). Delivered as an archive; nothing was
> committed. Details: [docs/09_LIMITATIONS.md](docs/09_LIMITATIONS.md).

## Definition of done: met in RTL simulation

The ControlCore runs real firmware (GNU-compiled C) on the RTL CPU. It submits vector tile commands (KERNEL,
DMA, VEC) and tensor GEMM descriptors to the unmodified accelerator RTL and observes each completion through its
interrupt. Results are checked bit-exact by the firmware and by an independent testbench reference.

## Results (from `reports/`, final run on the frozen sources)

| Check | Result | Report |
|---|---|---|
| System regression (ControlCore + vector tile + tensor unit): 4 scenarios, 2 back-pressure variants | **6 / 6 PASS** | [regression](reports/regression.md) |
| Firmware self-test on the RTL (14 groups: identity, MMIO, exceptions, timer, interrupts incl. 7 simultaneous sources, DMA, vector, tensor, concurrency, error recovery, RAS/parity, perf counters, watchdog, PMU) | **231 / 231 checks** in each full run | `reports/sim/boot_host_*.log` |
| Host-side checks (testbench as host: image load, mailbox, host-built GEMM / vector / DMA commands vs testbench reference, lock, console, RAS, telemetry) | **107 / 107** across the 6 runs | [regression](reports/regression.md) |
| Boot paths: host load, DMA boot from device memory, corrupted image rejected and replaced, host reset → cold boot, watchdog reset → warm boot | **PASS** | [regression](reports/regression.md) |
| cocotb unit tests (7 new blocks; ControlCore alone with Python mocks for the accelerators and memory) | **19 / 19 PASS** | [unit](reports/unit.md) |
| riscv-tests rv32ui/um/mi on the ControlCore CPU (`mcu_cpu` RV32M = 1), re-run here, 3 bus profiles × 2 seeds | **63 / 63 PASS** (3 documented exclusions) | [isa](reports/isa/riscv_tests_m1.txt) |
| Lint: Verilator `-Wall` on new RTL (ControlCore and full system), Icarus elaboration, firmware `-Wall -Wextra` | **0 warnings** | [lint](reports/lint.md) |
| Address-map validator: generated files up to date + 17 illegal maps rejected | **18 / 18 PASS** | [memmap_tests](reports/memmap_tests.md) |
| Vendored sources byte-identical to the repository archives | **160 / 160** | `third_party/PROVENANCE.md` |
| FPGA (ULX3S LFE5U-85F): ControlCore harness synthesised, placed and routed, bitstream generated | **27.42 MHz post-route estimate, 25 MHz met**; 18 791 / 83 640 logic cells (22 %), 80 DP16KD; **not run on a board** | [fpga](reports/fpga.md) |
| Full system (ControlCore + both accelerators), Yosys estimate | about 99 k logic cells: **does not fit LFE5U-85F**, not placed | [fpga](reports/fpga.md) |
| FPGA harness in RTL simulation (boots from block RAM, console on UART) | **PASS** | `reports/sim/fpga_harness.log` |

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit; reuse verified components; CPU decision; no unproven ISA claim | [docs/00_AUDIT.md](docs/00_AUDIT.md), [docs/02_CPU.md](docs/02_CPU.md), `third_party/PROVENANCE.md` |
| 2 | Top level: processor, boot ROM, I/D memory, control bus, INTC, timer, watchdog, vector / tensor / DMA command interfaces, perf counters, firmware loading and status; one clock domain | `rtl/silicaflux_control_core.sv`, [docs/01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md) |
| 3 | Exact ISA and privileged features; endianness, alignment, exceptions, reset vector, trap handling | [docs/02_CPU.md](docs/02_CPU.md) |
| 4 | One authoritative, versioned address map; SV + C headers; overlap / alignment validation | `config/cc_memmap.yaml`, `scripts/gen_memmap.py`, [docs/MEMORY_MAP.md](docs/MEMORY_MAP.md), `scripts/test_memmap.py` |
| 5 | Boot sequence 1–7; no pretended authentication | `firmware/bootrom/`, [docs/03_BOOT.md](docs/03_BOOT.md) |
| 6 | Vector ops, GEMM descriptors, DMA, completion IRQs, error status, perf counters; real ABI | `firmware/app/accel.c`, `selftest.c`, `main.c`, [docs/05_ACCELERATORS.md](docs/05_ACCELERATORS.md) |
| 7 | DMA / tensor / vector completion, RAS warning, fatal error, watchdog interrupts; priorities, acknowledgement, masking; simultaneous interrupts tested | [docs/04_INTERRUPTS.md](docs/04_INTERRUPTS.md), firmware T5 |
| 8 | C firmware: linker script, startup assembly, register definitions, interrupt handlers, command examples, self-test, host-visible diagnostics; reproducible cross-compilation | `firmware/`, [docs/06_FIRMWARE.md](docs/06_FIRMWARE.md) |
| 9 | Reset/boot, firmware, MMIO, invalid address, interrupts, timer, watchdog, tensor, vector, DMA, errors; Verilator / cocotb | `tb/`, [docs/07_VERIFICATION.md](docs/07_VERIFICATION.md) |
| 10 | FPGA synthesis; actual resources and timing; no board claim | `fpga/`, [docs/08_FPGA.md](docs/08_FPGA.md), [reports/fpga.md](reports/fpga.md) |
| 11 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_control_core.sv` | `rtl/silicaflux_control_core.sv` plus the new blocks `rtl/cc_sysctrl.sv`, `cc_mailbox.sv`, `cc_ras.sv`, `cc_pmu.sv`, `cc_perf.sv`, `cc_secmon.sv`, `cc_sfb_gate.sv` |
| Control bus and address map | `config/cc_memmap.yaml` → `rtl/generated/cc_memmap_pkg.sv`, `cc_memmap_defs.svh`, `firmware/include/generated/cc_memmap.h`, `cc_memory.ld`, `scripts/generated/cc_memmap.py`, `docs/MEMORY_MAP.md` |
| Boot ROM | `firmware/bootrom/` → `rtl/generated/sfv_bootrom_image.sv`; `scripts/mkimage.py` (image + CRC32) |
| Interrupt / timer / watchdog integration | `rtl/silicaflux_control_core.sv` (INTC sources, MTIMER, WDT, reset generator), `firmware/app/platform.c` |
| Accelerator integration | `integration/silicaflux_cc_hpc_system.sv` (ControlCore + unmodified TENSORCORE 08 / HPC Module 08 subsystem) |
| Firmware source | `firmware/app/`, `firmware/common/` |
| Linker / build scripts | `firmware/common/fw.ld`, `firmware/bootrom/rom.ld`, `firmware/Makefile`, top-level `Makefile`, `fpga/build.sh` |
| Tests and regression commands | `tb/tb_cc_system.sv`, `tb/unit/` (cocotb), `tb/tb_fpga_top.sv`, `scripts/regress.py`, `scripts/run_riscv_tests.sh`, `scripts/lint.py`, `scripts/test_memmap.py`, `scripts/check_vendor.py` |
| Hardware/software interface documentation | [docs/HW_SW_INTERFACE.md](docs/HW_SW_INTERFACE.md), [docs/MEMORY_MAP.md](docs/MEMORY_MAP.md), docs 01–09 |

## Quick start

Tools used (Ubuntu 24.04 packages): Verilator 5.020, Icarus Verilog 12, Yosys 0.33, nextpnr-ecp5 0.6 with
Project Trellis, `gcc-riscv64-unknown-elf` 13.2, Python 3 with PyYAML, and cocotb 1.9.2 (pip).

```bash
sudo apt-get install -y verilator iverilog yosys nextpnr-ecp5 fpga-trellis gcc-riscv64-unknown-elf python3-yaml
```

```bash
pip install cocotb==1.9.2 pyyaml
```

```bash
make fw
```

```bash
make sim
```

```bash
make regress
```

```bash
make run SCENARIO=boot_host
```

```bash
make unit
```

```bash
make lint check-map
```

```bash
make isa
```

```bash
make fpga
```

```bash
make fpga-sim
```

* `make fw` builds the boot ROM image and the firmware image.
* `make sim` builds the Verilator system simulation.
* `make regress` runs all 6 system scenario runs (about 3 minutes on 3 cores).
* `make run SCENARIO=boot_host` runs one scenario and prints the firmware console.
* `make unit` runs the cocotb tests.
* `make isa` runs riscv-tests. It clones riscv-tests into `deps/` the first time.
* `make fpga` runs ULX3S synthesis, P&R and bitstream generation (about 10 minutes).
* `make fpga-sim` simulates the FPGA harness.

## Layout

```
config/       cc_memmap.yaml (single source of truth for the address map)
rtl/          ControlCore RTL (new) + generated/ (map package, defines, boot-ROM image); files.f
integration/  ControlCore + accelerator subsystem; files_system.f
firmware/     boot ROM, startup, link scripts, platform layer, accelerator orchestration, self-test, Makefile
tb/           system testbench, FPGA harness testbench, unit/ (cocotb)
fpga/         ULX3S harness, constraints, build script (fpga/build/: tool outputs incl. bitstream)
scripts/      map generator + validator tests, image builder, regression, lint, ISA tests, vendor check, FPGA report
third_party/  unmodified SilicaFlux sources (CPU, INTC, WDT, DMA, SRAM, bus, vector tile, tensor unit, drivers)
docs/         00 audit … 09 limitations, MEMORY_MAP (generated), HW_SW_INTERFACE
reports/      tool outputs of the final runs (SUMMARY.md)
```
