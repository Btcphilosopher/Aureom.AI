// =============================================================================
// SilicaFlux ControlCore :: cc_sfb_gate -- SFB2 pass-through that can refuse
//
// Used twice: as the host write lock (cc_host_gate role: refuse = HOST_LOCK and
// a write to BOOTROM/IMEM/DMEM) and as the accelerator isolation gate on the
// external data port (refuse = accelerator domain isolated).
//   * One transaction at a time (the DataFabric crossbar already allows one
//     per port, SFB2 R6), so ordering is trivially preserved.
//   * A refused request is accepted locally and answered one cycle later with
//     rsp_error = 1, rdata = 0 (SFB2 R8); nothing reaches the master side.
//   * m_req_valid never depends on m_req_ready; a request is presented on the
//     master side only after refuse was evaluated, and once presented it is
//     never withdrawn (pend_q masks a late refuse; the upstream holds it, R2).
//   * idle = nothing outstanding (used by the PMU before stopping the clock).
// =============================================================================
`default_nettype none

module cc_sfb_gate (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // slave side (from upstream master / crossbar)
  input  wire logic        s_req_valid,
  output logic             s_req_ready,
  input  wire logic        s_req_write,
  input  wire logic [31:0] s_req_addr,
  input  wire logic [31:0] s_req_wdata,
  input  wire logic [3:0]  s_req_wstrb,
  output logic             s_rsp_valid,
  input  wire logic        s_rsp_ready,
  output logic [31:0]      s_rsp_rdata,
  output logic             s_rsp_error,
  // master side (to downstream slave)
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  // control / status
  input  wire logic        refuse,           // evaluated on the presented request
  output logic             refused_evt,      // a request was refused (pulse)
  output logic             idle
);
  logic out_q, loc_q, pend_q;
  wire  free = !out_q && !loc_q;
  // a request already presented downstream is never withdrawn, even if
  // `refuse` rises while it waits for m_req_ready
  wire  refuse_eff = refuse && !pend_q;

  assign m_req_valid = s_req_valid && free && !refuse_eff;
  assign m_req_write = s_req_write;
  assign m_req_addr  = s_req_addr;
  assign m_req_wdata = s_req_wdata;
  assign m_req_wstrb = s_req_wstrb;
  assign s_req_ready = free && (refuse_eff ? 1'b1 : m_req_ready);

  wire fwd_acc = m_req_valid && m_req_ready;
  wire loc_acc = s_req_valid && free && refuse_eff;
  wire m_rsp_hs = m_rsp_valid && m_rsp_ready;

  assign s_rsp_valid = loc_q || (!loc_q && m_rsp_valid);
  assign s_rsp_rdata = loc_q ? 32'd0 : m_rsp_rdata;
  assign s_rsp_error = loc_q ? 1'b1  : m_rsp_error;
  assign m_rsp_ready = !loc_q && s_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_q  <= 1'b0;
      loc_q  <= 1'b0;
      pend_q <= 1'b0;
    end else begin
      pend_q <= m_req_valid && !m_req_ready;
      if (fwd_acc && !m_rsp_hs)      out_q <= 1'b1;
      else if (m_rsp_hs)             out_q <= 1'b0;
      if (loc_acc)                   loc_q <= 1'b1;
      else if (loc_q && s_rsp_ready) loc_q <= 1'b0;
    end
  end

  assign refused_evt = loc_acc;
  assign idle        = free && !m_req_valid;     // nothing outstanding or waiting downstream
endmodule

`default_nettype wire
