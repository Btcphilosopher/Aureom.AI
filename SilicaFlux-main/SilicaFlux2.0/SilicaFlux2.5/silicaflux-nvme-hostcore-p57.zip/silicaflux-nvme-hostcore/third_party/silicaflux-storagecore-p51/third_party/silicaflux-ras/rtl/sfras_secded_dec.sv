// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_secded_dec
// Combinational extended-Hamming SECDED decoder + error classifier.
//
// Inputs: an N-bit stored codeword (layout: sfras_ecc_funcs.svh).
//   c_rx = cw[K+R-1:K] ^ INV[R-1:0], p_rx = cw[K+R] ^ INV[R], d_rx = cw[K-1:0]
//   s    = check bits recomputed from d_rx  XOR  c_rx          (R bits)
//   pe   = p_rx ^ ^c_rx ^ ^d_rx  (overall parity over the N un-inverted bits)
//
// Classification (exactly one of none / ce / ue is 1):
//   s == 0, pe == 0           NONE  data_o = d_rx
//   s == 0, pe == 1           CE    the overall parity bit flipped
//                                   (err_idx_o = K+R, data unaffected)
//   s != 0, pe == 1, s <= K+R CE    single error at Hamming position s:
//                                   check bit (s a power of two) or data bit
//                                   (flipped back in data_o); err_idx_o = the
//                                   stored-bit index of that bit
//   s != 0, pe == 1, s >  K+R UE    INVALID syndrome: names no bit, so it cannot
//                                   be a single error (>= 3 errors); NOT corrected
//   s != 0, pe == 0           UE    double error (or any even number >= 2)
// ce_o is asserted only when exactly one bit has been flipped back in
// cw_corr_o (and, for a data bit, in data_o).  On UE data_o = d_rx (the stored,
// uncorrected data bits) and cw_corr_o = cw_i: the caller decides how to
// contain them (poison, error response) -- this block never substitutes data.
// Errors of weight >= 3 can alias to a CE (miscorrection); that is a property
// of every distance-4 code and is characterised, not hidden, in
// reports/secded_characterisation.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_secded_dec #(
  parameter int K   = 64,
  parameter int INV = 0,
  // ---- derived, do not override ----
  parameter int R   = $clog2(K + $clog2(K + 1) + 1),
  parameter int N   = K + R + 1,
  parameter int IW  = $clog2(N)
) (
  input  wire logic [N-1:0]  cw_i,
  output logic      [K-1:0]  data_o,       // corrected data (raw on UE)
  output logic      [N-1:0]  cw_corr_o,    // corrected stored codeword (raw on UE)
  output logic               none_o,       // no error
  output logic               ce_o,         // single-bit error, corrected
  output logic               ue_o,         // uncorrectable (double / invalid syndrome)
  output logic               ue_inval_o,   // ue_o because of an invalid syndrome (s > K+R)
  output logic               ce_data_o,    // the corrected bit is a data bit
  output logic      [IW-1:0] err_idx_o,    // stored-bit index of the corrected bit (valid with ce_o)
  output logic      [R:0]    syn_o         // {pe, s}
);
  `include "sfras_ecc_funcs.svh"

  if (R != sfras_ecc_r(K) || N != K + sfras_ecc_r(K) + 1) begin : g_err_derived_overridden
    `SFRAS_CFG_FATAL("sfras_secded_dec: R / N / IW are derived parameters and must not be overridden")
  end

  localparam logic [R:0] INV_V = INV[R:0];

  // ---------------------------------------------------------------- syndrome
  wire [K-1:0] d_rx = cw_i[K-1:0];
  wire [R-1:0] c_rx = cw_i[K+R-1:K] ^ INV_V[R-1:0];
  wire         p_rx = cw_i[K+R]     ^ INV_V[R];

  /* verilator lint_off UNUSEDSIGNAL */
  logic [N-1:0] cw_recalc;                  // only the recomputed check bits are used
  /* verilator lint_on UNUSEDSIGNAL */
  sfras_secded_enc #(.K(K), .INV(0)) u_enc (.data_i(d_rx), .cw_o(cw_recalc));

  wire [R-1:0] s  = cw_recalc[K+R-1:K] ^ c_rx;
  wire         pe = p_rx ^ (^c_rx) ^ (^d_rx);

  wire s_zero  = (s == '0);
  wire s_valid = ({1'b0, s} <= (R+1)'(K + R));

  assign none_o     = s_zero && !pe;
  assign ce_o       = pe && (s_zero || s_valid);
  assign ue_o       = !s_zero && (!pe || !s_valid);
  assign ue_inval_o = !s_zero && pe && !s_valid;
  assign syn_o      = {pe, s};

  // ------------------------------------------------- one-hot error location
  logic [N-1:0] hit;
  for (genvar b = 0; b < N; b++) begin : g_hit
    localparam int HP = sfras_ecc_hpos(K, b);
    if (b == K + R) begin : g_par
      assign hit[b] = pe && s_zero;
    end else begin : g_pos
      assign hit[b] = pe && (s == R'(HP));
    end
  end

  assign cw_corr_o = cw_i ^ hit;            // hit is all-zero unless ce_o (s > K+R matches no bit)
  assign data_o    = d_rx ^ hit[K-1:0];
  assign ce_data_o = |hit[K-1:0];

  always_comb begin
    err_idx_o = '0;
    for (int b = 0; b < N; b++) if (hit[b]) err_idx_o = err_idx_o | IW'(b);
  end

`ifdef SFRAS_ASSERT
  always_comb begin
    if (!$isunknown(cw_i)) begin
      assert ($onehot({none_o, ce_o, ue_o})) else $error("%m: classification not one-hot");
      assert ($countones(hit) == (ce_o ? 1 : 0)) else $error("%m: correction mask weight mismatch");
    end
  end
`endif

endmodule

`default_nettype wire
