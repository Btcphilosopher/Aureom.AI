// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_sfb_ecc_slave
// SFB2 slave on a SECDED-protected SRAM (sfras_ecc_sram): the ECC counterpart
// of DataFabric's sfb_sram_slave (same request mapping and WRITE_ACK = 1
// ordering).  This is where the memory's containment boundary meets the
// fabric:
//   * a read of an uncorrectable or poisoned word answers rsp_error = 1 (the
//     only error signal SFB2 has); every SFB2 master already treats it as a
//     failed access (CPU load fault, DMA_ERR_READ_BUS abort, tensor-DMA error).
//     rsp_poison is an additional sideband for poison-aware masters.
//   * a partial write (wstrb not all-ones) is a read-modify-write inside the
//     wrapper; a partial write onto an uncorrectable word answers rsp_error = 1.
//   * corrected reads answer normally (rsp_error = 0) and raise a CE event.
// Word address = req_addr[OFF +: AW]; the crossbar decodes the window.
// All ECC-wrapper side ports (scrub, init, MBIST, events, fault injection) are
// passed through for the RAS controller and TestCore.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_sfb_ecc_slave #(
  parameter int DW           = 32,
  parameter int DEPTH        = 1024,
  parameter int READ_LATENCY = 1,
  parameter int BACKEND      = `SRAM_BACKEND_GENERIC,
  parameter int MACRO        = 0,
  parameter int POISON_MODE  = `SFRAS_POISON_BIT,
  parameter int DEC_PIPE     = 0,
  parameter int FI_EN        = 0,
  parameter int SCRUB_MAX_WAIT = 16,
  localparam int SB   = DW / 8,
  localparam int OFF  = (DW > 8) ? $clog2(DW / 8) : 0,
  localparam int AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int KC   = DW + ((POISON_MODE == `SFRAS_POISON_BIT) ? 1 : 0),
  localparam int R    = $clog2(KC + $clog2(KC + 1) + 1),
  localparam int N    = KC + R + 1,
  localparam int IW   = $clog2(N)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // SFB2 slave
  input  wire logic          req_valid,
  output logic               req_ready,
  input  wire logic          req_write,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]   req_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [DW-1:0] req_wdata,
  input  wire logic [SB-1:0] req_wstrb,
  output logic               rsp_valid,
  input  wire logic          rsp_ready,
  output logic [DW-1:0]      rsp_rdata,
  output logic               rsp_error,
  output logic               rsp_poison,
  // scrub port
  input  wire logic          scr_req_valid,
  output logic               scr_req_ready,
  input  wire logic [1:0]    scr_req_op,
  input  wire logic [AW-1:0] scr_req_addr,
  output logic               scr_rsp_valid,
  output logic [1:0]         scr_rsp_op,
  output logic [AW-1:0]      scr_rsp_addr,
  output logic               scr_rsp_ce,
  output logic               scr_rsp_ue,
  output logic               scr_rsp_poison,
  output logic               scr_rsp_wb,
  // init
  input  wire logic          init_req_i,
  output logic               init_busy_o,
  output logic               init_done_o,
  // MBIST
  input  wire logic          tst_active,
  output logic               tst_ready,
  input  wire logic          tst_ce,
  input  wire logic          tst_we,
  input  wire logic [AW-1:0] tst_addr,
  input  wire logic [N-1:0]  tst_wdata,
  output logic [N-1:0]       tst_rdata,
  // events
  output logic               ev_valid,
  output logic               ev_ce,
  output logic               ev_ue,
  output logic               ev_poison,
  output logic [2:0]         ev_org,
  output logic [AW-1:0]      ev_addr,
  output logic [R:0]         ev_syn,
  output logic [IW-1:0]      ev_idx,
  // fault injection
  input  wire logic          fi_arm_i,
  input  wire logic [1:0]    fi_mode_i,
  input  wire logic [N-1:0]  fi_mask_i,
  input  wire logic          fi_addr_en_i,
  input  wire logic [AW-1:0] fi_addr_i,
  output logic               fi_armed_o,
  output logic               fi_fired_o,
  output logic [AW-1:0]      fi_fired_addr_o
);
  logic rsp_err, rsp_ce_u, rsp_we_u, busy_u, plock_u, prmw_u;
  logic [0:0] rsp_id_u;

  sfras_ecc_sram #(
    .K(DW), .DEPTH(DEPTH), .READ_LATENCY(READ_LATENCY), .BACKEND(BACKEND), .MACRO(MACRO), .BYTE_EN(1),
    .WRITE_ACK(1), .ID_W(1), .DEC_PIPE(DEC_PIPE), .POISON_MODE(POISON_MODE), .UE_ZERO(0),
    .INIT_ON_RESET(1), .REINIT_AFTER_TEST(1), .TEST_EN(1), .SCRUB_MAX_WAIT(SCRUB_MAX_WAIT), .FI_EN(FI_EN)
  ) u_mem (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_we(req_write), .req_addr(req_addr[OFF +: AW]), .req_wdata,
    .req_wmask(req_wstrb), .req_id(1'b0),
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_ce(rsp_ce_u), .rsp_poison, .rsp_we(rsp_we_u),
    .rsp_id(rsp_id_u),
    .scr_req_valid, .scr_req_ready, .scr_req_op, .scr_req_addr,
    .scr_rsp_valid, .scr_rsp_op, .scr_rsp_addr, .scr_rsp_ce, .scr_rsp_ue, .scr_rsp_poison, .scr_rsp_wb,
    .init_req_i, .init_busy_o, .init_done_o,
    .tst_active, .tst_ready, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata,
    .ev_valid, .ev_ce, .ev_ue, .ev_poison, .ev_org, .ev_addr, .ev_syn, .ev_idx,
    .fi_arm_i, .fi_mode_i, .fi_mask_i, .fi_addr_en_i, .fi_addr_i, .fi_armed_o, .fi_fired_o, .fi_fired_addr_o,
    .busy(busy_u), .perf_lock_o(plock_u), .perf_rmw_o(prmw_u)
  );
  assign rsp_error = rsp_err;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = rsp_ce_u ^ rsp_we_u ^ busy_u ^ plock_u ^ prmw_u ^ rsp_id_u[0];
  /* verilator lint_on UNUSEDSIGNAL */

endmodule

`default_nettype wire
