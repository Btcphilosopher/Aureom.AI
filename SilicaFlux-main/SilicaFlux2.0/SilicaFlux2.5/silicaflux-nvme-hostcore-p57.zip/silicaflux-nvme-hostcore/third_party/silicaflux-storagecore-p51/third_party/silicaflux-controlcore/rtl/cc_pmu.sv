// =============================================================================
// SilicaFlux ControlCore :: cc_pmu -- accelerator clock, reset and isolation
//
// Register page CC_PG_PMU (block cc_pmu).  One clock domain; the accelerator
// subsystem receives a gated copy of it (acc_clk_en drives an ICG in the top).
//   ACC_CTRL.CLK_EN = 0  request the accelerator clock off.  The clock keeps
//                        running while a unit is busy or a ControlCore
//                        transaction to the accelerator fabric is outstanding
//                        (CLK_OFF_PENDING), then stops.  clk_on is registered,
//                        so the ICG enable is glitch-free.
//   ACC_CTRL.RST    = 1  hold the accelerator subsystem in reset (applied once the
//                        external port is idle; async assert, sync release
//                        through the top's reset synchroniser).
//   ACC_CTRL.ISO    = 1  isolate.
// The accelerator domain is ISOLATED whenever ISO, RST, !CLK_EN or a RAS fatal
// with CTRL.FATAL_ISOLATE: ControlCore accesses to the forwarded register pages
// are refused (rb_err) and new requests on the external data port are answered
// with an error (cc_sfb_gate), and the accelerator interrupt lines are masked.
// Isolation is what makes clock gating and reset safe: no access can reach a
// stopped or resetting domain.  No DVFS, no power switches (INFO).
// =============================================================================
`default_nettype none

module cc_pmu
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  /* verilator lint_off UNUSEDSIGNAL */           // only ACC_CTRL[2:0] is writable
  input  wire logic [31:0] rb_wdata,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // status
  input  wire logic        cpu_sleep,
  input  wire logic        vec_busy,
  input  wire logic        tsu_busy,
  input  wire logic        tsu_halted,
  input  wire logic        ext_idle,
  input  wire logic        fatal_iso,
  input  wire logic        acc_in_reset,      // synchronised accelerator reset is asserted
  // control
  output logic             acc_clk_en,
  output logic             acc_rst_req,
  output logic             acc_iso
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  wire wr = rb_sel && rb_we;
  logic [2:0]  ctl_q;
  logic        clk_on_q, rst_eff_q;
  logic [31:0] sleep_q, gated_q;

  wire busy = vec_busy || tsu_busy || !ext_idle;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctl_q    <= CC_PMU_ACC_CTRL_RST[2:0];
      clk_on_q <= 1'b1;
      rst_eff_q <= 1'b0;
      sleep_q  <= '0;
      gated_q  <= '0;
    end else begin
      if (wr && rb_addr == CC_PMU_ACC_CTRL) ctl_q <= rb_wdata[2:0];
      clk_on_q <= ctl_q[0] || busy;
      // RST takes effect only once no ControlCore transaction is outstanding on
      // the external port (isolation already blocks new ones); release is immediate
      rst_eff_q <= ctl_q[1] && (rst_eff_q || ext_idle);
      if (cpu_sleep && sleep_q != 32'hFFFF_FFFF) sleep_q <= sleep_q + 32'd1;
      if (!clk_on_q && gated_q != 32'hFFFF_FFFF) gated_q <= gated_q + 32'd1;
    end
  end

  assign acc_clk_en  = clk_on_q;
  assign acc_rst_req = rst_eff_q;
  assign acc_iso     = ctl_q[2] || ctl_q[1] || !ctl_q[0] || !clk_on_q || fatal_iso || acc_in_reset;

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      CC_PMU_INFO:       begin rb_rdata = 32'h0000_0011; rb_err = rb_we; end
      CC_PMU_ACC_CTRL:   rb_rdata = {29'd0, ctl_q};
      CC_PMU_ACC_STATUS: begin
        rb_rdata = {23'd0, fatal_iso, clk_on_q && !ctl_q[0], tsu_halted, tsu_busy, vec_busy, ext_idle,
                    acc_iso, acc_in_reset, clk_on_q};
        rb_err = rb_we;
      end
      CC_PMU_CC_STATE:   begin rb_rdata = {31'd0, cpu_sleep}; rb_err = rb_we; end
      CC_PMU_SLEEP_CYC:  begin rb_rdata = sleep_q; rb_err = rb_we; end
      CC_PMU_GATED_CYC:  begin rb_rdata = gated_q; rb_err = rb_we; end
      default:           rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
