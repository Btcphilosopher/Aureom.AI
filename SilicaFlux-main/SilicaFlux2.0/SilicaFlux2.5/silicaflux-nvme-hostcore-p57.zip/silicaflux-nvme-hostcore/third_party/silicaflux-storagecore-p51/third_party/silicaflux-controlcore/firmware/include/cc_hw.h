/* =============================================================================
 * SilicaFlux ControlCore -- hardware access layer shared by the boot ROM and
 * the firmware.  Addresses and offsets come ONLY from the generated
 * cc_memmap.h (config/cc_memmap.yaml); nothing is hard-coded here.
 * Bare metal, freestanding C (stdint/stddef only), RV32IM_Zicsr, machine mode.
 * ===========================================================================*/
#ifndef CC_HW_H
#define CC_HW_H

#include <stddef.h>
#include <stdint.h>
#include "generated/cc_memmap.h"

#define REG32(addr)          (*(volatile uint32_t *)(uintptr_t)(addr))
#define SYSCTRL(off)         REG32(CC_SYSCTRL_BASE + (off))
#define INTC(off)            REG32(CC_INTC_BASE + (off))
#define MTIMER(off)          REG32(CC_MTIMER_BASE + (off))
#define WDT(off)             REG32(CC_WDT_BASE + (off))
#define DMA(off)             REG32(CC_DMA_BASE + (off))
#define MBOX(off)            REG32(CC_MAILBOX_BASE + (off))
#define PERF(off)            REG32(CC_PERF_BASE + (off))
#define PMU(off)             REG32(CC_PMU_BASE + (off))
#define RAS(off)             REG32(CC_RAS_BASE + (off))
#define SEC(off)             REG32(CC_SECURITY_BASE + (off))
#define MBOX_H2F(i)          REG32(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4u * (i))
#define MBOX_F2H(i)          REG32(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 4u * (i))
#define PERF_CNT(i)          REG32(CC_PERF_BASE + CC_PERF_CNT0 + 4u * (i))

/* ---------------------------------------------------------------- CSRs */
#define csr_read(r)          ({ uint32_t __v; __asm__ volatile("csrr %0, " #r : "=r"(__v)); __v; })
#define csr_write(r, v)      __asm__ volatile("csrw " #r ", %0" ::"r"((uint32_t)(v)))
#define csr_set(r, v)        __asm__ volatile("csrs " #r ", %0" ::"r"((uint32_t)(v)))
#define csr_clear(r, v)      __asm__ volatile("csrc " #r ", %0" ::"r"((uint32_t)(v)))
#define MSTATUS_MIE          (1u << 3)
#define MIE_MSIE             (1u << 3)
#define MIE_MTIE             (1u << 7)
#define MIE_MEIE             (1u << 11)
#define MCAUSE_INT           0x80000000u

static inline void fence_i(void) { __asm__ volatile("fence.i" ::: "memory"); }
static inline void wfi(void) { __asm__ volatile("wfi"); }
static inline void irq_enable(void) { csr_set(mstatus, MSTATUS_MIE); }
static inline uint32_t irq_save(void) {
  uint32_t m; __asm__ volatile("csrrci %0, mstatus, 8" : "=r"(m)); return m & MSTATUS_MIE;
}
static inline void irq_restore(uint32_t m) { if (m) csr_set(mstatus, MSTATUS_MIE); }

/* ---------------------------------------------------------------- firmware image header */
typedef struct {
  uint32_t magic;          /* CC_IMAGE_MAGIC */
  uint32_t hdr_version;    /* CC_IMAGE_HDR_VERSION */
  uint32_t image_size;     /* bytes, header included */
  uint32_t entry;          /* entry point (inside the image, after the header) */
  uint32_t load_addr;      /* CC_IMEM_BASE */
  uint32_t crc32;          /* CRC-32 (IEEE 802.3, reflected) of bytes [CC_IMAGE_HDR_BYTES, image_size) */
  uint32_t fw_version;
  uint32_t flags;
  char     name[32];
} cc_image_hdr_t;

static inline void boot_stage(uint32_t s) { SYSCTRL(CC_SYSCTRL_BOOT_STAGE) = s; }

#endif /* CC_HW_H */
