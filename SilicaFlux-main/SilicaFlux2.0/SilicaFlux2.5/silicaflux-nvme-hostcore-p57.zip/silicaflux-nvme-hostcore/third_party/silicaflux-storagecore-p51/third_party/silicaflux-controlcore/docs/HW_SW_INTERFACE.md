# Hardware / software interface

This is the contract between the ControlCore hardware, its firmware, and the host. Register-level detail is
generated: **[MEMORY_MAP.md](MEMORY_MAP.md)** (from `config/cc_memmap.yaml`; same data in
`rtl/generated/cc_memmap_pkg.sv`, `rtl/generated/cc_memmap_defs.svh`, `firmware/include/generated/cc_memmap.h`,
`scripts/generated/cc_memmap.py`). Address map version: **1.0** (`SYSCTRL.MAP_VERSION = 0x0001_0000`).

## 1. Pins / ports of `silicaflux_control_core`

| Port | Dir | Meaning |
|---|---|---|
| `clk`, `rst_ni`, `test_mode` | in | functional clock; asynchronous power-on reset (active low); scan mode (resets bypassed, clock gates open) |
| `boot_mode_i[1:0]` | in | boot straps (0 host load, 1 device-memory image), synchronised |
| `host_rst_req_i` | in | host-requested ControlCore reset (rising edge, synchronised) -> cold boot |
| `hs_*` | SFB2 slave | **host access port**: IMEM/DMEM/BOOTROM (writes to them refused once `HOST_LOCK` is set), all register pages; not the EXT window. Stalls during reset. |
| `host_irq_o` | out | firmware -> host doorbell pending (`MBOX.F2H_PEND`) |
| `host_ready_o`, `cmdproc_ready_o` | out | `SYSCTRL.HOST_STATUS[0]` / `[1]` |
| `ras_fatal_o` | out | an unhandled fatal error is pending (`RAS.STATUS[15:8] != 0` and `CTRL.FATAL_TO_HOST`) |
| `acc_rb_*` | rb master | accelerator register pages 8..15, `acc_rb_addr[15:12] = page`; one-cycle strobe, `rb_rdata` / `rb_err` combinational (SilicaFlux-V register-bus contract) |
| `ext_*` | SFB2 master | ControlCore and system-DMA accesses to `0x2000_0000..0x3FFF_FFFF`; refused locally (error response) while the accelerator domain is isolated |
| `acc_clk_o`, `acc_rst_no` | out | gated clock and reset for the accelerator subsystem |
| `acc_vec_irq_i`, `acc_tsu_irq_i`, `acc_*_busy_i`, `acc_tsu_halted_i` | in | accelerator interrupt / status levels (synchronous to `acc_clk_o`) |
| `ext_warn_i`, `ext_fatal_i` | in | SoC RAS inputs (levels, synchronised) |
| `diag_valid_o`, `diag_char_o` | out | console character strobe (simulation / lab tap of `DIAG_TX`) |
| `test_done_o`, `test_fail_o`, `test_code_o` | out | `SYSCTRL.TEST_CTRL` (simulation / lab) |
| `cpu_sleep_o` | out | CPU in WFI |

## 2. Host bring-up sequence

1. Release reset. Poll `SYSCTRL.BOOT_STAGE` until `WAIT_IMAGE` (0x03) (host-load mode).
2. Write the image (`scripts/mkimage.py` output, little-endian words) to `CC_IMEM_BASE`.
3. `H2F_MSG0 = IMAGE_READY (1)`, write `H2F_RING`. Wait for `host_irq_o`; read `F2H_MSG0` (status `OK` or
   `BAD_CMD` with the `BOOT_ERR_*` reason in `F2H_MSG1`); write `F2H_ACK`. On error, rewrite and retry.
4. Wait for `host_ready_o`; read the capability message (`F2H_MSG1` accelerator mask: bit 0 vector, bit 1
   tensor), `F2H_ACK`. `HOST_STATUS.DEGRADED` = an accelerator is missing.
5. Submit commands (`docs/06_FIRMWARE.md` section 4). Read the console from `DIAG_RX` / `DIAG_POP`.
6. Recovery: `SYSCTRL.SOFT_RESET = 0x5AFEC0DE` (warm), or the `host_rst_req_i` pin (cold, image reload).

Device-memory boot (`BOOT_MODE_EXT`): place the image at `0x200F_0000` (or in `H2F_MSG1`) before releasing
reset; no host action is needed afterwards.

## 3. Firmware programming model (summary)

| Task | Registers |
|---|---|
| Boot progress / host status | `SYSCTRL.BOOT_STAGE`, `BOOT_STATUS`, `HOST_STATUS`, `FW_VERSION` |
| Reset cause / persistent state | `SYSCTRL.RESET_CAUSE` (W1C), `RESET_COUNT`, `SCRATCH0..3` (POR domain) |
| Interrupts | `INTC.ENABLE`, `PRIO0`, `THRESHOLD`, `CLAIM`; per-block status W1C + read-back (doc 04) |
| Timer / watchdog | `MTIMER.*`; `WDT.LOAD/PRESCALE/EWI_THRESH/CTRL`, `SERVICE` = 0xA5A5 then 0x5A5A |
| DMA | `DMA.SRC_ADDR/DST_ADDR/LENGTH/MODE`, `INT_ENABLE`, `CONTROL.START`, `INT_STATUS`, `ERROR_CODE` |
| Vector / tensor | pages 8 / 9 through the vendored drivers (doc 05) |
| Power | `PMU.ACC_CTRL` (CLK_EN, RST, ISO), `ACC_STATUS` |
| RAS | `RAS.STATUS` (W1C), `WARN_EN`, `FATAL_EN`, counters, `FIRST_*`, `LAST_*`, `INJECT`, `SW_REPORT`, `PAR_CHK_EN`, `PAR_INJECT` |
| Security status | `SECURITY.CAPS`, `STATUS`, `CTRL.HOST_LOCK`, `BOOT_MEASURE` |
| Performance | `PERF.CTRL` (freeze, clear), `CYCLE_LO/HI`, `CNT0 + 4i` (`CC_PERF_EV_*`) |

## 4. Data formats

* Firmware image: doc 03 section 3.
* Telemetry block (`PERF_DUMP`): doc 05 section 4.
* Vector descriptor / record: tile ABI (`third_party/silicaflux-hpc-m08-tile/docs/02_commands.md`).
* GEMM descriptor / record: tensor ABI v2 (`third_party/silicaflux-tensorcore08/docs/02_COMMAND_ABI.md`).
* Device memory: byte addresses, little-endian; the ControlCore, the tile and the tensor unit use the same
  addresses. No caches anywhere: completion means "every write acknowledged".

## 5. Versioning rules

* `MAP_VERSION` major changes on any incompatible address-map change; `gen_memmap.py --check` fails if the
  generated files are stale. Firmware checks `MAP_VERSION` against its compiled-in constant (self-test T1).
* Image header version 1; the ROM rejects other versions (`BOOT_ERR_HDR_VERSION`).
* Accelerator ABIs are versioned by the accelerators (tile `VERSION` 1.0, tensor `INFO[3:0] = 2`) and checked
  at discovery.
