// =============================================================================
// SilicaFlux ControlCore :: cc_sysctrl -- identity, resets, boot status, test port
//
// Register page CC_PG_SYSCTRL (map: config/cc_memmap.yaml, block cc_sysctrl).
// SilicaFlux-V register-bus contract: one-cycle rb_sel strobe, rb_rdata/rb_err
// combinational in the strobe cycle, side effects at the end of that cycle,
// rb_err = refused (no effect): unmapped offset, write to a read-only register,
// SOFT_RESET with a wrong key.
//
// Two reset domains:
//   POR domain (por_rst_n): RESET_CAUSE, RESET_COUNT, SCRATCH0..3 and the reset
//     stretcher.  Survives soft, watchdog and host resets.
//   SYS domain (rst_n): everything else (cleared by every system reset).
// Reset generator: a soft-reset write, a watchdog reset request (level) or a
// rising edge of the (synchronised) host reset request starts a
// CC_RESET_STRETCH-cycle pulse on sys_reset_req; the cause is OR-ed into
// RESET_CAUSE and RESET_COUNT increments.  The top level feeds sys_reset_req
// into the system reset synchroniser (async assert, sync release), so the
// requesting flops are cleared while the pulse is still held.
// =============================================================================
`default_nettype none

module cc_sysctrl
#(
  parameter logic [31:0] FEATURES   = 32'h0,
  parameter logic [31:0] ROM_BYTES  = 32'h0,
  parameter logic [31:0] IMEM_BYTES = 32'h0,
  parameter logic [31:0] DMEM_BYTES = 32'h0
) (
  input  wire logic        clk,
  input  wire logic        por_rst_n,
  input  wire logic        rst_n,
  // register bus
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // reset sources / generator
  input  wire logic [1:0]  boot_mode,        // synchronised straps
  input  wire logic        wdt_req,          // watchdog reset request (level, SYS domain)
  input  wire logic        host_rst_req,     // synchronised host reset request (edge-triggered)
  output logic             sys_reset_req,    // hold the SYS domain in reset
  // status pins
  output logic             host_ready,
  output logic             cmdproc_ready,
  output logic             test_done,
  output logic             test_fail,
  output logic [15:0]      test_code
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  localparam int unsigned STRETCH = CC_RESET_STRETCH;

  wire wr = rb_sel && rb_we;
  wire soft_req = wr && rb_addr == CC_SYSCTRL_SOFT_RESET && rb_wdata == CC_SOFT_RESET_KEY;

  // ------------------------------------------------------------ POR domain
  logic [3:0]  cause_q;
  logic [31:0] rcount_q;
  logic [31:0] scratch_q [4];
  logic [5:0]  str_q;
  logic        host_q;
  wire         host_edge = host_rst_req && !host_q;
  wire         any_req   = soft_req || wdt_req || host_edge;

  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      cause_q  <= CC_RESET_CAUSE_POR[3:0];
      rcount_q <= '0;
      str_q    <= '0;
      host_q   <= 1'b0;
      for (int i = 0; i < 4; i++) scratch_q[i] <= '0;
    end else begin
      host_q <= host_rst_req;
      if (str_q != 6'd0) begin
        str_q <= str_q - 6'd1;
      end else if (any_req) begin
        str_q    <= 6'(STRETCH);
        rcount_q <= rcount_q + 32'd1;
      end
      // cause: W1C first, then set (a new cause wins over a same-cycle clear)
      begin
        logic [3:0] c;
        c = cause_q;
        if (wr && rb_addr == CC_SYSCTRL_RESET_CAUSE) c = c & ~rb_wdata[3:0];
        if (str_q == 6'd0 && any_req)
          c = c | {host_edge, wdt_req, soft_req, 1'b0};
        cause_q <= c;
      end
      if (wr && rb_addr == CC_SYSCTRL_SCRATCH0) scratch_q[0] <= rb_wdata;
      if (wr && rb_addr == CC_SYSCTRL_SCRATCH1) scratch_q[1] <= rb_wdata;
      if (wr && rb_addr == CC_SYSCTRL_SCRATCH2) scratch_q[2] <= rb_wdata;
      if (wr && rb_addr == CC_SYSCTRL_SCRATCH3) scratch_q[3] <= rb_wdata;
    end
  end
  assign sys_reset_req = (str_q != 6'd0);

  // ------------------------------------------------------------ SYS domain
  logic [7:0]  stage_q;
  logic [31:0] bstat_q, fwver_q, test_q;
  logic [3:0]  hstat_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      stage_q <= '0; bstat_q <= '0; fwver_q <= '0; test_q <= '0; hstat_q <= '0;
    end else if (wr) begin
      case (rb_addr)
        CC_SYSCTRL_BOOT_STAGE:  stage_q <= rb_wdata[7:0];
        CC_SYSCTRL_BOOT_STATUS: bstat_q <= rb_wdata;
        CC_SYSCTRL_HOST_STATUS: hstat_q <= rb_wdata[3:0];
        CC_SYSCTRL_FW_VERSION:  fwver_q <= rb_wdata;
        CC_SYSCTRL_TEST_CTRL:   test_q  <= rb_wdata;
        default: ;
      endcase
    end
  end
  assign host_ready    = hstat_q[0];
  assign cmdproc_ready = hstat_q[1];
  assign test_done     = test_q[31];
  assign test_fail     = test_q[30];
  assign test_code     = test_q[15:0];

  // ------------------------------------------------------------ read / refuse
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      CC_SYSCTRL_ID:          begin rb_rdata = CC_SYSCTRL_ID_RST;         rb_err = rb_we; end
      CC_SYSCTRL_HW_VERSION:  begin rb_rdata = CC_SYSCTRL_HW_VERSION_RST; rb_err = rb_we; end
      CC_SYSCTRL_MAP_VERSION: begin rb_rdata = CC_MAP_VERSION;            rb_err = rb_we; end
      CC_SYSCTRL_FEATURES:    begin rb_rdata = FEATURES;                  rb_err = rb_we; end
      CC_SYSCTRL_ROM_BYTES:   begin rb_rdata = ROM_BYTES;                 rb_err = rb_we; end
      CC_SYSCTRL_IMEM_BYTES:  begin rb_rdata = IMEM_BYTES;                rb_err = rb_we; end
      CC_SYSCTRL_DMEM_BYTES:  begin rb_rdata = DMEM_BYTES;                rb_err = rb_we; end
      CC_SYSCTRL_RESET_CAUSE: rb_rdata = {28'd0, cause_q};
      CC_SYSCTRL_RESET_COUNT: begin rb_rdata = rcount_q;                  rb_err = rb_we; end
      CC_SYSCTRL_SOFT_RESET:  rb_err = !rb_we || (rb_wdata != CC_SOFT_RESET_KEY);
      CC_SYSCTRL_BOOT_MODE:   begin rb_rdata = {30'd0, boot_mode};        rb_err = rb_we; end
      CC_SYSCTRL_BOOT_STAGE:  rb_rdata = {24'd0, stage_q};
      CC_SYSCTRL_BOOT_STATUS: rb_rdata = bstat_q;
      CC_SYSCTRL_HOST_STATUS: rb_rdata = {28'd0, hstat_q};
      CC_SYSCTRL_FW_VERSION:  rb_rdata = fwver_q;
      CC_SYSCTRL_SCRATCH0:    rb_rdata = scratch_q[0];
      CC_SYSCTRL_SCRATCH1:    rb_rdata = scratch_q[1];
      CC_SYSCTRL_SCRATCH2:    rb_rdata = scratch_q[2];
      CC_SYSCTRL_SCRATCH3:    rb_rdata = scratch_q[3];
      CC_SYSCTRL_TEST_CTRL:   rb_rdata = test_q;
      default:                rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
