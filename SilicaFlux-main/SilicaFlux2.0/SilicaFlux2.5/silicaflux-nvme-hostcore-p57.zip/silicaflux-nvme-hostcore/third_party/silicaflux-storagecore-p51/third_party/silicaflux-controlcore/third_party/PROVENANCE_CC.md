# third_party -- provenance (all files unmodified)

Every file below `third_party/` is a byte-identical copy of a member of an archive in the Aureom.AI repository
(`btcphilosopher/Aureom.AI`, branch `claude/lucid-tesla-fm7wq6`, commit `8158b9d`). `SHA256SUMS` lists all 160
files. `python3 scripts/check_vendor.py --repo <path to Aureom.AI>` re-reads the original archives and compares
every file byte for byte (last run: **160 files, 0 problems**).

| Directory | Origin archive (repository path) | Archive SHA-256 | Used for |
|---|---|---|---|
| `silicaflux-mcu-i/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-mcu-i.zip` | `f2dd5bdac590883a3949c38a1973f32a8651c42bdc46569fee9f4d29f5013c23` | **CPU** `mcu_cpu` (RV32I[M]_Zicsr, riscv-tests evidence), `mcu_intc`, `mcu_wdt`, `mcu_dma`, `mcu_sram_bank`, `mcu_memmap_pkg` (register offsets of those blocks), CPU ISA testbench `tb/cpu/tb_cpu.sv`, MCU-I's CPU doc and recorded riscv-tests result |
| `silicaflux-v/` | same archive, `third_party/silicaflux-v/` (SilicaFlux-V release 1) | (as above) | `sfv_common` (reset/level synchronisers), `sfv_clkgate`, `sfv_periph_bridge` (register bus), `sfv_periph_misc` (`sfv_timer`), `sfv_mem_slaves` (`sfv_bootrom`), `gen_rom.py`, `bin2hex.py` |
| `silicaflux-datafabric/` | MCU-I and TENSORCORE 08 archives, `third_party/silicaflux-datafabric/` (identical where both carry a file) | (as above / below) | SFB2 crossbar, arbiter, decoders, register slice, skid buffer, v1 slave adapter, protocol docs; DMA engines used inside the accelerators |
| `silicaflux-sramlib/` | MCU-I and TENSORCORE 08 archives (identical) | | SRAM wrapper library (generic / FPGA / ASIC-leaf backends) for IMEM and DMEM |
| `silicaflux-tensorcore08/` | `SilicaFlux-main/silicaflux-tensorcore08.zip` | `be676860442cc1b670223b3ef9e59a9aeaed7d3998615a70b7aa2e9bf0c45f06` | **tensor unit** `silicaflux_tensor_unit` + `integration/sfx_hpc_tensor_system.sv` (the accelerator subsystem the ControlCore drives), C driver `tsu_driver.c`, ABI header `tsu_abi.h`, ABI / register-map docs |
| `silicaflux-tensorcore02..07/`, `silicaflux-hpc-m04-scratchpad/` | same TENSORCORE 08 archive, `third_party/` | | systolic array, operand buffers, accumulator, quantiser, tile iterator, tensor DMA adapter, scratchpad |
| `silicaflux-hpc-m08-tile/rtl`, `docs/02..03`, `third_party/` | same TENSORCORE 08 archive, `third_party/silicaflux-hpc-m08-tile/` | | **FP32 vector tile** `silicaflux_hpc_tile` (vector array, scratchpad, tile DMA, command queue, counters) |
| `silicaflux-hpc-m08-tile/sw/`, `docs/06_host_software.md` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m08-tile.zip` | `fa2e5a893f637c8f4152d8252754df063b4e6a0fdc901448453f2fe6040ee3f8` | tile C driver `silicaflux_hpc.c`, generated register header `hpc_tile_regs.h` |

Each of those projects documents its own verification evidence and limitations in its archive (MCU-I
`reports/SUMMARY.md`, TENSORCORE 08 `README.md` / `reports/`, HPC Module 08 `README.md` / `reports/`). The
ControlCore re-ran the CPU's riscv-tests here (`reports/isa/`) and exercises the accelerators through their real
register ABIs (`reports/regression.md`); it does not re-run the accelerators' own unit regressions.

License: the source repository contains no license file; these are internal Aureom.AI sources. The owner must
add a license before any external distribution. riscv-tests (BSD-licensed, riscv-software-src) is fetched by
`scripts/run_riscv_tests.sh` into `deps/`, not redistributed.
