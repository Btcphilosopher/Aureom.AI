# third_party — provenance

Everything under `third_party/` is **reused, unmodified** SilicaFlux source, copied from the archives in the
`btcphilosopher/Aureom.AI` repository (commit `e1f75e3`). `scripts/check_vendor.py --repo <checkout>` compares every
file byte for byte with the archive member and rewrites `SHA256SUMS` (last run: 69/69 identical).

| Directory | Archive | Project | Used for |
|---|---|---|---|
| `silicaflux-controlcore/rtl/` (+ `rtl/generated/`) | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-controlcore.zip` | Project 21 ControlCore | the SoC's control processor subsystem |
| `silicaflux-controlcore/third_party/{silicaflux-mcu-i, silicaflux-v, silicaflux-datafabric, silicaflux-sramlib}` | same archive (its own vendored copies, already verified there against MCU-I, SilicaFlux-V, DataFabric, SRAMLIB) | MCU-I, SilicaFlux-V, DataFabric, SRAMLIB | CPU, INTC, WDT, DMA, SRAM banks, register bridge, synchronisers, SFB2 crossbar, SRAM slave |
| `silicaflux-controlcore/firmware/{common,include,bootrom}` | same archive | Project 21 | firmware runtime (crt0, trap entry, link script, CRC32, headers) and boot ROM sources |
| `silicaflux-controlcore/scripts/{mkimage.py, generated/cc_memmap.py}` | same archive | Project 21 | firmware image builder (header + CRC32) |
| `silicaflux-controlcore/config/`, `docs/`, `README.md` | same archive | Project 21 | reference: address map, HW/SW interface |
| `silicaflux-ras/rtl/sfras_{secded_enc,secded_dec,ecc_funcs,defs,ecc_sram,sfb_ecc_slave}` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-ras-project26.zip` | Project 26 RAS | NAND page SECDED, ECC buffer SRAM |

`silicaflux-controlcore/third_party/PROVENANCE_CC.md` is the ControlCore's own provenance record (renamed only to
avoid a name clash). The repository contains no licence file; reuse here is within the same repository owner's
project family.
