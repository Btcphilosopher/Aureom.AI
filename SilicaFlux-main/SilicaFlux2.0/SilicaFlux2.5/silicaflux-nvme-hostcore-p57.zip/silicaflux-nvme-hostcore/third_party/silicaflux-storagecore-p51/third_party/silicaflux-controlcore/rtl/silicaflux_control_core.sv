// =============================================================================
// SilicaFlux-HPC :: silicaflux_control_core -- ControlCore (Project 21)
//
// Embedded control subsystem: initialises the chip, runs control firmware,
// configures the FP32 vector tile and the INT8 tensor unit, supervises DMA,
// handles interrupts, exposes status to the host and recovers from supported
// errors.  Deterministic on-chip orchestration, not an application processor.
//
//   mcu_cpu RV32IM_Zicsr (I) ─┐                                   ┌─ s0 BOOTROM  sfv_bootrom (8 KiB)
//   mcu_cpu RV32IM_Zicsr (D) ─┤                                   ├─ s1 IMEM     mcu_sram_bank (64 KiB, parity)
//   host port ─ cc_sfb_gate ──┼─ sfb_crossbar (SFB2, round robin) ┼─ s2 DMEM     mcu_sram_bank (32 KiB, parity)
//   mcu_dma (system DMA) ─────┘                                   ├─ s3 PERIPH   reg slice ─ v1 adapter ─ sfv_periph_bridge
//                                                                 └─ s4 EXT      cc_sfb_gate (isolation) ─ ext_* port
//   register pages: 0 SYSCTRL 1 INTC 2 MTIMER 3 WDT 4 DMA 5 MAILBOX 6 PERF 7 PMU
//                   8..15 -> acc_rb_* (8 vector tile, 9 tensor unit)  16 RAS  17 SECURITY
//
// Address map, register offsets, IRQ numbers: cc_memmap_pkg, GENERATED from
// config/cc_memmap.yaml (scripts/gen_memmap.py).  Reused blocks are vendored
// unmodified under third_party/ (SHA256SUMS, PROVENANCE.md).
//
// Clock: ONE functional clock `clk`.  The accelerator subsystem gets acc_clk_o,
// an ICG-gated copy (sfv_clkgate) controlled by cc_pmu (pass-through with
// SFV_NO_CLOCK_GATE on FPGA).  Everything is synchronous to clk.
// Resets (async assert, sync release; bypassed to rst_ni in test_mode):
//   por_rst_n  <- rst_ni                                    POR domain (reset cause, scratch)
//   sys_rst_n  <- por & !(soft | watchdog | host request)   CPU, bus, memories' control, peripherals
//   acc_rst_no <- sys & !PMU.ACC_CTRL.RST                   accelerator subsystem
// Inputs from other clock domains or pins (boot_mode_i, host_rst_req_i,
// ext_warn_i, ext_fatal_i) pass 2-flop synchronisers.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module silicaflux_control_core
#(
  parameter int          RV32M            = 1,            // 0: RV32I, 1: RV32IM iterative (default), 2: fast MUL
  parameter int          SRAM_PARITY      = 1,
  parameter int          SRAM_BACKEND     = `SRAM_BACKEND_GENERIC,
  parameter int          DMA_MAX_LEN_LOG2 = 20,
  parameter logic [31:0] MIMPID           = 32'h0021_0001  // mimpid: Project 21, implementation 1
) (
  input  wire logic        clk,
  input  wire logic        rst_ni,
  input  wire logic        test_mode,
  input  wire logic [1:0]  boot_mode_i,
  input  wire logic        host_rst_req_i,
  // ------------------------------------------------ host access port (SFB2 slave)
  input  wire logic        hs_req_valid,
  output logic             hs_req_ready,
  input  wire logic        hs_req_write,
  input  wire logic [31:0] hs_req_addr,
  input  wire logic [31:0] hs_req_wdata,
  input  wire logic [3:0]  hs_req_wstrb,
  output logic             hs_rsp_valid,
  input  wire logic        hs_rsp_ready,
  output logic [31:0]      hs_rsp_rdata,
  output logic             hs_rsp_error,
  output logic             host_irq_o,
  output logic             host_ready_o,
  output logic             cmdproc_ready_o,
  output logic             ras_fatal_o,
  // ------------------------------------------------ accelerator register port (rb master, 16 pages)
  output logic             acc_rb_sel,
  output logic             acc_rb_we,
  output logic [15:0]      acc_rb_addr,
  output logic [31:0]      acc_rb_wdata,
  input  wire logic [31:0] acc_rb_rdata,
  input  wire logic        acc_rb_err,
  // ------------------------------------------------ external data port (SFB2 master)
  output logic             ext_req_valid,
  input  wire logic        ext_req_ready,
  output logic             ext_req_write,
  output logic [31:0]      ext_req_addr,
  output logic [31:0]      ext_req_wdata,
  output logic [3:0]       ext_req_wstrb,
  input  wire logic        ext_rsp_valid,
  output logic             ext_rsp_ready,
  input  wire logic [31:0] ext_rsp_rdata,
  input  wire logic        ext_rsp_error,
  // ------------------------------------------------ accelerator domain control / status
  output logic             acc_clk_o,
  output logic             acc_rst_no,
  input  wire logic        acc_vec_irq_i,
  input  wire logic        acc_tsu_irq_i,
  input  wire logic        acc_vec_busy_i,
  input  wire logic        acc_tsu_busy_i,
  input  wire logic        acc_tsu_halted_i,
  // ------------------------------------------------ SoC RAS inputs
  input  wire logic        ext_warn_i,
  input  wire logic        ext_fatal_i,
  // ------------------------------------------------ diagnostics
  output logic             diag_valid_o,
  output logic [7:0]       diag_char_o,
  output logic             test_done_o,
  output logic             test_fail_o,
  output logic [15:0]      test_code_o,
  output logic             cpu_sleep_o
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  // ================================================================ sizes
  localparam int ROM_WORDS  = CC_BOOTROM_SIZE / 4;
  localparam int IMEM_WORDS = CC_IMEM_SIZE / 4;
  localparam int DMEM_WORDS = CC_DMEM_SIZE / 4;
  localparam int NM = CC_XBAR_NM, NS = CC_XBAR_NS, NP = 32;
  localparam int MI = CC_M_CPU_I, MD = CC_M_CPU_D, MH = CC_M_HOST, MA = CC_M_DMA;
  localparam int S_ROM = CC_S_BOOTROM, S_IM = CC_S_IMEM, S_DM = CC_S_DMEM;
  localparam int S_PER = CC_S_PERIPH, S_EXT = CC_S_EXT;
  localparam logic [31:0] FEATURES = 32'(RV32M != 0) | (32'(SRAM_PARITY != 0) << 1) | (32'd1 << 2) |
                                     (32'd1 << 3) | (32'd1 << 4) | (32'd1 << 5) | (32'd1 << 6);

  // ================================================================ resets and synchronisers
  logic por_rst_n, sys_rst_n, acc_rst_n, sys_reset_req, acc_rst_req;
  sfv_rst_sync u_rs_por (.clk, .rst_ni(rst_ni), .test_mode, .test_rst_ni(rst_ni), .rst_no(por_rst_n));
  sfv_rst_sync u_rs_sys (.clk, .rst_ni(por_rst_n && !sys_reset_req), .test_mode, .test_rst_ni(rst_ni),
                         .rst_no(sys_rst_n));
  sfv_rst_sync u_rs_acc (.clk, .rst_ni(sys_rst_n && !acc_rst_req), .test_mode, .test_rst_ni(rst_ni),
                         .rst_no(acc_rst_n));
  assign acc_rst_no = acc_rst_n;

  logic [1:0] boot_mode_s;
  logic       host_rst_s, ext_warn_s, ext_fatal_s;
  sfv_sync u_sy_bm0 (.clk, .rst_n(por_rst_n), .d(boot_mode_i[0]), .q(boot_mode_s[0]));
  sfv_sync u_sy_bm1 (.clk, .rst_n(por_rst_n), .d(boot_mode_i[1]), .q(boot_mode_s[1]));
  sfv_sync u_sy_hr  (.clk, .rst_n(por_rst_n), .d(host_rst_req_i), .q(host_rst_s));
  sfv_sync u_sy_ew  (.clk, .rst_n(sys_rst_n), .d(ext_warn_i), .q(ext_warn_s));
  sfv_sync u_sy_ef  (.clk, .rst_n(sys_rst_n), .d(ext_fatal_i), .q(ext_fatal_s));

  // ================================================================ crossbar
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*32-1:0] s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [NS*4-1:0]  s_req_wstrb;
  logic             dec_evt, dec_write;
  logic [31:0]      dec_addr;
  logic [1:0]       dec_master;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]    ev_acc_u, ev_stall_u, ev_loss_u, ev_rstall_u;
  /* verilator lint_on UNUSEDSIGNAL */

  sfb_crossbar #(
    .NM(NM), .NS(NS), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE(CC_XBAR_BASE), .SLV_MASK(CC_XBAR_MASK), .MST_SLV_EN(CC_XBAR_EN)
  ) u_xbar (
    .clk, .rst_n(sys_rst_n),
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(dec_evt), .err_addr(dec_addr), .err_master(dec_master), .err_write(dec_write),
    .ev_req_accept(ev_acc_u), .ev_req_stall(ev_stall_u), .ev_arb_loss(ev_loss_u), .ev_rsp_stall(ev_rstall_u)
  );

  // ================================================================ CPU (SFB v1 masters: rsp_ready = 1)
  logic irq_ext, irq_timer, irq_soft, cpu_sleep, cpu_bus_idle;
  logic [31:0] cpu_i_addr;
  /* verilator lint_off PINCONNECTEMPTY */
  mcu_cpu #(.BOOT_ADDR(CC_BOOTROM_BASE), .RV32M(RV32M), .MIMPID(MIMPID)) u_cpu (
    .clk, .rst_n(sys_rst_n),
    .i_req(m_req_valid[MI]), .i_gnt(m_req_ready[MI]), .i_addr(cpu_i_addr), .i_rvalid(m_rsp_valid[MI]),
    .i_rdata(m_rsp_rdata[MI*32 +: 32]), .i_err(m_rsp_error[MI]),
    .d_req(m_req_valid[MD]), .d_gnt(m_req_ready[MD]), .d_addr(m_req_addr[MD*32 +: 32]),
    .d_we(m_req_write[MD]), .d_be(m_req_wstrb[MD*4 +: 4]), .d_wdata(m_req_wdata[MD*32 +: 32]),
    .d_rvalid(m_rsp_valid[MD]), .d_rdata(m_rsp_rdata[MD*32 +: 32]), .d_err(m_rsp_error[MD]),
    .irq_ext, .irq_timer, .irq_soft, .sleeping(cpu_sleep), .bus_idle(cpu_bus_idle),
    .rt_valid(), .rt_pc(), .rt_insn(), .rt_trap(), .rt_cause(), .rt_rd(), .rt_rd_wdata(), .rt_rd_we()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  wire unused_cpu = cpu_bus_idle;
  assign m_req_addr[MI*32 +: 32]  = cpu_i_addr;
  assign m_req_write[MI]          = 1'b0;
  assign m_req_wstrb[MI*4 +: 4]   = 4'b1111;
  assign m_req_wdata[MI*32 +: 32] = 32'd0;
  assign m_rsp_ready[MI]          = 1'b1;
  assign m_rsp_ready[MD]          = 1'b1;
  assign cpu_sleep_o              = cpu_sleep;

  // ================================================================ host port + write lock
  logic host_lock, host_viol;
  /* verilator lint_off UNUSEDSIGNAL */
  logic host_idle_u;
  /* verilator lint_on UNUSEDSIGNAL */
  function automatic logic in_region(input logic [31:0] a, input logic [31:0] base, input logic [31:0] size);
    in_region = (a & ~(size - 32'd1)) == base;
  endfunction
  // the host port stalls (ready = 0) until the system domain is out of reset:
  // a request is never accepted by logic that is still being reset
  logic sys_up_q, hs_ready_g;
  always_ff @(posedge clk or negedge sys_rst_n) begin
    if (!sys_rst_n) sys_up_q <= 1'b0;
    else            sys_up_q <= 1'b1;
  end
  assign hs_req_ready = hs_ready_g && sys_up_q;
  wire host_refuse = host_lock && hs_req_write &&
                     (in_region(hs_req_addr, CC_BOOTROM_BASE, CC_BOOTROM_SIZE) ||
                      in_region(hs_req_addr, CC_IMEM_BASE, CC_IMEM_SIZE) ||
                      in_region(hs_req_addr, CC_DMEM_BASE, CC_DMEM_SIZE));
  cc_sfb_gate u_host_gate (
    .clk, .rst_n(sys_rst_n),
    .s_req_valid(hs_req_valid && sys_up_q), .s_req_ready(hs_ready_g), .s_req_write(hs_req_write), .s_req_addr(hs_req_addr),
    .s_req_wdata(hs_req_wdata), .s_req_wstrb(hs_req_wstrb), .s_rsp_valid(hs_rsp_valid), .s_rsp_ready(hs_rsp_ready),
    .s_rsp_rdata(hs_rsp_rdata), .s_rsp_error(hs_rsp_error),
    .m_req_valid(m_req_valid[MH]), .m_req_ready(m_req_ready[MH]), .m_req_write(m_req_write[MH]),
    .m_req_addr(m_req_addr[MH*32 +: 32]), .m_req_wdata(m_req_wdata[MH*32 +: 32]), .m_req_wstrb(m_req_wstrb[MH*4 +: 4]),
    .m_rsp_valid(m_rsp_valid[MH]), .m_rsp_ready(m_rsp_ready[MH]), .m_rsp_rdata(m_rsp_rdata[MH*32 +: 32]),
    .m_rsp_error(m_rsp_error[MH]),
    .refuse(host_refuse), .refused_evt(host_viol), .idle(host_idle_u)
  );

  // ================================================================ boot ROM (s0)
  logic rom_req, rom_gnt, rom_we, rom_rvalid, rom_err;
  logic [31:0] rom_addr, rom_wdata, rom_rdata;
  logic [3:0]  rom_be;
  sfb_v1_slave_adapter u_rom_ad (
    .clk, .rst_n(sys_rst_n),
    .req_valid(s_req_valid[S_ROM]), .req_ready(s_req_ready[S_ROM]), .req_write(s_req_write[S_ROM]),
    .req_addr(s_req_addr[S_ROM*32 +: 32]), .req_wdata(s_req_wdata[S_ROM*32 +: 32]),
    .req_wstrb(s_req_wstrb[S_ROM*4 +: 4]), .rsp_valid(s_rsp_valid[S_ROM]), .rsp_ready(s_rsp_ready[S_ROM]),
    .rsp_rdata(s_rsp_rdata[S_ROM*32 +: 32]), .rsp_error(s_rsp_error[S_ROM]),
    .v1_req(rom_req), .v1_gnt(rom_gnt), .v1_addr(rom_addr), .v1_we(rom_we), .v1_be(rom_be),
    .v1_wdata(rom_wdata), .v1_rvalid(rom_rvalid), .v1_rdata(rom_rdata), .v1_err(rom_err)
  );
  sfv_bootrom #(.WORDS(ROM_WORDS)) u_rom (
    .clk, .rst_n(sys_rst_n),
    .req(rom_req), .gnt(rom_gnt), .addr(rom_addr), .we(rom_we), .be(rom_be), .wdata(rom_wdata),
    .rvalid(rom_rvalid), .rdata(rom_rdata), .err(rom_err)
  );

  // ================================================================ IMEM (s1) / DMEM (s2)
  logic par_chk_en, par_inject, par_evt_i, par_evt_d;
  logic [31:0] par_addr_i, par_addr_d;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] tst_rd_i_u, tst_rd_d_u;
  /* verilator lint_on UNUSEDSIGNAL */
  mcu_sram_bank #(.DEPTH(IMEM_WORDS), .PARITY(SRAM_PARITY), .READ_LATENCY(1), .BACKEND(SRAM_BACKEND)) u_imem (
    .clk, .rst_n(sys_rst_n),
    .req_valid(s_req_valid[S_IM]), .req_ready(s_req_ready[S_IM]), .req_write(s_req_write[S_IM]),
    .req_addr(s_req_addr[S_IM*32 +: 32]), .req_wdata(s_req_wdata[S_IM*32 +: 32]), .req_wstrb(s_req_wstrb[S_IM*4 +: 4]),
    .rsp_valid(s_rsp_valid[S_IM]), .rsp_ready(s_rsp_ready[S_IM]), .rsp_rdata(s_rsp_rdata[S_IM*32 +: 32]),
    .rsp_error(s_rsp_error[S_IM]),
    .chk_en(par_chk_en), .inject(par_inject), .par_evt(par_evt_i), .par_addr(par_addr_i),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rd_i_u)
  );
  mcu_sram_bank #(.DEPTH(DMEM_WORDS), .PARITY(SRAM_PARITY), .READ_LATENCY(1), .BACKEND(SRAM_BACKEND)) u_dmem (
    .clk, .rst_n(sys_rst_n),
    .req_valid(s_req_valid[S_DM]), .req_ready(s_req_ready[S_DM]), .req_write(s_req_write[S_DM]),
    .req_addr(s_req_addr[S_DM*32 +: 32]), .req_wdata(s_req_wdata[S_DM*32 +: 32]), .req_wstrb(s_req_wstrb[S_DM*4 +: 4]),
    .rsp_valid(s_rsp_valid[S_DM]), .rsp_ready(s_rsp_ready[S_DM]), .rsp_rdata(s_rsp_rdata[S_DM*32 +: 32]),
    .rsp_error(s_rsp_error[S_DM]),
    .chk_en(par_chk_en), .inject(par_inject), .par_evt(par_evt_d), .par_addr(par_addr_d),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rd_d_u)
  );
  wire mem_write = (s_req_valid[S_IM] && s_req_ready[S_IM] && s_req_write[S_IM]) ||
                   (s_req_valid[S_DM] && s_req_ready[S_DM] && s_req_write[S_DM]);

  // ================================================================ external data port (s4) + isolation
  logic acc_iso, ext_idle, ext_refused;
  cc_sfb_gate u_ext_gate (
    .clk, .rst_n(sys_rst_n),
    .s_req_valid(s_req_valid[S_EXT]), .s_req_ready(s_req_ready[S_EXT]), .s_req_write(s_req_write[S_EXT]),
    .s_req_addr(s_req_addr[S_EXT*32 +: 32]), .s_req_wdata(s_req_wdata[S_EXT*32 +: 32]),
    .s_req_wstrb(s_req_wstrb[S_EXT*4 +: 4]), .s_rsp_valid(s_rsp_valid[S_EXT]), .s_rsp_ready(s_rsp_ready[S_EXT]),
    .s_rsp_rdata(s_rsp_rdata[S_EXT*32 +: 32]), .s_rsp_error(s_rsp_error[S_EXT]),
    .m_req_valid(ext_req_valid), .m_req_ready(ext_req_ready), .m_req_write(ext_req_write),
    .m_req_addr(ext_req_addr), .m_req_wdata(ext_req_wdata), .m_req_wstrb(ext_req_wstrb),
    .m_rsp_valid(ext_rsp_valid), .m_rsp_ready(ext_rsp_ready), .m_rsp_rdata(ext_rsp_rdata),
    .m_rsp_error(ext_rsp_error),
    .refuse(acc_iso), .refused_evt(ext_refused), .idle(ext_idle)
  );

  // ================================================================ peripheral window (s3)
  logic        ps_req_valid, ps_req_ready, ps_req_write, ps_rsp_valid, ps_rsp_ready, ps_rsp_error;
  logic [31:0] ps_req_addr, ps_req_wdata, ps_rsp_rdata;
  logic [3:0]  ps_req_wstrb;
  sfb_reg_slice #(.AW(32), .DW(32), .REQ_SLICE(1), .RSP_SLICE(0)) u_per_slice (
    .clk, .rst_n(sys_rst_n),
    .s_req_valid(s_req_valid[S_PER]), .s_req_ready(s_req_ready[S_PER]), .s_req_write(s_req_write[S_PER]),
    .s_req_addr(s_req_addr[S_PER*32 +: 32]), .s_req_wdata(s_req_wdata[S_PER*32 +: 32]),
    .s_req_wstrb(s_req_wstrb[S_PER*4 +: 4]), .s_rsp_valid(s_rsp_valid[S_PER]), .s_rsp_ready(s_rsp_ready[S_PER]),
    .s_rsp_rdata(s_rsp_rdata[S_PER*32 +: 32]), .s_rsp_error(s_rsp_error[S_PER]),
    .m_req_valid(ps_req_valid), .m_req_ready(ps_req_ready), .m_req_write(ps_req_write),
    .m_req_addr(ps_req_addr), .m_req_wdata(ps_req_wdata), .m_req_wstrb(ps_req_wstrb),
    .m_rsp_valid(ps_rsp_valid), .m_rsp_ready(ps_rsp_ready), .m_rsp_rdata(ps_rsp_rdata), .m_rsp_error(ps_rsp_error)
  );
  logic pb_req, pb_gnt, pb_we, pb_rvalid, pb_err;
  logic [31:0] pb_addr, pb_wdata, pb_rdata;
  logic [3:0]  pb_be;
  sfb_v1_slave_adapter u_per_ad (
    .clk, .rst_n(sys_rst_n),
    .req_valid(ps_req_valid), .req_ready(ps_req_ready), .req_write(ps_req_write),
    .req_addr(ps_req_addr), .req_wdata(ps_req_wdata), .req_wstrb(ps_req_wstrb),
    .rsp_valid(ps_rsp_valid), .rsp_ready(ps_rsp_ready), .rsp_rdata(ps_rsp_rdata), .rsp_error(ps_rsp_error),
    .v1_req(pb_req), .v1_gnt(pb_gnt), .v1_addr(pb_addr), .v1_we(pb_we), .v1_be(pb_be),
    .v1_wdata(pb_wdata), .v1_rvalid(pb_rvalid), .v1_rdata(pb_rdata), .v1_err(pb_err)
  );
  logic [NP-1:0]    rb_sel, rb_err;
  logic             rb_we;
  logic [11:0]      rb_addr;
  logic [31:0]      rb_wdata;
  logic [NP*32-1:0] rb_rdata;
  sfv_periph_bridge #(.NP(NP), .PAGE_EN(CC_PAGE_EN)) u_pbr (
    .clk, .rst_n(sys_rst_n),
    .req(pb_req), .gnt(pb_gnt), .addr(pb_addr), .we(pb_we), .be(pb_be), .wdata(pb_wdata),
    .rvalid(pb_rvalid), .rdata(pb_rdata), .err(pb_err),
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err
  );
  // peripheral-error snoop for RAS (one transaction per slave port)
  logic [31:0] per_addr_q;
  always_ff @(posedge clk or negedge sys_rst_n) begin
    if (!sys_rst_n)                                        per_addr_q <= '0;
    else if (s_req_valid[S_PER] && s_req_ready[S_PER])     per_addr_q <= s_req_addr[S_PER*32 +: 32];
  end
  wire per_evt = s_rsp_valid[S_PER] && s_rsp_ready[S_PER] && s_rsp_error[S_PER];

  localparam int P_SC = CC_PG_SYSCTRL, P_IC = CC_PG_INTC, P_MT = CC_PG_MTIMER;
  localparam int P_WD = CC_PG_WDT, P_DM = CC_PG_DMA, P_MB = CC_PG_MAILBOX;
  localparam int P_PF = CC_PG_PERF, P_PM = CC_PG_PMU, P_RS = CC_PG_RAS;
  localparam int P_SE = CC_PG_SECURITY;

  // pages without a block answer with a bus error (the bridge already refuses
  // pages outside CC_PAGE_EN; this covers the defaults of the rdata/err vectors)
  genvar gp;
  for (gp = 0; gp < NP; gp++) begin : g_page
    if (!CC_PAGE_EN[gp]) begin : g_absent
      assign rb_rdata[gp*32 +: 32] = 32'd0;
      assign rb_err[gp]            = 1'b1;
    end
  end

  // ---------------------------------------------------------------- accelerator pages 8..15 (forwarded)
  logic [2:0] fidx;
  always_comb begin
    fidx = 3'd0;
    for (int i = 0; i < 8; i++) if (rb_sel[8 + i]) fidx = 3'(i);
  end
  wire any_fwd    = |rb_sel[15:8];
  wire iso_rb_evt = any_fwd && acc_iso;
  assign acc_rb_sel   = any_fwd && !acc_iso;
  assign acc_rb_we    = rb_we;
  assign acc_rb_addr  = {1'b1, fidx, rb_addr};
  assign acc_rb_wdata = rb_wdata;
  for (gp = 8; gp < 16; gp++) begin : g_fwd
    assign rb_rdata[gp*32 +: 32] = acc_iso ? 32'd0 : acc_rb_rdata;
    assign rb_err[gp]            = acc_iso || acc_rb_err;
  end

  // ---------------------------------------------------------------- interrupt sources
  logic irq_fatal, irq_warn, irq_wdt, irq_dma, irq_host, dma_busy, dma_err_evt;
  logic [15:0] irq_src;
  always_comb begin
    irq_src = '0;
    irq_src[CC_IRQ_FATAL]    = irq_fatal;
    irq_src[CC_IRQ_WDT]      = irq_wdt;
    irq_src[CC_IRQ_RAS_WARN] = irq_warn;
    irq_src[CC_IRQ_DMA]      = irq_dma;
    irq_src[CC_IRQ_TENSOR]   = acc_tsu_irq_i && !acc_iso;
    irq_src[CC_IRQ_VECTOR]   = acc_vec_irq_i && !acc_iso;
    irq_src[CC_IRQ_HOST]     = irq_host;
  end

  // ---------------------------------------------------------------- page 0: SYSCTRL
  logic wdt_req;
  cc_sysctrl #(.FEATURES(FEATURES), .ROM_BYTES(CC_BOOTROM_SIZE), .IMEM_BYTES(CC_IMEM_SIZE),
               .DMEM_BYTES(CC_DMEM_SIZE)) u_sysctrl (
    .clk, .por_rst_n, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_SC]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_SC*32 +: 32]), .rb_err(rb_err[P_SC]),
    .boot_mode(boot_mode_s), .wdt_req, .host_rst_req(host_rst_s), .sys_reset_req,
    .host_ready(host_ready_o), .cmdproc_ready(cmdproc_ready_o),
    .test_done(test_done_o), .test_fail(test_fail_o), .test_code(test_code_o)
  );

  // ---------------------------------------------------------------- page 1: INTC (reused)
  mcu_intc #(.N(16)) u_intc (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_IC]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_IC*32 +: 32]), .rb_err(rb_err[P_IC]),
    .src(irq_src), .irq_ext
  );

  // ---------------------------------------------------------------- page 2: MTIMER (reused)
  sfv_timer u_mtimer (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_MT]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_MT*32 +: 32]), .rb_err(rb_err[P_MT]),
    .irq_timer, .irq_soft
  );

  // ---------------------------------------------------------------- page 3: WDT (reused)
  mcu_wdt u_wdt (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_WD]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_WD*32 +: 32]), .rb_err(rb_err[P_WD]),
    .dbg_halt(1'b0), .irq_ewi(irq_wdt), .reset_req(wdt_req)
  );

  // ---------------------------------------------------------------- page 4: DMA (reused) + master m3
  mcu_dma #(.MAX_LEN_LOG2(DMA_MAX_LEN_LOG2), .DREQ_MASK(16'h0000), .PER_BASE(CC_PERIPH_BASE),
            .PER_MASK(~(CC_PERIPH_SIZE - 32'd1))) u_dma (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_DM]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_DM*32 +: 32]), .rb_err(rb_err[P_DM]),
    .irq(irq_dma), .dreq(16'h0000),
    .req_valid(m_req_valid[MA]), .req_ready(m_req_ready[MA]), .req_write(m_req_write[MA]),
    .req_addr(m_req_addr[MA*32 +: 32]), .req_wdata(m_req_wdata[MA*32 +: 32]), .req_wstrb(m_req_wstrb[MA*4 +: 4]),
    .rsp_valid(m_rsp_valid[MA]), .rsp_ready(m_rsp_ready[MA]), .rsp_rdata(m_rsp_rdata[MA*32 +: 32]),
    .rsp_error(m_rsp_error[MA]),
    .busy(dma_busy), .err_evt(dma_err_evt)
  );

  // ---------------------------------------------------------------- page 5: MAILBOX
  cc_mailbox u_mbox (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_MB]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_MB*32 +: 32]), .rb_err(rb_err[P_MB]),
    .irq_h2f(irq_host), .host_irq(host_irq_o), .diag_valid(diag_valid_o), .diag_char(diag_char_o)
  );

  // ---------------------------------------------------------------- page 6: PERF
  localparam int NEV = 20;
  localparam logic [31:0] EDGE = (32'd1 << CC_PERF_EV_IRQ_EXT) | (32'd1 << CC_PERF_EV_IRQ_TIMER) |
                                 (32'h7F << CC_PERF_EV_SRC_FATAL);
  logic [NEV-1:0] pev;
  wire [1:0] nbusy = 2'(acc_vec_busy_i) + 2'(acc_tsu_busy_i) + 2'(dma_busy);
  always_comb begin
    pev = '0;
    pev[CC_PERF_EV_CPU_SLEEP]   = cpu_sleep;
    pev[CC_PERF_EV_VEC_BUSY]    = acc_vec_busy_i;
    pev[CC_PERF_EV_TSU_BUSY]    = acc_tsu_busy_i;
    pev[CC_PERF_EV_DMA_BUSY]    = dma_busy;
    pev[CC_PERF_EV_ACC_OVERLAP] = nbusy >= 2'd2;
    pev[CC_PERF_EV_EXT_REQ]     = ext_req_valid && ext_req_ready;
    pev[CC_PERF_EV_EXT_STALL]   = ext_req_valid && !ext_req_ready;
    pev[CC_PERF_EV_HOST_REQ]    = hs_req_valid && hs_req_ready;
    pev[CC_PERF_EV_IRQ_EXT]     = irq_ext;
    pev[CC_PERF_EV_IRQ_TIMER]   = irq_timer;
    pev[CC_PERF_EV_ACC_RB]      = acc_rb_sel;
    pev[CC_PERF_EV_BUS_ERR]     = dec_evt;
    for (int i = 0; i < 7; i++) pev[CC_PERF_EV_SRC_FATAL + i] = irq_src[i];
    pev[CC_PERF_EV_ISO_REFUSED] = iso_rb_evt || ext_refused;
  end
  cc_perf #(.NEV(NEV), .EDGE(EDGE)) u_perf (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_PF]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_PF*32 +: 32]), .rb_err(rb_err[P_PF]),
    .ev(pev)
  );

  // ---------------------------------------------------------------- page 7: PMU
  logic acc_clk_en, fatal_iso;
  cc_pmu u_pmu (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_PM]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_PM*32 +: 32]), .rb_err(rb_err[P_PM]),
    .cpu_sleep, .vec_busy(acc_vec_busy_i), .tsu_busy(acc_tsu_busy_i), .tsu_halted(acc_tsu_halted_i),
    .ext_idle, .fatal_iso, .acc_in_reset(!acc_rst_n),
    .acc_clk_en, .acc_rst_req, .acc_iso
  );
  sfv_clkgate u_cg_acc (.clk, .en(acc_clk_en), .test_en(test_mode), .gclk(acc_clk_o));

  // ---------------------------------------------------------------- page 16: RAS
  // Instruction-fetch decode errors are NOT RAS events: they are precise
  // instruction access faults of the CPU.  Reporting them as an interrupt would
  // livelock: the CPU takes a pending interrupt before the faulting
  // instruction's exception, and the re-fetch after MRET raises the event again.
  // (Found by the T3 self-test; perf BUS_ERR still counts every decode error.)
  wire dec_evt_ras = dec_evt && (dec_master != 2'(CC_M_CPU_I));
  cc_ras u_ras (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_RS]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_RS*32 +: 32]), .rb_err(rb_err[P_RS]),
    .ev_bus_decode(dec_evt_ras), .ev_bus_decode_addr(dec_addr),
    .ev_periph_err(per_evt), .ev_periph_err_addr(per_addr_q),
    .ev_dma_err(dma_err_evt),
    .ev_host_viol(host_viol), .ev_host_viol_addr(hs_req_addr),
    .ev_iso_access(iso_rb_evt || ext_refused),
    .ev_parity(par_evt_i || par_evt_d), .ev_parity_addr(par_evt_i ? par_addr_i : par_addr_d),
    .lv_ext_warn(ext_warn_s), .lv_ext_fatal(ext_fatal_s), .lv_tsu_halted(acc_tsu_halted_i && acc_rst_n),
    .mem_write,
    .irq_warn, .irq_fatal, .fatal_pin(ras_fatal_o), .fatal_iso, .par_inject, .par_chk_en
  );

  // ---------------------------------------------------------------- page 17: SECURITY
  cc_secmon u_sec (
    .clk, .rst_n(sys_rst_n),
    .rb_sel(rb_sel[P_SE]), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rb_rdata[P_SE*32 +: 32]), .rb_err(rb_err[P_SE]),
    .viol_evt(host_viol), .viol_addr(hs_req_addr), .host_lock
  );

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_dec = dec_write;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
