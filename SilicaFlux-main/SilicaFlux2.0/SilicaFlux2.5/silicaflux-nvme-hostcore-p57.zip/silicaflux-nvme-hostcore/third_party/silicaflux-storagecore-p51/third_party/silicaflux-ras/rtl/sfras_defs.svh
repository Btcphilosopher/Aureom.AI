// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_defs.svh
// Library-wide constants.  A `define header, not a package, for the same
// reason as silicaflux-sramlib's sram_defs.svh (Yosys 0.33 cannot resolve
// package references in parameter lists).  Values are part of the firmware
// contract (sw/silicaflux_ras_regs.h is generated from the same table,
// scripts/regmap.py): never renumber, only append.
// =============================================================================
`ifndef SFRAS_DEFS_SVH
`define SFRAS_DEFS_SVH

// ------------------------------------------------------------ event types
// One RAS event = {type, source, address (+valid), info, corrected, timestamp}.
`define SFRAS_EV_NONE          4'd0
`define SFRAS_EV_MEM_CE        4'd1   // correctable memory error: a bit WAS corrected
`define SFRAS_EV_MEM_UE        4'd2   // detected uncorrectable memory error (double / invalid syndrome)
`define SFRAS_EV_BUS_PARITY    4'd3   // parity mismatch on a protected bus link
`define SFRAS_EV_DMA_ERR       4'd4   // DMA transfer ended in error (info = DMA error code)
`define SFRAS_EV_WDOG          4'd5   // watchdog expired (info[0] = second stage)
`define SFRAS_EV_THERM_WARN    4'd6   // thermal warning threshold crossed / sensor stale
`define SFRAS_EV_THERM_FATAL   4'd7   // fatal thermal threshold crossed
`define SFRAS_EV_ILLEGAL_OP    4'd8   // illegal control operation (refused register access, bad command, locked injection, ...)
`define SFRAS_EV_POISON        4'd9   // poisoned data consumed at a containment boundary
`define SFRAS_EV_RECOVERY      4'd10  // recovery action failed (scrub write-back did not clear the error, ...)
`define SFRAS_EV_TIMEOUT       4'd11  // bus transaction timeout
`define SFRAS_EV_FI            4'd12  // a fault injection fired (informational audit trail)
`define SFRAS_EV_NUM_TYPES     13

// ------------------------------------------------------------ severities
`define SFRAS_SEV_INFO         2'd0   // corrected / informational: no data loss
`define SFRAS_SEV_WARN         2'd1   // degraded, no data loss yet
`define SFRAS_SEV_ERROR        2'd2   // data loss contained (poisoned / error response / transfer aborted)
`define SFRAS_SEV_FATAL        2'd3   // containment cannot be guaranteed: stop / isolate

// ------------------------------------------------------------ ECC memory: origin of an observation
`define SFRAS_ORG_READ         3'd0   // functional read
`define SFRAS_ORG_RMW          3'd1   // read half of a partial-write read-modify-write
`define SFRAS_ORG_SCRUB        3'd2   // scrub check read
`define SFRAS_ORG_SCRUB_FIX    3'd3   // scrub correct-and-write-back read
`define SFRAS_ORG_SCRUB_VERIFY 3'd4   // scrub verify read after a write-back
`define SFRAS_ORG_FI           3'd5   // in-place fault injection (never reported as an error)

// ------------------------------------------------------------ ECC memory: poison modes
`define SFRAS_POISON_NONE      0      // RMW onto an uncorrectable word is aborted (word left as found)
`define SFRAS_POISON_SIG       1      // poisoned word stored with a reserved double-error signature (no extra bit)
`define SFRAS_POISON_BIT       2      // poison flag stored as an extra data bit INSIDE the code (SEC-protected)

// ------------------------------------------------------------ ECC memory: scrub request ops
`define SFRAS_SCR_CHECK        2'd0   // read + classify, never writes
`define SFRAS_SCR_FIX          2'd1   // locked read; a correctable word is written back corrected
`define SFRAS_SCR_VERIFY       2'd2   // read + classify after a FIX (reported with origin VERIFY)

// ------------------------------------------------------------ ECC memory: fault injection modes
`define SFRAS_FI_WRITE         2'd0   // XOR mask into the stored word of the next functional write (persistent)
`define SFRAS_FI_READ          2'd1   // XOR mask into the read data of the next functional read (transient)
`define SFRAS_FI_SCRUB_WB      2'd2   // XOR mask into the next scrub write-back (recovery fault)
`define SFRAS_FI_INPLACE       2'd3   // locked read + write back (stored ^ mask) at FI address (persistent)

// ------------------------------------------------------------ configuration errors
`ifdef __ICARUS__
  `define SFRAS_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SFRAS_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SFRAS_DEFS_SVH
