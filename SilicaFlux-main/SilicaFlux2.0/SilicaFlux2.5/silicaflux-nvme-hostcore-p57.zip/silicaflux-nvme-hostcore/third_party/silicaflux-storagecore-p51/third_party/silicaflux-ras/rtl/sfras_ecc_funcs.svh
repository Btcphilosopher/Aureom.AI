// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_ecc_funcs.svh
// Elaboration-time functions that define the SECDED code organisation.
// Included INSIDE module bodies (no package: Yosys 0.33 cannot resolve package
// references in parameter lists - same convention as silicaflux-sramlib).
//
// Code: extended Hamming SECDED, K data bits, R Hamming check bits, 1 overall
// parity bit, N = K + R + 1 stored bits.  R is the smallest r with
// 2^r >= K + r + 1.                     K=8 -> (13,8)   K=16 -> (22,16)
//                                       K=32 -> (39,32) K=64 -> (72,64)
//                                       K=128 -> (137,128)
//
// Hamming positions (1-based, the syndrome value that names a bit):
//   check bit j          -> position 2^j                    (j = 0 .. R-1)
//   data bit i           -> the (i+1)-th integer >= 3 that is not a power of
//                           two: 3,5,6,7,9,10,...           (i = 0 .. K-1)
//   overall parity bit   -> position 0 (it is not covered by the syndrome)
//   Every position 1 .. K+R is used exactly once; a syndrome > K+R names no
//   bit ("invalid syndrome").
//
// Stored (systematic) bit order of the N-bit codeword cw:
//   cw[K-1:0]     data bits, data bit i at cw[i]
//   cw[K+R-1:K]   check bits, check bit j at cw[K+j]
//   cw[K+R]       overall parity bit (even parity over data + check bits)
// before the optional check-bit inversion mask INV (R+1 bits, applied to
// cw[K+R:K]; see sfras_ecc_default_inv).
// =============================================================================
// (no include guard on purpose: every module body that needs the functions
//  includes this file once)

  // Written in Verilog-2001 function style (assignment to the function name,
  // no 'return', loop variables declared up front): Yosys 0.33 accepts nothing
  // else in constant functions.

  // number of Hamming check bits for k data bits (k >= 1)
  function automatic integer sfras_ecc_r(input integer k);
    integer t;
    begin
      sfras_ecc_r = 0;
      for (t = 24; t >= 1; t = t - 1)
        if ((1 << t) >= k + t + 1) sfras_ecc_r = t;
    end
  endfunction

  // Hamming position of data bit i (closed form: skip every power of two)
  function automatic integer sfras_ecc_dpos(input integer i);
    integer t, p;
    begin
      p = i + 1;
      for (t = 0; t < 31; t = t + 1)
        if ((1 << t) <= p) p = p + 1;
      sfras_ecc_dpos = p;
    end
  endfunction

  // Hamming position of stored bit b of a (k-data-bit) codeword; 0 = overall parity
  function automatic integer sfras_ecc_hpos(input integer k, input integer b);
    integer r;
    begin
      r = sfras_ecc_r(k);
      if (b < k)          sfras_ecc_hpos = sfras_ecc_dpos(b);
      else if (b < k + r) sfras_ecc_hpos = (1 << (b - k));
      else                sfras_ecc_hpos = 0;
    end
  endfunction

  // XOR of the Hamming positions of all data bits = check bits of an all-ones word
  function automatic integer sfras_ecc_ones_chk(input integer k);
    integer i, c;
    begin
      c = 0;
      for (i = 0; i < k; i = i + 1) c = c ^ sfras_ecc_dpos(i);
      sfras_ecc_ones_chk = c;
    end
  endfunction

  // parity of the low 31 bits of v
  function automatic integer sfras_ecc_par(input integer v);
    integer i, p;
    begin
      p = 0;
      for (i = 0; i < 31; i = i + 1) p = p ^ ((v >> i) & 1);
      sfras_ecc_par = p;
    end
  endfunction

  // decoder classification of a constant stored word, used only at elaboration:
  // 1 if the stored word decodes as UNCORRECTABLE.
  //   c_rx / p_rx : stored check bits / parity AFTER removing the inversion
  //   c_calc      : check bits recomputed from the stored data bits
  //   dpar        : parity of the stored data bits
  function automatic integer sfras_ecc_is_ue(input integer k, input integer c_rx, input integer p_rx,
                                             input integer c_calc, input integer dpar);
    integer r, s, pe;
    begin
      r  = sfras_ecc_r(k);
      s  = c_calc ^ c_rx;
      pe = p_rx ^ dpar ^ sfras_ecc_par(c_rx);
      sfras_ecc_is_ue = ((s != 0) && ((pe == 0) || (s > k + r))) ? 1 : 0;
    end
  endfunction

  // Default check-bit inversion for memories (R+1 bits, bit R = parity bit).
  // Two bits are inverted (even weight), so the all-zero stored word -- a dead
  // word line, a macro that powers up or is scrubbed to zero -- always decodes
  // as UNCORRECTABLE (s = inverted check bits != 0, overall parity even).  The
  // first pair (a < b) that ALSO makes the all-ones stored word uncorrectable
  // is chosen; if no pair does (possible for some K), the pair (0,1) is used and
  // only the all-zero guarantee holds.  The reference model (model/secded_ref.py)
  // recomputes this choice independently with a brute-force decoder.
  function automatic integer sfras_ecc_default_inv(input integer k);
    integer r, msk, inv, ones_c, found, c_rx, p_rx, a, b;
    begin
      r      = sfras_ecc_r(k);
      msk    = (1 << r) - 1;
      ones_c = sfras_ecc_ones_chk(k);
      sfras_ecc_default_inv = 3;
      found  = 0;
      for (a = 0; a <= r; a = a + 1) begin
        for (b = a + 1; b <= r; b = b + 1) begin
          inv  = (1 << a) | (1 << b);
          c_rx = msk ^ (inv & msk);               // stored all-ones check bits, inversion removed
          p_rx = 1 ^ ((inv >> r) & 1);
          if (found == 0 && sfras_ecc_is_ue(k, c_rx, p_rx, ones_c, k & 1) != 0) begin
            sfras_ecc_default_inv = inv;
            found = 1;
          end
        end
      end
    end
  endfunction
