// =============================================================================
// SilicaFlux MCU-I :: mcu_wdt -- watchdog timer (new for MCU-I)
//
// Register map: docs/REGISTERS.md block `wdt`.
//   * Down-counter of ticks (one tick every PRESCALE+1 clk cycles), loaded
//     from LOAD when enabled and on every legal service.
//   * EN and LOCK are set-only: once enabled only a reset stops it; once
//     locked LOAD/PRESCALE/EWI_THRESH/CTRL writes return a bus error.
//   * Legal service: write WDT_KEY1, then WDT_KEY2 (no other SERVICE write
//     in between).  Any other value written to SERVICE while EN = 1 sets
//     ILLEGAL and requests a reset immediately (fail-safe: a runaway program
//     that scribbles registers does not keep the watchdog alive).
//   * Early warning: STATUS.EWI set when COUNT <= EWI_THRESH (interrupt when
//     EWI_EN), giving firmware a last chance to log state.
//   * Expiry (COUNT reaches 0 while running) or ILLEGAL -> reset_req (level,
//     held until the system reset that it causes clears this block); the
//     reset generator in mcu_sysctrl records cause WDT (POR domain).
// Behaviour by state (docs/WATCHDOG.md):
//   reset       - disabled, counter = LOAD reset value; restarts disabled.
//   debug halt  - counter pauses while `dbg_halt` (JTAG CPU hold) if DBG_PAUSE.
//   WFI sleep   - keeps counting (its clock is never gated).
//   lockup      - firmware stops servicing -> expiry -> system reset.
//   clock fail  - NOT detected: the watchdog runs from the same clock as the
//                 CPU, so a stopped clock stops the watchdog too.  Independent
//                 protection needs a separate oscillator (not present).
// =============================================================================
`default_nettype none

module mcu_wdt (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  input  wire logic        dbg_halt,
  output logic             irq_ewi,
  output logic             reset_req
);
  localparam logic [11:0] A_CTRL  = mcu_memmap_pkg::WDT_CTRL;
  localparam logic [11:0] A_LOAD  = mcu_memmap_pkg::WDT_LOAD;
  localparam logic [11:0] A_PRE   = mcu_memmap_pkg::WDT_PRESCALE;
  localparam logic [11:0] A_COUNT = mcu_memmap_pkg::WDT_COUNT;
  localparam logic [11:0] A_SVC   = mcu_memmap_pkg::WDT_SERVICE;
  localparam logic [11:0] A_EWI   = mcu_memmap_pkg::WDT_EWI_THRESH;
  localparam logic [11:0] A_STAT  = mcu_memmap_pkg::WDT_STATUS;

  logic        en_q, lock_q, ewien_q, dbgp_q, ewi_q, ill_q, key1_q, exp_q;
  logic [31:0] load_q, cnt_q, thr_q;
  logic [15:0] pre_q, pcnt_q;

  wire wr      = rb_sel && rb_we;
  wire svc_wr  = wr && rb_addr == A_SVC;
  wire svc_ok  = svc_wr && key1_q && rb_wdata == mcu_memmap_pkg::WDT_KEY2;
  wire svc_k1  = svc_wr && rb_wdata == mcu_memmap_pkg::WDT_KEY1;
  wire svc_bad = svc_wr && !svc_k1 && !svc_ok;
  wire cfg_wr  = wr && (rb_addr == A_LOAD || rb_addr == A_PRE || rb_addr == A_EWI || rb_addr == A_CTRL);
  wire cfg_ok  = cfg_wr && !lock_q;
  wire pause   = dbg_halt && dbgp_q;
  wire tick    = en_q && !pause && (pcnt_q == pre_q);
  wire en_now  = cfg_ok && rb_addr == A_CTRL && rb_wdata[0] && !en_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q <= 1'b0; lock_q <= 1'b0; ewien_q <= 1'b0; dbgp_q <= 1'b0;
      ewi_q <= 1'b0; ill_q <= 1'b0; key1_q <= 1'b0; exp_q <= 1'b0;
      load_q <= mcu_memmap_pkg::WDT_LOAD_RST; cnt_q <= mcu_memmap_pkg::WDT_LOAD_RST;
      thr_q <= '0; pre_q <= '0; pcnt_q <= '0;
    end else begin
      // configuration
      if (cfg_ok) begin
        case (rb_addr)
          A_CTRL: begin
            if (rb_wdata[0]) en_q   <= 1'b1;
            if (rb_wdata[1]) lock_q <= 1'b1;
            ewien_q <= rb_wdata[2];
            dbgp_q  <= rb_wdata[3];
          end
          A_LOAD: load_q <= rb_wdata;
          A_PRE:  pre_q  <= rb_wdata[15:0];
          A_EWI:  thr_q  <= rb_wdata;
          default: ;
        endcase
      end
      if (wr && rb_addr == A_STAT && rb_wdata[0]) ewi_q <= 1'b0;
      // service sequence
      if (svc_wr) key1_q <= svc_k1;
      if (svc_bad && en_q) ill_q <= 1'b1;
      // prescaler
      if (!en_q || pause || pcnt_q == pre_q) pcnt_q <= '0;
      else                                   pcnt_q <= pcnt_q + 16'd1;
      // counter
      if (en_now || (svc_ok && en_q)) begin
        cnt_q <= load_q;
        pcnt_q <= '0;
      end else if (tick && cnt_q != 32'd0) begin
        cnt_q <= cnt_q - 32'd1;
      end
      if (en_q && cnt_q == 32'd0 && !(svc_ok)) exp_q <= 1'b1;
      if (en_q && cnt_q <= thr_q) ewi_q <= 1'b1;
    end
  end

`ifdef FORMAL
  // embedded checker (formal/run_formal.py job "wdt"):
  // P1 EN is set-only; P2 reset_req is sticky; P3 LOAD/PRESCALE frozen while
  // locked; P4 the counter only increases on enable or a legal service;
  // P5 an illegal SERVICE value while enabled requests a reset next cycle
  logic        f_past = 1'b0, f_en, f_rr, f_lock, f_inc_ok, f_bad;
  logic [31:0] f_load, f_cnt;
  logic [15:0] f_pre;
  always_ff @(posedge clk) begin
    f_past <= rst_n;
    f_en <= en_q; f_rr <= reset_req; f_lock <= lock_q; f_load <= load_q; f_pre <= pre_q; f_cnt <= cnt_q;
    f_inc_ok <= en_now || (svc_ok && en_q); f_bad <= svc_bad && en_q;
  end
  always_comb begin
    if (rst_n && f_past) begin
      if (f_en)   assert (en_q);
      if (f_rr)   assert (reset_req);
      if (f_lock) assert (load_q == f_load && pre_q == f_pre);
      if (cnt_q > f_cnt) assert (f_inc_ok);
      if (f_bad)  assert (reset_req);
    end
  end
`endif

  assign irq_ewi   = ewien_q && ewi_q;
  assign reset_req = exp_q || ill_q;

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_CTRL:  begin rb_rdata = {28'd0, dbgp_q, ewien_q, lock_q, en_q}; rb_err = rb_we && lock_q; end
      A_LOAD:  begin rb_rdata = load_q; rb_err = rb_we && lock_q; end
      A_PRE:   begin rb_rdata = {16'd0, pre_q}; rb_err = rb_we && lock_q; end
      A_COUNT: begin rb_rdata = cnt_q; rb_err = rb_we; end
      A_SVC:   rb_rdata = 32'd0;
      A_EWI:   begin rb_rdata = thr_q; rb_err = rb_we && lock_q; end
      A_STAT:  rb_rdata = {28'd0, key1_q, ill_q, en_q, ewi_q};
      default: rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
