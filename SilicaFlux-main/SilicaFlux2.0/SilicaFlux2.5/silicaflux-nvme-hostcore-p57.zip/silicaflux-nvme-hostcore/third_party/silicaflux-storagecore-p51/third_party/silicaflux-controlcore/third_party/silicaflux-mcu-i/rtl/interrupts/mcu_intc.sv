// =============================================================================
// SilicaFlux MCU-I :: mcu_intc -- interrupt controller (-> CPU MEI)
//
// New for MCU-I (replaces SilicaFlux-V sfv_intc, which had enable + claim
// only).  Matches the CPU's actual interrupt architecture: RISC-V machine
// mode with one external interrupt input (mip.MEIP); MTI/MSI come from the
// CLINT-style machine timer.  Register map: docs/REGISTERS.md block `intc`.
//
//   * N (<= 16) LEVEL-sensitive sources, synchronous to clk.  Peripherals
//     hold their request until firmware clears the cause at the peripheral,
//     so nothing is latched here: no lost or duplicated interrupts.
//     Asynchronous external events enter through GPIO (2-flop synchronisers).
//   * SWPEND: software-set pending bit per source (software interrupts, test).
//   * Priority 0..7 per source (0 = never), THRESHOLD: a source interrupts
//     only when enabled, pending and priority > THRESHOLD.
//   * CLAIM: 1 + index of the highest-priority active source, lowest index on
//     ties; 0 = none.  Reading CLAIM has no side effect ("acknowledge" is the
//     peripheral clear; nesting: raise THRESHOLD to the claimed priority and
//     re-enable mstatus.MIE).
//   * irq_ext is a combinational function of registered state and the
//     (registered) source levels: architectural latency from a source flop
//     changing to mip.MEIP is 0 cycles; the CPU takes the trap at the next
//     instruction boundary that is not inside a bus access.
// =============================================================================
`default_nettype none

module mcu_intc #(
  parameter int N = 16
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         rb_sel,
  input  wire logic         rb_we,
  input  wire logic [11:0]  rb_addr,
  input  wire logic [31:0]  rb_wdata,
  output logic [31:0]       rb_rdata,
  output logic              rb_err,
  input  wire logic [N-1:0] src,
  output logic              irq_ext
);
  localparam logic [11:0] A_PENDING   = mcu_memmap_pkg::INTC_PENDING;
  localparam logic [11:0] A_ENABLE    = mcu_memmap_pkg::INTC_ENABLE;
  localparam logic [11:0] A_CLAIM     = mcu_memmap_pkg::INTC_CLAIM;
  localparam logic [11:0] A_SWPEND    = mcu_memmap_pkg::INTC_SWPEND;
  localparam logic [11:0] A_THRESHOLD = mcu_memmap_pkg::INTC_THRESHOLD;
  localparam logic [11:0] A_ACTIVE    = mcu_memmap_pkg::INTC_ACTIVE;
  localparam logic [11:0] A_PRIO0     = mcu_memmap_pkg::INTC_PRIO0;
  localparam logic [11:0] A_PRIO1     = mcu_memmap_pkg::INTC_PRIO1;

  logic [15:0] en_q, sw_q;
  logic [63:0] prio_q;              // 4 bits per source, 3 LSBs used
  logic [2:0]  thr_q;
  wire wr = rb_sel && rb_we;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q   <= '0;
      sw_q   <= '0;
      prio_q <= {16{4'h1}};
      thr_q  <= '0;
    end else if (wr) begin
      case (rb_addr)
        A_ENABLE:    en_q  <= rb_wdata[15:0];
        A_SWPEND:    sw_q  <= rb_wdata[15:0];
        A_THRESHOLD: thr_q <= rb_wdata[2:0];
        A_PRIO0:     prio_q[31:0]  <= rb_wdata & 32'h7777_7777;
        A_PRIO1:     prio_q[63:32] <= rb_wdata & 32'h7777_7777;
        default: ;
      endcase
    end
  end

  logic [15:0] src16, pend, act;
  always_comb begin
    src16 = '0;
    src16[N-1:0] = src;
    pend = src16 | sw_q;
    for (int i = 0; i < 16; i++)
      act[i] = pend[i] && en_q[i] && (prio_q[i*4 +: 3] > thr_q) && (i < N);
  end
  assign irq_ext = |act;

  // claim: highest priority, lowest index on ties
  logic [7:0] claim;
  logic [2:0] best;
  always_comb begin
    claim = 8'd0;
    best  = 3'd0;
    for (int i = 15; i >= 0; i--) begin
      if (act[i] && (prio_q[i*4 +: 3] >= best)) begin
        best  = prio_q[i*4 +: 3];
        claim = 8'(i + 1);
      end
    end
  end

`ifdef FORMAL
  // embedded checker (formal/run_formal.py job "intc"):
  // P1 irq_ext == (claim != 0); P2 the claimed source is active;
  // P3 no active source has a higher priority, none with a lower index has
  //    the same priority
  always_comb begin
    if (rst_n) begin
      assert (irq_ext == (claim != 8'd0));
      if (claim != 8'd0) begin
        assert (act[claim - 8'd1]);
        for (int i = 0; i < 16; i++) begin
          if (act[i]) assert (prio_q[i*4 +: 3] <= best);
          if (act[i] && (8'(i) < claim - 8'd1)) assert (prio_q[i*4 +: 3] != best);
        end
      end
    end
  end
`endif

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_PENDING:   begin rb_rdata[15:0] = pend; rb_err = rb_we; end
      A_ENABLE:    rb_rdata[15:0] = en_q;
      A_CLAIM:     begin rb_rdata[7:0] = claim; rb_err = rb_we; end
      A_SWPEND:    rb_rdata[15:0] = sw_q;
      A_THRESHOLD: rb_rdata[2:0] = thr_q;
      A_ACTIVE:    begin rb_rdata[15:0] = act; rb_err = rb_we; end
      A_PRIO0:     rb_rdata = prio_q[31:0];
      A_PRIO1:     rb_rdata = prio_q[63:32];
      default:     rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
