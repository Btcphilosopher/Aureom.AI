/* SilicaFlux ControlCore -- CRC-32 (IEEE 802.3, reflected, init/xorout 0xFFFFFFFF),
 * table built at run time (saves 1 KiB of ROM).  Used by the boot ROM to check
 * the firmware image and by scripts/mkimage.py (zlib.crc32, same polynomial).
 * This is an INTEGRITY check (accidental corruption), not authentication. */
#include "cc_crc32.h"

static uint32_t crc_table[256];
static int crc_ready;

static void crc32_init(void) {
  for (uint32_t i = 0; i < 256u; i++) {
    uint32_t c = i;
    for (int k = 0; k < 8; k++) c = (c & 1u) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
    crc_table[i] = c;
  }
  crc_ready = 1;
}

uint32_t cc_crc32(const void *data, uint32_t len) {
  if (!crc_ready) crc32_init();
  const uint8_t *p = (const uint8_t *)data;
  uint32_t c = 0xFFFFFFFFu;
  /* word-wise reads (the image lives in parity-protected SRAM; every word is
   * read exactly once) */
  uint32_t n = len >> 2;
  const volatile uint32_t *w = (const volatile uint32_t *)data;
  for (uint32_t i = 0; i < n; i++) {
    uint32_t v = w[i];
    c = crc_table[(c ^ v) & 0xFFu] ^ (c >> 8);
    c = crc_table[(c ^ (v >> 8)) & 0xFFu] ^ (c >> 8);
    c = crc_table[(c ^ (v >> 16)) & 0xFFu] ^ (c >> 8);
    c = crc_table[(c ^ (v >> 24)) & 0xFFu] ^ (c >> 8);
  }
  for (uint32_t i = n << 2; i < len; i++) c = crc_table[(c ^ p[i]) & 0xFFu] ^ (c >> 8);
  return c ^ 0xFFFFFFFFu;
}
