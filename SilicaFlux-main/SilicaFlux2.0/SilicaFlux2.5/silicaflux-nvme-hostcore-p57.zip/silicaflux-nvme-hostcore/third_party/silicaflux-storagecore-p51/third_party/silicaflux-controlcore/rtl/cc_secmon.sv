// =============================================================================
// SilicaFlux ControlCore :: cc_secmon -- security STATUS (not a security engine)
//
// Register page CC_PG_SECURITY (block cc_secmon).  Reports honestly what the
// ControlCore does and does not enforce:
//   implemented : host write lock (set-only HOST_LOCK; cc_host_gate refuses host
//                 writes to BOOTROM/IMEM/DMEM while set), execute-never on
//                 DMEM/EXT/PERIPH (crossbar access matrix), a write-once
//                 BOOT_MEASURE register that the boot ROM fills with the CRC32
//                 of the image it started (integrity check only).
//   NOT implemented: firmware authentication, secure boot, a hardware root of
//                 trust, key storage, debug authentication.  AUTH_STATE reads 0
//                 ("not implemented: image unauthenticated") and AUTH_HOOK
//                 reads 0 until Project 28 supplies a verified engine.
// =============================================================================
`default_nettype none

module cc_secmon
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  input  wire logic        viol_evt,          // host write refused
  input  wire logic [31:0] viol_addr,
  output logic             host_lock
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  localparam logic [31:0] CAPS = 32'b0111_0000;   // [4] lock [5] CRC32 integrity [6] XN; [3:0] = 0

  wire wr = rb_sel && rb_we;
  logic        lock_q, meas_v_q, viol_q;
  logic [31:0] meas_q, vaddr_q, vcnt_q;

  wire meas_wr = wr && rb_addr == CC_SEC_BOOT_MEASURE && !meas_v_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lock_q <= 1'b0; meas_v_q <= 1'b0; viol_q <= 1'b0; meas_q <= '0; vaddr_q <= '0; vcnt_q <= '0;
    end else begin
      if (wr && rb_addr == CC_SEC_CTRL && rb_wdata[0]) lock_q <= 1'b1;
      if (meas_wr) begin meas_q <= rb_wdata; meas_v_q <= 1'b1; end
      if (wr && rb_addr == CC_SEC_CLEAR && rb_wdata[0]) viol_q <= 1'b0;
      if (viol_evt) begin
        viol_q  <= 1'b1;
        vaddr_q <= viol_addr;
        if (vcnt_q != 32'hFFFF_FFFF) vcnt_q <= vcnt_q + 32'd1;
      end
    end
  end
  assign host_lock = lock_q;

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      CC_SEC_CAPS:         begin rb_rdata = CAPS; rb_err = rb_we; end
      CC_SEC_STATUS:       begin rb_rdata = {23'd0, viol_q, 4'd0, 2'd0, meas_v_q, lock_q}; rb_err = rb_we; end
      CC_SEC_CTRL:         rb_rdata = {31'd0, lock_q};
      CC_SEC_BOOT_MEASURE: begin rb_rdata = meas_q; rb_err = rb_we && meas_v_q; end
      CC_SEC_VIOL_ADDR:    begin rb_rdata = vaddr_q; rb_err = rb_we; end
      CC_SEC_VIOL_COUNT:   begin rb_rdata = vcnt_q; rb_err = rb_we; end
      CC_SEC_CLEAR:        rb_err = !rb_we;
      CC_SEC_AUTH_HOOK:    begin rb_rdata = 32'd0; rb_err = rb_we; end
      default:             rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
