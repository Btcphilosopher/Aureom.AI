// =============================================================================
// SilicaFlux ControlCore :: cc_perf -- ControlCore performance counters
//
// Register page CC_PG_PERF (block cc_perf).  A free-running 64-bit cycle
// counter and NEV 32-bit saturating event counters (CC_PERF_EV_*).  Bit i of
// EDGE selects rising-edge counting (interrupt lines) instead of per-cycle
// counting (busy levels, accepted requests).  CTRL.FREEZE holds every counter
// (consistent multi-register read); writing CTRL[1] = 1 clears them (wins over
// a same-cycle event).  The accelerators keep their own counter banks on their
// register pages (tile PERF[0..23], tensor unit PERF[0..19] / DMA_PERF[0..17]);
// firmware gathers all of them (docs/HW_SW_INTERFACE.md section 8).
// =============================================================================
`default_nettype none

module cc_perf
#(
  parameter int          NEV  = 20,
  parameter logic [31:0] EDGE = 32'h0
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           rb_sel,
  input  wire logic           rb_we,
  input  wire logic [11:0]    rb_addr,
  /* verilator lint_off UNUSEDSIGNAL */          // only CTRL[1:0] is writable
  input  wire logic [31:0]    rb_wdata,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]         rb_rdata,
  output logic                rb_err,
  input  wire logic [NEV-1:0] ev
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  wire wr  = rb_sel && rb_we;
  wire clr = wr && rb_addr == CC_PERF_CTRL && rb_wdata[1];
  logic           frz_q;
  logic [63:0]    cyc_q;
  logic [NEV-1:0] ev_q;
  logic [31:0]    cnt_q [NEV];

  wire [NEV-1:0] inc = (ev & ~(ev_q & EDGE[NEV-1:0]));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      frz_q <= 1'b0; cyc_q <= '0; ev_q <= '0;
      for (int i = 0; i < NEV; i++) cnt_q[i] <= '0;
    end else begin
      ev_q <= ev;
      if (wr && rb_addr == CC_PERF_CTRL) frz_q <= rb_wdata[0];
      if (clr) begin
        cyc_q <= '0;
        for (int i = 0; i < NEV; i++) cnt_q[i] <= '0;
      end else if (!frz_q) begin
        cyc_q <= cyc_q + 64'd1;
        for (int i = 0; i < NEV; i++)
          if (inc[i] && cnt_q[i] != 32'hFFFF_FFFF) cnt_q[i] <= cnt_q[i] + 32'd1;
      end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */          // [1:0] checked through rb_addr
  wire [11:0] ci_off = rb_addr - CC_PERF_CNT0;
  /* verilator lint_on UNUSEDSIGNAL */
  wire        ci_hit = rb_addr >= CC_PERF_CNT0 && ci_off[11:2] < 10'(NEV) && rb_addr[1:0] == 2'd0;
  localparam int IW = $clog2(NEV);
  wire [IW-1:0] ci  = ci_off[IW+1:2];

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (ci_hit) begin
      rb_rdata = cnt_q[ci];
      rb_err   = rb_we;
    end else begin
      case (rb_addr)
        CC_PERF_CTRL:     rb_rdata = {31'd0, frz_q};
        CC_PERF_INFO:     begin rb_rdata = 32'(NEV); rb_err = rb_we; end
        CC_PERF_CYCLE_LO: begin rb_rdata = cyc_q[31:0];  rb_err = rb_we; end
        CC_PERF_CYCLE_HI: begin rb_rdata = cyc_q[63:32]; rb_err = rb_we; end
        default:          rb_err = 1'b1;
      endcase
    end
  end
endmodule

`default_nettype wire
