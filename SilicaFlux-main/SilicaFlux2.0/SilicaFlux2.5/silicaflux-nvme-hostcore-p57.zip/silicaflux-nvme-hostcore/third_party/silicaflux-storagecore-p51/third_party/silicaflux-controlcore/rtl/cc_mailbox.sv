// =============================================================================
// SilicaFlux ControlCore :: cc_mailbox -- host <-> firmware mailbox + console
//
// Register page CC_PG_MAILBOX (block cc_mailbox).  The page is reachable by the
// firmware (CPU data port) and by the host (host access port); the register
// bus does not carry the requester, so the direction of each register is a
// software convention documented in docs/HW_SW_INTERFACE.md:
//   host  writes H2F_MSG0..7, H2F_RING; reads F2H_*, acknowledges F2H_ACK
//   fw    writes F2H_MSG0..7, F2H_RING; reads H2F_*, acknowledges H2F_ACK
// irq_h2f (-> INTC source HOST) = H2F_PEND; host_irq (pin) = F2H_PEND.
//
// Diagnostic console: DIAG_TX pushes a character into a 256-entry FIFO the host
// drains through DIAG_RX / DIAG_POP (reads have no side effects).  A full FIFO
// drops the character and sets OVF (firmware never stalls on the console).
// diag_valid/diag_char mirror every DIAG_TX write (simulation log / lab probe).
// =============================================================================
`default_nettype none

module cc_mailbox
#(
  parameter int DIAG_DEPTH = 256        // power of two
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             irq_h2f,
  output logic             host_irq,
  output logic             diag_valid,
  output logic [7:0]       diag_char
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  localparam int DW = $clog2(DIAG_DEPTH);

  wire wr = rb_sel && rb_we;
  logic [31:0] h2f_q [8];
  logic [31:0] f2h_q [8];
  logic        h2f_pend_q, f2h_pend_q, ovf_q;
  logic [31:0] h2f_code_q, f2h_code_q;
  logic [15:0] h2f_cnt_q, f2h_cnt_q;

  // console FIFO
  logic [7:0]    fifo_q [DIAG_DEPTH];
  logic [DW-1:0] wp_q, rp_q;
  logic [DW:0]   lvl_q;
  wire full  = lvl_q == (DW+1)'(DIAG_DEPTH);
  wire empty = lvl_q == '0;
  wire push  = wr && rb_addr == CC_MBOX_DIAG_TX && !full;
  wire pop   = wr && rb_addr == CC_MBOX_DIAG_POP && !empty;

  wire msg_h2f = rb_addr[11:5] == 7'd0;               // 0x000..0x01C
  wire msg_f2h = rb_addr[11:5] == 7'd1;               // 0x020..0x03C
  wire [2:0] mi = rb_addr[4:2];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 8; i++) begin h2f_q[i] <= '0; f2h_q[i] <= '0; end
      h2f_pend_q <= 1'b0; f2h_pend_q <= 1'b0; ovf_q <= 1'b0;
      h2f_code_q <= '0; f2h_code_q <= '0; h2f_cnt_q <= '0; f2h_cnt_q <= '0;
      wp_q <= '0; rp_q <= '0; lvl_q <= '0;
    end else begin
      if (wr && msg_h2f && rb_addr[1:0] == 2'd0) h2f_q[mi] <= rb_wdata;
      if (wr && msg_f2h && rb_addr[1:0] == 2'd0) f2h_q[mi] <= rb_wdata;
      if (wr && rb_addr == CC_MBOX_H2F_ACK)  h2f_pend_q <= 1'b0;
      if (wr && rb_addr == CC_MBOX_F2H_ACK)  f2h_pend_q <= 1'b0;
      if (wr && rb_addr == CC_MBOX_H2F_RING) begin
        h2f_pend_q <= 1'b1; h2f_code_q <= rb_wdata; h2f_cnt_q <= h2f_cnt_q + 16'd1;
      end
      if (wr && rb_addr == CC_MBOX_F2H_RING) begin
        f2h_pend_q <= 1'b1; f2h_code_q <= rb_wdata; f2h_cnt_q <= f2h_cnt_q + 16'd1;
      end
      if (wr && rb_addr == CC_MBOX_DIAG_TX && full) ovf_q <= 1'b1;
      if (wr && rb_addr == CC_MBOX_DIAG_STATUS && rb_wdata[16]) ovf_q <= 1'b0;
      if (push) wp_q <= wp_q + 1'b1;
      if (pop)  rp_q <= rp_q + 1'b1;
      lvl_q <= lvl_q + (DW+1)'(push) - (DW+1)'(pop);
    end
  end

  // FIFO storage: no reset (maps to distributed RAM)
  always_ff @(posedge clk) begin
    if (push) fifo_q[wp_q] <= rb_wdata[7:0];
  end

  assign irq_h2f    = h2f_pend_q;
  assign host_irq   = f2h_pend_q;
  assign diag_valid = wr && rb_addr == CC_MBOX_DIAG_TX;
  assign diag_char  = rb_wdata[7:0];

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (msg_h2f || msg_f2h) begin
      rb_rdata = msg_h2f ? h2f_q[mi] : f2h_q[mi];
    end else begin
      case (rb_addr)
        CC_MBOX_DB_STATUS:   begin rb_rdata = {30'd0, f2h_pend_q, h2f_pend_q}; rb_err = rb_we; end
        CC_MBOX_H2F_RING, CC_MBOX_H2F_ACK, CC_MBOX_F2H_RING, CC_MBOX_F2H_ACK, CC_MBOX_DIAG_TX,
        CC_MBOX_DIAG_POP:    rb_err = !rb_we;
        CC_MBOX_H2F_CODE:    begin rb_rdata = h2f_code_q; rb_err = rb_we; end
        CC_MBOX_F2H_CODE:    begin rb_rdata = f2h_code_q; rb_err = rb_we; end
        CC_MBOX_RING_COUNT:  begin rb_rdata = {f2h_cnt_q, h2f_cnt_q}; rb_err = rb_we; end
        CC_MBOX_DIAG_RX:     begin rb_rdata = {23'd0, !empty, empty ? 8'd0 : fifo_q[rp_q]}; rb_err = rb_we; end
        CC_MBOX_DIAG_STATUS: rb_rdata = {15'd0, ovf_q, 7'd0, 9'(lvl_q)};
        default:             rb_err = 1'b1;
      endcase
    end
  end
endmodule

`default_nettype wire
