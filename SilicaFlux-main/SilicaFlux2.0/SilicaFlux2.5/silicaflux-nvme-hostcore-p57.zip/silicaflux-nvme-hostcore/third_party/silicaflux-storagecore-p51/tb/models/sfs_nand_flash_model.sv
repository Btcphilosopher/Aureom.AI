// =============================================================================
// SilicaFlux StorageCore :: sfs_nand_flash_model -- behavioural NAND flash device
//
// SIMULATION MODEL (not synthesizable).  ONFI-style asynchronous SDR device,
// one LUN, x8 or x16:
//   FFh reset | 90h 00h read ID (5 bytes) | 70h read status
//   00h C C R R R 30h read page -> page register, tR busy, data out on RE#
//   80h C C R R R data.. 10h program (bits only 1 -> 0: AND), tPROG busy
//   60h R R R D0h block erase (all FFh), tBERS busy
// Command / address / data-in are latched on the rising edge of WE# (CE# low),
// data-out is driven tREA after the falling edge of RE# and released tRHOH
// after its rising edge.  R/B# low while busy.  Column addresses count bus
// beats (x16: 2 bytes per beat).  Row = block * PAGES_PER_BLOCK + page.
// Status byte: [7] WP# (1 = not protected) [6] RDY [5] ARDY [0] FAIL.
// Program / erase fail (status FAIL, array unchanged) on a bad block or with
// WP# low.  A command other than 10h after 80h cancels the program.
// Checks (counted, printed with +nanddbg): protocol errors (unknown command,
// command while busy, address count), minimum WE#/RE# pulse widths,
// re-programming a programmed page without erase.
// Test hooks (hierarchical task calls): flip_bit(), set_bad_block(),
// set_stuck_busy(), peek()/poke(), preload_page().
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfs_nand_flash_model #(
  parameter int    DQW             = 8,
  parameter int    RAW_PAGE        = 768,      // bytes per page incl. spare
  parameter int    PAGES_PER_BLOCK = 16,
  parameter int    BLOCKS          = 64,
  parameter real   T_R_NS          = 2000.0,
  parameter real   T_PROG_NS       = 4000.0,
  parameter real   T_BERS_NS       = 8000.0,
  parameter real   T_RST_NS        = 500.0,
  parameter real   T_REA_NS        = 8.0,
  parameter real   T_RHOH_NS       = 2.0,
  parameter real   T_WP_MIN_NS     = 10.0,
  parameter real   T_RP_MIN_NS     = 10.0,
  parameter logic [39:0] ID        = 40'h00_10_A1_DA_5F,   // bytes 0..4 = 5F DA A1 10 00 (byte 0 = maker)
  parameter string NAME            = "nand",
  parameter int    CH              = 0
) (
  input  wire          ce_n,
  input  wire          cle,
  input  wire          ale,
  input  wire          we_n,
  input  wire          re_n,
  input  wire          wp_n,
  inout  wire [DQW-1:0] dq,
  output logic         rb_n
);
  localparam int NPAGES = BLOCKS * PAGES_PER_BLOCK;
  localparam int BPB    = DQW / 8;   // bytes per beat

  logic [7:0] mem [NPAGES * RAW_PAGE];
  logic [7:0] preg [RAW_PAGE];
  bit         programmed [NPAGES];
  bit         bad [BLOCKS];
  bit         stuck_busy;
  bit         dbg;

  typedef enum int { M_IDLE, M_RD_ADDR, M_RD_OUT, M_PG_ADDR, M_PG_DATA, M_ER_ADDR, M_ID_ADDR, M_ID_OUT, M_STATUS } mode_e;
  mode_e      mode, mode_before_status;
  int         acnt, ptr, id_idx;
  logic [7:0] abytes [5];
  logic [7:0] status;
  bit         busy;
  logic [DQW-1:0] dq_drv;
  bit         dq_en;
  realtime    t_we_fall, t_re_fall;

  int n_reads, n_progs, n_erases, n_resets, n_proto_err, n_timing_err, n_reprog;

  assign dq   = dq_en ? dq_drv : {DQW{1'bz}};
  assign rb_n = !busy;

  initial begin
    for (int i = 0; i < NPAGES * RAW_PAGE; i++) mem[i] = 8'hFF;
    for (int i = 0; i < RAW_PAGE; i++) preg[i] = 8'hFF;
    for (int i = 0; i < NPAGES; i++) programmed[i] = 0;
    for (int i = 0; i < BLOCKS; i++) bad[i] = 0;
    stuck_busy = 0; busy = 0; dq_en = 0; dq_drv = '0;
    mode = M_IDLE; mode_before_status = M_IDLE; acnt = 0; ptr = 0; id_idx = 0;
    status = 8'hE0;
    n_reads = 0; n_progs = 0; n_erases = 0; n_resets = 0; n_proto_err = 0; n_timing_err = 0; n_reprog = 0;
    t_we_fall = 0; t_re_fall = 0;
    dbg = $test$plusargs("nanddbg");
  end

  // ---------------------------------------------------------------- helpers
  function automatic int row_of();
    return {abytes[4], abytes[3], abytes[2]};
  endfunction
  function automatic int erow_of();
    return {abytes[2], abytes[1], abytes[0]};
  endfunction
  function automatic logic [7:0] st_byte();
    return {wp_n, !busy, !busy, 4'b0, status[0]};
  endfunction
  task automatic proto_err(input string why);
    n_proto_err++;
    $display("[%0t] %s%0d: PROTOCOL ERROR: %s", $time, NAME, CH, why);
  endtask
  // busy timer: one process (no fork inside automatic tasks -- Icarus 12 limitation)
  real  busy_t;
  event ev_busy;
  task automatic go_busy(input real t);
    busy   = 1;
    busy_t = t;
    -> ev_busy;
  endtask
  always @(ev_busy) begin
    if (!stuck_busy) begin                 // stuck: R/B# never returns (timeout test)
      #(busy_t) busy = 0;
    end
  end

  // ---------------------------------------------------------------- timing checks
  always @(negedge we_n) if (!ce_n) t_we_fall = $realtime;
  always @(negedge re_n) if (!ce_n) t_re_fall = $realtime;

  // ---------------------------------------------------------------- WE# rising edge: command / address / data in
  always @(posedge we_n) begin
    if (!ce_n) begin
      if ($realtime - t_we_fall < T_WP_MIN_NS) begin
        n_timing_err++;
        $display("[%0t] %s%0d: TIMING tWP %0.1f ns < %0.1f", $time, NAME, CH, $realtime - t_we_fall, T_WP_MIN_NS);
      end
      if (cle && ale) proto_err("CLE and ALE both high");
      else if (cle) handle_cmd(dq[7:0]);
      else if (ale) handle_addr(dq[7:0]);
      else handle_din(dq);
    end
  end

  task automatic handle_cmd(input logic [7:0] c);
    if (dbg) $display("[%0t] %s%0d: CMD %02h", $time, NAME, CH, c);
    if (busy && c != 8'h70 && c != 8'hFF) proto_err($sformatf("command %02h while busy", c));
    else handle_cmd_ok(c);
  endtask

  task automatic handle_cmd_ok(input logic [7:0] c);
    if (mode == M_PG_DATA && c != 8'h10 && c != 8'h70) begin
      if (dbg) $display("[%0t] %s%0d: program cancelled by %02h", $time, NAME, CH, c);
    end
    case (c)
      8'hFF: begin
        n_resets++; mode = M_IDLE; status = 8'hE0; acnt = 0;
        go_busy(T_RST_NS);
      end
      8'h90: begin mode = M_ID_ADDR; acnt = 0; end
      8'h70: begin
        if (mode != M_STATUS) mode_before_status = mode;
        mode = M_STATUS;
      end
      8'h00: begin mode = M_RD_ADDR; acnt = 0; end
      8'h30: begin
        if (mode != M_RD_ADDR || acnt != 5) begin proto_err("30h without 00h + 5 address cycles"); mode = M_IDLE; end
        else if (row_of() >= NPAGES) begin proto_err("read row out of range"); mode = M_IDLE; end
        else begin
          int r; r = row_of();
          for (int i = 0; i < RAW_PAGE; i++) preg[i] = mem[r * RAW_PAGE + i];
          ptr = {abytes[1], abytes[0]} * BPB;
          n_reads++;
          mode = M_RD_OUT;
          if (dbg) $display("[%0t] %s%0d: READ row %0d", $time, NAME, CH, r);
          go_busy(T_R_NS);
        end
      end
      8'h80: begin
        mode = M_PG_ADDR; acnt = 0;
        for (int i = 0; i < RAW_PAGE; i++) preg[i] = 8'hFF;
      end
      8'h10: begin
        if (mode != M_PG_DATA) begin proto_err("10h without 80h + address"); mode = M_IDLE; end
        else begin
          int r; r = row_of();
          mode = M_IDLE;
          if (r >= NPAGES || !wp_n || bad[r / PAGES_PER_BLOCK]) begin
            status[0] = 1'b1;
            if (dbg) $display("[%0t] %s%0d: PROGRAM row %0d FAIL (wp_n=%0d)", $time, NAME, CH, r, wp_n);
          end else begin
            status[0] = 1'b0;
            if (programmed[r]) begin
              n_reprog++;
              $display("[%0t] %s%0d: WARNING re-program of row %0d without erase", $time, NAME, CH, r);
            end
            for (int i = 0; i < RAW_PAGE; i++) mem[r * RAW_PAGE + i] = mem[r * RAW_PAGE + i] & preg[i];
            programmed[r] = 1;
            n_progs++;
            if (dbg) $display("[%0t] %s%0d: PROGRAM row %0d", $time, NAME, CH, r);
          end
          go_busy(T_PROG_NS);
        end
      end
      8'h60: begin mode = M_ER_ADDR; acnt = 0; end
      8'hD0: begin
        if (mode != M_ER_ADDR || acnt != 3) begin proto_err("D0h without 60h + 3 address cycles"); mode = M_IDLE; end
        else begin
          int b; b = erow_of() / PAGES_PER_BLOCK;
          mode = M_IDLE;
          if (b >= BLOCKS || !wp_n || bad[b]) begin
            status[0] = 1'b1;
            if (dbg) $display("[%0t] %s%0d: ERASE block %0d FAIL", $time, NAME, CH, b);
          end else begin
            status[0] = 1'b0;
            for (int p = 0; p < PAGES_PER_BLOCK; p++) begin
              programmed[b * PAGES_PER_BLOCK + p] = 0;
              for (int i = 0; i < RAW_PAGE; i++) mem[(b * PAGES_PER_BLOCK + p) * RAW_PAGE + i] = 8'hFF;
            end
            n_erases++;
            if (dbg) $display("[%0t] %s%0d: ERASE block %0d", $time, NAME, CH, b);
          end
          go_busy(T_BERS_NS);
        end
      end
      default: begin proto_err($sformatf("unknown command %02h", c)); mode = M_IDLE; end
    endcase
  endtask

  task automatic handle_addr(input logic [7:0] a);
    if (busy) proto_err("address while busy");
    else case (mode)
      M_RD_ADDR, M_PG_ADDR: begin
        if (acnt < 5) abytes[acnt] = a; else proto_err("too many address cycles");
        acnt++;
        if (mode == M_PG_ADDR && acnt == 5) begin
          mode = M_PG_DATA;
          ptr  = {abytes[1], abytes[0]} * BPB;
        end
      end
      M_ER_ADDR: begin
        if (acnt < 3) abytes[acnt] = a; else proto_err("too many erase address cycles");
        acnt++;
      end
      M_ID_ADDR: begin
        if (a != 8'h00) proto_err("READ ID address must be 00h");
        mode = M_ID_OUT; id_idx = 0;
      end
      default: proto_err("unexpected address cycle");
    endcase
  endtask

  task automatic handle_din(input logic [DQW-1:0] d);
    if (mode != M_PG_DATA) proto_err("data-in outside a program");
    else begin
      for (int k = 0; k < BPB; k++) begin
        if (ptr + k < RAW_PAGE) preg[ptr + k] = d[k*8 +: 8];
        else proto_err("data-in beyond the page");
      end
      ptr += BPB;
    end
  endtask

  // ---------------------------------------------------------------- RE#: data out
  always @(negedge re_n) begin
    if (!ce_n) begin
      logic [DQW-1:0] v;
      v = '0;
      case (mode)
        M_STATUS: v = DQW'(st_byte());
        M_ID_OUT: begin
          v = DQW'(ID[id_idx*8 +: 8]);
          if (id_idx < 4) id_idx++;
        end
        M_RD_OUT: begin
          if (busy) proto_err("data-out while busy");
          for (int k = 0; k < BPB; k++) v[k*8 +: 8] = (ptr + k < RAW_PAGE) ? preg[ptr + k] : 8'hFF;
          ptr += BPB;
        end
        default: proto_err("RE# with no data to output");
      endcase
      #(T_REA_NS);
      dq_drv = v;
      dq_en  = 1;
    end
  end
  always @(posedge re_n) begin
    if (!ce_n && dq_en) begin
      if ($realtime - t_re_fall < T_RP_MIN_NS) begin
        n_timing_err++;
        $display("[%0t] %s%0d: TIMING tRP %0.1f ns < %0.1f", $time, NAME, CH, $realtime - t_re_fall, T_RP_MIN_NS);
      end
      #(T_RHOH_NS);
      dq_en = 0;
    end
  end
  always @(posedge ce_n) dq_en = 0;

  // ---------------------------------------------------------------- test hooks
  task automatic flip_bit(input int blk, input int pg, input int byte_off, input int bitn);
    int a; a = (blk * PAGES_PER_BLOCK + pg) * RAW_PAGE + byte_off;
    mem[a][bitn] = ~mem[a][bitn];
  endtask
  task automatic set_bad_block(input int blk, input bit v);
    bad[blk] = v;
  endtask
  task automatic set_stuck_busy(input bit v);
    stuck_busy = v;
    if (!v) busy = 0;
  endtask
  // row of the first programmed page whose raw bytes at offset off match b[31:0] (little endian), -1 if none
  function automatic int find_page(input logic [31:0] b, input int off);
    for (int r = 0; r < NPAGES; r++)
      if (programmed[r] && mem[r * RAW_PAGE + off] == b[7:0] && mem[r * RAW_PAGE + off + 1] == b[15:8] &&
          mem[r * RAW_PAGE + off + 2] == b[23:16] && mem[r * RAW_PAGE + off + 3] == b[31:24]) return r;
    return -1;
  endfunction
  function automatic logic [7:0] peek(input int blk, input int pg, input int byte_off);
    return mem[(blk * PAGES_PER_BLOCK + pg) * RAW_PAGE + byte_off];
  endfunction
  task automatic poke(input int blk, input int pg, input int byte_off, input logic [7:0] v);
    mem[(blk * PAGES_PER_BLOCK + pg) * RAW_PAGE + byte_off] = v;
  endtask
endmodule

`default_nettype wire
