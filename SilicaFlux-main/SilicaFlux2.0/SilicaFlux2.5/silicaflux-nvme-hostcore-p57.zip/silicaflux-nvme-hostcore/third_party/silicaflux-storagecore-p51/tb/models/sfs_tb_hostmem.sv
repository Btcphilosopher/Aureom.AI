// =============================================================================
// SilicaFlux StorageCore :: sfs_tb_hostmem -- simulated host memory (SFB2 slave)
//
// SIMULATION MODEL.  Host physical memory as seen through the device's
// bus-mastering port (future: PCIe endpoint AXI slave bridge):
//   * SIZE bytes, DW-bit words, byte strobes; outside SIZE -> rsp_error
//     (an "IOMMU fault" for the device);
//   * back-pressure: req_ready is low on BP_PCT % of cycles (seeded LFSR);
//   * response latency 1 + (0 .. LAT_MAX) cycles; rsp_valid held until
//     rsp_ready (SFB2 R4/R5), one transaction outstanding (R6).
// Backdoor: mem[] for the testbench (wr32/rd32 helpers).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfs_tb_hostmem #(
  parameter int DW    = 32,
  parameter int SIZE  = 1 << 20,
  localparam int SB   = DW / 8,
  localparam int OFF  = $clog2(SB),
  localparam int WORDS = SIZE / SB
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          req_valid,
  output logic               req_ready,
  input  wire logic          req_write,
  input  wire logic [31:0]   req_addr,
  input  wire logic [DW-1:0] req_wdata,
  input  wire logic [SB-1:0] req_wstrb,
  output logic               rsp_valid,
  input  wire logic          rsp_ready,
  output logic [DW-1:0]      rsp_rdata,
  output logic               rsp_error,
  input  wire int            bp_pct,
  input  wire int            lat_max
);
  logic [DW-1:0] mem [WORDS];
  logic [31:0]   lfsr;
  logic          busy, rdy_q;
  int            wait_cnt;
  int            n_rd, n_wr, n_err;

  initial begin
    for (int i = 0; i < WORDS; i++) mem[i] = '0;
    lfsr = 32'h1234_5678;
    if ($value$plusargs("hm_seed=%d", lfsr)) lfsr = lfsr ^ 32'hA5A5_0001;
    n_rd = 0; n_wr = 0; n_err = 0;
  end

  function automatic logic [31:0] step(input logic [31:0] s);
    return {s[30:0], s[31] ^ s[21] ^ s[1] ^ s[0]};
  endfunction

  assign req_ready = !busy && rdy_q;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 1'b0; rdy_q <= 1'b1; rsp_valid <= 1'b0; rsp_rdata <= '0; rsp_error <= 1'b0; wait_cnt <= 0;
    end else begin
      lfsr  <= step(lfsr);
      rdy_q <= (int'(lfsr[6:0]) % 100) >= bp_pct;
      if (req_valid && req_ready) begin
        int w; w = int'(req_addr >> OFF);
        busy <= 1'b1;
        wait_cnt <= (lat_max > 0) ? int'(lfsr[15:8]) % (lat_max + 1) : 0;
        if (req_addr >= SIZE || req_addr[OFF-1:0] != '0) begin
          rsp_error <= 1'b1; rsp_rdata <= '0; n_err <= n_err + 1;
        end else begin
          rsp_error <= 1'b0;
          if (req_write) begin
            for (int b = 0; b < SB; b++) if (req_wstrb[b]) mem[w][b*8 +: 8] <= req_wdata[b*8 +: 8];
            rsp_rdata <= '0; n_wr <= n_wr + 1;
          end else begin
            rsp_rdata <= mem[w]; n_rd <= n_rd + 1;
          end
        end
      end
      if (busy && !rsp_valid) begin
        if (wait_cnt == 0) rsp_valid <= 1'b1;
        else wait_cnt <= wait_cnt - 1;
      end
      if (rsp_valid && rsp_ready) begin
        rsp_valid <= 1'b0;
        busy <= 1'b0;
      end
    end
  end

  // backdoor
  function automatic logic [31:0] rd32(input int byte_addr);
    return mem[byte_addr >> OFF][((byte_addr >> 2) % (SB / 4 > 0 ? SB / 4 : 1)) * 32 +: 32];
  endfunction
  task automatic wr32(input int byte_addr, input logic [31:0] v);
    mem[byte_addr >> OFF][((byte_addr >> 2) % (SB / 4 > 0 ? SB / 4 : 1)) * 32 +: 32] = v;
  endtask
endmodule

`default_nettype wire
