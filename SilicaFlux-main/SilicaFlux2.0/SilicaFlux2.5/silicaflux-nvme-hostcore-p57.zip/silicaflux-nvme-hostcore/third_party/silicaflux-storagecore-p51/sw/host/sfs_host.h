/* SilicaFlux StorageCore -- minimal host-side driver API (reference) */
#ifndef SFS_HOST_H
#define SFS_HOST_H
#include <stdint.h>

typedef struct {
  void     *ctx;                                          /* backend handle (BAR mapping, simulator, ...) */
  uint32_t (*mmio_rd)(void *ctx, uint32_t bar_addr);
  void     (*mmio_wr)(void *ctx, uint32_t bar_addr, uint32_t v);
  uint32_t sq_entries, cq_entries, sq_tail, cq_head, phase, capacity;
} sfs_host_t;

typedef struct {
  uint16_t tid;
  uint8_t  status;                                        /* SFS_ST_* */
  uint8_t  err;                                           /* SFS_ERR_* */
  uint32_t result0, result1, sq_head;
} sfs_host_cpl_t;

int sfs_host_init(sfs_host_t *h, uint32_t timeout_polls);  /* EN -> RDY, reads capacity */
int sfs_host_submit(sfs_host_t *h, uint8_t op, uint8_t flags, uint16_t tid, uint64_t addr, uint32_t nlb,
                    uint64_t hbuf);
int sfs_host_reap(sfs_host_t *h, sfs_host_cpl_t *c);      /* 1: one completion consumed, 0: none */
int sfs_host_reset(sfs_host_t *h, uint32_t timeout_polls); /* controller reset (EN 1->0->1) */

#endif
