/* =============================================================================
 * SilicaFlux StorageCore -- minimal host-side driver (reference, compile-checked)
 *
 * Uses the same generated header as the firmware (sw/include/generated/sfs_map.h)
 * to drive the storage host controller through any 32-bit MMIO backend
 * (a PCIe BAR mapping in a real system; the SoC testbench implements the same
 * sequence in SystemVerilog).  Host buffers are passed as device-visible
 * (IOVA) addresses.  Single-threaded, polling or interrupt-driven by the caller.
 *
 *   cc -std=c11 -Wall -Wextra -Werror -Isw/include/generated -c sw/host/sfs_host.c
 * ===========================================================================*/
#include <stdint.h>
#include <stddef.h>
#include "sfs_map.h"
#include "sfs_host.h"

static uint32_t rd(sfs_host_t *h, uint32_t off)              { return h->mmio_rd(h->ctx, SFS_BAR_SHC_BASE + off); }
static void     wr(sfs_host_t *h, uint32_t off, uint32_t v)  { h->mmio_wr(h->ctx, SFS_BAR_SHC_BASE + off, v); }

int sfs_host_init(sfs_host_t *h, uint32_t timeout_polls) {
  if (rd(h, SFS_SHC_ID) != SFS_HIF_ID_VALUE) return -1;
  if ((rd(h, SFS_SHC_VERSION) >> 16) != (SFS_PROTO_VERSION >> 16)) return -2;
  uint32_t cap = rd(h, SFS_SHC_CAP);
  h->sq_entries = cap & 0xFFu;
  h->cq_entries = (cap >> 8) & 0xFFu;
  h->sq_tail = h->cq_head = 0;
  h->phase = 1;
  wr(h, SFS_SHC_INT_CTRL, 0x3u);
  wr(h, SFS_SHC_CTRL, 0x1u);                                   /* EN */
  for (uint32_t i = 0; i < timeout_polls; i++) {
    uint32_t st = rd(h, SFS_SHC_STATUS);
    if (st & 0x2u) return -3;                                  /* CFS */
    if (st & 0x1u) { h->capacity = rd(h, SFS_SHC_CAPACITY_LO); return 0; }
  }
  return -4;
}

int sfs_host_submit(sfs_host_t *h, uint8_t op, uint8_t flags, uint16_t tid, uint64_t addr, uint32_t nlb,
                    uint64_t hbuf) {
  uint32_t next = (h->sq_tail + 1u) % h->sq_entries;
  if (next == rd(h, SFS_SHC_SQ_HEAD)) return -1;                /* SQ full */
  uint32_t e[SFS_SQE_WORDS] = { SFS_SQE_W0(op, flags, tid), 0u, (uint32_t)addr, (uint32_t)(addr >> 32), nlb,
                                (uint32_t)hbuf, (uint32_t)(hbuf >> 32), 0u };
  for (uint32_t w = 0; w < SFS_SQE_WORDS; w++)
    wr(h, SFS_SHC_SQ_RING + h->sq_tail * SFS_SHC_SQ_RING_STRIDE + 4u * w, e[w]);
  h->sq_tail = next;
  wr(h, SFS_SHC_SQ_TAIL, h->sq_tail);
  return 0;
}

int sfs_host_reap(sfs_host_t *h, sfs_host_cpl_t *c) {
  uint32_t base = SFS_SHC_CQ_RING + h->cq_head * SFS_SHC_CQ_RING_STRIDE;
  uint32_t w3 = rd(h, base + 12u);
  if (SFS_CQE_PHASE(w3) != h->phase) return 0;                  /* nothing new */
  c->result0 = rd(h, base);
  c->result1 = rd(h, base + 4u);
  c->sq_head = rd(h, base + 8u) & 0xFFFFu;
  c->tid     = (uint16_t)SFS_CQE_TID(w3);
  c->status  = (uint8_t)SFS_CQE_STATUS(w3);
  c->err     = (uint8_t)SFS_CQE_ERR(w3);
  h->cq_head = (h->cq_head + 1u) % h->cq_entries;
  if (h->cq_head == 0u) h->phase ^= 1u;
  wr(h, SFS_SHC_CQ_HEAD, h->cq_head);
  return 1;
}

int sfs_host_reset(sfs_host_t *h, uint32_t timeout_polls) {
  wr(h, SFS_SHC_CTRL, 0u);
  for (uint32_t i = 0; i < timeout_polls; i++)
    if ((rd(h, SFS_SHC_STATUS) & 0x21u) == 0u) return sfs_host_init(h, timeout_polls);
  return -1;
}
