/* =============================================================================
 * SilicaFlux StorageCore firmware -- minimal flash translation layer
 *
 * Page-mapped FTL, one 512-byte logical block per NAND page:
 *   * L2P table in DMEM: 16-bit PPA {valid, ch[4:0], blk[5:0], pg[3:0]}.
 *   * Writes go to the open block of a channel (round robin across channels),
 *     pages strictly in order (NAND rule).  The NEXT block of every channel is
 *     erased ahead of time (internal NAND tag TAG_PREERASE|ch), so a write only
 *     waits when it outruns the pre-erase.  Program failure retires the block.
 *   * No garbage collection: capacity = NLBA_PER_CH x channels against
 *     63 x 16 data pages per channel; when a channel runs out of blocks it
 *     stops allocating (CAPACITY status).  Documented limitation.
 *   * Checkpoint (FLUSH, FUA, shutdown, power loss): snapshot of the L2P + open
 *     block + bad-block table, written to block 0 of channel 0 as a header page
 *     (magic, sequence, CRC32 of the map, CRC32 of the header) + map pages.
 *     Boot loads the newest valid checkpoint; writes after it are lost (that is
 *     the volatile-write-cache contract that FLUSH closes).
 * ===========================================================================*/
#include "fw.h"

#define CK_MAGIC   0x4C544653u          /* "SFTL" */
#define CK_VERSION 1u
#define BLK_NONE   0xFFu

uint16_t    g_l2p[MAX_NLBA];
static uint16_t ck_snap[MAX_NLBA];
ftl_stats_t g_ftl;

typedef struct { uint8_t cur_blk, cur_pg, next_blk, next_ready, erasing; } chs_t;
static chs_t    chs[MAX_CH];
static uint32_t bad[MAX_CH][2];         /* 64-bit bad-block bitmap per channel */
static uint32_t meta_wp;                /* next free page of the metadata block */

static int  is_bad(uint32_t ch, uint32_t b) { return (bad[ch][b >> 5] >> (b & 31u)) & 1u; }
static void set_bad(uint32_t ch, uint32_t b) { bad[ch][b >> 5] |= 1u << (b & 31u); }
static uint32_t find_next(uint32_t ch, uint32_t from) {
  for (uint32_t b = from; b < BLOCKS; b++) if (!is_bad(ch, b)) return b;
  return BLK_NONE;
}
static uint32_t map_pages(void) { return (g_ftl.nlba * 2u + LBA_BYTES - 1u) / LBA_BYTES; }
static uint32_t meta_slot(void) { return buf_slot(g_cfg.tags); }

/* ---------------------------------------------------------------- allocation */
uint16_t ftl_alloc(uint32_t ch) {
  chs_t *c = &chs[ch];
  if (c->cur_pg >= PPB) {
    if (c->next_blk == BLK_NONE) return PPA_NONE;
    if (!c->next_ready) return PPA_WAIT;
    c->cur_blk = c->next_blk;
    c->cur_pg = 0;
    c->next_ready = 0;
    c->next_blk = (uint8_t)find_next(ch, c->cur_blk + 1u);
  }
  return ppa_make(ch, c->cur_blk, c->cur_pg++);
}

void ftl_commit(uint32_t lba, uint16_t ppa) {
  g_l2p[lba] = ppa;
  g_ftl.writes++;
}

void ftl_program_failed(uint16_t ppa) {
  uint32_t ch = ppa_ch(ppa), b = ppa_blk(ppa);
  set_bad(ch, b);
  g_ftl.prog_fail++;
  g_ftl.retired++;
  if (chs[ch].cur_blk == b) chs[ch].cur_pg = PPB;          /* abandon the block */
  cprintf("[ftl] program failure ch%u blk %u: block retired\n", ch, b);
}

int ftl_free_channels(void) {
  int n = 0;
  for (uint32_t ch = 0; ch < g_cfg.nch; ch++) if (chs[ch].cur_pg < PPB || chs[ch].next_blk != BLK_NONE) n++;
  return n;
}

void ftl_service(void) {
  for (uint32_t ch = 0; ch < g_cfg.nch; ch++) {
    chs_t *c = &chs[ch];
    if (!c->next_ready && !c->erasing && c->next_blk != BLK_NONE && nand_free(ch) > 0) {
      nand_submit(ch, SFS_NOP_ERASE, c->next_blk * PPB, 0, 0, TAG_PREERASE | ch);
      c->erasing = 1;
    }
  }
}

/* ---------------------------------------------------------------- checkpoint job */
enum { CK_IDLE, CK_ERASE, CK_ERASE_WAIT, CK_PAGE, CK_PAGE_WAIT };
static uint32_t ck_state, ck_req, ck_page, ck_done, ck_seq_next;

void ckpt_request(void) { ck_req = 1; }
int  ckpt_busy(void) { return ck_state != CK_IDLE || ck_req; }
uint32_t ckpt_done_count(void) { return ck_done; }
uint32_t ckpt_target(void) { uint32_t t = ck_done + ((ck_state != CK_IDLE) ? 2u : 1u); ck_req = 1; return t; }

static void build_header(uint32_t a) {
  uint32_t w[128];
  memset(w, 0, sizeof(w));
  w[0] = CK_MAGIC; w[1] = CK_VERSION; w[2] = ck_seq_next; w[3] = g_ftl.nlba;
  w[4] = cc_crc32(ck_snap, g_ftl.nlba * 2u); w[5] = g_cfg.nch; w[6] = map_pages();
  for (uint32_t ch = 0; ch < g_cfg.nch; ch++) {
    w[8 + ch]      = chs[ch].cur_blk;
    w[16 + 2 * ch] = bad[ch][0];
    w[17 + 2 * ch] = bad[ch][1];
  }
  w[127] = cc_crc32(w, 127u * 4u);
  for (uint32_t i = 0; i < 128u; i++) BUFW(a + 4u * i) = w[i];
}
static void build_map(uint32_t a, uint32_t k) {
  const uint32_t *m = (const uint32_t *)&ck_snap[k * (LBA_BYTES / 2u)];
  uint32_t n = g_ftl.nlba / 2u - k * (LBA_BYTES / 4u);
  for (uint32_t i = 0; i < 128u; i++) BUFW(a + 4u * i) = (i < n) ? m[i] : 0xFFFFFFFFu;
}

void ckpt_service(void) {
  switch (ck_state) {
    case CK_IDLE:
      if (!ck_req) return;
      ck_req = 0;
      memcpy(ck_snap, g_l2p, g_ftl.nlba * 2u);
      ck_seq_next = g_ftl.seq + 1u;
      ck_page = 0;
      ck_state = (meta_wp + 1u + map_pages() > PPB) ? CK_ERASE : CK_PAGE;
      /* fall through */
    case CK_ERASE:
      if (ck_state == CK_ERASE) {
        if (nand_free(0) == 0) return;
        nand_submit(0, SFS_NOP_ERASE, META_BLK * PPB, 0, 0, TAG_CKPT);
        ck_state = CK_ERASE_WAIT;
      }
      return;
    case CK_PAGE:
      if (nand_free(0) == 0) return;
      if (ck_page == 0) build_header(meta_slot()); else build_map(meta_slot(), ck_page - 1u);
      nand_submit(0, SFS_NOP_PROGRAM, META_BLK * PPB + meta_wp, meta_slot(), LBA_BYTES, TAG_CKPT);
      ck_state = CK_PAGE_WAIT;
      return;
    default:
      return;
  }
}

/* ---------------------------------------------------------------- internal NAND completions */
void ftl_nand_done(uint32_t tag, uint32_t st) {
  if ((tag & 0xF0u) == TAG_PREERASE) {
    uint32_t ch = tag & 0xFu;
    chs_t *c = &chs[ch];
    c->erasing = 0;
    if (st == SFS_NST_OK) {
      c->next_ready = 1;
      g_ftl.prerases++;
    } else {
      set_bad(ch, c->next_blk);
      g_ftl.erase_fail++;
      g_ftl.retired++;
      c->next_blk = (uint8_t)find_next(ch, c->next_blk + 1u);
    }
  } else if (tag == TAG_CKPT) {
    if (ck_state == CK_ERASE_WAIT) {
      if (st == SFS_NST_OK) { meta_wp = 0; ck_state = CK_PAGE; ck_page = 0; }
      else { cprintf("[ftl] metadata erase failed (%u)\n", st); g_fw_errors++; ck_state = CK_IDLE; ck_done++; }
    } else if (ck_state == CK_PAGE_WAIT) {
      meta_wp++;
      if (st != SFS_NST_OK) {                                 /* retry this checkpoint from a fresh block */
        cprintf("[ftl] metadata program failed (%u)\n", st);
        ck_state = CK_ERASE;
      } else if (++ck_page == 1u + map_pages()) {
        g_ftl.seq = ck_seq_next;
        g_ftl.ckpt_count++;
        ck_done++;
        ck_state = CK_IDLE;
      } else {
        ck_state = CK_PAGE;
      }
    }
  }
}

/* ---------------------------------------------------------------- boot: load or format */
static int load_checkpoint(void) {
  uint32_t a = meta_slot(), best = 0, best_pg = 0, info;
  for (uint32_t pg = 0; pg < PPB; pg++) {
    int st = nand_sync(0, SFS_NOP_READ_PAGE, META_BLK * PPB + pg, a, LBA_BYTES, &info);
    if (st != (int)SFS_NST_OK && st != (int)SFS_NST_CORRECTED) continue;
    uint32_t w[128];
    for (uint32_t i = 0; i < 128u; i++) w[i] = BUFW(a + 4u * i);
    if (w[0] != CK_MAGIC || w[1] != CK_VERSION || w[3] != g_ftl.nlba || w[5] != g_cfg.nch) continue;
    if (cc_crc32(w, 127u * 4u) != w[127]) continue;
    if (w[2] > best) { best = w[2]; best_pg = pg; }
  }
  if (best == 0) return 0;
  uint32_t hdr[128];
  nand_sync(0, SFS_NOP_READ_PAGE, META_BLK * PPB + best_pg, a, LBA_BYTES, &info);
  for (uint32_t i = 0; i < 128u; i++) hdr[i] = BUFW(a + 4u * i);
  uint32_t *m = (uint32_t *)g_l2p;
  for (uint32_t k = 0; k < map_pages(); k++) {
    int st = nand_sync(0, SFS_NOP_READ_PAGE, META_BLK * PPB + best_pg + 1u + k, a, LBA_BYTES, &info);
    if (st != (int)SFS_NST_OK && st != (int)SFS_NST_CORRECTED) return 0;
    uint32_t n = g_ftl.nlba / 2u - k * 128u;
    for (uint32_t i = 0; i < 128u && i < n; i++) m[k * 128u + i] = BUFW(a + 4u * i);
  }
  if (cc_crc32(g_l2p, g_ftl.nlba * 2u) != hdr[4]) { memset(g_l2p, 0, sizeof(g_l2p)); return 0; }
  for (uint32_t ch = 0; ch < g_cfg.nch; ch++) {
    bad[ch][0] = hdr[16 + 2 * ch];
    bad[ch][1] = hdr[17 + 2 * ch];
    /* the open block may hold pages programmed after the checkpoint: continue in a fresh block */
    chs[ch].cur_blk = (uint8_t)hdr[8 + ch];
    chs[ch].cur_pg = PPB;
    chs[ch].next_blk = (uint8_t)find_next(ch, hdr[8 + ch] + 1u);
    chs[ch].next_ready = 0;
    chs[ch].erasing = 0;
  }
  g_ftl.seq = best;
  meta_wp = best_pg + 1u + map_pages();
  return 1;
}

void ftl_init(void) {
  memset(g_l2p, 0, sizeof(g_l2p));
  memset(bad, 0, sizeof(bad));
  memset(&g_ftl, 0, sizeof(g_ftl));
  g_ftl.nlba = NLBA_PER_CH * g_cfg.nch;
  if (g_ftl.nlba > MAX_NLBA) g_ftl.nlba = MAX_NLBA;
  if (load_checkpoint()) {
    uint32_t mapped = 0;
    for (uint32_t i = 0; i < g_ftl.nlba; i++) mapped += (g_l2p[i] & PPA_VALID) ? 1u : 0u;
    cprintf("[ftl] checkpoint seq %u loaded: %u of %u LBAs mapped\n", g_ftl.seq, mapped, g_ftl.nlba);
    return;
  }
  /* format: metadata block + first data block of every channel erased now; next blocks pre-erased */
  nand_sync(0, SFS_NOP_ERASE, META_BLK * PPB, 0, 0, 0);
  meta_wp = 0;
  for (uint32_t ch = 0; ch < g_cfg.nch; ch++) {
    uint32_t b = FIRST_DATA_BLK;
    while (b < BLOCKS && nand_sync(ch, SFS_NOP_ERASE, b * PPB, 0, 0, 0) != (int)SFS_NST_OK) { set_bad(ch, b); b++; }
    chs[ch].cur_blk = (uint8_t)b;
    chs[ch].cur_pg = 0;
    chs[ch].next_blk = (uint8_t)find_next(ch, b + 1u);
    chs[ch].next_ready = 0;
    chs[ch].erasing = 0;
  }
  cprintf("[ftl] formatted: %u LBAs x %u B over %u channel(s), %u data blocks each\n", g_ftl.nlba, LBA_BYTES,
          g_cfg.nch, BLOCKS - FIRST_DATA_BLK);
}
