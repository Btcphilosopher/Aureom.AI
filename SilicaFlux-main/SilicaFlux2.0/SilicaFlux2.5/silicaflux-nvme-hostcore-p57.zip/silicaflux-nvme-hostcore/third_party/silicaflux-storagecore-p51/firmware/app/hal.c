/* =============================================================================
 * SilicaFlux StorageCore firmware -- storage HAL
 *   discovery (identity, versions, configuration registers), NAND channel
 *   bring-up (RESET, READ_ID), queue-slot accounting, op / DMA submission.
 * ===========================================================================*/
#include "fw.h"

sfs_cfg_t g_cfg;

int nand_free(uint32_t ch) { return (int)(NAND(ch, SFS_NAND_Q_STATUS) & 0xFu); }
int dma_free(void)          { return (int)((SDMA(SFS_DMA_STATUS) >> 12) & 0xFu); }

void nand_submit(uint32_t ch, uint32_t op, uint32_t row, uint32_t buf, uint32_t len, uint32_t tag) {
  NAND(ch, SFS_NAND_OP_ROW) = row;
  NAND(ch, SFS_NAND_OP_COL) = 0u;
  NAND(ch, SFS_NAND_OP_BUF) = buf;
  NAND(ch, SFS_NAND_OP_LEN) = len;
  NAND(ch, SFS_NAND_OP_SUBMIT) = op | (g_cfg.ecc ? (1u << 8) : 0u) | ((tag & 0xFFu) << 16);
}

/* synchronous op: only while the channel has nothing else queued (boot / format) */
int nand_sync(uint32_t ch, uint32_t op, uint32_t row, uint32_t buf, uint32_t len, uint32_t *info0) {
  nand_submit(ch, op, row, buf, len, TAG_BOOT);
  uint32_t t0 = cycles(), h;
  while (!((h = NAND(ch, SFS_NAND_CPL_HEAD)) & 0x80000000u)) {
    if (cycles() - t0 > 4000000u) return -1;
  }
  if (info0) *info0 = NAND(ch, SFS_NAND_CPL_INFO0);
  NAND(ch, SFS_NAND_CPL_POP) = 0u;
  return (int)((h >> 8) & 0xFFu);
}

void dma_submit(uint32_t src, uint32_t dst, uint32_t len, uint32_t tag) {
  SDMA(SFS_DMA_SRC) = src;
  SDMA(SFS_DMA_DST) = dst;
  SDMA(SFS_DMA_LEN) = len;
  SDMA(SFS_DMA_SUBMIT) = tag & 0xFFu;
}

void buf_fill(uint32_t addr, uint32_t val, uint32_t bytes) {
  for (uint32_t i = 0; i < bytes; i += 4u) BUFW(addr + i) = val;
}

int hal_init(void) {
  if (SYS(SFS_SYS_ID) != SFS_SYS_ID_VALUE) { cprintf("[sfs] storage system page missing\n"); return 0; }
  uint32_t pv = SYS(SFS_SYS_PROTO_VERSION);
  if ((pv >> 16) != (SFS_PROTO_VERSION >> 16)) { cprintf("[sfs] protocol major %u unsupported\n", pv >> 16); return 0; }
  uint32_t c0 = SYS(SFS_SYS_CONFIG0), c2 = SYS(SFS_SYS_CONFIG2);
  g_cfg.nch       = c0 & 0xFu;
  g_cfg.cdw       = ((c0 >> 8) & 0xFu) * 8u;
  g_cfg.dw_bytes  = (c0 >> 12) & 0xFFu;
  g_cfg.tags      = (c0 >> 20) & 0xFFu;
  g_cfg.ecc       = (c0 >> 28) & 1u;
  g_cfg.ras       = (c0 >> 29) & 1u;
  g_cfg.buf_bytes = SYS(SFS_SYS_CONFIG1);
  g_cfg.page      = c2 & 0xFFFFu;
  g_cfg.aw        = (c2 >> 16) & 0xFFu;
  g_cfg.hqd       = c2 >> 24;
  cprintf("[sfs] StorageCore hw %08x proto %08x map %08x: %u ch x%u, buffer %u B, DMA %u-bit, %u tags, page %u B, "
          "ECC %u RAS %u\n", SYS(SFS_SYS_HW_VERSION), pv, SYS(SFS_SYS_MAP_VERSION), g_cfg.nch, g_cfg.cdw,
          g_cfg.buf_bytes, g_cfg.dw_bytes * 8u, g_cfg.tags, g_cfg.page, g_cfg.ecc, g_cfg.ras);
  if (g_cfg.nch == 0u || g_cfg.nch > MAX_CH || g_cfg.tags > MAX_TAGS || g_cfg.page != LBA_BYTES ||
      g_cfg.buf_bytes < (g_cfg.tags + 2u) * g_cfg.page) {
    cprintf("[sfs] unsupported configuration\n");
    return 0;
  }
  /* peripheral readiness: buffer ECC initialisation */
  uint32_t t0 = cycles();
  while (!(SYS(SFS_SYS_READY) & 1u)) if (cycles() - t0 > 2000000u) { cprintf("[sfs] buffer not ready\n"); return 0; }
  buf_fill(buf_slot(g_cfg.tags + 1u), 0u, g_cfg.page);        /* zero slot (unmapped reads) */
  /* channels */
  int mask = 0;
  for (uint32_t ch = 0; ch < g_cfg.nch; ch++) {
    uint32_t id0 = 0, info = NAND(ch, SFS_NAND_CH_INFO);
    NAND(ch, SFS_NAND_TIMING0) = 0x02020202u;                    /* tWP tWH tRP tREH = 2 cycles */
    NAND(ch, SFS_NAND_TIMING1) = 0x00000404u;
    NAND(ch, SFS_NAND_TIMEOUT) = 0x00100000u;
    NAND(ch, SFS_NAND_CH_CTRL) = 0x7u;                           /* WP_N, CE_EN, IRQ_EN */
    int r = nand_sync(ch, SFS_NOP_RESET, 0, 0, 0, 0);
    int i = nand_sync(ch, SFS_NOP_READ_ID, 0, 0, 0, &id0);
    if (r == (int)SFS_NST_OK && i == (int)SFS_NST_OK && id0 == DEV_ID0) {
      mask |= 1 << ch;
      cprintf("[sfs] ch%u: info %08x, NAND ID %08x -> %u blocks x %u pages x %u B\n", ch, info, id0, BLOCKS, PPB,
              g_cfg.page);
    } else {
      cprintf("[sfs] ch%u: NOT PRESENT (reset %d, id %d, %08x)\n", ch, r, i, id0);
    }
  }
  return mask;
}
