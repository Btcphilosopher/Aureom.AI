/* =============================================================================
 * SilicaFlux StorageCore firmware -- platform layer
 *   trap handler (MEI dispatch by INTC claim, MTI tick, MSI), interrupt
 *   priorities, timer tick + watchdog supervision, RAS reporting, console.
 * Derived from the ControlCore firmware platform layer (Project 21,
 * firmware/app/platform.c, libc_min.c): same interrupt model -- level sources,
 * the handler removes the cause, the dispatcher claims until INTC.CLAIM = 0.
 * Storage lines are serviced by DEFERRED processing: the ISR masks the line in
 * SFS_SYS IRQ_EN_* and wakes the main loop, which services every queue and
 * re-enables the line (irqs_rearm) before the next WFI.
 * ===========================================================================*/
#include "fw.h"

volatile uint32_t g_io_irqs, g_evt_irqs, g_ticks, g_mbox_pending;
volatile uint32_t g_mbox[8];
static void (*isr_table[16])(void);

uint32_t cycles(void) { return csr_read(mcycle); }

static uint64_t mtime(void) {
  uint32_t hi, lo;
  do {
    hi = MTIMER(CC_MTIMER_MTIME_HI);
    lo = MTIMER(CC_MTIMER_MTIME_LO);
  } while (hi != MTIMER(CC_MTIMER_MTIME_HI));
  return ((uint64_t)hi << 32) | lo;
}
static void timer_arm(uint32_t delta) {
  uint64_t t = mtime() + delta;
  MTIMER(CC_MTIMER_MTIMECMP_HI) = 0xFFFFFFFFu;
  MTIMER(CC_MTIMER_MTIMECMP_LO) = (uint32_t)t;
  MTIMER(CC_MTIMER_MTIMECMP_HI) = (uint32_t)(t >> 32);
}
void wdt_service(void) {
  WDT(CC_WDT_SERVICE) = CC_WDT_KEY1;
  WDT(CC_WDT_SERVICE) = CC_WDT_KEY2;
}

/* ---------------------------------------------------------------- ISRs */
static void isr_io(void)  { SYS(SFS_SYS_IRQ_EN_IO) = 0u;  (void)SYS(SFS_SYS_IRQ_EN_IO);  g_io_irqs++; }
static void isr_evt(void) { SYS(SFS_SYS_IRQ_EN_EVT) = 0u; (void)SYS(SFS_SYS_IRQ_EN_EVT); g_evt_irqs++; }
static void isr_host(void) {
  for (int i = 0; i < 8; i++) g_mbox[i] = MBOX_H2F(i);
  MBOX(CC_MBOX_H2F_ACK) = 0u;
  (void)MBOX(CC_MBOX_DB_STATUS);
  g_mbox_pending++;
}
static void isr_wdt(void) {
  WDT(CC_WDT_EWI_THRESH) = WDT_EWI;
  wdt_service();
  WDT(CC_WDT_STATUS) = CC_WDT_STATUS_EWI;
}
static void isr_dma(void) {                             /* ControlCore system DMA (unused at run time) */
  DMA(CC_DMA_INT_STATUS) = CC_DMA_INT_DONE | CC_DMA_INT_ERROR;
  (void)DMA(CC_DMA_INT_STATUS);
}
static void isr_ras(void) {
  /* ControlCore RAS: storage warnings / fatals arrive as level SOC sources;
   * they are owned by SFS_SYS RAS_STATUS, cleared by the main loop. Mask the
   * level sources here until then. */
  uint32_t st = RAS(CC_RAS_STATUS);
  uint32_t w = st & 0xFFu, f = (st >> 8) & 0xFFu;
  uint32_t lvlw = w & (1u << CC_RAS_SRC_EXT_WARN);
  uint32_t lvlf = f & (1u << (CC_RAS_SRC_EXT_FATAL - 8));
  if (lvlw) RAS(CC_RAS_WARN_EN) = RAS(CC_RAS_WARN_EN) & ~lvlw;
  if (lvlf) RAS(CC_RAS_FATAL_EN) = RAS(CC_RAS_FATAL_EN) & ~lvlf;
  RAS(CC_RAS_STATUS) = st;
  (void)RAS(CC_RAS_STATUS);
}

static void dispatch_ext(void) {
  uint32_t id, guard = 0;
  while ((id = INTC(CC_INTC_CLAIM)) != 0u) {
    uint32_t s = id - 1u;
    if (isr_table[s]) isr_table[s]();
    if (++guard > 64u || !isr_table[s]) {
      INTC(CC_INTC_ENABLE) = INTC(CC_INTC_ENABLE) & ~(1u << s);
      RAS(CC_RAS_SW_REPORT) = 0xE0000000u | s;
      guard = 0;
    }
  }
}

typedef struct { uint32_t x[32]; uint32_t mepc; } trap_frame_t;
void trap_handler(trap_frame_t *f) {
  uint32_t cause = csr_read(mcause);
  if (cause & MCAUSE_INT) {
    switch (cause & 0x1Fu) {
      case 11: dispatch_ext(); break;
      case 7:  g_ticks++; wdt_service(); timer_arm(TICK_CYCLES); break;
      case 3:  MTIMER(CC_MTIMER_MSIP) = 0u; break;
      default: break;
    }
    return;
  }
  cprintf("\n[FATAL] unexpected trap mcause=%08x mepc=%08x mtval=%08x\n", cause, f->mepc, csr_read(mtval));
  RAS(CC_RAS_SW_REPORT) = 0x80000000u | 0x7E000000u | (cause & 0xFFu);
  boot_stage(CC_BOOT_STAGE_FATAL);
  HIF(SFS_HIF_CTRL) = 0x2u;                           /* controller fatal status to the host */
  SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0xC0000000u | 0xDEADu;
  for (;;) wfi();
}

void irqs_rearm(void) {
  SYS(SFS_SYS_IRQ_EN_IO)  = IO_SOURCES;
  SYS(SFS_SYS_IRQ_EN_EVT) = EVT_SOURCES;
}

void platform_init(void) {
  isr_table[CC_IRQ_FATAL]    = isr_ras;
  isr_table[CC_IRQ_WDT]      = isr_wdt;
  isr_table[CC_IRQ_RAS_WARN] = isr_ras;
  isr_table[CC_IRQ_DMA]      = isr_dma;
  isr_table[SFS_CC_IRQ_IO]   = isr_io;
  isr_table[SFS_CC_IRQ_EVT]  = isr_evt;
  isr_table[CC_IRQ_HOST]     = isr_host;
  INTC(CC_INTC_ENABLE) = 0u;
  INTC(CC_INTC_SWPEND) = 0u;
  /* priorities: FATAL 7, WDT 6, RAS 5, storage EVENT 4, storage IO 3, DMA 2, HOST 2 */
  INTC(CC_INTC_PRIO0) = (7u << (4 * CC_IRQ_FATAL)) | (6u << (4 * CC_IRQ_WDT)) | (5u << (4 * CC_IRQ_RAS_WARN)) |
                        (2u << (4 * CC_IRQ_DMA)) | (3u << (4 * SFS_CC_IRQ_IO)) | (4u << (4 * SFS_CC_IRQ_EVT)) |
                        (2u << (4 * CC_IRQ_HOST));
  INTC(CC_INTC_PRIO1) = 0u;
  INTC(CC_INTC_THRESHOLD) = 0u;
  RAS(CC_RAS_STATUS) = 0xFFFFu;
  RAS(CC_RAS_WARN_EN) = 0x7Fu;
  RAS(CC_RAS_FATAL_EN) = 0x0Fu;
  RAS(CC_RAS_CTRL) = 0x1u | 0x4u;
  MTIMER(CC_MTIMER_PRESCALE) = 0u;
  timer_arm(TICK_CYCLES);
  WDT(CC_WDT_PRESCALE) = WDT_PRESCALE;
  WDT(CC_WDT_LOAD) = WDT_LOAD;
  WDT(CC_WDT_EWI_THRESH) = WDT_EWI;
  WDT(CC_WDT_CTRL) = CC_WDT_CTRL_EN | CC_WDT_CTRL_EWI_EN;
  wdt_service();
  INTC(CC_INTC_ENABLE) = (1u << CC_IRQ_FATAL) | (1u << CC_IRQ_WDT) | (1u << CC_IRQ_RAS_WARN) | (1u << CC_IRQ_DMA) |
                         (1u << SFS_CC_IRQ_IO) | (1u << SFS_CC_IRQ_EVT) | (1u << CC_IRQ_HOST);
  csr_write(mie, MIE_MEIE | MIE_MTIE | MIE_MSIE);
  irq_enable();
}

/* ---------------------------------------------------------------- libc subset + console (MAILBOX DIAG FIFO) */
void *memcpy(void *d, const void *s, size_t n) {
  uint8_t *dp = (uint8_t *)d;
  const uint8_t *sp = (const uint8_t *)s;
  while (n--) *dp++ = *sp++;
  return d;
}
void *memset(void *d, int c, size_t n) {
  uint8_t *dp = (uint8_t *)d;
  while (n--) *dp++ = (uint8_t)c;
  return d;
}
void con_putc(char c) { MBOX(CC_MBOX_DIAG_TX) = (uint8_t)c; }
void con_puts(const char *s) { while (*s) con_putc(*s++); }
static void put_u(uint32_t v, unsigned base, int width, char pad) {
  char buf[12]; int n = 0;
  do { uint32_t d = v % base; buf[n++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); v /= base; } while (v);
  while (n < width) buf[n++] = pad;
  while (n) con_putc(buf[--n]);
}
void cprintf(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  for (; *fmt; fmt++) {
    if (*fmt != '%') { con_putc(*fmt); continue; }
    int width = 0; char pad = ' ';
    fmt++;
    if (*fmt == '0') { pad = '0'; fmt++; }
    while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
    switch (*fmt) {
      case 'c': con_putc((char)va_arg(ap, int)); break;
      case 's': con_puts(va_arg(ap, const char *)); break;
      case 'u': put_u(va_arg(ap, uint32_t), 10, width, pad); break;
      case 'd': { int v = va_arg(ap, int); if (v < 0) { con_putc('-'); v = -v; } put_u((uint32_t)v, 10, width, pad); break; }
      case 'x': put_u(va_arg(ap, uint32_t), 16, width, pad); break;
      case '%': con_putc('%'); break;
      default:  con_putc('?'); break;
    }
  }
  va_end(ap);
}
