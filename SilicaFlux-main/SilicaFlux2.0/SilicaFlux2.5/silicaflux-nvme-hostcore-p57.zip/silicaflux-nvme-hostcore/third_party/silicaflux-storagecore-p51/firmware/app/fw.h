/* =============================================================================
 * SilicaFlux StorageCore firmware (Project 51) -- shared declarations
 *
 * Runs on the unmodified ControlCore RV32IM CPU (Project 21).  Reuses the
 * ControlCore runtime unchanged: crt0.S, trap_entry.S, fw.ld, crc32.c, cc_hw.h,
 * the generated cc_memmap.h, the boot ROM and the image format (mkimage.py).
 * Storage registers come from the generated sw/include/generated/sfs_map.h.
 * ===========================================================================*/
#ifndef SFS_FW_H
#define SFS_FW_H

#include <stdarg.h>
#include "cc_hw.h"
#include "sfs_map.h"

#define FW_VERSION      0x00510100u          /* Project 51, firmware 1.0 */
#define TICK_CYCLES     20000u
#define WDT_PRESCALE    63u
#define WDT_LOAD        50000u
#define WDT_EWI         5000u

/* ---------------------------------------------------------------- register access */
#define SYS(o)          REG32(SFS_SYS_BASE + (o))
#define CMDR(o)         REG32(SFS_CMD_BASE + (o))
#define SDMA(o)         REG32(SFS_DMA_BASE + (o))
#define NAND(c, o)      REG32(SFS_NAND_BASE + (uint32_t)(c) * SFS_NAND_CH_STRIDE + (o))
#define HIF(o)          REG32(SFS_HIF_BASE + (o))
#define BUFW(a)         REG32(a)

/* the storage interrupt lines occupy the ControlCore accelerator IRQ slots */
#define SFS_CC_IRQ_IO   CC_IRQ_TENSOR                 /* IRQ 4 <- SFS_SYS IRQ_EN_IO  */
#define SFS_CC_IRQ_EVT  CC_IRQ_VECTOR                 /* IRQ 5 <- SFS_SYS IRQ_EN_EVT */
#define IO_SOURCES      ((1u << SFS_IRQ_CMD) | (1u << SFS_IRQ_DMA) | (1u << SFS_IRQ_NAND))
#define EVT_SOURCES     ((1u << SFS_IRQ_HIF) | (1u << SFS_IRQ_PLP) | (1u << SFS_IRQ_RAS))

/* ---------------------------------------------------------------- NAND device geometry
 * The controller is geometry-agnostic; the firmware keeps a table keyed by the
 * READ_ID bytes.  One entry: the device modelled in tb/models (ID 5F DA A1 10 00). */
#define DEV_ID0         0x10A1DA5Fu
#define PPB             16u                          /* pages per block           */
#define BLOCKS          64u                          /* blocks per channel (LUN)  */
#define META_BLK        0u                           /* block 0: FTL checkpoint log (channel 0) */
#define FIRST_DATA_BLK  1u
#define MAX_CH          8u
#define MAX_TAGS        64u
#define MAX_NLBA        1024u
#define NLBA_PER_CH     256u
#define LBA_BYTES       512u

/* internal NAND tags (host commands use their own tag 0..CMD_QUEUE_DEPTH-1) */
#define TAG_PREERASE    0x80u                        /* | channel */
#define TAG_CKPT        0x90u
#define TAG_BOOT        0xA0u

typedef struct {
  uint32_t nch, cdw, dw_bytes, tags, ecc, ras, buf_bytes, page, aw, hqd;
} sfs_cfg_t;
extern sfs_cfg_t g_cfg;

/* ---------------------------------------------------------------- libc subset / console */
void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
void  con_putc(char c);
void  con_puts(const char *s);
void  cprintf(const char *fmt, ...);
#include "cc_crc32.h"                         /* ControlCore common/crc32.c: cc_crc32() */

/* ---------------------------------------------------------------- platform (traps, INTC, timer, WDT) */
extern volatile uint32_t g_io_irqs, g_evt_irqs, g_ticks, g_mbox_pending;
extern volatile uint32_t g_mbox[8];
void     platform_init(void);
uint32_t cycles(void);
void     wdt_service(void);
void     irqs_rearm(void);                          /* re-enable the storage lines after servicing */

/* ---------------------------------------------------------------- storage HAL */
static inline uint32_t buf_slot(uint32_t s) { return SFS_BUF_BASE + s * g_cfg.page; }
int  hal_init(void);                                /* discovery + channel bring-up; returns channel mask */
int  nand_free(uint32_t ch);                        /* free op-queue slots */
void nand_submit(uint32_t ch, uint32_t op, uint32_t row, uint32_t buf, uint32_t len, uint32_t tag);
int  nand_sync(uint32_t ch, uint32_t op, uint32_t row, uint32_t buf, uint32_t len, uint32_t *info0);
int  dma_free(void);
void dma_submit(uint32_t src, uint32_t dst, uint32_t len, uint32_t tag);
void buf_fill(uint32_t addr, uint32_t val, uint32_t bytes);

/* ---------------------------------------------------------------- FTL */
#define PPA_VALID       0x8000u
#define PPA_NONE        0xFFFFu
#define PPA_WAIT        0xFFFEu
static inline uint32_t ppa_ch(uint32_t p)  { return (p >> 10) & 0x1Fu; }
static inline uint32_t ppa_blk(uint32_t p) { return (p >> 4) & 0x3Fu; }
static inline uint32_t ppa_pg(uint32_t p)  { return p & 0xFu; }
static inline uint32_t ppa_row(uint32_t p) { return ppa_blk(p) * PPB + ppa_pg(p); }
static inline uint16_t ppa_make(uint32_t ch, uint32_t blk, uint32_t pg) {
  return (uint16_t)(PPA_VALID | (ch << 10) | (blk << 4) | pg);
}
typedef struct {
  uint32_t nlba, seq, ckpt_count, writes, reads, unmapped_reads, prog_fail, erase_fail, retired, prerases;
} ftl_stats_t;
extern ftl_stats_t g_ftl;
extern uint16_t g_l2p[MAX_NLBA];
void     ftl_init(void);                            /* load the newest checkpoint or format */
uint16_t ftl_alloc(uint32_t ch);                    /* next page of the channel's open block, PPA_WAIT, PPA_NONE */
void     ftl_commit(uint32_t lba, uint16_t ppa);
void     ftl_program_failed(uint16_t ppa);          /* retire the block, move on */
void     ftl_service(void);                         /* pre-erase the next block of every channel */
void     ftl_nand_done(uint32_t tag, uint32_t st);  /* internal NAND completion */
int      ftl_free_channels(void);                   /* channels that can still allocate */
/* checkpoint job */
void     ckpt_request(void);
int      ckpt_busy(void);
uint32_t ckpt_done_count(void);
uint32_t ckpt_target(void);                        /* request a checkpoint that starts after now; returns the count to wait for */
void     ckpt_service(void);

/* ---------------------------------------------------------------- command processing */
int      cmd_service(void);                         /* fetch, advance, complete; returns progress */
void     cmd_dma_done(uint32_t tag, uint32_t st, uint32_t info);
void     cmd_nand_done(uint32_t tag, uint32_t st, uint32_t sr, uint32_t i0, uint32_t i1);
void     cmd_abort_all(void);
int      cmd_active(void);                          /* number of commands in progress */
extern uint32_t g_cmd_done, g_cmd_err, g_fw_errors;

#endif /* SFS_FW_H */
