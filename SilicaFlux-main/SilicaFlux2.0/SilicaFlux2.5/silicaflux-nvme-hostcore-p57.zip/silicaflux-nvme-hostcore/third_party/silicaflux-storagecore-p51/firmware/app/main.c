/* =============================================================================
 * SilicaFlux StorageCore firmware -- bring-up and main event loop
 *
 * Boot (after the ControlCore boot ROM accepted the image):
 *   FW_INIT        platform: INTC priorities, timer tick, watchdog, RAS enables
 *   ACC_DISCOVERY  storage discovery: SFS_SYS identity / versions / configuration,
 *                  buffer ready, every NAND channel RESET + READ_ID
 *   SELF_TEST      buffer pattern test, FTL load (newest checkpoint) or format
 *   CMDPROC_READY  capacity / MDTS published, host-interface events enabled,
 *                  storage interrupt lines enabled, host write lock + storage
 *                  management lock set
 *   HOST_READY     capabilities in the mailbox, host_ready pin; if the host has
 *                  already set CTRL.EN the controller reports RDY
 * Main loop: service every queue until no progress, then WFI with the storage
 * lines re-armed (deferred interrupt processing, platform.c).
 * Events: controller enable / reset / shutdown (HIF), power loss (PLP),
 * storage RAS, mailbox commands (PING, vendor PHYS_EN, SHUTDOWN = end of test).
 * ===========================================================================*/
#include "fw.h"

volatile uint32_t g_resetting;
static uint32_t g_shn, g_shn_target, g_plp, g_plp_target, g_down, g_down_target, g_ras_events, g_db_errs;
static uint32_t g_mbox_seq;
static int      g_selftest_fail;

#define MBOX_CMD_SET_PHYS_EN  0x51u      /* vendor: arg1 = 1 allows ADDR_TYPE = PHYSICAL commands */
#define MBOX_CMD_STATS        0x52u

static void mbox_reply(uint32_t sts, uint32_t cmd, const uint32_t *d, int n) {
  for (int i = 0; i < 7; i++) MBOX_F2H(1 + i) = (i < n) ? d[i] : 0u;
  MBOX_F2H(0) = sts | (cmd << 8) | ((g_mbox_seq & 0xFFFFu) << 16);
  MBOX(CC_MBOX_F2H_RING) = cmd;
}

static void hif_set_rdy(int on) {
  uint32_t c = HIF(SFS_HIF_CTRL);
  HIF(SFS_HIF_CTRL) = on ? (c | 1u) : (c & ~1u);
}
static void hif_set_shst(uint32_t s) {
  HIF(SFS_HIF_CTRL) = (HIF(SFS_HIF_CTRL) & ~0xCu) | (s << 2);
}

/* ---------------------------------------------------------------- events */
static int events(void) {
  int n = 0;
  uint32_t ev = HIF(SFS_HIF_EVT_STATUS);
  if (ev) {
    HIF(SFS_HIF_EVT_STATUS) = ev;
    n++;
    if (ev & (1u << SFS_HEVT_EN_FALL)) {
      g_resetting = 1;
      cmd_abort_all();
      cprintf("[hif] controller reset requested (EN 1->0): aborting %d command(s)\n", cmd_active());
    }
    if (ev & (1u << SFS_HEVT_RESET_DONE)) { g_resetting = 0; cprintf("[hif] controller reset complete\n"); }
    if (ev & (1u << SFS_HEVT_SHN)) {
      g_shn = 1; g_shn_target = ckpt_target(); hif_set_shst(1u);
      cprintf("[hif] shutdown requested: committing the FTL map\n");
    }
    if (ev & (1u << SFS_HEVT_DB_ERR)) { g_db_errs++; cprintf("[hif] invalid doorbell %08x\n", HIF(SFS_HIF_DB_ERR_INFO)); }
  }
  uint32_t s = HIF(SFS_HIF_STATE);
  if (!g_resetting && (s & 1u) && !(s & 4u) && !(s & 8u)) {
    hif_set_rdy(1);
    cprintf("[hif] controller enabled -> RDY\n");
    n++;
  }
  if (g_shn && ckpt_done_count() >= g_shn_target) { g_shn = 0; hif_set_shst(2u); cprintf("[hif] shutdown complete\n"); n++; }

  /* power loss */
  uint32_t ps = SYS(SFS_SYS_PLP_STATUS);
  if (g_plp == 0 && (ps & 4u) && !(ps & 0x10u)) {
    g_plp = 1;
    cprintf("[plp] power-fail: new commands refused by hardware, draining %d in flight\n", cmd_active());
    n++;
  }
  if (g_plp == 1 && cmd_active() == 0) { g_plp = 2; g_plp_target = ckpt_target(); n++; }
  if (g_plp == 2 && ckpt_done_count() >= g_plp_target) {
    SYS(SFS_SYS_PLP_CTRL) = 0x5u;                         /* FW_SAFE | AUTO_WP -> NAND WP# asserted */
    g_plp = 3;
    cprintf("[plp] drained, FTL checkpoint seq %u committed, FW_SAFE (WP# asserted)\n", g_ftl.seq);
    n++;
  }
  if (g_plp == 3 && !(ps & 1u)) {
    SYS(SFS_SYS_PLP_CTRL) = 0x104u;                       /* CLR, keep AUTO_WP */
    g_plp = 0;
    cprintf("[plp] power restored: resuming\n");
    n++;
  }

  /* storage RAS (sticky): log, clear, re-enable the ControlCore SOC sources masked by isr_ras */
  uint32_t r = SYS(SFS_SYS_RAS_STATUS) & (SYS(SFS_SYS_RAS_WARN_EN) | SYS(SFS_SYS_RAS_FATAL_EN));
  if (r) {
    g_ras_events++;
    cprintf("[ras] storage RAS status %03x\n", r);
    SYS(SFS_SYS_RAS_STATUS) = r;
    RAS(CC_RAS_WARN_EN) = RAS(CC_RAS_WARN_EN) | (1u << CC_RAS_SRC_EXT_WARN);
    RAS(CC_RAS_FATAL_EN) = RAS(CC_RAS_FATAL_EN) | (1u << (CC_RAS_SRC_EXT_FATAL - 8));
    n++;
  }

  /* mailbox */
  if (g_mbox_pending) {
    g_mbox_pending = 0;
    g_mbox_seq++;
    uint32_t cmd = g_mbox[0] & 0xFFu;
    n++;
    if (cmd == CC_MBOX_CMD_PING) {
      uint32_t d[2] = { g_mbox[1], FW_VERSION };
      mbox_reply(CC_MBOX_STS_OK, cmd, d, 2);
    } else if (cmd == MBOX_CMD_SET_PHYS_EN) {
      SYS(SFS_SYS_SEC_CTRL) = (g_mbox[1] ? 1u : 0u) | 2u;
      mbox_reply(CC_MBOX_STS_OK, cmd, 0, 0);
    } else if (cmd == MBOX_CMD_STATS) {
      uint32_t d[6] = { g_cmd_done, g_cmd_err, g_ftl.seq, g_ftl.writes, g_fw_errors, g_ras_events };
      mbox_reply(CC_MBOX_STS_OK, cmd, d, 6);
    } else if (cmd == CC_MBOX_CMD_SHUTDOWN) {
      g_down = 1; g_down_target = ckpt_target();
    } else {
      mbox_reply(CC_MBOX_STS_BAD_CMD, cmd, 0, 0);
    }
  }
  if (g_down == 1 && ckpt_done_count() >= g_down_target && cmd_active() == 0) {
    g_down = 2;
    int fail = g_selftest_fail || g_fw_errors != 0u || g_mbox[1] != 0u;
    cprintf("SHUTDOWN: commands %u (errors reported to host %u), FTL writes %u reads %u, checkpoint seq %u, "
            "firmware errors %u, host-reported failures %u -> %s\n", g_cmd_done, g_cmd_err, g_ftl.writes,
            g_ftl.reads, g_ftl.seq, g_fw_errors, g_mbox[1], fail ? "FAIL" : "PASS");
    uint32_t d[4] = { g_cmd_done, g_cmd_err, g_ftl.seq, g_fw_errors };
    mbox_reply(fail ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK, CC_MBOX_CMD_SHUTDOWN, d, 4);
    boot_stage(CC_BOOT_STAGE_SHUTDOWN);
    SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0x80000000u | (fail ? 0x40000000u : 0u) | (g_cmd_done & 0xFFFFu);
  }
  return n;
}

/* ---------------------------------------------------------------- self test */
static void selftest(void) {
  uint32_t a = buf_slot(g_cfg.tags);
  for (uint32_t i = 0; i < 16u; i++) BUFW(a + 4u * i) = 0xA5A50000u ^ (a + 4u * i);
  for (uint32_t i = 0; i < 16u; i++) if (BUFW(a + 4u * i) != (0xA5A50000u ^ (a + 4u * i))) g_selftest_fail++;
  if (SYS(SFS_SYS_READY) & 0x100u) { cprintf("[st] power-fail pin asserted at boot\n"); }
  if (g_selftest_fail) cprintf("[st] buffer pattern test FAILED\n");
}

int main(void) {
  boot_stage(CC_BOOT_STAGE_FW_INIT);
  platform_init();
  uint32_t cause = SYSCTRL(CC_SYSCTRL_RESET_CAUSE);
  SYSCTRL(CC_SYSCTRL_RESET_CAUSE) = cause;
  SYSCTRL(CC_SYSCTRL_FW_VERSION) = FW_VERSION;
  cprintf("\nSilicaFlux StorageCore firmware %08x on ControlCore %08x (reset cause %x)\n", FW_VERSION,
          SYSCTRL(CC_SYSCTRL_HW_VERSION), cause);
  cprintf("SECURITY: firmware image integrity = CRC32 only; NO authentication is implemented\n");

  boot_stage(CC_BOOT_STAGE_ACC_DISCOVERY);
  int mask = hal_init();
  int degraded = (mask == 0) || (mask != (1 << g_cfg.nch) - 1);
  if (mask == 0) {
    cprintf("[sfs] no usable storage: staying in FATAL\n");
    HIF(SFS_HIF_CTRL) = 0x2u;
    boot_stage(CC_BOOT_STAGE_FATAL);
    for (;;) wfi();
  }

  boot_stage(CC_BOOT_STAGE_SELF_TEST);
  selftest();
  ftl_init();

  /* publish the namespace and arm the event sources */
  CMDR(SFS_CMD_CAP_LO) = g_ftl.nlba;
  CMDR(SFS_CMD_CAP_HI) = 0u;
  CMDR(SFS_CMD_MDTS) = 16u;
  HIF(SFS_HIF_EVT_EN) = 0x1Fu;
  SYS(SFS_SYS_RAS_STATUS) = 0x3FFu;
  SYS(SFS_SYS_RAS_WARN_EN) = (1u << SFS_RAS_NAND_UE) | (1u << SFS_RAS_DMA_ERR) | (1u << SFS_RAS_NAND_TMO) |
                             (1u << SFS_RAS_FW_PROTO) | (1u << SFS_RAS_SEC_VIOL) | (1u << SFS_RAS_FABRIC_DEC);
  SYS(SFS_SYS_RAS_FATAL_EN) = (1u << SFS_RAS_BUF_UE);
  SYS(SFS_SYS_PLP_CTRL) = 0x4u;                           /* AUTO_WP */
  SYS(SFS_SYS_SEC_CTRL) = 0x2u;                           /* HOST_MGMT_LOCK; PHYS_EN off */
  SEC(CC_SEC_CTRL) = 1u;                                  /* ControlCore host write lock (IMEM/DMEM/ROM) */
  irqs_rearm();

  boot_stage(CC_BOOT_STAGE_CMDPROC_READY);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING | CC_HOST_STATUS_CMDPROC_READY |
                                    (degraded ? CC_HOST_STATUS_DEGRADED : 0u);
  boot_stage(CC_BOOT_STAGE_HOST_READY);
  {
    uint32_t d[6] = { (uint32_t)mask, g_ftl.nlba, SYS(SFS_SYS_CONFIG0), cause, FW_VERSION, g_ftl.seq };
    mbox_reply(CC_MBOX_STS_OK, 0u, d, 6);
  }
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = SYSCTRL(CC_SYSCTRL_HOST_STATUS) | CC_HOST_STATUS_HOST_READY;
  cprintf("[sfs] HOST READY: %u LBAs x %u B, %u tag(s), channels %x%s\n", g_ftl.nlba, LBA_BYTES, g_cfg.tags, mask,
          degraded ? " (DEGRADED)" : "");

  for (;;) {
    int n;
    do {
      n = events();
      n += cmd_service();
    } while (n);
    uint32_t m = irq_save();
    if (!g_mbox_pending) {
      /* do not re-arm the power-loss source while draining: it stays asserted until FW_SAFE */
      SYS(SFS_SYS_IRQ_EN_IO) = IO_SOURCES;
      SYS(SFS_SYS_IRQ_EN_EVT) = (g_plp == 1 || g_plp == 2) ? (EVT_SOURCES & ~(1u << SFS_IRQ_PLP)) : EVT_SOURCES;
      wfi();
    }
    irq_restore(m);
  }
}
