/* =============================================================================
 * SilicaFlux StorageCore firmware -- command processing
 *
 * Every host command the command controller accepted is owned by the firmware
 * under its tag (0 .. CMD_QUEUE_DEPTH-1) until CPL_POST.  Each tag has a small
 * state machine; the tag is also the hardware tag of its NAND and DMA
 * operations, so completions route back without lookup.  All commands advance
 * concurrently: a READ waiting for tR on one channel does not block a WRITE's
 * DMA, an IDENTIFY, or a READ on another channel; completions are posted in
 * the order they finish (out of order w.r.t. submission).
 *   READ   : per block  NAND READ_PAGE -> buffer slot -> DMA -> host   (unmapped: DMA from the zero slot)
 *   WRITE  : per block  DMA host -> slot -> FTL alloc -> NAND PROGRAM -> L2P update  (FUA: + checkpoint)
 *   FLUSH  : checkpoint started after the command arrived
 *   DEALLOCATE: L2P entries cleared
 *   IDENTIFY / GET_LOG: 512-byte structure built in the slot -> DMA -> host
 *   ERASE (physical) : NAND ERASE.  PHYSICAL READ / WRITE bypass the FTL.
 * ===========================================================================*/
#include "fw.h"


enum {
  S_FREE, S_RD_NEXT, S_RD_NAND, S_RD_DMA_ISSUE, S_RD_DMA, S_WR_DMA_ISSUE, S_WR_DMA, S_WR_PROG_ISSUE, S_WR_PROG,
  S_OUT_ISSUE, S_OUT_DMA, S_CKPT_WAIT, S_ER_ISSUE, S_ER_WAIT
};
typedef struct {
  uint8_t  state, op, phys, fua, abort, retries, zero, st_final;
  uint16_t tid, ppa;
  uint32_t lba, nlb, i, hbuf, ce_bits, ck_target;
} ctx_t;
static ctx_t ctx[MAX_TAGS];
static uint32_t rr_ch;
uint32_t g_cmd_done, g_cmd_err, g_fw_errors;
extern volatile uint32_t g_resetting;

int cmd_active(void) {
  int n = 0;
  for (uint32_t t = 0; t < g_cfg.tags; t++) n += ctx[t].state != S_FREE;
  return n;
}

static void finish(uint32_t tag, uint32_t st, uint32_t err) {
  ctx_t *c = &ctx[tag];
  CMDR(SFS_CMD_CPL_RESULT0) = c->i;                         /* blocks transferred */
  CMDR(SFS_CMD_CPL_RESULT1) = c->ce_bits;                   /* ECC bits corrected on the way */
  CMDR(SFS_CMD_CPL_POST) = tag | (st << 8) | (err << 16);
  c->state = S_FREE;
  g_cmd_done++;
  if (st != SFS_ST_SUCCESS) g_cmd_err++;
}

/* physical address of block i of a PHYSICAL command: SFS_PPA(ch, blk, pg + i) */
static int phys_ppa(ctx_t *c, uint32_t i, uint16_t *p) {
  uint32_t ch = (c->lba >> 24) & 0xFFu, blk = (c->lba >> 8) & 0xFFFFu, pg = (c->lba & 0xFFu) + i;
  if (ch >= g_cfg.nch || blk >= BLOCKS || pg >= PPB) return -1;
  *p = ppa_make(ch, blk, pg);
  return 0;
}

static void build_identify(uint32_t a) {
  uint32_t w[128];
  static const char model[32] = "SilicaFlux StorageCore P51";
  memset(w, 0, sizeof(w));
  w[0] = SFS_SYS_ID_VALUE; w[1] = SYS(SFS_SYS_PROTO_VERSION); w[2] = SYS(SFS_SYS_HW_VERSION); w[3] = FW_VERSION;
  w[4] = g_ftl.nlba; w[5] = 0; w[6] = LBA_BYTES; w[7] = CMDR(SFS_CMD_MDTS);
  w[8] = g_cfg.nch; w[9] = g_cfg.tags; w[10] = g_cfg.page; w[11] = g_cfg.ecc | (g_cfg.ras << 1);
  w[12] = g_cfg.buf_bytes; w[13] = DEV_ID0; w[14] = BLOCKS; w[15] = PPB;
  memcpy(&w[16], model, sizeof(model));
  w[24] = SYS(SFS_SYS_CONFIG0); w[25] = SYS(SFS_SYS_CONFIG2); w[26] = SEC(CC_SEC_CAPS); w[27] = 0;  /* no authentication */
  for (uint32_t i = 0; i < 128u; i++) BUFW(a + 4u * i) = w[i];
}

static void build_log(uint32_t a) {
  uint32_t w[128], mapped = 0;
  for (uint32_t i = 0; i < g_ftl.nlba; i++) mapped += (g_l2p[i] & PPA_VALID) ? 1u : 0u;
  memset(w, 0, sizeof(w));
  w[0] = 0x474F4C53u;                                       /* "SLOG" */
  w[1] = g_cmd_done; w[2] = g_cmd_err; w[3] = g_ftl.writes; w[4] = g_ftl.reads; w[5] = g_ftl.unmapped_reads;
  w[6] = SYS(SFS_SYS_NAND_CE_COUNT); w[7] = SYS(SFS_SYS_NAND_UE_COUNT);
  w[8] = SYS(SFS_SYS_BUF_CE_COUNT); w[9] = SYS(SFS_SYS_BUF_UE_COUNT); w[10] = SYS(SFS_SYS_PLP_EVENTS);
  w[11] = g_ftl.seq; w[12] = g_ftl.ckpt_count; w[13] = g_ftl.prog_fail; w[14] = g_ftl.erase_fail;
  w[15] = g_ftl.retired; w[16] = mapped; w[17] = SYS(SFS_SYS_PERF_CYCLES); w[18] = SYS(SFS_SYS_PERF_HOST_CMDS);
  w[19] = SYS(SFS_SYS_PERF_DMA_BYTES); w[20] = SYS(SFS_SYS_PERF_NAND_RD); w[21] = SYS(SFS_SYS_PERF_NAND_PG);
  w[22] = SYS(SFS_SYS_PERF_NAND_ER); w[23] = SYS(SFS_SYS_PERF_CMD_LATMAX); w[24] = g_ftl.prerases;
  w[25] = SYS(SFS_SYS_RAS_STATUS); w[26] = g_fw_errors; w[27] = SYS(SFS_SYS_SEC_STATUS);
  w[28] = SYS(SFS_SYS_PERF_CQ_FULL); w[29] = SYS(SFS_SYS_PERF_FAB_STALL); w[30] = SYS(SFS_SYS_PERF_NAND_BUSY);
  w[31] = HIF(SFS_HIF_CQ_STALLS);
  for (uint32_t i = 0; i < 128u; i++) BUFW(a + 4u * i) = w[i];
}

/* ---------------------------------------------------------------- start a fetched command */
static void start(uint32_t tag) {
  ctx_t *c = &ctx[tag];
  uint32_t a = buf_slot(tag);
  if (g_resetting) { finish(tag, SFS_ST_ABORT_RESET, SFS_ERR_NOT_READY); return; }
  switch (c->op) {
    case SFS_OP_READ:  c->state = S_RD_NEXT; break;
    case SFS_OP_WRITE: c->state = S_WR_DMA_ISSUE; break;
    case SFS_OP_FLUSH: c->ck_target = ckpt_target(); c->state = S_CKPT_WAIT; break;
    case SFS_OP_DEALLOCATE:
      for (uint32_t i = 0; i < c->nlb; i++) g_l2p[c->lba + i] = 0;
      c->i = c->nlb;
      finish(tag, SFS_ST_SUCCESS, 0);
      break;
    case SFS_OP_IDENTIFY: build_identify(a); c->state = S_OUT_ISSUE; break;
    case SFS_OP_GET_LOG:  build_log(a);      c->state = S_OUT_ISSUE; break;
    case SFS_OP_ERASE: {
      uint16_t p;
      if (c->nlb != 1u || phys_ppa(c, 0, &p)) { finish(tag, SFS_ST_INVALID_FIELD, SFS_ERR_FW); return; }
      c->ppa = p;
      c->state = S_ER_ISSUE;
      break;
    }
    default: finish(tag, SFS_ST_INVALID_OPCODE, SFS_ERR_FW); return;
  }
  if (c->phys && c->state != S_FREE && c->op != SFS_OP_ERASE) {
    uint16_t p;
    if (phys_ppa(c, c->nlb - 1u, &p)) finish(tag, SFS_ST_INVALID_FIELD, SFS_ERR_FW);
  }
}

static int fetch(void) {
  int n = 0;
  uint32_t h;
  while ((h = CMDR(SFS_CMD_FWQ_HEAD)) & 0x80000000u) {
    uint32_t tag = h & 0xFFu, base = SFS_CMD_TAG_WIN + tag * SFS_CMD_TAG_STRIDE;
    ctx_t *c = &ctx[tag];
    uint32_t w0 = CMDR(base + 0u);
    memset(c, 0, sizeof(*c));
    c->op   = (uint8_t)(w0 & 0xFFu);
    c->phys = (uint8_t)((w0 >> 8) & SFS_SQE_FLAG_PHYS);
    c->fua  = (uint8_t)(((w0 >> 8) & SFS_SQE_FLAG_FUA) != 0u);
    c->tid  = (uint16_t)(w0 >> 16);
    c->lba  = CMDR(base + 8u);
    c->nlb  = CMDR(base + 16u);
    c->hbuf = CMDR(base + 20u);
    CMDR(SFS_CMD_FWQ_POP) = 0u;
    start(tag);
    n++;
  }
  return n;
}

/* ---------------------------------------------------------------- issue the next hardware operation */
static int issue(uint32_t tag) {
  ctx_t *c = &ctx[tag];
  uint32_t slot = buf_slot(tag);
  if (c->abort && (c->state == S_RD_NEXT || c->state == S_RD_DMA_ISSUE || c->state == S_WR_DMA_ISSUE ||
                   c->state == S_WR_PROG_ISSUE || c->state == S_OUT_ISSUE || c->state == S_CKPT_WAIT ||
                   c->state == S_ER_ISSUE)) {
    finish(tag, SFS_ST_ABORT_RESET, SFS_ERR_NOT_READY);
    return 1;
  }
  switch (c->state) {
    case S_RD_NEXT: {
      if (c->i == c->nlb) { finish(tag, SFS_ST_SUCCESS, 0); return 1; }
      uint16_t p;
      if (c->phys) phys_ppa(c, c->i, &p); else p = g_l2p[c->lba + c->i];
      if (!(p & PPA_VALID)) { c->zero = 1; c->state = S_RD_DMA_ISSUE; g_ftl.unmapped_reads++; return 1; }
      if (nand_free(ppa_ch(p)) == 0) return 0;
      c->zero = 0;
      c->ppa = p;
      nand_submit(ppa_ch(p), SFS_NOP_READ_PAGE, ppa_row(p), slot, LBA_BYTES, tag);
      c->state = S_RD_NAND;
      return 1;
    }
    case S_RD_DMA_ISSUE:
      if (dma_free() == 0) return 0;
      dma_submit(c->zero ? buf_slot(g_cfg.tags + 1u) : slot, SFS_HOSTMEM_BASE + c->hbuf + c->i * LBA_BYTES,
                 LBA_BYTES, tag);
      c->state = S_RD_DMA;
      return 1;
    case S_WR_DMA_ISSUE:
      if (c->i == c->nlb) {
        if (c->fua) { c->ck_target = ckpt_target(); c->state = S_CKPT_WAIT; }
        else finish(tag, SFS_ST_SUCCESS, 0);
        return 1;
      }
      if (dma_free() == 0) return 0;
      dma_submit(SFS_HOSTMEM_BASE + c->hbuf + c->i * LBA_BYTES, slot, LBA_BYTES, tag);
      c->state = S_WR_DMA;
      return 1;
    case S_WR_PROG_ISSUE: {
      if (c->phys) {
        uint16_t p;
        phys_ppa(c, c->i, &p);
        if (nand_free(ppa_ch(p)) == 0) return 0;
        c->ppa = p;
        nand_submit(ppa_ch(p), SFS_NOP_PROGRAM, ppa_row(p), slot, LBA_BYTES, tag);
        c->state = S_WR_PROG;
        return 1;
      }
      int none = 0;
      for (uint32_t k = 0; k < g_cfg.nch; k++) {
        uint32_t ch = (rr_ch + k) % g_cfg.nch;
        if (nand_free(ch) == 0) continue;
        uint16_t p = ftl_alloc(ch);
        if (p == PPA_WAIT) continue;
        if (p == PPA_NONE) { none++; continue; }
        c->ppa = p;
        nand_submit(ch, SFS_NOP_PROGRAM, ppa_row(p), slot, LBA_BYTES, tag);
        rr_ch = ch + 1u;
        c->state = S_WR_PROG;
        return 1;
      }
      if (none == (int)g_cfg.nch) { finish(tag, SFS_ST_CAPACITY, 0); return 1; }
      return 0;
    }
    case S_OUT_ISSUE:
      if (dma_free() == 0) return 0;
      dma_submit(slot, SFS_HOSTMEM_BASE + c->hbuf, LBA_BYTES, tag);
      c->state = S_OUT_DMA;
      return 1;
    case S_CKPT_WAIT:
      if (ckpt_done_count() < c->ck_target) return 0;
      finish(tag, SFS_ST_SUCCESS, 0);
      return 1;
    case S_ER_ISSUE:
      if (nand_free(ppa_ch(c->ppa)) == 0) return 0;
      nand_submit(ppa_ch(c->ppa), SFS_NOP_ERASE, ppa_blk(c->ppa) * PPB, 0, 0, tag);
      c->state = S_ER_WAIT;
      return 1;
    default:
      return 0;
  }
}

/* ---------------------------------------------------------------- completions */
void cmd_dma_done(uint32_t tag, uint32_t st, uint32_t info) {
  ctx_t *c = &ctx[tag];
  (void)info;
  if (tag >= g_cfg.tags || c->state == S_FREE) { g_fw_errors++; return; }
  if (c->abort) { finish(tag, SFS_ST_ABORT_RESET, SFS_ERR_NOT_READY); return; }
  if (st != SFS_DST_OK) {
    finish(tag, SFS_ST_DATA_XFER_ERR, (st == SFS_DST_READ_ERR) ? SFS_ERR_DMA_READ : SFS_ERR_DMA_WRITE);
    return;
  }
  switch (c->state) {
    case S_RD_DMA:  c->i++; if (!c->zero) g_ftl.reads++; c->state = S_RD_NEXT; break;
    case S_WR_DMA:  c->state = S_WR_PROG_ISSUE; break;
    case S_OUT_DMA: c->i = 1; finish(tag, SFS_ST_SUCCESS, 0); break;
    default:        g_fw_errors++; break;
  }
}

void cmd_nand_done(uint32_t tag, uint32_t st, uint32_t sr, uint32_t i0, uint32_t i1) {
  ctx_t *c = &ctx[tag];
  (void)sr; (void)i1;
  if (tag >= g_cfg.tags || c->state == S_FREE) { g_fw_errors++; return; }
  if (c->abort) { finish(tag, SFS_ST_ABORT_RESET, SFS_ERR_NOT_READY); return; }
  switch (c->state) {
    case S_RD_NAND:
      if (st == SFS_NST_OK || st == SFS_NST_CORRECTED) { c->ce_bits += i0 & 0xFFFFu; c->state = S_RD_DMA_ISSUE; }
      else if (st == SFS_NST_UNCORR) finish(tag, SFS_ST_MEDIA_UNREC, SFS_ERR_NAND_ECC_UE);
      else if (st == SFS_NST_TIMEOUT) finish(tag, SFS_ST_MEDIA_TIMEOUT, SFS_ERR_NAND_TIMEOUT);
      else finish(tag, SFS_ST_INTERNAL_ERR, SFS_ERR_NAND_BUS);
      break;
    case S_WR_PROG:
      if (st == SFS_NST_OK) {
        if (!c->phys) ftl_commit(c->lba + c->i, c->ppa);
        c->i++;
        c->state = S_WR_DMA_ISSUE;
      } else if (st == SFS_NST_PROG_FAIL && !c->phys && c->retries < 2u) {
        ftl_program_failed(c->ppa);                         /* data is still in the slot: retry elsewhere */
        c->retries++;
        c->state = S_WR_PROG_ISSUE;
      } else if (st == SFS_NST_WP) finish(tag, SFS_ST_MEDIA_WRITE, SFS_ERR_NAND_WP);
      else if (st == SFS_NST_TIMEOUT) finish(tag, SFS_ST_MEDIA_TIMEOUT, SFS_ERR_NAND_TIMEOUT);
      else finish(tag, SFS_ST_MEDIA_WRITE, SFS_ERR_NAND_FAIL);
      break;
    case S_ER_WAIT:
      if (st == SFS_NST_OK) { c->i = 1; finish(tag, SFS_ST_SUCCESS, 0); }
      else if (st == SFS_NST_WP) finish(tag, SFS_ST_MEDIA_ERASE, SFS_ERR_NAND_WP);
      else finish(tag, SFS_ST_MEDIA_ERASE, SFS_ERR_NAND_FAIL);
      break;
    default:
      g_fw_errors++;
      break;
  }
}

void cmd_abort_all(void) {
  for (uint32_t t = 0; t < g_cfg.tags; t++) if (ctx[t].state != S_FREE) ctx[t].abort = 1;
}

/* ---------------------------------------------------------------- one service pass: returns progress */
int cmd_service(void) {
  int n = fetch();
  uint32_t h;
  while ((h = SDMA(SFS_DMA_CPL_HEAD)) & 0x80000000u) {
    uint32_t info = SDMA(SFS_DMA_CPL_INFO);
    SDMA(SFS_DMA_CPL_POP) = 0u;
    cmd_dma_done((h >> 16) & 0xFFu, (h >> 8) & 0xFFu, info);
    n++;
  }
  for (uint32_t ch = 0; ch < g_cfg.nch; ch++) {
    while ((h = NAND(ch, SFS_NAND_CPL_HEAD)) & 0x80000000u) {
      uint32_t i0 = NAND(ch, SFS_NAND_CPL_INFO0), i1 = NAND(ch, SFS_NAND_CPL_INFO1);
      uint32_t tag = (h >> 16) & 0xFFu, st = (h >> 8) & 0xFFu;
      NAND(ch, SFS_NAND_CPL_POP) = 0u;
      if (tag & 0x80u) ftl_nand_done(tag, st);
      else cmd_nand_done(tag, st, h & 0xFFu, i0, i1);
      n++;
    }
  }
  for (uint32_t t = 0; t < g_cfg.tags; t++) if (ctx[t].state != S_FREE) n += issue(t);
  ftl_service();
  ckpt_service();
  return n;
}
