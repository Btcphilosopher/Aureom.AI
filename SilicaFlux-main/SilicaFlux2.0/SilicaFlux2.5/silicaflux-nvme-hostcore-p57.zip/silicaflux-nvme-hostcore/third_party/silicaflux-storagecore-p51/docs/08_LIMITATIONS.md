# 09 — Limitations and what is not claimed

Everything in this project is RTL simulation and Yosys estimates. Nothing ran on an FPGA board or silicon.

## Not claimed

* **NVMe / PCIe compliance.** The host interface is NVMe-*inspired* (SQ/CQ, doorbells, phase tags, EN/RDY,
  shutdown) with its own command set and rings in controller memory. There is no PCIe logic; the host is a
  testbench driver on an SFB2 port.
* **ONFI compliance.** The NAND sequencer implements the asynchronous SDR command/address/data cycles of the
  common command set (FFh, 90h, 70h, 00h/30h, 80h/10h, 60h/D0h) with programmable cycle-count timing. No NV-DDR /
  NV-DDR2/3 / Toggle modes, no DQS capture, no ONFI parameter page, no multi-plane / cache / multi-LUN commands, no
  calibration. Verified only against the behavioural model in `tb/models/`, not against a vendor model or device.
* **NAND-grade error correction.** Page ECC is per-word SECDED (P26 encoder/decoder): 1 bit corrected and 2 bits
  detected per 32/64-bit word. Real NAND needs BCH or LDPC over 512 B–1 KiB codewords with tens of bits of
  correction; the interleaved-ECC-beat layout is the integration point for such a code.
* **A production FTL.** No garbage collection (capacity is limited to 256 LBAs per channel against ~1000 data
  pages per channel, so the tests never run out), no wear levelling, no read-disturb / retention handling, no
  A/B metadata (an interrupted metadata-block erase loses the previous checkpoint), L2P in on-chip DMEM.
* **Performance.** The storage fabric is the DataFabric `sfb_crossbar` (one outstanding transaction per port,
  SFB2 R6): roughly one DMA word per four cycles. Multi-channel configurations are therefore fabric-bound. A burst /
  multi-outstanding fabric (DataFabric PROTOCOL.md §8 roadmap) is the obvious next step.
* **Timing closure / ASIC implementation.** Yosys generic and ECP5 estimates only. The OpenROAD configuration in
  `synth/openroad/` was not run (no OpenROAD / PDK in this environment). The generic buffer SRAM is not an SRAM
  macro.
* **Security.** Firmware images are CRC32-checked by the ControlCore boot ROM; there is **no authentication**,
  no encryption at rest, no key management. The host management lock and the ControlCore host write lock are
  access-control conveniences, not a security boundary against a malicious host with physical access.
* **Power.** One ungated clock; no power gating; PLP hold-up energy is not modelled.

## Simplifications that matter for future modules

* Logical block size = NAND page user size (512 B). Larger pages need sector packing in the FTL.
* Host addresses are 32-bit inside a 256 MiB host window (ABI field is 64-bit).
* `ADDRESS_WIDTH` limits the accepted storage address; the FTL itself uses 16-bit L2P entries.
* `CMD_QUEUE_DEPTH` ≤ 64 (SQ/CQ entries ≤ 64), one SQ/CQ pair.
* NAND device geometry comes from a firmware table keyed by the READ_ID bytes (one entry: the model).
* The SQ/CQ rings and the tag table are flip-flops; for deep queues they should become SRAM.

## Tool notes

* Yosys 0.33 has no SystemVerilog `import`; `scripts/synth.py` hoists the two package bodies to compilation-unit
  scope in a generated copy (sources unchanged). Icarus 12 lacks unpacked-array task ports and task `return`; the
  testbenches avoid both so every unit test runs on Icarus and Verilator.
* Verilator inlines timed tasks; the SoC testbench funnels all BAR traffic through one BFM process to keep the
  generated C++ compilable in reasonable time.
