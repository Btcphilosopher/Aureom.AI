# 02 — Storage transaction protocol (v1.0) and interfaces

Source: `rtl/silicaflux_storage_pkg.sv` (structs, packing) + `config/sfs_memmap.yaml` → generated
`rtl/generated/sfs_proto_enums.svh` (SV enums) and `sw/include/generated/sfs_map.h` (C). One source, three views;
`make check-map` fails if any generated view is stale, and `sfs_sys_regs` refuses to elaborate if the package
version and the YAML version differ.

## 1. Versioning

`SFS_PROTO_VERSION = 0x0001_0000` (major 1, minor 0), readable at `SFS_SYS.PROTO_VERSION` (firmware) and
`SHC.VERSION` (host). **Major** changes when a field moves or changes meaning; **minor** when a field is added in
reserved space or an enum value is added. The firmware refuses to run on a different major (`hal_init`).

## 2. Command transaction `sfs_cmd_t` (259 bits)

| Field | Bits | Meaning |
|---|---|---|
| `opcode` | 8 | `sfs_opcode_e`: FLUSH 00h, WRITE 01h, READ 02h, DEALLOCATE 09h, IDENTIFY 80h, GET_LOG 81h, ERASE 90h |
| `addr_type` | 1 | `sfs_addr_type_e`: LOGICAL (LBA, FTL translated) / PHYSICAL (`{ch[31:24], block[23:8], page[7:0]}`) |
| `dir` | 2 | `sfs_dir_e`: NONE / TO_HOST / FROM_HOST — derived from the opcode by `sfs_op_dir()` |
| `flags` | 8 | raw SQ W0[15:8]: [0] PHYSICAL, [1] FUA, [7:2] reserved (must be 0) |
| `tid` | 16 | transaction ID (the host's command identifier); every completion carries it back |
| `addr` | 64 | logical or physical address; `ADDRESS_WIDTH` bits implemented |
| `len` | 32 | transfer length in logical blocks, 1-based (0 is invalid for data commands) |
| `host_addr` | 64 | host buffer (32 bits implemented: host window 256 MiB) |
| `aux` | 32 | opcode specific (IDENTIFY: CNS) |
| `rsvd` | 32 | must be 0 |

## 3. Completion transaction `sfs_cpl_t` (95 bits)

| Field | Bits | Meaning |
|---|---|---|
| `tid` | 16 | transaction ID of the command (taken from the tag table, never from firmware) |
| `status` | 7 | `sfs_status_e` (generic outcome) |
| `err` | 8 | `sfs_err_e` (detail / source) |
| `result0` | 32 | completion metadata: blocks transferred |
| `result1` | 32 | completion metadata: ECC bits corrected while serving the command |

Status values: SUCCESS 00, INVALID_OPCODE 01, INVALID_FIELD 02, CID_CONFLICT 03, DATA_XFER_ERR 04,
ABORT_PWR_LOSS 05, INTERNAL_ERR 06, ABORT_RESET 07, LBA_RANGE 08, CAPACITY 09, ACCESS_DENIED 0A, MEDIA_UNREC 10,
MEDIA_WRITE 11, MEDIA_ERASE 12, MEDIA_TIMEOUT 13. Error codes: see docs/MEMORY_MAP.md §4.

## 4. Handshake rules (every storage ready/valid channel)

Same rules as SFB2 (DataFabric PROTOCOL.md R1–R3), applied to `cmd` and `cpl`:

1. Transfer on the rising edge where `valid && ready`.
2. Once `valid` is asserted the payload is held unchanged until accepted; no withdrawal. (`sfs_host_if` copies the SQ
   entry into an output register so later host writes to the slot cannot change an offered command;
   `sfs_cmd_ctrl` locks its round-robin completion choice while a completion is stalled.)
3. `valid` never depends combinationally on `ready`; `ready` may depend on `valid` and the payload
   (`sfs_cmd_ctrl.cmd_ready` depends on the validation result).

All fabric ports (storage fabric, host memory, host BAR) are SFB2; the register pages use the SilicaFlux-V register
bus (one-cycle strobe, same-cycle read data) through the ControlCore's forwarded accelerator port.

## 5. Host queue ABI (BAR, controller memory)

SQ entry (32 bytes): W0 `[7:0] opcode [8] PHYSICAL [9] FUA [15:10] 0 [31:16] TID`, W1 aux, W2/W3 ADDR, W4 LEN,
W5/W6 host buffer, W7 0. CQ entry (16 bytes): W0 result0, W1 result1, W2 `[15:0] SQ head`,
W3 `[15:0] TID [16] phase [23:17] status [31:24] error`.

* SQ: host writes entries at `0x8000_1000 + 32·slot`, then `SQ_TAIL`. A tail ≥ SQ entries, or a doorbell while the
  controller is not ready, is ignored and raises DB_ERR (sticky host event, HIF event, RAS HIF_DB).
* CQ: entries at `0x8000_2000 + 16·slot`; a new entry has `phase` equal to the host's expected phase (starts at 1,
  flips at every wrap). Host writes `CQ_HEAD`; a head that would pass the tail is ignored + DB_ERR. Phase tags are
  cleared on controller reset so no stale entry looks new.
* Interrupt: `host_irq_o = INT_CTRL[0] & (CQ tail ≠ head) | INT_CTRL[1] & EVT` (EVT: ready change, fatal, power
  loss, doorbell error; write-1-to-clear).
* Flow control: SQ entries = CQ entries = 2·CMD_QUEUE_DEPTH (≤ 64). The host never has more than entries−1
  outstanding; inside the controller, tags (`cmd_ready`) and CQ space (`cpl_ready`) back-pressure.

## 6. Hardware validation (command controller), in priority order

| Check | Status / error |
|---|---|
| opcode not supported | INVALID_OPCODE |
| reserved flag bits or W7 ≠ 0 | INVALID_FIELD / RSVD_FIELD |
| power-loss quiescence active | ABORT_PWR_LOSS / QUIESCED |
| controller reset in progress | ABORT_RESET / NOT_READY |
| PHYSICAL on FLUSH/DEALLOCATE/IDENTIFY/GET_LOG, or LOGICAL ERASE | INVALID_FIELD / ADDR_TYPE |
| PHYSICAL while `SEC_CTRL.PHYS_EN = 0` | ACCESS_DENIED / ADDR_TYPE |
| ADDR has bits above `ADDRESS_WIDTH` | INVALID_FIELD / ADDR_WIDTH |
| LEN = 0 (READ/WRITE/DEALLOCATE/ERASE) | INVALID_FIELD / LEN_ZERO |
| LEN > MDTS (READ/WRITE/ERASE) | INVALID_FIELD / LEN_MAX |
| host buffer misaligned (DMA word), above 32 bits, or beyond the 256 MiB host window | INVALID_FIELD / HOST_ADDR |
| logical ADDR + LEN > capacity | LBA_RANGE |
| TID equal to a command still owned by the controller | CID_CONFLICT |

Firmware-detected conditions (bad physical address, no space, media errors) use the remaining codes.

## 7. Internal interfaces (firmware ↔ hardware)

| Interface | Producer → consumer | Tag | Completion record |
|---|---|---|---|
| FWQ | command controller → firmware | command tag | — (`FWQ_HEAD` / `FWQ_POP`, command in the tag window) |
| CPL_POST | firmware → command controller | command tag | {status, error, result0, result1} |
| DMA descriptor | firmware → `sfs_dma` | any (firmware uses the command tag) | {tag, DST_*, bytes or fault address} |
| NAND operation | firmware → `sfs_nand_ctrl` | any (command tag; 0x80+ internal) | {tag, NST_*, NAND status byte, info0/1} |

Every queue has a free-slot register; a submit into a full queue is dropped and flagged (`SUBMIT_OVF` / `OP_OVF`,
RAS FW_PROTO), never silently overwritten.
