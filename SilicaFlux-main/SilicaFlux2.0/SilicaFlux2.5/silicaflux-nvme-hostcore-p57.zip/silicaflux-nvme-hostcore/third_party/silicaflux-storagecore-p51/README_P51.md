# SilicaFlux-STORE · Project 51 — StorageCore: storage-processor system-on-chip

**Primary RTL:** [`rtl/silicaflux_storage_soc.sv`](rtl/silicaflux_storage_soc.sv) · Aureom.AI | SilicaFlux-STORE

StorageCore is a synthesizable storage-controller SoC: a host queue interface, a command controller, a storage
DataFabric, an ECC-protected SRAM buffer, a storage DMA and ONFI-style NAND channel controllers, orchestrated by the
**verified SilicaFlux ControlCore** (RV32IM CPU, Project 21, reused unmodified) running real C firmware with a
minimal FTL — connected to a simulated host and behavioural NAND devices.

```
host ─BAR─► host interface (SQ/CQ) ─► command controller ─► firmware (ControlCore RV32IM)
                                                               │ NAND ops / DMA descriptors (tagged)
host memory ◄─► storage DMA ◄─► storage DataFabric ◄─► SRAM buffer (SECDED) ◄─► NAND controller ─► NAND flash
```

> **Status.** RTL simulation (Verilator 5.020, Icarus 12) and Yosys 0.33 estimates only. Nothing ran on an FPGA
> board or silicon. Not NVMe-, PCIe- or ONFI-compliant; no NAND-grade ECC, no garbage collection, no firmware
> authentication. See [docs/08_LIMITATIONS.md](docs/08_LIMITATIONS.md). Delivered as an archive; nothing was
> committed.

## Definition of done — met in RTL simulation

*The minimal storage SoC accepts a real command, accesses a modelled storage device and returns correctly tagged
results in RTL simulation.*

`tb/soc/tb_storage_soc.sv`, configuration `min1ch`: the host loads `firmware/build/sfs_fw.hex` through the BAR, the
unmodified ControlCore boot ROM checks and starts it, the firmware brings up the NAND channel (RESET, READ_ID) and the
FTL, the host enables the controller and submits IDENTIFY, a 4-block WRITE and a 4-block READ through the SQ ring.
The commands travel host interface → command controller → firmware → storage DMA / NAND controller → flash model and
back; each CQ entry carries the command's transaction ID, status and metadata, and the data read back equals the
data written. The run prints `TB DoD: command accepted, NAND model accessed, tagged results returned -- MET`.

## Results

All numbers from `reports/` (final runs on the frozen sources).

| Check | Result | Report |
|---|---|---|
| **DoD** — full SoC, real firmware on the unmodified ControlCore RV32IM CPU, NAND model, tagged completions | **MET** in `min1ch`, `research4ch` and `noecc1ch` | `reports/sim/soc_*_full.log` |
| Full-SoC scenario suite (boot, DoD, concurrency, invalid commands, unmapped/deallocated reads, NAND ECC correct/uncorrectable, back-pressure + full CQ, controller reset in flight, power loss, security locks, FLUSH/FUA/checkpoints, physical commands, GET_LOG, shutdown) | **4 / 4 runs PASS**: min1ch 152/152 checks (2 host-memory seeds), research4ch 195/195, noecc1ch 142/142; ≈ 2 M cycles each; firmware self-verdict PASS via `TEST_CTRL`; 0 NAND protocol / timing violations | [regression](reports/regression.md) |
| Concurrency | 8 (min1ch) / 16 (research4ch) commands in flight; 7 / 14 completed out of submission order; every TID completed exactly once | `reports/sim/soc_*_full.log` |
| Subsystem testbench (13 groups: registers, NAND, ECC, DMA, host queues, invalid commands, back-pressure, controller reset, power loss, buffer ECC, fabric errors, interrupts, end-to-end) | **6 / 6 runs PASS** on Icarus 12 **and** Verilator 5: 345 (min1ch), 554 (research4ch), 315 (noecc1ch) checks each | [regression](reports/regression.md) |
| Lint: Verilator `-Wall`, 2 tops × 3 configurations | **0 warnings in new RTL**; Icarus elaborates all 6; illegal parameter sets rejected by both | [lint](reports/lint.md) |
| Address map: generated SV/C/Markdown up to date; illegal maps / configurations rejected | **5/5 current, 20/20 selftest** | `scripts/gen_map.py` |
| Synthesis (Yosys 0.33, estimates) | `check -assert` clean (no latches / loops / multiple drivers) for 2 tops × 3 configs; storage subsystem min1ch ≈ 24 k generic cells + 3.0 k FF (6.6 k ECP5 LUT4); full SoC incl. CPU ≈ 18 k LUT4, 6.9 k FF, 58 DP16KD; no P&R | [synth](reports/synth.md) |
| Firmware | 14 068 B code, 7 808 B bss (image 14 324 B = 21 % of IMEM); `-Wall -Wextra -Werror` clean; boot to HOST_READY ≈ 0.64 M cycles | `firmware/build/` |
| Vendored sources byte-identical to the repository archives | **69 / 69** | `scripts/check_vendor.py`, `third_party/SHA256SUMS` |
| Host-side reference driver compiles against the same generated header | `gcc -std=c11 -Wall -Wextra -Werror -pedantic` clean | `sw/host/` |

## Requirement → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit; reuse verified modules; implemented / missing / unverified dependencies | [docs/00_AUDIT.md](docs/00_AUDIT.md), [third_party/PROVENANCE.md](third_party/PROVENANCE.md), `scripts/check_vendor.py` |
| 2 | Host Interface → Command Controller → Storage DataFabric → SRAM Buffers → NAND Controller → Flash Model, ControlCore orchestration, single channel first | `rtl/sfs_host_if.sv`, `sfs_cmd_ctrl.sv`, `sfs_storage_subsys.sv` (crossbar), buffer SRAM, `sfs_nand_ctrl.sv`, `tb/models/sfs_nand_flash_model.sv`; [docs/01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md) |
| 3 | `NUM_NAND_CHANNELS`, `CHANNEL_DATA_WIDTH`, `BUFFER_SIZE_BYTES`, `DMA_DATA_WIDTH`, `ADDRESS_WIDTH`, `CMD_QUEUE_DEPTH`, `ENABLE_ECC`, `ENABLE_RAS`; minimal + multi-channel research configs | top-level parameters; `config/configs/min1ch.yaml`, `research4ch.yaml`, `noecc1ch.yaml` → `rtl/generated/sfs_configs.svh` |
| 4 | Versioned transaction package: opcode, logical/physical address type, address, length, TID, direction, status, error code, completion metadata; ready/valid | `rtl/silicaflux_storage_pkg.sv` + generated enums; [docs/02_PROTOCOL.md](docs/02_PROTOCOL.md) |
| 5 | Registers: identification, NAND status, DMA, SRAM, interrupts, ECC, power-loss, RAS, security, performance; C headers | `config/sfs_memmap.yaml` → `rtl/generated/sfs_map_pkg.sv`, `sw/include/generated/sfs_map.h`, [docs/MEMORY_MAP.md](docs/MEMORY_MAP.md) |
| 6 | Reuse the ControlCore; firmware-visible command submission, device initialisation, completion handling | `third_party/silicaflux-controlcore` (unmodified), `firmware/`; [docs/03_CONTROLCORE_INTEGRATION.md](docs/03_CONTROLCORE_INTEGRATION.md) |
| 7 | One clock domain; reset sequencing, peripheral readiness, error propagation, safe quiescence; CDC only where asynchronous | [docs/04_CLOCK_RESET.md](docs/04_CLOCK_RESET.md); `sfv_sync` on NAND R/B# and power-fail only |
| 8 | Tests: register access, command submission, memory reads/writes, DMA, controller reset, interrupts, back-pressure, invalid addresses, concurrent commands, status reporting | `tb/unit/tb_sfs_subsys.sv`, `tb/soc/tb_storage_soc.sv`; [docs/06_VERIFICATION.md](docs/06_VERIFICATION.md) |
| 9 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_storage_soc.sv` | `rtl/silicaflux_storage_soc.sv` (+ `rtl/sfs_*.sv`) |
| `silicaflux_storage_pkg.sv` | `rtl/silicaflux_storage_pkg.sv` (+ generated `rtl/generated/sfs_proto_enums.svh`) |
| Configuration files | `config/sfs_memmap.yaml`, `config/configs/*.yaml`, generated `rtl/generated/sfs_configs.svh` |
| Address map | [docs/MEMORY_MAP.md](docs/MEMORY_MAP.md), `rtl/generated/sfs_map_pkg.sv`, `sw/include/generated/sfs_map.h` (`scripts/gen_map.py`, `--check`, `--selftest`) |
| ControlCore integration | `rtl/silicaflux_storage_soc.sv`, `firmware/` (C, RV32IM), [docs/03](docs/03_CONTROLCORE_INTEGRATION.md) |
| Testbenches | `tb/unit/tb_sfs_subsys.sv`, `tb/soc/tb_storage_soc.sv`, models `tb/models/sfs_nand_flash_model.sv`, `tb/models/sfs_tb_hostmem.sv` |
| Lint and synthesis scripts | `scripts/lint.py`, `scripts/synth.py`, `synth/openroad/` (prepared, not run), `scripts/regress.py`, `Makefile` |
| System architecture documentation | `docs/00`–`08` |

## Quick start

Tools (Ubuntu 24.04 packages): Verilator 5.020, Icarus Verilog 12, Yosys 0.33, `gcc-riscv64-unknown-elf` 13.2,
Python 3 with PyYAML.

```bash
sudo apt-get install -y verilator iverilog yosys gcc-riscv64-unknown-elf python3-yaml
```

```bash
make check-map fw
```

```bash
make unit CFG=min1ch
```

```bash
make soc CFG=min1ch SCENARIO=full
```

```bash
make regress
```

```bash
make lint synth
```

* `make unit` — subsystem testbench on Icarus (seconds); `make unit-vl` on Verilator.
* `make soc` — builds the Verilator model of the full SoC (C++ compile ≈ 10–15 min), then runs the real firmware
  (≈ 2 M cycles, a few seconds).
* `make regress` — every configuration on both simulators; writes `reports/regression.md`.
* `make vendor-check REPO=<path to the Aureom.AI checkout>` — vendored files byte-identical to the repository archives.

## Layout

```
config/       sfs_memmap.yaml (single source of truth) + configs/ (min1ch, research4ch, noecc1ch)
rtl/          new storage RTL; generated/ (map package, enums, configuration sets); files.f
firmware/     storage firmware (C): platform, HAL, FTL, command state machines, main; Makefile
sw/include/   generated C header shared by firmware and host drivers
tb/           unit/ (subsystem), soc/ (full SoC + firmware), models/ (NAND flash, host memory)
scripts/      gen_map.py, lint.py, synth.py, regress.py, check_vendor.py
synth/        yosys/ (generated scripts and logs), openroad/ (ORFS configuration, not executed)
third_party/  unmodified SilicaFlux sources: ControlCore (+ MCU-I, SilicaFlux-V, DataFabric, SRAMLIB), RAS P26
docs/         00 audit … 08 limitations, MEMORY_MAP (generated)
reports/      lint, synthesis, regression, simulation logs
```
