// =============================================================================
// SilicaFlux-STORE :: silicaflux_storage_soc -- StorageCore storage-processor SoC (Project 51)
//
//            host (simulated host / future PCIe endpoint BAR)
//              │ hb_* SFB2 slave (BAR)          ▲ hm_* SFB2 master (host memory, DW)   ▲ host_irq_o
//      ┌───────▼───────────┐                    │                                      │
//      │ BAR split          │ 0x0000_0000.. MGMT ─► cc_sfb_gate (storage pages locked) ─► ControlCore host port
//      │ (sfb_crossbar 1x2) │ 0x8000_0000 SHC  ──► sfs_host_if (SQ/CQ rings, doorbells)
//      └────────────────────┘
//      ControlCore (Project 21, UNMODIFIED): RV32IM_Zicsr CPU, boot ROM, IMEM/DMEM, SFB2 crossbar,
//        INTC, MTIMER, WDT, system DMA, mailbox, perf, PMU, RAS, security
//        acc_rb (pages 10..14) ──► storage registers      EXT (0x2000_0000..) ──► storage fabric
//        IRQ 4 (TENSOR slot) <- storage IO interrupt      IRQ 5 (VECTOR slot) <- storage EVENT interrupt
//        RAS SOC warning/fatal <- storage RAS             acc_rst_no -> storage subsystem reset
//      sfs_storage_subsys: host interface -> command controller -> storage DataFabric
//        -> SRAM buffer (ECC) <- storage DMA <-> host memory;  NAND controller(s) -> NAND pins
//
// One functional clock (clk).  Asynchronous inputs, each with a 2-flop
// synchroniser: rst_ni (reset synchroniser inside the ControlCore),
// host_rst_req_i, boot_mode_i (ControlCore), pwr_fail_ni (storage), nand_rb_n
// (per channel).  Reset sequencing: docs/04_CLOCK_RESET.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module silicaflux_storage_soc
  import sfs_map_pkg::*;
#(
  parameter int NUM_NAND_CHANNELS  = 1,
  parameter int CHANNEL_DATA_WIDTH = 8,
  parameter int BUFFER_SIZE_BYTES  = 16384,
  parameter int DMA_DATA_WIDTH     = 32,
  parameter int ADDRESS_WIDTH      = 32,
  parameter int CMD_QUEUE_DEPTH    = 8,
  parameter int ENABLE_ECC         = 1,
  parameter int ENABLE_RAS         = 1,
  parameter int NAND_PAGE_BYTES    = 512,
  parameter int SRAM_BACKEND       = `SRAM_BACKEND_GENERIC,
  localparam int NCH = NUM_NAND_CHANNELS,
  localparam int CDW = CHANNEL_DATA_WIDTH,
  localparam int DW  = DMA_DATA_WIDTH,
  localparam int SB  = DW / 8
) (
  input  wire logic               clk,
  input  wire logic               rst_ni,
  input  wire logic               test_mode,
  input  wire logic [1:0]         boot_mode_i,
  input  wire logic               host_rst_req_i,
  input  wire logic               pwr_fail_ni,
  // ---------------------------------------------------------------- host BAR (SFB2 slave, 32-bit)
  input  wire logic               hb_req_valid,
  output logic                    hb_req_ready,
  input  wire logic               hb_req_write,
  input  wire logic [31:0]        hb_req_addr,
  input  wire logic [31:0]        hb_req_wdata,
  input  wire logic [3:0]         hb_req_wstrb,
  output logic                    hb_rsp_valid,
  input  wire logic               hb_rsp_ready,
  output logic [31:0]             hb_rsp_rdata,
  output logic                    hb_rsp_error,
  // ---------------------------------------------------------------- host memory (SFB2 master, DW)
  output logic                    hm_req_valid,
  input  wire logic               hm_req_ready,
  output logic                    hm_req_write,
  output logic [31:0]             hm_req_addr,
  output logic [DW-1:0]           hm_req_wdata,
  output logic [SB-1:0]           hm_req_wstrb,
  input  wire logic               hm_rsp_valid,
  output logic                    hm_rsp_ready,
  input  wire logic [DW-1:0]      hm_rsp_rdata,
  input  wire logic               hm_rsp_error,
  // ---------------------------------------------------------------- host status
  output logic                    host_irq_o,       // storage queue / event interrupt
  output logic                    mgmt_irq_o,       // ControlCore mailbox F2H doorbell
  output logic                    host_ready_o,
  output logic                    cmdproc_ready_o,
  output logic                    ras_fatal_o,
  // ---------------------------------------------------------------- NAND channels (pads outside)
  output logic [NCH-1:0]          nand_ce_n,
  output logic [NCH-1:0]          nand_cle,
  output logic [NCH-1:0]          nand_ale,
  output logic [NCH-1:0]          nand_we_n,
  output logic [NCH-1:0]          nand_re_n,
  output logic [NCH-1:0]          nand_wp_n,
  output logic [NCH*CDW-1:0]      nand_dq_o,
  output logic [NCH-1:0]          nand_dq_oe,
  input  wire logic [NCH*CDW-1:0] nand_dq_i,
  input  wire logic [NCH-1:0]     nand_rb_n,
  // ---------------------------------------------------------------- diagnostics
  output logic                    diag_valid_o,
  output logic [7:0]              diag_char_o,
  output logic                    test_done_o,
  output logic                    test_fail_o,
  output logic [15:0]             test_code_o,
  output logic                    cpu_sleep_o
);
  // ================================================================ host BAR split (DataFabric crossbar, 1 x 2)
  // The BAR fabric runs on a reset that only POR asserts, so the host can always reach the
  // ControlCore host port (which stalls until the ControlCore is out of reset).
  logic sys_rst_n;
  sfv_rst_sync u_rs_bar (.clk, .rst_ni(rst_ni), .test_mode, .test_rst_ni(rst_ni), .rst_no(sys_rst_n));
  localparam logic [63:0] BAR_BASE = {SFS_BAR_SHC_BASE, SFS_BAR_MGMT_BASE};
  localparam logic [63:0] BAR_MASK = {~(SFS_BAR_SHC_SIZE - 32'd1), ~(SFS_BAR_MGMT_SIZE - 32'd1)};
  logic [1:0]  b_req_valid, b_req_ready, b_req_write, b_rsp_valid, b_rsp_ready, b_rsp_error;
  logic [63:0] b_req_addr, b_req_wdata, b_rsp_rdata;
  logic [7:0]  b_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        bar_err_evt, bar_err_w, bar_err_m;
  logic [31:0] bar_err_addr;
  logic        bev_a, bev_s, bev_l, bev_r;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_crossbar #(
    .NM(1), .NS(2), .AW(32), .DW(32), .ARB_MODE(0), .CHECK_ALIGN(1),
    .SLV_BASE(BAR_BASE), .SLV_MASK(BAR_MASK), .MST_SLV_EN(2'b11)
  ) u_bar (
    .clk, .rst_n(sys_rst_n),
    .m_req_valid(hb_req_valid), .m_req_ready(hb_req_ready), .m_req_write(hb_req_write), .m_req_addr(hb_req_addr),
    .m_req_wdata(hb_req_wdata), .m_req_wstrb(hb_req_wstrb), .m_rsp_valid(hb_rsp_valid), .m_rsp_ready(hb_rsp_ready),
    .m_rsp_rdata(hb_rsp_rdata), .m_rsp_error(hb_rsp_error),
    .s_req_valid(b_req_valid), .s_req_ready(b_req_ready), .s_req_write(b_req_write), .s_req_addr(b_req_addr),
    .s_req_wdata(b_req_wdata), .s_req_wstrb(b_req_wstrb), .s_rsp_valid(b_rsp_valid), .s_rsp_ready(b_rsp_ready),
    .s_rsp_rdata(b_rsp_rdata), .s_rsp_error(b_rsp_error),
    .err_evt(bar_err_evt), .err_addr(bar_err_addr), .err_master(bar_err_m), .err_write(bar_err_w),
    .ev_req_accept(bev_a), .ev_req_stall(bev_s), .ev_arb_loss(bev_l), .ev_rsp_stall(bev_r)
  );

  // ---------------------------------------------------------------- MGMT -> management gate -> ControlCore host port
  logic        mgmt_lock, sec_viol;
  logic        hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error;
  logic [31:0] hs_req_addr, hs_req_wdata, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        mg_idle;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [31:0] mg_addr = b_req_addr[31:0];
  wire mg_storage_page = (mg_addr >= SFS_SYS_BASE) && (mg_addr < SFS_SYS_BASE + 32'h6000);   // pages 10..15
  cc_sfb_gate u_mgmt_gate (
    .clk, .rst_n(sys_rst_n),
    .s_req_valid(b_req_valid[0]), .s_req_ready(b_req_ready[0]), .s_req_write(b_req_write[0]),
    .s_req_addr(mg_addr), .s_req_wdata(b_req_wdata[31:0]), .s_req_wstrb(b_req_wstrb[3:0]),
    .s_rsp_valid(b_rsp_valid[0]), .s_rsp_ready(b_rsp_ready[0]), .s_rsp_rdata(b_rsp_rdata[31:0]),
    .s_rsp_error(b_rsp_error[0]),
    .m_req_valid(hs_req_valid), .m_req_ready(hs_req_ready), .m_req_write(hs_req_write), .m_req_addr(hs_req_addr),
    .m_req_wdata(hs_req_wdata), .m_req_wstrb(hs_req_wstrb), .m_rsp_valid(hs_rsp_valid), .m_rsp_ready(hs_rsp_ready),
    .m_rsp_rdata(hs_rsp_rdata), .m_rsp_error(hs_rsp_error),
    .refuse(mgmt_lock && mg_storage_page), .refused_evt(sec_viol), .idle(mg_idle)
  );

  // ================================================================ ControlCore (unmodified)
  logic        acc_rb_sel, acc_rb_we, acc_rb_err;
  logic [15:0] acc_rb_addr;
  logic [31:0] acc_rb_wdata, acc_rb_rdata;
  logic        ext_req_valid, ext_req_ready, ext_req_write, ext_rsp_valid, ext_rsp_ready, ext_rsp_error;
  logic [31:0] ext_req_addr, ext_req_wdata, ext_rsp_rdata;
  logic [3:0]  ext_req_wstrb;
  logic        stor_rst_n, irq_io, irq_evt, busy_nand, busy_io, ext_warn, ext_fatal;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        acc_clk_unused;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_control_core #(.RV32M(1), .SRAM_PARITY(1), .SRAM_BACKEND(SRAM_BACKEND),
                            .MIMPID(32'h0051_0001)) u_cc (
    .clk, .rst_ni, .test_mode, .boot_mode_i, .host_rst_req_i,
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(mgmt_irq_o), .host_ready_o, .cmdproc_ready_o, .ras_fatal_o,
    .acc_rb_sel, .acc_rb_we, .acc_rb_addr, .acc_rb_wdata, .acc_rb_rdata, .acc_rb_err,
    .ext_req_valid, .ext_req_ready, .ext_req_write, .ext_req_addr, .ext_req_wdata, .ext_req_wstrb,
    .ext_rsp_valid, .ext_rsp_ready, .ext_rsp_rdata, .ext_rsp_error,
    .acc_clk_o(acc_clk_unused), .acc_rst_no(stor_rst_n),
    .acc_vec_irq_i(irq_evt), .acc_tsu_irq_i(irq_io),
    .acc_vec_busy_i(busy_nand), .acc_tsu_busy_i(busy_io), .acc_tsu_halted_i(1'b0),
    .ext_warn_i(ext_warn), .ext_fatal_i(ext_fatal),
    .diag_valid_o, .diag_char_o, .test_done_o, .test_fail_o, .test_code_o, .cpu_sleep_o
  );

  // ================================================================ storage subsystem
  sfs_storage_subsys #(
    .NUM_NAND_CHANNELS(NUM_NAND_CHANNELS), .CHANNEL_DATA_WIDTH(CHANNEL_DATA_WIDTH),
    .BUFFER_SIZE_BYTES(BUFFER_SIZE_BYTES), .DMA_DATA_WIDTH(DMA_DATA_WIDTH), .ADDRESS_WIDTH(ADDRESS_WIDTH),
    .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .ENABLE_ECC(ENABLE_ECC), .ENABLE_RAS(ENABLE_RAS),
    .NAND_PAGE_BYTES(NAND_PAGE_BYTES), .SRAM_BACKEND(SRAM_BACKEND)
  ) u_stor (
    .clk, .rst_n(stor_rst_n),
    .x_req_valid(ext_req_valid), .x_req_ready(ext_req_ready), .x_req_write(ext_req_write), .x_req_addr(ext_req_addr),
    .x_req_wdata(ext_req_wdata), .x_req_wstrb(ext_req_wstrb), .x_rsp_valid(ext_rsp_valid),
    .x_rsp_ready(ext_rsp_ready), .x_rsp_rdata(ext_rsp_rdata), .x_rsp_error(ext_rsp_error),
    .rb_sel(acc_rb_sel), .rb_we(acc_rb_we), .rb_addr(acc_rb_addr), .rb_wdata(acc_rb_wdata),
    .rb_rdata(acc_rb_rdata), .rb_err(acc_rb_err),
    .s_req_valid(b_req_valid[1]), .s_req_ready(b_req_ready[1]), .s_req_write(b_req_write[1]),
    .s_req_addr(b_req_addr[63:32] - SFS_BAR_SHC_BASE), .s_req_wdata(b_req_wdata[63:32]), .s_req_wstrb(b_req_wstrb[7:4]),
    .s_rsp_valid(b_rsp_valid[1]), .s_rsp_ready(b_rsp_ready[1]), .s_rsp_rdata(b_rsp_rdata[63:32]),
    .s_rsp_error(b_rsp_error[1]), .host_irq(host_irq_o),
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .nand_ce_n, .nand_cle, .nand_ale, .nand_we_n, .nand_re_n, .nand_wp_n, .nand_dq_o, .nand_dq_oe, .nand_dq_i,
    .nand_rb_n,
    .pwr_fail_ni, .ev_sec_viol(sec_viol), .mgmt_lock,
    .irq_io, .irq_evt, .busy_nand, .busy_io, .ext_warn, .ext_fatal
  );
endmodule

`default_nettype wire
