// =============================================================================
// SilicaFlux StorageCore :: sfs_sfb_gate -- width-generic SFB2 pass-through that can refuse
//   Same behaviour as the ControlCore's cc_sfb_gate (Project 21, 32-bit only):
//   a refused request is accepted locally and answered one cycle later with
//   rsp_error = 1, rdata = 0; a request already presented downstream is never
//   withdrawn.  Used on the host-memory port: bus mastering only while the
//   host has the controller enabled.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfs_sfb_gate #(
  parameter int DW = 32,
  localparam int SB = DW / 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          s_req_valid,
  output logic               s_req_ready,
  input  wire logic          s_req_write,
  input  wire logic [31:0]   s_req_addr,
  input  wire logic [DW-1:0] s_req_wdata,
  input  wire logic [SB-1:0] s_req_wstrb,
  output logic               s_rsp_valid,
  input  wire logic          s_rsp_ready,
  output logic [DW-1:0]      s_rsp_rdata,
  output logic               s_rsp_error,
  output logic               m_req_valid,
  input  wire logic          m_req_ready,
  output logic               m_req_write,
  output logic [31:0]        m_req_addr,
  output logic [DW-1:0]      m_req_wdata,
  output logic [SB-1:0]      m_req_wstrb,
  input  wire logic          m_rsp_valid,
  output logic               m_rsp_ready,
  input  wire logic [DW-1:0] m_rsp_rdata,
  input  wire logic          m_rsp_error,
  input  wire logic          refuse,
  output logic               refused_evt
);
  logic out_q, loc_q, pend_q;
  wire  free       = !out_q && !loc_q;
  wire  refuse_eff = refuse && !pend_q;
  assign m_req_valid = s_req_valid && free && !refuse_eff;
  assign m_req_write = s_req_write;
  assign m_req_addr  = s_req_addr;
  assign m_req_wdata = s_req_wdata;
  assign m_req_wstrb = s_req_wstrb;
  assign s_req_ready = free && (refuse_eff ? 1'b1 : m_req_ready);
  wire fwd_acc  = m_req_valid && m_req_ready;
  wire loc_acc  = s_req_valid && free && refuse_eff;
  wire m_rsp_hs = m_rsp_valid && m_rsp_ready;
  assign s_rsp_valid = loc_q || m_rsp_valid;
  assign s_rsp_rdata = loc_q ? '0 : m_rsp_rdata;
  assign s_rsp_error = loc_q ? 1'b1 : m_rsp_error;
  assign m_rsp_ready = !loc_q && s_rsp_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_q <= 1'b0; loc_q <= 1'b0; pend_q <= 1'b0;
    end else begin
      pend_q <= m_req_valid && !m_req_ready;
      if (fwd_acc && !m_rsp_hs)      out_q <= 1'b1;
      else if (m_rsp_hs)             out_q <= 1'b0;
      if (loc_acc)                   loc_q <= 1'b1;
      else if (loc_q && s_rsp_ready) loc_q <= 1'b0;
    end
  end
  assign refused_evt = loc_acc;
endmodule

`default_nettype wire
