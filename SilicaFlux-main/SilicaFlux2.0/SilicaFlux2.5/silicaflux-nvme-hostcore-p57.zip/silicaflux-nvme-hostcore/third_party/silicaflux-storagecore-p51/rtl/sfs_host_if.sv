// =============================================================================
// SilicaFlux StorageCore :: sfs_host_if -- storage host controller (host interface)
//
// NVMe-inspired (not NVMe compliant) queue interface for the simulated host and,
// later, a PCIe endpoint BAR:
//   * SQ ring (SQD x 32-byte entries) and CQ ring (CQD x 16-byte entries) live
//     in controller memory, reached through the host BAR (SFB2 slave, 32-bit):
//     the host writes SQ entries, rings SQ_TAIL; reads CQ entries (phase tag),
//     rings CQ_HEAD.  Doorbell values are validated (DB_ERR, value ignored).
//   * Fetch: one command at a time is copied from SQ[head] into an output
//     register (so later host writes to the slot cannot change it) and offered
//     to the command controller as sfs_cmd_t on a ready/valid channel.
//   * Completions (sfs_cpl_t, ready/valid) are written to CQ[tail] with the
//     phase tag and the current SQ head; a full CQ back-pressures (cpl_ready=0).
//   * Controller enable / reset (NVMe CC.EN / CSTS.RDY model):
//       EN 0->1 : EN_RISE event to firmware; firmware writes HIF CTRL.RDY.
//       EN 1->0 : RESETTING: fetching stops, the command already offered drains,
//                 completions are DROPPED (counted); when no command is
//                 outstanding (outstanding_zero) the queues are cleared,
//                 RDY = 0, RESET_DONE event.  Firmware must complete (abort)
//                 every tag it owns -- that is the safe quiescence point.
//   * Host interrupt: CQ pending (CQ tail != head) and/or sticky event.
// One clock domain (clk).  A real PCIe endpoint would bring its own clock;
// the BAR and completion paths would then need CDC FIFOs (docs/04).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfs_host_if
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
#(
  parameter int SQD             = 16,
  parameter int CQD             = 16,
  parameter int CMD_QUEUE_DEPTH = 8,
  parameter int ADDRESS_WIDTH   = 32,
  localparam int SW = $clog2(SQD),
  localparam int CW = $clog2(CQD)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // ---------------------------------------------------------------- host BAR (SFB2 slave, SHC window)
  input  wire logic        h_req_valid,
  output logic             h_req_ready,
  input  wire logic        h_req_write,
  input  wire logic [31:0] h_req_addr,
  input  wire logic [31:0] h_req_wdata,
  input  wire logic [3:0]  h_req_wstrb,
  output logic             h_rsp_valid,
  input  wire logic        h_rsp_ready,
  output logic [31:0]      h_rsp_rdata,
  output logic             h_rsp_error,
  output logic             host_irq,
  // ---------------------------------------------------------------- firmware page (HIF)
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             irq_hif,
  // ---------------------------------------------------------------- command / completion channels
  output logic             cmd_valid,
  input  wire logic        cmd_ready,
  output sfs_cmd_t         cmd,
  input  wire logic        cpl_valid,
  output logic             cpl_ready,
  input  wire sfs_cpl_t    cpl,
  // ---------------------------------------------------------------- status from the rest of the subsystem
  input  wire logic [63:0] capacity,
  input  wire logic [15:0] mdts,
  input  wire logic        outstanding_zero,   // no tag owned by the command controller / firmware
  input  wire logic        plp_quiesce,
  // ---------------------------------------------------------------- state / events
  output logic             en_o,
  output logic             rdy_o,
  output logic             resetting_o,
  output logic             ev_fetch,
  output logic             ev_cpl,
  output logic             ev_cq_stall,
  output logic             ev_db_err
);
  // ================================================================ state
  localparam int SQE_BITS = SFS_SQE_W * 32;
  logic [SQE_BITS-1:0] sq_mem [SQD];
  logic [SFS_CQE_W*32-1:0] cq_mem [CQD];
  logic [SW-1:0] sq_head, sq_tail;
  logic [CW-1:0] cq_head, cq_tail;
  logic          phase;
  logic [CQD-1:0] cq_ph;          // phase tag of every CQ slot (cleared on reset: no stale entry looks new)
  logic          en, shn, rdy, resetting, cfs;
  logic [1:0]    shst, int_ctrl;
  logic          int_evt;
  logic [4:0]    evt_status, evt_en;
  logic [16:0]   db_err_info;
  logic [31:0]   cq_stalls, n_sub, n_cpl;
  logic          stg_valid;
  sfs_cmd_t      stg;

  function automatic logic [SW-1:0] sinc(input logic [SW-1:0] p);
    sinc = (p == SW'(SQD - 1)) ? '0 : p + SW'(1);
  endfunction
  function automatic logic [CW-1:0] cinc(input logic [CW-1:0] p);
    cinc = (p == CW'(CQD - 1)) ? '0 : p + CW'(1);
  endfunction

  wire sq_empty = (sq_head == sq_tail);
  wire cq_full  = (cinc(cq_tail) == cq_head);
  wire cq_pend  = (cq_tail != cq_head);

  // ================================================================ fetch
  wire fetch = !stg_valid && en && rdy && !resetting && !sq_empty;
  assign cmd_valid = stg_valid;
  assign cmd       = stg;
  wire cmd_hs = cmd_valid && cmd_ready;

  // ================================================================ completion
  assign cpl_ready = resetting || !cq_full;
  wire cpl_hs  = cpl_valid && cpl_ready;
  wire cpl_wr  = cpl_hs && !resetting;
  assign ev_fetch    = fetch;
  assign ev_cpl      = cpl_wr;
  assign ev_cq_stall = cpl_valid && !cpl_ready;

  // ================================================================ host BAR access decode
  wire [15:0] ha = h_req_addr[15:0];
  wire        h_acc = h_req_valid && h_req_ready;
  wire        in_sq = (ha >= SFS_SHC_SQ_RING) && (ha < SFS_SHC_SQ_RING + 16'(SQD * SFS_SHC_SQ_RING_STRIDE));
  wire        in_cq = (ha >= SFS_SHC_CQ_RING) && (ha < SFS_SHC_CQ_RING + 16'(CQD * SFS_SHC_CQ_RING_STRIDE));
  wire [15:0] sq_off = ha - SFS_SHC_SQ_RING;
  wire [15:0] cq_off = ha - SFS_SHC_CQ_RING;
  wire [SW-1:0] sq_slot = sq_off[5 +: SW];
  wire [2:0]    sq_word = sq_off[4:2];
  wire [CW-1:0] cq_slot = cq_off[4 +: CW];
  wire [1:0]    cq_word = cq_off[3:2];
  wire        full_word = (h_req_wstrb == 4'hF);
  wire        hi_bits   = (h_req_addr[31:16] != 16'h0) || (h_req_addr[1:0] != 2'b00);

  logic [31:0] h_rd;
  logic        h_ok;     // address decodes for this access type
  always_comb begin
    h_rd = 32'h0;
    h_ok = 1'b1;
    if (hi_bits) h_ok = 1'b0;
    else if (in_sq) h_rd = sq_mem[sq_slot][sq_word*32 +: 32];
    else if (in_cq) begin
      h_rd = cq_mem[cq_slot][cq_word*32 +: 32];
      if (cq_word == 2'd3) h_rd[16] = cq_ph[cq_slot];
      if (h_req_write) h_ok = 1'b0;
    end else begin
      case (ha)
        16'(SFS_SHC_ID):          h_rd = SFS_HIF_ID_VALUE;
        16'(SFS_SHC_VERSION):     h_rd = SFS_PROTO_VERSION;
        16'(SFS_SHC_CAP):         h_rd = {8'(SFS_LBA_BYTES / 64), 8'(CMD_QUEUE_DEPTH), 8'(CQD), 8'(SQD)};
        16'(SFS_SHC_CAP2):        h_rd = {8'h0, 8'(ADDRESS_WIDTH), mdts};
        16'(SFS_SHC_CAPACITY_LO): h_rd = capacity[31:0];
        16'(SFS_SHC_CAPACITY_HI): h_rd = capacity[63:32];
        16'(SFS_SHC_CTRL):        h_rd = {30'h0, shn, en};
        16'(SFS_SHC_STATUS):      h_rd = {23'h0, int_evt, 2'b0, resetting, plp_quiesce, shst, cfs, rdy};
        16'(SFS_SHC_INT_CTRL):    h_rd = {30'h0, int_ctrl};
        16'(SFS_SHC_INT_STATUS):  h_rd = {30'h0, int_evt, cq_pend};
        16'(SFS_SHC_SQ_TAIL):     h_rd = 32'(sq_tail);
        16'(SFS_SHC_SQ_HEAD):     h_rd = 32'(sq_head);
        16'(SFS_SHC_CQ_HEAD):     h_rd = 32'(cq_head);
        16'(SFS_SHC_CQ_TAIL):     h_rd = 32'(cq_tail);
        16'(SFS_SHC_SUBMITTED):   h_rd = n_sub;
        16'(SFS_SHC_COMPLETED):   h_rd = n_cpl;
        default:                  h_ok = 1'b0;
      endcase
      // read-only registers refuse writes
      if (h_req_write && !(ha == 16'(SFS_SHC_CTRL) || ha == 16'(SFS_SHC_INT_CTRL) ||
                           ha == 16'(SFS_SHC_INT_STATUS) || ha == 16'(SFS_SHC_SQ_TAIL) ||
                           ha == 16'(SFS_SHC_CQ_HEAD))) h_ok = 1'b0;
    end
    if (h_req_write && !full_word) h_ok = 1'b0;
  end
  wire h_wr = h_acc && h_req_write && h_ok;

  // doorbell validation
  wire [31:0] dbv = h_req_wdata;
  wire        db_sq = h_wr && (ha == 16'(SFS_SHC_SQ_TAIL));
  wire        db_cq = h_wr && (ha == 16'(SFS_SHC_CQ_HEAD));
  wire [CW-1:0] cq_new  = dbv[CW-1:0];
  wire [CW-1:0] cq_used = cq_tail - cq_head;     // mod CQD (CQD is a power of two)
  wire [CW-1:0] cq_adv  = cq_new - cq_head;
  wire sq_db_bad = (dbv >= 32'(SQD)) || !rdy || resetting;
  wire cq_db_bad = (dbv >= 32'(CQD)) || (cq_adv > cq_used);
  assign ev_db_err = (db_sq && sq_db_bad) || (db_cq && cq_db_bad);

  // ================================================================ firmware page
  wire fw_wr = rb_sel && rb_we;
  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    case (rb_addr)
      SFS_HIF_STATE:       rb_rdata = {8'(cq_tail), 8'(sq_tail), 8'(sq_head), shst, 1'b0, cfs, resetting, rdy,
                                       shn, en};
      SFS_HIF_CTRL:        rb_rdata = {28'h0, shst, cfs, rdy};
      SFS_HIF_EVT_STATUS:  rb_rdata = {27'h0, evt_status};
      SFS_HIF_EVT_EN:      rb_rdata = {27'h0, evt_en};
      SFS_HIF_DB_ERR_INFO: rb_rdata = {15'h0, db_err_info};
      SFS_HIF_CQ_STALLS:   rb_rdata = cq_stalls;
      default:             rb_err = 1'b1;
    endcase
    if (rb_we && (rb_addr == SFS_HIF_STATE || rb_addr == SFS_HIF_DB_ERR_INFO || rb_addr == SFS_HIF_CQ_STALLS))
      rb_err = 1'b1;
  end
  assign irq_hif = |(evt_status & evt_en);

  // ================================================================ sequential
  wire reset_done = resetting && !stg_valid && outstanding_zero && !cpl_valid;
  logic en_q, plp_q;
  logic [4:0] evt_set, evt_clr;
  always_comb begin
    evt_set = (5'(en && !en_q) << SFS_HEVT_EN_RISE) | (5'(!en && en_q) << SFS_HEVT_EN_FALL) |
              (5'(h_wr && (ha == 16'(SFS_SHC_CTRL)) && h_req_wdata[1] && !shn) << SFS_HEVT_SHN) |
              (5'(ev_db_err) << SFS_HEVT_DB_ERR) | (5'(reset_done) << SFS_HEVT_RESET_DONE);
    evt_clr = (fw_wr && rb_addr == SFS_HIF_EVT_STATUS) ? rb_wdata[4:0] : 5'd0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sq_head <= '0; sq_tail <= '0; cq_head <= '0; cq_tail <= '0; phase <= 1'b1; cq_ph <= '0;
      en <= 1'b0; en_q <= 1'b0; plp_q <= 1'b0; shn <= 1'b0; rdy <= 1'b0; resetting <= 1'b0; cfs <= 1'b0; shst <= 2'b0;
      int_ctrl <= 2'b0; int_evt <= 1'b0; evt_status <= '0; evt_en <= '0; db_err_info <= '0;
      cq_stalls <= '0; n_sub <= '0; n_cpl <= '0; stg_valid <= 1'b0; stg <= '0;
    end else begin
      en_q <= en;
      plp_q <= plp_quiesce;
      evt_status <= (evt_status & ~evt_clr) | evt_set;
      // ------------------------------------------------ fetch / offer
      if (fetch) begin
        stg       <= sfs_sqe_unpack(sq_mem[sq_head]);
        stg_valid <= 1'b1;
        sq_head   <= sinc(sq_head);
        n_sub     <= n_sub + 32'd1;
      end else if (cmd_hs) begin
        stg_valid <= 1'b0;
      end
      // ------------------------------------------------ completion
      if (cpl_wr) begin
        cq_ph[cq_tail] <= phase;
        cq_tail <= cinc(cq_tail);
        if (cq_tail == CW'(CQD - 1)) phase <= ~phase;
        n_cpl   <= n_cpl + 32'd1;
      end
      if (ev_cq_stall && cq_stalls != 32'hFFFF_FFFF) cq_stalls <= cq_stalls + 32'd1;
      // ------------------------------------------------ host writes
      if (h_wr) begin
        case (ha)
          16'(SFS_SHC_CTRL): begin
            en  <= h_req_wdata[0];
            shn <= h_req_wdata[1];
          end
          16'(SFS_SHC_INT_CTRL):   int_ctrl <= h_req_wdata[1:0];
          16'(SFS_SHC_INT_STATUS): if (h_req_wdata[1]) int_evt <= 1'b0;
          16'(SFS_SHC_SQ_TAIL):    if (!sq_db_bad) sq_tail <= dbv[SW-1:0];
          16'(SFS_SHC_CQ_HEAD):    if (!cq_db_bad) cq_head <= cq_new;
          default: ;
        endcase
      end
      if (ev_db_err) begin
        db_err_info <= {db_cq, dbv[15:0]};
        int_evt     <= 1'b1;
      end
      // ------------------------------------------------ enable edges
      if (!en && en_q) resetting <= 1'b1;
      // ------------------------------------------------ firmware writes
      if (fw_wr) begin
        case (rb_addr)
          SFS_HIF_CTRL: begin
            // RDY can only be raised while enabled and not resetting
            if (rb_wdata[0] && en && !resetting && !rdy) begin
              rdy <= 1'b1;
              int_evt <= 1'b1;
            end else if (!rb_wdata[0] && rdy) begin
              rdy <= 1'b0;
              int_evt <= 1'b1;
            end
            if (rb_wdata[1] && !cfs) int_evt <= 1'b1;
            cfs  <= rb_wdata[1];
            shst <= rb_wdata[3:2];
          end
          SFS_HIF_EVT_EN:     evt_en <= rb_wdata[4:0];
          default: ;
        endcase
      end
      // ------------------------------------------------ reset completion
      if (reset_done) begin
        resetting <= 1'b0;
        rdy       <= 1'b0;
        sq_head <= '0; sq_tail <= '0; cq_head <= '0; cq_tail <= '0; phase <= 1'b1; cq_ph <= '0;
        shst <= 2'b0;
        int_evt <= 1'b1;
      end
      if (plp_quiesce && !plp_q) int_evt <= 1'b1;
    end
  end

  // ring storage (no reset: contents are defined by the host before use)
  always_ff @(posedge clk) begin
    if (h_wr && in_sq) sq_mem[sq_slot][sq_word*32 +: 32] <= h_req_wdata;
    if (cpl_wr) cq_mem[cq_tail] <= sfs_cqe_pack(cpl, phase, 16'(sq_head));
  end

  // ================================================================ host response (1 cycle, held under back-pressure)
  assign h_req_ready = !h_rsp_valid || h_rsp_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      h_rsp_valid <= 1'b0;
      h_rsp_rdata <= '0;
      h_rsp_error <= 1'b0;
    end else if (h_acc) begin
      h_rsp_valid <= 1'b1;
      h_rsp_rdata <= (h_ok && !h_req_write) ? h_rd : 32'h0;
      h_rsp_error <= !h_ok;
    end else if (h_rsp_ready) begin
      h_rsp_valid <= 1'b0;
    end
  end

  assign host_irq    = (int_ctrl[0] && cq_pend) || (int_ctrl[1] && int_evt);
  assign en_o        = en;
  assign rdy_o       = rdy;
  assign resetting_o = resetting;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^h_req_addr[1:0] ^ ^rb_wdata[31:5] ^ ^sq_off[15:9] ^ ^sq_off[1:0] ^ ^cq_off[15:8] ^ ^cq_off[1:0];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
