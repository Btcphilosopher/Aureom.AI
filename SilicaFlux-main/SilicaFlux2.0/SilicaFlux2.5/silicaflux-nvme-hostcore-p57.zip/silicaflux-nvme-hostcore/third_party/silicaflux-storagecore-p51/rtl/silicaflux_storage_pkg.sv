// =============================================================================
// SilicaFlux StorageCore (Project 51) :: silicaflux_storage_pkg
//
// Versioned internal storage transaction protocol.  Every storage block that
// carries a command or a completion uses these types on a ready/valid channel:
//
//   producer: valid=1 + payload held stable until ready=1 (no withdrawal);
//   consumer: ready may depend on valid; valid must not depend on ready;
//   transfer on the rising edge where valid && ready.
//   (Same rules as the SilicaFlux SFB2 request channel, PROTOCOL.md R1-R3.)
//
//   sfs_cmd_t  host interface -> command controller (and, by tag, firmware)
//   sfs_cpl_t  command controller -> host interface
//
// Enumerations (opcode, address type, direction, status, error code, NAND /
// DMA status, interrupt and RAS sources) are GENERATED from
// config/sfs_memmap.yaml into rtl/generated/sfs_proto_enums.svh and included
// here, so the SV types, the C header and the documentation cannot diverge.
//
// Version rule: MAJOR changes when a field moves or changes meaning; MINOR when
// a field is added in reserved space or an enum value is added.  A consumer
// must reject (or ignore) a transaction with an unknown MAJOR.
// Classification: SYNTHESIZABLE (package)
// =============================================================================
`default_nettype none

package silicaflux_storage_pkg;
  /* verilator lint_off UNUSEDPARAM */
  /* verilator lint_off UNUSEDSIGNAL */

  localparam int SFS_PROTO_MAJOR = 1;
  localparam int SFS_PROTO_MINOR = 0;
  // must equal sfs_map_pkg::SFS_PROTO_VERSION (generated from the YAML); checked in sfs_sys_regs
  localparam logic [31:0] SFS_PKG_PROTO_VERSION = (32'(SFS_PROTO_MAJOR) << 16) | 32'(SFS_PROTO_MINOR);

  `include "sfs_proto_enums.svh"

  // ---------------------------------------------------------------- ABI field widths
  localparam int SFS_TID_W    = 16;   // transaction ID (host command identifier)
  localparam int SFS_ADDR_W   = 64;   // LBA or PPA as carried; ADDRESS_WIDTH bits implemented
  localparam int SFS_LEN_W    = 32;   // transfer length in logical blocks (1-based)
  localparam int SFS_HADDR_W  = 64;   // host buffer address as carried
  localparam int SFS_SQE_W    = 8;    // SQ entry words
  localparam int SFS_CQE_W    = 4;    // CQ entry words

  // SQ entry W0 flag bits ([15:8])
  localparam int SFS_FLAG_PHYS = 0;   // ADDR_TYPE (sfs_addr_type_e)
  localparam int SFS_FLAG_FUA  = 1;   // force unit access
  localparam logic [7:0] SFS_FLAG_RSVD = 8'hFC;

  // ---------------------------------------------------------------- command transaction
  typedef struct packed {
    logic [7:0]             opcode;     // sfs_opcode_e
    logic                   addr_type;  // sfs_addr_type_e
    logic [1:0]             dir;        // sfs_dir_e (derived from opcode)
    logic [7:0]             flags;      // raw W0[15:8] (FUA, reserved bits for validation)
    logic [SFS_TID_W-1:0]   tid;        // transaction ID
    logic [SFS_ADDR_W-1:0]  addr;       // logical or physical address
    logic [SFS_LEN_W-1:0]   len;        // blocks (0 for non-data commands)
    logic [SFS_HADDR_W-1:0] host_addr;  // host buffer
    logic [31:0]            aux;        // opcode specific (IDENTIFY: CNS)
    logic [31:0]            rsvd;       // W7, must be 0
  } sfs_cmd_t;

  // ---------------------------------------------------------------- completion transaction
  typedef struct packed {
    logic [SFS_TID_W-1:0]   tid;        // transaction ID of the command
    logic [6:0]             status;     // sfs_status_e
    logic [7:0]             err;        // sfs_err_e
    logic [31:0]            result0;    // completion metadata (e.g. blocks transferred)
    logic [31:0]            result1;    // completion metadata (e.g. corrected bits)
  } sfs_cpl_t;

  // ---------------------------------------------------------------- helpers
  function automatic logic [1:0] sfs_op_dir(input logic [7:0] op);
    case (op)
      SFS_OP_READ, SFS_OP_IDENTIFY, SFS_OP_GET_LOG: sfs_op_dir = SFS_DIR_TO_HOST;
      SFS_OP_WRITE:                                 sfs_op_dir = SFS_DIR_FROM_HOST;
      default:                                      sfs_op_dir = SFS_DIR_NONE;
    endcase
  endfunction

  function automatic logic sfs_op_supported(input logic [7:0] op);
    case (op)
      SFS_OP_FLUSH, SFS_OP_WRITE, SFS_OP_READ, SFS_OP_DEALLOCATE,
      SFS_OP_IDENTIFY, SFS_OP_GET_LOG, SFS_OP_ERASE: sfs_op_supported = 1'b1;
      default:                                       sfs_op_supported = 1'b0;
    endcase
  endfunction

  // commands whose LEN counts logical blocks that are range-checked
  function automatic logic sfs_op_ranged(input logic [7:0] op);
    sfs_op_ranged = (op == SFS_OP_READ) || (op == SFS_OP_WRITE) || (op == SFS_OP_DEALLOCATE);
  endfunction

  // commands that move LEN blocks through a host buffer
  function automatic logic sfs_op_has_hbuf(input logic [7:0] op);
    sfs_op_has_hbuf = (op == SFS_OP_READ) || (op == SFS_OP_WRITE) ||
                      (op == SFS_OP_IDENTIFY) || (op == SFS_OP_GET_LOG);
  endfunction

  // Packed layouts (field order of the structs above; first field = MSBs).  The
  // conversion functions work on plain vectors so that every tool in the flow
  // (Verilator, Icarus 12, Yosys 0.33) accepts them; a packed vector and the
  // struct of the same width are assignment compatible.
  localparam int SFS_CMD_BITS = 8 + 1 + 2 + 8 + SFS_TID_W + SFS_ADDR_W + SFS_LEN_W + SFS_HADDR_W + 32 + 32; // 259
  localparam int SFS_CPL_BITS = SFS_TID_W + 7 + 8 + 32 + 32;                                       // 95
  // ($bits(type) is not used: Yosys 0.33 cannot parse it; sfs_cmd_ctrl checks the sum in simulation)
  localparam int SFS_CMD_O_RSVD = 0,   SFS_CMD_O_AUX = 32,  SFS_CMD_O_HADDR = 64, SFS_CMD_O_LEN = 128;
  localparam int SFS_CMD_O_ADDR = 160, SFS_CMD_O_TID = 224, SFS_CMD_O_FLAGS = 240, SFS_CMD_O_DIR = 248;
  localparam int SFS_CMD_O_ATYPE = 250, SFS_CMD_O_OPC = 251;
  localparam int SFS_CPL_O_R1 = 0, SFS_CPL_O_R0 = 32, SFS_CPL_O_ERR = 64, SFS_CPL_O_ST = 72, SFS_CPL_O_TID = 79;

  // SQ entry (8 x 32 bit, word 0 = bits [31:0]) -> command transaction
  function automatic logic [SFS_CMD_BITS-1:0] sfs_sqe_unpack(input logic [SFS_SQE_W*32-1:0] e);
    sfs_sqe_unpack = {e[7:0], e[8 + SFS_FLAG_PHYS], sfs_op_dir(e[7:0]), e[15:8], e[31:16],
                      e[127:64], e[159:128], e[223:160], e[63:32], e[255:224]};
  endfunction

  // command transaction -> SQ-entry layout (firmware tag-table window)
  function automatic logic [SFS_SQE_W*32-1:0] sfs_sqe_pack(input logic [SFS_CMD_BITS-1:0] c);
    sfs_sqe_pack = {c[SFS_CMD_O_RSVD +: 32], c[SFS_CMD_O_HADDR + 32 +: 32], c[SFS_CMD_O_HADDR +: 32],
                    c[SFS_CMD_O_LEN +: 32], c[SFS_CMD_O_ADDR + 32 +: 32], c[SFS_CMD_O_ADDR +: 32],
                    c[SFS_CMD_O_AUX +: 32], c[SFS_CMD_O_TID +: 16], c[SFS_CMD_O_FLAGS +: 8], c[SFS_CMD_O_OPC +: 8]};
  endfunction

  // completion -> CQ entry (4 x 32 bit, word 0 = bits [31:0])
  function automatic logic [SFS_CQE_W*32-1:0] sfs_cqe_pack(input logic [SFS_CPL_BITS-1:0] p, input logic phase,
                                                           input logic [15:0] sq_head);
    sfs_cqe_pack = {p[SFS_CPL_O_ERR +: 8], p[SFS_CPL_O_ST +: 7], phase, p[SFS_CPL_O_TID +: 16],
                    16'h0, sq_head, p[SFS_CPL_O_R1 +: 32], p[SFS_CPL_O_R0 +: 32]};
  endfunction

  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_on UNUSEDPARAM */
endpackage

`default_nettype wire
