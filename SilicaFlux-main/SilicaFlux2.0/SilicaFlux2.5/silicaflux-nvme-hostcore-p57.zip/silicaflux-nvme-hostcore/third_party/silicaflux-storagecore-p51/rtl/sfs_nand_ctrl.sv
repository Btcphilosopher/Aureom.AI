// =============================================================================
// SilicaFlux StorageCore :: sfs_nand_ctrl -- one NAND channel controller
//
// Firmware stages an operation (OP_ROW / OP_COL / OP_BUF / OP_LEN) and writes
// OP_SUBMIT {op, ECC_EN, tag}; operations run in order and each produces one
// completion {tag, status, NAND status byte, info} (CPL_HEAD / CPL_INFO0/1 /
// CPL_POP).  Back-pressure: a full completion queue stalls the channel.
//
// Pin interface: ONFI-style asynchronous SDR (CE#, CLE, ALE, WE#, RE#, WP#,
// DQ[CDW-1:0] split into dq_o/dq_oe/dq_i for the pad, R/B#).  All outputs are
// registered; WE#/RE# pulse widths are programmable in core-clock cycles
// (TIMING0/1), data from the device is sampled at the end of the RE# low
// phase.  R/B# is the only asynchronous input: 2-flop synchroniser (sfv_sync).
//   RESET       FFh                      wait R/B#
//   READ_ID     90h 00h                  5 bytes
//   READ_STATUS 70h                      1 byte
//   READ_PAGE   00h C1 C2 R1 R2 R3 30h   wait R/B#, data out -> buffer SRAM
//   PROGRAM     80h C1 C2 R1 R2 R3 data  10h, wait R/B#, 70h status
//   ERASE       60h R1 R2 R3 D0h         wait R/B#, 70h status
// Page data layout with ECC_EN (ENABLE_ECC = 1): every DW-bit fabric word is
// followed on the NAND bus by one ECC beat holding the SECDED check bits
// (sfras_secded_enc/dec, Project 26, K = DW: 7 bits for 32, 8 bits for 64;
// unused beat bits = 1).  Decoding is on the fly: corrected data is written to
// the buffer, CE bits / UE words are counted and reported.  A word whose data
// and ECC beat are all ones is an ERASED word (no decode, data = all ones).
// PROGRAM / ERASE are refused (status WP, no device access) while the
// channel's WP# is asserted (CH_CTRL.WP_N = 0 or the power-loss wp_force).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`default_nettype none

module sfs_nand_ctrl
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
#(
  parameter int CH         = 0,
  parameter int CDW        = 8,      // CHANNEL_DATA_WIDTH
  parameter int DW         = 32,     // fabric / DMA word
  parameter int PAGE_BYTES = 512,
  parameter int ENABLE_ECC = 1,
  parameter int OQD        = 4,
  parameter int CQD        = 4,
  localparam int SB    = DW / 8,
  localparam int OFF   = $clog2(SB),
  localparam int BEATS = DW / CDW,
  localparam int R     = $clog2(DW + $clog2(DW + 1) + 1),
  localparam int N     = DW + R + 1
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // firmware page (NAND, this channel's 256-byte slice)
  input  wire logic           rb_sel,
  input  wire logic           rb_we,
  input  wire logic [7:0]     rb_addr,
  input  wire logic [31:0]    rb_wdata,
  output logic [31:0]         rb_rdata,
  output logic                rb_err,
  // SFB2 master (buffer SRAM)
  output logic                m_req_valid,
  input  wire logic           m_req_ready,
  output logic                m_req_write,
  output logic [31:0]         m_req_addr,
  output logic [DW-1:0]       m_req_wdata,
  output logic [SB-1:0]       m_req_wstrb,
  input  wire logic           m_rsp_valid,
  output logic                m_rsp_ready,
  input  wire logic [DW-1:0]  m_rsp_rdata,
  input  wire logic           m_rsp_error,
  // NAND pins
  output logic                nand_ce_n,
  output logic                nand_cle,
  output logic                nand_ale,
  output logic                nand_we_n,
  output logic                nand_re_n,
  output logic                nand_wp_n,
  output logic [CDW-1:0]      nand_dq_o,
  output logic                nand_dq_oe,
  input  wire logic [CDW-1:0] nand_dq_i,
  input  wire logic           nand_rb_n,          // asynchronous
  // control / status
  input  wire logic           wp_force,           // power-loss write protect
  output logic                irq,
  output logic                busy,
  output logic                ev_rd_page,
  output logic                ev_prog,
  output logic                ev_erase,
  output logic                ev_ce,              // one corrected word
  output logic                ev_ue,              // one uncorrectable word
  output logic                ev_tmo,
  output logic                ev_fw_err
);
  // ================================================================ registers
  logic [31:0] ctrl_q, tim0, tim1, tmo_q, r_row, r_col, r_buf, r_len;
  logic        ovf;
  logic [31:0] st_ops, st_ce, st_ue, st_busy;
  wire [7:0] t_wp  = (tim0[7:0]   == 8'd0) ? 8'd1 : tim0[7:0];
  wire [7:0] t_wh  = (tim0[15:8]  == 8'd0) ? 8'd1 : tim0[15:8];
  wire [7:0] t_rp  = (tim0[23:16] == 8'd0) ? 8'd1 : tim0[23:16];
  wire [7:0] t_reh = (tim0[31:24] == 8'd0) ? 8'd1 : tim0[31:24];
  wire [7:0] t_whr = (tim1[7:0]   == 8'd0) ? 8'd1 : tim1[7:0];
  wire [7:0] t_wb  = (tim1[15:8]  == 8'd0) ? 8'd1 : tim1[15:8];

  // ================================================================ queues
  localparam int OPW = 4 + 1 + 8 + 24 + 16 + 32 + 32;
  wire fw_wr = rb_sel && rb_we;
  logic           oq_in_ready, oq_out_valid, oq_pop;
  logic [OPW-1:0] oq_head;
  logic [$clog2(OQD+1)-1:0] oq_level;
  wire submit = fw_wr && rb_addr == SFS_NAND_OP_SUBMIT[7:0];
  assign ev_fw_err = submit && !oq_in_ready;
  sfs_fifo #(.W(OPW), .DEPTH(OQD)) u_oq (
    .clk, .rst_n, .clr(1'b0),
    .in_valid(submit), .in_ready(oq_in_ready),
    .in_data({rb_wdata[3:0], rb_wdata[8], rb_wdata[23:16], r_row[23:0], r_col[15:0], r_buf, r_len}),
    .out_valid(oq_out_valid), .out_ready(oq_pop), .out_data(oq_head), .level(oq_level)
  );
  // completion {tag, status, sr, info0, info1}
  localparam int CPW = 8 + 8 + 8 + 32 + 32;
  logic           cq_in_valid, cq_in_ready, cq_out_valid, cq_pop;
  logic [CPW-1:0] cq_in, cq_head;
  logic [$clog2(CQD+1)-1:0] cq_level;
  sfs_fifo #(.W(CPW), .DEPTH(CQD)) u_cq (
    .clk, .rst_n, .clr(1'b0),
    .in_valid(cq_in_valid), .in_ready(cq_in_ready), .in_data(cq_in),
    .out_valid(cq_out_valid), .out_ready(cq_pop), .out_data(cq_head), .level(cq_level)
  );
  assign cq_pop = fw_wr && rb_addr == SFS_NAND_CPL_POP[7:0] && cq_out_valid;

  // ================================================================ R/B# synchroniser (genuine asynchronous input)
  logic rb_s;
  sfv_sync #(.RESET_VAL(1'b0)) u_rb_sync (.clk, .rst_n, .d(nand_rb_n), .q(rb_s));

  // ================================================================ PHY: bus-cycle primitives
  typedef enum logic [2:0] { K_CMD, K_ADDR, K_DIN, K_DOUT, K_WAIT, K_DLY } kind_e;
  typedef enum logic [2:0] { P_IDLE, P_WLO, P_WHI, P_RLO, P_RHI, P_WB, P_RB, P_DLY } pst_e;
  pst_e           pst;
  logic           p_req, p_done, p_tmo;
  kind_e          p_kind;
  logic [CDW-1:0] p_wd, p_rd;
  logic [7:0]     p_n;
  logic [7:0]     pcnt;
  logic [31:0]    tcnt;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pst <= P_IDLE; p_done <= 1'b0; p_tmo <= 1'b0; p_rd <= '0; pcnt <= '0; tcnt <= '0;
      nand_cle <= 1'b0; nand_ale <= 1'b0; nand_we_n <= 1'b1; nand_re_n <= 1'b1;
      nand_dq_o <= '0; nand_dq_oe <= 1'b0;
    end else begin
      p_done <= 1'b0;
      case (pst)
        P_IDLE: if (p_req) begin
          p_tmo <= 1'b0;
          case (p_kind)
            K_CMD, K_ADDR, K_DIN: begin
              nand_cle   <= (p_kind == K_CMD);
              nand_ale   <= (p_kind == K_ADDR);
              nand_dq_o  <= p_wd;
              nand_dq_oe <= 1'b1;
              nand_we_n  <= 1'b0;
              pcnt <= t_wp - 8'd1;
              pst  <= P_WLO;
            end
            K_DOUT: begin
              nand_dq_oe <= 1'b0;
              nand_re_n  <= 1'b0;
              pcnt <= t_rp - 8'd1;
              pst  <= P_RLO;
            end
            K_WAIT: begin
              pcnt <= t_wb - 8'd1;
              pst  <= P_WB;
            end
            default: begin
              pcnt <= (p_n == 8'd0) ? 8'd0 : p_n - 8'd1;
              pst  <= P_DLY;
            end
          endcase
        end
        P_WLO: if (pcnt == 8'd0) begin
          nand_we_n <= 1'b1;               // device latches on this rising edge
          pcnt <= t_wh - 8'd1;
          pst  <= P_WHI;
        end else pcnt <= pcnt - 8'd1;
        P_WHI: if (pcnt == 8'd0) begin
          nand_cle <= 1'b0; nand_ale <= 1'b0; nand_dq_oe <= 1'b0;
          p_done <= 1'b1; pst <= P_IDLE;
        end else pcnt <= pcnt - 8'd1;
        P_RLO: if (pcnt == 8'd0) begin
          p_rd      <= nand_dq_i;           // sampled at the end of tRP
          nand_re_n <= 1'b1;
          pcnt <= t_reh - 8'd1;
          pst  <= P_RHI;
        end else pcnt <= pcnt - 8'd1;
        P_RHI: if (pcnt == 8'd0) begin
          p_done <= 1'b1; pst <= P_IDLE;
        end else pcnt <= pcnt - 8'd1;
        P_WB: if (pcnt == 8'd0) begin
          tcnt <= tmo_q;
          pst  <= P_RB;
        end else pcnt <= pcnt - 8'd1;
        P_RB: if (rb_s) begin
          p_done <= 1'b1; pst <= P_IDLE;
        end else if (tcnt == 32'd0) begin
          p_tmo <= 1'b1; p_done <= 1'b1; pst <= P_IDLE;
        end else tcnt <= tcnt - 32'd1;
        P_DLY: if (pcnt == 8'd0) begin
          p_done <= 1'b1; pst <= P_IDLE;
        end else pcnt <= pcnt - 8'd1;
        default: pst <= P_IDLE;
      endcase
    end
  end

  // ================================================================ ECC
  logic [DW-1:0]  wword;            // word being assembled / sent
  logic [CDW-1:0] eccbeat;
  logic [N-1:0]   enc_cw;
  logic [DW-1:0]  dec_data;
  logic           dec_ce, dec_ue;
  generate
    if (ENABLE_ECC != 0) begin : g_ecc
      logic [N-1:0] dec_cw;
      /* verilator lint_off UNUSEDSIGNAL */
      logic [N-1:0] dec_corr_u;
      logic         dec_none_u, dec_inv_u, dec_cd_u;
      logic [$clog2(N)-1:0] dec_idx_u;
      logic [R:0]   dec_syn_u;
      /* verilator lint_on UNUSEDSIGNAL */
      sfras_secded_enc #(.K(DW)) u_enc (.data_i(wword), .cw_o(enc_cw));
      assign dec_cw = {eccbeat[R:0], wword};
      sfras_secded_dec #(.K(DW)) u_dec (
        .cw_i(dec_cw), .data_o(dec_data), .cw_corr_o(dec_corr_u), .none_o(dec_none_u), .ce_o(dec_ce),
        .ue_o(dec_ue), .ue_inval_o(dec_inv_u), .ce_data_o(dec_cd_u), .err_idx_o(dec_idx_u), .syn_o(dec_syn_u)
      );
    end else begin : g_noecc
      assign enc_cw   = {(N - DW)'(0), wword};
      assign dec_data = wword;
      assign dec_ce   = 1'b0;
      assign dec_ue   = 1'b0;
    end
  endgenerate
  // ECC beat sent on the bus: check bits in the low bits, unused bits = 1
  logic [CDW-1:0] ecc_out;
  always_comb begin
    ecc_out = {CDW{1'b1}};
    ecc_out[R:0] = enc_cw[N-1:DW];
  end
  wire erased_word = (wword == {DW{1'b1}}) && (eccbeat == {CDW{1'b1}});
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_enc = ^enc_cw[DW-1:0];          // only the check bits leave on the bus
  /* verilator lint_on UNUSEDSIGNAL */

  // ================================================================ operation sequencer
  typedef enum logic [4:0] {
    O_IDLE, O_CHECK, O_C1, O_ADDR, O_C2, O_WRB, O_C3, O_DLY, O_SR, O_ID,
    O_PR_BEAT, O_PR_DEC, O_PR_WREQ, O_PR_WRSP, O_PW_RREQ, O_PW_RRSP, O_PW_BEAT, O_CPL
  } ost_e;
  ost_e        ost, dly_next;
  logic        iss;                  // primitive issued, waiting for p_done
  logic [3:0]  op;
  logic        ecc_en;
  logic [7:0]  tag, ostat, sr;
  logic [23:0] row;
  logic [15:0] col;
  logic [31:0] obuf, olen;
  logic [2:0]  ai;                   // address byte index
  logic [3:0]  bi;                   // beat index inside a word (incl. the ECC beat)
  logic [15:0] wi, nw;               // word index / words
  logic [31:0] info0, info1;
  logic [15:0] ce_bits, ue_words;
  logic        first_ue;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [39:0] idbytes;                      // [7:0] is shifted out by the 5th byte
  /* verilator lint_on UNUSEDSIGNAL */

  wire [3:0]  h_op   = oq_head[OPW-1 -: 4];
  wire        h_ecc  = oq_head[OPW-5];
  wire [7:0]  h_tag  = oq_head[OPW-6 -: 8];
  wire [23:0] h_row  = oq_head[OPW-14 -: 24];
  wire [15:0] h_col  = oq_head[OPW-38 -: 16];
  wire [31:0] h_buf  = oq_head[63:32];
  wire [31:0] h_len  = oq_head[31:0];
  assign oq_pop = (ost == O_IDLE) && oq_out_valid;

  wire use_ecc = ecc_en && (ENABLE_ECC != 0);
  wire [3:0] nbeats = 4'(BEATS) + (use_ecc ? 4'd1 : 4'd0);
  wire wp_n_eff = ctrl_q[0] && !wp_force;
  logic [7:0] abyte;
  always_comb begin
    if (op == 4'(SFS_NOP_ERASE)) begin
      case (ai)
        3'd0: abyte = row[7:0];
        3'd1: abyte = row[15:8];
        default: abyte = row[23:16];
      endcase
    end else if (op == 4'(SFS_NOP_READ_ID)) begin
      abyte = 8'h00;
    end else begin
      case (ai)
        3'd0: abyte = col[7:0];
        3'd1: abyte = col[15:8];
        3'd2: abyte = row[7:0];
        3'd3: abyte = row[15:8];
        default: abyte = row[23:16];
      endcase
    end
  end
  wire [2:0] naddr = (op == 4'(SFS_NOP_ERASE)) ? 3'd3 : (op == 4'(SFS_NOP_READ_ID)) ? 3'd1 : 3'd5;

  // primitive request for the current state
  always_comb begin
    p_req  = 1'b0;
    p_kind = K_DLY;
    p_wd   = '0;
    p_n    = 8'd1;
    if (!iss) begin
      case (ost)
        O_C1: begin
          p_req = 1'b1; p_kind = K_CMD;
          case (op)
            4'(SFS_NOP_RESET):       p_wd = CDW'(8'hFF);
            4'(SFS_NOP_READ_ID):     p_wd = CDW'(8'h90);
            4'(SFS_NOP_READ_STATUS): p_wd = CDW'(8'h70);
            4'(SFS_NOP_READ_PAGE):   p_wd = CDW'(8'h00);
            4'(SFS_NOP_PROGRAM):     p_wd = CDW'(8'h80);
            default:                 p_wd = CDW'(8'h60);
          endcase
        end
        O_ADDR:    begin p_req = 1'b1; p_kind = K_ADDR; p_wd = CDW'(abyte); end
        O_C2: begin
          p_req = 1'b1; p_kind = K_CMD;
          p_wd = (op == 4'(SFS_NOP_READ_PAGE)) ? CDW'(8'h30) : (op == 4'(SFS_NOP_PROGRAM)) ? CDW'(8'h10) : CDW'(8'hD0);
        end
        O_WRB:     begin p_req = 1'b1; p_kind = K_WAIT; end
        O_C3:      begin p_req = 1'b1; p_kind = K_CMD; p_wd = CDW'(8'h70); end
        O_DLY:     begin p_req = 1'b1; p_kind = K_DLY; p_n = t_whr; end
        O_SR, O_ID, O_PR_BEAT: begin p_req = 1'b1; p_kind = K_DOUT; end
        O_PW_BEAT: begin
          p_req = 1'b1; p_kind = K_DIN;
          p_wd = (bi == 4'(BEATS)) ? ecc_out : wword[bi[2:0]*CDW +: CDW];
        end
        default: ;
      endcase
    end
  end

  assign m_req_valid = (ost == O_PR_WREQ) || (ost == O_PW_RREQ);
  assign m_req_write = (ost == O_PR_WREQ);
  assign m_req_addr  = obuf + 32'({wi, OFF'(0)});
  assign m_req_wdata = wword;
  assign m_req_wstrb = {SB{1'b1}};
  assign m_rsp_ready = 1'b1;

  assign cq_in_valid = (ost == O_CPL);
  assign cq_in       = {tag, ostat, sr, info0, info1};
  assign busy        = (ost != O_IDLE) || oq_out_valid;
  assign irq         = cq_out_valid && ctrl_q[2];

  assign ev_rd_page = (ost == O_CPL) && cq_in_ready && op == 4'(SFS_NOP_READ_PAGE);
  assign ev_prog    = (ost == O_CPL) && cq_in_ready && op == 4'(SFS_NOP_PROGRAM) && ostat == 8'(SFS_NST_OK);
  assign ev_erase   = (ost == O_CPL) && cq_in_ready && op == 4'(SFS_NOP_ERASE) && ostat == 8'(SFS_NST_OK);
  assign ev_ce      = (ost == O_PR_DEC) && use_ecc && !erased_word && dec_ce;
  assign ev_ue      = (ost == O_PR_DEC) && use_ecc && !erased_word && dec_ue;
  assign ev_tmo     = (ost == O_WRB) && iss && p_done && p_tmo;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ost <= O_IDLE; dly_next <= O_IDLE; iss <= 1'b0; op <= '0; ecc_en <= 1'b0; tag <= '0; ostat <= '0;
      sr <= '0; row <= '0; col <= '0; obuf <= '0; olen <= '0; ai <= '0; bi <= '0; wi <= '0; nw <= '0;
      info0 <= '0; info1 <= '0; ce_bits <= '0; ue_words <= '0; first_ue <= 1'b0; idbytes <= '0;
      wword <= '0; eccbeat <= '0; nand_ce_n <= 1'b1;
      st_ops <= '0; st_ce <= '0; st_ue <= '0; st_busy <= '0;
    end else begin
      if (p_req) iss <= 1'b1;
      if (iss && p_done) iss <= 1'b0;
      if (busy && st_busy != 32'hFFFF_FFFF) st_busy <= st_busy + 32'd1;
      case (ost)
        // -------------------------------------------------------- dispatch
        O_IDLE: if (oq_out_valid) begin
          op <= h_op; ecc_en <= h_ecc; tag <= h_tag; row <= h_row; col <= h_col; obuf <= h_buf;
          olen <= (h_len == 32'd0) ? 32'(PAGE_BYTES) : h_len;
          ostat <= 8'(SFS_NST_OK); sr <= '0; info0 <= '0; info1 <= '0; ce_bits <= '0; ue_words <= '0;
          first_ue <= 1'b0; ai <= '0; bi <= '0; wi <= '0;
          ost <= O_CHECK;
        end
        O_CHECK: begin
          nw <= 16'(olen >> OFF);
          if (op > 4'(SFS_NOP_ERASE) || !ctrl_q[1] ||
              ((op == 4'(SFS_NOP_READ_PAGE) || op == 4'(SFS_NOP_PROGRAM)) &&
               (olen > 32'(PAGE_BYTES) || olen[OFF-1:0] != '0 || obuf[OFF-1:0] != '0))) begin
            ostat <= 8'(SFS_NST_INVALID); ost <= O_CPL;
          end else if ((op == 4'(SFS_NOP_PROGRAM) || op == 4'(SFS_NOP_ERASE)) && !wp_n_eff) begin
            ostat <= 8'(SFS_NST_WP); ost <= O_CPL;
          end else begin
            nand_ce_n <= 1'b0;
            ost <= O_C1;
          end
        end
        // -------------------------------------------------------- command / address cycles
        O_C1: if (iss && p_done) begin
          case (op)
            4'(SFS_NOP_RESET):       ost <= O_WRB;
            4'(SFS_NOP_READ_STATUS): begin dly_next <= O_SR; ost <= O_DLY; end
            default:                 ost <= O_ADDR;
          endcase
        end
        O_ADDR: if (iss && p_done) begin
          if (ai == naddr - 3'd1) begin
            ai <= '0;
            case (op)
              4'(SFS_NOP_READ_ID): begin dly_next <= O_ID; ost <= O_DLY; end
              4'(SFS_NOP_PROGRAM): begin dly_next <= O_PW_RREQ; ost <= O_DLY; end
              default:             ost <= O_C2;
            endcase
          end else ai <= ai + 3'd1;
        end
        O_C2: if (iss && p_done) ost <= O_WRB;
        O_WRB: if (iss && p_done) begin
          if (p_tmo) begin
            ostat <= 8'(SFS_NST_TIMEOUT); ost <= O_CPL;
          end else begin
            case (op)
              4'(SFS_NOP_RESET):     ost <= O_CPL;
              4'(SFS_NOP_READ_PAGE): begin dly_next <= O_PR_BEAT; ost <= O_DLY; end
              default:               ost <= O_C3;
            endcase
          end
        end
        O_C3: if (iss && p_done) begin dly_next <= O_SR; ost <= O_DLY; end
        O_DLY: if (iss && p_done) ost <= dly_next;
        O_SR: if (iss && p_done) begin
          sr <= p_rd[7:0];
          if (op == 4'(SFS_NOP_PROGRAM) && p_rd[0]) ostat <= 8'(SFS_NST_PROG_FAIL);
          if (op == 4'(SFS_NOP_ERASE)   && p_rd[0]) ostat <= 8'(SFS_NST_ERASE_FAIL);
          ost <= O_CPL;
        end
        O_ID: if (iss && p_done) begin
          idbytes <= {p_rd[7:0], idbytes[39:8]};
          if (bi == 4'd4) begin
            // bytes arrive first-to-last; idbytes = {b3,b2,b1,b0,-} before this shift
            info0 <= idbytes[39:8];
            info1 <= {24'h0, p_rd[7:0]};
            bi <= '0;
            ost <= O_CPL;
          end else bi <= bi + 4'd1;
        end
        // -------------------------------------------------------- page read data phase
        O_PR_BEAT: if (iss && p_done) begin
          if (bi == 4'(BEATS)) eccbeat <= p_rd;
          else wword[bi[2:0]*CDW +: CDW] <= p_rd;
          if (bi == nbeats - 4'd1) begin
            bi <= '0;
            if (!use_ecc) eccbeat <= {CDW{1'b1}};
            ost <= O_PR_DEC;
          end else bi <= bi + 4'd1;
        end
        O_PR_DEC: begin
          if (use_ecc && !erased_word) begin
            wword <= dec_data;
            if (dec_ce) begin
              ce_bits <= ce_bits + 16'd1;
              if (st_ce != 32'hFFFF_FFFF) st_ce <= st_ce + 32'd1;
            end
            if (dec_ue) begin
              ue_words <= ue_words + 16'd1;
              if (st_ue != 32'hFFFF_FFFF) st_ue <= st_ue + 32'd1;
              if (!first_ue) begin first_ue <= 1'b1; info1 <= 32'(wi); end
            end
          end
          ost <= O_PR_WREQ;
        end
        O_PR_WREQ: if (m_req_ready) ost <= O_PR_WRSP;
        O_PR_WRSP: if (m_rsp_valid) begin
          if (m_rsp_error) begin
            ostat <= 8'(SFS_NST_BUS_ERR); ost <= O_CPL;
          end else if (wi == nw - 16'd1) begin
            info0 <= {ue_words, ce_bits};
            ostat <= (ue_words != 16'd0) ? 8'(SFS_NST_UNCORR) :
                     (ce_bits != 16'd0)  ? 8'(SFS_NST_CORRECTED) : 8'(SFS_NST_OK);
            ost <= O_CPL;
          end else begin
            wi <= wi + 16'd1;
            ost <= O_PR_BEAT;
          end
        end
        // -------------------------------------------------------- program data phase
        O_PW_RREQ: if (m_req_ready) ost <= O_PW_RRSP;
        O_PW_RRSP: if (m_rsp_valid) begin
          if (m_rsp_error) begin
            // no 10h: the device never programs; the next command cancels the data load
            ostat <= 8'(SFS_NST_BUS_ERR); ost <= O_CPL;
          end else begin
            wword <= m_rsp_rdata;
            bi <= '0;
            ost <= O_PW_BEAT;
          end
        end
        O_PW_BEAT: if (iss && p_done) begin
          if (bi == nbeats - 4'd1) begin
            bi <= '0;
            if (wi == nw - 16'd1) ost <= O_C2;
            else begin
              wi <= wi + 16'd1;
              ost <= O_PW_RREQ;
            end
          end else bi <= bi + 4'd1;
        end
        // -------------------------------------------------------- completion
        O_CPL: if (cq_in_ready) begin
          nand_ce_n <= 1'b1;
          st_ops <= st_ops + 32'd1;
          ost <= O_IDLE;
        end
        default: ost <= O_IDLE;
      endcase
    end
  end

  // ================================================================ register page
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctrl_q <= 32'h0; tim0 <= SFS_NAND_TIMING0_RST; tim1 <= SFS_NAND_TIMING1_RST; tmo_q <= SFS_NAND_TIMEOUT_RST;
      r_row <= '0; r_col <= '0; r_buf <= '0; r_len <= '0; ovf <= 1'b0;
    end else begin
      if (ev_fw_err) ovf <= 1'b1;
      if (fw_wr) begin
        case (rb_addr)
          SFS_NAND_CH_CTRL[7:0]: begin
            ctrl_q <= {29'h0, rb_wdata[2:0]};
            if (rb_wdata[8] && !ev_fw_err) ovf <= 1'b0;
          end
          SFS_NAND_TIMING0[7:0]: tim0  <= rb_wdata;
          SFS_NAND_TIMING1[7:0]: tim1  <= rb_wdata;
          SFS_NAND_TIMEOUT[7:0]: tmo_q <= rb_wdata;
          SFS_NAND_OP_ROW[7:0]:  r_row <= rb_wdata;
          SFS_NAND_OP_COL[7:0]:  r_col <= rb_wdata;
          SFS_NAND_OP_BUF[7:0]:  r_buf <= rb_wdata;
          SFS_NAND_OP_LEN[7:0]:  r_len <= rb_wdata;
          default: ;
        endcase
      end
    end
  end
  assign nand_wp_n = wp_n_eff;

  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    case (rb_addr)
      SFS_NAND_CH_INFO[7:0]:   rb_rdata = {16'(PAGE_BYTES), 7'h0, 1'(ENABLE_ECC != 0), 4'(CDW / 8), 4'(CH)};
      SFS_NAND_CH_STATUS[7:0]: rb_rdata = {15'h0, cq_out_valid, 4'h0, 4'(cq_level), 4'(oq_level), 1'b0,
                                           nand_wp_n, rb_s, busy};
      SFS_NAND_CH_CTRL[7:0]:   rb_rdata = ctrl_q;
      SFS_NAND_TIMING0[7:0]:   rb_rdata = tim0;
      SFS_NAND_TIMING1[7:0]:   rb_rdata = tim1;
      SFS_NAND_TIMEOUT[7:0]:   rb_rdata = tmo_q;
      SFS_NAND_OP_ROW[7:0]:    rb_rdata = r_row;
      SFS_NAND_OP_COL[7:0]:    rb_rdata = r_col;
      SFS_NAND_OP_BUF[7:0]:    rb_rdata = r_buf;
      SFS_NAND_OP_LEN[7:0]:    rb_rdata = r_len;
      SFS_NAND_OP_SUBMIT[7:0]: rb_rdata = 32'h0;
      SFS_NAND_CPL_HEAD[7:0]:  rb_rdata = {cq_out_valid, 7'h0, cq_head[CPW-1 -: 8], cq_head[CPW-9 -: 8],
                                           cq_head[CPW-17 -: 8]};
      SFS_NAND_CPL_INFO0[7:0]: rb_rdata = cq_head[63:32];
      SFS_NAND_CPL_INFO1[7:0]: rb_rdata = cq_head[31:0];
      SFS_NAND_CPL_POP[7:0]:   rb_rdata = 32'h0;
      SFS_NAND_Q_STATUS[7:0]:  rb_rdata = {23'h0, ovf, 4'h0, 4'(OQD - 32'(oq_level))};
      SFS_NAND_STAT_OPS[7:0]:  rb_rdata = st_ops;
      SFS_NAND_STAT_CE[7:0]:   rb_rdata = st_ce;
      SFS_NAND_STAT_UE[7:0]:   rb_rdata = st_ue;
      SFS_NAND_STAT_BUSY[7:0]: rb_rdata = st_busy;
      default:                 rb_err = 1'b1;
    endcase
    if (rb_we && (rb_addr == SFS_NAND_CH_INFO[7:0] || rb_addr == SFS_NAND_CH_STATUS[7:0] ||
                  rb_addr == SFS_NAND_CPL_HEAD[7:0] || rb_addr == SFS_NAND_CPL_INFO0[7:0] ||
                  rb_addr == SFS_NAND_CPL_INFO1[7:0] || rb_addr == SFS_NAND_Q_STATUS[7:0] ||
                  rb_addr == SFS_NAND_STAT_OPS[7:0] || rb_addr == SFS_NAND_STAT_CE[7:0] ||
                  rb_addr == SFS_NAND_STAT_UE[7:0] || rb_addr == SFS_NAND_STAT_BUSY[7:0])) rb_err = 1'b1;
  end

  // ================================================================ parameter checks
  if (CDW != 8 && CDW != 16) begin : g_bad_cdw
    `SFRAS_CFG_FATAL("sfs_nand_ctrl: CHANNEL_DATA_WIDTH must be 8 or 16")
  end
  if (DW != 32 && DW != 64) begin : g_bad_dw
    `SFRAS_CFG_FATAL("sfs_nand_ctrl: DMA_DATA_WIDTH must be 32 or 64")
  end
  if (CDW < R + 1) begin : g_bad_ecc
    `SFRAS_CFG_FATAL("sfs_nand_ctrl: ECC beat narrower than the SECDED check bits")
  end
endmodule

`default_nettype wire
