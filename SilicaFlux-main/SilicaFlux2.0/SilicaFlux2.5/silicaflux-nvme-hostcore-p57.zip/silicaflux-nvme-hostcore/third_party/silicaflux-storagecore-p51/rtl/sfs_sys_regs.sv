// =============================================================================
// SilicaFlux StorageCore :: sfs_sys_regs -- storage system page (ControlCore page 10)
//
//   identity / versions / configuration     readiness (peripheral ready bits)
//   interrupt aggregation -> 2 lines:       IO  -> ControlCore IRQ 4 (acc_tsu_irq_i)
//                                           EVT -> ControlCore IRQ 5 (acc_vec_irq_i)
//   power-loss (PLP): pwr_fail_ni (asynchronous pin, 2-flop synchroniser)
//       fall -> EVENT (sticky) -> QUIESCE: the command controller completes new
//       commands with ABORT_PWR_LOSS, the host sees STATUS.PLP; DRAINED when no
//       tag, DMA or NAND work is left; firmware commits its state and sets
//       FW_SAFE; with AUTO_WP the NAND WP# pins are then asserted.  CLR (pin
//       high again) ends the episode.
//   security: PHYS_EN, HOST_MGMT_LOCK, LOCK (sticky).  No authentication.
//   RAS: sticky sources (buffer ECC, NAND ECC, DMA, NAND timeout, fabric decode,
//       firmware protocol, doorbell, security) -> warning / fatal enables ->
//       ext_warn / ext_fatal (ControlCore RAS SOC sources, unmodified CC).
//   performance counters.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`default_nettype none

module sfs_sys_regs
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
#(
  parameter int NUM_NAND_CHANNELS  = 1,
  parameter int CHANNEL_DATA_WIDTH = 8,
  parameter int BUFFER_SIZE_BYTES  = 16384,
  parameter int DMA_DATA_WIDTH     = 32,
  parameter int ADDRESS_WIDTH      = 32,
  parameter int CMD_QUEUE_DEPTH    = 8,
  parameter int ENABLE_ECC         = 1,
  parameter int ENABLE_RAS         = 1,
  parameter int NAND_PAGE_BYTES    = 512,
  parameter int HOST_QUEUE_DEPTH   = 16,
  parameter int BUF_AW             = 12
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // register page
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // readiness
  input  wire logic        buf_ready,
  input  wire logic        nand_idle,
  input  wire logic        dma_idle,
  input  wire logic        hif_en,
  input  wire logic        hif_rdy,
  input  wire logic        cmd_idle,
  // interrupt sources (levels)
  input  wire logic        src_cmd,
  input  wire logic        src_dma,
  input  wire logic        src_nand,
  input  wire logic        src_hif,
  output logic             irq_io,
  output logic             irq_evt,
  // power loss
  input  wire logic        pwr_fail_ni,       // asynchronous, active low
  output logic             plp_quiesce,
  output logic             wp_force,
  // security
  output logic             phys_en,
  output logic             mgmt_lock,
  input  wire logic        ev_sec_viol,
  // RAS events
  input  wire logic        ev_buf_ce,
  input  wire logic        ev_buf_ue,
  input  wire logic [BUF_AW-1:0] ev_buf_addr,
  input  wire logic [3:0]  ev_nand_ce_n,      // number of channels reporting a corrected word this cycle
  input  wire logic [3:0]  ev_nand_ue_n,
  input  wire logic        ev_dma_err,
  input  wire logic        ev_nand_tmo,
  input  wire logic        ev_fab_dec,
  input  wire logic [31:0] ev_fab_addr,
  input  wire logic        ev_fw_proto,
  input  wire logic        ev_hif_db,
  output logic             ext_warn,
  output logic             ext_fatal,
  // buffer fault injection (ENABLE_RAS)
  output logic             fi_arm,            // one-cycle arm pulse (sfras_ecc_sram fi_arm_i)
  output logic [1:0]       fi_mode,
  output logic [31:0]      fi_mask,
  output logic             fi_addr_en,
  output logic [31:0]      fi_addr,
  input  wire logic        fi_armed,          // injection pending (sfras_ecc_sram fi_armed_o)
  // performance events
  input  wire logic        pe_fetch,
  input  wire logic        pe_cpl,
  input  wire logic        pe_dma_word,
  input  wire logic [3:0]  pe_nand_rd_n,
  input  wire logic [3:0]  pe_nand_pg_n,
  input  wire logic [3:0]  pe_nand_er_n,
  input  wire logic        pe_nand_busy,
  input  wire logic        pe_fab_stall,
  input  wire logic        pe_cq_full,
  input  wire logic        pe_lat_valid,
  input  wire logic [31:0] pe_lat
);
  // ================================================================ state
  logic [5:0]  en_io, en_evt;
  logic        pf_s, pf_q, plp_evt, fw_safe, force_q, auto_wp;
  logic [31:0] plp_events;
  logic        sec_phys, sec_lock_mgmt, sec_lock;
  logic [15:0] viol_cnt;
  logic [9:0]  ras_st, ras_warn_en, ras_fatal_en;
  logic [31:0] buf_ce_cnt, buf_ue_cnt, buf_err_addr, nand_ce_cnt, nand_ue_cnt, fab_addr;
  logic        fi_arm_q, fi_aen_q;
  logic [1:0]  fi_mode_q;
  logic [31:0] fi_mask_q, fi_addr_q;
  logic        pf_freeze;
  logic [31:0] pc_cyc, pc_cmds, pc_cpls, pc_dma, pc_rd, pc_pg, pc_er, pc_busy, pc_stall, pc_cqf, pc_lat, pc_latmax;

  // ================================================================ power-fail synchroniser (genuine asynchronous input)
  logic pwr_ok_s;
  sfv_sync #(.RESET_VAL(1'b1)) u_pf_sync (.clk, .rst_n, .d(pwr_fail_ni), .q(pwr_ok_s));
  assign pf_s = !pwr_ok_s;

  wire quiesce = plp_evt || force_q;
  wire drained = quiesce && cmd_idle && dma_idle && nand_idle;
  assign plp_quiesce = quiesce;
  assign wp_force    = quiesce && auto_wp && fw_safe;

  // ================================================================ interrupts
  wire src_plp = quiesce && !fw_safe;
  wire src_ras = |(ras_st & (ras_warn_en | ras_fatal_en));
  wire [5:0] irq_st = {src_ras, src_plp, src_hif, src_nand, src_dma, src_cmd};
  assign irq_io  = |(irq_st & en_io);
  assign irq_evt = |(irq_st & en_evt);
  assign ext_warn  = |(ras_st & ras_warn_en);
  assign ext_fatal = |(ras_st & ras_fatal_en);

  // ================================================================ RAS set vector
  logic [9:0] ras_set;
  always_comb begin
    ras_set = (10'(ev_buf_ce)              << SFS_RAS_BUF_CE)     | (10'(ev_buf_ue)   << SFS_RAS_BUF_UE)   |
              (10'(ev_nand_ce_n != 4'd0)  << SFS_RAS_NAND_CE)    | (10'(ev_nand_ue_n != 4'd0) << SFS_RAS_NAND_UE) |
              (10'(ev_dma_err)             << SFS_RAS_DMA_ERR)    | (10'(ev_nand_tmo) << SFS_RAS_NAND_TMO) |
              (10'(ev_fab_dec)             << SFS_RAS_FABRIC_DEC) | (10'(ev_fw_proto) << SFS_RAS_FW_PROTO) |
              (10'(ev_hif_db)              << SFS_RAS_HIF_DB)     | (10'(ev_sec_viol) << SFS_RAS_SEC_VIOL);
  end

  function automatic logic [31:0] sat(input logic [31:0] v, input logic [31:0] inc);
    logic [32:0] s;
    s = {1'b0, v} + {1'b0, inc};
    sat = s[32] ? 32'hFFFF_FFFF : s[31:0];
  endfunction

  wire fw_wr = rb_sel && rb_we;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_io <= '0; en_evt <= '0; pf_q <= 1'b0; plp_evt <= 1'b0; fw_safe <= 1'b0; force_q <= 1'b0;
      auto_wp <= SFS_SYS_PLP_CTRL_RST[2]; plp_events <= '0;
      sec_phys <= 1'b0; sec_lock_mgmt <= 1'b0; sec_lock <= 1'b0; viol_cnt <= '0;
      ras_st <= '0; ras_warn_en <= '0; ras_fatal_en <= '0;
      buf_ce_cnt <= '0; buf_ue_cnt <= '0; buf_err_addr <= '0; nand_ce_cnt <= '0; nand_ue_cnt <= '0; fab_addr <= '0;
      fi_arm_q <= 1'b0; fi_aen_q <= 1'b0; fi_mode_q <= '0; fi_mask_q <= '0; fi_addr_q <= '0;
      pf_freeze <= 1'b0;
      pc_cyc <= '0; pc_cmds <= '0; pc_cpls <= '0; pc_dma <= '0; pc_rd <= '0; pc_pg <= '0; pc_er <= '0;
      pc_busy <= '0; pc_stall <= '0; pc_cqf <= '0; pc_lat <= '0; pc_latmax <= '0;
    end else begin
      // ------------------------------------------------ PLP
      pf_q <= pf_s;
      if (pf_s && !pf_q) begin
        plp_evt <= 1'b1;
        if (plp_events != 32'hFFFF_FFFF) plp_events <= plp_events + 32'd1;
      end
      // ------------------------------------------------ RAS
      ras_st <= ras_st | ras_set;
      if (ev_buf_ce) buf_ce_cnt <= sat(buf_ce_cnt, 32'd1);
      if (ev_buf_ue) buf_ue_cnt <= sat(buf_ue_cnt, 32'd1);
      if (ev_buf_ce || ev_buf_ue) buf_err_addr <= 32'(ev_buf_addr);
      nand_ce_cnt <= sat(nand_ce_cnt, 32'(ev_nand_ce_n));
      nand_ue_cnt <= sat(nand_ue_cnt, 32'(ev_nand_ue_n));
      if (ev_fab_dec) fab_addr <= ev_fab_addr;
      if (ev_sec_viol && viol_cnt != 16'hFFFF) viol_cnt <= viol_cnt + 16'd1;
      fi_arm_q <= 1'b0;                              // pulse
      // ------------------------------------------------ performance
      if (!pf_freeze) begin
        pc_cyc <= pc_cyc + 32'd1;
        if (pe_fetch)     pc_cmds <= pc_cmds + 32'd1;
        if (pe_cpl)       pc_cpls <= pc_cpls + 32'd1;
        if (pe_dma_word)  pc_dma  <= pc_dma + 32'(DMA_DATA_WIDTH / 8);
        pc_rd <= pc_rd + 32'(pe_nand_rd_n);
        pc_pg <= pc_pg + 32'(pe_nand_pg_n);
        pc_er <= pc_er + 32'(pe_nand_er_n);
        if (pe_nand_busy) pc_busy  <= sat(pc_busy, 32'd1);
        if (pe_fab_stall) pc_stall <= sat(pc_stall, 32'd1);
        if (pe_cq_full)   pc_cqf   <= sat(pc_cqf, 32'd1);
        if (pe_lat_valid) begin
          pc_lat <= sat(pc_lat, pe_lat);
          if (pe_lat > pc_latmax) pc_latmax <= pe_lat;
        end
      end
      // ------------------------------------------------ firmware writes
      if (fw_wr) begin
        case (rb_addr)
          SFS_SYS_IRQ_EN_IO:  en_io  <= rb_wdata[5:0];
          SFS_SYS_IRQ_EN_EVT: en_evt <= rb_wdata[5:0];
          SFS_SYS_PLP_CTRL: begin
            if (rb_wdata[0]) fw_safe <= 1'b1;
            force_q <= rb_wdata[1];
            auto_wp <= rb_wdata[2];
            if (rb_wdata[8] && !pf_s) begin
              plp_evt <= 1'b0;
              fw_safe <= 1'b0;
            end
          end
          SFS_SYS_SEC_CTRL: if (!sec_lock) begin
            sec_phys      <= rb_wdata[0];
            sec_lock_mgmt <= rb_wdata[1];
            sec_lock      <= rb_wdata[31];
          end
          SFS_SYS_RAS_STATUS:   ras_st <= (ras_st & ~rb_wdata[9:0]) | ras_set;
          SFS_SYS_RAS_WARN_EN:  ras_warn_en  <= rb_wdata[9:0];
          SFS_SYS_RAS_FATAL_EN: ras_fatal_en <= rb_wdata[9:0];
          SFS_SYS_BUF_FI_CTRL: begin
            fi_arm_q  <= rb_wdata[0] && (ENABLE_RAS != 0);
            fi_mode_q <= rb_wdata[2:1];
            fi_aen_q  <= rb_wdata[3];
          end
          SFS_SYS_BUF_FI_MASK: fi_mask_q <= rb_wdata;
          SFS_SYS_BUF_FI_ADDR: fi_addr_q <= rb_wdata;
          SFS_SYS_PERF_CTRL: begin
            pf_freeze <= rb_wdata[0];
            if (rb_wdata[1]) begin
              pc_cyc <= '0; pc_cmds <= '0; pc_cpls <= '0; pc_dma <= '0; pc_rd <= '0; pc_pg <= '0; pc_er <= '0;
              pc_busy <= '0; pc_stall <= '0; pc_cqf <= '0; pc_lat <= '0; pc_latmax <= '0;
            end
          end
          default: ;
        endcase
      end
    end
  end

  assign phys_en    = sec_phys;
  assign mgmt_lock  = sec_lock_mgmt;
  assign fi_arm     = fi_arm_q;
  assign fi_mode    = fi_mode_q;
  assign fi_mask    = fi_mask_q;
  assign fi_addr_en = fi_aen_q;
  assign fi_addr    = fi_addr_q;

  // ================================================================ protocol version consistency
  if (SFS_PKG_PROTO_VERSION != SFS_PROTO_VERSION) begin : g_bad_proto
    `SFRAS_CFG_FATAL("silicaflux_storage_pkg and sfs_memmap.yaml disagree on the protocol version")
  end

  // ================================================================ read mux
  localparam logic [31:0] CONFIG0 = 32'(NUM_NAND_CHANNELS) | (32'(CHANNEL_DATA_WIDTH / 8) << 8) |
                                    (32'(DMA_DATA_WIDTH / 8) << 12) | (32'(CMD_QUEUE_DEPTH) << 20) |
                                    (32'(ENABLE_ECC != 0) << 28) | (32'(ENABLE_RAS != 0) << 29);
  localparam logic [31:0] CONFIG2 = 32'(NAND_PAGE_BYTES) | (32'(ADDRESS_WIDTH) << 16) |
                                    (32'(HOST_QUEUE_DEPTH) << 24);
  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    case (rb_addr)
      SFS_SYS_ID:             rb_rdata = SFS_SYS_ID_VALUE;
      SFS_SYS_HW_VERSION:     rb_rdata = SFS_HW_VERSION;
      SFS_SYS_PROTO_VERSION:  rb_rdata = SFS_PROTO_VERSION;
      SFS_SYS_MAP_VERSION:    rb_rdata = SFS_MAP_VERSION;
      SFS_SYS_CONFIG0:        rb_rdata = CONFIG0;
      SFS_SYS_CONFIG1:        rb_rdata = 32'(BUFFER_SIZE_BYTES);
      SFS_SYS_CONFIG2:        rb_rdata = CONFIG2;
      SFS_SYS_BUF_BASE:       rb_rdata = SFS_BUF_BASE;
      SFS_SYS_HOSTMEM_BASE:   rb_rdata = SFS_HOSTMEM_BASE;
      SFS_SYS_HOSTMEM_SIZE:   rb_rdata = SFS_HOSTMEM_WIN;
      SFS_SYS_READY:          rb_rdata = {23'h0, pf_s, 2'b0, cmd_idle, hif_rdy, hif_en, dma_idle, nand_idle, buf_ready};
      SFS_SYS_IRQ_STATUS:     rb_rdata = {26'h0, irq_st};
      SFS_SYS_IRQ_EN_IO:      rb_rdata = {26'h0, en_io};
      SFS_SYS_IRQ_EN_EVT:     rb_rdata = {26'h0, en_evt};
      SFS_SYS_PLP_STATUS:     rb_rdata = {26'h0, wp_force, fw_safe, drained, quiesce, plp_evt, pf_s};
      SFS_SYS_PLP_CTRL:       rb_rdata = {29'h0, auto_wp, force_q, fw_safe};
      SFS_SYS_PLP_EVENTS:     rb_rdata = plp_events;
      SFS_SYS_SEC_CTRL:       rb_rdata = {sec_lock, 29'h0, sec_lock_mgmt, sec_phys};
      SFS_SYS_SEC_STATUS:     rb_rdata = {15'h0, 1'b0, viol_cnt};
      SFS_SYS_RAS_STATUS:     rb_rdata = {22'h0, ras_st};
      SFS_SYS_RAS_WARN_EN:    rb_rdata = {22'h0, ras_warn_en};
      SFS_SYS_RAS_FATAL_EN:   rb_rdata = {22'h0, ras_fatal_en};
      SFS_SYS_BUF_CE_COUNT:   rb_rdata = buf_ce_cnt;
      SFS_SYS_BUF_UE_COUNT:   rb_rdata = buf_ue_cnt;
      SFS_SYS_BUF_ERR_ADDR:   rb_rdata = buf_err_addr;
      SFS_SYS_NAND_CE_COUNT:  rb_rdata = nand_ce_cnt;
      SFS_SYS_NAND_UE_COUNT:  rb_rdata = nand_ue_cnt;
      SFS_SYS_BUF_FI_CTRL:    rb_rdata = {28'h0, fi_aen_q, fi_mode_q, fi_armed};
      SFS_SYS_BUF_FI_MASK:    rb_rdata = fi_mask_q;
      SFS_SYS_BUF_FI_ADDR:    rb_rdata = fi_addr_q;
      SFS_SYS_FAB_ERR_ADDR:   rb_rdata = fab_addr;
      SFS_SYS_PERF_CTRL:      rb_rdata = {31'h0, pf_freeze};
      SFS_SYS_PERF_CYCLES:    rb_rdata = pc_cyc;
      SFS_SYS_PERF_HOST_CMDS: rb_rdata = pc_cmds;
      SFS_SYS_PERF_HOST_CPLS: rb_rdata = pc_cpls;
      SFS_SYS_PERF_DMA_BYTES: rb_rdata = pc_dma;
      SFS_SYS_PERF_NAND_RD:   rb_rdata = pc_rd;
      SFS_SYS_PERF_NAND_PG:   rb_rdata = pc_pg;
      SFS_SYS_PERF_NAND_ER:   rb_rdata = pc_er;
      SFS_SYS_PERF_NAND_BUSY: rb_rdata = pc_busy;
      SFS_SYS_PERF_FAB_STALL: rb_rdata = pc_stall;
      SFS_SYS_PERF_CQ_FULL:   rb_rdata = pc_cqf;
      SFS_SYS_PERF_CMD_LAT:   rb_rdata = pc_lat;
      SFS_SYS_PERF_CMD_LATMAX:rb_rdata = pc_latmax;
      default:                rb_err = 1'b1;
    endcase
    // writable registers only
    if (rb_we && !(rb_addr == SFS_SYS_IRQ_EN_IO || rb_addr == SFS_SYS_IRQ_EN_EVT || rb_addr == SFS_SYS_PLP_CTRL ||
                   rb_addr == SFS_SYS_SEC_CTRL || rb_addr == SFS_SYS_RAS_STATUS || rb_addr == SFS_SYS_RAS_WARN_EN ||
                   rb_addr == SFS_SYS_RAS_FATAL_EN || rb_addr == SFS_SYS_BUF_FI_CTRL ||
                   rb_addr == SFS_SYS_BUF_FI_MASK || rb_addr == SFS_SYS_BUF_FI_ADDR ||
                   rb_addr == SFS_SYS_PERF_CTRL)) rb_err = 1'b1;
  end
endmodule

`default_nettype wire
