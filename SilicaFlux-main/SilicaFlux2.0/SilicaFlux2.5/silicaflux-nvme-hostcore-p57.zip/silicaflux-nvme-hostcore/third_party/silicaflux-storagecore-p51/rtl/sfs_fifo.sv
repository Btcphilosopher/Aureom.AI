// =============================================================================
// SilicaFlux StorageCore :: sfs_fifo -- synchronous ready/valid FIFO (flops)
//   in : in_valid / in_ready (= !full), payload in_data
//   out: out_valid (= !empty) / out_ready, payload out_data (head, registered)
//   clr: synchronous flush (controller reset / abort)
// No combinational path from in_* to out_* or from out_ready to in_ready.
// DEPTH >= 2, any value (pointers wrap explicitly).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfs_fifo #(
  parameter int W     = 32,
  parameter int DEPTH = 4,
  localparam int AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int LW   = $clog2(DEPTH + 1)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          clr,
  input  wire logic          in_valid,
  output logic               in_ready,
  input  wire logic [W-1:0]  in_data,
  output logic               out_valid,
  input  wire logic          out_ready,
  output logic [W-1:0]       out_data,
  output logic [LW-1:0]      level
);
  logic [W-1:0]  mem [DEPTH];
  logic [AW-1:0] wp, rp;
  logic [LW-1:0] cnt;

  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;

  assign in_ready  = (cnt != LW'(DEPTH));
  assign out_valid = (cnt != '0);
  assign out_data  = mem[rp];
  assign level     = cnt;

  function automatic logic [AW-1:0] inc(input logic [AW-1:0] p);
    inc = (p == AW'(DEPTH - 1)) ? '0 : p + AW'(1);
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp  <= '0;
      rp  <= '0;
      cnt <= '0;
    end else if (clr) begin
      wp  <= '0;
      rp  <= '0;
      cnt <= '0;
    end else begin
      if (push) wp <= inc(wp);
      if (pop)  rp <= inc(rp);
      case ({push, pop})
        2'b10:   cnt <= cnt + LW'(1);
        2'b01:   cnt <= cnt - LW'(1);
        default: ;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    if (push) mem[wp] <= in_data;
  end
endmodule

`default_nettype wire
