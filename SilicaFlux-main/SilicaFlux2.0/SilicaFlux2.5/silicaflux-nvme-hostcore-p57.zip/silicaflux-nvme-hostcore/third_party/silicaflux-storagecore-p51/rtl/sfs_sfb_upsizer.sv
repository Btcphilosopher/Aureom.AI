// =============================================================================
// SilicaFlux StorageCore :: sfs_sfb_upsizer -- 32-bit SFB2 master -> DW-bit SFB2 slave port
//   Word address aligned down to DW, write data replicated on every 32-bit
//   lane, strobes shifted to the addressed lane; the read lane of the one
//   outstanding transaction (SFB2 R6) is remembered at acceptance.  Purely
//   combinational in the request direction (0 cycles); DW = 32 is a wire.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfs_sfb_upsizer #(
  parameter int DW = 64,
  localparam int SB = DW / 8,
  localparam int NL = DW / 32,
  localparam int LW = (NL > 1) ? $clog2(NL) : 1
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          s_req_valid,
  output logic               s_req_ready,
  input  wire logic          s_req_write,
  input  wire logic [31:0]   s_req_addr,
  input  wire logic [31:0]   s_req_wdata,
  input  wire logic [3:0]    s_req_wstrb,
  output logic               s_rsp_valid,
  input  wire logic          s_rsp_ready,
  output logic [31:0]        s_rsp_rdata,
  output logic               s_rsp_error,
  output logic               m_req_valid,
  input  wire logic          m_req_ready,
  output logic               m_req_write,
  output logic [31:0]        m_req_addr,
  output logic [DW-1:0]      m_req_wdata,
  output logic [SB-1:0]      m_req_wstrb,
  input  wire logic          m_rsp_valid,
  output logic               m_rsp_ready,
  input  wire logic [DW-1:0] m_rsp_rdata,
  input  wire logic          m_rsp_error
);
  assign m_req_valid = s_req_valid;
  assign s_req_ready = m_req_ready;
  assign m_req_write = s_req_write;
  assign s_rsp_valid = m_rsp_valid;
  assign m_rsp_ready = s_rsp_ready;
  assign s_rsp_error = m_rsp_error;
  generate
    if (NL == 1) begin : g_wire
      assign m_req_addr  = s_req_addr;
      assign m_req_wdata = s_req_wdata;
      assign m_req_wstrb = s_req_wstrb;
      assign s_rsp_rdata = m_rsp_rdata[31:0];
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused = clk ^ rst_n;
      /* verilator lint_on UNUSEDSIGNAL */
    end else begin : g_up
      localparam int OFF = $clog2(SB);
      wire [LW-1:0] lane = s_req_addr[2 +: LW];
      logic [LW-1:0] lane_q;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)                          lane_q <= '0;
        else if (s_req_valid && s_req_ready) lane_q <= lane;
      end
      assign m_req_addr  = {s_req_addr[31:OFF], OFF'(0)};
      assign m_req_wdata = {NL{s_req_wdata}};
      assign m_req_wstrb = SB'(s_req_wstrb) << (lane * 4);
      assign s_rsp_rdata = m_rsp_rdata[lane_q*32 +: 32];
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_lo = ^s_req_addr[1:0];      // byte offset inside the 32-bit lane: strobes carry it
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate
endmodule

`default_nettype wire
