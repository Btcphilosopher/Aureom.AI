// =============================================================================
// SilicaFlux StorageCore :: sfs_dma -- storage DMA (descriptor queue, tagged completions)
//
// Firmware stages SRC / DST / LEN and writes SUBMIT(tag); descriptors are
// executed in order by one SFB2 master of width DW (= DMA_DATA_WIDTH):
//   read word (src) -> write word (dst), DW-aligned, LEN a multiple of DW/8.
// Typical use: host memory window <-> buffer SRAM (both on the storage fabric).
// Each descriptor produces exactly one completion {tag, status, info} in the
// completion queue (CPL_HEAD / CPL_INFO / CPL_POP): OK (info = bytes),
// READ_ERR / WRITE_ERR (info = faulting address, transfer stopped there),
// INVALID (length 0 / misaligned, nothing transferred), ABORTED (CTRL.ABORT:
// the running descriptor stops at a word boundary, queued ones are flushed).
// The engine waits for completion-queue space before finishing a descriptor
// (back-pressure; nothing is lost).  SFB2 rules: one transaction outstanding,
// request held until accepted, rsp_ready = 1.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfs_dma
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
#(
  parameter int DW = 32,
  parameter int QD = 4,             // descriptor queue depth
  parameter int CD = 4,             // completion queue depth
  localparam int SB  = DW / 8,
  localparam int OFF = $clog2(SB)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // firmware page (DMA)
  input  wire logic          rb_sel,
  input  wire logic          rb_we,
  input  wire logic [11:0]   rb_addr,
  input  wire logic [31:0]   rb_wdata,
  output logic [31:0]        rb_rdata,
  output logic               rb_err,
  // SFB2 master
  output logic               m_req_valid,
  input  wire logic          m_req_ready,
  output logic               m_req_write,
  output logic [31:0]        m_req_addr,
  output logic [DW-1:0]      m_req_wdata,
  output logic [SB-1:0]      m_req_wstrb,
  input  wire logic          m_rsp_valid,
  output logic               m_rsp_ready,
  input  wire logic [DW-1:0] m_rsp_rdata,
  input  wire logic          m_rsp_error,
  // status / events
  output logic               irq_dma,
  output logic               busy,
  output logic               ev_word,       // one DW word written
  output logic               ev_err,        // descriptor ended with a bus error
  output logic               ev_fw_err      // SUBMIT while full
);
  // ================================================================ queues
  localparam int DQW = 8 + 3 * 32;
  logic           dq_in_ready, dq_out_valid, dq_pop;
  logic [DQW-1:0] dq_head;
  logic [$clog2(QD+1)-1:0] dq_level;
  logic           cq_in_valid, cq_in_ready, cq_out_valid, cq_pop;
  logic [47:0]    cq_in, cq_head;
  logic [$clog2(CD+1)-1:0] cq_level;
  logic [31:0]    r_src, r_dst, r_len;
  logic           ovf, abort_req;
  logic [31:0]    n_bytes, n_desc, n_err;

  wire fw_wr  = rb_sel && rb_we;
  wire submit = fw_wr && rb_addr == SFS_DMA_SUBMIT;
  assign ev_fw_err = submit && !dq_in_ready;

  sfs_fifo #(.W(DQW), .DEPTH(QD)) u_dq (
    .clk, .rst_n, .clr(1'b0),
    .in_valid(submit), .in_ready(dq_in_ready), .in_data({rb_wdata[7:0], r_src, r_dst, r_len}),
    .out_valid(dq_out_valid), .out_ready(dq_pop), .out_data(dq_head), .level(dq_level)
  );
  sfs_fifo #(.W(48), .DEPTH(CD)) u_cq (
    .clk, .rst_n, .clr(1'b0),
    .in_valid(cq_in_valid), .in_ready(cq_in_ready), .in_data(cq_in),
    .out_valid(cq_out_valid), .out_ready(cq_pop), .out_data(cq_head), .level(cq_level)
  );
  assign cq_pop = fw_wr && rb_addr == SFS_DMA_CPL_POP && cq_out_valid;

  // ================================================================ engine
  typedef enum logic [2:0] { S_IDLE, S_RD, S_RDW, S_WR, S_WRW, S_DONE } st_e;
  st_e st;
  logic [7:0]    tag;
  logic [31:0]   src, dst, len, done_b, info;
  logic [7:0]    dstat;
  logic [DW-1:0] data;

  wire [31:0] h_src = dq_head[95:64];
  wire [31:0] h_dst = dq_head[63:32];
  wire [31:0] h_len = dq_head[31:0];
  wire        h_bad = (h_len == 32'd0) || (h_len[OFF-1:0] != '0) || (h_src[OFF-1:0] != '0) || (h_dst[OFF-1:0] != '0);
  assign dq_pop = (st == S_IDLE) && dq_out_valid;

  assign m_req_valid = (st == S_RD) || (st == S_WR);
  assign m_req_write = (st == S_WR);
  assign m_req_addr  = (st == S_WR) ? dst : src;
  assign m_req_wdata = data;
  assign m_req_wstrb = {SB{1'b1}};
  assign m_rsp_ready = 1'b1;
  wire rsp = m_rsp_valid;

  assign cq_in_valid = (st == S_DONE);
  assign cq_in       = {tag, dstat, info};
  assign busy        = (st != S_IDLE) || dq_out_valid;
  assign irq_dma     = cq_out_valid;
  assign ev_word     = (st == S_WRW) && rsp && !m_rsp_error;
  assign ev_err      = (st == S_DONE) && cq_in_ready && (dstat == 8'(SFS_DST_READ_ERR) || dstat == 8'(SFS_DST_WRITE_ERR));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; tag <= '0; src <= '0; dst <= '0; len <= '0; done_b <= '0; info <= '0; dstat <= '0;
      data <= '0; n_bytes <= '0; n_desc <= '0; n_err <= '0;
    end else begin
      case (st)
        S_IDLE: if (dq_out_valid) begin
          tag <= dq_head[DQW-1 -: 8];
          src <= h_src; dst <= h_dst; len <= h_len; done_b <= '0;
          if (abort_req) begin
            dstat <= 8'(SFS_DST_ABORTED); info <= '0; st <= S_DONE;
          end else if (h_bad) begin
            dstat <= 8'(SFS_DST_INVALID); info <= '0; st <= S_DONE;
          end else begin
            st <= S_RD;
          end
        end
        S_RD: if (m_req_ready) st <= S_RDW;     // a presented request is never withdrawn (SFB2 R2)
        S_RDW: if (rsp) begin
          if (m_rsp_error) begin
            dstat <= 8'(SFS_DST_READ_ERR); info <= src; st <= S_DONE;
          end else begin
            data <= m_rsp_rdata; st <= S_WR;
          end
        end
        S_WR: if (m_req_ready) st <= S_WRW;
        S_WRW: if (rsp) begin
          if (m_rsp_error) begin
            dstat <= 8'(SFS_DST_WRITE_ERR); info <= dst; st <= S_DONE;
          end else begin
            n_bytes <= n_bytes + 32'(SB);
            src <= src + 32'(SB); dst <= dst + 32'(SB); done_b <= done_b + 32'(SB);
            if (done_b + 32'(SB) == len) begin
              dstat <= 8'(SFS_DST_OK); info <= len; st <= S_DONE;
            end else if (abort_req) begin
              dstat <= 8'(SFS_DST_ABORTED); info <= done_b + 32'(SB); st <= S_DONE;
            end else st <= S_RD;
          end
        end
        S_DONE: if (cq_in_ready) begin
          n_desc <= n_desc + 32'd1;
          if (dstat != 8'(SFS_DST_OK)) n_err <= n_err + 32'd1;
          st <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
    end
  end

  // ================================================================ registers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_src <= '0; r_dst <= '0; r_len <= '0; ovf <= 1'b0; abort_req <= 1'b0;
    end else begin
      if (ev_fw_err) ovf <= 1'b1;
      if (fw_wr) begin
        case (rb_addr)
          SFS_DMA_SRC: r_src <= rb_wdata;
          SFS_DMA_DST: r_dst <= rb_wdata;
          SFS_DMA_LEN: r_len <= rb_wdata;
          SFS_DMA_CTRL: begin
            if (rb_wdata[0]) abort_req <= 1'b1;
            if (rb_wdata[1] && !ev_fw_err) ovf <= 1'b0;
          end
          default: ;
        endcase
      end
      // abort completes once the queue is flushed and the engine is idle
      if (abort_req && st == S_IDLE && !dq_out_valid && !(fw_wr && rb_addr == SFS_DMA_CTRL)) abort_req <= 1'b0;
    end
  end

  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    case (rb_addr)
      SFS_DMA_INFO:     rb_rdata = {8'h0, 8'(SB), 8'(CD), 8'(QD)};
      SFS_DMA_STATUS:   rb_rdata = {7'h0, ovf, 4'h0, 4'(cq_level), 4'(QD - 32'(dq_level)), 4'(dq_level), 7'h0, busy};
      SFS_DMA_CTRL:     rb_rdata = {31'h0, abort_req};
      SFS_DMA_SRC:      rb_rdata = r_src;
      SFS_DMA_DST:      rb_rdata = r_dst;
      SFS_DMA_LEN:      rb_rdata = r_len;
      SFS_DMA_SUBMIT:   rb_rdata = 32'h0;
      SFS_DMA_CPL_HEAD: rb_rdata = {cq_out_valid, 7'h0, cq_head[47:40], cq_head[39:32], 8'h0};
      SFS_DMA_CPL_INFO: rb_rdata = cq_head[31:0];
      SFS_DMA_CPL_POP:  rb_rdata = 32'h0;
      SFS_DMA_BYTES:    rb_rdata = n_bytes;
      SFS_DMA_DESCS:    rb_rdata = n_desc;
      SFS_DMA_ERRORS:   rb_rdata = n_err;
      default:          rb_err = 1'b1;
    endcase
    if (rb_we && (rb_addr == SFS_DMA_INFO || rb_addr == SFS_DMA_STATUS || rb_addr == SFS_DMA_CPL_HEAD ||
                  rb_addr == SFS_DMA_CPL_INFO || rb_addr == SFS_DMA_BYTES || rb_addr == SFS_DMA_DESCS ||
                  rb_addr == SFS_DMA_ERRORS)) rb_err = 1'b1;
  end
endmodule

`default_nettype wire
