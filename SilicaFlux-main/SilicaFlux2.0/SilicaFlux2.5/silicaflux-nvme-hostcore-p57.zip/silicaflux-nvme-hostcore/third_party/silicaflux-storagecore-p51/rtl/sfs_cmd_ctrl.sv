// =============================================================================
// SilicaFlux StorageCore :: sfs_cmd_ctrl -- command controller
//
//   cmd (sfs_cmd_t, ready/valid) from the host interface
//     -> hardware validation (opcode, reserved fields, address type / policy,
//        ADDRESS_WIDTH, LEN, MDTS, host buffer window/alignment, capacity,
//        transaction-ID conflict, power-loss / reset quiescence)
//     -> invalid : completed by hardware (reject FIFO), firmware never sees it
//     -> valid   : tag allocated (CMD_QUEUE_DEPTH tags), command stored in the
//                  tag table, tag pushed into the firmware command queue (FWQ)
//     -> no free tag: cmd_ready = 0 (back-pressure into the SQ)
//   Firmware (ControlCore page 11): FWQ_HEAD / FWQ_POP, reads the command from
//   the tag window, executes it, posts {tag, status, error, result0/1} with
//   CPL_POST.  Only a tag the firmware popped and has not completed may be
//   posted (else STATUS.FW_ERR + RAS FW_PROTO, ignored).
//   cpl (sfs_cpl_t, ready/valid) to the host interface: round-robin between
//   hardware rejections and firmware completions; the TID comes from the tag
//   table, so a completion is always tagged with its own command's TID.  The
//   tag is freed when its completion is accepted.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfs_cmd_ctrl
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
#(
  parameter int CMD_QUEUE_DEPTH = 8,
  parameter int ADDRESS_WIDTH   = 32,
  parameter int HBUF_ALIGN      = 4,         // host buffer alignment in bytes (= DMA_DATA_WIDTH / 8)
  parameter int MDTS_RESET      = 16,
  localparam int NT  = CMD_QUEUE_DEPTH,
  localparam int TW  = (NT > 1) ? $clog2(NT) : 1,
  localparam int CB  = SFS_CMD_BITS,
  localparam int LW  = $clog2(NT + 1)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // ---------------------------------------------------------------- command / completion channels
  input  wire logic        cmd_valid,
  output logic             cmd_ready,
  input  wire sfs_cmd_t    cmd,
  output logic             cpl_valid,
  input  wire logic        cpl_ready,
  output sfs_cpl_t         cpl,
  // ---------------------------------------------------------------- firmware page (CMD)
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // ---------------------------------------------------------------- policy / state inputs
  input  wire logic        phys_en,
  input  wire logic        plp_quiesce,
  input  wire logic        resetting,
  // ---------------------------------------------------------------- outputs
  output logic [63:0]      capacity,
  output logic [15:0]      mdts,
  output logic             outstanding_zero,
  output logic             irq_cmd,
  output logic             ev_fw_err,
  output logic             ev_lat_valid,
  output logic [31:0]      ev_lat
);
  // ================================================================ tag table
  logic [CB-1:0] tt     [NT];
  logic [31:0]   tt_ts  [NT];
  logic [15:0]   tt_tid [NT];
  logic [NT-1:0] busy, fw_own;
  logic [31:0]   now;
  logic [31:0]   res0, res1, n_acc, n_rej, n_cpl, n_drop, last_rej;
  logic [63:0]   cap;
  logic [15:0]   mdts_q;
  logic          st_fw_err, st_dropped;

  // free tag (lowest index)
  logic          have_free;
  logic [TW-1:0] free_tag;
  always_comb begin
    have_free = 1'b0;
    free_tag  = '0;
    for (int i = NT - 1; i >= 0; i--) if (!busy[i]) begin have_free = 1'b1; free_tag = TW'(i); end
  end

  // ================================================================ validation
  logic [6:0] v_st;
  logic [7:0] v_err;
  logic       conflict;
  logic [31:0] hbytes;
  logic [64:0] lba_end;
  logic        addr_hi_bad;
  always_comb begin
    conflict = 1'b0;
    for (int i = 0; i < NT; i++) if (busy[i] && tt_tid[i] == cmd.tid) conflict = 1'b1;
    hbytes  = (cmd.opcode == SFS_OP_READ || cmd.opcode == SFS_OP_WRITE) ? (cmd.len << 9) : 32'd512;
    lba_end = {1'b0, cmd.addr} + {33'd0, cmd.len};
    addr_hi_bad = (ADDRESS_WIDTH < 64) ? ((cmd.addr >> ADDRESS_WIDTH) != 64'd0) : 1'b0;
    v_st  = SFS_ST_SUCCESS;
    v_err = SFS_ERR_NONE;
    if (!sfs_op_supported(cmd.opcode)) begin
      v_st = SFS_ST_INVALID_OPCODE;
    end else if ((cmd.flags & SFS_FLAG_RSVD) != 8'h0 || cmd.rsvd != 32'h0) begin
      v_st = SFS_ST_INVALID_FIELD;  v_err = SFS_ERR_RSVD_FIELD;
    end else if (plp_quiesce) begin
      v_st = SFS_ST_ABORT_PWR_LOSS; v_err = SFS_ERR_QUIESCED;
    end else if (resetting) begin
      v_st = SFS_ST_ABORT_RESET;    v_err = SFS_ERR_NOT_READY;
    end else if (cmd.addr_type == SFS_ADDR_PHYSICAL &&
                 !(cmd.opcode == SFS_OP_READ || cmd.opcode == SFS_OP_WRITE || cmd.opcode == SFS_OP_ERASE)) begin
      v_st = SFS_ST_INVALID_FIELD;  v_err = SFS_ERR_ADDR_TYPE;
    end else if (cmd.opcode == SFS_OP_ERASE && cmd.addr_type == SFS_ADDR_LOGICAL) begin
      v_st = SFS_ST_INVALID_FIELD;  v_err = SFS_ERR_ADDR_TYPE;
    end else if (cmd.addr_type == SFS_ADDR_PHYSICAL && !phys_en) begin
      v_st = SFS_ST_ACCESS_DENIED;  v_err = SFS_ERR_ADDR_TYPE;
    end else if ((sfs_op_ranged(cmd.opcode) || cmd.addr_type == SFS_ADDR_PHYSICAL) && addr_hi_bad) begin
      v_st = SFS_ST_INVALID_FIELD;  v_err = SFS_ERR_ADDR_WIDTH;
    end else if ((sfs_op_ranged(cmd.opcode) || cmd.opcode == SFS_OP_ERASE) && cmd.len == 32'd0) begin
      v_st = SFS_ST_INVALID_FIELD;  v_err = SFS_ERR_LEN_ZERO;
    end else if ((cmd.opcode == SFS_OP_READ || cmd.opcode == SFS_OP_WRITE || cmd.opcode == SFS_OP_ERASE) &&
                 cmd.len > 32'(mdts_q)) begin
      v_st = SFS_ST_INVALID_FIELD;  v_err = SFS_ERR_LEN_MAX;
    end else if (sfs_op_has_hbuf(cmd.opcode) &&
                 ((cmd.host_addr[63:32] != 32'h0) || (cmd.host_addr[31:0] % HBUF_ALIGN != 0) ||
                  ({1'b0, cmd.host_addr[31:0]} + {1'b0, hbytes} > {1'b0, SFS_HOSTMEM_WIN}))) begin
      v_st = SFS_ST_INVALID_FIELD;  v_err = SFS_ERR_HOST_ADDR;
    end else if (sfs_op_ranged(cmd.opcode) && cmd.addr_type == SFS_ADDR_LOGICAL && lba_end > {1'b0, cap}) begin
      v_st = SFS_ST_LBA_RANGE;      v_err = SFS_ERR_NONE;
    end else if (conflict) begin
      v_st = SFS_ST_CID_CONFLICT;   v_err = SFS_ERR_NONE;
    end
  end
  wire v_ok = (v_st == SFS_ST_SUCCESS);

  // ================================================================ queues
  // firmware command queue (tags)
  logic          fwq_in_ready, fwq_out_valid, fwq_pop;
  logic [TW-1:0] fwq_head;
  logic [LW-1:0] fwq_level;
  // reject FIFO {tid, status, err}
  logic          rq_in_ready, rq_out_valid, rq_pop;
  logic [30:0]   rq_head;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [1:0]    rq_level;
  /* verilator lint_on UNUSEDSIGNAL */
  // firmware completion FIFO {tag, status, err, res0, res1}
  localparam int FCW = TW + 7 + 8 + 64;
  logic           fc_in_valid, fc_in_ready, fc_out_valid, fc_pop;
  logic [FCW-1:0] fc_in, fc_head;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [LW-1:0]  fc_level;
  /* verilator lint_on UNUSEDSIGNAL */

  wire accept = cmd_valid && v_ok && have_free;
  wire reject = cmd_valid && !v_ok;
  assign cmd_ready = v_ok ? have_free : rq_in_ready;
  wire cmd_hs = cmd_valid && cmd_ready;

  sfs_fifo #(.W(TW), .DEPTH(NT)) u_fwq (
    .clk, .rst_n, .clr(1'b0),
    .in_valid(cmd_hs && v_ok), .in_ready(fwq_in_ready), .in_data(free_tag),
    .out_valid(fwq_out_valid), .out_ready(fwq_pop), .out_data(fwq_head), .level(fwq_level)
  );
  sfs_fifo #(.W(31), .DEPTH(2)) u_rq (
    .clk, .rst_n, .clr(1'b0),
    .in_valid(cmd_hs && !v_ok), .in_ready(rq_in_ready), .in_data({cmd.tid, v_st, v_err}),
    .out_valid(rq_out_valid), .out_ready(rq_pop), .out_data(rq_head), .level(rq_level)
  );
  sfs_fifo #(.W(FCW), .DEPTH(NT)) u_fc (
    .clk, .rst_n, .clr(1'b0),
    .in_valid(fc_in_valid), .in_ready(fc_in_ready), .in_data(fc_in),
    .out_valid(fc_out_valid), .out_ready(fc_pop), .out_data(fc_head), .level(fc_level)
  );

  // ================================================================ completion output (round robin, choice locked while stalled)
  logic rr, lock_v, lock_sel;
  wire  sel_rej = lock_v ? lock_sel : (rq_out_valid && (!fc_out_valid || rr));
  assign cpl_valid = rq_out_valid || fc_out_valid;
  wire  cpl_hs  = cpl_valid && cpl_ready;
  assign rq_pop = cpl_hs && sel_rej;
  assign fc_pop = cpl_hs && !sel_rej;

  wire [TW-1:0] fc_tag  = fc_head[FCW-1 -: TW];
  wire [6:0]    fc_st   = fc_head[64 + 8 +: 7];
  wire [7:0]    fc_err  = fc_head[64 +: 8];
  always_comb begin
    if (sel_rej) begin
      cpl.tid     = rq_head[30:15];
      cpl.status  = rq_head[14:8];
      cpl.err     = rq_head[7:0];
      cpl.result0 = 32'h0;
      cpl.result1 = 32'h0;
    end else begin
      cpl.tid     = tt_tid[fc_tag];
      cpl.status  = fc_st;
      cpl.err     = fc_err;
      cpl.result0 = fc_head[63:32];
      cpl.result1 = fc_head[31:0];
    end
  end

  // ================================================================ firmware register page
  wire fw_wr = rb_sel && rb_we;
  wire fw_rd = rb_sel && !rb_we;
  wire in_tagwin = (rb_addr >= SFS_CMD_TAG_WIN) && (rb_addr < SFS_CMD_TAG_WIN + 12'(NT * SFS_CMD_TAG_STRIDE));
  wire [11:0] tw_off = rb_addr - SFS_CMD_TAG_WIN;
  wire [TW-1:0] tw_tag = tw_off[5 +: TW];
  wire [2:0]    tw_word = tw_off[4:2];
  logic [SFS_SQE_W*32-1:0] tw_sqe;
  assign tw_sqe = sfs_sqe_pack(tt[tw_tag]);

  wire [TW-1:0] post_tag = rb_wdata[TW-1:0];
  wire post     = fw_wr && rb_addr == SFS_CMD_CPL_POST;
  wire post_ok  = post && (rb_wdata[7:0] < 8'(NT)) && busy[post_tag] && fw_own[post_tag] && fc_in_ready;
  wire pop_req  = fw_wr && rb_addr == SFS_CMD_FWQ_POP;
  assign fwq_pop     = pop_req && fwq_out_valid;
  assign fc_in_valid = post_ok;
  assign fc_in       = {post_tag, rb_wdata[14:8], rb_wdata[23:16], res0, res1};
  assign ev_fw_err   = (post && !post_ok) || (pop_req && !fwq_out_valid);

  logic [5:0] busy_cnt;
  always_comb begin
    busy_cnt = '0;
    for (int i = 0; i < NT; i++) busy_cnt = busy_cnt + 6'(busy[i]);
  end

  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    if (in_tagwin) begin
      rb_rdata = tw_sqe[tw_word*32 +: 32];
      if (rb_we) rb_err = 1'b1;
    end else begin
      case (rb_addr)
        SFS_CMD_INFO:        rb_rdata = {8'h0, 8'(fwq_level), 8'(busy_cnt), 8'(NT)};
        SFS_CMD_FWQ_HEAD:    rb_rdata = {fwq_out_valid, 23'h0, 8'(fwq_head)};
        SFS_CMD_FWQ_POP:     rb_rdata = 32'h0;
        SFS_CMD_CPL_RESULT0: rb_rdata = res0;
        SFS_CMD_CPL_RESULT1: rb_rdata = res1;
        SFS_CMD_CPL_POST:    rb_rdata = 32'h0;
        SFS_CMD_STATUS:      rb_rdata = {30'h0, st_dropped, st_fw_err};
        SFS_CMD_IRQ_EN:      rb_rdata = 32'h0;
        SFS_CMD_TAGS_BUSY:   rb_rdata = 32'(busy);
        SFS_CMD_MDTS:        rb_rdata = {16'h0, mdts_q};
        SFS_CMD_CAP_LO:      rb_rdata = cap[31:0];
        SFS_CMD_CAP_HI:      rb_rdata = cap[63:32];
        SFS_CMD_ACCEPTED:    rb_rdata = n_acc;
        SFS_CMD_REJECTED:    rb_rdata = n_rej;
        SFS_CMD_COMPLETED:   rb_rdata = n_cpl;
        SFS_CMD_DROPPED:     rb_rdata = n_drop;
        SFS_CMD_LAST_REJECT: rb_rdata = last_rej;
        default:             rb_err = 1'b1;
      endcase
      // write-only registers read as 0; read-only registers refuse writes
      if (rb_we && (rb_addr == SFS_CMD_INFO || rb_addr == SFS_CMD_FWQ_HEAD || rb_addr == SFS_CMD_TAGS_BUSY ||
                    rb_addr == SFS_CMD_ACCEPTED || rb_addr == SFS_CMD_REJECTED || rb_addr == SFS_CMD_COMPLETED ||
                    rb_addr == SFS_CMD_DROPPED || rb_addr == SFS_CMD_LAST_REJECT)) rb_err = 1'b1;
    end
  end
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_rd = fw_rd ^ ^tw_off[11:8] ^ ^tw_off[1:0];
  /* verilator lint_on UNUSEDSIGNAL */

  // ================================================================ sequential
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= '0; fw_own <= '0; now <= '0;
      res0 <= '0; res1 <= '0; n_acc <= '0; n_rej <= '0; n_cpl <= '0; n_drop <= '0; last_rej <= '0;
      cap <= '0; mdts_q <= 16'(MDTS_RESET); st_fw_err <= 1'b0; st_dropped <= 1'b0;
      rr <= 1'b0; lock_v <= 1'b0; lock_sel <= 1'b0;
    end else begin
      now <= now + 32'd1;
      if (cmd_hs && v_ok) begin
        busy[free_tag]  <= 1'b1;
        n_acc <= n_acc + 32'd1;
      end
      if (cmd_hs && !v_ok) begin
        n_rej    <= n_rej + 32'd1;
        last_rej <= {v_err, 1'b0, v_st, cmd.tid};
      end
      if (fwq_pop) fw_own[fwq_head] <= 1'b1;
      if (post_ok) fw_own[post_tag] <= 1'b0;
      if (fc_pop) begin
        busy[fc_tag] <= 1'b0;
        n_cpl <= n_cpl + 32'd1;
        if (resetting) begin
          n_drop <= n_drop + 32'd1;
          st_dropped <= 1'b1;
        end
      end
      if (rq_pop && resetting) n_drop <= n_drop + 32'd1;
      // completion arbitration state
      if (cpl_hs) begin
        rr     <= !sel_rej;
        lock_v <= 1'b0;
      end else if (cpl_valid) begin
        lock_v   <= 1'b1;
        lock_sel <= sel_rej;
      end
      if (ev_fw_err) st_fw_err <= 1'b1;
      if (fw_wr) begin
        case (rb_addr)
          SFS_CMD_CPL_RESULT0: res0 <= rb_wdata;
          SFS_CMD_CPL_RESULT1: res1 <= rb_wdata;
          SFS_CMD_STATUS: begin
            if (rb_wdata[0] && !ev_fw_err) st_fw_err <= 1'b0;
            if (rb_wdata[1]) st_dropped <= 1'b0;
          end
          SFS_CMD_MDTS:   mdts_q <= (rb_wdata[15:0] == 16'h0) ? 16'h1 : rb_wdata[15:0];
          SFS_CMD_CAP_LO: cap[31:0]  <= rb_wdata;
          SFS_CMD_CAP_HI: cap[63:32] <= rb_wdata;
          default: ;
        endcase
      end
    end
  end

`ifndef SYNTHESIS
  initial if ($bits(sfs_cmd_t) != SFS_CMD_BITS || $bits(sfs_cpl_t) != SFS_CPL_BITS)
    $fatal(1, "silicaflux_storage_pkg: SFS_CMD_BITS / SFS_CPL_BITS disagree with the struct widths");
`endif

  always_ff @(posedge clk) begin
    if (cmd_hs && v_ok) begin
      tt[free_tag]    <= CB'(cmd);
      tt_ts[free_tag] <= now;
      tt_tid[free_tag] <= cmd.tid;
    end
  end

  assign capacity         = cap;
  assign mdts             = mdts_q;
  assign outstanding_zero = (busy == '0) && !rq_out_valid;
  assign irq_cmd          = fwq_out_valid;
  assign ev_lat_valid     = fc_pop;
  assign ev_lat           = now - tt_ts[fc_tag];

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = fwq_in_ready ^ accept ^ reject;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
