# 03 — Command subset, validation and status codes

Status notation: `SCT/SC` (hex), `+DNR` when Do Not Retry is set. Every row is exercised by `tb/unit` (docs/08);
rows marked **SoC** also run against the P51 firmware / FTL / NAND.

## 1. Admin commands

| Opc | Command | Phase | Implemented behaviour |
|---|---|---|---|
| 06h | Identify | baseline | CNS 00h (namespace, NSID 1), 01h (controller), 02h (active NSID list), 03h (NS ID descriptor list: empty). Other CNS → `0/02+DNR`. CNS 00h/03h with NSID ≠ 1, CNS 02h with NSID ≥ FFFFFFFEh → `0/0B+DNR`. 4096 bytes through PRP1 (+PRP2 when PRP1 has an offset) |
| 01h | Create I/O SQ | baseline | QID 1..NUM_IOQ and free else `1/01`; QSIZE 1..MQES else `1/02`; PC = 0 or CC.IOSQES ≠ 6 → `0/02`; CQID 0 / > NUM_IOQ / not created → `1/00`; PRP1 not page aligned → `0/13`; base + size wraps 2^64 → `0/02`. QPRIO ignored (round robin) |
| 05h | Create I/O CQ | baseline | as above (`1/01`, `1/02`, `0/02`, `0/13`); IV ≥ NUM_VEC → `1/08`; IEN honoured; CC.IOCQES must be 4 |
| 00h | Delete I/O SQ | baseline | QID invalid / absent → `1/01`; otherwise the SQ stops being fetched, in-flight commands of that SQ complete normally, then the SQ is deleted and the Delete completes |
| 04h | Delete I/O CQ | baseline | QID invalid / absent → `1/01`; an SQ still mapped to it → `1/0C` (Invalid Queue Deletion) |
| 02h | Get Log Page | baseline | LID 01h Error Information (NERR × 64 B), 02h SMART / Health (512 B), 03h Firmware Slot (512 B), C0h vendor performance counters (512 B). Other LID → `1/09`. NSID must be 0 or FFFFFFFFh (no per-namespace logs) else `0/02`; LPO DW-aligned and < log size else `0/02`; NUMDL/NUMDU honoured (length beyond the log is zero-filled), > MDTS → `0/02`. Reading log 01h with RAE = 0 re-enables error-type asynchronous events |
| 09h | Set Features | phase 2 | FID 07h Number of Queues: always reports NSQA = NCQA = NUM_IOQ−1 (all implemented queue pairs — the specification lets a controller allocate a different number than requested; creation of a queue ID above NUM_IOQ fails with `1/01`); after any I/O queue exists → `0/0C` (Command Sequence Error); NSQR/NCQR = FFFFh → `0/02`. FID 06h Volatile Write Cache: WCE; **WCE = 0 makes every write FUA** (the back end commits each write). SV = 1 → `1/0D`. Other FIDs → `0/02` |
| 0Ah | Get Features | phase 2 | FID 07h, 06h with SEL 0 (current), 1 (default), 2 (saved = default), 3 (capabilities: VWC changeable). Other FIDs / SEL > 3 → `0/02` |
| 08h | Abort | phase 2 | best effort: always completes with DW0 bit 0 = 1 ("command not aborted"), which the specification permits |
| 0Ch | Asynchronous Event Request | phase 2 | up to AERL+1 (2) outstanding, more → `1/05`. Events: error status, AEI 01h invalid doorbell register, 02h invalid doorbell write value, log 01h. After one is reported, error events are masked until log 01h is read with RAE = 0. Outstanding AERs are dropped by a controller reset (no completion), as specified |
| others | — | — | `0/01+DNR` (Invalid Command Opcode) |

"Phase 2" commands were added after the baseline subset was validated; `ENABLE_EXT_ADMIN = 0` builds the baseline
only (configuration `noext`, regressed separately), in which they return Invalid Command Opcode.

## 2. NVM I/O commands

| Opc | Command | Implemented behaviour |
|---|---|---|
| 02h | Read | NSID must be 1 (else `0/0B+DNR`); DTYPE ≠ 0 → `0/02` (no directives); (NLB+1)·512 > MDTS → `0/02`; SLBA + NLB + 1 > NSZE (65-bit compare, wrap included) → `0/80+DNR`; PRP checks (§3); then the back end. LR, PRINFO, DSM, STC fields ignored (no protection information format) |
| 01h | Write | as Read; FUA (CDW12 bit 30) passed to the back end (P51: FTL checkpoint after the write) |
| 00h | Flush | NSID 1 or FFFFFFFFh (Identify VWC bits 2:1 = 11b), else `0/0B`; back end commits the volatile state (P51: FTL checkpoint) — **SoC** |
| others | — | `0/01+DNR` (Write Uncorrectable, Compare, Write Zeroes, Dataset Management, … not supported; Identify ONCS = 0) |

Common checks for every command: FUSE ≠ 00b → `0/02` (no fused operations, FUSES = 0); PSDT ≠ 00b → `0/02`
(no SGL, SGLS = 0); a CID equal to one still in flight on the same SQ → `0/03` (Command ID Conflict).

## 3. Data pointer checks (PRP)

PRP1 bits 1:0 ≠ 0 → `0/13` (PRP Offset Invalid). Two-page transfers: PRP2 must be page aligned → `0/13`. Longer
transfers: PRP2 must be QW aligned (list pointer) → `0/13`; every list entry must be page aligned → `0/13`; the last
slot of a list page is followed as a chain pointer when more entries are needed. A list read failing on the bus →
`0/04`. Details: docs/05.

## 4. Back-end status mapping (P51 `sfs_status_e` → NVMe)

| P51 status | NVMe status | DNR |
|---|---|---|
| SUCCESS | `0/00` | – |
| INVALID_FIELD | `0/02` Invalid Field in Command | 1 |
| DATA_XFER_ERR | `0/04` Data Transfer Error | 0 |
| ABORT_PWR_LOSS | `0/05` Commands Aborted due to Power Loss Notification — **SoC** | 0 |
| LBA_RANGE | `0/80` LBA Out of Range | 1 |
| CAPACITY | `0/81` Capacity Exceeded | 1 |
| ACCESS_DENIED | `2/86` Access Denied | 1 |
| MEDIA_UNREC | `2/81` Unrecovered Read Error — **SoC** (2-bit SECDED error) | 1 |
| MEDIA_WRITE / MEDIA_ERASE | `2/80` Write Fault | 1 |
| MEDIA_TIMEOUT | `2/81` (Read) / `2/80` (Write, Flush) | 0 |
| anything else | `0/06` Internal Error | 0 |

Completions that arrive for a context that no longer waits for them (stale generation, controller reset) are
dropped and counted (vendor log C0h, counter 27).

## 5. Identify data (fields not listed read 0)

**Controller (CNS 01h):** VID / SSVID = parameters (placeholders FFFEh); SN `SFP57-SIM-0000000001`; MN `SilicaFlux
NVMe HostCore P57 (sim)`; FR `P57-0100`; MDTS = log2(min(front-end, back-end transfer) / 4 KiB) (P51: 1 = 8 KiB);
CNTLID 0; VER 1.4.0; CNTRLTYPE 1 (I/O); OACS 0; ACL 0; AERL 1 (0 in the baseline build — see docs/10); FRMW 03h (one
read-only slot); LPA 04h (extended Get Log Page data); ELPE NERR−1; NPSS 0; WCTEMP = CCTEMP = 0 (no sensor: "not
reported"); SQES 66h; CQES 44h; NN 1; ONCS 0; FUSES 0; VWC 07h; AWUN = AWUPF = 0; SGLS 0; SUBNQN
`nqn.2026-11.ai.aureom:silicaflux-p57:sim-00001` (placeholder in the project owner's domain); power state 0 all
zero (power not characterised).

**Namespace (CNS 00h, NSID 1):** NSZE = NCAP = NUSE = back-end capacity in 512-byte blocks (P51: 256, published by
the firmware); NSFEAT 0; NLBAF 0; FLBAS 0; LBAF0 = {MS 0, LBADS 9, RP 0}; no NGUID / EUI64 (no IEEE OUI owned).

## 6. Log pages

* **Error Information (01h):** NERR entries, newest first: error count, SQID, CID, status field (DNR/M/CRD/SCT/SC,
  phase 0), parameter error location (byte / bit of the offending SQE field where known, FFFFh otherwise), LBA (for
  Read / Write), NSID. Every completion with a non-zero status creates an entry.
* **SMART / Health (02h):** measured: Data Units Read / Written (thousands of 512 B, rounded up — fixed in this
  project after the testbench caught a 10-bit overflow, docs/08 §5), Host Read / Write Commands (successful),
  Controller Busy Time (minutes with an I/O command in flight, `BUSY_CYC_PER_MIN` parameter), Media and Data
  Integrity Errors (completions with SCT 2), Number of Error Information Log Entries. **Not measured, reported 0:**
  Critical Warning, Composite Temperature, Available Spare (+threshold), Percentage Used, Power Cycles, Power On
  Hours, Unsafe Shutdowns, temperature sensors — the front end has no sensor, no persistent counter store and no
  media-wear data. A host must not read health from these fields.
* **Firmware Slot (03h):** AFI = slot 1 active, FRS1 = FR.
* **Vendor C0h:** 32 front-end performance counters (docs/09 §5).
