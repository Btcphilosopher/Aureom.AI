# 08 — Verification

Results: [reports/regression.md](../reports/regression.md) (every configuration, seed and simulator),
[reports/mutation.md](../reports/mutation.md), [reports/lint.md](../reports/lint.md). All testbenches are
self-checking: every check increments PASS or FAIL and the last line is the verdict; a run without a verdict line
counts as a failure.

## 1. Testbenches

| Testbench | DUT | Around it | Simulators |
|---|---|---|---|
| `tb/unit/tb_nvme_ctrl.sv` (+ `tb_nvme_tests.svh`) | `silicaflux_nvme_controller` | transaction-level PCIe transport + host memory + IOMMU (`sfn_tb_pcie_host`), NVMe host driver (`sfn_tb_nvme_driver.svh`), storage back-end model (`sfn_tb_backend`), reference media model | Verilator 5.020 and Icarus 12 |
| `tb/soc/tb_nvme_ssd.sv` (+ `tb_nvme_ssd_scenarios.svh`) | `silicaflux_nvme_ssd` = front end + **unmodified ControlCore CPU running the unmodified P51 firmware** + P51 storage hardware | same host side, P51 NAND model, firmware loaded through the boot-ROM flow | Verilator 5.020 (the CPU makes Icarus impractically slow, as in P51) |

Unit configurations: `base` (1 I/O queue pair, all admin commands), `multi` (4 pairs, one SQ sharing a CQ), `noext`
(baseline admin set only). Seeds randomise the transport (read latency, RCB splitting, cross-tag reordering,
back-pressure on requests and MSI, posted-write latency) and the back end (completion delay / order, command
back-pressure) in the random groups.

## 2. Host driver flow (what "a simulated NVMe host" does)

PCIe enumeration (read IDs and class code, size and assign the 64-bit BAR above 4 GiB, set MPS / MRRS, enable MSE /
BME, program MSI or leave INTx) → controller disable (CC.EN = 0, wait RDY = 0) → AQA / ASQ / ACQ → CC (IOSQES 6,
IOCQES 4, EN) → wait RDY → Identify Controller / Namespace → (Set Features Number of Queues) → Create I/O CQ / SQ →
I/O with PRP1 / PRP2 / PRP lists → reap CQEs by phase tag, ring CQ head doorbells → Flush / shutdown / reset.

## 3. Unit test groups (brief §10 item → group)

| Group | What is checked |
|---|---|
| `regs` | CAP fields (MQES, CQR, AMS, TO, DSTRD, NSSRS, CSS, BPS, MPSMIN/MAX, CMBS/PMRS), 2×32 = 64-bit CAP read, VS, reset values, RsvdZ masks of CC / AQA / ASQ, byte-enable writes, read-only registers, zero-length and 1-byte reads (byte count, lower address), 4-DW read → CA, MMIO with MSE = 0 → UR |
| `enable` | **controller enable / disable**: AQA = 0, unsupported MPS, unsupported CSS, ASQ wrapping 2^64 → CFS without RDY; CC.EN = 0 clears CFS; enable → RDY; disable → RDY 0; re-enable |
| `identify` | **Identify** controller (every non-zero field and the zero ones that matter: OACS, ONCS, SGLS, power state), namespace (NSZE / NCAP / NUSE / LBAF0), active NS list, NS descriptor list, invalid NSID / CNS; PRP1 offset spanning two pages with guard checks; PRP Offset Invalid cases |
| `queues` | **queue creation / deletion**: every Create CQ / SQ error status, duplicate IDs, Delete CQ in use, Delete admin SQ, delete and re-create |
| `io` | **Read / Write / Flush**: data checked word by word against the reference, guard bytes around buffers, volatile cache vs durable media, FLUSH NSID 1 / FFFFFFFFh / invalid, FUA |
| `prp` | 10 PRP layouts from 512 B to 32 KiB (offsets, page-crossing, PRP2 entry, lists with and without chaining, scattered pages), each written and read back; PRP errors: PRP1 / PRP2 / list pointer / list entry (last, first, in a chained page) offsets; transfer > MDTS |
| `invalid` | **invalid commands**: unsupported I/O and admin opcodes, FUSE, PSDT (SGL), NSID 0 / 2 / FFFFFFFFh, DTYPE; **out-of-range LBA** (SLBA = capacity, last block + 1, 2^64 wrap, SLBA ≥ 2^32) rejected by the front end without reaching the back end; Command ID Conflict |
| `wrap` | **queue wraparound**: SQ 3 / CQ 2 entries over 24 commands (phase inversions, SQHD); CQ full holds completions |
| `dma` | Max_Read_Request_Size 128 B: 8 KiB write / read through a PRP list with every read request split at 128 B (seed-independent); **DMA errors**: unmapped data page (UR), read into unmapped / read-only memory (IOMMU faults, posted), read-ahead bounded to the buffer (next page unmapped), Completer Abort, completion timeout, late completion (tag quarantine), unreadable PRP list |
| `fatal` | SQE fetch failure → CFS; Bus Master Enable clear → no TLP, CFS; recovery by reset |
| `reset` | **controller reset** with 6 commands in flight: RDY falls only after the back end aborts, no CQE written, no TLP after RDY = 0; recovery |
| `flr` | function-level reset: configuration space and controller registers reset, re-enumeration, recovery |
| `shutdown` | CC.SHN → SHST 01b → 10b, volatile cache committed |
| `power` | **power-failure interaction** (back-end model): flushed and FUA data survive a power cut, unflushed data may not (VWC = 1); re-enumeration after power-on |
| `irq` | INTx assert / INTMS / INTMC / head-doorbell deassert / INTx Disable; MSI vector 1 with 60-cycle posted latency (CQE and data visible when the MSI arrives); masking, unmask re-send, head-doorbell re-send, IEN = 0, single allocated message |
| `random` | 400 random Read / Write (some FUA) / Flush, 1–64 blocks, random offsets and list positions, up to NCTX+4 outstanding, out-of-order completion, randomised transport and back end; in `multi` over 4 SQs with a shared CQ |
| `ext` | Set / Get Features NQ (before / after queue creation), VWC (WCE = 0 forces FUA), SV, SEL; Abort; AER on invalid doorbell register / value, masking until log 01h read, AER limit |
| `logs` | error log (entry contents, ordering), SMART counters vs the host's own count, data units rounding, FW slot, vendor perf log, offsets, invalid LID / NSID / NUMD |
| global | TLP rule violations = 0 in every run |

## 4. SoC scenarios (real firmware, FTL, ECC, NAND)

| Scenario | What is checked |
|---|---|
| boot | ControlCore boot ROM accepts the P51 image (CRC32), firmware HOST_READY, capacity published |
| `init` | enumeration with MSI, enable (RDY raised by the firmware through the HIF page), Identify: MDTS 1, NSZE 256 |
| **DoD** | write 4 blocks, read them back through another PRP layout, FLUSH, read again → `TB DoD: … MET` |
| `prp` | 8 KiB with a PRP list (+ chained list page), 512 B across a page, 4 KiB FUA |
| `errors` | unwritten LBA reads zeros, LBA Out of Range against the firmware's capacity, > MDTS, unsupported opcodes |
| `wrap` | SQ 3 / CQ 2 entries, 16 commands on the real back end |
| `random` | 80 random commands, 8 in flight, out-of-order completion through the firmware |
| `ecc` | 1-bit NAND error corrected (data intact); 2-bit error → `2/81` Unrecovered Read Error; rewrite heals |
| `reset` | CC.EN = 0 with 6 writes in flight: firmware aborts (HIF EN_FALL), RDY falls, no TLP afterwards |
| `shutdown` | CC.SHN → firmware checkpoint → SHST 10b; data readable after reset |
| `power` | abrupt power cycle (whole SoC reset, NAND kept, firmware re-booted): flushed data intact, unflushed data = last checkpoint; power-loss warning: write during quiescence → `0/05`, acknowledged unflushed data survives the cycle |
| `logs` | SMART host command counters vs the host's count since power-on |
| firmware | mailbox SHUTDOWN: the P51 firmware's own verdict (no firmware errors) |
| global | TLP rule violations = 0, IOMMU faults = 0 |

## 5. Bugs found by the testbenches during development

| Bug | Found by | Fix |
|---|---|---|
| SMART data-unit remainder adder 10 bits wide: remainder + blocks wrapped past 1023, losing 1024 units and the thousands carry | `logs` (SMART vs host count) under Icarus and Verilator random streams | 11-bit sum |
| Window prefetch livelock: a freshly started stream did not count the access as covered and restarted every cycle | every data test (hang → reap timeouts) after the window rework | coverage includes the next offset the stream will request |
| Test gaps (not RTL): the LBA range test's boundary case was masked by another error, and only the last PRP list entry was checked for an offset, so the `lba_range` and `prp_entry_offset` mutants survived | mutation check | front-end rejection checked via the back-end command count; first-entry and chained-page entry offset tests |
| Test gap (not RTL): MRRS 128 B was exercised only when the random group drew it (4 of 12 Verilator runs), so the `tlp_mrrs` mutant survived the seed-1 mutation run | mutation check | deterministic MRRS 128 B sub-test in `dma` |
| Testbench bugs (not RTL): fixed PRP-list location shared by concurrent commands, page allocator wrap inside a "contiguous" buffer, wrong expectation after a power cut | random / power groups | per-buffer list pages, contiguous allocation, expectation = last checkpointed data |

## 6. Mutation check

[reports/mutation.md](../reports/mutation.md): 16 planted RTL bugs, each a single textual change to a copy of `rtl/`,
built and run through the unit testbench (Verilator, seed 1): CQ phase inversion, doorbell range check, CQ-full
check, LBA range off-by-one, PRP list entry offset check, CQE-before-data ordering, the three TLP splitting rules
(4 KiB, MPS, MRRS), completion-tag reassembly, MSI on CQE post, INTMS mask for INTx, CC reserved bits, read-ahead
bound, FUA propagation, namespace check.

**Result: 15 / 16 killed.** The survivor, `tlp_4k_cross`, is an equivalent mutant: it removes the adapter's 4 KiB
split for memory writes, but no engine issues a crossing write (write combining never crosses a host page, queue
bases are page-aligned, admin data goes per PRP page). The rule checker would flag one in any run.

| Detection | Mutants |
|---|---|
| directed group (one or more) | `cq_phase` (identify onward, 221 failures), `sq_tail_range` (aer), `cq_full` (wrap), `lba_range` (invalid), `prp_entry_offset` (prp), `tlp_mps` / `tlp_mrrs` (dma, MRRS 128 B), `cpl_tag_mixup` (io), `msi_on_post` / `intx_mask` (irq), `cc_rsvd` (regs), `prefetch_bound` (dma), `fua_dropped` (io), `nsid_check` (invalid) |
| random traffic only | `cqe_before_data`: the ordering hazard only shows under randomised posted-write latency and back-end timing (235 data / status errors in the seed-1 run); no directed test isolates it |

Earlier campaigns found three test gaps (`lba_range`, `prp_entry_offset`, `tlp_mrrs` survived); each was closed with a
deterministic test (§5).

## 7. Not done

No formal verification, no code-coverage measurement, no OS driver (Linux `nvme`) or QEMU co-simulation, no
conformance suite (docs/10 §3).
