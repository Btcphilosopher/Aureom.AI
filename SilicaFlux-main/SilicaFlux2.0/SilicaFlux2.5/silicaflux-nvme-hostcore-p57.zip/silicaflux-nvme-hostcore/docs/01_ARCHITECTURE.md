# 01 — Architecture

## 1. The requested chain

```
Host ─► PCIe Endpoint Adapter ─► NVMe Register Interface ─► Command Fetch ─► Command Decoder ─► Storage / FTL ─► Completion Queue ─► Host
```

| Stage | Implementation | File |
|---|---|---|
| Host | simulated: transaction-level root complex, host memory + IOMMU, NVMe host driver | `tb/common/sfn_tb_pcie_host.sv`, `tb/common/sfn_tb_nvme_driver.svh` |
| PCIe endpoint (physical) | **not present**: vendor hard IP in a product; its user-interface role is modelled by the simulation transport | docs/06 |
| PCIe Endpoint Adapter | completer (BAR0 MMIO) + requester (tags, MRRS/MPS/4 KiB splitting, in-order reassembly, completion timeout) | `rtl/sfn_ep_adapter.sv` |
| NVMe Register Interface | CAP VS INTMS INTMC CC CSTS AQA ASQ ACQ + doorbells | `rtl/sfn_regs.sv` |
| Queues | SQ / CQ state, head / tail / fetch pointers, phase, doorbell validation | `rtl/sfn_queue_mgr.sv` |
| Command Fetch | round-robin over SQs, 64-byte SQE reads, up to 4 in flight | `rtl/silicaflux_nvme_controller.sv` (fetch engine) |
| Command Decoder | opcode / field / namespace / MDTS / LBA-range / CID / PRP checks | same (decode) |
| PRP engine | PRP list fetch, chaining, offset checks | same (PRP-list engine) |
| Admin engine | Identify, queue create / delete, Get Log Page, Set / Get Features, Abort, AER | same + `rtl/sfn_admin_data.sv` |
| Storage / FTL | P51 command controller → ControlCore firmware (FTL) → NAND controller (ECC) → NAND; or the unit-test model | `rtl/soc/sfn_storage_backend.sv` (+ vendored P51), `tb/models/sfn_tb_backend.sv` |
| Data path | PRP-translated host-memory window for the back end's DMA (streaming prefetch, write combining) | `rtl/sfn_hostwin.sv` |
| Completion Queue | CQE writes with phase tag + SQ head, CQ-full hold, error log, SMART / perf counters | controller (completion engine) |
| Interrupts | pin-based and MSI vectors | `rtl/sfn_irq.sv` |

## 2. Block diagram

```
                ┌────────────────────────────── silicaflux_nvme_controller ──────────────────────────────────────┐
 SFN-TL         │  sfn_ep_adapter                                                                                  │
 cq/cc ◄──────► │   completer ── mm (DW) ──► sfn_regs ── doorbells ──► sfn_queue_mgr ◄─────────────┐              │
 rq/rc ◄──────► │   requester ◄── rd (id) ──┬── fetch engine ──► contexts (NCTX) ──► decode         │              │
 cfg   ───────► │             ◄── wr ───────┤                       │      │          │             │              │
 msi/intx ◄──── │                           ├── PRP-list engine ◄───┘      │          ├─► admin engine (Identify,     │
                │                           │                              │          │   queues, logs, features)   │
                │                           ├── completion engine ◄────────┴──────────┘ (CQE, phase, SQHD, AER)      │
                │                           └── sfn_hostwin ◄── hw_* (SFB2) ──────────────────────────┐              │
                │  sfn_irq ◄── CQ state                                                               │              │
                └──────────────────────────────── be_cmd / be_cpl / fe_en … ─────────────────────────┼──────────────┘
                                                        │                                               │
                ┌───────────── sfn_storage_backend (P51 leaf modules, unmodified) ───────────────────────┼──────────┐
                │ sfs_cmd_ctrl ── tags ──► ControlCore firmware (P51, unmodified): FTL, NAND ops, DMA ────┘          │
                │ storage DataFabric ── buffer SRAM (SECDED) ── sfs_dma ── hm_* ─────────────────────────────────────┘
                │ sfs_nand_ctrl (page ECC) ── NAND pins ──► NAND model           sfn_hif_regs (HIF firmware page)    │
                └─────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

## 3. Life of an NVMe Read (SoC configuration)

1. Host writes the SQE into its SQ in host memory and the SQ tail doorbell (MMIO write TLP to BAR0 + 1008h).
2. `sfn_ep_adapter` completer → `sfn_regs` doorbell → `sfn_queue_mgr` validates the value and moves the tail.
3. Fetch engine: SQ has entries, a free context exists → context allocated (`CX_FETCH`), 64-byte MRd issued through
   the adapter (tag, MRRS split). When the 16 DWs arrive the SQ head advances (this is what CQEs report as SQHD).
4. Decode: opcode, FUSE / PSDT, CID conflict, NSID, DTYPE, MDTS, LBA range, PRP1 / PRP2 offsets. Errors go straight
   to `CX_DONE` with a status. PRP tables of 1–2 pages are filled here; longer transfers go to the PRP-list engine,
   which reads the list (following chain pointers) and checks every entry.
5. Back-end dispatch: `sfs_cmd_t {READ, LBA, blocks, host_addr = context << 20, tid = {generation, context}}`.
6. P51: `sfs_cmd_ctrl` validates and tags it; the firmware pops the tag, looks the LBA up in the FTL, issues NAND
   READ_PAGE (page ECC corrects on the fly) into the buffer SRAM, then a DMA buffer → host window.
7. `sfn_hostwin` translates each window word through the command's PRP table and write-combines the words into
   posted memory-write TLPs (≤ MPS, never across a page).
8. P51 posts the completion (`sfs_cpl_t`, TID echoed); the context becomes `CX_DONE` with the mapped NVMe status.
9. Completion engine: waits until the window's write buffers are empty (data first), checks CQ space, writes the
   16-byte CQE (DW0 result, SQHD + SQID, CID + phase + status) and advances the CQ tail.
10. `sfn_irq` requests an MSI for the CQ's vector; the endpoint emits it after the CQE write.

## 4. Clocks, resets, parameters

One clock domain (the endpoint user clock). Resets: `rst_n` (power-on / hot reset / link down: everything), CC.EN
1 → 0 (controller reset, docs/02 §4), `cfg_flr` (function-level reset: controller reset + registers). In the SoC,
the NVMe front end has its own synchronised reset (`ep_rst_ni`), so a PCIe hot reset does not reboot the firmware.

| Parameter | Default | Meaning |
|---|---|---|
| `NUM_IOQ` | 1 | I/O queue pairs (1..8) |
| `NCTX` | 8 | commands in flight (power of two, 2..32); in the SoC = P51 tags |
| `MQES` | 1023 | CAP.MQES (0's based) |
| `NUM_VEC` | 8 | interrupt vectors (1..32) |
| `MAX_XFER_LOG2` | 15 | front-end transfer limit (32 KiB); MDTS = min(front end, back end) |
| `NTAG` / `RSLOT_BYTES` | 8 / 512 | read tags and reassembly buffer per tag (largest MRd) |
| `MPS_CAP` | 256 | largest MWr payload issued |
| `CPL_TIMEOUT` | 65536 | completion timeout, cycles (the unit testbench uses 3000) |
| `PF_BYTES` / `PF_CHUNK` / `PF_INF` | 1024 / 256 / 4 | window read-ahead depth, read size, reads in flight |
| `WC_BYTES` / `WC_IDLE` | 256 / 16 | window write-combining buffer (×2), idle flush |
| `FETCH_OUT` | 4 | SQE reads in flight |
| `ENABLE_EXT_ADMIN` | 1 | phase-2 admin commands (Set/Get Features, Abort, AER) |
| `NERR` / `AERL` | 4 / 1 | error-log entries, AER limit (0's based) |
| `CAP_TO` | 15 | CAP.TO (500 ms units) |
| `PCI_VID` / `PCI_SSVID` | FFFEh | **placeholders** — not assigned Vendor IDs; replace before any hardware use |

Illegal parameter sets refuse to elaborate in every tool (a deliberately undefined module is instantiated).

## 5. Internal interfaces (controller-private)

| Interface | Width / protocol |
|---|---|
| Register port (adapter → regs) | one DW per cycle, byte enables, read data combinational |
| DMA read (engines → adapter) | `{addr64, len ≤ 4096 B, id}` request; DW beats back **in request order**, `last`, `err` |
| DMA write (engines → adapter) | `{addr64, len ≤ 4096 B}` + DW beats; grant held for a whole request; adapter splits into TLPs |
| Back end | `sfs_cmd_t` / `sfs_cpl_t` (P51 protocol v1.0, ready/valid), `fe_en / fe_shn / fe_resetting / fe_reset_done`, `be_rdy / be_shst / be_cfs / be_idle`, capacity, MDTS |
| Window | SFB2 slave, 32-bit (DataFabric PROTOCOL.md rules; posted-write acknowledgement is the one documented deviation, docs/05 §4) |
