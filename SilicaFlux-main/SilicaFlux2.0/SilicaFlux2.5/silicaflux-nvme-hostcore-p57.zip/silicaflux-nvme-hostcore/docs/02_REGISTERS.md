# 02 — Controller registers and capability reporting

BAR0 is a 64-bit, non-prefetchable 16 KiB memory BAR (in the simulation transport: configuration offsets 10h/14h,
sizing returns `FFFFC004h`). Offsets, widths and field positions follow the NVM Express Base Specification
"Controller Registers" section and the NVMe over PCIe Transport mapping of those registers into BAR0/BAR1. Every
value below is checked by `tb/unit` group `regs` / `enable` (docs/08).

## 1. What the controller reports — and why

**Principle:** advertise only what the hardware executes. Where a field has no "not supported" encoding, the
minimum legal value is reported and the gap is listed in docs/10.

| Reg | Field | Value | Reason |
|---|---|---|---|
| CAP (00h, 64 bit) | MQES [15:0] | 1023 (parameter) | 1024-entry queues; pointers are 16 bit |
| | CQR [16] | 1 | **only physically contiguous queues** (no PRP-list queues) |
| | AMS [18:17] | 00b | round robin only (no WRR / vendor arbitration) |
| | TO [31:24] | 15 (7.5 s) | parameter; P51 firmware raises RDY in < 1 ms of simulated time once booted |
| | DSTRD [35:32] | 0 | 4-byte doorbell stride |
| | NSSRS [36] | 0 | no NVM subsystem reset → NSSR register reserved |
| | CSS [44:37] | 0000_0001b | NVM command set only; no I/O command-set framework (bit 6), not admin-only |
| | BPS [45], CPS, PMRS, CMBS, NSSS, CRMS | 0 | no boot partitions, PMR, CMB, subsystem shutdown, ready modes |
| | MPSMIN / MPSMAX [55:48] | 0 / 0 | **4 KiB memory pages only** |
| VS (08h) | MJR.MNR.TER | 1.4.0 | see §2 |
| INTMS (0Ch) / INTMC (10h) | IVMS / IVMC | per vector, NUM_VEC bits | pin-based / MSI masking; bits ≥ NUM_VEC read 0 |
| CC (14h) | EN [0] | RW | |
| | CSS [6:4] | must be 000b | other values → CSTS.CFS at enable |
| | MPS [10:7] | must be 0 | other values → CFS at enable |
| | AMS [13:11] | must be 000b | other values → CFS at enable |
| | SHN [15:14] | RW | shutdown notification → back end (P51: FTL checkpoint) |
| | IOSQES [19:16] / IOCQES [23:20] | RW; must be 6 / 4 when I/O queues are created | else Create I/O SQ/CQ → Invalid Field |
| | [31:24], [3:1] | RsvdZ | CRIME (2.x) not implemented |
| CSTS (1Ch) | RDY [0] | set when the back end is ready (P51 firmware writes HIF RDY) | |
| | CFS [1] | front-end fatal (bad configuration at enable, SQE fetch failure) OR back-end CFS | |
| | SHST [3:2] | from the back end (P51 firmware: 01b processing, 10b complete) | |
| | NSSRO [4], PP [5], ST [6] | 0 | no subsystem reset, no processing pause |
| AQA (24h) | ASQS [11:0], ACQS [27:16] | RW (0 → CFS at enable) | |
| ASQ (28h) / ACQ (30h) | base [63:12] | RW, bits 11:0 RsvdZ | queue base + size must not wrap 2^64 (→ CFS) |
| 38h–FFFh | CMB, BP, PMR, … | read 0, writes ignored | not implemented |
| 1000h + 8y / 1004h + 8y | SQyTDBL / CQyHDBL | write-only, read 0 | §3 |

Register reads have no side effects; byte enables are honoured on every RW register; partial writes to doorbells
are ignored (counted). The completer answers 1- and 2-DW accesses; longer reads get Completer Abort, longer writes
are dropped (counted); zero-length reads return one DW without a register access.

## 2. Version register

VS reports **1.4.0**. The design references are the NVMe 2.x document set (Base / NVM Command Set / PCIe Transport),
but 2.x adds requirements this subset does not implement for a controller that reports 2.x (Controller Ready
Timeouts register and CAP.CRMS, the I/O command-set framework with Identify CNS 05h/06h/1Ch, CSI descriptors). The
register layout and the command subset used here are those of the 1.4 controller model, so 1.4.0 is the value
a host driver will interpret correctly. **This is not a 1.4 conformance claim**: several commands and features
mandatory in 1.4 are absent (docs/10 §1). The same value is reported in Identify Controller VER.

## 3. Doorbells

| Write | Accepted when | Otherwise |
|---|---|---|
| SQyTDBL | queue y exists; value[31:16] = 0; value ≤ size−1 | ignored; *invalid doorbell register* (queue absent / index beyond `NUM_IOQ`) or *invalid doorbell write value*; asynchronous event (AEI 01h / 02h) when AER is enabled; HIF DB_ERR event to the firmware |
| CQyHDBL | as above, and the new head does not pass the entries the controller has posted | same |

The controller never trusts a doorbell to overwrite state: an invalid write leaves the queue unchanged.

## 4. Enable, ready, reset, shutdown

```
            CC.EN 0→1, config OK            back end ready (firmware RDY)
  DISABLED ───────────────────────► ENABLING ─────────────────────────► READY (CSTS.RDY = 1)
     ▲   └─ config bad → ERROR (CFS=1) ──┐           │ CC.EN 1→0                │ CC.EN 1→0
     │                                   └───────────┴──────────────► RESETTING ◄┘
     └──────────── everything quiet: queues deleted, CC/INTMS cleared, RDY = 0 ──┘
```

* **Enable checks**: AQA sizes ≥ 2 entries, CC.CSS / MPS / AMS supported, admin queues do not wrap 2^64. A failure
  sets CSTS.CFS and the controller does not become ready (as QEMU does); CC.EN = 0 clears it.
* **Controller reset (CC.EN 1 → 0)**: fetching stops; contexts not yet handed to the back end are dropped; the back
  end is told (`fe_resetting` → P51 HIF EN_FALL: firmware aborts its tags); completions arriving during the reset
  are dropped (no CQE is written); the host-memory window refuses new back-end accesses and drops write data not
  yet being emitted. RDY falls only when every context is free, no DMA read is outstanding, every write has been
  handed to the endpoint and the back end reports idle. Then all I/O queues are deleted, admin queue pointers
  reset, CC and INTMS cleared (AQA / ASQ / ACQ kept, as the specification requires), the back end gets
  `fe_reset_done`. Verified: no TLP from the device after RDY = 0 (`reset` groups, unit and SoC).
* **Function-level reset** (`cfg_flr`): same sequence, and AQA / ASQ / ACQ, error log, SMART counters and the VWC
  feature are reset too.
* **Shutdown (CC.SHN ≠ 00b)**: forwarded to the back end; CSTS.SHST follows the back end (P51: checkpoint, then
  10b). After SHST = 10b no further SQEs are fetched until the controller is reset.
