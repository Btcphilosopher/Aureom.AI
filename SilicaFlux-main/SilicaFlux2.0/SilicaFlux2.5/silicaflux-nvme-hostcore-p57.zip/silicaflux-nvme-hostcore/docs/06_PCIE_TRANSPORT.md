# 06 — PCIe transport: endpoint boundary and the simulated transport

**Status: there is no physical PCIe in this project.** No PHY, no data-link layer, no LTSSM / link training, no flow
control credits, no configuration-space RTL. Those belong to a verified vendor endpoint core, which does not exist in
the repository or this environment (docs/00). The controller's PCIe-facing side is a **transaction-layer user
interface (SFN-TL)**; in simulation it is driven by `tb/common/sfn_tb_pcie_host.sv`, a transaction-level model.
Nothing here is evidence about link behaviour, electrical compliance or enumeration on a real host.

## 1. SFN-TL (controller ports)

All channels valid/ready; a TLP is a sequence of 32-bit beats with its header held constant for every beat; `last`
marks the final beat.

| Channel | Direction | Header fields | Use |
|---|---|---|---|
| completer request `cq_*` | host → device | write, BAR id, address, length (DW), first/last BE, tag, requester ID | MMIO to BAR0 (NVMe registers, doorbells) |
| completer completion `cc_*` | device → host | tag, requester ID, status (SC / UR / CA), byte count, lower address, length | MMIO read data |
| requester request `rq_*` | device → host | write, 64-bit address, length, first/last BE, tag | SQE / PRP-list / data reads, CQE / data writes |
| requester completion `rc_*` | host → device | tag, status, byte count, lower address, length | read data; `rc_ready` is always 1 (buffer reserved per tag) |
| configuration status `cfg_*` | endpoint → device | BME, MPS, MRRS, MSI enable, MSI MME, INTx Disable, FLR pulse | |
| interrupt `msi_*`, `intx_assert` | device → endpoint | MSI vector request (valid/ready); INTx level | |

## 2. Endpoint adapter (`rtl/sfn_ep_adapter.sv`)

Completer: 1–2 DW requests to BAR0 become register accesses; completions carry the byte count and lower address
computed from the byte enables (explicitly checked for a zero-length and a 1-byte read; 4- and 8-byte reads are used
throughout); longer reads → CA (checked); other BARs → UR. Requester:
see docs/05 §6. With Bus Master Enable clear no request TLP is emitted.

## 3. Requirements on a real endpoint (to be verified on the chosen IP)

| # | Requirement |
|---|---|
| E1 | BAR0/1: 64-bit memory BAR, non-prefetchable, 16 KiB, delivered to the completer interface with the BAR id |
| E2 | Requests from the requester interface sent with the given 64-bit address (no translation), 3DW / 4DW header chosen by the IP |
| E3 | Posted writes emitted in the order the requester interface accepted them, one traffic class, Relaxed Ordering clear |
| E4 | An MSI requested after a posted write was accepted must not be emitted before that write |
| E5 | Completion timeout, UR, CA reported as completions with error status (the adapter also has its own timeout) |
| E6 | MPS / MRRS / BME / MSI / INTx-Disable state exported; FLR exported as a pulse; hot reset / link down → `rst_n` |
| E7 | Completions may be split at the RCB and interleaved across tags (handled), never back-pressured for long |
| E8 | Class code 01 08 02h (mass storage / NVM / NVM Express), Vendor / Device / Subsystem IDs assigned by the owner (**the FFFEh placeholders must be replaced**) |
| E9 | A user-clock CDC / width converter if the IP's datapath is wider than 32 bit (not provided; SFN-TL is 32-bit) |

## 4. Interrupts

| Mode | Behaviour (`rtl/sfn_irq.sv`) |
|---|---|
| Pin-based (MSI disabled) | `intx_assert` = any unmasked vector with unconsumed CQ entries; the endpoint sends Assert/Deassert INTA. INTx Disable suppresses it. Tested: assert on CQE, INTMS deasserts, INTMC re-asserts, CQ head doorbell deasserts |
| MSI single / multiple message | message for vector v requested on a CQE post to a CQ with IEN and IV = v, on a CQ-head doorbell that leaves entries (prevents lost interrupts), on unmask while pending; sent if unmasked and still pending. Vector v uses message v if v < 2^MME else message 0. Tested: vector 1, masking, unmask, re-send, IEN = 0, one allocated message |
| MSI-X | **not implemented** (no table / PBA); a host must use MSI or INTx |

No interrupt coalescing (feature 08h not implemented): one message per CQE plus re-sends (docs/09 shows ≈1.0–1.9
messages per command depending on queue depth).

## 5. Mapping to vendor endpoint families (unverified)

| Family | Completer side | Requester side | Interrupts | Notes |
|---|---|---|---|---|
| AMD/Xilinx UltraScale+ PCIe Integrated Block (CQ/CC/RQ/RC AXI4-Stream) | CQ → `cq_*`, CC ← `cc_*` | RQ ← `rq_*`, RC → `rc_*` | `cfg_interrupt_msi_*`, `cfg_interrupt_int` | the closest match to SFN-TL; descriptor formats, straddling and data widths (64–512 bit) need a shim |
| Intel/Altera P-Tile / R-Tile Avalon-ST | RX → `cq_*`, TX ← `cc_*` | TX ← `rq_*`, RX → `rc_*` | MSI interface / INTx | header formats differ; one shared RX/TX per direction |
| Lattice PCIe IP (CertusPro-NX) | per IP user interface | per IP | per IP | requires a SERDES device |

None of these has been instantiated, compiled or simulated here.

## 6. The simulation transport (`tb/common/sfn_tb_pcie_host.sv`)

Models what the endpoint and the root complex do at the transaction level: configuration space (IDs, class code,
Command register, 64-bit BAR sizing, MSI capability with 64-bit address and up to 32 vectors, PCIe capability with
MPS / MRRS / FLR); MMIO TLPs with completion checking; host memory (4 MiB) behind an IOMMU; read completions with
configurable latency, RCB splitting and cross-tag reordering; fault injection (CA, no completion, late completion,
unmapped); one ordered posted queue (memory writes, MSI, INTx messages) with a configurable latency; and the TLP rule
checker (docs/05 §6, plus BME, MSI-while-disabled, INTx-while-MSI). Configuration requests are applied directly, as
hard IP does internally; they are not TLPs on SFN-TL.

What it does **not** model: link layer (ACK/NAK, replay), credits and back-pressure from credits, ordering rules
other than posted-in-order, poisoned TLPs, ECRC, ATS / PASID, power management (ASPM, D-states), and any timing of a
real link.
