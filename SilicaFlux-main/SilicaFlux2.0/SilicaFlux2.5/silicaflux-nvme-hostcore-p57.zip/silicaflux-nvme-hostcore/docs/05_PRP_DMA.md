# 05 — Data pointers (PRP) and DMA

## 1. Supported subset

* **PRPs only** (PSDT = 00b; SGLS = 0 in Identify; PSDT ≠ 00b → Invalid Field).
* **Memory page size 4 KiB only** (CAP.MPSMIN = MPSMAX = 0; CC.MPS must be 0).
* Transfers up to MDTS = min(front-end limit `MAX_XFER_LOG2`, back-end limit). Unit configuration: 32 KiB
  (9 PRP entries); SoC: 8 KiB (P51 MDTS = 16 blocks).
* PRP lists with chaining: when more entries are needed than fit in the list's memory page, the last slot of the page
  is a pointer to the next list page; a list may start at any QW offset (including the last slot of a page).
* Queues are physically contiguous (CQR = 1): queue memory never uses PRP lists.

## 2. Validation (before any data moves)

| Rule | Status |
|---|---|
| PRP1 DW aligned (bits 1:0 = 0) | `0/13` PRP Offset Invalid |
| 2-page transfer: PRP2 page aligned | `0/13` |
| > 2 pages: PRP2 QW aligned | `0/13` |
| every list entry page aligned | `0/13` (checked while the list is read; nothing is transferred) |
| chain pointer QW aligned | `0/13` |
| list read fails (UR / CA / timeout / IOMMU) | `0/04` Data Transfer Error |
| transfer length > MDTS | `0/02` |
| create-queue base not page aligned | `0/13`; base + size wrapping 2^64 → `0/02` |

**Buffer length:** pages = ⌈(PRP1 offset + length) / 4096⌉; exactly that many entries are read from the list (no
read-ahead into the list), and the data path is bounded by the length (§3).
**Address overflow:** a page-aligned page cannot wrap 2^64; queue bases are checked at creation / enable; the adapter
never emits a TLP that wraps 2^64 (rule checker). Tested: SLBA + NLB wrap, queue base wrap, ASQ wrap.

## 3. The host-memory window (`sfn_hostwin`)

The back end (P51 DMA, or the unit model) addresses command data as `context × 1 MiB + byte offset` on an SFB2 port.
The window translates every word:

```
pos = PRP1[11:0] + offset ;  host address = PRPtable[context][pos >> 12] (entry 0 = PRP1's page) + pos[11:0]
```

and checks that the context is owned by the back end, the direction matches the opcode (Read: back end writes;
Write: back end reads), the word lies inside the transfer length and writes are whole words. Violations answer
`rsp_error` with no host-side effect.

* **Reads (NVMe Write data, host → device):** streaming prefetch. A miss starts a stream at the accessed offset; the
  stream keeps up to `PF_BYTES` (1 KiB) requested ahead of the consumer in reads of `PF_CHUNK` (256 B), at most
  `PF_INF` (4) in flight, each inside one memory page and never beyond the transfer length — **the device never reads
  host memory outside the command's buffer** (tested with the next page unmapped: no UR). A failed read poisons the
  stream; the back end then gets `rsp_error` and fails the command with `0/04`.
* **Writes (NVMe Read data, device → host):** two 256-byte combining buffers; one fills while the other is emitted.
  A buffer closes when full, at a page or transfer end, on a non-sequential write, after 16 idle cycles, or when the
  completion engine asks (`flush_req`). Buffers are emitted strictly in close order.

## 4. Ordering

| Hazard | Guarantee |
|---|---|
| CQE overtaking data (Read) | the window acknowledges posted writes on buffering; the completion engine posts a window-using command's CQE only when both buffers are empty (all data handed to the endpoint). The endpoint keeps posted writes in order (requirement E3, docs/06) |
| MSI overtaking the CQE | the MSI is requested only after the CQE write was accepted; the endpoint must emit an MSI after posted writes accepted before it (E4) |
| Identify / log data vs CQE | admin data is written (accepted) before the context becomes DONE |
| SQ slot reuse | SQHD advances only when the SQE has arrived (docs/04) |

Tested with a 60-cycle posted-write latency: CQE and data visible when the MSI arrives (`irq msi`). The mutation
check plants "CQE without draining" (`cqe_before_data`); it is caught by the random-traffic group (docs/08 §6).

The posted acknowledgement is the one deviation from SFB2 rule R7 ("write response only after the write is
performed"); it is confined to this port and compensated as above.

## 5. Host DMA mapping (IOMMU) — what was tested

The simulation host translates every device access through an IOMMU table (IOVA regions with read / write
permission); device reads of unmapped or unreadable memory complete with UR, device writes to unmapped or read-only
memory are dropped and logged.

| Case | Result |
|---|---|
| Write command, data page unmapped | `0/04` Data Transfer Error |
| Read command into unmapped / read-only page | completes (posted writes cannot fail at the device); IOMMU faults logged — this is how real systems behave |
| Completer Abort / no completion / late completion on data reads | `0/04`; late completion dropped, its tag quarantined (no reuse while it could still arrive) |
| PRP list in unmapped memory | `0/04`, no data written |
| Buffer page mapped alone, neighbour unmapped (full page and half page) | success, **no read beyond the buffer** |
| Bus Master Enable clear | no request TLP leaves the device; SQE fetch fails → CFS |
| every normal test | 0 IOMMU faults, guard patterns around every buffer intact |

## 6. TLP generation (adapter)

| Rule | Implementation |
|---|---|
| MWr ≤ Max_Payload_Size, MRd ≤ Max_Read_Request_Size | split at min(MPS, MPS_CAP = 256 B) / min(MRRS, 512 B) |
| no TLP crosses a 4 KiB boundary | split at every 4 KiB boundary |
| byte enables | first BE = Fh; last BE = 0 for 1-DW, Fh otherwise (all transfers are whole DWs) |
| tags | one per outstanding MRd (8), allocated in a ring, freed after delivery; timed-out tags quarantined for another timeout period |
| completions | RCB-split and cross-tag-interleaved completions reassembled per tag, delivered in request order; UR / CA / malformed / timeout → the request's beats are delivered with an error flag |

The simulation transport checks all of these on every TLP and the global check "PCIe TLP rule violations = 0" ends
every run.
