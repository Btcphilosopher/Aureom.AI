# 04 — Queue management

`rtl/sfn_queue_mgr.sv` holds the state; the fetch and completion engines in `silicaflux_nvme_controller.sv` move it.

## 1. State

| Per SQ | Per CQ |
|---|---|
| valid, deleting, base [63:12], size (0's based), **tail** (host doorbell), **fetch pointer** (next entry to read), **head** (entries whose 64 bytes have arrived = SQHD), associated CQ | valid, base, size, **tail** (next slot the controller writes), **phase** (starts 1, inverts on every wrap), **head** (host doorbell), IEN, IV |

Queue 0 is the admin pair (from AQA / ASQ / ACQ at enable). Queues live in host memory, physically contiguous
(CAP.CQR = 1). Several SQs may share one CQ (exercised in the `multi` configuration: SQ 4 → CQ 1).

## 2. Submission side

* **Arbitration:** round robin over every SQ with entries (admin included, CAP.AMS = 00b), one SQE per grant.
* **Fetch:** a 64-byte read per SQE, up to `FETCH_OUT` (4) reads in flight, each with a pre-allocated command
  context. The adapter returns read data in request order, so contexts fill in order.
* **Head pointer:** advanced only when an SQE's data has arrived. A CQE posted meanwhile reports the head (SQHD), so
  the host can never be told a slot is free while its read is still outstanding. Checked: SQHD equals the host's tail
  after every command (`wrap` groups).
* **Command IDs:** CID is carried in the context and returned in the CQE; a CID still in flight on the same SQ is
  answered `0/03` Command ID Conflict.
* **Queue full (SQ):** the host owns the SQ-full condition (tail + 1 = head). The controller only accepts tail values
  inside the queue; the host driver in the testbench never fills an SQ (it tracks SQHD from completions).
* **Fetch failure:** an SQE read that fails (UR / CA / timeout, or Bus Master Enable clear) cannot be reported per
  command, so the controller sets CSTS.CFS (`fatal` group).

## 3. Completion side

* **CQE:** DW0 command specific, DW1 0, DW2 {SQID, SQHD}, DW3 {status, phase, CID}; one 16-byte memory write.
* **Phase:** the CQ's current phase is written; the tail wraps at size and inverts the phase. Checked over 24
  commands through a 2-entry CQ (12 inversions) and with random queue sizes in the random groups.
* **CQ full:** a completion is posted only if `tail + 1 ≠ head`; otherwise it waits in its context. Completions of
  other CQs are not blocked (the engine picks any eligible context, round robin). Checked: 4 commands into a 2-entry
  CQ with the head never advanced → exactly one CQE written, the rest delivered one by one as the head moves; the
  stall is counted (vendor log C0h counter 19).
* **Ordering against data:** a context that moved data through the window is posted only when the window's write
  buffers are empty, i.e. every data DW has been handed to the endpoint before the CQE (docs/05 §4).
* **Interrupt:** after the CQE write the CQ's vector is requested (docs/06 §4).

## 4. Command contexts

`NCTX` contexts, each holding the whole SQE, its SQ, a generation number (stale back-end completions are ignored),
a fetch sequence number (admin commands execute oldest-first), status, DW0, the transfer length, the PRP table and
timestamps for the performance counters. States:

```
FREE → FETCH → DECODE → (PRP) → BE_RDY → BE_WAIT → DONE → POST → FREE
                       └──────→ ADM_RDY → ADM_RUN ─┘
                       └──── error ───────────────→ DONE
```

## 5. Wrap and full checks performed

| Check | Where |
|---|---|
| SQ 3 entries / CQ 2 entries, 24 commands, phase and SQHD every time | unit `wrap` |
| CQ full: one CQE written, three held, then released in order | unit `wrap` |
| Admin queues of 4 / 8 entries over hundreds of admin commands | every unit group |
| SQs of 8 / 13 / 18 / 23 and CQs of 8 / 12 / 16 / 20 entries, SQ 4 sharing CQ 1, 400 random commands, out-of-order completion | unit `random` (multi) |
| SQ 3 / CQ 2 on the real back end, 16 commands | SoC `wrap` |
