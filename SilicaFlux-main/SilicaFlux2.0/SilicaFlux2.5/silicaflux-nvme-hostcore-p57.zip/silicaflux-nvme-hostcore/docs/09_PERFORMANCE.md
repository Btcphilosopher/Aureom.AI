# 09 — Performance

All numbers are **RTL-simulation cycle counts** (Verilator 5.020) converted at a stated clock; none is a hardware
measurement. Full tables: [reports/perf/PERF.md](../reports/perf/PERF.md) (+ `perf.csv`, raw logs). Method: the
host keeps QD commands in flight on I/O queue 1 (batched SQ and CQ doorbells, CQ polled every cycle); latency is
"SQ doorbell accepted → CQE visible in host memory"; the controller's own counters (vendor log C0h) give the
back-end service time and fetch latency.

## 1. What each requested metric is, and where it comes from

| Metric (brief §9) | Measured as | Front end (unit, 250 MHz) | Full SoC (P51 back end, 100 MHz) |
|---|---|---|---|
| Commands per second | Flush throughput (no data) | QD 1: 1.48 M/s; QD 8: **6.85 M/s** (36.5 cycles / command) | ≈ 2.4 k/s (each Flush is an FTL checkpoint) |
| Queue depth | QD 1, 2, 4, 8 sweeps | see §2 | see §3 |
| Host-to-controller latency | SQ doorbell → controller's SQE read TLP | **4 cycles** (16 ns); SQE arrives one read latency later | 4 cycles |
| NAND service latency | front-end dispatch → back-end completion (counter 17/18), QD 1 | n/a (model) | see §3 |
| I/O completion latency | doorbell → CQE visible | 512 B Read QD 1: 363 cycles (1.45 µs) at 400 ns host read latency | see §3 |
| DMA bandwidth | TLP payload bytes per cycle on the requester interface | up to **3.8 B / cycle** (SFN-TL is 32-bit: 4 B / cycle ceiling) | ≤ 0.13 B / cycle (back-end bound) |
| Interrupt activity | MSI messages per command | 1.00 at QD 1; 1.5–1.9 at QD 2–8 (re-send on CQ-head doorbell; no coalescing) | 1.00 |
| Read / write throughput | MB/s at the stated clock | Read 950 MB/s, Write 655 MB/s (32 KiB) | ≈ 7–11 MB/s |

## 2. Front end alone (zero-latency back-end model)

The back-end model serves one command at a time (as P51's single DMA engine does), so data-command throughput stops
growing once the window is saturated; the latencies at QD > 1 then include queueing behind that one engine.

| Workload | QD 1 | QD 8 | Limit |
|---|---|---|---|
| Flush | 169 cycles / cmd | 36.5 cycles / cmd | command processing (fetch, decode, dispatch, CQE, MSI) |
| Read 512 B | 683 kIOPS, 350 MB/s | 1.53 MIOPS, 783 MB/s | per-command overhead |
| Write 512 B | 469 kIOPS | 676 kIOPS | read latency of the first prefetch |
| Read 4 KiB | 785 MB/s | 929 MB/s | window → TLP datapath (3.8 B / cycle) |
| Write 4 KiB | 546 MB/s | 589 MB/s | host read latency vs. read-ahead depth |
| Read 32 KiB | 916 MB/s | 950 MB/s | 32-bit SFN-TL |
| Write 32 KiB | 642 MB/s | 655 MB/s | read-ahead depth (1 KiB, 4 reads in flight) |
| Write 4 KiB, 1.6 µs host read latency | 319 MB/s | 372 MB/s | read-ahead depth vs. latency |

**Engineering iteration (measured, kept in the record):** the first window design (single 256-byte write buffer,
miss-driven 256-byte prefetch) reached 492 MB/s for Read 4 KiB and **232 MB/s** for Write 4 KiB at QD 8. Double-
buffered write combining raised Read to 929 MB/s; a streaming read-ahead (1 KiB, 256-byte reads, 4 in flight,
bounded by page and buffer) raised Write to 589 MB/s (×2.5). The remaining host→device limit is the read-ahead depth
against the host read latency; at 1.6 µs latency it drops to 372 MB/s. Deeper read-ahead costs buffer area.

## 3. Full SoC: front end + P51 firmware FTL + NAND model

| Workload | QD 1 latency | Back-end (NAND) service, QD 1 | QD 2–8 throughput |
|---|---|---|---|
| Read 512 B | 78.4 µs | 77.4 µs | ≈ 20.8 kIOPS (10.7 MB/s) |
| Write 512 B | 81.1 µs | 80.1 µs | ≈ 20.0 kIOPS (10.2 MB/s) |
| Read 4 KiB | 551 µs | 550 µs | ≈ 2.7 kIOPS (11.0 MB/s) |
| Write 4 KiB | 570 µs | 569 µs | ≈ 2.6 kIOPS (10.6 MB/s) |
| Read / Write 8 KiB (MDTS) | 1.09 / 1.13 ms | – | – |
| Flush (FTL checkpoint) | ≈ 400 µs | ≈ 400 µs | – |

Back-end service dominates: the NVMe front end adds ≈ 100 cycles (1 µs at 100 MHz) to every command; the rest is
the P51 firmware's per-block state machine on the ControlCore, the P51 DMA (one 32-bit word per SFB2 transaction,
≈ 4 cycles per word) and NAND (tR 2 µs, tPROG 4 µs in the model). Latency grows linearly with blocks (≈ 69 µs per
512-byte block). Throughput gains ≈ 1.6× from QD 1 to QD 2 (NAND and DMA of different commands overlap in the
firmware) and nothing beyond, because one NAND channel and one firmware loop serve every command. A Flush costs
≈ 400 µs because P51 writes the whole L2P checkpoint. All values: reports/perf/PERF.md §2.

## 4. Where the time goes (front end, Read 512 B, QD 1, 363 cycles)

| Step | Cycles | Source |
|---|---|---|
| doorbell → SQE read TLP | 4 | measured (watch range) |
| SQE read round trip: 100-cycle host read latency + 16 data beats | ≈ 120 | model parameter + beats |
| decode + back-end dispatch | ≈ 3 | RTL pipeline |
| back-end service: the model moves 128 words through the window (1 / cycle) | 133 | measured (counter 17) |
| emission of the last write-combining buffer (≤ 64 beats), CQE write, 8-cycle posted latency, polling | ≈ 103 | remainder |
| **total** | **363** | measured |

## 5. Front-end performance counters (vendor log C0h)

| # | Counter | # | Counter |
|---|---|---|---|
| 0 | cycles while ready | 16 | max fetch → CQE latency |
| 1 | SQEs fetched | 17 / 18 | back-end service time sum / max |
| 2 | CQEs posted | 19 | cycles a completion waited for CQ space |
| 3 / 4 / 5 / 6 | Reads / Writes / Flushes / admin completed | 20 / 21 / 22 / 23 | completion timeouts / UR-CA-malformed / unexpected completions / BME-blocked requests |
| 7 | error completions | 24 / 25 | SQE fetch latency sum / max |
| 8 / 9 | DWs read / written on the requester interface | 26 | window accesses refused |
| 10 / 11 | MSI messages / INTx assertions | 27 | back-end completions dropped (stale) |
| 12 / 13 / 14 | SQ / CQ doorbells, invalid doorbell writes | 28 / 29 / 30 | bad MMIO requests / window reads / window writes |
| 15 | fetch → CQE latency sum | 31 | fatal events |
