# 10 — Limitations, conformance gaps and what is not claimed

## Not claimed

* **NVMe conformance** — of any version (VS reports 1.4.0 for driver compatibility, docs/02 §2). This is an
  intentionally limited subset; §1 lists what a conformant controller needs and this one lacks. No conformance suite
  was run (none is in the repository; the established ones are licensed and need hardware plus a host OS).
* **PCIe anything** — no physical layer, data-link layer, link training, credits or configuration-space RTL; no
  endpoint IP was instantiated; the transport is a transaction-level simulation model (docs/06). No enumeration on a
  real host, no electrical or protocol compliance.
* **Hardware results** — everything is RTL simulation (Verilator 5.020, Icarus 12) and Yosys 0.33 size estimates.
  No FPGA, no silicon, no timing closure, no power.
* **Media behaviour** — NAND timings and errors come from P51's behavioural model.
* **Identifiers** — PCI Vendor / Subsystem Vendor ID FFFEh, serial number, NQN are placeholders.

## 1. Gaps against a conformant NVMe controller (Base + NVM Command Set + PCIe Transport)

| Area | Status here |
|---|---|
| Mandatory admin commands | Identify, Create/Delete I/O SQ/CQ, Get Log Page: implemented. Set/Get Features: **2 FIDs only** (07h, 06h); mandatory features Arbitration (01h), Power Management (02h), Temperature Threshold (04h), Error Recovery (05h), Interrupt Coalescing (08h), Interrupt Vector Configuration (09h), Write Atomicity Normal (0Ah), Asynchronous Event Configuration (0Bh) → Invalid Field. Abort: always "not aborted". AER: error-status events (invalid doorbell) only; no SMART / notice events |
| Optional admin commands | none (Format NVM, Firmware Commit / Download, Namespace Management / Attachment, Device Self-test, Security Send/Receive, Sanitize, Keep Alive, Directives, Virtualization, Doorbell Buffer Config, Get LBA Status …) → Invalid Opcode; OACS = 0 |
| NVM commands | Read, Write, Flush. Dataset Management (deallocate — the P51 back end supports DEALLOCATE but it is not exposed), Write Zeroes, Compare, Write Uncorrectable, Verify, Reservations → Invalid Opcode; ONCS = 0 |
| Log pages | 01h, 02h, 03h (+ vendor C0h). SMART: temperature, spare, wear, power-cycle / power-on / unsafe-shutdown counters **not measured, read 0** (docs/03 §6). Commands Supported and Effects (05h), Telemetry, Persistent Event, … not supported |
| Interrupts | pin-based and MSI; **no MSI-X**, no coalescing |
| Arbitration | round robin only; no weighted round robin / urgent class |
| Memory page size | 4 KiB only |
| Data pointers | PRP only; **no SGL** |
| Queues | physically contiguous only (CQR = 1); max 1024 entries; `NUM_IOQ` ≤ 8 pairs |
| Namespaces | one, 512-byte LBA format, no metadata, no protection information, no NGUID / EUI64 / UUID |
| Controller features | no CMB, PMR, boot partitions, NVM subsystem reset, controller ready modes / CRTO (2.x), host memory buffer, APST, keep-alive, ANA, sanitize |
| Error log | 4 entries (ring), cleared by FLR / power-on |
| Baseline build (`ENABLE_EXT_ADMIN = 0`) | rejects AER but Identify AERL can only express "1 outstanding" (0's based) — a known inconsistency of the baseline-only configuration |
| Shutdown | after SHST = 10b no further SQEs are fetched until reset; abrupt and normal shutdown are treated the same |
| Delete I/O SQ | waits for in-flight commands of that SQ to complete normally (does not abort them with `0/08`); SQEs not yet fetched are discarded |

## 2. Implementation limits

* **Storage behind NVMe** is P51's minimal FTL: 256 LBAs (128 KiB) per channel, **no garbage collection** (≈ 1000
  page writes per channel before Capacity Exceeded), checkpoint-based persistence. The P56 FlashMap FTL (GC, wear
  levelling, journal) exists but is not integrated into a command-processing firmware — the obvious next step.
* **Single NAND channel in the SoC configuration**; P51's multi-channel `research4ch` uses a 64-bit fabric and the
  window is 32-bit only.
* **Throughput**: SFN-TL is 32 bit (4 B / cycle). Measured front-end limits ≈ 3.8 B / cycle device → host and
  ≈ 2.6 B / cycle host → device at 400 ns read latency (docs/09). The P51 back end (DMA one word per transaction,
  firmware per-block state machine, one NAND channel) limits the SoC to ≈ 7–11 MB/s.
* **Area** (reports/synth.md, Yosys estimates): base configuration ≈ 55.8 k LUT4 + 24.8 k FF + 2 DP16KD on ECP5
  (4 queue pairs / 16 contexts: ≈ 90.9 k LUT4 + 33.2 k FF). 60 % of the generic flip-flops are the window buffers in
  `sfn_hostwin` (1 KiB read-ahead + 2 × 256 B write combining): they are written inside the reset-qualified
  `always_ff` and partly read asynchronously, so Yosys does not infer RAM for them. Most of the rest is the command
  contexts (whole 64-byte SQE per context, several read ports). Not fixed here because it changes verified RTL: move
  the buffer writes to a reset-free block with a registered read (as done for `prp_tab`), and keep SQEs and PRP
  tables in SRAM.
* **No CDC**: one clock; a real endpoint user clock would need a CDC to the storage clock (the P51 SoC runs one clock).
* **Completion timeout** is a cycle count (`CPL_TIMEOUT`), not the PCIe Device Control 2 ranges.
* **Read-ahead** may still be in flight when a Write command fails early on the back end; those reads stay inside the
  command's buffer but can arrive after its CQE.

## 3. Verification limits

* Directed + constrained-random simulation with a reference model; no formal proofs, no code-coverage tool run.
* One host driver (the testbench's); not tested against an operating-system driver (Linux `nvme`), QEMU or real
  hardware. The driver follows the standard bring-up order (docs/08 §2) but is not a conformance test.
* The NVMe specification text was not available in the environment; field values were written from the published
  specifications as known to the author and are tabulated for review (docs/02, docs/03).
