# 00 — Repository audit (Project 57 NVMe HostCore)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/affectionate-maxwell-58mvyi`, commit `4173a23`. As in every
earlier SilicaFlux project the hardware and firmware live in zip archives under
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Every archive relevant to an NVMe front end was extracted and read:
`silicaflux-storagecore-p51.zip` (P51), `silicaflux-flashmap-p56.zip` (P56), `silicaflux-flashlink-p53.zip` (P53),
`silicaflux-buffercore-p55.zip` (P55), `silicaflux-ecccore-p54.zip` (P54, in `SilicaFlux-main/`),
`silicaflux-hostlink-project25.zip` (P25), `silicaflux-controlcore.zip` (P21), `silicaflux-hpc-m05-dma-adapter.zip`,
`silicaflux-hpc-m06-command-queue.zip`, `silicaflux-extmem-bridge-p24.zip`, `silicaflux-nandlab-v0.1.0.zip` (P52),
`silicaflux-ioshell-p37.zip`, `silicaflux-ras-project26.zip`. "Evidence" below is what the owning project recorded;
the P51 baseline was additionally **re-run here**: its unmodified SoC testbench (`make soc CFG=min1ch SCENARIO=dod`)
built in 2 min 43 s with Verilator 5.020 and passed (30 checks, 825 162 cycles), and its firmware rebuilt to the same
image (CRC32 `f7d46dd3`).

## 1. Findings and decisions

| Area requested | Found | Decision |
|---|---|---|
| **PCIe host interface** | P25 HostLink: "PCIe accelerator host interface" with an **AXI-bridge endpoint boundary** (BAR AXI4 slave, AXI4 master for host memory, interrupt request) and a C++ transaction-level host model. It contains **no PCIe protocol logic** by design. P51 `sfs_host_if`: NVMe-*inspired* SQ/CQ rings in *controller* memory behind a BAR (not NVMe: own 32-byte SQE format, no PRPs, no host-memory queues). | New front end. Boundary moved one level down to a **transaction-layer user interface (SFN-TL)** — completer request/completion + requester request/completion, the role split hard-IP user interfaces use — because NVMe over PCIe needs requester behaviour P25's bridge hides (MRRS / MPS splitting, 4 KiB rule, tags, split / reordered completions, completion timeout, MSI ordering). Still no physical / data-link / link-training logic (docs/06). |
| **Available endpoint IP** | **None.** No vendor PCIe endpoint core, FPGA project or board with SERDES exists in the repository or this environment (same finding as P25). | Transaction-level simulated transport `tb/common/sfn_tb_pcie_host.sv`, clearly labelled as such; mapping to vendor IP documented, **not** verified (docs/06 §5). |
| **ControlCore** | P21: RV32IM_Zicsr CPU, boot ROM (image header + CRC32), 64 KiB IMEM, 32 KiB DMEM, mailbox, RAS, accelerator register port (pages 10..14) and EXT fabric port. Reused unmodified by P51. | Reused **unmodified** through P51 (vendored byte-identical). |
| **StorageCore** | P51: `sfs_cmd_ctrl` (validation, tag table, firmware command queue), storage DataFabric crossbar, buffer SRAM with SECDED (P26), `sfs_dma`, `sfs_nand_ctrl` (ONFI-style SDR, inline per-word SECDED), `sfs_sys_regs` (PLP, RAS, perf). Clean internal command boundary `sfs_cmd_t` / `sfs_cpl_t` (ready/valid, transaction ID echoed). Host-memory traffic leaves through one SFB2 master (`hm_*`). | The NVMe front end connects **at `sfs_cmd_t` / `sfs_cpl_t`** and serves the `hm_*` port with a PRP-translating window. All P51 leaf modules are used unmodified; only the subsystem composition is re-done without `sfs_host_if` (`rtl/soc/sfn_storage_backend.sv`, diff in docs/07 §2). |
| **DMA** | P51 `sfs_dma`: descriptor queue, one SFB2 transaction outstanding, ≈ 1 word / 4 cycles; addresses inside a 256 MiB host window. HPC M05 DMA adapter: compute-tile oriented. | Kept. Each command gets a 1 MiB window slot; `sfn_hostwin` translates window offsets through the command's PRPs (docs/05). |
| **FTL firmware** | P51 `firmware/app/ftl.c`: page map, 256 LBAs / channel, pre-erase, program-failure retirement, **checkpoint on FLUSH / FUA / shutdown / power-loss warning; writes after the last checkpoint are lost on power loss** — i.e. a volatile write cache contract. No GC. P56 FlashMap: complete FTL library (GC, WL, journal), but **not** integrated into a command-processing firmware (its RTL run is a self-test). | Use the **P51 firmware unmodified** (it already implements the command path the front end drives). Identify reports VWC = 1 and FLUSH maps to the P51 checkpoint (docs/07 §4). P56 integration = next step (docs/10). |
| **Interrupt logic** | P51: one level host interrupt + event bits, no MSI. P25: MSI/MSI-X-style vector request port. | New `sfn_irq`: NVMe pin-based and MSI (single / multiple message) semantics with INTMS / INTMC; MSI-X not implemented. |
| **Command / completion queues** | P51 rings (controller memory), P25 queues in host memory (own format), HPC M06 command queue (compute). None is NVMe. | New: NVMe queues in host memory, `sfn_queue_mgr` + fetch / completion engines (docs/04). |
| HIF firmware contract | P51 firmware talks to the host interface only through the HIF page: EN_RISE → firmware raises RDY; EN_FALL → firmware aborts its tags → RESET_DONE; SHN → checkpoint → SHST. | This **is** NVMe's CC.EN / CSTS.RDY / CC.SHN / CSTS.SHST protocol. `rtl/soc/sfn_hif_regs.sv` reproduces the page register-for-register, driven by the NVMe controller state, so the firmware runs unmodified. |
| Simulation tools | Not installed in the container. | Installed from Ubuntu 24.04: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, `gcc-riscv64-unknown-elf` 13.2 — the versions P51 / P56 record. |
| NVMe specifications | No copy in the repository; no network access to nvmexpress.org from this environment was attempted. | Register and command definitions written from the published NVM Express Base, NVM Command Set and PCIe Transport specifications as known to the author; every field the RTL drives is listed in docs/02 and docs/03 so it can be reviewed against the official documents. **No conformance claim.** |
| Conformance suites | None in the repository; the commonly used suites (UNH-IOL NVMe conformance tests, vendor compliance tools) are licensed or require hardware and a host OS. | Not run. Not legally / technically accessible here (docs/10). |

## 2. Dependency status

| Dependency | Status |
|---|---|
| ControlCore CPU, boot ROM, runtime (P21) | implemented + verified upstream; re-exercised here by the unmodified P51 firmware on the RTL |
| P51 command controller, DMA, NAND controller, buffer SRAM + SECDED, sys regs, flash model | implemented + verified upstream; used unmodified in the SoC testbench |
| P51 firmware (FTL, command state machines, PLP) | implemented + verified upstream; built unmodified (identical CRC32) |
| NVMe front end: adapter, registers, queues, fetch, decode, PRP, admin, completion, interrupts, window | **implemented here** |
| Transaction-level PCIe transport, host driver, back-end model | **implemented here (simulation only)** |
| Physical PCIe endpoint, MSI-X, P56 FTL in the command firmware, multi-channel back end behind NVMe | **missing → not implemented** (docs/10) |

## 3. Unverified inherited items

* No SilicaFlux block has run on an FPGA board or silicon; nothing here either.
* NAND timings and reliability in the P51 model are behavioural / illustrative; every SoC-level latency inherits that.
* No licence file exists in the repository.
