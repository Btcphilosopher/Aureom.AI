# 07 — Storage back end: mapping NVMe commands to the FTL

## 1. Boundary

The front end drives the **P51 StorageCore command channel** (`silicaflux_storage_pkg`, protocol v1.0): one
`sfs_cmd_t` per Read / Write / Flush, `tid = {context generation, context index}`, `host_addr = context × 1 MiB` (the
command's window slot), `len` = blocks, `flags.FUA`. P51's `sfs_cmd_ctrl` validates it again, allocates a tag and
hands it to the firmware; the completion `sfs_cpl_t` echoes the TID and carries the P51 status (mapped in docs/03 §4).
Controller state travels on `fe_en` / `fe_shn` / `fe_resetting` / `fe_reset_done` → HIF page, and `be_rdy` /
`be_shst` / `be_cfs` / `be_idle` back.

## 2. `rtl/soc/sfn_storage_backend.sv` — what changed relative to P51

Derived from P51 `rtl/sfs_storage_subsys.sv` (vendored unmodified in `third_party/`), by `diff`:

| Change | Lines |
|---|---|
| module renamed, header comment | 2 |
| SHC host BAR slave ports and `host_irq` removed; command / completion / controller-state ports added | port list |
| `sfs_host_if` instance removed; `sfn_hif_regs` instance + 9 assigns added (HIF page, EN / RESETTING / RDY / SHST / CFS / DB_ERR wiring, perf events) | 1 instance |
| everything else (crossbar, ECC buffer, DMA, NAND channels, sys regs, gate) | **unchanged text** |

All P51 leaf modules (`sfs_cmd_ctrl`, `sfs_dma`, `sfs_nand_ctrl`, `sfs_sys_regs`, `sfs_sfb_gate`, `sfs_sfb_upsizer`,
DataFabric crossbar, P26 ECC SRAM) and the whole ControlCore are compiled from the vendored, byte-identical files
(`third_party/SHA256SUMS`, `make vendor-check`).

`rtl/soc/sfn_hif_regs.sv` reproduces P51's HIF firmware page register for register (docs: file header) so the P51
firmware (`firmware/app/*.c`) runs **unmodified**; its build produces the identical image (CRC32 `f7d46dd3`).

## 3. Command paths (P51 firmware, `firmware/app/cmd.c` + `ftl.c`)

| NVMe | P51 path |
|---|---|
| **Read** | per block: FTL lookup (L2P in DMEM) → NAND READ_PAGE into a buffer slot (per-word SECDED decode on the fly: 1-bit errors corrected, 2-bit → uncorrectable) → storage DMA slot → host window → `sfn_hostwin` → PRP pages. Unmapped LBA: DMA from a zero slot |
| **Write** | per block: storage DMA host window → slot (`sfn_hostwin` prefetches from the PRP pages) → FTL allocates the next page of the open block (pre-erased) → NAND PROGRAM (SECDED encode) → L2P commit; program failure retires the block and retries (2×) |
| **Flush** | FTL checkpoint that starts after the command arrived: L2P + open blocks + bad-block table written to the metadata block (header with CRC32) |
| **Write + FUA** | write, then a checkpoint, then completion |

The requested transformations "ECC / other configured transformations" are P51's per-word SECDED page code (a
placeholder for BCH/LDPC, P51 docs/08); P54's BCH/LDPC codec is not wired into P51's NAND controller and therefore
not into this path.

## 4. Persistence contract (what the host may rely on)

| Event | Data guaranteed after power is restored |
|---|---|
| Write completed, no Flush / FUA | **not guaranteed** (P51 FTL: writes after the last checkpoint are lost on an abrupt power cut). Hence Identify **VWC = 1** (volatile write cache present) |
| Flush completed | every Write completed before the Flush was submitted |
| Write with FUA completed | that write (and everything before the checkpoint) |
| Set Features VWC WCE = 0 | every subsequent write is sent with FUA → durable at completion |
| Shutdown complete (CSTS.SHST = 10b) | everything completed before |
| Power-loss warning (P51 `pwr_fail_ni`, PLP) | P51 hardware refuses new commands (`0/05` to the host), the firmware drains, checkpoints, asserts NAND WP#: everything completed before the warning |

Verified on the SoC (`tb/soc`, docs/08): (a) abrupt power cut — flushed data intact, unflushed data reads back as the
last checkpointed contents; (b) power-loss warning — acknowledged unflushed data intact after the cycle, a write
submitted during quiescence completes `0/05` and is never applied; (c) shutdown — SHST = 10b after the checkpoint.

## 5. What the front end checks that P51 also checks

The front end validates LBA range against the capacity the firmware publishes (CMDR CAP), MDTS against the
firmware's MDTS, and host-buffer alignment / window bounds by construction. P51 `sfs_cmd_ctrl` re-checks all of these;
any rejection there would surface as a mapped status (docs/03 §4), never as a hang.

## 6. Unit-test back end (`tb/models/sfn_tb_backend.sv`)

Implements the same contract in a model: up to 8 commands, random completion delay and order, data moved through the
window with pipelined SFB2 transfers (one word per cycle when the window allows), durable store + volatile cache
(Write → cache, FUA → durable, Flush / shutdown → commit, `power_cut()` → cache lost), injectable unrecoverable
LBAs, HIF-like enable / reset / shutdown handshake, aborts of unstarted commands while resetting (as P51 firmware
does on EN 1 → 0).
