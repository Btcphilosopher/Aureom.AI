#!/usr/bin/env bash
# Package the project as a zip (sources, docs, reports; no build products).
#   scripts/package.sh <output.zip>
set -euo pipefail
OUT=$(realpath -m "${1:-silicaflux-nvme-hostcore-p57.zip}")
cd "$(dirname "$0")/../.."
rm -f "$OUT"
zip -qr "$OUT" silicaflux-nvme-hostcore -x 'silicaflux-nvme-hostcore/build/*' \
  'silicaflux-nvme-hostcore/synth/yosys/*.log' 'silicaflux-nvme-hostcore/synth/yosys/sfn_rtl_yosys*.sv' \
  '*/__pycache__/*' '*.pyc'
echo "$OUT: $(unzip -l "$OUT" | tail -1)"
