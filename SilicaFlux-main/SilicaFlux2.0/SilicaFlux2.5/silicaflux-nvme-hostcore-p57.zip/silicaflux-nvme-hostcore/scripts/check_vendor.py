#!/usr/bin/env python3
"""Verify that third_party/silicaflux-storagecore-p51 is byte-identical to the P51 archive in the repository.

  python3 -B scripts/check_vendor.py --repo <Aureom.AI checkout>      compare against the archive
  python3 -B scripts/check_vendor.py                                 check against third_party/SHA256SUMS only

The vendored subset keeps P51's own paths, except README.md -> README_P51.md.
"""
import argparse, hashlib, io, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VEND = os.path.join(ROOT, 'third_party', 'silicaflux-storagecore-p51')
ARCHIVE = 'SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip'
RENAME = {'README_P51.md': 'README.md'}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo')
    a = ap.parse_args()
    sums = {}
    for line in open(os.path.join(ROOT, 'third_party', 'SHA256SUMS')):
        h, p = line.split(None, 1)
        sums[p.strip()] = h
    bad = 0
    for p, h in sums.items():
        f = os.path.join(VEND, p)
        if not os.path.exists(f) or sha(open(f, 'rb').read()) != h:
            print('MISMATCH (manifest)', p); bad += 1
    print(f'manifest: {len(sums) - bad} / {len(sums)} files match third_party/SHA256SUMS')
    if a.repo:
        z = zipfile.ZipFile(os.path.join(a.repo, ARCHIVE))
        names = {n.split('/', 1)[1]: n for n in z.namelist() if '/' in n and not n.endswith('/')}
        ok = 0
        for p in sums:
            src = RENAME.get(p, p)
            if src not in names:
                print('NOT IN ARCHIVE', p); bad += 1; continue
            if sha(z.read(names[src])) == sha(open(os.path.join(VEND, p), 'rb').read()):
                ok += 1
            else:
                print('DIFFERS FROM ARCHIVE', p); bad += 1
        print(f'archive {ARCHIVE}: {ok} / {len(sums)} vendored files byte-identical')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
