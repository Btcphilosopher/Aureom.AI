#!/usr/bin/env python3
"""SilicaFlux-STORE Project 57 -- regression runner.

Builds and runs every testbench, collects the verdict lines and writes reports/regression.md.

  unit (front end + back-end model) : configs base / multi / noext, Verilator (several seeds) and Icarus (seed 1)
  soc  (front end + P51 SoC + firmware) : scenarios dod and full, Verilator

Usage: python3 -B scripts/regress.py [-j N] [--seeds 1,2,3] [--no-icarus] [--only unit|soc]
"""
import argparse, concurrent.futures as cf, os, re, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
B = os.path.join(ROOT, 'build')
VFLAGS = ['--binary', '--timing', '-j', '2', '-Wno-fatal', '-Wno-lint', '-Wno-style', '-Wno-TIMESCALEMOD',
          '-Wno-MULTIDRIVEN', '-MAKEFLAGS', 'OPT_FAST=-O1']
UNIT_SRC = ['-f', 'rtl/files_nvme.f', 'tb/common/sfn_tb_pcie_host.sv', 'tb/models/sfn_tb_backend.sv',
            'tb/unit/tb_nvme_ctrl.sv']
SOC_SRC = ['-f', 'rtl/files_soc.f', 'third_party/silicaflux-storagecore-p51/tb/models/sfs_nand_flash_model.sv',
           'tb/common/sfn_tb_pcie_host.sv', 'tb/soc/tb_nvme_ssd.sv']
CONFIGS = {'base': [], 'multi': ['CFG_MULTI'], 'noext': ['CFG_NOEXT']}
DESC = {'base': '1 I/O queue pair, all admin commands', 'multi': '4 I/O queue pairs (one shared CQ)',
        'noext': 'baseline admin set only (Set/Get Features, Abort, AER disabled)'}


def run(cmd, log, timeout=3600):
    t0 = time.time()
    with open(log, 'w') as f:
        try:
            r = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
            rc = r.returncode
        except subprocess.TimeoutExpired:
            rc = -1
    return rc, time.time() - t0


def verdict(log, pat):
    try:
        txt = open(log, errors='replace').read()
    except OSError:
        return None, ''
    m = re.findall(pat, txt)
    fails = [l for l in txt.splitlines() if ' FAIL ' in l or 'FAIL ' in l[:12]][:5]
    return (m[-1] if m else None), '\n'.join(fails)


def build_vl(name, defines, src, top):
    mdir = os.path.join(B, 'v_' + name)
    subprocess.run(['rm', '-rf', mdir])
    cmd = ['verilator'] + VFLAGS + ['+define+' + d for d in defines] + ['-Itb/unit', '-Itb/common', '-Itb/soc'] + \
          src + ['--top-module', top, '-Mdir', mdir, '-o', 'Vtb']
    rc, dt = run(cmd, os.path.join(B, 'build_' + name + '.log'))
    return name + ' (Verilator)', rc, dt


def build_iv(name, defines):
    out = os.path.join(B, 'iv_' + name + '.vvp')
    cmd = ['iverilog', '-g2012'] + ['-D' + d for d in defines] + ['-I', 'tb/unit', '-I', 'tb/common'] + UNIT_SRC + \
          ['-s', 'tb_nvme_ctrl', '-o', out]
    rc, dt = run(cmd, os.path.join(B, 'build_iv_' + name + '.log'))
    return 'unit_' + name + ' (Icarus)', rc, dt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('-j', type=int, default=3)
    ap.add_argument('--seeds', default='1,2,3,4')
    ap.add_argument('--no-icarus', action='store_true')
    ap.add_argument('--only', choices=['unit', 'soc'])
    a = ap.parse_args()
    os.makedirs(B, exist_ok=True)
    seeds = [int(s) for s in a.seeds.split(',')]
    tools = subprocess.run(['bash', '-c', 'verilator --version; iverilog -V 2>&1 | head -1'], capture_output=True,
                           text=True).stdout.strip()
    rows, t_start = [], time.time()

    # ---------------------------------------------------------------- builds
    builds = []
    with cf.ThreadPoolExecutor(a.j) as ex:
        futs = []
        if a.only in (None, 'unit'):
            for c, d in CONFIGS.items():
                futs.append(ex.submit(build_vl, 'unit_' + c, d, UNIT_SRC, 'tb_nvme_ctrl'))
                if not a.no_icarus:
                    futs.append(ex.submit(build_iv, c, d))
        if a.only in (None, 'soc'):
            futs.append(ex.submit(build_vl, 'soc', [], SOC_SRC, 'tb_nvme_ssd'))
        for f in futs:
            builds.append(f.result())
    for n, rc, dt in builds:
        print(f'build {n}: rc={rc} {dt:.0f}s')
        if rc != 0:
            print(f'  see build/build_{n}.log', file=sys.stderr)

    # ---------------------------------------------------------------- runs
    jobs = []
    if a.only in (None, 'unit'):
        for c in CONFIGS:
            for s in seeds:
                jobs.append(('unit', 'Verilator', c, s, [os.path.join(B, 'v_unit_' + c, 'Vtb'), f'+seed={s}'],
                             f'run_unit_{c}_vl_{s}.log'))
            if not a.no_icarus:
                jobs.append(('unit', 'Icarus', c, 1, ['vvp', '-n', os.path.join(B, 'iv_' + c + '.vvp'), '+seed=1'],
                             f'run_unit_{c}_iv_1.log'))
    if a.only in (None, 'soc'):
        for sc in ('dod', 'full'):
            jobs.append(('soc', 'Verilator', sc, 0, [os.path.join(B, 'v_soc', 'Vtb'), f'+scenario={sc}'],
                         f'run_soc_{sc}.log'))

    def do(j):
        kind, sim, cfg, seed, cmd, log = j
        rc, dt = run(cmd, os.path.join(B, log), timeout=7200)
        pat = r'(tb_nvme_ctrl NIOQ=\d+ EXT=\d+ seed=\d+: \d+ checks, \d+ failures, \d+ cycles -> \w+)' if kind == 'unit' \
            else r'(tb_nvme_ssd \w+: \d+ checks, \d+ failures, \d+ cycles -> \w+)'
        v, fails = verdict(os.path.join(B, log), pat)
        return kind, sim, cfg, seed, v, fails, dt, log

    with cf.ThreadPoolExecutor(a.j) as ex:
        for r in ex.map(do, jobs):
            rows.append(r)
            print(f'{r[0]:4} {r[1]:9} {r[2]:6} seed {r[3]}: {r[4]}  ({r[6]:.0f}s)')
            if r[5]:
                print(r[5])

    # ---------------------------------------------------------------- report
    ok = all(r[4] and r[4].endswith('PASS') for r in rows) and all(b[1] == 0 for b in builds)
    lines = ['# Regression report (generated by scripts/regress.py)', '',
             f'Date: {time.strftime("%Y-%m-%d %H:%M:%S")} · wall time {time.time() - t_start:.0f} s · '
             f'overall: **{"PASS" if ok else "FAIL"}**', '', '```', tools, '```', '',
             '## Builds', '', '| Target | Result | Time |', '|---|---|---|']
    for n, rc, dt in builds:
        lines.append(f'| {n} | {"ok" if rc == 0 else "FAILED (rc " + str(rc) + ")"} | {"< 1" if dt < 1 else f"{dt:.0f}"} s |')
    lines += ['', '## Unit testbench (`tb/unit/tb_nvme_ctrl.sv`: front end + transaction-level PCIe host + back-end model)',
              '', '| Config | Simulator | Seed | Verdict | Wall time | Log |', '|---|---|---|---|---|---|']
    for r in rows:
        if r[0] == 'unit':
            lines.append(f'| {r[2]} ({DESC[r[2]]}) | {r[1]} | {r[3]} | {r[4] or "NO VERDICT"} | {r[6]:.0f} s | build/{r[7]} |')
    lines += ['', '## SoC testbench (`tb/soc/tb_nvme_ssd.sv`: front end + unmodified ControlCore CPU + P51 firmware / FTL / NAND)',
              '', '| Scenario | Simulator | Verdict | Wall time | Log |', '|---|---|---|---|---|']
    for r in rows:
        if r[0] == 'soc':
            lines.append(f'| {r[2]} | {r[1]} | {r[4] or "NO VERDICT"} | {r[6]:.0f} s | build/{r[7]} |')
    lines += ['', 'Each verdict line is printed by the testbench itself after its last check; a run without a verdict '
              'line (crash, timeout) counts as a failure.', '']
    os.makedirs(os.path.join(ROOT, 'reports'), exist_ok=True)
    open(os.path.join(ROOT, 'reports', 'regression.md'), 'w').write('\n'.join(lines))
    print('overall', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
