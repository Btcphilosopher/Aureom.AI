#!/usr/bin/env python3
"""SilicaFlux-STORE Project 57 -- mutation check: do the testbenches catch planted RTL bugs?

Each mutant copies rtl/ to build/mut/<name>/rtl, applies ONE textual change, builds the unit testbench
(Verilator) and runs it (seed 1).  A mutant is KILLED if the run reports failures or produces no verdict.
Surviving unit-level mutants are also run through the SoC DoD scenario.  Writes reports/mutation.md.

  python3 -B scripts/mutate.py [-j N]
"""
import argparse, concurrent.futures as cf, os, re, shutil, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
MUT = os.path.join(ROOT, 'build', 'mut')
VFLAGS = ['--binary', '--timing', '-j', '2', '-Wno-fatal', '-Wno-lint', '-Wno-style', '-Wno-TIMESCALEMOD',
          '-Wno-MULTIDRIVEN', '-MAKEFLAGS', 'OPT_FAST=-O1']

# (name, file, original, mutated, what the bug is)
MUTANTS = [
    ('cq_phase', 'sfn_queue_mgr.sv',
     "if (cq_tail[po_qid*16 +: 16] == cq_size[po_qid*16 +: 16]) cq_ph[po_qid] <= ~cq_ph[po_qid];",
     "if (1'b0) cq_ph[po_qid] <= ~cq_ph[po_qid];",
     'CQ phase tag never inverts on wrap'),
    ('sq_tail_range', 'sfn_queue_mgr.sv',
     "wire           rng_ok = (db_val[31:16] == 16'h0) && (dval <= dsize);",
     "wire           rng_ok = 1'b1;",
     'SQ tail / CQ head doorbell value not range-checked'),
    ('cq_full', 'silicaflux_nvme_controller.sv',
     "if (cx_st[i] == CX_DONE && cq_v[q] && !cq_full[q] && (!cx_win[i] || wc_empty))",
     "if (cx_st[i] == CX_DONE && cq_v[q] && (!cx_win[i] || wc_empty))",
     'completion posted into a full CQ (overwrites an unconsumed entry)'),
    ('lba_range', 'silicaflux_nvme_controller.sv',
     "else if (d_io_rw && d_lend > {1'b0, be_capacity})",
     "else if (d_io_rw && d_lend > {1'b0, be_capacity} + 65'd1)",
     'LBA range check off by one'),
    ('prp_entry_offset', 'silicaflux_nvme_controller.sv',
     "if (pe_entry[11:0] != 12'h000 && pe_st == ST_OK) pe_st <= st(1, SCT_GEN, SC_PRP_OFFSET);",
     "if (1'b0) pe_st <= st(1, SCT_GEN, SC_PRP_OFFSET);",
     'PRP list entry offset not checked (first check site)'),
    ('cqe_before_data', 'silicaflux_nvme_controller.sv',
     "if (cx_st[i] == CX_DONE && cq_v[q] && !cq_full[q] && (!cx_win[i] || wc_empty))",
     "if (cx_st[i] == CX_DONE && cq_v[q] && !cq_full[q])",
     'CQE posted without draining buffered read data first (ordering)'),
    ('tlp_4k_cross', 'sfn_ep_adapter.sv',
     "wire [12:0]  w_chunk = min13(min13(w_rem, mps_eff), w_to4k);",
     "wire [12:0]  w_chunk = min13(w_rem, mps_eff);",
     'memory-write TLPs may cross a 4 KiB boundary (expected equivalent: no engine issues a crossing write)'),
    ('tlp_mps', 'sfn_ep_adapter.sv',
     "wire [12:0]  w_chunk = min13(min13(w_rem, mps_eff), w_to4k);",
     "wire [12:0]  w_chunk = min13(w_rem, w_to4k);",
     'memory-write TLPs not split at Max_Payload_Size'),
    ('tlp_mrrs', 'sfn_ep_adapter.sv',
     "wire [12:0] ri_chunk = min13(min13(ri_rem, mrrs_eff), ri_to4k);",
     "wire [12:0] ri_chunk = min13(min13(ri_rem, 13'(RSLOT_BYTES)), ri_to4k);",
     'memory-read TLPs not split at Max_Read_Request_Size'),
    ('cpl_tag_mixup', 'sfn_ep_adapter.sv',
     "if (rc_data_bt && !rc_overrun) rbuf[{rt, t_rcv[rt][SAW-1:0]}] <= rc_data;",
     "if (rc_data_bt && !rc_overrun) rbuf[{ap - TW'(1), t_rcv[rt][SAW-1:0]}] <= rc_data;",
     'completion data written to the most recently allocated tag instead of its own'),
    ('msi_on_post', 'sfn_irq.sv',
     "if (post_evt && cq_ien[post_qid]) req[cq_iv[post_qid*5 +: 5]] = 1'b1;",
     "if (1'b0) req[cq_iv[post_qid*5 +: 5]] = 1'b1;",
     'no MSI requested when a CQE is posted'),
    ('intx_mask', 'sfn_irq.sv',
     "assign intx_assert = !cfg_msi_en && !cfg_intx_dis && |(pend & ~mask);",
     "assign intx_assert = !cfg_msi_en && !cfg_intx_dis && |pend;",
     'INTMS mask ignored for pin-based interrupts'),
    ('cc_rsvd', 'silicaflux_nvme_pkg.sv',
     "localparam logic [31:0] CC_WMASK  = 32'h00FF_FFF1;",
     "localparam logic [31:0] CC_WMASK  = 32'hFFFF_FFFF;",
     'CC reserved bits writable'),
    ('prefetch_bound', 'sfn_hostwin.sv',
     "pf_lo <= OW'(off); pf_hi <= OW'(off); pf_rq <= OW'(off); pf_end <= OW'(lk_len);",
     "pf_lo <= OW'(off); pf_hi <= OW'(off); pf_rq <= OW'(off); pf_end <= OW'(lk_len) + OW'(4096);",
     'read-ahead runs up to 4 KiB past the end of the host buffer'),
    ('fua_dropped', 'silicaflux_nvme_controller.sv',
     "bd_cmd.flags = {6'd0, b_sqe[32*12 + 30] || !vwc_wce, 1'b0};",
     "bd_cmd.flags = {6'd0, !vwc_wce, 1'b0};",
     'FUA bit of Write not passed to the back end'),
    ('nsid_check', 'silicaflux_nvme_controller.sv',
     "else if (d_io_rw && d_nsid != 32'd1)",
     "else if (d_io_rw && d_nsid == 32'd0)",
     'I/O commands accepted for non-existent namespaces'),
]

NOTE = "## Survivors\n\n* `tlp_4k_cross` is an **equivalent mutant**: it removes the adapter's 4 KiB split for memory writes, but no engine ever asks for a crossing write. Write-combined data is collected per host memory page (sfn_hostwin: never across a page), CQEs are 16-byte writes into page-aligned queues, admin data is written per PRP page and MSI writes are 4 bytes. The TLP rule checker (no 4 KiB crossing) runs on every TLP in every regression run and would flag one if any engine produced it. The split stays in the adapter as protection for future engines.\n\n## History\n\n* An earlier campaign (before the final testbench) left `lba_range` and `prp_entry_offset` alive (the faulty case was masked or only the last list entry was tested) and `tlp_mrrs` alive (MRRS 128 B was only exercised when the random group drew it, never for seed 1). Each led to a deterministic test (`invalid`, `prp`, `dma` groups); all three are killed above.\n"


def prepare(name, f, orig, mut):
    d = os.path.join(MUT, name)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, 'rtl'), os.path.join(d, 'rtl'))
    p = os.path.join(d, 'rtl', f) if f != 'silicaflux_nvme_pkg.sv' else os.path.join(d, 'rtl', f)
    txt = open(p).read()
    n = txt.count(orig)
    if n < 1:
        raise SystemExit(f'mutant {name}: original text not found in {f}')
    open(p, 'w').write(txt.replace(orig, mut, 1))
    for fl in ('files_nvme.f', 'files_soc.f'):
        src = open(os.path.join(ROOT, 'rtl', fl)).read()
        src = re.sub(r'^rtl/', d.replace('\\', '/') + '/rtl/', src, flags=re.M)
        src = re.sub(r'^(\+incdir\+|)third_party/', r'\g<1>' + ROOT + '/third_party/', src, flags=re.M)
        open(os.path.join(d, fl), 'w').write(src)
    return d


def run(cmd, log, timeout=1800):
    with open(log, 'w') as fh:
        try:
            return subprocess.run(cmd, cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            return -1


def verdict(log, pat):
    t = open(log, errors='replace').read()
    m = re.findall(pat, t)
    if not m:
        return 'no verdict (hang / crash)', True
    fails = int(re.search(r'(\d+) failures', m[-1]).group(1))
    first = next((l for l in t.splitlines() if ' FAIL ' in l), '')
    return (f'{fails} failures; first: {first.strip()[:140]}' if fails else 'all checks passed'), fails > 0


def one(m):
    name, f, orig, mut, what = m
    d = prepare(name, f, orig, mut)
    t0 = time.time()
    rc = run(['verilator'] + VFLAGS + ['-Itb/unit', '-Itb/common', '-f', os.path.join(d, 'files_nvme.f'),
              'tb/common/sfn_tb_pcie_host.sv', 'tb/models/sfn_tb_backend.sv', 'tb/unit/tb_nvme_ctrl.sv',
              '--top-module', 'tb_nvme_ctrl', '-Mdir', os.path.join(d, 'v_unit'), '-o', 'Vtb'],
             os.path.join(d, 'build_unit.log'))
    if rc != 0:
        return name, what, 'build failed (compile-time kill)', True, '', time.time() - t0
    run([os.path.join(d, 'v_unit', 'Vtb'), '+seed=1'], os.path.join(d, 'unit.log'), timeout=600)
    v, killed = verdict(os.path.join(d, 'unit.log'), r'tb_nvme_ctrl NIOQ.*?-> \w+')
    soc = ''
    if not killed:
        rc = run(['verilator'] + VFLAGS + ['-Itb/common', '-Itb/soc', '-f', os.path.join(d, 'files_soc.f'),
                  'third_party/silicaflux-storagecore-p51/tb/models/sfs_nand_flash_model.sv',
                  'tb/common/sfn_tb_pcie_host.sv', 'tb/soc/tb_nvme_ssd.sv', '--top-module', 'tb_nvme_ssd',
                  '-Mdir', os.path.join(d, 'v_soc'), '-o', 'Vtb'], os.path.join(d, 'build_soc.log'))
        if rc == 0:
            run([os.path.join(d, 'v_soc', 'Vtb'), '+scenario=full'], os.path.join(d, 'soc.log'), timeout=900)
            soc, killed = verdict(os.path.join(d, 'soc.log'), r'tb_nvme_ssd \w+:.*?-> \w+')
    return name, what, v, killed, soc, time.time() - t0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('-j', type=int, default=2)
    ap.add_argument('--only', help='comma-separated mutant names')
    a = ap.parse_args()
    sel = [m for m in MUTANTS if not a.only or m[0] in a.only.split(',')]
    os.makedirs(MUT, exist_ok=True)
    rows = []
    with cf.ThreadPoolExecutor(a.j) as ex:
        for r in ex.map(one, sel):
            rows.append(r)
            print(f"{r[0]:18} {'KILLED' if r[3] else 'SURVIVED'}  {r[2][:100]}  {r[4][:60]}  ({r[5]:.0f}s)")
    k = sum(1 for r in rows if r[3])
    L = ['# Mutation check (generated by scripts/mutate.py)', '',
         f'{k} / {len(rows)} planted RTL bugs killed.  Each mutant is one textual change to a copy of `rtl/`; it '
         'is killed when the unit testbench (Verilator, seed 1) reports a failure or no verdict.  Mutants the unit '
         'testbench misses are also run through the full SoC scenario (real firmware, FTL and NAND).', '',
         '| Mutant | Planted bug | Unit testbench | SoC (if run) | Result |', '|---|---|---|---|---|']
    for name, what, v, killed, soc, dt in rows:
        L.append(f"| `{name}` | {what} | {v.replace('|', '/')} | {soc.replace('|', '/') or '-'} | "
                 f"{'**killed**' if killed else '**survived**'} |")
    L += ['', NOTE]
    open(os.path.join(ROOT, 'reports', 'mutation.md'), 'w').write('\n'.join(L))
    print(f'{k}/{len(rows)} killed')
    return 0


if __name__ == '__main__':
    sys.exit(main())
