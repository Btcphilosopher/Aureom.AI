# SilicaFlux-GFX — a small triangle renderer for the SilicaFlux compute architecture

A synthesizable-style SystemVerilog graphics **extension** to SilicaFlux v1.0: vertex input → restricted
vertex transform → homogeneous clipping → triangle setup → rasterisation (exact top-left rule) → depth test →
colour interpolation → framebuffer, with texture sampling added on top once the untextured pipeline was
verified. It attaches to the existing cluster through SilicaFlux's *documented* interfaces (work tokens,
D-format instructions, the reserved application-opcode range) and renders a rotating triangle and a
3D scene, checked **bit-for-bit** against a software reference rasteriser.

> **It is not an OpenGL or Vulkan implementation** and must not be described as one or as "conformant" to
> any graphics API. API integration is a separate future project. Details of what this is and is not:
> `docs/GFX_SPEC.md` §1, and the limitations below.

![scene](demo/out/scene_3d_sheet.png)

## Read first

| Document | Contents |
|---|---|
| `docs/GFX_SPEC.md` | **the contract**: coordinate conventions, fixed-point formats, edge inclusion, depth representation, overflow policy, registers |
| `docs/INTEGRATION.md` | how it plugs into SilicaFlux; what was changed in the baseline and why; **baseline defects found** |
| `docs/DISPLAY.md` | physical display output — kept separate from the engine; what is and is not verified |
| `docs/VERIFICATION.md` | test strategy, inventory, results, mutation campaign, accuracy, gaps |
| `docs/SYNTHESIS_STATUS.md` | what "synthesizable" is and is **not** backed by (no FPGA/ASIC run was done) |

## Quick start

```bash
./run_all.sh              # ~5 min: baseline regression, model tests, lints, RTL-vs-model, system, display
./run_all.sh --demos      # + regenerate the demos; every frame is compared RTL-vs-model
./run_all.sh --mutation   # + inject 19 bugs into the RTL and confirm the tests catch each one (~25 min)
```

Needs Python 3 with `pytest` and `pillow`, Verilator ≥ 5.0 (tested 5.020), Icarus Verilog (used only for the baseline's
own regression). Optional: `pyslang`, Yosys.

## Layout

```
rtl/            the rendering engine (standalone; no dependency on SilicaFlux)   gfx_pkg gfx_div gfx_ram gfx_fbmem
                                                                                 gfx_xform gfx_geom gfx_setup gfx_raster gfx_core
integration/    SilicaFlux attachment: gfx_tile (compute_tile-compatible), patch generator + diffs, programs, system tb
display/        scan-out controller, video timing, Pmod VGA adapter, monitor-model testbench  (NOT part of the engine)
model/          bit-exact Python reference rasteriser, independent exact-rational coverage oracle, scene helpers
tb/  sim/       engine testbench (command-file driven, framebuffer capture to PPM) and the pytest suites
tools/          simulation drivers, consistency/lint/audit/accuracy/mutation tools
demo/           demo generator and its output (GIFs, contact sheets, results.json)
third_party/    UNMODIFIED vendored copy of the SilicaFlux v1.0 baseline RTL (reference for the patch generator)
synth/          reproducible partial-synthesis script
```

## What was built, in the order requested

1. Vertex input, restricted transform, setup, clipping, rasterisation, depth test, colour interpolation, framebuffer
   writes — verified before anything else was added.
2. **Then** texture sampling (nearest, wrap/clamp, replace/modulate) and perspective-correct weights.
3. SilicaFlux integration; 4. display scan-out; 5. demos.

## Results at a glance (all reproducible with `run_all.sh`)

* **RTL = reference model, bit for bit**: colour buffers, depth buffer, all 14 counters, front/back selection and a
  stage-by-stage trace, over 58 + 24 directed/fuzz scenarios, **including shared-edge triangles, top-left tie
  cases on a half-pixel lattice, and 17 clipping boundary cases** (vertex on a plane, behind the eye, straddling
  near/far, enormous triangles, all six planes at once…).
* **The model itself is checked against an independent oracle** (exact rationals, a *geometric* definition of
  the top-left rule): 6 000 random triangles, no mismatch; shared-edge/mesh tests prove "covered exactly once".
* **Demos**: 120 frames (rotating triangle, 3D scene with cube + pyramid + checker floor, perspective-correct
  textured scene) — *every* frame captured from the RTL framebuffer equals the model's.
* **Integration**: a real SilicaFlux program on the baseline scalar core dispatches `GFXWR/GFXCLR/GFXDRAW/GFXPRES`
  through the scheduler; the 3-D cube frame matches the model. `gfx_tile`'s 26 `compute_tile` ports are identical
  (machine-checked). The baseline's own 7 testbenches still pass on the patched RTL.
* **Display**: scan-out decoded from its sync signals equals the framebuffer, on an asynchronous pixel clock, including
  the native 160×120×4 → 640×480 VESA raster.
* **The verification environment was tested too**: 19 deliberately injected RTL bugs (inverted fill rule, exclusive clip
  boundary, missing rounding, wrong cull sense, off-by-one bbox, …) — all caught (`docs/VERIFICATION.md`).

## Limitations you should know about (full list: `docs/GFX_SPEC.md` §16, `docs/SYNTHESIS_STATUS.md`)

* **Nothing was run on hardware and no synthesis/timing was done** — no Fmax, area or frame-rate claim exists.
  Cycle counts in `demo/out/results.json` are *simulated* engine clocks.
* **Interpolated depth is accurate to ≈ 15 bits** (measured max error ≈ 548 D24 LSB) even though the buffer is 24 bit.
* Physical display routes (Pmod VGA, DVI/HDMI encoder IP, on-board HDMI chip) are *documented*, not built or
  tested; pin constraints are deliberately left as an unfilled template.
* Engine compiles under Verilator only (not Icarus 12, not Yosys 0.33); slang elaborates it with 0 errors.
* Four **baseline** SilicaFlux defects were found (plus one by inspection) (scheduler token loss — fixed in the patched tree; distance-1 RAW hazard,
  branch-shadow execution, early `halt` — worked around in software). See `docs/INTEGRATION.md`.
* One triangle at a time; no blending, stencil, mip-mapping, filtering, lines or points.

`third_party/silicaflux-base/` is the baseline's own RTL (from this repository's `SilicaFlux-main.zip`), included
unmodified so that the patch generator and the regression are self-contained.
