// =============================================================================
// tb_gfx_core -- command-stream testbench for the rendering engine
//
//   +cmds=<file>   one command per line:  op space addr data   (all hex)
//   +out=<prefix>  writes  <prefix>.res   per-command  "err rdata"
//                          <prefix>.fb0 / .fb1   colour buffers (hex, 1 px/line)
//                          <prefix>.depth        depth buffer
//                          <prefix>.cnt          engine counters + front_sel
//
// Framebuffer capture is a simulation backdoor read of the dual-port memories;
// the host-visible path (GFX READ commands) is exercised separately.
// =============================================================================
`timescale 1ns/1ps
module tb_gfx_core;
  import gfx_pkg::*;
  parameter int FB_W       = 32;
  parameter int FB_H       = 24;
  parameter int VB_VERTS   = 256;
  parameter int IB_DEPTH   = 1024;
  parameter int TEX_LOG2W  = 6;
  parameter int TEX_LOG2H  = 6;
  parameter bit DOUBLE_BUF = 1'b1;
  parameter int MAX_CYCLES = 200_000_000;
  localparam int NPIX = FB_W * FB_H;
  localparam int AW   = $clog2(NPIX);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic        cmd_valid = 1'b0, cmd_ready, cmd_done, cmd_err;
  logic [2:0]  cmd_op = '0;
  logic [3:0]  cmd_space = '0;
  logic [31:0] cmd_addr = '0, cmd_wdata = '0, cmd_rdata;
  logic [23:0] scan_data;
  logic        front_sel;

  gfx_core #(.FB_W(FB_W), .FB_H(FB_H), .VB_VERTS(VB_VERTS), .IB_DEPTH(IB_DEPTH),
             .TEX_LOG2W(TEX_LOG2W), .TEX_LOG2H(TEX_LOG2H), .DOUBLE_BUF(DOUBLE_BUF)) dut (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_op(cmd_op), .cmd_space(cmd_space),
    .cmd_addr(cmd_addr), .cmd_wdata(cmd_wdata),
    .cmd_done(cmd_done), .cmd_err(cmd_err), .cmd_rdata(cmd_rdata),
    .scan_clk(clk), .scan_buf(front_sel), .scan_addr('0), .scan_data(scan_data),
    .front_sel_o(front_sel));

  int fres;
  longint unsigned cycles = 0;
  always @(posedge clk) begin
    cycles <= cycles + 1;
    if (cycles > MAX_CYCLES) begin
      $display("TB_TIMEOUT after %0d cycles", cycles);
      $finish;
    end
  end

  task automatic send(input logic [2:0] op, input logic [3:0] sp,
                      input logic [31:0] ad, input logic [31:0] wd);
    while (!cmd_ready) @(negedge clk);
    cmd_valid = 1'b1; cmd_op = op; cmd_space = sp; cmd_addr = ad; cmd_wdata = wd;
    @(negedge clk);
    cmd_valid = 1'b0;
    while (!cmd_done) @(negedge clk);
    $fdisplay(fres, "%0d %08x", cmd_err, cmd_rdata);
  endtask

  // ---- framebuffer capture: write the FRONT buffer as a binary PPM (P6) after every PRESENT
  string ppm_prefix = "";
  int    frame_no = 0;
  task automatic capture_front();
    int f;
    string fn;
    logic [23:0] px;
    fn = $sformatf("%s_%04d.ppm", ppm_prefix, frame_no);
    f = $fopen(fn, "wb");
    $fwrite(f, "P6\n%0d %0d\n255\n", FB_W, FB_H);
    for (int i = 0; i < NPIX; i++) begin
      px = front_sel ? dut.u_fb.cmem1[i] : dut.u_fb.cmem0[i];
      $fwrite(f, "%c%c%c", px[23:16], px[15:8], px[7:0]);
    end
    $fclose(f);
    $display("FRAME %0d cycle=%0d", frame_no, cycles);
    frame_no++;
  endtask

  task automatic dump(input string prefix);
    int f;
    f = $fopen({prefix, ".fb0"}, "w");
    for (int i = 0; i < NPIX; i++) $fdisplay(f, "%06x", dut.u_fb.cmem0[i]);
    $fclose(f);
    f = $fopen({prefix, ".fb1"}, "w");
    for (int i = 0; i < NPIX; i++) $fdisplay(f, "%06x", dut.u_fb.cmem1[i]);
    $fclose(f);
    f = $fopen({prefix, ".depth"}, "w");
    for (int i = 0; i < NPIX; i++) $fdisplay(f, "%06x", dut.u_fb.zmem[i]);
    $fclose(f);
    f = $fopen({prefix, ".cnt"}, "w");
    for (int i = 0; i < NUM_CNT; i++) $fdisplay(f, "%0d", dut.cnt[i]);
    $fdisplay(f, "%0d", front_sel);
    $fclose(f);
  endtask

  string cmdfile, outp;
  int fcmd, n;
  logic [31:0] op_i, sp_i, ad_i, wd_i;
  longint unsigned ncmd = 0;

  initial begin
    if (!$value$plusargs("cmds=%s", cmdfile)) begin $display("TB: +cmds= required"); $finish; end
    if (!$value$plusargs("out=%s", outp))     outp = "gfx_out";
    if (!$value$plusargs("ppm=%s", ppm_prefix)) ppm_prefix = "";
    fres = $fopen({outp, ".res"}, "w");
    fcmd = $fopen(cmdfile, "r");
    if (fcmd == 0) begin $display("TB: cannot open %s", cmdfile); $finish; end
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (2) @(negedge clk);
    while (!$feof(fcmd)) begin
      n = $fscanf(fcmd, "%h %h %h %h\n", op_i, sp_i, ad_i, wd_i);
      if (n == 4) begin
        send(op_i[2:0], sp_i[3:0], ad_i, wd_i);
        if (op_i[2:0] == CMD_PRESENT && ppm_prefix != "") capture_front();
        ncmd++;
      end
    end
    $fclose(fcmd);
    $fclose(fres);
    dump(outp);
    $display("TB_DONE cmds=%0d cycles=%0d", ncmd, cycles);
    $finish;
  end
endmodule
