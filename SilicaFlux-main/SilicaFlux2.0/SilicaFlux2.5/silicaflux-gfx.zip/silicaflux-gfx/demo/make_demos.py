#!/usr/bin/env python3
"""
Demonstrations rendered by the SilicaFlux-GFX RTL (Verilator simulation), 160x120.

  1. rotating triangle       RGB vertex colours, perspective, double-sided
  2. 3D scene                tessellated floor + spinning cube + pyramid piercing the cube,
                             orbiting camera, depth test, back-face culling, near-plane clipping
  3. textured scene          perspective-correct, modulated checker texture on cube + floor

EVERY frame of EVERY demo is captured from the RTL's framebuffer after PRESENT (PPM dump by the
testbench) and must equal the bit-exact reference model's front buffer; the script aborts otherwise.
Outputs (demo/out): GIF animations, contact sheets, PNG stills, results.json.
"""
import json, math, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "model"), str(ROOT / "tools")]
import gfxref as G, gfxsim as S, scene as SC                      # noqa: E402
from cmdgen import Cmds                                            # noqa: E402
from PIL import Image                                              # noqa: E402

W, H = 160, 120
P = G.Params(W=W, H=H)
OUT = ROOT / "demo" / "out"
ASPECT = W / H


def to_image(buf, scale=1):
    im = Image.new("RGB", (W, H))
    im.putdata([((v >> 16) & 255, (v >> 8) & 255, v & 255) for v in buf])
    return im.resize((W * scale, H * scale), Image.NEAREST) if scale > 1 else im


def upload(c, verts, idx, first_vtx=0, first_idx=0):
    for i, (x, y, z, col, u, v) in enumerate(verts):
        c.vertex(first_vtx + i, x, y, z, col, u, v)
    c.indices([first_vtx + k for k in idx], base=first_idx)
    return first_idx // 3, len(idx) // 3


def run(name, cmds, nframes):
    rtl = S.run_rtl(P, cmds, trace=False, ppm=True)
    g = G.Gfx(P); g.snap = True
    G.run_cmds(g, cmds)
    assert len(rtl["frames"]) == nframes == len(g.snapshots), (name, len(rtl["frames"]), len(g.snapshots))
    for i, (a, b) in enumerate(zip(rtl["frames"], g.snapshots)):
        assert a == b, "%s frame %d: RTL framebuffer differs from the reference model" % (name, i)
    cnt = dict(zip(G.CNT_NAMES, rtl["cnt"]))
    per = [rtl["frame_cycles"][0]] + [b - a for a, b in zip(rtl["frame_cycles"], rtl["frame_cycles"][1:])]
    print("%-18s %3d frames bit-exact vs model | cycles/frame min %d max %d | counters %s" % (
        name, nframes, min(per), max(per), {k: v for k, v in cnt.items() if v}))
    return rtl["frames"], dict(frames=nframes, bit_exact_frames=nframes, cycles_per_frame=per, counters=cnt,
                               total_sim_cycles=rtl["cycles"])


def save(name, frames, step_ms):
    OUT.mkdir(parents=True, exist_ok=True)
    ims2 = [to_image(f, 2) for f in frames]
    ims2[0].save(OUT / (name + ".gif"), save_all=True, append_images=ims2[1:], duration=step_ms, loop=0, optimize=True)
    to_image(frames[0], 4).save(OUT / (name + "_first.png"))
    to_image(frames[len(frames) // 3], 4).save(OUT / (name + "_mid.png"))
    # contact sheet: 12 evenly spaced frames, 4x3
    pick = [frames[int(i * len(frames) / 12)] for i in range(12)]
    sheet = Image.new("RGB", (4 * W + 5 * 4, 3 * H + 4 * 4), (24, 24, 24))
    for k, f in enumerate(pick):
        sheet.paste(to_image(f), (4 + (k % 4) * (W + 4), 4 + (k // 4) * (H + 4)))
    sheet.resize((sheet.width * 2, sheet.height * 2), Image.NEAREST).save(OUT / (name + "_sheet.png"))


# ------------------------------------------------------------------------------------------
def demo_triangle(n=36):
    c = Cmds().clear_colors(0x14141C)
    verts = [(-1.0, -0.8, 0, 0xFF3030, 0, 0), (1.0, -0.8, 0, 0x30FF30, 0, 0), (0.0, 1.0, 0, 0x3060FF, 0, 0)]
    first, cnt = upload(c, verts, [0, 1, 2])
    proj = SC.perspective(0.9, ASPECT, 0.5, 20.0)
    for f in range(n):
        th = 2 * math.pi * f / n
        # spin about a skewed axis (>45 deg off the screen plane) so the triangle never goes exactly edge-on;
        # the first half-turn shows its front, the second its back, hence cull = none below
        mv = SC.mat_mul(SC.translate(0, 0, -3.2), SC.rot_axis((0.4, 0.45, 0.8), th))
        c.mvp(SC.to_fx(SC.mat_mul(proj, mv)))
        c.rs(depth_en=1, depth_wr=1, func=1, cull=0).clear().draw(first, cnt).present()
    return c, n


def build_scene_geometry():
    fv, fi = SC.floor_grid(6, 9.0, -1.0)
    cv, ci = SC.cube(face_colors=[0xE04848, 0x48E048, 0x4870E8, 0xE8D048, 0x48D8E0, 0xD848E0], s=0.9)
    ci = SC.fix_winding(cv, ci, (0, 0, 0))
    pv, pi = SC.pyramid(0.75, 1.9)
    return (fv, fi), (cv, ci), (pv, pi)


def demo_scene(n=48):
    (fv, fi), (cv, ci), (pv, pi) = build_scene_geometry()
    c = Cmds().clear_colors(0x6C86B0)                        # sky
    vb = 0
    ff, fc = upload(c, fv, fi, vb, 0);                 vb += len(fv); ib = len(fi)
    cf, cc = upload(c, cv, ci, vb, ib);                vb += len(cv); ib += len(ci)
    pf, pc = upload(c, pv, pi, vb, ib)
    proj = SC.perspective(0.95, ASPECT, 0.35, 40.0)
    for f in range(n):
        a = 2 * math.pi * f / n
        eye = (7.0 * math.sin(a * 0.5 + 0.6), 2.6, 7.0 * math.cos(a * 0.5 + 0.6))
        view = SC.look_at(eye, (0, 0.2, 0), (0, 1, 0))
        pv_ = SC.mat_mul(proj, view)
        c.rs(depth_en=1, depth_wr=1, func=1, cull=1, front_ccw=1).clear()
        c.mvp(SC.to_fx(pv_));                                                       c.draw(ff, fc)       # floor
        m_cube = SC.mat_mul(SC.translate(-0.6, 0.0, 0), SC.mat_mul(SC.rot_y(a * 2), SC.rot_x(a)))
        c.mvp(SC.to_fx(SC.mat_mul(pv_, m_cube)));                                   c.draw(cf, cc)       # cube
        m_pyr = SC.translate(0.9 + 0.6 * math.sin(a * 2), -1.0, 0.3 * math.cos(a * 2))
        c.mvp(SC.to_fx(SC.mat_mul(pv_, m_pyr)));                                    c.draw(pf, pc)       # pyramid
        c.present()
    return c, n


def demo_textured(n=36):
    fv, fi = SC.floor_grid(4, 9.0, -1.0, 0xFFFFFF, 0xFFFFFF, uv_scale=1.0)
    cv, ci = SC.cube(face_colors=[0xFFB0B0, 0xB0FFB0, 0xB0B0FF, 0xFFFFB0, 0xB0FFFF, 0xFFB0FF], s=0.95)
    c = Cmds().clear_colors(0x384870)
    c.texture(SC.checker(6, 6, 8, 0xF2F2F2, 0x3050B8))
    vb = 0
    ff, fc = upload(c, fv, fi, vb, 0);          vb += len(fv); ib = len(fi)
    cf, cc = upload(c, cv, ci, vb, ib)
    proj = SC.perspective(1.0, ASPECT, 0.35, 40.0)
    for f in range(n):
        a = 2 * math.pi * f / n
        eye = (5.2 * math.sin(a * 0.25), 2.0, 5.2 * math.cos(a * 0.25))
        pv_ = SC.mat_mul(proj, SC.look_at(eye, (0, 0, 0), (0, 1, 0)))
        c.rs(depth_en=1, depth_wr=1, func=1, cull=1, front_ccw=1, tex=1, persp=1, modulate=1).clear()
        c.mvp(SC.to_fx(pv_));                                               c.draw(ff, fc)
        m_cube = SC.mat_mul(SC.translate(0, 0, 0), SC.mat_mul(SC.rot_y(a), SC.rot_x(a * 0.5)))
        c.mvp(SC.to_fx(SC.mat_mul(pv_, m_cube)));                           c.draw(cf, cc)
        c.present()
    return c, n


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    results = {}
    for name, fn, ms in (("rotating_triangle", demo_triangle, 80), ("scene_3d", demo_scene, 70),
                         ("scene_textured", demo_textured, 80)):
        cmds, n = fn()
        frames, info = run(name, cmds, n)
        save(name, frames, ms)
        results[name] = info
    results["config"] = dict(framebuffer="%dx%d" % (W, H), note="cycle counts are SIMULATED engine clocks; "
                             "no clock frequency or frame rate is claimed")
    (OUT / "results.json").write_text(json.dumps(results, indent=1))
    print("wrote", OUT)


if __name__ == "__main__":
    main()
