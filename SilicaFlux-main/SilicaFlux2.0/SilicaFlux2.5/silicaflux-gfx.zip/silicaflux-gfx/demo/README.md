# Demonstrations

`python3 make_demos.py` renders three scenes on the RTL at 160×120 (Verilator simulation of `gfx_core`) and, for
**every frame**, requires the framebuffer captured from the RTL (PPM dump after each `PRESENT`) to equal the reference
model's front buffer. It aborts if any frame differs. Outputs land in `out/`:

| File | Scene |
|---|---|
| `rotating_triangle.gif`, `_sheet.png`, `_first.png`, `_mid.png` | 36 frames: RGB-interpolated triangle tumbling about a skewed axis (perspective, double-sided) |
| `scene_3d.gif`, `_sheet.png`, … | 48 frames: tessellated checker floor, spinning cube, pyramid piercing the cube, orbiting camera; depth test, back-face culling, near-plane clipping (72+12+6 triangles per frame) |
| `scene_textured.gif`, `_sheet.png`, … | 36 frames: perspective-correct 64×64 checker on a floor and a modulated cube |
| `results.json` | per-frame **simulated** cycle counts, final counters, frame bit-exactness |

GIFs are 2× nearest-neighbour upscales; the PNG stills are 4×; the contact sheets are 12 evenly spaced frames at 2×.
Cycle counts are engine clocks in simulation; no frame rate is implied.
