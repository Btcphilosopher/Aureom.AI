#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-GFX -- run every check and print one verdict per step.
#
#   ./run_all.sh              fast path: everything except demos and the mutation campaign (~5 min)
#   ./run_all.sh --demos      also regenerate the demo frames (RTL vs model, every frame)   (+1 min)
#   ./run_all.sh --mutation   also run the 19-mutant campaign on the verification env       (+25 min)
#
# Requires: python3 (+pytest, pillow), Verilator >= 5.0 (tested 5.020), Icarus Verilog (baseline regression only).
# Optional: pyslang (`pip install pyslang`) for the slang elaboration step, Yosys for synth/yosys_blocks.sh.
# =============================================================================
set -u
cd "$(dirname "$0")"
DEMOS=0; MUT=0
for a in "$@"; do case "$a" in --demos) DEMOS=1;; --mutation) MUT=1;; esac; done
FAILS=(); RES=()
step() {                                   # step "name" cmd...
  local name="$1"; shift
  printf '\n\033[1m── %s\033[0m\n' "$name"
  if "$@"; then RES+=("PASS  $name"); else RES+=("FAIL  $name"); FAILS+=("$name"); fi
}

baseline_regression() {                    # the baseline's own 7 testbenches, on the PATCHED rtl, Icarus
  command -v iverilog >/dev/null || { echo "iverilog not found"; return 1; }
  python3 integration/apply_patches.py >/dev/null || return 1
  local R=build/sfx_regress; rm -rf "$R"; mkdir -p "$R/sim"
  cp -r build/sfx_gfx/rtl "$R/rtl"; cp -r third_party/silicaflux-base/tb "$R/tb"
  cp third_party/silicaflux-base/sim/run_sim.sh "$R/sim/"
  ( cd "$R/sim" && chmod +x run_sim.sh && ./run_sim.sh 2>&1 | sed 's/\x1b\[[0-9;]*m//g' | grep -E "✔|✘|PASSED:|ALL PASSED" ) | tee build/baseline_regression.txt
  grep -q "PASSED: 7  FAILED: 0" build/baseline_regression.txt
}
slang_step() { python3 -c "import pyslang" 2>/dev/null || { echo "pyslang not installed -- SKIPPED"; return 0; }; python3 tools/slang_check.py; }

mkdir -p build
step "baseline SilicaFlux regression (7 TBs) on the patched RTL [Icarus]"  baseline_regression
step "reference model + independent oracle self-tests"                    bash -c 'cd model && python3 -m pytest -q -p no:cacheprovider test_model.py'
step "model <-> RTL constants identical"                                  python3 tools/check_consts.py
step "gfx_tile port-compatible with compute_tile"                         python3 tools/check_tile_ports.py
step "SilicaFlux programs: RAW-hazard / branch-shadow lint"               python3 tools/check_raw_hazards.py integration/programs/*.sfx
step "RTL static audit (no non-synthesizable constructs)"                 python3 tools/audit_synth.py
step "slang strict elaboration"                                           slang_step
step "Verilator -Wall lint of the engine"                                 bash -c 'verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM --top-module gfx_core -GFB_W=32 -GFB_H=24 rtl/gfx_pkg.sv rtl/gfx_div.sv rtl/gfx_ram.sv rtl/gfx_fbmem.sv rtl/gfx_xform.sv rtl/gfx_geom.sv rtl/gfx_setup.sv rtl/gfx_raster.sv rtl/gfx_core.sv'
step "RTL vs model: untextured pipeline, shared edges, clipping, fuzz"    bash -c 'cd sim && python3 -m pytest -q -p no:cacheprovider test_rtl_phase1.py'
step "RTL vs model: texture + perspective-correct"                        bash -c 'cd sim && python3 -m pytest -q -p no:cacheprovider test_rtl_phase2.py'
step "gfx_tile token protocol (28 checks)"                                bash -c 'cd sim && python3 -m pytest -q -p no:cacheprovider test_tile.py'
step "system: SilicaFlux program -> scheduler -> graphics tile"           bash -c 'cd sim && python3 -m pytest -q -p no:cacheprovider test_system.py'
step "display: scan-out decoded from sync signals == framebuffer"         bash -c 'cd sim && python3 -m pytest -q -p no:cacheprovider test_display.py'
step "interpolation accuracy vs exact rationals"                          python3 tools/accuracy_report.py
if [ $DEMOS -eq 1 ]; then step "demos (every frame bit-exact vs model)"   bash -c 'cd demo && python3 make_demos.py'; fi
if [ $MUT   -eq 1 ]; then step "mutation campaign (19 injected RTL bugs)" bash -c 'python3 tools/mutation_check.py | tee build/mutation_results.txt'; fi

printf '\n\033[1m══════════ SUMMARY ══════════\033[0m\n'
for r in "${RES[@]}"; do echo "  $r"; done
if [ ${#FAILS[@]} -eq 0 ]; then printf '\n\033[32mALL %d STEPS PASSED\033[0m\n' "${#RES[@]}"; exit 0
else printf '\n\033[31m%d STEP(S) FAILED\033[0m\n' "${#FAILS[@]}"; exit 1; fi
