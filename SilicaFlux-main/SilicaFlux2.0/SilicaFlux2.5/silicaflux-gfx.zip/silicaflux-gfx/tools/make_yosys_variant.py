#!/usr/bin/env python3
"""Generate a Yosys-0.33-friendly copy of the engine RTL (scoped package names instead of
`import gfx_pkg::*`).  Only a mechanical rewrite for the tool's front-end; the shipped RTL is untouched."""
import re, shutil, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
pkg = (ROOT / "rtl" / "gfx_pkg.sv").read_text()
names = set(re.findall(r"localparam\s+(?:int|logic\s*\[[^\]]+\])\s+(\w+)", pkg)) | set(re.findall(r"\}\s*(\w+_t);", pkg)) | {"bitlen64", "depth_pass"}
for f in (ROOT / "rtl").glob("*.sv"):
    s = f.read_text()
    if f.name != "gfx_pkg.sv":
        s = re.sub(r"^\s*import gfx_pkg::\*;\s*$", "", s, flags=re.M)
        for n in sorted(names, key=len, reverse=True):
            s = re.sub(r"(?<![\w:.])%s(?!\w)" % re.escape(n), "gfx_pkg::" + n, s)
        s = s.replace("gfx_pkg::gfx_pkg::", "gfx_pkg::")
    (out / f.name).write_text(s)
print("wrote", out)
