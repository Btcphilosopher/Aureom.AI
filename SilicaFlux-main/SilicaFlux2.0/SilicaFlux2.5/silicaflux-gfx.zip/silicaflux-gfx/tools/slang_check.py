#!/usr/bin/env python3
"""Strict elaboration of the engine and display side with slang (pyslang) -- a third, independent
SystemVerilog front end next to Verilator and Icarus.  Exit status 0 == no errors."""
import sys
from pathlib import Path
import pyslang
from pyslang.driver import Driver

ROOT = Path(__file__).resolve().parent.parent
RTL = ["gfx_pkg.sv", "gfx_div.sv", "gfx_ram.sv", "gfx_fbmem.sv", "gfx_xform.sv", "gfx_geom.sv",
       "gfx_setup.sv", "gfx_raster.sv", "gfx_core.sv"]
DISP = ["video_timing.sv", "gfx_scanout.sv", "pmod_vga_adapter.sv"]


def run(top, files, extra=()):
    d = Driver()
    d.addStandardArgs()
    args = ["slang", "--top", top, "-DSYNTHESIS", "--timescale", "1ns/1ps", *extra] + [str(f) for f in files]
    ok = d.parseCommandLine(" ".join(args))
    ok = ok and d.processOptions() and d.parseAllSources()
    comp = d.createCompilation()
    d.reportCompilation(comp, False)                # prints diagnostics (returns None)
    diags = list(comp.getAllDiagnostics())
    nerr = sum(1 for x in diags if x.isError())
    nwarn = len(diags) - nerr
    print("%-14s: %s  (%d errors, %d warnings)" % (top, "OK" if ok and nerr == 0 else "ERRORS", nerr, nwarn))
    return 0 if ok and nerr == 0 else 1


def main():
    rtl = [ROOT / "rtl" / f for f in RTL]
    disp = [ROOT / "display" / f for f in DISP]
    rc = run("gfx_core", rtl, ["-GFB_W=160", "-GFB_H=120"])
    rc |= run("gfx_scanout", rtl + disp, [])
    return rc


if __name__ == "__main__":
    sys.exit(main())
