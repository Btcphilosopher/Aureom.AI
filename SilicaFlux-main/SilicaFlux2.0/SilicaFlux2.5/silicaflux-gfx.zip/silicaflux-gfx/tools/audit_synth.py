#!/usr/bin/env python3
"""
Static audit of the shipped RTL (rtl/, display/, integration/rtl/) for constructs that are not
synthesizable.  Simulation-only code is allowed ONLY inside `ifndef SYNTHESIS` or `ifdef GFX_TRACE /
GFX_TOKEN_TRACE` regions.  This is a style audit, NOT a synthesis run.
"""
import re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent

FORBIDDEN_ALWAYS = [
    (r"(?<![\w(])#\s*\d", "delay (#n)"),
    (r"\bfork\b|\bjoin(_any|_none)?\b", "fork/join"),
    (r"\bforce\b|\brelease\b", "force/release"),
    (r"\bwait\s*\(", "wait()"),
    (r"\$(u?random|urandom_range|dist_\w+)", "random system function"),
    (r"\bclass\b|\bprogram\b|\bcovergroup\b|\bconstraint\b", "class/program/coverage"),
]
SIM_ONLY = [
    (r"\binitial\b", "initial block"),
    (r"\$(display|write|fwrite|fdisplay|fopen|fclose|finish|stop|time|readmem[hb]|dump\w*|sformatf)", "system task"),
]
SIM_GUARDS = ("SYNTHESIS", "GFX_TRACE", "GFX_TOKEN_TRACE")


def audit(path):
    issues = []
    stack = []                         # list of bool: "inside a simulation-only region"
    for n, raw in enumerate(path.read_text().splitlines(), 1):
        line = re.sub(r"//.*", "", raw)
        m = re.match(r"\s*`(ifndef|ifdef|elsif|else|endif)\b\s*(\w*)", line)
        if m:
            k, name = m.groups()
            if k == "ifdef":    stack.append(name in ("GFX_TRACE", "GFX_TOKEN_TRACE"))
            elif k == "ifndef": stack.append(name == "SYNTHESIS")
            elif k == "else":   stack[-1] = (not stack[-1]) if stack else False
            elif k == "endif":  stack and stack.pop()
            continue
        in_sim = any(stack)
        for pat, what in FORBIDDEN_ALWAYS:
            if re.search(pat, line):
                issues.append("%s:%d  %s" % (path.name, n, what))
        if not in_sim:
            for pat, what in SIM_ONLY:
                if re.search(pat, line):
                    issues.append("%s:%d  %s outside a simulation guard" % (path.name, n, what))
    return issues


def main():
    files = sorted((ROOT / "rtl").glob("*.sv")) + sorted((ROOT / "display").glob("*.sv")) + \
            sorted((ROOT / "integration" / "rtl").glob("*.sv"))
    bad = []
    for f in files:
        bad += audit(f)
    print("audited %d RTL files: %s" % (len(files), "clean" if not bad else "%d issue(s)" % len(bad)))
    for b in bad: print("  ", b)
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
