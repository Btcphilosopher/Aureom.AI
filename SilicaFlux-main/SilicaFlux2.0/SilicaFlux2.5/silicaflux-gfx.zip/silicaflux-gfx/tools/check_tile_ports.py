#!/usr/bin/env python3
"""Verify gfx_tile exposes every compute_tile port with identical direction, type and width."""
import re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent

def ports(path, module):
    txt = path.read_text()
    txt = re.sub(r"//[^\n]*", "", txt)
    m = re.search(r"module\s+%s\b.*?\)\s*\(\s*(.*?)\n\s*\)\s*;" % module, txt, re.S)
    if not m:
        raise SystemExit("cannot parse %s" % module)
    body = m.group(1)
    out = {}
    for decl in re.finditer(r"\b(input|output)\s+(?:logic\s+)?(?:(noc_flit_t)\s+|(?:logic\s+)?(\[[^\]]+\])?\s*)(\w+)\s*(?:,|$)", body):
        direction, typ, rng, name = decl.groups()
        out[name] = (direction, typ or "logic", re.sub(r"\s+", "", rng or ""))
    return out

def main():
    base = ports(ROOT / "third_party/silicaflux-base/rtl/compute_tile.sv", "compute_tile")
    gfx = ports(ROOT / "integration/rtl/gfx_tile.sv", "gfx_tile")
    missing = [n for n in base if n not in gfx]
    differ = [(n, base[n], gfx[n]) for n in base if n in gfx and base[n] != gfx[n]]
    extra = [n for n in gfx if n not in base]
    print("compute_tile ports: %d   gfx_tile ports: %d   (extra sideband: %d)" % (len(base), len(gfx), len(extra)))
    for n, a, b in differ: print("DIFFERENT %s: %s vs %s" % (n, a, b))
    for n in missing: print("MISSING   %s" % n)
    print("extra (graphics sideband):", ", ".join(extra))
    ok = not missing and not differ
    print("PORT COMPATIBLE" if ok else "NOT COMPATIBLE")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
