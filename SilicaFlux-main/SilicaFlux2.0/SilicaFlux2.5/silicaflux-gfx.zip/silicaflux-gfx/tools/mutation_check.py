#!/usr/bin/env python3
"""
Mutation check of the verification environment.

Copies rtl/ to a scratch directory, injects ONE deliberate bug at a time, and
runs the RTL-vs-model suite against the mutated design.  A mutant that the
suite does not fail on is a hole in the tests ("survived").  The result table
is written to docs/MUTATION_RESULTS.md by the caller.
"""
import os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TESTS = os.environ.get("MUT_TESTS", "test_rtl_phase1.py")

MUTANTS = [
    # name, file, regex, replacement
    ("fill rule inverted (not top-left)", "gfx_setup.sv",
     r"bias_r\[ei\] <= !\(\(ea > 26'sd0\) \|\| \(ea == 26'sd0 && eb > 26'sd0\)\);",
     "bias_r[ei] <= ((ea > 26'sd0) || (ea == 26'sd0 && eb > 26'sd0));"),
    ("all edges inclusive (no tie-break)", "gfx_setup.sv",
     r"bias_r\[ei\] <= !\(\(ea > 26'sd0\) \|\| \(ea == 26'sd0 && eb > 26'sd0\)\);",
     "bias_r[ei] <= 1'b0;"),
    ("near plane exclusive (d>0 instead of d>=0)", "gfx_geom.sv",
     r"if \(plane_dist\(plane_r, pin\[i_r\]\) >= 36'sd0\) any_in", "if (plane_dist(plane_r, pin[i_r]) > 36'sd0) any_in"),
    ("depth LESS behaves as LEQUAL", "gfx_pkg.sv",
     r"3'd1: depth_pass = \(z <  zb\);", "3'd1: depth_pass = (z <= zb);"),
    ("transform rounding removed", "gfx_xform.sv",
     r"\(acc_n \+ 66'sd32768\)", "(acc_n + 66'sd0)"),
    ("colour rounding removed", "gfx_raster.sv",
     r"\+ \(1 << 27\);\n    gsum", "+ 0;\n    gsum"),
    ("weight sum not renormalised (w2 = ONE-w0)", "gfx_raster.sv",
     r"w2n = LAM_ONE - w0n - w1n;", "w2n = LAM_ONE - w0n;"),
    ("clip intersection from wrong end (not canonical)", "gfx_geom.sv",
     r"iv_in <= pin\[sh_next\]; iv_out <= pin\[i_r\];\n            d_in  <= pdist\[sh_next\]; d_out <= pdist\[i_r\];",
     "iv_in <= pin[i_r]; iv_out <= pin[sh_next];\n            d_in  <= pdist[i_r]; d_out <= pdist[sh_next];"),
    ("viewport y not flipped", "gfx_geom.sv",
     r"pnum   = pw \* 36'\(GB\) - \{\{4\{pc.y\[31\]\}\}, pc.y\};", "pnum   = pw * 36'(GB) + {{4{pc.y[31]}}, pc.y};"),
    ("cull sense inverted", "gfx_setup.sv",
     r"is_front = front_ccw \? !\(area2 > 0\) : \(area2 > 0\);|assign is_front = front_ccw \? !\(area2 > 0\) : \(area2 > 0\);",
     "assign is_front = front_ccw ? (area2 > 0) : !(area2 > 0);"),
    ("bbox max off by one pixel (misses last column)", "gfx_setup.sv",
     r"cx1 = \(fx1 > WIN_BITS'\(FB_W - 1\)\) \? WIN_BITS'\(FB_W - 1\) : fx1;",
     "cx1 = (fx1 > WIN_BITS'(FB_W - 1)) ? WIN_BITS'(FB_W - 1) : fx1 - 1;"),
    ("far plane ignored (no clip on plane 1)", "gfx_geom.sv",
     r"3'd1:    plane_dist = w - z;", "3'd1:    plane_dist = w + z;"),
    # ---- phase 2 (run against test_rtl_phase2.py)
    ("tex: clamp ignored (always wrap)", "gfx_raster.sv",
     r"taddr_r <= \{\(clamp_v \? ty_c : ty_w\), \(clamp_u \? tx_c : tx_w\)\};", "taddr_r <= {ty_w, tx_w};"),
    ("tex: u/v swapped in address", "gfx_raster.sv",
     r"taddr_r <= \{\(clamp_v \? ty_c : ty_w\), \(clamp_u \? tx_c : tx_w\)\};",
     "taddr_r <= {(clamp_u ? tx_c : tx_w), (clamp_v ? ty_c : ty_w)};"),
    ("tex: modulate rounding removed", "gfx_raster.sv",
     r"qr = 17'\(pr\) \+ 17'd128;", "qr = 17'(pr);"),
    ("tex: modulate behaves as replace", "gfx_raster.sv",
     r"end else if \(modulate\) begin", "end else if (1'b0) begin"),
    ("persp: attributes use screen weights", "gfx_raster.sv",
     r"m0 <= mu0; m1 <= mu1; m2 <= mu2;", "m0 <= l0; m1 <= l1; m2 <= l2;"),
    ("persp: reciprocal shift off by one", "gfx_raster.sv",
     r"shS <= 7'\(\$signed\(\{1'b0, nS\}\) - 7'sd4", "shS <= 7'($signed({1'b0, nS}) - 7'sd5"),
    ("tex: texel coordinate shift wrong", "gfx_raster.sv",
     r"tx_s = u_fx >>> \(FRAC - TEX_LOG2W\);", "tx_s = u_fx >>> (FRAC - TEX_LOG2W + 1);"),
]
PHASE2 = ("tex:", "persp:")


def main():
    only = sys.argv[1:]
    rows = []
    for name, fn, pat, rep in MUTANTS:
        if only and not any(o in name for o in only):
            continue
        tmp = Path(tempfile.mkdtemp(prefix="mut_"))
        shutil.copytree(ROOT / "rtl", tmp / "rtl")
        f = tmp / "rtl" / fn
        src = f.read_text()
        new, n = re.subn(pat, rep, src)
        if n == 0:
            rows.append((name, "PATTERN-NOT-FOUND")); print("%-52s PATTERN NOT FOUND" % name); continue
        f.write_text(new)
        env = dict(os.environ, GFX_RTL_DIR=str(tmp / "rtl"), GFX_BUILD_DIR=str(tmp / "build"))
        suite = "test_rtl_phase2.py" if name.startswith(PHASE2) else TESTS
        r = subprocess.run([sys.executable, "-m", "pytest", "-x", "-q", "-p", "no:cacheprovider",
                            str(ROOT / "sim" / suite)], env=env, capture_output=True, text=True, cwd=ROOT / "sim")
        killed = r.returncode != 0
        first = ""
        if killed:
            m = re.search(r"FAILED (\S+)", r.stdout)
            first = m.group(1).split("::")[-1] if m else "build/compile error?"
        rows.append((name, "killed by " + first if killed else "SURVIVED"))
        print("%-52s %s" % (name, rows[-1][1]), flush=True)
        shutil.rmtree(tmp, ignore_errors=True)
    surv = [r for r in rows if r[1] == "SURVIVED" or r[1] == "PATTERN-NOT-FOUND"]
    print("\n%d mutants, %d killed, %d survived/invalid" % (len(rows), len(rows) - len(surv), len(surv)))
    return 1 if surv else 0


if __name__ == "__main__":
    sys.exit(main())
