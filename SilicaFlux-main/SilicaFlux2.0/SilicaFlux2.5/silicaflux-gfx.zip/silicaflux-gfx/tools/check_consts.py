#!/usr/bin/env python3
"""The Python model and rtl/gfx_pkg.sv must agree on every architectural constant.
Parses the package and compares against model/gfxref.py; exit status 0 == identical."""
import re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
import gfxref as G

def pkg_consts():
    txt = (ROOT / "rtl" / "gfx_pkg.sv").read_text()
    out = {}
    for m in re.finditer(r"localparam\s+(?:int|logic\s*\[[^\]]+\])\s+(\w+)\s*=\s*([^;]+);", txt):
        name, val = m.group(1), m.group(2).strip()
        val = re.sub(r"//.*", "", val).strip()
        mm = re.fullmatch(r"(?:\d+)?'?[hHdD]?\s*([0-9A-Fa-f_]+)", val.replace("_", ""))
        if re.fullmatch(r"\d+", val): out[name] = int(val)
        elif re.fullmatch(r"\d+'h[0-9A-Fa-f_]+", val): out[name] = int(val.split("'h")[1].replace("_", ""), 16)
        elif re.fullmatch(r"\d+'d\d+", val): out[name] = int(val.split("'d")[1])
        elif re.fullmatch(r"32'h[0-9A-Fa-f_]+", val): out[name] = int(val.split("'h")[1].replace("_", ""), 16)
    return out

def main():
    c = pkg_consts()
    pairs = [("FRAC", G.FRAC), ("SUBPIX", G.SUBPIX), ("GB", G.GB), ("LAM_F", G.LAM_F), ("DEPTH_BITS", G.DEPTH_BITS),
             ("CLIP_T", G.CLIP_T), ("WIN_BITS", G.WIN_BITS), ("VTX_WORDS", G.VTX_WORDS), ("RECIP_MANT", G.RECIP_MANT),
             ("RECIP_NUM", G.RECIP_NUM), ("NUM_CNT", len(G.CNT_NAMES)),
             ("SP_CFG", G.SP_CFG), ("SP_VERT", G.SP_VERT), ("SP_IDX", G.SP_IDX), ("SP_TEX", G.SP_TEX),
             ("SP_COLOR", G.SP_COLOR), ("SP_DEPTH", G.SP_DEPTH), ("SP_FRONT", G.SP_FRONT),
             ("CMD_WRITE", G.OP_WRITE), ("CMD_READ", G.OP_READ), ("CMD_CLEAR", G.OP_CLEAR),
             ("CMD_DRAW", G.OP_DRAW), ("CMD_PRESENT", G.OP_PRESENT),
             ("CFG_ID", G.CFG_ID), ("CFG_STATUS", G.CFG_STATUS), ("CFG_RS", G.CFG_RS), ("CFG_CLR_COLOR", G.CFG_CLR_COLOR),
             ("CFG_CLR_DEPTH", G.CFG_CLR_DEPTH), ("CFG_FRONT", G.CFG_FRONT), ("CFG_MVP", G.CFG_MVP), ("CFG_CNT", G.CFG_CNT),
             ("CFG_CNT_CLEAR", G.CFG_CNT_CLEAR), ("GFX_ID", G.GFX_ID),
             ("RS_DEPTH_EN", G.RS_DEPTH_EN), ("RS_DEPTH_WR", G.RS_DEPTH_WR), ("RS_FUNC_LO", G.RS_DEPTH_FUNC_LO),
             ("RS_CULL_LO", G.RS_CULL_LO), ("RS_FRONT_CCW", G.RS_FRONT_CCW), ("RS_TEX_EN", G.RS_TEX_EN),
             ("RS_PERSP_EN", G.RS_PERSP_EN), ("RS_WRAP_U_CL", G.RS_WRAP_U_CLAMP), ("RS_WRAP_V_CL", G.RS_WRAP_V_CLAMP),
             ("RS_MODULATE", G.RS_MODULATE)]
    # counter indices must follow the model's name order
    names = ["TRIS_IN", "TRIS_XF_OVF", "TRIS_CLIPREJ", "TRIS_CLIPPED", "TRIS_DEGEN", "TRIS_CULLED", "TRIS_OFFSCR",
             "TRIS_RASTER", "FRAG_COV", "FRAG_ZFAIL", "FRAG_WRITTEN", "BAD_REF", "WIN_SAT", "CLIP_BAD_W"]
    pairs += [("CN_" + n, i) for i, n in enumerate(names)]
    bad = 0
    for k, v in pairs:
        if c.get(k) != v:
            print("MISMATCH %-14s rtl=%s model=%s" % (k, c.get(k), v)); bad += 1
    zmax = (1 << G.DEPTH_BITS) - 1
    print("checked %d constants: %s" % (len(pairs), "ALL MATCH" if not bad else "%d MISMATCH" % bad))
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
