#!/usr/bin/env python3
"""System-level driver: SilicaFlux program on the real scalar core drives the graphics tile."""
import os, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "model"), str(ROOT / "tools")]
import gfxref as G                                     # noqa: E402
import gfxsim as S                                     # noqa: E402

PATCHED_DIRS = {"fixed": ROOT / "build" / "sfx_gfx", "unfixed": ROOT / "build" / "sfx_gfx_unfixed"}
BASE_RTL = ["silicaflux_pkg.sv", "alu.sv", "forwarding_unit.sv", "fetch_unit.sv", "decoder.sv",
            "register_bank.sv", "vector_engine.sv", "tensor_unit.sv", "memory_controller.sv",
            "control_core.sv", "scheduler.sv", "compute_tile.sv", "noc_router.sv",
            "noc_interconnect.sv", "tile_interface.sv"]


def ensure_patched(variant="fixed"):
    args = [sys.executable, str(ROOT / "integration" / "apply_patches.py")]
    if variant == "unfixed":
        args += ["--no-scheduler-fix", "--out", str(PATCHED_DIRS["unfixed"])]
    subprocess.run(args, check=True, stdout=subprocess.DEVNULL)


def build(fbw, fbh, variant="fixed") -> Path:
    ensure_patched(variant)
    PATCHED = PATCHED_DIRS[variant]
    mdir = S.BUILD / ("sys_%s_%dx%d%s" % (variant, fbw, fbh, "_dbg" if os.environ.get("GFX_SYS_DEFS") else ""))
    exe = mdir / "tb"
    gfx = [str(ROOT / "rtl" / f) for f in S.RTL if f != "gfx_core.sv"] + [str(ROOT / "rtl" / "gfx_core.sv")]
    src = (gfx[:1] + gfx[1:] +
           [str(PATCHED / "rtl" / f) for f in BASE_RTL] +
           [str(PATCHED / "rtl" / "gfx_tile.sv"), str(PATCHED / "rtl" / "silicaflux_gfx_top.sv"),
            str(ROOT / "integration" / "tb" / "tb_silicaflux_gfx_top.sv")])
    newest = max(os.path.getmtime(s) for s in src)
    if exe.exists() and os.path.getmtime(exe) > newest:
        return exe
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
           "-O2", *os.environ.get("GFX_SYS_DEFS", "").split(), "-I" + str(PATCHED / "rtl"), "--top-module", "tb_silicaflux_gfx_top", "--Mdir", str(mdir),
           "-o", "tb", "-GFB_W=%d" % fbw, "-GFB_H=%d" % fbh] + src
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not exe.exists():
        raise RuntimeError("system build failed:\n" + r.stdout[-3000:] + r.stderr[-3000:])
    return exe


def assemble(asm_text: str, d: Path, variant="fixed") -> Path:
    src = d / "prog.sfx"
    src.write_text(asm_text)
    r = subprocess.run([sys.executable, str(PATCHED_DIRS[variant] / "sim" / "sfx_asm.py"), str(src), "-o", str(d / "prog"),
                        "--format", "hex"], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("assembler failed:\n" + r.stdout + r.stderr)
    return d / "prog.hex"


def run_system(p: G.Params, asm_text: str, host_loads, keep=False, variant="fixed"):
    exe = build(p.W, p.H, variant)
    d = Path(tempfile.mkdtemp(prefix="sys_", dir=str(S.BUILD)))
    hexf = assemble(asm_text, d, variant)
    ld = d / "ld.txt"
    ld.write_text("".join("%x %x %x %x\n" % c for c in host_loads))
    out = d / "out"
    r = subprocess.run([str(exe), "+prog=" + str(hexf), "+ld=" + str(ld), "+out=" + str(out)],
                       capture_output=True, text=True)
    if "TB_DONE" not in r.stdout:
        raise RuntimeError("system sim did not finish:\n" + r.stdout[-2000:])
    rd = lambda n: [int(x, 16) for x in (d / ("out." + n)).read_text().split()]
    cnt = [int(x) for x in (d / "out.cnt").read_text().split()]
    res = dict(fb0=rd("fb0"), fb1=rd("fb1"), depth=rd("depth"), cnt=cnt[:len(G.CNT_NAMES)],
               front=cnt[len(G.CNT_NAMES)], halted="TB_NO_HALT" not in r.stdout,
               cycles=int(r.stdout.split("cycles=")[1].split()[0]), stdout=r.stdout)
    if not keep:
        import shutil; shutil.rmtree(d, ignore_errors=True)
    return res


def compare_system(p, asm_text, host_loads, program_cmds, variant="fixed"):
    """program_cmds: the graphics commands the program is EXPECTED to issue, in order."""
    res = run_system(p, asm_text, host_loads, variant=variant)
    g = G.Gfx(p)
    G.run_cmds(g, list(host_loads) + list(program_cmds))
    bad = []
    if not res["halted"]:
        bad.append("program never reached HALT")
    nb = 2 if p.DOUBLE_BUF else 1
    for b in range(nb):
        if res["fb%d" % b][:len(g.color[b])] != g.color[b]:
            diff = [i for i in range(len(g.color[b])) if res["fb%d" % b][i] != g.color[b][i]]
            bad.append("colour buf %d differs in %d px (first x=%d y=%d)" % (b, len(diff), diff[0] % p.W, diff[0] // p.W))
    if res["depth"] != g.depth:
        bad.append("depth buffer differs")
    mc = [g.cnt[k] for k in G.CNT_NAMES]
    if res["cnt"] != mc:
        bad.append("counters rtl=%s model=%s" % (dict(zip(G.CNT_NAMES, res["cnt"])), dict(zip(G.CNT_NAMES, mc))))
    if res["front"] != g.front:
        bad.append("front_sel rtl=%d model=%d" % (res["front"], g.front))
    return bad, res, g
