#!/usr/bin/env python3
"""
Lint SilicaFlux assembly for the baseline's distance-1 RAW hazard.

The baseline forwarding unit compares the consumer against ex_mem only, which
is one cycle too late for an instruction directly behind its producer.  A
scalar-register producer (MOV/ADD/SUB/MUL/LOAD) must therefore be followed by
at least one unrelated instruction before a consumer reads that register.
Branch shadows (PC+1 and PC+5 execute after a taken branch) are also flagged.
"""
import re, sys
from pathlib import Path

PRODUCERS = {"MOV", "ADD", "SUB", "MUL", "LOAD"}
BRANCHES = {"BEQ", "BNE", "JMP"}


def parse(line):
    line = line.split(";")[0].strip()
    if not line: return None
    if ":" in line: line = line.split(":", 1)[1].strip()
    if not line or line.startswith("."): return None
    parts = line.split(None, 1)
    ops = [o for o in re.split(r"[,\s]+", parts[1]) if o] if len(parts) > 1 else []
    return parts[0].upper(), ops


def regs(ops):
    return {int(o[1:]) for o in ops if re.fullmatch(r"[rR]\d+", o)}


def lint(text):
    prog = [p for p in (parse(l) for l in text.splitlines()) if p]
    issues = []
    for i in range(len(prog) - 1):
        mn, ops = prog[i]
        if mn in PRODUCERS and ops:
            rd = int(ops[0][1:]) if re.fullmatch(r"[rR]\d+", ops[0]) else None
            nmn, nops = prog[i + 1]
            srcs = regs(nops) if nmn not in PRODUCERS else regs(nops[1:])
            if nmn in ("MOV",): srcs = set()
            if nmn in ("GFXWR", "GFXRD", "GFXDRAW") and len(nops) > 1: srcs = regs(nops[1:2])
            if rd not in (None, 0) and rd in srcs:
                issues.append("instr %d (%s %s) feeds instr %d (%s %s) directly: insert a NOP" %
                              (i, mn, ",".join(ops), i + 1, nmn, ",".join(nops)))
        if mn in BRANCHES:
            window = prog[i + 1:i + 7]
            bad = [w for w in window if w[0] not in ("NOP",)]
            if bad:
                issues.append("instr %d (%s): next 6 slots must be NOP (taken-branch shadow), found %s" % (i, mn, bad[0][0]))
    return issues


if __name__ == "__main__":
    rc = 0
    for f in sys.argv[1:]:
        iss = lint(Path(f).read_text())
        print("%s: %s" % (f, "OK" if not iss else ""))
        for m in iss: print("   ", m)
        rc |= bool(iss)
    sys.exit(rc)
