#!/usr/bin/env python3
"""Quantify the model's (== RTL's) interpolation error against exact rational ground truth."""
import random, sys
from fractions import Fraction as F
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
import gfxref as G

def main(seed=1, trials=4000):
    rng = random.Random(seed)
    W = H = 64
    worst_c = worst_z = 0.0
    sum_c = n = 0
    worst_lam = 0.0
    for _ in range(trials):
        v = [G.SV(rng.randrange(-8*256, 72*256), rng.randrange(-8*256, 72*256), rng.randrange(G.ZMAX+1), 0,
                  rng.randrange(256) << 8, rng.randrange(256) << 8, rng.randrange(256) << 8, 0, 0) for _ in range(3)]
        su, _ = G.tri_setup(v, W, H, 0, 0)
        if su is None: continue
        a, b, c = su.v
        step = max(1, (su.x1 - su.x0 + 1) // 6)
        for py in range(su.y0, su.y1 + 1, step):
            for px in range(su.x0, su.x1 + 1, step):
                e = G.edge_at(su, px, py)
                if not G.covered(su, e): continue
                lam = G.weights(e[0], e[1], su.rn)
                ideal = [F(x, su.area2) for x in e]
                worst_lam = max(worst_lam, max(abs(lam[i] / G.ONE - float(ideal[i])) for i in range(3)))
                z = (lam[0]*a.sz + lam[1]*b.sz + lam[2]*c.sz) >> G.LAM_F
                zi = float(ideal[0]*a.sz + ideal[1]*b.sz + ideal[2]*c.sz)
                worst_z = max(worst_z, abs(z - zi))
                for ch in "rgb":
                    acc = lam[0]*getattr(a, ch) + lam[1]*getattr(b, ch) + lam[2]*getattr(c, ch)
                    c8 = (acc + (1 << 27)) >> 28
                    ci = float(ideal[0]*getattr(a, ch) + ideal[1]*getattr(b, ch) + ideal[2]*getattr(c, ch)) / 256
                    err = abs(c8 - ci)
                    worst_c = max(worst_c, err); sum_c += err; n += 1
    print("samples: %d pixels x 3 channels" % n)
    print("max |weight error|          : %.3g  (= %.2f x 2^-%d)" % (worst_lam, worst_lam * G.ONE, G.LAM_F))
    print("max colour error            : %.3f of one 8-bit LSB (ideal round-to-nearest bound 0.5)" % worst_c)
    print("mean colour error           : %.3f LSB" % (sum_c / n))
    print("max depth error             : %.3f D24 LSB (truncation floor bound 1.0)" % worst_z)

if __name__ == "__main__":
    main()
