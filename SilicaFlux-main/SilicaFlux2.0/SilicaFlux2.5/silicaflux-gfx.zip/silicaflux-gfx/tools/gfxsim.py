#!/usr/bin/env python3
"""Build + run the RTL testbench and compare it with the reference model."""
import os, subprocess, sys, hashlib, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
import gfxref as G                       # noqa: E402

RTL = ["gfx_pkg.sv", "gfx_div.sv", "gfx_ram.sv", "gfx_fbmem.sv", "gfx_xform.sv",
       "gfx_geom.sv", "gfx_setup.sv", "gfx_raster.sv", "gfx_core.sv"]
BUILD = Path(os.environ.get("GFX_BUILD_DIR", ROOT / "build"))
BUILD.mkdir(parents=True, exist_ok=True)
RTL_DIR = Path(os.environ.get("GFX_RTL_DIR", ROOT / "rtl"))   # overridable for mutation testing


def build(p: G.Params, trace: bool = True) -> Path:
    tag = "%dx%d_vb%d_ib%d_t%dx%d_db%d_%s" % (p.W, p.H, p.VB_VERTS, p.IB_DEPTH, p.TEX_LOG2W,
                                               p.TEX_LOG2H, p.DOUBLE_BUF, "tr" if trace else "nt")
    mdir = BUILD / ("obj_" + tag)
    exe = mdir / "tb"
    srcs = [str(RTL_DIR / f) for f in RTL] + [str(ROOT / "tb" / "tb_gfx_core.sv")]
    newest = max(os.path.getmtime(s) for s in srcs)
    if exe.exists() and os.path.getmtime(exe) > newest:
        return exe
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-WIDTH", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
           "--top-module", "tb_gfx_core", "-O2", "--Mdir", str(mdir), "-o", "tb",
           "-GFB_W=%d" % p.W, "-GFB_H=%d" % p.H, "-GVB_VERTS=%d" % p.VB_VERTS,
           "-GIB_DEPTH=%d" % p.IB_DEPTH, "-GTEX_LOG2W=%d" % p.TEX_LOG2W,
           "-GTEX_LOG2H=%d" % p.TEX_LOG2H, "-GDOUBLE_BUF=%d" % p.DOUBLE_BUF]
    if trace:
        cmd.append("-DGFX_TRACE")
    cmd += srcs
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not exe.exists():
        raise RuntimeError("verilator build failed:\n" + r.stdout[-4000:] + r.stderr[-4000:])
    return exe


def run_rtl(p: G.Params, cmds, trace=True, tag="run", keep=False, ppm=False):
    exe = build(p, trace)
    d = Path(tempfile.mkdtemp(prefix="gfx_", dir=str(BUILD)))
    cf = d / "cmds.txt"
    cf.write_text("".join("%x %x %x %x\n" % c for c in cmds))
    out = d / "out"
    args = [str(exe), "+cmds=" + str(cf), "+out=" + str(out)]
    if ppm:
        args.append("+ppm=" + str(d / "frame"))
    r = subprocess.run(args, capture_output=True, text=True)
    if "TB_DONE" not in r.stdout:
        raise RuntimeError("simulation did not finish:\n" + r.stdout[-3000:] + r.stderr[-2000:])
    res = [tuple(int(x, 16) if i else int(x) for i, x in enumerate(l.split()))
           for l in (d / "out.res").read_text().splitlines()]
    rd = lambda n: [int(x, 16) for x in (d / ("out." + n)).read_text().split()]
    cnt = [int(x) for x in (d / "out.cnt").read_text().split()]
    traces = {}
    for line in r.stdout.splitlines():
        if line[:3] in ("XF ", "SC ", "SU ", "TD ") or line.startswith(("CR", "BW")):
            traces.setdefault(line[:2], []).append(line.split()[1:] if line[:2] in ("XF", "SC", "SU", "TD") else [])
    cyc = int(r.stdout.split("cycles=")[1].split()[0])
    frame_cycles = [int(l.split("cycle=")[1]) for l in r.stdout.splitlines() if l.startswith("FRAME ")]
    frames = []
    if ppm:
        for f in sorted(d.glob("frame_*.ppm")):
            frames.append(read_ppm(f))
    out_d = dict(frames=frames, frame_cycles=frame_cycles, res=res, fb0=rd("fb0"), fb1=rd("fb1"), depth=rd("depth"),
                 cnt=cnt[:len(G.CNT_NAMES)], front=cnt[len(G.CNT_NAMES)], traces=traces, cycles=cyc,
                 dir=str(d))
    if not keep:
        import shutil; shutil.rmtree(d, ignore_errors=True)
    return out_d


def read_ppm(path):
    data = Path(path).read_bytes()
    parts = data.split(b"\n", 3)
    assert parts[0] == b"P6", "not a P6 PPM"
    w, h = map(int, parts[1].split())
    body = parts[3]
    assert len(body) == w * h * 3, (len(body), w, h)
    return [(body[3*i] << 16) | (body[3*i+1] << 8) | body[3*i+2] for i in range(w * h)]


def run_model(p: G.Params, cmds, trace=True):
    g = G.Gfx(p)
    g.do_trace = trace
    res = G.run_cmds(g, cmds)
    return g, res


def compare(p: G.Params, cmds, trace=True, verbose=True):
    """Returns list of mismatch strings (empty == bit-exact)."""
    rtl = run_rtl(p, cmds, trace)
    g, res = run_model(p, cmds, trace)
    bad = []
    if rtl["res"] != res:
        for i, (a, b) in enumerate(zip(rtl["res"], res)):
            if a != b:
                bad.append("cmd %d %s: rtl=%s model=%s" % (i, cmds[i], a, b)); break
    nb = 2 if p.DOUBLE_BUF else 1
    for b in range(nb):
        m = g.color[b]; r = rtl["fb%d" % b]
        if r[:len(m)] != m:
            diff = [i for i in range(len(m)) if r[i] != m[i]]
            bad.append("colour buf %d: %d px differ, first (x=%d,y=%d) rtl=%06x model=%06x" % (
                b, len(diff), diff[0] % p.W, diff[0] // p.W, r[diff[0]], m[diff[0]]))
    if rtl["depth"] != g.depth:
        diff = [i for i in range(len(g.depth)) if rtl["depth"][i] != g.depth[i]]
        bad.append("depth: %d px differ, first (x=%d,y=%d) rtl=%06x model=%06x" % (
            len(diff), diff[0] % p.W, diff[0] // p.W, rtl["depth"][diff[0]], g.depth[diff[0]]))
    mc = [g.cnt[k] for k in G.CNT_NAMES]
    if rtl["cnt"] != mc:
        bad.append("counters rtl=%s model=%s" % (dict(zip(G.CNT_NAMES, rtl["cnt"])), dict(zip(G.CNT_NAMES, mc))))
    if rtl["front"] != g.front:
        bad.append("front_sel rtl=%d model=%d" % (rtl["front"], g.front))
    if trace:
        mt = {}
        for line in g.trace:
            tag = line[:2]
            mt.setdefault(tag, []).append(line.split()[1:] if tag in ("XF", "SC", "SU", "TD") else [])
        for tag in ("XF", "SC", "SU", "TD"):
            a, b = rtl["traces"].get(tag, []), mt.get(tag, [])
            if a != b:
                n = next((i for i in range(min(len(a), len(b))) if a[i] != b[i]), min(len(a), len(b)))
                bad.append("trace %s: rtl has %d lines, model %d; first diff at #%d\n   rtl  : %s\n   model: %s" % (
                    tag, len(a), len(b), n, " ".join(a[n]) if n < len(a) else "<none>",
                    " ".join(b[n]) if n < len(b) else "<none>"))
    return bad, rtl, g


if __name__ == "__main__":
    print(build(G.Params(W=32, H=24)))
