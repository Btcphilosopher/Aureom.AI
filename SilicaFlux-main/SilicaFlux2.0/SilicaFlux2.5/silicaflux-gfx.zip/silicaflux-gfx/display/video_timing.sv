// =============================================================================
// video_timing -- raster timing generator (display side; NOT part of the engine)
//
// Defaults are the VESA 640x480 @ 60 Hz timing (documented standard):
//   horizontal: 640 active + 16 front porch + 96 sync + 48 back porch = 800
//   vertical  : 480 active + 10 front porch +  2 sync + 33 back porch = 525
//   both syncs negative polarity;  nominal pixel clock 25.175 MHz (25.000 MHz is
//   within the tolerance of VGA/DVI sinks in practice -- verify with your display)
// `pix_ce` lets the generator run from a faster clock with a clock enable
// (e.g. clk/4) so no PLL is needed; tie to 1 when `clk` IS the pixel clock.
// All outputs are registered and mutually aligned.
// =============================================================================
module video_timing #(
  parameter int H_ACTIVE = 640, parameter int H_FP = 16, parameter int H_SYNC = 96, parameter int H_BP = 48,
  parameter int V_ACTIVE = 480, parameter int V_FP = 10, parameter int V_SYNC = 2,  parameter int V_BP = 33,
  parameter bit HS_ACTIVE_LOW = 1'b1,
  parameter bit VS_ACTIVE_LOW = 1'b1
) (
  input  logic clk,
  input  logic rst_n,
  input  logic pix_ce,
  output logic [$clog2(H_ACTIVE+H_FP+H_SYNC+H_BP)-1:0] h,
  output logic [$clog2(V_ACTIVE+V_FP+V_SYNC+V_BP)-1:0] v,
  output logic de,
  output logic hs,
  output logic vs,
  output logic frame_start            // high for the whole first pixel of a frame (h == 0, v == 0)
);
  localparam int H_TOTAL = H_ACTIVE + H_FP + H_SYNC + H_BP;
  localparam int V_TOTAL = V_ACTIVE + V_FP + V_SYNC + V_BP;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      h <= '0; v <= '0; de <= 1'b0; frame_start <= 1'b0;
      hs <= !HS_ACTIVE_LOW ? 1'b0 : 1'b1;
      vs <= !VS_ACTIVE_LOW ? 1'b0 : 1'b1;
    end else if (pix_ce) begin
      logic [$clog2(H_TOTAL)-1:0] hn;
      logic [$clog2(V_TOTAL)-1:0] vn;
      hn = (h == H_TOTAL - 1) ? '0 : h + 1'b1;
      vn = (h == H_TOTAL - 1) ? ((v == V_TOTAL - 1) ? '0 : v + 1'b1) : v;
      h <= hn; v <= vn;
      de <= (hn < H_ACTIVE) && (vn < V_ACTIVE);
      hs <= ((hn >= H_ACTIVE + H_FP) && (hn < H_ACTIVE + H_FP + H_SYNC)) ? !HS_ACTIVE_LOW : HS_ACTIVE_LOW;
      vs <= ((vn >= V_ACTIVE + V_FP) && (vn < V_ACTIVE + V_FP + V_SYNC)) ? !VS_ACTIVE_LOW : VS_ACTIVE_LOW;
      frame_start <= (hn == 0) && (vn == 0);
    end
  end
endmodule
