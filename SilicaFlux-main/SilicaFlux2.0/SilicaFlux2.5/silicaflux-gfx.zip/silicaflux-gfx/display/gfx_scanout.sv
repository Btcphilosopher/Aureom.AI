// =============================================================================
// gfx_scanout -- framebuffer scan-out (display side; NOT part of the engine)
//
// Reads the engine's scan port (gfx_fbmem: scan_clk/scan_buf/scan_addr/scan_data)
// and produces an RGB888 + DE/HS/VS pixel stream:
//
//     vid_r/g/b[7:0], vid_de, vid_hs, vid_vs         (clocked by pix_clk)
//
// That stream is the boundary to the board: it feeds a DAC/resistor network
// (Pmod VGA, see pmod_vga_adapter.sv), a DVI/HDMI TMDS encoder IP, or an
// external HDMI transmitter chip -- docs/DISPLAY.md lists the options.
//
//  * integer up-scaling by SCALE (power of two): FB 160x120 x4 -> 640x480
//  * the source is centred when SCALE*FB is smaller than the active area
//  * the front buffer index (from the engine, a different clock domain) is
//    synchronised with 2 flops and latched ONLY between frames, so a frame is
//    never torn between two buffers
//  * `pix_ce` as in video_timing; scan_clk must be the same clock as pix_clk
//    (the framebuffer memory is dual-clock: engine clock on the write side).
//    CE_DIV is the (fixed) number of pix_clk cycles per pixel enable.  The memory
//    needs one clock to return data, which is a whole pixel period when CE_DIV == 1
//    but only part of one when CE_DIV >= 2, so the pipeline depth depends on it.
// =============================================================================
module gfx_scanout #(
  parameter int FB_W   = 160,
  parameter int FB_H   = 120,
  parameter int SCALE  = 4,
  parameter int H_ACTIVE = 640, parameter int H_FP = 16, parameter int H_SYNC = 96, parameter int H_BP = 48,
  parameter int V_ACTIVE = 480, parameter int V_FP = 10, parameter int V_SYNC = 2,  parameter int V_BP = 33,
  parameter bit HS_ACTIVE_LOW = 1'b1,
  parameter bit VS_ACTIVE_LOW = 1'b1,
  parameter int CE_DIV  = 1                    // pix_clk cycles per pix_ce pulse (1 = pix_clk is the pixel clock)
) (
  input  logic          pix_clk,
  input  logic          rst_n,
  input  logic          pix_ce,
  input  logic          front_sel_async,        // from gfx_core.front_sel_o (engine clock domain)

  // framebuffer scan port
  output logic [$clog2(FB_W*FB_H)-1:0] scan_addr,
  output logic                         scan_buf,
  input  logic [23:0]                  scan_data,   // valid one clock after scan_addr

  // pixel stream
  output logic [7:0]    vid_r,
  output logic [7:0]    vid_g,
  output logic [7:0]    vid_b,
  output logic          vid_de,
  output logic          vid_hs,
  output logic          vid_vs
);
  localparam int SH = $clog2(SCALE);
  localparam int X0 = (H_ACTIVE - FB_W * SCALE) / 2;     // left border (pixels)
  localparam int Y0 = (V_ACTIVE - FB_H * SCALE) / 2;     // top border (lines)

  logic [$clog2(H_ACTIVE+H_FP+H_SYNC+H_BP)-1:0] h;
  logic [$clog2(V_ACTIVE+V_FP+V_SYNC+V_BP)-1:0] v;
  logic de0, hs0, vs0, fstart;
  video_timing #(.H_ACTIVE(H_ACTIVE), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
                 .V_ACTIVE(V_ACTIVE), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP),
                 .HS_ACTIVE_LOW(HS_ACTIVE_LOW), .VS_ACTIVE_LOW(VS_ACTIVE_LOW)) u_t (
    .clk(pix_clk), .rst_n(rst_n), .pix_ce(pix_ce), .h(h), .v(v), .de(de0), .hs(hs0), .vs(vs0),
    .frame_start(fstart));

  // ---- front-buffer synchroniser; the select is latched at the LAST pixel of the previous frame
  //      (inside blanking) so that even a picture that fills the raster never mixes two buffers
  localparam int H_TOTAL = H_ACTIVE + H_FP + H_SYNC + H_BP;
  localparam int V_TOTAL = V_ACTIVE + V_FP + V_SYNC + V_BP;
  logic fs_m, fs_s;
  always_ff @(posedge pix_clk or negedge rst_n) begin
    if (!rst_n) begin fs_m <= 1'b0; fs_s <= 1'b0; scan_buf <= 1'b0; end
    else begin
      fs_m <= front_sel_async; fs_s <= fs_m;
      if (pix_ce && (h == H_TOTAL - 1) && (v == V_TOTAL - 1)) scan_buf <= fs_s;
    end
  end

  // ---- source coordinates
  logic in_src;
  logic signed [15:0] xs, ys;
  assign xs = $signed(16'(h)) - 16'(X0);
  assign ys = $signed(16'(v)) - 16'(Y0);
  assign in_src = de0 && (xs >= 0) && (ys >= 0) && (xs < 16'(FB_W * SCALE)) && (ys < 16'(FB_H * SCALE));

  logic [$clog2(FB_W*FB_H)-1:0] addr_c;
  always_comb begin
    addr_c = '0;
    if (in_src) addr_c = $clog2(FB_W*FB_H)'((32'(ys) >> SH) * FB_W + (32'(xs) >> SH));
  end

  // ---- pipeline alignment
  //   CE_DIV == 1 : addr reg -> memory out reg -> vid reg            => LAT = 3 pixels
  //   CE_DIV >= 2 : addr reg -> (memory out is ready before the next enable) -> vid reg => LAT = 2
  localparam int LAT = (CE_DIV == 1) ? 3 : 2;
  logic [2:0] de_p, hs_p, vs_p, src_p;
  always_ff @(posedge pix_clk or negedge rst_n) begin
    if (!rst_n) begin
      scan_addr <= '0; de_p <= '0; hs_p <= {3{HS_ACTIVE_LOW}}; vs_p <= {3{VS_ACTIVE_LOW}}; src_p <= '0;
      vid_r <= '0; vid_g <= '0; vid_b <= '0;
    end else if (pix_ce) begin
      scan_addr <= addr_c;
      de_p  <= {de_p[1:0], de0};   hs_p <= {hs_p[1:0], hs0};   vs_p <= {vs_p[1:0], vs0};
      src_p <= {src_p[1:0], in_src};
      if (src_p[LAT-2]) begin vid_r <= scan_data[23:16]; vid_g <= scan_data[15:8]; vid_b <= scan_data[7:0]; end
      else begin vid_r <= 8'h00; vid_g <= 8'h00; vid_b <= 8'h00; end
    end
  end
  assign vid_de = de_p[LAT-1];
  assign vid_hs = hs_p[LAT-1];
  assign vid_vs = vs_p[LAT-1];
endmodule
