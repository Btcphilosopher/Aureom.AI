// =============================================================================
// pmod_vga_adapter -- RGB888 pixel stream -> Digilent Pmod VGA signal set
//
// Digilent's Pmod VGA is a documented board peripheral: a resistor-ladder DAC
// with 4 bits per colour (RGB444) plus HSYNC and VSYNC, driven directly by FPGA
// pins.  This adapter is the entire "PHY" side: it drops the 4 LSBs of each
// colour (truncation; round-to-nearest would need saturation logic) and
// blanks outside the active area, registering every output so pin timing is
// clean.  No vendor primitives are used.  See docs/DISPLAY.md for what is and
// is NOT verified (pin assignment is board/connector specific).
// =============================================================================
module pmod_vga_adapter (
  input  logic       pix_clk,
  input  logic       rst_n,
  input  logic       pix_ce,
  input  logic [7:0] vid_r, vid_g, vid_b,
  input  logic       vid_de, vid_hs, vid_vs,
  output logic [3:0] vga_r, vga_g, vga_b,
  output logic       vga_hs, vga_vs
);
  always_ff @(posedge pix_clk or negedge rst_n) begin
    if (!rst_n) begin
      vga_r <= '0; vga_g <= '0; vga_b <= '0; vga_hs <= 1'b1; vga_vs <= 1'b1;
    end else if (pix_ce) begin
      vga_r  <= vid_de ? vid_r[7:4] : 4'h0;
      vga_g  <= vid_de ? vid_g[7:4] : 4'h0;
      vga_b  <= vid_de ? vid_b[7:4] : 4'h0;
      vga_hs <= vid_hs;
      vga_vs <= vid_vs;
    end
  end
endmodule
