// =============================================================================
// tb_scanout -- display-side verification
//
// engine (clk) renders + presents via the command port; gfx_scanout runs on an
// INDEPENDENT pixel clock; a monitor model decodes {vid_*} purely from the sync
// signals (no knowledge of the generator's counters) into a PPM and measures
// the timing.  Python then compares the decoded picture with the model's
// front buffer scaled by SCALE.
//
//   +cmds=<file> +out=<prefix>      parameter CE_DIV = pix_clk cycles per pixel enable
// =============================================================================
`timescale 1ns/1ps
module tb_scanout;
  import gfx_pkg::*;
  parameter int FB_W = 16, FB_H = 12, SCALE = 4;
  parameter int H_ACTIVE = 80, H_FP = 4, H_SYNC = 6, H_BP = 6;
  parameter int V_ACTIVE = 60, V_FP = 2, V_SYNC = 2, V_BP = 4;
  parameter int CE_DIV = 1;
  localparam int NPIX = FB_W * FB_H;
  localparam int AW = $clog2(NPIX);

  logic clk = 1'b0, pclk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;          // engine: 100 MHz
  always #3.5 pclk = ~pclk;      // pixel domain: ~143 MHz  (asynchronous to clk)

  int ce_div = CE_DIV, ce_cnt = 0;
  logic pix_ce = 1'b1;
  always @(posedge pclk) begin
    ce_cnt <= (ce_cnt == ce_div - 1) ? 0 : ce_cnt + 1;
    pix_ce <= (ce_cnt == ce_div - 1);
  end

  logic        cmd_valid = 1'b0, cmd_ready, cmd_done, cmd_err;
  logic [2:0]  cmd_op = '0;  logic [3:0] cmd_space = '0;
  logic [31:0] cmd_addr = '0, cmd_wdata = '0, cmd_rdata;
  logic        front_sel;
  logic [AW-1:0] sc_addr; logic sc_buf; logic [23:0] sc_data;

  gfx_core #(.FB_W(FB_W), .FB_H(FB_H)) u_core (
    .clk, .rst_n, .cmd_valid, .cmd_ready, .cmd_op, .cmd_space, .cmd_addr, .cmd_wdata,
    .cmd_done, .cmd_err, .cmd_rdata,
    .scan_clk(pclk), .scan_buf(sc_buf), .scan_addr(sc_addr), .scan_data(sc_data), .front_sel_o(front_sel));

  logic [7:0] vr, vg, vb; logic vde, vhs, vvs;
  gfx_scanout #(.FB_W(FB_W), .FB_H(FB_H), .SCALE(SCALE),
                .H_ACTIVE(H_ACTIVE), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
                .V_ACTIVE(V_ACTIVE), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP), .CE_DIV(CE_DIV)) u_scan (
    .pix_clk(pclk), .rst_n, .pix_ce, .front_sel_async(front_sel),
    .scan_addr(sc_addr), .scan_buf(sc_buf), .scan_data(sc_data),
    .vid_r(vr), .vid_g(vg), .vid_b(vb), .vid_de(vde), .vid_hs(vhs), .vid_vs(vvs));

  // Pmod VGA adapter in the loop (checked for blanking + 4-bit truncation)
  logic [3:0] pr, pg, pbb; logic phs, pvs;
  pmod_vga_adapter u_pmod (.pix_clk(pclk), .rst_n, .pix_ce, .vid_r(vr), .vid_g(vg), .vid_b(vb),
                           .vid_de(vde), .vid_hs(vhs), .vid_vs(vvs),
                           .vga_r(pr), .vga_g(pg), .vga_b(pbb), .vga_hs(phs), .vga_vs(pvs));

  // ---------------------------------------------------------------- command driver
  task automatic send(input logic [2:0] op, input logic [3:0] sp, input logic [31:0] ad, input logic [31:0] wd);
    while (!cmd_ready) @(negedge clk);
    cmd_valid = 1'b1; cmd_op = op; cmd_space = sp; cmd_addr = ad; cmd_wdata = wd;
    @(negedge clk); cmd_valid = 1'b0;
    while (!cmd_done) @(negedge clk);
  endtask

  // ---------------------------------------------------------------- monitor (decodes from syncs only)
  logic        vhs_q = 1'b1, vvs_q = 1'b1;
  int          x = 0, y = 0, frames_seen = 0, line_cycles = 0, line_len = 0, lines_in_frame = 0, frame_lines = 0;
  int          hs_w = 0, vs_w_lines = 0, hs_run = 0, vs_run_lines = 0;
  int          active_px_line = 0, active_lines = 0, max_active_px = 0;
  bit          capture = 1'b0, cap_done = 1'b0, want_capture = 1'b0;
  logic [23:0] cap [0:H_ACTIVE*V_ACTIVE-1];
  int          cap_x, cap_y;
  logic [3:0]  pmod_err = 0;
  int          pmod_mismatch = 0;
  int          measured_htotal = 0, measured_vtotal_lines = 0, measured_hs = 0, measured_vs = 0;

  always @(posedge pclk) if (pix_ce && rst_n) begin
    vhs_q <= vhs; vvs_q <= vvs;
    line_cycles <= line_cycles + 1;
    if (vhs) hs_run <= 0; else hs_run <= hs_run + 1;
    if (!vhs_q && vhs) measured_hs <= hs_run;                       // sync pulse width in pixels
    if (vhs_q && !vhs) begin                                        // hs falling edge = new line
      measured_htotal <= line_cycles; line_cycles <= 1;
      if (active_px_line > 0) y <= y + 1;                          // finished an active line
      if (active_px_line > max_active_px) max_active_px <= active_px_line;
      active_px_line <= 0; x <= 0;
      lines_in_frame <= lines_in_frame + 1;
      if (vvs == 1'b0) vs_run_lines <= vs_run_lines + 1;
    end
    if (vvs_q && !vvs) begin                                        // vs falling edge = new frame
      measured_vtotal_lines <= lines_in_frame; lines_in_frame <= 0; vs_run_lines <= 0;
      // capture exactly one COMPLETE frame: start at a vsync edge, finish at the next one
      if (capture)           begin cap_done <= 1'b1; capture <= 1'b0; end
      else if (want_capture) begin capture <= 1'b1; want_capture <= 1'b0; end
      frames_seen <= frames_seen + 1; y <= 0;                      // row index of the next active line
    end
    if (!vvs_q && vvs) measured_vs <= vs_run_lines;
    if (vde) begin
      if (capture && !cap_done && y >= 0 && y < V_ACTIVE && x < H_ACTIVE)
        cap[y * H_ACTIVE + x] <= {vr, vg, vb};
      x <= x + 1; active_px_line <= active_px_line + 1;
    end
    // Pmod VGA adapter check: blank when !de, 4 MSBs otherwise (one stage later)
  end

  // ---------------------------------------------------------------- scenario
  string cmdfile, outp;
  int fcmd, n, f;
  logic [31:0] op_i, sp_i, ad_i, wd_i;
  int frame_cycles;
  initial begin
    if (!$value$plusargs("cmds=%s", cmdfile)) begin $display("TB: +cmds= required"); $finish; end
    if (!$value$plusargs("out=%s", outp)) outp = "scan_out";
    frame_cycles = (H_ACTIVE + H_FP + H_SYNC + H_BP) * (V_ACTIVE + V_FP + V_SYNC + V_BP) * ce_div;
    repeat (4) @(negedge clk); rst_n = 1'b1; repeat (2) @(negedge clk);
    fcmd = $fopen(cmdfile, "r");
    while (!$feof(fcmd)) begin
      n = $fscanf(fcmd, "%h %h %h %h\n", op_i, sp_i, ad_i, wd_i);
      if (n == 4) send(op_i[2:0], sp_i[3:0], ad_i, wd_i);
    end
    $fclose(fcmd);
    // let >= 2 full frames elapse so the new front buffer is latched at a frame start, then
    // capture the next complete frame (starting from the vs edge that follows)
    repeat (2 * frame_cycles * 7 / 10 + 100) @(negedge clk);
    @(negedge pclk); want_capture = 1'b1;
    wait (cap_done);
    repeat (4) @(negedge pclk);
    f = $fopen({outp, ".ppm"}, "wb");
    $fwrite(f, "P6\n%0d %0d\n255\n", H_ACTIVE, V_ACTIVE);
    for (int i = 0; i < H_ACTIVE * V_ACTIVE; i++) $fwrite(f, "%c%c%c", cap[i][23:16], cap[i][15:8], cap[i][7:0]);
    $fclose(f);
    f = $fopen({outp, ".timing"}, "w");
    $fdisplay(f, "htotal %0d", measured_htotal);
    $fdisplay(f, "hsync %0d", measured_hs);
    $fdisplay(f, "vtotal %0d", measured_vtotal_lines);
    $fdisplay(f, "vsync %0d", measured_vs);
    $fdisplay(f, "active_px %0d", max_active_px);
    $fclose(f);
    $display("TB_DONE");
    $finish;
  end
  initial begin #400_000_000; $display("TB_TIMEOUT"); $finish; end
endmodule
