"""
Self-tests of the reference model itself (no RTL involved).

These establish that the *model* is a trustworthy oracle before it is used to
judge the RTL:
  * fill rule == independent exact-rational geometric oracle
  * shared edges: every pixel covered exactly once (no gaps / no overlap)
  * barycentric weights: partition of unity, interpolation error bounds
  * clipping: boundary cases and invariants
"""
import random
from fractions import Fraction as F

import pytest

import gfxref as G
import oracle as O

SUB = 256


# ---------------------------------------------------------------- fill rule
def rand_tri(rng, W, H, lattice):
    def c(maxv):
        return rng.randrange(-2 * lattice, (maxv * SUB) // lattice + 2 * lattice) * lattice
    return [(c(W), c(H)) for _ in range(3)]


@pytest.mark.parametrize("lattice", [128, 64, 32, 1])
def test_fill_rule_matches_oracle(lattice):
    rng = random.Random(1234 + lattice)
    W = H = 10
    n_ties = 0
    for _ in range(1500):
        v = rand_tri(rng, W, H, lattice)
        got = G.coverage_mask(v, W, H)
        exp = O.coverage(v, W, H)
        assert got == exp, (v, sorted(got ^ exp))
        n_ties += 1
    assert n_ties


def test_fill_rule_pixel_on_vertex_and_edges():
    # Right triangle with a vertex exactly at a pixel centre (2.5, 2.5)
    c = 2 * SUB + 128
    v = [(c, c), (c + 4 * SUB, c), (c, c + 4 * SUB)]
    got = G.coverage_mask(v, 16, 16)
    assert got == O.coverage(v, 16, 16)
    # (2,2) centre is vertex 0 with top edge (v0->v1) and left edge (v2->v0): owned -> covered
    assert (2, 2) in got
    # hypotenuse pixel centres lie exactly on the edge: only top-left owners count
    assert (4, 4) not in got  # on hypotenuse, hypotenuse is a "bottom-right" edge


# ------------------------------------------------------------- shared edges
def _split_quad(q, diag):
    a, b, c, d = q
    return ([a, b, c], [a, c, d]) if diag == 0 else ([a, b, d], [b, c, d])


def test_quad_diagonals_cover_each_pixel_exactly_once():
    rng = random.Random(7)
    W = H = 12
    for _ in range(400):
        # axis-aligned rect on a half-pixel lattice -> every pixel centre interior to
        # or on the boundary of the rect is expected to be covered exactly as for a
        # single rectangle two-triangle split.
        x0 = rng.randrange(0, 6) * 128; y0 = rng.randrange(0, 6) * 128
        x1 = x0 + rng.randrange(1, 8) * 128; y1 = y0 + rng.randrange(1, 8) * 128
        q = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
        for diag in (0, 1):
            t0, t1 = _split_quad(q, diag)
            # both windings
            for flip in (0, 1):
                a = t0 if not flip else [t0[0], t0[2], t0[1]]
                b = t1 if not flip else [t1[0], t1[2], t1[1]]
                m0, m1 = G.coverage_mask(a, W, H), G.coverage_mask(b, W, H)
                assert not (m0 & m1), "double coverage on shared edge"
                # reference: pixels with centre in [x0,x1) x [y0,y1) (top-left rule on a rect)
                exp = {(px, py) for px in range(W) for py in range(H)
                       if x0 <= px * SUB + 128 < x1 and y0 <= py * SUB + 128 < y1}
                assert (m0 | m1) == exp, (q, diag, flip)


def test_random_mesh_no_gap_no_overlap():
    rng = random.Random(99)
    W, H = 20, 16
    for trial in range(60):
        nx, ny = rng.randrange(2, 6), rng.randrange(2, 6)
        xs = [i * (W * SUB // nx) for i in range(nx + 1)]
        ys = [j * (H * SUB // ny) for j in range(ny + 1)]
        pts = {}
        for j in range(ny + 1):
            for i in range(nx + 1):
                jx = 0 if i in (0, nx) else rng.randrange(-60, 61) * 2
                jy = 0 if j in (0, ny) else rng.randrange(-60, 61) * 2
                pts[(i, j)] = (xs[i] + jx, ys[j] + jy)
        count = {}
        for j in range(ny):
            for i in range(nx):
                a, b, c, d = pts[(i, j)], pts[(i+1, j)], pts[(i+1, j+1)], pts[(i, j+1)]
                tris = [[a, b, c], [a, c, d]] if rng.random() < .5 else [[a, b, d], [b, c, d]]
                for t in tris:
                    if rng.random() < .5:
                        t = [t[0], t[2], t[1]]
                    for p in G.coverage_mask(t, W, H):
                        count[p] = count.get(p, 0) + 1
        assert all(v == 1 for v in count.values()), "overlap"
        full = {(x, y) for x in range(W) for y in range(H)}
        assert set(count) == full, "gap: %s" % sorted(full - set(count))[:5]


# --------------------------------------------------------- weights / interp
def test_weights_partition_of_unity_and_error():
    rng = random.Random(5)
    worst = 0.0
    for _ in range(3000):
        W = H = 64
        v = [(rng.randrange(0, W * SUB), rng.randrange(0, H * SUB)) for _ in range(3)]
        sv = [G.SV(x, y, 0, 0, 0, 0, 0, 0, 0) for x, y in v]
        su, why = G.tri_setup(sv, W, H, 0, 0)
        if su is None:
            continue
        for py in range(su.y0, su.y1 + 1, 3):
            for px in range(su.x0, su.x1 + 1, 3):
                e = G.edge_at(su, px, py)
                if not G.covered(su, e):
                    continue
                l = G.weights(e[0], e[1], su.rn)
                assert sum(l) == G.ONE and min(l) >= 0
                for i in range(2):
                    ideal = e[i] / su.area2
                    worst = max(worst, abs(l[i] / G.ONE - ideal))
    # normalised-reciprocal error must stay far below 1/256 of a colour step
    assert worst < 2e-4, worst


def test_weights_extremes_big_and_tiny_triangles():
    # huge triangle (area near guard band limit) and 1-subpixel sliver
    big = [(-3 * 1024 * 128, -3 * 1024 * 128), (4 * 1024 * 128, 0), (0, 4 * 1024 * 128)]
    sv = [G.SV(x, y, 0, 0, 0, 0, 0, 0, 0) for x, y in big]
    su, _ = G.tri_setup(sv, 1024, 1024, 0, 0)
    e = G.edge_at(su, 100, 100)
    l = G.weights(e[0], e[1], su.rn)
    assert sum(l) == G.ONE
    # one-subpixel sliver whose bounding box contains pixel (0,0) but whose area
    # (1/2 subpixel^2) cannot contain the pixel centre: setup succeeds, coverage empty
    tiny = [(0, 0), (1, 0), (0, 1)]
    sv = [G.SV(x, y, 0, 0, 0, 0, 0, 0, 0) for x, y in tiny]
    su, why = G.tri_setup(sv, 4, 4, 0, 0)
    assert su is not None and su.area2 == 1
    assert G.coverage_mask(tiny, 4, 4) == set() == O.coverage(tiny, 4, 4)


def test_div255_round_exhaustive():
    for x in range(0, 255 * 255 + 1):
        assert G.div255_round(x) == (2 * x + 255) // 510, x


# ------------------------------------------------------------------- clipping
def cv(x, y, z, w, r=255, g=0, b=0):
    return G.CV(G.fx(x), G.fx(y), G.fx(z), G.fx(w), r << 8, g << 8, b << 8, 0, 0)


def test_clip_inside_unchanged_and_all_outside_rejected():
    t = [cv(-.5, -.5, .5, 1), cv(.5, -.5, .5, 1), cv(0, .5, .5, 1)]
    p, c = G.clip_polygon(t)
    assert p == t and not c
    behind = [cv(0, 0, -1, 1), cv(1, 0, -.5, 1), cv(0, 1, -2, 1)]
    p, c = G.clip_polygon(behind)
    assert p == []
    beyond_far = [cv(0, 0, 2, 1), cv(1, 0, 3, 1), cv(0, 1, 2.5, 1)]
    assert G.clip_polygon(beyond_far)[0] == []


def test_clip_vertex_exactly_on_planes_is_inside():
    # z == 0 (near plane) and z == w (far plane) and x == +-GB*w are inclusive
    t = [cv(0, 0, 0, 1), cv(.5, 0, 1, 1), cv(G.GB, 0, .5, 1)]
    p, c = G.clip_polygon(t)
    assert p == t and not c


def test_clip_near_straddle_produces_valid_polygon():
    t = [cv(-1, -1, -.5, 1), cv(1, -1, .5, 1), cv(0, 1, .5, 1)]
    p, c = G.clip_polygon(t)
    assert c and 3 <= len(p) <= 4
    for v in p:
        for k in range(6):
            assert G.plane_dist(k, v) >= -4, (k, v)       # rounding slack: a few raw LSBs


def test_clip_shared_edge_intersections_bit_identical():
    # two triangles sharing the edge A-B straddling the near plane must produce
    # the same intersection vertex regardless of traversal direction
    A = cv(-1, 0, -.3, 1, 10, 20, 30); B = cv(1, .2, .7, 1.3, 200, 100, 50)
    C = cv(0, 1, .4, 1, 0, 0, 0); D = cv(0, -1, .5, 1, 5, 6, 7)
    p1, _ = G.clip_polygon([A, B, C])
    p2, _ = G.clip_polygon([B, A, D])
    s1 = {v.t() for v in p1}; s2 = {v.t() for v in p2}
    common = s1 & s2
    assert len(common) >= 2, (s1, s2)    # the clipped point on AB and B itself


def test_clip_max_vertices_bound():
    rng = random.Random(3)
    for _ in range(3000):
        t = [G.CV(rng.randrange(-8 << 16, 8 << 16), rng.randrange(-8 << 16, 8 << 16),
                  rng.randrange(-4 << 16, 4 << 16), rng.randrange(-4 << 16, 6 << 16),
                  0, 0, 0, 0, 0) for _ in range(3)]
        p, _ = G.clip_polygon(t)
        assert len(p) <= 9


# ------------------------------------------------------------------ pipeline
def test_end_to_end_triangle_and_depth():
    g = G.Gfx(G.Params(W=16, H=16))
    ident = [G.fx(1), 0, 0, 0, 0, G.fx(1), 0, 0, 0, 0, G.fx(1), 0, 0, 0, 0, G.fx(1)]
    for i, m in enumerate(ident):
        g.write(G.SP_CFG, G.CFG_MVP + i, m)
    # NDC-sized triangle with z in [0,1]
    def vtx(i, x, y, z, col):
        o = i * G.VTX_WORDS
        for k, val in enumerate([G.fx(x), G.fx(y), G.fx(z), col, 0, 0]):
            g.write(G.SP_VERT, o + k, val)
    vtx(0, -.8, -.8, .5, 0xFF0000); vtx(1, .8, -.8, .5, 0x00FF00); vtx(2, 0, .8, .5, 0x0000FF)
    for i in range(3):
        g.write(G.SP_IDX, i, i)
    g.write(G.SP_CFG, G.CFG_RS, 1 | 2 | (1 << 2))     # depth test+write, LESS
    g.clear()
    g.draw(0, 1)
    assert g.cnt["tris_raster"] == 1 and g.cnt["frags_written"] > 50
    # all written fragments must have z strictly below clear depth
    assert g.cnt["frags_zfail"] == 0
    # second draw of identical depth fails LESS
    g.draw(0, 1)
    assert g.cnt["frags_zfail"] == g.cnt["frags_cov"] // 2


def test_depth_funcs():
    assert G.depth_pass(1, 1, 2) and not G.depth_pass(1, 2, 2)
    assert G.depth_pass(3, 2, 2) and not G.depth_pass(3, 3, 2)
    assert G.depth_pass(2, 2, 2) and not G.depth_pass(2, 1, 2)
    assert G.depth_pass(4, 3, 2) and not G.depth_pass(4, 2, 2)
    assert G.depth_pass(5, 3, 2) and not G.depth_pass(5, 2, 2)
    assert G.depth_pass(6, 2, 2) and not G.depth_pass(6, 1, 2)
    assert not G.depth_pass(0, 0, 0) and G.depth_pass(7, 0, 0)
