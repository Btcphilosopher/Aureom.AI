#!/usr/bin/env python3
"""
Independent coverage oracle for the SilicaFlux-GFX fill rule.

This deliberately shares NO code with gfxref.py's rasteriser.  It uses exact
rational arithmetic and a *geometric*, winding-independent definition of the
top-left rule:

  A pixel is covered iff its centre P satisfies, for the triangle (v0,v1,v2):
      * all three barycentric coordinates lambda_i >= 0   (exact Fractions), and
      * for every i with lambda_i == 0 (P lies on edge i, the edge opposite
        vertex i) that edge is an OWNED edge, where
          - a horizontal edge is owned iff the third vertex is BELOW it
            (window y grows downward)            -> "top edge"
          - a non-horizontal edge is owned iff the third vertex lies strictly
            to the RIGHT of the edge's supporting line      -> "left edge"

Because ownership depends only on which side the third vertex is on, two
triangles that share an edge from opposite sides always give the edge to
exactly one of them: no gaps, no double coverage.
"""
from fractions import Fraction as F
from typing import Iterable, List, Set, Tuple

SUB = 256


def _D(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])


def edge_owned(a, b, c) -> bool:
    if a[1] == b[1]:
        return c[1] > a[1]                          # top edge: interior below
    xline = F(a[0]) + F((b[0] - a[0]) * (c[1] - a[1]), (b[1] - a[1]))
    return F(c[0]) > xline                          # left edge: interior to the right


def covers(v: List[Tuple[int, int]], px: int, py: int) -> bool:
    total = _D(v[0], v[1], v[2])
    if total == 0:
        return False
    p = (px * SUB + SUB // 2, py * SUB + SUB // 2)
    lam = [F(_D(p, v[1], v[2]), total), F(_D(v[0], p, v[2]), total), F(_D(v[0], v[1], p), total)]
    if any(l < 0 for l in lam):
        return False
    edges = [(v[1], v[2], v[0]), (v[2], v[0], v[1]), (v[0], v[1], v[2])]
    for l, (a, b, c) in zip(lam, edges):
        if l == 0 and not edge_owned(a, b, c):
            return False
    return True


def coverage(v: List[Tuple[int, int]], W: int, H: int) -> Set[Tuple[int, int]]:
    xs = [p[0] for p in v]; ys = [p[1] for p in v]
    x0 = max(0, min(xs) // SUB); x1 = min(W - 1, max(xs) // SUB)
    y0 = max(0, min(ys) // SUB); y1 = min(H - 1, max(ys) // SUB)
    return {(x, y) for y in range(y0, y1 + 1) for x in range(x0, x1 + 1) if covers(v, x, y)}
