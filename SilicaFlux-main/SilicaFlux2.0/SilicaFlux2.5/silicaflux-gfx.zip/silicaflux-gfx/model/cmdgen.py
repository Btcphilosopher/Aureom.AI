"""Command-stream builder shared by tests, demos and the RTL testbench.

A command is (op, space, addr, data).  The same list drives both the Python
reference model (gfxref.run_cmds) and the RTL testbench (written as hex text).
"""
import gfxref as G


class Cmds(list):
    def w(self, space, addr, data):
        self.append((G.OP_WRITE, space, addr, data & 0xFFFFFFFF)); return self

    def r(self, space, addr):
        self.append((G.OP_READ, space, addr, 0)); return self

    # ---- configuration
    def mvp(self, m):
        for i, v in enumerate(m):
            self.w(G.SP_CFG, G.CFG_MVP + i, v)
        return self

    def rs(self, **kw):
        v = 0
        v |= (1 if kw.get("depth_en", 0) else 0) << G.RS_DEPTH_EN
        v |= (1 if kw.get("depth_wr", 0) else 0) << G.RS_DEPTH_WR
        v |= (kw.get("func", 1) & 7) << G.RS_DEPTH_FUNC_LO
        v |= (kw.get("cull", 0) & 3) << G.RS_CULL_LO
        v |= (1 if kw.get("front_ccw", 0) else 0) << G.RS_FRONT_CCW
        v |= (1 if kw.get("tex", 0) else 0) << G.RS_TEX_EN
        v |= (1 if kw.get("persp", 0) else 0) << G.RS_PERSP_EN
        v |= (1 if kw.get("clamp_u", 0) else 0) << G.RS_WRAP_U_CLAMP
        v |= (1 if kw.get("clamp_v", 0) else 0) << G.RS_WRAP_V_CLAMP
        v |= (1 if kw.get("modulate", 0) else 0) << G.RS_MODULATE
        return self.w(G.SP_CFG, G.CFG_RS, v)

    def clear_colors(self, rgb=0, depth=G.ZMAX):
        self.w(G.SP_CFG, G.CFG_CLR_COLOR, rgb)
        self.w(G.SP_CFG, G.CFG_CLR_DEPTH, depth)
        return self

    # ---- geometry upload
    def vertex(self, i, x, y, z, rgb=0xFFFFFF, u=0.0, v=0.0, raw=False):
        o = i * G.VTX_WORDS
        f = (lambda q: q) if raw else G.fx
        for k, val in enumerate([f(x), f(y), f(z), rgb, f(u), f(v)]):
            self.w(G.SP_VERT, o + k, val)
        return self

    def indices(self, idx, base=0):
        for k, v in enumerate(idx):
            self.w(G.SP_IDX, base + k, v)
        return self

    def texture(self, texels):
        for i, t in enumerate(texels):
            self.w(G.SP_TEX, i, t)
        return self

    # ---- actions
    def clear(self):   self.append((G.OP_CLEAR, 0, 0, 0)); return self
    def draw(self, first, count): self.append((G.OP_DRAW, 0, first, count)); return self
    def present(self): self.append((G.OP_PRESENT, 0, 0, 0)); return self

    def dump_text(self):
        return "".join("%x %x %x %x\n" % c for c in self)


IDENT = [G.fx(1), 0, 0, 0,  0, G.fx(1), 0, 0,  0, 0, G.fx(1), 0,  0, 0, 0, G.fx(1)]
