"""Host-side scene helpers: float math is fine HERE (it is the host/driver's
job to produce the Q16.16 matrix); the engine only ever sees raw integers."""
import math
import gfxref as G


def mat_mul(a, b):
    return [sum(a[4*i+k] * b[4*k+j] for k in range(4)) for i in range(4) for j in range(4)]


def rot_x(t):
    c, s = math.cos(t), math.sin(t)
    return [1, 0, 0, 0,  0, c, -s, 0,  0, s, c, 0,  0, 0, 0, 1]


def rot_y(t):
    c, s = math.cos(t), math.sin(t)
    return [c, 0, s, 0,  0, 1, 0, 0,  -s, 0, c, 0,  0, 0, 0, 1]


def rot_z(t):
    c, s = math.cos(t), math.sin(t)
    return [c, -s, 0, 0,  s, c, 0, 0,  0, 0, 1, 0,  0, 0, 0, 1]


def translate(x, y, z):
    return [1, 0, 0, x,  0, 1, 0, y,  0, 0, 1, z,  0, 0, 0, 1]


def scale(x, y, z):
    return [x, 0, 0, 0,  0, y, 0, 0,  0, 0, z, 0,  0, 0, 0, 1]


def perspective(fovy, aspect, n, f):
    """Right-handed eye space (camera looks down -z), clip depth range [0, w]."""
    t = 1.0 / math.tan(fovy / 2)
    return [t / aspect, 0, 0, 0,
            0, t, 0, 0,
            0, 0, f / (n - f), n * f / (n - f),
            0, 0, -1, 0]


def ortho(l, r, b, t, n, f):
    return [2 / (r - l), 0, 0, -(r + l) / (r - l),
            0, 2 / (t - b), 0, -(t + b) / (t - b),
            0, 0, 1 / (n - f), n / (n - f),
            0, 0, 0, 1]


def to_fx(m):
    return [G.fx(v) for v in m]


def ndc_from_window(X, Y, W, H):
    """Window pixel coords (floats) -> NDC for an identity-matrix, w == 1 draw."""
    return X * 2.0 / W - 1.0, 1.0 - Y * 2.0 / H


def checker(log2w=6, log2h=6, tile=8, c0=0xF0F0F0, c1=0x2040C0):
    w, h = 1 << log2w, 1 << log2h
    return [c0 if ((x // tile) + (y // tile)) & 1 == 0 else c1 for y in range(h) for x in range(w)]


def gradient_texture(log2w=6, log2h=6):
    w, h = 1 << log2w, 1 << log2h
    return [((x * 255 // (w - 1)) << 16) | ((y * 255 // (h - 1)) << 8) | 0x80 for y in range(h) for x in range(w)]


# Unit cube: 24 vertices (4 per face, own colour/uv), 12 triangles
def cube(face_colors=None, s=1.0):
    fc = face_colors or [0xE04040, 0x40E040, 0x4040E0, 0xE0E040, 0x40E0E0, 0xE040E0]
    faces = [  # (normal-axis, 4 corners ccw seen from outside)
        ([(-s, -s,  s), ( s, -s,  s), ( s,  s,  s), (-s,  s,  s)]),   # +z
        ([( s, -s, -s), (-s, -s, -s), (-s,  s, -s), ( s,  s, -s)]),   # -z
        ([( s, -s,  s), ( s, -s, -s), ( s,  s, -s), ( s,  s,  s)]),   # +x
        ([(-s, -s, -s), (-s, -s,  s), (-s,  s,  s), (-s,  s, -s)]),   # -x
        ([(-s,  s,  s), ( s,  s,  s), ( s,  s, -s), (-s,  s, -s)]),   # +y
        ([(-s, -s, -s), ( s, -s, -s), ( s, -s,  s), (-s, -s,  s)]),   # -y
    ]
    uv = [(0, 1), (1, 1), (1, 0), (0, 0)]
    verts, idx = [], []
    for f, corners in enumerate(faces):
        base = len(verts)
        for k, (x, y, z) in enumerate(corners):
            verts.append((x, y, z, fc[f], uv[k][0], uv[k][1]))
        idx += [base, base + 1, base + 2, base, base + 2, base + 3]
    return verts, idx


# ---------------------------------------------------------------- camera / geometry helpers
def _sub(a, b): return [a[i] - b[i] for i in range(3)]
def _cross(a, b): return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def _dot(a, b): return sum(a[i]*b[i] for i in range(3))
def _norm(a):
    l = math.sqrt(_dot(a, a)); return [x / l for x in a]


def look_at(eye, target, up=(0, 1, 0)):
    """Right-handed view matrix; the camera looks down its own -z axis."""
    f = _norm(_sub(target, eye))
    s = _norm(_cross(f, up))
    u = _cross(s, f)
    return [s[0], s[1], s[2], -_dot(s, eye),
            u[0], u[1], u[2], -_dot(u, eye),
            -f[0], -f[1], -f[2], _dot(f, eye),
            0, 0, 0, 1]


def fix_winding(verts, idx, centre):
    """Re-order each triangle so that its geometric normal points away from `centre`
    (counter-clockwise when seen from outside, right-handed)."""
    out = []
    for t in range(0, len(idx), 3):
        a, b, c = (verts[i] for i in idx[t:t+3])
        n = _cross(_sub(b[:3], a[:3]), _sub(c[:3], a[:3]))
        mid = [(a[k] + b[k] + c[k]) / 3 - centre[k] for k in range(3)]
        out += [idx[t], idx[t+1], idx[t+2]] if _dot(n, mid) > 0 else [idx[t], idx[t+2], idx[t+1]]
    return out


def pyramid(base=0.8, height=1.7, colors=(0xE0A030, 0xD04080, 0x40B0E0, 0x80D040, 0x909090)):
    b = base
    apex = (0, height, 0)
    corners = [(-b, 0, -b), (b, 0, -b), (b, 0, b), (-b, 0, b)]
    verts, idx = [], []
    for k in range(4):
        p, q = corners[k], corners[(k + 1) % 4]
        base_i = len(verts)
        for pt in (p, q, apex):
            verts.append((pt[0], pt[1], pt[2], colors[k], 0.0, 0.0))
        idx += [base_i, base_i + 1, base_i + 2]
    bi = len(verts)
    for pt in corners:
        verts.append((pt[0], pt[1], pt[2], colors[4], 0.0, 0.0))
    idx += [bi, bi + 1, bi + 2, bi, bi + 2, bi + 3]
    return verts, fix_winding(verts, idx, (0, height * 0.3, 0))


def floor_grid(n=6, half=9.0, y=-1.0, c0=0x587058, c1=0x203820, uv_scale=1.0):
    verts, idx = [], []
    step = 2 * half / n
    for j in range(n):
        for i in range(n):
            x0, z0 = -half + i * step, -half + j * step
            col = c0 if (i + j) & 1 == 0 else c1
            b = len(verts)
            for (x, z, u, v) in [(x0, z0, i, j), (x0 + step, z0, i + 1, j),
                                 (x0 + step, z0 + step, i + 1, j + 1), (x0, z0 + step, i, j + 1)]:
                verts.append((x, y, z, col, u * uv_scale, v * uv_scale))
            idx += [b, b + 2, b + 1, b, b + 3, b + 2]       # normal +y (CCW seen from above)
    return verts, idx


def rot_axis(axis, t):
    """Rotation by angle t about an arbitrary axis (Rodrigues)."""
    x, y, z = _norm(list(axis))
    c, s = math.cos(t), math.sin(t)
    k = 1 - c
    return [c + x*x*k,   x*y*k - z*s, x*z*k + y*s, 0,
            y*x*k + z*s, c + y*y*k,   y*z*k - x*s, 0,
            z*x*k - y*s, z*y*k + x*s, c + z*z*k,   0,
            0, 0, 0, 1]
