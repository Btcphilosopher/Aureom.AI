#!/usr/bin/env python3
"""
SilicaFlux-GFX  --  bit-exact software reference rasteriser
===========================================================

This module is the *executable specification* of the SilicaFlux graphics
extension.  Every arithmetic step uses Python integers with the exact
widths, shifts and rounding rules of the RTL in ../rtl, so the RTL
framebuffer must equal this model's framebuffer bit for bit.

It is deliberately written in the same stage order as the hardware:

    vertex fetch -> restricted transform -> clip (homogeneous) -> projection
    -> triangle setup -> rasterise (top-left rule) -> depth test
    -> colour / texture -> framebuffer write

Nothing here is a conformant OpenGL/Vulkan implementation.  See
docs/GFX_SPEC.md for the full contract (coordinate conventions, fixed-point
formats, edge inclusion, depth representation, overflow policy).

Conventions in one paragraph
----------------------------
Clip space is right-handed with x right, y up, depth range [0, w]:
a point is inside the view volume iff  -w <= x <= w, -w <= y <= w, 0 <= z <= w.
Window space has its origin at the top-left corner of the framebuffer,
+x right, +y DOWN; pixel (i, j) has its sample point at its centre
(i + 1/2, j + 1/2).  All window coordinates are integers in units of
1/256 pixel.  A pixel is covered if its centre is strictly inside the
triangle, or exactly on an edge that is a *top* or *left* edge.
"""
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# ----------------------------------------------------------------------------
# Architecture constants.  MUST match rtl/gfx_pkg.sv (checked by
# tools/check_consts.py).
# ----------------------------------------------------------------------------
FRAC       = 16                 # Q16.16 for object/clip space and matrix
SUBPIX     = 8                  # window coordinates: 1/256 pixel
GB         = 4                  # guard-band factor: |x|,|y| <= GB*w
LAM_F      = 20                 # barycentric weight fraction bits
ONE        = 1 << LAM_F
DEPTH_BITS = 24
ZMAX       = (1 << DEPTH_BITS) - 1
IW_FRAC    = 24                 # reciprocal-w, unsigned Q8.24
IW_MAX     = (1 << 32) - 1
CLIP_T     = 24                 # clip intersection parameter fraction bits
WIN_BITS   = 24                 # saturation range of window coordinates
VTX_WORDS  = 8                  # words per vertex record
RECIP_MANT = 16                 # normalised-reciprocal mantissa bits
RECIP_NUM  = 24                 # numerator is truncated to this many bits
CNT_MAX    = (1 << 32) - 1

# Render-state register bit positions
RS_DEPTH_EN, RS_DEPTH_WR = 0, 1
RS_DEPTH_FUNC_LO         = 2      # [4:2]
RS_CULL_LO               = 5      # [6:5]
RS_FRONT_CCW             = 7
RS_TEX_EN                = 8
RS_PERSP_EN              = 9
RS_WRAP_U_CLAMP          = 10
RS_WRAP_V_CLAMP          = 11
RS_MODULATE              = 12

# Address spaces
SP_CFG, SP_VERT, SP_IDX, SP_TEX, SP_COLOR, SP_DEPTH, SP_FRONT = 0, 1, 2, 3, 4, 5, 6

# CFG register map (word addresses)
CFG_ID, CFG_STATUS, CFG_RS, CFG_CLR_COLOR, CFG_CLR_DEPTH = 0x00, 0x01, 0x02, 0x03, 0x04
CFG_FRONT = 0x05
CFG_MVP = 0x10           # 0x10..0x1F, row major, Q16.16
CFG_CNT = 0x20           # read-only counters 0x20..0x2F
CFG_CNT_CLEAR = 0x3F
GFX_ID = 0x47465801      # 'GFX' v1

CNT_NAMES = [
    "tris_in", "tris_xf_ovf", "tris_clip_rej", "tris_clipped", "tris_degen",
    "tris_culled", "tris_offscreen", "tris_raster", "frags_cov", "frags_zfail",
    "frags_written", "bad_ref", "win_sat", "clip_bad_w",
]

DEPTH_FUNCS = ["NEVER", "LESS", "EQUAL", "LEQUAL", "GREATER", "NOTEQUAL",
               "GEQUAL", "ALWAYS"]


def s32(x: int) -> int:
    x &= 0xFFFFFFFF
    return x - (1 << 32) if x >> 31 else x


def sat_range(x: int, bits: int) -> Tuple[int, bool]:
    lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    if x < lo:
        return lo, True
    if x > hi:
        return hi, True
    return x, False


def fx(v: float) -> int:
    """Host-side helper: float -> Q16.16 raw (round half away from zero is NOT
    used; Python round() is banker's, hosts may choose any rule - the engine
    only ever sees the raw integer)."""
    return int(round(v * (1 << FRAC)))


# ----------------------------------------------------------------------------
# Vertex types
# ----------------------------------------------------------------------------
@dataclass
class CV:
    """Clip-space vertex: x,y,z,w Q16.16 signed; r,g,b Q8.8 unsigned;
    u,v Q16.16 signed."""
    x: int; y: int; z: int; w: int
    r: int; g: int; b: int
    u: int; v: int

    def t(self):
        return (self.x, self.y, self.z, self.w, self.r, self.g, self.b, self.u, self.v)


@dataclass
class SV:
    """Window-space vertex: sx,sy signed 1/256 px; sz unsigned D24;
    iw unsigned Q8.24; colour Q8.8; u,v Q16.16."""
    sx: int; sy: int; sz: int; iw: int
    r: int; g: int; b: int
    u: int; v: int

    def t(self):
        return (self.sx, self.sy, self.sz, self.iw, self.r, self.g, self.b, self.u, self.v)


# ----------------------------------------------------------------------------
# Stage 1: restricted vertex transform   clip = M * (x, y, z, 1)
# ----------------------------------------------------------------------------
def xform_vertex(m: List[int], x: int, y: int, z: int):
    """m: 16 raw Q16.16 values, row-major.  Returns ((x,y,z,w), ovf)."""
    out, ovf = [], False
    for i in range(4):
        acc = m[4*i+0]*x + m[4*i+1]*y + m[4*i+2]*z + (m[4*i+3] << FRAC)
        r = (acc + (1 << (FRAC - 1))) >> FRAC          # round half up, floor shift
        r, o = sat_range(r, 32)
        ovf |= o
        out.append(r)
    return tuple(out), ovf


# ----------------------------------------------------------------------------
# Stage 2: clipping against the 6 planes, Sutherland-Hodgman, homogeneous
# ----------------------------------------------------------------------------
PLANE_NAMES = ["near", "far", "left", "right", "bottom", "top"]


def plane_dist(k: int, v: CV) -> int:
    if k == 0: return v.z
    if k == 1: return v.w - v.z
    if k == 2: return v.x + GB * v.w
    if k == 3: return GB * v.w - v.x
    if k == 4: return v.y + GB * v.w
    return GB * v.w - v.y


def _isect(vin: CV, din: int, vout: CV, dout: int) -> CV:
    # Canonical orientation (inside -> outside) so that two triangles sharing
    # an edge compute bit-identical intersection vertices.
    den = din - dout                      # > 0
    t = (din << CLIP_T) // den            # 0 <= t < 2**CLIP_T
    a, b = vin.t(), vout.t()
    return CV(*[ai + (((bi - ai) * t) >> CLIP_T) for ai, bi in zip(a, b)])


def clip_polygon(tri: List[CV]):
    """Returns (polygon, clipped_flag).  polygon == [] means fully rejected."""
    poly = list(tri)
    clipped = False
    for k in range(6):
        d = [plane_dist(k, v) for v in poly]
        if all(x >= 0 for x in d):
            continue
        if all(x < 0 for x in d):
            return [], clipped
        clipped = True
        out = []
        n = len(poly)
        for i in range(n):
            j = (i + 1) % n
            cur, nxt, dc, dn = poly[i], poly[j], d[i], d[j]
            if dc >= 0:
                out.append(nxt if dn >= 0 else _isect(cur, dc, nxt, dn))
            elif dn >= 0:
                out.append(_isect(nxt, dn, cur, dc))
                out.append(nxt)
        if len(out) > 9 or len(out) < 3:
            return [], clipped            # capacity exceeded / degenerate: reject
        poly = out
    return poly, clipped


# ----------------------------------------------------------------------------
# Stage 3: perspective divide + viewport
# ----------------------------------------------------------------------------
def project_vertex(v: CV, W: int, H: int):
    """Returns (SV, saturated_flag).  Requires v.w > 0."""
    w = v.w
    nx = max(0, v.x + GB * w)
    qx = (nx * (W << SUBPIX) + w) // (2 * w)
    sx = qx - (GB - 1) * W * (1 << (SUBPIX - 1))
    ny = max(0, GB * w - v.y)
    qy = (ny * (H << SUBPIX) + w) // (2 * w)
    sy = qy - (GB - 1) * H * (1 << (SUBPIX - 1))
    nz = min(max(v.z, 0), w)
    sz = (nz * ZMAX * 2 + w) // (2 * w)
    iw = min(IW_MAX, (1 << 40) // w)
    sx, o1 = sat_range(sx, WIN_BITS)
    sy, o2 = sat_range(sy, WIN_BITS)
    assert 0 <= sz <= ZMAX
    return SV(sx, sy, sz, iw, v.r, v.g, v.b, v.u, v.v), (o1 or o2)


# ----------------------------------------------------------------------------
# Stage 4: normalised reciprocal + barycentric weights
# ----------------------------------------------------------------------------
def recip_norm(den: int):
    """Block floating-point reciprocal of a positive integer.
    Returns (R, k, sh): weights are (num >> k) * R >> sh (sh may be < 0)."""
    assert den > 0
    n = den.bit_length()
    m = den >> (n - RECIP_MANT) if n >= RECIP_MANT else den << (RECIP_MANT - n)
    R = (1 << 32) // (m + 1)               # under-estimates 2^32/m  => sum(w) <= ONE
    k = max(0, n - RECIP_NUM)
    sh = n - 4 - k                         # = 32 + (n-16) - LAM_F - k
    return R, k, sh


def _shift(x: int, sh: int) -> int:
    return x >> sh if sh >= 0 else x << (-sh)


def weights(n0: int, n1: int, rn):
    """Normalised weights (w0,w1,w2) in Q0.20 with w0+w1+w2 == ONE exactly."""
    R, k, sh = rn
    w0 = _shift((n0 >> k) * R, sh)
    w1 = _shift((n1 >> k) * R, sh)
    w2 = ONE - w0 - w1
    assert w0 >= 0 and w1 >= 0 and w2 >= 0, (n0, n1, rn, w0, w1, w2)
    return w0, w1, w2


# ----------------------------------------------------------------------------
# Stage 5: triangle setup
# ----------------------------------------------------------------------------
@dataclass
class Setup:
    v: List[SV]
    area2: int
    A: List[int]; B: List[int]; C: List[int]
    bias: List[int]
    x0: int; x1: int; y0: int; y1: int
    rn: tuple


def is_top_left(A: int, B: int) -> bool:
    """Edge e(p)=A*px+B*py+C, interior where e>0 (CW-on-screen, y down)."""
    return A > 0 or (A == 0 and B > 0)


def tri_setup(v: List[SV], W: int, H: int, cull: int, front_ccw: int):
    """Returns (Setup | None, reason).  reason in {'degen','culled','offscreen',None}."""
    a, b, c = v
    area2 = (b.sx - a.sx) * (c.sy - a.sy) - (c.sx - a.sx) * (b.sy - a.sy)
    if area2 == 0:
        return None, "degen"
    cw_visual = area2 > 0                       # y-down: area2>0 <=> clockwise on screen
    front = (not cw_visual) if front_ccw else cw_visual
    if (cull == 1 and not front) or (cull == 2 and front) or cull == 3:
        return None, "culled"
    if area2 < 0:
        v = [a, c, b]
        area2 = -area2
    a, b, c = v
    edges = [(b, c), (c, a), (a, b)]            # e_i is opposite vertex i
    A, B, C, bias = [], [], [], []
    for p, q in edges:
        Ai = -(q.sy - p.sy)
        Bi = (q.sx - p.sx)
        Ci = -(Ai * p.sx + Bi * p.sy)
        A.append(Ai); B.append(Bi); C.append(Ci)
        bias.append(0 if is_top_left(Ai, Bi) else 1)
    minx = min(a.sx, b.sx, c.sx) >> SUBPIX
    maxx = max(a.sx, b.sx, c.sx) >> SUBPIX
    miny = min(a.sy, b.sy, c.sy) >> SUBPIX
    maxy = max(a.sy, b.sy, c.sy) >> SUBPIX
    x0, x1 = max(minx, 0), min(maxx, W - 1)
    y0, y1 = max(miny, 0), min(maxy, H - 1)
    if x0 > x1 or y0 > y1:
        return None, "offscreen"
    return Setup(v, area2, A, B, C, bias, x0, x1, y0, y1, recip_norm(area2)), None


def edge_at(su: Setup, px: int, py: int):
    sx_ = (px << SUBPIX) + (1 << (SUBPIX - 1))
    sy_ = (py << SUBPIX) + (1 << (SUBPIX - 1))
    return [su.A[i] * sx_ + su.B[i] * sy_ + su.C[i] for i in range(3)]


def covered(su: Setup, e) -> bool:
    return all(e[i] - su.bias[i] >= 0 for i in range(3))


def coverage_mask(verts_sub: List[Tuple[int, int]], W: int, H: int):
    """Pixels covered by a screen-space triangle (fill rule only, no cull)."""
    sv = [SV(x, y, 0, 0, 0, 0, 0, 0, 0) for x, y in verts_sub]
    su, why = tri_setup(sv, W, H, 0, 0)
    out = set()
    if su is None:
        return out
    for py in range(su.y0, su.y1 + 1):
        for px in range(su.x0, su.x1 + 1):
            if covered(su, edge_at(su, px, py)):
                out.add((px, py))
    return out


# ----------------------------------------------------------------------------
# Texture helpers
# ----------------------------------------------------------------------------
def div255_round(x: int) -> int:
    """round(x/255) for 0 <= x <= 255*255 using shifts/adds only."""
    t = x + 128
    return (t + (t >> 8)) >> 8


# ----------------------------------------------------------------------------
# Whole device model
# ----------------------------------------------------------------------------
@dataclass
class Params:
    W: int = 160
    H: int = 120
    VB_VERTS: int = 256
    IB_DEPTH: int = 1024
    TEX_LOG2W: int = 6
    TEX_LOG2H: int = 6
    DOUBLE_BUF: int = 1


class Gfx:
    def __init__(self, p: Optional[Params] = None):
        self.p = p or Params()
        p = self.p
        self.vb = [0] * (p.VB_VERTS * VTX_WORDS)
        self.ib = [0] * p.IB_DEPTH
        self.tex = [0] * ((1 << p.TEX_LOG2W) << p.TEX_LOG2H)
        nb = 2 if p.DOUBLE_BUF else 1
        self.color = [[0] * (p.W * p.H) for _ in range(nb)]
        self.depth = [0] * (p.W * p.H)
        self.front = 0
        self.mvp = [0] * 16
        self.rs = 0
        self.clr_color = 0
        self.clr_depth = ZMAX
        self.cnt = {k: 0 for k in CNT_NAMES}
        self.trace: List[str] = []
        self.do_trace = False
        self.err = 0
        self.snapshots: List[List[int]] = []      # front buffer after each PRESENT (if enabled)
        self.snap = False

    # ------------------------------------------------------------------ host
    @property
    def back(self):
        return (1 - self.front) if self.p.DOUBLE_BUF else 0

    def bump(self, name, n=1):
        self.cnt[name] = min(CNT_MAX, self.cnt[name] + n)

    def write(self, space: int, addr: int, data: int):
        data &= 0xFFFFFFFF
        p = self.p
        if space == SP_CFG:
            if addr == CFG_RS: self.rs = data & 0x1FFF
            elif addr == CFG_CLR_COLOR: self.clr_color = data & 0xFFFFFF
            elif addr == CFG_CLR_DEPTH: self.clr_depth = data & ZMAX
            elif CFG_MVP <= addr < CFG_MVP + 16: self.mvp[addr - CFG_MVP] = s32(data)
            elif addr == CFG_CNT_CLEAR: self.cnt = {k: 0 for k in CNT_NAMES}
            elif addr == CFG_STATUS: self.err = 0; return True
            else: self.err = 1; return False
        elif space == SP_VERT:
            if addr >= len(self.vb): self.err = 1; return False
            self.vb[addr] = data
        elif space == SP_IDX:
            if addr >= len(self.ib): self.err = 1; return False
            self.ib[addr] = data & 0xFFFF
        elif space == SP_TEX:
            if addr >= len(self.tex): self.err = 1; return False
            self.tex[addr] = data & 0xFFFFFF
        elif space == SP_COLOR:
            if addr >= p.W * p.H: self.err = 1; return False
            self.color[self.back][addr] = data & 0xFFFFFF
        elif space == SP_DEPTH:
            if addr >= p.W * p.H: self.err = 1; return False
            self.depth[addr] = data & ZMAX
        else:
            self.err = 1; return False
        return True

    def read(self, space: int, addr: int):
        p = self.p
        if space == SP_CFG:
            if addr == CFG_ID: return GFX_ID
            if addr == CFG_STATUS: return self.err << 1
            if addr == CFG_RS: return self.rs
            if addr == CFG_CLR_COLOR: return self.clr_color
            if addr == CFG_CLR_DEPTH: return self.clr_depth
            if addr == CFG_FRONT: return self.front
            if CFG_MVP <= addr < CFG_MVP + 16: return self.mvp[addr - CFG_MVP] & 0xFFFFFFFF
            if CFG_CNT <= addr < CFG_CNT + len(CNT_NAMES):
                return self.cnt[CNT_NAMES[addr - CFG_CNT]]
            return 0
        if space == SP_COLOR and addr < p.W * p.H: return self.color[self.back][addr]
        if space == SP_FRONT and addr < p.W * p.H: return self.color[self.front if p.DOUBLE_BUF else 0][addr]
        if space == SP_DEPTH and addr < p.W * p.H: return self.depth[addr]
        return 0

    def clear(self):
        p = self.p
        self.color[self.back] = [self.clr_color] * (p.W * p.H)
        self.depth = [self.clr_depth] * (p.W * p.H)

    def present(self):
        if self.p.DOUBLE_BUF:
            self.front ^= 1
        if self.snap:
            self.snapshots.append(list(self.color[self.front if self.p.DOUBLE_BUF else 0]))

    # ---------------------------------------------------------------- render
    def _tr(self, s):
        if self.do_trace:
            self.trace.append(s)

    def draw(self, first: int, count: int):
        p = self.p
        for t in range(first, first + count):
            self.bump("tris_in")
            ia = 3 * t
            if ia + 2 >= p.IB_DEPTH:
                self.bump("bad_ref"); continue
            idx = [self.ib[ia + j] & 0xFFFF for j in range(3)]
            if any(i >= p.VB_VERTS for i in idx):
                self.bump("bad_ref"); continue
            cvs, ovf = [], False
            for i in idx:
                o = i * VTX_WORDS
                x, y, z = (s32(self.vb[o]), s32(self.vb[o+1]), s32(self.vb[o+2]))
                col = self.vb[o+3]
                u, v = s32(self.vb[o+4]), s32(self.vb[o+5])
                (cx, cy, cz, cw), ov = xform_vertex(self.mvp, x, y, z)
                ovf |= ov
                cvs.append(CV(cx, cy, cz, cw, ((col >> 16) & 255) << 8,
                              ((col >> 8) & 255) << 8, (col & 255) << 8, u, v))
            self._tr("XF " + " ".join(",".join("%08x" % (q & 0xFFFFFFFF) for q in c.t()) for c in cvs)
                     + (" OVF" if ovf else ""))
            if ovf:
                self.bump("tris_xf_ovf"); continue
            poly, clipped = clip_polygon(cvs)
            if not poly:
                self.bump("tris_clip_rej"); self._tr("CR"); continue
            if clipped:
                self.bump("tris_clipped")
            if any(c.w <= 0 for c in poly):
                self.bump("clip_bad_w"); self._tr("BW"); continue
            svs = []
            for c in poly:
                s, sat = project_vertex(c, p.W, p.H)
                if sat: self.bump("win_sat")
                svs.append(s)
            for k in range(1, len(svs) - 1):
                self.raster_tri([svs[0], svs[k], svs[k + 1]])

    def raster_tri(self, v: List[SV]):
        p = self.p
        self._tr("SC " + " ".join(",".join("%08x" % (q & 0xFFFFFFFF) for q in s.t()) for s in v))
        rs = self.rs
        cull = (rs >> RS_CULL_LO) & 3
        su, why = tri_setup(v, p.W, p.H, cull, (rs >> RS_FRONT_CCW) & 1)
        if su is None:
            self.bump({"degen": "tris_degen", "culled": "tris_culled",
                       "offscreen": "tris_offscreen"}[why])
            self._tr("SU " + why); return
        self._tr("SU %x %d %d %d %d" % (su.area2, su.x0, su.x1, su.y0, su.y1))
        self.bump("tris_raster")
        depth_en = (rs >> RS_DEPTH_EN) & 1
        depth_wr = (rs >> RS_DEPTH_WR) & 1
        func = (rs >> RS_DEPTH_FUNC_LO) & 7
        tex_en = (rs >> RS_TEX_EN) & 1
        persp = (rs >> RS_PERSP_EN) & 1
        cl_u = (rs >> RS_WRAP_U_CLAMP) & 1
        cl_v = (rs >> RS_WRAP_V_CLAMP) & 1
        modul = (rs >> RS_MODULATE) & 1
        a, b, c = su.v
        e_row = edge_at(su, su.x0, su.y0)
        cov = zf = wr = 0
        buf = self.color[self.back]
        for py in range(su.y0, su.y1 + 1):
            e = list(e_row)
            for px in range(su.x0, su.x1 + 1):
                if covered(su, e):
                    cov += 1
                    lam = weights(e[0], e[1], su.rn)
                    z = (lam[0]*a.sz + lam[1]*b.sz + lam[2]*c.sz) >> LAM_F
                    assert 0 <= z <= ZMAX
                    addr = py * p.W + px
                    if depth_en:
                        zb = self.depth[addr]
                        ok = depth_pass(func, z, zb)
                    else:
                        ok = True
                    if not ok:
                        zf += 1
                    else:
                        mu = lam
                        if persp:
                            rho = [lam[0]*a.iw, lam[1]*b.iw, lam[2]*c.iw]
                            S = rho[0] + rho[1] + rho[2]
                            if S > 0:
                                mu = weights(rho[0], rho[1], recip_norm(S))
                        col = []
                        for ch in ("r", "g", "b"):
                            acc = (mu[0]*getattr(a, ch) + mu[1]*getattr(b, ch) + mu[2]*getattr(c, ch))
                            col.append((acc + (1 << 27)) >> 28)
                        assert all(0 <= q <= 255 for q in col)
                        if tex_en:
                            uu = (mu[0]*a.u + mu[1]*b.u + mu[2]*c.u) >> LAM_F
                            vv = (mu[0]*a.v + mu[1]*b.v + mu[2]*c.v) >> LAM_F
                            texel = self.sample(uu, vv, cl_u, cl_v)
                            tcol = [(texel >> 16) & 255, (texel >> 8) & 255, texel & 255]
                            if modul:
                                col = [div255_round(tcol[i] * col[i]) for i in range(3)]
                            else:
                                col = tcol
                        buf[addr] = (col[0] << 16) | (col[1] << 8) | col[2]
                        if depth_wr:
                            self.depth[addr] = z
                        wr += 1
                for i in range(3):
                    e[i] += su.A[i] << SUBPIX
            for i in range(3):
                e_row[i] += su.B[i] << SUBPIX
        self.bump("frags_cov", cov); self.bump("frags_zfail", zf); self.bump("frags_written", wr)
        self._tr("TD %d %d %d" % (cov, zf, wr))

    def sample(self, u: int, v: int, clamp_u: int, clamp_v: int) -> int:
        p = self.p
        tx = u >> (FRAC - p.TEX_LOG2W)
        ty = v >> (FRAC - p.TEX_LOG2H)
        tw, th = 1 << p.TEX_LOG2W, 1 << p.TEX_LOG2H
        tx = min(max(tx, 0), tw - 1) if clamp_u else tx & (tw - 1)
        ty = min(max(ty, 0), th - 1) if clamp_v else ty & (th - 1)
        return self.tex[(ty << p.TEX_LOG2W) | tx]

    # ------------------------------------------------------------ convenience
    def framebuffer_rgb(self, front: bool = False):
        """Return list of (r,g,b) rows for the back (or front) buffer."""
        p = self.p
        buf = self.color[self.front if (front and p.DOUBLE_BUF) else self.back]
        return [[((buf[y*p.W+x] >> 16) & 255, (buf[y*p.W+x] >> 8) & 255, buf[y*p.W+x] & 255)
                 for x in range(p.W)] for y in range(p.H)]


def depth_pass(func: int, z: int, zb: int) -> bool:
    return [False, z < zb, z == zb, z <= zb, z > zb, z != zb, z >= zb, True][func]


# ----------------------------------------------------------------------------
# Command-stream interface (same stream the RTL testbench replays)
# ----------------------------------------------------------------------------
OP_WRITE, OP_READ, OP_CLEAR, OP_DRAW, OP_PRESENT = 0, 1, 2, 3, 4


def run_cmds(g: Gfx, cmds):
    """cmds: iterable of (op, space, addr, data).
    Returns one (err, rdata) pair per command, exactly what the RTL command
    port reports (err is 1 only for a rejected WRITE)."""
    res = []
    for op, sp, ad, da in cmds:
        err, rd = 0, 0
        if op == OP_WRITE:
            err = 0 if g.write(sp, ad, da) else 1
        elif op == OP_READ:
            rd = g.read(sp, ad)
        elif op == OP_CLEAR:
            g.clear()
        elif op == OP_DRAW:
            g.draw(ad & 0xFFFF, da & 0xFFFF)
        elif op == OP_PRESENT:
            g.present()
        res.append((err, rd & 0xFFFFFFFF))
    return res


if __name__ == "__main__":
    g = Gfx(Params(W=16, H=16))
    print("model loaded; GFX_ID=%08x" % GFX_ID)
