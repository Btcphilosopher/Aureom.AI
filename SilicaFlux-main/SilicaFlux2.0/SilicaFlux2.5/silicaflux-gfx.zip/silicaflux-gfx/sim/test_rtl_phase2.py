"""
Phase-2 (texture sampling + perspective-correct interpolation) tests.
Same contract as phase 1: RTL must equal the bit-exact model.
"""
import math
import random
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "tools"), str(ROOT / "model")]
import gfxref as G            # noqa: E402
import gfxsim as S            # noqa: E402
import scene as SC            # noqa: E402
from cmdgen import Cmds, IDENT  # noqa: E402

P = G.Params(W=32, H=24)
CHK = SC.checker(6, 6, 8)
GRAD = SC.gradient_texture(6, 6)


def check(p, cmds):
    bad, rtl, g = S.compare(p, cmds, True)
    assert not bad, "\n".join(bad)
    return rtl, g


def quad_scene(uvs, tex=CHK, mvp=IDENT, w=1.0, **rs):
    c = Cmds().mvp(mvp).clear_colors(0x000000)
    c.texture(tex)
    c.rs(depth_en=0, tex=1, **rs).clear()
    pos = [(-.9, -.9), (.9, -.9), (.9, .9), (-.9, .9)]
    for i, ((x, y), (u, v)) in enumerate(zip(pos, uvs)):
        c.vertex(i, x, y, .5, 0xFFFFFF, u, v)
    c.indices([0, 1, 2, 0, 2, 3]).draw(0, 2).present()
    return c


UV01 = [(0, 1), (1, 1), (1, 0), (0, 0)]


def test_texture_replace_nearest_basic():
    rtl, g = check(P, quad_scene(UV01))
    assert g.cnt["frags_written"] > 300


@pytest.mark.parametrize("cu,cv", [(0, 0), (1, 0), (0, 1), (1, 1)])
def test_wrap_vs_clamp_outside_unit_square(cu, cv):
    uvs = [(-0.5, 1.7), (1.9, 1.7), (1.9, -0.6), (-0.5, -0.6)]
    check(P, quad_scene(uvs, clamp_u=cu, clamp_v=cv))


def test_wrap_negative_coordinates_and_large_repeat():
    uvs = [(-3.25, 5.5), (4.75, 5.5), (4.75, -2.5), (-3.25, -2.5)]
    check(P, quad_scene(uvs, tex=GRAD))


def test_modulate_with_vertex_colours():
    c = Cmds().mvp(IDENT).clear_colors(0x101010).texture(GRAD)
    c.rs(depth_en=0, tex=1, modulate=1).clear()
    cols = [0xFF0000, 0x00FF00, 0x0000FF, 0xFFFFFF]
    pos = [(-.9, -.9), (.9, -.9), (.9, .9), (-.9, .9)]
    for i, ((x, y), col, (u, v)) in enumerate(zip(pos, cols, UV01)):
        c.vertex(i, x, y, .5, col, u, v)
    c.indices([0, 1, 2, 0, 2, 3]).draw(0, 2).present()
    check(P, c)


def test_texture_disabled_after_enabled_is_untextured():
    c = quad_scene(UV01)
    c.rs(depth_en=0, tex=0).clear().draw(0, 2)
    check(P, c)


def _tilted_quad(persp, tex=CHK):
    """A floor-like quad receding into the distance: strong foreshortening."""
    proj = SC.perspective(1.0, 32 / 24, 0.3, 50.0)
    mv = SC.mat_mul(SC.translate(0, -0.6, -2.0), SC.rot_x(-0.0))
    c = Cmds().mvp(SC.to_fx(SC.mat_mul(proj, mv))).clear_colors(0x303030).texture(tex)
    c.rs(depth_en=1, depth_wr=1, func=1, tex=1, persp=persp).clear()
    quad = [(-3, 0, 1.5, 0, 0), (3, 0, 1.5, 3, 0), (3, 0, -30, 3, 30), (-3, 0, -30, 0, 30)]
    for i, (x, y, z, u, v) in enumerate(quad):
        c.vertex(i, x, y, z, 0xFFFFFF, u, v)
    c.indices([0, 1, 2, 0, 2, 3]).draw(0, 2).present()
    return c


@pytest.mark.parametrize("persp", [0, 1])
def test_perspective_and_affine_floor_bit_exact(persp):
    rtl, g = check(P, _tilted_quad(persp))
    assert g.cnt["frags_written"] > 100


def test_perspective_changes_the_image():
    _, g0 = check(P, _tilted_quad(0))
    _, g1 = check(P, _tilted_quad(1))
    b0, b1 = g0.color[g0.front], g1.color[g1.front]   # drawn buffer is the front one after PRESENT
    assert sum(1 for a, b in zip(b0, b1) if a != b) > 20


def test_perspective_colour_without_texture_bit_exact():
    proj = SC.perspective(1.0, 32 / 24, 0.3, 50.0)
    mv = SC.translate(0, 0, -3)
    c = Cmds().mvp(SC.to_fx(SC.mat_mul(proj, mv))).clear_colors(0)
    c.rs(depth_en=1, depth_wr=1, func=1, persp=1).clear()
    c.vertex(0, -2, -1, 2.5, 0xFF0000).vertex(1, 2, -1, -6, 0x00FF00).vertex(2, 0, 2, -1, 0x0000FF)
    c.indices([0, 1, 2]).draw(0, 1).present()
    check(P, c)


def test_textured_perspective_with_near_plane_clipping():
    proj = SC.perspective(1.1, 32 / 24, 0.5, 40.0)
    c = Cmds().mvp(SC.to_fx(proj)).clear_colors(0x202020).texture(CHK)
    c.rs(depth_en=1, depth_wr=1, func=1, tex=1, persp=1, modulate=1).clear()
    quad = [(-2, -1, 1.0, 0, 0), (2, -1, 1.0, 4, 0), (2, -1, -12, 4, 8), (-2, -1, -12, 0, 8)]
    for i, (x, y, z, u, v) in enumerate(quad):
        c.vertex(i, x, y, z, 0xFFE0C0, u, v)
    c.indices([0, 1, 2, 0, 2, 3]).draw(0, 2).present()
    rtl, g = check(P, c)
    assert g.cnt["tris_clipped"] >= 1


@pytest.mark.parametrize("seed", range(10))
def test_random_textured_scenes_bit_exact(seed):
    rng = random.Random(555 + seed)
    proj = SC.perspective(rng.uniform(.7, 1.6), 32 / 24, rng.choice([.2, .5]), rng.choice([10., 40.]))
    mv = SC.mat_mul(SC.translate(rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(-5, -1)),
                    SC.mat_mul(SC.rot_y(rng.uniform(0, 6.28)), SC.rot_x(rng.uniform(0, 6.28))))
    c = Cmds().mvp(SC.to_fx(SC.mat_mul(proj, mv))).clear_colors(rng.randrange(1 << 24))
    c.texture(rng.choice([CHK, GRAD]))
    c.rs(depth_en=rng.random() < .8, depth_wr=1, func=rng.choice([1, 3]), tex=rng.random() < .8,
         persp=rng.random() < .6, modulate=rng.random() < .5, clamp_u=rng.random() < .3,
         clamp_v=rng.random() < .3, cull=rng.choice([0, 0, 1, 2])).clear()
    n = rng.randrange(2, 7)
    for i in range(3 * n):
        c.vertex(i, rng.uniform(-2, 2), rng.uniform(-2, 2), rng.uniform(-2, 2), rng.randrange(1 << 24),
                 rng.uniform(-2, 3), rng.uniform(-2, 3))
    c.indices(list(range(3 * n))).draw(0, n).present()
    check(P, c)


# ------------------------------------------------ model-vs-ideal (float) accuracy
def test_model_perspective_uv_close_to_float_ideal():
    """The bit-exact model is itself checked against exact float perspective-correct
    interpolation: |du| must stay small compared with a texel (1/64)."""
    W, H = 32, 24
    proj = SC.perspective(1.0, W / H, 0.3, 50.0)
    mv = SC.translate(0, -0.6, -2.0)
    mvp = SC.to_fx(SC.mat_mul(proj, mv))
    quad = [(-3, 0, 1.5, 0, 0), (3, 0, 1.5, 3, 0), (3, 0, -30, 3, 30), (-3, 0, -30, 0, 30)]
    g = G.Gfx(G.Params(W=W, H=H))
    g.mvp = mvp
    verts = []
    for (x, y, z, u, v) in quad:
        (cx, cy, cz, cw), ovf = G.xform_vertex(mvp, G.fx(x), G.fx(y), G.fx(z))
        assert not ovf
        verts.append(G.CV(cx, cy, cz, cw, 0, 0, 0, G.fx(u), G.fx(v)))
    worst_u = worst_v = 0.0
    n = 0
    for tri in ([0, 1, 2], [0, 2, 3]):
        poly, _ = G.clip_polygon([verts[i] for i in tri])
        svs = [G.project_vertex(c, W, H)[0] for c in poly]
        for k in range(1, len(svs) - 1):
            su, _ = G.tri_setup([svs[0], svs[k], svs[k + 1]], W, H, 0, 0)
            if su is None:
                continue
            a, b, c = su.v
            for py in range(su.y0, su.y1 + 1):
                for px in range(su.x0, su.x1 + 1):
                    e = G.edge_at(su, px, py)
                    if not G.covered(su, e):
                        continue
                    lam = G.weights(e[0], e[1], su.rn)
                    rho = [lam[0] * a.iw, lam[1] * b.iw, lam[2] * c.iw]
                    mu = G.weights(rho[0], rho[1], G.recip_norm(sum(rho)))
                    u_m = (mu[0] * a.u + mu[1] * b.u + mu[2] * c.u) >> G.LAM_F
                    v_m = (mu[0] * a.v + mu[1] * b.v + mu[2] * c.v) >> G.LAM_F
                    # float ideal from the same window-space triangle
                    fl = [l / G.ONE for l in lam]
                    fw = [(fl[0] * (a.iw / 2**24), fl[1] * (b.iw / 2**24), fl[2] * (c.iw / 2**24))]
                    S_ = sum(fw[0])
                    u_i = (fw[0][0] * a.u + fw[0][1] * b.u + fw[0][2] * c.u) / S_ / 65536
                    v_i = (fw[0][0] * a.v + fw[0][1] * b.v + fw[0][2] * c.v) / S_ / 65536
                    worst_u = max(worst_u, abs(u_m / 65536 - u_i))
                    worst_v = max(worst_v, abs(v_m / 65536 - v_i))
                    n += 1
    assert n > 100
    # v spans 0..30 over the quad; error relative to the span stays tiny
    assert worst_u < 0.01 and worst_v < 0.2, (worst_u, worst_v)
