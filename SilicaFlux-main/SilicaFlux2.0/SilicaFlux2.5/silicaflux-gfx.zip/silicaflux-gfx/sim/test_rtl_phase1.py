"""
Phase-1 (untextured) RTL-vs-reference tests.

Every test builds a command stream, runs it on (a) the Verilator-simulated RTL
and (b) the bit-exact Python model, and requires an IDENTICAL result:
colour buffers, depth buffer, all 14 counters, front-buffer select, per-command
error/readback values, and the stage-by-stage trace (XF/SC/SU/TD).

Shared-edge and tie tests additionally cross-check the RTL's framebuffer
against the independent exact-rational oracle (model/oracle.py).
"""
import random
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "tools"), str(ROOT / "model")]
import gfxref as G            # noqa: E402
import gfxsim as S            # noqa: E402
import oracle as O            # noqa: E402
import scene as SC            # noqa: E402
from cmdgen import Cmds, IDENT  # noqa: E402

P_SMALL = G.Params(W=32, H=24)
P_SQ = G.Params(W=32, H=32)          # power-of-two viewport: window coords exactly representable


def check(p, cmds, trace=True):
    bad, rtl, g = S.compare(p, cmds, trace)
    assert not bad, "\n".join(bad)
    return rtl, g


def win_vertex(c, i, X, Y, z=0.5, rgb=0xFFFFFF):
    x, y = SC.ndc_from_window(X, Y, 32, 32)
    c.vertex(i, x, y, z, rgb)


# ------------------------------------------------------------------ basics
def test_single_triangle_colour_interp():
    c = Cmds().mvp(IDENT).rs(depth_en=1, depth_wr=1, func=1).clear_colors(0x101010)
    c.vertex(0, -.8, -.8, .5, 0xFF0000).vertex(1, .8, -.8, .5, 0x00FF00).vertex(2, 0, .8, .5, 0x0000FF)
    c.indices([0, 1, 2]).clear().draw(0, 1).present()
    rtl, g = check(P_SMALL, c)
    assert g.cnt["frags_written"] > 100


@pytest.mark.parametrize("cull,front_ccw", [(0, 0), (1, 0), (2, 0), (3, 0), (1, 1), (2, 1)])
def test_cull_modes_both_windings(cull, front_ccw):
    c = Cmds().mvp(IDENT).rs(depth_en=0, cull=cull, front_ccw=front_ccw).clear_colors(0)
    # tri 0 : visually CCW,  tri 1: visually CW (mirror)
    c.vertex(0, -.9, -.9, .5, 0xFF0000).vertex(1, -.1, -.9, .5, 0xFF0000).vertex(2, -.5, -.1, .5, 0xFF0000)
    c.vertex(3, .1, -.9, .5, 0x00FF00).vertex(4, .5, -.1, .5, 0x00FF00).vertex(5, .9, -.9, .5, 0x00FF00)
    c.indices([0, 1, 2, 3, 4, 5]).clear().draw(0, 2).present()
    rtl, g = check(P_SMALL, c)
    if cull in (0,):
        assert g.cnt["tris_culled"] == 0
    if cull == 3:
        assert g.cnt["tris_culled"] == 2
    if cull in (1, 2):
        assert g.cnt["tris_culled"] == 1


def test_degenerate_and_offscreen_and_bad_ref():
    c = Cmds().mvp(IDENT).rs().clear_colors(0)
    c.vertex(0, 0, 0, .5, 0xFFFFFF).vertex(1, .5, .5, .5).vertex(2, -.5, -.5, .5)        # collinear
    c.vertex(3, 3, 3, .5).vertex(4, 3.5, 3, .5).vertex(5, 3, 3.5, .5)                   # inside GB, off-screen
    c.indices([0, 1, 2, 3, 4, 5, 0, 1, 300, 5, 5, 5])
    c.clear().draw(0, 4).present()
    rtl, g = check(P_SMALL, c)
    assert g.cnt["tris_degen"] >= 1 and g.cnt["tris_offscreen"] == 1 and g.cnt["bad_ref"] == 1


# --------------------------------------------------------------- depth tests
@pytest.mark.parametrize("func", range(8))
def test_depth_funcs_equal_and_ordered(func):
    c = Cmds().mvp(IDENT).clear_colors(0)
    # three overlapping triangles: z=.5 (red), z=.5 (green; equal), z=.25 (blue; nearer), z=.75 (white)
    for k, (z, col) in enumerate([(.5, 0xFF0000), (.5, 0x00FF00), (.25, 0x0000FF), (.75, 0xFFFFFF)]):
        c.vertex(3*k, -.9, -.9, z, col).vertex(3*k+1, .9, -.9, z, col).vertex(3*k+2, 0, .9, z, col)
    c.indices(list(range(12)))
    c.rs(depth_en=1, depth_wr=1, func=func).clear()
    for t in range(4):
        c.draw(t, 1)
    c.present()
    check(P_SMALL, c)


def test_depth_write_off_and_test_off():
    c = Cmds().mvp(IDENT).clear_colors(0x202020)
    c.vertex(0, -.9, -.9, .3, 0xFF0000).vertex(1, .9, -.9, .3, 0xFF0000).vertex(2, 0, .9, .3, 0xFF0000)
    c.vertex(3, -.9, -.9, .6, 0x00FF00).vertex(4, .9, -.9, .6, 0x00FF00).vertex(5, 0, .9, .6, 0x00FF00)
    c.indices(list(range(6)))
    c.rs(depth_en=1, depth_wr=0, func=1).clear().draw(0, 2)        # no depth write -> both land
    c.rs(depth_en=0, depth_wr=1).clear().draw(0, 2)                # test off, write on
    c.present()
    check(P_SMALL, c)


def test_intersecting_triangles():
    c = Cmds().mvp(IDENT).clear_colors(0).rs(depth_en=1, depth_wr=1, func=1)
    c.vertex(0, -.9, -.8, .2, 0xFF2020).vertex(1, .9, -.8, .8, 0xFF2020).vertex(2, 0, .9, .5, 0xFF2020)
    c.vertex(3, -.9, -.8, .8, 0x2020FF).vertex(4, .9, -.8, .2, 0x2020FF).vertex(5, 0, .9, .5, 0x2020FF)
    c.indices(list(range(6))).clear().draw(0, 2).present()
    rtl, g = check(P_SMALL, c)
    assert g.cnt["frags_zfail"] > 0 and g.cnt["frags_written"] > g.cnt["frags_cov"] // 2


# --------------------------------------------------- shared edges / tie lattice
def _quad_scene(X0, Y0, X1, Y1, diag, flip):
    c = Cmds().mvp(IDENT).clear_colors(0).rs(depth_en=1, depth_wr=1, func=1)   # LESS, equal z
    corners = [(X0, Y0), (X1, Y0), (X1, Y1), (X0, Y1)]
    for i, (X, Y) in enumerate(corners):
        win_vertex(c, i, X, Y)
    tris = [[0, 1, 2], [0, 2, 3]] if diag == 0 else [[0, 1, 3], [1, 2, 3]]
    if flip:
        tris = [[t[0], t[2], t[1]] for t in tris]
    c.indices(sum(tris, [])).clear().draw(0, 2).present()
    return c, corners, tris


@pytest.mark.parametrize("diag", [0, 1])
@pytest.mark.parametrize("flip", [0, 1])
def test_quad_shared_edge_exact_once(diag, flip):
    rng = random.Random(100 * diag + flip)
    for _ in range(6):
        X0, Y0 = rng.randrange(0, 12) / 2, rng.randrange(0, 12) / 2
        X1, Y1 = X0 + rng.randrange(1, 20) / 2, Y0 + rng.randrange(1, 20) / 2
        c, corners, tris = _quad_scene(X0, Y0, X1, Y1, diag, flip)
        rtl, g = check(P_SQ, c)
        # shared diagonal: every pixel covered exactly once -> no depth-equal rejections
        assert rtl["cnt"][G.CNT_NAMES.index("frags_zfail")] == 0, (X0, Y0, X1, Y1)
        # RTL pixel set must equal the independent oracle's union
        win = [(int(round(X * 256)), int(round(Y * 256))) for X, Y in corners]
        exp = set()
        for t in tris:
            exp |= O.coverage([win[i] for i in t], 32, 32)
        got = {(i % 32, i // 32) for i, v in enumerate(rtl["fb1"]) if v}
        # colour 0 is "no pixel" only because vertex colour is white here
        assert got == exp


def test_tie_lattice_random_triangles_vs_oracle():
    """Random triangles on a half-pixel lattice => many pixel centres exactly on edges."""
    rng = random.Random(2024)
    n_checked = 0
    for batch in range(6):
        c = Cmds().mvp(IDENT).rs(depth_en=0).clear_colors(0)
        tris = []
        c.clear()
        for t in range(6):
            v = [(rng.randrange(-4, 70) / 2, rng.randrange(-4, 70) / 2) for _ in range(3)]
            tris.append(v)
        # draw each triangle separately into the same buffer is ambiguous -> compare union with oracle
        for t, v in enumerate(tris):
            for k, (X, Y) in enumerate(v):
                win_vertex(c, 3 * t + k, X, Y, rgb=0xFFFFFF)
        c.indices(list(range(18))).draw(0, 6).present()
        rtl, g = check(P_SQ, c)
        exp = set()
        for v in tris:
            sub = [(int(X * 256), int(Y * 256)) for X, Y in v]
            exp |= O.coverage(sub, 32, 32)
        got = {(i % 32, i // 32) for i, px in enumerate(rtl["fb1"]) if px}
        assert got == exp, sorted(got ^ exp)[:10]
        n_checked += 6
    assert n_checked == 36


def test_triangle_fan_and_random_mesh_no_gap_no_overlap():
    rng = random.Random(77)
    for trial in range(4):
        nx, ny = rng.randrange(2, 5), rng.randrange(2, 5)
        W = H = 32
        pts = {}
        for j in range(ny + 1):
            for i in range(nx + 1):
                X = i * W / nx; Y = j * H / ny
                if 0 < i < nx: X += rng.randrange(-3, 4) / 2
                if 0 < j < ny: Y += rng.randrange(-3, 4) / 2
                pts[(i, j)] = (X, Y)
        c = Cmds().mvp(IDENT).clear_colors(0).rs(depth_en=1, depth_wr=1, func=1)
        vid = {}
        for k, key in enumerate(sorted(pts)):
            vid[key] = k
            win_vertex(c, k, pts[key][0], pts[key][1])
        idx = []
        for j in range(ny):
            for i in range(nx):
                a, b, cc, d = vid[(i, j)], vid[(i+1, j)], vid[(i+1, j+1)], vid[(i, j+1)]
                tr = [[a, b, cc], [a, cc, d]] if rng.random() < .5 else [[a, b, d], [b, cc, d]]
                for t in tr:
                    idx += t if rng.random() < .5 else [t[0], t[2], t[1]]
        c.indices(idx).clear().draw(0, len(idx) // 3).present()
        rtl, g = check(P_SQ, c)
        assert g.cnt["frags_zfail"] == 0, "pixel hit twice"
        assert g.cnt["frags_written"] == W * H, "gap in mesh coverage"


# -------------------------------------------------------------- clipping
def persp_scene(tris, near=0.5, far=10.0, rs=None):
    """tris: list of 3 (x,y,z_eye,rgb) in EYE space (z negative = in front)."""
    c = Cmds().mvp(SC.to_fx(SC.perspective(1.2, 32 / 24, near, far))).clear_colors(0x080808)
    c.rs(**(rs or dict(depth_en=1, depth_wr=1, func=1))).clear()
    idx = []
    for t, tri in enumerate(tris):
        for k, (x, y, z, rgb) in enumerate(tri):
            c.vertex(3 * t + k, x, y, z, rgb)
        idx += [3 * t, 3 * t + 1, 3 * t + 2]
    c.indices(idx).draw(0, len(tris)).present()
    return c


CLIP_CASES = {
    "fully_visible":        [[(-1, -1, -4, 0xFF0000), (1, -1, -4, 0x00FF00), (0, 1, -4, 0x0000FF)]],
    "straddle_near":        [[(-1, -1, -0.1, 0xFF0000), (1, -1, -4, 0x00FF00), (0, 1, -4, 0x0000FF)]],
    "behind_eye":           [[(-1, -1, 1, 0xFF0000), (1, -1, 2, 0x00FF00), (0, 1, 3, 0x0000FF)]],
    "one_vertex_behind":    [[(-1, -1, 2, 0xFF0000), (1, -1, -3, 0x00FF00), (0, 1, -3, 0x0000FF)]],
    "two_vertices_behind":  [[(-1, -1, 2, 0xFF0000), (1, -1, 3, 0x00FF00), (0, 1, -3, 0x0000FF)]],
    "beyond_far":           [[(-1, -1, -20, 0xFF0000), (1, -1, -30, 0x00FF00), (0, 1, -25, 0x0000FF)]],
    "straddle_far":         [[(-3, -3, -5, 0xFF0000), (3, -3, -15, 0x00FF00), (0, 3, -9, 0x0000FF)]],
    "on_near_plane":        [[(-.2, -.2, -0.5, 0xFF0000), (.2, -.2, -0.5, 0x00FF00), (0, .2, -0.5, 0x0000FF)]],
    "on_far_plane":         [[(-4, -4, -10, 0xFF0000), (4, -4, -10, 0x00FF00), (0, 4, -10, 0x0000FF)]],
    "edge_on_near_plane":   [[(-.2, -.2, -0.5, 0xFF0000), (.2, -.2, -0.5, 0x00FF00), (0, .3, -3, 0x0000FF)]],
    "huge_covers_screen":   [[(-400, -400, -4, 0xFF0000), (400, -400, -4, 0x00FF00), (0, 400, -4, 0x0000FF)]],
    "huge_with_near_clip":  [[(-300, -300, 1, 0xFF0000), (300, -300, -4, 0x00FF00), (0, 300, -4, 0x0000FF)]],
    "left_partial":         [[(-6, -1, -4, 0xFF0000), (0, -1, -4, 0x00FF00), (-3, 1, -4, 0x0000FF)]],
    "right_partial_guard":  [[(0, -1, -4, 0xFF0000), (12, -1, -4, 0x00FF00), (6, 1, -4, 0x0000FF)]],
    "outside_left_only":    [[(-30, -1, -4, 0xFF0000), (-25, -1, -4, 0x00FF00), (-28, 1, -4, 0x0000FF)]],
    "outside_top_only":     [[(-1, 30, -4, 0xFF0000), (1, 30, -4, 0x00FF00), (0, 35, -4, 0x0000FF)]],
    "all_planes_big":       [[(-50, -50, 2, 0xFF0000), (50, -50, -9.99, 0x00FF00), (0, 50, -20, 0x0000FF)]],
}


@pytest.mark.parametrize("name", sorted(CLIP_CASES))
def test_clip_boundary_cases(name):
    c = persp_scene(CLIP_CASES[name])
    rtl, g = check(P_SMALL, c)


def test_clip_counters_sanity():
    c = persp_scene(CLIP_CASES["behind_eye"] + CLIP_CASES["straddle_near"] + CLIP_CASES["fully_visible"])
    rtl, g = check(P_SMALL, c)
    assert g.cnt["tris_clip_rej"] == 1 and g.cnt["tris_clipped"] == 1 and g.cnt["tris_raster"] >= 2


def test_clip_shared_edge_across_near_plane_no_crack():
    """Two triangles share an edge that crosses the near plane; after clipping the
    union must show no gap and no overlap (LESS with equal z => zfail must be 0)."""
    X = 0.0
    quad = [(-1.5, -1, -0.3), (1.5, -1, -0.3), (1.5, 1, -6), (-1.5, 1, -6)]
    c = Cmds().mvp(SC.to_fx(SC.perspective(1.2, 32 / 24, 0.5, 10.0))).clear_colors(0)
    c.rs(depth_en=0).clear()
    for i, (x, y, z) in enumerate(quad):
        c.vertex(i, x, y, z, 0xFFFFFF)
    c.indices([0, 1, 2, 0, 2, 3]).draw(0, 2).present()
    rtl, g = check(P_SMALL, c)
    assert g.cnt["tris_clipped"] >= 1


# ----------------------------------------------------------- overflow policy
def test_transform_overflow_drops_triangle():
    c = Cmds().mvp(SC.to_fx(SC.scale(1, 1, 1))).clear_colors(0).rs(depth_en=0)
    big = 0x7FFF0000          # 32767.0 in Q16.16
    c.mvp([G.fx(30000), 0, 0, 0,  0, 1 << 16, 0, 0,  0, 0, 1 << 16, 0,  0, 0, 0, 1 << 16])
    c.vertex(0, 30000, 0, 0.5, 0xFFFFFF).vertex(1, 1, 1, .5).vertex(2, -1, 1, .5)   # x*30000 overflows s32
    c.vertex(3, -.5, -.5, .5, 0xFF0000).vertex(4, .5, -.5, .5, 0xFF0000).vertex(5, 0, .5, .5, 0xFF0000)
    c.mvp(IDENT)
    c.indices(list(range(6))).clear().draw(0, 2).present()
    rtl, g = check(P_SMALL, c)
    # second draw with the overflow matrix
    c2 = Cmds().mvp([G.fx(30000), 0, 0, 0, 0, 1 << 16, 0, 0, 0, 0, 1 << 16, 0, 0, 0, 0, 1 << 16]).rs(depth_en=0)
    c2.vertex(0, 30000, 0, .5).vertex(1, 1, 1, .5).vertex(2, -1, 1, .5).indices([0, 1, 2]).clear().draw(0, 1)
    rtl, g = check(P_SMALL, c2)
    assert g.cnt["tris_xf_ovf"] == 1 and g.cnt["tris_raster"] == 0


def test_command_errors_and_readback():
    c = Cmds().mvp(IDENT)
    c.w(G.SP_CFG, 0x7F, 1)             # unmapped CFG register
    c.w(G.SP_VERT, 256 * 8, 1)         # out of range vertex word
    c.w(G.SP_IDX, 1024, 1)
    c.w(G.SP_COLOR, 32 * 24, 1)
    c.w(9, 0, 1)                       # bad space
    c.r(G.SP_CFG, G.CFG_STATUS)
    c.w(G.SP_CFG, G.CFG_STATUS, 0)
    c.r(G.SP_CFG, G.CFG_STATUS)
    c.r(G.SP_CFG, G.CFG_ID).r(G.SP_CFG, G.CFG_MVP + 5).r(G.SP_CFG, 0x30)
    c.rs(depth_en=1, depth_wr=1).clear_colors(0xABCDEF, 0x123456).clear()
    c.r(G.SP_COLOR, 0).r(G.SP_COLOR, 32 * 24 - 1).r(G.SP_COLOR, 32 * 24).r(G.SP_DEPTH, 5).r(G.SP_FRONT, 3)
    c.w(G.SP_COLOR, 7, 0x112233).r(G.SP_COLOR, 7)
    c.present().r(G.SP_FRONT, 7).r(G.SP_COLOR, 7).r(G.SP_CFG, G.CFG_FRONT)
    rtl, g = check(P_SMALL, c)
    res = rtl["res"]
    assert [r[0] for r in res[16:21]] == [1] * 5, "all five bad writes must report err"
    assert res[21][1] == 2, "STATUS.err sticky bit set after the bad writes"
    assert res[22] == (0, 0), "writing STATUS clears the sticky bit"
    assert res[23][1] == 0
    assert res[24][1] == G.GFX_ID


# ----------------------------------------------------------------- fuzzing
@pytest.mark.parametrize("seed", range(12))
def test_random_scenes_bit_exact(seed):
    rng = random.Random(9000 + seed)
    c = Cmds()
    proj = SC.perspective(rng.uniform(.6, 1.8), 32 / 24, rng.choice([.1, .5, 1.0]), rng.choice([5.0, 20.0, 80.0]))
    mv = SC.mat_mul(SC.translate(rng.uniform(-2, 2), rng.uniform(-2, 2), rng.uniform(-6, 1)),
                    SC.mat_mul(SC.rot_y(rng.uniform(0, 6.28)), SC.rot_x(rng.uniform(0, 6.28))))
    c.mvp(SC.to_fx(SC.mat_mul(proj, mv)))
    c.rs(depth_en=rng.random() < .8, depth_wr=1, func=rng.choice([1, 3, 3, 7]),
         cull=rng.choice([0, 0, 1, 2]), front_ccw=rng.random() < .5).clear_colors(rng.randrange(1 << 24))
    n = rng.randrange(2, 9)
    for i in range(3 * n):
        c.vertex(i, rng.uniform(-3, 3), rng.uniform(-3, 3), rng.uniform(-3, 3), rng.randrange(1 << 24))
    c.indices(list(range(3 * n))).clear().draw(0, n).present()
    check(P_SMALL, c)


def test_framebuffer_capture_matches_front_buffer_each_present():
    """Simulation capture: the PPM dumped after every PRESENT must equal the model's front buffer."""
    c = Cmds().mvp(IDENT).rs(depth_en=1, depth_wr=1, func=1).clear_colors(0x102030)
    c.vertex(0, -.8, -.8, .5, 0xFF0000).vertex(1, .8, -.8, .5, 0x00FF00).vertex(2, 0, .8, .5, 0x0000FF)
    c.indices([0, 1, 2])
    for k in range(3):
        c.mvp(SC.to_fx(SC.mat_mul(SC.translate(0, 0, 0), SC.rot_z(0.4 * k))))
        c.clear().draw(0, 1).present()
    rtl = S.run_rtl(P_SMALL, c, trace=False, ppm=True)
    g = G.Gfx(P_SMALL); g.snap = True
    G.run_cmds(g, c)
    assert len(rtl["frames"]) == 3 == len(g.snapshots)
    assert rtl["frames"] == g.snapshots
    assert rtl["frames"][0] != rtl["frames"][1]
