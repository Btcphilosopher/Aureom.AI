"""
Display-side tests: gfx_scanout + video_timing + pmod_vga_adapter against the engine's real
framebuffer, on an asynchronous pixel clock.  The decoded picture must equal the reference
model's front buffer scaled by SCALE (centred, black borders), and the measured timing must
equal the configured raster timing.
"""
import subprocess, sys, tempfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "tools"), str(ROOT / "model")]
import gfxref as G            # noqa: E402
import gfxsim as S            # noqa: E402
import scene as SC            # noqa: E402
from cmdgen import Cmds, IDENT  # noqa: E402

SMALL = dict(FB_W=16, FB_H=12, SCALE=4, H=dict(H_ACTIVE=80, H_FP=4, H_SYNC=6, H_BP=6),
             V=dict(V_ACTIVE=60, V_FP=2, V_SYNC=2, V_BP=4))
VGA = dict(FB_W=160, FB_H=120, SCALE=4, H=dict(H_ACTIVE=640, H_FP=16, H_SYNC=96, H_BP=48),
           V=dict(V_ACTIVE=480, V_FP=10, V_SYNC=2, V_BP=33))


def build(ce=1, cfg=SMALL, tag="small"):
    mdir = S.BUILD / ("scanout_tb_%s_ce%d" % (tag, ce))
    gen = ["-GFB_W=%d" % cfg["FB_W"], "-GFB_H=%d" % cfg["FB_H"], "-GSCALE=%d" % cfg["SCALE"]] + \
          ["-G%s=%d" % kv for kv in list(cfg["H"].items()) + list(cfg["V"].items())]
    srcs = [str(ROOT / "rtl" / f) for f in S.RTL] + [str(ROOT / "display" / f) for f in
            ("video_timing.sv", "gfx_scanout.sv", "pmod_vga_adapter.sv")] + [str(ROOT / "display" / "tb" / "tb_scanout.sv")]
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
           "--top-module", "tb_scanout", "-GCE_DIV=%d" % ce, "--Mdir", str(mdir), "-o", "tb"] + gen + srcs
    r = subprocess.run(cmd, capture_output=True, text=True)
    assert (mdir / "tb").exists(), r.stdout[-3000:] + r.stderr[-3000:]
    return mdir / "tb"


def scene_cmds():
    c = Cmds().mvp(IDENT).rs(depth_en=1, depth_wr=1, func=1).clear_colors(0x203050)
    c.vertex(0, -.85, -.8, .5, 0xFF2020).vertex(1, .85, -.7, .5, 0x20FF20).vertex(2, -.1, .85, .5, 0x2020FF)
    c.indices([0, 1, 2]).clear().draw(0, 1).present()
    return c


def check_scanout(cfg, tag, ce, cmds):
    exe = build(ce, cfg, tag)
    FB_W, FB_H, SCALE, H, V = cfg["FB_W"], cfg["FB_H"], cfg["SCALE"], cfg["H"], cfg["V"]
    d = Path(tempfile.mkdtemp(prefix="scan_", dir=str(S.BUILD)))
    (d / "c.txt").write_text(cmds.dump_text())
    r = subprocess.run([str(exe), "+cmds=" + str(d / "c.txt"), "+out=" + str(d / "o")], capture_output=True, text=True)
    assert "TB_DONE" in r.stdout, r.stdout[-1500:]
    # ---- expected image from the reference model
    g = G.Gfx(G.Params(W=FB_W, H=FB_H)); G.run_cmds(g, cmds)
    front = g.color[g.front]
    exp = [[0] * H["H_ACTIVE"] for _ in range(V["V_ACTIVE"])]
    x0 = (H["H_ACTIVE"] - FB_W * SCALE) // 2; y0 = (V["V_ACTIVE"] - FB_H * SCALE) // 2
    for y in range(FB_H * SCALE):
        for x in range(FB_W * SCALE):
            exp[y0 + y][x0 + x] = front[(y // SCALE) * FB_W + x // SCALE]
    got = S.read_ppm(d / "o.ppm")
    got = [got[y * H["H_ACTIVE"]:(y + 1) * H["H_ACTIVE"]] for y in range(V["V_ACTIVE"])]
    diff = [(x, y) for y in range(V["V_ACTIVE"]) for x in range(H["H_ACTIVE"]) if got[y][x] != exp[y][x]]
    assert not diff, "%d pixels differ, first %s: got %06x exp %06x" % (len(diff), diff[0], got[diff[0][1]][diff[0][0]], exp[diff[0][1]][diff[0][0]])
    assert len({v for row in got for v in row}) > 20          # a real picture, not a flat colour
    t = {l.split()[0]: int(l.split()[1]) for l in (d / "o.timing").read_text().splitlines()}
    assert t["htotal"] == sum(H.values()), t
    assert t["hsync"] == H["H_SYNC"], t
    assert t["vtotal"] == sum(V.values()), t
    assert t["vsync"] == V["V_SYNC"], t
    assert t["active_px"] == H["H_ACTIVE"], t


@pytest.mark.parametrize("ce", [1, 2, 4])
def test_scanout_decodes_to_scaled_front_buffer(ce):
    check_scanout(SMALL, "small", ce, scene_cmds())


def test_scanout_native_vesa_640x480_from_160x120_no_borders():
    """The real configuration: 160x120 x4 fills the whole 640x480 raster (no border), 800x525 total."""
    c = Cmds().mvp(IDENT).rs(depth_en=1, depth_wr=1, func=1).clear_colors(0x203050)
    c.vertex(0, -.85, -.8, .5, 0xFF2020).vertex(1, .85, -.7, .5, 0x20FF20).vertex(2, -.1, .85, .5, 0x2020FF)
    c.indices([0, 1, 2]).clear().draw(0, 1).present()
    check_scanout(VGA, "vga", 1, c)
