"""gfx_tile token-protocol testbench (self-checking SV), run under Verilator."""
import os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "tools")]
import gfxsim as S            # noqa: E402
import gfxsys as Y            # noqa: E402


def test_gfx_tile_token_protocol():
    Y.ensure_patched("fixed")
    P = Y.PATCHED_DIRS["fixed"]
    mdir = S.BUILD / "tile_tb"
    srcs = ([str(ROOT / "rtl" / f) for f in S.RTL] +
            [str(P / "rtl" / "silicaflux_pkg.sv"), str(P / "rtl" / "gfx_tile.sv"),
             str(ROOT / "integration" / "tb" / "tb_gfx_tile.sv")])
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
           "-I" + str(P / "rtl"), "--top-module", "tb_gfx_tile", "--Mdir", str(mdir), "-o", "tb"] + srcs
    r = subprocess.run(cmd, capture_output=True, text=True)
    assert (mdir / "tb").exists(), r.stdout[-2000:] + r.stderr[-2000:]
    out = subprocess.run([str(mdir / "tb")], capture_output=True, text=True).stdout
    print(out)
    assert "[FAIL]" not in out and "[TIMEOUT]" not in out, out
    assert out.count("[PASS]") >= 25
