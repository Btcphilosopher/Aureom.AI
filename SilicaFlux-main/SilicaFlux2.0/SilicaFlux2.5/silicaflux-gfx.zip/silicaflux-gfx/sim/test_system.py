"""
System tests: real SilicaFlux scalar core + scheduler + graphics tile (tile 3),
programs written in SilicaFlux assembly using the GFX* opcodes.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "tools"), str(ROOT / "model")]
import gfxref as G            # noqa: E402
import gfxsys as Y            # noqa: E402
from cmdgen import Cmds, IDENT  # noqa: E402

P = G.Params(W=32, H=24)
PROG = (ROOT / "integration" / "programs" / "draw_triangle.sfx").read_text()


def tri_assets():
    c = Cmds().mvp(IDENT)
    c.vertex(0, -.8, -.8, .5, 0xFF0000).vertex(1, .8, -.8, .5, 0x00FF00).vertex(2, 0, .8, .5, 0x0000FF)
    c.indices([0, 1, 2])
    return c


def tri_program_cmds():
    c = Cmds()
    c.w(G.SP_CFG, G.CFG_RS, 7).w(G.SP_CFG, G.CFG_CLR_COLOR, 4112).clear().draw(0, 1).present()
    return c


def test_program_renders_triangle_through_scheduler():
    bad, res, g = Y.compare_system(P, PROG, tri_assets(), tri_program_cmds())
    assert not bad, "\n".join(bad)
    assert g.cnt["frags_written"] > 100 and res["cycles"] > 0


def test_baseline_scheduler_without_fix_loses_tokens():
    """EVIDENCE for integration/patches/rtl_scheduler.sv.diff: with the baseline scheduler as shipped,
    back-to-back tokens to one tile are lost (instruction released without dispatch), so the same
    program must NOT reproduce the model.  If this test ever starts failing, the fix is unnecessary."""
    bad, res, g = Y.compare_system(P, PROG, tri_assets(), tri_program_cmds(), variant="unfixed")
    assert bad, "unfixed scheduler unexpectedly behaved correctly"
    assert res["cnt"][G.CNT_NAMES.index("frags_written")] == 0 or res["front"] != g.front, bad


CUBE_PROG = (ROOT / "integration" / "programs" / "cube_frame.sfx").read_text()


def test_program_renders_cube_with_culling_and_depth():
    import scene as SC
    verts, idx = SC.cube()
    proj = SC.perspective(0.9, 32 / 24, 0.5, 20.0)
    mv = SC.mat_mul(SC.translate(0, 0, -4.2), SC.mat_mul(SC.rot_x(0.5), SC.rot_y(0.7)))
    c = Cmds().mvp(SC.to_fx(SC.mat_mul(proj, mv))).clear_colors(0x202040)
    for i, (x, y, z, col, u, v) in enumerate(verts):
        c.vertex(i, x, y, z, col, u, v)
    c.indices(idx)
    prog = Cmds().w(G.SP_CFG, G.CFG_RS, 39).clear().draw(0, 12).present()
    bad, res, g = Y.compare_system(P, CUBE_PROG, c, prog)
    assert not bad, "\n".join(bad)
    assert g.cnt["tris_culled"] == 6 and g.cnt["tris_raster"] >= 6      # back faces culled
    assert g.cnt["frags_zfail"] >= 0 and g.cnt["frags_written"] > 150
