// =============================================================================
// SilicaFlux -- Graphics Tile  (gfx_tile)
//
// A drop-in alternative to `compute_tile`: all 26 compute_tile ports are IDENTICAL in
// name, width and direction to compute_tile's (tools/check_tile_ports.py
// verifies this against the vendored baseline), so the scheduler, NoC and
// register bank need no change.  The tile executes the graphics extension
// opcodes that SilicaFlux reserves for application kernels (0x18..0x1E):
//
//   GFXWR   tile, rS, space, addr14   write rS to gfx space[space] word addr14
//   GFXRD   tile, rS, space, addr14   read  space[space] word (rS + addr14)
//                                     -> tile_result_scalar
//   GFXCLR  tile                      clear back colour buffer + depth buffer
//   GFXDRAW tile, rC, 0, first14      draw triangles first .. first+rC[15:0]-1
//   GFXPRES tile                      present: swap front/back colour buffers
//
// They are D-format instructions; the scheduler delivers
//   tok_length = space (5 bits)   tok_mem_addr = addr14   scalar_data_in = rS
// exactly as it does for DFLOAD/DFSTORE.  Completion is reported with the
// normal one-cycle tile_done pulse, so DFSYNC barriers work unchanged.
//
// Sideband ports (beyond compute_tile):
//   gfx_ld_*   host/DMA load port straight into the engine's command port.
//              The SilicaFlux scalar ISA can only build 17-bit immediates, so
//              32-bit assets (matrices, vertices, textures) arrive here.
//              Token traffic has priority; ld_ready is low while a token is
//              in flight.
//   scan_*     display/capture read port (see display/ and docs/DISPLAY.md)
// =============================================================================
`include "silicaflux_pkg.sv"

module gfx_tile
  import silicaflux_pkg::*;
#(
  parameter int TILE_ID    = 0,
  parameter int LANES      = LANES_DEFAULT,    // unused; kept for drop-in parameter parity
  parameter int FB_W       = 160,
  parameter int FB_H       = 120,
  parameter int VB_VERTS   = 256,
  parameter int IB_DEPTH   = 1024,
  parameter int TEX_LOG2W  = 6,
  parameter int TEX_LOG2H  = 6,
  parameter bit DOUBLE_BUF = 1'b1
)
(
  input  logic          clk,
  input  logic          rst_n,

  // --- Scheduler Work Token Interface (flat fields) -- identical to compute_tile
  input  logic [4:0]    tok_opcode,
  input  logic [2:0]    tok_tile_id,
  input  logic [4:0]    tok_src_reg,
  input  logic [4:0]    tok_dst_reg,
  input  logic [3:0]    tok_vsrc_reg,
  input  logic [3:0]    tok_vdst_reg,
  input  logic [13:0]   tok_mem_addr,
  input  logic [4:0]    tok_length,
  input  logic [7:0]    tok_func,
  input  logic          token_valid,
  output logic          token_ready,

  // --- Scalar Data Feed
  input  logic [XLEN-1:0]  scalar_data_in,
  input  logic [VLEN-1:0]  vector_data_in,
  input  logic [VLEN-1:0]  vector_data_in_b,

  // --- Result Output
  output logic            tile_done,
  output logic            tile_error,
  output logic [XLEN-1:0] tile_result_scalar,
  output logic [VLEN-1:0] tile_result_vector,

  // --- NoC Send Interface
  output noc_flit_t     noc_flit_out,
  output logic          noc_flit_valid,
  input  logic          noc_flit_ready,

  // --- NoC Receive Interface
  input  noc_flit_t     noc_flit_in,
  input  logic          noc_flit_in_valid,
  output logic          noc_flit_in_ready,

  // ===== graphics sideband (not part of compute_tile) =====
  input  logic          gfx_ld_valid,
  output logic          gfx_ld_ready,
  input  logic [2:0]    gfx_ld_op,
  input  logic [3:0]    gfx_ld_space,
  input  logic [31:0]   gfx_ld_addr,
  input  logic [31:0]   gfx_ld_wdata,
  output logic          gfx_ld_done,       // 1-cycle pulse
  output logic          gfx_ld_err,
  output logic [31:0]   gfx_ld_rdata,

  input  logic                         scan_clk,
  input  logic                         scan_buf,
  input  logic [$clog2(FB_W*FB_H)-1:0] scan_addr,
  output logic [23:0]                  scan_data,
  output logic                         front_sel
);
  import gfx_pkg::CMD_WRITE, gfx_pkg::CMD_READ, gfx_pkg::CMD_CLEAR,
         gfx_pkg::CMD_DRAW,  gfx_pkg::CMD_PRESENT;

  // ---------------------------------------------------------------- engine
  logic        cmd_valid, cmd_ready, cmd_done, cmd_err;
  logic [2:0]  cmd_op;
  logic [3:0]  cmd_space;
  logic [31:0] cmd_addr, cmd_wdata, cmd_rdata;

  gfx_core #(.FB_W(FB_W), .FB_H(FB_H), .VB_VERTS(VB_VERTS), .IB_DEPTH(IB_DEPTH),
             .TEX_LOG2W(TEX_LOG2W), .TEX_LOG2H(TEX_LOG2H), .DOUBLE_BUF(DOUBLE_BUF)) u_core (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_op(cmd_op), .cmd_space(cmd_space),
    .cmd_addr(cmd_addr), .cmd_wdata(cmd_wdata),
    .cmd_done(cmd_done), .cmd_err(cmd_err), .cmd_rdata(cmd_rdata),
    .scan_clk(scan_clk), .scan_buf(scan_buf), .scan_addr(scan_addr), .scan_data(scan_data),
    .front_sel_o(front_sel));

  // ---------------------------------------------------------------- tile FSM
  typedef enum logic [2:0] { T_IDLE, T_ISSUE, T_WAIT, T_HISSUE, T_HWAIT } tstate_t;
  tstate_t tstate;

  // token decode (combinational, from the live token while IDLE)
  logic        tok_known;
  logic [2:0]  d_op;
  logic [31:0] d_addr, d_wdata;
  always_comb begin
    tok_known = 1'b1;
    d_op      = CMD_WRITE;
    d_addr    = {18'b0, tok_mem_addr};
    d_wdata   = scalar_data_in;
    case (tok_opcode)
      OP_GFXWR:   begin d_op = CMD_WRITE; end
      OP_GFXRD:   begin d_op = CMD_READ;  d_addr = {18'b0, tok_mem_addr} + scalar_data_in; end
      OP_GFXCLR:  begin d_op = CMD_CLEAR; end
      OP_GFXDRAW: begin d_op = CMD_DRAW;  d_wdata = {16'b0, scalar_data_in[15:0]}; end
      OP_GFXPRES: begin d_op = CMD_PRESENT; end
      default:    tok_known = 1'b0;
    endcase
  end

  assign noc_flit_in_ready = 1'b1;          // NoC traffic is not used by this tile: consume and ignore
  assign gfx_ld_ready      = (tstate == T_IDLE) && !token_valid;
  assign tile_result_vector = '0;

  // command-port drive
  assign cmd_valid = (tstate == T_ISSUE) || (tstate == T_HISSUE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tstate <= T_IDLE; token_ready <= 1'b1;
      tile_done <= 1'b0; tile_error <= 1'b0; tile_result_scalar <= '0;
      noc_flit_valid <= 1'b0; noc_flit_out <= '0;
      cmd_op <= '0; cmd_space <= '0; cmd_addr <= '0; cmd_wdata <= '0;
      gfx_ld_done <= 1'b0; gfx_ld_err <= 1'b0; gfx_ld_rdata <= '0;
    end else begin
      tile_done   <= 1'b0;
      gfx_ld_done <= 1'b0;
      noc_flit_valid <= 1'b0;
      case (tstate)
        T_IDLE: begin
          token_ready <= 1'b1;
          if (token_valid && token_ready) begin
`ifdef GFX_TOKEN_TRACE
            $display("[gfx_tile %0d] token op=%h len=%0d addr=%0d scalar=%0d t=%0t", TILE_ID, tok_opcode, tok_length, tok_mem_addr, scalar_data_in, $time);
`endif
            token_ready <= 1'b0;
            if (tok_known) begin
              cmd_op <= d_op; cmd_space <= tok_length[3:0]; cmd_addr <= d_addr; cmd_wdata <= d_wdata;
              tstate <= T_ISSUE;
            end else begin                  // unsupported opcode: complete with error (DFSYNC etc. are benign)
              tile_done <= 1'b1;
              tile_error <= (tok_opcode != OP_DFSYNC);
              token_ready <= 1'b1;
            end
          end else if (gfx_ld_valid) begin
            token_ready <= 1'b0;            // block the scheduler while the host owns the port
            cmd_op <= gfx_ld_op; cmd_space <= gfx_ld_space; cmd_addr <= gfx_ld_addr; cmd_wdata <= gfx_ld_wdata;
            tstate <= T_HISSUE;
          end
        end

        T_ISSUE:  if (cmd_ready) tstate <= T_WAIT;
        T_WAIT:   if (cmd_done) begin
          tile_done <= 1'b1; tile_error <= cmd_err; tile_result_scalar <= cmd_rdata;
          token_ready <= 1'b1; tstate <= T_IDLE;
        end

        T_HISSUE: if (cmd_ready) tstate <= T_HWAIT;
        T_HWAIT:  if (cmd_done) begin
          gfx_ld_done <= 1'b1; gfx_ld_err <= cmd_err; gfx_ld_rdata <= cmd_rdata;
          token_ready <= 1'b1; tstate <= T_IDLE;
        end

        default: tstate <= T_IDLE;
      endcase
    end
  end
endmodule
