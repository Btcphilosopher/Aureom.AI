// =============================================================================
// tb_silicaflux_gfx_top -- system test: SilicaFlux scalar core -> scheduler ->
// graphics tile, running a real SilicaFlux program.
//
//   +prog=<hex>   SilicaFlux program (one 32-bit hex word per line); word 0 must be a NOP
//   +ld=<file>    host asset loads:  op space addr data  (hex), via the gfx sideband port
//   +out=<prefix> dumps <prefix>.fb0/.fb1/.depth/.cnt  (as tb_gfx_core)
//
// Boot sequence (the baseline has no run-gate, so a boot-ROM style spin is used):
//   1. imem[0] = JMP r0,#0 (spin), imem[1..6] must be NOP padding (baseline branch-shadow
//      hazard: wrong-path instructions at PC+1 and PC+5 of a taken branch still execute),
//      imem[7..] = program; release reset
//   2. host DMA's assets in through gfx_ld_*  (CPU is spinning)
//   3. imem[0] <= program word 0 (NOP) -> CPU runs the program
//   4. wait for HALT (the program ends with DFSYNC, so all graphics work is done)
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_silicaflux_gfx_top;
  import silicaflux_pkg::*;
  parameter int FB_W = 32;
  parameter int FB_H = 24;
  localparam int NPIX = FB_W * FB_H;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic                imem_wr_en = 1'b0;
  logic [PC_WIDTH-1:0] imem_wr_addr = '0;
  logic [XLEN-1:0]     imem_wr_data = '0;
  logic [7:0]          tile_phy_tx_data;
  logic                tile_phy_tx_valid, tile_phy_rx_credit;
  logic                halt;
  logic [XLEN-1:0]     debug_scalar_r1;

  logic        ld_valid = 1'b0, ld_ready, ld_done, ld_err;
  logic [2:0]  ld_op = '0;
  logic [3:0]  ld_space = '0;
  logic [31:0] ld_addr = '0, ld_wdata = '0, ld_rdata;
  logic [23:0] scan_data;
  logic        front_sel;

  silicaflux_gfx_top #(.LANES(4), .FB_W(FB_W), .FB_H(FB_H)) dut (
    .clk(clk), .rst_n(rst_n),
    .imem_wr_en(imem_wr_en), .imem_wr_addr(imem_wr_addr), .imem_wr_data(imem_wr_data),
    .tile_phy_tx_data(tile_phy_tx_data), .tile_phy_tx_valid(tile_phy_tx_valid),
    .tile_phy_tx_credit(1'b1), .tile_phy_rx_data(8'h00), .tile_phy_rx_valid(1'b0),
    .tile_phy_rx_credit(tile_phy_rx_credit),
    .gfx_ld_valid(ld_valid), .gfx_ld_ready(ld_ready), .gfx_ld_op(ld_op), .gfx_ld_space(ld_space),
    .gfx_ld_addr(ld_addr), .gfx_ld_wdata(ld_wdata), .gfx_ld_done(ld_done), .gfx_ld_err(ld_err),
    .gfx_ld_rdata(ld_rdata),
    .gfx_scan_clk(clk), .gfx_scan_buf(front_sel), .gfx_scan_addr('0), .gfx_scan_data(scan_data),
    .gfx_front_sel(front_sel),
    .halt(halt), .debug_scalar_r1(debug_scalar_r1));

`ifdef TB_TRACE_PIPE
  // pipeline-level debug: what the control core hands to the scheduler, and what the tile sees
  always @(posedge clk) if (rst_n && (dut.sched_valid || dut.tile_token_valid[3]))
    $display("[pipe %0t] sched_valid=%b op=%h tile=%0d ready=%b stall=%b busy3=%b | tok_valid3=%b tok_ready3=%b pc=%0d",
             $time, dut.sched_valid, dut.sched_instr.opcode, dut.sched_instr.tile_id, dut.sched_ready,
             dut.id_stall, dut.u_sched.tile_busy[3], dut.tile_token_valid[3], dut.tile_token_ready[3],
             dut.u_ctrl.is_ex.pc);
`endif
`ifdef TB_TRACE_FETCH
  always @(posedge clk) if (rst_n && $time < 700000)
    $display("[fetch %0t] pc=%0d ifid.instr=%h valid=%b | is_ex.op=%h pc=%0d valid=%b | br_taken=%b flush=%b",
             $time, dut.u_fetch.pc_reg, dut.if_id.instruction, dut.if_id.valid,
             dut.u_ctrl.is_ex.instr.opcode, dut.u_ctrl.is_ex.pc, dut.u_ctrl.is_ex.valid, dut.branch_taken, dut.pipeline_flush_int);
`endif
  longint unsigned cycles = 0;
  always @(posedge clk) begin
    cycles <= cycles + 1;
    if (cycles > 300_000_000) begin $display("TB_TIMEOUT"); $finish; end
  end

  task automatic imem_write(input int addr, input logic [31:0] data);
    @(negedge clk);
    imem_wr_en = 1'b1; imem_wr_addr = PC_WIDTH'(addr); imem_wr_data = data;
    @(negedge clk);
    imem_wr_en = 1'b0;
  endtask

  int fres;
  task automatic ld_send(input logic [2:0] op, input logic [3:0] sp, input logic [31:0] ad, input logic [31:0] wd);
    while (!ld_ready) @(negedge clk);
    ld_valid = 1'b1; ld_op = op; ld_space = sp; ld_addr = ad; ld_wdata = wd;
    @(negedge clk);
    ld_valid = 1'b0;
    while (!ld_done) @(negedge clk);
    $fdisplay(fres, "%0d %08x", ld_err, ld_rdata);
  endtask

  string progfile, ldfile, outp;
  int fprog, fld, n, nprog = 0;
  logic [31:0] w, op_i, sp_i, ad_i, wd_i;
  logic [31:0] first_word;
  localparam logic [31:0] JMP_SELF = {OP_JMP, 5'd0, 5'd0, 17'd0};

  task automatic dump(input string prefix);
    int f;
    f = $fopen({prefix, ".fb0"}, "w");
    for (int i = 0; i < NPIX; i++) $fdisplay(f, "%06x", dut.g_tiles[3].g_gfx.u_tile.u_core.u_fb.cmem0[i]);
    $fclose(f);
    f = $fopen({prefix, ".fb1"}, "w");
    for (int i = 0; i < NPIX; i++) $fdisplay(f, "%06x", dut.g_tiles[3].g_gfx.u_tile.u_core.u_fb.cmem1[i]);
    $fclose(f);
    f = $fopen({prefix, ".depth"}, "w");
    for (int i = 0; i < NPIX; i++) $fdisplay(f, "%06x", dut.g_tiles[3].g_gfx.u_tile.u_core.u_fb.zmem[i]);
    $fclose(f);
    f = $fopen({prefix, ".cnt"}, "w");
    for (int i = 0; i < gfx_pkg::NUM_CNT; i++) $fdisplay(f, "%0d", dut.g_tiles[3].g_gfx.u_tile.u_core.cnt[i]);
    $fdisplay(f, "%0d", front_sel);
    $fclose(f);
  endtask

  initial begin
    if (!$value$plusargs("prog=%s", progfile)) begin $display("TB: +prog= required"); $finish; end
    if (!$value$plusargs("ld=%s", ldfile))     begin $display("TB: +ld= required");   $finish; end
    if (!$value$plusargs("out=%s", outp))      outp = "sys_out";
    fres = $fopen({outp, ".res"}, "w");

    // 1. program (word 0 held back; spin at 0 meanwhile), reset released
    fprog = $fopen(progfile, "r");
    while (!$feof(fprog)) begin
      n = $fscanf(fprog, "%h\n", w);
      if (n == 1) begin
        if (nprog == 0) first_word = w; else imem_write(nprog, w);
        nprog++;
      end
    end
    $fclose(fprog);
    imem_write(0, JMP_SELF);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (10) @(negedge clk);

    // 2. host DMA of assets
    fld = $fopen(ldfile, "r");
    while (!$feof(fld)) begin
      n = $fscanf(fld, "%h %h %h %h\n", op_i, sp_i, ad_i, wd_i);
      if (n == 4) ld_send(op_i[2:0], sp_i[3:0], ad_i, wd_i);
    end
    $fclose(fld);
    $fclose(fres);

    // 3. start the program
    imem_write(0, first_word);

    // 4. wait for HALT to reach EXECUTE.  (The `halt` output is raised when HALT is merely FETCHED,
    //    several instructions early; HALT can only execute after every older instruction -- including
    //    the DFSYNC barrier -- has completed.)
    begin : wait_halt
      int guard;
      guard = 0;
      while (!(dut.u_ctrl.is_ex.valid && dut.u_ctrl.is_ex.instr.opcode == 5'h1F) && guard < 20_000_000) begin
        @(negedge clk); guard++;
      end
      if (guard >= 20_000_000) $display("TB_NO_HALT");
    end
    repeat (50) @(negedge clk);
    dump(outp);
    $display("TB_DONE halt=%0d cycles=%0d", halt, cycles);
    $finish;
  end
endmodule
