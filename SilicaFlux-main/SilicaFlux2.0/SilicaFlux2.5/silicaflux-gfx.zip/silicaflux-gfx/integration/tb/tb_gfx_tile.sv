// =============================================================================
// tb_gfx_tile -- token-protocol tests for gfx_tile, driven through the SAME flat
// token interface the scheduler uses for compute_tile (see tb_compute_tile.sv).
// Self-checking; prints [PASS]/[FAIL] lines in the baseline's style.
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_gfx_tile;
  import silicaflux_pkg::*;
  localparam int FB_W = 16, FB_H = 12;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic [4:0]  tok_opcode = '0;      logic [2:0]  tok_tile_id = '0;
  logic [4:0]  tok_src_reg = '0, tok_dst_reg = '0;
  logic [3:0]  tok_vsrc_reg = '0, tok_vdst_reg = '0;
  logic [13:0] tok_mem_addr = '0;    logic [4:0]  tok_length = '0;   logic [7:0] tok_func = '0;
  logic        token_valid = 1'b0, token_ready;
  logic [XLEN-1:0] scalar_data_in = '0;
  logic [VLEN-1:0] vector_data_in = '0, vector_data_in_b = '0;
  logic            tile_done, tile_error;
  logic [XLEN-1:0] tile_result_scalar;
  logic [VLEN-1:0] tile_result_vector;
  noc_flit_t noc_flit_out;  logic noc_flit_valid;  logic noc_flit_ready = 1'b1;
  noc_flit_t noc_flit_in = '0; logic noc_flit_in_valid = 1'b0, noc_flit_in_ready;

  logic ld_valid = 1'b0, ld_ready, ld_done, ld_err;
  logic [2:0] ld_op = '0; logic [3:0] ld_space = '0; logic [31:0] ld_addr = '0, ld_wdata = '0, ld_rdata;
  logic [23:0] scan_data; logic front_sel;

  gfx_tile #(.TILE_ID(3), .FB_W(FB_W), .FB_H(FB_H)) dut (
    .clk, .rst_n,
    .tok_opcode, .tok_tile_id, .tok_src_reg, .tok_dst_reg, .tok_vsrc_reg, .tok_vdst_reg,
    .tok_mem_addr, .tok_length, .tok_func, .token_valid, .token_ready,
    .scalar_data_in, .vector_data_in, .vector_data_in_b,
    .tile_done, .tile_error, .tile_result_scalar, .tile_result_vector,
    .noc_flit_out, .noc_flit_valid, .noc_flit_ready,
    .noc_flit_in, .noc_flit_in_valid, .noc_flit_in_ready,
    .gfx_ld_valid(ld_valid), .gfx_ld_ready(ld_ready), .gfx_ld_op(ld_op), .gfx_ld_space(ld_space),
    .gfx_ld_addr(ld_addr), .gfx_ld_wdata(ld_wdata), .gfx_ld_done(ld_done), .gfx_ld_err(ld_err),
    .gfx_ld_rdata(ld_rdata),
    .scan_clk(clk), .scan_buf(front_sel), .scan_addr('0), .scan_data, .front_sel);

  int pass_cnt = 0, fail_cnt = 0;
  task automatic chk(input string name, input logic [63:0] got, input logic [63:0] exp);
    if (got === exp) begin $display("[PASS] %-44s = %0h", name, got); pass_cnt++; end
    else begin $display("[FAIL] %-44s got=%0h exp=%0h", name, got, exp); fail_cnt++; end
  endtask

  // issue one token; returns after tile_done.  Counts done pulses and checks token_ready low while busy.
  int done_pulses, busy_ready_violations;
  logic [31:0] res_scalar; logic res_err;
  task automatic tok(input logic [4:0] op, input logic [4:0] len, input logic [13:0] addr, input logic [31:0] sc);
    int guard;
    while (!token_ready) @(negedge clk);
    tok_opcode = op; tok_length = len; tok_mem_addr = addr; scalar_data_in = sc; token_valid = 1'b1;
    @(negedge clk);
    token_valid = 1'b0;
    done_pulses = 0; busy_ready_violations = 0; guard = 0;
    while (done_pulses == 0 && guard < 400000) begin
      if (token_ready && !tile_done) busy_ready_violations++;      // ready must stay low until done
      if (tile_done) begin done_pulses++; res_scalar = tile_result_scalar; res_err = tile_error; end
      else @(negedge clk);
      guard++;
    end
    @(negedge clk);
    if (tile_done) done_pulses++;                                   // a second consecutive pulse would be a protocol bug
  endtask

  logic [31:0] t0;
  initial begin
    repeat (4) @(negedge clk); rst_n = 1'b1; repeat (2) @(negedge clk);

    chk("reset: token_ready", token_ready, 1'b1);
    chk("reset: tile_done low", tile_done, 1'b0);
    chk("NoC: receive port always ready", noc_flit_in_ready, 1'b1);

    // --- write/read registers
    tok(OP_GFXWR, 5'd0, 14'h002, 32'h0000_0007);                    // RS
    chk("GFXWR RS: single done pulse", done_pulses, 1);
    chk("GFXWR RS: no error", res_err, 1'b0);
    chk("GFXWR: token_ready low while busy", busy_ready_violations, 0);
    tok(OP_GFXRD, 5'd0, 14'h002, 32'd0);
    chk("GFXRD RS == 7", res_scalar, 32'd7);
    tok(OP_GFXRD, 5'd0, 14'h000, 32'd0);
    chk("GFXRD ID", res_scalar, 32'h4746_5801);
    tok(OP_GFXWR, 5'd0, 14'h015, 32'hCAFE_0001);                    // MVP[5]
    tok(OP_GFXRD, 5'd0, 14'h005, 32'h0000_0010);                    // address = rS(0x10) + addr14(5)
    chk("GFXRD effective address rS+addr14", res_scalar, 32'hCAFE_0001);

    // --- errors
    tok(OP_GFXWR, 5'd0, 14'h07F, 32'd1);
    chk("GFXWR unmapped CFG register -> tile_error", res_err, 1'b1);
    tok(OP_GFXWR, 5'd9, 14'h000, 32'd1);
    chk("GFXWR bad space -> tile_error", res_err, 1'b1);
    tok(OP_VADD, 5'd0, 14'd0, 32'd0);
    chk("foreign opcode -> done with tile_error", {done_pulses[0], res_err}, 2'b11);
    tok(OP_DFSYNC, 5'd0, 14'd0, 32'd0);
    chk("DFSYNC token completes, no error", {done_pulses[0], res_err}, 2'b10);

    // --- clear + readback (FB 16x12)
    tok(OP_GFXWR, 5'd0, 14'h003, 32'h00AB_CDEF);                    // clear colour
    tok(OP_GFXCLR, 5'd0, 14'd0, 32'd0);
    chk("GFXCLR: single done pulse", done_pulses, 1);
    chk("GFXCLR: token_ready low while sweeping", busy_ready_violations, 0);
    tok(OP_GFXRD, 5'd4, 14'd5, 32'd0);                              // SP_COLOR pixel 5
    chk("GFXRD colour after clear", res_scalar, 32'h00AB_CDEF);
    tok(OP_GFXRD, 5'd5, 14'd7, 32'd0);                              // SP_DEPTH pixel 7
    chk("GFXRD depth after clear == ZMAX", res_scalar, 32'h00FF_FFFF);
    chk("front_sel low before present", front_sel, 1'b0);
    tok(OP_GFXPRES, 5'd0, 14'd0, 32'd0);
    chk("GFXPRES toggles front_sel", front_sel, 1'b1);
    tok(OP_GFXRD, 5'd6, 14'd5, 32'd0);                              // SP_FRONT pixel 5 (was back before the swap -> now front)
    chk("GFXRD front buffer after present", res_scalar, 32'h00AB_CDEF);

    // --- host sideband port
    chk("host port ready when idle", ld_ready, 1'b1);
    ld_valid = 1'b1; ld_op = 3'd0; ld_space = 4'd0; ld_addr = 32'h003; ld_wdata = 32'h0012_3456;
    @(negedge clk); ld_valid = 1'b0;
    chk("token_ready low during host command", token_ready, 1'b0);
    while (!ld_done) @(negedge clk);
    chk("host write: no error", ld_err, 1'b0);
    tok(OP_GFXRD, 5'd0, 14'h003, 32'd0);
    chk("host write visible to token path", res_scalar, 32'h0012_3456);
    chk("tile_done NOT pulsed for host commands", dut.tile_done, 1'b0);

    // host request issued while a long token (clear) is in flight must wait
    tok_opcode = OP_GFXCLR; tok_length = '0; tok_mem_addr = '0; scalar_data_in = '0; token_valid = 1'b1;
    @(negedge clk); token_valid = 1'b0;
    chk("host port not ready while token in flight", ld_ready, 1'b0);
    ld_valid = 1'b1; ld_op = 3'd1; ld_space = 4'd0; ld_addr = 32'h000; ld_wdata = '0;      // read ID
    t0 = 0;
    while (!ld_done) begin @(negedge clk); t0++; if (t0 > 100000) break; end
    ld_valid = 1'b0;
    chk("queued host read completes after the token", {t0 > 50, ld_rdata == 32'h4746_5801}, 2'b11);

    // --- NoC ports quiet
    chk("NoC send port never valid", noc_flit_valid, 1'b0);

    $display("\n============================");
    $display("  gfx_tile TB Summary");
    $display("  PASS: %0d  FAIL: %0d", pass_cnt, fail_cnt);
    $display("============================");
    $finish;
  end
  initial begin #200_000_000; $display("[TIMEOUT]"); $finish; end
endmodule
