#!/usr/bin/env python3
"""
Derive the graphics-enabled SilicaFlux RTL from the vendored baseline.

  third_party/silicaflux-base/   (UNMODIFIED copy of the baseline v1.0 RTL)
        |  apply_patches.py     (each edit asserts it matches exactly once)
        v
  build/sfx_gfx/                 patched pkg + control_core + assembler,
                                 plus silicaflux_gfx_top.sv derived from silicaflux_top.sv
  integration/patches/*.diff     unified diffs of every change, for review

Nothing in the baseline's documented interfaces changes: the edits only USE the
opcode range 0x18..0x1E that the baseline README reserves for application
kernels, and add a new top module instead of editing silicaflux_top.
"""
import difflib, re, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BASE = ROOT / "third_party" / "silicaflux-base"
OUT = ROOT / "build" / "sfx_gfx"
PATCHES = ROOT / "integration" / "patches"


def sub1(text, old, new, what):
    n = text.count(old)
    if n != 1:
        raise SystemExit("patch '%s': anchor matched %d times (expected 1)" % (what, n))
    return text.replace(old, new)


def write_diff(name, a, b):
    if OUT != ROOT / "build" / "sfx_gfx":
        return ""                      # negative-test variants must not overwrite the reviewed diffs
    d = "".join(difflib.unified_diff(a.splitlines(True), b.splitlines(True),
                                     "baseline/" + name, "gfx/" + name))
    (PATCHES / (name.replace("/", "_") + ".diff")).write_text(d)
    return d


SCHED_OLD = ("  assign instr_ready = !sync_stall && (\n"
             "    (target_tile==3'd0 && (tile_tok_ready_0 || !tile_busy[0])) ||\n"
             "    (target_tile==3'd1 && (tile_tok_ready_1 || !tile_busy[1])) ||\n"
             "    (target_tile==3'd2 && (tile_tok_ready_2 || !tile_busy[2])) ||\n"
             "    (target_tile==3'd3 && (tile_tok_ready_3 || !tile_busy[3])));\n")
SCHED_NEW = ("  // BUGFIX (graphics integration): for TILE OPERATIONS the baseline released the instruction when the\n"
             "  // tile was 'ready || !busy' but only DISPATCHED it when 'ready && !busy'.  In the cycle in which a\n"
             "  // finishing tile re-asserted token_ready while its scoreboard bit was still set, a waiting\n"
             "  // instruction was consumed without ever being dispatched (a lost token).  For tile operations ready\n"
             "  // now means exactly 'dispatched this cycle'.  DFSYNC is a scheduler-level barrier that needs no tile,\n"
             "  // so its baseline acceptance rule is kept bit-for-bit.  Port list and protocol are unchanged.\n"
             "  logic instr_ready_legacy;\n"
             "  assign instr_ready_legacy = !sync_stall && (\n"
             "    (target_tile==3'd0 && (tile_tok_ready_0 || !tile_busy[0])) ||\n"
             "    (target_tile==3'd1 && (tile_tok_ready_1 || !tile_busy[1])) ||\n"
             "    (target_tile==3'd2 && (tile_tok_ready_2 || !tile_busy[2])) ||\n"
             "    (target_tile==3'd3 && (tile_tok_ready_3 || !tile_busy[3])));\n"
             "  assign instr_ready = (instr_in.opcode == OP_DFSYNC) ? instr_ready_legacy : dispatch_ok;\n")


def main(fix_scheduler=True, out=None):
    global OUT
    if out is not None:
        OUT = Path(out)
    if OUT.exists():
        shutil.rmtree(OUT)
    (OUT / "rtl").mkdir(parents=True)
    (OUT / "sim").mkdir(parents=True)
    PATCHES.mkdir(parents=True, exist_ok=True)
    for f in (BASE / "rtl").glob("*.sv"):
        shutil.copy(f, OUT / "rtl" / f.name)
    shutil.copy(BASE / "sim" / "sfx_asm.py", OUT / "sim" / "sfx_asm.py")

    # ---- 1. package: opcodes + D-format classification --------------------
    p = OUT / "rtl" / "silicaflux_pkg.sv"
    a = p.read_text(); b = a
    b = sub1(b, "  parameter logic [4:0] OP_VSTORE   = 5'h17; // MEM[rs1 + imm] = vrs1 (128-bit)\n",
             "  parameter logic [4:0] OP_VSTORE   = 5'h17; // MEM[rs1 + imm] = vrs1 (128-bit)\n"
             "\n"
             "  // Graphics extension group (0x18-0x1C) -- the application-kernel range that the\n"
             "  // baseline README reserves (0x18-0x1E).  D-format, executed by gfx_tile.\n"
             "  parameter logic [4:0] OP_GFXWR    = 5'h18; // write word to graphics space\n"
             "  parameter logic [4:0] OP_GFXRD    = 5'h19; // read word from graphics space\n"
             "  parameter logic [4:0] OP_GFXCLR   = 5'h1A; // clear colour + depth (draw buffer)\n"
             "  parameter logic [4:0] OP_GFXDRAW  = 5'h1B; // draw triangles\n"
             "  parameter logic [4:0] OP_GFXPRES  = 5'h1C; // present (swap buffers)\n", "pkg opcodes")
    b = sub1(b, "      OP_DFLOAD, OP_DFSTORE, OP_DFMAP, OP_DFEXEC, OP_DFSYNC:\n        get_format = FMT_D;",
             "      OP_DFLOAD, OP_DFSTORE, OP_DFMAP, OP_DFEXEC, OP_DFSYNC,\n"
             "      OP_GFXWR, OP_GFXRD, OP_GFXCLR, OP_GFXDRAW, OP_GFXPRES:\n        get_format = FMT_D;", "pkg get_format")
    p.write_text(b); write_diff("rtl/silicaflux_pkg.sv", a, b)

    # ---- 2. control core: route GFX opcodes to the scheduler ---------------
    p = OUT / "rtl" / "control_core.sv"
    a = p.read_text()
    b = sub1(a, "    is_ex.instr.opcode == OP_BCAST   || is_ex.instr.opcode == OP_VLOAD   ||\n"
                "    is_ex.instr.opcode == OP_VSTORE\n  );",
             "    is_ex.instr.opcode == OP_BCAST   || is_ex.instr.opcode == OP_VLOAD   ||\n"
             "    is_ex.instr.opcode == OP_VSTORE  ||\n"
             "    is_ex.instr.opcode == OP_GFXWR   || is_ex.instr.opcode == OP_GFXRD   ||\n"
             "    is_ex.instr.opcode == OP_GFXCLR  || is_ex.instr.opcode == OP_GFXDRAW ||\n"
             "    is_ex.instr.opcode == OP_GFXPRES\n  );", "control_core sched ops")
    p.write_text(b); write_diff("rtl/control_core.sv", a, b)

    # ---- 2b. scheduler lost-token fix ------------------------------------
    if fix_scheduler:
        p = OUT / "rtl" / "scheduler.sv"
        a = p.read_text()
        b = sub1(a, SCHED_OLD, SCHED_NEW, "scheduler instr_ready")
        p.write_text(b); write_diff("rtl/scheduler.sv", a, b)

    # ---- 3. assembler -------------------------------------------------------
    p = OUT / "sim" / "sfx_asm.py"
    a = p.read_text()
    b = sub1(a, "    'VSTORE':   0x17,\n", "    'VSTORE':   0x17,\n"
             "    'GFXWR':    0x18,\n    'GFXRD':    0x19,\n    'GFXCLR':   0x1A,\n"
             "    'GFXDRAW':  0x1B,\n    'GFXPRES':  0x1C,\n", "asm opcodes")
    b = sub1(b, "D_OPS  = {'DFLOAD', 'DFSTORE', 'DFMAP', 'DFEXEC', 'DFSYNC'}",
             "D_OPS  = {'DFLOAD', 'DFSTORE', 'DFMAP', 'DFEXEC', 'DFSYNC',\n"
             "          'GFXWR', 'GFXRD', 'GFXCLR', 'GFXDRAW', 'GFXPRES'}", "asm D_OPS")
    p.write_text(b); write_diff("sim/sfx_asm.py", a, b)

    # ---- 4. new top derived from silicaflux_top.sv --------------------------
    src = (BASE / "rtl" / "silicaflux_top.sv").read_text()
    t = src
    t = sub1(t, "module silicaflux_top\n  import silicaflux_pkg::*;\n#(\n  parameter int LANES = LANES_DEFAULT   // SIMD lane count per tile\n)",
             "module silicaflux_gfx_top\n  import silicaflux_pkg::*;\n#(\n  parameter int LANES       = LANES_DEFAULT,  // SIMD lane count per tile\n"
             "  parameter int GFX_TILE_ID = 3,              // which of the NUM_TILES tiles is the graphics tile\n"
             "  parameter int FB_W        = 160,\n  parameter int FB_H        = 120\n)", "top header")
    t = sub1(t, "  // --- Status Outputs ---\n",
             "  // --- Graphics sideband (see integration/rtl/gfx_tile.sv) ---\n"
             "  input  logic                  gfx_ld_valid,\n  output logic                  gfx_ld_ready,\n"
             "  input  logic [2:0]            gfx_ld_op,\n  input  logic [3:0]            gfx_ld_space,\n"
             "  input  logic [31:0]           gfx_ld_addr,\n  input  logic [31:0]           gfx_ld_wdata,\n"
             "  output logic                  gfx_ld_done,\n  output logic                  gfx_ld_err,\n"
             "  output logic [31:0]           gfx_ld_rdata,\n"
             "  input  logic                  gfx_scan_clk,\n  input  logic                  gfx_scan_buf,\n"
             "  input  logic [$clog2(FB_W*FB_H)-1:0] gfx_scan_addr,\n  output logic [23:0]           gfx_scan_data,\n"
             "  output logic                  gfx_front_sel,\n\n  // --- Status Outputs ---\n", "top ports")
    m = re.search(r"      compute_tile #\(\n        \.TILE_ID \(t\),\n        \.LANES   \(LANES\)\n      \) u_tile \((.*?)\n      \);\n", t, re.S)
    if not m:
        raise SystemExit("top: compute_tile instance not found")
    conns = m.group(1)
    gconns = conns + (",\n        .gfx_ld_valid(gfx_ld_valid), .gfx_ld_ready(gfx_ld_ready), .gfx_ld_op(gfx_ld_op),\n"
                      "        .gfx_ld_space(gfx_ld_space), .gfx_ld_addr(gfx_ld_addr), .gfx_ld_wdata(gfx_ld_wdata),\n"
                      "        .gfx_ld_done(gfx_ld_done), .gfx_ld_err(gfx_ld_err), .gfx_ld_rdata(gfx_ld_rdata),\n"
                      "        .scan_clk(gfx_scan_clk), .scan_buf(gfx_scan_buf), .scan_addr(gfx_scan_addr),\n"
                      "        .scan_data(gfx_scan_data), .front_sel(gfx_front_sel)")
    new = ("      if (t == GFX_TILE_ID) begin : g_gfx\n"
           "        gfx_tile #(.TILE_ID(t), .LANES(LANES), .FB_W(FB_W), .FB_H(FB_H)) u_tile (" + gconns + "\n      );\n"
           "      end else begin : g_cmp\n"
           "        compute_tile #(\n        .TILE_ID (t),\n        .LANES   (LANES)\n      ) u_tile (" + conns + "\n      );\n"
           "      end\n")
    t = t.replace(m.group(0), new)
    t = sub1(t, "// SilicaFlux — Top Level\n// silicaflux_top.sv\n",
             "// SilicaFlux — Top Level with graphics tile\n// silicaflux_gfx_top.sv  (GENERATED by integration/apply_patches.py\n"
             "// from the baseline silicaflux_top.sv; see integration/patches/silicaflux_gfx_top.sv.diff)\n", "top banner")
    (OUT / "rtl" / "silicaflux_gfx_top.sv").write_text(t)
    write_diff("rtl/silicaflux_top.sv", src, t)
    shutil.copy(ROOT / "integration" / "rtl" / "gfx_tile.sv", OUT / "rtl" / "gfx_tile.sv")
    if not fix_scheduler:
        print("NOTE: scheduler lost-token fix NOT applied (negative-test build)")
    print("patched tree written to", OUT)
    for d in sorted(PATCHES.glob("*.diff")):
        ins = sum(1 for l in d.read_text().splitlines() if l.startswith("+") and not l.startswith("+++"))
        dele = sum(1 for l in d.read_text().splitlines() if l.startswith("-") and not l.startswith("---"))
        print("  %-34s +%d -%d" % (d.name, ins, dele))


if __name__ == "__main__":
    out = sys.argv[sys.argv.index("--out") + 1] if "--out" in sys.argv else None
    main(fix_scheduler="--no-scheduler-fix" not in sys.argv, out=out)
