// =============================================================================
// SilicaFlux-GFX  --  shared package
// gfx_pkg.sv
//
// All numeric formats of the graphics extension live here and are mirrored,
// value for value, in model/gfxref.py (tools/check_consts.py enforces that).
// See docs/GFX_SPEC.md for the written contract.
//
// Style follows the SilicaFlux baseline: SystemVerilog, active-low async
// reset, no #delays or initial blocks in synthesizable RTL.
// =============================================================================
`ifndef GFX_PKG_SV
`define GFX_PKG_SV

package gfx_pkg;

  // ---------------------------------------------------------------------------
  // Fixed-point formats
  // ---------------------------------------------------------------------------
  localparam int FRAC       = 16;   // object/clip space & matrix: signed Q16.16
  localparam int SUBPIX     = 8;    // window coords: integer units of 1/256 px
  localparam int GB         = 4;    // guard band: |x|,|y| <= GB*w
  localparam int LAM_F      = 20;   // barycentric weight fraction bits (ONE = 2^20)
  localparam int DEPTH_BITS = 24;   // D24 UNORM depth
  localparam int CLIP_T     = 24;   // clip intersection parameter fraction bits
  localparam int WIN_BITS   = 24;   // window coordinate saturation width (signed)
  localparam int VTX_WORDS  = 8;    // 32-bit words per vertex record
  localparam int EW         = 56;   // edge-function accumulator width (signed)
  localparam int RECIP_MANT = 16;   // normalised-reciprocal mantissa bits
  localparam int RECIP_NUM  = 24;   // weight numerator truncated to this width
  localparam logic [DEPTH_BITS-1:0] ZMAX = {DEPTH_BITS{1'b1}};
  localparam logic [LAM_F:0]        LAM_ONE = (21'd1 << LAM_F);

  // ---------------------------------------------------------------------------
  // Address spaces (command port)
  // ---------------------------------------------------------------------------
  localparam logic [3:0] SP_CFG   = 4'd0;
  localparam logic [3:0] SP_VERT  = 4'd1;
  localparam logic [3:0] SP_IDX   = 4'd2;
  localparam logic [3:0] SP_TEX   = 4'd3;
  localparam logic [3:0] SP_COLOR = 4'd4;  // draw target (back) buffer
  localparam logic [3:0] SP_DEPTH = 4'd5;
  localparam logic [3:0] SP_FRONT = 4'd6;  // display (front) buffer, read only

  // Command opcodes (command port)
  localparam logic [2:0] CMD_WRITE   = 3'd0;
  localparam logic [2:0] CMD_READ    = 3'd1;
  localparam logic [2:0] CMD_CLEAR   = 3'd2;
  localparam logic [2:0] CMD_DRAW    = 3'd3;
  localparam logic [2:0] CMD_PRESENT = 3'd4;

  // CFG register map (word addresses)
  localparam int CFG_ID        = 32'h00;
  localparam int CFG_STATUS    = 32'h01;
  localparam int CFG_RS        = 32'h02;
  localparam int CFG_CLR_COLOR = 32'h03;
  localparam int CFG_CLR_DEPTH = 32'h04;
  localparam int CFG_FRONT     = 32'h05;
  localparam int CFG_MVP       = 32'h10;   // 0x10..0x1F row-major
  localparam int CFG_CNT       = 32'h20;   // 0x20..0x2D counters (read-only)
  localparam int CFG_CNT_CLEAR = 32'h3F;
  localparam int NUM_CNT       = 14;
  localparam logic [31:0] GFX_ID = 32'h4746_5801;

  // Counter indices (order is part of the contract)
  localparam int CN_TRIS_IN      = 0;
  localparam int CN_TRIS_XF_OVF  = 1;
  localparam int CN_TRIS_CLIPREJ = 2;
  localparam int CN_TRIS_CLIPPED = 3;
  localparam int CN_TRIS_DEGEN   = 4;
  localparam int CN_TRIS_CULLED  = 5;
  localparam int CN_TRIS_OFFSCR  = 6;
  localparam int CN_TRIS_RASTER  = 7;
  localparam int CN_FRAG_COV     = 8;
  localparam int CN_FRAG_ZFAIL   = 9;
  localparam int CN_FRAG_WRITTEN = 10;
  localparam int CN_BAD_REF      = 11;
  localparam int CN_WIN_SAT      = 12;
  localparam int CN_CLIP_BAD_W   = 13;

  // Render-state register bit positions
  localparam int RS_DEPTH_EN   = 0;
  localparam int RS_DEPTH_WR   = 1;
  localparam int RS_FUNC_LO    = 2;     // [4:2]
  localparam int RS_CULL_LO    = 5;     // [6:5]
  localparam int RS_FRONT_CCW  = 7;
  localparam int RS_TEX_EN     = 8;
  localparam int RS_PERSP_EN   = 9;
  localparam int RS_WRAP_U_CL  = 10;
  localparam int RS_WRAP_V_CL  = 11;
  localparam int RS_MODULATE   = 12;

  // ---------------------------------------------------------------------------
  // Pipeline bundles
  // ---------------------------------------------------------------------------
  // Clip-space vertex (240 bits)
  typedef struct packed {
    logic signed [31:0] x;
    logic signed [31:0] y;
    logic signed [31:0] z;
    logic signed [31:0] w;
    logic        [15:0] r;     // Q8.8
    logic        [15:0] g;
    logic        [15:0] b;
    logic signed [31:0] u;     // Q16.16
    logic signed [31:0] v;
  } cv_t;

  // Window-space vertex (216 bits)
  typedef struct packed {
    logic signed [WIN_BITS-1:0]   sx;   // 1/256 px
    logic signed [WIN_BITS-1:0]   sy;
    logic        [DEPTH_BITS-1:0] sz;   // D24
    logic        [31:0]           iw;   // 1/w, unsigned Q8.24
    logic        [15:0] r;
    logic        [15:0] g;
    logic        [15:0] b;
    logic signed [31:0] u;
    logic signed [31:0] v;
  } sv_t;

  // Triangle-setup record handed to the rasteriser
  typedef struct packed {
    sv_t v0;                       // vertices ordered so that area > 0
    sv_t v1;
    sv_t v2;
    logic signed [25:0] a0, a1, a2;      // edge e_i = A_i*px + B_i*py + C_i
    logic signed [25:0] b0, b1, b2;
    logic signed [EW-1:0] e0, e1, e2;    // edge values at the first sample point
    logic [2:0]  bias;                   // bias[i]=1: edge i is NOT top-left
    logic [10:0] x0, x1, y0, y1;         // pixel bounding box (inclusive)
    logic [16:0] rcp;                    // R = floor(2^32/(m+1))
    logic [4:0]  rk;                     // numerator pre-shift k
    logic signed [6:0] rsh;              // weight post-shift (may be < 0)
  } su_t;

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  // Bit length of x (0 for x==0)
  function automatic int unsigned bitlen64(input logic [63:0] x);
    int unsigned n;
    n = 0;
    for (int i = 0; i < 64; i++) if (x[i]) n = i + 1;
    bitlen64 = n;
  endfunction

  // Depth comparison (func encoding fixed by the contract)
  function automatic logic depth_pass(input logic [2:0] func,
                                      input logic [DEPTH_BITS-1:0] z,
                                      input logic [DEPTH_BITS-1:0] zb);
    case (func)
      3'd0: depth_pass = 1'b0;          // NEVER
      3'd1: depth_pass = (z <  zb);     // LESS
      3'd2: depth_pass = (z == zb);     // EQUAL
      3'd3: depth_pass = (z <= zb);     // LEQUAL
      3'd4: depth_pass = (z >  zb);     // GREATER
      3'd5: depth_pass = (z != zb);     // NOTEQUAL
      3'd6: depth_pass = (z >= zb);     // GEQUAL
      default: depth_pass = 1'b1;       // ALWAYS
    endcase
  endfunction

endpackage

`endif // GFX_PKG_SV
