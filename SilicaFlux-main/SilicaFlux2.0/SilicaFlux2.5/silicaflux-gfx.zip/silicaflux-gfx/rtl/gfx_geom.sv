// =============================================================================
// gfx_geom -- homogeneous clipping, perspective divide + viewport, fan emit
//
//   in : one clip-space triangle  (cv_t x3)
//   out: 0..7 window-space triangles (sv_t x3) per input triangle
//
// Clipping (Sutherland-Hodgman, inside = distance >= 0, i.e. inclusive):
//     plane 0 near   : z
//     plane 1 far    : w - z
//     plane 2 left   : x + GB*w        (guard band, GB = 4)
//     plane 3 right  : GB*w - x
//     plane 4 bottom : y + GB*w
//     plane 5 top    : GB*w - y
// A plane on which every current vertex is inside is skipped; all-outside
// rejects the triangle.  Intersections are computed from the inside vertex
// towards the outside vertex (canonical orientation), so a shared edge yields
// bit-identical vertices in both neighbouring triangles (no cracks).
//
// Projection:  window = round(ndc * viewport) in 1/256 px, rounding half up,
// using a single sequential divider.  See docs/GFX_SPEC.md section 4.
// =============================================================================
module gfx_geom
#(
  parameter int FB_W = 160,
  parameter int FB_H = 120
) (
  input  logic          clk,
  input  logic          rst_n,

  input  logic          in_valid,
  output logic          in_ready,
  input  gfx_pkg::cv_t           in_v0,
  input  gfx_pkg::cv_t           in_v1,
  input  gfx_pkg::cv_t           in_v2,

  output logic          out_valid,
  input  logic          out_ready,
  output gfx_pkg::sv_t           out_v0,
  output gfx_pkg::sv_t           out_v1,
  output gfx_pkg::sv_t           out_v2,

  output logic          busy,
  output logic [gfx_pkg::NUM_CNT-1:0] ev
);
  import gfx_pkg::*;


  // --------------------------------------------------------------------------
  // Helpers
  // --------------------------------------------------------------------------
  function automatic logic signed [35:0] plane_dist(input logic [2:0] k, input cv_t c);
    logic signed [35:0] x, y, z, w, gw;
    x  = {{4{c.x[31]}}, c.x};
    y  = {{4{c.y[31]}}, c.y};
    z  = {{4{c.z[31]}}, c.z};
    w  = {{4{c.w[31]}}, c.w};
    gw = w * 36'(GB);                 // guard band factor, gfx_pkg::GB (= 4)
    case (k)
      3'd0:    plane_dist = z;
      3'd1:    plane_dist = w - z;
      3'd2:    plane_dist = x + gw;
      3'd3:    plane_dist = gw - x;
      3'd4:    plane_dist = y + gw;
      default: plane_dist = gw - y;
    endcase
  endfunction

  // attribute k of a clip vertex as a sign-extended 34-bit value
  function automatic logic signed [33:0] cv_get(input cv_t c, input logic [3:0] k);
    case (k)
      4'd0:    cv_get = {{2{c.x[31]}}, c.x};
      4'd1:    cv_get = {{2{c.y[31]}}, c.y};
      4'd2:    cv_get = {{2{c.z[31]}}, c.z};
      4'd3:    cv_get = {{2{c.w[31]}}, c.w};
      4'd4:    cv_get = {18'b0, c.r};
      4'd5:    cv_get = {18'b0, c.g};
      4'd6:    cv_get = {18'b0, c.b};
      4'd7:    cv_get = {{2{c.u[31]}}, c.u};
      default: cv_get = {{2{c.v[31]}}, c.v};
    endcase
  endfunction

  function automatic cv_t cv_set(input cv_t c, input logic [3:0] k,
                                 input logic signed [33:0] val);
    cv_t r;
    r = c;
    case (k)
      4'd0:    r.x = val[31:0];
      4'd1:    r.y = val[31:0];
      4'd2:    r.z = val[31:0];
      4'd3:    r.w = val[31:0];
      4'd4:    r.r = val[15:0];
      4'd5:    r.g = val[15:0];
      4'd6:    r.b = val[15:0];
      4'd7:    r.u = val[31:0];
      default: r.v = val[31:0];
    endcase
    cv_set = r;
  endfunction

  // --------------------------------------------------------------------------
  // State
  // --------------------------------------------------------------------------
  typedef enum logic [4:0] {
    G_IDLE, G_DIST, G_DECIDE, G_SH, G_IS_S, G_IS_W, G_IS_L, G_IS_A, G_COPY,
    G_WCHK, G_PJ_S, G_PJ_W, G_EMIT
  } gstate_t;
  gstate_t st;

  cv_t   pin  [0:9];
  cv_t   pout [0:9];
  logic signed [35:0] pdist [0:9];
  sv_t   sp   [0:8];

  logic [3:0] n_r, nout_r, i_r;
  logic [2:0] plane_r;
  logic       any_in, any_out, clipped_r, cap_ovf;

  // intersection working set
  cv_t                iv_in, iv_out, iv_res;
  logic signed [35:0] d_in, d_out;
  logic [3:0]         sh_j;
  logic               then_nxt;
  logic [24:0]        tq;
  logic [3:0]         li;

  // projection working set
  logic [3:0] pj_r;
  logic [1:0] pstep;
  logic       sat_acc;
  logic signed [WIN_BITS-1:0] sx_r, sy_r;
  logic [DEPTH_BITS-1:0]      sz_r;
  logic [3:0] ek_r;

  // divider
  logic          div_start, div_busy, div_done;
  logic [63:0]   div_n, div_q;
  logic [39:0]   div_d;
  logic signed [36:0] den37;
  assign den37 = {d_in[35], d_in} - {d_out[35], d_out};     // > 0, up to 2^36
  gfx_div #(.NW(64), .DW(40)) u_div (
    .clk(clk), .rst_n(rst_n), .start(div_start), .n(div_n), .d(div_d),
    .busy(div_busy), .done(div_done), .q(div_q)
  );

  // --------------------------------------------------------------------------
  // Divider operand mux (combinational from state)
  // --------------------------------------------------------------------------
  cv_t pc;                                       // vertex being projected
  logic signed [35:0] pw, pnum;
  logic [34:0]        pnum_c;
  assign pc = pin[pj_r];

  always_comb begin
    pw     = {{4{pc.w[31]}}, pc.w};
    pnum   = '0;
    pnum_c = '0;
    div_n  = '0;
    div_d  = '0;
    div_start = 1'b0;
    case (st)
      G_IS_S: begin
        div_n     = {4'b0, d_in, 24'b0};
        div_d     = {3'b0, den37};
        div_start = 1'b1;
      end
      G_PJ_S: begin
        div_start = 1'b1;
        case (pstep)
          2'd0: begin   // x
            pnum   = {{4{pc.x[31]}}, pc.x} + pw * 36'(GB);
            pnum_c = pnum[35] ? 35'd0 : pnum[34:0];
            div_n  = 64'(pnum_c) * (64'(FB_W) << SUBPIX) + {32'b0, pc.w};
            div_d  = {7'b0, pc.w, 1'b0};
          end
          2'd1: begin   // y (window y grows downward)
            pnum   = pw * 36'(GB) - {{4{pc.y[31]}}, pc.y};
            pnum_c = pnum[35] ? 35'd0 : pnum[34:0];
            div_n  = 64'(pnum_c) * (64'(FB_H) << SUBPIX) + {32'b0, pc.w};
            div_d  = {7'b0, pc.w, 1'b0};
          end
          2'd2: begin   // z, clamped to [0, w]
            if (pc.z[31])              pnum_c = 35'd0;
            else if (pc.z > pc.w)      pnum_c = {3'b0, pc.w};
            else                       pnum_c = {3'b0, pc.z};
            div_n  = 64'(pnum_c) * 64'(ZMAX) * 64'd2 + {32'b0, pc.w};
            div_d  = {7'b0, pc.w, 1'b0};
          end
          default: begin // 1/w, unsigned Q8.24
            div_n  = 64'd1 << 40;
            div_d  = {8'b0, pc.w};
          end
        endcase
      end
      default: ;
    endcase
  end

  // wide window result before saturation
  logic signed [65:0] win_x, win_y;
  localparam longint unsigned KX = (64'(GB) - 64'd1) * 64'(FB_W) * 64'(1 << (SUBPIX - 1));
  localparam longint unsigned KY = (64'(GB) - 64'd1) * 64'(FB_H) * 64'(1 << (SUBPIX - 1));
  assign win_x = $signed({2'b0, div_q}) - 66'($signed({1'b0, KX}));
  assign win_y = $signed({2'b0, div_q}) - 66'($signed({1'b0, KY}));

  localparam logic signed [65:0] WMAX =  66'sd8388607;    //  2^23 - 1
  localparam logic signed [65:0] WMIN = -66'sd8388608;    // -2^23

  // any vertex with w <= 0 ?
  logic wbad;
  always_comb begin
    wbad = 1'b0;
    for (int q = 0; q < 10; q++)
      if (q < int'(n_r) && pin[q].w <= 32'sd0) wbad = 1'b1;
  end

  // lerp datapath
  logic signed [33:0] l_a, l_b, l_res;
  logic signed [33:0] l_delta;
  logic signed [59:0] l_prod;
  always_comb begin
    l_a     = cv_get(iv_in,  li);
    l_b     = cv_get(iv_out, li);
    l_delta = l_b - l_a;
    l_prod  = l_delta * $signed({1'b0, tq});
    l_res   = l_a + 34'(l_prod >>> CLIP_T);
  end

  // current SH edge
  logic [3:0] sh_next;
  assign sh_next = (i_r == n_r - 4'd1) ? 4'd0 : i_r + 4'd1;

  // --------------------------------------------------------------------------
  // Outputs
  // --------------------------------------------------------------------------
  assign in_ready  = (st == G_IDLE);
  assign out_valid = (st == G_EMIT);
  assign busy      = (st != G_IDLE);
  assign out_v0    = sp[0];
  assign out_v1    = sp[ek_r];
  assign out_v2    = sp[ek_r + 4'd1];

`ifdef GFX_TRACE
  task automatic pr_sv(input sv_t s);
    $write("%08x,%08x,%08x,%08x,%08x,%08x,%08x,%08x,%08x ",
           {{8{s.sx[WIN_BITS-1]}}, s.sx}, {{8{s.sy[WIN_BITS-1]}}, s.sy},
           {8'b0, s.sz}, s.iw, {16'b0, s.r}, {16'b0, s.g}, {16'b0, s.b}, s.u, s.v);
  endtask
`endif

  // --------------------------------------------------------------------------
  // FSM
  // --------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= G_IDLE;
      n_r <= '0; nout_r <= '0; i_r <= '0; plane_r <= '0;
      any_in <= 1'b0; any_out <= 1'b0; clipped_r <= 1'b0; cap_ovf <= 1'b0;
      iv_in <= '0; iv_out <= '0; iv_res <= '0; d_in <= '0; d_out <= '0;
      sh_j <= '0; then_nxt <= 1'b0; tq <= '0; li <= '0;
      pj_r <= '0; pstep <= '0; sat_acc <= 1'b0; ek_r <= '0;
      sx_r <= '0; sy_r <= '0; sz_r <= '0;
      ev <= '0;
      for (int q = 0; q < 10; q++) begin pin[q] <= '0; pout[q] <= '0; pdist[q] <= '0; end
      for (int q = 0; q < 9;  q++) sp[q] <= '0;
    end else begin
      ev <= '0;
      case (st)
        // ------------------------------------------------------------------
        G_IDLE: if (in_valid) begin
          pin[0] <= in_v0; pin[1] <= in_v1; pin[2] <= in_v2;
          n_r <= 4'd3; plane_r <= 3'd0; clipped_r <= 1'b0; cap_ovf <= 1'b0;
          i_r <= 4'd0; any_in <= 1'b0; any_out <= 1'b0;
          st <= G_DIST;
        end

        // ------------------------------------------------------------------
        G_DIST: begin
          pdist[i_r] <= plane_dist(plane_r, pin[i_r]);
          if (plane_dist(plane_r, pin[i_r]) >= 36'sd0) any_in  <= 1'b1;
          else                                         any_out <= 1'b1;
          if (i_r == n_r - 4'd1) begin
            i_r <= 4'd0;
            st  <= G_DECIDE;
          end else begin
            i_r <= i_r + 4'd1;
          end
        end

        G_DECIDE: begin
          if (!any_out) begin                      // plane fully satisfied: skip
            if (plane_r == 3'd5) begin
              if (clipped_r) ev[CN_TRIS_CLIPPED] <= 1'b1;
              st <= G_WCHK;
            end else begin
              plane_r <= plane_r + 3'd1; any_in <= 1'b0; any_out <= 1'b0;
              st <= G_DIST;
            end
          end else if (!any_in) begin              // fully outside: reject
            ev[CN_TRIS_CLIPREJ] <= 1'b1;
            st <= G_IDLE;
          end else begin                           // straddles: run S-H on this plane
            clipped_r <= 1'b1;
            nout_r <= 4'd0;
            i_r    <= 4'd0;
            st     <= G_SH;
          end
        end

        // ------------------------------------------------------------------
        // Sutherland-Hodgman, one polygon edge (i -> i+1) per visit
        G_SH: begin
          if (pdist[i_r] >= 36'sd0 && pdist[sh_next] >= 36'sd0) begin
            if (nout_r < 4'd9) begin
              pout[nout_r] <= pin[sh_next];
              nout_r <= nout_r + 4'd1;
            end else cap_ovf <= 1'b1;
            if (i_r == n_r - 4'd1) st <= G_COPY; else i_r <= i_r + 4'd1;
          end else if (pdist[i_r] >= 36'sd0) begin            // leaving: inside = cur
            iv_in <= pin[i_r]; iv_out <= pin[sh_next];
            d_in  <= pdist[i_r]; d_out <= pdist[sh_next];
            then_nxt <= 1'b0; sh_j <= sh_next;
            st <= G_IS_S;
          end else if (pdist[sh_next] >= 36'sd0) begin         // entering: inside = nxt
            iv_in <= pin[sh_next]; iv_out <= pin[i_r];
            d_in  <= pdist[sh_next]; d_out <= pdist[i_r];
            then_nxt <= 1'b1; sh_j <= sh_next;
            st <= G_IS_S;
          end else begin                                       // both outside
            if (i_r == n_r - 4'd1) st <= G_COPY; else i_r <= i_r + 4'd1;
          end
        end

        G_IS_S: st <= G_IS_W;                      // div_start is combinational here

        G_IS_W: if (div_done) begin
          tq <= div_q[24:0];
          li <= 4'd0;
          st <= G_IS_L;
        end

        G_IS_L: begin                              // one attribute per cycle
          iv_res <= cv_set(iv_res, li, l_res);
          if (li == 4'd8) st <= G_IS_A; else li <= li + 4'd1;
        end

        G_IS_A: begin
          if (then_nxt) begin
            if (nout_r <= 4'd7) begin
              pout[nout_r]        <= iv_res;
              pout[nout_r + 4'd1] <= pin[sh_j];
              nout_r <= nout_r + 4'd2;
            end else cap_ovf <= 1'b1;
          end else begin
            if (nout_r <= 4'd8) begin
              pout[nout_r] <= iv_res;
              nout_r <= nout_r + 4'd1;
            end else cap_ovf <= 1'b1;
          end
          if (i_r == n_r - 4'd1) st <= G_COPY;
          else begin i_r <= i_r + 4'd1; st <= G_SH; end
        end

        G_COPY: begin
          for (int q = 0; q < 10; q++) pin[q] <= pout[q];
          n_r <= nout_r;
          if (cap_ovf || nout_r < 4'd3) begin           // capacity / degenerate: reject
            ev[CN_TRIS_CLIPREJ] <= 1'b1;
            st <= G_IDLE;
          end else if (plane_r == 3'd5) begin
            if (clipped_r) ev[CN_TRIS_CLIPPED] <= 1'b1;
            st <= G_WCHK;
          end else begin
            plane_r <= plane_r + 3'd1; i_r <= 4'd0; any_in <= 1'b0; any_out <= 1'b0;
            st <= G_DIST;
          end
        end

        // ------------------------------------------------------------------
        G_WCHK: begin
          if (wbad) begin
            ev[CN_CLIP_BAD_W] <= 1'b1;
            st <= G_IDLE;
          end else begin
            pj_r <= 4'd0; pstep <= 2'd0; sat_acc <= 1'b0;
            st <= G_PJ_S;
          end
        end

        G_PJ_S: st <= G_PJ_W;                      // div_start combinational

        G_PJ_W: if (div_done) begin
          case (pstep)
            2'd0: begin
              if (win_x > WMAX)      begin sx_r <= WMAX[WIN_BITS-1:0]; sat_acc <= 1'b1; end
              else if (win_x < WMIN) begin sx_r <= WMIN[WIN_BITS-1:0]; sat_acc <= 1'b1; end
              else                         sx_r <= win_x[WIN_BITS-1:0];
            end
            2'd1: begin
              if (win_y > WMAX)      begin sy_r <= WMAX[WIN_BITS-1:0]; sat_acc <= 1'b1; end
              else if (win_y < WMIN) begin sy_r <= WMIN[WIN_BITS-1:0]; sat_acc <= 1'b1; end
              else                         sy_r <= win_y[WIN_BITS-1:0];
            end
            2'd2: sz_r <= (div_q > 64'(ZMAX)) ? ZMAX : div_q[DEPTH_BITS-1:0];
            default: ;
          endcase
          if (pstep == 2'd3) begin
            sp[pj_r].sx <= sx_r; sp[pj_r].sy <= sy_r; sp[pj_r].sz <= sz_r;
            sp[pj_r].iw <= (div_q > 64'hFFFF_FFFF) ? 32'hFFFF_FFFF : div_q[31:0];
            sp[pj_r].r <= pc.r; sp[pj_r].g <= pc.g; sp[pj_r].b <= pc.b;
            sp[pj_r].u <= pc.u; sp[pj_r].v <= pc.v;
            if (sat_acc) ev[CN_WIN_SAT] <= 1'b1;
            sat_acc <= 1'b0;
            pstep   <= 2'd0;
            if (pj_r == n_r - 4'd1) begin
              ek_r <= 4'd1;
              st   <= G_EMIT;
            end else begin
              pj_r <= pj_r + 4'd1;
              st   <= G_PJ_S;
            end
          end else begin
            pstep <= pstep + 2'd1;
            st    <= G_PJ_S;
          end
        end

        // ------------------------------------------------------------------
        G_EMIT: if (out_ready) begin
`ifdef GFX_TRACE
          $write("SC "); pr_sv(out_v0); pr_sv(out_v1); pr_sv(out_v2); $write("\n");
`endif
          if (ek_r == n_r - 4'd2) st <= G_IDLE;
          else                    ek_r <= ek_r + 4'd1;
        end

        default: st <= G_IDLE;
      endcase
    end
  end
endmodule
