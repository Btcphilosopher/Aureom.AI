// =============================================================================
// gfx_core -- the SilicaFlux graphics rendering engine
//
//   command port --> register file / memories
//                \-> DRAW: xform -> geom (clip+project) -> setup -> raster -> fbmem
//
// The command port is deliberately simple and engine-local; gfx_tile.sv maps
// SilicaFlux work tokens onto it.  Commands execute strictly one at a time.
//
//   cmd_valid && cmd_ready          accepts a command
//   cmd_done  (1-cycle pulse)       command finished; cmd_err / cmd_rdata valid
//
// Display/capture hardware attaches ONLY through the scan_* port and
// front_sel_o; nothing in this file knows about video timing.
// =============================================================================
module gfx_core
#(
  parameter int FB_W       = 160,
  parameter int FB_H       = 120,
  parameter int VB_VERTS   = 256,
  parameter int IB_DEPTH   = 1024,
  parameter int TEX_LOG2W  = 6,
  parameter int TEX_LOG2H  = 6,
  parameter bit DOUBLE_BUF = 1'b1
) (
  input  logic          clk,
  input  logic          rst_n,

  // ---- command port
  input  logic          cmd_valid,
  output logic          cmd_ready,
  input  logic [2:0]    cmd_op,
  input  logic [3:0]    cmd_space,
  input  logic [31:0]   cmd_addr,
  input  logic [31:0]   cmd_wdata,
  output logic          cmd_done,
  output logic          cmd_err,
  output logic [31:0]   cmd_rdata,

  // ---- display / capture boundary (own clock domain)
  input  logic                         scan_clk,
  input  logic                         scan_buf,
  input  logic [$clog2(FB_W*FB_H)-1:0] scan_addr,
  output logic [23:0]                  scan_data,
  output logic                         front_sel_o
);
  import gfx_pkg::*;

  localparam int NPIX = FB_W * FB_H;
  localparam int AW   = $clog2(NPIX);
  localparam int VBW  = VB_VERTS * VTX_WORDS;
  localparam int NTEX = (1 << TEX_LOG2W) << TEX_LOG2H;

  // --------------------------------------------------------------------------
  // Registers
  // --------------------------------------------------------------------------
  logic [12:0]        rs_r;
  logic [23:0]        clr_color_r;
  logic [DEPTH_BITS-1:0] clr_depth_r;
  logic signed [31:0] mvp [0:15];
  logic               front_r;
  logic               err_sticky;
  logic [31:0]        cnt [0:NUM_CNT-1];

  assign front_sel_o = front_r;

  logic [511:0] mvp_flat;
  always_comb for (int i = 0; i < 16; i++) mvp_flat[32*i +: 32] = mvp[i];

  // --------------------------------------------------------------------------
  // Command sequencer
  // --------------------------------------------------------------------------
  typedef enum logic [3:0] { C_IDLE, C_EXEC, C_RD1, C_CLR, C_DRAW0, C_DRAW1 } cstate_t;
  cstate_t st;

  logic [2:0]  op_r;
  logic [3:0]  sp_r;
  logic [31:0] addr_r, wd_r;
  logic [AW-1:0] ctr;

  assign cmd_ready = (st == C_IDLE);

  wire is_exec = (st == C_EXEC);
  wire is_wr   = is_exec && (op_r == CMD_WRITE);

  // ---- host write decode
  wire wr_cfg   = is_wr && (sp_r == SP_CFG);
  wire in_vert  = (addr_r < 32'(VBW));
  wire in_idx   = (addr_r < 32'(IB_DEPTH));
  wire in_tex   = (addr_r < 32'(NTEX));
  wire in_pix   = (addr_r < 32'(NPIX));
  wire wr_vert  = is_wr && (sp_r == SP_VERT)  && in_vert;
  wire wr_idx   = is_wr && (sp_r == SP_IDX)   && in_idx;
  wire wr_tex   = is_wr && (sp_r == SP_TEX)   && in_tex;
  wire wr_color = is_wr && (sp_r == SP_COLOR) && in_pix;
  wire wr_depth = is_wr && (sp_r == SP_DEPTH) && in_pix;

  logic wr_bad;
  always_comb begin
    wr_bad = 1'b0;
    case (sp_r)
      SP_CFG: begin
        wr_bad = 1'b1;
        if (addr_r[31:8] == 24'd0) begin
          case (addr_r[7:0])
            8'(CFG_RS), 8'(CFG_CLR_COLOR), 8'(CFG_CLR_DEPTH),
            8'(CFG_CNT_CLEAR), 8'(CFG_STATUS): wr_bad = 1'b0;
            default: if (addr_r[7:0] >= 8'(CFG_MVP) && addr_r[7:0] < 8'(CFG_MVP) + 8'd16) wr_bad = 1'b0;
          endcase
        end
      end
      SP_VERT:  wr_bad = !in_vert;
      SP_IDX:   wr_bad = !in_idx;
      SP_TEX:   wr_bad = !in_tex;
      SP_COLOR: wr_bad = !in_pix;
      SP_DEPTH: wr_bad = !in_pix;
      default:  wr_bad = 1'b1;
    endcase
  end

  // ---- CFG read mux
  logic [31:0] cfg_rd;
  always_comb begin
    cfg_rd = 32'd0;
    if (addr_r[31:8] == 24'd0) begin
      if (addr_r[7:0] == 8'(CFG_ID))             cfg_rd = GFX_ID;
      else if (addr_r[7:0] == 8'(CFG_STATUS))    cfg_rd = {30'd0, err_sticky, 1'b0};
      else if (addr_r[7:0] == 8'(CFG_RS))        cfg_rd = {19'd0, rs_r};
      else if (addr_r[7:0] == 8'(CFG_CLR_COLOR)) cfg_rd = {8'd0, clr_color_r};
      else if (addr_r[7:0] == 8'(CFG_CLR_DEPTH)) cfg_rd = {8'd0, clr_depth_r};
      else if (addr_r[7:0] == 8'(CFG_FRONT))     cfg_rd = {31'd0, front_r};
      else if (addr_r[7:0] >= 8'(CFG_MVP) && addr_r[7:0] < 8'(CFG_MVP) + 8'd16)
                                                  cfg_rd = mvp[addr_r[3:0]];
      else if (addr_r[7:0] >= 8'(CFG_CNT) && addr_r[7:0] < 8'(CFG_CNT) + 8'(NUM_CNT))
                                                  cfg_rd = cnt[4'(addr_r[7:0] - 8'(CFG_CNT))];
    end
  end

  // --------------------------------------------------------------------------
  // Memories
  // --------------------------------------------------------------------------
  logic [31:0] vb_rdata, ib_rdata_w, tex_rdata;
  logic [$clog2(VBW)-1:0]      vb_raddr;
  logic [$clog2(IB_DEPTH)-1:0] ib_raddr;

  gfx_ram #(.DW(32), .DEPTH(VBW)) u_vmem (
    .clk(clk), .we(wr_vert), .waddr(addr_r[$clog2(VBW)-1:0]), .wdata(wd_r),
    .raddr(vb_raddr), .rdata(vb_rdata));
  gfx_ram #(.DW(32), .DEPTH(IB_DEPTH)) u_imem (
    .clk(clk), .we(wr_idx), .waddr(addr_r[$clog2(IB_DEPTH)-1:0]), .wdata({16'd0, wd_r[15:0]}),
    .raddr(ib_raddr), .rdata(ib_rdata_w));
  logic [$clog2(NTEX)-1:0] tex_raddr;
  gfx_ram #(.DW(32), .DEPTH(NTEX)) u_tmem (
    .clk(clk), .we(wr_tex), .waddr(addr_r[$clog2(NTEX)-1:0]), .wdata({8'd0, wd_r[23:0]}),
    .raddr(tex_raddr), .rdata(tex_rdata));

  // framebuffer / depth
  logic                  ras_c_we, ras_z_we;
  logic [AW-1:0]         ras_c_waddr, ras_z_waddr, ras_z_raddr;
  logic [23:0]           ras_c_wdata;
  logic [DEPTH_BITS-1:0] ras_z_wdata, z_rdata;

  wire is_clr = (st == C_CLR);
  wire c_we   = is_clr | wr_color | ras_c_we;
  wire z_we   = is_clr | wr_depth | ras_z_we;
  wire [AW-1:0] c_waddr = is_clr ? ctr : (is_exec ? addr_r[AW-1:0] : ras_c_waddr);
  wire [AW-1:0] z_waddr = is_clr ? ctr : (is_exec ? addr_r[AW-1:0] : ras_z_waddr);
  wire [23:0]   c_wdata = is_clr ? clr_color_r : (is_exec ? wd_r[23:0] : ras_c_wdata);
  wire [DEPTH_BITS-1:0] z_wdata = is_clr ? clr_depth_r : (is_exec ? wd_r[DEPTH_BITS-1:0] : ras_z_wdata);
  wire host_rd = is_exec || (st == C_RD1);
  wire [AW-1:0] z_raddr = host_rd ? addr_r[AW-1:0] : ras_z_raddr;

  logic [23:0] h_rdata;
  gfx_fbmem #(.FB_W(FB_W), .FB_H(FB_H), .DOUBLE_BUF(DOUBLE_BUF)) u_fb (
    .clk(clk), .front_sel(front_r),
    .c_we(c_we), .c_waddr(c_waddr), .c_wdata(c_wdata),
    .z_we(z_we), .z_waddr(z_waddr), .z_wdata(z_wdata),
    .z_raddr(z_raddr), .z_rdata(z_rdata),
    .h_raddr(addr_r[AW-1:0]), .h_front(sp_r == SP_FRONT), .h_rdata(h_rdata),
    .scan_clk(scan_clk), .scan_buf(scan_buf), .scan_addr(scan_addr), .scan_data(scan_data));

  // --------------------------------------------------------------------------
  // Pipeline
  // --------------------------------------------------------------------------
  logic xf_start, xf_busy;
  cv_t  xf_v0, xf_v1, xf_v2;
  logic xf_valid, xf_ready;
  logic [NUM_CNT-1:0] ev_xf, ev_geom, ev_setup, ev_ras;

  gfx_xform #(.VB_VERTS(VB_VERTS), .IB_DEPTH(IB_DEPTH)) u_xf (
    .clk(clk), .rst_n(rst_n), .start(xf_start),
    .first_tri(addr_r[15:0]), .count_tri(wd_r[15:0]), .busy(xf_busy),
    .mvp_flat(mvp_flat),
    .ib_raddr(ib_raddr), .ib_rdata(ib_rdata_w),
    .vb_raddr(vb_raddr), .vb_rdata(vb_rdata),
    .out_valid(xf_valid), .out_ready(xf_ready), .out_v0(xf_v0), .out_v1(xf_v1), .out_v2(xf_v2),
    .ev(ev_xf));

  logic gm_valid, gm_ready, gm_busy;
  sv_t  gm_v0, gm_v1, gm_v2;
  gfx_geom #(.FB_W(FB_W), .FB_H(FB_H)) u_geom (
    .clk(clk), .rst_n(rst_n),
    .in_valid(xf_valid), .in_ready(xf_ready), .in_v0(xf_v0), .in_v1(xf_v1), .in_v2(xf_v2),
    .out_valid(gm_valid), .out_ready(gm_ready), .out_v0(gm_v0), .out_v1(gm_v1), .out_v2(gm_v2),
    .busy(gm_busy), .ev(ev_geom));

  logic su_valid, su_ready, su_busy;
  su_t  su_rec;
  gfx_setup #(.FB_W(FB_W), .FB_H(FB_H)) u_setup (
    .clk(clk), .rst_n(rst_n),
    .cull(rs_r[RS_CULL_LO +: 2]), .front_ccw(rs_r[RS_FRONT_CCW]),
    .in_valid(gm_valid), .in_ready(gm_ready), .in_v0(gm_v0), .in_v1(gm_v1), .in_v2(gm_v2),
    .out_valid(su_valid), .out_ready(su_ready), .out_su(su_rec),
    .busy(su_busy), .ev(ev_setup));

  logic ras_busy;
  gfx_raster #(.FB_W(FB_W), .FB_H(FB_H), .TEX_LOG2W(TEX_LOG2W), .TEX_LOG2H(TEX_LOG2H)) u_raster (
    .clk(clk), .rst_n(rst_n),
    .depth_en(rs_r[RS_DEPTH_EN]), .depth_wr(rs_r[RS_DEPTH_WR]),
    .depth_func(rs_r[RS_FUNC_LO +: 3]),
    .tex_en(rs_r[RS_TEX_EN]), .persp_en(rs_r[RS_PERSP_EN]),
    .clamp_u(rs_r[RS_WRAP_U_CL]), .clamp_v(rs_r[RS_WRAP_V_CL]), .modulate(rs_r[RS_MODULATE]),
    .in_valid(su_valid), .in_ready(su_ready), .in_su(su_rec), .busy(ras_busy),
    .z_raddr(ras_z_raddr), .z_rdata(z_rdata),
    .z_we(ras_z_we), .z_waddr(ras_z_waddr), .z_wdata(ras_z_wdata),
    .c_we(ras_c_we), .c_waddr(ras_c_waddr), .c_wdata(ras_c_wdata),
    .tex_raddr(tex_raddr), .tex_rdata(tex_rdata[23:0]),
    .ev(ev_ras));

  wire pipe_idle = !xf_busy && !gm_busy && !su_busy && !ras_busy;
  assign xf_start = is_exec && (op_r == CMD_DRAW);

  // --------------------------------------------------------------------------
  // Statistics counters (32-bit, saturating)
  // --------------------------------------------------------------------------
  logic [NUM_CNT-1:0] ev_all;
  assign ev_all = ev_xf | ev_geom | ev_setup | ev_ras;

  logic cnt_clear;
  assign cnt_clear = wr_cfg && (addr_r[7:0] == 8'(CFG_CNT_CLEAR)) && (addr_r[31:8] == 24'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NUM_CNT; i++) cnt[i] <= 32'd0;
    end else begin
      for (int i = 0; i < NUM_CNT; i++) begin
        if (cnt_clear)                          cnt[i] <= 32'd0;
        else if (ev_all[i] && cnt[i] != 32'hFFFF_FFFF) cnt[i] <= cnt[i] + 32'd1;
      end
    end
  end

  // --------------------------------------------------------------------------
  // Sequencer FSM
  // --------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= C_IDLE; op_r <= '0; sp_r <= '0; addr_r <= '0; wd_r <= '0; ctr <= '0;
      cmd_done <= 1'b0; cmd_err <= 1'b0; cmd_rdata <= '0;
      rs_r <= '0; clr_color_r <= '0; clr_depth_r <= ZMAX; front_r <= 1'b0; err_sticky <= 1'b0;
      for (int i = 0; i < 16; i++) mvp[i] <= '0;
    end else begin
      cmd_done <= 1'b0;
      cmd_err  <= 1'b0;
      case (st)
        C_IDLE: if (cmd_valid) begin
          op_r <= cmd_op; sp_r <= cmd_space; addr_r <= cmd_addr; wd_r <= cmd_wdata;
          cmd_rdata <= 32'd0;                 // rdata is only meaningful for READ
          st <= C_EXEC;
        end

        C_EXEC: begin
          case (op_r)
            CMD_WRITE: begin
              if (sp_r == SP_CFG && !wr_bad) begin
                if (addr_r[7:0] == 8'(CFG_RS))             rs_r        <= wd_r[12:0];
                else if (addr_r[7:0] == 8'(CFG_CLR_COLOR)) clr_color_r <= wd_r[23:0];
                else if (addr_r[7:0] == 8'(CFG_CLR_DEPTH)) clr_depth_r <= wd_r[DEPTH_BITS-1:0];
                else if (addr_r[7:0] == 8'(CFG_STATUS))    err_sticky  <= 1'b0;
                else if (addr_r[7:0] >= 8'(CFG_MVP) && addr_r[7:0] < 8'(CFG_MVP) + 8'd16)
                  mvp[addr_r[3:0]] <= $signed(wd_r);
              end
              if (wr_bad) err_sticky <= 1'b1;
              cmd_done <= 1'b1; cmd_err <= wr_bad; st <= C_IDLE;
            end

            CMD_READ: begin
              case (sp_r)
                SP_CFG: begin
                  cmd_rdata <= cfg_rd; cmd_done <= 1'b1; st <= C_IDLE;
                end
                SP_COLOR, SP_FRONT, SP_DEPTH: st <= C_RD1;
                default: begin
                  cmd_rdata <= 32'd0; cmd_done <= 1'b1; st <= C_IDLE;
                end
              endcase
            end

            CMD_CLEAR: begin ctr <= '0; st <= C_CLR; end

            CMD_DRAW:  st <= C_DRAW0;

            CMD_PRESENT: begin
              if (DOUBLE_BUF) front_r <= ~front_r;
              cmd_done <= 1'b1; st <= C_IDLE;
            end

            default: begin cmd_done <= 1'b1; cmd_err <= 1'b1; err_sticky <= 1'b1; st <= C_IDLE; end
          endcase
        end

        C_RD1: begin                       // read data is valid this cycle
          if (addr_r < 32'(NPIX)) cmd_rdata <= (sp_r == SP_DEPTH) ? {8'd0, z_rdata} : {8'd0, h_rdata};
          else                    cmd_rdata <= 32'd0;
          cmd_done <= 1'b1; st <= C_IDLE;
        end

        C_CLR: begin
          if (ctr == AW'(NPIX - 1)) begin
            cmd_done <= 1'b1; st <= C_IDLE;
          end else begin
            ctr <= ctr + AW'(1);
          end
        end

        C_DRAW0: st <= C_DRAW1;            // let the first stage raise `busy`

        C_DRAW1: if (pipe_idle) begin
          cmd_done <= 1'b1; st <= C_IDLE;
        end

        default: st <= C_IDLE;
      endcase
    end
  end
endmodule
