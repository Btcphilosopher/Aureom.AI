// =============================================================================
// gfx_setup -- triangle setup
//
//   * signed area (2x) in 1/256-px units; zero area -> degenerate drop
//   * facing from the sign of the area (window y grows DOWN, so a positive
//     area is clockwise on screen) and the cull / front-face render state
//   * vertices re-ordered so that area > 0  =>  inside <=> all edge fns >= 0
//   * edge equations  e_i(p) = A_i*px + B_i*py + C_i  (edge i opposite vertex i)
//   * top-left ownership as a per-edge bias:  bias_i = 1 unless
//         A_i > 0  ||  (A_i == 0 && B_i > 0)
//   * pixel bounding box, clipped to the framebuffer; empty -> offscreen drop
//   * first-sample edge values at pixel centre (x0+1/2, y0+1/2)
//   * block floating-point reciprocal of the area for barycentric weights:
//         R = floor(2^32 / (m+1)),  m = area normalised to 16 bits
// =============================================================================
module gfx_setup
#(
  parameter int FB_W = 160,
  parameter int FB_H = 120
) (
  input  logic          clk,
  input  logic          rst_n,

  input  logic [1:0]    cull,        // 0 none, 1 back, 2 front, 3 all
  input  logic          front_ccw,   // front faces are counter-clockwise on screen

  input  logic          in_valid,
  output logic          in_ready,
  input  gfx_pkg::sv_t           in_v0,
  input  gfx_pkg::sv_t           in_v1,
  input  gfx_pkg::sv_t           in_v2,

  output logic          out_valid,
  input  logic          out_ready,
  output gfx_pkg::su_t           out_su,

  output logic          busy,
  output logic [gfx_pkg::NUM_CNT-1:0] ev
);
  import gfx_pkg::*;


  typedef enum logic [3:0] {
    S_IDLE, S_AREA, S_EDGE, S_BBOX, S_EINIT, S_NORM, S_DIV, S_OUT
  } sstate_t;
  sstate_t st;

  sv_t va, vb, vc;
  logic [EW-1:0] area;                         // > 0 after S_AREA
  logic [1:0]    ei;
  logic signed [25:0] ra [0:2];
  logic signed [25:0] rb [0:2];
  logic signed [EW-1:0] rc [0:2];
  logic signed [EW-1:0] re [0:2];
  logic [2:0]    bias_r;
  logic [10:0]   bx0, bx1, by0, by1;
  logic [16:0]   rcp_r;
  logic [4:0]    rk_r;
  logic signed [6:0] rsh_r;

  // ----------------------------------------------------------------- area
  logic signed [EW-1:0] dx1, dy1, dx2, dy2, area2;
  always_comb begin
    dx1 = EW'(vb.sx) - EW'(va.sx);
    dy1 = EW'(vb.sy) - EW'(va.sy);
    dx2 = EW'(vc.sx) - EW'(va.sx);
    dy2 = EW'(vc.sy) - EW'(va.sy);
    area2 = dx1 * dy2 - dx2 * dy1;
  end

  // ----------------------------------------------------------------- edge select
  sv_t ep, eq;
  logic signed [25:0] ea, eb;
  logic signed [EW-1:0] ec;
  always_comb begin
    case (ei)
      2'd0:    begin ep = vb; eq = vc; end
      2'd1:    begin ep = vc; eq = va; end
      default: begin ep = va; eq = vb; end
    endcase
    ea = -(26'(eq.sy) - 26'(ep.sy));
    eb =   26'(eq.sx) - 26'(ep.sx);
    ec = -(EW'(ea) * EW'(ep.sx) + EW'(eb) * EW'(ep.sy));
  end

  // ----------------------------------------------------------------- bbox
  logic signed [WIN_BITS-1:0] minx, maxx, miny, maxy;
  logic signed [WIN_BITS-1:0] fx0, fx1, fy0, fy1;
  logic signed [WIN_BITS-1:0] cx0, cx1, cy0, cy1;
  always_comb begin
    minx = va.sx; if (vb.sx < minx) minx = vb.sx; if (vc.sx < minx) minx = vc.sx;
    maxx = va.sx; if (vb.sx > maxx) maxx = vb.sx; if (vc.sx > maxx) maxx = vc.sx;
    miny = va.sy; if (vb.sy < miny) miny = vb.sy; if (vc.sy < miny) miny = vc.sy;
    maxy = va.sy; if (vb.sy > maxy) maxy = vb.sy; if (vc.sy > maxy) maxy = vc.sy;
    fx0 = minx >>> SUBPIX;  fx1 = maxx >>> SUBPIX;
    fy0 = miny >>> SUBPIX;  fy1 = maxy >>> SUBPIX;
    cx0 = (fx0 < 0) ? '0 : fx0;
    cy0 = (fy0 < 0) ? '0 : fy0;
    cx1 = (fx1 > WIN_BITS'(FB_W - 1)) ? WIN_BITS'(FB_W - 1) : fx1;
    cy1 = (fy1 > WIN_BITS'(FB_H - 1)) ? WIN_BITS'(FB_H - 1) : fy1;
  end

  // ----------------------------------------------------------------- first sample
  logic signed [EW-1:0] spx, spy, einit;
  assign spx = EW'({1'b0, bx0, 1'b1, 7'b0} );  // x0*256 + 128  (bx0 << 8 | 0x80)
  assign spy = EW'({1'b0, by0, 1'b1, 7'b0} );
  always_comb begin
    einit = EW'(ra[ei]) * spx + EW'(rb[ei]) * spy + rc[ei];
  end

  // ----------------------------------------------------------------- normalise
  logic [5:0]  nbits;
  logic [15:0] mant;
  logic [5:0]  kk;
  assign nbits = 6'(bitlen64(64'(area)));
  always_comb begin
    if (nbits >= 6'd16) mant = 16'((area >> (nbits - 6'd16)));
    else                mant = 16'((area << (6'd16 - nbits)));
    kk = (nbits > 6'd24) ? (nbits - 6'd24) : 6'd0;
  end

  logic          div_start, div_busy, div_done;
  logic [32:0]   div_q;
  gfx_div #(.NW(33), .DW(17)) u_div (
    .clk(clk), .rst_n(rst_n), .start(div_start),
    .n(33'h1_0000_0000), .d({1'b0, mant} + 17'd1),
    .busy(div_busy), .done(div_done), .q(div_q)
  );
  assign div_start = (st == S_NORM);

  // ----------------------------------------------------------------- outputs
  assign in_ready  = (st == S_IDLE);
  assign out_valid = (st == S_OUT);
  assign busy      = (st != S_IDLE);

  always_comb begin
    out_su.v0 = va; out_su.v1 = vb; out_su.v2 = vc;
    out_su.a0 = ra[0]; out_su.a1 = ra[1]; out_su.a2 = ra[2];
    out_su.b0 = rb[0]; out_su.b1 = rb[1]; out_su.b2 = rb[2];
    out_su.e0 = re[0]; out_su.e1 = re[1]; out_su.e2 = re[2];
    out_su.bias = bias_r;
    out_su.x0 = bx0; out_su.x1 = bx1; out_su.y0 = by0; out_su.y1 = by1;
    out_su.rcp = rcp_r; out_su.rk = rk_r; out_su.rsh = rsh_r;
  end

  // ----------------------------------------------------------------- FSM
  logic is_front;
  assign is_front = front_ccw ? !(area2 > 0) : (area2 > 0);   // y-down: area2>0 <=> clockwise
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; va <= '0; vb <= '0; vc <= '0; area <= '0; ei <= '0;
      bias_r <= '0; bx0 <= '0; bx1 <= '0; by0 <= '0; by1 <= '0;
      rcp_r <= '0; rk_r <= '0; rsh_r <= '0; ev <= '0;
      for (int q = 0; q < 3; q++) begin ra[q] <= '0; rb[q] <= '0; rc[q] <= '0; re[q] <= '0; end
    end else begin
      ev <= '0;
      case (st)
        S_IDLE: if (in_valid) begin
          va <= in_v0; vb <= in_v1; vc <= in_v2;
          st <= S_AREA;
        end

        S_AREA: begin
          if (area2 == '0) begin
            ev[CN_TRIS_DEGEN] <= 1'b1;
`ifdef GFX_TRACE
            $display("SU degen");
`endif
            st <= S_IDLE;
          end else begin
            if ((cull == 2'd1 && !is_front) || (cull == 2'd2 && is_front) || cull == 2'd3) begin
              ev[CN_TRIS_CULLED] <= 1'b1;
`ifdef GFX_TRACE
              $display("SU culled");
`endif
              st <= S_IDLE;
            end else begin
              if (area2 < 0) begin
                vb <= vc; vc <= vb;
                area <= EW'(-area2);
              end else begin
                area <= EW'(area2);
              end
              ei <= 2'd0;
              st <= S_EDGE;
            end
          end
        end

        S_EDGE: begin
          ra[ei] <= ea; rb[ei] <= eb; rc[ei] <= ec;
          bias_r[ei] <= !((ea > 26'sd0) || (ea == 26'sd0 && eb > 26'sd0));
          if (ei == 2'd2) st <= S_BBOX; else ei <= ei + 2'd1;
        end

        S_BBOX: begin
          if (cx0 > cx1 || cy0 > cy1) begin
            ev[CN_TRIS_OFFSCR] <= 1'b1;
`ifdef GFX_TRACE
            $display("SU offscreen");
`endif
            st <= S_IDLE;
          end else begin
            bx0 <= 11'(cx0); bx1 <= 11'(cx1); by0 <= 11'(cy0); by1 <= 11'(cy1);
            ei <= 2'd0;
            st <= S_EINIT;
          end
        end

        S_EINIT: begin
          re[ei] <= einit;
          if (ei == 2'd2) st <= S_NORM; else ei <= ei + 2'd1;
        end

        S_NORM: begin
          rk_r  <= 5'(kk);
          rsh_r <= 7'($signed({1'b0, nbits}) - 7'sd4 - $signed({1'b0, kk}));
          st    <= S_DIV;
        end

        S_DIV: if (div_done) begin
          rcp_r <= div_q[16:0];
          st    <= S_OUT;
        end

        S_OUT: if (out_ready) begin
`ifdef GFX_TRACE
          $display("SU %0x %0d %0d %0d %0d", area, bx0, bx1, by0, by1);
`endif
          st <= S_IDLE;
        end

        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
