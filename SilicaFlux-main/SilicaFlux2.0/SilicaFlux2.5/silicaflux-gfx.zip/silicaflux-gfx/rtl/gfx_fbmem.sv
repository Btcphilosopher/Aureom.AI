// =============================================================================
// gfx_fbmem -- framebuffer + depth memories
//
// This module is the ONLY boundary between the rendering engine and anything
// that displays or captures pixels:
//
//   engine side (clk)       colour write port into the draw (back) buffer,
//                           depth read/write, host read-back of colour
//   scan-out side (scan_clk) independent read port into the display buffer
//
// The scan-out port has its own clock so a display controller can run from a
// pixel clock without a data-path clock-domain crossing (the memory is a
// true dual-clock block RAM).  Only `scan_buf` (which buffer to show) must be
// synchronised by the display side -- see display/gfx_scanout.sv.
//
// Colour is stored as RGB888 (24 bits); depth as D24.
// =============================================================================
module gfx_fbmem
#(
  parameter int FB_W       = 160,
  parameter int FB_H       = 120,
  parameter bit DOUBLE_BUF = 1'b1
) (
  input  logic                         clk,
  input  logic                         front_sel,     // buffer currently displayed (engine view)

  // draw-target colour write
  input  logic                         c_we,
  input  logic [$clog2(FB_W*FB_H)-1:0] c_waddr,
  input  logic [23:0]                  c_wdata,

  // depth
  input  logic                         z_we,
  input  logic [$clog2(FB_W*FB_H)-1:0] z_waddr,
  input  logic [gfx_pkg::DEPTH_BITS-1:0]        z_wdata,
  input  logic [$clog2(FB_W*FB_H)-1:0] z_raddr,
  output logic [gfx_pkg::DEPTH_BITS-1:0]        z_rdata,

  // host read-back of colour (engine clock); h_front selects front/back
  input  logic [$clog2(FB_W*FB_H)-1:0] h_raddr,
  input  logic                         h_front,
  output logic [23:0]                  h_rdata,

  // scan-out read port (display clock)
  input  logic                         scan_clk,
  input  logic                         scan_buf,      // buffer index to display
  input  logic [$clog2(FB_W*FB_H)-1:0] scan_addr,
  output logic [23:0]                  scan_data
);
  import gfx_pkg::*;

  localparam int N  = FB_W * FB_H;
  localparam int AW = $clog2(N);

  logic back_idx;
  assign back_idx = DOUBLE_BUF ? ~front_sel : 1'b0;

  logic [23:0] cmem0 [0:N-1];
  logic [23:0] cmem1 [0:N-1];
  logic [DEPTH_BITS-1:0] zmem [0:N-1];

`ifndef SYNTHESIS
  initial begin
    for (int i = 0; i < N; i++) begin cmem0[i] = '0; cmem1[i] = '0; zmem[i] = '0; end
    z_rdata = '0; h_rdata = '0; scan_data = '0;
  end
`endif

  // colour write (draw target)
  always_ff @(posedge clk) begin
    if (c_we) begin
      if (back_idx) cmem1[c_waddr] <= c_wdata;
      else          cmem0[c_waddr] <= c_wdata;
    end
  end

  // depth
  always_ff @(posedge clk) begin
    if (z_we) zmem[z_waddr] <= z_wdata;
    z_rdata <= zmem[z_raddr];
  end

  // host read-back
  logic h_buf;
  assign h_buf = DOUBLE_BUF ? (h_front ? front_sel : ~front_sel) : 1'b0;
  always_ff @(posedge clk) begin
    h_rdata <= h_buf ? cmem1[h_raddr] : cmem0[h_raddr];
  end

  // scan-out (own clock)
  logic sc_buf;
  assign sc_buf = DOUBLE_BUF ? scan_buf : 1'b0;
  always_ff @(posedge scan_clk) begin
    scan_data <= sc_buf ? cmem1[scan_addr] : cmem0[scan_addr];
  end
endmodule
