// =============================================================================
// gfx_ram -- simple dual-port synchronous RAM (1 write port, 1 read port)
//
// Behavioural; infers block RAM on FPGAs.  Read data appears one cycle after
// the address (registered output).  Read-during-write to the same address
// returns the OLD data.  The sim-only zero fill makes simulation deterministic
// (FPGA block RAM powers up to zero, matching).
// =============================================================================
module gfx_ram #(
  parameter int DW    = 32,
  parameter int DEPTH = 256
) (
  input  logic                     clk,
  input  logic                     we,
  input  logic [$clog2(DEPTH)-1:0] waddr,
  input  logic [DW-1:0]            wdata,
  input  logic [$clog2(DEPTH)-1:0] raddr,
  output logic [DW-1:0]            rdata
);
  logic [DW-1:0] mem [0:DEPTH-1];

`ifndef SYNTHESIS
  initial begin
    for (int i = 0; i < DEPTH; i++) mem[i] = '0;
    rdata = '0;
  end
`endif

  always_ff @(posedge clk) begin
    if (we) mem[waddr] <= wdata;
    rdata <= mem[raddr];
  end
endmodule
