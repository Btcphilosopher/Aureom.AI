// =============================================================================
// gfx_raster -- rasterisation, depth test, colour/texture, framebuffer write
//
// Walks the triangle's bounding box in row-major order, one sample point per
// pixel (its centre).  Edge functions are stepped incrementally with exact
// integer adds, so coverage is exact; ties are resolved by the top-left bias
// computed in setup.  See docs/GFX_SPEC.md sections 5-9.
//
// Per covered pixel:
//   R_LAM : screen-space barycentric weights  w0,w1 = (e_i >> k)*R >> sh ; w2 = ONE-w0-w1
//   R_Z   : z = (w0*z0 + w1*z1 + w2*z2) >> 20              (D24, truncating)
//   R_CMP : depth compare (depth read was issued when the pixel was selected)
//   -- phase 2 (render-state controlled) --
//   R_RHO/RN/RDIV/MU : perspective-correct weights  mu_i = (l_i*iw_i)/sum(l_j*iw_j)
//                      (a weight TRANSFORM: colour and uv then use mu_i unchanged)
//   R_UV/TEXW        : uv interpolation, wrap/clamp, texel address, texel fetch
//   R_COL            : c = (sum m_i*c_i + 2^27) >> 28 ; texture replace/modulate ;
//                      colour write + depth write
// =============================================================================
module gfx_raster
#(
  parameter int FB_W      = 160,
  parameter int FB_H      = 120,
  parameter int TEX_LOG2W = 6,
  parameter int TEX_LOG2H = 6
) (
  input  logic          clk,
  input  logic          rst_n,

  // render state
  input  logic          depth_en,
  input  logic          depth_wr,
  input  logic [2:0]    depth_func,
  input  logic          tex_en,
  input  logic          persp_en,
  input  logic          clamp_u,
  input  logic          clamp_v,
  input  logic          modulate,

  input  logic          in_valid,
  output logic          in_ready,
  input  gfx_pkg::su_t           in_su,
  output logic          busy,

  // depth buffer (1-cycle read latency)
  output logic [$clog2(FB_W*FB_H)-1:0] z_raddr,
  input  logic [gfx_pkg::DEPTH_BITS-1:0]        z_rdata,
  output logic                         z_we,
  output logic [$clog2(FB_W*FB_H)-1:0] z_waddr,
  output logic [gfx_pkg::DEPTH_BITS-1:0]        z_wdata,
  // colour buffer (draw target)
  output logic                         c_we,
  output logic [$clog2(FB_W*FB_H)-1:0] c_waddr,
  output logic [23:0]                  c_wdata,
  // texture memory (1-cycle read latency)
  output logic [TEX_LOG2W+TEX_LOG2H-1:0] tex_raddr,
  input  logic [23:0]                    tex_rdata,

  output logic [gfx_pkg::NUM_CNT-1:0] ev
);
  import gfx_pkg::*;

  localparam int AW  = $clog2(FB_W * FB_H);
  localparam int TAW = TEX_LOG2W + TEX_LOG2H;

  typedef enum logic [4:0] {
    R_IDLE, R_PIX, R_LAM, R_Z, R_CMP,
    R_RHO, R_RN, R_RDIV, R_MU1, R_MU0,
    R_UV, R_TEXW, R_COL
  } rstate_t;
  rstate_t st;

  su_t su;
  logic signed [EW-1:0] e0, e1, e2;          // edge values at current pixel
  logic signed [EW-1:0] r0, r1, r2;          // edge values at start of current row
  logic [10:0] px, py;
  logic [AW-1:0] addr, addr_row;
  logic [LAM_F:0] l0, l1, l2;                // screen-space weights
  logic [LAM_F:0] m0, m1, m2;                // weights used for attributes (== l unless persp)
  logic [DEPTH_BITS-1:0] zf;                 // interpolated fragment depth
  logic [31:0] cov_c, zf_c, wr_c;            // per-triangle statistics (trace only)

  assign busy     = (st != R_IDLE);
  assign in_ready = (st == R_IDLE);
  assign z_raddr  = addr;

  // ------------------------------------------------------------------ coverage
  logic covered;
  always_comb begin
    covered = (e0 - $signed({{(EW-1){1'b0}}, su.bias[0]}) >= 0) &&
              (e1 - $signed({{(EW-1){1'b0}}, su.bias[1]}) >= 0) &&
              (e2 - $signed({{(EW-1){1'b0}}, su.bias[2]}) >= 0);
  end

  // ------------------------------------------------------------------ screen-space weights
  logic [RECIP_NUM-1:0] n0, n1;
  logic [LAM_F+RECIP_NUM:0] p0, p1;          // 24 x 17-bit product, 45-bit headroom for left shifts
  logic [LAM_F+RECIP_NUM:0] s0, s1;
  logic [LAM_F:0] w0n, w1n, w2n;
  always_comb begin
    n0 = RECIP_NUM'(e0 >>> su.rk);
    n1 = RECIP_NUM'(e1 >>> su.rk);
    p0 = n0 * su.rcp;
    p1 = n1 * su.rcp;
    if (su.rsh >= 7'sd0) begin
      s0 = p0 >> su.rsh;
      s1 = p1 >> su.rsh;
    end else begin
      s0 = p0 << (-su.rsh);
      s1 = p1 << (-su.rsh);
    end
    w0n = s0[LAM_F:0];
    w1n = s1[LAM_F:0];
    w2n = LAM_ONE - w0n - w1n;
  end

  // ------------------------------------------------------------------ depth
  logic [DEPTH_BITS+LAM_F+2:0] zsum;
  assign zsum = l0 * su.v0.sz + l1 * su.v1.sz + l2 * su.v2.sz;

  logic z_pass;
  assign z_pass = depth_en ? depth_pass(depth_func, zf, z_rdata) : 1'b1;

  // ------------------------------------------------------------------ perspective-correct weights
  logic [LAM_F+31:0] rho0, rho1, rho2;       // l_i * iw_i  (21 x 32 -> 53 bits)
  logic [LAM_F+33:0] rhoS;                   // sum (55 bits)
  logic [63:0]       rho_ext;
  logic [5:0]        nS;
  logic [15:0]       mantS;
  logic [5:0]        kS;
  logic [16:0]       rcpS;
  logic signed [6:0] shS;
  logic [5:0]        kS_n;

  always_comb begin
    rho_ext = 64'(rhoS);
    nS = 6'(bitlen64(rho_ext));
    if (nS >= 6'd16) mantS = 16'(rho_ext >> (nS - 6'd16));
    else             mantS = 16'(rho_ext << (6'd16 - nS));
    kS_n = (nS > 6'd24) ? (nS - 6'd24) : 6'd0;
  end

  logic        rdiv_start, rdiv_busy, rdiv_done;
  logic [32:0] rdiv_q;
  gfx_div #(.NW(33), .DW(17)) u_rdiv (
    .clk(clk), .rst_n(rst_n), .start(rdiv_start),
    .n(33'h1_0000_0000), .d({1'b0, mantS} + 17'd1),
    .busy(rdiv_busy), .done(rdiv_done), .q(rdiv_q)
  );
  assign rdiv_start = (st == R_RN) && (rhoS != '0);

  logic [RECIP_NUM-1:0]     mn0, mn1;
  logic [LAM_F+RECIP_NUM:0] mp0, mp1, ms0, ms1;
  logic [LAM_F:0]           mu0, mu1, mu2;
  always_comb begin
    mn0 = RECIP_NUM'(rho0 >> kS);
    mn1 = RECIP_NUM'(rho1 >> kS);
    mp0 = mn0 * rcpS;
    mp1 = mn1 * rcpS;
    if (shS >= 7'sd0) begin
      ms0 = mp0 >> shS;
      ms1 = mp1 >> shS;
    end else begin
      ms0 = mp0 << (-shS);
      ms1 = mp1 << (-shS);
    end
    mu0 = ms0[LAM_F:0];
    mu1 = ms1[LAM_F:0];
    mu2 = LAM_ONE - mu0 - mu1;
  end

  // ------------------------------------------------------------------ uv + texture
  logic signed [LAM_F+34:0] usum, vsum;
  logic signed [31:0]       u_fx, v_fx, tx_s, ty_s;
  logic [TEX_LOG2W-1:0]     tx_w, tx_c;
  logic [TEX_LOG2H-1:0]     ty_w, ty_c;
  logic [TAW-1:0]           taddr_r;

  always_comb begin
    usum = $signed({1'b0, m0}) * su.v0.u + $signed({1'b0, m1}) * su.v1.u + $signed({1'b0, m2}) * su.v2.u;
    vsum = $signed({1'b0, m0}) * su.v0.v + $signed({1'b0, m1}) * su.v1.v + $signed({1'b0, m2}) * su.v2.v;
    u_fx = 32'(usum >>> LAM_F);
    v_fx = 32'(vsum >>> LAM_F);
    tx_s = u_fx >>> (FRAC - TEX_LOG2W);
    ty_s = v_fx >>> (FRAC - TEX_LOG2H);
    tx_w = tx_s[TEX_LOG2W-1:0];
    ty_w = ty_s[TEX_LOG2H-1:0];
    if (tx_s < 32'sd0)                         tx_c = '0;
    else if (tx_s > 32'((1 << TEX_LOG2W) - 1)) tx_c = '1;
    else                                       tx_c = tx_s[TEX_LOG2W-1:0];
    if (ty_s < 32'sd0)                         ty_c = '0;
    else if (ty_s > 32'((1 << TEX_LOG2H) - 1)) ty_c = '1;
    else                                       ty_c = ty_s[TEX_LOG2H-1:0];
  end
  assign tex_raddr = taddr_r;

  // ------------------------------------------------------------------ colour
  logic [LAM_F+16+2:0] rsum, gsum, bsum;
  logic [7:0] cr, cg, cb;          // interpolated vertex colour
  logic [7:0] fr, fg, fb;          // final colour after texturing
  logic [15:0] pr, pg, pb;
  logic [16:0] qr, qg, qb;
  always_comb begin
    rsum = m0 * su.v0.r + m1 * su.v1.r + m2 * su.v2.r + (1 << 27);
    gsum = m0 * su.v0.g + m1 * su.v1.g + m2 * su.v2.g + (1 << 27);
    bsum = m0 * su.v0.b + m1 * su.v1.b + m2 * su.v2.b + (1 << 27);
    cr = rsum[28 +: 8];
    cg = gsum[28 +: 8];
    cb = bsum[28 +: 8];
    // modulate: round(t*c/255) via (x+128 + ((x+128)>>8)) >> 8
    pr = tex_rdata[23:16] * cr;
    pg = tex_rdata[15:8]  * cg;
    pb = tex_rdata[7:0]   * cb;
    qr = 17'(pr) + 17'd128;
    qg = 17'(pg) + 17'd128;
    qb = 17'(pb) + 17'd128;
    if (!tex_en) begin
      fr = cr; fg = cg; fb = cb;
    end else if (modulate) begin
      fr = 8'((qr + (qr >> 8)) >> 8);
      fg = 8'((qg + (qg >> 8)) >> 8);
      fb = 8'((qb + (qb >> 8)) >> 8);
    end else begin
      fr = tex_rdata[23:16]; fg = tex_rdata[15:8]; fb = tex_rdata[7:0];
    end
  end

  // ------------------------------------------------------------------ outputs to memories
  assign c_we    = (st == R_COL);
  assign c_waddr = addr;
  assign c_wdata = {fr, fg, fb};
  assign z_we    = (st == R_COL) && depth_wr;
  assign z_waddr = addr;
  assign z_wdata = zf;

  // ------------------------------------------------------------------ FSM
  logic last_px, last_py;
  assign last_px = (px == su.x1);
  assign last_py = (py == su.y1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= R_IDLE; su <= '0;
      e0 <= '0; e1 <= '0; e2 <= '0; r0 <= '0; r1 <= '0; r2 <= '0;
      px <= '0; py <= '0; addr <= '0; addr_row <= '0;
      l0 <= '0; l1 <= '0; l2 <= '0; m0 <= '0; m1 <= '0; m2 <= '0; zf <= '0;
      rho0 <= '0; rho1 <= '0; rho2 <= '0; rhoS <= '0; rcpS <= '0; shS <= '0; kS <= '0;
      taddr_r <= '0;
      cov_c <= '0; zf_c <= '0; wr_c <= '0;
      ev <= '0;
    end else begin
      ev <= '0;
      case (st)
        R_IDLE: if (in_valid) begin
          su <= in_su;
          e0 <= in_su.e0; e1 <= in_su.e1; e2 <= in_su.e2;
          r0 <= in_su.e0; r1 <= in_su.e1; r2 <= in_su.e2;
          px <= in_su.x0; py <= in_su.y0;
          addr     <= AW'(32'(in_su.y0) * 32'(FB_W) + 32'(in_su.x0));
          addr_row <= AW'(32'(in_su.y0) * 32'(FB_W) + 32'(in_su.x0));
          cov_c <= '0; zf_c <= '0; wr_c <= '0;
          ev[CN_TRIS_RASTER] <= 1'b1;
          st <= R_PIX;
        end

        R_PIX: begin
          if (covered) begin
            ev[CN_FRAG_COV] <= 1'b1;
            cov_c <= cov_c + 32'd1;
            st <= R_LAM;
          end else begin
            adv(1'b0, 1'b0);
          end
        end

        R_LAM: begin
          l0 <= w0n; l1 <= w1n; l2 <= w2n;
          st <= R_Z;
        end

        R_Z: begin
          zf <= zsum[LAM_F +: DEPTH_BITS];
          st <= R_CMP;
        end

        R_CMP: begin
          if (z_pass) begin
            st <= persp_en ? R_RHO : R_MU0;
          end else begin
            ev[CN_FRAG_ZFAIL] <= 1'b1;
            zf_c <= zf_c + 32'd1;
            adv(1'b1, 1'b0);
          end
        end

        // ---- perspective-correct weights
        R_RHO: begin
          rho0 <= l0 * su.v0.iw;
          rho1 <= l1 * su.v1.iw;
          rho2 <= l2 * su.v2.iw;
          rhoS <= l0 * su.v0.iw + l1 * su.v1.iw + l2 * su.v2.iw;
          st <= R_RN;
        end

        R_RN: begin
          kS  <= kS_n;
          shS <= 7'($signed({1'b0, nS}) - 7'sd4 - $signed({1'b0, kS_n}));
          st  <= (rhoS != '0) ? R_RDIV : R_MU0;      // S == 0 cannot occur; fall back to screen weights
        end

        R_RDIV: if (rdiv_done) begin
          rcpS <= rdiv_q[16:0];
          st   <= R_MU1;
        end

        R_MU1: begin
          m0 <= mu0; m1 <= mu1; m2 <= mu2;
          st <= tex_en ? R_UV : R_COL;
        end

        R_MU0: begin
          m0 <= l0; m1 <= l1; m2 <= l2;
          st <= tex_en ? R_UV : R_COL;
        end

        // ---- texture fetch
        R_UV: begin
          taddr_r <= {(clamp_v ? ty_c : ty_w), (clamp_u ? tx_c : tx_w)};
          st <= R_TEXW;
        end

        R_TEXW: st <= R_COL;             // texel appears at tex_rdata in R_COL

        R_COL: begin
          ev[CN_FRAG_WRITTEN] <= 1'b1;
          wr_c <= wr_c + 32'd1;
          adv(1'b0, 1'b1);
        end

        default: st <= R_IDLE;
      endcase
    end
  end

  // advance to the next sample point (or finish the triangle)
  task automatic adv(input logic inc_zf, input logic inc_wr);
    if (last_px) begin
      if (last_py) begin
`ifdef GFX_TRACE
        $display("TD %0d %0d %0d", cov_c, zf_c + 32'(inc_zf), wr_c + 32'(inc_wr));
`endif
        st <= R_IDLE;
      end else begin
        py <= py + 11'd1;
        px <= su.x0;
        e0 <= r0 + (EW'(su.b0) <<< SUBPIX);
        e1 <= r1 + (EW'(su.b1) <<< SUBPIX);
        e2 <= r2 + (EW'(su.b2) <<< SUBPIX);
        r0 <= r0 + (EW'(su.b0) <<< SUBPIX);
        r1 <= r1 + (EW'(su.b1) <<< SUBPIX);
        r2 <= r2 + (EW'(su.b2) <<< SUBPIX);
        addr     <= addr_row + AW'(FB_W);
        addr_row <= addr_row + AW'(FB_W);
        st <= R_PIX;
      end
    end else begin
      px <= px + 11'd1;
      e0 <= e0 + (EW'(su.a0) <<< SUBPIX);
      e1 <= e1 + (EW'(su.a1) <<< SUBPIX);
      e2 <= e2 + (EW'(su.a2) <<< SUBPIX);
      addr <= addr + AW'(1);
      st <= R_PIX;
    end
  endtask
endmodule
