// =============================================================================
// gfx_xform -- vertex input + restricted vertex transformation
//
// For every triangle of a draw call:
//   1. read three 16-bit indices from the index memory,
//   2. read three 8-word vertex records from the vertex memory,
//   3. transform position by the single MVP matrix:  clip = M * (x, y, z, 1)
//      (Q16.16 x Q16.16, 66-bit accumulate, round-half-up, saturate to s32),
//   4. widen the vertex colour to Q8.8 and pass u,v through,
//   5. hand the clip-space triangle downstream (valid/ready).
//
// "Restricted" means: one matrix, no lighting, no programmable shading, one
// multiplier (16 MACs per vertex).  A saturated component marks the whole
// triangle as dropped (counted in tris_xf_ovf); values never wrap.
// =============================================================================
module gfx_xform
#(
  parameter int VB_VERTS = 256,
  parameter int IB_DEPTH = 1024
) (
  input  logic          clk,
  input  logic          rst_n,

  input  logic          start,              // pulse (ignored while busy)
  input  logic [15:0]   first_tri,
  input  logic [15:0]   count_tri,
  output logic          busy,

  input  logic [511:0]  mvp_flat,           // 16 x s32, row-major, element i at [32*i +: 32]

  output logic [$clog2(IB_DEPTH)-1:0]            ib_raddr,
  input  logic [31:0]                            ib_rdata,   // 1-cycle read latency
  output logic [$clog2(VB_VERTS*gfx_pkg::VTX_WORDS)-1:0]  vb_raddr,
  input  logic [31:0]                            vb_rdata,   // 1-cycle read latency

  output logic          out_valid,
  input  logic          out_ready,
  output gfx_pkg::cv_t           out_v0,
  output gfx_pkg::cv_t           out_v1,
  output gfx_pkg::cv_t           out_v2,

  output logic [gfx_pkg::NUM_CNT-1:0] ev             // 1-cycle event pulses
);
  import gfx_pkg::*;


  typedef enum logic [3:0] {
    X_IDLE, X_TRI, X_IDX_REQ, X_IDX_CAP, X_VRD, X_MAC, X_VDONE,
    X_CHECK, X_EMIT, X_NEXT
  } xstate_t;
  xstate_t st;

  logic [16:0]  t_r;           // current triangle number
  logic [16:0]  rem_r;         // triangles still to process
  logic [1:0]   j_r;           // vertex within triangle
  logic [15:0]  idx_r;
  logic [2:0]   rk_r;
  logic [3:0]   mi_r;
  logic [31:0]  words [0:5];
  logic signed [65:0] acc;
  logic signed [31:0] rx [0:3];
  logic         ovf_acc;
  cv_t          vtx [0:2];

  // ---------------------------------------------------------------- addresses
  logic [19:0] tri_base;       // 3 * t
  assign tri_base = {2'b0, t_r, 1'b0} + {3'b0, t_r};
  logic [19:0] ia_full;
  assign ia_full  = tri_base + {18'b0, j_r};
  assign ib_raddr = ia_full[$clog2(IB_DEPTH)-1:0];
  assign vb_raddr = {idx_r[$clog2(VB_VERTS)-1:0], rk_r};

  // ---------------------------------------------------------------- MAC datapath
  logic [1:0]  col, row;
  assign col = mi_r[1:0];
  assign row = mi_r[3:2];

  logic signed [31:0] m_elem, opnd;
  logic signed [63:0] prod;
  logic signed [65:0] acc_n, rnd;
  logic               row_ovf;
  logic signed [31:0] row_sat;

  always_comb begin
    m_elem = $signed(mvp_flat[{mi_r, 5'b0} +: 32]);
    case (col)
      2'd0:    opnd = $signed(words[0]);
      2'd1:    opnd = $signed(words[1]);
      2'd2:    opnd = $signed(words[2]);
      default: opnd = 32'sd65536;                 // homogeneous 1.0 in Q16.16
    endcase
    prod  = m_elem * opnd;
    acc_n = ((col == 2'd0) ? 66'sd0 : acc) + 66'(prod);
    rnd   = (acc_n + 66'sd32768) >>> FRAC;
    row_ovf = (rnd > 66'sd2147483647) || (rnd < -66'sd2147483648);
    if (rnd > 66'sd2147483647)       row_sat = 32'sh7FFFFFFF;
    else if (rnd < -66'sd2147483648) row_sat = 32'sh80000000;
    else                             row_sat = rnd[31:0];
  end

  assign busy      = (st != X_IDLE);
  assign out_valid = (st == X_EMIT);
  assign out_v0    = vtx[0];
  assign out_v1    = vtx[1];
  assign out_v2    = vtx[2];

  // ---------------------------------------------------------------- trace
`ifdef GFX_TRACE
  task automatic pr_cv(input cv_t c);
    $write("%08x,%08x,%08x,%08x,%08x,%08x,%08x,%08x,%08x ",
           c.x, c.y, c.z, c.w, {16'b0, c.r}, {16'b0, c.g}, {16'b0, c.b}, c.u, c.v);
  endtask
`endif

  // ---------------------------------------------------------------- FSM
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st      <= X_IDLE;
      t_r     <= '0;
      rem_r   <= '0;
      j_r     <= '0;
      idx_r   <= '0;
      rk_r    <= '0;
      mi_r    <= '0;
      acc     <= '0;
      ovf_acc <= 1'b0;
      ev      <= '0;
      for (int i = 0; i < 6; i++) words[i] <= '0;
      for (int i = 0; i < 4; i++) rx[i]    <= '0;
      for (int i = 0; i < 3; i++) vtx[i]   <= '0;
    end else begin
      ev <= '0;
      case (st)
        X_IDLE: begin
          if (start && count_tri != 16'd0) begin
            t_r     <= {1'b0, first_tri};
            rem_r   <= {1'b0, count_tri};
            ovf_acc <= 1'b0;
            st      <= X_TRI;
          end
        end

        X_TRI: begin
          ev[CN_TRIS_IN] <= 1'b1;
          if ((tri_base + 20'd2) >= 20'(IB_DEPTH)) begin
            ev[CN_BAD_REF] <= 1'b1;
            st             <= X_NEXT;
          end else begin
            j_r     <= 2'd0;
            ovf_acc <= 1'b0;
            st      <= X_IDX_REQ;
          end
        end

        X_IDX_REQ: st <= X_IDX_CAP;          // address is combinational from t_r/j_r

        X_IDX_CAP: begin
          idx_r <= ib_rdata[15:0];
          if (ib_rdata[15:0] >= 16'(VB_VERTS)) begin
            ev[CN_BAD_REF] <= 1'b1;
            st             <= X_NEXT;
          end else begin
            rk_r <= 3'd0;
            st   <= X_VRD;
          end
        end

        X_VRD: begin                         // issue word rk, capture word rk-1
          if (rk_r != 3'd0) words[rk_r - 3'd1] <= vb_rdata;
          if (rk_r == 3'd6) begin
            mi_r <= 4'd0;
            st   <= X_MAC;
          end else begin
            rk_r <= rk_r + 3'd1;
          end
        end

        X_MAC: begin
          acc <= acc_n;
          if (col == 2'd3) begin
            rx[row] <= row_sat;
            if (row_ovf) ovf_acc <= 1'b1;
          end
          if (mi_r == 4'd15) st <= X_VDONE;
          else               mi_r <= mi_r + 4'd1;
        end

        X_VDONE: begin
          vtx[j_r].x <= rx[0];
          vtx[j_r].y <= rx[1];
          vtx[j_r].z <= rx[2];
          vtx[j_r].w <= rx[3];
          vtx[j_r].r <= {words[3][23:16], 8'h00};
          vtx[j_r].g <= {words[3][15:8],  8'h00};
          vtx[j_r].b <= {words[3][7:0],   8'h00};
          vtx[j_r].u <= $signed(words[4]);
          vtx[j_r].v <= $signed(words[5]);
          if (j_r == 2'd2) begin
            st <= X_CHECK;
          end else begin
            j_r <= j_r + 2'd1;
            st  <= X_IDX_REQ;
          end
        end

        X_CHECK: begin
`ifdef GFX_TRACE
          $write("XF ");
          pr_cv(vtx[0]); pr_cv(vtx[1]); pr_cv(vtx[2]);
          if (ovf_acc) $write("OVF");
          $write("\n");
`endif
          if (ovf_acc) begin
            ev[CN_TRIS_XF_OVF] <= 1'b1;
            st                 <= X_NEXT;
          end else begin
            st <= X_EMIT;
          end
        end

        X_EMIT: if (out_ready) st <= X_NEXT;

        X_NEXT: begin
          t_r   <= t_r + 17'd1;
          rem_r <= rem_r - 17'd1;
          if (rem_r == 17'd1) st <= X_IDLE;
          else                st <= X_TRI;
        end

        default: st <= X_IDLE;
      endcase
    end
  end
endmodule
