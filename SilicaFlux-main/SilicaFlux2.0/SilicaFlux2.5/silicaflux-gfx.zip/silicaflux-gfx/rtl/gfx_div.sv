// =============================================================================
// gfx_div -- unsigned restoring divider, one quotient bit per clock
//
//   q = floor(n / d)      NW clocks after `start`, `done` pulses for one cycle
//
// Divide-by-zero is defined (q = 0) so that a bad operand can never hang the
// pipeline; callers guarantee d != 0 on every legal path (see docs/GFX_SPEC.md,
// "Overflow and degenerate-input policy").
// =============================================================================
module gfx_div #(
  parameter int NW = 64,           // dividend / quotient width
  parameter int DW = 40            // divisor width
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          start,     // pulse; ignored while busy
  input  logic [NW-1:0] n,
  input  logic [DW-1:0] d,
  output logic          busy,
  output logic          done,      // 1-cycle pulse, q valid in this cycle
  output logic [NW-1:0] q
);
  localparam int CW = $clog2(NW + 1);

  logic [NW-1:0] n_r;
  logic [DW-1:0] d_r;
  logic [DW-1:0] rem;
  logic [CW-1:0] cnt;
  logic [DW:0]   trial;

  assign trial = {rem, n_r[NW-1]};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      n_r  <= '0;
      d_r  <= '0;
      rem  <= '0;
      q    <= '0;
      cnt  <= '0;
      busy <= 1'b0;
      done <= 1'b0;
    end else begin
      done <= 1'b0;
      if (!busy) begin
        if (start) begin
          n_r  <= n;
          d_r  <= d;
          rem  <= '0;
          q    <= '0;
          cnt  <= CW'(NW);
          busy <= 1'b1;
          if (d == '0) begin           // defined result, finish next cycle
            busy <= 1'b0;
            done <= 1'b1;
          end
        end
      end else begin
        if (trial >= {1'b0, d_r}) begin
          rem <= DW'(trial - {1'b0, d_r});
          q   <= {q[NW-2:0], 1'b1};
        end else begin
          rem <= trial[DW-1:0];
          q   <= {q[NW-2:0], 1'b0};
        end
        n_r <= {n_r[NW-2:0], 1'b0};
        cnt <= cnt - 1'b1;
        if (cnt == CW'(1)) begin
          busy <= 1'b0;
          done <= 1'b1;
        end
      end
    end
  end
endmodule
