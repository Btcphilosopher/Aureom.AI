# third_party/silicaflux-base

An **unmodified** copy of the SilicaFlux v1.0 baseline (`rtl/`, `tb/`, `sim/`, `docs/`, `README.md`), taken from this
repository's `SilicaFlux-main.zip` → `silicaflux.zip`. It is here only so that

* `integration/apply_patches.py` can derive the graphics-enabled RTL (`build/sfx_gfx/`) and review diffs against it, and
* `run_all.sh` can run the baseline's own testbenches (`sim/run_sim.sh`) against the *patched* RTL.

Nothing in this directory was edited. Synthesis scripts were not copied. The baseline's own licence/terms, if any,
apply to these files; none was stated in the bundle.
