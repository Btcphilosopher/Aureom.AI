#!/usr/bin/env bash
# Partial open-source synthesis evidence (see docs/SYNTHESIS_STATUS.md).  Reads rtl/, writes build/synth/.
# Whole-design synthesis is not possible with Yosys 0.33 (front-end gaps), so blocks are run separately
# on a mechanically rewritten copy (scoped package names).  The shipped RTL is never modified.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=build/synth; Y=$OUT/rtl_y
mkdir -p "$OUT"
python3 tools/make_yosys_variant.py "$Y" >/dev/null
RD="read_verilog -sv -DSYNTHESIS $Y/gfx_pkg.sv $Y/gfx_div.sv $Y/gfx_ram.sv $Y/gfx_fbmem.sv $Y/gfx_setup.sv $Y/gfx_raster.sv"

echo "== gfx_div : fully technology-mapped (Yosys generic gates)"
yosys -q -l $OUT/div.log -p "$RD; hierarchy -top gfx_div; proc; opt -fast; synth -top gfx_div -flatten; stat" >/dev/null 2>&1
grep -E "Number of cells|\\\$_DFFE_PN0P_|\\\$_MUX_" $OUT/div.log | sort -u | tail -4

echo "== gfx_fbmem 160x120 : memory inference only (no flip-flop mapping)"
yosys -q -l $OUT/fb.log -p "read_verilog -sv -DSYNTHESIS $Y/gfx_pkg.sv $Y/gfx_fbmem.sv; hierarchy -top gfx_fbmem -chparam FB_W 160 -chparam FB_H 120; proc; opt -fast; memory -nomap; stat" >/dev/null 2>&1
grep -E "mem_v2|Number of cells" $OUT/fb.log | tail -2

for m in gfx_setup gfx_raster; do
  echo "== $m : word-level operator census (coarse-grain, before mapping)"
  yosys -q -l $OUT/$m.log -p "$RD; hierarchy -top $m; synth -top $m -flatten -run :fine; opt -fast; stat" >/dev/null 2>&1
  grep -E '^ +\$macc +[0-9]+|Number of cells' $OUT/$m.log | sort -u | tail -3
done
