# Integration with the SilicaFlux compute architecture

## Which SilicaFlux, and what "retain the documented interfaces" meant here

The repository contains several SilicaFlux bundles. This extension targets the
**SilicaFlux v1.0 cluster** (`SilicaFlux-main.zip → silicaflux.zip`: 32-bit ISA,
dataflow scheduler, compute tiles, 2×2 NoC). Its README documents exactly one
extension mechanism, which is what this work uses:

> *"Custom Dataflow Kernels — Reserve opcodes `0x18`–`0x1E` … Wire them through
> the scheduler's opcode dispatch and add the corresponding functional unit to
> `compute_tile`."*

The sibling `silicafluxai` bundle (INT8 systolic GEMM) and the physical-design
bundle were reviewed but are unrelated to this extension; the engine's internal
handshakes follow the same valid/ready discipline (`sfx_stream_if.sv`) but none
of its modules are used.

### Interfaces retained (and how that is checked)

| Documented interface | Status | Evidence |
|---|---|---|
| `compute_tile` port list (26 ports: token fields, scalar/vector feeds, result, NoC send/receive) | **identical** in name, direction, type, width | `tools/check_tile_ports.py` |
| Scheduler work-token protocol (`token_valid` / registered `token_ready`, one-cycle `tile_done`, `tile_busy` scoreboard, `DFSYNC` barrier) | unchanged; `gfx_tile` obeys it | `integration/tb/tb_gfx_tile.sv` (28 checks), system tests |
| D-format encoding `[31:27]op [26:24]tile [23:19]reg [18:14]len [13:0]addr` | unchanged; GFX opcodes use it | assembler + decoder `get_format` |
| Opcode map `0x00–0x17`, `0x1F` | unchanged; GFX uses `0x18–0x1C` of the reserved `0x18–0x1E` | `integration/patches/rtl_silicaflux_pkg.sv.diff` |
| `silicaflux_top` port list | **untouched** — a new top `silicaflux_gfx_top` is generated beside it | `integration/patches/rtl_silicaflux_top.sv.diff` |
| NoC / tile-interface | ports present; the graphics tile consumes and ignores NoC flits and never sends | `tb_gfx_tile` |
| Baseline regression (7 testbenches) | **still passes** on the patched RTL (Icarus, the baseline's own runner) | `run_all.sh` step 1 |

## The graphics instructions

All are D-format, executed by `gfx_tile` (tile 3 in `silicaflux_gfx_top`; selectable by `GFX_TILE_ID`).
`tok_length` carries the address *space*, `tok_mem_addr` the 14-bit address and
`scalar_data_in` the register operand — exactly the fields the scheduler already routes.

| Mnemonic | Encoding fields | Effect |
|---|---|---|
| `GFXWR tile, rS, space, addr` | op `0x18` | write `rS` to `space[addr]` (registers, vertex/index/texture memory, colour/depth buffers) |
| `GFXRD tile, rS, space, addr` | op `0x19` | read `space[rS + addr]` → `tile_result_scalar` |
| `GFXCLR tile` | op `0x1A` | clear colour (`CFG_CLR_COLOR`) and depth (`CFG_CLR_DEPTH`) of the draw buffer |
| `GFXDRAW tile, rC, 0, first` | op `0x1B` | draw triangles `first … first + rC[15:0] − 1` |
| `GFXPRES tile` | op `0x1C` | swap front/back colour buffers |

An opcode this tile does not implement completes with `tile_error = 1`, except
`DFSYNC`, which completes cleanly (a no-op for this tile).

Example (`integration/programs/draw_triangle.sfx`, passes `tools/check_raw_hazards.py`):

```asm
        NOP                       ; word 0: host patches this in to release the boot spin
        NOP ... NOP               ; words 1-6: branch-shadow padding (see "Baseline defects")
        MOV     r1, 7             ; depth test | depth write | LESS
        NOP                       ; RAW spacing
        GFXWR   3, r1, 0, 2       ; CFG.RS
        GFXCLR  3
        MOV     r3, 1
        NOP
        GFXDRAW 3, r3, 0, 0
        GFXPRES 3
        DFSYNC
        HALT
```

### Why there is a sideband port

The scalar ISA can only build 17-bit immediates (`MOV`), and the cluster has no
bulk data-load path (the scratchpad cannot be preloaded from outside). A 32-bit
matrix, vertex or texel therefore cannot come from a SilicaFlux program. `gfx_tile`
adds a **host load port** (`gfx_ld_*`, same command format as the engine's port)
for assets, and a **scan port** (`scan_*`) for display/capture. Token traffic has
priority; the host port stalls while a token is in flight and blocks the
scheduler (`token_ready` low) while the host owns the engine. These are *extra*
ports on `gfx_tile`/`silicaflux_gfx_top`; no baseline port changed.

The system test boots exactly as a bring-up would: the program loads with `imem[0]`
holding a self-jump; the host DMAs assets; the host then patches `imem[0]`
to release the CPU.

## Changes to the vendored baseline

`third_party/silicaflux-base/` is an **unmodified** copy of the baseline v1.0 RTL.
`integration/apply_patches.py` derives the graphics-enabled tree into `build/sfx_gfx/`
(each edit asserts its anchor matches exactly once) and writes reviewable diffs to
`integration/patches/`:

| File | Change | Size |
|---|---|---|
| `silicaflux_pkg.sv` | 5 opcode constants; `get_format` classifies them as D-format | +10 / −1 |
| `control_core.sv` | route the 5 opcodes to the scheduler (`is_sched_op`) | +4 / −1 |
| `sfx_asm.py` | 5 mnemonics | +7 / −1 |
| `scheduler.sv` | **bug fix** for tile operations only (`DFSYNC` rule untouched), see D1 below | +9 / −1 |
| `silicaflux_gfx_top.sv` | new file derived from `silicaflux_top.sv`: graphics tile in slot `GFX_TILE_ID`, sideband ports | +61 / −5 vs the original |

## Baseline defects found while integrating

Found by self-checking tests and a pipeline trace, not by reading alone (except D5).
They matter because the baseline's own top-level test prints `[INFO] … observe waveforms`
and does not check results, so none of this was visible from it.

* **D1 — scheduler loses a token when its tile frees up (FIXED, narrowly).**
  `instr_ready` releases an instruction when `tile_tok_ready || !tile_busy`, but
  dispatch requires `!tile_busy && tile_tok_ready`. In the cycle a finishing tile
  re-asserts `token_ready` while its scoreboard bit is still set, a waiting
  instruction is consumed **without being dispatched**. Reproduced: with the
  unmodified scheduler the triangle program delivers only 3 of its 5 tokens to
  the tile (the clear-colour write and the draw vanish); with the fix all 5 arrive
  in order. The fix makes `instr_ready = dispatch_ok` for **tile operations only**:
  `DFSYNC` is a scheduler-level barrier that needs no tile, so the baseline's looser
  acceptance rule is correct for it and is kept bit-for-bit. (My first version of the fix applied
  to every opcode and **broke the baseline's own `tb_scheduler` DFSYNC test**; that failure, caught by the
  regression step, is why the fix is scoped as above.) Test:
  `sim/test_system.py::test_baseline_scheduler_without_fix_loses_tokens`
  (fails if the fix ever becomes unnecessary). The baseline's 7 testbenches pass on the patched RTL.
* **D2 — read-after-write hazard at distance 1 (NOT fixed; software rule).**
  The forwarding unit compares against `ex_mem`, one stage too late for an
  instruction directly behind its producer, so `MOV r1,7` immediately followed by
  `GFXWR … r1` delivers the stale value 0. Rule: leave ≥ 1 unrelated instruction
  between a producer and its consumer. `tools/check_raw_hazards.py` lints the
  shipped programs.
* **D3 — wrong-path instructions execute after a taken branch (NOT fixed; software rule).**
  The instruction at PC+1 and a stale one in the SRAM output stage (here PC+5)
  still execute after a taken branch/jump. Rule: pad the 6 slots after a branch
  with `NOP`. The boot spin uses it; the lint checks it.
* **D4 — `halt` is raised at *fetch*** (several instructions before `HALT`
  executes), so it cannot be used as "program finished". The system testbench waits
  for `HALT` to reach the execute stage, which can only happen after `DFSYNC`
  has drained every tile.
* **D5 — (by inspection only) scheduler write-back always targets `r0`**
  (`wb_reg <= '0`), so scalar tile results never reach the register file;
  `GFXRD` results are observable on `tile_result_scalar`/`tile_done` (verified at
  tile level) but a program cannot consume them.

## Running it

```bash
./run_all.sh                       # everything below, with a summary
python3 integration/apply_patches.py          # regenerate build/sfx_gfx + patches/*.diff
python3 -m pytest sim/test_system.py sim/test_tile.py
python3 tools/check_tile_ports.py
python3 tools/check_raw_hazards.py integration/programs/*.sfx
```

Debug aids (not needed for normal runs): build the system testbench with
`GFX_SYS_DEFS="-DGFX_TOKEN_TRACE -DTB_TRACE_PIPE"` (and `-DTB_TRACE_FETCH`) to print every token the tile accepts and the
control-core / scheduler hand-off per cycle — this is how defects D1–D3 were diagnosed.

Tool note: the integrated system is simulated with **Verilator**. The engine does
not compile under Icarus Verilog 12 (its array-of-struct and constant-select
limitations); Icarus is therefore used only for the *baseline* regression.
