# SilicaFlux-GFX — Architecture & Numeric Specification

Status: **v1.0 of the graphics extension**. This document is normative for
`rtl/` and `model/gfxref.py`: where they differ, that is a bug. The two are
compared bit-for-bit by the test suite (see `VERIFICATION.md`), and the shared
constants are checked mechanically by `tools/check_consts.py`.

> **What this is not.** This is a small fixed-function triangle renderer. It is
> **not** an OpenGL or Vulkan implementation, it is not conformant to any
> graphics API, and nothing here should be described as one. API integration
> (a driver / command translation layer) is a separate future project. Where
> this document borrows a convention from an API (e.g. a `[0, w]` depth range)
> it is only because that convention is convenient for fixed-point hardware.

Contents: 1 Scope · 2 Conventions · 3 Number formats · 4 Pipeline · 5 Vertex
input · 6 Transform · 7 Clipping · 8 Projection · 9 Setup & fill rule · 10
Rasterisation & weights · 11 Depth · 12 Colour & framebuffer · 13 Texturing ·
14 Overflow policy · 15 Command interface · 16 Limits.

---

## 1. Scope

| Stage | Implemented | Module |
|---|---|---|
| Vertex input (indexed triangle list) | yes | `gfx_xform` |
| Restricted vertex transform (one 4×4 matrix) | yes | `gfx_xform` |
| Clipping (homogeneous, 6 planes) | yes | `gfx_geom` |
| Perspective divide + viewport | yes | `gfx_geom` |
| Triangle setup, culling | yes | `gfx_setup` |
| Rasterisation (top-left rule) | yes | `gfx_raster` |
| Depth test (8 functions) | yes | `gfx_raster` |
| Colour interpolation (Gouraud) | yes | `gfx_raster` |
| Framebuffer write, double buffering | yes | `gfx_fbmem` |
| Texture sampling (nearest, wrap/clamp, modulate) | yes — added after the untextured path was verified | `gfx_raster` |
| Perspective-correct interpolation | yes (render-state bit) | `gfx_raster` |

Not implemented (deliberately): lighting, programmable shading, alpha blending,
stencil, scissor registers (the scissor *is* the framebuffer), mip-mapping,
bilinear filtering, points, lines, MSAA, a triangle FIFO between stages, any API.

## 2. Conventions

**Spaces.** Object-space vertices are multiplied by one 4×4 matrix `M`
(supplied by the host; usually projection × view × model) to give **clip space**.

* Clip space is right-handed. `x` right, `y` up, `z` into the screen.
* The view volume is `-w ≤ x ≤ w`, `-w ≤ y ≤ w`, **`0 ≤ z ≤ w`** (zero-to-one depth).
* Matrix convention: `clip = M · (x, y, z, 1)ᵀ`, `M` row-major in registers
  `CFG_MVP+0 … +15` (`M[r][c]` at `CFG_MVP + 4r + c`). The input `w` is implicitly `1.0`.
* NDC = clip / w.

**Window space** (what the rasteriser sees):

* Origin at the **top-left corner of the framebuffer**, `+x` right, **`+y` down**.
* Pixel `(i, j)` covers `[i, i+1) × [j, j+1)`; its **sample point is its centre**
  `(i + ½, j + ½)`.
* Coordinates are integers in units of **1/256 pixel** ("sub-pixel units").
* Viewport transform (fixed, full framebuffer, `W×H` pixels):
  `x_win = (x_ndc + 1)·W/2`, `y_win = (1 − y_ndc)·H/2`, `z_win = z_ndc` mapped to D24 (§11).

**Facing.** With window `y` down, `area2 = (xb−xa)(yc−ya) − (xc−xa)(yb−ya)` is **positive
for a triangle that is clockwise on screen**. Render-state bit `front_ccw`
selects which is "front": `front_ccw = 0` (reset default) → clockwise-on-screen
is front; `front_ccw = 1` → counter-clockwise-on-screen is front. Cull mode
`0` none, `1` cull back, `2` cull front, `3` cull everything.

## 3. Number formats

| Quantity | Format | Notes |
|---|---|---|
| Object / clip coords, matrix | signed **Q16.16**, 32 bit | range ±32768, step 2⁻¹⁶ |
| Vertex colour in | `0x00RRGGBB`, 8 bit/channel | |
| Colour in the pipeline | unsigned **Q8.8**, 16 bit/channel | widened so clip interpolation keeps precision |
| Texture coordinates `u,v` | signed **Q16.16** | normalised: 1.0 = one repeat of the texture |
| Clip-distance values | signed 36 bit | cannot overflow for s32 inputs (§14) |
| Clip intersection parameter `t` | unsigned Q0.24 | `t < 1` |
| Window `x,y` | signed 24 bit, units of **1/256 px** | `SUBPIX = 8`; saturates at ±2²³ |
| Window depth | unsigned 24 bit **D24 UNORM** | `0 … 0xFFFFFF` |
| `1/w` | unsigned **Q8.24**, 32 bit | `min(2³²−1, ⌊2⁴⁰ / w_raw⌋)` |
| Edge functions | signed 56 bit (`EW`) | magnitude bounded by 2⁵⁰ (§14) |
| Barycentric / attribute weights | unsigned **Q0.20**, `ONE = 2²⁰` | always sum to exactly `ONE` |
| Reciprocal mantissa | 16 bit (`RECIP_MANT`) | numerator truncated to 24 bit (`RECIP_NUM`) |
| Counters | 32 bit, **saturating** | never wrap |
| Framebuffer pixel | RGB888 (24 bit) | stored as `{R,G,B}`; reads return `{8'h00,R,G,B}` |

All rounding rules are stated per stage below; there is no hidden rounding.

## 4. Pipeline

```
 index mem ─┐                                        ┌── texture mem
 vertex mem ┴─▶ XFORM ─▶ GEOM ─────────▶ SETUP ─▶ RASTER ─▶ FBMEM ─▶ scan port ─▶ (display side)
              fetch+    clip(6 planes)    area,cull  coverage  colour/depth  dual-clock
              4×4 MAC   divide+viewport   edges,bbox weights   (2 colour +   read port
              (1 mult)  fan-triangulate   1/area    depth,tex   1 depth)
```

Stages communicate with `valid/ready` handshakes and each holds one item, so
stages overlap on consecutive triangles. There is no triangle FIFO. Typical cost
(simulated): ~100 cycles/triangle fetch+transform, ~800 cycles/triangle
divide+project (4 divisions × 3 vertices × 64 cycles), 1 cycle per bounding-box
pixel outside the triangle, 6 cycles per untextured covered pixel, ≈ 45 per
perspective-textured pixel (one 33-cycle division). Measured per-frame cycle
counts are in `demo/out/results.json`; **no clock frequency or frame rate is
claimed** — no timing closure was attempted (`SYNTHESIS_STATUS.md`).

## 5. Vertex input

A vertex record is 8 consecutive 32-bit words in the vertex memory
(`VB_VERTS` records, default 256):

| Word | Content |
|---|---|
| 0, 1, 2 | `x, y, z` — signed Q16.16 |
| 3 | colour `0x00RRGGBB` |
| 4, 5 | `u, v` — signed Q16.16 |
| 6, 7 | reserved (ignored) |

The index memory holds one **16-bit index per 32-bit word** (`IB_DEPTH`, default
1024); triangle `t` uses words `3t, 3t+1, 3t+2`. `DRAW(first, count)` processes
triangles `first … first+count−1` (16-bit fields). A triangle whose index-memory
words lie past `IB_DEPTH`, or that references a vertex ≥ `VB_VERTS`, is
skipped and counted in `bad_ref`. There is no vertex cache: a shared vertex is
fetched and transformed once per use.

## 6. Transform (restricted)

For each of the four output components `i`:

```
acc_i = M[i][0]·x + M[i][1]·y + M[i][2]·z + (M[i][3] << 16)          (66-bit signed accumulator)
out_i = (acc_i + 0x8000) >>> 16                                        (round half up; arithmetic shift)
```

`out_i` is saturated to signed 32 bit. If **any** component of **any** of the
triangle's three vertices saturates, the whole triangle is **dropped** and
counted in `tris_xf_ovf`; saturated values are never rasterised and nothing wraps.
Colour is widened `c8 → c8 << 8` (Q8.8); `u, v` pass through unchanged.
One multiplier, 16 cycles per vertex.

## 7. Clipping

Clipping is Sutherland–Hodgman in homogeneous clip space against six planes,
applied in this order. A vertex is **inside a plane iff its distance is ≥ 0**
(boundaries are inclusive):

| # | Plane | Distance |
|---|---|---|
| 0 | near | `z` |
| 1 | far | `w − z` |
| 2 | left | `x + GB·w` |
| 3 | right | `GB·w − x` |
| 4 | bottom | `y + GB·w` |
| 5 | top | `GB·w − y` |

`GB = 4` is a **guard band**: x/y are clipped at four times the visible range
rather than at ±w, so ordinary triangles that merely overhang the screen are
**not** clipped (the rasteriser's bounding box is clamped to the framebuffer
instead) while triangles with enormous or negative-`w` extent still get bounded
coordinates. Consequence: the window-coordinate range after clipping is bounded
by `±(GB+1)·W·128` sub-pixel units, far inside the 24-bit window range.

Per plane: if all vertices are inside → skip the plane (polygon unchanged); if
all are outside → the triangle is **rejected** (`tris_clip_rej`); otherwise the
polygon is clipped. A triangle that was clipped by at least one plane and
survives is counted in `tris_clipped`.

**Intersections** are always computed from the **inside vertex towards the outside
vertex**, independent of traversal direction:

```
t = ⌊ d_in · 2²⁴ / (d_in − d_out) ⌋          (0 ≤ t < 2²⁴)
v = v_in + ⌊ (v_out − v_in) · t / 2²⁴ ⌋       (arithmetic shift, every attribute, incl. colour/uv)
```

Because the direction is canonical, two triangles sharing an edge that crosses a
plane produce **bit-identical** intersection vertices — no cracks (tested).

A vertex lying exactly on a plane is inside; an edge from such a vertex to an
outside vertex yields a duplicate of the vertex (a zero-length polygon edge),
which later appears as a degenerate (zero-area) fan triangle and is dropped in
setup. This is intentional and tested.

**Capacity.** The polygon buffer holds 9 vertices (3 + one per plane would be 9).
If rounding noise ever produced more, or fewer than 3, the triangle is rejected
(`tris_clip_rej`) rather than overflowing. After clipping, any vertex with
`w ≤ 0` rejects the polygon (`clip_bad_w`); with the six planes applied this can
only be a degenerate point at the clip-space origin.

The clipped polygon (≤ 9 vertices) is projected once per vertex (§8) and
**fan-triangulated** `(v0, vk, vk+1)`; winding is preserved, so culling stays
consistent.

## 8. Projection and viewport

With `w > 0` (raw Q16.16 integers `x, y, z, w`; ÷ is floor division, all
operands non-negative):

```
sx = ⌊ (max(0, x + GB·w) · (W·256) + w) / (2w) ⌋ − (GB−1)·W·128        = round_half_up((x/w + 1)·W/2·256)
sy = ⌊ (max(0, GB·w − y) · (H·256) + w) / (2w) ⌋ − (GB−1)·H·128        = round_half_up((1 − y/w)·H/2·256)
sz = ⌊ (clamp(z, 0, w) · (2²⁴−1) · 2 + w) / (2w) ⌋                      = round_half_up(z/w · (2²⁴−1))
iw = min(2³²−1, ⌊ 2⁴⁰ / w ⌋)
```

`sx, sy` saturate to signed 24 bit (counted in `win_sat`; unreachable for
clipped geometry). One restoring divider, 64 cycles per division.
`iw` saturates (silently) for `w_raw ≤ 256`, i.e. `w ≤ 2⁻⁸`.

## 9. Triangle setup and the fill rule

Window vertices `a, b, c`; `area2 = (b.x−a.x)(c.y−a.y) − (c.x−a.x)(b.y−a.y)`.

1. `area2 = 0` → dropped, `tris_degen`.
2. Facing (§2) and cull mode → dropped, `tris_culled`.
3. If `area2 < 0` the order of `b, c` is swapped and `area2` negated, so that
   afterwards **`area2 > 0` and "inside" means all three edge functions ≥ 0**.
4. Edge `i` is opposite vertex `i`: `e0: b→c`, `e1: c→a`, `e2: a→b`. For edge
   `p→q`: `A = −(q.y−p.y)`, `B = q.x−p.x`, `C = −(A·p.x + B·p.y)`, and
   `e(px,py) = A·px + B·py + C` — **exact integer arithmetic, no rounding**.
5. Bounding box = floor of the vertex extrema / 256, clamped to the
   framebuffer. Empty → dropped, `tris_offscreen`.

**Edge inclusion (top-left rule).** A pixel is covered iff its centre has
`eᵢ > 0` for all three edges, or `eᵢ = 0` on an edge that is a **top or left
edge** (and `> 0` on the others — a point on two edges, i.e. a vertex, needs
*both* to be top/left). In bias form: `covered ⇔ eᵢ − biasᵢ ≥ 0 ∀i`, with
`biasᵢ = 0` if `Aᵢ > 0 ∨ (Aᵢ = 0 ∧ Bᵢ > 0)`, else `1`.

Geometric reading (winding-independent): a horizontal edge is *top* if the
triangle lies below it; any other edge is *left* if the triangle lies to its right.
Properties, all tested: (a) two triangles sharing an edge from opposite sides
cover each pixel on it **exactly once** (the edge belongs to exactly one of them);
(b) a mesh has no gaps and no double hits; (c) the rule is identical for both
windings. The independent oracle (`model/oracle.py`) implements the geometric
definition with exact rationals and shares no code with the model.

## 10. Rasterisation and attribute weights

Pixels are visited in row-major order over the bounding box; edge functions are
stepped by `A·256` per pixel and `B·256` per row (exact integer adds).

**Weights.** A block-floating-point reciprocal of `area2` is computed once per
triangle (`n = bitlength(area2)`, `m = area2` normalised to 16 bits,
`R = ⌊2³² / (m+1)⌋`, `k = max(0, n−24)`, `sh = n − 4 − k`), then per pixel:

```
w0 = ((e0 >> k) · R) >> sh        w1 = ((e1 >> k) · R) >> sh        w2 = ONE − w0 − w1
```

`R` deliberately **under**-estimates `2³²/m`, which guarantees `w0 + w1 ≤ ONE`, so
`w2 ≥ 0`, and `w0 + w1 + w2 = ONE` **exactly** — a flat-coloured triangle stays
exactly flat and no attribute ever leaves the range of its vertex values
(no clamping is needed anywhere). Measured accuracy against exact rationals
(`tools/accuracy_report.py`, 224 988 pixel samples): max weight error
**3.8×10⁻⁵ (≈ 40 × 2⁻²⁰)**.

## 11. Depth

* **Representation:** D24 UNORM, linear in `z_ndc = z/w`; `0` = near, `0xFFFFFF`
  = far. Stored in a 24-bit buffer. Linear in `z/w` means it is hyperbolic in
  eye-space distance: precision is concentrated near the near plane (the
  usual perspective-depth trade-off); a reversed-Z arrangement is available
  by choosing the matrix and the `GREATER`/`GEQUAL` functions.
* **Per-vertex** `sz` is rounded (§8); **per-pixel** `z = (w0·z0 + w1·z1 + w2·z2) >> 20`
  (truncating). Because the weights sum to `ONE`, `0 ≤ z ≤ 0xFFFFFF` always.
* **Accuracy — read this.** Storage is 24 bit, but the *interpolated* value is
  limited by the 20-bit weights and 16-bit reciprocal mantissa: measured maximum error
  is **≈ 548 D24 LSB (3.3×10⁻⁵ of full range, i.e. about 15 bits of effective
  accuracy)**. Do not rely on more than ≈ D16-equivalent interpolation accuracy.
  Making it tighter needs `LAM_F = 24` and `RECIP_MANT = 24` (wider multipliers
  and divider) — a documented, not-implemented upgrade.
* **Test:** `depth_en`; function `NEVER, LESS, EQUAL, LEQUAL, GREATER, NOTEQUAL,
  GEQUAL, ALWAYS` (encoding 0–7, state bits `[4:2]`). With the test disabled
  every fragment passes. **Write:** `depth_wr`, only for fragments that pass.
* **Clear value** `CFG_CLR_DEPTH` (reset: `0xFFFFFF`). Far-plane handling is
  geometric (clipping), so no per-fragment far test exists.

## 12. Colour and framebuffer

`c8 = (w0·c0 + w1·c1 + w2·c2 + 2²⁷) >> 28` per channel (Q8.8 × Q0.20 → Q8.28,
**round to nearest**). Interpolation is Gouraud; with `persp = 0` it is linear in
**screen** space (not perspective-correct). Measured accuracy: max error
**0.504** of an 8-bit LSB (ideal rounding bound 0.5), mean 0.25.
Framebuffer: RGB888, optionally double-buffered (`DOUBLE_BUF`): draws and
clears go to the back buffer; `PRESENT` swaps; the display reads the front
buffer. No blending: a passing fragment overwrites.

## 13. Texturing

Enabled by `tex_en`. One texture of `2^TEX_LOG2W × 2^TEX_LOG2H` RGB888 texels
(default 64×64), word address `(ty << TEX_LOG2W) | tx`.

* `u_fx = (Σ mᵢ·uᵢ) >>> 20`; `tx = u_fx >>> (16 − TEX_LOG2W)` (floor). **Nearest** only.
* Wrap per axis: `repeat` keeps the low bits (two's complement, so negative
  coordinates repeat correctly) or `clamp` saturates to `[0, size−1]`.
* Combine: `replace` outputs the texel; `modulate` outputs `round(texel·colour / 255)`
  per channel as `(x+128 + ((x+128)>>8)) >> 8`, which equals `round(x/255)` for all
  `0 ≤ x ≤ 255²` (exhaustively tested).
* **Perspective-correct mode** (`persp`): the weights are *transformed*:
  `ρᵢ = wᵢ·iwᵢ`, `S = Σρᵢ`, `μᵢ = ρᵢ/S` using the same block-FP reciprocal
  (`μ₂ = ONE − μ₀ − μ₁`). Colour **and** uv then use `μ` instead of `w` in the
  formulas above; **depth always uses `w`** (it is linear in screen space).
  One 33-cycle division per covered pixel. Measured against float:
  max |Δu| = 8×10⁻⁵, max |Δv| = 9.7×10⁻⁴ for `v` spanning 0…30 (one texel = 1.6×10⁻² of `u`).

## 14. Overflow and degenerate-input policy

The rule everywhere: **detect, drop the primitive, count it; never wrap and never
rasterise a value that was clamped to hide an error.**

| Stage | Hazard | Handling | Counter |
|---|---|---|---|
| Fetch | index ≥ `VB_VERTS`, or triangle words beyond `IB_DEPTH` | skip triangle | `bad_ref` |
| Transform | any component saturates s32 | drop triangle | `tris_xf_ovf` |
| Clip distances | 36-bit signed; max |value| = 5·2³¹ < 2³⁵ | cannot overflow | — |
| Clip intersection | `t < 2²⁴`; lerp lies between two int32 values | cannot overflow | — |
| Clip capacity | > 9 or < 3 vertices | reject | `tris_clip_rej` |
| After clip | `w ≤ 0` | drop polygon | `clip_bad_w` |
| Divider | divide by zero | defined result 0; unreachable (`w > 0`, `d_in − d_out > 0` checked) | — |
| Projection | sx/sy outside ±2²³ | saturate | `win_sat` |
| Projection | z outside `[0,w]` | clamp (rounding only) | — |
| Projection | `1/w` ≥ 2³² | saturate (silent; `w_raw ≤ 256`) | — |
| Setup | `area2 = 0` | drop | `tris_degen` |
| Setup | wholly off-screen / culled | drop | `tris_offscreen` / `tris_culled` |
| Setup | edge/area width | vertices are 24-bit ⇒ \|edge\| < 2⁵⁰ < 2⁵⁵ | — |
| Weights | negative / sum ≠ ONE | impossible by construction (property tested 3000+ triangles) | — |
| Colour / depth / uv | out of range | impossible: convex combination | — |
| Counters | 2³² events | saturate at `0xFFFFFFFF` | — |
| Command port | bad space / out-of-range address | `cmd_err`, no state change | `STATUS.err` (sticky) |

## 15. Command interface and registers

`gfx_core` command port (`valid/ready` in, one-cycle `cmd_done` pulse out):
`cmd_op` ∈ `WRITE, READ, CLEAR, DRAW, PRESENT`; `cmd_space`, `cmd_addr`,
`cmd_wdata`; results on `cmd_err`, `cmd_rdata` (zero for non-reads).
Commands run strictly one at a time. `gfx_tile` maps SilicaFlux work tokens onto
this port (`INTEGRATION.md`).

**Spaces** (word addressed): `0` CFG registers · `1` vertex memory (W) · `2` index
memory (W) · `3` texture memory (W) · `4` draw (back) colour buffer (R/W, pixel
index `y·W+x`) · `5` depth buffer (R/W) · `6` display (front) colour buffer (R).

**CFG registers:** `0x00` ID (`0x47465801`) · `0x01` STATUS (`bit1` = sticky error; write clears)
· `0x02` render state · `0x03` clear colour · `0x04` clear depth · `0x05` front-buffer index
· `0x10–0x1F` matrix · `0x20–0x2D` counters (read-only) · `0x3F` clear counters.

**Render state `0x02`:** `[0]` depth test · `[1]` depth write · `[4:2]` depth func ·
`[6:5]` cull · `[7]` front_ccw · `[8]` texture · `[9]` perspective-correct ·
`[10]` clamp u · `[11]` clamp v · `[12]` modulate.

**Counters** `0x20…0x2D`: `tris_in, tris_xf_ovf, tris_clip_rej, tris_clipped,
tris_degen, tris_culled, tris_offscreen, tris_raster, frags_cov, frags_zfail,
frags_written, bad_ref, win_sat, clip_bad_w`. Every input triangle ends in
exactly one of: rasterised, or one drop reason (a clipped polygon may fan into
several triangles, each of which is counted at setup).

## 16. Limits and parameters

* Compile-time: `FB_W, FB_H` (tested: 16×12, 32×24, 32×32, 160×120; the window
  arithmetic is sized for ≤ 1024), `VB_VERTS`, `IB_DEPTH`, `TEX_LOG2W/H`, `DOUBLE_BUF`.
* One matrix per draw (an object with its own matrix is its own `DRAW`).
* Triangles are processed one at a time; no early-Z across triangles; no scissor
  other than the framebuffer.
* Interpolated depth accuracy ≈ 15 bit (§11). Perspective-correct weights use a
  16-bit mantissa (§13).
* Not demonstrated on hardware; no timing/area closure (see `SYNTHESIS_STATUS.md`).
