# Verification

Everything here is reproducible with `./run_all.sh` (`--demos`, `--mutation` for the slow parts).
Numbers are a snapshot from the delivery run; the commands regenerate them.

## Strategy: three independent legs

1. **RTL ⇔ bit-exact reference model.** `model/gfxref.py` performs every step with Python integers using the
   exact widths, shifts and rounding of the RTL (spec §3–§13). Each test builds one command stream, runs it on the
   Verilator-simulated RTL **and** on the model, and requires identical: both colour buffers, the depth buffer, all
   14 counters, the front-buffer select, every command's error/readback value, and four per-stage trace streams
   (`XF` transformed vertices, `SC` projected triangles, `SU` setup result, `TD` per-triangle fragment tallies — so a
   mismatch is localised to a stage).
2. **The model ⇔ independent ground truth.** Bit-exactness proves the RTL implements the model — not that the model
   is right. So the model is itself checked against (a) `model/oracle.py`, which decides pixel coverage with exact
   rationals and a *geometric*, winding-independent definition of the top-left rule and shares no code with the model;
   (b) exact-rational barycentric interpolation (accuracy report below); (c) float perspective-correct interpolation;
   (d) global properties that must hold regardless of any implementation: every pixel of a shared edge is covered exactly
   once, a triangulated mesh has no gaps and no overlaps (the depth test with *equal* depth makes any double hit show
   up as a z-fail counter), `w₀+w₁+w₂ = ONE`, `div255` exhaustive.
3. **The tests themselves.** A mutation campaign injects one deliberate bug at a time into a copy of the RTL and
   requires the suite to fail.

Tests were run against the model with the *integer* semantics fixed first; the RTL was then brought to equality.
The first RTL run of the phase-1 smoke test matched exactly; the checks were validated for sensitivity (below) rather than assumed.

## Inventory (delivery run)

| Suite | File | Count | What it covers |
|---|---|---|---|
| Model self-tests | `model/test_model.py` | 17 | fill rule vs oracle on 4 lattices (6 000 random triangles incl. exact ties), quad/mesh no-gap/no-overlap, weight identities and error bound, clip invariants (shared-edge bit-identity, ≤ 9 vertices), depth functions, `div255` exhaustive (65 026 values) |
| RTL vs model, untextured | `sim/test_rtl_phase1.py` | 58 | colour interpolation; 6 cull/winding combinations; degenerate/off-screen/bad-index; all 8 depth functions with equal/nearer/farther fragments; depth write/test off; intersecting triangles; **shared-edge quads (both diagonals × both windings) cross-checked against the oracle**; **tie-lattice random triangles vs oracle**; **random jittered meshes: no gap, no overlap**; **17 clipping boundary cases**; clip counter sanity; shared edge across the near plane; transform overflow; command errors + readback + sticky status; 12 random scenes; PPM capture = front buffer after every `PRESENT` |
| RTL vs model, textured | `sim/test_rtl_phase2.py` | 24 | nearest sampling; wrap/clamp per axis, negative and large coordinates; modulate; texture on/off; foreshortened floor affine vs perspective (images must differ); perspective colour without texture; perspective + near-plane clipping; 10 random textured scenes; model-vs-float uv error bound |
| Tile protocol | `sim/test_tile.py` → `integration/tb/tb_gfx_tile.sv` | 1 test, 28 checks | reset state; single `tile_done` pulse; `token_ready` low while busy; `GFXRD` effective address; error reporting; `DFSYNC` compatibility; clear/present/readback; host sideband arbitration both ways; NoC ports quiet |
| System | `sim/test_system.py` | 3 | real SilicaFlux scalar core → scheduler → graphics tile: triangle program, 12-triangle cube with culling + depth, and the **negative test that the unfixed baseline scheduler loses tokens** |
| Display | `sim/test_display.py` | 4 | scan-out decoded from sync signals == scaled front buffer; `CE_DIV` 1/2/4; native 640×480 raster; measured timing |
| Baseline regression | `third_party/…/tb` via `run_all.sh` | 7 TBs | the baseline's own testbenches on the patched RTL (Icarus) |
| Consistency / lint / audit | `tools/check_consts.py`, `check_tile_ports.py`, `check_raw_hazards.py`, `audit_synth.py`, `slang_check.py` | — | 57 constants model==RTL; 26 ports identical; programs hazard-free; no non-synthesizable constructs; slang 0 errors |

## The clipping and edge cases specifically requested

* **Shared-edge triangles:** quads split along each diagonal in both windings with random half-pixel-lattice rectangles
  (`test_quad_shared_edge_exact_once`), random jittered meshes with both diagonal choices and random windings
  (`test_triangle_fan_and_random_mesh_no_gap_no_overlap`), and a pair of triangles sharing an edge that **crosses the near
  plane** (so the clipper must produce bit-identical intersection points). In all of them the equal-depth `LESS` test
  makes a double hit a counted z-fail; the mesh test also requires `frags_written == W×H` (no gaps).
* **Pixel centres exactly on edges and vertices:** `test_tie_lattice_random_triangles_vs_oracle` draws 36 random triangles
  on a half-pixel lattice and requires the RTL's pixel set to equal the exact-rational oracle's.
* **Clipping boundaries** (`CLIP_CASES`): fully visible; straddling near; behind the eye; one/two vertices behind;
  beyond far; straddling far; **vertices exactly on the near and far planes**; an edge lying in the near plane; a huge
  triangle covering the screen; a huge triangle also cut by the near plane; partial overlap of the left guard
  band; outside the guard band; outside only one plane; and a triangle crossing all of near/far/left/right/top/bottom.

## Mutation campaign (does the suite notice a wrong design?)

19 single-fault mutants of the RTL; a mutant that survives is a hole in the tests. **19 / 19 killed, 0 survived.**
(`tools/mutation_check.py`; first-failing test shown. The four mutants in `gfx_geom` were re-run after the last RTL edit
— tying the guard band to `gfx_pkg::GB`; the other 15 target files that did not change afterwards.)

```
fill rule inverted (not top-left)                    killed by test_quad_shared_edge_exact_once[0-0]
all edges inclusive (no tie-break)                   killed by test_quad_shared_edge_exact_once[0-0]
near plane exclusive (d>0 instead of d>=0)           killed by test_clip_boundary_cases[edge_on_near_plane]
depth LESS behaves as LEQUAL                         killed by test_depth_funcs_equal_and_ordered[1]
transform rounding removed                           killed by test_clip_boundary_cases[all_planes_big]
colour rounding removed                              killed by test_single_triangle_colour_interp
weight sum not renormalised (w2 = ONE-w0)            killed by test_single_triangle_colour_interp
clip intersection from wrong end (not canonical)     killed by test_clip_boundary_cases[all_planes_big]
viewport y not flipped                               killed by test_single_triangle_colour_interp
cull sense inverted                                  killed by test_cull_modes_both_windings[1-0]
bbox max off by one pixel (misses last column)       killed by test_single_triangle_colour_interp
far plane ignored (no clip on plane 1)               killed by test_clip_boundary_cases[all_planes_big]
tex: clamp ignored (always wrap)                     killed by test_wrap_vs_clamp_outside_unit_square[1-0]
tex: u/v swapped in address                          killed by test_wrap_negative_coordinates_and_large_repeat
tex: modulate rounding removed                       killed by test_modulate_with_vertex_colours
tex: modulate behaves as replace                     killed by test_modulate_with_vertex_colours
persp: attributes use screen weights                 killed by test_perspective_and_affine_floor_bit_exact[1]
persp: reciprocal shift off by one                   killed by test_perspective_and_affine_floor_bit_exact[1]
tex: texel coordinate shift wrong                    killed by test_texture_replace_nearest_basic
```

Two observations from the early sensitivity checks shaped the suite. (1) A first weight-perturbation mutant (1 part
in 2²⁰) was too small to change any 8-bit output and went undetected — a poor mutant, replaced by a visible one.
(2) A *flipped fill rule* went undetected by a generic single-triangle scene, because no pixel centre lies exactly on
an edge there. That is why the tie-lattice and shared-edge tests exist; the same mutant is now killed by them.

## Measured accuracy (`tools/accuracy_report.py`, 224 988 pixel samples vs exact rationals)

| Quantity | Result |
|---|---|
| Barycentric weight error | max 3.8×10⁻⁵ (≈ 40 × 2⁻²⁰) |
| Colour (8-bit channel) | max **0.504** LSB, mean 0.25 LSB (round-to-nearest bound is 0.5) |
| **Depth (D24)** | max error **≈ 548 LSB = 3.3×10⁻⁵ of range ≈ 15 effective bits** |
| Perspective-correct `u`, `v` (float ideal; `v` spans 0…30) | max \|Δu\| 8×10⁻⁵, max \|Δv\| 9.7×10⁻⁴ |

The depth figure is a real limitation of the chosen weight precision (spec §11), not a rounding-rule issue.

## Demos (every frame RTL == model)

| Demo | Frames | Bit-exact vs model | Simulated cycles / frame (min – max) | Triangles in (all frames) | rasterised | clipped | culled | clip-rejected |
|---|---|---|---|---|---|---|---|---|
| `rotating_triangle` | 36 | **36 / 36** | 26,805 – 39,924 | 36 | 36 | 0 | 0 | 0 |
| `scene_3d` | 48 | **48 / 48** | 136,875 – 155,725 | 4,320 | 2,633 | 633 | 501 | 197 |
| `scene_textured` | 36 | **36 / 36** | 676,258 – 695,851 | 1,584 | 937 | 400 | 246 | 75 |

Cycle counts are simulated engine clocks, not time: no clock frequency was achieved or measured.

## Bugs the verification found (in my own design and in the baseline)

In this work: a stale `cmd_rdata` on non-read commands; a scan-out whose pixel alignment was wrong for `CE_DIV ≥ 2`;
a scan-out buffer latch that never fired for `CE_DIV ≥ 2`; a part-select out of range (slang); a `GB` that was hard-coded
as a literal rather than tied to the package (found while writing the constants check); and three numeric claims in the
draft spec (per-pixel cycle costs, an accumulator bound, a saturation threshold) that were corrected on re-derivation.
a first, too-broad version of the scheduler fix that broke the *baseline's own* DFSYNC test (caught by the regression step of
`run_all.sh` before delivery, then narrowed to tile operations). In the baseline: see `INTEGRATION.md` D1–D5.

## What was **not** verified

* Anything on hardware; any synthesized netlist (`SYNTHESIS_STATUS.md`).
* Frame sizes above 160×120 in the engine (the arithmetic is sized for ≤ 1024; the *display* path was verified at 640×480).
* Simulation under Icarus or any simulator other than Verilator (slang elaborates it; that is a front-end check, not a second simulation).
* Long-running behaviour (counter saturation at 2³² events is by construction only).
* The unfilled board-constraint templates and every physical display route (`DISPLAY.md`).
* Coverage: line/branch/toggle coverage was **not** collected; confidence comes from directed + property + mutation testing.
