# Display output — and why it is separate from the rendering engine

**The rendering engine knows nothing about displays.** It writes pixels into a
framebuffer and exposes one read port. Everything that turns that framebuffer
into a video signal lives in `display/` and can be replaced without touching `rtl/`.

```
 ┌────────────────────── rtl/ : rendering engine ──────────────────────┐   ┌───────────── display/ ─────────────┐   ┌── board ──┐
 │ …raster ─▶ gfx_fbmem (colour ×2, depth) ── scan port ───────────────┼──▶│ gfx_scanout (+video_timing)        │──▶│ DAC / TMDS │
 │  (clk)         write side: engine clock    scan_clk/scan_buf/       │   │  RGB888 + DE/HS/VS  (pix_clk)      │   │ encoder IP │
 └──────────────────────────────────────────────────────────────────────┘   └────────────────────────────────────┘   └────────────┘
                      boundary 1: scan port          boundary 2: pixel stream (vid_r/g/b[7:0], vid_de, vid_hs, vid_vs)
```

## Boundary 1 — the scan port (engine ⇄ display)

| Signal | Dir (engine) | Meaning |
|---|---|---|
| `scan_clk` | in | read clock for the framebuffer (the display's pixel clock domain) |
| `scan_buf` | in | which colour buffer to read (0/1); must be stable during a frame |
| `scan_addr[$clog2(W·H)-1:0]` | in | pixel index `y·W + x` |
| `scan_data[23:0]` | out | `{R,G,B}`, valid **one `scan_clk` after** `scan_addr` |
| `front_sel_o` | out | buffer the engine considers front (engine clock domain — synchronise before use) |

The colour memory is a simple dual-port RAM with **independent read and write
clocks**, so no pixel data crosses a clock domain through logic. The only crossing is the
1-bit `front_sel_o`, which `gfx_scanout` passes through two flops and latches **at the last
pixel of the previous frame**, i.e. in blanking — the picture can never mix two
buffers within a frame.

## Boundary 2 — the pixel stream (display ⇄ board)

`vid_r, vid_g, vid_b [7:0]`, `vid_de` (data enable), `vid_hs`, `vid_vs`, all registered and aligned,
clocked by `pix_clk` (optionally gated by `pix_ce`, below). This is the conventional parallel-RGB
interface that DVI/HDMI transmitters, TMDS-encoder IP and resistor-ladder VGA DACs all accept.

## What is provided (`display/`)

| File | Role |
|---|---|
| `video_timing.sv` | raster generator; defaults = **VESA 640×480 @ 60 Hz** (800×525 total, negative syncs) |
| `gfx_scanout.sv` | integer up-scaler + frame-safe buffer select + pipeline alignment; 160×120 ×4 → 640×480 |
| `pmod_vga_adapter.sv` | RGB888 → the Digilent **Pmod VGA** signal set (4-4-4 + HS + VS, truncation, blanking) |
| `tb/tb_scanout.sv` | monitor model: decodes frames **from the sync signals alone** and measures timing |

`CE_DIV` (parameter) / `pix_ce` (input) let the whole display side run from a single faster
clock with a pixel enable — e.g. 100 MHz / 4 = **25.000 MHz** with no PLL. VESA nominal is
25.175 MHz; most sinks tolerate 25.000 MHz, but that is a property of the monitor, not something
tested here. The memory's one-clock read latency is a whole pixel period when `CE_DIV = 1` but only part of
one when `CE_DIV ≥ 2`, so `gfx_scanout` derives its pipeline alignment from the parameter.

## Verified in simulation (`sim/test_display.py`, 4 tests)

For every configuration the engine renders a depth-tested triangle and presents it; the scan-out runs on a
**pixel clock asynchronous to the engine clock**; the monitor model reconstructs a complete frame from
`vid_*` and the test requires it to equal the reference model's front buffer, scaled and centred,
**pixel for pixel**, and the measured line/frame lengths and sync widths to equal the configured timing:

| Config | Result |
|---|---|
| 16×12 ×4 in an 80×60 raster with borders, `CE_DIV` = 1, 2, 4 | exact picture; exact `htotal/hsync/vtotal/vsync` |
| **160×120 ×4 in the full 640×480 VESA raster (no borders)**, 800×525 total | exact picture; 96-px / 2-line sync widths |

Bugs found by these tests while writing them (fixed): a scan-out pipeline whose latency was wrong
for `CE_DIV ≥ 2`; a buffer-select latch that never fired for `CE_DIV ≥ 2`; and (by an independent
front end, slang) an out-of-range part-select that simulated correctly by luck.

## Connecting it to a physical display — options, honestly

Nothing below was built for or run on hardware. Pin assignments, clocking primitives and
monitor compatibility **must be taken from the board vendor's documentation**; this section only
says which documented interface each route uses.

1. **Digilent Pmod VGA on a board with Pmod headers (documented board peripheral).** The Pmod
   VGA is a 4-bit-per-colour resistor-ladder DAC plus HSYNC/VSYNC, driven directly by FPGA pins
   (two Pmod connectors). Use `gfx_scanout → pmod_vga_adapter` and constrain `vga_r/g/b[3:0]`,
   `vga_hs`, `vga_vs` to the connector pins listed in the **board's master constraints file and the
   Pmod's reference manual**. The Arty A7 family has no video connector of its own, so this is the
   route for the SilicaFlux repo's Arty A7-100T synthesis target. Constraint template:

   ```tcl
   # TEMPLATE ONLY -- fill every <PIN> from the vendor master XDC + Pmod VGA reference manual
   set_property -dict { PACKAGE_PIN <PIN> IOSTANDARD LVCMOS33 } [get_ports { vga_r[0] }]   ;# ... vga_r[3:0], vga_g[3:0], vga_b[3:0]
   set_property -dict { PACKAGE_PIN <PIN> IOSTANDARD LVCMOS33 } [get_ports { vga_hs }]
   set_property -dict { PACKAGE_PIN <PIN> IOSTANDARD LVCMOS33 } [get_ports { vga_vs }]
   create_clock -period 10.000 [get_ports clk]          ;# 100 MHz board clock; pix_ce = clk/4 (CE_DIV = 4)
   ```

2. **DVI/HDMI through established TMDS encoder IP** on a board with a DVI/HDMI output connector:
   feed `vid_r/g/b`, `vid_de`, `vid_hs`, `vid_vs` into the vendor/partner encoder (for example Digilent's
   open-source `rgb2dvi` IP for Xilinx devices, which takes parallel RGB plus syncs and a pixel clock and
   generates the serial clock internally). Its clocking and constraints come with that IP's documentation.

3. **Board with an on-board HDMI transmitter chip** (the Terasic DE10-Nano, the SilicaFlux repo's Quartus
   target, uses an ADV7513): the chip takes the same parallel RGB + DE/HS/VS bus; it additionally needs an
   I²C register configuration that must come from the board's reference design. Intel's Clocked Video
   Output IP is the established alternative if the framebuffer is moved into external memory.

Resource note (estimate, not tool output): at 160×120, double-buffered 24-bit colour plus a 24-bit depth buffer
is ≈ 1.38 Mbit; with the extra read ports (scan-out, host read-back) the tools may replicate memories, so
expect on the order of 60–100 36-Kbit block RAMs. Removing the host read-back port would reduce
that, but v1 does not provide that as a parameter. `gfx_fbmem` is written for block-RAM inference; Yosys
confirms it infers three memories (`$mem` ×3) but no vendor tool was run.

## Not verified

* any real display, DAC, TMDS or HDMI-chip output; EDID / monitor lock;
* pin assignments and I/O standards (templates above are deliberately unfilled);
* dual-clock block-RAM inference by Vivado or Quartus, and timing closure of the pixel path;
* the 25.000 MHz vs 25.175 MHz tolerance of any particular monitor.
