# Synthesizability — what was checked, and what was not

**No FPGA or ASIC synthesis, place-and-route, timing, area or power run was performed.**
No vendor tool was available. "Synthesizable SystemVerilog" is therefore supported by the
evidence below — coding style, three independent front ends, and partial open-source
synthesis — and **not** by a completed implementation. Do not quote an Fmax, LUT/BRAM/DSP
count or frame rate for this design; none exists.

## Evidence that exists

| Check | Tool | Result | How to reproduce |
|---|---|---|---|
| Strict lint of the engine (`-Wall`, waiving only declaration-filename and unused-signal/param noise) | Verilator 5.020 | clean | `verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM --top-module gfx_core rtl/*.sv` |
| Strict elaboration of engine + display side (`-DSYNTHESIS`) | slang 12.2 (`pyslang`) | **0 errors**; 129 warnings (engine) / 49 (display), all in the classes `sign-conversion` 46, `arith-op-mismatch` 40, `sign-compare` 25, `useless-cast` 13, `case-type` 5 — mixed signedness / width style, not individually audited | `python3 tools/slang_check.py` |
| Forbidden-construct audit: no delays, no `initial`/system tasks outside `ifndef SYNTHESIS` / `ifdef GFX_TRACE`, no fork/force/wait/random/class | `tools/audit_synth.py` | 13 files clean (self-tested on a deliberately bad file) | `python3 tools/audit_synth.py` |
| Simulation-only code isolated | by construction | `$display` trace under `GFX_TRACE` only; memory zero-fill under `ifndef SYNTHESIS` | grep |
| Memory inference | Yosys 0.33 (`proc; memory -nomap`) on `gfx_fbmem`, 160×120 | 3 `$mem_v2` cells (two colour buffers, one depth buffer) | `build/synth/` scripts in `synth/` |
| Divider, fully technology-mapped to Yosys generic gates | Yosys 0.33 | `gfx_div` (64×40): 913 cells (216 DFFE + 105 MUX + logic) | `synth/yosys_blocks.sh` |
| Word-level operator census, `gfx_setup` / `gfx_raster` (coarse-grain, **before** mapping) | Yosys 0.33 | setup: 316 cells incl. 7 multiply-accumulate (`$macc`) groups; raster: 361 cells incl. 20 `$macc` groups | `synth/yosys_blocks.sh` |

The `$macc` figures count **combinational multiply operators as written** (each state's
expression is its own operator); they are *not* DSP-block counts. The FSMs are written so that a
tool or a later refactor could time-share them; no such sharing was done or evaluated.

## What did not work, and why

* **Whole-design Yosys run: not possible with the available Yosys (0.33).** Its front end rejects
  `import pkg::*` (anywhere), `return` in functions (fixed in the RTL by using the legacy
  assign-to-function-name style, which is harmless to other tools), and variable-indexed arrays of
  packed structs (`pin[i].x <= …` in `gfx_geom`/`gfx_xform`). Rewriting a verified design around an old
  front end's gaps was judged the wrong trade. A newer Yosys with the `slang` plugin, or `sv2v`, would
  most likely take it unchanged; neither was available (`apt`/`pip`).
* **Icarus Verilog 12 cannot compile the engine** (same array-of-struct limitations, plus
  constant selects in `always_*`). Verilator is the simulator for everything here; Icarus is used only
  for the *baseline* SilicaFlux regression.

## Known timing and area concerns (not measured — flagged for whoever runs the tools)

* Per-pixel arithmetic is combinational within a state: 24×17 weight multiplies feeding variable
  shifts (`R_LAM`), 21×24 depth sums (`R_Z`), 21×16 three-term colour sums plus rounding (`R_COL`),
  and for perspective-correct texturing 21×32 products and a 55-bit sum (`R_RHO`). Expect these to need
  pipelining before they meet a fast clock.
* `gfx_div` is a 1-bit-per-cycle restoring divider (64-bit dividend); the projection stage spends 64 cycles
  per division by design (area over speed).
* Edge accumulators are 56 bit; the coverage test is three 56-bit compare-with-bias operations in one cycle.
* Block-RAM: `gfx_fbmem` is a 1-write / 2-read (scan, host) dual-clock memory written in the standard
  inferable style; tools may replicate memories for the extra read port. Vivado/Quartus inference was not tested.
* Vertex/index/texture memories are 1-write/1-read simple dual-port RAMs (`gfx_ram`).

## Reproducing the Yosys numbers

`synth/yosys_blocks.sh` regenerates the Yosys-friendly variant (scoped names instead of `import`) into
`build/synth/rtl_y/` with `tools/make_yosys_variant.py` and runs the per-block scripts. The shipped RTL is
not modified.
