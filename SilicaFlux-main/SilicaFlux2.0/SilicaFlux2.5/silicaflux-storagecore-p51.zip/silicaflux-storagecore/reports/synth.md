# Synthesis report (Yosys 0.33, estimates only)

Generic: `synth -flatten; check -assert` (fails on latches, loops, multiple drivers). FPGA: `synth_ecp5 -abc9` (Lattice ECP5, the board family of the ControlCore/MCU-I flows). No place & route, no timing closure, no ASIC flow run: see `synth/openroad/` for the prepared, NOT executed, OpenROAD configuration.

| Configuration | Top | Generic cells (logic + FF) | generic FF | $mem cells (SRAMs, unmapped) | check -assert | ECP5 LUT4 | ECP5 FF | DP16KD |
|---|---|---|---|---|---|---|---|---|
| `min1ch` | `sfs_storage_subsys` | 24433 | 2957 | 14 | PASS | 6634 | 3086 | 10 |
| `min1ch` | `silicaflux_storage_soc` | 56660 | 6784 | 21 | PASS | 17962 | 6928 | 58 |
| `noecc1ch` | `sfs_storage_subsys` | 20574 | 2526 | 14 | PASS | 5288 | 2656 | 8 |
| `noecc1ch` | `silicaflux_storage_soc` | 52746 | 6353 | 21 | PASS | 16749 | 6498 | 56 |
| `research4ch` | `sfs_storage_subsys` | 46244 | 5668 | 20 | PASS | 13757 | 5927 | 36 |
| `research4ch` | `silicaflux_storage_soc` | 78667 | 9495 | 27 | PASS | 24881 | 9769 | 84 |

**Result: PASS**
