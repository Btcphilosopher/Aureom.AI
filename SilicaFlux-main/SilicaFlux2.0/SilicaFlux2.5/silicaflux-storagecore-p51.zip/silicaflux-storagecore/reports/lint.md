# Lint report

Tools: Verilator 5.020 (`--lint-only -Wall`), Icarus Verilog 12 (`-g2012` elaboration).
New RTL = `rtl/*.sv` + generated packages.  `third_party/` = reused, unmodified sources (reported, not counted).

| Top | Configuration | Verilator new-RTL warnings | third_party warnings | Icarus |
|---|---|---|---|---|
| `sfs_storage_subsys` | `min1ch` | 0 | 82 | elaborates |
| `silicaflux_storage_soc` | `min1ch` | 0 | 363 | elaborates |
| `sfs_storage_subsys` | `noecc1ch` | 0 | 82 | elaborates |
| `silicaflux_storage_soc` | `noecc1ch` | 0 | 363 | elaborates |
| `sfs_storage_subsys` | `research4ch` | 0 | 82 | elaborates |
| `silicaflux_storage_soc` | `research4ch` | 0 | 363 | elaborates |

## Illegal parameter sets (must be rejected)

| Parameters | Verilator | Icarus |
|---|---|---|
| `CHANNEL_DATA_WIDTH=12` | rejected ($fatal at elaboration) | rejected ($fatal at time 0) |
| `DMA_DATA_WIDTH=48` | rejected ($fatal at elaboration) | rejected ($fatal at time 0) |

**Result: PASS**
