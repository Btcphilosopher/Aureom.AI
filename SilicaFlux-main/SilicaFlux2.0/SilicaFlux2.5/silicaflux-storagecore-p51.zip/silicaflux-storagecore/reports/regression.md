# Regression

Host: vm; tools: Verilator 5.020, Icarus Verilog 12.0, riscv64-unknown-elf-gcc 13.2, Python 3.

| Kind | Tool | Configuration / run | Result | Wall time (s) |
|---|---|---|---|---|
| map | gen_map --check | `-` | PASS | 0 |
| map | gen_map --selftest | `-` | PASS (20/20) | 0 |
| fw | riscv64-unknown-elf-gcc | `-` | PASS | 0 |
| unit | icarus | `min1ch` | PASS (345 checks, 0 failures) | 9 |
| unit | verilator | `min1ch` | PASS (345 checks, 0 failures) | 0 |
| unit | icarus | `research4ch` | PASS (554 checks, 0 failures) | 35 |
| unit | verilator | `research4ch` | PASS (554 checks, 0 failures) | 1 |
| unit | icarus | `noecc1ch` | PASS (315 checks, 0 failures) | 9 |
| unit | verilator | `noecc1ch` | PASS (315 checks, 0 failures) | 0 |
| soc | verilator | `min1ch_full` | PASS (152 checks, 0 failures, 2,026,505 cycles) | 7 |
| soc | verilator | `min1ch_full_seed2` | PASS (152 checks, 0 failures, 2,029,904 cycles) | 7 |
| soc | verilator | `research4ch_full` | PASS (195 checks, 0 failures, 2,013,494 cycles) | 9 |
| soc | verilator | `noecc1ch_full` | PASS (142 checks, 0 failures, 1,829,066 cycles) | 5 |

**Overall: PASS** -- logs in `reports/sim/`.
