// =============================================================================
// SilicaFlux-STORE :: tb_storage_soc -- full SoC testbench (real firmware on the RTL CPU)
//
// DUT: silicaflux_storage_soc = UNMODIFIED ControlCore (RV32IM CPU, boot ROM, ...)
//      + StorageCore subsystem.  Around it:
//   * simulated HOST: drives the BAR (SFB2 slave port) as a host driver would,
//     owns host memory (sfs_tb_hostmem: back-pressure, latency, IOMMU faults)
//     and waits on host_irq_o / mgmt_irq_o;
//   * one behavioural NAND device per channel (sfs_nand_flash_model).
// The firmware image (firmware/build/sfs_fw.hex) is loaded into IMEM through
// the ControlCore host port, the boot ROM checks it (header + CRC32) and
// starts it -- the same flow as the ControlCore's own system testbench.
//
// Scenarios (+scenario=dod|full, default full):
//   dod  : boot, enable, IDENTIFY, WRITE 4 LBAs, READ them back, tagged results
//   full : dod + concurrency (QD = tags, out-of-order completions), invalid
//          commands, unmapped / deallocated reads, NAND ECC correct / uncorrectable,
//          back-pressure (host memory + full CQ), controller reset with commands
//          in flight, power loss, security locks, FLUSH/FUA/checkpoint, physical
//          commands, GET_LOG status, shutdown, end-of-test through the mailbox.
// Plusargs: +fw=<hex> +scenario=<s> +timeout=<cycles> +con (echo firmware console)
// Config:   +define+SFS_CFG_<MIN1CH|RESEARCH4CH|NOECC1CH> (+define+SFS_MULTI for 4 ch)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "sfs_configs.svh"

module tb_storage_soc;
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
  import cc_memmap_pkg::*;

  localparam int NCH  = `SFS_P_NUM_NAND_CHANNELS;
  localparam int CDW  = `SFS_P_CHANNEL_DATA_WIDTH;
  localparam int BUFB = `SFS_P_BUFFER_SIZE_BYTES;
  localparam int DW   = `SFS_P_DMA_DATA_WIDTH;
  localparam int AWID = `SFS_P_ADDRESS_WIDTH;
  localparam int NT   = `SFS_P_CMD_QUEUE_DEPTH;
  localparam int ECC  = `SFS_P_ENABLE_ECC;
  localparam int RAS  = `SFS_P_ENABLE_RAS;
  localparam int PAGE = `SFS_P_NAND_PAGE_BYTES;
  localparam int SB   = DW / 8;
  localparam int HQD  = (2 * NT > 64) ? 64 : 2 * NT;
  localparam int PPB  = 16;
  localparam int RAW_PAGE = PAGE * 3 / 2;
  localparam logic [31:0] SHC = SFS_BAR_SHC_BASE;
  localparam int SFS_SQE_FUA_FLAG = 2;
  string scenario;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;                       // 100 MHz core clock
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ---------------------------------------------------------------- DUT
  logic        hb_req_valid = 0, hb_req_write = 0, hb_req_ready, hb_rsp_valid, hb_rsp_error;
  logic [31:0] hb_req_addr = 0, hb_req_wdata = 0, hb_rsp_rdata;
  logic [3:0]  hb_req_wstrb = 4'hF;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr;
  logic [DW-1:0] hm_req_wdata, hm_rsp_rdata;
  logic [SB-1:0] hm_req_wstrb;
  logic        host_irq, mgmt_irq, host_ready, cmdproc_ready, ras_fatal;
  logic [NCH-1:0] ce_n, cle, ale, we_n, re_n, wp_n, dq_oe, rb_n;
  logic [NCH*CDW-1:0] dq_o, dq_i;
  logic        pwr_fail_n = 1'b1, host_rst_req = 1'b0;
  logic        diag_valid, test_done, test_fail, cpu_sleep;
  logic [7:0]  diag_char;
  logic [15:0] test_code;
  int          bp_pct = 0, lat_max = 2;

  silicaflux_storage_soc #(
    .NUM_NAND_CHANNELS(NCH), .CHANNEL_DATA_WIDTH(CDW), .BUFFER_SIZE_BYTES(BUFB), .DMA_DATA_WIDTH(DW),
    .ADDRESS_WIDTH(AWID), .CMD_QUEUE_DEPTH(NT), .ENABLE_ECC(ECC), .ENABLE_RAS(RAS), .NAND_PAGE_BYTES(PAGE)
  ) dut (
    .clk, .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(2'(CC_BOOT_MODE_HOST)), .host_rst_req_i(host_rst_req),
    .pwr_fail_ni(pwr_fail_n),
    .hb_req_valid, .hb_req_ready, .hb_req_write, .hb_req_addr, .hb_req_wdata, .hb_req_wstrb,
    .hb_rsp_valid, .hb_rsp_ready(1'b1), .hb_rsp_rdata, .hb_rsp_error,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .host_irq_o(host_irq), .mgmt_irq_o(mgmt_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready),
    .ras_fatal_o(ras_fatal),
    .nand_ce_n(ce_n), .nand_cle(cle), .nand_ale(ale), .nand_we_n(we_n), .nand_re_n(re_n), .nand_wp_n(wp_n),
    .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(dq_i), .nand_rb_n(rb_n),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep)
  );

  sfs_tb_hostmem #(.DW(DW), .SIZE(1 << 20)) hmem (
    .clk, .rst_n, .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write),
    .req_addr(hm_req_addr), .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid),
    .rsp_ready(hm_rsp_ready), .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error), .bp_pct, .lat_max
  );

  genvar gc;
  for (gc = 0; gc < NCH; gc++) begin : g_nand
    wire [CDW-1:0] dq;
    assign dq = dq_oe[gc] ? dq_o[gc*CDW +: CDW] : {CDW{1'bz}};
    assign dq_i[gc*CDW +: CDW] = dq;
    sfs_nand_flash_model #(.DQW(CDW), .RAW_PAGE(RAW_PAGE), .PAGES_PER_BLOCK(PPB), .BLOCKS(64), .CH(gc)) flash (
      .ce_n(ce_n[gc]), .cle(cle[gc]), .ale(ale[gc]), .we_n(we_n[gc]), .re_n(re_n[gc]), .wp_n(wp_n[gc]),
      .dq, .rb_n(rb_n[gc])
    );
  end

  // ---------------------------------------------------------------- firmware console
  string con_line = "";
  bit con_echo;
  initial con_echo = $test$plusargs("con") || 1'b1;
  always @(posedge clk) if (diag_valid) begin
    if (diag_char == 8'h0A) begin if (con_echo) $display("FW| %s", con_line); con_line = ""; end
    else con_line = {con_line, string'(diag_char)};
  end

  // ---------------------------------------------------------------- scoreboard
  int n_pass = 0, n_fail = 0;
  string grp = "";
  task automatic check(input string what, input logic [63:0] got, input logic [63:0] exp);
    if (got === exp) n_pass++;
    else begin n_fail++; $display("[%0d] FAIL %s/%s: got 0x%0h expected 0x%0h", cyc, grp, what, got, exp); end
  endtask
  task automatic check_true(input string what, input bit c);
    check(what, 64'(c), 64'd1);
  endtask

  // ---------------------------------------------------------------- host BAR BFM
  // One process performs every BAR transaction; callers hand it a request and wait for the answer.
  // (Keeps the code Verilator generates per call site small: tasks with timing are inlined.)
  bit          bfm_wr, bfm_err, bfm_busy = 0;
  logic [31:0] bfm_a, bfm_wd, bfm_rd;
  event        bfm_go, bfm_fin;
  always begin
    @(bfm_go);
    @(negedge clk);
    hb_req_valid = 1; hb_req_write = bfm_wr; hb_req_addr = bfm_a; hb_req_wdata = bfm_wd; hb_req_wstrb = 4'hF;
    #4; while (!hb_req_ready) begin @(negedge clk); #4; end
    @(posedge clk); #1;
    hb_req_valid = 0;
    @(negedge clk); #4; while (!hb_rsp_valid) begin @(negedge clk); #4; end
    bfm_rd = hb_rsp_rdata; bfm_err = hb_rsp_error;
    @(posedge clk); #1;
    -> bfm_fin;
  end
  task automatic bar_access(input bit wr, input logic [31:0] a, input logic [31:0] wd,
                            output logic [31:0] rd, output logic err);
    while (bfm_busy) @(posedge clk);
    bfm_busy = 1; bfm_wr = wr; bfm_a = a; bfm_wd = wd;
    #1 -> bfm_go;                     // the server is parked at @(bfm_go) by now
    @(bfm_fin);
    rd = bfm_rd; err = bfm_err; bfm_busy = 0;
  endtask
  task automatic bw(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; logic e;
    bar_access(1, a, d, r, e);
    if (e) begin n_fail++; $display("[%0d] FAIL %s: BAR write error @%08h", cyc, grp, a); end
  endtask
  task automatic br(input logic [31:0] a, output logic [31:0] d);
    logic e;
    bar_access(0, a, 0, d, e);
    if (e) begin n_fail++; $display("[%0d] FAIL %s: BAR read error @%08h", cyc, grp, a); end
  endtask

  // ---------------------------------------------------------------- boot (ControlCore host-load flow)
  logic [31:0] img [$];
  logic [31:0] rsp [8];
  task automatic mbox_wait(input longint tmo);
    longint t0 = cyc;
    while (!mgmt_irq && cyc - t0 < tmo) @(posedge clk);
    if (!mgmt_irq) begin n_fail++; $display("[%0d] FAIL %s: mailbox timeout", cyc, grp); end
    for (int i = 0; i < 8; i++) begin logic [31:0] v; br(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 32'(4 * i), v); rsp[i] = v; end
    bw(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
  endtask
  task automatic mbox_cmd(input logic [31:0] cmd, input logic [31:0] a1, input longint tmo);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, a1);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd);
    mbox_wait(tmo);
  endtask
  task automatic boot();
    string fw; int fd; logic [31:0] w, v; longint t0;
    grp = "boot";
    if (!$value$plusargs("fw=%s", fw)) fw = "firmware/build/sfs_fw.hex";
    fd = $fopen(fw, "r");
    if (fd == 0) $fatal(1, "cannot open firmware image %s", fw);
    while ($fscanf(fd, "%h\n", w) == 1) img.push_back(w);
    $fclose(fd);
    $display("TB host: firmware image %s, %0d words", fw, img.size());
    t0 = cyc;
    do br(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v); while (v != CC_BOOT_STAGE_WAIT_IMAGE && cyc - t0 < 2_000_000);
    check("ROM waits for the image", v, CC_BOOT_STAGE_WAIT_IMAGE);
    for (int i = 0; i < img.size(); i++) bw(CC_IMEM_BASE + 32'(4 * i), img[i]);
    $display("TB host: image written at cycle %0d", cyc);
    mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 0, 3_000_000);
    check("boot ROM accepted the image", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    t0 = cyc;
    while (!host_ready && cyc - t0 < 3_000_000) @(posedge clk);
    check_true("host_ready pin", host_ready);
    mbox_wait(1000);
    $display("TB host: HOST READY at cycle %0d: channels=%0h capacity=%0d config0=%08h cause=%0h fw=%08h ckpt=%0d",
             cyc, rsp[1], rsp[2], rsp[3], rsp[4], rsp[5], rsp[6]);
    check("channel mask", rsp[1], (1 << NCH) - 1);
    check("capacity", rsp[2], 256 * NCH);
  endtask

  // ---------------------------------------------------------------- host driver: queues
  int sq_tail_s = 0, cq_head_s = 0; bit phase_s = 1;
  int cap_lba = 0;
  // outstanding-command bookkeeping: tid -> expected status (-1 = any), done flag
  int  exp_st [int];
  bit  seen [int];
  logic [127:0] cqe_of [int];
  int  cpl_order [$];

  task automatic enable_ctrl();
    logic [31:0] v; longint t0;
    bw(SHC + SFS_SHC_INT_CTRL, 32'h3);                      // CQ + event interrupts
    bw(SHC + SFS_SHC_CTRL, 32'h1);
    t0 = cyc;
    do br(SHC + SFS_SHC_STATUS, v); while (!v[0] && cyc - t0 < 500_000);
    check("controller RDY", 64'(v[0]), 1);
    br(SHC + SFS_SHC_CAPACITY_LO, v); cap_lba = int'(v);
    sq_tail_s = 0; cq_head_s = 0; phase_s = 1;
    bw(SHC + SFS_SHC_INT_STATUS, 32'h2);
  endtask
  task automatic submit(input int op, input int flags, input int tid, input logic [63:0] addr, input int len,
                        input logic [31:0] hbuf, input int expect_status);
    logic [31:0] w [8];
    w[0] = 32'(op) | (32'(flags) << 8) | (32'(tid) << 16); w[1] = 0; w[2] = addr[31:0]; w[3] = addr[63:32];
    w[4] = 32'(len); w[5] = hbuf; w[6] = 0; w[7] = 0;
    for (int k = 0; k < 8; k++) bw(SHC + SFS_SHC_SQ_RING + 32'(sq_tail_s * 32 + k * 4), w[k]);
    sq_tail_s = (sq_tail_s + 1) % HQD;
    exp_st[tid] = expect_status;
    seen[tid] = 0;
  endtask
  task automatic ring();
    bw(SHC + SFS_SHC_SQ_TAIL, 32'(sq_tail_s));
  endtask
  // consume every available CQ entry; returns how many
  task automatic reap(output int n);
    logic [31:0] w3, w;
    logic [127:0] c;
    n = 0;
    br(SHC + SFS_SHC_CQ_RING + 32'(cq_head_s * 16 + 12), w3);
    while (w3[16] == phase_s) begin
      int tid;
      c = '0;
      for (int k = 0; k < 3; k++) begin br(SHC + SFS_SHC_CQ_RING + 32'(cq_head_s * 16 + k * 4), w); c[k*32 +: 32] = w; end
      c[96 +: 32] = w3;
      tid = int'(w3[15:0]);
      if (!exp_st.exists(tid)) begin
        n_fail++; $display("[%0d] FAIL %s: completion for unknown TID %04h", cyc, grp, tid);
      end else begin
        if (seen[tid]) begin n_fail++; $display("[%0d] FAIL %s: duplicate completion TID %04h", cyc, grp, tid); end
        seen[tid] = 1;
        cqe_of[tid] = c;
        cpl_order.push_back(tid);
        if (exp_st[tid] >= 0) check($sformatf("status of TID %04h", tid), 64'(w3[23:17]), 64'(exp_st[tid]));
      end
      cq_head_s = (cq_head_s + 1) % HQD;
      if (cq_head_s == 0) phase_s = !phase_s;
      n++;
      br(SHC + SFS_SHC_CQ_RING + 32'(cq_head_s * 16 + 12), w3);
    end
    if (n) bw(SHC + SFS_SHC_CQ_HEAD, 32'(cq_head_s));
  endtask
  // wait (on host_irq) until every listed TID has completed
  task automatic wait_tids(input int tids [$], input longint tmo);
    longint t0 = cyc; int n, left;
    forever begin
      left = 0;
      foreach (tids[i]) if (!seen[tids[i]]) left++;
      if (left == 0) break;
      if (cyc - t0 > tmo) begin
        n_fail++; $display("[%0d] FAIL %s: %0d command(s) did not complete", cyc, grp, left);
        foreach (tids[i]) if (!seen[tids[i]]) $display("      missing TID %04h", tids[i]);
        break;
      end
      if (!host_irq) @(posedge host_irq or posedge cpu_sleep);
      reap(n);
      if (n == 0) repeat (50) @(posedge clk);
    end
  endtask
  function automatic int st_of(input int tid);  return int'(cqe_of[tid][113 +: 7]); endfunction
  function automatic int err_of(input int tid); return int'(cqe_of[tid][120 +: 8]); endfunction
  function automatic logic [31:0] r0_of(input int tid); return cqe_of[tid][0 +: 32]; endfunction
  function automatic logic [31:0] r1_of(input int tid); return cqe_of[tid][32 +: 32]; endfunction

  // host buffers
  function automatic logic [31:0] pat(input int lba, input int w, input int gen);
    return {8'(gen), 8'(lba), 16'(w)} ^ 32'h5A00_0000;
  endfunction
  task automatic fill_host(input logic [31:0] hb, input int lba0, input int n, input int gen);
    for (int b = 0; b < n; b++) for (int w = 0; w < PAGE / 4; w++) hmem.wr32(int'(hb) + b * PAGE + w * 4, pat(lba0 + b, w, gen));
  endtask
  task automatic clear_host(input logic [31:0] hb, input int n);
    for (int b = 0; b < n; b++) for (int w = 0; w < PAGE / 4; w++) hmem.wr32(int'(hb) + b * PAGE + w * 4, 32'hDEAD_BEEF);
  endtask
  task automatic check_host(input string what, input logic [31:0] hb, input int lba0, input int n, input int gen);
    int bad = 0;
    for (int b = 0; b < n; b++) for (int w = 0; w < PAGE / 4; w++)
      if (hmem.rd32(int'(hb) + b * PAGE + w * 4) !== pat(lba0 + b, w, gen)) begin
        if (bad < 3) $display("      %s: lba %0d word %0d = %08h, expected %08h", what, lba0 + b, w,
                              hmem.rd32(int'(hb) + b * PAGE + w * 4), pat(lba0 + b, w, gen));
        bad++;
      end
    check(what, 64'(bad), 0);
  endtask
  task automatic check_zero(input string what, input logic [31:0] hb, input int n);
    int bad = 0;
    for (int i = 0; i < n * PAGE / 4; i++) if (hmem.rd32(int'(hb) + i * 4) !== 32'h0) bad++;
    check(what, 64'(bad), 0);
  endtask
  int tid_next = 16'h1000;
  function automatic int new_tid(); tid_next++; return tid_next; endfunction
  // one synchronous command
  task automatic do_cmd(input int op, input int flags, input logic [63:0] addr, input int len, input logic [31:0] hb,
                        input int expect_status, output int tid);
    int q [$];
    tid = new_tid();
    submit(op, flags, tid, addr, len, hb, expect_status);
    ring();
    q.push_back(tid);
    wait_tids(q, 3_000_000);
  endtask

  // ======================================================================== scenarios
  task automatic s_dod();
    int t; logic [31:0] v;
    grp = "dod";
    br(SHC + SFS_SHC_ID, v);      check("SHC ID", v, SFS_HIF_ID_VALUE);
    br(SHC + SFS_SHC_VERSION, v); check("protocol version", v, SFS_PROTO_VERSION);
    check("capacity published", 64'(cap_lba), 256 * NCH);
    do_cmd(SFS_OP_IDENTIFY, 0, 0, 0, 32'h0000_1000, SFS_ST_SUCCESS, t);
    check("IDENTIFY magic", hmem.rd32(32'h1000), SFS_SYS_ID_VALUE);
    check("IDENTIFY capacity", hmem.rd32(32'h1010), 256 * NCH);
    check("IDENTIFY channels", hmem.rd32(32'h1020), NCH);
    check("IDENTIFY NAND ID", hmem.rd32(32'h1034), 32'h10A1_DA5F);
    fill_host(32'h10000, 0, 4, 1);
    do_cmd(SFS_OP_WRITE, 0, 0, 4, 32'h10000, SFS_ST_SUCCESS, t);
    check("WRITE result0 = blocks", r0_of(t), 4);
    clear_host(32'h20000, 4);
    do_cmd(SFS_OP_READ, 0, 0, 4, 32'h20000, SFS_ST_SUCCESS, t);
    check("READ result0 = blocks", r0_of(t), 4);
    check("READ correctly tagged", 64'(cqe_of[t][96 +: 16]), 64'(t));
    check_host("DoD: data written then read back", 32'h20000, 0, 4, 1);
    if (n_fail == 0) $display("TB DoD: command accepted, NAND model accessed, tagged results returned -- MET");
    else             $display("TB DoD: command accepted, NAND model accessed, tagged results returned -- NOT MET");
  endtask

  task automatic s_concurrency();
    int tids [$], w_tids [$]; int ooo = 0;
    grp = "concurrency";
    // NT writes of 2 blocks each to distinct LBAs, all in flight at once
    for (int i = 0; i < NT && i < HQD - 1; i++) begin
      int t = new_tid();
      fill_host(32'h30000 + 32'(i * 2 * PAGE), 16 + i * 2, 2, 2);
      submit(SFS_OP_WRITE, 0, t, 64'(16 + i * 2), 2, 32'h30000 + 32'(i * 2 * PAGE), SFS_ST_SUCCESS);
      w_tids.push_back(t);
    end
    cpl_order.delete();
    ring();
    wait_tids(w_tids, 5_000_000);
    // mixed: reads of what was written + IDENTIFY + FLUSH, completions may overtake
    for (int i = 0; i < NT - 2 && i < HQD - 3; i++) begin
      int t = new_tid();
      clear_host(32'h50000 + 32'(i * 2 * PAGE), 2);
      submit(SFS_OP_READ, 0, t, 64'(16 + i * 2), 2, 32'h50000 + 32'(i * 2 * PAGE), SFS_ST_SUCCESS);
      tids.push_back(t);
    end
    begin int t = new_tid(); submit(SFS_OP_IDENTIFY, 0, t, 0, 0, 32'h2000, SFS_ST_SUCCESS); tids.push_back(t); end
    begin int t = new_tid(); submit(SFS_OP_FLUSH, 0, t, 0, 0, 0, SFS_ST_SUCCESS); tids.push_back(t); end
    cpl_order.delete();
    ring();
    wait_tids(tids, 5_000_000);
    foreach (cpl_order[i]) if (cpl_order[i] != tids[i]) ooo++;
    $display("TB concurrency: %0d commands in flight, %0d completed out of submission order", tids.size(), ooo);
    check_true("completions overtook each other", ooo > 0);
    for (int i = 0; i < NT - 2 && i < HQD - 3; i++)
      check_host($sformatf("concurrent read %0d", i), 32'h50000 + 32'(i * 2 * PAGE), 16 + i * 2, 2, 2);
  endtask

  task automatic s_invalid();
    int t, t1, t2; int q [$];
    grp = "invalid";
    do_cmd(8'h42, 0, 0, 1, 32'h1000, SFS_ST_INVALID_OPCODE, t);
    do_cmd(SFS_OP_READ, 0, 64'(cap_lba - 1), 2, 32'h1000, SFS_ST_LBA_RANGE, t);
    do_cmd(SFS_OP_WRITE, 0, 0, 17, 32'h1000, SFS_ST_INVALID_FIELD, t);  check("LEN > MDTS err", 64'(err_of(t)), SFS_ERR_LEN_MAX);
    do_cmd(SFS_OP_READ, 0, 0, 0, 32'h1000, SFS_ST_INVALID_FIELD, t);    check("LEN 0 err", 64'(err_of(t)), SFS_ERR_LEN_ZERO);
    do_cmd(SFS_OP_READ, 0, 0, 1, 32'h1001, SFS_ST_INVALID_FIELD, t);    check("host addr err", 64'(err_of(t)), SFS_ERR_HOST_ADDR);
    do_cmd(SFS_OP_ERASE, 1, 0, 1, 0, SFS_ST_ACCESS_DENIED, t);          // physical not enabled
    // transaction-ID conflict with a long command in flight
    t1 = new_tid();
    fill_host(32'h60000, 100, 16, 3);
    submit(SFS_OP_WRITE, 0, t1, 100, 16, 32'h60000, SFS_ST_SUCCESS);
    ring();
    repeat (200) @(posedge clk);
    // second command with the SAME TID while the first is outstanding
    begin
      logic [31:0] w [8];
      w[0] = 32'(SFS_OP_FLUSH) | (32'(t1) << 16); w[1] = 0; w[2] = 0; w[3] = 0; w[4] = 0; w[5] = 0; w[6] = 0; w[7] = 0;
      for (int k = 0; k < 8; k++) bw(SHC + SFS_SHC_SQ_RING + 32'(sq_tail_s * 32 + k * 4), w[k]);
      sq_tail_s = (sq_tail_s + 1) % HQD;
      ring();
    end
    exp_st[t1] = -1;
    q.push_back(t1);
    wait_tids(q, 3_000_000);
    // two completions carry TID t1: the hardware conflict rejection (immediate), then the write itself
    check("conflict rejected by hardware first", 64'(st_of(t1)), SFS_ST_CID_CONFLICT);
    seen[t1] = 0;
    wait_tids(q, 3_000_000);
    check("original write completes", 64'(st_of(t1)), SFS_ST_SUCCESS);
    begin
      int t3; clear_host(32'h70000, 16);
      do_cmd(SFS_OP_READ, 0, 100, 16, 32'h70000, SFS_ST_SUCCESS, t3);
      check_host("16-block write intact after the conflict", 32'h70000, 100, 16, 3);
    end
  endtask

  task automatic s_unmapped();
    int t;
    grp = "unmapped";
    hmem.wr32(32'h8000, 32'hFFFF_FFFF);
    do_cmd(SFS_OP_READ, 0, 64'(cap_lba - 1), 1, 32'h8000, SFS_ST_SUCCESS, t);
    check_zero("never-written LBA reads zeros", 32'h8000, 1);
    do_cmd(SFS_OP_DEALLOCATE, 0, 0, 2, 0, SFS_ST_SUCCESS, t);
    clear_host(32'h8000, 2);
    do_cmd(SFS_OP_READ, 0, 0, 2, 32'h8000, SFS_ST_SUCCESS, t);
    check_zero("deallocated LBAs read zeros", 32'h8000, 2);
    clear_host(32'h8000, 2);
    do_cmd(SFS_OP_READ, 0, 2, 2, 32'h8000, SFS_ST_SUCCESS, t);
    check_host("neighbours untouched", 32'h8000, 2, 2, 1);
  endtask

  task automatic s_ecc();
    int t, row, ch; logic [31:0] p0;
    grp = "ecc";
    fill_host(32'h9000, 40, 1, 7);
    do_cmd(SFS_OP_WRITE, 0, 40, 1, 32'h9000, SFS_ST_SUCCESS, t);
    p0 = pat(40, 0, 7);
    row = -1; ch = 0;
    for (int c = 0; c < NCH && row < 0; c++) begin row = find(c, p0); ch = c; end
    check_true("written page located in the NAND model", row >= 0);
    if (row >= 0 && ECC != 0) begin
      flip(ch, row / PPB, row % PPB, 5 * (SB + CDW / 8) + 1, 4);          // one bit in word 5
      clear_host(32'hA000, 1);
      do_cmd(SFS_OP_READ, 0, 40, 1, 32'hA000, SFS_ST_SUCCESS, t);
      check("corrected bits reported (result1)", r1_of(t), 1);
      check_host("data corrected by page ECC", 32'hA000, 40, 1, 7);
      flip(ch, row / PPB, row % PPB, 9 * (SB + CDW / 8) + 0, 0);          // two bits in word 9
      flip(ch, row / PPB, row % PPB, 9 * (SB + CDW / 8) + 2, 6);
      do_cmd(SFS_OP_READ, 0, 40, 1, 32'hA000, SFS_ST_MEDIA_UNREC, t);
      check("uncorrectable error code", 64'(err_of(t)), SFS_ERR_NAND_ECC_UE);
      // rewrite heals the LBA (new page)
      do_cmd(SFS_OP_WRITE, 0, 40, 1, 32'h9000, SFS_ST_SUCCESS, t);
      clear_host(32'hA000, 1);
      do_cmd(SFS_OP_READ, 0, 40, 1, 32'hA000, SFS_ST_SUCCESS, t);
      check_host("rewritten LBA reads clean", 32'hA000, 40, 1, 7);
    end
  endtask

  task automatic s_backpressure();
    int tids [$]; int n; logic [31:0] v;
    grp = "backpressure";
    bp_pct = 60; lat_max = 8;
    fill_host(32'hB0000, 60, 16, 4);
    begin int t; do_cmd(SFS_OP_WRITE, 0, 60, 16, 32'hB0000, SFS_ST_SUCCESS, t); end
    clear_host(32'hC0000, 16);
    begin int t; do_cmd(SFS_OP_READ, 0, 60, 16, 32'hC0000, SFS_ST_SUCCESS, t); end
    check_host("16 blocks under host-memory back-pressure", 32'hC0000, 60, 16, 4);
    bp_pct = 0; lat_max = 2;
    // full CQ: the host stops reaping; completions back up inside the controller
    bw(SHC + SFS_SHC_INT_CTRL, 32'h0);
    for (int i = 0; i < HQD - 1; i++) begin
      int t = new_tid(); submit(SFS_OP_READ, 0, t, 64'(60 + (i % 16)), 1, 32'hD0000 + 32'(i * PAGE), SFS_ST_SUCCESS);
      tids.push_back(t);
    end
    ring();
    begin   // wait until the CQ holds HQD-1 entries (each read ~3.5k cycles on one channel)
      longint t0 = cyc;
      do begin repeat (2000) @(posedge clk); br(SHC + SFS_SHC_CQ_TAIL, v); end
      while ((v - 32'(cq_head_s) + HQD) % HQD != HQD - 1 && cyc - t0 < 2_000_000);
    end
    check("CQ filled to capacity", 64'((v - 32'(cq_head_s) + HQD) % HQD), HQD - 1);
    for (int i = 0; i < 4; i++) begin
      int t = new_tid(); submit(SFS_OP_READ, 0, t, 64'(60 + i), 1, 32'hD0000 + 32'(i * PAGE), SFS_ST_SUCCESS);
      tids.push_back(t);
    end
    ring();
    repeat (40000) @(posedge clk);
    bw(SHC + SFS_SHC_INT_CTRL, 32'h3);
    wait_tids(tids, 5_000_000);
    check("all completions delivered after the CQ drained", 64'(tids.size()), HQD + 3);
    begin
      int t; do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
      check_true("CQ-full stall cycles counted", hmem.rd32(32'hE000 + 31 * 4) > 0);
    end
  endtask

  task automatic s_ctrlreset();
    int tids [$]; logic [31:0] v; longint t0; int n;
    grp = "ctrlreset";
    for (int i = 0; i < 4; i++) begin
      int t = new_tid(); fill_host(32'h40000 + 32'(i * 16 * PAGE), 120 + i * 16, 16, 5);
      submit(SFS_OP_WRITE, 0, t, 64'(120 + i * 16), 16, 32'h40000 + 32'(i * 16 * PAGE), -1);
      tids.push_back(t);
    end
    ring();
    repeat (3000) @(posedge clk);
    bw(SHC + SFS_SHC_CTRL, 32'h0);                           // controller reset with commands in flight
    t0 = cyc;
    do br(SHC + SFS_SHC_STATUS, v); while ((v[0] || v[5]) && cyc - t0 < 2_000_000);
    check("reset completed: RDY = 0", 64'(v[0]), 0);
    check("reset completed: not RESETTING", 64'(v[5]), 0);
    br(SHC + SFS_SHC_CQ_TAIL, v); check("queues cleared", v, 0);
    foreach (tids[i]) seen[tids[i]] = 1;                     // aborted commands are not reported after a reset
    enable_ctrl();
    begin
      int t; do_cmd(SFS_OP_IDENTIFY, 0, 0, 0, 32'h3000, SFS_ST_SUCCESS, t);
      check("controller usable after reset", hmem.rd32(32'h3000), SFS_SYS_ID_VALUE);
      clear_host(32'h20000, 4);
      do_cmd(SFS_OP_READ, 0, 0 + 2, 2, 32'h20000, SFS_ST_SUCCESS, t);
      check_host("earlier data survives a controller reset", 32'h20000, 2, 2, 1);
    end
  endtask

  task automatic s_plp();
    int tids [$], q [$]; logic [31:0] v; longint t0; int t;
    grp = "plp";
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    v = hmem.rd32(32'hE000 + 12 * 4);                       // checkpoints so far
    for (int i = 0; i < 3; i++) begin
      int tt = new_tid(); fill_host(32'h90000 + 32'(i * 4 * PAGE), 180 + i * 4, 4, 6);
      submit(SFS_OP_WRITE, 0, tt, 64'(180 + i * 4), 4, 32'h90000 + 32'(i * 4 * PAGE), SFS_ST_SUCCESS);
      tids.push_back(tt);
    end
    ring();
    repeat (500) @(posedge clk);
    pwr_fail_n = 0;                                         // power-fail pin (asynchronous)
    wait_tids(tids, 3_000_000);                             // commands already accepted drain normally
    begin
      int tt = new_tid(); submit(SFS_OP_WRITE, 0, tt, 200, 1, 32'h90000, SFS_ST_ABORT_PWR_LOSS);
      ring(); q.push_back(tt); wait_tids(q, 1_000_000);
      check("refused with QUIESCED", 64'(err_of(tt)), SFS_ERR_QUIESCED);
    end
    br(SHC + SFS_SHC_STATUS, v); check("host sees PLP", 64'(v[4]), 1);
    t0 = cyc;
    while (wp_n[0] && cyc - t0 < 2_000_000) @(posedge clk);
    for (int c = 0; c < NCH; c++) check("NAND WP# asserted after FW_SAFE", 64'(wp_n[c]), 0);
    pwr_fail_n = 1;
    t0 = cyc;
    while (!wp_n[0] && cyc - t0 < 2_000_000) @(posedge clk);
    check("WP# released after power restore", 64'(wp_n[0]), 1);
    do br(SHC + SFS_SHC_STATUS, v); while (v[4] && cyc - t0 < 2_000_000);
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    check("PLP event counted", hmem.rd32(32'hE000 + 10 * 4), 1);
    check_true("PLP checkpoint written", hmem.rd32(32'hE000 + 11 * 4) > 0);
    clear_host(32'hA0000, 12);
    do_cmd(SFS_OP_READ, 0, 180, 12, 32'hA0000, SFS_ST_SUCCESS, t);
    check_host("data written across the power event", 32'hA0000, 180, 12, 6);
  endtask

  task automatic s_security();
    logic [31:0] v; logic e;
    grp = "security";
    bar_access(1, SFS_SYS_BASE + SFS_SYS_SEC_CTRL, 32'h1, v, e);   check("host write to storage page refused", 64'(e), 1);
    bar_access(0, SFS_CMD_BASE + SFS_CMD_FWQ_HEAD, 0, v, e);       check("host read of storage page refused", 64'(e), 1);
    bar_access(1, CC_IMEM_BASE + 32'h100, 32'h0, v, e);            check("host write to IMEM refused (CC lock)", 64'(e), 1);
    bar_access(0, CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, 0, v, e); check("host can still read boot status", 64'(e), 0);
    bar_access(0, SHC + 32'h0F00, 0, v, e);                         check("unmapped SHC offset", 64'(e), 1);
    bar_access(0, 32'hA000_0000, 0, v, e);                          check("unmapped BAR address", 64'(e), 1);
    bar_access(1, SHC + SFS_SHC_SQ_TAIL, 32'(HQD + 5), v, e);       // invalid doorbell value
    br(SHC + SFS_SHC_STATUS, v); check("doorbell error flagged", 64'(v[8]), 1);
    bw(SHC + SFS_SHC_INT_STATUS, 32'h2);
  endtask

  task automatic s_flush_phys();
    int t; logic [31:0] seq0;
    grp = "flush_phys";
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    seq0 = hmem.rd32(32'hE000 + 11 * 4);
    do_cmd(SFS_OP_FLUSH, 0, 0, 0, 0, SFS_ST_SUCCESS, t);
    fill_host(32'h9800, 41, 1, 8);
    do_cmd(SFS_OP_WRITE, SFS_SQE_FUA_FLAG, 41, 1, 32'h9800, SFS_ST_SUCCESS, t);
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    check("FLUSH + FUA committed 2 checkpoints", hmem.rd32(32'hE000 + 11 * 4), seq0 + 2);
    // physical addressing: enabled by the vendor mailbox command
    mbox_cmd(32'h51, 1, 200000);
    do_cmd(SFS_OP_ERASE, 1, 64'((0 << 24) | (60 << 8)), 1, 0, SFS_ST_SUCCESS, t);
    fill_host(32'h9800, 250, 1, 9);
    do_cmd(SFS_OP_WRITE, 1, 64'((0 << 24) | (60 << 8) | 3), 1, 32'h9800, SFS_ST_SUCCESS, t);
    clear_host(32'h9C00, 1);
    do_cmd(SFS_OP_READ, 1, 64'((0 << 24) | (60 << 8) | 3), 1, 32'h9C00, SFS_ST_SUCCESS, t);
    check_host("physical write/read", 32'h9C00, 250, 1, 9);
    check("physical page in NAND", 64'(g_nand[0].flash.find_page(pat(250, 0, 9), 0)), 60 * PPB + 3);
    do_cmd(SFS_OP_READ, 1, 64'((0 << 24) | (99 << 8)), 1, 32'h9C00, SFS_ST_INVALID_FIELD, t);
    mbox_cmd(32'h51, 0, 200000);
    do_cmd(SFS_OP_ERASE, 1, 64'((0 << 24) | (60 << 8)), 1, 0, SFS_ST_ACCESS_DENIED, t);
  endtask

  task automatic s_log_shutdown();
    int t; logic [31:0] v; longint t0;
    grp = "status";
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    check("log magic", hmem.rd32(32'hE000), 32'h474F_4C53);
    check_true("log: commands", hmem.rd32(32'hE000 + 4) >= 3);
    check_true("log: FTL writes", hmem.rd32(32'hE000 + 3 * 4) > 0);
    check("log: firmware errors", hmem.rd32(32'hE000 + 26 * 4), 0);
    if (ECC != 0 && scenario == "full") begin
      check_true("log: NAND corrected", hmem.rd32(32'hE000 + 6 * 4) >= 1);
      check_true("log: NAND uncorrectable", hmem.rd32(32'hE000 + 7 * 4) >= 1);
    end
    $display("TB GET_LOG: cmds=%0d errs=%0d writes=%0d reads=%0d nandCE=%0d nandUE=%0d ckpt_seq=%0d dma_bytes=%0d lat_max=%0d",
             hmem.rd32(32'hE000 + 4), hmem.rd32(32'hE000 + 8), hmem.rd32(32'hE000 + 12), hmem.rd32(32'hE000 + 16),
             hmem.rd32(32'hE000 + 24), hmem.rd32(32'hE000 + 28), hmem.rd32(32'hE000 + 44), hmem.rd32(32'hE000 + 76),
             hmem.rd32(32'hE000 + 92));
    bw(SHC + SFS_SHC_CTRL, 32'h3);                           // shutdown request (EN kept)
    t0 = cyc;
    do br(SHC + SFS_SHC_STATUS, v); while (v[3:2] != 2'd2 && cyc - t0 < 2_000_000);
    check("shutdown complete (SHST = 2)", 64'(v[3:2]), 2);
  endtask

  // ---------------------------------------------------------------- model access
  function automatic int find(input int c, input logic [31:0] p);
    case (c)
      0: return g_nand[0].flash.find_page(p, 0);
`ifdef SFS_MULTI
      1: return g_nand[1].flash.find_page(p, 0);
      2: return g_nand[2].flash.find_page(p, 0);
      3: return g_nand[3].flash.find_page(p, 0);
`endif
      default: return -1;
    endcase
  endfunction
  task automatic flip(input int c, input int blk, input int pg, input int off, input int b);
    case (c)
      0: g_nand[0].flash.flip_bit(blk, pg, off, b);
`ifdef SFS_MULTI
      1: g_nand[1].flash.flip_bit(blk, pg, off, b);
      2: g_nand[2].flash.flip_bit(blk, pg, off, b);
      3: g_nand[3].flash.flip_bit(blk, pg, off, b);
`endif
      default: ;
    endcase
  endtask

  // ---------------------------------------------------------------- main
  initial begin
    longint tmo;
    if (!$value$plusargs("scenario=%s", scenario)) scenario = "full";
    $display("tb_storage_soc: config %s scenario %s  NCH=%0d CDW=%0d BUF=%0d DW=%0d TAGS=%0d ECC=%0d RAS=%0d",
             `SFS_CFG_NAME, scenario, NCH, CDW, BUFB, DW, NT, ECC, RAS);
    repeat (10) @(posedge clk);
    rst_n = 1'b1;
    boot();
    grp = "enable"; enable_ctrl();
    s_dod();
    if (scenario == "full") begin
      s_concurrency();
      s_invalid();
      s_unmapped();
      s_ecc();
      s_backpressure();
      s_ctrlreset();
      s_plp();
      s_security();
      s_flush_phys();
    end
    s_log_shutdown();
    // end of test: the firmware reports through the ControlCore test port
    grp = "finish";
    mbox_cmd(CC_MBOX_CMD_SHUTDOWN, 32'(n_fail), 2_000_000);
    repeat (50) @(posedge clk);
    check("firmware TEST_CTRL done", 64'(test_done), 1);
    check("firmware TEST_CTRL fail", 64'(test_fail), 0);
    begin : flash_checks
      int pe, te;
      pe = g_nand[0].flash.n_proto_err; te = g_nand[0].flash.n_timing_err;
      check("NAND protocol errors (ch0)", 64'(pe), 0);
      check("NAND timing errors (ch0)", 64'(te), 0);
    end
    $display("tb_storage_soc %s %s: %0d checks, %0d failures, %0d cycles -> %s", `SFS_CFG_NAME, scenario,
             n_pass + n_fail, n_fail, cyc, (n_fail == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin
    longint tmo;
    if (!$value$plusargs("timeout=%d", tmo)) tmo = 60_000_000;
    while (cyc < tmo) @(posedge clk);
    $display("tb_storage_soc %s: TIMEOUT at cycle %0d (group %s) -> FAIL", `SFS_CFG_NAME, cyc, grp);
    $finish;
  end
endmodule

`default_nettype wire
