// =============================================================================
// SilicaFlux StorageCore :: tb_sfs_subsys -- storage subsystem testbench (no CPU)
//
// DUT: sfs_storage_subsys (+ NAND flash model per channel, host-memory model).
// The testbench plays three roles through the subsystem's real ports:
//   HOST      : SHC BAR (registers, SQ/CQ rings, doorbells) + host memory
//   FW-BFM    : the ControlCore accelerator register port (pages 10..14) --
//               a SIMULATION HOST standing in for the firmware, used for fast,
//               targeted tests.  The real firmware on the real RV32IM CPU is
//               exercised by tb/soc/tb_storage_soc.sv.
//   CC-EXT    : the ControlCore EXT data port (storage fabric master m0)
// Groups (each prints PASS/FAIL counts; +test=<name> runs one group):
//   regs nand ecc dma hostq invalid bp ctrlreset plp bufecc fabric irq e2e
// Config: compile with +define+SFS_CFG_<MIN1CH|RESEARCH4CH|NOECC1CH>.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "sfs_configs.svh"

module tb_sfs_subsys;
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;

  localparam int NCH  = `SFS_P_NUM_NAND_CHANNELS;
  localparam int CDW  = `SFS_P_CHANNEL_DATA_WIDTH;
  localparam int BUFB = `SFS_P_BUFFER_SIZE_BYTES;
  localparam int DW   = `SFS_P_DMA_DATA_WIDTH;
  localparam int AWID = `SFS_P_ADDRESS_WIDTH;
  localparam int NT   = `SFS_P_CMD_QUEUE_DEPTH;
  localparam int ECC  = `SFS_P_ENABLE_ECC;
  localparam int RAS  = `SFS_P_ENABLE_RAS;
  localparam int PAGE = `SFS_P_NAND_PAGE_BYTES;
  localparam int SB   = DW / 8;
  localparam int HQD  = (2 * NT > 64) ? 64 : 2 * NT;
  localparam int PPB  = 16;
  localparam int RAW_PAGE = PAGE * 3 / 2;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT signals
  logic        x_req_valid = 0, x_req_write = 0, x_rsp_valid, x_req_ready, x_rsp_error;
  logic [31:0] x_req_addr = 0, x_req_wdata = 0, x_rsp_rdata;
  logic [3:0]  x_req_wstrb = 4'hF;
  logic        rb_sel = 0, rb_we = 0, rb_err;
  logic [15:0] rb_addr = 0;
  logic [31:0] rb_wdata = 0, rb_rdata;
  logic        s_req_valid = 0, s_req_write = 0, s_req_ready, s_rsp_valid, s_rsp_error;
  logic [31:0] s_req_addr = 0, s_req_wdata = 0, s_rsp_rdata;
  logic [3:0]  s_req_wstrb = 4'hF;
  logic        host_irq;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr;
  logic [DW-1:0] hm_req_wdata, hm_rsp_rdata;
  logic [SB-1:0] hm_req_wstrb;
  logic [NCH-1:0] ce_n, cle, ale, we_n, re_n, wp_n, dq_oe, rb_n;
  logic [NCH*CDW-1:0] dq_o, dq_i;
  logic        pwr_fail_n = 1'b1, sec_viol = 1'b0;
  logic        mgmt_lock, irq_io, irq_evt, busy_nand, busy_io, ext_warn, ext_fatal;
  int          bp_pct = 0, lat_max = 2;

  sfs_storage_subsys #(
    .NUM_NAND_CHANNELS(NCH), .CHANNEL_DATA_WIDTH(CDW), .BUFFER_SIZE_BYTES(BUFB), .DMA_DATA_WIDTH(DW),
    .ADDRESS_WIDTH(AWID), .CMD_QUEUE_DEPTH(NT), .ENABLE_ECC(ECC), .ENABLE_RAS(RAS), .NAND_PAGE_BYTES(PAGE)
  ) dut (
    .clk, .rst_n,
    .x_req_valid, .x_req_ready, .x_req_write, .x_req_addr, .x_req_wdata, .x_req_wstrb,
    .x_rsp_valid, .x_rsp_ready(1'b1), .x_rsp_rdata, .x_rsp_error,
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready(1'b1), .s_rsp_rdata, .s_rsp_error, .host_irq,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .nand_ce_n(ce_n), .nand_cle(cle), .nand_ale(ale), .nand_we_n(we_n), .nand_re_n(re_n), .nand_wp_n(wp_n),
    .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(dq_i), .nand_rb_n(rb_n),
    .pwr_fail_ni(pwr_fail_n), .ev_sec_viol(sec_viol), .mgmt_lock,
    .irq_io, .irq_evt, .busy_nand, .busy_io, .ext_warn, .ext_fatal
  );

  sfs_tb_hostmem #(.DW(DW), .SIZE(1 << 20)) hmem (
    .clk, .rst_n, .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write),
    .req_addr(hm_req_addr), .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid),
    .rsp_ready(hm_rsp_ready), .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error), .bp_pct, .lat_max
  );

  genvar gc;
  for (gc = 0; gc < NCH; gc++) begin : g_nand
    wire [CDW-1:0] dq;
    assign dq = dq_oe[gc] ? dq_o[gc*CDW +: CDW] : {CDW{1'bz}};
    assign dq_i[gc*CDW +: CDW] = dq;
    sfs_nand_flash_model #(.DQW(CDW), .RAW_PAGE(RAW_PAGE), .PAGES_PER_BLOCK(PPB), .BLOCKS(64),
                           .CH(gc)) flash (
      .ce_n(ce_n[gc]), .cle(cle[gc]), .ale(ale[gc]), .we_n(we_n[gc]), .re_n(re_n[gc]), .wp_n(wp_n[gc]),
      .dq, .rb_n(rb_n[gc])
    );
  end

  // ---------------------------------------------------------------- scoreboard
  int n_pass = 0, n_fail = 0;
  string grp = "";
  task automatic check(input string what, input logic [63:0] got, input logic [63:0] exp);
    if (got === exp) n_pass++;
    else begin
      n_fail++;
      $display("[%0t] FAIL %s/%s: got 0x%0h expected 0x%0h", $time, grp, what, got, exp);
    end
  endtask
  task automatic check_true(input string what, input bit c);
    check(what, 64'(c), 64'd1);
  endtask

  // ---------------------------------------------------------------- port BFMs (drive at negedge, sample before posedge)
  task automatic x_access(input bit wr, input logic [31:0] a, input logic [31:0] wd, input logic [3:0] be,
                          output logic [31:0] rd, output logic err);
    @(negedge clk);
    x_req_valid = 1; x_req_write = wr; x_req_addr = a; x_req_wdata = wd; x_req_wstrb = be;
    #4; while (!x_req_ready) begin @(negedge clk); #4; end
    @(posedge clk); #1;
    x_req_valid = 0;
    @(negedge clk); #4; while (!x_rsp_valid) begin @(negedge clk); #4; end
    rd = x_rsp_rdata; err = x_rsp_error;
    @(posedge clk); #1;
  endtask
  task automatic xw(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; logic e;
    x_access(1, a, d, 4'hF, r, e);
    if (e) begin n_fail++; $display("[%0t] FAIL x write error @%08h", $time, a); end
  endtask
  task automatic xr(input logic [31:0] a, output logic [31:0] d);
    logic e;
    x_access(0, a, 0, 4'hF, d, e);
    if (e) begin n_fail++; $display("[%0t] FAIL x read error @%08h", $time, a); end
  endtask

  task automatic h_access(input bit wr, input logic [31:0] a, input logic [31:0] wd, input logic [3:0] be,
                          output logic [31:0] rd, output logic err);
    @(negedge clk);
    s_req_valid = 1; s_req_write = wr; s_req_addr = a; s_req_wdata = wd; s_req_wstrb = be;
    #4; while (!s_req_ready) begin @(negedge clk); #4; end
    @(posedge clk); #1;
    s_req_valid = 0;
    @(negedge clk); #4; while (!s_rsp_valid) begin @(negedge clk); #4; end
    rd = s_rsp_rdata; err = s_rsp_error;
    @(posedge clk); #1;
  endtask
  task automatic hw(input logic [15:0] off, input logic [31:0] d);
    logic [31:0] r; logic e;
    h_access(1, 32'(off), d, 4'hF, r, e);
    if (e) begin n_fail++; $display("[%0t] FAIL host write error @%04h", $time, off); end
  endtask
  function automatic logic [31:0] dummy(input int x); return 32'(x); endfunction
  task automatic hr(input logic [15:0] off, output logic [31:0] d);
    logic e;
    h_access(0, 32'(off), 0, 4'hF, d, e);
    if (e) begin n_fail++; $display("[%0t] FAIL host read error @%04h", $time, off); end
  endtask

  task automatic rb_access(input bit wr, input int page, input logic [11:0] off, input logic [31:0] wd,
                           output logic [31:0] rd, output logic err);
    @(negedge clk);
    rb_sel = 1; rb_we = wr; rb_addr = {1'b1, 3'(page - 8), off}; rb_wdata = wd;
    #2; rd = rb_rdata; err = rb_err;
    @(posedge clk); #1;
    rb_sel = 0; rb_we = 0;
  endtask
  task automatic fw_wr(input int page, input logic [11:0] off, input logic [31:0] d);
    logic [31:0] r; logic e;
    rb_access(1, page, off, d, r, e);
    if (e) begin n_fail++; $display("[%0t] FAIL fw write error page %0d off %03h", $time, page, off); end
  endtask
  task automatic fw_rd(input int page, input logic [11:0] off, output logic [31:0] d);
    logic e;
    rb_access(0, page, off, 0, d, e);
    if (e) begin n_fail++; $display("[%0t] FAIL fw read error page %0d off %03h", $time, page, off); end
  endtask

  // ---------------------------------------------------------------- storage helpers (firmware BFM)
  function automatic logic [11:0] nreg(input int ch, input logic [11:0] r);
    return 12'(ch * SFS_NAND_CH_STRIDE) + r;
  endfunction
  task automatic nand_op(input int ch, input int op, input int row, input int col, input logic [31:0] bufa,
                         input int len, input bit ecc, input int tag,
                         output int st, output int sr, output logic [31:0] i0, output logic [31:0] i1);
    logic [31:0] v;
    fw_wr(SFS_PG_NAND, nreg(ch, SFS_NAND_OP_ROW), 32'(row));
    fw_wr(SFS_PG_NAND, nreg(ch, SFS_NAND_OP_COL), 32'(col));
    fw_wr(SFS_PG_NAND, nreg(ch, SFS_NAND_OP_BUF), bufa);
    fw_wr(SFS_PG_NAND, nreg(ch, SFS_NAND_OP_LEN), 32'(len));
    fw_wr(SFS_PG_NAND, nreg(ch, SFS_NAND_OP_SUBMIT), 32'(op) | (32'(ecc) << 8) | (32'(tag) << 16));
    do fw_rd(SFS_PG_NAND, nreg(ch, SFS_NAND_CPL_HEAD), v); while (!v[31]);
    check("nand cpl tag", 64'(v[23:16]), 64'(tag));
    st = int'(v[15:8]); sr = int'(v[7:0]);
    fw_rd(SFS_PG_NAND, nreg(ch, SFS_NAND_CPL_INFO0), i0);
    fw_rd(SFS_PG_NAND, nreg(ch, SFS_NAND_CPL_INFO1), i1);
    fw_wr(SFS_PG_NAND, nreg(ch, SFS_NAND_CPL_POP), 0);
  endtask
  task automatic dma_xfer(input logic [31:0] src, input logic [31:0] dst, input int len, input int tag,
                          output int st, output logic [31:0] info);
    logic [31:0] v;
    fw_wr(SFS_PG_DMA, SFS_DMA_SRC, src);
    fw_wr(SFS_PG_DMA, SFS_DMA_DST, dst);
    fw_wr(SFS_PG_DMA, SFS_DMA_LEN, 32'(len));
    fw_wr(SFS_PG_DMA, SFS_DMA_SUBMIT, 32'(tag));
    do fw_rd(SFS_PG_DMA, SFS_DMA_CPL_HEAD, v); while (!v[31]);
    check("dma cpl tag", 64'(v[23:16]), 64'(tag));
    st = int'(v[15:8]);
    fw_rd(SFS_PG_DMA, SFS_DMA_CPL_INFO, info);
    fw_wr(SFS_PG_DMA, SFS_DMA_CPL_POP, 0);
  endtask
  task automatic buf_fill(input logic [31:0] off, input int bytes, input logic [31:0] seed);
    for (int i = 0; i < bytes; i += 4) xw(SFS_BUF_BASE + off + 32'(i), seed ^ (32'(i) * 32'h9E37_79B9));
  endtask
  task automatic buf_check(input string what, input logic [31:0] off, input int bytes, input logic [31:0] seed);
    logic [31:0] v; int bad = 0;
    for (int i = 0; i < bytes; i += 4) begin
      xr(SFS_BUF_BASE + off + 32'(i), v);
      if (v !== (seed ^ (32'(i) * 32'h9E37_79B9))) begin
        if (bad < 4) $display("[%0t]   %s word %0d: %08h != %08h", $time, what, i / 4, v, seed ^ (32'(i) * 32'h9E37_79B9));
        bad++;
      end
    end
    check(what, 64'(bad), 0);
  endtask
  task automatic nand_init(input int ch);
    int st, sr; logic [31:0] i0, i1;
    fw_wr(SFS_PG_NAND, nreg(ch, SFS_NAND_CH_CTRL), 32'h7);         // WP_N, CE_EN, IRQ_EN
    nand_op(ch, SFS_NOP_RESET, 0, 0, 0, 0, 0, 8'hA0, st, sr, i0, i1);
    check("reset status", 64'(st), SFS_NST_OK);
  endtask

  // ---------------------------------------------------------------- host-queue helpers
  int sq_tail_s, cq_head_s; bit phase_s;
  task automatic host_enable();
    logic [31:0] v;
    hw(SFS_SHC_CTRL, 32'h1);
    fw_rd(SFS_PG_HIF, SFS_HIF_EVT_STATUS, v);
    check_true("EN_RISE event", v[SFS_HEVT_EN_RISE]);
    fw_wr(SFS_PG_HIF, SFS_HIF_EVT_STATUS, 32'h1F);
    fw_wr(SFS_PG_HIF, SFS_HIF_CTRL, 32'h1);                         // firmware: RDY
    hr(SFS_SHC_STATUS, v);
    check_true("RDY", v[0]);
    sq_tail_s = 0; cq_head_s = 0; phase_s = 1;
  endtask
  task automatic sq_put(input logic [255:0] e);
    for (int w = 0; w < 8; w++) hw(16'(SFS_SHC_SQ_RING + sq_tail_s * 32 + w * 4), e[w*32 +: 32]);
    sq_tail_s = (sq_tail_s + 1) % HQD;
  endtask
  task automatic sq_ring();
    hw(SFS_SHC_SQ_TAIL, 32'(sq_tail_s));
  endtask
  task automatic mk_sqe(output logic [255:0] e, input int op, input int flags, input int tid,
                        input logic [63:0] addr, input int len, input logic [31:0] hbuf);
    e = '0;
    e[0 +: 32] = 32'(op) | (32'(flags) << 8) | (32'(tid) << 16);
    e[64 +: 64] = addr; e[128 +: 32] = 32'(len); e[160 +: 32] = hbuf;
  endtask
  // wait for one CQ entry (phase tag), consume it
  task automatic cq_get(output logic [127:0] c, input int tmo_cycles);
    logic [31:0] w3; int t;
    t = 0;
    hr(16'(SFS_SHC_CQ_RING + cq_head_s * 16 + 12), w3);
    while (w3[16] != phase_s) begin
      t++;
      if (t > tmo_cycles) begin
        n_fail++; $display("[%0t] FAIL %s: CQ timeout", $time, grp);
        w3 = {16'hFFFF, 15'h7FFF, phase_s};      // leave the loop with an impossible entry
      end else hr(16'(SFS_SHC_CQ_RING + cq_head_s * 16 + 12), w3);
    end
    c = '0;
    if (t <= tmo_cycles) begin
      for (int w = 0; w < 3; w++) begin
        logic [31:0] tmp;
        hr(16'(SFS_SHC_CQ_RING + cq_head_s * 16 + w * 4), tmp);
        c[w*32 +: 32] = tmp;
      end
      cq_head_s = (cq_head_s + 1) % HQD;
      if (cq_head_s == 0) phase_s = !phase_s;
      hw(SFS_SHC_CQ_HEAD, 32'(cq_head_s));
    end
    c[96 +: 32] = w3;
  endtask
  // firmware BFM: take the next command
  task automatic fw_take(output int tag, output logic [255:0] e);
    logic [31:0] v;
    do fw_rd(SFS_PG_CMD, SFS_CMD_FWQ_HEAD, v); while (!v[31]);
    tag = int'(v[7:0]);
    for (int w = 0; w < 8; w++) begin
      fw_rd(SFS_PG_CMD, 12'(SFS_CMD_TAG_WIN + tag * 32 + w * 4), v);
      e[w*32 +: 32] = v;
    end
    fw_wr(SFS_PG_CMD, SFS_CMD_FWQ_POP, 0);
  endtask
  task automatic fw_done(input int tag, input int st, input int err, input logic [31:0] r0, input logic [31:0] r1);
    fw_wr(SFS_PG_CMD, SFS_CMD_CPL_RESULT0, r0);
    fw_wr(SFS_PG_CMD, SFS_CMD_CPL_RESULT1, r1);
    fw_wr(SFS_PG_CMD, SFS_CMD_CPL_POST, 32'(tag) | (32'(st) << 8) | (32'(err) << 16));
  endtask
  // submit one command and expect a hardware rejection
  task automatic expect_reject(input string what, input logic [255:0] e, input int st, input int err);
    logic [127:0] c;
    sq_put(e); sq_ring();
    cq_get(c, 200);
    check({what, " tid"}, 64'(c[96 +: 16]), 64'(e[16 +: 16]));
    check({what, " status"}, 64'(c[113 +: 7]), 64'(st));
    check({what, " err"}, 64'(c[120 +: 8]), 64'(err));
  endtask

  // ---------------------------------------------------------------- page layout helper
  function automatic int raw_off(input int word, input int byte_in_word);
    return word * (SB + ((ECC != 0) ? CDW / 8 : 0)) + byte_in_word;
  endfunction

  // ======================================================================== tests
  task automatic t_regs();
    logic [31:0] v; logic e;
    grp = "regs";
    fw_rd(SFS_PG_SYS, SFS_SYS_ID, v);            check("SYS ID", v, SFS_SYS_ID_VALUE);
    fw_rd(SFS_PG_SYS, SFS_SYS_PROTO_VERSION, v); check("proto version", v, SFS_PROTO_VERSION);
    fw_rd(SFS_PG_SYS, SFS_SYS_MAP_VERSION, v);   check("map version", v, SFS_MAP_VERSION);
    fw_rd(SFS_PG_SYS, SFS_SYS_CONFIG0, v);
    check("cfg channels", 64'(v[3:0]), NCH); check("cfg cdw", 64'(v[11:8]), CDW / 8);
    check("cfg dw", 64'(v[19:12]), SB); check("cfg tags", 64'(v[27:20]), NT);
    check("cfg ecc", 64'(v[28]), ECC != 0); check("cfg ras", 64'(v[29]), RAS != 0);
    fw_rd(SFS_PG_SYS, SFS_SYS_CONFIG1, v);       check("cfg buffer", v, BUFB);
    fw_rd(SFS_PG_SYS, SFS_SYS_CONFIG2, v);       check("cfg page", 64'(v[15:0]), PAGE);
    check("cfg addr width", 64'(v[23:16]), AWID);
    // wait for buffer init (ECC SRAM initialises every word after reset)
    do fw_rd(SFS_PG_SYS, SFS_SYS_READY, v); while (!v[0]);
    check("ready: nand idle", 64'(v[1]), 1); check("ready: dma idle", 64'(v[2]), 1);
    // RW / RO / invalid offsets / absent pages
    fw_wr(SFS_PG_SYS, SFS_SYS_IRQ_EN_EVT, 32'h2A); fw_rd(SFS_PG_SYS, SFS_SYS_IRQ_EN_EVT, v); check("RW irq_en_evt", v, 32'h2A);
    fw_wr(SFS_PG_SYS, SFS_SYS_IRQ_EN_EVT, 0);
    rb_access(1, SFS_PG_SYS, SFS_SYS_ID, 32'h0, v, e);        check("RO write refused", 64'(e), 1);
    rb_access(0, SFS_PG_SYS, 12'h3FC, 0, v, e);                check("unmapped SYS offset", 64'(e), 1);
    rb_access(0, SFS_PG_CMD, 12'h0FC, 0, v, e);                check("unmapped CMD offset", 64'(e), 1);
    rb_access(0, 8, 12'h000, 0, v, e);                         check("absent page 8", 64'(e), 1);
    rb_access(0, 9, 12'h000, 0, v, e);                         check("absent page 9", 64'(e), 1);
    rb_access(0, 15, 12'h000, 0, v, e);                        check("absent page 15", 64'(e), 1);
    rb_access(0, SFS_PG_NAND, nreg(NCH, SFS_NAND_CH_INFO), 0, v, e); check("absent NAND channel", 64'(e), 1);
    for (int c = 0; c < NCH; c++) begin
      fw_rd(SFS_PG_NAND, nreg(c, SFS_NAND_CH_INFO), v);
      check("CH_INFO channel", 64'(v[3:0]), c); check("CH_INFO page", 64'(v[31:16]), PAGE);
    end
    fw_rd(SFS_PG_DMA, SFS_DMA_INFO, v);           check("DMA width", 64'(v[23:16]), SB);
    fw_rd(SFS_PG_CMD, SFS_CMD_INFO, v);           check("CMD depth", 64'(v[7:0]), NT);
    fw_rd(SFS_PG_CMD, SFS_CMD_MDTS, v);           check("MDTS reset", v, 16);
    // host BAR
    hr(SFS_SHC_ID, v);                            check("SHC ID", v, SFS_HIF_ID_VALUE);
    hr(SFS_SHC_CAP, v);                           check("CAP SQ", 64'(v[7:0]), HQD); check("CAP tags", 64'(v[23:16]), NT);
    h_access(1, SFS_SHC_ID, 0, 4'hF, v, e);       check("host RO write refused", 64'(e), 1);
    h_access(0, 32'h0FF0, 0, 4'hF, v, e);         check("host unmapped", 64'(e), 1);
    h_access(1, SFS_SHC_CTRL, 0, 4'h1, v, e);     check("host sub-word write refused", 64'(e), 1);
    h_access(1, 16'(SFS_SHC_CQ_RING), 0, 4'hF, v, e); check("host CQ ring write refused", 64'(e), 1);
    // CC EXT -> buffer SRAM, byte strobes
    xw(SFS_BUF_BASE + 32'h10, 32'h1122_3344);
    x_access(1, SFS_BUF_BASE + 32'h10, 32'hAABB_CCDD, 4'b0100, v, e);
    xr(SFS_BUF_BASE + 32'h10, v);                 check("buffer byte strobe", v, 32'h11BB_3344);
  endtask

  task automatic t_nand();
    int st, sr; logic [31:0] i0, i1;
    grp = "nand";
    for (int c = 0; c < NCH; c++) begin
      nand_init(c);
      nand_op(c, SFS_NOP_READ_ID, 0, 0, 0, 0, 0, 1, st, sr, i0, i1);
      check("READ_ID ok", 64'(st), SFS_NST_OK);
      check("READ_ID bytes 0..3", i0, 32'h10A1_DA5F); check("READ_ID byte 4", i1, 32'h00);
      nand_op(c, SFS_NOP_READ_STATUS, 0, 0, 0, 0, 0, 2, st, sr, i0, i1);
      check("READ_STATUS byte", 64'(sr), 8'hE0);
      nand_op(c, SFS_NOP_ERASE, 3 * PPB, 0, 0, 0, 0, 3, st, sr, i0, i1);
      check("ERASE ok", 64'(st), SFS_NST_OK);
      check("ERASE count", g_nand_erases(c), 1);
      buf_fill(32'h400, PAGE, 32'hC0DE_0000 + 32'(c));
      nand_op(c, SFS_NOP_PROGRAM, 3 * PPB + 1, 0, SFS_BUF_BASE + 32'h400, PAGE, 1, 4, st, sr, i0, i1);
      check("PROGRAM ok", 64'(st), SFS_NST_OK);
      buf_fill(32'h400, PAGE, 32'h0);                       // scrub the buffer
      nand_op(c, SFS_NOP_READ_PAGE, 3 * PPB + 1, 0, SFS_BUF_BASE + 32'h800, PAGE, 1, 5, st, sr, i0, i1);
      check("READ_PAGE ok", 64'(st), SFS_NST_OK);
      buf_check("READ_PAGE data", 32'h800, PAGE, 32'hC0DE_0000 + 32'(c));
      // partial-page read (64 bytes, OP_LEN)
      nand_op(c, SFS_NOP_READ_PAGE, 3 * PPB + 1, 0, SFS_BUF_BASE + 32'hC00, 64, 1, 6, st, sr, i0, i1);
      buf_check("partial READ_PAGE", 32'hC00, 64, 32'hC0DE_0000 + 32'(c));
      // write protect: program refused without touching the device
      fw_wr(SFS_PG_NAND, nreg(c, SFS_NAND_CH_CTRL), 32'h6);
      nand_op(c, SFS_NOP_PROGRAM, 3 * PPB + 2, 0, SFS_BUF_BASE + 32'h400, PAGE, 1, 7, st, sr, i0, i1);
      check("PROGRAM with WP", 64'(st), SFS_NST_WP);
      fw_wr(SFS_PG_NAND, nreg(c, SFS_NAND_CH_CTRL), 32'h7);
      // invalid: misaligned length
      nand_op(c, SFS_NOP_READ_PAGE, 0, 0, SFS_BUF_BASE, 6, 1, 8, st, sr, i0, i1);
      check("READ_PAGE bad length", 64'(st), SFS_NST_INVALID);
      // bad block: program status FAIL
      set_bad(c, 5, 1);
      nand_op(c, SFS_NOP_PROGRAM, 5 * PPB, 0, SFS_BUF_BASE + 32'h400, PAGE, 1, 9, st, sr, i0, i1);
      check("PROGRAM bad block", 64'(st), SFS_NST_PROG_FAIL); check("status FAIL bit", 64'(sr[0]), 1);
      nand_op(c, SFS_NOP_ERASE, 5 * PPB, 0, 0, 0, 0, 10, st, sr, i0, i1);
      check("ERASE bad block", 64'(st), SFS_NST_ERASE_FAIL);
      set_bad(c, 5, 0);
      // R/B# stuck: timeout
      fw_wr(SFS_PG_NAND, nreg(c, SFS_NAND_TIMEOUT), 32'd2000);
      set_stuck(c, 1);
      nand_op(c, SFS_NOP_ERASE, 6 * PPB, 0, 0, 0, 0, 11, st, sr, i0, i1);
      check("R/B# timeout", 64'(st), SFS_NST_TIMEOUT);
      set_stuck(c, 0);
      fw_wr(SFS_PG_NAND, nreg(c, SFS_NAND_TIMEOUT), SFS_NAND_TIMEOUT_RST);
      nand_init(c);
      // op-queue overflow is refused and flagged
    end
  endtask

  task automatic t_ecc();
    int st, sr; logic [31:0] i0, i1, v;
    grp = "ecc";
    for (int c = 0; c < NCH; c++) begin
      nand_op(c, SFS_NOP_ERASE, 7 * PPB, 0, 0, 0, 0, 1, st, sr, i0, i1);
      buf_fill(32'h0, PAGE, 32'h5EED_0000 + 32'(c));
      nand_op(c, SFS_NOP_PROGRAM, 7 * PPB, 0, SFS_BUF_BASE, PAGE, 1, 2, st, sr, i0, i1);
      // single-bit errors in 3 different words (data bit, data bit, ECC beat)
      flip(c, 7, 0, raw_off(0, 1), 3);
      flip(c, 7, 0, raw_off(9, SB - 1), 7);
      flip(c, 7, 0, raw_off(20, SB), 2);
      nand_op(c, SFS_NOP_READ_PAGE, 7 * PPB, 0, SFS_BUF_BASE + 32'h800, PAGE, 1, 3, st, sr, i0, i1);
      check("CE status", 64'(st), SFS_NST_CORRECTED);
      check("CE count", 64'(i0[15:0]), 3); check("UE count", 64'(i0[31:16]), 0);
      buf_check("corrected data", 32'h800, PAGE, 32'h5EED_0000 + 32'(c));
      // double-bit error in word 30
      flip(c, 7, 0, raw_off(30, 0), 0);
      flip(c, 7, 0, raw_off(30, 2), 5);
      nand_op(c, SFS_NOP_READ_PAGE, 7 * PPB, 0, SFS_BUF_BASE + 32'h800, PAGE, 1, 4, st, sr, i0, i1);
      check("UE status", 64'(st), SFS_NST_UNCORR);
      check("UE words", 64'(i0[31:16]), 1); check("UE first index", i1, 30);
      // raw read (ECC_EN = 0) returns the stored, uncorrected bytes of word 0
      nand_op(c, SFS_NOP_READ_PAGE, 7 * PPB, 0, SFS_BUF_BASE + 32'hC00, SB, 0, 5, st, sr, i0, i1);
      xr(SFS_BUF_BASE + 32'hC00, v);
      check("raw read sees the flipped bit", 64'(v ^ (32'h5EED_0000 + 32'(c))), 32'h0000_0800);
      // erased page reads as all ones, no error
      nand_op(c, SFS_NOP_READ_PAGE, 7 * PPB + 3, 0, SFS_BUF_BASE + 32'hC00, PAGE, 1, 6, st, sr, i0, i1);
      check("erased page status", 64'(st), SFS_NST_OK);
      xr(SFS_BUF_BASE + 32'hC00 + 32'(PAGE - 4), v); check("erased data", v, 32'hFFFF_FFFF);
    end
    // read 1: 3 corrected words; read 2: the same 3 + 1 uncorrectable word
    fw_rd(SFS_PG_SYS, SFS_SYS_NAND_CE_COUNT, v); check("SYS NAND CE count", v, 32'(6 * NCH));
    fw_rd(SFS_PG_SYS, SFS_SYS_NAND_UE_COUNT, v); check("SYS NAND UE count", v, 32'(NCH));
    fw_rd(SFS_PG_SYS, SFS_SYS_RAS_STATUS, v);
    check_true("RAS NAND_CE", v[SFS_RAS_NAND_CE]); check_true("RAS NAND_UE", v[SFS_RAS_NAND_UE]);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_STATUS, 32'h3FF);
  endtask

  task automatic t_dma();
    int st; logic [31:0] info, v;
    grp = "dma";
    hw(SFS_SHC_CTRL, 32'h1);                                   // bus mastering needs EN
    for (int i = 0; i < 256; i++) hmem.wr32(32'h1000 + i * 4, 32'hD0A0_0000 + 32'(i));
    dma_xfer(SFS_HOSTMEM_BASE + 32'h1000, SFS_BUF_BASE + 32'h1000, 1024, 8'h41, st, info);
    check("host->buf status", 64'(st), SFS_DST_OK); check("host->buf bytes", info, 1024);
    xr(SFS_BUF_BASE + 32'h1000 + 32'd1020, v); check("host->buf last word", v, 32'hD0A0_00FF);
    dma_xfer(SFS_BUF_BASE + 32'h1000, SFS_HOSTMEM_BASE + 32'h8000, 1024, 8'h42, st, info);
    check("buf->host status", 64'(st), SFS_DST_OK);
    begin
      int bad = 0;
      for (int i = 0; i < 256; i++) if (hmem.rd32(32'h8000 + i * 4) !== 32'hD0A0_0000 + 32'(i)) bad++;
      check("buf->host data", 64'(bad), 0);
    end
    dma_xfer(SFS_BUF_BASE + 32'h2, SFS_BUF_BASE + 32'h100, 8, 8'h43, st, info);
    check("misaligned -> INVALID", 64'(st), SFS_DST_INVALID);
    dma_xfer(SFS_BUF_BASE, SFS_BUF_BASE + 32'h100, 0, 8'h44, st, info);
    check("length 0 -> INVALID", 64'(st), SFS_DST_INVALID);
    dma_xfer(32'h2800_0000, SFS_BUF_BASE, 16, 8'h45, st, info);
    check("unmapped source -> READ_ERR", 64'(st), SFS_DST_READ_ERR); check("fault address", info, 32'h2800_0000);
    dma_xfer(SFS_BUF_BASE, SFS_HOSTMEM_BASE + 32'h00FF_FFF0, 64, 8'h46, st, info);
    check("host IOMMU fault -> WRITE_ERR", 64'(st), SFS_DST_WRITE_ERR);
    // queue 4 descriptors back to back, completions in order with their tags
    for (int d = 0; d < 4; d++) begin
      fw_wr(SFS_PG_DMA, SFS_DMA_SRC, SFS_HOSTMEM_BASE + 32'h1000 + 32'(d * 64));
      fw_wr(SFS_PG_DMA, SFS_DMA_DST, SFS_BUF_BASE + 32'h3000 + 32'(d * 64));
      fw_wr(SFS_PG_DMA, SFS_DMA_LEN, 64);
      fw_wr(SFS_PG_DMA, SFS_DMA_SUBMIT, 32'h50 + 32'(d));
    end
    fw_wr(SFS_PG_DMA, SFS_DMA_SUBMIT, 32'h5F);                  // 5th: queue full while the first runs?
    for (int d = 0; d < 4; d++) begin
      do fw_rd(SFS_PG_DMA, SFS_DMA_CPL_HEAD, v); while (!v[31]);
      check("queued tag order", 64'(v[23:16]), 32'h50 + 32'(d));
      check("queued status", 64'(v[15:8]), SFS_DST_OK);
      fw_wr(SFS_PG_DMA, SFS_DMA_CPL_POP, 0);
    end
    // the 5th descriptor either ran (queue had space) or was refused with SUBMIT_OVF
    fw_rd(SFS_PG_DMA, SFS_DMA_STATUS, v);
    if (v[24]) begin
      check("overflow flagged", 64'(v[24]), 1);
      fw_wr(SFS_PG_DMA, SFS_DMA_CTRL, 32'h2);
    end else begin
      do fw_rd(SFS_PG_DMA, SFS_DMA_CPL_HEAD, v); while (!v[31]);
      fw_wr(SFS_PG_DMA, SFS_DMA_CPL_POP, 0);
    end
    xr(SFS_BUF_BASE + 32'h3000 + 32'd252, v); check("queued data", v, 32'hD0A0_003F);
    // bus mastering refused while the host has the controller disabled
    hw(SFS_SHC_CTRL, 32'h0);
    dma_xfer(SFS_HOSTMEM_BASE + 32'h1000, SFS_BUF_BASE, 16, 8'h47, st, info);
    check("host memory gated when EN = 0", 64'(st), SFS_DST_READ_ERR);
    // wait for the controller-reset handshake to finish (nothing outstanding)
    do hr(SFS_SHC_STATUS, v); while (v[5]);
    fw_wr(SFS_PG_HIF, SFS_HIF_EVT_STATUS, 32'h1F);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_STATUS, 32'h3FF);
  endtask

  task automatic t_hostq();
    logic [255:0] e; logic [127:0] c; logic [31:0] v; int tag; int tags [8]; logic [255:0] got [8]; logic [255:0] gw;
    grp = "hostq";
    fw_wr(SFS_PG_CMD, SFS_CMD_CAP_LO, 32'd1000);
    host_enable();
    hr(SFS_SHC_CAPACITY_LO, v); check("capacity visible to host", v, 1000);
    // 4 commands, completed by the firmware BFM in reverse order
    for (int i = 0; i < 4; i++) begin
      mk_sqe(e, SFS_OP_READ, 0, 16'h100 + i, 64'(10 * i), 1 + i, 32'h4000 + 32'(i * 4096));
      sq_put(e);
    end
    sq_ring();
    for (int i = 0; i < 4; i++) begin
      logic [255:0] gtmp; int ttmp;
      fw_take(ttmp, gtmp);
      tags[i] = ttmp; got[i] = gtmp;
      check("fw sees opcode", 64'(got[i][0 +: 8]), SFS_OP_READ);
      check("fw sees tid", 64'(got[i][16 +: 16]), 16'h100 + i);
      check("fw sees addr", 64'(got[i][64 +: 32]), 10 * i); check("fw sees len", 64'(got[i][128 +: 32]), 1 + i);
      check("fw sees host buffer", 64'(got[i][160 +: 32]), 32'h4000 + 32'(i * 4096));
    end
    fw_rd(SFS_PG_CMD, SFS_CMD_TAGS_BUSY, v); check("4 tags busy", 64'($countones(v)), 4);
    hr(SFS_SHC_INT_STATUS, v); check("no CQ entry yet", 64'(v[0]), 0);
    hw(SFS_SHC_INT_CTRL, 32'h1);
    for (int i = 3; i >= 0; i--) fw_done(tags[i], SFS_ST_SUCCESS, 0, 32'(1 + i), 32'hAB00 + 32'(i));
    repeat (4) @(posedge clk);
    check("host_irq with CQ pending", 64'(host_irq), 1);
    for (int i = 3; i >= 0; i--) begin
      cq_get(c, 100);
      check("out-of-order tid", 64'(c[96 +: 16]), 16'h100 + i);
      check("status", 64'(c[113 +: 7]), SFS_ST_SUCCESS);
      check("result0", c[0 +: 32], 32'(1 + i)); check("result1", c[32 +: 32], 32'hAB00 + 32'(i));
      check("sq head reported", 64'(c[64 +: 16]), 4);
    end
    repeat (2) @(posedge clk);
    check("host_irq clears", 64'(host_irq), 0);
    // CQ wrap and phase flip: 2*HQD single commands
    for (int i = 0; i < 2 * HQD + 3; i++) begin
      mk_sqe(e, SFS_OP_FLUSH, 0, 16'h2000 + i, 0, 0, 0);
      sq_put(e); sq_ring();
      fw_take(tag, gw);
      fw_done(tag, SFS_ST_SUCCESS, 0, 0, 0);
      cq_get(c, 100);
      check("wrap tid", 64'(c[96 +: 16]), 16'h2000 + i);
    end
    // doorbell errors
    hw(SFS_SHC_SQ_TAIL, 32'(HQD));                               // beyond the queue
    hr(SFS_SHC_STATUS, v); check("DB_ERR (SQ tail)", 64'(v[8]), 1);
    fw_rd(SFS_PG_HIF, SFS_HIF_DB_ERR_INFO, v); check("DB_ERR info", v, 32'(HQD));
    hw(SFS_SHC_INT_STATUS, 32'h2);
    hw(SFS_SHC_CQ_HEAD, 32'((cq_head_s + 3) % HQD));             // passes the CQ tail
    hr(SFS_SHC_STATUS, v); check("DB_ERR (CQ head)", 64'(v[8]), 1);
    hw(SFS_SHC_INT_STATUS, 32'h2);
    hr(SFS_SHC_SQ_TAIL, v); check("bad SQ doorbell ignored", v, 32'(sq_tail_s));
    fw_wr(SFS_PG_HIF, SFS_HIF_EVT_STATUS, 32'h1F);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_STATUS, 32'h3FF);
  endtask

  task automatic t_invalid();
    logic [255:0] e; logic [127:0] c; logic [31:0] v; int tag; logic [255:0] got;
    grp = "invalid";
    mk_sqe(e, 8'h55, 0, 16'h301, 0, 1, 32'h1000);   expect_reject("bad opcode", e, SFS_ST_INVALID_OPCODE, 0);
    mk_sqe(e, SFS_OP_READ, 8'h80, 16'h302, 0, 1, 32'h1000); expect_reject("reserved flag", e, SFS_ST_INVALID_FIELD, SFS_ERR_RSVD_FIELD);
    mk_sqe(e, SFS_OP_READ, 0, 16'h303, 0, 1, 32'h1000); e[224 +: 32] = 1; expect_reject("reserved W7", e, SFS_ST_INVALID_FIELD, SFS_ERR_RSVD_FIELD);
    mk_sqe(e, SFS_OP_READ, 0, 16'h304, 999, 2, 32'h1000); expect_reject("LBA range", e, SFS_ST_LBA_RANGE, 0);
    mk_sqe(e, SFS_OP_WRITE, 0, 16'h305, 0, 0, 32'h1000); expect_reject("LEN 0", e, SFS_ST_INVALID_FIELD, SFS_ERR_LEN_ZERO);
    mk_sqe(e, SFS_OP_WRITE, 0, 16'h306, 0, 17, 32'h1000); expect_reject("LEN > MDTS", e, SFS_ST_INVALID_FIELD, SFS_ERR_LEN_MAX);
    mk_sqe(e, SFS_OP_READ, 0, 16'h307, 0, 1, 32'h1002); expect_reject("host buffer misaligned", e, SFS_ST_INVALID_FIELD, SFS_ERR_HOST_ADDR);
    mk_sqe(e, SFS_OP_READ, 0, 16'h308, 0, 1, 32'h0FFF_FF00); expect_reject("host buffer outside window", e, SFS_ST_INVALID_FIELD, SFS_ERR_HOST_ADDR);
    mk_sqe(e, SFS_OP_READ, 0, 16'h309, 64'h1_0000_0000, 1, 32'h1000);
    if (AWID < 33) expect_reject("ADDR above ADDRESS_WIDTH", e, SFS_ST_INVALID_FIELD, SFS_ERR_ADDR_WIDTH);
    else expect_reject("ADDR beyond capacity", e, SFS_ST_LBA_RANGE, 0);
    mk_sqe(e, SFS_OP_READ, 1, 16'h30A, 0, 1, 32'h1000); expect_reject("physical without PHYS_EN", e, SFS_ST_ACCESS_DENIED, SFS_ERR_ADDR_TYPE);
    mk_sqe(e, SFS_OP_ERASE, 0, 16'h30B, 0, 1, 0); expect_reject("logical ERASE", e, SFS_ST_INVALID_FIELD, SFS_ERR_ADDR_TYPE);
    mk_sqe(e, SFS_OP_FLUSH, 1, 16'h30C, 0, 0, 0); expect_reject("physical FLUSH", e, SFS_ST_INVALID_FIELD, SFS_ERR_ADDR_TYPE);
    // transaction-ID conflict: same TID while the first is outstanding
    mk_sqe(e, SFS_OP_READ, 0, 16'h0777, 0, 1, 32'h1000); sq_put(e); sq_ring();
    fw_take(tag, got);
    expect_reject("TID conflict", e, SFS_ST_CID_CONFLICT, 0);
    fw_done(tag, SFS_ST_SUCCESS, 0, 0, 0);
    cq_get(c, 100); check("original completes", 64'(c[96 +: 16]), 16'h0777);
    fw_rd(SFS_PG_CMD, SFS_CMD_REJECTED, v); check("rejections counted", v, 13);
    fw_rd(SFS_PG_CMD, SFS_CMD_LAST_REJECT, v); check("last reject tid", 64'(v[15:0]), 16'h0777);
    // firmware protocol errors: completing a tag it does not own, popping an empty queue
    fw_done(NT - 1, SFS_ST_SUCCESS, 0, 0, 0);
    fw_wr(SFS_PG_CMD, SFS_CMD_FWQ_POP, 0);
    fw_rd(SFS_PG_CMD, SFS_CMD_STATUS, v); check("FW_ERR flagged", 64'(v[0]), 1);
    fw_rd(SFS_PG_SYS, SFS_SYS_RAS_STATUS, v); check("RAS FW_PROTO", 64'(v[SFS_RAS_FW_PROTO]), 1);
    fw_wr(SFS_PG_CMD, SFS_CMD_STATUS, 32'h3);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_STATUS, 32'h3FF);
    hr(SFS_SHC_CQ_TAIL, v); check("no spurious CQ entry", v, 32'(cq_head_s));
  endtask

  task automatic t_bp();
    logic [255:0] e; logic [127:0] c; logic [31:0] v; int tag; logic [255:0] got; int tags [64]; int n;
    grp = "bp";
    // more commands than tags: the SQ holds the excess until tags free up
    n = (NT + 4 < HQD) ? NT + 4 : HQD - 1;
    for (int i = 0; i < n; i++) begin
      mk_sqe(e, SFS_OP_FLUSH, 0, 16'h400 + i, 0, 0, 0); sq_put(e);
    end
    sq_ring();
    repeat (8 * NT) @(posedge clk);
    fw_rd(SFS_PG_CMD, SFS_CMD_INFO, v); check("all tags busy", 64'(v[15:8]), NT);
    hr(SFS_SHC_SQ_HEAD, v);
    check("SQ head stalls (tags + 1 staged)", 64'((v - 32'(sq_tail_s - n + HQD)) % HQD), (NT + 1) % HQD);
    for (int i = 0; i < n; i++) begin
      fw_take(tag, got);
      check("fifo order", 64'(got[16 +: 16]), 16'h400 + i);
      fw_done(tag, SFS_ST_SUCCESS, 0, 0, 0);
    end
    for (int i = 0; i < n; i++) begin cq_get(c, 100); check("bp tid", 64'(c[96 +: 16]), 16'h400 + i); end
    // CQ full: host does not consume; firmware completions back up (cpl_ready = 0)
    for (int i = 0; i < HQD - 1 && i < NT; i++) begin
      mk_sqe(e, SFS_OP_FLUSH, 0, 16'h500 + i, 0, 0, 0); sq_put(e);
    end
    sq_ring();
    for (int i = 0; i < HQD - 1 && i < NT; i++) begin fw_take(tag, got); fw_done(tag, SFS_ST_SUCCESS, 0, 0, 0); end
    // fill the CQ completely by delaying consumption of earlier entries: CQ capacity is HQD-1
    repeat (10) @(posedge clk);
    fw_rd(SFS_PG_HIF, SFS_HIF_CQ_STALLS, v);
    if (NT >= HQD - 1) check_true("CQ stalls counted", v != 0);
    for (int i = 0; i < HQD - 1 && i < NT; i++) begin cq_get(c, 100); check("cq-full tid", 64'(c[96 +: 16]), 16'h500 + i); end
    // host-memory back-pressure + latency on a DMA burst
    bp_pct = 60; lat_max = 7;
    hw(SFS_SHC_CTRL, 32'h1);
    begin
      int st; logic [31:0] info;
      dma_xfer(SFS_HOSTMEM_BASE + 32'h1000, SFS_BUF_BASE + 32'h2000, 512, 8'h61, st, info);
      check("DMA under back-pressure", 64'(st), SFS_DST_OK);
      xr(SFS_BUF_BASE + 32'h2000 + 32'd508, v); check("DMA bp data", v, 32'hD0A0_007F);
    end
    bp_pct = 0; lat_max = 2;
  endtask

  task automatic t_ctrlreset();
    logic [255:0] e; logic [127:0] c; logic [31:0] v; int tag; logic [255:0] got; int tags [4];
    grp = "ctrlreset";
    for (int i = 0; i < 3; i++) begin mk_sqe(e, SFS_OP_READ, 0, 16'h600 + i, 0, 1, 32'h1000); sq_put(e); end
    sq_ring();
    for (int i = 0; i < 3; i++) begin fw_take(tag, got); tags[i] = tag; end
    fw_wr(SFS_PG_HIF, SFS_HIF_EVT_STATUS, 32'h1F);
    hw(SFS_SHC_CTRL, 32'h0);                                     // host: controller reset
    repeat (5) @(posedge clk);
    fw_rd(SFS_PG_HIF, SFS_HIF_EVT_STATUS, v); check_true("EN_FALL event", v[SFS_HEVT_EN_FALL]);
    hr(SFS_SHC_STATUS, v); check("RESETTING while tags are owned", 64'(v[5]), 1); check("still RDY", 64'(v[0]), 1);
    // a command submitted during the reset is not fetched
    for (int i = 0; i < 3; i++) fw_done(tags[i], SFS_ST_ABORT_RESET, 0, 0, 0);
    repeat (10) @(posedge clk);
    hr(SFS_SHC_STATUS, v); check("reset done: RDY = 0", 64'(v[0]), 0); check("reset done: not resetting", 64'(v[5]), 0);
    fw_rd(SFS_PG_HIF, SFS_HIF_EVT_STATUS, v); check_true("RESET_DONE event", v[SFS_HEVT_RESET_DONE]);
    fw_rd(SFS_PG_CMD, SFS_CMD_DROPPED, v); check("completions dropped", v, 3);
    hr(SFS_SHC_SQ_HEAD, v); check("SQ head cleared", v, 0);
    hr(SFS_SHC_CQ_TAIL, v); check("CQ tail cleared", v, 0);
    fw_wr(SFS_PG_HIF, SFS_HIF_EVT_STATUS, 32'h1F);
    host_enable();
    mk_sqe(e, SFS_OP_FLUSH, 0, 16'h0610, 0, 0, 0); sq_put(e); sq_ring();
    fw_take(tag, got); fw_done(tag, SFS_ST_SUCCESS, 0, 0, 0);
    cq_get(c, 100); check("works after re-enable", 64'(c[96 +: 16]), 16'h0610); check("phase 1 again", 64'(c[112]), 1);
  endtask

  task automatic t_plp();
    logic [255:0] e; logic [127:0] c; logic [31:0] v; int st, sr; logic [31:0] i0, i1;
    grp = "plp";
    fw_wr(SFS_PG_SYS, SFS_SYS_IRQ_EN_EVT, 32'(1 << SFS_IRQ_PLP));
    pwr_fail_n = 0;
    repeat (4) @(posedge clk);
    check("EVENT irq line", 64'(irq_evt), 1);
    fw_rd(SFS_PG_SYS, SFS_SYS_PLP_STATUS, v);
    check("PLP pin", 64'(v[0]), 1); check("PLP event", 64'(v[1]), 1); check("quiesce", 64'(v[2]), 1);
    check("drained", 64'(v[3]), 1);
    hr(SFS_SHC_STATUS, v); check("host sees PLP", 64'(v[4]), 1);
    mk_sqe(e, SFS_OP_WRITE, 0, 16'h0700, 0, 1, 32'h1000);
    expect_reject("new command during PLP", e, SFS_ST_ABORT_PWR_LOSS, SFS_ERR_QUIESCED);
    // firmware commits (here: nothing to commit) and declares FW_SAFE -> WP# asserted
    nand_op(0, SFS_NOP_PROGRAM, 9 * PPB, 0, SFS_BUF_BASE, PAGE, ECC != 0, 1, st, sr, i0, i1);
    check("program still allowed before FW_SAFE", 64'(st), SFS_NST_OK);
    fw_wr(SFS_PG_SYS, SFS_SYS_PLP_CTRL, 32'h5);
    repeat (2) @(posedge clk);
    check("irq drops after FW_SAFE", 64'(irq_evt), 0);
    for (int ch = 0; ch < NCH; ch++) check("WP# asserted", 64'(wp_n[ch]), 0);
    nand_op(0, SFS_NOP_PROGRAM, 9 * PPB + 1, 0, SFS_BUF_BASE, PAGE, ECC != 0, 2, st, sr, i0, i1);
    check("program refused after FW_SAFE", 64'(st), SFS_NST_WP);
    pwr_fail_n = 1;
    repeat (4) @(posedge clk);
    fw_wr(SFS_PG_SYS, SFS_SYS_PLP_CTRL, 32'h104);
    fw_rd(SFS_PG_SYS, SFS_SYS_PLP_STATUS, v); check("PLP cleared", 64'(v[2:0]), 0);
    fw_rd(SFS_PG_SYS, SFS_SYS_PLP_EVENTS, v); check("PLP events", v, 1);
    for (int ch = 0; ch < NCH; ch++) check("WP# released", 64'(wp_n[ch]), 1);
    fw_wr(SFS_PG_SYS, SFS_SYS_IRQ_EN_EVT, 0);
    hw(SFS_SHC_INT_STATUS, 32'h2);
  endtask

  task automatic t_bufecc();
    logic [31:0] v; logic e;
    grp = "bufecc";
    xw(SFS_BUF_BASE + 32'h200, 32'hCAFE_F00D);
    // single-bit persistent fault on the next write to word 0x200/SB
    fw_wr(SFS_PG_SYS, SFS_SYS_BUF_FI_MASK, 32'h0000_0010);
    fw_wr(SFS_PG_SYS, SFS_SYS_BUF_FI_ADDR, 32'h200 / SB);
    fw_wr(SFS_PG_SYS, SFS_SYS_BUF_FI_CTRL, 32'h9);              // ARM, mode WRITE, ADDR_EN
    repeat (2) @(posedge clk);
    fw_rd(SFS_PG_SYS, SFS_SYS_BUF_FI_CTRL, v); check("FI armed", 64'(v[0]), 1);
    xw(SFS_BUF_BASE + 32'h200, 32'h1234_5678);
    xr(SFS_BUF_BASE + 32'h200, v); check("buffer CE corrected", v, 32'h1234_5678);
    fw_rd(SFS_PG_SYS, SFS_SYS_BUF_CE_COUNT, v); check("buffer CE counted", v, 1);
    fw_rd(SFS_PG_SYS, SFS_SYS_BUF_FI_CTRL, v); check("FI fired (no longer armed)", 64'(v[0]), 0);
    // double-bit fault -> uncorrectable -> read error, RAS fatal enable -> ext_fatal
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_FATAL_EN, 32'(1 << SFS_RAS_BUF_UE));
    fw_wr(SFS_PG_SYS, SFS_SYS_BUF_FI_MASK, 32'h0000_0003);
    fw_wr(SFS_PG_SYS, SFS_SYS_BUF_FI_CTRL, 32'h9);
    repeat (2) @(posedge clk);
    // with DW > 32 this 32-bit write is a read-modify-write inside the ECC SRAM
    x_access(1, SFS_BUF_BASE + 32'h200, 32'h0BAD_0BAD, 4'hF, v, e);
    x_access(0, SFS_BUF_BASE + 32'h200, 0, 4'hF, v, e);
    check("buffer UE -> bus error", 64'(e), 1);
    fw_rd(SFS_PG_SYS, SFS_SYS_BUF_UE_COUNT, v); check("buffer UE counted", v, 1);
    check("ext_fatal raised", 64'(ext_fatal), 1);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_STATUS, 32'h3FF);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_FATAL_EN, 0);
    // a full-word write repairs the word (DMA writes whole DW words; a 32-bit partial write onto an
    // uncorrectable 64-bit word is refused by the ECC SRAM, Project 26 containment rule)
    for (int i = 0; i < SB; i += 4) xw(SFS_BUF_BASE + 32'h300 + 32'(i), 32'h0);
    begin
      int st; logic [31:0] info;
      dma_xfer(SFS_BUF_BASE + 32'h300, SFS_BUF_BASE + 32'h200, SB, 8'h77, st, info);
      check("repair DMA", 64'(st), SFS_DST_OK);
    end
    xr(SFS_BUF_BASE + 32'h200, v); check("word repaired by write", v, 0);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_STATUS, 32'h3FF);
  endtask

  task automatic t_fabric();
    logic [31:0] v; logic e;
    grp = "fabric";
    x_access(0, 32'h2400_0000, 0, 4'hF, v, e);  check("unmapped fabric address", 64'(e), 1);
    x_access(1, SFS_BUF_BASE + 32'(BUFB), 0, 4'hF, v, e); check("beyond buffer", 64'(e), 1);
    fw_rd(SFS_PG_SYS, SFS_SYS_FAB_ERR_ADDR, v); check("fabric error address", v, SFS_BUF_BASE + 32'(BUFB));
    fw_rd(SFS_PG_SYS, SFS_SYS_RAS_STATUS, v); check("RAS FABRIC_DEC", 64'(v[SFS_RAS_FABRIC_DEC]), 1);
    fw_wr(SFS_PG_SYS, SFS_SYS_RAS_STATUS, 32'h3FF);
  endtask

  task automatic t_irq();
    logic [31:0] v; int st, sr; logic [31:0] i0, i1;
    grp = "irq";
    fw_wr(SFS_PG_SYS, SFS_SYS_IRQ_EN_IO, 32'(1 << SFS_IRQ_NAND));
    fw_wr(SFS_PG_NAND, nreg(0, SFS_NAND_OP_ROW), 0);
    fw_wr(SFS_PG_NAND, nreg(0, SFS_NAND_OP_SUBMIT), 32'(SFS_NOP_READ_STATUS) | (32'h33 << 16));
    fork
      begin : wait_irq
        int t = 0;
        while (!irq_io && t < 5000) begin @(posedge clk); t++; end
      end
    join
    check("IO line on NAND completion", 64'(irq_io), 1);
    fw_rd(SFS_PG_SYS, SFS_SYS_IRQ_STATUS, v); check("IRQ_STATUS NAND", 64'(v[SFS_IRQ_NAND]), 1);
    fw_wr(SFS_PG_NAND, nreg(0, SFS_NAND_CPL_POP), 0);
    repeat (2) @(posedge clk);
    check("IO line drops after pop", 64'(irq_io), 0);
    fw_wr(SFS_PG_SYS, SFS_SYS_IRQ_EN_IO, 0);
    // masked source does not reach the line
    fw_wr(SFS_PG_NAND, nreg(0, SFS_NAND_OP_SUBMIT), 32'(SFS_NOP_READ_STATUS) | (32'h34 << 16));
    repeat (400) @(posedge clk);
    check("masked", 64'(irq_io), 0);
    fw_wr(SFS_PG_NAND, nreg(0, SFS_NAND_CPL_POP), 0);
  endtask

  // complete storage commands with the firmware BFM: WRITE then READ through NAND + DMA
  task automatic t_e2e();
    logic [255:0] e; logic [127:0] c; logic [31:0] v; int tag; logic [255:0] got; int st, sr; logic [31:0] i0, i1, info;
    grp = "e2e";
    for (int i = 0; i < PAGE / 4; i++) hmem.wr32(32'h10000 + i * 4, 32'hE2E0_0000 + 32'(i));
    mk_sqe(e, SFS_OP_WRITE, 0, 16'h0901, 5, 1, 32'h10000); sq_put(e); sq_ring();
    fw_take(tag, got);
    dma_xfer(SFS_HOSTMEM_BASE + got[160 +: 32], SFS_BUF_BASE + 32'h1800, PAGE, tag, st, info);
    nand_op(0, SFS_NOP_ERASE, 12 * PPB, 0, 0, 0, 0, tag, st, sr, i0, i1);
    nand_op(0, SFS_NOP_PROGRAM, 12 * PPB + got[64 +: 32], 0, SFS_BUF_BASE + 32'h1800, PAGE, ECC != 0, tag, st, sr, i0, i1);
    fw_done(tag, (st == SFS_NST_OK) ? SFS_ST_SUCCESS : SFS_ST_MEDIA_WRITE, 0, 1, 0);
    cq_get(c, 100); check("WRITE tid", 64'(c[96 +: 16]), 16'h0901); check("WRITE status", 64'(c[113 +: 7]), 0);
    mk_sqe(e, SFS_OP_READ, 0, 16'h0902, 5, 1, 32'h20000); sq_put(e); sq_ring();
    fw_take(tag, got);
    nand_op(0, SFS_NOP_READ_PAGE, 12 * PPB + got[64 +: 32], 0, SFS_BUF_BASE + 32'h1C00, PAGE, ECC != 0, tag, st, sr, i0, i1);
    dma_xfer(SFS_BUF_BASE + 32'h1C00, SFS_HOSTMEM_BASE + got[160 +: 32], PAGE, tag, st, info);
    fw_done(tag, SFS_ST_SUCCESS, 0, 1, i0);
    cq_get(c, 100); check("READ tid", 64'(c[96 +: 16]), 16'h0902);
    begin
      int bad = 0;
      for (int i = 0; i < PAGE / 4; i++) if (hmem.rd32(32'h20000 + i * 4) !== 32'hE2E0_0000 + 32'(i)) bad++;
      check("e2e data host->NAND->host", 64'(bad), 0);
    end
    fw_rd(SFS_PG_SYS, SFS_SYS_PERF_HOST_CMDS, v); check_true("perf: commands counted", v > 0);
    fw_rd(SFS_PG_SYS, SFS_SYS_PERF_NAND_PG, v);   check_true("perf: programs counted", v > 0);
    fw_rd(SFS_PG_SYS, SFS_SYS_PERF_DMA_BYTES, v); check_true("perf: DMA bytes counted", v >= 2 * PAGE);
    fw_rd(SFS_PG_SYS, SFS_SYS_PERF_CMD_LATMAX, v); check_true("perf: latency max", v > 0);
  endtask

  // ---------------------------------------------------------------- model access (generate-indexed)
  task automatic flip(input int ch, input int blk, input int pg, input int off, input int b);
    case (ch)
      0: g_nand[0].flash.flip_bit(blk, pg, off, b);
`ifdef SFS_MULTI
      1: g_nand[1].flash.flip_bit(blk, pg, off, b);
      2: g_nand[2].flash.flip_bit(blk, pg, off, b);
      3: g_nand[3].flash.flip_bit(blk, pg, off, b);
`endif
      default: ;
    endcase
  endtask
  task automatic set_bad(input int ch, input int blk, input bit v);
    case (ch)
      0: g_nand[0].flash.set_bad_block(blk, v);
`ifdef SFS_MULTI
      1: g_nand[1].flash.set_bad_block(blk, v);
      2: g_nand[2].flash.set_bad_block(blk, v);
      3: g_nand[3].flash.set_bad_block(blk, v);
`endif
      default: ;
    endcase
  endtask
  task automatic set_stuck(input int ch, input bit v);
    case (ch)
      0: g_nand[0].flash.set_stuck_busy(v);
`ifdef SFS_MULTI
      1: g_nand[1].flash.set_stuck_busy(v);
      2: g_nand[2].flash.set_stuck_busy(v);
      3: g_nand[3].flash.set_stuck_busy(v);
`endif
      default: ;
    endcase
  endtask
  function automatic int g_nand_erases(input int ch);
    case (ch)
      0: return g_nand[0].flash.n_erases;
`ifdef SFS_MULTI
      1: return g_nand[1].flash.n_erases;
      2: return g_nand[2].flash.n_erases;
      3: return g_nand[3].flash.n_erases;
`endif
      default: return -1;
    endcase
  endfunction

  // ---------------------------------------------------------------- main
  string only;
  initial begin
    if (!$value$plusargs("test=%s", only)) only = "all";
    $display("tb_sfs_subsys: config %s  NCH=%0d CDW=%0d BUF=%0d DW=%0d AW=%0d TAGS=%0d ECC=%0d RAS=%0d",
             `SFS_CFG_NAME, NCH, CDW, BUFB, DW, AWID, NT, ECC, RAS);
    repeat (5) @(posedge clk);
    rst_n = 1'b1;
    repeat (5) @(posedge clk);
    t_regs();   $display("  group regs      done: pass %0d fail %0d", n_pass, n_fail);
    if (only == "all" || only == "nand")      begin t_nand();      $display("  group nand      done: pass %0d fail %0d", n_pass, n_fail); end
    if ((only == "all" || only == "ecc") && ECC == 0) $display("  group ecc       skipped: ENABLE_ECC = 0");
    if ((only == "all" || only == "ecc") && ECC != 0) begin t_ecc();       $display("  group ecc       done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "dma")       begin t_dma();       $display("  group dma       done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "hostq")     begin t_hostq();     $display("  group hostq     done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "invalid")   begin t_invalid();   $display("  group invalid   done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "bp")        begin t_bp();        $display("  group bp        done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "ctrlreset") begin t_ctrlreset(); $display("  group ctrlreset done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "plp")       begin t_plp();       $display("  group plp       done: pass %0d fail %0d", n_pass, n_fail); end
    if ((only == "all" || only == "bufecc") && RAS == 0) $display("  group bufecc    skipped: ENABLE_RAS = 0");
    if ((only == "all" || only == "bufecc") && RAS != 0) begin t_bufecc();    $display("  group bufecc    done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "fabric")    begin t_fabric();    $display("  group fabric    done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "irq")       begin t_irq();       $display("  group irq       done: pass %0d fail %0d", n_pass, n_fail); end
    if (only == "all" || only == "e2e")       begin t_e2e();       $display("  group e2e       done: pass %0d fail %0d", n_pass, n_fail); end
    begin : final_checks
      int pe, te;
      pe = g_nand[0].flash.n_proto_err; te = g_nand[0].flash.n_timing_err;
      check("flash protocol errors", 64'(pe), 0);
      check("flash timing errors", 64'(te), 0);
    end
    $display("tb_sfs_subsys %s: %0d checks, %0d failures -> %s", `SFS_CFG_NAME, n_pass + n_fail, n_fail,
             (n_fail == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    int tmo;
    if (!$value$plusargs("timeout=%d", tmo)) tmo = 20_000_000;
    #(tmo * 10);
    $display("tb_sfs_subsys: TIMEOUT");
    $display("tb_sfs_subsys %s: TIMEOUT -> FAIL", `SFS_CFG_NAME);
    $finish;
  end
endmodule

`default_nettype wire
