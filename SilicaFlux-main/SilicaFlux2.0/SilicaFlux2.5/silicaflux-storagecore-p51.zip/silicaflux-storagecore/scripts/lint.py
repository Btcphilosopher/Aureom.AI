#!/usr/bin/env python3
"""SilicaFlux StorageCore -- lint.

  * Verilator 5 --lint-only -Wall on the new storage RTL, every configuration,
    both tops (sfs_storage_subsys and silicaflux_storage_soc).  Warnings located
    in third_party/ (unmodified reused sources) are reported separately and do
    not count: they belong to the projects that own those files.
  * Icarus Verilog 12 elaboration of the same tops.
  * Illegal parameter sets must be rejected at elaboration.
Writes reports/lint.md; exit 1 on any new-RTL warning or unexpected result.
"""
import os
import re
import subprocess
import sys

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = os.path.join(ROOT, "rtl")
PARAMS = ["NUM_NAND_CHANNELS", "CHANNEL_DATA_WIDTH", "BUFFER_SIZE_BYTES", "DMA_DATA_WIDTH", "ADDRESS_WIDTH",
          "CMD_QUEUE_DEPTH", "ENABLE_ECC", "ENABLE_RAS", "NAND_PAGE_BYTES"]


def configs():
    out = []
    for f in sorted(os.listdir(os.path.join(ROOT, "config", "configs"))):
        with open(os.path.join(ROOT, "config", "configs", f)) as fh:
            out.append(yaml.safe_load(fh))
    return out


def run(cmd):
    p = subprocess.run(cmd, cwd=RTL, capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def vlint(top, params):
    g = [f"-G{k}={v}" for k, v in params.items()]
    rc, out = run(["verilator", "--lint-only", "-Wall", "-Wno-fatal", "-f", "files.f", "--top-module", top] + g)
    new, old = [], []
    for line in out.splitlines():
        if not line.startswith("%Warning") and not line.startswith("%Error"):
            continue
        (old if "third_party" in line else new).append(line)
    errors = [l for l in out.splitlines() if l.startswith("%Error")]
    return rc, new, old, errors


def ilint(top, params):
    p = [f"-P{top}.{k}={v}" for k, v in params.items()]
    rc, out = run(["iverilog", "-g2012", "-s", top, "-o", "/dev/null", "-f", "files.f"] + p)
    errs = [l for l in out.splitlines() if "error" in l.lower() and "cannot be synthesized" not in l]
    return rc, errs


def main():
    rep = ["# Lint report", "", "Tools: Verilator 5.020 (`--lint-only -Wall`), Icarus Verilog 12 (`-g2012` elaboration).",
           "New RTL = `rtl/*.sv` + generated packages.  `third_party/` = reused, unmodified sources (reported, not counted).", "",
           "| Top | Configuration | Verilator new-RTL warnings | third_party warnings | Icarus |", "|---|---|---|---|---|"]
    ok = True
    details = []
    for c in configs():
        for top in ["sfs_storage_subsys", "silicaflux_storage_soc"]:
            rc, new, old, errors = vlint(top, c["params"])
            irc, ierr = ilint(top, c["params"])
            good = rc == 0 and not new and not errors
            igood = irc == 0
            ok &= good and igood
            rep.append(f"| `{top}` | `{c['name']}` | {len(new)} | {len(old)} | {'elaborates' if igood else 'FAIL'} |")
            details += [f"{top}/{c['name']}: {l}" for l in new + errors + ierr]
    # illegal parameter sets must be rejected
    illegal = {
        "CHANNEL_DATA_WIDTH=12": {"CHANNEL_DATA_WIDTH": 12},
        "DMA_DATA_WIDTH=48": {"DMA_DATA_WIDTH": 48},
    }
    rep += ["", "## Illegal parameter sets (must be rejected)", "", "| Parameters | Verilator | Icarus |", "|---|---|---|"]
    for name, p in illegal.items():
        base = dict(configs()[0]["params"])
        base.update(p)
        rc, new, _, errors = vlint("sfs_storage_subsys", base)
        p = [f"-Psfs_storage_subsys.{k}={v}" for k, v in base.items()]
        exe = os.path.join(ROOT, "build", "lint_illegal.vvp")
        os.makedirs(os.path.dirname(exe), exist_ok=True)
        run(["iverilog", "-g2012", "-s", "sfs_storage_subsys", "-o", exe, "-f", "files.f"] + p)
        _, iout = run(["vvp", "-n", exe])
        irej = "FATAL" in iout or "fatal" in iout
        vrej = rc != 0 or bool(errors) or any("USERFATAL" in l for l in new)
        rep.append(f"| `{name}` | {'rejected ($fatal at elaboration)' if vrej else 'ACCEPTED'} | {'rejected ($fatal at time 0)' if irej else 'ACCEPTED'} |")
        ok &= vrej and irej
    if details:
        rep += ["", "## New-RTL findings", "", "```"] + details + ["```"]
    rep += ["", f"**Result: {'PASS' if ok else 'FAIL'}**", ""]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "lint.md"), "w") as f:
        f.write("\n".join(rep))
    print("\n".join(rep))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
