#!/usr/bin/env python3
"""SilicaFlux StorageCore (Project 51) -- address-map / protocol generator.

Single source of truth: config/sfs_memmap.yaml (+ config/configs/*.yaml).

  python3 scripts/gen_map.py            regenerate every output
  python3 scripts/gen_map.py --check    exit 1 if an output is stale or the map is illegal
  python3 scripts/gen_map.py --selftest validate that illegal maps are rejected

Outputs
  rtl/generated/sfs_map_pkg.sv        package sfs_map_pkg (addresses, pages, register offsets, reset values)
  rtl/generated/sfs_proto_enums.svh   typedef enums, `included by rtl/silicaflux_storage_pkg.sv
  rtl/generated/sfs_configs.svh       `define parameter sets for every configuration
  sw/include/generated/sfs_map.h      C header (firmware and host driver)
  docs/MEMORY_MAP.md                  human-readable map
"""
import copy
import glob
import os
import sys

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "config", "sfs_memmap.yaml")
CFG_GLOB = os.path.join(ROOT, "config", "configs", "*.yaml")

ENUM_TYPES = {
    "OP": "sfs_opcode_e", "ADDR": "sfs_addr_type_e", "DIR": "sfs_dir_e", "ST": "sfs_status_e",
    "ERR": "sfs_err_e", "NOP": "sfs_nand_op_e", "NST": "sfs_nand_st_e", "DST": "sfs_dma_st_e",
    "IRQ": "sfs_irq_e", "RAS": "sfs_ras_e", "HEVT": "sfs_hevt_e",
}
PARAM_ORDER = ["NUM_NAND_CHANNELS", "CHANNEL_DATA_WIDTH", "BUFFER_SIZE_BYTES", "DMA_DATA_WIDTH",
               "ADDRESS_WIDTH", "CMD_QUEUE_DEPTH", "ENABLE_ECC", "ENABLE_RAS", "NAND_PAGE_BYTES"]
EXT_LO, EXT_HI = 0x20000000, 0x40000000      # ControlCore EXT window (cc_memmap.yaml)
ACCESS = {"RO", "RW", "WO", "W1C"}


class MapError(Exception):
    pass


def ver(v):
    return (v[0] << 16) | v[1]


# ----------------------------------------------------------------------------- validation
def validate(m, cfgs):
    pages = m["cc_pages"]
    seen = set()
    for n, p in pages.items():
        if not 10 <= p <= 15:
            raise MapError(f"page {n}={p}: storage pages must be ControlCore forwarded pages 10..15")
        if p in seen:
            raise MapError(f"page {p} used twice")
        seen.add(p)
    fab = sorted(m["fabric"], key=lambda r: r["base"])
    for r in fab:
        if r["size"] & (r["size"] - 1) or r["base"] % r["size"]:
            raise MapError(f"fabric region {r['name']}: size must be a power of two and the base aligned")
        if r["base"] < EXT_LO or r["base"] + r["size"] > EXT_HI:
            raise MapError(f"fabric region {r['name']} outside the ControlCore EXT window")
    for a, b in zip(fab, fab[1:]):
        if a["base"] + a["size"] > b["base"]:
            raise MapError(f"fabric regions {a['name']} and {b['name']} overlap")
    for blk in m["blocks"]:
        limit = blk.get("stride", 0x1000 if blk["name"] != "SHC" else 0x1000)
        offs = {}
        for r in blk["regs"]:
            name, off, acc = r[0], r[1], r[2]
            if acc not in ACCESS:
                raise MapError(f"{blk['name']}.{name}: access {acc}")
            if off % 4:
                raise MapError(f"{blk['name']}.{name}: offset 0x{off:x} not word aligned")
            if off >= limit:
                raise MapError(f"{blk['name']}.{name}: offset 0x{off:x} outside the block (0x{limit:x})")
            if off in offs:
                raise MapError(f"{blk['name']}: {name} overlaps {offs[off]} at 0x{off:x}")
            offs[off] = name
    for en, e in m["enums"].items():
        vals = {}
        for n, d in e["values"].items():
            v = d["v"]
            if v >= (1 << e["width"]):
                raise MapError(f"enum {en}.{n}={v} does not fit {e['width']} bits")
            if v in vals:
                raise MapError(f"enum {en}: {n} and {vals[v]} share value {v}")
            vals[v] = n
    for c in cfgs:
        p = c["params"]
        for k in PARAM_ORDER:
            if k not in p:
                raise MapError(f"config {c['name']}: missing {k}")
        if not 1 <= p["NUM_NAND_CHANNELS"] <= 8:
            raise MapError(f"config {c['name']}: NUM_NAND_CHANNELS 1..8")
        if p["CHANNEL_DATA_WIDTH"] not in (8, 16):
            raise MapError(f"config {c['name']}: CHANNEL_DATA_WIDTH 8 or 16")
        if p["DMA_DATA_WIDTH"] not in (32, 64):
            raise MapError(f"config {c['name']}: DMA_DATA_WIDTH 32 or 64")
        b = p["BUFFER_SIZE_BYTES"]
        if b & (b - 1) or not 4096 <= b <= 0x01000000:
            raise MapError(f"config {c['name']}: BUFFER_SIZE_BYTES power of two, 4 KiB..16 MiB")
        q = p["CMD_QUEUE_DEPTH"]
        if q & (q - 1) or not 2 <= q <= 64:
            raise MapError(f"config {c['name']}: CMD_QUEUE_DEPTH power of two, 2..64")
        if not 16 <= p["ADDRESS_WIDTH"] <= 64:
            raise MapError(f"config {c['name']}: ADDRESS_WIDTH 16..64")
        pg = p["NAND_PAGE_BYTES"]
        if pg & (pg - 1) or not 64 <= pg <= 16384:
            raise MapError(f"config {c['name']}: NAND_PAGE_BYTES power of two 64..16384")


# ----------------------------------------------------------------------------- emitters
def hdr(c):
    return [f"{c} GENERATED by scripts/gen_map.py from config/sfs_memmap.yaml -- do not edit.",
            f"{c} SilicaFlux StorageCore (Project 51) address map v{{}}.{{}}"]


def emit_sv_pkg(m):
    mv = m["versions"]["map"]
    o = ["// " + hdr("//")[0][3:], f"// SilicaFlux StorageCore (Project 51) address map v{mv[0]}.{mv[1]}",
         "`default_nettype none", "", "package sfs_map_pkg;", "  /* verilator lint_off UNUSEDPARAM */"]
    v = m["versions"]
    o += [f"  localparam logic [31:0] SFS_MAP_VERSION   = 32'h{ver(v['map']):08x};",
          f"  localparam logic [31:0] SFS_PROTO_VERSION = 32'h{ver(v['proto']):08x};",
          f"  localparam logic [31:0] SFS_HW_VERSION    = 32'h{ver(v['hw']):08x};",
          f"  localparam logic [31:0] SFS_SYS_ID_VALUE  = 32'h{m['ids']['SYS_ID']:08x};",
          f"  localparam logic [31:0] SFS_HIF_ID_VALUE  = 32'h{m['ids']['HIF_ID']:08x};",
          f"  localparam int          SFS_LBA_BYTES     = {m['lba_bytes']};", ""]
    o.append("  // ControlCore register pages (forwarded accelerator pages; acc_rb_addr[14:12] = page - 8)")
    for n, p in m["cc_pages"].items():
        o.append(f"  localparam int          SFS_PG_{n:<6} = {p};")
        o.append(f"  localparam logic [31:0] SFS_{n}_BASE = 32'h{m['cc_periph_base'] + p * 0x1000:08x};")
    o.append(f"  localparam int          SFS_NAND_CH_STRIDE = 'h{m['nand_channel_stride']:x};")
    o.append("")
    o.append("  // storage fabric (= ControlCore EXT window)")
    for r in m["fabric"]:
        o.append(f"  localparam logic [31:0] SFS_{r['name']}_BASE = 32'h{r['base']:08x};")
        o.append(f"  localparam logic [31:0] SFS_{r['name']}_WIN  = 32'h{r['size']:08x};")
    o.append("")
    o.append("  // host BAR")
    for r in m["host_bar"]:
        o.append(f"  localparam logic [31:0] SFS_BAR_{r['name']}_BASE = 32'h{r['base']:08x};")
        o.append(f"  localparam logic [31:0] SFS_BAR_{r['name']}_SIZE = 32'h{r['size']:08x};")
    for n, w in m["shc_windows"].items():
        o.append(f"  localparam logic [15:0] SFS_SHC_{n} = 16'h{w['offset']:04x};")
        o.append(f"  localparam int          SFS_SHC_{n}_STRIDE = {w['stride']};")
    t = m["cmd_tag_window"]
    o.append(f"  localparam logic [11:0] SFS_CMD_TAG_WIN = 12'h{t['offset']:03x};")
    o.append(f"  localparam int          SFS_CMD_TAG_STRIDE = {t['stride']};")
    for blk in m["blocks"]:
        w = 16 if blk["name"] == "SHC" else 12
        o.append("")
        o.append(f"  // {blk['name']}: {blk['desc']} ({blk['where']})")
        for r in blk["regs"]:
            name, off, _acc, rst, desc = r
            o.append(f"  localparam logic [{w-1}:0] {blk['prefix']}{name} = {w}'h{off:0{w//4}x};  // {desc}")
            if rst is not None:
                o.append(f"  localparam logic [31:0] {blk['prefix']}{name}_RST = 32'h{rst:08x};")
    o += ["  /* verilator lint_on UNUSEDPARAM */", "endpackage", "", "`default_nettype wire", ""]
    return "\n".join(o)


def emit_sv_enums(m):
    o = ["// " + hdr("//")[0][3:],
         "// Protocol enumerations, `included inside package silicaflux_storage_pkg.", ""]
    for en, e in m["enums"].items():
        t = ENUM_TYPES[en]
        w = e["width"]
        o.append(f"// {e['desc']}")
        o.append(f"typedef enum logic [{w-1}:0] {{")
        items = list(e["values"].items())
        for i, (n, d) in enumerate(items):
            comma = "," if i < len(items) - 1 else ""
            o.append(f"  SFS_{en}_{n} = {w}'d{d['v']}{comma}  // {d['desc']}")
        o.append(f"}} {t};")
        o.append("")
    return "\n".join(o)


def emit_sv_cfg(cfgs):
    o = ["// " + hdr("//")[0][3:].replace("sfs_memmap.yaml", "configs/*.yaml"),
         "// Parameter sets: define SFS_CFG_<NAME> (default SFS_CFG_MIN1CH) before including.",
         "`ifndef SFS_CONFIGS_SVH", "`define SFS_CONFIGS_SVH"]
    names = [c["name"].upper() for c in cfgs]
    o.append("`ifndef SFS_CFG_" + " `ifndef SFS_CFG_".join(names))
    o.append("  `define SFS_CFG_MIN1CH")
    o.append("`endif " * len(names))
    for c in cfgs:
        o.append(f"`ifdef SFS_CFG_{c['name'].upper()}  // {c['desc']}")
        o.append(f"  `define SFS_CFG_NAME \"{c['name']}\"")
        for k in PARAM_ORDER:
            o.append(f"  `define SFS_P_{k} {c['params'][k]}")
        o.append("`endif")
    o += ["`endif", ""]
    return "\n".join(o)


def emit_c(m, cfgs):
    v = m["versions"]
    o = ["/* " + hdr("")[0].strip() + " */", "#ifndef SFS_MAP_H", "#define SFS_MAP_H", ""]
    o += [f"#define SFS_MAP_VERSION   0x{ver(v['map']):08x}u",
          f"#define SFS_PROTO_VERSION 0x{ver(v['proto']):08x}u",
          f"#define SFS_HW_VERSION    0x{ver(v['hw']):08x}u",
          f"#define SFS_SYS_ID_VALUE  0x{m['ids']['SYS_ID']:08x}u",
          f"#define SFS_HIF_ID_VALUE  0x{m['ids']['HIF_ID']:08x}u",
          f"#define SFS_LBA_BYTES     {m['lba_bytes']}u", ""]
    o.append("/* ControlCore view: storage register pages */")
    for n, p in m["cc_pages"].items():
        o.append(f"#define SFS_PG_{n} {p}u")
        o.append(f"#define SFS_{n}_BASE 0x{m['cc_periph_base'] + p * 0x1000:08x}u")
    o.append(f"#define SFS_NAND_CH_STRIDE 0x{m['nand_channel_stride']:x}u")
    o.append("\n/* storage fabric (ControlCore EXT window) */")
    for r in m["fabric"]:
        o.append(f"#define SFS_{r['name']}_BASE 0x{r['base']:08x}u")
        o.append(f"#define SFS_{r['name']}_WIN  0x{r['size']:08x}u")
    o.append("\n/* host BAR view */")
    for r in m["host_bar"]:
        o.append(f"#define SFS_BAR_{r['name']}_BASE 0x{r['base']:08x}u")
        o.append(f"#define SFS_BAR_{r['name']}_SIZE 0x{r['size']:08x}u")
    for n, w in m["shc_windows"].items():
        o.append(f"#define SFS_SHC_{n} 0x{w['offset']:04x}u")
        o.append(f"#define SFS_SHC_{n}_STRIDE {w['stride']}u")
    t = m["cmd_tag_window"]
    o.append(f"#define SFS_CMD_TAG_WIN 0x{t['offset']:03x}u")
    o.append(f"#define SFS_CMD_TAG_STRIDE {t['stride']}u")
    for blk in m["blocks"]:
        o.append(f"\n/* {blk['name']}: {blk['desc']} -- {blk['where']} */")
        for r in blk["regs"]:
            name, off, _acc, rst, desc = r
            o.append(f"#define {blk['prefix']}{name} 0x{off:03x}u  /* {r[2]}: {desc.replace('*/', '* /').replace('/*', '/ *')} */")
            if rst is not None:
                o.append(f"#define {blk['prefix']}{name}_RST 0x{rst:08x}u")
    for en, e in m["enums"].items():
        o.append(f"\n/* {e['desc']} ({ENUM_TYPES[en]}) */")
        for n, d in e["values"].items():
            o.append(f"#define SFS_{en}_{n} 0x{d['v']:02x}u  /* {d['desc']} */")
    o.append("""
/* SQ entry (32 bytes, host writes it into the SQ ring) */
#define SFS_SQE_WORDS          8u
#define SFS_SQE_W0(op, flags, tid) ((uint32_t)(op) | ((uint32_t)(flags) << 8) | ((uint32_t)(tid) << 16))
#define SFS_SQE_FLAG_PHYS      0x01u   /* W0[8]: ADDR_TYPE = PHYSICAL */
#define SFS_SQE_FLAG_FUA       0x02u   /* W0[9]: force unit access (write: commit before completion) */
#define SFS_SQE_FLAG_RSVD_MASK 0xFCu   /* W0[15:10] must be 0 */
/* W1 aux (IDENTIFY: CNS) | W2 ADDR[31:0] | W3 ADDR[63:32] | W4 LEN (blocks, 1-based)
 * W5 HOST_ADDR[31:0] | W6 HOST_ADDR[63:32] | W7 reserved (0) */

/* CQ entry (16 bytes, controller writes it into the CQ ring)
 * W0 RESULT0 | W1 RESULT1 | W2 [15:0] SQ head [31:16] reserved
 * W3 [15:0] TID [16] PHASE [23:17] STATUS (SFS_ST_*) [31:24] ERROR (SFS_ERR_*) */
#define SFS_CQE_WORDS          4u
#define SFS_CQE_TID(w3)        ((w3) & 0xFFFFu)
#define SFS_CQE_PHASE(w3)      (((w3) >> 16) & 1u)
#define SFS_CQE_STATUS(w3)     (((w3) >> 17) & 0x7Fu)
#define SFS_CQE_ERR(w3)        (((w3) >> 24) & 0xFFu)

/* PHYSICAL address encoding (ADDR_TYPE = PHYSICAL): [7:0] page [23:8] block [31:24] channel */
#define SFS_PPA(ch, blk, pg)   (((uint32_t)(ch) << 24) | ((uint32_t)(blk) << 8) | (uint32_t)(pg))
""")
    o.append("/* configurations (config/configs/<name>.yaml); the firmware reads the real values from SFS_SYS_CONFIGn */")
    for c in cfgs:
        for k in PARAM_ORDER:
            o.append(f"#define SFS_CFG_{c['name'].upper()}_{k} {c['params'][k]}u")
    o += ["", "#endif /* SFS_MAP_H */", ""]
    return "\n".join(o)


def emit_md(m, cfgs):
    v = m["versions"]
    o = [f"# StorageCore address map v{v['map'][0]}.{v['map'][1]}", "",
         "> GENERATED by `scripts/gen_map.py` from `config/sfs_memmap.yaml` (single source of truth). "
         "Do not edit; edit the YAML and run `make map`. The same run writes `rtl/generated/sfs_map_pkg.sv`, "
         "`rtl/generated/sfs_proto_enums.svh`, `rtl/generated/sfs_configs.svh` and `sw/include/generated/sfs_map.h`; "
         "`make check-map` fails if any of them is stale or if the map is illegal (overlap, misalignment, "
         "page outside 10..15, enum collision, illegal configuration).", "",
         f"Protocol version {v['proto'][0]}.{v['proto'][1]}, StorageCore RTL {v['hw'][0]}.{v['hw'][1]}. "
         "Byte addresses, little-endian, 32-bit registers (word accesses only).", "",
         "## 1. ControlCore view (firmware)", "",
         "The ControlCore map (`third_party/silicaflux-controlcore/docs/MEMORY_MAP.md`) is unchanged. The storage "
         "blocks occupy its forwarded accelerator pages and its EXT window:", "",
         "| Region | Base | Size | Description |", "|---|---|---|---|"]
    for n, p in m["cc_pages"].items():
        blk = next(b for b in m["blocks"] if b["name"] == n)
        o.append(f"| {n} (page {p}) | `0x{m['cc_periph_base'] + p * 0x1000:08X}` | 4 KiB | {blk['desc']} |")
    for r in m["fabric"]:
        o.append(f"| {r['name']} | `0x{r['base']:08X}` | {r['size'] // 1024} KiB window | {r['desc']} |")
    o += ["", "## 2. Storage fabric (SFB2, `sfb_crossbar`)", "",
          "| Master | BUF | HOSTMEM |", "|---|---|---|",
          "| ControlCore EXT (CPU data port, system DMA) | yes | yes |",
          "| Storage DMA | yes | yes |",
          "| NAND channel c | yes | - (decode error) |", "",
          "Unmapped addresses, access-matrix denials and misaligned addresses are answered by the crossbar's "
          "decode-error slave (`rsp_error = 1`, no side effect) and logged in `SFS_SYS.RAS_STATUS.FABRIC_DEC` / "
          "`FAB_ERR_ADDR`.", "",
          "## 3. Host view (one SFB2 slave port: BAR)", "",
          "| Window | Base | Size | Description |", "|---|---|---|---|"]
    for r in m["host_bar"]:
        o.append(f"| {r['name']} | `0x{r['base']:08X}` | 0x{r['size']:X} | {r['desc']} |")
    for n, w in m["shc_windows"].items():
        o.append(f"| SHC {n} | `0x{0x80000000 + w['offset']:08X}` | stride {w['stride']} | {w['desc']} (offsets relative to the SHC window) |")
    o += ["", "## 4. Protocol enumerations", ""]
    for en, e in m["enums"].items():
        o += [f"### {en}: {e['desc']} (`{ENUM_TYPES[en]}`, {e['width']} bits)", "",
              "| Name | Value | Meaning |", "|---|---|---|"]
        for n, d in e["values"].items():
            o.append(f"| `SFS_{en}_{n}` | `0x{d['v']:02X}` | {d['desc']} |")
        o.append("")
    o += ["## 5. Queue entries (host ABI)", "",
          "SQ entry, 8 words: `W0` = [7:0] opcode, [8] ADDR_TYPE, [9] FUA, [15:10] reserved, [31:16] TID; "
          "`W1` aux (IDENTIFY: CNS); `W2/W3` ADDR[63:0]; `W4` LEN (blocks, 1-based); `W5/W6` host buffer address; "
          "`W7` reserved.", "",
          "CQ entry, 4 words: `W0` RESULT0, `W1` RESULT1, `W2` [15:0] SQ head, `W3` [15:0] TID, [16] phase, "
          "[23:17] status, [31:24] error.", ""]
    o += ["## 6. Registers", ""]
    for blk in m["blocks"]:
        o += [f"### {blk['name']} -- `{blk['block']}` ({blk['where']}, prefix `{blk['prefix']}`)", "",
              blk["desc"] + ".", "", "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
        for r in blk["regs"]:
            name, off, acc, rst, desc = r
            rs = f"`0x{rst:08X}`" if rst is not None else ""
            o.append(f"| `0x{off:03X}` | {name} | {acc} | {rs} | {desc} |")
        o.append("")
    o += ["## 7. Configurations", "", "| Name | " + " | ".join(PARAM_ORDER) + " |",
          "|---|" + "---|" * len(PARAM_ORDER)]
    for c in cfgs:
        o.append(f"| `{c['name']}` | " + " | ".join(str(c["params"][k]) for k in PARAM_ORDER) + " |")
    o.append("")
    return "\n".join(o)


# ----------------------------------------------------------------------------- driver
def load():
    with open(SRC) as f:
        m = yaml.safe_load(f)
    cfgs = []
    for p in sorted(glob.glob(CFG_GLOB)):
        with open(p) as f:
            cfgs.append(yaml.safe_load(f))
    cfgs.sort(key=lambda c: (c["name"] != "min1ch", c["name"]))
    return m, cfgs


def outputs(m, cfgs):
    return {
        "rtl/generated/sfs_map_pkg.sv": emit_sv_pkg(m),
        "rtl/generated/sfs_proto_enums.svh": emit_sv_enums(m),
        "rtl/generated/sfs_configs.svh": emit_sv_cfg(cfgs),
        "sw/include/generated/sfs_map.h": emit_c(m, cfgs),
        "docs/MEMORY_MAP.md": emit_md(m, cfgs),
    }


def selftest(m, cfgs):
    """Each mutation must be rejected by validate()."""
    def mut(fn):
        mm, cc = copy.deepcopy(m), copy.deepcopy(cfgs)
        fn(mm, cc)
        return mm, cc
    cases = {
        "page outside 10..15": lambda mm, cc: mm["cc_pages"].__setitem__("SYS", 9),
        "duplicate page": lambda mm, cc: mm["cc_pages"].__setitem__("CMD", 10),
        "misaligned register": lambda mm, cc: mm["blocks"][0]["regs"][1].__setitem__(1, 0x006),
        "overlapping register": lambda mm, cc: mm["blocks"][0]["regs"][1].__setitem__(1, 0x000),
        "register outside NAND stride": lambda mm, cc: mm["blocks"][3]["regs"][0].__setitem__(1, 0x100),
        "bad access type": lambda mm, cc: mm["blocks"][0]["regs"][0].__setitem__(2, "RX"),
        "fabric overlap": lambda mm, cc: mm["fabric"][1].__setitem__("base", 0x20000000),
        "fabric outside EXT": lambda mm, cc: mm["fabric"][1].__setitem__("base", 0x40000000),
        "fabric misaligned": lambda mm, cc: mm["fabric"][0].__setitem__("base", 0x20100000),
        "enum collision": lambda mm, cc: mm["enums"]["OP"]["values"]["READ"].__setitem__("v", 0x01),
        "enum too wide": lambda mm, cc: mm["enums"]["ST"]["values"]["SUCCESS"].__setitem__("v", 0x80),
        "cfg channels": lambda mm, cc: cc[0]["params"].__setitem__("NUM_NAND_CHANNELS", 9),
        "cfg bus width": lambda mm, cc: cc[0]["params"].__setitem__("CHANNEL_DATA_WIDTH", 32),
        "cfg dma width": lambda mm, cc: cc[0]["params"].__setitem__("DMA_DATA_WIDTH", 128),
        "cfg buffer": lambda mm, cc: cc[0]["params"].__setitem__("BUFFER_SIZE_BYTES", 20000),
        "cfg queue": lambda mm, cc: cc[0]["params"].__setitem__("CMD_QUEUE_DEPTH", 12),
        "cfg addr width": lambda mm, cc: cc[0]["params"].__setitem__("ADDRESS_WIDTH", 8),
        "cfg page": lambda mm, cc: cc[0]["params"].__setitem__("NAND_PAGE_BYTES", 500),
        "cfg missing": lambda mm, cc: cc[0]["params"].pop("ENABLE_ECC"),
    }
    ok = 0
    for name, fn in cases.items():
        mm, cc = mut(fn)
        try:
            validate(mm, cc)
            print(f"  FAIL  illegal map accepted: {name}")
        except MapError as e:
            ok += 1
            print(f"  PASS  rejected: {name}  ({e})")
    validate(m, cfgs)
    print(f"  PASS  reference map accepted")
    print(f"map selftest: {ok + 1}/{len(cases) + 1} PASS")
    return ok == len(cases)


def main():
    m, cfgs = load()
    try:
        validate(m, cfgs)
    except MapError as e:
        print(f"gen_map: ILLEGAL MAP: {e}")
        return 1
    if "--selftest" in sys.argv:
        return 0 if selftest(m, cfgs) else 1
    outs = outputs(m, cfgs)
    if "--check" in sys.argv:
        stale = []
        for rel, txt in outs.items():
            p = os.path.join(ROOT, rel)
            if not os.path.exists(p) or open(p).read() != txt:
                stale.append(rel)
        for s in stale:
            print(f"gen_map: STALE {s}")
        print(f"gen_map --check: {len(outs) - len(stale)}/{len(outs)} outputs up to date")
        return 1 if stale else 0
    for rel, txt in outs.items():
        p = os.path.join(ROOT, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(txt)
        print(f"gen_map: wrote {rel}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
