#!/usr/bin/env python3
"""SilicaFlux StorageCore -- regression.

  python3 scripts/regress.py [--unit] [--soc] [--quick] [-j N]

  map      gen_map --check + --selftest (illegal maps rejected)
  fw       firmware build (riscv64-unknown-elf-gcc)
  unit     tb/unit/tb_sfs_subsys: Icarus 12 x {min1ch, research4ch, noecc1ch}
                                  Verilator 5 x {min1ch, research4ch, noecc1ch}
  soc      tb/soc/tb_storage_soc (real firmware on the RTL CPU), Verilator:
             min1ch full, research4ch full, noecc1ch full, min1ch under host-memory back-pressure seed 2
Logs in reports/sim/, summary in reports/regression.md.  Exit 1 on any failure.
"""
import argparse
import concurrent.futures as cf
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = os.path.join(ROOT, "rtl")
SIM = os.path.join(ROOT, "reports", "sim")
BUILD = os.path.join(ROOT, "build")
MODELS = ["../tb/models/sfs_nand_flash_model.sv", "../tb/models/sfs_tb_hostmem.sv"]
VFLAGS = ["--binary", "--timing", "-O2", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
          "-Wno-MULTIDRIVEN"]
CFGS = ["min1ch", "research4ch", "noecc1ch"]


def defs(cfg):
    d = [f"+define+SFS_CFG_{cfg.upper()}"]
    if cfg == "research4ch":
        d.append("+define+SFS_MULTI")
    return d


def sh(cmd, cwd, log, timeout=None):
    t0 = time.time()
    with open(log, "w") as f:
        p = subprocess.run(cmd, cwd=cwd, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
    return p.returncode, time.time() - t0


def tail(log, pat):
    txt = open(log, errors="replace").read()
    m = re.findall(pat, txt)
    return m[-1] if m else None


def unit_icarus(cfg):
    out = os.path.join(BUILD, f"ivl_sub_{cfg}.vvp")
    log = os.path.join(SIM, f"unit_icarus_{cfg}.log")
    d = [x.replace("+define+", "-D") for x in defs(cfg)]
    rc, _ = sh(["iverilog", "-g2012", "-s", "tb_sfs_subsys", "-o", out] + d + ["-f", "files.f"] + MODELS +
               ["../tb/unit/tb_sfs_subsys.sv"], RTL, log + ".build")
    if rc:
        return ("unit", "icarus", cfg, "BUILD FAIL", 0)
    rc, t = sh(["vvp", "-n", out], ROOT, log, 3600)
    r = tail(log, r"tb_sfs_subsys \S+: (\d+) checks, (\d+) failures -> (\w+)")
    return ("unit", "icarus", cfg, f"{r[2]} ({r[0]} checks, {r[1]} failures)" if r else "NO RESULT", t)


def vbuild(top, tb, cfg, tag):
    mdir = os.path.join(BUILD, f"v_{tag}_{cfg}")
    log = os.path.join(SIM, f"{tag}_verilator_{cfg}.build.log")
    rc, t = sh(["verilator"] + VFLAGS + ["-j", "4"] + defs(cfg) + ["-f", "files.f"] + MODELS + [tb,
               "--top-module", top, "-Mdir", mdir, "-o", "Vtb"], RTL, log)
    return rc, os.path.join(mdir, "Vtb"), t


def unit_verilator(cfg):
    rc, exe, _ = vbuild("tb_sfs_subsys", "../tb/unit/tb_sfs_subsys.sv", cfg, "unit")
    if rc:
        return ("unit", "verilator", cfg, "BUILD FAIL", 0)
    log = os.path.join(SIM, f"unit_verilator_{cfg}.log")
    rc, t = sh([exe], ROOT, log, 3600)
    r = tail(log, r"tb_sfs_subsys \S+: (\d+) checks, (\d+) failures -> (\w+)")
    return ("unit", "verilator", cfg, f"{r[2]} ({r[0]} checks, {r[1]} failures)" if r else "NO RESULT", t)


def soc(cfg, scenario, extra, name):
    exe = os.path.join(BUILD, f"v_soc_{cfg}", "Vtb")
    log = os.path.join(SIM, f"soc_{name}.log")
    rc, t = sh([exe, f"+scenario={scenario}", "+fw=firmware/build/sfs_fw.hex"] + extra, ROOT, log, 7200)
    r = tail(log, r"tb_storage_soc \S+ \S+: (\d+) checks, (\d+) failures, (\d+) cycles -> (\w+)")
    res = f"{r[3]} ({r[0]} checks, {r[1]} failures, {int(r[2]):,} cycles)" if r else "NO RESULT"
    return ("soc", "verilator", name, res, t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--unit", action="store_true")
    ap.add_argument("--soc", action="store_true")
    ap.add_argument("-j", type=int, default=2)
    a = ap.parse_args()
    both = not a.unit and not a.soc
    os.makedirs(SIM, exist_ok=True)
    os.makedirs(BUILD, exist_ok=True)
    rows = []
    rc, _ = sh([sys.executable, "-B", "scripts/gen_map.py", "--check"], ROOT, os.path.join(SIM, "map_check.log"))
    rows.append(("map", "gen_map --check", "-", "PASS" if rc == 0 else "FAIL", 0))
    rc, _ = sh([sys.executable, "-B", "scripts/gen_map.py", "--selftest"], ROOT, os.path.join(SIM, "map_selftest.log"))
    r = tail(os.path.join(SIM, "map_selftest.log"), r"map selftest: (\S+) PASS")
    rows.append(("map", "gen_map --selftest", "-", f"PASS ({r})" if rc == 0 else "FAIL", 0))
    rc, _ = sh(["make", "-C", "firmware"], ROOT, os.path.join(SIM, "fw_build.log"))
    rows.append(("fw", "riscv64-unknown-elf-gcc", "-", "PASS" if rc == 0 else "FAIL", 0))
    jobs = []
    with cf.ThreadPoolExecutor(max_workers=a.j) as ex:
        if a.unit or both:
            for c in CFGS:
                jobs.append(ex.submit(unit_icarus, c))
                jobs.append(ex.submit(unit_verilator, c))
        if a.soc or both:
            def soc_cfg(c):
                rc, _, _ = vbuild("tb_storage_soc", "../tb/soc/tb_storage_soc.sv", c, "soc")
                if rc:
                    return [("soc", "verilator", c, "BUILD FAIL", 0)]
                out = [soc(c, "full", [], f"{c}_full")]
                if c == "min1ch":
                    out.append(soc(c, "full", ["+hm_seed=2"], f"{c}_full_seed2"))
                return out
            for c in CFGS:
                jobs.append(ex.submit(soc_cfg, c))
        for j in jobs:
            r = j.result()
            rows += r if isinstance(r, list) else [r]
            print(rows[-1], flush=True)
    ok = all(("PASS" in r[3]) for r in rows)
    rep = ["# Regression", "", f"Host: {os.uname().nodename}; tools: Verilator 5.020, Icarus Verilog 12.0, "
           "riscv64-unknown-elf-gcc 13.2, Python 3.", "",
           "| Kind | Tool | Configuration / run | Result | Wall time (s) |", "|---|---|---|---|---|"]
    for k, tool, cfg, res, t in rows:
        rep.append(f"| {k} | {tool} | `{cfg}` | {res} | {t:.0f} |")
    rep += ["", f"**Overall: {'PASS' if ok else 'FAIL'}** -- logs in `reports/sim/`.", ""]
    with open(os.path.join(ROOT, "reports", "regression.md"), "w") as f:
        f.write("\n".join(rep))
    print("\n".join(rep))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
