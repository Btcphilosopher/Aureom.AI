#!/usr/bin/env python3
"""SilicaFlux StorageCore -- verify that every vendored third_party/ file is byte-identical
to the corresponding member of the SilicaFlux archives in the Aureom.AI repository.

  python3 scripts/check_vendor.py --repo <path to the btcphilosopher/Aureom.AI checkout>

Also (re)writes third_party/SHA256SUMS.  Exit 1 on any difference or missing member.
"""
import argparse
import hashlib
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARCH = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5"
SOURCES = {
    # vendored directory           archive (relative to the repo)                       member prefix
    "silicaflux-controlcore": (f"{ARCH}/silicaflux-controlcore.zip", "silicaflux-controlcore/"),
    "silicaflux-ras":         (f"{ARCH}/silicaflux-ras-project26.zip", "silicaflux-ras/"),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    a = ap.parse_args()
    ok = bad = 0
    sums = []
    for d, (arch, prefix) in SOURCES.items():
        z = zipfile.ZipFile(os.path.join(a.repo, arch))
        names = set(z.namelist())
        base = os.path.join(ROOT, "third_party", d)
        for dp, dn, fs in os.walk(base):
            dn[:] = [x for x in dn if x != "__pycache__"]
            for fn in sorted(fs):
                p = os.path.join(dp, fn)
                rel = os.path.relpath(p, base)
                data = open(p, "rb").read()
                sums.append(f"{hashlib.sha256(data).hexdigest()}  {d}/{rel}")
                if rel == "third_party/PROVENANCE_CC.md":
                    member = prefix + "third_party/PROVENANCE.md"
                else:
                    member = prefix + rel
                if member not in names:
                    print(f"MISSING in {arch}: {member}")
                    bad += 1
                elif z.read(member) != data:
                    print(f"DIFFERENT: third_party/{d}/{rel}")
                    bad += 1
                else:
                    ok += 1
    with open(os.path.join(ROOT, "third_party", "SHA256SUMS"), "w") as f:
        f.write("\n".join(sums) + "\n")
    print(f"check_vendor: {ok}/{ok + bad} vendored files byte-identical to the repository archives")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
