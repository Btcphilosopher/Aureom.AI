# SilicaFlux StorageCore -- timing constraints (sfs_storage_subsys / silicaflux_storage_soc)
# One functional clock.  Target 100 MHz (the simulation clock); NOT closed on any technology.
create_clock -name clk -period 10.0 [get_ports clk]
set_clock_uncertainty 0.25 [get_clocks clk]
set_clock_transition  0.15 [get_clocks clk]

# synchronous ports: 40 % of the cycle budget outside the block
set sync_in  [remove_from_collection [all_inputs] [get_ports {clk rst_n rst_ni nand_rb_n* pwr_fail_ni}]]
set_input_delay  4.0 -clock clk $sync_in
set_output_delay 4.0 -clock clk [all_outputs]

# asynchronous inputs: 2-flop synchronisers (sfv_sync); reset: async assert, synchronised release
set_false_path -from [get_ports {nand_rb_n* pwr_fail_ni}]
set_false_path -from [get_ports {rst_n rst_ni}]

# NAND DQ is sampled by the controller's own RE# timing (tRP cycles): a single-cycle path at the pad
set_input_delay 2.0 -clock clk [get_ports {nand_dq_i*}]
