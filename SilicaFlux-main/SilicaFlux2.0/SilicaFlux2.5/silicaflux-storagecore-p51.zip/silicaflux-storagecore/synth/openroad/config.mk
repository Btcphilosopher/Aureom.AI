# =============================================================================
# SilicaFlux StorageCore -- OpenROAD-flow-scripts (ORFS) configuration
# Design: sfs_storage_subsys, configuration min1ch, platform IHP SG13G2 (the open PDK used by the
# SilicaFlux CLOCKTREE / IOSHELL projects).
#
# STATUS: PREPARED, NOT EXECUTED.  OpenROAD / ORFS and the PDK are not installed in this environment.
# Before running: (1) generate the Yosys-ready source with `python3 scripts/synth.py --quick`
# (synth/yosys/sfs_rtl_yosys.sv: package bodies hoisted, see docs/07), (2) replace the generic buffer
# SRAM by an SG13G2 macro (SRAM_BACKEND = ASIC, silicaflux-sramlib macro leaves) or keep it as flops for
# a first run, (3) make DESIGN_CONFIG=<this file>.
# =============================================================================
export DESIGN_NICKNAME = sfs_storage_subsys
export DESIGN_NAME     = sfs_storage_subsys
export PLATFORM        = ihp-sg13g2

export SFS_ROOT        = $(dir $(DESIGN_CONFIG))/../..
export VERILOG_FILES   = $(SFS_ROOT)/synth/yosys/sfs_rtl_yosys.sv \
                         $(wildcard $(SFS_ROOT)/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/*.sv) \
                         $(SFS_ROOT)/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/mem/sfb_sram_slave.sv \
                         $(SFS_ROOT)/third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/common/sfv_common.sv \
                         $(wildcard $(SFS_ROOT)/third_party/silicaflux-ras/rtl/*.sv) \
                         $(SFS_ROOT)/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv \
                         $(SFS_ROOT)/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv
export VERILOG_INCLUDE_DIRS = $(SFS_ROOT)/rtl/generated $(SFS_ROOT)/third_party/silicaflux-ras/rtl \
                         $(SFS_ROOT)/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem \
                         $(SFS_ROOT)/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/backends/asic
export SYNTH_HIERARCHICAL = 0
export VERILOG_DEFINES  = -DSYNTHESIS
export SDC_FILE        = $(dir $(DESIGN_CONFIG))/constraint.sdc

# floorplan: utilisation-driven first pass
export CORE_UTILIZATION = 45
export PLACE_DENSITY    = 0.60
export TNS_END_PERCENT  = 100
