# 06 — Verification

## 1. Environments

| Testbench | DUT | Stimulus / checking | Simulators |
|---|---|---|---|
| `tb/unit/tb_sfs_subsys.sv` | `sfs_storage_subsys` + one `sfs_nand_flash_model` per channel + `sfs_tb_hostmem` | testbench drives the real ports as **host** (BAR), as **firmware BFM** (the ControlCore accelerator register port — a clearly identified simulation host used only for fast block-level tests) and as **ControlCore EXT** master; 13 groups, self-checking | Icarus 12 and Verilator 5, every configuration |
| `tb/soc/tb_storage_soc.sv` | `silicaflux_storage_soc` (unmodified ControlCore CPU running `firmware/build/sfs_fw.hex`) + flash model(s) + host memory | testbench is a **host driver**: loads the firmware through the BAR, boots via the ControlCore boot ROM, enables the controller, submits SQ entries, waits on `host_irq_o`, checks CQ entries and host-memory data; 12 scenario groups; the firmware reports its own verdict through `SYSCTRL.TEST_CTRL` | Verilator 5, every configuration |

Both testbenches end with the flash model's protocol-error and pulse-width-violation counters asserted to be zero.

## 2. Requested test items → where they are covered

| Requested | Unit testbench (`tb_sfs_subsys`) | SoC testbench (`tb_storage_soc`, real firmware) |
|---|---|---|
| **Register access** | `regs`: identity/versions/CONFIG vs parameters, RW/RO/W1C, write to RO refused, unmapped offsets, absent pages 8/9/15, absent NAND channel, BAR ID/CAP, sub-word write refused, CQ-ring write refused, buffer byte strobes | `dod`: SHC ID/version/capacity; `security`: unmapped BAR / SHC offsets |
| **Command submission** | `hostq`: SQ ring + doorbell, fetch, tag-window contents, firmware pop/complete | every scenario (SQ ring, doorbell, CQ ring, phase) |
| **Memory reads/writes** | `nand`: ERASE/PROGRAM/READ_PAGE + partial read vs buffer; `e2e`: host→NAND→host | `dod`: WRITE 4 LBAs, READ back; `unmapped`: never-written / deallocated LBAs read zeros; `flush_phys`: physical write/read, data located in the NAND model |
| **DMA transfers** | `dma`: host→buffer, buffer→host, 4 queued descriptors (tag order), misaligned / length 0 → INVALID, unmapped source → READ_ERR + fault address, host IOMMU fault → WRITE_ERR, refused when host EN = 0, repair of an ECC word by DMA | all READ/WRITE/IDENTIFY/GET_LOG traffic; `backpressure`: 16-block transfers under 60 % host-memory back-pressure with up to 8 cycles latency |
| **Controller reset** | `ctrlreset`: EN 1→0 with owned tags, RESETTING until aborted, completions dropped + counted, queues and phase tags cleared, RESET_DONE, re-enable | `ctrlreset`: four 16-block writes in flight, EN 1→0, reset completes, queues cleared, controller usable afterwards, earlier data intact |
| **Interrupts** | `irq`: NAND completion on the IO line, IRQ_STATUS, drop after pop, masked source silent; `hostq`: host_irq with CQ pending and clears; `plp`: EVENT line, drops after FW_SAFE | host driver waits on `host_irq_o` for every completion; firmware runs fully interrupt-driven (IO/EVENT lines, deferred servicing, WFI) |
| **Backpressure** | `bp`: more commands than tags (SQ head stalls at tags + 1), FIFO order; CQ full → stall cycles counted; DMA under host-memory back-pressure | `backpressure`: host stops reaping; CQ fills to capacity; 4 more commands complete only after the host drains; CQ-full stall cycles in GET_LOG |
| **Invalid addresses** | `invalid`: LBA range, ADDR above ADDRESS_WIDTH, host buffer misaligned / outside window; `fabric`: unmapped fabric address, beyond the buffer, FAB_ERR_ADDR + RAS; `dma`: unmapped DMA source; `regs`: unmapped registers | `invalid`: LBA range, misaligned host buffer; `security`: unmapped BAR, locked storage pages, locked IMEM; `flush_phys`: physical block beyond the device |
| **Concurrent commands** | `hostq`: 4 commands owned at once, completed in reverse order, TIDs/results correct | `concurrency`: `CMD_QUEUE_DEPTH` writes in flight, then reads + IDENTIFY + FLUSH in flight; completions overtake each other (counted); every TID completes exactly once; data verified |
| **Status reporting** | `invalid`: hardware status + error code for 13 cases, REJECTED / LAST_REJECT; `nand`/`ecc`: NAND status codes, CE/UE counts, first UE index; `plp`, `bufecc`, `fabric`: RAS status / counters | every completion's status / error / result0 (blocks) / result1 (corrected bits); `ecc`: MEDIA_UNREC / NAND_ECC_UE; `plp`: ABORT_PWR_LOSS / QUIESCED, STATUS.PLP; GET_LOG counters; shutdown SHST |
| ECC / RAS | `ecc`: 3 single-bit errors corrected (data, data, ECC beat), double-bit → UNCORR, raw read sees the flip, erased page; `bufecc`: buffer FI single-bit corrected, double-bit → bus error + ext_fatal | `ecc`: bit flips injected into the NAND model under a mapped LBA: corrected (result1 = 1) and uncorrectable; rewrite heals |
| Power loss | `plp`: quiesce, new command aborted, drained, program allowed until FW_SAFE then refused, WP# pins, CLR | `plp`: power fails with 3 writes in flight → they drain, new write aborted, firmware checkpoints, WP# asserted, power returns, data written across the event reads back |
| Security | — | `security`: host access to storage pages refused (management lock), IMEM write refused (ControlCore lock), doorbell error flagged; `flush_phys`: PHYSICAL commands refused until the vendor mailbox command enables them |
| NAND protocol | `nand`: RESET, READ_ID bytes, READ_STATUS, WP refusal, bad block → PROG/ERASE FAIL, R/B# stuck → TIMEOUT | flash-model protocol / timing counters = 0 after the whole run |

## 3. Results

See `reports/regression.md` (generated by `scripts/regress.py`) and the logs in `reports/sim/`. The SoC log shows
the firmware console (`FW|` lines) interleaved with the host driver's checks.

## 4. Coverage gaps (honest)

* No formal proofs of the new blocks (the reused DataFabric / RAS / ControlCore blocks have their own).
* No mutation testing yet; no functional-coverage database (coverage is the scenario list above).
* The flash model is self-written: a vendor NAND model would be the independent reference.
* No randomised long-run stress (seeded host-memory back-pressure only).
