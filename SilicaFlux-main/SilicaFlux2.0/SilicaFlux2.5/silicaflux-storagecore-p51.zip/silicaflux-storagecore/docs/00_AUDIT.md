# 00 — Repository audit (Project 51 StorageCore)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/bold-sagan-aff892`, commit `e1f75e3`. As in every earlier
SilicaFlux project, the hardware work lives inside zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Every archive relevant to a storage controller was extracted and
read. "Evidence" is what the owning project recorded in its own reports; it was not re-run here unless stated.

## 1. What exists, and what this project does with it

| Area requested | Found | Evidence (owning project) | Decision |
|---|---|---|---|
| **ControlCore / RV32IM CPU** | `silicaflux-controlcore.zip` (Project 21): `silicaflux_control_core.sv` — MCU-I `mcu_cpu` RV32IM_Zicsr (machine mode), boot ROM with host/EXT image load + CRC32, 64 KiB IMEM / 32 KiB DMEM with parity, SFB2 crossbar, INTC, MTIMER, WDT, system DMA, mailbox, perf, PMU, RAS, security status; forwarded accelerator register pages 8..15, EXT SFB2 master port, host SFB2 slave port | riscv-tests 63/63, 6/6 system scenarios, 231 firmware self-checks, Verilator `-Wall` clean, Yosys + ECP5 P&R estimate | **Reused unmodified** as the storage firmware processor. Storage blocks attach to its forwarded pages 10..14, EXT port and accelerator IRQ/busy/RAS inputs. Boot ROM, image format, runtime (crt0, trap entry, link script, CRC32) reused unchanged. Vendored copies verified byte-identical (`scripts/check_vendor.py`: 69/69). |
| Other CPUs | `RISC-V CPU.zip` (`rv32i_core`), `cpu_core.zip`, `pipelined_cpu.zip`, `silicaflux.zip control_core.sv` (non-RISC-V) | no ISA suite / no traps | Not used. A simulation-host stand-in was therefore **not** needed for the SoC; the unit testbench uses a clearly labelled firmware BFM only for fast block-level tests. |
| **DataFabric** | `silicaflux-datafabric.zip`: SFB2 protocol (PROTOCOL.md R1–R12), `sfb_crossbar`, arbiters, register slice, `sfb_sram_slave`, DMA engines, protocol checker | formal proofs, regressions | **Reused unmodified**: `sfb_crossbar` is the storage fabric (and the host BAR splitter); `sfb_sram_slave` is the buffer when `ENABLE_RAS = 0`. SFB2 rules are the storage fabric's rules. |
| **DMA engines** | DataFabric `dma_transfer_engine` / `dma_burst_engine`; MCU-I `mcu_dma` (in ControlCore); HPC M05 tile DMA; TC07 tensor DMA | per project | ControlCore system DMA kept (boot). **New** `sfs_dma`: a storage DMA needs a descriptor queue with per-command tags and tagged completions, which none of the existing engines provide (single-transfer register interfaces or accelerator-internal). |
| **SRAM wrappers** | `silicaflux-sramlib.zip` (generic / FPGA / ASIC macro backends, MBIST); `silicaflux-sramgrid-p33` (floorplanned grids) | formal, synthesis | Reused through `sfb_sram_slave` / `sfras_ecc_sram` (generic backend in simulation; macro backends selectable via `SRAM_BACKEND`). |
| **ECC / RAS** | `silicaflux-ras-project26.zip`: `sfras_secded_enc/dec` (systematic extended Hamming, any K), `sfras_ecc_sram`, `sfras_sfb_ecc_slave` (SFB2 ECC SRAM: RMW, poison, fault injection, events) | 39 runs, 22/22 mutants, all-bit-position tests | **Reused unmodified**: the buffer SRAM is `sfras_sfb_ecc_slave` when `ENABLE_RAS = 1`; NAND page ECC uses `sfras_secded_enc/dec` with K = DMA_DATA_WIDTH. |
| **Interrupt controllers** | `mcu_intc` (16 sources, priorities, claim) inside the ControlCore; `sfv_intc` | MCU-I formal + unit | Used as-is through the ControlCore. Storage sources are aggregated by the new `sfs_sys_regs` into two lines that occupy the ControlCore's TENSOR (4) and VECTOR (5) IRQ slots. |
| **Clock / reset** | `sfv_rst_sync`, `sfv_sync`, `sfv_clkgate` (SilicaFlux-V); ControlCore reset generator; `silicaflux-clocktree-p35` (chip clock/reset tree), `silicaflux-powerclock` | per project | One core clock. ControlCore reset tree reused (POR / system / accelerator-domain reset); the storage subsystem runs on the ControlCore's accelerator-domain reset so firmware (PMU) can reset it. `sfv_sync` used for the two genuinely asynchronous storage inputs (NAND R/B#, power-fail). Chip-level P35 tree not integrated (single-clock SoC). |
| **Host-facing interfaces** | `silicaflux-hostlink-project25.zip`: PCIe BAR0 ABI, NVMe-style queues in host memory, AXI endpoint shell — TensorCore command set; ControlCore host port + mailbox | 144/144 co-sim runs; physical PCIe BLOCKED there | Not reused for the queue logic: its command ABI is accelerator-specific (DMA/GEMM) and its queues live in host memory behind a PCIe/AXI endpoint that does not exist in the repository. **New** `sfs_host_if` keeps HostLink's *model* (BAR registers + SQ/CQ + doorbells + interrupt) with storage opcodes and controller-memory rings, behind an SFB2 port that a future endpoint shell can drive. The ControlCore host port is reused for firmware load / mailbox through the same BAR. |
| Command queues | HPC M06 `hpc_command_queue`; tile / tensor command FIFOs | module regressions | Not reusable as a storage command controller (no validation, tags or completions). **New** `sfs_cmd_ctrl`. |
| NAND / flash | **Nothing.** No NAND controller, ONFI sequencer, flash model, FTL or storage firmware anywhere in the repository. `memory-recycler.zip`, `memorylab`, `memoryflow` are DRAM/analysis tools. | — | **New**: `sfs_nand_ctrl`, `tb/models/sfs_nand_flash_model.sv`, firmware FTL. |
| Power-loss protection | Nothing storage-specific (`powerclock` = DVFS/thermal) | — | **New** PLP logic in `sfs_sys_regs` + firmware drain / checkpoint / WP#. |
| Security | ControlCore: host write lock, BOOT_MEASURE, no authentication; `silicaflux-secureboot-p28.zip` exists (Project 28) | P28 own reports | ControlCore lock used; a storage management lock added. Project 28 authentication **not integrated** (out of scope; recorded in docs/08). |
| **FPGA flows** | Yosys + nextpnr-ecp5 (ULX3S) in MCU-I / ControlCore / M08 / TC08; no board runs anywhere | reports | Yosys `synth_ecp5` resource estimates here (nextpnr not installed in this environment; no P&R claimed). |
| **OpenROAD flows** | `silicaflux-clocktree-p35`, `dietop-p31`, `ioshell-p37` reference IHP SG13G2 / OpenROAD / OpenSTA work | their reports | `synth/openroad/` provides an ORFS configuration for the storage subsystem; **not executed** (OpenROAD is not installed in this environment). |

## 2. Dependency status

| Dependency | Status for this project |
|---|---|
| ControlCore (CPU, boot, INTC, WDT, RAS, mailbox) | implemented + verified upstream; re-exercised here by real firmware on the RTL in `tb_storage_soc` |
| DataFabric `sfb_crossbar`, `sfb_sram_slave` | implemented + verified upstream; re-exercised here (two crossbar instances) |
| RAS `sfras_*` ECC | implemented + verified upstream; re-exercised here (buffer CE/UE, fault injection, page ECC) |
| NAND controller, flash model, storage DMA, host queue interface, command controller, PLP, storage firmware/FTL | **missing in the repository → implemented here** |
| PCIe endpoint, NVMe compliance, real NAND devices, ONFI NV-DDR timing, BCH/LDPC ECC, garbage collection, wear levelling, authentication | **missing → not implemented** (docs/08) |

## 3. Unverified items inherited

* The ControlCore's ISA evidence is riscv-tests only (no compliance claim) — unchanged.
* No SilicaFlux block has run on an FPGA board or silicon — unchanged; nothing here either.
* No licence file exists in the repository (third_party/PROVENANCE.md).
