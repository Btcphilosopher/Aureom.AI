# 04 — Clock, reset, readiness, error propagation, quiescence

## 1. Clock

One functional clock, `clk` (simulated at 100 MHz). Every storage flop, the ControlCore, the storage fabric and the
NAND sequencer run on it. The ControlCore's gated accelerator clock (`acc_clk_o`) is deliberately **not** used in v1:
the storage subsystem is never idle long enough to justify a second (gated) domain, and an ungated domain avoids a
clock-gate / data race between `clk` and `acc_clk_o` in simulation. The NAND bus timing (tWP, tWH, tRP, tREH,
tWHR/tADL, tWB) is generated in clock cycles from `TIMING0/1`.

## 2. Asynchronous inputs (the only CDC in the design)

| Input | Why asynchronous | Treatment |
|---|---|---|
| `rst_ni` | board reset | ControlCore `sfv_rst_sync` (async assert, sync release); a second `sfv_rst_sync` for the BAR splitter |
| `host_rst_req_i`, `boot_mode_i` | host / straps | ControlCore `sfv_sync` (unchanged) |
| `nand_rb_n[c]` | NAND device ready/busy, open-drain, unrelated to `clk` | `sfv_sync` (2 flops) per channel in `sfs_nand_ctrl` |
| `pwr_fail_ni` | power supervisor | `sfv_sync` (2 flops, reset value "power good") in `sfs_sys_regs` |

NAND read data (`nand_dq_i`) is not a CDC: the controller itself drives RE# and samples DQ at the end of the
programmed tRP (the device's tREA must fit, which the flash model checks with its own timing assertions; an ONFI
NV-DDR source-synchronous interface would need a DQS capture path — docs/08). The host BAR and host-memory ports are
synchronous to `clk` in this SoC; a PCIe endpoint would bring its own clock and needs CDC FIFOs at the
`sfs_host_if` / host-memory boundary (future work, interfaces kept ready/valid for that reason).

## 3. Reset hierarchy and sequencing

```
rst_ni ──► ControlCore POR domain ──► system reset (POR | soft | watchdog | host request) ──► CPU, bus, IMEM/DMEM, peripherals
                                        └──► accelerator-domain reset = system AND NOT PMU.ACC_CTRL.RST ──► storage subsystem
rst_ni ──► BAR-split reset (POR only: the host can always reach the ControlCore host port, which stalls until ready)
```

1. **Assertion** is asynchronous everywhere; **release** is synchronous (reset synchronisers), so every storage flop
   leaves reset on the same edge.
2. After release, the storage subsystem is safe by construction: NAND CE# high, WP# low (`CH_CTRL = 0`), no queue
   entries, host interface disabled (`EN = 0`, `RDY = 0`), interrupts disabled, host memory refused (bus mastering
   off until the host sets `EN`).
3. **Peripheral readiness** (`SFS_SYS.READY`): `BUF_READY` rises when the ECC buffer has initialised every word
   (`sfras_ecc_sram` INIT_ON_RESET, DEPTH cycles); `NAND_IDLE`, `DMA_IDLE`, `CMD_IDLE`, `HIF_EN`, `HIF_RDY`, and the
   synchronised power-fail pin. The firmware waits for `BUF_READY`, then resets and identifies every channel
   (RESET waits for R/B#), and only then publishes capacity and accepts commands (`RDY`).
4. **Firmware-controlled storage reset**: `PMU.ACC_CTRL.RST` holds the storage subsystem in reset; releasing it
   repeats steps 2–3. A ControlCore soft / watchdog / host reset resets the storage subsystem as well.
5. **Host-controlled controller reset** (`SHC.CTRL.EN` 1→0, NVMe CC.EN model): fetching stops; the command already
   offered drains; the firmware receives EN_FALL, aborts every command it owns (state machines finish at the next
   step boundary with ABORT_RESET; hardware operations already started complete first); completions are dropped while
   resetting; when no tag is owned and no completion is pending the queues are cleared, phase tags cleared, `RDY = 0`,
   RESET_DONE. `EN` 0→1: firmware sets `RDY` again. NAND contents and the FTL are untouched.

## 4. Error propagation

| Source | Detected by | Propagation |
|---|---|---|
| invalid command | command controller | hardware completion (status + error code), counter, LAST_REJECT |
| NAND ECC correctable | `sfs_nand_ctrl` (SECDED) | corrected data written; NST_CORRECTED; result1 of the host completion; SYS counters; RAS NAND_CE |
| NAND ECC uncorrectable | `sfs_nand_ctrl` | NST_UNCORR → host MEDIA_UNREC / NAND_ECC_UE; RAS NAND_UE (warning enabled → ControlCore RAS) |
| NAND program / erase fail | device status byte | firmware retires the block and retries elsewhere (write) or reports MEDIA_WRITE / MEDIA_ERASE |
| NAND R/B# stuck | `TIMEOUT` counter | NST_TIMEOUT → MEDIA_TIMEOUT; RAS NAND_TMO |
| buffer SRAM CE / UE | `sfras_ecc_sram` | CE corrected silently + counted; UE → `rsp_error` on the fabric (DMA/NAND/CPU see a bus error) + RAS BUF_UE (fatal enabled → `ext_fatal` → ControlCore FATAL, `ras_fatal_o`) |
| fabric decode error | `sfb_crossbar` | `rsp_error` to the master, RAS FABRIC_DEC + FAB_ERR_ADDR |
| DMA bus error | `sfs_dma` | DST_READ_ERR / WRITE_ERR with the fault address → host DATA_XFER_ERR |
| firmware protocol errors | CMD / DMA / NAND queues | refused, flagged, RAS FW_PROTO |
| host doorbell error | `sfs_host_if` | value ignored, host EVT, HIF DB_ERR event, RAS HIF_DB |
| management access to locked pages | SoC `cc_sfb_gate` | `rsp_error` to the host, RAS SEC_VIOL, SEC_STATUS counter |
| controller fatal (firmware) | firmware | `SHC.STATUS.CFS` + host EVT interrupt |

## 5. Safe command quiescence (power loss)

1. `pwr_fail_ni` falls → (2-flop sync) → `PLP_STATUS.EVENT`, `QUIESCE`; host `STATUS.PLP`; EVENT interrupt.
2. Hardware immediately completes every *new* command with ABORT_PWR_LOSS / QUIESCED (nothing new reaches firmware).
3. Commands already owned by the firmware **drain to completion** (a half-written multi-block command is finished,
   not torn).
4. When `cmd_active == 0`, the firmware writes an FTL checkpoint (map, open blocks, bad-block table) to the metadata
   block, then sets `PLP_CTRL.FW_SAFE`; with `AUTO_WP` the hardware drives WP# low on every channel: no further
   program/erase can reach the media during the brown-out (the controller also refuses them, status WP).
5. Power returns (`pwr_fail_ni` high): firmware writes `PLP_CTRL.CLR`; WP# released; commands accepted again.

`PLP_STATUS.DRAINED` (no tag, DMA or NAND work) is exported for supervisors that want to cut power as early as
possible. The energy needed to finish steps 3–4 (hold-up capacitance) is a board-level budget not modelled here.
