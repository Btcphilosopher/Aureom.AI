# 08 — Lint, synthesis and physical-design preparation

## 1. Lint (`scripts/lint.py` → `reports/lint.md`)

* Verilator 5.020 `--lint-only -Wall`, both tops (`sfs_storage_subsys`, `silicaflux_storage_soc`), every
  configuration: **0 warnings in the new RTL**. Warnings inside `third_party/` (reused, unmodified sources) are
  listed separately and not counted — they belong to the projects that own those files (the ControlCore project
  itself lints with `-Wno-lint -Wno-style`).
* Icarus Verilog 12 elaborates every configuration of both tops.
* Illegal parameter sets (`CHANNEL_DATA_WIDTH = 12`, `DMA_DATA_WIDTH = 48`) are rejected by both tools
  (elaboration `$fatal` in Verilator, time-0 `$fatal` in Icarus). The address-map generator rejects 19 further
  illegal maps/configurations (`scripts/gen_map.py --selftest`).

## 2. Synthesis (`scripts/synth.py` → `reports/synth.md`)

Yosys 0.33, estimates only:

* **generic**: `synth -flatten` up to the fine stage, SRAMs kept as `$mem` cells (no memory library in a generic
  flow; mapping them to flip-flops would hide the logic), `techmap; abc`, then `check -assert` (fails on latches,
  combinational loops, multiple drivers) and `stat`;
* **FPGA**: `synth_ecp5 -abc9` (Lattice ECP5 — the family of the ControlCore / MCU-I flows; memories map to DP16KD
  block RAM). No place & route here (nextpnr is not installed in this environment).

Yosys 0.33 has no SystemVerilog `import`. `synth.py` therefore generates `synth/yosys/sfs_rtl_yosys.sv`, in which the
bodies of `sfs_map_pkg` and `silicaflux_storage_pkg` are hoisted to compilation-unit scope (Yosys accepts typedefs,
localparams and functions there) and the `import` lines are dropped; the sources are unchanged. To keep that
possible the RTL avoids constructs Yosys 0.33 cannot parse (`return`, `$bits(type)`, struct-typed function
arguments): the package conversion functions work on plain vectors.

Results (`reports/synth.md`):

| Configuration | Top | Generic cells (logic + FF) | generic FF | $mem cells (SRAMs, unmapped) | check -assert | ECP5 LUT4 | ECP5 FF | DP16KD |
|---|---|---|---|---|---|---|---|---|
| `min1ch` | `sfs_storage_subsys` | 24433 | 2957 | 14 | PASS | 6634 | 3086 | 10 |
| `min1ch` | `silicaflux_storage_soc` | 56660 | 6784 | 21 | PASS | 17962 | 6928 | 58 |
| `noecc1ch` | `sfs_storage_subsys` | 20574 | 2526 | 14 | PASS | 5288 | 2656 | 8 |
| `noecc1ch` | `silicaflux_storage_soc` | 52746 | 6353 | 21 | PASS | 16749 | 6498 | 56 |
| `research4ch` | `sfs_storage_subsys` | 46244 | 5668 | 20 | PASS | 13757 | 5927 | 36 |
| `research4ch` | `silicaflux_storage_soc` | 78667 | 9495 | 27 | PASS | 24881 | 9769 | 84 |

Reading the table: the storage subsystem of the minimal configuration is about 24 k generic gates + 3.0 k flip-flops
outside its SRAMs (≈ 6.6 k ECP5 LUT4); the whole SoC including the ControlCore CPU, boot ROM and control SRAMs is
≈ 18 k LUT4 and 58 DP16KD — within an LFE5U-85F by resource count (estimate only: no place & route was run here; the
ControlCore project placed and routed its own harness at 27 MHz on that device). `ENABLE_ECC/ENABLE_RAS = 0` saves
≈ 1.3 k LUT4 and two block RAMs; the 4-channel 64-bit research configuration roughly doubles the subsystem.

## 3. OpenROAD (prepared, not executed)

`synth/openroad/config.mk` + `constraint.sdc`: an OpenROAD-flow-scripts configuration for `sfs_storage_subsys` on
IHP SG13G2 (the open PDK used by the SilicaFlux CLOCKTREE / IOSHELL projects), 100 MHz single clock, false paths on
the asynchronous inputs (NAND R/B#, power-fail, resets). It has **not** been run: neither OpenROAD nor the PDK is
installed here, and the generic buffer SRAM must first be replaced by an SG13G2 macro (silicaflux-sramlib ASIC
backend) for a meaningful floorplan. No timing, area or power number from a physical flow is claimed.
