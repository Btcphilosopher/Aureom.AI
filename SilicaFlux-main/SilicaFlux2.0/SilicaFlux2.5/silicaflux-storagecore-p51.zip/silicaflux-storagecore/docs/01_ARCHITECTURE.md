# 01 — System architecture

## 1. Block diagram (minimal configuration `min1ch`)

```
                           simulated host  (testbench host driver; future: PCIe endpoint shell)
        BAR (SFB2 slave, 32-bit)  │                    ▲ host memory (SFB2 master, DMA_DATA_WIDTH)   ▲ host_irq_o
 ┌────────────────────────────────▼────────────────────┼─────────────────────────────────────────────┼───────────┐
 │ silicaflux_storage_soc                              │                                             │           │
 │  ┌──────────────────────┐ 0x0000_0000 MGMT ──► cc_sfb_gate (storage pages locked) ─► ControlCore host port      │
 │  │ BAR split            │                                                                                     │
 │  │ sfb_crossbar 1x2     │ 0x8000_0000 SHC ───┐                                                                │
 │  └──────────────────────┘                    │                                                                │
 │                                              ▼                                                                │
 │  ┌───────────────────────── sfs_storage_subsys ───────────────────────────────────────────────────────────┐   │
 │  │  sfs_host_if ── sfs_cmd_t ──► sfs_cmd_ctrl ── tag ──► firmware command queue (FWQ)                     │   │
 │  │  SQ/CQ rings ◄── sfs_cpl_t ─── (validation, tag table, completion arbiter)                             │   │
 │  │                                                                                                        │   │
 │  │                    Storage DataFabric  (sfb_crossbar, NM = 2 + NUM_NAND_CHANNELS, NS = 2, DW)          │   │
 │  │   m0 ControlCore EXT ─(sfs_sfb_upsizer)─┐                                ┌─► s0 BUF  SRAM buffer       │   │
 │  │   m1 sfs_dma ───────────────────────────┼──────── crossbar ──────────────┤   (sfras_sfb_ecc_slave)     │   │
 │  │   m2 sfs_nand_ctrl ch0 ─────────────────┘   (NAND masters: BUF only)    └─► s1 HOSTMEM ─ sfs_sfb_gate ─┼───┼─► hm_*
 │  │                                                                                                        │   │
 │  │   sfs_nand_ctrl ch0 ── CE# CLE ALE WE# RE# WP# DQ[7:0] R/B# ───────────────────────────────────────────┼───┼─► NAND
 │  │   sfs_sys_regs: identity/config, readiness, IRQ aggregation, PLP, security, RAS, perf counters        │   │
 │  └───────────────▲──────────────────────────────▲────────────────────────▲───────────────────────────────┘   │
 │        acc_rb pages 10..14            EXT (0x2000_0000..)       IRQ 4/5, busy, ext_warn/fatal, acc_rst_no    │
 │  ┌───────────────┴──────────────────────────────┴────────────────────────┴───────────────────────────────┐   │
 │  │ silicaflux_control_core (Project 21, UNMODIFIED): RV32IM CPU · boot ROM · IMEM/DMEM · INTC · MTIMER ·  │   │
 │  │ WDT · system DMA · mailbox · perf · PMU · RAS · security                                                │   │
 │  └────────────────────────────────────────────────────────────────────────────────────────────────────────┘   │
 └───────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

The requested chain **Host Interface → Command Controller → Storage DataFabric → SRAM Buffers → NAND Controller →
External Flash Model** maps to `sfs_host_if` → `sfs_cmd_ctrl` → storage `sfb_crossbar` → buffer SRAM → `sfs_nand_ctrl`
→ `sfs_nand_flash_model`, with the **ControlCore** firmware orchestrating every step.

## 2. Life of a command

1. Host writes a 32-byte SQ entry into the SQ ring (BAR `0x8000_1000 + 32·slot`) and rings `SQ_TAIL`.
2. `sfs_host_if` copies SQ[head] into an output register (immune to later host writes), advances the head and offers
   it as `sfs_cmd_t` (ready/valid).
3. `sfs_cmd_ctrl` validates it in one cycle. Invalid → a hardware completion with status/error code (the firmware
   never sees it). Valid → a free tag is allocated, the command is stored in the tag table, the tag is pushed into the
   firmware command queue and the IO interrupt is raised. No free tag → `cmd_ready = 0`: commands wait in the SQ.
4. Firmware (ControlCore CPU) pops the tag, reads the command from the tag window and runs a per-tag state machine:
   * READ: FTL lookup → NAND READ_PAGE (ECC decode on the fly) → buffer slot → storage DMA → host memory, per block;
   * WRITE: storage DMA host memory → slot → FTL allocates the next page of a pre-erased block → NAND PROGRAM
     (ECC encode on the fly) → L2P update, per block; FUA adds a checkpoint;
   * FLUSH / FUA / shutdown / power loss: FTL checkpoint to the metadata block;
   * IDENTIFY / GET_LOG: structure built in the slot → DMA → host; DEALLOCATE: L2P cleared; ERASE (physical).
   The tag is the hardware tag of every NAND and DMA operation of the command, so completions route back directly.
5. Firmware posts `{tag, status, error, result0, result1}`; the command controller attaches the command's TID from
   the tag table and offers `sfs_cpl_t`; the host interface writes CQ[tail] with the phase tag and SQ head and raises
   the host interrupt. A full CQ back-pressures the completion path. The tag is freed when the completion is accepted.

Many commands are in flight at once (up to `CMD_QUEUE_DEPTH`); they complete in the order they finish.

## 3. Parameters

| Parameter | Meaning | min1ch | research4ch | Legal |
|---|---|---|---|---|
| `NUM_NAND_CHANNELS` | NAND channel controllers (one fabric master and one register slice each) | 1 | 4 | 1..8 |
| `CHANNEL_DATA_WIDTH` | NAND DQ width | 8 | 16 | 8, 16 |
| `BUFFER_SIZE_BYTES` | SRAM buffer (power of two) | 16 KiB | 64 KiB | 4 KiB..16 MiB |
| `DMA_DATA_WIDTH` | storage fabric / DMA / buffer word; ECC word K | 32 | 64 | 32, 64 |
| `ADDRESS_WIDTH` | implemented storage-address bits (ABI field is 64-bit; higher bits → INVALID_FIELD/ADDR_WIDTH) | 32 | 40 | 16..64 |
| `CMD_QUEUE_DEPTH` | tags (commands owned by the controller); SQ/CQ entries = 2× (≤ 64) | 8 | 16 | 2..64, power of two |
| `ENABLE_ECC` | NAND page ECC (interleaved SECDED beat per word) | 1 | 1 | 0/1 |
| `ENABLE_RAS` | buffer SRAM SECDED + poison + fault injection (P26) instead of plain SRAM | 1 | 1 | 0/1 |
| `NAND_PAGE_BYTES` | user bytes per page (= logical block) | 512 | 512 | 64..16384 |

Configurations live in `config/configs/*.yaml` (`min1ch`, `research4ch`, `noecc1ch`); `scripts/gen_map.py`
validates them and emits `rtl/generated/sfs_configs.svh` (testbench parameter sets) and C defines. The firmware reads
the real values from `SFS_SYS.CONFIG0..2`, so one firmware image runs on every configuration.

## 4. New RTL

| File | Block | Notes |
|---|---|---|
| `rtl/silicaflux_storage_soc.sv` | SoC top | ControlCore + BAR split + management gate + storage subsystem |
| `rtl/sfs_storage_subsys.sv` | storage subsystem | everything storage-specific; testable without the CPU |
| `rtl/silicaflux_storage_pkg.sv` | protocol package | versioned `sfs_cmd_t` / `sfs_cpl_t`, enums (generated), packing |
| `rtl/sfs_host_if.sv` | host interface | SQ/CQ rings, doorbells + validation, EN/RDY reset handshake, shutdown, IRQ |
| `rtl/sfs_cmd_ctrl.sv` | command controller | validation, tag table, FWQ, completion posting, latency |
| `rtl/sfs_dma.sv` | storage DMA | 4-deep descriptor queue, tagged completions, abort |
| `rtl/sfs_nand_ctrl.sv` | NAND channel | ONFI-style SDR sequencer, op/cpl queues, inline SECDED, WP, timeout |
| `rtl/sfs_sys_regs.sv` | system page | identity, readiness, IRQ aggregation, PLP, security, RAS, perf |
| `rtl/sfs_fifo.sv`, `sfs_sfb_upsizer.sv`, `sfs_sfb_gate.sv` | infrastructure | FIFO; 32→DW SFB2 upsizer; width-generic refuse gate |
| `rtl/generated/*` | generated | address map package, enums, configuration sets |

## 5. Multi-channel research configuration

`research4ch`: four channels, x16 NAND bus, 64-bit fabric/DMA (the ControlCore's 32-bit EXT port is widened by
`sfs_sfb_upsizer`; a 32-bit CPU write into the 64-bit ECC buffer becomes a read-modify-write inside the P26 ECC
SRAM), 64 KiB buffer, 16 tags (32-entry SQ/CQ), 40-bit storage addresses. The FTL stripes writes round-robin over
channels; reads go to the channel that holds the page, so channels work in parallel. The fabric still allows one
outstanding transaction per port (SFB2 R6); its bandwidth, not the NAND bus, limits this configuration
(docs/08).
