# 03 — ControlCore integration and firmware interface

The ControlCore (Project 21) is instantiated **unmodified** (`third_party/silicaflux-controlcore/rtl/`,
`MIMPID = 0x0051_0001`). Nothing in it was edited; every attachment uses a port it already exposes.

## 1. Attachment points

| ControlCore port / feature | Storage use |
|---|---|
| `acc_rb_*` (forwarded register pages 8..15) | pages 10 SYS, 11 CMD, 12 DMA, 13 NAND (channel c at +0x100·c), 14 HIF; 8, 9, 15 answer a bus error |
| `ext_*` SFB2 master (EXT window `0x2000_0000..0x3FFF_FFFF`) | storage fabric master m0: buffer SRAM at `0x2000_0000`, host-memory window at `0x3000_0000` |
| `acc_tsu_irq_i` → INTC source 4 | storage **IO** line: command queue, DMA completions, NAND completions (`SFS_SYS.IRQ_EN_IO`) |
| `acc_vec_irq_i` → INTC source 5 | storage **EVENT** line: host-interface events, power loss, storage RAS (`SFS_SYS.IRQ_EN_EVT`) |
| `acc_vec_busy_i` / `acc_tsu_busy_i` | NAND busy / DMA-or-command busy (PMU idle detection, perf counters) |
| `ext_warn_i` / `ext_fatal_i` | storage RAS warnings / fatals → ControlCore RAS SOC_WARN / SOC_FATAL (→ `ras_fatal_o` pin) |
| `acc_rst_no` | storage subsystem reset (system reset AND NOT `PMU.ACC_CTRL.RST`): firmware can reset all storage logic |
| `acc_clk_o` | not used: the storage subsystem runs on the core clock (one clock domain in v1) |
| `acc_tsu_halted_i` | tied 0 |
| host port `hs_*` | BAR window `0x0000_0000..0x7FFF_FFFF` through a `cc_sfb_gate` that refuses host access to pages 10..15 when `SFS_SYS.SEC_CTRL.HOST_MGMT_LOCK = 1` |
| `host_irq_o` | `mgmt_irq_o` (mailbox F2H doorbell) |

The IRQ slot names in the ControlCore's generated header stay TENSOR/VECTOR; the storage firmware aliases them
(`SFS_CC_IRQ_IO = CC_IRQ_TENSOR`, `SFS_CC_IRQ_EVT = CC_IRQ_VECTOR`).

## 2. Boot

Identical to the ControlCore's verified flow (its docs/03_BOOT.md): `boot_mode_i = HOST`; the boot ROM scrubs and
tests DMEM/IMEM, waits in `WAIT_IMAGE`; the host writes `firmware/build/sfs_fw.hex` into IMEM through the BAR
(management window), sets `H2F_MSG0 = IMAGE_READY` and rings; the ROM checks header and CRC32 and jumps to the
firmware. The firmware then publishes boot stages:

| Stage | Firmware action |
|---|---|
| FW_INIT | INTC priorities (FATAL 7, WDT 6, RAS 5, storage EVENT 4, storage IO 3, DMA 2, HOST 2), timer tick, watchdog, RAS enables |
| ACC_DISCOVERY | `SFS_SYS.ID/PROTO_VERSION/CONFIG*`; wait `READY.BUF_READY`; per channel: timing, CE/WP enable, RESET, READ_ID (geometry table) |
| SELF_TEST | buffer pattern test; FTL: load newest checkpoint or format |
| CMDPROC_READY | capacity + MDTS published to the command controller; HIF events, RAS enables, `AUTO_WP`, storage management lock, ControlCore host write lock; storage IRQ lines armed |
| HOST_READY | mailbox: channel mask, capacity, CONFIG0, reset cause, firmware version, checkpoint sequence; `host_ready_o` pin; if the host already set `CTRL.EN`, `HIF.CTRL.RDY = 1` |

The image is integrity-checked (CRC32) only. **No authentication** (ControlCore SECURITY.CAPS, firmware banner,
IDENTIFY word 27 all say so). Project 28 secure boot is not integrated.

## 3. Firmware structure (`firmware/`)

| File | Content |
|---|---|
| `app/platform.c` | trap handler, INTC claim dispatch, timer tick + watchdog, RAS ISR, console, libc subset (derived from ControlCore `platform.c` / `libc_min.c`) |
| `app/hal.c` | discovery, channel bring-up, queue-slot accounting, NAND / DMA submission |
| `app/ftl.c` | page-mapped FTL, pre-erase, bad-block retirement, checkpoint job, boot load / format |
| `app/cmd.c` | per-tag command state machines, completion routing, IDENTIFY / GET_LOG builders |
| `app/main.c` | bring-up, event loop, host-interface / power-loss / RAS events, mailbox |
| ControlCore (unmodified) | `crt0.S`, `trap_entry.S`, `fw.ld`, `crc32.c`, `cc_hw.h`, generated `cc_memmap.h` / `cc_memory.ld`, `mkimage.py` |

Interrupt model: level sources, deferred processing. The storage ISRs only mask their line (`IRQ_EN_IO/EVT = 0`) and
return; the main loop services every queue until no progress is made, re-arms the lines and executes WFI. A source
that becomes pending while masked fires as soon as it is re-armed, so no event is lost; the 20 000-cycle timer tick
is a backstop. The power-loss source is not re-armed while the firmware drains (it stays asserted by design until
FW_SAFE).

Mailbox commands handled at run time: PING, `0x51` vendor SET_PHYS_EN (allows PHYSICAL commands), `0x52` STATS,
SHUTDOWN (final checkpoint, summary, `SYSCTRL.TEST_CTRL` done/fail for the testbench).

## 4. Hardware/software interface summary

* Command ownership: the firmware owns a tag from `FWQ_POP` to `CPL_POST`; the hardware refuses a CPL_POST for a tag
  the firmware does not own (`CMD.STATUS.FW_ERR`, RAS FW_PROTO).
* Every hardware queue has a free-slot register; the firmware checks it before submitting (`nand_free`, `dma_free`).
* The tag of a command is the hardware tag of all its NAND and DMA operations; tags with bit 7 set are internal
  (0x80|ch pre-erase, 0x90 checkpoint, 0xA0 boot).
* Buffer slots: slot t (`0x2000_0000 + 512·t`) belongs to tag t; slot `tags` holds checkpoint pages; slot `tags+1`
  is all zeros (source for unmapped reads).
