#!/usr/bin/env python3
"""
TENSORCORE 05 -- ABI consistency: rtl/tensor_quantize_pkg.sv <-> model/tq_ref.py.

Every opcode, version, rounding-mode code, flag bit, output-format code, reject
code, beat error code, field-mask bit, parameter-write status, counter index and
fixed field width defined in the RTL package must have the same value in the
Python reference (which generates every test vector).  Also checks the
intermediate-width formulas for IN_W 32..64, ASYM_EN 0/1.

  python3 tools/check_abi.py
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model"))
import tq_ref as R  # noqa: E402


def sv_consts(path):
    txt = open(path).read()
    out = {}
    for m in re.finditer(r"localparam\s+(?:logic\s*\[[^\]]+\]\s*|int\s+)(\w+)\s*=\s*([^;]+);", txt):
        name, val = m.group(1), m.group(2).strip()
        v = re.sub(r"\s", "", val)
        mm = re.fullmatch(r"(\d+)'([hdb])([0-9a-fA-F_]+)", v)
        if mm:
            out[name] = int(mm.group(3).replace("_", ""), {"h": 16, "d": 10, "b": 2}[mm.group(2)])
        elif re.fullmatch(r"\d+", v):
            out[name] = int(v)
    return out


def main():
    sv = sv_consts(os.path.join(ROOT, "rtl/tensor_quantize_pkg.sv"))
    py = {
        "OP_OPEN": R.OP_OPEN, "OP_CLOSE": R.OP_CLOSE, "VERSION": R.VERSION,
        "RM_RNE": R.RM_RNE, "RM_RTZ": R.RM_RTZ, "RM_RDN": R.RM_RDN, "RM_RUP": R.RM_RUP, "RM_RMM": R.RM_RMM,
        "FLB_BIAS": R.FL_BIAS.bit_length() - 1, "FLB_RQ": R.FL_RQ.bit_length() - 1,
        "FLB_PC": R.FL_PC.bit_length() - 1, "FLB_RELU": R.FL_RELU.bit_length() - 1,
        "FLB_WRAP": R.FL_WRAP.bit_length() - 1,
        "OFMT_INT32": R.OFMT_INT32, "OFMT_INT8": R.OFMT_INT8,
        "FMB_BIAS": R.FM_BIAS.bit_length() - 1, "FMB_MULT": R.FM_MULT.bit_length() - 1,
        "FMB_SHIFT": R.FM_SHIFT.bit_length() - 1, "FMB_ZP": R.FM_ZP.bit_length() - 1,
        "FMB_CS": R.FM_CS.bit_length() - 1, "NFIELD": 5,
        "PW_OK": R.PW_OK, "PW_GRP": R.PW_GRP, "PW_UNSUP": R.PW_UNSUP,
        "BIAS_W": R.BIAS_W, "MULT_W": R.MULT_W, "SHIFT_W": R.SHIFT_W, "ZP_W": R.ZP_W, "ZA_W": R.ZA_W,
        "OUT_W": R.OUT_W, "NPERF": R.NPERF,
    }
    for i, n in enumerate(R.QR_NAMES):
        py["QR_" + n] = i
    for i, n in enumerate(R.BE_NAMES):
        py["BE_" + n] = i
    for i, n in enumerate(R.PF_NAMES):
        py["PF_" + n] = i
    fails, n = [], 0
    for k, v in py.items():
        n += 1
        if k not in sv:
            fails.append(f"{k}: missing in RTL package")
        elif sv[k] != v:
            fails.append(f"{k}: RTL {sv[k]} != model {v}")
    for k in sv:
        if k not in py:
            fails.append(f"{k}: in RTL package but not checked against the model")
    # width formulas (the package functions mirror these lines)
    pkg = open(os.path.join(ROOT, "rtl/tensor_quantize_pkg.sv")).read()
    cw = re.search(r"function automatic int cw_of.*?if \(asym != 0\) cw_of = in_w \+ (\d+);\s*else\s*cw_of = BIAS_W;", pkg, re.S)
    xw = re.search(r"function automatic int xw_of.*?if \(asym != 0\) xw_of = in_w \+ (\d+);\s*else\s*xw_of = in_w \+ (\d+);", pkg, re.S)
    if not cw or not xw:
        fails.append("width functions not found in the RTL package")
    else:
        for in_w in range(32, 65):
            for asym in (0, 1):
                n += 1
                w = R.widths(in_w, asym)
                rcw = in_w + int(cw.group(1)) if asym else 32
                rxw = in_w + int(xw.group(1)) if asym else in_w + int(xw.group(2))
                if (rcw, rxw, rxw + 32, rxw + 33) != (w["CW"], w["XW"], w["PW"], w["YW"]):
                    fails.append(f"widths in_w={in_w} asym={asym}: RTL {(rcw, rxw)} model {w}")
    for f in fails:
        print("ABI MISMATCH:", f)
    print(f"ABI check: {n - len(fails)}/{n} items agree")
    print("RESULT:", "PASS" if not fails else "FAIL")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
