#!/usr/bin/env python3
"""
TENSORCORE 05 -- staged regression driver.

  tools/run_regress.py [--upto STAGE] [--quick] [--skip-verilator] [-j N] [--only NAME]

Bring-up order, as the brief requires (a stage runs only if every earlier stage
passed):
  stage 0  reference-model self-tests (tests/test_ref_model.py)
  stage 1  INT32 pass-through                       (unit, both simulators)
  stage 2  INT32 bias with saturation / wrap        (unit, both simulators)
  stage 3  symmetric INT8 requantisation, RNE, ReLU (unit, both simulators)
  stage 4  advanced: per-channel, rounding modes, INT32 requantisation,
           asymmetric inputs, errors, reset, GEMM datasets, soak, throughput,
           and the integration TC02 -> TC04 -> TC05 on the real array,
           over the configuration matrix.

A run passes only if the TB prints TB_RESULT: PASS and no simulator error line
appears; where Icarus and Verilator ran the same vectors with the same seed and
profile, their TB_ logs must be identical line for line.
Writes reports/regression_summary.md and reports/regression.json.
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
T2 = "third_party/tensorcore02/rtl/"
T4 = "third_party/tensorcore04/rtl/"
TQ = ["rtl/tensor_quantize_pkg.sv", T4 + "tensor_acc_fifo.sv", "rtl/tensor_quant_params.sv",
      "rtl/tensor_quant_lane.sv", "rtl/tensor_quantize.sv"]
INTEG = [T2 + f for f in ("tensor_pe.sv", "tensor_skew.sv", "tensor_output_collect.sv", "tensor_systolic_array.sv")] + \
        [T4 + f for f in ("tensor_acc_pkg.sv", "tensor_acc_fifo.sv", "tensor_acc_storage.sv",
                          "tensor_acc_out_router.sv", "tensor_accumulator.sv", "tensor_acc_subsystem.sv")] + \
        ["rtl/tensor_quantize_pkg.sv", "rtl/tensor_quant_params.sv", "rtl/tensor_quant_lane.sv",
         "rtl/tensor_quantize.sv", "integration/tensor_core_output.sv"]

PROF = {   # unit timing profiles
    "P0": "+ORDY=100",
    "P1": "+ORDY=50 +BGAP=20 +CGAP=20",
    "P2": "+ORDY=15 +OBURST=200 +BGAP=5 +CGAP=40",
    "P3": "+ORDY=90 +OBURST=50 +BGAP=60",
}
IPROF = {  # integration timing profiles
    "Q0": "+QRDY=100 +ORDY=100",
    "Q1": "+SGAP=20 +STALL=15 +QRDY=40 +ORDY=50",
    "Q2": "+SGAP=5 +STALL=40 +QRDY=10 +ORDY=20",
}
STAGE_SUITES = {1: ["s1_pass"], 2: ["s2_bias"], 3: ["s3_int8", "s3_ties"],
                4: ["s4_perchan", "s4_rmodes", "s4_ties", "s4_int32rq", "s4_asym", "s4_errors", "s4_reset",
                    "s4_gemm", "s4_soak"]}
ALL4 = STAGE_SUITES[4]


def U(name, stage, suites, rows=4, cols=4, in_w=32, ctx=2, grp=4, asym=0, ofifo=4, perf_w=32,
      sims=("icarus", "verilator"), profs=("P0", "P1", "P2", "P3"), seeds=(1, 2), scale=1.0, extra=""):
    return dict(kind="unit", name=name, stage=stage, suites=list(suites), rows=rows, cols=cols, in_w=in_w,
                ctx=ctx, grp=grp, asym=asym, ofifo=ofifo, perf_w=perf_w, sims=list(sims), profs=list(profs),
                seeds=list(seeds), scale=scale, extra=extra)


def I(name, suites, rows=4, cols=4, tiles=2, acc=32, grp=4, asym=0, sims=("icarus", "verilator"),
      profs=("Q0", "Q1", "Q2"), seeds=(1,), repeat=1):
    return dict(kind="integ", name=name, stage=4, suites=list(suites), rows=rows, cols=cols, tiles=tiles,
                acc=acc, grp=grp, asym=asym, sims=list(sims), profs=list(profs), seeds=list(seeds), repeat=repeat)


JOBS = [
    # ------------------------------------------------ stages 1-3: baseline, 4x4, both simulators
    U("S1_pass_4x4", 1, STAGE_SUITES[1], seeds=(1, 2, 3)),
    U("S1_pass_4x4_acc40", 1, STAGE_SUITES[1], in_w=40, sims=("icarus",)),
    U("S2_bias_4x4", 2, STAGE_SUITES[2], seeds=(1, 2, 3)),
    U("S2_bias_4x4_acc48", 2, STAGE_SUITES[2], in_w=48, sims=("icarus",)),
    U("S3_int8_4x4", 3, STAGE_SUITES[3], seeds=(1, 2, 3)),
    U("S3_int8_1x1", 3, STAGE_SUITES[3], rows=1, cols=1, ctx=1, grp=1, sims=("icarus",)),
    # ------------------------------------------------ stage 4: advanced, configuration matrix
    U("U_4x4_base", 4, ALL4, seeds=(1, 2, 3, 4)),
    U("U_4x4_asym", 4, ALL4, asym=1, seeds=(1, 2, 3)),
    U("U_3x5_in40_ctx3_asym", 4, ALL4, rows=3, cols=5, in_w=40, ctx=3, grp=5, asym=1, sims=("icarus",),
      profs=("P0", "P2")),
    U("U_4x4_in48", 4, ALL4, in_w=48, sims=("verilator",), profs=("P1", "P3")),
    U("U_2x2_in64_ctx4_asym", 4, ALL4, rows=2, cols=2, in_w=64, ctx=4, grp=3, asym=1, sims=("verilator",),
      profs=("P0", "P2")),
    U("U_1x1_ctx1", 4, ALL4, rows=1, cols=1, ctx=1, grp=1, sims=("icarus",), profs=("P1", "P2")),
    U("U_8x8", 4, ALL4, rows=8, cols=8, grp=2, sims=("verilator",), profs=("P0", "P2"), seeds=(1,)),
    U("U_16x16", 4, ["s4_perchan", "s4_ties", "s4_errors", "s4_soak"], rows=16, cols=16, grp=2,
      sims=("verilator",), profs=("P1",), seeds=(1,)),
    U("U_ofifo1", 4, ["s3_int8", "s4_soak", "s4_reset"], ofifo=1, sims=("icarus",), profs=("P0", "P2")),
    U("U_ofifo2", 4, ["s4_soak", "s4_errors"], ofifo=2, sims=("icarus",), profs=("P1", "P3")),
    U("U_ofifo8", 4, ["s4_soak", "s4_perchan"], ofifo=8, sims=("icarus",), profs=("P0", "P2")),
    U("U_perfw6_saturation", 4, ["s4_soak", "s4_gemm"], perf_w=6, sims=("icarus",), profs=("P1",), seeds=(1,)),
    U("U_soak_long", 4, ["s4_soak", "s4_gemm", "s4_ties"], sims=("verilator",), profs=("P1", "P2"),
      seeds=(5, 6, 7, 8), scale=6.0),
    U("U_soak_long_asym", 4, ["s4_soak", "s4_asym"], asym=1, sims=("verilator",), profs=("P2", "P3"),
      seeds=(5, 6, 7), scale=6.0),
    U("T_throughput", 4, ["p_stream"], sims=("icarus", "verilator"), profs=("P0",), seeds=(1,),
      extra="+NOSTALL"),
    # ------------------------------------------------ stage 4: integration on the real TC02 array + TC04
    I("I_4x4_base", ["baseline", "layers", "stress"]),
    I("I_4x4_asym", ["layers", "stress"], asym=1),
    I("I_4x4_acc40_asym", ["layers", "stress"], acc=40, asym=1, sims=("verilator",)),
    I("I_4x4_3slots", ["layers"], tiles=3, sims=("icarus",), profs=("Q1",)),
    I("I_2x2_asym", ["layers", "stress"], rows=2, cols=2, grp=3, asym=1, sims=("icarus",), profs=("Q0", "Q2")),
    I("I_8x8", ["layers"], rows=8, cols=8, grp=2, sims=("verilator",), profs=("Q1",)),
    I("I_4x4_long", ["layers"], sims=("verilator",), profs=("Q1", "Q2"), seeds=(2, 3, 4, 5), repeat=4),
    I("I_4x4_long_asym", ["layers", "stress"], asym=1, sims=("verilator",), profs=("Q1",), seeds=(6, 7, 8),
      repeat=3),
]


def sh(cmd, timeout=7200):
    t = time.time()
    r = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr, time.time() - t


def build(j, sim):
    bdir = f"build/{j['name']}_{sim}"
    os.makedirs(os.path.join(ROOT, bdir), exist_ok=True)
    if j["kind"] == "unit":
        top, srcs = "tb_tq", TQ + ["tb/tb_tq.sv"]
        ps = dict(ROWS=j["rows"], COLS=j["cols"], IN_W=j["in_w"], NUM_CTX=j["ctx"], NUM_GRP=j["grp"],
                  ASYM_EN=j["asym"], OFIFO_DEPTH=j["ofifo"], PERF_W=j["perf_w"])
    else:
        top, srcs = "tb_tq_integ", INTEG + ["tb/tb_tq_integ.sv"]
        ps = dict(ROWS=j["rows"], COLS=j["cols"], NUM_TILES=j["tiles"], ACC_W=j["acc"], NUM_GRP=j["grp"],
                  ASYM_EN=j["asym"])
    if sim == "icarus":
        p = " ".join(f"-P{top}.{k}={v}" for k, v in ps.items())
        rc, out, _ = sh(f"iverilog -g2012 -s {top} {p} -o {bdir}/sim.vvp {' '.join(srcs)}")
        return rc, out, f"vvp -n {bdir}/sim.vvp"
    g = " ".join(f"-G{k}={v}" for k, v in ps.items())
    rc, out, _ = sh(f"verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -j 2 --top-module {top} {g} "
                    f"--Mdir {bdir}/obj -o vsim {' '.join(srcs)}")
    return rc, out, f"{bdir}/obj/vsim"


def gen(j, suite, seed):
    vec = f"vectors/{j['name']}_{suite}_s{seed}.hex"
    if j["kind"] == "unit":
        cmd = (f"python3 tools/gen_unit.py --suite {suite} --rows {j['rows']} --cols {j['cols']} --in-w {j['in_w']} "
               f"--ctx {j['ctx']} --grp {j['grp']} --asym {j['asym']} --seed {seed} --scale {j['scale']} --out {vec}")
    else:
        cmd = (f"python3 tools/gen_integ.py --suite {suite} --rows {j['rows']} --cols {j['cols']} --tiles {j['tiles']} "
               f"--acc {j['acc']} --grp {j['grp']} --asym {j['asym']} --seed {seed} --repeat {j['repeat']} --out {vec}")
    rc, out, _ = sh(cmd)
    return rc, out, vec


def tb_core(out):
    return [l for l in out.splitlines() if l.startswith("TB_") and not l.startswith("TB_INFO")]


def run_job(j, sims_allowed):
    res = []
    sims = [s for s in j["sims"] if s in sims_allowed]
    exes = {}
    for s in sims:
        rc, out, exe = build(j, s)
        if rc != 0:
            res.append(dict(job=j["name"], stage=j["stage"], sim=s, suite="-", prof="-", seed="-", ok=False,
                            summary="BUILD FAILED: " + out[-400:].replace("\n", " ")))
        else:
            exes[s] = exe
    for suite in j["suites"]:
        for seed in j["seeds"]:
            rc, gout, vec = gen(j, suite, seed)
            if rc != 0:
                res.append(dict(job=j["name"], stage=j["stage"], sim="gen", suite=suite, prof="-", seed=seed,
                                ok=False, summary="GENERATOR FAILED: " + gout[-300:].replace("\n", " ")))
                continue
            for prof in j["profs"]:
                pa = (PROF if j["kind"] == "unit" else IPROF)[prof]
                cores = {}
                for s, exe in exes.items():
                    arg = "+VEC" if j["kind"] == "unit" else "+JOBS"
                    rc, out, t = sh(f"{exe} {arg}={vec} +SEED={seed} {pa} {j.get('extra', '')}")
                    ok = ("TB_RESULT: PASS" in out) and not re.search(r"^(%Error|ERROR:|.*\$error)", out, re.M)
                    summ = next((l for l in out.splitlines() if l.startswith("TB_SUMMARY")), "")
                    thr = next((l for l in out.splitlines() if l.startswith("TB_THROUGHPUT")), "")
                    errs = [l for l in out.splitlines() if "ERROR" in l][:3]
                    cores[s] = tb_core(out)
                    res.append(dict(job=j["name"], stage=j["stage"], sim=s, suite=suite, prof=prof, seed=seed, ok=ok,
                                    summary=(summ + " " + thr).strip() if ok else " | ".join(errs)[:600],
                                    seconds=round(t, 1)))
                if len(cores) == 2:
                    same = cores["icarus"] == cores["verilator"]
                    res.append(dict(job=j["name"], stage=j["stage"], sim="cross", suite=suite, prof=prof, seed=seed,
                                    ok=same, summary="icarus == verilator (TB_ logs identical)" if same else
                                    "LOGS DIFFER"))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--upto", type=int, default=4)
    ap.add_argument("--quick", action="store_true", help="one seed and one profile per job")
    ap.add_argument("--skip-verilator", action="store_true")
    ap.add_argument("-j", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default="reports/regression_summary.md")
    a = ap.parse_args()
    os.chdir(ROOT)
    os.makedirs("reports", exist_ok=True)
    os.makedirs("vectors", exist_ok=True)
    sims = {"icarus"} if a.skip_verilator else {"icarus", "verilator"}
    t0 = time.time()
    results = []
    rc, out, _ = sh("python3 tests/test_ref_model.py")
    results.append(dict(job="model_selftest", stage=0, sim="python", suite="-", prof="-", seed="-",
                        ok=rc == 0 and "RESULT: PASS" in out, summary=out.strip().splitlines()[-2]))
    print(results[-1]["summary"], flush=True)
    jobs = [j for j in JOBS if (not a.only or re.search(a.only, j["name"])) and j["stage"] <= a.upto]
    if a.quick:
        for j in jobs:
            j["seeds"] = j["seeds"][:1]
            j["profs"] = j["profs"][-1:]
    stop = not results[0]["ok"]
    for stage in (1, 2, 3, 4):
        sj = [j for j in jobs if j["stage"] == stage]
        if not sj:
            continue
        if stop:
            print(f"stage {stage}: NOT RUN (an earlier stage failed)")
            continue
        with cf.ThreadPoolExecutor(max_workers=a.j) as ex:
            for r in ex.map(lambda j: run_job(j, sims), sj):
                results += r
                for x in r:
                    if not x["ok"]:
                        print(f"  FAIL {x['job']} {x['sim']} {x['suite']} {x['prof']} s{x['seed']}: {x['summary'][:200]}",
                              flush=True)
        st = [r for r in results if r["stage"] == stage]
        npass = sum(r["ok"] for r in st)
        print(f"stage {stage}: {npass}/{len(st)} checks pass ({time.time() - t0:.0f}s)", flush=True)
        if npass != len(st):
            stop = True
    tot = len(results)
    npass = sum(r["ok"] for r in results)
    runs = [r for r in results if r["sim"] in ("icarus", "verilator")]
    with open(a.out, "w") as f:
        f.write("# TENSORCORE 05 regression summary\n\n")
        f.write(f"**{npass} / {tot} checks pass**: {sum(r['sim'] == 'icarus' for r in runs)} Icarus runs, "
                f"{sum(r['sim'] == 'verilator' for r in runs)} Verilator runs, "
                f"{sum(r['sim'] == 'cross' for r in results)} cross-simulator log comparisons, model self-test. "
                f"Wall time {time.time() - t0:.0f} s.\n\n")
        for s in range(0, 5):
            st = [r for r in results if r["stage"] == s]
            if st:
                f.write(f"* stage {s}: {sum(r['ok'] for r in st)} / {len(st)}\n")
        f.write("\n| stage | job | sim | suite | profile | seed | result | summary |\n|---|---|---|---|---|---|---|---|\n")
        for r in results:
            f.write(f"| {r['stage']} | {r['job']} | {r['sim']} | {r['suite']} | {r['prof']} | {r['seed']} | "
                    f"{'PASS' if r['ok'] else '**FAIL**'} | {r['summary'].replace('|', '/')} |\n")
    with open(os.path.splitext(a.out)[0].replace("_summary", "") + ".json", "w") as f:
        json.dump(dict(passed=npass, total=tot, results=results), f, indent=1)
    print(f"REGRESSION: {npass}/{tot} checks pass -> {a.out}")
    sys.exit(0 if npass == tot else 1)


if __name__ == "__main__":
    main()
