#!/usr/bin/env python3
"""
TENSORCORE 05 -- mutation testing.

Each mutant is a small, plausible design bug injected into a copy of the RTL.
The RTL's own simulation invariants are compiled out (+define+TQ_NO_INVARIANTS,
+define+TA_NO_INVARIANTS), so a mutant is KILLED only if the testbench itself
reports a failure.  The test plan runs fast suites first and stops at the first
kill.  A surviving mutant is either a test gap (fix the tests) or provably
equivalent (documented in docs/VERIFICATION.md).

  python3 tools/mutation_test.py [-j N] [--only m07]
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = ["rtl/tensor_quantize_pkg.sv", "third_party/tensorcore04/rtl/tensor_acc_fifo.sv",
         "rtl/tensor_quant_params.sv", "rtl/tensor_quant_lane.sv", "rtl/tensor_quantize.sv"]
L, T, P = "rtl/tensor_quant_lane.sv", "rtl/tensor_quantize.sv", "rtl/tensor_quant_params.sv"

MUTANTS = [
    # ---------------------------------------------------------------- rounding
    ("m01", "RNE ties rounded up (half-up)", L, [("RM_RNE: inc = g & (st | fl[0]);", "RM_RNE: inc = g;")]),
    ("m02", "RNE ties rounded down", L, [("RM_RNE: inc = g & (st | fl[0]);", "RM_RNE: inc = g & st;")]),
    ("m03", "RNE ties to odd", L, [("RM_RNE: inc = g & (st | fl[0]);", "RM_RNE: inc = g & (st | ~fl[0]);")]),
    ("m04", "RMM ties toward +inf", L, [("RM_RMM: inc = g & (st | ~neg);", "RM_RMM: inc = g;")]),
    ("m05", "RTZ implemented as floor", L, [("RM_RTZ: inc = neg & (g | st);", "RM_RTZ: inc = 1'b0;")]),
    ("m06", "RUP ignores the sticky bits", L, [("RM_RUP: inc = g | st;", "RM_RUP: inc = g;")]),
    ("m07", "guard bit taken one position too high", L,
     [("assign gm  = (s2 == 6'd0) ? '0 : (PW'(1) << (s2 - 6'd1));", "assign gm  = (s2 == 6'd0) ? '0 : (PW'(1) << s2);")]),
    ("m08", "sticky mask one bit short", L,
     [("((PW'(1) << (s2 - 6'd1)) - PW'(1))", "((PW'(1) << (s2 - 6'd2)) - PW'(1))")]),
    ("m09", "S = 0 not special-cased (guard = bit 63)", L,
     [("assign gm  = (s2 == 6'd0) ? '0 : (PW'(1) << (s2 - 6'd1));", "assign gm  = (PW'(1) << (s2 - 6'd1));")]),
    ("m10", "logical instead of arithmetic shift", L, [("assign fl  = p2 >>> s2;", "assign fl  = p2 >> s2;")]),
    ("m11", "sign taken from the wrong bit", L, [("assign neg = p2[PW-1];", "assign neg = p2[PW-2];")]),
    ("m12", "unsigned multiply", L, [("assign p_n = x * mult;", "assign p_n = $unsigned(x) * $unsigned(mult);")]),
    ("m13", "multiplier truncated to 31 bits", L, [("assign p_n = x * mult;", "assign p_n = x * $signed(mult[30:0]);")]),
    # ---------------------------------------------------------------- zero-point / saturation / activation
    ("m14", "output zero-point not added", L, [("assign y    = YW'(r) + YW'(z2);", "assign y    = YW'(r);")]),
    ("m15", "output zero-point subtracted", L, [("assign y    = YW'(r) + YW'(z2);", "assign y    = YW'(r) - YW'(z2);")]),
    ("m16", "INT8 max 126", L, [("YW'(127)  :", "YW'(126)  :")]),
    ("m17", "INT8 min -127", L, [("-YW'(128) :", "-YW'(127) :")]),
    ("m18", "INT32 max off by one", L, [("YW'(32'sh7FFF_FFFF)", "YW'(32'sh7FFF_FFFE)")]),
    ("m19", "saturation flag raised at the bound", L, [("assign hi   = (y > qmax);", "assign hi   = (y >= qmax);")]),
    ("m20", "WRAP ignored (always saturates)", L, [("if (wrap2)   qs = y[31:0];", "if (1'b0)   qs = y[31:0];")]),
    ("m21", "ReLU floor 0 instead of the zero-point", L,
     [("assign relu_hit = act2 & relu2 & (qs < z2);", "assign relu_hit = act2 & relu2 & (qs < 32'sd0);"),
      ("(relu_hit ? z2 : qs)", "(relu_hit ? 32'd0 : qs)")]),
    ("m22", "ReLU compares <= (counts equal values)", L,
     [("assign relu_hit = act2 & relu2 & (qs < z2);", "assign relu_hit = act2 & relu2 & (qs <= z2);")]),
    ("m23", "ReLU disabled", L, [("assign relu_hit = act2 & relu2 & (qs < z2);", "assign relu_hit = 1'b0;")]),
    # ---------------------------------------------------------------- bias / correction / snapshot
    ("m24", "bias not added", T, [("(XW'(acc) + XW'(be))", "XW'(acc)")]),
    ("m25", "bias subtracted", T, [("(XW'(acc) + XW'(be))", "(XW'(acc) - XW'(be))")]),
    ("m26", "input zero-point correction added (sign)", T,
     [("assign beff   = (f_bias ? CW'(tb) : CW'(0)) - csterm;", "assign beff   = (f_bias ? CW'(tb) : CW'(0)) + csterm;")]),
    ("m27", "input zero-point correction dropped", T,
     [("? CW'(csprod) : '0;", "? '0 : '0;")]),
    ("m28", "per-tensor / per-channel multiplier swapped", T, [("f_pc ? tm : d_mult;", "f_pc ? d_mult : tm;")]),
    ("m29", "per-channel shift ignored", T, [("f_pc ? rd_shift[j*6 +: 6] : d_shift;", "d_shift;")]),
    ("m30", "pass-through multiplier 0 instead of 1", T, [("!f_rq ? 32'd1 :", "!f_rq ? 32'd0 :")]),
    ("m31", "bias read live from the table at beat time (no snapshot)", T,
     [("assign be  = c_beff[bsel][j*CW +: CW];", "assign be  = CW'($signed(rd_bias[j*32 +: 32]));")]),
    ("m32", "element index: row not added to M0", T,
     [("(c_m0[bsel] + 32'(in_row))", "c_m0[bsel]")]),
    ("m33", "channel index not scaled by COLS", T, [("32'(d_grp) * 32'(COLS)", "32'(d_grp)")]),
    # ---------------------------------------------------------------- contexts / flow control
    ("m34", "context released by a wrong-tag last beat", T,
     [("assign b_rel  = b_acc & b_ctx_ok & b_tag_ok & in_last;", "assign b_rel  = b_acc & b_ctx_ok & in_last;")]),
    ("m35", "context never released", T,
     [("assign b_rel  = b_acc & b_ctx_ok & b_tag_ok & in_last;", "assign b_rel  = 1'b0;")]),
    ("m36", "OPEN accepted on a busy context", T,
     [("assign desc_ready = run_q & (~opener | ~c_open[dsel]);", "assign desc_ready = run_q;")]),
    ("m37", "beats accepted on a closed context", T,
     [("assign in_ready = run_q & (crd_q != '0) & ~b_stall;", "assign in_ready = run_q & (crd_q != '0);")]),
    ("m38", "one credit too many", T, [("crd_q <= CRW'(OFIFO_DEPTH);", "crd_q <= CRW'(OFIFO_DEPTH + 1);")]),
    ("m39", "credits not returned on pop", T,
     [("crd_q <= crd_q - CRW'(b_acc) + CRW'(ofifo_pop);", "crd_q <= crd_q - CRW'(b_acc);")]),
    ("m40", "no credit check (backpressure ignored)", T,
     [("assign in_ready = run_q & (crd_q != '0) & ~b_stall;", "assign in_ready = run_q & ~b_stall;")]),
    # ---------------------------------------------------------------- beat errors
    ("m41", "tag check missing", T, [("else if (!b_tag_ok)      b_code", "else if (1'b0)      b_code")]),
    ("m42", "poisoned context computed normally", T, [("else if (c_poison[bsel]) b_code", "else if (1'b0) b_code")]),
    ("m43", "frame check missing", T, [("else if (b_frame)        b_code", "else if (1'b0)        b_code")]),
    ("m44", "upstream error not propagated", T, [("else if (in_err)         b_code", "else if (1'b0)         b_code")]),
    ("m45", "upstream overflow flag not masked by col_mask", T,
     [("r1_iovf  <= in_ovf & in_col_mask;", "r1_iovf  <= in_ovf;")]),
    # ---------------------------------------------------------------- descriptor validation
    ("m46", "VERSION not checked", T, [("if (!ver_ok)                                       d_code",
                                         "if (1'b0)                                       d_code")]),
    ("m47", "word 7 reserved bits not checked", T, [("(d_r5b != 0) | (dw7 != 0);", "(d_r5b != 0);")]),
    ("m48", "RM 5 accepted", T, [("(d_rm > tensor_quantize_pkg::RM_RMM)", "(d_rm > 3'd5)")]),
    ("m49", "PC without RQ accepted", T, [("((f_pc && !f_rq) || (f_wrap", "((1'b0) || (f_wrap")]),
    ("m50", "unused fields not checked", T, [("else if (rsvd_unused)", "else if (1'b0)")]),
    ("m51", "zB != 0 accepted", T, [("d_zb != 0 || (za_nz", "1'b0 || (za_nz")]),
    ("m52", "M = ROWS + 1 accepted", T, [("(32'(d_m) > ROWS)", "(32'(d_m) > ROWS + 1)")]),
    ("m53", "M0 + M overflow not checked", T, [("> 33'h1_0000_0000);", "> 33'h1_FFFF_FFFF);")]),
    ("m54", "per-tensor zp 128 accepted", T, [("((d_zp > 32'sd127) ||", "((d_zp > 32'sd128) ||")]),
    ("m55", "channel group range not checked", T, [("else if (uses_table && !grp_in)", "else if (1'b0)")]),
    ("m56", "unloaded parameters accepted", T, [("(uses_table && (lane_missing != 0))", "(1'b0)")]),
    ("m57", "column sum not required for zA != 0", T,
     [("assign need       = {za_nz, f_pc, f_pc, f_pc, f_bias};", "assign need       = {1'b0, f_pc, f_pc, f_pc, f_bias};")]),
    ("m58", "per-channel zp range not checked", T, [("(f_pc && (lane_pzp_bad != 0))", "(1'b0)")]),
    ("m59", "CLOSE ignores the tag", T, [("!c_open[dsel] || c_tag[dsel] != d_tag", "!c_open[dsel]")]),
    ("m60", "hard rejects not reported", T, [("desc_rej      <= d_acc & d_poison;", "desc_rej      <= d_acc & d_poison & opener;")]),
    ("m61", "reject code not recorded in the sticky vector", T,
     [("if (d_acc && d_poison) desc_err_sticky[d_code] <= 1'b1;", "")]),
    # ---------------------------------------------------------------- parameter table
    ("m62", "lane mask ignored on writes", P, [("assign we = wr_ok & p_lane_mask[j];", "assign we = wr_ok;")]),
    ("m63", "field mask ignored for bias", P,
     [("if (we && fm[tensor_quantize_pkg::FMB_BIAS])  t_bias[wg]", "if (we)  t_bias[wg]")]),
    ("m64", "group range not checked on writes", P, [("assign grp_ok  = (32'(p_grp) < NUM_GRP);", "assign grp_ok  = 1'b1;")]),
    ("m65", "valid bits not cleared by reset", P, [("for (int g = 0; g < NUM_GRP; g++) t_vld[g] <= '0;", "")]),
    ("m66", "column-sum write with ASYM_EN = 0 accepted", P,
     [("assign unsup   = p_fmask[tensor_quantize_pkg::FMB_CS] & (ASYM_EN == 0);", "assign unsup   = 1'b0;")]),
    # ---------------------------------------------------------------- outputs / counters
    ("m67", "element counter counts masked lanes", T, [("b_acc ? popc(b_act) : '0;", "b_acc ? popc(in_col_mask) : '0;")]),
    ("m68", "counters wrap instead of saturating", T,
     [("cnt[i] <= s[PERF_W] ? {PERF_W{1'b1}} : s[PERF_W-1:0];", "cnt[i] <= s[PERF_W-1:0];")]),
    ("m69", "packed INT8 view misaligned", T, [("assign out_q8[j*8 +: 8] = out_data[j*32 +: 8];",
                                                  "assign out_q8[j*8 +: 8] = out_data[j*32 + 1 +: 8];")]),
    ("m70", "output format reported wrongly", T,
     [("assign out_fmt = of_fmt8 ? tensor_quantize_pkg::OFMT_INT8 : tensor_quantize_pkg::OFMT_INT32;",
       "assign out_fmt = tensor_quantize_pkg::OFMT_INT32;")]),
]

# Survivors proven equivalent (cannot change any output for any input the design accepts)
EQUIV = {
    "m11": "equivalent: |x*M| <= 2^(XW+30), so every product fits PW-1 bits and bit PW-2 equals the sign bit, "
           "except p = (-2^(XW-1))*(-2^31) = +2^(XW+30) exactly; its low S bits (S <= 63 <= XW+30) are all zero, "
           "so g = st = 0 and `neg` (only used ANDed with g|st) is never consulted.",
}

# test plan: (config, suite, profile args, extra), cheapest first; first failure kills
CFG = {
    "base": dict(ROWS=4, COLS=4, IN_W=32, NUM_CTX=2, NUM_GRP=4, ASYM_EN=0, OFIFO_DEPTH=4, PERF_W=32),
    "asym": dict(ROWS=4, COLS=4, IN_W=32, NUM_CTX=2, NUM_GRP=4, ASYM_EN=1, OFIFO_DEPTH=4, PERF_W=32),
    "ctx3": dict(ROWS=3, COLS=5, IN_W=40, NUM_CTX=3, NUM_GRP=5, ASYM_EN=1, OFIFO_DEPTH=4, PERF_W=32),
    "pw6": dict(ROWS=4, COLS=4, IN_W=32, NUM_CTX=2, NUM_GRP=4, ASYM_EN=0, OFIFO_DEPTH=4, PERF_W=6),
}
PLAN = [
    ("base", "s1_pass", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("base", "s2_bias", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("base", "s3_int8", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("base", "s3_ties", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("base", "s4_perchan", "+ORDY=15 +OBURST=200 +BGAP=5 +CGAP=40", ""),
    ("base", "s4_ties", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("base", "s4_int32rq", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("base", "s4_errors", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("base", "s4_reset", "+ORDY=15 +OBURST=200 +BGAP=5 +CGAP=40", ""),
    ("base", "s4_soak", "+ORDY=15 +OBURST=200 +BGAP=5 +CGAP=40", ""),
    ("base", "p_stream", "+ORDY=100", "+NOSTALL"),
    ("asym", "s4_asym", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("asym", "s4_gemm", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("asym", "s4_reset", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("asym", "s4_errors", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("ctx3", "s4_errors", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
    ("pw6", "s4_soak", "+ORDY=50 +BGAP=20 +CGAP=20", ""),
]


def sh(cmd, cwd=ROOT, timeout=1800):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr


def vec_name(cfg, suite):
    return os.path.join(ROOT, f"vectors/mut_{cfg}_{suite}.hex")


def gen_vectors():
    for cfg, suite, _, _ in PLAN:
        c = CFG[cfg]
        rc, out = sh(f"python3 tools/gen_unit.py --suite {suite} --rows {c['ROWS']} --cols {c['COLS']} "
                     f"--in-w {c['IN_W']} --ctx {c['NUM_CTX']} --grp {c['NUM_GRP']} --asym {c['ASYM_EN']} "
                     f"--seed 11 --out {vec_name(cfg, suite)}")
        if rc:
            sys.exit("generator failed: " + out)


def build(d, cfg):
    c = CFG[cfg]
    ps = " ".join(f"-Ptb_tq.{k}={v}" for k, v in c.items())
    srcs = " ".join(os.path.join(d, os.path.basename(f)) for f in FILES)
    rc, out = sh(f"iverilog -g2012 -DTQ_NO_INVARIANTS -DTA_NO_INVARIANTS -s tb_tq {ps} -o {d}/{cfg}.vvp {srcs} "
                 f"{ROOT}/tb/tb_tq.sv")
    return rc == 0, out


def run_mutant(m, keep=False):
    mid, desc, f, edits = m
    d = os.path.join(ROOT, "build", "mut", mid)
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    for src in FILES:
        shutil.copy(os.path.join(ROOT, src), d)
    p = os.path.join(d, os.path.basename(f))
    txt = open(p).read()
    for old, new in edits:
        if txt.count(old) != 1:
            return dict(id=mid, desc=desc, status="BAD_MUTANT", detail=f"pattern found {txt.count(old)} times: {old}")
        txt = txt.replace(old, new)
    open(p, "w").write(txt)
    built = {}
    for cfg, suite, prof, extra in PLAN:
        if cfg not in built:
            ok, out = build(d, cfg)
            built[cfg] = ok
            if not ok:
                return dict(id=mid, desc=desc, status="KILLED", detail=f"does not compile ({cfg})", by="compile")
        try:
            rc, out = sh(f"vvp -n {d}/{cfg}.vvp +VEC={vec_name(cfg, suite)} +SEED=3 {prof} {extra}", timeout=600)
        except subprocess.TimeoutExpired:
            return dict(id=mid, desc=desc, status="KILLED", detail="simulation hang", by=f"{cfg}:{suite}")
        if "TB_RESULT: PASS" not in out:
            first = next((l for l in out.splitlines() if "TB_ERROR" in l or "FAIL" in l), "")
            if not keep:
                shutil.rmtree(d, ignore_errors=True)
            return dict(id=mid, desc=desc, status="KILLED", by=f"{cfg}:{suite}", detail=first[:200])
    if not keep:
        shutil.rmtree(d, ignore_errors=True)
    return dict(id=mid, desc=desc, status="SURVIVED", by="-", detail="no test failed")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-j", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    t0 = time.time()
    gen_vectors()
    # the unmutated design must pass the whole plan
    ref = run_mutant(("m00", "unmutated reference", T, []))
    if ref["status"] != "SURVIVED":
        sys.exit(f"reference design fails the mutation plan: {ref}")
    ms = [m for m in MUTANTS if not a.only or re.search(a.only, m[0])]
    with cf.ThreadPoolExecutor(max_workers=a.j) as ex:
        res = list(ex.map(run_mutant, ms))
    for r in res:
        if r["status"] == "SURVIVED" and r["id"] in EQUIV:
            r["status"] = "EQUIVALENT"
            r["detail"] = EQUIV[r["id"]]
    killed = sum(r["status"] == "KILLED" for r in res)
    equiv = [r for r in res if r["status"] == "EQUIVALENT"]
    surv = [r for r in res if r["status"] == "SURVIVED"]
    bad = [r for r in res if r["status"] == "BAD_MUTANT"]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports/mutation_report.md"), "w") as f:
        f.write("# TENSORCORE 05 mutation report\n\n")
        f.write(f"**{killed} / {len(res)} mutants killed** by the testbench alone (RTL invariants compiled out); "
                f"{len(equiv)} proven equivalent; {len(surv)} unexplained survivors; {len(bad)} malformed. "
                f"Wall time {time.time() - t0:.0f} s.\n\n")
        f.write("| id | injected bug | result | killed by | first failure |\n|---|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['id']} | {r['desc']} | {r['status']} | {r.get('by', '-')} | "
                    f"{r['detail'].replace('|', '/')} |\n")
    with open(os.path.join(ROOT, "reports/mutation_results.json"), "w") as f:
        json.dump(res, f, indent=1)
    for r in res:
        print(f"{r['id']} {r['status']:9s} {r.get('by', '-'):22s} {r['desc']}")
    print(f"MUTATION: {killed}/{len(res)} killed, {len(equiv)} equivalent, {len(surv)} unexplained survivors, "
          f"{len(bad)} malformed")
    sys.exit(0 if not bad and not surv else 1)


if __name__ == "__main__":
    main()
