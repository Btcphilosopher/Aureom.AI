#!/usr/bin/env python3
"""
TENSORCORE 05 -- stimulus coverage of the numeric corner cases.

Regenerates the unit vectors of the baseline (4x4, IN_W 32) and asymmetric
regression jobs (same suites and seeds as tools/run_regress.py) and aggregates
the generator's coverage counters: exact rounding ties that reach the output
unsaturated, per rounding mode (and how many of them have an even floor, where
RNE and round-half-up differ), near-ties, distinct shifts, negative and zero
multipliers, saturation in each direction, explicit wrap, ReLU outputs exactly
at the zero-point, and the descriptor reject codes exercised.

  python3 tools/coverage.py      -> reports/coverage.md
"""
import ast
import collections
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import run_regress as RR  # noqa: E402

JOBS = ["S1_pass_4x4", "S2_bias_4x4", "S3_int8_4x4", "U_4x4_base", "U_4x4_asym"]


def main():
    tot = collections.Counter()
    ties = collections.Counter()
    even = collections.Counter()
    rej = collections.Counter()
    shiftmask = 0
    for j in RR.JOBS:
        if j["name"] not in JOBS:
            continue
        for suite in j["suites"]:
            for seed in j["seeds"]:
                cmd = (f"python3 tools/gen_unit.py --suite {suite} --rows {j['rows']} --cols {j['cols']} "
                       f"--in-w {j['in_w']} --ctx {j['ctx']} --grp {j['grp']} --asym {j['asym']} --seed {seed} "
                       f"--out build/cov.hex")
                out = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True).stdout
                g = next(l for l in out.splitlines() if l.startswith("GEN"))
                c = next(l for l in out.splitlines() if l.startswith("COV"))
                for k in ("beats", "elems", "descs", "pws", "sat", "relu", "resets"):
                    tot[k] += int(re.search(rf"\b{k}=(\d+)", g).group(1))
                rd = ast.literal_eval(re.search(r"rejects=\d+ (\{.*\})", g).group(1))
                rej.update(rd)
                lt = ast.literal_eval(re.search(r"live_ties=(\{[^}]*\})", c).group(1))
                ev = ast.literal_eval(re.search(r"even-floor (\{[^}]*\})", c).group(1))
                ties.update(lt)
                even.update(ev)
                for k in ("near_ties", "neg_mult", "zero_mult", "sat_hi", "sat_lo", "wrap", "relu_at_zp"):
                    tot[k] += int(re.search(rf"\b{k}=(\d+)", c).group(1))
                shiftmask |= int(re.search(r"shiftmask=(0x[0-9a-f]+|0)", c).group(1), 0)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports/coverage.md"), "w") as f:
        f.write("# TENSORCORE 05 stimulus coverage (unit vectors of the baseline and asymmetric jobs)\n\n")
        f.write(f"Jobs: {', '.join(JOBS)} (all their suites and seeds).\n\n")
        f.write(f"* beats {tot['beats']}, elements {tot['elems']}, descriptors {tot['descs']}, parameter writes "
                f"{tot['pws']}, resets {tot['resets']}\n")
        f.write(f"* saturated elements {tot['sat']} (high {tot['sat_hi']}, low {tot['sat_lo']}, explicit wrap "
                f"{tot['wrap']}); ReLU raised {tot['relu']}; outputs exactly at the zero-point under ReLU "
                f"{tot['relu_at_zp']}\n")
        nsh = bin(shiftmask).count("1")
        f.write(f"* negative multipliers {tot['neg_mult']}, zero multipliers {tot['zero_mult']}; requantising "
                f"shifts S used: {nsh} of 64" + (" (every S = 0..63)" if nsh == 64 else f" (mask {shiftmask:#x})") + "\n")
        f.write(f"* near-ties (sticky set, within 2^-20 of 1/2): {tot['near_ties']}\n\n")
        f.write("| rounding mode | exact ties reaching the output unsaturated | of which even floor |\n|---|---|---|\n")
        for m in ("RNE", "RTZ", "RDN", "RUP", "RMM"):
            f.write(f"| {m} | {ties[m]} | {even[m]} |\n")
        f.write("\n| descriptor reject code | times exercised |\n|---|---|\n")
        for k, v in sorted(rej.items()):
            f.write(f"| {k} | {v} |\n")
    print(open(os.path.join(ROOT, "reports/coverage.md")).read())


if __name__ == "__main__":
    main()
