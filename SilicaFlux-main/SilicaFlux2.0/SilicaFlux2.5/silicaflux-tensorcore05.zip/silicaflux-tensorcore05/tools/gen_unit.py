#!/usr/bin/env python3
"""
TENSORCORE 05 -- unit-test vector generator for tb/tb_tq.sv.

  tools/gen_unit.py --suite <name> [--rows R --cols C --in-w W --ctx N --grp G --asym A]
                    [--seed S] --out vectors/x.hex

Every expected output beat is computed by model/tq_ref.py (Fraction-based
integer reference), never by re-implementing the RTL algorithm.

Ordering rules that make expected values deterministic although the TB drives
the control port (parameters + descriptors, in list order) and the beat port
concurrently with random timing:
  * traffic is emitted in WAVES; a wave opens at most one tile per context;
  * all control commands of wave w precede its beats in the list, and all beats
    of wave w precede the control commands of wave w+1 for any context that
    wave w uses -- so a descriptor can only wait for beats that are already
    queued ahead of it (no deadlock), and a beat always meets its own tile;
  * a parameter write placed after a descriptor can never reach that tile
    (the snapshot is taken when the descriptor is accepted): this is exactly
    what the association tests rely on;
  * stray (wrong-tag) beats are placed before the last beat of an open tile
    on their context, so they meet a context that is open.

Suites, in bring-up order (tools/run_regress.py enforces it):
  stage 1  s1_pass    INT32 pass-through
  stage 2  s2_bias    + per-channel INT32 bias, saturation, explicit wrap
  stage 3  s3_int8    + INT8 requantisation, per-tensor, RNE, ReLU, boundaries
  stage 4  s4_perchan per-channel M/S/zp, parameter reload in flight, same-cycle write+desc
           s4_rmodes  RTZ/RDN/RUP/RMM, dense ties for every shift 0..63
           s4_int32rq requantisation to INT32, saturation and wrap
           s4_asym    input zero-point correction (ASYM_EN=1) / rejection (ASYM_EN=0)
           s4_errors  every descriptor / beat / parameter error path, CLOSE, stickies
           s4_reset   reset at random points, state really cleared
           s4_gemm    representative quantised GEMM layers (per-tensor / per-channel)
           s4_soak    random mix of everything
"""
import argparse
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
import tq_ref as R  # noqa: E402

MAGIC = 0x7C051001
OP_PW, OP_DESC, OP_BEAT, OP_SAME, OP_RESET, OP_DRAIN, OP_PERF, OP_PERFCLR, OP_SYNC, OP_STATUS, OP_STICKY, \
    OP_BSYNC = range(1, 13)
CTL_OPS = (OP_PW, OP_DESC, OP_SAME, OP_SYNC)
KIND = {"none": 0, "open": 1, "poison": 2, "close": 3}


def u32(v):
    return v & 0xFFFFFFFF


class Gen:
    def __init__(self, cfg, seed):
        self.c = cfg
        self.m = R.TQModel(cfg)
        self.rnd = random.Random(seed)
        self.cmds = []
        self.tag = 1
        self.beats_since_reset = 0
        self.sticky = [0, 0, 0]          # desc, beat, param
        self.ctl_since_reset = 0
        self.stats = dict(beats=0, elems=0, descs=0, pws=0, ties=0, sat=0, relu=0, resets=0, rej={})
        self.cov = dict(live_tie={m: 0 for m in R.RM_NAMES}, live_tie_even={m: 0 for m in R.RM_NAMES},
                        near_tie=0, shifts=set(), neg_mult=0, zero_mult=0, sat_hi=0, sat_lo=0,
                        relu_at_zp=0, wrap=0)

    # ------------------------------------------------------------------ emitters
    def new_tag(self):
        t = self.tag
        self.tag = (self.tag % 0xFFF0) + 1
        return t

    def lane_words(self, l):
        cs = R.ux(l.get("cs", 0), 64)
        return [u32(l.get("bias", 0)), u32(l.get("mult", 0)), l.get("shift", 0) & 0x3F, u32(l.get("zp", 0)),
                cs & 0xFFFFFFFF, cs >> 32]

    def pw_payload(self, grp, lane_mask, fmask, lanes):
        code = self.m.param_write(grp, lane_mask, fmask, lanes)
        if code:
            self.sticky[2] |= 1 << code
        self.stats["pws"] += 1
        w = [grp, lane_mask, fmask, code]
        for j in range(self.c.cols):
            w += self.lane_words(lanes[j])
        return w

    def pw(self, grp, lane_mask, fmask, lanes):
        p = self.pw_payload(grp, lane_mask, fmask, lanes)
        self.cmds.append((OP_PW, p))
        return p[3]

    def desc_payload(self, words):
        code, kind, snap = self.m.desc(words)
        if code:
            self.sticky[0] |= 1 << code
            self.stats["rej"][R.QR_NAMES[code]] = self.stats["rej"].get(R.QR_NAMES[code], 0) + 1
        self.stats["descs"] += 1
        return [u32(x) for x in words] + [code, KIND[kind]], code, kind, snap

    def desc(self, words):
        p, code, kind, snap = self.desc_payload(words)
        self.cmds.append((OP_DESC, p))
        return code, kind, snap

    def same_cycle(self, pw_args, words):
        """Parameter write and descriptor accepted in the same clock cycle: the descriptor
        must see the OLD table contents."""
        dp, code, kind, snap = self.desc_payload(words)      # descriptor first (old table)
        pp = self.pw_payload(*pw_args)                       # then the write
        self.cmds.append((OP_SAME, pp + dp))
        return code, kind, snap

    def beat(self, snap, ctx, tag, row, mask, last, err=0, data=None, ovf=0):
        c = self.c
        data = data if data is not None else [0] * c.cols
        e = self.m.eval_beat(snap, ctx, tag, row, mask, last, err, data, ovf)
        if snap is not None and not snap.poison and snap.tag == tag and e["code"] in (R.BE_NONE, R.BE_UPSTREAM):
            for j in range(c.cols):
                l = snap.lanes[j]
                if l is None or not ((mask >> j) & 1):
                    continue
                x = data[j] + l["bias"] - snap.za * l["cs"]
                y_ok = not ((e["sat"] >> j) & 1)
                if snap.rq:
                    sh, mu = l["shift"], l["mult"]
                    self.cov["shifts"].add(sh)
                    self.cov["neg_mult"] += int(mu < 0)
                    self.cov["zero_mult"] += int(mu == 0)
                    if sh > 0 and y_ok:
                        rem = (x * mu) % (1 << sh)
                        if rem == 1 << (sh - 1):
                            self.cov["live_tie"][snap.rm] += 1
                            self.cov["live_tie_even"][snap.rm] += int(((x * mu) >> sh) % 2 == 0)
                        elif abs(rem - (1 << (sh - 1))) <= max(1, (1 << sh) >> 20):
                            self.cov["near_tie"] += 1
                if (e["sat"] >> j) & 1:
                    hi = R.FMT_RANGE[snap.ofmt][1]
                    if snap.wrap:
                        self.cov["wrap"] += 1
                    elif e["data"][j] == hi or (snap.relu and e["data"][j] > 0):
                        self.cov["sat_hi"] += 1
                    else:
                        self.cov["sat_lo"] += 1
                if snap.relu and e["data"][j] == l["zp"]:
                    self.cov["relu_at_zp"] += 1
        self.m.release_if_last(ctx, tag, last)
        w = [ctx, tag, row, mask, int(last), err, ovf]
        for j in range(c.cols):
            v = R.ux(data[j], 64)
            w += [v & 0xFFFFFFFF, v >> 32]
        w += [e["tag"], e["ctx"], e["row"], u32(e["m"]), u32(e["ch0"]), e["col_mask"], int(e["last"]),
              e["fmt"], e["code"], e["sat"], e["iovf"], e["relu"], e["active"]]
        w += [u32(d) for d in e["data"]]
        self.cmds.append((OP_BEAT, w))
        self.beats_since_reset += 1
        if e["code"]:
            self.sticky[1] |= 1 << e["code"]
        self.stats["beats"] += 1
        self.stats["elems"] += e["active"]
        self.stats["sat"] += bin(e["sat"]).count("1")
        self.stats["relu"] += bin(e["relu"]).count("1")
        return e

    def bsync(self):
        """Beats queued after this wait until every control command queued before it is done."""
        n = sum(1 for op, _ in self.cmds_since_reset() if op in CTL_OPS)
        self.cmds.append((OP_BSYNC, [n]))

    def cmds_since_reset(self):
        for i in range(len(self.cmds) - 1, -1, -1):
            if self.cmds[i][0] == OP_RESET:
                return self.cmds[i + 1:]
        return self.cmds

    def drain(self):
        self.cmds.append((OP_DRAIN, []))

    def checks(self):
        """Drain, then compare counters, context status and sticky errors."""
        self.drain()
        self.cmds.append((OP_PERF, []))
        om = sum(1 << k for k in range(self.c.num_ctx) if self.m.ctx[k] is not None)
        pm = sum(1 << k for k in range(self.c.num_ctx) if self.m.ctx[k] is not None and self.m.ctx[k].poison)
        self.cmds.append((OP_STATUS, [om, pm]))
        self.cmds.append((OP_STICKY, list(self.sticky)))

    def reset(self, delay):
        self.cmds.append((OP_RESET, [delay]))
        self.m.reset()
        self.beats_since_reset = 0
        self.sticky = [0, 0, 0]
        self.stats["resets"] += 1

    def perfclr(self):
        self.drain()
        self.cmds.append((OP_PERFCLR, []))

    def sync(self, n):
        self.cmds.append((OP_SYNC, [n]))

    # ------------------------------------------------------------------ data
    def rand_acc(self, mode="mix"):
        r, w = self.rnd, self.c.in_w
        lo, hi = R.srange(w)
        k = r.random()
        if mode == "small" or (mode == "mix" and k < 0.30):
            return r.randint(-5000, 5000)
        if mode == "mix" and k < 0.45:
            return r.choice([lo, hi, lo + 1, hi - 1, 0, 1, -1, -(1 << 31), (1 << 31) - 1, -(1 << 31) + 1,
                             (1 << 31) - 2] + ([1 << 31, -(1 << 31) - 1, (1 << 31) + 1] if w > 32 else []))
        if mode == "mix" and k < 0.75:
            b = r.randint(1, w - 1)
            return r.randint(-(1 << (b - 1)), (1 << (b - 1)) - 1)
        return r.randint(lo, hi)

    def rand_bias(self):
        r = self.rnd
        k = r.random()
        if k < 0.25:
            return r.choice([-(1 << 31), (1 << 31) - 1, -1, 0, 1, (1 << 30), -(1 << 30)])
        if k < 0.6:
            return r.randint(-100000, 100000)
        return r.randint(-(1 << 31), (1 << 31) - 1)

    def rand_scale(self):
        """(M, S) from a realistic real scale, or an edge case."""
        r = self.rnd
        k = r.random()
        if k < 0.40:
            sc = 2.0 ** r.uniform(-24, -2) * r.choice([1, 1, 1, -1])
            return R.quantize_multiplier(sc)
        if k < 0.55:
            return self.tie_scale()
        if k < 0.65:
            return 0, r.randint(0, 63)                                       # zero multiplier
        if k < 0.75:
            return r.choice([1, -1, 3, (1 << 31) - 1, -(1 << 31), 1 << 30]), r.choice([0, 1, 63, 62])
        return r.randint(-(1 << 31), (1 << 31) - 1), r.randint(0, 63)

    def tie_scale(self):
        """M = odd * 2^a with a small odd part: the scales for which exact rounding ties are
        reachable at non-saturating magnitudes (x*M/2^S within a few hundred)."""
        r = self.rnd
        o = r.choice([1, 3, 5, 7, 9, 11, 13, 15, 17, 31, 63, 127, 255]) * r.choice([1, -1])
        a = r.randint(0, 30 - abs(o).bit_length())
        sp = r.randint(1, 22)
        return o << a, min(63, sp + a)

    def solve_x(self, mult, s, t, xlo, xhi, xc=None):
        """x in [xlo, xhi] with x*mult == t (mod 2^s), or None.  With xc, the solution closest
        to xc (within a few steps) is chosen, so the result has a chosen magnitude."""
        if s == 0:
            return self.rnd.randint(xlo, xhi)
        mod = 1 << s
        if mult == 0:
            return self.rnd.randint(xlo, xhi) if t % mod == 0 else None
        a = (mult & -mult).bit_length() - 1          # 2-adic valuation
        if a >= s:
            return self.rnd.randint(xlo, xhi) if t % mod == 0 else None
        if t % (1 << a):
            return None
        sp = s - a
        o = mult >> a
        c = ((t >> a) * pow(o % (1 << sp), -1, 1 << sp)) % (1 << sp)
        step = 1 << sp
        jmin = -((c - xlo) // step)
        jmax = (xhi - c) // step
        if jmin > jmax:
            return None
        if xc is None:
            return c + self.rnd.randint(jmin, jmax) * step
        j = round((xc - c) / step) + self.rnd.randint(-2, 2)
        return c + min(max(j, jmin), jmax) * step

    def tie_x(self, mult, s, xlo, xhi, xc=None):
        """x that puts x*mult/2^s on or next to a rounding boundary (near xc if given)."""
        if s == 0 or mult == 0:
            return None
        a = (mult & -mult).bit_length() - 1
        h = 1 << (s - 1)
        g = 1 << min(a, s - 1)
        t = self.rnd.choice([h, h, h, h + g, h - g if h > g else h, 0, g, (1 << s) - g])
        x = self.solve_x(mult, s, t % (1 << s), xlo, xhi, xc)
        if x is not None:
            self.stats["ties"] += 1
        return x

    def target_x(self, mult, s, zp, target):
        """x with R(x*mult/2^s) + zp close to `target` (saturation / ReLU boundaries)."""
        if mult == 0:
            return None
        v = (target - zp) + self.rnd.choice([-0.5, -0.25, 0, 0.25, 0.5, 0.75])
        return int(round(v * (1 << s) / mult))

    def acc_for(self, snap, j):
        """An accumulator for lane j of a tile, biased toward the interesting cases."""
        c, r = self.c, self.rnd
        lo, hi = R.srange(c.in_w)
        if snap is None or snap.poison or snap.lanes[j] is None:
            return self.rand_acc()
        l = snap.lanes[j]
        beff = l["bias"] - snap.za * l["cs"]
        x = None
        k = r.random()
        if snap.rq and k < 0.35:
            qlo, qhi = R.FMT_RANGE[snap.ofmt]
            if snap.ofmt == R.OFMT_INT8 or r.random() < 0.7:
                tgt = r.randint(max(qlo, -300), min(qhi, 300)) - l["zp"]
            else:
                tgt = r.randint(qlo, qhi) - l["zp"]
            xc = (tgt << l["shift"]) // l["mult"] if l["mult"] else 0
            x = self.tie_x(l["mult"], l["shift"], lo + beff, hi + beff, xc)
        elif k < 0.50:
            qlo, qhi = R.FMT_RANGE[snap.ofmt]
            tgt = r.choice([qlo - 1, qlo, qlo + 1, qhi - 1, qhi, qhi + 1, l["zp"] - 1, l["zp"], l["zp"] + 1])
            if snap.rq:
                x = self.target_x(l["mult"], l["shift"], l["zp"], tgt)
            else:
                x = tgt
        if x is not None:
            acc = x - beff
            if lo <= acc <= hi:
                return acc
        return self.rand_acc()

    # ------------------------------------------------------------------ tiles and waves
    def load_group(self, grp, kind="mix", fmask=0x0F, ofmt=R.OFMT_INT8, lane_mask=None):
        c, r = self.c, self.rnd
        lanes = []
        for _ in range(c.cols):
            m, s = self.rand_scale()
            lo, hi = R.FMT_RANGE[ofmt]
            zp = r.choice([0, lo, hi, r.randint(lo, hi)]) if ofmt == R.OFMT_INT8 else r.choice(
                [0, r.randint(-1000, 1000), r.randint(lo, hi)])
            cs = r.choice([0, r.randint(-128 * 4096, 127 * 4096), R.srange(c.in_w)[0], R.srange(c.in_w)[1],
                           r.randint(*R.srange(c.in_w))])
            lanes.append(dict(bias=self.rand_bias(), mult=m, shift=s, zp=zp, cs=cs))
        if c.asym_en:
            fmask |= R.FM_CS
        return self.pw(grp, lane_mask if lane_mask is not None else (1 << c.cols) - 1, fmask, lanes)

    @staticmethod
    def close_desc(ctx, tag, **kw):
        f = dict(m=0, n=0)
        f.update(kw)
        return R.encode_desc(op=R.OP_CLOSE, ctx=ctx, tag=tag, **f)

    def mk_desc(self, ctx, flags, ofmt=R.OFMT_INT32, rm=R.RM_RNE, m=None, n=None, grp=0, m0=None,
                mult=0, shift=0, zp=0, za=0, zb=0, rsvd=None, op=R.OP_OPEN, ver=R.VERSION, tag=None):
        c, r = self.c, self.rnd
        m = m if m is not None else r.randint(1, c.rows)
        n = n if n is not None else r.randint(1, c.cols)
        m0 = m0 if m0 is not None else r.choice([0, r.randint(0, 1 << 20), 0xFFFFFFFF - m + 1])
        tag = tag if tag is not None else self.new_tag()
        return R.encode_desc(op=op, ver=ver, rm=rm, flags=flags, ofmt=ofmt, tag=tag, ctx=ctx, m=m, n=n,
                             grp=grp, m0=m0, mult=mult, shift=shift, za=za, zb=zb, zp=zp, rsvd=rsvd)

    def tile_beats(self, snap, ctx, tag, M, N, err_p=0.0, ovf_p=0.0, frame_p=0.0, data_fn=None):
        """Row beats of one tile (list of closures emitting each beat)."""
        c, r = self.c, self.rnd
        out = []
        for row in range(M):
            mask = (1 << N) - 1
            last = row == M - 1
            rr = row
            ridw = max(1, (c.rows - 1).bit_length())
            if frame_p and r.random() < frame_p:
                kind = r.choice(["mask", "row"])
                if kind == "row" and M < (1 << ridw):
                    rr = r.randint(M, (1 << ridw) - 1)        # row outside the tile (last flag kept)
                else:
                    mask ^= 1 << r.randrange(c.cols)
                    mask &= (1 << c.cols) - 1
            data = [data_fn(row, j) if data_fn else self.acc_for(snap, j) for j in range(c.cols)]
            for j in range(N, c.cols):
                if r.random() < 0.5:
                    data[j] = 0
            ovf = sum(1 << j for j in range(c.cols) if r.random() < ovf_p)
            err = int(r.random() < err_p)
            out.append((snap, ctx, tag, rr, mask, last, err, data, ovf))
        return out

    def wave(self, tiles, stray=0, interleave=True):
        """tiles: list of beat lists (control commands already emitted).  Interleave rows of the
        tiles at random (per-tile order kept), optionally inject stray-tag beats."""
        r = self.rnd
        queues = [list(t) for t in tiles if t]
        order = []
        while queues:
            q = r.choice(queues) if interleave else queues[0]
            order.append(q.pop(0))
            if not q:
                queues.remove(q)
        # stray beats: before the last beat of a tile on that context, always derived from a
        # REAL last beat (a stray derived from a stray could carry the real tag again)
        real = [False] * len(order)
        for i, b in enumerate(order):
            real[i] = bool(b[5]) and not b[0].poison
        for _ in range(stray):
            cands = [i for i in range(len(order)) if real[i]]
            if not cands:
                break
            i = r.choice(cands)
            b = order[i]
            # wrong tag; half of them carry last = 1, which must NOT release the context
            bad = (b[0], b[1], (b[2] + 0x8000) & 0xFFFF or 1, 0, b[4], r.random() < 0.5, 0, b[7], 0)
            order.insert(i, bad)
            real.insert(i, False)
        for b in order:
            self.beat(*b)

    def open_tiles(self, specs):
        """specs: list of (ctx, words).  Emits descriptors, returns [(snap, ctx, tag, M, N)]."""
        res = []
        for ctx, words in specs:
            code, kind, snap = self.desc(words)
            d = R.decode_desc(words)
            res.append((snap, ctx, d["tag"], d["m"], d["n"], code, kind))
        return res

    def ctx_sets(self):
        k = self.rnd.randint(1, self.c.num_ctx)
        return self.rnd.sample(range(self.c.num_ctx), k)

    # ------------------------------------------------------------------ generic traffic
    def traffic(self, waves, flag_fn, stray=0, err_p=0.02, ovf_p=0.05, frame_p=0.0, pw_between=False):
        c, r = self.c, self.rnd
        for _ in range(waves):
            specs = []
            for ctx in self.ctx_sets():
                specs.append((ctx, flag_fn(ctx)))
            opened = self.open_tiles(specs)
            if pw_between and r.random() < 0.5:        # reload a group while tiles using it are in flight
                self.load_group(r.randrange(c.num_grp), ofmt=r.choice([R.OFMT_INT8, R.OFMT_INT32]))
            tiles = []
            for snap, ctx, tag, M, N, code, kind in opened:
                if kind in ("open", "poison"):
                    tiles.append(self.tile_beats(snap, ctx, tag, max(M, 1) if not snap.poison else r.randint(1, c.rows),
                                                 max(min(N, c.cols), 1), err_p, ovf_p, frame_p))
            self.wave(tiles, stray)


# ============================================================================ suites
def s1_pass(g, n):
    c = g.c
    for _ in range(n):
        g.traffic(6, lambda ctx: g.mk_desc(ctx, 0))
        g.checks()


def s2_bias(g, n):
    c, r = g.c, g.rnd
    for gi in range(c.num_grp):
        g.load_group(gi, fmask=R.FM_BIAS)
    g.checks()
    for _ in range(n):
        def fl(ctx):
            f = r.choice([0, R.FL_BIAS, R.FL_BIAS, R.FL_BIAS | R.FL_WRAP])
            return g.mk_desc(ctx, f, grp=r.randrange(c.num_grp))
        g.traffic(5, fl)
        if r.random() < 0.5:
            g.load_group(r.randrange(c.num_grp), fmask=R.FM_BIAS)
        g.checks()


def s3_int8(g, n):
    """Per-tensor INT8 requantisation, RNE, optional bias and ReLU."""
    c, r = g.c, g.rnd
    for gi in range(c.num_grp):
        g.load_group(gi, fmask=R.FM_BIAS)
    g.checks()
    for _ in range(n):
        def fl(ctx):
            m, s = g.rand_scale()
            f = R.FL_RQ | r.choice([0, R.FL_BIAS]) | r.choice([0, R.FL_RELU])
            return g.mk_desc(ctx, f, ofmt=R.OFMT_INT8, rm=R.RM_RNE, grp=r.randrange(c.num_grp), mult=m,
                             shift=s, zp=r.choice([0, -128, 127, r.randint(-128, 127)]))
        g.traffic(5, fl)
        g.checks()


def tie_mult(r, sh):
    """A multiplier for shift sh such that exact ties are reachable with |x| < 2^31 and the
    rounded result stays small: M = +-odd * 2^a with a as large as the 32-bit field allows."""
    if sh >= 63:
        return -(1 << 31)
    a = min(sh - 1, 30)
    room = 30 - a
    o = r.choice([1, 3, 5, 7, 9, 15, 31, 127]) if room >= 7 else (1 if room < 2 else r.choice([1, 3]))
    while o.bit_length() > room + 1 and o > 1:
        o >>= 1
        o |= 1
    m = (o << a) * r.choice([1, -1])
    return max(-(1 << 31), min((1 << 31) - 1, m))


def ties(g, n, rms, per_channel):
    """Directed rounding boundaries for every shift 1..63."""
    c, r = g.c, g.rnd
    for it in range(n):
        for rm in rms:
            if per_channel:
                for gi in range(c.num_grp):
                    lanes = []
                    for j in range(c.cols):
                        sh = 1 + (gi * c.cols + j + it * 5 + rm * 11) % 63
                        lanes.append(dict(bias=r.randint(-64, 64), mult=tie_mult(r, sh), shift=sh,
                                          zp=r.randint(-20, 20), cs=0))
                    g.pw(gi, (1 << c.cols) - 1, 0x0F, lanes)
                tiles = [(R.FL_RQ | R.FL_PC | R.FL_BIAS | r.choice([0, R.FL_RELU]), 0, 0, 0, gi)
                         for gi in range(c.num_grp)]
            else:
                tiles = []
                for sh in range(1, 64):
                    tiles.append((R.FL_RQ | r.choice([0, R.FL_RELU]), tie_mult(r, sh), sh, r.randint(-20, 20), 0))
            while tiles:
                wave = tiles[: c.num_ctx]
                tiles = tiles[c.num_ctx:]
                opened = []
                for k, (f, m, sh, zp, gi) in enumerate(wave):
                    words = g.mk_desc(k, f, ofmt=R.OFMT_INT8, rm=rm, grp=gi, mult=m, shift=sh, zp=zp,
                                      n=c.cols)
                    o = g.open_tiles([(k, words)])[0]
                    assert o[5] == R.QR_OK
                    opened.append(o)
                tl = []
                for snap, k, tag, M, N, code, kind in opened:
                    def df(row, j, snap=snap):
                        l = snap.lanes[j]
                        lo, hi = R.srange(c.in_w)
                        beff = l["bias"]
                        xc = (r.randint(-60, 60) << l["shift"]) // l["mult"]
                        x = g.tie_x(l["mult"], l["shift"], lo + beff, hi + beff, xc)
                        return (x - beff) if x is not None else g.rand_acc("small")
                    tl.append(g.tile_beats(snap, k, tag, M, N, err_p=0, ovf_p=0, data_fn=df))
                g.wave(tl)
        g.checks()


def s3_ties(g, n):
    ties(g, n, [R.RM_RNE], False)


def s4_ties(g, n):
    ties(g, n, [R.RM_RNE, R.RM_RTZ, R.RM_RDN, R.RM_RUP, R.RM_RMM], True)
    ties(g, 1, [R.RM_RTZ, R.RM_RDN, R.RM_RUP, R.RM_RMM], False)


def s4_perchan(g, n):
    c, r = g.c, g.rnd
    for gi in range(c.num_grp):
        g.load_group(gi, ofmt=R.OFMT_INT8)
    g.checks()
    for it in range(n):
        def fl(ctx):
            f = R.FL_RQ | R.FL_PC | r.choice([0, R.FL_BIAS]) | r.choice([0, R.FL_RELU])
            return g.mk_desc(ctx, f, ofmt=R.OFMT_INT8, grp=r.randrange(c.num_grp))
        g.traffic(4, fl, pw_between=True)
        # same-cycle parameter write + descriptor on the same group: descriptor sees OLD values
        grp = r.randrange(c.num_grp)
        ctx = r.randrange(c.num_ctx)
        g.drain()
        if g.m.ctx[ctx] is None:
            lanes = []
            for _ in range(c.cols):
                m, s = g.rand_scale()
                lanes.append(dict(bias=g.rand_bias(), mult=m, shift=s, zp=r.randint(-128, 127), cs=0))
            words = g.mk_desc(ctx, R.FL_RQ | R.FL_PC | R.FL_BIAS, ofmt=R.OFMT_INT8, grp=grp)
            code, kind, snap = g.same_cycle((grp, (1 << c.cols) - 1, 0x0F, lanes), words)
            d = R.decode_desc(words)
            g.wave([g.tile_beats(snap, ctx, d["tag"], d["m"], d["n"])])
            # and the next tile on that group sees the NEW values
            words = g.mk_desc(ctx, R.FL_RQ | R.FL_PC | R.FL_BIAS, ofmt=R.OFMT_INT8, grp=grp)
            o = g.open_tiles([(ctx, words)])[0]
            g.wave([g.tile_beats(o[0], ctx, o[2], o[3], o[4])])
        # partial-lane writes and single-field updates
        g.load_group(r.randrange(c.num_grp), fmask=r.choice([R.FM_MULT, R.FM_SHIFT, R.FM_ZP, R.FM_BIAS, 0x0F]),
                     lane_mask=r.randint(1, (1 << c.cols) - 1))
        g.checks()


def s4_rmodes(g, n):
    """Every rounding mode; dense ties for every shift 0..63 (per-channel, so each lane can hold
    a different shift)."""
    c, r = g.c, g.rnd
    shifts = list(range(64))
    for it in range(n):
        for gi in range(c.num_grp):
            lanes = []
            for j in range(c.cols):
                s = shifts[(gi * c.cols + j + it * 7) % 64]
                o = r.choice([1, -1, 3, -3, 5, -7, 127, -255])
                a = max(0, min(30 - abs(o).bit_length(), s - r.randint(1, 20)))
                m = r.choice([o << a, o << a, o << a, (1 << 30) + 1, -(1 << 31), (1 << 31) - 1, 1 << 30,
                              r.randint(-(1 << 31), (1 << 31) - 1) | 1])
                lanes.append(dict(bias=r.randint(-1000, 1000), mult=m, shift=s, zp=r.randint(-128, 127), cs=0))
            g.pw(gi, (1 << c.cols) - 1, 0x0F, lanes)
        for rm in (R.RM_RNE, R.RM_RTZ, R.RM_RDN, R.RM_RUP, R.RM_RMM):
            def fl(ctx, rm=rm):
                f = R.FL_RQ | R.FL_PC | r.choice([0, R.FL_BIAS]) | r.choice([0, 0, R.FL_RELU])
                return g.mk_desc(ctx, f, ofmt=R.OFMT_INT8, rm=rm, grp=r.randrange(c.num_grp), n=c.cols)
            g.traffic(3, fl, err_p=0, ovf_p=0)
            # per-tensor too
            def fl2(ctx, rm=rm):
                m, s = g.rand_scale()
                return g.mk_desc(ctx, R.FL_RQ, ofmt=R.OFMT_INT8, rm=rm, mult=m, shift=s,
                                 zp=r.randint(-128, 127))
            g.traffic(2, fl2, err_p=0, ovf_p=0)
        g.checks()


def s4_int32rq(g, n):
    c, r = g.c, g.rnd
    for gi in range(c.num_grp):
        g.load_group(gi, ofmt=R.OFMT_INT32)
    g.checks()
    for _ in range(n):
        def fl(ctx):
            pc = r.random() < 0.5
            f = R.FL_RQ | (R.FL_PC if pc else 0) | r.choice([0, R.FL_BIAS]) | r.choice([0, R.FL_RELU]) | \
                r.choice([0, 0, R.FL_WRAP])
            m, s = r.choice([g.rand_scale(), (r.randint(-(1 << 31), (1 << 31) - 1), r.randint(0, 8)),
                             ((1 << 31) - 1, 0), (-(1 << 31), 0)])
            return g.mk_desc(ctx, f, ofmt=R.OFMT_INT32, rm=r.randint(0, 4), grp=r.randrange(c.num_grp),
                             mult=0 if pc else m, shift=0 if pc else s,
                             zp=0 if pc else r.choice([0, r.randint(-(1 << 31), (1 << 31) - 1)]))
        g.traffic(5, fl)
        g.checks()


def s4_asym(g, n):
    c, r = g.c, g.rnd
    for gi in range(c.num_grp):
        g.load_group(gi, ofmt=R.OFMT_INT8)
    g.checks()
    for _ in range(n):
        def fl(ctx):
            za = r.choice([0, -128, 127, r.randint(-128, 127), r.randint(-128, 127)])
            pc = r.random() < 0.5
            f = r.choice([R.FL_RQ, R.FL_RQ | R.FL_BIAS]) | (R.FL_PC if pc else 0) | r.choice([0, R.FL_RELU])
            m, s = g.rand_scale()
            return g.mk_desc(ctx, f, ofmt=R.OFMT_INT8, grp=r.randrange(c.num_grp), za=za,
                             mult=0 if pc else m, shift=0 if pc else s, zp=0 if pc else r.randint(-128, 127))
        g.traffic(5, fl)
        # zB != 0 is never supported
        def flb(ctx):
            return g.mk_desc(ctx, R.FL_RQ, ofmt=R.OFMT_INT8, mult=1 << 30, shift=30, zb=r.randint(1, 255))
        g.traffic(1, flb)
        g.checks()


def s4_errors(g, n):
    c, r = g.c, g.rnd
    # table never written since reset: any descriptor needing it is rejected (QR_PARAM), poisoned
    for f in (R.FL_BIAS, R.FL_RQ | R.FL_PC):
        k = r.randrange(c.num_ctx)
        o = g.open_tiles([(k, g.mk_desc(k, f, ofmt=R.OFMT_INT8, grp=r.randrange(c.num_grp)))])[0]
        assert o[5] == R.QR_PARAM, R.QR_NAMES[o[5]]
        g.wave([g.tile_beats(o[0], k, o[2], r.randint(1, c.rows), r.randint(1, c.cols))])
    for gi in range(c.num_grp):
        g.load_group(gi, ofmt=R.OFMT_INT8)
    g.checks()
    for it in range(n):
        ctx = r.randrange(c.num_ctx)
        # --- hard rejects: nothing opens (the context stays free)
        for words in (g.mk_desc(ctx, 0, ver=2), g.mk_desc(ctx, 0, ver=0), g.mk_desc(ctx, 0, op=0x10),
                      g.mk_desc(ctx, 0, op=0x42), g.mk_desc(c.num_ctx + r.randint(0, 255 - c.num_ctx) if c.num_ctx < 256 else 0, 0)):
            g.desc(words)
        # --- CLOSE of a free context: STATE; malformed CLOSE: RSVD
        g.desc(g.close_desc(ctx, 1234))
        g.desc(g.close_desc(ctx, 1234, m=1))
        g.desc(g.close_desc(ctx, 1234, flags=R.FL_RELU))
        # --- every semantic reject opens POISONED; its tile drains flagged
        bad = [
            dict(flags=0, rsvd={0: 1 << 15}), dict(flags=0, rsvd={0: 1 << 28}), dict(flags=0x20),
            dict(flags=0, rsvd={1: 1 << 24}), dict(flags=0, rsvd={5: 1 << 6}), dict(flags=0, rsvd={5: 1 << 24}),
            dict(flags=0, rsvd={7: 1}),
            dict(flags=0, ofmt=2), dict(flags=0, ofmt=15),
            dict(flags=R.FL_RQ, ofmt=R.OFMT_INT8, rm=5, mult=1, shift=1), dict(flags=R.FL_RQ, rm=7, mult=1),
            dict(flags=R.FL_PC, ofmt=R.OFMT_INT8), dict(flags=R.FL_RQ | R.FL_WRAP, ofmt=R.OFMT_INT8, mult=1),
            dict(flags=0, rm=1), dict(flags=0, mult=5), dict(flags=0, shift=3), dict(flags=0, zp=1),
            dict(flags=R.FL_RQ | R.FL_PC, ofmt=R.OFMT_INT8, mult=1), dict(flags=R.FL_RQ | R.FL_PC, ofmt=R.OFMT_INT8, zp=3),
            dict(flags=R.FL_RQ, ofmt=R.OFMT_INT8, mult=1, zb=1),
            dict(flags=0, m=0), dict(flags=0, m=c.rows + 1), dict(flags=0, n=0), dict(flags=0, n=c.cols + 1),
            dict(flags=0, m0=0xFFFFFFFF, m=2) if c.rows >= 2 else dict(flags=0, n=0),
            dict(flags=R.FL_RQ, ofmt=R.OFMT_INT8, mult=1, zp=128), dict(flags=R.FL_RQ, ofmt=R.OFMT_INT8, mult=1, zp=-129),
            dict(flags=R.FL_BIAS, grp=c.num_grp), dict(flags=R.FL_RQ | R.FL_PC, ofmt=R.OFMT_INT8, grp=0xFFFF),
        ]
        if not c.asym_en:
            bad.append(dict(flags=R.FL_RQ, ofmt=R.OFMT_INT8, mult=1, za=5))
        r.shuffle(bad)
        for spec in bad:                 # every malformed descriptor, every iteration
            k = r.randrange(c.num_ctx)
            kw = dict(spec)
            kw.setdefault("m", r.randint(1, c.rows))
            kw.setdefault("n", r.randint(1, c.cols))
            words = g.mk_desc(k, **kw)
            o = g.open_tiles([(k, words)])[0]
            snap, _, tag, M, N, code, kind = o
            assert kind == "poison", (spec, R.QR_NAMES[code])
            g.wave([g.tile_beats(snap, k, tag, r.randint(1, c.rows), r.randint(1, c.cols))], stray=0)
        # --- PARAM: group with unloaded fields (fresh group needs a reset; use a partial write)
        g.drain()
        # --- PZP: per-channel zp outside INT8 for a lane of the tile
        grp = r.randrange(c.num_grp)
        lanes = [dict(bias=0, mult=1 << 30, shift=30, zp=r.choice([128, -129, 1 << 20]), cs=0) for _ in range(c.cols)]
        g.pw(grp, 1 << r.randrange(c.cols), R.FM_ZP | R.FM_MULT | R.FM_SHIFT, lanes)
        k = r.randrange(c.num_ctx)
        o = g.open_tiles([(k, g.mk_desc(k, R.FL_RQ | R.FL_PC, ofmt=R.OFMT_INT8, grp=grp, n=c.cols))])[0]
        g.wave([g.tile_beats(o[0], k, o[2], r.randint(1, c.rows), c.cols)])
        g.load_group(grp, ofmt=R.OFMT_INT8)   # repair
        # --- parameter write errors
        g.pw(c.num_grp + r.randint(0, 100), 1, R.FM_BIAS, [dict(bias=1)] * c.cols)
        g.pw(0xFFFF, (1 << c.cols) - 1, 0x0F, [dict(bias=1)] * c.cols)
        if not c.asym_en:
            g.pw(0, 1, R.FM_CS | R.FM_BIAS, [dict(bias=99, cs=5)] * c.cols)   # rejected whole: bias unchanged
        # --- stray tags, frame errors, upstream errors on good tiles
        def fl(ctx):
            return g.mk_desc(ctx, R.FL_RQ | R.FL_PC | R.FL_BIAS, ofmt=R.OFMT_INT8, grp=r.randrange(c.num_grp))
        g.traffic(3, fl, stray=2, err_p=0.2, frame_p=0.25)
        # --- out-of-range context in the beat stream (only possible for NUM_CTX not a power of two)
        ctxw = max(1, (c.num_ctx - 1).bit_length())
        if (1 << ctxw) > c.num_ctx:
            for _ in range(3):
                g.beat(None, c.num_ctx + r.randrange((1 << ctxw) - c.num_ctx), 77, 0, 1, 1, 0,
                       [g.rand_acc() for _ in range(c.cols)], 1)
        # --- CLOSE after an aborted tile: open, send some rows, sync, close; context reusable
        k = r.randrange(c.num_ctx)
        g.drain()
        words = g.mk_desc(k, R.FL_RQ | R.FL_PC, ofmt=R.OFMT_INT8, grp=r.randrange(c.num_grp), m=c.rows)
        o = g.open_tiles([(k, words)])[0]
        nb = r.randint(0, c.rows - 1)
        bl = g.tile_beats(o[0], k, o[2], c.rows, o[4])[:nb]
        g.wave([bl])
        g.sync(g.beats_since_reset)
        g.desc(g.close_desc(k, (o[2] + 1) & 0xFFFF))      # wrong tag: STATE
        g.desc(g.close_desc(k, o[2]))                      # closes
        o = g.open_tiles([(k, g.mk_desc(k, 0))])[0]
        g.bsync()                                          # the new tile's beats follow the CLOSE
        g.wave([g.tile_beats(o[0], k, o[2], o[3], o[4])])
        g.checks()


def s4_reset(g, n):
    c, r = g.c, g.rnd
    for it in range(n):
        for gi in range(c.num_grp):
            g.load_group(gi, ofmt=R.OFMT_INT8)
        def fl(ctx):
            return g.mk_desc(ctx, R.FL_RQ | R.FL_PC | R.FL_BIAS | r.choice([0, R.FL_RELU]), ofmt=R.OFMT_INT8,
                             grp=r.randrange(c.num_grp))
        g.traffic(4, fl)
        g.reset(r.choice([0, 1, 2, 3, r.randint(4, 60), r.randint(4, 300)]))
        # after reset: no context open, every table field invalid
        g.checks()
        k = r.randrange(c.num_ctx)
        o = g.open_tiles([(k, g.mk_desc(k, R.FL_BIAS, grp=r.randrange(c.num_grp)))])[0]
        assert o[5] == R.QR_PARAM
        g.wave([g.tile_beats(o[0], k, o[2], r.randint(1, c.rows), r.randint(1, c.cols))])
        o = g.open_tiles([(k, g.mk_desc(k, 0))])[0]   # pass-through needs no table
        g.wave([g.tile_beats(o[0], k, o[2], o[3], o[4])])
        if c.asym_en:
            # bias, M, S, zp loaded but the column sum missing: zA != 0 alone must be rejected
            gi = r.randrange(c.num_grp)
            lanes = [dict(bias=1, mult=1 << 30, shift=30, zp=0, cs=0) for _ in range(c.cols)]
            g.pw(gi, (1 << c.cols) - 1, 0x0F, lanes)
            o = g.open_tiles([(k, g.mk_desc(k, R.FL_RQ | R.FL_PC | R.FL_BIAS, ofmt=R.OFMT_INT8, grp=gi, za=-5))])[0]
            assert o[5] == R.QR_PARAM
            g.wave([g.tile_beats(o[0], k, o[2], r.randint(1, c.rows), r.randint(1, c.cols))])
        g.checks()


def s4_gemm(g, n, M=12, K=96):
    """Representative quantised layers: int8 activations (post-ReLU, zA = -128 when ASYM_EN),
    symmetric int8 weights with per-channel scales, int32 bias; the TB checks the hardware
    against the integer contract; the float-scale agreement is reported for information."""
    c, r = g.c, g.rnd
    info = []
    for layer in range(n):
        N = c.cols * c.num_grp
        Ncut = min(N, c.cols * r.randint(1, c.num_grp))
        za = -128 if c.asym_en else 0
        # activations: ReLU'd real values quantised with scale s_in (zero at za)
        A = [[min(127, max(-128, za + int(abs(r.gauss(0, 30))))) if c.asym_en else
              min(127, max(-128, int(r.gauss(0, 40)))) for _ in range(K)] for _ in range(M)]
        s_in = 0.05
        s_w = [abs(r.gauss(0.01, 0.004)) + 1e-4 for _ in range(Ncut)]
        B = [[min(127, max(-127, int(round(r.gauss(0, 0.02) / s_w[nn])))) for nn in range(Ncut)] for _ in range(K)]
        s_out = r.choice([0.02, 0.05, 0.1])
        zp_out = r.choice([-128, -10, 0, 5]) if layer % 2 else 0
        bias_f = [r.gauss(0, 0.5) for _ in range(Ncut)]
        bias = [int(round(bias_f[nn] / (s_in * s_w[nn]))) for nn in range(Ncut)]
        per_ch = layer % 3 != 0
        MS = [R.quantize_multiplier(s_in * s_w[nn] / s_out) for nn in range(Ncut)]
        if not per_ch:
            ms = R.quantize_multiplier(s_in * (sum(s_w) / Ncut) / s_out)
            MS = [ms] * Ncut
        cs = R.colsum(B)
        relu = layer % 2 == 1
        for grp in range(Ncut // c.cols):
            lanes = []
            for j in range(c.cols):
                nn = grp * c.cols + j
                lanes.append(dict(bias=bias[nn], mult=MS[nn][0], shift=MS[nn][1], zp=zp_out, cs=cs[nn]))
            g.pw(grp, (1 << c.cols) - 1, 0x0F | (R.FM_CS if c.asym_en else 0), lanes)
        raw = [[sum(A[m][k] * B[k][nn] for k in range(K)) for nn in range(Ncut)] for m in range(M)]
        Q, _ = R.qgemm_direct(A, B, za=za, bias=bias, mult=[x[0] for x in MS], shift=[x[1] for x in MS],
                              zp=[zp_out] * Ncut, relu=relu)
        # tiles
        tiles_m = [(m0, min(c.rows, M - m0)) for m0 in range(0, M, c.rows)]
        tiles_n = list(range(Ncut // c.cols))
        jobs = [(m0, mm, gn) for (m0, mm) in tiles_m for gn in tiles_n]
        agree = tot = 0
        while jobs:
            wave = jobs[: c.num_ctx]
            jobs = jobs[c.num_ctx:]
            opened = []
            for k, (m0, mm, gn) in enumerate(wave):
                f = R.FL_RQ | R.FL_BIAS | (R.FL_PC if per_ch else 0) | (R.FL_RELU if relu else 0)
                words = g.mk_desc(k, f, ofmt=R.OFMT_INT8, grp=gn, m=mm, n=c.cols, m0=m0, za=za,
                                  mult=0 if per_ch else MS[0][0], shift=0 if per_ch else MS[0][1],
                                  zp=0 if per_ch else zp_out)
                o = g.open_tiles([(k, words)])[0]
                assert o[5] == R.QR_OK, R.QR_NAMES[o[5]]
                opened.append((o, m0, gn))
            tl = []
            for o, m0, gn in opened:
                snap, k, tag, mm, nn_, code, kind = o
                tl.append(g.tile_beats(snap, k, tag, mm, c.cols, err_p=0, ovf_p=0,
                                       data_fn=lambda row, j, m0=m0, gn=gn: raw[m0 + row][gn * c.cols + j]))
            g.wave(tl)
            # the expected beat values came from the element contract on the RAW accumulator; check
            # they equal the literal quantised GEMM (correction applied exactly once)
            for o, m0, gn in opened:
                snap = o[0]
                for row in range(o[3]):
                    for j in range(c.cols):
                        nn = gn * c.cols + j
                        l = snap.lanes[j]
                        q, _, _ = R.element(raw[m0 + row][nn], bias=l["bias"], za=snap.za, colsum=l["cs"],
                                            mult=l["mult"], shift=l["shift"], zp=l["zp"], rq=True,
                                            ofmt=R.OFMT_INT8, relu=snap.relu)
                        assert q == Q[m0 + row][nn]
                        real = s_in * s_w[nn] / s_out if per_ch else s_in * (sum(s_w) / Ncut) / s_out
                        acc_t = raw[m0 + row][nn] - za * cs[nn] + bias[nn]
                        qf = R.float_requant(acc_t, real, zp_out)
                        if relu:
                            qf = max(qf, zp_out)
                        agree += int(qf == q)
                        tot += 1
        info.append((layer, per_ch, relu, za, agree, tot))
        g.checks()
    g.gemm_info = info


def s4_soak(g, n):
    c, r = g.c, g.rnd
    for gi in range(c.num_grp):
        g.load_group(gi, ofmt=R.OFMT_INT8)
    for _ in range(n):
        def fl(ctx):
            k = r.random()
            if k < 0.15:
                return g.mk_desc(ctx, r.choice([0, R.FL_RELU, R.FL_WRAP]))
            if k < 0.3:
                return g.mk_desc(ctx, R.FL_BIAS | r.choice([0, R.FL_WRAP, R.FL_RELU]), grp=r.randrange(c.num_grp))
            if k < 0.9:
                pc = r.random() < 0.5
                m, s = g.rand_scale()
                za = r.choice([0, 0, r.randint(-128, 127)]) if c.asym_en else 0
                fmt = r.choice([R.OFMT_INT8, R.OFMT_INT8, R.OFMT_INT32])
                return g.mk_desc(ctx, R.FL_RQ | (R.FL_PC if pc else 0) | r.choice([0, R.FL_BIAS]) |
                                 r.choice([0, R.FL_RELU]), ofmt=fmt, rm=r.randint(0, 4),
                                 grp=r.randrange(c.num_grp), mult=0 if pc else m, shift=0 if pc else s,
                                 zp=0 if pc else (r.randint(-128, 127) if fmt == R.OFMT_INT8 else r.randint(-99999, 99999)),
                                 za=za)
            return g.mk_desc(ctx, R.FL_RQ, ofmt=R.OFMT_INT8, mult=1, rm=r.choice([5, 6]))   # poisoned
        g.traffic(8, fl, stray=r.choice([0, 0, 1]), err_p=0.03, frame_p=0.02, pw_between=True)
        if r.random() < 0.3:
            g.perfclr()
        g.checks()


def p_stream(g, n):
    """Throughput: a long stream of full tiles alternating between contexts, no gaps; with
    out_ready = 1 the TB requires one accepted beat per cycle (no input stall at all)."""
    c, r = g.c, g.rnd
    for gi in range(c.num_grp):
        g.load_group(gi, ofmt=R.OFMT_INT8)
    g.checks()
    tiles = 60 * n
    for t in range(0, tiles, c.num_ctx):
        opened = []
        for k in range(c.num_ctx):
            words = g.mk_desc(k, R.FL_RQ | R.FL_PC | R.FL_BIAS | R.FL_RELU, ofmt=R.OFMT_INT8,
                              grp=r.randrange(c.num_grp), m=c.rows, n=c.cols)
            opened.append(g.open_tiles([(k, words)])[0])
        g.wave([g.tile_beats(o[0], o[1], o[2], o[3], o[4], err_p=0, ovf_p=0) for o in opened], interleave=False)
    g.checks()


SUITES = dict(p_stream=(p_stream, 4, 2), s1_pass=(s1_pass, 1, 6), s2_bias=(s2_bias, 2, 6), s3_int8=(s3_int8, 3, 8),
              s3_ties=(s3_ties, 3, 2), s4_ties=(s4_ties, 4, 4),
              s4_perchan=(s4_perchan, 4, 6), s4_rmodes=(s4_rmodes, 4, 3), s4_int32rq=(s4_int32rq, 4, 6),
              s4_asym=(s4_asym, 4, 6), s4_errors=(s4_errors, 4, 3), s4_reset=(s4_reset, 4, 6),
              s4_gemm=(s4_gemm, 4, 4), s4_soak=(s4_soak, 4, 12))


def write(g, path):
    c = g.c
    body = []
    for op, p in g.cmds:
        body.append((op << 24) | len(p))
        body += [u32(x) for x in p]
    hdr = [MAGIC, 0, c.rows, c.cols, c.in_w, c.num_ctx, c.num_grp, c.asym_en, len(g.cmds)]
    words = hdr + body
    words[1] = len(words)
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as f:
        f.write("\n".join("%08x" % w for w in words) + "\n")
    return len(words)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", required=True, choices=sorted(SUITES))
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--in-w", type=int, default=32)
    ap.add_argument("--ctx", type=int, default=2)
    ap.add_argument("--grp", type=int, default=4)
    ap.add_argument("--asym", type=int, default=0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--scale", type=float, default=1.0, help="multiply the suite's iteration count")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cfg = R.Config(a.rows, a.cols, a.in_w, a.ctx, a.grp, a.asym)
    g = Gen(cfg, a.seed * 1000003 + sum(map(ord, a.suite)))
    fn, _, n = SUITES[a.suite]
    fn(g, max(1, int(round(n * a.scale))))
    nw = write(g, a.out)
    st = g.stats
    print(f"GEN suite={a.suite} cmds={len(g.cmds)} words={nw} beats={st['beats']} elems={st['elems']} "
          f"descs={st['descs']} pws={st['pws']} ties={st['ties']} sat={st['sat']} relu={st['relu']} "
          f"resets={st['resets']} rejects={sum(st['rej'].values())} {dict(sorted(st['rej'].items()))}")
    cv = g.cov
    print("COV live_ties=%s (even-floor %s) near_ties=%d shifts_used=%d shiftmask=%#x neg_mult=%d zero_mult=%d sat_hi=%d sat_lo=%d wrap=%d relu_at_zp=%d" % (
        {R.RM_NAMES[k]: v for k, v in cv["live_tie"].items()}, {R.RM_NAMES[k]: v for k, v in cv["live_tie_even"].items()},
        cv["near_tie"], len(cv["shifts"]), sum(1 << x for x in cv["shifts"]), cv["neg_mult"], cv["zero_mult"],
        cv["sat_hi"], cv["sat_lo"], cv["wrap"], cv["relu_at_zp"]))
    if hasattr(g, "gemm_info"):
        for layer, pc, relu, za, ag, tot in g.gemm_info:
            print(f"GEMM_INFO layer={layer} per_channel={int(pc)} relu={int(relu)} zA={za} elements={tot} "
                  f"integer_contract_equals_float_scale={ag}/{tot} ({100.0 * ag / max(1, tot):.2f}%)")


if __name__ == "__main__":
    main()
