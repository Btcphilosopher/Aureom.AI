#!/usr/bin/env python3
"""
TENSORCORE 05 -- integration-test generator for tb/tb_tq_integ.sv
(TC02 systolic array -> TC04 accumulator subsystem -> TC05 tensor_quantize).

  tools/gen_integ.py --suite <name> [--rows R --cols C --tiles T --acc W --grp G --asym A]
                     [--seed S] --out vectors/i.hex

A suite is a list of quantised GEMM LAYERS.  Each layer C = A(M x K) * B(K x N)
is cut into ROWS x COLS output tiles (channel group = N tile), each tile into a
random partition of K chunks run one launch at a time on the real array.
Expected outputs come from model/tq_ref.py: qgemm_direct evaluates
sum_k (A - zA) * B literally, then the element contract.  Layer kinds:

  int32_pass   raw INT32 through the quantiser (pass-through)
  int32_bias   INT32 + bias (bias site TC04 or TC05, at random)
  int8_pt      per-tensor requantisation, bias site at random, optional ReLU
  int8_pc      per-channel requantisation (bias in TC05), optional ReLU
  int8_asym    per-channel, input zero-point zA != 0 (ASYM_EN = 1 only)
  stress       extreme operands (+-128 / 127) and aggressive scales: saturation

Representative layers model a post-ReLU int8 activation tensor (zero point -128
when ASYM_EN, otherwise symmetric), symmetric int8 per-channel weights, int32
bias = round(b / (s_in * s_w)), real multipliers s_in * s_w / s_out converted
to (M, S) by quantize_multiplier().  The agreement between the integer contract
and the real-valued scale is printed for information (never a pass criterion).
"""
import argparse
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
import tq_ref as R  # noqa: E402

MAGIC = 0x7C052001
T_LAYER, T_JOB = 1, 2


def u32(v):
    return v & 0xFFFFFFFF


def partition(r, K, nch):
    cuts = sorted(r.sample(range(1, K), nch - 1)) if nch > 1 else []
    pts = [0] + cuts + [K]
    return [pts[i + 1] - pts[i] for i in range(nch)]


class G:
    def __init__(self, a):
        self.a = a
        self.r = random.Random(a.seed * 7919 + sum(map(ord, a.suite)))
        self.words = []
        self.tag = 1
        self.njobs = 0
        self.nlayers = 0
        self.info = []
        self.slot = 0

    def layer(self, kind):
        a, r = self.a, self.r
        R_, C_ = a.rows, a.cols
        if kind == "int8_asym" and not a.asym:
            kind = "int8_pc"
        Mt = r.randint(1, 3 * R_)
        NG = r.randint(1, a.grp)
        Nt = NG * C_ - (r.randint(0, C_ - 1) if r.random() < 0.3 else 0)   # last group may be partial
        K = r.choice([1, 2, 3, r.randint(4, 40), r.randint(40, 200), r.randint(200, 520)])
        za = 0
        if kind == "int8_asym":
            za = r.choice([-128, -100, r.randint(-128, 127)])
        stress = kind == "stress"
        if stress:
            A = [[r.choice([-128, 127, -128, r.randint(-128, 127)]) for _ in range(K)] for _ in range(Mt)]
            B = [[r.choice([-128, 127, -127, r.randint(-128, 127)]) for _ in range(Nt)] for _ in range(K)]
        else:
            if za:
                A = [[min(127, max(-128, za + int(abs(r.gauss(0, 35))))) for _ in range(K)] for _ in range(Mt)]
            else:
                A = [[min(127, max(-128, int(r.gauss(0, 40)))) for _ in range(K)] for _ in range(Mt)]
            s_w = [abs(r.gauss(0.01, 0.004)) + 1e-4 for _ in range(Nt)]
            B = [[min(127, max(-127, int(round(r.gauss(0, 0.02) / s_w[n])))) for n in range(Nt)] for _ in range(K)]
        s_in = 0.05
        if stress:
            s_w = [2.0 ** r.uniform(-12, -4) for _ in range(Nt)]
        s_out = r.choice([0.02, 0.05, 0.1, 0.4])
        if stress:
            s_out = r.choice([1e-4, 1e-3, 0.5])
        zp = r.choice([-128, -10, 0, 7, 127]) if kind.startswith("int8") or stress else 0
        relu = kind in ("int8_pt", "int8_pc", "int8_asym", "stress") and r.random() < 0.5
        bias = [int(round(r.gauss(0, 0.5) / (s_in * s_w[n]))) for n in range(Nt)]
        if kind == "int32_pass":
            bias = [0] * Nt
        bias = [max(-(1 << 20), min(1 << 20, b)) for b in bias]
        rq = kind not in ("int32_pass", "int32_bias")
        pc = kind in ("int8_pc", "int8_asym") or (stress and r.random() < 0.5)
        ofmt = R.OFMT_INT8 if rq else R.OFMT_INT32
        if rq:
            MS = [R.quantize_multiplier(s_in * s_w[n] / s_out) for n in range(Nt)]
            if not pc:
                ms = R.quantize_multiplier(s_in * (sum(s_w) / Nt) / s_out)
                MS = [ms] * Nt
        else:
            MS = [(1, 0)] * Nt
        rm = R.RM_RNE if kind != "stress" else r.randint(0, 4)
        bias_tc04 = kind in ("int32_bias", "int8_pt") and r.random() < 0.5    # bias site: TC04 accumulator
        use_bias = kind != "int32_pass"
        cs = R.colsum(B)
        # expected
        Q, SAT = R.qgemm_direct(A, B, za=za, bias=bias if use_bias else None, mult=[m for m, _ in MS],
                                shift=[s for _, s in MS], zp=[zp] * Nt, rq=rq, ofmt=ofmt, relu=relu, rm=rm)
        raw = [[sum(A[m][k] * B[k][n] for k in range(K)) + (bias[n] if bias_tc04 else 0) for n in range(Nt)]
               for m in range(Mt)]
        # informational: integer contract vs real-valued scale
        if rq and not stress:
            agree = tot = 0
            for m in range(Mt):
                for n in range(Nt):
                    acc_t = raw[m][n] - (bias[n] if bias_tc04 else 0) - za * cs[n] + bias[n]
                    sc = s_in * s_w[n] / s_out if pc else s_in * (sum(s_w) / Nt) / s_out
                    qf = R.float_requant(acc_t, sc, zp)
                    if relu:
                        qf = max(qf, zp)
                    agree += int(qf == Q[m][n])
                    tot += 1
            self.info.append((kind, pc, relu, za, agree, tot))
        # ---- layer record: parameter writes (all groups the layer uses)
        pws = []
        for g in range(NG):
            lanes = []
            lm = 0
            for j in range(C_):
                n = g * C_ + j
                if n < Nt:
                    lm |= 1 << j
                    lanes.append([u32(bias[n] if (use_bias and not bias_tc04) else 0), u32(MS[n][0]), MS[n][1],
                                  u32(zp), R.ux(cs[n], 64) & 0xFFFFFFFF, R.ux(cs[n], 64) >> 32])
                else:
                    lanes.append([0, 0, 0, 0, 0, 0])
            fm = R.FM_BIAS | R.FM_MULT | R.FM_SHIFT | R.FM_ZP | (R.FM_CS if a.asym else 0)
            pws.append([g, lm, fm] + sum(lanes, []))
        body = [len(pws)] + sum(pws, [])
        self.words += [(T_LAYER << 24) | len(body)] + body
        self.nlayers += 1
        # ---- jobs (tiles)
        flags = (R.FL_RQ if rq else 0) | (R.FL_PC if pc else 0) | (R.FL_RELU if relu else 0) | \
                (R.FL_BIAS if (use_bias and not bias_tc04) else 0)
        tiles = [(m0, min(R_, Mt - m0), g) for m0 in range(0, Mt, R_) for g in range(NG)]
        r.shuffle(tiles)
        for m0, M, g in tiles:
            n0 = g * C_
            N = min(C_, Nt - n0)
            nch = r.randint(1, min(4, K))
            ck = partition(r, K, nch)
            tag = self.tag
            self.tag = self.tag % 0xFFF0 + 1
            slot = self.slot
            self.slot = (self.slot + 1) % a.tiles
            desc = R.encode_desc(op=R.OP_OPEN, rm=rm if rq else 0, flags=flags, ofmt=ofmt, tag=tag, ctx=slot,
                                 m=M, n=N, grp=g, m0=m0, mult=0 if (pc or not rq) else MS[0][0],
                                 shift=0 if (pc or not rq) else MS[0][1], za=za,
                                 zp=0 if (pc or not rq) else zp)
            dest = 0b010 | (0b001 if r.random() < 0.4 else 0)
            late = int(r.random() < 0.3)
            tb = [u32(bias[n0 + j]) if (bias_tc04 and j < N) else 0 for j in range(C_)]
            rec = [slot, tag, M, N, K, nch, int(bias_tc04), dest, late, m0, g] + desc + tb + ck
            rec += [u32(A[m0 + i][k]) for i in range(M) for k in range(K)]
            rec += [u32(B[k][n0 + j]) for k in range(K) for j in range(N)]
            rec += [u32(Q[m0 + i][n0 + j]) for i in range(M) for j in range(N)]
            lo, hi = R.srange(32)
            for i in range(M):
                for j in range(N):
                    v = raw[m0 + i][n0 + j]
                    clip = int(v < lo or v > hi)
                    rec.append(int(SAT[m0 + i][n0 + j]) | (clip << 1))
            rec += [u32(min(max(raw[m0 + i][n0 + j], lo), hi)) for i in range(M) for j in range(N)]
            self.words += [(T_JOB << 24) | len(rec)] + rec
            self.njobs += 1


SUITES = {
    "smoke": ["int32_pass", "int32_bias", "int8_pt"],
    "baseline": ["int32_pass", "int32_bias", "int8_pt", "int8_pt", "int32_bias", "int8_pt"],
    "layers": ["int8_pc", "int8_pt", "int8_pc", "int32_bias", "int8_asym", "int8_pc", "int8_asym", "stress",
               "int8_pt", "int8_pc"],
    "stress": ["stress", "stress", "int8_pc", "stress", "int32_bias", "stress"],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", required=True, choices=sorted(SUITES))
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--tiles", type=int, default=2)
    ap.add_argument("--acc", type=int, default=32)
    ap.add_argument("--grp", type=int, default=4)
    ap.add_argument("--asym", type=int, default=0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--repeat", type=int, default=1)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    g = G(a)
    for _ in range(a.repeat):
        for kind in SUITES[a.suite]:
            g.layer(kind)
    hdr = [MAGIC, 0, a.rows, a.cols, a.tiles, a.acc, a.asym, a.grp, g.njobs, g.nlayers]
    words = hdr + g.words
    words[1] = len(words)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w") as f:
        f.write("\n".join("%08x" % (w & 0xFFFFFFFF) for w in words) + "\n")
    print(f"GEN_INTEG suite={a.suite} layers={g.nlayers} jobs={g.njobs} words={len(words)}")
    for kind, pc, relu, za, ag, tot in g.info:
        print(f"GEMM_INFO kind={kind} per_channel={int(pc)} relu={int(relu)} zA={za} elements={tot} "
              f"integer_contract_equals_float_scale={ag}/{tot} ({100.0 * ag / max(1, tot):.2f}%)")


if __name__ == "__main__":
    main()
