#!/usr/bin/env python3
"""
TENSORCORE 05 -- Yosys 0.33 synthesis sweep (RESOURCE ESTIMATES ONLY).

Generic `synth` (technology-independent cells, with `check -assert`: no latches,
no multiple drivers, no combinational loops) and `synth_xilinx` (7-series
LUT/FF/DSP mapping, no place and route) of tensor_quantize.  NO timing / Fmax
is claimed: there is no place-and-route and no timing library in this flow.

The per-channel parameter table is a flop array in this reference RTL; the
`_grp1` configurations isolate the datapath from the table so the two costs can
be read separately.

  python3 synth/run_synth.py
"""
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/tensor_quantize_pkg.sv", "third_party/tensorcore04/rtl/tensor_acc_fifo.sv", "rtl/tensor_quant_params.sv",
       "rtl/tensor_quant_lane.sv", "rtl/tensor_quantize.sv"]

CONFIGS = [
    ("4x4_in32_grp1", dict(ROWS=4, COLS=4, IN_W=32, NUM_CTX=2, NUM_GRP=1, ASYM_EN=0)),
    ("4x4_in32_grp16", dict(ROWS=4, COLS=4, IN_W=32, NUM_CTX=2, NUM_GRP=16, ASYM_EN=0)),
    ("4x4_in32_grp16_asym", dict(ROWS=4, COLS=4, IN_W=32, NUM_CTX=2, NUM_GRP=16, ASYM_EN=1)),
    ("4x4_in40_grp16_asym", dict(ROWS=4, COLS=4, IN_W=40, NUM_CTX=2, NUM_GRP=16, ASYM_EN=1)),
    ("4x4_in32_grp1_noperf", dict(ROWS=4, COLS=4, IN_W=32, NUM_CTX=2, NUM_GRP=1, ASYM_EN=0, PERF_EN=0)),
    ("8x8_in32_grp4", dict(ROWS=8, COLS=8, IN_W=32, NUM_CTX=2, NUM_GRP=4, ASYM_EN=0)),
]


def run(name, params, flow):
    os.makedirs(os.path.join(ROOT, "synth/reports"), exist_ok=True)
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    if flow == "generic":
        synth = "synth -flatten -top tensor_quantize\ncheck -assert"
    else:
        synth = "synth_xilinx -flatten -top tensor_quantize -family xc7"
    ys = (f"read_verilog -sv {' '.join(RTL)}\n"
          f"chparam {chp} tensor_quantize\n"
          f"hierarchy -check -top tensor_quantize\n"
          f"proc\ncheck -assert\n"
          f"{synth}\n"
          f"tee -o synth/reports/stat_{flow}_{name}.txt stat\n")
    yfile = f"synth/reports/{flow}_{name}.ys"
    with open(os.path.join(ROOT, yfile), "w") as f:
        f.write(ys)
    r = subprocess.run(f"yosys -q -s {yfile}", shell=True, cwd=ROOT, capture_output=True, text=True, timeout=7200)
    with open(os.path.join(ROOT, f"synth/reports/{flow}_{name}.stdout"), "w") as f:
        f.write(r.stdout + r.stderr)
    if r.returncode != 0:
        return dict(name=name, flow=flow, ok=False, err=(r.stdout + r.stderr)[-600:])
    st = open(os.path.join(ROOT, f"synth/reports/stat_{flow}_{name}.txt")).read()
    cells = re.search(r"Number of cells:\s+(\d+)", st)
    out = dict(name=name, flow=flow, ok=True, cells=int(cells.group(1)) if cells else -1)
    latches = len(re.findall(r"\$_DLATCH", st))
    out["latches"] = latches
    if flow == "generic":
        out["ff"] = sum(int(n) for n in re.findall(r"\$_(?:S?DFF\w*|DFFE\w*|SDFF\w*|ALDFF\w*)_\s+(\d+)", st))
    else:
        out["ff"] = sum(int(n) for n in re.findall(r"\bFD\w*\s+(\d+)", st))
        out["lut"] = sum(int(n) for n in re.findall(r"\bLUT\d\s+(\d+)", st))
        out["dsp"] = sum(int(n) for n in re.findall(r"\bDSP48E1\s+(\d+)", st))
        out["carry4"] = sum(int(n) for n in re.findall(r"\bCARRY4\s+(\d+)", st))
        out["lutram"] = sum(int(n) for n in re.findall(r"\bRAM\w+\s+(\d+)", st))
    return out


def main():
    res = []
    for name, p in CONFIGS:
        for flow in ("generic", "xc7"):
            r = run(name, p, flow)
            print(r, flush=True)
            res.append(r)
    with open(os.path.join(ROOT, "reports/synth.json"), "w") as f:
        json.dump(res, f, indent=1)
    with open(os.path.join(ROOT, "reports/synthesis_summary.md"), "w") as f:
        f.write("# TENSORCORE 05 synthesis summary (Yosys 0.33)\n\n")
        f.write("Resource estimates only. No place and route, no timing library: **no Fmax or area claim.**\n")
        f.write("Every generic run passes `check -assert` (no latches, no multiple drivers, no logic loops).\n\n")
        f.write("| config | generic cells | generic FF | xc7 LUT | xc7 FF | xc7 DSP48E1 | xc7 CARRY4 | xc7 LUTRAM |\n")
        f.write("|---|---|---|---|---|---|---|---|\n")
        for name, _ in CONFIGS:
            g = next(r for r in res if r["name"] == name and r["flow"] == "generic")
            x = next(r for r in res if r["name"] == name and r["flow"] == "xc7")
            if g["ok"] and x["ok"]:
                f.write(f"| {name} | {g['cells']} | {g['ff']} | {x['lut']} | {x['ff']} | {x['dsp']} | {x['carry4']} | "
                        f"{x['lutram']} |\n")
            else:
                f.write(f"| {name} | FAILED | | | | | | |\n")
    sys.exit(0 if all(r["ok"] for r in res) else 1)


if __name__ == "__main__":
    main()
