# SilicaFlux TENSORCORE 05: tensor quantisation, bias, activation and output conversion

Aureom.AI | SilicaFlux-HPC. Primary source: **`rtl/tensor_quantize.sv`**.

This module converts the exact signed accumulations that TENSORCORE 04 commits (its `oquant_*` port, one
tile row per beat) into the output format a per-tile descriptor requests. The conversion uses one
documented integer contract, with no real-number arithmetic and no undocumented rounding or overflow:

```
x = acc + bias[n] - zA*colsum[n]                  exact          (bias, zA optional)
y = R_rm( x * M[n] / 2^S[n] ) + zp[n]             one rounding   (requantising modes)
q = clamp(y, qmin, qmax)  [or wrap, INT32 only]   flagged
q = max(q, zp[n])                                 ReLU, if selected
```

> **Not committed to GitHub.** Delivered as a plain archive (no `.git`).

## What is implemented

| | status |
|---|---|
| INT32 pass-through | **baseline**, brought up first (stage 1) |
| INT32 + bias, saturate (default) or explicit wrap, always flagged | **baseline** (stage 2) |
| INT8 requantisation, M (s32) / S (0..63), RNE, output zero-point | **baseline** (stage 3) |
| ReLU (floor = output zero-point, the correct quantised-domain ReLU) | **baseline** (stage 3) |
| per-output-channel M, S, zp (+ bias), parameter table + load port, snapshot per tile | stage 4 |
| RTZ / RDN / RUP / RMM rounding (RISC-V `frm` encoding), INT32 requantisation | stage 4, additional, independently verified |
| input (activation) zero-point zA with symmetric weights, via weight column sums (`ASYM_EN = 1`) | stage 4 |
| weight zero-point zB ≠ 0 | **unsupported, rejected** (the array produces no row sums of A) |
| INT4, BF16, FP16, FP32 accumulation, FP8, sparse | **roadmap only** (`docs/ROADMAP.md`), rejected today |

The **output channel is N**, the column dimension of `C = A×B` (TC04's `bias[n]` axis). Lane `j` of a beat
is channel `CH_GRP·COLS + j`.

## Results (final runs on these sources)

* **Regression: 1239 / 1239 checks pass.** That is 455 Icarus runs, 467 Verilator runs, 316
  cross-simulator log comparisons (all line-for-line identical), and the reference-model self-test. The
  stages ran strictly in order: INT32 pass-through (44 / 44), then bias (44 / 44), then INT8
  requantisation (88 / 88), then the advanced modes, the configuration matrix and the integration
  (1062 / 1062).
* **Definition of done: met.** Every converted element of every run equals the declared fixed-point
  contract exactly, including the rounding and the saturation flag. The unit tests cover 750 k elements,
  145 k of them saturated; every shift 0..63; thousands of exact rounding ties per mode
  (`reports/coverage.md`). The full chain, **unmodified TC02 array → unmodified TC04 → TC05**, was run on
  representative quantised GEMM layers: 3 638 tiles, 7 015 chunk launches and 43 796 elements, each
  compared with `Σ(A − zA)·B` evaluated literally.
* **Mutation testing: 69 / 70 injected bugs killed** by the testbench alone. The survivor is proven
  equivalent. Two test gaps the first run exposed are closed (`docs/VERIFICATION.md` §5).
* **Reference-model proofs by enumeration:** 638 281 checks. The RTL rounding algorithm equals the
  definitions of all five modes, and every intermediate width holds every input corner for IN_W
  32/40/48/64.
* **Throughput** is one beat (COLS elements) per cycle with `OFIFO_DEPTH ≥ 4`; latency is 3 cycles. Output
  backpressure never stalls the pipeline (credits).
* **Lint** (`verilator -Wall`) is clean over 8 parameter sets. **Yosys** maps every configuration with no
  latches. The 4×4 xc7 estimate is ≈ 5.2 k LUT, 2.7 k FF and 16 DSP48 for the datapath (5.8 k LUT with a
  16-group parameter table in LUTRAM). These are **estimates only; no timing
  or Fmax is claimed.**

## Layout

| path | contents |
|---|---|
| `rtl/tensor_quantize.sv` | **primary source**: descriptor decode / validation, slot-indexed contexts with parameter snapshots, stage A, credit-reserved output FIFO, counters |
| `rtl/tensor_quant_lane.sv` | per-lane exact multiply, single rounding (5 modes), zero-point, saturation / wrap, ReLU |
| `rtl/tensor_quant_params.sv` | **parameter storage and load interface** (channel groups, lane / field masks, valid bits) |
| `rtl/tensor_quantize_pkg.sv` | ABI encodings, codes, counter indices, width functions |
| `model/tq_ref.py` | **independent integer reference** (Fraction-based), descriptor ABI, `quantize_multiplier`, `qgemm_direct` |
| `tests/test_ref_model.py` | rounding / width / identity proofs by enumeration |
| `tb/tb_tq.sv`, `tools/gen_unit.py` | unit TB and its vector generator (13 suites + throughput) |
| `tb/tb_tq_integ.sv`, `tools/gen_integ.py` | integration TB (TC02 → TC04 → TC05) and quantised-GEMM layer generator |
| `integration/tensor_core_output.sv` | **integration example** (TC04 subsystem + quantiser) |
| `integration/example_layer.py` | host side: real scales → (M, S), parameter writes, descriptors, expected output |
| `tools/run_regress.py`, `tools/mutation_test.py`, `tools/coverage.py`, `tools/check_abi.py`, `synth/run_synth.py` | regression, mutation, coverage, ABI check, synthesis |
| `docs/` | `NUMERIC_FORMAT` (**the numeric-format specification**), `ARCHITECTURE`, `AUDIT`, `INTEGRATION`, `VERIFICATION`, `ROADMAP` |
| `third_party/` | TC04 and TC02 RTL, unmodified, with hashes (`NOTICE.md`); TC04's FIFO is reused inside the quantiser |
| `reports/`, `logs/` | outputs of the final runs |

## Quick start

Requires Icarus Verilog 12, Verilator 5.020, Yosys 0.33 and Python 3 (standard library only); these are
the SilicaFlux baseline, available as Ubuntu 24.04 packages.

```
make model      # reference-model proofs (seconds)
make abi        # RTL package == Python reference
make smoke      # START: INT32 pass-through + one real-array integration run (Icarus, seconds)
make stage1     # stage 1 only; then make stage2, make stage3
make regress    # everything, in stage order, both simulators (about a minute on 4 cores)
make lint perf mutation synth
```

All vectors are regenerated deterministically (seeded), so `vectors/` and `build/` are not shipped.

## Integration in one paragraph

Put `tensor_quantize` on TC04's quantiser port: `oquant_valid/ready → in_valid/ready`, `o_slot → in_ctx`,
`o_tag/o_row/o_last/o_col_mask → in_*`, `o_wide → in_data` (the exact lanes, `IN_W = ACC_W`),
`o_ovf/o_err → in_ovf/in_err`. `integration/tensor_core_output.sv` does exactly this. Load each layer's
per-channel groups on `p_*`. For each tile routed to the quantiser, send one 256-bit OPEN descriptor with
`CTX = slot` and `TAG = tag`. It may arrive late, and the beats wait for it. Apply bias in TC04 **or** here,
never both. Results leave on `out_*` with their element index (`out_m`, `out_ch0 + lane`), tag, format,
saturation and error flags. Raw INT32 keeps flowing on TC04's SRAM / DMA ports and is never requantised.
See `docs/INTEGRATION.md`.

## Honest caveats

The verification is simulation only (Icarus + Verilator): no formal proof on the RTL, no gate-level
simulation, no FPGA or silicon. The parameter table is a flop / LUTRAM reference; no SRAM macro is
included. The integration TB models the operand feed (TC03 not instantiated), and full-chain abort and
reset are tested at unit level only. Column sums for the zA correction must be supplied correctly by the
host; the hardware never sees the weights, so it cannot check them. This contract rounds once, so it is
not bit-identical with TFLite's double-rounding requantiser (`docs/NUMERIC_FORMAT.md` §3.2).
