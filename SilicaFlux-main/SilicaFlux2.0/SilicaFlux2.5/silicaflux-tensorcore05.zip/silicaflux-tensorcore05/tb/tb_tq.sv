// =============================================================================
//  SilicaFlux TENSORCORE 05  --  tb_tq.sv
//  Unit testbench for tensor_quantize (vector-driven; vectors and every
//  expected value come from tools/gen_unit.py + model/tq_ref.py).
//
//  THREADS
//    dispatcher : reads the command list in order; queues control commands
//                 (parameter writes, descriptors, same-cycle pairs, syncs) and
//                 beats; executes barriers (DRAIN, PERF, STATUS, STICKY,
//                 PERFCLR) and RESET (after a random delay, while traffic is
//                 still in flight).
//    control    : drives p_* and desc_* in list order, random gaps; checks the
//                 response pulses (p_err / desc_ok / desc_rej / code).
//    beats      : drives in_* in list order, random gaps; on every accepted
//                 beat pushes its expected output onto the scoreboard.
//    monitor    : random out_ready (per-cycle % and long stall bursts); every
//                 output beat is compared field by field with the scoreboard
//                 head; payload and valid must stay stable while stalled.
//
//  CHECKS: every output field of every beat; response codes of every
//  descriptor and parameter write; ctx_open / ctx_poison; sticky error
//  vectors; all 13 performance counters against the testbench's own tallies
//  (stall counters against its own observation of the ports); no output
//  without an accepted beat; drain to idle; watchdog.
//
//  DUT outputs are never read by a delayed thread AT a clock edge: an edge
//  sampler latches handshakes and threads read them after `@(posedge clk); #1`
//  (TENSORCORE 04 discipline, required for Verilator --timing).
//
//  +VEC=<file> +SEED=<n> +ORDY=<%> +OBURST=<%%> +BGAP=<%> +CGAP=<%>
// =============================================================================
`timescale 1ns/1ps
module tb_tq #(
    parameter int ROWS        = 4,
    parameter int COLS        = 4,
    parameter int IN_W        = 32,
    parameter int NUM_CTX     = 2,
    parameter int NUM_GRP     = 4,
    parameter int ASYM_EN     = 0,
    parameter int OFIFO_DEPTH = 4,
    parameter int PERF_W      = 32,
    parameter int MEMW        = 1 << 22
);
    localparam int CTX_W = (NUM_CTX > 1) ? $clog2(NUM_CTX) : 1;
    localparam int RIDW  = (ROWS > 1) ? $clog2(ROWS) : 1;
    localparam int NPERF = 13;
    localparam int MAXL  = 1 << 18;
    localparam logic [7:0] C_PW = 1, C_DESC = 2, C_BEAT = 3, C_SAME = 4, C_RESET = 5, C_DRAIN = 6,
                           C_PERF = 7, C_PERFCLR = 8, C_SYNC = 9, C_STATUS = 10, C_STICKY = 11, C_BSYNC = 12;
    localparam int PWL = 4 + 6 * COLS;      // parameter-write payload words

    logic clk = 1'b0;
    always #5 clk = ~clk;
    logic rst_n = 1'b0;

    // ------------------------------------------------------------------ DUT
    logic                    desc_valid = 1'b0, desc_ready, desc_ok, desc_rej;
    logic [255:0]            desc_data = '0;
    logic [3:0]              desc_rej_code;
    logic                    p_valid = 1'b0, p_ready, p_err;
    logic [15:0]             p_grp = '0;
    logic [COLS-1:0]         p_lane_mask = '0;
    logic [4:0]              p_fmask = '0;
    logic [COLS*32-1:0]      p_bias = '0, p_mult = '0, p_zp = '0;
    logic [COLS*6-1:0]       p_shift = '0;
    logic [COLS*IN_W-1:0]    p_cs = '0;
    logic [1:0]              p_err_code;
    logic                    in_valid = 1'b0, in_ready, in_last = 1'b0, in_err = 1'b0;
    logic [CTX_W-1:0]        in_ctx = '0;
    logic [15:0]             in_tag = '0;
    logic [RIDW-1:0]         in_row = '0;
    logic [COLS-1:0]         in_col_mask = '0, in_ovf = '0;
    logic [COLS*IN_W-1:0]    in_data = '0;
    logic                    out_valid, out_ready, out_last, out_err;
    logic [15:0]             out_tag;
    logic [CTX_W-1:0]        out_ctx;
    logic [RIDW-1:0]         out_row;
    logic [31:0]             out_m, out_ch0;
    logic [COLS-1:0]         out_col_mask, out_sat, out_iovf;
    logic [3:0]              out_fmt;
    logic [COLS*32-1:0]      out_data;
    logic [COLS*8-1:0]       out_q8;
    logic [2:0]              out_err_code;
    logic [NUM_CTX-1:0]      ctx_open, ctx_poison;
    logic                    idle, perf_clr = 1'b0;
    logic [15:0]             desc_err_sticky;
    logic [7:0]              beat_err_sticky;
    logic [3:0]              param_err_sticky;
    logic [NPERF*PERF_W-1:0] perf_o;

    tensor_quantize #(.ROWS(ROWS), .COLS(COLS), .IN_W(IN_W), .NUM_CTX(NUM_CTX), .NUM_GRP(NUM_GRP),
                      .ASYM_EN(ASYM_EN), .OFIFO_DEPTH(OFIFO_DEPTH), .PERF_W(PERF_W)) dut (
        .clk, .rst_n,
        .desc_valid, .desc_ready, .desc_data, .desc_ok, .desc_rej, .desc_rej_code,
        .p_valid, .p_ready, .p_grp, .p_lane_mask, .p_fmask, .p_bias, .p_mult, .p_shift, .p_zp, .p_cs,
        .p_err, .p_err_code,
        .in_valid, .in_ready, .in_ctx, .in_tag, .in_row, .in_col_mask, .in_last, .in_data, .in_ovf, .in_err,
        .out_valid, .out_ready, .out_tag, .out_ctx, .out_row, .out_m, .out_ch0, .out_col_mask, .out_last,
        .out_fmt, .out_data, .out_q8, .out_sat, .out_iovf, .out_err, .out_err_code,
        .ctx_open, .ctx_poison, .idle, .desc_err_sticky, .beat_err_sticky, .param_err_sticky,
        .perf_clr, .perf_o);

    // ------------------------------------------------------------------ state
    logic [31:0] vec [0:MEMW-1];
    int ctl_list [0:MAXL-1];
    int beat_list [0:MAXL-1];
    int sb_list [0:MAXL-1];
    int ctl_head = 0, ctl_tail = 0, beat_head = 0, beat_tail = 0, sb_head = 0, sb_tail = 0;
    int epoch = 0;
    int errors = 0, cyc = 0, last_progress = 0;
    int seed = 1, ordy = 100, oburst = 0, bgap = 0, cgap = 0;
    longint acc_count = 0;                 // beats accepted since the last reset
    longint ctl_done = 0;                  // control commands completed since the last reset
    longint tally [NPERF];
    longint n_beats_in = 0, n_beats_out = 0, n_elems = 0, n_desc = 0, n_pw = 0, n_resets = 0, n_checks = 0;
    longint n_same = 0, n_sat = 0, n_relu = 0, n_err_beats = 0;
    longint first_in = -1, last_in = -1, first_out = -1, lat_min = 1000000;
    logic   nostall = 1'b0;
    always @(posedge clk) begin
        if (rst_n === 1'b1 && in_valid && in_ready) begin
            if (first_in < 0) first_in = cyc;
            last_in = cyc;
        end
        if (rst_n === 1'b1 && out_valid && out_ready && first_out < 0) first_out = cyc;
    end

    always @(posedge clk) cyc <= cyc + 1;

    function automatic logic [31:0] xs(input logic [31:0] s);
        logic [31:0] x;
        x = s; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5);
        xs = x;
    endfunction

    function automatic int popc(input logic [31:0] v);
        popc = 0;
        for (int i = 0; i < 32; i++) popc = popc + int'(v[i]);
    endfunction

    task automatic fail(input string msg);
        errors = errors + 1;
        if (errors <= 40) $display("TB_ERROR cyc=%0d: %s", cyc, msg);
        if (errors > 200) begin
            $display("TB_ERROR: more than 200 errors, stopping");
            $display("TB_RESULT: FAIL");
            $finish;
        end
    endtask

    // Each thread resumes in its own post-edge slot, so the order in which threads observe
    // one another never depends on the process scheduling of the simulator (Icarus and
    // both simulators give identical logs): dispatcher/reset #1, control #2, beats #3.
    task automatic tick();
        @(posedge clk);
        #1;
    endtask
    task automatic tick_c();
        @(posedge clk);
        #2;
    endtask
    task automatic tick_b();
        @(posedge clk);
        #3;
    endtask

    // ------------------------------------------------------------------ environment: out_ready
    logic [31:0] env_rs = 32'h2468_ACE1;
    int burst = 0;
    logic ordy_q = 1'b0;
    assign out_ready = ordy_q;
    always @(posedge clk) begin
        logic [31:0] r;
        r = xs(env_rs);
        env_rs <= xs(r);
        if (burst > 0) begin
            burst <= burst - 1;
            ordy_q <= 1'b0;
        end else if (((r >> 7) % 10000) < 32'(oburst)) begin
            burst <= int'((r >> 17) % 64) + 1;
            ordy_q <= 1'b0;
        end else begin
            ordy_q <= ((r % 100) < 32'(ordy));
        end
    end

    // ------------------------------------------------------------------ optional trace (+TRACE)
    logic trace = 1'b0;
    always @(posedge clk) begin
        if (trace && rst_n === 1'b1) begin
            if (desc_valid && desc_ready)
                $display("TRACE cyc=%0d DESC op=%02h ctx=%0d tag=%0d", cyc, desc_data[7:0], desc_data[55:48], desc_data[47:32]);
            if (p_valid && p_ready) $display("TRACE cyc=%0d PW grp=%0d", cyc, p_grp);
            if (in_valid && in_ready)
                $display("TRACE cyc=%0d BEAT ctx=%0d tag=%0d row=%0d last=%b open=%b", cyc, in_ctx, in_tag, in_row, in_last, ctx_open);
            if (out_valid && out_ready) $display("TRACE cyc=%0d OUT tag=%0d row=%0d code=%0d", cyc, out_tag, out_row, out_err_code);
        end
    end

    // ------------------------------------------------------------------ edge sampler
    logic smp_p_hs = 0, smp_d_hs = 0, smp_in_hs = 0;
    always @(posedge clk) begin
        smp_p_hs  <= (rst_n === 1'b1) && p_valid && p_ready;
        smp_d_hs  <= (rst_n === 1'b1) && desc_valid && desc_ready;
        smp_in_hs <= (rst_n === 1'b1) && in_valid && in_ready;
    end

    // ------------------------------------------------------------------ stall tallies (port observation)
    always @(posedge clk) begin
        if (rst_n === 1'b1) begin
            if (perf_clr === 1'b1) begin
                for (int i = 0; i < NPERF; i++) tally[i] = 0;
            end else begin
                if (in_valid && !in_ready) tally[10] = tally[10] + 1;
                if (in_valid && (32'(in_ctx) < NUM_CTX) && !ctx_open[in_ctx]) tally[11] = tally[11] + 1;
                if (out_valid && !out_ready) tally[12] = tally[12] + 1;
            end
        end
    end

    // ------------------------------------------------------------------ random gap
    logic [31:0] ctl_rs, beat_rs;
    task automatic gap_ctl();
        logic [31:0] r;
        r = xs(ctl_rs); ctl_rs = r;
        while ((r % 100) < 32'(cgap)) begin
            tick_c();
            r = xs(ctl_rs); ctl_rs = r;
        end
    endtask
    task automatic gap_beat();
        logic [31:0] r;
        r = xs(beat_rs); beat_rs = r;
        while ((r % 100) < 32'(bgap)) begin
            tick_b();
            r = xs(beat_rs); beat_rs = r;
        end
    endtask

    // ------------------------------------------------------------------ control thread
    // NOTE: wide DUT inputs are assembled in locals and assigned WHOLE.  Verilator 5.020
    // with --timing does not re-evaluate combinational logic after per-slice non-blocking
    // writes `bus[j*W +: W] <= ...` made in a loop inside an automatic task (found here:
    // the DUT saw a stale descriptor; Icarus was unaffected).
    task automatic load_pw(input int b);
        logic [COLS*32-1:0]   vb, vm, vz;
        logic [COLS*6-1:0]    vs;
        logic [COLS*IN_W-1:0] vc;
        for (int j = 0; j < COLS; j++) begin
            int l;
            l = b + 4 + 6 * j;
            vb[j*32 +: 32]   = vec[l];
            vm[j*32 +: 32]   = vec[l + 1];
            vs[j*6 +: 6]     = vec[l + 2][5:0];
            vz[j*32 +: 32]   = vec[l + 3];
            vc[j*IN_W +: IN_W] = IN_W'({vec[l + 5], vec[l + 4]});
        end
        p_grp       <= vec[b][15:0];
        p_lane_mask <= COLS'(vec[b + 1]);
        p_fmask     <= vec[b + 2][4:0];
        p_bias      <= vb;
        p_mult      <= vm;
        p_shift     <= vs;
        p_zp        <= vz;
        p_cs        <= vc;
    endtask
    task automatic load_desc(input int b);
        logic [255:0] v;
        for (int w = 0; w < 8; w++) v[w*32 +: 32] = vec[b + w];
        desc_data <= v;
    endtask
    task automatic chk_pw(input int b);
        int code;
        code = int'(vec[b + 3]);
        if (p_err !== (code != 0) || int'(p_err_code) != code)
            fail($sformatf("param write grp %0d: p_err=%b code=%0d, expected code %0d", vec[b], p_err, p_err_code, code));
        if (code == 0) tally[8] = tally[8] + 1; else tally[9] = tally[9] + 1;
        n_pw = n_pw + 1;
    endtask
    task automatic chk_desc(input int b);
        int code;
        code = int'(vec[b + 8]);
        if (desc_ok !== (code == 0) || desc_rej !== (code != 0) || int'(desc_rej_code) != code)
            fail($sformatf("descriptor (hdr %08h ctx %0d tag %0d): ok=%b rej=%b code=%0d, expected code %0d",
                           vec[b], vec[b + 1][23:16], vec[b + 1][15:0], desc_ok, desc_rej, desc_rej_code, code));
        if (code == 0) tally[6] = tally[6] + 1; else tally[7] = tally[7] + 1;
        n_desc = n_desc + 1;
    endtask

    initial begin : control
        forever begin
            int o, ep;
            logic [7:0] op;
            while (ctl_head == ctl_tail) tick_c();
            o = ctl_list[ctl_head];
            ep = epoch;
            op = vec[o][31:24];
            if (op == C_SYNC) begin
                if (trace) $display("TRACE cyc=%0d SYNC wait %0d (have %0d)", cyc, vec[o + 1], acc_count);
                while (acc_count < longint'(vec[o + 1]) && ep == epoch) tick_c();
            end else begin
                gap_ctl();
                if (ep != epoch) begin
                    // a reset arrived during the gap: the item was abandoned
                end else if (op == C_PW) begin
                    load_pw(o + 1);
                    p_valid <= 1'b1;
                    tick_c();
                    while (!smp_p_hs && ep == epoch) tick_c();
                    p_valid <= 1'b0;
                    if (ep == epoch) chk_pw(o + 1);
                end else if (op == C_DESC) begin
                    load_desc(o + 1);
                    desc_valid <= 1'b1;
                    tick_c();
                    while (!smp_d_hs && ep == epoch) tick_c();
                    desc_valid <= 1'b0;
                    if (ep == epoch) chk_desc(o + 1);
                end else if (op == C_SAME) begin
                    // present both payloads, wait until the descriptor can be taken, then raise both
                    // valids together: both handshakes happen at the same clock edge
                    load_pw(o + 1);
                    load_desc(o + 1 + PWL);
                    tick_c();
                    while (desc_ready !== 1'b1 && ep == epoch) tick_c();
                    if (ep == epoch) begin
                        p_valid <= 1'b1;
                        desc_valid <= 1'b1;
                        tick_c();
                        p_valid <= 1'b0;
                        desc_valid <= 1'b0;
                        if (ep == epoch) begin
                            if (!(smp_p_hs && smp_d_hs)) fail("same-cycle write + descriptor did not handshake together");
                            chk_pw(o + 1);
                            chk_desc(o + 1 + PWL);
                            n_same = n_same + 1;
                        end
                    end
                end else begin
                    fail($sformatf("bad control op %0d", op));
                end
            end
            if (ep == epoch) begin
                ctl_head = ctl_head + 1;
                ctl_done = ctl_done + 1;
            end
            last_progress = cyc;
        end
    end

    // ------------------------------------------------------------------ beat thread
    initial begin : beats
        forever begin
            int o, ep;
            while (beat_head == beat_tail) tick_b();
            o = beat_list[beat_head];
            ep = epoch;
            if (vec[o][31:24] == C_BSYNC) begin
                while (ctl_done < longint'(vec[o + 1]) && ep == epoch) tick_b();
                if (ep == epoch) beat_head = beat_head + 1;
            end else begin
            gap_beat();
            if (ep == epoch) begin
                in_ctx      <= CTX_W'(vec[o + 1]);
                in_tag      <= vec[o + 2][15:0];
                in_row      <= RIDW'(vec[o + 3]);
                in_col_mask <= COLS'(vec[o + 4]);
                in_last     <= vec[o + 5][0];
                in_err      <= vec[o + 6][0];
                in_ovf      <= COLS'(vec[o + 7]);
                begin
                    logic [COLS*IN_W-1:0] vd;
                    for (int j = 0; j < COLS; j++) vd[j*IN_W +: IN_W] = IN_W'({vec[o + 9 + 2*j], vec[o + 8 + 2*j]});
                    in_data <= vd;
                end
                in_valid <= 1'b1;
                tick_b();
                while (!smp_in_hs && ep == epoch) tick_b();
                in_valid <= 1'b0;
                if (ep == epoch) begin
                    int e;
                    e = o + 8 + 2 * COLS;
                    sb_list[sb_tail] = o;
                    sb_tail = sb_tail + 1;
                    acc_count = acc_count + 1;
                    tally[0] = tally[0] + 1;
                    tally[2] = tally[2] + longint'(vec[e + 12]);
                    if (vec[e + 8] != 0) tally[5] = tally[5] + 1;
                    n_beats_in = n_beats_in + 1;
                    n_elems = n_elems + longint'(vec[e + 12]);
                    beat_head = beat_head + 1;
                end
            end
            end
            last_progress = cyc;
        end
    end

    // ------------------------------------------------------------------ output monitor
    logic                 st_prev = 1'b0;
    logic [COLS*32-1:0]   st_data;
    logic [15:0]          st_tag;
    logic [31:0]          st_m;
    logic [COLS-1:0]      st_sat;
    logic [2:0]           st_code;
    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            st_prev <= 1'b0;
        end else begin
            if (st_prev && (out_valid !== 1'b1 || out_data !== st_data || out_tag !== st_tag ||
                            out_m !== st_m || out_sat !== st_sat || out_err_code !== st_code))
                fail("output changed or dropped while stalled (valid/ready rule)");
            st_prev <= out_valid && !out_ready;
            st_data <= out_data; st_tag <= out_tag; st_m <= out_m; st_sat <= out_sat; st_code <= out_err_code;
            if (out_valid === 1'b1 && out_ready === 1'b1) begin
                if (sb_head == sb_tail) fail("output beat without an accepted input beat");
                else begin
                    int o, e;
                    o = sb_list[sb_head];
                    e = o + 8 + 2 * COLS;
                    sb_head = sb_head + 1;
                    if (out_tag !== vec[e][15:0] || 32'(out_ctx) != vec[e + 1] || 32'(out_row) != vec[e + 2] ||
                        out_m !== vec[e + 3] || out_ch0 !== vec[e + 4] || 32'(out_col_mask) != vec[e + 5] ||
                        32'(out_last) != vec[e + 6] || 32'(out_fmt) != vec[e + 7] || 32'(out_err_code) != vec[e + 8] ||
                        out_err !== (vec[e + 8] != 0) || 32'(out_sat) != vec[e + 9] || 32'(out_iovf) != vec[e + 10])
                        fail($sformatf("beat (cmd @%0d) sideband: tag %0d/%0d ctx %0d/%0d row %0d/%0d m %0d/%0d ch0 %0d/%0d mask %b/%0h last %b/%0d fmt %0d/%0d code %0d/%0d sat %b/%0h iovf %b/%0h",
                                       o, out_tag, vec[e], out_ctx, vec[e+1], out_row, vec[e+2], out_m, vec[e+3],
                                       out_ch0, vec[e+4], out_col_mask, vec[e+5], out_last, vec[e+6], out_fmt, vec[e+7],
                                       out_err_code, vec[e+8], out_sat, vec[e+9], out_iovf, vec[e+10]));
                    for (int j = 0; j < COLS; j++) begin
                        if (out_data[j*32 +: 32] !== vec[e + 13 + j] || out_q8[j*8 +: 8] !== vec[e + 13 + j][7:0])
                            fail($sformatf("beat (cmd @%0d) tag %0d row %0d lane %0d: data %0d (q8 %0d), expected %0d [acc %0d]",
                                           o, out_tag, out_row, j, $signed(out_data[j*32 +: 32]), $signed(out_q8[j*8 +: 8]),
                                           $signed(vec[e + 13 + j]), $signed({vec[o + 9 + 2*j], vec[o + 8 + 2*j]})));
                    end
                    tally[1] = tally[1] + 1;
                    tally[3] = tally[3] + popc(vec[e + 9]);
                    tally[4] = tally[4] + popc(vec[e + 11]);
                    n_beats_out = n_beats_out + 1;
                    n_sat = n_sat + popc(vec[e + 9]);
                    n_relu = n_relu + popc(vec[e + 11]);
                    if (vec[e + 8] != 0) n_err_beats = n_err_beats + 1;
                    last_progress = cyc;
                end
            end
            if (out_valid === 1'bx || in_ready === 1'bx || desc_ready === 1'bx || p_ready === 1'bx)
                fail("X on a handshake output");
        end
    end

    // ------------------------------------------------------------------ barriers
    task automatic drain();
        while (!(ctl_head == ctl_tail && beat_head == beat_tail && sb_head == sb_tail && idle === 1'b1)) tick();
        repeat (2) tick();
        if (sb_head != sb_tail) fail("scoreboard not empty after drain");
    endtask

    task automatic check_perf();
        for (int i = 0; i < NPERF; i++) begin
            longint e, got, mx;
            mx = (PERF_W >= 63) ? 64'h7FFF_FFFF_FFFF_FFFF : ((longint'(1) << PERF_W) - 1);
            e = (tally[i] > mx) ? mx : tally[i];
            got = longint'(perf_o[i*PERF_W +: PERF_W]);
            if (got != e) fail($sformatf("perf counter %0d = %0d, expected %0d", i, got, e));
        end
        n_checks = n_checks + 1;
    endtask

    task automatic do_reset(input int delay);
        repeat (delay) tick();
        rst_n <= 1'b0;
        epoch = epoch + 1;
        ctl_head = ctl_tail;
        beat_head = beat_tail;
        sb_head = sb_tail;
        p_valid <= 1'b0;
        desc_valid <= 1'b0;
        in_valid <= 1'b0;
        acc_count = 0;
        ctl_done = 0;
        for (int i = 0; i < NPERF; i++) tally[i] = 0;
        repeat (2) tick();
        rst_n <= 1'b1;
        tick();
        n_resets = n_resets + 1;
        // everything really cleared
        if (ctx_open !== '0 || ctx_poison !== '0 || desc_err_sticky !== '0 || beat_err_sticky !== '0 ||
            param_err_sticky !== '0 || idle !== 1'b1 || out_valid !== 1'b0)
            fail("state not cleared by reset");
        for (int i = 0; i < NPERF; i++) if (perf_o[i*PERF_W +: PERF_W] !== '0 && i < 10) fail("counter not cleared by reset");
    endtask

    // ------------------------------------------------------------------ main / dispatcher
    initial begin : main
        string vfile;
        int at, ncmd;
        if ($value$plusargs("SEED=%d", seed)) ;
        if ($value$plusargs("ORDY=%d", ordy)) ;
        if ($value$plusargs("OBURST=%d", oburst)) ;
        if ($value$plusargs("BGAP=%d", bgap)) ;
        if ($value$plusargs("CGAP=%d", cgap)) ;
        trace = $test$plusargs("TRACE");
        nostall = $test$plusargs("NOSTALL");
        env_rs  = xs(32'(seed) ^ 32'hFACE_B00C);
        ctl_rs  = xs(32'(seed) ^ 32'h1357_9BDF);
        beat_rs = xs(32'(seed) ^ 32'h0BAD_F00D);
        for (int i = 0; i < NPERF; i++) tally[i] = 0;
        if (!$value$plusargs("VEC=%s", vfile)) begin
            $display("TB_RESULT: FAIL (no +VEC)");
            $finish;
        end
        $readmemh(vfile, vec);
        if (vec[0] !== 32'h7C05_1001 || vec[2] != ROWS || vec[3] != COLS || vec[4] != IN_W ||
            vec[5] != NUM_CTX || vec[6] != NUM_GRP || vec[7] != ASYM_EN) begin
            $display("TB_RESULT: FAIL (vector file does not match this configuration)");
            $finish;
        end
        ncmd = int'(vec[8]);
        $display("TB_INFO vec=%s words=%0d cmds=%0d ROWS=%0d COLS=%0d IN_W=%0d CTX=%0d GRP=%0d ASYM=%0d OFIFO=%0d PERF_W=%0d seed=%0d ordy=%0d oburst=%0d bgap=%0d cgap=%0d",
                 vfile, vec[1], ncmd, ROWS, COLS, IN_W, NUM_CTX, NUM_GRP, ASYM_EN, OFIFO_DEPTH, PERF_W,
                 seed, ordy, oburst, bgap, cgap);
        repeat (4) tick();
        rst_n <= 1'b1;
        repeat (2) tick();
        last_progress = cyc;
        at = 9;
        for (int i = 0; i < ncmd; i++) begin
            logic [7:0] op;
            op = vec[at][31:24];
            case (op)
                C_PW, C_DESC, C_SAME, C_SYNC: begin ctl_list[ctl_tail] = at; ctl_tail = ctl_tail + 1; end
                C_BEAT, C_BSYNC: begin beat_list[beat_tail] = at; beat_tail = beat_tail + 1; end
                C_DRAIN:  drain();
                C_PERF:   begin drain(); check_perf(); end
                C_PERFCLR: begin
                    drain();
                    perf_clr <= 1'b1;
                    tick();
                    perf_clr <= 1'b0;
                    tick();
                end
                C_STATUS: begin
                    drain();
                    if (32'(ctx_open) != vec[at + 1] || 32'(ctx_poison) != vec[at + 2])
                        fail($sformatf("ctx_open %b / poison %b, expected %0h / %0h", ctx_open, ctx_poison,
                                       vec[at + 1], vec[at + 2]));
                end
                C_STICKY: begin
                    drain();
                    if (32'(desc_err_sticky) != vec[at + 1] || 32'(beat_err_sticky) != vec[at + 2] ||
                        32'(param_err_sticky) != vec[at + 3])
                        fail($sformatf("sticky desc %04h beat %02h param %0h, expected %0h %0h %0h", desc_err_sticky,
                                       beat_err_sticky, param_err_sticky, vec[at + 1], vec[at + 2], vec[at + 3]));
                end
                C_RESET:  do_reset(int'(vec[at + 1]));
                default:  fail($sformatf("bad command %0d at %0d", op, at));
            endcase
            at = at + 1 + int'(vec[at][23:0]);
        end
        drain();
        $display("TB_PERF %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
                 perf_o[0*PERF_W +: PERF_W], perf_o[1*PERF_W +: PERF_W], perf_o[2*PERF_W +: PERF_W],
                 perf_o[3*PERF_W +: PERF_W], perf_o[4*PERF_W +: PERF_W], perf_o[5*PERF_W +: PERF_W],
                 perf_o[6*PERF_W +: PERF_W], perf_o[7*PERF_W +: PERF_W], perf_o[8*PERF_W +: PERF_W],
                 perf_o[9*PERF_W +: PERF_W], perf_o[10*PERF_W +: PERF_W], perf_o[11*PERF_W +: PERF_W],
                 perf_o[12*PERF_W +: PERF_W]);
        $display("TB_SUMMARY beats_in=%0d beats_out=%0d elems=%0d sat=%0d relu=%0d err_beats=%0d descs=%0d pws=%0d same_cycle=%0d resets=%0d perf_checks=%0d cycles=%0d errors=%0d",
                 n_beats_in, n_beats_out, n_elems, n_sat, n_relu, n_err_beats, n_desc, n_pw, n_same, n_resets,
                 n_checks, cyc, errors);
        if (first_in >= 0)
            $display("TB_THROUGHPUT beats=%0d cycles_first_to_last_accept=%0d first_accept_to_first_output=%0d",
                     n_beats_in, last_in - first_in + 1, first_out - first_in);
        // credit (backpressure) stalls = input stalls that are not waits for a descriptor
        if (nostall && perf_o[10*PERF_W +: PERF_W] != perf_o[11*PERF_W +: PERF_W])
            fail($sformatf("throughput: %0d credit stall cycles (expected none)",
                           perf_o[10*PERF_W +: PERF_W] - perf_o[11*PERF_W +: PERF_W]));
        if (nostall && last_in - first_in + 1 != n_beats_in)
            fail("throughput: not one beat per cycle");
        $display("TB_RESULT: %s", (errors == 0) ? "PASS" : "FAIL");
        $finish;
    end

    always @(posedge clk) begin
        if (cyc > 100 && cyc - last_progress > 20000) begin
            fail($sformatf("watchdog: no progress for 20000 cycles (ctl %0d/%0d beat %0d/%0d sb %0d/%0d idle %b in_ready %b desc_ready %b ctx_open %b)",
                           ctl_head, ctl_tail, beat_head, beat_tail, sb_head, sb_tail, idle, in_ready, desc_ready, ctx_open));
            $display("TB_RESULT: FAIL");
            $finish;
        end
    end
endmodule
