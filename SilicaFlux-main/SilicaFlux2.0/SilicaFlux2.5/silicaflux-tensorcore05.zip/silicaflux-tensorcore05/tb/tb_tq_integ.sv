// =============================================================================
//  SilicaFlux TENSORCORE 05  --  tb_tq_integ.sv
//  Integration testbench:
//      TENSORCORE 02 tensor_systolic_array (unmodified, third_party)
//        -> TENSORCORE 04 tensor_acc_subsystem (unmodified, third_party)
//        -> TENSORCORE 05 tensor_quantize           (integration/tensor_core_output.sv)
//
//  The TB plays the K-chunk sequencer and the operand buffers.  Per LAYER it
//  loads the per-channel parameters; per output TILE it opens the accumulator
//  tile, sends the quantiser descriptor (before the chunks, or "late" after
//  them, so beats wait for it), and runs each K chunk on the array with random
//  s_valid gaps and stall_i.  The array readout goes to the accumulator; its
//  quantiser port goes to tensor_quantize; random backpressure on the
//  quantiser output and on the raw SRAM port.
//
//  CHECKS
//    * every quantised element == model/tq_ref.qgemm_direct (sum (A - zA) B
//      evaluated literally, bias, requantisation, saturation, ReLU), and its
//      saturation flag; element index (m, channel), tag, format, framing
//    * raw INT32 on the SRAM port (when selected) == exact GEMM (+ TC04 bias)
//    * every tile row delivered exactly once on every selected port
//    * no accumulator / array / quantiser error, reject or poisoned context
//    * quantiser counters: beats, elements, saturations, descriptors
//
//  +JOBS=<file> +SEED=<n> +SGAP=<%> +STALL=<%> +QRDY=<%> +ORDY=<%>
// =============================================================================
`timescale 1ns/1ps
module tb_tq_integ #(
    parameter int ROWS      = 4,
    parameter int COLS      = 4,
    parameter int NUM_TILES = 2,
    parameter int ACC_W     = 32,
    parameter int RD_LAT    = 1,
    parameter int NUM_GRP   = 4,
    parameter int ASYM_EN   = 0,
    parameter int MEMW      = 1 << 23
);
    localparam int DW = 8, PSUM_W = 32, KW = 17;
    localparam int SLOT_W = (NUM_TILES > 1) ? $clog2(NUM_TILES) : 1;
    localparam int RIDW   = (ROWS > 1) ? $clog2(ROWS) : 1;
    localparam int MW     = $clog2(ROWS + 1);
    localparam int NW     = $clog2(COLS + 1);
    localparam int QNP    = 13;

    logic clk = 1'b0;
    always #5 clk = ~clk;
    logic rst_n = 1'b0;

    // ------------------------------------------------------------------ array
    logic                   a_cfg_valid = 1'b0, a_cfg_ready, a_cfg_reject;
    logic [MW-1:0]          a_cfg_m = '0;
    logic [NW-1:0]          a_cfg_n = '0;
    logic [KW-1:0]          a_cfg_k = '0;
    logic                   s_valid = 1'b0, s_ready;
    logic [ROWS*DW-1:0]     s_a = '0;
    logic [COLS*DW-1:0]     s_b = '0;
    logic [KW-1:0]          s_k;
    logic                   stall_i = 1'b0;
    logic                   m_valid, m_ready, m_last;
    logic [RIDW-1:0]        m_row;
    logic [COLS*PSUM_W-1:0] m_data;
    logic [COLS-1:0]        m_col_mask;
    logic                   a_busy, a_tile_done, a_align_err;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [39:0]            ap_busy, ap_issue, ap_su, ap_se, ap_mac, ap_pad;
    /* verilator lint_on UNUSEDSIGNAL */

    tensor_systolic_array #(.ARRAY_ROWS(ROWS), .ARRAY_COLS(COLS), .DATA_WIDTH(DW), .ACC_WIDTH(PSUM_W),
                            .K_WIDTH(KW), .MUL_PIPE(0), .CHECK_ALIGN(1), .PERF_EN(1)) u_array (
        .clk(clk), .rst_n(rst_n),
        .cfg_valid(a_cfg_valid), .cfg_ready(a_cfg_ready), .cfg_m(a_cfg_m), .cfg_n(a_cfg_n), .cfg_k(a_cfg_k),
        .cfg_reject(a_cfg_reject),
        .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .stall_i(stall_i),
        .m_valid(m_valid), .m_ready(m_ready), .m_row(m_row), .m_data(m_data), .m_col_mask(m_col_mask),
        .m_last(m_last), .busy(a_busy), .tile_done(a_tile_done), .align_err(a_align_err),
        .perf_busy(ap_busy), .perf_issue(ap_issue), .perf_stall_up(ap_su), .perf_stall_ext(ap_se),
        .perf_mac(ap_mac), .perf_pad(ap_pad));

    // ------------------------------------------------------------------ accumulator + quantiser
    logic                   cfg_valid = 1'b0, cfg_ready, cfg_reject;
    logic [2:0]             cfg_reject_code;
    logic [SLOT_W-1:0]      cfg_slot = '0;
    logic [15:0]            cfg_tag = '0;
    logic [MW-1:0]          cfg_m = '0;
    logic [NW-1:0]          cfg_n = '0;
    logic [39:0]            cfg_k_total = '0;
    logic [15:0]            cfg_n_chunks = '0;
    logic                   cfg_bias_en = 1'b0;
    logic [COLS*32-1:0]     cfg_bias = '0;
    logic [2:0]             cfg_dest = '0;
    logic [SLOT_W-1:0]      sb_slot = '0;
    logic [15:0]            sb_tag = '0, sb_chunk = '0;
    logic [16:0]            sb_kc = '0;
    logic                   desc_valid = 1'b0, desc_ready, desc_ok, desc_rej;
    logic [255:0]           desc_data = '0;
    logic [3:0]             desc_rej_code;
    logic                   p_valid = 1'b0, p_ready, p_err;
    logic [15:0]            p_grp = '0;
    logic [COLS-1:0]        p_lane_mask = '0;
    logic [4:0]             p_fmask = '0;
    logic [COLS*32-1:0]     p_bias = '0, p_mult = '0, p_zp = '0;
    logic [COLS*6-1:0]      p_shift = '0;
    logic [COLS*ACC_W-1:0]  p_cs = '0;
    logic [1:0]             p_err_code;
    logic                   q_valid, q_ready, q_last, q_err;
    logic [15:0]            q_tag;
    logic [SLOT_W-1:0]      q_ctx;
    logic [RIDW-1:0]        q_row;
    logic [31:0]            q_m, q_ch0;
    logic [COLS-1:0]        q_col_mask, q_sat, q_iovf;
    logic [3:0]             q_fmt;
    logic [COLS*32-1:0]     q_data;
    logic [COLS*8-1:0]      q_q8;
    logic [2:0]             q_err_code;
    logic                   osram_valid, osram_ready, odma_valid;
    logic [15:0]            raw_tag;
    logic [RIDW-1:0]        raw_row;
    logic [COLS*32-1:0]     raw_data;
    logic [COLS-1:0]        raw_clip;
    logic                   acc_cmt_done, acc_idle, acc_err_pulse, q_idle;
    logic [2:0]             acc_err_code;
    logic [NUM_TILES-1:0]   q_ctx_open;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [16*40-1:0]       acc_perf;
    /* verilator lint_on UNUSEDSIGNAL */
    logic [QNP*32-1:0]      q_perf;

    tensor_core_output #(.ROWS(ROWS), .COLS(COLS), .NUM_TILES(NUM_TILES), .ACC_W(ACC_W), .RD_LAT(RD_LAT),
                         .NUM_GRP(NUM_GRP), .ASYM_EN(ASYM_EN)) dut (
        .clk, .rst_n,
        .cfg_valid, .cfg_ready, .cfg_slot, .cfg_tag, .cfg_m, .cfg_n, .cfg_k_total, .cfg_n_chunks,
        .cfg_bias_en, .cfg_bias, .cfg_dest, .cfg_reject, .cfg_reject_code,
        .ps_valid(m_valid), .ps_ready(m_ready), .ps_slot(sb_slot), .ps_tag(sb_tag), .ps_chunk(sb_chunk),
        .ps_chunk_k(sb_kc), .ps_row(m_row), .ps_data(m_data), .ps_col_mask(m_col_mask), .ps_last(m_last),
        .desc_valid, .desc_ready, .desc_data, .desc_ok, .desc_rej, .desc_rej_code,
        .p_valid, .p_ready, .p_grp, .p_lane_mask, .p_fmask, .p_bias, .p_mult, .p_shift, .p_zp, .p_cs,
        .p_err, .p_err_code,
        .q_valid, .q_ready, .q_tag, .q_ctx, .q_row, .q_m, .q_ch0, .q_col_mask, .q_last, .q_fmt, .q_data,
        .q_q8, .q_sat, .q_iovf, .q_err, .q_err_code,
        .osram_valid, .osram_ready, .odma_valid, .odma_ready(1'b1), .raw_tag, .raw_row, .raw_data, .raw_clip,
        .acc_cmt_done, .acc_idle, .acc_err_pulse, .acc_err_code, .q_idle, .q_ctx_open, .acc_perf, .q_perf);

    // ------------------------------------------------------------------ vectors / state
    logic [31:0] vec [0:MEMW-1];
    int job_at [0:8191];
    int njobs = 0, nlayers = 0, errors = 0, cyc = 0, last_progress = 0;
    int seed = 1, sgap = 0, stall = 0, qrdy = 100, ordy = 100;
    int tag_job [0:65535];
    logic [1:0] row_seen [0:65535][0:15];     // {raw, quant}
    longint n_launch = 0, n_q_beats = 0, n_raw_beats = 0, n_elems = 0, n_sat = 0, n_late = 0, n_tc04_bias = 0;
    longint exp_beats = 0, exp_elems = 0, exp_sat = 0, n_pw = 0;

    always @(posedge clk) cyc <= cyc + 1;

    function automatic logic [31:0] xs(input logic [31:0] s);
        logic [31:0] x;
        x = s; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5);
        xs = x;
    endfunction

    task automatic fail(input string msg);
        errors = errors + 1;
        if (errors <= 40) $display("TB_ERROR cyc=%0d: %s", cyc, msg);
        if (errors > 200) begin
            $display("TB_RESULT: FAIL");
            $finish;
        end
    endtask

    task automatic tick();
        @(posedge clk);
        #1;
    endtask

    // job fields
    function automatic int jf(input int j, input int k);  jf = int'(vec[job_at[j] + 1 + k]); endfunction
    function automatic int j_ck(input int j);  j_ck  = job_at[j] + 20 + COLS;              endfunction
    function automatic int j_a(input int j);   j_a   = j_ck(j) + jf(j, 5);                  endfunction
    function automatic int j_b(input int j);   j_b   = j_a(j) + jf(j, 2) * jf(j, 4);         endfunction
    function automatic int j_q(input int j);   j_q   = j_b(j) + jf(j, 4) * jf(j, 3);         endfunction
    function automatic int j_s(input int j);   j_s   = j_q(j) + jf(j, 2) * jf(j, 3);         endfunction
    function automatic int j_r(input int j);   j_r   = j_s(j) + jf(j, 2) * jf(j, 3);         endfunction

    // ------------------------------------------------------------------ random environment
    logic [31:0] env_rs = 32'h2468_ACE1;
    logic        qrdy_q = 1'b0, ordy_q = 1'b0;
    assign q_ready = qrdy_q;
    assign osram_ready = ordy_q;
    always @(posedge clk) begin
        logic [31:0] r;
        r = xs(env_rs);
        env_rs <= xs(r);
        qrdy_q  <= ((r % 100) < 32'(qrdy));
        ordy_q  <= (((r >> 8) % 100) < 32'(ordy));
        stall_i <= (((r >> 16) % 100) < 32'(stall));
    end

    // ------------------------------------------------------------------ edge sampler
    logic smp_acfg_hs = 0, smp_cfg_hs = 0, smp_s_hs = 0, smp_d_hs = 0, smp_p_hs = 0, smp_a_idle = 0, smp_a_readout = 0;
    always @(posedge clk) begin
        smp_acfg_hs   <= a_cfg_valid & a_cfg_ready;
        smp_cfg_hs    <= cfg_valid & cfg_ready;
        smp_s_hs      <= s_valid & s_ready;
        smp_d_hs      <= desc_valid & desc_ready;
        smp_p_hs      <= p_valid & p_ready;
        smp_a_idle    <= a_cfg_ready;
        smp_a_readout <= a_tile_done;
    end

    // ------------------------------------------------------------------ error monitors
    always @(posedge clk) begin
        if (rst_n === 1'b1) begin
            if (a_align_err === 1'b1) fail("array align_err");
            if (a_cfg_reject === 1'b1) fail("array rejected a launch");
            if (cfg_reject === 1'b1) fail($sformatf("accumulator rejected a tile (code %0d)", cfg_reject_code));
            if (acc_err_pulse === 1'b1) fail($sformatf("accumulator psum error (code %0d)", acc_err_code));
            if (desc_rej === 1'b1) fail($sformatf("quantiser rejected a descriptor (code %0d)", desc_rej_code));
            if (p_err === 1'b1) fail($sformatf("quantiser rejected a parameter write (code %0d)", p_err_code));
            if (odma_valid === 1'b1) fail("DMA port used although never selected");
        end
    end

    // ------------------------------------------------------------------ quantised output checker
    always @(posedge clk) begin
        if (rst_n === 1'b1 && q_valid === 1'b1 && q_ready === 1'b1) begin
            int j, M, N, m0, g, row, qa, sa;
            j = tag_job[q_tag];
            n_q_beats = n_q_beats + 1;
            last_progress = cyc;
            if (j < 0) fail($sformatf("quantised beat for unknown tag %0d", q_tag));
            else begin
                M = jf(j, 2); N = jf(j, 3); m0 = jf(j, 9); g = jf(j, 10);
                row = int'(q_row);
                qa = j_q(j); sa = j_s(j);
                if (q_err !== 1'b0 || q_m !== 32'(m0 + row) || q_ch0 !== 32'(g * COLS) || 32'(q_ctx) != vec[job_at[j] + 1] ||
                    q_col_mask !== COLS'((64'd1 << N) - 1) || q_last !== (row == M - 1) ||
                    q_fmt !== vec[job_at[j] + 12][27:24] || q_iovf !== '0)
                    fail($sformatf("tag %0d row %0d: sideband err=%b m=%0d ch0=%0d ctx=%0d mask=%b last=%b fmt=%0d", q_tag, row,
                                   q_err, q_m, q_ch0, q_ctx, q_col_mask, q_last, q_fmt));
                if (row_seen[q_tag][row][0]) fail($sformatf("tag %0d row %0d quantised twice", q_tag, row));
                row_seen[q_tag][row][0] = 1'b1;
                for (int n = 0; n < COLS; n++) begin
                    logic [31:0] e;
                    logic es;
                    e  = (n < N) ? vec[qa + row * N + n] : 32'd0;
                    es = (n < N) ? vec[sa + row * N + n][0] : 1'b0;
                    if (q_data[n*32 +: 32] !== e || q_sat[n] !== es || (q_fmt == 4'd1 && q_q8[n*8 +: 8] !== e[7:0]))
                        fail($sformatf("tag %0d m %0d channel %0d: q=%0d sat=%b, reference %0d sat=%b", q_tag, m0 + row,
                                       g * COLS + n, $signed(q_data[n*32 +: 32]), q_sat[n], $signed(e), es));
                    if (n < N) begin
                        n_elems = n_elems + 1;
                        n_sat = n_sat + longint'(es);
                    end
                end
            end
        end
    end

    // ------------------------------------------------------------------ raw SRAM-port checker
    always @(posedge clk) begin
        if (rst_n === 1'b1 && osram_valid === 1'b1 && osram_ready === 1'b1) begin
            int j, N, row, ra, sa;
            j = tag_job[raw_tag];
            n_raw_beats = n_raw_beats + 1;
            if (j < 0) fail($sformatf("raw beat for unknown tag %0d", raw_tag));
            else begin
                N = jf(j, 3); row = int'(raw_row); ra = j_r(j); sa = j_s(j);
                if (!vec[job_at[j] + 8][0]) fail($sformatf("tag %0d on the SRAM port, not selected", raw_tag));
                if (row_seen[raw_tag][row][1]) fail($sformatf("tag %0d row %0d raw twice", raw_tag, row));
                row_seen[raw_tag][row][1] = 1'b1;
                for (int n = 0; n < N; n++)
                    if (raw_data[n*32 +: 32] !== vec[ra + row * N + n] || raw_clip[n] !== vec[sa + row * N + n][1])
                        fail($sformatf("tag %0d row %0d col %0d: raw %0d, exact GEMM %0d", raw_tag, row, n,
                                       $signed(raw_data[n*32 +: 32]), $signed(vec[ra + row * N + n])));
            end
        end
    end

    // ------------------------------------------------------------------ sequencer
    logic [31:0] seq_rs;
    task automatic gap();
        logic [31:0] r;
        r = xs(seq_rs); seq_rs = r;
        while ((r % 100) < 32'(sgap)) begin
            tick();
            r = xs(seq_rs); seq_rs = r;
        end
    endtask

    task automatic param_write(input int b);
        logic [COLS*32-1:0]    vb, vm, vz;
        logic [COLS*6-1:0]     vs;
        logic [COLS*ACC_W-1:0] vc;
        for (int j = 0; j < COLS; j++) begin
            int l;
            l = b + 3 + 6 * j;
            vb[j*32 +: 32] = vec[l]; vm[j*32 +: 32] = vec[l + 1]; vs[j*6 +: 6] = vec[l + 2][5:0];
            vz[j*32 +: 32] = vec[l + 3]; vc[j*ACC_W +: ACC_W] = ACC_W'({vec[l + 5], vec[l + 4]});
        end
        gap();
        p_grp <= vec[b][15:0]; p_lane_mask <= COLS'(vec[b + 1]); p_fmask <= vec[b + 2][4:0];
        p_bias <= vb; p_mult <= vm; p_shift <= vs; p_zp <= vz; p_cs <= vc;
        p_valid <= 1'b1;
        tick();
        while (!smp_p_hs) tick();
        p_valid <= 1'b0;
        n_pw = n_pw + 1;
    endtask

    task automatic tq_desc(input int j);
        logic [255:0] v;
        for (int w = 0; w < 8; w++) v[w*32 +: 32] = vec[job_at[j] + 12 + w];
        gap();
        desc_data <= v;
        desc_valid <= 1'b1;
        tick();
        while (!smp_d_hs) tick();
        desc_valid <= 1'b0;
        if (desc_ok !== 1'b1) fail($sformatf("job %0d: descriptor not accepted cleanly", j));
    endtask

    task automatic run_chunk(input int j, input int c, input int k0);
        int kc, M, N, K;
        kc = int'(vec[j_ck(j) + c]);
        M = jf(j, 2); N = jf(j, 3); K = jf(j, 4);
        sb_slot  <= SLOT_W'(jf(j, 0));
        sb_tag   <= 16'(jf(j, 1));
        sb_chunk <= 16'(c);
        sb_kc    <= 17'(kc);
        a_cfg_m <= MW'(M); a_cfg_n <= NW'(N); a_cfg_k <= KW'(kc);
        a_cfg_valid <= 1'b1;
        tick();
        while (!smp_acfg_hs) tick();
        a_cfg_valid <= 1'b0;
        n_launch = n_launch + 1;
        for (int k = 0; k < kc; k++) begin
            logic [ROWS*DW-1:0] va;
            logic [COLS*DW-1:0] vb;
            gap();
            for (int m = 0; m < ROWS; m++) va[m*DW +: DW] = (m < M) ? vec[j_a(j) + m * K + k0 + k][DW-1:0] : '0;
            for (int n = 0; n < COLS; n++) vb[n*DW +: DW] = (n < N) ? vec[j_b(j) + (k0 + k) * N + n][DW-1:0] : '0;
            s_a <= va;
            s_b <= vb;
            s_valid <= 1'b1;
            tick();
            while (!smp_s_hs) tick();
            s_valid <= 1'b0;
            last_progress = cyc;
        end
        while (!smp_a_readout) tick();
        while (!smp_a_idle) tick();
    endtask

    task automatic run_job(input int j);
        logic [COLS*32-1:0] vb;
        int nch, k0, M, N;
        nch = jf(j, 5); M = jf(j, 2); N = jf(j, 3);
        for (int n = 0; n < COLS; n++) vb[n*32 +: 32] = vec[job_at[j] + 20 + n];
        gap();
        cfg_slot <= SLOT_W'(jf(j, 0)); cfg_tag <= 16'(jf(j, 1));
        cfg_m <= MW'(M); cfg_n <= NW'(N); cfg_k_total <= 40'(jf(j, 4));
        cfg_n_chunks <= 16'(nch); cfg_bias_en <= vec[job_at[j] + 7][0]; cfg_bias <= vb;
        cfg_dest <= vec[job_at[j] + 8][2:0];
        cfg_valid <= 1'b1;
        tick();
        while (!smp_cfg_hs) tick();
        cfg_valid <= 1'b0;
        tag_job[jf(j, 1)] = j;
        exp_beats = exp_beats + M;
        exp_elems = exp_elems + M * N;
        for (int i = 0; i < M * N; i++) exp_sat = exp_sat + longint'(vec[j_s(j) + i][0]);
        if (vec[job_at[j] + 7][0]) n_tc04_bias = n_tc04_bias + 1;
        if (!vec[job_at[j] + 9][0]) tq_desc(j);
        k0 = 0;
        for (int c = 0; c < nch; c++) begin
            run_chunk(j, c, k0);
            k0 = k0 + int'(vec[j_ck(j) + c]);
        end
        if (vec[job_at[j] + 9][0]) begin
            logic [31:0] r;
            r = xs(seq_rs); seq_rs = r;
            repeat (int'(r % 61)) tick();   // late: the tile's beats wait for the descriptor
            tq_desc(j);
            n_late = n_late + 1;
        end
    endtask

    // ------------------------------------------------------------------ main
    initial begin : main
        string jfile;
        int at, nrec;
        if ($value$plusargs("SEED=%d", seed)) ;
        if ($value$plusargs("SGAP=%d", sgap)) ;
        if ($value$plusargs("STALL=%d", stall)) ;
        if ($value$plusargs("QRDY=%d", qrdy)) ;
        if ($value$plusargs("ORDY=%d", ordy)) ;
        seq_rs = xs(32'(seed) ^ 32'h1357_9BDF);
        env_rs = xs(32'(seed) ^ 32'hFACE_B00C);
        if (!$value$plusargs("JOBS=%s", jfile)) begin
            $display("TB_RESULT: FAIL (no +JOBS)");
            $finish;
        end
        for (int t = 0; t < 65536; t++) begin
            tag_job[t] = -1;
            for (int r = 0; r < 16; r++) row_seen[t][r] = '0;
        end
        $readmemh(jfile, vec);
        if (vec[0] !== 32'h7C05_2001 || vec[2] != ROWS || vec[3] != COLS || vec[4] != NUM_TILES ||
            vec[5] != ACC_W || vec[6] != ASYM_EN || vec[7] != NUM_GRP) begin
            $display("TB_RESULT: FAIL (job file does not match this configuration)");
            $finish;
        end
        njobs = int'(vec[8]);
        nlayers = int'(vec[9]);
        $display("TB_INFO jobs=%s words=%0d layers=%0d tiles=%0d ROWS=%0d COLS=%0d SLOTS=%0d ACC_W=%0d ASYM=%0d seed=%0d sgap=%0d stall=%0d qrdy=%0d ordy=%0d",
                 jfile, vec[1], nlayers, njobs, ROWS, COLS, NUM_TILES, ACC_W, ASYM_EN, seed, sgap, stall, qrdy, ordy);
        repeat (4) tick();
        rst_n <= 1'b1;
        repeat (2) tick();
        last_progress = cyc;
        at = 10;
        nrec = 0;
        while (at < int'(vec[1])) begin
            int typ, len;
            typ = int'(vec[at][31:24]);
            len = int'(vec[at][23:0]);
            if (typ == 1) begin
                int npw;
                npw = int'(vec[at + 1]);
                for (int p = 0; p < npw; p++) param_write(at + 2 + p * (3 + 6 * COLS));
            end else if (typ == 2) begin
                job_at[nrec] = at;
                run_job(nrec);
                nrec = nrec + 1;
            end else fail("bad record");
            at = at + 1 + len;
        end
        while (!(acc_idle === 1'b1 && q_idle === 1'b1 && n_q_beats == exp_beats)) tick();
        repeat (20) tick();
        for (int j = 0; j < njobs; j++)
            for (int r = 0; r < jf(j, 2); r++)
                if (row_seen[jf(j, 1)][r] != {vec[job_at[j] + 8][0], 1'b1})
                    fail($sformatf("job %0d tag %0d row %0d delivered %b", j, jf(j, 1), r, row_seen[jf(j, 1)][r]));
        if (64'(q_perf[0*32 +: 32]) != 64'(exp_beats) || 64'(q_perf[1*32 +: 32]) != 64'(exp_beats))
            fail($sformatf("quantiser beat counters %0d/%0d, expected %0d", q_perf[0*32 +: 32], q_perf[1*32 +: 32], exp_beats));
        if (64'(q_perf[2*32 +: 32]) != 64'(exp_elems)) fail("quantiser element counter");
        if (64'(q_perf[3*32 +: 32]) != 64'(exp_sat)) fail($sformatf("quantiser saturation counter %0d, expected %0d", q_perf[3*32 +: 32], exp_sat));
        if (q_perf[5*32 +: 32] != 0 || q_perf[7*32 +: 32] != 0 || q_perf[9*32 +: 32] != 0) fail("quantiser error counters non-zero");
        if (64'(q_perf[6*32 +: 32]) != 64'(njobs)) fail("quantiser descriptor counter");
        if (64'(q_perf[8*32 +: 32]) != 64'(n_pw)) fail("quantiser parameter-write counter");
        if (q_ctx_open !== '0) fail("a quantiser context is still open");
        $display("TB_SUMMARY layers=%0d tiles=%0d launches=%0d param_writes=%0d late_desc=%0d tc04_bias_tiles=%0d q_beats=%0d raw_beats=%0d elements=%0d saturated=%0d ctx_wait_cycles=%0d cycles=%0d errors=%0d",
                 nlayers, njobs, n_launch, n_pw, n_late, n_tc04_bias, n_q_beats, n_raw_beats, n_elems, n_sat,
                 q_perf[11*32 +: 32], cyc, errors);
        $display("TB_RESULT: %s", (errors == 0) ? "PASS" : "FAIL");
        $finish;
    end

    always @(posedge clk) begin
        if (cyc > 100 && cyc - last_progress > 200000) begin
            fail("watchdog: no progress for 200000 cycles");
            $display("TB_RESULT: FAIL");
            $finish;
        end
    end
endmodule
