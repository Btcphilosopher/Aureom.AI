// =============================================================================
//  SilicaFlux TENSORCORE 05  --  integration/tensor_core_output.sv
//  Integration example:  TENSORCORE 04 accumulator subsystem  ->  tensor_quantize
//  Aureom.AI | SilicaFlux-HPC
//
//      TC02 array --m_*--> [ tensor_acc_subsystem ] --oquant_*--> [ tensor_quantize ] --> out_*
//                                   |  osram_* / odma_*  (raw exact INT32, never requantised)
//
//  WIRING (the whole contract between the two blocks)
//      TC04 oquant_valid / oquant_ready   <->  TQ in_valid / in_ready
//      TC04 o_slot   -> in_ctx      (context = accumulator slot: NUM_CTX = NUM_TILES)
//      TC04 o_tag    -> in_tag      TC04 o_row -> in_row     TC04 o_last -> in_last
//      TC04 o_col_mask -> in_col_mask
//      TC04 o_wide   -> in_data     (exact ACC_W lanes: IN_W = ACC_W, never the narrowed o_data)
//      TC04 o_ovf    -> in_ovf      TC04 o_err -> in_err
//
//  SEQUENCER RULES (docs/INTEGRATION.md)
//    * For every tile routed to the quantiser (cfg_dest bit 1), send one TQ OPEN
//      descriptor with CTX = cfg_slot and TAG = cfg_tag.  It may be sent before,
//      during or after the tile's chunks: beats wait for it.  Send it before
//      opening the NEXT accumulator tile, so the accumulator can always drain.
//    * Bias is applied exactly once: either TC04 (cfg_bias_en) or TQ
//      (FLAGS.BIAS), never both.  Both give the same exact result (integer
//      addition is associative) as long as TC04 STRICT_RANGE accepted the tile.
//    * After an accumulator HC_ABORT of a tile that had a TQ descriptor, send a
//      TQ CLOSE for that slot/tag.
//    * Parameters (tensor_quant_params) are loaded on the p_* port; a
//      descriptor snapshots them, so a layer's parameters may be reloaded as soon
//      as the last descriptor of the previous layer has been accepted.
// =============================================================================
`timescale 1ns/1ps
module tensor_core_output #(
    parameter int ROWS        = 4,
    parameter int COLS        = 4,
    parameter int NUM_TILES   = 2,
    parameter int ACC_W       = 32,
    parameter int RD_LAT      = 1,
    parameter int NUM_GRP     = 16,
    parameter int ASYM_EN     = 0,
    parameter int OFIFO_DEPTH = 4,
    // ---------------- derived: never override ----------------
    parameter int SLOT_W = (NUM_TILES > 1) ? $clog2(NUM_TILES) : 1,
    parameter int RIDW   = (ROWS > 1) ? $clog2(ROWS) : 1,
    parameter int MW     = $clog2(ROWS + 1),
    parameter int NW     = $clog2(COLS + 1),
    parameter int TNPERF = tensor_acc_pkg::NPERF,
    parameter int QNPERF = tensor_quantize_pkg::NPERF,
    parameter int EVW    = $clog2(COLS + 1)
) (
    input  logic                       clk,
    input  logic                       rst_n,
    // ---------------- accumulator tile configuration (TC04)
    input  logic                       cfg_valid,
    output logic                       cfg_ready,
    input  logic [SLOT_W-1:0]          cfg_slot,
    input  logic [15:0]                cfg_tag,
    input  logic [MW-1:0]              cfg_m,
    input  logic [NW-1:0]              cfg_n,
    input  logic [39:0]                cfg_k_total,
    input  logic [15:0]                cfg_n_chunks,
    input  logic                       cfg_bias_en,
    input  logic [COLS*32-1:0]         cfg_bias,
    input  logic [2:0]                 cfg_dest,
    output logic                       cfg_reject,
    output logic [2:0]                 cfg_reject_code,
    // ---------------- partial sums from the TC02 array (+ sequencer sideband)
    input  logic                       ps_valid,
    output logic                       ps_ready,
    input  logic [SLOT_W-1:0]          ps_slot,
    input  logic [15:0]                ps_tag,
    input  logic [15:0]                ps_chunk,
    input  logic [16:0]                ps_chunk_k,
    input  logic [RIDW-1:0]            ps_row,
    input  logic [COLS*32-1:0]         ps_data,
    input  logic [COLS-1:0]            ps_col_mask,
    input  logic                       ps_last,
    // ---------------- quantiser descriptors and parameters (TC05)
    input  logic                       desc_valid,
    output logic                       desc_ready,
    input  logic [255:0]               desc_data,
    output logic                       desc_ok,
    output logic                       desc_rej,
    output logic [3:0]                 desc_rej_code,
    input  logic                       p_valid,
    output logic                       p_ready,
    input  logic [15:0]                p_grp,
    input  logic [COLS-1:0]            p_lane_mask,
    input  logic [4:0]                 p_fmask,
    input  logic [COLS*32-1:0]         p_bias,
    input  logic [COLS*32-1:0]         p_mult,
    input  logic [COLS*6-1:0]          p_shift,
    input  logic [COLS*32-1:0]         p_zp,
    input  logic [COLS*ACC_W-1:0]      p_cs,
    output logic                       p_err,
    output logic [1:0]                 p_err_code,
    // ---------------- converted results (TC05)
    output logic                       q_valid,
    input  logic                       q_ready,
    output logic [15:0]                q_tag,
    output logic [SLOT_W-1:0]          q_ctx,
    output logic [RIDW-1:0]            q_row,
    output logic [31:0]                q_m,
    output logic [31:0]                q_ch0,
    output logic [COLS-1:0]            q_col_mask,
    output logic                       q_last,
    output logic [3:0]                 q_fmt,
    output logic [COLS*32-1:0]         q_data,
    output logic [COLS*8-1:0]          q_q8,
    output logic [COLS-1:0]            q_sat,
    output logic [COLS-1:0]            q_iovf,
    output logic                       q_err,
    output logic [2:0]                 q_err_code,
    // ---------------- raw exact results (TC04 SRAM / DMA ports, unchanged)
    output logic                       osram_valid,
    input  logic                       osram_ready,
    output logic                       odma_valid,
    input  logic                       odma_ready,
    output logic [15:0]                raw_tag,
    output logic [RIDW-1:0]            raw_row,
    output logic [COLS*32-1:0]         raw_data,
    output logic [COLS-1:0]            raw_clip,
    // ---------------- status
    output logic                       acc_cmt_done,
    output logic                       acc_idle,
    output logic                       acc_err_pulse,
    output logic [2:0]                 acc_err_code,
    output logic                       q_idle,
    output logic [NUM_TILES-1:0]       q_ctx_open,
    output logic [TNPERF*40-1:0]       acc_perf,
    output logic [QNPERF*32-1:0]       q_perf
);
    // TC04 result payload (shared by its three ports)
    logic                    oquant_valid, oquant_ready;
    logic [15:0]             o_tag;
    logic [SLOT_W-1:0]       o_slot;
    logic [RIDW-1:0]         o_row;
    logic                    o_last, o_err;
    logic [COLS-1:0]         o_col_mask, o_ovf, o_clip;
    logic [COLS*ACC_W-1:0]   o_wide;
    logic [COLS*32-1:0]      o_data;
    /* verilator lint_off UNUSEDSIGNAL */
    logic                    hc_ready, hr_valid, hr_vld, cmt_ovf, cmt_clip, cmt_err;
    logic [2:0]              hr_status;
    logic [COLS*ACC_W-1:0]   hr_data;
    logic [COLS-1:0]         hr_ovf;
    logic [15:0]             hr_nchunk;
    logic [39:0]             hr_kacc;
    logic [SLOT_W-1:0]       cmt_slot;
    logic [15:0]             cmt_tag;
    logic [NUM_TILES*2-1:0]  slot_state;
    logic [7:0]              err_sticky;
    logic [TNPERF*EVW-1:0]   ev_inc;
    logic                    st_en, st_rd_req, st_rd_ready, st_wr_req, st_wr_ready;
    logic [NUM_TILES-1:0]    q_ctx_poison;
    logic [15:0]             q_desc_sticky;
    logic [7:0]              q_beat_sticky;
    logic [3:0]              q_param_sticky;
    /* verilator lint_on UNUSEDSIGNAL */

    tensor_acc_subsystem #(.ROWS(ROWS), .COLS(COLS), .ACC_W(ACC_W), .OUT_W(32), .NUM_TILES(NUM_TILES),
                           .RD_LAT(RD_LAT)) u_acc (
        .clk, .rst_n,
        .cfg_valid, .cfg_ready, .cfg_slot, .cfg_tag, .cfg_m, .cfg_n, .cfg_k_total, .cfg_n_chunks,
        .cfg_bias_en, .cfg_bias, .cfg_dest, .cfg_reject, .cfg_reject_code,
        .ps_valid, .ps_ready, .ps_slot, .ps_tag, .ps_chunk, .ps_chunk_k, .ps_row, .ps_data,
        .ps_col_mask, .ps_last,
        .hc_valid(1'b0), .hc_ready, .hc_op(2'd0), .hc_slot('0), .hc_row('0), .hc_wdata('0),
        .hr_valid, .hr_ready(1'b1), .hr_status, .hr_data, .hr_ovf, .hr_vld, .hr_nchunk, .hr_kacc,
        .st_rd_block(1'b0), .st_wr_block(1'b0),
        .osram_valid, .osram_ready, .oquant_valid, .oquant_ready, .odma_valid, .odma_ready,
        .o_tag, .o_slot, .o_row, .o_last, .o_col_mask, .o_wide, .o_data, .o_ovf, .o_clip, .o_err,
        .cmt_done(acc_cmt_done), .cmt_slot, .cmt_tag, .cmt_ovf, .cmt_clip, .cmt_err,
        .slot_state, .idle(acc_idle), .err_pulse(acc_err_pulse), .err_code(acc_err_code), .err_sticky,
        .perf_clr(1'b0), .ev_inc, .perf_o(acc_perf),
        .st_en, .st_rd_req, .st_rd_ready, .st_wr_req, .st_wr_ready);

    tensor_quantize #(.ROWS(ROWS), .COLS(COLS), .IN_W(ACC_W), .NUM_CTX(NUM_TILES), .NUM_GRP(NUM_GRP),
                      .ASYM_EN(ASYM_EN), .OFIFO_DEPTH(OFIFO_DEPTH)) u_q (
        .clk, .rst_n,
        .desc_valid, .desc_ready, .desc_data, .desc_ok, .desc_rej, .desc_rej_code,
        .p_valid, .p_ready, .p_grp, .p_lane_mask, .p_fmask, .p_bias, .p_mult, .p_shift, .p_zp, .p_cs,
        .p_err, .p_err_code,
        .in_valid(oquant_valid), .in_ready(oquant_ready), .in_ctx(o_slot), .in_tag(o_tag), .in_row(o_row),
        .in_col_mask(o_col_mask), .in_last(o_last), .in_data(o_wide), .in_ovf(o_ovf), .in_err(o_err),
        .out_valid(q_valid), .out_ready(q_ready), .out_tag(q_tag), .out_ctx(q_ctx), .out_row(q_row),
        .out_m(q_m), .out_ch0(q_ch0), .out_col_mask(q_col_mask), .out_last(q_last), .out_fmt(q_fmt),
        .out_data(q_data), .out_q8(q_q8), .out_sat(q_sat), .out_iovf(q_iovf), .out_err(q_err),
        .out_err_code(q_err_code),
        .ctx_open(q_ctx_open), .ctx_poison(q_ctx_poison), .idle(q_idle), .desc_err_sticky(q_desc_sticky),
        .beat_err_sticky(q_beat_sticky), .param_err_sticky(q_param_sticky),
        .perf_clr(1'b0), .perf_o(q_perf));

    assign raw_tag  = o_tag;
    assign raw_row  = o_row;
    assign raw_data = o_data;
    assign raw_clip = o_clip;
endmodule
