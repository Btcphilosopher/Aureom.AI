#!/usr/bin/env python3
"""
TENSORCORE 05 -- host-side integration example (software half).

Shows how a host prepares one quantised fully-connected / 1x1-conv layer for the
TC02 -> TC04 -> TC05 pipeline:

  1. real-valued quantisation parameters (from a trained, quantised model):
       activations  int8, scale s_in, zero point zA   (zA != 0 needs ASYM_EN = 1)
       weights      int8, symmetric (zB = 0), per-output-channel scale s_w[n]
       outputs      int8, scale s_out, zero point zp_out
       bias         float b[n]  ->  int32  round(b[n] / (s_in * s_w[n]))
  2. real multipliers s_in * s_w[n] / s_out -> integer (M[n], S[n])
     (the only place a real number exists; the RTL never sees one)
  3. the parameter-port writes (one per channel group of COLS channels)
  4. one 256-bit descriptor per output tile (ABI v1)
  5. the expected int8 output, from the integer reference

and checks the integer result against a float64 evaluation of the same layer
(how far the M / 2^S approximation of the real scale moves any output).

  python3 integration/example_layer.py
"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
import tq_ref as R  # noqa: E402

ROWS, COLS = 4, 4            # array / tile size
NUM_TILES = 2                # accumulator slots = quantiser contexts
ASYM_EN = 1                  # build with tensor_quantize #(.ASYM_EN(1)) to use zA != 0


def main():
    rnd = random.Random(2026)
    M_, K, N = 6, 64, 8                      # C[6 x 8] = A[6 x 64] * B[64 x 8]
    s_in, zA = 0.04, -128                    # post-ReLU activations: real 0 is int8 -128
    s_w = [0.002 + 0.001 * n for n in range(N)]
    s_out, zp_out = 0.08, -128
    b_real = [0.3 * (n - 4) for n in range(N)]

    A = [[min(127, zA + int(abs(rnd.gauss(0, 40)))) for _ in range(K)] for _ in range(M_)]
    B = [[max(-127, min(127, int(round(rnd.gauss(0, 0.15) / s_w[n])))) for n in range(N)] for _ in range(K)]

    # ---- 2. integer parameters
    bias = [int(round(b_real[n] / (s_in * s_w[n]))) for n in range(N)]
    MS = [R.quantize_multiplier(s_in * s_w[n] / s_out) for n in range(N)]
    colsum = R.colsum(B)                     # weight statistic for the zA correction
    print("channel  bias        M           S   scale(real)      M/2^S            rel.err")
    for n in range(N):
        m, s = MS[n]
        real = s_in * s_w[n] / s_out
        print(f"{n:7d}  {bias[n]:8d}  {m:11d}  {s:3d}   {real:.10f}  {m / 2 ** s:.10f}  {abs(m / 2 ** s - real) / real:.2e}")

    # ---- 3. parameter-port writes: group g holds channels g*COLS .. g*COLS + COLS - 1
    print("\nparameter writes (p_grp, p_lane_mask, p_fmask, lanes {bias, mult, shift, zp, colsum}):")
    for g in range(N // COLS):
        lanes = [(bias[g * COLS + j], MS[g * COLS + j][0], MS[g * COLS + j][1], zp_out, colsum[g * COLS + j])
                 for j in range(COLS)]
        fm = R.FM_BIAS | R.FM_MULT | R.FM_SHIFT | R.FM_ZP | (R.FM_CS if ASYM_EN else 0)
        print(f"  grp {g}  mask {(1 << COLS) - 1:#x}  fmask {fm:#04x}  {lanes}")

    # ---- 4. descriptors: one per ROWS x COLS output tile; CTX = the accumulator slot
    print("\ndescriptors (8 x 32-bit words, word 0 first):")
    slot, tag = 0, 100
    flags = R.FL_RQ | R.FL_PC | R.FL_BIAS | R.FL_RELU
    for m0 in range(0, M_, ROWS):
        for g in range(N // COLS):
            w = R.encode_desc(op=R.OP_OPEN, rm=R.RM_RNE, flags=flags, ofmt=R.OFMT_INT8, tag=tag, ctx=slot,
                              m=min(ROWS, M_ - m0), n=COLS, grp=g, m0=m0, za=zA)
            print(f"  tile m0={m0} grp={g} slot={slot} tag={tag}: " + " ".join(f"{x:08x}" for x in w))
            slot, tag = (slot + 1) % NUM_TILES, tag + 1

    # ---- 5. expected output (integer contract) and float comparison
    Q, SAT = R.qgemm_direct(A, B, za=zA, bias=bias, mult=[m for m, _ in MS], shift=[s for _, s in MS],
                            zp=[zp_out] * N, relu=True)
    diff = 0
    for m in range(M_):
        for n in range(N):
            acc = sum((A[m][k] - zA) * B[k][n] for k in range(K)) + bias[n]
            qf = max(R.float_requant(acc, s_in * s_w[n] / s_out, zp_out), zp_out)
            diff += int(qf != Q[m][n])
    print("\nexpected int8 output (rows m, channels n):")
    for m in range(M_):
        print("  " + " ".join(f"{q:5d}" for q in Q[m]))
    print(f"\nsaturated elements: {sum(map(sum, SAT))}; integer contract differs from the float64-scale "
          f"evaluation in {diff} of {M_ * N} elements (informational)")


if __name__ == "__main__":
    main()
