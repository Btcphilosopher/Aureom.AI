# TENSORCORE 05 mutation report

**69 / 70 mutants killed** by the testbench alone (RTL invariants compiled out); 1 proven equivalent; 0 unexplained survivors; 0 malformed. Wall time 26 s.

| id | injected bug | result | killed by | first failure |
|---|---|---|---|---|
| m01 | RNE ties rounded up (half-up) | KILLED | base:s3_int8 | TB_ERROR cyc=42: beat (cmd @497) tag 6 row 0 lane 0: data 113 (q8 113), expected 112 [acc 3835513] |
| m02 | RNE ties rounded down | KILLED | base:s3_int8 | TB_ERROR cyc=42: beat (cmd @497) tag 6 row 0 lane 1: data 67 (q8 67), expected 68 [acc 2359296] |
| m03 | RNE ties to odd | KILLED | base:s3_int8 | TB_ERROR cyc=42: beat (cmd @497) tag 6 row 0 lane 0: data 113 (q8 113), expected 112 [acc 3835513] |
| m04 | RMM ties toward +inf | KILLED | base:s4_ties | TB_ERROR cyc=98: beat (cmd @2074) tag 17 row 0 lane 2: data -42 (q8 -42), expected -43 [acc -6357053] |
| m05 | RTZ implemented as floor | KILLED | base:s4_ties | TB_ERROR cyc=34: beat (cmd @604) tag 5 row 0 lane 1: data -31 (q8 -31), expected -30 [acc 4] |
| m06 | RUP ignores the sticky bits | KILLED | base:s4_ties | TB_ERROR cyc=76: beat (cmd @1584) tag 13 row 0 lane 1: data 27 (q8 27), expected 28 [acc 777] |
| m07 | guard bit taken one position too high | KILLED | base:s3_int8 | TB_ERROR cyc=27: beat (cmd @178) tag 1 row 1 lane 0: data -16 (q8 -16), expected -17 [acc -2706] |
| m08 | sticky mask one bit short | KILLED | base:s3_ties | TB_ERROR cyc=147: beat (cmd @2671) tag 32 row 0 lane 0: data 49 (q8 49), expected 50 [acc -155] |
| m09 | S = 0 not special-cased (guard = bit 63) | KILLED | base:s1_pass | TB_ERROR cyc=10: beat (cmd @20) tag 1 row 0 lane 0: data -2147483646 (q8 2), expected -2147483647 [acc -2147483647] |
| m10 | logical instead of arithmetic shift | KILLED | base:s3_int8 | TB_ERROR cyc=24: beat (cmd @145) sideband: tag 1/1 ctx 0/0 row 0/0 m 4294967294/4294967294 ch0 8/8 mask 0001/1 last 0/0 fmt 1/1 code 0/0 sat 0001/0 iovf 0000/0 |
| m11 | sign taken from the wrong bit | EQUIVALENT | - | equivalent: /x*M/ <= 2^(XW+30), so every product fits PW-1 bits and bit PW-2 equals the sign bit, except p = (-2^(XW-1))*(-2^31) = +2^(XW+30) exactly; its low S bits (S <= 63 <= XW+30) are all zero, so g = st = 0 and `neg` (only used ANDed with g/st) is never consulted. |
| m12 | unsigned multiply | KILLED | base:s1_pass | TB_ERROR cyc=10: beat (cmd @20) sideband: tag 1/1 ctx 1/1 row 0/0 m 0/0 ch0 0/0 mask 0111/7 last 0/0 fmt 0/0 code 0/0 sat 0001/0 iovf 0000/0 |
| m13 | multiplier truncated to 31 bits | KILLED | base:s3_int8 | TB_ERROR cyc=24: beat (cmd @145) tag 1 row 0 lane 0: data 12 (q8 12), expected -48 [acc -7676] |
| m14 | output zero-point not added | KILLED | base:s3_int8 | TB_ERROR cyc=66: beat (cmd @594) tag 8 row 0 lane 2: data 0 (q8 0), expected -128 [acc -52189] |
| m15 | output zero-point subtracted | KILLED | base:s3_int8 | TB_ERROR cyc=66: beat (cmd @594) sideband: tag 8/8 ctx 1/1 row 0/0 m 0/0 ch0 0/0 mask 1111/f last 1/1 fmt 1/1 code 0/0 sat 1111/b iovf 0000/0 |
| m16 | INT8 max 126 | KILLED | base:s3_int8 | TB_ERROR cyc=34: beat (cmd @288) tag 2 row 2 lane 1: data 126 (q8 126), expected 127 [acc -1087923666] |
| m17 | INT8 min -127 | KILLED | base:s3_int8 | TB_ERROR cyc=42: beat (cmd @497) tag 6 row 0 lane 3: data -127 (q8 -127), expected -128 [acc -4718593] |
| m18 | INT32 max off by one | KILLED | base:s1_pass | TB_ERROR cyc=14: beat (cmd @86) sideband: tag 1/1 ctx 1/1 row 2/2 m 2/2 ch0 0/0 mask 0111/7 last 0/0 fmt 0/0 code 0/0 sat 0010/0 iovf 0000/0 |
| m19 | saturation flag raised at the bound | KILLED | base:s1_pass | TB_ERROR cyc=14: beat (cmd @86) sideband: tag 1/1 ctx 1/1 row 2/2 m 2/2 ch0 0/0 mask 0111/7 last 0/0 fmt 0/0 code 0/0 sat 0010/0 iovf 0000/0 |
| m20 | WRAP ignored (always saturates) | KILLED | base:s2_bias | TB_ERROR cyc=72: beat (cmd @854) tag 8 row 1 lane 1: data 2147483647 (q8 -1), expected -2147483648 [acc 2147425371] |
| m21 | ReLU floor 0 instead of the zero-point | KILLED | base:s3_int8 | TB_ERROR cyc=37: beat (cmd @420) tag 4 row 0 lane 0: data 0 (q8 0), expected 127 [acc -1826733079] |
| m22 | ReLU compares <= (counts equal values) | KILLED | base:s3_int8 | TB_ERROR cyc=47: perf counter 4 = 16, expected 3 |
| m23 | ReLU disabled | KILLED | base:s3_int8 | TB_ERROR cyc=34: beat (cmd @288) tag 2 row 2 lane 2: data -127 (q8 -127), expected 0 [acc 1085790482] |
| m24 | bias not added | KILLED | base:s2_bias | TB_ERROR cyc=27: beat (cmd @156) tag 2 row 0 lane 0: data -12616 (q8 -72), expected -12617 [acc -12616] |
| m25 | bias subtracted | KILLED | base:s2_bias | TB_ERROR cyc=27: beat (cmd @156) tag 2 row 0 lane 0: data -12615 (q8 -71), expected -12617 [acc -12616] |
| m26 | input zero-point correction added (sign) | KILLED | asym:s4_asym | TB_ERROR cyc=24: beat (cmd @145) tag 1 row 0 lane 0: data -128 (q8 -128), expected 127 [acc -2147483648] |
| m27 | input zero-point correction dropped | KILLED | asym:s4_asym | TB_ERROR cyc=24: beat (cmd @145) tag 1 row 0 lane 1: data -128 (q8 -128), expected 127 [acc 577] |
| m28 | per-tensor / per-channel multiplier swapped | KILLED | base:s3_int8 | TB_ERROR cyc=24: beat (cmd @145) tag 1 row 0 lane 0: data x (q8 x), expected -48 [acc -7676] |
| m29 | per-channel shift ignored | KILLED | base:s4_perchan | TB_ERROR cyc=42: beat (cmd @207) sideband: tag 1/1 ctx 1/1 row 1/1 m 1/1 ch0 8/8 mask 0011/3 last 0/0 fmt 1/1 code 0/0 sat 0011/1 iovf 0000/0 |
| m30 | pass-through multiplier 0 instead of 1 | KILLED | base:s1_pass | TB_ERROR cyc=10: beat (cmd @20) tag 1 row 0 lane 0: data 0 (q8 0), expected -2147483647 [acc -2147483647] |
| m31 | bias read live from the table at beat time (no snapshot) | KILLED | base:s1_pass | TB_ERROR cyc=10: beat (cmd @20) tag 1 row 0 lane 0: data x (q8 x), expected -2147483647 [acc -2147483647] |
| m32 | element index: row not added to M0 | KILLED | base:s1_pass | TB_ERROR cyc=13: beat (cmd @53) sideband: tag 1/1 ctx 1/1 row 1/1 m 0/1 ch0 0/0 mask 0111/7 last 0/0 fmt 0/0 code 0/0 sat 0000/0 iovf 0000/0 |
| m33 | channel index not scaled by COLS | KILLED | base:s2_bias | TB_ERROR cyc=36: beat (cmd @332) sideband: tag 3/3 ctx 1/1 row 0/0 m 0/0 ch0 2/8 mask 0111/7 last 0/0 fmt 0/0 code 0/0 sat 0000/0 iovf 0001/1 |
| m34 | context released by a wrong-tag last beat | KILLED | base:s4_errors | TB_ERROR cyc=234: beat (cmd @4108) sideband: tag 39/39 ctx 0/0 row 3/3 m 0/631843 ch0 0/0 mask 0111/7 last 1/1 fmt 0/1 code 2/4 sat 0000/7 iovf 0000/0 |
| m35 | context never released | KILLED | base:s1_pass | TB_ERROR cyc=19: beat (cmd @174) sideband: tag 2/2 ctx 1/1 row 0/0 m 0/4294967292 ch0 0/0 mask 0001/1 last 0/0 fmt 0/0 code 2/0 sat 0000/0 iovf 0000/0 |
| m36 | OPEN accepted on a busy context | KILLED | base:s1_pass | TB_ERROR cyc=13: beat (cmd @53) sideband: tag 1/1 ctx 1/1 row 1/1 m 0/1 ch0 0/0 mask 0111/7 last 0/0 fmt 0/0 code 2/0 sat 0000/0 iovf 0000/0 |
| m37 | beats accepted on a closed context | KILLED | base:s1_pass | TB_ERROR cyc=10: beat (cmd @20) sideband: tag 1/1 ctx 1/1 row 0/0 m x/0 ch0 x/0 mask 0111/7 last 0/0 fmt X/0 code 0/0 sat 0xxx/0 iovf 0000/0 |
| m38 | one credit too many | KILLED | base:s1_pass | TB_ERROR cyc=42: output changed or dropped while stalled (valid/ready rule) |
| m39 | credits not returned on pop | KILLED | base:s1_pass | TB_ERROR cyc=20017: watchdog: no progress for 20000 cycles (ctl 3/10 beat 4/30 sb 4/4 idle 1 in_ready 0 desc_ready 0 ctx_open 11) |
| m40 | no credit check (backpressure ignored) | KILLED | base:s1_pass | TB_ERROR cyc=31: output changed or dropped while stalled (valid/ready rule) |
| m41 | tag check missing | KILLED | base:s4_errors | TB_ERROR cyc=232: beat (cmd @4042) sideband: tag 32807/32807 ctx 0/0 row 0/0 m 631840/0 ch0 0/0 mask 0111/7 last 1/1 fmt 1/0 code 4/2 sat 0111/0 iovf 0000/0 |
| m42 | poisoned context computed normally | KILLED | base:s4_perchan | TB_ERROR cyc=67: beat (cmd @361) sideband: tag 2/2 ctx 0/0 row 0/0 m 4294967293/0 ch0 12/0 mask 1111/f last 0/0 fmt 1/0 code 4/3 sat 0000/0 iovf 1000/8 |
| m43 | frame check missing | KILLED | base:s4_errors | TB_ERROR cyc=227: beat (cmd @3943) sideband: tag 39/39 ctx 0/0 row 0/0 m 631840/631840 ch0 0/0 mask 1110/e last 0/0 fmt 1/1 code 0/4 sat 0110/6 iovf 0000/0 |
| m44 | upstream error not propagated | KILLED | base:s1_pass | TB_ERROR cyc=69: beat (cmd @1076) sideband: tag 10/10 ctx 0/0 row 2/2 m 4294967295/4294967295 ch0 0/0 mask 0011/3 last 1/1 fmt 0/0 code 0/5 sat 0000/0 iovf 0000/0 |
| m45 | upstream overflow flag not masked by col_mask | KILLED | base:s1_pass | TB_ERROR cyc=29: beat (cmd @394) sideband: tag 4/4 ctx 1/1 row 0/0 m 965922/965922 ch0 0/0 mask 0001/1 last 0/0 fmt 0/0 code 0/0 sat 0000/0 iovf 0100/0 |
| m46 | VERSION not checked | KILLED | base:s4_errors | TB_ERROR cyc=31: descriptor (hdr 00000240 ctx 1 tag 3): ok=1 rej=0 code=0, expected code 1 |
| m47 | word 7 reserved bits not checked | KILLED | base:s4_errors | TB_ERROR cyc=147: descriptor (hdr 00000140 ctx 1 tag 26): ok=1 rej=0 code=0, expected code 4 |
| m48 | RM 5 accepted | KILLED | base:s4_errors | TB_ERROR cyc=153: descriptor (hdr 01025140 ctx 1 tag 28): ok=1 rej=0 code=0, expected code 7 |
| m49 | PC without RQ accepted | KILLED | base:s4_errors | TB_ERROR cyc=134: descriptor (hdr 01040140 ctx 1 tag 25): ok=1 rej=0 code=0, expected code 8 |
| m50 | unused fields not checked | KILLED | base:s4_errors | TB_ERROR cyc=70: descriptor (hdr 00000140 ctx 0 tag 12): ok=1 rej=0 code=0, expected code 4 |
| m51 | zB != 0 accepted | KILLED | base:s4_errors | TB_ERROR cyc=43: descriptor (hdr 01020140 ctx 1 tag 9): ok=1 rej=0 code=0, expected code 9 |
| m52 | M = ROWS + 1 accepted | KILLED | base:s4_errors | TB_ERROR cyc=56: descriptor (hdr 00000140 ctx 0 tag 11): ok=1 rej=0 code=0, expected code 10 |
| m53 | M0 + M overflow not checked | KILLED | base:s4_errors | TB_ERROR cyc=118: descriptor (hdr 00000140 ctx 1 tag 22): ok=1 rej=0 code=0, expected code 10 |
| m54 | per-tensor zp 128 accepted | KILLED | base:s4_errors | TB_ERROR cyc=112: descriptor (hdr 01020140 ctx 0 tag 21): ok=1 rej=0 code=0, expected code 11 |
| m55 | channel group range not checked | KILLED | base:s4_errors | TB_ERROR cyc=83: descriptor (hdr 01060140 ctx 0 tag 16): ok=1 rej=0 code=0, expected code 12 |
| m56 | unloaded parameters accepted | KILLED | base:s4_errors | TB_ERROR cyc=7: descriptor (hdr 01010140 ctx 0 tag 1): ok=1 rej=0 code=0, expected code 13 |
| m57 | column sum not required for zA != 0 | KILLED | asym:s4_reset | TB_ERROR cyc=58: descriptor (hdr 01070140 ctx 0 tag 8): ok=1 rej=0 code=0, expected code 13 |
| m58 | per-channel zp range not checked | KILLED | base:s4_perchan | TB_ERROR cyc=27: descriptor (hdr 01060140 ctx 0 tag 2): ok=1 rej=0 code=0, expected code 14 |
| m59 | CLOSE ignores the tag | KILLED | base:s4_errors | TB_ERROR cyc=263: descriptor (hdr 00000141 ctx 0 tag 44): ok=1 rej=0 code=0, expected code 5 |
| m60 | hard rejects not reported | KILLED | base:s4_errors | TB_ERROR cyc=31: descriptor (hdr 00000240 ctx 1 tag 3): ok=0 rej=0 code=1, expected code 1 |
| m61 | reject code not recorded in the sticky vector | KILLED | base:s4_perchan | TB_ERROR cyc=211: sticky desc 0000 beat 08 param 0, expected 4000 8 0 |
| m62 | lane mask ignored on writes | KILLED | base:s4_perchan | TB_ERROR cyc=751: beat (cmd @2936) sideband: tag 25/25 ctx 1/1 row 0/0 m 209535/209535 ch0 4/4 mask 0111/7 last 0/0 fmt 1/1 code 0/0 sat 0101/1 iovf 0000/0 |
| m63 | field mask ignored for bias | KILLED | base:s4_perchan | TB_ERROR cyc=771: beat (cmd @3123) sideband: tag 28/28 ctx 0/0 row 0/0 m 4294967292/4294967292 ch0 4/4 mask 0111/7 last 0/0 fmt 1/1 code 0/0 sat 0111/5 iovf 0010/2 |
| m64 | group range not checked on writes | KILLED | base:s4_errors | TB_ERROR cyc=221: param write grp 9: p_err=0 code=0, expected code 1 |
| m65 | valid bits not cleared by reset | KILLED | base:s4_errors | TB_ERROR cyc=7: descriptor (hdr 01010140 ctx 0 tag 1): ok=1 rej=0 code=0, expected code 13 |
| m66 | column-sum write with ASYM_EN = 0 accepted | KILLED | base:s4_errors | TB_ERROR cyc=223: param write grp 0: p_err=0 code=0, expected code 2 |
| m67 | element counter counts masked lanes | KILLED | base:s4_perchan | TB_ERROR cyc=207: perf counter 2 = 55, expected 43 |
| m68 | counters wrap instead of saturating | KILLED | pw6:s4_soak | TB_ERROR cyc=172: perf counter 2 = 12, expected 63 |
| m69 | packed INT8 view misaligned | KILLED | base:s1_pass | TB_ERROR cyc=10: beat (cmd @20) tag 1 row 0 lane 0: data -2147483647 (q8 0), expected -2147483647 [acc -2147483647] |
| m70 | output format reported wrongly | KILLED | base:s3_int8 | TB_ERROR cyc=24: beat (cmd @145) sideband: tag 1/1 ctx 0/0 row 0/0 m 4294967294/4294967294 ch0 8/8 mask 0001/1 last 0/0 fmt 0/1 code 0/0 sat 0000/0 iovf 0000/0 |
