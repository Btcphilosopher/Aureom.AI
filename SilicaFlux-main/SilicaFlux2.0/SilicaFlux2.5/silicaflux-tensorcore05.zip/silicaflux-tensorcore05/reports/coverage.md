# TENSORCORE 05 stimulus coverage (unit vectors of the baseline and asymmetric jobs)

Jobs: S1_pass_4x4, S2_bias_4x4, S3_int8_4x4, U_4x4_base, U_4x4_asym (all their suites and seeds).

* beats 18912, elements 52554, descriptors 7566, parameter writes 1686, resets 42
* saturated elements 10540 (high 5747, low 4380, explicit wrap 319); ReLU raised 9430; outputs exactly at the zero-point under ReLU 12445
* negative multipliers 20423, zero multipliers 1184; requantising shifts S used: 64 of 64 (every S = 0..63)
* near-ties (sticky set, within 2^-20 of 1/2): 1962

| rounding mode | exact ties reaching the output unsaturated | of which even floor |
|---|---|---|
| RNE | 3060 | 1563 |
| RTZ | 3186 | 1519 |
| RDN | 3087 | 1526 |
| RUP | 2729 | 1335 |
| RMM | 2693 | 1447 |

| descriptor reject code | times exercised |
|---|---|
| CHAN | 42 |
| CTX | 21 |
| DIM | 105 |
| FLAGS | 42 |
| FMT | 42 |
| OPCODE | 42 |
| PARAM | 74 |
| PZP | 126 |
| RM | 137 |
| RSVD | 315 |
| STATE | 42 |
| UNSUP | 236 |
| VERSION | 42 |
| ZP | 42 |
