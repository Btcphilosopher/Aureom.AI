# TENSORCORE 05 synthesis summary (Yosys 0.33)

Resource estimates only. No place and route, no timing library: **no Fmax or area claim.**
Every generic run passes `check -assert` (no latches, no multiple drivers, no logic loops).

| config | generic cells | generic FF | xc7 LUT | xc7 FF | xc7 DSP48E1 | xc7 CARRY4 | xc7 LUTRAM |
|---|---|---|---|---|---|---|---|
| 4x4_in32_grp1 | 49925 | 3716 | 5184 | 2740 | 16 | 540 | 38 |
| 4x4_in32_grp16 | 68171 | 10140 | 5780 | 2636 | 16 | 540 | 114 |
| 4x4_in32_grp16_asym | 88505 | 12307 | 6533 | 2755 | 24 | 612 | 138 |
| 4x4_in40_grp16_asym | 99365 | 12947 | 7147 | 2883 | 32 | 696 | 142 |
| 4x4_in32_grp1_noperf | 47887 | 3300 | 4715 | 2324 | 16 | 420 | 38 |
| 8x8_in32_grp4 | 103038 | 8956 | 9661 | 4024 | 32 | 909 | 214 |
