# Third-party (in-house) sources: copied unmodified

All files below are byte-identical copies from the repository `btcphilosopher/aureom.ai`,
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. None of them is modified by this package.

## TENSORCORE 04: `silicaflux-tensorcore04.zip` (SHA-256 `470f9fd7028bb5740c924ceb69f1cddd754ba3cd78a3ac4f23670979bf9956fb`)

`tensor_acc_fifo.sv` is **reused inside `tensor_quantize`** as its output FIFO. The other files are used
only by the integration example (`integration/tensor_core_output.sv`) and its testbench.

| file | SHA-256 |
|---|---|
| tensorcore04/rtl/tensor_acc_fifo.sv | 063393ee2000a3d525c7dcc5cebf33f18d83269c31cbf1505da56205e6b27fe0 |
| tensorcore04/rtl/tensor_acc_out_router.sv | 12c387c028ef6c69b29eff0fd73b092f261ecc0a72445bcff0609511c848f05b |
| tensorcore04/rtl/tensor_acc_pkg.sv | 839c395a324a1e04556f47bb22751397cf8506c05de7aeda11ea4fe1bdeaecb1 |
| tensorcore04/rtl/tensor_acc_storage.sv | e0927b856835f2079aa93f4df50a49979cc9a48c92493ca463406e87e6f8cbe3 |
| tensorcore04/rtl/tensor_acc_subsystem.sv | 6dadcd3e2d4bd14bab2f668176398dfab377d8f4fb8f16ff90013e02616ef1c6 |
| tensorcore04/rtl/tensor_accumulator.sv | bb1cce9bee4eed622e3a5c7975810dfe1f7cc3d9c86b82c8ba19a4388ef1d78f |

## TENSORCORE 02: `silicaflux-tensorcore02.zip` (SHA-256 `0a2ab37797b30ab3eda08d7e98b47dadd1549f8ab588d434c98b18b0a048370f`)

These are used only by the integration testbench. The hashes are identical to those recorded in TC04's
`third_party/tensorcore02/NOTICE.md`.

| file | SHA-256 |
|---|---|
| tensorcore02/rtl/tensor_systolic_array.sv | 07be2f4be73cb01800406a690d2e1301b8e71db2efc46401c3fe38ca31604c20 |
| tensorcore02/rtl/tensor_pe.sv | f931027f5c65b87b38cb962b303e31cd802b2ed6de9ff9bac8356ffcf237780f |
| tensorcore02/rtl/tensor_skew.sv | a69f279fa282f22e2df5ea535c1b72bf7d37f4681b5c4c07a3d2f54b4e8bedae |
| tensorcore02/rtl/tensor_output_collect.sv | ae2bf95f200152b8b45f80c89b7ddce6398f6a42e364007a896d199471aa2143 |

TENSORCORE 01 also defines a module named `tensor_pe`, with a different interface, so the two cannot be
compiled together. Only the TC02 version is included here.
