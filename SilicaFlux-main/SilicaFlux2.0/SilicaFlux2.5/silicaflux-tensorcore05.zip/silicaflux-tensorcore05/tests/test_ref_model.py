#!/usr/bin/env python3
"""
TENSORCORE 05 -- self-tests of the integer reference model (model/tq_ref.py).

  python3 tests/test_ref_model.py

1. Rounding: the definitional modes (Fraction) against a second, pure-integer
   (divmod) implementation, exhaustively for small operands, and against the
   RTL's algorithm (arithmetic shift + guard/sticky/lsb increment table) both
   exhaustively for small widths and randomly at full width (S up to 63,
   products up to 113 bits).
2. Known values for every mode (ties, negatives, S = 0).
3. Intermediate widths: every extreme corner of every input box fits the RTL
   widths (bias_eff, x, p, r, y), for IN_W 32/40/48/64 and ASYM_EN 0/1.  The
   maps are bilinear/monotone, so corner enumeration bounds the whole box.
   Also shows the widths are not wasteful: the corners need XW and PW bits.
4. ReLU-at-zero-point commutes with saturation when zp is inside the output
   range (the reason the descriptor rejects out-of-range zero-points).
5. Asymmetric input: sum (A - zA) B == sum AB - zA * colsum(B), random data.
6. quantize_multiplier precision.
7. Descriptor encode/decode round trip; element contract spot values.
"""
import os
import random
import sys
from fractions import Fraction

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
import tq_ref as R  # noqa: E402

FAIL = []


def check(cond, msg):
    if not cond:
        FAIL.append(msg)
        if len(FAIL) < 30:
            print("FAIL:", msg)


# ----------------------------------------------------------------------------- rounding
def round_divmod(p, s, rm):
    """Second definitional implementation: integers only."""
    if s == 0:
        return p
    d = 1 << s
    q, r = divmod(p, d)          # floor division, 0 <= r < d
    if r == 0:
        return q
    twice = 2 * r
    if rm == R.RM_RDN:
        return q
    if rm == R.RM_RUP:
        return q + 1
    if rm == R.RM_RTZ:
        return q + 1 if p < 0 else q
    if twice > d:
        return q + 1
    if twice < d:
        return q
    if rm == R.RM_RNE:
        return q + (q & 1)
    if rm == R.RM_RMM:
        return q + 1 if p > 0 else q
    raise ValueError


def round_rtl(p, s, rm, pw):
    """The RTL algorithm on a pw-bit two's-complement word (tensor_quantize.sv, stage C)."""
    u = R.ux(p, pw)
    fl = R.sx(u, pw) >> s                    # arithmetic shift right (floor)
    gm = 0 if s == 0 else (1 << (s - 1))
    sm = 0 if s <= 1 else ((1 << (s - 1)) - 1)
    g = int((u & gm) != 0)
    st = int((u & sm) != 0)
    neg = (u >> (pw - 1)) & 1
    lsb = fl & 1
    inc = {R.RM_RNE: g & (st | lsb),
           R.RM_RTZ: neg & (g | st),
           R.RM_RDN: 0,
           R.RM_RUP: g | st,
           R.RM_RMM: g & (st | (1 - neg))}[rm]
    return fl + inc


def test_rounding():
    n = 0
    for s in range(0, 11):
        for p in range(-(1 << 11), (1 << 11) + 1):
            for rm in R.RM_NAMES:
                a = R.round_rational(Fraction(p, 1 << s), rm)
                b = round_divmod(p, s, rm)
                c = round_rtl(p, s, rm, 16)
                check(a == b == c, f"round p={p} s={s} rm={rm}: frac {a} divmod {b} rtl {c}")
                n += 1
    rnd = random.Random(5)
    for _ in range(40000):
        pw = rnd.choice([65, 73, 81, 89, 105])
        p = rnd.randint(-(1 << (pw - 1)), (1 << (pw - 1)) - 1)
        s = rnd.randint(0, 63)
        if rnd.random() < 0.4 and s > 0:      # force exact ties and tie +- 1
            base = rnd.randint(-(1 << (pw - 2 - s)), (1 << (pw - 2 - s))) << s
            p = base + (1 << (s - 1)) + rnd.choice([-1, 0, 0, 1])
        for rm in R.RM_NAMES:
            a = R.round_rational(Fraction(p, 1 << s), rm)
            c = round_rtl(p, s, rm, pw)
            check(a == c, f"round(full) pw={pw} p={p} s={s} rm={rm}: frac {a} rtl {c}")
            n += 1
    return n


def test_known_values():
    tbl = [  # value, RNE, RTZ, RDN, RUP, RMM
        (Fraction(5, 2), 2, 2, 2, 3, 3), (Fraction(7, 2), 4, 3, 3, 4, 4),
        (Fraction(-5, 2), -2, -2, -3, -2, -3), (Fraction(-7, 2), -4, -3, -4, -3, -4),
        (Fraction(1, 2), 0, 0, 0, 1, 1), (Fraction(-1, 2), 0, 0, -1, 0, -1),
        (Fraction(3, 4), 1, 0, 0, 1, 1), (Fraction(-3, 4), -1, 0, -1, 0, -1),
        (Fraction(1, 4), 0, 0, 0, 1, 0), (Fraction(-1, 4), 0, 0, -1, 0, 0),
        (Fraction(6, 1), 6, 6, 6, 6, 6), (Fraction(-6, 1), -6, -6, -6, -6, -6),
    ]
    for v, *exp in tbl:
        for rm, e in zip(range(5), exp):
            check(R.round_rational(v, rm) == e, f"known {v} {R.RM_NAMES[rm]}: {R.round_rational(v, rm)} != {e}")
    return len(tbl) * 5


# ----------------------------------------------------------------------------- widths
def test_widths():
    n = 0
    for in_w in (32, 40, 48, 64):
        for asym in (0, 1):
            w = R.widths(in_w, asym)
            accs = R.srange(in_w)
            biases = R.srange(32)
            zas = (-128, 127) if asym else (0,)
            css = R.srange(in_w) if asym else (0,)
            mults = R.srange(32)
            zps = R.srange(32)
            need_x = need_p = 0
            for acc in accs:
                for b in biases:
                    for za in zas:
                        for cs in css:
                            beff = b - za * cs
                            check(R.fits(beff, w["CW"]), f"beff {beff} !fits CW={w['CW']} in_w={in_w}")
                            x = acc + beff
                            check(R.fits(x, w["XW"]), f"x {x} !fits XW={w['XW']}")
                            need_x = max(need_x, x.bit_length() + 1)
                            for mu in mults:
                                p = x * mu
                                check(R.fits(p, w["PW"]), f"p {p} !fits PW={w['PW']}")
                                need_p = max(need_p, p.bit_length() + 1)
                                for s in (0, 1, 2, 63):
                                    for rm in R.RM_NAMES:
                                        r = R.rescale(x, mu, s, rm)
                                        check(R.fits(r, w["PW"]), f"r {r} !fits PW")
                                        for zp in zps:
                                            check(R.fits(r + zp, w["YW"]), "y !fits YW")
                                            n += 1
            # the widths are tight for the x and p terms (no wasted bits beyond one)
            check(need_x >= w["XW"] - 1, f"XW={w['XW']} loose (need {need_x}) in_w={in_w} asym={asym}")
            check(need_p >= w["PW"] - 1, f"PW={w['PW']} loose (need {need_p})")
    return n


# ----------------------------------------------------------------------------- relu / clamp
def test_relu_commutes():
    n = 0
    for lo, hi in ((-128, 127), (-8, 7)):
        for zp in range(lo, hi + 1):
            for y in range(lo * 3, hi * 3 + 1):
                a = max(min(max(y, lo), hi), zp)          # clamp then ReLU (contract order)
                b = min(max(max(y, zp), lo), hi)          # ReLU then clamp
                check(a == b, f"relu/clamp commute zp={zp} y={y}")
                n += 1
    # and the counterexample that motivates the zp-range check
    zp, lo, hi, y = 200, -128, 127, 150
    check(max(min(max(y, lo), hi), zp) != min(max(max(y, zp), lo), hi), "counterexample lost")
    return n


# ----------------------------------------------------------------------------- asymmetric identity
def test_asym_identity():
    rnd = random.Random(11)
    n = 0
    for _ in range(300):
        M, K, N = rnd.randint(1, 5), rnd.randint(1, 40), rnd.randint(1, 5)
        A = [[rnd.randint(-128, 127) for _ in range(K)] for _ in range(M)]
        B = [[rnd.randint(-128, 127) for _ in range(N)] for _ in range(K)]
        za = rnd.randint(-128, 127)
        cs = R.colsum(B)
        for m in range(M):
            for nn in range(N):
                direct = sum((A[m][k] - za) * B[k][nn] for k in range(K))
                raw = sum(A[m][k] * B[k][nn] for k in range(K))
                check(direct == raw - za * cs[nn], "asym identity")
                n += 1
        # element contract applies the correction exactly once
        bias = [rnd.randint(-1000, 1000) for _ in range(N)]
        mult = [rnd.randint(1, (1 << 31) - 1) for _ in range(N)]
        shift = [rnd.randint(20, 40) for _ in range(N)]
        zp = [rnd.randint(-128, 127) for _ in range(N)]
        Q, _ = R.qgemm_direct(A, B, za=za, bias=bias, mult=mult, shift=shift, zp=zp)
        for m in range(M):
            for nn in range(N):
                raw = sum(A[m][k] * B[k][nn] for k in range(K))
                q, _, _ = R.element(raw, bias=bias[nn], za=za, colsum=cs[nn], mult=mult[nn],
                                    shift=shift[nn], zp=zp[nn], rq=True, ofmt=R.OFMT_INT8)
                check(q == Q[m][nn], "asym element vs direct gemm")
    return n


# ----------------------------------------------------------------------------- multiplier helper
def test_quantize_multiplier():
    rnd = random.Random(3)
    n = 0
    for _ in range(5000):
        e = rnd.uniform(-40, 30)
        sc = rnd.choice([-1, 1]) * (2.0 ** e)
        m, s = R.quantize_multiplier(sc)
        check(R.fits(m, 32) and 0 <= s <= 63, f"qm range {sc} -> {m},{s}")
        err = abs(Fraction(m, 1 << s) - Fraction(sc))
        check(err <= Fraction(1, 1 << (s + 1)), f"qm error {sc}")
        if 2.0 ** -32 < abs(sc) < 2.0 ** 30:
            check(abs(m) >= (1 << 30) or s == 63, f"qm not normalised {sc} -> {m},{s}")
            check(err / abs(Fraction(sc)) <= Fraction(1, 1 << 30), f"qm rel error {sc}")
        n += 1
    check(R.quantize_multiplier(0.0) == (0, 0), "qm zero")
    check(R.quantize_multiplier(1.0) == (1 << 30, 30), "qm one")
    return n


# ----------------------------------------------------------------------------- ABI + spot values
def test_abi_and_spots():
    rnd = random.Random(9)
    n = 0
    for _ in range(2000):
        f = dict(op=rnd.choice([R.OP_OPEN, R.OP_CLOSE]), rm=rnd.randint(0, 7), flags=rnd.randint(0, 31),
                 ofmt=rnd.randint(0, 15), tag=rnd.randint(0, 0xFFFF), ctx=rnd.randint(0, 255),
                 m=rnd.randint(0, 255), n=rnd.randint(0, 255), grp=rnd.randint(0, 0xFFFF),
                 m0=rnd.randint(0, 0xFFFFFFFF), mult=rnd.randint(-(1 << 31), (1 << 31) - 1),
                 shift=rnd.randint(0, 63), za=rnd.randint(-128, 127), zb=rnd.randint(0, 255),
                 zp=rnd.randint(-(1 << 31), (1 << 31) - 1))
        d = R.decode_desc(R.encode_desc(**f))
        for k, v in f.items():
            check(d[k] == v, f"abi round trip {k}: {d[k]} != {v}")
        n += 1
    E = R.element
    check(E(12345) == (12345, False, False), "passthrough")
    check(E(-(1 << 31)) == (-(1 << 31), False, False), "passthrough INT32_MIN")
    check(E((1 << 31) - 1, bias=1) == ((1 << 31) - 1, True, False), "bias +sat")
    check(E(-(1 << 31), bias=-1) == (-(1 << 31), True, False), "bias -sat")
    check(E((1 << 31) - 1, bias=1, wrap=True) == (-(1 << 31), True, False), "bias wrap")
    check(E(777, mult=0, shift=5, zp=-3, rq=True, ofmt=R.OFMT_INT8) == (-3, False, False), "zero multiplier")
    check(E(5, mult=1, shift=1, rq=True, ofmt=R.OFMT_INT8) == (2, False, False), "2.5 RNE")
    check(E(7, mult=1, shift=1, rq=True, ofmt=R.OFMT_INT8) == (4, False, False), "3.5 RNE")
    check(E(-5, mult=1, shift=1, rq=True, ofmt=R.OFMT_INT8, rm=R.RM_RMM) == (-3, False, False), "-2.5 RMM")
    check(E(1000, mult=1, shift=0, rq=True, ofmt=R.OFMT_INT8) == (127, True, False), "int8 +sat")
    check(E(-1000, mult=1, shift=0, rq=True, ofmt=R.OFMT_INT8) == (-128, True, False), "int8 -sat")
    check(E(-1000, mult=1, shift=0, zp=-10, rq=True, ofmt=R.OFMT_INT8, relu=True) == (-10, True, True),
          "relu clamps at zp")
    check(E(-5, relu=True) == (0, False, True), "int32 relu")
    check(E(1, mult=-(1 << 31), shift=31, rq=True, ofmt=R.OFMT_INT8) == (-1, False, False), "negative scale")
    check(E(3, mult=1, shift=63, rq=True, ofmt=R.OFMT_INT8, rm=R.RM_RUP) == (1, False, False), "max shift RUP")
    return n


def main():
    tot = 0
    for t in (test_rounding, test_known_values, test_widths, test_relu_commutes, test_asym_identity,
              test_quantize_multiplier, test_abi_and_spots):
        k = t()
        print(f"{t.__name__:28s} {k:9d} checks")
        tot += k
    print(f"model self-tests: {tot} checks, {len(FAIL)} failures")
    print("RESULT:", "PASS" if not FAIL else "FAIL")
    sys.exit(0 if not FAIL else 1)


if __name__ == "__main__":
    main()
