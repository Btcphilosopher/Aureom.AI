# Audit: accumulator interface, existing quantisation, reference kernels, descriptors

Repository: `btcphilosopher/aureom.ai`, branch `claude/beautiful-shannon-bnxwb5`, audited 2026-11-08.
**Nothing was committed to the repository.** This package is delivered only as a zip.

The repository is an archive store of zips, PDFs and images. The TensorCore line lives in
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`:

| archive | contents | used here |
|---|---|---|
| `silicaflux-tensorcore01-tensor_pe.zip` | TC01 INT8 MAC PE + mesh | read only |
| `silicaflux-tensorcore02.zip` (SHA-256 `0a2ab377…370f`) | TC02 output-stationary systolic array | **integration TB**, unmodified |
| `silicaflux-tensorcore03.zip` (SHA-256 `c0350203…7741`) | TC03 banked operand buffers: SRAM delivery of `s_a`/`s_b` k-slices to TC02, double buffering | not on this module's data path; it produces no row or column sums. The integration TB drives the array's operand port directly, as TC04's did |
| `silicaflux-tensorcore04.zip` (SHA-256 `470f9fd7…56fb`) | TC04 partial-sum accumulator subsystem | **direct upstream**, unmodified; its FIFO is **reused** |
| `silicaflux-hpc-m06-command-queue.zip` | HPC Module 06 command queue and descriptor ABI v1 | conventions reused |
| `silicafluxai.zip` | silicaflux-ai: `sfx_saturate`, `sfx_accumulator`, `gemm.py`, `datatypes.py` | read; nothing reused (below) |
| `SilicaFluxML.zip` | `fixed_point_ops.sv` (Q-format saturating ops) | read; not applicable (below) |

The upstream was re-verified here before work started. TC04 `make smoke` (unit + real-array integration,
Icarus) and `make model` pass with the installed Icarus 12.0 / Verilator 5.020 / Yosys 0.33, the versions
the TC line uses.

## 1. Accumulator output interface (TC04 → this module)

`tensor_acc_subsystem` routes each committed tile row to any subset of three ports (an eager fork). The
quantiser port is `oquant_valid/oquant_ready`. The payload is shared:

| TC04 signal | meaning | used as |
|---|---|---|
| `o_tag` (16) | tile tag | `in_tag` |
| `o_slot` | accumulator slot | `in_ctx` (context index) |
| `o_row`, `o_last`, `o_col_mask` | row framing | `in_row`, `in_last`, `in_col_mask` |
| `o_wide` (COLS × ACC_W) | **exact** accumulator | `in_data`. TC04's docs say the quantiser should consume `o_wide` when ACC_W > 32 |
| `o_data` (COLS × 32) | INT32 view, clipped | **not** used (it would pre-saturate a wide accumulator) |
| `o_ovf` | per-lane: the accumulation itself overflowed | `in_ovf`, passed through as `out_iovf` |
| `o_clip` | o_data narrowing clipped | not used (refers to `o_data`) |
| `o_err` | a malformed psum was rejected on this tile | `in_err`, beat flagged `UPSTREAM` |

Findings that shaped the design:

* **Commit order is not descriptor order.** TC04 commits a tile when its last chunk lands, so with two or
  more slots tiles leave in completion order. The quantiser therefore keys its contexts by slot and checks
  the tag. A FIFO of descriptors would mis-pair parameters.
* **A tile's beats are contiguous, and TC04 re-opens a slot only after the last commit read of its
  previous tile has issued.** That previous tile's beats may still be in TC04's output FIFO, but they are
  all *ahead* of any beat of the new tile. So one context per slot is enough: the new tile's descriptor
  waits (`desc_ready = 0`) until the previous tile's last beat has passed the quantiser and released the
  context.
* **Bias can already be applied in TC04** (`cfg_bias_en`, folded into chunk 0, exactly once). The quantiser
  also offers bias, so that it can work standalone and for the INT32 bias mode the brief requires. The
  integration rule is *exactly one of the two*, and the integration test runs both placements. Integer
  addition is associative, so with TC04's `STRICT_RANGE` both give the same result (`INTEGRATION.md`).
* **The output channel is N**, TC04's `bias[n]` axis. All rows of a tile share COLS channels, so the
  parameters are fetched once per tile, not once per beat.

## 2. Existing INT8 tensor arithmetic

| | TC01 `tensor_pe` | TC02 `tensor_pe` / array |
|---|---|---|
| operands | signed INT8 × INT8, **symmetric** (no zero-point inputs) | same |
| accumulation | 32-bit (40 verified), saturate / wrap | 32-bit, wraps silently; TC04 bounds K so it cannot |
| row / column sums | none | none |

Neither array produces Σ_k A[m][k] (row sums) or Σ_k B[k][n] (column sums). This decides the
asymmetric-input question (`NUMERIC_FORMAT.md` §6.3). Column sums depend only on the weights and can be
precomputed by the host, so zA ≠ 0 with zB = 0 is implementable. Row sums would need new hardware in the
operand path, so zB ≠ 0 is not implementable and is rejected.

## 3. Existing quantisation RTL

**None exists.** The search covered every zip in the repository for `quant`, `requant`, `zero_point`,
`round`, `scale`. Findings:

* `silicaflux-ai/docs/PHASE_STATUS.md`: "Not built: rounding, scaling/requantization, zero-point handling,
  dequantization". `sfx_gemm_controller` outputs raw INT32.
* `silicaflux-ai/rtl/arithmetic/sfx_saturate.sv`: a combinational signed clamp (`saturated` flag). This
  module's saturation is the same idea, but it compares the exact YW-bit value with a format-dependent
  bound, so `sfx_saturate` (fixed widths, no format select) is not instantiated. It is not otherwise
  verified for this use.
* `silicaflux-ai/python/models/datatypes.py: quantize_affine`: **float** `round(x/scale) + zp` with numpy
  (round-half-even on float64), marked PYTHON-MODEL-ONLY. It is not an integer contract and is not used as
  the reference. The reference here is an independent Fraction-based integer model.
* `SilicaFluxML/rtl/fixed_point_ops.sv`: Q-format add/mul/div with **truncating** rescale. Different
  semantics (truncation, not a documented rounding mode). Not used.
* TC01 `docs/AUDIT.md` already records `dsp_arithmetic.zip` (`mac_unit`, `sat_arith`) as fixed-point and
  not compiling in Icarus 12.

## 4. Software reference kernels

`silicaflux-ai/python/models/gemm.py` tiles INT8 GEMM and wraps at 32 bits. It models the silicaflux-ai
lineage, not TC02/TC04 (whose accumulation never wraps). TC04's `model/acc_ref.py` is the exact reference
for the accumulation. This module's reference (`model/tq_ref.py`) starts where those stop. It takes exact
accumulators (or, for the GEMM-level checks, recomputes `Σ (A − zA)·B` itself) and applies the conversion
contract.

## 5. Command descriptor format

HPC Module 06 defines ABI v1. It uses a 256-bit descriptor (8 words, word 0 = `OPCODE[7:0] VERSION[11:8]
RM[14:12] rsvd[15] FLAGS[23:16] TID[31:24]`), opcode classes `0x0X` DMA, `0x1X` vector, `0x2X` sync and
`0x3X` control, with everything else reserved. Its validation is first-failing-rule with no side effects,
and it reuses the RISC-V `frm` rounding encoding (RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4).

This module's descriptor follows the same conventions:

* 256 bits;
* word 0 has OPCODE / VERSION / RM / FLAGS in the same bit positions;
* the same RM encoding;
* reserved fields must be 0;
* ordered validation with codes.

It takes the unused class `0x4X` (OPEN `0x40`, CLOSE `0x41`). The 16-bit tile tag replaces M06's 8-bit TID
because TC04 tags are 16 bits. **Module 06 is not modified.** Adding these opcodes to its queue is an
integration step, described in `INTEGRATION.md` §5 and not implemented.

## 6. Reused, unmodified (hashes in `third_party/NOTICE.md`)

* `tensor_acc_fifo.sv` (TC04): the output FIFO of this module.
* All TC04 RTL and all TC02 array RTL: the integration example and testbench.
* TC04 conventions: synchronous active-low reset; flat packed buses with `+:` lane slicing; package with
  scoped references and assignment-to-function-name (Yosys 0.33); `translate_off` elaboration checks;
  invariants under an `ifndef` so mutation testing can compile them out; the TB edge-sampler discipline.
* M06 ABI conventions (above).

## 7. Tool findings during this work

* **Verilator 5.020 (--timing):** per-slice non-blocking writes `bus[j*W +: W] <= …` inside a loop in an
  automatic task did not trigger re-evaluation of the DUT's combinational logic. The DUT decoded a stale
  descriptor; at `-O0` it never saw the input at all. Icarus was unaffected. The testbenches therefore
  assemble every wide bus in a local variable and assign it whole. This is noted in `tb/tb_tq.sv`.
* **Verilator metacomments:** a comment line beginning `// Verilator …` is parsed as a directive. Such a
  line in the TB changed scheduling behaviour and broke a multi-top build. Comments are worded to avoid it.
* **Cross-simulator determinism:** concurrent TB threads resumed in the same time slot run in a
  simulator-dependent order. The data matched, but stall counts differed by a few cycles. Each thread now
  resumes in its own post-edge slot (#1 dispatcher, #2 control, #3 beats), and the logs of the two
  simulators are identical (208 / 208 comparisons).
