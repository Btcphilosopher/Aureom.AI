# Future precision roadmap (documented, NOT implemented)

Nothing in this file exists in the RTL. Every item below is rejected today by the descriptor validation:
reserved OFMT codes give `QR_FMT`, and a non-zero ZB gives `QR_UNSUP`. Hardware never approximates an
unsupported request silently. Each item needs its own arithmetic core, its own numeric specification
(like `NUMERIC_FORMAT.md`) and its own independent reference and verification campaign before it may be
enabled.

The integer path built here (exact x → one rounding → saturation → activation) stays the reference for
every integer format. Floating-point formats are a different kind of arithmetic. They are not "more bits
of the same thing".

| item | what it needs | what can be reused | key verification risks |
|---|---|---|---|
| **INT4 outputs** (signed `[-8, 7]`; packed 2 per byte) | a new OFMT code; `qmin/qmax` = −8 / 7; zero-point range check for INT4; a packed output view (`COLS × 4`); a packing contract for odd COLS | the whole lane datapath: only the clamp bounds change | packing / lane order; ReLU floor at an INT4 zero-point; the zp range check |
| **INT4 operands** (weights / activations) | an INT4 or packed-INT8 MAC array (TC01/02 are INT8); TC04 range bound `P_MAX = 2^6` (K bound grows 256×) | this output stage unchanged (the accumulator stays INT32) | accumulation bounds in TC04 (`max_exact_k(32, 4)`); unpacking order in TC03 |
| **UINT8 outputs** (legacy asymmetric) | OFMT code, `[0, 255]` | lane datapath | zp in `[0, 255]`; ReLU floor |
| **Weight zero-point zB ≠ 0** | `Σ_k A[m][k]` per row: a row-sum accumulator beside TC03's A delivery (or a ones-column trick in the array), carried with the tile to this stage; the `K·zA·zB` term | the correction path (`bias_eff` becomes per row × per channel, so it moves from the snapshot to stage A) | the row sum must cover exactly the same K chunks as the accumulation (chunk replays in TC04); width `IN_W + 9`; applied once |
| **TFLite-compatible requantisation** (`MultiplyByQuantizedMultiplier`: doubling high multiply, then rounding shift, both ties away from zero, two roundings) | a separate rounding mode | the multiplier | bit-exactness against the TFLite reference kernels across left / right shifts; documented divergence from the single-rounding contract |
| **BF16 output** (1-8-7) | int → float conversion: leading-zero count, normalise, round to nearest even at the 8-bit significand, overflow to ±Inf or saturate (policy to define), signed zero, no subnormals from integers; scale as a float multiply or exponent bias | HPC Module 02 `hpc_fp32_round`, `hpc_lzc` and their RNE / fflags conventions (`docs/FP_SEMANTICS.md`) | double rounding if converted via FP32; exact-integer cases above 2^8; specification of the scale (power of two only, or arbitrary) |
| **FP16 output** (1-5-10) | as BF16 but with 5-bit exponent: integers above 65504 overflow, so saturation-to-max-finite vs Inf must be specified; subnormals reachable with fractional scales | Module 02 rounding | overflow policy; subnormal handling; tininess definition |
| **FP32 accumulation for floating-point tensor ops** | a floating-point MAC array (FMA per PE or a fused dot product), non-associative accumulation, so **K-chunking changes results**: the reduction order must be specified (sequential per chunk? pairwise?) and TC04's "exact regardless of partition" property no longer holds | Module 02/03 FP32 FMA lanes (`hpc_fp32_fma`) | order-dependent results; NaN / Inf propagation through partial sums; a new reference that reproduces the exact reduction order |
| **FP8 variants** (E4M3 / E5M2, OCP MX) | per-format encodings: E4M3 has no Inf and saturates, E5M2 is IEEE-like; a scaling contract (per-tensor or MX block scales: shared E8M0 exponent per block of 32); an FP8 MAC array or FP8 → INT dequantisation | output path: rounding to 3 or 2 mantissa bits with RNE; saturation semantics per format | the format-specific NaN / saturation rules; block-scale association with elements (the same association problem this module solves for parameters) |
| **Sparse tensor formats** (2:4 structured, block-sparse, CSR) | metadata streams through TC03 and the array; index decode; skipping zero K-slices in TC02/TC04 | this stage unchanged for structured sparsity on K (outputs stay dense); output sparsity (e.g. ReLU masks) would need an output compressor | metadata / value alignment under stalls; exactness preserved when K-slices are skipped |

## Order of work suggested by the risk

1. **INT4 / UINT8 outputs.** These are a bounds change on a verified datapath: new OFMT codes, new tests.
2. **zB ≠ 0.** This needs one new statistic (row sums), whose exactness can be proven the same way as the
   column-sum correction.
3. **TFLite-compatible mode,** for direct model import.
4. **BF16 / FP16 outputs from integers.** One rounding, reusing the Module 02 rounding unit.
5. **Floating-point accumulation** and **FP8**. These need new arithmetic cores, a reduction-order contract
   and a new reference.
6. **Sparsity.** This is a data-delivery feature (TC03 / TC02); the output stage is largely unaffected.
