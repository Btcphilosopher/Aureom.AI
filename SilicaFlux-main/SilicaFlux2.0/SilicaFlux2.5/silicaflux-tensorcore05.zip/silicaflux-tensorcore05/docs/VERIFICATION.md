# Verification

All results below are from the final runs on the shipped sources, with Icarus Verilog 12.0, Verilator
5.020, Yosys 0.33 and Python 3 (standard library only). Raw outputs are in `reports/` and `logs/`.

## 1. Strategy

1. **An independent integer reference.** `model/tq_ref.py` implements `NUMERIC_FORMAT.md` literally. Its
   integers are unbounded, every division by 2^S is an exact `fractions.Fraction`, and each rounding mode
   uses its textbook definition: Python `round()` on a Fraction is ties-to-even; floor, ceil and trunc come
   from `math`. Nothing is copied from the RTL's bit-level algorithm. GEMM-level expected values evaluate
   `Σ (A − zA)·B` literally, never through the correction identity the hardware uses.
2. **Proofs by enumeration, inside the model's self-tests** (`tests/test_ref_model.py`, 638 281 checks):
   * the RTL rounding algorithm equals the definitions (exhaustive for small widths, 200 k random cases at
     full width);
   * every intermediate width holds every corner of the input box;
   * ReLU-at-zp commutes with saturation;
   * the asymmetric identity holds;
   * `quantize_multiplier` meets its precision bound.
3. **Staged bring-up, enforced by the regression driver.** Stage 1: INT32 pass-through. Stage 2: bias.
   Stage 3: symmetric INT8 requantisation. Only then stage 4, the advanced modes. A stage runs only if every
   earlier stage passed.
4. **Bit-for-bit comparison of every output field** of every beat: data, packed INT8 view, saturation and
   upstream flags, error code, tag, context, row, element index (m, channel), mask, last flag, format.
   Also every descriptor and parameter-write response code, context status, the sticky error vectors, and
   all 13 performance counters.
5. **Two simulators, identical logs.** Every vector that runs on both must produce line-for-line identical
   `TB_` output (316 / 316).
6. **Mutation testing.** 70 injected bugs, with the RTL's own invariants compiled out.

## 2. Testbenches

| TB | DUT | drives | checks |
|---|---|---|---|
| `tb/tb_tq.sv` | `tensor_quantize` | vector-driven: a dispatcher plus two concurrent drivers (control: parameters and descriptors in list order; beats), random gaps, random `out_ready` with stall bursts up to 64 cycles, reset at random points during traffic, same-cycle parameter write + descriptor, `perf_clr` | §1.4. Valid / payload stability under backpressure every cycle. No output without an accepted input. Drain to idle. Throughput (`+NOSTALL`). Watchdog |
| `tb/tb_tq_integ.sv` | `integration/tensor_core_output.sv` = **unmodified TC02 array → unmodified TC04 subsystem → TC05** | K-chunk sequencer: per layer, parameter loads; per tile, TC04 cfg + TC05 descriptor (30 % late), chunks launched on the array with random `s_valid` gaps and `stall_i`; random backpressure on the quantised and raw SRAM ports | every quantised element vs `qgemm_direct`; every raw SRAM-port element vs the exact GEMM; every row exactly once per selected port; no array / accumulator / quantiser error or reject; counters |

The vector generators (`tools/gen_unit.py`, `tools/gen_integ.py`) compute every expected value with the
reference model. The ordering rules that keep expected values deterministic, even though the TB drives the
ports concurrently with random timing, are documented in the `gen_unit.py` header: waves, SYNC / BSYNC
barriers, and strays derived only from real beats.

## 3. Unit suites (stage in brackets)

| suite | content |
|---|---|
| `s1_pass` [1] | INT32 pass-through: extremes, random IN_W values, partial tiles, interleaved contexts, upstream flags |
| `s2_bias` [2] | per-channel INT32 bias from the table: ±2^31 extremes, positive and negative saturation, explicit WRAP |
| `s3_int8` [3] | INT8 per-tensor requantisation, RNE, optional bias and ReLU; realistic scales, tie-friendly scales, zero / ±1 / ±2^31 multipliers, S ∈ {0, 1, 62, 63}; values aimed at qmin ± 1, qmax ± 1, zp ± 1 |
| `s3_ties` [3] | directed: **every shift S = 1..63**, multipliers chosen so exact ties are reachable unsaturated (S = 63: M = −2^31, x = ±2^31), RNE |
| `s4_perchan` | per-channel M / S / zp; the table rewritten while tiles that use it are in flight; **same-cycle write + descriptor** (the descriptor sees the old values, the next one the new values); partial-lane and single-field writes |
| `s4_rmodes` / `s4_ties` | RTZ, RDN, RUP, RMM (and RNE) per-channel and per-tensor; dense ties for every shift in all five modes |
| `s4_int32rq` | requantisation into INT32, saturation and wrap, per-channel and per-tensor, all modes |
| `s4_asym` | zA ∈ {−128, 127, random}, column sums at their extremes (ASYM_EN = 1), or rejection `QR_UNSUP` (ASYM_EN = 0); zB ≠ 0 always rejected |
| `s4_errors` | **every** reject code (VERSION, OPCODE, CTX, RSVD ×13 variants: 7 reserved-bit, 6 unused-field, STATE, FMT, RM, FLAGS, UNSUP, DIM ×5, ZP, CHAN, PARAM, PZP), poisoned tiles drained, CLOSE (wrong tag, malformed, after an aborted tile), wrong-tag strays (half with `last = 1`, which must not release), frame errors, upstream errors, NOCTX (for non-power-of-two NUM_CTX), parameter-write errors, sticky vectors |
| `s4_reset` | reset after 0..300 cycles of traffic; everything cleared; table valid bits cleared (`QR_PARAM` until reloaded, including the column sum alone) |
| `s4_gemm` | representative quantised layers (int8 activations, symmetric per-channel weights, int32 bias, real scales → `quantize_multiplier`), per-tensor and per-channel, zA = −128 with ASYM_EN; expected values cross-checked against `qgemm_direct` inside the generator |
| `s4_soak` | random mix of all modes, poisoned descriptors, strays, frame and upstream errors, reloads, `perf_clr` |
| `p_stream` | throughput: 480 full beats, `out_ready = 1`; requires one accepted beat per cycle and zero credit stalls |

### Brief §7 checklist

| item | where (examples) |
|---|---|
| positive saturation | `s2_bias` (acc + bias > 2^31 − 1), `s3_int8` (y > 127), `s4_int32rq`; 5 747 high saturations in the baseline + ASYM unit vectors (`reports/coverage.md`) |
| negative saturation | same suites; 4 380 low saturations |
| large bias | `s2_bias` bias ∈ {±2^31, ±2^30}, with acc extremes |
| negative accumulator | every suite (signed random, INT_MIN); 20 423 negative multipliers on top |
| zero multiplier | `s3_int8` / `s4_*` (M = 0, any S → y = zp); 1 184 elements |
| rounding boundaries | `s3_ties`, `s4_ties`: thousands of exact ties per mode, about half with an even floor (where RNE and half-up differ), plus 1 962 near-ties (`reports/coverage.md`) |
| maximum shift | S = 63 in `s3_ties` / `s4_ties` (exact tie x·M = 2^62), `s3_int8` |
| minimum shift | S = 0 (`rand_scale` edge cases; all pass-through and bias modes run at S = 0 internally) |
| intermediate overflow prevention | widths proven by corner enumeration (model); the RTL driven with acc = ±2^(IN_W−1), bias = ±2^31, M = −2^31, zA·colsum extremes (`s4_asym`), IN_W 32/40/48/64; any wrap inside the datapath would show as a data mismatch |

### Brief §9 checklist

| item | where |
|---|---|
| independent integer reference, bit for bit | §1.1; every field compared |
| representative quantised GEMM datasets | `s4_gemm` (unit) and the integration layers (`layers`, `stress`) on the real array |
| positive / negative scales | M < 0 in every requantising suite (negative scales are permitted by the contract) |
| per-channel parameters | `s4_perchan`, `s4_ties`, `s4_gemm`, integration `int8_pc` / `int8_asym` |
| ReLU boundaries | values aimed at zp − 1, zp, zp + 1; 12 445 outputs exactly at the zero-point; mutants m21–m23 |
| saturation, bias | above |
| random data | `s4_soak` (and every suite's background distribution) |
| backpressure | 4 unit and 3 integration timing profiles, up to 85 % not-ready with 64-cycle bursts |
| reset | `s4_reset` (468 resets across the regression) |

## 4. Regression (`reports/regression_summary.md`)

**1239 / 1239 checks pass**: 455 Icarus runs, 467 Verilator runs, 316 cross-simulator log comparisons (all
identical), and the model self-test. 30 jobs.

| stage | checks | content |
|---|---|---|
| 0 | 1 / 1 | reference-model self-tests (638 281 checks) |
| 1 | 44 / 44 | INT32 pass-through, 4×4 (3 seeds × 4 profiles × 2 simulators) and IN_W 40 |
| 2 | 44 / 44 | INT32 bias, 4×4 and IN_W 48 |
| 3 | 88 / 88 | INT8 requantisation + ties, 4×4 and 1×1 |
| 4 | 1062 / 1062 | configuration matrix below, throughput, integration |

Configuration matrix (stage 4):

* unit: 4×4 base (4 seeds) and ASYM; 3×5 with IN_W 40, 3 contexts, ASYM; 4×4 IN_W 48; 2×2 IN_W 64 with
  4 contexts and ASYM; 1×1 with 1 context; 8×8; 16×16; OFIFO_DEPTH 1 / 2 / 8; PERF_W 6 (counter
  saturation); long soaks (×6 iterations, 4 seeds) for base and ASYM;
* integration: 4×4 base and ASYM; 4×4 ACC_W 40 + ASYM; 4×4 with 3 slots; 2×2 ASYM; 8×8; long multi-layer
  runs.

Volume:

* unit: 259 744 beats, 750 435 elements, 145 247 saturations, 139 057 ReLU clamps, 48 754 error beats,
  104 443 descriptors, 25 804 parameter writes, 474 same-cycle write + descriptor pairs, 468 resets,
  7 224 counter checks;
* integration on the real array: 3 638 tiles, 7 015 chunk launches, 43 796 quantised elements (10 177
  saturated), 4 886 raw beats, 1 170 late descriptors (34 495 cycles of beats waiting for them), 572 tiles
  with the bias in TC04 instead of TC05.

**Definition of done.** Every converted element in every run equals the declared fixed-point contract
exactly, including the rounding (all five modes, every shift) and the saturation flag.

**Throughput.** One beat per cycle with `OFIFO_DEPTH ≥ 4` (480 beats in 480 cycles, zero credit stalls,
both simulators); 1/2 at depth 2, 1/4 at depth 1. Latency is 3 cycles (`logs/perf/`).

## 5. Mutation testing (`reports/mutation_report.md`)

70 mutants: rounding (13), zero-point / saturation / activation (10), bias / correction / snapshot (10),
contexts / flow control (7), beat errors (5), descriptor validation (16), parameter table (5), outputs /
counters (4). The RTL's invariants are compiled out, so only the testbench can kill a mutant. The plan runs
17 vector sets, cheapest first.

**69 / 70 killed. 1 proven equivalent. 0 unexplained.**

* **m11** (sign taken from bit PW−2) is **equivalent**. Every reachable product fits PW−1 bits except the
  single corner `(−2^(XW−1))·(−2^31) = 2^(XW+30)`. Its low S bits are zero for every S ≤ 63, so `neg`
  (only used ANDed with `g|st`) is never consulted for it.
* **Gaps found and closed.** The first mutation run left m49 (PC without RQ accepted) and m54 (zp = 128
  accepted) alive. The error suite applied a random *subset* of the malformed descriptors per iteration, and
  that seed never drew them. It now applies every one in every iteration.
* **Before the mutation campaign, an RNE → round-half-up injection survived the INT8 suite.** Its tie
  cases were constructed at random magnitudes and almost all saturated, so the rounding never mattered.
  This was fixed with tie solutions centred on in-range targets, tie-friendly multipliers
  (`odd × 2^a`), the dense `s3_ties` / `s4_ties` suites, and the live-tie coverage counters.

## 6. Problems found during the work (and fixes)

| found by | problem | fix |
|---|---|---|
| model width test | the generic formula `max(IN_W, CW) + 1` over-provisioned XW by one bit with ASYM_EN | exact bound `IN_W + 8`; the test now also checks tightness |
| design review (before simulation) | `cond ? (zA * colsum) : '0`: an unsigned arm makes SV evaluate the product unsigned (zero-extended operands) | product formed in its own signed net (comment in RTL) |
| Verilator lint | `EVW'(a & ~b)` evaluates the operator at the cast width | self-determined `EVW'({…})` |
| Verilator run | per-slice non-blocking writes to a wide TB bus inside a task were not seen by the DUT's combinational logic (Verilator 5.020 --timing; Icarus fine) | buses assembled locally, assigned whole |
| Verilator run | a comment starting `// Verilator …` parsed as a metacomment | reworded |
| cross-simulator diff | same-time-slot thread order differed (data equal, stall counts not) | per-thread post-edge slots (#1 / #2 / #3) |
| unit TB | CLOSE descriptors built with the encoder's M = N = 1 defaults (RSVD, not CLOSE) | dedicated `close_desc` |
| unit TB | a new tile's beat overtook the CLOSE of the aborted tile (the DUT correctly flagged TAG) | beat-side barrier BSYNC |
| unit TB | a stray derived from a stray regained the real tag (genuine early release; the DUT was correct) | strays derived only from real beats |
| integration TB | late descriptors still beat the accumulator's commit (no actual waits) | random extra delay before late descriptors |

Simulation found **no functional bug in the conversion RTL**. Stages 1–3 passed at first run. The bugs
above were in the stimulus, the testbench, or (one width, one signedness trap) caught by the model test and
by review before simulation. Because a first-time pass can also mean weak tests, the tests themselves were
checked by mutation (§5) and by the coverage counters (`reports/coverage.md`).

## 7. Other checks

* **Lint:** `verilator -Wall` clean for `tensor_quantize` over 8 parameter sets (1×1 … 16×16, IN_W
  32/40/48/64, contexts 1–4, ASYM 0/1), and for the integration wrapper. The only warnings outside this
  package are TIMESCALEMOD in the unmodified TC02 files (`logs/final_lint.log`).
* **ABI:** `tools/check_abi.py`: 131 / 131 RTL ↔ model items (codes, bits, counter indices, widths for IN_W
  32..64).
* **Synthesis:** Yosys generic and xc7 for 6 configurations; `check -assert` passes and there are no
  latches (`reports/synthesis_summary.md`).
* **Upstream:** TC04 `make smoke` and `make model` re-run here and pass. The TC02/TC04 RTL is byte-identical
  to the repository's (`third_party/NOTICE.md`).

## 8. Limits of this verification (stated plainly)

* Simulation only. No formal proof (the rounding and width proofs are by enumeration in Python, not on the
  RTL). No gate-level simulation. No FPGA or silicon run. Synthesis is Yosys mapping without place and
  route: no Fmax or area claim.
* The parameter table is a flop / LUTRAM array. An SRAM-macro version must keep the read-on-OPEN timing
  (`ARCHITECTURE.md` §7). None is included.
* The integration TB models the operand feed (TC03 is not instantiated). It does not exercise TC04
  `HC_ABORT` + TC05 CLOSE, or a reset, **in the full chain**. Both are covered at unit level only.
* Column-sum correctness is a host obligation. The hardware cannot check it (`NUMERIC_FORMAT.md` §6.3).
* The float-scale agreement figures (628 / 628 sample elements identical) are informational. Differences
  of 1 LSB are possible by construction and are not errors.
