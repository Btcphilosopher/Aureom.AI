# Integration

Example RTL: `integration/tensor_core_output.sv` (TC04 `tensor_acc_subsystem` + `tensor_quantize`).
Example host software: `integration/example_layer.py`. Example sequencer and full-chain test:
`tb/tb_tq_integ.sv`, driving the unmodified TC02 array → TC04 → TC05.

```
 TC03 operand buffers --s_a/s_b--> TC02 array --m_*--> TC04 accumulator --oquant_*--> TC05 quantiser --> out_*
 (modelled by the TB)                                     |  osram_* / odma_*: raw exact INT32, untouched
                                                          v
                                     per-tile cfg (TC04) and descriptor (TC05) from one sequencer
```

## 1. Wiring (the complete contract between TC04 and TC05)

| TC04 | TC05 | note |
|---|---|---|
| `oquant_valid` / `oquant_ready` | `in_valid` / `in_ready` | TC04's eager fork waits for every selected port. A beat waiting for its quantiser descriptor therefore also holds the SRAM / DMA copy of that beat. This is intended: rows stay aligned across ports |
| `o_slot` | `in_ctx` | `NUM_CTX = NUM_TILES` |
| `o_tag`, `o_row`, `o_last`, `o_col_mask` | `in_tag`, `in_row`, `in_last`, `in_col_mask` | |
| `o_wide` | `in_data` | **exact** `ACC_W` lanes; `IN_W = ACC_W` |
| `o_ovf`, `o_err` | `in_ovf`, `in_err` | propagated as `out_iovf`, and `out_err_code = UPSTREAM` |
| same `clk`, `rst_n` | | both synchronous, active low |

## 2. Sequencer rules

1. **Parameters before descriptors.** Load a layer's per-channel groups (`p_*`) before the first descriptor
   that uses them. A descriptor snapshots its group, so the next layer's parameters may be written as soon
   as the last descriptor of the current layer has been **accepted**. There is no need to wait for its
   tiles to drain. The integration test does exactly this between layers.
2. **One descriptor per quantised tile.** For every TC04 tile with `cfg_dest` bit 1 (quantiser), send one
   OPEN with `CTX = cfg_slot`, `TAG = cfg_tag`, `M = cfg_m`, `N = cfg_n`, `M0` = the tile's first global
   row, and `CH_GRP` = the tile's N-tile index.
3. **Timing of the descriptor.** It may be sent before, during or after the tile's K chunks; the beats wait
   for it. It must not wait for anything that itself needs the accumulator to drain. In particular, send it
   **before the sequencer blocks on opening another accumulator tile**. While the tile's beats wait at the
   head of TC04's output FIFO, TC04 stops committing (no output credit), committed slots stop freeing, and
   `cfg_ready` can stay low. A descriptor that is never sent therefore stops the pipeline (by design: the
   alternative would be to drop or guess parameters). The integration sequencer sends 30 % of descriptors
   after the tile's chunks, with an extra random delay of up to 60 cycles.
4. **Bias exactly once.** Enable it in TC04 (`cfg_bias_en`, folded into chunk 0) **or** in TC05
   (`FLAGS.BIAS`, from the parameter table), never both. With TC04's `STRICT_RANGE = 1` both placements
   give identical results, because integer addition is associative and nothing saturates before TC05. The
   integration test runs both placements. TC05's bias is the one to use when bias is per-channel data
   loaded once per layer, and also for the INT32-plus-bias output mode on a raw accumulator.
5. **Abort.** After TC04 `HC_ABORT` of a tile whose TC05 descriptor was sent, send TC05 CLOSE (`CTX`,
   `TAG`). Otherwise the context waits for a last beat that will never arrive.
6. **Asymmetric activations** (`ASYM_EN = 1`): load `colsum[n] = Σ_k B[k][n]` with the parameters. It is the
   sum over the **whole** K of the layer, not per chunk, and the correction is applied once at the output.
   Weights must be symmetric (zB = 0).
7. **Raw INT32 results** go to TC04's SRAM / DMA ports (`cfg_dest` bits 0 / 2) and never pass through the
   quantiser. A tile can go to both (`dest = 0b011`). The integration test checks the raw copy against the
   exact GEMM and the quantised copy against the quantised GEMM, for the same tile.

## 3. Host procedure (see `integration/example_layer.py`)

```
for each layer:
    M[n], S[n] = quantize_multiplier(s_in * s_w[n] / s_out)       # real -> integer, host only
    bias[n]    = round(b[n] / (s_in * s_w[n]))
    colsum[n]  = sum_k B[k][n]                                     # if zA != 0
    for g in channel groups:  p_write(grp=g, lanes=g*COLS..g*COLS+COLS-1, fmask=BIAS|MULT|SHIFT|ZP[|CS])
    for each output tile (m0, g):
        slot = next free accumulator slot; tag = new tag
        TC04.cfg(slot, tag, M, N, k_total=K, n_chunks, dest=QUANT[|SRAM])
        TC05.desc(OPEN, ctx=slot, tag, M, N, CH_GRP=g, M0=m0, FLAGS=RQ|PC|BIAS[|RELU], OFMT=INT8, RM=RNE, ZA=zA)
        for each K chunk: launch TC02 with the chunk's k-slices (TC03), sideband {slot, tag, chunk, chunk_k}
```

## 4. Verified integration (reports/regression_summary.md, jobs `I_*`)

Configurations: 4×4 with 2 slots (baseline); 4×4 with ASYM_EN; 4×4 with ACC_W 40 and ASYM_EN; 4×4 with 3
slots; 2×2 with ASYM_EN; 8×8. Layer suites: `baseline`, `layers`, `stress` (generator: `tools/gen_integ.py`).
Each layer is a real quantised GEMM: int8 activations (post-ReLU, zA = −128 when asymmetric), symmetric
per-channel int8 weights, int32 bias, scales converted by `quantize_multiplier`. K ranges from 1 to 520,
split into 1–4 chunks of random size. Tiles are shuffled across slots. Partial tiles in M and N are
included. Each quantised element is compared with `qgemm_direct`, which evaluates `Σ (A − zA)·B` literally.

## 5. Path into the HPC command queue (Module 06): not implemented

Module 06's ABI v1 reserves opcodes outside its classes. Making TC05 a queue client would need:

* a class `0x4X` decode in `hpc_cq_validate` that forwards OPEN / CLOSE descriptors unchanged. TC05 already
  validates them, with its own codes, which would map into the completion record's error field;
* a parameter-load command (DMA from scratchpad into `p_*`, `COLS` lanes per group);
* completion: a TC05 tile is complete when its last beat leaves `out_*`. `out_last` with `out_tag` gives
  the tile identity a completion record needs.

Module 06 is frozen (a new layout needs a new VERSION). None of this is done here.
