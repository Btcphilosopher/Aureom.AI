# Architecture: TENSORCORE 05 output conversion

Primary source: `rtl/tensor_quantize.sv`. Lane arithmetic: `rtl/tensor_quant_lane.sv`. Parameter storage:
`rtl/tensor_quant_params.sv`. Encodings: `rtl/tensor_quantize_pkg.sv`. Integration:
`integration/tensor_core_output.sv`. The arithmetic itself is specified in `NUMERIC_FORMAT.md`.

```
                    p_*  (parameter load: group, lane mask, field mask)
                     |
                     v
              +-------------------+   rd_* (one whole group, combinational)
              | tensor_quant_     |---------------------------------+
              | params            |  NUM_GRP x COLS x {bias, M, S,  |
              +-------------------+  zp, colsum} + valid bits       |
                                                                     v
 desc_* (256 b) --> decode / validate --(OPEN: snapshot, CLOSE)--> contexts [NUM_CTX]
                    desc_ok / desc_rej / code                      {open, poison, tag, M, mask, M0,
                                                                    ch0, fmt, rm, relu, wrap,
                                                                    per lane: bias_eff, M, S, zp}
                                                                     |
 in_* (TC04 oquant)                                                  | lookup by in_ctx (= TC04 slot)
 ---------------> stage A: accept (credit, ctx open), checks, ------+
                  x = acc + bias_eff                    -> R1 (data + this beat's parameters)
                  stage B (per lane): p = x * M         -> R2
                  stage C (per lane): round, + zp, saturate / wrap, ReLU
                                                        -> output FIFO (credit-reserved) --> out_*
```

## 1. Interfaces

| port group | protocol | notes |
|---|---|---|
| `desc_*` | valid/ready, 256-bit ABI v1 (`NUMERIC_FORMAT.md` §8) | `desc_ready` never depends on `desc_valid`. An OPEN for a busy context waits. Every other descriptor is consumed at once. `desc_ok` / `desc_rej` / `desc_rej_code` pulse in the cycle after acceptance |
| `p_*` | valid/ready (`p_ready = 1` outside reset) | one channel group per write; `p_err` / `p_err_code` pulse the cycle after |
| `in_*` | valid/ready; payload = TC04 `oquant` beat | `in_ready` depends on `in_ctx` (a beat waits for its context), which is legal for ready/valid |
| `out_*` | valid/ready from a FIFO | `out_valid` and the payload stay stable until accepted (checked every cycle by the TB) |
| status | `ctx_open`, `ctx_poison`, `idle`, three sticky error vectors | |
| `perf_o` | 13 saturating counters, `perf_clr` | `rtl/tensor_quantize_pkg.sv` `PF_*` |

## 2. Contexts

There are `NUM_CTX` contexts, indexed by the producer's slot (TC04 `o_slot`), so `NUM_CTX = NUM_TILES`.
TC04 commits tiles in **completion** order, and across slots that is not descriptor order. Each beat
therefore finds its parameters by slot and checks the tile tag.

```
            OPEN accepted (clean)           last beat with matching tag, or CLOSE
  FREE  -------------------------->  OPEN  --------------------------------------> FREE
    |       OPEN accepted (rejected by rules 4..14)                                ^
    +-----------------------------> POISONED  --- last beat / CLOSE --------------+
```

* An OPEN for an open context **waits** (`desc_ready = 0`). It is accepted in the cycle after the release.
  An OPEN and a release of the same context cannot happen in the same cycle, so there is no race.
* A beat for a FREE context **waits** (`in_ready = 0`, counted as `PF_CTX_WAIT`). The descriptor may
  therefore arrive late, even after the tile's chunks have been accumulated.
* A wrong-tag beat on an open context is delivered flagged `TAG` and does **not** release it, even with
  `in_last`.
* CLOSE releases an open context whose tag matches. It is used after an upstream abort (TC04 `HC_ABORT`),
  when the tile's last beat will never come.

### The snapshot

When an OPEN is accepted, the descriptor path reads the whole parameter group `CH_GRP` from the table, in
one cycle and combinationally. It forms, for each lane `j < N`:

* `bias_eff = (BIAS ? bias : 0) − zA·colsum`. This is the input-zero-point correction, folded in once per
  tile.
* `M`, `S`, `zp`: from the table (PC) or from the descriptor (per-tensor). In pass-through and bias-only
  modes they are forced to `1`, `0`, `0`. In those modes every rounding mode is the identity, so **one
  datapath implements every mode** and there is no bypass multiplexer.

Lanes `j ≥ N` are zeroed. A poisoned context stores zeros (its beats output zero data).

## 3. Pipeline

| stage | cycle | work | registers |
|---|---|---|---|
| A | t (beat accepted) | context lookup, tag / poison / frame / upstream checks, `x = acc + bias_eff` (exact, XW bits), element index `M0 + row`, copy this beat's M, S, zp, flags | R1 |
| B | t + 1 | `p = x · M` (exact, PW bits), per lane | R2 (in `tensor_quant_lane`) |
| C | t + 2 | `fl = p >>> S`, guard / sticky / lsb, increment by RM, `+ zp`, saturate or wrap, ReLU, flags | output FIFO |
| out | t + 3 | `out_valid` | |

**Latency is 3 cycles** from the accepting clock edge to `out_valid`, measured in every throughput run.

### Flow control: credits, no internal stall

The pipeline **never stalls**. A beat is accepted only if an output-FIFO slot is reserved for it: the
credit counter `crd_q` starts at `OFIFO_DEPTH`, is decremented on accept and incremented on output pop.
`in_ready = run & (crd_q ≠ 0) & ~(context not open)`. Because `crd_q` is registered, `out_ready` has no
combinational path to `in_ready`.

| `OFIFO_DEPTH` | sustained rate (`out_ready` = 1) | measured |
|---|---|---|
| ≥ 4 | **1 beat / cycle** | 480 beats in 480 cycles, zero credit stalls (`T_throughput`, both simulators) |
| 2 | 1 beat / 2 cycles | 958 cycles for 480 beats |
| 1 | 1 beat / 4 cycles | 1917 cycles for 480 beats |

In general the rate is `min(1, DEPTH/4)`: a credit returns 4 cycles after it was taken (3 pipeline cycles
plus the pop). The invariant `crd_q + fifo_count + v1 + v2 = OFIFO_DEPTH` is asserted in simulation every
cycle.

### Why backpressure cannot misassociate parameters

1. Everything a beat needs (M, S, zp, `bias_eff`, format, rounding mode, ReLU, wrap, element index) is
   copied out of its context **in the cycle the beat is accepted**. From then on it travels with the beat
   through R1 → R2 → FIFO.
2. Nothing downstream of stage A reads the context or the table. Stalls, table reloads, context re-opens
   and interleaved tiles therefore cannot reach a beat that is already accepted.
3. The stages never stall, because backpressure is absorbed at the input by credits. There is no partial
   advance in which a data register and its parameter register could be clocked differently.
4. Reloading the table while a tile drains cannot reach that tile: its snapshot was taken when its
   descriptor was accepted.

The tests exercise each point. Random backpressure up to 85 % with 64-cycle stall bursts. The table
rewritten while tiles that use it are in flight. Tiles of different contexts interleaved row by row.
Late descriptors. Every output beat compared field by field (data, flags, tag, element index). Mutant m31
(bias read from the live table at beat time instead of the snapshot) is killed.

## 4. Ordering rules (all tested)

| rule | where |
|---|---|
| A parameter write accepted in cycle t is visible to descriptors accepted in t + 1 or later; a descriptor accepted in the same cycle sees the old contents | `tensor_quant_params.sv`; `SAME` commands in `s4_perchan` |
| An OPEN waits for its context to be free; a beat waits for its context to be open | `desc_ready`, `in_ready` |
| Beats leave in the order they were accepted | FIFO |
| A tile's last beat (matching tag) releases its context, poisoned or not | `b_rel` |

## 5. Reset

`rst_n` is synchronous and active low, like TC02 and TC04. It clears contexts (all FREE), the pipeline
valid bits, the FIFO, the credits, the parameter **valid bits** (data is SRAM-like and is not cleared),
the sticky errors and the counters. The ready outputs are low during reset and for one cycle after it
(`run_q`). The testbench resets at random points during traffic, then checks that every status output is
cleared. It also checks that a descriptor needing the table is rejected `QR_PARAM` until the parameters
are reloaded.

## 6. Parameters

| parameter | default | verified | meaning |
|---|---|---|---|
| `ROWS`, `COLS` | 4, 4 | 1×1, 2×2, 3×5, 4×4, 8×8, 16×16 | tile size (= TC04) |
| `IN_W` | 32 | 32, 40, 48, 64 | accumulator lane width (= TC04 `ACC_W`) |
| `NUM_CTX` | 2 | 1, 2, 3, 4 | contexts (= TC04 `NUM_TILES`); 1 and 3 exercise `NOCTX` |
| `NUM_GRP` | 16 | 1 .. 5 in simulation; 1, 4, 16 synthesised | parameter table depth in channel groups |
| `ASYM_EN` | 0 | 0, 1 | build the input-zero-point correction |
| `OFIFO_DEPTH` | 4 | 1, 2, 4, 8 | output FIFO; ≥ 4 for full rate |
| `PERF_EN`, `PERF_W` | 1, 32 | 32, 6 (saturation) | counters |

## 7. Resource notes (Yosys estimates, `reports/synthesis_summary.md`)

The datapath is `COLS` exact multipliers (XW × 32 bits), `COLS` barrel shifters of PW bits, and the
comparators. The reference parameter table is a flop array (`NUM_GRP·COLS·102` bits, plus colsum with
ASYM_EN). In silicon it would be one SRAM read per descriptor (one wide word per group), and
`tensor_quant_params.sv` is written so it can be swapped: its read is used only on the descriptor path.
The context snapshots are flops (`NUM_CTX·COLS·(CW + 70)` bits). No timing or Fmax is claimed. The
`p >>> S` shift with a 63-bit range and the XW × 32 multiplier are the deep paths. If needed, a second
multiplier stage (as in TC02's `MUL_PIPE`) would be the first change.
