# Numeric-format specification: TENSORCORE 05 output conversion

This document is the arithmetic contract of `rtl/tensor_quantize.sv`. Its executable form is
`model/tq_ref.py`, which produces every expected value in every test. The RTL is checked against it
bit for bit: every value, every saturation flag, every element index.

All quantities are **integers**. No real number exists anywhere in the RTL. A real scale exists only on
the host, which converts it once to the integer pair (M, S) (§3.4).

---

## 1. Inputs, outputs and the output channel

| item | definition |
|---|---|
| input lane `acc` | signed two's complement, `IN_W` bits. This is TC04's exact accumulator `o_wide`, never the narrowed `o_data`. `IN_W` = TC04 `ACC_W`: 32 is the baseline; 40, 48 and 64 are verified |
| input beat | one tile row: `COLS` lanes, `in_col_mask`, `in_row`, `in_last`, `in_tag`, `in_ctx` (= TC04 slot), `in_ovf` (TC04 per-lane overflow), `in_err` (TC04 tile error) |
| output formats | `OFMT_INT32` (code 0): signed 32-bit. `OFMT_INT8` (code 1): signed 8-bit. Codes 2..15 are reserved and rejected |
| output lane | a 32-bit container. An INT8 value is sign-extended in it, and the beat also carries a packed `COLS x 8` view (`out_q8`) |
| **output channel** | the **N (column) dimension** of `C = A x B`, the same axis as TC04's `bias[n]`. Lane `j` of a beat is channel `CH_GRP*COLS + j`. Rows (M) are pixels or batch entries, and every row of a tile uses the same `COLS` channels |
| element index | `out_m = M0 + row` (global row), `out_ch0 = CH_GRP*COLS` (channel of lane 0). Element `(out_m, out_ch0 + j)` is lane `j` |

## 2. Operation order (the contract)

```
Accumulation (TC04) -> Bias and input-zero-point correction -> Requantisation -> Activation -> Output
```

For an active lane `j` (`in_col_mask[j] = 1` and `j < N`):

```
x   = acc + bias[n] - zA * colsum[n]                               (2.1)  exact
y   = R_rm( x * M[n] / 2^S[n] ) + zp[n]      if RQ_EN               (2.2)  one rounding, exact
    = x                                      otherwise
q   = clamp(y, qmin, qmax)                                          (2.3)  saturation
    = y mod 2^32  (two's complement)         if WRAP (INT32 only, explicitly selected)
sat = (y < qmin) or (y > qmax)                                      (2.4)  flagged in both policies
q   = max(q, F)   with F = zp[n] if RQ_EN else 0,   if RELU         (2.5)  activation
```

* `bias[n]` is used only with `FLAGS.BIAS`; otherwise it is 0. `zA * colsum[n]` is used only when `ZA != 0`,
  which needs `ASYM_EN = 1` (§6.3).
* `[qmin, qmax]` is `[-128, 127]` for INT8 and `[-2^31, 2^31 - 1]` for INT32.
* Inactive lanes output 0, with `sat = 0`.
* **Saturation is part of requantisation (2.3), and activation follows it (2.5).** The literal formula is
  `q_out = clamp(round(acc x scale) + zero_point)`, then the activation. The zero-point is required to lie in
  `[qmin, qmax]` (§6.1). Under that condition `max(clamp(y), zp) = clamp(max(y, zp))`, so the *value* is the
  same as applying ReLU before saturation. The `sat` flag reports the requantiser's clamp, which happens
  before the activation. `tests/test_ref_model.py` proves the commutation exhaustively over the INT8 range,
  and it keeps the counterexample (zp = 200) that the zero-point check rules out.

### Modes

| mode | FLAGS | OFMT | result | status |
|---|---|---|---|---|
| INT32 pass-through | – | INT32 | `q = sat32(acc)`, which equals `acc` bit for bit when `IN_W = 32` | **baseline, stage 1** |
| INT32 + bias | `BIAS` | INT32 | `q = sat32(acc + bias[n])` | **baseline, stage 2** |
| INT32 + bias, wrap | `BIAS WRAP` | INT32 | `q = (acc + bias[n]) mod 2^32`, flagged | baseline, stage 2 |
| INT8 requantisation | `RQ` (+`BIAS`) | INT8 | (2.2)–(2.4), per-tensor M, S, zp | **baseline, stage 3** |
| ReLU | `RELU` | any | (2.5) | **baseline, stage 3** |
| per-channel requantisation | `RQ PC` | INT8 / INT32 | M, S, zp taken from the table per channel | stage 4 |
| INT32 requantisation | `RQ` | INT32 | (2.2)–(2.4) into the INT32 range | stage 4 (additional) |
| RTZ, RDN, RUP, RMM rounding | `RQ`, `RM` = 1..4 | any | §3.2 | stage 4 (additional) |
| input zero-point correction | `ZA != 0` | any | (2.1), weights symmetric only | stage 4, `ASYM_EN = 1` |

Each additional mode was enabled only after stages 1–3 passed. Each is verified independently against
the Fraction-based reference (`docs/VERIFICATION.md`).

## 3. Requantisation

### 3.1 Scale representation

| field | width | signedness | range | notes |
|---|---|---|---|---|
| multiplier `M` | 32 | signed | `[-2^31, 2^31 - 1]` | negative scales are permitted; `M = 0` gives `y = zp` |
| shift `S` | 6 | unsigned | `[0, 63]` | right shift only. Scales of 1 or more use `S = 0` with an integer `M` |
| scale | – | – | `M / 2^S` | from `2^-63` (M = 1, S = 63) up to `2^31 - 1` in magnitude |

**Precision.** For `2^-33 <= |scale| < 2^31`, a normalised representation with `|M| >= 2^30` exists. Its
representation error is `|M / 2^S - scale| <= 2^-(S+1)`, which is a relative error of at most `2^-31`.
`quantize_multiplier()` (host side) chooses the largest `S` whose rounded `M` still fits.

### 3.2 Rounding: one rounding of the exact rational

`R_rm(p / 2^S)` rounds the exact rational number `v = p / 2^S`, where `p = x * M` is the exact product, to
an integer. **There is exactly one rounding in the whole conversion.** Modes use the Module 02 / RISC-V
`frm` encoding:

| RM | name | definition (v not an integer) | at an exact tie `v = k + 1/2` |
|---|---|---|---|
| 0 | **RNE** (baseline) | nearest integer | the even one of `k`, `k + 1` |
| 1 | RTZ | toward zero (`trunc`) | `k` if `v > 0`, `k + 1` if `v < 0` |
| 2 | RDN | toward −∞ (`floor`) | `k` |
| 3 | RUP | toward +∞ (`ceil`) | `k + 1` |
| 4 | RMM | nearest integer | away from zero |
| 5..7 | – | rejected (`QR_RM`) | |

For `S = 0`, `v` is an integer and every mode returns it unchanged.

| v | RNE | RTZ | RDN | RUP | RMM |
|---|---|---|---|---|---|
| 2.5 | 2 | 2 | 2 | 3 | 3 |
| 3.5 | 4 | 3 | 3 | 4 | 4 |
| −2.5 | −2 | −2 | −3 | −2 | −3 |
| −3.5 | −4 | −3 | −4 | −3 | −4 |
| 0.75 | 1 | 0 | 0 | 1 | 1 |
| −0.25 | 0 | 0 | −1 | 0 | 0 |

**Hardware algorithm** (`rtl/tensor_quant_lane.sv`). `fl = p >>> S` is `floor(v)`. The discarded bits give
`g` (bit S−1, the ½ position), `st` (the OR of bits S−2..0), `neg` (the sign of p) and `lsb = fl[0]`. The
result is `fl + inc`, where `inc` is:

| RNE | RTZ | RDN | RUP | RMM |
|---|---|---|---|---|
| `g & (st \| lsb)` | `neg & (g \| st)` | `0` | `g \| st` | `g & (st \| ~neg)` |

`tests/test_ref_model.py` checks this table against the definitions above two ways:

* exhaustively for |p| ≤ 2^11 and S ≤ 10 (three independent implementations: Fraction, integer divmod,
  the bit algorithm);
* at random over 200 000 cases at full width (products up to 105 bits, S up to 63, 40 % forced onto ties and
  ties ± 1).

**Not TFLite-identical.** TFLite's `MultiplyByQuantizedMultiplier` rounds **twice** (a doubling high
multiply, then a rounding shift, both ties away from zero). This contract rounds once. Results can differ
by 1 LSB on rare inputs. A TFLite-compatible double-rounding mode would be a separate, separately verified
mode. It is not implemented (`docs/ROADMAP.md`).

### 3.3 Saturation (overflow) policy

* **Default: saturate.** `q = clamp(y)`. `out_sat[j] = 1` whenever `y` was outside the output range.
* **WRAP** (INT32 output only, `FLAGS.WRAP`, explicitly selected): `q = y mod 2^32`. `out_sat[j]` is still
  set. WRAP with INT8 is rejected (`QR_FLAGS`).
* **Bias overflow** is handled by this same rule. The INT32 sum `acc + bias` is formed exactly (33+ bits)
  and then saturated or wrapped. In requantising modes the *exact* sum, not a saturated one, feeds the
  multiplier, so a value is never saturated twice.
* **Upstream inexactness** (TC04 `o_ovf`, possible only with `STRICT_RANGE = 0` or a host preload in TC04)
  is passed through untouched as `out_iovf`. This module never sets or clears it.

### 3.4 Host conversion of a real scale (software, not RTL)

`model/tq_ref.py: quantize_multiplier(scale)` returns `(M, S)` with `S` as large as possible (most precise).
For a layer with input scale `s_in`, per-channel weight scales `s_w[n]` and output scale `s_out`:
`M[n], S[n] = quantize_multiplier(s_in * s_w[n] / s_out)`, and
`bias_int32[n] = round(bias_real[n] / (s_in * s_w[n]))`. `integration/example_layer.py` shows the full
procedure.

## 4. Examples (all verified as model spot checks or TB vectors)

| acc | bias | M | S | zp | mode | y | q | sat |
|---|---|---|---|---|---|---|---|---|
| 12345 | – | – | – | – | INT32 pass | 12345 | 12345 | 0 |
| 2^31 − 1 | 1 | – | – | – | INT32+bias | 2^31 | 2^31 − 1 | 1 |
| 2^31 − 1 | 1 | – | – | – | INT32+bias WRAP | 2^31 | −2^31 | 1 |
| 777 | – | 0 | 5 | −3 | INT8 RNE | −3 | −3 | 0 (zero multiplier) |
| 5 | – | 1 | 1 | 0 | INT8 RNE | 2 (2.5, tie to even) | 2 | 0 |
| −5 | – | 1 | 1 | 0 | INT8 RMM | −3 | −3 | 0 |
| −2^31 | – | −2^31 | 63 | 0 | INT8 RNE | 0 (exactly 0.5 → even) | 0 | 0 (maximum shift) |
| 1000 | – | 1 | 0 | 0 | INT8 | 1000 | 127 | 1 |
| −1000 | – | 1 | 0 | −10 | INT8 RELU | −1010 | max(−128, −10) = −10 | 1 |
| 1 | – | −2^31 | 31 | 0 | INT8 RNE | −1 | −1 | 0 (negative scale) |

## 5. Intermediate widths: no intermediate overflow

| quantity | width | bound used |
|---|---|---|
| `bias_eff = bias − zA·colsum` | `CW = 32` (ASYM_EN = 0), `IN_W + 8` (ASYM_EN = 1) | `|zA·colsum| ≤ 2^7 · 2^(IN_W−1) = 2^(IN_W+6)`, `|bias| ≤ 2^31` |
| `x = acc + bias_eff` | `XW = IN_W + 1` (ASYM_EN = 0), `IN_W + 8` (ASYM_EN = 1) | `|x| ≤ 2^(IN_W−1) + 2^31 ≤ 2^IN_W`; ASYM: `< 2^(IN_W+7)` (IN_W ≥ 32) |
| `p = x · M` | `PW = XW + 32` | `|p| ≤ 2^(XW−1) · 2^31 = 2^(XW+30)` |
| `r = R(p / 2^S)` | `PW` | `r = p` (S = 0) or `|r| ≤ |p|/2 + 1` (S ≥ 1) |
| `y = r + zp` | `YW = PW + 1` | `|zp| ≤ 2^31` |

| IN_W | ASYM_EN | CW | XW | PW | YW | multiplier |
|---|---|---|---|---|---|---|
| 32 | 0 | 32 | 33 | 65 | 66 | 33 × 32 |
| 32 | 1 | 40 | 40 | 72 | 73 | 40 × 32 |
| 40 | 1 | 48 | 48 | 80 | 81 | 48 × 32 |
| 48 | 0 | 32 | 49 | 81 | 82 | 49 × 32 |
| 64 | 1 | 72 | 72 | 104 | 105 | 72 × 32 |

These bounds are **checked, not assumed**. `tests/test_ref_model.py: test_widths` enumerates every corner
of the input box for IN_W 32/40/48/64 × ASYM_EN 0/1: acc, bias, zA, colsum, M and zp at their extremes,
S ∈ {0, 1, 2, 63}, all five rounding modes. Every intermediate is shown to fit. Each map is bilinear or
monotone, so the corners bound the whole box. The same test shows XW and PW are tight to within one bit.
`tools/check_abi.py` checks that the RTL package's width functions equal the model's for IN_W 32..64.
The only bit that is never needed is the top bit of PW. It matters only for the single product
`(−2^(XW−1))·(−2^31)`, and then only through `neg`, which that product's zero fraction never consults
(mutant m11, `docs/VERIFICATION.md`).

## 6. Zero-points

### 6.1 Output zero-point `zp`

* Signed 32-bit field. It is applied only with `RQ_EN`. It is added **after** the rounding and **before**
  saturation (2.2).
* It must lie in `[qmin, qmax]` of the output format: per-tensor `QR_ZP`, per-channel `QR_PZP`. This keeps
  the ReLU floor representable and makes saturation and activation commute (§2).
* Without `RQ_EN` there is no zero-point: the field must be 0 (`QR_RSVD`), and the ReLU floor is 0.
* **ReLU in the quantised domain clamps at the zero-point.** The real value is
  `r = s_out · (q − zp)`, so `r ≥ 0 ⇔ q ≥ zp`. Clamping at 0 would be wrong whenever `zp ≠ 0` (mutant m21
  tests exactly this bug).

### 6.2 Per-channel versus per-tensor

With `PC`, M, S and zp come from the parameter table, per channel. Without it they come from the
descriptor and are the same for all channels. Bias is always per channel (table) when `BIAS` is set.

### 6.3 Input (activation / weight) zero-points: what is and is not supported

The MAC array (TC02) multiplies symmetric signed INT8 operands. It computes `P = Σ_k A[m][k]·B[k][n]` on
the stored integer values. The exact asymmetric accumulation is

```
Σ_k (A − zA)(B − zB) = Σ AB − zA·Σ_k B[k][n] − zB·Σ_k A[m][k] + K·zA·zB
```

| case | status | why |
|---|---|---|
| **zA ≠ 0, zB = 0** (asymmetric activations, symmetric weights: the common int8 deployment) | **supported with `ASYM_EN = 1`** | The only extra term is `−zA·colsum[n]`, with `colsum[n] = Σ_k B[k][n]`. It is a property of the weights, loaded with the parameters (field `FMB_CS`). It is folded into `bias_eff` once per tile when the descriptor opens and added once per element, after TC04 has finished all K chunks. So it is applied **exactly once**, never per chunk. The widths in §5 cover it. A descriptor with `ZA ≠ 0` is rejected (`QR_PARAM`) unless every active lane's column sum is loaded |
| zB ≠ 0 | **unsupported, rejected** (`QR_UNSUP`) | This term needs `Σ_k A[m][k]` per row. The array does not produce row sums of A, and neither TC03 nor TC04 does. The `ZB` descriptor field exists only so this case is rejected explicitly |
| `K·zA·zB` | unsupported | Only arises with zB ≠ 0 |
| zA ≠ 0 with `ASYM_EN = 0` | rejected (`QR_UNSUP`) | The correction hardware is not built |

**The output zero-point is not input asymmetry.** `zp` (§6.1) shifts the result only. Supporting it says
nothing about input zero-points.

**What the hardware cannot check.** Column sums are software-provided. The quantiser never sees B, so it
cannot verify that `colsum[n]` matches the weights. The tests compute column sums independently from B. The
integration test checks the end-to-end identity on the real array: TC02 computes `Σ AB` on the raw stored
values, TC04 accumulates it, and TC05 applies the correction. The result is compared with
`Σ (A − zA)·B` evaluated literally by `qgemm_direct`, which never uses the identity.

**Range.** TC04's `STRICT_RANGE` check bounds the raw products, which are still INT8 × INT8. The corrected
value `Σ(A − zA)B` can be up to about twice as large. It is held exactly in XW bits here, and only the
final conversion saturates.

## 7. Per-channel parameter storage

| item | definition |
|---|---|
| organisation | `NUM_GRP` channel **groups** × `COLS` lanes. Group `g`, lane `j` is channel `g·COLS + j` |
| per lane | `bias` s32, `mult` s32, `shift` u6, `zp` s32, `colsum` s`IN_W` (ASYM_EN only), plus one **valid bit per field** |
| write | `p_*` port: one group, any lanes (`p_lane_mask`), any fields (`p_fmask`). The write is applied whole or not at all. `p_grp ≥ NUM_GRP` → `PW_GRP`; a column-sum write with `ASYM_EN = 0` → `PW_UNSUP` |
| read | When a descriptor is accepted, the whole group `CH_GRP` is copied into the context: the **snapshot** |
| ordering | A write accepted in cycle t is visible to descriptors accepted in **t + 1 or later**. A descriptor accepted in the same cycle t reads the old contents (tested directly: `SAME` commands) |
| association | A tile uses its snapshot for all its rows. Rewriting the table while the tile drains cannot affect it |
| reset | Valid bits cleared, data untouched. A descriptor that needs a field whose valid bit is clear is rejected (`QR_PARAM`) |

## 8. ABI

### 8.1 Descriptor (256 bits = 8 × 32-bit words, word *w* = bits `[32w+31:32w]`)

The conventions follow HPC Module 06's command ABI: a version field, the RM encoding, reserved-must-be-zero
fields, and first-failing-rule validation. The opcodes take the unused class `0x4X` (tensor output
conversion). Folding them into Module 06's queue is described in `docs/INTEGRATION.md`; it is not
implemented.

| word | bits | field | meaning |
|---|---|---|---|
| 0 | [7:0] | OPCODE | `0x40` OPEN, `0x41` CLOSE |
| | [11:8] | VERSION | must be 1 |
| | [14:12] | RM | rounding mode (§3.2); must be 0 without RQ |
| | [15] | – | reserved, 0 |
| | [23:16] | FLAGS | bit 0 BIAS, 1 RQ, 2 PC, 3 RELU, 4 WRAP; bits 5–7 reserved |
| | [27:24] | OFMT | 0 INT32, 1 INT8 |
| | [31:28] | – | reserved, 0 |
| 1 | [15:0] | TAG | tile tag (= TC04 `cfg_tag`) |
| | [23:16] | CTX | context (= TC04 `cfg_slot`) |
| | [31:24] | – | reserved, 0 |
| 2 | [7:0] | M | tile rows, 1..ROWS |
| | [15:8] | N | tile columns (channels), 1..COLS |
| | [31:16] | CH_GRP | channel group: lane j is channel CH_GRP·COLS + j |
| 3 | [31:0] | M0 | global row index of tile row 0 (M0 + M − 1 ≤ 2^32 − 1) |
| 4 | [31:0] | MULT | per-tensor multiplier (signed); 0 unless RQ and not PC |
| 5 | [5:0] | SHIFT | per-tensor shift; 0 unless RQ and not PC |
| | [7:6] | – | reserved, 0 |
| | [15:8] | ZA | input (activation) zero-point, signed; ≠ 0 needs ASYM_EN |
| | [23:16] | ZB | weight zero-point: **must be 0** (unsupported, §6.3) |
| | [31:24] | – | reserved, 0 |
| 6 | [31:0] | ZP | per-tensor output zero-point (signed); 0 unless RQ and not PC |
| 7 | [31:0] | – | reserved, 0 |

CLOSE uses only OPCODE, VERSION, TAG and CTX. Every other field must be 0.

### 8.2 Validation (first failing rule wins; `desc_rej_code`)

| # | rule | code | effect |
|---|---|---|---|
| 1 | VERSION ≠ 1 | 1 `QR_VERSION` | consumed, nothing opened |
| 2 | OPCODE ∉ {0x40, 0x41} | 2 `QR_OPCODE` | consumed, nothing opened |
| 3 | CTX ≥ NUM_CTX | 3 `QR_CTX` | consumed, nothing opened |
| C1 | CLOSE: any other field ≠ 0 | 4 `QR_RSVD` | nothing closed |
| C2 | CLOSE: context not open, or TAG differs | 5 `QR_STATE` | nothing closed |
| 4 | reserved bit set | 4 `QR_RSVD` | context opened **POISONED** |
| 5 | OFMT ∉ {0, 1} | 6 `QR_FMT` | poisoned |
| 6 | RM ∈ {5, 6, 7} | 7 `QR_RM` | poisoned |
| 7 | PC without RQ, or WRAP without INT32 | 8 `QR_FLAGS` | poisoned |
| 8 | a field unused by the mode ≠ 0 (RM / MULT / SHIFT / ZP without RQ; MULT / SHIFT / ZP with PC) | 4 `QR_RSVD` | poisoned |
| 9 | ZB ≠ 0, or ZA ≠ 0 with ASYM_EN = 0 | 9 `QR_UNSUP` | poisoned |
| 10 | M ∉ [1, ROWS], N ∉ [1, COLS], or M0 + M − 1 > 2^32 − 1 | 10 `QR_DIM` | poisoned |
| 11 | per-tensor ZP outside the output range | 11 `QR_ZP` | poisoned |
| 12 | table used (BIAS, PC or ZA ≠ 0) and CH_GRP ≥ NUM_GRP | 12 `QR_CHAN` | poisoned |
| 13 | a needed field not loaded for some lane j < N | 13 `QR_PARAM` | poisoned |
| 14 | PC and some per-channel zp (j < N) outside the output range | 14 `QR_PZP` | poisoned |

An OPEN that passes rules 1–3 always opens its context, either clean or POISONED. The beats of a poisoned
tile are delivered with zero data and `out_err_code = POISON`, and the tile's last beat frees the context.
A bad descriptor therefore never deadlocks the accumulator upstream. Rules 1–3 cannot be trusted to name a
context, so nothing opens. A beat for such a context waits, and the sticky error records the reject.

### 8.3 Beat error codes (`out_err_code`, priority order)

| code | condition | data / index fields |
|---|---|---|
| 0 `NONE` | – | computed |
| 1 `NOCTX` | `in_ctx ≥ NUM_CTX` (possible only when NUM_CTX is not a power of two) | zero |
| 2 `TAG` | context open with a different tag (stale or misrouted beat); does **not** release the context | zero |
| 3 `POISON` | context opened by a rejected descriptor | zero |
| 4 `FRAME` | `row ≥ M`, `col_mask ≠ tile mask`, or `last ≠ (row == M − 1)` | computed, flagged |
| 5 `UPSTREAM` | `in_err` set by TC04 | computed, flagged |

A beat for a context that is in range but not open **waits** (`in_ready = 0`) until its descriptor arrives.
No beat is ever dropped, so the element stream stays aligned with the producer.

### 8.4 Output beat

`out_tag`, `out_ctx`, `out_row`, `out_m`, `out_ch0`, `out_col_mask` (= `in_col_mask`), `out_last`,
`out_fmt`, `out_data[COLS×32]`, `out_q8[COLS×8]`, `out_sat[COLS]`, `out_iovf[COLS]` (= `in_ovf &
in_col_mask`), `out_err`, `out_err_code`. Beats leave in the order they were accepted.

## 9. Not supported (stated, not silently approximated)

Floating-point outputs (BF16, FP16, FP32, FP8), INT4, UINT8 output, weight zero-points (zB ≠ 0), channels on
the M axis, left shifts (S < 0; S = 0 with an integer M already covers scales ≥ 1), TFLite double-rounding
compatibility, and sparse formats. See `docs/ROADMAP.md`.
