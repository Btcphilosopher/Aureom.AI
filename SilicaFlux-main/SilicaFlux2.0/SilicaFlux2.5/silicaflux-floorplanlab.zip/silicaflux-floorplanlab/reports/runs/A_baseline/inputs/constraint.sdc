# SilicaFlux-V (sfv_soc_df) functional-mode timing constraints for FloorplanLab.
# Derived from third_party/silicaflux-v/asic/constraints/sfv_soc.sdc (release 1);
# sfv_soc_df has the identical port list.  The period is substituted by
# FloorplanLab (20); ORFS reads "set clk_period" for ABC.
# NOTE: clocks are IDEAL until CTS -- every timing number before CTS is a
# pre-route, pre-CTS estimate.
set clk_period 20
create_clock -name clk -period $clk_period [get_ports clk]
create_clock -name tck -period 100 [get_ports tck]
# JTAG and system clocks are asynchronous; crossings use sfv_sync two-flop
# synchronisers / toggle handshakes (silicaflux-v docs/CLOCK_RESET.md).
set_clock_groups -asynchronous -group {clk} -group {tck}
set_clock_uncertainty 0.25 [get_clocks clk]
set_clock_transition 0.15 [get_clocks clk]
# I/O budgets: 30 % of the period outside the core (pads + board), as release 1
set io_in [expr 0.3 * $clk_period]
set_input_delay  $io_in -clock clk [get_ports {uart_rx spi_miso gpio_i*}]
set_output_delay $io_in -clock clk [get_ports {uart_tx spi_sck spi_mosi spi_cs0_n gpio_o* gpio_oe* test_pass test_fail test_status* cpu_sleep}]
set_input_delay  20.0 -clock tck [get_ports {tms tdi}]
set_output_delay 20.0 -clock tck [get_ports {tdo tdo_oe}]
# reset and test-mode pins are asynchronous / static in functional mode
set_false_path -from [get_ports rst_ni]
set_false_path -from [get_ports test_mode]
set_load 0.02 [all_outputs]
set_input_transition 0.2 [all_inputs]
