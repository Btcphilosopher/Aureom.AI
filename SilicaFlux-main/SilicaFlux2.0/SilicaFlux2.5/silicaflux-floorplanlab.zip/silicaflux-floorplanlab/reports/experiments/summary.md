# SilicaFlux-V floorplan experiments -- measured results

All numbers are read from Yosys / OpenROAD / OpenSTA outputs of the runs listed (see `reports/runs/<id>/run.json`
for per-run provenance: git revision, tool versions, ORFS revision, netlist hash, config hash).
Timing is **PRE-ROUTE** (placement parasitics, ideal clocks, typical corner) -- not an achieved frequency.
Global routing is **PRELIMINARY** (FastRoute, pre-CTS). Power is a **vectorless estimate** and is not ranked.

Baseline for deltas: `A_baseline`.  Comparable = same netlist hash, tools, ORFS revision and clock period.

## Runs and status

| run_id | status | physically_valid | grt_overflow_free | arrangement | target_util | failed_gates | failure_reason |
|---|---|---|---|---|---|---|---|
| A_baseline | completed | True | False | auto (macro_placement) | 0.500 |  | n/a |
| B_core_area_plus | completed | True | False | auto (macro_placement) | 0.350 |  | n/a |
| C_sram_near_compute | completed | True | False | tspm_center_2x2 | 0.500 |  | n/a |
| D_logic_consolidated | completed | True | False | top_cluster | 0.500 |  | n/a |
| E_pdn_corridors | completed | True | False | periphery_rows | 0.500 |  | n/a |
| L_periphery_rows | completed | True | False | periphery_rows | 0.500 |  | n/a |
| L_west_east_columns | completed | True | False | west_east_columns | 0.500 |  | n/a |
| R_00 | completed | True | False | top_cluster | 0.424 |  | n/a |
| R_01 | completed | True | False | periphery_rows | 0.529 |  | n/a |
| R_02 | completed | True | False | top_cluster | 0.579 |  | n/a |
| SA_00 | failed | False | n/a | tspm_center_2x2 | 0.650 | 10 | ORFS placement failed |
| SA_01 | completed | True | False | tspm_center_2x2 | 0.644 |  | n/a |
| S_sky130_baseline | completed_with_gate_failures | False | n/a | auto (macro_placement) | 0.500 | 6 | n/a |
| U_00 | completed | True | True | auto (macro_placement) | 0.300 |  | n/a |
| U_01 | completed | True | False | auto (macro_placement) | 0.400 |  | n/a |
| U_02 | completed | True | False | auto (macro_placement) | 0.600 |  | n/a |
| U_03 | failed | False | n/a | auto (macro_placement) | 0.700 | 5 | ORFS floorplan stage failed |

`physically_valid` = gates 2-11 pass (legal placement, connected PDN, completed STA); it does **not** mean
routable: `grt_overflow_free` says whether the preliminary global route ended with zero overflow.

## Area

| run_id | die_w_um | die_h_um | die_area_mm2 | core_area_mm2 | std_cell_area_placed_um2 | macro_area_um2 | std_cell_util_of_rows | core_util_incl_macros |
|---|---|---|---|---|---|---|---|---|
| A_baseline | 2819.040 | 2823.660 | 7.960 | 7.505 | 1107780.100 | 4533478.500 | 0.385 | 0.752 |
| B_core_area_plus | 2996.160 | 3001.320 | 8.992 | 8.508 | 1110752.100 | 4533478.500 | 0.287 | 0.663 |
| C_sram_near_compute | 3494.880 | 2279.340 | 7.966 | 7.498 | 1108952.200 | 4533478.500 | 0.388 | 0.752 |
| D_logic_consolidated | 3494.880 | 2279.340 | 7.966 | 7.498 | 1109618.100 | 4533478.500 | 0.388 | 0.753 |
| E_pdn_corridors | 3518.880 | 2362.500 | 8.313 | 7.837 | 1108703.600 | 4533478.500 | 0.347 | 0.720 |
| L_periphery_rows | 3494.880 | 2279.340 | 7.966 | 7.498 | 1108841.500 | 4533478.500 | 0.388 | 0.752 |
| L_west_east_columns | 3497.760 | 2967.300 | 10.379 | 9.855 | 1109966.500 | 4533478.500 | 0.213 | 0.573 |
| R_00 | 3494.880 | 2404.080 | 8.402 | 7.924 | 1111853.400 | 4533478.500 | 0.339 | 0.712 |
| R_01 | 3494.880 | 2241.540 | 7.834 | 7.369 | 1109095.500 | 4533478.500 | 0.407 | 0.766 |
| R_02 | 3494.880 | 2188.620 | 7.649 | 7.189 | 1109217.100 | 4533478.500 | 0.435 | 0.785 |
| SA_00 | 3494.880 | 2124.360 | 7.424 | 6.969 | n/a | 4533478.500 | n/a | n/a |
| SA_01 | 3494.880 | 2128.140 | 7.438 | 6.982 | 1109859.400 | 4533478.500 | 0.474 | 0.808 |
| S_sky130_baseline | 5513.560 | 5518.880 | 30.429 | 29.738 | n/a | 25995936.900 | n/a | n/a |
| U_00 | 3090.240 | 3095.820 | 9.567 | 9.067 | 1110675.900 | 4533478.500 | 0.250 | 0.623 |
| U_01 | 2923.680 | 2929.500 | 8.565 | 8.092 | 1110975.300 | 4533478.500 | 0.321 | 0.698 |
| U_02 | 2747.040 | 2751.840 | 7.559 | 7.116 | 1111229.300 | 4533478.500 | 0.447 | 0.793 |
| U_03 | 2694.240 | 2698.920 | 7.272 | 6.837 | n/a | n/a | n/a | n/a |

## Performance (pre-route) and routability (preliminary)

| run_id | wns_ns | tns_ns | whs_ns | reg2reg_slack_ns | reg2reg_delay_ns | placed_hpwl_mm | inter_group_hpwl_mm | grt_completed | grt_overflow | grt_hotspot_near_macro_frac | grt_wirelength_mm | grt_wns_ns |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A_baseline | 10.049 | 0.000 | -0.345 | 10.865 | 9.135 | 6791.960 | 5095.820 | 1.000 | 2339.000 | 0.995 | 9356.920 | 1.123 |
| B_core_area_plus | 9.877 | 0.000 | -0.373 | 10.332 | 9.668 | 7734.310 | 6431.230 | 1.000 | 18847.000 | 1.000 | 12358.350 | -8.635 |
| C_sram_near_compute | 9.740 | 0.000 | -0.320 | 10.489 | 9.511 | 6872.470 | 5160.930 | 1.000 | 3329.000 | 1.000 | 9500.820 | 2.725 |
| D_logic_consolidated | 9.971 | 0.000 | -0.390 | 10.902 | 9.098 | 7051.030 | 5159.030 | 1.000 | 11956.000 | 1.000 | 10476.300 | 1.678 |
| E_pdn_corridors | 9.915 | 0.000 | -0.395 | 10.940 | 9.060 | 6711.640 | 5053.040 | 1.000 | 9277.000 | 1.000 | 9336.660 | 3.216 |
| L_periphery_rows | 9.971 | 0.000 | -0.321 | 10.850 | 9.150 | 6834.780 | 5154.110 | 1.000 | 22543.000 | 1.000 | 10383.440 | 1.909 |
| L_west_east_columns | 9.812 | 0.000 | -0.295 | 10.837 | 9.163 | 7266.950 | 5082.720 | 1.000 | 50466.000 | 1.000 | 12098.020 | -7.254 |
| R_00 | 9.905 | 0.000 | -0.401 | 10.552 | 9.448 | 8886.120 | 6342.570 | 1.000 | 3509.000 | 1.000 | 10856.580 | 2.893 |
| R_01 | 9.964 | 0.000 | -0.313 | 10.753 | 9.247 | 6799.790 | 5189.030 | 1.000 | 24975.000 | 1.000 | 10372.390 | 2.337 |
| R_02 | 9.850 | 0.000 | -0.402 | 10.765 | 9.235 | 7091.020 | 5133.710 | 1.000 | 23696.000 | 1.000 | 11066.230 | 1.786 |
| SA_00 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| SA_01 | 10.098 | 0.000 | -0.380 | 10.750 | 9.250 | 7616.650 | 5337.220 | 1.000 | 61093.000 | 0.978 | 14740.040 | -6.119 |
| S_sky130_baseline | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| U_00 | 10.102 | 0.000 | -0.345 | 10.881 | 9.119 | 7541.480 | 5926.610 | 1.000 | 0.000 | n/a | 10064.260 | -3.868 |
| U_01 | 10.150 | 0.000 | -0.302 | 10.606 | 9.394 | 7591.510 | 6049.280 | 1.000 | 21124.000 | 0.998 | 12628.340 | -7.423 |
| U_02 | 10.032 | 0.000 | -0.344 | 10.063 | 9.937 | 8140.590 | 6681.650 | 1.000 | 86833.000 | 0.999 | 15649.570 | -7.197 |
| U_03 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

Worst register-to-register path per run (pre-route):

| run_id | reg2reg_start | reg2reg_end | reg2reg_slack_ns |
|---|---|---|---|
| A_baseline | u_cpu/_23040_ (rising edge-triggered fli | u_tile/u_te/u_mac/_34924_ | 10.865 |
| B_core_area_plus | u_cpu/_23040_ (rising edge-triggered fli | u_tile/u_te/u_mac/_35133_ | 10.332 |
| C_sram_near_compute | u_cpu/_23048_ (rising edge-triggered fli | u_cpu/_22700_ (rising edge-triggered fli | 10.489 |
| D_logic_consolidated | u_cpu/_23040_ (rising edge-triggered fli | u_tile/u_te/u_mac/_35074_ | 10.902 |
| E_pdn_corridors | u_tile/g_bank[3].u_ram/u_macro/g_m[0].ge | u_tile/u_te/u_mac/_35133_ | 10.940 |
| L_periphery_rows | u_cpu/_21829_ (rising edge-triggered fli | u_tile/u_te/u_mac/_35074_ | 10.850 |
| L_west_east_columns | u_tile/g_bank[1].u_ram/u_macro/g_m[0].ge | u_tile/u_ve/_64100_ (rising edge-trigger | 10.837 |
| R_00 | u_cpu/_21829_ (rising edge-triggered fli | u_tile/u_te/u_mac/_34927_ | 10.552 |
| R_01 | u_tile/g_bank[3].u_ram/u_macro/g_m[0].ge | u_tile/u_te/u_mac/_35133_ | 10.753 |
| R_02 | u_cpu/_23040_ (rising edge-triggered fli | u_cpu/_22718_ (rising edge-triggered fli | 10.765 |
| SA_00 |  |  | n/a |
| SA_01 | u_tile/g_bank[2].u_ram/u_macro/g_m[0].ge | u_tile/u_te/u_mac/_35133_ | 10.750 |
| S_sky130_baseline |  |  | n/a |
| U_00 | u_cpu/_23040_ (rising edge-triggered fli | u_cpu/_22699_ (rising edge-triggered fli | 10.881 |
| U_01 | u_tile/g_bank[0].u_ram/u_macro/g_m[0].ge | u_tile/u_te/u_mac/_35133_ | 10.606 |
| U_02 | u_cpu/_21829_ (rising edge-triggered fli | u_tile/u_te/u_mac/_35074_ | 10.063 |
| U_03 |  |  | n/a |

## Power (information only)

| run_id | pdn_connected | power_vectorless_mw |
|---|---|---|
| A_baseline | True | 8.340 |
| B_core_area_plus | True | 8.340 |
| C_sram_near_compute | True | 8.340 |
| D_logic_consolidated | True | 8.340 |
| E_pdn_corridors | True | 8.340 |
| L_periphery_rows | True | 8.340 |
| L_west_east_columns | True | 8.340 |
| R_00 | True | 8.350 |
| R_01 | True | 8.340 |
| R_02 | True | 8.340 |
| SA_00 | True | n/a |
| SA_01 | True | 8.350 |
| S_sky130_baseline | False | n/a |
| U_00 | True | 8.340 |
| U_01 | True | 8.340 |
| U_02 | True | 8.340 |
| U_03 | False | n/a |

Power = OpenSTA `report_power` with **no switching-activity file** (input activity 0.1); IHP SRAM
Liberty power data are included as provided by the macro library; clock tree not built. Not used for ranking.

## Quality gates

| run_id | gate1 | gate2 | gate3 | gate4 | gate5 | gate6 | gate7 | gate8 | gate9 | gate10 | gate11 | gate12 | gate13 | gate14 | gate15 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A_baseline | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| B_core_area_plus | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| C_sram_near_compute | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| D_logic_consolidated | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| E_pdn_corridors | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| L_periphery_rows | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| L_west_east_columns | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| R_00 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| R_01 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| R_02 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| SA_00 | PASS | PASS | PASS | PASS | PASS | PASS | NOT_RUN | PASS | PASS | FAIL | NOT_RUN | NOT_RUN | NOT_RUN | PASS | PASS |
| SA_01 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| S_sky130_baseline | PASS | PASS | PASS | PASS | PASS | FAIL | NOT_RUN | PASS | NOT_RUN | NOT_RUN | NOT_RUN | NOT_RUN | NOT_RUN | PASS | PASS |
| U_00 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| U_01 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| U_02 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| U_03 | PASS | PASS | PASS | PASS | FAIL | NOT_RUN | NOT_RUN | NOT_RUN | NOT_RUN | NOT_RUN | NOT_RUN | NOT_RUN | NOT_RUN | PASS | PASS |

## Deltas vs baseline (%)

| run_id | d_die_area_mm2_pct | d_core_area_mm2_pct | d_std_cell_area_placed_um2_pct | d_placed_hpwl_mm_pct | d_wns_ns_pct | d_reg2reg_delay_ns_pct | d_grt_overflow_pct | d_grt_wirelength_mm_pct | d_grt_wns_ns_pct | d_inter_group_hpwl_mm_pct |
|---|---|---|---|---|---|---|---|---|---|---|
| A_baseline | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| B_core_area_plus | 12.97 | 13.37 | 0.27 | 13.87 | -1.71 | 5.83 | 705.77 | 32.08 | -868.54 | 26.21 |
| C_sram_near_compute | 0.08 | -0.08 | 0.11 | 1.19 | -3.08 | 4.12 | 42.33 | 1.54 | 142.54 | 1.28 |
| D_logic_consolidated | 0.08 | -0.08 | 0.17 | 3.81 | -0.78 | -0.41 | 411.16 | 11.96 | 49.35 | 1.24 |
| E_pdn_corridors | 4.44 | 4.43 | 0.08 | -1.18 | -1.33 | -0.82 | 296.62 | -0.22 | 186.29 | -0.84 |
| L_periphery_rows | 0.08 | -0.08 | 0.10 | 0.63 | -0.77 | 0.16 | 863.79 | 10.97 | 69.88 | 1.14 |
| L_west_east_columns | 30.39 | 31.33 | 0.20 | 6.99 | -2.36 | 0.31 | 2057.59 | 29.29 | -745.70 | -0.26 |
| R_00 | 5.55 | 5.59 | 0.37 | 30.83 | -1.43 | 3.43 | 50.02 | 16.03 | 157.53 | 24.47 |
| R_01 | -1.58 | -1.80 | 0.12 | 0.12 | -0.85 | 1.23 | 967.76 | 10.85 | 108.03 | 1.83 |
| R_02 | -3.91 | -4.21 | 0.13 | 4.40 | -1.98 | 1.09 | 913.08 | 18.27 | 58.92 | 0.74 |
| SA_00 | -6.73 | -7.13 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| SA_01 | -6.56 | -6.96 | 0.19 | 12.14 | 0.48 | 1.26 | 2511.93 | 57.53 | -644.65 | 4.74 |
| S_sky130_baseline | 282.27 | 296.26 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |
| U_00 | 20.19 | 20.82 | 0.26 | 11.04 | 0.53 | -0.18 | -100.00 | 7.56 | -444.25 | 16.30 |
| U_01 | 7.60 | 7.83 | 0.29 | 11.77 | 1.01 | 2.84 | 803.12 | 34.96 | -760.73 | 18.71 |
| U_02 | -5.03 | -5.18 | 0.31 | 19.86 | -0.17 | 8.78 | 3612.40 | 67.25 | -740.55 | 31.12 |
| U_03 | -8.65 | -8.90 | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a |

## Annealing proposer vs measured results

Surrogate evaluations: 160. The surrogate (optimiser.py) only proposes candidates;
the rows below are the measured outcomes of the proposed runs (SA_*) next to comparable manual runs.

| run_id | arrangement | target_util | die_area_mm2 | reg2reg_delay_ns | grt_overflow | grt_wirelength_mm | physically_valid |
|---|---|---|---|---|---|---|---|
| C_sram_near_compute | tspm_center_2x2 | 0.500 | 7.966 | 9.511 | 3329.000 | 9500.820 | True |
| D_logic_consolidated | top_cluster | 0.500 | 7.966 | 9.098 | 11956.000 | 10476.300 | True |
| L_periphery_rows | periphery_rows | 0.500 | 7.966 | 9.150 | 22543.000 | 10383.440 | True |
| L_west_east_columns | west_east_columns | 0.500 | 10.379 | 9.163 | 50466.000 | 12098.020 | True |
| SA_00 | tspm_center_2x2 | 0.650 | 7.424 | n/a | n/a | n/a | False |
| SA_01 | tspm_center_2x2 | 0.644 | 7.438 | 9.250 | 61093.000 | 14740.040 | True |

## Pareto analysis

Rule: only physically valid, comparable runs with a completed global route are ranked; Pareto over die area (min), WNS with global-route parasitics (max), GRT overflow (min), GRT wirelength (min).

Eligible runs: A_baseline, B_core_area_plus, C_sram_near_compute, D_logic_consolidated, E_pdn_corridors, L_periphery_rows, L_west_east_columns, R_00, R_01, R_02, SA_01, U_00, U_01, U_02

Non-dominated (Pareto) set: **A_baseline, C_sram_near_compute, E_pdn_corridors, R_00, R_01, R_02, SA_01, U_00**

Invalid / failed runs (kept, never ranked):

- `SA_00`: failed -- gates failed: 10; ORFS placement failed
- `S_sky130_baseline`: completed_with_gate_failures -- gates failed: 6; 
- `U_03`: failed -- gates failed: 5; ORFS floorplan stage failed
