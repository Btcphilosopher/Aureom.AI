# =============================================================================
#  synth.tcl
#  SilicaFlux SoC :: Quartus Prime build automation
#  Target  : Terasic DE10-Nano / Intel Cyclone V SoC 5CSEBA6U23I7
#  Flow    : project creation -> Analysis & Synthesis -> Fitter -> Timing
#            Analyzer (with optional seed sweep) -> Assembler -> RBF/POF
#  Tool    : Quartus Prime Standard / Lite Edition (Cyclone V is not supported
#            by Quartus Prime Pro Edition)
#
#  Usage   : quartus_sh -t synth.tcl [key=value ...]
#            quartus_sh -t synth.tcl help
#  Every key may also be provided as an environment variable SF_<KEY>.
#  Precedence: built-in default < environment < command line.
#
#  Exit codes
#    0  build succeeded, timing met
#    1  unexpected internal error
#    2  environment / configuration / source preflight failure
#    3  Analysis & Synthesis failure
#    4  Fitter failure
#    5  Assembler / programming-file failure
#    6  Timing Analyzer failure
#    7  build completed but timing closure missed (enforce_timing=1)
# =============================================================================

package require ::quartus::project
package require ::quartus::flow
catch {package require ::quartus::device}

namespace eval ::sf {
    variable VERSION     "1.0.0"
    variable script_path [info script]
    variable cfg
    variable stages      {}
    variable skipped     {}
    variable warnings    {}
    variable artifacts   {}
    variable util        {}
    variable timing      {}
    variable seed_log    {}
    variable logch       ""
    variable logbuf      {}
    variable sources     {}
    variable ports       {}
    variable final_seed  ""
}

# -----------------------------------------------------------------------------
#  Logging
# -----------------------------------------------------------------------------

proc ::sf::log {level msg} {
    variable logch
    variable logbuf
    variable warnings
    set stamp [clock format [clock seconds] -format "%H:%M:%S"]
    foreach l [split $msg "\n"] {
        set line [format "\[SF\]\[%s\]\[%-5s\] %s" $stamp $level $l]
        puts stdout $line
        if {$logch ne ""} {
            puts $logch $line
            flush $logch
        } else {
            lappend logbuf $line
        }
    }
    if {$level eq "WARN"} {
        lappend warnings $msg
    }
}

proc ::sf::banner {title} {
    log INFO [string repeat "=" 72]
    log INFO "STAGE: $title"
    log INFO [string repeat "=" 72]
}

proc ::sf::open_log {file} {
    variable logch
    variable logbuf
    set logch [open $file w]
    fconfigure $logch -translation lf
    foreach line $logbuf {
        puts $logch $line
    }
    flush $logch
    set logbuf {}
}

proc ::sf::close_log {} {
    variable logch
    if {$logch ne ""} {
        catch {close $logch}
        set logch ""
    }
}

# -----------------------------------------------------------------------------
#  Configuration
# -----------------------------------------------------------------------------

proc ::sf::set_defaults {} {
    variable cfg
    variable script_path
    if {$script_path eq ""} {
        set root [pwd]
    } else {
        set root [file dirname [file normalize $script_path]]
    }
    array unset cfg
    array set cfg [list \
        root           $root \
        project        silicaflux_de10 \
        revision       "" \
        top            silicaflux_top \
        family         "Cyclone V" \
        device         5CSEBA6U23I7 \
        build_dir      [file join $root build] \
        rtl_dirs       {} \
        extra_sources  "" \
        sdc            "" \
        pin_file       "" \
        profile        fpga \
        params         {} \
        defines        {} \
        clk_port       clk_core_i \
        clk_period     10.000 \
        mem_period     10.000 \
        host_period    20.000 \
        rtc_period     1000.000 \
        jtag_period    100.000 \
        seeds          {1} \
        jobs           4 \
        enforce_timing 1 \
        virtual_pins   1 \
        stage_sources  1 \
        allow_missing  0 \
        gen_rbf        1 \
        gen_pof        0 \
        pof_device     EPCQ256 \
    ]
}

proc ::sf::cfg_types {} {
    return [dict create \
        bool   {enforce_timing virtual_pins stage_sources allow_missing gen_rbf gen_pof} \
        number {clk_period mem_period host_period rtc_period jtag_period} \
        int    {jobs} \
        list   {rtl_dirs seeds params defines} \
    ]
}

proc ::sf::usage {} {
    puts "SilicaFlux Quartus build automation (synth.tcl)"
    puts ""
    puts "  quartus_sh -t synth.tcl \[key=value ...\]"
    puts ""
    puts "  project=NAME         Quartus project / revision name (silicaflux_de10)"
    puts "  top=ENTITY           top-level entity (silicaflux_top)"
    puts "  device=PART          FPGA part (5CSEBA6U23I7)"
    puts "  build_dir=DIR        clean build directory (<script dir>/build)"
    puts "  rtl_dirs=A;B         RTL search directories, ';' or ',' separated"
    puts "                       (then <script dir>/rtl, /src and the script dir)"
    puts "  extra_sources=FILE   text file, one additional source path per line"
    puts "  sdc=FILE             external SDC (default: silicaflux.sdc if present,"
    puts "                       otherwise a generated 100 MHz constraint set)"
    puts "  pin_file=FILE        Tcl file with set_location_assignment calls"
    puts "                       (default: silicaflux_pins.tcl if present)"
    puts "  profile=fpga|native  fpga = scaled parameter set sized for Cyclone V,"
    puts "                       native = RTL default parameters"
    puts "  params=N=V;N=V       extra top-level parameter overrides"
    puts "  defines=A=1;B        extra Verilog macros"
    puts "  clk_port=PORT        primary clock port (clk_core_i)"
    puts "  clk_period=NS        primary clock period (10.000 = 100 MHz)"
    puts "  seeds=1,2,3          fitter seeds tried in order until timing is met"
    puts "  jobs=N               parallel processors (4)"
    puts "  enforce_timing=0|1   exit 7 when timing is not met (1)"
    puts "  virtual_pins=0|1     map every non-clock top port to a virtual pin (1)"
    puts "  stage_sources=0|1    stage .sf sources as .sv copies in the build tree (1)"
    puts "  allow_missing=0|1    continue when a listed source is not found (0)"
    puts "  gen_rbf=0|1          produce HPS-compatible .rbf (1)"
    puts "  gen_pof=0|1          produce .pof for an external config flash (0)"
    puts "  pof_device=DEV       configuration device for .pof (EPCQ256)"
}

proc ::sf::to_bool {key val} {
    if {![string is boolean -strict $val]} {
        puts stderr "\[SF\]\[ERROR\] option '$key' expects a boolean, got '$val'"
        exit 2
    }
    return [expr {$val ? 1 : 0}]
}

proc ::sf::split_list {val} {
    set out {}
    foreach item [split $val ";, \t"] {
        if {$item ne ""} {
            lappend out $item
        }
    }
    return $out
}

proc ::sf::apply_option {key val origin} {
    variable cfg
    if {![info exists cfg($key)]} {
        puts stderr "\[SF\]\[ERROR\] unknown option '$key' ($origin). Run with 'help' for the option list."
        exit 2
    }
    set types [cfg_types]
    if {[lsearch -exact [dict get $types bool] $key] >= 0} {
        set val [to_bool $key $val]
    } elseif {[lsearch -exact [dict get $types number] $key] >= 0} {
        if {![string is double -strict $val] || $val <= 0} {
            puts stderr "\[SF\]\[ERROR\] option '$key' expects a positive number, got '$val' ($origin)"
            exit 2
        }
        set val [format %.3f $val]
    } elseif {[lsearch -exact [dict get $types int] $key] >= 0} {
        if {![string is integer -strict $val] || $val < 1} {
            puts stderr "\[SF\]\[ERROR\] option '$key' expects a positive integer, got '$val' ($origin)"
            exit 2
        }
    } elseif {[lsearch -exact [dict get $types list] $key] >= 0} {
        set val [split_list $val]
    }
    set cfg($key) $val
}

proc ::sf::load_config {} {
    variable cfg
    set_defaults
    foreach key [lsort [array names cfg]] {
        set envname "SF_[string toupper $key]"
        if {[info exists ::env($envname)] && $::env($envname) ne ""} {
            apply_option $key $::env($envname) "environment $envname"
        }
    }
    if {[info exists ::quartus(args)]} {
        set argv_list $::quartus(args)
    } elseif {[info exists ::argv]} {
        set argv_list $::argv
    } else {
        set argv_list {}
    }
    foreach arg $argv_list {
        if {$arg in {help -h --help}} {
            usage
            exit 0
        }
        set arg [string trimleft $arg "-"]
        set eq [string first "=" $arg]
        if {$eq < 1} {
            puts stderr "\[SF\]\[ERROR\] malformed argument '$arg' (expected key=value)"
            exit 2
        }
        set key [string map {- _} [string tolower [string range $arg 0 [expr {$eq - 1}]]]]
        apply_option $key [string range $arg [expr {$eq + 1}] end] "command line"
    }
    if {$cfg(revision) eq ""} {
        set cfg(revision) $cfg(project)
    }
    set cfg(root)      [file normalize $cfg(root)]
    set cfg(build_dir) [file normalize $cfg(build_dir)]
    if {$cfg(profile) ni {fpga native}} {
        puts stderr "\[SF\]\[ERROR\] profile must be 'fpga' or 'native', got '$cfg(profile)'"
        exit 2
    }
    if {[llength $cfg(seeds)] == 0} {
        set cfg(seeds) {1}
    }
    foreach s $cfg(seeds) {
        if {![string is integer -strict $s]} {
            puts stderr "\[SF\]\[ERROR\] seeds must be integers, got '$s'"
            exit 2
        }
    }
}

# -----------------------------------------------------------------------------
#  Failure handling and summaries
# -----------------------------------------------------------------------------

proc ::sf::keep_failure_reports {} {
    variable cfg
    set src  [file join $cfg(build_dir) output_files]
    set dest [file join $cfg(build_dir) artifacts reports]
    if {![file isdirectory $src] || ![file isdirectory $dest]} {
        return
    }
    foreach pat {*.rpt *.summary *.smsg} {
        foreach f [glob -nocomplain -directory $src $pat] {
            file copy -force $f $dest
        }
    }
}

proc ::sf::die {code msg} {
    log ERROR $msg
    log ERROR "BUILD FAILED (exit code $code)"
    catch {keep_failure_reports}
    catch {write_summary FAILED $code $msg}
    catch {project_close}
    close_log
    exit $code
}

proc ::sf::fmt_dur {sec} {
    return [format "%02d:%02d:%02d" [expr {$sec / 3600}] [expr {($sec % 3600) / 60}] [expr {$sec % 60}]]
}

proc ::sf::summary_lines {result code msg} {
    variable cfg
    variable stages
    variable skipped
    variable warnings
    variable artifacts
    variable util
    variable timing
    variable seed_log
    variable final_seed
    variable sources
    set ver  [expr {[info exists ::quartus(version)] ? $::quartus(version) : "unknown"}]
    set ed   [expr {[info exists ::quartus(edition)] ? $::quartus(edition) : "unknown"}]
    set L {}
    lappend L "SilicaFlux build summary"
    lappend L [string repeat "=" 72]
    lappend L "Result          : $result (exit code $code)"
    if {$msg ne ""} {
        lappend L "Detail          : $msg"
    }
    lappend L "Project         : $cfg(project) (revision $cfg(revision))"
    lappend L "Top-level       : $cfg(top)"
    lappend L "Device          : $cfg(family) $cfg(device)"
    lappend L "Quartus         : $ver ($ed)"
    lappend L "Parameter set   : $cfg(profile)"
    lappend L "Target clock    : $cfg(clk_port) @ $cfg(clk_period) ns"
    lappend L "Sources         : [llength $sources] files"
    lappend L ""
    lappend L "Stages"
    lappend L [string repeat "-" 72]
    foreach s $stages {
        lassign $s name status dur
        lappend L [format "  %-44s %-8s %s" $name $status [fmt_dur $dur]]
    }
    if {[llength $seed_log] > 1} {
        lappend L ""
        lappend L "Seed sweep (final seed: $final_seed)"
        lappend L [string repeat "-" 72]
        foreach r $seed_log {
            lassign $r seed wns met
            lappend L [format "  seed %-6s worst slack %-10s %s" $seed $wns [expr {$met == 1 ? "MET" : ($met == 0 ? "VIOLATED" : "UNKNOWN")}]]
        }
    }
    if {[llength $util]} {
        lappend L ""
        lappend L "Utilization (post-fit)"
        lappend L [string repeat "-" 72]
        foreach {k v} $util {
            lappend L [format "  %-34s %s" $k $v]
        }
    }
    if {[llength $timing]} {
        lappend L ""
        lappend L "Timing"
        lappend L [string repeat "-" 72]
        foreach {k v} $timing {
            lappend L [format "  %-34s %s" $k $v]
        }
    }
    if {[llength $artifacts]} {
        lappend L ""
        lappend L "Artifacts"
        lappend L [string repeat "-" 72]
        foreach a $artifacts {
            lappend L "  $a"
        }
    }
    if {[llength $skipped]} {
        lappend L ""
        lappend L "Optional assignments not accepted by this Quartus installation"
        lappend L [string repeat "-" 72]
        foreach s $skipped {
            lassign $s name value err
            lappend L "  $name = $value"
        }
    }
    lappend L ""
    lappend L "Warnings logged by this script: [llength $warnings]"
    return $L
}

proc ::sf::write_summary {result code msg} {
    variable cfg
    set dir [file join $cfg(build_dir) artifacts reports]
    if {![file isdirectory $dir]} {
        return
    }
    set fd [open [file join $dir build_summary.txt] w]
    fconfigure $fd -translation lf
    foreach l [summary_lines $result $code $msg] {
        puts $fd $l
    }
    close $fd
}

# -----------------------------------------------------------------------------
#  Assignment helpers
# -----------------------------------------------------------------------------

proc ::sf::assign {name value} {
    if {[catch {set_global_assignment -name $name $value} err]} {
        die 2 "required assignment $name = $value was rejected: $err"
    }
}

proc ::sf::assign_opt {name value} {
    variable skipped
    if {[catch {set_global_assignment -name $name $value} err]} {
        lappend skipped [list $name $value $err]
        log WARN "optional assignment skipped: $name = $value ($err)"
        return 0
    }
    return 1
}

proc ::sf::commit_assignments {} {
    export_assignments
}

# -----------------------------------------------------------------------------
#  Tool / device preflight
# -----------------------------------------------------------------------------

proc ::sf::check_tool {} {
    variable cfg
    set ver [expr {[info exists ::quartus(version)] ? $::quartus(version) : "unknown"}]
    set ed  [expr {[info exists ::quartus(edition)] ? $::quartus(edition) : "unknown"}]
    log INFO "Quartus version : $ver"
    log INFO "Quartus edition : $ed"
    if {[string match -nocase "*pro*" $ed]} {
        die 2 "Quartus Prime Pro Edition does not support $cfg(family). Use Quartus Prime Standard or Lite Edition."
    }
    if {[catch {get_part_list -family $cfg(family)} parts]} {
        log WARN "device support list unavailable ($parts); skipping device installation check"
        return
    }
    if {[lsearch -exact $parts $cfg(device)] < 0} {
        die 2 "device $cfg(device) is not available in this Quartus installation (Cyclone V device support not installed?)"
    }
    log INFO "Device support  : $cfg(device) present"
}

# -----------------------------------------------------------------------------
#  RTL source discovery
# -----------------------------------------------------------------------------

# Compile-order seed list. Packages are re-ordered by dependency analysis below,
# so this list only needs to be hierarchically sensible. sf_frontend_pkg.sf is
# the package imported by fetch_unit.sf and is listed explicitly for that reason.
proc ::sf::source_manifest {} {
    return {
        silicaflux_pkg.sf
        sf_frontend_pkg.sf
        decoder.sf
        fetch_unit.sf
        alu.sf
        forwarding_unit.sf
        register_bank.sf
        control_core.sf
        vector_engine.sf
        tensor_unit.sf
        memory_controller.sf
        scheduler.sf
        compute_tile.sf
        noc_interconnect.sf
        tile_interface.sf
        silicaflux_top.sf
    }
}

proc ::sf::search_dirs {} {
    variable cfg
    set dirs {}
    foreach d $cfg(rtl_dirs) {
        lappend dirs [file normalize $d]
    }
    foreach d [list [file join $cfg(root) rtl] [file join $cfg(root) src] $cfg(root)] {
        lappend dirs [file normalize $d]
    }
    set out {}
    foreach d $dirs {
        if {[file isdirectory $d] && [lsearch -exact $out $d] < 0} {
            lappend out $d
        }
    }
    return $out
}

proc ::sf::read_extra_sources {dirs} {
    variable cfg
    set list_file $cfg(extra_sources)
    if {$list_file eq ""} {
        set cand [file join $cfg(root) silicaflux_extra_sources.f]
        if {[file isfile $cand]} {
            set list_file $cand
        } else {
            return {}
        }
    }
    if {![file isfile $list_file]} {
        die 2 "extra_sources file not found: $list_file"
    }
    set base [file dirname [file normalize $list_file]]
    set fd [open $list_file r]
    set data [read $fd]
    close $fd
    set out {}
    foreach line [split $data "\n"] {
        set line [string trim $line]
        if {$line eq "" || [string index $line 0] eq "#"} {
            continue
        }
        set found ""
        foreach d [linsert $dirs 0 $base] {
            set p [file join $d $line]
            if {[file isfile $p]} {
                set found [file normalize $p]
                break
            }
        }
        if {$found eq ""} {
            die 2 "extra source '$line' listed in $list_file was not found"
        }
        lappend out $found
    }
    return $out
}

proc ::sf::slurp {file} {
    set fd [open $file r]
    set data [read $fd]
    close $fd
    return $data
}

proc ::sf::strip_comments {txt} {
    regsub -all {/\*.*?\*/} $txt { } txt
    regsub -all {//[^\n]*} $txt {} txt
    return $txt
}

proc ::sf::scan_packages {file} {
    set txt [strip_comments [slurp $file]]
    set defs {}
    foreach {all name} [regexp -all -inline {\mpackage\s+(?:automatic\s+|static\s+)?([A-Za-z_][A-Za-z0-9_$]*)\s*;} $txt] {
        if {[lsearch -exact $defs $name] < 0} {
            lappend defs $name
        }
    }
    set uses {}
    foreach {all name} [regexp -all -inline {\m([A-Za-z_][A-Za-z0-9_$]*)\s*::} $txt] {
        if {[lsearch -exact $uses $name] < 0} {
            lappend uses $name
        }
    }
    return [list $defs $uses]
}

# Stable dependency ordering: a file that defines a package precedes every file
# that references that package; otherwise the listed order is preserved.
proc ::sf::order_by_packages {files} {
    set pkgfile [dict create]
    set uses    [dict create]
    foreach f $files {
        lassign [scan_packages $f] d u
        foreach p $d {
            if {[dict exists $pkgfile $p] && [dict get $pkgfile $p] ne $f} {
                die 2 "package '$p' is defined in more than one source:\n  [dict get $pkgfile $p]\n  $f"
            }
            dict set pkgfile $p $f
        }
        dict set uses $f $u
    }
    foreach f $files {
        foreach p [dict get $uses $f] {
            if {![dict exists $pkgfile $p] && [string match "*_pkg" $p]} {
                if {[::sf::cfg_get allow_missing]} {
                    log WARN "package '$p' used by [file tail $f] is not defined by any listed source"
                } else {
                    die 2 "package '$p' used by [file tail $f] is not defined by any listed source.\nAdd the defining file to silicaflux_extra_sources.f (or set allow_missing=1)."
                }
            }
        }
    }
    set done {}
    set remaining $files
    while {[llength $remaining]} {
        set picked ""
        foreach f $remaining {
            set ready 1
            foreach p [dict get $uses $f] {
                if {[dict exists $pkgfile $p]} {
                    set g [dict get $pkgfile $p]
                    if {$g ne $f && [lsearch -exact $done $g] < 0} {
                        set ready 0
                        break
                    }
                }
            }
            if {$ready} {
                set picked $f
                break
            }
        }
        if {$picked eq ""} {
            die 2 "circular package dependency among:\n  [join $remaining "\n  "]"
        }
        lappend done $picked
        set idx [lsearch -exact $remaining $picked]
        set remaining [lreplace $remaining $idx $idx]
    }
    return $done
}

proc ::sf::cfg_get {key} {
    variable cfg
    return $cfg($key)
}

proc ::sf::resolve_sources {} {
    variable cfg
    variable sources
    set dirs [search_dirs]
    if {![llength $dirs]} {
        die 2 "no RTL search directory exists (looked under $cfg(root); set rtl_dirs=...)"
    }
    log INFO "RTL search path :"
    foreach d $dirs {
        log INFO "    $d"
    }
    set found {}
    set missing {}
    foreach name [source_manifest] {
        set hit ""
        foreach d $dirs {
            set p [file join $d $name]
            if {[file isfile $p]} {
                set hit [file normalize $p]
                break
            }
        }
        if {$hit eq ""} {
            lappend missing $name
        } else {
            lappend found $hit
        }
    }
    if {[llength $missing]} {
        set text "RTL sources not found in the search path:\n    [join $missing "\n    "]"
        if {$cfg(allow_missing)} {
            log WARN $text
        } else {
            die 2 "$text\nProvide them in one of the search directories, via rtl_dirs=..., or set allow_missing=1."
        }
    }
    set top_name "$cfg(top).sf"
    set top_file ""
    set ordered {}
    foreach f $found {
        if {[file tail $f] eq $top_name} {
            set top_file $f
        } else {
            lappend ordered $f
        }
    }
    if {$top_file eq ""} {
        die 2 "top-level source $top_name was not found; cannot continue"
    }
    foreach f [read_extra_sources $dirs] {
        if {[lsearch -exact $ordered $f] < 0 && $f ne $top_file} {
            lappend ordered $f
        }
    }
    lappend ordered $top_file
    set sources [order_by_packages $ordered]
    set cfg(top_file) $top_file
    log INFO "Compile order   :"
    set i 0
    foreach f $sources {
        incr i
        log INFO [format "    %2d  %s" $i $f]
    }
}

# -----------------------------------------------------------------------------
#  Top-level port discovery (used for virtual-pin mapping and clock checks)
# -----------------------------------------------------------------------------

proc ::sf::match_paren {txt open_idx} {
    set depth 0
    set n [string length $txt]
    for {set i $open_idx} {$i < $n} {incr i} {
        set c [string index $txt $i]
        if {$c eq "("} {
            incr depth
        } elseif {$c eq ")"} {
            incr depth -1
            if {$depth == 0} {
                return $i
            }
        }
    }
    return -1
}

proc ::sf::split_top_commas {txt} {
    set parts {}
    set depth 0
    set cur ""
    foreach c [split $txt ""] {
        if {$c in {( [ \{}} {
            incr depth
        } elseif {$c in {) ] \}}} {
            incr depth -1
        }
        if {$c eq "," && $depth == 0} {
            lappend parts $cur
            set cur ""
        } else {
            append cur $c
        }
    }
    if {[string trim $cur] ne ""} {
        lappend parts $cur
    }
    return $parts
}

# Returns a list of {name is_bus} pairs, or {} when the header cannot be parsed.
proc ::sf::parse_ports {file top} {
    set txt [strip_comments [slurp $file]]
    if {![regexp -indices [format {\mmodule\s+%s\M} $top] $txt m]} {
        return {}
    }
    set i [expr {[lindex $m 1] + 1}]
    set n [string length $txt]
    while {1} {
        while {$i < $n && [string is space [string index $txt $i]]} {
            incr i
        }
        if {[string range $txt $i [expr {$i + 5}]] eq "import" } {
            set semi [string first ";" $txt $i]
            if {$semi < 0} {
                return {}
            }
            set i [expr {$semi + 1}]
            continue
        }
        break
    }
    if {[string index $txt $i] eq "#"} {
        incr i
        while {$i < $n && [string is space [string index $txt $i]]} {
            incr i
        }
        if {[string index $txt $i] ne "("} {
            return {}
        }
        set close [match_paren $txt $i]
        if {$close < 0} {
            return {}
        }
        set i [expr {$close + 1}]
        while {$i < $n && [string is space [string index $txt $i]]} {
            incr i
        }
    }
    if {[string index $txt $i] ne "("} {
        return {}
    }
    set close [match_paren $txt $i]
    if {$close < 0} {
        return {}
    }
    set body [string range $txt [expr {$i + 1}] [expr {$close - 1}]]
    set result {}
    set inherit_bus 0
    foreach piece [split_top_commas $body] {
        set piece [string trim $piece]
        regsub {(\s*\[[^\]]*\])+\s*$} $piece {} piece
        if {![regexp {([A-Za-z_][A-Za-z0-9_$]*)\s*$} $piece -> name]} {
            continue
        }
        set rest $piece
        set stripped 0
        if {[regsub {^(input|output|inout|ref)\s+} $rest {} rest]} {
            set stripped 1
        }
        while {[regsub {^(var|wire|logic|bit|reg|signed|unsigned)\s+} $rest {} rest]} {
            set stripped 1
        }
        set rest [string trim $rest]
        if {$rest eq $name} {
            set is_bus [expr {$stripped ? 0 : $inherit_bus}]
        } else {
            set is_bus 1
        }
        set inherit_bus $is_bus
        lappend result [list $name $is_bus]
    }
    return $result
}

proc ::sf::clock_port_names {} {
    variable cfg
    set names [list $cfg(clk_port)]
    foreach n {clk_mem_i clk_host_i clk_rtc_i jtag_tck_i} {
        if {[lsearch -exact $names $n] < 0} {
            lappend names $n
        }
    }
    return $names
}

proc ::sf::discover_ports {} {
    variable cfg
    variable ports
    set ports [parse_ports $cfg(top_file) $cfg(top)]
    if {![llength $ports]} {
        if {$cfg(virtual_pins) && $cfg(pin_file) eq ""} {
            die 2 "could not parse the port list of $cfg(top) from $cfg(top_file); virtual-pin mapping needs it.\nSupply pin_file=... or set virtual_pins=0."
        }
        log WARN "could not parse the port list of $cfg(top); primary clock presence not verified"
        return
    }
    set names {}
    foreach p $ports {
        lappend names [lindex $p 0]
    }
    log INFO "Top-level ports : [llength $ports] parsed from $cfg(top)"
    if {[lsearch -exact $names $cfg(clk_port)] < 0} {
        die 2 "primary clock port '$cfg(clk_port)' does not exist on $cfg(top) (ports: [join $names {, }])"
    }
}

# -----------------------------------------------------------------------------
#  Build directory
# -----------------------------------------------------------------------------

proc ::sf::prepare_build_dir {} {
    variable cfg
    variable sources
    set b $cfg(build_dir)
    if {$b eq "/" || $b eq $cfg(root) || [string first "$b/" "$cfg(root)/"] == 0} {
        die 2 "refusing to clean build_dir '$b' (it is, or contains, the script directory)"
    }
    foreach f $sources {
        if {[string first "$b/" $f] == 0} {
            die 2 "refusing to clean build_dir '$b': it contains RTL source $f"
        }
    }
    foreach aux [list $cfg(sdc) $cfg(pin_file) $cfg(extra_sources)] {
        if {$aux ne "" && [string first "$b/" [file normalize $aux]] == 0} {
            die 2 "refusing to clean build_dir '$b': it contains the input file $aux"
        }
    }
    if {[file exists $b]} {
        log INFO "cleaning previous build tree: $b"
        file delete -force $b
    }
    file mkdir $b
    file mkdir [file join $b artifacts reports]
    file mkdir [file join $b output_files]
    open_log [file join $b silicaflux_build.log]
    cd $b
    log INFO "build directory : $b"
}

proc ::sf::digest {file} {
    if {![catch {package require md5}]} {
        if {![catch {::md5::md5 -hex -file $file} h]} {
            return $h
        }
    }
    foreach tool {sha256sum md5sum} {
        if {![catch {exec $tool $file} out]} {
            return "$tool:[lindex $out 0]"
        }
    }
    return "size=[file size $file]"
}

# Quartus selects the HDL front end from the assignment type (SYSTEMVERILOG_FILE),
# but staging the Silica Flux-2017 (.sf) sources as .sv copies keeps every
# downstream tool and message independent of the non-standard extension and
# records an exact, reproducible source manifest.
proc ::sf::stage_sources {} {
    variable cfg
    variable sources
    variable staged
    set staged {}
    if {!$cfg(stage_sources)} {
        foreach f $sources {
            lappend staged $f
        }
        log INFO "source staging disabled; referencing sources in place"
        return
    }
    file mkdir rtl_stage
    set manifest [open [file join artifacts reports source_manifest.txt] w]
    puts $manifest "# order  staged-file  size  digest  original-path"
    set used [dict create]
    set i 0
    foreach f $sources {
        incr i
        set base [file rootname [file tail $f]]
        set dest "$base.sv"
        set k 1
        while {[dict exists $used $dest]} {
            incr k
            set dest "${base}_$k.sv"
        }
        dict set used $dest 1
        file copy -force $f [file join rtl_stage $dest]
        lappend staged "rtl_stage/$dest"
        puts $manifest [format "%2d  rtl_stage/%s  %d  %s  %s" $i $dest [file size $f] [digest $f] $f]
    }
    close $manifest
    log INFO "staged [llength $staged] sources into [file join $cfg(build_dir) rtl_stage]"
}

# -----------------------------------------------------------------------------
#  Parameter profile
# -----------------------------------------------------------------------------

# The RTL default configuration (multiple complexes, 8 LLC banks of 4 MB each,
# 2 MB L2 per complex) is orders of magnitude larger than the roughly 5.5 Mb of
# M10K and 41.9k ALMs on a 5CSEBA6U23I7. The fpga profile scales capacity and
# array-dimension parameters only; sequencing / timeout parameters are left at
# the RTL defaults. Anything here can be overridden with params=NAME=VALUE.
proc ::sf::profile_parameters {} {
    variable cfg
    if {$cfg(profile) eq "native"} {
        return [dict create]
    }
    return [dict create \
        NUM_CPLX              1 \
        CORES_PER_CPLX        1 \
        NUM_LLC_BANKS         2 \
        NUM_MEM_PORTS         1 \
        NUM_DMA_PORTS         1 \
        NUM_COH_DOMAINS       1 \
        NUM_EXT_IRQ           32 \
        EN_TRACE              0 \
        EN_ECC                0 \
        EN_DBG_SBA            0 \
        L2_SIZE_KB            64 \
        L2_WAYS               4 \
        LLC_BANK_SIZE_KB      64 \
        LLC_WAYS              4 \
        SNOOP_FILTER_ENTRIES  2048 \
        TLB_L2_ENTRIES        128 \
        NUM_PTW               1 \
        TRACE_FIFO_DEPTH      64 \
    ]
}

proc ::sf::apply_parameters {} {
    variable cfg
    set pd [profile_parameters]
    foreach kv $cfg(params) {
        set eq [string first "=" $kv]
        if {$eq < 1} {
            die 2 "malformed params entry '$kv' (expected NAME=VALUE)"
        }
        dict set pd [string range $kv 0 [expr {$eq - 1}]] [string range $kv [expr {$eq + 1}] end]
    }
    if {![dict size $pd]} {
        log INFO "no top-level parameter overrides (profile=$cfg(profile))"
        return
    }
    foreach name [lsort -dictionary [dict keys $pd]] {
        set value [dict get $pd $name]
        if {[catch {set_parameter -name $name $value} err]} {
            die 2 "set_parameter $name = $value failed: $err"
        }
        log INFO [format "parameter       : %-22s = %s" $name $value]
    }
}

# -----------------------------------------------------------------------------
#  Project creation and global settings
# -----------------------------------------------------------------------------

proc ::sf::create_project {} {
    variable cfg
    banner "Project creation"
    if {[catch {project_new -overwrite -revision $cfg(revision) $cfg(project)} err]} {
        die 2 "project_new failed: $err"
    }
    assign FAMILY $cfg(family)
    assign DEVICE $cfg(device)
    assign TOP_LEVEL_ENTITY $cfg(top)
    assign PROJECT_OUTPUT_DIRECTORY output_files
    assign_opt MIN_CORE_JUNCTION_TEMP -40
    assign_opt MAX_CORE_JUNCTION_TEMP 100
    assign_opt STRATIX_DEVICE_IO_STANDARD "3.3-V LVTTL"
    assign_opt RESERVE_ALL_UNUSED_PINS_WEAK_PULLUP "AS INPUT TRI-STATED WITH WEAK PULL-UP"
    log INFO "project $cfg(project) created for $cfg(family) $cfg(device), top-level $cfg(top)"
}

proc ::sf::apply_synthesis_settings {} {
    variable cfg
    banner "Synthesis and fitter settings"
    # HDL front end: Silica Flux-2017 sources are SystemVerilog-compatible and are
    # compiled through the SystemVerilog front end.
    assign VERILOG_INPUT_VERSION SYSTEMVERILOG_2005
    assign_opt VERILOG_SHOW_LMF_MAPPING_MESSAGES OFF
    assign_opt SEARCH_PATH [expr {$cfg(stage_sources) ? "rtl_stage" : "."}]
    foreach d $cfg(defines) {
        assign VERILOG_MACRO $d
    }

    # Balanced area / fmax synthesis.
    assign_opt OPTIMIZATION_MODE BALANCED
    assign_opt OPTIMIZATION_TECHNIQUE BALANCED
    assign_opt SYNTH_TIMING_DRIVEN_SYNTHESIS ON
    assign_opt STATE_MACHINE_PROCESSING AUTO

    # DSP block inference (tensor_unit MAC arrays, vector_engine lanes).
    assign_opt AUTO_DSP_RECOGNITION ON
    assign_opt DSP_BLOCK_BALANCING AUTO
    assign_opt AUTO_SHIFT_REGISTER_RECOGNITION AUTO

    # Block RAM inference (memory_controller scratchpad, cache arrays, FIFOs).
    assign_opt AUTO_RAM_RECOGNITION ON
    assign_opt AUTO_ROM_RECOGNITION ON
    assign_opt AUTO_RAM_TO_LCELL_CONVERSION OFF
    assign_opt ALLOW_ANY_RAM_SIZE_FOR_RECOGNITION ON

    # Register retiming. Synchronizer chains are identified so that retiming and
    # duplication never touch clock-domain-crossing flops.
    assign_opt SYNCHRONIZER_IDENTIFICATION "FORCED IF ASYNCHRONOUS"
    assign_opt ALLOW_REGISTER_RETIMING ON
    assign_opt ADV_NETLIST_OPT_SYNTH_WYSIWYG_REMAP ON
    assign_opt PHYSICAL_SYNTHESIS_REGISTER_RETIMING ON
    assign_opt PHYSICAL_SYNTHESIS_REGISTER_DUPLICATION ON
    assign_opt PHYSICAL_SYNTHESIS_COMBO_LOGIC ON
    assign_opt PHYSICAL_SYNTHESIS_EFFORT NORMAL

    # Timing-driven, deterministic fitting.
    assign_opt FITTER_EFFORT "STANDARD FIT"
    assign_opt OPTIMIZE_TIMING "NORMAL COMPILATION"
    assign_opt OPTIMIZE_MULTI_CORNER_TIMING ON
    assign_opt ROUTER_TIMING_OPTIMIZATION_LEVEL NORMAL
    assign_opt PLACEMENT_EFFORT_MULTIPLIER 1.0
    assign_opt ROUTER_EFFORT_MULTIPLIER 1.0
    assign_opt FINAL_PLACEMENT_OPTIMIZATION AUTOMATICALLY
    assign_opt FITTER_AGGRESSIVE_ROUTABILITY_OPTIMIZATION AUTOMATICALLY
    assign_opt TIMING_ANALYZER_MULTICORNER_ANALYSIS ON
    assign_opt NUM_PARALLEL_PROCESSORS $cfg(jobs)
    assign SEED [lindex $cfg(seeds) 0]
    log INFO "settings applied (optimization=BALANCED, seed list: $cfg(seeds), jobs=$cfg(jobs))"
}

proc ::sf::add_sources {} {
    variable staged
    banner "Source registration"
    foreach f $staged {
        if {[catch {set_global_assignment -name SYSTEMVERILOG_FILE $f} err]} {
            die 2 "could not register source $f: $err"
        }
    }
    log INFO "registered [llength $staged] SystemVerilog sources"
}

# -----------------------------------------------------------------------------
#  Constraints: SDC and pins
# -----------------------------------------------------------------------------

proc ::sf::generate_sdc {path} {
    variable cfg
    set clocks [list \
        [list $cfg(clk_port) $cfg(clk_period)] \
        [list clk_mem_i  $cfg(mem_period)] \
        [list clk_host_i $cfg(host_period)] \
        [list clk_rtc_i  $cfg(rtc_period)] \
        [list jtag_tck_i $cfg(jtag_period)] \
    ]
    set seen {}
    set clock_lines {}
    foreach c $clocks {
        lassign $c port period
        if {[lsearch -exact $seen $port] >= 0} {
            continue
        }
        lappend seen $port
        lappend clock_lines [format {if {[sf_has_port %s]} {create_clock -name %s -period %s [get_ports %s]}} $port $port $period $port]
    }
    set template {# SilicaFlux default timing constraints (generated by synth.tcl)
# Primary clock: @PRIMARY@, @PERIOD@ ns

proc sf_has_port {n} {
    return [expr {[get_collection_size [get_ports -nowarn $n]] > 0}]
}

@CLOCKS@

derive_pll_clocks
derive_clock_uncertainty

# Every clock domain is crossed through dedicated synchronizer / CDC primitives.
set sf_clks {}
foreach c {@CLKLIST@} {
    if {[sf_has_port $c]} {
        lappend sf_clks $c
    }
}
if {[llength $sf_clks] > 1} {
    set sf_groups {}
    foreach c $sf_clks {
        lappend sf_groups -group [list $c]
    }
    set_clock_groups -asynchronous {*}$sf_groups
}
@IOBLOCK@
}
    set ioblock ""
    if {$cfg(virtual_pins)} {
        set ioblock {
# All non-clock ports are virtual pins; they carry no board timing.
set_false_path -from [remove_from_collection [all_inputs] [get_ports $sf_clks]]
set_false_path -to [all_outputs]
}
    }
    set text [string map [list \
        @PRIMARY@ $cfg(clk_port) \
        @PERIOD@  $cfg(clk_period) \
        @CLOCKS@  [join $clock_lines "\n"] \
        @CLKLIST@ [join $seen " "] \
        @IOBLOCK@ $ioblock] $template]
    set fd [open $path w]
    fconfigure $fd -translation lf
    puts $fd $text
    close $fd
}

proc ::sf::apply_constraints {} {
    variable cfg
    variable artifacts
    banner "Timing and pin constraints"
    set sdc $cfg(sdc)
    if {$sdc eq ""} {
        set cand [file join $cfg(root) silicaflux.sdc]
        set cand2 [file join $cfg(root) constraints silicaflux.sdc]
        if {[file isfile $cand]} {
            set sdc $cand
        } elseif {[file isfile $cand2]} {
            set sdc $cand2
        }
    }
    if {$sdc ne ""} {
        if {![file isfile $sdc]} {
            die 2 "sdc file not found: $sdc"
        }
        file copy -force $sdc silicaflux.sdc
        log INFO "using external SDC: $sdc"
    } else {
        generate_sdc silicaflux.sdc
        log INFO "no external SDC found; generated $cfg(clk_port) constraint at $cfg(clk_period) ns"
    }
    assign SDC_FILE silicaflux.sdc
    lappend artifacts "silicaflux.sdc (applied constraints)"

    set pin_file $cfg(pin_file)
    if {$pin_file eq ""} {
        set cand [file join $cfg(root) silicaflux_pins.tcl]
        if {[file isfile $cand]} {
            set pin_file $cand
        }
    }
    if {$pin_file ne ""} {
        if {![file isfile $pin_file]} {
            die 2 "pin_file not found: $pin_file"
        }
        log INFO "applying board pin assignments from $pin_file"
        if {[catch {uplevel #0 [list source $pin_file]} err]} {
            die 2 "pin_file $pin_file failed: $err"
        }
        return
    }
    if {!$cfg(virtual_pins)} {
        log INFO "no pin file and virtual_pins=0: pin placement left to the Fitter"
        return
    }
    variable ports
    set skip [clock_port_names]
    set count 0
    foreach p $ports {
        lassign $p name is_bus
        if {[lsearch -exact $skip $name] >= 0} {
            continue
        }
        set target [expr {$is_bus ? "${name}\[*\]" : $name}]
        if {[catch {set_instance_assignment -name VIRTUAL_PIN ON -to $target} err]} {
            die 2 "virtual pin assignment for $target failed: $err"
        }
        incr count
    }
    log INFO "no pin file: mapped $count top-level ports to virtual pins (clock ports remain physical)"
}

# -----------------------------------------------------------------------------
#  Stage execution
# -----------------------------------------------------------------------------

proc ::sf::dump_errors {tool} {
    variable cfg
    set rpt [file join output_files "$cfg(revision).$tool.rpt"]
    if {![file isfile $rpt]} {
        return
    }
    set shown 0
    foreach line [split [slurp $rpt] "\n"] {
        if {[regexp {(Error \([0-9]+\): .*)$} $line -> e]} {
            log ERROR [string trim $e " ;"]
            incr shown
            if {$shown >= 25} {
                log ERROR "(further errors omitted; see output_files/$cfg(revision).$tool.rpt)"
                break
            }
        }
    }
}

proc ::sf::run_tool {stage tool code {toolargs {}}} {
    variable stages
    banner $stage
    commit_assignments
    set t [clock seconds]
    if {[llength $toolargs]} {
        set rc [catch {execute_module -tool $tool -args [join $toolargs " "]} msg]
    } else {
        set rc [catch {execute_module -tool $tool} msg]
    }
    set dt [expr {[clock seconds] - $t}]
    if {$rc} {
        lappend stages [list $stage FAILED $dt]
        dump_errors $tool
        die $code "$stage FAILED after [fmt_dur $dt]: $msg"
    }
    lappend stages [list $stage OK $dt]
    log INFO "$stage completed in [fmt_dur $dt]"
}

# -----------------------------------------------------------------------------
#  Report parsing
# -----------------------------------------------------------------------------

proc ::sf::parse_kv_summary {file} {
    set kv [dict create]
    if {![file isfile $file]} {
        return $kv
    }
    foreach line [split [slurp $file] "\n"] {
        if {[regexp {^([^:]+?)\s*:\s*(.*?)\s*$} $line -> k v]} {
            dict set kv $k $v
        }
    }
    return $kv
}

proc ::sf::collect_utilization {} {
    variable cfg
    variable util
    set kv [parse_kv_summary [file join output_files "$cfg(revision).fit.summary"]]
    set util {}
    foreach key {
        "Fitter Status"
        "Logic utilization (in ALMs)"
        "Total registers"
        "Total pins"
        "Total virtual pins"
        "Total block memory bits"
        "Total RAM Blocks"
        "Total DSP Blocks"
        "Total HSSI RX PCSs"
        "Total PLLs"
        "Total DLLs"
    } {
        if {[dict exists $kv $key]} {
            lappend util $key [dict get $kv $key]
        }
    }
    if {![llength $util]} {
        log WARN "fitter summary not found or empty; utilization unavailable"
    } else {
        foreach {k v} $util {
            log INFO [format "utilization     : %-30s %s" $k $v]
        }
    }
}

proc ::sf::parse_sta_summary {file} {
    set rows {}
    if {![file isfile $file]} {
        return $rows
    }
    set type ""
    set slack ""
    set tns ""
    foreach line [split [slurp $file] "\n"] {
        set line [string trim $line]
        if {[regexp {^Type\s*:\s*(.*)$} $line -> v]} {
            if {$type ne ""} {
                lappend rows [list $type $slack $tns]
            }
            set type $v
            set slack ""
            set tns ""
        } elseif {[regexp {^Slack\s*:\s*(\S+)} $line -> v]} {
            set slack $v
        } elseif {[regexp {^TNS\s*:\s*(\S+)} $line -> v]} {
            set tns $v
        }
    }
    if {$type ne ""} {
        lappend rows [list $type $slack $tns]
    }
    return $rows
}

proc ::sf::parse_fmax {file} {
    set out [dict create]
    if {![file isfile $file]} {
        return $out
    }
    foreach line [split [slurp $file] "\n"] {
        if {[regexp {^;\s*([0-9]+(?:\.[0-9]+)?)\s*MHz\s*;\s*([0-9]+(?:\.[0-9]+)?)\s*MHz\s*;\s*([^;]*?)\s*;} $line -> fmax rfmax clk]} {
            if {![dict exists $out $clk] || $rfmax < [dict get $out $clk]} {
                dict set out $clk $rfmax
            }
        }
    }
    return $out
}

# Returns {met wns_setup wns_hold worst fmax_dict}; met is 1, 0 or -1 (unknown).
proc ::sf::evaluate_timing {} {
    variable cfg
    variable timing
    set rows [parse_sta_summary [file join output_files "$cfg(revision).sta.summary"]]
    set worst ""
    set wns_setup ""
    set wns_hold ""
    set viol {}
    set usable 0
    foreach r $rows {
        lassign $r type slack tns
        if {![string is double -strict $slack]} {
            continue
        }
        incr usable
        if {$worst eq "" || $slack < $worst} {
            set worst $slack
        }
        if {[string match "*Setup*" $type] && ($wns_setup eq "" || $slack < $wns_setup)} {
            set wns_setup $slack
        }
        if {[string match "*Hold*" $type] && ($wns_hold eq "" || $slack < $wns_hold)} {
            set wns_hold $slack
        }
        if {$slack < 0} {
            lappend viol "$type slack $slack"
        }
    }
    set fmax [parse_fmax [file join output_files "$cfg(revision).sta.rpt"]]
    if {!$usable || $wns_setup eq ""} {
        log WARN "no constrained setup paths found in the Timing Analyzer summary (is the clock constrained?)"
        set met -1
    } else {
        set met [expr {[llength $viol] == 0}]
    }
    set timing {}
    lappend timing "Timing requirement" "[format %.1f [expr {1000.0 / $cfg(clk_period)}]] MHz ($cfg(clk_period) ns on $cfg(clk_port))"
    lappend timing "Worst setup slack" [expr {$wns_setup eq "" ? "n/a" : "$wns_setup ns"}]
    lappend timing "Worst hold slack" [expr {$wns_hold eq "" ? "n/a" : "$wns_hold ns"}]
    lappend timing "Worst slack (all checks)" [expr {$worst eq "" ? "n/a" : "$worst ns"}]
    dict for {clk f} $fmax {
        lappend timing "Restricted Fmax ($clk)" "$f MHz (slowest corner)"
    }
    lappend timing "Timing verdict" [expr {$met == 1 ? "MET" : ($met == 0 ? "NOT MET" : "UNKNOWN")}]
    foreach v [lrange $viol 0 9] {
        log WARN "timing violation: $v"
    }
    return [list $met $wns_setup $wns_hold $worst $fmax]
}

# -----------------------------------------------------------------------------
#  Fit + timing with optional seed sweep
# -----------------------------------------------------------------------------

proc ::sf::fit_and_time {} {
    variable cfg
    variable seed_log
    variable final_seed
    set seeds $cfg(seeds)
    set multi [expr {[llength $seeds] > 1}]
    set best_seed ""
    set best_slack ""
    set last_seed ""
    set result {}
    foreach seed $seeds {
        assign SEED $seed
        set tag [expr {$multi ? " (seed $seed)" : ""}]
        run_tool "Fitter$tag" fit 4
        run_tool "Timing Analyzer$tag" sta 6
        set result [evaluate_timing]
        lassign $result met wns_setup wns_hold worst fmax
        lappend seed_log [list $seed [expr {$worst eq "" ? "n/a" : $worst}] $met]
        set last_seed $seed
        set rank [expr {$worst eq "" ? -1.0e9 : $worst}]
        if {$best_seed eq "" || $rank > $best_slack} {
            set best_seed $seed
            set best_slack $rank
        }
        if {$met == 1} {
            log INFO "timing met with seed $seed"
            break
        }
        if {$multi} {
            log WARN "timing not met with seed $seed (worst slack [expr {$worst eq "" ? "n/a" : $worst}] ns)"
        }
    }
    lassign $result met
    if {$met != 1 && $multi && $best_seed ne $last_seed} {
        log INFO "re-running the best seed ($best_seed) so the final database matches it"
        assign SEED $best_seed
        run_tool "Fitter (final, seed $best_seed)" fit 4
        run_tool "Timing Analyzer (final, seed $best_seed)" sta 6
        set result [evaluate_timing]
        set last_seed $best_seed
    }
    set final_seed $last_seed
    return $result
}

# -----------------------------------------------------------------------------
#  Programming files and artifacts
# -----------------------------------------------------------------------------

proc ::sf::generate_programming_files {} {
    variable cfg
    variable artifacts
    variable stages
    set sof [file join output_files "$cfg(revision).sof"]
    if {![file isfile $sof]} {
        die 5 "Assembler finished but $sof was not produced"
    }
    lappend artifacts "output_files/$cfg(revision).sof (SRAM object file, JTAG programming)"
    if {$cfg(gen_rbf)} {
        set rbf [file join output_files "$cfg(revision).rbf"]
        banner "Raw binary file (HPS-driven FPGA configuration)"
        set t [clock seconds]
        if {[catch {execute_module -tool cpf -args "-c --hps -o bitstream_compression=on $sof $rbf"} err] || ![file isfile $rbf]} {
            lappend stages [list "RBF generation" FAILED [expr {[clock seconds] - $t}]]
            log WARN "RBF generation failed (non-fatal): $err"
        } else {
            lappend stages [list "RBF generation" OK [expr {[clock seconds] - $t}]]
            lappend artifacts "output_files/$cfg(revision).rbf (compressed, HPS-compatible)"
        }
    }
    if {$cfg(gen_pof)} {
        set pof [file join output_files "$cfg(revision).pof"]
        banner "Programmer object file (configuration flash: $cfg(pof_device))"
        set t [clock seconds]
        if {[catch {execute_module -tool cpf -args "-c -d $cfg(pof_device) -s $cfg(device) $sof $pof"} err] || ![file isfile $pof]} {
            lappend stages [list "POF generation" FAILED [expr {[clock seconds] - $t}]]
            die 5 "POF generation was requested (gen_pof=1) and failed: $err"
        }
        lappend stages [list "POF generation" OK [expr {[clock seconds] - $t}]]
        lappend artifacts "output_files/$cfg(revision).pof (configuration flash image, $cfg(pof_device))"
    } else {
        log INFO "POF not generated: the DE10-Nano configures the FPGA over JTAG or from the HPS (use gen_pof=1 for an external flash)"
    }
}

proc ::sf::collect_artifacts {} {
    variable cfg
    set dest [file join $cfg(build_dir) artifacts]
    set reports [file join $dest reports]
    foreach pat {*.sof *.rbf *.pof} {
        foreach f [glob -nocomplain -directory output_files $pat] {
            file copy -force $f $dest
        }
    }
    foreach pat {*.rpt *.summary *.smsg *.pin *.jdi *.map.rpt *.fit.rpt *.sta.rpt} {
        foreach f [glob -nocomplain -directory output_files $pat] {
            file copy -force $f $reports
        }
    }
    foreach f {silicaflux.sdc} {
        if {[file isfile $f]} {
            file copy -force $f $reports
        }
    }
    set fd [open [file join $reports utilization_summary.txt] w]
    variable util
    puts $fd "SilicaFlux post-fit utilization ($cfg(family) $cfg(device))"
    foreach {k v} $util {
        puts $fd [format "%-34s %s" $k $v]
    }
    close $fd
    set fd [open [file join $reports timing_summary.txt] w]
    variable timing
    puts $fd "SilicaFlux timing summary ($cfg(family) $cfg(device))"
    foreach {k v} $timing {
        puts $fd [format "%-34s %s" $k $v]
    }
    close $fd
}

# -----------------------------------------------------------------------------
#  Main
# -----------------------------------------------------------------------------

proc ::sf::print_config {} {
    variable cfg
    foreach k {project revision top family device profile clk_port clk_period seeds jobs
               enforce_timing virtual_pins stage_sources gen_rbf gen_pof build_dir} {
        log INFO [format "config          : %-15s = %s" $k $cfg($k)]
    }
}

proc ::sf::main {} {
    variable cfg
    variable stages
    variable artifacts
    set t_start [clock seconds]

    load_config
    log INFO "SilicaFlux Quartus build automation v$::sf::VERSION"
    check_tool
    resolve_sources
    discover_ports
    prepare_build_dir
    print_config

    stage_sources
    create_project
    apply_synthesis_settings
    add_sources
    apply_parameters
    apply_constraints

    run_tool "Analysis & Synthesis" map 3
    set timing_result [fit_and_time]
    collect_utilization
    run_tool "Assembler" asm 5
    generate_programming_files

    lassign $timing_result met
    collect_artifacts
    catch {project_close}

    set total [expr {[clock seconds] - $t_start}]
    set code 0
    set result SUCCESS
    set detail ""
    if {$met != 1} {
        if {$met == 0} {
            set detail "timing closure not achieved at $cfg(clk_period) ns"
        } else {
            set detail "timing results unavailable: no constrained setup paths were reported"
        }
        if {$cfg(enforce_timing)} {
            set code 7
            set result "FAILED (timing)"
        } else {
            set result "SUCCESS (timing not enforced)"
        }
    }
    lappend stages [list "Total" [expr {$code == 0 ? "OK" : "FAILED"}] $total]
    write_summary $result $code $detail
    foreach l [summary_lines $result $code $detail] {
        log INFO $l
    }
    if {$code != 0} {
        log ERROR "BUILD FAILED (exit code $code): $detail"
    } else {
        log INFO "BUILD SUCCEEDED in [fmt_dur $total]"
    }
    close_log
    exit $code
}

if {[catch {::sf::main} err opts]} {
    catch {::sf::log ERROR "unexpected internal error: $err"}
    catch {::sf::log ERROR [dict get $opts -errorinfo]}
    catch {::sf::write_summary FAILED 1 "unexpected internal error: $err"}
    catch {project_close}
    catch {::sf::close_log}
    exit 1
}
