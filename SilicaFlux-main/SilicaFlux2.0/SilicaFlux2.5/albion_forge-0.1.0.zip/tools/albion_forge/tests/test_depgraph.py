"""Dependency analysis: missing modules, circular dependencies, duplicate
definitions, deterministic ordering."""
import itertools
import random

from albion_forge.depgraph import SourceFile, candidate_tops, resolve
from albion_forge.diagnostics import DiagnosticSink, Severity
from albion_forge.sv_scan import scan_text

from conftest import codes


def sf(path: str, text: str, vfs=None) -> SourceFile:
    return SourceFile(logical=path, path="/" + path, scan=scan_text("/" + path, text, vfs=vfs))


# ---------------------------------------------------------------------- missing modules
def test_missing_module_reports_file_line_and_parent_module():
    files = [sf("rtl/top.sv", "module top;\n  logic c;\n  ghost u_g (.c(c));\nendmodule\n")]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink)
    assert not res.ok
    (d,) = [x for x in sink.items if x.code == "DEP001"]
    assert d.severity == Severity.ERROR
    assert d.file == "rtl/top.sv" and d.line == 3 and d.module == "top"
    assert "ghost" in d.message
    assert res.missing_units == [("ghost", "top", "rtl/top.sv", 3)]


def test_blackboxed_cells_and_assertion_idioms_are_not_missing():
    files = [sf("t.sv", """
      module top #(parameter int W = 8);
        sky130_cell u0 ();
        if (W > 64) begin : g_bad
          illegal_parameter_W_too_big u_assert ();
        end
        if (W > 99) begin : g_bad2
          hpc_param_error_DATA_W_must_be_32 u_assert2 ();
        end
      endmodule""")]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink, blackboxes=["sky130_cell"])
    assert res.ok, [d.render() for d in sink.items]
    assert [d.severity for d in sink.items if d.code == "DEP001"] == [Severity.INFO, Severity.INFO]


def test_missing_package_and_module_used_as_package():
    files = [sf("a.sv", "module top; import nopkg::*; endmodule"),
             sf("b.sv", "module not_a_pkg; endmodule"),
             sf("c.sv", "module top2; import not_a_pkg::*; endmodule")]
    s1 = DiagnosticSink()
    resolve(files, "top", s1)
    assert codes(s1.errors) == ["DEP002"]
    s2 = DiagnosticSink()
    resolve(files, "top2", s2)
    (d,) = s2.errors
    assert d.code == "DEP002" and "defined as a module, not a package" in d.message


def test_unknown_top_lists_candidates():
    files = [sf("a.sv", "module real_top; endmodule")]
    sink = DiagnosticSink()
    res = resolve(files, "nope", sink)
    assert not res.ok and codes(sink.errors) == ["DEP006"]
    assert "real_top" in sink.errors[0].hint


def test_missing_include_is_reported_per_file():
    files = [sf("a.sv", '`include "gone.svh"\nmodule top; endmodule')]
    sink = DiagnosticSink()
    resolve(files, "top", sink)
    d = [x for x in sink.errors if x.code == "DEP005"][0]
    assert d.file == "a.sv" and d.line == 1


# ---------------------------------------------------------------------- circular dependencies
def test_module_cycle_detected_with_path():
    files = [sf("a.sv", "module a; b u(); endmodule"), sf("b.sv", "module b; c u(); endmodule"),
             sf("c.sv", "module c; a u(); endmodule")]
    sink = DiagnosticSink()
    res = resolve(files, "a", sink)
    assert not res.ok
    (d,) = [x for x in sink.errors if x.code == "DEP003"]
    assert "a -> b -> c -> a" in d.message
    assert res.cycles == [["a", "b", "c"]]


def test_package_cycle_detected():
    files = [sf("pa.sv", "package pa; localparam int X = pb::Y; endpackage"),
             sf("pb.sv", "package pb; localparam int Y = pa::X; endpackage"),
             sf("t.sv", "module top; import pa::*; endmodule")]
    sink = DiagnosticSink()
    resolve(files, "top", sink)
    assert "DEP003" in codes(sink.errors)


def test_self_instantiation_is_a_cycle():
    files = [sf("a.sv", "module a; a u(); endmodule")]
    sink = DiagnosticSink()
    resolve(files, "a", sink)
    assert "DEP003" in codes(sink.errors)


def test_diamond_is_not_a_cycle():
    files = [sf("t.sv", "module top; l u1(); r u2(); endmodule"), sf("l.sv", "module l; leaf u(); endmodule"),
             sf("r.sv", "module r; leaf u(); endmodule"), sf("f.sv", "module leaf; endmodule")]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink)
    assert res.ok and res.cycles == []
    order = [f.logical for f in res.order]
    assert order.index("f.sv") < order.index("l.sv") < order.index("t.sv")


# ---------------------------------------------------------------------- duplicate definitions
def test_conflicting_duplicate_definition_is_error_when_reachable():
    files = [sf("top.sv", "module top; leaf u(); endmodule"),
             sf("leaf1.sv", "module leaf; wire a; endmodule"),
             sf("leaf2.sv", "module leaf; wire b; endmodule")]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink)
    assert not res.ok
    (d,) = [x for x in sink.errors if x.code == "DEP004"]
    assert d.module == "leaf" and "leaf1.sv" in d.message and "leaf2.sv" in d.message
    assert res.duplicates == {"leaf": ["leaf1.sv:1", "leaf2.sv:1"]}


def test_identical_duplicate_is_only_a_warning():
    body = "module leaf; wire a; endmodule"
    files = [sf("top.sv", "module top; leaf u(); endmodule"), sf("l1.sv", body), sf("l2.sv", body)]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink)
    assert res.ok
    assert codes(sink.warnings) == ["DEP008"]


def test_unreachable_duplicate_is_warning_not_error():
    files = [sf("top.sv", "module top; endmodule"), sf("x1.sv", "module other; wire a; endmodule"),
             sf("x2.sv", "module other; wire b; endmodule")]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink)
    assert res.ok
    assert codes(sink.warnings) == ["DEP004"]


def test_header_included_by_many_files_is_one_definition():
    vfs = {"/pkg.sv": "package shared_pkg; localparam int X = 1; endpackage"}
    files = [sf("pkg.sv", vfs["/pkg.sv"]),
             sf("a.sv", '`include "pkg.sv"\nmodule top; import shared_pkg::*; b u(); endmodule', vfs),
             sf("b.sv", '`include "pkg.sv"\nmodule b; import shared_pkg::*; endmodule', vfs)]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink)
    assert res.ok, [d.render() for d in sink.items]
    assert res.duplicates == {}


# ---------------------------------------------------------------------- ordering
def test_package_files_precede_users_and_ordering_is_deterministic():
    base = [sf("z_pkg.sv", "package zp; localparam int X = 1; endpackage"),
            sf("a_top.sv", "module top; import zp::*; mid u(); endmodule"),
            sf("m_mid.sv", "module mid; import zp::*; leaf u(); endmodule"),
            sf("b_leaf.sv", "module leaf; import zp::*; endmodule")]
    ref = None
    for perm in itertools.islice(itertools.permutations(base), 24):
        sink = DiagnosticSink()
        res = resolve(list(perm), "top", sink)
        assert res.ok
        order = [f.logical for f in res.order]
        if ref is None:
            ref = order
        assert order == ref                                   # independent of input order
    assert ref.index("z_pkg.sv") < ref.index("b_leaf.sv") < ref.index("m_mid.sv") < ref.index("a_top.sv")


def test_random_shuffles_give_identical_order():
    rng = random.Random(7)
    files = [sf(f"f{i}.sv", f"module m{i}; " + (f"m{i + 1} u();" if i < 12 else "") + " endmodule") for i in range(13)]
    orders = set()
    for _ in range(10):
        rng.shuffle(files)
        res = resolve(list(files), "m0", DiagnosticSink())
        orders.add(tuple(f.logical for f in res.order))
    assert len(orders) == 1


def test_sibling_unit_in_selected_file_pulls_its_package():
    # `top` does not use `other`, but both live in one file the tools parse as a whole
    files = [sf("pkg.sv", "package needs_me; localparam int X = 1; endpackage"),
             sf("both.sv", "module top; endmodule\nmodule other; import needs_me::*; endmodule")]
    sink = DiagnosticSink()
    res = resolve(files, "top", sink)
    assert res.ok
    assert [f.logical for f in res.order] == ["pkg.sv", "both.sv"]


def test_candidate_tops():
    files = [sf("a.sv", "module top; sub u(); endmodule"), sf("b.sv", "module sub; endmodule"),
             sf("c.sv", "module lonely; endmodule")]
    assert candidate_tops(files) == ["lonely", "top"]


def test_cycle_path_is_a_real_path_not_sorted_members():
    # a -> c -> b -> a : sorted members would print "a -> b -> c -> a", which is not a path
    files = [sf("a.sv", "module a; c u(); endmodule"), sf("c.sv", "module c; b u(); endmodule"),
             sf("b.sv", "module b; a u(); endmodule")]
    sink = DiagnosticSink()
    resolve(files, "a", sink)
    (d,) = [x for x in sink.errors if x.code == "DEP003"]
    assert "a -> c -> b -> a" in d.message
