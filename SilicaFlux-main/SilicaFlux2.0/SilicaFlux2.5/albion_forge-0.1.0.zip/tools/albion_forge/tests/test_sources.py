"""Archive materialisation: pins, unsafe members, .sf translation, globbing."""
import hashlib
import os
import zipfile

from albion_forge.sources import glob_match, materialize
from albion_forge.diagnostics import DiagnosticSink

from conftest import LEAF, TOP, codes, config_text


def mat(proj):
    ctx = proj.ctx()
    sink = DiagnosticSink()
    m = materialize(ctx.cfg, proj.root, ctx.src_dir, sink)
    return ctx, m, sink


def test_glob_semantics():
    assert glob_match("rtl/*.sv", "rtl/a.sv") and not glob_match("rtl/*.sv", "rtl/sub/a.sv")
    assert glob_match("rtl/**/*.sv", "rtl/sub/deep/a.sv") and glob_match("rtl/**/*.sv", "rtl/a.sv")
    assert glob_match("a?.sv", "ab.sv") and not glob_match("a?.sv", "abc.sv")


def test_materialize_is_byte_exact_and_sorted(mk):
    p = mk()
    ctx, m, sink = mat(p)
    assert not sink.errors
    logical = [f.logical for f in m.files]
    assert logical == sorted(logical)
    f = next(f for f in m.files if f.logical == "rtl:rtl/top.sv")
    assert open(f.path).read() == TOP
    assert f.sha256 == hashlib.sha256(TOP.encode()).hexdigest()
    assert m.archives[0]["sha256"] == p.sha


def test_archive_hash_pin_mismatch(mk):
    p = mk()
    with open(os.path.join(p.root, p.archive_rel), "ab") as fh:        # tamper with the archive
        fh.write(b"\0")
    ctx, m, sink = mat(p)
    (d,) = sink.errors
    assert d.code == "SRC002" and "pins" in d.message and not m.files


def test_per_file_pin_mismatch(mk):
    p = mk(extra="")
    txt = open(os.path.join(p.cfgdir, "fx.toml")).read()
    txt = txt.replace('glob = ["rtl/*.sv"]', 'glob = ["rtl/*.sv"]\n[source.pins]\n"rtl/leaf.sv" = "' + "1" * 64 + '"', 1)
    p.write_config(txt)
    ctx, m, sink = mat(p)
    assert any(d.code == "SRC002" and "leaf.sv" in d.message for d in sink.errors)


def test_missing_archive_missing_file_and_empty_glob(mk, tmp_path):
    p = mk()
    os.remove(os.path.join(p.root, p.archive_rel))
    _, _, sink = mat(p)
    assert codes(sink.errors) == ["SRC001"] and "not found" in sink.errors[0].message
    p2 = mk(rtl_glob="rtl/nothing_*.sv")
    _, _, sink = mat(p2)
    assert codes(sink.errors) == ["SRC001"] and "matched nothing" in sink.errors[0].message


def test_unsafe_archive_members_are_refused(mk):
    p = mk(raw={"../evil.sv": b"module evil; endmodule", "/abs.sv": b"module abs; endmodule"})
    # re-pin because write_archive hashed the new archive; config already holds that hash
    ctx, m, sink = mat(p)
    unsafe = [d for d in sink.errors if d.code == "SRC003"]
    assert len(unsafe) == 2
    assert not os.path.exists(os.path.join(os.path.dirname(ctx.build_dir), "evil.sv"))


def test_symlink_members_are_refused(mk, tmp_path):
    p = mk()
    path = os.path.join(p.root, p.archive_rel)
    with zipfile.ZipFile(path, "a") as z:
        zi = zipfile.ZipInfo("rtl/link.sv")
        zi.create_system = 3
        zi.external_attr = (0o120777 << 16)
        z.writestr(zi, "/etc/passwd")
    sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
    txt = open(os.path.join(p.cfgdir, "fx.toml")).read().replace(p.sha, sha)
    p.write_config(txt)
    _, _, sink = mat(p)
    assert any(d.code == "SRC003" and "symlink" in d.message for d in sink.errors)


def test_sf_extension_is_mapped_to_sv_byte_identically(mk):
    sf_text = "// Language: Silica Flux-2017\n" + LEAF
    p = mk(rtl={"leaf.sf": sf_text, "top.sv": TOP}, rtl_glob="rtl/*.s[fv]")
    ctx, m, sink = mat(p)
    assert not sink.errors, [d.render() for d in sink.errors]
    f = next(f for f in m.files if f.relpath == "rtl/leaf.sf")
    assert f.path.endswith("leaf.sv") and f.translated_from == "rtl/leaf.sf"
    assert open(f.path).read() == sf_text                                     # byte identical, rename only
    assert f.logical == "rtl:rtl/leaf.sf"                                      # reports keep the original name


def test_dsl_sf_sketch_is_rejected_not_renamed(mk):
    dsl = "// documentation only\npackage silicaflux.ml\nfixed Fixed16_16 { int_bits: 16, frac_bits: 16 }\n"
    p = mk(rtl={"sketch.sf": dsl, "top.sv": TOP, "leaf.sv": LEAF}, rtl_glob="rtl/*")
    ctx, m, sink = mat(p)
    (d,) = [x for x in sink.errors if x.code == "SRC005"]
    assert d.file == "rtl:rtl/sketch.sf" and "DSL sketch" in d.message and "no translator" in d.message
    assert not any(f.relpath.endswith("sketch.sf") for f in m.files)


def test_headers_under_incdirs_are_extracted_but_not_compiled(mk):
    rtl = {"leaf.sv": LEAF, "top.sv": '`include "defs.svh"\n' + TOP, "defs.svh": "`define X 1\n"}
    p = mk(rtl=rtl, rtl_glob="rtl/*.sv")
    ctx, m, sink = mat(p)
    h = next(f for f in m.files if f.relpath == "rtl/defs.svh")
    assert not h.compiled and os.path.isfile(h.path)
    assert any(d.endswith("src/rtl/rtl") for d in m.incdirs)
