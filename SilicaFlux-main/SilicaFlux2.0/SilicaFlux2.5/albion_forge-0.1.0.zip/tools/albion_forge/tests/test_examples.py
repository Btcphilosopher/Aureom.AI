"""The documented example configurations must stay valid against the schema."""
import os

import pytest

from albion_forge.config import load_config
from albion_forge.diagnostics import DiagnosticSink

from conftest import FORGE

EXDIR = os.path.join(FORGE, "configs", "examples")
EXAMPLES = sorted(f for f in os.listdir(EXDIR) if f.endswith(".toml"))


@pytest.mark.parametrize("fname", EXAMPLES)
def test_example_loads(fname):
    sink = DiagnosticSink()
    cfg = load_config(os.path.join(EXDIR, fname), EXDIR, sink)
    assert cfg is not None, [d.render() for d in sink.errors]


def test_blocked_example_is_disabled_with_a_blocker():
    sink = DiagnosticSink()
    cfg = load_config(os.path.join(EXDIR, "blocked_target.toml"), EXDIR, sink)
    assert not cfg.enabled and "No RTL" in cfg.blocker


def test_examples_are_not_listed_as_real_configurations():
    from albion_forge.config import list_config_names
    names = list_config_names(os.path.join(FORGE, "configs"))
    assert "example" not in names and "blocked_target" not in names
