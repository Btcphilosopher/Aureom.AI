"""Validation of the configurations that ship with AlbionForge, against the
real SilicaFlux repository (archives are SHA-pinned, so this also detects an
archive that changed underneath a configuration).

These tests need no EDA tool (analysis only) except where marked.
"""
import os

import pytest

from albion_forge import stages
from albion_forge.build import BuildContext
from albion_forge.config import list_config_names, load_config
from albion_forge.diagnostics import DiagnosticSink, Severity

from conftest import FORGE, needs_icarus

REPO = os.path.dirname(os.path.dirname(FORGE))
CFGDIR = os.path.join(FORGE, "configs")
NAMES = list_config_names(CFGDIR)


def _cfg(name):
    sink = DiagnosticSink()
    cfg = load_config(name, CFGDIR, sink)
    assert cfg is not None, [d.render() for d in sink.items]
    return cfg


def test_there_are_shipped_configurations():
    assert {"smoke"} <= set(NAMES)


@pytest.mark.parametrize("name", NAMES)
def test_shipped_config_is_valid(name):
    cfg = _cfg(name)
    assert cfg.name == name
    if not cfg.enabled:
        assert len(cfg.blocker.strip()) > 40, "a disabled configuration must explain itself"


def test_every_required_target_is_present_exactly_once():
    cats = [(_cfg(n).category, n) for n in NAMES]
    for need in ("smoke", "riscv_core", "sram", "datafabric", "dma", "vector", "tensor", "soc"):
        assert any(c == need for c, _ in cats), f"no configuration for category '{need}' (enabled or blocked)"


@pytest.mark.parametrize("name", [n for n in NAMES if _cfg(n).enabled])
def test_enabled_config_resolves_against_the_real_repository(name, tmp_path):
    cfg = _cfg(name)
    arch = [s.archive for s in cfg.sources if s.archive]
    if any(not os.path.isfile(os.path.join(REPO, a)) for a in arch):
        pytest.skip("repository archives not present in this checkout")
    ctx = BuildContext(cfg, REPO, str(tmp_path))
    assert ctx.prepare(), [d.render() for d in ctx.sink.items]       # pins match, members exist, no unsafe paths
    for stage in ("lint", "elaborate", "synth"):
        if stage == "synth" and cfg.synth.get("enabled", True) is False:
            continue
        a = ctx.analysis(stage, top=cfg.synth.get("top") if stage == "synth" else None)
        bad = [d for d in a.sink.items if d.severity >= Severity.ERROR]
        assert a.ok, f"{stage}: " + "; ".join(d.render() for d in bad[:5])
        assert a.top_decl is not None and a.top_decl.kind == "module"
        # every declared parameter exists on the top and is overridable
        sink = DiagnosticSink()
        assert ctx.validate_rtl_parameters(a, sink, "design", top_name=a.top), [d.render() for d in sink.items]
    if cfg.simulate.get("enabled"):
        a = ctx.analysis("simulate", top=cfg.simulate["tb_top"])
        assert a.ok, "; ".join(d.render() for d in a.sink.items if d.severity >= Severity.ERROR)


@pytest.mark.parametrize("name", [n for n in NAMES if _cfg(n).enabled])
def test_enabled_config_documents_every_disabled_stage(name):
    cfg = _cfg(name)
    if cfg.synth.get("enabled", True) is False:
        assert cfg.synth.get("note"), "disabling synthesis requires a note explaining the blocker"
    if not cfg.simulate.get("enabled", False):
        assert cfg.simulate.get("note"), "no simulation configured: a note must say why"


# ------------------------------------------------------------------------------------------
@needs_icarus
def test_vector_v1_lane_sweep_pins_the_documented_reduction_defect(tmp_path):
    """LANES=4 and 8 must pass; LANES=16 currently FAILS (blocker B-05: the reduction tree
    of vector_engine ignores lanes 8..15).  If the RTL is ever fixed this test fails on purpose:
    update docs/KNOWN_BLOCKERS.md and the configuration."""
    if "vector_v1" not in NAMES:
        pytest.skip("vector_v1 not shipped")
    cfg = _cfg("vector_v1")
    if not os.path.isfile(os.path.join(REPO, cfg.sources[0].archive)):
        pytest.skip("repository archives not present in this checkout")
    results = {}
    for lanes in ("4", "8", "16"):
        ctx = BuildContext(cfg, REPO, str(tmp_path / lanes), {"LANES": lanes})
        results[lanes] = stages.simulate(ctx)
    assert results["4"].status == "passed" and results["8"].status == "passed"
    r16 = results["16"]
    assert r16.status == "failed"
    failing = {d.message.split("[FAIL] ")[1].split(" ")[0] for d in r16.diagnostics
               if "[FAIL]" in d.message}
    assert {"REDUCE_SUM", "REDUCE_MIN", "REDUCE_MAX", "DOT"} <= failing
