"""Build manifests, reproducibility, deterministic ordering, revision tracking."""
import hashlib
import json
import os
import random
import shutil
import subprocess
import zipfile

from albion_forge import pipeline, toolchain
from albion_forge.build import BuildContext, repo_info
from albion_forge.config import load_config
from albion_forge.diagnostics import DiagnosticSink

from conftest import LEAF, TB_GOOD, TOP, needs_icarus, needs_verilator, needs_yosys


def manifest_for(proj, root=None, params=None):
    ctx = proj.ctx(params=params, build_root=root)
    t = pipeline.Target(ctx, ctx.cfg)
    pipeline.run_stages(t, ("lint", "elaborate"))
    with open(os.path.join(ctx.build_dir, "manifest.json")) as fh:
        return ctx, json.load(fh)


@needs_verilator
def test_manifest_records_tools_sources_archives_and_config(mk):
    p = mk(sim=False, synth=False)
    ctx, m = manifest_for(p)
    assert m["forge"]["version"]
    assert m["config"]["name"] == "fx" and len(m["config"]["sha256"]) == 64
    assert m["effective_parameters"] == {"W": 8, "DEPTH": 4}
    assert m["archives"][0]["path"] == "archives/fixture.zip" and m["archives"][0]["sha256"] == p.sha
    srcs = [s["file"] for s in m["sources"]]
    assert srcs == sorted(srcs) and "rtl:rtl/top.sv" in srcs
    assert m["sources"][0]["sha256"] == hashlib.sha256(
        open([f.path for f in ctx.materialized.files if f.logical == m["sources"][0]["file"]][0], "rb").read()).hexdigest()
    v = m["tools"]["verilator"]
    assert v["found"] and v["version"] and v["meets_minimum"]
    order = [e["file"] for e in m["stages_analysis"]["lint"]["compile_order"]]
    assert order == ["rtl:rtl/rtl/leaf.sv".replace("rtl/rtl", "rtl"), "rtl:rtl/top.sv"] or order[-1] == "rtl:rtl/top.sv"
    assert m["stage_results"]["lint"]["status"] == "passed"
    assert m["repro_digest"]


@needs_verilator
def test_output_directory_is_reproducible_and_parameter_specific(mk):
    p = mk(sim=False, synth=False)
    a = p.ctx().build_dir
    b = p.ctx().build_dir
    assert a == b and a.endswith(os.path.join("fx", "default"))
    c1 = p.ctx(params={"W": "16"}).build_dir
    c2 = p.ctx(params={"W": "16"}).build_dir
    c3 = p.ctx(params={"W": "32"}).build_dir
    assert c1 == c2 != c3 and os.path.basename(c1).startswith("o-")


@needs_verilator
@needs_icarus
def test_two_independent_builds_have_identical_reproducibility_digest(mk, tmp_path):
    p = mk(sim=False, synth=False)
    _, m1 = manifest_for(p, str(tmp_path / "b1"))
    _, m2 = manifest_for(p, str(tmp_path / "b2"))
    assert m1["repro_digest"] == m2["repro_digest"]


@needs_verilator
def test_digest_changes_when_a_source_byte_changes(mk, tmp_path):
    p1 = mk(sim=False, synth=False)
    p2 = mk(rtl={"leaf.sv": LEAF + "// edit\n", "top.sv": TOP}, sim=False, synth=False)
    _, m1 = manifest_for(p1, str(tmp_path / "b1"))
    _, m2 = manifest_for(p2, str(tmp_path / "b2"))
    assert m1["repro_digest"] != m2["repro_digest"]


@needs_verilator
def test_digest_changes_with_parameters(mk, tmp_path):
    p = mk(sim=False, synth=False)
    _, m1 = manifest_for(p, str(tmp_path / "b1"))
    _, m2 = manifest_for(p, str(tmp_path / "b2"), params={"W": "16"})
    assert m1["repro_digest"] != m2["repro_digest"]


@needs_verilator
def test_compile_order_independent_of_archive_member_order(mk, tmp_path):
    p = mk(sim=False, synth=False)
    path = os.path.join(p.root, p.archive_rel)
    names = []
    with zipfile.ZipFile(path) as z:
        data = {n: z.read(n) for n in z.namelist()}
    orders = []
    for seed in (1, 2, 3):
        names = sorted(data)
        random.Random(seed).shuffle(names)
        with zipfile.ZipFile(path, "w") as z:
            for n in names:
                z.writestr(n, data[n])
        sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
        txt = open(os.path.join(p.cfgdir, "fx.toml")).read()
        import re
        txt = re.sub(r'archive_sha256 = "[0-9a-f]{64}"', f'archive_sha256 = "{sha}"', txt)
        p.write_config(txt)
        _, m = manifest_for(p, str(tmp_path / f"b{seed}"))
        orders.append([e["file"] for e in m["stages_analysis"]["lint"]["compile_order"]])
    assert orders[0] == orders[1] == orders[2]


def test_repo_info_tracks_git_revision_and_dirty_state(tmp_path):
    if shutil.which("git") is None:
        import pytest
        pytest.skip("git not installed")
    repo = str(tmp_path / "r")
    os.makedirs(repo)
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t"}
    run = lambda *a: subprocess.run(["git", "-C", repo, *a], check=True, capture_output=True, env=env)
    run("init", "-q")
    with zipfile.ZipFile(os.path.join(repo, "a.zip"), "w") as z:
        z.writestr("x.sv", "module x; endmodule")
    run("add", "a.zip")
    run("commit", "-q", "-m", "init")
    info = repo_info(repo, ["a.zip"])
    assert len(info["revision"]) == 40 and info["dirty"] is False and info["dirty_used"] == []
    with zipfile.ZipFile(os.path.join(repo, "a.zip"), "w") as z:
        z.writestr("x.sv", "module y; endmodule")
    info = repo_info(repo, ["a.zip"])
    assert info["dirty"] is True and info["dirty_used"] == ["a.zip"]


def test_repo_info_outside_git_is_explicit(tmp_path):
    info = repo_info(str(tmp_path))
    assert info["vcs"] == "none" and info["revision"] is None


@needs_verilator
@needs_icarus
@needs_yosys
def test_reproducibility_check_function_rebuilds_from_scratch(mk):
    p = mk()
    ctx = p.ctx()
    t = pipeline.Target(ctx, ctx.cfg)
    pipeline.run_stages(t, pipeline.CI_STAGES)
    same, d1, d2 = pipeline.reproducibility_check(t, pipeline.CI_STAGES, p.root, p.cfgdir, {}, {})
    assert same and d1 == d2 and len(d1) == 64


def test_digest_covers_measured_outputs_not_just_inputs_and_status():
    """Two builds with identical inputs and identical PASS statuses but different measured results
    (cell count, number of simulation checks) must NOT share a digest."""
    base = {
        "config": {"sha256": "c"}, "effective_parameters": {"W": 8}, "archives": [], "sources": [],
        "stages_analysis": {}, "tools": {"yosys": {"found": True, "version": "0.33"}},
        "stage_results": {"synth": {"status": "passed", "metrics": {"cells": 100}},
                          "simulate": {"status": "passed", "metrics": {"pass_markers": 3, "runs": {"a": {"pass_markers": 3, "fail_markers": 0, "rc": 0, "seconds": 1.0}}}}},
    }
    d0 = BuildContext.repro_digest(base)
    import copy
    changed = copy.deepcopy(base); changed["stage_results"]["synth"]["metrics"]["cells"] = 101
    assert BuildContext.repro_digest(changed) != d0
    fewer = copy.deepcopy(base); fewer["stage_results"]["simulate"]["metrics"]["pass_markers"] = 2
    assert BuildContext.repro_digest(fewer) != d0
    timing = copy.deepcopy(base); timing["stage_results"]["simulate"]["metrics"]["runs"]["a"]["seconds"] = 99.0
    assert BuildContext.repro_digest(timing) == d0            # timings never matter


def test_repo_info_reports_untracked_paths_and_report_says_so(tmp_path):
    if shutil.which("git") is None:
        import pytest
        pytest.skip("git not installed")
    repo = str(tmp_path / "r2")
    os.makedirs(repo)
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t"}
    run = lambda *a: subprocess.run(["git", "-C", repo, *a], check=True, capture_output=True, env=env)
    run("init", "-q")
    open(os.path.join(repo, "a.txt"), "w").write("x")
    run("add", "a.txt")
    run("commit", "-q", "-m", "i")
    open(os.path.join(repo, "new_tool.py"), "w").write("y")          # untracked
    info = repo_info(repo, [])
    assert info["dirty"] is False and info["n_untracked"] == 1
    from albion_forge.report import render_markdown
    md = render_markdown({"configs": [], "forge_tests": None}, info, None)
    assert "tracked files clean; 1 untracked path(s)" in md
