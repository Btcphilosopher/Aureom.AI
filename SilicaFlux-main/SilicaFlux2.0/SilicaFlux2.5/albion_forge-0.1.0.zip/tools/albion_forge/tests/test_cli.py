"""Command-line behaviour: consistent CLI, exit codes, reports."""
import json
import os

import pytest

from albion_forge.cli import main

from conftest import config_text, needs_all, needs_verilator


def run(p, *args, capsys=None):
    argv = list(args) + ["--repo", p.root, "--config-dir", p.cfgdir, "--build-root", p.build]
    # global options belong after the sub-command in this CLI
    cmd, rest = argv[0], argv[1:]
    rc = main([cmd] + rest)
    out = capsys.readouterr().out if capsys else ""
    return rc, out


def test_codes_lists_every_registered_code(capsys):
    assert main(["codes"]) == 0
    out = capsys.readouterr().out
    for c in ("DEP001", "DEP003", "DEP004", "CFG005", "LNG001", "PAR001", "STG003", "TLS001"):
        assert c in out


def test_list_shows_disabled_configs_with_blockers(mk, capsys):
    p = mk(name="good")
    with open(os.path.join(p.cfgdir, "off.toml"), "w") as fh:
        fh.write(config_text("off", p.sha, enabled=False, blocker="no RTL exists for this target"))
    rc, out = run(p, "list", capsys=capsys)
    assert rc == 0
    assert "good" in out and "enabled" in out
    assert "off" in out and "DISABLED" in out and "no RTL exists" in out


def test_unknown_config_is_a_usage_error(mk, capsys):
    p = mk()
    rc, out = run(p, "lint", "--config", "nonexistent", capsys=capsys)
    assert rc == 2 and "CFG003" in out and "not found" in out


def test_no_config_selected_is_a_usage_error(mk, capsys):
    p = mk()
    rc = main(["lint", "--repo", p.root, "--config-dir", p.cfgdir, "--build-root", p.build])
    assert rc == 2


def test_param_override_requires_single_config(mk):
    p = mk()
    rc = main(["lint", "--all", "-P", "W=16", "--repo", p.root, "--config-dir", p.cfgdir, "--build-root", p.build])
    assert rc == 2


@needs_verilator
def test_invalid_parameter_override_exits_nonzero_without_running_tools(mk, capsys):
    p = mk(sim=False, synth=False)
    rc, out = run(p, "lint", "--config", "fx", "-P", "W=9999", capsys=capsys)
    assert rc == 1 and "PAR003" in out and "<= 64" in out
    assert not os.path.exists(os.path.join(p.build, "fx", "o-x", "lint"))


@needs_verilator
def test_lint_command_json_output_and_exit_code(mk, capsys):
    p = mk(sim=False, synth=False)
    rc, out = run(p, "lint", "--config", "fx", "--json", capsys=capsys)
    data = json.loads(out)
    assert rc == 0 and data[0]["stage"] == "lint" and data[0]["status"] == "passed"


def test_disabled_config_is_blocked_not_passed(mk, capsys):
    p = mk()
    p.write_config(config_text("fx", p.sha, enabled=False, blocker="blocked by missing IP"))
    rc, out = run(p, "lint", "--config", "fx", capsys=capsys)
    assert rc == 3 and "BLOCKED" in out and "blocked by missing IP" in out


def test_missing_tool_exit_code_is_blocked(mk, capsys, monkeypatch):
    p = mk(sim=False, synth=False)
    monkeypatch.setenv("ALBION_TOOL_VERILATOR", "/nonexistent")
    rc, out = run(p, "lint", "--config", "fx", capsys=capsys)
    assert rc == 3 and "BLOCKED" in out and "TLS001" in out


def test_doctor_reports_each_tool(capsys):
    main(["doctor"])
    out = capsys.readouterr().out
    for t in ("verilator", "icarus", "yosys", "opensta", "openroad", "pytest"):
        assert t in out
    assert "never a pass" in out


def test_doctor_exit_code_when_required_tool_missing(capsys, monkeypatch):
    monkeypatch.setenv("ALBION_TOOL_YOSYS", "/nonexistent")
    assert main(["doctor"]) == 3
    assert "MISSING" in capsys.readouterr().out


@needs_all
def test_ci_end_to_end_writes_reports_and_returns_zero(mk, capsys):
    p = mk()
    rc, out = run(p, "ci", "--config", "fx", "--skip-forge-tests", "--reproduce", capsys=capsys)
    assert rc == 0, out
    assert "reproduce" in out and "PASS" in out
    rep = os.path.join(p.build, "reports")
    md = open(os.path.join(rep, "BUILD_REPORT.md")).read()
    assert "| `fx` |" in md and "PASS" in md and "Generated from recorded stage results only" in md
    summary = json.load(open(os.path.join(rep, "ci_summary.json")))
    assert summary["exit_code"] == 0 and summary["configs"][0]["reproducible"] is True
    assert "<testsuite" in open(os.path.join(rep, "junit.xml")).read()


@needs_all
def test_ci_reports_failure_with_exit_one(mk, capsys):
    from conftest import TB_FAILING
    p = mk(tb={"tb_top.sv": TB_FAILING})
    rc, out = run(p, "ci", "--config", "fx", "--skip-forge-tests", capsys=capsys)
    assert rc == 1 and "FAIL" in out
    md = open(os.path.join(p.build, "reports", "BUILD_REPORT.md")).read()
    assert "FAIL" in md and "STG003" in md


def test_report_never_invents_a_pass(mk, capsys):
    p = mk()
    rc, out = run(p, "report", "--config", "fx", capsys=capsys)       # nothing was run
    assert rc == 0
    md = open(os.path.join(p.build, "reports", "BUILD_REPORT.md")).read()
    assert "NOT RUN" in md and "| PASS |" not in md
