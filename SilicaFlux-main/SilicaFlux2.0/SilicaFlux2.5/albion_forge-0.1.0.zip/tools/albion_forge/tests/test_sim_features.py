"""Simulation features: multiple runs, tb_name mapping, templated plusargs, data files."""
import os
import re

import pytest

from albion_forge import stages
from albion_forge.diagnostics import Severity

from conftest import LEAF, TOP, needs_icarus, needs_verilator

# A testbench whose DUT-facing parameter is called WIDTH (the DUT calls it W), selecting scenarios by +test=
TB_MULTI = """\
`timescale 1ns/1ps
module tb_top #(parameter int WIDTH = 8);
  logic clk = 0, rst_n = 0;
  logic [WIDTH-1:0] d = '0, q;
  logic [$clog2(5)-1:0] depth;
  top #(.W(WIDTH)) dut (.clk, .rst_n, .d, .q, .depth_o(depth));
  always #5 clk = ~clk;
  string test = "none";
  initial begin
    void'($value$plusargs("test=%s", test));
    rst_n = 0; repeat (2) @(posedge clk); rst_n = 1;
    d = {WIDTH{1'b1}}; repeat (3) @(posedge clk); #1;
    if (test == "good" || test == "also_good") $display("[PASS] scenario %s width=%0d q_ok=%0d", test, WIDTH, q == {WIDTH{1'b1}});
    else $display("[FAIL] scenario %s", test);
    $finish;
  end
endmodule
"""


def cfg_with(p, old, new):
    path = os.path.join(p.cfgdir, "fx.toml")
    txt = open(path).read()
    assert old in txt, old
    p.write_config(txt.replace(old, new))


@needs_icarus
def test_multiple_runs_each_need_their_own_positive_evidence(mk):
    p = mk(tb={"tb_top.sv": TB_MULTI}, synth=False, min_pass=2)
    cfg_with(p, "timeout_s = 60", 'timeout_s = 60\nruns = [ { name = "a", plusargs = ["+test=good"] }, { name = "b", plusargs = ["+test=also_good"] } ]')
    r = stages.simulate(p.ctx())
    assert r.status == "passed", [d.render() for d in r.diagnostics]
    assert set(r.metrics["runs"]) == {"a", "b"} and all(v["pass_markers"] == 1 for v in r.metrics["runs"].values())
    assert r.metrics["pass_markers"] == 2
    d = p.ctx().build_dir
    assert os.path.isfile(os.path.join(d, "simulate", "a.log")) and os.path.isfile(os.path.join(d, "simulate", "b.log"))


@needs_icarus
def test_one_failing_run_fails_the_stage_and_is_named(mk):
    p = mk(tb={"tb_top.sv": TB_MULTI}, synth=False, min_pass=1)
    cfg_with(p, "timeout_s = 60", 'timeout_s = 60\nruns = [ { name = "ok", plusargs = ["+test=good"] }, { name = "bad", plusargs = ["+test=broken"] } ]')
    r = stages.simulate(p.ctx())
    assert r.status == "failed"
    msg = " ".join(d.message for d in r.diagnostics if d.severity >= Severity.ERROR)
    assert "run 'bad'" in msg and "ok" not in re.findall(r"run '(\w+)'", msg)


def test_run_definitions_are_validated(tmp_path):
    from albion_forge.config import load_config
    from albion_forge.diagnostics import DiagnosticSink
    from conftest import config_text
    d = tmp_path / "cfg"
    d.mkdir()
    for body, frag in (('runs = [ { name = "a b", plusargs = [] } ]', "must be"),
                       ('runs = [ { name = "a" }, { name = "a" } ]', "duplicate run name"),
                       ('runs = [ { name = "a", extra = 1 } ]', "must be")):
        txt = config_text("c", "0" * 64).replace("timeout_s = 60", "timeout_s = 60\n" + body)
        (d / "c.toml").write_text(txt)
        sink = DiagnosticSink()
        assert load_config("c", str(d), sink) is None
        assert any(frag in x.message for x in sink.errors), [x.message for x in sink.errors]


@needs_icarus
def test_tb_name_maps_design_parameter_onto_testbench_parameter(mk):
    p = mk(tb={"tb_top.sv": TB_MULTI}, synth=False, min_pass=1)
    cfg_with(p, 'rtl_name = "W"\ntype = "int"', 'rtl_name = "W"\ntb_name = "WIDTH"\napply_to = ["design", "tb"]\ntype = "int"')
    cfg_with(p, "timeout_s = 60", 'timeout_s = 60\nplusargs = ["+test=good"]')
    ctx = p.ctx(params={"W": "16"})
    r = stages.simulate(ctx)
    assert r.status == "passed", [d.render() for d in r.diagnostics]
    assert r.metrics["tb_parameters"] == {"WIDTH": 16}
    assert "-P" in r.commands[0].argv and "tb_top.WIDTH=16" in r.commands[0].argv
    assert "width=16" in open(os.path.join(ctx.build_dir, "simulate", "run.log")).read()


@needs_icarus
def test_design_parameter_does_not_leak_into_a_same_named_tb_parameter_unless_declared(mk):
    # TB has a parameter called W, but the config says apply_to = ["design"]: a non-default value must NOT be
    # silently routed (the TB's W might mean something else) -> simulation is skipped, not faked.
    tb = TB_MULTI.replace("WIDTH", "W")
    p = mk(tb={"tb_top.sv": tb}, synth=False, min_pass=1)
    r = stages.simulate(p.ctx(params={"W": "16"}))
    assert r.status == "skipped" and "cannot be routed" in r.summary


@needs_icarus
def test_templated_plusargs_and_missing_stimulus_is_skipped_not_failed(mk):
    p = mk(tb={"tb_top.sv": TB_MULTI}, synth=False, min_pass=1, rtl_glob="rtl/*.sv")
    cfg_with(p, "timeout_s = 60",
             'timeout_s = 60\nplusargs = ["+test=good"]\ndata_files = ["{src:tb}/data/vec_{DEPTH}.hex"]')
    r = stages.simulate(p.ctx())                              # DEPTH = 4 (default): data/vec_4.hex does not exist
    assert r.status == "skipped" and "no testbench stimulus" in r.summary
    assert any(d.code == "STG004" and "vec_4.hex" in d.message for d in r.diagnostics)
    assert r.commands == []                                    # nothing was simulated


@needs_icarus
def test_data_file_present_runs_with_expanded_path(mk, tmp_path):
    import hashlib, zipfile
    p = mk(tb={"tb_top.sv": TB_MULTI}, synth=False, min_pass=1)
    arch = os.path.join(p.root, p.archive_rel)
    with zipfile.ZipFile(arch, "a") as z:
        z.writestr("data/vec_4.hex", "00\n")
    sha = hashlib.sha256(open(arch, "rb").read()).hexdigest()
    txt = open(os.path.join(p.cfgdir, "fx.toml")).read().replace(p.sha, sha)
    txt = txt.replace('glob = ["tb/*.sv"]', 'glob = ["tb/*.sv"]\nsupport = ["data/*.hex"]')
    txt = txt.replace("timeout_s = 60", 'timeout_s = 60\nplusargs = ["+test=good", "+VEC={src:tb}/data/vec_{DEPTH}.hex"]\ndata_files = ["{src:tb}/data/vec_{DEPTH}.hex"]')
    p.write_config(txt)
    ctx = p.ctx()
    r = stages.simulate(ctx)
    assert r.status == "passed", [d.render() for d in r.diagnostics]
    run_argv = r.commands[-1].argv
    assert any(a.startswith("+VEC=") and a.endswith("src/tb/data/vec_4.hex") for a in run_argv)
