"""Shared fixtures: build miniature repositories (real zip archives, pinned
hashes, TOML configuration) so each failure mode is exercised end to end."""
from __future__ import annotations

import hashlib
import io
import os
import shutil
import sys
import textwrap
import zipfile
from typing import Dict, Optional

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
FORGE = os.path.dirname(HERE)
sys.path.insert(0, FORGE)

from albion_forge import toolchain                      # noqa: E402
from albion_forge.build import BuildContext             # noqa: E402
from albion_forge.config import load_config             # noqa: E402
from albion_forge.diagnostics import DiagnosticSink     # noqa: E402

HAVE = {k: toolchain.detect(k).found for k in ("verilator", "icarus", "yosys", "vvp")}
needs_verilator = pytest.mark.skipif(not HAVE["verilator"], reason="verilator not installed")
needs_icarus = pytest.mark.skipif(not (HAVE["icarus"] and HAVE["vvp"]), reason="icarus not installed")
needs_yosys = pytest.mark.skipif(not HAVE["yosys"], reason="yosys not installed")
needs_all = pytest.mark.skipif(not all(HAVE[k] for k in ("verilator", "icarus", "yosys", "vvp")),
                               reason="verilator + icarus + yosys required")


# --------------------------------------------------------------------------
# tiny RTL used throughout
# --------------------------------------------------------------------------
LEAF = """\
module leaf #(parameter int W = 8) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [W-1:0] d,
  output logic [W-1:0] q
);
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) q <= '0;
    else        q <= d;
endmodule
"""

TOP = """\
module top #(
  parameter int W     = 8,
  parameter int DEPTH = 4
) (
  input  logic                          clk,
  input  logic                          rst_n,
  input  logic [W-1:0]                  d,
  output logic [W-1:0]                  q,
  output logic [$clog2(DEPTH+1)-1:0]    depth_o
);
  localparam int LAT = 1;
  logic [W-1:0] mid;
  leaf #(.W(W)) u_a (.clk, .rst_n, .d(d),   .q(mid));
  leaf #(.W(W)) u_b (.clk, .rst_n, .d(mid), .q(q));
  assign depth_o = ($clog2(DEPTH+1))'(DEPTH - LAT + LAT);
endmodule
"""

TB_GOOD = """\
`timescale 1ns/1ps
module tb_top;
  localparam int W = 8;
  logic clk = 0, rst_n = 0;
  logic [W-1:0] d, q;
  top dut (.clk, .rst_n, .d, .q, .depth_o());
  always #5 clk = ~clk;
  int n = 0;
  task automatic chk(input string name, input logic [W-1:0] got, input logic [W-1:0] exp);
    if (got === exp) begin $display("[PASS] %s", name); n++; end
    else $display("[FAIL] %s got %0d exp %0d", name, got, exp);
  endtask
  initial begin
    d = 8'h00; repeat (2) @(posedge clk); rst_n = 1;
    d = 8'h5a; repeat (3) @(posedge clk); #1 chk("pipeline-1", q, 8'h5a);
    d = 8'ha5; repeat (3) @(posedge clk); #1 chk("pipeline-2", q, 8'ha5);
    d = 8'hff; repeat (3) @(posedge clk); #1 chk("pipeline-3", q, 8'hff);
    $finish;
  end
endmodule
"""

# prints "ALL TESTS PASSED" but never checks anything (the real-world tb_silicaflux_top pattern)
TB_VACUOUS = """\
module tb_top;
  logic clk = 0;
  int pass_count = 0;
  top #() dut (.clk(clk), .rst_n(1'b1), .d('0), .q(), .depth_o());
  initial begin
    repeat (4) #5 clk = ~clk;
    $display("[INFO] observe waveforms");
    pass_count++;
    $display("ALL TESTS PASSED (%0d)", pass_count);
    $finish;
  end
endmodule
"""

TB_FAILING = TB_GOOD.replace('chk("pipeline-2", q, 8\'ha5)', 'chk("pipeline-2", q, 8\'h00)')


# --------------------------------------------------------------------------
class Proj:
    """A miniature repository on disk."""

    def __init__(self, root: str, name: str):
        self.root = root
        self.name = name
        self.cfgdir = os.path.join(root, "cfg")
        self.build = os.path.join(root, "build")
        os.makedirs(self.cfgdir, exist_ok=True)
        os.makedirs(self.build, exist_ok=True)
        self.archive_rel = "archives/fixture.zip"
        self.sha = ""

    def write_archive(self, members: Dict[str, str], extra_raw: Optional[Dict[str, bytes]] = None) -> str:
        os.makedirs(os.path.join(self.root, "archives"), exist_ok=True)
        path = os.path.join(self.root, self.archive_rel)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for n, t in sorted(members.items()):
                z.writestr(n, t)
            for n, b in (extra_raw or {}).items():
                z.writestr(n, b)
        self.sha = hashlib.sha256(open(path, "rb").read()).hexdigest()
        return self.sha

    def write_config(self, text: str) -> str:
        p = os.path.join(self.cfgdir, f"{self.name}.toml")
        with open(p, "w") as fh:
            fh.write(text)
        return p

    def load(self, sink: Optional[DiagnosticSink] = None):
        sink = sink or DiagnosticSink()
        return load_config(self.name, self.cfgdir, sink), sink

    def ctx(self, params=None, blocks=None, build_root: Optional[str] = None) -> BuildContext:
        cfg, sink = self.load()
        assert cfg is not None, [d.render() for d in sink.items]
        return BuildContext(cfg, self.root, build_root or self.build, params, blocks)


def config_text(name: str, sha: str, *, top: str = "top", rtl_glob: str = "rtl/*.sv", tb_glob: Optional[str] = "tb/*.sv",
                extra: str = "", sim: bool = True, params: bool = True, min_pass: int = 3, enabled: bool = True,
                blocker: str = "", synth: bool = True, lint_extra: str = "", engine: str = "icarus") -> str:
    t = f"""
schema_version = 1
[config]
name = "{name}"
title = "fixture"
category = "other"
enabled = {"true" if enabled else "false"}
"""
    if blocker:
        t += f'blocker = """{blocker}"""\n'
    t += f"""
[[source]]
id = "rtl"
role = "rtl"
archive = "archives/fixture.zip"
archive_sha256 = "{sha}"
glob = ["{rtl_glob}"]
incdirs = ["rtl"]
"""
    if tb_glob:
        t += f"""
[[source]]
id = "tb"
role = "tb"
archive = "archives/fixture.zip"
archive_sha256 = "{sha}"
glob = ["{tb_glob}"]
incdirs = ["rtl"]
"""
    t += f'\n[design]\ntop = "{top}"\n[clock]\nname = "clk"\nperiod_ns = 8.0\n'
    if params:
        t += """
[parameters.W]
rtl_name = "W"
type = "int"
default = 8
min = 1
max = 64
[parameters.DEPTH]
rtl_name = "DEPTH"
type = "int"
default = 4
choices = [2, 4, 8]
"""
    if sim:
        t += f"""
[simulate]
enabled = true
engine = "{engine}"
tb_top = "tb_top"
pass_regex = '^\\[PASS\\]'
fail_regex = '^\\[FAIL\\]'
min_pass = {min_pass}
timeout_s = 60
"""
    if synth:
        t += f'\n[synth]\nenabled = true\ntop = "{top}"\n'
    t += lint_extra + extra
    return t


@pytest.fixture
def mk(tmp_path):
    """Factory: mk(rtl={...}, tb={...}, **config_text kwargs) -> Proj"""

    def _mk(rtl: Optional[Dict[str, str]] = None, tb: Optional[Dict[str, str]] = None, name: str = "fx",
            raw: Optional[Dict[str, bytes]] = None, **kw) -> Proj:
        root = str(tmp_path / f"repo_{len(os.listdir(tmp_path))}")
        os.makedirs(root)
        p = Proj(root, name)
        members: Dict[str, str] = {}
        rtl_files = rtl if rtl is not None else {"leaf.sv": LEAF, "top.sv": TOP}
        tb_files = tb if tb is not None else {"tb_top.sv": TB_GOOD}
        for fn, txt in rtl_files.items():
            members[f"rtl/{fn}"] = txt
        for fn, txt in tb_files.items():
            members[f"tb/{fn}"] = txt
        sha = p.write_archive(members, raw)
        kw.setdefault("tb_glob", "tb/*.sv" if tb_files else None)
        if not tb_files:
            kw.setdefault("sim", False)
        p.write_config(config_text(name, sha, **kw))
        return p

    return _mk


def codes(items) -> list:
    return [d.code for d in items]
