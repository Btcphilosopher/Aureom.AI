"""Stage behaviour with the real EDA tools on tiny designs, including every
failure mode the forge must report with file / module attribution."""
import json
import os
import stat

import pytest

from albion_forge import stages
from albion_forge.diagnostics import Severity

from conftest import (LEAF, TB_FAILING, TB_GOOD, TB_VACUOUS, TOP, codes, needs_all, needs_icarus, needs_verilator,
                      needs_yosys)


def errs(res):
    return [d for d in res.diagnostics if d.severity >= Severity.ERROR]


# ====================================================================== success path
@needs_all
def test_successful_minimal_compilation_and_simulation(mk):
    p = mk()
    ctx = p.ctx()
    r_lint, r_elab = stages.lint(ctx), stages.elaborate(ctx)
    r_sim, r_syn = stages.simulate(ctx), stages.synth(ctx)
    for r in (r_lint, r_elab, r_sim, r_syn):
        assert r.status == "passed", (r.stage, r.summary, [d.render() for d in errs(r)])
    assert r_lint.metrics["warnings_unwaived"] == 0 and r_lint.metrics["files"] == 2
    assert set(r_elab.metrics["tools_run"]) == {"verilator", "icarus", "yosys"}
    assert r_sim.metrics["pass_markers"] == 3 and r_sim.metrics["fail_markers"] == 0
    assert r_syn.metrics["cells"] > 0 and r_syn.metrics["modules"] >= 1
    # evidence is recorded on disk, per stage
    for st in ("lint", "elaborate", "simulate", "synth"):
        data = json.load(open(os.path.join(ctx.build_dir, "results", f"{st}.json")))
        assert data["status"] == "passed" and data["commands"]
    # logs exist and the compile order file is deterministic and dependency-first
    files_f = open(os.path.join(ctx.build_dir, "lint", "files.f")).read().splitlines()
    srcs = [l for l in files_f if l.endswith(".sv")]
    assert srcs.index("src/rtl/rtl/leaf.sv") < srcs.index("src/rtl/rtl/top.sv")


# ====================================================================== lint policy
UNUSED = """\
module top #(parameter int W = 8, parameter int DEPTH = 4) (input logic clk, input logic rst_n,
  input logic [W-1:0] d, output logic [W-1:0] q);
  logic [W-1:0] dead;
  leaf #(.W(W)) u (.clk, .rst_n, .d, .q);
endmodule
"""


@needs_verilator
def test_lint_strict_policy_fails_on_warning_with_attribution(mk):
    p = mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False)
    r = stages.lint(p.ctx())
    assert r.status == "failed"
    e = [d for d in errs(r) if d.code == "STG002"]
    assert e and e[0].file == "rtl:rtl/top.sv" and e[0].module == "top" and e[0].line == 4 - 1 + 0 or e[0].line
    assert any("UNUSED" in d.message or "UNDRIVEN" in d.message for d in e)


@needs_verilator
def test_lint_waiver_with_reason_clears_warning_and_stale_waiver_warns(mk):
    waive = """
[[lint.waive]]
id = "UNUSEDSIGNAL"
scope = "rtl:rtl/top.sv"
reason = "scratch net kept for debug"
[[lint.waive]]
id = "WIDTHEXPAND"
scope = "*"
reason = "nothing matches this"
"""
    p = mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False, lint_extra=waive)
    r = stages.lint(p.ctx())
    # UNDRIVEN/UNUSED may both be reported; only assert on the waiver bookkeeping
    stale = [d for d in r.diagnostics if d.code == "STG006"]
    assert any("WIDTHEXPAND" in d.message and "stale" in d.message for d in stale)
    assert r.metrics["warnings_waived"] >= 1


@needs_verilator
def test_lint_waiver_budget_is_enforced(mk):
    waive = """
[[lint.waive]]
id = "UNUSEDSIGNAL"
scope = "*"
max_count = 0
reason = "budget of zero"
"""
    p = mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False, lint_extra=waive)
    r = stages.lint(p.ctx())
    assert any(d.code == "STG006" and "budget" in d.message for d in errs(r))


@needs_verilator
def test_lint_baseline_ratchet_allows_known_and_rejects_new(mk):
    p = mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False)
    strict = stages.lint(p.ctx())
    counts = strict.metrics["warnings_by_class"]
    assert counts
    ok_extra = "\n[lint]\nstrict = false\n[lint.baseline]\n" + "\n".join(f"{k} = {v}" for k, v in counts.items()) + "\n"
    p2 = mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False, name="fx2", lint_extra=ok_extra)
    r = stages.lint(p2.ctx())
    assert r.status == "passed" and r.metrics["policy"] == "ratchet", [d.render() for d in errs(r)]
    tight = "\n[lint]\nstrict = false\n[lint.baseline]\n" + "\n".join(f"{k} = 0" for k in counts) + "\n"
    p3 = mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False, name="fx3", lint_extra=tight)
    r3 = stages.lint(p3.ctx())
    assert r3.status == "failed" and any("exceed the baseline" in d.message for d in errs(r3))


@needs_verilator
def test_lint_werror_classes_in_ratchet_mode(mk):
    cls = list(stages.lint(mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False, name="a1").ctx()).metrics["warnings_by_class"])
    extra = f'\n[lint]\nstrict = false\nwerror_classes = {json.dumps(cls)}\n'
    p = mk(rtl={"leaf.sv": LEAF, "top.sv": UNUSED}, sim=False, name="a2", lint_extra=extra)
    assert stages.lint(p.ctx()).status == "failed"


# ====================================================================== tool errors attributed to file / module
@needs_verilator
@needs_icarus
def test_syntax_error_is_attributed_to_file_line_module(mk):
    bad = "module top(input logic clk);\n  logic a\n  assign a = 1'b1;\nendmodule\n"
    p = mk(rtl={"top.sv": bad}, sim=False, synth=False, params=False)
    r = stages.elaborate(p.ctx())
    assert r.status == "failed"
    located = [d for d in errs(r) if d.file == "rtl:rtl/top.sv"]
    assert located and all(d.line is not None for d in located)
    assert any(d.module == "top" for d in located)


@needs_verilator
def test_missing_module_fails_before_any_tool_runs(mk):
    top = "module top(input logic clk); ghost u_ghost (.clk(clk)); endmodule\n"
    p = mk(rtl={"top.sv": top}, sim=False, synth=False, params=False)
    ctx = p.ctx()
    for fn in (stages.lint, stages.elaborate):
        r = fn(ctx)
        assert r.status == "failed" and r.commands == []                 # no tool was invoked
        (d,) = [x for x in errs(r) if x.code == "DEP001"]
        assert d.file == "rtl:rtl/top.sv" and d.module == "top" and d.line == 1 and "ghost" in d.message


@needs_verilator
def test_circular_dependency_fails_with_path(mk):
    rtl = {"a.sv": "module top; b u(); endmodule", "b.sv": "module b; top u(); endmodule"}
    p = mk(rtl=rtl, sim=False, synth=False, params=False)
    r = stages.elaborate(p.ctx())
    assert r.status == "failed" and any(d.code == "DEP003" and "b -> top -> b" in d.message for d in errs(r))


@needs_verilator
def test_duplicate_definitions_fail(mk):
    rtl = {"leaf.sv": LEAF, "leaf2.sv": LEAF.replace("q <= d", "q <= ~d"), "top.sv": TOP}
    p = mk(rtl=rtl, sim=False, synth=False)
    r = stages.lint(p.ctx())
    assert r.status == "failed"
    (d,) = [x for x in errs(r) if x.code == "DEP004"]
    assert d.module == "leaf" and "leaf.sv" in d.message and "leaf2.sv" in d.message


# ====================================================================== unsupported constructs
@needs_verilator
def test_unsupported_construct_in_rtl_is_rejected(mk):
    cls = LEAF.replace("endmodule", "  class helper; endclass\nendmodule")
    p = mk(rtl={"leaf.sv": cls, "top.sv": TOP}, sim=False, synth=False)
    r = stages.elaborate(p.ctx())
    assert r.status == "failed"
    (d,) = [x for x in errs(r) if x.code == "LNG001"]
    assert d.file == "rtl:rtl/leaf.sv" and d.module == "leaf" and "class" in d.message


@needs_verilator
def test_same_construct_is_fine_in_a_testbench_role(mk):
    tb = TB_GOOD.replace("endmodule", "  class helper; endclass\nendmodule")
    p = mk(tb={"tb_top.sv": tb}, synth=False)
    r = stages.simulate(p.ctx())
    assert not [d for d in r.diagnostics if d.code == "LNG001"]


@needs_yosys
def test_sim_only_constructs_in_synthesizable_rtl_warn_or_error(mk):
    rtl = LEAF.replace("endmodule", "  initial $display(\"hi\");\nendmodule")
    p = mk(rtl={"leaf.sv": rtl, "top.sv": TOP}, sim=False)
    r = stages.synth(p.ctx())
    assert any(d.code == "LNG002" and d.severity == Severity.WARNING and d.module == "leaf" for d in r.diagnostics)
    p2 = mk(rtl={"leaf.sv": rtl, "top.sv": TOP}, sim=False, name="fx2", extra='\n[language]\nsim_only_action = "error"\n')
    r2 = stages.synth(p2.ctx())
    assert r2.status == "failed" and any(d.code == "LNG002" for d in errs(r2))


@needs_yosys
def test_known_yosys_033_parser_limitation_is_reported_not_hidden(mk):
    """`return {{N{x}}, y};` is rejected by Yosys 0.33 (found in the v1.0 SilicaFlux package)."""
    rtl = """\
module top(input logic [3:0] a, output logic [7:0] y);
  function automatic logic [7:0] sext(input logic [3:0] x);
    return {{4{x[3]}}, x};
  endfunction
  assign y = sext(a);
endmodule
"""
    p = mk(rtl={"top.sv": rtl}, sim=False, params=False)
    ctx = p.ctx()
    r = stages.synth(ctx)
    from albion_forge.toolchain import detect
    if tuple(int(x) for x in detect("yosys").version.split(".")[:2]) >= (0, 34):
        pytest.skip("this Yosys accepts the construct")
    assert r.status == "failed"
    assert any(d.code == "STG001" and d.file == "rtl:rtl/top.sv" and d.line == 3 for d in errs(r))


# ====================================================================== parameters against the real RTL
@needs_verilator
def test_unknown_and_localparam_overrides_are_rejected_against_rtl(mk):
    p = mk(rtl={"leaf.sv": LEAF, "top.sv": TOP}, sim=False, synth=False, extra="""
[parameters.LAT]
rtl_name = "LAT"
default = 1
[parameters.NOPE]
rtl_name = "NOPE"
default = 1
""")
    r = stages.lint(p.ctx())
    got = {d.code: d for d in errs(r)}
    assert "PAR001" in got and "NOPE" in got["PAR001"].message and got["PAR001"].module == "top"
    assert "PAR002" in got and "LAT" in got["PAR002"].message and "localparam" in got["PAR002"].message


@needs_verilator
@needs_icarus
@needs_yosys
def test_valid_parameter_override_reaches_every_tool(mk):
    p = mk(sim=False)
    ctx = p.ctx(params={"W": "16", "DEPTH": "8"})
    assert stages.lint(ctx).status == "passed"
    r = stages.elaborate(ctx)
    assert r.status == "passed" and r.metrics["design_parameters"] == {"W": 16, "DEPTH": 8}
    argvs = [" ".join(c.argv) for c in r.commands]
    assert any("-GW=16" in a for a in argvs) and any("top.W=16" in a for a in argvs)
    ys = open(os.path.join(ctx.build_dir, "elaborate", "elab.ys")).read()
    assert ys.count("chparam") == 1 and "-set W 16" in ys and "-set DEPTH 8" in ys
    assert "verilog_defaults -add -sv -defer" in ys
    assert stages.synth(ctx).status == "passed"
    assert ctx.build_dir.endswith(ctx.tag) and ctx.tag.startswith("o-")        # overrides get their own output dir


@needs_icarus
def test_parameters_the_testbench_cannot_route_skip_simulation_instead_of_lying(mk):
    p = mk(synth=False)
    r = stages.simulate(p.ctx(params={"W": "16"}))
    assert r.status == "skipped" and "cannot be routed" in r.summary
    assert any(d.code == "STG004" for d in r.diagnostics)


# ====================================================================== simulation needs positive evidence
@needs_icarus
def test_vacuous_testbench_cannot_pass(mk):
    p = mk(tb={"tb_top.sv": TB_VACUOUS}, synth=False)
    r = stages.simulate(p.ctx())
    assert r.status == "failed"
    assert any(d.code == "STG003" and "only 0 individual PASS marker" in d.message for d in errs(r))
    assert "ALL TESTS PASSED" in open(os.path.join(p.ctx().build_dir, "simulate", "run.log")).read()


@needs_icarus
def test_failing_testbench_fails(mk):
    p = mk(tb={"tb_top.sv": TB_FAILING}, synth=False)
    r = stages.simulate(p.ctx())
    assert r.status == "failed" and r.metrics["fail_markers"] == 1 and r.metrics["pass_markers"] == 2


@needs_icarus
def test_min_pass_guards_against_check_erosion(mk):
    p = mk(synth=False, min_pass=4)                      # TB prints 3
    r = stages.simulate(p.ctx())
    assert r.status == "failed" and "at least 4 required" in r.summary


@needs_icarus
def test_simulation_timeout_is_a_failure(mk):
    hang = "module tb_top; top dut(.clk(1'b0), .rst_n(1'b1), .d('0), .q(), .depth_o()); initial begin forever #1; end endmodule\n"
    p = mk(tb={"tb_top.sv": hang}, synth=False)
    txt = open(os.path.join(p.cfgdir, "fx.toml")).read().replace("timeout_s = 60", "timeout_s = 2")
    p.write_config(txt)
    r = stages.simulate(p.ctx())
    assert r.status == "failed" and "timed out" in r.summary


@needs_verilator
def test_verilator_engine_simulation(mk):
    p = mk(synth=False, engine="verilator")
    r = stages.simulate(p.ctx())
    assert r.status == "passed", [d.render() for d in errs(r)]
    assert r.metrics["engine"] == "verilator" and r.metrics["pass_markers"] == 3


# ====================================================================== missing / outdated tools are never a pass
def _fake_tool(tmp_path, name, body):
    path = tmp_path / name
    path.write_text("#!/bin/sh\n" + body + "\n")
    path.chmod(path.stat().st_mode | stat.S_IEXEC)
    return str(path)


def test_missing_required_tool_blocks_instead_of_passing(mk, monkeypatch):
    p = mk(sim=False, synth=False)
    monkeypatch.setenv("ALBION_TOOL_VERILATOR", "/nonexistent/verilator")
    r = stages.lint(p.ctx())
    assert r.status == "blocked" and any(d.code == "TLS001" and "verilator" in d.message for d in r.diagnostics)
    assert r.commands == []


def test_outdated_tool_blocks_with_version_message(mk, monkeypatch, tmp_path):
    fake = _fake_tool(tmp_path, "verilator", 'echo "Verilator 3.9 2020-01-01"')
    monkeypatch.setenv("ALBION_TOOL_VERILATOR", fake)
    p = mk(sim=False, synth=False)
    r = stages.lint(p.ctx())
    assert r.status == "blocked"
    assert any(d.code == "TLS002" and "3.9" in d.message and "older than the minimum 5.0" in d.message for d in r.diagnostics)


def test_elaboration_with_no_available_tool_is_blocked(mk, monkeypatch):
    for t in ("VERILATOR", "ICARUS", "YOSYS"):
        monkeypatch.setenv(f"ALBION_TOOL_{t}", "/nonexistent")
    p = mk(sim=False, synth=False)
    r = stages.elaborate(p.ctx())
    assert r.status == "blocked" and "no elaboration tool" in r.summary


@needs_yosys
def test_missing_optional_sta_tool_is_skipped_not_passed(mk, monkeypatch):
    monkeypatch.setenv("ALBION_TOOL_OPENSTA", "/nonexistent")
    monkeypatch.setenv("ALBION_TOOL_OPENROAD", "/nonexistent")
    p = mk(sim=False)
    r = stages.synth(p.ctx())
    assert r.status == "passed" and r.metrics["sta"].startswith("skipped")
    assert any(d.code == "TLS003" and "NOT passed" in d.message for d in r.diagnostics)
    assert r.metrics["clock_target_applied"] is False


@needs_yosys
def test_sta_stub_script_generation_and_wns_parsing(mk, monkeypatch, tmp_path):
    """OpenSTA is not installed here: this exercises script generation and result
    parsing against a *stub* executable only.  It is not evidence about real STA."""
    stub = _fake_tool(tmp_path, "sta", 'if [ "$1" = "-version" ]; then echo "2.5.0"; exit 0; fi\n'
                                         'echo "wns -0.42"; echo "tns -1.5"')
    monkeypatch.setenv("ALBION_TOOL_OPENSTA", stub)
    lib = tmp_path / "fake.lib"
    lib.write_text("library(fake){}")
    p = mk(sim=False, extra=f'\n[sta]\nliberty = "{lib}"\n')
    r = stages.synth(p.ctx())
    tcl = open(os.path.join(p.ctx().build_dir, "synth", "sta.tcl")).read()
    assert "read_liberty" in tcl and "read_sdc" in tcl and "link_design top" in tcl
    sdc = open(os.path.join(p.ctx().build_dir, "synth", "constraints.sdc")).read()
    assert "create_clock -name clk -period 8" in sdc
    assert r.metrics["wns"] == -0.42 and r.status == "failed"
    assert any("timing not met" in d.message for d in errs(r))


@needs_verilator
def test_one_bit_parameters_are_passed_as_sized_literals(mk):
    """`-GEN=1` is a 32-bit constant: for a `parameter bit EN` Verilator emits WIDTHTRUNC, a warning the
    RTL did not earn.  The forge must read the declared type and pass 1'b1 / 1'b0."""
    rtl = {"top.sv": "module top #(parameter bit EN = 1'b0)(input logic a, output logic y);\n  assign y = EN ? a : 1'b0;\nendmodule\n"}
    p = mk(rtl=rtl, sim=False, synth=False, params=False, extra="""
[blocks.en]
param = "EN"
default = false
""")
    ctx = p.ctx(blocks={"en": "on"})
    r = stages.lint(ctx)
    assert r.status == "passed", [d.render() for d in errs(r)]
    assert any("-GEN=1'b1" in " ".join(c.argv) for c in r.commands)


@needs_icarus
def test_a_single_fail_marker_fails_the_run_even_with_enough_pass_markers(mk):
    """Independent of min_pass: 3 PASS markers (the required minimum) plus one FAIL line must still fail."""
    tb = TB_GOOD.replace("    $finish;", '    chk("always-wrong", 8\'h00, 8\'h01);\n    $finish;')
    p = mk(tb={"tb_top.sv": tb}, synth=False, min_pass=3)
    r = stages.simulate(p.ctx())
    assert r.metrics["pass_markers"] == 3 and r.metrics["fail_markers"] == 1       # min_pass alone would be satisfied
    assert r.status == "failed" and "1 failure marker" in r.summary
