"""Unit tests of the structural scanner (no EDA tools needed)."""
from albion_forge.sv_scan import classify_sf, scan_text, strip_comments


def names(r):
    return [(d.kind, d.name) for d in r.decls]


def test_declarations_params_and_ports():
    r = scan_text("a.sv", """
      package p; localparam int X = 3; endpackage
      module m #(parameter int W = 8, parameter logic [3:0] K = 4'hA, localparam int L = W*2)
        (input logic clk, input logic [W-1:0] d, output logic q);
      endmodule
      interface bus_if(input logic clk); endinterface
    """)
    assert names(r) == [("package", "p"), ("module", "m"), ("interface", "bus_if")]
    m = r.decls[1]
    assert [(p.name, p.kind) for p in m.params] == [("W", "parameter"), ("K", "parameter"), ("L", "localparam")]
    assert m.params[0].default == "8"
    assert m.ports == ["clk", "d", "q"]
    assert m.line == 3 and m.end_line == 5


def test_instances_with_named_and_positional_overrides():
    r = scan_text("a.sv", """
      module top; logic c;
        leaf #(.W(8), .D(2)) u0 (.c(c));
        leaf #(8) u1 (c);
        leaf u2 (c), u3 (c);
        if (1) begin : g
          other u4 (.x(c));
        end
      endmodule
    """)
    got = [(i.target, i.inst_name, i.overrides, i.positional_overrides) for i in r.instances]
    assert ("leaf", "u0", ("W", "D"), 0) in got
    assert ("leaf", "u1", (), 1) in got
    assert {"u2", "u3", "u4"} <= {g[1] for g in got}


def test_keywords_and_gates_are_not_instances():
    r = scan_text("a.sv", """
      module m(input a, b, output y);
        and g1 (y, a, b);
        assign y2 = a;
        always_ff @(posedge a) begin y <= b; end
        typedef logic [3:0] nib_t;
        nib_t x;
        wire w = a;
      endmodule
    """)
    assert r.instances == []


def test_comments_strings_do_not_create_declarations():
    r = scan_text("a.sv", '''
      // module ghost; endmodule
      /* module ghost2; endmodule */
      module real_one; initial $display("module fake_in_string;"); endmodule
    ''')
    assert names(r) == [("module", "real_one")]
    assert strip_comments("a // b\nc").count("\n") == 1          # line numbers preserved


def test_package_references_import_and_scope_including_header():
    r = scan_text("a.sv", """
      module m #(parameter int W = pkg_a::W2) (input pkg_b::t_e e);
        import pkg_c::*;
        localparam int Q = pkg_d::K;
      endmodule
    """)
    got = {(x.package, x.form) for x in r.refs}
    assert {("pkg_a", "scope"), ("pkg_b", "scope"), ("pkg_c", "import"), ("pkg_d", "scope")} <= got


def test_ifdef_selects_branches_and_defines():
    src = """
      `ifdef FAST
        module fast; endmodule
      `else
        module slow; endmodule
      `endif
    """
    assert names(scan_text("a.sv", src)) == [("module", "slow")]
    assert names(scan_text("a.sv", src, defines={"FAST": "1"})) == [("module", "fast")]
    inner = scan_text("a.sv", "`define FAST\n" + src)
    assert names(inner) == [("module", "fast")]


def test_include_resolution_with_virtual_fs_and_unresolved():
    vfs = {"/d/inc.svh": "package inc_pkg; endpackage"}
    r = scan_text("/d/a.sv", '`include "inc.svh"\nmodule m; endmodule', vfs=vfs)
    assert [(d.name, d.file) for d in r.decls] == [("inc_pkg", "/d/inc.svh"), ("m", "/d/a.sv")]
    r2 = scan_text("/d/a.sv", '`include "nope.svh"\nmodule m; endmodule', vfs=vfs)
    assert r2.includes[0][2] is None


def test_instances_inside_macro_bodies_are_soft_dependencies():
    r = scan_text("a.sv", """
      module m;
      `define SLOT(K) \\
        if (K < 2) begin : u_``K \\
          child #(.W(8)) u_c (.clk(clk)); \\
        end
      endmodule
    """)
    soft = [i for i in r.instances if i.via_macro]
    assert [(i.target, i.inst_name) for i in soft] == [("child", "u_c")]


def test_construct_classification():
    r = scan_text("a.sv", """
      module m;
        class c; endclass
        initial begin #5; $display("x"); fork join end
        covergroup cg; endgroup
        assert property (@(posedge clk) a |-> b);
        initial $fatal(1, "x");
      endmodule
    """)
    cats = {f.category for f in r.findings}
    assert {"class", "initial_block", "delay", "system_task", "fork_join", "covergroup",
            "concurrent_assertion", "severity_task"} <= cats


def test_unbalanced_unit_is_reported():
    r = scan_text("a.sv", "module m; wire a;")
    assert r.parse_errors and "no matching end" in r.parse_errors[0][1]


def test_sf_dialect_classifier():
    assert classify_sf("// hdr\npackage silicaflux_pkg;\nendpackage") == "sv"
    assert classify_sf("module alu #(parameter int W=8)(input logic a); endmodule") == "sv"
    assert classify_sf("package silicaflux.ml\nfixed Fixed16_16 { int_bits: 16 }") == "dsl"
    assert classify_sf("module Core(DATA_W: UInt = 32) {\n state machine X {} }\nfixed T { a: 1 }") == "dsl"


def test_body_parameters_follow_ieee_override_rules():
    r = scan_text("a.sv", """
      module with_ports #(parameter int W = 8) (input logic a);
        localparam int LAT = 1;
        parameter int B = 2, C = 3;     // localparam: module has a parameter port list (IEEE 1800-2017 6.20.1)
      endmodule
      module no_ports (input logic a);
        parameter int P = 5;            // overridable
        localparam Q = 2;
      endmodule
    """)
    kinds = {d.name: {p.name: p.kind for p in d.params} for d in r.decls}
    assert kinds["with_ports"] == {"W": "parameter", "LAT": "localparam", "B": "localparam", "C": "localparam"}
    assert kinds["no_ports"] == {"P": "parameter", "Q": "localparam"}
