"""Invalid configurations and parameter errors."""
import textwrap

import pytest

from albion_forge.config import (apply_overrides, check_param_value, load_config, parse_overrides,
                                 rtl_parameter_map, safe_eval, ParamSpec)
from albion_forge.diagnostics import DiagnosticSink

from conftest import codes, config_text

SHA = "0" * 64


def load(tmp_path, text, name="c"):
    d = tmp_path / "cfg"
    d.mkdir(exist_ok=True)
    (d / f"{name}.toml").write_text(text)
    sink = DiagnosticSink()
    return load_config(name, str(d), sink), sink


def good(**kw):
    return config_text("c", SHA, **kw)


# ---------------------------------------------------------------------- structure / schema
def test_good_config_loads(tmp_path):
    cfg, sink = load(tmp_path, good())
    assert cfg is not None and not sink.items
    assert cfg.top == "top" and set(cfg.params) == {"W", "DEPTH"}


def test_missing_file_lists_available(tmp_path):
    sink = DiagnosticSink()
    assert load_config("nope", str(tmp_path), sink) is None
    assert codes(sink.errors) == ["CFG003"]


def test_invalid_toml(tmp_path):
    cfg, sink = load(tmp_path, "this is = = not toml")
    assert cfg is None and codes(sink.errors) == ["CFG001"]


@pytest.mark.parametrize("mutate,expect", [
    (lambda t: t.replace("schema_version = 1", "schema_version = 2"), "schema_version"),
    (lambda t: t.replace('title = "fixture"', 'titel = "fixture"'), "unknown key 'titel'"),
    (lambda t: t.replace('category = "other"', 'category = "gpu"'), "category"),
    (lambda t: t.replace('role = "rtl"', 'role = "magic"'), "role"),
    (lambda t: t.replace('archive_sha256 = "' + SHA + '"', 'archive_sha256 = "abc"', 1), "64-hex"),
    (lambda t: t.replace('top = "top"', 'top = "1bad"', 1), "[design].top"),
    (lambda t: t + '\n[bogus]\nx = 1\n', "unknown key 'bogus'"),
])
def test_schema_violations(tmp_path, mutate, expect):
    cfg, sink = load(tmp_path, mutate(good()))
    assert cfg is None
    assert any(expect in d.message for d in sink.errors), [d.message for d in sink.errors]
    assert all(d.code in ("CFG002",) for d in sink.errors)


def test_name_must_match_file(tmp_path):
    cfg, sink = load(tmp_path, good().replace('name = "c"', 'name = "other"'))
    assert cfg is None and "must equal the file name" in sink.errors[0].message


def test_unpinned_archive_is_rejected(tmp_path):
    cfg, sink = load(tmp_path, good().replace('archive_sha256 = "' + SHA + '"\n', "", 1))
    assert cfg is None and "pin `archive_sha256`" in sink.errors[0].message


def test_source_needs_exactly_one_origin_and_a_selection(tmp_path):
    t = good().replace('archive = "archives/fixture.zip"\n', 'archive = "a.zip"\npath = "dir"\n', 1)
    cfg, sink = load(tmp_path, t)
    assert cfg is None and "exactly one of" in sink.errors[0].message
    t2 = good().replace('glob = ["rtl/*.sv"]', "")
    cfg, sink = load(tmp_path, t2)
    assert cfg is None and "`files` and/or `glob`" in " ".join(d.message for d in sink.errors)


# ---------------------------------------------------------------------- enabled / blocker honesty
def test_disabled_config_requires_a_blocker(tmp_path):
    cfg, sink = load(tmp_path, good(enabled=False))
    assert cfg is None and codes(sink.errors) == ["CFG004"]
    cfg, sink = load(tmp_path, good(enabled=False, blocker="no RTL exists"))
    assert cfg is not None and cfg.blocker == "no RTL exists" and not cfg.enabled


def test_enabled_config_must_not_carry_a_blocker(tmp_path):
    cfg, sink = load(tmp_path, good(blocker="still broken"))
    assert cfg is None and codes(sink.errors) == ["CFG004"]


def test_enabled_config_needs_a_source(tmp_path):
    text = "schema_version = 1\n[config]\nname = \"c\"\ntitle = \"t\"\nenabled = true\n[design]\ntop = \"x\"\n"
    cfg, sink = load(tmp_path, text)
    assert cfg is None and "at least one [[source]]" in " ".join(d.message for d in sink.errors)


# ---------------------------------------------------------------------- clock
@pytest.mark.parametrize("period", ["0", "-3.5", "0.0", '"fast"', "true", "1e9"])
def test_invalid_clock_period(tmp_path, period):
    cfg, sink = load(tmp_path, good().replace("period_ns = 8.0", f"period_ns = {period}"))
    assert cfg is None and "CFG007" in codes(sink.errors)


# ---------------------------------------------------------------------- parameters / blocks / simulate
def test_parameter_default_must_satisfy_its_own_constraints(tmp_path):
    cfg, sink = load(tmp_path, good().replace("default = 8\nmin = 1", "default = 128\nmin = 1"))
    assert cfg is None and "CFG005" in codes(sink.errors)


def test_parameter_type_and_unknown_keys(tmp_path):
    cfg, sink = load(tmp_path, good().replace('type = "int"', 'type = "float"', 1))
    assert cfg is None
    cfg, sink = load(tmp_path, good().replace('rtl_name = "W"', 'rtl_nam = "W"'))
    assert cfg is None and "unknown key 'rtl_nam'" in sink.errors[0].message


def test_block_references_and_requirements(tmp_path):
    t = good() + '\n[blocks.a]\nparam = "EN_A"\nrequires = ["ghost"]\n'
    cfg, sink = load(tmp_path, t)
    assert cfg is None and codes(sink.errors) == ["CFG006"]


def test_simulate_demands_positive_evidence(tmp_path):
    cfg, sink = load(tmp_path, good(min_pass=0))
    assert cfg is None and "min_pass" in sink.errors[0].message and "not a pass" in sink.errors[0].message
    cfg, sink = load(tmp_path, good().replace("pass_regex = '^\\[PASS\\]'\n", ""))
    assert cfg is None and "pass_regex is required" in sink.errors[0].message
    cfg, sink = load(tmp_path, good().replace("pass_regex = '^\\[PASS\\]'", "pass_regex = '(unclosed'"))
    assert cfg is None and "not a valid regex" in sink.errors[0].message


def test_simulate_needs_a_tb_source(tmp_path):
    cfg, sink = load(tmp_path, good(tb_glob=None))
    assert cfg is None and 'role = "tb"' in " ".join(d.message for d in sink.errors)


def test_lint_waiver_requires_a_reason(tmp_path):
    t = good() + '\n[[lint.waive]]\nid = "UNUSEDSIGNAL"\nscope = "*"\nreason = "  "\n'
    cfg, sink = load(tmp_path, t)
    assert cfg is None and codes(sink.errors) == ["STG006"]


# ---------------------------------------------------------------------- overrides (parameter errors)
@pytest.fixture
def cfg(tmp_path):
    t = good() + '\n[[constraints]]\nexpr = "W % 8 == 0"\nmessage = "W must be a byte multiple"\n'
    t += '\n[blocks.fifo]\nparam = "EN_FIFO"\ndefault = true\n[blocks.dma]\nparam = "EN_DMA"\ndefault = false\nrequires = ["fifo"]\n'
    t += '[blocks.alt]\nparam = "EN_ALT"\ndefault = false\nconflicts = ["fifo"]\n'
    c, sink = load(tmp_path, t)
    assert c is not None, [d.render() for d in sink.errors]
    return c


def apply(cfg, p=(), b=()):
    sink = DiagnosticSink()
    ov = parse_overrides(list(p), sink)
    bv = parse_overrides(list(b), sink, "block")
    vals = apply_overrides(cfg, ov, bv, sink)
    return vals, sink


def test_defaults_and_valid_override(cfg):
    vals, sink = apply(cfg, ["W=16", "DEPTH=8"])
    assert not sink.errors and vals["W"] == 16 and vals["DEPTH"] == 8
    assert rtl_parameter_map(cfg, vals)["design"] == {"W": 16, "DEPTH": 8, "EN_FIFO": 1, "EN_DMA": 0, "EN_ALT": 0}


def test_unknown_parameter_override(cfg):
    _, sink = apply(cfg, ["BOGUS=3"])
    assert codes(sink.errors) == ["CFG005"] and "BOGUS" in sink.errors[0].message


@pytest.mark.parametrize("kv,frag", [("W=0", ">= 1"), ("W=65", "<= 64"), ("DEPTH=3", "one of [2, 4, 8]"),
                                     ("W=abc", "cannot interpret"), ("W=8.5", "cannot interpret")])
def test_out_of_range_and_wrong_type(cfg, kv, frag):
    _, sink = apply(cfg, [kv])
    assert sink.errors and frag in sink.errors[0].message


def test_cross_parameter_constraint(cfg):
    _, sink = apply(cfg, ["W=12"])
    assert codes(sink.errors) == ["PAR003"] and "byte multiple" in sink.errors[0].message


def test_malformed_override_syntax():
    sink = DiagnosticSink()
    parse_overrides(["W"], sink)
    assert codes(sink.errors) == ["CFG005"]


def test_block_requires_and_conflicts(cfg):
    _, sink = apply(cfg, b=["dma=on", "fifo=off"])
    assert any("requires block 'fifo'" in d.message for d in sink.errors)
    _, sink = apply(cfg, b=["alt=on"])
    assert any("conflicts with block 'fifo'" in d.message for d in sink.errors)
    _, sink = apply(cfg, b=["nothere=on"])
    assert codes(sink.errors) == ["CFG006"]
    vals, sink = apply(cfg, b=["dma=on"])
    assert not sink.errors and vals["block:dma"] is True


def test_check_param_value_primitives():
    p = ParamSpec("X", "X", pow2=True, min=2, multiple_of=2)
    assert check_param_value(p, 8) is None
    assert "power of two" in check_param_value(p, 6)
    assert "integer" in check_param_value(p, True)
    b = ParamSpec("B", "B", type="bool", default=False)
    assert check_param_value(b, 1) is None and "boolean" in check_param_value(b, 7)


# ---------------------------------------------------------------------- safe constraint evaluator
def test_safe_eval_allows_arithmetic_only():
    assert safe_eval("clog2(W) <= 4 and W % 2 == 0", {"W": 8}) is True
    for evil in ("__import__('os').system('true')", "W.__class__", "open('x')", "[1][0]", "W if W else 0"):
        with pytest.raises(ValueError):
            safe_eval(evil, {"W": 1})
