# AlbionForge: RTL build, dependency-management and verification infrastructure for SilicaFlux

AlbionForge compiles, lints, elaborates, simulates and synthesizes the SystemVerilog in the SilicaFlux repository from
**SHA-pinned source archives**, with machine-readable configurations, validated parameters, deterministic ordering,
build manifests and CI. It runs the real open-source tools and **never reports a result a tool did not produce**.

> Name clash, on purpose explained: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/albionforge-0.1.0.zip` is an *earlier SoC integration
> project* with the same name. Here it is just one design under test (`albion_soc`); this directory is the build infrastructure.

## One command

```bash
# 1. dependencies (Ubuntu 24.04; Python >= 3.11 for tomllib)
sudo apt-get install -y verilator iverilog yosys make g++ python3 python3-pytest git

# 2. from the repository root: build, simulate, synthesize every enabled configuration and write the reports
tools/albion_forge/albion ci
```

Faster, one configuration (seconds to a few minutes):

```bash
tools/albion_forge/albion ci --config smoke --reproduce      # builds twice from scratch and compares digests
```

Results: `build/albion/reports/BUILD_REPORT.md` (status matrix), `junit.xml`, and per configuration `build/albion/<config>/default/manifest.json`
plus every raw tool log. Exit status `0` = everything passed, `1` = a failure, `3` = blocked (e.g. a required tool is missing).

`tools/albion_forge/albion doctor` tells you what is installed and what is missing; a missing tool **blocks or skips** its stages and is never a pass.

## Commands

| command | does |
|---|---|
| `albion list` | configurations, whether actual RTL supports them (`enabled`) or why not (`DISABLED` + blocker) |
| `albion doctor` | detect Verilator, Icarus, Yosys, OpenSTA, OpenROAD, pytest; versions; install hints |
| `albion lint -c NAME` | Verilator `-Wall`, strict policy with justified, budgeted waivers (or a baseline ratchet) |
| `albion elaborate -c NAME` | elaborate with every configured tool (Verilator, Icarus, Yosys) |
| `albion simulate -c NAME` | self-checking testbench; passes only on positive evidence (`min_pass`) |
| `albion synth -c NAME` | Yosys generic synthesis; OpenSTA/OpenROAD only if installed **and** a liberty is configured |
| `albion test` | forge self-tests (pytest) + design regression (`--forge-only`, `--design-only`) |
| `albion report` | render Markdown / JSON / JUnit from *recorded* results (a stage never run shows `NOT RUN`) |
| `albion ci` | all of the above for every enabled configuration, then tests and reports (`--reproduce`, `--allow-missing-tools`, `--fail-fast`) |
| `albion inventory` | forensic inventory of the whole repository into `reports/` |
| `albion pin FILE...` | SHA-256 for `archive_sha256` |
| `albion codes` | the diagnostic-code registry |

Common options: `-c/--config NAME` (repeatable), `--all`, `-P NAME=VALUE` (parameter override), `-B block=on|off` (optional accelerator block),
`--json`, `-v`, `--repo`, `--build-root`.

```bash
albion simulate --config tensor -P ARRAY_ROWS=4 -P ARRAY_COLS=1      # a different array shape
albion synth    --config dma    -P ENGINE=1 -P DW=128 -P FIFO_DEPTH=16
albion synth    --config vector -P NUM_LANES=4 -B reduction=off      # drop an optional block
albion simulate --config vector_v1 -P LANES=16                       # FAILS: documents a real RTL defect (KNOWN_BLOCKERS B-05)
```

## Configurations

| config | category | design top | what supports it |
|---|---|---|---|
| `smoke` | smoke | `sf_albion_fifo` | AlbionCore FIFO + its swept testbench (6.66 M checks) |
| `riscv_core` | riscv_core | `silicaflux_control_core` | ControlCore (RV32) system simulation, shipped firmware |
| `sram` | sram | `sram_sp` | SRAM wrapper, depth / width / mask / latency sweep |
| `datafabric` | datafabric | `sfb_crossbar` | SFB2 crossbar, ports / width / arbitration sweep |
| `dma` | dma | `hpc_dma_adapter` | DMA adapter + engine + scratchpad system testbench |
| `vector` | vector | `hpc_vector_array` | HPC vector array, lanes and optional reduction / perf blocks (no simulation, B-06) |
| `vector_v1` | vector | `vector_engine` | v1.0 SIMD engine, forge-owned lane-generic testbench (finds B-05) |
| `tensor` | tensor | `tensor_systolic_array` | systolic array, shape / width sweep with shipped numpy-oracle vectors |
| `albion_soc` | soc | `sf_albion_soc_min` | the minimum Albion cloud SoC, shipped firmware |

Only configurations backed by RTL that a real tool confirmed are enabled. A target without supporting RTL is declared `enabled = false` with a `blocker`
(`configs/examples/blocked_target.toml`). See `docs/CONFIGURATION.md` and the annotated `configs/examples/annotated_full.toml`.

## Last verified run (shipped in `reports/`)

One `albion ci` over all nine configurations: **exit 0, 24 min 19 s** on 4 cores, Verilator 5.020 · Icarus 12.0 · Yosys 0.33, 174 forge self-tests passed
(the suite has grown since). Measured values; `skipped` = not claimed (reason in `docs/KNOWN_BLOCKERS.md`).

| config | lint (unwaived / waived) | elaborate with | simulate | synth (Yosys generic cells) |
|---|---|---|---|---|
| `smoke` | 0 / 0 | verilator, icarus, yosys | verilator: PASS, 6,662,220 checks, 0 errors | 106 |
| `riscv_core` | 0 / 286 | verilator, icarus, yosys | verilator: 4 scenarios PASS (197 s) | 1,936,305 (992 s) |
| `sram` | 0 / 1 | verilator, icarus, yosys | verilator: 3 seeds PASS | 71,052 |
| `datafabric` | 0 / 0 | verilator, icarus, yosys | verilator: 5 scenarios PASS | 2,008 |
| `dma` | 0 / 0 | verilator, icarus, yosys | verilator: 8 scenarios PASS | 8,289 |
| `vector` | 0 / 0 | verilator, icarus, yosys | **skipped** (B-06) | 60,211 |
| `vector_v1` | 0 / 12 | verilator, icarus | icarus: 9 ops, 144 checks PASS (LANES=4); LANES=16 **FAILS** (B-05) | **skipped** (B-02) |
| `tensor` | 0 / 0 | verilator, icarus, yosys | icarus: 2x2, 326 tests PASS | 6,580 |
| `albion_soc` | 664 / 0 (ratchet) | verilator, yosys | verilator: 3 scenarios PASS | **skipped** (B-11) |

Reproducibility (`reports/reproducibility.txt`): `smoke`, `sram`, `datafabric`, `tensor` and `vector_v1` were each rebuilt from scratch and produced **identical digests**; `datafabric`'s digest
also equals the one from the earlier full run (different build root, different time).

STA: **skipped everywhere** (OpenSTA / OpenROAD not installed, B-01). Parameter sweeps beyond the defaults (shapes, widths, lanes, ports, optional blocks) were also run through the
stages; the results are recorded in `reports/PARAMETER_SWEEPS.md` (they are not part of the default `ci`).

## What is verified, what is not

`reports/BUILD_REPORT.md` is the authority: it is rendered from the recorded results of the last `albion ci`. Anything not verified is listed with its cause and
what would unblock it in **`docs/KNOWN_BLOCKERS.md`**. The headline limits: no OpenSTA/OpenROAD (so **no timing, area or physical-design claim exists**), Yosys 0.33
cannot parse the v1.0 package, Icarus 12 cannot parse AlbionCore's package, and the prebuilt firmware images cannot be rebuilt (no RISC-V compiler).

## Layout

```
tools/albion_forge/
  albion                 launcher (python3 -m albion_forge also works)
  albion_forge/          the tool (see docs/ARCHITECTURE.md)
  configs/*.toml         one file per target;  configs/examples/ annotated documentation
  rtl/                   forge-owned verification collateral (lane-generic vector testbench)
  tests/                 pytest suite (scanner, dependency graph, config, sources, stages with real tools, CLI, manifests)
  ci/albion-forge.yml    CI workflow (mirrored to .github/workflows/)
  docs/                  ARCHITECTURE · CONFIGURATION · FORENSICS · KNOWN_BLOCKERS · CI · DIAGNOSTICS
  reports/               RTL_INVENTORY.md, rtl_inventory.json, rtl_files.tsv, BUILD_REPORT.md, build_report.json, junit.xml, ci_summary.json,
                         PARAMETER_SWEEPS.md, reproducibility.txt, manifests/, results/
```

`build/` (at the repository root) is generated output; add it to `.gitignore`.

## Tests

```bash
python3 -m pytest tools/albion_forge/tests -q         # or: albion test --forge-only
```

Real tools are used where they exist; a test needing an absent tool **skips with a reason**. The suite covers (among others): missing modules, circular
dependencies (modules, packages, self-instantiation), duplicate definitions, invalid configurations, parameter errors (unknown, out of range, wrong type, constraint,
localparam, unreachable through the testbench), unsupported language constructs, unsafe archives, `.sf` handling, vacuous / failing / timing-out testbenches, missing and outdated
tools, determinism under shuffled inputs, reproducibility digests, git revision tracking and a successful minimal compilation + simulation + synthesis.

## Requirements

Python >= 3.11 (standard library only; `pytest` for the tests). Verified with Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33. Optional: OpenSTA, OpenROAD (detected, **not verified here**), git (revision tracking).
