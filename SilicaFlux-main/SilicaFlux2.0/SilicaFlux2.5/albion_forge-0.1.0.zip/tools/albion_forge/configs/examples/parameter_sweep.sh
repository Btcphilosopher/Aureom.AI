#!/usr/bin/env bash
# Parameter sweep driven from the shell.  Every combination is validated against the configuration, the declared
# constraints and the real RTL top before any tool runs; each combination builds in its own reproducible
# directory (build/albion/<config>/o-<hash>).  A combination the testbench cannot reach is SKIPPED, not faked.
set -u
ALBION="$(dirname "$0")/../../albion"
for lanes in 4 8 16; do
  "$ALBION" ci --config vector_v1 -P LANES=$lanes --skip-forge-tests || echo "LANES=$lanes: exit $?"
done
for rows in 1 2 4; do for cols in 1 2 4; do
  "$ALBION" simulate --config tensor -P ARRAY_ROWS=$rows -P ARRAY_COLS=$cols
done; done
