# Example configurations

These files are *documentation*: they are never listed by `albion list` and never run by `albion ci`. They are
validated by the test-suite (`tests/test_examples.py`) so they cannot rot.

| file | shows |
|---|---|
| `annotated_full.toml` | every schema section with comments: sources, parameters, constraints, blocks, lint policy, multi-run simulation |
| `blocked_target.toml` | how a target that has no supporting RTL is declared (`enabled = false` + `blocker`) |
| `parameter_sweep.sh`  | driving a parameter sweep from the shell with `albion ... -P NAME=VALUE` |
