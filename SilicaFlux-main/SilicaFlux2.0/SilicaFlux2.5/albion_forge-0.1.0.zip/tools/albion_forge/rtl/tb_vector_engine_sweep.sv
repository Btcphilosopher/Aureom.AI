// =============================================================================
//  tb_vector_engine_sweep.sv  --  AlbionForge-owned, lane-generic testbench for
//  the SilicaFlux v1.0 `vector_engine`.
// -----------------------------------------------------------------------------
//  Why this exists: the repository's own tb_vector_engine.sv hard-codes
//  `localparam int LANES = 4`, so the LANES parameter (4/8/16) can never be
//  exercised through simulation.  This testbench takes LANES as a *parameter of
//  its top module*, which is what lets `albion simulate -P LANES=8` reach the DUT.
//
//  Every vector operation is checked against an independent software model over
//  16 pseudo-random vectors.  One [PASS] / [FAIL] line is printed per operation,
//  followed by a machine-readable summary line.  Nothing here is copied from the
//  repository's testbench.
// =============================================================================
`timescale 1ns/1ps
module tb_vector_engine_sweep #(
  parameter int LANES = 4
);
  import silicaflux_pkg::*;

  localparam int VW    = LANES * XLEN;
  localparam int NVEC  = 16;

  logic              clk = 1'b0;
  logic              rst_n = 1'b0;
  logic              issue_valid = 1'b0;
  logic [4:0]        opcode = '0;
  logic [7:0]        func = '0;
  logic [VW-1:0]     vop_a = '0, vop_b = '0, vresult;
  logic [XLEN-1:0]   scalar_in = '0, scalar_result;
  logic              result_valid, is_scalar_result;

  vector_engine #(.LANES(LANES)) dut (.*);

  always #5 clk = ~clk;

  // ---- deterministic stimulus (xorshift32) -----------------------------------
  logic [31:0] rng = 32'h1badf00d;
  function automatic logic [31:0] next_rand();
    rng ^= rng << 13;
    rng ^= rng >> 17;
    rng ^= rng << 5;
    return rng;
  endfunction

  int checks = 0;
  int errors = 0;
  int ops_pass = 0;

  // ---- independent reference model --------------------------------------------
  function automatic logic [XLEN-1:0] ref_reduce(input logic [VW-1:0] v, input logic [1:0] kind);
    logic [XLEN-1:0] acc, x;
    acc = v[XLEN-1:0];
    for (int i = 1; i < LANES; i++) begin
      x = v[i*XLEN +: XLEN];
      case (kind)
        2'b00:   acc = acc + x;
        2'b01:   acc = ($signed(x) < $signed(acc)) ? x : acc;
        2'b10:   acc = ($signed(x) > $signed(acc)) ? x : acc;
        default: acc = acc & x;
      endcase
    end
    return acc;
  endfunction

  function automatic logic [XLEN-1:0] ref_dot(input logic [VW-1:0] a, input logic [VW-1:0] b);
    logic [XLEN-1:0] acc = '0;
    for (int i = 0; i < LANES; i++)
      acc = acc + a[i*XLEN +: XLEN] * b[i*XLEN +: XLEN];
    return acc;
  endfunction

  // The DUT registers its outputs on the posedge that falls between the two negedges below,
  // so the result (and the one-cycle result_valid pulse) is sampled right after the second one.
  task automatic issue(input logic [4:0] op, input logic [7:0] fn);
    @(negedge clk);
    issue_valid = 1'b1; opcode = op; func = fn;
    @(negedge clk);
    issue_valid = 1'b0;
    #1;
  endtask

  // `ones_biased`: each bit is 1 with probability 15/16, so an AND across many lanes still has set bits
  // (an AND of random words is almost always 0 and could not tell 8 lanes from 16).
  task automatic randomise(input bit ones_biased = 1'b0);
    for (int i = 0; i < LANES; i++) begin
      vop_a[i*XLEN +: XLEN] = ones_biased ? ~(next_rand() & next_rand() & next_rand() & next_rand()) : next_rand();
      vop_b[i*XLEN +: XLEN] = next_rand();
    end
    scalar_in = next_rand();
  endtask

  // run NVEC vectors through `op`; `kind`: 0 lane-wise vector result, 1 scalar result
  task automatic run_op(input string name, input logic [4:0] op, input logic [7:0] fn, input int kind);
    int bad = 0;
    logic [VW-1:0]   exp_v;
    logic [XLEN-1:0] exp_s;
    string           first = "";
    for (int n = 0; n < NVEC; n++) begin
      randomise(op == OP_REDUCE && fn[1:0] == 2'b11);
      issue(op, fn);
      checks++;
      case (op)
        OP_VADD:  for (int i = 0; i < LANES; i++) exp_v[i*XLEN +: XLEN] = vop_a[i*XLEN +: XLEN] + vop_b[i*XLEN +: XLEN];
        OP_VSUB:  for (int i = 0; i < LANES; i++) exp_v[i*XLEN +: XLEN] = vop_a[i*XLEN +: XLEN] - vop_b[i*XLEN +: XLEN];
        OP_VMUL:  for (int i = 0; i < LANES; i++) exp_v[i*XLEN +: XLEN] = vop_a[i*XLEN +: XLEN] * vop_b[i*XLEN +: XLEN];
        OP_BCAST: for (int i = 0; i < LANES; i++) exp_v[i*XLEN +: XLEN] = scalar_in;
        default:  exp_v = '0;
      endcase
      exp_s = (op == OP_DOT) ? ref_dot(vop_a, vop_b) : ref_reduce(vop_a, fn[1:0]);
      if (kind == 0) begin
        if (!(result_valid && !is_scalar_result && vresult === exp_v)) begin
          bad++;
          if (first == "") $sformat(first, "vector %0d mismatch", n);
        end
      end else begin
        if (!(result_valid && is_scalar_result && scalar_result === exp_s)) begin
          bad++;
          if (first == "") $sformat(first, "vector %0d: got %0d expected %0d", n, scalar_result, exp_s);
        end
      end
    end
    if (bad == 0) begin
      $display("[PASS] %s (LANES=%0d, %0d vectors)", name, LANES, NVEC);
      ops_pass++;
    end else begin
      $display("[FAIL] %s (LANES=%0d): %0d/%0d vectors wrong, first: %s", name, LANES, bad, NVEC, first);
      errors += bad;
    end
  endtask

  initial begin
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    run_op("VADD",       OP_VADD,   8'h00, 0);
    run_op("VSUB",       OP_VSUB,   8'h00, 0);
    run_op("VMUL",       OP_VMUL,   8'h00, 0);
    run_op("BCAST",      OP_BCAST,  8'h00, 0);
    run_op("DOT",        OP_DOT,    8'h00, 1);
    run_op("REDUCE_SUM", OP_REDUCE, 8'h00, 1);
    run_op("REDUCE_MIN", OP_REDUCE, 8'h01, 1);
    run_op("REDUCE_MAX", OP_REDUCE, 8'h02, 1);
    run_op("REDUCE_AND", OP_REDUCE, 8'h03, 1);
    $display("TB_RESULT tb_vector_engine_sweep LANES=%0d ops_passed=%0d checks=%0d errors=%0d",
             LANES, ops_pass, checks, errors);
    $finish;
  end

  initial begin
    #2_000_000;
    $display("[TIMEOUT] tb_vector_engine_sweep");
    $finish;
  end
endmodule
