# AlbionForge build report

> Generated from recorded stage results only. A cell reads PASS only if a real tool ran and met the configuration's criteria; `SKIPPED` / `BLOCKED` / `NOT RUN` are never passes.

- Repository: `855cbf41953864d65e16dbbf72f737e30d9704e3` on `claude/keen-ritchie-qylgjs` (tracked files clean; 3 untracked path(s), consumed archives modified: none)
- Tools: icarus 12.0, openroad **MISSING**, opensta **MISSING**, pytest 9.2.0, verilator 5.020, vvp 12.0, yosys 0.33
- Forge self-tests: 174 tests, 0 failures, 0 errors, 0 skipped

## Status matrix

| configuration | category | lint | elaborate | simulate | synth |
|---|---|---|---|---|---|
| `albion_soc` | soc | PASS | PASS | PASS | SKIPPED |
| `datafabric` | datafabric | PASS | PASS | PASS | PASS |
| `dma` | dma | PASS | PASS | PASS | PASS |
| `riscv_core` | riscv_core | PASS | PASS | PASS | PASS |
| `smoke` | smoke | PASS | PASS | PASS | PASS |
| `sram` | sram | PASS | PASS | PASS | PASS |
| `tensor` | tensor | PASS | PASS | PASS | PASS |
| `vector` | vector | PASS | PASS | SKIPPED | PASS |
| `vector_v1` | vector | PASS | PASS | PASS | SKIPPED |

## Details

### `albion_soc` -- Albion Cloud SoC: sf_albion_soc_min (ControlCore + Meridian fabric + IronMemory + CloudDMA)

- top: `sf_albion_soc_min`; params: `{"STALL_PCT": 0}`
- sources: 105 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/albionforge-0.1.0.zip` (sha256 `42e13958640a`)
- repro digest: `d3937c5d4f1f09f8`
- **lint**: PASS -- 96 files, 0 error(s), 664 unwaived / 0 waived warning(s) [ratchet policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, yosys 0.33
- **simulate**: PASS -- verilator 5.020: 3 PASS marker(s), 0 failure marker(s)
- **synth**: SKIPPED -- synthesis not enabled: Whole-SoC Yosys synthesis is not part of the default flow: the earlier project reports tens of minutes and this forge has not verified it. Block-level synthesis is covered by the dma, datafabric, sram and riscv_core configurations.

### `datafabric` -- DataFabric interconnect: sfb_crossbar (NM x NS, DW, arbitration)

- top: `sfb_crossbar`; params: `{"ARB_MODE": 1, "DW": 32, "NM": 3, "NS": 3, "SLICE": 0}`
- sources: 43 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip` (sha256 `9f1f37357c8e`)
- repro digest: `5af6c62f10d364e4`
- **lint**: PASS -- 6 files, 0 error(s), 0 unwaived / 0 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0, yosys 0.33
- **simulate**: PASS -- verilator 5.020: 5 PASS marker(s), 0 failure marker(s)
- **synth**: PASS -- yosys 0.33: 2008 cells; STA: skipped: OpenSTA/OpenROAD not installed

### `dma` -- DMA subsystem: hpc_dma_adapter + DataFabric engine + scratchpad (HPC Module 05)

- top: `hpc_dma_adapter`; params: `{"DUAL_PORT": 0, "DW": 32, "ENGINE": 0, "FIFO_DEPTH": 8}`
- sources: 49 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m05-dma-adapter.zip` (sha256 `655b66849494`)
- repro digest: `28a05067611778fc`
- **lint**: PASS -- 10 files, 0 error(s), 0 unwaived / 0 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0, yosys 0.33
- **simulate**: PASS -- verilator 5.020: 8 PASS marker(s), 0 failure marker(s)
- **synth**: PASS -- yosys 0.33: 8289 cells; STA: skipped: OpenSTA/OpenROAD not installed

### `riscv_core` -- RISC-V control core: silicaflux_control_core (RV32, host mailbox, PMU, RAS, secure monitor)

- top: `silicaflux_control_core`; params: `{}`
- sources: 140 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-controlcore.zip` (sha256 `39b5b8e374a4`)
- repro digest: `17c720e6f1398aee`
- **lint**: PASS -- 40 files, 0 error(s), 0 unwaived / 286 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0, yosys 0.33
- **simulate**: PASS -- verilator 5.020: 4 PASS marker(s), 0 failure marker(s)
- **synth**: PASS -- yosys 0.33: 1936305 cells; STA: skipped: OpenSTA/OpenROAD not installed

### `smoke` -- Minimal smoke: AlbionCore sf_albion_fifo + self-checking sweep testbench

- top: `sf_albion_fifo`; params: `{}`
- sources: 24 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/albioncore-0.1.0.zip` (sha256 `d79c338783c7`)
- repro digest: `17c68eed3e78413b`
- **lint**: PASS -- 1 files, 0 error(s), 0 unwaived / 0 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0, yosys 0.33
- **simulate**: PASS -- verilator 5.020: 1 PASS marker(s), 0 failure marker(s)
- **synth**: PASS -- yosys 0.33: 106 cells; STA: skipped: OpenSTA/OpenROAD not installed

### `sram` -- SRAM subsystem: sram_sp wrapper (depth, data width, byte mask, read latency)

- top: `sram_sp`; params: `{"DATA_WIDTH": 32, "DEPTH": 1024, "MASK_WIDTH": 4, "READ_LATENCY": 1}`
- sources: 32 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` (sha256 `13b1cee1f913`)
- repro digest: `a9571effc4f12939`
- **lint**: PASS -- 11 files, 0 error(s), 0 unwaived / 1 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0, yosys 0.33
- **simulate**: PASS -- verilator 5.020: 3 PASS marker(s), 0 failure marker(s)
- **synth**: PASS -- yosys 0.33: 71052 cells; STA: skipped: OpenSTA/OpenROAD not installed

### `tensor` -- Tensor accelerator: parameterised systolic array (TENSORCORE 02)

- top: `tensor_systolic_array`; params: `{"ACC_WIDTH": 32, "ARRAY_COLS": 2, "ARRAY_ROWS": 2, "DATA_WIDTH": 8}`
- sources: 18 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore02.zip` (sha256 `0a2ab37797b3`)
- repro digest: `425d2ff238f2292b`
- **lint**: PASS -- 4 files, 0 error(s), 0 unwaived / 0 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0, yosys 0.33
- **simulate**: PASS -- icarus 12.0: 1 PASS marker(s), 0 failure marker(s)
- **synth**: PASS -- yosys 0.33: 6580 cells; STA: skipped: OpenSTA/OpenROAD not installed

### `vector` -- Vector accelerator: hpc_vector_array (NUM_LANES fp32/int32 lanes, optional reduction unit)

- top: `hpc_vector_array`; params: `{"CMD_DEPTH": 4, "NUM_LANES": 2, "TRK_DEPTH": 8, "block:perf": true, "block:reduction": true}`
- sources: 17 files from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m03-vector-array.zip` (sha256 `c1b6d2946c5b`)
- repro digest: `0e54c6272610d729`
- **lint**: PASS -- 17 files, 0 error(s), 0 unwaived / 0 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0, yosys 0.33
- **simulate**: SKIPPED -- simulation not enabled: The project testbench needs stimulus produced by a C reference model + Python generator (ref/build_ref.sh, ref/gen_stim.py); AlbionForge has no pre-simulation generation step. See docs/KNOWN_BLOCKERS.md B-06.
- **synth**: PASS -- yosys 0.33: 60211 cells; STA: skipped: OpenSTA/OpenROAD not installed

### `vector_v1` -- Vector accelerator (v1.0): SIMD vector_engine, LANES = 4 / 8 / 16

- top: `vector_engine`; params: `{"LANES": 4}`
- sources: 3 files from `SilicaFlux-main/silicaflux.zip` (sha256 `ccb055b8f292`), `tools/albion_forge/rtl` (sha256 ``)
- repro digest: `8ed83e405dd6c553`
- **lint**: PASS -- 2 files, 0 error(s), 0 unwaived / 12 waived warning(s) [strict policy]
- **elaborate**: PASS -- elaborated OK with verilator 5.020, icarus 12.0
- **simulate**: PASS -- icarus 12.0: 9 PASS marker(s), 0 failure marker(s)
- **synth**: SKIPPED -- synthesis not enabled: Yosys 0.33 rejects silicaflux_pkg.sv:218 (return {{15{imm[16]}}, imm};) - blocker B-02. Not claimed.

