# AlbionForge architecture

AlbionForge turns *(configuration + parameter overrides + SHA-pinned source archives)* into a **deterministic build
directory**, runs real EDA tools against it, and records **positive evidence** of every result. It never infers a pass.

> Not to be confused with `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/albionforge-0.1.0.zip`, an earlier *SoC
> integration project* of the same name. That project is a **design under test** here (configuration `albion_soc`);
> this directory is the build/verification **infrastructure**.

## Data flow

```
 configs/<name>.toml ──► config.py        strict schema, typed parameters, constraints, blocks      CFG*/PAR*
        + -P/-B overrides                 (unknown key = error; disabled target needs a blocker)
                │
                ▼
        sources.py       open pinned archive (SHA-256) → extract ONLY the selected members into
                         build/albion/<config>/<tag>/src/<id>/ (safe paths, byte-exact, .sf → .sv rename)     SRC*
                │
                ▼
        sv_scan.py       comment/string-aware scan with `ifdef/`include/macro-body handling:
                         units, instances, package refs, parameters, simulation-only constructs
                │
                ▼
        depgraph.py      resolve the top (+ testbench) → dependency-first, lexicographically smallest
                         topological order; missing modules/packages, cycles, duplicates, includes        DEP*
                │
                ▼
        build.py         language-profile checks (LNG*), RTL parameter validation (PAR001/002),
                         filelists, manifest, reproducibility digest
                │
                ▼
        stages.py        lint · elaborate · simulate · synth(+STA)  →  runner.py (logged subprocesses)
                │            every tool message is mapped back to  <source-id>:<file>:<line> [module]
                ▼
        results/<stage>.json  ·  manifest.json  ·  report.py (Markdown / JSON / JUnit)  ·  pipeline.py (ci)
```

`inventory.py` is the forensic side-channel: it reads the *whole repository* (archives in memory, nothing is
extracted into the repo) and writes `reports/RTL_INVENTORY.md` + `rtl_inventory.json`.

## Module map

| module | responsibility |
|---|---|
| `diagnostics.py` | `Diagnostic` (code, severity, **file, line, module**), the code registry (`docs/DIAGNOSTICS.md` is generated from it) |
| `config.py` | TOML schema, `SourceSpec` / `ParamSpec` / `BlockSpec`, constraint evaluator (whitelist AST, no `eval`), override validation |
| `sources.py` | archive / tree materialisation, SHA-256 pins, unsafe-path and symlink refusal, `.sf` handling, glob |
| `sv_scan.py` | structural scanner (not a parser): declarations, instances, `pkg::` refs, params, construct census, `.sf` dialect classifier |
| `depgraph.py` | closure, ordering, missing / duplicate / cycle diagnostics |
| `build.py` | `BuildContext`: preparation, per-stage analysis, parameter validation, manifest, `repo_info` |
| `toolchain.py` | detection + exact versions of Verilator, Icarus, Yosys, OpenSTA, OpenROAD, pytest; minimum versions; install hints |
| `runner.py` | subprocess execution with a minimal, locale-neutral environment and a full log per command |
| `stages.py` | the four stages, output parsers, warning policy (strict / waivers / ratchet) |
| `pipeline.py` | multi-config orchestration, forge self-tests, reproducibility rebuild, CI verdict |
| `report.py` | reports rendered **only from recorded results** |
| `inventory.py` | repository forensics |
| `cli.py` | `albion` command |

## Result semantics (the honesty contract)

| status | meaning |
|---|---|
| `passed` | a real tool ran **and** its output met the configuration's criteria (positive evidence) |
| `failed` | a tool ran and a criterion was not met, or the forge's own pre-tool analysis found an error |
| `blocked` | a *required* tool is missing / too old, or the configuration is disabled (it carries a `blocker`) |
| `skipped` | an *optional* part cannot run (OpenSTA absent, no liberty, no stimulus for this parameter combination) |

`blocked` and `skipped` are **never** counted as passes. `albion ci` exits `3` for blocked, `1` for failed.
A simulation passes only with `>= min_pass` matching marker lines, zero failure markers, exit status 0, and (if
configured) a summary line per run. The forge ships a regression test for the testbench pattern found in the
repository that prints "ALL TESTS PASSED" after incrementing a counter unconditionally (`tb_silicaflux_top`):
it scores **0** individual checks and therefore cannot pass.

## Determinism and reproducibility

* Source order is the lexicographically smallest topological order of the file dependency graph: independent of
  the order files were listed in, the order members appear in the archive, or the platform (tested with shuffles).
* Archives are pinned by SHA-256; extraction is byte-exact; `.sf → .sv` is a rename.
* The output directory is `build/albion/<config>/<tag>`, `tag = default` or `o-<hash of the non-default overrides>`
  (an override equal to its default maps to `default`).
* `manifest.json` records forge version, configuration digest, effective parameters, repository revision (git
  `HEAD`, branch, dirty flag, and which *consumed* archives are dirty), archive hashes, every source's SHA-256,
  the per-stage compile order, tool versions/paths, every command line, and all stage results.
* `repro_digest` hashes everything that must be identical between two builds of the same inputs (config, parameters,
  archive and source hashes, compile order, tool versions, stage outcomes); timings and host paths are excluded.
  `albion ci --reproduce` rebuilds from scratch in a temporary root and compares digests.

## Why per-archive configurations

The repository is a snapshot collection: **213 unit names have conflicting definitions** (e.g. `silicaflux_pkg` exists in
nine distinct versions, `sg_top` in nineteen) and only about half of the candidate tops are dependency-complete inside
their own archive. A flat build is impossible, so each configuration draws from **one** pinned archive (which vendors its
own `third_party/` closure) and the forge refuses duplicates that matter (`DEP004`).

## Extending

* **New target**: add `configs/<name>.toml` (see `configs/examples/annotated_full.toml`); pin the archive with
  `albion pin`; run `albion lint/elaborate/simulate/synth --config <name>`. If no RTL supports it, ship it with
  `enabled = false` and a `blocker`.
* **New stage / tool**: add a function to `stages.py` returning a `StageResult`, register it in `STAGES`, add the tool to
  `toolchain.TOOLS`. Anything that parses tool output must be covered by a test that feeds it real output.
* **New diagnostic**: add to `CODES`, then regenerate `docs/DIAGNOSTICS.md` (`albion codes --markdown`).
