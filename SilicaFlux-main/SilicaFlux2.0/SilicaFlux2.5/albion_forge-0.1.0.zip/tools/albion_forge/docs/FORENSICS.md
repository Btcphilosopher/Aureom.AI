# Repository forensics: what is actually in SilicaFlux

Method: `albion inventory` walks the whole repository (loose files, zip archives, archives nested inside archives)
**in memory**, scans every HDL file with the forge's own scanner, and runs real Verilator on the `.sf` population.
Raw data: `reports/rtl_inventory.json`, `reports/rtl_files.tsv`; summary: `reports/RTL_INVENTORY.md`. Re-run it any time:
`tools/albion_forge/albion inventory`. Figures below are measured on the repository state recorded in
`reports/BUILD_REPORT.md` (the tool counts what is there; it does not extrapolate).

## 1. The source is inside archives, and the archives overlap

* The repository contains **no loose `.sv`/`.v` file**. HDL lives in zip archives, often nested (zip in zip in zip).
* **6,481 HDL file occurrences** in 492 containers (447 distinct archives, the rest byte-identical copies) reduce to
  **2,212 unique file contents** (2.9x duplication): every project archive re-vendors the earlier ones under `third_party/`.
* Unique contents by extension: `.sv` 1,951, `.svh` 155, `.sf` 64, `.v` 31, `.sfx` 11. By family: 2,142 SilicaFlux
  (incl. AlbionCore / Albion SoC), 70 come from archives of other products found in the same repository (e.g. `aardvark_imaging_v0.1.0.zip`, and a
  `Silica_Flux_Lighter.sf` inside a consumer-products archive).
* Design units: 1,867 modules, 96 packages, 11 interfaces (1,974 distinct names).

## 2. `.sf` files: two different things (translation is only *sometimes* meaningful)

| kind | unique files | verdict |
|---|---|---|
| **SystemVerilog with a different extension** (header: "Language: Silica Flux-2017") | 62 | plain SV; no language translation. AlbionForge maps `.sf` → `.sv` as a **byte-identical copy** (`sources.py`) |
| **Speculative DSL sketch** (`package silicaflux.ml`, `fixed Fixed16_16 {…}`, `state machine`) | 2 (`SilicaFluxML/dsl/silicaflux_ml.sf`, `…/silicaflux-quantumtunnel/sf/sf_quantum_tunnel.sf`) | **not HDL**. Their own headers: *"documentation only – NOT COMPILED … no .sf compiler or transpiler exists … .sf and .sv are NOT interchangeable"*. The forge refuses them as sources (`SRC005`) |

`.sfx` (11 unique) are assembly programs for `sim/sfx_asm.py`, not HDL.

Verilator 5.020 `--lint-only` on the SV-dialect files that belong to SilicaFlux (61 tested, trying every package variant and the
sibling headers): **39 parse clean** (29 only with the right package file), **10** fail only at link level (a module or package
defined elsewhere), **4** use `covergroup` (valid SV that Verilator 5.020 does not support; testbenches), and **8 fail with an
unknown package type** in every single package variant. For `forwarding_unit.sf` this was traced: its types (`fwd_src_e`, `rob_tag_t`)
exist only in a 112-line addendum package whose header says *"merge into the project package"*, and merging it into the 70 KB
`silicaflux_pkg.sf` produces duplicate declarations (`preg_t`). That is a package-dependency gap needing manual reconciliation by the
authors, **not** a dialect difference. The other seven show the same error signature but were not individually reconciled.

## 3. The repository cannot be compiled as one design

**213 unit names have more than one distinct definition** across archives (largest: `sg_top` 19 versions, `cfg_top` 13, `tl_wrap` 13,
`silicaflux_pkg` 9, `alu` 5, `forwarding_unit` 5). A flat file list is therefore ambiguous; each AlbionForge configuration draws from
**one** pinned archive, and any *reachable* duplicate is `DEP004` (identical duplicates are only `DEP008`). One further trap found in
v1.0: every v1.0 file does `` `include "silicaflux_pkg.sv" `` and defines the package again, which is only legal because the package
file is include-guarded; the scanner attributes such declarations to the defining file so they are not miscounted as 16 duplicates.

## 4. Top-level candidates, missing modules, unresolved dependencies

Static closure survey over **117 project roots / 200 candidate tops**: **104 are dependency-complete inside their own archive**; 96 are
not. Most frequently missing *modules*: `sfv_sync` (48), `sfv_rst_sync` (23), `sfb_crossbar` (16), `dma_fifo` (16), `sfb_v1_slave_adapter`
(12), `sfb_reg_slice` (11), `sfras_secded_dec/enc` (7). Most frequently missing *packages*: `sfh_abi_pkg`, `sfmem_map_pkg`, `sf_albion_pkg`,
`sfn_pkg`, `sfb_memmap_pkg`. Causes seen on inspection: (a) the archive relies on a sibling project that is not vendored into it; (b) a
**generated** file is absent (e.g. `sfv_bootrom_image` is produced by a RISC-V toolchain flow); (c) technology macros (`sky130_sram_*`) that
must be black-boxed. This is a static count by the forge's scanner; the configurations only claim what a real tool then confirmed.

Two RTL idioms look like missing modules but are not: designs deliberately instantiate an **undefined module named like the error**
(`illegal_parameter_BND_LOG2_at_most_12…`, `hpc_param_error_DATA_W_must_be_32`) in a non-taken `generate` branch to force an elaboration error.
The forge recognises these (`assertion_idioms`) and reports them as INFO.

## 5. Clock and reset conventions

Two dialects coexist. The original v1.0 and most project IP use **`clk` / `rst_n`** (1,082 / 915 ports), the AlbionCore / ControlCore / Albion family
uses **`clk_i` / `rst_ni`** (236 / 237, OpenTitan style). Both are **active-low**. Sequential-block census: **1,666** `always_ff` with an *asynchronous*
active-low reset (`negedge rst_n`), **4** asynchronous active-high, **3,798** clock-only sensitivity lists (reset, if any, is synchronous). Other clocking:
`clka`/`clkb` (dual-clock SRAM), `rclk_i`/`wclk_i` (async FIFOs), `por_rst_n`, `trst_n`, `host_rst_req` (host-driven reset) appear in the SoC-level IP.

## 6. Simulation-only and unsupported constructs

In files under `rtl/`-style directories (occurrences): `initial` 164, `final` 72, `#` delays 41, simulation system tasks 264, immediate
assertions 189, concurrent assertions 1,578 (the census does not define `SYNTHESIS`, so assertions guarded by `` `ifndef SYNTHESIS`` are included), severity tasks
(`$error`/`$fatal`, legal in generate) 1,477. **Constructs that cannot be synthesized, found in RTL directories:** `class` (11 files), `fork/join` (7 files),
`covergroup`, constrained-random (`rand`) and an IPC primitive (1 file each). Testbench files, as expected, use everything (162 `class`, 1,838 delays,
11,112 system-task uses, 84 covergroups). The forge's `[language]` profile rejects the first set in RTL (`LNG001`), warns on the second when synthesizing (`LNG002`).

## 7. Existing simulation, FPGA and ASIC infrastructure

* **v1.0 cluster** (`silicaflux.zip`): `sim/run_sim.sh` compiles with Icarus and *counts `[PASS]`/`[FAIL]` lines*. Reproduced: six of its seven testbenches
  pass with real checks (7, 15, 6, 9, 6, 15 markers). The seventh, `tb_silicaflux_top`, is **vacuous**: it increments `pass_count` unconditionally ("observe
  waveforms") and prints "ALL TESTS PASSED" with zero checks. The forge cannot be fooled this way (`min_pass`).
* Per-project `Makefile`s: Verilator `--binary --timing`, Icarus, cocotb (unit tests of newer IP; **not runnable here**: cocotb absent), Python generators
  (memory maps, vectors), RISC-V firmware builds (compiler absent). Some archives ship the built firmware image, which the forge uses and pins.
* FPGA: v1.0 ships `synth/vivado/synth.tcl` (+ XDC) and `synth/quartus/synth.tcl`; other projects use Yosys + nextpnr. ASIC: `synth/silicaflux.sdc` (100 MHz) and
  OpenLane/OpenROAD-style flows in several project archives. **1,263 unique script-like files** were found (ASIC-flavoured 237, FPGA-flavoured 93,
  FPGA+ASIC 119, simulation 150, Yosys 45, other 336; the rest are mixed). None of the vendor/PDK flows can run in this environment (Vivado, Quartus,
  OpenROAD, PDKs absent); the forge does not invent their results.

## 8. What the forge builds, and from where

| configuration | archive (pinned) | design top | testbench | stages verified |
|---|---|---|---|---|
| `smoke` | `…/albioncore-0.1.0.zip` | `sf_albion_fifo` | `tb_sf_albion_fifo` | lint · elaborate (3 tools) · simulate · synth |
| `riscv_core` | `…/silicaflux-controlcore.zip` | `silicaflux_control_core` | `tb_cc_system` (shipped firmware) | see `BUILD_REPORT.md` |
| `sram` | `…/silicaflux-sramlib.zip` | `sram_sp` | `tb_sram_sp` | lint · elaborate · simulate · synth |
| `datafabric` | `…/silicaflux-datafabric.zip` | `sfb_crossbar` | `tb_sfb_xbar` | lint · elaborate · simulate · synth |
| `dma` | `…/silicaflux-hpc-m05-dma-adapter.zip` | `hpc_dma_adapter` | `tb_hpc_dma_adapter` | lint · elaborate · simulate · synth |
| `vector` | `…/silicaflux-hpc-m03-vector-array.zip` | `hpc_vector_array` | (needs generated stimulus) | lint · elaborate · synth |
| `vector_v1` | `SilicaFlux-main/silicaflux.zip` | `vector_engine` | forge-owned lane sweep | lint · elaborate (2 tools) · simulate |
| `tensor` | `…/silicaflux-tensorcore02.zip` | `tensor_systolic_array` | `tb_array` + shipped vectors | lint · elaborate · simulate · synth |
| `albion_soc` | `…/albionforge-0.1.0.zip` | `sf_albion_soc_min` | `tb_albion_soc` (shipped firmware) | lint · elaborate (2 tools) · simulate |

(`…/` = `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`.) Everything the forge could **not** verify is listed, with cause, in `KNOWN_BLOCKERS.md`.
