# Configuration reference

Configuration files are TOML (`configs/<name>.toml`, `[config].name` must equal the file name). The schema is
strict: **unknown keys are errors**. A fully annotated example is in `configs/examples/annotated_full.toml`.

## Sections

| section | keys | notes |
|---|---|---|
| `schema_version` | `1` | |
| `[config]` | `name title description category enabled blocker` | `enabled = false` **requires** a non-empty `blocker`; `enabled = true` forbids one (`CFG004`). Categories: `smoke riscv_core sram datafabric dma vector tensor soc other` |
| `[[source]]` | `id role archive` \| `path`, `archive_sha256`, `root`, `files`, `glob`, `exclude`, `incdirs`, `support`, `third_party`, `optional`, `pins` | archives **must** be SHA-256 pinned. `role`: `rtl` (all stages), `model` (all but synth), `tb` (simulate only), `header` |
| `[design]` | `top defines defines_<stage> blackboxes assertion_idioms` | `SYNTHESIS=1` is defined automatically for the synth view |
| `[language]` | `profile forbid sim_only sim_only_action allow_in` | `LNG001` for forbidden constructs (class, program, fork/join, covergroup, DPI, UVM ...) in RTL; `LNG002` for simulation-only constructs in synthesis |
| `[clock]` | `name period_ns sim_param` | recorded in `constraints.sdc`; **not** used by generic Yosys synthesis |
| `[parameters.NAME]` | `rtl_name tb_name type default choices min max pow2 multiple_of apply_to doc tags` | see below |
| `[[constraints]]` | `expr message` | safe expression over parameter keys; operators `+ - * // % ** << >> & \| ^`, comparisons, `and/or/not`, `clog2 min max abs` |
| `[blocks.NAME]` | `param default requires conflicts doc` | optional accelerator blocks, passed to the RTL as `1` / `0` |
| `[lint]` | `strict werror_classes baseline` + `[[lint.waive]]` | see "Warnings as errors" |
| `[elaborate]` | `tools` | any of `verilator icarus yosys`; every listed tool that is installed must succeed |
| `[simulate]` | `enabled engine tb_top pass_regex fail_regex min_pass require_summary_regex timeout_s build_timeout_s plusargs data_files runs flags note` | see below |
| `[synth]` | `enabled top flags read_flags flatten check_assert max_seconds expect_max_cells note` | disabling requires a `note` |
| `[sta]` | `enabled liberty` | runs only if OpenSTA/OpenROAD **and** a liberty exist |

## Parameters

A value is validated **four** times before any tool runs:

1. against its declaration (`type`, `choices` / `min` / `max` / `pow2` / `multiple_of`) -> `PAR003`/`CFG005`;
2. against the cross-parameter `[[constraints]]` -> `PAR003`;
3. against **what the RTL top actually declares**: unknown name `PAR001`; `localparam`, type parameter, or a body
   `parameter` in a module with a `#(...)` port list (which IEEE 1800 makes a localparam) `PAR002`;
4. in simulation, against what the **testbench top** exposes.

Where the value goes is decided by `apply_to`:

* `"design"` – Verilator `-GNAME=`, Icarus `-P top.NAME=`, Yosys `chparam` on the design top. 1-bit parameters
  (`parameter bit EN`) are passed as sized literals (`1'b1`) so the forge adds no WIDTH warnings of its own.
* `"tb"` – the testbench top's parameter (`tb_name`, default `rtl_name`). **This is the only way a value reaches
  the DUT in simulation**: the testbench instantiates the DUT.

If a parameter has a non-default value and its testbench cannot take it, `simulate` is **skipped with `STG004`**
instead of silently simulating the default.

`albion <stage> --config X -P NAME=VALUE -B block=on|off` selects overrides. An override equal to its default builds
in the `default` directory; otherwise in `o-<hash>`.

## Simulation

```toml
[simulate]
engine     = "verilator"                 # or icarus
tb_top     = "tb_x"
plusargs   = ["+VEC={src:tb}/vectors/v_{ROWS}x{COLS}.hex"]   # {KEY} -> parameter value, {src:ID} -> source directory
data_files = ["{src:tb}/vectors/v_{ROWS}x{COLS}.hex"]        # must exist, else SKIPPED (no stimulus for this shape)
pass_regex = '^TB RESULT PASS .*errors=0'
fail_regex = '^TB RESULT FAIL|%Error'
min_pass   = 3                           # >= 1 is mandatory: "no FAIL seen" is never a pass
runs = [ { name = "smoke", plusargs = ["+test=smoke"] }, { name = "bp", plusargs = ["+test=bp"] } ]
```

One compiled simulator is executed once per `runs` entry; **every** run needs its own PASS marker (and, with
`require_summary_regex`, its own summary line) and `min_pass` applies to the total.

## Warnings as errors

* **strict** (default when no `baseline`/`werror_classes` is given): every unwaived Verilator `-Wall` warning is an error.
* **waivers**: `[[lint.waive]] id, scope (fnmatch on the logical file), reason (mandatory), max_count`. A waiver
  that matches nothing is reported stale (`STG006`); one that matches more than `max_count` is an error.
* **ratchet** (`strict = false`): classes in `werror_classes` are errors; every other class is capped at
  `[lint.baseline]`; a *new* warning fails; nothing is suppressed. Used for the legacy SoC.

## Pins

`albion pin <archive>...` prints the SHA-256 to put in `archive_sha256`. A changed archive is `SRC002`; per-file pins
(`pins = { "path" = "sha" }`) are also checked.
