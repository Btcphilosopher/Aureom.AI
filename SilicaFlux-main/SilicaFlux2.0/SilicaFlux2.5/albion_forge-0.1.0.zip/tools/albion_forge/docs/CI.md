# Continuous integration

The workflow lives at `tools/albion_forge/ci/albion-forge.yml` and is **mirrored to `.github/workflows/albion-forge.yml`**
(GitHub only reads workflows from there). Keep the two identical.

## Jobs

| job | what | tools |
|---|---|---|
| `forge-tests` | `pytest tools/albion_forge/tests` | Python only. Tests that need an absent EDA tool **skip with a reason**, they never pass vacuously. The shipped-config tests (which need the real archives) are excluded here |
| `rtl-ci` | `albion doctor`, then `albion ci` (all enabled configurations), then `albion ci --reproduce` on the fast ones, then `albion inventory`; uploads reports, manifests, logs | `apt-get install verilator iverilog yosys make g++` (Ubuntu 24.04: Verilator 5.020, Icarus 12.0, Yosys 0.33: the versions the forge was verified with) |

Triggers: push / pull request touching `tools/albion_forge/**` or `SilicaFlux-main/**`, manual dispatch, and a weekly run
(catches tool-package drift). Permissions are read-only.

## What `albion ci` does

For every **enabled** configuration, in sorted order: `lint → elaborate → simulate → synth`; then the forge self-tests;
then it writes `build/albion/reports/` (`BUILD_REPORT.md`, `build_report.json`, `junit.xml`, `ci_summary.json`).
Disabled configurations are listed as `DISABLED` with their blocker; they are never counted as passes.

| flag | effect |
|---|---|
| `--config NAME` (repeatable) / `--all` | select configurations (`--all` is the default for `ci`) |
| `--reproduce` | rebuild each configuration from scratch in a temporary root and compare `repro_digest`; a mismatch fails the run |
| `--allow-missing-tools` | treat *blocked-by-missing-tool* as non-fatal (never turns a failure into a pass) |
| `--skip-forge-tests` | skip the pytest step |
| `--fail-fast` | stop a configuration at its first failing stage |

Exit status: `0` all passed · `1` something failed · `2` usage / configuration error · `3` blocked (missing tool, or an explicitly requested
configuration is disabled).

## Reading the results

* `build/albion/reports/BUILD_REPORT.md`: status matrix plus per-configuration details and the first errors with `file:line [module]`.
* `build/albion/<config>/<tag>/manifest.json`: tool versions, repository revision, archive and source hashes, compile order, every command, results.
* `build/albion/<config>/<tag>/<stage>/*.log`: the raw tool output for every command (nothing is summarised away).
* `junit.xml` plugs into any CI test-report viewer.

## Runtime (measured, 4 cores)

Fast configurations (`smoke`, `sram`, `datafabric`, `tensor` default, `dma`, `vector`, `vector_v1`) take seconds to a few minutes each
(Verilator builds of the system testbenches dominate). `riscv_core` is the long one (system-simulation build plus slow synthesis, see
`KNOWN_BLOCKERS.md` B-08) and `albion_soc` needs a large Verilator build; budget the `rtl-ci` job generously (the workflow allows 180 minutes).
