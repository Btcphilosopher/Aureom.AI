# Known blockers

Everything AlbionForge could **not** verify, or verified to be broken, with the evidence and what would unblock it.
IDs are referenced from the configurations. "Measured" means a real tool produced the evidence in this environment
(Ubuntu 24.04, Verilator 5.020, Icarus 12.0, Yosys 0.33, Python 3.13); nothing here is inferred.

## Toolchain

### B-01 OpenSTA and OpenROAD are not installed; no timing, area or physical result exists
* Neither is packaged by Ubuntu 24.04 (`apt-cache search` finds nothing; `pip index` lists a PyPI package named `openroad` (0.0.1); it was deliberately not installed because it is not evidently the OpenROAD project).
* The forge **detects** both (`albion doctor`), writes `constraints.sdc` from `[clock]`, and implements the OpenSTA/OpenROAD invocation
  (liberty + netlist + SDC → WNS/TNS). That code path is **only tested against a stub executable** (`tests/test_stages.py::test_sta_stub_*`):
  it is **not verified against the real tools**. Every `synth` result says `STA: skipped` (`TLS003`), never passed.
* **No frequency, slack, area (µm²), power or place-and-route claim is made anywhere.** Generic Yosys cell counts are the only quantitative
  synthesis output and they are technology-independent proxies.
* Unblock: install OpenSTA/OpenROAD, add a `[sta] liberty` (a PDK) to a configuration.

### B-15 The clock target is recorded but not used by synthesis
Generic Yosys synthesis has no liberty; `[clock].period_ns` goes to `constraints.sdc` and to STA only (`clock_target_applied = false` in every synth result).

### B-02 Yosys 0.33 cannot parse the v1.0 SilicaFlux package → the v1.0 cluster cannot be synthesized or Yosys-elaborated
* Measured: `silicaflux_pkg.sv:218: ERROR: syntax error, unexpected '{'` for `return {{15{imm[16]}}, imm};` (function `return` of a concatenation).
* Impact: the v1.0 modules import this package (each file includes it textually). `vector_v1` therefore disables synthesis and restricts elaboration to Verilator + Icarus.
* Unblock: newer Yosys, or rewrite the function body as an assignment to the function name.

### B-04 Icarus 12 cannot parse AlbionCore's package → Albion SoC is not elaborated by Icarus
* Measured: `sf_albion_pkg.sv:297: Malformed statement` (a package function refers to its own enum constants as `sf_albion_pkg::SF_OP_READ`).
* Impact: `albion_soc` elaborates with Verilator and Yosys only. (Icarus also prints `sorry: constant selects in always_* processes are not currently
  supported (all bits will be included)` for some DataFabric/DMA RTL; compilation succeeds, the forge records it as a warning.)

## RTL defects found by the forge

### B-05 `vector_engine` is wrong for `LANES = 16`: reductions and dot-product ignore lanes 8..15 (verified by simulation)
* `rtl/vector_engine.sv` builds `reduce_lvl2[0:LANES/4-1]` (4 entries for 16 lanes) but the final stage combines only `reduce_lvl2[0]` and `[1]`
  (the code comment says "simplified"). For `LANES = 4` and `8` the tree is complete.
* Measured with the forge-owned lane-generic testbench (`rtl/tb_vector_engine_sweep.sv`, independent reference model, 16 random vectors per op):
  `LANES=4`: 9/9 operations pass (144 checks, 0 errors); `LANES=8`: 9/9; **`LANES=16`: `DOT`, `REDUCE_SUM`, `REDUCE_MIN`, `REDUCE_MAX`, `REDUCE_AND` fail
  (71 wrong vectors)**. Example: lanes `1..16` summed gives `36` instead of `136`.
* The repository's own `tb_vector_engine.sv` hard-codes `LANES = 4`, so it cannot see this. `tests/test_shipped_configs.py` pins the failure: if the RTL is fixed
  that test fails on purpose, telling you to remove this entry.
* Unblock: add a level-3 reduction stage for `LANES = 16`.

### B-07 The repository's own top-level v1.0 testbench passes vacuously
`tb/tb_silicaflux_top.sv` increments `pass_count` unconditionally ("observe waveforms for r3=30 …") and prints `ALL TESTS PASSED` with **zero** `[PASS]` checks;
`sim/run_sim.sh` counts it as passed. It is deliberately **not** used as evidence. The other six v1.0 testbenches have real checks (7, 15, 6, 9, 6, 15 markers).

### B-12 Other archives contain RTL that Verilator 5.020 rejects (found during forensics; no configuration enabled for them)
Measured with `verilator --lint-only`: `memory_cache_repo/async_fifo.sv:171` (`Unsupported: ## cycle delay range expression`), `…/direct_mapped_cache.sv:175`
(`BLKLOOPINIT: delayed assignment to array inside for loops`), `dsp_arithmetic/fft_butterfly_r2.sv:179` (`syntax error, unexpected automatic`),
`dsp_arithmetic/fixed_point_pkg.sv:147` (`First value of [a:b] isn't a constant`), `SilicaFluxML/silicaflux_ml_top.sv:134` (`Assigning to input/const variable 'weights_predict'`).
These are not enabled targets; they are listed so nobody mistakes them for buildable designs.

## Repository structure

### B-03 No flat build; many archives are not self-contained
213 unit names have conflicting definitions (`silicaflux_pkg`: 9 distinct versions); 96 of 200 candidate tops lack a complete dependency closure inside their own archive
(missing sibling IP, generated files, technology macros). See `FORENSICS.md` §3–4. AlbionForge therefore builds **one pinned archive per configuration**.
Archives that were not built (no configuration) are simply *not claimed*.

### B-10 `.sf` files
* Two `.sf` files are a DSL sketch that declares itself "documentation only, not compiled"; no translator exists → refused (`SRC005`).
* Eight loose v2.0 SV-dialect `.sf` modules (`alu (1)`, `compute_tile`, `forwarding_unit` ×2, `scheduler`, `silicaflux_top`, `tile_interface`, `vector_engine (1)`) do not parse
  against any single package variant in the repository. Traced for `forwarding_unit.sf`: its types exist only in a "merge into the project package" addendum that collides with the
  main package (`preg_t`). Not buildable without manual reconciliation by the authors.

## Per-configuration limits

### B-06 `vector` (HPC vector array): simulation is not enabled
The project testbench consumes `cmds.txt / beats.txt / res.txt / cpl.txt` produced by a C reference model and a Python generator (`ref/build_ref.sh`, `ref/gen_stim.py`).
The forge has no pre-simulation generation step by design (generated inputs would not be pinned). Lint, elaboration (3 tools) and synthesis are verified, including `NUM_LANES` and
the optional reduction / performance blocks.

### B-08 `riscv_core`: synthesis is slow
Not a failure, a size effect: **Yosys 0.33 synthesis of `silicaflux_control_core` takes 991.5 s on 4 cores** (measured in the final CI run) and
yields **1,936,305 generic cells** (888,425 enable-flops, 896,289 muxes, 107,492 AND-NOT, 0 inferred memories), consistent with the control SRAMs being
mapped to flops. A first attempt with a 900 s budget timed out inside Yosys's closing `check` pass, so the configuration carries `max_seconds = 2700`.
These are technology-independent generic cells: **not** an area, timing or power claim (see B-01). Unblock: map the SRAMs to macros / inferred memories for a meaningful size estimate.

### B-09 Prebuilt firmware images are binaries pinned only by their archive hash
`riscv_core` (`firmware/build/fw/controlcore_fw.hex`) and `albion_soc` (`results/firmware/albion_fw.hex`) simulate firmware that ships *inside* the archives. No RISC-V compiler is installed,
so the forge cannot rebuild them or confirm they correspond to the C sources. They are protected against change (the archive SHA-256 is pinned), not against being stale.

### B-11 `albion_soc`
* The Citadel and the IOMMU do not exist in the repository; the SoC uses a Meridian reference policy table and a CloudDMA simulation permission table (stated in the project's own report).
* Whole-SoC Yosys synthesis is **not enabled** (the earlier project reports tens of minutes; the forge has not verified it). Block-level synthesis is covered by `dma`, `datafabric`, `sram`, `riscv_core`.
* Lint uses the **ratchet** policy (664 benign style warnings capped at measured counts, including one known `SYNCASYNCNET` review item in new glue code); nothing is suppressed.
* Simulated scenarios: `normal`, `reset_mid_dma`, `reset_early`. The project's other scenarios (`reset_async`, back-pressure matrix, FPGA wrapper boot) are not part of the forge run.

### B-13 `tensor`
* Stimulus vectors ship only for specific array shapes; other shapes run lint/elaborate/synth and `simulate` is **skipped** (`STG004`), not failed.
* `DATA_WIDTH` / `ACC_WIDTH` are swept in lint/elaborate/synth only: shipped vectors for other widths are not wired in.
* Measured simulation time with Icarus: 2x2 ≈ 4 s, 3x5 ≈ 19 s, **8x8 ≈ 416 s**. CI uses the 2x2 default.

### B-14 `sram`
Generic (inferred) backend only. The technology macros (`sky130`, `gf180`, `IHP`) are black boxes in the library and are not exercised; Yosys maps the array to flops: 1024x32 → 71,052 generic cells (32,866 enable-flops + 32,854 muxes, 0 inferred memories).

## Not attempted (out of scope for this module)
Formal proofs (SymbiYosys absent), coverage collection, gate-level simulation, mutation testing, cocotb unit tests (cocotb absent), vendor FPGA flows (Vivado / Quartus absent), PDK flows.
