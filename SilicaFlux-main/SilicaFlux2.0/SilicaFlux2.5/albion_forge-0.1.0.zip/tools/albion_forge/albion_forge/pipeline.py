"""Pipeline orchestration shared by the CLI commands: running stages for one
or many configurations, forge self-tests, the reproducibility check and the
``ci`` command's pass/fail policy."""
from __future__ import annotations

import dataclasses
import json
import os
import re
import shutil
import sys
import tempfile
import time
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .build import BuildContext, StageResult, default_build_root
from .config import Config, list_config_names, load_config
from .diagnostics import DiagnosticSink, Severity
from .runner import run_cmd
from . import stages as st
from . import toolchain

FORGE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CI_STAGES = ("lint", "elaborate", "simulate", "synth")


@dataclasses.dataclass
class Target:
    ctx: BuildContext
    cfg: Config


def write_manifest(ctx: BuildContext) -> str:
    tools = toolchain.detect_all()
    m = ctx.manifest(tools)
    m["repro_digest"] = ctx.repro_digest(m)
    path = os.path.join(ctx.build_dir, "manifest.json")
    os.makedirs(ctx.build_dir, exist_ok=True)
    with open(path, "w") as fh:
        json.dump(m, fh, indent=1, sort_keys=True)
    return path


def run_stage(ctx: BuildContext, stage: str) -> StageResult:
    return st.STAGES[stage](ctx)


def load_targets(names: Sequence[str], all_enabled: bool, config_dir: str, repo_root: str, build_root: str,
                 param_ov: Dict[str, str], block_ov: Dict[str, str], sink: DiagnosticSink,
                 include_disabled: bool = False) -> List[Target]:
    chosen = list(names)
    if all_enabled:
        chosen = list_config_names(config_dir)
    out: List[Target] = []
    for n in chosen:
        cfg = load_config(n, config_dir, sink)
        if cfg is None:
            continue
        if all_enabled and not cfg.enabled and not include_disabled:
            continue
        out.append(Target(BuildContext(cfg, repo_root, build_root, param_ov, block_ov), cfg))
    return out


# --------------------------------------------------------------------------
# forge self-tests
# --------------------------------------------------------------------------
def forge_tests(build_root: str, extra: Sequence[str] = ()) -> StageResult:
    t0 = time.monotonic()
    sink = DiagnosticSink()
    if not toolchain.require(["pytest"], sink, "test"):
        return StageResult("forge-tests", "blocked", "pytest is not available", diagnostics=sink.items)
    info = toolchain.detect("pytest")
    out_dir = os.path.join(build_root, "_forge_tests")
    os.makedirs(out_dir, exist_ok=True)
    junit = os.path.join(out_dir, "junit.xml")
    argv = [sys.executable, "-m", "pytest", os.path.join(FORGE_DIR, "tests"), "-q", "-p", "no:cacheprovider",
            f"--junitxml={junit}"] + list(extra)
    rec, text = run_cmd(argv, FORGE_DIR, os.path.join(out_dir, "pytest.log"), build_root, tool="pytest", timeout=1800)
    m = re.search(r"(\d+) passed", text)
    f = re.search(r"(\d+) failed", text)
    e = re.search(r"(\d+) error", text)
    s = re.search(r"(\d+) skipped", text)
    passed = int(m.group(1)) if m else 0
    failed = int(f.group(1)) if f else 0
    errors = int(e.group(1)) if e else 0
    skipped = int(s.group(1)) if s else 0
    if rec.rc != 0:
        sink.error("STG001", f"pytest reported failures (exit {rec.rc})", hint=f"see {rec.log}")
    status = "passed" if rec.rc == 0 and passed > 0 and not failed and not errors else "failed"
    if passed == 0 and rec.rc == 0:
        sink.error("STG007", "pytest ran no tests")
        status = "failed"
    return StageResult("forge-tests", status,
                       f"pytest {info.version}: {passed} passed, {failed} failed, {errors} errors, {skipped} skipped",
                       {"passed": passed, "failed": failed, "errors": errors, "skipped": skipped,
                        "pytest_version": info.version}, [rec], sink.items,
                       [os.path.relpath(junit, build_root)], time.monotonic() - t0)


# --------------------------------------------------------------------------
# running a set of stages
# --------------------------------------------------------------------------
def run_stages(target: Target, stages: Sequence[str], fail_fast: bool = False) -> List[StageResult]:
    results: List[StageResult] = []
    for s in stages:
        r = run_stage(target.ctx, s)
        results.append(r)
        if fail_fast and r.status in ("failed", "blocked"):
            break
    if target.ctx.prepared and target.ctx.materialized is not None:
        write_manifest(target.ctx)
    return results


# --------------------------------------------------------------------------
# CI policy
# --------------------------------------------------------------------------
def classify(results: Sequence[StageResult], allow_missing_tools: bool) -> str:
    """'pass' | 'fail' | 'blocked' for a set of stage results."""
    if any(r.status == "failed" for r in results):
        return "fail"
    if any(r.status == "blocked" for r in results):
        return "pass" if allow_missing_tools else "blocked"
    return "pass"


def reproducibility_check(target: Target, stages: Sequence[str], repo_root: str, config_dir: str,
                          param_ov: Dict[str, str], block_ov: Dict[str, str]) -> Tuple[bool, str, str]:
    """Rebuild ``target`` from scratch in a temporary build root and compare the
    reproducibility digests (inputs, ordering, tool versions, stage outcomes)."""
    first = target.ctx
    if not first.prepared:
        return False, "", "first build was not prepared"
    tmp = tempfile.mkdtemp(prefix="albion_repro_")
    try:
        sink = DiagnosticSink()
        cfg = load_config(target.cfg.name, config_dir, sink)
        if cfg is None:
            return False, "", "cannot reload configuration"
        ctx2 = BuildContext(cfg, repo_root, tmp, param_ov, block_ov)
        t2 = Target(ctx2, cfg)
        run_stages(t2, stages)
        with open(os.path.join(first.build_dir, "manifest.json")) as fh:
            m1 = json.load(fh)
        with open(os.path.join(ctx2.build_dir, "manifest.json")) as fh:
            m2 = json.load(fh)
        d1, d2 = m1["repro_digest"], m2["repro_digest"]
        return d1 == d2, d1, d2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
