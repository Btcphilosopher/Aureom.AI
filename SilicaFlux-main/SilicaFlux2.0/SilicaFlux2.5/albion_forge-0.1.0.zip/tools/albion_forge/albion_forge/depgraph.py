"""Dependency resolution over scanned HDL sources.

Given a set of scanned files and a top module, produce:

* a *deterministic* dependency-first compile order (lexicographically smallest
  topological order, independent of the order files were supplied in);
* diagnostics -- each attributed to file / line / module -- for missing
  modules, missing packages, duplicate definitions, circular dependencies,
  missing includes and an unknown top.

Resolution is name based and global within the supplied set; that is exactly
how the EDA tools see a flat file list, which is why the forge never mixes
source sets from different archive snapshots (the repository contains up to 24
conflicting versions of ``silicaflux_pkg``).
"""
from __future__ import annotations

import dataclasses
import heapq
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

from .diagnostics import DiagnosticSink
from .sv_scan import Decl, ScanResult

__all__ = ["SourceFile", "Resolution", "resolve", "candidate_tops", "PRIMITIVES"]

#: Verilog built-in primitives / things that look like instances but are not
#: design units.  (Gate primitives are filtered by the scanner already; these
#: are belt-and-braces.)
PRIMITIVES = frozenset({
    "and", "nand", "or", "nor", "xor", "xnor", "not", "buf", "bufif0", "bufif1",
    "notif0", "notif1", "pullup", "pulldown", "nmos", "pmos", "cmos", "tran",
})


@dataclasses.dataclass
class SourceFile:
    """A source file the forge has materialised on disk."""

    logical: str                  # stable, repo-relative identity ("archive:path")
    path: str                     # absolute on-disk path of the compilable file
    scan: ScanResult
    role: str = "rtl"             # rtl | tb | model | header
    group: str = ""               # source-group id from the configuration
    is_header: bool = False

    @property
    def sha256(self) -> str:
        return self.scan.sha256


@dataclasses.dataclass
class Resolution:
    top: str
    order: List[SourceFile]                    # dependency-first compile order
    units: Dict[str, List[Tuple[Decl, SourceFile]]]
    closure_units: List[str]                   # unit names reachable from top (sorted)
    missing_units: List[Tuple[str, str, str, int]]   # (target, parent, file, line)
    missing_packages: List[Tuple[str, str, str, int]]
    cycles: List[List[str]]
    duplicates: Dict[str, List[str]]           # name -> [logical file, ...]
    include_dirs: List[str]
    ok: bool


def _index(files: Sequence[SourceFile], sink: DiagnosticSink, closure_hint: Optional[Set[str]] = None
           ) -> Tuple[Dict[str, List[Tuple[Decl, SourceFile]]], Dict[str, List[str]]]:
    """Index definitions by name.

    A declaration reached through ``include`` is attributed to the file that
    *physically defines it* (``Decl.file``), not to every includer; the same
    physical definition reached from many includers is one definition.  This
    matters for the v1.0 SilicaFlux files, which each ``include`` the package
    file textually.
    """
    by_path = {f.path: f for f in files}
    units: Dict[str, List[Tuple[Decl, SourceFile]]] = {}
    seen_loc: Set[Tuple[str, int, str]] = set()
    for f in sorted(files, key=lambda x: x.logical):
        if f.is_header:
            continue
        for d in f.scan.decls:
            loc = (d.file, d.line, d.name)
            if loc in seen_loc:
                continue
            seen_loc.add(loc)
            owner = by_path.get(d.file, f)
            units.setdefault(d.name, []).append((d, owner))
    dups: Dict[str, List[str]] = {}
    for name, defs in units.items():
        seen: Dict[str, Tuple[Decl, SourceFile]] = {}
        for d, f in defs:
            seen.setdefault(f.logical + f":{d.line}", (d, f))
        if len(seen) > 1:
            dups[name] = sorted(seen)
    return units, dups


def candidate_tops(files: Sequence[SourceFile]) -> List[str]:
    """Modules that are never instantiated anywhere in ``files`` (sorted)."""
    instantiated: Set[str] = set()
    defined: Dict[str, Decl] = {}
    for f in files:
        if f.is_header:
            continue
        for i in f.scan.instances:
            instantiated.add(i.target)
        for d in f.scan.decls:
            if d.kind in ("module", "interface", "program"):
                defined.setdefault(d.name, d)
    return sorted(n for n, d in defined.items() if n not in instantiated and d.kind == "module")


def resolve(files: Sequence[SourceFile], top: str, sink: DiagnosticSink, *,
            blackboxes: Iterable[str] = (), include_dirs: Sequence[str] = (),
            extra_roots: Sequence[str] = (),
            assertion_idioms: Sequence[str] = ("illegal_parameter_*", "*_param_error_*")) -> Resolution:
    """Resolve ``top`` (plus ``extra_roots`` -- e.g. a testbench) in ``files``.

    ``assertion_idioms`` are glob patterns of module names that RTL deliberately
    instantiates *without defining* inside a generate branch to turn an illegal
    parameter combination into an elaboration error (found in CloudDMA:
    ``illegal_parameter_BND_LOG2_at_most_12...``; HPC modules use ``hpc_param_error_*``).  They are not missing
    dependencies; they are reported as INFO, never as DEP001.
    """
    import fnmatch
    bb = set(blackboxes)
    files = list(files)
    n_errors_before = len(sink.errors)
    units, dups = _index(files, sink)

    # -- header include failures are reported per file ----------------------
    for f in sorted(files, key=lambda x: x.logical):
        for inc, line, resolved in f.scan.includes:
            if resolved is None:
                sink.error("DEP005", f"`include \"{inc}\" not found on the include path",
                           file=f.logical, line=line)
        for ln, msg in f.scan.parse_errors:
            sink.error("LNG003", msg, file=f.logical, line=ln)

    roots = [top] + [r for r in extra_roots if r != top]
    for r in roots:
        if r not in units:
            sink.error("DEP006", f"top module '{r}' is not defined in any of the {len(files)} resolved source files",
                       hint="check the configuration's `top` / source globs; candidate tops: "
                            + ", ".join(candidate_tops(files)[:8]))
    if any(r not in units for r in roots):
        return Resolution(top, [], units, [], [], [], [], dups, list(include_dirs), False)

    def pick(name: str) -> Tuple[Decl, SourceFile]:
        return units[name][0]   # deterministic: files sorted by logical path

    # -- reachability over unit graph ------------------------------------------
    edges: Dict[str, Set[str]] = {}
    edge_loc: Dict[Tuple[str, str], Tuple[str, int]] = {}
    missing_units: List[Tuple[str, str, str, int]] = []
    missing_pkgs: List[Tuple[str, str, str, int]] = []
    bad_scope: List[Tuple[str, str, str, str, int]] = []
    idioms: List[Tuple[str, str, str, int]] = []
    soft_missing: List[Tuple[str, str, str, int]] = []
    seen: Set[str] = set()
    queue: List[str] = list(roots)
    typedef_names: Set[str] = set()
    for f in files:
        typedef_names |= f.scan.typedefs
    ignore_scopes = {"std", "$unit", "local", "super", "this"}

    sibling_done: Set[str] = set()

    def process(name: str, full: bool) -> None:
        """Walk one unit.  ``full`` follows instances and packages; the
        sibling mode (units that merely share a file with a reachable unit)
        follows *package references only*: the tools parse the whole file, so
        an import in a sibling must resolve, but the sibling's own children
        need not exist."""
        d, f = pick(name)
        out = edges.setdefault(name, set())
        if full:
            for i in f.scan.instances:
                if i.parent != name:
                    continue
                tgt = i.target
                if tgt in units:
                    out.add(tgt)
                    edge_loc.setdefault((name, tgt), (f.logical if i.file == f.scan.path else _rel(i.file, files), i.line))
                    queue.append(tgt)
                elif tgt in bb or tgt in PRIMITIVES:
                    continue
                elif i.via_macro:
                    soft_missing.append((tgt, name, f.logical, i.line))
                elif any(fnmatch.fnmatchcase(tgt, pat) for pat in assertion_idioms):
                    idioms.append((tgt, name, f.logical, i.line))
                else:
                    missing_units.append((tgt, name, _rel(i.file, files) if i.file != f.scan.path else f.logical, i.line))
        for r in f.scan.refs:
            if r.parent != name:
                continue
            pk = r.package
            if pk == name or pk in ignore_scopes:
                continue
            if pk in units and units[pk][0][0].kind == "package":
                out.add(pk)
                edge_loc.setdefault((name, pk), (f.logical if r.file == f.scan.path else _rel(r.file, files), r.line))
                queue.append(pk)
            elif pk in units:
                # `X::` / `import X::*` where X is a module / interface / program:
                # illegal SystemVerilog (only packages and classes are scopes)
                kind = units[pk][0][0].kind
                bad_scope.append((pk, kind, name, f.logical if r.file == f.scan.path else _rel(r.file, files), r.line))
            elif pk in typedef_names or pk in bb:
                continue
            elif r.via_macro:
                soft_missing.append((pk, name, f.logical, r.line))
            else:
                missing_pkgs.append((pk, name, f.logical if r.file == f.scan.path else _rel(r.file, files), r.line))
        # compilation-unit scope references (outside any unit)
        for r in f.scan.refs:
            if r.parent == "" and r.package in units and units[r.package][0][0].kind == "package" \
                    and r.package != name:
                out.add(r.package)
                queue.append(r.package)

    while True:
        while queue:
            name = queue.pop()
            if name in seen:
                continue
            seen.add(name)
            process(name, full=True)
        # sibling units in files already selected: package references only
        grew = False
        for name in sorted(seen):
            f = pick(name)[1]
            for d2 in f.scan.decls:
                if d2.name not in seen and d2.name not in sibling_done and d2.name in units:
                    sibling_done.add(d2.name)
                    process(d2.name, full=False)
                    grew = True
        if not grew and not queue:
            break

    # report missing (deduplicated, deterministic)
    for tgt, parent, ffile, line in sorted(set(missing_units)):
        sink.error("DEP001", f"module '{tgt}' is instantiated by '{parent}' but is not defined in the resolved sources",
                   file=ffile, line=line, module=parent,
                   hint="add the source that defines it, or list it under `blackboxes` if it is a technology cell / macro")
    for pk, parent, ffile, line in sorted(set(missing_pkgs)):
        sink.error("DEP002", f"package '{pk}' is referenced by '{parent}' but is not defined in the resolved sources",
                   file=ffile, line=line, module=parent)

    for tgt, parent, ffile, line in sorted(set(soft_missing)):
        sink.warning("DEP001", f"'{tgt}' is referenced only inside a `define body of '{parent}' and is not defined "
                     "(ignored: the macro may never be expanded)", file=ffile, line=line, module=parent)
    for tgt, parent, ffile, line in sorted(set(idioms)):
        sink.info("DEP001", f"'{tgt}' is intentionally undefined (elaboration-assertion idiom) in '{parent}'",
                  file=ffile, line=line, module=parent)
    for pk, kind, parent, ffile, line in sorted(set(bad_scope)):
        sink.error("DEP002", f"'{pk}' is used as a package scope ('{pk}::') by '{parent}' but is defined as a {kind}, not a package",
                   file=ffile, line=line, module=parent,
                   hint="only packages (and classes) provide a `::` scope; declare it with `package`")

    # duplicates: only an error when the ambiguity can matter (name reachable)
    for name in sorted(dups):
        locs = dups[name]
        if name in seen:
            hashes = {fl.sha256 for _, fl in units[name]}
            if len(hashes) == 1:
                sink.warning("DEP008", f"'{name}' defined in {len(locs)} files with identical content: {', '.join(locs)}",
                             module=name, file=locs[0])
            else:
                d0, f0 = units[name][0]
                sink.error("DEP004", f"'{name}' has {len(locs)} conflicting definitions: " + "; ".join(locs),
                           module=name, file=f0.logical, line=d0.line,
                           hint="flat compilation takes one definition per name; split the source group or remove one")
        else:
            sink.warning("DEP004", f"'{name}' is defined in {len(locs)} files (not reachable from the top; ignored): "
                         + "; ".join(locs), module=name, file=locs[0])

    # cycles -----------------------------------------------------------------------
    cycles = _sccs(edges)
    for cyc in cycles:
        walk = _cycle_walk(cyc, edges)
        path = " -> ".join(walk + [walk[0]])
        loc = edge_loc.get((walk[0], walk[1 % len(walk)]), (None, None))
        sink.error("DEP003", f"circular dependency: {path}", module=cyc[0], file=loc[0], line=loc[1],
                   hint="break the cycle (a package may not import a package that imports it back; "
                        "a module may not instantiate itself)")

    # compile order over files -------------------------------------------------------
    order = _file_order([pick(n)[1] for n in sorted(seen)], units, edges)
    ok = len(sink.errors) == n_errors_before
    return Resolution(top, order, units, sorted(seen), sorted(set(missing_units)),
                      sorted(set(missing_pkgs)), cycles, dups, list(include_dirs), ok)


def _cycle_walk(scc: List[str], edges: Dict[str, Set[str]]) -> List[str]:
    """A real cycle through the smallest node of the SCC (shortest path back to
    it, BFS restricted to the SCC), so the reported path is one that exists."""
    members = set(scc)
    start = scc[0]
    prev: Dict[str, Optional[str]] = {}
    frontier = [start]
    seen = {start}
    while frontier:
        nxt = []
        for n in frontier:
            for m in sorted(edges.get(n, ())):
                if m not in members:
                    continue
                if m == start:
                    path = [n]
                    while path[-1] != start:
                        path.append(prev[path[-1]])  # type: ignore[arg-type]
                    path.reverse()
                    return path
                if m not in seen:
                    seen.add(m)
                    prev[m] = n
                    nxt.append(m)
        frontier = nxt
    return scc


def _rel(path: str, files: Sequence[SourceFile]) -> str:
    """Logical name for an included-header path."""
    for f in files:
        if f.path == path:
            return f.logical
    return path


def _sccs(edges: Dict[str, Set[str]]) -> List[List[str]]:
    """Tarjan; returns cyclic SCCs (size>1 or self loop), each rotated to start at
    its smallest name; list sorted -- deterministic."""
    index: Dict[str, int] = {}
    low: Dict[str, int] = {}
    on: Set[str] = set()
    stack: List[str] = []
    out: List[List[str]] = []
    counter = [0]

    def strong(v: str) -> None:
        # iterative to avoid recursion limits on deep hierarchies
        work = [(v, iter(sorted(edges.get(v, ()))))]
        index[v] = low[v] = counter[0]
        counter[0] += 1
        stack.append(v)
        on.add(v)
        while work:
            node, it = work[-1]
            advanced = False
            for w in it:
                if w not in index:
                    index[w] = low[w] = counter[0]
                    counter[0] += 1
                    stack.append(w)
                    on.add(w)
                    work.append((w, iter(sorted(edges.get(w, ())))))
                    advanced = True
                    break
                elif w in on:
                    low[node] = min(low[node], index[w])
            if advanced:
                continue
            work.pop()
            if work:
                parent = work[-1][0]
                low[parent] = min(low[parent], low[node])
            if low[node] == index[node]:
                comp = []
                while True:
                    w = stack.pop()
                    on.discard(w)
                    comp.append(w)
                    if w == node:
                        break
                if len(comp) > 1 or node in edges.get(node, ()):
                    comp.sort()
                    out.append(comp)

    for v in sorted(edges):
        if v not in index:
            strong(v)
    out.sort()
    return out


def _file_order(files: List[SourceFile], units: Dict[str, List[Tuple[Decl, SourceFile]]],
                edges: Dict[str, Set[str]]) -> List[SourceFile]:
    """Lexicographically-smallest topological order of files, dependencies first."""
    by_logical = {f.logical: f for f in files}
    deps: Dict[str, Set[str]] = {f.logical: set() for f in files}
    for name, tgts in edges.items():
        src = units[name][0][1].logical
        for t in tgts:
            dst = units[t][0][1].logical
            if dst != src and dst in deps:
                deps[src].add(dst)
    # Kahn with a heap keyed on logical path
    indeg = {k: len(v) for k, v in deps.items()}
    rev: Dict[str, Set[str]] = {k: set() for k in deps}
    for k, v in deps.items():
        for d in v:
            rev[d].add(k)
    heap = [k for k, v in indeg.items() if v == 0]
    heapq.heapify(heap)
    out: List[str] = []
    while heap:
        k = heapq.heappop(heap)
        out.append(k)
        for m in sorted(rev[k]):
            indeg[m] -= 1
            if indeg[m] == 0:
                heapq.heappush(heap, m)
    # file-level cycle that is not a unit-level cycle (two files, each referencing
    # a different unit of the other): append the remainder sorted, deterministic.
    rest = sorted(k for k in deps if k not in set(out))
    out.extend(rest)
    return [by_logical[k] for k in out]
