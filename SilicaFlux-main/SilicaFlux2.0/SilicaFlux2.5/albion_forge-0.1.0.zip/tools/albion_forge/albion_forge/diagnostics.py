"""Structured diagnostics for AlbionForge.

Every problem the forge can detect is reported as a :class:`Diagnostic`
carrying a stable machine-readable ``code``, a severity, and -- wherever the
information exists -- the *file*, *line* and *module* it belongs to.  Human
output and the JSON build manifest are both rendered from the same objects, so
"error reporting by file and module" is a property of the data model rather
than of string formatting.

Codes are part of the public interface (tests and CI match on them).  Adding a
code is fine; renaming one is a breaking change.
"""
from __future__ import annotations

import dataclasses
import enum
from typing import Iterable, List, Optional

__all__ = [
    "Severity",
    "Diagnostic",
    "ForgeError",
    "DiagnosticSink",
    "CODES",
]


class Severity(enum.IntEnum):
    INFO = 10
    WARNING = 20
    ERROR = 30

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.name.lower()


#: Registry of every diagnostic code with a one-line meaning.  ``docs`` and
#: ``albion codes`` render from this table so the documentation cannot drift.
CODES = {
    # configuration -----------------------------------------------------
    "CFG001": "configuration file cannot be read or is not valid TOML",
    "CFG002": "configuration schema violation (missing / unknown / wrongly typed key)",
    "CFG003": "configuration refers to a configuration, group or block that does not exist",
    "CFG004": "configuration is not enabled (no RTL backs it, see blocker field)",
    "CFG005": "parameter override is invalid (unknown, out of range, wrong type, not overridable)",
    "CFG006": "optional block combination is invalid (requires / conflicts)",
    "CFG007": "clock target is invalid",
    # sources -----------------------------------------------------------
    "SRC001": "source file / archive member not found",
    "SRC002": "source content hash does not match the pinned hash",
    "SRC003": "archive is unreadable or contains an unsafe path",
    "SRC004": "file language / extension is not supported by this configuration",
    "SRC005": "translation of a non-SystemVerilog source is required but unavailable",
    # dependency analysis -------------------------------------------------
    "DEP001": "module / interface / program is instantiated but never defined",
    "DEP002": "package is referenced but never defined",
    "DEP003": "circular dependency",
    "DEP004": "duplicate definition (same name defined in more than one place)",
    "DEP005": "`include file not found",
    "DEP006": "top module not found in the resolved sources",
    "DEP007": "top module is ambiguous or is not a design top",
    "DEP008": "identical file content supplied more than once (deduplicated)",
    # language constructs ---------------------------------------------------
    "LNG001": "construct not supported by the selected language profile",
    "LNG002": "simulation-only construct present in synthesizable RTL",
    "LNG003": "source could not be tokenised / parsed (unbalanced construct)",
    # parameters ------------------------------------------------------------
    "PAR001": "parameter is not declared by the module it is applied to",
    "PAR002": "parameter is a localparam / not overridable",
    "PAR003": "parameter value violates a declared constraint",
    # toolchain --------------------------------------------------------------
    "TLS001": "required tool is not installed",
    "TLS002": "tool version is older than the minimum supported version",
    "TLS003": "optional tool is not installed (stage skipped, not passed)",
    "TLS004": "tool version differs from the version pinned in the configuration",
    # stages ------------------------------------------------------------------
    "STG001": "tool invocation failed",
    "STG002": "tool warning promoted to error by policy",
    "STG003": "simulation did not report PASS",
    "STG004": "stage skipped",
    "STG005": "tool output contained an unwaived warning",
    "STG006": "waiver is stale (matches nothing) or lacks a reason",
    "STG007": "stage produced no result artifact",
    # manifest / reproducibility ------------------------------------------------
    "MAN001": "reproducibility check failed (two builds differ)",
    "MAN002": "source tree is dirty / not at a recorded revision",
}


@dataclasses.dataclass(frozen=True)
class Diagnostic:
    """One reported problem, always attributable to a location when known."""

    code: str
    severity: Severity
    message: str
    file: Optional[str] = None
    line: Optional[int] = None
    module: Optional[str] = None
    hint: Optional[str] = None

    def __post_init__(self) -> None:
        if self.code not in CODES:
            raise ValueError(f"unregistered diagnostic code {self.code!r}")

    # -- rendering -----------------------------------------------------------
    def location(self) -> str:
        parts = []
        if self.file:
            parts.append(self.file + (f":{self.line}" if self.line else ""))
        if self.module:
            parts.append(f"[module {self.module}]")
        return " ".join(parts)

    def render(self) -> str:
        loc = self.location()
        head = f"{self.severity}: {self.code}"
        out = f"{head}: {loc}: {self.message}" if loc else f"{head}: {self.message}"
        if self.hint:
            out += f"\n      hint: {self.hint}"
        return out

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "severity": str(self.severity),
            "message": self.message,
            "file": self.file,
            "line": self.line,
            "module": self.module,
            "hint": self.hint,
        }


class DiagnosticSink:
    """Ordered collector.  Order is the order of emission, which the analysers
    make deterministic (sorted inputs), so the report is reproducible."""

    def __init__(self) -> None:
        self.items: List[Diagnostic] = []

    def add(self, code: str, severity: Severity, message: str, **kw) -> Diagnostic:
        d = Diagnostic(code, severity, message, **kw)
        self.items.append(d)
        return d

    def error(self, code: str, message: str, **kw) -> Diagnostic:
        return self.add(code, Severity.ERROR, message, **kw)

    def warning(self, code: str, message: str, **kw) -> Diagnostic:
        return self.add(code, Severity.WARNING, message, **kw)

    def info(self, code: str, message: str, **kw) -> Diagnostic:
        return self.add(code, Severity.INFO, message, **kw)

    def extend(self, other: Iterable[Diagnostic]) -> None:
        self.items.extend(other)

    @property
    def errors(self) -> List[Diagnostic]:
        return [d for d in self.items if d.severity >= Severity.ERROR]

    @property
    def warnings(self) -> List[Diagnostic]:
        return [d for d in self.items if d.severity == Severity.WARNING]

    def has_errors(self) -> bool:
        return any(d.severity >= Severity.ERROR for d in self.items)

    def codes(self) -> List[str]:
        return [d.code for d in self.items]


class ForgeError(Exception):
    """Raised for conditions that make continuing pointless.  Carries the
    diagnostics that explain it so the CLI can still print file/module info."""

    def __init__(self, diagnostics: Iterable[Diagnostic] | Diagnostic):
        if isinstance(diagnostics, Diagnostic):
            diagnostics = [diagnostics]
        self.diagnostics: List[Diagnostic] = list(diagnostics)
        super().__init__("; ".join(d.render() for d in self.diagnostics))
