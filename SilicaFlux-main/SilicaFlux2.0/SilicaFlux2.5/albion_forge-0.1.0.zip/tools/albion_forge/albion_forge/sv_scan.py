"""Lightweight, dependency-free SystemVerilog structural scanner.

This is *not* a SystemVerilog parser and the forge never relies on it for
semantic correctness -- Verilator / Yosys / Icarus remain the ground truth for
whether a design elaborates.  The scanner exists so the forge can, **before any
EDA tool runs**:

* find design-unit declarations (module / interface / program / package) and
  the file and line they live in;
* find instantiations and package references, to build a dependency graph and
  report missing units, duplicate definitions and cycles with file/module
  attribution;
* read module parameter lists, so configuration overrides can be validated
  against what the RTL really declares;
* classify constructs that are simulation-only or outside the supported
  language profile.

Accuracy is checked in two ways: unit tests with hand-written fixtures, and --
more importantly -- every dependency-ordered file list the forge produces is
then compiled by a real tool; a dependency the scanner missed surfaces as a
tool error, never as a silent pass.

Preprocessing is deliberately small: comments and strings are blanked while
preserving line numbers, ``define`` / ``undef`` / ``ifdef`` family conditionals
are evaluated against an explicit define set, and ``include`` is followed with
an explicit include-directory list.  Function-like macro expansion is *not*
performed (macro uses are recorded as opaque directives).
"""
from __future__ import annotations

import dataclasses
import hashlib
import os
import re
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "Param",
    "Decl",
    "Instance",
    "Ref",
    "Finding",
    "ScanResult",
    "scan_file",
    "scan_text",
    "strip_comments",
    "classify_sf",
    "SV_KEYWORDS",
]

# --------------------------------------------------------------------------
# keyword tables
# --------------------------------------------------------------------------
_KW = """
accept_on alias always always_comb always_ff always_latch and assert assign assume
automatic before begin bind bins binsof bit break buf bufif0 bufif1 byte case casex
casez cell chandle checker class clocking cmos config const constraint context continue
cover covergroup coverpoint cross deassign default defparam design disable dist do edge
else end endcase endchecker endclass endclocking endconfig endfunction endgenerate
endgroup endinterface endmodule endpackage endprimitive endprogram endproperty endsequence
endspecify endtable endtask enum event eventually expect export extends extern final
first_match for force foreach forever fork forkjoin function generate genvar global highz0
highz1 if iff ifnone ignore_bins illegal_bins implements implies import incdir include
initial inout input inside instance int integer interconnect interface intersect join
join_any join_none large let liblist library local localparam logic longint macromodule
matches medium modport module nand negedge nettype new nexttime nmos nor noshowcancelled
not notif0 notif1 null or output package packed parameter pmos posedge primitive priority
program property protected pull0 pull1 pulldown pullup pulsestyle_ondetect
pulsestyle_onevent pure rand randc randcase randsequence rcmos real realtime ref reg
reject_on release repeat restrict return rnmos rpmos rtran rtranif0 rtranif1 s_always
s_eventually s_nexttime s_until s_until_with scalared sequence shortint shortreal
showcancelled signed small soft solve specify specparam static string strong strong0
strong1 struct super supply0 supply1 sync_accept_on sync_reject_on table tagged task this
throughout time timeprecision timeunit tran tranif0 tranif1 tri tri0 tri1 triand trior
trireg type typedef union unique unique0 unsigned until until_with untyped use uwire var
vectored virtual void wait wait_order wand weak weak0 weak1 while wildcard wire with
within wor xnor xor
"""
SV_KEYWORDS: frozenset = frozenset(_KW.split())

_UNIT_KW = {"module": "module", "macromodule": "module", "interface": "interface",
            "program": "program", "package": "package"}
_END_KW = {"endmodule": "module", "endinterface": "interface",
           "endprogram": "program", "endpackage": "package"}

# Constructs that are never part of synthesizable RTL.  Mapped to a
# *category* string; the language profile decides what to do with a category.
_SIM_KEYWORDS = {
    "initial": "initial_block",
    "final": "final_block",
    "fork": "fork_join",
    "join": "fork_join",
    "join_any": "fork_join",
    "join_none": "fork_join",
    "class": "class",
    "endclass": "class",
    "program": "program",
    "covergroup": "covergroup",
    "coverpoint": "covergroup",
    "constraint": "constraint_random",
    "rand": "constraint_random",
    "randc": "constraint_random",
    "randcase": "constraint_random",
    "randsequence": "constraint_random",
    "force": "force_release",
    "release": "force_release",
    "wait": "wait_stmt",
    "event": "event_type",
    "chandle": "dpi",
    "mailbox": "ipc",
    "semaphore": "ipc",
}
# Concurrent assertion constructs (immediate assert is handled separately).
_ASSERT_KEYWORDS = {"property", "sequence", "endproperty", "endsequence", "checker"}

_SYS_SIM = {
    "$display", "$write", "$monitor", "$strobe", "$displayb", "$displayh", "$displayo",
    "$finish", "$stop",
    "$random", "$urandom", "$urandom_range", "$dist_uniform",
    "$fopen", "$fclose", "$fwrite", "$fdisplay", "$fscanf", "$fgets", "$fflush",
    "$readmemh", "$readmemb", "$dumpfile", "$dumpvars", "$dumpoff", "$dumpon", "$dumpall",
    "$time", "$stime", "$realtime", "$system", "$test$plusargs", "$value$plusargs",
    "$sformat", "$sformatf", "$swrite", "$timeformat", "$assertoff", "$asserton",
    "$assertkill", "$coverage_control", "$get_coverage",
}
# severity tasks are legal at elaboration time (generate blocks); recorded separately
_SYS_SEVERITY = {"$fatal", "$error", "$warning", "$info"}
# system functions that are elaboration-time constants and fine in RTL
_SYS_RTL_OK = {
    "$clog2", "$bits", "$size", "$signed", "$unsigned", "$countones", "$onehot",
    "$onehot0", "$isunknown", "$high", "$low", "$left", "$right", "$increment",
    "$dimensions", "$unpacked_dimensions", "$typename", "$cast", "$rtoi", "$itor",
    "$ceil", "$floor", "$ln", "$log10", "$exp", "$sqrt", "$pow", "$setuphold",
    "$setup", "$hold", "$width", "$period", "$recovery", "$removal", "$skew",
    "$fell", "$rose", "$stable", "$past", "$changed", "$countbits", "$root",
}

# --------------------------------------------------------------------------
# data model
# --------------------------------------------------------------------------


@dataclasses.dataclass(frozen=True)
class Param:
    name: str
    default: Optional[str]      # raw default-expression text, None if absent
    kind: str                   # "parameter" | "localparam" | "type"
    ptype: str = ""             # raw type text ("int unsigned", "logic [7:0]", ...)


@dataclasses.dataclass
class Decl:
    kind: str                   # module | interface | program | package
    name: str
    file: str
    line: int
    end_line: int = 0
    params: List[Param] = dataclasses.field(default_factory=list)
    ports: List[str] = dataclasses.field(default_factory=list)
    n_ports_ansi: int = 0
    has_param_port_list: bool = False     # `#( ... )` present (then body `parameter` is a localparam, IEEE 1800)


@dataclasses.dataclass
class Instance:
    parent: str                 # enclosing design unit name
    target: str                 # instantiated unit name
    inst_name: str
    file: str
    line: int
    overrides: Tuple[str, ...] = ()       # named parameter overrides (".NAME")
    positional_overrides: int = 0
    via_macro: bool = False               # found in a `define body (soft dependency)


@dataclasses.dataclass
class Ref:
    parent: str                 # enclosing design unit ("" = compilation unit scope)
    package: str
    form: str                   # "import" | "scope" | "export"
    file: str
    line: int
    via_macro: bool = False


@dataclasses.dataclass
class Finding:
    category: str               # e.g. "initial_block", "system_task", "delay", "class" ...
    token: str
    file: str
    line: int
    module: str                 # enclosing unit ("" if none)


@dataclasses.dataclass
class ScanResult:
    path: str
    sha256: str
    n_lines: int
    decls: List[Decl] = dataclasses.field(default_factory=list)
    instances: List[Instance] = dataclasses.field(default_factory=list)
    refs: List[Ref] = dataclasses.field(default_factory=list)
    findings: List[Finding] = dataclasses.field(default_factory=list)
    includes: List[Tuple[str, int, Optional[str]]] = dataclasses.field(default_factory=list)
    defines_seen: Set[str] = dataclasses.field(default_factory=set)
    typedefs: Set[str] = dataclasses.field(default_factory=set)
    clock_reset: List[Tuple[str, str]] = dataclasses.field(default_factory=list)
    parse_errors: List[Tuple[int, str]] = dataclasses.field(default_factory=list)
    timescale: Optional[str] = None

    def decl_names(self) -> List[str]:
        return [d.name for d in self.decls]


# --------------------------------------------------------------------------
# comment / string stripping (line-preserving)
# --------------------------------------------------------------------------
_COMMENT_OR_STRING = re.compile(
    r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\\n])*"', re.S)


def strip_comments(text: str) -> str:
    """Blank comments (whitespace) and replace string literals with ``""`` of
    equal length, preserving every newline so line numbers stay valid."""

    def _sub(m: "re.Match[str]") -> str:
        s = m.group(0)
        if s.startswith('"'):
            return '"' + "_" * (len(s) - 2) + '"' if len(s) >= 2 else s
        return re.sub(r"[^\n]", " ", s)

    return _COMMENT_OR_STRING.sub(_sub, text)


def classify_sf(text: str) -> str:
    """Classify the *dialect* of a ``.sf`` file: ``"sv"`` or ``"dsl"``.

    The repository contains two unrelated things with the extension ``.sf``:
    SystemVerilog (header "Language: Silica Flux-2017", plain SV syntax) and a
    speculative DSL *sketch* (``package silicaflux.ml``, ``fixed T { ... }``,
    ``state machine``) that its own header says is documentation only and not
    compiled.  Only the first can be turned into a tool input.
    """
    t = strip_comments(text)
    if re.search(r"(?m)^\s*package\s+\w+(?:\.\w+)+\s*$", t):
        return "dsl"
    if re.search(r"(?m)^\s*fixed\s+\w+\s*\{", t) or re.search(r"(?m)^\s*state\s+machine\b", t):
        return "dsl"
    return "sv"


# --------------------------------------------------------------------------
# preprocessing: define / ifdef / include
# --------------------------------------------------------------------------
_DIRECTIVE_LINE = re.compile(r"^\s*`(\w+)\b(.*)$")


def _split_lines_with_continuations(text: str) -> List[Tuple[int, str]]:
    """Yield (first_line_number, logical_line) joining backslash continuations
    (only meaningful for `define).  Line numbers are 1-based."""
    out: List[Tuple[int, str]] = []
    raw = text.split("\n")
    i = 0
    while i < len(raw):
        start = i
        line = raw[i]
        while line.rstrip().endswith("\\") and i + 1 < len(raw):
            line = line.rstrip()[:-1] + " " + raw[i + 1]
            i += 1
        out.append((start + 1, line))
        i += 1
    return out


class _Pre:
    """One preprocessing session for a translation unit."""

    def __init__(self, defines: Dict[str, str], include_dirs: Sequence[str],
                 vfs: Optional[Dict[str, str]] = None):
        self.defines = dict(defines)
        self.include_dirs = list(include_dirs)
        self.include_stack: List[str] = []
        self.vfs = vfs

    def run(self, path: str, text: str, out_tokens_text: List[Tuple[str, int, str]],
            res: ScanResult, depth: int = 0) -> None:
        """Append (file, line_no, line_text) for every *live* source line of
        ``text`` to ``out_tokens_text``; recursion handles `include."""
        stripped = strip_comments(text)
        cond: List[Tuple[bool, bool, bool]] = []  # (parent_live, this_live, any_taken)
        live = True
        for lineno, line in _split_lines_with_continuations(stripped):
            m = _DIRECTIVE_LINE.match(line)
            if m:
                d, rest = m.group(1), m.group(2).strip()
                if d in ("ifdef", "ifndef"):
                    name = (rest.split() or [""])[0]
                    val = name in self.defines
                    taken = val if d == "ifdef" else not val
                    cond.append((live, live and taken, taken))
                    live = live and taken
                    continue
                if d == "elsif":
                    if cond:
                        parent_live, _, any_taken = cond.pop()
                        name = (rest.split() or [""])[0]
                        taken = (name in self.defines) and not any_taken
                        cond.append((parent_live, parent_live and taken, any_taken or taken))
                        live = parent_live and taken
                    continue
                if d == "else":
                    if cond:
                        parent_live, _, any_taken = cond.pop()
                        taken = not any_taken
                        cond.append((parent_live, parent_live and taken, True))
                        live = parent_live and taken
                    continue
                if d == "endif":
                    if cond:
                        parent_live, _, _ = cond.pop()
                        live = parent_live
                    else:
                        res.parse_errors.append((lineno, "`endif without `ifdef"))
                    continue
                if not live:
                    continue
                if d == "define":
                    mm = re.match(r"(\w+)(\([^)]*\))?\s*(.*)$", rest)
                    if mm:
                        self.defines[mm.group(1)] = mm.group(3)
                        res.defines_seen.add(mm.group(1))
                        body = mm.group(3)
                        # A macro body that looks like it contains an instantiation or a
                        # package scope is scanned as a *soft* dependency (it may never
                        # be expanded, so a missing target there is only a warning).
                        if "(" in body and re.search(r"\w\s*(#\s*\(|\w+\s*\()|::", body):
                            out_tokens_text.append((path, lineno, "`__MBODY__ " + body + " `__MEND__"))
                    continue
                if d == "undef":
                    self.defines.pop(rest.split()[0] if rest else "", None)
                    continue
                if d == "include":
                    mm = re.search(r'"([^"]*)"', rest) or re.search(r"<([^>]*)>", rest)
                    inc = None
                    resolved: Optional[str] = None
                    if mm:
                        # strings were underscored by strip_comments: recover from raw text
                        raw_line = text.split("\n")[lineno - 1]
                        mr = re.search(r'`include\s*["<]([^">]*)[">]', raw_line)
                        inc = mr.group(1) if mr else mm.group(1)
                        resolved = self._resolve_include(path, inc)
                    res.includes.append((inc or "?", lineno, resolved))
                    if resolved and resolved not in self.include_stack and depth < 16:
                        if self.vfs is not None:
                            itext = self.vfs.get(resolved, "")
                        else:
                            try:
                                with open(resolved, "r", encoding="utf-8", errors="replace") as fh:
                                    itext = fh.read()
                            except OSError:
                                continue
                        self.include_stack.append(resolved)
                        self.run(resolved, itext, out_tokens_text, res, depth + 1)
                        self.include_stack.pop()
                    continue
                if d == "timescale":
                    if res.timescale is None:
                        raw_line = text.split("\n")[lineno - 1]
                        res.timescale = raw_line.strip().replace("`timescale", "").strip()
                    continue
                if d in ("resetall", "celldefine", "endcelldefine", "default_nettype",
                         "pragma", "line", "begin_keywords", "end_keywords",
                         "unconnected_drive", "nounconnected_drive"):
                    continue
                # unknown directive at line start == macro use, keep the text
            if live:
                out_tokens_text.append((path, lineno, line))

    def _resolve_include(self, from_file: str, inc: str) -> Optional[str]:
        cands = []
        if os.path.isabs(inc):
            cands.append(inc)
        else:
            cands.append(os.path.join(os.path.dirname(from_file), inc))
            for d in self.include_dirs:
                cands.append(os.path.join(d, inc))
        for c in cands:
            c = os.path.normpath(c)
            if self.vfs is not None:
                if c in self.vfs:
                    return c
            elif os.path.isfile(c):
                return c
        return None


# --------------------------------------------------------------------------
# tokeniser
# --------------------------------------------------------------------------
_TOKEN = re.compile(r"""
  (?P<sys>\$[A-Za-z_][\w$]*)
 |(?P<dir>`[A-Za-z_]\w*)
 |(?P<num>\d[\d_]*\s*'[sS]?[bBoOdDhH]\s*[0-9a-fA-FxXzZ_?]+|'[sS]?[bBoOdDhH]\s*[0-9a-fA-FxXzZ_?]+|\d[\d_]*(?:\.\d[\d_]*)?(?:[eE][+-]?\d+)?|'[01xXzZ])
 |(?P<id>[A-Za-z_][\w$]*)
 |(?P<esc>\\\S+)
 |(?P<op>::|\+:|-:|\*\*|<<<|>>>|===|!==|==\?|!=\?|<=|>=|==|!=|&&|\|\||<<|>>|->|\#\#|\S)
""", re.X)

Tok = Tuple[str, str, str, int]  # (kind, text, file, line)


def _tokenise(lines: List[Tuple[str, int, str]]) -> List[Tok]:
    toks: List[Tok] = []
    for path, lineno, line in lines:
        # `@(*)` and attributes confuse paren matching: normalise early
        line = re.sub(r"@\s*\(\s*\*\s*\)", "@* ", line)
        for m in _TOKEN.finditer(line):
            kind = m.lastgroup or "op"
            toks.append((kind, m.group(0), path, lineno))
    # drop attributes "(* ... *)"
    out: List[Tok] = []
    i = 0
    n = len(toks)
    while i < n:
        t = toks[i]
        if t[1] == "(" and i + 1 < n and toks[i + 1][1] == "*" and not (
                i + 2 < n and toks[i + 2][1] == ")"):
            j = i + 2
            while j + 1 < n and not (toks[j][1] == "*" and toks[j + 1][1] == ")"):
                j += 1
            i = j + 2
            continue
        out.append(t)
        i += 1
    return out


def _match_paren(toks: List[Tok], i: int) -> int:
    """toks[i] is '(' ; return index of the matching ')' (or len-1)."""
    depth = 0
    n = len(toks)
    j = i
    while j < n:
        s = toks[j][1]
        if s == "(":
            depth += 1
        elif s == ")":
            depth -= 1
            if depth == 0:
                return j
        j += 1
    return n - 1


def _join(toks: Sequence[Tok]) -> str:
    return " ".join(t[1] for t in toks)


# --------------------------------------------------------------------------
# parameter list parsing
# --------------------------------------------------------------------------
def _parse_param_list(toks: Sequence[Tok], default_kind: str = "parameter") -> List[Param]:
    """Parse the tokens *inside* ``#( ... )`` (or a body ``parameter ... ;``)."""
    # split on top-level commas
    groups: List[List[Tok]] = [[]]
    depth = 0
    for t in toks:
        if t[1] in "([{":
            depth += 1
        elif t[1] in ")]}":
            depth -= 1
        if t[1] == "," and depth == 0:
            groups.append([])
        else:
            groups[-1].append(t)
    params: List[Param] = []
    kind = default_kind
    for g in groups:
        if not g:
            continue
        ts = list(g)
        if ts[0][1] in ("parameter", "localparam"):
            kind = ts[0][1]
            ts = ts[1:]
        elif ts[0][1] == "type" and False:  # handled below
            pass
        is_type = bool(ts) and ts[0][1] == "type"
        # find top-level '='
        eq = None
        d2 = 0
        for k, t in enumerate(ts):
            if t[1] in "([{":
                d2 += 1
            elif t[1] in ")]}":
                d2 -= 1
            elif t[1] == "=" and d2 == 0:
                eq = k
                break
        lhs = ts[:eq] if eq is not None else ts
        default = _join(ts[eq + 1:]) if eq is not None else None
        # name = last identifier in lhs (skip trailing unpacked dims  [..])
        name = None
        k = len(lhs) - 1
        d3 = 0
        while k >= 0:
            s = lhs[k][1]
            if s == "]":
                d3 += 1
            elif s == "[":
                d3 -= 1
            elif d3 == 0 and lhs[k][0] == "id":
                name = s
                break
            k -= 1
        if not name:
            continue
        ptype = _join(lhs[:k]) if k > 0 else ""
        if is_type:
            ptype = "type"
        params.append(Param(name, default, "type" if is_type else kind, ptype))
    return params


_CLOCK_RE = re.compile(r"^(?:i_)?(?:a?clk|clock|clk_?\w*|\w*_clk(?:_i)?|\w*clk_i)$", re.I)
_RESET_RE = re.compile(
    r"^(?:\w*rst\w*|\w*reset\w*|\w*aresetn?|\w*resetn?)$", re.I)


# --------------------------------------------------------------------------
# main scan
# --------------------------------------------------------------------------
_STMT_BOUNDARY = {"begin", "end", "generate", "endgenerate", "else", "endcase",
                  "endfunction", "endtask", "join", "join_any", "join_none",
                  "endclass", "endgroup", "endclocking", "endspecify", "endtable",
                  "endprimitive", "endchecker", "endconfig"}
_STMT_HEAD_PAREN = {"if", "for", "foreach", "while", "repeat", "case", "casex",
                    "casez", "unique", "priority"}
_NOT_INSTANCE_HEAD = set(SV_KEYWORDS) | {
    "string", "mailbox", "semaphore", "process", "std", "uvm_component",
}
_GATE_PRIMS = {"and", "nand", "or", "nor", "xor", "xnor", "not", "buf", "bufif0",
               "bufif1", "notif0", "notif1", "pullup", "pulldown", "nmos", "pmos",
               "cmos", "tran", "tranif0", "tranif1", "rnmos", "rpmos", "rcmos",
               "rtran", "rtranif0", "rtranif1"}


def scan_text(path: str, text: str, defines: Optional[Dict[str, str]] = None,
              include_dirs: Sequence[str] = (), vfs: Optional[Dict[str, str]] = None) -> ScanResult:
    """Scan ``text``.  With ``vfs`` (virtual path -> text) ``include`` files are
    resolved against that mapping instead of the real filesystem."""
    sha = hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()
    res = ScanResult(path=path, sha256=sha, n_lines=text.count("\n") + 1)
    pre = _Pre(defines or {}, include_dirs, vfs)
    lines: List[Tuple[str, int, str]] = []
    pre.run(path, text, lines, res)
    toks = _tokenise(lines)
    _scan_tokens(toks, res)
    return res


def scan_file(path: str, defines: Optional[Dict[str, str]] = None,
              include_dirs: Sequence[str] = ()) -> ScanResult:
    with open(path, "rb") as fh:
        raw = fh.read()
    text = raw.decode("utf-8", errors="replace")
    res = scan_text(path, text, defines, include_dirs)
    res.sha256 = hashlib.sha256(raw).hexdigest()
    return res


def _scan_tokens(toks: List[Tok], res: ScanResult) -> None:
    n = len(toks)
    i = 0
    paren = 0
    stack: List[Decl] = []
    stmt: List[Tok] = []
    typedef_names: Set[str] = set()

    def cur() -> str:
        return stack[-1].name if stack else ""

    def add_finding(cat: str, tok: Tok) -> None:
        res.findings.append(Finding(cat, tok[1], tok[2], tok[3], cur()))

    while i < n:
        kind, s, f, ln = toks[i]
        prev = toks[i - 1][1] if i else ""

        # ---------------- macro bodies (soft dependencies) -----------------
        if kind == "dir" and s == "`__MBODY__":
            k = i + 1
            body: List[Tok] = []
            while k < n and not (toks[k][0] == "dir" and toks[k][1] == "`__MEND__"):
                body.append(toks[k])
                k += 1
            _scan_macro_body(body, stack[-1].name if stack else "", res, stack[-1] if stack else None)
            i = k + 1
            continue

        # ---------------- system tasks ---------------------------------
        if kind == "sys":
            if s in _SYS_SIM:
                add_finding("system_task", toks[i])
            elif s in _SYS_SEVERITY:
                add_finding("severity_task", toks[i])
            elif s not in _SYS_RTL_OK:
                add_finding("system_task_other", toks[i])

        # ---------------- delays -----------------------------------------
        if s == "#" and i + 1 < n:
            nxt = toks[i + 1]
            if nxt[0] == "num" or (nxt[0] == "id" and prev in (";", "begin", "=", "<=", "else",
                                                             "end", "assign", ")", "forever", ":")):
                add_finding("delay", toks[i])
            elif nxt[1] == "(" and prev in ("assign", ";", "begin", "=", "<=", ")", "else"):
                add_finding("delay", toks[i])

        # ---------------- parens --------------------------------------------
        if s == "(":
            paren += 1
        elif s == ")":
            paren = max(0, paren - 1)

        # ---------------- design-unit begin -----------------------------------
        if kind == "id" and s in _UNIT_KW and paren == 0 and prev not in ("virtual", "extern", "typedef", "import", "export", "end"):
            # `program`/`interface` as generic-interface-port or `interface class` are skipped
            j = i + 1
            if j < n and toks[j][1] == "class" and s == "interface":
                i += 1
                continue
            while j < n and toks[j][1] in ("automatic", "static"):
                j += 1
            if j < n and toks[j][0] == "id" and toks[j][1] not in SV_KEYWORDS:
                d = Decl(_UNIT_KW[s], toks[j][1], toks[j][2], toks[j][3])
                if s == "program":
                    add_finding("program", toks[i])
                # header: [import ...;]* [#( params )] [( ports )] ;
                k = j + 1
                while k < n and toks[k][1] == "import":
                    while k < n and toks[k][1] != ";":
                        if toks[k][1] == "::" and k > 0:
                            res.refs.append(Ref(d.name, toks[k - 1][1], "import", toks[k][2], toks[k][3]))
                        k += 1
                    k += 1
                if k < n and toks[k][1] == "#" and k + 1 < n and toks[k + 1][1] == "(":
                    e = _match_paren(toks, k + 1)
                    d.params = _parse_param_list(toks[k + 2:e])
                    d.has_param_port_list = True
                    k = e + 1
                if k < n and toks[k][1] == "(" and d.kind != "package":
                    e = _match_paren(toks, k)
                    hdr = toks[k + 1:e]
                    d.ports, d.n_ports_ansi = _extract_ports(hdr)
                    for pn, pdir in _clock_reset_from_ports(hdr):
                        res.clock_reset.append((d.name, pn))
                    k = e + 1
                stack.append(d)
                res.decls.append(d)
                stmt = []
                # tokens up to header end are consumed: skip to ';' (header terminator)
                hdr_start = j + 1
                while k < n and toks[k][1] != ";":
                    k += 1
                # scope references / system tasks inside the header (parameter
                # defaults such as `sfn_pkg::clog2c(DEPTH)`, port types such as
                # `pkg::t`) still count as dependencies of this unit
                for q in range(hdr_start, min(k, n)):
                    tq = toks[q]
                    if tq[1] == "::" and q > 0 and toks[q - 1][0] == "id" \
                            and toks[q - 1][1] not in ("local", "super", "std", "this"):
                        res.refs.append(Ref(d.name, toks[q - 1][1], "scope", tq[2], tq[3]))
                    elif tq[0] == "sys" and tq[1] in _SYS_SIM:
                        add_finding("system_task", tq)
                i = k + 1
                paren = 0
                continue
        if kind == "id" and s in _END_KW and stack:
            d = stack.pop()
            d.end_line = ln
            stmt = []
            i += 1
            # swallow ": name"
            if i + 1 < n and toks[i][1] == ":" and toks[i + 1][0] == "id":
                i += 2
            continue

        # ---------------- simulation-only keywords ---------------------------------
        if kind == "id":
            if s in _SIM_KEYWORDS and not (s == "program" and False):
                if s == "wait" and prev in (".", "::"):
                    pass
                elif s in ("rand", "event", "join") and (prev in (".", "::")):
                    pass
                else:
                    add_finding(_SIM_KEYWORDS[s], toks[i])
            elif s in _ASSERT_KEYWORDS:
                add_finding("concurrent_assertion", toks[i])
            elif s in ("assert", "assume", "cover", "expect"):
                # concurrent: followed by 'property' ; immediate: followed by '('
                if i + 1 < n and toks[i + 1][1] == "property":
                    add_finding("concurrent_assertion", toks[i])
                else:
                    add_finding("immediate_assertion", toks[i])
            elif s == "import" and i + 1 < n and toks[i + 1][0] == "num":
                pass
            elif s == "virtual" and i + 1 < n and toks[i + 1][1] == "interface":
                add_finding("virtual_interface", toks[i])
            elif s.startswith("uvm_"):
                add_finding("uvm", toks[i])

        # DPI import: import "DPI-C" ...
        if s == "import" and i + 1 < n and toks[i + 1][1].startswith('"'):
            add_finding("dpi", toks[i])

        # ---------------- package references -----------------------------------------
        if s == "import" and kind == "id" and stack is not None:
            # import pkg::name, pkg2::*;   (statement-level)
            k = i + 1
            if k < n and not toks[k][1].startswith('"'):
                while k < n and toks[k][1] != ";":
                    if toks[k][1] == "::" and k > 0 and toks[k - 1][0] == "id":
                        res.refs.append(Ref(cur(), toks[k - 1][1], "import", toks[k][2], toks[k][3]))
                    k += 1
                i = k + 1
                stmt = []
                continue
        if s == "export" and kind == "id":
            k = i + 1
            while k < n and toks[k][1] != ";":
                if toks[k][1] == "::" and k > 0 and toks[k - 1][0] == "id":
                    res.refs.append(Ref(cur(), toks[k - 1][1], "export", toks[k][2], toks[k][3]))
                k += 1
            i = k + 1
            stmt = []
            continue
        if s == "::" and i > 0 and toks[i - 1][0] == "id" and toks[i - 1][1] not in ("local", "super", "std", "this"):
            # scope reference `pkg::name` (not preceded by import, handled above)
            res.refs.append(Ref(cur(), toks[i - 1][1], "scope", f, ln))

        # ---------------- typedef names ----------------------------------------------------
        if s == "typedef":
            k = i + 1
            depth = 0
            last_id = None
            while k < n:
                t = toks[k][1]
                if t in "({[":
                    depth += 1
                elif t in ")}]":
                    depth -= 1
                elif t == ";" and depth == 0:
                    break
                if toks[k][0] == "id" and depth == 0:
                    last_id = t
                k += 1
            if last_id:
                typedef_names.add(last_id)

        # ---------------- statement assembly / instance detection -------------------------------
        if stack and stack[-1].kind != "package":
            if s in _STMT_BOUNDARY and kind == "id" and paren == 0:
                stmt = []
                # swallow "begin : label" / "end : label"
                if s in ("begin", "end") and i + 2 < n and toks[i + 1][1] == ":" and toks[i + 2][0] == "id":
                    i += 3
                    continue
                i += 1
                continue
            if s == ";" and paren == 0:
                if stmt and stmt[0][1] in ("parameter", "localparam"):
                    kind0 = stmt[0][1]
                    if kind0 == "parameter" and stack[-1].has_param_port_list:
                        kind0 = "localparam"      # IEEE 1800-2017 6.20.1
                    have = {p.name for p in stack[-1].params}
                    for prm in _parse_param_list(stmt[1:], kind0):
                        if prm.name not in have:
                            stack[-1].params.append(prm)
                else:
                    _analyse_stmt(stmt, stack[-1], res)
                stmt = []
                i += 1
                continue
            stmt.append(toks[i])
            # leading "if (...)" / "for (...)" / "case (...)" heads: drop them from the stmt
            if len(stmt) >= 1 and stmt[0][1] in _STMT_HEAD_PAREN and s == ")" and paren == 0:
                stmt = []
            # leading "x :" labels
        else:
            if s == ";" and paren == 0:
                stmt = []
        i += 1

    res.typedefs |= typedef_names
    # anything left open => unbalanced
    for d in stack:
        res.parse_errors.append((d.line, f"{d.kind} {d.name} has no matching end"))


def _extract_ports(hdr: Sequence[Tok]) -> Tuple[List[str], int]:
    """Names of ports in an ANSI header.  Best effort."""
    groups: List[List[Tok]] = [[]]
    depth = 0
    for t in hdr:
        if t[1] in "([{":
            depth += 1
        elif t[1] in ")]}":
            depth -= 1
        if t[1] == "," and depth == 0:
            groups.append([])
        else:
            groups[-1].append(t)
    names: List[str] = []
    for g in groups:
        if not g:
            continue
        # drop default / '=' part
        ts = []
        d2 = 0
        for t in g:
            if t[1] == "=" and d2 == 0:
                break
            if t[1] in "([{":
                d2 += 1
            elif t[1] in ")]}":
                d2 -= 1
            ts.append(t)
        # last identifier outside brackets
        d3 = 0
        for t in reversed(ts):
            if t[1] == "]":
                d3 += 1
            elif t[1] == "[":
                d3 -= 1
            elif d3 == 0 and t[0] == "id" and t[1] not in SV_KEYWORDS:
                names.append(t[1])
                break
    return names, len(names)


def _clock_reset_from_ports(hdr: Sequence[Tok]) -> List[Tuple[str, str]]:
    names, _ = _extract_ports(hdr)
    return [(n, "port") for n in names if _CLOCK_RE.match(n) or _RESET_RE.match(n)]


def _scan_macro_body(body: List[Tok], parent: str, res: ScanResult, unit: Optional[Decl]) -> None:
    """Soft scan of a ``define`` body.

    Macro bodies are not statement-structured (token pastes inside labels,
    unbalanced begin/end), so instead of statement splitting this searches the
    token stream for the instantiation pattern ``TYPE [#(...)] name (`` and for
    ``pkg::`` scope references.  Everything found is flagged ``via_macro`` and
    treated as a *soft* dependency by the resolver.
    """
    toks: List[Tok] = []
    i = 0
    while i < len(body):
        t = body[i]
        if t[1] == "##" and toks and i + 1 < len(body):
            nxt = body[i + 1]
            toks[-1] = (toks[-1][0], toks[-1][1] + nxt[1], toks[-1][2], toks[-1][3])
            i += 2
            continue
        toks.append(t)
        i += 1
    n = len(toks)
    for q, t in enumerate(toks):
        if t[1] == "::" and q > 0 and toks[q - 1][0] == "id" and toks[q - 1][1] not in ("local", "super", "std", "this"):
            res.refs.append(Ref(parent, toks[q - 1][1], "scope", t[2], t[3], via_macro=True))
    def plain_id(k: int) -> bool:
        return (0 <= k < n and toks[k][0] == "id" and toks[k][1] not in SV_KEYWORDS
                and toks[k][1] not in _GATE_PRIMS and toks[k][1] not in _NOT_INSTANCE_HEAD)
    for q in range(n):
        if not plain_id(q):
            continue
        if q > 0 and toks[q - 1][1] in (".", "::", "`", "\\"):
            continue
        if q + 1 < n and toks[q + 1][1] == "`":      # TYPE``K : pasted name, unknowable
            continue
        j = q + 1
        overrides: List[str] = []
        if j < n and toks[j][1] == "#" and j + 1 < n and toks[j + 1][1] == "(":
            e = _match_paren(toks, j + 1)
            inner = toks[j + 2:e]
            d = 0
            for r_, tt in enumerate(inner):
                if tt[1] in "([{":
                    d += 1
                elif tt[1] in ")]}":
                    d -= 1
                elif d == 0 and tt[1] == "." and r_ + 1 < len(inner) and inner[r_ + 1][0] == "id":
                    overrides.append(inner[r_ + 1][1])
            j = e + 1
        if plain_id(j) and j + 1 < n and toks[j + 1][1] == "(":
            res.instances.append(Instance(parent or "$unit", toks[q][1], toks[j][1], toks[q][2], toks[q][3],
                                          tuple(overrides), 0, True))


def _analyse_stmt(stmt: List[Tok], unit: Decl, res: ScanResult, via_macro: bool = False) -> None:
    """Detect `T [#(...)] name [dims] ( ... ) [, name2 (...)] ;`."""
    if not stmt:
        return
    ts = list(stmt)
    # strip leading `else` / labels
    while ts and (ts[0][1] in ("else",) or (len(ts) > 1 and ts[0][0] == "id" and ts[1][1] == ":"
                                           and ts[0][1] not in SV_KEYWORDS and ts[0][1] not in ("default",))):
        ts = ts[2:] if ts[0][1] != "else" else ts[1:]
    if not ts or ts[0][0] != "id":
        return
    head = ts[0][1]
    if head in _NOT_INSTANCE_HEAD or head in _GATE_PRIMS:
        return
    j = 1
    if j < len(ts) and ts[j][1] == "::":      # pkg::type x(...) not an instance form we model
        return
    overrides: List[str] = []
    positional = 0
    if j < len(ts) and ts[j][1] == "#":
        if j + 1 < len(ts) and ts[j + 1][1] == "(":
            e = _match_paren(ts, j + 1)
            inner = ts[j + 2:e]
            # named overrides ".NAME(" at depth 0
            d = 0
            expect_arg = True
            for q, t in enumerate(inner):
                if t[1] in "([{":
                    d += 1
                elif t[1] in ")]}":
                    d -= 1
                elif d == 0 and t[1] == "." and q + 1 < len(inner) and inner[q + 1][0] == "id":
                    overrides.append(inner[q + 1][1])
            if not overrides and inner:
                positional = 1 + sum(1 for t in _depth0(inner) if t[1] == ",")
            j = e + 1
        else:
            return  # delay, not an instance
    # instance name(s)
    first = True
    emitted = False
    while j < len(ts):
        if ts[j][0] != "id" or ts[j][1] in SV_KEYWORDS:
            break
        name_tok = ts[j]
        j += 1
        while j < len(ts) and ts[j][1] == "[":      # array of instances
            k = j
            d = 0
            while k < len(ts):
                if ts[k][1] == "[":
                    d += 1
                elif ts[k][1] == "]":
                    d -= 1
                    if d == 0:
                        break
                k += 1
            j = k + 1
        if j < len(ts) and ts[j][1] == "(":
            e = _match_paren(ts, j)
            res.instances.append(Instance(unit.name, head, name_tok[1], name_tok[2], name_tok[3],
                                          tuple(overrides), positional, via_macro))
            emitted = True
            j = e + 1
            if j < len(ts) and ts[j][1] == ",":
                j += 1
                continue
            break
        else:
            break
    return


def _depth0(toks: Sequence[Tok]) -> List[Tok]:
    out = []
    d = 0
    for t in toks:
        if t[1] in "([{":
            d += 1
        elif t[1] in ")]}":
            d -= 1
        elif d == 0:
            out.append(t)
    return out


# --------------------------------------------------------------------------
# convenience
# --------------------------------------------------------------------------
def always_ff_styles(text: str) -> Dict[str, int]:
    """Count reset styles in ``always_ff`` / ``always @`` sensitivity lists.

    Returns counts keyed by e.g. ``async_neg_reset`` / ``async_pos_reset`` /
    ``sync_or_none``.  Used only by the forensic inventory.
    """
    t = strip_comments(text)
    counts = {"async_neg_reset": 0, "async_pos_reset": 0, "sync_or_none": 0}
    for m in re.finditer(r"always(?:_ff)?\s*@\s*\(([^)]*)\)", t):
        sens = m.group(1)
        if not re.search(r"\b(posedge|negedge)\b", sens):
            continue
        edges = re.findall(r"\b(posedge|negedge)\s+(\w+)", sens)
        if len(edges) >= 2:
            second = edges[1]
            if second[0] == "negedge":
                counts["async_neg_reset"] += 1
            else:
                counts["async_pos_reset"] += 1
        else:
            counts["sync_or_none"] += 1
    return counts
