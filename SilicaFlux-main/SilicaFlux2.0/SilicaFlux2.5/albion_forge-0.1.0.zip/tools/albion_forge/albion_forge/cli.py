"""``albion`` command line.

    albion list
    albion doctor
    albion lint|elaborate|simulate|synth  [--config NAME ... | --all] [--param K=V] [--block B=on|off]
    albion test   [--config NAME | --all] [--forge-only | --design-only]
    albion report [--config NAME | --all]
    albion ci     [--config NAME | --all] [--reproduce] [--allow-missing-tools]
    albion inventory | pin | codes

Exit status: 0 success, 1 a stage failed, 2 usage/configuration error,
3 blocked (required tool missing / explicitly requested config disabled).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Any, Dict, List, Optional, Sequence

from . import __version__, pipeline, report as rpt
from .build import BuildContext, StageResult, default_build_root, repo_info
from .config import list_config_names, load_config, parse_overrides
from .diagnostics import CODES, DiagnosticSink, Severity
from . import toolchain

FORGE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_REPO = os.path.dirname(os.path.dirname(FORGE_DIR))
DEFAULT_CONFIG_DIR = os.path.join(FORGE_DIR, "configs")


# --------------------------------------------------------------------------
def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="albion", description="AlbionForge: RTL build & verification for SilicaFlux",
                                formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    p.add_argument("--version", action="version", version=f"albion_forge {__version__}")
    g = argparse.ArgumentParser(add_help=False)
    g.add_argument("--repo", default=os.environ.get("ALBION_REPO", DEFAULT_REPO), help="SilicaFlux repository root")
    g.add_argument("--build-root", default=os.environ.get("ALBION_BUILD_ROOT"),
                   help="output root (default: <repo>/build/albion)")
    g.add_argument("--config-dir", default=os.environ.get("ALBION_CONFIG_DIR", DEFAULT_CONFIG_DIR))
    g.add_argument("--json", action="store_true", help="machine-readable output")
    g.add_argument("-v", "--verbose", action="store_true", help="show warnings and info diagnostics")
    sel = argparse.ArgumentParser(add_help=False)
    sel.add_argument("-c", "--config", action="append", default=[], metavar="NAME",
                     help="configuration to build (repeatable)")
    sel.add_argument("--all", action="store_true", help="every enabled configuration")
    sel.add_argument("-P", "--param", action="append", default=[], metavar="NAME=VALUE",
                     help="override a declared parameter (validated against the config and the RTL)")
    sel.add_argument("-B", "--block", action="append", default=[], metavar="BLOCK=on|off",
                     help="enable/disable an optional accelerator block")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list", parents=[g], help="list configurations and whether RTL supports them")
    sub.add_parser("doctor", parents=[g], help="detect tools, versions and missing requirements")
    for name, helptext in (("lint", "Verilator -Wall lint with warning policy"),
                           ("elaborate", "elaborate with every available tool"),
                           ("simulate", "run the self-checking testbench"),
                           ("synth", "Yosys synthesis (+ STA when tools and liberty exist)")):
        sub.add_parser(name, parents=[g, sel], help=helptext)
    t = sub.add_parser("test", parents=[g, sel], help="forge self-tests and design regression")
    t.add_argument("--forge-only", action="store_true")
    t.add_argument("--design-only", action="store_true")
    r = sub.add_parser("report", parents=[g, sel], help="render reports from recorded results")
    r.add_argument("--out", default=None, help="report directory (default <build-root>/reports)")
    c = sub.add_parser("ci", parents=[g, sel], help="full pipeline: lint, elaborate, simulate, synth, tests, report")
    c.add_argument("--reproduce", action="store_true", help="rebuild from scratch and compare reproducibility digests")
    c.add_argument("--allow-missing-tools", action="store_true", help="treat blocked-by-missing-tool as non-fatal")
    c.add_argument("--skip-forge-tests", action="store_true")
    c.add_argument("--fail-fast", action="store_true")
    inv = sub.add_parser("inventory", parents=[g], help="forensic inventory of every HDL file in the repository")
    inv.add_argument("--out", default=None)
    inv.add_argument("--no-tool-parse", action="store_true", help="skip the Verilator parse survey of .sf files")
    pn = sub.add_parser("pin", parents=[g], help="print the SHA-256 of archives (for [[source]].archive_sha256)")
    pn.add_argument("paths", nargs="+")
    cd = sub.add_parser("codes", parents=[g], help="list diagnostic codes")
    cd.add_argument("--markdown", action="store_true", help="render docs/DIAGNOSTICS.md")
    return p


# --------------------------------------------------------------------------
def _emit(diags: Sequence[Any], verbose: bool, limit: int = 25, indent: str = "    ") -> None:
    shown = 0
    for d in diags:
        if d.severity >= Severity.ERROR or (verbose and d.severity >= Severity.WARNING):
            if shown < limit or verbose:
                print(indent + d.render().replace("\n", "\n" + indent))
            shown += 1
    hidden = shown - limit
    if hidden > 0 and not verbose:
        print(f"{indent}... {hidden} more (use -v)")


def _tag(status: str) -> str:
    return {"passed": "PASS", "failed": "FAIL", "blocked": "BLOCKED", "skipped": "SKIP"}.get(status, status.upper())


def _print_result(cfgname: str, r: StageResult, verbose: bool) -> None:
    print(f"[{_tag(r.status):7s}] {r.stage:<10s} {cfgname:<14s} {r.summary}  ({r.seconds:.1f}s)")
    _emit(r.diagnostics, verbose)


def _exit_for(results: Sequence[StageResult]) -> int:
    if any(r.status == "failed" for r in results):
        return 1
    if any(r.status == "blocked" for r in results):
        return 3
    return 0


# --------------------------------------------------------------------------
def main(argv: Optional[Sequence[str]] = None) -> int:
    ns = _parser().parse_args(argv)
    repo = os.path.abspath(ns.repo)
    build_root = os.path.abspath(ns.build_root or default_build_root(repo))
    cdir = ns.config_dir
    cmd = ns.cmd

    if cmd == "codes":
        if ns.markdown:
            print("# Diagnostic codes\n\n_Generated by `albion codes --markdown` from the registry in `diagnostics.py`; "
                  "codes are a stable interface (tests and CI match on them)._\n")
            groups = {"CFG": "Configuration", "SRC": "Sources", "DEP": "Dependency analysis", "LNG": "Language constructs",
                      "PAR": "Parameters", "TLS": "Toolchain", "STG": "Stages", "MAN": "Manifest / reproducibility"}
            for pre, title in groups.items():
                print(f"## {title}\n\n| code | meaning |\n|---|---|")
                for k in sorted(c for c in CODES if c.startswith(pre)):
                    print(f"| `{k}` | {CODES[k]} |")
                print()
            return 0
        for k in sorted(CODES):
            print(f"{k}  {CODES[k]}")
        return 0
    if cmd == "pin":
        from .sources import sha256_file
        for pth in ns.paths:
            print(f"{sha256_file(pth)}  {pth}")
        return 0
    if cmd == "doctor":
        return _doctor(ns)
    if cmd == "list":
        return _list(ns, cdir)
    if cmd == "inventory":
        from . import inventory
        return inventory.run(repo, ns.out or os.path.join(build_root, "inventory"), ns.json,
                             tool_parse=not ns.no_tool_parse)

    # ------------- commands that operate on configurations -------------------
    sink = DiagnosticSink()
    pov = parse_overrides(getattr(ns, "param", []), sink)
    bov = parse_overrides(getattr(ns, "block", []), sink, "block")
    if sink.has_errors():
        _emit(sink.items, True)
        return 2
    names = list(getattr(ns, "config", []))
    all_enabled = bool(getattr(ns, "all", False))
    if cmd in ("ci", "report", "test") and not names and not all_enabled:
        all_enabled = True
    if not names and not all_enabled:
        print("error: choose a configuration with --config NAME (see `albion list`) or --all", file=sys.stderr)
        return 2
    if pov or bov:
        if all_enabled:
            print("error: --param/--block overrides apply to one configuration; use --config NAME", file=sys.stderr)
            return 2
    targets = pipeline.load_targets(names, all_enabled, cdir, repo, build_root, pov, bov, sink,
                                    include_disabled=(cmd in ("report", "ci")))
    if sink.has_errors():
        _emit(sink.items, True)
        return 2

    if cmd in ("lint", "elaborate", "simulate", "synth"):
        allr: List[StageResult] = []
        for t in targets:
            r = pipeline.run_stage(t.ctx, cmd)
            if t.ctx.prepared and t.ctx.materialized is not None:
                pipeline.write_manifest(t.ctx)
            allr.append(r)
            if ns.json:
                continue
            _print_result(t.cfg.name, r, ns.verbose)
        if ns.json:
            print(json.dumps([r.to_dict() for r in allr], indent=1))
        return _exit_for(allr)

    if cmd == "test":
        return _test(ns, targets, build_root)
    if cmd == "report":
        return _report(ns, targets, build_root, repo, cdir)
    if cmd == "ci":
        return _ci(ns, targets, build_root, repo, cdir, pov, bov)
    return 2


# --------------------------------------------------------------------------
def _doctor(ns: argparse.Namespace) -> int:
    infos = toolchain.detect_all()
    missing_required: List[str] = []
    print(f"AlbionForge {__version__}  (python {sys.version.split()[0]})")
    print(f"{'tool':<10} {'status':<9} {'version':<10} {'minimum':<8} path / install hint")
    needed = {"verilator", "icarus", "yosys", "pytest"}
    for k, i in sorted(infos.items()):
        spec = toolchain.TOOLS[k]
        mn = ".".join(map(str, spec.min_version))
        if not i.found:
            st = "MISSING"
            if k in needed:
                missing_required.append(k)
            print(f"{k:<10} {st:<9} {'-':<10} {mn:<8} {spec.install_hint}")
        else:
            st = "ok" if i.ok_version else "TOO OLD"
            if not i.ok_version and k in needed:
                missing_required.append(k)
            print(f"{k:<10} {st:<9} {i.version or '?':<10} {mn:<8} {i.path}")
    print()
    print("Roles: verilator = lint + elaborate (+ simulate engine); icarus/vvp = elaborate + simulate engine;")
    print("       yosys = elaborate + synth; opensta/openroad = optional timing (need a liberty);")
    print("       pytest = forge self-tests.  A missing tool blocks or skips its stages; it is never a pass.")
    if ns.json:
        print(json.dumps({k: v.to_dict() for k, v in infos.items()}, indent=1))
    return 3 if missing_required else 0


def _list(ns: argparse.Namespace, cdir: str) -> int:
    sink = DiagnosticSink()
    rows = []
    for n in list_config_names(cdir):
        c = load_config(n, cdir, sink)
        if c is None:
            rows.append((n, "INVALID", "", ""))
        else:
            rows.append((n, "enabled" if c.enabled else "DISABLED", c.category, c.top or "-",
                         c.title if c.enabled else c.blocker.strip().splitlines()[0][:100]))
    if ns.json:
        print(json.dumps([list(r) for r in rows], indent=1))
        return 0
    print(f"{'config':<18} {'state':<9} {'category':<11} {'top':<28} title / blocker")
    for r in rows:
        if r[1] == "INVALID":
            print(f"{r[0]:<18} INVALID")
            continue
        print(f"{r[0]:<18} {r[1]:<9} {r[2]:<11} {r[3]:<28} {r[4]}")
    _emit(sink.items, True, indent="  ")
    return 2 if sink.has_errors() else 0


def _test(ns: argparse.Namespace, targets: List[pipeline.Target], build_root: str) -> int:
    results: List[StageResult] = []
    if not ns.design_only:
        r = pipeline.forge_tests(build_root)
        results.append(r)
        _print_result("albion_forge", r, ns.verbose)
    if not ns.forge_only:
        for t in targets:
            if not t.cfg.enabled:
                print(f"[DISABLED] simulate   {t.cfg.name:<14s} {t.cfg.blocker.strip().splitlines()[0][:100]}")
                continue
            r = pipeline.run_stage(t.ctx, "simulate")
            pipeline.write_manifest(t.ctx)
            results.append(r)
            _print_result(t.cfg.name, r, ns.verbose)
    return _exit_for(results)


def _report(ns: argparse.Namespace, targets: List[pipeline.Target], build_root: str, repo: str, cdir: str) -> int:
    names = [t.cfg.name for t in targets]
    tag = targets[0].ctx.tag if targets else "default"
    data = rpt.collect(build_root, cdir, names, tag)
    out = ns.out or os.path.join(build_root, "reports")
    infos = {k: v.to_dict() for k, v in toolchain.detect_all().items()}
    paths = rpt.write_reports(data, out, repo_info(repo), infos)
    for p in paths:
        print("wrote", os.path.relpath(p))
    return 0


def _ci(ns: argparse.Namespace, targets: List[pipeline.Target], build_root: str, repo: str, cdir: str,
        pov: Dict[str, str], bov: Dict[str, str]) -> int:
    t0 = time.monotonic()
    rc = 0
    summary: List[Dict[str, Any]] = []
    all_results: List[StageResult] = []
    infos = toolchain.detect_all()
    print(f"AlbionForge {__version__} CI: {len(targets)} configuration(s); tools: "
          + ", ".join(f"{k} {v.version}" for k, v in sorted(infos.items()) if v.found))
    for t in targets:
        if not t.cfg.enabled:
            print(f"[DISABLED] {t.cfg.name:<14s} {t.cfg.blocker.strip().splitlines()[0][:110]}")
            summary.append({"config": t.cfg.name, "state": "disabled"})
            continue
        res = pipeline.run_stages(t, pipeline.CI_STAGES, fail_fast=ns.fail_fast)
        for r in res:
            _print_result(t.cfg.name, r, ns.verbose)
        all_results += res
        verdict = pipeline.classify(res, ns.allow_missing_tools)
        entry: Dict[str, Any] = {"config": t.cfg.name, "state": verdict,
                                 "stages": {r.stage: r.status for r in res}}
        if ns.reproduce and verdict != "blocked" and t.ctx.prepared and t.ctx.materialized is not None:
            same, d1, d2 = pipeline.reproducibility_check(t, pipeline.CI_STAGES, repo, cdir, pov, bov)
            entry["reproducible"] = same
            print(f"[{'PASS' if same else 'FAIL':7s}] reproduce  {t.cfg.name:<14s} digest {d1[:12]} vs {d2[:12]}")
            if not same:
                verdict = "fail"
                entry["state"] = "fail"
        summary.append(entry)
        if verdict == "fail":
            rc = max(rc, 1)
        elif verdict == "blocked":
            rc = max(rc, 3)
    if not ns.skip_forge_tests:
        r = pipeline.forge_tests(build_root)
        _print_result("albion_forge", r, ns.verbose)
        all_results.append(r)
        if r.status == "failed":
            rc = max(rc, 1)
        elif r.status == "blocked" and not ns.allow_missing_tools:
            rc = max(rc, 3)
    names = [t.cfg.name for t in targets]
    data = rpt.collect(build_root, cdir, names, targets[0].ctx.tag if targets else "default")
    out = os.path.join(build_root, "reports")
    rpt.write_reports(data, out, repo_info(repo), {k: v.to_dict() for k, v in infos.items()})
    with open(os.path.join(out, "ci_summary.json"), "w") as fh:
        json.dump({"exit_code": rc, "configs": summary, "seconds": round(time.monotonic() - t0, 1)}, fh, indent=1)
    print()
    print(f"{'config':<18}{'verdict':<10}stages")
    for e in summary:
        print(f"{e['config']:<18}{e['state']:<10}" + ", ".join(f"{k}={v}" for k, v in e.get("stages", {}).items()))
    print(f"\nreports: {os.path.relpath(out)}   total {time.monotonic() - t0:.1f}s   exit {rc}")
    return rc


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
