"""Build context: the shared preparation every stage needs.

``BuildContext`` turns (configuration + overrides) into a deterministic build
directory containing the materialised sources, then performs the *pre-tool*
analysis the forge is responsible for:

1. scan every compiled source (stage-specific defines),
2. enforce the language profile (unsupported / simulation-only constructs),
3. resolve the top module's dependency closure into a deterministic order
   (missing modules, duplicates, cycles, missing includes reported with
   file / line / module),
4. validate parameter overrides against what the RTL *actually declares*.

Only then do stages invoke external tools.  Nothing here shells out.
"""
from __future__ import annotations

import dataclasses
import fnmatch
import hashlib
import json
import os
import platform
import subprocess
import sys
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from . import __version__
from .config import Config, apply_overrides, rtl_parameter_map
from .depgraph import Resolution, SourceFile, resolve
from .diagnostics import Diagnostic, DiagnosticSink, Severity
from .sources import MFile, Materialized, materialize
from .sv_scan import Decl, scan_file

__all__ = ["BuildContext", "Analysis", "StageResult", "repo_info", "default_build_root"]

STAGE_ROLES = {
    "lint": ("rtl", "model"),
    "elaborate": ("rtl", "model"),
    "synth": ("rtl",),
    "simulate": ("rtl", "model", "tb"),
}
AUTO_DEFINES = {"synth": {"SYNTHESIS": "1"}}


#: Measured outputs that must be identical between two builds of the same inputs.  Timings, paths and
#: free-text lines are deliberately excluded.
_STABLE_KEYS = ("files", "errors", "warnings_total", "warnings_waived", "warnings_unwaived", "warnings_by_class",
                "tools_run", "cells", "memories", "memory_bits", "modules", "yosys_warnings", "pass_markers",
                "fail_markers", "tb_parameters", "design_parameters")


def _stable_metrics(m: Mapping[str, Any]) -> Dict[str, Any]:
    out = {k: m[k] for k in _STABLE_KEYS if k in m}
    if isinstance(m.get("runs"), dict):
        out["runs"] = {n: (r.get("pass_markers"), r.get("fail_markers"), r.get("rc")) for n, r in sorted(m["runs"].items())}
    return out


def _non_default(cfg: Config, param_ov: Mapping[str, str], block_ov: Mapping[str, str]) -> Dict[str, str]:
    """Overrides that actually differ from the configuration's defaults.  An
    override equal to its default builds into the same directory as no override
    (so `-P LANES=4` and the default share one reproducible output location)."""
    out: Dict[str, str] = {}
    for k, v in param_ov.items():
        spec = cfg.params.get(k)
        try:
            val: Any = (str(v).lower() in ("1", "true", "on", "yes")) if spec and spec.type == "bool" else int(str(v), 0)
        except ValueError:
            out[f"p:{k}"] = str(v)
            continue
        if spec is None or val != spec.default:
            out[f"p:{k}"] = str(val)
    for k, v in block_ov.items():
        b = cfg.blocks.get(k)
        on = str(v).lower() in ("on", "1", "true")
        if b is None or on != b.default:
            out[f"b:{k}"] = "on" if on else "off"
    return out


def default_build_root(repo_root: str) -> str:
    return os.path.join(repo_root, "build", "albion")


# --------------------------------------------------------------------------
# results
# --------------------------------------------------------------------------
@dataclasses.dataclass
class StageResult:
    stage: str
    status: str                       # passed | failed | skipped | blocked
    summary: str = ""
    metrics: Dict[str, Any] = dataclasses.field(default_factory=dict)
    commands: List[Any] = dataclasses.field(default_factory=list)       # CmdRecord
    diagnostics: List[Diagnostic] = dataclasses.field(default_factory=list)
    artifacts: List[str] = dataclasses.field(default_factory=list)
    seconds: float = 0.0

    @property
    def ok(self) -> bool:
        return self.status == "passed"

    def to_dict(self, volatile: bool = True) -> dict:
        d = {"stage": self.stage, "status": self.status, "summary": self.summary,
             "metrics": self.metrics, "commands": [c.to_dict(volatile) for c in self.commands],
             "diagnostics": [x.to_dict() for x in self.diagnostics], "artifacts": sorted(self.artifacts)}
        if volatile:
            d["seconds"] = round(self.seconds, 3)
        return d


@dataclasses.dataclass
class Analysis:
    stage: str
    files: List[SourceFile]                 # every scanned file of the stage's roles
    resolution: Optional[Resolution]
    order: List[SourceFile]                 # dependency-ordered compile list (closure only)
    defines: Dict[str, str]
    incdirs: List[str]
    sink: DiagnosticSink
    unused: List[str]                       # selected-but-not-needed logical files
    top: str
    top_decl: Optional[Decl] = None

    @property
    def ok(self) -> bool:
        return self.resolution is not None and self.resolution.ok and not self.sink.has_errors()


# --------------------------------------------------------------------------
# repo / revision tracking
# --------------------------------------------------------------------------
def _git(repo: str, *args: str) -> Optional[str]:
    try:
        p = subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True, timeout=30,
                           env={**os.environ, "LC_ALL": "C"})
        # rstrip only: `git status --porcelain` lines start with significant spaces (" M path")
        return p.stdout.rstrip("\n") if p.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def repo_info(repo: str, used_paths: Sequence[str] = ()) -> Dict[str, Any]:
    """Source revision tracking.  ``dirty_used`` lists modified/untracked paths
    among the archives/trees the build actually consumed."""
    head = (_git(repo, "rev-parse", "HEAD") or "").strip() or None
    if head is None:
        return {"vcs": "none", "revision": None, "dirty": None, "branch": None, "dirty_used": []}
    status = _git(repo, "status", "--porcelain=v1", "--untracked-files=no") or ""
    changed = [l[3:].strip().strip('"') for l in status.splitlines() if l.strip()]
    dirty_used = sorted(p for p in changed if any(p == u or p.startswith(u.rstrip("/") + "/") for u in used_paths))
    untracked = [l[3:] for l in (_git(repo, "status", "--porcelain=v1", "--untracked-files=normal") or "").splitlines()
                 if l.startswith("??")]
    return {"vcs": "git", "revision": head, "n_untracked": len(untracked), "branch": (_git(repo, "rev-parse", "--abbrev-ref", "HEAD") or "").strip(),
            "describe": (_git(repo, "describe", "--always", "--dirty") or "").strip(),
            "dirty": bool(changed), "n_changed_tracked": len(changed), "dirty_used": dirty_used}


# --------------------------------------------------------------------------
# build context
# --------------------------------------------------------------------------
class BuildContext:
    def __init__(self, cfg: Config, repo_root: str, build_root: str,
                 param_overrides: Optional[Mapping[str, str]] = None,
                 block_overrides: Optional[Mapping[str, str]] = None):
        self.cfg = cfg
        self.repo_root = os.path.abspath(repo_root)
        self.build_root = os.path.abspath(build_root)
        self.param_ov = dict(param_overrides or {})
        self.block_ov = dict(block_overrides or {})
        self.sink = DiagnosticSink()
        self.values: Dict[str, Any] = {}
        self.rtl_params: Dict[str, Dict[str, int]] = {"design": {}, "tb": {}}
        self.materialized: Optional[Materialized] = None
        self._analysis: Dict[str, Analysis] = {}
        self.results: Dict[str, StageResult] = {}
        self.prepared = False
        self.ok = True
        tag = "default"
        ov = _non_default(cfg, self.param_ov, self.block_ov)
        if ov:
            tag = "o-" + hashlib.sha256(json.dumps(ov, sort_keys=True).encode()).hexdigest()[:8]
        self.tag = tag
        self.build_dir = os.path.join(self.build_root, cfg.name, tag)
        self.src_dir = os.path.join(self.build_dir, "src")

    # -- preparation ----------------------------------------------------------
    def prepare(self) -> bool:
        """Validate overrides and materialise sources.  Idempotent."""
        if self.prepared:
            return self.ok
        self.prepared = True
        self.values = apply_overrides(self.cfg, self.param_ov, self.block_ov, self.sink)
        self.rtl_params = rtl_parameter_map(self.cfg, self.values)
        if self.sink.has_errors():
            self.ok = False
            return False
        os.makedirs(self.build_dir, exist_ok=True)
        self.materialized = materialize(self.cfg, self.repo_root, self.src_dir, self.sink)
        self.ok = self.materialized.ok and not self.sink.has_errors()
        return self.ok

    # -- analysis ------------------------------------------------------------------
    def defines_for(self, stage: str) -> Dict[str, str]:
        d = dict(self.cfg.defines)
        d.update(AUTO_DEFINES.get(stage, {}))
        d.update(self.cfg.stage_defines.get(stage, {}))
        return d

    def analysis(self, stage: str, top: Optional[str] = None, extra_roots: Sequence[str] = ()) -> Analysis:
        key = f"{stage}:{top or ''}:{','.join(extra_roots)}"
        if key in self._analysis:
            return self._analysis[key]
        sink = DiagnosticSink()
        assert self.materialized is not None, "prepare() first"
        roles = STAGE_ROLES[stage]
        mfiles = [f for f in self.materialized.files if f.compiled and f.role in roles]
        defines = self.defines_for(stage)
        # include path: configured incdirs + every directory that holds an extracted file
        incdirs = list(self.materialized.incdirs)
        for f in self.materialized.files:
            d = os.path.dirname(f.path)
            if d not in incdirs:
                incdirs.append(d)
        incdirs = sorted(dict.fromkeys(incdirs))
        files: List[SourceFile] = []
        for mf in mfiles:
            try:
                sc = scan_file(mf.path, defines=defines, include_dirs=incdirs)
            except OSError as e:
                sink.error("SRC001", f"cannot read {mf.logical}: {e}", file=mf.logical)
                continue
            files.append(SourceFile(logical=mf.logical, path=mf.path, scan=sc, role=mf.role,
                                    group=mf.source_id,
                                    is_header=mf.path.lower().endswith((".svh", ".vh"))))
        design_top = top or self.cfg.top
        self._language_checks(files, sink, stage)
        res = resolve(files, design_top, sink, blackboxes=self.cfg.blackboxes, include_dirs=incdirs,
                      extra_roots=extra_roots, assertion_idioms=self.cfg.assertion_idioms)
        order = res.order if res.ok or res.order else []
        needed = {f.logical for f in order}
        unused = sorted(f.logical for f in files if f.logical not in needed and not f.is_header)
        top_decl = None
        if res.units.get(design_top):
            top_decl = res.units[design_top][0][0]
        a = Analysis(stage, files, res, order, defines, incdirs, sink, unused, design_top, top_decl)
        self._analysis[key] = a
        return a

    # -- language profile ---------------------------------------------------------------
    def _language_checks(self, files: Sequence[SourceFile], sink: DiagnosticSink, stage: str) -> None:
        lang = self.cfg.language
        forbid = set(lang["forbid"])
        sim_only = set(lang["sim_only"])
        action = lang["sim_only_action"]
        allow_in = lang.get("allow_in", [])
        for f in files:
            if f.role == "tb":
                continue                          # testbenches may use anything
            if any(fnmatch.fnmatchcase(f.logical, pat) for pat in allow_in):
                continue
            agg: Dict[Tuple[str, str, str], List[Any]] = {}
            for fd in f.scan.findings:
                if fd.category in forbid or fd.category in sim_only:
                    file_l = f.logical if fd.file == f.scan.path else fd.file
                    agg.setdefault((fd.category, fd.module, file_l), []).append(fd)
            for (cat, mod, file_l), items in sorted(agg.items()):
                first = min(items, key=lambda x: x.line)
                toks = sorted({i.token for i in items})
                if cat in forbid:
                    if stage in ("synth", "lint", "elaborate", "simulate"):
                        sink.error("LNG001", f"{cat.replace('_', ' ')} construct ({', '.join(toks[:4])}) "
                                             f"x{len(items)} is not supported by language profile '{lang['profile']}'",
                                   file=file_l, line=first.line, module=mod or None,
                                   hint="remove it from the RTL, move it to a testbench, or list the file in [language].allow_in")
                elif action != "ignore" and stage == "synth":
                    # sim-only constructs matter for synthesis; elsewhere they are normal
                    mk = sink.error if action == "error" else sink.warning
                    mk("LNG002", f"simulation-only construct {cat.replace('_', ' ')} ({', '.join(toks[:4])}) "
                                 f"x{len(items)} in synthesizable RTL", file=file_l, line=first.line,
                       module=mod or None)

    # -- parameter validation vs. the RTL --------------------------------------------------
    def validate_rtl_parameters(self, analysis: Analysis, sink: DiagnosticSink,
                                scope: str = "design", top_name: Optional[str] = None) -> bool:
        wanted = self.rtl_params.get(scope, {})
        if not wanted:
            return True
        name = top_name or analysis.top
        res = analysis.resolution
        decl = res.units[name][0][0] if res and name in res.units else None
        if decl is None:
            return True
        ok = True
        declared = {p.name: p for p in decl.params}
        # body-level `parameter` declarations are not parsed; header parameters are authoritative
        for pname in sorted(wanted):
            p = declared.get(pname)
            where = res.units[name][0][1].logical
            if p is None:
                sink.error("PAR001", f"parameter '{pname}' is not declared by module '{name}' "
                                     f"(declared: {', '.join(sorted(declared)) or 'none'})",
                           file=where, line=decl.line, module=name)
                ok = False
            elif p.kind == "localparam":
                sink.error("PAR002", f"'{pname}' in module '{name}' is a localparam and cannot be overridden",
                           file=where, line=decl.line, module=name)
                ok = False
            elif p.kind == "type":
                sink.error("PAR002", f"'{pname}' in module '{name}' is a type parameter; "
                                     "numeric overrides do not apply", file=where, line=decl.line, module=name)
                ok = False
        return ok

    # -- paths ----------------------------------------------------------------------------------
    def stage_dir(self, stage: str) -> str:
        d = os.path.join(self.build_dir, stage)
        os.makedirs(d, exist_ok=True)
        return d

    def logical_for_path(self, path: str) -> str:
        if self.materialized:
            for f in self.materialized.files:
                if f.path == path or os.path.realpath(f.path) == os.path.realpath(path):
                    return f.logical
        return path

    def module_at(self, analysis: Analysis, logical: str, line: int) -> Optional[str]:
        for f in analysis.files:
            for d in f.scan.decls:
                dl = f.logical if d.file == f.scan.path else None
                if dl == logical and d.line <= line <= (d.end_line or d.line):
                    return d.name
        return None

    def write_filelist(self, stage: str, analysis: Analysis, extra_defines: Optional[Mapping[str, str]] = None) -> str:
        path = os.path.join(self.stage_dir(stage), "files.f")
        lines = ["// AlbionForge filelist (dependency-ordered, deterministic).  Paths are relative to the build dir."]
        for d in analysis.incdirs:
            lines.append("+incdir+" + os.path.relpath(d, self.build_dir))
        defs = dict(analysis.defines)
        defs.update(extra_defines or {})
        for k in sorted(defs):
            lines.append(f"+define+{k}" + (f"={defs[k]}" if defs[k] != "" else ""))
        for f in analysis.order:
            lines.append(os.path.relpath(f.path, self.build_dir))
        with open(path, "w") as fh:
            fh.write("\n".join(lines) + "\n")
        return path

    # -- manifest -----------------------------------------------------------------------------------
    def manifest(self, tools: Mapping[str, Any]) -> Dict[str, Any]:
        mat = self.materialized
        used = sorted({a["path"] for a in (mat.archives if mat else []) if a.get("path")})
        stage_files: Dict[str, Any] = {}
        for key, a in sorted(self._analysis.items()):
            stage_files[a.stage] = {
                "top": a.top,
                "compile_order": [{"file": f.logical, "sha256": f.sha256} for f in a.order],
                "unused_sources": a.unused,
                "defines": a.defines,
                "include_dirs": [os.path.relpath(d, self.build_dir) for d in a.incdirs],
            }
        m: Dict[str, Any] = {
            "forge": {"version": __version__, "python": platform.python_version(), "platform": platform.platform()},
            "config": {"name": self.cfg.name, "file": self.cfg.path, "sha256": self.cfg.digest(),
                       "category": self.cfg.category, "enabled": self.cfg.enabled},
            "effective_parameters": {k: v for k, v in sorted(self.values.items())},
            "rtl_parameter_overrides": self.rtl_params,
            "clock": self.cfg.clock,
            "repository": repo_info(self.repo_root, used),
            "archives": mat.archives if mat else [],
            "sources": [{"file": f.logical, "sha256": f.sha256, "size": f.size, "role": f.role,
                         "third_party": f.third_party, "compiled": f.compiled,
                         "translated_from": f.translated_from} for f in (mat.files if mat else [])],
            "stages_analysis": stage_files,
            "tools": {k: v.to_dict() for k, v in sorted(tools.items())},
            "stage_results": {k: r.to_dict(volatile=False) for k, r in sorted(self.results.items())},
        }
        return m

    @staticmethod
    def repro_digest(manifest: Mapping[str, Any]) -> str:
        """Digest of everything that must be identical between two builds of the
        same inputs: configuration, parameters, archive/source hashes, compile
        order, tool versions.  (Timings, paths and platform strings excluded.)"""
        keep = {
            "config": manifest["config"]["sha256"],
            "params": manifest["effective_parameters"],
            "archives": [(a["path"], a["sha256"]) for a in manifest["archives"]],
            "sources": [(s["file"], s["sha256"]) for s in manifest["sources"]],
            "order": {k: [(e["file"], e["sha256"]) for e in v["compile_order"]]
                      for k, v in manifest["stages_analysis"].items()},
            "tools": {k: v["version"] for k, v in manifest["tools"].items() if v["found"]},
            "status": {k: v["status"] for k, v in manifest["stage_results"].items()},
            "measured": {k: _stable_metrics(v.get("metrics", {})) for k, v in sorted(manifest["stage_results"].items())},
        }
        return hashlib.sha256(json.dumps(keep, sort_keys=True).encode()).hexdigest()
