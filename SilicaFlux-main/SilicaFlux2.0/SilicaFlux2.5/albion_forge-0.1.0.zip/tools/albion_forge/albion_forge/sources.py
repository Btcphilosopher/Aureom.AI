"""Source materialisation: turn configuration source specs into files on disk.

The SilicaFlux repository stores its RTL inside (sometimes nested) zip
archives, and several archives contain *different versions of the same
package* -- so the forge never mixes archives.  Each ``[[source]]`` names one
archive (pinned by SHA-256) or one tree directory, and an explicit file
selection.  This module:

* verifies the archive hash and any per-file pins (``SRC002``);
* extracts only the selected members (plus headers under the include dirs and
  declared ``support`` files) into ``<build>/src/<source-id>/`` preserving the
  relative layout, so ``include`` resolution behaves as in the original tree;
* rejects unsafe archive members (absolute paths, ``..``, symlinks);
* maps ``.sf`` -> ``.sv`` (the only translation required: ``.sf`` files are
  SystemVerilog with a different extension, checked by the real tools in the
  lint stage and surveyed by ``albion inventory``);
* records everything (origin, hashes, translation) for the build manifest.

Extraction is deterministic: members are processed in sorted order and file
contents are copied byte-for-byte.
"""
from __future__ import annotations

import dataclasses
import fnmatch
import hashlib
import os
import re
import stat
import zipfile
from typing import Dict, List, Optional, Sequence, Tuple

from .config import Config, SourceSpec
from .diagnostics import DiagnosticSink
from .sv_scan import classify_sf

__all__ = ["MFile", "Materialized", "materialize", "sha256_file", "sha256_bytes", "glob_match"]

HEADER_EXT = (".svh", ".vh", ".h", ".inc")
DATA_EXT = (".mem", ".hex", ".memh", ".memb", ".bin", ".txt", ".csv", ".json")
HDL_EXT = (".sv", ".v", ".sf")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------
# glob with ** support
# --------------------------------------------------------------------------
_glob_cache: Dict[str, "re.Pattern[str]"] = {}


def glob_match(pattern: str, relpath: str) -> bool:
    """fnmatch-style match where ``**`` spans directories and ``*`` does not."""
    rx = _glob_cache.get(pattern)
    if rx is None:
        out = []
        i = 0
        while i < len(pattern):
            c = pattern[i]
            if c == "*":
                if pattern[i:i + 3] == "**/":
                    out.append("(?:.*/)?")
                    i += 3
                    continue
                if pattern[i:i + 2] == "**":
                    out.append(".*")
                    i += 2
                    continue
                out.append("[^/]*")
            elif c == "?":
                out.append("[^/]")
            elif c == "[":
                j = pattern.find("]", i)
                if j == -1:
                    out.append(re.escape(c))
                else:
                    out.append(pattern[i:j + 1])
                    i = j
            else:
                out.append(re.escape(c))
            i += 1
        rx = re.compile("^" + "".join(out) + "$")
        _glob_cache[pattern] = rx
    return bool(rx.match(relpath))


# --------------------------------------------------------------------------
# data model
# --------------------------------------------------------------------------
@dataclasses.dataclass
class MFile:
    logical: str                 # "<source-id>:<relpath>" -- stable identity used in all reports
    path: str                    # absolute path of the on-disk copy (what tools read)
    relpath: str                 # path inside the source (after root strip), original extension
    source_id: str
    role: str
    sha256: str                  # hash of the ORIGINAL bytes (== bytes on disk: translation is rename only)
    size: int
    third_party: bool
    compiled: bool               # True for HDL files that go on a tool command line
    translated_from: Optional[str] = None   # original name if .sf -> .sv mapping applied


@dataclasses.dataclass
class Materialized:
    files: List[MFile]
    incdirs: List[str]                       # absolute, deterministic order
    archives: List[dict]                     # per archive: path, sha256, size, members used
    src_dir: str
    ok: bool = True
    #: archive-level problems are reported once per archive, not once per source group
    reported: set = dataclasses.field(default_factory=set)

    def by_logical(self) -> Dict[str, MFile]:
        return {f.logical: f for f in self.files}


# --------------------------------------------------------------------------
# materialise
# --------------------------------------------------------------------------
def _safe_member(name: str) -> Optional[str]:
    parts = [p for p in name.replace("\\", "/").split("/") if p not in ("", ".")]
    if not parts or ".." in parts or name.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", name):
        return None
    return "/".join(parts)


def materialize(cfg: Config, repo_root: str, src_dir: str, sink: DiagnosticSink) -> Materialized:
    os.makedirs(src_dir, exist_ok=True)
    result = Materialized(files=[], incdirs=[], archives=[], src_dir=src_dir)
    for spec in cfg.sources:
        if spec.archive:
            _from_archive(spec, repo_root, src_dir, sink, result)
        else:
            _from_tree(spec, repo_root, src_dir, sink, result)
    # stable order & unique logical names
    seen: Dict[str, MFile] = {}
    for f in result.files:
        if f.logical in seen:
            sink.error("DEP004", f"source '{f.logical}' selected twice", file=f.logical)
        seen[f.logical] = f
    result.files.sort(key=lambda f: f.logical)
    result.incdirs = sorted(dict.fromkeys(result.incdirs))
    result.ok = not sink.has_errors()
    return result


def _select(spec: SourceSpec, names: Sequence[str], sink: DiagnosticSink, where: str
            ) -> Tuple[List[str], List[str]]:
    """Return (compile members, support members) chosen from ``names`` (relpaths)."""
    nameset = set(names)
    chosen: List[str] = []
    for f in spec.files:
        if f in nameset:
            chosen.append(f)
        elif not spec.optional:
            sink.error("SRC001", f"file '{f}' selected by source '{spec.id}' not found in {where}", file=where)
    for g in spec.glob:
        hits = [n for n in names if glob_match(g, n)]
        if not hits and not spec.optional:
            sink.error("SRC001", f"glob '{g}' of source '{spec.id}' matched nothing in {where}", file=where)
        chosen.extend(hits)
    chosen = sorted(dict.fromkeys(chosen))
    chosen = [c for c in chosen if not any(glob_match(x, c) for x in spec.exclude)]
    support: List[str] = []
    inc_prefixes = [i.rstrip("/").lstrip("./") if i not in (".", "") else "" for i in spec.incdirs]
    for n in names:
        if n in chosen:
            continue
        in_inc = any(p == "" or n == p or n.startswith(p + "/") for p in inc_prefixes)
        if any(glob_match(g, n) for g in spec.support) or (in_inc and n.lower().endswith(HEADER_EXT)):
            support.append(n)
    return chosen, sorted(dict.fromkeys(support))


def _dest_name(rel: str) -> Tuple[str, Optional[str]]:
    if rel.lower().endswith(".sf"):
        return rel[:-3] + ".sv", rel
    return rel, None


def _write(dst: str, data: bytes) -> None:
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isfile(dst):
        with open(dst, "rb") as fh:
            if fh.read() == data:
                return
    with open(dst, "wb") as fh:
        fh.write(data)


def _register(result: Materialized, spec: SourceSpec, rel: str, data: bytes, src_dir: str,
              compiled: bool, sink: DiagnosticSink, origin: str) -> None:
    if rel.lower().endswith(".sf") and compiled:
        if classify_sf(data.decode("utf-8", "replace")) == "dsl":
            sink.error("SRC005", f"'{rel}' is a Silica Flux DSL sketch, not SystemVerilog; no translator exists "
                                 "(its own header says 'documentation only, not compiled')",
                       file=f"{spec.id}:{rel}",
                       hint="use the SystemVerilog implementation the sketch documents instead")
            return
    dest_rel, translated = _dest_name(rel) if compiled else (rel, None)
    dst = os.path.join(src_dir, spec.id, dest_rel)
    if translated and os.path.exists(os.path.join(src_dir, spec.id, rel[:-3] + ".sv")) and any(
            f.logical == f"{spec.id}:{rel[:-3]}.sv" for f in result.files):
        sink.error("SRC004", f".sf -> .sv translation of '{rel}' collides with an existing '{rel[:-3]}.sv'",
                   file=origin)
    _write(dst, data)
    sha = sha256_bytes(data)
    for member, want in spec.pins:
        if member == rel and want != sha:
            sink.error("SRC002", f"'{rel}' has SHA-256 {sha}, pinned {want}", file=f"{spec.id}:{rel}")
    result.files.append(MFile(logical=f"{spec.id}:{rel}", path=dst, relpath=rel, source_id=spec.id,
                              role=spec.role, sha256=sha, size=len(data), third_party=spec.third_party,
                              compiled=compiled, translated_from=translated))


def _incdirs(spec: SourceSpec, src_dir: str, result: Materialized) -> None:
    for d in spec.incdirs:
        result.incdirs.append(os.path.normpath(os.path.join(src_dir, spec.id, d)))
    # the directory of each compiled file is always on the include path too (tools do the same)


def _from_archive(spec: SourceSpec, repo_root: str, src_dir: str, sink: DiagnosticSink,
                  result: Materialized) -> None:
    ap = os.path.join(repo_root, spec.archive or "")
    rel_ap = spec.archive or ""
    first_time = ("archive", rel_ap) not in result.reported
    result.reported.add(("archive", rel_ap))
    if not os.path.isfile(ap):
        if not spec.optional and first_time:
            sink.error("SRC001", f"archive '{rel_ap}' (source '{spec.id}') not found under {repo_root}", file=rel_ap)
        return
    got = sha256_file(ap)
    if spec.archive_sha256 and got != spec.archive_sha256:
        if first_time:
            sink.error("SRC002", f"archive '{rel_ap}' has SHA-256 {got}, configuration pins {spec.archive_sha256}",
                       file=rel_ap, hint="the archive changed; re-verify the configuration and re-pin with `albion pin`")
        return
    try:
        zf = zipfile.ZipFile(ap)
    except (zipfile.BadZipFile, OSError) as e:
        if first_time:
            sink.error("SRC003", f"cannot open archive '{rel_ap}': {e}", file=rel_ap)
        return
    with zf:
        members: Dict[str, zipfile.ZipInfo] = {}
        root = spec.root
        for info in zf.infolist():
            if info.is_dir():
                continue
            mode = (info.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                if first_time:
                    sink.error("SRC003", f"archive member '{info.filename}' is a symlink (refused)", file=rel_ap)
                continue
            safe = _safe_member(info.filename)
            if safe is None:
                if first_time:
                    sink.error("SRC003", f"archive member '{info.filename}' has an unsafe path (refused)", file=rel_ap)
                continue
            if root and not safe.startswith(root):
                continue
            members[safe[len(root):]] = info
        names = sorted(members)
        chosen, support = _select(spec, names, sink, rel_ap)
        used = 0
        for rel in chosen:
            data = zf.read(members[rel])
            _register(result, spec, rel, data, src_dir, rel.lower().endswith(HDL_EXT) and spec.role != "header",
                      sink, rel_ap)
            used += 1
        for rel in support:
            data = zf.read(members[rel])
            _register(result, spec, rel, data, src_dir, False, sink, rel_ap)
        result.archives.append({"source": spec.id, "path": rel_ap, "sha256": got,
                                "size": os.path.getsize(ap), "root": spec.root,
                                "members_compiled": used, "members_support": len(support)})
    _incdirs(spec, src_dir, result)


def _from_tree(spec: SourceSpec, repo_root: str, src_dir: str, sink: DiagnosticSink,
               result: Materialized) -> None:
    base = os.path.join(repo_root, spec.path or "")
    if not os.path.isdir(base):
        if not spec.optional:
            sink.error("SRC001", f"directory '{spec.path}' (source '{spec.id}') not found under {repo_root}",
                       file=spec.path)
        return
    names: List[str] = []
    for dp, dn, fn in os.walk(base):
        dn.sort()
        for f in sorted(fn):
            names.append(os.path.relpath(os.path.join(dp, f), base).replace(os.sep, "/"))
    chosen, support = _select(spec, sorted(names), sink, spec.path or "")
    for rel in chosen:
        with open(os.path.join(base, rel), "rb") as fh:
            data = fh.read()
        _register(result, spec, rel, data, src_dir, rel.lower().endswith(HDL_EXT) and spec.role != "header",
                  sink, spec.path or "")
    for rel in support:
        with open(os.path.join(base, rel), "rb") as fh:
            data = fh.read()
        _register(result, spec, rel, data, src_dir, False, sink, spec.path or "")
    result.archives.append({"source": spec.id, "path": spec.path, "sha256": None, "size": None,
                            "root": "", "members_compiled": len(chosen), "members_support": len(support)})
    _incdirs(spec, src_dir, result)
