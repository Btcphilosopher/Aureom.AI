"""AlbionForge: RTL build, dependency-management and verification infrastructure for SilicaFlux."""
__version__ = "0.1.0"
