"""EDA toolchain detection.

The forge supports Verilator, Icarus Verilog, Yosys, OpenSTA, OpenROAD and
Python/pytest.  Each tool is *detected*, its exact version recorded, and its
role (required / optional per stage) reported.  A missing tool is never an
implicit pass: stages that need it are reported as ``skipped`` (optional tool)
or ``blocked`` (required tool) with an actionable install hint.

Detection can be redirected for tests with ``ALBION_TOOL_<NAME>`` environment
variables (e.g. ``ALBION_TOOL_YOSYS=/path/to/fake-yosys``), which is how the
unit tests exercise the missing-tool and version-comparison paths without
touching the host installation.
"""
from __future__ import annotations

import dataclasses
import os
import re
import shutil
import subprocess
import sys
from typing import Dict, List, Optional, Sequence, Tuple

from .diagnostics import DiagnosticSink

__all__ = ["ToolSpec", "ToolInfo", "TOOLS", "detect", "detect_all", "version_tuple", "STAGE_TOOLS"]


@dataclasses.dataclass(frozen=True)
class ToolSpec:
    key: str
    exe: Tuple[str, ...]                 # candidate executable names, first found wins
    version_args: Tuple[str, ...]
    version_re: str
    min_version: Tuple[int, ...]
    install_hint: str
    description: str


TOOLS: Dict[str, ToolSpec] = {
    "verilator": ToolSpec("verilator", ("verilator",), ("--version",),
                          r"Verilator\s+(\d+(?:\.\d+)*)", (5, 0),
                          "apt-get install verilator  (>= 5.0 needed for --binary/--timing; 5.020 verified)",
                          "lint, elaboration, cycle-accurate simulation"),
    "icarus": ToolSpec("icarus", ("iverilog",), ("-V",),
                       r"Icarus Verilog version\s+(\d+(?:\.\d+)*)", (11, 0),
                       "apt-get install iverilog vvp  (>= 11 needed; 12.0 verified)",
                       "elaboration and event-driven simulation"),
    "vvp": ToolSpec("vvp", ("vvp",), ("-V",),
                    r"Icarus Verilog runtime version\s+(\d+(?:\.\d+)*)", (11, 0),
                    "ships with iverilog", "Icarus simulation runtime"),
    "yosys": ToolSpec("yosys", ("yosys",), ("-V",),
                      r"Yosys\s+(\d+(?:\.\d+)*)", (0, 33),
                      "apt-get install yosys  (0.33 verified)", "elaboration check, generic synthesis"),
    "opensta": ToolSpec("opensta", ("sta", "opensta"), ("-version",),
                        r"(\d+(?:\.\d+)+)", (2, 0),
                        "build OpenSTA from https://github.com/The-OpenROAD-Project/OpenSTA "
                        "(not packaged by Ubuntu 24.04)", "static timing analysis (needs a liberty file)"),
    "openroad": ToolSpec("openroad", ("openroad",), ("-version",),
                         r"(\d+(?:\.\d+)*)", (2, 0),
                         "install OpenROAD (https://github.com/The-OpenROAD-Project/OpenROAD, "
                         "or OpenROAD-flow-scripts); not packaged by Ubuntu 24.04",
                         "physical implementation (needs a PDK/platform)"),
    "pytest": ToolSpec("pytest", (), ("--version",),
                       r"pytest\s+(\d+(?:\.\d+)*)", (7, 0),
                       "pip install pytest", "forge self-tests"),
}

#: which tools each stage needs (required) / can use (optional)
STAGE_TOOLS: Dict[str, Dict[str, Tuple[str, ...]]] = {
    "lint": {"required": ("verilator",), "optional": ()},
    "elaborate": {"required": (), "optional": ("verilator", "icarus", "yosys")},
    "simulate": {"required": (), "optional": ("icarus", "vvp", "verilator")},   # engine decides
    "synth": {"required": ("yosys",), "optional": ("opensta", "openroad")},
    "test": {"required": ("pytest",), "optional": ()},
}


@dataclasses.dataclass
class ToolInfo:
    key: str
    found: bool
    path: Optional[str] = None
    version: Optional[str] = None
    raw_version_line: Optional[str] = None
    ok_version: bool = True
    min_version: Tuple[int, ...] = ()

    def to_dict(self) -> dict:
        return {"key": self.key, "found": self.found, "path": self.path, "version": self.version,
                "version_line": self.raw_version_line, "meets_minimum": self.ok_version,
                "minimum": ".".join(map(str, self.min_version))}


def version_tuple(s: str) -> Tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", s))


_cache: Dict[str, ToolInfo] = {}


def detect(key: str, use_cache: bool = True) -> ToolInfo:
    if use_cache and key in _cache and not os.environ.get(f"ALBION_TOOL_{key.upper()}"):
        return _cache[key]
    spec = TOOLS[key]
    override = os.environ.get(f"ALBION_TOOL_{key.upper()}")
    exe: Optional[str] = None
    if key == "pytest":
        exe = override or sys.executable
    elif override:
        exe = override if os.path.isfile(override) and os.access(override, os.X_OK) else None
    else:
        for cand in spec.exe:
            exe = shutil.which(cand)
            if exe:
                break
    cacheable = not override                  # overrides (tests) must never poison the cache
    if not exe:
        info = ToolInfo(key, False, min_version=spec.min_version)
        if cacheable:
            _cache[key] = info
        return info
    args = [exe] + (["-m", "pytest"] if key == "pytest" and exe == sys.executable else []) + list(spec.version_args)
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=30,
                           env={**os.environ, "LC_ALL": "C"})
        text = (p.stdout + "\n" + p.stderr)
    except (OSError, subprocess.TimeoutExpired):
        text = ""
    m = re.search(spec.version_re, text)
    ver = m.group(1) if m else None
    line = next((l for l in text.splitlines() if l.strip()), "") if text else ""
    ok = True
    if ver and spec.min_version:
        ok = version_tuple(ver) >= spec.min_version
    elif not ver:
        ok = False
    info = ToolInfo(key, True, exe, ver, line.strip(), ok, spec.min_version)
    if cacheable:
        _cache[key] = info
    return info


def detect_all(keys: Optional[Sequence[str]] = None) -> Dict[str, ToolInfo]:
    return {k: detect(k) for k in (keys or sorted(TOOLS))}


def require(keys: Sequence[str], sink: DiagnosticSink, stage: str, *, required: bool = True) -> bool:
    """Check tools; emit TLS001/TLS002 (required) or TLS003 (optional).  Returns
    ``True`` only when every tool is present and recent enough."""
    ok = True
    for k in keys:
        info = detect(k)
        spec = TOOLS[k]
        if not info.found:
            if required:
                sink.error("TLS001", f"{k} is required by '{stage}' but is not installed", hint=spec.install_hint)
            else:
                sink.warning("TLS003", f"{k} not installed: {stage} part skipped", hint=spec.install_hint)
            ok = False
        elif not info.ok_version:
            if required:
                sink.error("TLS002", f"{k} {info.version or '(unknown version)'} is older than the minimum "
                                     f"{'.'.join(map(str, spec.min_version))}", hint=spec.install_hint)
            else:
                sink.warning("TLS002", f"{k} {info.version or '?'} older than minimum "
                                       f"{'.'.join(map(str, spec.min_version))}: {stage} part skipped",
                             hint=spec.install_hint)
            ok = False
    return ok
