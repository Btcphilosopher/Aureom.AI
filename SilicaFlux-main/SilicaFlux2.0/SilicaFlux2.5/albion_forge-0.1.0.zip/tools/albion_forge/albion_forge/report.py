"""Report generation: human Markdown, machine JSON and JUnit XML.

Reports are rendered **only from recorded results** (``results/*.json`` and
``manifest.json`` written by the stages).  The report generator never runs a
tool and never infers a pass: a stage with no recorded result is shown as
``NOT RUN``.
"""
from __future__ import annotations

import json
import os
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional, Sequence

from .config import Config, list_config_names, load_config
from .diagnostics import DiagnosticSink

STAGE_ORDER = ("lint", "elaborate", "simulate", "synth")
BADGE = {"passed": "PASS", "failed": "FAIL", "blocked": "BLOCKED", "skipped": "SKIPPED", "none": "NOT RUN"}


def load_results(build_dir: str) -> Dict[str, dict]:
    out: Dict[str, dict] = {}
    rdir = os.path.join(build_dir, "results")
    if os.path.isdir(rdir):
        for f in sorted(os.listdir(rdir)):
            if f.endswith(".json"):
                with open(os.path.join(rdir, f)) as fh:
                    out[f[:-5]] = json.load(fh)
    return out


def collect(build_root: str, config_dir: str, names: Optional[Sequence[str]] = None,
            tag: str = "default") -> Dict[str, Any]:
    """Gather everything known about each configuration."""
    sink = DiagnosticSink()
    entries: List[Dict[str, Any]] = []
    for n in (names or list_config_names(config_dir)):
        cfg = load_config(n, config_dir, sink)
        if cfg is None:
            entries.append({"name": n, "config_error": [d.render() for d in sink.errors if n in d.render()]})
            continue
        bdir = os.path.join(build_root, n, tag)
        res = load_results(bdir)
        man = None
        mp = os.path.join(bdir, "manifest.json")
        if os.path.isfile(mp):
            with open(mp) as fh:
                man = json.load(fh)
        entries.append({"name": n, "title": cfg.title, "category": cfg.category, "enabled": cfg.enabled,
                        "blocker": cfg.blocker, "results": res, "manifest": man,
                        "top": cfg.top, "build_dir": bdir})
    forge = None
    fp = os.path.join(build_root, "_forge_tests", "junit.xml")
    if os.path.isfile(fp):
        try:
            root = ET.parse(fp).getroot()
            ts = root if root.tag == "testsuite" else root.find("testsuite")
            if ts is not None:
                forge = {k: int(ts.get(k, 0)) for k in ("tests", "failures", "errors", "skipped")}
        except ET.ParseError:
            forge = None
    return {"configs": entries, "forge_tests": forge}


def _status(entry: Dict[str, Any], stage: str) -> str:
    if not entry.get("enabled"):
        return "blocked"
    r = entry.get("results", {}).get(stage)
    return r["status"] if r else "none"


def render_markdown(data: Dict[str, Any], repo_info: Optional[Dict[str, Any]] = None, tools: Optional[dict] = None) -> str:
    L: List[str] = ["# AlbionForge build report", ""]
    L.append("> Generated from recorded stage results only. A cell reads PASS only if a real tool ran and met "
             "the configuration's criteria; `SKIPPED` / `BLOCKED` / `NOT RUN` are never passes.")
    L.append("")
    if repo_info:
        L.append(f"- Repository: `{repo_info.get('revision')}` on `{repo_info.get('branch')}` "
                 f"({'tracked files modified' if repo_info.get('dirty') else 'tracked files clean'}; "
                 f"{repo_info.get('n_untracked', '?')} untracked path(s), consumed archives modified: "
                 f"{', '.join(repo_info.get('dirty_used') or []) or 'none'})")
    if tools:
        L.append("- Tools: " + ", ".join(f"{k} {v['version']}" if v["found"] else f"{k} **MISSING**"
                                          for k, v in sorted(tools.items())))
    ft = data.get("forge_tests")
    if ft:
        L.append(f"- Forge self-tests: {ft['tests']} tests, {ft['failures']} failures, {ft['errors']} errors, "
                 f"{ft['skipped']} skipped")
    L += ["", "## Status matrix", "", "| configuration | category | " + " | ".join(STAGE_ORDER) + " |",
          "|---|---|" + "---|" * len(STAGE_ORDER)]
    for e in data["configs"]:
        if "config_error" in e:
            L.append(f"| {e['name']} | - | " + " | ".join(["CONFIG ERROR"] * len(STAGE_ORDER)) + " |")
            continue
        L.append(f"| `{e['name']}` | {e['category']} | " +
                 " | ".join(BADGE[_status(e, s)] for s in STAGE_ORDER) + " |")
    L += ["", "## Details", ""]
    for e in data["configs"]:
        if "config_error" in e:
            L += [f"### {e['name']}", "", "Configuration could not be loaded:", ""] + [f"- {x}" for x in e["config_error"]] + [""]
            continue
        L.append(f"### `{e['name']}` -- {e['title']}")
        L.append("")
        if not e["enabled"]:
            L += [f"**Disabled** -- no RTL currently supports this configuration.", "", f"> {e['blocker']}", ""]
            continue
        man = e.get("manifest")
        if man:
            L.append(f"- top: `{e['top']}`; params: `{json.dumps(man['effective_parameters'], sort_keys=True)}`")
            seen_arch = []
            for a in man["archives"]:
                if (a["path"], a["sha256"]) not in seen_arch:
                    seen_arch.append((a["path"], a["sha256"]))
            L.append(f"- sources: {len(man['sources'])} files from "
                     + ", ".join(f"`{pth}` (sha256 `{(sh or '')[:12]}`)" for pth, sh in seen_arch))
            L.append(f"- repro digest: `{man.get('repro_digest', '')[:16]}`")
        for s in STAGE_ORDER:
            r = e["results"].get(s)
            if not r:
                L.append(f"- **{s}**: NOT RUN")
                continue
            L.append(f"- **{s}**: {BADGE[r['status']]} -- {r['summary']}")
            errs = [d for d in r["diagnostics"] if d["severity"] == "error"]
            for d in errs[:8]:
                loc = (d["file"] or "") + (f":{d['line']}" if d.get("line") else "")
                L.append(f"    - `{d['code']}` {loc} {('[' + d['module'] + ']') if d.get('module') else ''} {d['message']}")
        L.append("")
    return "\n".join(L) + "\n"


def render_junit(data: Dict[str, Any]) -> str:
    suites = ET.Element("testsuites")
    for e in data["configs"]:
        if "config_error" in e:
            continue
        ts = ET.SubElement(suites, "testsuite", name=e["name"])
        n = fail = skip = 0
        for s in STAGE_ORDER:
            n += 1
            tc = ET.SubElement(ts, "testcase", classname=e["name"], name=s)
            stat = _status(e, s)
            if stat == "passed":
                continue
            if stat == "failed":
                fail += 1
                r = e["results"][s]
                f = ET.SubElement(tc, "failure", message=r["summary"])
                f.text = "\n".join(f"{d['code']} {d.get('file') or ''}:{d.get('line') or ''} {d['message']}"
                                   for d in r["diagnostics"] if d["severity"] == "error")
            else:
                skip += 1
                ET.SubElement(tc, "skipped", message=(e.get("blocker") if not e.get("enabled") else
                                                      (e["results"].get(s, {}).get("summary") or "not run")))
        ts.set("tests", str(n))
        ts.set("failures", str(fail))
        ts.set("skipped", str(skip))
    ET.indent(suites)
    return ET.tostring(suites, encoding="unicode")


def write_reports(data: Dict[str, Any], out_dir: str, repo_info: Optional[dict] = None,
                  tools: Optional[dict] = None) -> List[str]:
    os.makedirs(out_dir, exist_ok=True)
    paths = []
    p = os.path.join(out_dir, "BUILD_REPORT.md")
    with open(p, "w") as fh:
        fh.write(render_markdown(data, repo_info, tools))
    paths.append(p)
    p = os.path.join(out_dir, "build_report.json")
    with open(p, "w") as fh:
        json.dump({"data": data, "repository": repo_info, "tools": tools}, fh, indent=1, sort_keys=True, default=str)
    paths.append(p)
    p = os.path.join(out_dir, "junit.xml")
    with open(p, "w") as fh:
        fh.write(render_junit(data))
    paths.append(p)
    return paths
