"""Stage implementations: lint, elaborate, simulate, synth (+ optional STA).

Principles
----------
* **Positive evidence only.**  A stage is ``passed`` only when a real tool ran
  and its output satisfied explicit criteria.  A missing tool yields ``blocked``
  (required) or ``skipped`` (optional) -- never ``passed``.
* **Attribution.**  Tool messages are parsed and mapped back to *logical* file
  names (``<source-id>:<path>``), line numbers and enclosing modules.
* **Policies are data.**  Warnings-as-errors behaviour (strict / class list /
  baseline ratchet) and waivers (each with a mandatory reason) come from the
  configuration and are applied here, so a legacy RTL snapshot can be built
  with a documented, ratcheted warning budget instead of blanket suppression.
"""
from __future__ import annotations

import collections
import fnmatch
import json
import os
import re
import time
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from .build import Analysis, BuildContext, StageResult
from .diagnostics import Diagnostic, DiagnosticSink, Severity
from .runner import CmdRecord, run_cmd
from . import toolchain
from .toolchain import detect, require

__all__ = ["lint", "elaborate", "simulate", "synth", "STAGES", "parse_verilator", "parse_icarus",
           "parse_yosys", "count_markers"]

JOBS = int(os.environ.get("ALBION_JOBS", "2"))

# --------------------------------------------------------------------------
# output parsers
# --------------------------------------------------------------------------
_VL = re.compile(r"^%(Warning|Error)(?:-([A-Za-z0-9_]+))?:\s+(?:(.+?):(\d+):(?:(\d+):)?\s+)?(.*)$")
_IVL = re.compile(r"^(.+?):(\d+):\s*(error|warning|sorry)?:?\s*(.*)$")
_YS = re.compile(r"^(?:(.+?):(\d+)(?:\.\d+-\d+\.\d+)?:\s+)?(ERROR|Warning|WARNING):\s+(.*)$")


def parse_verilator(text: str) -> List[Dict[str, Any]]:
    out = []
    for line in text.splitlines():
        m = _VL.match(line)
        if not m:
            continue
        kind, cls, file, ln, col, msg = m.groups()
        if kind == "Error" and msg.startswith("Exiting due to"):
            continue
        out.append({"kind": kind.lower(), "class": cls or "", "file": file, "line": int(ln) if ln else None,
                    "col": int(col) if col else None, "message": msg.strip()})
    return out


def parse_icarus(text: str) -> List[Dict[str, Any]]:
    out = []
    for line in text.splitlines():
        m = _IVL.match(line)
        if not m or not m.group(3):
            continue
        out.append({"kind": m.group(3), "file": m.group(1), "line": int(m.group(2)), "message": m.group(4).strip()})
    # un-located errors:  "ERROR: ..." / "error: ..."
    for line in text.splitlines():
        if re.match(r"^\s*(?:ERROR|error):", line) and not _IVL.match(line):
            out.append({"kind": "error", "file": None, "line": None, "message": line.strip()})
    return out


def parse_yosys(text: str) -> List[Dict[str, Any]]:
    out = []
    for line in text.splitlines():
        m = _YS.match(line.strip())
        if not m:
            continue
        file, ln, kind, msg = m.groups()
        out.append({"kind": "error" if kind == "ERROR" else "warning", "file": file,
                    "line": int(ln) if ln else None, "message": msg.strip()})
    return out


def count_markers(text: str, pass_re: str, fail_re: Optional[str]) -> Tuple[int, int, List[str]]:
    pr = re.compile(pass_re)
    fr = re.compile(fail_re) if fail_re else None
    p = f = 0
    fail_lines: List[str] = []
    for line in text.splitlines():
        if pr.search(line):
            p += 1
        if fr and fr.search(line):
            f += 1
            if len(fail_lines) < 5:
                fail_lines.append(line.strip())
    return p, f, fail_lines


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _logical(ctx: BuildContext, path: Optional[str]) -> Optional[str]:
    if not path:
        return None
    ap = os.path.normpath(path if os.path.isabs(path) else os.path.join(ctx.build_dir, path))
    mf = ctx.materialized.by_logical() if ctx.materialized else {}
    for lg, f in mf.items():
        if os.path.normpath(f.path) == ap:
            return lg
    # headers / support files extracted but not "compiled"
    prefix = os.path.normpath(ctx.src_dir) + os.sep
    if ap.startswith(prefix):
        rest = ap[len(prefix):].split(os.sep, 1)
        if len(rest) == 2:
            return f"{rest[0]}:{rest[1]}"
    return path


def _header(ctx: BuildContext, stage: str) -> Tuple[Optional[StageResult], Optional[Analysis]]:
    """Common prologue.  Returns (early failure, analysis)."""
    if not ctx.cfg.enabled:
        return StageResult(stage, "blocked", f"configuration '{ctx.cfg.name}' is disabled: {ctx.cfg.blocker}"), None
    if not ctx.prepare():
        return StageResult(stage, "failed", "configuration / sources could not be prepared",
                           diagnostics=list(ctx.sink.items)), None
    return None, None


def _finish(res: StageResult, ctx: BuildContext) -> StageResult:
    ctx.results[res.stage] = res
    rdir = os.path.join(ctx.build_dir, "results")
    os.makedirs(rdir, exist_ok=True)
    with open(os.path.join(rdir, f"{res.stage}.json"), "w") as fh:
        json.dump(res.to_dict(), fh, indent=1, sort_keys=True)
    return res


def _diag_from(ctx: BuildContext, a: Analysis, sink: DiagnosticSink, items: Sequence[Dict[str, Any]],
               code: str, default_sev: Severity = Severity.ERROR) -> None:
    seen = {(d.code, d.file, d.line, d.message) for d in sink.items}
    for it in items:
        file = _logical(ctx, it.get("file"))
        mod = ctx.module_at(a, file, it["line"]) if file and it.get("line") else None
        sev = default_sev if it["kind"] == "error" else Severity.WARNING
        key = (code, file, it.get("line"), it["message"][:300])
        if key in seen:
            continue
        seen.add(key)
        sink.add(code, sev, it["message"][:300], file=file, line=it.get("line"), module=mod)


def _analysis_failed(ctx: BuildContext, stage: str, a: Analysis, prefix: str = "dependency analysis") -> StageResult:
    items = list(ctx.sink.items) + [d for d in a.sink.items]
    nerr = sum(1 for d in items if d.severity >= Severity.ERROR)
    return StageResult(stage, "failed", f"{prefix} found {nerr} error(s) before any tool ran",
                       metrics={"files_in_closure": len(a.order)}, diagnostics=items)


def _filtered_items(a: Analysis, ctx: BuildContext) -> List[Diagnostic]:
    return list(ctx.sink.items) + list(a.sink.items)


def _param_literal(decl: Optional[Any], name: str, value: int) -> str:
    """Value literal for a command-line parameter override.  A parameter declared 1 bit wide
    (``bit`` / ``logic`` / ``reg`` with no range) gets a sized literal: an unsized ``-GNAME=1``
    is a 32-bit constant and makes Verilator emit a WIDTHTRUNC warning that the RTL did not earn."""
    if decl is not None:
        for p in decl.params:
            if p.name == name and p.kind == "parameter":
                t = p.ptype.split()
                if t and t[-1] in ("bit", "logic", "reg") and "[" not in p.ptype:
                    return f"1'b{1 if value else 0}"
    return str(value)


def _verilator_flags(ctx: BuildContext, a: Analysis, scope_params: Mapping[str, int],
                     decl: Optional[Any] = None) -> List[str]:
    decl = decl if decl is not None else a.top_decl
    fl: List[str] = []
    for d in a.incdirs:
        fl.append("-I" + d)
    for k in sorted(a.defines):
        fl.append(f"+define+{k}" + (f"={a.defines[k]}" if a.defines[k] != "" else ""))
    for k in sorted(scope_params):
        fl.append(f"-G{k}={_param_literal(decl, k, scope_params[k])}")
    return fl


# --------------------------------------------------------------------------
# lint
# --------------------------------------------------------------------------
def lint(ctx: BuildContext) -> StageResult:
    t0 = time.monotonic()
    early, _ = _header(ctx, "lint")
    if early:
        return _finish(early, ctx)
    if ctx.cfg.lint.get("enabled", True) is False:
        return _finish(StageResult("lint", "skipped", "lint disabled in configuration"), ctx)
    a = ctx.analysis("lint")
    diags = _filtered_items(a, ctx)
    ctx.validate_rtl_parameters(a, a.sink, "design")
    diags = _filtered_items(a, ctx)
    if not a.ok:
        r = _analysis_failed(ctx, "lint", a)
        r.diagnostics = diags
        return _finish(r, ctx)
    sink = DiagnosticSink()
    sink.extend(diags)
    if not require(["verilator"], sink, "lint"):
        return _finish(StageResult("lint", "blocked", "verilator is not available", diagnostics=sink.items), ctx)
    vl = detect("verilator")
    sdir = ctx.stage_dir("lint")
    ctx.write_filelist("lint", a)
    argv = [vl.path, "--lint-only", "-Wall", "-Wno-fatal", "--top-module", a.top]
    argv += _verilator_flags(ctx, a, ctx.rtl_params.get("design", {}))
    argv += list(ctx.cfg.lint.get("flags", []))
    argv += [f.path for f in a.order]
    rec, out = run_cmd(argv, sdir, os.path.join(sdir, "verilator.log"), ctx.build_dir, tool="verilator",
                       timeout=float(ctx.cfg.lint.get("timeout_s", 600)))
    items = parse_verilator(out)
    errors = [i for i in items if i["kind"] == "error"]
    warns = [i for i in items if i["kind"] == "warning"]
    # attribute
    for it in items:
        it["logical"] = _logical(ctx, it.get("file"))
        it["module"] = ctx.module_at(a, it["logical"], it["line"]) if it["logical"] and it.get("line") else None
        mf = ctx.materialized.by_logical().get(it["logical"] or "")
        it["third_party"] = bool(mf and mf.third_party)
    for e in errors:
        sink.error("STG001", f"verilator: {e['message'][:240]}", file=e["logical"], line=e["line"], module=e["module"])
    if rec.rc != 0 and not errors:
        sink.error("STG001", f"verilator exited with status {rec.rc}", hint=f"see {rec.log}")
    # --- warning policy -------------------------------------------------------------
    waivers = ctx.cfg.waivers
    waived_counts: Dict[int, int] = collections.Counter()
    unwaived: List[Dict[str, Any]] = []
    waived_total = 0
    for w in warns:
        hit = None
        for wi, wv in enumerate(waivers):
            if wv.id == w["class"] and fnmatch.fnmatchcase(w["logical"] or "", wv.scope):
                hit = wi
                break
        if hit is None:
            unwaived.append(w)
        else:
            waived_counts[hit] += 1
            waived_total += 1
    for wi, wv in enumerate(waivers):
        n = waived_counts.get(wi, 0)
        if n == 0:
            sink.warning("STG006", f"waiver '{wv.id}' (scope {wv.scope}) matched no warning: stale, remove it",
                         file=ctx.cfg.path)
        elif wv.max_count is not None and n > wv.max_count:
            sink.error("STG006", f"waiver '{wv.id}' (scope {wv.scope}) covers {n} warnings, budget is {wv.max_count}",
                       file=ctx.cfg.path)
    by_class = collections.Counter(w["class"] for w in unwaived)
    pol = ctx.cfg.lint
    werror = set(pol.get("werror_classes", []))
    baseline: Dict[str, int] = dict(pol.get("baseline", {}))
    strict = pol.get("strict", not (werror or baseline))
    n_warn_diag = 0
    for w in unwaived:
        cls = w["class"]
        is_err = strict or cls in werror
        if is_err:
            sink.error("STG002", f"[{cls}] {w['message'][:200]}", file=w["logical"], line=w["line"], module=w["module"],
                       hint="fix the RTL or add a justified [[lint.waive]] entry")
        elif n_warn_diag < 40:
            sink.warning("STG005", f"[{cls}] {w['message'][:200]}", file=w["logical"], line=w["line"], module=w["module"])
            n_warn_diag += 1
    if not strict:
        for cls, n in sorted(by_class.items()):
            if cls in werror:
                continue
            allowed = baseline.get(cls)
            if allowed is None:
                sink.warning("STG005", f"warning class {cls}: {n} unwaived (no baseline entry; informational)")
            elif n > allowed:
                sink.error("STG002", f"warning class {cls}: {n} occurrences exceed the baseline of {allowed} "
                                     "(new warnings are not allowed; fix them or consciously raise the baseline)",
                           file=ctx.cfg.path)
    # --- metrics ------------------------------------------------------------------------
    by_group = collections.Counter()
    for w in unwaived:
        mf = (w["logical"] or ":").split(":", 1)[0]
        by_group[mf] += 1
    metrics = {
        "verilator_version": vl.version, "files": len(a.order), "top": a.top,
        "errors": len(errors), "warnings_total": len(warns), "warnings_waived": waived_total,
        "warnings_unwaived": len(unwaived), "warnings_by_class": dict(sorted(by_class.items())),
        "warnings_by_source": dict(sorted(by_group.items())), "policy": "strict" if strict else "ratchet",
        "unused_sources": len(a.unused),
        "design_parameters": ctx.rtl_params.get("design", {}),
    }
    status = "failed" if sink.has_errors() else "passed"
    summary = (f"{len(a.order)} files, {len(errors)} error(s), {len(unwaived)} unwaived / {waived_total} waived "
               f"warning(s) [{metrics['policy']} policy]")
    res = StageResult("lint", status, summary, metrics, [rec], sink.items, [rec.log, "lint/files.f"],
                      time.monotonic() - t0)
    return _finish(res, ctx)


# --------------------------------------------------------------------------
# elaborate
# --------------------------------------------------------------------------
def elaborate(ctx: BuildContext) -> StageResult:
    t0 = time.monotonic()
    early, _ = _header(ctx, "elaborate")
    if early:
        return _finish(early, ctx)
    a = ctx.analysis("elaborate")
    ctx.validate_rtl_parameters(a, a.sink, "design")
    sink = DiagnosticSink()
    sink.extend(_filtered_items(a, ctx))
    if not a.ok:
        r = _analysis_failed(ctx, "elaborate", a)
        r.diagnostics = sink.items
        return _finish(r, ctx)
    sdir = ctx.stage_dir("elaborate")
    ctx.write_filelist("elaborate", a)
    wanted = list(ctx.cfg.elaborate.get("tools", ["verilator", "icarus", "yosys"]))
    cmds: List[CmdRecord] = []
    ran: Dict[str, str] = {}
    skipped: List[str] = []
    params = ctx.rtl_params.get("design", {})
    for tool in wanted:
        if tool not in ("verilator", "icarus", "yosys"):
            sink.error("CFG002", f"[elaborate].tools: unknown tool '{tool}'", file=ctx.cfg.path)
            continue
        probe = DiagnosticSink()
        if not require([tool], probe, "elaborate", required=False):
            skipped.append(tool)
            sink.extend(probe.items)
            continue
        info = detect(tool)
        if tool == "verilator":
            argv = [info.path, "--lint-only", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
                    "--top-module", a.top] + _verilator_flags(ctx, a, params) + [f.path for f in a.order]
            rec, out = run_cmd(argv, sdir, os.path.join(sdir, "verilator.log"), ctx.build_dir, tool=tool,
                               timeout=600)
            items = parse_verilator(out)
            errs = [i for i in items if i["kind"] == "error"]
            _diag_from(ctx, a, sink, errs, "STG001")
            ok = rec.rc == 0 and not errs
        elif tool == "icarus":
            argv = [info.path, "-g2012", "-s", a.top, "-o", os.path.join(sdir, "elab.vvp")]
            for d in a.incdirs:
                argv += ["-I", d]
            for k in sorted(a.defines):
                argv += ["-D", f"{k}={a.defines[k]}" if a.defines[k] != "" else k]
            for k in sorted(params):
                argv += ["-P", f"{a.top}.{k}={params[k]}"]
            argv += [f.path for f in a.order]
            rec, out = run_cmd(argv, sdir, os.path.join(sdir, "icarus.log"), ctx.build_dir, tool=tool, timeout=600)
            allitems = parse_icarus(out)
            items = [i for i in allitems if i["kind"] == "error"]
            _diag_from(ctx, a, sink, items, "STG001")
            _diag_from(ctx, a, sink, [i for i in allitems if i["kind"] != "error"], "STG005")   # `sorry:` notes

            ok = rec.rc == 0 and not items
        else:  # yosys: use the synthesis view of the sources (SYNTHESIS defined)
            sa = ctx.analysis("synth")
            if not sa.ok:
                sink.extend(d for d in sa.sink.items if d.severity >= Severity.ERROR and d not in sink.items)
                ok = False
                rec = CmdRecord(["yosys"], sdir, 1, 0.0, "", tool=tool)
            else:
                script = _yosys_read_script(ctx, sa, params) + ["hierarchy -check -top " + sa.top, "stat"]
                rec, out = _yosys_run(ctx, sdir, script, "elab", 600)
                items = [i for i in parse_yosys(out) if i["kind"] == "error"]
                _diag_from(ctx, sa, sink, items, "STG001")
                if rec.rc != 0 and not items:
                    sink.error("STG001", f"yosys exited with status {rec.rc}", hint=f"see {rec.log}")
                ok = rec.rc == 0 and not items
        cmds.append(rec)
        ran[tool] = "passed" if ok else "failed"
        if not ok and not any(d.severity >= Severity.ERROR and d.code == "STG001" for d in sink.items):
            sink.error("STG001", f"{tool} failed (exit {rec.rc})", hint=f"see {rec.log}")
    for t in skipped:
        pass
    metrics = {"tools_run": ran, "tools_skipped": skipped, "top": a.top, "files": len(a.order),
               "design_parameters": params,
               "tool_versions": {t: detect(t).version for t in ran}}
    if not ran:
        status, summary = "blocked", "no elaboration tool is installed (need verilator, icarus or yosys)"
    elif any(v == "failed" for v in ran.values()):
        status = "failed"
        summary = "elaboration failed in: " + ", ".join(t for t, v in ran.items() if v == "failed")
    else:
        status = "passed"
        summary = "elaborated OK with " + ", ".join(f"{t} {detect(t).version}" for t in ran)
        if skipped:
            summary += f" (skipped, not installed: {', '.join(skipped)})"
    return _finish(StageResult("elaborate", status, summary, metrics, cmds, sink.items,
                               [c.log for c in cmds] + ["elaborate/files.f"], time.monotonic() - t0), ctx)


def _yosys_read_script(ctx: BuildContext, a: Analysis, params: Mapping[str, int]) -> List[str]:
    """Yosys commands that read the dependency-ordered sources.

    Options are stated once with ``verilog_defaults`` (large designs have dozens of include
    directories; repeating them on every ``read_verilog`` overflows argument limits).  ``-defer``
    elaborates only what the top reaches: without it Yosys elaborates EVERY module at read time with
    default parameters, which trips deliberate ``$fatal`` parameter checks in unused modules (e.g.
    technology-macro leaves in the SRAM library)."""
    cmds: List[str] = ["verilog_defaults -clear"]
    opts = ["-sv"] + list(ctx.cfg.synth.get("read_flags", ["-defer"]))
    opts += [f"-D{k}" + (f"={a.defines[k]}" if a.defines[k] != "" else "") for k in sorted(a.defines)]
    opts += [f"-I{d}" for d in a.incdirs]
    cmds.append("verilog_defaults -add " + " ".join(opts))
    for f in a.order:
        cmds.append(f"read_verilog {f.path}")
    cmds.append("verilog_defaults -clear")
    if params:
        # ONE chparam with several -set options: separate commands make Yosys derive a renamed
        # `$paramod...` module on the first, so the second would not find the original top.
        cmds.append("chparam " + " ".join(f"-set {k} {params[k]}" for k in sorted(params)) + f" {a.top}")
    return cmds


def _yosys_run(ctx: BuildContext, sdir: str, script: List[str], name: str, timeout: float):
    path = os.path.join(sdir, f"{name}.ys")
    with open(path, "w") as fh:
        fh.write("\n".join(script) + "\n")
    info = detect("yosys")
    return run_cmd([info.path, "-s", path], sdir, os.path.join(sdir, "yosys.log"), ctx.build_dir, tool="yosys",
                   timeout=timeout)


# --------------------------------------------------------------------------
# simulate
# --------------------------------------------------------------------------
def simulate(ctx: BuildContext) -> StageResult:
    t0 = time.monotonic()
    early, _ = _header(ctx, "simulate")
    if early:
        return _finish(early, ctx)
    sim = ctx.cfg.simulate
    if not sim.get("enabled", False):
        why = sim.get("note", "no self-checking testbench is configured for this target")
        return _finish(StageResult("simulate", "skipped", f"simulation not enabled: {why}"), ctx)
    tb = sim["tb_top"]
    a = ctx.analysis("simulate", top=tb)
    sink = DiagnosticSink()
    sink.extend(_filtered_items(a, ctx))
    if not a.ok:
        r = _analysis_failed(ctx, "simulate", a)
        r.diagnostics = sink.items
        return _finish(r, ctx)
    # parameter routing: a design parameter reaches the DUT only through the testbench top
    tb_decl = a.resolution.units[tb][0][0]
    tb_declared = {p.name for p in tb_decl.params if p.kind != "localparam"}
    design_defaults = ctx.cfg.defaults()
    tb_params: Dict[str, int] = {}
    unreachable: List[str] = []
    for key, spec in sorted(ctx.cfg.params.items()):
        val = ctx.values[key]
        if "tb" in spec.apply_to and spec.tb_name in tb_declared:
            tb_params[spec.tb_name] = int(val)
        elif val != design_defaults[key]:
            # the value would have to reach the DUT through the testbench top, which does not expose it
            unreachable.append(f"{key}={val}")
    for bk, blk in sorted(ctx.cfg.blocks.items()):
        val = bool(ctx.values.get(f"block:{bk}"))
        if blk.param in tb_declared:
            tb_params[blk.param] = int(val)
        elif val != blk.default:
            unreachable.append(f"block {bk}={'on' if val else 'off'}")
    if unreachable:
        sink.warning("STG004", f"testbench '{tb}' does not expose parameter(s) for: {', '.join(unreachable)}; "
                               "simulation not run for this non-default configuration",
                     file=ctx.cfg.path, module=tb)
        return _finish(StageResult("simulate", "skipped",
                                   "non-default parameters cannot be routed through the testbench top",
                                   {"unreachable": unreachable}, [], sink.items), ctx)
    engine = sim.get("engine", "icarus")
    need = ["icarus", "vvp"] if engine == "icarus" else ["verilator"]
    if not require(need, sink, f"simulate ({engine})"):
        return _finish(StageResult("simulate", "blocked", f"{engine} is not available", diagnostics=sink.items), ctx)
    # templated stimulus: {KEY} -> effective parameter value, {src:ID} -> directory of source ID
    def expand(text: str) -> str:
        def sub(m: "re.Match[str]") -> str:
            k = m.group(1)
            if k.startswith("src:"):
                return os.path.join(ctx.src_dir, k[4:])
            if k.startswith("block:"):
                return "1" if ctx.values.get(k) else "0"
            return str(int(ctx.values[k])) if k in ctx.values else m.group(0)
        return re.sub(r"\{([^{}]+)\}", sub, text)

    missing_data = []
    for df in sim.get("data_files", []):
        path = expand(df)
        if not os.path.isfile(path):
            missing_data.append(os.path.relpath(path, ctx.build_dir))
    if missing_data:
        avail = ""
        parent = os.path.dirname(expand(sim["data_files"][0]))
        if os.path.isdir(parent):
            avail = "; available: " + ", ".join(sorted(os.listdir(parent))[:12])
        sink.warning("STG004", f"no stimulus data for this parameter combination: {', '.join(missing_data)}{avail}",
                     file=ctx.cfg.path, module=tb)
        return _finish(StageResult("simulate", "skipped",
                                   "no testbench stimulus exists for this parameter combination",
                                   {"missing_data_files": missing_data}, [], sink.items), ctx)
    sdir = ctx.stage_dir("simulate")
    ctx.write_filelist("simulate", a)
    cmds: List[CmdRecord] = []
    base_plus = [expand(x) for x in list(sim.get("plusargs", [])) + list(sim.get("args", []))]
    runs = list(sim.get("runs") or [{"name": "run", "plusargs": []}])
    timeout = float(sim.get("timeout_s", 300))
    if engine == "icarus":
        ic = detect("icarus")
        vv = detect("vvp")
        exe = os.path.join(sdir, "sim.vvp")
        argv = [ic.path, "-g2012", "-s", tb, "-o", exe]
        for d in a.incdirs:
            argv += ["-I", d]
        for k in sorted(a.defines):
            argv += ["-D", f"{k}={a.defines[k]}" if a.defines[k] != "" else k]
        for k in sorted(tb_params):
            argv += ["-P", f"{tb}.{k}={tb_params[k]}"]
        argv += list(sim.get("flags", [])) + [f.path for f in a.order]
        brec, bout = run_cmd(argv, sdir, os.path.join(sdir, "build.log"), ctx.build_dir, tool="icarus", timeout=600)
        cmds.append(brec)
        if brec.rc != 0:
            _diag_from(ctx, a, sink, [i for i in parse_icarus(bout) if i["kind"] == "error"], "STG001")
            sink.error("STG001", f"icarus failed to build testbench '{tb}' (exit {brec.rc})", hint=f"see {brec.log}")
            return _finish(StageResult("simulate", "failed", "testbench build failed", {}, cmds, sink.items,
                                       [brec.log], time.monotonic() - t0), ctx)
        runner = [vv.path, exe]
        engine_ver = ic.version
    else:
        vl = detect("verilator")
        odir = os.path.join(sdir, "obj")
        argv = [vl.path, "--binary", "--timing", "-j", str(JOBS), "-Wno-fatal", "-Wno-lint", "-Wno-style",
                "-Wno-TIMESCALEMOD", "--top-module", tb, "-Mdir", odir, "-o", "vsim"]
        argv += _verilator_flags(ctx, a, tb_params, tb_decl) + list(sim.get("flags", [])) + [f.path for f in a.order]
        brec, bout = run_cmd(argv, sdir, os.path.join(sdir, "build.log"), ctx.build_dir, tool="verilator",
                             timeout=float(sim.get("build_timeout_s", 1200)))
        cmds.append(brec)
        if brec.rc != 0:
            _diag_from(ctx, a, sink, [i for i in parse_verilator(bout) if i["kind"] == "error"], "STG001")
            sink.error("STG001", f"verilator failed to build testbench '{tb}' (exit {brec.rc})", hint=f"see {brec.log}")
            return _finish(StageResult("simulate", "failed", "testbench build failed", {}, cmds, sink.items,
                                       [brec.log], time.monotonic() - t0), ctx)
        runner = [os.path.join(odir, "vsim")]
        engine_ver = vl.version
    # ---- one compiled simulation, one or more runs; EVERY run needs its own positive evidence ----
    npass = nfail = 0
    reasons: List[str] = []
    fail_lines: List[str] = []
    per_run: Dict[str, Any] = {}
    all_out = ""
    for r in runs:
        rname = r["name"]
        rplus = base_plus + [expand(x) for x in r.get("plusargs", [])]
        rrec, rout = run_cmd(runner + rplus, sdir, os.path.join(sdir, f"{rname}.log" if len(runs) > 1 else "run.log"),
                             ctx.build_dir, tool="sim", timeout=timeout)
        cmds.append(rrec)
        all_out += rout
        rp, rf, rfl = count_markers(rout, sim["pass_regex"], sim.get("fail_regex"))
        npass += rp
        nfail += rf
        fail_lines += rfl
        per_run[rname] = {"pass_markers": rp, "fail_markers": rf, "rc": rrec.rc, "seconds": round(rrec.seconds, 2)}
        why = []
        if rrec.timed_out:
            why.append(f"timed out after {timeout:.0f}s")
        elif rrec.rc != 0:
            why.append(f"exit status {rrec.rc}")
        if rf:
            why.append(f"{rf} failure marker(s)")
        if rp < 1:
            why.append("no PASS marker")
        if why:
            reasons.append((f"run '{rname}': " if len(runs) > 1 else "") + ", ".join(why))
    rout = all_out
    min_pass = int(sim["min_pass"])
    if npass < min_pass:
        reasons.append(f"only {npass} individual PASS marker(s), at least {min_pass} required")
    srx = sim.get("require_summary_regex")
    if srx and len(re.findall(srx, rout, re.M)) < len(runs):
        reasons.append(f"required summary line /{srx}/ not found in every run")
    for fl in fail_lines:
        sink.error("STG003", f"testbench reported: {fl[:200]}", module=tb)
    if reasons:
        sink.error("STG003", f"simulation of '{tb}' did not pass: " + "; ".join(reasons), module=tb,
                   hint="see " + ", ".join(c.log for c in cmds[1:3]))
    rrec = cmds[-1]
    metrics = {"engine": engine, "engine_version": engine_ver, "tb_top": tb, "pass_markers": npass,
               "fail_markers": nfail, "min_pass": min_pass, "files": len(a.order), "runs": per_run,
               "tb_parameters": tb_params, "simulated_time_line": next(
                   (l.strip() for l in rout.splitlines() if "$finish" in l), "")}
    arts = [c.log for c in cmds]
    arts += sorted(os.path.relpath(os.path.join(sdir, f), ctx.build_dir) for f in os.listdir(sdir)
                   if f.endswith((".vcd", ".fst")))
    status = "failed" if reasons else "passed"
    summary = (f"{engine} {engine_ver}: {npass} PASS marker(s), {nfail} failure marker(s)"
               + ("" if not reasons else " -- " + "; ".join(reasons)))
    return _finish(StageResult("simulate", status, summary, metrics, cmds, sink.items, arts,
                               time.monotonic() - t0), ctx)


# --------------------------------------------------------------------------
# synth (+ optional STA)
# --------------------------------------------------------------------------
def synth(ctx: BuildContext) -> StageResult:
    t0 = time.monotonic()
    early, _ = _header(ctx, "synth")
    if early:
        return _finish(early, ctx)
    syn = ctx.cfg.synth
    if syn.get("enabled", True) is False:
        why = syn.get("note", "synthesis is not enabled for this target")
        return _finish(StageResult("synth", "skipped", f"synthesis not enabled: {why}"), ctx)
    top = syn.get("top", ctx.cfg.top)
    a = ctx.analysis("synth", top=top)
    ctx.validate_rtl_parameters(a, a.sink, "design", top_name=top)
    sink = DiagnosticSink()
    sink.extend(_filtered_items(a, ctx))
    if not a.ok:
        r = _analysis_failed(ctx, "synth", a)
        r.diagnostics = sink.items
        return _finish(r, ctx)
    if not require(["yosys"], sink, "synth"):
        return _finish(StageResult("synth", "blocked", "yosys is not available", diagnostics=sink.items), ctx)
    ys = detect("yosys")
    sdir = ctx.stage_dir("synth")
    ctx.write_filelist("synth", a)
    params = ctx.rtl_params.get("design", {})
    stat_json = os.path.join(sdir, "stat.json")
    netlist = os.path.join(sdir, "netlist.v")
    flat = ["-flatten"] if syn.get("flatten", False) else []
    script = _yosys_read_script(ctx, a, params)
    # `hierarchy -top` records the top as a design attribute (and, with parameter overrides, renames the
    # derived module to `$paramod...`), so synth / stat must NOT repeat `-top <name>`.
    # `synth` already ends with Yosys's own `check` pass (slow on large designs): a second, explicit one is only
    # added when the configuration asks for a hard failure (`check_assert = true`).
    script += [f"hierarchy -check -top {top}", "synth " + " ".join(flat + list(syn.get("flags", [])))]
    if syn.get("check_assert", False):
        script.append("check -assert")
    script += [f"tee -o {stat_json} stat -json", f"tee -o {os.path.join(sdir, 'stat.txt')} stat",
               f"write_verilog -noattr {netlist}"]
    # SDC for downstream STA: the clock target is recorded even though generic synthesis ignores it
    period = float(ctx.cfg.clock["period_ns"])
    sdc_path = os.path.join(sdir, "constraints.sdc")
    with open(sdc_path, "w") as fh:
        fh.write(f"# generated by AlbionForge from [clock] of configuration '{ctx.cfg.name}'\n")
        fh.write(f"create_clock -name {ctx.cfg.clock['name']} -period {period:g} [get_ports {ctx.cfg.clock['name']}]\n")
    rec, out = _yosys_run(ctx, sdir, script, "synth", float(syn.get("max_seconds", 900)))
    items = parse_yosys(out)
    errs = [i for i in items if i["kind"] == "error"]
    _diag_from(ctx, a, sink, errs, "STG001")
    if rec.timed_out:
        sink.error("STG001", f"yosys exceeded the {syn.get('max_seconds', 900)}s budget", hint=f"see {rec.log}")
    elif rec.rc != 0 and not errs:
        sink.error("STG001", f"yosys exited with status {rec.rc}", hint=f"see {rec.log}")
    warn_n = sum(1 for i in items if i["kind"] == "warning")
    metrics: Dict[str, Any] = {"yosys_version": ys.version, "top": top, "files": len(a.order),
                               "yosys_warnings": warn_n, "design_parameters": params,
                               "clock_period_ns": period,
                               "clock_target_applied": False,
                               "clock_note": "generic Yosys synthesis has no liberty: the clock target is written "
                                             "to constraints.sdc for STA/OpenROAD but not used for mapping"}
    if rec.rc == 0 and os.path.isfile(stat_json):
        try:
            metrics.update(_parse_stat(stat_json, top))
        except (OSError, ValueError, KeyError) as e:
            sink.warning("STG007", f"could not parse Yosys stat output: {e}")
    elif rec.rc == 0:
        sink.error("STG007", "yosys reported success but produced no stat.json", hint=f"see {rec.log}")
    cap = syn.get("expect_max_cells")
    if cap is not None and metrics.get("cells") is not None and metrics["cells"] > cap:
        sink.error("STG002", f"synthesised cell count {metrics['cells']} exceeds the configured ceiling {cap}")
    cmds = [rec]
    arts = [rec.log, "synth/synth.ys", "synth/stat.json", "synth/stat.txt", "synth/netlist.v", "synth/constraints.sdc", "synth/files.f"]
    # ---- timing (optional tools) -------------------------------------------------------
    sta = _sta(ctx, sink, sdir, top, netlist, sdc_path, rec.rc == 0)
    metrics["sta"] = sta["status"]
    if sta.get("rec"):
        cmds.append(sta["rec"])
        arts.append(sta["rec"].log)
    metrics.update({k: v for k, v in sta.items() if k in ("wns", "tns", "sta_tool", "sta_version")})
    status = "failed" if sink.has_errors() else "passed"
    summary = (f"yosys {ys.version}: " + (f"{metrics.get('cells', '?')} cells" if status == "passed"
               else "synthesis failed") + f"; STA: {sta['status']}")
    return _finish(StageResult("synth", status, summary, metrics, cmds, sink.items, arts, time.monotonic() - t0), ctx)


def _parse_stat(path: str, top: str) -> Dict[str, Any]:
    with open(path) as fh:
        text = fh.read()
    start = text.index("{")
    data = json.loads(text[start:])
    out: Dict[str, Any] = {}
    design = data.get("design") or {}
    mods = data.get("modules") or {}
    src = design if design.get("num_cells") is not None else mods.get(top) or mods.get("\\" + top) or {}
    if "num_cells" in src:
        out["cells"] = int(src["num_cells"])
    if "num_wire_bits" in src:
        out["wire_bits"] = int(src["num_wire_bits"])
    if "num_memories" in src:
        out["memories"] = int(src.get("num_memories") or 0)
        out["memory_bits"] = int(src.get("num_memory_bits") or 0)
    ctype = src.get("num_cells_by_type") or {}
    out["cell_types"] = {k: int(v) for k, v in sorted(ctype.items())}
    out["modules"] = len(mods)
    return out


def _sta(ctx: BuildContext, sink: DiagnosticSink, sdir: str, top: str, netlist: str, sdc: str,
         synth_ok: bool) -> Dict[str, Any]:
    cfg = ctx.cfg.sta
    if not cfg.get("enabled", True):
        return {"status": "disabled"}
    if not synth_ok:
        return {"status": "skipped: synthesis did not succeed"}
    probe = DiagnosticSink()
    chosen = None
    for k in ("opensta", "openroad"):
        if require([k], probe, "sta", required=False):
            chosen = k
            break
    if chosen is None:
        sink.warning("TLS003", "neither OpenSTA ('sta') nor OpenROAD is installed: timing analysis skipped "
                               "(NOT passed)", hint=toolchain.TOOLS["opensta"].install_hint)
        return {"status": "skipped: OpenSTA/OpenROAD not installed"}
    lib = cfg.get("liberty")
    if not lib:
        sink.warning("STG004", f"{chosen} is installed but no [sta].liberty is configured: timing analysis skipped "
                               "(a liberty/PDK is required; the forge does not invent timing data)")
        return {"status": "skipped: no liberty configured"}
    lib_abs = lib if os.path.isabs(lib) else os.path.join(ctx.repo_root, lib)
    if not os.path.isfile(lib_abs):
        sink.error("SRC001", f"[sta].liberty '{lib}' not found", file=ctx.cfg.path)
        return {"status": "failed: liberty missing"}
    tcl = os.path.join(sdir, "sta.tcl")
    with open(tcl, "w") as fh:
        fh.write(f"read_liberty {lib_abs}\nread_verilog {netlist}\nlink_design {top}\nread_sdc {sdc}\n"
                 "report_checks -path_delay max -format full\nreport_wns\nreport_tns\nexit\n")
    info = detect(chosen)
    argv = [info.path, "-no_init", "-exit", tcl] if chosen == "opensta" else [info.path, "-no_init", "-exit", tcl]
    rec, out = run_cmd(argv, sdir, os.path.join(sdir, "sta.log"), ctx.build_dir, tool=chosen, timeout=900)
    res: Dict[str, Any] = {"status": "passed" if rec.rc == 0 else "failed", "rec": rec,
                           "sta_tool": chosen, "sta_version": info.version}
    m = re.search(r"wns\s+(-?\d+(?:\.\d+)?)", out, re.I)
    if m:
        res["wns"] = float(m.group(1))
    m = re.search(r"tns\s+(-?\d+(?:\.\d+)?)", out, re.I)
    if m:
        res["tns"] = float(m.group(1))
    if rec.rc != 0:
        sink.error("STG001", f"{chosen} failed (exit {rec.rc})", hint=f"see {rec.log}")
    elif res.get("wns") is not None and res["wns"] < 0:
        sink.error("STG002", f"timing not met: WNS {res['wns']} ns at {ctx.cfg.clock['period_ns']} ns target")
        res["status"] = "failed"
    return res


STAGES = {"lint": lint, "elaborate": elaborate, "simulate": simulate, "synth": synth}
