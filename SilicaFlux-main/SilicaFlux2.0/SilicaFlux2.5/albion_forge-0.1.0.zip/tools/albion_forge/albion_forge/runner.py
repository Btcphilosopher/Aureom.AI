"""Subprocess execution with full logging and a deterministic environment."""
from __future__ import annotations

import dataclasses
import os
import subprocess
import time
from typing import Dict, List, Optional, Sequence

__all__ = ["CmdRecord", "run_cmd"]

#: Environment passed to every tool.  Deliberately small: locale-independent
#: output, no inherited tool-configuration variables that could change results.
_KEEP = ("PATH", "HOME", "TMPDIR", "USER", "VERILATOR_ROOT", "YOSYS_DATDIR", "LD_LIBRARY_PATH",
         "SSL_CERT_FILE", "ALBION_TOOL_VERILATOR", "ALBION_TOOL_YOSYS", "ALBION_TOOL_ICARUS")


@dataclasses.dataclass
class CmdRecord:
    argv: List[str]
    cwd: str
    rc: int
    seconds: float
    log: str                     # path (relative to the build dir) of the combined stdout+stderr log
    timed_out: bool = False
    tool: str = ""
    stdout_tail: str = ""

    def to_dict(self, volatile: bool = True) -> dict:
        d = {"argv": self.argv, "cwd": self.cwd, "rc": self.rc, "log": self.log, "tool": self.tool,
             "timed_out": self.timed_out}
        if volatile:
            d["seconds"] = round(self.seconds, 3)
        return d


def run_cmd(argv: Sequence[str], cwd: str, log_path: str, build_dir: str, *, timeout: Optional[float] = None,
            tool: str = "", extra_env: Optional[Dict[str, str]] = None) -> tuple["CmdRecord", str]:
    """Run ``argv`` in ``cwd``; write combined output to ``log_path``; return
    the record and the full output text."""
    env = {k: os.environ[k] for k in _KEEP if k in os.environ}
    env.update({"LC_ALL": "C", "LANG": "C"})
    if extra_env:
        env.update(extra_env)
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    os.makedirs(cwd, exist_ok=True)
    t0 = time.monotonic()
    timed_out = False
    try:
        p = subprocess.run(list(argv), cwd=cwd, env=env, capture_output=True, text=True,
                           errors="replace", timeout=timeout)
        out = (p.stdout or "") + (p.stderr or "")
        rc = p.returncode
    except subprocess.TimeoutExpired as e:
        timed_out = True
        out = ((e.stdout.decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")) +
               (e.stderr.decode(errors="replace") if isinstance(e.stderr, bytes) else (e.stderr or "")))
        out += f"\n[albion] TIMEOUT after {timeout}s\n"
        rc = 124
    except OSError as e:
        out = f"[albion] cannot execute {argv[0]}: {e}\n"
        rc = 127
    dt = time.monotonic() - t0
    with open(log_path, "w", encoding="utf-8", errors="replace") as fh:
        fh.write("$ " + " ".join(argv) + "\n")
        fh.write(out)
    rel_log = os.path.relpath(log_path, build_dir)
    rec = CmdRecord(list(argv), cwd, rc, dt, rel_log, timed_out, tool, out[-2000:])
    return rec, out
