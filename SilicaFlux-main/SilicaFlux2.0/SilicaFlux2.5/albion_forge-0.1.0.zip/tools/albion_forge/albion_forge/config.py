"""Machine-readable configuration (TOML) for AlbionForge.

A *configuration* names one buildable hardware target (smoke test, RISC-V
control core, SRAM subsystem, ...).  Configuration files are validated against
a strict schema: unknown keys are errors (typos must not silently disable a
check), every parameter is typed and range-checked, and a configuration that
is not backed by working RTL must say so (``enabled = false`` plus a
``blocker`` explanation) instead of pretending.

Schema summary (see ``docs/CONFIGURATION.md`` for the annotated version)::

    schema_version = 1
    [config]     name, title, description, category, enabled, blocker
    [[source]]   id, role, archive|path, archive_sha256, root, files|glob,
                 exclude, incdirs, third_party, optional
    [design]     top, defines, blackboxes, assertion_idioms
    [language]   profile, forbid, sim_only, sim_only_action
    [clock]      name, period_ns, sim_param
    [parameters.NAME]  rtl_name, type, default, choices|min/max/pow2/multiple_of
    [[constraints]]    expr, message
    [blocks.NAME]      param, default, requires, conflicts
    [lint]       werror_classes, baseline, waive[], flags
    [elaborate]  tools
    [simulate]   engine, tb_top, dut, pass_regex, fail_regex, min_pass, ...
    [synth]      tool, top, flags, blackbox_ok, max_seconds, ...
    [sta]        liberty, sdc, ...
"""
from __future__ import annotations

import ast
import dataclasses
import hashlib
import json
import os
import re
import tomllib
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from .diagnostics import DiagnosticSink, ForgeError, Diagnostic, Severity

__all__ = [
    "Config",
    "SourceSpec",
    "ParamSpec",
    "BlockSpec",
    "load_config",
    "list_config_names",
    "safe_eval",
    "parse_overrides",
    "SCHEMA_VERSION",
]

SCHEMA_VERSION = 1

CATEGORIES = ("smoke", "riscv_core", "sram", "datafabric", "dma", "vector", "tensor", "soc", "other")
ROLES = ("rtl", "tb", "model", "header")
STAGES_WITH_DEFINES = ("lint", "elaborate", "simulate", "synth")

# default forbidden / sim-only construct categories (match sv_scan finding categories)
DEFAULT_FORBID = ["class", "program", "fork_join", "covergroup", "constraint_random",
                  "dpi", "uvm", "force_release", "ipc", "virtual_interface"]
DEFAULT_SIM_ONLY = ["initial_block", "final_block", "delay", "system_task",
                    "wait_stmt", "event_type", "immediate_assertion", "concurrent_assertion"]


# --------------------------------------------------------------------------
# dataclasses
# --------------------------------------------------------------------------
@dataclasses.dataclass(frozen=True)
class SourceSpec:
    id: str
    role: str = "rtl"
    archive: Optional[str] = None            # path relative to repo root
    archive_sha256: Optional[str] = None
    path: Optional[str] = None               # tree source: directory relative to repo root
    root: str = ""                           # prefix stripped from archive members
    files: Tuple[str, ...] = ()              # explicit member list (relative to root)
    glob: Tuple[str, ...] = ()
    exclude: Tuple[str, ...] = ()
    incdirs: Tuple[str, ...] = ()
    support: Tuple[str, ...] = ()            # extra non-compiled files to extract (globs): headers, mem images
    third_party: bool = False
    optional: bool = False                   # source may be absent (reported, not fatal)
    pins: Tuple[Tuple[str, str], ...] = ()   # (member, sha256) per-file pins


@dataclasses.dataclass(frozen=True)
class ParamSpec:
    key: str                                  # configuration-level name (CLI --param KEY=V)
    rtl_name: str                             # parameter name on the design top
    tb_name: str = ""                         # parameter name on the testbench top (default: rtl_name)
    type: str = "int"                         # int | bool
    default: Any = 0
    choices: Tuple[Any, ...] = ()
    min: Optional[int] = None
    max: Optional[int] = None
    pow2: bool = False
    multiple_of: Optional[int] = None
    doc: str = ""
    tags: Tuple[str, ...] = ()
    apply_to: Tuple[str, ...] = ("design",)    # design | tb : where the RTL parameter lives


@dataclasses.dataclass(frozen=True)
class BlockSpec:
    key: str
    param: str                                # RTL parameter on the top that enables the block
    default: bool = True
    requires: Tuple[str, ...] = ()
    conflicts: Tuple[str, ...] = ()
    doc: str = ""


@dataclasses.dataclass(frozen=True)
class WaiverSpec:
    id: str                                   # tool warning class, e.g. DECLFILENAME
    reason: str
    scope: str = "*"                          # fnmatch against logical file path
    max_count: Optional[int] = None


@dataclasses.dataclass
class Config:
    name: str
    title: str
    description: str
    category: str
    enabled: bool
    blocker: str
    sources: List[SourceSpec]
    top: str
    defines: Dict[str, str]
    stage_defines: Dict[str, Dict[str, str]]
    blackboxes: List[str]
    assertion_idioms: List[str]
    language: Dict[str, Any]
    clock: Dict[str, Any]
    params: Dict[str, ParamSpec]
    constraints: List[Tuple[str, str]]
    blocks: Dict[str, BlockSpec]
    lint: Dict[str, Any]
    elaborate: Dict[str, Any]
    simulate: Dict[str, Any]
    synth: Dict[str, Any]
    sta: Dict[str, Any]
    waivers: List[WaiverSpec]
    path: str = ""
    raw: Dict[str, Any] = dataclasses.field(default_factory=dict)

    # -- helpers --------------------------------------------------------------
    def canonical(self) -> str:
        return json.dumps(self.raw, sort_keys=True, separators=(",", ":"), default=str)

    def digest(self) -> str:
        return hashlib.sha256(self.canonical().encode()).hexdigest()

    def sources_by_role(self, *roles: str) -> List[SourceSpec]:
        return [s for s in self.sources if s.role in roles]

    def defaults(self) -> Dict[str, Any]:
        return {k: p.default for k, p in self.params.items()}


# --------------------------------------------------------------------------
# strict schema checking helpers
# --------------------------------------------------------------------------
_ALLOWED = {
    "": {"schema_version", "config", "source", "design", "language", "clock", "parameters",
         "constraints", "blocks", "lint", "elaborate", "simulate", "synth", "sta"},
    "config": {"name", "title", "description", "category", "enabled", "blocker", "tags", "status_note"},
    "source": {"id", "role", "archive", "archive_sha256", "path", "root", "files", "glob", "exclude",
               "incdirs", "support", "third_party", "optional", "pins", "note"},
    "design": {"top", "defines", "defines_lint", "defines_elaborate", "defines_simulate",
               "defines_synth", "blackboxes", "assertion_idioms"},
    "language": {"profile", "forbid", "sim_only", "sim_only_action", "allow_in"},
    "clock": {"name", "period_ns", "sim_param"},
    "parameters": None,   # free-form names; entries checked separately
    "param": {"rtl_name", "tb_name", "type", "default", "choices", "min", "max", "pow2", "multiple_of", "doc",
              "tags", "apply_to"},
    "constraints": {"expr", "message"},
    "blocks": None,
    "block": {"param", "default", "requires", "conflicts", "doc"},
    "lint": {"werror_classes", "baseline", "waive", "flags", "enabled", "tool", "strict"},
    "waive": {"id", "reason", "scope", "max_count"},
    "elaborate": {"tools", "flags"},
    "simulate": {"enabled", "engine", "tb_top", "dut", "pass_regex", "fail_regex", "min_pass",
                 "timeout_s", "build_timeout_s", "args", "flags", "plusargs", "data_files", "runs", "note",
                 "require_summary_regex"},
    "synth": {"enabled", "tool", "top", "flags", "blackbox_ok", "max_seconds", "flatten", "mode",
              "expect_max_cells", "check_assert", "note", "read_flags"},
    "sta": {"enabled", "liberty", "sdc", "tool", "note"},
}


def _check_keys(tbl: Mapping[str, Any], allowed: Optional[set], where: str, sink: DiagnosticSink,
                file: str) -> None:
    if allowed is None:
        return
    for k in sorted(tbl):
        if k not in allowed:
            sink.error("CFG002", f"unknown key '{k}' in [{where}] (allowed: {', '.join(sorted(allowed))})",
                       file=file)


def _need(cond: bool, sink: DiagnosticSink, file: str, msg: str) -> bool:
    if not cond:
        sink.error("CFG002", msg, file=file)
    return cond


def _tup(v: Any) -> Tuple[Any, ...]:
    if v is None:
        return ()
    if isinstance(v, (list, tuple)):
        return tuple(v)
    return (v,)


# --------------------------------------------------------------------------
# loading
# --------------------------------------------------------------------------
def list_config_names(config_dir: str) -> List[str]:
    if not os.path.isdir(config_dir):
        return []
    return sorted(f[:-5] for f in os.listdir(config_dir) if f.endswith(".toml"))


def load_config(name_or_path: str, config_dir: str, sink: DiagnosticSink) -> Optional[Config]:
    """Load and strictly validate a configuration.  Returns ``None`` (with
    diagnostics in ``sink``) if it cannot be used."""
    path = name_or_path
    if not (name_or_path.endswith(".toml") and os.path.isfile(name_or_path)):
        path = os.path.join(config_dir, name_or_path + ".toml")
    if not os.path.isfile(path):
        sink.error("CFG003", f"configuration '{name_or_path}' not found "
                             f"(looked in {config_dir}; available: {', '.join(list_config_names(config_dir)) or 'none'})")
        return None
    rel = os.path.relpath(path)
    try:
        with open(path, "rb") as fh:
            raw = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError) as e:
        sink.error("CFG001", f"cannot parse configuration: {e}", file=rel)
        return None

    n0 = len(sink.errors)
    _check_keys(raw, _ALLOWED[""], "", sink, rel)
    if raw.get("schema_version") != SCHEMA_VERSION:
        sink.error("CFG002", f"schema_version must be {SCHEMA_VERSION} (found {raw.get('schema_version')!r})", file=rel)

    c = raw.get("config", {})
    _check_keys(c, _ALLOWED["config"], "config", sink, rel)
    name = c.get("name")
    if not _need(isinstance(name, str) and re.fullmatch(r"[a-z][a-z0-9_]*", name or ""), sink, rel,
                 "[config].name must match [a-z][a-z0-9_]*"):
        name = os.path.basename(path)[:-5]
    elif name != os.path.basename(path)[:-5] and os.path.dirname(os.path.abspath(path)) == os.path.abspath(config_dir):
        sink.error("CFG002", f"[config].name '{name}' must equal the file name '{os.path.basename(path)[:-5]}'", file=rel)
    category = c.get("category", "other")
    if category not in CATEGORIES:
        sink.error("CFG002", f"[config].category '{category}' not one of {CATEGORIES}", file=rel)
    enabled = c.get("enabled", True)
    blocker = c.get("blocker", "")
    if not isinstance(enabled, bool):
        sink.error("CFG002", "[config].enabled must be a boolean", file=rel)
        enabled = False
    if not enabled and not blocker.strip():
        sink.error("CFG004", "a disabled configuration must explain why in [config].blocker "
                             "(a configuration is only enabled when actual RTL supports it)", file=rel)
    if enabled and blocker.strip():
        sink.error("CFG004", "[config].blocker is set but the configuration is enabled; "
                             "either remove the blocker or set enabled = false", file=rel)

    # sources -------------------------------------------------------------
    sources: List[SourceSpec] = []
    ids = set()
    for i, s in enumerate(raw.get("source", [])):
        where = f"source[{i}]"
        _check_keys(s, _ALLOWED["source"], where, sink, rel)
        sid = s.get("id", "")
        if not re.fullmatch(r"[a-z][a-z0-9_]*", sid or ""):
            sink.error("CFG002", f"[{where}].id must match [a-z][a-z0-9_]*", file=rel)
            continue
        if sid in ids:
            sink.error("CFG002", f"duplicate source id '{sid}'", file=rel)
        ids.add(sid)
        role = s.get("role", "rtl")
        if role not in ROLES:
            sink.error("CFG002", f"[{where}].role '{role}' not in {ROLES}", file=rel)
        if bool(s.get("archive")) == bool(s.get("path")):
            sink.error("CFG002", f"[{where}] needs exactly one of `archive` or `path`", file=rel)
        if s.get("archive") and not (s.get("archive_sha256") or "").strip():
            sink.error("CFG002", f"[{where}] archive sources must pin `archive_sha256` "
                                 "(use `albion pin` to compute it)", file=rel)
        if s.get("archive_sha256") and not re.fullmatch(r"[0-9a-f]{64}", s["archive_sha256"]):
            sink.error("CFG002", f"[{where}].archive_sha256 is not a 64-hex SHA-256", file=rel)
        if not (s.get("files") or s.get("glob")):
            sink.error("CFG002", f"[{where}] needs `files` and/or `glob`", file=rel)
        pins = tuple(sorted((k, v) for k, v in (s.get("pins") or {}).items()))
        sources.append(SourceSpec(
            id=sid, role=role, archive=s.get("archive"), archive_sha256=s.get("archive_sha256"),
            path=s.get("path"), root=s.get("root", ""), files=_tup(s.get("files")),
            glob=_tup(s.get("glob")), exclude=_tup(s.get("exclude")), incdirs=_tup(s.get("incdirs")),
            support=_tup(s.get("support")), third_party=bool(s.get("third_party", False)), optional=bool(s.get("optional", False)),
            pins=pins))
    if enabled and not sources:
        sink.error("CFG002", "an enabled configuration needs at least one [[source]]", file=rel)

    d = raw.get("design", {})
    _check_keys(d, _ALLOWED["design"], "design", sink, rel)
    top = d.get("top", "")
    if enabled and not re.fullmatch(r"[A-Za-z_]\w*", top or ""):
        sink.error("CFG002", "[design].top must be a module name", file=rel)
    defines = {str(k): str(v) for k, v in (d.get("defines") or {}).items()}
    stage_defines = {st: {str(k): str(v) for k, v in (d.get(f"defines_{st}") or {}).items()}
                     for st in STAGES_WITH_DEFINES}

    lang = dict(raw.get("language", {}))
    _check_keys(lang, _ALLOWED["language"], "language", sink, rel)
    lang.setdefault("profile", "synthesizable")
    lang.setdefault("forbid", list(DEFAULT_FORBID))
    lang.setdefault("sim_only", list(DEFAULT_SIM_ONLY))
    lang.setdefault("sim_only_action", "warn")
    if lang["sim_only_action"] not in ("error", "warn", "ignore"):
        sink.error("CFG002", "[language].sim_only_action must be error|warn|ignore", file=rel)

    clock = dict(raw.get("clock", {}))
    _check_keys(clock, _ALLOWED["clock"], "clock", sink, rel)
    clock.setdefault("name", "clk")
    clock.setdefault("period_ns", 10.0)
    per = clock["period_ns"]
    if not isinstance(per, (int, float)) or isinstance(per, bool) or per <= 0 or per > 1_000_000:
        sink.error("CFG007", f"[clock].period_ns must be a positive number (got {per!r})", file=rel)

    params = _load_params(raw.get("parameters", {}), sink, rel)
    constraints: List[Tuple[str, str]] = []
    for i, cn in enumerate(raw.get("constraints", [])):
        _check_keys(cn, _ALLOWED["constraints"], f"constraints[{i}]", sink, rel)
        expr = cn.get("expr", "")
        try:
            ast.parse(expr, mode="eval")
        except SyntaxError:
            sink.error("CFG002", f"[constraints][{i}].expr is not a valid expression: {expr!r}", file=rel)
            continue
        constraints.append((expr, cn.get("message", expr)))
    blocks = _load_blocks(raw.get("blocks", {}), sink, rel)
    for b in blocks.values():
        for r in b.requires + b.conflicts:
            if r not in blocks:
                sink.error("CFG006", f"block '{b.key}' refers to unknown block '{r}'", file=rel)

    lint = dict(raw.get("lint", {}))
    _check_keys(lint, _ALLOWED["lint"], "lint", sink, rel)
    waivers: List[WaiverSpec] = []
    for i, w in enumerate(lint.get("waive", [])):
        _check_keys(w, _ALLOWED["waive"], f"lint.waive[{i}]", sink, rel)
        if not (w.get("reason") or "").strip():
            sink.error("STG006", f"lint waiver '{w.get('id')}' has no reason (every waiver must be justified)", file=rel)
        waivers.append(WaiverSpec(w.get("id", ""), w.get("reason", ""), w.get("scope", "*"), w.get("max_count")))
    elab = dict(raw.get("elaborate", {}))
    _check_keys(elab, _ALLOWED["elaborate"], "elaborate", sink, rel)
    elab.setdefault("tools", ["verilator", "icarus", "yosys"])
    sim = dict(raw.get("simulate", {}))
    _check_keys(sim, _ALLOWED["simulate"], "simulate", sink, rel)
    syn = dict(raw.get("synth", {}))
    _check_keys(syn, _ALLOWED["synth"], "synth", sink, rel)
    sta = dict(raw.get("sta", {}))
    _check_keys(sta, _ALLOWED["sta"], "sta", sink, rel)
    if sim.get("enabled", False):
        if not sim.get("tb_top"):
            sink.error("CFG002", "[simulate] is enabled but has no tb_top", file=rel)
        if sim.get("engine", "icarus") not in ("icarus", "verilator"):
            sink.error("CFG002", "[simulate].engine must be icarus|verilator", file=rel)
        if not sim.get("pass_regex"):
            sink.error("CFG002", "[simulate].pass_regex is required (a simulation only passes on positive evidence)", file=rel)
        if int(sim.get("min_pass", 0)) < 1:
            sink.error("CFG002", "[simulate].min_pass must be >= 1: 'no FAIL printed' is not a pass", file=rel)
        for k in ("pass_regex", "fail_regex"):
            if sim.get(k):
                try:
                    re.compile(sim[k])
                except re.error as e:
                    sink.error("CFG002", f"[simulate].{k} is not a valid regex: {e}", file=rel)
        if not any(s.role == "tb" for s in sources):
            sink.error("CFG002", "[simulate] is enabled but there is no source with role = \"tb\"", file=rel)
        seen_runs = set()
        for i, r in enumerate(sim.get("runs", [])):
            if not isinstance(r, dict) or not re.fullmatch(r"[A-Za-z0-9_.-]+", str(r.get("name", ""))) \
                    or not isinstance(r.get("plusargs", []), list) or set(r) - {"name", "plusargs"}:
                sink.error("CFG002", f"[simulate].runs[{i}] must be {{ name = \"...\", plusargs = [...] }}", file=rel)
                continue
            if r["name"] in seen_runs:
                sink.error("CFG002", f"[simulate].runs: duplicate run name '{r['name']}'", file=rel)
            seen_runs.add(r["name"])

    if len(sink.errors) > n0:
        return None
    return Config(name=name, title=c.get("title", name), description=c.get("description", ""),
                  category=category, enabled=enabled, blocker=blocker, sources=sources, top=top,
                  defines=defines, stage_defines=stage_defines,
                  blackboxes=list(d.get("blackboxes", [])),
                  assertion_idioms=list(d.get("assertion_idioms", ["illegal_parameter_*", "*_param_error_*"])),
                  language=lang, clock=clock, params=params, constraints=constraints, blocks=blocks,
                  lint=lint, elaborate=elab, simulate=sim, synth=syn, sta=sta, waivers=waivers,
                  path=rel, raw=raw)


def _load_params(tbl: Mapping[str, Any], sink: DiagnosticSink, file: str) -> Dict[str, ParamSpec]:
    out: Dict[str, ParamSpec] = {}
    for key in sorted(tbl):
        p = tbl[key]
        if not re.fullmatch(r"[A-Za-z_]\w*", key):
            sink.error("CFG002", f"parameter key '{key}' is not an identifier", file=file)
            continue
        _check_keys(p, _ALLOWED["param"], f"parameters.{key}", sink, file)
        typ = p.get("type", "int")
        if typ not in ("int", "bool"):
            sink.error("CFG002", f"[parameters.{key}].type must be int|bool", file=file)
            continue
        if "default" not in p:
            sink.error("CFG002", f"[parameters.{key}] needs a default", file=file)
            continue
        spec = ParamSpec(key=key, rtl_name=p.get("rtl_name", key), tb_name=p.get("tb_name", p.get("rtl_name", key)),
                         type=typ, default=p["default"],
                         choices=_tup(p.get("choices")), min=p.get("min"), max=p.get("max"),
                         pow2=bool(p.get("pow2", False)), multiple_of=p.get("multiple_of"),
                         doc=p.get("doc", ""), tags=_tup(p.get("tags")),
                         apply_to=_tup(p.get("apply_to", ("design",))))
        err = check_param_value(spec, spec.default)
        if err:
            sink.error("CFG005", f"[parameters.{key}] default {spec.default!r} violates its own constraints: {err}", file=file)
        out[key] = spec
    return out


def _load_blocks(tbl: Mapping[str, Any], sink: DiagnosticSink, file: str) -> Dict[str, BlockSpec]:
    out: Dict[str, BlockSpec] = {}
    for key in sorted(tbl):
        b = tbl[key]
        _check_keys(b, _ALLOWED["block"], f"blocks.{key}", sink, file)
        if not b.get("param"):
            sink.error("CFG002", f"[blocks.{key}] needs `param` (the RTL parameter that enables it)", file=file)
            continue
        out[key] = BlockSpec(key=key, param=b["param"], default=bool(b.get("default", True)),
                             requires=_tup(b.get("requires")), conflicts=_tup(b.get("conflicts")),
                             doc=b.get("doc", ""))
    return out


# --------------------------------------------------------------------------
# parameter checking / overrides
# --------------------------------------------------------------------------
def check_param_value(spec: ParamSpec, value: Any) -> Optional[str]:
    """Return an error string if ``value`` violates ``spec`` else ``None``."""
    if spec.type == "bool":
        if not isinstance(value, bool) and value not in (0, 1):
            return f"expected a boolean (0/1), got {value!r}"
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        return f"expected an integer, got {value!r}"
    if spec.choices and value not in spec.choices:
        return f"must be one of {list(spec.choices)}, got {value}"
    if spec.min is not None and value < spec.min:
        return f"must be >= {spec.min}, got {value}"
    if spec.max is not None and value > spec.max:
        return f"must be <= {spec.max}, got {value}"
    if spec.pow2 and (value <= 0 or value & (value - 1)):
        return f"must be a power of two, got {value}"
    if spec.multiple_of and value % spec.multiple_of:
        return f"must be a multiple of {spec.multiple_of}, got {value}"
    return None


class _Safe(ast.NodeVisitor):
    """Whitelist evaluator for ``[[constraints]]`` expressions."""

    BIN = {ast.Add: lambda a, b: a + b, ast.Sub: lambda a, b: a - b, ast.Mult: lambda a, b: a * b,
           ast.FloorDiv: lambda a, b: a // b, ast.Mod: lambda a, b: a % b, ast.Pow: lambda a, b: a ** b,
           ast.LShift: lambda a, b: a << b, ast.RShift: lambda a, b: a >> b,
           ast.BitAnd: lambda a, b: a & b, ast.BitOr: lambda a, b: a | b, ast.BitXor: lambda a, b: a ^ b}
    CMP = {ast.Eq: lambda a, b: a == b, ast.NotEq: lambda a, b: a != b, ast.Lt: lambda a, b: a < b,
           ast.LtE: lambda a, b: a <= b, ast.Gt: lambda a, b: a > b, ast.GtE: lambda a, b: a >= b}

    def __init__(self, env: Mapping[str, Any]):
        self.env = env

    def visit(self, node):  # type: ignore[override]
        m = getattr(self, "v_" + type(node).__name__, None)
        if m is None:
            raise ValueError(f"unsupported expression element {type(node).__name__}")
        return m(node)

    def v_Expression(self, n): return self.visit(n.body)
    def v_Constant(self, n):
        if isinstance(n.value, (int, bool)):
            return n.value
        raise ValueError("only integer literals allowed")
    def v_Name(self, n):
        if n.id in self.env:
            return self.env[n.id]
        if n.id in ("True", "False"):
            return n.id == "True"
        raise ValueError(f"unknown parameter '{n.id}'")
    def v_BinOp(self, n):
        f = self.BIN.get(type(n.op))
        if not f:
            raise ValueError("operator not allowed")
        return f(self.visit(n.left), self.visit(n.right))
    def v_UnaryOp(self, n):
        v = self.visit(n.operand)
        if isinstance(n.op, ast.Not): return not v
        if isinstance(n.op, ast.USub): return -v
        if isinstance(n.op, ast.Invert): return ~v
        raise ValueError("operator not allowed")
    def v_BoolOp(self, n):
        vals = [self.visit(v) for v in n.values]
        return all(vals) if isinstance(n.op, ast.And) else any(vals)
    def v_Compare(self, n):
        left = self.visit(n.left)
        for op, comp in zip(n.ops, n.comparators):
            f = self.CMP.get(type(op))
            if not f:
                raise ValueError("comparison not allowed")
            right = self.visit(comp)
            if not f(left, right):
                return False
            left = right
        return True
    def v_Call(self, n):
        if isinstance(n.func, ast.Name) and n.func.id in ("clog2", "min", "max", "abs"):
            args = [self.visit(a) for a in n.args]
            if n.func.id == "clog2":
                return max(0, (int(args[0]) - 1).bit_length())
            return {"min": min, "max": max, "abs": abs}[n.func.id](*args)
        raise ValueError("function call not allowed")


def safe_eval(expr: str, env: Mapping[str, Any]) -> Any:
    return _Safe(env).visit(ast.parse(expr, mode="eval"))


def parse_overrides(pairs: Sequence[str], sink: DiagnosticSink, what: str = "parameter") -> Dict[str, str]:
    out: Dict[str, str] = {}
    for p in pairs:
        if "=" not in p:
            sink.error("CFG005", f"{what} override '{p}' must look like NAME=VALUE")
            continue
        k, v = p.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def apply_overrides(cfg: Config, param_ov: Mapping[str, str], block_ov: Mapping[str, str],
                    sink: DiagnosticSink) -> Dict[str, Any]:
    """Compute the effective parameter set (config key -> value) and validate it
    (types, ranges, constraints, block requires/conflicts).  Errors go to ``sink``."""
    values: Dict[str, Any] = cfg.defaults()
    for k, v in sorted(param_ov.items()):
        spec = cfg.params.get(k)
        if spec is None:
            sink.error("CFG005", f"parameter '{k}' is not declared by configuration '{cfg.name}' "
                                 f"(declared: {', '.join(sorted(cfg.params)) or 'none'})", file=cfg.path)
            continue
        try:
            val: Any = (v.lower() in ("1", "true", "on", "yes")) if spec.type == "bool" else int(v, 0)
            if spec.type == "bool" and v.lower() not in ("0", "1", "true", "false", "on", "off", "yes", "no"):
                raise ValueError
        except ValueError:
            sink.error("CFG005", f"parameter '{k}': cannot interpret '{v}' as {spec.type}", file=cfg.path)
            continue
        err = check_param_value(spec, val)
        if err:
            sink.error("PAR003", f"parameter '{k}': {err}", file=cfg.path)
            continue
        values[k] = val
    # constraints over the effective set
    env = {k: (int(v) if isinstance(v, bool) else v) for k, v in values.items()}
    for expr, msg in cfg.constraints:
        try:
            if not safe_eval(expr, env):
                sink.error("PAR003", f"constraint violated: {msg}  [{expr}]", file=cfg.path)
        except (ValueError, ZeroDivisionError) as e:
            sink.error("CFG002", f"constraint '{expr}' cannot be evaluated: {e}", file=cfg.path)
    # blocks
    state = {k: b.default for k, b in cfg.blocks.items()}
    for k, v in sorted(block_ov.items()):
        if k not in cfg.blocks:
            sink.error("CFG006", f"block '{k}' is not declared by configuration '{cfg.name}' "
                                 f"(declared: {', '.join(sorted(cfg.blocks)) or 'none'})", file=cfg.path)
            continue
        if v.lower() not in ("on", "off", "1", "0", "true", "false"):
            sink.error("CFG006", f"block '{k}': value must be on|off, got '{v}'", file=cfg.path)
            continue
        state[k] = v.lower() in ("on", "1", "true")
    for k, on in sorted(state.items()):
        if not on:
            continue
        for r in cfg.blocks[k].requires:
            if not state.get(r, False):
                sink.error("CFG006", f"block '{k}' requires block '{r}' to be enabled", file=cfg.path)
        for r in cfg.blocks[k].conflicts:
            if state.get(r, False):
                sink.error("CFG006", f"block '{k}' conflicts with block '{r}'", file=cfg.path)
    for k, on in state.items():
        values[f"block:{k}"] = bool(on)
    return values


def rtl_parameter_map(cfg: Config, values: Mapping[str, Any]) -> Dict[str, Dict[str, int]]:
    """Split the effective values into RTL parameter overrides per scope."""
    out: Dict[str, Dict[str, int]] = {"design": {}, "tb": {}}
    for k, spec in cfg.params.items():
        v = values[k]
        for scope in spec.apply_to:
            out.setdefault(scope, {})[spec.tb_name if scope == "tb" else spec.rtl_name] = int(v)
    for k, b in cfg.blocks.items():
        out["design"][b.param] = 1 if values.get(f"block:{k}") else 0
    return out
