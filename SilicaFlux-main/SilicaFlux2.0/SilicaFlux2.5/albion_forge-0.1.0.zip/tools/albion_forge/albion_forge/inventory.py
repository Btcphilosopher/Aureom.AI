"""Repository forensics: ``albion inventory``.

Walks the whole SilicaFlux repository -- loose files, zip archives and archives
nested inside archives -- *in memory* (nothing is extracted to the repo) and
reports, reproducibly:

* every SystemVerilog / Verilog / ``.sf`` / ``.sfx`` file, deduplicated by
  content hash, with the containers it appears in;
* design-unit definitions, duplicate / version-conflicting definitions;
* per-project dependency closure of each candidate top (missing modules,
  missing packages, include failures, conflicts);
* clock / reset conventions, simulation-only constructs, DPI / class / UVM use;
* what ``.sf`` files really are, **checked with Verilator** (does each one parse
  as SystemVerilog once given a ``.sv`` extension?);
* existing FPGA / ASIC / simulation build scripts.

The output is data (JSON + TSV) plus a human summary in Markdown.
"""
from __future__ import annotations

import collections
import hashlib
import io
import json
import os
import posixpath
import re
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from . import __version__
from .depgraph import SourceFile, candidate_tops, resolve
from .diagnostics import DiagnosticSink, Severity
from .sv_scan import always_ff_styles, classify_sf, scan_text
from . import toolchain

HDL_EXT = (".sv", ".v", ".svh", ".vh", ".sf", ".sfx")
SKIP_BIN = (".png", ".jpg", ".jpeg", ".gif", ".mp3", ".webm", ".mp4", ".pdf", ".woff", ".woff2", ".ttf", ".ico")
SCRIPT_NAMES = ("makefile", "gnumakefile")
SCRIPT_EXT = (".mk", ".sh", ".tcl", ".sdc", ".xdc", ".qsf", ".ys", ".f", ".do", ".lpf", ".pcf", ".cfg")
NONRTL_DIRS = {"tb", "tests", "test", "formal", "sim", "sim_models", "examples", "bench", "benchmarks",
               "verif", "verification", "docs", "reports"}
SIMONLY_CATEGORIES = ("initial_block", "final_block", "delay", "system_task", "wait_stmt", "event_type",
                      "immediate_assertion", "concurrent_assertion", "severity_task")
FORBID_CATEGORIES = ("class", "program", "fork_join", "covergroup", "constraint_random", "dpi", "uvm",
                     "force_release", "ipc", "virtual_interface")
MAX_NESTED = 300_000_000


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


class _Walker:
    def __init__(self) -> None:
        self.by_sha: Dict[str, bytes] = {}                    # HDL content (first occurrence)
        self.occ: Dict[str, List[Tuple[str, str]]] = collections.defaultdict(list)  # sha -> [(container, path)]
        self.containers: List[Dict[str, Any]] = []
        self.seen_container: Dict[str, str] = {}
        self.scripts: List[Dict[str, Any]] = []
        self.other_ext: collections.Counter = collections.Counter()
        self.vfs_by_container: Dict[str, Dict[str, str]] = collections.defaultdict(dict)

    def add_hdl(self, container: str, path: str, data: bytes) -> None:
        h = sha(data)
        if h not in self.by_sha:
            self.by_sha[h] = data
        self.occ[h].append((container, path))
        self.vfs_by_container[container][posixpath.normpath("/" + path)] = None  # filled lazily

    def walk_zip(self, zf: zipfile.ZipFile, container: str, depth: int) -> None:
        n_hdl = 0
        for info in zf.infolist():
            if info.is_dir():
                continue
            name = info.filename
            low = name.lower()
            if "/.git/" in "/" + name or name.startswith(".git/") or "__MACOSX" in name:
                continue
            if low.endswith(SKIP_BIN):
                continue
            if low.endswith(HDL_EXT):
                self.add_hdl(container, name, zf.read(info))
                n_hdl += 1
            elif low.endswith(".zip") and depth < 6 and info.file_size < MAX_NESTED:
                try:
                    inner = zf.read(info)
                    ih = sha(inner)
                    cname = container + "!" + name
                    if ih in self.seen_container:
                        self.containers.append({"container": cname, "sha256": ih, "duplicate_of": self.seen_container[ih]})
                        continue
                    self.seen_container[ih] = cname
                    with zipfile.ZipFile(io.BytesIO(inner)) as z2:
                        before = len(self.containers)
                        self.containers.append({"container": cname, "sha256": ih, "depth": depth + 1})
                        self.walk_zip(z2, cname, depth + 1)
                except (zipfile.BadZipFile, OSError):
                    self.containers.append({"container": container + "!" + name, "error": "unreadable"})
            elif low.endswith((".tar.gz", ".tgz")) and depth < 6:
                try:
                    tf = tarfile.open(fileobj=io.BytesIO(zf.read(info)))
                    for m in tf.getmembers():
                        if m.isfile() and m.name.lower().endswith(HDL_EXT):
                            f = tf.extractfile(m)
                            if f:
                                self.add_hdl(container + "!" + name, m.name, f.read())
                except (tarfile.TarError, OSError):
                    pass
            else:
                base = posixpath.basename(low)
                if base in SCRIPT_NAMES or low.endswith(SCRIPT_EXT) or base.startswith("run_"):
                    if info.file_size < 400_000:
                        self.scripts.append({"container": container, "path": name, "size": info.file_size,
                                             "sha256": sha(zf.read(info))[:16],
                                             "kind": _script_kind(name, zf.read(info))})
                else:
                    self.other_ext[os.path.splitext(low)[1]] += 1


def _script_kind(path: str, data: bytes) -> str:
    low = path.lower()
    text = data[:20000].decode("utf-8", "replace").lower()
    kinds = []
    if low.endswith((".xdc", ".qsf", ".lpf", ".pcf")) or any(k in text for k in ("vivado", "quartus", "nextpnr", "arty", "de10", "ecp5", "set_property package_pin")):
        kinds.append("fpga")
    if low.endswith(".sdc") or any(k in text for k in ("openlane", "openroad", "sky130", "gf180", "nangate", "floorplan", "create_clock", "liberty", "synth_asic", "abc -liberty")):
        kinds.append("asic")
    if any(k in text for k in ("verilator", "iverilog", "vvp", "cocotb", "xrun", "vcs ", "questa", "vsim")):
        kinds.append("sim")
    if "yosys" in text:
        kinds.append("yosys")
    return "+".join(kinds) if kinds else "other"


def walk_repo(repo: str) -> _Walker:
    w = _Walker()
    for dp, dn, fn in os.walk(repo):
        dn[:] = sorted(d for d in dn if d not in (".git", "build", "node_modules", "__pycache__"))
        rel_dp = os.path.relpath(dp, repo)
        if rel_dp.replace(os.sep, "/").startswith("tools/albion_forge"):
            dn[:] = []
            continue
        for f in sorted(fn):
            p = os.path.join(dp, f)
            rel = os.path.relpath(p, repo).replace(os.sep, "/")
            low = f.lower()
            if low.endswith(SKIP_BIN):
                continue
            if low.endswith(".zip"):
                try:
                    zb = open(p, "rb").read()
                    zh = sha(zb)
                    if zh in w.seen_container:
                        w.containers.append({"container": rel, "sha256": zh, "duplicate_of": w.seen_container[zh]})
                        continue
                    w.seen_container[zh] = rel
                    w.containers.append({"container": rel, "sha256": zh, "depth": 0})
                    with zipfile.ZipFile(io.BytesIO(zb)) as zf:
                        w.walk_zip(zf, rel, 0)
                except (zipfile.BadZipFile, OSError):
                    w.containers.append({"container": rel, "error": "unreadable"})
            elif low.endswith(HDL_EXT):
                try:
                    w.add_hdl("(loose)", rel, open(p, "rb").read())
                except OSError:
                    pass
            elif low.endswith((".tar.gz", ".tgz")):
                try:
                    tf = tarfile.open(p)
                    for m in tf.getmembers():
                        if m.isfile() and m.name.lower().endswith(HDL_EXT):
                            fh = tf.extractfile(m)
                            if fh:
                                w.add_hdl(rel, m.name, fh.read())
                except (tarfile.TarError, OSError):
                    pass
            else:
                base = low
                if base in SCRIPT_NAMES or low.endswith(SCRIPT_EXT) or base.startswith("run_"):
                    try:
                        data = open(p, "rb").read()
                    except OSError:
                        continue
                    if len(data) < 400_000:
                        w.scripts.append({"container": "(loose)", "path": rel, "size": len(data),
                                          "sha256": sha(data)[:16], "kind": _script_kind(rel, data)})
    return w


# --------------------------------------------------------------------------
def _family(container: str) -> str:
    low = container.lower()
    return "silicaflux" if any(k in low for k in ("silicaflux", "albion", "sha256-learn", "neurax")) else "other"


def _role_of(path: str) -> str:
    parts = [p.lower() for p in path.split("/")]
    base = parts[-1]
    if any(p in ("tb", "tests", "test", "bench", "verif") for p in parts[:-1]) or base.startswith("tb_"):
        return "tb"
    if any(p in ("formal",) for p in parts[:-1]) or base.startswith("fv_"):
        return "formal"
    if any(p in ("sim_models", "sim") for p in parts[:-1]):
        return "model"
    return "rtl"


def analyse(w: _Walker, tool_parse: bool = True) -> Dict[str, Any]:
    # ---- per unique file scan ---------------------------------------------------------
    uniq: Dict[str, Dict[str, Any]] = {}
    scans: Dict[str, Any] = {}
    for h, data in sorted(w.by_sha.items()):
        occ = sorted(w.occ[h])
        c0, p0 = occ[0]
        ext = os.path.splitext(p0)[1].lower()
        text = data.decode("utf-8", "replace")
        row: Dict[str, Any] = {"sha256": h, "ext": ext, "size": len(data), "lines": text.count("\n") + 1,
                               "occurrences": len(occ), "first": f"{c0}::{p0}", "role": _role_of(p0)}
        if ext != ".sfx":
            sc = scan_text(p0, text)
            scans[h] = sc
            row["units"] = [(d.kind, d.name) for d in sc.decls]
            row["findings"] = dict(collections.Counter(f.category for f in sc.findings))
            row["parse_errors"] = len(sc.parse_errors)
            row["ff"] = always_ff_styles(text)
            row["ports_clk_rst"] = sorted({n for _, n in sc.clock_reset})[:6]
        uniq[h] = row

    # ---- duplicate / conflicting definitions ------------------------------------------------
    by_name: Dict[Tuple[str, str], Set[str]] = collections.defaultdict(set)
    for h, sc in scans.items():
        for d in sc.decls:
            by_name[(d.kind, d.name)].add(h)
    conflicts = sorted(((n, len(s)) for (k, n), s in by_name.items() if len(s) > 1), key=lambda x: (-x[1], x[0]))
    unit_kinds = collections.Counter(k for (k, _n) in by_name)

    # ---- tops / closure survey per project --------------------------------------------------
    projects = _projects(w)
    closure_rows: List[Dict[str, Any]] = []
    miss_mod: collections.Counter = collections.Counter()
    miss_pkg: collections.Counter = collections.Counter()
    for pkey, members in sorted(projects.items()):
        files: List[SourceFile] = []
        proj_vfs: Dict[str, str] = {}
        for (cont, path, h) in members:
            proj_vfs[posixpath.normpath("/" + path)] = w.by_sha[h].decode("utf-8", "replace")
        dirs = sorted({posixpath.dirname(p) for p in proj_vfs})
        for (cont, path, h) in members:
            if path.lower().endswith((".svh", ".vh")):
                continue
            vp = posixpath.normpath("/" + path)
            sc = scan_text(vp, proj_vfs[vp], include_dirs=dirs, vfs=proj_vfs)
            files.append(SourceFile(logical=path, path=vp, scan=sc))
        if not files:
            continue
        own = [f for f in files if "third_party" not in f.logical.split("/")]
        tops = [t for t in candidate_tops(own) if t not in {i.target for f in files for i in f.scan.instances}]
        entry: Dict[str, Any] = {"project": pkey, "files": len(files), "own_files": len(own), "tops": tops[:5], "closures": {}}
        for t in tops[:3]:
            sink = DiagnosticSink()
            r = resolve(files, t, sink)
            ec = collections.Counter(d.code for d in sink.items if d.severity >= Severity.ERROR)
            for d in sink.errors:
                m = re.search(r"module '([^']+)' is instantiated", d.message)
                if m and d.code == "DEP001":
                    miss_mod[m.group(1)] += 1
                m = re.search(r"package '([^']+)' is referenced", d.message)
                if m and d.code == "DEP002":
                    miss_pkg[m.group(1)] += 1
            entry["closures"][t] = {"complete": r.ok, "files_in_closure": len(r.order), "errors": dict(ec)}
        closure_rows.append(entry)

    # ---- clock / reset conventions --------------------------------------------------------------
    port_names: collections.Counter = collections.Counter()
    ff_total = collections.Counter()
    for h, row in uniq.items():
        for k, v in row.get("ff", {}).items():
            ff_total[k] += v
        for n in row.get("ports_clk_rst", []):
            port_names[n] += 1

    # ---- simulation-only / unsupported constructs --------------------------------------------------------
    con = {"rtl": collections.Counter(), "tb": collections.Counter(), "other": collections.Counter()}
    files_with: Dict[str, Dict[str, int]] = {"rtl": collections.Counter(), "tb": collections.Counter()}
    for h, row in uniq.items():
        role = "rtl" if row["role"] == "rtl" else "tb" if row["role"] == "tb" else "other"
        for cat, n in row.get("findings", {}).items():
            con[role][cat] += n
            if role in files_with:
                files_with[role][cat] += 1

    # ---- .sf survey -------------------------------------------------------------------------------------------
    sf_info = _sf_survey(w, uniq, scans, tool_parse)

    # ---- scripts --------------------------------------------------------------------------------------------------
    seen = set()
    scripts = []
    for s in w.scripts:
        k = (s["sha256"], s["path"].split("/")[-1])
        if k in seen:
            continue
        seen.add(k)
        scripts.append(s)
    script_kinds = collections.Counter(s["kind"] for s in scripts)

    fam = collections.Counter()
    for h in uniq:
        fam[_family(uniq[h]["first"])] += 1

    total_files = sum(len(v) for v in w.occ.values())
    return {
        "forge_version": __version__,
        "totals": {"hdl_file_occurrences": total_files, "unique_hdl_contents": len(uniq),
                   "duplication_factor": round(total_files / max(1, len(uniq)), 2),
                   "containers": len(w.containers),
                   "unique_containers": sum(1 for c in w.containers if "duplicate_of" not in c and "error" not in c),
                   "by_extension_unique": dict(collections.Counter(r["ext"] for r in uniq.values())),
                   "by_family_unique": dict(fam),
                   "design_units": dict(unit_kinds), "distinct_unit_names": len(by_name)},
        "conflicting_definitions": {"names_with_multiple_versions": len(conflicts), "top": conflicts[:40]},
        "closure_survey": {
            "projects": len(closure_rows),
            "tops_evaluated": sum(len(r["closures"]) for r in closure_rows),
            "tops_dependency_complete": sum(1 for r in closure_rows for c in r["closures"].values() if c["complete"]),
            "most_missing_modules": miss_mod.most_common(25),
            "most_missing_packages": miss_pkg.most_common(15),
            "rows": closure_rows},
        "clock_reset": {"always_ff_reset_styles": dict(ff_total), "common_clk_rst_port_names": port_names.most_common(20)},
        "constructs": {"rtl_files": dict(con["rtl"]),
                       "tb_files": dict(con["tb"]),
                       "rtl_files_containing": dict(files_with["rtl"]),
                       "forbidden_in_rtl_dirs": {k: v for k, v in files_with["rtl"].items() if k in FORBID_CATEGORIES}},
        "sf_survey": sf_info,
        "build_scripts": {"unique": len(scripts), "by_kind": dict(script_kinds),
                          "examples": [s["container"] + "::" + s["path"] for s in scripts if "asic" in s["kind"]][:10]},
        "unique_files": [{"sha256": h[:16], **{k: v for k, v in r.items() if k not in ("sha256",)}}
                         for h, r in sorted(uniq.items(), key=lambda kv: kv[1]["first"])],
    }


def _projects(w: _Walker) -> Dict[str, List[Tuple[str, str, str]]]:
    """Group files into 'projects': a container plus the directory prefix above its
    first ``rtl/`` directory.  Vendored ``third_party`` trees stay inside their
    parent project (that is what a single build of the parent sees)."""
    projects: Dict[str, List[Tuple[str, str, str]]] = collections.defaultdict(list)
    for h, occs in w.occ.items():
        for (cont, path) in occs:
            parts = path.split("/")
            if "rtl" not in parts:
                continue
            if _role_of(path) != "rtl" and not path.lower().endswith((".svh", ".vh")):
                continue
            if any(p in NONRTL_DIRS for p in parts[:-1] if p != "rtl"):
                continue
            # first "rtl" component that is not under third_party
            pre = None
            for i, p in enumerate(parts[:-1]):
                if p == "rtl" and "third_party" not in parts[:i]:
                    pre = "/".join(parts[:i])
                    break
            if pre is None:
                continue
            projects[f"{cont}::{pre}"].append((cont, path, h))
    for k in projects:
        projects[k] = sorted(set(projects[k]))
    return projects


def _sf_survey(w: _Walker, uniq: Dict[str, Dict[str, Any]], scans: Dict[str, Any], tool_parse: bool) -> Dict[str, Any]:
    """Answer "are `.sf` files SystemVerilog?" with the real parser.

    Each unique ``.sf`` file is copied to a temp dir as ``.sv`` together with the
    package files it (transitively) needs, and linted with Verilator.  Because
    the repository holds *several versions* of the same package, every package
    variant is tried (same-container variants first); a file counts as a
    *syntax failure* only if **no** variant combination gets past the parser.
    Messages about unknown types / missing packages are *not* syntax errors,
    but Verilator reports an unknown type as 'syntax error ... TYPE-IDENTIFIER',
    which is why the variant search matters.
    """
    sf_all = [(h, r) for h, r in uniq.items() if r["ext"] == ".sf"]
    dsl = [(h, r) for h, r in sf_all if classify_sf(w.by_sha[h].decode("utf-8", "replace")) == "dsl"]
    dsl_h = {h for h, _ in dsl}
    sf = [(h, r) for h, r in sf_all if h not in dsl_h]
    sfx = [(h, r) for h, r in uniq.items() if r["ext"] == ".sfx"]
    info: Dict[str, Any] = {"unique_sf_files": len(sf_all), "sf_occurrences": sum(r["occurrences"] for _, r in sf_all),
                            "dialects": {"systemverilog_with_sf_extension": len(sf),
                                         "dsl_sketch_not_compilable": len(dsl),
                                         "dsl_sketch_files": [r["first"] for _, r in dsl]},
                            "unique_sfx_files": len(sfx),
                            "sfx_nature": "SilicaFlux assembly programs consumed by sim/sfx_asm.py (not HDL)",
                            "header_language_claim": "files declare 'Language: Silica Flux-2017'",
                            "translation_required": None}
    vl = toolchain.detect("verilator")
    if not tool_parse or not vl.found:
        info["parse_check"] = "not run" + ("" if tool_parse else " (--no-tool-parse)") + ("" if vl.found else " (verilator missing)")
        return info
    # package name -> variants (sha), same-container preference resolved per file
    pkg_variants: Dict[str, List[str]] = collections.defaultdict(list)
    for h, r in uniq.items():
        for kind, name in r.get("units", []):
            if kind == "package":
                pkg_variants[name].append(h)

    def needs(h: str) -> List[str]:
        return sorted({x.package for x in scans[h].refs if x.package in pkg_variants and x.package not in
                       {d.name for d in scans[h].decls}})

    # headers by (container, directory): `include`d geometry/config headers must be present
    hdr_index: Dict[Tuple[str, str], List[Tuple[str, str]]] = collections.defaultdict(list)
    for h, r in uniq.items():
        if r["ext"] in (".svh", ".vh"):
            for c, pth in w.occ[h]:
                hdr_index[(c, posixpath.dirname(pth))].append((posixpath.basename(pth), h))

    def lint(order: List[str], td: str, cont: str = "", pdir: str = "") -> Tuple[int, List[str]]:
        d = tempfile.mkdtemp(dir=td)
        for name, hh in hdr_index.get((cont, pdir), []):
            with open(os.path.join(d, name), "wb") as fh:
                fh.write(w.by_sha[hh])
        paths = []
        for i, hh in enumerate(order):
            fp = os.path.join(d, f"{i:02d}_{hh[:8]}.sv")
            with open(fp, "wb") as fh:
                fh.write(w.by_sha[hh])
            paths.append(fp)
        p = subprocess.run([vl.path, "--lint-only", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
                            "-I" + d] + paths,
                           capture_output=True, text=True, timeout=180, env={**os.environ, "LC_ALL": "C"})
        errs = [l for l in p.stderr.splitlines() if l.startswith("%Error")]
        return p.returncode, errs

    syntax_fail: List[str] = []
    tool_unsupported: List[str] = []
    other_family: List[str] = []
    ok = ok_with_pkg = link_only = 0
    with tempfile.TemporaryDirectory(prefix="albion_sf_") as td:
        for h, r in sorted(sf, key=lambda kv: kv[1]["first"]):
            cont = r["first"].split("::", 1)[0]
            # transitive package set (names), then candidate variants per name
            names: List[str] = []
            todo = needs(h)
            while todo and len(names) < 6:
                n = todo.pop(0)
                if n in names:
                    continue
                names.append(n)
                for v in pkg_variants[n][:1]:
                    todo += [x for x in needs(v) if x not in names]
            def ranked(n: str) -> List[str]:
                vs = pkg_variants[n]
                same = [v for v in vs if any(c == cont for c, _ in w.occ[v])]
                return same + [v for v in vs if v not in same]
            attempts: List[List[str]] = []
            base = [ranked(n)[0] for n in names]
            attempts.append(base)
            for i, n in enumerate(names):          # vary one package at a time
                for alt in ranked(n)[1:]:
                    attempts.append(base[:i] + [alt] + base[i + 1:])
            last_errs: List[str] = []
            outcome = None
            for att in attempts[:60]:
                rc, errs = lint(att + [h], td, cont, posixpath.dirname(r["first"].split("::", 1)[1]))
                last_errs = errs
                syn = [l for l in errs if "syntax error" in l]
                uns = [l for l in errs if "Unsupported" in l or "UNSUPPORTED" in l]
                if not errs:
                    outcome = "ok"
                    break
                if not syn and uns:
                    outcome = "tool_unsupported"
                    break
                if not syn:
                    outcome = "link"
                    break
            fam = _family(r["first"])       # full "container::path": loose repo files have container "(loose)"
            if fam != "silicaflux":
                other_family.append(r["first"])
                continue
            if outcome == "ok":
                ok += 1
                ok_with_pkg += 1 if names else 0
            elif outcome == "link":
                link_only += 1
            elif outcome == "tool_unsupported":
                tool_unsupported.append(f"{r['first']}: {[l for l in last_errs if 'nsupported' in l or 'UNSUPPORTED' in l][0][-120:]}")
            else:
                syntax_fail.append(f"{r['first']}: " + re.sub(r"/\S*?/(\d\d_\w+\.sv|[\w.]+\.sv)", r"\1",
                                   [l for l in last_errs if 'syntax' in l][0])[-170:])
    info["parse_check"] = {
        "tool": f"verilator {vl.version} --lint-only (each file renamed to .sv; every package variant and sibling header tried)",
        "silicaflux_sf_files_tested": len(sf) - len(other_family),
        "systemverilog_dialect_files": len(sf),
        "parses_clean": ok, "parses_clean_needing_package_files": ok_with_pkg,
        "parses_but_only_link_level_errors": link_only,
        "valid_sv_but_verilator_unsupported": len(tool_unsupported), "tool_unsupported_examples": tool_unsupported[:6],
        "unresolved_types_in_every_package_variant_or_syntax_errors": len(syntax_fail), "failures": syntax_fail[:25],
        "non_silicaflux_sf_files_ignored": other_family}
    info["translation_required"] = "dialect-dependent"
    info["conclusion"] = (
        f"`.sf` is two things. {len(sf)} unique files are SystemVerilog with a different extension (no language translation: "
        "AlbionForge maps `.sf` -> `.sv` as a byte-identical copy, `SRC005` guards the other kind). "
        f"{len(dsl)} unique files are a speculative DSL sketch that declares itself 'documentation only, not compiled' "
        "(package silicaflux.ml / fixed T {..} / state machine) - no translator exists, so they cannot be build inputs. "
        f"Of the {len(sf) - len(other_family)} SilicaFlux SV-dialect files, {ok} parse clean under Verilator ({ok_with_pkg} of them only with the right "
        f"package variant) and {link_only} fail only at link level (a module or package defined elsewhere); {len(tool_unsupported)} use constructs Verilator "
        f"5.020 does not support (covergroup, in testbenches); {len(syntax_fail)} fail against EVERY single package variant with 'unexpected IDENTIFIER, "
        "expecting TYPE-IDENTIFIER', i.e. an unknown package type. Verified for forwarding_unit.sf: the types it needs (fwd_src_e, rob_tag_t) exist only in a "
        "112-line addendum package whose header says 'merge into the project package', and merging it into the 70 KB silicaflux_pkg.sf yields duplicate "
        "declarations (preg_t): a package-dependency gap that needs manual reconciliation by the authors, not a dialect difference. The other failing files show "
        "the identical error signature but were not individually reconciled.")
    return info


# --------------------------------------------------------------------------
def render_markdown(d: Dict[str, Any]) -> str:
    t = d["totals"]
    L = ["# SilicaFlux RTL inventory", "",
         f"_Generated by `albion inventory` (AlbionForge {d['forge_version']}); numbers are measured, not estimated._", "",
         "## Repository census", "",
         f"- HDL file occurrences: **{t['hdl_file_occurrences']}** in {t['containers']} containers "
         f"({t['unique_containers']} distinct archives); unique contents: **{t['unique_hdl_contents']}** "
         f"(duplication factor {t['duplication_factor']}x)",
         f"- unique files by extension: {t['by_extension_unique']}; by family: {t['by_family_unique']}",
         f"- design units: {t['design_units']} ({t['distinct_unit_names']} distinct names)", "",
         "## Conflicting definitions (why the repo cannot be built as one flat design)", "",
         f"{d['conflicting_definitions']['names_with_multiple_versions']} unit names have more than one distinct "
         "definition across archives. Largest:", "", "| unit | distinct versions |", "|---|---|"]
    for n, c in d["conflicting_definitions"]["top"][:15]:
        L.append(f"| `{n}` | {c} |")
    cs = d["closure_survey"]
    L += ["", "## Dependency closure survey (static)", "",
          f"{cs['projects']} project roots; {cs['tops_evaluated']} candidate tops evaluated; "
          f"**{cs['tops_dependency_complete']}** have a complete dependency closure inside their own archive.", "",
          "Most frequently missing modules:", ""]
    for n, c in cs["most_missing_modules"][:15]:
        L.append(f"- `{n}` ({c})")
    L += ["", "Most frequently missing packages:", ""]
    for n, c in cs["most_missing_packages"][:10]:
        L.append(f"- `{n}` ({c})")
    cr = d["clock_reset"]
    L += ["", "## Clock / reset conventions", "",
          f"- `always_ff` reset style counts: {cr['always_ff_reset_styles']}",
          "- most common clock/reset port names: " + ", ".join(f"`{n}` ({c})" for n, c in cr["common_clk_rst_port_names"][:12]), ""]
    k = d["constructs"]
    L += ["## Simulation-only / unsupported constructs", "",
          f"- in RTL-directory files (occurrences): {k['rtl_files']}",
          f"- forbidden-in-RTL categories present in RTL dirs (files): {k['forbidden_in_rtl_dirs']}", ""]
    s = d["sf_survey"]
    L += ["## `.sf` and `.sfx` files", "",
          f"- `.sf`: {s['unique_sf_files']} unique files ({s['sf_occurrences']} occurrences). {s.get('conclusion', '')}",
          f"- parse check: {json.dumps(s.get('parse_check'), default=str)}",
          f"- `.sfx`: {s['unique_sfx_files']} unique files -- {s['sfx_nature']}", ""]
    b = d["build_scripts"]
    L += ["## Existing build scripts", "", f"- {b['unique']} unique script-like files; by kind: {b['by_kind']}", ""]
    return "\n".join(L) + "\n"


def run(repo: str, out_dir: str, as_json: bool = False, tool_parse: bool = True) -> int:
    print(f"scanning {repo} (archives are read in memory; nothing is extracted)...", file=sys.stderr)
    w = walk_repo(repo)
    data = analyse(w, tool_parse)
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "rtl_inventory.json"), "w") as fh:
        json.dump(data, fh, indent=1, sort_keys=True, default=str)
    with open(os.path.join(out_dir, "RTL_INVENTORY.md"), "w") as fh:
        fh.write(render_markdown(data))
    with open(os.path.join(out_dir, "rtl_files.tsv"), "w") as fh:
        fh.write("sha256_16\text\tsize\tlines\toccurrences\trole\tunits\tfirst_location\n")
        for r in data["unique_files"]:
            fh.write("\t".join(str(x) for x in (r["sha256"], r["ext"], r["size"], r["lines"], r["occurrences"], r["role"],
                                                ",".join(n for _, n in r.get("units", []))[:200], r["first"])) + "\n")
    t = data["totals"]
    print(f"{t['hdl_file_occurrences']} HDL files / {t['unique_hdl_contents']} unique in {t['containers']} containers; "
          f"{data['conflicting_definitions']['names_with_multiple_versions']} conflicting unit names; "
          f"{data['closure_survey']['tops_dependency_complete']}/{data['closure_survey']['tops_evaluated']} tops closed")
    print("wrote", os.path.join(out_dir, "RTL_INVENTORY.md"))
    if as_json:
        print(json.dumps(data["totals"], indent=1))
    return 0
