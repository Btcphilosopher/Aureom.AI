# 04 — Integration: ports, wrappers, address map

## The DPU's ports (`silicaflux_cloud_dpu`)

| Group | Ports | Protocol |
|---|---|---|
| clock / reset / RAS | `clk`, `rst_ni`, `test_mode`, `boot_mode_i[1:0]`, `host_rst_req_i`, `ext_warn_i`, `ext_fatal_i`, `ras_fatal_o` | one functional clock `clk`; `rst_ni` active low, asynchronous assert / synchronous release (synchronised inside the ControlCore, bypassed in `test_mode`) |
| host management | `hs_req_*`, `hs_rsp_*`, `host_irq_o`, `host_ready_o`, `cmdproc_ready_o` | ControlCore host access port (ready/valid request/response, word access) |
| VirtualIO | `vio_sub_valid/ready/q/cmd` (one shared submission bus, 384-bit descriptor), `vio_cpl_valid/ready/data` (one 256-bit completion port **per host queue**) | ready/valid, payload held until taken |
| CloudDMA host memory | `hm_req_*`, `hm_rsp_*` (`ADDRESS_WIDTH`, `DATA_WIDTH`) | **SFB2** (DataFabric): one outstanding request, response never in the acceptance cycle |
| CloudTelemetry | `tlm_valid/ready/data` (80-bit event) | ready/valid; drops-and-counts when not consumed |
| diagnostics | `diag_*` (console characters), `test_done_o/test_fail_o/test_code_o`, `cpu_sleep_o`, `dpu_busy_o`, `dpu_irq_event_o/fault_o` | observation only |

The submission bus is **one physical bus shared by all queues** (`vio_sub_q` selects the queue, as a PCIe function
selects its own virtual function). A host model that drives several queues from concurrent threads must take turns on
it — the system testbench's lock for exactly this (`sub_busy`) was missing in the first version of the `multi` and
`isolation` scenarios, and the resulting "queue 0 never completes" was a testbench defect, not an RTL defect.

## Parameters

See `docs/01_ARCHITECTURE.md` §2. Illegal combinations (any `ENABLE_*` = 1, 0 queues, > 15 queues, > 16 tenants, odd
data width, …) are **elaboration errors** with a readable generate-block name; the lint driver proves each one is
refused (`reports/lint.md`, "negative elaboration").

## Wrappers (`integration/`)

| File | What it is | Status |
|---|---|---|
| `silicaflux_cloud_dpu_axi.sv` | the DPU with an **AXI4 master** (`m_axi_*`, single-beat, ID 0, `AxLEN = 0`) instead of the SFB2 host-memory port — the boundary at which a PCIe endpoint IP / HostLink (Project 25) or an AXI interconnect attaches | Verilator `-Wall` clean (0 warnings) |
| `sfd_sfb2_to_axi4.sv` | the bridge itself | unit-verified: 600 random reads/writes (with byte strobes and an error window) against an AXI slave model with random channel delays, 601 checks, 0 fails; Yosys `check` clean |

The full DPU regression runs on the SFB2 port. The AXI wrapper is therefore covered by *the bridge test plus the DPU
tests*, **not** by a separate in-system regression (listed in `docs/07_LIMITATIONS.md`).

## Address map

Generated from `config/dpu_memmap.yaml` (the single source of truth) by `scripts/gen_dpu_memmap.py`:

| Output | Used by |
|---|---|
| `rtl/pkg/silicaflux_cloud_memmap_pkg.sv` | RTL, testbench |
| `firmware/include/generated/dpu_memmap.h`, `dpu_abi.h` | firmware (`dpu_abi.h` takes its opcode/error/layout constants from `silicaflux_cloud_pkg.sv`) |
| `docs/DPU_MEMORY_MAP.md` | people |

`make check-map` fails if any generated file is stale and runs 13 negative tests of the validator (misaligned or
overlapping registers, array overruns, duplicate names/ids, …) — each illegal map must be rejected.
