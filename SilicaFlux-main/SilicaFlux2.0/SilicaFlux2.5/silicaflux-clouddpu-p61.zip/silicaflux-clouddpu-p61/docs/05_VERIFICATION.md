# 05 — Verification

> Numbers in this document are copied from the generated reports (`reports/regression.md`, `reports/mutation.md`,
> `reports/lint.md`, `reports/unit/summary.txt`, `reports/synth/SUMMARY.md`), which are written by the scripts from
> real runs. Re-run with `make all`. Nothing here is a hardware result.

## 1. Approach

* **Minimum first.** The minimum configuration (1 tenant, 1 network queue, 1 DMA channel, 32-bit, 1 clock) was brought up
  and its whole scenario set passed *before* a second tenant / queue / DMA channel / wider datapath was built and
  regressed. The advanced blocks (tensor, crypto, storage) are not built at all (`ENABLE_* ≠ 0` is an elaboration error).
* **Independent checking.** The testbench (`tb/tb_dpu.sv`, `tb/dpu_tests.svh`) acts only as the *simulated host* and
  checks with models that do not share code with the RTL:
  * a **software reference model** of the PacketCore test adapter (transform, CRC-32, RFC 1071 checksum);
  * a **scoreboard** keyed by *(queue, tag)* — every completion must match the expected status, error code, byte count,
    CRC, checksum, queue and tenant; completions may be out of order; nothing may complete twice or not at all;
  * a **shadow image of host memory** compared *at the moment each completion is received* (so a completion that
    overtakes its output commit finds stale bytes) and again at the end of every scenario;
  * an **independent permission monitor** on the host port that rejects any access outside the union of granted
    windows (and, with one DMA channel, outside the windows of the tenant that is executing);
  * **SRAM back-door checks** of partitions and scrubbing; **CRC cross-check** against SecureStore's `sfsec_crc`;
  * **SystemVerilog assertions** (`rtl/dpu/sfd_assertions.sv`, simulation only) running in every scenario:

    | | property |
    |---|---|
    | H1 | SFB2 R2 — a host-memory request is held unchanged until accepted |
    | H2 | SFB2 R5 — no response in the cycle a request is accepted |
    | Q1 / Q2 | a presented completion is held until taken / a queue's port only carries that queue's records |
    | T1 | a presented telemetry event is held until taken |
    | C1 | an OK completion of a host-writing operation carries the COMMITTED flag (and a failed command never does) |
    | C2 | a completion never finds its queue full (credits) |
    | D1 / D2 / D3 | nothing is dispatched while disabled / more than one start per cycle / while halted or resetting |
    | S1 / S2 | no job of a tenant executes while its SRAM is scrubbed / a timed-out slot still counts as in flight |

* **Defence in depth is tested separately.** `tb/tb_guard_unit.sv` drives the job slot and PacketCore hub *without* the
  command processor with transactions it would have refused, and requires the per-beat guards alone to stop every one
  (zero forbidden host accesses, zero SRAM bytes changed outside the owner's partition).
* **The real firmware runs on the real RTL CPU** (scenario `fw`): boot ROM → host-loaded image → CRC check → POST →
  tenant configuration → firmware self-test (133 checks) → commands → fault report → recovery → shutdown, with the
  testbench independently recomputing host memory after every firmware-driven command.

## 2. Scenarios (brief §9)

| Scenario | What it covers |
|---|---|
| `reset` | reset values of every register, idle interfaces, queued work cleared by a host reset |
| `boot` | bring-up sequence, identification, configuration, first transfers |
| `mmio` | register access rules: word-only, read-only, W1C, unmapped offsets, bus errors |
| `decode` | every descriptor validity rule and every refusal code (30 commands: opcode, reserved fields, length, alignment, tenant, state, windows, SRAM range, engine classes blocked) |
| `mgmt` | the management queue and the SRAM window of the ControlCore |
| `data` | data transfer: PKT_PROCESS (3 transforms), DMA H2D/D2H, random lengths incl. partial last beats, 103 commands, host memory compared at every completion |
| `stress` | long random traffic with back-pressure/latency variants (seeded) |
| `saturation` | queue and completion-queue saturation: only the saturated queue stops |
| `errprop` | host-memory errors injected on read and on write propagate to completions, faults and counters |
| `telemetry` | every event, ordering, drop-and-count when the consumer stalls |
| `perf` | every performance counter against an independently computed expectation; freeze/clear |
| `multi` | several queues / DMA channels / tenants at once, memory conflicts observed |
| `isolation` | two tenants side by side, configuration rules (overlap refusals), then tenant 0 *attacks* tenant 1 (every attempt refused, nothing of tenant 1 changes), quarantine → recover → re-enable with the other tenant unaffected, and *the queue binding — not the descriptor's tenant field — decides the tenant* |
| `recovery` | job watchdog, halt, DP_RESET, orphaned host response, host reset under traffic |
| `geometry` | the data and stress scenarios on 64- and 128-bit datapaths |
| `fw` | the firmware system scenario above |

## 3. Defects found by verification (and what each was)

Honest accounting — none of these was hidden by weakening a check.

| Found by | Defect | Kind | Fix |
|---|---|---|---|
| `fw` (first RTL run of the firmware) | POST submitted a command before enabling dispatch; timed out; all later completions read one record stale (44 firmware + 22 host-side check failures) | **firmware** | enable dispatch first |
| `tb_layout_check` | stray field in the testbench transaction struct made the struct view disagree with the RTL flat offsets | package (testbench view) | removed the field |
| `perf` rerun | host-memory shadow not updated for a D2H of staged data | testbench | shadow updated |
| `recovery` | left a 400-cycle job timeout active, so a legitimate post-reset transfer timed out | testbench | timeout restored |
| scenario development | reading a non-existent queue returned zeros silently | RTL (spec gap) | bus error |
| lint / maximum-geometry review | `NT[3:0]` / `NW[2:0]` truncation at 16 tenants / 8 windows | RTL (latent at the maximum geometry) | wider compares |
| scenario runs | tenant in-flight decrement lost when a dispatch and a completion coincide; zombie double-clear | RTL | combinational inc/dec vectors |
| multi-config regression | `multi`/`isolation` forked two traffic generators onto the one shared submission bus; queue 0's descriptors were overwritten ("never completed") | **testbench** | bus lock |
| multi-config regression | `perf` reused one SRAM staging buffer and relied on H2D-then-D2H order, which concurrent DMA slots do not guarantee | **testbench** (stimulus; ordering is documented) | serialised when `NS > 1` |
| multi-config regression (second run: 4 of 55 runs, one command each, only under timing variation) | `rand_traffic` rotated 4 SRAM staging buffers and 8 destination slots assuming "at most `NS` commands overlap in time"; with out-of-order slots one slot can finish several short commands while the other still runs a long one, so command *i+4* reused command *i*'s buffer while *i* was still staged (the tenant raced against itself; wrong input CRC on exactly that command) | **testbench** (stimulus; the RTL behaved as documented — staging is the submitter's job) | the generator waits until the previous owner of a staging range / destination slot has completed (`staging_busy`) |
| mutation campaign, first run (19 / 20 killed) | mutant **M20** (scrubber does not re-issue a write lost to a data-plane reset) **survived**: no scenario issued `DP_RESET` while a tenant was being scrubbed, so the lost-write path in `sfd_tenant_ctx` was untested. A first attempt (one reset instant) still survived — the scrubber's write pattern is periodic, so one instant lands at one fixed phase | **test hole** (the RTL was right) | `recovery` now resets the data plane in the middle of a scrub at 8 consecutive cycle offsets and requires the scrub to finish, the partition to read zero and the tenant to be re-enabled; M20 is then killed (tenant stuck in `SCRUBBING`) |
| multi-config regression | `recovery` used a 4-byte-aligned offset on 64/128-bit datapaths (refused `ERR_ALIGN` — the RTL was right); `geometry` re-committed a live tenant (`CFG_BUSY` — the RTL was right) | **testbench** | aligned offset; reset between phases |

Two lessons worth keeping: (1) all five classes of multi-configuration failure were *testbench* defects, and two of them
(alignment, `CFG_BUSY`) were the RTL correctly refusing a bad stimulus — the checks caught the testbench, which is what they are for; (2) the firmware defect would have been invisible
without running the real firmware on the real CPU.

## 4. Results

### 4.1 System regression — `reports/regression.md` (generated by `scripts/regress.py`)

**55 / 55 runs passed**, in five separately built configurations (each a different Verilator build; geometry is a compile-time property):

| Config | Geometry | Runs | Passed | Checks | Commands submitted |
|---|---|---:|---:|---:|---:|
| `min` | **minimum DPU**: 1 tenant, 1 network + 1 compute queue, 1 DMA channel, 32-bit data / address, 1 bank | 16 | 16 | 4 703 | 454 |
| `mt` | 2 tenants, 2 network queues, 2 DMA channels, 2 banks, 32-bit | 17 | 17 | 4 851 | 469 |
| `w64` | 1 tenant, 2 queues, 2 DMA channels, **64-bit data, 40-bit address** | 12 | 12 | 4 620 | 427 |
| `w128` | 4 tenants, 4 + 2 queues, 3 DMA channels, **128-bit data, 64-bit address**, 4 windows, 4 banks, 128 KiB | 9 | 9 | 5 062 | 470 |
| `fw` | minimum geometry **plus the real firmware on the real CPU** | 1 | 1 | 70 (+ 133 in the firmware) | — ¹ |
| | | **55** | **55** | **19 306** | |

¹ Commands issued by the firmware go through the *management* queue; the testbench's host-queue scoreboard counters
therefore read 0 for `fw`. Its checks are the 70 testbench checks (host memory recomputed independently after every
firmware-driven command, identification, boot stages, write lock, fault report, recovery, test pins) and the firmware's own
133 self-test checks, all passing (`FW| SHUTDOWN: firmware checks=133 fails=0, host-reported fails=0 -> PASS`).

Several scenarios are run again with different seeds / host back-pressure / completion back-pressure / latency
(`+bp`, `+cbp`, `+lat`, `+seed`); every variant is its own row. A `PASS` requires the simulator's exit status 0, the
line `TB RESULT PASS` (zero failed checks) and no assertion firing.

### 4.2 Other reports

| Report | Result |
|---|---|
| `reports/unit/summary.txt` — `make unit` | layout check 60/60; CRC cross-check against SecureStore `sfsec_crc`: 401 random messages, 402 checks; **guard unit** (per-beat guards without the command processor): 36 checks; AXI bridge: 600 transactions, 601 checks — **0 failures** |
| `reports/lint.md` — `make lint` | Verilator `-Wall`: 6 DPU + 2 AXI-wrapper configurations with **0 warnings**; 15 illegal parameter sets all refused at elaboration — **23 checks, 0 problems** |
| `make check-map` | 4 generated files not stale; address-map validator: 13 negative cases + the real map, 0 problems |
| `make check-vendor` | 80 vendored files byte-identical to their recorded SHA-256 |
| `reports/synth/SUMMARY.md` — `make synth` | generic Yosys synthesis of 5 configurations, 0 latches, 0 `check` problems (`docs/06_SYNTHESIS.md`) |
| `reports/tools.txt` | Verilator 5.020, Yosys 0.33, Icarus 12.0, riscv64-unknown-elf-gcc 13.2.0, Python 3.13 / PyYAML 6.0.3 |

### 4.3 Mutation campaign — `reports/mutation.md` (generated by `scripts/mutate.py`)

`scripts/mutate.py` injects **one deliberate RTL bug at a time** into a *copy* of the RTL (the project tree is never
modified), builds a bench, and runs it. A mutant is **killed** when a check, an assertion or a timeout fails; a survivor
is a hole in the tests (or an equivalent mutant) and would be listed as such.

**Final run on the shipped testbench: 20 of 20 mutants killed.** (Run 1 killed 19 of 20 — see §3: M20 survived and exposed
a real test hole, which was then closed and the *whole* campaign re-run.)

| Area | Mutants (all killed) | First detector |
|---|---|---|
| Commit before completion | M01 completion on issue instead of acknowledge; M13 partial last beat writes the whole word | testbench: completion byte count, host-memory image vs. shadow |
| Permission enforcement | M02 per-beat host guard permits all; M06 SRAM guard off by one beat; M15 refused request not answered with an error | **guard unit bench** (without the command processor) |
| | M03 host-read window unchecked; M14 write permission ignored; M19 SRAM range unchecked | testbench decode / permission monitor |
| Tenant isolation | M04 descriptor tenant claim not checked against the queue binding; M07 violating tenant not quarantined; M05 teardown skips the scrub; M18 completions leak to queue 0 | testbench; **assertion Q2** for M18 |
| Queues / credits / counters | M09 completion credits ignored; M16 W1C inverted; M17 byte counter wrong; M08 CRC polynomial wrong | **assertion C2** for M09; testbench for the rest |
| Reset / recovery | M10 tenant in-flight counter never decremented; M11 orphaned host response delivered to the next owner; M12 timeout does not halt dispatch; M20 scrubber does not re-issue a write lost to a data-plane reset | testbench (`boot`, `recovery`) |

Caveats: 20 mutants are a *sample* of the bug space, not a coverage metric; the system mutants run the *reduced* scenario
set of the minimum (9 scenarios) or two-tenant (4 scenarios) configuration; the report records the *first* failing check
and does not say which other independent checks would also have fired.

### 4.4 What the evidence does *not* cover

See `docs/07_LIMITATIONS.md`. In particular: simulation only; the permission monitor can only check the union of granted
windows when several DMA slots are active (the *per-tenant* property under concurrency rests on the guard unit bench and
the per-beat guards, not on the system monitor); fixed seeds; the larger configurations run fewer scenarios than the
minimum one.

