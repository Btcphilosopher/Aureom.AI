# 03 — ControlCore integration, boot and control firmware

The management plane is the **ControlCore** (Project 21), vendored **unmodified** under `third_party/`. Nothing in it
was changed; the DPU attaches to the three extension points it already offers:

| ControlCore hook | What the DPU puts there |
|---|---|
| accelerator register port, `PERIPH` pages 8..15 (`0x4000_8000..0x4000_FFFF`) | the eight DPU register regions (`docs/DPU_MEMORY_MAP.md`) |
| EXT window `0x2000_0000..` | the DPU local SRAM (through `sfd_mgmt_adapter`, a fabric master) |
| two accelerator interrupt inputs (INTC sources "VECTOR", "TENSOR") | `DPU_EVENT` (management completion queue not empty) and `DPU_FAULT` (`FAULT_STATUS & FAULT_ENABLE`) |
| RAS `ext_warn` / `ext_fatal` inputs | `FAULT_WARN` / `FAULT_FATAL` masks of the DPU fault register |
| PMU clock gate `acc_clk_o` / `acc_rst_no` | the DPU's clock and (persistent-domain) reset |
| host access port `hs_*`, mailbox, `host_irq_o` | the host's management channel (the *physical function* of this device) |

The register-bus contract of the accelerator port (one-cycle `rb_sel` strobe, combinational read data, side effects at
the end of the strobe, word-only writes) is honoured by every register page (`sfd_regs`, `sfd_tenant_ctx`,
`sfd_cmdq`, `sfd_perf`, `sfd_tlm`); `tb` scenario `mmio` checks byte-strobe refusal, unmapped offsets and read-only
registers.

## Boot sequence

```
reset ──► boot ROM (vendored)  WAIT_IMAGE ◄── host writes the firmware image into IMEM through hs_*
                               image header + CRC32 check  (integrity only; NOT authenticated)
          ──► firmware _start (crt0, vendored) ──► main()
              FW_INIT         reset cause, FW version, console, trap/interrupt setup (INTC, RAS)
              ACC_DISCOVERY   read ID ("SFDP"), ABI major, CONFIG0/1, SRAM_BYTES, BLOCK_STATUS.
                              Mismatch ⇒ BOOT_ERROR, no host-ready.
              SELF_TEST       dispatch enable, then POST (below)
              CMDPROC_READY   host write lock (SECURITY.CTRL) set: the host can no longer write IMEM/DMEM/ROM
              HOST_READY      identification published in the mailbox; host told
          ──► sleep (WFI) until a mailbox command arrives
```

There is **no Linux** and no operating system: the firmware is freestanding C (`-nostdlib`, only `libgcc`), 10 656 bytes
(16 % of the ControlCore instruction memory), built with `riscv64-unknown-elf-gcc` 13.2 for `rv32im_zicsr_zifencei`.

**Power-on self-test.** One management-queue round trip *by interrupt*: a `NOP` for a tenant that has not been
configured must come back `ERR_TENANT_STATE`, with the `DPU_EVENT` interrupt delivered and the tag echoed. That proves
register access, the command path, the completion queue, the interrupt wiring *and* the isolation rule ("nothing runs for
an unconfigured tenant") before any tenant exists.

> **A defect this firmware had and the RTL run found:** the first version of the POST submitted that `NOP` *before*
> enabling dispatch (`CTRL.EN`). The command correctly waited in the queue (D1: nothing is dispatched while `EN = 0`), the
> POST timed out, and — worse — every later completion read came back one record stale. It was invisible until the real
> firmware ran on the RTL CPU (scenario `fw`, first run: 44 firmware checks failed). Fix: enable dispatch before the POST;
> safe, because the command processor refuses every command of a tenant that is not ACTIVE. Scenario `fw` now passes.

## Host command interface (mailbox)

| Code | Command | Arguments → response |
|---|---|---|
| `0x40` | `DPUCMD_INFO` | → ID, ABI version, CONFIG0/1, SRAM bytes, BLOCK_STATUS, FEATURES |
| `0x41` | `DPUCMD_CONFIG` | tenant, host in-window base, SRAM partition size → CFG status, tenant state. Programs partition + two windows, `COMMIT` (validation, overlap checks, **scrub**), `ENABLE`; turns on dispatch and fault reporting |
| `0x42` | `DPUCMD_SELFTEST` | group mask → checks, fails (groups: ID, MMIO, PKT, ERR, PERM, PERF, RESET, IRQ) |
| `0x43` | `DPUCMD_SUBMIT` | op / proc-op / tenant, tag, src, dst, length, SRAM offset, param → completion words 0..6 (management queue, trusted) |
| `0x44` | `DPUCMD_FAULTS` | → fault bits, count, last tenant, last error, last address, fault IRQ count |
| `0x45` | `DPUCMD_PERF` | → accepted, retired, errors, DMA bytes read/written, violations |
| `0x46` | `DPUCMD_RECOVER` | tenant, or `0xFF` for a data-plane reset → tenant state / reset count |
| ControlCore | `PING`, `SHUTDOWN` | standard ControlCore mailbox commands |

Response word 0 = `status | cmd << 8 | seq << 16`; `F2H` is rung when the response is complete.

## Interrupts, faults, configuration, device identity

* **Interrupts are level sources acknowledged at the source.** `DPU_EVENT`'s ISR masks it (`IRQ_ENABLE`) until the
  consumer has popped the record; `DPU_FAULT`'s ISR accumulates the sticky bits and the last-fault capture
  (tenant, error, address) and clears them with write-1-to-clear, which drops the level.
* **Fault reporting.** `CONFIG` enables `FAULT_ENABLE = PERM_VIOL | HOST_ERR | DESC_ERR | TIMEOUT` (→ `DPU_FAULT`) and
  `FAULT_WARN = PERM_VIOL | TIMEOUT` (→ ControlCore RAS warning). A quarantined tenant is recovered by the firmware's
  `RECOVER` (drain → scrub → re-enable).
* **Device ID.** `DPU_G_ID = 0x53464450` ("SFDP"), ABI 1.0, configuration words, and `BLOCK_STATUS` — two bits per block
  (`ABSENT / BLOCKED / TEST_ADAPTER / REAL`) so software can see which blocks are real.
* **Configuration.** All tenant configuration is *shadow registers + `COMMIT`*, refused unless the tenant is `DISABLED`.

## What the firmware self-test proves (and what it does not)

`DPUCMD_SELFTEST` runs on the ControlCore CPU **on the RTL**, in 8 groups, 133 checks. It checks completion records,
the SRAM contents (read back through the EXT window and compared with a **C reference model** of the PacketCore test
adapter: transform, CRC-32, RFC 1071 checksum), and interrupt delivery. It cannot see host memory — the testbench owns
that and checks it independently in scenario `fw` (`tb/dpu_fw_test.svh`): after each firmware-submitted command the
testbench recomputes the expected host-memory image and compares it, so the firmware's word is never taken on trust.

## Rebuilding

```bash
make fw          # firmware/build/dpu_fw.{elf,img,hex,json}; rebuild after any change to the package or the memory map
```
