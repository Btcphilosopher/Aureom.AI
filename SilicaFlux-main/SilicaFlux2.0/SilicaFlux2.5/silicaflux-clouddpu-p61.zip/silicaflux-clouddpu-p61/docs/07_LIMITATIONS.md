# 07 — Limitations, non-claims and follow-on work

This is a **simulation-verified RTL design**, not silicon, not a board result and not a product. Read this before
relying on anything else in the package.

## Not implemented (clearly marked, not hidden)

| Item | State | How software / the design sees it |
|---|---|---|
| **PacketCore** | does not exist in the repository | `sfd_packetcore_tadapter` is a **TEST ADAPTER** (PASS / XOR32 / BSWAP32 on a staged buffer + CRC-32 + RFC 1071 checksum). It parses no packets. `BLOCK_STATUS = TEST_ADAPTER` |
| **VirtualIO** | does not exist | only the queue ports exist; the host side is a testbench model. No virtio rings, no SR-IOV, no MSI-X |
| **InferenceScheduler / TensorCore, CryptoCore, StorageFabric** | not integrated, not verified | `ENABLE_*` must be 0 (elaboration error otherwise); the engine opcodes complete with `ERR_BLOCKED`; `BLOCK_STATUS = BLOCKED` |
| **CloudTelemetry consumer** | does not exist | the event port and counters are real; a testbench model consumes them |
| Network MAC/PHY, **PCIe endpoint**, IOMMU / PASID, Linux driver | out of scope | The DPU's own per-beat window check is its only host-address protection |

## Verification boundaries

* **RTL simulation only** (Verilator 5.020, `-O0` C++). No FPGA, no silicon, no gate-level simulation, no formal proof
  of the DPU's own properties (the *reused* blocks carry their own formal evidence from their own projects; none was
  re-run here). The SVA checkers are simulation assertions, not proofs.
* Icarus 12 is installed but is **not** used for the system testbench (it needs SVA and classes); Yosys 0.33 has no
  concurrent-assertion frontend, so assertions live in a sim-only module outside the synthesis list.
* The mutation campaign samples 20 injected bugs, not the space of all bugs; a survivor list is in `reports/mutation.md`.
* The AXI wrapper is verified at bridge level only (`tb_axi_bridge`) and lint level; the DPU regression runs on SFB2.
* The clock-gated path is bypassed (`SFV_NO_CLOCK_GATE`) in every simulation and in synthesis.
* Random stimulus uses fixed seeds; the regression is deterministic and **reproducible**, which also means it is a finite
  sample. Larger configurations have fewer scenarios than the minimum one (see `reports/regression.md`).
* The firmware self-test and the testbench were built by the same author as the RTL; the independent elements are the
  reference models (C model of the PacketCore adapter, SecureStore's CRC, an independent permission monitor, the host-memory
  shadow image) — not a second team.

## Design limits

* **One outstanding transaction per SFB2 port**, single-beat host transfers: the minimum DPU trades bandwidth for
  provable simplicity. No throughput or latency figure is claimed anywhere in this package (the performance counters are verified for
  *correctness*, not used to benchmark); expect it to be far below a real DPU's.
* **No ordering between commands of one queue when `NUM_DMA_CHANNELS > 1`.** They may run in parallel and complete out
  of order (tag identifies them, like an NVMe completion queue). A tenant that needs ordering waits for the completion
  or uses disjoint SRAM staging buffers. (The `perf` scenario had to be serialised for exactly this reason.) This is
  *within* a tenant: it cannot affect another tenant's data.
* **The management plane is trusted** (ControlCore firmware + the host that reaches `hs_*`): it can reconfigure
  tenants, read the whole SRAM and submit for any tenant. Tenants (virtual functions) have only their queue and
  completion ports.
* **No secure boot:** the firmware image is CRC-32-checked, *not authenticated* (inherited from the ControlCore; the
  firmware prints "integrity only, NOT authenticated").
* **No side-channel claims:** the SRAM banks, the fabric and the single PacketCore adapter are shared; latency is observable.
  No denial-of-service guarantee beyond round-robin arbitration and per-queue completion credits.
* One tenant's violation quarantines *that tenant* (policy bit, default on); the data plane keeps serving others.
  A **job timeout halts dispatch for everyone** until firmware issues `DP_RESET` (a stuck host memory cannot be told
  apart from a stuck slot) — deliberate, simple, and a shared-fate limit.
* No ECC on the local SRAM (the RAS project's ECC slave is a drop-in follow-on); no DVFS (`PowerClock` is not integrated).
* No license file (see `third_party/PROVENANCE.md`).

## Follow-on work, in a sensible order

1. Real VirtualIO front end on HostLink (Project 25) + a PCIe endpoint; in-system regression of the AXI wrapper.
2. Replace `sfd_perf` by the validated HPC M07 counter bank (adds its formal evidence) — noted in `00_AUDIT.md`.
3. Burst transfers / more outstanding requests; measure bandwidth against a real memory model.
4. ECC SRAM slave (RAS project), then CryptoCore (a GCM-class core; SecureStore's XTS/CMAC are storage-oriented), then
   enable one advanced block at a time, **each verified in isolation before the next** (the order the brief demands).
5. Formal proofs of the isolation properties (`S1`, `S2`, `Q2`, `C1`) and an FPGA place-and-route on the established ECP5 flow.
