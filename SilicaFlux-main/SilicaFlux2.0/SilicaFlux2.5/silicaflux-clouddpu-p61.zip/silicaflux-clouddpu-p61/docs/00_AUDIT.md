# 00 — Repository audit (Project 61, SilicaFlux CloudDPU)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/silicaflux-clouddpu-arch-42qdjs`, HEAD `d013575`. As in the earlier
SilicaFlux projects, the RTL lives almost entirely inside zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. **All 92 archives were extracted** (read-only, in a scratch directory)
and the 12 areas named in the brief were inspected; the findings cite the archive.

How the evidence was gathered — and how far to trust it:

* **Re-run here:** the ControlCore system scenario `boot_host` (firmware build with the GNU toolchain, Verilator 5.020
  system simulation): *231 firmware checks, 0 fails, `TB RESULT PASS`, 2 791 325 cycles* — the same numbers the
  ControlCore README claims. This confirms the toolchain and the reused CPU/boot ROM work in this environment.
* **Verified byte-for-byte:** every file vendored into `third_party/` equals its archive member
  (`scripts/check_vendor.py --repo <Aureom.AI>`: 80 files, 0 differences). Nothing vendored is edited.
* **Taken from the projects' own reports (not re-run here):** the verification counts quoted below for DataFabric,
  SRAM library, SecureStore, etc. The report files were opened and the numbers re-added; no README-vs-report
  disagreement was found. Each number is simulation/formal evidence *of that project*, never a hardware result.
* **Spot-checked:** the facts about `sfsec_crc` (ports, modes), the HPC-tile "minimal" command queue and the absence of
  FPGAFlow were checked directly; a first-pass fact sheet was produced by a read-only sub-agent and the claims this
  project depends on were verified against the sources.

## 1. What exists, what is reusable, what was decided

| Area (brief) | Found | Evidence recorded by that project | Decision for the DPU |
|---|---|---|---|
| **ControlCore** (P21) | `silicaflux_control_core`: RV32IM_Zicsr CPU (`mcu_cpu`, from MCU-I), 8 KiB boot ROM, 64 KiB I / 32 KiB D SRAM with parity, SFB2 crossbar, INTC (16 sources), timer, WDT, system DMA, mailbox + host console, perf counters, PMU (clock gate), RAS, security status; pages 8..15 of its register window forwarded to an "accelerator register port"; 512 MiB EXT window | system regression 6/6, firmware self-test 231/231, host checks 107/107, riscv-tests 63/63, lint 0 warnings; **no RISC-V compliance claim; no firmware authentication (CRC32 only)** | **Reused unmodified** as the management plane. DPU registers sit on its forwarded pages 8..15, DPU SRAM behind its EXT window, DPU interrupts on its two accelerator interrupt inputs. Re-run here: 231/231. |
| **DataFabric** (P03) | SFB2 protocol, `sfb_crossbar`, arbiters, register slice, `sfb_sram_slave`, DMA engines | unbounded proofs for the interconnect, bounded for the DMA, gate-level sim, SoC firmware | **Reused unmodified**: `sfb_crossbar` is the DPU's internal fabric and the host-port multiplexer; `sfb_sram_slave` fronts the SRAM banks. Its protocol rules R1–R12 govern every DPU port. |
| **DataFabric-NoC** (P22) | SFB3 shared-bus / crossbar / mesh with QoS, FENCE ordering | 782 regression runs, 38/38 formal, mutation 35/35 | Not used: with ≤ 8 masters the P03 crossbar is the NoC project's own recommended baseline. Candidate for a later multi-DPU scale-out. |
| **SRAM Wrapper Library** (P01) | `sram_sp` + generic / FPGA / ASIC-macro backends | lint, sweep, mutation, formal (bounded), cross-simulator | **Reused unmodified**; the DPU uses the generic backend (`DPU_SRAM_BACKEND`); the ASIC macro adapters (SKY130/GF180/IHP) are one parameter away. |
| **Cloud DMA** | **None exists.** DMA parts: DataFabric `silicaflux_dma` (single channel), HPC M05 `hpc_dma_adapter` (wraps the DataFabric engines; needs the M04 scratchpad port protocol; 684/684 runs), StorageCore `sfs_dma` (one outstanding, aligned), BufferCore `sfsb_eng_h2b/b2h` (not standalone), HostLink `sfh_engine` (tied to TensorCore dispatch) | as listed | **New `sfd_clouddma`** (native to this project): host memory ↔ local SRAM with per-beat guards, partial last beats and an explicit commit flag. M05 was not reused: its scratchpad port and tag protocol would have needed a translation layer *and* would not provide the per-beat tenant guard. See §3. |
| **Storage DMA** | StorageCore P51 has `sfs_dma`; P57 NVMe host core only a PRP window; P55 buffer engines | P51: SoC 4/4, unit 6/6, ~18 k LUT4; **not NVMe/ONFI compliant, no GC** | `ENABLE_STORAGE` stays **blocked**. P51's DMA is a template only. |
| **Vector Engine** (HPC M02/M03/M08) | FP32 lane (132/132), vector array (1632/1632, vs SoftFloat), tile with DMA/command queue (145/145) | ECP5 55 992 / 83 640 comb; one nextpnr result for M03 | Not in the minimum DPU. M08 contains its own *minimal* 100-line `hpc_command_queue` / 57-line `hpc_perf_counters` that are **not** the validated M06/M07 modules (same names, different ports). |
| **TensorCore** (TC01–TC10) | INT8 4×4 array, TC08 unit: 111/111, 642 GEMMs, C-driver co-sim | single clock, SFB2 master + `rb_*` page; one command at a time; no hardware run | `ENABLE_TENSOR` stays **blocked**: no InferenceScheduler exists, and integrating a compute engine into a multi-tenant data plane (per-tenant partition/window enforcement on the tensor DMA) is not verified. |
| **SecureStore** (P59) | AES (third-party secworks) + XTS/CMAC/KDF/**CRC** (original), 29 940 + 10 233 + 490 checks, 28/28 mutants | **not Yosys-checked** (its README: Verilator ≥ 5.040 only); not FIPS/CAVP; AES iterative (~53 cycles/block); wiring to ControlCore "not done" | `ENABLE_CRYPTO` stays **blocked** (XTS/CMAC are storage-oriented, no GCM). `sfsec_crc` (CRC-32 IEEE, mode 1) is used as the **independent golden CRC in verification** (`tb/tb_crc_xcheck.sv`): the datapath uses own `sfd_crc32` because `sfsec_pkg.sv` uses `return`, which the baseline Yosys 0.33 flow rejects (checked) and vendored files are never edited. |
| **PowerClock** (P27) | power manager + thermal monitor; APB slave, two async clock domains, CDC | 107 runs, 0 failures; no DVFS (`CAP.DVFS = 0`); thresholds are placeholders | Not integrated (APB, 2 clock domains); the DPU uses the ControlCore's PMU / clock gate. |
| **RAS** (P26) | SECDED, ECC SRAM, scrub, watchdog, thermal, fault injection; `sfras_sfb_ecc_slave` is a drop-in for `sfb_sram_slave` | 39/39 runs, mutation 22/22, lint 24/24 | Not in the minimum configuration (generic SRAM without ECC). The ECC slave is the obvious next step for the DPU SRAM. DPU faults feed the ControlCore RAS block through its warning/fatal inputs. |
| **PCIe host bridge** (HostLink P25) | NVMe-style SQ/CQ in host memory, descriptor engine, BAR ABI, **AXI** endpoint boundary; simulated host model | 144/144 co-sim, mutation 26/26; **no PCIe protocol logic, physical PCIe blocked** | Not integrated. The DPU's host-facing ports are plain ready/valid (see §3); HostLink is the natural real VirtualIO front end once a PCIe endpoint exists. |
| **Performance counters** (HPC M07) | generic counter bank, CDC counter, snapshot/freeze; formal A1–A7, mutation 46/46 | "Overall: PASS" | Not reused: the DPU needs 16 global + per-tenant 64-bit event counters with a LO/HI latch protocol; **new `sfd_perf`** was written instead. Honest caveat: M07 could have been adapted; replacing `sfd_perf` by it is a clean follow-up that would add its formal evidence. |
| **FPGAFlow** | **No project, file or directory with that name exists** (searched all 92 archives). The existing practice is per-project open-tool flows on the ULX3S (ECP5 LFE5U-85F, 25 MHz): Yosys `synth_ecp5` + nextpnr-ecp5 + ecppack, e.g. `silicaflux-controlcore/fpga/build.sh`. | no bitstream anywhere has run on a board | **Not run for the DPU** (no place-and-route was attempted). Generic Yosys synthesis only (`docs/06_SYNTHESIS.md`). |

## 2. Modules that do **not** exist (and what stands in for them)

| Brief item | Status | What this project provides |
|---|---|---|
| PacketCore | does not exist | `sfd_packetcore_tadapter` — a clearly named **test adapter**: PASS / XOR32 / BSWAP32 on a staged buffer plus CRC-32 and RFC 1071 checksum. `BLOCK_STATUS` reports `TEST_ADAPTER`. It is not a packet parser. |
| CloudDMA | does not exist | **implemented** (`sfd_clouddma`), verified here |
| VirtualIO | does not exist | the queue ports `vio_sub_*` / `vio_cpl_*` are the interface; the host side is a testbench model (`TEST_ADAPTER`); no virtio ring parsing, no SR-IOV, no IOMMU |
| InferenceScheduler | does not exist | compute-class queues exist; `OP_INFER` is refused with `ERR_BLOCKED` (`BLOCKED`) |
| CryptoCore | does not exist | `OP_CRYPTO` refused with `ERR_BLOCKED` (`BLOCKED`) |
| StorageFabric | does not exist | `OP_STORAGE` refused with `ERR_BLOCKED` (`BLOCKED`) |
| CloudTelemetry | does not exist | the `tlm_*` event port and the counters are implemented; the consumer is a testbench model |
| Network MAC / PHY, PCIe endpoint IP, IOMMU, SR-IOV, secure boot (P28 absent for the ControlCore), Linux driver | do not exist | out of scope; listed as follow-on work in `docs/07_LIMITATIONS.md` |

`ENABLE_TENSOR`, `ENABLE_CRYPTO`, `ENABLE_STORAGE` are parameters with value 0 and **setting any of them is an
elaboration error** until the block exists *and* is individually verified.

## 3. Why the interfaces look the way they do

* One protocol everywhere: **SFB2** (DataFabric) for every internal master/slave and for the host-memory port, so the
  whole data plane inherits a documented, formally-checked handshake (R1–R12). One outstanding transaction per port: the
  minimum DPU trades bandwidth for provable simplicity (no throughput figure is claimed).
* The ControlCore is not modified. Its two *accelerator interrupt* inputs carry `DPU_EVENT` / `DPU_FAULT` (INTC sources
  5 / 4, named VECTOR / TENSOR in its map); its "accelerator register port" carries the DPU pages 8..15. This is
  documented in `config/dpu_memmap.yaml` and `firmware/include/dpu_hw.h`.
* Synthesizable RTL follows the repository's coding rules (flat ports, no structs/`import`/`return`/`inside`,
  functions assign to the function name) because the baseline flow is Yosys 0.33; two Yosys 0.33 limits were found and
  worked around (module-header `import` is rejected; `return` is rejected). Fully-qualified `pkg::NAME` references are
  accepted — that is how the RTL uses `silicaflux_cloud_pkg`.

## 4. Tool versions used here

Verilator 5.020, Yosys 0.33, Icarus 12 (installed; the full-system bench is Verilator-only because it needs SVA and
classes), GNU `riscv64-unknown-elf-gcc` 13.2 (`rv32im_zicsr_zifencei`, ilp32), Python 3.13 + PyYAML. Exact versions are
recorded in `reports/tools.txt`.

## 5. Gaps found in the repository that this project does not close

* No firmware authentication / secure boot for the ControlCore (CRC32 integrity only) — reported by the firmware.
* No RISC-V compliance claim anywhere (riscv-tests only).
* No hardware (FPGA board or silicon) result anywhere in the repository; none here either.
* No license file: `third_party/PROVENANCE.md` states this; an owner must add one before external distribution.
