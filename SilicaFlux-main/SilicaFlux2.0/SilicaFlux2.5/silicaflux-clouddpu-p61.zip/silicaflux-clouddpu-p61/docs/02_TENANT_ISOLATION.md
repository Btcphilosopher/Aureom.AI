# 02 — Tenant protection

> *A tenant ID alone does not provide isolation.* (project brief, §7)

A tenant id is a label a descriptor can lie about. This design separates the **five** objects the brief names, and each
is protected by hardware that does not trust the label.

| Object | Where it lives | What protects it |
|---|---|---|
| **Tenant context** | `sfd_tenant_ctx` | Written only through the ControlCore register page (management plane). Shadow registers + `COMMIT`; `COMMIT` is refused unless the tenant is `DISABLED`, so a live tenant's permissions cannot be edited. Overlap checks against every other configured tenant. State machine below. |
| **Command queues** | `sfd_cmdq` | Each host queue is **hard-wired to one tenant** by the `BIND` register (changeable only while the queue is empty and idle). The tenant of a command is the queue's binding; the `tenant` field in the descriptor is only a *claim*, and a claim different from the binding is `ERR_TENANT_MISMATCH` (a violation). The submission port selects a queue (`vio_sub_q`) the way a PCIe function selects its own virtual function; the *management* queue (id 15) is firmware-only. |
| **DMA permissions** | `sfd_win_check`, `sfd_host_guard`, `sfd_cmdproc` | Per-tenant host windows `{base, size, R, W}`. Checked **twice**: once by the command processor (precise error code, before anything moves), and again on **every beat** by a guard in the datapath that reads the live tenant context. |
| **Memory ownership** | `sfd_tenant_ctx`, `sfd_sram_guard` | Each tenant owns one contiguous SRAM partition. Descriptors carry *partition-relative* offsets (a tenant never names an absolute SRAM address). Partitions never overlap (checked on `COMMIT`). Every beat of CloudDMA *and of PacketCore* passes `sfd_sram_guard`. The partition is **scrubbed** on assignment, teardown and recovery. |
| **Completion records** | `sfd_cmdq` | One completion FIFO per queue; a completion is written only into the queue it belongs to (SVA `Q2`); the record carries the tenant; `vio_cpl_data[q]` is the only way to read queue q's records. A queue with no credits back-pressures only itself. |

## The tenant state machine

```
 DISABLED --COMMIT ok--> SCRUBBING --scrub done--> DISABLED(configured) --ENABLE--> ACTIVE
 ACTIVE --violation (policy)--> QUARANTINED
 ACTIVE | QUARANTINED --DISABLE/RECOVER--> DRAINING --no job in flight--> SCRUBBING --> DISABLED
```

* `COMMIT` validates: partition non-empty, 256-byte aligned, inside the SRAM; each host window non-empty, beat-aligned,
  inside the `ADDRESS_WIDTH` space; no overlap of the partition or of any host window with another *configured*
  tenant (`CFG_OVERLAP_SRAM`, `CFG_OVERLAP_HOST`). Then the partition is scrubbed **before** the tenant can be enabled —
  a new owner can never read a previous owner's bytes.
* A tenant is **quarantined** on its first isolation violation (`POLICY[0]`, default on): further commands complete with
  `ERR_QUARANTINED`; other tenants keep running. Management recovers it with `RECOVER` (drain → scrub → `DISABLED`) and
  re-admits it with `ENABLE`.
* A timed-out job's slot stays counted as in flight until the data plane is reset, so the tenant cannot be scrubbed
  while a stuck slot might still write into the partition (SVA `S1`/`S2`).

## Where "multi-tenant execution" is enabled

The brief says to integrate real permission enforcement **before** enabling multi-tenant execution. Enforcement is not a
mode: there is no parameter, register or build option that disables a check, so `NUM_TENANTS > 1` is legal in the same
RTL that passed the single-tenant verification. The multi-tenant configurations were built and regressed only after the
minimum one passed, and the claim "tenants are isolated" rests on all of the following holding together:

1. window / partition checks and per-beat guards verified at single-tenant level (`decode`, `tb_guard_unit`);
2. tenant context commit rules verified (`isolation` scenario, two tenants);
3. mutation testing of the principal checks — host-window read/write permission (M03, M14), descriptor tenant claim vs. queue binding (M04),
   per-beat host and SRAM guards (M02, M06), quarantine (M07), scrub-on-teardown (M05), cross-queue completion leak (M18), SRAM range (M19) —
   each injected bug must be detected (`reports/mutation.md`).

## Defence in depth: the guard unit test

The command processor is the *first* line of defence; the guards are the *second* and are verified **without** it.
`tb/tb_guard_unit.sv` drives a job slot (+ PacketCore hub + crossbar + SRAM + host memory model) directly with
transactions the command processor would have refused, and requires every one to end in `ERR_PERM_BEAT` with **zero**
forbidden host accesses and **zero** SRAM bytes changed outside the owner's partition. Cases: other tenant's host
window (read and write), read-only window written, outside every window, unconfigured tenant, a transfer that starts
legal and crosses the window end mid-way (only the in-window beats are written), SRAM staging running past the
partition end (DMA and PacketCore), reading another tenant's SRAM out to the host.

## Trust boundaries — stated plainly

* The **management plane is trusted**: the ControlCore firmware and the host reaching the ControlCore host port (the
  physical function / hypervisor) can reconfigure tenants, read the whole SRAM through the EXT window and submit commands
  for any tenant through the management queue. Tenants (virtual functions) have **only** their queue and completion ports.
* The host write lock (`SECURITY.CTRL.HOST_LOCK`) set by the firmware protects the ControlCore's own memories from the
  host; it does **not** restrict the host's access to the DPU registers, because the host *is* the management plane here.
* No IOMMU / PASID / SR-IOV exists in the repository: the per-beat host window check is the DPU's own IOVA protection.
  Whether the *host memory system* honours the same windows is outside this block.
* Not claimed: side-channel isolation (shared SRAM banks, shared fabric timing and the shared PacketCore are observable
  through latency), denial-of-service fairness beyond round-robin arbitration, secure boot (the firmware image is
  CRC-checked, not authenticated).
