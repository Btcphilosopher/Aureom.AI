# 01 — Architecture

Primary RTL: `rtl/silicaflux_cloud_dpu.sv` · shared format: `rtl/pkg/silicaflux_cloud_pkg.sv` · register map:
`config/dpu_memmap.yaml` (generated `docs/DPU_MEMORY_MAP.md`).

## 1. Block diagram

```
 host (testbench / PF driver)                      management plane (reused, unmodified)
 ┌──────────────────────────────────┐               ┌──────────────────────────────────────────────┐
 │ vio_sub_*  descriptor submit     │               │ silicaflux_control_core  (Project 21)          │
 │ vio_cpl_*  completions (per queue)│               │  RV32IM_Zicsr CPU · boot ROM · INTC · mailbox  │
 │ hm_*       host memory (SFB2)    │               │  host port hs_* · register pages 8..15 ──────┐ │
 │ tlm_*      telemetry events      │               │  EXT window 0x2000_0000.. ───────────────┐   │ │
 └───────┬────────────┬─────────────┘               └───────────────────────────────────────────┼───┼─┘
         │            │ hm                                              DPU_EVENT/FAULT irq ◄───┘   │ │
         ▼            │                                                                            │ │
   ┌──────────┐  heads  ┌─────────────┐ txn  ┌────────────┐ SRAM+host beats ┌───────────────────┐ │ │
   │ sfd_cmdq │───────► │ sfd_cmdproc │────► │ sfd_job_   │────────────────►│ sfd_fabric         │◄┘ │
   │ SQ + CQ  │◄──cpl───│ validate    │◄done─│ slot  x NCH│  host guard     │ sfb_crossbar (SFB2)│   │
   │ per queue│ credits │ dispatch    │      │ CloudDMA   │  SRAM guard     │ SRAM banks (sramlib)│   │
   └──────────┘         │ watchdog    │      └─────┬──────┘                 │ host-port mux       │   │
        ▲               │ DP reset    │            │ PacketCore job         └───────────┬─────────┘   │
        │ binding       └──────┬──────┘      ┌─────▼──────┐  SRAM guard                  │ mgmt window │
   ┌────┴────────┐ tenant ctx  │             │ sfd_pkt_hub│───────────────────────────────┘             │
   │sfd_tenant_  │◄────────────┘             │ PacketCore │                                             │
   │ctx + scrub  │  (partitions, windows,    │ TEST ADAPTER                                             │
   └─────────────┘   state machine)          └────────────┘      sfd_regs · sfd_perf · sfd_tlm ◄────────┘
```

| # | Brief item | Module(s) | Status |
|---|---|---|---|
| 1 | RISC-V ControlCore | `silicaflux_control_core` (vendored) | real, reused |
| 2 | Cloud command processor | `sfd_cmdproc`, `sfd_cmdq` | new, verified |
| 3 | DataFabric | `sfd_fabric` (DataFabric `sfb_crossbar` + sramlib banks + host-port mux) | reused + new glue |
| 4 | PacketCore interface | `sfd_pkt_hub` + `sfd_packetcore_tadapter` | **test adapter** |
| 5 | CloudDMA interface | `sfd_clouddma` inside `sfd_job_slot` | new, verified |
| 6 | VirtualIO interface | `vio_sub_*` / `vio_cpl_*` ports | interface real, host side is a test model |
| 7 | Local SRAM | `sfd_fabric` banks over `sram_sp` | reused |
| 8 | InferenceScheduler | compute-class queues, `OP_INFER` → `ERR_BLOCKED` | **blocked** |
| 9 | CryptoCore | `OP_CRYPTO` → `ERR_BLOCKED` | **blocked** |
| 10 | StorageFabric | `OP_STORAGE` → `ERR_BLOCKED` | **blocked** |
| 11 | CloudTelemetry | `sfd_tlm` (event port) + `sfd_perf` (counters) | interface real, consumer is a test model |
| 12 | Clock / reset / RAS | ControlCore resets + `dp_rst_n`; DPU faults → ControlCore RAS inputs | real |

`BLOCK_STATUS` (register `G_BLOCK_STATUS`) reports the honest state of each block to software
(`ABSENT / BLOCKED / TEST_ADAPTER / REAL`).

## 2. Parameters

| Parameter | Default | Range / note |
|---|---|---|
| `NUM_NETWORK_QUEUES` | 1 | ≥ 1; queues `0..NNQ-1` are network class (PacketCore / CloudDMA ops) |
| `NUM_COMPUTE_QUEUES` | 1 | 0..; the next queues; compute class (engine ops, all `BLOCKED`); NNQ+NCQ ≤ 15 |
| `NUM_DMA_CHANNELS` | 1 | 1..8 job slots (one CloudDMA channel each) |
| `NUM_TENANTS` | 1 | 1..16; > 1 is legal because permission enforcement cannot be switched off |
| `DATA_WIDTH` | 32 | 32 / 64 / 128 (SRAM word, DMA beat, host-memory beat) |
| `ADDRESS_WIDTH` | 32 | 32..64 (host/IOVA addresses) |
| `SRAM_CAPACITY` | 65 536 B | multiple of 256 B; per bank a power of two |
| `ENABLE_TENSOR/CRYPTO/STORAGE` | 0 | **must be 0** — elaboration error otherwise |
| `NUM_SRAM_BANKS` | 1 | contiguous banks (memory conflicts arise between masters) |
| `QUEUE_DEPTH` / `CPLQ_DEPTH` | 4 / 4 | per queue |
| `NUM_WINDOWS` | 2 | host windows per tenant (≤ 8) |
| `MAX_XFER_BYTES` | 4096 | longest legal descriptor |

Illegal combinations are refused at elaboration with a readable generate-block name (`g_err_…`).

## 3. Common transaction format (`silicaflux_cloud_pkg`)

One transaction, three renderings of the same fields (transaction id, source, destination, tenant, opcode, address,
length, permissions, status, error, completion tag):

| Rendering | Width | Used for |
|---|---|---|
| `sfc_cmd` | 384 b = 12 × 32-bit words | host-visible submission descriptor |
| `sfc_txn` | 320 b | internal bundle (command processor → slot → engines → telemetry) |
| `sfc_cpl` | 256 b = 8 words | host-visible completion record |

The host does **not** choose the transaction id (DPU sequence), the source, the destination or the *authoritative* tenant
(the queue's hardware binding). Descriptor word map and completion word map are in the package header; field positions
are shared constants, and `tb/tb_layout_check.sv` proves the struct views used by testbenches and the flat offsets used
by the RTL are the same bits (it found one defect in the package during development).

Operations: `NOP`; `PKT_PROCESS` (host → SRAM → PacketCore → SRAM → host); `DMA_H2D`; `DMA_D2H`; engine classes
`INFER` / `CRYPTO` / `STORAGE` (refused). Completion status `OK / ERROR / ABORTED` plus an 8-bit error code
(`ERR_*`, listed in the package; 0x10..0x14 are isolation violations).

## 4. The data path and its ordering rules

```
 vio_sub ─► SQ[q] ─► cmdproc ─► slot: H2D (host read beat ► guard ► SRAM write beat)
                                      PROC (PacketCore: SRAM read ► transform+CRC ► SRAM write, guarded)
                                      D2H  (SRAM read beat ► host write beat ► guard)      ◄ last ACK = COMMIT
                                      ─► done+commit ─► cmdproc builds record ─► CQ[q] ─► vio_cpl
```

* One SFB2 transaction per beat, one outstanding per port. Host and SRAM addresses must be beat-aligned; the **length
  may end inside a beat**: the last beat uses a partial byte strobe, so no byte outside `[addr, addr+len)` is written
  (tested, and mutation M13 proves the test can fail).
* **Commit before completion** (the rule the brief singles out). `done_commit` is raised only when the response of the
  *last* write beat has been received (SFB2 R7: a write response is issued only after the target performed the write).
  The command processor builds an `OK` completion only from a slot result that carries the flag for any operation
  that writes host memory; otherwise the record becomes `ERR_INTERNAL`. The completion carries `COMMITTED = 1`. Checked by:
  the SVA `C1` (an OK completion of a host-writing operation must carry the flag); the testbench comparing the host-memory
  image *at the moment the completion is received* (the host model applies a write at the cycle it acknowledges it, so an
  early completion finds old bytes); and the mutation campaign: mutant M01 (the last store beat is reported done when it
  is *issued* instead of *acknowledged*) is killed by the testbench scoreboard (the completion's byte count comes up one
  beat short in `smoke` and `boot`) — the report records the first failing check, it does not claim which of the
  independent checks would also have fired.
* Completions of one queue are in order when `NUM_DMA_CHANNELS = 1`; with several slots they may complete out of order —
  the completion tag identifies them (like an NVMe CQ).
* **Completion credits.** Popping a descriptor reserves a slot in that queue's completion FIFO. A completion therefore
  never finds the FIFO full and never blocks; a queue whose completions are not being read simply stops being scheduled,
  and *only that queue* (saturation test, SVA `C2`).

## 5. Fabric

`sfd_fabric` instantiates the DataFabric `sfb_crossbar` with masters
`{management, CloudDMA slot 0..NCH-1, PacketCore, scrubber}` and one slave per SRAM bank; round-robin arbitration;
`ev_arb_loss` per master is the **memory-conflict** counter. The management master is the ControlCore EXT window through
`sfd_mgmt_adapter` (32-bit → `DATA_WIDTH`, lane steering, range check). The slots' host ports share one host-memory port
through a second crossbar instance (`NS = 1`) when `NUM_DMA_CHANNELS > 1`.

## 6. Clock, reset, RAS

* One functional clock `clk`. The DPU runs on the ControlCore's accelerator clock `acc_clk_o` (an ICG copy; define
  `SFV_NO_CLOCK_GATE` for a pass-through, which every simulation here does) and `acc_rst_no`.
* **Persistent domain** (queues, tenant contexts, counters, registers, command processor) resets with `acc_rst_no`.
  **Data-plane domain** (job slots, DMA, PacketCore, crossbars, SRAM controllers) additionally resets on
  `CTRL.DP_RESET`. SRAM *contents* are never cleared by a reset — only the tenant scrubber clears memory.
* **Data-plane reset sequence** (`sfd_cmdproc`): stop dispatch → complete every in-flight job with `ERR_RESET_ABORT`
  (`ABORTED`) → hold `dp_rst_n` low 4 cycles → clear zombies → resume. A request outstanding on the host port at that
  moment would leave a *late response* owed by the host; `sfd_hm_port` remembers it (orphan), swallows it when it
  arrives and issues nothing meanwhile — otherwise a stale response would corrupt the first transfer after the reset
  (mutation M11).
* **Watchdog**: a job older than `JOB_TIMEOUT` cycles completes with `ERR_TIMEOUT`, its slot becomes a *zombie* (still
  counted as in flight, so the tenant cannot be scrubbed under a slot that may still write) and dispatch *halts*
  until firmware issues `DP_RESET`.
* **RAS**: sticky `FAULT_STATUS` bits (`PERM_VIOL`, `HOST_ERR`, `DESC_ERR`, `TIMEOUT`, `SRAM_ERR`, `INTERNAL`,
  `RESET_DONE`, `TLM_DROP`) with last-fault capture; `FAULT_ENABLE` → `DPU_FAULT` interrupt, `FAULT_WARN`/`FAULT_FATAL`
  masks → the ControlCore RAS warning/fatal inputs (the ControlCore's own `acc_tsu_halted` fatal path is deliberately
  *not* used: it would isolate the very registers recovery needs).

## 7. Performance and telemetry

64-bit counters (LO/HI latch read, FREEZE, CLEAR): commands accepted / retired / errored, DMA bytes read/written
(completed beats only), active cycles, stall cycles (dispatch / fabric / host / any), memory conflicts, error events,
violations, host errors, timeouts, cycles; per tenant: commands, committed bytes, active cycles, violations, errors.
`sfd_tlm` exports 80-bit records `{timestamp, argument, event, queue, tenant}`; a full 16-entry FIFO **drops and counts**
rather than back-pressuring the data path.

## 8. What the minimum configuration is

`NUM_TENANTS=1, NUM_NETWORK_QUEUES=1, NUM_COMPUTE_QUEUES=1, NUM_DMA_CHANNELS=1`, 32-bit data/address, 64 KiB SRAM,
one clock — *one tenant, one packet stream, one DMA path, one clock*, as the brief asks. Larger configurations are
built and regression-tested (`reports/regression.md`) but each only after the minimum one passed.
