# 06 — Synthesis configuration and results

**Technology-independent only.** There is no PDK, no cell library, no clock constraint and no place-and-route in this
project, so there is **no area, frequency or power number**. What exists is a Yosys 0.33 *generic* synthesis that proves
the RTL is synthesizable with the repository's baseline open-source flow, contains no latches, and passes `check -assert`.

## Flow (`synth/synth_dpu.ys.tmpl`, driven by `scripts/synth.sh` / `scripts/synth_all.sh`)

```
read_verilog -defer -sv -DSYNTHESIS -DSFV_NO_CLOCK_GATE <vendored libraries + DPU RTL>   # the simulation-only checkers are NOT in the list
chparam ...   (after the read, before hierarchy: Yosys 0.33 ignores it earlier)
hierarchy -check -top <top>;  proc;  flatten;  opt_clean
check -assert                         # no combinational loops, no undriven/multiply-driven nets
memory -nomap; opt -full              # SRAM arrays and FIFO storage stay as $mem_v2 (they are memories, not gates)
select -count t:$dlatch t:$adlatch    # latch count
techmap; opt -fast; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX; opt_clean; stat
```
* `SFV_NO_CLOCK_GATE` removes the ControlCore's clock-gate latch (an ASIC flow puts the library ICG cell behind
  `sfv_clkgate`); consequently **the gated-clock path is not exercised by the simulations either** (every simulation here
  also defines it).
* The local SRAM uses the SRAM Wrapper Library's **generic** backend (`DPU_SRAM_BACKEND`); the ASIC macro adapters
  (SKY130 / GF180 / IHP) are one parameter away but were not synthesized.

## Results (`reports/synth/SUMMARY.md`)

| Configuration | Parameters | Generic cells | Flip-flops | Memories | Latches | `check` problems |
|---|---|---:|---:|---:|---:|---:|
| `min` (whole top: DPU + ControlCore) | defaults: 1 tenant, 1 network queue, 1 DMA channel, 32-bit | 67 666 | 8 147 | 16 | 0 | 0 |
| `controlcore` (alone) | — | 29 183 | 3 886 | 7 | 0 | 0 |
| `mt` | 2 tenants, 2 network queues, 2 DMA channels, 2 SRAM banks | 81 741 | 9 842 | 20 | 0 | 0 |
| `w64` | 64-bit data, 40-bit addresses, 2 queues, 2 DMA channels, 2 banks | 79 694 | 9 244 | 20 | 0 | 0 |
| `w128` | 4 tenants, 4+2 queues, 3 DMA channels, 128-bit, 64-bit addresses, 4 windows, 4 banks, 128 KiB | 168 422 | 15 387 | 30 | 0 | 0 |

* The DPU on its own is roughly `min − controlcore` ≈ **38.5 K generic cells / 4.3 K flip-flops** (an arithmetic
  difference of two separate runs, not a separately synthesized DPU hierarchy).
* The cell numbers **exclude the SRAM bit arrays and FIFO storage** (`$mem_v2`, left unmapped on purpose).
* These counts say how the generated logic *scales* with the parameters (the 128-bit, 4-tenant, 3-channel build is
  about 2.5 × the minimum). They are **not** an area estimate: a standard-cell library, memory compiler and timing
  closure would change every number.
* Not run: static timing, power, CDC analysis (there is one clock), formal proofs, FPGA place-and-route (`FPGAFlow` does
  not exist in the repository — the established practice is a per-project ULX3S/ECP5 flow, which was not attempted for
  the DPU), gate-level simulation.

```bash
make synth      # regenerates reports/synth/*; the largest configuration takes a few minutes and a few GB of memory
```
