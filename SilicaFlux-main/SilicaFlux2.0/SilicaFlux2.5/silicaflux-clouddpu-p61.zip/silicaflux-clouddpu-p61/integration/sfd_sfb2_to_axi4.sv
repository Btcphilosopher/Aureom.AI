// =============================================================================
// CloudDPU integration wrapper :: sfd_sfb2_to_axi4 -- SFB2 master (single beat) -> AXI4 master
//
// The DPU's host-memory port is SFB2 (one beat per transaction, one outstanding).  A PCIe endpoint IP (HostLink's
// boundary, Project 25) or any AXI4 interconnect presents an AXI4 slave.  This bridge converts one SFB2 transaction into
// one single-beat AXI4 transaction (AxLEN = 0, AxSIZE = log2(DW/8), INCR, fixed ID 0):
//     write  AW and W are issued together (each may complete independently), the SFB2 response is given when B arrives
//     read   AR, then the SFB2 response (with the read data) is given when R arrives
// BRESP / RRESP other than OKAY (bit 1 set: SLVERR / DECERR) become rsp_error = 1 with zero read data.
// R7 of SFB2 (a write response only after the write was performed) holds because B is only given by the AXI slave after
// the write completed.  No state besides the one outstanding transaction.  Not verified against a real PCIe endpoint
// (none exists in the repository): verified against a behavioural AXI4 memory (tb/tb_axi_bridge.sv).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_sfb2_to_axi4 #(
  parameter int AW = 32,
  parameter int DW = 32
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // SFB2 slave side (from the DPU host-memory port)
  input  wire logic            req_valid,
  output logic                 req_ready,
  input  wire logic            req_write,
  input  wire logic [AW-1:0]   req_addr,
  input  wire logic [DW-1:0]   req_wdata,
  input  wire logic [DW/8-1:0] req_wstrb,
  output logic                 rsp_valid,
  input  wire logic            rsp_ready,
  output logic [DW-1:0]        rsp_rdata,
  output logic                 rsp_error,
  // AXI4 master
  output logic                 m_awvalid,
  input  wire logic            m_awready,
  output logic [AW-1:0]        m_awaddr,
  output logic [7:0]           m_awlen,
  output logic [2:0]           m_awsize,
  output logic [1:0]           m_awburst,
  output logic [2:0]           m_awprot,
  output logic                 m_wvalid,
  input  wire logic            m_wready,
  output logic [DW-1:0]        m_wdata,
  output logic [DW/8-1:0]      m_wstrb,
  output logic                 m_wlast,
  input  wire logic            m_bvalid,
  output logic                 m_bready,
  input  wire logic [1:0]      m_bresp,
  output logic                 m_arvalid,
  input  wire logic            m_arready,
  output logic [AW-1:0]        m_araddr,
  output logic [7:0]           m_arlen,
  output logic [2:0]           m_arsize,
  output logic [1:0]           m_arburst,
  output logic [2:0]           m_arprot,
  input  wire logic            m_rvalid,
  output logic                 m_rready,
  input  wire logic [DW-1:0]   m_rdata,
  input  wire logic [1:0]      m_rresp,
  input  wire logic            m_rlast
);
  localparam logic [2:0] SIZE = 3'($clog2(DW / 8));
  localparam logic [1:0] S_IDLE = 2'd0, S_WR = 2'd1, S_RD = 2'd2, S_RSP = 2'd3;

  logic [1:0]        st_q;
  logic              aw_done_q, w_done_q, ar_done_q, err_q;
  logic [AW-1:0]     addr_q;
  logic [DW-1:0]     wdata_q, rdata_q;
  logic [DW/8-1:0]   wstrb_q;

  assign req_ready = (st_q == S_IDLE);
  assign m_awvalid = (st_q == S_WR) && !aw_done_q;
  assign m_awaddr  = addr_q;
  assign m_awlen   = 8'd0;
  assign m_awsize  = SIZE;
  assign m_awburst = 2'b01;
  assign m_awprot  = 3'b000;
  assign m_wvalid  = (st_q == S_WR) && !w_done_q;
  assign m_wdata   = wdata_q;
  assign m_wstrb   = wstrb_q;
  assign m_wlast   = 1'b1;
  assign m_bready  = (st_q == S_WR) && aw_done_q && w_done_q;
  assign m_arvalid = (st_q == S_RD) && !ar_done_q;
  assign m_araddr  = addr_q;
  assign m_arlen   = 8'd0;
  assign m_arsize  = SIZE;
  assign m_arburst = 2'b01;
  assign m_arprot  = 3'b000;
  assign m_rready  = (st_q == S_RD) && ar_done_q;
  assign rsp_valid = (st_q == S_RSP);
  assign rsp_rdata = err_q ? {DW{1'b0}} : rdata_q;
  assign rsp_error = err_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE;  aw_done_q <= 1'b0;  w_done_q <= 1'b0;  ar_done_q <= 1'b0;  err_q <= 1'b0;
      addr_q <= '0;  wdata_q <= '0;  rdata_q <= '0;  wstrb_q <= '0;
    end else begin
      case (st_q)
        S_IDLE: if (req_valid) begin
          addr_q <= req_addr;  wdata_q <= req_wdata;  wstrb_q <= req_wstrb;
          aw_done_q <= 1'b0;  w_done_q <= 1'b0;  ar_done_q <= 1'b0;  err_q <= 1'b0;
          st_q <= req_write ? S_WR : S_RD;
        end
        S_WR: begin
          if (m_awvalid && m_awready) aw_done_q <= 1'b1;
          if (m_wvalid && m_wready)   w_done_q  <= 1'b1;
          if (m_bvalid && m_bready) begin err_q <= m_bresp[1]; st_q <= S_RSP; end
        end
        S_RD: begin
          if (m_arvalid && m_arready) ar_done_q <= 1'b1;
          if (m_rvalid && m_rready) begin rdata_q <= m_rdata; err_q <= m_rresp[1]; st_q <= S_RSP; end
        end
        S_RSP: if (rsp_ready) st_q <= S_IDLE;
        default: st_q <= S_IDLE;
      endcase
    end
  end
  wire unused_ok = &{1'b0, m_rlast, m_bresp[0], m_rresp[0]};   // only bit 1 (SLVERR/DECERR) is meaningful
endmodule

`default_nettype wire
