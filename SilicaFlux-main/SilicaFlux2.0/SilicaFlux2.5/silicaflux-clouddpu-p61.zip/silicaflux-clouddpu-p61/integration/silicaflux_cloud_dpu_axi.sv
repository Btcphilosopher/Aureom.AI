// =============================================================================
// CloudDPU integration wrapper :: silicaflux_cloud_dpu_axi -- the DPU with an AXI4 host-memory port
//
// silicaflux_cloud_dpu with its SFB2 host-memory port (hm_*) replaced by an AXI4 master (m_axi_*), the boundary at which a
// PCIe endpoint IP / HostLink (Project 25) or an AXI interconnect attaches.  Everything else is the DPU's own interface.
// The bridge is sfd_sfb2_to_axi4 (single beat, AxLEN = 0, ID 0).  Parameters are those of silicaflux_cloud_dpu.
// Status: lint-clean and bridge-verified (tb/tb_axi_bridge.sv); the full DPU regression runs on the SFB2 port, so the
// combination is covered by the bridge test plus the DPU tests, not by a separate system regression.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_cloud_dpu_axi #(
  parameter int NUM_NETWORK_QUEUES = 1,
  parameter int NUM_DMA_CHANNELS   = 1,
  parameter int NUM_TENANTS        = 1,
  parameter int NUM_COMPUTE_QUEUES = 1,
  parameter int DATA_WIDTH         = 32,
  parameter int ADDRESS_WIDTH      = 32,
  parameter int SRAM_CAPACITY      = 65536,
  parameter int ENABLE_TENSOR      = 0,
  parameter int ENABLE_CRYPTO      = 0,
  parameter int ENABLE_STORAGE     = 0,
  parameter int NUM_SRAM_BANKS     = 1,
  parameter int QUEUE_DEPTH        = 4,
  parameter int CPLQ_DEPTH         = 4,
  parameter int NUM_WINDOWS        = 2,
  parameter int MAX_XFER_BYTES     = 4096
) (
  input  wire logic        clk,
  input  wire logic        rst_ni,
  input  wire logic        test_mode,
  input  wire logic [1:0]  boot_mode_i,
  input  wire logic        host_rst_req_i,
  input  wire logic        ext_warn_i,
  input  wire logic        ext_fatal_i,
  output logic             ras_fatal_o,
  input  wire logic        hs_req_valid,
  output logic             hs_req_ready,
  input  wire logic        hs_req_write,
  input  wire logic [31:0] hs_req_addr,
  input  wire logic [31:0] hs_req_wdata,
  input  wire logic [3:0]  hs_req_wstrb,
  output logic             hs_rsp_valid,
  input  wire logic        hs_rsp_ready,
  output logic [31:0]      hs_rsp_rdata,
  output logic             hs_rsp_error,
  output logic             host_irq_o,
  output logic             host_ready_o,
  output logic             cmdproc_ready_o,
  input  wire logic        vio_sub_valid,
  output logic             vio_sub_ready,
  input  wire logic [3:0]  vio_sub_q,
  input  wire logic [silicaflux_cloud_pkg::CMD_W-1:0] vio_sub_cmd,
  output logic [NUM_NETWORK_QUEUES+NUM_COMPUTE_QUEUES-1:0] vio_cpl_valid,
  input  wire logic [NUM_NETWORK_QUEUES+NUM_COMPUTE_QUEUES-1:0] vio_cpl_ready,
  output logic [(NUM_NETWORK_QUEUES+NUM_COMPUTE_QUEUES)*silicaflux_cloud_pkg::CPL_W-1:0] vio_cpl_data,
  output logic             tlm_valid,
  input  wire logic        tlm_ready,
  output logic [silicaflux_cloud_pkg::TLM_W-1:0] tlm_data,
  output logic             diag_valid_o,
  output logic [7:0]       diag_char_o,
  output logic             test_done_o,
  output logic             test_fail_o,
  output logic [15:0]      test_code_o,
  output logic             cpu_sleep_o,
  output logic             dpu_busy_o,
  output logic             dpu_irq_event_o,
  output logic             dpu_irq_fault_o,
  // ---------------------------------------------------------------- AXI4 master (host memory)
  output logic                      m_axi_awvalid,
  input  wire logic                 m_axi_awready,
  output logic [ADDRESS_WIDTH-1:0]  m_axi_awaddr,
  output logic [7:0]                m_axi_awlen,
  output logic [2:0]                m_axi_awsize,
  output logic [1:0]                m_axi_awburst,
  output logic [2:0]                m_axi_awprot,
  output logic                      m_axi_wvalid,
  input  wire logic                 m_axi_wready,
  output logic [DATA_WIDTH-1:0]     m_axi_wdata,
  output logic [DATA_WIDTH/8-1:0]   m_axi_wstrb,
  output logic                      m_axi_wlast,
  input  wire logic                 m_axi_bvalid,
  output logic                      m_axi_bready,
  input  wire logic [1:0]           m_axi_bresp,
  output logic                      m_axi_arvalid,
  input  wire logic                 m_axi_arready,
  output logic [ADDRESS_WIDTH-1:0]  m_axi_araddr,
  output logic [7:0]                m_axi_arlen,
  output logic [2:0]                m_axi_arsize,
  output logic [1:0]                m_axi_arburst,
  output logic [2:0]                m_axi_arprot,
  input  wire logic                 m_axi_rvalid,
  output logic                      m_axi_rready,
  input  wire logic [DATA_WIDTH-1:0] m_axi_rdata,
  input  wire logic [1:0]           m_axi_rresp,
  input  wire logic                 m_axi_rlast
);
  logic                   hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [ADDRESS_WIDTH-1:0] hm_req_addr;
  logic [DATA_WIDTH-1:0]  hm_req_wdata, hm_rsp_rdata;
  logic [DATA_WIDTH/8-1:0] hm_req_wstrb;

  silicaflux_cloud_dpu #(
    .NUM_NETWORK_QUEUES, .NUM_DMA_CHANNELS, .NUM_TENANTS, .NUM_COMPUTE_QUEUES, .DATA_WIDTH, .ADDRESS_WIDTH, .SRAM_CAPACITY,
    .ENABLE_TENSOR, .ENABLE_CRYPTO, .ENABLE_STORAGE, .NUM_SRAM_BANKS, .QUEUE_DEPTH, .CPLQ_DEPTH, .NUM_WINDOWS, .MAX_XFER_BYTES
  ) u_dpu (
    .clk, .rst_ni, .test_mode, .boot_mode_i, .host_rst_req_i, .ext_warn_i, .ext_fatal_i, .ras_fatal_o,
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error, .host_irq_o, .host_ready_o, .cmdproc_ready_o,
    .vio_sub_valid, .vio_sub_ready, .vio_sub_q, .vio_sub_cmd, .vio_cpl_valid, .vio_cpl_ready, .vio_cpl_data,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .tlm_valid, .tlm_ready, .tlm_data,
    .diag_valid_o, .diag_char_o, .test_done_o, .test_fail_o, .test_code_o, .cpu_sleep_o,
    .dpu_busy_o, .dpu_irq_event_o, .dpu_irq_fault_o
  );

  sfd_sfb2_to_axi4 #(.AW(ADDRESS_WIDTH), .DW(DATA_WIDTH)) u_axi (
    .clk, .rst_n(rst_ni),
    .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write), .req_addr(hm_req_addr),
    .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb),
    .rsp_valid(hm_rsp_valid), .rsp_ready(hm_rsp_ready), .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error),
    .m_awvalid(m_axi_awvalid), .m_awready(m_axi_awready), .m_awaddr(m_axi_awaddr), .m_awlen(m_axi_awlen), .m_awsize(m_axi_awsize),
    .m_awburst(m_axi_awburst), .m_awprot(m_axi_awprot),
    .m_wvalid(m_axi_wvalid), .m_wready(m_axi_wready), .m_wdata(m_axi_wdata), .m_wstrb(m_axi_wstrb), .m_wlast(m_axi_wlast),
    .m_bvalid(m_axi_bvalid), .m_bready(m_axi_bready), .m_bresp(m_axi_bresp),
    .m_arvalid(m_axi_arvalid), .m_arready(m_axi_arready), .m_araddr(m_axi_araddr), .m_arlen(m_axi_arlen), .m_arsize(m_axi_arsize),
    .m_arburst(m_axi_arburst), .m_arprot(m_axi_arprot),
    .m_rvalid(m_axi_rvalid), .m_rready(m_axi_rready), .m_rdata(m_axi_rdata), .m_rresp(m_axi_rresp), .m_rlast(m_axi_rlast)
  );
endmodule

`default_nettype wire
