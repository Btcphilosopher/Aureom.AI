// =============================================================================
// tb_axi_bridge -- sfd_sfb2_to_axi4 against a behavioural AXI4 memory with random channel delays and an error window.
// Random SFB2 reads/writes (byte strobes) are compared with a reference memory; reads of an error window must return
// rsp_error = 1 with zero data and writes to it must have no effect.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_axi_bridge;
  localparam int AW = 32, DW = 64, DWB = DW / 8;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic req_valid = 0, req_ready, req_write = 0, rsp_valid, rsp_ready = 0, rsp_error;
  logic [AW-1:0] req_addr = 0;
  logic [DW-1:0] req_wdata = 0, rsp_rdata;
  logic [DWB-1:0] req_wstrb = 0;
  logic awv, awr = 0, wv, wr = 0, bv = 0, br, arv, arr = 0, rv = 0, rr, rl = 1;
  logic [AW-1:0] awa, ara;
  logic [7:0] awl, arl; logic [2:0] aws, ars, awp, arp; logic [1:0] awb, arb, bresp = 0, rresp = 0;
  logic [DW-1:0] wd, rd = 0;
  logic [DWB-1:0] ws; logic wl;
  sfd_sfb2_to_axi4 #(.AW(AW), .DW(DW)) dut (
    .clk, .rst_n, .req_valid, .req_ready, .req_write, .req_addr, .req_wdata, .req_wstrb, .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_error,
    .m_awvalid(awv), .m_awready(awr), .m_awaddr(awa), .m_awlen(awl), .m_awsize(aws), .m_awburst(awb), .m_awprot(awp),
    .m_wvalid(wv), .m_wready(wr), .m_wdata(wd), .m_wstrb(ws), .m_wlast(wl), .m_bvalid(bv), .m_bready(br), .m_bresp(bresp),
    .m_arvalid(arv), .m_arready(arr), .m_araddr(ara), .m_arlen(arl), .m_arsize(ars), .m_arburst(arb), .m_arprot(arp),
    .m_rvalid(rv), .m_rready(rr), .m_rdata(rd), .m_rresp(rresp), .m_rlast(rl));
  // AXI memory slave: independent random ready delays; write performed when both AW and W were taken, B one cycle later
  byte mem [4096];
  byte ref_mem [4096];
  int fails = 0, checks = 0, nproto = 0;
  logic aw_got = 0, w_got = 0; logic [AW-1:0] aw_a; logic [DW-1:0] w_d; logic [DWB-1:0] w_s;
  logic [AW-1:0] ar_a; logic ar_got = 0;
  function automatic bit in_err(input logic [AW-1:0] a); return a >= 3072; endfunction
  always @(posedge clk) begin
    awr <= ($urandom_range(3, 0) != 0) && !aw_got;
    wr  <= ($urandom_range(3, 0) != 0) && !w_got;
    arr <= ($urandom_range(3, 0) != 0) && !ar_got && !rv;
    if (awv && awr) begin aw_got <= 1; aw_a <= awa; if (awl !== 8'd0 || aws !== 3'd3 || awb !== 2'b01) nproto++; end
    if (wv && wr)   begin w_got <= 1;  w_d <= wd; w_s <= ws; if (wl !== 1'b1) nproto++; end
    if (aw_got && w_got && !bv) begin
      if (!in_err(aw_a)) for (int b = 0; b < DWB; b++) if (w_s[b]) mem[aw_a + b] = w_d[8*b +: 8];
      bv <= 1; bresp <= in_err(aw_a) ? 2'b10 : 2'b00; aw_got <= 0; w_got <= 0;
    end
    if (bv && br) bv <= 0;
    if (arv && arr) begin ar_got <= 1; ar_a <= ara; if (arl !== 8'd0 || ars !== 3'd3 || arb !== 2'b01) nproto++; end
    if (ar_got && !rv && $urandom_range(2, 0) != 0) begin
      rv <= 1; rresp <= in_err(ar_a) ? 2'b11 : 2'b00; ar_got <= 0;
      for (int b = 0; b < DWB; b++) rd[8*b +: 8] <= in_err(ar_a) ? 8'hEE : mem[ar_a + b];
    end
    if (rv && rr) rv <= 0;
  end
  task automatic xfer(input bit w, input logic [AW-1:0] a, input logic [DW-1:0] d, input logic [DWB-1:0] s, output logic [DW-1:0] rdat, output bit err);
    @(negedge clk);
    req_valid = 1; req_write = w; req_addr = a; req_wdata = d; req_wstrb = s;
    #1; while (!req_ready) begin @(negedge clk); #1; end
    @(posedge clk); #1; req_valid = 0;
    rsp_ready = ($urandom_range(2, 0) != 0);
    while (!(rsp_valid && rsp_ready)) begin @(negedge clk); rsp_ready = ($urandom_range(2, 0) != 0); #1; end
    rdat = rsp_rdata; err = rsp_error;
    @(posedge clk); #1; rsp_ready = 0;
  endtask
  initial begin
    logic [DW-1:0] d, r; bit e; logic [AW-1:0] a;
    for (int i = 0; i < 4096; i++) begin mem[i] = byte'(i * 13 + 5); ref_mem[i] = mem[i]; end
    repeat (4) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);
    for (int n = 0; n < 600; n++) begin
      a = AW'(8 * $urandom_range(511, 0));
      if ($urandom_range(1, 0)) begin
        d = {$urandom, $urandom}; xfer(1, a, d, DWB'($urandom), r, e);
        checks++;
        if (e !== in_err(a)) begin fails++; $display("write error flag wrong at %0h: %0b", a, e); end
        if (!in_err(a)) for (int b = 0; b < DWB; b++) if (dut.wstrb_q[b]) ref_mem[a + b] = d[8*b +: 8];
      end else begin
        xfer(0, a, 0, 0, r, e);
        checks++;
        if (e !== in_err(a)) begin fails++; $display("read error flag wrong at %0h", a); end
        else if (in_err(a)) begin if (r !== 0) begin fails++; $display("error read returned data"); end end
        else for (int b = 0; b < DWB; b++) if (r[8*b +: 8] !== ref_mem[a + b]) begin fails++; $display("read mismatch at %0h+%0d", a, b); break; end
      end
    end
    checks++; if (nproto != 0) begin fails++; $display("AXI protocol field violations: %0d", nproto); end
    $display("TB RESULT %s transactions=600 checks=%0d fails=%0d", fails == 0 ? "PASS" : "FAIL", checks, fails);
    if (fails == 0) $finish(0); else $fatal(1, "axi bridge failed");
  end
  initial begin #50_000_000; $display("TB RESULT FAIL TIMEOUT"); $fatal(1, "timeout"); end
endmodule
