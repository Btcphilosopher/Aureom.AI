// =============================================================================
// SilicaFlux CloudDPU :: tb_dpu -- self-checking testbench of the complete DPU (ControlCore + data plane)
//
// The testbench plays the SIMULATED HOST only:
//   * management host: SFB2 master on the ControlCore host access port (configures the DPU through its register
//     pages, exactly as the PF driver / firmware would; the ControlCore CPU sits in its boot ROM)
//   * virtual functions: queue submission + completion ports (vio_*), random completion back-pressure
//   * host memory: SFB2 slave with latency, random back-pressure, write-commit at acknowledge time, error
//     injection ranges and a "late response" mode
//   * CloudTelemetry consumer
// CHECKING is independent of the RTL: a software reference model of PacketCore (transform, CRC-32, RFC 1071),
// a scoreboard keyed by (queue, tag), a shadow image of host memory compared at every completion and at the end
// of every scenario, a monitor that rejects any host-memory access outside the union of granted windows (and,
// with one DMA channel, outside the windows of the tenant that is executing), SRAM back-door checks of partitions
// and scrubbing, and the SystemVerilog assertions in rtl/dpu/sfd_assertions.sv.
//
// Scenario: +test=<name>[,<name>...]  (see run_test)      +seed=<n>  +bp=<0..90 host back-pressure %>
//           +cbp=<0..90 completion back-pressure %>  +lat=<max host latency>
// Result:   "TB RESULT PASS|FAIL ..." and exit status.
// Compile-time configuration (Verilator -D): NT NNQ NCQ NS DW AW NW NB SRAMB QD CD MAXX
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifndef NT
 `define NT 1
`endif
`ifndef NNQ
 `define NNQ 1
`endif
`ifndef NCQ
 `define NCQ 1
`endif
`ifndef NS
 `define NS 1
`endif
`ifndef DW
 `define DW 32
`endif
`ifndef AW
 `define AW 32
`endif
`ifndef NW
 `define NW 2
`endif
`ifndef NB
 `define NB 1
`endif
`ifndef SRAMB
 `define SRAMB 65536
`endif
`ifndef QD
 `define QD 4
`endif
`ifndef CD
 `define CD 4
`endif
`ifndef MAXX
 `define MAXX 4096
`endif

module tb_dpu;
  import silicaflux_cloud_pkg::*;
  import silicaflux_cloud_memmap_pkg::*;
`ifdef WITH_FW
  import cc_memmap_pkg::*;
`endif

  localparam int NT = `NT, NNQ = `NNQ, NCQ = `NCQ, NS = `NS, DW = `DW, AW = `AW, NW = `NW, NB = `NB;
  localparam int SRAMB = `SRAMB, QD = `QD, CD = `CD, MAXX = `MAXX;
  localparam int NQH = NNQ + NCQ;
  localparam int DWB = DW / 8;
  localparam longint HM_BASE  = (AW > 32) ? 64'h0000_00AB_0000_0000 : 64'h0000_0000_4000_0000;
  localparam int     HM_BYTES = 1 << 20;

  // ------------------------------------------------------------------ clock / reset / bookkeeping
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int seed = 1, bp_pct = 0, cbp_pct = 0, lat_max = 3;
  string tests;

  // Failure / check counters live in a class: its methods are compiled once as C++ methods instead of being inlined at
  // every one of the thousands of call sites (which made the generated simulation code unmanageably large).
  class tb_cnt;
    int fails = 0, checks = 0;
    function void fail(input longint unsigned t, input string msg);
      $display("[%0d] TB FAIL: %s", t, msg);
      fails++;
    endfunction
    function void check(input longint unsigned t, input string what, input longint unsigned got, input longint unsigned exp);
      checks++;
      if (got !== exp) begin
        $display("[%0d] TB CHECK FAIL %s: got %0h exp %0h", t, what, got, exp);
        fails++;
      end
    endfunction
    function void check_true(input longint unsigned t, input string what, input bit cond);
      checks++;
      if (!cond) begin $display("[%0d] TB CHECK FAIL %s", t, what); fails++; end
    endfunction
  endclass
  tb_cnt cnt = new();
  function automatic void fail(input string msg);                    cnt.fail(cyc, msg); endfunction
  function automatic void check(input string what, input longint unsigned got, input longint unsigned exp);
    cnt.check(cyc, what, got, exp);
  endfunction
  function automatic void check_true(input string what, input bit cond);  cnt.check_true(cyc, what, cond); endfunction

  // ------------------------------------------------------------------ DUT
  logic        boot_host_rst = 1'b0, ext_warn = 1'b0, ext_fatal = 1'b0;
  logic        hs_req_valid = 1'b0, hs_req_ready, hs_req_write = 1'b0, hs_rsp_valid, hs_rsp_error;
  logic [31:0] hs_req_addr = '0, hs_req_wdata = '0, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb = 4'hF;
  logic        host_irq, host_ready, cmdproc_ready, ras_fatal;
  logic        vio_sub_valid = 1'b0, vio_sub_ready;
  logic [3:0]  vio_sub_q = '0;
  logic [CMD_W-1:0] vio_sub_cmd = '0;
  logic [NQH-1:0] vio_cpl_valid, vio_cpl_ready = '0;
  logic [NQH*CPL_W-1:0] vio_cpl_data;
  logic        hm_req_valid, hm_req_ready = 1'b0, hm_req_write, hm_rsp_valid = 1'b0, hm_rsp_ready, hm_rsp_error = 1'b0;
  logic [AW-1:0] hm_req_addr;
  logic [DW-1:0] hm_req_wdata, hm_rsp_rdata = '0;
  logic [DWB-1:0] hm_req_wstrb;
  logic        tlm_valid, tlm_ready = 1'b1;
  logic [TLM_W-1:0] tlm_data;
  logic        diag_valid, test_done, test_fail, cpu_sleep, dpu_busy, dpu_irq_event, dpu_irq_fault;
  logic [7:0]  diag_char;
  logic [15:0] test_code;

  silicaflux_cloud_dpu #(
    .NUM_NETWORK_QUEUES(NNQ), .NUM_COMPUTE_QUEUES(NCQ), .NUM_DMA_CHANNELS(NS), .NUM_TENANTS(NT),
    .DATA_WIDTH(DW), .ADDRESS_WIDTH(AW), .SRAM_CAPACITY(SRAMB), .NUM_SRAM_BANKS(NB), .NUM_WINDOWS(NW),
    .QUEUE_DEPTH(QD), .CPLQ_DEPTH(CD), .MAX_XFER_BYTES(MAXX)
  ) dut (
    .clk, .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(2'b00), .host_rst_req_i(boot_host_rst),
    .ext_warn_i(ext_warn), .ext_fatal_i(ext_fatal), .ras_fatal_o(ras_fatal),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready(1'b1), .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(host_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready),
    .vio_sub_valid, .vio_sub_ready, .vio_sub_q, .vio_sub_cmd,
    .vio_cpl_valid, .vio_cpl_ready, .vio_cpl_data,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .tlm_valid, .tlm_ready, .tlm_data,
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep),
    .dpu_busy_o(dpu_busy), .dpu_irq_event_o(dpu_irq_event), .dpu_irq_fault_o(dpu_irq_fault)
  );

  // ================================================================== management host BFM (ControlCore host port)
  task automatic host_access(input bit wr, input logic [31:0] a, input logic [31:0] wd,
                             output logic [31:0] rd, output bit err);
    @(negedge clk);
    hs_req_valid = 1'b1; hs_req_write = wr; hs_req_addr = a; hs_req_wdata = wd; hs_req_wstrb = 4'hF;
    #1;
    while (!hs_req_ready) begin @(negedge clk); #1; end
    @(posedge clk);
    #1;
    hs_req_valid = 1'b0;
    while (!hs_rsp_valid) begin @(negedge clk); #1; end
    rd = hs_rsp_rdata; err = hs_rsp_error;
    @(posedge clk);
  endtask
  function automatic logic [31:0] raddr(input int region, input int off);
    return DPU_GLOBAL_PAGE_BASE + 32'(region) * 32'h1000 + 32'(off);
  endfunction
  task automatic rw(input int region, input int off, input logic [31:0] d);            // register write, must succeed
    logic [31:0] r; bit e;
    host_access(1'b1, raddr(region, off), d, r, e);
    if (e) fail($sformatf("register write region %0d off %0h refused", region, off));
  endtask
  task automatic rr(input int region, input int off, output logic [31:0] d);           // register read, must succeed
    bit e;
    host_access(1'b0, raddr(region, off), 32'd0, d, e);
    if (e) fail($sformatf("register read region %0d off %0h refused", region, off));
  endtask
  task automatic rw_err(input int region, input int off, input logic [31:0] d, output bit err);   // write, error expected/observed
    logic [31:0] r;
    host_access(1'b1, raddr(region, off), d, r, err);
  endtask
  task automatic rr_err(input int region, input int off, output logic [31:0] d, output bit err);
    host_access(1'b0, raddr(region, off), 32'd0, d, err);
  endtask
  task automatic rr64(input int region, input int off, output logic [63:0] v);             // LO then HI (atomic by design)
    logic [31:0] lo, hi;
    rr(region, off, lo);
    rr(region, off + 4, hi);
    v = {hi, lo};
  endtask

  // ================================================================== host memory model (SFB2 slave)
  byte hm  [HM_BYTES];                    // actual memory
  byte exp_mem [HM_BYTES];                // what the memory must contain
  bit  dc_mem  [HM_BYTES];                // don't-care (partially written by a failed transfer)
  typedef struct { bit write; longint unsigned addr; logic [DW-1:0] wdata; logic [DWB-1:0] wstrb; longint due; } hm_req_t;
  hm_req_t hm_q[$];
  longint unsigned hm_inj_lo [$], hm_inj_hi [$];  // error ranges (absolute addresses) [lo, hi)
  int      hm_inj_n = 0;                  // count of injected-error responses delivered
  longint  hm_hold_until = 0;             // responses are withheld until this cycle (late-response / timeout tests)
  int      hm_reads = 0, hm_writes = 0, hm_wild = 0, hm_noperm = 0;
  longint  hm_bytes_rd = 0, hm_bytes_wr = 0;

  function automatic byte pat(input longint unsigned a);                 // deterministic initial content
    logic [31:0] x;
    x = a[31:0] * 32'h9E3779B1 + 32'h7F4A7C15 + a[63:32];
    x = x ^ (x >> 15);  x = x * 32'h85EBCA6B;  x = x ^ (x >> 13);
    return x[7:0];
  endfunction
  task automatic hm_init();
    for (int i = 0; i < HM_BYTES; i++) begin hm[i] = pat(i); exp_mem[i] = pat(i); dc_mem[i] = 1'b0; end
  endtask
  function automatic bit hm_in_range(input longint unsigned a);
    return (a >= HM_BASE) && (a + DWB <= HM_BASE + HM_BYTES);
  endfunction
  function automatic bit hm_err_addr(input longint unsigned a);
    for (int i = 0; i < hm_inj_lo.size(); i++) if (a >= hm_inj_lo[i] && a < hm_inj_hi[i]) return 1'b1;
    return 1'b0;
  endfunction

  // granted windows as configured by the testbench (independent of the RTL): [tenant][window]
  longint unsigned tw_base [NT][NW];
  int unsigned     tw_size [NT][NW];
  bit              tw_v    [NT][NW];
  bit              tw_r    [NT][NW];
  bit              tw_w    [NT][NW];
  function automatic bit granted_any(input longint unsigned a, input bit wr);
    for (int t = 0; t < NT; t++) for (int w = 0; w < NW; w++)
      if (tw_v[t][w] && a >= tw_base[t][w] && a + DWB <= tw_base[t][w] + tw_size[t][w] && (wr ? tw_w[t][w] : tw_r[t][w])) return 1'b1;
    return 1'b0;
  endfunction
  function automatic bit granted_tenant(input int t, input longint unsigned a, input bit wr);
    for (int w = 0; w < NW; w++)
      if (tw_v[t][w] && a >= tw_base[t][w] && a + DWB <= tw_base[t][w] + tw_size[t][w] && (wr ? tw_w[t][w] : tw_r[t][w])) return 1'b1;
    return 1'b0;
  endfunction

  int  hm_lat_max_i;
  bit  hm_rdy_q = 1'b0;
  always @(posedge clk) begin
    // ---- request acceptance (values sampled before this edge)
    if (hm_req_valid && hm_req_ready) begin
      hm_req_t r;
      longint unsigned a;
      a = longint'(hm_req_addr);
      r.write = hm_req_write;  r.addr = a;  r.wdata = hm_req_wdata;  r.wstrb = hm_req_wstrb;
      r.due   = longint'(cyc) + 1 + (lat_max > 0 ? $urandom_range(lat_max, 0) : 0);
      hm_q.push_back(r);
      // independent permission monitor
      if (!hm_in_range(a)) begin hm_wild++; fail($sformatf("host access outside the memory model: %0h", a)); end
      else if (!granted_any(a, hm_req_write)) begin
        hm_noperm++; fail($sformatf("host %s at %0h is inside no granted window (permission leak)", hm_req_write ? "WRITE" : "READ", a));
      end
    end
    // ---- response channel
    if (hm_rsp_valid && hm_rsp_ready) hm_rsp_valid <= 1'b0;
    if ((!hm_rsp_valid || hm_rsp_ready) && hm_q.size() > 0 && hm_q[0].due <= longint'(cyc) && longint'(cyc) >= hm_hold_until) begin
      hm_req_t r;
      r = hm_q.pop_front();
      hm_rsp_valid <= 1'b1;
      hm_rsp_error <= 1'b0;
      hm_rsp_rdata <= '0;
      if (!hm_in_range(r.addr) || hm_err_addr(r.addr)) begin
        hm_rsp_error <= 1'b1;
        hm_inj_n++;
      end else begin
        automatic int o = int'(r.addr - HM_BASE);
        if (r.write) begin
          for (int b = 0; b < DWB; b++) if (r.wstrb[b]) hm[o + b] = r.wdata[8*b +: 8];       // the write is performed AT acknowledge time
          hm_writes++;
          for (int b = 0; b < DWB; b++) if (r.wstrb[b]) hm_bytes_wr++;
        end else begin
          for (int b = 0; b < DWB; b++) hm_rsp_rdata[8*b +: 8] <= hm[o + b];
          hm_reads++;
          hm_bytes_rd += DWB;
        end
      end
    end
    // ---- request ready: random, at most 4 requests queued
    hm_req_ready <= (hm_q.size() < 4) && (bp_pct == 0 || ($urandom_range(99, 0) >= bp_pct));
  end

  // ================================================================== telemetry consumer
  logic [TLM_W-1:0] tlm_log [$];
  bit force_tlm_stall = 1'b0;                     // scenario knob: the telemetry consumer stops reading
  always @(posedge clk) begin
    if (tlm_valid && tlm_ready) tlm_log.push_back(tlm_data);
    tlm_ready <= !force_tlm_stall && ((cbp_pct == 0) ? 1'b1 : ($urandom_range(99, 0) >= cbp_pct));
  end

  // ================================================================== reference model of PacketCore (test adapter)
  function automatic logic [31:0] crc32_ref(input byte d[$]);
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    foreach (d[i]) begin
      c = c ^ {24'd0, d[i]};
      for (int k = 0; k < 8; k++) c = c[0] ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    end
    return ~c;
  endfunction
  function automatic logic [15:0] csum_ref(input byte d[$]);                // RFC 1071, network byte order, odd tail zero padded
    logic [31:0] s;
    s = 32'd0;
    for (int i = 0; i < d.size(); i += 2) s += {16'd0, d[i], (i + 1 < d.size()) ? d[i+1] : 8'd0};
    while (s[31:16] != 0) s = {16'd0, s[15:0]} + {16'd0, s[31:16]};
    return ~s[15:0];
  endfunction
  function automatic void proc_ref(input byte inp[$], input logic [7:0] pop, input logic [31:0] key, output byte outp[$]);
    outp.delete();
    for (int i = 0; i < inp.size(); i++) begin
      byte b;
      b = inp[i];
      if (pop == PROC_XOR32) b = b ^ key[8*(i % 4) +: 8];
      else if (pop == PROC_BSWAP32) b = inp[(i / 4) * 4 + (3 - (i % 4))];
      outp.push_back(b);
    end
  endfunction

  // ================================================================== scoreboard
  typedef struct {
    int           queue;
    int           tenant;                // tenant that owns the queue
    sfc_cmd_t     cmd;
    bit           exp_ok;                // expected status OK
    logic [7:0]   exp_err;
    byte          exp_out[$];            // expected output bytes (PKT_PROCESS / D2H)
    logic [31:0]  exp_crc_in, exp_crc_out;
    logic [15:0]  exp_csum;
    bit           has_crc;
    bit           dc_on_fail;            // output range is "don't care" if the command fails (host error injected)
    longint       t_submit;
  } exp_t;
  exp_t   sb [longint unsigned];         // key = {queue, tag}
  int     sb_submitted = 0, sb_completed = 0, sb_ok = 0, sb_err = 0;
  longint sb_bytes_ok = 0;
  int     sb_by_err [int];               // error code histogram
  int     sb_order_violations = 0;
  longint unsigned last_tag_q [NQH + 1];
  logic [CPL_W-1:0] cpl_log [$];         // every completion record received (for tests that want to inspect)

  function automatic longint unsigned skey(input int q, input logic [31:0] tag);
    return {32'(q), tag};
  endfunction

  // SRAM back door (read only).  A bank's word is exposed by a continuous assign on a shared index: a variable
  // index into a generate scope is not legal SV.  Fill SRAM through the real data path, never by writing here.
  localparam int BANK_BYTES = SRAMB / NB;
  int            pk_idx = 0;
  logic [DW-1:0] pk_rd [NB];
  genvar gpb;
  generate
    for (gpb = 0; gpb < NB; gpb++) begin : g_pk
      assign pk_rd[gpb] = dut.u_fab.g_bank[gpb].u_bank.u_sram.u_array.g_generic.u_mem.mem[pk_idx];
    end
  endgenerate
  task automatic sram_peek_word(input int a, output logic [DW-1:0] v);          // a = byte address (beat aligned)
    pk_idx = (a % BANK_BYTES) / DWB;
    #1;
    v = pk_rd[a / BANK_BYTES];
  endtask
  task automatic sram_peek_byte(input int a, output byte v);
    logic [DW-1:0] w;
    sram_peek_word(a - (a % DWB), w);
    v = w[8 * (a % DWB) +: 8];
  endtask
  // number of non-zero bytes in [base, base+size) of the SRAM
  task automatic sram_nonzero(input int base, input int size, output int n);
    logic [DW-1:0] w;
    n = 0;
    for (int a = base; a < base + size; a += DWB) begin
      sram_peek_word(a, w);
      for (int b2 = 0; b2 < DWB; b2++) if (w[8*b2 +: 8] != 8'd0) n++;
    end
  endtask

  // ---- build the expectation for a command from the TB's view of memory and configuration
  task automatic expect_cmd(input int q, input int tenant, input sfc_cmd_t c, input bit exp_ok, input logic [7:0] exp_err,
                            input bit dc_on_fail);
    exp_t e;
    byte  inb[$], outb[$];
    longint unsigned k;
    // queue locals are cleared explicitly: Verilator 5.020 keeps them across calls of an automatic task
    inb.delete();  outb.delete();
    e.queue = q;  e.tenant = tenant;  e.cmd = c;  e.exp_ok = exp_ok;  e.exp_err = exp_err;  e.dc_on_fail = dc_on_fail;
    e.has_crc = 1'b0;  e.t_submit = cyc;
    e.exp_out.delete();
    if (exp_ok && (c.opcode == OP_PKT_PROCESS || c.opcode == OP_DMA_H2D)) begin
      for (int i = 0; i < int'(c.length); i++) inb.push_back(exp_mem[int'(c.src - HM_BASE) + i]);
    end
    if (exp_ok && c.opcode == OP_PKT_PROCESS) begin
      proc_ref(inb, c.proc_op, c.param, outb);
      e.exp_out = outb;
      e.exp_crc_in = crc32_ref(inb);  e.exp_crc_out = crc32_ref(outb);  e.exp_csum = csum_ref(outb);  e.has_crc = 1'b1;
    end
    k = skey(q, c.tag);
    if (sb.exists(k)) fail($sformatf("testbench bug: duplicate (queue %0d, tag %0h) outstanding", q, c.tag));
    sb[k] = e;
    sb_submitted++;
  endtask

  // ---- check a completion record against the expectation and against the committed memory
  task automatic on_completion(input int q, input sfc_cpl_t c);
    longint unsigned k;
    exp_t e;
    cpl_log.push_back(c);
    k = skey(q, c.tag);
    sb_completed++;
    if (c.err != 0) begin if (sb_by_err.exists(int'(c.err))) sb_by_err[int'(c.err)]++; else sb_by_err[int'(c.err)] = 1; end
    if (!sb.exists(k)) begin
      fail($sformatf("completion for unknown (queue %0d, tag %0h): status %0h err %0h", q, c.tag, c.status, c.err));
      return;
    end
    e = sb[k];
    sb.delete(k);
    check($sformatf("cpl q%0d tag %0h queue field", q, c.tag), c.queue, q);
    check($sformatf("cpl q%0d tag %0h tenant field (queue binding)", q, c.tag), c.tenant, e.tenant);
    check($sformatf("cpl q%0d tag %0h opcode", q, c.tag), c.opcode, e.cmd.opcode);
    if (e.exp_ok) begin
      check($sformatf("cpl q%0d tag %0h status OK (err=%0h)", q, c.tag, c.err), c.status, ST_OK);
      check($sformatf("cpl q%0d tag %0h err", q, c.tag), c.err, ERR_NONE);
      sb_ok++;
      if (c.opcode == OP_PKT_PROCESS || c.opcode == OP_DMA_D2H || c.opcode == OP_DMA_H2D)
        check($sformatf("cpl q%0d tag %0h bytes", q, c.tag), c.bytes, e.cmd.length);
      if (op_writes_host(c.opcode)) begin
        check_true($sformatf("cpl q%0d tag %0h COMMITTED flag", q, c.tag), c.flags[CPL_FLAG_COMMITTED]);
        sb_bytes_ok += e.cmd.length;
      end
      if (e.has_crc) begin
        check($sformatf("cpl q%0d tag %0h crc_in", q, c.tag), c.crc_in, e.exp_crc_in);
        check($sformatf("cpl q%0d tag %0h crc_out", q, c.tag), c.crc_out, e.exp_crc_out);
        check($sformatf("cpl q%0d tag %0h csum", q, c.tag), c.csum, e.exp_csum);
      end
      // COMMIT-BEFORE-COMPLETION: the destination must already hold the final data NOW
      if (c.opcode == OP_PKT_PROCESS) begin
        int bad = 0;
        for (int i = 0; i < int'(e.cmd.length); i++) begin
          if (hm[int'(e.cmd.dst - HM_BASE) + i] !== e.exp_out[i]) bad++;
          exp_mem[int'(e.cmd.dst - HM_BASE) + i] = e.exp_out[i];
        end
        check($sformatf("cpl q%0d tag %0h output bytes already committed at completion (mismatches)", q, c.tag), bad, 0);
      end
    end else begin
      check($sformatf("cpl q%0d tag %0h status ERROR", q, c.tag), c.status, (e.exp_err == ERR_RESET_ABORT) ? ST_ABORTED : ST_ERROR);
      check($sformatf("cpl q%0d tag %0h error code", q, c.tag), c.err, e.exp_err);
      check_true($sformatf("cpl q%0d tag %0h not COMMITTED on error", q, c.tag), !c.flags[CPL_FLAG_COMMITTED]);
      sb_err++;
      if (e.dc_on_fail && op_writes_host(e.cmd.opcode))
        for (int i = 0; i < int'(e.cmd.length); i++) dc_mem[int'(e.cmd.dst - HM_BASE) + i] = 1'b1;
    end
  endtask

  // ---- completion consumer with random back-pressure (registered ready)
  always @(posedge clk) begin
    for (int q = 0; q < NQH; q++) begin
      if (vio_cpl_valid[q] && vio_cpl_ready[q]) begin
        sfc_cpl_t cc;
        cc = vio_cpl_data[q*CPL_W +: CPL_W];
        on_completion(q, cc);
      end
      vio_cpl_ready[q] <= cons_en[q] && ((cbp_pct == 0) ? 1'b1 : ($urandom_range(99, 0) >= cbp_pct));
    end
  end
  bit cons_en [NQH];
  initial for (int q = 0; q < NQH; q++) cons_en[q] = 1'b1;

  // ---- compare the whole host memory against the shadow image
  task automatic compare_memory(input string where);
    int bad = 0;
    for (int i = 0; i < HM_BYTES; i++) if (!dc_mem[i] && hm[i] !== exp_mem[i]) begin
      if (bad < 4) $display("[%0d] TB   memory mismatch at %0h: have %0h expect %0h", cyc, HM_BASE + i, hm[i], exp_mem[i]);
      bad++;
    end
    check($sformatf("host memory equals shadow image after %s (mismatching bytes)", where), bad, 0);
  endtask

  // ================================================================== VIO submit BFM
  // The submission port is ONE physical bus shared by every queue (vio_sub_q selects the queue).  Scenarios that run
  // several traffic generators concurrently (multi, isolation) must therefore take turns: sub_busy is the bus lock.
  // (No time control sits between the test of sub_busy and its assignment, so the lock is atomic in this scheduler.)
  bit sub_busy = 1'b0;
  task automatic vio_submit_raw(input int q, input sfc_cmd_t c);
    while (sub_busy) @(negedge clk);
    sub_busy = 1'b1;
    @(negedge clk);
    vio_sub_valid = 1'b1; vio_sub_q = 4'(q); vio_sub_cmd = c;
    #1;
    while (!vio_sub_ready) begin @(negedge clk); #1; end
    @(posedge clk);
    #1;
    vio_sub_valid = 1'b0;
    sub_busy = 1'b0;
  endtask
  task automatic submit(input int q, input int tenant, input sfc_cmd_t c, input bit exp_ok, input logic [7:0] exp_err,
                        input bit dc_on_fail = 1'b0);
    expect_cmd(q, tenant, c, exp_ok, exp_err, dc_on_fail);
    vio_submit_raw(q, c);
  endtask
  function automatic sfc_cmd_t mk(input logic [7:0] op, input int tenant, input logic [31:0] tag, input longint unsigned src,
                                  input longint unsigned dst, input int len, input int soff, input logic [7:0] pop = 8'd0,
                                  input logic [31:0] param = 32'd0);
    sfc_cmd_t c;
    c = '0;
    c.opcode = op;  c.tenant = 4'(tenant);  c.tag = tag;  c.src = 64'(src);  c.dst = 64'(dst);
    c.length = 32'(len);  c.sram_off = 32'(soff);  c.proc_op = pop;  c.param = param;
    return c;
  endfunction

  task automatic drain(input int max_cycles);
    longint t0 = cyc;
    while (sb.size() > 0 && cyc - t0 < max_cycles) @(posedge clk);
    if (sb.size() > 0) begin
      fail($sformatf("drain timeout: %0d commands never completed", sb.size()));
      foreach (sb[k]) $display("      outstanding: queue %0d tag %0h op %0h", sb[k].queue, sb[k].cmd.tag, sb[k].cmd.opcode);
    end
    repeat (8) @(posedge clk);
  endtask

  // ================================================================== tenant configuration helpers (management host)
  int sram_base_of [NT], sram_size_of [NT];
  task automatic tenant_set_win(input int t, input int w, input longint unsigned base, input int unsigned size, input bit r, input bit wr);
    rw(1, 'h100 * t + 'h20 + 'h10 * w + 0, base[31:0]);
    rw(1, 'h100 * t + 'h20 + 'h10 * w + 4, base[63:32]);
    rw(1, 'h100 * t + 'h20 + 'h10 * w + 8, size);
    rw(1, 'h100 * t + 'h20 + 'h10 * w + 12, {29'd0, wr, r, 1'b1});
    tw_base[t][w] = base;  tw_size[t][w] = size;  tw_v[t][w] = 1'b1;  tw_r[t][w] = r;  tw_w[t][w] = wr;
  endtask
  task automatic tenant_clear_win_model(input int t);
    for (int w = 0; w < NW; w++) tw_v[t][w] = 1'b0;
  endtask
  task automatic tenant_set_part(input int t, input int base, input int size);
    rw(1, 'h100 * t + 'h0C, 32'(base));
    rw(1, 'h100 * t + 'h10, 32'(size));
    sram_base_of[t] = base;  sram_size_of[t] = size;
  endtask
  task automatic tenant_cmd(input int t, input logic [31:0] cmd);
    rw(1, 'h100 * t + 'h04, cmd);
  endtask
  task automatic tenant_state(input int t, output int st);
    logic [31:0] v;
    rr(1, 'h100 * t, v);
    st = int'(v[2:0]);
  endtask
  task automatic wait_tenant_state(input int t, input int st, input int max_cycles);
    longint t0 = cyc;
    int     cur;
    tenant_state(t, cur);
    while (cur != st && cyc - t0 < max_cycles) begin repeat (4) @(posedge clk); tenant_state(t, cur); end
    check($sformatf("tenant %0d reaches state %0d", t, st), cur, st);
  endtask
  // COMMIT and wait for the result.  CFG_OK: also wait for the scrub of the new partition to finish.
  task automatic tenant_commit(input int t, output logic [7:0] cfg);
    logic [31:0] v;
    longint t0;
    tenant_cmd(t, TCMD_COMMIT);
    t0 = cyc;
    repeat (3) @(posedge clk);
    rr(1, 'h100 * t + 'h08, v);
    while (v[7:0] == CFG_NONE && cyc - t0 < 10_000) begin repeat (2) @(posedge clk); rr(1, 'h100 * t + 'h08, v); end
    cfg = v[7:0];
    if (cfg == CFG_OK) begin
      rr(1, 'h100 * t, v);
      while (!(v[2:0] == TS_DISABLED && v[8]) && cyc - t0 < 600_000) begin repeat (8) @(posedge clk); rr(1, 'h100 * t, v); end
      check($sformatf("tenant %0d configured and scrubbed", t), v[8], 1'b1);
    end
  endtask
  task automatic tenant_bringup(input int t, output logic [7:0] cfg);
    int st;
    tenant_commit(t, cfg);
    if (cfg == CFG_OK) begin
      tenant_cmd(t, TCMD_ENABLE);
      tenant_state(t, st);
      check($sformatf("tenant %0d ACTIVE", t), st, int'(TS_ACTIVE));
    end
  endtask
  task automatic dpu_enable(input bit en);
    rw(0, int'(DPU_G_CTRL), {31'd0, en});
  endtask
  // default two-window plan per tenant: window 0 = input area (R), window 1 = output area (RW)
  function automatic longint unsigned in_base(input int t);   return HM_BASE + 64'h1_0000 * (2 * t); endfunction
  function automatic longint unsigned out_base(input int t);  return HM_BASE + 64'h1_0000 * (2 * t + 1); endfunction
  task automatic default_tenant(input int t, input int sbase, input int ssize);
    logic [7:0] cfg;
    tenant_set_part(t, sbase, ssize);
    tenant_set_win(t, 0, in_base(t),  32'h1_0000, 1'b1, 1'b0);          // 64 KiB, read only
    if (NW > 1) tenant_set_win(t, 1, out_base(t), 32'h1_0000, 1'b1, 1'b1);   // 64 KiB, read/write
    tenant_bringup(t, cfg);
    check($sformatf("default_tenant %0d CFG_OK", t), cfg, CFG_OK);
  endtask

  // ================================================================== reset / bring-up
  task automatic tb_reset_all();
    rst_n = 1'b0;
    vio_sub_valid = 1'b0;
    sub_busy = 1'b0;
    boot_host_rst = 1'b0;
    hm_q.delete();  hm_rsp_valid = 1'b0;  hm_hold_until = 0;
    hm_inj_lo.delete();  hm_inj_hi.delete();
    force_tlm_stall = 1'b0;
    for (int q = 0; q < NQH; q++) cons_en[q] = 1'b1;
    sb.delete();  tlm_log.delete();
    for (int t = 0; t < NT; t++) for (int w = 0; w < NW; w++) tw_v[t][w] = 1'b0;
    repeat (6) @(posedge clk);
    rst_n = 1'b1;
    repeat (40) @(posedge clk);
  endtask
  task automatic do_reset();
    rst_n = 1'b0;
    vio_sub_valid = 1'b0;
    repeat (6) @(posedge clk);
    rst_n = 1'b1;
    repeat (40) @(posedge clk);
    // the host port stalls until the system domain is up; the first access succeeds only afterwards
  endtask

  // ================================================================== scenarios
  `include "dpu_tests.svh"

  // ================================================================== watchdog and main
  longint timeout;
  initial begin
    if (!$value$plusargs("timeout=%d", timeout)) timeout = 60_000_000;
    wait (cyc > timeout);
    $display("TB RESULT FAIL TIMEOUT at cycle %0d (outstanding %0d)", cyc, sb.size());
    $fatal(1, "timeout");
  end

  initial begin
    string t;
    int pos;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    void'($value$plusargs("bp=%d", bp_pct));
    void'($value$plusargs("cbp=%d", cbp_pct));
    void'($value$plusargs("lat=%d", lat_max));
    if (!$value$plusargs("test=%s", tests)) tests = "smoke";
    void'($urandom(seed));
    for (int q = 0; q < NQH + 1; q++) last_tag_q[q] = 0;
    for (int t2 = 0; t2 < NT; t2++) for (int w = 0; w < NW; w++) begin tw_v[t2][w] = 1'b0; tw_r[t2][w] = 1'b0; tw_w[t2][w] = 1'b0; tw_base[t2][w] = 0; tw_size[t2][w] = 0; end
    hm_init();
    $display("TB config: NT=%0d NNQ=%0d NCQ=%0d NS=%0d DW=%0d AW=%0d NW=%0d NB=%0d SRAM=%0d QD=%0d CD=%0d seed=%0d bp=%0d cbp=%0d lat=%0d tests=%s",
             NT, NNQ, NCQ, NS, DW, AW, NW, NB, SRAMB, QD, CD, seed, bp_pct, cbp_pct, lat_max, tests);
    // CRC / checksum reference self-check (CRC-32("123456789") = CBF43926; RFC 1071 example)
    begin
      byte v[$];
      string chk;
      chk = "123456789";
      for (int i = 0; i < chk.len(); i++) v.push_back(byte'(chk[i]));
      check("crc32_ref(123456789)", crc32_ref(v), 32'hCBF4_3926);
      v.delete();
      v = '{8'h00, 8'h01, 8'hf2, 8'h03, 8'hf4, 8'hf5, 8'hf6, 8'hf7};
      check("csum_ref(RFC1071 sample)", csum_ref(v), 16'h220d);
    end
    do_reset();
    while (tests.len() > 0) begin
      pos = 0;
      while (pos < tests.len() && tests[pos] != ",") pos++;
      t = tests.substr(0, pos - 1);
      tests = (pos < tests.len()) ? tests.substr(pos + 1, tests.len() - 1) : "";
      run_test(t);
    end
    compare_memory("all scenarios");
    $display("TB SUMMARY submitted=%0d completed=%0d ok=%0d err=%0d host_reads=%0d host_writes=%0d checks=%0d",
             sb_submitted, sb_completed, sb_ok, sb_err, hm_reads, hm_writes, cnt.checks);
    if (cnt.fails == 0) begin $display("TB RESULT PASS"); $finish(0); end
    else begin $display("TB RESULT FAIL fails=%0d", cnt.fails); $fatal(1, "failed"); end
  end
endmodule
