// =============================================================================
// CloudDPU firmware system scenario (included only with -DWITH_FW).
//
// The REAL boot ROM and the compiled control firmware (firmware/build/dpu_fw.hex) run on the RTL RV32IM CPU of the
// ControlCore.  The testbench is the HOST:
//   1. waits for the boot ROM (WAIT_IMAGE), writes the firmware image into IMEM through the host port, rings IMAGE_READY,
//      the ROM checks header + CRC32 and starts it;
//   2. waits for HOST_READY and checks the device identification the firmware publishes;
//   3. configures a tenant through the firmware (DPUCMD_CONFIG), runs the firmware's own self-test on the CPU, and
//      then independently recomputes, from the testbench's own memory image, what every firmware-driven command must have
//      written to host memory;
//   4. drives commands through the firmware (DPUCMD_SUBMIT), including an isolation violation, and reads back the fault
//      report, the recovery flow and the performance counters;
//   5. shuts the run down (SHUTDOWN) and checks the TEST_CTRL pins.
// Everything the firmware says is checked against the testbench's reference model, never taken on trust.
// =============================================================================
string fw_con_line = "";
string fw_con_all  = "";
always @(posedge clk) if (diag_valid) begin
  if (diag_char == 8'h0A) begin
    $display("[%0d] FW| %s", cyc, fw_con_line);
    fw_con_all = {fw_con_all, fw_con_line, "\n"};
    fw_con_line = "";
  end else fw_con_line = {fw_con_line, string'(diag_char)};
end

logic [31:0] fw_img [$];
logic [31:0] fw_rsp [8];
task automatic hwr(input logic [31:0] a, input logic [31:0] d);
  logic [31:0] r; bit e;
  host_access(1'b1, a, d, r, e);
  if (e) fail($sformatf("host write %08h refused", a));
endtask
task automatic hrd(input logic [31:0] a, output logic [31:0] d);
  bit e;
  host_access(1'b0, a, 32'd0, d, e);
  if (e) fail($sformatf("host read %08h refused", a));
endtask
task automatic fw_wait_stage(input logic [31:0] st, input longint tmo);
  logic [31:0] v;
  longint t0 = cyc;
  forever begin
    hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v);
    if (v == st) break;
    if (cyc - t0 > tmo) begin fail($sformatf("timeout waiting for boot stage %0h (at %0h)", st, v)); break; end
    repeat (200) @(posedge clk);
  end
endtask
task automatic fw_mbox_wait(input longint tmo);
  longint t0 = cyc;
  while (!host_irq) begin
    @(posedge clk);
    if (cyc - t0 > tmo) begin fail("timeout waiting for the firmware"); return; end
  end
  for (int i = 0; i < 8; i++) hrd(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 32'(4 * i), fw_rsp[i]);
  hwr(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
endtask
task automatic fw_mbox(input logic [31:0] cmd, input logic [31:0] a1, input logic [31:0] a2, input logic [31:0] a3,
                       input logic [31:0] a4, input logic [31:0] a5, input logic [31:0] a6, input logic [31:0] a7, input longint tmo);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4,  a1);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 8,  a2);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 12, a3);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 16, a4);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 20, a5);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 24, a6);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 28, a7);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd);
  hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd);
  fw_mbox_wait(tmo);
  check($sformatf("firmware answered command %02h (echo)", cmd), (fw_rsp[0] >> 8) & 32'hFF, cmd);
endtask

// reference: the PacketCore test adapter on a byte string taken from the testbench's host-memory image
task automatic fw_expect_pkt(input longint unsigned src, input longint unsigned dst, input int len, input logic [7:0] pop, input logic [31:0] key,
                             output logic [31:0] crc_in, output logic [31:0] crc_out, output logic [15:0] csum);
  byte inb[$], outb[$];
  inb.delete();  outb.delete();
  for (int i = 0; i < len; i++) inb.push_back(exp_mem[int'(src - HM_BASE) + i]);
  proc_ref(inb, pop, key, outb);
  for (int i = 0; i < len; i++) exp_mem[int'(dst - HM_BASE) + i] = outb[i];
  crc_in = crc32_ref(inb);  crc_out = crc32_ref(outb);  csum = csum_ref(outb);
endtask

task automatic t_fw();
  string fw_path;
  int fd;
  logic [31:0] w, v, ci, co;
  logic [15:0] cs;
  bit e;
  int part = SRAMB / NT;
  longint unsigned ib = in_base(0), ob = out_base(0);
  logic [31:0] ib32 = ib[31:0];
  if (!$value$plusargs("fw=%s", fw_path)) begin fail("+fw=<image.hex> is required"); return; end
  fd = $fopen(fw_path, "r");
  if (fd == 0) begin fail({"cannot open ", fw_path}); return; end
  fw_img.delete();
  while ($fscanf(fd, "%h\n", w) == 1) fw_img.push_back(w);
  $fclose(fd);
  $display("      fw: image %s, %0d words", fw_path, fw_img.size());
  // the windows the firmware will program, for the independent permission monitor
  tw_base[0][0] = ib;  tw_size[0][0] = 32'h1_0000;  tw_v[0][0] = 1'b1;  tw_r[0][0] = 1'b1;  tw_w[0][0] = 1'b0;
  tw_base[0][1] = ob;  tw_size[0][1] = 32'h1_0000;  tw_v[0][1] = 1'b1;  tw_r[0][1] = 1'b1;  tw_w[0][1] = 1'b1;

  $display("      fw: boot from the host: ROM waits for the image, host loads it, ROM verifies (CRC32) and starts it");
  fw_wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 3_000_000);
  for (int i = 0; i < fw_img.size(); i++) hwr(CC_IMEM_BASE + 32'(4 * i), fw_img[i]);
  fw_mbox(CC_MBOX_CMD_IMAGE_READY, 0, 0, 0, 0, 0, 0, 0, 4_000_000);
  check("ROM accepted the image", fw_rsp[0][7:0], CC_MBOX_STS_OK);
  begin
    longint t0 = cyc;
    while (!host_ready && cyc - t0 < 8_000_000) @(posedge clk);
    check_true("HOST_READY reached", host_ready);
    fw_mbox_wait(2000);                                      // unsolicited ready notification with the device identification
  end
  $display("      fw: device identification published by the firmware");
  check("ready notification status OK (POST passed)", fw_rsp[0][7:0], CC_MBOX_STS_OK);
  check("ID", fw_rsp[1], DPU_ID_MAGIC);
  check("version", fw_rsp[2], {DPU_ABI_MAJOR, DPU_ABI_MINOR});
  check("CONFIG0", fw_rsp[3], {8'(NS), 8'(NCQ), 8'(NNQ), 8'(NT)});
  check("CONFIG1", fw_rsp[4], {8'(NW), 8'(AW), 16'(DW)});
  check("BLOCK_STATUS (inference/crypto/storage blocked, packetcore test adapter)", fw_rsp[5][11:0], {BLK_BLOCKED, BLK_BLOCKED, BLK_BLOCKED, BLK_TEST_ADAPTER, BLK_REAL, BLK_TEST_ADAPTER});
  hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v);  check("boot stage HOST_READY", v, CC_BOOT_STAGE_HOST_READY);
  host_access(1'b1, CC_IMEM_BASE, 32'h0, v, e);  check_true("host write to IMEM refused after the firmware set the write lock", e);
  check_true("firmware POST line on the console", fw_con_all.len() > 0);
  fw_mbox(DPUCMD_INFO, 0, 0, 0, 0, 0, 0, 0, 1_000_000);
  check("INFO status", fw_rsp[0][7:0], CC_MBOX_STS_OK);  check("INFO sram bytes", fw_rsp[5], SRAMB);

  $display("      fw: configure tenant 0 through the firmware");
  fw_mbox(DPUCMD_CONFIG, 0, ib32, 32'(part), 0, 0, 0, 0, 20_000_000);
  check("CONFIG status OK", fw_rsp[0][7:0], CC_MBOX_STS_OK);
  check("CONFIG commit result", fw_rsp[1], CFG_OK);
  check("tenant ACTIVE", fw_rsp[2], TS_ACTIVE);
  rr(1, 'h0C, v);  check("firmware programmed SRAM_BASE", v, 0);
  rr(1, 'h10, v);  check("firmware programmed SRAM_SIZE", v, part);
  rr(0, int'(DPU_G_CTRL), v);  check("dispatch enabled by the firmware", v[0], 1'b1);
  rr(0, int'(DPU_G_FAULT_ENABLE), v);  check_true("fault interrupts enabled by the firmware", v[FLT_PERM_VIOL] && v[FLT_HOST_ERR]);

  $display("      fw: firmware self-test on the RTL CPU (identity, MMIO, PKT with SRAM cross-check, errors, isolation, perf, reset, IRQ)");
  fw_mbox(DPUCMD_SELFTEST, 0, 0, 0, 0, 0, 0, 0, 120_000_000);
  check("SELFTEST answered OK", fw_rsp[0][7:0], CC_MBOX_STS_OK);
  check_true("SELFTEST ran a meaningful number of checks", fw_rsp[1] > 80);
  check("SELFTEST: firmware-reported failures", fw_rsp[2], 0);
  $display("      fw: self-test checks=%0d fails=%0d", fw_rsp[1], fw_rsp[2]);
  // the host-visible effects of the firmware's own PKT commands: recompute them independently
  begin
    logic [7:0]  c_pop [6];
    int          c_len [6];
    logic [31:0] c_key [6];
    // the six cases of firmware/app/dpu_selftest.c::t_pkt (transform, length, key)
    c_pop[0] = PROC_PASS;    c_len[0] = 64;    c_key[0] = 32'h0;
    c_pop[1] = PROC_XOR32;   c_len[1] = 61;    c_key[1] = 32'hC3A5F00F;
    c_pop[2] = PROC_BSWAP32; c_len[2] = 128;   c_key[2] = 32'h0;
    c_pop[3] = PROC_XOR32;   c_len[3] = 1;     c_key[3] = 32'h000000FF;
    c_pop[4] = PROC_PASS;    c_len[4] = 1500;  c_key[4] = 32'h0;
    c_pop[5] = PROC_BSWAP32; c_len[5] = 1496;  c_key[5] = 32'h0;
    for (int i = 0; i < 6; i++) fw_expect_pkt(ib + 64 * i, ob + 2048 * i, c_len[i], c_pop[i], c_key[i], ci, co, cs);
    fw_expect_pkt(ib, ob + 32'h8000, 100, PROC_XOR32, 32'h01020304, ci, co, cs);          // the self-test's data-plane-reset check
  end
  compare_memory("firmware self-test (host memory written by firmware-submitted commands)");

  $display("      fw: host-driven commands through the firmware");
  begin
    longint unsigned s = ib + 4096, d = ob + 32'h4000;
    fw_expect_pkt(s, d, 700, PROC_XOR32, 32'hDEADBEEF, ci, co, cs);
    fw_mbox(DPUCMD_SUBMIT, {8'd0, 4'd0, 4'd0, PROC_XOR32, OP_PKT_PROCESS}, 32'hFEED_0001, s[31:0], d[31:0], 700, 0, 32'hDEADBEEF, 20_000_000);
    check("SUBMIT status OK", fw_rsp[0][7:0], CC_MBOX_STS_OK);
    check("completion tag", fw_rsp[2], 32'hFEED_0001);
    check("completion status/err", fw_rsp[1][23:8], 16'h0000);
    check("completion committed", fw_rsp[3][16], 1'b1);
    check("completion bytes", fw_rsp[4], 700);
    check("completion crc_in", fw_rsp[5], ci);
    check("completion crc_out", fw_rsp[6], co);
    check("completion csum", fw_rsp[7][15:0], cs);
    compare_memory("firmware-submitted PKT (output committed before the firmware saw the completion)");
    // an isolation violation submitted through the firmware: refused, reported, quarantine
    fw_mbox(DPUCMD_SUBMIT, {8'd0, 4'd0, 4'd0, PROC_PASS, OP_PKT_PROCESS}, 32'hFEED_0002, ib32 + 32'h20_0000, d[31:0] + 32'h2000, 64, 0, 0, 20_000_000);
    check("violating SUBMIT reports an error status", fw_rsp[0][7:0], CC_MBOX_STS_ACC_ERROR);
    check("violation: ERR_PERM_READ", fw_rsp[1][23:16], ERR_PERM_READ);
    check("violation: not committed", fw_rsp[3][16], 1'b0);
    repeat (300) @(posedge clk);
    fw_mbox(DPUCMD_SUBMIT, {8'd0, 4'd0, 4'd0, 8'd0, OP_NOP}, 32'hFEED_0003, 0, 0, 0, 0, 0, 20_000_000);
    check("quarantined tenant: ERR_QUARANTINED", fw_rsp[1][23:16], ERR_QUARANTINED);
    $display("      fw: fault report to the host");
    fw_mbox(DPUCMD_FAULTS, 0, 0, 0, 0, 0, 0, 0, 2_000_000);
    check_true("fault bits include PERM_VIOL", fw_rsp[1][FLT_PERM_VIOL]);
    check_true("fault IRQ delivered to the CPU", fw_rsp[6] > 0);
    check("last fault tenant", fw_rsp[3], 0);
    check("last fault error code", fw_rsp[4], ERR_PERM_READ);
    check("last fault address low word", fw_rsp[5], ib32 + 32'h20_0000);
    // the ControlCore RAS block saw the DPU warning (FAULT_WARN routes PERM_VIOL to its warning input)
    hrd(CC_RAS_BASE + CC_RAS_WARN_COUNT, v);  check_true("the DPU violation reached the ControlCore RAS block (warning count > 0)", v > 0);
    fw_mbox(DPUCMD_RECOVER, 0, 0, 0, 0, 0, 0, 0, 40_000_000);
    check("RECOVER: tenant ACTIVE again", fw_rsp[1], TS_ACTIVE);
    begin
      longint unsigned d2 = ob + 32'h6000;
      fw_expect_pkt(ib, d2, 333, PROC_XOR32, 32'h12345678, ci, co, cs);
      fw_mbox(DPUCMD_SUBMIT, {8'd0, 4'd0, 4'd0, PROC_XOR32, OP_PKT_PROCESS}, 32'hFEED_0004, ib32, d2[31:0], 333, 0, 32'h12345678, 20_000_000);
    end
    check("after recovery the tenant works again", fw_rsp[0][7:0], CC_MBOX_STS_OK);
    check("after recovery crc_out", fw_rsp[6], co);
    fw_mbox(DPUCMD_PERF, 0, 0, 0, 0, 0, 0, 0, 2_000_000);
    check_true("perf: commands retired > 0", fw_rsp[2] > 0);
    check_true("perf: DMA bytes counted", fw_rsp[4] > 0 && fw_rsp[5] > 0);
    check_true("perf: violations counted", fw_rsp[6] >= 1);
    fw_mbox(DPUCMD_RECOVER, 32'hFF, 0, 0, 0, 0, 0, 0, 2_000_000);
    check_true("data-plane reset counted", fw_rsp[1] >= 2);
  end
  compare_memory("firmware system scenario");

  $display("      fw: shutdown");
  fw_mbox(CC_MBOX_CMD_SHUTDOWN, 32'(cnt.fails), 0, 0, 0, 0, 0, 0, 1_000_000);
  repeat (20) @(posedge clk);
  check("TEST_CTRL done", test_done, 1);
  check("TEST_CTRL fail", test_fail, 0);
  check_true("firmware console shows the PASS verdict", fw_con_all.len() > 0);
endtask
