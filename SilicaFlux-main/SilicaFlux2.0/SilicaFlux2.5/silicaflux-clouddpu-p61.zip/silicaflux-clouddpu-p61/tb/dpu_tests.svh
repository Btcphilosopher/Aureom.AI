// =============================================================================
// CloudDPU test scenarios (included inside tb_dpu).  Every scenario is self-checking through the scoreboard,
// the shadow memory image and explicit register / SRAM checks.  Scenarios that need more than one tenant, queue
// or DMA channel check the configuration first and say "SKIP" (not "pass") when the build does not have them.
// =============================================================================

int unsigned next_tag = 32'h0000_1000;
function automatic logic [31:0] ntag();
  next_tag++;
  return next_tag;
endfunction

// ---------------------------------------------------------------- small helpers
function automatic int rnd(input int lo, input int hi);
  return $urandom_range(hi, lo);
endfunction
function automatic int al(input int v);                    // round down to a beat
  return v - (v % DWB);
endfunction
function automatic int al_up(input int v);
  return ((v + DWB - 1) / DWB) * DWB;
endfunction
function automatic longint unsigned in_addr(input int t, input int off);  return in_base(t) + off;  endfunction
function automatic longint unsigned out_addr(input int t, input int off); return out_base(t) + off; endfunction

// SRAM checksum of [base, base+size) through the back door
task automatic sram_sum(input int base, input int size, output logic [63:0] h);
  logic [DW-1:0] w;
  h = 64'hCBF2_9CE4_8422_2325;
  for (int a = base; a < base + size; a += DWB) begin
    sram_peek_word(a, w);
    for (int b2 = 0; b2 < DWB; b2++) h = (h ^ {56'd0, w[8*b2 +: 8]}) * 64'h0000_0100_0000_01B3;
  end
endtask

// host-side snapshot of the perf counters
task automatic perf_get(input int k, output logic [63:0] v);
  rr64(4, 'h010 + 8 * k, v);
endtask
task automatic perf_clear();
  rw(4, 0, 32'h2);
endtask
task automatic fault_status(output logic [31:0] v);
  rr(0, int'(DPU_G_FAULT_STATUS), v);
endtask

// Is any command of tenant t that is still outstanding (submitted, no completion seen yet) using SRAM staging bytes in
// [lo, hi) or writing the host destination slot `dst`?  Commands of a queue are not ordered when there are several DMA
// channels, and one slot can finish several short commands while another is still running a long one, so "at most NS
// commands overlap in time" is NOT a safe assumption: a generator must wait until the previous owner of a staging buffer
// or destination slot has completed.  (Staging and destinations are the submitter's responsibility, as in NVMe.)
function automatic bit staging_busy(input int t, input int lo, input int hi, input longint unsigned dst);
  bit busy = 1'b0;
  int nlo, nhi;
  foreach (sb[k]) begin
    if (sb[k].tenant == t && (sb[k].cmd.opcode == OP_PKT_PROCESS || sb[k].cmd.opcode == OP_DMA_H2D || sb[k].cmd.opcode == OP_DMA_D2H)) begin
      nlo = int'(sb[k].cmd.sram_off);
      nhi = nlo + ((sb[k].cmd.opcode == OP_PKT_PROCESS) ? 2 : 1) * al_up(int'(sb[k].cmd.length));
      if (nlo < hi && lo < nhi) busy = 1'b1;
      if ((sb[k].cmd.opcode == OP_PKT_PROCESS || sb[k].cmd.opcode == OP_DMA_D2H) && longint'(sb[k].cmd.dst) == longint'(dst)) busy = 1'b1;
    end
  end
  return busy;
endfunction

// run N PKT_PROCESS commands on queue q/tenant t with random sizes, ops and offsets; drain afterwards
// Staging buffers are 8 KiB (in + out, up to 4 KiB each) and destinations 4 KiB slots; every command that can be in
// flight at the same time gets its own, so the shadow image has one unambiguous expectation.  A queue that shares its
// tenant with another queue uses the half selected by `half` (0/1).
task automatic rand_traffic(input int q, input int t, input int n, input bit concurrent = 1'b0, input int half = 0);
  logic [31:0] key;
  logic [7:0]  pop;
  int          len, soff, k;
  longint unsigned src, dst;
  int part = sram_size_of[t];
  int nbuf = part / 8192;
  int nuse = (nbuf >= 8) ? 4 : ((nbuf > 0) ? ((nbuf > 4) ? 4 : nbuf) : 1);
  int blo  = (nbuf >= 8) ? half * 4 : 0;
  for (int i = 0; i < n; i++) begin
    len = (rnd(0, 3) == 0) ? rnd(1, 64) : rnd(1, MAXX);
    pop = rnd(0, 2);
    if (pop == PROC_BSWAP32) len = (len + 3) & ~3;
    if (len > MAXX) len = MAXX;
    key = $urandom;
    k   = blo + (i % nuse);
    soff = (nbuf > 0) ? k * 8192 : 0;
    src = in_addr(t, al(rnd(0, 32'h1_0000 - 4096)));
    dst = out_addr(t, (half * 8 + (i % 8)) * 4096);
    while (staging_busy(t, soff, soff + 2 * al_up(len), dst)) @(posedge clk);   // previous owner of this buffer / destination done?
    submit(q, t, mk(OP_PKT_PROCESS, t, ntag(), src, dst, len, soff, pop, key), 1'b1, ERR_NONE);
    if (!concurrent && (i % 3) == 2) drain(2_000_000);
  end
  drain(4_000_000);
endtask

// ================================================================================ scenarios
// ---- smoke: one tenant, NOP + one real PKT_PROCESS transaction end to end
task automatic t_smoke();
  default_tenant(0, 0, SRAMB / NT);
  dpu_enable(1'b1);
  submit(0, 0, mk(OP_NOP, 0, 32'h100, 0, 0, 0, 0), 1'b1, ERR_NONE);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, 32'h101, in_base(0), out_base(0), 64, 0, PROC_XOR32, 32'hA5A5_A5A5), 1'b1, ERR_NONE);
  drain(200_000);
  compare_memory("smoke");
endtask

// ---- reset: reset values of every register, idle interfaces, queued work cleared by a host reset
task automatic t_reset();
  logic [31:0] v;
  logic [63:0] v64;
  int st;
  $display("      reset: register reset values");
  rr(0, int'(DPU_G_ID), v);               check("ID = SFDP", v, DPU_ID_MAGIC);
  rr(0, int'(DPU_G_VERSION), v);          check("VERSION", v, {DPU_ABI_MAJOR, DPU_ABI_MINOR});
  rr(0, int'(DPU_G_CONFIG0), v);          check("CONFIG0", v, {8'(NS), 8'(NCQ), 8'(NNQ), 8'(NT)});
  rr(0, int'(DPU_G_CONFIG1), v);          check("CONFIG1", v, {8'(NW), 8'(AW), 16'(DW)});
  rr(0, int'(DPU_G_SRAM_BYTES), v);       check("SRAM_BYTES", v, SRAMB);
  rr(0, int'(DPU_G_MAX_XFER), v);         check("MAX_XFER", v, MAXX);
  rr(0, int'(DPU_G_BLOCK_STATUS), v);
  check("BLOCK_STATUS PACKETCORE = TEST_ADAPTER", v[1:0], BLK_TEST_ADAPTER);
  check("BLOCK_STATUS CLOUDDMA = REAL", v[3:2], BLK_REAL);
  check("BLOCK_STATUS VIRTUALIO = TEST_ADAPTER", v[5:4], BLK_TEST_ADAPTER);
  check("BLOCK_STATUS INFERENCE = BLOCKED", v[7:6], BLK_BLOCKED);
  check("BLOCK_STATUS CRYPTO = BLOCKED", v[9:8], BLK_BLOCKED);
  check("BLOCK_STATUS STORAGE = BLOCKED", v[11:10], BLK_BLOCKED);
  check("BLOCK_STATUS TELEMETRY = REAL", v[13:12], BLK_REAL);
  check("BLOCK_STATUS CONTROLCORE = REAL", v[15:14], BLK_REAL);
  rr(0, int'(DPU_G_FEATURES), v);         check("FEATURES: tensor/crypto/storage all disabled", v[2:0], 3'b000);
  check("FEATURES: permission enforcement always on", v[3], 1'b1);
  check("FEATURES: multi-tenant capable == (NT>1)", v[4], (NT > 1));
  rr(0, int'(DPU_G_CTRL), v);             check("CTRL.EN = 0 after reset", v, 0);
  rr(0, int'(DPU_G_STATUS), v);           check("STATUS idle", v[7:0], 0);
  rr(0, int'(DPU_G_FAULT_STATUS), v);     check("FAULT_STATUS clear", v, 0);
  rr(0, int'(DPU_G_JOB_TIMEOUT), v);      check("JOB_TIMEOUT default", v, 32'h0004_0000);
  rr(0, int'(DPU_G_DP_RESETS), v);        check("DP_RESETS = 0", v, 0);
  for (int t = 0; t < NT; t++) begin
    rr(1, 'h100 * t, v);                  check($sformatf("tenant %0d DISABLED, not configured", t), v[8:0], 9'd0);
    rr(1, 'h100 * t + 'h14, v);           check($sformatf("tenant %0d POLICY default", t), v, 1);
  end
  for (int q = 0; q < NQH; q++) begin
    rr(2, 32 * q, v);                     check($sformatf("queue %0d default binding", q), v, q % NT);
    rr(2, 32 * q + 4, v);                 check($sformatf("queue %0d empty, class", q), v[16:0], (q >= NNQ) ? 17'h10000 : 17'h0);
  end
  rr(5, 0, v);                            check("TLM enabled", v, 1);
  rr(4, 4, v);                            check("PERF INFO", v, {16'd0, 8'(NT), 8'd16});
  check("no completions pending", vio_cpl_valid, 0);
  check("no host memory request after reset", hm_req_valid, 0);
  check("dpu idle after reset", dpu_busy, 0);

  $display("      reset: queued work is discarded by a host reset");
  default_tenant(0, 0, SRAMB / NT);                         // dispatch still disabled (CTRL.EN = 0)
  begin
    int nreq0 = hm_reads + hm_writes;
    cons_en[0] = 1'b1;
    vio_submit_raw(0, mk(OP_NOP, 0, 32'h5000, 0, 0, 0, 0));    // goes into the queue but must NOT run: dispatch disabled
    repeat (200) @(posedge clk);
    rr(2, 4, v);                          check("queued command waits while CTRL.EN = 0", v[7:0], 1);
    check("nothing completed while disabled", vio_cpl_valid, 0);
    check("no host traffic while disabled", hm_reads + hm_writes, nreq0);
  end
  boot_host_rst = 1'b1;  repeat (6) @(posedge clk);  boot_host_rst = 1'b0;
  hm_q.delete();  hm_rsp_valid = 1'b0;                      // a function-level reset also flushes the host link
  repeat (60) @(posedge clk);
  rr(2, 4, v);                            check("queue empty after host reset", v[7:0], 0);
  rr(2, 8, v);                            check("SUBMITTED counter cleared by reset", v, 0);
  tenant_state(0, st);                    check("tenant back to DISABLED after reset", st, int'(TS_DISABLED));
  rr(0, int'(DPU_G_CTRL), v);             check("CTRL.EN back to 0", v, 0);
  sb.delete();
  for (int t = 0; t < NT; t++) for (int w = 0; w < NW; w++) tw_v[t][w] = 1'b0;
endtask

// ---- boot: bring-up sequence of the management plane and the scrub guarantee
task automatic t_boot();
  logic [31:0] v;
  logic [63:0] h0, h1, hb0, hb1;
  int nz, st;
  int sb0 = 0, sz0 = SRAMB / 2 / NT;
  $display("      boot: ID, configure, commit, scrub, enable");
  rr(0, int'(DPU_G_ID), v);  check("ID", v, DPU_ID_MAGIC);
  default_tenant(0, sb0, sz0);
  dpu_enable(1'b1);
  rr(0, int'(DPU_G_CTRL), v);  check("CTRL.EN", v, 1);
  // fill the partition with non-zero data through the real data path (H2D), outside the partition stays untouched
  submit(0, 0, mk(OP_DMA_H2D, 0, ntag(), in_addr(0, 0), 0, 2048, 0), 1'b1, ERR_NONE);
  drain(500_000);
  sram_nonzero(sb0, sz0, nz);
  check_true("partition holds data after H2D", nz > 1000);
  sram_sum(sb0 + sz0, 4096, hb0);                                       // area above the partition
  // teardown: DISABLE -> DRAINING -> SCRUBBING -> DISABLED, partition must read zero afterwards
  tenant_cmd(0, TCMD_DISABLE);
  wait_tenant_state(0, int'(TS_DISABLED), 500_000);
  sram_nonzero(sb0, sz0, nz);
  check("partition scrubbed to zero on teardown (non-zero bytes)", nz, 0);
  sram_sum(sb0 + sz0, 4096, hb1);
  check("SRAM outside the partition untouched by the scrub", hb1, hb0);
  rr(1, 0, v);  check("still configured after teardown", v[8], 1'b1);
  // a command for a disabled tenant is refused cleanly
  submit(0, 0, mk(OP_NOP, 0, ntag(), 0, 0, 0, 0), 1'b0, ERR_TENANT_STATE);
  drain(100_000);
  tenant_cmd(0, TCMD_ENABLE);
  tenant_state(0, st);  check("re-enabled", st, int'(TS_ACTIVE));
  submit(0, 0, mk(OP_NOP, 0, ntag(), 0, 0, 0, 0), 1'b1, ERR_NONE);
  drain(100_000);
  // reconfigure: a new partition position is accepted only after RELEASE or while DISABLED, and is scrubbed again
  tenant_cmd(0, TCMD_DISABLE);
  wait_tenant_state(0, int'(TS_DISABLED), 500_000);
  tenant_set_part(0, 4096, 8192);
  begin logic [7:0] cfg; tenant_commit(0, cfg); check("recommit CFG_OK", cfg, CFG_OK); end
  tenant_cmd(0, TCMD_ENABLE);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 100, 0, PROC_PASS, 0), 1'b1, ERR_NONE);
  drain(500_000);
  compare_memory("boot");
endtask

// ---- mmio: register semantics (access types, shadow registers, W1C, errors)
task automatic t_mmio();
  logic [31:0] v;
  bit e;
  $display("      mmio: read/write registers");
  rw(0, int'(DPU_G_SCRATCH), 32'hDEAD_BEEF);  rr(0, int'(DPU_G_SCRATCH), v);  check("SCRATCH r/w", v, 32'hDEAD_BEEF);
  rw(0, int'(DPU_G_JOB_TIMEOUT), 32'h1234);   rr(0, int'(DPU_G_JOB_TIMEOUT), v);  check("JOB_TIMEOUT r/w", v, 32'h1234);
  rw(0, int'(DPU_G_JOB_TIMEOUT), 32'h0004_0000);
  rw(0, int'(DPU_G_FAULT_ENABLE), 32'hFF);    rr(0, int'(DPU_G_FAULT_ENABLE), v);  check("FAULT_ENABLE r/w", v, 32'hFF);
  rw(0, int'(DPU_G_FAULT_ENABLE), 0);
  rw(0, int'(DPU_G_IRQ_ENABLE), 1);           rr(0, int'(DPU_G_IRQ_ENABLE), v);  check("IRQ_ENABLE r/w", v, 1);
  rw(0, int'(DPU_G_IRQ_ENABLE), 0);
  $display("      mmio: read-only and unmapped registers refuse writes / accesses");
  rw_err(0, int'(DPU_G_ID), 32'h1, e);            check_true("write to ID is a bus error", e);
  rw_err(0, int'(DPU_G_STATUS), 32'h1, e);        check_true("write to STATUS is a bus error", e);
  rw_err(0, int'(DPU_G_TIME_LO), 32'h1, e);       check_true("write to TIME_LO is a bus error", e);
  rr_err(0, 12'h0F0, v, e);                       check_true("read of an unmapped GLOBAL offset is a bus error", e);
  rr_err(0, 12'h068, v, e);                       check_true("read of a reserved GLOBAL offset is a bus error", e);
  rw_err(7, 0, 32'h1, e);                         check_true("write to a DEBUG register is a bus error", e);
  rr_err(7, 12'h200, v, e);                       check_true("DEBUG read beyond its registers is a bus error", e);
  rw_err(6, 0, 32'h1, e);                         check_true("write to ENGINES is a bus error", e);
  rr_err(3, 12'h100, v, e);                       check_true("MGMT_CQ unmapped offset is a bus error", e);
  rr_err(5, 12'h100, v, e);                       check_true("TELEMETRY unmapped offset is a bus error", e);
  rr_err(1, 12'h100 * NT, v, e);                  if (NT < 16) check_true("tenant index >= NT is a bus error", e);
  rw_err(1, 'h18, 32'h1, e);                      check_true("tenant VIOL_COUNT is read-only", e);
  rr_err(1, 12'h20 + 12'h10 * NW, v, e);          if (NW < 8) check_true("window index >= NW is a bus error", e);
  rr_err(4, 12'h004, v, e);                       check_true("PERF.INFO read is legal", !e);
  rw_err(4, 12'h010, 32'h1, e);                   check_true("PERF counters are read-only", e);
  $display("      mmio: sticky fault register is W1C, set wins over clear");
  begin
    default_tenant(0, 0, SRAMB / NT);
    dpu_enable(1'b1);
    rw(1, 'h14, 0);                                // no quarantine: this scenario provokes errors
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 0, 0, PROC_PASS, 0), 1'b0, ERR_BAD_LENGTH);
    drain(100_000);
    fault_status(v);  check_true("FLT_DESC_ERR set by a bad length", v[FLT_DESC_ERR]);
    rr(0, int'(DPU_G_FAULT_ERR), v);  check("FAULT_ERR captured", v, ERR_BAD_LENGTH);
    rw(0, int'(DPU_G_FAULT_STATUS), 32'h1 << FLT_DESC_ERR);
    fault_status(v);  check("FAULT_STATUS cleared by W1C", v & (32'h1 << FLT_DESC_ERR), 0);
    rw(0, int'(DPU_G_FAULT_STATUS), 32'hFFFF_FFFF);
    fault_status(v);  check("FAULT_STATUS all clear", v, 0);
  end
  $display("      mmio: shadow configuration registers");
  begin
    logic [31:0] st0;
    rw(1, 'h0C, 32'h2000);  rr(1, 'h0C, v);  check("shadow SRAM_BASE reads back", v, 32'h2000);
    rr(1, 0, st0);
    tenant_cmd(0, TCMD_COMMIT);                    // tenant 0 is ACTIVE: commit refused, nothing changes
    repeat (8) @(posedge clk);
    rr(1, 8, v);  check("COMMIT on an ACTIVE tenant refused: CFG_BUSY", v[7:0], CFG_BUSY);
    rr(1, 0, v);  check("tenant state unchanged by a refused COMMIT", v, st0);
    rw(1, 'h0C, 0);
  end
  $display("      mmio: queue binding rules");
  begin
    rw_err(2, 0, 32'(NT), e);                      check_true("BIND >= NT refused", e);
    rw_err(2, 32 * MGMT_QUEUE_ID, 0, e);           check_true("BIND of the management queue refused", e);
    rr_err(2, 32 * (NQH < 14 ? NQH : 14) + 32, v, e);
    if (NQH < 14) check_true("queue that does not exist is a bus error", e);
    rw_err(2, 0, 32'(0), e);                       check_true("BIND = 0 on an idle queue accepted", !e);
  end
  $display("      mmio: management submit window");
  begin
    for (int w = 0; w < 12; w++) rw(2, 'h800 + 4 * w, 32'hA000_0000 + w);
    for (int w = 0; w < 12; w++) begin rr(2, 'h800 + 4 * w, v); check($sformatf("M_DESC%0d reads back", w), v, 32'hA000_0000 + w); end
  end
  compare_memory("mmio");
endtask

// ---- decode: every error code, no data moved on a rejected descriptor
task automatic t_decode();
  logic [31:0] v;
  int r0, w0;
  logic [63:0] sh0, sh1;
  int part = SRAMB / NT;
  sfc_cmd_t c;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  for (int q = 0; q < NQH; q++) rw(2, 32 * q, 0);           // every queue bound to tenant 0 for this scenario
  rw(1, 'h14, 0);                                           // POLICY: no quarantine, so every case reaches decode
  r0 = hm_reads;  w0 = hm_writes;
  sram_sum(0, part, sh0);
  $display("      decode: descriptor errors (nothing may move)");
  c = mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0);
  submit(0, 0, mk(8'h77, 0, ntag(), 0, 0, 0, 0), 1'b0, ERR_BAD_OPCODE);
  c.w0_rsvd = 12'h1;  c.tag = ntag();                          submit(0, 0, c, 1'b0, ERR_BAD_DESC);
  c = mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0);
  c.flags = 8'h02;                                              submit(0, 0, c, 1'b0, ERR_BAD_DESC);
  c = mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0);
  c.w8_rsvd = 24'h1;                                            submit(0, 0, c, 1'b0, ERR_BAD_DESC);
  c = mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0);
  c.w10_rsvd = 32'h8000_0000;                                   submit(0, 0, c, 1'b0, ERR_BAD_DESC);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 0, 0, PROC_PASS, 0), 1'b0, ERR_BAD_LENGTH);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), MAXX + 1, 0, PROC_PASS, 0), 1'b0, ERR_BAD_LENGTH);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, 8'h09, 0), 1'b0, ERR_PROC_OP);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 62, 0, PROC_BSWAP32, 0), 1'b0, ERR_PROC_OP);
  if (DWB > 1) begin
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 1), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_ALIGN);
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, DWB / 2), 64, 0, PROC_PASS, 0), 1'b0, ERR_ALIGN);
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 1, PROC_PASS, 0), 1'b0, ERR_ALIGN);
  end
  submit(0, 0, mk(OP_PKT_PROCESS, 5, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_TENANT_MISMATCH);
  $display("      decode: ownership / permission errors");
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, part - 64, PROC_PASS, 0), 1'b0, ERR_SRAM_RANGE);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, part + 4096, PROC_PASS, 0), 1'b0, ERR_SRAM_RANGE);
  submit(0, 0, mk(OP_DMA_H2D, 0, ntag(), in_addr(0, 0), 0, 128, part - 64), 1'b0, ERR_SRAM_RANGE);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0) + 32'h1_0000 - 32, out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_READ);   // straddles the window end
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), HM_BASE + 32'h8_0000, out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_READ);            // outside every window
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), in_addr(0, 4096), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_WRITE);                // destination in the READ-ONLY window
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), HM_BASE + 32'h9_0000, 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_WRITE);            // outside every window
  submit(0, 0, mk(OP_DMA_D2H, 0, ntag(), 0, in_addr(0, 128), 64, 0), 1'b0, ERR_PERM_WRITE);
  submit(0, 0, mk(OP_DMA_H2D, 0, ntag(), HM_BASE + 32'h9_0000, 0, 64, 0), 1'b0, ERR_PERM_READ);
  drain(500_000);
  check("rejected descriptors moved no host data (reads)", hm_reads, r0);
  check("rejected descriptors moved no host data (writes)", hm_writes, w0);
  sram_sum(0, part, sh1);
  check("rejected descriptors left the SRAM unchanged", sh1, sh0);
  compare_memory("decode errors");
  rr(1, 'h18, v);  check_true("violations counted per tenant (VIOL_COUNT >= 8)", v >= 8);
  fault_status(v); check_true("FLT_PERM_VIOL and FLT_DESC_ERR set", v[FLT_PERM_VIOL] && v[FLT_DESC_ERR]);
  rw(0, int'(DPU_G_FAULT_STATUS), 32'hFF);

  $display("      decode: queue classes and blocked engines");
  if (NCQ > 0) begin
    logic [63:0] bl0, bl1;
    int cq = NNQ;                                           // first compute queue
    logic [31:0] rej0, rej1;
    rr(6, 'h10, rej0);
    submit(cq, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_BAD_OPCODE);   // network op on a compute queue
    submit(NNQ - 1, 0, mk(OP_INFER, 0, ntag(), 0, 0, 0, 0), 1'b0, ERR_BAD_OPCODE);                                              // compute op on a network queue
    submit(cq, 0, mk(OP_INFER, 0, ntag(), 0, 0, 0, 0), 1'b0, ERR_BLOCKED);
    submit(cq, 0, mk(OP_CRYPTO, 0, ntag(), 0, 0, 0, 0), 1'b0, ERR_BLOCKED);
    submit(cq, 0, mk(OP_STORAGE, 0, ntag(), 0, 0, 0, 0), 1'b0, ERR_BLOCKED);
    submit(cq, 0, mk(OP_NOP, 0, ntag(), 0, 0, 0, 0), 1'b1, ERR_NONE);
    drain(200_000);
    rr(6, 'h10, rej1);  check("ENGINES.BLOCKED_REJECTS counts the three engine refusals", rej1 - rej0, 3);
    rr(6, 0, v);  check("ENGINES.INFER: BLOCKED, ENABLE=0", v[8:0], {1'b0, 6'd0, BLK_BLOCKED});
    check("engine refusals moved no host data", hm_reads + hm_writes, r0 + w0);
  end
  $display("      decode: tenant state");
  tenant_cmd(0, TCMD_DISABLE);
  wait_tenant_state(0, int'(TS_DISABLED), 500_000);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_TENANT_STATE);
  drain(100_000);
  tenant_cmd(0, TCMD_ENABLE);
  rw(1, 'h14, 1);                                           // POLICY back to quarantine-on-violation
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b1, ERR_NONE);
  drain(200_000);
  compare_memory("decode");
endtask

// ---- management queue: firmware-style submission and completion through registers
task automatic mgmt_submit(input sfc_cmd_t c);
  logic [31:0] v;
  for (int w = 0; w < 12; w++) rw(2, 'h800 + 4 * w, c[32*w +: 32]);
  rw(2, 'h830, 1);
  rr(2, 'h834, v);
  check("management submit accepted", v[1:0], 2'b01);
endtask
task automatic mgmt_wait_cpl(output sfc_cpl_t c);
  logic [31:0] v;
  longint t0 = cyc;
  rr(3, 0, v);
  while (!v[8] && cyc - t0 < 500_000) begin repeat (8) @(posedge clk); rr(3, 0, v); end
  check_true("management completion arrived", v[8]);
  for (int w = 0; w < 8; w++) begin rr(3, 'h10 + 4 * w, v); c[32*w +: 32] = v; end
  rw(3, 4, 1);
endtask
task automatic t_mgmt();
  sfc_cpl_t c;
  logic [31:0] v;
  default_tenant(0, 0, SRAMB / NT);
  dpu_enable(1'b1);
  $display("      mgmt: firmware-submitted commands complete through the management queue");
  mgmt_submit(mk(OP_NOP, 0, 32'hAAAA_0001, 0, 0, 0, 0));
  mgmt_wait_cpl(c);
  check("mgmt NOP tag", c.tag, 32'hAAAA_0001);  check("mgmt NOP status", c.status, ST_OK);  check("mgmt queue id", c.queue, MGMT_QUEUE_ID);
  mgmt_submit(mk(OP_PKT_PROCESS, 0, 32'hAAAA_0002, in_base(0), out_base(0), 200, 0, PROC_BSWAP32, 0));
  mgmt_wait_cpl(c);
  check("mgmt PKT status", c.status, ST_OK);  check("mgmt PKT committed", c.flags[CPL_FLAG_COMMITTED], 1'b1);
  begin
    byte inb[$], outb[$];
    int bad = 0;
    inb.delete(); outb.delete();
    for (int i = 0; i < 200; i++) inb.push_back(exp_mem[int'(in_base(0) - HM_BASE) + i]);
    proc_ref(inb, PROC_BSWAP32, 0, outb);
    for (int i = 0; i < 200; i++) begin if (hm[int'(out_base(0) - HM_BASE) + i] !== outb[i]) bad++; exp_mem[int'(out_base(0) - HM_BASE) + i] = outb[i]; end
    check("mgmt PKT output bytes", bad, 0);
    check("mgmt PKT crc_out", c.crc_out, crc32_ref(outb));
  end
  mgmt_submit(mk(OP_NOP, 9, 32'hAAAA_0003, 0, 0, 0, 0));      // a management descriptor naming a tenant that does not exist
  mgmt_wait_cpl(c);
  check("mgmt bad tenant", c.err, ERR_BAD_TENANT);
  // the management queue is trusted to name any tenant, but the tenant's own rules still apply
  if (NT > 1) begin
    mgmt_submit(mk(OP_NOP, 1, 32'hAAAA_0004, 0, 0, 0, 0));    // tenant 1 is not enabled
    mgmt_wait_cpl(c);
    check("mgmt NOP for a disabled tenant", c.err, ERR_TENANT_STATE);
  end
  // interrupt line: event IRQ follows the management CQ when enabled
  rw(0, int'(DPU_G_IRQ_ENABLE), 1);
  mgmt_submit(mk(OP_NOP, 0, 32'hAAAA_0005, 0, 0, 0, 0));
  repeat (100) @(posedge clk);
  check("DPU_EVENT interrupt asserted while the management CQ holds a record", dpu_irq_event, 1'b1);
  mgmt_wait_cpl(c);
  repeat (4) @(posedge clk);
  check("DPU_EVENT interrupt released when the CQ drains", dpu_irq_event, 1'b0);
  rw(0, int'(DPU_G_IRQ_ENABLE), 0);
  compare_memory("mgmt");
endtask

// ---- data: lengths, ops, alignments, staging round trips; commit-before-completion is checked per command
task automatic t_data();
  int lens[$] = '{1, 2, 3, 4, 5, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 127, 128, 129, 255, 256, 511, 512, 1000, 1500, 2047, 2048, 4095, 4096};
  logic [7:0] ops[$] = '{PROC_PASS, PROC_XOR32, PROC_BSWAP32};
  int part = SRAMB / NT;
  logic [31:0] key;
  int n = 0, len;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  $display("      data: PKT_PROCESS over lengths and operations");
  foreach (lens[i]) begin
    foreach (ops[j]) begin
      len = lens[i];
      if (len > MAXX) continue;
      if (ops[j] == PROC_BSWAP32) len = (len + 3) & ~3;
      key = $urandom;
      submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, al(rnd(0, 32'hF000))), out_addr(0, (n % 16) * 4096), len,
                      (n % 4) * 8192, ops[j], key), 1'b1, ERR_NONE);
      n++;
      if ((n % 4) == 0) drain(2_000_000);
    end
  end
  drain(2_000_000);
  compare_memory("PKT_PROCESS lengths");
  $display("      data: H2D staging, SRAM content, D2H round trip");
  for (int i = 0; i < 6; i++) begin
    int l = (i == 0) ? 1 : rnd(1, 3000);
    int so = al(rnd(0, 4096));
    longint unsigned s = in_addr(0, al(rnd(0, 32'h8000)));
    longint unsigned d = out_addr(0, al(rnd(0, 32'h8000)));
    byte mem_in[$];
    int bad = 0;
    mem_in.delete();
    for (int b = 0; b < l; b++) mem_in.push_back(exp_mem[int'(s - HM_BASE) + b]);
    submit(0, 0, mk(OP_DMA_H2D, 0, ntag(), s, 0, l, so), 1'b1, ERR_NONE);
    drain(1_000_000);
    for (int b = 0; b < l; b++) begin byte x; sram_peek_byte(so + b, x); if (x !== mem_in[b]) bad++; end
    check($sformatf("H2D %0d bytes: SRAM holds the host data (mismatches)", l), bad, 0);
    // D2H: expectation = what the SRAM holds
    begin
      sfc_cmd_t c = mk(OP_DMA_D2H, 0, ntag(), 0, d, l, so);
      expect_cmd(0, 0, c, 1'b1, ERR_NONE, 1'b0);
      vio_submit_raw(0, c);
      drain(1_000_000);
      bad = 0;
      for (int b = 0; b < l; b++) begin if (hm[int'(d - HM_BASE) + b] !== mem_in[b]) bad++; exp_mem[int'(d - HM_BASE) + b] = mem_in[b]; end
      check($sformatf("D2H %0d bytes: host holds the SRAM data (mismatches)", l), bad, 0);
    end
  end
  $display("      data: partial last beats never write outside [dst, dst+len)");
  begin
    byte prior[$];
    longint unsigned d = out_addr(0, 5 * 4096);
    int l = DWB * 3 + (DWB > 1 ? 1 : 0);
    prior.delete();
    for (int b = 0; b < 3 * DWB + 8; b++) prior.push_back(hm[int'(d - HM_BASE) + b]);
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), d, l, 0, PROC_XOR32, 32'hFFFF_FFFF), 1'b1, ERR_NONE);
    drain(500_000);
    for (int b = l; b < 3 * DWB + 8; b++) check($sformatf("byte %0d beyond the transfer untouched", b), hm[int'(d - HM_BASE) + b], prior[b]);
  end
  compare_memory("data");
endtask

// ---- stress: random mixed traffic (run it with +bp / +cbp / +lat for back-pressure variations)
task automatic t_stress();
  int part = SRAMB / NT;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  $display("      stress: bp=%0d%% cbp=%0d%% lat<=%0d", bp_pct, cbp_pct, lat_max);
  rand_traffic(0, 0, 40);
  compare_memory("stress");
endtask

// ---- saturation: full queues, exhausted completion credits, no loss, no cross-queue stall
task automatic t_saturation();
  logic [31:0] v;
  int acc = 0;
  bit got;
  int part = SRAMB / NT;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  cons_en[0] = 1'b0;                                           // the host stops reading queue 0's completions
  $display("      saturation: CQ credits (%0d) then SQ (%0d) fill, further submissions are back-pressured", CD, QD);
  for (int i = 0; i < CD + QD; i++) begin
    submit(0, 0, mk(OP_NOP, 0, ntag(), 0, 0, 0, 0), 1'b1, ERR_NONE);
    acc++;
  end
  repeat (200) @(posedge clk);
  rr(2, 4, v);
  check("SQ full of waiting descriptors", v[7:0], QD);
  check("CQ holds exactly CPLQ_DEPTH completions", v[15:8], CD);
  // the next submission must stall (valid held, ready low)
  @(negedge clk);
  vio_sub_valid = 1'b1; vio_sub_q = 4'd0; vio_sub_cmd = mk(OP_NOP, 0, 32'h7777_0001, 0, 0, 0, 0);
  expect_cmd(0, 0, mk(OP_NOP, 0, 32'h7777_0001, 0, 0, 0, 0), 1'b1, ERR_NONE, 1'b0);
  repeat (40) begin #1; check("vio_sub_ready low while the queue is full", vio_sub_ready, 1'b0); @(negedge clk); end
  // another queue keeps working while queue 0 is saturated (back-pressure is per queue)
  if (NQH > 1) begin
    // (vio port is busy holding the stalled descriptor; the independent-queue check uses the management queue)
    sfc_cpl_t c;
    mgmt_submit(mk(OP_NOP, 0, 32'hAAAA_0100, 0, 0, 0, 0));
    mgmt_wait_cpl(c);
    check("management queue progresses while queue 0 is saturated", c.status, ST_OK);
  end
  cons_en[0] = 1'b1;                                           // the host reads again: everything drains
  #1;
  while (!vio_sub_ready) begin @(negedge clk); #1; end
  @(posedge clk); #1; vio_sub_valid = 1'b0;
  drain(500_000);
  check_true("all submitted commands completed, none lost", sb.size() == 0);
  rr(2, 8, v);  check("SUBMITTED counter", v, CD + QD + 1);
  rr(2, 12, v); check("COMPLETED counter", v, CD + QD + 1);
  compare_memory("saturation");
endtask

// ---- error propagation: host memory errors reach the completion, never a success, and the DPU keeps working
task automatic t_errprop();
  logic [31:0] v;
  logic [63:0] c0, c1;
  int part = SRAMB / NT;
  longint unsigned s, d;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  $display("      errprop: host read error in the middle of the input buffer");
  s = in_addr(0, 4096);
  hm_inj_lo.push_back(s + 512); hm_inj_hi.push_back(s + 512 + 64);
  begin
    int w0 = hm_writes;
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), s, out_addr(0, 0), 1024, 0, PROC_XOR32, 32'h5A5A_5A5A), 1'b0, ERR_HOST_MEM, 1'b1);
    drain(500_000);
    check("no output written after a failed read (host writes)", hm_writes, w0);
  end
  fault_status(v);  check_true("FLT_HOST_ERR set", v[FLT_HOST_ERR]);
  rr(0, int'(DPU_G_FAULT_ERR), v);  check("FAULT_ERR = ERR_HOST_MEM", v, ERR_HOST_MEM);
  rw(0, int'(DPU_G_FAULT_STATUS), 32'hFF);
  hm_inj_lo.delete(); hm_inj_hi.delete();
  $display("      errprop: host write error part-way through the output");
  d = out_addr(0, 8192);
  hm_inj_lo.push_back(d + 256); hm_inj_hi.push_back(d + 256 + 64);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), d, 1024, 0, PROC_PASS, 0), 1'b0, ERR_HOST_MEM, 1'b1);
  drain(500_000);
  hm_inj_lo.delete(); hm_inj_hi.delete();
  $display("      errprop: the DPU is not wedged, the next transfer is correct");
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 16384), 1000, 0, PROC_BSWAP32, 0), 1'b1, ERR_NONE);
  drain(500_000);
  perf_get(13, c0);  check_true("perf HOST_ERRORS counted both", c0 >= 2);
  begin int st; tenant_state(0, st);  check("a host-memory error does not quarantine the tenant", st, int'(TS_ACTIVE)); end
  compare_memory("errprop");
endtask

// ---- telemetry
task automatic t_telemetry();
  logic [31:0] v;
  int n_ret = 0, n_viol = 0, n_state = 0;
  tlm_log.delete();
  default_tenant(0, 0, SRAMB / NT);
  dpu_enable(1'b1);
  rw(1, 'h14, 0);
  for (int i = 0; i < 5; i++) submit(0, 0, mk(OP_NOP, 0, ntag(), 0, 0, 0, 0), 1'b1, ERR_NONE);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), HM_BASE + 32'h9_0000, out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_READ);
  drain(200_000);
  repeat (20) @(posedge clk);
  foreach (tlm_log[i]) begin
    logic [TLM_W-1:0] e = tlm_log[i];
    if (e[15:8] == TLM_CMD_RETIRE) n_ret++;
    if (e[15:8] == TLM_VIOLATION) begin n_viol++; check("violation event argument", e[47:16], ERR_PERM_READ); end
    if (e[15:8] == TLM_TENANT_STATE) n_state++;
  end
  check("telemetry: one retire event per successful command", n_ret, 5);
  check("telemetry: one violation event", n_viol, 1);
  check_true("telemetry: tenant state changes reported", n_state >= 2);
  rr(5, 12, v);  check_true("TLM EMITTED counts events", v >= 8);
  // telemetry never back-pressures the data path: a stalled consumer only costs dropped events
  $display("      telemetry: stalled consumer -> events dropped and counted, traffic unaffected");
  begin
    logic [31:0] d0, d1;
    rr(5, 8, d0);
    force_tlm_stall = 1'b1;
    for (int i = 0; i < 40; i++) submit(0, 0, mk(OP_NOP, 0, ntag(), 0, 0, 0, 0), 1'b1, ERR_NONE);
    drain(500_000);
    force_tlm_stall = 1'b0;
    rr(5, 8, d1);  check_true("telemetry dropped events were counted", d1 > d0);
    fault_status(v);  check_true("FLT_TLM_DROP set", v[FLT_TLM_DROP]);
    rw(0, int'(DPU_G_FAULT_STATUS), 32'hFF);
  end
  tlm_log.delete();
  compare_memory("telemetry");
endtask
// ---- perf: counters agree with the testbench's own accounting
task automatic t_perf();
  logic [63:0] v;
  longint exp_rd = 0, exp_wr = 0, exp_bytes = 0;
  int n = 0, nerr = 0;
  int part = SRAMB / NT;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  rw(1, 'h14, 0);
  perf_clear();
  $display("      perf: counters vs expected");
  for (int i = 0; i < 12; i++) begin
    int len = rnd(1, 1500);
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, al(rnd(0, 32'h8000))), out_addr(0, 4096 * (i % 8)), len, 0, PROC_XOR32, $urandom), 1'b1, ERR_NONE);
    exp_rd += len;  exp_wr += len;  exp_bytes += len;  n++;
    // Commands of one queue are NOT ordered against each other when there are several DMA channels (they may run in
    // parallel and complete out of order), and all of these use the same SRAM staging buffer: this scenario measures
    // counters, so it waits for each completion.  (Concurrency itself is exercised by `multi` and `stress`.)
    if (NS > 1) drain(2_000_000);
  end
  submit(0, 0, mk(OP_DMA_H2D, 0, ntag(), in_addr(0, 0), 0, 300, 0), 1'b1, ERR_NONE);  exp_rd += 300;  exp_bytes += 300;  n++;
  if (NS > 1) drain(2_000_000);                     // the D2H below returns what this H2D staged: it must have finished
  submit(0, 0, mk(OP_DMA_D2H, 0, ntag(), 0, out_addr(0, 60000), 100, 0), 1'b1, ERR_NONE);  exp_wr += 100;  exp_bytes += 100;  n++;
  begin   // the SRAM staging buffer at offset 0 holds the 300 bytes just loaded from in_addr(0, 0): the D2H returns the first 100 of them
    longint unsigned dsta = out_addr(0, 60000);
    longint unsigned srca = in_addr(0, 0);
    drain(2_000_000);
    for (int b = 0; b < 100; b++) exp_mem[int'(dsta - HM_BASE) + b] = exp_mem[int'(srca - HM_BASE) + b];
  end
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 0, 0, PROC_PASS, 0), 1'b0, ERR_BAD_LENGTH);  nerr++;
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), HM_BASE + 32'h9_0000, out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_READ);  nerr++;
  drain(2_000_000);
  perf_get(0, v);   check("perf CMDS_ACCEPTED", v, n + nerr);
  perf_get(1, v);   check("perf CMDS_RETIRED", v, n + nerr);
  perf_get(2, v);   check("perf CMDS_ERROR", v, nerr);
  perf_get(3, v);   check("perf DMA_BYTES_RD", v, exp_rd);
  perf_get(4, v);   check("perf DMA_BYTES_WR", v, exp_wr);
  perf_get(5, v);   check_true("perf ACTIVE_CYCLES > 0", v > 0);
  perf_get(11, v);  check("perf ERR_EVENTS", v, nerr);
  perf_get(12, v);  check("perf VIOLATIONS", v, 1);
  perf_get(15, v);  check_true("perf CYCLES running", v > 100);
  rr(4, 'h400 + 0, v[31:0]);  check("tenant 0 retired", v[31:0], n + nerr);
  begin logic [63:0] by; rr64(4, 'h400 + 8, by); check("tenant 0 BYTES = sum of lengths of the successful commands", by, exp_bytes); end
  rr64(4, 'h400 + 16, v);  check_true("tenant 0 active cycles > 0", v > 0);
  if (NT > 1) begin rr64(4, 'h400 + 'h20 + 16, v);  check("idle tenant 1 has zero active cycles", v, 0); end
  // freeze gives a consistent snapshot; clear zeroes
  rw(4, 0, 32'h1);  perf_get(15, v);  begin logic [63:0] v2; repeat (50) @(posedge clk); perf_get(15, v2); check("FREEZE holds CYCLES", v2, v); end
  rw(4, 0, 32'h2);  rw(4, 0, 32'h0);  perf_get(0, v);  check("CLEAR zeroes counters", v, 0);
  compare_memory("perf");
endtask

// ---- multi: several queues / DMA channels / tenants at once
task automatic t_multi();
  int part = SRAMB / NT;
  if (NNQ < 2 && NS < 2 && NT < 2) begin $display("      multi: SKIP (needs NNQ>=2, NS>=2 or NT>=2)"); return; end
  for (int t = 0; t < NT; t++) default_tenant(t, t * part, part);
  dpu_enable(1'b1);
  $display("      multi: %0d queues x %0d channels, concurrent random traffic", NNQ, NS);
  fork
    begin : f0 if (NNQ > 0) rand_traffic(0, 0, 30, 1'b1, 0); end
    begin : f1 if (NNQ > 1) rand_traffic(1, 1 % NT, 30, 1'b1, (NT == 1) ? 1 : 0); end
    begin : f2 if (NNQ > 2) rand_traffic(2, 2 % NT, 20, 1'b1, 0); end
    begin : f3 if (NNQ > 3) rand_traffic(3, 3 % NT, 20, 1'b1, 0); end
  join
  drain(4_000_000);
  begin
    logic [63:0] v;
    perf_get(10, v);
    if (NS > 1) check_true("memory conflicts observed with concurrent DMA channels", v > 0);
    $display("      multi: memory conflicts counted = %0d", v);
  end
  compare_memory("multi");
endtask

// ---- isolation: tenants cannot reach each other's SRAM, windows, queues or completions
task automatic t_isolation();
  logic [31:0] v;
  logic [63:0] a0, a1, b0, b1;
  int part = SRAMB / NT;
  int st;
  longint unsigned ib0, ib1;
  int r0, w0;
  logic [7:0] cfg;
  if (NT < 2) begin $display("      isolation: SKIP (needs NUM_TENANTS >= 2)"); return; end
  default_tenant(0, 0, part);
  default_tenant(1, part, part);
  dpu_enable(1'b1);
  $display("      isolation: two tenants run side by side");
  fork
    rand_traffic(0, 0, 12, 1'b1);
    rand_traffic(NNQ > 1 ? 1 : 0, 1, 12, 1'b1);
  join
  compare_memory("isolation: normal traffic");
  // fill tenant 1's partition with its own data
  submit(NNQ > 1 ? 1 : 0, 1, mk(OP_DMA_H2D, 1, ntag(), in_addr(1, 0), 0, 4096, 0), 1'b1, ERR_NONE);
  drain(500_000);
  sram_sum(part, part, b0);
  begin
    int q1 = (NNQ > 1) ? 1 : 0;
    $display("      isolation: configuration rules");
    // overlapping SRAM partition
    tenant_cmd(1, TCMD_DISABLE);
    wait_tenant_state(1, int'(TS_DISABLED), 500_000);
    tenant_set_part(1, part / 2, part);
    tenant_commit(1, cfg);  check("overlapping SRAM partition refused", cfg, CFG_OVERLAP_SRAM);
    // overlapping host window (tenant 1 asks for tenant 0's input window)
    tenant_set_part(1, part, part);
    ib0 = in_base(0);  ib1 = in_base(1);
    rw(1, 'h100 + 'h20 + 0, ib0[31:0]);
    rw(1, 'h100 + 'h20 + 4, ib0[63:32]);
    tenant_commit(1, cfg);  check("overlapping host window refused", cfg, CFG_OVERLAP_HOST);
    // restore the legal configuration
    rw(1, 'h100 + 'h20 + 0, ib1[31:0]);
    rw(1, 'h100 + 'h20 + 4, ib1[63:32]);
    tenant_bringup(1, cfg);  check("tenant 1 legal configuration accepted", cfg, CFG_OK);
    // partition outside the SRAM / empty / misaligned
    tenant_cmd(1, TCMD_DISABLE);  wait_tenant_state(1, int'(TS_DISABLED), 500_000);
    tenant_set_part(1, SRAMB - 256, 512);
    tenant_commit(1, cfg);  check("partition beyond the SRAM refused", cfg, CFG_BAD_PART);
    tenant_set_part(1, part + 1, 256);
    tenant_commit(1, cfg);  check("misaligned partition refused", cfg, CFG_BAD_PART);
    tenant_set_part(1, part, part);
    tenant_commit(1, cfg);  check("legal partition accepted again", cfg, CFG_OK);
    tenant_cmd(1, TCMD_ENABLE);
    // the SRAM of tenant 1 was scrubbed by the re-commit: its own data is gone (not leaked to anyone)
    sram_nonzero(part, part, st);  check("recommit scrubbed tenant 1's partition", st, 0);
    submit(q1, 1, mk(OP_DMA_H2D, 1, ntag(), in_addr(1, 0), 0, 4096, 0), 1'b1, ERR_NONE);
    drain(500_000);
    sram_sum(part, part, b0);
  end
  $display("      isolation: tenant 0 attacks tenant 1 (every attempt must be refused, nothing of tenant 1 changes)");
  rw(1, 'h14, 0);                                          // observe every case: no quarantine for this part
  sram_sum(part, part, b0);
  r0 = hm_reads;  w0 = hm_writes;
  // 1 source in tenant 1's window
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(1, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_READ);
  // 2 destination in tenant 1's window
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(1, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_WRITE);
  submit(0, 0, mk(OP_DMA_D2H, 0, ntag(), 0, out_addr(1, 0), 64, 0), 1'b0, ERR_PERM_WRITE);
  // 3 SRAM buffers reaching past the partition end into tenant 1's partition
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 1024, part - 512, PROC_PASS, 0), 1'b0, ERR_SRAM_RANGE);
  submit(0, 0, mk(OP_DMA_H2D, 0, ntag(), in_addr(0, 0), 0, 1024, part), 1'b0, ERR_SRAM_RANGE);
  submit(0, 0, mk(OP_DMA_D2H, 0, ntag(), 0, out_addr(0, 0), 1024, part + 4096), 1'b0, ERR_SRAM_RANGE);
  // 4 spoofed tenant field on tenant 0's queue
  submit(0, 0, mk(OP_PKT_PROCESS, 1, ntag(), in_addr(1, 0), out_addr(1, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_TENANT_MISMATCH);
  drain(500_000);
  sram_sum(part, part, b1);
  check("tenant 1 SRAM partition unchanged", b1, b0);
  check("no host reads performed for refused attacks", hm_reads, r0);
  check("no host writes performed for refused attacks", hm_writes, w0);
  compare_memory("isolation: attacks");
  rr(1, 'h18, v);  check_true("tenant 0 violation counter", v >= 7);
  rr(1, 'h118, v); check("tenant 1 violation counter is zero (it never misbehaved)", v, 0);
  $display("      isolation: quarantine, recovery, the other tenant is unaffected");
  rw(1, 'h14, 1);                                          // quarantine policy on for tenant 0
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(1, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_PERM_READ);
  drain(200_000);
  tenant_state(0, st);  check("tenant 0 QUARANTINED after a violation", st, int'(TS_QUARANTINED));
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 64, 0, PROC_PASS, 0), 1'b0, ERR_QUARANTINED);
  begin
    int q1 = (NNQ > 1) ? 1 : 0;
    submit(q1, 1, mk(OP_PKT_PROCESS, 1, ntag(), in_addr(1, 0), out_addr(1, 0), 500, 0, PROC_XOR32, 32'h1234_5678), 1'b1, ERR_NONE);
    drain(500_000);
    tenant_state(1, st);  check("tenant 1 still ACTIVE while tenant 0 is quarantined", st, int'(TS_ACTIVE));
  end
  tenant_cmd(0, TCMD_RECOVER);
  wait_tenant_state(0, int'(TS_DISABLED), 1_000_000);
  sram_nonzero(0, part, st);  check("recovery scrubbed tenant 0's partition", st, 0);
  sram_sum(part, part, b1);
  begin logic [63:0] b2; sram_sum(part, part, b2); check("tenant 1 SRAM still intact after tenant 0's recovery", b2, b1); end
  tenant_cmd(0, TCMD_ENABLE);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 700, 0, PROC_BSWAP32, 0), 1'b1, ERR_NONE);
  drain(500_000);
  tenant_state(0, st);  check("tenant 0 ACTIVE again after RECOVER + ENABLE", st, int'(TS_ACTIVE));
  $display("      isolation: queue binding decides the tenant, not the descriptor");
  if (NNQ > 1) begin
    // while queue 1 is idle it can be re-bound to tenant 0; a descriptor naming tenant 1 on it is then a spoof
    rw(2, 32, 0);
    submit(1, 0, mk(OP_NOP, 1, ntag(), 0, 0, 0, 0), 1'b0, ERR_TENANT_MISMATCH);
    drain(100_000);
    tenant_state(0, st);
    if (st == int'(TS_QUARANTINED)) begin tenant_cmd(0, TCMD_RECOVER); wait_tenant_state(0, int'(TS_DISABLED), 1_000_000); tenant_cmd(0, TCMD_ENABLE); end
    submit(1, 0, mk(OP_NOP, 0, ntag(), 0, 0, 0, 0), 1'b1, ERR_NONE);
    drain(100_000);
    rw(2, 32, 1);
  end
  compare_memory("isolation");
endtask

// ---- recovery: job watchdog, data-plane reset, orphaned host responses, host reset under traffic
task automatic t_recovery();
  logic [31:0] v;
  int part = SRAMB / NT;
  int st;
  longint unsigned dpr0;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  $display("      recovery: a stuck host memory is caught by the job watchdog");
  rw(0, int'(DPU_G_JOB_TIMEOUT), 400);
  hm_hold_until = 64'h7FFF_FFFF_FFFF;                              // host memory stops answering
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 0), 256, 0, PROC_XOR32, 32'h0F0F_0F0F), 1'b0, ERR_TIMEOUT);
  repeat (900) @(posedge clk);
  check_true("timeout completion delivered", sb.size() == 0);
  rr(0, int'(DPU_G_STATUS), v);  check("STATUS.halted after a timeout", v[1], 1'b1);
  fault_status(v);  check_true("FLT_TIMEOUT set", v[FLT_TIMEOUT]);
  $display("      recovery: while halted nothing new is dispatched");
  begin
    int r0 = hm_reads + hm_writes + hm_q.size();
    expect_cmd(0, 0, mk(OP_NOP, 0, 32'h4242_0001, 0, 0, 0, 0), 1'b1, ERR_NONE, 1'b0);
    vio_submit_raw(0, mk(OP_NOP, 0, 32'h4242_0001, 0, 0, 0, 0));
    repeat (300) @(posedge clk);
    check_true("queued NOP waits while halted", sb.size() == 1);
    check("no new host traffic while halted", hm_reads + hm_writes + hm_q.size(), r0);
  end
  $display("      recovery: DP_RESET with a response still owed by the host (orphaned response)");
  rr(0, int'(DPU_G_DP_RESETS), v);  dpr0 = v;
  rw(0, int'(DPU_G_JOB_TIMEOUT), 32'h0004_0000);                       // the later transfers wait on the host: no spurious timeout
  rw(0, int'(DPU_G_CTRL), 32'h3);                                    // EN stays 1, DP_RESET pulse
  repeat (60) @(posedge clk);
  rr(0, int'(DPU_G_DP_RESETS), v);  check("DP_RESETS incremented", v, dpr0 + 1);
  rr(0, int'(DPU_G_STATUS), v);     check("halted cleared by the reset", v[1], 1'b0);
  rr(7, 'h44, v);                   check_true("host port reports an orphaned response", v[1]);
  // the queued NOP is not a data-plane job: it completes now that dispatch resumed
  drain(100_000);
  // the stale response must be swallowed; no new host request until it arrived
  begin
    int q0 = hm_q.size();
    submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 4096), 128, 0, PROC_PASS, 0), 1'b1, ERR_NONE);
    repeat (200) @(posedge clk);
    check("no new request while the orphaned response is pending", hm_q.size(), q0);
    hm_hold_until = 0;                                               // the host finally answers
    drain(500_000);
  end
  rr(7, 'h44, v);  check("orphan cleared after the late response", v[1:0], 2'b00);
  check_true("the transfer after the reset completed", sb.size() == 0);
  compare_memory("recovery after timeout");
  $display("      recovery: DP_RESET aborts what is in flight and the data plane works again");
  hm_hold_until = 64'h7FFF_FFFF_FFFF;
  rw(0, int'(DPU_G_JOB_TIMEOUT), 32'h0004_0000);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 8192), 512, 0, PROC_PASS, 0), 1'b0, ERR_RESET_ABORT);
  repeat (100) @(posedge clk);
  rw(0, int'(DPU_G_CTRL), 32'h3);
  repeat (80) @(posedge clk);
  check_true("in-flight job completed with ERR_RESET_ABORT", sb.size() == 0);
  hm_hold_until = 0;
  repeat (40) @(posedge clk);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, al(100)), out_addr(0, 12288), 333, 0, PROC_XOR32, 32'hC3C3_C3C3), 1'b1, ERR_NONE);
  drain(500_000);
  tenant_state(0, st);  check("tenant config survived the data-plane reset", st, int'(TS_ACTIVE));
  compare_memory("recovery after abort");
  $display("      recovery: DP_RESET on an idle DPU is harmless");
  rw(0, int'(DPU_G_CTRL), 32'h3);
  repeat (60) @(posedge clk);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 20480), 100, 0, PROC_PASS, 0), 1'b1, ERR_NONE);
  drain(300_000);
  $display("      recovery: DP_RESET in the middle of a tenant scrub (a scrub write lost to the reset must be re-issued)");
  // The scrubber issues one write after another with a fixed period, so a single reset instant lands at one fixed phase of
  // that pattern and may never catch a write in flight: the reset instant is swept over 8 consecutive cycle offsets.
  for (int k = 0; k < 8; k++) begin
    int nz_before, nz_after;
    // put data at the TOP of the partition: the scrubber works upwards, so it is still unscrubbed when the reset hits
    submit(0, 0, mk(OP_DMA_H2D, 0, ntag(), in_addr(0, 0), 0, 4096, part - 4096), 1'b1, ERR_NONE);
    drain(300_000);
    sram_nonzero(sram_base_of[0], sram_size_of[0], nz_before);
    check_true($sformatf("[%0d] partition holds data before the teardown", k), nz_before > 1000);
    tenant_cmd(0, TCMD_DISABLE);                                      // DRAINING -> SCRUBBING: the whole partition is rewritten with zeros
    wait_tenant_state(0, int'(TS_SCRUBBING), 100_000);
    repeat (300 + k) @(posedge clk);                                  // well inside the scrub
    tenant_state(0, st);  check($sformatf("[%0d] tenant 0 is still SCRUBBING when the reset hits", k), st, int'(TS_SCRUBBING));
    rw(0, int'(DPU_G_CTRL), 32'h3);                                   // DP_RESET: crossbar and SRAM controllers reset, a scrub write in flight is lost
    wait_tenant_state(0, int'(TS_DISABLED), 2_000_000);
    tenant_state(0, st);  check($sformatf("[%0d] scrub finished after the reset (DISABLED, not stuck in SCRUBBING)", k), st, int'(TS_DISABLED));
    sram_nonzero(sram_base_of[0], sram_size_of[0], nz_after);
    check($sformatf("[%0d] partition all zero after a scrub interrupted by a data-plane reset (non-zero bytes)", k), nz_after, 0);
    tenant_cmd(0, TCMD_ENABLE);
    tenant_state(0, st);  check($sformatf("[%0d] tenant 0 ACTIVE again after the interrupted scrub", k), st, int'(TS_ACTIVE));
  end
  $display("      recovery: host reset under traffic, then a clean restart");
  hm_hold_until = 0;
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 24576), 3000, 0, PROC_XOR32, 32'h1), 1'b0, ERR_RESET_ABORT);
  repeat (150) @(posedge clk);
  boot_host_rst = 1'b1;  repeat (6) @(posedge clk);  boot_host_rst = 1'b0;
  hm_q.delete();  hm_rsp_valid = 1'b0;
  sb.delete();                                                       // pending commands vanish with the reset
  for (int i = 0; i < 3000; i++) dc_mem[int'(out_addr(0, 24576) - HM_BASE) + i] = 1'b1;   // the interrupted transfer may have written part of its output
  repeat (80) @(posedge clk);
  for (int t = 0; t < NT; t++) for (int w = 0; w < NW; w++) tw_v[t][w] = 1'b0;
  default_tenant(0, 0, part);
  dpu_enable(1'b1);
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 28672), 777, 0, PROC_BSWAP32, 0), 1'b0, ERR_PROC_OP);   // 777 % 4 != 0
  submit(0, 0, mk(OP_PKT_PROCESS, 0, ntag(), in_addr(0, 0), out_addr(0, 28672), 776, 0, PROC_BSWAP32, 0), 1'b1, ERR_NONE);
  drain(500_000);
  compare_memory("recovery after host reset");
endtask

// ---- width: the same data checks under the configured geometry (run with other -D builds)
task automatic t_geometry();
  t_data();
  tb_reset_all();                         // a live tenant cannot be re-committed (CFG_BUSY): start the next scenario clean
  t_stress();
endtask

`ifdef WITH_FW
`include "dpu_fw_test.svh"
`endif

task automatic run_test(input string name);
  $display("[%0d] ---- scenario %s", cyc, name);
  if (name != "smoke_noreset") tb_reset_all();
  case (name)
    "smoke":      t_smoke();
    "reset":      t_reset();
    "boot":       t_boot();
    "mmio":       t_mmio();
    "decode":     t_decode();
    "mgmt":       t_mgmt();
    "data":       t_data();
    "stress":     t_stress();
    "saturation": t_saturation();
    "errprop":    t_errprop();
    "telemetry":  t_telemetry();
    "perf":       t_perf();
    "multi":      t_multi();
    "isolation":  t_isolation();
    "recovery":   t_recovery();
    "geometry":   t_geometry();
`ifdef WITH_FW
    "fw":         t_fw();
`endif
    default:      fail({"unknown scenario ", name});
  endcase
endtask
