// =============================================================================
// CloudDPU :: tb_crc_xcheck -- sfd_crc32 (datapath) against SecureStore's validated sfsec_crc (mode 1, CRC-32 IEEE)
// and against the standard check value CRC-32("123456789") = 0xCBF43926, over random messages and byte groupings.
// sfsec_crc is vendored unmodified (768-message evidence in its own report); it is used here, in verification, as the
// independent golden implementation.  (It is not in the synthesizable path: its package uses `return`, which the
// baseline Yosys 0.33 flow rejects.)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_crc_xcheck;
  logic clk = 0, rst_n = 0, clr = 0, en = 0;
  logic [31:0] data = 0, a_o, b_o;
  logic [2:0] nb = 0;
  always #5 clk = ~clk;
  sfd_crc32 u_dut (.clk, .rst_n, .clr, .en, .data_i(data), .nbytes_i(nb), .crc_o(a_o));
  sfsec_crc u_ref (.clk, .rst_n, .clr, .mode_i(2'd1), .en, .data_i(data), .nbytes_i(nb), .crc_o(b_o));
  int fails = 0, checks = 0, msgs = 0;
  task automatic feed(input byte m[$]);
    int i;
    @(negedge clk); clr = 1; en = 0;
    @(negedge clk); clr = 0;
    i = 0;
    while (i < m.size()) begin
      int n = 1 + $urandom_range(3, 0);
      if (i + n > m.size()) n = m.size() - i;
      data = 0;
      for (int k = 0; k < n; k++) data[8*k +: 8] = m[i + k];
      nb = 3'(n); en = 1;
      @(negedge clk);
      i += n;
    end
    en = 0;
    @(negedge clk);
    checks++;
    if (a_o !== b_o) begin fails++; $display("MISMATCH len=%0d dut=%08h ref=%08h", m.size(), a_o, b_o); end
    msgs++;
  endtask
  initial begin
    byte m[$];
    string s = "123456789";
    repeat (3) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);
    for (int i = 0; i < s.len(); i++) m.push_back(byte'(s[i]));
    feed(m);
    checks++; if (a_o !== 32'hCBF4_3926) begin fails++; $display("check value: got %08h", a_o); end
    for (int t = 0; t < 400; t++) begin
      m.delete();
      for (int i = 0; i < $urandom_range(200, 1); i++) m.push_back(byte'($urandom));
      feed(m);
    end
    $display("TB RESULT %s messages=%0d checks=%0d fails=%0d", fails == 0 ? "PASS" : "FAIL", msgs, checks, fails);
    if (fails == 0) $finish(0); else $fatal(1, "crc xcheck failed");
  end
endmodule
