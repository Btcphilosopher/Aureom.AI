// =============================================================================
// CloudDPU :: tb_layout_check -- the flat field positions used by the synthesizable RTL and the packed-struct views
// used by testbenches describe the SAME bits (silicaflux_cloud_pkg).  The RTL cannot use structs (Yosys 0.33), the
// testbenches should not hard-code offsets: this test ties the two together.
// =============================================================================
`default_nettype none
module tb_layout_check;
  import silicaflux_cloud_pkg::*;
  int fails = 0, checks = 0;
  task automatic ck(input string w, input longint unsigned g, input longint unsigned e);
    checks++;
    if (g !== e) begin fails++; $display("LAYOUT FAIL %s: got %0h exp %0h", w, g, e); end
  endtask
  initial begin
    sfc_cmd_t c;  sfc_cpl_t p;  sfc_txn_t t;
    logic [CMD_W-1:0] cv;  logic [CPL_W-1:0] pv;  logic [TXN_W-1:0] tv;
    ck("CMD_W", $bits(sfc_cmd_t), CMD_W);  ck("CPL_W", $bits(sfc_cpl_t), CPL_W);  ck("TXN_W", $bits(sfc_txn_t), TXN_W);
    ck("CMD_W = 32*CMD_NW", CMD_W, 32 * CMD_NW);  ck("CPL_W = 32*CPL_NW", CPL_W, 32 * CPL_NW);
    c = '0;
    c.opcode = 8'hA1; c.flags = 8'hB2; c.tenant = 4'hC; c.w0_rsvd = 12'hDDD; c.tag = 32'h1111_2222;
    c.src = 64'h3333_4444_5555_6666; c.dst = 64'h7777_8888_9999_AAAA; c.length = 32'hBBBB_CCCC; c.sram_off = 32'hDDDD_EEEE;
    c.proc_op = 8'hF1; c.w8_rsvd = 24'hF2F3F4; c.param = 32'h0102_0304; c.w10_rsvd = 32'hA5A5_A5A5; c.w11_rsvd = 32'h5A5A_5A5A;
    cv = c;
    ck("cmd.opcode", cv[CMD_OPCODE_LSB +: 8], 8'hA1);   ck("cmd.flags", cv[CMD_FLAGS_LSB +: 8], 8'hB2);
    ck("cmd.tenant", cv[CMD_TENANT_LSB +: 4], 4'hC);    ck("cmd.w0_rsvd", cv[CMD_W0_RSVD_LSB +: 12], 12'hDDD);
    ck("cmd.tag", cv[CMD_TAG_LSB +: 32], 32'h1111_2222); ck("cmd.src", cv[CMD_SRC_LSB +: 64], 64'h3333_4444_5555_6666);
    ck("cmd.dst", cv[CMD_DST_LSB +: 64], 64'h7777_8888_9999_AAAA); ck("cmd.length", cv[CMD_LEN_LSB +: 32], 32'hBBBB_CCCC);
    ck("cmd.sram_off", cv[CMD_SRAM_OFF_LSB +: 32], 32'hDDDD_EEEE); ck("cmd.proc_op", cv[CMD_PROC_OP_LSB +: 8], 8'hF1);
    ck("cmd.w8_rsvd", cv[CMD_W8_RSVD_LSB +: 24], 24'hF2F3F4); ck("cmd.param", cv[CMD_PARAM_LSB +: 32], 32'h0102_0304);
    ck("cmd.rsvd", cv[CMD_RSVD_LSB +: 64], 64'h5A5A_5A5A_A5A5_A5A5);
    ck("word 0 = W0", cv[31:0], {12'hDDD, 4'hC, 8'hB2, 8'hA1});  ck("word 1 = tag", cv[63:32], 32'h1111_2222);
    ck("word 6 = length", cv[223:192], 32'hBBBB_CCCC);
    p = '0;
    p.opcode = 8'h11; p.status = 8'h22; p.err = 8'h33; p.tenant = 4'h4; p.queue = 4'h5; p.tag = 32'hAAAA_BBBB; p.txn_id = 16'hCCCC; p.flags = 16'hDDDD;
    p.bytes = 32'h1234_5678; p.crc_in = 32'hDEAD_BEEF; p.crc_out = 32'hCAFE_F00D; p.csum = 16'hABCD; p.ts = 32'h0F0F_0F0F;
    pv = p;
    ck("cpl.opcode", pv[CPL_OPCODE_LSB +: 8], 8'h11);  ck("cpl.status", pv[CPL_STATUS_LSB +: 8], 8'h22);  ck("cpl.err", pv[CPL_ERR_LSB +: 8], 8'h33);
    ck("cpl.tenant", pv[CPL_TENANT_LSB +: 4], 4'h4);   ck("cpl.queue", pv[CPL_QUEUE_LSB +: 4], 4'h5);     ck("cpl.tag", pv[CPL_TAG_LSB +: 32], 32'hAAAA_BBBB);
    ck("cpl.txn", pv[CPL_TXN_LSB +: 16], 16'hCCCC);    ck("cpl.flags", pv[CPL_FLAGS_LSB +: 16], 16'hDDDD); ck("cpl.bytes", pv[CPL_BYTES_LSB +: 32], 32'h1234_5678);
    ck("cpl.crc_in", pv[CPL_CRC_IN_LSB +: 32], 32'hDEAD_BEEF); ck("cpl.crc_out", pv[CPL_CRC_OUT_LSB +: 32], 32'hCAFE_F00D);
    ck("cpl.csum", pv[CPL_CSUM_LSB +: 16], 16'hABCD);  ck("cpl.ts", pv[CPL_TS_LSB +: 32], 32'h0F0F_0F0F);
    ck("cpl word 0", pv[31:0], {4'h5, 4'h4, 8'h33, 8'h22, 8'h11});
    t = '0;
    t.txn_id = 16'h1111; t.src = 4'h2; t.dst = 4'h3; t.tenant = 4'h4; t.queue = 4'h5; t.opcode = 8'h66; t.proc_op = 8'h77; t.perm = 2'b10;
    t.status = 4'h8; t.err = 8'h99; t.tag = 32'hAAAA_AAAA; t.length = 32'hBBBB_BBBB; t.sram_off = 32'hCCCC_CCCC; t.param = 32'hDDDD_DDDD;
    t.addr_in = 64'hEEEE_EEEE_1111_1111; t.addr_out = 64'h2222_2222_3333_3333;
    tv = t;
    ck("txn.txn_id", tv[TXN_ID_LSB +: 16], 16'h1111);  ck("txn.src", tv[TXN_SRC_LSB +: 4], 4'h2);  ck("txn.dst", tv[TXN_DST_LSB +: 4], 4'h3);
    ck("txn.tenant", tv[TXN_TENANT_LSB +: 4], 4'h4);   ck("txn.queue", tv[TXN_QUEUE_LSB +: 4], 4'h5);  ck("txn.opcode", tv[TXN_OPCODE_LSB +: 8], 8'h66);
    ck("txn.proc_op", tv[TXN_PROC_OP_LSB +: 8], 8'h77); ck("txn.perm", tv[TXN_PERM_LSB +: 2], 2'b10);  ck("txn.status", tv[TXN_STATUS_LSB +: 4], 4'h8);
    ck("txn.err", tv[TXN_ERR_LSB +: 8], 8'h99);        ck("txn.tag", tv[TXN_TAG_LSB +: 32], 32'hAAAA_AAAA); ck("txn.length", tv[TXN_LEN_LSB +: 32], 32'hBBBB_BBBB);
    ck("txn.sram_off", tv[TXN_SRAM_OFF_LSB +: 32], 32'hCCCC_CCCC); ck("txn.param", tv[TXN_PARAM_LSB +: 32], 32'hDDDD_DDDD);
    ck("txn.addr_in", tv[TXN_ADDR_IN_LSB +: 64], 64'hEEEE_EEEE_1111_1111); ck("txn.addr_out", tv[TXN_ADDR_OUT_LSB +: 64], 64'h2222_2222_3333_3333);
    // function sanity
    ck("err_is_violation(ERR_PERM_READ)", err_is_violation(ERR_PERM_READ), 1);  ck("err_is_violation(ERR_BAD_LENGTH)", err_is_violation(ERR_BAD_LENGTH), 0);
    ck("err_is_violation(ERR_TENANT_MISMATCH)", err_is_violation(ERR_TENANT_MISMATCH), 1); ck("err_is_violation(ERR_HOST_MEM)", err_is_violation(ERR_HOST_MEM), 0);
    ck("op_writes_host(PKT)", op_writes_host(OP_PKT_PROCESS), 1);  ck("op_writes_host(H2D)", op_writes_host(OP_DMA_H2D), 0);
    ck("op_reads_host(H2D)", op_reads_host(OP_DMA_H2D), 1);        ck("op_is_eng(INFER)", op_is_eng(OP_INFER), 1);  ck("op_is_net(NOP)", op_is_net(OP_NOP), 0);
    $display("TB RESULT %s checks=%0d fails=%0d", fails == 0 ? "PASS" : "FAIL", checks, fails);
    if (fails == 0) $finish(0); else $fatal(1, "layout check failed");
  end
endmodule
