// =============================================================================
// CloudDPU :: tb_guard_unit -- the per-beat permission guards work WITHOUT the command processor
//
// The command processor validates every descriptor before dispatch (sfd_cmdproc).  The guards inside the job slot and
// the PacketCore hub are a second, independent line of defence: they check every actual beat against the live tenant
// context.  This test removes the first line: it drives sfd_job_slot directly with transactions that the command
// processor would have refused, and shows that no byte moves anyway.
//   DUT:  sfd_job_slot + sfd_pkt_hub + SFB2 crossbar + SRAM (sramlib) + a host-memory model, two tenants configured here
//   Each case must END with ERR_PERM_BEAT, with ZERO forbidden host accesses and ZERO changed bytes outside the
//   tenant's partition / windows.  Legal transactions run first and last to show the setup itself is sound.
// =============================================================================
`timescale 1ns/1ps
`include "sram_defs.svh"
`default_nettype none

module tb_guard_unit;
  import silicaflux_cloud_pkg::*;
  localparam int DW = 32, AW = 32, NT = 3, NW = 2, DWB = DW / 8;
  localparam int SRAMB = 16384;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  int fails = 0, checks = 0;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  task automatic check(input string w, input longint unsigned g, input longint unsigned e);
    checks++;
    if (g !== e) begin $display("[%0d] CHECK FAIL %s: got %0h exp %0h", cyc, w, g, e); fails++; end
  endtask

  // ---- tenant context (static): tenant 0 partition [0,0x1000) windows R [0x1000,+0x1000) RW [0x2000,+0x1000)
  //                              tenant 1 partition [0x1000,0x2000) window RW [0x8000,+0x1000)
  //                              tenant 2 NOT configured (cfg_ok = 0)
  logic [NT-1:0]       t_cfg_ok;
  logic [NT*32-1:0]    t_part_base, t_part_size;
  logic [NT*NW*64-1:0] t_win_base;
  logic [NT*NW*32-1:0] t_win_size;
  logic [NT*NW-1:0]    t_win_valid;
  logic [NT*NW*2-1:0]  t_win_perm;
  task automatic set_win(input int t, input int w, input longint unsigned base, input int size, input bit r, input bit wr);
    t_win_base [(t*NW + w)*64 +: 64] = base;
    t_win_size [(t*NW + w)*32 +: 32] = 32'(size);
    t_win_valid[t*NW + w]            = 1'b1;
    t_win_perm [(t*NW + w)*2 +: 2]   = {wr, r};
  endtask
  initial begin
    t_cfg_ok = '0;  t_part_base = '0;  t_part_size = '0;  t_win_base = '0;  t_win_size = '0;  t_win_valid = '0;  t_win_perm = '0;
    t_cfg_ok[0] = 1'b1;  t_part_base[0 +: 32] = 32'h0000;  t_part_size[0 +: 32] = 32'h1000;
    t_cfg_ok[1] = 1'b1;  t_part_base[32 +: 32] = 32'h1000; t_part_size[32 +: 32] = 32'h1000;
    set_win(0, 0, 64'h1000, 32'h1000, 1'b1, 1'b0);       // tenant 0: read-only window
    set_win(0, 1, 64'h2000, 32'h1000, 1'b1, 1'b1);       // tenant 0: read/write window
    set_win(1, 0, 64'h8000, 32'h1000, 1'b1, 1'b1);       // tenant 1: read/write window
  end

  // ---- DUT
  logic start = 0;
  logic [TXN_W-1:0] txn = '0;
  logic done_valid, done_ack = 0, done_commit, busy;
  logic [7:0] done_err;
  logic [31:0] done_bytes, crc_in, crc_out;
  logic [15:0] csum;
  logic [63:0] faddr;
  logic [3:0] fsm, ten;
  logic hm_rv, hm_rr, hm_rw, hm_pv, hm_pr, hm_pe;
  logic [AW-1:0] hm_ra;
  logic [DW-1:0] hm_rwd, hm_prd;
  logic [DWB-1:0] hm_rws;
  logic sm_v, sm_r, sm_w, sm_pv, sm_pr, sm_pe;
  logic [31:0] sm_a;
  logic [DW-1:0] sm_wd, sm_prd;
  logic [DWB-1:0] sm_ws;
  logic pk_req, pk_ack, pk_resv;
  logic [31:0] pk_in, pk_out, pk_len, pk_param, pk_crc_i, pk_crc_o;
  logic [7:0] pk_op, pk_err;
  logic [3:0] pk_ten;
  logic [15:0] pk_cs;
  logic ev_h, ev_d, ev_t, hub_busy, hub_job, hub_trip;
  logic [7:0] ev_b;

  sfd_job_slot #(.DW(DW), .AW(AW), .NT(NT), .NW(NW)) u_slot (
    .clk, .rst_n, .start, .start_txn(txn), .done_valid, .done_ack, .done_err, .done_bytes, .done_commit,
    .done_crc_in(crc_in), .done_crc_out(crc_out), .done_csum(csum), .done_fault_addr(faddr), .busy, .fsm_o(fsm), .tenant_o(ten),
    .t_cfg_ok, .t_part_base, .t_part_size, .t_win_base, .t_win_size, .t_win_valid, .t_win_perm,
    .hm_req_valid(hm_rv), .hm_req_ready(hm_rr), .hm_req_write(hm_rw), .hm_req_addr(hm_ra), .hm_req_wdata(hm_rwd), .hm_req_wstrb(hm_rws),
    .hm_rsp_valid(hm_pv), .hm_rsp_ready(hm_pr), .hm_rsp_rdata(hm_prd), .hm_rsp_error(hm_pe),
    .sm_req_valid(sm_v), .sm_req_ready(sm_r), .sm_req_write(sm_w), .sm_req_addr(sm_a), .sm_req_wdata(sm_wd), .sm_req_wstrb(sm_ws),
    .sm_rsp_valid(sm_pv), .sm_rsp_ready(sm_pr), .sm_rsp_rdata(sm_prd), .sm_rsp_error(sm_pe),
    .pkt_req(pk_req), .pkt_in(pk_in), .pkt_out(pk_out), .pkt_len(pk_len), .pkt_op(pk_op), .pkt_param(pk_param), .pkt_tenant(pk_ten),
    .pkt_ack(pk_ack), .pkt_res_valid(pk_resv), .pkt_res_err(pk_err), .pkt_res_crc_in(pk_crc_i), .pkt_res_crc_out(pk_crc_o), .pkt_res_csum(pk_cs),
    .ev_h2d_beat(ev_h), .ev_d2h_beat(ev_d), .ev_beat_bytes(ev_b), .ev_guard_trip(ev_t)
  );
  // PacketCore hub (one slot), its own guarded SRAM port
  logic hp_v, hp_r, hp_w, hp_pv, hp_pr, hp_pe;
  logic [31:0] hp_a;
  logic [DW-1:0] hp_wd, hp_prd;
  logic [DWB-1:0] hp_ws;
  sfd_pkt_hub #(.DW(DW), .NS(1), .NT(NT)) u_hub (
    .clk, .rst_n, .pkt_req(pk_req), .pkt_in(pk_in), .pkt_out(pk_out), .pkt_len(pk_len), .pkt_op(pk_op), .pkt_param(pk_param), .pkt_tenant(pk_ten),
    .pkt_ack(pk_ack), .pkt_res_valid(pk_resv), .pkt_res_err(pk_err), .pkt_res_crc_in(pk_crc_i), .pkt_res_crc_out(pk_crc_o), .pkt_res_csum(pk_cs),
    .t_cfg_ok, .t_part_base, .t_part_size,
    .sm_req_valid(hp_v), .sm_req_ready(hp_r), .sm_req_write(hp_w), .sm_req_addr(hp_a), .sm_req_wdata(hp_wd), .sm_req_wstrb(hp_ws),
    .sm_rsp_valid(hp_pv), .sm_rsp_ready(hp_pr), .sm_rsp_rdata(hp_prd), .sm_rsp_error(hp_pe),
    .busy(hub_busy), .ev_job(hub_job), .ev_guard_trip(hub_trip)
  );
  // SRAM: DataFabric crossbar (2 masters) + sramlib bank
  logic xs_v, xs_r, xs_w, xs_pv, xs_pr, xs_pe;
  logic [31:0] xs_a;
  logic [DW-1:0] xs_wd, xs_prd;
  logic [DWB-1:0] xs_ws;
  logic [1:0] ex_a, ex_s, ex_l, ex_r;
  logic ex_e, ex_w; logic [31:0] ex_ad; logic ex_m;
  sfb_crossbar #(.NM(2), .NS(1), .AW(32), .DW(DW), .ARB_MODE(1), .CHECK_ALIGN(1),
                 .SLV_BASE(32'h0), .SLV_MASK(~32'(SRAMB - 1)), .MST_SLV_EN(2'b11)) u_x (
    .clk, .rst_n,
    .m_req_valid({hp_v, sm_v}), .m_req_ready({hp_r, sm_r}), .m_req_write({hp_w, sm_w}), .m_req_addr({hp_a, sm_a}),
    .m_req_wdata({hp_wd, sm_wd}), .m_req_wstrb({hp_ws, sm_ws}),
    .m_rsp_valid({hp_pv, sm_pv}), .m_rsp_ready({hp_pr, sm_pr}), .m_rsp_rdata({hp_prd, sm_prd}), .m_rsp_error({hp_pe, sm_pe}),
    .s_req_valid(xs_v), .s_req_ready(xs_r), .s_req_write(xs_w), .s_req_addr(xs_a), .s_req_wdata(xs_wd), .s_req_wstrb(xs_ws),
    .s_rsp_valid(xs_pv), .s_rsp_ready(xs_pr), .s_rsp_rdata(xs_prd), .s_rsp_error(xs_pe),
    .err_evt(ex_e), .err_addr(ex_ad), .err_master(ex_m), .err_write(ex_w),
    .ev_req_accept(ex_a), .ev_req_stall(ex_s), .ev_arb_loss(ex_l), .ev_rsp_stall(ex_r)
  );
  logic [DW-1:0] tst_rd;
  sfb_sram_slave #(.DW(DW), .DEPTH(SRAMB / DWB), .READ_LATENCY(1)) u_sram (
    .clk, .rst_n, .req_valid(xs_v), .req_ready(xs_r), .req_write(xs_w), .req_addr(xs_a), .req_wdata(xs_wd), .req_wstrb(xs_ws),
    .rsp_valid(xs_pv), .rsp_ready(xs_pr), .rsp_rdata(xs_prd), .rsp_error(xs_pe),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rd)
  );
  // monitor on the SRAM slave side: every write must land inside its owner's partition
  int sram_oob_writes = 0;
  int sram_writes_t0 = 0, sram_writes_t1 = 0;
  always @(posedge clk) if (xs_v && xs_r && xs_w) begin
    if (ten == 4'd0 && !(xs_a >= 32'h0 && xs_a < 32'h1000)) sram_oob_writes++;
    if (ten == 4'd1 && !(xs_a >= 32'h1000 && xs_a < 32'h2000)) sram_oob_writes++;
  end

  // ---- host memory model (SFB2 slave), 64 KiB at 0, counts accesses per window
  byte hm [65536];
  int hm_r_cnt = 0, hm_w_cnt = 0, hm_forbidden = 0;
  logic pend = 0; logic pend_w = 0; logic [AW-1:0] pend_a; logic [DW-1:0] pend_d; logic [DWB-1:0] pend_s;
  assign hm_rr = !pend;
  assign hm_pv = pend;
  assign hm_pe = 1'b0;
  logic [DW-1:0] rdata_q;
  assign hm_prd = rdata_q;
  function automatic bit allowed_host(input logic [AW-1:0] a, input bit w, input int tenant);
    if (tenant == 0) return (a >= 32'h1000 && a < 32'h2000 && !w) || (a >= 32'h2000 && a < 32'h3000);
    if (tenant == 1) return (a >= 32'h8000 && a < 32'h9000);
    return 1'b0;
  endfunction
  always @(posedge clk) begin
    if (pend && hm_pr) pend <= 1'b0;
    if (hm_rv && hm_rr) begin
      pend <= 1'b1; pend_w <= hm_rw; pend_a <= hm_ra;
      if (!allowed_host(hm_ra, hm_rw, int'(ten))) hm_forbidden++;
      if (hm_rw) begin
        hm_w_cnt++;
        for (int b = 0; b < DWB; b++) if (hm_rws[b]) hm[hm_ra + b] = hm_rwd[8*b +: 8];
        rdata_q <= '0;
      end else begin
        hm_r_cnt++;
        for (int b = 0; b < DWB; b++) rdata_q[8*b +: 8] <= hm[hm_ra + b];
      end
    end
  end

  // ---- helpers
  function automatic logic [TXN_W-1:0] mk(input logic [7:0] op, input int tenant, input longint unsigned src, input longint unsigned dst,
                                         input int len, input int soff, input logic [7:0] pop = 0, input logic [31:0] key = 0);
    logic [TXN_W-1:0] t;
    t = '0;
    t[TXN_TENANT_LSB +: 4] = 4'(tenant);
    t[TXN_OPCODE_LSB +: 8] = op;
    t[TXN_PROC_OP_LSB +: 8] = pop;
    t[TXN_PARAM_LSB +: 32] = key;
    t[TXN_LEN_LSB +: 32] = 32'(len);
    t[TXN_SRAM_OFF_LSB +: 32] = 32'(soff);
    t[TXN_ADDR_IN_LSB +: 64] = 64'(src);
    t[TXN_ADDR_OUT_LSB +: 64] = 64'(dst);
    return t;
  endfunction
  task automatic run(input logic [TXN_W-1:0] t, output logic [7:0] err, output logic commit);
    @(negedge clk);
    txn = t; start = 1'b1;
    @(negedge clk);
    start = 1'b0;
    while (!done_valid) @(negedge clk);
    err = done_err; commit = done_commit;
    done_ack = 1'b1;
    @(negedge clk);
    done_ack = 1'b0;
    repeat (3) @(negedge clk);
  endtask
  function automatic longint unsigned sram_sum(input int base, input int size);
    longint unsigned h = 64'hCBF29CE484222325;
    for (int a = base; a < base + size; a += DWB) begin
      logic [DW-1:0] w;
      w = u_sram.u_sram.u_array.g_generic.u_mem.mem[a / DWB];
      for (int b = 0; b < DWB; b++) h = (h ^ w[8*b +: 8]) * 64'h100000001B3;
    end
    return h;
  endfunction

  logic [7:0] err; logic cmt;
  longint unsigned t1_before, t0_before;
  int r0, w0, forb0, oob0;
  initial begin
    for (int i = 0; i < 65536; i++) hm[i] = byte'(i * 7 + 3);
    repeat (5) @(posedge clk); rst_n = 1; repeat (5) @(posedge clk);
    // ---------------- sanity: legal transfers
    $display("guard: legal transfers of tenant 0 and tenant 1");
    run(mk(OP_DMA_H2D, 0, 32'h1000, 0, 100, 0), err, cmt);                  check("legal H2D t0", err, ERR_NONE);
    run(mk(OP_DMA_D2H, 0, 0, 32'h2000, 100, 0), err, cmt);                  check("legal D2H t0", err, ERR_NONE); check("D2H committed", cmt, 1);
    run(mk(OP_PKT_PROCESS, 0, 32'h1000, 32'h2400, 64, 256, PROC_XOR32, 32'hFFFF_FFFF), err, cmt);   check("legal PKT t0", err, ERR_NONE); check("PKT committed", cmt, 1);
    run(mk(OP_DMA_H2D, 1, 32'h8000, 0, 64, 0), err, cmt);                    check("legal H2D t1", err, ERR_NONE);
    check("no forbidden accesses so far", hm_forbidden, 0);
    check("no SRAM write outside the owner's partition so far", sram_oob_writes, 0);
    t0_before = sram_sum(32'h0000, 32'h1000);
    t1_before = sram_sum(32'h1000, 32'h1000);
    r0 = hm_r_cnt; w0 = hm_w_cnt; forb0 = hm_forbidden; oob0 = sram_oob_writes;

    // ---------------- every case below bypasses the command processor and MUST be stopped by a guard
    $display("guard: host window violations (txn handed straight to the slot)");
    run(mk(OP_DMA_H2D, 0, 32'h8000, 0, 64, 0), err, cmt);                    // tenant 0 reads tenant 1's window
    check("H2D from another tenant's window -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    check("... no host read was issued", hm_r_cnt, r0);
    run(mk(OP_DMA_D2H, 0, 0, 32'h8000, 64, 0), err, cmt);                    // tenant 0 writes tenant 1's window
    check("D2H into another tenant's window -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    check("... no host write was issued", hm_w_cnt, w0);
    run(mk(OP_DMA_D2H, 0, 0, 32'h1100, 64, 0), err, cmt);                    // write into tenant 0's own READ-ONLY window
    check("D2H into a read-only window -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    check("... still no host write", hm_w_cnt, w0);
    run(mk(OP_DMA_H2D, 0, 32'hF000, 0, 64, 0), err, cmt);                    // outside every window
    check("H2D outside every window -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    run(mk(OP_DMA_H2D, 2, 32'h1000, 0, 64, 0), err, cmt);                    // unconfigured tenant 2
    check("job of an unconfigured tenant -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    check("... no host access at all for the unconfigured tenant", hm_r_cnt, r0);

    $display("guard: transfer that STARTS legal and crosses the window end mid-way");
    begin
      byte canary [4];
      for (int i = 0; i < 4; i++) canary[i] = hm[32'h2FFC + i];
      run(mk(OP_DMA_D2H, 0, 0, 32'h2FF0, 64, 0), err, cmt);                  // 16 legal bytes, then the window ends at 0x3000
      check("D2H crossing the window end -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
      for (int i = 0; i < 4; i++) check($sformatf("byte beyond the window end untouched [%0d]", i), hm[32'h3000 + i], byte'((32'h3000 + i) * 7 + 3));
      check("committed flag NOT set", cmt, 0);
      check("only the 4 beats that were inside the window were written", hm_w_cnt, w0 + 4);
    end
    w0 = hm_w_cnt;                                                           // baseline for the SRAM cases: tenant 0 writes nothing more
    t1_before = sram_sum(32'h1000, 32'h1000);

    $display("guard: SRAM ownership violations");
    run(mk(OP_DMA_H2D, 0, 32'h1000, 0, 128, 32'h0FC0), err, cmt);            // staging runs from tenant 0's partition into tenant 1's
    check("H2D running past the partition end -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    run(mk(OP_DMA_H2D, 0, 32'h1000, 0, 64, 32'h1000), err, cmt);             // staging entirely in tenant 1's partition
    check("H2D into another tenant's SRAM -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    run(mk(OP_DMA_D2H, 0, 0, 32'h2000, 64, 32'h1000), err, cmt);             // read another tenant's SRAM out to the host
    check("D2H of another tenant's SRAM -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    check("... and nothing of it reached the host (writes)", hm_w_cnt, w0);
    run(mk(OP_PKT_PROCESS, 0, 32'h1000, 32'h2000, 512, 32'h0F00, PROC_PASS), err, cmt);   // PacketCore buffers cross the partition end
    check("PKT staging past the partition end -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
    check("tenant 1 partition untouched by every attack of tenant 0", sram_sum(32'h1000, 32'h1000), t1_before);
    begin
      longint unsigned beyond = sram_sum(32'h2000, 32'h2000);                 // SRAM above both partitions: owned by nobody
      run(mk(OP_PKT_PROCESS, 1, 32'h8000, 32'h8000 + 32'h800, 64, 32'hFC0, PROC_PASS), err, cmt);   // tenant 1: out buffer past ITS partition end
      check("PKT (tenant 1) out buffer past its partition end -> ERR_PERM_BEAT", err, ERR_PERM_BEAT);
      check("nothing was written outside every partition", sram_sum(32'h2000, 32'h2000), beyond);
    end

    // ---------------- the totals
    check("NO forbidden host access during the whole bypass run", hm_forbidden, forb0);
    check("NO SRAM write outside the owner's partition", sram_oob_writes, oob0);
    check("tenant 0 partition changed only by its own legal traffic (guard cases wrote nothing)", sram_sum(32'h0000, 32'h1000) !== 0, 1);
    // ---------------- the slot still works afterwards
    run(mk(OP_DMA_D2H, 0, 0, 32'h2200, 64, 0), err, cmt);                    check("slot still works after the attacks", err, ERR_NONE);
    $display("TB RESULT %s checks=%0d fails=%0d", fails == 0 ? "PASS" : "FAIL", checks, fails);
    if (fails == 0) $finish(0); else $fatal(1, "guard unit failed");
  end
  initial begin #20_000_000; $display("TB RESULT FAIL TIMEOUT"); $fatal(1, "timeout"); end
endmodule
