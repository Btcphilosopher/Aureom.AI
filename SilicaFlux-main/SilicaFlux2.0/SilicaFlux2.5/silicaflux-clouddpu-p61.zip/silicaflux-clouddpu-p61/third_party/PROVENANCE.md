# Provenance of `third_party/`

Everything under this directory is **copied byte-for-byte** from archives in the repository
`btcphilosopher/Aureom.AI` (branch `claude/silicaflux-clouddpu-arch-42qdjs`, HEAD `d013575`) and is **never edited**.

| Subdirectory | Source archive (under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`) | What was taken |
|---|---|---|
| `silicaflux-controlcore/` | `silicaflux-controlcore.zip` (Project 21) | the ControlCore RTL, its generated memory-map/boot-ROM files, its firmware support (crt0, trap entry, link script, hardware-access headers, image tool) and **the libraries it nests** under its own `third_party/`: MCU-I CPU/interrupts/WDT/DMA, SilicaFlux-V peripherals and bridge, **DataFabric** SFB2 interconnect, **SRAM Wrapper Library** |
| `silicaflux-securestore/` | `silicaflux-securestore-p59.zip` (Project 59) | only `sfsec_crc.sv` and `sfsec_pkg.sv` — used in verification as the **independent golden CRC-32** (not in the synthesizable path) |

* `MANIFEST.tsv` records, for every file, the archive, the archive's SHA-256, the member name and the file's SHA-256;
  `SHA256SUMS` is the same list in `sha256sum` format.
* `scripts/check_vendor.py` proves the tree is unmodified (`make check-vendor`); with `REPO=<path to the repository>` it
  also re-reads the archives and compares the bytes (done during development: 80 files, 0 differences).
* **License.** No license file exists in the repository. This directory therefore carries none, and neither does the
  project: *an owner must decide the license before any external distribution.*
* Third-party code *inside* those archives (e.g. the SecureStore AES core from secworks, which is **not** vendored here) keeps
  its own notices in its origin archive.
