# 03 -- Boot sequence

Every stage is published in `SYSCTRL.BOOT_STAGE` (host-readable at any time through the host port); errors in
`SYSCTRL.BOOT_STATUS`. Values: `CC_BOOT_STAGE_*` / `CC_BOOT_ERR_*` in the generated map.

| # | Brief step | Stage (value) | Who | What happens |
|---|---|---|---|---|
| 1 | Reset assertion and release | `RESET` (0x00) | hardware | POR / soft / watchdog / host reset; stretched to 16 cycles; synchronous release. `RESET_CAUSE` records why. |
| 2 | Boot ROM execution | `ROM_START` (0x01) | ROM | `mtvec` -> ROM trap handler; **DMEM scrubbed** (every word written before parity checking is enabled) |
| 3 | Memory and peripheral initialisation | `ROM_INIT` (0x02) | ROM | INTC, DMA interrupts and RAS enables to a known state; DMEM pattern test (`addr ^ 0xA5A55A5A`); cold boot: **IMEM scrubbed**, then `RAS.PAR_CHK_EN = 1` |
| -- | Image transfer | `WAIT_IMAGE` (0x03) / `IMAGE_CHECK` (0x04) | ROM | see section 2 |
| 5 | Firmware startup | `FW_START` (0x05) -> `FW_INIT` (0x06) | ROM -> firmware | `SECURITY.BOOT_MEASURE` = image CRC32 (write-once), `fence.i`, jump to the header's entry. Firmware: copy `.data`, zero `.bss`, reset cause read and cleared, INTC priorities, timer tick, watchdog, RAS enables. |
| 4 | Accelerator discovery | `ACC_DISCOVERY` (0x07) | firmware | expected-trap probes of the tile (`ID = "SFHT"`, version, configuration) and of the tensor unit (`ID = "SFTC"`, ABI v2, capabilities); interrupts enabled on both |
| -- | Power-on self test | `SELF_TEST` (0x08) | firmware | one NOP round trip per accelerator **by interrupt**, one DMA transfer, parity check active |
| 6 | Command processor readiness | `CMDPROC_READY` (0x09) | firmware | host write lock set (`SECURITY.CTRL.HOST_LOCK`), `HOST_STATUS.CMDPROC_READY` (pin `cmdproc_ready_o`), `DEGRADED` if an accelerator is missing |
| 7 | Host-ready status | `HOST_READY` (0x0A) | firmware | capabilities in `F2H_MSG1..6` (accelerator mask, tile CONFIG0, tensor INFO, reset cause, firmware version, image CRC), `F2H_RING` (pin `host_irq_o`), then `HOST_STATUS.HOST_READY` (pin `host_ready_o`) |

Step 4 (discovery) is done by the firmware after it starts, i.e. after step 5; the table keeps the brief's
numbering. Measured on the RTL (boot from host, `reports/sim/boot_host_bp0_s1.log`): ROM banner at cycle 24 862,
image written by the host in 15 704 cycles (8 504 words), image accepted (header + CRC32 of 31 KB) 378 661
cycles after the doorbell, firmware entry at 690 174, **HOST_READY at 729 055 cycles** (29 ms at 25 MHz).

## 2. Boot sources

`SYSCTRL.BOOT_MODE` = synchronised straps `boot_mode_i[1:0]`.

* **Cold boot, `BOOT_MODE_HOST` (0):** the ROM waits in `WAIT_IMAGE`. The host writes the image into IMEM
  through the host port (word writes from `CC_IMEM_BASE`), sets `H2F_MSG0 = IMAGE_READY` and rings `H2F_RING`.
  The ROM checks the image; OK -> answer `OK` in `F2H_MSG0`, ring `F2H`, start it. Error -> `BOOT_ERROR`,
  `BOOT_STATUS = CC_BOOT_ERR_*`, answer `BAD_CMD` with the reason in `F2H_MSG1`, and wait for the next
  `IMAGE_READY` (the host can correct the image without a reset). Other commands get `BUSY`.
* **Cold boot, `BOOT_MODE_EXT` (1):** the ROM copies the header from device memory (`H2F_MSG1` if non-zero,
  else `CC_EXT_IMAGE_DEFAULT = 0x200F_0000`) with the **system DMA**, checks it, copies the payload, checks the
  CRC. Any failure falls back to host loading.
* **Warm boot** (`RESET_CAUSE` has SOFT or WDT): IMEM is not scrubbed; if the retained image still passes the
  header and CRC checks it is restarted without the host (`BOOT_STATUS[8] = WARM`); otherwise cold boot.
  A host-requested reset is always a cold boot.

## 3. Image format (`scripts/mkimage.py`, `cc_image_hdr_t` in `firmware/include/cc_hw.h`)

| Offset | Field | Check by the ROM |
|---|---|---|
| 0x00 | magic `0x43434653` ("SFCC") | `BOOT_ERR_MAGIC` |
| 0x04 | header version (1) | `BOOT_ERR_HDR_VERSION` |
| 0x08 | image size in bytes, header included, multiple of 4 | `> 0x100`, `<= IMEM`, `BOOT_ERR_SIZE` |
| 0x0C | entry point | inside the payload, aligned, `BOOT_ERR_ENTRY` |
| 0x10 | load address (= `CC_IMEM_BASE`) | `BOOT_ERR_SIZE` |
| 0x14 | CRC-32 (IEEE 802.3, reflected) of bytes `[0x100, size)` | `BOOT_ERR_CRC` |
| 0x18 | firmware version | -- |
| 0x1C | flags (0) | -- |
| 0x20 | name (32 bytes) | -- |
| 0x100 | payload: `.text`, `.rodata`, `.data` load image | |

## 4. What the boot does NOT do (security)

The CRC32 detects accidental corruption only. **It is not authentication**: anyone who can write IMEM or the
device-memory image can produce a matching CRC. There is no signature check, no key, no secure boot and no
hardware root of trust; `SECURITY.CAPS[3:0] = 0` and `SECURITY.STATUS.AUTH_STATE = 0` ("not implemented:
image unauthenticated") say so to the host, and the firmware prints it at start-up. `SECURITY.AUTH_HOOK` is
reserved for the Project 28 engine. Implemented protections are limited to: the host write lock (after the
firmware started, host writes to BOOTROM/IMEM/DMEM are refused and logged), execute-never on DMEM/EXT/PERIPH,
and the write-once `BOOT_MEASURE` register.

## 5. Verified (system scenarios, `reports/regression.md`)

`boot_host` (load, accept, start, host lock), `boot_ext` (DMA boot from device memory, also under 25 %
back-pressure), `bad_image` (CRC rejection, `BOOT_ERROR` visible to the host, corrected image accepted without
reset, host reset -> cold boot -> reload -> cause HOST), `wdt_reset` (watchdog reset -> warm boot without the
host, cause WDT, POR-domain evidence kept).
