# 09 -- Known limitations and open items

Stated plainly so that nothing in this package is read as a claim it does not make.

## Evidence limits

* **Simulation only.** All functional results are RTL simulation (Verilator 5.020; Icarus 12 for elaboration
  only). No gate-level simulation, no formal proof of the new RTL, no silicon.
* **No FPGA board.** A bitstream for the ControlCore harness was generated (ULX3S, LFE5U-85F) and the harness was
  simulated; it has **never been loaded on hardware**. Timing is a single-seed nextpnr post-route estimate.
* **The complete system (ControlCore + vector tile + tensor unit) was not placed and routed** on an FPGA; only
  a Yosys resource estimate exists (`reports/fpga.md`). The FPGA harness has no accelerators.
* **No RISC-V compliance claim**: riscv-tests (not riscv-arch-test) on the CPU, as recorded by MCU-I and re-run here.
* Accelerator correctness beyond what the ControlCore firmware and testbench check (bit-exact results for the
  workloads in doc 05) relies on the accelerators' own verification (their archives' reports).

## Functional limits (v1)

* **No firmware authentication, secure boot, root of trust, key storage or debug authentication.** CRC32 is an
  integrity check. Project 28 must supply and verify authentication; `SECURITY.AUTH_HOOK` is the reserved
  integration point. Reported by `SECURITY.CAPS/STATUS` and on the console.
* No debug port / RISC-V debug module in the ControlCore (MCU-I's JTAG was not integrated).
* Single clock domain; the accelerator clock is a gated copy. No DVFS, no power switches / retention.
* Host port: one transaction at a time; a host access in flight when a ControlCore reset is applied is lost
  (the host must not access the ControlCore while it resets -- `host_ready_o` low, `BOOT_STAGE` polling resumes
  after the reset). Host and firmware share the mailbox page; the register bus cannot tell them apart, so the
  direction of each mailbox register is a software convention.
* Host write lock is coarse (all of BOOTROM/IMEM/DMEM, set-only until a system reset).
* Mailbox command processor handles one command at a time (no command queue); a command sent before the
  previous answer is acknowledged overwrites the argument registers.
* Console FIFO keeps the first 256 unread characters; later characters are dropped until the host drains it
  (`OVF` flag). The FPGA harness UART has the same drop policy (115200 baud is slower than the firmware prints).
* The FPGA harness device memory is 64 KiB and aliases every EXT address into it.
* IMEM-parity soft-reset policy (doc 02 section 6) is implemented but not exercised by the regression.
* RAS: level sources (`EXT_WARN`, `EXT_FATAL`, `TSU_HALTED`) are masked by the firmware handler until their
  cause is cleared; counts saturate at 2^32 - 1.
* `cc_perf` is area-heavy for what it does (largest new block, about 4 k LUT4 on ECP5).

## Verification gaps

* No randomised / constrained-random test of the ControlCore crossbar under concurrent host + CPU + DMA traffic
  beyond the scenarios (the crossbar itself is DataFabric-verified).
* No coverage measurement collected for the new RTL.
* Reset during an outstanding accelerator command is exercised only through the PMU reset of the accelerator
  domain (T10), not by an unexpected ControlCore reset during a GEMM.
* Cross-simulator (Icarus) runs of the system scenarios were not performed (Icarus elaborates the ControlCore;
  the system testbench uses SystemVerilog features tuned for Verilator).
