// =============================================================================
// SilicaFlux CloudDPU (Project 61) :: silicaflux_cloud_pkg -- shared transaction format
//
// SINGLE SOURCE OF TRUTH for every constant, field position and error code that
// crosses a module, firmware or testbench boundary.
//
//   * Synthesizable RTL uses ONLY the localparams and functions of this package,
//     fully qualified (silicaflux_cloud_pkg::NAME), on flat bit vectors.  Reason:
//     the baseline flow (Yosys 0.33) rejects `import`, structs and `return`
//     (third_party silicaflux-v RTL_CODING_RULES.md; re-verified for this project,
//     docs/05_VERIFICATION.md).  Fully qualified references are accepted.
//   * Testbenches `import silicaflux_cloud_pkg::*` and use the packed-struct views at
//     the end of this file.  tb/tb_layout_check.sv proves that the struct views and
//     the flat field positions used by the RTL describe the same bits.
//   * Firmware gets the same numbers from scripts/gen_dpu_memmap.py (include/
//     generated/dpu_abi.h), which is checked against this file (make check-abi).
//
// COMMON TRANSACTION FORMAT (project brief, section 4)
//   A transaction carries: transaction ID, source and destination endpoint, tenant
//   (domain) ID, operation code, memory address, transfer length, permissions,
//   status, error code and completion tag.  It exists in three renderings of the
//   same fields:
//     sfc_cmd   host-visible submission descriptor  (CMD_W  = 384 bit, 12 words)
//     sfc_txn   internal transaction bundle         (TXN_W  = 320 bit)
//     sfc_cpl   host-visible completion record      (CPL_W  = 256 bit,  8 words)
//   The host cannot choose the transaction ID, the source, the destination or the
//   tenant that is authoritative: the DPU assigns the ID and takes the tenant from
//   the QUEUE the descriptor arrived on (hardware binding).  The tenant field inside
//   a descriptor is only a claim that is checked against that binding.
//
// Byte order: little endian everywhere (byte i of a word is bits [8i+7:8i]); host
// descriptors and completion records are arrays of 32-bit little-endian words.
// Classification: SYNTHESIZABLE (constants/functions), VERIFICATION-ONLY (struct views)
// =============================================================================
package silicaflux_cloud_pkg;

  // ---------------------------------------------------------------- identification
  localparam logic [31:0] DPU_ID_MAGIC  = 32'h5346_4450;   // "SFDP"
  localparam logic [15:0] DPU_ABI_MAJOR = 16'd1;
  localparam logic [15:0] DPU_ABI_MINOR = 16'd0;
  localparam logic [31:0] DPU_RTL_VER   = 32'h0001_0000;   // Project 61 RTL 1.0

  // ---------------------------------------------------------------- field widths and limits
  localparam int TENANT_W      = 4;     // tenant (domain) id
  localparam int QUEUE_W       = 4;     // queue id
  localparam int OPC_W         = 8;
  localparam int ERR_W         = 8;
  localparam int STATUS_W      = 4;
  localparam int TXN_ID_W      = 16;
  localparam int TAG_W         = 32;
  localparam int LEN_W         = 32;
  localparam int HADDR_MAX_W   = 64;    // widest supported host (IOVA) address
  localparam int MAX_TENANTS   = 16;
  localparam int MAX_HOST_QUEUES = 15;  // queue ids 0..14; id 15 is the management queue
  localparam int MGMT_QUEUE_ID = 15;
  localparam int MAX_WINDOWS   = 8;     // host windows per tenant
  localparam int SRAM_PAGE_BYTES = 256; // granularity of SRAM partitions (base and size)

  // ---------------------------------------------------------------- endpoints (source / destination)
  localparam logic [3:0] EP_HOST      = 4'd0;   // simulated host / virtual function
  localparam logic [3:0] EP_FW        = 4'd1;   // ControlCore firmware (management)
  localparam logic [3:0] EP_CMDPROC   = 4'd2;
  localparam logic [3:0] EP_CLOUDDMA  = 4'd3;
  localparam logic [3:0] EP_SRAM      = 4'd4;
  localparam logic [3:0] EP_PACKET    = 4'd5;
  localparam logic [3:0] EP_INFER     = 4'd6;
  localparam logic [3:0] EP_CRYPTO    = 4'd7;
  localparam logic [3:0] EP_STORAGE   = 4'd8;
  localparam logic [3:0] EP_TELEMETRY = 4'd9;
  localparam logic [3:0] EP_NONE      = 4'd15;

  // ---------------------------------------------------------------- operation codes
  localparam logic [7:0] OP_NOP         = 8'h00;  // queue round trip, no data
  localparam logic [7:0] OP_PKT_PROCESS = 8'h01;  // host -> SRAM -> PacketCore -> SRAM -> host
  localparam logic [7:0] OP_DMA_H2D     = 8'h02;  // host -> SRAM
  localparam logic [7:0] OP_DMA_D2H     = 8'h03;  // SRAM -> host
  localparam logic [7:0] OP_INFER       = 8'h10;  // InferenceScheduler  (BLOCKED unless ENABLE_TENSOR)
  localparam logic [7:0] OP_CRYPTO      = 8'h11;  // CryptoCore          (BLOCKED unless ENABLE_CRYPTO)
  localparam logic [7:0] OP_STORAGE     = 8'h12;  // StorageFabric       (BLOCKED unless ENABLE_STORAGE)

  // PacketCore processing operations (descriptor word 8).  These belong to the PacketCore
  // TEST ADAPTER (rtl/dpu/sfd_packetcore_tadapter.sv); none of them is cryptography.
  localparam logic [7:0] PROC_PASS      = 8'h00;  // out = in
  localparam logic [7:0] PROC_XOR32     = 8'h01;  // out = in ^ (param repeated every 4 bytes)
  localparam logic [7:0] PROC_BSWAP32   = 8'h02;  // swap the bytes of every 32-bit word (length % 4 == 0)

  // ---------------------------------------------------------------- permissions
  localparam logic [1:0] PERM_NONE = 2'b00;
  localparam logic [1:0] PERM_R    = 2'b01;
  localparam logic [1:0] PERM_W    = 2'b10;
  localparam logic [1:0] PERM_RW   = 2'b11;

  // ---------------------------------------------------------------- completion status
  localparam logic [3:0] ST_OK      = 4'd0;   // executed, output committed (if any)
  localparam logic [3:0] ST_ERROR   = 4'd1;   // rejected or failed; `err` says why
  localparam logic [3:0] ST_ABORTED = 4'd2;   // cancelled by a data-plane reset

  // ---------------------------------------------------------------- error codes
  localparam logic [7:0] ERR_NONE            = 8'h00;
  // descriptor / policy errors (no data moved)
  localparam logic [7:0] ERR_BAD_OPCODE      = 8'h01;
  localparam logic [7:0] ERR_BAD_DESC        = 8'h02;  // reserved field not zero
  localparam logic [7:0] ERR_BAD_LENGTH      = 8'h03;
  localparam logic [7:0] ERR_ALIGN           = 8'h04;
  localparam logic [7:0] ERR_TENANT_STATE    = 8'h05;  // tenant not ACTIVE (disabled / draining / scrubbing)
  localparam logic [7:0] ERR_QUARANTINED     = 8'h06;
  localparam logic [7:0] ERR_BLOCKED         = 8'h07;  // engine class not integrated / not verified
  localparam logic [7:0] ERR_BAD_TENANT      = 8'h08;
  localparam logic [7:0] ERR_PROC_OP         = 8'h09;  // unknown PacketCore op, or length not valid for the op
  // isolation violations (these count as security events, 0x10..0x14)
  localparam logic [7:0] ERR_TENANT_MISMATCH = 8'h10;  // descriptor tenant != queue binding
  localparam logic [7:0] ERR_PERM_READ       = 8'h11;  // host source not inside a readable window of the tenant
  localparam logic [7:0] ERR_PERM_WRITE      = 8'h12;  // host destination not inside a writable window
  localparam logic [7:0] ERR_SRAM_RANGE      = 8'h13;  // SRAM buffers outside the tenant's partition
  localparam logic [7:0] ERR_PERM_BEAT       = 8'h14;  // per-beat guard refused an access (defence in depth)
  // execution faults
  localparam logic [7:0] ERR_HOST_MEM        = 8'h20;  // host memory answered with an error
  localparam logic [7:0] ERR_SRAM_RESP       = 8'h21;  // local SRAM / fabric error
  localparam logic [7:0] ERR_TIMEOUT         = 8'h22;  // job watchdog
  localparam logic [7:0] ERR_RESET_ABORT     = 8'h23;  // data-plane reset
  localparam logic [7:0] ERR_INTERNAL        = 8'h24;

  function automatic logic err_is_violation(input logic [7:0] e);
    err_is_violation = (e >= 8'h10) && (e <= 8'h14);
  endfunction

  // ---------------------------------------------------------------- tenant states
  localparam logic [2:0] TS_DISABLED    = 3'd0;  // configurable; accepts no work
  localparam logic [2:0] TS_ACTIVE      = 3'd1;
  localparam logic [2:0] TS_DRAINING    = 3'd2;  // no new work, waiting for in-flight commands
  localparam logic [2:0] TS_SCRUBBING   = 3'd3;  // SRAM partition being zeroed
  localparam logic [2:0] TS_QUARANTINED = 3'd4;  // isolation violation: no new work until RECOVER

  // tenant commands (TENANT.CMD register)
  localparam logic [31:0] TCMD_COMMIT  = 32'd1;  // validate shadow configuration, scrub partition
  localparam logic [31:0] TCMD_ENABLE  = 32'd2;  // DISABLED && configured -> ACTIVE
  localparam logic [31:0] TCMD_DISABLE = 32'd3;  // ACTIVE/QUARANTINED -> drain -> scrub -> DISABLED
  localparam logic [31:0] TCMD_RECOVER = 32'd4;  // same as DISABLE (named for the quarantine flow)

  // tenant configuration commit results (TENANT.CFG_STATUS)
  localparam logic [7:0] CFG_NONE         = 8'h00;
  localparam logic [7:0] CFG_OK           = 8'h01;
  localparam logic [7:0] CFG_BUSY         = 8'h10;  // tenant not DISABLED
  localparam logic [7:0] CFG_BAD_PART     = 8'h11;  // partition empty, unaligned or outside SRAM
  localparam logic [7:0] CFG_BAD_WINDOW   = 8'h12;  // window empty or wraps the address space
  localparam logic [7:0] CFG_OVERLAP_SRAM = 8'h13;  // partition overlaps another configured tenant
  localparam logic [7:0] CFG_OVERLAP_HOST = 8'h14;  // host window overlaps a window of another tenant
  localparam logic [7:0] CFG_NO_TENANT    = 8'h15;
  localparam logic [7:0] CFG_SCRUB_FAIL   = 8'h16;  // the SRAM scrub got an error response; partition released
  localparam logic [31:0] TCMD_RELEASE    = 32'd5;  // DISABLED -> give the partition and windows back

  // ---------------------------------------------------------------- fault bits (FAULT_STATUS, sticky W1C)
  localparam int FLT_PERM_VIOL  = 0;   // any isolation violation (err 0x10..0x14)
  localparam int FLT_HOST_ERR   = 1;   // host memory error response
  localparam int FLT_DESC_ERR   = 2;   // malformed descriptor
  localparam int FLT_TIMEOUT    = 3;   // job watchdog expired
  localparam int FLT_SRAM_ERR   = 4;
  localparam int FLT_INTERNAL   = 5;
  localparam int FLT_RESET_DONE = 6;   // a data-plane reset completed (informational)
  localparam int FLT_TLM_DROP   = 7;   // telemetry event lost
  localparam int FLT_NUM        = 8;

  // ---------------------------------------------------------------- interface / block status (BLOCK_STATUS, 2 bit each)
  localparam logic [1:0] BLK_ABSENT       = 2'd0;
  localparam logic [1:0] BLK_BLOCKED      = 2'd1;  // interface exists; every job is refused with ERR_BLOCKED
  localparam logic [1:0] BLK_TEST_ADAPTER = 2'd2;  // behavioural stand-in, NOT the real block
  localparam logic [1:0] BLK_REAL         = 2'd3;  // real, verified implementation

  // ---------------------------------------------------------------- host <-> ControlCore firmware mailbox protocol (DPU firmware)
  // Command codes written to MAILBOX.H2F_MSG0 by the host; arguments in H2F_MSG1..7; the answer arrives in F2H_MSG0..7
  // (F2H_MSG0 = status | cmd << 8 | seq << 16).  Codes 0x40.. are free in the ControlCore protocol (docs/MEMORY_MAP.md).
  localparam logic [31:0] DPUCMD_INFO     = 32'h40;   // -> ID, VERSION, CONFIG0, CONFIG1, SRAM_BYTES, BLOCK_STATUS, FEATURES
  localparam logic [31:0] DPUCMD_CONFIG   = 32'h41;   // a1 tenant, a2 host in-window base, a3 SRAM partition size -> cfg status, tenant state
  localparam logic [31:0] DPUCMD_SELFTEST = 32'h42;   // a1 group mask (0 = all) -> checks, fails
  localparam logic [31:0] DPUCMD_SUBMIT   = 32'h43;   // a1 op|pop<<8|tenant<<16 a2 tag a3 src a4 dst a5 len a6 soff a7 param -> completion words 0..6
  localparam logic [31:0] DPUCMD_FAULTS   = 32'h44;   // -> fault bits, fault count, last tenant, last err, last addr, fault IRQ count
  localparam logic [31:0] DPUCMD_PERF     = 32'h45;   // -> accepted, retired, errors, DMA bytes rd, DMA bytes wr, violations
  localparam logic [31:0] DPUCMD_RECOVER  = 32'h46;   // a1 tenant (0xFF = data-plane reset) -> tenant state / reset count

  // ---------------------------------------------------------------- telemetry event codes
  localparam logic [7:0] TLM_CMD_RETIRE   = 8'h01;  // arg = {err, status}
  localparam logic [7:0] TLM_VIOLATION    = 8'h02;  // arg = error code
  localparam logic [7:0] TLM_TENANT_STATE = 8'h03;  // arg = new state
  localparam logic [7:0] TLM_FAULT        = 8'h04;  // arg = fault bit
  localparam logic [7:0] TLM_DP_RESET     = 8'h05;
  localparam int         TLM_W            = 80;     // {ts[31:0], arg[31:0], event[7:0], queue[3:0], tenant[3:0]}

  // ---------------------------------------------------------------- flat descriptor layout: sfc_cmd (384 bit)
  localparam int CMD_NW = 12;
  localparam int CMD_W  = 384;
  localparam int CMD_OPCODE_LSB   = 0;     // W0[7:0]
  localparam int CMD_FLAGS_LSB    = 8;     // W0[15:8]
  localparam int CMD_TENANT_LSB   = 16;    // W0[19:16]
  localparam int CMD_W0_RSVD_LSB  = 20;    // W0[31:20] must be 0
  localparam int CMD_TAG_LSB      = 32;    // W1
  localparam int CMD_SRC_LSB      = 64;    // W2,W3 host input address
  localparam int CMD_DST_LSB      = 128;   // W4,W5 host output address
  localparam int CMD_LEN_LSB      = 192;   // W6 bytes
  localparam int CMD_SRAM_OFF_LSB = 224;   // W7 staging offset inside the tenant partition
  localparam int CMD_PROC_OP_LSB  = 256;   // W8[7:0]
  localparam int CMD_W8_RSVD_LSB  = 264;   // W8[31:8] must be 0
  localparam int CMD_PARAM_LSB    = 288;   // W9
  localparam int CMD_RSVD_LSB     = 320;   // W10,W11 must be 0
  localparam int CMD_FLAG_IRQ     = 0;     // flags[0]: request an interrupt on completion (management queue)

  // ---------------------------------------------------------------- flat completion layout: sfc_cpl (256 bit)
  localparam int CPL_NW = 8;
  localparam int CPL_W  = 256;
  localparam int CPL_OPCODE_LSB = 0;       // W0[7:0]
  localparam int CPL_STATUS_LSB = 8;       // W0[15:8]
  localparam int CPL_ERR_LSB    = 16;      // W0[23:16]
  localparam int CPL_TENANT_LSB = 24;      // W0[27:24]
  localparam int CPL_QUEUE_LSB  = 28;      // W0[31:28]
  localparam int CPL_TAG_LSB     = 32;     // W1
  localparam int CPL_TXN_LSB     = 64;     // W2[15:0]
  localparam int CPL_FLAGS_LSB   = 80;     // W2[31:16]
  localparam int CPL_BYTES_LSB   = 96;     // W3 bytes of output committed (or input staged for H2D)
  localparam int CPL_CRC_IN_LSB  = 128;    // W4 CRC-32 (IEEE 802.3) of the input stream
  localparam int CPL_CRC_OUT_LSB = 160;    // W5 CRC-32 of the output stream
  localparam int CPL_CSUM_LSB    = 192;    // W6[15:0] RFC 1071 internet checksum of the output stream
  localparam int CPL_TS_LSB      = 224;    // W7 cycle counter at commit
  localparam int CPL_FLAG_COMMITTED = 0;   // flags[0]: every output byte was acknowledged by the destination

  // ---------------------------------------------------------------- flat internal transaction: sfc_txn (320 bit)
  localparam int TXN_W = 320;
  localparam int TXN_ID_LSB       = 0;     // [15:0]
  localparam int TXN_SRC_LSB      = 16;    // [19:16]
  localparam int TXN_DST_LSB      = 20;    // [23:20]
  localparam int TXN_TENANT_LSB   = 24;    // [27:24]
  localparam int TXN_QUEUE_LSB    = 28;    // [31:28]
  localparam int TXN_OPCODE_LSB   = 32;    // [39:32]
  localparam int TXN_PROC_OP_LSB  = 40;    // [47:40]
  localparam int TXN_PERM_LSB     = 48;    // [49:48] permissions the operation needs on its host buffers
  localparam int TXN_STATUS_LSB   = 52;    // [55:52]
  localparam int TXN_ERR_LSB      = 56;    // [63:56]
  localparam int TXN_TAG_LSB      = 64;    // [95:64]
  localparam int TXN_LEN_LSB      = 96;    // [127:96]
  localparam int TXN_SRAM_OFF_LSB = 128;   // [159:128]
  localparam int TXN_PARAM_LSB    = 160;   // [191:160]
  localparam int TXN_ADDR_IN_LSB  = 192;   // [255:192]
  localparam int TXN_ADDR_OUT_LSB = 256;   // [319:256]

  // ---------------------------------------------------------------- operation classes
  function automatic logic op_is_net(input logic [7:0] op);     // PacketCore / CloudDMA operations
    op_is_net = (op == OP_PKT_PROCESS) || (op == OP_DMA_H2D) || (op == OP_DMA_D2H);
  endfunction
  function automatic logic op_is_eng(input logic [7:0] op);     // engine classes behind a blocked interface
    op_is_eng = (op == OP_INFER) || (op == OP_CRYPTO) || (op == OP_STORAGE);
  endfunction
  function automatic logic op_reads_host(input logic [7:0] op); // consumes a host input buffer
    op_reads_host = (op == OP_PKT_PROCESS) || (op == OP_DMA_H2D);
  endfunction
  function automatic logic op_writes_host(input logic [7:0] op);// produces a host output buffer (commit required)
    op_writes_host = (op == OP_PKT_PROCESS) || (op == OP_DMA_D2H);
  endfunction

  // =============================================================================
  // VERIFICATION-ONLY VIEWS (structs).  Not used by synthesizable RTL (Yosys 0.33).
  // Field order is MSB -> LSB so that word i of the packed value is bits [32*i +: 32].
  // =============================================================================
  typedef struct packed {
    logic [31:0] w11_rsvd;
    logic [31:0] w10_rsvd;
    logic [31:0] param;                         // W9
    logic [23:0] w8_rsvd;
    logic [7:0]  proc_op;                       // W8
    logic [31:0] sram_off;                      // W7
    logic [31:0] length;                        // W6
    logic [63:0] dst;                           // W4,W5
    logic [63:0] src;                           // W2,W3
    logic [31:0] tag;                           // W1
    logic [11:0] w0_rsvd;
    logic [3:0]  tenant;
    logic [7:0]  flags;
    logic [7:0]  opcode;                        // W0
  } sfc_cmd_t;

  typedef struct packed {
    logic [31:0] ts;                            // W7
    logic [15:0] w6_rsvd;
    logic [15:0] csum;                          // W6
    logic [31:0] crc_out;                       // W5
    logic [31:0] crc_in;                        // W4
    logic [31:0] bytes;                         // W3
    logic [15:0] flags;
    logic [15:0] txn_id;                        // W2
    logic [31:0] tag;                           // W1
    logic [3:0]  queue;
    logic [3:0]  tenant;
    logic [7:0]  err;
    logic [7:0]  status;
    logic [7:0]  opcode;                        // W0
  } sfc_cpl_t;

  typedef struct packed {
    logic [63:0] addr_out;
    logic [63:0] addr_in;
    logic [31:0] param;
    logic [31:0] sram_off;
    logic [31:0] length;
    logic [31:0] tag;
    logic [7:0]  err;
    logic [3:0]  status;
    logic [1:0]  rsvd_b;
    logic [1:0]  perm;
    logic [7:0]  proc_op;
    logic [7:0]  opcode;
    logic [3:0]  queue;
    logic [3:0]  tenant;
    logic [3:0]  dst;
    logic [3:0]  src;
    logic [15:0] txn_id;
  } sfc_txn_t;

endpackage
