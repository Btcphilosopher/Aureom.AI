// =============================================================================
// SilicaFlux CloudDPU (Project 61) :: silicaflux_cloud_dpu -- cloud data processing unit, top level
//
//   host / virtual functions                                                      management plane
//   ┌──────────────────────┐                                                      ┌───────────────────────────────┐
//   │ vio_sub_*  (submit)  │──► sfd_cmdq ──► sfd_cmdproc ──► sfd_job_slot x NCH   │ silicaflux_control_core        │
//   │ vio_cpl_*  (complete)│◄── (per queue)   │  ▲ validate    │ CloudDMA          │ RV32IM_Zicsr, boot ROM, INTC,   │
//   └──────────────────────┘                  │  │ tenant ctx  │ host guard        │ mailbox, host port (hs_*)       │
//   hm_* host memory ◄──── sfd_fabric ◄───────┘  │             │ SRAM guard        │ register pages 8..15 ──► DPU    │
//                          │ SFB2 crossbar       sfd_tenant_ctx└─► sfd_pkt_hub ─►  │ EXT window ──► local SRAM       │
//                          │ SRAM banks (sramlib)  (partitions, windows,   PacketCore └───────────────────────────────┘
//   tlm_* ◄─ sfd_tlm       │                       scrub)         TEST ADAPTER
//
// Project-brief items and where they live
//   1 RISC-V ControlCore        silicaflux_control_core (Project 21, vendored unmodified)         BLK_REAL
//   2 Cloud command processor   sfd_cmdproc (+ sfd_cmdq)                                          new, verified here
//   3 DataFabric                sfd_fabric: DataFabric sfb_crossbar (reused) + SRAM Wrapper Library banks
//   4 PacketCore interface      sfd_packetcore_tadapter via sfd_pkt_hub                           BLK_TEST_ADAPTER
//   5 CloudDMA interface        sfd_clouddma in sfd_job_slot + guards                             new, verified here
//   6 VirtualIO interface       vio_sub_* / vio_cpl_* queue ports; the host side is a testbench   BLK_TEST_ADAPTER
//   7 Local SRAM                sfd_fabric banks (sramlib sram_sp), tenant partitions
//   8 InferenceScheduler        compute-class queues + OP_INFER, refused with ERR_BLOCKED        BLK_BLOCKED
//   9 CryptoCore                OP_CRYPTO, refused with ERR_BLOCKED                               BLK_BLOCKED
//  10 StorageFabric             OP_STORAGE, refused with ERR_BLOCKED                              BLK_BLOCKED
//  11 CloudTelemetry            tlm_* event port (sfd_tlm) + performance counters (sfd_perf)      BLK_REAL (interface only)
//  12 Clock / reset / RAS       clk, rst_ni, boot_mode_i, host_rst_req_i, ext_warn_i / ext_fatal_i, ras_fatal_o;
//                               DPU faults feed the ControlCore RAS inputs through FAULT_WARN / FAULT_FATAL masks
//
// ADVANCED BLOCKS ARE NOT ENABLED.  ENABLE_TENSOR / ENABLE_CRYPTO / ENABLE_STORAGE must be 0: setting one is an
// elaboration error until the corresponding block has been integrated AND individually verified.
//
// ISOLATION.  Tenants (virtual functions) reach the DPU only through their own queue (vio_sub_q selects the
// queue; the tenant is the queue's hardware binding).  The management registers, the tenant configuration and
// the SRAM window are reachable only through the ControlCore.  Permission enforcement cannot be switched off:
// there is no parameter or register that bypasses the per-beat guards, which is why NUM_TENANTS > 1 is legal.
//
// CLOCKS / RESETS.  One functional clock.  The DPU runs on the ControlCore's accelerator clock acc_clk_o (an ICG
// copy of clk; define SFV_NO_CLOCK_GATE for a pass-through) and acc_rst_no.  Persistent blocks (queues, tenant
// contexts, counters, registers) use acc_rst_no; the data plane (job slots, DMA, PacketCore, crossbars, SRAM
// controllers) additionally resets on DP_RESET.  All the ready/valid ports below are synchronous to clk.
//
// Register map: config/dpu_memmap.yaml (pages 8..15 of the ControlCore PERIPH window).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module silicaflux_cloud_dpu #(
  // ---- brief section 3
  parameter int NUM_NETWORK_QUEUES = 1,
  parameter int NUM_DMA_CHANNELS   = 1,
  parameter int NUM_TENANTS        = 1,
  parameter int NUM_COMPUTE_QUEUES = 1,
  parameter int DATA_WIDTH         = 32,          // 32 / 64 / 128
  parameter int ADDRESS_WIDTH      = 32,          // host (IOVA) address width, 32..64
  parameter int SRAM_CAPACITY      = 65536,       // bytes of local SRAM
  parameter int ENABLE_TENSOR      = 0,           // must be 0 (blocked, see header)
  parameter int ENABLE_CRYPTO      = 0,           // must be 0
  parameter int ENABLE_STORAGE     = 0,           // must be 0
  // ---- additional
  parameter int NUM_SRAM_BANKS     = 1,
  parameter int QUEUE_DEPTH        = 4,
  parameter int CPLQ_DEPTH         = 4,
  parameter int NUM_WINDOWS        = 2,           // host windows per tenant
  parameter int MAX_XFER_BYTES     = 4096,
  parameter int TLM_DEPTH          = 16,
  // ---- ControlCore
  parameter int RV32M              = 1,
  parameter int SRAM_PARITY        = 1,
  parameter int CC_SRAM_BACKEND    = `SRAM_BACKEND_GENERIC,
  parameter int DPU_SRAM_BACKEND   = `SRAM_BACKEND_GENERIC
) (
  // ---------------------------------------------------------------- clock, reset, RAS
  input  wire logic        clk,
  input  wire logic        rst_ni,
  input  wire logic        test_mode,
  input  wire logic [1:0]  boot_mode_i,
  input  wire logic        host_rst_req_i,
  input  wire logic        ext_warn_i,
  input  wire logic        ext_fatal_i,
  output logic             ras_fatal_o,
  // ---------------------------------------------------------------- host management port (ControlCore host access port)
  input  wire logic        hs_req_valid,
  output logic             hs_req_ready,
  input  wire logic        hs_req_write,
  input  wire logic [31:0] hs_req_addr,
  input  wire logic [31:0] hs_req_wdata,
  input  wire logic [3:0]  hs_req_wstrb,
  output logic             hs_rsp_valid,
  input  wire logic        hs_rsp_ready,
  output logic [31:0]      hs_rsp_rdata,
  output logic             hs_rsp_error,
  output logic             host_irq_o,
  output logic             host_ready_o,
  output logic             cmdproc_ready_o,
  // ---------------------------------------------------------------- VirtualIO interface: command submission / completion
  input  wire logic        vio_sub_valid,
  output logic             vio_sub_ready,
  input  wire logic [3:0]  vio_sub_q,
  input  wire logic [silicaflux_cloud_pkg::CMD_W-1:0] vio_sub_cmd,
  output logic [NUM_NETWORK_QUEUES+NUM_COMPUTE_QUEUES-1:0] vio_cpl_valid,
  input  wire logic [NUM_NETWORK_QUEUES+NUM_COMPUTE_QUEUES-1:0] vio_cpl_ready,
  output logic [(NUM_NETWORK_QUEUES+NUM_COMPUTE_QUEUES)*silicaflux_cloud_pkg::CPL_W-1:0] vio_cpl_data,
  // ---------------------------------------------------------------- CloudDMA host memory port (SFB2 master)
  output logic                   hm_req_valid,
  input  wire logic              hm_req_ready,
  output logic                   hm_req_write,
  output logic [ADDRESS_WIDTH-1:0] hm_req_addr,
  output logic [DATA_WIDTH-1:0]  hm_req_wdata,
  output logic [DATA_WIDTH/8-1:0] hm_req_wstrb,
  input  wire logic              hm_rsp_valid,
  output logic                   hm_rsp_ready,
  input  wire logic [DATA_WIDTH-1:0] hm_rsp_rdata,
  input  wire logic              hm_rsp_error,
  // ---------------------------------------------------------------- CloudTelemetry event port
  output logic                   tlm_valid,
  input  wire logic              tlm_ready,
  output logic [silicaflux_cloud_pkg::TLM_W-1:0] tlm_data,
  // ---------------------------------------------------------------- diagnostics
  output logic             diag_valid_o,
  output logic [7:0]       diag_char_o,
  output logic             test_done_o,
  output logic             test_fail_o,
  output logic [15:0]      test_code_o,
  output logic             cpu_sleep_o,
  output logic             dpu_busy_o,
  output logic             dpu_irq_event_o,
  output logic             dpu_irq_fault_o
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */

  localparam int NNQ = NUM_NETWORK_QUEUES;
  localparam int NCQ = NUM_COMPUTE_QUEUES;
  localparam int NQH = NNQ + NCQ;                // host queues
  localparam int NQT = NQH + 1;                  // + management queue
  localparam int NT  = NUM_TENANTS;
  localparam int NS  = NUM_DMA_CHANNELS;
  localparam int NW  = NUM_WINDOWS;
  localparam int DW  = DATA_WIDTH;
  localparam int AW  = ADDRESS_WIDTH;
  localparam int DWB = DW / 8;
  localparam int CMDW = silicaflux_cloud_pkg::CMD_W;
  localparam int CPLW = silicaflux_cloud_pkg::CPL_W;
  localparam int TXNW = silicaflux_cloud_pkg::TXN_W;
  localparam int BANK_BYTES = SRAM_CAPACITY / NUM_SRAM_BANKS;

  // ------------------------------------------------------------ elaboration-time configuration checks
  generate
    if (ENABLE_TENSOR != 0) begin : g_err_ENABLE_TENSOR_blocked_InferenceScheduler_not_integrated_or_verified
      `SRAM_CFG_FATAL("ENABLE_TENSOR must be 0: no verified InferenceScheduler/TensorCore integration exists in Project 61")
    end
    if (ENABLE_CRYPTO != 0) begin : g_err_ENABLE_CRYPTO_blocked_CryptoCore_does_not_exist
      `SRAM_CFG_FATAL("ENABLE_CRYPTO must be 0: no CryptoCore exists; SecureStore AES/XTS is not integrated or verified here")
    end
    if (ENABLE_STORAGE != 0) begin : g_err_ENABLE_STORAGE_blocked_StorageFabric_does_not_exist
      `SRAM_CFG_FATAL("ENABLE_STORAGE must be 0: no StorageFabric exists; StorageCore is not integrated or verified here")
    end
    if (NNQ < 1 || NCQ < 0 || NQH > silicaflux_cloud_pkg::MAX_HOST_QUEUES) begin : g_err_queue_counts
      `SRAM_CFG_FATAL("need 1 <= NUM_NETWORK_QUEUES and NUM_NETWORK_QUEUES + NUM_COMPUTE_QUEUES <= 15")
    end
    if (NT < 1 || NT > silicaflux_cloud_pkg::MAX_TENANTS) begin : g_err_tenant_count
      `SRAM_CFG_FATAL("NUM_TENANTS must be 1..16")
    end
    if (NS < 1 || NS > 8) begin : g_err_dma_channels
      `SRAM_CFG_FATAL("NUM_DMA_CHANNELS must be 1..8")
    end
    if (!(DW == 32 || DW == 64 || DW == 128)) begin : g_err_data_width
      `SRAM_CFG_FATAL("DATA_WIDTH must be 32, 64 or 128")
    end
    if (AW < 32 || AW > 64) begin : g_err_address_width
      `SRAM_CFG_FATAL("ADDRESS_WIDTH must be 32..64")
    end
    if (NW < 1 || NW > silicaflux_cloud_pkg::MAX_WINDOWS) begin : g_err_windows
      `SRAM_CFG_FATAL("NUM_WINDOWS must be 1..8")
    end
    if (NUM_SRAM_BANKS < 1 || (SRAM_CAPACITY % NUM_SRAM_BANKS) != 0 || (BANK_BYTES & (BANK_BYTES - 1)) != 0 ||
        (BANK_BYTES % DWB) != 0 || (SRAM_CAPACITY % silicaflux_cloud_pkg::SRAM_PAGE_BYTES) != 0) begin : g_err_sram_geometry
      `SRAM_CFG_FATAL("SRAM_CAPACITY / NUM_SRAM_BANKS must be a power of two, a multiple of the beat size, and SRAM_CAPACITY a multiple of 256 bytes")
    end
    if (MAX_XFER_BYTES < DWB || MAX_XFER_BYTES > 65536) begin : g_err_max_xfer
      `SRAM_CFG_FATAL("MAX_XFER_BYTES must be between one beat and 65536")
    end
    if (QUEUE_DEPTH < 1 || CPLQ_DEPTH < 1) begin : g_err_queue_depth
      `SRAM_CFG_FATAL("QUEUE_DEPTH and CPLQ_DEPTH must be >= 1")
    end
  endgenerate

  // ============================================================ ControlCore
  logic        acc_rb_sel, acc_rb_we, acc_rb_err, acc_rst_n, acc_clk;
  logic [15:0] acc_rb_addr;
  logic [31:0] acc_rb_wdata, acc_rb_rdata;
  logic        x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [31:0] x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [3:0]  x_req_wstrb;
  logic        irq_event, irq_fault, dpu_warn, dpu_fatal, dpu_busy;

  silicaflux_control_core #(.RV32M(RV32M), .SRAM_PARITY(SRAM_PARITY), .SRAM_BACKEND(CC_SRAM_BACKEND)) u_cc (
    .clk, .rst_ni, .test_mode, .boot_mode_i, .host_rst_req_i,
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o, .host_ready_o, .cmdproc_ready_o, .ras_fatal_o,
    .acc_rb_sel, .acc_rb_we, .acc_rb_addr, .acc_rb_wdata, .acc_rb_rdata, .acc_rb_err,
    .ext_req_valid(x_req_valid), .ext_req_ready(x_req_ready), .ext_req_write(x_req_write), .ext_req_addr(x_req_addr),
    .ext_req_wdata(x_req_wdata), .ext_req_wstrb(x_req_wstrb),
    .ext_rsp_valid(x_rsp_valid), .ext_rsp_ready(x_rsp_ready), .ext_rsp_rdata(x_rsp_rdata), .ext_rsp_error(x_rsp_error),
    .acc_clk_o(acc_clk), .acc_rst_no(acc_rst_n),
    // The ControlCore is vendored unmodified.  Its two accelerator interrupt inputs carry the DPU interrupts
    // (INTC source 5 = DPU_EVENT, source 4 = DPU_FAULT); DPU faults reach its RAS block through ext_warn/ext_fatal.
    .acc_vec_irq_i(irq_event), .acc_tsu_irq_i(irq_fault), .acc_vec_busy_i(dpu_busy), .acc_tsu_busy_i(1'b0),
    .acc_tsu_halted_i(1'b0),
    .ext_warn_i(ext_warn_i || dpu_warn), .ext_fatal_i(ext_fatal_i || dpu_fatal),
    .diag_valid_o, .diag_char_o, .test_done_o, .test_fail_o, .test_code_o, .cpu_sleep_o
  );

  // ============================================================ clock / reset of the DPU
  wire dclk   = acc_clk;
  wire drst_n = acc_rst_n;                     // persistent domain
  logic dp_rst_n_cp, dp_resetting;
  wire  dp_rst_n = drst_n && dp_rst_n_cp;      // data-plane domain

  // ============================================================ register pages 8..15 -> regions 0..7
  /* verilator lint_off UNUSEDSIGNAL */          // acc_rb_addr[15] is the constant page-forwarding flag
  wire [15:0] acc_rb_addr_u = acc_rb_addr;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [2:0]  region = acc_rb_addr[14:12];
  wire [11:0] rb_a   = acc_rb_addr[11:0];
  logic [7:0] rb_sel;
  always_comb begin
    rb_sel = '0;
    if (acc_rb_sel) rb_sel[region] = 1'b1;
  end
  logic [31:0] rb0_rdata, rb1_rdata, rb2_rdata, rb3_rdata, rb4_rdata, rb5_rdata, rb6_rdata, rb7_rdata;
  logic        rb0_err, rb1_err, rb2_err, rb3_err, rb4_err, rb5_err, rb6_err, rb7_err;
  wire  [8*32-1:0] rb_rd = {rb7_rdata, rb6_rdata, rb5_rdata, rb4_rdata, rb3_rdata, rb2_rdata, rb1_rdata, rb0_rdata};
  wire  [7:0]      rb_er = {rb7_err, rb6_err, rb5_err, rb4_err, rb3_err, rb2_err, rb1_err, rb0_err};
  always_comb begin
    acc_rb_rdata = rb_rd[region*32 +: 32];
    acc_rb_err   = rb_er[region];
  end

  // ============================================================ tenant contexts
  logic [NT*3-1:0]      t_state;
  logic [NT-1:0]        t_cfg_ok;
  logic [NT*32-1:0]     t_part_base, t_part_size;
  logic [NT*NW*64-1:0]  t_win_base;
  logic [NT*NW*32-1:0]  t_win_size;
  logic [NT*NW-1:0]     t_win_valid;
  logic [NT*NW*2-1:0]   t_win_perm;
  logic [NT*8-1:0]      t_inflight;
  logic                 viol_evt;
  logic [3:0]           viol_tenant;
  logic                 sc_req_valid, sc_req_ready, sc_req_write, sc_rsp_valid, sc_rsp_ready, sc_rsp_error;
  logic [31:0]          sc_req_addr;
  logic [DW-1:0]        sc_req_wdata, sc_rsp_rdata;
  logic [DWB-1:0]       sc_req_wstrb;
  logic                 st_ev_valid;
  logic [3:0]           st_ev_tenant;
  logic [2:0]           st_ev_new;
  logic                 scrub_active;
  logic [3:0]           scrub_tenant;
  logic [15:0]          scrub_beats;

  sfd_tenant_ctx #(.NT(NT), .NW(NW), .SRAM_BYTES(SRAM_CAPACITY), .DW(DW), .AW(AW)) u_tenant (
    .clk(dclk), .rst_n(drst_n),
    .rb_sel(rb_sel[1]), .rb_we(acc_rb_we), .rb_addr(rb_a), .rb_wdata(acc_rb_wdata), .rb_rdata(rb1_rdata), .rb_err(rb1_err),
    .t_state, .t_cfg_ok, .t_part_base, .t_part_size, .t_win_base, .t_win_size, .t_win_valid, .t_win_perm,
    .t_inflight, .viol_evt, .viol_tenant,
    .sc_req_valid, .sc_req_ready, .sc_req_write, .sc_req_addr, .sc_req_wdata, .sc_req_wstrb,
    .sc_rsp_valid, .sc_rsp_ready, .sc_rsp_rdata, .sc_rsp_error,
    .dp_resetting,
    .ev_state_valid(st_ev_valid), .ev_state_tenant(st_ev_tenant), .ev_state_new(st_ev_new),
    .scrub_active, .scrub_tenant, .scrub_beats
  );

  // ============================================================ queues and command processor
  logic [NQT-1:0]       h_valid, h_pop, h_credit, q_compute, ev_sub;
  logic [NQT*CMDW-1:0]  h_cmd;
  logic [NQT*4-1:0]     q_tenant;
  logic                 c_push;
  logic [3:0]           c_push_q;
  logic [CPLW-1:0]      c_push_data;
  logic [7:0]           q_total;
  logic                 mgmt_cq_nonempty, ev_bad_q, ev_cq_overflow;

  sfd_cmdq #(.NQH(NQH), .NNQ(NNQ), .QD(QUEUE_DEPTH), .CD(CPLQ_DEPTH), .NT(NT)) u_cmdq (
    .clk(dclk), .rst_n(drst_n),
    .rb2_sel(rb_sel[2]), .rb3_sel(rb_sel[3]), .rb_we(acc_rb_we), .rb_addr(rb_a), .rb_wdata(acc_rb_wdata),
    .rb2_rdata, .rb2_err, .rb3_rdata, .rb3_err,
    .sub_valid(vio_sub_valid), .sub_ready(vio_sub_ready), .sub_q(vio_sub_q), .sub_cmd(vio_sub_cmd),
    .cpl_valid(vio_cpl_valid), .cpl_ready(vio_cpl_ready), .cpl_data(vio_cpl_data),
    .h_valid, .h_cmd, .h_pop, .h_credit, .q_tenant, .q_compute,
    .c_push, .c_push_q, .c_push_data,
    .q_total, .mgmt_cq_nonempty, .ev_sub, .ev_bad_q, .ev_cq_overflow
  );

  logic          ctl_en, dp_reset_req, cp_halted, cp_busy;
  logic [31:0]   job_timeout, time_cnt;
  logic [7:0]    cp_inflight;
  logic [NS-1:0] slot_start, slot_busy, slot_done, slot_ack, slot_commit, slot_zombie;
  logic [NS*TXNW-1:0] slot_txn;
  logic [NS*8-1:0]    slot_err;
  logic [NS*32-1:0]   slot_bytes, slot_crc_in, slot_crc_out;
  logic [NS*16-1:0]   slot_csum;
  logic [NS*64-1:0]   slot_faddr;
  logic [NS*4-1:0]    slot_fsm, slot_ten;
  logic [silicaflux_cloud_pkg::FLT_NUM-1:0] flt_set;
  logic [3:0]    flt_tenant;
  logic [7:0]    flt_err;
  logic [63:0]   flt_addr;
  logic          flt_addr_valid;
  logic          ev_retire, ev_blocked, ev_stall, ev_dp_reset;
  logic [3:0]    ev_ten, ev_queue, dbg_cp_state, dbg_qsel;
  logic [7:0]    ev_err, ev_status;
  logic [31:0]   ev_bytes;

  sfd_cmdproc #(.NQH(NQH), .NS(NS), .NT(NT), .NW(NW), .DW(DW), .MAX_XFER(MAX_XFER_BYTES)) u_cp (
    .clk(dclk), .rst_n(drst_n),
    .ctl_en, .dp_reset_req, .job_timeout, .time_cnt,
    .halted(cp_halted), .dp_rst_n_o(dp_rst_n_cp), .dp_resetting, .busy(cp_busy), .inflight_total(cp_inflight),
    .h_valid, .h_cmd, .h_pop, .h_credit, .q_tenant, .q_compute,
    .c_push, .c_push_q, .c_push_data,
    .t_state, .t_part_size, .t_win_base, .t_win_size, .t_win_valid, .t_win_perm, .t_inflight,
    .viol_evt, .viol_tenant,
    .slot_start, .slot_txn, .slot_busy, .slot_done, .slot_ack, .slot_err, .slot_bytes, .slot_commit,
    .slot_crc_in, .slot_crc_out, .slot_csum, .slot_faddr,
    .flt_set, .flt_tenant, .flt_err, .flt_addr, .flt_addr_valid,
    .ev_retire, .ev_ten, .ev_queue, .ev_err, .ev_status, .ev_bytes, .ev_blocked, .ev_stall, .ev_dp_reset,
    .dbg_state(dbg_cp_state), .dbg_qsel, .dbg_zombie(slot_zombie)
  );
  assign dpu_busy = cp_busy;

  // ============================================================ job slots (data plane)
  logic [NS-1:0]       sd_req_valid, sd_req_ready, sd_req_write, sd_rsp_valid, sd_rsp_ready, sd_rsp_error;
  logic [NS*32-1:0]    sd_req_addr;
  logic [NS*DW-1:0]    sd_req_wdata, sd_rsp_rdata;
  logic [NS*DWB-1:0]   sd_req_wstrb;
  logic [NS-1:0]       sh_req_valid, sh_req_ready, sh_req_write, sh_rsp_valid, sh_rsp_ready, sh_rsp_error;
  logic [NS*AW-1:0]    sh_req_addr;
  logic [NS*DW-1:0]    sh_req_wdata, sh_rsp_rdata;
  logic [NS*DWB-1:0]   sh_req_wstrb;
  logic [NS-1:0]       pk_req, pk_ack, pk_res_valid, ev_h2d, ev_d2h, ev_trip;
  logic [NS*32-1:0]    pk_in, pk_out, pk_len, pk_param;
  logic [NS*8-1:0]     pk_op, ev_bbytes;
  logic [NS*4-1:0]     pk_ten;
  logic [7:0]          pk_res_err;
  logic [31:0]         pk_res_crc_in, pk_res_crc_out;
  logic [15:0]         pk_res_csum;

  genvar gs;
  generate
    for (gs = 0; gs < NS; gs++) begin : g_slot
      sfd_job_slot #(.DW(DW), .AW(AW), .NT(NT), .NW(NW)) u_slot (
        .clk(dclk), .rst_n(dp_rst_n),
        .start(slot_start[gs]), .start_txn(slot_txn[gs*TXNW +: TXNW]),
        .done_valid(slot_done[gs]), .done_ack(slot_ack[gs]), .done_err(slot_err[gs*8 +: 8]),
        .done_bytes(slot_bytes[gs*32 +: 32]), .done_commit(slot_commit[gs]),
        .done_crc_in(slot_crc_in[gs*32 +: 32]), .done_crc_out(slot_crc_out[gs*32 +: 32]), .done_csum(slot_csum[gs*16 +: 16]),
        .done_fault_addr(slot_faddr[gs*64 +: 64]), .busy(slot_busy[gs]), .fsm_o(slot_fsm[gs*4 +: 4]), .tenant_o(slot_ten[gs*4 +: 4]),
        .t_cfg_ok, .t_part_base, .t_part_size, .t_win_base, .t_win_size, .t_win_valid, .t_win_perm,
        .hm_req_valid(sh_req_valid[gs]), .hm_req_ready(sh_req_ready[gs]), .hm_req_write(sh_req_write[gs]),
        .hm_req_addr(sh_req_addr[gs*AW +: AW]), .hm_req_wdata(sh_req_wdata[gs*DW +: DW]), .hm_req_wstrb(sh_req_wstrb[gs*DWB +: DWB]),
        .hm_rsp_valid(sh_rsp_valid[gs]), .hm_rsp_ready(sh_rsp_ready[gs]), .hm_rsp_rdata(sh_rsp_rdata[gs*DW +: DW]),
        .hm_rsp_error(sh_rsp_error[gs]),
        .sm_req_valid(sd_req_valid[gs]), .sm_req_ready(sd_req_ready[gs]), .sm_req_write(sd_req_write[gs]),
        .sm_req_addr(sd_req_addr[gs*32 +: 32]), .sm_req_wdata(sd_req_wdata[gs*DW +: DW]), .sm_req_wstrb(sd_req_wstrb[gs*DWB +: DWB]),
        .sm_rsp_valid(sd_rsp_valid[gs]), .sm_rsp_ready(sd_rsp_ready[gs]), .sm_rsp_rdata(sd_rsp_rdata[gs*DW +: DW]),
        .sm_rsp_error(sd_rsp_error[gs]),
        .pkt_req(pk_req[gs]), .pkt_in(pk_in[gs*32 +: 32]), .pkt_out(pk_out[gs*32 +: 32]), .pkt_len(pk_len[gs*32 +: 32]),
        .pkt_op(pk_op[gs*8 +: 8]), .pkt_param(pk_param[gs*32 +: 32]), .pkt_tenant(pk_ten[gs*4 +: 4]),
        .pkt_ack(pk_ack[gs]), .pkt_res_valid(pk_res_valid[gs]), .pkt_res_err(pk_res_err), .pkt_res_crc_in(pk_res_crc_in), .pkt_res_crc_out(pk_res_crc_out),
        .pkt_res_csum(pk_res_csum),
        .ev_h2d_beat(ev_h2d[gs]), .ev_d2h_beat(ev_d2h[gs]), .ev_beat_bytes(ev_bbytes[gs*8 +: 8]), .ev_guard_trip(ev_trip[gs])
      );
    end
  endgenerate

  // PacketCore test adapter (shared) behind its own guard
  logic                pm_req_valid, pm_req_ready, pm_req_write, pm_rsp_valid, pm_rsp_ready, pm_rsp_error;
  logic [31:0]         pm_req_addr;
  logic [DW-1:0]       pm_req_wdata, pm_rsp_rdata;
  logic [DWB-1:0]      pm_req_wstrb;
  logic                pkt_busy_unused, ev_pkt_job, ev_pkt_trip_unused;
  sfd_pkt_hub #(.DW(DW), .NS(NS), .NT(NT)) u_pkt (
    .clk(dclk), .rst_n(dp_rst_n),
    .pkt_req(pk_req), .pkt_in(pk_in), .pkt_out(pk_out), .pkt_len(pk_len), .pkt_op(pk_op), .pkt_param(pk_param),
    .pkt_tenant(pk_ten), .pkt_ack(pk_ack), .pkt_res_valid(pk_res_valid), .pkt_res_err(pk_res_err),
    .pkt_res_crc_in(pk_res_crc_in), .pkt_res_crc_out(pk_res_crc_out), .pkt_res_csum(pk_res_csum),
    .t_cfg_ok, .t_part_base, .t_part_size,
    .sm_req_valid(pm_req_valid), .sm_req_ready(pm_req_ready), .sm_req_write(pm_req_write), .sm_req_addr(pm_req_addr),
    .sm_req_wdata(pm_req_wdata), .sm_req_wstrb(pm_req_wstrb),
    .sm_rsp_valid(pm_rsp_valid), .sm_rsp_ready(pm_rsp_ready), .sm_rsp_rdata(pm_rsp_rdata), .sm_rsp_error(pm_rsp_error),
    .busy(pkt_busy_unused), .ev_job(ev_pkt_job), .ev_guard_trip(ev_pkt_trip_unused)
  );

  // ============================================================ DataFabric
  logic [NS+2:0] ev_arb_loss;
  logic          ev_stall_fabric, ev_stall_host, hm_out, hm_orphan;
  sfd_fabric #(.DW(DW), .AW(AW), .NCH(NS), .SRAM_BYTES(SRAM_CAPACITY), .NB(NUM_SRAM_BANKS),
               .SRAM_BACKEND(DPU_SRAM_BACKEND), .EXT_BASE(CC_EXT_BASE)) u_fab (
    .clk(dclk), .rst_n(drst_n), .dp_rst_n, .dp_resetting,
    .e_req_valid(x_req_valid), .e_req_ready(x_req_ready), .e_req_write(x_req_write), .e_req_addr(x_req_addr),
    .e_req_wdata(x_req_wdata), .e_req_wstrb(x_req_wstrb),
    .e_rsp_valid(x_rsp_valid), .e_rsp_ready(x_rsp_ready), .e_rsp_rdata(x_rsp_rdata), .e_rsp_error(x_rsp_error),
    .d_req_valid(sd_req_valid), .d_req_ready(sd_req_ready), .d_req_write(sd_req_write), .d_req_addr(sd_req_addr),
    .d_req_wdata(sd_req_wdata), .d_req_wstrb(sd_req_wstrb),
    .d_rsp_valid(sd_rsp_valid), .d_rsp_ready(sd_rsp_ready), .d_rsp_rdata(sd_rsp_rdata), .d_rsp_error(sd_rsp_error),
    .p_req_valid(pm_req_valid), .p_req_ready(pm_req_ready), .p_req_write(pm_req_write), .p_req_addr(pm_req_addr),
    .p_req_wdata(pm_req_wdata), .p_req_wstrb(pm_req_wstrb),
    .p_rsp_valid(pm_rsp_valid), .p_rsp_ready(pm_rsp_ready), .p_rsp_rdata(pm_rsp_rdata), .p_rsp_error(pm_rsp_error),
    .c_req_valid(sc_req_valid), .c_req_ready(sc_req_ready), .c_req_write(sc_req_write), .c_req_addr(sc_req_addr),
    .c_req_wdata(sc_req_wdata), .c_req_wstrb(sc_req_wstrb),
    .c_rsp_valid(sc_rsp_valid), .c_rsp_ready(sc_rsp_ready), .c_rsp_rdata(sc_rsp_rdata), .c_rsp_error(sc_rsp_error),
    .h_req_valid(sh_req_valid), .h_req_ready(sh_req_ready), .h_req_write(sh_req_write), .h_req_addr(sh_req_addr),
    .h_req_wdata(sh_req_wdata), .h_req_wstrb(sh_req_wstrb),
    .h_rsp_valid(sh_rsp_valid), .h_rsp_ready(sh_rsp_ready), .h_rsp_rdata(sh_rsp_rdata), .h_rsp_error(sh_rsp_error),
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .ev_arb_loss, .ev_stall_fabric, .ev_stall_host, .hm_out_o(hm_out), .hm_orphan_o(hm_orphan)
  );

  // ============================================================ counters, telemetry, global registers
  logic tlm_drop;
  sfd_perf #(.NT(NT), .NS(NS), .NQT(NQT), .NM(NS + 3)) u_perf (
    .clk(dclk), .rst_n(drst_n),
    .rb_sel(rb_sel[4]), .rb_we(acc_rb_we), .rb_addr(rb_a), .rb_wdata(acc_rb_wdata), .rb_rdata(rb4_rdata), .rb_err(rb4_err),
    .ev_sub, .ev_retire, .ev_ten, .ev_status, .ev_err, .ev_bytes,
    .ev_viol(viol_evt), .ev_host_err(flt_set[silicaflux_cloud_pkg::FLT_HOST_ERR]), .ev_timeout(flt_set[silicaflux_cloud_pkg::FLT_TIMEOUT]),
    .ev_busy(cp_inflight != 8'd0), .ev_stall_dispatch(ev_stall), .ev_stall_fabric, .ev_stall_host,
    .ev_arb_loss, .ev_h2d_beat(ev_h2d), .ev_d2h_beat(ev_d2h), .ev_beat_bytes(ev_bbytes),
    .slot_busy, .slot_ten
  );

  sfd_tlm #(.DEPTH(TLM_DEPTH)) u_tlm (
    .clk(dclk), .rst_n(drst_n),
    .rb_sel(rb_sel[5]), .rb_we(acc_rb_we), .rb_addr(rb_a), .rb_wdata(acc_rb_wdata), .rb_rdata(rb5_rdata), .rb_err(rb5_err),
    .time_cnt,
    .ev_retire, .ev_ten, .ev_queue, .ev_status, .ev_err,
    .st_valid(st_ev_valid), .st_tenant(st_ev_tenant), .st_new(st_ev_new), .ev_dp_reset,
    .tlm_valid, .tlm_ready, .tlm_data, .ev_drop(tlm_drop)
  );

  sfd_regs #(.NT(NT), .NNQ(NNQ), .NCQ(NCQ), .NCH(NS), .DW(DW), .AW(AW), .NW(NW), .SRAM_BYTES(SRAM_CAPACITY),
             .MAX_XFER(MAX_XFER_BYTES), .ENT(ENABLE_TENSOR), .ENC(ENABLE_CRYPTO), .ENS(ENABLE_STORAGE), .QD(QUEUE_DEPTH)) u_regs (
    .clk(dclk), .rst_n(drst_n),
    .rb0_sel(rb_sel[0]), .rb_we(acc_rb_we), .rb_addr(rb_a), .rb_wdata(acc_rb_wdata),
    .rb0_rdata, .rb0_err, .rb6_rdata, .rb6_err, .rb7_rdata, .rb7_err,
    .ctl_en, .dp_reset_req, .job_timeout, .time_cnt,
    .st_busy(cp_busy), .st_halted(cp_halted), .st_resetting(dp_resetting), .st_scrub(scrub_active),
    .st_inflight(cp_inflight), .st_queued(q_total), .mgmt_cq_nonempty,
    .flt_set, .flt_tlm_drop(tlm_drop), .flt_tenant, .flt_err, .flt_addr, .flt_addr_valid,
    .irq_event, .irq_fault, .ext_warn(dpu_warn), .ext_fatal(dpu_fatal),
    .ev_blocked, .ev_pkt_job,
    .dbg_slot_fsm(slot_fsm), .dbg_slot_busy(slot_busy), .dbg_zombie(slot_zombie), .dbg_slot_ten(slot_ten),
    .dbg_cp_state, .dbg_qsel, .hm_out, .hm_orphan, .scrub_ten(scrub_tenant), .scrub_act(scrub_active), .scrub_beats
  );

`ifdef SFD_ASSERT
  // simulation-only checkers (rtl/dpu/sfd_assertions.sv); never part of the synthesis file list
  sfd_assertions #(.NQH(NQH), .NS(NS), .NT(NT), .AW(AW), .DW(DW)) u_assert (
    .clk(dclk), .rst_n(drst_n), .dp_resetting, .ctl_en, .halted(cp_halted),
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb, .hm_rsp_valid,
    .vio_cpl_valid, .vio_cpl_ready, .vio_cpl_data, .tlm_valid, .tlm_ready, .tlm_data,
    .c_push, .c_push_data, .ev_cq_overflow, .slot_start, .slot_busy, .slot_ten, .slot_zombie,
    .scrub_active, .scrub_tenant, .t_inflight
  );
`endif

  assign dpu_busy_o      = dpu_busy;
  assign dpu_irq_event_o = irq_event;
  assign dpu_irq_fault_o = irq_fault;

  wire unused_ok = &{1'b0, ev_bad_q, ev_cq_overflow, ev_trip, ev_pkt_trip_unused, pkt_busy_unused, rb_sel[7:6]};
endmodule

`default_nettype wire
