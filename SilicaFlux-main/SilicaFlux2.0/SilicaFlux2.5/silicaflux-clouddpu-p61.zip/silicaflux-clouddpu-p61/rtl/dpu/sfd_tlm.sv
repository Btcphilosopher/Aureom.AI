// =============================================================================
// CloudDPU :: sfd_tlm -- CloudTelemetry event exporter (register region 5)
//
// Turns DPU events into 80-bit records on a ready/valid port (`tlm_*`) for an external CloudTelemetry
// consumer (none exists in the repository; the port is the interface, a testbench model consumes it):
//   {timestamp[31:0], argument[31:0], event[7:0], queue[3:0], tenant[3:0]}        (silicaflux_cloud_pkg::TLM_*)
//   TLM_CMD_RETIRE    argument = {err, status}          TLM_VIOLATION   argument = error code (isolation violation)
//   TLM_TENANT_STATE  argument = new state              TLM_DP_RESET    data-plane reset completed
// A 16-entry FIFO absorbs bursts.  A record that finds the FIFO full is DROPPED and counted (DROPPED register,
// FAULT_STATUS.TLM_DROP): telemetry never back-pressures the data path.  Lower-priority events (tenant state,
// reset) wait in a one-deep holding register; retire events have priority.
// Persistent reset domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_tlm #(
  parameter int DEPTH = 16
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            rb_sel,
  input  wire logic            rb_we,
  input  wire logic [11:0]     rb_addr,
  /* verilator lint_off UNUSEDSIGNAL */          // only CTRL[0] is writable
  input  wire logic [31:0]     rb_wdata,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]          rb_rdata,
  output logic                 rb_err,
  input  wire logic [31:0]     time_cnt,
  // events
  input  wire logic            ev_retire,
  input  wire logic [3:0]      ev_ten,
  input  wire logic [3:0]      ev_queue,
  input  wire logic [7:0]      ev_status,
  input  wire logic [7:0]      ev_err,
  input  wire logic            st_valid,
  input  wire logic [3:0]      st_tenant,
  input  wire logic [2:0]      st_new,
  input  wire logic            ev_dp_reset,
  // export port
  output logic                 tlm_valid,
  input  wire logic            tlm_ready,
  output logic [silicaflux_cloud_pkg::TLM_W-1:0] tlm_data,
  output logic                 ev_drop
);
  localparam int TW = silicaflux_cloud_pkg::TLM_W;
  logic        en_q;
  logic        hs_v_q, hr_v_q;                     // holding registers: tenant state, reset
  logic [3:0]  hs_t_q;
  logic [2:0]  hs_n_q;
  logic [31:0] emitted_q, dropped_q, last0_q, last1_q, last2_q;

  // choose this cycle's event
  logic         c_v;
  logic [7:0]   c_ev;
  logic [3:0]   c_t, c_q;
  logic [31:0]  c_arg;
  logic         take_s, take_r;
  always_comb begin
    c_v = 1'b0;  c_ev = 8'd0;  c_t = 4'd0;  c_q = 4'd0;  c_arg = 32'd0;  take_s = 1'b0;  take_r = 1'b0;
    if (ev_retire) begin
      c_v = 1'b1;  c_t = ev_ten;  c_q = ev_queue;
      if (silicaflux_cloud_pkg::err_is_violation(ev_err)) begin c_ev = silicaflux_cloud_pkg::TLM_VIOLATION;  c_arg = {24'd0, ev_err}; end
      else begin c_ev = silicaflux_cloud_pkg::TLM_CMD_RETIRE; c_arg = {16'd0, ev_err, ev_status}; end
    end else if (hs_v_q) begin
      c_v = 1'b1;  c_ev = silicaflux_cloud_pkg::TLM_TENANT_STATE;  c_t = hs_t_q;  c_arg = {29'd0, hs_n_q};  take_s = 1'b1;
    end else if (hr_v_q) begin
      c_v = 1'b1;  c_ev = silicaflux_cloud_pkg::TLM_DP_RESET;  take_r = 1'b1;
    end
  end

  logic          f_in_ready;
  logic [4:0]    f_level;
  wire  [TW-1:0] c_word = {time_cnt, c_arg, c_ev, c_q, c_t};
  wire  push  = c_v && en_q && f_in_ready;
  assign ev_drop = c_v && en_q && !f_in_ready;

  sfd_fifo #(.WIDTH(TW), .DEPTH(DEPTH)) u_f (
    .clk, .rst_n, .flush(1'b0),
    .in_valid(c_v && en_q), .in_ready(f_in_ready), .in_data(c_word),
    .out_valid(tlm_valid), .out_ready(tlm_ready), .out_data(tlm_data), .level(f_level)
  );

  wire wr = rb_sel && rb_we;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q <= 1'b1;  hs_v_q <= 1'b0;  hr_v_q <= 1'b0;  hs_t_q <= '0;  hs_n_q <= '0;
      emitted_q <= '0;  dropped_q <= '0;  last0_q <= '0;  last1_q <= '0;  last2_q <= '0;
    end else begin
      if (wr && rb_addr == 12'h000) en_q <= rb_wdata[0];
      // holding registers: set by the event, cleared when taken into the FIFO (or when events are disabled)
      if (st_valid) begin hs_v_q <= 1'b1; hs_t_q <= st_tenant; hs_n_q <= st_new; end
      if (ev_dp_reset) hr_v_q <= 1'b1;
      if (take_s && (!en_q || f_in_ready)) hs_v_q <= st_valid;
      if (take_r && (!en_q || f_in_ready)) hr_v_q <= ev_dp_reset;
      if (push) begin
        emitted_q <= emitted_q + 32'd1;
        last0_q   <= time_cnt;
        last1_q   <= c_arg;
        last2_q   <= {16'd0, c_q, c_t, c_ev};
      end
      if (ev_drop && !take_s && !take_r) dropped_q <= dropped_q + 32'd1;
    end
  end

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      12'h000: rb_rdata = {31'd0, en_q};
      12'h004: begin rb_rdata = {27'd0, f_level}; rb_err = rb_we; end
      12'h008: begin rb_rdata = dropped_q;        rb_err = rb_we; end
      12'h00C: begin rb_rdata = emitted_q;        rb_err = rb_we; end
      12'h010: begin rb_rdata = last0_q;          rb_err = rb_we; end
      12'h014: begin rb_rdata = last1_q;          rb_err = rb_we; end
      12'h018: begin rb_rdata = last2_q;          rb_err = rb_we; end
      default: rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
