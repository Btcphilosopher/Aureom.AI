// =============================================================================
// CloudDPU :: sfd_mgmt_adapter -- ControlCore EXT window (32-bit SFB2) -> local SRAM fabric (DW-bit SFB2)
//
// The management plane (ControlCore CPU / system DMA) sees the local SRAM at EXT_BASE + offset, 32 bits at a
// time.  This adapter range-checks the window, aligns the access to a DW-bit beat (data replicated, byte
// strobes steered to the lane, read lane selected from the response) and presents it as a master of the SRAM
// crossbar.  Out-of-window accesses are answered with rsp_error (the ControlCore turns them into a bus fault).
// The management master is TRUSTED (it may read and write any SRAM address, e.g. to inspect or load buffers);
// it is not a tenant and is reachable only through the ControlCore.
// A data-plane reset while a request is in flight turns it into an error response, so the ControlCore never hangs.
// Persistent reset domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_mgmt_adapter #(
  parameter int          DW         = 32,
  parameter int          SRAM_BYTES = 65536,
  parameter logic [31:0] EXT_BASE   = 32'h2000_0000
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            dp_resetting,
  // ControlCore ext port (slave side of this block)
  input  wire logic            e_req_valid,
  output logic                 e_req_ready,
  input  wire logic            e_req_write,
  input  wire logic [31:0]     e_req_addr,
  input  wire logic [31:0]     e_req_wdata,
  input  wire logic [3:0]      e_req_wstrb,
  output logic                 e_rsp_valid,
  input  wire logic            e_rsp_ready,
  output logic [31:0]          e_rsp_rdata,
  output logic                 e_rsp_error,
  // crossbar master port
  output logic                 m_req_valid,
  input  wire logic            m_req_ready,
  output logic                 m_req_write,
  output logic [31:0]          m_req_addr,
  output logic [DW-1:0]        m_req_wdata,
  output logic [DW/8-1:0]      m_req_wstrb,
  input  wire logic            m_rsp_valid,
  output logic                 m_rsp_ready,
  input  wire logic [DW-1:0]   m_rsp_rdata,
  input  wire logic            m_rsp_error
);
  localparam int DWB = DW / 8;
  localparam int NL  = DW / 32;                          // 32-bit lanes per beat
  localparam int LW  = (NL > 1) ? $clog2(NL) : 1;

  logic              pend_q, err_q;
  logic [LW-1:0]     lane_q;
  wire  [31:0]       off    = e_req_addr - EXT_BASE;
  wire               inwin  = (e_req_addr >= EXT_BASE) && (off < SRAM_BYTES[31:0]);
  wire  [LW-1:0]     lane   = (NL > 1) ? off[LW+1:2] : '0;

  assign m_req_valid = e_req_valid && inwin && !pend_q && !err_q && !dp_resetting;
  assign m_req_write = e_req_write;
  assign m_req_addr  = off & ~(DWB[31:0] - 32'd1);
  always_comb begin
    m_req_wdata = {NL{e_req_wdata}};
    m_req_wstrb = '0;
    for (int l = 0; l < NL; l++) if (lane == l[LW-1:0]) m_req_wstrb[l*4 +: 4] = e_req_wstrb;
  end
  assign e_req_ready = !pend_q && !err_q && !dp_resetting && (inwin ? m_req_ready : 1'b1);

  wire swallow = e_req_valid && !inwin && !pend_q && !err_q && !dp_resetting;
  assign e_rsp_valid = err_q || (pend_q && m_rsp_valid);
  assign e_rsp_error = err_q || (pend_q && m_rsp_error);
  always_comb begin
    e_rsp_rdata = 32'd0;
    for (int l = 0; l < NL; l++) if (lane_q == l[LW-1:0] && pend_q && !err_q) e_rsp_rdata = m_rsp_rdata[l*32 +: 32];
  end
  assign m_rsp_ready = pend_q && !err_q && e_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pend_q <= 1'b0;  err_q <= 1'b0;  lane_q <= '0;
    end else begin
      if (m_req_valid && m_req_ready) begin pend_q <= 1'b1; lane_q <= lane; end
      if (swallow)                    err_q <= 1'b1;
      if (pend_q && dp_resetting)     begin pend_q <= 1'b0; err_q <= 1'b1; end      // the fabric dropped it
      if (pend_q && m_rsp_valid && e_rsp_ready) pend_q <= 1'b0;
      if (err_q && e_rsp_ready)       err_q <= 1'b0;
    end
  end
endmodule

`default_nettype wire
