// =============================================================================
// CloudDPU :: sfd_fabric -- the DPU DataFabric: local SRAM banks, SRAM crossbar, host-port multiplexer
//
//   SRAM crossbar (DataFabric sfb_crossbar, reused unmodified, SFB2, round robin)
//     masters  0            management  (ControlCore EXT window via sfd_mgmt_adapter, trusted)
//              1..NCH       CloudDMA SRAM port of job slot 0..NCH-1      (guarded in the slot)
//              NCH+1        PacketCore SRAM port                          (guarded in the hub)
//              NCH+2        tenant scrubber                               (trusted)
//     slaves   NB banks of SRAM_BYTES/NB bytes each, sfb_sram_slave over the SRAM Wrapper Library (sram_sp)
//   Host-memory multiplexer: the CloudDMA host ports of the NCH slots share ONE host-memory port.  With NCH > 1
//   the DataFabric crossbar (NM = NCH, NS = 1) arbitrates; with NCH = 1 the slot is wired straight to the port.
//
// Reset domains: the crossbars and SRAM controllers are in the DATA-PLANE domain (dp_rst_n: reset by DP_RESET);
// the management adapter and the host port wrapper are persistent.  SRAM CONTENTS are never cleared by a reset:
// clearing is the tenant scrubber's job and happens on assignment and teardown.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sfd_fabric #(
  parameter int          DW           = 32,
  parameter int          AW           = 32,
  parameter int          NCH          = 1,
  parameter int          SRAM_BYTES   = 65536,
  parameter int          NB           = 1,
  parameter int          SRAM_BACKEND = `SRAM_BACKEND_GENERIC,
  parameter logic [31:0] EXT_BASE     = 32'h2000_0000
) (
  input  wire logic            clk,
  input  wire logic            rst_n,        // persistent
  input  wire logic            dp_rst_n,     // data plane (already ANDed with rst_n by the parent)
  input  wire logic            dp_resetting,
  // management (ControlCore EXT port)
  input  wire logic            e_req_valid,
  output logic                 e_req_ready,
  input  wire logic            e_req_write,
  input  wire logic [31:0]     e_req_addr,
  input  wire logic [31:0]     e_req_wdata,
  input  wire logic [3:0]      e_req_wstrb,
  output logic                 e_rsp_valid,
  input  wire logic            e_rsp_ready,
  output logic [31:0]          e_rsp_rdata,
  output logic                 e_rsp_error,
  // CloudDMA SRAM ports (one per slot)
  input  wire logic [NCH-1:0]       d_req_valid,
  output logic [NCH-1:0]            d_req_ready,
  input  wire logic [NCH-1:0]       d_req_write,
  input  wire logic [NCH*32-1:0]    d_req_addr,
  input  wire logic [NCH*DW-1:0]    d_req_wdata,
  input  wire logic [NCH*DW/8-1:0]  d_req_wstrb,
  output logic [NCH-1:0]            d_rsp_valid,
  input  wire logic [NCH-1:0]       d_rsp_ready,
  output logic [NCH*DW-1:0]         d_rsp_rdata,
  output logic [NCH-1:0]            d_rsp_error,
  // PacketCore SRAM port
  input  wire logic            p_req_valid,
  output logic                 p_req_ready,
  input  wire logic            p_req_write,
  input  wire logic [31:0]     p_req_addr,
  input  wire logic [DW-1:0]   p_req_wdata,
  input  wire logic [DW/8-1:0] p_req_wstrb,
  output logic                 p_rsp_valid,
  input  wire logic            p_rsp_ready,
  output logic [DW-1:0]        p_rsp_rdata,
  output logic                 p_rsp_error,
  // scrubber SRAM port
  input  wire logic            c_req_valid,
  output logic                 c_req_ready,
  input  wire logic            c_req_write,
  input  wire logic [31:0]     c_req_addr,
  input  wire logic [DW-1:0]   c_req_wdata,
  input  wire logic [DW/8-1:0] c_req_wstrb,
  output logic                 c_rsp_valid,
  input  wire logic            c_rsp_ready,
  output logic [DW-1:0]        c_rsp_rdata,
  output logic                 c_rsp_error,
  // host memory: slot ports in, one external port out
  input  wire logic [NCH-1:0]       h_req_valid,
  output logic [NCH-1:0]            h_req_ready,
  input  wire logic [NCH-1:0]       h_req_write,
  input  wire logic [NCH*AW-1:0]    h_req_addr,
  input  wire logic [NCH*DW-1:0]    h_req_wdata,
  input  wire logic [NCH*DW/8-1:0]  h_req_wstrb,
  output logic [NCH-1:0]            h_rsp_valid,
  input  wire logic [NCH-1:0]       h_rsp_ready,
  output logic [NCH*DW-1:0]         h_rsp_rdata,
  output logic [NCH-1:0]            h_rsp_error,
  output logic                 hm_req_valid,
  input  wire logic            hm_req_ready,
  output logic                 hm_req_write,
  output logic [AW-1:0]        hm_req_addr,
  output logic [DW-1:0]        hm_req_wdata,
  output logic [DW/8-1:0]      hm_req_wstrb,
  input  wire logic            hm_rsp_valid,
  output logic                 hm_rsp_ready,
  input  wire logic [DW-1:0]   hm_rsp_rdata,
  input  wire logic            hm_rsp_error,
  // events / status
  output logic [NCH+2:0]       ev_arb_loss,       // per SRAM master: lost arbitration this cycle (memory conflict)
  output logic                 ev_stall_fabric,   // some SRAM master has a request waiting
  output logic                 ev_stall_host,     // host port: request waiting
  output logic                 hm_out_o,
  output logic                 hm_orphan_o
);
  localparam int NM         = NCH + 3;
  localparam int DWB        = DW / 8;
  localparam int BANK_BYTES = SRAM_BYTES / NB;
  localparam int BANK_WORDS = BANK_BYTES / DWB;

  function automatic logic [NB*32-1:0] f_base(input int unused);
    integer i;
    logic [NB*32-1:0] r;
    r = {(NB*32){1'b0}};
    for (i = 0; i < NB; i = i + 1) r[i*32 +: 32] = 32'(i * BANK_BYTES);
    f_base = r;
  endfunction
  function automatic logic [NB*32-1:0] f_mask(input int unused);
    integer i;
    logic [NB*32-1:0] r;
    r = {(NB*32){1'b0}};
    for (i = 0; i < NB; i = i + 1) r[i*32 +: 32] = ~(32'(BANK_BYTES) - 32'd1);
    f_mask = r;
  endfunction
  localparam logic [NB*32-1:0] SLV_BASE_V = f_base(0);
  localparam logic [NB*32-1:0] SLV_MASK_V = f_mask(0);

  // ------------------------------------------------------------ SRAM crossbar master vectors
  logic [NM-1:0]      xm_req_valid, xm_req_ready, xm_req_write, xm_rsp_valid, xm_rsp_ready, xm_rsp_error;
  logic [NM*32-1:0]   xm_req_addr;
  logic [NM*DW-1:0]   xm_req_wdata, xm_rsp_rdata;
  logic [NM*DWB-1:0]  xm_req_wstrb;

  // master 0: management
  sfd_mgmt_adapter #(.DW(DW), .SRAM_BYTES(SRAM_BYTES), .EXT_BASE(EXT_BASE)) u_mgmt (
    .clk, .rst_n, .dp_resetting,
    .e_req_valid, .e_req_ready, .e_req_write, .e_req_addr, .e_req_wdata, .e_req_wstrb,
    .e_rsp_valid, .e_rsp_ready, .e_rsp_rdata, .e_rsp_error,
    .m_req_valid(xm_req_valid[0]), .m_req_ready(xm_req_ready[0]), .m_req_write(xm_req_write[0]),
    .m_req_addr(xm_req_addr[0 +: 32]), .m_req_wdata(xm_req_wdata[0 +: DW]), .m_req_wstrb(xm_req_wstrb[0 +: DWB]),
    .m_rsp_valid(xm_rsp_valid[0]), .m_rsp_ready(xm_rsp_ready[0]), .m_rsp_rdata(xm_rsp_rdata[0 +: DW]),
    .m_rsp_error(xm_rsp_error[0])
  );
  // masters 1..NCH: CloudDMA
  genvar gi;
  generate
    for (gi = 0; gi < NCH; gi++) begin : g_dma
      assign xm_req_valid[1+gi]                = d_req_valid[gi];
      assign d_req_ready[gi]                   = xm_req_ready[1+gi];
      assign xm_req_write[1+gi]                = d_req_write[gi];
      assign xm_req_addr[(1+gi)*32 +: 32]      = d_req_addr[gi*32 +: 32];
      assign xm_req_wdata[(1+gi)*DW +: DW]     = d_req_wdata[gi*DW +: DW];
      assign xm_req_wstrb[(1+gi)*DWB +: DWB]   = d_req_wstrb[gi*DWB +: DWB];
      assign d_rsp_valid[gi]                   = xm_rsp_valid[1+gi];
      assign xm_rsp_ready[1+gi]                = d_rsp_ready[gi];
      assign d_rsp_rdata[gi*DW +: DW]          = xm_rsp_rdata[(1+gi)*DW +: DW];
      assign d_rsp_error[gi]                   = xm_rsp_error[1+gi];
    end
  endgenerate
  // master NCH+1: PacketCore, NCH+2: scrubber
  assign xm_req_valid[NCH+1]              = p_req_valid;
  assign p_req_ready                      = xm_req_ready[NCH+1];
  assign xm_req_write[NCH+1]              = p_req_write;
  assign xm_req_addr[(NCH+1)*32 +: 32]    = p_req_addr;
  assign xm_req_wdata[(NCH+1)*DW +: DW]   = p_req_wdata;
  assign xm_req_wstrb[(NCH+1)*DWB +: DWB] = p_req_wstrb;
  assign p_rsp_valid                      = xm_rsp_valid[NCH+1];
  assign xm_rsp_ready[NCH+1]              = p_rsp_ready;
  assign p_rsp_rdata                      = xm_rsp_rdata[(NCH+1)*DW +: DW];
  assign p_rsp_error                      = xm_rsp_error[NCH+1];

  assign xm_req_valid[NCH+2]              = c_req_valid;
  assign c_req_ready                      = xm_req_ready[NCH+2];
  assign xm_req_write[NCH+2]              = c_req_write;
  assign xm_req_addr[(NCH+2)*32 +: 32]    = c_req_addr;
  assign xm_req_wdata[(NCH+2)*DW +: DW]   = c_req_wdata;
  assign xm_req_wstrb[(NCH+2)*DWB +: DWB] = c_req_wstrb;
  assign c_rsp_valid                      = xm_rsp_valid[NCH+2];
  assign xm_rsp_ready[NCH+2]              = c_rsp_ready;
  assign c_rsp_rdata                      = xm_rsp_rdata[(NCH+2)*DW +: DW];
  assign c_rsp_error                      = xm_rsp_error[NCH+2];

  // ------------------------------------------------------------ crossbar and banks
  logic [NB-1:0]      xs_req_valid, xs_req_ready, xs_req_write, xs_rsp_valid, xs_rsp_ready, xs_rsp_error;
  logic [NB*32-1:0]   xs_req_addr;
  logic [NB*DW-1:0]   xs_req_wdata, xs_rsp_rdata;
  logic [NB*DWB-1:0]  xs_req_wstrb;
  logic [NM-1:0]      x_ev_acc_unused, x_ev_rsp_unused, x_ev_stall;
  logic               x_err_evt_unused, x_err_write_unused;
  logic [31:0]        x_err_addr_unused;
  logic [(NM > 1 ? $clog2(NM) : 1)-1:0] x_err_master_unused;

  sfb_crossbar #(
    .NM(NM), .NS(NB), .AW(32), .DW(DW), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE(SLV_BASE_V), .SLV_MASK(SLV_MASK_V), .MST_SLV_EN({(NM*NB){1'b1}})
  ) u_xbar (
    .clk, .rst_n(dp_rst_n),
    .m_req_valid(xm_req_valid), .m_req_ready(xm_req_ready), .m_req_write(xm_req_write), .m_req_addr(xm_req_addr),
    .m_req_wdata(xm_req_wdata), .m_req_wstrb(xm_req_wstrb),
    .m_rsp_valid(xm_rsp_valid), .m_rsp_ready(xm_rsp_ready), .m_rsp_rdata(xm_rsp_rdata), .m_rsp_error(xm_rsp_error),
    .s_req_valid(xs_req_valid), .s_req_ready(xs_req_ready), .s_req_write(xs_req_write), .s_req_addr(xs_req_addr),
    .s_req_wdata(xs_req_wdata), .s_req_wstrb(xs_req_wstrb),
    .s_rsp_valid(xs_rsp_valid), .s_rsp_ready(xs_rsp_ready), .s_rsp_rdata(xs_rsp_rdata), .s_rsp_error(xs_rsp_error),
    .err_evt(x_err_evt_unused), .err_addr(x_err_addr_unused), .err_master(x_err_master_unused), .err_write(x_err_write_unused),
    .ev_req_accept(x_ev_acc_unused), .ev_req_stall(x_ev_stall), .ev_arb_loss, .ev_rsp_stall(x_ev_rsp_unused)
  );
  assign ev_stall_fabric = |(xm_req_valid & ~xm_req_ready);

  genvar gb;
  generate
    for (gb = 0; gb < NB; gb++) begin : g_bank
      logic [DW-1:0] tst_rd_unused;
      sfb_sram_slave #(.DW(DW), .DEPTH(BANK_WORDS), .READ_LATENCY(1), .BACKEND(SRAM_BACKEND)) u_bank (
        .clk, .rst_n(dp_rst_n),
        .req_valid(xs_req_valid[gb]), .req_ready(xs_req_ready[gb]), .req_write(xs_req_write[gb]),
        .req_addr(xs_req_addr[gb*32 +: 32]), .req_wdata(xs_req_wdata[gb*DW +: DW]), .req_wstrb(xs_req_wstrb[gb*DWB +: DWB]),
        .rsp_valid(xs_rsp_valid[gb]), .rsp_ready(xs_rsp_ready[gb]), .rsp_rdata(xs_rsp_rdata[gb*DW +: DW]),
        .rsp_error(xs_rsp_error[gb]),
        .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rd_unused)
      );
    end
  endgenerate

  // ------------------------------------------------------------ host-memory multiplexer
  logic              mx_req_valid, mx_req_ready, mx_req_write, mx_rsp_valid, mx_rsp_ready, mx_rsp_error;
  logic [AW-1:0]     mx_req_addr;
  logic [DW-1:0]     mx_req_wdata, mx_rsp_rdata;
  logic [DWB-1:0]    mx_req_wstrb;
  generate
    if (NCH == 1) begin : g_direct
      assign mx_req_valid = h_req_valid[0];
      assign h_req_ready[0] = mx_req_ready;
      assign mx_req_write = h_req_write[0];
      assign mx_req_addr  = h_req_addr[0 +: AW];
      assign mx_req_wdata = h_req_wdata[0 +: DW];
      assign mx_req_wstrb = h_req_wstrb[0 +: DWB];
      assign h_rsp_valid[0] = mx_rsp_valid;
      assign mx_rsp_ready = h_rsp_ready[0];
      assign h_rsp_rdata[0 +: DW] = mx_rsp_rdata;
      assign h_rsp_error[0] = mx_rsp_error;
    end else begin : g_mux
      logic [NCH-1:0]  hx_err_unused_a, hx_err_unused_b, hx_err_unused_c, hx_err_unused_d;
      logic            hx_e_unused, hx_ew_unused;
      logic [AW-1:0]   hx_ea_unused;
      logic [$clog2(NCH)-1:0] hx_em_unused;
      sfb_crossbar #(
        .NM(NCH), .NS(1), .AW(AW), .DW(DW), .ARB_MODE(1), .CHECK_ALIGN(1),
        .SLV_BASE({AW{1'b0}}), .SLV_MASK({AW{1'b0}}), .MST_SLV_EN({NCH{1'b1}})
      ) u_hmux (
        .clk, .rst_n(dp_rst_n),
        .m_req_valid(h_req_valid), .m_req_ready(h_req_ready), .m_req_write(h_req_write), .m_req_addr(h_req_addr),
        .m_req_wdata(h_req_wdata), .m_req_wstrb(h_req_wstrb),
        .m_rsp_valid(h_rsp_valid), .m_rsp_ready(h_rsp_ready), .m_rsp_rdata(h_rsp_rdata), .m_rsp_error(h_rsp_error),
        .s_req_valid(mx_req_valid), .s_req_ready(mx_req_ready), .s_req_write(mx_req_write), .s_req_addr(mx_req_addr),
        .s_req_wdata(mx_req_wdata), .s_req_wstrb(mx_req_wstrb),
        .s_rsp_valid(mx_rsp_valid), .s_rsp_ready(mx_rsp_ready), .s_rsp_rdata(mx_rsp_rdata), .s_rsp_error(mx_rsp_error),
        .err_evt(hx_e_unused), .err_addr(hx_ea_unused), .err_master(hx_em_unused), .err_write(hx_ew_unused),
        .ev_req_accept(hx_err_unused_a), .ev_req_stall(hx_err_unused_b), .ev_arb_loss(hx_err_unused_c), .ev_rsp_stall(hx_err_unused_d)
      );
    end
  endgenerate

  sfd_hm_port #(.AW(AW), .DW(DW)) u_hm (
    .clk, .rst_n, .dp_resetting,
    .s_req_valid(mx_req_valid), .s_req_ready(mx_req_ready), .s_req_write(mx_req_write), .s_req_addr(mx_req_addr),
    .s_req_wdata(mx_req_wdata), .s_req_wstrb(mx_req_wstrb),
    .s_rsp_valid(mx_rsp_valid), .s_rsp_ready(mx_rsp_ready), .s_rsp_rdata(mx_rsp_rdata), .s_rsp_error(mx_rsp_error),
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .out_o(hm_out_o), .orphan_o(hm_orphan_o)
  );
  assign ev_stall_host = mx_req_valid && !mx_req_ready;

  wire unused_ok = &{1'b0, x_ev_stall};
endmodule

`default_nettype wire
