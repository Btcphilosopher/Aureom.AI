// =============================================================================
// CloudDPU :: sfd_clouddma -- CloudDMA channel: host memory <-> local SRAM (native to Project 61;
// no CloudDMA existed in the repository, see docs/00_AUDIT.md)
//
//   dir 0  H2D   host read beat -> SRAM write beat        (load)
//   dir 1  D2H   SRAM read beat -> host write beat        (store)
// One beat = DW bits, SFB2 single-beat transactions, one outstanding transaction per port (R6).  Host
// address and SRAM address must be beat aligned; the length may end inside a beat: the last beat of a
// store/load uses a partial byte strobe, so no byte outside [addr, addr+len) is ever written.
//
// COMMIT SEMANTICS.  `done_commit` is raised only when the response of the LAST write beat has been
// received (SFB2 R7: a write response is issued only after the target performed the write).  A
// transfer that fails part-way reports done_commit = 0 and an error code; bytes already written stay
// written (they are inside the tenant's own window / partition: the guards guarantee that).
//
// The ports are plain SFB2 masters; the per-beat permission guards (sfd_host_guard / sfd_sram_guard)
// sit OUTSIDE this block, in sfd_job_slot, between these ports and the fabric.  `g_viol` tells this
// block that a guard swallowed one of its requests, so the error is reported as ERR_PERM_BEAT.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_clouddma #(
  parameter int DW = 32,
  parameter int AW = 32
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // command
  input  wire logic            cmd_valid,
  output logic                 cmd_ready,
  input  wire logic            cmd_dir,
  input  wire logic [AW-1:0]   cmd_haddr,
  input  wire logic [31:0]     cmd_saddr,
  input  wire logic [31:0]     cmd_len,
  // result
  output logic                 done_valid,
  output logic [7:0]           done_err,
  output logic [31:0]          done_bytes,
  output logic                 done_commit,
  output logic                 busy,
  // host memory master
  output logic                 hm_req_valid,
  input  wire logic            hm_req_ready,
  output logic                 hm_req_write,
  output logic [AW-1:0]        hm_req_addr,
  output logic [DW-1:0]        hm_req_wdata,
  output logic [DW/8-1:0]      hm_req_wstrb,
  input  wire logic            hm_rsp_valid,
  output logic                 hm_rsp_ready,
  input  wire logic [DW-1:0]   hm_rsp_rdata,
  input  wire logic            hm_rsp_error,
  // SRAM master
  output logic                 sm_req_valid,
  input  wire logic            sm_req_ready,
  output logic                 sm_req_write,
  output logic [31:0]          sm_req_addr,
  output logic [DW-1:0]        sm_req_wdata,
  output logic [DW/8-1:0]      sm_req_wstrb,
  input  wire logic            sm_rsp_valid,
  output logic                 sm_rsp_ready,
  input  wire logic [DW-1:0]   sm_rsp_rdata,
  input  wire logic            sm_rsp_error,
  // a guard swallowed a request of this channel
  input  wire logic            g_viol,
  // events (one pulse per completed data beat)
  output logic                 ev_h2d_beat,
  output logic                 ev_d2h_beat,
  output logic [7:0]           ev_beat_bytes
);
  localparam int DWB = DW / 8;
  localparam int DLG = $clog2(DWB);
  localparam logic [31:0] DWB32 = DWB;

  localparam logic [3:0] S_IDLE = 4'd0,  S_H_RD_REQ = 4'd1, S_H_RD_RSP = 4'd2, S_S_WR_REQ = 4'd3, S_S_WR_RSP = 4'd4,
                         S_S_RD_REQ = 4'd5, S_S_RD_RSP = 4'd6, S_H_WR_REQ = 4'd7, S_H_WR_RSP = 4'd8, S_DONE = 4'd9;

  logic [3:0]        st_q;
  logic              dir_q, viol_q;
  logic [AW-1:0]     haddr_q;
  logic [31:0]       saddr_q, beats_q, bytes_q;
  logic [DLG-1:0]    rem_q;                 // length modulo the beat size
  logic [DW-1:0]     data_q;
  logic [7:0]        err_q;

  // beat geometry
  wire              last    = (beats_q == 32'd1);
  wire [DLG-1:0]    rem     = rem_q;
  wire              partial = last && (rem != '0);
  logic [DWB-1:0]   strb;
  logic [7:0]       nbytes;
  always_comb begin
    for (int b = 0; b < DWB; b++) strb[b] = !(partial && (b >= {1'b0, rem}));
    nbytes = partial ? {{(8-DLG){1'b0}}, rem} : DWB[7:0];
  end

  assign cmd_ready    = (st_q == S_IDLE);
  assign busy         = (st_q != S_IDLE);
  assign done_valid   = (st_q == S_DONE);
  assign done_err     = err_q;
  assign done_bytes   = bytes_q;
  assign done_commit  = (st_q == S_DONE) && dir_q && (err_q == silicaflux_cloud_pkg::ERR_NONE);

  assign hm_req_valid = (st_q == S_H_RD_REQ) || (st_q == S_H_WR_REQ);
  assign hm_req_write = (st_q == S_H_WR_REQ);
  assign hm_req_addr  = haddr_q;
  assign hm_req_wdata = data_q;
  assign hm_req_wstrb = strb;
  assign hm_rsp_ready = (st_q == S_H_RD_RSP) || (st_q == S_H_WR_RSP);

  assign sm_req_valid = (st_q == S_S_WR_REQ) || (st_q == S_S_RD_REQ);
  assign sm_req_write = (st_q == S_S_WR_REQ);
  assign sm_req_addr  = saddr_q;
  assign sm_req_wdata = data_q;
  assign sm_req_wstrb = strb;
  assign sm_rsp_ready = (st_q == S_S_WR_RSP) || (st_q == S_S_RD_RSP);

  assign ev_h2d_beat   = (st_q == S_S_WR_RSP) && sm_rsp_valid && !sm_rsp_error;
  assign ev_d2h_beat   = (st_q == S_H_WR_RSP) && hm_rsp_valid && !hm_rsp_error;
  assign ev_beat_bytes = nbytes;

  wire [7:0] host_err = viol_q ? silicaflux_cloud_pkg::ERR_PERM_BEAT : silicaflux_cloud_pkg::ERR_HOST_MEM;
  wire [7:0] sram_err = viol_q ? silicaflux_cloud_pkg::ERR_PERM_BEAT : silicaflux_cloud_pkg::ERR_SRAM_RESP;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q    <= S_IDLE;
      dir_q   <= 1'b0;
      viol_q  <= 1'b0;
      haddr_q <= '0;
      saddr_q <= '0;
      rem_q   <= '0;
      beats_q <= '0;
      bytes_q <= '0;
      data_q  <= '0;
      err_q   <= silicaflux_cloud_pkg::ERR_NONE;
    end else begin
      if (g_viol) viol_q <= 1'b1;
      case (st_q)
        S_IDLE: begin
          if (cmd_valid) begin
            dir_q   <= cmd_dir;
            haddr_q <= cmd_haddr;
            saddr_q <= cmd_saddr;
            rem_q   <= cmd_len[DLG-1:0];
            beats_q <= (cmd_len + DWB32 - 32'd1) >> DLG;
            bytes_q <= 32'd0;
            err_q   <= silicaflux_cloud_pkg::ERR_NONE;
            viol_q  <= 1'b0;
            if (cmd_len == 32'd0)  st_q <= S_DONE;
            else if (cmd_dir)      st_q <= S_S_RD_REQ;
            else                   st_q <= S_H_RD_REQ;
          end
        end
        // ---------------- H2D: host read -> SRAM write
        S_H_RD_REQ: if (hm_req_ready) st_q <= S_H_RD_RSP;
        S_H_RD_RSP: begin
          if (hm_rsp_valid) begin
            if (hm_rsp_error) begin err_q <= host_err; st_q <= S_DONE; end
            else begin data_q <= hm_rsp_rdata; st_q <= S_S_WR_REQ; end
          end
        end
        S_S_WR_REQ: if (sm_req_ready) st_q <= S_S_WR_RSP;
        S_S_WR_RSP: begin
          if (sm_rsp_valid) begin
            if (sm_rsp_error) begin err_q <= sram_err; st_q <= S_DONE; end
            else begin
              bytes_q <= bytes_q + {24'd0, nbytes};
              haddr_q <= haddr_q + AW'(DWB);
              saddr_q <= saddr_q + DWB32;
              beats_q <= beats_q - 32'd1;
              st_q    <= last ? S_DONE : S_H_RD_REQ;
            end
          end
        end
        // ---------------- D2H: SRAM read -> host write
        S_S_RD_REQ: if (sm_req_ready) st_q <= S_S_RD_RSP;
        S_S_RD_RSP: begin
          if (sm_rsp_valid) begin
            if (sm_rsp_error) begin err_q <= sram_err; st_q <= S_DONE; end
            else begin data_q <= sm_rsp_rdata; st_q <= S_H_WR_REQ; end
          end
        end
        S_H_WR_REQ: if (hm_req_ready) st_q <= S_H_WR_RSP;
        S_H_WR_RSP: begin
          if (hm_rsp_valid) begin
            if (hm_rsp_error) begin err_q <= host_err; st_q <= S_DONE; end
            else begin
              bytes_q <= bytes_q + {24'd0, nbytes};      // counted only once the destination acknowledged it
              haddr_q <= haddr_q + AW'(DWB);
              saddr_q <= saddr_q + DWB32;
              beats_q <= beats_q - 32'd1;
              st_q    <= last ? S_DONE : S_S_RD_REQ;
            end
          end
        end
        S_DONE: st_q <= S_IDLE;
        default: begin err_q <= silicaflux_cloud_pkg::ERR_INTERNAL; st_q <= S_DONE; end
      endcase
    end
  end
endmodule

`default_nettype wire
