// =============================================================================
// CloudDPU :: sfd_pkt_hub -- shares ONE PacketCore (test adapter) between the job slots
//
// Round-robin arbitration of the slots' PacketCore requests, one job at a time.  The result pulse of the
// adapter is routed to the slot that owns the job.  The adapter's SRAM master leaves through an
// sfd_sram_guard that uses the tenant of the job currently in the adapter, so PacketCore can never touch
// SRAM outside the owning tenant's partition either.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_pkt_hub #(
  parameter int DW = 32,
  parameter int NS = 1,          // slots
  parameter int NT = 1
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // slot side (arrays)
  input  wire logic [NS-1:0]       pkt_req,
  input  wire logic [NS*32-1:0]    pkt_in,
  input  wire logic [NS*32-1:0]    pkt_out,
  input  wire logic [NS*32-1:0]    pkt_len,
  input  wire logic [NS*8-1:0]     pkt_op,
  input  wire logic [NS*32-1:0]    pkt_param,
  /* verilator lint_off UNUSEDSIGNAL */          // only log2(NT) tenant bits are needed
  input  wire logic [NS*4-1:0]     pkt_tenant,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [NS-1:0]            pkt_ack,
  output logic [NS-1:0]            pkt_res_valid,
  output logic [7:0]               pkt_res_err,
  output logic [31:0]              pkt_res_crc_in,
  output logic [31:0]              pkt_res_crc_out,
  output logic [15:0]              pkt_res_csum,
  // tenant context for the guard
  input  wire logic [NT-1:0]       t_cfg_ok,
  input  wire logic [NT*32-1:0]    t_part_base,
  input  wire logic [NT*32-1:0]    t_part_size,
  // SRAM master (guarded)
  output logic                 sm_req_valid,
  input  wire logic            sm_req_ready,
  output logic                 sm_req_write,
  output logic [31:0]          sm_req_addr,
  output logic [DW-1:0]        sm_req_wdata,
  output logic [DW/8-1:0]      sm_req_wstrb,
  input  wire logic            sm_rsp_valid,
  output logic                 sm_rsp_ready,
  input  wire logic [DW-1:0]   sm_rsp_rdata,
  input  wire logic            sm_rsp_error,
  output logic                 busy,
  output logic                 ev_job,
  output logic                 ev_guard_trip
);
  localparam int TIW = (NT > 1) ? $clog2(NT) : 1;
  localparam int SIW = (NS > 1) ? $clog2(NS) : 1;

  logic [NS-1:0] grant;
  logic          any;
  logic          a_job_valid, a_job_ready;
  logic          a_res_valid;
  logic [SIW-1:0] own_q;
  logic [TIW-1:0] ten_q;
  logic          own_v_q;

  sfd_rr_arb #(.N(NS)) u_arb (.clk, .rst_n, .req(pkt_req & {NS{!own_v_q}}), .advance(a_job_valid && a_job_ready), .grant, .any);

  logic [SIW-1:0] gsel;
  always_comb begin
    gsel = '0;
    for (int s = 0; s < NS; s++) if (grant[s]) gsel = s[SIW-1:0];
  end
  assign a_job_valid = any && !own_v_q;
  assign pkt_ack     = grant & {NS{a_job_valid && a_job_ready}};
  assign ev_job      = a_job_valid && a_job_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      own_q <= '0;  ten_q <= '0;  own_v_q <= 1'b0;
    end else begin
      if (a_job_valid && a_job_ready) begin
        own_q   <= gsel;
        ten_q   <= pkt_tenant[gsel*4 +: TIW];
        own_v_q <= 1'b1;
      end else if (a_res_valid) begin
        own_v_q <= 1'b0;
      end
    end
  end

  logic         pm_req_valid, pm_req_ready, pm_req_write, pm_rsp_valid, pm_rsp_ready, pm_rsp_error;
  logic [31:0]  pm_req_addr;
  logic [DW-1:0] pm_req_wdata, pm_rsp_rdata;
  logic [DW/8-1:0] pm_req_wstrb;
  logic         g_trip;
  logic         allow_unused;
  logic [31:0]  res_bytes_unused;
  wire [TIW-1:0] ti = ten_q;

  sfd_packetcore_tadapter #(.DW(DW)) u_pkt (
    .clk, .rst_n,
    .job_valid(a_job_valid), .job_ready(a_job_ready),
    .job_in(pkt_in[gsel*32 +: 32]), .job_out(pkt_out[gsel*32 +: 32]), .job_len(pkt_len[gsel*32 +: 32]),
    .job_op(pkt_op[gsel*8 +: 8]), .job_param(pkt_param[gsel*32 +: 32]),
    .res_valid(a_res_valid), .res_err(pkt_res_err), .res_crc_in(pkt_res_crc_in), .res_crc_out(pkt_res_crc_out),
    .res_csum(pkt_res_csum), .res_bytes(res_bytes_unused),
    .busy,
    .sm_req_valid(pm_req_valid), .sm_req_ready(pm_req_ready), .sm_req_write(pm_req_write), .sm_req_addr(pm_req_addr),
    .sm_req_wdata(pm_req_wdata), .sm_req_wstrb(pm_req_wstrb),
    .sm_rsp_valid(pm_rsp_valid), .sm_rsp_ready(pm_rsp_ready), .sm_rsp_rdata(pm_rsp_rdata), .sm_rsp_error(pm_rsp_error),
    .g_viol(g_trip)
  );
  always_comb begin
    pkt_res_valid = '0;
    for (int s = 0; s < NS; s++) pkt_res_valid[s] = a_res_valid && own_v_q && (own_q == s[SIW-1:0]);
  end

  sfd_sram_guard #(.DW(DW)) u_guard (
    .clk, .rst_n,
    .m_req_valid(pm_req_valid), .m_req_ready(pm_req_ready), .m_req_write(pm_req_write), .m_req_addr(pm_req_addr),
    .m_req_wdata(pm_req_wdata), .m_req_wstrb(pm_req_wstrb),
    .m_rsp_valid(pm_rsp_valid), .m_rsp_ready(pm_rsp_ready), .m_rsp_rdata(pm_rsp_rdata), .m_rsp_error(pm_rsp_error),
    .s_req_valid(sm_req_valid), .s_req_ready(sm_req_ready), .s_req_write(sm_req_write), .s_req_addr(sm_req_addr),
    .s_req_wdata(sm_req_wdata), .s_req_wstrb(sm_req_wstrb),
    .s_rsp_valid(sm_rsp_valid), .s_rsp_ready(sm_rsp_ready), .s_rsp_rdata(sm_rsp_rdata), .s_rsp_error(sm_rsp_error),
    .job_active(own_v_q && t_cfg_ok[ti]), .part_base(t_part_base[ti*32 +: 32]), .part_size(t_part_size[ti*32 +: 32]),
    .allow_o(allow_unused), .viol_evt(g_trip)
  );
  assign ev_guard_trip = g_trip;
  wire unused_ok = &{1'b0, allow_unused, res_bytes_unused};
endmodule

`default_nettype wire
