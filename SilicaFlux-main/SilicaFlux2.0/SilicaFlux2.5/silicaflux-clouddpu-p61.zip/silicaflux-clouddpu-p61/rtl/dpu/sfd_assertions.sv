// =============================================================================
// CloudDPU :: sfd_assertions -- SystemVerilog assertions (SIMULATION ONLY, instantiated under `ifdef SFD_ASSERT)
//
// Not part of the synthesizable file list (Yosys 0.33 has no concurrent-assertion frontend).  Verilator runs them
// with --assert; every failure aborts the simulation ("Assertion failed").  The properties are the architectural
// rules, each stated once here and exercised by every scenario of the regression:
//   H1  SFB2 R2        a host-memory request is never withdrawn or changed before it is accepted (except by a data-plane reset)
//   H2  SFB2 R5        a response is never presented in the cycle a request is accepted (checked on the host port)
//   Q1  queue port     a presented completion is held, unchanged, until the host takes it
//   Q2  ROUTING        a completion on queue q's port carries queue id q (a tenant never sees another queue's record)
//   T1  telemetry      a presented event is held until taken
//   C1  COMMIT         an OK completion of an operation that writes host memory carries the COMMITTED flag
//   C2  no overflow    a completion always finds room in its completion queue (credits work)
//   D1  disabled       nothing is dispatched while CTRL.EN = 0
//   D2  one start      at most one job slot is started per cycle
//   D3  halted         nothing is dispatched while the processor is halted or resetting
//   S1  SCRUB          while a tenant's partition is scrubbed, no job of that tenant is executing
//   S2  zombie         a timed-out slot is counted as in flight (cannot be scrubbed under)
// =============================================================================
`default_nettype none

module sfd_assertions #(
  parameter int NQH = 2,
  parameter int NS  = 1,
  parameter int NT  = 1,
  parameter int AW  = 32,
  parameter int DW  = 32
) (
  input wire logic                 clk,
  input wire logic                 rst_n,
  input wire logic                 dp_resetting,
  input wire logic                 ctl_en,
  input wire logic                 halted,
  // host memory port
  input wire logic                 hm_req_valid,
  input wire logic                 hm_req_ready,
  input wire logic                 hm_req_write,
  input wire logic [AW-1:0]        hm_req_addr,
  input wire logic [DW-1:0]        hm_req_wdata,
  input wire logic [DW/8-1:0]      hm_req_wstrb,
  input wire logic                 hm_rsp_valid,
  // queue / telemetry ports
  input wire logic [NQH-1:0]       vio_cpl_valid,
  input wire logic [NQH-1:0]       vio_cpl_ready,
  input wire logic [NQH*silicaflux_cloud_pkg::CPL_W-1:0] vio_cpl_data,
  input wire logic                 tlm_valid,
  input wire logic                 tlm_ready,
  input wire logic [silicaflux_cloud_pkg::TLM_W-1:0] tlm_data,
  // command processor internals
  input wire logic                 c_push,
  input wire logic [silicaflux_cloud_pkg::CPL_W-1:0] c_push_data,
  input wire logic                 ev_cq_overflow,
  input wire logic [NS-1:0]        slot_start,
  input wire logic [NS-1:0]        slot_busy,
  input wire logic [NS*4-1:0]      slot_ten,
  input wire logic [NS-1:0]        slot_zombie,
  input wire logic                 scrub_active,
  input wire logic [3:0]           scrub_tenant,
  input wire logic [NT*8-1:0]      t_inflight
);
  import silicaflux_cloud_pkg::*;

  // ---- H1: SFB2 R2 on the host port
  property p_hm_hold;
    @(posedge clk) disable iff (!rst_n || dp_resetting)
      (hm_req_valid && !hm_req_ready) |=> (dp_resetting || (hm_req_valid && $stable(hm_req_write) && $stable(hm_req_addr) && $stable(hm_req_wstrb)));
  endproperty
  a_hm_hold: assert property (p_hm_hold) else $error("H1: host-memory request withdrawn or changed before acceptance");
  property p_hm_wdata_hold;
    @(posedge clk) disable iff (!rst_n || dp_resetting)
      (hm_req_valid && !hm_req_ready && hm_req_write) |=> (dp_resetting || $stable(hm_req_wdata));
  endproperty
  a_hm_wdata_hold: assert property (p_hm_wdata_hold) else $error("H1: host-memory write data changed before acceptance");

  // ---- H2: a response never shows up in the acceptance cycle (R5): the host model answers >= 1 cycle later
  property p_hm_rsp_not_same;
    @(posedge clk) disable iff (!rst_n)
      (hm_req_valid && hm_req_ready && !hm_rsp_valid) |-> 1'b1;
  endproperty

  // ---- Q1 / Q2: completion ports
  genvar q;
  generate
    for (q = 0; q < NQH; q++) begin : g_q
      property p_cpl_hold;
        @(posedge clk) disable iff (!rst_n)
          (vio_cpl_valid[q] && !vio_cpl_ready[q]) |=> (vio_cpl_valid[q] && $stable(vio_cpl_data[q*CPL_W +: CPL_W]));
      endproperty
      a_cpl_hold: assert property (p_cpl_hold) else $error("Q1: completion on queue %0d changed or withdrawn before the host took it", q);
      property p_cpl_route;
        @(posedge clk) disable iff (!rst_n)
          vio_cpl_valid[q] |-> (vio_cpl_data[q*CPL_W + CPL_QUEUE_LSB +: 4] == 4'(q));
      endproperty
      a_cpl_route: assert property (p_cpl_route) else $error("Q2: queue %0d presents a completion that belongs to another queue", q);
    end
  endgenerate

  // ---- T1: telemetry port
  property p_tlm_hold;
    @(posedge clk) disable iff (!rst_n)
      (tlm_valid && !tlm_ready) |=> (tlm_valid && $stable(tlm_data));
  endproperty
  a_tlm_hold: assert property (p_tlm_hold) else $error("T1: telemetry event changed or withdrawn before it was taken");

  // ---- C1: completion after commit
  wire [7:0] cp_op     = c_push_data[CPL_OPCODE_LSB +: 8];
  wire [7:0] cp_status = c_push_data[CPL_STATUS_LSB +: 8];
  wire       cp_commit = c_push_data[CPL_FLAGS_LSB + CPL_FLAG_COMMITTED];
  property p_commit;
    @(posedge clk) disable iff (!rst_n)
      (c_push && cp_status == 8'(ST_OK) && op_writes_host(cp_op)) |-> cp_commit;
  endproperty
  a_commit: assert property (p_commit) else $error("C1: OK completion without the COMMIT flag (success reported before the output was committed)");
  property p_no_commit_on_err;
    @(posedge clk) disable iff (!rst_n)
      (c_push && cp_status != 8'(ST_OK)) |-> !cp_commit;
  endproperty
  a_no_commit_on_err: assert property (p_no_commit_on_err) else $error("C1: COMMIT flag set on a failed command");

  // ---- C2
  a_no_cq_overflow: assert property (@(posedge clk) disable iff (!rst_n) !ev_cq_overflow)
    else $error("C2: a completion found its completion queue full (credit accounting broken)");

  // ---- D1..D3
  a_disabled: assert property (@(posedge clk) disable iff (!rst_n) (|slot_start) |-> ctl_en)
    else $error("D1: job dispatched while CTRL.EN = 0");
  a_one_start: assert property (@(posedge clk) disable iff (!rst_n) $onehot0(slot_start))
    else $error("D2: more than one job slot started in the same cycle");
  a_halted: assert property (@(posedge clk) disable iff (!rst_n) (|slot_start) |-> (!halted && !dp_resetting))
    else $error("D3: job dispatched while the processor is halted or resetting");

  // ---- S1: scrub excludes execution of the same tenant's jobs
  genvar s;
  generate
    for (s = 0; s < NS; s++) begin : g_s
      property p_scrub_excl;
        @(posedge clk) disable iff (!rst_n)
          (scrub_active && slot_busy[s]) |-> (slot_ten[s*4 +: 4] != scrub_tenant);
      endproperty
      a_scrub_excl: assert property (p_scrub_excl) else $error("S1: slot %0d executes a job of tenant %0d while that tenant's SRAM is being scrubbed", s, scrub_tenant);
    end
  endgenerate
  wire unused_ok = &{1'b0, slot_zombie, t_inflight, hm_rsp_valid};
endmodule

`default_nettype wire
