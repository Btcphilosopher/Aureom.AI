// =============================================================================
// CloudDPU :: sfd_cmdproc -- cloud command processor
//
// Arbitrates the command queues (round robin among queues that have a descriptor AND a completion credit),
// validates each descriptor, dispatches it to a free job slot (or completes it with an error), turns slot
// results into completion records, watches every job, and runs the data-plane reset sequence.
//
// VALIDATION ORDER (first failing check decides the error code; nothing has moved yet when it fails):
//   1 mgmt tenant range   2 tenant claim == queue binding (host queues)   3 reserved fields zero
//   4 opcode known        5 opcode legal on this queue class                6 tenant ACTIVE (else QUARANTINED/STATE)
//   7 engine class blocked (INFER/CRYPTO/STORAGE -> ERR_BLOCKED)           NOP completes here
//   8 length / PacketCore op      9 beat alignment      10 SRAM buffers inside the tenant's partition
//  11 host source readable (window, R)       12 host destination writable (window, W)
// Checks 2, 10, 11, 12 are ISOLATION checks: a failure is a violation (error 0x10..0x13), is reported to the
// tenant context (counter, optional quarantine), to the fault registers and to telemetry.  The per-beat guards
// in the slots re-check the same properties on every actual access (defence in depth).
//
// COMPLETION RULE.  A completion with status OK is built only from a slot result that carries the CloudDMA
// COMMIT flag when the operation writes host memory.  A result without it is turned into ERR_INTERNAL: the DPU
// can never report success before the output is committed.
//
// WATCHDOG / RECOVERY.  A job older than JOB_TIMEOUT cycles is completed with ERR_TIMEOUT, its slot becomes a
// ZOMBIE (still counted as in flight for its tenant, so the tenant cannot be scrubbed under a slot that may
// still write) and the processor HALTS (no new dispatch).  DP_RESET aborts what is left (ERR_RESET_ABORT),
// resets the data plane (slots, DMA, PacketCore, fabric, SRAM controller), clears the zombies and resumes.
// Tenant configuration, queues and completion FIFOs survive a data-plane reset.
// Persistent reset domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_cmdproc #(
  parameter int NQH      = 2,
  parameter int NS       = 1,
  parameter int NT       = 1,
  parameter int NW       = 2,
  parameter int DW       = 32,
  parameter int MAX_XFER = 4096
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // control
  input  wire logic            ctl_en,
  input  wire logic            dp_reset_req,
  input  wire logic [31:0]     job_timeout,
  input  wire logic [31:0]     time_cnt,
  output logic                 halted,
  output logic                 dp_rst_n_o,
  output logic                 dp_resetting,
  output logic                 busy,
  output logic [7:0]           inflight_total,
  // queues
  input  wire logic [NQH:0]    h_valid,
  input  wire logic [(NQH+1)*silicaflux_cloud_pkg::CMD_W-1:0] h_cmd,
  output logic [NQH:0]         h_pop,
  input  wire logic [NQH:0]    h_credit,
  input  wire logic [(NQH+1)*4-1:0] q_tenant,
  input  wire logic [NQH:0]    q_compute,
  output logic                 c_push,
  output logic [3:0]           c_push_q,
  output logic [silicaflux_cloud_pkg::CPL_W-1:0] c_push_data,
  // tenant context
  input  wire logic [NT*3-1:0]      t_state,
  input  wire logic [NT*32-1:0]     t_part_size,
  input  wire logic [NT*NW*64-1:0]  t_win_base,
  input  wire logic [NT*NW*32-1:0]  t_win_size,
  input  wire logic [NT*NW-1:0]     t_win_valid,
  input  wire logic [NT*NW*2-1:0]   t_win_perm,
  output logic [NT*8-1:0]           t_inflight,
  output logic                 viol_evt,
  output logic [3:0]           viol_tenant,
  // job slots
  output logic [NS-1:0]        slot_start,
  output logic [NS*silicaflux_cloud_pkg::TXN_W-1:0] slot_txn,
  input  wire logic [NS-1:0]   slot_busy,
  input  wire logic [NS-1:0]   slot_done,
  output logic [NS-1:0]        slot_ack,
  input  wire logic [NS*8-1:0] slot_err,
  input  wire logic [NS*32-1:0] slot_bytes,
  input  wire logic [NS-1:0]   slot_commit,
  input  wire logic [NS*32-1:0] slot_crc_in,
  input  wire logic [NS*32-1:0] slot_crc_out,
  input  wire logic [NS*16-1:0] slot_csum,
  input  wire logic [NS*64-1:0] slot_faddr,
  // faults and events
  output logic [silicaflux_cloud_pkg::FLT_NUM-1:0] flt_set,
  output logic [3:0]           flt_tenant,
  output logic [7:0]           flt_err,
  output logic [63:0]          flt_addr,
  output logic                 flt_addr_valid,
  output logic                 ev_retire,
  output logic [3:0]           ev_ten,
  output logic [3:0]           ev_queue,
  output logic [7:0]           ev_err,
  output logic [7:0]           ev_status,
  output logic [31:0]          ev_bytes,
  output logic                 ev_blocked,
  output logic                 ev_stall,
  output logic                 ev_dp_reset,
  // debug
  output logic [3:0]           dbg_state,
  output logic [3:0]           dbg_qsel,
  output logic [NS-1:0]        dbg_zombie
);
  localparam int NQT  = NQH + 1;
  localparam int CMDW = silicaflux_cloud_pkg::CMD_W;
  localparam int CPLW = silicaflux_cloud_pkg::CPL_W;
  localparam int TXNW = silicaflux_cloud_pkg::TXN_W;
  localparam int DWB  = DW / 8;
  localparam int DLG  = $clog2(DWB);
  localparam int TIW  = (NT > 1) ? $clog2(NT) : 1;
  localparam int SIW  = (NS > 1) ? $clog2(NS) : 1;
  localparam int QIW  = (NQT > 1) ? $clog2(NQT) : 1;
  localparam logic [31:0] DWB32 = DWB;
  localparam logic [31:0] MAXX  = MAX_XFER;

  localparam logic [3:0] P_RUN = 4'd0, P_RS_ABORT = 4'd1, P_RS_ASSERT = 4'd2, P_RS_DONE = 4'd3;

  // ------------------------------------------------------------ state
  logic [3:0]            ps_q;
  logic [2:0]            rs_cnt_q;
  logic                  halted_q;
  logic [15:0]           txn_ctr_q;
  logic [NS-1:0]         inf_v_q, zombie_q;
  logic [TXNW-1:0]       inf_txn_q [NS];
  logic [31:0]           age_q [NS];
  logic [7:0]            tinf_q [NT];
  logic                  dp_rst_n_q;
  logic                  rs_req_q;

  assign halted       = halted_q;
  assign dp_rst_n_o   = dp_rst_n_q;
  assign dp_resetting = (ps_q != P_RUN);
  assign dbg_state    = ps_q;
  assign dbg_zombie   = zombie_q;
  always_comb begin
    for (int t = 0; t < NT; t++) t_inflight[t*8 +: 8] = tinf_q[t];
    inflight_total = 8'd0;
    for (int s = 0; s < NS; s++) inflight_total = inflight_total + {7'd0, inf_v_q[s]};
  end
  assign busy = (|inf_v_q) || (|h_valid) || (ps_q != P_RUN);

  // ------------------------------------------------------------ queue selection
  logic [NQT-1:0] elig, grant;
  logic           any_elig;
  logic           run_ok;
  assign run_ok = ctl_en && !halted_q && (ps_q == P_RUN);
  always_comb begin
    for (int q = 0; q < NQT; q++) elig[q] = run_ok && h_valid[q] && h_credit[q];
  end
  logic act_done;                                   // an action completes this cycle (advance arbiter)
  sfd_rr_arb #(.N(NQT)) u_arb (.clk, .rst_n, .req(elig), .advance(act_done), .grant, .any(any_elig));

  logic [QIW-1:0] sel;
  always_comb begin
    sel = '0;
    for (int q = 0; q < NQT; q++) if (grant[q]) sel = q[QIW-1:0];
  end
  assign dbg_qsel = 4'(sel);

  wire [CMDW-1:0] cmd       = h_cmd[sel*CMDW +: CMDW];
  wire            is_mgmt   = (sel == QIW'(NQH));
  wire [3:0]      bound     = q_tenant[sel*4 +: 4];
  wire            cls_comp  = q_compute[sel];

  // ------------------------------------------------------------ descriptor fields
  wire [7:0]  d_op    = cmd[silicaflux_cloud_pkg::CMD_OPCODE_LSB +: 8];
  wire [7:0]  d_flags = cmd[silicaflux_cloud_pkg::CMD_FLAGS_LSB +: 8];
  wire [3:0]  d_ten   = cmd[silicaflux_cloud_pkg::CMD_TENANT_LSB +: 4];
  wire [11:0] d_w0r   = cmd[silicaflux_cloud_pkg::CMD_W0_RSVD_LSB +: 12];
  wire [31:0] d_tag   = cmd[silicaflux_cloud_pkg::CMD_TAG_LSB +: 32];
  wire [63:0] d_src   = cmd[silicaflux_cloud_pkg::CMD_SRC_LSB +: 64];
  wire [63:0] d_dst   = cmd[silicaflux_cloud_pkg::CMD_DST_LSB +: 64];
  wire [31:0] d_len   = cmd[silicaflux_cloud_pkg::CMD_LEN_LSB +: 32];
  wire [31:0] d_soff  = cmd[silicaflux_cloud_pkg::CMD_SRAM_OFF_LSB +: 32];
  wire [7:0]  d_pop   = cmd[silicaflux_cloud_pkg::CMD_PROC_OP_LSB +: 8];
  wire [23:0] d_w8r   = cmd[silicaflux_cloud_pkg::CMD_W8_RSVD_LSB +: 24];
  wire [31:0] d_param = cmd[silicaflux_cloud_pkg::CMD_PARAM_LSB +: 32];
  wire [63:0] d_rsv   = cmd[silicaflux_cloud_pkg::CMD_RSVD_LSB +: 64];

  wire [3:0]     ten    = is_mgmt ? d_ten : bound;
  wire [TIW-1:0] ti     = ten[TIW-1:0];
  wire           ten_in_range = ({1'b0, ten} < 5'(NT));
  wire [2:0]     tstate = ten_in_range ? t_state[ti*3 +: 3] : silicaflux_cloud_pkg::TS_DISABLED;

  wire op_net  = silicaflux_cloud_pkg::op_is_net(d_op);
  wire op_eng  = silicaflux_cloud_pkg::op_is_eng(d_op);
  wire op_rd   = silicaflux_cloud_pkg::op_reads_host(d_op);
  wire op_wr   = silicaflux_cloud_pkg::op_writes_host(d_op);
  wire op_pkt  = (d_op == silicaflux_cloud_pkg::OP_PKT_PROCESS);
  wire op_nop  = (d_op == silicaflux_cloud_pkg::OP_NOP);

  // window checks on the tenant's live windows
  logic win_rd_ok, win_wr_ok;
  sfd_win_check #(.NW(NW)) u_wr (
    .win_base(t_win_base[ti*NW*64 +: NW*64]), .win_size(t_win_size[ti*NW*32 +: NW*32]),
    .win_valid(t_win_valid[ti*NW +: NW]), .win_perm(t_win_perm[ti*NW*2 +: NW*2]),
    .addr(d_src), .len(d_len), .need_r(1'b1), .need_w(1'b0), .ok(win_rd_ok));
  sfd_win_check #(.NW(NW)) u_ww (
    .win_base(t_win_base[ti*NW*64 +: NW*64]), .win_size(t_win_size[ti*NW*32 +: NW*32]),
    .win_valid(t_win_valid[ti*NW +: NW]), .win_perm(t_win_perm[ti*NW*2 +: NW*2]),
    .addr(d_dst), .len(d_len), .need_r(1'b0), .need_w(1'b1), .ok(win_wr_ok));

  // SRAM staging buffers inside the partition
  wire [31:0] len_al    = (d_len + DWB32 - 32'd1) & ~(DWB32 - 32'd1);
  wire [34:0] sram_need = {3'd0, d_soff} + (op_pkt ? {2'd0, len_al, 1'b0} : {3'd0, len_al});
  wire [31:0] psize     = ten_in_range ? t_part_size[ti*32 +: 32] : 32'd0;
  wire        sram_bad  = (d_soff > psize) || (sram_need > {3'd0, psize});

  // ------------------------------------------------------------ verdict
  logic [7:0] v_err;
  logic       v_nop;                                  // completes at once, no slot
  logic       v_need_slot;
  logic [63:0] v_faddr;
  always_comb begin
    v_err       = silicaflux_cloud_pkg::ERR_NONE;
    v_nop       = 1'b0;
    v_need_slot = 1'b0;
    v_faddr     = 64'd0;
    if (is_mgmt && !ten_in_range)                                       v_err = silicaflux_cloud_pkg::ERR_BAD_TENANT;
    else if (!is_mgmt && d_ten != bound)                                v_err = silicaflux_cloud_pkg::ERR_TENANT_MISMATCH;
    else if (d_w0r != 12'd0 || d_flags[7:1] != 7'd0 || d_w8r != 24'd0 || d_rsv != 64'd0)
                                                                        v_err = silicaflux_cloud_pkg::ERR_BAD_DESC;
    else if (!(op_nop || op_net || op_eng))                             v_err = silicaflux_cloud_pkg::ERR_BAD_OPCODE;
    else if (!is_mgmt && ((op_net && cls_comp) || (op_eng && !cls_comp))) v_err = silicaflux_cloud_pkg::ERR_BAD_OPCODE;
    else if (tstate == silicaflux_cloud_pkg::TS_QUARANTINED)            v_err = silicaflux_cloud_pkg::ERR_QUARANTINED;
    else if (tstate != silicaflux_cloud_pkg::TS_ACTIVE)                 v_err = silicaflux_cloud_pkg::ERR_TENANT_STATE;
    else if (op_eng)                                                    v_err = silicaflux_cloud_pkg::ERR_BLOCKED;
    else if (op_nop)                                                    v_nop = 1'b1;
    else if (d_len == 32'd0 || d_len > MAXX)                            v_err = silicaflux_cloud_pkg::ERR_BAD_LENGTH;
    else if (op_pkt && !(d_pop == silicaflux_cloud_pkg::PROC_PASS || d_pop == silicaflux_cloud_pkg::PROC_XOR32 ||
                         d_pop == silicaflux_cloud_pkg::PROC_BSWAP32))  v_err = silicaflux_cloud_pkg::ERR_PROC_OP;
    else if (op_pkt && d_pop == silicaflux_cloud_pkg::PROC_BSWAP32 && d_len[1:0] != 2'b00)
                                                                        v_err = silicaflux_cloud_pkg::ERR_PROC_OP;
    else if (d_soff[DLG-1:0] != '0 || (op_rd && d_src[DLG-1:0] != '0) || (op_wr && d_dst[DLG-1:0] != '0))
                                                                        v_err = silicaflux_cloud_pkg::ERR_ALIGN;
    else if (sram_bad)                                                  v_err = silicaflux_cloud_pkg::ERR_SRAM_RANGE;
    else if (op_rd && !win_rd_ok) begin                                 v_err = silicaflux_cloud_pkg::ERR_PERM_READ;  v_faddr = d_src; end
    else if (op_wr && !win_wr_ok) begin                                 v_err = silicaflux_cloud_pkg::ERR_PERM_WRITE; v_faddr = d_dst; end
    else                                                                v_need_slot = 1'b1;
  end

  // ------------------------------------------------------------ free slot
  logic [NS-1:0]  free_slot;
  logic [SIW-1:0] free_idx;
  logic           have_free;
  always_comb begin
    have_free = 1'b0;
    free_idx  = '0;
    for (int s = 0; s < NS; s++) free_slot[s] = !inf_v_q[s] && !slot_busy[s];
    for (int s = NS - 1; s >= 0; s--) if (free_slot[s]) begin have_free = 1'b1; free_idx = s[SIW-1:0]; end
  end

  // ------------------------------------------------------------ completion sources (priority: DONE > TIMEOUT > ABORT > DECODE)
  logic          done_pick_v, to_pick_v, ab_pick_v, zomb_clear_v;
  logic [SIW-1:0] done_pick, to_pick, ab_pick, zomb_pick;
  always_comb begin
    done_pick_v = 1'b0;  done_pick = '0;
    to_pick_v   = 1'b0;  to_pick   = '0;
    ab_pick_v   = 1'b0;  ab_pick   = '0;
    zomb_clear_v = 1'b0; zomb_pick = '0;
    for (int s = NS - 1; s >= 0; s--) begin
      if (inf_v_q[s] && slot_done[s] && !zombie_q[s]) begin done_pick_v = 1'b1; done_pick = s[SIW-1:0]; end
      if (inf_v_q[s] && !slot_done[s] && !zombie_q[s] && (job_timeout != 32'd0) && (age_q[s] >= job_timeout) && (ps_q == P_RUN))
                                                                                            begin to_pick_v = 1'b1; to_pick = s[SIW-1:0]; end
      if (inf_v_q[s] && !slot_done[s] && !zombie_q[s] && (ps_q == P_RS_ABORT))               begin ab_pick_v = 1'b1; ab_pick = s[SIW-1:0]; end
      if (inf_v_q[s] && zombie_q[s] && !slot_done[s] && (ps_q == P_RS_ABORT))                begin zomb_clear_v = 1'b1; zomb_pick = s[SIW-1:0]; end
    end
  end
  // a late result of a zombie (its completion was already reported) is acknowledged and dropped
  logic          late_v;
  logic [SIW-1:0] late_pick;
  always_comb begin
    late_v = 1'b0; late_pick = '0;
    for (int s = NS - 1; s >= 0; s--) if (inf_v_q[s] && zombie_q[s] && slot_done[s]) begin late_v = 1'b1; late_pick = s[SIW-1:0]; end
  end

  localparam logic [1:0] K_NONE = 2'd0, K_DONE = 2'd1, K_TO = 2'd2, K_ABORT = 2'd3;
  logic [1:0]     pk;                                // chosen source for the slot-based completion
  logic [SIW-1:0] pk_s;
  always_comb begin
    pk = K_NONE;  pk_s = '0;
    if (done_pick_v)    begin pk = K_DONE;  pk_s = done_pick; end
    else if (to_pick_v) begin pk = K_TO;    pk_s = to_pick;   end
    else if (ab_pick_v) begin pk = K_ABORT; pk_s = ab_pick;   end
  end

  // action of the decode stage
  wire dec_possible = any_elig && run_ok;
  wire dec_reject   = dec_possible && (v_err != silicaflux_cloud_pkg::ERR_NONE);
  wire dec_nop      = dec_possible && v_nop;
  wire dec_disp     = dec_possible && v_need_slot && have_free;
  wire dec_cpl      = (dec_reject || dec_nop) && (pk == K_NONE);   // completion port free this cycle
  wire dec_go       = dec_cpl || dec_disp;
  assign act_done   = dec_go;
  assign ev_stall   = dec_possible && !dec_go;

  always_comb begin
    h_pop = '0;
    if (dec_go) h_pop[sel] = 1'b1;
  end

  // ------------------------------------------------------------ completion record assembly
  /* verilator lint_off UNUSEDSIGNAL */          // the completion uses a subset of the transaction bundle
  logic [TXNW-1:0] s_txn;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [7:0]      s_err;
  logic [3:0]      s_status;
  logic            s_commit_ok;
  logic [31:0]     s_bytes, s_crc_in, s_crc_out;
  logic [15:0]     s_csum;
  logic [63:0]     s_faddr;
  logic [7:0]      s_op;
  always_comb begin
    s_txn      = inf_txn_q[pk_s];
    s_op       = s_txn[silicaflux_cloud_pkg::TXN_OPCODE_LSB +: 8];
    s_err      = slot_err[pk_s*8 +: 8];
    s_bytes    = slot_bytes[pk_s*32 +: 32];
    s_crc_in   = slot_crc_in[pk_s*32 +: 32];
    s_crc_out  = slot_crc_out[pk_s*32 +: 32];
    s_csum     = slot_csum[pk_s*16 +: 16];
    s_faddr    = slot_faddr[pk_s*64 +: 64];
    s_commit_ok = slot_commit[pk_s];
    if (pk == K_TO) begin
      s_err = silicaflux_cloud_pkg::ERR_TIMEOUT;  s_bytes = 32'd0;  s_crc_in = 32'd0;  s_crc_out = 32'd0;  s_csum = 16'd0;
      s_commit_ok = 1'b0;
    end else if (pk == K_ABORT) begin
      s_err = silicaflux_cloud_pkg::ERR_RESET_ABORT;  s_bytes = 32'd0;  s_crc_in = 32'd0;  s_crc_out = 32'd0;  s_csum = 16'd0;
      s_commit_ok = 1'b0;
    end else begin
      // the commit rule: success is impossible without the commit flag for operations that write host memory
      if (s_err == silicaflux_cloud_pkg::ERR_NONE && silicaflux_cloud_pkg::op_writes_host(s_op) && !s_commit_ok)
        s_err = silicaflux_cloud_pkg::ERR_INTERNAL;
    end
    s_status = (pk == K_ABORT) ? silicaflux_cloud_pkg::ST_ABORTED :
               (s_err == silicaflux_cloud_pkg::ERR_NONE) ? silicaflux_cloud_pkg::ST_OK : silicaflux_cloud_pkg::ST_ERROR;
  end

  // decode-time completion (reject / NOP)
  wire [7:0] r_err   = dec_nop ? silicaflux_cloud_pkg::ERR_NONE : v_err;
  wire [3:0] r_status = (r_err == silicaflux_cloud_pkg::ERR_NONE) ? silicaflux_cloud_pkg::ST_OK : silicaflux_cloud_pkg::ST_ERROR;

  logic [CPLW-1:0] cpl_s, cpl_d;
  always_comb begin
    cpl_s = '0;
    cpl_s[silicaflux_cloud_pkg::CPL_OPCODE_LSB +: 8]  = s_op;
    cpl_s[silicaflux_cloud_pkg::CPL_STATUS_LSB +: 8]  = {4'd0, s_status};
    cpl_s[silicaflux_cloud_pkg::CPL_ERR_LSB +: 8]     = s_err;
    cpl_s[silicaflux_cloud_pkg::CPL_TENANT_LSB +: 4]  = s_txn[silicaflux_cloud_pkg::TXN_TENANT_LSB +: 4];
    cpl_s[silicaflux_cloud_pkg::CPL_QUEUE_LSB +: 4]   = s_txn[silicaflux_cloud_pkg::TXN_QUEUE_LSB +: 4];
    cpl_s[silicaflux_cloud_pkg::CPL_TAG_LSB +: 32]    = s_txn[silicaflux_cloud_pkg::TXN_TAG_LSB +: 32];
    cpl_s[silicaflux_cloud_pkg::CPL_TXN_LSB +: 16]    = s_txn[silicaflux_cloud_pkg::TXN_ID_LSB +: 16];
    cpl_s[silicaflux_cloud_pkg::CPL_FLAGS_LSB + silicaflux_cloud_pkg::CPL_FLAG_COMMITTED] = (s_err == silicaflux_cloud_pkg::ERR_NONE) && s_commit_ok;
    cpl_s[silicaflux_cloud_pkg::CPL_BYTES_LSB +: 32]  = s_bytes;
    cpl_s[silicaflux_cloud_pkg::CPL_CRC_IN_LSB +: 32] = s_crc_in;
    cpl_s[silicaflux_cloud_pkg::CPL_CRC_OUT_LSB +: 32] = s_crc_out;
    cpl_s[silicaflux_cloud_pkg::CPL_CSUM_LSB +: 16]   = s_csum;
    cpl_s[silicaflux_cloud_pkg::CPL_TS_LSB +: 32]     = time_cnt;

    cpl_d = '0;
    cpl_d[silicaflux_cloud_pkg::CPL_OPCODE_LSB +: 8]  = d_op;
    cpl_d[silicaflux_cloud_pkg::CPL_STATUS_LSB +: 8]  = {4'd0, r_status};
    cpl_d[silicaflux_cloud_pkg::CPL_ERR_LSB +: 8]     = r_err;
    cpl_d[silicaflux_cloud_pkg::CPL_TENANT_LSB +: 4]  = ten;
    cpl_d[silicaflux_cloud_pkg::CPL_QUEUE_LSB +: 4]   = is_mgmt ? 4'(silicaflux_cloud_pkg::MGMT_QUEUE_ID) : 4'(sel);
    cpl_d[silicaflux_cloud_pkg::CPL_TAG_LSB +: 32]    = d_tag;
    cpl_d[silicaflux_cloud_pkg::CPL_TXN_LSB +: 16]    = txn_ctr_q;
    cpl_d[silicaflux_cloud_pkg::CPL_TS_LSB +: 32]     = time_cnt;
  end

  wire [3:0] s_queue_idx_ext = s_txn[silicaflux_cloud_pkg::TXN_QUEUE_LSB +: 4];
  wire [3:0] s_queue_int     = (s_queue_idx_ext == 4'(silicaflux_cloud_pkg::MGMT_QUEUE_ID)) ? 4'(NQH) : s_queue_idx_ext;

  always_comb begin
    c_push      = 1'b0;
    c_push_q    = 4'd0;
    c_push_data = '0;
    if (pk != K_NONE) begin
      c_push = 1'b1;  c_push_q = s_queue_int;  c_push_data = cpl_s;
    end else if (dec_cpl) begin
      c_push = 1'b1;  c_push_q = 4'(sel);      c_push_data = cpl_d;
    end
  end

  // ------------------------------------------------------------ events, violations, faults
  wire        ret_slot  = (pk != K_NONE);
  wire [7:0]  ret_err   = ret_slot ? s_err : r_err;
  wire [3:0]  ret_ten   = ret_slot ? s_txn[silicaflux_cloud_pkg::TXN_TENANT_LSB +: 4] : ten;
  assign ev_retire  = c_push;
  assign ev_ten     = ret_ten;
  assign ev_queue   = ret_slot ? s_txn[silicaflux_cloud_pkg::TXN_QUEUE_LSB +: 4] : (is_mgmt ? 4'(silicaflux_cloud_pkg::MGMT_QUEUE_ID) : 4'(sel));
  assign ev_err     = ret_err;
  assign ev_status  = ret_slot ? {4'd0, s_status} : {4'd0, r_status};
  assign ev_bytes   = ret_slot ? s_bytes : 32'd0;
  assign ev_blocked = c_push && (ret_err == silicaflux_cloud_pkg::ERR_BLOCKED);

  wire ret_viol = c_push && silicaflux_cloud_pkg::err_is_violation(ret_err);
  assign viol_evt    = ret_viol;
  assign viol_tenant = ret_ten;

  always_comb begin
    flt_set        = '0;
    flt_tenant     = ret_ten;
    flt_err        = ret_err;
    flt_addr       = ret_slot ? s_faddr : v_faddr;
    flt_addr_valid = 1'b0;
    if (c_push) begin
      if (silicaflux_cloud_pkg::err_is_violation(ret_err)) begin flt_set[silicaflux_cloud_pkg::FLT_PERM_VIOL] = 1'b1; flt_addr_valid = 1'b1; end
      if (ret_err == silicaflux_cloud_pkg::ERR_HOST_MEM)   flt_set[silicaflux_cloud_pkg::FLT_HOST_ERR] = 1'b1;
      if (ret_err == silicaflux_cloud_pkg::ERR_SRAM_RESP)  flt_set[silicaflux_cloud_pkg::FLT_SRAM_ERR] = 1'b1;
      if (ret_err == silicaflux_cloud_pkg::ERR_INTERNAL)   flt_set[silicaflux_cloud_pkg::FLT_INTERNAL] = 1'b1;
      if (ret_err == silicaflux_cloud_pkg::ERR_TIMEOUT)    flt_set[silicaflux_cloud_pkg::FLT_TIMEOUT]  = 1'b1;
      if (!ret_slot && (ret_err == silicaflux_cloud_pkg::ERR_BAD_DESC || ret_err == silicaflux_cloud_pkg::ERR_BAD_OPCODE ||
                        ret_err == silicaflux_cloud_pkg::ERR_BAD_LENGTH || ret_err == silicaflux_cloud_pkg::ERR_ALIGN ||
                        ret_err == silicaflux_cloud_pkg::ERR_PROC_OP || ret_err == silicaflux_cloud_pkg::ERR_BAD_TENANT))
        flt_set[silicaflux_cloud_pkg::FLT_DESC_ERR] = 1'b1;
    end
    if (ps_q == P_RS_DONE) flt_set[silicaflux_cloud_pkg::FLT_RESET_DONE] = 1'b1;
  end
  assign ev_dp_reset = (ps_q == P_RS_DONE);

  // ------------------------------------------------------------ slot control
  always_comb begin
    slot_start = '0;
    slot_ack   = '0;
    for (int s = 0; s < NS; s++) begin
      if (dec_disp && free_idx == s[SIW-1:0]) slot_start[s] = 1'b1;
      if (pk != K_NONE && pk_s == s[SIW-1:0] && (pk == K_DONE)) slot_ack[s] = 1'b1;
      if (late_v && late_pick == s[SIW-1:0]) slot_ack[s] = 1'b1;
    end
  end

  logic [TXNW-1:0] new_txn;
  always_comb begin
    new_txn = '0;
    new_txn[silicaflux_cloud_pkg::TXN_ID_LSB +: 16]      = txn_ctr_q;
    new_txn[silicaflux_cloud_pkg::TXN_SRC_LSB +: 4]      = is_mgmt ? silicaflux_cloud_pkg::EP_FW : silicaflux_cloud_pkg::EP_HOST;
    new_txn[silicaflux_cloud_pkg::TXN_DST_LSB +: 4]      = op_pkt ? silicaflux_cloud_pkg::EP_PACKET : silicaflux_cloud_pkg::EP_CLOUDDMA;
    new_txn[silicaflux_cloud_pkg::TXN_TENANT_LSB +: 4]   = ten;
    new_txn[silicaflux_cloud_pkg::TXN_QUEUE_LSB +: 4]    = is_mgmt ? 4'(silicaflux_cloud_pkg::MGMT_QUEUE_ID) : 4'(sel);
    new_txn[silicaflux_cloud_pkg::TXN_OPCODE_LSB +: 8]   = d_op;
    new_txn[silicaflux_cloud_pkg::TXN_PROC_OP_LSB +: 8]  = d_pop;
    new_txn[silicaflux_cloud_pkg::TXN_PERM_LSB +: 2]     = {op_wr, op_rd};
    new_txn[silicaflux_cloud_pkg::TXN_TAG_LSB +: 32]     = d_tag;
    new_txn[silicaflux_cloud_pkg::TXN_LEN_LSB +: 32]     = d_len;
    new_txn[silicaflux_cloud_pkg::TXN_SRAM_OFF_LSB +: 32] = d_soff;
    new_txn[silicaflux_cloud_pkg::TXN_PARAM_LSB +: 32]   = d_param;
    new_txn[silicaflux_cloud_pkg::TXN_ADDR_IN_LSB +: 64] = d_src;
    new_txn[silicaflux_cloud_pkg::TXN_ADDR_OUT_LSB +: 64] = d_dst;
  end
  always_comb begin
    for (int s = 0; s < NS; s++) slot_txn[s*TXNW +: TXNW] = new_txn;
  end

  // tenant index of a slot that is cleared outside a normal completion
  wire [TIW-1:0] late_ti = inf_txn_q[late_pick][silicaflux_cloud_pkg::TXN_TENANT_LSB +: TIW];
  wire [TIW-1:0] zomb_ti = inf_txn_q[zomb_pick][silicaflux_cloud_pkg::TXN_TENANT_LSB +: TIW];

  // per-tenant in-flight accounting: every increment/decrement of the same cycle is applied (no lost update)
  wire zomb_act = zomb_clear_v && (pk == K_NONE) && !ab_pick_v && (ps_q == P_RS_ABORT);
  logic [NT-1:0] t_inc;
  logic [1:0]    t_dec [NT];
  always_comb begin
    for (int t = 0; t < NT; t++) begin
      t_inc[t] = dec_disp && (ti == t[TIW-1:0]);
      t_dec[t] = 2'd0;
      if ((pk == K_DONE || pk == K_ABORT) && ret_ti == t[TIW-1:0]) t_dec[t] = t_dec[t] + 2'd1;
      if (late_v && late_ti == t[TIW-1:0])                         t_dec[t] = t_dec[t] + 2'd1;
      if (zomb_act && zomb_ti == t[TIW-1:0])                       t_dec[t] = t_dec[t] + 2'd1;
    end
  end

  // ------------------------------------------------------------ sequential
  wire [TIW-1:0] ret_ti = ret_ten[TIW-1:0];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ps_q <= P_RUN;  rs_cnt_q <= '0;  halted_q <= 1'b0;  txn_ctr_q <= '0;
      inf_v_q <= '0;  zombie_q <= '0;  dp_rst_n_q <= 1'b1;  rs_req_q <= 1'b0;
      for (int s = 0; s < NS; s++) begin inf_txn_q[s] <= '0; age_q[s] <= 32'd0; end
      for (int t = 0; t < NT; t++) tinf_q[t] <= 8'd0;
    end else begin
      if (dp_reset_req) rs_req_q <= 1'b1;

      // ---- tenant in-flight counters
      for (int t = 0; t < NT; t++) tinf_q[t] <= tinf_q[t] + {7'd0, t_inc[t]} - {6'd0, t_dec[t]};

      // ---- job ages
      for (int s = 0; s < NS; s++) if (inf_v_q[s] && !slot_done[s] && age_q[s] != 32'hFFFF_FFFF) age_q[s] <= age_q[s] + 32'd1;

      // ---- dispatch
      if (dec_disp) begin
        inf_v_q[free_idx]    <= 1'b1;
        zombie_q[free_idx]   <= 1'b0;
        inf_txn_q[free_idx]  <= new_txn;
        age_q[free_idx]      <= 32'd0;
        txn_ctr_q            <= txn_ctr_q + 16'd1;
      end else if (dec_cpl) begin
        txn_ctr_q            <= txn_ctr_q + 16'd1;       // every accepted descriptor gets its own transaction id
      end

      // ---- slot-result completions
      if (pk == K_DONE) inf_v_q[pk_s] <= 1'b0;
      if (pk == K_TO) begin
        zombie_q[pk_s] <= 1'b1;                                   // slot stays counted as in flight
        halted_q       <= 1'b1;
      end
      if (late_v) begin                                           // late result of a timed-out job: drop it, free the slot
        inf_v_q[late_pick]  <= 1'b0;
        zombie_q[late_pick] <= 1'b0;
      end

      // ---- reset sequence
      case (ps_q)
        P_RUN: begin
          if (rs_req_q) begin ps_q <= P_RS_ABORT; rs_req_q <= 1'b0; end
        end
        P_RS_ABORT: begin
          if (pk == K_ABORT) inf_v_q[pk_s] <= 1'b0;
          if (zomb_act) begin                                       // a timed-out job: its completion was already reported
            inf_v_q[zomb_pick]  <= 1'b0;
            zombie_q[zomb_pick] <= 1'b0;
          end
          if (!(|inf_v_q)) begin ps_q <= P_RS_ASSERT; rs_cnt_q <= 3'd4; dp_rst_n_q <= 1'b0; end
        end
        P_RS_ASSERT: begin
          if (rs_cnt_q == 3'd0) begin dp_rst_n_q <= 1'b1; ps_q <= P_RS_DONE; end
          else rs_cnt_q <= rs_cnt_q - 3'd1;
        end
        P_RS_DONE: begin
          halted_q <= 1'b0;
          zombie_q <= '0;
          ps_q     <= P_RUN;
        end
        default: ps_q <= P_RUN;
      endcase
    end
  end

  wire unused_ok = &{1'b0, d_flags[0]};
endmodule

`default_nettype wire
