// =============================================================================
// CloudDPU :: sfd_hm_port -- the DPU's host-memory port (SFB2 master) with reset-safe response tracking
//
// A data-plane reset throws away the requesters, but host memory still owes a response to a request that was
// accepted before the reset.  This block remembers that one request is outstanding; if the data plane is reset
// while it is, the late response is ORPHANED: it is swallowed (never delivered to the new owner of the port) and
// no new request is issued until it has arrived.  Without this, a stale response would corrupt the first
// transfer after the reset.  If the host never answers, the port stays blocked (the DPU reports it in
// DEBUG.HOSTPORT) - a host that drops a response needs a host-initiated reset.
// Persistent reset domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_hm_port #(
  parameter int AW = 32,
  parameter int DW = 32
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            dp_resetting,
  // fabric side (slave view)
  input  wire logic            s_req_valid,
  output logic                 s_req_ready,
  input  wire logic            s_req_write,
  input  wire logic [AW-1:0]   s_req_addr,
  input  wire logic [DW-1:0]   s_req_wdata,
  input  wire logic [DW/8-1:0] s_req_wstrb,
  output logic                 s_rsp_valid,
  input  wire logic            s_rsp_ready,
  output logic [DW-1:0]        s_rsp_rdata,
  output logic                 s_rsp_error,
  // external host memory (master view)
  output logic                 hm_req_valid,
  input  wire logic            hm_req_ready,
  output logic                 hm_req_write,
  output logic [AW-1:0]        hm_req_addr,
  output logic [DW-1:0]        hm_req_wdata,
  output logic [DW/8-1:0]      hm_req_wstrb,
  input  wire logic            hm_rsp_valid,
  output logic                 hm_rsp_ready,
  input  wire logic [DW-1:0]   hm_rsp_rdata,
  input  wire logic            hm_rsp_error,
  // status
  output logic                 out_o,
  output logic                 orphan_o
);
  logic out_q, orphan_q;
  assign hm_req_valid = s_req_valid && !orphan_q && !dp_resetting;
  assign hm_req_write = s_req_write;
  assign hm_req_addr  = s_req_addr;
  assign hm_req_wdata = s_req_wdata;
  assign hm_req_wstrb = s_req_wstrb;
  assign s_req_ready  = hm_req_ready && !orphan_q && !dp_resetting;

  assign s_rsp_valid  = hm_rsp_valid && !orphan_q;
  assign s_rsp_rdata  = hm_rsp_rdata;
  assign s_rsp_error  = hm_rsp_error;
  assign hm_rsp_ready = orphan_q ? 1'b1 : s_rsp_ready;
  assign out_o        = out_q;
  assign orphan_o     = orphan_q;

  wire rsp_taken = hm_rsp_valid && hm_rsp_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_q <= 1'b0;  orphan_q <= 1'b0;
    end else begin
      if (hm_req_valid && hm_req_ready) out_q <= 1'b1;
      if (rsp_taken) begin out_q <= 1'b0; orphan_q <= 1'b0; end
      if (dp_resetting && out_q && !rsp_taken) orphan_q <= 1'b1;
    end
  end
endmodule

`default_nettype wire
