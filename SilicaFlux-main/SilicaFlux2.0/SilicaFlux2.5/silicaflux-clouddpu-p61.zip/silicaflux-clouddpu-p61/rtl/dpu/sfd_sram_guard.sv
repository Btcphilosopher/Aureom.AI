// =============================================================================
// CloudDPU :: sfd_sram_guard -- per-beat SRAM OWNERSHIP enforcement
//
// Every beat that CloudDMA or PacketCore presents to the local SRAM must fall inside the SRAM
// partition owned by the tenant of the running job.  Same structure and rationale as sfd_host_guard.
// The management port and the scrubber are trusted masters and do not pass through a guard.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_sram_guard #(
  parameter int DW = 32
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            m_req_valid,
  output logic                 m_req_ready,
  input  wire logic            m_req_write,
  input  wire logic [31:0]     m_req_addr,
  input  wire logic [DW-1:0]   m_req_wdata,
  input  wire logic [DW/8-1:0] m_req_wstrb,
  output logic                 m_rsp_valid,
  input  wire logic            m_rsp_ready,
  output logic [DW-1:0]        m_rsp_rdata,
  output logic                 m_rsp_error,
  output logic                 s_req_valid,
  input  wire logic            s_req_ready,
  output logic                 s_req_write,
  output logic [31:0]          s_req_addr,
  output logic [DW-1:0]        s_req_wdata,
  output logic [DW/8-1:0]      s_req_wstrb,
  input  wire logic            s_rsp_valid,
  output logic                 s_rsp_ready,
  input  wire logic [DW-1:0]   s_rsp_rdata,
  input  wire logic            s_rsp_error,
  input  wire logic            job_active,
  input  wire logic [31:0]     part_base,
  input  wire logic [31:0]     part_size,
  output logic                 allow_o,
  output logic                 viol_evt
);
  localparam logic [31:0] DWB32 = DW / 8;
  wire [32:0] a_end = {1'b0, m_req_addr} + {1'b0, DWB32};
  wire [32:0] p_end = {1'b0, part_base} + {1'b0, part_size};
  wire allow = job_active && (part_size != 32'd0) && (m_req_addr >= part_base) && (a_end <= p_end);
  assign allow_o = allow;

  sfd_sfb_gate #(.AW(32), .DW(DW)) u_gate (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .allow, .blk_evt(viol_evt)
  );
endmodule

`default_nettype wire
