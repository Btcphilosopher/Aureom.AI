// =============================================================================
// CloudDPU :: sfd_job_slot -- one execution context = one CloudDMA channel + its sequencer
//
//   OP_PKT_PROCESS   H2D (host in-buffer -> SRAM) -> PacketCore job (SRAM in -> SRAM out) -> D2H (SRAM out -> host)
//   OP_DMA_H2D       H2D only
//   OP_DMA_D2H       D2H of the SRAM staging buffer
// The slot reports a result only after the LAST step finished; `done_commit` is the CloudDMA commit flag
// of the final D2H (all output beats acknowledged by the destination).  Results are held (done_valid
// level) until the command processor acknowledges them, so no result is ever lost.
//
// ENFORCEMENT.  The slot's two memory ports leave through sfd_host_guard (host windows of the job's
// tenant, per beat) and sfd_sram_guard (the tenant's SRAM partition, per beat).  Both guards read the LIVE
// tenant context arrays, not a copy handed over by the command processor.
//
// Local SRAM layout of a job (tenant partition-relative offsets become absolute here):
//   in  buffer  [base + sram_off,               + len_al)
//   out buffer  [base + sram_off + len_al,      + len_al)      (PKT_PROCESS only)      len_al = len rounded up to a beat
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_job_slot #(
  parameter int DW = 32,
  parameter int AW = 32,
  parameter int NT = 1,
  parameter int NW = 2
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // dispatch (one-cycle pulse while !busy)
  input  wire logic            start,
  /* verilator lint_off UNUSEDSIGNAL */          // the slot uses a subset of the transaction bundle
  input  wire logic [silicaflux_cloud_pkg::TXN_W-1:0] start_txn,
  /* verilator lint_on UNUSEDSIGNAL */
  // result
  output logic                 done_valid,
  input  wire logic            done_ack,
  output logic [7:0]           done_err,
  output logic [31:0]          done_bytes,
  output logic                 done_commit,
  output logic [31:0]          done_crc_in,
  output logic [31:0]          done_crc_out,
  output logic [15:0]          done_csum,
  output logic [63:0]          done_fault_addr,
  output logic                 busy,
  output logic [3:0]           fsm_o,
  output logic [3:0]           tenant_o,
  // live tenant context (flat)
  input  wire logic [NT-1:0]        t_cfg_ok,
  input  wire logic [NT*32-1:0]     t_part_base,
  input  wire logic [NT*32-1:0]     t_part_size,
  input  wire logic [NT*NW*64-1:0]  t_win_base,
  input  wire logic [NT*NW*32-1:0]  t_win_size,
  input  wire logic [NT*NW-1:0]     t_win_valid,
  input  wire logic [NT*NW*2-1:0]   t_win_perm,
  // host memory master (guarded)
  output logic                 hm_req_valid,
  input  wire logic            hm_req_ready,
  output logic                 hm_req_write,
  output logic [AW-1:0]        hm_req_addr,
  output logic [DW-1:0]        hm_req_wdata,
  output logic [DW/8-1:0]      hm_req_wstrb,
  input  wire logic            hm_rsp_valid,
  output logic                 hm_rsp_ready,
  input  wire logic [DW-1:0]   hm_rsp_rdata,
  input  wire logic            hm_rsp_error,
  // SRAM master (guarded)
  output logic                 sm_req_valid,
  input  wire logic            sm_req_ready,
  output logic                 sm_req_write,
  output logic [31:0]          sm_req_addr,
  output logic [DW-1:0]        sm_req_wdata,
  output logic [DW/8-1:0]      sm_req_wstrb,
  input  wire logic            sm_rsp_valid,
  output logic                 sm_rsp_ready,
  input  wire logic [DW-1:0]   sm_rsp_rdata,
  input  wire logic            sm_rsp_error,
  // PacketCore hub
  output logic                 pkt_req,
  output logic [31:0]          pkt_in,
  output logic [31:0]          pkt_out,
  output logic [31:0]          pkt_len,
  output logic [7:0]           pkt_op,
  output logic [31:0]          pkt_param,
  output logic [3:0]           pkt_tenant,
  input  wire logic            pkt_ack,
  input  wire logic            pkt_res_valid,
  input  wire logic [7:0]      pkt_res_err,
  input  wire logic [31:0]     pkt_res_crc_in,
  input  wire logic [31:0]     pkt_res_crc_out,
  input  wire logic [15:0]     pkt_res_csum,
  // events
  output logic                 ev_h2d_beat,
  output logic                 ev_d2h_beat,
  output logic [7:0]           ev_beat_bytes,
  output logic                 ev_guard_trip
);
  localparam int DWB = DW / 8;
  localparam logic [31:0] DWB32 = DWB;
  localparam int TIW = (NT > 1) ? $clog2(NT) : 1;

  localparam logic [3:0] L_IDLE = 4'd0, L_H2D_CMD = 4'd1, L_H2D_WAIT = 4'd2, L_PROC_REQ = 4'd3, L_PROC_WAIT = 4'd4,
                         L_D2H_CMD = 4'd5, L_D2H_WAIT = 4'd6, L_DONE = 4'd7;

  logic [3:0]  st_q;
  logic [3:0]  ten_q;
  logic [7:0]  op_q, pop_q, err_q;
  logic [31:0] len_q, param_q, in_abs_q, out_abs_q;
  logic [AW-1:0] src_q, dst_q;
  logic        commit_q;
  logic [31:0] bytes_q, crc_in_q, crc_out_q;
  logic [15:0] csum_q;
  logic [63:0] fault_addr_q;

  wire [TIW-1:0] ti = ten_q[TIW-1:0];
  wire [3:0]     t_in = start_txn[silicaflux_cloud_pkg::TXN_TENANT_LSB +: 4];

  // ------------------------------------------------------------ DMA channel
  logic        dma_cmd_valid, dma_cmd_ready, dma_cmd_dir;
  logic [AW-1:0] dma_haddr;
  logic [31:0] dma_saddr, dma_len;
  logic        dma_done_valid, dma_done_commit, dma_busy;
  logic [7:0]  dma_done_err;
  logic [31:0] dma_done_bytes;

  logic                 dh_req_valid, dh_req_ready, dh_req_write, dh_rsp_valid, dh_rsp_ready, dh_rsp_error;
  logic [AW-1:0]        dh_req_addr;
  logic [DW-1:0]        dh_req_wdata, dh_rsp_rdata;
  logic [DW/8-1:0]      dh_req_wstrb;
  logic                 ds_req_valid, ds_req_ready, ds_req_write, ds_rsp_valid, ds_rsp_ready, ds_rsp_error;
  logic [31:0]          ds_req_addr;
  logic [DW-1:0]        ds_req_wdata, ds_rsp_rdata;
  logic [DW/8-1:0]      ds_req_wstrb;
  logic                 h_viol, s_viol;
  logic [AW-1:0]        h_viol_addr;
  logic                 h_allow_unused, s_allow_unused;

  sfd_clouddma #(.DW(DW), .AW(AW)) u_dma (
    .clk, .rst_n,
    .cmd_valid(dma_cmd_valid), .cmd_ready(dma_cmd_ready), .cmd_dir(dma_cmd_dir),
    .cmd_haddr(dma_haddr), .cmd_saddr(dma_saddr), .cmd_len(dma_len),
    .done_valid(dma_done_valid), .done_err(dma_done_err), .done_bytes(dma_done_bytes), .done_commit(dma_done_commit),
    .busy(dma_busy),
    .hm_req_valid(dh_req_valid), .hm_req_ready(dh_req_ready), .hm_req_write(dh_req_write), .hm_req_addr(dh_req_addr),
    .hm_req_wdata(dh_req_wdata), .hm_req_wstrb(dh_req_wstrb),
    .hm_rsp_valid(dh_rsp_valid), .hm_rsp_ready(dh_rsp_ready), .hm_rsp_rdata(dh_rsp_rdata), .hm_rsp_error(dh_rsp_error),
    .sm_req_valid(ds_req_valid), .sm_req_ready(ds_req_ready), .sm_req_write(ds_req_write), .sm_req_addr(ds_req_addr),
    .sm_req_wdata(ds_req_wdata), .sm_req_wstrb(ds_req_wstrb),
    .sm_rsp_valid(ds_rsp_valid), .sm_rsp_ready(ds_rsp_ready), .sm_rsp_rdata(ds_rsp_rdata), .sm_rsp_error(ds_rsp_error),
    .g_viol(h_viol || s_viol),
    .ev_h2d_beat, .ev_d2h_beat, .ev_beat_bytes
  );

  // ------------------------------------------------------------ guards (live tenant context)
  wire job_on = (st_q != L_IDLE) && (st_q != L_DONE) && t_cfg_ok[ti];

  sfd_host_guard #(.AW(AW), .DW(DW), .NW(NW)) u_hguard (
    .clk, .rst_n,
    .m_req_valid(dh_req_valid), .m_req_ready(dh_req_ready), .m_req_write(dh_req_write), .m_req_addr(dh_req_addr),
    .m_req_wdata(dh_req_wdata), .m_req_wstrb(dh_req_wstrb),
    .m_rsp_valid(dh_rsp_valid), .m_rsp_ready(dh_rsp_ready), .m_rsp_rdata(dh_rsp_rdata), .m_rsp_error(dh_rsp_error),
    .s_req_valid(hm_req_valid), .s_req_ready(hm_req_ready), .s_req_write(hm_req_write), .s_req_addr(hm_req_addr),
    .s_req_wdata(hm_req_wdata), .s_req_wstrb(hm_req_wstrb),
    .s_rsp_valid(hm_rsp_valid), .s_rsp_ready(hm_rsp_ready), .s_rsp_rdata(hm_rsp_rdata), .s_rsp_error(hm_rsp_error),
    .job_active(job_on),
    .win_base(t_win_base[ti*NW*64 +: NW*64]), .win_size(t_win_size[ti*NW*32 +: NW*32]),
    .win_valid(t_win_valid[ti*NW +: NW]), .win_perm(t_win_perm[ti*NW*2 +: NW*2]),
    .allow_o(h_allow_unused), .viol_evt(h_viol), .viol_addr(h_viol_addr)
  );
  sfd_sram_guard #(.DW(DW)) u_sguard (
    .clk, .rst_n,
    .m_req_valid(ds_req_valid), .m_req_ready(ds_req_ready), .m_req_write(ds_req_write), .m_req_addr(ds_req_addr),
    .m_req_wdata(ds_req_wdata), .m_req_wstrb(ds_req_wstrb),
    .m_rsp_valid(ds_rsp_valid), .m_rsp_ready(ds_rsp_ready), .m_rsp_rdata(ds_rsp_rdata), .m_rsp_error(ds_rsp_error),
    .s_req_valid(sm_req_valid), .s_req_ready(sm_req_ready), .s_req_write(sm_req_write), .s_req_addr(sm_req_addr),
    .s_req_wdata(sm_req_wdata), .s_req_wstrb(sm_req_wstrb),
    .s_rsp_valid(sm_rsp_valid), .s_rsp_ready(sm_rsp_ready), .s_rsp_rdata(sm_rsp_rdata), .s_rsp_error(sm_rsp_error),
    .job_active(job_on), .part_base(t_part_base[ti*32 +: 32]), .part_size(t_part_size[ti*32 +: 32]),
    .allow_o(s_allow_unused), .viol_evt(s_viol)
  );
  assign ev_guard_trip = h_viol || s_viol;

  // ------------------------------------------------------------ outputs
  assign busy            = (st_q != L_IDLE);
  assign fsm_o           = st_q;
  assign tenant_o        = ten_q;
  assign done_valid      = (st_q == L_DONE);
  assign done_err        = err_q;
  assign done_bytes      = bytes_q;
  assign done_commit     = commit_q;
  assign done_crc_in     = crc_in_q;
  assign done_crc_out    = crc_out_q;
  assign done_csum       = csum_q;
  assign done_fault_addr = fault_addr_q;

  assign dma_cmd_valid = (st_q == L_H2D_CMD) || (st_q == L_D2H_CMD);
  assign dma_cmd_dir   = (st_q == L_D2H_CMD);
  assign dma_haddr     = (st_q == L_D2H_CMD) ? dst_q : src_q;
  assign dma_saddr     = (st_q == L_D2H_CMD) ? ((op_q == silicaflux_cloud_pkg::OP_PKT_PROCESS) ? out_abs_q : in_abs_q) : in_abs_q;
  assign dma_len       = len_q;

  assign pkt_req    = (st_q == L_PROC_REQ);
  assign pkt_in     = in_abs_q;
  assign pkt_out    = out_abs_q;
  assign pkt_len    = len_q;
  assign pkt_op     = pop_q;
  assign pkt_param  = param_q;
  assign pkt_tenant = ten_q;

  wire [31:0] len_al = (start_txn[silicaflux_cloud_pkg::TXN_LEN_LSB +: 32] + DWB32 - 32'd1) & ~(DWB32 - 32'd1);
  wire [TIW-1:0] ti_in = t_in[TIW-1:0];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= L_IDLE;  ten_q <= '0;  op_q <= '0;  pop_q <= '0;  err_q <= silicaflux_cloud_pkg::ERR_NONE;
      len_q <= '0;  param_q <= '0;  in_abs_q <= '0;  out_abs_q <= '0;  src_q <= '0;  dst_q <= '0;
      commit_q <= 1'b0;  bytes_q <= '0;  crc_in_q <= '0;  crc_out_q <= '0;  csum_q <= '0;  fault_addr_q <= '0;
    end else begin
      if (h_viol) fault_addr_q <= {{(64-AW){1'b0}}, h_viol_addr};
      case (st_q)
        L_IDLE: begin
          if (start) begin
            ten_q     <= t_in;
            op_q      <= start_txn[silicaflux_cloud_pkg::TXN_OPCODE_LSB +: 8];
            pop_q     <= start_txn[silicaflux_cloud_pkg::TXN_PROC_OP_LSB +: 8];
            param_q   <= start_txn[silicaflux_cloud_pkg::TXN_PARAM_LSB +: 32];
            len_q     <= start_txn[silicaflux_cloud_pkg::TXN_LEN_LSB +: 32];
            src_q     <= start_txn[silicaflux_cloud_pkg::TXN_ADDR_IN_LSB +: AW];
            dst_q     <= start_txn[silicaflux_cloud_pkg::TXN_ADDR_OUT_LSB +: AW];
            in_abs_q  <= t_part_base[ti_in*32 +: 32] + start_txn[silicaflux_cloud_pkg::TXN_SRAM_OFF_LSB +: 32];
            out_abs_q <= t_part_base[ti_in*32 +: 32] + start_txn[silicaflux_cloud_pkg::TXN_SRAM_OFF_LSB +: 32] + len_al;
            err_q     <= silicaflux_cloud_pkg::ERR_NONE;
            commit_q  <= 1'b0;
            bytes_q   <= 32'd0;
            crc_in_q  <= 32'd0;
            crc_out_q <= 32'd0;
            csum_q    <= 16'd0;
            fault_addr_q <= 64'd0;
            if (silicaflux_cloud_pkg::op_reads_host(start_txn[silicaflux_cloud_pkg::TXN_OPCODE_LSB +: 8])) st_q <= L_H2D_CMD;
            else                                                                                          st_q <= L_D2H_CMD;
          end
        end
        // ---- load
        L_H2D_CMD: if (dma_cmd_ready) st_q <= L_H2D_WAIT;
        L_H2D_WAIT: begin
          if (dma_done_valid) begin
            if (dma_done_err != silicaflux_cloud_pkg::ERR_NONE) begin err_q <= dma_done_err; st_q <= L_DONE; end
            else if (op_q == silicaflux_cloud_pkg::OP_PKT_PROCESS) st_q <= L_PROC_REQ;
            else begin bytes_q <= dma_done_bytes; st_q <= L_DONE; end
          end
        end
        // ---- PacketCore
        L_PROC_REQ: if (pkt_ack) st_q <= L_PROC_WAIT;
        L_PROC_WAIT: begin
          if (pkt_res_valid) begin
            if (pkt_res_err != silicaflux_cloud_pkg::ERR_NONE) begin err_q <= pkt_res_err; st_q <= L_DONE; end
            else begin
              crc_in_q  <= pkt_res_crc_in;
              crc_out_q <= pkt_res_crc_out;
              csum_q    <= pkt_res_csum;
              st_q      <= L_D2H_CMD;
            end
          end
        end
        // ---- store
        L_D2H_CMD: if (dma_cmd_ready) st_q <= L_D2H_WAIT;
        L_D2H_WAIT: begin
          if (dma_done_valid) begin
            if (dma_done_err != silicaflux_cloud_pkg::ERR_NONE) err_q <= dma_done_err;
            else begin bytes_q <= dma_done_bytes; commit_q <= dma_done_commit; end
            st_q <= L_DONE;
          end
        end
        L_DONE: if (done_ack) st_q <= L_IDLE;
        default: begin err_q <= silicaflux_cloud_pkg::ERR_INTERNAL; st_q <= L_DONE; end
      endcase
    end
  end

  wire unused_ok = &{1'b0, dma_busy, h_allow_unused, s_allow_unused};
endmodule

`default_nettype wire
