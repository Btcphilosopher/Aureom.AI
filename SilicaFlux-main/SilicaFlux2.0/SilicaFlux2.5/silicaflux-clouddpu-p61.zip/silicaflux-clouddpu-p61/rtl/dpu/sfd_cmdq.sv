// =============================================================================
// CloudDPU :: sfd_cmdq -- command queues and completion queues
//
//   host queues 0..NQH-1   physically separate submission FIFO (CMD_W bits x QD) and completion FIFO
//                          (CPL_W bits x CD) per queue.  Queue id q < NNQ is a NETWORK queue, the rest are
//                          COMPUTE queues.  Each queue is hard-wired to ONE tenant through the BIND register
//                          (management only, changeable only while the queue is empty and idle).  The tenant
//                          that counts is the queue's binding, never the field inside the descriptor.
//   management queue (id 15, internal index NQH)   fed by the M_DESC/M_SUBMIT registers (firmware), completion
//                          records readable through the MGMT_CQ page.  Trusted: it may name any tenant.
//
// COMPLETION CREDITS.  Popping a descriptor from a submission queue reserves a slot in that queue's completion
// FIFO (credit).  A completion therefore ALWAYS finds room: it is never dropped and never blocks the command
// processor.  A queue with no credit is simply not scheduled (back-pressure towards that tenant only).
// A completion of tenant A lives in A's completion FIFO and nowhere else: tenant B cannot read it.
//
// Register pages: region 2 (queue table + management submit) and region 3 (management completion queue).
// Persistent reset domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_cmdq #(
  parameter int NQH = 2,           // host queues (network + compute), 1..15
  parameter int NNQ = 1,           // of which network queues (the first NNQ)
  parameter int QD  = 4,           // submission FIFO depth
  parameter int CD  = 4,           // completion FIFO depth
  parameter int NT  = 1            // tenants (default binding q % NT)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // register pages
  input  wire logic            rb2_sel,
  input  wire logic            rb3_sel,
  input  wire logic            rb_we,
  input  wire logic [11:0]     rb_addr,
  input  wire logic [31:0]     rb_wdata,
  output logic [31:0]          rb2_rdata,
  output logic                 rb2_err,
  output logic [31:0]          rb3_rdata,
  output logic                 rb3_err,
  // host submission
  input  wire logic            sub_valid,
  output logic                 sub_ready,
  input  wire logic [3:0]      sub_q,
  input  wire logic [silicaflux_cloud_pkg::CMD_W-1:0] sub_cmd,
  // host completions (one port per host queue)
  output logic [NQH-1:0]       cpl_valid,
  input  wire logic [NQH-1:0]  cpl_ready,
  output logic [NQH*silicaflux_cloud_pkg::CPL_W-1:0] cpl_data,
  // command processor side
  output logic [NQH:0]         h_valid,
  output logic [(NQH+1)*silicaflux_cloud_pkg::CMD_W-1:0] h_cmd,
  input  wire logic [NQH:0]    h_pop,
  output logic [NQH:0]         h_credit,
  output logic [(NQH+1)*4-1:0] q_tenant,
  output logic [NQH:0]         q_compute,
  input  wire logic            c_push,
  input  wire logic [3:0]      c_push_q,            // internal index (NQH = management)
  input  wire logic [silicaflux_cloud_pkg::CPL_W-1:0] c_push_data,
  // status / events
  output logic [7:0]           q_total,             // descriptors waiting in all submission queues
  output logic                 mgmt_cq_nonempty,
  output logic [NQH:0]         ev_sub,
  output logic                 ev_bad_q,
  output logic                 ev_cq_overflow
);
  localparam int NQT = NQH + 1;
  localparam int QIW = (NQT > 1) ? $clog2(NQT) : 1;
  localparam int CMDW = silicaflux_cloud_pkg::CMD_W;
  localparam int CPLW = silicaflux_cloud_pkg::CPL_W;
  localparam int LW   = $clog2(((QD > CD) ? QD : CD) + 1);

  // ------------------------------------------------------------ FIFOs
  logic [NQT-1:0]       sq_in_valid, sq_in_ready, sq_out_valid;
  logic [NQT*CMDW-1:0]  sq_out_data;
  logic [NQT*LW-1:0]    sq_level;
  logic [NQT-1:0]       cq_in_valid, cq_in_ready, cq_out_valid, cq_out_ready;
  logic [NQT*CPLW-1:0]  cq_out_data;
  logic [NQT*LW-1:0]    cq_level;
  logic [CMDW-1:0]      mdesc_vec;
  logic [31:0]          mdesc_q [12];
  logic                 msub_valid;

  genvar gq;
  generate
    for (gq = 0; gq < NQT; gq++) begin : g_q
      logic [CMDW-1:0] sq_data_in;
      logic [LW-1:0]   sq_lvl_w, cq_lvl_w;
      if (gq < NQH) begin : g_host
        assign sq_in_valid[gq] = sub_valid && (sub_q == gq[3:0]);
        assign sq_data_in      = sub_cmd;
      end else begin : g_mgmt
        assign sq_in_valid[gq] = msub_valid;
        assign sq_data_in      = mdesc_vec;
      end
      sfd_fifo #(.WIDTH(CMDW), .DEPTH(QD)) u_sq (
        .clk, .rst_n, .flush(1'b0),
        .in_valid(sq_in_valid[gq]), .in_ready(sq_in_ready[gq]), .in_data(sq_data_in),
        .out_valid(sq_out_valid[gq]), .out_ready(h_pop[gq]), .out_data(sq_out_data[gq*CMDW +: CMDW]),
        .level(sq_lvl_w[$clog2(QD+1)-1:0])
      );
      if (LW > $clog2(QD+1)) begin : g_sqpad
        assign sq_lvl_w[LW-1:$clog2(QD+1)] = '0;
      end
      assign sq_level[gq*LW +: LW] = sq_lvl_w;
      sfd_fifo #(.WIDTH(CPLW), .DEPTH(CD)) u_cq (
        .clk, .rst_n, .flush(1'b0),
        .in_valid(cq_in_valid[gq]), .in_ready(cq_in_ready[gq]), .in_data(c_push_data),
        .out_valid(cq_out_valid[gq]), .out_ready(cq_out_ready[gq]), .out_data(cq_out_data[gq*CPLW +: CPLW]),
        .level(cq_lvl_w[$clog2(CD+1)-1:0])
      );
      if (LW > $clog2(CD+1)) begin : g_cqpad
        assign cq_lvl_w[LW-1:$clog2(CD+1)] = '0;
      end
      assign cq_level[gq*LW +: LW] = cq_lvl_w;
      assign cq_in_valid[gq] = c_push && (c_push_q == gq[3:0]);
    end
  endgenerate

  // host-visible completion ports (queue q) and management completion pop
  logic mgmt_pop;
  always_comb begin
    for (int q = 0; q < NQH; q++) begin
      cpl_valid[q]  = cq_out_valid[q];
      cq_out_ready[q] = cpl_ready[q];
    end
    cq_out_ready[NQH] = mgmt_pop;
  end
  genvar gc;
  generate
    for (gc = 0; gc < NQH; gc++) begin : g_cpl
      assign cpl_data[gc*CPLW +: CPLW] = cq_out_data[gc*CPLW +: CPLW];
    end
  endgenerate

  assign h_valid = sq_out_valid;
  assign h_cmd   = sq_out_data;

  // host submission handshake: a queue that does not exist swallows the descriptor (counted)
  wire sub_q_ok = ({1'b0, sub_q} < 5'(NQH));
  logic sub_q_ready;
  always_comb begin
    sub_q_ready = 1'b1;
    for (int q = 0; q < NQH; q++) if (sub_q == q[3:0]) sub_q_ready = sq_in_ready[q];
  end
  assign sub_ready = sub_q_ok ? sub_q_ready : 1'b1;
  assign ev_bad_q  = sub_valid && !sub_q_ok;
  always_comb begin
    ev_sub = '0;
    for (int q = 0; q < NQH; q++) ev_sub[q] = sq_in_valid[q] && sq_in_ready[q];
    ev_sub[NQH] = sq_in_valid[NQH] && sq_in_ready[NQH];
  end

  // ------------------------------------------------------------ credits
  logic [LW-1:0] credit_q [NQT];
  logic [NQT-1:0] cq_pop;
  always_comb begin
    for (int q = 0; q < NQT; q++) cq_pop[q] = cq_out_valid[q] && cq_out_ready[q];
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int q = 0; q < NQT; q++) credit_q[q] <= LW'(CD);
    end else begin
      for (int q = 0; q < NQT; q++) begin
        if (h_pop[q] && !cq_pop[q])      credit_q[q] <= credit_q[q] - 1'b1;
        else if (!h_pop[q] && cq_pop[q]) credit_q[q] <= credit_q[q] + 1'b1;
      end
    end
  end
  always_comb begin
    for (int q = 0; q < NQT; q++) h_credit[q] = (credit_q[q] != '0);
  end
  assign ev_cq_overflow = c_push && !cq_in_ready[c_push_q[QIW-1:0]];

  // ------------------------------------------------------------ bindings and classes
  logic [3:0] bind_q [NQT];
  always_comb begin
    for (int q = 0; q < NQT; q++) begin
      q_tenant[q*4 +: 4] = bind_q[q];
      q_compute[q]       = (q >= NNQ) && (q < NQH);
    end
  end

  // ------------------------------------------------------------ statistics
  logic [31:0] n_sub_q [NQT], n_cpl_q [NQT], n_rej_q [NQT];
  wire c_rej = (c_push_data[silicaflux_cloud_pkg::CPL_STATUS_LSB +: 8] != 8'(silicaflux_cloud_pkg::ST_OK));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int q = 0; q < NQT; q++) begin n_sub_q[q] <= 32'd0; n_cpl_q[q] <= 32'd0; n_rej_q[q] <= 32'd0; end
    end else begin
      for (int q = 0; q < NQT; q++) begin
        if (ev_sub[q])  n_sub_q[q] <= n_sub_q[q] + 32'd1;
        if (cq_pop[q])  n_cpl_q[q] <= n_cpl_q[q] + 32'd1;
        if (c_push && c_push_q == q[3:0] && c_rej) n_rej_q[q] <= n_rej_q[q] + 32'd1;
      end
    end
  end

  always_comb begin
    q_total = 8'd0;
    for (int q = 0; q < NQT; q++) q_total = q_total + {{(8-LW){1'b0}}, sq_level[q*LW +: LW]};
  end

  // ------------------------------------------------------------ region 2: queue table + management submit
  wire        wr2     = rb2_sel && rb_we;
  wire        in_tbl  = (rb_addr < 12'h200);
  wire [3:0]  rb_q    = rb_addr[8:5];
  wire [4:0]  rb_o    = rb_addr[4:0];
  wire        q_host  = ({1'b0, rb_q} < 5'(NQH));
  wire        q_mgmt  = (rb_q == 4'(silicaflux_cloud_pkg::MGMT_QUEUE_ID));
  wire        q_exist = q_host || q_mgmt;
  wire [QIW-1:0] qi   = q_mgmt ? QIW'(NQH) : rb_q[QIW-1:0];
  wire        q_idle  = !sq_out_valid[qi] && (credit_q[qi] == LW'(CD));
  logic [1:0] msub_status_q;
  wire  [3:0] md_w = rb_addr[5:2];                  // management descriptor word (0x800 + 4w, w < 12)

  always_comb begin
    rb2_rdata = 32'd0;
    rb2_err   = 1'b0;
    if (in_tbl) begin
      if (!q_exist || rb_o[1:0] != 2'b00) begin
        rb2_err = 1'b1;                                            // a queue that does not exist (or a misaligned offset)
      end else begin
        case (rb_o)
          5'h00: rb2_rdata = q_mgmt ? 32'd0 : {28'd0, bind_q[qi]};
          5'h04: rb2_rdata = {13'd0, 1'b1, q_mgmt, q_compute[qi] && !q_mgmt, {8'd0 + 8'(cq_level[qi*LW +: LW])}, 8'(sq_level[qi*LW +: LW])};
          5'h08: rb2_rdata = n_sub_q[qi];
          5'h0C: rb2_rdata = n_cpl_q[qi];
          5'h10: rb2_rdata = n_rej_q[qi];
          default: rb2_err = 1'b1;
        endcase
        if (rb_we && rb_o != 5'h00) rb2_err = 1'b1;                    // only BIND is writable
        if (rb_we && rb_o == 5'h00 && (q_mgmt || !q_idle || ({1'b0, rb_wdata[3:0]} >= 5'(NT)) || (rb_wdata[31:4] != 28'd0)))
          rb2_err = 1'b1;
      end
    end else if (rb_addr >= 12'h800 && rb_addr < 12'h830) begin
      rb2_rdata = mdesc_q[md_w];
      if (rb_addr[1:0] != 2'b00) rb2_err = 1'b1;
    end else if (rb_addr == 12'h830) begin
      rb2_rdata = 32'd0;
      rb2_err   = !rb_we && 1'b0;
    end else if (rb_addr == 12'h834) begin
      rb2_rdata = {30'd0, msub_status_q};
      rb2_err   = rb_we;
    end else begin
      rb2_err = 1'b1;
    end
  end

  always_comb begin
    for (int w = 0; w < 12; w++) mdesc_vec[w*32 +: 32] = mdesc_q[w];
  end
  assign msub_valid = wr2 && (rb_addr == 12'h830) && rb_wdata[0];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int q = 0; q < NQT; q++) bind_q[q] <= (q < NQH) ? 4'(q % NT) : 4'd0;
      for (int w = 0; w < 12; w++) mdesc_q[w] <= 32'd0;
      msub_status_q <= 2'b00;
    end else begin
      if (wr2 && in_tbl && q_host && rb_o == 5'h00 && !rb2_err) bind_q[qi] <= rb_wdata[3:0];
      if (wr2 && rb_addr >= 12'h800 && rb_addr < 12'h830 && rb_addr[1:0] == 2'b00) mdesc_q[md_w] <= rb_wdata;
      if (msub_valid) msub_status_q <= sq_in_ready[NQH] ? 2'b01 : 2'b10;
    end
  end

  // ------------------------------------------------------------ region 3: management completion queue
  wire wr3 = rb3_sel && rb_we;
  wire [3:0] rc_w = rb_addr[5:2] - 4'd4;              // head-record word (0x10 + 4w, w < 8)
  assign mgmt_pop = wr3 && (rb_addr == 12'h004) && rb_wdata[0];
  assign mgmt_cq_nonempty = cq_out_valid[NQH];
  always_comb begin
    rb3_rdata = 32'd0;
    rb3_err   = 1'b0;
    if (rb_addr == 12'h000)      begin rb3_rdata = {23'd0, cq_out_valid[NQH], 8'(cq_level[NQH*LW +: LW])}; rb3_err = rb_we; end
    else if (rb_addr == 12'h004) begin rb3_rdata = 32'd0; end
    else if (rb_addr >= 12'h010 && rb_addr < 12'h030 && rb_addr[1:0] == 2'b00) begin
      rb3_rdata = cq_out_data[NQH*CPLW + 32'(rc_w) * 32 +: 32];
      rb3_err   = rb_we;
    end else rb3_err = 1'b1;
  end
endmodule

`default_nettype wire
