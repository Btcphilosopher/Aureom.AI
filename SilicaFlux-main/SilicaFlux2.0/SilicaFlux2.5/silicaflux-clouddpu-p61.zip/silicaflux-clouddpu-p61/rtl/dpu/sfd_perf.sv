// =============================================================================
// CloudDPU :: sfd_perf -- performance counters (register region 4)
//
// 64-bit counters read as LO/HI pairs: the LO read latches HI, so a LO-then-HI read sequence is atomic.
//   global k:  0 CMDS_ACCEPTED   1 CMDS_RETIRED   2 CMDS_ERROR      3 DMA_BYTES_RD (host->SRAM)  4 DMA_BYTES_WR (SRAM->host)
//              5 ACTIVE_CYCLES   6 STALL_DISPATCH  7 STALL_FABRIC     8 STALL_HOST                 9 STALL_ANY
//             10 MEM_CONFLICTS  (SRAM crossbar arbitration losses)     11 ERR_EVENTS  12 VIOLATIONS  13 HOST_ERRORS
//             14 TIMEOUTS       15 CYCLES
//   per tenant: CMDS (retired), BYTES (committed), ACTIVE cycles (a job of the tenant was executing), VIOL, ERRORS
// CTRL.FREEZE holds every counter (consistent snapshot of several registers); CTRL.CLEAR zeroes them.
// DMA byte counts are sums of the bytes moved by completed DATA BEATS (a beat counts when its destination
// acknowledged it), so they never include bytes that were only requested.
// Persistent reset domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_perf #(
  parameter int NT  = 1,
  parameter int NS  = 1,
  parameter int NQT = 2,
  parameter int NM  = 4              // SRAM crossbar masters
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            rb_sel,
  input  wire logic            rb_we,
  input  wire logic [11:0]     rb_addr,
  /* verilator lint_off UNUSEDSIGNAL */          // only CTRL[1:0] is writable
  input  wire logic [31:0]     rb_wdata,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]          rb_rdata,
  output logic                 rb_err,
  // events
  input  wire logic [NQT-1:0]  ev_sub,
  input  wire logic            ev_retire,
  /* verilator lint_off UNUSEDSIGNAL */          // only log2(NT) tenant bits are used
  input  wire logic [3:0]      ev_ten,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [7:0]      ev_status,
  input  wire logic [7:0]      ev_err,
  input  wire logic [31:0]     ev_bytes,
  input  wire logic            ev_viol,
  input  wire logic            ev_host_err,
  input  wire logic            ev_timeout,
  input  wire logic            ev_busy,
  input  wire logic            ev_stall_dispatch,
  input  wire logic            ev_stall_fabric,
  input  wire logic            ev_stall_host,
  input  wire logic [NM-1:0]   ev_arb_loss,
  input  wire logic [NS-1:0]   ev_h2d_beat,
  input  wire logic [NS-1:0]   ev_d2h_beat,
  input  wire logic [NS*8-1:0] ev_beat_bytes,
  input  wire logic [NS-1:0]   slot_busy,
  input  wire logic [NS*4-1:0] slot_ten
);
  localparam int NG  = 16;
  localparam int TIW = (NT > 1) ? $clog2(NT) : 1;

  logic        frz_q;
  logic [63:0] g_q [NG];
  logic [63:0] t_cmds_q [NT], t_bytes_q [NT], t_act_q [NT];
  logic [31:0] t_viol_q [NT], t_err_q [NT];
  logic [31:0] hi_q;

  // ---- per-cycle increments
  logic [7:0]  n_sub, n_arb;
  logic [15:0] b_rd, b_wr;
  always_comb begin
    n_sub = 8'd0;
    for (int q = 0; q < NQT; q++) n_sub = n_sub + {7'd0, ev_sub[q]};
    n_arb = 8'd0;
    for (int m = 0; m < NM; m++) n_arb = n_arb + {7'd0, ev_arb_loss[m]};
    b_rd = 16'd0;  b_wr = 16'd0;
    for (int s = 0; s < NS; s++) begin
      if (ev_h2d_beat[s]) b_rd = b_rd + {8'd0, ev_beat_bytes[s*8 +: 8]};
      if (ev_d2h_beat[s]) b_wr = b_wr + {8'd0, ev_beat_bytes[s*8 +: 8]};
    end
  end
  wire retire_err = ev_retire && (ev_status != 8'd0);
  wire stall_any  = ev_stall_dispatch || ev_stall_fabric || ev_stall_host;

  logic [63:0] inc [NG];
  always_comb begin
    for (int k = 0; k < NG; k++) inc[k] = 64'd0;
    inc[0]  = {56'd0, n_sub};
    inc[1]  = {63'd0, ev_retire};
    inc[2]  = {63'd0, retire_err};
    inc[3]  = {48'd0, b_rd};
    inc[4]  = {48'd0, b_wr};
    inc[5]  = {63'd0, ev_busy};
    inc[6]  = {63'd0, ev_stall_dispatch};
    inc[7]  = {63'd0, ev_stall_fabric};
    inc[8]  = {63'd0, ev_stall_host};
    inc[9]  = {63'd0, stall_any};
    inc[10] = {56'd0, n_arb};
    inc[11] = {63'd0, ev_retire && (ev_err != 8'd0)};
    inc[12] = {63'd0, ev_viol};
    inc[13] = {63'd0, ev_host_err};
    inc[14] = {63'd0, ev_timeout};
    inc[15] = 64'd1;
  end

  // ---- register address decode (shared by the read mux and the HI latch)
  wire        g_hit = (rb_addr >= 12'h010) && (rb_addr < 12'h090) && (rb_addr[1:0] == 2'b00);
  wire [3:0]  gk    = rb_addr[6:3] - 4'd2;          // counter index (offset 0x10 + 8k; k < 16)
  wire        t_hit = (rb_addr[11:9] == 3'b010) && (rb_addr[1:0] == 2'b00) && ({1'b0, rb_addr[8:5]} < 5'(NT));
  wire [4:0]  t_o   = rb_addr[4:0];
  wire [TIW-1:0] tsel = rb_addr[5 + TIW - 1 : 5];

  wire wr  = rb_sel && rb_we;
  wire clr = wr && (rb_addr == 12'h000) && rb_wdata[1];
  wire [TIW-1:0] rti = ev_ten[TIW-1:0];
  logic [NT-1:0] t_act_inc;
  always_comb begin
    t_act_inc = '0;
    for (int s = 0; s < NS; s++)
      for (int t = 0; t < NT; t++)
        if (slot_busy[s] && slot_ten[s*4 +: 4] == t[3:0]) t_act_inc[t] = 1'b1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      frz_q <= 1'b0;  hi_q <= 32'd0;
      for (int k = 0; k < NG; k++) g_q[k] <= 64'd0;
      for (int t = 0; t < NT; t++) begin
        t_cmds_q[t] <= 64'd0;  t_bytes_q[t] <= 64'd0;  t_act_q[t] <= 64'd0;  t_viol_q[t] <= 32'd0;  t_err_q[t] <= 32'd0;
      end
    end else begin
      if (wr && rb_addr == 12'h000) frz_q <= rb_wdata[0];
      if (clr) begin
        for (int k = 0; k < NG; k++) g_q[k] <= 64'd0;
        for (int t = 0; t < NT; t++) begin
          t_cmds_q[t] <= 64'd0;  t_bytes_q[t] <= 64'd0;  t_act_q[t] <= 64'd0;  t_viol_q[t] <= 32'd0;  t_err_q[t] <= 32'd0;
        end
      end else if (!frz_q) begin
        for (int k = 0; k < NG; k++) g_q[k] <= g_q[k] + inc[k];
        for (int t = 0; t < NT; t++) begin
          if (t_act_inc[t]) t_act_q[t] <= t_act_q[t] + 64'd1;
          if (ev_retire && rti == t[TIW-1:0]) begin
            t_cmds_q[t]  <= t_cmds_q[t] + 64'd1;
            t_bytes_q[t] <= t_bytes_q[t] + {32'd0, ev_bytes};
            if (ev_err != 8'd0) t_err_q[t] <= t_err_q[t] + 32'd1;
          end
          if (ev_viol && rti == t[TIW-1:0]) t_viol_q[t] <= t_viol_q[t] + 32'd1;
        end
      end
      // the LO read latches HI (side effect at the strobe)
      if (rb_sel && !rb_we) begin
        if (g_hit && !rb_addr[2])    hi_q <= g_q[gk][63:32];
        if (t_hit && t_o == 5'h00)   hi_q <= t_cmds_q[tsel][63:32];
        if (t_hit && t_o == 5'h08)   hi_q <= t_bytes_q[tsel][63:32];
        if (t_hit && t_o == 5'h10)   hi_q <= t_act_q[tsel][63:32];
      end
    end
  end

  // ---- register read
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_addr == 12'h000)      begin rb_rdata = {30'd0, 1'b0, frz_q}; end
    else if (rb_addr == 12'h004) begin rb_rdata = {16'd0, 8'(NT), 8'(NG)}; rb_err = rb_we; end
    else if (g_hit) begin
      rb_rdata = rb_addr[2] ? hi_q : g_q[gk][31:0];
      rb_err   = rb_we;
    end else if (t_hit) begin
      rb_err = rb_we;
      case (t_o)
        5'h00: rb_rdata = t_cmds_q[tsel][31:0];
        5'h04: rb_rdata = hi_q;
        5'h08: rb_rdata = t_bytes_q[tsel][31:0];
        5'h0C: rb_rdata = hi_q;
        5'h10: rb_rdata = t_act_q[tsel][31:0];
        5'h14: rb_rdata = hi_q;
        5'h18: rb_rdata = t_viol_q[tsel];
        5'h1C: rb_rdata = t_err_q[tsel];
        default: rb_err = 1'b1;
      endcase
    end else rb_err = 1'b1;
    if (rb_we && rb_addr == 12'h000) rb_err = 1'b0;
  end
endmodule

`default_nettype wire
