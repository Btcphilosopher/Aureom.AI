// =============================================================================
// CloudDPU :: sfd_packetcore_tadapter -- PACKETCORE *TEST ADAPTER*  (BLK_TEST_ADAPTER, not a PacketCore)
//
// There is no PacketCore in the SilicaFlux repository (docs/00_AUDIT.md).  This block stands in for it
// behind the interface the DPU needs: "process the staged input buffer in local SRAM into an output
// buffer in local SRAM and report integrity results".  It is deliberately simple and deterministic so
// that an independent reference model can check every byte:
//   PROC_PASS     out = in
//   PROC_XOR32    out = in ^ {param, param, ...}           (a keyed byte-lane mask; NOT encryption)
//   PROC_BSWAP32  every 32-bit word byte-swapped            (length must be a multiple of 4)
// For every job it also computes, over exactly the `len` valid bytes:
//   crc_in   CRC-32 (IEEE 802.3) of the input stream   } sfd_crc32, cross-checked against SecureStore's
//   crc_out  CRC-32 of the output stream               }  validated sfsec_crc (mode 1) in tb/tb_crc_xcheck.sv
//   csum     RFC 1071 internet checksum of the output stream (network byte order, odd tail zero padded)
// Data path: SRAM read beat -> transform -> SRAM write beat, one beat at a time on one SRAM master
// port (SFB2).  The port is guarded outside this block (sfd_sram_guard in sfd_job_slot's shared
// PacketCore wrapper); `g_viol` tells this block a request was swallowed.
// A job is complete only after the response to its LAST output write beat has been received, so the
// output buffer is committed to the SRAM before `res_valid`.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_packetcore_tadapter #(
  parameter int DW = 32
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // job
  input  wire logic            job_valid,
  output logic                 job_ready,
  input  wire logic [31:0]     job_in,        // absolute SRAM address of the input buffer
  input  wire logic [31:0]     job_out,       // absolute SRAM address of the output buffer
  input  wire logic [31:0]     job_len,       // bytes, > 0
  input  wire logic [7:0]      job_op,
  input  wire logic [31:0]     job_param,
  // result (one-cycle pulse)
  output logic                 res_valid,
  output logic [7:0]           res_err,
  output logic [31:0]          res_crc_in,
  output logic [31:0]          res_crc_out,
  output logic [15:0]          res_csum,
  output logic [31:0]          res_bytes,
  output logic                 busy,
  // SRAM master
  output logic                 sm_req_valid,
  input  wire logic            sm_req_ready,
  output logic                 sm_req_write,
  output logic [31:0]          sm_req_addr,
  output logic [DW-1:0]        sm_req_wdata,
  output logic [DW/8-1:0]      sm_req_wstrb,
  input  wire logic            sm_rsp_valid,
  output logic                 sm_rsp_ready,
  input  wire logic [DW-1:0]   sm_rsp_rdata,
  input  wire logic            sm_rsp_error,
  input  wire logic            g_viol
);
  localparam int DWB = DW / 8;
  localparam int DLG = $clog2(DWB);
  localparam int NCH = DW / 32;                     // 32-bit CRC chunks per beat
  localparam logic [31:0] DWB32 = DWB;

  localparam logic [3:0] A_IDLE = 4'd0, A_START = 4'd1, A_RD_REQ = 4'd2, A_RD_RSP = 4'd3, A_XFORM = 4'd4,
                         A_WR_REQ = 4'd5, A_WR_RSP = 4'd6, A_FIN = 4'd7;

  // ------------------------------------------------------------ transform and checksum helpers
  function automatic logic [DW-1:0] xform(input logic [DW-1:0] d, input logic [7:0] op, input logic [31:0] key);
    integer l;
    logic [31:0] w;
    for (l = 0; l < NCH; l = l + 1) begin
      w = d[l*32 +: 32];
      if (op == silicaflux_cloud_pkg::PROC_XOR32)         w = w ^ key;
      else if (op == silicaflux_cloud_pkg::PROC_BSWAP32)  w = {w[7:0], w[15:8], w[23:16], w[31:24]};
      xform[l*32 +: 32] = w;
    end
  endfunction

  // RFC 1071 partial sum of one beat: 16-bit words {byte[2k], byte[2k+1]}, bytes beyond nb count as 0
  function automatic logic [31:0] beat_sum(input logic [DW-1:0] d, input logic [7:0] nb);
    integer k;
    logic [31:0] s;
    logic [7:0]  hi, lo;
    s = 32'd0;
    for (k = 0; k < DWB / 2; k = k + 1) begin
      hi = (8'(2*k)     < nb) ? d[(2*k)*8 +: 8]     : 8'd0;
      lo = (8'(2*k + 1) < nb) ? d[(2*k + 1)*8 +: 8] : 8'd0;
      s  = s + {16'd0, hi, lo};
    end
    beat_sum = s;
  endfunction

  // ------------------------------------------------------------ state
  logic [3:0]      st_q;
  logic [31:0]     in_q, out_q, beats_q, bytes_q, param_q, sum_q;
  logic [DLG-1:0]  rem_q;
  logic [7:0]      op_q, err_q;
  logic [DW-1:0]   din_q, dout_q;
  logic [3:0]      ch_q;
  logic            viol_q;

  wire             last    = (beats_q == 32'd1);
  wire             partial = last && (rem_q != '0);
  wire [7:0]       nb      = partial ? {{(8-DLG){1'b0}}, rem_q} : DWB[7:0];
  logic [DWB-1:0]  strb;
  always_comb begin
    for (int b = 0; b < DWB; b++) strb[b] = !(partial && (b >= {1'b0, rem_q}));
  end

  // chunk feed
  wire [7:0]   left     = nb - {2'd0, ch_q, 2'b00};            // bytes not yet fed (ch_q*4 <= nb-1 in A_XFORM)
  wire [2:0]   nbytes   = (left >= 8'd4) ? 3'd4 : left[2:0];
  wire         crc_en   = (st_q == A_XFORM);
  wire         crc_clr  = (st_q == A_START);
  logic [31:0] cin_d, cout_d;
  always_comb begin
    cin_d  = 32'd0;
    cout_d = 32'd0;
    for (int c = 0; c < NCH; c++) begin
      if (ch_q == c[3:0]) begin
        cin_d  = din_q[c*32 +: 32];
        cout_d = dout_q[c*32 +: 32];
      end
    end
  end
  wire is_last_chunk = ({2'd0, ch_q, 2'b00} + 8'd4) >= nb;

  logic [31:0] crc_in_o, crc_out_o;
  sfd_crc32 u_crc_in  (.clk, .rst_n, .clr(crc_clr), .en(crc_en), .data_i(cin_d),  .nbytes_i(nbytes), .crc_o(crc_in_o));
  sfd_crc32 u_crc_out (.clk, .rst_n, .clr(crc_clr), .en(crc_en), .data_i(cout_d), .nbytes_i(nbytes), .crc_o(crc_out_o));

  // final RFC 1071 fold
  wire [16:0] f1 = {1'b0, sum_q[15:0]} + {1'b0, sum_q[31:16]};
  wire [15:0] f2 = f1[15:0] + {15'd0, f1[16]};            // two folds suffice: f1 <= 0x1FFFE, f2 <= 0xFFFF

  assign job_ready    = (st_q == A_IDLE);
  assign busy         = (st_q != A_IDLE);
  assign res_valid    = (st_q == A_FIN);
  assign res_err      = err_q;
  assign res_crc_in   = crc_in_o;
  assign res_crc_out  = crc_out_o;
  assign res_csum     = ~f2;
  assign res_bytes    = bytes_q;

  assign sm_req_valid = (st_q == A_RD_REQ) || (st_q == A_WR_REQ);
  assign sm_req_write = (st_q == A_WR_REQ);
  assign sm_req_addr  = (st_q == A_WR_REQ) ? out_q : in_q;
  assign sm_req_wdata = dout_q;
  assign sm_req_wstrb = strb;
  assign sm_rsp_ready = (st_q == A_RD_RSP) || (st_q == A_WR_RSP);

  wire [7:0] sram_err = viol_q ? silicaflux_cloud_pkg::ERR_PERM_BEAT : silicaflux_cloud_pkg::ERR_SRAM_RESP;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q    <= A_IDLE;
      in_q    <= '0;  out_q <= '0;  beats_q <= '0;  bytes_q <= '0;  param_q <= '0;  sum_q <= '0;
      rem_q   <= '0;  op_q <= '0;   err_q <= silicaflux_cloud_pkg::ERR_NONE;
      din_q   <= '0;  dout_q <= '0; ch_q <= '0;     viol_q <= 1'b0;
    end else begin
      if (g_viol) viol_q <= 1'b1;
      case (st_q)
        A_IDLE: begin
          if (job_valid) begin
            in_q    <= job_in;
            out_q   <= job_out;
            beats_q <= (job_len + DWB32 - 32'd1) >> DLG;
            rem_q   <= job_len[DLG-1:0];
            op_q    <= job_op;
            param_q <= job_param;
            bytes_q <= 32'd0;
            sum_q   <= 32'd0;
            err_q   <= silicaflux_cloud_pkg::ERR_NONE;
            viol_q  <= 1'b0;
            st_q    <= A_START;
          end
        end
        A_START:  st_q <= A_RD_REQ;                       // crc_clr is asserted in this state
        A_RD_REQ: if (sm_req_ready) st_q <= A_RD_RSP;
        A_RD_RSP: begin
          if (sm_rsp_valid) begin
            if (sm_rsp_error) begin err_q <= sram_err; st_q <= A_FIN; end
            else begin
              din_q  <= sm_rsp_rdata;
              dout_q <= xform(sm_rsp_rdata, op_q, param_q);
              ch_q   <= 4'd0;
              st_q   <= A_XFORM;
            end
          end
        end
        A_XFORM: begin                                    // crc_en: feed one 32-bit chunk of in and out
          if (is_last_chunk) begin
            sum_q <= sum_q + beat_sum(dout_q, nb);
            st_q  <= A_WR_REQ;
          end else begin
            ch_q <= ch_q + 4'd1;
          end
        end
        A_WR_REQ: if (sm_req_ready) st_q <= A_WR_RSP;
        A_WR_RSP: begin
          if (sm_rsp_valid) begin
            if (sm_rsp_error) begin err_q <= sram_err; st_q <= A_FIN; end
            else begin
              bytes_q <= bytes_q + {24'd0, nb};           // counted once the SRAM acknowledged the write
              in_q    <= in_q  + DWB32;
              out_q   <= out_q + DWB32;
              beats_q <= beats_q - 32'd1;
              st_q    <= last ? A_FIN : A_RD_REQ;
            end
          end
        end
        A_FIN:   st_q <= A_IDLE;
        default: begin err_q <= silicaflux_cloud_pkg::ERR_INTERNAL; st_q <= A_FIN; end
      endcase
    end
  end
endmodule

`default_nettype wire
