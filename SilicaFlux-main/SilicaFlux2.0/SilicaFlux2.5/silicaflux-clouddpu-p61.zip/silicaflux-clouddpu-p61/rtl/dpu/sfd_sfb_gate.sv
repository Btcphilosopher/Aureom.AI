// =============================================================================
// CloudDPU :: sfd_sfb_gate -- SFB2 request gate: forward an authorised request, SWALLOW a refused one
//
// The only path from master to slave runs through `allow`:  s_req_valid = m_req_valid && allow.
// A refused request is accepted (so the master is never wedged), never reaches the slave, and is
// answered one cycle later with rsp_error = 1 (SFB2 R8: an errored write has no side effect).
// `blk_evt` pulses when a request is swallowed.  One transaction at a time (SFB2 R6).
// Protocol notes: s_req_valid does not depend on s_req_ready (R3); the error response never appears in
// the acceptance cycle (R5) and is held until rsp_ready (R4).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_sfb_gate #(
  parameter int AW = 32,
  parameter int DW = 32
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // master side
  input  wire logic            m_req_valid,
  output logic                 m_req_ready,
  input  wire logic            m_req_write,
  input  wire logic [AW-1:0]   m_req_addr,
  input  wire logic [DW-1:0]   m_req_wdata,
  input  wire logic [DW/8-1:0] m_req_wstrb,
  output logic                 m_rsp_valid,
  input  wire logic            m_rsp_ready,
  output logic [DW-1:0]        m_rsp_rdata,
  output logic                 m_rsp_error,
  // slave side
  output logic                 s_req_valid,
  input  wire logic            s_req_ready,
  output logic                 s_req_write,
  output logic [AW-1:0]        s_req_addr,
  output logic [DW-1:0]        s_req_wdata,
  output logic [DW/8-1:0]      s_req_wstrb,
  input  wire logic            s_rsp_valid,
  output logic                 s_rsp_ready,
  input  wire logic [DW-1:0]   s_rsp_rdata,
  input  wire logic            s_rsp_error,
  // policy
  input  wire logic            allow,
  output logic                 blk_evt
);
  logic err_pend_q;

  assign s_req_valid = m_req_valid && allow && !err_pend_q;
  assign s_req_write = m_req_write;
  assign s_req_addr  = m_req_addr;
  assign s_req_wdata = m_req_wdata;
  assign s_req_wstrb = m_req_wstrb;
  assign m_req_ready = !err_pend_q && (allow ? s_req_ready : 1'b1);
  assign blk_evt     = m_req_valid && !allow && !err_pend_q;      // accepted and swallowed this cycle

  assign m_rsp_valid = err_pend_q || s_rsp_valid;
  assign m_rsp_error = err_pend_q || s_rsp_error;
  assign m_rsp_rdata = err_pend_q ? {DW{1'b0}} : s_rsp_rdata;
  assign s_rsp_ready = !err_pend_q && m_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                              err_pend_q <= 1'b0;
    else if (blk_evt)                        err_pend_q <= 1'b1;
    else if (err_pend_q && m_rsp_ready)      err_pend_q <= 1'b0;
  end
endmodule

`default_nettype wire
