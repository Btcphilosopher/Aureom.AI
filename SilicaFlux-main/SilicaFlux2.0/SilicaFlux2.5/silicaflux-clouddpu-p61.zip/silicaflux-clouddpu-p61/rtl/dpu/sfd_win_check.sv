// =============================================================================
// CloudDPU :: sfd_win_check -- is [addr, addr+len) inside ONE host window of a tenant that grants
// the requested permissions?  Combinational.  Used by the command processor (pre-check, gives a
// precise error code) and by sfd_host_guard (per-beat enforcement, defence in depth).
//   perm bit 0 = R, bit 1 = W (silicaflux_cloud_pkg::PERM_*).   len == 0 never matches.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_win_check #(
  parameter int NW = 2
) (
  input  wire logic [NW*64-1:0] win_base,
  input  wire logic [NW*32-1:0] win_size,
  input  wire logic [NW-1:0]    win_valid,
  input  wire logic [NW*2-1:0]  win_perm,
  input  wire logic [63:0]      addr,
  input  wire logic [31:0]      len,
  input  wire logic             need_r,
  input  wire logic             need_w,
  output logic                  ok
);
  logic [NW-1:0] hit;
  genvar w;
  generate
    for (w = 0; w < NW; w++) begin : g_win
      wire [63:0] wb    = win_base[w*64 +: 64];
      wire [64:0] a_end = {1'b0, addr} + {33'd0, len};
      wire [64:0] w_end = {1'b0, wb} + {33'd0, win_size[w*32 +: 32]};
      assign hit[w] = win_valid[w] && (len != 32'd0) &&
                      (addr >= wb) && (a_end <= w_end) &&
                      (!need_r || win_perm[w*2]) && (!need_w || win_perm[w*2 + 1]);
    end
  endgenerate
  assign ok = |hit;
endmodule

`default_nettype wire
