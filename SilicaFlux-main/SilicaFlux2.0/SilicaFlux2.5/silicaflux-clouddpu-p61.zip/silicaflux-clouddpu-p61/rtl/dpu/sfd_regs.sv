// =============================================================================
// CloudDPU :: sfd_regs -- global control/status registers (regions 0, 6, 7), fault capture and RAS/IRQ drive
//
// Region 0 GLOBAL     identification, configuration read-back, CTRL (dispatch enable, data-plane reset),
//                     interrupt enable, sticky FAULT_STATUS with enable / warn / fatal masks, last-fault capture,
//                     job watchdog value, free-running time
// Region 6 ENGINES    status of the engine-class interfaces (BLOCKED unless the block exists)
// Region 7 DEBUG      read-only visibility of the job slots, command processor, host port and scrubber
//
// Interrupt lines (level):  irq_event = IRQ_ENABLE[0] && management completion queue not empty
//                           irq_fault = |(FAULT_STATUS & FAULT_ENABLE)
// RAS lines (level, to the ControlCore RAS inputs):  ext_warn = |(FAULT_STATUS & FAULT_WARN)
//                                                    ext_fatal = |(FAULT_STATUS & FAULT_FATAL)
// Reset: dispatch is DISABLED (CTRL.EN = 0) until management enables it: nothing runs after reset by itself.
// Persistent reset domain.  Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_regs #(
  parameter int NT         = 1,
  parameter int NNQ        = 1,
  parameter int NCQ        = 1,
  parameter int NCH        = 1,
  parameter int DW         = 32,
  parameter int AW         = 32,
  parameter int NW         = 2,
  parameter int SRAM_BYTES = 65536,
  parameter int MAX_XFER   = 4096,
  parameter int ENT        = 0,
  parameter int ENC        = 0,
  parameter int ENS        = 0,
  parameter int QD         = 4
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            rb0_sel,
  input  wire logic            rb_we,
  input  wire logic [11:0]     rb_addr,
  input  wire logic [31:0]     rb_wdata,
  output logic [31:0]          rb0_rdata,
  output logic                 rb0_err,
  output logic [31:0]          rb6_rdata,
  output logic                 rb6_err,
  output logic [31:0]          rb7_rdata,
  output logic                 rb7_err,
  // controls
  output logic                 ctl_en,
  output logic                 dp_reset_req,
  output logic [31:0]          job_timeout,
  output logic [31:0]          time_cnt,
  // status
  input  wire logic            st_busy,
  input  wire logic            st_halted,
  input  wire logic            st_resetting,
  input  wire logic            st_scrub,
  input  wire logic [7:0]      st_inflight,
  input  wire logic [7:0]      st_queued,
  input  wire logic            mgmt_cq_nonempty,
  // faults
  input  wire logic [silicaflux_cloud_pkg::FLT_NUM-1:0] flt_set,
  input  wire logic            flt_tlm_drop,
  input  wire logic [3:0]      flt_tenant,
  input  wire logic [7:0]      flt_err,
  input  wire logic [63:0]     flt_addr,
  input  wire logic            flt_addr_valid,
  output logic                 irq_event,
  output logic                 irq_fault,
  output logic                 ext_warn,
  output logic                 ext_fatal,
  // engines
  input  wire logic            ev_blocked,
  input  wire logic            ev_pkt_job,
  // debug
  input  wire logic [NCH*4-1:0] dbg_slot_fsm,
  input  wire logic [NCH-1:0]   dbg_slot_busy,
  input  wire logic [NCH-1:0]   dbg_zombie,
  input  wire logic [NCH*4-1:0] dbg_slot_ten,
  input  wire logic [3:0]      dbg_cp_state,
  input  wire logic [3:0]      dbg_qsel,
  input  wire logic            hm_out,
  input  wire logic            hm_orphan,
  input  wire logic [3:0]      scrub_ten,
  input  wire logic            scrub_act,
  input  wire logic [15:0]     scrub_beats
);
  localparam int FN = silicaflux_cloud_pkg::FLT_NUM;
  localparam logic [1:0] BLK_INF = (ENT != 0) ? silicaflux_cloud_pkg::BLK_REAL : silicaflux_cloud_pkg::BLK_BLOCKED;
  localparam logic [1:0] BLK_CRY = (ENC != 0) ? silicaflux_cloud_pkg::BLK_REAL : silicaflux_cloud_pkg::BLK_BLOCKED;
  localparam logic [1:0] BLK_STO = (ENS != 0) ? silicaflux_cloud_pkg::BLK_REAL : silicaflux_cloud_pkg::BLK_BLOCKED;

  logic          en_q, irq_en_q;
  logic [FN-1:0] fst_q, fen_q, fwn_q, ffa_q;
  logic [31:0]   jt_q, scr_q, nrst_q, ftn_q, fer_q, fal_q, fah_q;
  logic [63:0]   time_q;
  logic [31:0]   thi_q;
  logic [31:0]   blk_rej_q, pkt_jobs_q;
  logic          rst_pulse_q;

  assign ctl_en       = en_q;
  assign job_timeout  = jt_q;
  assign time_cnt     = time_q[31:0];
  assign dp_reset_req = rst_pulse_q;
  assign irq_event    = irq_en_q && mgmt_cq_nonempty;
  assign irq_fault    = |(fst_q & fen_q);
  assign ext_warn     = |(fst_q & fwn_q);
  assign ext_fatal    = |(fst_q & ffa_q);

  wire wr0 = rb0_sel && rb_we;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q <= 1'b0;  irq_en_q <= 1'b0;  fst_q <= '0;  fen_q <= '0;  fwn_q <= '0;  ffa_q <= '0;
      jt_q <= 32'h0004_0000;  scr_q <= '0;  nrst_q <= '0;  ftn_q <= '0;  fer_q <= '0;  fal_q <= '0;  fah_q <= '0;
      time_q <= '0;  thi_q <= '0;  blk_rej_q <= '0;  pkt_jobs_q <= '0;  rst_pulse_q <= 1'b0;
    end else begin
      time_q      <= time_q + 64'd1;
      rst_pulse_q <= 1'b0;
      if (rb0_sel && !rb_we && rb_addr == 12'h054) thi_q <= time_q[63:32];      // TIME_LO read latches TIME_HI
      if (wr0) begin
        case (rb_addr)
          12'h020: begin en_q <= rb_wdata[0]; if (rb_wdata[1]) begin rst_pulse_q <= 1'b1; nrst_q <= nrst_q + 32'd1; end end
          12'h02C: irq_en_q <= rb_wdata[0];
          12'h030: fst_q <= fst_q & ~rb_wdata[FN-1:0];                              // W1C (set below wins)
          12'h034: fen_q <= rb_wdata[FN-1:0];
          12'h038: fwn_q <= rb_wdata[FN-1:0];
          12'h03C: ffa_q <= rb_wdata[FN-1:0];
          12'h050: jt_q  <= rb_wdata;
          12'h060: scr_q <= rb_wdata;
          default: ;
        endcase
      end
      // sticky set (wins over a same-cycle clear)
      for (int b = 0; b < FN; b++) begin
        if (flt_set[b]) fst_q[b] <= 1'b1;
      end
      if (flt_tlm_drop) fst_q[silicaflux_cloud_pkg::FLT_TLM_DROP] <= 1'b1;
      if (|flt_set) begin
        ftn_q <= {28'd0, flt_tenant};
        fer_q <= {24'd0, flt_err};
        if (flt_addr_valid) begin fal_q <= flt_addr[31:0]; fah_q <= flt_addr[63:32]; end
      end
      if (ev_blocked) blk_rej_q  <= blk_rej_q + 32'd1;
      if (ev_pkt_job) pkt_jobs_q <= pkt_jobs_q + 32'd1;
    end
  end

  // ---------------------------------------------------------------- region 0 read
  always_comb begin
    rb0_rdata = 32'd0;
    rb0_err   = 1'b0;
    case (rb_addr)
      12'h000: rb0_rdata = silicaflux_cloud_pkg::DPU_ID_MAGIC;
      12'h004: rb0_rdata = {silicaflux_cloud_pkg::DPU_ABI_MAJOR, silicaflux_cloud_pkg::DPU_ABI_MINOR};
      12'h008: rb0_rdata = {8'(NCH), 8'(NCQ), 8'(NNQ), 8'(NT)};
      12'h00C: rb0_rdata = {8'(NW), 8'(AW), 16'(DW)};
      12'h010: rb0_rdata = SRAM_BYTES[31:0];
      12'h014: rb0_rdata = MAX_XFER[31:0];
      12'h018: rb0_rdata = {16'd0, 2'b11 /*CONTROLCORE real*/, 2'b11 /*TELEMETRY real*/, BLK_STO, BLK_CRY, BLK_INF,
                            silicaflux_cloud_pkg::BLK_TEST_ADAPTER /*VIRTUALIO*/, silicaflux_cloud_pkg::BLK_REAL /*CLOUDDMA*/,
                            silicaflux_cloud_pkg::BLK_TEST_ADAPTER /*PACKETCORE*/};
      12'h01C: rb0_rdata = {25'd0, (QD > 1), 1'b1, (NT > 1), 1'b1, 1'(ENS != 0), 1'(ENC != 0), 1'(ENT != 0)};
      12'h020: rb0_rdata = {31'd0, en_q};
      12'h024: rb0_rdata = {8'd0, st_queued, st_inflight, 4'd0, st_scrub, st_resetting, st_halted, st_busy};
      12'h028: rb0_rdata = {30'd0, irq_fault, irq_event};
      12'h02C: rb0_rdata = {31'd0, irq_en_q};
      12'h030: rb0_rdata = {{(32-FN){1'b0}}, fst_q};
      12'h034: rb0_rdata = {{(32-FN){1'b0}}, fen_q};
      12'h038: rb0_rdata = {{(32-FN){1'b0}}, fwn_q};
      12'h03C: rb0_rdata = {{(32-FN){1'b0}}, ffa_q};
      12'h040: rb0_rdata = ftn_q;
      12'h044: rb0_rdata = fer_q;
      12'h048: rb0_rdata = fal_q;
      12'h04C: rb0_rdata = fah_q;
      12'h050: rb0_rdata = jt_q;
      12'h054: rb0_rdata = time_q[31:0];
      12'h058: rb0_rdata = thi_q;
      12'h060: rb0_rdata = scr_q;
      12'h064: rb0_rdata = nrst_q;
      default: rb0_err = 1'b1;
    endcase
    // write permissions: RO registers refuse writes
    if (rb_we) begin
      case (rb_addr)
        12'h020, 12'h02C, 12'h030, 12'h034, 12'h038, 12'h03C, 12'h050, 12'h060: rb0_err = 1'b0;
        default: rb0_err = 1'b1;
      endcase
    end
    if (!rb_we && rb_addr == 12'h028) rb0_err = 1'b0;
  end

  // ---------------------------------------------------------------- region 6: engines
  always_comb begin
    rb6_rdata = 32'd0;
    rb6_err   = rb_we;
    case (rb_addr)
      12'h000: begin rb6_rdata = {23'd0, 1'(ENT != 0), 6'd0, BLK_INF}; end
      12'h004: begin rb6_rdata = {23'd0, 1'(ENC != 0), 6'd0, BLK_CRY}; end
      12'h008: begin rb6_rdata = {23'd0, 1'(ENS != 0), 6'd0, BLK_STO}; end
      12'h010: begin rb6_rdata = blk_rej_q; end
      12'h014: begin rb6_rdata = pkt_jobs_q; end
      default: rb6_err = 1'b1;
    endcase
  end

  // ---------------------------------------------------------------- region 7: debug
  localparam int DSW = (NCH > 1) ? $clog2(NCH) : 1;
  wire [2:0]     d_slot = rb_addr[4:2];
  wire [DSW-1:0] d_si   = d_slot[DSW-1:0];
  always_comb begin
    rb7_rdata = 32'd0;
    rb7_err   = rb_we;
    if (rb_addr < 12'h020) begin
      rb7_err = rb_we;
      if ({1'b0, d_slot} < 4'(NCH) && rb_addr[1:0] == 2'b00)
        rb7_rdata = {12'd0, dbg_slot_ten[d_si*4 +: 4], 6'd0, dbg_zombie[d_si], dbg_slot_busy[d_si], 4'd0, dbg_slot_fsm[d_si*4 +: 4]};
      else if (rb_addr[1:0] != 2'b00 || {1'b0, d_slot} >= 4'(NCH)) rb7_err = 1'b1;
    end else if (rb_addr == 12'h040) rb7_rdata = {24'd0, dbg_qsel, dbg_cp_state};
    else if (rb_addr == 12'h044)     rb7_rdata = {30'd0, hm_orphan, hm_out};
    else if (rb_addr == 12'h048)     rb7_rdata = {scrub_beats, 7'd0, scrub_act, 4'd0, scrub_ten};
    else rb7_err = 1'b1;
  end
endmodule

`default_nettype wire
