// =============================================================================
// CloudDPU :: sfd_tenant_ctx -- tenant contexts: the architectural basis of isolation
//
// A tenant ID alone is only a label.  Isolation comes from four hardware-enforced objects
// that this block owns and every other block consults:
//   * SRAM PARTITION   [base, base+size) of the local SRAM, owned by exactly one tenant;
//                      partitions of different tenants can never overlap (checked on COMMIT)
//   * HOST WINDOWS     up to NW (base, size, R/W) regions of host (IOVA) address space the
//                      tenant's DMA may touch; windows of different tenants never overlap
//   * STATE MACHINE    DISABLED -> (COMMIT) SCRUBBING -> DISABLED(configured) -> (ENABLE) ACTIVE
//                      ACTIVE -> (violation, policy) QUARANTINED
//                      ACTIVE/QUARANTINED -> (DISABLE/RECOVER) DRAINING -> SCRUBBING -> DISABLED
//   * SCRUB            every partition is zeroed before the tenant can use it (first assignment,
//                      reconfiguration, teardown, recovery): no residual data can leak to the
//                      next owner of the SRAM.
// The configuration registers are SHADOW registers: writing them changes nothing until COMMIT, and
// COMMIT is refused unless the tenant is DISABLED (a live tenant's permissions cannot be edited).
// Only the management plane (ControlCore register port) reaches these registers; tenants do not.
//
// Register page: region 1 (config/dpu_memmap.yaml).  Combinational read, write at end of strobe.
// Reset: asynchronous, active low (persistent domain: survives a data-plane reset).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_tenant_ctx #(
  parameter int NT         = 1,
  parameter int NW         = 2,
  parameter int SRAM_BYTES = 65536,
  parameter int DW         = 32,
  parameter int AW         = 32
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // register page
  input  wire logic                  rb_sel,
  input  wire logic                  rb_we,
  input  wire logic [11:0]           rb_addr,
  input  wire logic [31:0]           rb_wdata,
  output logic [31:0]                rb_rdata,
  output logic                       rb_err,
  // effective configuration (flat)
  output logic [NT*3-1:0]            t_state,
  output logic [NT-1:0]              t_cfg_ok,
  output logic [NT*32-1:0]           t_part_base,
  output logic [NT*32-1:0]           t_part_size,
  output logic [NT*NW*64-1:0]        t_win_base,
  output logic [NT*NW*32-1:0]        t_win_size,
  output logic [NT*NW-1:0]           t_win_valid,
  output logic [NT*NW*2-1:0]         t_win_perm,
  // runtime inputs
  input  wire logic [NT*8-1:0]       t_inflight,
  input  wire logic                  dp_resetting,      // data-plane reset: a scrub write in flight is lost, re-issue it
  input  wire logic                  viol_evt,
  input  wire logic [3:0]            viol_tenant,
  // scrub master (SFB2, write-only, zero data)
  output logic                       sc_req_valid,
  input  wire logic                  sc_req_ready,
  output logic                       sc_req_write,
  output logic [31:0]                sc_req_addr,
  output logic [DW-1:0]              sc_req_wdata,
  output logic [DW/8-1:0]            sc_req_wstrb,
  input  wire logic                  sc_rsp_valid,
  output logic                       sc_rsp_ready,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [DW-1:0]         sc_rsp_rdata,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic                  sc_rsp_error,
  // events
  output logic                       ev_state_valid,
  output logic [3:0]                 ev_state_tenant,
  output logic [2:0]                 ev_state_new,
  output logic                       scrub_active,
  output logic [3:0]                 scrub_tenant,
  output logic [15:0]                scrub_beats
);
  localparam int DWB = DW / 8;
  localparam int DLG = $clog2(DWB);
  localparam int TIW = (NT > 1) ? $clog2(NT) : 1;   // width of an array index

  // ------------------------------------------------------------ state
  logic [2:0]        st_q      [NT];
  logic [NT-1:0]     cfg_ok_q, claimed_q, pol_q;
  logic [7:0]        cfgst_q   [NT];
  logic [31:0]       viol_q    [NT];
  logic [31:0]       sh_base_q [NT];
  logic [31:0]       sh_size_q [NT];
  logic [31:0]       ef_base_q [NT];
  logic [31:0]       ef_size_q [NT];
  // windows, flat: index (t*NW + w)
  logic [NT*NW*64-1:0] sh_wb_q, ef_wb_q;
  logic [NT*NW*32-1:0] sh_ws_q, ef_ws_q;
  logic [NT*NW*3-1:0]  sh_wc_q;          // {W, R, valid}
  logic [NT*NW*3-1:0]  ef_wc_q;
  logic [2:0]          st_prev [NT];

  // ------------------------------------------------------------ flat outputs
  genvar gt, gw;
  generate
    for (gt = 0; gt < NT; gt++) begin : g_out
      assign t_state[gt*3 +: 3]      = st_q[gt];
      assign t_cfg_ok[gt]            = cfg_ok_q[gt];
      assign t_part_base[gt*32 +: 32] = ef_base_q[gt];
      assign t_part_size[gt*32 +: 32] = ef_size_q[gt];
      for (gw = 0; gw < NW; gw++) begin : g_w
        assign t_win_base [(gt*NW+gw)*64 +: 64] = ef_wb_q[(gt*NW+gw)*64 +: 64];
        assign t_win_size [(gt*NW+gw)*32 +: 32] = ef_ws_q[(gt*NW+gw)*32 +: 32];
        assign t_win_valid[gt*NW+gw]            = ef_wc_q[(gt*NW+gw)*3];
        assign t_win_perm [(gt*NW+gw)*2 +: 2]   = ef_wc_q[(gt*NW+gw)*3 + 1 +: 2];
      end
    end
  endgenerate

  // ------------------------------------------------------------ register decode
  wire [3:0] rb_t   = rb_addr[11:8];
  wire [7:0] rb_o   = rb_addr[7:0];
  wire       t_ok   = ({1'b0, rb_t} < 5'(NT));
  wire [TIW-1:0] rb_ti = rb_t[TIW-1:0];
  wire       in_win = (rb_o >= 8'h20) && (rb_o < 8'hA0);
  wire [2:0] rb_w   = 3'((rb_o - 8'h20) >> 4);
  wire [1:0] rb_f   = rb_o[3:2];
  wire       w_ok   = ({1'b0, rb_w} < 4'(NW));
  wire       wr     = rb_sel && rb_we;

  logic [3:0]  cmd_t;
  logic [31:0] cmd_v;
  logic        cmd_valid;
  always_comb begin
    cmd_valid = wr && t_ok && (rb_o == 8'h04);
    cmd_t     = rb_t;
    cmd_v     = rb_wdata;
  end
  wire [TIW-1:0] cmd_ti = cmd_t[TIW-1:0];

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (!t_ok) begin
      rb_err = 1'b1;
    end else if (in_win) begin
      if (!w_ok || rb_o[1:0] != 2'b00) rb_err = 1'b1;
      else begin
        case (rb_f)
          2'd0: rb_rdata = sh_wb_q[(32'(rb_t)*NW + 32'(rb_w))*64 +: 32];
          2'd1: rb_rdata = sh_wb_q[(32'(rb_t)*NW + 32'(rb_w))*64 + 32 +: 32];
          2'd2: rb_rdata = sh_ws_q[(32'(rb_t)*NW + 32'(rb_w))*32 +: 32];
          default: rb_rdata = {29'd0, sh_wc_q[(32'(rb_t)*NW + 32'(rb_w))*3 +: 3]};
        endcase
      end
    end else begin
      case (rb_o)
        8'h00: rb_rdata = {t_inflight[rb_ti*8 +: 8], 8'd0, 7'd0, cfg_ok_q[rb_ti], 5'd0, st_q[rb_ti]};
        8'h04: rb_rdata = 32'd0;
        8'h08: rb_rdata = {24'd0, cfgst_q[rb_ti]};
        8'h0C: rb_rdata = sh_base_q[rb_ti];
        8'h10: rb_rdata = sh_size_q[rb_ti];
        8'h14: rb_rdata = {31'd0, pol_q[rb_ti]};
        8'h18: rb_rdata = viol_q[rb_ti];
        8'h1C: rb_rdata = {24'd0, t_inflight[rb_ti*8 +: 8]};
        default: rb_err = 1'b1;
      endcase
      if (rb_we && (rb_o == 8'h00 || rb_o == 8'h08 || rb_o == 8'h18 || rb_o == 8'h1C)) rb_err = 1'b1;   // RO
      if (!rb_we && rb_o == 8'h04) rb_err = 1'b0;                                                        // WO reads 0
    end
    if (in_win && !(rb_o[1:0] == 2'b00)) rb_err = 1'b1;
  end

  // ------------------------------------------------------------ commit validation
  localparam int CS_IDLE = 0, CS_SCAN = 1;
  logic          cs_q;
  logic [3:0]    cm_t_q;
  logic [4:0]    cm_i_q;

  // shadow checks of the tenant being committed (combinational on cm_t_q)
  wire [TIW-1:0] cm_ti = cm_t_q[TIW-1:0];
  wire [TIW-1:0] cm_ii = cm_i_q[TIW-1:0];
  wire [31:0]  c_base = sh_base_q[cm_ti];
  wire [31:0]  c_size = sh_size_q[cm_ti];
  wire [32:0]  c_end  = {1'b0, c_base} + {1'b0, c_size};
  wire         part_bad = (c_size == 32'd0) || (c_base[7:0] != 8'd0) || (c_size[7:0] != 8'd0) ||
                          (c_end > 33'(SRAM_BYTES));
  logic        win_bad;
  always_comb begin
    win_bad = 1'b0;
    for (int w = 0; w < NW; w++) begin
      if (sh_wc_q[(32'(cm_t_q)*NW + w)*3]) begin
        if (sh_ws_q[(32'(cm_t_q)*NW + w)*32 +: 32] == 32'd0) win_bad = 1'b1;
        if (sh_wb_q[(32'(cm_t_q)*NW + w)*64 +: DLG] != '0)   win_bad = 1'b1;
        if (sh_ws_q[(32'(cm_t_q)*NW + w)*32 +: DLG] != '0)   win_bad = 1'b1;
        if (AW < 64) begin
          if ({1'b0, sh_wb_q[(32'(cm_t_q)*NW + w)*64 +: 64]} + {33'd0, sh_ws_q[(32'(cm_t_q)*NW + w)*32 +: 32]} >
              (65'd1 << AW)) win_bad = 1'b1;
        end
      end
    end
  end

  // overlap of the committing tenant with tenant cm_i_q (claimed, not itself)
  wire [31:0] o_base = ef_base_q[cm_ii];
  wire [31:0] o_size = ef_size_q[cm_ii];
  wire        part_ovl = claimed_q[cm_ii] && (c_base < o_base + o_size) && (o_base < c_base + c_size);
  logic       win_ovl;
  always_comb begin
    win_ovl = 1'b0;
    for (int a = 0; a < NW; a++) begin
      for (int b = 0; b < NW; b++) begin
        if (sh_wc_q[(32'(cm_t_q)*NW + a)*3] && ef_wc_q[(32'(cm_ii)*NW + b)*3] && claimed_q[cm_ii]) begin
          if ({1'b0, sh_wb_q[(32'(cm_t_q)*NW + a)*64 +: 64]} <
                {1'b0, ef_wb_q[(32'(cm_ii)*NW + b)*64 +: 64]} + {33'd0, ef_ws_q[(32'(cm_ii)*NW + b)*32 +: 32]} &&
              {1'b0, ef_wb_q[(32'(cm_ii)*NW + b)*64 +: 64]} <
                {1'b0, sh_wb_q[(32'(cm_t_q)*NW + a)*64 +: 64]} + {33'd0, sh_ws_q[(32'(cm_t_q)*NW + a)*32 +: 32]})
            win_ovl = 1'b1;
        end
      end
    end
  end

  // ------------------------------------------------------------ scrub engine
  logic        sc_act_q;
  logic [3:0]  sc_t_q;
  logic [31:0] sc_addr_q, sc_end_q;
  logic        sc_wait_q;           // request accepted, waiting for the response
  logic [15:0] sc_beats_q;
  logic        sc_done, sc_fail;
  logic [3:0]  sc_pick;
  logic        sc_pick_v;
  wire [TIW-1:0] sc_ti   = sc_t_q[TIW-1:0];
  wire [TIW-1:0] pick_ti = sc_pick[TIW-1:0];
  always_comb begin
    sc_pick   = 4'd0;
    sc_pick_v = 1'b0;
    for (int t = NT - 1; t >= 0; t--) begin
      if (st_q[t] == silicaflux_cloud_pkg::TS_SCRUBBING) begin
        sc_pick   = t[3:0];
        sc_pick_v = 1'b1;
      end
    end
  end
  assign scrub_active = sc_act_q;
  assign scrub_tenant = sc_t_q;
  assign scrub_beats  = sc_beats_q;
  assign sc_req_valid = sc_act_q && !sc_wait_q;
  assign sc_req_write = 1'b1;
  assign sc_req_addr  = sc_addr_q;
  assign sc_req_wdata = '0;
  assign sc_req_wstrb = {DWB{1'b1}};
  assign sc_rsp_ready = 1'b1;
  assign sc_done = sc_act_q && sc_wait_q && sc_rsp_valid && !sc_rsp_error && ((sc_addr_q + DWB[31:0]) >= sc_end_q);
  assign sc_fail = sc_act_q && sc_wait_q && sc_rsp_valid && sc_rsp_error;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sc_act_q   <= 1'b0;
      sc_wait_q  <= 1'b0;
      sc_t_q     <= '0;
      sc_addr_q  <= '0;
      sc_end_q   <= '0;
      sc_beats_q <= '0;
    end else begin
      if (!sc_act_q) begin
        if (sc_pick_v) begin
          sc_act_q   <= 1'b1;
          sc_wait_q  <= 1'b0;
          sc_t_q     <= sc_pick;
          sc_addr_q  <= ef_base_q[pick_ti];
          sc_end_q   <= ef_base_q[pick_ti] + ef_size_q[pick_ti];
          sc_beats_q <= '0;
        end
      end else begin
        if (sc_req_valid && sc_req_ready) sc_wait_q <= 1'b1;
        if (sc_wait_q && dp_resetting) sc_wait_q <= 1'b0;        // the fabric dropped the write: zeroing is idempotent, issue it again
        if (sc_wait_q && sc_rsp_valid) begin
          sc_wait_q  <= 1'b0;
          sc_addr_q  <= sc_addr_q + DWB[31:0];
          sc_beats_q <= sc_beats_q + 16'd1;
          if (sc_done || sc_fail) sc_act_q <= 1'b0;
        end
      end
    end
  end

  // ------------------------------------------------------------ tenant state machines and registers
  wire [TIW-1:0] viol_ti = viol_tenant[TIW-1:0];
  wire cmd_commit  = cmd_valid && (cmd_v == silicaflux_cloud_pkg::TCMD_COMMIT);
  wire cmd_enable  = cmd_valid && (cmd_v == silicaflux_cloud_pkg::TCMD_ENABLE);
  wire cmd_disable = cmd_valid && ((cmd_v == silicaflux_cloud_pkg::TCMD_DISABLE) || (cmd_v == silicaflux_cloud_pkg::TCMD_RECOVER));
  wire cmd_release = cmd_valid && (cmd_v == silicaflux_cloud_pkg::TCMD_RELEASE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cs_q     <= 1'b0;
      cm_t_q   <= '0;
      cm_i_q   <= '0;
      cfg_ok_q <= '0;
      claimed_q <= '0;
      pol_q    <= {NT{1'b1}};
      sh_wb_q  <= '0;  ef_wb_q <= '0;
      sh_ws_q  <= '0;  ef_ws_q <= '0;
      sh_wc_q  <= '0;  ef_wc_q <= '0;
      for (int t = 0; t < NT; t++) begin
        st_q[t]      <= silicaflux_cloud_pkg::TS_DISABLED;
        cfgst_q[t]   <= silicaflux_cloud_pkg::CFG_NONE;
        viol_q[t]    <= 32'd0;
        sh_base_q[t] <= 32'd0;  sh_size_q[t] <= 32'd0;
        ef_base_q[t] <= 32'd0;  ef_size_q[t] <= 32'd0;
      end
    end else begin
      // ---- shadow register writes
      if (wr && t_ok) begin
        if (rb_o == 8'h0C) sh_base_q[rb_ti] <= rb_wdata;
        if (rb_o == 8'h10) sh_size_q[rb_ti] <= rb_wdata;
        if (rb_o == 8'h14) pol_q[rb_ti]     <= rb_wdata[0];
        if (in_win && w_ok && rb_o[1:0] == 2'b00) begin
          case (rb_f)
            2'd0: sh_wb_q[(32'(rb_t)*NW + 32'(rb_w))*64 +: 32]      <= rb_wdata;
            2'd1: sh_wb_q[(32'(rb_t)*NW + 32'(rb_w))*64 + 32 +: 32] <= rb_wdata;
            2'd2: sh_ws_q[(32'(rb_t)*NW + 32'(rb_w))*32 +: 32]      <= rb_wdata;
            default: sh_wc_q[(32'(rb_t)*NW + 32'(rb_w))*3 +: 3]     <= rb_wdata[2:0];
          endcase
        end
      end

      // ---- violations: count, optional quarantine
      if (viol_evt && ({1'b0, viol_tenant} < 5'(NT))) begin
        viol_q[viol_ti] <= viol_q[viol_ti] + 32'd1;
        if (pol_q[viol_ti] && st_q[viol_ti] == silicaflux_cloud_pkg::TS_ACTIVE)
          st_q[viol_ti] <= silicaflux_cloud_pkg::TS_QUARANTINED;
      end

      // ---- draining finishes when nothing of the tenant is in flight
      for (int t = 0; t < NT; t++) begin
        if (st_q[t] == silicaflux_cloud_pkg::TS_DRAINING && t_inflight[t*8 +: 8] == 8'd0)
          st_q[t] <= silicaflux_cloud_pkg::TS_SCRUBBING;
      end

      // ---- scrub completion
      if (sc_done) begin
        st_q[sc_ti]    <= silicaflux_cloud_pkg::TS_DISABLED;
        cfg_ok_q[sc_ti] <= 1'b1;
      end
      if (sc_fail) begin
        st_q[sc_ti]     <= silicaflux_cloud_pkg::TS_DISABLED;
        cfg_ok_q[sc_ti] <= 1'b0;
        claimed_q[sc_ti] <= 1'b0;
        cfgst_q[sc_ti]  <= silicaflux_cloud_pkg::CFG_SCRUB_FAIL;
      end

      // ---- management commands (one tenant per write; commit is a 2-phase scan)
      if (cmd_enable) begin
        if (st_q[cmd_ti] == silicaflux_cloud_pkg::TS_DISABLED && cfg_ok_q[cmd_ti])
          st_q[cmd_ti] <= silicaflux_cloud_pkg::TS_ACTIVE;
      end
      if (cmd_disable) begin
        if (st_q[cmd_ti] == silicaflux_cloud_pkg::TS_ACTIVE || st_q[cmd_ti] == silicaflux_cloud_pkg::TS_QUARANTINED)
          st_q[cmd_ti] <= silicaflux_cloud_pkg::TS_DRAINING;
      end
      if (cmd_release) begin
        if (st_q[cmd_ti] == silicaflux_cloud_pkg::TS_DISABLED) begin
          claimed_q[cmd_ti] <= 1'b0;
          cfg_ok_q[cmd_ti]  <= 1'b0;
          cfgst_q[cmd_ti]   <= silicaflux_cloud_pkg::CFG_NONE;
        end
      end
      if (cmd_commit && cs_q == 1'b0) begin
        if (st_q[cmd_ti] != silicaflux_cloud_pkg::TS_DISABLED) begin
          cfgst_q[cmd_ti] <= silicaflux_cloud_pkg::CFG_BUSY;
        end else begin
          cs_q   <= 1'b1;
          cm_t_q <= cmd_t;
          cm_i_q <= 5'd0;
          cfgst_q[cmd_ti] <= silicaflux_cloud_pkg::CFG_NONE;
        end
      end
      if (cs_q) begin
        if (part_bad) begin
          cs_q <= 1'b0;  cfgst_q[cm_ti] <= silicaflux_cloud_pkg::CFG_BAD_PART;
        end else if (win_bad) begin
          cs_q <= 1'b0;  cfgst_q[cm_ti] <= silicaflux_cloud_pkg::CFG_BAD_WINDOW;
        end else if (cm_i_q < NT[4:0]) begin
          if (cm_i_q[3:0] != cm_t_q && part_ovl) begin
            cs_q <= 1'b0;  cfgst_q[cm_ti] <= silicaflux_cloud_pkg::CFG_OVERLAP_SRAM;
          end else if (cm_i_q[3:0] != cm_t_q && win_ovl) begin
            cs_q <= 1'b0;  cfgst_q[cm_ti] <= silicaflux_cloud_pkg::CFG_OVERLAP_HOST;
          end else begin
            cm_i_q <= cm_i_q + 5'd1;
          end
        end else begin
          // scan finished without conflict: make the shadow configuration effective, then scrub it
          cs_q                <= 1'b0;
          ef_base_q[cm_ti]   <= c_base;
          ef_size_q[cm_ti]   <= c_size;
          for (int w = 0; w < NW; w++) begin
            ef_wb_q[(32'(cm_t_q)*NW + w)*64 +: 64] <= sh_wb_q[(32'(cm_t_q)*NW + w)*64 +: 64];
            ef_ws_q[(32'(cm_t_q)*NW + w)*32 +: 32] <= sh_ws_q[(32'(cm_t_q)*NW + w)*32 +: 32];
            ef_wc_q[(32'(cm_t_q)*NW + w)*3 +: 3]   <= sh_wc_q[(32'(cm_t_q)*NW + w)*3 +: 3];
          end
          claimed_q[cm_ti]   <= 1'b1;
          cfg_ok_q[cm_ti]    <= 1'b0;
          st_q[cm_ti]        <= silicaflux_cloud_pkg::TS_SCRUBBING;
          cfgst_q[cm_ti]     <= silicaflux_cloud_pkg::CFG_OK;
        end
      end
    end
  end

  // ------------------------------------------------------------ state-change event (lowest tenant first)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int t = 0; t < NT; t++) st_prev[t] <= silicaflux_cloud_pkg::TS_DISABLED;
    end else begin
      for (int t = 0; t < NT; t++) st_prev[t] <= st_q[t];
    end
  end
  always_comb begin
    ev_state_valid  = 1'b0;
    ev_state_tenant = 4'd0;
    ev_state_new    = 3'd0;
    for (int t = NT - 1; t >= 0; t--) begin
      if (st_q[t] != st_prev[t]) begin
        ev_state_valid  = 1'b1;
        ev_state_tenant = t[3:0];
        ev_state_new    = st_q[t];
      end
    end
  end
endmodule

`default_nettype wire
