// =============================================================================
// CloudDPU :: sfd_host_guard -- per-beat HOST PERMISSION enforcement for CloudDMA
//
// Every beat that CloudDMA presents to host memory must fall inside one host window of the tenant
// that owns the running job, with the right permission (read for a load, write for a store).  The
// check is on the FINAL address of each beat, independent of the command processor's pre-check:
// a bug or a corrupted descriptor upstream cannot move a byte outside the tenant's windows.
// Window base/size are multiples of the beat size (enforced on tenant COMMIT), so checking the
// whole beat is exact.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_host_guard #(
  parameter int AW = 32,
  parameter int DW = 32,
  parameter int NW = 2
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            m_req_valid,
  output logic                 m_req_ready,
  input  wire logic            m_req_write,
  input  wire logic [AW-1:0]   m_req_addr,
  input  wire logic [DW-1:0]   m_req_wdata,
  input  wire logic [DW/8-1:0] m_req_wstrb,
  output logic                 m_rsp_valid,
  input  wire logic            m_rsp_ready,
  output logic [DW-1:0]        m_rsp_rdata,
  output logic                 m_rsp_error,
  output logic                 s_req_valid,
  input  wire logic            s_req_ready,
  output logic                 s_req_write,
  output logic [AW-1:0]        s_req_addr,
  output logic [DW-1:0]        s_req_wdata,
  output logic [DW/8-1:0]      s_req_wstrb,
  input  wire logic            s_rsp_valid,
  output logic                 s_rsp_ready,
  input  wire logic [DW-1:0]   s_rsp_rdata,
  input  wire logic            s_rsp_error,
  // the running job's tenant
  input  wire logic            job_active,
  input  wire logic [NW*64-1:0] win_base,
  input  wire logic [NW*32-1:0] win_size,
  input  wire logic [NW-1:0]   win_valid,
  input  wire logic [NW*2-1:0] win_perm,
  output logic                 allow_o,       // combinational verdict for the request being presented
  output logic                 viol_evt,
  output logic [AW-1:0]        viol_addr
);
  localparam logic [31:0] DWB32 = DW / 8;
  logic ok;
  sfd_win_check #(.NW(NW)) u_chk (
    .win_base, .win_size, .win_valid, .win_perm,
    .addr({{(64-AW){1'b0}}, m_req_addr}), .len(DWB32),
    .need_r(!m_req_write), .need_w(m_req_write), .ok
  );
  wire allow = job_active && ok;
  assign allow_o = allow;

  sfd_sfb_gate #(.AW(AW), .DW(DW)) u_gate (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .allow, .blk_evt(viol_evt)
  );
  assign viol_addr = m_req_addr;
endmodule

`default_nettype wire
