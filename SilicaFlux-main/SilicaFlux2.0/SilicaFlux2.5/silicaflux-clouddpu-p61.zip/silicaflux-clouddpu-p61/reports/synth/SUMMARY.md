# CloudDPU generic synthesis (Yosys 0.33, technology independent, NO PDK)

Cell counts are of a generic AND/NAND/OR/NOR/XOR/XNOR/MUX/NOT + flip-flop netlist after `abc`; they are NOT area, frequency or power claims.
`Memories` counts `$mem_v2` blocks left unmapped (SRAM arrays and FIFO storage).  Latches: `$dlatch`/`$adlatch` cells (the ControlCore clock-gate latch is bypassed by SFV_NO_CLOCK_GATE).
Every run passes `check -assert` (the last column is the number of problems it reported).

| Name | Top | Parameters | Generic cells | Flip-flops | Memories | Latches | `check` problems |
|---|---|---|---|---|---|---|---|
| min | silicaflux_cloud_dpu |  | 67666 | 8147 | 16 | 0 | 0 |
| controlcore | silicaflux_control_core |  | 29183 | 3886 | 7 | 0 | 0 |
| mt | silicaflux_cloud_dpu | NUM_TENANTS=2 NUM_NETWORK_QUEUES=2 NUM_DMA_CHANNELS=2 NUM_SRAM_BANKS=2 | 81741 | 9842 | 20 | 0 | 0 |
| w64 | silicaflux_cloud_dpu | DATA_WIDTH=64 ADDRESS_WIDTH=40 NUM_NETWORK_QUEUES=2 NUM_DMA_CHANNELS=2 NUM_SRAM_BANKS=2 | 79694 | 9244 | 20 | 0 | 0 |
| w128 | silicaflux_cloud_dpu | NUM_TENANTS=4 NUM_NETWORK_QUEUES=4 NUM_COMPUTE_QUEUES=2 NUM_DMA_CHANNELS=3 DATA_WIDTH=128 ADDRESS_WIDTH=64 NUM_WINDOWS=4 NUM_SRAM_BANKS=4 SRAM_CAPACITY=131072 QUEUE_DEPTH=3 CPLQ_DEPTH=3 | 168422 | 15387 | 30 | 0 | 0 |
