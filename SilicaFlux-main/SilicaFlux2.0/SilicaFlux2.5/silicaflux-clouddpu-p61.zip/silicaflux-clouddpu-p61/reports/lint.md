# Lint and elaboration checks

Verilator 5.020 `-Wall`, vendored files waived by file path only (`scripts/vendored_waivers.vlt`).

| Kind | Configuration | Result |
|---|---|---|
| lint | min (defaults) | PASS (0 warnings) |
| lint | 2 tenants, 2 net queues, 2 channels, 2 banks, 64-bit | PASS (0 warnings) |
| lint | 4 tenants, 6 queues, 3 channels, 128-bit, 48-bit address | PASS (0 warnings) |
| lint | 16 tenants, 15 queues, 8 channels, 64-bit address | PASS (0 warnings) |
| lint | no compute queue, depth 1 | PASS (0 warnings) |
| lint | min + simulation-only assertions (sfd_assertions) | PASS (0 warnings) |
| lint | AXI4 wrapper (silicaflux_cloud_dpu_axi), min | PASS (0 warnings) |
| lint | AXI4 wrapper (silicaflux_cloud_dpu_axi), 64-bit data, 40-bit address, 2 channels | PASS (0 warnings) |
| negative | ENABLE_TENSOR=1 | REFUSED at elaboration |
| negative | ENABLE_CRYPTO=1 | REFUSED at elaboration |
| negative | ENABLE_STORAGE=1 | REFUSED at elaboration |
| negative | 17 tenants | REFUSED at elaboration |
| negative | 0 tenants | REFUSED at elaboration |
| negative | 0 network queues | REFUSED at elaboration |
| negative | 16 queues | REFUSED at elaboration |
| negative | 9 channels | REFUSED at elaboration |
| negative | DATA_WIDTH=48 | REFUSED at elaboration |
| negative | ADDRESS_WIDTH=24 | REFUSED at elaboration |
| negative | 9 windows | REFUSED at elaboration |
| negative | SRAM not a multiple of 256 | REFUSED at elaboration |
| negative | bank not a power of two | REFUSED at elaboration |
| negative | MAX_XFER below one beat | REFUSED at elaboration |
| negative | queue depth 0 | REFUSED at elaboration |

**23 checks, 0 problems.**
