/* =============================================================================
 * SilicaFlux CloudDPU firmware -- self-test, run by the ControlCore CPU on the RTL.
 *
 * The tests drive the DPU only through its register pages and the management queue and check three things
 * independently of the DPU: (1) completion records, (2) bytes in the local SRAM, which the CPU can read through the
 * EXT window (a C reference model of the PacketCore test adapter recomputes the transform, CRC-32 and RFC 1071
 * checksum from the staged input buffer), (3) interrupt delivery.  The host side of the transaction (host memory)
 * is checked by the simulation testbench, which owns it.
 * Groups (DST_*): ID, MMIO, PKT, ERR, PERM, PERF, RESET, IRQ.
 * ===========================================================================*/
#include "dpu_hw.h"

tally_t g_tally;
uint32_t g_host_in, g_host_out, g_sram_part;
static uint32_t g_tenant;
static uint32_t g_tag = 0xF0000000u;

void check(int ok, uint32_t id, uint32_t got, uint32_t exp) {
  g_tally.checks++;
  if (!ok) {
    g_tally.fails++;
    cprintf("  CHECK FAIL id=%x got=%08x exp=%08x\n", id, got, exp);
  }
}
void dpu_selftest_set_env(uint32_t t, uint32_t in_base, uint32_t out_base, uint32_t part) {
  g_tenant = t; g_host_in = in_base; g_host_out = out_base; g_sram_part = part;
}

/* ---------------------------------------------------------------- C reference of the PacketCore test adapter */
static uint32_t crc32_ref(const uint8_t *p, uint32_t n) {
  uint32_t c = 0xFFFFFFFFu;
  for (uint32_t i = 0; i < n; i++) {
    c ^= p[i];
    for (int k = 0; k < 8; k++) c = (c & 1u) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
  }
  return ~c;
}
static uint16_t csum_ref(const uint8_t *p, uint32_t n) {
  uint32_t s = 0;
  for (uint32_t i = 0; i < n; i += 2) s += ((uint32_t)p[i] << 8) | ((i + 1 < n) ? p[i + 1] : 0u);
  while (s >> 16) s = (s & 0xFFFFu) + (s >> 16);
  return (uint16_t)~s;
}
static void proc_ref(uint32_t op, uint32_t key, const uint8_t *in, uint8_t *out, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) {
    uint8_t b = in[i];
    if (op == SFC_PROC_XOR32) b ^= (uint8_t)(key >> (8u * (i & 3u)));
    else if (op == SFC_PROC_BSWAP32) b = in[(i & ~3u) + (3u - (i & 3u))];
    out[i] = b;
  }
}

/* read bytes of the local SRAM through the EXT window (word reads) */
static void sram_read(uint32_t off, uint8_t *dst, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) {
    uint32_t w = DPU_SRAM((off + i) & ~3u);
    dst[i] = (uint8_t)(w >> (8u * ((off + i) & 3u)));
  }
}
static uint32_t sram_nonzero_words(uint32_t off, uint32_t bytes) {
  uint32_t nz = 0;
  for (uint32_t a = off; a < off + bytes; a += 4u) if (DPU_SRAM(a)) nz++;
  return nz;
}

static uint8_t g_in[1536], g_out[1536], g_exp[1536];
static uint32_t beat_bytes(void) { return (DPU_G(DPU_G_CONFIG1) & 0xFFFFu) / 8u; }
static uint32_t round_up(uint32_t v, uint32_t a) { return (v + a - 1u) / a * a; }

static int run_cmd(uint32_t op, uint32_t tenant, uint32_t src, uint32_t dst, uint32_t len, uint32_t soff, uint32_t pop,
                   uint32_t param, dpu_cpl_t *c, uint32_t *tag_out) {
  dpu_desc_t d;
  uint32_t tag = ++g_tag;
  dpu_desc_init(&d, op, tenant, tag, src, dst, len, soff, pop, param);
  if (tag_out) *tag_out = tag;
  return dpu_mgmt_run(&d, c);
}

/* ---------------------------------------------------------------- groups */
static void t_id(void) {
  CHECK_EQ(0x0101, DPU_G(DPU_G_ID), SFC_DPU_ID_MAGIC);
  CHECK_EQ(0x0102, DPU_G(DPU_G_VERSION), (SFC_DPU_ABI_MAJOR << 16) | SFC_DPU_ABI_MINOR);
  uint32_t c0 = DPU_G(DPU_G_CONFIG0);
  CHECK_TRUE(0x0103, (c0 & 0xFFu) >= 1u && ((c0 >> 8) & 0xFFu) >= 1u && ((c0 >> 24) & 0xFFu) >= 1u);
  CHECK_TRUE(0x0104, (DPU_G(DPU_G_FEATURES) >> 3) & 1u);                       /* permission enforcement always on */
  uint32_t b = DPU_G(DPU_G_BLOCK_STATUS);
  CHECK_EQ(0x0105, (b >> 6) & 3u, SFC_BLK_BLOCKED);                            /* InferenceScheduler */
  CHECK_EQ(0x0106, (b >> 8) & 3u, SFC_BLK_BLOCKED);                            /* CryptoCore */
  CHECK_EQ(0x0107, (b >> 10) & 3u, SFC_BLK_BLOCKED);                           /* StorageFabric */
  CHECK_EQ(0x0108, b & 3u, SFC_BLK_TEST_ADAPTER);                              /* PacketCore */
  CHECK_EQ(0x0109, SYSCTRL(CC_SYSCTRL_ID), 0x53464343u);                       /* ControlCore "SFCC" */
}

static void t_mmio(void) {
  uint32_t save = DPU_G(DPU_G_SCRATCH);
  DPU_G(DPU_G_SCRATCH) = 0x55AA55AAu;  CHECK_EQ(0x0201, DPU_G(DPU_G_SCRATCH), 0x55AA55AAu);
  DPU_G(DPU_G_SCRATCH) = 0xA5A5A5A5u;  CHECK_EQ(0x0202, DPU_G(DPU_G_SCRATCH), 0xA5A5A5A5u);
  DPU_G(DPU_G_SCRATCH) = save;
  CHECK_EQ(0x0203, probe_wr(DPU_GLOBAL_PAGE_BASE + DPU_G_ID, 1u), 7u);        /* store access fault: ID is read-only */
  CHECK_EQ(0x0204, probe_rd(DPU_GLOBAL_PAGE_BASE + 0x0F0u, 0), 5u);            /* load access fault: unmapped offset */
  CHECK_EQ(0x0205, probe_wr(DPU_DEBUG_PAGE_BASE + DPU_D_SLOT0, 1u), 7u);      /* DEBUG page is read-only */
  CHECK_EQ(0x0206, probe_rd(DPU_SRAM_EXT_BASE + DPU_G(DPU_G_SRAM_BYTES), 0), 5u); /* beyond the local SRAM */
  uint32_t v = 0;
  CHECK_EQ(0x0207, probe_rd(DPU_GLOBAL_PAGE_BASE + DPU_G_ID, &v), 0u);
  CHECK_EQ(0x0208, v, SFC_DPU_ID_MAGIC);
}

static void t_pkt(void) {
  static const struct { uint32_t pop, len, key; } cases[] = {
    {SFC_PROC_PASS, 64, 0}, {SFC_PROC_XOR32, 61, 0xC3A5F00Fu}, {SFC_PROC_BSWAP32, 128, 0},
    {SFC_PROC_XOR32, 1, 0x000000FFu}, {SFC_PROC_PASS, 1500, 0}, {SFC_PROC_BSWAP32, 1496, 0},
  };
  uint32_t bb = beat_bytes();
  uint32_t part_base = DPU_T(g_tenant, DPU_T_SRAM_BASE);
  for (unsigned i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
    dpu_cpl_t c;
    uint32_t tag, len = cases[i].len, soff = 0, len_al = round_up(len, bb);
    int rc = run_cmd(SFC_OP_PKT_PROCESS, g_tenant, g_host_in + 64u * i, g_host_out + 2048u * i, len, soff, cases[i].pop, cases[i].key, &c, &tag);
    CHECK_EQ(0x0300 + i, rc, 0);
    if (rc) continue;
    CHECK_EQ(0x0310 + i, CPL_STATUS(&c), SFC_ST_OK);
    CHECK_EQ(0x0320 + i, CPL_ERR(&c), SFC_ERR_NONE);
    CHECK_EQ(0x0330 + i, CPL_TAG(&c), tag);
    CHECK_EQ(0x0340 + i, CPL_QUEUE(&c), SFC_MGMT_QUEUE_ID);
    CHECK_EQ(0x0350 + i, CPL_COMMITTED(&c), 1u);
    CHECK_EQ(0x0360 + i, CPL_BYTES(&c), len);
    /* the staged buffers live in the tenant's SRAM partition: recompute everything independently */
    sram_read(part_base + soff, g_in, len);
    sram_read(part_base + soff + len_al, g_out, len);
    proc_ref(cases[i].pop, cases[i].key, g_in, g_exp, len);
    uint32_t bad = 0;
    for (uint32_t k = 0; k < len; k++) if (g_out[k] != g_exp[k]) bad++;
    CHECK_EQ(0x0370 + i, bad, 0u);
    CHECK_EQ(0x0380 + i, CPL_CRC_IN(&c), crc32_ref(g_in, len));
    CHECK_EQ(0x0390 + i, CPL_CRC_OUT(&c), crc32_ref(g_exp, len));
    CHECK_EQ(0x03A0 + i, CPL_CSUM(&c), csum_ref(g_exp, len));
  }
}

static void t_err(void) {
  dpu_cpl_t c;
  uint32_t fe_saved = DPU_G(DPU_G_FAULT_ENABLE);
  DPU_G(DPU_G_FAULT_ENABLE) = (1u << SFC_FLT_DESC_ERR);
  (void)dpu_fault_take();
  uint32_t irq0 = g_fault_irqs;
  CHECK_EQ(0x0400, run_cmd(0x77, g_tenant, 0, 0, 0, 0, 0, 0, &c, 0), 0);
  CHECK_EQ(0x0401, CPL_ERR(&c), SFC_ERR_BAD_OPCODE);
  CHECK_EQ(0x0402, CPL_STATUS(&c), SFC_ST_ERROR);
  CHECK_EQ(0x0403, CPL_COMMITTED(&c), 0u);
  CHECK_EQ(0x0404, run_cmd(SFC_OP_PKT_PROCESS, g_tenant, g_host_in, g_host_out, 0, 0, 0, 0, &c, 0), 0);
  CHECK_EQ(0x0405, CPL_ERR(&c), SFC_ERR_BAD_LENGTH);
  CHECK_EQ(0x0406, run_cmd(SFC_OP_NOP, 9u, 0, 0, 0, 0, 0, 0, &c, 0), 0);
  CHECK_EQ(0x0407, CPL_ERR(&c), SFC_ERR_BAD_TENANT);
  CHECK_EQ(0x0408, run_cmd(SFC_OP_INFER, g_tenant, 0, 0, 0, 0, 0, 0, &c, 0), 0);
  CHECK_EQ(0x0409, CPL_ERR(&c), SFC_ERR_BLOCKED);                              /* engine classes stay blocked */
  CHECK_EQ(0x040A, run_cmd(SFC_OP_CRYPTO, g_tenant, 0, 0, 0, 0, 0, 0, &c, 0), 0);
  CHECK_EQ(0x040B, CPL_ERR(&c), SFC_ERR_BLOCKED);
  /* the fault interrupt must have been delivered, and the capture registers describe the last fault */
  for (volatile int i = 0; i < 2000 && g_fault_irqs == irq0; i++) ;
  CHECK_TRUE(0x040C, g_fault_irqs != irq0);
  CHECK_TRUE(0x040D, (g_fault_bits >> SFC_FLT_DESC_ERR) & 1u);
  CHECK_EQ(0x040E, DPU_G(DPU_G_FAULT_STATUS) & (1u << SFC_FLT_DESC_ERR), 0u);   /* the ISR cleared it (W1C) */
  (void)dpu_fault_take();
  DPU_G(DPU_G_FAULT_ENABLE) = fe_saved;
}

static void t_perm(void) {
  dpu_cpl_t c;
  uint32_t part_base = DPU_T(g_tenant, DPU_T_SRAM_BASE);
  uint32_t fe_saved = DPU_G(DPU_G_FAULT_ENABLE);
  DPU_G(DPU_G_FAULT_ENABLE) = (1u << SFC_FLT_PERM_VIOL);
  (void)dpu_fault_take();
  uint32_t v0 = DPU_T(g_tenant, DPU_T_VIOL_COUNT);
  /* an access outside every window of the tenant: refused, no data moves, the tenant is quarantined */
  CHECK_EQ(0x0500, run_cmd(SFC_OP_PKT_PROCESS, g_tenant, g_host_in + 0x100000u, g_host_out, 64, 0, SFC_PROC_PASS, 0, &c, 0), 0);
  CHECK_EQ(0x0501, CPL_ERR(&c), SFC_ERR_PERM_READ);
  CHECK_EQ(0x0502, CPL_COMMITTED(&c), 0u);
  CHECK_EQ(0x0503, dpu_tenant_state(g_tenant), SFC_TS_QUARANTINED);
  CHECK_EQ(0x0504, DPU_T(g_tenant, DPU_T_VIOL_COUNT), v0 + 1u);
  CHECK_EQ(0x0505, run_cmd(SFC_OP_NOP, g_tenant, 0, 0, 0, 0, 0, 0, &c, 0), 0);
  CHECK_EQ(0x0506, CPL_ERR(&c), SFC_ERR_QUARANTINED);
  for (volatile int i = 0; i < 2000 && !((g_fault_bits >> SFC_FLT_PERM_VIOL) & 1u); i++) ;
  CHECK_TRUE(0x0507, (g_fault_bits >> SFC_FLT_PERM_VIOL) & 1u);
  CHECK_EQ(0x0508, g_last_fault_err, SFC_ERR_PERM_READ);
  /* fill the staging area so that the recovery scrub has something to erase */
  CHECK_EQ(0x0509, dpu_tenant_recover(g_tenant), SFC_TS_ACTIVE);
  CHECK_EQ(0x050A, sram_nonzero_words(part_base, g_sram_part < 8192u ? g_sram_part : 8192u), 0u);  /* scrubbed */
  CHECK_EQ(0x050B, run_cmd(SFC_OP_NOP, g_tenant, 0, 0, 0, 0, 0, 0, &c, 0), 0);
  CHECK_EQ(0x050C, CPL_STATUS(&c), SFC_ST_OK);                                  /* re-admitted */
  /* destination in the read-only window */
  CHECK_EQ(0x050D, run_cmd(SFC_OP_PKT_PROCESS, g_tenant, g_host_in, g_host_in + 0x1000u, 64, 0, SFC_PROC_PASS, 0, &c, 0), 0);
  CHECK_EQ(0x050E, CPL_ERR(&c), SFC_ERR_PERM_WRITE);
  CHECK_EQ(0x050F, dpu_tenant_recover(g_tenant), SFC_TS_ACTIVE);
  /* SRAM buffers beyond the partition */
  CHECK_EQ(0x0510, run_cmd(SFC_OP_PKT_PROCESS, g_tenant, g_host_in, g_host_out, 64, g_sram_part - 64u, SFC_PROC_PASS, 0, &c, 0), 0);
  CHECK_EQ(0x0511, CPL_ERR(&c), SFC_ERR_SRAM_RANGE);
  CHECK_EQ(0x0512, dpu_tenant_recover(g_tenant), SFC_TS_ACTIVE);
  (void)dpu_fault_take();
  DPU_G(DPU_G_FAULT_ENABLE) = fe_saved;
}

static void t_perf(void) {
  uint32_t acc = DPU_P(DPU_P_CNT0 + 8u * 0u), ret = DPU_P(DPU_P_CNT0 + 8u * 1u), err = DPU_P(DPU_P_CNT0 + 8u * 2u);
  CHECK_TRUE(0x0600, acc > 0u);
  CHECK_EQ(0x0601, acc, ret);                                                   /* every accepted command was retired */
  CHECK_TRUE(0x0602, err > 0u && err < ret);
  CHECK_TRUE(0x0603, DPU_P(DPU_P_CNT0 + 8u * 12u) >= 3u);                       /* the isolation violations above */
  CHECK_TRUE(0x0604, DPU_P(DPU_P_CNT0 + 8u * 3u) > 0u);                         /* DMA_BYTES_RD */
  uint32_t t0 = DPU_G(DPU_G_TIME_LO);
  for (volatile int i = 0; i < 100; i++) ;
  CHECK_TRUE(0x0605, DPU_G(DPU_G_TIME_LO) != t0);
  DPU_P(DPU_P_CTRL) = 2u;                                                       /* CLEAR */
  DPU_P(DPU_P_CTRL) = 0u;
  CHECK_TRUE(0x0606, DPU_P(DPU_P_CNT0 + 8u * 0u) == 0u);
}

static void t_reset(void) {
  dpu_cpl_t c;
  uint32_t n0 = DPU_G(DPU_G_DP_RESETS);
  dpu_dp_reset();
  CHECK_EQ(0x0700, DPU_G(DPU_G_DP_RESETS), n0 + 1u);
  CHECK_EQ(0x0701, DPU_G(DPU_G_STATUS) & 2u, 0u);                               /* not halted */
  CHECK_EQ(0x0702, dpu_tenant_state(g_tenant), SFC_TS_ACTIVE);                  /* tenant configuration survives */
  CHECK_EQ(0x0703, run_cmd(SFC_OP_PKT_PROCESS, g_tenant, g_host_in, g_host_out + 0x8000u, 100, 0, SFC_PROC_XOR32, 0x01020304u, &c, 0), 0);
  CHECK_EQ(0x0704, CPL_STATUS(&c), SFC_ST_OK);
}

static void t_irq(void) {
  CHECK_TRUE(0x0800, g_event_irqs > 0u);
  CHECK_TRUE(0x0801, g_fault_irqs > 0u);
  CHECK_EQ(0x0802, DPU_G(DPU_G_IRQ_ENABLE), 0u);                                /* masked between waits */
  CHECK_EQ(0x0803, (INTC(CC_INTC_PENDING) >> DPU_IRQ_EVENT) & 1u, 0u);          /* no completion left behind */
}

uint32_t dpu_selftest_run(uint32_t mask) {
  uint32_t f0 = g_tally.fails;
  if (mask & DST_ID)    { cprintf("[dpu-st] ID\n");    t_id(); }
  if (mask & DST_MMIO)  { cprintf("[dpu-st] MMIO\n");  t_mmio(); }
  if (mask & DST_PKT)   { cprintf("[dpu-st] PKT\n");   t_pkt(); }
  if (mask & DST_ERR)   { cprintf("[dpu-st] ERR\n");   t_err(); }
  if (mask & DST_PERM)  { cprintf("[dpu-st] PERM\n");  t_perm(); }
  if (mask & DST_PERF)  { cprintf("[dpu-st] PERF\n");  t_perf(); }
  if (mask & DST_RESET) { cprintf("[dpu-st] RESET\n"); t_reset(); }
  if (mask & DST_IRQ)   { cprintf("[dpu-st] IRQ\n");   t_irq(); }
  return g_tally.fails - f0;
}
