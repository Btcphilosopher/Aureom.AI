/* =============================================================================
 * SilicaFlux CloudDPU firmware -- platform layer
 *   trap handler (exceptions, machine external interrupts by INTC claim), expected-trap probes, interrupt setup,
 *   the two DPU interrupt service routines and the host mailbox ISR.
 *
 * Interrupt model: level-sensitive sources; the ISR of source s removes the cause AT THE SOURCE (that is the
 * acknowledgement), the dispatcher claims again until INTC.CLAIM = 0.  Traps are not nested (MIE = 0 in a trap).
 *   DPU_EVENT  management completion queue not empty.  The ISR only notes it and MASKS the source; the consumer
 *              pops the record(s) and unmasks (a level source cannot be acknowledged any other way).
 *   DPU_FAULT  FAULT_STATUS & FAULT_ENABLE.  The ISR accumulates the sticky bits and the last-fault capture into
 *              g_fault_*, then clears them with W1C: that drops the level.
 * ===========================================================================*/
#include "dpu_hw.h"

static expect_t g_expect;
volatile uint32_t g_cmd[8], g_cmd_pending, g_cmd_seq;
volatile uint32_t g_event_irqs, g_fault_irqs, g_fault_bits, g_fault_count, g_last_fault_tenant, g_last_fault_err;
volatile uint32_t g_last_fault_addr;
static void (*isr_table[16])(void);

uint32_t cycles(void) { return csr_read(mcycle); }

/* ---------------------------------------------------------------- expected-trap probes */
static void expect_arm(void) { g_expect.cause = 0; g_expect.armed = 1; __asm__ volatile("" ::: "memory"); }
static uint32_t expect_result(void) { __asm__ volatile("" ::: "memory"); g_expect.armed = 0; return g_expect.cause; }
uint32_t probe_wr(uint32_t addr, uint32_t val) {
  expect_arm();
  __asm__ volatile("sw %0, 0(%1)" ::"r"(val), "r"(addr) : "memory");
  return expect_result();
}
uint32_t probe_rd(uint32_t addr, uint32_t *val) {
  uint32_t v = 0xDEADBEEFu;
  expect_arm();
  __asm__ volatile("lw %0, 0(%1)" : "+r"(v) : "r"(addr) : "memory");
  uint32_t c = expect_result();
  if (val) *val = v;
  return c;
}

/* ---------------------------------------------------------------- interrupt service routines */
static void isr_dpu_event(void) {
  g_event_irqs++;
  DPU_G(DPU_G_IRQ_ENABLE) = 0u;                         /* mask the level source until the consumer popped the record */
}
static void isr_dpu_fault(void) {
  uint32_t st = DPU_G(DPU_G_FAULT_STATUS);
  g_fault_bits |= st;
  g_fault_count++;
  g_fault_irqs++;
  g_last_fault_tenant = DPU_G(DPU_G_FAULT_TENANT);
  g_last_fault_err    = DPU_G(DPU_G_FAULT_ERR);
  g_last_fault_addr   = DPU_G(DPU_G_FAULT_ADDR_LO);
  DPU_G(DPU_G_FAULT_STATUS) = st;                       /* W1C: drops the level */
  (void)DPU_G(DPU_G_FAULT_STATUS);
}
static void isr_ras_warn(void) {                        /* DPU faults routed to the ControlCore RAS block */
  uint32_t st = RAS(CC_RAS_STATUS) & 0xFFu;
  uint32_t lvl = st & (1u << CC_RAS_SRC_EXT_WARN);
  if (lvl) RAS(CC_RAS_WARN_EN) = RAS(CC_RAS_WARN_EN) & ~lvl;   /* level input: mask until the owner clears the cause */
  RAS(CC_RAS_STATUS) = st;
  (void)RAS(CC_RAS_STATUS);
}
static void isr_host(void) {
  for (int i = 0; i < 8; i++) g_cmd[i] = MBOX_H2F(i);
  MBOX(CC_MBOX_H2F_ACK) = 0u;
  (void)MBOX(CC_MBOX_DB_STATUS);
  g_cmd_pending++;
}

static void dispatch_ext(void) {
  uint32_t id, guard = 0;
  while ((id = INTC(CC_INTC_CLAIM)) != 0u) {
    uint32_t s = id - 1u;
    if (isr_table[s]) isr_table[s]();
    if (++guard > 64u || !isr_table[s]) {                 /* a source that cannot be cleared is masked, not allowed to storm */
      INTC(CC_INTC_ENABLE) = INTC(CC_INTC_ENABLE) & ~(1u << s);
      guard = 0;
    }
  }
}

static void fatal_trap(uint32_t cause, uint32_t epc, uint32_t tval) {
  cprintf("\n[FATAL] unexpected trap mcause=%08x mepc=%08x mtval=%08x\n", cause, epc, tval);
  boot_stage(CC_BOOT_STAGE_FATAL);
  SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0xC0000000u | 0xDEADu;
  for (;;) wfi();
}

void trap_handler(trap_frame_t *f) {
  uint32_t cause = csr_read(mcause);
  if (cause & MCAUSE_INT) {
    if ((cause & 0x1Fu) == 11u) dispatch_ext();
    return;
  }
  uint32_t tval = csr_read(mtval);
  if (g_expect.armed) {                                  /* a bus error on a probed access: record it, skip the instruction */
    g_expect.cause = cause;
    g_expect.count++;
    g_expect.armed = 0;
    f->mepc = f->mepc + 4u;
    return;
  }
  fatal_trap(cause, f->mepc, tval);
}

void platform_init(void) {
  isr_table[CC_IRQ_RAS_WARN] = isr_ras_warn;
  isr_table[DPU_IRQ_EVENT]   = isr_dpu_event;
  isr_table[DPU_IRQ_FAULT]   = isr_dpu_fault;
  isr_table[CC_IRQ_HOST]     = isr_host;
  INTC(CC_INTC_ENABLE) = 0u;
  INTC(CC_INTC_SWPEND) = 0u;
  INTC(CC_INTC_PRIO0) = (CC_IRQ_RAS_WARN_PRIO << (4 * CC_IRQ_RAS_WARN)) | (CC_IRQ_VECTOR_PRIO << (4 * DPU_IRQ_EVENT)) |
                        (CC_IRQ_TENSOR_PRIO << (4 * DPU_IRQ_FAULT)) | (CC_IRQ_HOST_PRIO << (4 * CC_IRQ_HOST));
  INTC(CC_INTC_PRIO1) = 0u;
  INTC(CC_INTC_THRESHOLD) = 0u;
  RAS(CC_RAS_STATUS) = 0xFFFFu;
  RAS(CC_RAS_WARN_EN) = 0x7Fu;
  RAS(CC_RAS_CTRL) = 0x1u | 0x4u;
  INTC(CC_INTC_ENABLE) = (1u << CC_IRQ_RAS_WARN) | (1u << DPU_IRQ_EVENT) | (1u << DPU_IRQ_FAULT) | (1u << CC_IRQ_HOST);
  csr_write(mie, MIE_MEIE);
  irq_enable();
}
