/* =============================================================================
 * SilicaFlux CloudDPU firmware -- main: boot stages + host command processor
 *
 * Boot (continuing the ControlCore boot ROM's stages, all visible in SYSCTRL.BOOT_STAGE):
 *   FW_INIT         reset cause, interrupt controller, RAS
 *   ACC_DISCOVERY   identify the DPU (ID, ABI, configuration, block status); refuse to run on a mismatch
 *   SELF_TEST       power-on test: scratch register, one management-queue round trip BY INTERRUPT
 *                   (a NOP for a not yet configured tenant must come back as ERR_TENANT_STATE: the command path
 *                   is alive and the isolation rule holds before anything is configured)
 *   CMDPROC_READY   host write lock set, mailbox command processor running
 *   HOST_READY      DPU identification published, host told
 * The firmware does not require, and does not run, Linux.  Then: sleep (WFI) until the host interrupt delivers a
 * mailbox command; answer in F2H_MSG0..7 and ring F2H.  Response: F2H_MSG0 = status | cmd << 8 | seq << 16.
 * ===========================================================================*/
#include "dpu_hw.h"

static void respond(uint32_t cmd, uint32_t sts, const uint32_t *d, int n) {
  for (int i = 0; i < n && i < 7; i++) MBOX_F2H(1 + i) = d[i];
  MBOX_F2H(0) = sts | (cmd << 8) | ((g_cmd_seq & 0xFFFFu) << 16);
  MBOX(CC_MBOX_F2H_RING) = cmd;
}

static int post(void) {
  int fails = 0;
  dpu_cpl_t c;
  dpu_desc_t d;
  uint32_t save = DPU_G(DPU_G_SCRATCH);
  DPU_G(DPU_G_SCRATCH) = 0xC0DEF00Du;
  if (DPU_G(DPU_G_SCRATCH) != 0xC0DEF00Du) fails++;
  DPU_G(DPU_G_SCRATCH) = save;
  dpu_desc_init(&d, SFC_OP_NOP, 0u, 0xB007u, 0, 0, 0, 0, 0, 0);
  if (dpu_mgmt_run(&d, &c) || CPL_STATUS(&c) != SFC_ST_ERROR || CPL_ERR(&c) != SFC_ERR_TENANT_STATE ||
      CPL_TAG(&c) != 0xB007u || g_event_irqs == 0u)
    fails++;
  return fails;
}

int main(void) {
  boot_stage(CC_BOOT_STAGE_FW_INIT);
  uint32_t reset_cause = SYSCTRL(CC_SYSCTRL_RESET_CAUSE);
  SYSCTRL(CC_SYSCTRL_RESET_CAUSE) = 0xFu;
  SYSCTRL(CC_SYSCTRL_FW_VERSION) = FW_VERSION;
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING;
  cprintf("\nSilicaFlux CloudDPU firmware %x.%x  (RV32IM, misa=%08x)\n", FW_VERSION >> 16, FW_VERSION & 0xFFFFu, csr_read(misa));
  cprintf("reset cause=%x  image crc=%08x (integrity only, NOT authenticated)\n", reset_cause, SEC(CC_SEC_BOOT_MEASURE));
  platform_init();

  boot_stage(CC_BOOT_STAGE_ACC_DISCOVERY);
  uint32_t id = DPU_G(DPU_G_ID), ver = DPU_G(DPU_G_VERSION);
  if (id != SFC_DPU_ID_MAGIC || (ver >> 16) != SFC_DPU_ABI_MAJOR) {
    cprintf("DPU NOT RECOGNISED id=%08x version=%08x\n", id, ver);
    boot_stage(CC_BOOT_STAGE_BOOT_ERROR);
    SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0xC0000000u | 0xD001u;
    for (;;) wfi();
  }
  uint32_t c0 = DPU_G(DPU_G_CONFIG0), c1 = DPU_G(DPU_G_CONFIG1), blk = DPU_G(DPU_G_BLOCK_STATUS);
  cprintf("DPU ABI %u.%u: %u tenants, %u net + %u compute queues, %u DMA channels, %u-bit data, %u-bit addr, SRAM %u KiB\n",
          ver >> 16, ver & 0xFFFFu, c0 & 0xFFu, (c0 >> 8) & 0xFFu, (c0 >> 16) & 0xFFu, c0 >> 24, c1 & 0xFFFFu,
          (c1 >> 16) & 0xFFu, DPU_G(DPU_G_SRAM_BYTES) >> 10);
  cprintf("blocks: packetcore=%u clouddma=%u virtualio=%u inference=%u crypto=%u storage=%u telemetry=%u (0 absent 1 blocked 2 test-adapter 3 real)\n",
          blk & 3u, (blk >> 2) & 3u, (blk >> 4) & 3u, (blk >> 6) & 3u, (blk >> 8) & 3u, (blk >> 10) & 3u, (blk >> 12) & 3u);

  boot_stage(CC_BOOT_STAGE_SELF_TEST);
  /* Dispatch enable is a management decision taken BEFORE the first command: with it off, a queued command simply waits
   * (that is why a POST that forgets this times out).  Enabling dispatch with no tenant ACTIVE is safe: the command
   * processor refuses every command of a tenant that is not ACTIVE (ERR_TENANT_STATE), which is exactly what POST checks. */
  DPU_G(DPU_G_CTRL) = 1u;
  int pf = post();
  cprintf("POST: %s\n", pf ? "FAIL" : "PASS");
  g_tally.fails += (uint32_t)pf;

  SEC(CC_SEC_CTRL) = 1u;                                  /* host may no longer write IMEM/DMEM/ROM */
  boot_stage(CC_BOOT_STAGE_CMDPROC_READY);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING | CC_HOST_STATUS_CMDPROC_READY;
  boot_stage(CC_BOOT_STAGE_HOST_READY);
  uint32_t caps[6] = {id, ver, c0, c1, blk, FW_VERSION};
  respond(CC_MBOX_CMD_NONE, pf ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK, caps, 6);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = SYSCTRL(CC_SYSCTRL_HOST_STATUS) | CC_HOST_STATUS_HOST_READY;
  cprintf("HOST READY\n");

  uint32_t done = 0;
  for (;;) {
    WAIT_UNTIL(g_cmd_pending != done, 0xFFFFFFFFu);
    if (g_cmd_pending == done) continue;
    done = g_cmd_pending;
    g_cmd_seq++;
    uint32_t cmd = g_cmd[0];
    switch (cmd) {
      case CC_MBOX_CMD_PING: {
        uint32_t o[2] = {g_cmd[1], FW_VERSION};
        respond(cmd, CC_MBOX_STS_OK, o, 2);
        break;
      }
      case DPUCMD_INFO: {
        uint32_t o[7] = {id, ver, c0, c1, DPU_G(DPU_G_SRAM_BYTES), blk, DPU_G(DPU_G_FEATURES)};
        respond(cmd, CC_MBOX_STS_OK, o, 7);
        break;
      }
      case DPUCMD_CONFIG: {                               /* a1 tenant, a2 host in-window base, a3 partition size */
        uint32_t t = g_cmd[1], in_base = g_cmd[2], part = g_cmd[3];
        uint32_t cfg = dpu_tenant_configure(t, t * part, part, in_base, in_base + 0x10000u);
        if (cfg == SFC_CFG_OK) {
          dpu_selftest_set_env(t, in_base, in_base + 0x10000u, part);
          DPU_G(DPU_G_CTRL) = 1u;                         /* dispatch enable */
          /* isolation violations, host-memory errors, malformed descriptors and job timeouts raise DPU_FAULT; the
           * violations and timeouts are also routed to the ControlCore RAS block (warning input) */
          DPU_G(DPU_G_FAULT_ENABLE) = (1u << SFC_FLT_PERM_VIOL) | (1u << SFC_FLT_HOST_ERR) | (1u << SFC_FLT_DESC_ERR) | (1u << SFC_FLT_TIMEOUT);
          DPU_G(DPU_G_FAULT_WARN)   = (1u << SFC_FLT_PERM_VIOL) | (1u << SFC_FLT_TIMEOUT);
        }
        uint32_t o[2] = {cfg, dpu_tenant_state(t)};
        cprintf("[cmd] CONFIG tenant %u in=%08x part=%u -> cfg=%x state=%u\n", t, in_base, part, cfg, o[1]);
        respond(cmd, cfg == SFC_CFG_OK ? CC_MBOX_STS_OK : CC_MBOX_STS_ACC_ERROR, o, 2);
        break;
      }
      case DPUCMD_SELFTEST: {
        uint32_t k0 = g_tally.checks;
        uint32_t f = dpu_selftest_run(g_cmd[1] ? g_cmd[1] : DST_ALL);
        uint32_t o[2] = {g_tally.checks - k0, f};
        boot_stage(CC_BOOT_STAGE_HOST_READY);
        respond(cmd, CC_MBOX_STS_OK, o, 2);
        break;
      }
      case DPUCMD_SUBMIT: {                               /* a1 = op | pop << 8 | tenant << 16, a2 tag, a3 src, a4 dst, a5 len, a6 soff, a7 param */
        dpu_desc_t d;
        dpu_cpl_t c;
        dpu_desc_init(&d, g_cmd[1] & 0xFFu, (g_cmd[1] >> 16) & 0xFu, g_cmd[2], g_cmd[3], g_cmd[4], g_cmd[5], g_cmd[6],
                      (g_cmd[1] >> 8) & 0xFFu, g_cmd[7]);
        int rc = dpu_mgmt_run(&d, &c);
        if (rc) { respond(cmd, CC_MBOX_STS_TIMEOUT, 0, 0); break; }
        uint32_t o[7] = {c.w[0], c.w[1], c.w[2], c.w[3], c.w[4], c.w[5], c.w[6]};
        respond(cmd, CPL_STATUS(&c) == SFC_ST_OK ? CC_MBOX_STS_OK : CC_MBOX_STS_ACC_ERROR, o, 7);
        break;
      }
      case DPUCMD_FAULTS: {
        uint32_t o[6] = {g_fault_bits, g_fault_count, g_last_fault_tenant, g_last_fault_err, g_last_fault_addr, g_fault_irqs};
        respond(cmd, CC_MBOX_STS_OK, o, 6);
        break;
      }
      case DPUCMD_PERF: {
        uint32_t o[6] = {DPU_P(DPU_P_CNT0 + 8u * 0u), DPU_P(DPU_P_CNT0 + 8u * 1u), DPU_P(DPU_P_CNT0 + 8u * 2u),
                         DPU_P(DPU_P_CNT0 + 8u * 3u), DPU_P(DPU_P_CNT0 + 8u * 4u), DPU_P(DPU_P_CNT0 + 8u * 12u)};
        respond(cmd, CC_MBOX_STS_OK, o, 6);
        break;
      }
      case DPUCMD_RECOVER: {
        uint32_t t = g_cmd[1], r;
        if (t == 0xFFu) { dpu_dp_reset(); r = DPU_G(DPU_G_DP_RESETS); }
        else r = dpu_tenant_recover(t);
        uint32_t o[1] = {r};
        respond(cmd, CC_MBOX_STS_OK, o, 1);
        break;
      }
      case CC_MBOX_CMD_SHUTDOWN: {
        uint32_t fails = g_tally.fails + g_cmd[1];
        cprintf("SHUTDOWN: firmware checks=%u fails=%u, host-reported fails=%u -> %s\n", g_tally.checks, g_tally.fails,
                g_cmd[1], fails ? "FAIL" : "PASS");
        uint32_t o[2] = {g_tally.checks, g_tally.fails};
        respond(cmd, CC_MBOX_STS_OK, o, 2);
        boot_stage(CC_BOOT_STAGE_SHUTDOWN);
        SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0x80000000u | (fails ? 0x40000000u : 0u) | (fails & 0xFFFFu);
        break;
      }
      default:
        respond(cmd, CC_MBOX_STS_BAD_CMD, 0, 0);
        break;
    }
  }
}
