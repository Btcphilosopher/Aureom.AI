/* SilicaFlux CloudDPU firmware -- freestanding libc subset + console.
 * The console writes to MAILBOX.DIAG_TX: a 256-entry FIFO the host drains (host-visible diagnostics); a full
 * FIFO drops characters and never stalls the firmware. */
#include <stdarg.h>
#include "dpu_hw.h"

void *memcpy(void *d, const void *s, size_t n) {
  uint8_t *dp = (uint8_t *)d;
  const uint8_t *sp = (const uint8_t *)s;
  for (size_t i = 0; i < n; i++) dp[i] = sp[i];
  return d;
}
void *memset(void *d, int c, size_t n) {
  uint8_t *dp = (uint8_t *)d;
  for (size_t i = 0; i < n; i++) dp[i] = (uint8_t)c;
  return d;
}
void con_putc(char c) { MBOX(CC_MBOX_DIAG_TX) = (uint8_t)c; }
static void con_puts(const char *s) { while (*s) con_putc(*s++); }

static void put_u(uint32_t v, unsigned base, int width, char pad) {
  char buf[12];
  int n = 0;
  do { buf[n++] = "0123456789abcdef"[v % base]; v /= base; } while (v);
  while (n < width) buf[n++] = pad;
  while (n) con_putc(buf[--n]);
}

/* %s %c %d %u %x with optional zero-pad width (%08x) */
void cprintf(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  for (; *fmt; fmt++) {
    if (*fmt != '%') { con_putc(*fmt); continue; }
    char pad = ' ';
    int width = 0;
    fmt++;
    if (*fmt == '0') { pad = '0'; fmt++; }
    while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
    switch (*fmt) {
      case 's': con_puts(va_arg(ap, const char *)); break;
      case 'c': con_putc((char)va_arg(ap, int)); break;
      case 'u': put_u(va_arg(ap, uint32_t), 10, width, pad); break;
      case 'x': put_u(va_arg(ap, uint32_t), 16, width, pad); break;
      case 'd': {
        int32_t v = va_arg(ap, int32_t);
        if (v < 0) { con_putc('-'); v = -v; }
        put_u((uint32_t)v, 10, width, pad);
        break;
      }
      case '%': con_putc('%'); break;
      default: con_putc('?'); break;
    }
  }
  va_end(ap);
}
