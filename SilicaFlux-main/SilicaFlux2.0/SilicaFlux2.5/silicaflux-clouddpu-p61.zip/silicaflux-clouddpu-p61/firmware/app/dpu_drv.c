/* =============================================================================
 * SilicaFlux CloudDPU firmware -- DPU driver: tenant configuration, management-queue command submission and
 * completion by interrupt, fault take-over, data-plane reset.  Everything is plain register access through the
 * generated address map; there is no hidden state in hardware that this file does not name.
 * ===========================================================================*/
#include "dpu_hw.h"

void dpu_desc_init(dpu_desc_t *d, uint32_t op, uint32_t tenant, uint32_t tag, uint32_t src, uint32_t dst, uint32_t len,
                   uint32_t soff, uint32_t proc_op, uint32_t param) {
  memset(d, 0, sizeof(*d));
  d->w[0] = op | (tenant << 16);
  d->w[1] = tag;
  d->w[2] = src;                      /* W3 = high word: host addresses are 32-bit in this firmware */
  d->w[4] = dst;                      /* W5 = high word */
  d->w[6] = len;
  d->w[7] = soff;
  d->w[8] = proc_op;
  d->w[9] = param;
}

int dpu_mgmt_submit(const dpu_desc_t *d) {
  for (unsigned i = 0; i < 12u; i++) DPU_QM(DPU_Q_M_DESC0 + 4u * i) = d->w[i];
  DPU_QM(DPU_Q_M_SUBMIT) = 1u;
  return (DPU_QM(DPU_Q_M_SUBMIT_STATUS) & 1u) ? 0 : -1;
}

/* completion by interrupt: unmask DPU_EVENT, sleep until the ISR noted it, pop the record */
int dpu_mgmt_wait(dpu_cpl_t *c, uint32_t tmo) {
  uint32_t seen = g_event_irqs;
  DPU_G(DPU_G_IRQ_ENABLE) = 1u;
  if (WAIT_UNTIL(g_event_irqs != seen || (DPU_C(DPU_C_STATUS) & 0x100u), tmo)) { DPU_G(DPU_G_IRQ_ENABLE) = 0u; return -1; }
  for (unsigned i = 0; i < 8u; i++) c->w[i] = DPU_C(DPU_C_REC0 + 4u * i);
  DPU_C(DPU_C_POP) = 1u;
  DPU_G(DPU_G_IRQ_ENABLE) = 0u;
  return 0;
}

int dpu_mgmt_run(const dpu_desc_t *d, dpu_cpl_t *c) {
  if (dpu_mgmt_submit(d)) return -2;
  return dpu_mgmt_wait(c, 2000000u);
}

uint32_t dpu_tenant_state(uint32_t t) { return DPU_T(t, DPU_T_STATE) & 7u; }

int dpu_wait_tenant(uint32_t t, uint32_t state, uint32_t tmo) {
  uint32_t t0 = cycles();
  while (dpu_tenant_state(t) != state) if (cycles() - t0 > tmo) return -1;
  return 0;
}

/* partition [sram_base, +size) and two host windows: [in_base, +64 KiB) read-only, [out_base, +64 KiB) read/write.
 * COMMIT validates (no overlap with other tenants, inside the SRAM), scrubs the partition, then ENABLE.
 * Returns the CFG_* status of the commit (SFC_CFG_OK = 1 on success, tenant ACTIVE). */
uint32_t dpu_tenant_configure(uint32_t t, uint32_t sram_base, uint32_t sram_size, uint32_t in_base, uint32_t out_base) {
  DPU_T(t, DPU_T_SRAM_BASE) = sram_base;
  DPU_T(t, DPU_T_SRAM_SIZE) = sram_size;
  DPU_T(t, DPU_T_WIN0 + 0u * DPU_T_WIN0_STRIDE + DPU_T_WIN_BASE_LO) = in_base;
  DPU_T(t, DPU_T_WIN0 + 0u * DPU_T_WIN0_STRIDE + DPU_T_WIN_BASE_HI) = 0u;
  DPU_T(t, DPU_T_WIN0 + 0u * DPU_T_WIN0_STRIDE + DPU_T_WIN_SIZE)    = 0x10000u;
  DPU_T(t, DPU_T_WIN0 + 0u * DPU_T_WIN0_STRIDE + DPU_T_WIN_CTRL)    = 0x3u;        /* valid | R */
  DPU_T(t, DPU_T_WIN0 + 1u * DPU_T_WIN0_STRIDE + DPU_T_WIN_BASE_LO) = out_base;
  DPU_T(t, DPU_T_WIN0 + 1u * DPU_T_WIN0_STRIDE + DPU_T_WIN_BASE_HI) = 0u;
  DPU_T(t, DPU_T_WIN0 + 1u * DPU_T_WIN0_STRIDE + DPU_T_WIN_SIZE)    = 0x10000u;
  DPU_T(t, DPU_T_WIN0 + 1u * DPU_T_WIN0_STRIDE + DPU_T_WIN_CTRL)    = 0x7u;        /* valid | R | W */
  DPU_T(t, DPU_T_CMD) = SFC_TCMD_COMMIT;
  uint32_t t0 = cycles(), cfg;
  do { cfg = DPU_T(t, DPU_T_CFG_STATUS) & 0xFFu; } while (cfg == SFC_CFG_NONE && cycles() - t0 < 100000u);
  if (cfg != SFC_CFG_OK) return cfg;
  /* wait for the scrub: DISABLED and configured */
  while (!((DPU_T(t, DPU_T_STATE) & 0x107u) == 0x100u)) if (cycles() - t0 > 20000000u) return 0xFFu;
  DPU_T(t, DPU_T_CMD) = SFC_TCMD_ENABLE;
  return dpu_tenant_state(t) == SFC_TS_ACTIVE ? cfg : 0xFEu;
}

/* a quarantined (or live) tenant: RECOVER drains, scrubs the partition and leaves it DISABLED; ENABLE re-admits it */
uint32_t dpu_tenant_recover(uint32_t t) {
  DPU_T(t, DPU_T_CMD) = SFC_TCMD_RECOVER;
  if (dpu_wait_tenant(t, SFC_TS_DISABLED, 20000000u)) return 0xFFu;
  DPU_T(t, DPU_T_CMD) = SFC_TCMD_ENABLE;
  return dpu_tenant_state(t);
}

void dpu_dp_reset(void) {
  DPU_G(DPU_G_CTRL) = 3u;                               /* EN stays 1, DP_RESET pulse (self-clearing) */
  uint32_t t0 = cycles();
  while ((DPU_G(DPU_G_STATUS) & 4u) && cycles() - t0 < 100000u) ;
}

uint32_t dpu_fault_take(void) {
  csr_clear(mstatus, MSTATUS_MIE);
  uint32_t b = g_fault_bits;
  g_fault_bits = 0u;
  csr_set(mstatus, MSTATUS_MIE);
  return b;
}
