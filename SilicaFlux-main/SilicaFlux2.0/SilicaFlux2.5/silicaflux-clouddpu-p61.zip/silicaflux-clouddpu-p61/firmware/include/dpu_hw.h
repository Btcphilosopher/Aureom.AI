/* =============================================================================
 * SilicaFlux CloudDPU firmware -- hardware access layer for the DPU register pages and local SRAM.
 * Addresses and offsets come ONLY from the generated dpu_memmap.h / dpu_abi.h (config/dpu_memmap.yaml and
 * rtl/pkg/silicaflux_cloud_pkg.sv).  Bare metal, freestanding C, RV32IM_Zicsr, machine mode, on the vendored
 * ControlCore (Project 21).
 * ===========================================================================*/
#ifndef DPU_HW_H
#define DPU_HW_H

#include "cc_hw.h"
#include "generated/dpu_memmap.h"
#include "generated/dpu_abi.h"

#define FW_VERSION      0x00010000u

/* register windows */
#define DPU_G(off)        REG32(DPU_GLOBAL_PAGE_BASE + (off))
#define DPU_T(t, off)     REG32(DPU_TENANT_PAGE_BASE + (uint32_t)(t) * DPU_T_STRIDE + (off))
#define DPU_Q(q, off)     REG32(DPU_QUEUE_PAGE_BASE + (uint32_t)(q) * DPU_Q_STRIDE + (off))
#define DPU_QM(off)       REG32(DPU_QUEUE_PAGE_BASE + (off))
#define DPU_C(off)        REG32(DPU_MGMT_CQ_PAGE_BASE + (off))
#define DPU_P(off)        REG32(DPU_PERF_PAGE_BASE + (off))
#define DPU_L(off)        REG32(DPU_TELEMETRY_PAGE_BASE + (off))
#define DPU_E(off)        REG32(DPU_ENGINES_PAGE_BASE + (off))
#define DPU_D(off)        REG32(DPU_DEBUG_PAGE_BASE + (off))
#define DPU_SRAM(off)     REG32(DPU_SRAM_EXT_BASE + (uint32_t)(off))

/* ControlCore interrupt sources carrying the DPU interrupts (the ControlCore RTL is unmodified: its two
 * accelerator interrupt inputs are reused under DPU names) */
#define DPU_IRQ_EVENT     CC_IRQ_VECTOR
#define DPU_IRQ_FAULT     CC_IRQ_TENSOR

/* host mailbox commands of the DPU firmware (codes 0x40.. are free in the ControlCore protocol) */
#define DPUCMD_INFO       SFC_DPUCMD_INFO
#define DPUCMD_CONFIG     SFC_DPUCMD_CONFIG
#define DPUCMD_SELFTEST   SFC_DPUCMD_SELFTEST
#define DPUCMD_SUBMIT     SFC_DPUCMD_SUBMIT
#define DPUCMD_FAULTS     SFC_DPUCMD_FAULTS
#define DPUCMD_PERF       SFC_DPUCMD_PERF
#define DPUCMD_RECOVER    SFC_DPUCMD_RECOVER

/* firmware self-test groups */
#define DST_ID      (1u << 0)
#define DST_MMIO    (1u << 1)
#define DST_PKT     (1u << 2)
#define DST_ERR     (1u << 3)
#define DST_PERM    (1u << 4)
#define DST_PERF    (1u << 5)
#define DST_RESET   (1u << 6)
#define DST_IRQ     (1u << 7)
#define DST_ALL     0xFFu

/* descriptor / completion as 32-bit words (layout: silicaflux_cloud_pkg CMD_* / CPL_*) */
typedef struct { uint32_t w[12]; } dpu_desc_t;
typedef struct { uint32_t w[8]; }  dpu_cpl_t;
#define CPL_OPCODE(c)  ((c)->w[0] & 0xFFu)
#define CPL_STATUS(c)  (((c)->w[0] >> 8) & 0xFFu)
#define CPL_ERR(c)     (((c)->w[0] >> 16) & 0xFFu)
#define CPL_TENANT(c)  (((c)->w[0] >> 24) & 0xFu)
#define CPL_QUEUE(c)   (((c)->w[0] >> 28) & 0xFu)
#define CPL_TAG(c)     ((c)->w[1])
#define CPL_COMMITTED(c) (((c)->w[2] >> 16) & 1u)
#define CPL_BYTES(c)   ((c)->w[3])
#define CPL_CRC_IN(c)  ((c)->w[4])
#define CPL_CRC_OUT(c) ((c)->w[5])
#define CPL_CSUM(c)    ((c)->w[6] & 0xFFFFu)

/* ---------------------------------------------------------------- libc subset, console, traps, interrupts */
void  *memcpy(void *d, const void *s, size_t n);
void  *memset(void *d, int c, size_t n);
void   con_putc(char c);
void   cprintf(const char *fmt, ...);

typedef struct { uint32_t x[32]; uint32_t mepc; } trap_frame_t;
typedef struct { volatile uint32_t armed, cause, count; } expect_t;
uint32_t probe_wr(uint32_t addr, uint32_t val);     /* 0 = no trap, else mcause */
uint32_t probe_rd(uint32_t addr, uint32_t *val);
void     platform_init(void);
uint32_t cycles(void);
#define WAIT_UNTIL(cond, tmo) ({                                         \
    int __r = 0; uint32_t __t0 = cycles();                               \
    for (;;) {                                                           \
      csr_clear(mstatus, MSTATUS_MIE);                                   \
      if (cond) break;                                                   \
      if (cycles() - __t0 > (uint32_t)(tmo)) { __r = -1; break; }        \
      wfi();                                                             \
      csr_set(mstatus, MSTATUS_MIE);                                     \
    }                                                                    \
    csr_set(mstatus, MSTATUS_MIE);                                       \
    __r; })

extern volatile uint32_t g_cmd[8], g_cmd_pending, g_cmd_seq;
extern volatile uint32_t g_event_irqs, g_fault_irqs, g_fault_bits, g_fault_count, g_last_fault_tenant, g_last_fault_err;
extern volatile uint32_t g_last_fault_addr;

/* ---------------------------------------------------------------- DPU driver */
void     dpu_desc_init(dpu_desc_t *d, uint32_t op, uint32_t tenant, uint32_t tag, uint32_t src, uint32_t dst, uint32_t len,
                       uint32_t soff, uint32_t proc_op, uint32_t param);
int      dpu_mgmt_submit(const dpu_desc_t *d);                /* 0 accepted, -1 queue full */
int      dpu_mgmt_wait(dpu_cpl_t *c, uint32_t tmo);           /* completion by DPU_EVENT interrupt; 0 ok, -1 timeout */
int      dpu_mgmt_run(const dpu_desc_t *d, dpu_cpl_t *c);
uint32_t dpu_tenant_state(uint32_t t);
int      dpu_wait_tenant(uint32_t t, uint32_t state, uint32_t tmo);
uint32_t dpu_tenant_configure(uint32_t t, uint32_t sram_base, uint32_t sram_size, uint32_t in_base, uint32_t out_base);
uint32_t dpu_tenant_recover(uint32_t t);                       /* DISABLE/RECOVER -> scrub -> ENABLE; returns final state */
void     dpu_dp_reset(void);
uint32_t dpu_fault_take(void);                                 /* returns and clears the fault bits accumulated by the ISR */

/* ---------------------------------------------------------------- self-test */
typedef struct { uint32_t checks, fails; } tally_t;
extern tally_t g_tally;
void     check(int ok, uint32_t id, uint32_t got, uint32_t exp);
#define CHECK_EQ(id, got, exp) do { uint32_t __g = (uint32_t)(got), __e = (uint32_t)(exp); check(__g == __e, (id), __g, __e); } while (0)
#define CHECK_TRUE(id, c)      do { int __c = !!(c); check(__c, (id), (uint32_t)__c, 1u); } while (0)
uint32_t dpu_selftest_run(uint32_t mask);
extern uint32_t g_host_in, g_host_out, g_sram_part;           /* set by DPUCMD_CONFIG: used by the self-test */
void     dpu_selftest_set_env(uint32_t t, uint32_t in_base, uint32_t out_base, uint32_t part);

#endif /* DPU_HW_H */
