#!/usr/bin/env python3
"""Vendor reused SilicaFlux sources, byte-identical, from the repository archives.

  vendor.py --repo <path to Aureom.AI checkout>      (maintainer: refresh third_party/ + MANIFEST.tsv + SHA256SUMS)

Nothing is edited after copying.  check_vendor.py later proves the copies are unmodified.
"""
import argparse, fnmatch, hashlib, os, sys, zipfile

ARCH_DIR = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5"
# (archive, member prefix inside the archive, destination under third_party/, include globs, exclude globs)
SOURCES = [
    ("silicaflux-controlcore.zip", "silicaflux-controlcore/", "silicaflux-controlcore/",
     ["rtl/*.sv", "rtl/generated/*",
      "config/cc_memmap.yaml",
      "firmware/bootrom/*", "firmware/common/*", "firmware/include/*", "firmware/include/generated/*",
      "scripts/mkimage.py", "scripts/generated/cc_memmap.py",
      "third_party/silicaflux-datafabric/rtl/*", "third_party/silicaflux-datafabric/tb/common/*",
      "third_party/silicaflux-sramlib/rtl/*",
      "third_party/silicaflux-v/rtl/*", "third_party/silicaflux-v/scripts/*",
      "third_party/silicaflux-mcu-i/rtl/*", "third_party/silicaflux-mcu-i/docs/*",
      "docs/MEMORY_MAP.md", "docs/03_BOOT.md", "docs/09_LIMITATIONS.md"],
     []),
    ("silicaflux-securestore-p59.zip", "silicaflux-securestore/", "silicaflux-securestore/",
     ["rtl/sfsec_crc.sv", "rtl/sfsec_pkg.sv"], []),
]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    a = ap.parse_args()
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    tp = os.path.join(root, "third_party")
    rows = []
    for arch, pre, dest, inc, exc in SOURCES:
        zp = os.path.join(a.repo, ARCH_DIR, arch)
        zsha = hashlib.sha256(open(zp, "rb").read()).hexdigest()
        with zipfile.ZipFile(zp) as z:
            for info in sorted(z.infolist(), key=lambda i: i.filename):
                if info.is_dir() or not info.filename.startswith(pre):
                    continue
                rel = info.filename[len(pre):]
                if not any(fnmatch.fnmatch(rel, g) for g in inc) or any(fnmatch.fnmatch(rel, g) for g in exc):
                    continue
                data = z.read(info)
                out = os.path.join(tp, dest, rel)
                os.makedirs(os.path.dirname(out), exist_ok=True)
                open(out, "wb").write(data)
                rows.append((os.path.join(dest, rel), arch, zsha, info.filename, hashlib.sha256(data).hexdigest()))
    with open(os.path.join(tp, "MANIFEST.tsv"), "w") as f:
        f.write("# vendored_path\tarchive (under %s)\tarchive_sha256\tmember\tfile_sha256\n" % ARCH_DIR)
        for r in rows: f.write("\t".join(r) + "\n")
    with open(os.path.join(tp, "SHA256SUMS"), "w") as f:
        for r in rows: f.write("%s  %s\n" % (r[4], r[0]))
    print("vendored %d files" % len(rows))

if __name__ == "__main__":
    sys.exit(main())
