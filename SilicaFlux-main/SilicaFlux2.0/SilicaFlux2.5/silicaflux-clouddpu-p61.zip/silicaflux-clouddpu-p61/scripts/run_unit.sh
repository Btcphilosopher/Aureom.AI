#!/bin/bash
# Builds and runs the four unit benches (small; seconds each).  Exit status 0 only if every bench prints its PASS line.
#   tb_layout_check : struct views (testbench) and flat offsets (RTL) of the transaction/completion/descriptor formats are the same bits
#   tb_crc_xcheck   : sfd_crc32 (datapath) against SecureStore's validated sfsec_crc and the CRC-32 check value
#   tb_guard_unit   : per-beat host/SRAM guards, job slot and PacketCore hub WITHOUT the command processor
#   tb_axi_bridge   : SFB2 -> AXI4 single-beat bridge against an AXI slave model
cd "$(dirname "$0")/.." || exit 2
CC=third_party/silicaflux-controlcore
SRAML=$CC/third_party/silicaflux-sramlib
DF=$CC/third_party/silicaflux-datafabric/rtl
SEC=third_party/silicaflux-securestore/rtl
PKG=rtl/pkg/silicaflux_cloud_pkg.sv
COMMON=(-Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD scripts/vendored_waivers.vlt
        +incdir+$SRAML/rtl/mem +incdir+$SRAML/rtl/mem/backends/asic)
mkdir -p reports/unit
fail=0
run() {   # run <tb> <exe-name> <pass-pattern> <source files...>
  local tb=$1 exe=$2 pat=$3; shift 3
  rm -rf build/unit_$tb; mkdir -p build/unit_$tb
  if ! verilator --binary --timing -O1 -j 2 --assert "${COMMON[@]}" "$@" tb/$tb.sv --top-module $tb \
        -Mdir build/unit_$tb -o $exe > build/unit_$tb/build.log 2>&1; then
    echo "$tb: BUILD FAILED (build/unit_$tb/build.log)"; grep -E "%Error" build/unit_$tb/build.log | head -5; fail=1; return
  fi
  build/unit_$tb/$exe > reports/unit/$tb.log 2>&1
  if grep -qE "$pat" reports/unit/$tb.log; then echo "$tb: PASS   $(grep -E "$pat" reports/unit/$tb.log | tail -1)"
  else echo "$tb: FAIL   (reports/unit/$tb.log)"; tail -5 reports/unit/$tb.log; fail=1; fi
}
run tb_layout_check vtb_layout_check "TB RESULT PASS" $PKG
run tb_crc_xcheck   vtb_crc_xcheck   "TB RESULT PASS" $PKG rtl/dpu/sfd_crc32.sv $SEC/sfsec_pkg.sv $SEC/sfsec_crc.sv
GUARD=( $PKG
  $SRAML/rtl/mem/backends/generic/sram_generic_1rw.sv $SRAML/rtl/mem/backends/fpga/sram_fpga_1rw.sv
  $SRAML/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv $SRAML/rtl/mem/backends/asic/sram_asic_array.sv
  $SRAML/rtl/mem/sram_backend_1rw.sv $SRAML/rtl/mem/sram_rsp_path.sv $SRAML/rtl/mem/sram_sp.sv
  $DF/interconnect/sfb_addr_decoder.sv $DF/interconnect/sfb_arbiter.sv $DF/interconnect/sfb_error_slave.sv
  $DF/interconnect/sfb_req_mux.sv $DF/interconnect/sfb_rsp_router.sv $DF/interconnect/sfb_crossbar.sv
  $DF/mem/sfb_sram_slave.sv
  rtl/dpu/sfd_rr_arb.sv rtl/dpu/sfd_win_check.sv rtl/dpu/sfd_crc32.sv rtl/dpu/sfd_sfb_gate.sv rtl/dpu/sfd_host_guard.sv
  rtl/dpu/sfd_sram_guard.sv rtl/dpu/sfd_clouddma.sv rtl/dpu/sfd_packetcore_tadapter.sv rtl/dpu/sfd_job_slot.sv rtl/dpu/sfd_pkt_hub.sv )
run tb_guard_unit   vtb_guard_unit   "TB RESULT PASS" "${GUARD[@]}"
run tb_axi_bridge   vtb_axi_bridge   "TB RESULT PASS" integration/sfd_sfb2_to_axi4.sv
exit $fail
