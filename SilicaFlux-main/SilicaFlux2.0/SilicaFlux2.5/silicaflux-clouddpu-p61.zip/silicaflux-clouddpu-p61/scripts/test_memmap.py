#!/usr/bin/env python3
"""Negative tests of the address-map validator: every illegal map must be rejected (exit status 2), the real map accepted."""
import copy, os, subprocess, sys, tempfile, yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEN = os.path.join(ROOT, "scripts/gen_dpu_memmap.py")
base = yaml.safe_load(open(os.path.join(ROOT, "config/dpu_memmap.yaml")))

def run(m, name):
    with tempfile.TemporaryDirectory() as d:
        mp = os.path.join(d, "m.yaml")
        yaml.safe_dump(m, open(mp, "w"))
        r = subprocess.run([sys.executable, GEN, "--map", mp, "--out", d], capture_output=True, text=True)
        return r.returncode, r.stdout

def reg(m, region, name):
    return next(r for r in m["regions"][region]["regs"] if r["name"] == name)

cases = []
def mut(name, fn):
    m = copy.deepcopy(base); fn(m); cases.append((name, m))

mut("misaligned register", lambda m: reg(m, 0, "CTRL").__setitem__("at", 0x022))
mut("duplicate offset (overlap)", lambda m: reg(m, 0, "STATUS").__setitem__("at", 0x020))
mut("register beyond the 4 KiB page", lambda m: reg(m, 0, "SCRATCH").__setitem__("at", 0x1000))
mut("duplicate register name", lambda m: m["regions"][0]["regs"].append(dict(reg(m, 0, "CTRL"), at=0x0F0)))
mut("array element larger than the stride", lambda m: reg(m, 1, "WIN0").__setitem__("at", 0xF8))
mut("array exceeds the page", lambda m: m["regions"][1]["array"].__setitem__("count", 17))
mut("two regions with the same id", lambda m: m["regions"][3].__setitem__("id", 2))
mut("region id out of range", lambda m: m["regions"][3].__setitem__("id", 9))
mut("counter block overlaps the control registers", lambda m: m["regions"][4]["tenant_block"].__setitem__("base", 0x010))
mut("tenant block exceeds the page", lambda m: m["regions"][4]["tenant_block"].__setitem__("base", 0xF00))
mut("management window inside the queue array", lambda m: m["regions"][2]["extra"][0].__setitem__("at", 0x100))
mut("base page too high", lambda m: m.__setitem__("base_page", 28))
mut("word array overruns its neighbour", lambda m: reg(m, 4, "CNT0").__setitem__("count", 400))

bad = 0
rc, out = run(base, "good")
print("%-52s %s" % ("the real map", "accepted" if rc == 0 else "REJECTED (bug): " + out.strip()))
bad += rc != 0
for name, m in cases:
    rc, out = run(m, name)
    ok = rc == 2
    bad += not ok
    print("%-52s %s" % (name, "rejected: " + out.strip()[:70] if ok else "NOT REJECTED (bug)"))
print("%d negative cases + the real map: %d problems" % (len(cases), bad))
sys.exit(1 if bad else 0)
