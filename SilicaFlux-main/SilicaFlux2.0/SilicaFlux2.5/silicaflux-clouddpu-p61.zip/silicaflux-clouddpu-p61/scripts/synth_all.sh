#!/bin/bash
# The standard synthesis set (technology-independent, Yosys 0.33).  Rewrites reports/synth/SUMMARY.md.
cd "$(dirname "$0")/.."
mkdir -p reports/synth build
rm -f reports/synth/*.txt reports/synth/*.log
printf '# CloudDPU generic synthesis (Yosys 0.33, technology independent, NO PDK)\n\nCell counts are of a generic AND/NAND/OR/NOR/XOR/XNOR/MUX/NOT + flip-flop netlist after `abc`; they are NOT area, frequency or power claims.\n`Memories` counts `$mem_v2` blocks left unmapped (SRAM arrays and FIFO storage).  Latches: `$dlatch`/`$adlatch` cells (the ControlCore clock-gate latch is bypassed by SFV_NO_CLOCK_GATE).\nEvery run passes `check -assert` (the last column is the number of problems it reported).\n\n| Name | Top | Parameters | Generic cells | Flip-flops | Memories | Latches | `check` problems |\n|---|---|---|---|---|---|---|---|\n' > reports/synth/SUMMARY.md
bash scripts/synth.sh min
TOP=silicaflux_control_core bash scripts/synth.sh controlcore
bash scripts/synth.sh mt NUM_TENANTS=2 NUM_NETWORK_QUEUES=2 NUM_DMA_CHANNELS=2 NUM_SRAM_BANKS=2
bash scripts/synth.sh w64 DATA_WIDTH=64 ADDRESS_WIDTH=40 NUM_NETWORK_QUEUES=2 NUM_DMA_CHANNELS=2 NUM_SRAM_BANKS=2
bash scripts/synth.sh w128 NUM_TENANTS=4 NUM_NETWORK_QUEUES=4 NUM_COMPUTE_QUEUES=2 NUM_DMA_CHANNELS=3 DATA_WIDTH=128 ADDRESS_WIDTH=64 NUM_WINDOWS=4 NUM_SRAM_BANKS=4 SRAM_CAPACITY=131072 QUEUE_DEPTH=3 CPLQ_DEPTH=3
