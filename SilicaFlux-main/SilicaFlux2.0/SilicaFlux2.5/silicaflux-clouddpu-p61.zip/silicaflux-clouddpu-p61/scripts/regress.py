#!/usr/bin/env python3
"""CloudDPU regression: build the testbench in several configurations and run every scenario.

  scripts/regress.py [--configs min,mt,w64,w128] [--jobs 4] [--quick]

Each configuration is a separate Verilator build (compile-time geometry: tenants, queues, DMA channels, data and address
width, SRAM banks) compiled at -O0 (a C++ -O1 build of this testbench takes > 25 minutes; -O0 takes ~5).
Scenarios run as separate processes, each with its own seed/back-pressure setting; the result of every run is a line
in reports/regression.md.  Exit status 0 only if every run passed.
"""
import argparse, os, re, subprocess, sys, time, concurrent.futures as cf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIGS = {
    # name: (defines, scenarios[(name, extra plusargs)])
    "min":  (["NT=1", "NNQ=1", "NCQ=1", "NS=1", "DW=32", "AW=32", "NW=2", "NB=1"],
             ["smoke", "reset", "boot", "mmio", "decode", "mgmt", "data", "stress", "saturation", "errprop", "telemetry", "perf", "recovery",
              ("stress", ["+bp=60", "+cbp=60", "+lat=8", "+seed=7"]), ("data", ["+bp=40", "+cbp=70", "+lat=12", "+seed=11"]),
              ("stress", ["+bp=85", "+cbp=85", "+lat=2", "+seed=3"])]),
    "mt":   (["NT=2", "NNQ=2", "NCQ=1", "NS=2", "DW=32", "AW=32", "NW=2", "NB=2"],
             ["smoke", "reset", "boot", "mmio", "decode", "mgmt", "data", "saturation", "errprop", "telemetry", "perf", "multi", "isolation", "recovery",
              ("multi", ["+bp=50", "+cbp=50", "+lat=6", "+seed=5"]), ("isolation", ["+bp=30", "+cbp=30", "+lat=4", "+seed=9"]),
              ("stress", ["+bp=60", "+cbp=60", "+lat=8", "+seed=2"])]),
    "w64":  (["NT=1", "NNQ=2", "NCQ=1", "NS=2", "DW=64", "AW=40", "NW=2", "NB=2"],
             ["smoke", "reset", "boot", "decode", "mgmt", "geometry", "saturation", "errprop", "multi", "perf", "recovery",
              ("geometry", ["+bp=50", "+cbp=50", "+lat=6", "+seed=4"])]),
    "fw":   (["WITH_FW=1", "NT=1", "NNQ=1", "NCQ=1", "NS=1", "DW=32", "AW=32", "NW=2", "NB=1"],
             [("fw", ["+fw=firmware/build/dpu_fw.hex", "+timeout=150000000"])]),
    "w128": (["NT=4", "NNQ=4", "NCQ=2", "NS=3", "DW=128", "AW=64", "NW=4", "NB=4", "SRAMB=131072", "QD=3", "CD=3"],
             ["smoke", "reset", "decode", "geometry", "multi", "isolation", "recovery",
              ("multi", ["+bp=40", "+cbp=40", "+lat=5", "+seed=6"]), ("isolation", ["+bp=40", "+cbp=40", "+lat=5", "+seed=8"])]),
}

def build(name, defines):
    d = os.path.join(ROOT, "build", "reg_" + name)
    os.makedirs(d, exist_ok=True)
    env = dict(os.environ, DPU_ASSERT="1")
    files = subprocess.run(["bash", os.path.join(ROOT, "scripts/rtl_files.sh")], cwd=ROOT, env=env, capture_output=True, text=True).stdout.split()
    gen = ["verilator", "--cc", "--exe", "--main", "--timing", "-O1", "--assert", "-DSFD_ASSERT", "-Wno-fatal", "-Wno-lint", "-Wno-style",
           "-Wno-TIMESCALEMOD", "-DSFV_NO_CLOCK_GATE", "scripts/vendored_waivers.vlt"] + ["-D" + x for x in defines] + files + \
          ["+incdir+tb", "tb/tb_dpu.sv", "--top-module", "tb_dpu", "-Mdir", d, "-o", "vtb"]
    log = open(os.path.join(d, "build.log"), "w")
    t0 = time.time()
    if subprocess.run(gen, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT).returncode:
        return name, False, "verilator failed (see %s/build.log)" % d, 0
    mk = subprocess.run(["make", "-C", d, "-f", "Vtb_dpu.mk", "-j", "4", "OPT_FAST=-O0", "OPT_SLOW=-O0", "OPT_GLOBAL=-O0"],
                        cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    return name, mk.returncode == 0, "" if mk.returncode == 0 else "make failed (see %s/build.log)" % d, time.time() - t0

def run(cfg, sc):
    name, extra = (sc, []) if isinstance(sc, str) else sc
    tag = name + ("_" + "_".join(x.strip("+").replace("=", "") for x in extra if not x.startswith(("+timeout=", "+fw="))) if extra else "")
    tag = tag.rstrip("_")
    d = os.path.join(ROOT, "reports", "sim", cfg)
    os.makedirs(d, exist_ok=True)
    logp = os.path.join(d, tag + ".log")
    t0 = time.time()
    try:
        r = subprocess.run([os.path.join(ROOT, "build", "reg_" + cfg, "vtb"), "+test=" + name, "+timeout=200000000"] + extra,
                           cwd=ROOT, stdout=open(logp, "w"), stderr=subprocess.STDOUT, timeout=3000)
        rc = r.returncode
    except subprocess.TimeoutExpired:
        rc = -9
    txt = open(logp).read()
    summ = [l for l in txt.splitlines() if l.startswith("TB SUMMARY")]
    res = "PASS" if (rc == 0 and "TB RESULT PASS" in txt) else "FAIL"
    skipped = "SKIP" in txt
    return cfg, tag, res, (summ[-1][11:] if summ else ""), time.time() - t0, skipped

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="min,mt,w64,w128")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--skip-build", action="store_true")
    a = ap.parse_args()
    cfgs = a.configs.split(",")
    if not a.skip_build:
        with cf.ThreadPoolExecutor(max_workers=3) as ex:
            for name, ok, msg, dt in ex.map(lambda c: build(c, CONFIGS[c][0]), cfgs):
                print("build %-5s %s %s (%.0fs)" % (name, "ok" if ok else "FAILED", msg, dt), flush=True)
                if not ok:
                    return 1
    rows = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = [ex.submit(run, c, s) for c in cfgs for s in CONFIGS[c][1]]
        for f in cf.as_completed(futs):
            r = f.result()
            rows.append(r)
            print("%-5s %-34s %s  %s (%.0fs)" % (r[0], r[1], r[2], r[3][:110], r[4]), flush=True)
    rows.sort()
    out = ["# CloudDPU regression", "", "Generated by `scripts/regress.py` from real simulation runs (Verilator 5.020, -O0 C++).", "",
           "| Config | Scenario | Result | Summary |", "|---|---|---|---|"]
    for c, t, res, sm, dt, sk in rows:
        out.append("| %s | %s | **%s** | %s |" % (c, t, res, sm))
    npass = sum(1 for r in rows if r[2] == "PASS")
    out += ["", "**%d / %d runs passed.**" % (npass, len(rows))]
    open(os.path.join(ROOT, "reports", "regression.md"), "w").write("\n".join(out) + "\n")
    print("\n%d / %d runs passed" % (npass, len(rows)))
    return 0 if npass == len(rows) else 1

if __name__ == "__main__":
    sys.exit(main())
