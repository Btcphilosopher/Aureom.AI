#!/usr/bin/env python3
"""Prove third_party/ is byte-identical to what was vendored.

  check_vendor.py                      SHA-256 of every vendored file vs third_party/SHA256SUMS and MANIFEST.tsv
  check_vendor.py --repo <Aureom.AI>   additionally re-read the repository archives and compare bytes

Exit status 0 = no problems.
"""
import argparse, hashlib, os, sys, zipfile

ARCH_DIR = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5"

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--repo"); a = ap.parse_args()
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    tp = os.path.join(root, "third_party")
    problems = 0; n = 0
    rows = [l.rstrip("\n").split("\t") for l in open(os.path.join(tp, "MANIFEST.tsv")) if not l.startswith("#")]
    sums = {}
    for l in open(os.path.join(tp, "SHA256SUMS")):
        h, p = l.rstrip("\n").split("  ", 1); sums[p] = h
    zips = {}
    for path, arch, zsha, member, fsha in rows:
        n += 1
        fp = os.path.join(tp, path)
        if not os.path.isfile(fp):
            print("MISSING", path); problems += 1; continue
        data = open(fp, "rb").read()
        h = hashlib.sha256(data).hexdigest()
        if h != fsha or sums.get(path) != fsha:
            print("MODIFIED", path); problems += 1
        if a.repo:
            if arch not in zips:
                zp = os.path.join(a.repo, ARCH_DIR, arch)
                if hashlib.sha256(open(zp, "rb").read()).hexdigest() != zsha:
                    print("ARCHIVE HASH DIFFERS", arch); problems += 1
                zips[arch] = zipfile.ZipFile(zp)
            if zips[arch].read(member) != data:
                print("DIFFERS FROM ARCHIVE", path); problems += 1
    extra = []
    for d, _, fs in os.walk(tp):
        for f in fs:
            rel = os.path.relpath(os.path.join(d, f), tp)
            if rel not in ("MANIFEST.tsv", "SHA256SUMS", "PROVENANCE.md") and rel not in sums:
                extra.append(rel)
    for e in extra: print("UNLISTED FILE", e); problems += 1
    print("check_vendor: %d files, %d problems%s" % (n, problems, " (archives compared)" if a.repo else ""))
    return 1 if problems else 0

if __name__ == "__main__":
    sys.exit(main())
