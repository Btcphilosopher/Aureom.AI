#!/bin/bash
# Prints the exact tool versions this project was built and verified with.
for c in verilator yosys iverilog riscv64-unknown-elf-gcc python3 make; do
  if command -v $c >/dev/null 2>&1; then
    case $c in
      python3) v=$($c --version 2>&1 | head -1); v="$v; PyYAML $(python3 -c 'import yaml;print(yaml.__version__)' 2>&1)";;
      riscv64-unknown-elf-gcc) v=$($c --version 2>&1 | head -1);;
      iverilog) v=$($c -V 2>&1 | head -1);;
      *) v=$($c --version 2>&1 | head -1);;
    esac
    printf '%-26s %s\n' "$c" "$v"
  else printf '%-26s %s\n' "$c" "NOT INSTALLED"; fi
done
