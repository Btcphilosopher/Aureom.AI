#!/usr/bin/env python3
"""Lint of the whole DPU system (ControlCore + DPU) with Verilator -Wall, in several configurations, plus negative
elaboration tests: every illegal parameter set and every attempt to enable a blocked engine class must be REFUSED.

  scripts/lint.py        writes reports/lint.md, exit status 0 only if everything is as expected

Waivers apply to vendored files only (scripts/vendored_waivers.vlt); project code is linted with none beyond commented
inline ones.  Yosys elaboration of the same files is done by scripts/synth_all.sh.
"""
import os, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GOOD = {
    "min (defaults)": [],
    "2 tenants, 2 net queues, 2 channels, 2 banks, 64-bit": ["NUM_TENANTS=2", "NUM_NETWORK_QUEUES=2", "NUM_DMA_CHANNELS=2", "DATA_WIDTH=64", "NUM_SRAM_BANKS=2"],
    "4 tenants, 6 queues, 3 channels, 128-bit, 48-bit address": ["NUM_TENANTS=4", "NUM_NETWORK_QUEUES=4", "NUM_COMPUTE_QUEUES=2", "NUM_DMA_CHANNELS=3", "DATA_WIDTH=128",
                                                                "ADDRESS_WIDTH=48", "NUM_WINDOWS=4", "NUM_SRAM_BANKS=4", "SRAM_CAPACITY=131072"],
    "16 tenants, 15 queues, 8 channels, 64-bit address": ["NUM_TENANTS=16", "NUM_NETWORK_QUEUES=8", "NUM_COMPUTE_QUEUES=7", "NUM_DMA_CHANNELS=8", "ADDRESS_WIDTH=64", "NUM_WINDOWS=8"],
    "no compute queue, depth 1": ["NUM_COMPUTE_QUEUES=0", "QUEUE_DEPTH=1", "CPLQ_DEPTH=1"],
}
BAD = {
    "ENABLE_TENSOR=1": ["ENABLE_TENSOR=1"], "ENABLE_CRYPTO=1": ["ENABLE_CRYPTO=1"], "ENABLE_STORAGE=1": ["ENABLE_STORAGE=1"],
    "17 tenants": ["NUM_TENANTS=17"], "0 tenants": ["NUM_TENANTS=0"], "0 network queues": ["NUM_NETWORK_QUEUES=0"],
    "16 queues": ["NUM_NETWORK_QUEUES=8", "NUM_COMPUTE_QUEUES=8"], "9 channels": ["NUM_DMA_CHANNELS=9"],
    "DATA_WIDTH=48": ["DATA_WIDTH=48"], "ADDRESS_WIDTH=24": ["ADDRESS_WIDTH=24"], "9 windows": ["NUM_WINDOWS=9"],
    "SRAM not a multiple of 256": ["SRAM_CAPACITY=65700"], "bank not a power of two": ["SRAM_CAPACITY=98304", "NUM_SRAM_BANKS=1"],
    "MAX_XFER below one beat": ["MAX_XFER_BYTES=2"], "queue depth 0": ["QUEUE_DEPTH=0"],
}

def lint(params, extra=(), top="silicaflux_cloud_dpu", more=()):
    env = dict(os.environ)
    files = subprocess.run(["bash", "scripts/rtl_files.sh"], cwd=ROOT, env=env, capture_output=True, text=True).stdout.split()
    cmd = ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Wno-UNUSEDPARAM", "-Wno-PINCONNECTEMPTY", "-DSFV_NO_CLOCK_GATE",
           "scripts/vendored_waivers.vlt"] + list(extra) + ["-G" + p for p in params] + files + list(more) + ["--top-module", top]
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr

def main():
    rows, bad = [], 0
    for name, p in GOOD.items():
        rc, out = lint(p)
        warns = [l for l in out.splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
        ok = rc == 0 and not warns
        bad += 0 if ok else 1
        rows.append(("lint", name, "PASS (0 warnings)" if ok else "FAIL: " + (warns[0][:100] if warns else "rc=%d" % rc)))
    # the same with the simulation-only assertion module included (SVA are checked for syntax and widths)
    env_old = os.environ.get("DPU_ASSERT")
    os.environ["DPU_ASSERT"] = "1"
    rc, out = lint([], ["--assert", "-DSFD_ASSERT", "-Wno-SYNCASYNCNET"])
    warns = [l for l in out.splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
    ok = rc == 0 and not warns
    bad += 0 if ok else 1
    rows.append(("lint", "min + simulation-only assertions (sfd_assertions)", "PASS (0 warnings)" if ok else "FAIL: " + (warns[0][:100] if warns else "rc=%d" % rc)))
    if env_old is None: del os.environ["DPU_ASSERT"]
    # integration wrapper: the DPU with an AXI4 host-memory master (and its SFB2->AXI4 bridge), two geometries
    for name, p in (("min", []), ("64-bit data, 40-bit address, 2 channels", ["DATA_WIDTH=64", "ADDRESS_WIDTH=40", "NUM_DMA_CHANNELS=2", "NUM_SRAM_BANKS=2"])):
        rc, out = lint(p, top="silicaflux_cloud_dpu_axi", more=["integration/sfd_sfb2_to_axi4.sv", "integration/silicaflux_cloud_dpu_axi.sv"])
        warns = [l for l in out.splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
        ok = rc == 0 and not warns
        bad += 0 if ok else 1
        rows.append(("lint", "AXI4 wrapper (silicaflux_cloud_dpu_axi), " + name, "PASS (0 warnings)" if ok else "FAIL: " + (warns[0][:100] if warns else "rc=%d" % rc)))
    for name, p in BAD.items():
        rc, out = lint(p)
        refused = rc != 0 and ("%Error" in out or "$fatal" in out or "Fatal" in out)
        bad += 0 if refused else 1
        msg = next((l for l in out.splitlines() if "g_err" in l or "Fatal" in l or "%Error" in l), "")
        rows.append(("negative", name, "REFUSED at elaboration" if refused else "NOT REFUSED (bug)"))
    out = ["# Lint and elaboration checks", "", "Verilator 5.020 `-Wall`, vendored files waived by file path only (`scripts/vendored_waivers.vlt`).", "",
           "| Kind | Configuration | Result |", "|---|---|---|"]
    out += ["| %s | %s | %s |" % r for r in rows]
    out += ["", "**%d checks, %d problems.**" % (len(rows), bad)]
    open(os.path.join(ROOT, "reports", "lint.md"), "w").write("\n".join(out) + "\n")
    print("\n".join("%-9s %-60s %s" % r for r in rows))
    print("%d checks, %d problems" % (len(rows), bad))
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
