#!/bin/bash
# =============================================================================
# CloudDPU generic synthesis wrapper (technology independent).  NO PDK: this reports gate-level cell counts of a
# generic AND/OR/XOR/MUX netlist and memory bits; it makes NO frequency, area-in-um2 or power claim.
#
#   scripts/synth.sh [name] [PARAM=value ...]       e.g.  scripts/synth.sh min
#                                                         scripts/synth.sh mt NUM_TENANTS=2 NUM_NETWORK_QUEUES=2 NUM_DMA_CHANNELS=2
#   scripts/synth.sh --list                          the standard configurations used by `make synth`
# Output: reports/synth/<name>.{check,stat_pre,stat,latches}.txt and a one-line summary appended to reports/synth/SUMMARY.md
# =============================================================================
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
CC=third_party/silicaflux-controlcore
name=${1:-min}; shift || true
TOP=${TOP:-silicaflux_cloud_dpu}                 # TOP=silicaflux_control_core synthesizes the reused ControlCore alone
INCS="-I $CC/rtl/generated -I $CC/third_party/silicaflux-sramlib/rtl/mem -I $CC/third_party/silicaflux-sramlib/rtl/mem/backends/asic"
FILES=$(bash scripts/rtl_files.sh | grep -v '^+' | tr '\n' ' ')
PARAMS=""
for p in "$@"; do k=${p%%=*}; v=${p#*=}; PARAMS="${PARAMS}chparam -set $k $v $TOP\n"; done
mkdir -p reports/synth build
REPORT=reports/synth/$name
# fill the template (python: the placeholders contain characters that make sed fragile); parameters are applied AFTER the
# -defer read and BEFORE the hierarchy pass, which is the only order Yosys 0.33 honours
FILES="$FILES" INCS="$INCS" TOPN="$TOP" REPORT="$REPORT" PARAMS="$PARAMS" python3 - <<'PY' > build/synth_$name.ys
import os
t = open("synth/synth_dpu.ys.tmpl").read()
t = t.replace("@FILES@", os.environ["FILES"]).replace("@INCS@", os.environ["INCS"]).replace("@TOP@", os.environ["TOPN"])
t = t.replace("@REPORT@", os.environ["REPORT"]).replace("@PARAMS@", os.environ["PARAMS"].replace("\\n", "\n"))
print(t)
PY
yosys -q -l reports/synth/$name.log build/synth_$name.ys > /dev/null 2>&1 || { echo "SYNTH FAILED: see reports/synth/$name.log"; tail -15 reports/synth/$name.log; exit 1; }
cells=$(grep -E "Number of cells:" $REPORT.stat.txt | tail -1 | awk '{print $NF}')
ffs=$(grep -E '\$_(S?DFF|DFFE|SDFFCE)' $REPORT.stat.txt | awk '{s += $NF} END {print s+0}')
mems=$(grep -E '\$mem_v2' $REPORT.stat.txt | awk '{print $NF}' | tail -1)
lat=$(grep -oE "^[0-9]+ objects" $REPORT.latches.txt | awk '{print $1}' | tail -1)
probs=$(grep -oE "Found and reported [0-9]+ problems" $REPORT.check.txt | awk '{print $4}')
echo "| $name | $TOP | $* | ${cells:-?} | ${ffs:-?} | ${mems:-0} | ${lat:-0} | ${probs:-?} |" >> reports/synth/SUMMARY.md
echo "synth $name ($TOP): generic cells=${cells:-?}  flops=${ffs:-?}  memories=${mems:-0}  latches=${lat:-0}  check problems=${probs:-?}"
