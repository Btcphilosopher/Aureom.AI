#!/usr/bin/env python3
"""Mutation campaign: inject one deliberate RTL bug at a time and check that the verification environment notices.

  scripts/mutate.py list                      show the mutants
  scripts/mutate.py check                     verify that every mutation pattern matches exactly once
  scripts/mutate.py run [ids...] [--jobs N]   build + run the benches for each mutant (default: all)

A mutant is KILLED when its bench fails: a check/assertion/timeout in the system bench (tb_dpu, reduced scenario set) or
in the guard unit bench (tb_guard_unit).  A mutant that SURVIVES is a hole in the tests (or an equivalent mutant) and is
reported honestly in reports/mutation.md.  Mutants are applied to COPIES of the RTL under build/mut_<id>/; the project
tree is never modified.
"""
import concurrent.futures as cf, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# id, file, old, new, description, bench ("sys1" min-config system bench / "sys2" two-tenant bench / "guard" unit bench)
MUTANTS = [
 ("M01", "rtl/dpu/sfd_clouddma.sv", "S_H_WR_REQ: if (hm_req_ready) st_q <= S_H_WR_RSP;",
  "S_H_WR_REQ: if (hm_req_ready) st_q <= last ? S_DONE : S_H_WR_RSP;",
  "COMPLETION BEFORE COMMIT: the last store beat is reported done when it is issued, not when the host acknowledged it", "sys1"),
 ("M02", "rtl/dpu/sfd_host_guard.sv", "wire allow = job_active && ok;", "wire allow = 1'b1;",
  "per-beat HOST guard permits everything", "guard"),
 ("M03", "rtl/dpu/sfd_cmdproc.sv", "else if (op_rd && !win_rd_ok) begin", "else if (1'b0 && op_rd && !win_rd_ok) begin",
  "command processor no longer checks the host READ window", "sys1"),
 ("M04", "rtl/dpu/sfd_cmdproc.sv", "else if (!is_mgmt && d_ten != bound)", "else if (1'b0 && !is_mgmt && d_ten != bound)",
  "descriptor tenant claim is not checked against the queue binding (spoofing)", "sys1"),
 ("M05", "rtl/dpu/sfd_tenant_ctx.sv", "st_q[t] <= silicaflux_cloud_pkg::TS_SCRUBBING;", "st_q[t] <= silicaflux_cloud_pkg::TS_DISABLED;",
  "teardown skips the SRAM scrub (residual data stays for the next owner)", "sys1"),
 ("M06", "rtl/dpu/sfd_sram_guard.sv", "(a_end <= p_end)", "(a_end <= p_end + {1'b0, DWB32})",
  "per-beat SRAM guard off by one beat (one beat past the partition end is allowed)", "guard"),
 ("M07", "rtl/dpu/sfd_tenant_ctx.sv", "if (pol_q[viol_ti] && st_q[viol_ti] == silicaflux_cloud_pkg::TS_ACTIVE)",
  "if (1'b0 && pol_q[viol_ti] && st_q[viol_ti] == silicaflux_cloud_pkg::TS_ACTIVE)",
  "a violating tenant is never quarantined", "sys2"),
 ("M08", "rtl/dpu/sfd_crc32.sv", "32'hEDB8_8320", "32'hEDB8_8321", "CRC-32 polynomial wrong", "sys1"),
 ("M09", "rtl/dpu/sfd_cmdq.sv", "h_credit[q] = (credit_q[q] != '0);", "h_credit[q] = 1'b1;",
  "completion credits ignored (a completion can find its queue full)", "sys1"),
 ("M10", "rtl/dpu/sfd_cmdproc.sv", "if (late_v && late_ti == t[TIW-1:0])                         t_dec[t] = t_dec[t] + 2'd1;",
  "if (late_v && late_ti == t[TIW-1:0])                         t_dec[t] = t_dec[t] + 2'd1;\n      t_dec[t] = 2'd0;",
  "tenant in-flight counter never decremented (a tenant can never drain)", "sys1"),
 ("M11", "rtl/dpu/sfd_hm_port.sv", "if (dp_resetting && out_q && !rsp_taken) orphan_q <= 1'b1;", "if (dp_resetting && out_q && !rsp_taken) orphan_q <= 1'b0;",
  "orphaned host response after a data-plane reset is delivered to the new owner", "sys1"),
 ("M12", "rtl/dpu/sfd_cmdproc.sv", "halted_q       <= 1'b1;", "halted_q       <= halted_q;",
  "a job timeout does not halt dispatch", "sys1"),
 ("M13", "rtl/dpu/sfd_clouddma.sv", "strb[b] = !(partial && (b >= {1'b0, rem}));", "strb[b] = 1'b1;",
  "partial last beat writes the whole word (bytes beyond the transfer are overwritten)", "sys1"),
 ("M14", "rtl/dpu/sfd_win_check.sv", "(!need_w || win_perm[w*2 + 1])", "1'b1",
  "write permission of host windows ignored", "sys1"),
 ("M15", "rtl/dpu/sfd_sfb_gate.sv", "assign m_rsp_error = err_pend_q || s_rsp_error;", "assign m_rsp_error = s_rsp_error;",
  "a refused request is not answered with an error (the master would use garbage)", "guard"),
 ("M16", "rtl/dpu/sfd_regs.sv", "12'h030: fst_q <= fst_q & ~rb_wdata[FN-1:0];", "12'h030: fst_q <= fst_q | rb_wdata[FN-1:0];",
  "FAULT_STATUS write-1-to-clear inverted", "sys1"),
 ("M17", "rtl/dpu/sfd_perf.sv", "if (ev_h2d_beat[s]) b_rd = b_rd + {8'd0, ev_beat_bytes[s*8 +: 8]};", "if (ev_h2d_beat[s]) b_rd = b_rd + 16'd4;",
  "DMA read-byte counter counts 4 per beat instead of the valid bytes", "sys1"),
 ("M18", "rtl/dpu/sfd_cmdproc.sv", "c_push = 1'b1;  c_push_q = s_queue_int;  c_push_data = cpl_s;", "c_push = 1'b1;  c_push_q = (s_queue_int == 4'(NQH)) ? 4'(NQH) : 4'd0;  c_push_data = cpl_s;",
  "completions of a job are delivered to queue 0 instead of the submitting queue (cross-queue leak)", "sys2"),
 ("M19", "rtl/dpu/sfd_cmdproc.sv", "else if (sram_bad)                                                  v_err = silicaflux_cloud_pkg::ERR_SRAM_RANGE;",
  "else if (1'b0 && sram_bad)                                         v_err = silicaflux_cloud_pkg::ERR_SRAM_RANGE;",
  "command processor no longer checks the SRAM partition (only the per-beat guard remains)", "sys1"),
 ("M20", "rtl/dpu/sfd_tenant_ctx.sv", "if (sc_wait_q && dp_resetting) sc_wait_q <= 1'b0;", "",
  "scrubber does not restart a write lost to a data-plane reset (it can wait forever)", "sys1"),
]

def apply(m, dest):
    mid, f, old, new, desc, bench = m
    shutil.rmtree(dest, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl"), os.path.join(dest, "rtl"))
    p = os.path.join(dest, f)
    s = open(p).read()
    if s.count(old) != 1:
        raise RuntimeError("%s: pattern occurs %d times in %s" % (mid, s.count(old), f))
    open(p, "w").write(s.replace(old, new))

def file_list(dest):
    out = subprocess.run(["bash", os.path.join(ROOT, "scripts/rtl_files.sh")], cwd=ROOT, env=dict(os.environ, DPU_ASSERT="1"),
                         capture_output=True, text=True).stdout.split()
    return [os.path.join(dest, x) if x.startswith("rtl/") else x for x in out]

def build_run(m):
    mid, f, old, new, desc, bench = m
    dest = os.path.join(ROOT, "build", "mut_" + mid)
    try:
        apply(m, dest)
    except RuntimeError as e:
        return mid, "ERROR", str(e), 0
    t0 = time.time()
    files = file_list(dest)
    log = open(os.path.join(dest, "build.log"), "w")
    if bench == "guard":
        top = "tb_guard_unit"
        extra = [x for x in files if re.search(r"sfd_(win_check|sfb_gate|host_guard|sram_guard|clouddma|crc32|rr_arb|packetcore_tadapter|job_slot|pkt_hub)\.sv$", x)]
        base = [x for x in files if "third_party" in x and re.search(r"sramlib|datafabric", x)]
        src = ["+incdir+third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem", "+incdir+third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/backends/asic",
               "rtl/pkg/silicaflux_cloud_pkg.sv"] + [x for x in base if x.endswith(".sv")] + extra + ["tb/tb_guard_unit.sv"]
        gen = ["verilator", "--binary", "--timing", "-O1", "--assert", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
               "scripts/vendored_waivers.vlt"] + src + ["--top-module", top, "-Mdir", dest + "/obj", "-o", "vsim"]
        r = subprocess.run(gen, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if r.returncode:
            return mid, "ERROR", "build failed (build/mut_%s/build.log)" % mid, time.time() - t0
        runs = [([dest + "/obj/vsim"], "guard unit")]
    else:
        defs = {"sys1": ["NT=1", "NNQ=1", "NCQ=1", "NS=1", "DW=32", "AW=32", "NW=2", "NB=1"],
                "sys2": ["NT=2", "NNQ=2", "NCQ=1", "NS=2", "DW=32", "AW=32", "NW=2", "NB=2"]}[bench]
        tests = os.path.join(dest, "tests")
        os.makedirs(tests, exist_ok=True)
        s = open(os.path.join(ROOT, "tb/dpu_tests.svh")).read()
        keep = {"sys1": {"t_smoke", "t_boot", "t_mmio", "t_decode", "t_data", "t_saturation", "t_errprop", "t_perf", "t_recovery"},
                "sys2": {"t_smoke", "t_multi", "t_isolation", "t_decode"}}[bench]
        always = {"sram_sum", "perf_get", "perf_clear", "fault_status", "rand_traffic", "mgmt_submit", "mgmt_wait_cpl", "run_test", "t_smoke"}
        marks = [(mm.group(1), mm.start()) for mm in re.finditer(r"^task automatic (\w+)\(", s, re.M)]
        out = [s[:marks[0][1]]]
        for i, (n, st) in enumerate(marks):
            en = marks[i + 1][1] if i + 1 < len(marks) else len(s)
            out.append(s[st:en] if (n in keep or n in always) else "task automatic %s(); endtask\n" % n)
        open(os.path.join(tests, "dpu_tests.svh"), "w").write("".join(out))
        gen = ["verilator", "--cc", "--exe", "--main", "--timing", "-O1", "--assert", "-DSFD_ASSERT", "-Wno-fatal", "-Wno-lint", "-Wno-style",
               "-Wno-TIMESCALEMOD", "-DSFV_NO_CLOCK_GATE", "scripts/vendored_waivers.vlt"] + ["-D" + x for x in defs] + files + \
              ["+incdir+" + tests, "tb/tb_dpu.sv", "--top-module", "tb_dpu", "-Mdir", dest + "/obj", "-o", "vtb"]
        r = subprocess.run(gen, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if r.returncode:
            return mid, "ERROR", "verilator failed (build/mut_%s/build.log)" % mid, time.time() - t0
        r = subprocess.run(["make", "-C", dest + "/obj", "-f", "Vtb_dpu.mk", "-j", "2", "OPT_FAST=-O0", "OPT_SLOW=-O0", "OPT_GLOBAL=-O0"],
                           cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if r.returncode:
            return mid, "ERROR", "make failed (build/mut_%s/build.log)" % mid, time.time() - t0
        sc = ["smoke", "boot", "mmio", "decode", "data", "saturation", "errprop", "perf", "recovery"] if bench == "sys1" else ["smoke", "decode", "multi", "isolation"]
        runs = [([dest + "/obj/vtb", "+test=" + x, "+timeout=60000000"], x) for x in sc]
    killed_by = []
    for cmd, name in runs:
        try:
            r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=900)
            txt = r.stdout + r.stderr
            ok = (r.returncode == 0 and "TB RESULT PASS" in txt)
        except subprocess.TimeoutExpired:
            ok = False; txt = "timeout"
        if not ok:
            first = next((l for l in txt.splitlines() if ("CHECK FAIL" in l or "TB FAIL" in l or "Assertion" in l or "%Error" in l or "timeout" in l.lower())), "failed")
            killed_by.append("%s: %s" % (name, first.strip()[:130]))
    return mid, ("KILLED" if killed_by else "SURVIVED"), "; ".join(killed_by[:2]), time.time() - t0

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    if cmd == "list":
        for m in MUTANTS: print(m[0], m[5], m[4])
        return 0
    if cmd == "check":
        bad = 0
        for m in MUTANTS:
            c = open(os.path.join(ROOT, m[1])).read().count(m[2])
            if c != 1: print("BAD pattern %s occurs %d times in %s" % (m[0], c, m[1])); bad += 1
        print("mutation patterns: %d mutants, %d bad" % (len(MUTANTS), bad))
        return 1 if bad else 0
    ids = [a for a in sys.argv[2:] if a.startswith("M")]
    jobs = 3
    if "--jobs" in sys.argv: jobs = int(sys.argv[sys.argv.index("--jobs") + 1])
    todo = [m for m in MUTANTS if not ids or m[0] in ids]
    res = []
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        for mid, st, why, dt in ex.map(build_run, todo):
            m = next(x for x in MUTANTS if x[0] == mid)
            print("%s %-8s %s | %s (%.0fs)" % (mid, st, m[4][:70], why[:150], dt), flush=True)
            res.append((m, st, why, dt))
    out = ["# Mutation campaign", "", "Generated by `scripts/mutate.py` from real builds and runs. One deliberate RTL bug per mutant, applied to a copy of the RTL.", "",
           "| Id | Bench | Injected bug | Result | First failure |", "|---|---|---|---|---|"]
    for m, st, why, dt in res:
        out.append("| %s | %s | %s | **%s** | %s |" % (m[0], m[5], m[4], st, why.replace("|", "/")[:160]))
    k = sum(1 for r in res if r[1] == "KILLED")
    out += ["", "**%d of %d mutants killed.**" % (k, len(res))]
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(out) + "\n")
    print("%d / %d killed" % (k, len(res)))
    return 0

if __name__ == "__main__":
    sys.exit(main())
