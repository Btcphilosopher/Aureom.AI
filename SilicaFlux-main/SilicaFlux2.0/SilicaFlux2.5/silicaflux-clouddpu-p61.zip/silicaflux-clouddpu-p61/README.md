# SilicaFlux CloudDPU (Project 61)

A **synthesizable cloud data-processing unit**, built by reusing the validated SilicaFlux blocks (ControlCore,
DataFabric, SRAM Wrapper Library) and writing the missing pieces (command queues + processor, CloudDMA, tenant
protection, counters, telemetry port, control firmware) as real RTL — then verifying it by simulation.

* Primary RTL: `rtl/silicaflux_cloud_dpu.sv` · shared transaction format: `rtl/pkg/silicaflux_cloud_pkg.sv`
* Deliverable form: **this zip**. Nothing was committed to GitHub.

## Status in one table — read this first

| Brief item | State |
|---|---|
| ControlCore (RISC-V RV32IM_Zicsr), DataFabric `sfb_crossbar`, SRAM banks | **real, reused unmodified** (vendored byte-for-byte, hash-checked) |
| Cloud command processor, command/completion queues, **CloudDMA**, tenant context + guards, counters, telemetry port, register map, control firmware | **new, implemented, verified in simulation** |
| PacketCore | **TEST ADAPTER** (PASS / XOR32 / BSWAP32 + CRC-32 + RFC 1071 checksum) — it does not exist in the repository and parses no packets |
| VirtualIO, CloudTelemetry consumer | interfaces are real; the host side is a **testbench model** |
| InferenceScheduler / TensorCore, CryptoCore, StorageFabric | **BLOCKED** — not integrated, not verified; `ENABLE_*` must be 0 (elaboration error), engine opcodes complete with `ERR_BLOCKED` |
| PCIe endpoint, MAC/PHY, IOMMU, SR-IOV, Linux driver | not implemented (out of scope; the brief says no Linux) |
| Place-and-route, FPGA, silicon, timing, area, power | **none** — generic Yosys synthesis only |

## Definition of done — met

> *The minimum configuration executes a genuine data-processing transaction end to end in RTL simulation, preserving
> data, completion and permission semantics.*

`min` configuration (1 tenant · 1 packet stream · 1 DMA path · 1 clock), scenario `smoke` and then `data`: host →
command queue → CloudDMA (host read) → local SRAM → PacketCore processing → output buffer in SRAM → CloudDMA (host
write) → **commit acknowledged** → completion record. **Success is never reported before the output is committed**
(assertion `C1`; a shadow-memory comparison at the instant each completion is received; and mutant `M01`, which
reintroduces the bug — completion on issue instead of on acknowledge — and is killed by the testbench). 103 random transactions in `data`, all byte-exact; a host-window violation is refused with the
right error and moves no byte (`decode`, `isolation`, `tb_guard_unit`).

## Results (all from the generated reports; re-run with `make all`)

| | Result | Where |
|---|---|---|
| System regression | **55 / 55 runs passed** — 5 builds (min · 2 tenants · 64-bit · 4-tenant 128-bit · with real firmware), 19 306 checks | `reports/regression.md` |
| Real firmware on the RTL CPU | boot ROM → host-loaded image → CRC → POST → config → **133 firmware checks, 0 fails** + 70 independent testbench checks | `reports/sim/fw/fw.log` |
| Unit benches | layout 60/60 · CRC vs SecureStore golden 402/402 · **per-beat guards without the command processor** 36/36 · AXI bridge 601/601 | `reports/unit/summary.txt` |
| Lint | Verilator `-Wall`: 0 warnings in 8 configurations; 15 illegal parameter sets refused (23 checks, 0 problems) | `reports/lint.md` |
| Mutation | **20 / 20** injected RTL bugs killed (first run 19 / 20 — the survivor exposed a real test hole, fixed, whole campaign re-run) | `reports/mutation.md` |
| Synthesis | Yosys 0.33 generic, 5 configurations, 0 latches, 0 `check` problems; minimum DPU ≈ 38.5 K generic cells (excl. SRAM bits; **not** an area claim) | `reports/synth/SUMMARY.md` |
| Address map / vendor | 13 negative validator cases; 80 vendored files byte-identical | `make check-map check-vendor` |

Defects found during verification, and what each was (RTL / firmware / testbench), are listed honestly in
`docs/05_VERIFICATION.md` §3 — including a real **firmware** bug that only appeared when the real firmware ran on the
real CPU, and five classes of **testbench** bug found by the multi-tenant / multi-channel runs.

## Layout

```
rtl/silicaflux_cloud_dpu.sv        top level (+ rtl/dpu/*.sv: queues, command processor, job slot, CloudDMA, guards, tenant ctx, fabric, perf, telemetry, regs, assertions)
rtl/pkg/                           silicaflux_cloud_pkg.sv (transaction format, codes), generated address-map package
config/dpu_memmap.yaml             the address map (single source) -> scripts/gen_dpu_memmap.py -> RTL package, firmware headers, docs/DPU_MEMORY_MAP.md
firmware/                          control firmware for the ControlCore (freestanding C, no Linux): boot stages, POST, mailbox command set, self-test; build/dpu_fw.{elf,img,hex}
integration/                       AXI4 host-memory wrapper + SFB2->AXI4 bridge
tb/                                system testbench (scoreboard, shadow memory, permission monitor), scenarios, firmware scenario, unit benches
scripts/                           regress.py, mutate.py, lint.py, synth*.sh, run_unit.sh, memmap generator + validator, vendor tools
synth/                             Yosys script template
third_party/                       vendored ControlCore + libraries (unmodified), MANIFEST/SHA256SUMS, PROVENANCE.md
reports/                           regression, mutation, lint, unit, synthesis, tools — generated by the scripts above
docs/                              00 audit · 01 architecture · 02 tenant isolation · 03 firmware & boot · 04 integration · 05 verification · 06 synthesis · 07 limitations · memory map
```

## Reproduce

Tools (Ubuntu 24.04 packages): `verilator` 5.020, `yosys` 0.33, `iverilog` 12, `gcc-riscv64-unknown-elf` 13.2, `python3` + `pyyaml`.
The system-testbench C++ is compiled at `-O0` (≈ 5–12 min per configuration; at `-O1` it takes > 25 min) — the
simulations themselves run in seconds.

```bash
make check-map check-vendor     # generated files fresh, validator negative tests, vendored tree untouched
make fw lint unit               # firmware image, lint + negative elaboration, unit benches (about a minute)
make regress                    # builds 5 testbench configurations and runs 55 scenarios (~15–25 min on 4 cores)
make mutate                     # 20 injected RTL bugs (~45 min)
make synth                      # generic synthesis of 5 configurations
```

## Where to start reading

1. `docs/00_AUDIT.md` — what already existed in the repository, what was reused, what does not exist.
2. `docs/01_ARCHITECTURE.md` — blocks, parameters, transaction format, ordering and commit rules, reset/RAS.
3. `docs/02_TENANT_ISOLATION.md` — *a tenant ID alone does not provide isolation*: how the five protected objects are enforced.
4. `docs/07_LIMITATIONS.md` — what this is **not**.
