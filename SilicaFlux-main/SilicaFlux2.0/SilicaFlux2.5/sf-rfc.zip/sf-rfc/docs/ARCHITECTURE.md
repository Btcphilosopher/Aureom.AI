# SilicaFlux banked register file and operand collector — architecture specification

Status: implemented in `rtl/`, verified in simulation (Verilator) against an independent Python architectural model.
Section 14 lists exactly what is **not** done or not proven. Numbers quoted here come from `results/` (regenerate with
the scripts named there); nothing in this document is an estimate unless it says so.

Contents: 1 scope · 2 geometry and the register→bank mapping · 3 interfaces · 4 same-cycle read/write behaviour ·
5 operand and execution-mask contract · 6 hazards (RAW, WAW, **WAR**) · 7 the collector · 8 arbitration ·
9 back-pressure and the no-drop guarantee · 10 reset and clear · 11 latency · 12 storage cost model ·
13 integration with `sf_simt_ctrl` / SF-G1 · 14 limitations

---

## 1. Scope

`sf_rfc` sits between a SIMT issue stage (one instruction per cycle, as `sf_simt_ctrl`) and the execution units
(one dispatch channel per backend port). It stores every register of every resident warp, reads the source
operands of each issued instruction into a private **collector unit (CU)**, hands the complete instruction to the
execution port, and accepts results back through a small number of writeback ports.

```
 issue ──► [allocate CU] ──► CU0 … CUn-1  (one instruction each, 2 operand slots)
                │               │ read requests (bank,row)          ▲ oldest-ready-first per class
                ▼               ▼                                   │
        [bank read arbiter, 1 grant/bank/cycle] ─► BANK 0 … BANK B-1 ─► dispatch ALU / dispatch MEM ─► execution
                                                     ▲   (1R + 1W RAM, per-lane write enable,
 writeback ports ─► [write arbiter, 1/bank/cycle] ───┘    lazy-zero bits, staging + forwarding)
        ▲ valid/ready (back-pressure)                      completion ──► front end (same cycle as acceptance)
```

Files: `rtl/sf_rfc.sv` (top), `sf_rfc_bank.sv` (one bank), `sf_rfc_ram.sv` (the only array declaration),
`sf_rfc_pkg.sv` (mapping, counters), `sf_rf_base.sv` (baseline for comparison), `sf_rfc_simt_dec.sv` (SIMT decode).

## 2. Geometry and the register→bank mapping

A **warp register** is the pair *(warp, reg)*: one row of `LANES × 32` bits. `r0` is hard-wired to zero (never read from
a bank, writes discarded; its row is simply unused, 1/32 of the array).

| parameter | default | meaning |
|---|---|---|
| `NUM_WARPS` | 8 | resident warps (any ≥ 1) |
| `LANES` | 8 | warp width = execution-mask width (SF-G1 `LANES`, SIMT `WARP_SIZE`) |
| `NUM_BANKS` | 4 | power of two, 1…32. Each bank is a 1-read + 1-write memory |
| `BANK_MAP` | 2 (XOR) | 0 LOW, 1 SKEW, 2 XOR |
| `NUM_CU` | 6 | collector units |

Let `BW = log2(NUM_BANKS)`, `RPW = 32 >> BW` (rows per warp per bank), `ROWS = NUM_WARPS·RPW`.

```
row  = warp·RPW + (reg >> BW)                         identical for every map
bank = reg[BW-1:0]                                    BANK_MAP 0  LOW
bank = (reg[BW-1:0] + warp) mod NUM_BANKS             BANK_MAP 1  SKEW
bank = reg[BW-1:0] XOR ((hi ^ (hi>>BW) ^ warp) mod NUM_BANKS),  hi = reg >> BW        BANK_MAP 2  XOR
```

**One-to-one.** With the row fixed, `bank` is a bijection of `reg[BW-1:0]` for every map (LOW is the identity, SKEW
adds a function of the row, XOR xors a function of the row), so `(bank,row) ↔ (warp,reg)` and no two warp registers
share storage. This is checked mechanically: `scripts/check_bankmap.py` compares the RTL function (`f_bank`) with
`python/rfref/bankmap.py` for all 4 608 combinations of bank count × map × warp × register and re-verifies
bijectivity.

Worked examples, 4 banks: LOW: `(warp 3, r6)` → bank 2, row 25. SKEW: bank `(2+3) mod 4 = 1`. XOR: `(warp 0, r4)` → bank 1,
`(warp 0, r8)` → bank 2 (the upper register bits move the bank, so stride-4 and stride-8 register patterns spread).

**Why XOR is the default — and how strong that argument really is.** LOW leaves the hot registers of real code in one bank
(busiest bank 1.76× the mean at 4 banks, `results/requirements.md`) and loses 9 % IPC overall (`results/compare.md`). SKEW
removes that imbalance but cannot help *within* one warp: two registers of one instruction collide under SKEW exactly when
they collide under LOW (the warp term cancels), and on these programs XOR is statically *worse* at 4 banks (30.6 % vs 25.9 %
of two-operand instructions share a bank). What XOR adds is robustness to register **strides**: with stride-8 registers
(all in bank 0 under LOW) IPC is 0.99 (XOR) / 0.79 (SKEW) / 0.61 (LOW) with 4 units, and 0.99 / 0.99 / 0.61 with the default
6 units — with enough units SKEW's per-warp rotation hides the stride too. On real SIMT streams all three maps are within
0.4 % of each other at the default. So the XOR default is a **margin, not a measured win** at the default configuration: it
costs no measurable throughput and no meaningful logic, and it keeps full speed on strided register use when `NUM_CU` is
reduced to save area. `BANK_MAP=1` is equally defensible.

## 3. Interfaces

All signals are sampled on `posedge clk`; `rst_n` is synchronous, active low. Wide payloads are `LANES·32` bits,
lane *i* in bits `[32i+31:32i]`.

**Issue** (one instruction per cycle): `iss_valid_i`, `iss_ready_o[NUM_CLS]`, `iss_cls_i`, `iss_warp_i`, `iss_tag_i`,
`iss_mask_i`, `iss_use1/2_i`, `iss_rs1/2_i`, `iss_wr_i`, `iss_rd_i`, `iss_payload_i` (opaque, returned at dispatch).
`iss_ready_o[c]` is a function of **registered state only** — never of `iss_valid_i` or the payload — as `sf_simt_ctrl`
requires (its rule D1). A transfer happens when `iss_valid_i && iss_ready_o[iss_cls_i]`. `r0` and unused slots may be
presented as they are: the collector elides them.

**Dispatch** (one channel per class = backend port): `dsp_valid_o[c]`, `dsp_ready_i[c]`, `dsp_warp/tag/mask/wr/rd/payload_o`,
`dsp_op1_o`, `dsp_op2_o`. Once `dsp_valid_o` rises, every output of that channel is **held until `dsp_ready_i`** (no
retraction, no change; checked by the testbench every cycle).

**Writeback** (`NUM_WB` ports, valid/ready): `wb_valid_i`, `wb_ready_o`, `wb_warp_i`, `wb_tag_i`, `wb_we_i`, `wb_rd_i`,
`wb_mask_i`, `wb_data_i`, `wb_aux_i`. The producer holds the record stable until accepted. `wb_ready_o` is combinational in
the *other* ports' records (it is the arbitration result) but never in anything the producer derives from `wb_ready_o`.
**Completion**: `cmpl_valid_o = wb_valid_i & wb_ready_o`, with `warp`, `tag`, `aux` echoed — valid exactly in the
acceptance cycle. Records without a register write (`wb_we=0`, `rd=r0`, empty mask: stores, branches, discarded results)
are always accepted and complete immediately; they never occupy a bank write port.

**Maintenance**: `clr_all_i`, `clr_warp_i[w]` (all registers / one warp read zero from the next cycle; must be applied
while that part is quiescent — asserted in simulation), `idle_o`. **Counters**: `perf_o[16]` (indices in `sf_rfc_pkg`).
**Monitor** outputs (`mon_*`) exist for verification and are unconnected in synthesis.

## 4. Same-cycle read/write behaviour (the rule)

> A read **launched** in cycle *t* returns the content of the register after **all writes accepted in cycles ≤ t**,
> lane by lane (**write-through**). A lane that is not in a write's mask is never forwarded or modified.

*Launch* = the cycle in which the bank arbiter grants the read (the row address is presented to the RAM). *Accept* = the
cycle in which `wb_valid_i && wb_ready_o` for a record that writes. Data of a read launched in *t* is valid in *t+1* and is
captured into the CU at the end of *t+1*.

How the RAM-level collisions are covered (`sf_rfc_bank.sv`): a write accepted in cycle *c* is **staged** (registered) and
written into the RAM at the end of *c+1* ("landing"). The RAM is read-first (it returns the old word when read and
written at the same edge), so a read launched in:

| launch cycle | where the write accepted in *c* is found | mechanism |
|---|---|---|
| ≥ *c+2* | in the RAM | ordinary read |
| *c+1* (RAM samples at the landing edge) | in the **landing copy** `f_*` captured at launch | overlay per lane |
| *c* (same cycle as acceptance) | in the staging register `stg_*` during *c+1* | overlay per lane (`WRITE_THROUGH=1`) |

Overlay order is *RAM → landing copy → staging copy*, so two writes to one row in flight resolve oldest-first.
`WRITE_THROUGH=0` removes the last row of the table (a read launched in the accept cycle sees the old value) and its mux
(area in `results/synth.md`). With `sf_simt_ctrl` the last case never occurs — its scoreboard clears one cycle after
completion, so a consumer launches at *c+1* at the earliest — but the module is specified for any front end, and the
write-through path is exercised and checked at module level (279 same-cycle collisions in the first stress run).

**Simultaneous writes.** At most one write per bank is accepted per cycle (one RAM write port). Two ports offering
*different rows of one bank* in one cycle: round-robin winner accepted, the other sees `wb_ready_o = 0` and must hold.
Two ports offering the **same row** in one cycle: the **lower-numbered port is always accepted first** (a higher port is
the younger instruction), so the final value is the higher port's on overlapping lanes; the second is accepted in the
next cycle. Acceptance order is application order. Nothing is merged, dropped or reordered.

## 5. Operand and execution-mask contract

The collector delivers to the execution unit, for each instruction, two operand rows `op1`, `op2`:

* the **exact architectural register row** (all lanes, including lanes outside the mask) when the slot is used, the register
  is not `r0`, and the mask is not empty;
* **all zeros** otherwise (unused slot, `r0`, fully masked instruction). Zero is guaranteed — never stale data from a previous
  occupant: the operand registers of a CU are cleared at allocation.
* If both slots name the same register, one bank read feeds both (slot 2 *follows* slot 1).

**Mask handling.** (a) a fully masked instruction performs *no* bank read and no write but still dispatches and completes;
(b) the mask travels with the instruction (`dsp_mask_o`) and the execution unit returns the *effective* mask with its
result; (c) a register write applies **only lanes whose mask bit is set** — per-lane write enables all the way into the RAM
(one 32-bit memory per lane, §FPGA_MEMORY) — and a lane outside the mask is never written, forwarded to, or zeroed (except
the one-time zero fill of a never-written row, §10). Branch outcomes ride the completion sideband (`aux`).

## 6. Hazards

The front end (`sf_simt_ctrl`) owns **RAW** and **WAW**: an instruction does not issue while one of its sources or its
destination has a write pending, and a pending bit clears one cycle after the completion. This module's rules make that
sufficient:

* **RAW.** The consumer is allocated ≥ 1 cycle after the producer's completion *c*, so its first read launches in ≥ *c+1*
  > *c*: by the rule of §4 it sees the producer's write (through the staging/landing overlays if the RAM has not yet been
  written).
* **WAW.** Two writes to one register never overlap in time (front-end rule); they are accepted in completion order.
* **WAR — introduced by collection, closed here.** In `sf_simt_ctrl` operands are sampled *at the issue handshake*, so a
  younger instruction can never overtake the read of an older one and the scoreboard does not track WAR. A collector reads
  operands *after* issue, so without a rule a younger same-warp instruction could dispatch, execute and write register `R`
  while an older one is still waiting (e.g. behind a bank conflict) to read it. **Rule: the CUs of one warp dispatch
  strictly in issue order** (an older same-warp unit that has not dispatched blocks all younger ones; different warps are
  independent).

  *Proof sketch.* Let X be older than Y in one warp, Y writes `R`, X reads `R`. A result can only be produced by a
  dispatched instruction, so Y's write is accepted at some cycle `w ≥ dispatch(Y) + 1`. In-order dispatch gives
  `dispatch(Y) ≥ dispatch(X) + 1` (units dispatch from registered state, so two same-warp units never go in one cycle). X dispatches only
  when both operands are captured, i.e. its read was launched at `l ≤ dispatch(X) − 1`. Hence `l < w`, and a read
  launched *before* the write is accepted cannot see it. ∎ (Assumes the backend only writes back instructions it was
  dispatched — the dispatch/writeback contract.)

  *Evidence that the rule is load-bearing, and what it costs.* Removing it is caught: a targeted probe (`war_*` traces: one
  warp whose older instruction's reads are starved on a hot bank while a younger one writes that register) makes the RTL's
  own assertion fire — `WAR violation: write w0 r4 accepted while unit 2 still has to read it` — and the testbench reports
  out-of-order dispatch (`results/mutation_full.md`). *Cost:* `PERF_ORDER_BLK` counts unit-cycles where a complete unit was
  held behind an incomplete older unit of its warp; at the default configuration it is **0 on all 11 traces** (including
  59 k real SIMT instructions); it only fires in the probe with a deeper pool (172–182 unit-cycles at 8 units). A first
  version of the mutation test for this rule was itself invalid (it removed the rule from a perf-only signal) and "passed";
  see `docs/VERIFICATION.md` for how that was found.

## 7. The collector

Each CU holds one instruction: descriptor (class, warp, tag, mask, `rd`, payload), two operand slots, and its position in
the age order. A slot is in exactly one of: *not needed*, **request** (waiting for a bank read port), **in flight**
(read launched; data captured next cycle), **done**. A CU is *complete* when no slot is requesting or in flight.

* **Allocation.** Lowest free CU; `iss_ready_o[c]` requires a free CU **and** fewer than `CLS_CAP = NUM_CU−1` CUs of class
  *c* (see "liveness"). It is a **flip-flop output**: per-class occupancy and the free-unit count are kept in counters (they change by
  at most one allocation and one dispatch per class per cycle) and next cycle's readiness is computed from their next values.
  That is exactly the direct definition evaluated one cycle early — an RTL assertion compares the two every cycle — and it takes
  the population count off the issue → read-request → arbitration path (ECP5 Fmax 38 → 56 MHz, `docs/RESULTS.md` §5).
  The age order is a matrix (`older[a][d]`: *d* was allocated before *a*), updated at allocation.
* **FAST_READ** (default 1): the first read attempt happens *in the allocation cycle* using the issue-bus fields, so a
  conflict-free instruction reaches dispatch two cycles after issue (one for operand-free instructions); with 0 the first
  attempt is the next cycle (three cycles). The new unit is the youngest requester.
* **Capture.** Bank data is captured into the slot that requested it (`cu_bank[c][s]` selects the bank output); a granted
  request is never re-issued (`request → in flight → done` is monotone; asserted).
* **Dispatch.** Per class, the **oldest complete, unblocked unit** is selected. After `dsp_valid_o` rises the selection is
  locked until `dsp_ready_i`, so a newly completed older unit cannot change the payload under a stalled consumer.
* **Class cap (liveness).** If the MEM port stalls, MEM instructions pile up in CUs. With no cap they could occupy *every*
  CU and starve ALU instructions of other warps — a stall of one port would stall the other. With the cap each class always
  has ≥ 1 CU, so the unstalled class keeps **at least one unit's worth of throughput**. Measured with the MEM port stalled for
  900 cycles starting at cycle 200 (`memflood`: memory warps with four independent loads in flight each): **283 ALU dispatches
  with the cap, 5 without it** (a mutant; identical on all 6 seeds tried), **0 for the baseline**; with a 2 000-cycle stall on
  `memstall`: 627 vs 3 (baseline). The property is a *floor*: without the cap, starvation only happens if the stalled class actually
  fills the pool, which on `memstall` depends on what is in flight when the stall begins (14 vs 287 on some seeds, 543 vs 543 on
  others), which is why the regression and the mutation test use the flooding trace.
* **`RD_SHARE`** (default 0): co-grant requests for the *same row* of the winner's bank. Measured hit rate: **0.00 %** of
  reads in every configuration (with `FAST_READ`, each request is normally served at its own allocation), so it is off;
  the parameter is kept, verified, and costed.

### 7.1 Isolation: operands of different instructions or warps are never mixed

Mixing could happen in four places; each has a structural guarantee and a test that would fail if it were broken
(the mutation that breaks it is in `results/mutation_full.md`):

| where | guarantee | broken by (mutant, all **caught**) |
|---|---|---|
| bank → operand slot | A slot captures only from the bank recorded for **its own request** (`cu_bank`, registered at allocation) and only in the cycle after **its own grant** (`in flight`); the row it asked for is the row the bank launched (asserted: every granted requester of a bank wants the launched row). | slot 2 captured from slot 1's bank; request for the wrong warp's row; co-grant ignoring the row |
| previous occupant → next instruction | The operand registers of a CU are **cleared at allocation**; a slot that is not needed therefore delivers zero, never the previous instruction's data. | operand registers not cleared (both slots) |
| CU → execution unit | One unit per class is selected, **locked** from the cycle `dsp_valid_o` rises until `dsp_ready_i`; the payload is a mux of exactly that unit (one-hot select, asserted). A unit is freed only by its own dispatch handshake. | lock removed; unit freed without handshake; dispatch of an incomplete unit |
| execution unit → register file | A result is written to the row addressed by `(wb_warp, wb_rd)` of its own record; the completion echoes `warp`, `tag`, `aux` of that same record in the acceptance cycle. | destination row built from the wrong warp; completion before acceptance |

The testbench makes any mix visible: every register value is produced by an operand-sensitive function of its sources, so a
row from the wrong warp, register, instruction or lane produces a different value, is compared with the Python model at the
dispatch of *every* instruction (all lanes), and would also corrupt every dependent instruction and the final register dump.

## 8. Arbitration

**Bank read** — one grant per bank per cycle among the pending requests of that bank. `RD_ARB=1` **oldest-first** (older CU
wins, slot 1 before slot 2): a request waits only behind requests of *older* units (each makes at most two requests, each
served once) and its own unit's slot 1, so its wait is ≤ `2·(NUM_CU−1)+1` cycles. `RD_ARB=0` round-robin with a pointer that
never passes a pending requester: ≤ `2·NUM_CU`. The stress testbench checks the looser bound `6·NREQ+16` on every request
(`S8`); the largest latency actually observed with one bank under hammering was 11 cycles (`results/regress.md`). Throughput difference between the two is within noise (`results/compare.md`); oldest-first is
the default because it also keeps the older instruction of a warp ahead, which is what the in-order rule wants.
A request that loses **stays pending and retries** — contention costs cycles, never accesses.

**Writeback** — per bank, round-robin over the ports whose record targets that bank, pointer advancing past the winner
(a loser is accepted within `NUM_WB` cycles: bounded, checked as `S6`); the same-row rule of §4 overrides the rotation when
two ports offer one row. The loser is back-pressured through `wb_ready_o`.

**Dispatch** — oldest-first within a class (§7); the two classes dispatch independently in the same cycle.

## 9. Back-pressure and the no-drop guarantee

Every place where two things want one resource has a visible loser that **waits**:

| contention | loser | where the wait is held |
|---|---|---|
| two reads, one bank | pending request | CU slot state `request` |
| two writes, one bank | `wb_ready_o = 0` | the writeback producer |
| no free CU / class cap | `iss_ready_o = 0` | the front end |
| execution unit not ready | `dsp_valid_o` stays high, payload frozen | the CU |

There is no code path that discards a request, a write or a completion: *writes accepted = completions raised for records
that write* and *dispatched = allocated* are cross-checked against independent testbench counts in every run. **Prolonged
downstream stalls** (execution port stalled 2 000–3 000 cycles, both ports, 90 % bubbles) propagate as `dsp_valid` held →
CUs full → `iss_ready_o` low; on release everything drains and all work completes (`results/regress.md`, scenario 6).
Deadlock freedom: a CU frees only at dispatch; dispatch needs only operands and the port; operands need only bank read ports
(always granted within the bounds above); writeback acceptance depends on nothing but bank write ports; the class cap
prevents one stalled port from filling the pool.

## 10. Reset and clear

RAM cannot be cleared in one cycle, so there is **no clear sequencer and no busy period**. Every row has a *clean* flip-flop:
set by `rst_n`, `clr_all_i` and `clr_warp_i`; cleared when the row first lands a write. A clean row reads as zero regardless of
the RAM content; the first write to a clean row writes the whole row (lanes outside the mask get zero) so no stale lane
survives a partial first write. Consequently the registers of a fresh kernel launch read zero in **one cycle**
(SIMT spec: "registers are zero at launch (backend duty)"), versus the 32-cycle sequencer of SF-G1. `rst_n` additionally drops
every CU, staged write and in-flight request (any reset pulse length ≥ 1 cycle; tested with 1-, 2- and 3-cycle pulses and
random RAM power-up values); during reset all ready/valid outputs are forced low so no transfer can complete.

## 11. Latency (cycles, no conflicts, no back-pressure)

| path | FAST_READ=1 | FAST_READ=0 | baseline `sf_rf_base` |
|---|---|---|---|
| issue → dispatch, ≥ 1 register read | 2 | 3 | 2 |
| issue → dispatch, no register read | 1 | 1 | 2 |
| write accepted → visible to a read | same cycle | same cycle | same cycle |
| producer completion → consumer dispatch (front-end clear + issue + read) | 1 + 2 | 1 + 3 | 1 + 2 |

Each denied read attempt adds one cycle. The two designs deliberately share the 2-cycle minimum so differences in the
comparison come from the architecture (banking vs replication, collection vs a single in-order stage).

## 12. Storage cost model

Bits for `W = LANES·32`, `NW` warps, `B` banks, `U` CUs: array `NW·32·W` (banked) or **2×** that (baseline: replicated copy
per source operand); clean bits `NW·32` (×2); per bank staging + landing copies `2W + 2·LANES + 16`; operand buffers `2W·U`
(banked) / `2W` (baseline); control `≈ U(110+U)`. Table with synthesis cross-check: `results/synth.md`, `docs/RESULTS.md`.

## 13. Integration

`sf_simt_ctrl` ↔ `sf_rfc` (decode: `sf_rfc_simt_dec`, cross-checked against `sf_simt_pkg::sf_predecode` on 128 000 words):

| `sf_simt_ctrl` | `sf_rfc` |
|---|---|
| `iss_valid_o`, `iss_ready_i[p]` | `iss_valid_i`, `iss_ready_o[p]` |
| `iss_port_o` | `iss_cls_i` (0 ALU, 1 MEM) |
| `iss_warp_o`, `iss_slot_o`, `iss_mask_o` | `iss_warp_i`, `iss_tag_i`, `iss_mask_i` |
| `iss_instr_o` | decoder → `iss_use1/2, rs1/2, wr, rd`; also `iss_payload_i` |
| `cmpl_valid_i[p]`, `cmpl_warp_i`, `cmpl_slot_i`, `cmpl_taken_i` | `cmpl_valid_o[p]`, `cmpl_warp_o`, `cmpl_tag_o`, `cmpl_aux_o` |

**Reset.** `sf_simt_ctrl` uses an asynchronous reset (`rst_ni`); `sf_rfc` uses a synchronous one (§10). Wiring one `rst_ni` to
both is correct provided it is **released synchronously** to `clk`; Verilator flags the mixed use (`SYNCASYNCNET`) in
`sf_simt_rfc_top.sv` and it is left visible on purpose.

**`WRITE_THROUGH`.** `sf_simt_ctrl` clears its scoreboard bit one cycle after completion, so the same-cycle overlay of §4 can never
be exercised; the reference wrapper sets `WRITE_THROUGH = 0`, which is **cycle-identical** to 1 on every scoreboard-legal run
(`results/regress.md`: 58 212 cycles of `simt_rand`, 6 576 forwarded reads through the landing-edge overlay) and removes ~9 % of the
LUTs (`results/synth.md`).

**This changes the SIMT downstream contract D2** ("operands are sampled at the issue handshake"): operands are now sampled at
*dispatch*, after a few cycles. Everything the front end relies on remains true — exactly one completion per accepted
instruction, ≥ 1 cycle after issue, loads/stores of one warp performed in issue order (in-order dispatch) — and WAR is
provided by §6. The SF-G1 core keeps its own guard-predicate file (`sfg1_regfile`'s predicate part); the effective mask
`iss_mask & guard` is what `iss_mask_i` / `wb_mask_i` carry.

## 14. Limitations and non-goals

* **Verified in simulation only, against a testbench model of the front end.** `sf_simt_ctrl` was **not** co-simulated with
  this module; the interface is validated by the decode cross-check, by a closed-loop testbench that implements the
  documented issue rules (RAW/WAW scoreboard with the one-cycle clear, 4 in-flight slots per warp, fetch gap, branch wait), and
  by the module-level stress test.
* **No Vivado/Quartus.** Utilisation is Yosys; the only timing is ECP5 place-and-route (§ `docs/FPGA_MEMORY.md`).
* Single-issue (one instruction per cycle) — a dual-issue front end needs a second issue port and doubles the read demand.
* Two source operands per instruction (the SilicaFlux ISA's maximum); a 3-operand FMA needs a third slot per CU.
* Bank count is a power of two; `NUM_WARPS` need not be.
* One memory per lane per bank means narrow, deep banks are not supported (a 1024-bit row is `LANES=32` memories wide).
* The WAR rule makes each warp's dispatch in-order; an out-of-order-per-warp front end would need per-register WAR tracking instead.
* Liveness is **checked** (bounded-wait assertions, stall scenarios), not formally proven.
