# Verification

Everything below was run with Verilator 5.49 (2-state, `--x-initial unique` with randomised power-up values) and Python 3.13.
`make regress stress mutate` reproduces it; raw outputs are in `results/`.

## 1. Strategy: independent layers, each able to fail on its own

| layer | what it is | what it can catch |
|---|---|---|
| **L1 Python architectural model** (`python/rfref/model.py`) | Per-warp register arrays, `r0` rule, lane masks, operand-zero rules, a deterministic operand-sensitive value function. Knows nothing about timing, banks or arbitration. Hand-worked unit tests (16). | The reference. Each instruction's expected operand rows and result row are written to `<trace>.exp`. |
| **L2 closed-loop trace testbench** (`tb/tb_rfc_trace.sv`) | Front-end model (issue rules of `sf_simt_ctrl`), backend (random latencies, stall windows), checker. **Same file, same trace, same timing for baseline and banked.** Checks every dispatched instruction against L1: both operand rows (all lanes), warp/tag/mask/class/`rd`/`wr`, exactly-once, per-warp order = program order, payload stability under stall, every writeback result, every completion record, scoreboard conservation, final register state (read back through 32 `DUMP` instructions per warp), and recounts the RTL's counters independently. | Wrong operand (register, warp, instruction, lane, stale value), lost/duplicated/reordered work, protocol violations, WAR/RAW/WAW through the whole flow, counter errors. |
| **L3 module-level stress** (`tb/tb_rfc_stress.sv`) | Unconstrained random traffic against a *cycle-accurate shadow model of the documented visibility rule* (§4 of the architecture): registers from a tiny hot pool, writes to arbitrary registers at arbitrary times from either port, same-row simultaneous writes, empty/partial masks, mid-run resets of 1–3 cycles, quiescent clears. Checks S1–S9 (operands, once-and-in-order, completion = acceptance, ≤ 1 write/bank/cycle, same-row ordering, bounded wait of writes and of reads, one row per bank per cycle, counters). | What the scoreboard-legal traces cannot reach: same-cycle read/write collisions, same-row ordering, reset/clear semantics. |
| **L4 bank unit test** (`tb/tb_rfc_bank.sv`) | The bank (RAM + clean bits + staging + overlays) against a shadow of the same rule, ≈ 170 k reads per seed, ≈ 62 k of them through the forwarding paths. | The subtlest logic, in isolation. |
| **L5 RTL assertions** | `sf_rfc.sv`: slot-state exclusivity and ownership, dispatch only of eligible one-hot units, ≤ 1 write per bank, completion only for an offered record, `clr_*` only when quiescent, one launched row per bank, and (STRICT) **WAR violation**. | Internal invariants on every cycle of every run. |
| **L6 cross-checks against the repository** | `tb_decode_xcheck`: SIMT decode adapter vs `sf_simt_pkg::sf_predecode` (128 000 words, 0 differences); `check_bankmap.py`: RTL mapping vs Python (4 608 combinations, 0 differences, bijective); integration wrapper elaborates against the unmodified SIMT RTL in two geometries. | Misreading the core's register-access contract; mapping errors. |
| **L7 named regression** (`scripts/run_regress.py`) | The six required scenarios with *behavioural* assertions (§3). 96 checks. | "The run passed but the scenario never happened." |
| **L8 mutation campaigns** (`scripts/mutate_rfc.py`, `mutate_bank.py`) | 31 + 8 injected defects; a mutant must make some test fail. | Whether L2–L5 can actually fail. |
| **L9 lint** | Verilator `-Wall`, clean on 7 parameter sets (1 bank, 32 banks, 1 lane, 32 lanes, non-power-of-two warps/units, 3 writeback ports …) for `sf_rfc`, clean for `sf_rf_base`. Illegal parameter values are rejected at elaboration. | Width/latch/unused/implicit problems. |

## 2. Results

(The comparison sweep of §2 was run before the issue-readiness was registered. After that change, 410 sampled sweep runs — 10 designs ×
all 11 traces × the 4 profiles — were replayed and are **cycle-identical** in cycles, conflicts, write stalls, maximum latency and total
wait; all other suites below were rerun on the final RTL.)

| item | result |
|---|---|
| Python unit tests | 16 passed |
| Named regression | **96 / 96** checks (`results/regress.md`) |
| Stress matrix | 9 configurations × 5 traffic profiles (default, saturated, slow sink, mid-run reset, quiescent clear) × 3 seeds = **135 runs, 0 failures**; coverage: 1 799 889 dispatches, 30 162 same-cycle read/write collisions, 5 276 same-row simultaneous-write pairs, 45 053 write bank conflicts, 671 431 partial-mask writes, 349 887 empty-mask instructions |
| Mutation campaign (collector, writeback, reset, clear, baseline) | **31 / 31 caught**; bank unit test **8 / 8** (`results/mutation_full.md`) |
| Trace comparison | 27 designs × 11 traces × 4 timing profiles, **every run checked against L1** (`results/compare.md`); no run failed |

## 3. The six required scenarios

| required test | how it is exercised | assertion that it really happened |
|---|---|---|
| **repeated accesses to one bank** | `NUM_BANKS=1` (every access in one bank); 4 banks with the LOW map against stride-4/8 registers (all in bank 0); stress with a 7-register pool | conflict rate ≥ 15 % (measured 83–85 %), all instructions dispatched, **max latency 9–11 cycles ≤ the bound 36**; the default XOR map is 1.6× faster than LOW on the same stride |
| **simultaneous writes** | `ldburst`/`uni_*`/`loopy` (ALU and MEM results land together), stress with two ports aiming at one bank and at one row | write bank conflicts 49–167 per run, each back-pressured (stalled port-cycles = conflicts), **accepted writes = completions = testbench count**, 1 723 same-row pairs, lowest port always first (S5) |
| **dependent instructions** | `dep1` (serial chain), `dep8`, `loopy`, and the same-cycle collisions of the stress test | forwarding on 373 of 658 chain instructions; the dependent-chain throughput equals the baseline (IPC 0.2575 both) |
| **partial masks** | `uni_mixed` (36 % partial), `loopy` (35 %), real SIMT streams `simt_dir` (7 %) / `simt_rand` (60 %); stress with 224 k partial writes | final register state, and every operand row in between, equal the model lane by lane |
| **reset** | `+reset_at` 150/531/1200 with 1-, 2- and 3-cycle pulses, 8–6 instructions in flight at the reset, RAM power-up values randomised; stress reset profile; baseline too | the trace restarts and all registers read as zero; counters restart with the DUT |
| **prolonged downstream stalls** | MEM port stalled 2 000 cycles; ALU port 1 500; **both ports 3 000**; periodic MEM stall; 20 %/10 % ready with 70 % writeback bubbles | nothing lost or duplicated, back-pressure reaches `iss_ready` (e.g. 2 997 issue-blocked cycles), recovery to normal; **ALU keeps flowing: 627 dispatches in the 2 000-cycle MEM stall vs 3 for the baseline** |

## 4. What the mutation campaign taught me about my own testbenches

The first campaign caught 20 of 24. The four misses were all informative, and one *result* corrected a belief:

1. **"In-order dispatch removed" was missed — and the mutant was invalid.** It edited a perf-only copy of the condition, so it was
   equivalent to the original. I first read the miss as "the rule is unnecessary" and checked that hypothesis properly: a
   *precise* counter (`ORDER_BLK` = complete unit held behind an **incomplete** older unit, not merely "older unit present")
   showed the hazard never occurs on realistic traffic, and a probe trace (`war_*`: older instruction starved on a hot bank,
   younger instruction writing its source) was built until the situation occurred (172–182 events at 8 units). With the
   mutant fixed, the RTL's `WAR violation` assertion fires and the testbench reports out-of-order dispatch. Conclusions:
   the rule is necessary; it costs nothing on real traffic.
2. **"Class cap ignored" was missed** — a liveness property, invisible without a long stall and a *progress* criterion. Added a
   stall scenario with a floor on the other class's dispatches. It then went **missed a second time** when the shipped default
   changed from 4 to 6 units: the scenario's loads were consumed quickly, so the stalled class did not always fill the larger pool and
   the mutant behaved like the original on some seeds (543 vs 543 ALU dispatches; 14 vs 287 on others). The property is a
   conditional floor, so the probe must *saturate* the pool: `memflood` (four independent loads in flight per memory warp), stall at
   cycle 200 (later windows are invalid probes: the ALU-only warps have run out of work), floor 150 → deterministic on all 6 seeds
   tried (283 with the cap, 5 without). The mutation campaign now runs at the shipped default, which is what exposed this.
   *Afterwards* the issue-readiness was registered (`docs/RESULTS.md` §5, timing). The class-cap mutant is now caught by the RTL's own check
   that the registered readiness equals the direct definition ("a unit is free and fewer than `CLS_CAP` of the class are allocated"),
   every cycle of every run; the stall-progress probe caught the same defect on the pre-change RTL. Two further mutants target the
   new occupancy/free counters.
3. **"`r0` writes not discarded" was missed** — architecturally invisible (`r0` rows are never read), but it wastes a bank write
   slot and makes `PERF_WB_ACCEPT` wrong. Added an independent testbench count of accepted register writes.
4. **"Same-cycle write-through overlay removed" was missed at system level** — correctly: the scoreboard guarantees a consumer
   never launches in the producer's acceptance cycle, so the path is unreachable end-to-end. It is covered by the stress test
   and the bank unit test (both catch it). This is also why `WRITE_THROUGH` is a parameter.

Defects in the testbenches themselves found by running them (not by the RTL failing):
* the "minimum activity" check counted only the segment after the last reset, so the **unmutated** design failed it;
* a 3-cycle reset hid the "staged write survives reset" mutant (the write lands harmlessly while reset is still asserted); reset
  pulses are now 1–3 cycles;
* the testbench's own statistics were not cleared on reset, so the counter cross-checks failed after a mid-run reset;
* the first "operand wait" metric went negative (operand-free instructions dispatch in 1 cycle, not the assumed 2) — replaced by
  wait beyond each instruction's own minimum;
* a concurrent-build race in the sweep scripts (two jobs compiling one directory), and a pip-Verilator precompiled-header
  defect (worked around, see `python/rfref/run.py`).

No functional **RTL** defect was found by L2–L7 after the first complete version; the evidence that those layers could have
found one is L8, not their passing. I would not expect a design this small to be bug-free on that basis alone, which is why
the stress test, the bank unit test and the mutation campaign exist.

## 5. What is NOT verified

* **No co-simulation with `sf_simt_ctrl`.** The front end is modelled in the testbench from its documentation, the decode is
  cross-checked against its RTL, and the integration wrapper is elaborated against its RTL, but the real control unit has not
  been run against this register file.
* **No formal proof.** Liveness and the WAR argument (architecture §6) are a proof sketch plus bounded-wait checks.
* **Simulation only**, one simulator (Verilator, 2-state): X-propagation, gate-level and post-route simulation were not run.
  RAM power-up contents are randomised, which exercises the lazy-zero logic but is not a 4-state check.
* **FPGA RAM inference was checked in Yosys only.** Vivado/Quartus behaviour (read-during-write mode in particular) is an
  assumption documented in `docs/FPGA_MEMORY.md`.
* Simulated widths: 8 lanes × 8 warps for every trace and sweep; **32 lanes × 8 warps** (the SIMT default, 1 024-bit rows) on 8
  traces for both designs (`results/lanes32.md`, all pass); the module-level stress test at 1–4 lanes and 1–5 warps. Wider
  than 32 lanes, more than 8 warps in system-level runs, `NUM_WB = 3` and `NUM_CLS = 1` are only linted/elaborated.
* Dual-issue front ends and 3-source instructions are out of scope.
