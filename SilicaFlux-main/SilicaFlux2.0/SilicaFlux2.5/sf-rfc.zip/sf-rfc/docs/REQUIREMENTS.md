# What the SilicaFlux core requires of its register file

This document records what was inspected in the repository **before** the bank count, port count and arbitration policy
were chosen, what the core actually demands, and how each design parameter follows from that. Every number marked ⟨m⟩ is
measured by `python/analyze_requirements.py` (output in `results/requirements.md`) on the repository's own programs.

## 1. What exists in the repository (and what does not)

| source (zip inside `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`) | what it contributes |
|---|---|
| `silicaflux-simt (1).zip` → `docs/ARCHITECTURE.md`, `rtl/sf_simt_ctrl.sv`, `rtl/sf_simt_pkg.sv`, `model/sfisa.py`, `model/sfref.py` | The GPU **front end**: single-issue SIMT control unit, 8 resident warps, 32-lane warps by default, instruction set, scoreboard, issue/completion bus, the *downstream contract* (D1–D4) and fairness assumptions (F1–F5). **Explicitly leaves the register file and ALUs to "the downstream".** |
| `sf-g1-execution-core.zip` → `docs/SF-G1_SPEC.md`, `docs/MICROARCHITECTURE.md`, `rtl/sfg1_regfile.sv` | An existing **register file** for a lane-parallel integer execution core: per-lane 32×32 RAMs, **two replicated copies** (one per source operand) so both operands read in one cycle, **one write port**, same-cycle write-through, per-lane write enables from the execution mask, a 32-cycle post-reset clear sequencer, single warp, no collector. Its own README states that its ISA/interfaces are *assumed*, anchored only to the SilicaFlux-v1 ALU encodings. |
| `register_bank.sf`, `forwarding_unit.sf`, `README.md` (older scalar control core) | Vocabulary only (write-through vs forwarding, "higher-numbered write port is younger and wins", a banking hook): this is the scalar pipeline, not the SIMT GPU core, and is not the target. |

The "SilicaFlux GPU" therefore = the SIMT front end + an SF-G1-style lane-parallel backend. No design of a multi-warp
register file or an operand collector exists in the repository; `sf_rfc` supplies the missing downstream block and
`sf_rf_base` reconstructs the existing SF-G1 approach (with the warp dimension added) as the comparison baseline.

## 2. The register-access contract of the core

From `sfisa.py` / `ARCHITECTURE.md` §3 and §9 — and **cross-checked against the SIMT RTL's own `sf_predecode`** by
`tb/tb_decode_xcheck.sv` (128 000 random words, 0 differences):

| instruction | register reads | register write | port |
|---|---|---|---|
| `add sub mul and or xor shl shr sar slt sltu` | rs1, rs2 | rd | ALU |
| `addi` (also `mov`/`movi`) | rs1 | rd | ALU |
| `lui`, `s2r` | — | rd | ALU |
| `bnz`, `bz` | rs1 | — (returns a per-thread taken mask) | ALU |
| `ldg`, `lds` | rs1 (address) | rd, *later* (load return) | MEM |
| `stg`, `sts` | rs1 (address), rs2 (data) | — | MEM |
| `nop exit ssy sync bar jmp` | — (executed inside the control unit) | — | none |

Fixed facts: 32 registers per thread, `r0` reads zero and ignores writes, 32-bit data, ≤ 2 source reads and ≤ 1 write per
instruction, **one issue per cycle**, **two backend ports** (ALU, MEM), **two completion channels** (so up to 2 register
writes per cycle), up to `NUM_SLOTS = 4` instructions in flight per warp, completions may arrive out of order, the
execution mask arrives with the instruction (`iss_mask_o`) and only active lanes may be written.

Hazard contract of the front end: the scoreboard tracks **RAW and WAW** only; **WAR is not tracked because operands are
sampled at the issue handshake** (D2). A pending bit clears one cycle after the completion (registered, "no
completion-to-issue bypass"), so a dependent instruction issues ≥ 1 cycle after its producer's completion.

## 3. Measured demand ⟨m⟩

84 programs (24 fault-free directed programs + 60 random legal programs of the repository's generator), run through the
lock-step SIMT reference model (real divergence masks, real register allocation): **142 918 backend-bound instructions**.

| quantity | value |
|---|---|
| register **reads per instruction** after eliding `r0`, duplicate registers and empty masks | **mean 1.12** — 0 reads: 25.5 %, 1 read: 36.7 %, 2 reads: 37.8 % |
| nominal source operands (ISA view) | 0: 3.1 %, 1: 57.9 %, 2: 39.0 % |
| `r0` reads (need no bank access) | 32 033 slots (a third of slots are `movi`/`mov`-style `r0` sources) |
| register **writes per instruction** | **0.82** |
| MEM-port instructions | 9.8 % |
| partially masked instructions (some, not all, lanes active) | 55.7 % (divergence is the norm, not the exception) |
| RAW distance ≤ 2 instructions within a warp | 45.3 % of dependent reads |
| a source register was also read by one of the previous 4 instructions of the warp | 37.5 % |
| hottest read registers | r26 16.8 %, r14 10.1 %, r23 5.4 %, r18 5.1 % (loop counters and per-thread ids) |
| two operands of one instruction in the same bank — 2 banks: LOW 51.6 % / SKEW 51.6 % / XOR 44.5 %; 4 banks: 25.9 / 25.9 / **30.6 %**; 8 banks: 8.3 / 8.3 / 7.3 % | static |
| busiest-bank load ÷ mean, 4 banks | LOW **1.76**, SKEW 1.00, XOR 1.00 |

## 4. How the requirements fix the parameters

| decision | evidence |
|---|---|
| **Banks, not replication, not a multi-ported RAM.** An FPGA memory has one write and one (or two) read ports. Replicating the whole file for a second read port doubles the RAM (SF-G1's choice) and the file here is `NUM_WARPS·32·LANES·32` bits (64 Kib at 8×8, 256 Kib at 8 warps × 32 lanes). Banking multiplies read *bandwidth* at constant storage. | Mean demand 1.12 reads/cycle at 1 IPC. |
| **≥ 2 banks, 4 chosen.** One bank would be read-bound: 1.12 reads/cycle on a 1-read/cycle port → utilisation > 100 %, IPC ≤ 0.89 even with perfect scheduling (measured: −27 %). Two banks: 56 % utilisation and a quarter of real instructions conflict. Four: 28 % per bank. Eight buys ≤ 0.5 % IPC for +2 Kib of storage and a wider crossbar. | §3 + `results/compare.md` (bank-count sweep). |
| **Write ports.** ≤ 2 results/cycle (two completion channels), 0.82 writes/instruction. Each bank has one write port; with ≥ 2 banks two simultaneous writes usually go to different banks and both proceed. The single write port of the baseline stalls 0.086 writeback-cycles per write, the 4-bank design 0.015. | `results/compare.md`. |
| **Mapping: warp-aware, XOR-folded.** The hot registers of real code concentrate (r26, r14 …): LOW maps them to a few banks (1.76× imbalance). SKEW fixes the imbalance but not strides. XOR does both; on real code all three are equal within 0.4 %, on strided register use XOR is 1.6× faster than SKEW. | §3, `compare.md`. |
| **Operand collector with ≥ 5 units.** A bank-conflicted instruction must not block the instructions behind it. A unit is occupied allocate → capture → dispatch → free ≈ 4 cycles, so 4 units cannot sustain 1 IPC with any conflict (measured: 2 units −55 %, 3 −23 %, 4 −5 %, **6 = baseline throughput**). | sweep. |
| **Elide `r0` / empty-mask / duplicate reads.** A third of read slots are `r0`; 1.7 k are duplicates; a masked-out instruction needs nothing. Each avoided read is bank bandwidth saved. | §3. |
| **Forwarding + write staging.** 45 % of dependent reads are ≤ 2 instructions after the producer, and the front end lets a consumer issue one cycle after completion — the write has not landed in the RAM yet. | §3, `ARCHITECTURE.md` §4. |
| **Per-lane write enables and a never-written-row rule.** 56 % of instructions are partially masked. | §3. |
| **WAR protection inside the module.** Operand reads move from issue to a later point, which silently invalidates the front end's "no WAR" assumption. | `ARCHITECTURE.md` §6. |
| **Lazy-zero reset, no sequencer.** SIMT: registers are zero at kernel launch; SF-G1 spends 32 cycles per clear. A 256-flop clean vector clears everything in one cycle. | `ARCHITECTURE.md` §10. |
| **Read co-grant (`RD_SHARE`) is optional and off.** 37.5 % *static* source reuse looked promising; measured co-grant hit rate is 0.00 % because, with the first read attempted at issue, same-row requests are rarely pending together. | `compare.md`. |

## 5. Assumptions (not found in the repository, stated so they can be challenged)

* **Warp width = `LANES`.** SF-G1's default is 8 lanes, `sf_simt_ctrl`'s default `WARP_SIZE` is 32; both are `LANES` here.
  Simulation and comparison use 8 (all traces), synthesis is reported for 2, 8 and 32.
* **Backend ports and write ports.** Two dispatch classes (ALU/MEM) and two writeback ports are taken from the two
  completion channels of `sf_simt_ctrl`; `NUM_WB` is a parameter.
* **Execution-unit contract.** The backend writes back only instructions it has been dispatched, holds a writeback record stable
  until accepted, and returns the effective mask — this is what makes the WAR proof go through.
* **Guard predicates** (SF-G1) are outside the module: the effective mask `iss_mask & guard` is what is presented.
* Values: data are opaque 32-bit words; ALU/memory semantics are not modelled in the RTL (the testbench uses an
  operand-sensitive hash so that any wrong operand corrupts the result and everything downstream).
