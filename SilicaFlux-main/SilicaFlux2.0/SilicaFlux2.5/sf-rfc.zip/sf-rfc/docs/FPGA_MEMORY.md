# FPGA memory inference: assumptions, what the tools did, what is not known

## 1. What the RTL declares

There is **one** place where an array exists: `rtl/sf_rfc_ram.sv`.

```systemverilog
(* ram_style = ... *) logic [31:0] mem [0:ROWS-1];          // 32 bits wide
always_ff @(posedge clk) begin
  if (we) mem[waddr] <= wdata;                              // ONE write port
  rdata <= mem[raddr];                                      // ONE read port, registered (synchronous read)
end
```

* **One write port and one read port, nothing else.** No other module indexes an array; every operand read and every
  register write goes through the arbiters of `sf_rfc.sv`, which grant **at most one read and one write per bank per cycle**.
  Multi-porting is obtained by *banking* (more memories), never by assuming a memory with more ports. The baseline obtains its
  second read port by *replication* (two memories written together), which is exactly what it pays 2× storage for.
* **32 bits wide, one instance per lane per bank.** A bank row is `LANES × 32` bits and a write has a per-lane mask, so each
  lane has its own memory with its own write enable. The enable is a whole-word enable: the tool needs **no byte-enable /
  write-mask RAM feature** (which differs between vendors and between LUTRAM and block RAM). Total instances: `LANES × NUM_BANKS`
  (banked), `LANES × 2` (baseline).
* **Read-first coding style** (`rdata <= mem[raddr]` in the same block as the write, non-blocking): if a read and a write hit the
  same address in one cycle, the read returns the *old* word.
* **`RAM_STYLE`**: 0 no attribute (tool decides), 1 `ram_style = "block"`, 2 `ram_style = "distributed"`.
* **No RAM reset.** RAM cannot be cleared in one cycle. Power-up contents are *never relied on*: per-row *clean* flip-flops
  (`FDSE`, one per warp register) make a never-written row read as zero, and the first write to a row zero-fills the lanes it
  does not cover (architecture §10). The clean bits are deliberately flip-flops, not RAM: they must all be set in one cycle by
  `rst_n` / `clr_all_i`, and read asynchronously at launch.

## 2. Assumptions about the target memory (what must hold for the RTL to be correct)

| # | assumption | consequence if false |
|---|---|---|
| A1 | The memory is a simple dual-port RAM: 1 synchronous-write port, 1 read port with the address registered at the clock edge. | The arbitration would not be sufficient — but nothing is assumed beyond this. |
| A2 | **Read-during-write on the same address and same edge returns the old word *or* the new word**, per lane, per word — either is fine. | `sf_rfc_bank.sv` overlays the colliding write explicitly (landing-edge overlay `f_*`), so READ_FIRST and WRITE_FIRST are both correct. |
| A3 | The read-during-write mode is **not NO_CHANGE** (output holds its previous value). | **Incorrect operation**: the landing-edge overlay assumes the RAM output is *some* defined word of that row, and a held value is the previous row. The code reads every cycle (`rdata <= mem[raddr]`, no read enable), which does not give a tool a reason to choose NO_CHANGE; check the vendor report. |
| A4 | The read output may be a LUTRAM asynchronous read followed by a fabric register, or a block-RAM synchronous read **without** the optional output register (1-cycle read latency). | With the optional BRAM output register the read latency becomes 2 cycles and the launch→capture timing of the collector is off by one. Do not enable `DOA_REG`/output-register inference (`REGCEB`/"output pipeline" options). |
| A5 | Contents at power-up are arbitrary. | None: the design does not use them (verified with Verilator `+rand+reset+2`, see `docs/VERIFICATION.md`). |
| A6 | A write enable of 0 leaves the word untouched (no read-modify-write corruption of neighbouring bits). | Standard for all vendors' RAMs. |

Vendor notes (what is known versus assumed — **only Yosys was run**):

* **Xilinx 7-series / UltraScale.** LUTRAM (`RAM32M`, `RAM64M`, `RAM64X1D` …) is a 1-write/1-read SDP memory with asynchronous
  read; the registered read in the RTL becomes the fabric flop after it, collision returns the old word (READ_FIRST by
  construction). Block RAM (`RAMB18E1`/`RAMB36E1`) in SDP mode with the template above is READ_FIRST. The same-clock
  READ_FIRST template is the one in the vendor coding guides. *Not run in Vivado.*
* **Intel (Quartus).** MLAB/M9K/M20K "old data" read-during-write behaviour is selected from this template for same-clock
  ports; if a device cannot do it natively Quartus adds bypass logic (functionally harmless). A "don't care" mode would
  violate A2 — verify in the Fitter's RAM report. *Not run.*
* **Lattice ECP5.** `TRELLIS_DPR16X4` (distributed, 16×4) and `DP16KD` (18 Kb, `WRITEMODE`). *Yosys mapping only; place-and-route
  timing was run with nextpnr (§5).*
* **ASIC.** Replace `sf_rfc_ram` by a 1R1W compiled SRAM macro (or 2P register file): the interface (§1) is the portable contract;
  the same-edge collision is already covered by the overlay.

## 3. LUTRAM or block RAM?

A bank holds `ROWS = NUM_WARPS·(32/NUM_BANKS)` rows per lane. A block-RAM primitive (18 Kb: 512 × 36) is used efficiently only
for deep memories:

| configuration (8 lanes) | rows per lane memory | 36-bit-wide BRAM18 row utilisation | tool choice (Yosys, `RAM_STYLE=0`) |
|---|---|---|---|
| baseline (2 copies of the whole file) | 256 | 50 % | block RAM on both families |
| banked, 4 banks | 64 | 12.5 % | LUTRAM on Xilinx 7-series; block RAM on ECP5 |
| banked, 1 bank | 256 | 50 % | block RAM |
| banked, 8 banks | 32 | 6 % | LUTRAM |

Rules of thumb: below ≈ 128 rows per lane-memory use **distributed RAM** (`RAM_STYLE=2`); at 256 rows and above (e.g. 32 warps ÷
4 banks, or 1–2 banks) use block RAM (`RAM_STYLE=1`). Set the style explicitly rather than trusting "auto": the two tools disagreed above.
Measured resource counts are in `results/synth.md` (summarised in `docs/RESULTS.md` §5).

## 4. Why the logic around the memories is as large as it is

The memories are not the dominant FPGA cost of a collector. The wide datapaths are: the capture crossbar (every operand slot
selects among the bank outputs), the per-bank forwarding overlays (3-way per-lane mux + landing/staging copies), the dispatch
multiplexers (every class selects among the units) and the operand buffers themselves (2 rows per unit). All of them scale
linearly with `LANES × 32`; the number of units, banks and classes multiplies them. `docs/RESULTS.md` §5 gives the measured
numbers, including the unit-count trade-off, and states the cost plainly.

## 5. Timing: what exists and what does not

* **Xilinx / Intel timing: none.** No Vivado/Quartus run was available; Yosys alone produces no Xilinx timing. Do not infer one.
* **ECP5 (LFE5U-85F-6, CABGA381): post-place-and-route Fmax from nextpnr-ecp5**, measured on the DUT inside a pin-limited shell
  (`synth/sf_rfc_synth_top.sv`: registered inputs from a shift chain, registered outputs XOR-folded; the shell's own paths are
  short). It bounds the DUT's internal register-to-register paths and **does not model** the arrival times of inputs from the
  neighbouring SIMT/execution blocks. Table: `docs/RESULTS.md` §5.
* The paths worth checking first in a vendor tool: (1) issue bus → bank/row decode → arbitration → RAM address (the
  `FAST_READ` path); (2) writeback arbitration → staging register data mux (`LANES·32`-bit wide, high fan-out select);
  (3) unit selection → operand multiplexers → execution unit. If (1) or (3) is critical, `FAST_READ=0` (one more cycle of
  latency) and registering the dispatch outputs respectively are the first remedies.

## 6. Checklist for the first Vivado/Quartus run

1. Confirm the number of inferred RAM instances = `LANES × NUM_BANKS` (banked) / `LANES × 2` (baseline) and their type.
2. Confirm the read-during-write mode is READ_FIRST or WRITE_FIRST (never NO_CHANGE / "don't care") and that no output register
   was merged into the RAM.
3. Confirm the clean bits are `FDSE` flops with synchronous set (256 for 8 warps) and not absorbed into a RAM.
4. Run the module-level stress test with the vendor's post-synthesis netlist (random RAM initial values) before trusting timing.
