# Results: baseline vs banked register file / operand collector

All numbers are produced by the scripts in this package from closed-loop RTL simulation (Verilator) in which **every
dispatched instruction of every run is checked against the Python architectural model**: 27 designs × 11 traces × 4 timing
profiles = 1 188 runs, 9.77 million instructions, **0 failing runs** (`results/compare.json`, `results/compare.md`).
Baseline and banked designs get the *same* trace files and the *same* timing plusargs; only the DUT differs.

## 1. What is compared

| | **baseline** (`sf_rf_base`) | **banked** (`sf_rfc`, default) |
|---|---|---|
| architecture | SF-G1's approach + warp dimension: **two replicated copies** of the whole register file (one per source operand), **one write port**, **one in-order operand stage** | **4 banks** (1R+1W each), XOR mapping, **6 collector units**, per-bank write ports, oldest-first read arbitration, per-class dispatch |
| read conflicts | none by construction | yes — arbitrated, never dropped |
| minimum issue→dispatch | 2 cycles | 2 cycles (1 for operand-free instructions) |
| shared | the same RAM/forwarding/lazy-zero bank module, the same ports and operand contract | |

Traces (8 warps × 8 lanes, `python/gen_traces.py`): **real SIMT streams** (`simt_dir`: the 24 fault-free directed programs;
`simt_rand`: 24 random legal programs, 56 632 instructions, real divergence masks) and **synthetic** ones the real programs
don't stress — `uni_mixed`, `uni_full`, `loopy` (compiler-like unrolled loops), `hammer8`/`hammer4` (all registers in one bank
under the LOW map), `dep1`/`dep8` (serial dependency chains), `ldburst` (bursts of loads → simultaneous writebacks), `memstall`
(memory-heavy and ALU-only warps). Profiles: `ideal` (fast, always ready), `typical` (ALU latency 2±2, MEM 8±6), `bursty` (75 %/50 %
port readiness, 25 % writeback bubbles), `memstall` (MEM port stalled 900 of every 3 000 cycles).

## 2. Throughput

Geometric-mean IPC, banked default vs baseline:

| profile | all 11 traces | real SIMT streams only |
|---|---|---|
| ideal | **+0.1 %** | −0.3 % |
| typical | **−0.0 %** (0.8303 vs 0.8305) | +0.0 % (0.8842 vs 0.8840) |
| bursty back-pressure | **+12.3 %** | **+8.1 %** |
| MEM port stalled 30 % of the time | +0.6 % | +1.5 % |

* With an always-ready downstream the two are equal: 4 banks and 6 units hide the bank conflicts. Per trace (`typical`): `simt_dir`
  0.804 vs 0.805, `simt_rand` 0.972 vs 0.970, `uni_mixed` 0.998 vs 0.996, `loopy` 0.943 vs 0.955 (−1.3 %, the worst case),
  `dep1` 0.256 vs 0.256.
* **The gain is in the stall behaviour, and it comes from collection (several instructions in flight), not from banking.** The
  baseline's single operand stage holds one instruction; when its dispatch target is not ready everything behind it waits, including
  instructions of the *other* port. Prolonged-stall scenario (MEM port stalled, `memstall` trace): ALU dispatches **while the MEM
  port is stalled: 627 in 2 000 cycles (banked) vs 3 (baseline)**; 287 vs 0 for a 900-cycle stall (`results/regress.md`).
  *Caveat on fairness:* a baseline with one operand register per port would close part of this gap; the baseline here is the
  existing SF-G1 structure on purpose.
* **Dependent instructions** are not slowed: the serial chain `dep1` runs at the same IPC as the baseline (0.2575 both);
  forwarding supplies 373 of its 658 reads.

## 3. Bank conflicts, operand wait, write back-pressure (profile `typical`)

| design | read conflict rate | instr. with a denied read | wait mean (cycles beyond the instruction's own minimum) | wait p99 | writeback stalls per write |
|---|---|---|---|---|---|
| baseline | 0 (by construction) | n/a | 0.000 | 0 | **0.086** |
| **4 banks, XOR, 6 units (default)** — all traces | 9.9 % | 12.8 % | 0.60 | 2 | **0.016** |
| &nbsp;&nbsp;same, real SIMT streams only | 11.5 % | 13.9 % | 0.72 | 2 | 0.011 |
| 1 bank | 78.9 % | 76.8 % | 3.52 | 8 | 0.060 |
| 2 banks, XOR | 30.6 % | 35.7 % | 1.00 | 3 | 0.033 |
| 8 banks, XOR | 2.1 % | 2.6 % | 0.26 | 2 | 0.008 |
| 4 banks, LOW map | 40.7 % | 20.3 % | 0.98 | 7 | 0.014 |
| 4 banks, SKEW map | 12.7 % | 17.1 % | 0.64 | 2 | 0.016 |

(Definitions: read conflict rate = requester-cycles denied by bank arbitration ÷ requester-cycles; "wait" includes every cause —
bank conflicts, waiting for the dispatch port, the in-order rule. Full table in `results/compare.md`.)

* Conflicts exist (≈ 1 instruction in 8) but cost only 0.6 cycles on average and ≤ 2 cycles at the 99th percentile, which the
  collector hides.
* One bank is **read-bound** (−26 % IPC overall), as the requirement analysis predicted (1.12 reads/instruction vs one read port).
* **The write side is where banking wins outright:** the single write port of the baseline stalls 0.086 port-cycles per write,
  the 4-bank design 0.016 (5.4× fewer), because the two simultaneous results usually target different banks.

## 4. Design choices, and the measurement behind each

| choice | evidence | strength |
|---|---|---|
| **4 banks** | 1 bank −26 % IPC; 2 banks −0.7 % (SKEW) / −2.8 % (XOR) IPC with 3× the conflict rate and 2× the write stalls of 4; 8 banks +0.1 % for more crossbar | solid; 2 banks (SKEW) is a defensible smaller point |
| **6 collector units** | 2 units −53 %, 3 −20 %, 4 −1.4 % (−2.7 % real), **5 −0.1 %**, 6 −0.0 %, 8 −0.0 % | 5 is the throughput knee; 6 adds margin (bursty profile: 4/5/6 units +9.4/12.2/12.3 %) |
| **oldest-first vs round-robin read arbitration** | geomean IPC 0.8303 vs 0.8307 | **no measurable difference**; oldest-first kept for its tighter wait bound |
| **`FAST_READ` (read attempt at allocation)** | off: −2.2 % IPC overall and −2.1 % on real streams at 6 units (+9.0 % instead of +12.3 % in the bursty profile); +1 cycle of latency and each unit is occupied one cycle longer | solid |
| **XOR map** | see `ARCHITECTURE.md` §2: equal to SKEW at 6 units; protects stride patterns at 4 units; LOW loses 9 % | a margin, not a measured win at the default |
| **`RD_SHARE` (co-grant) off** | **0 of 123 325 reads** were shared | solid negative result |
| **in-order dispatch per warp** (WAR rule) | needed for correctness (probe + assertion); **0 events on all 11 traces** at the default | solid |
| **`WRITE_THROUGH=1`** | unreachable with `sf_simt_ctrl` (consumer launches ≥ 1 cycle after completion), exercised at module level; costs one overlay mux | kept for generality; `=0` is correct for this front end |


## 5. FPGA cost and timing: what the throughput parity costs


Utilisation = design synthesised standalone. `LUT` excludes LUTs used as RAM (`RAM32M`/`RAM64M`, reported separately as 4 LUT6 each); `RAMB18` counts 18 Kb blocks. IPC columns are geometric means over the 11 traces of `results/compare.md`, relative to the baseline.

| design | LUT | LUT as RAM | FF | RAMB18 | LUT vs baseline | FF vs baseline | IPC typical (all / real) | IPC bursty (all) |
|---|---|---|---|---|---|---|---|---|
| baseline | 2278 | 0 | 1445 | 16 | 1.0× | 1.0× | +0.0% / +0.0% | +0.0% |
| banked_default | 12378 | 1408 | 7063 | 0 | 6.1× | 4.9× | -0.0% / +0.0% | +12.3% |
| banked_cu5 | 10536 | 1408 | 6461 | 0 | 5.2× | 4.5× | -0.1% / +0.0% | +12.2% |
| banked_cu4 | 9850 | 1408 | 5859 | 0 | 4.9× | 4.1× | -1.4% / -2.7% | +9.4% |
| banked_cu2 | 7423 | 1408 | 4660 | 0 | 3.9× | 3.2× | -53.4% / -56.5% | -41.9% |
| banked_B1 | 5567 | 0 | 4401 | 8 | 2.4× | 3.0× | -25.8% / -7.3% | -3.6% |
| banked_B2 | 9962 | 0 | 4950 | 16 | 4.4× | 3.4× | -2.8% / -0.7% | +9.7% |
| banked_B8 | 26438 | 1536 | 10252 | 0 | 12.3× | 7.1× | +0.1% / +0.1% | +12.5% |
| banked_nofast | 12231 | 1408 | 7039 | 0 | 6.0× | 4.9× | -2.2% / -2.1% | +9.0% |
| banked_share | 12586 | 1408 | 7063 | 0 | 6.1× | 4.9× | -0.0% / +0.0% | +12.3% |

### Same designs, Lattice ECP5 mapping

| design | LUT4 | FF | DPR16X4 (distributed RAM) | DP16KD (block RAM) |
|---|---|---|---|---|
| baseline | 3475 | 1989 | 0 | 16 |
| banked_default | 20915 | 8175 | 0 | 32 |
| banked_cu5 | 18042 | 7573 | 0 | 32 |
| banked_cu4 | 15977 | 6971 | 0 | 32 |
| banked_cu2 | 10099 | 5772 | 0 | 32 |
| banked_B1 | 7643 | 4937 | 0 | 8 |
| banked_B2 | 11960 | 6020 | 0 | 16 |
| banked_B8 | 34556 | 10252 | 1024 | 0 |
| banked_nofast | 20586 | 8151 | 0 | 32 |
| banked_share | 21370 | 8175 | 0 | 32 |

### Options and what they cost (7-series, relative to the default `banked_default`)

| option | LUT | FF | note |
|---|---|---|---|
| banked_wt0 | -1096 (-9 %) | -24 | WRITE_THROUGH=0: removes the same-cycle overlay (unreachable with sf_simt_ctrl); cycle-identical on every scoreboard-legal run; RAM LUTs 1408, RAMB18 0 |
| banked_share | +208 (+2 %) | +0 | RD_SHARE=1: co-grant comparators; measured hit rate 0.00 %; RAM LUTs 1408, RAMB18 0 |
| banked_nofast | -147 (-1 %) | -24 | FAST_READ=0: no issue-cycle read attempt; −2.2 % IPC; RAM LUTs 1408, RAMB18 0 |
| banked_perf | +903 (+7 %) | +522 | PERF_EN=1: the 16 saturating 32-bit counters (instrumentation); RAM LUTs 1408, RAMB18 0 |
| banked_ram_block | -52 (-0 %) | -1024 | RAM_STYLE=1: block RAM instead of LUTRAM (64-row memories use 12.5 % of a RAMB18); RAM LUTs 0, RAMB18 32 |
| banked_ram_dist | +0 (+0 %) | +0 | RAM_STYLE=2: distributed RAM; RAM LUTs 1408, RAMB18 0 |
| baseline_ram_dist | 2901 | 1957 | baseline in distributed RAM; RAM LUTs 2816, RAMB18 0 (absolute, not a delta) |
| baseline_ram_block | 2278 | 1445 | baseline in block RAM; RAM LUTs 0, RAMB18 16 (absolute, not a delta) |

### Where the logic goes (one bank synthesised standalone)

| block | LUT | LUT as RAM | FF | RAMB18 |
|---|---|---|---|---|
| one bank, 64 rows × 8 lanes (banked: ×4) | 959 | 352 | 864 | 0 |
| one bank, 256 rows × 8 lanes (baseline: ×2) | 1335 | 0 | 804 | 8 |
| one bank, 64 rows, WRITE_THROUGH=0 | 697 | 352 | 858 | 0 |
| **banked default: 4 banks** | 3836 | 1408 | 3456 | 0 |
| **banked default: total** | 12378 | 1408 | 7063 | 0 |
| **collector logic (total − 4 banks)** | 8542 | 0 | 3607 | – |
| **baseline: total** | 2278 | 0 | 1445 | 16 |

Attribution is approximate: a bank synthesised alone keeps logic (e.g. the `rd_hit`/`idle` monitor outputs) that is optimised away in context, which is why the baseline total (2 banks + its operand stage) comes out *below* two standalone banks. Read the collector row as an upper bound.

### Scaling with warp width (default design, 7-series)

| lanes | banked LUT | banked LUT as RAM | banked FF | baseline LUT | baseline FF | baseline RAMB18 |
|---|---|---|---|---|---|---|
| 2 | 4621 | 352 | 2371 | 1086 | 653 | 4 |
| 8 | 12378 | 1408 | 7063 | 2278 | 1445 | 16 |
| 32 | 43571 | 5632 | 25831 | 7010 | 4613 | 64 |

### Timing: ECP5 (LFE5U-85F-6) place & route, 4 lanes, pin-limited shell, 100 MHz requested, seeds 1-3

Fmax of the `clk` domain reported by nextpnr-ecp5. **This is not a Xilinx or Intel number.** The shell registers every input and output, so the figure bounds the DUT's internal register-to-register paths only.

| design | seed 1 | seed 2 | seed 3 | median (MHz) |
|---|---|---|---|---|
| banked_B2_L4 | 52.3 | 53.0 | 52.5 | 52.5 |
| banked_cu4_L4 | 64.1 | 58.5 | 61.7 | 61.7 |
| banked_default_L4 | 55.7 | 57.2 | 54.3 | 55.7 |
| banked_nofast_L4 | 58.2 | 65.7 | 60.5 | 60.5 |
| banked_wt0_L4 | 52.9 | 55.5 | 53.2 | 53.2 |
| baseline_L4 | 93.8 | 89.7 | 94.7 | 93.8 |

Critical path of the first banked run (nextpnr excerpt):

```
Info:       type curr  total name
Info:   clk-to-q  0.52  0.52 Source g_dut.dut.cu_row[3]_TRELLIS_FF_Q_5.Q
Info:    routing  1.16  1.68 Net g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_2_D_LUT4_Z_D_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D[0] (71,19) -> (73,21)
Info:                          Sink g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D_LUT4_Z.D
Info:                          Defined in:
Info:                               /share/lattice/cells_map_trellis.v:108.23-108.24
Info:      logic  0.24  1.92 Source g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D_LUT4_Z.F
Info:    routing  0.99  2.91 Net g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D[2] (73,21) -> (71,23)
Info:                          Sink g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z.D
Info:                          Defined in:
Info:                               /share/lattice/cells_map_trellis.v:108.23-108.24
Info:      logic  0.24  3.14 Source g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z.F
Info:    routing  0.63  3.78 Net g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D[3] (71,23) -> (71,23)
Info:                          Sink g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_2_C_LUT4_D_Z_LUT4_Z_C_LUT4_Z_1.D
```

**Timing reading guide.** Fmax is from nextpnr-ecp5 (speed grade 6, 100 MHz requested, 3 seeds) on a 4-lane build inside a pin-limited
shell. Neither design meets 100 MHz. The first version of the banked design closed at ≈ 38 MHz; its critical path was the
*readiness* computation (a per-class population count feeding the issue → read-request → arbitration path). Registering the readiness
(occupancy counters, cycle-identical behaviour: 410 / 410 replayed sweep runs unchanged, and an RTL assertion compares it with the
direct definition every cycle) raised it to **56 MHz**. The path that now limits the banked design runs from a collector-unit
register through dispatch selection into the occupancy counters: 17.5 ns, of which **13.7 ns is routing** (a 20 k-LUT, wide,
high-fan-out netlist at default placement effort). Dropping `FAST_READ` (which removes the issue-cycle arbitration path) gives
60 MHz, four units 62 MHz: none of the cheap levers closes the gap to the baseline's 94 MHz.

## 6. Verdict

| | per cycle | per FPGA resource / per second |
|---|---|---|
| throughput, downstream always ready | **parity** (0.8303 vs 0.8305 geomean IPC) | the baseline clocks ≈ 1.7× faster on ECP5 (≈ 94 vs ≈ 56 MHz) → ≈ 78 vs ≈ 46 M instr/s |
| throughput under bursty back-pressure | **+12.3 %** (real SIMT streams +8.1 %) | baseline still ≈ 1.5× faster per second (54 vs 36 M instr/s) |
| stall tolerance (ALU work while MEM is stalled) | **627 vs 3 dispatches** | – |
| writeback contention | **5.4× fewer stalls** | – |
| register-file RAM bits | **−50 %** (total storage −46 %) | the baseline's RAM lives in 16 block RAMs the FPGA has to spare; banked uses 1 408 LUT-RAM LUTs |
| logic | – | **6.1× LUT, 4.9× FF** (8 lanes); 7.0× / 5.6× at 32 lanes (LUT counts include LUTs used as RAM) |

**What this means.** The banked register file and operand collector reach the baseline's throughput per cycle with half the RAM bits,
and are clearly better at tolerating a non-ready downstream and at write contention. **On this FPGA, at this size (8 lanes, 8 warps,
two source operands), they are not an improvement in area or in clock rate**: the replicated baseline is ≈ 6× smaller and ≈ 1.7× faster in
MHz, and the collector's cost is its wide operand buffers, bank→slot crossbars, forwarding registers and dispatch multiplexers, not the
register array. (For scale: SF-G1's whole execution core was reported to close at 69–76 MHz on the same family, limited by its
multiplier, so in a full core the baseline's register file would not be the limiter whereas the collector would.)

Where the balance would shift, and why this is a design for it rather than a claim that it already wins:

* **RAM-limited targets** (an ASIC with SRAM macros, or an FPGA with few block RAMs): the 2× replication is the baseline's cost and
  banking removes it. The RAM-bit saving grows linearly with `NUM_WARPS × LANES`; the collector's buffers do not grow with `NUM_WARPS`.
* **Three or more source operands** (an FMA-class instruction): replication needs one copy per source (3×, 4× …), banking needs
  the same banks plus a third operand slot.
* **A front end that stalls its downstream** (shared memory ports, long-latency units): the stall tolerance is real and is a property
  of having several units in flight, which also could be bolted onto the baseline.
* Not measured, offered as the likely next steps if frequency matters: register the dispatch outputs (one more cycle of latency),
  split the oldest-first arbitration into two stages, floorplan the 20 k-LUT netlist, give `NUM_CU = 5` (−15 % LUT for −0.1 % IPC).

## 7. Caveats on these numbers

* Yosys cell counts, not Vivado/Quartus reports; the tools also chose different RAM types by default (baseline: block RAM on both
  families; banked 4×: LUT-RAM on 7-series, block RAM on ECP5): set `RAM_STYLE` explicitly in a real flow.
* Utilisation is the design standalone with `PERF_EN = 0`; the counters add ≈ 7 % LUT / 522 FF (`banked_perf`).
* Timing is ECP5 only, 4 lanes, in a registered shell, default nextpnr effort, 3 seeds; no Xilinx or Intel timing exists in this package.
* Throughput comes from RTL simulation of 11 traces and 4 timing profiles on an 8-lane, 8-warp core; the front end is a testbench model
  of `sf_simt_ctrl`, not the real RTL.
* The baseline is the existing SF-G1 structure (plus warps), kept simple on purpose.
