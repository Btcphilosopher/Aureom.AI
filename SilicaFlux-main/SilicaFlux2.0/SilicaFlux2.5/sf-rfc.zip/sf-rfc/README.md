# SilicaFlux banked register file and operand collector

Synthesizable SystemVerilog for the register file and operand-collection stage of the SilicaFlux SIMT GPU core, a
replicated-RAM **baseline** to compare it with, a Python architectural reference model, and the verification, comparison and
synthesis flows that produced every number below. **Nothing in this package has been committed to git.**

## What it is

`sf_rfc` sits between a single-issue SIMT issue stage (`sf_simt_ctrl`) and the execution units. It stores `NUM_WARPS × 32` warp
registers of `LANES × 32` bits in **`NUM_BANKS` one-read/one-write memories**, collects the source operands of each issued
instruction into a private **collector unit**, dispatches complete instructions per execution port, and accepts results
through back-pressured writeback ports.

| required item | where (§ = `docs/ARCHITECTURE.md`) |
|---|---|
| configurable banks (1…32, power of two) | `NUM_BANKS`; `rtl/sf_rfc.sv` |
| documented register→bank mapping (LOW / SKEW / XOR), checked RTL = Python, bijective | `docs/ARCHITECTURE.md` §2, `scripts/check_bankmap.py` |
| per-instruction operand collection | collector units (`NUM_CU`), §7 |
| bank-conflict arbitration (oldest-first / round-robin), losers retry, nothing dropped | §8, §9 |
| writeback arbitration, same-row ordering, completion at acceptance | §4, §8 |
| operand forwarding (staging + landing overlays, per lane) | `rtl/sf_rfc_bank.sv`, §4 |
| execution-mask handling (per-lane write enables, empty-mask elision, zero operands) | §5 |
| back-pressure end to end (`iss_ready` ← units ← `dsp_ready`; `wb_ready`) | §9 |
| same-cycle read/write behaviour | §4: *a read launched in cycle t sees all writes accepted in cycles ≤ t* |
| no mixing of operands between instructions or warps | §7.1 (mechanisms + the mutants that break each) |

## Results in one table (details and caveats: `docs/RESULTS.md`)

Baseline = SF-G1's architecture + the warp dimension (2 replicated register-file copies, 1 write port, 1 in-order operand stage).
Banked default = 4 banks, XOR map, 6 collector units, oldest-first. Same traces, same timing, every run checked against the Python model.

| | baseline | banked default |
|---|---|---|
| **IPC**, always-ready downstream (11 traces / real SIMT streams) | 0.8305 / 0.8840 | **0.8303 / 0.8842** — parity |
| IPC under bursty back-pressure | 0.5802 / 0.6353 | **0.6514 / 0.6868** (+12.3 % / +8.1 %) |
| ALU instructions dispatched while the MEM port is stalled 2 000 cycles | 3 | **627** |
| bank read conflicts (share of read requests denied) | 0 (replication) | 9.9 % (real streams 11.5 %); 12.8 % of instructions had a read denied at least once; mean wait beyond the minimum 0.6 cycle (all causes), p99 2 cycles |
| writeback stalls per register write | 0.086 | **0.016** |
| register-file RAM bits | 131 072 | **65 536** (total storage incl. buffers 133 404 vs 71 736 bits, −46 %) |
| **FPGA logic** (Yosys, 7-series, 8 lanes) | 2 278 LUT, 1 445 FF, 16 RAMB18 | **12 378 LUT + 1 408 LUT-RAM LUTs, 7 063 FF** — 6.1× LUT, 4.9× FF |
| **Fmax** (ECP5 place & route, 4 lanes; **not** Xilinx/Intel) | **≈ 94 MHz** | **≈ 56 MHz** (cu4: 62, no FAST_READ: 60) |

> **Read this before concluding anything.** The banked design matches the baseline's throughput *per cycle* with half the RAM bits
> and is clearly better at tolerating a downstream that is not always ready and at write contention. **But on this FPGA at this
> size it is not smaller or faster**: ≈ 6× the logic and ≈ 0.6× the clock (≈ 46 vs ≈ 78 M instr/s at equal IPC), because a collector's
> cost is its wide operand buffers, crossbars, forwarding registers and dispatch multiplexers, not the register array. It pays off
> where RAM is the scarce resource (ASIC SRAM macros, few block RAMs, many warps × lanes) or where an instruction needs more than two
> source operands (replication would need one copy per source). The first version of this design closed at ≈ 38 MHz; one
> behaviour-preserving change (registered issue-readiness) raised it to ≈ 56 MHz and the remaining path is documented in
> `docs/RESULTS.md` §5–6 together with the levers not yet tried.

## Layout

```
rtl/        sf_rfc.sv (banked RF + collector) · sf_rfc_bank.sv · sf_rfc_ram.sv (only array) · sf_rfc_pkg.sv (mapping, counters)
            sf_rf_base.sv (baseline) · sf_rfc_simt_dec.sv (SIMT instruction decode) · sf_simt_rfc_top.sv (reference integration, lint-only)
tb/         tb_rfc_trace.sv (closed-loop, trace-driven; both DUTs) · tb_rfc_stress.sv (unconstrained + shadow model) · tb_rfc_bank.sv
            tb_decode_xcheck.sv · tb_bankmap.sv · sf_rfc_tb_pkg.sv
python/     rfref/ (ops, model = architectural reference, bankmap, tracegen, simt_trace, run) · analyze_requirements.py · gen_traces.py · tests/
scripts/    run_regress.py · run_stress.py · run_compare.py · run_lanes32.py · mutate_rfc.py · mutate_bank.py · check_bankmap.py · synth.py
synth/      sf_rfc_synth_top.sv (pin-limited shell for place & route)
third_party/silicaflux-simt/   vendored SIMT model/RTL used for traces, decode cross-check and the integration wrapper (PROVENANCE.md)
docs/       REQUIREMENTS · ARCHITECTURE (the specification) · RESULTS · VERIFICATION · FPGA_MEMORY
results/    requirements · compare · regress · mutation_full · synth · lanes32 (all generated by the scripts above)
```

## Reproduce

Tools: Verilator ≥ 5.020 (`pip install verilator`; with a distribution Verilator use `VERILATOR=verilator SFRFC_PCH_FIX=0`), g++,
Python ≥ 3.9 + pytest, and for synthesis `pip install yowasp-yosys yowasp-nextpnr-ecp5`.

```bash
make unit traces regress stress mutate      # ~12 min on 4 cores; results/regress.md, mutation_full.md
make compare                                 # baseline vs banked sweep (~30 min)   -> results/compare.md
make synth                                   # Yosys + nextpnr (~40 min)            -> results/synth.md
```

## What is not done (read before relying on this)

* **`sf_simt_ctrl` was not co-simulated with this module.** The interface is validated against the real RTL by an exhaustive
  decode cross-check and by elaborating `sf_simt_rfc_top.sv` with the unmodified SIMT RTL, and against a testbench model of the
  front end's documented rules; the SIMT contract D2 ("operands sampled at issue") **changes** and the WAR protection that
  replaces it is argued in `ARCHITECTURE.md` §6.
* **No Vivado/Quartus.** Utilisation is Yosys (7-series and ECP5 mappings); the only timing is ECP5 place-and-route from nextpnr.
  FPGA RAM inference is therefore an *assumption* documented in `docs/FPGA_MEMORY.md`, with a checklist for the first vendor run.
* **Simulation only**, one simulator (Verilator, 2-state); no formal proof; liveness is checked by bounds and stall scenarios.
* **The baseline is the existing SF-G1 structure, deliberately simple.** A baseline with a per-port operand register would close
  part of the stall-behaviour gap.
* Single issue, two source operands, power-of-two banks. Not tested beyond 32 lanes / 8 warps at system level.
