#!/usr/bin/env python3
"""Register-access requirements of the SilicaFlux SIMT core, measured from its own programs.

Inputs : the 24 fault-free directed programs + N random legal programs of the vendored SIMT model,
         executed by the lock-step reference (real divergence masks, real register allocation).
Outputs: results/requirements.json and results/requirements.md  (tables quoted by docs/REQUIREMENTS.md)

What is measured and why (each item feeds a design decision):
  * source operands per backend instruction (0/1/2) after eliding r0, unused slots, duplicate registers and
    fully masked instructions  -> number of read ports the average instruction needs
  * writes per instruction                                         -> write-port demand
  * register popularity                                            -> hot registers / bank imbalance
  * static same-bank probability of the two operands of one instruction, for every (NUM_BANKS, BANK_MAP)
    -> how often an instruction cannot read both operands in one bank access
  * producer->consumer distance (instructions, same warp)          -> how often forwarding is on the critical path
  * source-register reuse within the last K instructions of a warp -> potential of read sharing in the collector
"""
import json
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

from rfref import bankmap, simt_trace          # noqa: E402

LANES = 8
NSEED = int(os.environ.get("NSEED", "60"))


def collect():
    streams = []
    for name, per_warp in simt_trace.directed_traces(LANES):
        streams.append((name, per_warp))
    for name, per_warp in simt_trace.random_traces(LANES, range(1, NSEED + 1)):
        streams.append((name, per_warp))
    return streams


def main():
    streams = collect()
    n_ins = n_dir = 0
    reads_hist = Counter()          # effective register reads per instruction
    nominal_hist = Counter()        # reads before eliding r0/dup/mask
    write_cnt = Counter()
    cls_cnt = Counter()
    reg_reads = Counter()
    reg_writes = Counter()
    mask_pop = Counter()
    two_src = []                    # (warp, rs1, rs2) for instructions with two distinct register reads
    raw_dist = Counter()
    reuse_hits = Counter()
    reuse_tot = 0
    elided = Counter()
    K = 4
    for name, per_warp in streams:
        n_dir += 1
        for w, seq in per_warp.items():
            last_wr = {}
            recent = []
            for idx, d in enumerate(seq):
                n_ins += 1
                cls_cnt[d["cls"]] += 1
                nominal = d["use1"] + d["use2"]
                nominal_hist[nominal] += 1
                srcs = []
                if d["use1"] and d["rs1"] != 0:
                    srcs.append(d["rs1"])
                elif d["use1"]:
                    elided["r0 read"] += 1
                if d["use2"] and d["rs2"] != 0:
                    if d["use1"] and d["rs1"] == d["rs2"]:
                        elided["duplicate register"] += 1
                    else:
                        srcs.append(d["rs2"])
                elif d["use2"]:
                    elided["r0 read"] += 1
                if d["mask"] == 0 and srcs:
                    elided["fully masked"] += 1
                    srcs = []
                reads_hist[len(srcs)] += 1
                for r in srcs:
                    reg_reads[r] += 1
                    if r in last_wr:
                        raw_dist[min(idx - last_wr[r], 8)] += 1
                if len(srcs) == 2:
                    two_src.append((w, srcs[0], srcs[1]))
                for r in srcs:
                    reuse_tot += 1
                    if any(r in rr for rr in recent[-K:]):
                        reuse_hits["reused"] += 1
                recent.append(set(srcs))
                if d["wr"] and d["rd"] != 0:
                    write_cnt["write"] += 1
                    reg_writes[d["rd"]] += 1
                    last_wr[d["rd"]] = idx
                else:
                    write_cnt["no write"] += 1
                mask_pop[bin(d["mask"]).count("1")] += 1

    tot_reads = sum(k * v for k, v in reads_hist.items())
    res = dict(programs=n_dir, instructions=n_ins, lanes=LANES,
               reads_per_instr_hist={k: reads_hist[k] for k in sorted(reads_hist)},
               nominal_reads_hist={k: nominal_hist[k] for k in sorted(nominal_hist)},
               mean_reads_per_instr=tot_reads / n_ins, writes_per_instr=write_cnt["write"] / n_ins,
               frac_mem_class=cls_cnt[1] / n_ins, elided=dict(elided),
               frac_zero_mask=mask_pop[0] / n_ins, frac_partial_mask=sum(v for k, v in mask_pop.items() if 0 < k < LANES) / n_ins,
               raw_distance_hist={k: raw_dist[k] for k in sorted(raw_dist)},
               frac_raw_dist_le2=(raw_dist[1] + raw_dist[2]) / max(1, sum(raw_dist.values())),
               source_reuse_within_4=reuse_hits["reused"] / max(1, reuse_tot))
    top = sorted(reg_reads.items(), key=lambda kv: -kv[1])[:8]
    res["hot_read_regs"] = [(f"r{r}", c / tot_reads) for r, c in top]
    res["distinct_regs_read"] = len(reg_reads)

    # static same-bank probability of the two operands of one instruction
    conf = {}
    imbalance = {}
    for nb in (1, 2, 4, 8, 16):
        for bm in (0, 1, 2):
            same = 0
            load = Counter()
            for (w, a, b) in two_src:
                if bankmap.bank_of(bm, nb, w, a) == bankmap.bank_of(bm, nb, w, b):
                    same += 1
            for r, c in reg_reads.items():       # warp-averaged read load per bank (uniform over warps 0..7)
                for w in range(8):
                    load[bankmap.bank_of(bm, nb, w, r)] += c / 8
            conf[f"{nb}/{bankmap.MAP_NAMES[bm]}"] = same / max(1, len(two_src))
            imbalance[f"{nb}/{bankmap.MAP_NAMES[bm]}"] = max(load.values()) / (sum(load.values()) / nb) if nb > 1 else 1.0
    res["two_operand_same_bank_prob"] = conf
    res["bank_load_imbalance_max_over_mean"] = imbalance
    res["two_src_instr_frac"] = len(two_src) / n_ins

    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "results", "requirements.json"), "w"), indent=1)

    L = []
    L.append("# Register-access requirements (measured from the SilicaFlux SIMT programs)\n")
    L.append(f"{n_dir} programs ({sum(1 for _ in simt_trace.directed_traces(LANES))} directed + random legal), "
             f"{n_ins} backend-bound instructions, warp size {LANES}, 8 warps.\n")
    L.append("| quantity | value |\n|---|---|")
    L.append(f"| register reads per instruction (after r0/duplicate/mask elision) | mean {res['mean_reads_per_instr']:.2f}; "
             + ", ".join(f"{k}: {100*v/n_ins:.1f}%" for k, v in sorted(reads_hist.items())) + " |")
    L.append(f"| nominal source operands (ISA view) | " + ", ".join(f"{k}: {100*v/n_ins:.1f}%" for k, v in sorted(nominal_hist.items())) + " |")
    L.append(f"| register writes per instruction | {res['writes_per_instr']:.2f} |")
    L.append(f"| MEM-port instructions | {100*res['frac_mem_class']:.1f}% |")
    L.append(f"| fully masked / partially masked | {100*res['frac_zero_mask']:.1f}% / {100*res['frac_partial_mask']:.1f}% |")
    L.append(f"| read slots elided | " + ", ".join(f"{k}: {v}" for k, v in elided.items()) + " |")
    L.append(f"| instructions with two distinct register reads | {100*res['two_src_instr_frac']:.1f}% |")
    L.append(f"| RAW distance <= 2 instructions (same warp) | {100*res['frac_raw_dist_le2']:.1f}% of dependent reads |")
    L.append(f"| source register already read by one of the previous 4 instructions of the warp | {100*res['source_reuse_within_4']:.1f}% |")
    L.append(f"| hottest read registers | " + ", ".join(f"{r} {100*p:.1f}%" for r, p in res['hot_read_regs'][:6]) + " |")
    L.append("\n## Probability that the two operands of one instruction fall into the same bank\n")
    L.append("| NUM_BANKS | LOW | SKEW | XOR |\n|---|---|---|---|")
    for nb in (1, 2, 4, 8, 16):
        L.append(f"| {nb} | " + " | ".join(f"{100*conf[f'{nb}/{bankmap.MAP_NAMES[bm]}']:.1f}%" for bm in (0, 1, 2)) + " |")
    L.append("\n## Read-load imbalance across banks (busiest bank / mean bank, warp-averaged)\n")
    L.append("| NUM_BANKS | LOW | SKEW | XOR |\n|---|---|---|---|")
    for nb in (2, 4, 8, 16):
        L.append(f"| {nb} | " + " | ".join(f"{imbalance[f'{nb}/{bankmap.MAP_NAMES[bm]}']:.2f}" for bm in (0, 1, 2)) + " |")
    open(os.path.join(ROOT, "results", "requirements.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
