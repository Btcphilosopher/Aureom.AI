"""Unit tests of the Python reference layer (architectural model, mapping, trace generation, ISA decode)."""
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

from rfref import bankmap, model, ops, simt_trace, tracegen   # noqa: E402
from rfref.ops import Insn, CLS_ALU, CLS_MEM, FN_S2R, FN_ALU2, FN_ALU1, FN_BR, FN_LD, FN_ST, FN_DUMP   # noqa: E402

M32 = 0xFFFFFFFF


def ins(**kw):
    d = dict(gid=0, warp=0, cls=CLS_ALU, fn=FN_ALU2, op=0, use1=0, rs1=0, use2=0, rs2=0, wr=0, rd=0, mask=0xF, imm=0)
    d.update(kw)
    return Insn(**d)


# ------------------------------------------------------------------ value functions
def test_f_lane_s2r_hand_value():
    # lane 0, warp 0, imm 0:  (1*K2) ^ (1*K3) = 0x85EBCA6B ^ 0xC2B2AE35
    assert ops.f_lane(FN_S2R, 0, 0, 0, 0, 0, 0) == 0x4759_645E


def test_f_lane_wraps_32bit_and_depends_on_every_input():
    base = ops.f_lane(FN_ALU2, 3, 0xFFFFFFFF, 0x80000000, 0x1234, 2, 5)
    assert 0 <= base <= M32
    for args in [(FN_ALU2, 4, 0xFFFFFFFF, 0x80000000, 0x1234, 2, 5), (FN_ALU2, 3, 0xFFFFFFFE, 0x80000000, 0x1234, 2, 5),
                 (FN_ALU2, 3, 0xFFFFFFFF, 0x80000001, 0x1234, 2, 5), (FN_ALU2, 3, 0xFFFFFFFF, 0x80000000, 0x1235, 2, 5)]:
        assert ops.f_lane(*args) != base            # operand/op/imm sensitivity
    assert ops.f_lane(FN_LD, 0, 5, 0, 7, 1, 2) != ops.f_lane(FN_LD, 0, 5, 0, 7, 1, 3)   # lane sensitivity
    assert ops.f_lane(FN_LD, 0, 5, 0, 7, 1, 2) != ops.f_lane(FN_LD, 0, 5, 0, 7, 2, 2)   # warp sensitivity
    assert ops.f_lane(FN_ST, 0, 5, 5, 5, 0, 0) == 0 and ops.f_lane(FN_DUMP, 0, 5, 5, 5, 0, 0) == 0


# ------------------------------------------------------------------ architectural model
def test_model_reset_state_is_zero_and_r0_reads_zero():
    m = model.ArchModel(4, 2)
    e = m.step(ins(fn=FN_DUMP, use1=1, rs1=7))
    assert e["op1"] == [0, 0, 0, 0]
    e = m.step(ins(fn=FN_DUMP, use1=1, rs1=0))
    assert e["op1"] == [0, 0, 0, 0]


def test_model_write_then_read_and_r0_write_discarded():
    m = model.ArchModel(4, 2)
    m.step(ins(fn=FN_S2R, wr=1, rd=5, mask=0xF, imm=3))
    e = m.step(ins(fn=FN_DUMP, use1=1, rs1=5))
    assert e["op1"] == [ops.f_lane(FN_S2R, 0, 0, 0, 3, 0, l) for l in range(4)]
    m.step(ins(fn=FN_S2R, wr=1, rd=0, mask=0xF, imm=9))                 # write to r0: discarded
    assert m.step(ins(fn=FN_DUMP, use1=1, rs1=0))["op1"] == [0, 0, 0, 0]


def test_model_partial_mask_touches_only_masked_lanes():
    m = model.ArchModel(4, 1)
    m.step(ins(fn=FN_S2R, wr=1, rd=2, mask=0xF, imm=1))
    before = m.step(ins(fn=FN_DUMP, use1=1, rs1=2))["op1"]
    m.step(ins(fn=FN_S2R, wr=1, rd=2, mask=0b0101, imm=77))             # lanes 0 and 2 only
    after = m.step(ins(fn=FN_DUMP, use1=1, rs1=2))["op1"]
    new = [ops.f_lane(FN_S2R, 0, 0, 0, 77, 0, l) for l in range(4)]
    assert after == [new[0], before[1], new[2], before[3]]


def test_model_empty_mask_delivers_zero_operands_and_writes_nothing():
    m = model.ArchModel(4, 1)
    m.step(ins(fn=FN_S2R, wr=1, rd=2, mask=0xF, imm=1))
    e = m.step(ins(fn=FN_ALU2, use1=1, rs1=2, use2=1, rs2=2, wr=1, rd=3, mask=0))
    assert e["op1"] == [0] * 4 and e["op2"] == [0] * 4
    assert m.regs[0][3] == [0] * 4                                       # nothing was written


def test_model_unused_slot_is_zero_even_if_register_field_nonzero():
    m = model.ArchModel(4, 1)
    m.step(ins(fn=FN_S2R, wr=1, rd=6, mask=0xF, imm=1))
    e = m.step(ins(fn=FN_ALU1, use1=1, rs1=6, use2=0, rs2=6, wr=1, rd=1))
    assert e["op2"] == [0] * 4 and e["op1"] != [0] * 4


def test_model_duplicate_source_register_gives_equal_operands():
    m = model.ArchModel(4, 1)
    m.step(ins(fn=FN_S2R, wr=1, rd=4, mask=0xF, imm=5))
    e = m.step(ins(fn=FN_ALU2, use1=1, rs1=4, use2=1, rs2=4, wr=1, rd=4))
    assert e["op1"] == e["op2"]


def test_model_warps_are_independent():
    m = model.ArchModel(2, 2)
    m.step(ins(warp=0, fn=FN_S2R, wr=1, rd=1, mask=3, imm=1))
    assert m.step(ins(warp=1, fn=FN_DUMP, use1=1, rs1=1))["op1"] == [0, 0]


def test_model_branch_taken_masked():
    m = model.ArchModel(4, 1)
    m.step(ins(fn=FN_S2R, wr=1, rd=1, mask=0xF, imm=2))
    e = m.step(ins(fn=FN_BR, use1=1, rs1=1, mask=0b0110, imm=0xFFFF))
    assert e["taken"] & ~0b0110 == 0 and not e["we"]


# ------------------------------------------------------------------ mapping
def test_bank_mapping_bijective_and_documented_examples():
    for nb in (1, 2, 4, 8, 16, 32):
        for bm in (0, 1, 2):
            assert bankmap.check_bijection(bm, nb, 8) and bankmap.check_bijection(bm, nb, 5)
    # documented examples (docs/ARCHITECTURE.md s.2): 4 banks
    assert bankmap.bank_of(0, 4, 3, 6) == 2 and bankmap.row_of(4, 3, 6) == 3 * 8 + 1          # LOW : reg mod 4
    assert bankmap.bank_of(1, 4, 3, 6) == (2 + 3) % 4                                           # SKEW: + warp
    assert bankmap.bank_of(2, 4, 0, 4) == 1 and bankmap.bank_of(2, 4, 0, 8) == 2               # XOR : hi bits fold in


def test_xor_map_spreads_stride_that_defeats_low_and_skew():
    regs = [8, 16, 24]
    for bm, expect_spread in ((0, False), (1, False), (2, True)):
        banks = {bankmap.bank_of(bm, 4, 0, r) for r in regs}
        assert (len(banks) > 1) == expect_spread


# ------------------------------------------------------------------ traces
def test_trace_files_roundtrip_and_layout(tmp_path):
    pw = tracegen.gen_uniform(3, 30, 4, seed=5, mmode="mixed")
    insns = tracegen.build("t", pw, 4, 3, str(tmp_path))
    lines = open(tmp_path / "t.trace").read().splitlines()
    assert lines[0].split() == ["4", "3", str(len(insns))]
    assert sum(map(int, lines[1].split())) == len(insns)
    parsed = [Insn.parse(l) for l in lines[2:]]
    assert parsed == insns
    assert [i.gid for i in insns] == list(range(len(insns)))               # warp-major, contiguous
    warps = [i.warp for i in insns]
    assert warps == sorted(warps)
    exp = open(tmp_path / "t.exp").read().splitlines()
    assert len(exp) == len(insns) and all(len(e.split()[1]) == 4 * 8 for e in exp)
    # every warp ends with the 32-instruction register dump r0..r31
    for w in range(3):
        d = [i for i in insns if i.warp == w][-32:]
        assert [i.rs1 for i in d] == list(range(32)) and all(i.fn == FN_DUMP for i in d)


def test_dump_expectation_equals_final_architectural_state(tmp_path):
    pw = tracegen.gen_loopy(2, 60, 4, seed=3, mmode="mixed")
    insns = tracegen.finalize(pw, 4, 2)
    exp, m = model.run_trace(insns, 4, 2)
    for i in insns:
        if i.fn == FN_DUMP:
            assert exp[i.gid]["op1"] == (m.regs[i.warp][i.rs1] if i.rs1 else [0] * 4)


# ------------------------------------------------------------------ ISA decode (cross-checked in RTL by tb_decode_xcheck)
def test_decode_backend_operand_table():
    sfisa, _, _ = simt_trace._import_simt()
    cases = {
        "add r3, r1, r2": (CLS_ALU, FN_ALU2, 1, 1, 1), "addi r3, r1, 5": (CLS_ALU, FN_ALU1, 1, 0, 1),
        "s2r r3, lane": (CLS_ALU, FN_S2R, 0, 0, 1), "bnz r4, 0": (CLS_ALU, FN_BR, 1, 0, 0),
        "ldg r3, [r4 + 2]": (CLS_MEM, FN_LD, 1, 0, 1), "stg r5, [r4 + 2]": (CLS_MEM, FN_ST, 1, 1, 0),
    }
    for text, (cls, fn, u1, u2, wr) in cases.items():
        w = sfisa.assemble(text + "\n")[0][0]
        d = simt_trace.decode_backend(w)
        assert (d["cls"], d["fn"], d["use1"], d["use2"], d["wr"]) == (cls, fn, u1, u2, wr), text
    w = sfisa.assemble("stg r5, [r4 + 2]\n")[0][0]
    d = simt_trace.decode_backend(w)
    assert d["rs1"] == 4 and d["rs2"] == 5                                   # address in rs1, data in rs2
    for local in ("nop", "exit", "sync", "bar"):
        assert simt_trace.decode_backend(sfisa.assemble(local + "\n")[0][0]) is None


def test_real_simt_traces_are_available_and_carry_partial_masks():
    seen_partial = False
    n = 0
    for name, per_warp in simt_trace.directed_traces(8):
        for seq in per_warp.values():
            for d in seq:
                n += 1
                seen_partial |= (0 < d["mask"] < 0xFF)
    assert n > 500 and seen_partial
