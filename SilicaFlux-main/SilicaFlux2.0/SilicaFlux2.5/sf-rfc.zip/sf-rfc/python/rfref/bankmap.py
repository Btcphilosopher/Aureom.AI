"""Register -> bank/row mapping: the normative reference for rtl/sf_rfc_pkg.sv (f_bank / f_row).

A *warp register* is the pair (warp, reg): one row of LANES x 32 bits.  NUM_BANKS is a power of two
(BW = log2(NUM_BANKS)).  Each bank is a one-read/one-write memory of ROWS = NUM_WARPS * (32 >> BW) rows.

    row  = warp * (32 >> BW) + (reg >> BW)            (identical for every map)
    bank depends on the map (BANK_MAP):
        0  LOW   : reg[BW-1:0]
        1  SKEW  : (reg[BW-1:0] + warp) mod NUM_BANKS
        2  XOR   : reg[BW-1:0] ^ H,   H = (hi ^ (hi >> BW) ^ warp) mod NUM_BANKS,  hi = reg >> BW

For every map the bank is a bijection of reg[BW-1:0] once (warp, reg >> BW) -- i.e. the row -- is fixed, so
(bank, row) <-> (warp, reg) is one-to-one and no two warp registers share storage.
"""

REGS = 32


def bw_of(nb: int) -> int:
    assert nb >= 1 and nb & (nb - 1) == 0 and nb <= REGS, "NUM_BANKS must be a power of two <= 32"
    return nb.bit_length() - 1


def bank_of(bmap: int, nb: int, warp: int, reg: int) -> int:
    bw = bw_of(nb)
    m = nb - 1
    lo = reg & m
    hi = reg >> bw
    w5 = warp & 31
    if bmap == 0:
        return lo
    if bmap == 1:
        return (lo + w5) & m
    if bmap == 2:
        h = hi ^ (hi >> bw) ^ w5
        return (lo ^ h) & m
    raise ValueError(bmap)


def row_of(nb: int, warp: int, reg: int) -> int:
    bw = bw_of(nb)
    return warp * (REGS >> bw) + (reg >> bw)


def rows_per_bank(nb: int, nwarps: int) -> int:
    return nwarps * (REGS >> bw_of(nb))


def check_bijection(bmap: int, nb: int, nwarps: int) -> bool:
    """(warp, reg) -> (bank, row) must be injective and land inside the arrays."""
    seen = set()
    rows = rows_per_bank(nb, nwarps)
    for w in range(nwarps):
        for r in range(REGS):
            k = (bank_of(bmap, nb, w, r), row_of(nb, w, r))
            if k in seen or not (0 <= k[0] < nb and 0 <= k[1] < rows):
                return False
            seen.add(k)
    return len(seen) == nwarps * REGS


MAP_NAMES = {0: "LOW", 1: "SKEW", 2: "XOR"}
