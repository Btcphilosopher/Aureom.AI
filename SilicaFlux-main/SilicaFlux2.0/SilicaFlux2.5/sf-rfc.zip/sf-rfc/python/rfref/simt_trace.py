"""Extract backend-bound instruction streams (with real divergence masks) from SilicaFlux SIMT programs.

Source: third_party/silicaflux-simt (vendored model/sfisa.py, sfref.py, sfgen.py and the directed programs).
`run_simt` yields, per warp, the list of (pc, active_mask) of every instruction the scheduler issued.
Instructions that never leave the control unit (nop/exit/ssy/sync/bar/jmp) do not touch the register
file and are dropped; the remaining ones are decoded into the operand-use record the collector needs:

    R-ops       add sub mul and or xor shl shr sar slt sltu : reads rs1, rs2   writes rd   (ALU port)
    addi/mov    reads rs1                                   writes rd                       (ALU port)
    lui, s2r    reads nothing                               writes rd                       (ALU port)
    bnz, bz     reads rs1                                   writes nothing (taken mask)     (ALU port)
    ldg, lds    reads rs1                                   writes rd (returns later)       (MEM port)
    stg, sts    reads rs1 (address) and rs2 (data)          writes nothing                  (MEM port)

(See docs/REQUIREMENTS.md for how this table was derived from sfisa.py / ARCHITECTURE.md section 3.)
"""
import glob
import os
import sys
from typing import Dict, List, Tuple

from .ops import (Insn, CLS_ALU, CLS_MEM, FN_S2R, FN_ALU2, FN_ALU1, FN_BR, FN_LD, FN_ST)

HERE = os.path.dirname(os.path.abspath(__file__))
VENDOR = os.path.abspath(os.path.join(HERE, "..", "..", "third_party", "silicaflux-simt"))


def _import_simt():
    p = os.path.join(VENDOR, "model")
    if p not in sys.path:
        sys.path.insert(0, p)
    import sfisa, sfref, sfgen   # noqa: E402
    return sfisa, sfref, sfgen


def decode_backend(word: int):
    """Return None for control-unit-local instructions, else a dict of operand-use fields."""
    sfisa, _, _ = _import_simt()
    op = (word >> 27) & 31
    name = sfisa.OPNAME.get(op)
    rd, rs1, rs2 = (word >> 22) & 31, (word >> 17) & 31, (word >> 12) & 31
    imm = word & 0xFFFFF
    if name is None:
        return None
    if name in sfisa.R_OPS:
        return dict(cls=CLS_ALU, fn=FN_ALU2, op=sorted(sfisa.R_OPS).index(name) & 15,
                    use1=1, rs1=rs1, use2=1, rs2=rs2, wr=1, rd=rd, imm=imm)
    if name == "addi":
        return dict(cls=CLS_ALU, fn=FN_ALU1, op=0, use1=1, rs1=rs1, use2=0, rs2=0, wr=1, rd=rd, imm=imm)
    if name in ("lui", "s2r"):
        return dict(cls=CLS_ALU, fn=FN_S2R, op=0, use1=0, rs1=0, use2=0, rs2=0, wr=1, rd=rd, imm=imm)
    if name in ("bnz", "bz"):
        return dict(cls=CLS_ALU, fn=FN_BR, op=0, use1=1, rs1=rs1, use2=0, rs2=0, wr=0, rd=0, imm=imm)
    if name in sfisa.LOADS:
        return dict(cls=CLS_MEM, fn=FN_LD, op=0, use1=1, rs1=rs1, use2=0, rs2=0, wr=1, rd=rd, imm=imm)
    if name in sfisa.STORES:
        return dict(cls=CLS_MEM, fn=FN_ST, op=0, use1=1, rs1=rs1, use2=1, rs2=rs2, wr=0, rd=0, imm=imm)
    return None   # nop exit ssy sync bar jmp


def from_program(words: List[int], cfg) -> Dict[int, List[dict]]:
    """Run the lock-step SIMT model and return {warp: [insn field dicts incl. mask]} (program order)."""
    _, sfref, _ = _import_simt()
    st = sfref.run_simt(words, cfg)
    if st.reject or st.kernel_fault:
        raise ValueError("program faults / rejected under this config")
    out = {}
    for w, tr in st.trace.items():
        seq = []
        for pc, mask in tr:
            d = decode_backend(words[pc])
            if d is None:
                continue
            d = dict(d)
            d["mask"] = mask
            seq.append(d)
        out[w] = seq
    return out


def directed_traces(lanes: int, num_warps: int = 8):
    """Yield (name, per-warp dict) for every fault-free directed program, 2 workgroups x 2 warps."""
    sfisa, sfref, _ = _import_simt()
    for f in sorted(glob.glob(os.path.join(VENDOR, "programs", "*.s"))):
        words, _, _ = sfisa.assemble(open(f).read())
        cfg = sfref.Cfg(num_warps=num_warps, warp_size=lanes, stack_depth=8, num_wg=2, wpw=2)
        try:
            yield os.path.basename(f)[:-2], from_program(words, cfg)
        except ValueError:
            continue


def random_traces(lanes: int, seeds, num_warps: int = 8):
    """Random legal structured programs (sfgen), launch shapes as in the SIMT regression."""
    import random
    sfisa, sfref, sfgen = _import_simt()
    for seed in seeds:
        rng = random.Random(seed)
        text = sfgen.Gen(seed, max_depth=3, warp_size=lanes).generate()
        words, _, _ = sfisa.assemble(text)
        nwg, wpw, tl = sfgen.random_cfg(rng, num_warps, lanes)
        cfg = sfref.Cfg(num_warps=num_warps, warp_size=lanes, stack_depth=8, num_wg=nwg, wpw=wpw, tlast=tl)
        try:
            yield f"rand{seed}", from_program(words, cfg)
        except (ValueError, sfref.RefError):
            continue
