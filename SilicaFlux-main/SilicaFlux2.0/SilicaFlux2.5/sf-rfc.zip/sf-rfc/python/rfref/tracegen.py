"""Synthetic instruction-trace generators + trace/expected-file writers.

Every generator returns {warp: [field dicts]} (program order per warp); `finalize()` turns that into
globally numbered `Insn`s (gid is warp-major and contiguous per warp), appends a *register dump* to every
warp (32 DUMP instructions that read r0..r31 through the normal operand path -- this is how the final
architectural state of the RTL is compared with the Python model, with no extra read port), and
`write_trace` / `write_expected` produce the files the testbenches read.
"""
import random
from typing import Dict, List

from . import bankmap
from .model import run_trace, pack
from .ops import (Insn, CLS_ALU, CLS_MEM, FN_S2R, FN_ALU2, FN_ALU1, FN_BR, FN_LD, FN_ST, FN_DUMP)


# --------------------------------------------------------------------------- masks
def make_mask(rng: random.Random, lanes: int, mode: str) -> int:
    full = (1 << lanes) - 1
    if mode == "full":
        return full
    if mode == "rand":
        return rng.getrandbits(lanes)
    if mode == "mixed":                       # divergence-like mixture incl. empty and single-lane masks
        x = rng.random()
        if x < 0.55:
            return full
        if x < 0.70:
            return (full >> (lanes // 2)) << (lanes // 2) if lanes > 1 else full   # upper half
        if x < 0.80:
            return (1 << (lanes // 2)) - 1 if lanes > 1 else full                 # lower half
        if x < 0.88:
            return 1 << rng.randrange(lanes)                                       # single lane
        if x < 0.93:
            return 0                                                               # fully masked
        return rng.getrandbits(lanes)
    raise ValueError(mode)


def _d(rng, lanes, mmode, **kw):
    d = dict(op=rng.randrange(16), use1=0, rs1=0, use2=0, rs2=0, wr=0, rd=0,
             imm=rng.getrandbits(20), mask=make_mask(rng, lanes, mmode))
    d.update(kw)
    return d


# --------------------------------------------------------------------------- generators
def gen_uniform(nwarps, n, lanes, seed, mmode="mixed", regs=range(1, 32), r0_prob=0.04):
    """Uniform random registers.  The mix mimics the SIMT ISA: ~45% R-ops, ~15% addi, ~5% s2r, 12% ld, 10% st, 8% br."""
    rng = random.Random(seed)
    out = {}
    regs = list(regs)

    def pick():
        return 0 if rng.random() < r0_prob else rng.choice(regs)
    for w in range(nwarps):
        seq = []
        for r in range(1, 13):                       # initialise some registers with lane-varying data
            seq.append(_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=r))
        for _ in range(n):
            x = rng.random()
            if x < 0.45:
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=pick(), use2=1, rs2=pick(), wr=1,
                              rd=0 if rng.random() < 0.04 else rng.choice(regs)))     # some results target r0: must be discarded
            elif x < 0.60:
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU1, use1=1, rs1=pick(), wr=1, rd=rng.choice(regs)))
            elif x < 0.65:
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_S2R, wr=1, rd=rng.choice(regs)))
            elif x < 0.77:
                seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_LD, use1=1, rs1=pick(), wr=1, rd=rng.choice(regs)))
            elif x < 0.87:
                seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_ST, use1=1, rs1=pick(), use2=1, rs2=pick()))
            else:
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_BR, use1=1, rs1=pick()))
        out[w] = seq
    return out


def gen_loopy(nwarps, n, lanes, seed, mmode="full"):
    """Compiler-like unrolled loop bodies: loads feed a short arithmetic chain, results are stored, registers
    come from a sliding window so values are reused soon after being produced (RAW distance 1-4)."""
    rng = random.Random(seed)
    out = {}
    for w in range(nwarps):
        seq = []
        base = 1 + rng.randrange(0, 8)
        for r in range(1, 9):
            seq.append(_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=r))
        while len(seq) < n:
            win = [(base + k) % 31 + 1 for k in range(12)]
            a, b, c, d, e = rng.sample(win, 5)
            seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_LD, use1=1, rs1=a, wr=1, rd=b))
            seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_LD, use1=1, rs1=a, wr=1, rd=c))
            seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=b, use2=1, rs2=c, wr=1, rd=d))
            seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=d, use2=1, rs2=b, wr=1, rd=e))
            seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU1, use1=1, rs1=e, wr=1, rd=e))
            seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_ST, use1=1, rs1=a, use2=1, rs2=e))
            if rng.random() < 0.3:
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_BR, use1=1, rs1=e))
            base = (base + 1) % 31
        out[w] = seq[:n]
    return out


def gen_hammer(nwarps, n, lanes, seed, stride=8, mmode="full"):
    """Adversarial: every operand register is a multiple of `stride` => under the LOW map every access of
    every warp targets bank 0 (for NUM_BANKS <= stride)."""
    rng = random.Random(seed)
    regs = [r for r in range(stride, 32, stride)] or [stride % 32 or 8]
    out = {}
    for w in range(nwarps):
        seq = []
        for r in regs:
            seq.append(_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=r))
        for _ in range(n):
            a, b, d = rng.choice(regs), rng.choice(regs), rng.choice(regs)
            seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=a, use2=1, rs2=b, wr=1, rd=d))
        out[w] = seq
    return out


def gen_depchain(nwarps, n, lanes, seed, mmode="full"):
    """Serial dependency chain: every instruction consumes the previous result (r1 = f(r1, r2))."""
    rng = random.Random(seed)
    out = {}
    for w in range(nwarps):
        seq = [_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=1),
               _d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=2)]
        for _ in range(n):
            seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=1, use2=1, rs2=2, wr=1, rd=1))
        out[w] = seq
    return out


def gen_ldburst(nwarps, n, lanes, seed, mmode="full"):
    """Bursts of independent loads followed by consumers: many long-latency results land together while
    ALU results are also retiring -> exercises writeback arbitration."""
    rng = random.Random(seed)
    out = {}
    for w in range(nwarps):
        seq = [_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=1)]
        while len(seq) < n:
            regs = rng.sample(range(2, 30), 6)
            for r in regs:
                seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_LD, use1=1, rs1=1, wr=1, rd=r))
            for i in range(0, 6, 2):
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=regs[i], use2=1, rs2=regs[i + 1],
                              wr=1, rd=rng.choice(regs)))
        out[w] = seq[:n]
    return out


def gen_war_probe(nwarps, n, lanes, seed, nb=4, bmap=1, mmode="full"):
    """Targeted write-after-read probe.  Warps 1..N-1 saturate bank 0 with two-source instructions whose operands
    all live in bank 0.  Warp 0 repeats   X: rd=cold <- hot_a, hot_b        (its reads queue behind the hammer)
                                          Y: hot_a   <- cold2               (writes the register X still has to read)
                                          Z: rd2     <- hot_a, cold2        (RAW on Y)
    X's read is starved for several cycles on the hot bank while Y (reading a free bank) can collect, dispatch and
    write back.  A collector that lets Y overtake X hands X the NEW value of hot_a -> operand mismatch."""
    rng = random.Random(seed)

    def regs(w, hot):
        return [r for r in range(1, 32) if (bankmap.bank_of(bmap, nb, w, r) == 0) == hot]
    out = {}
    for w in range(nwarps):
        hot, cold = regs(w, True), regs(w, False)
        seq = [_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=r) for r in (hot[:6] + cold[:6])]
        for _ in range(n):
            if w == 0:
                a, b = rng.sample(hot[:6], 2)
                c1, c2, c3 = rng.sample(cold[:6], 3)
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=a, use2=1, rs2=b, wr=1, rd=c1))
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU1, use1=1, rs1=c2, wr=1, rd=a))
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=a, use2=1, rs2=c2, wr=1, rd=c3))
            else:
                a, b = rng.sample(hot[:6], 2)
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=a, use2=1, rs2=b, wr=1,
                              rd=rng.choice(cold[:6])))
        out[w] = seq
    return out


def gen_memstall(nwarps, n, lanes, seed, mmode="full"):
    """Liveness probe for prolonged downstream stalls: warps 0..N/2-1 are memory-heavy (loads feeding ALU work),
    the others are pure ALU.  Run with the MEM port stalled for a long window: the ALU-only warps must keep
    retiring work (no resource may be monopolised by the stalled class)."""
    rng = random.Random(seed)
    out = {}
    half = max(1, nwarps // 2)
    for w in range(nwarps):
        seq = [_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=r) for r in range(1, 9)]
        for i in range(n):
            if w < half:
                r = rng.sample(range(9, 28), 3)
                seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_LD, use1=1, rs1=rng.randrange(1, 9), wr=1, rd=r[0]))
                seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_LD, use1=1, rs1=rng.randrange(1, 9), wr=1, rd=r[1]))
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=r[0], use2=1, rs2=r[1], wr=1, rd=r[2]))
            else:
                a, b, d = rng.sample(range(1, 28), 3)
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=a, use2=1, rs2=b, wr=1, rd=d))
        out[w] = seq
    return out


def gen_memflood(nwarps, n, lanes, seed, mmode="full"):
    """Pool-flooding liveness probe: memory warps issue four INDEPENDENT loads in a row (no consumer in between), so with the
    MEM port stalled they can keep up to NUM_SLOTS=4 loads each in flight -- far more than any collector pool.  ALU-only warps
    must nevertheless keep flowing (the class cap)."""
    rng = random.Random(seed)
    out = {}
    half = max(1, nwarps // 2)
    for w in range(nwarps):
        seq = [_d(rng, lanes, "full", cls=CLS_ALU, fn=FN_S2R, wr=1, rd=r) for r in range(1, 9)]
        for i in range(n):
            if w < half:
                regs = rng.sample(range(9, 28), 5)
                for r in regs[:4]:
                    seq.append(_d(rng, lanes, mmode, cls=CLS_MEM, fn=FN_LD, use1=1, rs1=rng.randrange(1, 9), wr=1, rd=r))
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=regs[0], use2=1, rs2=regs[1], wr=1, rd=regs[4]))
            else:
                a, b, d = rng.sample(range(1, 28), 3)
                seq.append(_d(rng, lanes, mmode, cls=CLS_ALU, fn=FN_ALU2, use1=1, rs1=a, use2=1, rs2=b, wr=1, rd=d))
        out[w] = seq
    return out


# --------------------------------------------------------------------------- assembly of a trace
def finalize(per_warp: Dict[int, List[dict]], lanes: int, nwarps: int, dump: bool = True) -> List[Insn]:
    full = (1 << lanes) - 1
    insns, gid = [], 0
    for w in range(nwarps):
        seq = list(per_warp.get(w, []))
        if dump:
            for r in range(32):
                seq.append(dict(cls=CLS_ALU, fn=FN_DUMP, op=0, use1=1, rs1=r, use2=0, rs2=0, wr=0, rd=0,
                                imm=0, mask=full))
        for d in seq:
            insns.append(Insn(gid=gid, warp=w, cls=d["cls"], fn=d["fn"], op=d["op"], use1=d["use1"], rs1=d["rs1"],
                              use2=d["use2"], rs2=d["rs2"], wr=d["wr"], rd=d["rd"], mask=d["mask"] & full,
                              imm=d["imm"]))
            gid += 1
    return insns


def write_trace(path: str, insns: List[Insn], lanes: int, nwarps: int):
    cnt = [0] * nwarps
    for i in insns:
        cnt[i.warp] += 1
    with open(path, "w") as f:
        f.write(f"{lanes} {nwarps} {len(insns)}\n")
        f.write(" ".join(map(str, cnt)) + "\n")
        for i in insns:
            f.write(i.line() + "\n")


def write_expected(path: str, insns: List[Insn], lanes: int, nwarps: int):
    exp, _ = run_trace(insns, lanes, nwarps)
    with open(path, "w") as f:
        for i in insns:
            e = exp[i.gid]
            f.write(f"{i.gid} {pack(e['op1'])} {pack(e['op2'])} {pack(e['res'])} {e['taken']:x}\n")
    return exp


def build(name: str, per_warp, lanes: int, nwarps: int, outdir: str):
    """Write <outdir>/<name>.trace and <name>.exp; return the Insn list."""
    import os
    os.makedirs(outdir, exist_ok=True)
    insns = finalize(per_warp, lanes, nwarps)
    write_trace(os.path.join(outdir, name + ".trace"), insns, lanes, nwarps)
    write_expected(os.path.join(outdir, name + ".exp"), insns, lanes, nwarps)
    return insns
