"""Python architectural register model -- the reference for all RTL checking.

Semantics (program order per warp, no timing):
  * state: regs[warp][reg] = list of LANES 32-bit values, all zero at reset / clear; r0 reads zero, writes dropped
  * an instruction needs its source operand rows; the *operand* the register file must deliver is
        row(warp, reg)            if the slot is used, reg != 0 and mask != 0
        all-zero                  otherwise                (r0, unused slot, fully masked instruction)
    -- this is the documented operand contract of the collector, see docs/ARCHITECTURE.md section 5.
  * result lanes come from ops.f_lane() evaluated on the delivered operands of ALL lanes
  * the register write updates ONLY lanes with mask bit set, only if wr and rd != 0; other lanes keep their value
Warps do not interact, so any interleaving of warps yields the same per-warp result: the expected
operand/result stream of an instruction is independent of timing.  That is what lets the closed-loop
RTL testbench check every dispatched operand against this model regardless of scheduling.
"""
from typing import List, Dict

from .ops import Insn, f_lane, taken_bit, FN_BR, FN_LD, FN_S2R, FN_ALU1, FN_ALU2, M32

HAS_RESULT = {FN_S2R, FN_ALU1, FN_ALU2, FN_LD}


class ArchModel:
    def __init__(self, lanes: int, nwarps: int):
        self.lanes = lanes
        self.nwarps = nwarps
        self.regs = [[[0] * lanes for _ in range(32)] for _ in range(nwarps)]

    def clear(self):
        for w in range(self.nwarps):
            for r in range(32):
                self.regs[w][r] = [0] * self.lanes

    def operand(self, ins: Insn, slot: int) -> List[int]:
        use, rs = (ins.use1, ins.rs1) if slot == 0 else (ins.use2, ins.rs2)
        if use and rs != 0 and ins.mask != 0:
            return list(self.regs[ins.warp][rs])
        return [0] * self.lanes

    def step(self, ins: Insn) -> Dict:
        a = self.operand(ins, 0)
        b = self.operand(ins, 1)
        res = [f_lane(ins.fn, ins.op, a[l], b[l], ins.imm, ins.warp, l) for l in range(self.lanes)]
        taken = 0
        if ins.fn == FN_BR:
            for l in range(self.lanes):
                taken |= taken_bit(a[l], ins.imm, l) << l
            taken &= ins.mask
        we = bool(ins.wr and ins.rd != 0 and ins.fn in HAS_RESULT)
        if we:
            row = self.regs[ins.warp][ins.rd]
            for l in range(self.lanes):
                if (ins.mask >> l) & 1:
                    row[l] = res[l]
        return dict(op1=a, op2=b, res=res if ins.fn in HAS_RESULT else [0] * self.lanes,
                    taken=taken, we=we)


def pack(vals: List[int]) -> str:
    """lane 0 in the least-significant 32 bits -> hex string of LANES*8 digits (what $fscanf %h reads)."""
    return "".join(f"{v & M32:08x}" for v in reversed(vals))


def run_trace(insns: List[Insn], lanes: int, nwarps: int):
    """Execute per-warp in program order; return per-gid expected records and the final model."""
    m = ArchModel(lanes, nwarps)
    out = {}
    by_warp = {}
    for i in insns:
        by_warp.setdefault(i.warp, []).append(i)
    for w in sorted(by_warp):
        for i in by_warp[w]:
            out[i.gid] = m.step(i)
    return out, m
