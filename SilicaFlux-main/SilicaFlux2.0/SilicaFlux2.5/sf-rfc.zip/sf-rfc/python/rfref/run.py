"""Build (Verilator) and run the RTL testbenches; parse their RESULT lines."""
import hashlib
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
RTL = ["rtl/sf_rfc_pkg.sv", "rtl/sf_rfc_ram.sv", "rtl/sf_rfc_bank.sv", "rtl/sf_rfc.sv", "rtl/sf_rf_base.sv"]
TBPKG = ["tb/sf_rfc_tb_pkg.sv"]

VERILATOR = os.environ.get("VERILATOR", "verilator-cli")
# The `pip install verilator` wheel ships verilated.mk with an empty precompiled-header include flag, which breaks the
# C++ build of any design large enough to trigger PCH.  With GCC the correct flag is -include.  A distribution Verilator
# does not need this: set SFRFC_PCH_FIX=0.
PCH_FIX = os.environ.get("SFRFC_PCH_FIX", "1") != "0"
WORK = os.environ.get("SFRFC_WORK", os.path.join(ROOT, "work", "build"))


def _rtl_hash(extra_files):
    h = hashlib.sha1()
    for f in RTL + TBPKG + extra_files:
        h.update(open(os.path.join(ROOT, f), "rb").read())
    return h.hexdigest()[:8]


def build(top: str, tbfile: str, params: dict, extra_files=(), defines=(), rtl=None, tag=None, quiet=True):
    """Compile `top` with -G parameters; cached on (sources, params). Returns the executable path."""
    files = list(rtl if rtl is not None else RTL) + TBPKG + [tbfile] + list(extra_files)
    h = hashlib.sha1()
    for f in files:
        h.update(open(os.path.join(ROOT, f), "rb").read())
    h.update(repr(sorted(params.items())).encode() + repr(sorted(defines)).encode() + top.encode())
    name = (tag or top) + "_" + h.hexdigest()[:10]
    d = os.path.join(WORK, name)
    exe = os.path.join(d, "obj", "V" + top)
    if os.path.exists(exe):
        return exe
    os.makedirs(d, exist_ok=True)
    cmd = [VERILATOR, "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-PROCASSINIT",
           "--x-initial", "unique", "--x-assign", "unique", "--top-module", top, "-Mdir", os.path.join(d, "obj")]
    if PCH_FIX:
        cmd += ["-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include"]
    cmd += [f"-G{k}={v}" for k, v in params.items()]
    cmd += [f"-D{x}" for x in defines]
    cmd += [os.path.join(ROOT, f) for f in files]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=d)
    open(os.path.join(d, "build.log"), "w").write(r.stdout + r.stderr)
    if r.returncode != 0:
        errs = [l for l in (r.stdout + r.stderr).splitlines() if "%Error" in l or "error:" in l.lower()]
        raise RuntimeError(f"build of {name} failed:\n" + "\n".join(errs[:15]))
    return exe


def run(exe: str, plusargs: dict, seed: int = 1, timeout: int = 900):
    cmd = [exe, "+verilator+rand+reset+2", f"+verilator+seed+{seed}"]
    for k, v in plusargs.items():
        cmd.append(f"+{k}={v}")
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    out = r.stdout + r.stderr
    res = parse(out)
    res["_ok"] = ("PASS" in out.splitlines()) and res.get("status") == "OK" and r.returncode == 0
    res["_log"] = out
    return res


def parse(out: str) -> dict:
    d = {}
    for line in out.splitlines():
        if line.startswith("RESULT"):
            for tok in line.split()[1:]:
                if "=" in tok:
                    k, v = tok.split("=", 1)
                    try:
                        d[k] = int(v)
                    except ValueError:
                        try:
                            d[k] = float(v)
                        except ValueError:
                            d[k] = v
    return d
