"""Instruction record and lane-value semantics shared by the Python reference and the RTL testbenches.

The register file / operand collector is data-path agnostic: it only moves operand rows.  To
verify that it moves the *right* rows, every instruction in a trace computes a deterministic,
operand-sensitive 32-bit function of its source operands.  A wrong operand (wrong register, wrong
warp, wrong instruction, stale value, wrong lane) therefore corrupts the result, and the corruption
propagates through dependent instructions into the final register state.

These formulas are mirrored *exactly* in tb/sf_rfc_tb_pkg.sv (function `f_lane`).  Any change here
must be made there too; the closed-loop testbench fails on the very first instruction otherwise.
"""
from dataclasses import dataclass

M32 = 0xFFFFFFFF

# Functional classes (what the instruction does with its operands).
FN_S2R, FN_ALU2, FN_ALU1, FN_BR, FN_LD, FN_ST, FN_DUMP = range(7)
FN_NAMES = ["S2R", "ALU2", "ALU1", "BR", "LD", "ST", "DUMP"]

# Dispatch classes = backend ports of the SIMT core (sf_simt_ctrl: 0 = ALU port, 1 = MEM port).
CLS_ALU, CLS_MEM = 0, 1

K1, K2, K3, K4, K5 = 0x9E3779B1, 0x85EBCA6B, 0xC2B2AE35, 0x27D4EB2F, 0x165667B1


def f_lane(fn: int, op: int, a: int, b: int, imm: int, warp: int, lane: int) -> int:
    """Result of one lane.  Returns 0 for functions that produce no register result."""
    if fn == FN_S2R:
        return ((((lane + 1) * K2) & M32) ^ (((warp + 1) * K3) & M32) ^ imm) & M32
    if fn == FN_ALU2:
        t = (a * K1) & M32
        t = (t + (((b ^ imm) * K4) & M32)) & M32
        t = t ^ (a >> 7) ^ ((b << 5) & M32)
        return (t + ((op * K5) & M32)) & M32
    if fn == FN_ALU1:
        t = ((a * K1) & M32) ^ imm
        t = (t + (a >> 11)) & M32
        return (t + ((op * K5) & M32)) & M32
    if fn == FN_LD:
        return ((((a + imm) & M32) * K4) & M32 ^ (((lane + 1) * K2) & M32) ^ ((warp * K3) & M32)) & M32
    return 0


def taken_bit(a: int, imm: int, lane: int) -> int:
    """Branch outcome of one lane (BR returns a per-lane taken mask on the completion sideband)."""
    return (((a ^ imm) >> (lane & 31)) & 1)


@dataclass
class Insn:
    gid: int          # global id, warp-major, contiguous per warp
    warp: int
    cls: int          # CLS_ALU / CLS_MEM  (dispatch port)
    fn: int           # FN_*
    op: int           # sub-operation selector (0..15), only feeds the value function
    use1: int         # reads rs1
    rs1: int
    use2: int         # reads rs2
    rs2: int
    wr: int           # writes rd (the write itself may be partial: mask, or r0 => discarded)
    rd: int
    mask: int         # execution mask (bit i = lane i active)
    imm: int          # 32-bit immediate (value function input only)

    def reads(self):
        """Source registers that actually need a register-file access (r0, unused slots excluded)."""
        out = []
        if self.use1 and self.rs1 != 0:
            out.append(self.rs1)
        if self.use2 and self.rs2 != 0:
            out.append(self.rs2)
        return out

    def line(self) -> str:
        return (f"{self.gid} {self.warp} {self.cls} {self.fn} {self.op} {self.use1} {self.rs1} "
                f"{self.use2} {self.rs2} {self.wr} {self.rd} {self.mask:x} {self.imm:x}")

    @staticmethod
    def parse(line: str) -> "Insn":
        t = line.split()
        return Insn(int(t[0]), int(t[1]), int(t[2]), int(t[3]), int(t[4]), int(t[5]), int(t[6]),
                    int(t[7]), int(t[8]), int(t[9]), int(t[10]), int(t[11], 16), int(t[12], 16))
