#!/usr/bin/env python3
"""Generate the standard trace set (identical for every DUT/config) into work/traces/.

All traces are written as <name>.trace (instructions) + <name>.exp (Python-model expectations).
Synthetic: patterns the real programs do not stress.  SIMT-derived: real instruction streams with real
divergence masks, from the vendored SilicaFlux SIMT programs (directed suite + random legal programs).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from rfref import tracegen, simt_trace   # noqa: E402

ROOT = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(ROOT, "work", "traces")


def concat(streams, nwarps):
    """Per warp: concatenation of the per-warp streams of several programs (program i feeds warp (i+k) mod nwarps)."""
    out = {w: [] for w in range(nwarps)}
    k = 0
    for name, per_warp in streams:
        for w in sorted(per_warp):
            out[(k + w) % nwarps].extend(per_warp[w])
        k += max(1, len(per_warp))
    return out


def main(lanes=8, nwarps=8, scale=1.0, outdir=OUT):
    n = lambda x: max(20, int(x * scale))
    os.makedirs(outdir, exist_ok=True)
    made = {}

    def add(name, per_warp):
        made[name] = tracegen.build(name, per_warp, lanes, nwarps, outdir)

    add("uni_mixed", tracegen.gen_uniform(nwarps, n(500), lanes, 11, "mixed"))
    add("uni_full", tracegen.gen_uniform(nwarps, n(500), lanes, 12, "full"))
    add("loopy", tracegen.gen_loopy(nwarps, n(500), lanes, 13, "mixed"))
    add("hammer8", tracegen.gen_hammer(nwarps, n(400), lanes, 14, stride=8))
    add("hammer4", tracegen.gen_hammer(nwarps, n(400), lanes, 15, stride=4))
    add("dep1", tracegen.gen_depchain(1, n(400), lanes, 16))
    add("dep8", tracegen.gen_depchain(nwarps, n(200), lanes, 17))
    add("ldburst", tracegen.gen_ldburst(nwarps, n(400), lanes, 18, "mixed"))
    add("memstall", tracegen.gen_memstall(nwarps, n(300), lanes, 19))
    add("memflood", tracegen.gen_memflood(nwarps, n(300), lanes, 21))
    # WAR probes are generated for the bank geometries used in the tests (hot bank 0 depends on the mapping)
    # (3 hammer warps + the probe warp: enough to starve the probe's reads without saturating the unit pool,
    #  which would stop the younger probe instruction from being allocated at all)
    for nb, bm in ((4, 1), (4, 2), (2, 1), (8, 1)):
        add(f"war_nb{nb}m{bm}", tracegen.gen_war_probe(4, n(300), lanes, 20 + nb + bm, nb=nb, bmap=bm))
    d_streams = list(simt_trace.directed_traces(lanes, nwarps))
    add("simt_dir", concat(d_streams, nwarps))
    r_streams = list(simt_trace.random_traces(lanes, range(100, 100 + int(24 * scale) + 1), nwarps))
    add("simt_rand", concat(r_streams, nwarps))
    return made


if __name__ == "__main__":
    lanes = int(os.environ.get("LANES", "8"))
    scale = float(os.environ.get("SCALE", "1.0"))
    out = os.environ.get("OUT", OUT)
    made = main(lanes=lanes, scale=scale, outdir=out)
    for k, v in made.items():
        print(f"{k:12s} {len(v):6d} instructions")
