// Dumps the RTL's register -> (bank, row) mapping for every bank count, map and (warp, reg); the Python reference
// (python/rfref/bankmap.py) is compared against this dump by scripts/check_bankmap.py.
module tb_bankmap;
  import sf_rfc_pkg::*;
  initial begin
    for (int bw = 0; bw <= 5; bw++) begin
      for (int bm = 0; bm < 3; bm++) begin
        for (int w = 0; w < 8; w++) begin
          for (int r = 0; r < 32; r++) begin
            logic [4:0] b;
            int row;
            b   = f_bank(bm, bw, 5'(w), 5'(r));
            row = w * (32 >> bw) + (r >> bw);
            $display("MAP %0d %0d %0d %0d %0d %0d", 1 << bw, bm, w, r, b, row);
          end
        end
      end
    end
    $finish;
  end
endmodule
