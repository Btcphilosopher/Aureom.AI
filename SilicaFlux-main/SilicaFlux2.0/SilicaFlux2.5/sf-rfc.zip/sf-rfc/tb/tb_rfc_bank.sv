// Unit test of sf_rfc_bank against an independent shadow model of the specified visibility rule:
//   a read launched in cycle t returns the row content after all writes accepted in cycles <= t
//   (write-through), per lane; never-written rows read as zero; clr takes effect for reads launched >= t+1.
// Stimulus: dense random reads/writes on a tiny row space (forces every collision pattern), random masks
// including empty-mask-free partial masks, random clr_warp/clr_all pulses applied only when quiescent.
`default_nettype none
module tb_rfc_bank;
  parameter int unsigned LANES = 4;
  parameter int unsigned NUM_WARPS = 2;
  parameter int unsigned RPW = 4;
  parameter int unsigned ROWS = NUM_WARPS * RPW;
  parameter int unsigned STYLE = 0;
  parameter bit WT = 1'b1;
  parameter int unsigned CYCLES = 200000;
  localparam int unsigned AW = $clog2(ROWS);
  localparam int unsigned W = LANES * 32;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic clr_all = 0;
  logic [NUM_WARPS-1:0] clr_warp = '0;
  logic wr_en = 0, rd_en = 0;
  logic [AW-1:0] wr_row = '0, rd_row = '0;
  logic [LANES-1:0] wr_mask = '0;
  logic [W-1:0] wr_data = '0;
  wire [W-1:0] rd_data;
  wire rd_hit, idle;

  sf_rfc_bank #(.ROWS(ROWS), .LANES(LANES), .RPW(RPW), .NUM_WARPS(NUM_WARPS), .RAM_STYLE(STYLE), .WRITE_THROUGH(WT)) dut (
    .clk, .rst_n, .clr_all, .clr_warp, .wr_en, .wr_row, .wr_mask, .wr_data, .rd_en, .rd_row, .rd_data, .rd_hit, .idle);

  logic [31:0] shadow [ROWS][LANES];
  logic [W-1:0] exp_q;
  logic exp_v;
  int errors = 0, checks = 0, hits_seen = 0, hit_cases[4];
  bit stg_pending;     // a write was accepted last cycle (staged)

  // ---- stimulus (driven after the edge, so DUT inputs are stable before the next edge)
  int seed;
  initial begin
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    void'($urandom(seed));
  end

  int cyc = 0;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (cyc == 5) rst_n <= 1;
  end

  // shadow update + check on the same edge ending cycle t (inputs sampled are those of cycle t)
  always @(posedge clk) begin
    logic [31:0] tmp [LANES];
    if (!rst_n) begin
      for (int r = 0; r < ROWS; r++) for (int l = 0; l < LANES; l++) shadow[r][l] = 32'd0;
      exp_v <= 1'b0;
      stg_pending <= 1'b0;
    end else begin
      // check the read launched in the previous cycle
      if (exp_v) begin
        checks++;
        if (rd_data !== exp_q) begin
          errors++;
          if (errors < 10) $display("MISMATCH cyc=%0d got=%h exp=%h", cyc, rd_data, exp_q);
        end
        if (rd_hit) hits_seen++;
      end
      // reads launched now see writes accepted now (write-through) [or not, if WT=0 -> only < t]
      for (int l = 0; l < LANES; l++) tmp[l] = shadow[rd_row][l];
      if (WT && wr_en && wr_row == rd_row)
        for (int l = 0; l < LANES; l++) if (wr_mask[l]) tmp[l] = wr_data[l*32 +: 32];
      for (int l = 0; l < LANES; l++) exp_q[l*32 +: 32] <= tmp[l];
      exp_v <= rd_en;
      // clears (applied only when quiescent by the stimulus): visible to reads launched >= t+1
      if (clr_all) for (int r = 0; r < ROWS; r++) for (int l = 0; l < LANES; l++) shadow[r][l] = 32'd0;
      for (int w = 0; w < NUM_WARPS; w++) if (clr_warp[w])
        for (int r = w*RPW; r < (w+1)*RPW; r++) for (int l = 0; l < LANES; l++) shadow[r][l] = 32'd0;
      // writes accepted now
      if (wr_en) for (int l = 0; l < LANES; l++) if (wr_mask[l]) shadow[wr_row][l] = wr_data[l*32 +: 32];
      stg_pending <= wr_en;
    end
  end

  // the WT=0 variant is "read-old for the accept cycle": the expected value above must then exclude it, which the
  // shadow does (WT && ...). The write itself still lands, visible from t+1.

  // random stimulus generator (after the edge)
  logic [31:0] rnd;
  always @(posedge clk) begin
    if (rst_n) begin
      rnd = $urandom;
      // few distinct rows so that collisions are the norm
      wr_en   <= ($urandom % 100) < 70;
      wr_row  <= AW'($urandom % ((($urandom % 3) == 0) ? ROWS : 3));
      wr_mask <= LANES'(1 + ($urandom % ((1 << LANES) - 1)));      // non-empty
      for (int l = 0; l < LANES; l++) wr_data[l*32 +: 32] <= $urandom;
      rd_en   <= ($urandom % 100) < 85;
      // bias reads toward the rows just written (same row same cycle, row written last cycle, ...)
      case ($urandom % 4)
        0: rd_row <= AW'($urandom % ROWS);
        1: rd_row <= wr_row;                     // next-cycle collision candidate
        default: rd_row <= AW'($urandom % 3);
      endcase
      // clears only when quiescent: nothing staged, nothing being accepted this/next cycle
      clr_all  <= 1'b0;
      clr_warp <= '0;
      if (!wr_en && !stg_pending && idle && ($urandom % 400) == 0) begin
        wr_en <= 1'b0;
        if ($urandom % 3 == 0) clr_all <= 1'b1;
        else clr_warp[$urandom % NUM_WARPS] <= 1'b1;
      end
    end
  end

  initial begin
    for (int i = 0; i < CYCLES; i++) @(posedge clk);
    $display("RESULT tb_rfc_bank LANES=%0d STYLE=%0d WT=%0d checks=%0d forwarded_reads=%0d errors=%0d",
             LANES, STYLE, WT, checks, hits_seen, errors);
    if (errors == 0 && checks > 1000 && hits_seen > 100) $display("PASS");
    else $display("FAIL");
    $finish;
  end
endmodule
`default_nettype wire
