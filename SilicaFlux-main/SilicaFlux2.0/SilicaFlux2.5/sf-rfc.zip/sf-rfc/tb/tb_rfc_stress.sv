// =============================================================================
//  tb_rfc_stress -- module-level, UNCONSTRAINED random test of sf_rfc against a cycle-accurate shadow model.
//
//  The trace testbench drives scoreboard-legal traffic.  This one deliberately is not: registers come from a
//  tiny hot pool, writebacks target arbitrary registers at arbitrary times from either port (so reads race
//  with writes, the same register is written by two ports in the same cycle, WAR/RAW windows are wide open),
//  masks include empty and single-lane, and the DUT is reset in the middle of activity.
//
//  Shadow model = the DOCUMENTED SEMANTICS only (docs/ARCHITECTURE.md s.4), driven by what the DUT reports
//  at its ports (accepted writes) and monitor outputs (which requests were granted in which cycle):
//    * a write is applied to lanes in its mask in the cycle it is ACCEPTED (wb_valid && wb_ready, need = we && rd != 0 && mask != 0)
//    * a read granted in cycle t returns the row as of the end of the writes accepted in cycles <= t (write-through)
//    * operands that are not needed (r0 / unused / empty mask) are delivered as zero; a duplicate-register slot
//      equals slot 0
//    * clear/reset: every register reads zero afterwards, in-flight work vanishes
//  Properties checked (each can fail independently):
//    S1 operand values (all lanes)      S2 dispatch exactly once, per-warp in allocation order
//    S3 completion == acceptance, record echoed   S4 <= 1 accepted write per bank per cycle
//    S5 same-row writes offered together are accepted lowest-port first   S6 bounded wait of a pending write
//    S7 one launched row per bank per cycle   S8 bounded wait of a pending read request (no starvation)
//    S9 counters (conflicts, write stalls, accepted writes) equal an independent recount
// =============================================================================
`default_nettype none
module tb_rfc_stress
  import sf_rfc_pkg::*;
#(
  parameter int NUM_WARPS = 4,
  parameter int LANES     = 4,
  parameter int NUM_BANKS = 4,
  parameter int BANK_MAP  = 1,
  parameter int NUM_CU    = 4,
  parameter int RD_ARB    = 1,
  parameter bit RD_SHARE  = 1'b1,
  parameter bit FAST_READ = 1'b1,
  parameter bit WRITE_THROUGH = 1'b1,
  parameter int RAM_STYLE = 0
);
  localparam int NUM_CLS = 2, NUM_WB = 2, TAG_W = 4, PAYLOAD_W = 32, AUX_W = LANES;
  localparam int W = LANES * 32;
  localparam int WARP_W = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1;
  localparam int NREQ = 2 * NUM_CU;
  localparam int CU_W = (NUM_CU > 1) ? $clog2(NUM_CU) : 1;
  localparam int BW = clog2f(NUM_BANKS);
  localparam int POOL = 7;                                  // hot register pool size
  localparam int WAIT_BOUND_RD = 6 * NREQ + 16;
  localparam int WAIT_BOUND_WR = 4 * NUM_WB + 8;

  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n = 1'b0;
  logic clr_all = 1'b0;
  logic [NUM_WARPS-1:0] clr_warp = '0;
  logic idle;
  logic iss_valid;
  logic [NUM_CLS-1:0] iss_ready;
  logic iss_cls;
  logic [WARP_W-1:0] iss_warp;
  logic [TAG_W-1:0] iss_tag;
  logic [LANES-1:0] iss_mask;
  logic iss_use1, iss_use2, iss_wr;
  logic [4:0] iss_rs1, iss_rs2, iss_rd;
  logic [PAYLOAD_W-1:0] iss_payload;
  logic [NUM_CLS-1:0] dsp_valid, dsp_ready;
  logic [WARP_W-1:0] dsp_warp [NUM_CLS];
  logic [TAG_W-1:0] dsp_tag [NUM_CLS];
  logic [LANES-1:0] dsp_mask [NUM_CLS];
  logic dsp_wr [NUM_CLS];
  logic [4:0] dsp_rd [NUM_CLS];
  logic [PAYLOAD_W-1:0] dsp_payload [NUM_CLS];
  logic [W-1:0] dsp_op1 [NUM_CLS], dsp_op2 [NUM_CLS];
  logic [NUM_WB-1:0] wb_valid, wb_ready;
  logic [WARP_W-1:0] wb_warp [NUM_WB];
  logic [TAG_W-1:0] wb_tag [NUM_WB];
  logic wb_we [NUM_WB];
  logic [4:0] wb_rd [NUM_WB];
  logic [LANES-1:0] wb_mask [NUM_WB];
  logic [W-1:0] wb_data [NUM_WB];
  logic [AUX_W-1:0] wb_aux [NUM_WB];
  logic [NUM_WB-1:0] cmpl_valid;
  logic [WARP_W-1:0] cmpl_warp [NUM_WB];
  logic [TAG_W-1:0] cmpl_tag [NUM_WB];
  logic [AUX_W-1:0] cmpl_aux [NUM_WB];
  logic [31:0] perf [PERF_N];
  logic [NUM_CU-1:0] mon_alloc;
  logic [NREQ-1:0] mon_req, mon_gnt;
  logic [WARP_W-1:0] mon_rq_warp [NREQ];
  logic [4:0] mon_rq_reg [NREQ];
  logic [CU_W-1:0] mon_dsp_cu [NUM_CLS];

  sf_rfc #(.NUM_WARPS(NUM_WARPS), .LANES(LANES), .NUM_BANKS(NUM_BANKS), .BANK_MAP(BANK_MAP), .NUM_CU(NUM_CU),
           .NUM_CLS(NUM_CLS), .NUM_WB(NUM_WB), .RD_ARB(RD_ARB), .RD_SHARE(RD_SHARE), .FAST_READ(FAST_READ),
           .WRITE_THROUGH(WRITE_THROUGH), .TAG_W(TAG_W), .PAYLOAD_W(PAYLOAD_W), .AUX_W(AUX_W), .RAM_STYLE(RAM_STYLE),
           .STRICT(1'b0), .PERF_EN(1'b1)) dut (
    .clk, .rst_n, .clr_all_i(clr_all), .clr_warp_i(clr_warp), .idle_o(idle),
    .iss_valid_i(iss_valid), .iss_ready_o(iss_ready), .iss_cls_i(iss_cls), .iss_warp_i(iss_warp), .iss_tag_i(iss_tag),
    .iss_mask_i(iss_mask), .iss_use1_i(iss_use1), .iss_use2_i(iss_use2), .iss_rs1_i(iss_rs1), .iss_rs2_i(iss_rs2),
    .iss_wr_i(iss_wr), .iss_rd_i(iss_rd), .iss_payload_i(iss_payload),
    .dsp_valid_o(dsp_valid), .dsp_ready_i(dsp_ready), .dsp_warp_o(dsp_warp), .dsp_tag_o(dsp_tag), .dsp_mask_o(dsp_mask),
    .dsp_wr_o(dsp_wr), .dsp_rd_o(dsp_rd), .dsp_payload_o(dsp_payload), .dsp_op1_o(dsp_op1), .dsp_op2_o(dsp_op2),
    .wb_valid_i(wb_valid), .wb_ready_o(wb_ready), .wb_warp_i(wb_warp), .wb_tag_i(wb_tag), .wb_we_i(wb_we),
    .wb_rd_i(wb_rd), .wb_mask_i(wb_mask), .wb_data_i(wb_data), .wb_aux_i(wb_aux),
    .cmpl_valid_o(cmpl_valid), .cmpl_warp_o(cmpl_warp), .cmpl_tag_o(cmpl_tag), .cmpl_aux_o(cmpl_aux),
    .perf_clear_i(1'b0), .perf_o(perf), .mon_alloc_o(mon_alloc), .mon_req_o(mon_req), .mon_gnt_o(mon_gnt),
    .mon_rq_warp_o(mon_rq_warp), .mon_rq_reg_o(mon_rq_reg), .mon_dsp_cu_o(mon_dsp_cu));

  // ------------------------------------------------------------------ run parameters
  int seed, cycles, iss_pct, dsp_pct, wb_pct, wr_pct, reset_every, clear_every, max_instr;
  initial begin
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("cycles=%d", cycles)) cycles = 60000;
    if (!$value$plusargs("iss_pct=%d", iss_pct)) iss_pct = 70;
    if (!$value$plusargs("dsp_pct=%d", dsp_pct)) dsp_pct = 60;
    if (!$value$plusargs("wb_pct=%d", wb_pct)) wb_pct = 60;
    if (!$value$plusargs("wr_pct=%d", wr_pct)) wr_pct = 75;
    if (!$value$plusargs("reset_every=%d", reset_every)) reset_every = 0;
    if (!$value$plusargs("clear_every=%d", clear_every)) clear_every = 0;
    void'($urandom(seed));
  end

  // ------------------------------------------------------------------ shadow state
  logic [31:0] shadow [NUM_WARPS][32][LANES];

  typedef struct {
    bit               v;
    int               id;
    int               warp, cls, tag;
    bit [LANES-1:0]   mask;
    bit               wr;
    int               rd, rs1, rs2;
    bit               need0, need1, dup;
    logic [W-1:0]     exp0, exp1;
    int               seq;            // allocation order within the warp
    int               age;
  } cu_t;
  cu_t cu [NUM_CU];

  int  next_id, issued, completed_n, dispatched_n, errors, resets, clears;
  longint unsigned total_disp;
  int  alloc_seq [NUM_WARPS], disp_seq [NUM_WARPS];
  int  rwait [NREQ];
  longint unsigned conf_tb, wr_acc_tb, wb_stall_tb, dsp_stall_tb;
  longint unsigned cov_same_cycle, cov_next_cycle, cov_pair_same_row, cov_wb_conf, cov_partial, cov_empty;

  // ------------------------------------------------------------------ backend pool
  typedef struct {
    bit v; int id, warp, tag, rdy;
    bit we; int rd; bit [LANES-1:0] mask; logic [W-1:0] data;
  } be_t;
  be_t be [64];
  bit  wcur_v [NUM_WB];
  int  wcur_id [NUM_WB], wcur_wait [NUM_WB];
  int  wcur_row_key [NUM_WB];
  int  offer_age [NUM_WB];

  function automatic int ibank(input int w, input int r);
    logic [4:0] b;
    b = f_bank(BANK_MAP, BW, 5'(w), 5'(r));
    return int'(b);
  endfunction
  function automatic int irow(input int w, input int r);
    return w * (32 >> BW) + (r >> BW);
  endfunction

  task automatic err(input string m);
    errors++;
    if (errors <= 12) $display("[cyc %0d] ERROR: %s", cyc, m);
  endtask

  // ------------------------------------------------------------------ stimulus generator (combinational view)
  int cyc = 0;
  bit quiesce;                 // stop issuing / offering, drain, then clear
  int rr_pick;
  logic run_en;
  logic [31:0] rnd1, rnd2;

  function automatic int pick_reg(input int pool_only);
    int x;
    x = $urandom_range(0, 99);
    if (pool_only != 0 || x < 85) return $urandom_range(0, POOL);   // r0 .. r7 : r0 included on purpose
    return $urandom_range(0, 31);
  endfunction
  function automatic bit [LANES-1:0] pick_mask();
    int x;
    x = $urandom_range(0, 99);
    if (x < 35) return '1;
    if (x < 45) return '0;
    if (x < 60) return LANES'(1) << $urandom_range(0, LANES - 1);
    return LANES'($urandom);
  endfunction

  // stimulus is decided at the clock edge and registered (new values visible next cycle) except the issue valid,
  // which also needs the DUT's same-cycle iss_ready: keep the candidate registered and gate with iss_ready.
  logic            cand_v;
  logic            cand_cls;
  logic [WARP_W-1:0] cand_warp;
  logic [LANES-1:0] cand_mask;
  logic            cand_u1, cand_u2, cand_wr;
  logic [4:0]      cand_r1, cand_r2, cand_rd;
  logic [31:0]     cand_id;

  assign iss_valid   = cand_v && rst_n && !quiesce;
  assign iss_cls     = cand_cls;
  assign iss_warp    = cand_warp;
  assign iss_tag     = TAG_W'(cand_id);
  assign iss_mask    = cand_mask;
  assign iss_use1    = cand_u1;
  assign iss_use2    = cand_u2;
  assign iss_rs1     = cand_r1;
  assign iss_rs2     = cand_r2;
  assign iss_wr      = cand_wr;
  assign iss_rd      = cand_rd;
  assign iss_payload = cand_id;

  // ------------------------------------------------------------------ main checker / driver
  int  pre_applied_w;
  logic [31:0] tmp_row [LANES];
  int  held_wait [NUM_WB];
  int  rst_cnt, qcnt;
  bit  clr_pending;

  always @(posedge clk) begin
    int p, r, c, g, k, lw, lr;
    bit need_acc [NUM_WB];
    int bank_cnt [NUM_BANKS];
    logic [W-1:0] row_val;
    int n_nr;
    cyc <= cyc + 1;
    if (cyc == 5) rst_n <= 1'b1;

    if (!rst_n) begin
      // reset: everything vanishes; shadow state is all-zero
      for (int w = 0; w < NUM_WARPS; w++) begin
        for (int q = 0; q < 32; q++) for (int l = 0; l < LANES; l++) shadow[w][q][l] = 32'd0;
        alloc_seq[w] = 0; disp_seq[w] = 0;
      end
      for (int q = 0; q < NUM_CU; q++) cu[q].v = 1'b0;
      for (int q = 0; q < 64; q++) be[q].v = 1'b0;
      for (p = 0; p < NUM_WB; p++) begin wcur_v[p] = 1'b0; wb_valid[p] <= 1'b0; held_wait[p] = 0; end
      for (int q = 0; q < NREQ; q++) rwait[q] = 0;
      dsp_ready <= '0;
      cand_v <= 1'b0;
      issued = (cyc < 6) ? 0 : issued;       // counters keep running across a mid-run reset (see below)
    end else begin
      // ---------------- 1. writebacks accepted this cycle -> shadow (write-through: before this cycle's reads)
      for (int b = 0; b < NUM_BANKS; b++) bank_cnt[b] = 0;
      for (p = 0; p < NUM_WB; p++) begin
        need_acc[p] = wb_valid[p] && wb_ready[p] && wb_we[p] && wb_rd[p] != 5'd0 && wb_mask[p] != '0;
        if (cmpl_valid[p] !== (wb_valid[p] & wb_ready[p])) err($sformatf("S3 cmpl_valid[%0d] != wb_valid&wb_ready", p));
        if (wb_valid[p] && wb_ready[p]) begin
          if (cmpl_warp[p] !== wb_warp[p] || cmpl_tag[p] !== wb_tag[p] || cmpl_aux[p] !== wb_aux[p])
            err($sformatf("S3 completion record on port %0d differs from the accepted record", p));
          completed_n++;
          wcur_v[p] = 1'b0; held_wait[p] = 0;
        end else if (wb_valid[p]) begin
          wb_stall_tb++;
          held_wait[p]++;
          if (held_wait[p] > WAIT_BOUND_WR) err($sformatf("S6 writeback port %0d waited %0d cycles without acceptance", p, held_wait[p]));
        end
        if (need_acc[p]) begin
          wr_acc_tb++;
          bank_cnt[ibank(int'(wb_warp[p]), int'(wb_rd[p]))]++;
          if ((wb_mask[p] != '1)) cov_partial++;
        end
      end
      for (int b = 0; b < NUM_BANKS; b++) if (bank_cnt[b] > 1) err($sformatf("S4 bank %0d accepted %0d writes in one cycle", b, bank_cnt[b]));
      // same-row pair offered together: lowest port first (and never both in the same cycle: S4)
      if (NUM_WB >= 2 && wb_valid[0] && wb_valid[1] && wb_we[0] && wb_we[1] && wb_rd[0] != 0 && wb_rd[1] != 0 &&
          wb_mask[0] != '0 && wb_mask[1] != '0 && wb_warp[0] == wb_warp[1] && wb_rd[0] == wb_rd[1]) begin
        cov_pair_same_row++;
        if (wb_ready[1] && !wb_ready[0]) err("S5 same-row pair: higher port accepted before the lower one");
      end
      if (NUM_WB >= 2 && wb_valid[0] && wb_valid[1] && wb_we[0] && wb_we[1] && wb_rd[0] != 0 && wb_rd[1] != 0 &&
          wb_mask[0] != '0 && wb_mask[1] != '0 && ibank(int'(wb_warp[0]), int'(wb_rd[0])) == ibank(int'(wb_warp[1]), int'(wb_rd[1])))
        cov_wb_conf++;
      if (WRITE_THROUGH) apply_writes(need_acc);          // visible to reads launched in this very cycle

      // ---------------- 2. allocation (record what the DUT was asked to collect)
      for (c = 0; c < NUM_CU; c++) if (mon_alloc[c]) begin
        if (cu[c].v) err($sformatf("allocation into occupied unit %0d", c));
        cu[c].v = 1'b1; cu[c].id = int'(iss_payload); cu[c].warp = int'(iss_warp); cu[c].cls = int'(iss_cls);
        cu[c].tag = int'(iss_tag); cu[c].mask = iss_mask; cu[c].wr = iss_wr; cu[c].rd = int'(iss_rd);
        cu[c].rs1 = int'(iss_rs1); cu[c].rs2 = int'(iss_rs2);
        cu[c].need0 = iss_use1 && iss_rs1 != 0 && iss_mask != '0;
        cu[c].dup = cu[c].need0 && iss_use2 && iss_rs2 == iss_rs1;
        cu[c].need1 = iss_use2 && iss_rs2 != 0 && iss_mask != '0 && !cu[c].dup;
        cu[c].exp0 = '0; cu[c].exp1 = '0;
        cu[c].seq = alloc_seq[int'(iss_warp)]++;
        issued++;
        if (iss_mask == '0) cov_empty++;
      end

      // ---------------- 3. read grants this cycle: expected row value now (writes accepted this cycle included)
      for (r = 0; r < NREQ; r++) begin
        c = r / 2; k = r % 2;
        if (mon_req[r] && !mon_gnt[r]) begin conf_tb++; rwait[r]++; if (rwait[r] > WAIT_BOUND_RD) err($sformatf("S8 requester %0d starved for %0d cycles", r, rwait[r])); end
        if (!mon_req[r]) rwait[r] = 0;
        if (mon_gnt[r]) begin
          rwait[r] = 0;
          lw = int'(mon_rq_warp[r]); lr = int'(mon_rq_reg[r]);
          if (!mon_req[r]) err("S7 grant without request");
          for (int l = 0; l < LANES; l++) row_val[l*32 +: 32] = shadow[lw][lr][l];
          if (k == 0) cu[c].exp0 = row_val; else cu[c].exp1 = row_val;
          // coverage: read of a row written in this very cycle / in the previous cycle
          for (p = 0; p < NUM_WB; p++) if (need_acc[p] && int'(wb_warp[p]) == lw && int'(wb_rd[p]) == lr) cov_same_cycle++;
        end
      end
      if (!WRITE_THROUGH) apply_writes(need_acc);         // read-old variant: visible from the next cycle only
      // S7: all grants of one bank must be for the same row
      for (int b = 0; b < NUM_BANKS; b++) begin
        int rowv; rowv = -1;
        for (r = 0; r < NREQ; r++) if (mon_gnt[r] && ibank(int'(mon_rq_warp[r]), int'(mon_rq_reg[r])) == b) begin
          if (rowv >= 0 && rowv != irow(int'(mon_rq_warp[r]), int'(mon_rq_reg[r]))) err($sformatf("S7 bank %0d launched two different rows in one cycle", b));
          rowv = irow(int'(mon_rq_warp[r]), int'(mon_rq_reg[r]));
        end
      end

      // ---------------- 4. dispatch accepted this cycle
      for (p = 0; p < NUM_CLS; p++) begin
        if (dsp_valid[p] && !dsp_ready[p]) dsp_stall_tb++;
        if (dsp_valid[p] && dsp_ready[p]) begin
          c = int'(mon_dsp_cu[p]);
          if (!cu[c].v) err($sformatf("S2 dispatch of free unit %0d", c));
          else begin
            logic [W-1:0] e1, e2;
            e1 = cu[c].need0 ? cu[c].exp0 : '0;
            e2 = cu[c].need1 ? cu[c].exp1 : (cu[c].dup ? cu[c].exp0 : '0);
            if (int'(dsp_payload[p]) != cu[c].id) err($sformatf("S2 payload %0d != unit's instruction %0d", dsp_payload[p], cu[c].id));
            if (int'(dsp_warp[p]) != cu[c].warp || int'(dsp_tag[p]) != cu[c].tag || dsp_mask[p] !== cu[c].mask || p != cu[c].cls)
              err($sformatf("S2 descriptor of instruction %0d corrupted", cu[c].id));
            if (dsp_op1[p] !== e1) err($sformatf("S1 id%0d w%0d r%0d: OPERAND 1 got %h exp %h", cu[c].id, cu[c].warp, cu[c].rs1, dsp_op1[p], e1));
            if (dsp_op2[p] !== e2) err($sformatf("S1 id%0d w%0d r%0d: OPERAND 2 got %h exp %h", cu[c].id, cu[c].warp, cu[c].rs2, dsp_op2[p], e2));
            if (cu[c].seq != disp_seq[cu[c].warp]) err($sformatf("S2 warp %0d dispatch out of allocation order (%0d != %0d)", cu[c].warp, cu[c].seq, disp_seq[cu[c].warp]));
            disp_seq[cu[c].warp]++;
            dispatched_n++;
            total_disp++;
            // backend: schedule a writeback record (random target register, random mask/data, random delay)
            for (g = 0; g < 64; g++) if (!be[g].v) break;
            if (g < 64) begin
              be[g].v = 1'b1; be[g].id = cu[c].id; be[g].warp = cu[c].warp; be[g].tag = cu[c].tag;
              be[g].rdy = cyc + $urandom_range(1, 6);
              be[g].we = ($urandom_range(0, 99) < wr_pct);
              be[g].rd = pick_reg(0);
              be[g].mask = pick_mask();
              for (int l = 0; l < LANES; l++) be[g].data[l*32 +: 32] = $urandom;
            end else err("backend pool full");
            cu[c].v = 1'b0;
          end
        end
      end

      // ---------------- 5. next writeback offers (registered; held until accepted)
      for (p = 0; p < NUM_WB; p++) begin
        if (!wcur_v[p] && !quiesce_wb_hold()) begin
          g = -1;
          for (int q = 0; q < 64; q++) if (be[q].v && be[q].rdy <= cyc + 1 && (g < 0 || be[q].rdy < be[g].rdy)) g = q;
          if (g >= 0 && $urandom_range(0, 99) < wb_pct) begin
            wcur_v[p] = 1'b1; wcur_id[p] = be[g].id;
            wb_warp[p] <= WARP_W'(be[g].warp); wb_tag[p] <= TAG_W'(be[g].tag); wb_we[p] <= be[g].we;
            wb_rd[p] <= 5'(be[g].rd); wb_mask[p] <= be[g].mask; wb_data[p] <= be[g].data;
            wb_aux[p] <= AUX_W'($urandom);
            be[g].v = 1'b0;
          end
        end
        wb_valid[p] <= wcur_v[p];
      end

      // ---------------- 6. next issue candidate / ready pattern
      if (!quiesce) begin
        if (!(cand_v && !(iss_valid && iss_ready[iss_cls]))) begin     // previous candidate accepted (or none): make a new one
          if ($urandom_range(0, 99) < iss_pct && issued < max_instr_total()) begin
            cand_v <= 1'b1; cand_id <= next_id; next_id++;
            cand_cls <= $urandom_range(0, 1);
            cand_warp <= WARP_W'($urandom_range(0, NUM_WARPS - 1));
            cand_mask <= pick_mask();
            cand_u1 <= $urandom_range(0, 99) < 85;  cand_u2 <= $urandom_range(0, 99) < 60;
            cand_r1 <= 5'(pick_reg(0));
            cand_r2 <= ($urandom_range(0, 99) < 12) ? 5'(pick_reg(0)) : 5'(pick_reg(0));
            cand_wr <= $urandom_range(0, 1);
            cand_rd <= 5'(pick_reg(0));
          end else cand_v <= 1'b0;
        end
      end else cand_v <= 1'b0;
      for (p = 0; p < NUM_CLS; p++) dsp_ready[p] <= ($urandom_range(0, 99) < dsp_pct);
    end
  end

  task automatic apply_writes(input bit acc [NUM_WB]);
    for (int pp = 0; pp < NUM_WB; pp++) if (acc[pp]) begin
      int lw2, lr2;
      lw2 = int'(wb_warp[pp]); lr2 = int'(wb_rd[pp]);
      for (int l = 0; l < LANES; l++) if (wb_mask[pp][l]) shadow[lw2][lr2][l] = wb_data[pp][l*32 +: 32];
    end
  endtask

  function automatic bit quiesce_wb_hold();
    return 1'b0;
  endfunction
  function automatic int max_instr_total();
    return 1 << 30;
  endfunction

  // ------------------------------------------------------------------ resets and quiescent clears
  int ev_cnt;
  initial begin max_instr = 1 << 30; ev_cnt = 0; quiesce = 1'b0; qcnt = 0; rst_cnt = 0; clr_pending = 1'b0;
    next_id = 1; issued = 0; completed_n = 0; dispatched_n = 0; errors = 0; resets = 0; clears = 0; total_disp = 0;
    conf_tb = 0; wr_acc_tb = 0; wb_stall_tb = 0; dsp_stall_tb = 0;
    cov_same_cycle = 0; cov_next_cycle = 0; cov_pair_same_row = 0; cov_wb_conf = 0; cov_partial = 0; cov_empty = 0;
    cand_v = 1'b0; cand_id = 0; cand_cls = 1'b0; cand_warp = '0; cand_mask = '0; cand_u1 = 1'b0; cand_u2 = 1'b0;
    cand_r1 = '0; cand_r2 = '0; cand_rd = '0; cand_wr = 1'b0;
    dsp_ready = '0; wb_valid = '0;
    for (int p = 0; p < NUM_WB; p++) begin wcur_v[p] = 1'b0; wb_warp[p] = '0; wb_tag[p] = '0; wb_we[p] = 1'b0; wb_rd[p] = '0; wb_mask[p] = '0; wb_data[p] = '0; wb_aux[p] = '0; end
    for (int q = 0; q < 64; q++) be[q].v = 1'b0;
    for (int q = 0; q < NUM_CU; q++) cu[q].v = 1'b0;
  end

  always @(posedge clk) if (rst_n) begin
    ev_cnt++;
    // mid-run reset (all state, in-flight work and the RAM contents must vanish architecturally)
    if (reset_every > 0 && ev_cnt % reset_every == 0 && !quiesce) begin
      resets++;
      rst_n <= 1'b0;
      rst_cnt = $urandom_range(1, 3);               // reset pulses of 1..3 cycles
      completed_n = 0; dispatched_n = 0; issued = 0;
    end
    // quiescent clear: stop traffic, drain, then clear one warp or everything
    if (clear_every > 0 && ev_cnt % clear_every == 0 && !quiesce) begin quiesce = 1'b1; qcnt = 0; end
    if (quiesce) begin
      qcnt++;
      if (idle && !wcur_v[0] && !wcur_v[1] && qcnt > 40 && !clr_pending) begin
        bit any_be; any_be = 1'b0;
        for (int q = 0; q < 64; q++) if (be[q].v) any_be = 1'b1;
        if (!any_be) begin
          clr_pending = 1'b1;
          clears++;
          if ($urandom_range(0, 2) == 0) begin
            clr_all <= 1'b1;
            for (int w = 0; w < NUM_WARPS; w++) for (int q = 0; q < 32; q++) for (int l = 0; l < LANES; l++) shadow[w][q][l] = 32'd0;
          end else begin
            int w; w = $urandom_range(0, NUM_WARPS - 1);
            clr_warp[w] <= 1'b1;
            for (int q = 0; q < 32; q++) for (int l = 0; l < LANES; l++) shadow[w][q][l] = 32'd0;
          end
        end
      end else if (clr_pending) begin
        clr_all <= 1'b0; clr_warp <= '0;
        clr_pending = 1'b0; quiesce = 1'b0;
      end
    end
  end
  always @(posedge clk) begin
    if (!rst_n && rst_cnt > 0) begin
      rst_cnt--;
      if (rst_cnt == 0) rst_n <= 1'b1;
    end
  end

  // ------------------------------------------------------------------ end of run
  initial begin
    for (int i = 0; i < cycles; i++) @(posedge clk);
    finish();
  end
  task automatic finish();
    bit ok;
    ok = (errors == 0);
    if (perf[PERF_RD_CONFLICT] != conf_tb && resets == 0) begin $display("ERROR: S9 read-conflict counter RTL %0d vs recount %0d", perf[PERF_RD_CONFLICT], conf_tb); ok = 1'b0; end
    if (perf[PERF_WB_ACCEPT] != wr_acc_tb && resets == 0)  begin $display("ERROR: S9 accepted-write counter RTL %0d vs recount %0d", perf[PERF_WB_ACCEPT], wr_acc_tb); ok = 1'b0; end
    if (perf[PERF_WB_STALL] != wb_stall_tb && resets == 0) begin $display("ERROR: S9 wb-stall counter RTL %0d vs recount %0d", perf[PERF_WB_STALL], wb_stall_tb); ok = 1'b0; end
    if (perf[PERF_DSP_STALL] != dsp_stall_tb && resets == 0) begin $display("ERROR: S9 dispatch-stall counter RTL %0d vs recount %0d", perf[PERF_DSP_STALL], dsp_stall_tb); ok = 1'b0; end
    if (total_disp < 200) begin $display("ERROR: only %0d dispatches in the whole run (no real activity)", total_disp); ok = 1'b0; end
    $display("RESULT tb_rfc_stress banks=%0d map=%0d cu=%0d arb=%0d share=%0d fast=%0d wt=%0d cyc=%0d dispatched=%0d completed=%0d wr_acc=%0d rd_conf=%0d wb_stall=%0d resets=%0d clears=%0d cov_same_cycle_rw=%0d cov_same_row_pair=%0d cov_wb_bank_conf=%0d cov_partial_wr=%0d cov_empty_mask=%0d errors=%0d",
             NUM_BANKS, BANK_MAP, NUM_CU, RD_ARB, RD_SHARE, FAST_READ, WRITE_THROUGH, cyc, dispatched_n, completed_n, wr_acc_tb, conf_tb, wb_stall_tb, resets, clears,
             cov_same_cycle, cov_pair_same_row, cov_wb_conf, cov_partial, cov_empty, errors);
    if (ok) $display("PASS"); else $display("FAIL");
    $finish;
  endtask
endmodule
`default_nettype wire
