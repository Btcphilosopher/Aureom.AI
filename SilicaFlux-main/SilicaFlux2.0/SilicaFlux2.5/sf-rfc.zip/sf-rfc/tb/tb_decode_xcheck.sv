// Cross-check of sf_rfc_simt_dec against the SIMT RTL's own sf_simt_pkg::sf_predecode, all 32 opcodes x random fields.
`default_nettype none
module tb_decode_xcheck;
  import sf_simt_pkg::*;
  logic [31:0] w;
  logic u1, u2, wr, mem;
  logic [4:0] rs1, rs2, rd;
  sf_rfc_simt_dec dut (.instr_i(w), .use1_o(u1), .use2_o(u2), .wr_o(wr), .rs1_o(rs1), .rs2_o(rs2), .rd_o(rd), .mem_o(mem));
  int errors = 0, checks = 0, backend = 0;
  initial begin
    for (int op = 0; op < 32; op++) begin
      for (int k = 0; k < 4000; k++) begin
        sf_dinstr_t d;
        bit exp_mem;
        w = {5'(op), 27'($urandom)};
        if (k < 40) w[26:12] = {5'(k % 32), 5'((k / 3) % 32), 5'((k / 5) % 32)};   // include r0 combinations
        #1;
        d = sf_predecode(w, 1'b0);
        exp_mem = (d.cls == SF_CLS_LD) || (d.cls == SF_CLS_ST);
        checks++;
        if (d.cls != SF_CLS_LOCAL && !d.illegal) backend++;
        // r0 is elided by the SIMT decode; the descriptor here leaves it to sf_rfc: compare after the same elision
        if ((u1 && rs1 != 0) !== d.use_rs1) begin errors++; $display("use1 mismatch op=%0h w=%h", op, w); end
        if ((u2 && rs2 != 0) !== d.use_rs2) begin errors++; $display("use2 mismatch op=%0h w=%h", op, w); end
        if ((wr && rd  != 0) !== d.wr_rd)   begin errors++; $display("wr   mismatch op=%0h w=%h", op, w); end
        if (!d.illegal && d.cls != SF_CLS_LOCAL && mem !== exp_mem) begin errors++; $display("port mismatch op=%0h w=%h", op, w); end
        if (d.cls == SF_CLS_LOCAL && (u1 || u2 || wr)) begin errors++; $display("local op %0h decoded with operands", op); end
      end
    end
    $display("RESULT tb_decode_xcheck checks=%0d backend_words=%0d errors=%0d", checks, backend, errors);
    if (errors == 0) $display("PASS"); else $display("FAIL");
    $finish;
  end
endmodule
`default_nettype wire
