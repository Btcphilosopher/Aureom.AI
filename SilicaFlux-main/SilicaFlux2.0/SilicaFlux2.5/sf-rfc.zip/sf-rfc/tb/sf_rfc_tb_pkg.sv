// Value semantics of the trace instructions -- mirror of python/rfref/ops.py (keep in sync).
package sf_rfc_tb_pkg;
  localparam logic [31:0] K1 = 32'h9E3779B1, K2 = 32'h85EBCA6B, K3 = 32'hC2B2AE35, K4 = 32'h27D4EB2F, K5 = 32'h165667B1;
  localparam int FN_S2R = 0, FN_ALU2 = 1, FN_ALU1 = 2, FN_BR = 3, FN_LD = 4, FN_ST = 5, FN_DUMP = 6;

  function automatic logic fn_has_result(input int fn);
    return (fn == FN_S2R) || (fn == FN_ALU2) || (fn == FN_ALU1) || (fn == FN_LD);
  endfunction

  function automatic logic [31:0] f_lane(input int fn, input int op, input logic [31:0] a, input logic [31:0] b,
                                         input logic [31:0] imm, input int warp, input int lane);
    logic [31:0] t;
    case (fn)
      FN_S2R: return ((32'(lane) + 32'd1) * K2) ^ ((32'(warp) + 32'd1) * K3) ^ imm;
      FN_ALU2: begin
        t = a * K1;
        t = t + ((b ^ imm) * K4);
        t = t ^ (a >> 7) ^ (b << 5);
        return t + (32'(op) * K5);
      end
      FN_ALU1: begin
        t = (a * K1) ^ imm;
        t = t + (a >> 11);
        return t + (32'(op) * K5);
      end
      FN_LD: return (((a + imm) * K4) ^ ((32'(lane) + 32'd1) * K2) ^ (32'(warp) * K3));
      default: return 32'd0;
    endcase
  endfunction

  function automatic logic taken_bit(input logic [31:0] a, input logic [31:0] imm, input int lane);
    logic [31:0] x;
    x = (a ^ imm) >> (lane & 31);
    return x[0];
  endfunction
endpackage
