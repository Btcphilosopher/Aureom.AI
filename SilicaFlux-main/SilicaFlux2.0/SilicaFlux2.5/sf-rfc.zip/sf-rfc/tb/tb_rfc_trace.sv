// =============================================================================
//  tb_rfc_trace -- closed-loop, trace-driven testbench for sf_rfc (banked) and sf_rf_base (baseline).
//
//  The SAME trace file and the SAME timing configuration drive either DUT (DUT_KIND), so every metric is
//  directly comparable.  The testbench plays three roles:
//    FRONT END  issue rules of sf_simt_ctrl: one issue per cycle, round robin over warps, RAW/WAW scoreboard
//               (a completion in cycle c clears the pending bit for cycle c+1), NUM_SLOTS=4 in flight per warp,
//               fetch gap between instructions of one warp (single-warp CPI = FETCH_GAP+1), warp waits for a
//               branch's completion, iss_ready honoured.
//    BACKEND    accepts dispatches (ready pattern + stall windows), computes the result from the operands it
//               RECEIVED (so a wrong operand corrupts everything downstream), returns it after a random latency
//               through the writeback port (held until accepted), with optional idle gaps.
//    CHECKER    every dispatched instruction is checked field by field and its two operand rows against the
//               PYTHON architectural model (exp file); dispatch order per warp must equal program order;
//               every writeback result must equal the model's; completions must match offered records exactly;
//               the final register file is verified through DUMP instructions that read r0..r31.
//  Output: a RESULT line (key=value) consumed by scripts/*.py, then PASS or FAIL.
// =============================================================================
`default_nettype none
module tb_rfc_trace
  import sf_rfc_pkg::*, sf_rfc_tb_pkg::*;
#(
  parameter int DUT_KIND  = 0,        // 0 = sf_rfc (banked), 1 = sf_rf_base (replicated baseline)
  parameter int NUM_WARPS = 8,
  parameter int LANES     = 8,
  parameter int NUM_BANKS = 4,
  parameter int BANK_MAP  = 1,
  parameter int NUM_CU    = 4,
  parameter int RD_ARB    = 1,
  parameter bit RD_SHARE  = 1'b1,
  parameter bit FAST_READ = 1'b1,
  parameter bit WRITE_THROUGH = 1'b1,
  parameter int RAM_STYLE = 0
);
  localparam int NUM_CLS   = 2;
  localparam int NUM_WB    = 2;
  localparam int SLOTS     = 4;
  localparam int TAG_W     = 4;
  localparam int PAYLOAD_W = 32;
  localparam int AUX_W     = LANES;
  localparam int W         = LANES * 32;
  localparam int WARP_W    = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1;
  localparam int CLS_W     = 1;
  localparam int NREQ      = 2 * NUM_CU;
  localparam int CU_W      = (NUM_CU > 1) ? $clog2(NUM_CU) : 1;
  localparam int BQ        = 512;

  // ------------------------------------------------------------------ clock / reset
  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n = 1'b0;

  // ------------------------------------------------------------------ DUT signals
  logic                     clr_all = 1'b0;
  logic [NUM_WARPS-1:0]     clr_warp = '0;
  logic                     idle;
  logic                     iss_valid;
  logic [NUM_CLS-1:0]       iss_ready;
  logic [CLS_W-1:0]         iss_cls;
  logic [WARP_W-1:0]        iss_warp;
  logic [TAG_W-1:0]         iss_tag;
  logic [LANES-1:0]         iss_mask;
  logic                     iss_use1, iss_use2, iss_wr;
  logic [4:0]               iss_rs1, iss_rs2, iss_rd;
  logic [PAYLOAD_W-1:0]     iss_payload;
  logic [NUM_CLS-1:0]       dsp_valid, dsp_ready;
  logic [WARP_W-1:0]        dsp_warp    [NUM_CLS];
  logic [TAG_W-1:0]         dsp_tag     [NUM_CLS];
  logic [LANES-1:0]         dsp_mask    [NUM_CLS];
  logic                     dsp_wr      [NUM_CLS];
  logic [4:0]               dsp_rd      [NUM_CLS];
  logic [PAYLOAD_W-1:0]     dsp_payload [NUM_CLS];
  logic [W-1:0]             dsp_op1     [NUM_CLS];
  logic [W-1:0]             dsp_op2     [NUM_CLS];
  logic [NUM_WB-1:0]        wb_valid, wb_ready;
  logic [WARP_W-1:0]        wb_warp     [NUM_WB];
  logic [TAG_W-1:0]         wb_tag      [NUM_WB];
  logic                     wb_we       [NUM_WB];
  logic [4:0]               wb_rd       [NUM_WB];
  logic [LANES-1:0]         wb_mask     [NUM_WB];
  logic [W-1:0]             wb_data     [NUM_WB];
  logic [AUX_W-1:0]         wb_aux      [NUM_WB];
  logic [NUM_WB-1:0]        cmpl_valid;
  logic [WARP_W-1:0]        cmpl_warp   [NUM_WB];
  logic [TAG_W-1:0]         cmpl_tag    [NUM_WB];
  logic [AUX_W-1:0]         cmpl_aux    [NUM_WB];
  logic [31:0]              perf        [PERF_N];
  logic [NUM_CU-1:0]        mon_alloc;
  logic [NREQ-1:0]          mon_req, mon_gnt;
  logic [WARP_W-1:0]        mon_rq_warp [NREQ];
  logic [4:0]               mon_rq_reg  [NREQ];
  logic [CU_W-1:0]          mon_dsp_cu  [NUM_CLS];

  if (DUT_KIND == 0) begin : g_dut
    sf_rfc #(.NUM_WARPS(NUM_WARPS), .LANES(LANES), .NUM_BANKS(NUM_BANKS), .BANK_MAP(BANK_MAP), .NUM_CU(NUM_CU),
             .NUM_CLS(NUM_CLS), .NUM_WB(NUM_WB), .RD_ARB(RD_ARB), .RD_SHARE(RD_SHARE), .FAST_READ(FAST_READ), .WRITE_THROUGH(WRITE_THROUGH),
             .TAG_W(TAG_W), .PAYLOAD_W(PAYLOAD_W), .AUX_W(AUX_W), .RAM_STYLE(RAM_STYLE), .STRICT(1'b1), .PERF_EN(1'b1)) dut (
      .clk, .rst_n, .clr_all_i(clr_all), .clr_warp_i(clr_warp), .idle_o(idle),
      .iss_valid_i(iss_valid), .iss_ready_o(iss_ready), .iss_cls_i(iss_cls), .iss_warp_i(iss_warp), .iss_tag_i(iss_tag),
      .iss_mask_i(iss_mask), .iss_use1_i(iss_use1), .iss_use2_i(iss_use2), .iss_rs1_i(iss_rs1), .iss_rs2_i(iss_rs2),
      .iss_wr_i(iss_wr), .iss_rd_i(iss_rd), .iss_payload_i(iss_payload),
      .dsp_valid_o(dsp_valid), .dsp_ready_i(dsp_ready), .dsp_warp_o(dsp_warp), .dsp_tag_o(dsp_tag), .dsp_mask_o(dsp_mask),
      .dsp_wr_o(dsp_wr), .dsp_rd_o(dsp_rd), .dsp_payload_o(dsp_payload), .dsp_op1_o(dsp_op1), .dsp_op2_o(dsp_op2),
      .wb_valid_i(wb_valid), .wb_ready_o(wb_ready), .wb_warp_i(wb_warp), .wb_tag_i(wb_tag), .wb_we_i(wb_we),
      .wb_rd_i(wb_rd), .wb_mask_i(wb_mask), .wb_data_i(wb_data), .wb_aux_i(wb_aux),
      .cmpl_valid_o(cmpl_valid), .cmpl_warp_o(cmpl_warp), .cmpl_tag_o(cmpl_tag), .cmpl_aux_o(cmpl_aux),
      .perf_clear_i(1'b0), .perf_o(perf), .mon_alloc_o(mon_alloc), .mon_req_o(mon_req), .mon_gnt_o(mon_gnt),
      .mon_rq_warp_o(mon_rq_warp), .mon_rq_reg_o(mon_rq_reg), .mon_dsp_cu_o(mon_dsp_cu));
  end else begin : g_dut
    sf_rf_base #(.NUM_WARPS(NUM_WARPS), .LANES(LANES), .NUM_CU(NUM_CU), .NUM_CLS(NUM_CLS), .NUM_WB(NUM_WB),
                 .TAG_W(TAG_W), .PAYLOAD_W(PAYLOAD_W), .AUX_W(AUX_W), .RAM_STYLE(RAM_STYLE), .PERF_EN(1'b1), .WRITE_THROUGH(WRITE_THROUGH)) dut (
      .clk, .rst_n, .clr_all_i(clr_all), .clr_warp_i(clr_warp), .idle_o(idle),
      .iss_valid_i(iss_valid), .iss_ready_o(iss_ready), .iss_cls_i(iss_cls), .iss_warp_i(iss_warp), .iss_tag_i(iss_tag),
      .iss_mask_i(iss_mask), .iss_use1_i(iss_use1), .iss_use2_i(iss_use2), .iss_rs1_i(iss_rs1), .iss_rs2_i(iss_rs2),
      .iss_wr_i(iss_wr), .iss_rd_i(iss_rd), .iss_payload_i(iss_payload),
      .dsp_valid_o(dsp_valid), .dsp_ready_i(dsp_ready), .dsp_warp_o(dsp_warp), .dsp_tag_o(dsp_tag), .dsp_mask_o(dsp_mask),
      .dsp_wr_o(dsp_wr), .dsp_rd_o(dsp_rd), .dsp_payload_o(dsp_payload), .dsp_op1_o(dsp_op1), .dsp_op2_o(dsp_op2),
      .wb_valid_i(wb_valid), .wb_ready_o(wb_ready), .wb_warp_i(wb_warp), .wb_tag_i(wb_tag), .wb_we_i(wb_we),
      .wb_rd_i(wb_rd), .wb_mask_i(wb_mask), .wb_data_i(wb_data), .wb_aux_i(wb_aux),
      .cmpl_valid_o(cmpl_valid), .cmpl_warp_o(cmpl_warp), .cmpl_tag_o(cmpl_tag), .cmpl_aux_o(cmpl_aux),
      .perf_clear_i(1'b0), .perf_o(perf), .mon_alloc_o(mon_alloc), .mon_req_o(mon_req), .mon_gnt_o(mon_gnt),
      .mon_rq_warp_o(mon_rq_warp), .mon_rq_reg_o(mon_rq_reg), .mon_dsp_cu_o(mon_dsp_cu));
  end

  // ------------------------------------------------------------------ run configuration (plusargs)
  string trace_path, exp_path;
  int    seed, fetch_gap, alu_lat, alu_jit, mem_lat, mem_jit, wb_idle_pct;
  int    dsp_pct [NUM_CLS];
  int    stall_cls, stall_start, stall_len, stall_period;
  int    wbstall_start, wbstall_len, wbstall_period;
  int    reset_at, reset_len, max_cycles, dump_lat;
  string tag_name;

  // ------------------------------------------------------------------ trace storage
  int           n_instr, t_lanes, t_warps;
  int           wbase [NUM_WARPS];
  int           wcnt  [NUM_WARPS];
  int           i_warp [], i_cls [], i_fn [], i_op [], i_use1 [], i_rs1 [], i_use2 [], i_rs2 [], i_wr [], i_rd [];
  logic [31:0]  i_imm [];
  logic [LANES-1:0] i_mask [];
  logic [W-1:0] e_op1 [], e_op2 [], e_res [];
  logic [LANES-1:0] e_taken [];
  int           issue_cyc [], disp_cyc [], tag_of [], i_nreads [];
  bit           d_done [];

  initial begin
    int fd, g, c, n;
    int a[13];
    logic [31:0] m, imm;
    logic [W-1:0] o1, o2, rs;
    logic [LANES-1:0] tk;
    string line;
    if (!$value$plusargs("trace=%s", trace_path)) begin $display("FAIL: +trace= missing"); $finish; end
    if (!$value$plusargs("exp=%s", exp_path))     begin $display("FAIL: +exp= missing");   $finish; end
    if (!$value$plusargs("seed=%d", seed))               seed = 1;
    if (!$value$plusargs("fetch_gap=%d", fetch_gap))     fetch_gap = 2;
    if (!$value$plusargs("alu_lat=%d", alu_lat))         alu_lat = 2;
    if (!$value$plusargs("alu_jit=%d", alu_jit))         alu_jit = 2;
    if (!$value$plusargs("mem_lat=%d", mem_lat))         mem_lat = 8;
    if (!$value$plusargs("mem_jit=%d", mem_jit))         mem_jit = 6;
    if (!$value$plusargs("wb_idle_pct=%d", wb_idle_pct)) wb_idle_pct = 0;
    if (!$value$plusargs("dsp_pct0=%d", dsp_pct[0]))     dsp_pct[0] = 100;
    if (!$value$plusargs("dsp_pct1=%d", dsp_pct[1]))     dsp_pct[1] = 100;
    if (!$value$plusargs("stall_cls=%d", stall_cls))     stall_cls = -1;
    if (!$value$plusargs("stall_start=%d", stall_start)) stall_start = 0;
    if (!$value$plusargs("stall_len=%d", stall_len))     stall_len = 0;
    if (!$value$plusargs("stall_period=%d", stall_period)) stall_period = 0;
    if (!$value$plusargs("reset_at=%d", reset_at))       reset_at = -1;
    if (!$value$plusargs("reset_len=%d", reset_len))     reset_len = 3;
    if (!$value$plusargs("max_cycles=%d", max_cycles))   max_cycles = 2000000;
    if (!$value$plusargs("name=%s", tag_name))           tag_name = "run";
    void'($urandom(seed));

    fd = $fopen(trace_path, "r");
    if (fd == 0) begin $display("FAIL: cannot open %s", trace_path); $finish; end
    n = $fscanf(fd, "%d %d %d\n", t_lanes, t_warps, n_instr);
    if (t_lanes != LANES || t_warps > NUM_WARPS) begin
      $display("FAIL: trace lanes=%0d warps=%0d does not fit LANES=%0d NUM_WARPS=%0d", t_lanes, t_warps, LANES, NUM_WARPS);
      $finish;
    end
    for (int w = 0; w < NUM_WARPS; w++) wcnt[w] = 0;
    for (int w = 0; w < t_warps; w++) n = $fscanf(fd, "%d", wcnt[w]);
    wbase[0] = 0;
    for (int w = 1; w < NUM_WARPS; w++) wbase[w] = wbase[w-1] + wcnt[w-1];
    i_warp = new[n_instr]; i_cls = new[n_instr]; i_fn = new[n_instr]; i_op = new[n_instr];
    i_use1 = new[n_instr]; i_rs1 = new[n_instr]; i_use2 = new[n_instr]; i_rs2 = new[n_instr];
    i_wr = new[n_instr]; i_rd = new[n_instr]; i_imm = new[n_instr]; i_mask = new[n_instr];
    e_op1 = new[n_instr]; e_op2 = new[n_instr]; e_res = new[n_instr]; e_taken = new[n_instr];
    issue_cyc = new[n_instr]; disp_cyc = new[n_instr]; tag_of = new[n_instr]; d_done = new[n_instr]; i_nreads = new[n_instr];
    for (int k = 0; k < n_instr; k++) begin
      n = $fscanf(fd, "%d %d %d %d %d %d %d %d %d %d %d %h %h\n",
                  a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], m, imm);
      g = a[0];
      i_warp[g] = a[1]; i_cls[g] = a[2]; i_fn[g] = a[3]; i_op[g] = a[4]; i_use1[g] = a[5]; i_rs1[g] = a[6];
      i_use2[g] = a[7]; i_rs2[g] = a[8]; i_wr[g] = a[9]; i_rd[g] = a[10]; i_mask[g] = m[LANES-1:0]; i_imm[g] = imm;
      // register reads this instruction needs (r0, unused slots, duplicates and empty masks excluded)
      i_nreads[g] = 0;
      if (m[LANES-1:0] != '0) begin
        if (a[5] != 0 && a[6] != 0) i_nreads[g]++;
        if (a[7] != 0 && a[8] != 0 && !(a[5] != 0 && a[6] == a[8] && DUT_KIND == 0)) i_nreads[g]++;
      end
    end
    $fclose(fd);
    fd = $fopen(exp_path, "r");
    if (fd == 0) begin $display("FAIL: cannot open %s", exp_path); $finish; end
    for (int k = 0; k < n_instr; k++) begin
      n = $fscanf(fd, "%d %h %h %h %h\n", g, o1, o2, rs, tk);
      e_op1[g] = o1; e_op2[g] = o2; e_res[g] = rs; e_taken[g] = tk;
    end
    $fclose(fd);
  end

  // ------------------------------------------------------------------ front-end model state (updated with NBAs)
  int           cyc;
  int           w_next [NUM_WARPS];
  logic [31:0]  w_pend [NUM_WARPS];
  int           w_gap  [NUM_WARPS];
  logic         w_brw  [NUM_WARPS];
  int           w_infl [NUM_WARPS];
  logic         slot_v [NUM_WARPS][SLOTS];
  int           slot_gid [NUM_WARPS][SLOTS];
  int           rr_ptr;
  logic         issuing_en;

  // ------------------------------------------------------------------ issue selection (combinational)
  int   sel_w, sel_g, sel_s;
  logic cand_blocked;                       // a hazard-free candidate existed but the DUT was not ready

  always_comb begin
    sel_w = -1; sel_g = 0; sel_s = 0; cand_blocked = 1'b0;
    iss_valid = 1'b0; iss_cls = '0; iss_warp = '0; iss_tag = '0; iss_mask = '0; iss_use1 = 1'b0; iss_use2 = 1'b0;
    iss_rs1 = '0; iss_rs2 = '0; iss_wr = 1'b0; iss_rd = '0; iss_payload = '0;
    if (rst_n && issuing_en && n_instr > 0) begin
      for (int k = 0; k < NUM_WARPS; k++) begin
        int w, g, s;
        bit ok;
        w = (rr_ptr + k) % NUM_WARPS;
        if (sel_w < 0 && w_next[w] < wcnt[w] && w_gap[w] == 0 && !w_brw[w] && w_infl[w] < SLOTS) begin
          g  = wbase[w] + w_next[w];
          ok = 1'b1;
          if (i_use1[g] != 0 && i_rs1[g] != 0 && w_pend[w][i_rs1[g]]) ok = 1'b0;
          if (i_use2[g] != 0 && i_rs2[g] != 0 && w_pend[w][i_rs2[g]]) ok = 1'b0;
          if (i_wr[g]   != 0 && i_rd[g]  != 0 && w_pend[w][i_rd[g]])  ok = 1'b0;
          if (ok && !iss_ready[i_cls[g]]) begin ok = 1'b0; cand_blocked = 1'b1; end
          if (ok) begin
            s = 0;
            for (int q = SLOTS - 1; q >= 0; q--) if (!slot_v[w][q]) s = q;
            sel_w = w; sel_g = g; sel_s = s;
          end
        end
      end
      if (sel_w >= 0) begin
        iss_valid   = 1'b1;
        iss_cls     = CLS_W'(i_cls[sel_g]);
        iss_warp    = WARP_W'(sel_w);
        iss_tag     = TAG_W'(sel_s);
        iss_mask    = i_mask[sel_g];
        iss_use1    = (i_use1[sel_g] != 0);
        iss_use2    = (i_use2[sel_g] != 0);
        iss_rs1     = 5'(i_rs1[sel_g]);
        iss_rs2     = 5'(i_rs2[sel_g]);
        iss_wr      = (i_wr[sel_g] != 0);
        iss_rd      = 5'(i_rd[sel_g]);
        iss_payload = PAYLOAD_W'(sel_g);
      end
    end
  end

  // ------------------------------------------------------------------ backend model state
  bit           bq_v    [BQ];
  int           bq_gid  [BQ];
  int           bq_cls  [BQ];
  int           bq_rdy  [BQ];
  logic [W-1:0] bq_res  [BQ];
  logic [LANES-1:0] bq_aux [BQ];
  bit           wb_cur_v [NUM_WB];
  int           wb_cur_g [NUM_WB];
  int           w_dnext [NUM_WARPS];
  bit           prev_stall [NUM_CLS];
  logic [PAYLOAD_W-1:0] prev_pay [NUM_CLS];
  logic [W-1:0] prev_o1 [NUM_CLS], prev_o2 [NUM_CLS];
  logic [LANES-1:0] prev_mk [NUM_CLS];

  // ------------------------------------------------------------------ statistics
  longint unsigned st_issue_first, st_cycles, st_lat_sum, st_lat_n;
  int           st_lat_max;
  longint unsigned st_wait_sum, st_whist [16];
  longint unsigned st_hist [16];
  longint unsigned st_cand_blocked, st_issue_cyc, st_wb_stall [NUM_WB], st_dsp_stall [NUM_CLS];
  longint unsigned st_conf_tb, st_req_tb, st_gnt_tb;
  int           completed, dispatched, errors, inflight_at_reset, resets;
  bit           done;
  longint unsigned st_cls_cnt [2];
  longint unsigned st_wr_acc, st_stall_other, st_stall_cyc;

  task automatic err(input string msg);
    errors++;
    if (errors <= 12) $display("[%0t cyc %0d] ERROR: %s", $time, cyc, msg);
  endtask

  // ------------------------------------------------------------------ sequential model
  int  gap_n [NUM_WARPS], infl_n [NUM_WARPS], next_n [NUM_WARPS], dnext_n [NUM_WARPS];
  logic [31:0] pend_n [NUM_WARPS];
  logic brw_n [NUM_WARPS];
  logic slotv_n [NUM_WARPS][SLOTS];
  int  slotg_n [NUM_WARPS][SLOTS];
  int  rr_n;
  logic [NUM_CLS-1:0] rdy_n;
  bit  wbv_n [NUM_WB];
  int  rst_cnt = 0;
  bit  reset_done = 1'b0;

  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (cyc >= max_cycles && !done) begin
      $display("FAIL: timeout at cycle %0d (completed %0d of %0d, dispatched %0d)", cyc, completed, n_instr, dispatched);
      $display("RESULT name=%s status=TIMEOUT", tag_name);
      done = 1'b1;
      $finish;
    end
  end

  initial begin
    cyc = 0; done = 1'b0; errors = 0; completed = 0; dispatched = 0; resets = 0; inflight_at_reset = 0;
    rr_ptr = 0; issuing_en = 1'b0;
    for (int w = 0; w < NUM_WARPS; w++) begin
      w_next[w] = 0; w_pend[w] = '0; w_gap[w] = 0; w_brw[w] = 1'b0; w_infl[w] = 0; w_dnext[w] = 0;
      for (int s = 0; s < SLOTS; s++) begin slot_v[w][s] = 1'b0; slot_gid[w][s] = 0; end
    end
    for (int q = 0; q < BQ; q++) bq_v[q] = 1'b0;
    for (int p = 0; p < NUM_WB; p++) begin wb_cur_v[p] = 1'b0; wb_cur_g[p] = 0; wb_valid[p] = 1'b0; end
    dsp_ready = '0;
    for (int p = 0; p < NUM_CLS; p++) prev_stall[p] = 1'b0;
    st_issue_first = 0; st_cycles = 0; st_lat_sum = 0; st_lat_n = 0; st_lat_max = 0; st_wait_sum = 0;
    for (int i = 0; i < 16; i++) st_whist[i] = 0;
    for (int i = 0; i < 16; i++) st_hist[i] = 0;
    st_wr_acc = 0; st_stall_other = 0; st_stall_cyc = 0;
    st_cand_blocked = 0; st_issue_cyc = 0; st_conf_tb = 0; st_req_tb = 0; st_gnt_tb = 0;
    for (int p = 0; p < NUM_WB; p++) st_wb_stall[p] = 0;
    for (int p = 0; p < NUM_CLS; p++) begin st_dsp_stall[p] = 0; st_cls_cnt[p] = 0; end
  end

  // release reset after a few cycles; optional mid-run reset pulse (all state must restart cleanly)
  always @(posedge clk) begin
    if (cyc == 5) begin rst_n <= 1'b1; issuing_en <= 1'b1; end
    if (reset_at >= 0 && cyc == reset_at && !reset_done && completed < n_instr) begin
      reset_done = 1'b1;
      resets++;
      inflight_at_reset = 0;
      for (int w = 0; w < NUM_WARPS; w++) inflight_at_reset += w_infl[w];
      rst_n <= 1'b0;
      rst_cnt = reset_len;
    end else if (rst_cnt > 0) begin
      rst_cnt--;
      if (rst_cnt == 0) rst_n <= 1'b1;
    end
  end

  always @(posedge clk) begin
    int g, w, s, p, lat, pick, best, dcls;
    logic [W-1:0] res_row;
    logic [LANES-1:0] tk;
    logic [31:0] a_v, b_v;

    if (!rst_n) begin
      // ---- reset: flush the whole model; the trace restarts from its first instruction
      for (w = 0; w < NUM_WARPS; w++) begin
        w_next[w] <= 0; w_pend[w] <= '0; w_gap[w] <= 0; w_brw[w] <= 1'b0; w_infl[w] <= 0; w_dnext[w] <= 0;
        for (s = 0; s < SLOTS; s++) slot_v[w][s] <= 1'b0;
      end
      for (int q = 0; q < BQ; q++) bq_v[q] = 1'b0;
      for (p = 0; p < NUM_WB; p++) begin wb_cur_v[p] = 1'b0; wb_valid[p] <= 1'b0; end
      dsp_ready <= '0;
      for (p = 0; p < NUM_CLS; p++) prev_stall[p] = 1'b0;
      rr_ptr <= 0;
      for (int k = 0; k < n_instr; k++) d_done[k] = 1'b0;
      completed = 0; dispatched = 0;
      // the DUT's counters clear with reset: restart every independent statistic with it
      st_issue_first = 0; st_cycles = 0; st_lat_sum = 0; st_lat_n = 0; st_lat_max = 0; st_wait_sum = 0;
      for (int i = 0; i < 16; i++) begin st_hist[i] = 0; st_whist[i] = 0; end
      st_cand_blocked = 0; st_issue_cyc = 0; st_conf_tb = 0; st_req_tb = 0; st_gnt_tb = 0;
      st_wr_acc = 0; st_stall_other = 0; st_stall_cyc = 0;
      for (p = 0; p < NUM_WB; p++) st_wb_stall[p] = 0;
      for (p = 0; p < NUM_CLS; p++) begin st_dsp_stall[p] = 0; st_cls_cnt[p] = 0; end
    end else if (n_instr > 0) begin
      // ---- next-state copies
      for (w = 0; w < NUM_WARPS; w++) begin
        gap_n[w] = (w_gap[w] > 0) ? w_gap[w] - 1 : 0;
        infl_n[w] = w_infl[w]; next_n[w] = w_next[w]; dnext_n[w] = w_dnext[w];
        pend_n[w] = w_pend[w]; brw_n[w] = w_brw[w];
        for (s = 0; s < SLOTS; s++) begin slotv_n[w][s] = slot_v[w][s]; slotg_n[w][s] = slot_gid[w][s]; end
      end
      rr_n = rr_ptr;

      // ---- cycle accounting
      if (completed < n_instr) st_cycles++;
      if (cand_blocked && sel_w < 0) st_cand_blocked++;   // wanted to issue, DUT not ready, nothing else issued
      st_req_tb  += $countones(mon_req);
      st_gnt_tb  += $countones(mon_gnt);
      st_conf_tb += $countones(mon_req & ~mon_gnt);

      // ---- completions (cycle c) -> scoreboard clear visible in c+1
      for (p = 0; p < NUM_WB; p++) begin
        if (cmpl_valid[p] !== (wb_valid[p] & wb_ready[p])) err($sformatf("cmpl_valid[%0d] != wb_valid&wb_ready", p));
        if (wb_valid[p] && wb_ready[p]) begin
          g = wb_cur_g[p];
          if (cmpl_warp[p] !== wb_warp[p] || cmpl_tag[p] !== wb_tag[p] || cmpl_aux[p] !== wb_aux[p])
            err($sformatf("completion record differs from the accepted writeback record (port %0d)", p));
          w = int'(cmpl_warp[p]); s = int'(cmpl_tag[p]);
          if (w >= NUM_WARPS || s >= SLOTS || !slot_v[w][s] || slot_gid[w][s] != g) begin
            err($sformatf("completion for unknown/foreign slot w%0d s%0d (gid %0d)", w, s, g));
          end else begin
            slotv_n[w][s] = 1'b0;
            infl_n[w]--;
            if (i_wr[g] != 0 && i_rd[g] != 0) pend_n[w][i_rd[g]] = 1'b0;
            if (i_fn[g] == FN_BR) brw_n[w] = 1'b0;
            completed++;
          end
          if (wb_we[p] && wb_rd[p] != 5'd0 && wb_mask[p] != '0) st_wr_acc++;
          wb_cur_v[p] = 1'b0;
        end else if (wb_valid[p] && !wb_ready[p]) begin
          st_wb_stall[p]++;
        end
      end

      // ---- is the configured stall window active in this cycle?
      if (stall_cls >= 0 && stall_len > 0 && completed < n_instr) begin
        if (stall_period > 0 ? (((cyc % stall_period) >= stall_start) && ((cyc % stall_period) < stall_start + stall_len))
                             : ((cyc >= stall_start) && (cyc < stall_start + stall_len))) begin
          st_stall_cyc++;
          if (stall_cls < 2 && dsp_valid[1 - stall_cls] && dsp_ready[1 - stall_cls]) st_stall_other++;
        end
      end
      // ---- dispatch accept (cycle c): check, then run the "execution unit"
      for (p = 0; p < NUM_CLS; p++) begin
        if (dsp_valid[p] && !dsp_ready[p]) st_dsp_stall[p]++;
        // ready/valid contract: once valid is raised the record must stay put until it is accepted
        if (prev_stall[p]) begin
          if (!dsp_valid[p]) err($sformatf("dispatch class %0d: valid retracted before acceptance", p));
          else if (dsp_payload[p] !== prev_pay[p] || dsp_op1[p] !== prev_o1[p] || dsp_op2[p] !== prev_o2[p] || dsp_mask[p] !== prev_mk[p])
            err($sformatf("dispatch class %0d: payload changed while stalled (g%0d -> g%0d)", p, prev_pay[p], dsp_payload[p]));
        end
        prev_stall[p] = dsp_valid[p] && !dsp_ready[p];
        prev_pay[p] = dsp_payload[p]; prev_o1[p] = dsp_op1[p]; prev_o2[p] = dsp_op2[p]; prev_mk[p] = dsp_mask[p];
        if (dsp_valid[p] && dsp_ready[p]) begin
          g = int'(dsp_payload[p]);
          if (g < 0 || g >= n_instr) begin
            err($sformatf("dispatch with bad payload %0d", g));
          end else begin
            w = i_warp[g];
            if (d_done[g]) err($sformatf("instruction %0d dispatched twice", g));
            d_done[g] = 1'b1;
            if (g != wbase[w] + w_dnext[w])
              err($sformatf("warp %0d dispatch out of program order: got local %0d expected %0d", w, g - wbase[w], w_dnext[w]));
            dnext_n[w] = g - wbase[w] + 1;
            if (int'(dsp_warp[p]) != w)                      err($sformatf("g%0d: wrong warp %0d != %0d", g, dsp_warp[p], w));
            if (int'(dsp_tag[p]) != tag_of[g])               err($sformatf("g%0d: wrong tag %0d != %0d", g, dsp_tag[p], tag_of[g]));
            if (dsp_mask[p] !== i_mask[g])                   err($sformatf("g%0d: wrong mask %h != %h", g, dsp_mask[p], i_mask[g]));
            if (p != i_cls[g])                               err($sformatf("g%0d: dispatched on class %0d, expected %0d", g, p, i_cls[g]));
            if ((dsp_wr[p] ? 1 : 0) != i_wr[g])              err($sformatf("g%0d: wrong wr flag", g));
            if (i_wr[g] != 0 && int'(dsp_rd[p]) != i_rd[g])  err($sformatf("g%0d: wrong rd %0d != %0d", g, dsp_rd[p], i_rd[g]));
            if (dsp_op1[p] !== e_op1[g])
              err($sformatf("g%0d (w%0d fn%0d rs1=r%0d): OPERAND 1 MISMATCH got %h exp %h", g, w, i_fn[g], i_rs1[g], dsp_op1[p], e_op1[g]));
            if (dsp_op2[p] !== e_op2[g])
              err($sformatf("g%0d (w%0d fn%0d rs2=r%0d): OPERAND 2 MISMATCH got %h exp %h", g, w, i_fn[g], i_rs2[g], dsp_op2[p], e_op2[g]));
            disp_cyc[g] = cyc;
            lat = cyc - issue_cyc[g];
            st_lat_sum += lat; st_lat_n++;
            if (lat > st_lat_max) st_lat_max = lat;
            st_hist[(lat > 15) ? 15 : lat]++;
            // wait beyond this instruction's own conflict-free pipeline minimum
            begin
              int minl, wx;
              minl = (DUT_KIND == 1) ? 2 : ((i_nreads[g] == 0) ? 1 : (FAST_READ ? 2 : 3));
              wx = lat - minl;
              if (wx < 0) err($sformatf("g%0d: dispatched faster (%0d) than the pipeline minimum (%0d)", g, lat, minl));
              st_wait_sum += (wx < 0) ? 0 : wx;
              st_whist[(wx > 15) ? 15 : ((wx < 0) ? 0 : wx)]++;
            end
            st_cls_cnt[p]++;
            dispatched++;
            // execution: result from the operands the DUT delivered (errors propagate)
            for (int l = 0; l < LANES; l++) begin
              a_v = dsp_op1[p][l*32 +: 32]; b_v = dsp_op2[p][l*32 +: 32];
              res_row[l*32 +: 32] = f_lane(i_fn[g], i_op[g], a_v, b_v, i_imm[g], w, l);
              tk[l] = (i_fn[g] == FN_BR) ? taken_bit(a_v, i_imm[g], l) & i_mask[g][l] : 1'b0;
            end
            lat = (p == 0) ? alu_lat + ((alu_jit > 0) ? $urandom_range(0, alu_jit) : 0)
                           : mem_lat + ((mem_jit > 0) ? $urandom_range(0, mem_jit) : 0);
            pick = -1;
            for (int q = 0; q < BQ; q++) if (!bq_v[q] && pick < 0) pick = q;
            if (pick < 0) err("backend queue overflow");
            else begin
              bq_v[pick] = 1'b1; bq_gid[pick] = g; bq_cls[pick] = p; bq_rdy[pick] = cyc + lat; bq_res[pick] = res_row; bq_aux[pick] = tk;
            end
          end
        end
      end

      // ---- writeback offers (registered): hold until accepted; otherwise pick the oldest ready record of this port
      for (p = 0; p < NUM_WB; p++) begin
        wbv_n[p] = wb_cur_v[p];
        if (!wb_cur_v[p]) begin
          best = -1;
          for (int q = 0; q < BQ; q++)
            if (bq_v[q] && bq_cls[q] == p && bq_rdy[q] <= cyc + 1 &&
                (best < 0 || bq_rdy[q] < bq_rdy[best] || (bq_rdy[q] == bq_rdy[best] && bq_gid[q] < bq_gid[best]))) best = q;
          // optional bubbles / stall window on the writeback producers
          if (best >= 0 && !(wb_idle_pct > 0 && $urandom_range(0, 99) < wb_idle_pct)) begin
            g = bq_gid[best];
            wb_cur_v[p] = 1'b1; wb_cur_g[p] = g; wbv_n[p] = 1'b1;
            wb_warp[p] <= WARP_W'(i_warp[g]);
            wb_tag[p]  <= TAG_W'(tag_of[g]);
            wb_we[p]   <= (i_wr[g] != 0) && fn_has_result(i_fn[g]);
            wb_rd[p]   <= 5'(i_rd[g]);
            wb_mask[p] <= i_mask[g];
            wb_data[p] <= bq_res[best];
            wb_aux[p]  <= bq_aux[best];
            if (bq_res[best] !== e_res[g] && fn_has_result(i_fn[g]))
              err($sformatf("g%0d: result computed from delivered operands differs from the model (res %h exp %h)", g, bq_res[best], e_res[g]));
            if (i_fn[g] == FN_BR && bq_aux[best] !== e_taken[g])
              err($sformatf("g%0d: branch taken mask differs from the model", g));
            bq_v[best] = 1'b0;
          end
        end
        wb_valid[p] <= wbv_n[p];
      end

      // ---- issue fire (cycle c)
      if (iss_valid && iss_ready[iss_cls]) begin
        w = sel_w; g = sel_g; s = sel_s;
        slotv_n[w][s] = 1'b1; slotg_n[w][s] = g;
        tag_of[g] = s;
        issue_cyc[g] = cyc;
        if (i_wr[g] != 0 && i_rd[g] != 0) pend_n[w][i_rd[g]] = 1'b1;
        infl_n[w]++;
        next_n[w]++;
        gap_n[w] = fetch_gap;
        if (i_fn[g] == FN_BR) brw_n[w] = 1'b1;
        rr_n = (w + 1) % NUM_WARPS;
        st_issue_cyc++;
        if (st_issue_first == 0) st_issue_first = cyc;
      end

      // ---- backend ready pattern for the next cycle (prolonged stall windows + random back-pressure)
      for (p = 0; p < NUM_CLS; p++) begin
        rdy_n[p] = ($urandom_range(0, 99) < dsp_pct[p]);
        if ((stall_cls == p || stall_cls == 2) && stall_len > 0) begin     // stall_cls 2 = both ports
          if (stall_period > 0) begin
            if (((cyc + 1) % stall_period) >= stall_start && ((cyc + 1) % stall_period) < stall_start + stall_len) rdy_n[p] = 1'b0;
          end else if ((cyc + 1) >= stall_start && (cyc + 1) < stall_start + stall_len) rdy_n[p] = 1'b0;
        end
      end
      dsp_ready <= rdy_n;

      // ---- commit model state
      for (w = 0; w < NUM_WARPS; w++) begin
        w_gap[w] <= gap_n[w]; w_infl[w] <= infl_n[w]; w_next[w] <= next_n[w]; w_dnext[w] <= dnext_n[w];
        w_pend[w] <= pend_n[w]; w_brw[w] <= brw_n[w];
        for (s = 0; s < SLOTS; s++) begin slot_v[w][s] <= slotv_n[w][s]; slot_gid[w][s] <= slotg_n[w][s]; end
      end
      rr_ptr <= rr_n;

      // ---- finish
      if (completed == n_instr && !done) begin
        done = 1'b1;
        finish_run();
      end
    end
  end

  // ------------------------------------------------------------------ end of run
  task automatic finish_run();
    longint unsigned wb_st, ds_st;
    bit ok;
    string st;
    wb_st = 0; ds_st = 0;
    for (int p = 0; p < NUM_WB; p++) wb_st += st_wb_stall[p];
    for (int p = 0; p < NUM_CLS; p++) ds_st += st_dsp_stall[p];
    ok = (errors == 0);
    if (DUT_KIND == 0 && st_conf_tb != perf[PERF_RD_CONFLICT]) begin
      $display("ERROR: read-conflict counter mismatch: RTL %0d, testbench recount %0d", perf[PERF_RD_CONFLICT], st_conf_tb);
      ok = 1'b0;
    end
    if (perf[PERF_WB_STALL] != wb_st) begin
      $display("ERROR: writeback-stall counter mismatch: RTL %0d, testbench %0d", perf[PERF_WB_STALL], wb_st);
      ok = 1'b0;
    end
    if (perf[PERF_DSP_STALL] != ds_st) begin
      $display("ERROR: dispatch-stall counter mismatch: RTL %0d, testbench %0d", perf[PERF_DSP_STALL], ds_st);
      ok = 1'b0;
    end
    if (perf[PERF_WB_ACCEPT] != st_wr_acc) begin
      $display("ERROR: accepted-write counter mismatch: RTL %0d, testbench %0d", perf[PERF_WB_ACCEPT], st_wr_acc);
      ok = 1'b0;
    end
    if (perf[PERF_DISPATCH] != n_instr || perf[PERF_ALLOC] != n_instr) begin
      $display("ERROR: alloc/dispatch counters %0d/%0d != instructions %0d", perf[PERF_ALLOC], perf[PERF_DISPATCH], n_instr);
      ok = 1'b0;
    end
    st = ok ? "OK" : "ERR";
    $write("RESULT name=%s dut=%0d status=%s instr=%0d cycles=%0d ipc=%f lat_mean=%f lat_max=%0d lat_n=%0d",
           tag_name, DUT_KIND, st, n_instr, st_cycles, real'(n_instr) / real'(st_cycles),
           real'(st_lat_sum) / real'(st_lat_n), st_lat_max, st_lat_n);
    $write(" cand_blocked=%0d issue_cyc=%0d wb_stall=%0d dsp_stall=%0d resets=%0d inflight_at_reset=%0d",
           st_cand_blocked, st_issue_cyc, wb_st, ds_st, resets, inflight_at_reset);
    $write(" tb_rd_req=%0d tb_rd_gnt=%0d tb_rd_conf=%0d", st_req_tb, st_gnt_tb, st_conf_tb);
    $write(" wr_acc=%0d stall_cyc=%0d stall_other_disp=%0d wait_sum=%0d", st_wr_acc, st_stall_cyc, st_stall_other, st_wait_sum);
    $write(" whist=");
    for (int i = 0; i < 16; i++) $write("%0d%s", st_whist[i], (i == 15) ? "" : ",");
    for (int i = 0; i < PERF_N; i++) $write(" p%0d=%0d", i, perf[i]);
    $write(" hist=");
    for (int i = 0; i < 16; i++) $write("%0d%s", st_hist[i], (i == 15) ? "" : ",");
    $write("\n");
    if (ok) $display("PASS"); else $display("FAIL errors=%0d", errors);
    $finish;
  endtask
endmodule
`default_nettype wire
