import subprocess, shutil, os, sys
R = "../rtl"
src = open(f"{R}/sf_rfc_bank.sv").read()
muts = {
 "drop landing-edge overlay (f_v)":      ("(f_v  & f_mask[l])   ? f_data[l*32 +: 32]   : base", "base"),
 "drop staged-write overlay (a_hit)":    ("(a_hit & stg_mask[l]) ? stg_data[l*32 +: 32] : v1", "v1"),
 "ignore clean bit on read":             ("q_clean ? 32'd0 : ram_q[l*32 +: 32]", "ram_q[l*32 +: 32]"),
 "no zero-fill on first partial write":  ("(stg_mask[l] | land_clean)", "(stg_mask[l])"),
 "overlay ignores lane mask (f)":        ("(f_v  & f_mask[l])", "(f_v)"),
 "overlay ignores lane mask (a)":        ("(a_hit & stg_mask[l])", "(a_hit)"),
 "landing does not clear clean bit":     ("if (stg_v) clean[stg_row] <= 1'b0;", ""),
 "f_v compares wrong row":               ("f_v     <= stg_v & (stg_row == rd_row);", "f_v     <= stg_v & (stg_row == q_row);"),
}
for name,(a,b) in muts.items():
    assert a in src, name
    d = "mut"; shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
    open(f"{d}/bank.sv","w").write(src.replace(a,b,1))
    r = subprocess.run(["verilator-cli","--binary","--timing","-Wno-fatal","-Wno-lint","-Wno-style","-Wno-PROCASSINIT","--x-initial","unique",
        f"{R}/sf_rfc_pkg.sv",f"{R}/sf_rfc_ram.sv",f"{d}/bank.sv","../tb/tb_rfc_bank.sv","--top-module","tb_rfc_bank","-Mdir",f"{d}/obj"],capture_output=True,text=True)
    if r.returncode: print("BUILD FAIL", name, r.stderr[-300:]); continue
    o = subprocess.run([f"{d}/obj/Vtb_rfc_bank","+seed=1","+verilator+rand+reset+2"],capture_output=True,text=True).stdout
    print(("CAUGHT  " if "FAIL" in o else "MISSED  ") + name)
