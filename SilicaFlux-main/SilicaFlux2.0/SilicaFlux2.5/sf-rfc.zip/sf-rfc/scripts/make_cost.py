#!/usr/bin/env python3
"""Join results/synth.json (Yosys utilisation, nextpnr timing) with results/compare.json (throughput) into results/cost.md:
what each throughput point costs in FPGA fabric.  Run after run_compare.py and synth.py."""
import json
import math
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
S = json.load(open(os.path.join(ROOT, "results", "synth.json")))
C = json.load(open(os.path.join(ROOT, "results", "compare.json")))
ALL = ["uni_mixed", "uni_full", "loopy", "hammer8", "hammer4", "dep1", "dep8", "ldburst", "memstall", "simt_dir", "simt_rand"]
REAL = ["simt_dir", "simt_rand"]


def gm(xs):
    return math.exp(sum(math.log(x) for x in xs) / len(xs))


R = {r["name"]: r for r in C["results"]}


def ipc(name, prof, ts):
    return gm([R[name]["runs"][f"{prof}|{t}"]["ipc"] for t in ts])


def rel(name, prof, ts):
    return 100 * (ipc(name, prof, ts) / ipc("baseline", prof, ts) - 1)


def x7(tag):
    c = next(r for r in S["synth"] if r["tag"] == tag and r["fam"] == "xc7")["cells"]
    lut = sum(v for k, v in c.items() if re.fullmatch(r"LUT[1-6]", k))
    ff = sum(v for k, v in c.items() if re.fullmatch(r"FD[CPRS]E", k))
    ramlut = 4 * (c.get("RAM32M", 0) + c.get("RAM64M", 0))
    return dict(lut=lut, ramlut=ramlut, ff=ff, b18=c.get("RAMB18E1", 0) + 2 * c.get("RAMB36E1", 0), carry=c.get("CARRY4", 0))


def ec(tag):
    c = next(r for r in S["synth"] if r["tag"] == tag and r["fam"] == "ecp5")["cells"]
    return dict(lut=c.get("LUT4", 0), ff=c.get("TRELLIS_FF", 0), dpr=c.get("TRELLIS_DPR16X4", 0), bram=c.get("DP16KD", 0))


NAME = {"baseline": "baseline", "banked_default": "B4/XOR/cu6/age/fast", "banked_cu5": "B4/XOR/cu5/age/fast", "banked_cu4": "B4/XOR/cu4/age/fast",
        "banked_cu2": "B4/XOR/cu2/age/fast", "banked_B1": "B1/XOR/cu6/age/fast", "banked_B2": "B2/XOR/cu6/age/fast", "banked_B8": "B8/XOR/cu6/age/fast",
        "banked_nofast": "B4/XOR/cu6/age", "banked_share": "B4/XOR/cu6/age/share/fast"}

L = ["# FPGA cost versus throughput (8 lanes, 8 warps; Yosys 0.71, `PERF_EN=0`)\n",
     "Utilisation = design synthesised standalone. `LUT` excludes LUTs used as RAM (`RAM32M`/`RAM64M`, reported separately as 4 LUT6 each); "
     "`RAMB18` counts 18 Kb blocks. IPC columns are geometric means over the 11 traces of `results/compare.md`, relative to the baseline.\n",
     "| design | LUT | LUT as RAM | FF | RAMB18 | LUT vs baseline | FF vs baseline | IPC typical (all / real) | IPC bursty (all) |", "|---|---|---|---|---|---|---|---|---|"]
b = x7("baseline")
for tag, nm in NAME.items():
    try:
        u = x7(tag)
    except StopIteration:
        continue
    L.append(f"| {tag} | {u['lut']} | {u['ramlut']} | {u['ff']} | {u['b18']} | {(u['lut']+u['ramlut'])/(b['lut']+b['ramlut']):.1f}× | {u['ff']/b['ff']:.1f}× | "
             f"{rel(nm, 'typical', ALL):+.1f}% / {rel(nm, 'typical', REAL):+.1f}% | {rel(nm, 'bursty', ALL):+.1f}% |")
L += ["", "## Same designs, Lattice ECP5 mapping\n", "| design | LUT4 | FF | DPR16X4 (distributed RAM) | DP16KD (block RAM) |", "|---|---|---|---|---|"]
for tag in NAME:
    try:
        u = ec(tag)
    except StopIteration:
        continue
    L.append(f"| {tag} | {u['lut']} | {u['ff']} | {u['dpr']} | {u['bram']} |")

L += ["", "## Options and what they cost (7-series, relative to the default `banked_default`)\n", "| option | LUT | FF | note |", "|---|---|---|---|"]
d = x7("banked_default")
for tag, note in (("banked_wt0", "WRITE_THROUGH=0: removes the same-cycle overlay (unreachable with sf_simt_ctrl); cycle-identical on every scoreboard-legal run"),
                  ("banked_share", "RD_SHARE=1: co-grant comparators; measured hit rate 0.00 %"),
                  ("banked_nofast", "FAST_READ=0: no issue-cycle read attempt; −2.2 % IPC"),
                  ("banked_perf", "PERF_EN=1: the 16 saturating 32-bit counters (instrumentation)"),
                  ("banked_ram_block", "RAM_STYLE=1: block RAM instead of LUTRAM (64-row memories use 12.5 % of a RAMB18)"),
                  ("banked_ram_dist", "RAM_STYLE=2: distributed RAM")):
    try:
        u = x7(tag)
    except StopIteration:
        continue
    L.append(f"| {tag} | {u['lut']-d['lut']:+d} ({100*(u['lut']-d['lut'])/d['lut']:+.0f} %) | {u['ff']-d['ff']:+d} | {note}; RAM LUTs {u['ramlut']}, RAMB18 {u['b18']} |")
for tag, note in (("baseline_ram_dist", "baseline in distributed RAM"), ("baseline_ram_block", "baseline in block RAM")):
    try:
        u = x7(tag)
        L.append(f"| {tag} | {u['lut']} | {u['ff']} | {note}; RAM LUTs {u['ramlut']}, RAMB18 {u['b18']} (absolute, not a delta) |")
    except StopIteration:
        pass

L += ["", "## Where the logic goes (one bank synthesised standalone)\n", "| block | LUT | LUT as RAM | FF | RAMB18 |", "|---|---|---|---|---|"]
try:
    b64, b256, b64w = x7("module_bank_64rows"), x7("module_bank_256rows"), x7("module_bank_64rows_wt0")
    L.append(f"| one bank, 64 rows × 8 lanes (banked: ×4) | {b64['lut']} | {b64['ramlut']} | {b64['ff']} | {b64['b18']} |")
    L.append(f"| one bank, 256 rows × 8 lanes (baseline: ×2) | {b256['lut']} | {b256['ramlut']} | {b256['ff']} | {b256['b18']} |")
    L.append(f"| one bank, 64 rows, WRITE_THROUGH=0 | {b64w['lut']} | {b64w['ramlut']} | {b64w['ff']} | {b64w['b18']} |")
    L.append(f"| **banked default: 4 banks** | {4*b64['lut']} | {4*b64['ramlut']} | {4*b64['ff']} | {4*b64['b18']} |")
    L.append(f"| **banked default: total** | {d['lut']} | {d['ramlut']} | {d['ff']} | {d['b18']} |")
    L.append(f"| **collector logic (total − 4 banks)** | {d['lut']-4*b64['lut']} | {d['ramlut']-4*b64['ramlut']} | {d['ff']-4*b64['ff']} | – |")
    L.append(f"| **baseline: total** | {b['lut']} | {b['ramlut']} | {b['ff']} | {b['b18']} |")
    L.append("")
    L.append("Attribution is approximate: a bank synthesised alone keeps logic (e.g. the `rd_hit`/`idle` monitor outputs) that is optimised away in context, "
             "which is why the baseline total (2 banks + its operand stage) comes out *below* two standalone banks. Read the collector row as an upper bound.")
except StopIteration:
    pass

L += ["", "## Scaling with warp width (default design, 7-series)\n", "| lanes | banked LUT | banked LUT as RAM | banked FF | baseline LUT | baseline FF | baseline RAMB18 |", "|---|---|---|---|---|---|---|"]
for ln, bt, at in ((2, "banked_default_L2", "baseline_L2"), (8, "banked_default", "baseline"), (32, "banked_default_L32", "baseline_L32")):
    try:
        u, a = x7(bt), x7(at)
        L.append(f"| {ln} | {u['lut']} | {u['ramlut']} | {u['ff']} | {a['lut']} | {a['ff']} | {a['b18']} |")
    except StopIteration:
        pass

if S.get("pnr"):
    L += ["", "## Timing: ECP5 (LFE5U-85F-6) place & route, 4 lanes, pin-limited shell, 100 MHz requested, seeds 1-3\n",
          "Fmax of the `clk` domain reported by nextpnr-ecp5. **This is not a Xilinx or Intel number.** The shell registers every input and output, so the figure bounds the DUT's internal register-to-register paths only.\n",
          "| design | seed 1 | seed 2 | seed 3 | median (MHz) |", "|---|---|---|---|---|"]
    for t in sorted({r["tag"] for r in S["pnr"]}):
        fs = [next((r.get("fmax") for r in S["pnr"] if r["tag"] == t and r["seed"] == s), None) for s in (1, 2, 3)]
        vs = sorted(f for f in fs if f)
        med = f"{vs[len(vs)//2]:.1f}" if vs else "n/a"
        L.append(f"| {t} | " + " | ".join(f"{f:.1f}" if f else "n/a" for f in fs) + f" | {med} |")
    paths = [r for r in S["pnr"] if r.get("path")]
    if paths:
        L += ["", "Critical path of the first banked run (nextpnr excerpt):", "", "```"] + next((r["path"] for r in paths if "banked_default" in r["tag"]), paths[0]["path"]).splitlines()[:14] + ["```"]
open(os.path.join(ROOT, "results", "cost.md"), "w").write("\n".join(L) + "\n")
print("\n".join(L))
