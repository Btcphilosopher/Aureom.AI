#!/usr/bin/env python3
"""Baseline vs banked comparison and design-space sweep on IDENTICAL instruction traces.

Every (design, trace, timing profile) is one closed-loop RTL simulation of tb_rfc_trace; the SAME trace/expected
files and the SAME timing plusargs drive baseline and banked designs, and every run is checked against the Python
model (a failing run aborts the comparison: numbers from a wrong design are meaningless).

Outputs results/compare.json (raw) and results/compare.md (tables quoted by docs/RESULTS.md).
Usage: scripts/run_compare.py [--jobs 4] [--quick]
"""
import argparse
import json
import math
import os
import sys
from concurrent.futures import ProcessPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from rfref import run   # noqa: E402

T = os.path.join(ROOT, "work", "traces")
LANES, NWARPS = 8, 8
TRACES = ["uni_mixed", "uni_full", "loopy", "hammer8", "hammer4", "dep1", "dep8", "ldburst", "memstall", "simt_dir", "simt_rand"]
REAL = ["simt_dir", "simt_rand"]
PROFILES = {
    "ideal":   dict(alu_lat=1, alu_jit=0, mem_lat=4, mem_jit=0, fetch_gap=2),
    "typical": dict(alu_lat=2, alu_jit=2, mem_lat=8, mem_jit=6, fetch_gap=2),
    "bursty":  dict(alu_lat=2, alu_jit=3, mem_lat=10, mem_jit=10, fetch_gap=2, dsp_pct0=75, dsp_pct1=50, wb_idle_pct=25),
    "memstall": dict(alu_lat=2, alu_jit=2, mem_lat=8, mem_jit=6, fetch_gap=2, stall_cls=1, stall_start=500, stall_len=900, stall_period=3000),
}
D = dict(DUT_KIND=0, NUM_WARPS=NWARPS, LANES=LANES, NUM_BANKS=4, BANK_MAP=2, NUM_CU=6, RD_ARB=1, RD_SHARE=0, FAST_READ=1)


def name_of(p):
    if p["DUT_KIND"] == 1:
        return "baseline"
    return f"B{p['NUM_BANKS']}/{['LOW','SKEW','XOR'][p['BANK_MAP']]}/cu{p['NUM_CU']}/{'age' if p['RD_ARB'] else 'rr'}" \
           f"{'/share' if p['RD_SHARE'] else ''}{'/fast' if p['FAST_READ'] else ''}"


def configs(quick=False):
    """Baseline + the chosen point D + one-factor-at-a-time sweeps around it."""
    cs = [dict(D, DUT_KIND=1)]
    seen = set()

    def add(**kw):
        p = dict(D); p.update(kw)
        k = name_of(p)
        if k not in seen:
            seen.add(k); cs.append(p)
    add()
    for nb in ((2, 4) if quick else (1, 2, 4, 8)):
        for bm in (0, 1, 2):
            add(NUM_BANKS=nb, BANK_MAP=bm)
    if not quick:
        for cu in (2, 3, 4, 5, 8):
            add(NUM_CU=cu)
        for arb in (0, 1):
            for sh in (0, 1):
                for fr in (0, 1):
                    add(RD_ARB=arb, RD_SHARE=sh, FAST_READ=fr)
        for nb in (2, 8):
            add(NUM_BANKS=nb, NUM_CU=4)
    return cs


def work(args):
    p, traces, profs = args
    exe = run.build("tb_rfc_trace", "tb/tb_rfc_trace.sv", p, tag="cmp")
    out = {}
    for prof in profs:
        for t in traces:
            pa = dict(trace=f"{T}/{t}.trace", exp=f"{T}/{t}.exp", name=t, seed=7)
            pa.update(PROFILES[prof])
            r = run.run(exe, pa, seed=11, timeout=1800)
            log = r.pop("_log")
            ok = r.pop("_ok") and "[sf_rfc" not in log
            r["ok"] = ok
            if not ok:
                r["why"] = next((l for l in log.splitlines() if "ERROR" in l or "FAIL" in l), "")[:200]
            out[f"{prof}|{t}"] = r
    return name_of(p), p, out


def gmean(xs):
    xs = [x for x in xs if x > 0]
    return math.exp(sum(math.log(x) for x in xs) / len(xs)) if xs else 0.0


def storage_bits(p):
    """Storage in bits, itemised (see docs/ARCHITECTURE.md s.9).  W = row width."""
    W = LANES * 32
    rows = NWARPS * 32
    if p["DUT_KIND"] == 1:
        arr = 2 * rows * W                                   # two replicated copies of the register file
        clean = 2 * rows
        fwd = 2 * (2 * W + 2 * LANES + 16)                   # stg + f per copy
        opnd = 2 * W + 2 * W                                  # R-stage rows are on the bank outputs; O stage holds 2 rows (+ misc)
        opnd = 2 * W
        ctrl = 2 * 110
        return dict(array=arr, clean=clean, forward=fwd, operand_buffers=opnd, control=ctrl)
    nb, ncu = p["NUM_BANKS"], p["NUM_CU"]
    arr = rows * W
    clean = rows
    fwd = nb * (2 * W + 2 * LANES + 16)
    opnd = ncu * 2 * W
    ctrl = ncu * (110 + ncu)                                 # descriptor, slot state, age row
    return dict(array=arr, clean=clean, forward=fwd, operand_buffers=opnd, control=ctrl)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    cs = configs(a.quick)
    profs = ["typical", "ideal"] if a.quick else list(PROFILES)
    traces = ["uni_mixed", "hammer8", "dep1", "memstall", "simt_dir"] if a.quick else TRACES
    # builds first (distinct directories), then the runs (the same pool, results cached by build)
    with ProcessPoolExecutor(a.jobs) as ex:
        list(ex.map(lambda_build, cs))
        results = list(ex.map(work, [(p, traces, profs) for p in cs]))
    bad = [(n, k, r.get("why")) for n, p, o in results for k, r in o.items() if not r["ok"]]
    if bad:
        for b in bad[:20]:
            print("RUN FAILED:", b)
        sys.exit(1)
    json.dump(dict(profiles=PROFILES, results=[dict(name=n, params=p, runs=o, storage=storage_bits(p)) for n, p, o in results]),
              open(os.path.join(ROOT, "results", "compare.json"), "w"), indent=1)
    report(results, profs, traces)


def lambda_build(p):
    return run.build("tb_rfc_trace", "tb/tb_rfc_trace.sv", p, tag="cmp")


def pctl(hist, q):
    tot = sum(hist)
    acc = 0
    for i, c in enumerate(hist):
        acc += c
        if tot and acc >= q * tot:
            return i
    return len(hist) - 1


def conflict_row(n, p, rr):
    req = sum(r.get("p3", 0) for r in rr); den = sum(r.get("p5", 0) for r in rr)
    ins = sum(r["instr"] for r in rr); iconf = sum(r.get("p7", 0) for r in rr)
    wait = sum(r["wait_sum"] for r in rr) / ins
    wh = [0] * 16
    for r in rr:
        for i, c in enumerate(str(r["whist"]).split(",")):
            wh[i] += int(c)
    wst = sum(r.get("p9", 0) for r in rr); wacc = sum(r.get("p8", 0) for r in rr)
    fwd = sum(r.get("p11", 0) for r in rr)
    sb = sum(storage_bits(p).values())
    cr = f"{100*den/req:.1f}%" if p["DUT_KIND"] == 0 else "0 (by construction)"
    ic = f"{100*iconf/ins:.1f}%" if p["DUT_KIND"] == 0 else "n/a"
    return f"| {n} | {cr} | {ic} | {wait:.3f} | {pctl(wh, 0.99)} | {wst/max(1,wacc):.3f} | {fwd/ins:.3f} | {sb/1024:.1f} |"


def agg(o, prof, traces, field, f=lambda x: x):
    return [f(o[f"{prof}|{t}"][field]) for t in traces if f"{prof}|{t}" in o]


def report(results, profs, traces):
    base = next(r for r in results if r[0] == "baseline")
    L = ["# Baseline vs banked register file: identical traces, closed-loop RTL simulation\n",
         f"Warps={NWARPS}, lanes={LANES}; every run checked against the Python model. Profiles: " +
         "; ".join(f"**{k}** = {v}" for k, v in PROFILES.items() if k in profs) + "\n"]
    for prof in profs:
        L.append(f"\n## Throughput (IPC) per trace, profile `{prof}`\n")
        hdr = "| design | " + " | ".join(traces) + " | geomean IPC | vs baseline |"
        L += [hdr, "|---" * (len(traces) + 3) + "|"]
        bg = gmean(agg(base[2], prof, traces, "ipc"))
        for n, p, o in results:
            ipcs = agg(o, prof, traces, "ipc")
            g = gmean(ipcs)
            L.append(f"| {n} | " + " | ".join(f"{x:.3f}" for x in ipcs) + f" | {g:.4f} | {100*(g/bg-1):+.1f}% |")
    prof = "typical"
    L.append(f"\n## Conflicts, operand wait and write back-pressure, profile `{prof}`\n")
    L.append("* **read conflict rate** = requester-cycles denied by bank arbitration / requester-cycles (RTL counters, cross-checked by the testbench)\n"
             "* **instr. with conflict** = dispatched instructions that were denied at least once\n"
             "* **wait** = cycles from issue to dispatch beyond that instruction's own conflict-free pipeline minimum "
             "(banked: 1 cycle for operand-free instructions, 2 with a read, 3 without FAST_READ; baseline: 2). Includes every cause: "
             "bank conflicts, waiting for the dispatch port, the per-warp in-order rule. Mean and 99th percentile.\n"
             "* **wb stall / write** = writeback-port-cycles offered but not accepted per accepted register write\n")
    L += ["| design | read conflict rate | instr. with conflict | wait mean | wait p99 | wb stall / write | fwd hits / instr | storage (Kib) |",
          "|---|---|---|---|---|---|---|---|"]
    for n, p, o in results:
        L.append(conflict_row(n, p, [o[f"{prof}|{t}"] for t in traces]))
    # same statistics restricted to the real SIMT streams (the synthetic set contains adversarial traces on purpose)
    L.append(f"\n## The same statistics on the REAL SIMT instruction streams only (simt_dir + simt_rand), profile `{prof}`\n")
    L += ["| design | read conflict rate | instr. with conflict | wait mean | wait p99 | wb stall / write | fwd hits / instr | storage (Kib) |",
          "|---|---|---|---|---|---|---|---|"]
    for n, p, o in results:
        L.append(conflict_row(n, p, [o[f"{prof}|{t}"] for t in REAL]))
    L.append("\n## Real SIMT instruction streams only (simt_dir + simt_rand), all profiles\n")
    L += ["| design | " + " | ".join(profs) + " |", "|---" * (len(profs) + 1) + "|"]
    for n, p, o in results:
        L.append(f"| {n} | " + " | ".join(f"{gmean(agg(o, pf, REAL, 'ipc')):.4f}" for pf in profs) + " |")
    open(os.path.join(ROOT, "results", "compare.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L[:60]))


if __name__ == "__main__":
    main()
