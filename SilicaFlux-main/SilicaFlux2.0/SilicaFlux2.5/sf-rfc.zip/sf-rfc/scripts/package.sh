#!/bin/sh
# Build sf-rfc.zip from the project tree (sources, docs, results, third_party; NOT the work/ build directory).
# usage: scripts/package.sh [output.zip]      default: <parent of the project>/sf-rfc.zip
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
PARENT=$(dirname "$ROOT")
OUT=${1:-$PARENT/sf-rfc.zip}
case "$OUT" in /*) ;; *) OUT="$PWD/$OUT" ;; esac
rm -f "$OUT"
cd "$PARENT"
zip -r -q "$OUT" "$(basename "$ROOT")" -x "*/work/*" -x "*/__pycache__/*" -x "*.pyc" -x "*/.pytest_cache/*"
echo "wrote $OUT"
