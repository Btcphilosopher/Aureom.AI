#!/usr/bin/env python3
"""Mutation campaign: inject one defect at a time into a COPY of the RTL and require the verification
environment (closed-loop trace testbench = Python model + RTL assertions + protocol checks) to catch it.

A mutant is CAUGHT when any run reports a failure: wrong operand/result, protocol violation, RTL assertion
text, counter cross-check mismatch, timeout (deadlock/livelock), or a non-OK status.  A mutant that is
built but not caught is reported as MISSED (and analysed in docs/VERIFICATION.md: either an equivalent
mutant or a coverage hole that must be closed).

Usage: scripts/mutate_rfc.py [--jobs 4] [--only NAME_SUBSTR]
Writes results/mutation.md.
"""
import argparse
import os
import shutil
import sys
from concurrent.futures import ProcessPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from rfref import run   # noqa: E402

T = os.path.join(ROOT, "work", "traces")

# (name, file, old, new, config-override)       config-override lets a mutant be exercised in the config where it lives
M = [
 ("collector: in-order dispatch rule removed (WAR)",      "sf_rfc.sv", "elig_vec[c]       = done_vec[c] & ~blk;", "elig_vec[c]       = done_vec[c];",
    dict(params=dict(NUM_CU=8), plus=dict(alu_lat=1, alu_jit=0, fetch_gap=0), traces=["war_nb4m2"])),
 ("collector: slot-2 captured from slot-1 bank",           "sf_rfc.sv", "          if (cu_bank[c][s] == BW1'(b)) cap[c][s]", "          if (cu_bank[c][0] == BW1'(b)) cap[c][s]", {}),
 ("collector: slot-1 operand not cleared at allocation",   "sf_rfc.sv", "        cu_data[c][0] <= '0;\n", "", {}),
 ("collector: slot-2 operand not cleared at allocation",   "sf_rfc.sv", "        cu_data[c][1] <= '0;\n", "", {}),
 ("collector: empty-mask read elision removed",            "sf_rfc.sv", "n_need[0] = iss_use1_i & (iss_rs1_i != 5'd0) & ~n_mz;", "n_need[0] = iss_use1_i & (iss_rs1_i != 5'd0);", {}),
 ("collector: duplicate-register follower never filled",   "sf_rfc.sv", "(n_need[1] & FAST_READ & g1) | (n_alias & FAST_READ & g0)", "(n_need[1] & FAST_READ & g1)", {}),
 ("collector: co-grant ignores the row (RD_SHARE=1)",     "sf_rfc.sv", "(rq_row[r] == wrow);", "1'b1;", dict(params=dict(RD_SHARE=1, NUM_BANKS=2, NUM_CU=4))),
 ("collector: dispatch lock removed (payload may change)", "sf_rfc.sv", "      if (lock_v[p]) begin", "      if (1'b0) begin", {}),
 ("collector: dispatch ignores operand completion",        "sf_rfc.sv", "elig_vec[c]       = done_vec[c] & ~blk;", "elig_vec[c]       = cu_v[c] & ~blk;", {}),
 ("collector: unit freed without dispatch handshake",      "sf_rfc.sv", "        if (fire_cu[c]) cu_v[c] <= 1'b0;", "        if (sel_oh[0][c] | sel_oh[1][c]) cu_v[c] <= 1'b0;", {}),
 ("collector: age column not cleared on allocation",       "sf_rfc.sv", "        older_q[c]    <= older_q[c] & ~alloc_oh;", "        older_q[c]    <= older_q[c];", {}),
 ("collector: class cap ignored (can fill all units)",     "sf_rfc.sv", "room_n[p] = (free_n != '0) && (int'(occ_n[p]) < CLS_CAP);", "room_n[p] = (free_n != '0);",
    dict(traces=["memflood"], plus=dict(stall_cls=1, stall_start=200, stall_len=900, mem_lat=4, mem_jit=0), min_other=150)),
 ("collector: issue accepted when no unit is free",        "sf_rfc.sv", "room_n[p] = (free_n != '0) && (int'(occ_n[p]) < CLS_CAP);", "room_n[p] = 1'b1;", {}),
 ("collector: class occupancy counter not decremented at dispatch", "sf_rfc.sv", " - CNT_W'((dsp_valid_o[p] && dsp_ready_i[p]) ? 1 : 0);", ";", {}),
 ("collector: free-unit counter ignores allocation",       "sf_rfc.sv", "free_n = free_q - CNT_W'(iss_fire ? 1 : 0) + CNT_W'(nd);", "free_n = free_q + CNT_W'(nd);", {}),
 ("writeback: r0 writes not discarded",                    "sf_rfc.sv", " & (wb_rd_i[p] != 5'd0) & (|wb_mask_i[p]);", " & (|wb_mask_i[p]);", {}),
 ("writeback: lane mask ignored (whole row written)",      "sf_rfc.sv", "bw_mask[b] = bw_mask[b] | wb_mask_i[p];", "bw_mask[b] = '1;", {}),
 ("writeback: loser dropped instead of back-pressured",    "sf_rfc.sv", "w_acc[p] = ~w_need[p] | g;", "w_acc[p] = 1'b1;", {}),
 ("writeback: completion raised before acceptance",        "sf_rfc.sv", "assign cmpl_valid_o = wb_valid_i & wb_ready_o;", "assign cmpl_valid_o = wb_valid_i;", {}),
 ("writeback: destination row uses wrong warp",            "sf_rfc.sv", "w_row[p]  = row_of(wb_warp_i[p], wb_rd_i[p]);", "w_row[p]  = row_of(WARP_W'(0), wb_rd_i[p]);", {}),
 ("collector: read request uses wrong warp for slot 2",    "sf_rfc.sv", "n_row[1]  = n_alias ? n_row[0]  : row_of(iss_warp_i, iss_rs2_i);", "n_row[1]  = n_alias ? n_row[0]  : row_of(WARP_W'(0), iss_rs2_i);", {}),
 ("writeback: same-row write ordering removed",             "sf_rfc.sv", "        if (found && wreq[p] && (w_row[p] == w_row[rr])) fin = WB_W'(p);", "        if (1'b0) fin = WB_W'(p);", dict(stress_only=True)),
 ("bank: staged-write overlay removed (same-cycle write-through)", "sf_rfc_bank.sv", "(a_hit & stg_mask[l]) ? stg_data[l*32 +: 32] : v1", "v1", dict(stress_only=True)),
 ("reset: collector request bits not cleared",            "sf_rfc.sv", "        st_rq[0][c] <= 1'b0;  st_rq[1][c] <= 1'b0;\n        st_fl[0][c] <= 1'b0;  st_fl[1][c] <= 1'b0;\n        cu_conf[c] <= 1'b0;", "        cu_conf[c] <= 1'b0;", dict(plus=dict(reset_at=900, reset_len=1), traces=["uni_mixed"], stress_profiles=["reset"])),
 ("reset: staged write survives reset",                    "sf_rfc_bank.sv", "    if (!rst_n || clr_all) stg_v <= 1'b0;", "    if (clr_all) stg_v <= 1'b0;", dict(stress_only=True)),
 ("reset: clean bits not set by reset",                    "sf_rfc_bank.sv", "    if (!rst_n || clr_all) begin\n      clean <= '1;", "    if (clr_all) begin\n      clean <= '1;", dict(plus=dict(reset_at=900, reset_len=1), traces=["uni_mixed"], stress_profiles=["reset"])),
 ("clear: per-warp clear does not set clean bits",         "sf_rfc_bank.sv", "        if (clr_warp[w]) clean[w*RPW +: RPW] <= '1;", "", dict(stress_only=True, stress_profiles=["clear"])),
 ("bank: landing-edge overlay removed",                    "sf_rfc_bank.sv", "(f_v  & f_mask[l])   ? f_data[l*32 +: 32]   : base", "base", {}),
 ("bank: clean bit ignored on read",                       "sf_rfc_bank.sv", "q_clean ? 32'd0 : ram_q[l*32 +: 32]", "ram_q[l*32 +: 32]", {}),
 ("bank: first partial write leaves stale lanes",          "sf_rfc_bank.sv", "(stg_mask[l] | land_clean)", "(stg_mask[l])", {}),
 ("baseline: operand stage ignores back-pressure",         "sf_rf_base.sv", "    hold   = r_v & ~o_free;", "    hold   = 1'b0;", {"__base": 1}),
]

TRACES = ["uni_mixed", "loopy", "hammer8", "dep1", "ldburst", "simt_dir"]
# the SHIPPED default point (docs/RESULTS.md); mutants that live behind an option (RD_SHARE) override it
BASE_PARAMS = dict(DUT_KIND=0, NUM_WARPS=8, LANES=8, NUM_BANKS=4, BANK_MAP=2, NUM_CU=6, RD_ARB=1, RD_SHARE=0, FAST_READ=1)
STRESS_PARAMS = dict(NUM_WARPS=4, LANES=4, NUM_BANKS=4, BANK_MAP=2, NUM_CU=6, RD_ARB=1, RD_SHARE=0, FAST_READ=1, WRITE_THROUGH=1)
STRESS_PROFILES = {"default": dict(), "saturated": dict(iss_pct=100, dsp_pct=95, wb_pct=100, wr_pct=95),
                   "reset": dict(reset_every=1777), "clear": dict(clear_every=1500, iss_pct=80)}


def make_copy(idx, fname, old, new):
    d = os.path.join(ROOT, "work", "mut", f"m{idx:02d}")
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    files = []
    for f in run.RTL:
        src = open(os.path.join(ROOT, f)).read()
        if os.path.basename(f) == fname:
            if src.count(old) != 1:
                return None, f"pattern found {src.count(old)} times"
            src = src.replace(old, new)
        dst = os.path.join(d, os.path.basename(f))
        open(dst, "w").write(src)
        files.append(dst)
    return files, ""


def failed(r):
    log = r["_log"]
    if (not r["_ok"]) or ("[sf_rfc" in log) or ("TIMEOUT" in log) or ("%Error" in log):
        return next((l for l in log.splitlines() if "ERROR" in l or "[sf_rfc" in l or "FAIL" in l or "TIMEOUT" in l or "%Error" in l), "failed")[:110]
    return None


def trace_stage(idx, params, files, ovr):
    try:
        exe = run.build("tb_rfc_trace", "tb/tb_rfc_trace.sv", params, rtl=files, tag=f"mut{idx:02d}")
    except Exception as e:
        return "BUILD-FAIL", str(e)[:200]
    cfgs = [dict(), dict(dsp_pct0=60, dsp_pct1=40, wb_idle_pct=20)]
    plan = [(t, 0, dict(ovr.get("plus", {}))) for t in ovr.get("traces", [])]
    plan += [(t, k, e) for t in TRACES for k, e in enumerate(cfgs)]
    for t, k, extra in plan:
        pa = dict(trace=f"{T}/{t}.trace", exp=f"{T}/{t}.exp", name=t, seed=3 + k)
        pa.update(extra)
        try:
            r = run.run(exe, pa, seed=5 + k, timeout=600)
        except Exception as e:      # timeout = deadlock / livelock = caught
            return "CAUGHT", f"trace {t}: {type(e).__name__}"
        why = failed(r)
        if not why and "min_other" in ovr and t in ovr.get("traces", []) and r.get("stall_other_disp", 0) < ovr["min_other"]:
            why = f"other class starved during the stall ({r.get('stall_other_disp')} dispatches in {r.get('stall_cyc')} cycles)"
        if why:
            return "CAUGHT", f"trace {t}{'(stalled)' if k else ''}: {why}"
    return "MISSED", ""


def stress_stage(idx, files, ovr):
    try:
        exe = run.build("tb_rfc_stress", "tb/tb_rfc_stress.sv", STRESS_PARAMS, rtl=files, tag=f"mutS{idx:02d}")
    except Exception as e:
        return "BUILD-FAIL", str(e)[:200]
    import subprocess
    for prof in ovr.get("stress_profiles", ["default", "saturated", "reset", "clear"]):
        for seed in (1, 2):
            pa = dict(seed=seed, cycles=25000); pa.update(STRESS_PROFILES[prof])
            cmd = [exe, "+verilator+rand+reset+2", f"+verilator+seed+{seed}"] + [f"+{k}={v}" for k, v in pa.items()]
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            except subprocess.TimeoutExpired:
                return "CAUGHT", f"stress {prof}: timeout"
            out = r.stdout + r.stderr
            if "PASS" not in out.splitlines() or "%Error" in out:
                return "CAUGHT", f"stress {prof}: " + next((l for l in out.splitlines() if "ERROR" in l or "%Error" in l or "FAIL" in l), "failed")[:100]
    return "MISSED", ""


def one(args):
    idx, (name, fname, old, new, ovr) = args
    files, why = make_copy(idx, fname, old, new)
    if files is None:
        return (idx, name, "INVALID", why)
    params = dict(BASE_PARAMS)
    params.update(ovr.get("params", {}))
    if "__base" in ovr:
        params.update(DUT_KIND=1)
    if not ovr.get("stress_only"):
        status, why = trace_stage(idx, params, files, ovr)
        if status != "MISSED":
            return (idx, name, status, why)
    if "__base" in ovr:
        return (idx, name, "MISSED", "")
    return (idx,) + (name,) + stress_stage(idx, files, ovr)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    todo = [(i, m) for i, m in enumerate(M) if a.only in m[0]]
    with ProcessPoolExecutor(a.jobs) as ex:
        res = sorted(ex.map(one, todo))
    lines = ["# Mutation campaign\n",
             "Each row injects ONE defect into a copy of the RTL. CAUGHT = some run of the closed-loop trace testbench "
             "(Python model, protocol checks, RTL assertions, counter cross-checks) or of the module-level stress testbench failed.\n",
             "| # | defect injected | result | first symptom |", "|---|---|---|---|"]
    for idx, name, status, why in res:
        lines.append(f"| {idx} | {name} | **{status}** | {why} |")
        print(f"{status:9s} {name}   {why}")
    n_c = sum(1 for r in res if r[2] == "CAUGHT")
    n_v = sum(1 for r in res if r[2] in ("CAUGHT", "MISSED"))
    lines.append(f"\n{n_c} of {n_v} valid mutants caught.")
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    out = "mutation_full.md" if not a.only else "mutation_partial.md"
    open(os.path.join(ROOT, "results", out), "w").write("\n".join(lines) + "\n")
    print(f"\n{n_c}/{n_v} caught")


if __name__ == "__main__":
    main()
