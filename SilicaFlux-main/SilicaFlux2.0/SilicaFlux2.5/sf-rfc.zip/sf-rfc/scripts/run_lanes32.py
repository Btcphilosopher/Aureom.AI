#!/usr/bin/env python3
"""Closed-loop comparison at 32 lanes (the SIMT default WARP_SIZE; 1024-bit rows) on traces regenerated for 32 lanes.
Writes results/lanes32.md.  (All other simulations use 8 lanes, the SF-G1 default.)"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from rfref import run   # noqa: E402

T = os.path.join(ROOT, "work", "traces32")
if not os.path.exists(os.path.join(T, "simt_rand.trace")):
    env = dict(os.environ, LANES="32", SCALE="0.3", OUT=T)
    subprocess.run([sys.executable, os.path.join(ROOT, "python", "gen_traces.py")], env=env, check=True, cwd=os.path.join(ROOT, "python"))
P = dict(DUT_KIND=0, NUM_WARPS=8, LANES=32, NUM_BANKS=4, BANK_MAP=2, NUM_CU=6, RD_ARB=1, RD_SHARE=0, FAST_READ=1)
exe = run.build("tb_rfc_trace", "tb/tb_rfc_trace.sv", P, tag="l32")
exeb = run.build("tb_rfc_trace", "tb/tb_rfc_trace.sv", dict(P, DUT_KIND=1), tag="l32b")
rows = ["# 32-lane simulation (8 warps, 1024-bit warp registers, 4 banks, XOR, 6 units)\n",
        "| trace | instructions | banked ok | banked IPC | read conflict rate | baseline ok | baseline IPC |", "|---|---|---|---|---|---|---|"]
bad = 0
for t in ["uni_mixed", "loopy", "hammer8", "dep1", "ldburst", "memstall", "simt_dir", "simt_rand"]:
    pa = dict(trace=f"{T}/{t}.trace", exp=f"{T}/{t}.exp", name=t, alu_lat=2, alu_jit=2, mem_lat=8, mem_jit=6, fetch_gap=2)
    a, b = run.run(exe, pa), run.run(exeb, pa)
    bad += (not a["_ok"]) + (not b["_ok"])
    rows.append(f"| {t} | {a['instr']} | {'PASS' if a['_ok'] else '**FAIL**'} | {a['ipc']:.3f} | {100*a['p5']/max(1,a['p3']):.1f}% | {'PASS' if b['_ok'] else '**FAIL**'} | {b['ipc']:.3f} |")
open(os.path.join(ROOT, "results", "lanes32.md"), "w").write("\n".join(rows) + "\n")
print("\n".join(rows))
sys.exit(1 if bad else 0)
