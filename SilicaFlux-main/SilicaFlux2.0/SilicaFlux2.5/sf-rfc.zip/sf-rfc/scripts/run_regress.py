#!/usr/bin/env python3
"""Named regression of the required scenarios.  Every test has BEHAVIOURAL assertions on top of "the run passed":
the scenario must actually have happened (coverage), nothing may be lost, and bounds must hold.

  1  repeated accesses to one bank     2  simultaneous writes               3  dependent instructions
  4  partial execution masks           5  reset (1..3 cycle pulses, in-flight work)   6  prolonged downstream stalls
  +  bank map RTL==Python, SIMT decode cross-check, elaboration-error checks, RTL lint (-Wall), module-level stress

Usage: scripts/run_regress.py [--quick] [--jobs 4]       Writes results/regress.md; exit status 1 on any failure.
"""
import argparse
import json
import os
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from rfref import run   # noqa: E402

T = os.path.join(ROOT, "work", "traces")
DEF = dict(DUT_KIND=0, NUM_WARPS=8, LANES=8, NUM_BANKS=4, BANK_MAP=2, NUM_CU=6, RD_ARB=1, RD_SHARE=0, FAST_READ=1)
BASE = dict(DEF, DUT_KIND=1)
TYP = dict(alu_lat=2, alu_jit=2, mem_lat=8, mem_jit=6, fetch_gap=2)


def go(args):
    """One simulation: (params, trace, plusargs) -> (result dict, log)."""
    params, trace, plus, seed = args
    exe = run.build("tb_rfc_trace", "tb/tb_rfc_trace.sv", params, tag="reg")
    pa = dict(trace=f"{T}/{trace}.trace", exp=f"{T}/{trace}.exp", name=trace, seed=seed)
    pa.update(plus)
    r = run.run(exe, pa, seed=seed + 100, timeout=1800)
    log = r.pop("_log")
    r["ok"] = r.pop("_ok") and "[sf_rfc" not in log
    r["why"] = next((l for l in log.splitlines() if "ERROR" in l or "FAIL" in l or "TIMEOUT" in l), "")[:160]
    return r


def partial_fraction(trace, lanes=8):
    full = (1 << lanes) - 1
    n = p = 0
    for line in open(f"{T}/{trace}.trace").read().splitlines()[2:]:
        m = int(line.split()[11], 16)
        n += 1
        p += 0 < m < full
    return p / n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    results = []     # (test, case, passed, detail)
    pool = ProcessPoolExecutor(a.jobs)

    def check(test, case, cond, detail=""):
        results.append((test, case, bool(cond), detail))

    # build the configurations once (distinct directories), then fan the runs out
    list(pool.map(lambda_build, [DEF, BASE, dict(DEF, NUM_BANKS=1, BANK_MAP=0), dict(DEF, BANK_MAP=0), dict(DEF, BANK_MAP=1), dict(DEF, WRITE_THROUGH=0)]))

    # ---------------------------------------------------------------- 1. repeated accesses to one bank
    cases = [("NB=1 (every access hits the same bank), hammer8", dict(DEF, NUM_BANKS=1, BANK_MAP=0), "hammer8"),
             ("NB=1, uni_mixed", dict(DEF, NUM_BANKS=1, BANK_MAP=0), "uni_mixed"),
             ("NB=4 LOW map vs stride-8 registers (all in bank 0)", dict(DEF, BANK_MAP=0), "hammer8"),
             ("NB=4 LOW map vs stride-4 registers", dict(DEF, BANK_MAP=0), "hammer4"),
             ("NB=4 SKEW map vs stride-8 registers", dict(DEF, BANK_MAP=1), "hammer8")]
    outs = list(pool.map(go, [(p, t, dict(TYP), 1) for _, p, t in cases]))
    for (name, p, t), r in zip(cases, outs):
        n_req, n_den = r.get("p3", 0), r.get("p5", 0)
        bound = 2 * (2 * p["NUM_CU"]) + 12
        check("1 one-bank", name, r["ok"] and r["status"] == "OK", r["why"])
        check("1 one-bank", name + ": contention really happened", n_den > 0.15 * n_req, f"conflict rate {100*n_den/max(1,n_req):.0f}%")
        check("1 one-bank", name + ": nothing dropped, bounded wait",
              r["instr"] == r["p2"] == r["p1"] and r["lat_max"] <= bound, f"max latency {r['lat_max']} <= {bound}; dispatched {r['p2']}/{r['instr']}")
    # the default (XOR) map must dissolve the stride pattern that serialises the other maps
    r_def = go((DEF, "hammer8", dict(TYP), 1))
    r_low = outs[2]
    check("1 one-bank", "default XOR map spreads stride-8 registers (throughput vs LOW map)", r_def["ipc"] > 1.3 * r_low["ipc"],
          f"IPC {r_def['ipc']:.3f} vs {r_low['ipc']:.3f}")

    # ---------------------------------------------------------------- 2. simultaneous writes
    runs = list(pool.map(go, [(DEF, t, dict(TYP), 2) for t in ("ldburst", "uni_full", "uni_mixed", "loopy")] +
                              [(BASE, t, dict(TYP), 2) for t in ("ldburst", "uni_mixed")]))
    for t, r in zip(("ldburst", "uni_full", "uni_mixed", "loopy"), runs[:4]):
        check("2 simultaneous writes", f"banked, {t}", r["ok"], r["why"])
        check("2 simultaneous writes", f"banked, {t}: write bank conflicts occurred and were back-pressured, none lost",
              r["p10"] > 0 and r["p9"] > 0 and r["wr_acc"] == r["p8"], f"bank conflicts {r['p10']}, stalled port-cycles {r['p9']}, accepted writes {r['p8']}=={r['wr_acc']}")
    for t, r in zip(("ldburst", "uni_mixed"), runs[4:]):
        check("2 simultaneous writes", f"baseline (single write port), {t}", r["ok"] and r["p9"] > 0, f"stalled port-cycles {r['p9']}")
    sr = subprocess.run([sys.executable, os.path.join(HERE, "run_stress.py"), "--quick"], capture_output=True, text=True)
    out = sr.stdout.strip().splitlines()[-1] if sr.stdout.strip() else sr.stderr[-300:]
    check("2 simultaneous writes", "stress matrix (same-row simultaneous writes, same-cycle read/write, resets, clears)",
          sr.returncode == 0 and "0 failures" in out and "'pair': 0" not in out and "'same': 0" not in out, out[:200])

    # ---------------------------------------------------------------- 3. dependent instructions (forwarding)
    for t in ("dep1", "dep8", "loopy"):
        r = go((DEF, t, dict(TYP), 3))
        b = go((BASE, t, dict(TYP), 3))
        check("3 dependent", f"{t}: banked and baseline both correct", r["ok"] and b["ok"], r["why"] or b["why"])
        if t == "dep1":
            check("3 dependent", "dep1: forwarding exercised on (nearly) every dependent hop", r["p11"] > 0.5 * r["instr"], f"forwarded reads {r['p11']} / {r['instr']} instructions")
            check("3 dependent", "dep1: same dependent-chain throughput as the baseline", abs(r["ipc"] - b["ipc"]) < 0.01 * b["ipc"] + 1e-9, f"IPC {r['ipc']:.4f} vs {b['ipc']:.4f}")
        else:
            check("3 dependent", f"{t}: forwarding used", r["p11"] > 0, f"{r['p11']} forwarded reads")

    # WRITE_THROUGH=0 is the setting for sf_simt_ctrl (a consumer never launches in the producer's acceptance cycle):
    # the whole scoreboard-legal flow must be correct, identical in behaviour, and cheaper
    wt0 = dict(DEF, WRITE_THROUGH=0)
    for t in ("dep1", "loopy", "uni_mixed", "simt_rand"):
        r0 = go((wt0, t, dict(TYP), 3))
        r1 = go((DEF, t, dict(TYP), 3))
        check("3 dependent", f"{t}: WRITE_THROUGH=0 (SIMT front-end setting) correct and cycle-identical to WRITE_THROUGH=1",
              r0["ok"] and r0["cycles"] == r1["cycles"] and r0["p11"] > 0 or (r0["ok"] and t == "uni_mixed" and r0["cycles"] == r1["cycles"]),
              f"cycles {r0['cycles']} vs {r1['cycles']}, forwarded reads {r0['p11']}")

    # ---------------------------------------------------------------- 4. partial masks
    # minimum partially-masked fraction each trace must really contain (measured: 35.9 / 35.1 / 7.3 / 59.9 %)
    need = {"uni_mixed": 0.25, "loopy": 0.25, "simt_dir": 0.05, "simt_rand": 0.40}
    for t, lo in need.items():
        f = partial_fraction(t)
        r = go((DEF, t, dict(TYP), 4))
        check("4 partial masks", f"{t} ({100*f:.1f}% of instructions partially masked, need >= {100*lo:.0f}%)", r["ok"] and f >= lo, r["why"])

    # ---------------------------------------------------------------- 5. reset
    rs = [(at, ln, tr) for tr in ("uni_mixed", "simt_dir") for at in (150, 531, 1200) for ln in (1, 2, 3)]
    if a.quick:
        rs = rs[::3]
    outs = list(pool.map(go, [(DEF, tr, dict(TYP, reset_at=at, reset_len=ln), 5) for at, ln, tr in rs]))
    for (at, ln, tr), r in zip(rs, outs):
        check("5 reset", f"{tr}: reset at cycle {at}, {ln}-cycle pulse, trace restarts from zero state",
              r["ok"] and r.get("resets") == 1 and r.get("inflight_at_reset", 0) > 0, f"in-flight at reset {r.get('inflight_at_reset')}; {r['why']}")
    b = go((BASE, "uni_mixed", dict(TYP, reset_at=531, reset_len=1), 5))
    check("5 reset", "baseline: same reset scenario", b["ok"] and b.get("resets") == 1, b["why"])

    # ---------------------------------------------------------------- 6. prolonged downstream stalls
    # memflood @200: the stalled class saturates the pool deterministically (5 vs 283 ALU dispatches without/with the class cap
    # on every seed tried); later windows are not valid probes because the ALU-only warps have run out of work by then
    scen = [("MEM port stalled 900 cycles, pool flooded with loads", dict(stall_cls=1, stall_start=200, stall_len=900, mem_lat=4, mem_jit=0), "memflood"),
            ("MEM port stalled 2000 cycles", dict(stall_cls=1, stall_start=400, stall_len=2000), "memstall"),
            ("ALU port stalled 1500 cycles", dict(stall_cls=0, stall_start=300, stall_len=1500), "ldburst"),
            ("BOTH ports stalled 3000 cycles", dict(stall_cls=2, stall_start=250, stall_len=3000), "uni_mixed"),
            ("periodic MEM stalls (900 of every 3000 cycles)", dict(stall_cls=1, stall_start=500, stall_len=900, stall_period=3000), "memstall"),
            ("slow sink: 20%/10% ready + 70% writeback bubbles", dict(dsp_pct0=20, dsp_pct1=10, wb_idle_pct=70), "uni_mixed")]
    jobs = [(p, t, dict(TYP, **pl), 6) for _, pl, t in scen for p in (DEF, BASE)]
    outs = list(pool.map(go, jobs))
    for i, (name, pl, t) in enumerate(scen):
        r, b = outs[2 * i], outs[2 * i + 1]
        check("6 stalls", f"{name} ({t}): banked correct, nothing lost, recovers", r["ok"] and r["instr"] == r["p2"], r["why"])
        check("6 stalls", f"{name} ({t}): back-pressure reached the front end (iss_ready fell)", r["cand_blocked"] > 0 or r["p15"] > 0 or r["p14"] > 0,
              f"issue-blocked cycles {r['cand_blocked']}, units-full cycles {r['p15']}, dispatch stalls {r['p14']}")
        check("6 stalls", f"{name} ({t}): baseline correct too", b["ok"], b["why"])
        if pl.get("stall_cls") == 1 and pl.get("stall_period", 0) == 0:
            need = 0.15 * r["stall_cyc"]
            check("6 stalls", f"{name}: ALU work keeps flowing while MEM is stalled (banked)", r["stall_other_disp"] >= need,
                  f"{r['stall_other_disp']} ALU dispatches in {r['stall_cyc']} stalled cycles (need >= {need:.0f}); baseline {b['stall_other_disp']}")

    pool.shutdown()

    # ---------------------------------------------------------------- mapping, decode, elaboration, lint
    for name, cmd in (("bank map RTL == Python, bijective", [sys.executable, os.path.join(HERE, "check_bankmap.py")]),):
        p = subprocess.run(cmd, capture_output=True, text=True)
        check("+ mapping", name, p.returncode == 0, p.stdout.strip()[-120:])
    check("+ decode", "SIMT decode adapter == sf_simt_pkg::sf_predecode (128k words)", decode_ok(), "")
    for bad in ("NUM_BANKS=3", "NUM_BANKS=64", "BANK_MAP=5", "NUM_CU=0", "CLS_CAP=9"):
        r = lint_cfg(bad)
        check("+ elaboration", f"illegal parameter {bad} is rejected at elaboration", r.returncode != 0 and "sf_rfc:" in (r.stdout + r.stderr), "")
    for cfg in ("", "-GNUM_BANKS=1 -GBANK_MAP=0", "-GNUM_BANKS=2 -GRD_ARB=0", "-GNUM_BANKS=8 -GNUM_CU=8 -GRD_SHARE=1 -GFAST_READ=0",
                "-GNUM_BANKS=16 -GLANES=32 -GNUM_WARPS=3 -GNUM_CU=3", "-GNUM_CU=1 -GNUM_BANKS=1 -GLANES=1 -GNUM_WARPS=1 -GNUM_CLS=1 -GNUM_WB=1",
                "-GNUM_BANKS=32 -GNUM_WB=3 -GNUM_CU=2 -GRAM_STYLE=1 -GSTRICT=1 -GPERF_EN=0 -GWRITE_THROUGH=0"):
        r = lint_cfg(cfg, expect_clean=True)
        check("+ lint", f"sf_rfc -Wall clean {cfg or '(defaults)'}", r.returncode == 0 and "%Warning" not in r.stderr, r.stderr[:200])
    r = lint_cfg("", top="sf_rf_base")
    check("+ lint", "sf_rf_base -Wall clean", r.returncode == 0 and "%Warning" not in r.stderr, r.stderr[:200])

    # ---------------------------------------------------------------- report
    npass = sum(1 for r in results if r[2])
    lines = ["# Regression results\n", f"{npass} of {len(results)} checks passed.\n", "| scenario | case | result | detail |", "|---|---|---|---|"]
    for t, c, ok, d in results:
        lines.append(f"| {t} | {c} | {'PASS' if ok else '**FAIL**'} | {d} |")
    open(os.path.join(ROOT, "results", "regress.md"), "w").write("\n".join(lines) + "\n")
    for t, c, ok, d in results:
        if not ok:
            print(f"FAIL [{t}] {c}: {d}")
    print(f"regress: {npass}/{len(results)} checks passed")
    return 0 if npass == len(results) else 1


def lambda_build(p):
    return run.build("tb_rfc_trace", "tb/tb_rfc_trace.sv", p, tag="reg")


def decode_ok():
    d = os.path.join(ROOT, "work", "dec")
    os.makedirs(d, exist_ok=True)
    exe = os.path.join(d, "obj", "Vtb_decode_xcheck")
    cmd = [run.VERILATOR, "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", "tb_decode_xcheck", "-Mdir", os.path.join(d, "obj"),
           "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", os.path.join(ROOT, "third_party/silicaflux-simt/rtl/sf_simt_pkg.sv"),
           os.path.join(ROOT, "rtl/sf_rfc_simt_dec.sv"), os.path.join(ROOT, "tb/tb_decode_xcheck.sv")]
    subprocess.run(cmd, capture_output=True, text=True, cwd=d)
    out = subprocess.run([exe], capture_output=True, text=True).stdout
    return "PASS" in out.splitlines() and "errors=0" in out


def lint_cfg(cfg, top="sf_rfc", expect_clean=False):
    files = ["rtl/sf_rfc_pkg.sv", "rtl/sf_rfc_ram.sv", "rtl/sf_rfc_bank.sv", "rtl/sf_rfc.sv"] + (["rtl/sf_rf_base.sv"] if top == "sf_rf_base" else [])
    cmd = [run.VERILATOR, "--lint-only", "-Wall", "-Wno-DECLFILENAME", "--top-module", top] + cfg.split() + files
    if cfg.startswith("NUM_") or cfg.startswith("BANK_") or cfg.startswith("CLS_"):
        cmd = [run.VERILATOR, "--lint-only", "-Wall", "-Wno-DECLFILENAME", "--top-module", top, f"-G{cfg}"] + files
    return subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)


if __name__ == "__main__":
    sys.exit(main())
