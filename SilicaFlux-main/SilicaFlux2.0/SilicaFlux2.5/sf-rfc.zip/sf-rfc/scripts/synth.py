#!/usr/bin/env python3
"""Synthesis driver: Yosys (slang frontend) + nextpnr-ecp5, results/synth.json and results/synth.md.

  utilisation  : the DUT synthesised STANDALONE (no I/O pads), Xilinx 7-series mapping (synth_xilinx -family xc7)
                 and Lattice ECP5 mapping (synth_ecp5).  Counts are Yosys `stat` cells.
  timing       : ONLY ECP5, post-place-and-route Fmax from nextpnr-ecp5 (LFE5U-85F-6, CABGA381) of the pin-limited
                 shell synth/sf_rfc_synth_top.sv.  There is NO open-source place & route for Xilinx here, so no Xilinx
                 timing exists in this repository -- do not read the ECP5 figure as a Xilinx estimate.
The WASI build of Yosys only sees the current directory, so everything runs from the project root.
Usage: scripts/synth.py [--pnr] [--quick] [--jobs 4]
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(ROOT, "work", "synth")
FILES = ["rtl/sf_rfc_pkg.sv", "rtl/sf_rfc_ram.sv", "rtl/sf_rfc_bank.sv", "rtl/sf_rfc.sv", "rtl/sf_rf_base.sv"]
YOSYS = os.environ.get("YOSYS", "yowasp-yosys")
NEXTPNR = os.environ.get("NEXTPNR", "yowasp-nextpnr-ecp5")

# the chosen default point (docs/RESULTS.md); PERF_EN=0 so utilisation excludes the 16 instrumentation counters
BASE = dict(NUM_WARPS=8, LANES=8, NUM_BANKS=4, BANK_MAP=2, NUM_CU=6, RD_ARB=1, RD_SHARE=0, FAST_READ=1,
            WRITE_THROUGH=1, RAM_STYLE=0, PERF_EN=0)
BITP = {"RD_SHARE", "FAST_READ", "WRITE_THROUGH", "PERF_EN"}


def gflags(params, keys):
    """-G flags for read_slang (bit parameters need a sized literal)."""
    return " ".join(f"-G {k}=1'b{int(params[k])}" if k in BITP else f"-G {k}={params[k]}" for k in keys if k in params)


DUT_KEYS = {2: ["ROWS", "LANES", "RPW", "NUM_WARPS", "RAM_STYLE", "WRITE_THROUGH"],
            0: ["NUM_WARPS", "LANES", "NUM_BANKS", "BANK_MAP", "NUM_CU", "RD_ARB", "RD_SHARE", "FAST_READ", "WRITE_THROUGH", "RAM_STYLE", "PERF_EN"],
            1: ["NUM_WARPS", "LANES", "WRITE_THROUGH", "RAM_STYLE", "PERF_EN", "NUM_CU"]}


def parse_stat(path):
    cells = {}
    for line in open(path):
        m = re.match(r"\s+(\d+)\s+(?:[\d.]+\s+)?(\S+)\s*$", line)
        if m:
            cells[m.group(2)] = cells.get(m.group(2), 0) + int(m.group(1))
    return cells


def synth(args):
    kind, params, fam, tag = args
    os.makedirs(OUT, exist_ok=True)
    top = {0: "sf_rfc", 1: "sf_rf_base", 2: "sf_rfc_bank"}[kind]
    files = " ".join(FILES)
    stat = os.path.join("work", "synth", f"{tag}_{fam}.stat")
    log = os.path.join("work", "synth", f"{tag}_{fam}.log")
    read = f"read_slang -j 1 --top {top} {gflags(params, DUT_KEYS[kind])} {files}"
    if fam == "xc7":
        script = f"{read}; synth_xilinx -family xc7 -top {top} -noiopad -flatten; tee -o {stat} stat"
    else:
        script = f"{read}; synth_ecp5 -top {top}; tee -o {stat} stat"
    t = time.time()
    r = subprocess.run([YOSYS, "-q", "-l", log, "-p", script], cwd=ROOT, capture_output=True, text=True)
    cells = parse_stat(os.path.join(ROOT, stat)) if os.path.exists(os.path.join(ROOT, stat)) else {}
    return dict(tag=tag, kind=kind, fam=fam, params=params, cells=cells, secs=time.time() - t, rc=r.returncode,
                err=(r.stderr or "")[-300:] if r.returncode else "")


def pnr(args):
    kind, params, tag, seed, freq = args
    os.makedirs(OUT, exist_ok=True)
    js = os.path.join("work", "synth", f"{tag}_pnr.json")
    log = os.path.join("work", "synth", f"{tag}_s{seed}.pnr.log")
    p = dict(params, KIND=kind)
    gen = gflags(p, ["KIND", "NUM_WARPS", "LANES", "NUM_BANKS", "BANK_MAP", "NUM_CU", "RD_ARB", "RD_SHARE", "FAST_READ",
                     "WRITE_THROUGH", "RAM_STYLE", "PERF_EN"])
    files = " ".join(FILES + ["synth/sf_rfc_synth_top.sv"])
    if not os.path.exists(os.path.join(ROOT, js)):
        s = f"read_slang -j 1 --top sf_rfc_synth_top {gen} {files}; synth_ecp5 -top sf_rfc_synth_top -json {js}; tee -o work/synth/{tag}_pnr.stat stat"
        r = subprocess.run([YOSYS, "-q", "-l", os.path.join("work", "synth", f"{tag}_pnr_synth.log"), "-p", s], cwd=ROOT, capture_output=True, text=True)
        if r.returncode:
            return dict(tag=tag, seed=seed, fmax=None, err=r.stderr[-300:])
    t = time.time()
    r = subprocess.run([NEXTPNR, "--85k", "--package", "CABGA381", "--json", js, "--freq", str(freq), "--seed", str(seed),
                        "--timing-allow-fail", "-l", log], cwd=ROOT, capture_output=True, text=True)
    txt = open(os.path.join(ROOT, log)).read() if os.path.exists(os.path.join(ROOT, log)) else ""
    fm = re.findall(r"Max frequency for clock\s+'[^']*clk[^']*':\s+([\d.]+) MHz", txt)
    crit = re.findall(r"Critical path report for clock 'clk'.*?\n((?:.*\n){0,40}?)\n", txt)
    path = ""
    m = re.search(r"Info: Critical path report for clock 'clk' \(posedge -> posedge\):\n(.*?)\n\n", txt, re.S)
    if m:
        path = m.group(1)
    return dict(tag=tag, seed=seed, fmax=float(fm[-1]) if fm else None, secs=time.time() - t, path=path[:1500], rc=r.returncode)


def lut_equiv_xc7(c):
    lut = sum(v for k, v in c.items() if re.fullmatch(r"LUT[1-6]", k))
    lutram = 4 * (c.get("RAM32M", 0) + c.get("RAM64M", 0)) + 2 * (c.get("RAM32X1D", 0) + c.get("RAM64X1D", 0)) + c.get("RAM32X1S", 0) + c.get("RAM64X1S", 0) \
        + 4 * c.get("RAM128X1D", 0) + 8 * c.get("RAM256X1S", 0)
    ff = sum(v for k, v in c.items() if re.fullmatch(r"FD[CPRS]E?", k) or k in ("FDRE", "FDSE", "FDCE", "FDPE", "FDCE_1"))
    return lut, lutram, ff


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pnr", action="store_true")
    ap.add_argument("--modules", action="store_true", help="synthesise single banks standalone and merge into results/synth.json")
    ap.add_argument("--pnr-parse", action="store_true", help="rebuild the timing table from the nextpnr logs in work/synth (no runs)")
    ap.add_argument("--pnr-only", action="store_true", help="reuse results/synth.json utilisation, only run place & route")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--pnr-lanes", type=int, default=8)
    a = ap.parse_args()

    if a.pnr_parse:
        old = json.load(open(os.path.join(ROOT, "results", "synth.json")))
        pr = []
        for f in sorted(os.listdir(OUT)):
            m = re.fullmatch(r"(.+)_s(\d+)\.pnr\.log", f)
            if not m:
                continue
            txt = open(os.path.join(OUT, f)).read()
            fm = re.findall(r"Max frequency for clock\s+'[^']*clk[^']*':\s+([\d.]+) MHz", txt)
            cp = re.search(r"Critical path report for clock '[^']*clk[^']*' \(posedge -> posedge\):\n(.*?)\n\n", txt, re.S)
            pr.append(dict(tag=m.group(1), seed=int(m.group(2)), fmax=float(fm[-1]) if fm else None, path=(cp.group(1) if cp else "")[:1800]))
        old["pnr"] = pr
        json.dump(old, open(os.path.join(ROOT, "results", "synth.json"), "w"), indent=1)
        report(old["synth"], pr)
        return
    if a.modules:
        mp = [("module_bank_64rows", 2, dict(ROWS=64, LANES=8, RPW=8, NUM_WARPS=8, RAM_STYLE=0, WRITE_THROUGH=1)),
              ("module_bank_256rows", 2, dict(ROWS=256, LANES=8, RPW=32, NUM_WARPS=8, RAM_STYLE=0, WRITE_THROUGH=1)),
              ("module_bank_64rows_wt0", 2, dict(ROWS=64, LANES=8, RPW=8, NUM_WARPS=8, RAM_STYLE=0, WRITE_THROUGH=0))]
        old = json.load(open(os.path.join(ROOT, "results", "synth.json")))
        with ProcessPoolExecutor(a.jobs) as ex:
            new = list(ex.map(synth, [(k, p, fam, tag) for tag, k, p in mp for fam in ("xc7", "ecp5")]))
        old["synth"] = [r for r in old["synth"] if not r["tag"].startswith("module_")] + new
        json.dump(old, open(os.path.join(ROOT, "results", "synth.json"), "w"), indent=1)
        report(old["synth"], old.get("pnr", []))
        return
    pts = [("baseline", 1, dict(BASE)), ("banked_default", 0, dict(BASE))]
    for nb in (1, 2, 8):
        pts.append((f"banked_B{nb}", 0, dict(BASE, NUM_BANKS=nb, BANK_MAP=2 if nb > 1 else 0)))
    if not a.quick:
        pts += [("banked_cu5", 0, dict(BASE, NUM_CU=5)),
                ("banked_cu4", 0, dict(BASE, NUM_CU=4)),
                ("banked_cu2", 0, dict(BASE, NUM_CU=2)),
                ("banked_nofast", 0, dict(BASE, FAST_READ=0)),
                ("banked_share", 0, dict(BASE, RD_SHARE=1)),
                ("banked_wt0", 0, dict(BASE, WRITE_THROUGH=0)),
                ("banked_perf", 0, dict(BASE, PERF_EN=1)),
                ("banked_ram_block", 0, dict(BASE, RAM_STYLE=1)),
                ("banked_ram_dist", 0, dict(BASE, RAM_STYLE=2)),
                ("baseline_ram_dist", 1, dict(BASE, RAM_STYLE=2)),
                ("baseline_ram_block", 1, dict(BASE, RAM_STYLE=1)),
                ("banked_default_L32", 0, dict(BASE, LANES=32)),
                ("baseline_L32", 1, dict(BASE, LANES=32)),
                ("banked_default_L2", 0, dict(BASE, LANES=2)),
                ("baseline_L2", 1, dict(BASE, LANES=2))]
    jobs = [(k, p, fam, tag) for tag, k, p in pts for fam in ("xc7", "ecp5")]
    res = []
    if a.pnr_only:
        a.pnr = True
        res = json.load(open(os.path.join(ROOT, "results", "synth.json")))["synth"]
    else:
        with ProcessPoolExecutor(a.jobs) as ex:
            for r in ex.map(synth, jobs):
                res.append(r)
                print(f"synth {r['tag']:18s} {r['fam']:5s} rc={r['rc']} {r['secs']:.0f}s", flush=True)
    pnr_res = []
    if a.pnr:
        L = a.pnr_lanes
        pp = [("baseline", 1, dict(BASE, LANES=L)), ("banked_default", 0, dict(BASE, LANES=L)),
              ("banked_cu4", 0, dict(BASE, LANES=L, NUM_CU=4)), ("banked_B2", 0, dict(BASE, LANES=L, NUM_BANKS=2)),
              ("banked_nofast", 0, dict(BASE, LANES=L, FAST_READ=0)), ("banked_wt0", 0, dict(BASE, LANES=L, WRITE_THROUGH=0))]
        pj = [(k, p, f"{t}_L{L}", s, 100) for t, k, p in pp for s in (1, 2, 3)]
        with ProcessPoolExecutor(a.jobs) as ex:
            for r in ex.map(pnr, pj):
                pnr_res.append(r)
                print(f"pnr {r['tag']} seed{r['seed']}: fmax={r.get('fmax')}", flush=True)
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    json.dump(dict(synth=res, pnr=pnr_res), open(os.path.join(ROOT, "results", "synth.json"), "w"), indent=1)
    report(res, pnr_res)


def report(res, pnr_res):
    L = ["# Synthesis results (Yosys 0.71 + slang; nextpnr-ecp5 0.11)\n",
         "Utilisation = the design synthesised **standalone** (I/O not mapped to pads) with `PERF_EN=0` unless the row says otherwise. "
         "Cell counts are Yosys `stat` output; nothing here comes from Vivado/Quartus.\n",
         "## Xilinx 7-series mapping (`synth_xilinx -family xc7`) -- utilisation only, no timing\n",
         "| design | LUT | LUTRAM macros (RAM32M/RAM64M..) | LUTs used as RAM | FF | RAMB18/36 | CARRY4 | MUXF7/8 |", "|---|---|---|---|---|---|---|---|"]
    for r in res:
        if r["fam"] != "xc7" or r["rc"]:
            continue
        c = r["cells"]
        lut, lutram, ff = lut_equiv_xc7(c)
        ram = sum(v for k, v in c.items() if k.startswith("RAM") and not k.startswith("RAMB"))
        rb = f"{c.get('RAMB18E1', 0)}/{c.get('RAMB36E1', 0)}"
        L.append(f"| {r['tag']} | {lut} | {ram} | {lutram} | {ff} | {rb} | {c.get('CARRY4', 0)} | {c.get('MUXF7', 0)}/{c.get('MUXF8', 0)} |")
    L += ["", "## Lattice ECP5 mapping (`synth_ecp5`)\n", "| design | LUT4 | FF | DPR16X4 (distributed RAM) | DP16KD (block RAM) | CCU2C |", "|---|---|---|---|---|---|"]
    for r in res:
        if r["fam"] != "ecp5" or r["rc"]:
            continue
        c = r["cells"]
        L.append(f"| {r['tag']} | {c.get('LUT4', 0)} | {c.get('TRELLIS_FF', 0)} | {c.get('TRELLIS_DPR16X4', 0)} | {c.get('DP16KD', 0)} | {c.get('CCU2C', 0)} |")
    bad = [r for r in res if r["rc"]]
    if bad:
        L.append("\nFailed syntheses: " + ", ".join(f"{r['tag']}/{r['fam']}" for r in bad))
    if pnr_res:
        L += ["", "## Timing: ECP5 (LFE5U-85F-6) post place & route, pin-limited shell, 100 MHz requested\n",
              "| design | seed 1 | seed 2 | seed 3 | median Fmax (MHz) |", "|---|---|---|---|---|"]
        tags = sorted({r["tag"] for r in pnr_res})
        for t in tags:
            fs = [next((r.get("fmax") for r in pnr_res if r["tag"] == t and r["seed"] == s), None) for s in (1, 2, 3)]
            vs = sorted(f for f in fs if f)
            med = vs[len(vs) // 2] if vs else None
            L.append(f"| {t} | " + " | ".join(f"{f:.1f}" if f else "n/a" for f in fs) + f" | {med:.1f} |" if med else f"| {t} | n/a | n/a | n/a | n/a |")
    open(os.path.join(ROOT, "results", "synth.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
