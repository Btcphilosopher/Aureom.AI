#!/usr/bin/env python3
"""Module-level stress matrix: tb_rfc_stress over representative configurations x seeds x traffic profiles."""
import os
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from rfref import run   # noqa: E402

D = dict(NUM_WARPS=4, LANES=4, NUM_BANKS=4, BANK_MAP=1, NUM_CU=4, RD_ARB=1, RD_SHARE=1, FAST_READ=1, WRITE_THROUGH=1, RAM_STYLE=0)
CONFIGS = [
    dict(),                                                                                   # default point
    dict(NUM_BANKS=1, BANK_MAP=0, RD_ARB=0, RD_SHARE=0, FAST_READ=0, NUM_CU=2),                # degenerate: one bank
    dict(NUM_BANKS=2, BANK_MAP=2, RD_ARB=0, RD_SHARE=1, FAST_READ=1, NUM_CU=3),
    dict(NUM_BANKS=8, BANK_MAP=2, RD_ARB=1, RD_SHARE=0, FAST_READ=0, NUM_CU=6),
    dict(NUM_BANKS=4, BANK_MAP=0, RD_ARB=0, RD_SHARE=1, FAST_READ=0, NUM_CU=4, WRITE_THROUGH=0),
    dict(NUM_BANKS=16, BANK_MAP=1, RD_ARB=1, NUM_CU=5, LANES=1, NUM_WARPS=3),                  # one lane, non-power-of-two warps
    dict(NUM_BANKS=4, BANK_MAP=2, RD_ARB=1, WRITE_THROUGH=0, FAST_READ=1),
    dict(NUM_BANKS=32, BANK_MAP=1, NUM_CU=2, NUM_WARPS=1, LANES=2),                            # as many banks as registers
    dict(NUM_BANKS=4, RAM_STYLE=1, NUM_CU=8, LANES=3, NUM_WARPS=5),
]
PROFILES = [
    ("default", dict()),
    ("saturated", dict(iss_pct=100, dsp_pct=95, wb_pct=100, wr_pct=95)),
    ("slow-sink", dict(iss_pct=90, dsp_pct=15, wb_pct=30)),
    ("reset", dict(reset_every=1777)),
    ("clear", dict(clear_every=1500, iss_pct=80)),
]


def params_of(ci):
    params = dict(D); params.update(CONFIGS[ci])
    return params


def build_cfg(ci):
    return run.build("tb_rfc_stress", "tb/tb_rfc_stress.sv", params_of(ci), tag="stress")


def job(a):
    ci, pi, seed = a
    exe = build_cfg(ci)                       # cached: all builds were done up front, one per configuration
    pa = dict(seed=seed, cycles=30000); pa.update(PROFILES[pi][1])
    cmd = [exe, "+verilator+rand+reset+2", f"+verilator+seed+{seed}"] + [f"+{k}={v}" for k, v in pa.items()]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    out = r.stdout + r.stderr
    ok = "PASS" in out.splitlines() and "%Error" not in out and "[sf_rfc" not in out
    res = run.parse(out)
    return ci, pi, seed, ok, res, out


def main():
    seeds = [1, 2, 3] if "--quick" not in sys.argv else [1]
    # build everything first (serially per config would also work; the pool builds lazily and caches)
    jobs = [(ci, pi, s) for ci in range(len(CONFIGS)) for pi in range(len(PROFILES)) for s in seeds]
    nfail = 0
    with ProcessPoolExecutor(4) as ex:                       # one build per configuration (distinct directories)
        list(ex.map(build_cfg, range(len(CONFIGS))))
    cov = dict(same=0, pair=0, bconf=0, part=0, empty=0, disp=0)
    with ProcessPoolExecutor(4) as ex:
        for ci, pi, seed, ok, res, out in ex.map(job, jobs):
            cov["same"] += res.get("cov_same_cycle_rw", 0); cov["pair"] += res.get("cov_same_row_pair", 0)
            cov["bconf"] += res.get("cov_wb_bank_conf", 0); cov["part"] += res.get("cov_partial_wr", 0)
            cov["empty"] += res.get("cov_empty_mask", 0); cov["disp"] += res.get("dispatched", 0)
            if not ok:
                nfail += 1
                print(f"FAIL cfg{ci} {PROFILES[pi][0]} seed{seed}: " + " | ".join(l for l in out.splitlines() if "ERROR" in l or "FAIL" in l)[:400])
    print(f"stress: {len(jobs)} runs, {nfail} failures; coverage {cov}")
    return nfail


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
