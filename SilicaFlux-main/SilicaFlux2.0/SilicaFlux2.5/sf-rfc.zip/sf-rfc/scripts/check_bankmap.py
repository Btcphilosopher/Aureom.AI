#!/usr/bin/env python3
"""Compare the RTL register->bank mapping (sf_rfc_pkg::f_bank + row formula) with python/rfref/bankmap.py for every
bank count 1..32, map 0..2, warp 0..7, reg 0..31; also re-check bijectivity and that every row index is in range."""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from rfref import bankmap, run   # noqa: E402


def main():
    exe = run.build("tb_bankmap", "tb/tb_bankmap.sv", {}, tag="bankmap", rtl=["rtl/sf_rfc_pkg.sv"])
    out = subprocess.run([exe], capture_output=True, text=True).stdout
    n = bad = 0
    for line in out.splitlines():
        if not line.startswith("MAP "):
            continue
        _, nb, bm, w, r, b, row = line.split()
        nb, bm, w, r, b, row = int(nb), int(bm), int(w), int(r), int(b), int(row)
        n += 1
        if bankmap.bank_of(bm, nb, w, r) != b or bankmap.row_of(nb, w, r) != row:
            bad += 1
            if bad < 5:
                print("MISMATCH", line, "python:", bankmap.bank_of(bm, nb, w, r), bankmap.row_of(nb, w, r))
    inj = all(bankmap.check_bijection(bm, nb, nw) for nb in (1, 2, 4, 8, 16, 32) for bm in (0, 1, 2) for nw in (1, 3, 8))
    print(f"bankmap: {n} entries compared, {bad} mismatches, bijective={inj}")
    return 0 if (n == 6 * 3 * 8 * 32 and bad == 0 and inj) else 1


if __name__ == "__main__":
    sys.exit(main())
