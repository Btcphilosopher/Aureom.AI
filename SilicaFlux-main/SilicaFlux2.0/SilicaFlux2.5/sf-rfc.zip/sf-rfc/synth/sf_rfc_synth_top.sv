// =============================================================================
//  sf_rfc_synth_top -- pin-limited shell used ONLY to place & route the register file / collector.
//
//  The DUT has thousands of I/O bits (two 256-bit operand rows per dispatch port, 256-bit write data, ...), far more
//  than any FPGA package has pins, and nextpnr cannot place a design that needs more I/O than the device offers.
//  This shell makes P&R possible without changing what is timed:
//     * every DUT input comes from a flip-flop of one long shift register (one serial input pin)
//     * every DUT output is captured in a flip-flop, then XOR-folded through a registered tree to one output pin
//  so the paths nextpnr times between the shell flops and inside the DUT are ordinary register-to-register paths.
//  The shell costs ~NIN+NOUT flip-flops and a small XOR tree, which is why LUT/FF *utilisation* is always taken
//  from the DUT synthesised standalone (scripts/synth.sh), and this shell is used for Fmax only.
//  What this does not model: the true arrival times of inputs from the neighbouring SIMT/execution blocks.
// =============================================================================
`default_nettype none
module sf_rfc_synth_top #(
  parameter int KIND = 0,                       // 0 = sf_rfc (banked), 1 = sf_rf_base (baseline)
  parameter int NUM_WARPS = 8,
  parameter int LANES = 8,
  parameter int NUM_BANKS = 4,
  parameter int BANK_MAP = 1,
  parameter int NUM_CU = 4,
  parameter int RD_ARB = 1,
  parameter bit RD_SHARE = 1'b1,
  parameter bit FAST_READ = 1'b1,
  parameter bit WRITE_THROUGH = 1'b1,
  parameter int RAM_STYLE = 0,
  parameter bit PERF_EN = 1'b0
) (
  input  wire clk,
  input  wire rst_n,
  input  wire si,
  output wire so
);
  localparam int NUM_CLS = 2, NUM_WB = 2, TAG_W = 4, PAYLOAD_W = 32;
  localparam int W = LANES * 32;
  localparam int WARP_W = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1;
  localparam int AUX_W = LANES;
  localparam int NREQ = 2 * NUM_CU;
  localparam int CU_W = (NUM_CU > 1) ? $clog2(NUM_CU) : 1;
  localparam int PERF_N = 16;

  // per-writeback-port input record
  localparam int WB_REC = WARP_W + TAG_W + 1 + 5 + LANES + W + AUX_W;
  localparam int NIN = 1 + NUM_WARPS + 1 + 1 + WARP_W + TAG_W + LANES + 2 + 10 + 1 + 5 + PAYLOAD_W + NUM_CLS + NUM_WB + NUM_WB * WB_REC;

  logic [NIN-1:0] sr;
  always_ff @(posedge clk) sr <= {sr[NIN-2:0], si};

  // ---- unpack the shift register into the DUT inputs
  logic clr_all;  logic [NUM_WARPS-1:0] clr_warp;
  logic iss_valid, iss_cls; logic [WARP_W-1:0] iss_warp; logic [TAG_W-1:0] iss_tag; logic [LANES-1:0] iss_mask;
  logic iss_use1, iss_use2, iss_wr; logic [4:0] iss_rs1, iss_rs2, iss_rd; logic [PAYLOAD_W-1:0] iss_payload;
  logic [NUM_CLS-1:0] dsp_ready; logic [NUM_WB-1:0] wb_valid;
  logic [WARP_W-1:0] wb_warp [NUM_WB]; logic [TAG_W-1:0] wb_tag [NUM_WB]; logic wb_we [NUM_WB];
  logic [4:0] wb_rd [NUM_WB]; logic [LANES-1:0] wb_mask [NUM_WB]; logic [W-1:0] wb_data [NUM_WB]; logic [AUX_W-1:0] wb_aux [NUM_WB];

  always_comb begin
    int o;
    o = 0;
    clr_all = sr[o]; o += 1;
    clr_warp = sr[o +: NUM_WARPS]; o += NUM_WARPS;
    iss_valid = sr[o]; o += 1;
    iss_cls = sr[o]; o += 1;
    iss_warp = sr[o +: WARP_W]; o += WARP_W;
    iss_tag = sr[o +: TAG_W]; o += TAG_W;
    iss_mask = sr[o +: LANES]; o += LANES;
    iss_use1 = sr[o]; o += 1;
    iss_use2 = sr[o]; o += 1;
    iss_rs1 = sr[o +: 5]; o += 5;
    iss_rs2 = sr[o +: 5]; o += 5;
    iss_wr = sr[o]; o += 1;
    iss_rd = sr[o +: 5]; o += 5;
    iss_payload = sr[o +: PAYLOAD_W]; o += PAYLOAD_W;
    dsp_ready = sr[o +: NUM_CLS]; o += NUM_CLS;
    wb_valid = sr[o +: NUM_WB]; o += NUM_WB;
    for (int p = 0; p < NUM_WB; p++) begin
      wb_warp[p] = sr[o +: WARP_W]; o += WARP_W;
      wb_tag[p] = sr[o +: TAG_W]; o += TAG_W;
      wb_we[p] = sr[o]; o += 1;
      wb_rd[p] = sr[o +: 5]; o += 5;
      wb_mask[p] = sr[o +: LANES]; o += LANES;
      wb_data[p] = sr[o +: W]; o += W;
      wb_aux[p] = sr[o +: AUX_W]; o += AUX_W;
    end
  end

  // ---- DUT
  logic idle;
  logic [NUM_CLS-1:0] iss_ready, dsp_valid;
  logic [WARP_W-1:0] dsp_warp [NUM_CLS]; logic [TAG_W-1:0] dsp_tag [NUM_CLS]; logic [LANES-1:0] dsp_mask [NUM_CLS];
  logic dsp_wr [NUM_CLS]; logic [4:0] dsp_rd [NUM_CLS]; logic [PAYLOAD_W-1:0] dsp_payload [NUM_CLS];
  logic [W-1:0] dsp_op1 [NUM_CLS], dsp_op2 [NUM_CLS];
  logic [NUM_WB-1:0] wb_ready, cmpl_valid;
  logic [WARP_W-1:0] cmpl_warp [NUM_WB]; logic [TAG_W-1:0] cmpl_tag [NUM_WB]; logic [AUX_W-1:0] cmpl_aux [NUM_WB];
  logic [31:0] perf [PERF_N];
  logic [NUM_CU-1:0] mon_alloc; logic [NREQ-1:0] mon_req, mon_gnt;
  logic [WARP_W-1:0] mon_rq_warp [NREQ]; logic [4:0] mon_rq_reg [NREQ]; logic [CU_W-1:0] mon_dsp_cu [NUM_CLS];

  if (KIND == 0) begin : g_dut
    sf_rfc #(.NUM_WARPS(NUM_WARPS), .LANES(LANES), .NUM_BANKS(NUM_BANKS), .BANK_MAP(BANK_MAP), .NUM_CU(NUM_CU),
             .NUM_CLS(NUM_CLS), .NUM_WB(NUM_WB), .RD_ARB(RD_ARB), .RD_SHARE(RD_SHARE), .FAST_READ(FAST_READ),
             .WRITE_THROUGH(WRITE_THROUGH), .TAG_W(TAG_W), .PAYLOAD_W(PAYLOAD_W), .AUX_W(AUX_W), .RAM_STYLE(RAM_STYLE),
             .STRICT(1'b0), .PERF_EN(PERF_EN)) dut (
      .clk, .rst_n, .clr_all_i(clr_all), .clr_warp_i(clr_warp), .idle_o(idle),
      .iss_valid_i(iss_valid), .iss_ready_o(iss_ready), .iss_cls_i(iss_cls), .iss_warp_i(iss_warp), .iss_tag_i(iss_tag),
      .iss_mask_i(iss_mask), .iss_use1_i(iss_use1), .iss_use2_i(iss_use2), .iss_rs1_i(iss_rs1), .iss_rs2_i(iss_rs2),
      .iss_wr_i(iss_wr), .iss_rd_i(iss_rd), .iss_payload_i(iss_payload),
      .dsp_valid_o(dsp_valid), .dsp_ready_i(dsp_ready), .dsp_warp_o(dsp_warp), .dsp_tag_o(dsp_tag), .dsp_mask_o(dsp_mask),
      .dsp_wr_o(dsp_wr), .dsp_rd_o(dsp_rd), .dsp_payload_o(dsp_payload), .dsp_op1_o(dsp_op1), .dsp_op2_o(dsp_op2),
      .wb_valid_i(wb_valid), .wb_ready_o(wb_ready), .wb_warp_i(wb_warp), .wb_tag_i(wb_tag), .wb_we_i(wb_we),
      .wb_rd_i(wb_rd), .wb_mask_i(wb_mask), .wb_data_i(wb_data), .wb_aux_i(wb_aux),
      .cmpl_valid_o(cmpl_valid), .cmpl_warp_o(cmpl_warp), .cmpl_tag_o(cmpl_tag), .cmpl_aux_o(cmpl_aux),
      .perf_clear_i(1'b0), .perf_o(perf), .mon_alloc_o(mon_alloc), .mon_req_o(mon_req), .mon_gnt_o(mon_gnt),
      .mon_rq_warp_o(mon_rq_warp), .mon_rq_reg_o(mon_rq_reg), .mon_dsp_cu_o(mon_dsp_cu));
  end else begin : g_dut
    sf_rf_base #(.NUM_WARPS(NUM_WARPS), .LANES(LANES), .NUM_CU(NUM_CU), .NUM_CLS(NUM_CLS), .NUM_WB(NUM_WB),
                 .TAG_W(TAG_W), .PAYLOAD_W(PAYLOAD_W), .AUX_W(AUX_W), .RAM_STYLE(RAM_STYLE), .PERF_EN(PERF_EN),
                 .WRITE_THROUGH(WRITE_THROUGH)) dut (
      .clk, .rst_n, .clr_all_i(clr_all), .clr_warp_i(clr_warp), .idle_o(idle),
      .iss_valid_i(iss_valid), .iss_ready_o(iss_ready), .iss_cls_i(iss_cls), .iss_warp_i(iss_warp), .iss_tag_i(iss_tag),
      .iss_mask_i(iss_mask), .iss_use1_i(iss_use1), .iss_use2_i(iss_use2), .iss_rs1_i(iss_rs1), .iss_rs2_i(iss_rs2),
      .iss_wr_i(iss_wr), .iss_rd_i(iss_rd), .iss_payload_i(iss_payload),
      .dsp_valid_o(dsp_valid), .dsp_ready_i(dsp_ready), .dsp_warp_o(dsp_warp), .dsp_tag_o(dsp_tag), .dsp_mask_o(dsp_mask),
      .dsp_wr_o(dsp_wr), .dsp_rd_o(dsp_rd), .dsp_payload_o(dsp_payload), .dsp_op1_o(dsp_op1), .dsp_op2_o(dsp_op2),
      .wb_valid_i(wb_valid), .wb_ready_o(wb_ready), .wb_warp_i(wb_warp), .wb_tag_i(wb_tag), .wb_we_i(wb_we),
      .wb_rd_i(wb_rd), .wb_mask_i(wb_mask), .wb_data_i(wb_data), .wb_aux_i(wb_aux),
      .cmpl_valid_o(cmpl_valid), .cmpl_warp_o(cmpl_warp), .cmpl_tag_o(cmpl_tag), .cmpl_aux_o(cmpl_aux),
      .perf_clear_i(1'b0), .perf_o(perf), .mon_alloc_o(mon_alloc), .mon_req_o(mon_req), .mon_gnt_o(mon_gnt),
      .mon_rq_warp_o(mon_rq_warp), .mon_rq_reg_o(mon_rq_reg), .mon_dsp_cu_o(mon_dsp_cu));
  end

  // ---- capture every DUT output (the monitor ports are deliberately NOT captured: they are verification-only)
  localparam int NOUT = 1 + NUM_CLS + NUM_CLS + NUM_CLS * (WARP_W + TAG_W + LANES + 1 + 5 + PAYLOAD_W + 2 * W) +
                        NUM_WB + NUM_WB + NUM_WB * (WARP_W + TAG_W + AUX_W);
  logic [NOUT-1:0] out_v, out_q;
  always_comb begin
    int o;
    o = 0;
    out_v[o] = idle; o += 1;
    out_v[o +: NUM_CLS] = iss_ready; o += NUM_CLS;
    out_v[o +: NUM_CLS] = dsp_valid; o += NUM_CLS;
    for (int p = 0; p < NUM_CLS; p++) begin
      out_v[o +: WARP_W] = dsp_warp[p]; o += WARP_W;
      out_v[o +: TAG_W] = dsp_tag[p]; o += TAG_W;
      out_v[o +: LANES] = dsp_mask[p]; o += LANES;
      out_v[o] = dsp_wr[p]; o += 1;
      out_v[o +: 5] = dsp_rd[p]; o += 5;
      out_v[o +: PAYLOAD_W] = dsp_payload[p]; o += PAYLOAD_W;
      out_v[o +: W] = dsp_op1[p]; o += W;
      out_v[o +: W] = dsp_op2[p]; o += W;
    end
    out_v[o +: NUM_WB] = wb_ready; o += NUM_WB;
    out_v[o +: NUM_WB] = cmpl_valid; o += NUM_WB;
    for (int p = 0; p < NUM_WB; p++) begin
      out_v[o +: WARP_W] = cmpl_warp[p]; o += WARP_W;
      out_v[o +: TAG_W] = cmpl_tag[p]; o += TAG_W;
      out_v[o +: AUX_W] = cmpl_aux[p]; o += AUX_W;
    end
  end
  always_ff @(posedge clk) out_q <= out_v;

  // registered XOR tree: 32 bits -> 1 per stage (vectors zero-padded to a multiple of 32)
  localparam int NCH = (NOUT + 31) / 32;
  logic [NCH*32-1:0] out_pad;
  logic [NCH-1:0] f1;
  assign out_pad = {{(NCH*32 - NOUT){1'b0}}, out_q};
  always_ff @(posedge clk) begin
    for (int i = 0; i < NCH; i++) f1[i] <= ^out_pad[i*32 +: 32];
  end
  localparam int NCH2 = (NCH + 31) / 32;
  logic [NCH2*32-1:0] f1_pad;
  logic [NCH2-1:0] f2;
  assign f1_pad = {{(NCH2*32 - NCH){1'b0}}, f1};
  always_ff @(posedge clk) begin
    for (int i = 0; i < NCH2; i++) f2[i] <= ^f1_pad[i*32 +: 32];
  end
  logic so_q;
  always_ff @(posedge clk) so_q <= ^f2;
  assign so = so_q;
endmodule
`default_nettype wire
