# Mutation campaign

Each row injects ONE defect into a copy of the RTL. CAUGHT = some run of the closed-loop trace testbench (Python model, protocol checks, RTL assertions, counter cross-checks) or of the module-level stress testbench failed.

| # | defect injected | result | first symptom |
|---|---|---|---|
| 0 | collector: in-order dispatch rule removed (WAR) | **CAUGHT** | trace war_nb4m2: [2855 cyc 285] ERROR: warp 0 dispatch out of program order: got local 37 expected 35 |
| 1 | collector: slot-2 captured from slot-1 bank | **CAUGHT** | trace uni_mixed: [1145 cyc 114] ERROR: g1645 (w3 fn1 rs2=r23): OPERAND 2 MISMATCH got 259e83f0a3b2584529466e2a975a24bf1d6ff9049 |
| 2 | collector: slot-1 operand not cleared at allocation | **CAUGHT** | trace uni_mixed: [75 cyc 7] ERROR: g0 (w0 fn0 rs1=r0): OPERAND 1 MISMATCH got 00000000000000007e64adcdec993730b54fea94000000001 |
| 3 | collector: slot-2 operand not cleared at allocation | **CAUGHT** | trace uni_mixed: [75 cyc 7] ERROR: g0 (w0 fn0 rs2=r0): OPERAND 2 MISMATCH got 00000000000000007e64adcdec993730b54fea94000000001 |
| 4 | collector: empty-mask read elision removed | **CAUGHT** | trace uni_mixed: [1665 cyc 166] ERROR: g20 (w0 fn1 rs1=r7): OPERAND 1 MISMATCH got 245f692f29f1c81dc9f44bb2356567ba9c6714799c67 |
| 5 | collector: duplicate-register follower never filled | **CAUGHT** | trace uni_mixed: [1095 cyc 109] ERROR: g2732 (w5 fn5 rs2=r2): OPERAND 2 MISMATCH got 000000000000000000000000000000000000000000 |
| 6 | collector: co-grant ignores the row (RD_SHARE=1) | **CAUGHT** | trace uni_mixed: [1125] %Error: sf_rfc.sv:704: Assertion failed in tb_rfc_trace.g_dut.dut.unnamedblk66.unnamedblk67: [sf_rfc] b |
| 7 | collector: dispatch lock removed (payload may change) | **CAUGHT** | trace uni_mixed(stalled): [3835 cyc 383] ERROR: dispatch class 0: payload changed while stalled (g3841 -> g3298) |
| 8 | collector: dispatch ignores operand completion | **CAUGHT** | trace uni_mixed: [1035 cyc 103] ERROR: g12 (w0 fn2 rs1=r7): OPERAND 1 MISMATCH got 00000000000000000000000000000000000000000000 |
| 9 | collector: unit freed without dispatch handshake | **CAUGHT** | trace uni_mixed(stalled): [105] %Error: sf_rfc.sv:718: Assertion failed in tb_rfc_trace.g_dut.dut.unnamedblk70.unnamedblk71: [sf_rfc] di |
| 10 | collector: age column not cleared on allocation | **CAUGHT** | trace uni_mixed: FAIL: timeout at cycle 2000000 (completed 113 of 4352, dispatched 113) |
| 11 | collector: class cap ignored (can fill all units) | **CAUGHT** | trace memflood: [2075] %Error: sf_rfc.sv:699: Assertion failed in tb_rfc_trace.g_dut.dut: [sf_rfc] registered readiness 11 dif |
| 12 | collector: issue accepted when no unit is free | **CAUGHT** | trace uni_mixed(stalled): [155] %Error: sf_rfc.sv:699: Assertion failed in tb_rfc_trace.g_dut.dut: [sf_rfc] registered readiness 11 diff |
| 13 | collector: class occupancy counter not decremented at dispatch | **CAUGHT** | trace uni_mixed: [115] %Error: sf_rfc.sv:699: Assertion failed in tb_rfc_trace.g_dut.dut: [sf_rfc] registered readiness 10 diff |
| 14 | collector: free-unit counter ignores allocation | **CAUGHT** | trace uni_mixed: [95] %Error: sf_rfc.sv:699: Assertion failed in tb_rfc_trace.g_dut.dut: [sf_rfc] registered readiness 00 diffe |
| 15 | writeback: r0 writes not discarded | **CAUGHT** | trace uni_mixed: ERROR: accepted-write counter mismatch: RTL 3038, testbench 2970 |
| 16 | writeback: lane mask ignored (whole row written) | **CAUGHT** | trace uni_mixed: [1295 cyc 129] ERROR: g1102 (w2 fn1 rs2=r31): OPERAND 2 MISMATCH got 67486afce164b1496b908726d58ccdb35fb91008d |
| 17 | writeback: loser dropped instead of back-pressured | **CAUGHT** | trace uni_mixed: [3465 cyc 346] ERROR: g3305 (w6 fn5 rs2=r22): OPERAND 2 MISMATCH got d64d52b52653ebe53442ba034073c0deb8dccf329 |
| 18 | writeback: completion raised before acceptance | **CAUGHT** | trace uni_mixed: [1975 cyc 197] ERROR: cmpl_valid[1] != wb_valid&wb_ready |
| 19 | writeback: destination row uses wrong warp | **CAUGHT** | trace uni_mixed: [1045 cyc 104] ERROR: g12 (w0 fn2 rs1=r7): OPERAND 1 MISMATCH got e229039f6405d82aeef1ee4550eda4d0dad8796b5cb4 |
| 20 | collector: read request uses wrong warp for slot 2 | **CAUGHT** | trace uni_mixed: [1175 cyc 117] ERROR: g3277 (w6 fn5 rs2=r5): OPERAND 2 MISMATCH got 9c6714799c6714799c6714799c6714799c6714799c |
| 21 | writeback: same-row write ordering removed | **CAUGHT** | stress default: [cyc 798] ERROR: S5 same-row pair: higher port accepted before the lower one |
| 22 | bank: staged-write overlay removed (same-cycle write-through) | **CAUGHT** | stress default: [cyc 187] ERROR: S1 id121 w1 r5: OPERAND 1 got e300d494381ffc51a73e200ce12a1615 exp e300d494381ffc51 |
| 23 | reset: collector request bits not cleared | **CAUGHT** | trace uni_mixed: [65] %Error: sf_rfc.sv:709: Assertion failed in tb_rfc_trace.g_dut.dut.unnamedblk68.unnamedblk69: [sf_rfc] fre |
| 24 | reset: staged write survives reset | **CAUGHT** | stress reset: [cyc 1792] ERROR: S1 id1242 w3 r3: OPERAND 1 got 000000002c63a8f30000000000000000 exp 00000000000000 |
| 25 | reset: clean bits not set by reset | **CAUGHT** | trace uni_mixed: [1065 cyc 106] ERROR: g1100 (w2 fn4 rs1=r19): OPERAND 1 MISMATCH got bc7ea0cbcb5a6073e27c4c389560bbbd4e04d227e |
| 26 | clear: per-warp clear does not set clean bits | **CAUGHT** | stress clear: [cyc 1551] ERROR: S1 id1126 w2 r2: OPERAND 1 got d67f12932fcefb0a475281f51a4986e5 exp 00000000000000 |
| 27 | bank: landing-edge overlay removed | **CAUGHT** | trace uni_mixed: [4695 cyc 469] ERROR: g1145 (w2 fn3 rs1=r8): OPERAND 1 MISMATCH got 67458eb4e16955016b9d636ed58129fb5fb4f440d9 |
| 28 | bank: clean bit ignored on read | **CAUGHT** | trace uni_mixed: [1065 cyc 106] ERROR: g1100 (w2 fn4 rs1=r19): OPERAND 1 MISMATCH got bc7ea0cbcb5a6073e27c4c389560bbbd4e04d227e |
| 29 | bank: first partial write leaves stale lanes | **CAUGHT** | trace uni_mixed: [1395 cyc 139] ERROR: g1648 (w3 fn2 rs1=r16): OPERAND 1 MISMATCH got 3db509219de2aa583db509213db50921321e302e3 |
| 30 | baseline: operand stage ignores back-pressure | **CAUGHT** | trace uni_mixed(stalled): [1815 cyc 181] ERROR: g2732 (w5 fn5 rs1=r2): OPERAND 1 MISMATCH got 000000000000000000000000000000000000000000 |

31 of 31 valid mutants caught.
