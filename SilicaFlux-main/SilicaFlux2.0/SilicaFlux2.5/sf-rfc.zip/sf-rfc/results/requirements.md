# Register-access requirements (measured from the SilicaFlux SIMT programs)

84 programs (24 directed + random legal), 142918 backend-bound instructions, warp size 8, 8 warps.

| quantity | value |
|---|---|
| register reads per instruction (after r0/duplicate/mask elision) | mean 1.12; 0: 25.5%, 1: 36.7%, 2: 37.8% |
| nominal source operands (ISA view) | 0: 3.1%, 1: 57.9%, 2: 39.0% |
| register writes per instruction | 0.82 |
| MEM-port instructions | 9.8% |
| fully masked / partially masked | 0.0% / 55.7% |
| read slots elided | r0 read: 32033, duplicate register: 1664 |
| instructions with two distinct register reads | 37.8% |
| RAW distance <= 2 instructions (same warp) | 45.3% of dependent reads |
| source register already read by one of the previous 4 instructions of the warp | 37.5% |
| hottest read registers | r26 16.8%, r14 10.1%, r23 5.4%, r18 5.1%, r12 3.9%, r3 3.8% |

## Probability that the two operands of one instruction fall into the same bank

| NUM_BANKS | LOW | SKEW | XOR |
|---|---|---|---|
| 1 | 100.0% | 100.0% | 100.0% |
| 2 | 51.6% | 51.6% | 44.5% |
| 4 | 25.9% | 25.9% | 30.6% |
| 8 | 8.3% | 8.3% | 7.3% |
| 16 | 2.6% | 2.6% | 2.6% |

## Read-load imbalance across banks (busiest bank / mean bank, warp-averaged)

| NUM_BANKS | LOW | SKEW | XOR |
|---|---|---|---|
| 2 | 1.26 | 1.00 | 1.00 |
| 4 | 1.76 | 1.00 | 1.00 |
| 8 | 2.31 | 1.00 | 1.00 |
| 16 | 3.25 | 1.21 | 1.04 |
