# FPGA cost versus throughput (8 lanes, 8 warps; Yosys 0.71, `PERF_EN=0`)

Utilisation = design synthesised standalone. `LUT` excludes LUTs used as RAM (`RAM32M`/`RAM64M`, reported separately as 4 LUT6 each); `RAMB18` counts 18 Kb blocks. IPC columns are geometric means over the 11 traces of `results/compare.md`, relative to the baseline.

| design | LUT | LUT as RAM | FF | RAMB18 | LUT vs baseline | FF vs baseline | IPC typical (all / real) | IPC bursty (all) |
|---|---|---|---|---|---|---|---|---|
| baseline | 2278 | 0 | 1445 | 16 | 1.0× | 1.0× | +0.0% / +0.0% | +0.0% |
| banked_default | 12378 | 1408 | 7063 | 0 | 6.1× | 4.9× | -0.0% / +0.0% | +12.3% |
| banked_cu5 | 10536 | 1408 | 6461 | 0 | 5.2× | 4.5× | -0.1% / +0.0% | +12.2% |
| banked_cu4 | 9850 | 1408 | 5859 | 0 | 4.9× | 4.1× | -1.4% / -2.7% | +9.4% |
| banked_cu2 | 7423 | 1408 | 4660 | 0 | 3.9× | 3.2× | -53.4% / -56.5% | -41.9% |
| banked_B1 | 5567 | 0 | 4401 | 8 | 2.4× | 3.0× | -25.8% / -7.3% | -3.6% |
| banked_B2 | 9962 | 0 | 4950 | 16 | 4.4× | 3.4× | -2.8% / -0.7% | +9.7% |
| banked_B8 | 26438 | 1536 | 10252 | 0 | 12.3× | 7.1× | +0.1% / +0.1% | +12.5% |
| banked_nofast | 12231 | 1408 | 7039 | 0 | 6.0× | 4.9× | -2.2% / -2.1% | +9.0% |
| banked_share | 12586 | 1408 | 7063 | 0 | 6.1× | 4.9× | -0.0% / +0.0% | +12.3% |

## Same designs, Lattice ECP5 mapping

| design | LUT4 | FF | DPR16X4 (distributed RAM) | DP16KD (block RAM) |
|---|---|---|---|---|
| baseline | 3475 | 1989 | 0 | 16 |
| banked_default | 20915 | 8175 | 0 | 32 |
| banked_cu5 | 18042 | 7573 | 0 | 32 |
| banked_cu4 | 15977 | 6971 | 0 | 32 |
| banked_cu2 | 10099 | 5772 | 0 | 32 |
| banked_B1 | 7643 | 4937 | 0 | 8 |
| banked_B2 | 11960 | 6020 | 0 | 16 |
| banked_B8 | 34556 | 10252 | 1024 | 0 |
| banked_nofast | 20586 | 8151 | 0 | 32 |
| banked_share | 21370 | 8175 | 0 | 32 |

## Options and what they cost (7-series, relative to the default `banked_default`)

| option | LUT | FF | note |
|---|---|---|---|
| banked_wt0 | -1096 (-9 %) | -24 | WRITE_THROUGH=0: removes the same-cycle overlay (unreachable with sf_simt_ctrl); cycle-identical on every scoreboard-legal run; RAM LUTs 1408, RAMB18 0 |
| banked_share | +208 (+2 %) | +0 | RD_SHARE=1: co-grant comparators; measured hit rate 0.00 %; RAM LUTs 1408, RAMB18 0 |
| banked_nofast | -147 (-1 %) | -24 | FAST_READ=0: no issue-cycle read attempt; −2.2 % IPC; RAM LUTs 1408, RAMB18 0 |
| banked_perf | +903 (+7 %) | +522 | PERF_EN=1: the 16 saturating 32-bit counters (instrumentation); RAM LUTs 1408, RAMB18 0 |
| banked_ram_block | -52 (-0 %) | -1024 | RAM_STYLE=1: block RAM instead of LUTRAM (64-row memories use 12.5 % of a RAMB18); RAM LUTs 0, RAMB18 32 |
| banked_ram_dist | +0 (+0 %) | +0 | RAM_STYLE=2: distributed RAM; RAM LUTs 1408, RAMB18 0 |
| baseline_ram_dist | 2901 | 1957 | baseline in distributed RAM; RAM LUTs 2816, RAMB18 0 (absolute, not a delta) |
| baseline_ram_block | 2278 | 1445 | baseline in block RAM; RAM LUTs 0, RAMB18 16 (absolute, not a delta) |

## Where the logic goes (one bank synthesised standalone)

| block | LUT | LUT as RAM | FF | RAMB18 |
|---|---|---|---|---|
| one bank, 64 rows × 8 lanes (banked: ×4) | 959 | 352 | 864 | 0 |
| one bank, 256 rows × 8 lanes (baseline: ×2) | 1335 | 0 | 804 | 8 |
| one bank, 64 rows, WRITE_THROUGH=0 | 697 | 352 | 858 | 0 |
| **banked default: 4 banks** | 3836 | 1408 | 3456 | 0 |
| **banked default: total** | 12378 | 1408 | 7063 | 0 |
| **collector logic (total − 4 banks)** | 8542 | 0 | 3607 | – |
| **baseline: total** | 2278 | 0 | 1445 | 16 |

Attribution is approximate: a bank synthesised alone keeps logic (e.g. the `rd_hit`/`idle` monitor outputs) that is optimised away in context, which is why the baseline total (2 banks + its operand stage) comes out *below* two standalone banks. Read the collector row as an upper bound.

## Scaling with warp width (default design, 7-series)

| lanes | banked LUT | banked LUT as RAM | banked FF | baseline LUT | baseline FF | baseline RAMB18 |
|---|---|---|---|---|---|---|
| 2 | 4621 | 352 | 2371 | 1086 | 653 | 4 |
| 8 | 12378 | 1408 | 7063 | 2278 | 1445 | 16 |
| 32 | 43571 | 5632 | 25831 | 7010 | 4613 | 64 |

## Timing: ECP5 (LFE5U-85F-6) place & route, 4 lanes, pin-limited shell, 100 MHz requested, seeds 1-3

Fmax of the `clk` domain reported by nextpnr-ecp5. **This is not a Xilinx or Intel number.** The shell registers every input and output, so the figure bounds the DUT's internal register-to-register paths only.

| design | seed 1 | seed 2 | seed 3 | median (MHz) |
|---|---|---|---|---|
| banked_B2_L4 | 52.3 | 53.0 | 52.5 | 52.5 |
| banked_cu4_L4 | 64.1 | 58.5 | 61.7 | 61.7 |
| banked_default_L4 | 55.7 | 57.2 | 54.3 | 55.7 |
| banked_nofast_L4 | 58.2 | 65.7 | 60.5 | 60.5 |
| banked_wt0_L4 | 52.9 | 55.5 | 53.2 | 53.2 |
| baseline_L4 | 93.8 | 89.7 | 94.7 | 93.8 |

Critical path of the first banked run (nextpnr excerpt):

```
Info:       type curr  total name
Info:   clk-to-q  0.52  0.52 Source g_dut.dut.cu_row[3]_TRELLIS_FF_Q_5.Q
Info:    routing  1.16  1.68 Net g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_2_D_LUT4_Z_D_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D[0] (71,19) -> (73,21)
Info:                          Sink g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D_LUT4_Z.D
Info:                          Defined in:
Info:                               /share/lattice/cells_map_trellis.v:108.23-108.24
Info:      logic  0.24  1.92 Source g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D_LUT4_Z.F
Info:    routing  0.99  2.91 Net g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z_D[2] (73,21) -> (71,23)
Info:                          Sink g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z.D
Info:                          Defined in:
Info:                               /share/lattice/cells_map_trellis.v:108.23-108.24
Info:      logic  0.24  3.14 Source g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D_LUT4_Z.F
Info:    routing  0.63  3.78 Net g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_1_C_LUT4_D_Z_LUT4_Z_2_D[3] (71,23) -> (71,23)
Info:                          Sink g_dut.dut.cu_cls[2]_LUT4_C_D_PFUMX_Z_C0_LUT4_Z_2_C_LUT4_D_Z_LUT4_Z_C_LUT4_Z_1.D
```
