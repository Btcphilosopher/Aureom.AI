# Regression results

96 of 96 checks passed.

| scenario | case | result | detail |
|---|---|---|---|
| 1 one-bank | NB=1 (every access hits the same bank), hammer8 | PASS |  |
| 1 one-bank | NB=1 (every access hits the same bank), hammer8: contention really happened | PASS | conflict rate 83% |
| 1 one-bank | NB=1 (every access hits the same bank), hammer8: nothing dropped, bounded wait | PASS | max latency 9 <= 36; dispatched 3480/3480 |
| 1 one-bank | NB=1, uni_mixed | PASS |  |
| 1 one-bank | NB=1, uni_mixed: contention really happened | PASS | conflict rate 83% |
| 1 one-bank | NB=1, uni_mixed: nothing dropped, bounded wait | PASS | max latency 11 <= 36; dispatched 4352/4352 |
| 1 one-bank | NB=4 LOW map vs stride-8 registers (all in bank 0) | PASS |  |
| 1 one-bank | NB=4 LOW map vs stride-8 registers (all in bank 0): contention really happened | PASS | conflict rate 83% |
| 1 one-bank | NB=4 LOW map vs stride-8 registers (all in bank 0): nothing dropped, bounded wait | PASS | max latency 9 <= 36; dispatched 3480/3480 |
| 1 one-bank | NB=4 LOW map vs stride-4 registers | PASS |  |
| 1 one-bank | NB=4 LOW map vs stride-4 registers: contention really happened | PASS | conflict rate 85% |
| 1 one-bank | NB=4 LOW map vs stride-4 registers: nothing dropped, bounded wait | PASS | max latency 9 <= 36; dispatched 3512/3512 |
| 1 one-bank | NB=4 SKEW map vs stride-8 registers | PASS |  |
| 1 one-bank | NB=4 SKEW map vs stride-8 registers: contention really happened | PASS | conflict rate 30% |
| 1 one-bank | NB=4 SKEW map vs stride-8 registers: nothing dropped, bounded wait | PASS | max latency 4 <= 36; dispatched 3480/3480 |
| 1 one-bank | default XOR map spreads stride-8 registers (throughput vs LOW map) | PASS | IPC 0.994 vs 0.614 |
| 2 simultaneous writes | banked, ldburst | PASS |  |
| 2 simultaneous writes | banked, ldburst: write bank conflicts occurred and were back-pressured, none lost | PASS | bank conflicts 167, stalled port-cycles 167, accepted writes 3049==3049 |
| 2 simultaneous writes | banked, uni_full | PASS |  |
| 2 simultaneous writes | banked, uni_full: write bank conflicts occurred and were back-pressured, none lost | PASS | bank conflicts 83, stalled port-cycles 83, accepted writes 3060==3060 |
| 2 simultaneous writes | banked, uni_mixed | PASS |  |
| 2 simultaneous writes | banked, uni_mixed: write bank conflicts occurred and were back-pressured, none lost | PASS | bank conflicts 49, stalled port-cycles 49, accepted writes 2970==2970 |
| 2 simultaneous writes | banked, loopy | PASS |  |
| 2 simultaneous writes | banked, loopy: write bank conflicts occurred and were back-pressured, none lost | PASS | bank conflicts 144, stalled port-cycles 144, accepted writes 3035==3035 |
| 2 simultaneous writes | baseline (single write port), ldburst | PASS | stalled port-cycles 1258 |
| 2 simultaneous writes | baseline (single write port), uni_mixed | PASS | stalled port-cycles 336 |
| 2 simultaneous writes | stress matrix (same-row simultaneous writes, same-cycle read/write, resets, clears) | PASS | stress: 45 runs, 0 failures; coverage {'same': 10140, 'pair': 1723, 'bconf': 14979, 'part': 223878, 'empty': 116502, 'disp': 599670} |
| 3 dependent | dep1: banked and baseline both correct | PASS |  |
| 3 dependent | dep1: forwarding exercised on (nearly) every dependent hop | PASS | forwarded reads 373 / 658 instructions |
| 3 dependent | dep1: same dependent-chain throughput as the baseline | PASS | IPC 0.2575 vs 0.2575 |
| 3 dependent | dep8: banked and baseline both correct | PASS |  |
| 3 dependent | dep8: forwarding used | PASS | 337 forwarded reads |
| 3 dependent | loopy: banked and baseline both correct | PASS |  |
| 3 dependent | loopy: forwarding used | PASS | 777 forwarded reads |
| 3 dependent | dep1: WRITE_THROUGH=0 (SIMT front-end setting) correct and cycle-identical to WRITE_THROUGH=1 | PASS | cycles 2555 vs 2555, forwarded reads 373 |
| 3 dependent | loopy: WRITE_THROUGH=0 (SIMT front-end setting) correct and cycle-identical to WRITE_THROUGH=1 | PASS | cycles 4484 vs 4484, forwarded reads 777 |
| 3 dependent | uni_mixed: WRITE_THROUGH=0 (SIMT front-end setting) correct and cycle-identical to WRITE_THROUGH=1 | PASS | cycles 4359 vs 4359, forwarded reads 28 |
| 3 dependent | simt_rand: WRITE_THROUGH=0 (SIMT front-end setting) correct and cycle-identical to WRITE_THROUGH=1 | PASS | cycles 58212 vs 58212, forwarded reads 6576 |
| 4 partial masks | uni_mixed (35.9% of instructions partially masked, need >= 25%) | PASS |  |
| 4 partial masks | loopy (35.1% of instructions partially masked, need >= 25%) | PASS |  |
| 4 partial masks | simt_dir (7.3% of instructions partially masked, need >= 5%) | PASS |  |
| 4 partial masks | simt_rand (59.9% of instructions partially masked, need >= 40%) | PASS |  |
| 5 reset | uni_mixed: reset at cycle 150, 1-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 8;  |
| 5 reset | uni_mixed: reset at cycle 150, 2-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 8;  |
| 5 reset | uni_mixed: reset at cycle 150, 3-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 8;  |
| 5 reset | uni_mixed: reset at cycle 531, 1-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | uni_mixed: reset at cycle 531, 2-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | uni_mixed: reset at cycle 531, 3-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | uni_mixed: reset at cycle 1200, 1-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | uni_mixed: reset at cycle 1200, 2-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | uni_mixed: reset at cycle 1200, 3-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | simt_dir: reset at cycle 150, 1-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 6;  |
| 5 reset | simt_dir: reset at cycle 150, 2-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 6;  |
| 5 reset | simt_dir: reset at cycle 150, 3-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 6;  |
| 5 reset | simt_dir: reset at cycle 531, 1-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | simt_dir: reset at cycle 531, 2-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | simt_dir: reset at cycle 531, 3-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | simt_dir: reset at cycle 1200, 1-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | simt_dir: reset at cycle 1200, 2-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | simt_dir: reset at cycle 1200, 3-cycle pulse, trace restarts from zero state | PASS | in-flight at reset 7;  |
| 5 reset | baseline: same reset scenario | PASS |  |
| 6 stalls | MEM port stalled 900 cycles, pool flooded with loads (memflood): banked correct, nothing lost, recovers | PASS |  |
| 6 stalls | MEM port stalled 900 cycles, pool flooded with loads (memflood): back-pressure reached the front end (iss_ready fell) | PASS | issue-blocked cycles 615, units-full cycles 615, dispatch stalls 900 |
| 6 stalls | MEM port stalled 900 cycles, pool flooded with loads (memflood): baseline correct too | PASS |  |
| 6 stalls | MEM port stalled 900 cycles, pool flooded with loads: ALU work keeps flowing while MEM is stalled (banked) | PASS | 283 ALU dispatches in 900 stalled cycles (need >= 135); baseline 0 |
| 6 stalls | MEM port stalled 2000 cycles (memstall): banked correct, nothing lost, recovers | PASS |  |
| 6 stalls | MEM port stalled 2000 cycles (memstall): back-pressure reached the front end (iss_ready fell) | PASS | issue-blocked cycles 1370, units-full cycles 1370, dispatch stalls 1996 |
| 6 stalls | MEM port stalled 2000 cycles (memstall): baseline correct too | PASS |  |
| 6 stalls | MEM port stalled 2000 cycles: ALU work keeps flowing while MEM is stalled (banked) | PASS | 627 ALU dispatches in 2000 stalled cycles (need >= 300); baseline 3 |
| 6 stalls | ALU port stalled 1500 cycles (ldburst): banked correct, nothing lost, recovers | PASS |  |
| 6 stalls | ALU port stalled 1500 cycles (ldburst): back-pressure reached the front end (iss_ready fell) | PASS | issue-blocked cycles 1494, units-full cycles 1494, dispatch stalls 1500 |
| 6 stalls | ALU port stalled 1500 cycles (ldburst): baseline correct too | PASS |  |
| 6 stalls | BOTH ports stalled 3000 cycles (uni_mixed): banked correct, nothing lost, recovers | PASS |  |
| 6 stalls | BOTH ports stalled 3000 cycles (uni_mixed): back-pressure reached the front end (iss_ready fell) | PASS | issue-blocked cycles 2997, units-full cycles 2997, dispatch stalls 5998 |
| 6 stalls | BOTH ports stalled 3000 cycles (uni_mixed): baseline correct too | PASS |  |
| 6 stalls | periodic MEM stalls (900 of every 3000 cycles) (memstall): banked correct, nothing lost, recovers | PASS |  |
| 6 stalls | periodic MEM stalls (900 of every 3000 cycles) (memstall): back-pressure reached the front end (iss_ready fell) | PASS | issue-blocked cycles 3280, units-full cycles 618, dispatch stalls 3579 |
| 6 stalls | periodic MEM stalls (900 of every 3000 cycles) (memstall): baseline correct too | PASS |  |
| 6 stalls | slow sink: 20%/10% ready + 70% writeback bubbles (uni_mixed): banked correct, nothing lost, recovers | PASS |  |
| 6 stalls | slow sink: 20%/10% ready + 70% writeback bubbles (uni_mixed): back-pressure reached the front end (iss_ready fell) | PASS | issue-blocked cycles 13233, units-full cycles 9476, dispatch stalls 21599 |
| 6 stalls | slow sink: 20%/10% ready + 70% writeback bubbles (uni_mixed): baseline correct too | PASS |  |
| + mapping | bank map RTL == Python, bijective | PASS | bankmap: 4608 entries compared, 0 mismatches, bijective=True |
| + decode | SIMT decode adapter == sf_simt_pkg::sf_predecode (128k words) | PASS |  |
| + elaboration | illegal parameter NUM_BANKS=3 is rejected at elaboration | PASS |  |
| + elaboration | illegal parameter NUM_BANKS=64 is rejected at elaboration | PASS |  |
| + elaboration | illegal parameter BANK_MAP=5 is rejected at elaboration | PASS |  |
| + elaboration | illegal parameter NUM_CU=0 is rejected at elaboration | PASS |  |
| + elaboration | illegal parameter CLS_CAP=9 is rejected at elaboration | PASS |  |
| + lint | sf_rfc -Wall clean (defaults) | PASS |  |
| + lint | sf_rfc -Wall clean -GNUM_BANKS=1 -GBANK_MAP=0 | PASS |  |
| + lint | sf_rfc -Wall clean -GNUM_BANKS=2 -GRD_ARB=0 | PASS |  |
| + lint | sf_rfc -Wall clean -GNUM_BANKS=8 -GNUM_CU=8 -GRD_SHARE=1 -GFAST_READ=0 | PASS |  |
| + lint | sf_rfc -Wall clean -GNUM_BANKS=16 -GLANES=32 -GNUM_WARPS=3 -GNUM_CU=3 | PASS |  |
| + lint | sf_rfc -Wall clean -GNUM_CU=1 -GNUM_BANKS=1 -GLANES=1 -GNUM_WARPS=1 -GNUM_CLS=1 -GNUM_WB=1 | PASS |  |
| + lint | sf_rfc -Wall clean -GNUM_BANKS=32 -GNUM_WB=3 -GNUM_CU=2 -GRAM_STYLE=1 -GSTRICT=1 -GPERF_EN=0 -GWRITE_THROUGH=0 | PASS |  |
| + lint | sf_rf_base -Wall clean | PASS |  |
