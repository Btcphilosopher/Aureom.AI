# 32-lane simulation (8 warps, 1024-bit warp registers, 4 banks, XOR, 6 units)

| trace | instructions | banked ok | banked IPC | read conflict rate | baseline ok | baseline IPC |
|---|---|---|---|---|---|---|
| uni_mixed | 1552 | PASS | 0.994 | 10.9% | PASS | 0.995 |
| loopy | 1456 | PASS | 0.954 | 7.3% | PASS | 0.929 |
| hammer8 | 1240 | PASS | 0.994 | 0.0% | PASS | 0.994 |
| dep1 | 378 | PASS | 0.429 | 0.0% | PASS | 0.429 |
| ldburst | 1216 | PASS | 0.988 | 6.5% | PASS | 0.985 |
| memstall | 1760 | PASS | 0.745 | 10.1% | PASS | 0.745 |
| simt_dir | 2680 | PASS | 0.800 | 9.3% | PASS | 0.805 |
| simt_rand | 25006 | PASS | 0.896 | 9.9% | PASS | 0.891 |
