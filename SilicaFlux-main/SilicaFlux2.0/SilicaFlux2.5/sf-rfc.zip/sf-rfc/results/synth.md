# Synthesis results (Yosys 0.71 + slang; nextpnr-ecp5 0.11)

Utilisation = the design synthesised **standalone** (I/O not mapped to pads) with `PERF_EN=0` unless the row says otherwise. Cell counts are Yosys `stat` output; nothing here comes from Vivado/Quartus.

## Xilinx 7-series mapping (`synth_xilinx -family xc7`) -- utilisation only, no timing

| design | LUT | LUTRAM macros (RAM32M/RAM64M..) | LUTs used as RAM | FF | RAMB18/36 | CARRY4 | MUXF7/8 |
|---|---|---|---|---|---|---|---|
| baseline | 2278 | 0 | 0 | 1445 | 16/0 | 0 | 0/0 |
| banked_default | 12378 | 352 | 1408 | 7063 | 0/0 | 3 | 12/6 |
| banked_B1 | 5567 | 0 | 0 | 4401 | 8/0 | 3 | 6/2 |
| banked_B2 | 9962 | 0 | 0 | 4950 | 16/0 | 3 | 7/3 |
| banked_B8 | 26438 | 384 | 1536 | 10252 | 0/0 | 3 | 26/13 |
| banked_cu5 | 10536 | 352 | 1408 | 6461 | 0/0 | 3 | 2/1 |
| banked_cu4 | 9850 | 352 | 1408 | 5859 | 0/0 | 3 | 3/0 |
| banked_cu2 | 7423 | 352 | 1408 | 4660 | 0/0 | 0 | 0/0 |
| banked_nofast | 12231 | 352 | 1408 | 7039 | 0/0 | 3 | 3/1 |
| banked_share | 12586 | 352 | 1408 | 7063 | 0/0 | 3 | 32/13 |
| banked_wt0 | 11282 | 352 | 1408 | 7039 | 0/0 | 3 | 0/0 |
| banked_perf | 13281 | 352 | 1408 | 7585 | 0/0 | 254 | 3/1 |
| banked_ram_block | 12326 | 0 | 0 | 6039 | 32/0 | 3 | 7/3 |
| banked_ram_dist | 12378 | 352 | 1408 | 7063 | 0/0 | 3 | 12/6 |
| baseline_ram_dist | 2901 | 704 | 2816 | 1957 | 0/0 | 0 | 1/0 |
| baseline_ram_block | 2278 | 0 | 0 | 1445 | 16/0 | 0 | 0/0 |
| banked_default_L32 | 43571 | 1408 | 5632 | 25831 | 0/0 | 3 | 2/1 |
| baseline_L32 | 7010 | 0 | 0 | 4613 | 64/0 | 0 | 0/0 |
| banked_default_L2 | 4621 | 88 | 352 | 2371 | 0/0 | 3 | 22/7 |
| baseline_L2 | 1086 | 0 | 0 | 653 | 4/0 | 0 | 0/0 |
| module_bank_64rows | 959 | 88 | 352 | 864 | 0/0 | 0 | 0/0 |
| module_bank_256rows | 1335 | 0 | 0 | 804 | 8/0 | 0 | 0/0 |
| module_bank_64rows_wt0 | 697 | 88 | 352 | 858 | 0/0 | 0 | 0/0 |

## Lattice ECP5 mapping (`synth_ecp5`)

| design | LUT4 | FF | DPR16X4 (distributed RAM) | DP16KD (block RAM) | CCU2C |
|---|---|---|---|---|---|
| baseline | 3475 | 1989 | 0 | 16 | 0 |
| banked_default | 20915 | 8175 | 0 | 32 | 0 |
| banked_B1 | 7643 | 4937 | 0 | 8 | 0 |
| banked_B2 | 11960 | 6020 | 0 | 16 | 0 |
| banked_B8 | 34556 | 10252 | 1024 | 0 | 0 |
| banked_cu5 | 18042 | 7573 | 0 | 32 | 0 |
| banked_cu4 | 15977 | 6971 | 0 | 32 | 0 |
| banked_cu2 | 10099 | 5772 | 0 | 32 | 0 |
| banked_nofast | 20586 | 8151 | 0 | 32 | 0 |
| banked_share | 21370 | 8175 | 0 | 32 | 0 |
| banked_wt0 | 19768 | 8151 | 0 | 32 | 0 |
| banked_perf | 20984 | 8697 | 0 | 32 | 376 |
| banked_ram_block | 20915 | 8175 | 0 | 32 | 0 |
| banked_ram_dist | 24080 | 7063 | 1024 | 0 | 0 |
| baseline_ram_dist | 9998 | 1957 | 2048 | 0 | 0 |
| baseline_ram_block | 3475 | 1989 | 0 | 16 | 0 |
| banked_default_L32 | 73658 | 30207 | 0 | 128 | 0 |
| baseline_L32 | 8816 | 6765 | 0 | 64 | 0 |
| banked_default_L2 | 7609 | 2667 | 0 | 8 | 0 |
| baseline_L2 | 1825 | 795 | 0 | 4 | 0 |
| module_bank_64rows | 1071 | 1142 | 0 | 8 | 0 |
| module_bank_256rows | 1603 | 1340 | 0 | 8 | 0 |
| module_bank_64rows_wt0 | 800 | 1136 | 0 | 8 | 0 |

## Timing: ECP5 (LFE5U-85F-6) post place & route, pin-limited shell, 100 MHz requested

| design | seed 1 | seed 2 | seed 3 | median Fmax (MHz) |
|---|---|---|---|---|
| banked_B2_L4 | 52.3 | 53.0 | 52.5 | 52.5 |
| banked_cu4_L4 | 64.1 | 58.5 | 61.7 | 61.7 |
| banked_default_L4 | 55.7 | 57.2 | 54.3 | 55.7 |
| banked_nofast_L4 | 58.2 | 65.7 | 60.5 | 60.5 |
| banked_wt0_L4 | 52.9 | 55.5 | 53.2 | 53.2 |
| baseline_L4 | 93.8 | 89.7 | 94.7 | 93.8 |
