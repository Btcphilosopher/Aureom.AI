// =============================================================================
//  sf_simt_rfc_top -- REFERENCE INTEGRATION: the SilicaFlux SIMT control unit + banked register file / collector.
//
//  Connects sf_simt_ctrl (third_party, unchanged) to sf_rfc through sf_rfc_simt_dec exactly as documented in
//  docs/ARCHITECTURE.md s.13.  The execution units are NOT included: this module exports their two dispatch channels
//  (operand rows, effective mask, payload = {wg, widx, pc, instr}) and takes their two writeback records.
//  Status: elaborated and lint-checked with Verilator against the unmodified SIMT RTL (type/width/direction check of
//  the mapping).  It has NOT been co-simulated -- see docs/ARCHITECTURE.md s.14.
// =============================================================================
`default_nettype none
module sf_simt_rfc_top
  import sf_simt_pkg::*;
#(
  parameter int unsigned NUM_WARPS = 8,
  parameter int unsigned WARP_SIZE = 8,           // = sf_rfc LANES
  parameter int unsigned PC_W      = 16,
  parameter int unsigned STACK_DEPTH = 8,
  parameter int unsigned NUM_SLOTS = 4,
  parameter int unsigned NUM_BANKS = 4,
  parameter int unsigned BANK_MAP  = 2,
  parameter int unsigned NUM_CU    = 6,
  localparam int unsigned WID_W    = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1,
  localparam int unsigned SLOT_W   = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1,
  localparam int unsigned PAY_W    = 32 + PC_W + 2 * WID_W,
  localparam int unsigned W        = WARP_SIZE * 32
) (
  input  logic                                clk_i,
  input  logic                                rst_ni,
  // kernel launch / status (straight through)
  input  logic                                launch_valid_i,
  output logic                                launch_ready_o,
  input  logic [PC_W-1:0]                     launch_pc_i,
  input  logic [$clog2(NUM_WARPS+1)-1:0]      launch_num_wg_i,
  input  logic [$clog2(NUM_WARPS+1)-1:0]      launch_wpw_i,
  input  logic [$clog2(WARP_SIZE+1)-1:0]      launch_last_threads_i,
  input  logic [$clog2(STACK_DEPTH+1)-1:0]    launch_stack_need_i,
  output logic                                busy_o,
  output logic                                kernel_done_o,
  output logic                                kernel_fault_o,
  // instruction fetch (straight through)
  output logic                                if_req_valid_o,
  input  logic                                if_req_ready_i,
  output logic [WID_W-1:0]                    if_req_warp_o,
  output logic [PC_W-1:0]                     if_req_pc_o,
  input  logic                                if_rsp_valid_i,
  input  logic [WID_W-1:0]                    if_rsp_warp_i,
  input  logic [PC_W-1:0]                     if_rsp_pc_i,
  input  logic [31:0]                         if_rsp_instr_i,
  input  logic                                if_rsp_err_i,
  // execution units: dispatch (class 0 = ALU port, 1 = MEM port)
  output logic [1:0]                          dsp_valid_o,
  input  logic [1:0]                          dsp_ready_i,
  output logic [WID_W-1:0]                    dsp_warp_o    [2],
  output logic [SLOT_W-1:0]                   dsp_slot_o    [2],
  output logic [WARP_SIZE-1:0]                dsp_mask_o    [2],
  output logic [PAY_W-1:0]                    dsp_payload_o [2],     // {wg, widx, pc, instr}
  output logic [4:0]                          dsp_rd_o      [2],
  output logic                                dsp_wr_o      [2],
  output logic [W-1:0]                        dsp_op1_o     [2],
  output logic [W-1:0]                        dsp_op2_o     [2],
  // execution units: writeback
  input  logic [1:0]                          wb_valid_i,
  output logic [1:0]                          wb_ready_o,
  input  logic [WID_W-1:0]                    wb_warp_i     [2],
  input  logic [SLOT_W-1:0]                   wb_slot_i     [2],
  input  logic                                wb_we_i       [2],
  input  logic [4:0]                          wb_rd_i       [2],
  input  logic [WARP_SIZE-1:0]                wb_mask_i     [2],
  input  logic [W-1:0]                        wb_data_i     [2],
  input  logic [WARP_SIZE-1:0]                wb_taken_i    [2],
  // a kernel launch zeroes the registers of every warp (quiescent: the control unit is idle between kernels)
  output logic                                rf_idle_o
);
  // ---- control unit
  logic                 iss_valid, iss_port;
  logic [1:0]           iss_ready;
  logic [WID_W-1:0]     iss_warp, iss_wg, iss_widx;
  logic [SLOT_W-1:0]    iss_slot;
  logic [PC_W-1:0]      iss_pc;
  logic [WARP_SIZE-1:0] iss_mask;
  logic [31:0]          iss_instr;
  logic [1:0]           cmpl_valid;
  logic [WID_W-1:0]     cmpl_warp  [2];
  logic [SLOT_W-1:0]    cmpl_slot  [2];
  logic [WARP_SIZE-1:0] cmpl_taken [2];
  logic [31:0]          ctrl_perf [PERF_N];
  logic                 err_proto, err_assert;

  sf_simt_ctrl #(.NUM_WARPS(NUM_WARPS), .WARP_SIZE(WARP_SIZE), .PC_W(PC_W), .STACK_DEPTH(STACK_DEPTH), .NUM_SLOTS(NUM_SLOTS)) u_ctrl (
    .clk_i, .rst_ni,
    .launch_valid_i, .launch_ready_o, .launch_pc_i, .launch_num_wg_i, .launch_wpw_i, .launch_last_threads_i, .launch_stack_need_i,
    .launch_reject_o(), .launch_reject_cause_o(),
    .busy_o, .kernel_done_o, .kernel_fault_o,
    .if_req_valid_o, .if_req_ready_i, .if_req_warp_o, .if_req_pc_o,
    .if_rsp_valid_i, .if_rsp_warp_i, .if_rsp_pc_i, .if_rsp_instr_i, .if_rsp_err_i,
    .iss_valid_o(iss_valid), .iss_port_o(iss_port), .iss_ready_i(iss_ready), .iss_warp_o(iss_warp), .iss_slot_o(iss_slot),
    .iss_pc_o(iss_pc), .iss_mask_o(iss_mask), .iss_instr_o(iss_instr), .iss_wg_o(iss_wg), .iss_widx_o(iss_widx),
    .cmpl_valid_i(cmpl_valid), .cmpl_warp_i(cmpl_warp), .cmpl_slot_i(cmpl_slot), .cmpl_taken_i(cmpl_taken),
    .cfg_check_struct_i(1'b0), .perf_clear_i(1'b0), .perf_o(ctrl_perf),
    .ev_issue_o(), .ev_exec_o(), .ev_warp_o(), .ev_pc_o(), .ev_mask_o(), .ev_instr_o(), .ev_fill_o(),
    .sched_cand_o(), .sched_elig_o(), .sched_grant_o(), .wg_release_o(), .core_run_o(),
    .warp_state_o(), .warp_class_o(), .warp_pc_o(), .warp_active_o(), .warp_live_o(), .warp_sp_o(), .warp_wg_o(), .warp_fault_o(),
    .err_proto_o(err_proto), .err_assert_o(err_assert));

  // ---- decode + register file / collector
  logic        d_use1, d_use2, d_wr, d_mem;
  logic [4:0]  d_rs1, d_rs2, d_rd;
  sf_rfc_simt_dec u_dec (.instr_i(iss_instr), .use1_o(d_use1), .use2_o(d_use2), .wr_o(d_wr), .rs1_o(d_rs1), .rs2_o(d_rs2), .rd_o(d_rd), .mem_o(d_mem));

  logic [31:0] rf_perf [sf_rfc_pkg::PERF_N];
  logic [1:0]  rf_cmpl_valid;
  sf_rfc #(.NUM_WARPS(NUM_WARPS), .LANES(WARP_SIZE), .NUM_BANKS(NUM_BANKS), .BANK_MAP(BANK_MAP), .NUM_CU(NUM_CU),
           .NUM_CLS(2), .NUM_WB(2), .TAG_W(SLOT_W), .PAYLOAD_W(PAY_W), .AUX_W(WARP_SIZE),
           // sf_simt_ctrl clears its scoreboard bit one cycle after completion: a consumer never launches in the producer's
           // acceptance cycle, so the same-cycle write-through overlay is unreachable (docs/ARCHITECTURE.md s.4) and is left out
           .WRITE_THROUGH(1'b0)) u_rf (
    .clk(clk_i), .rst_n(rst_ni), .clr_all_i(1'b0), .clr_warp_i('0), .idle_o(rf_idle_o),
    .iss_valid_i(iss_valid), .iss_ready_o(iss_ready), .iss_cls_i(iss_port), .iss_warp_i(iss_warp), .iss_tag_i(iss_slot),
    .iss_mask_i(iss_mask), .iss_use1_i(d_use1), .iss_use2_i(d_use2), .iss_rs1_i(d_rs1), .iss_rs2_i(d_rs2),
    .iss_wr_i(d_wr), .iss_rd_i(d_rd), .iss_payload_i({iss_wg, iss_widx, iss_pc, iss_instr}),
    .dsp_valid_o, .dsp_ready_i, .dsp_warp_o, .dsp_tag_o(dsp_slot_o), .dsp_mask_o, .dsp_wr_o, .dsp_rd_o, .dsp_payload_o, .dsp_op1_o, .dsp_op2_o,
    .wb_valid_i, .wb_ready_o, .wb_warp_i, .wb_tag_i(wb_slot_i), .wb_we_i, .wb_rd_i, .wb_mask_i, .wb_data_i, .wb_aux_i(wb_taken_i),
    .cmpl_valid_o(rf_cmpl_valid), .cmpl_warp_o(cmpl_warp), .cmpl_tag_o(cmpl_slot), .cmpl_aux_o(cmpl_taken),
    .perf_clear_i(1'b0), .perf_o(rf_perf), .mon_alloc_o(), .mon_req_o(), .mon_gnt_o(), .mon_rq_warp_o(), .mon_rq_reg_o(), .mon_dsp_cu_o());
  assign cmpl_valid = rf_cmpl_valid;
endmodule
`default_nettype wire
