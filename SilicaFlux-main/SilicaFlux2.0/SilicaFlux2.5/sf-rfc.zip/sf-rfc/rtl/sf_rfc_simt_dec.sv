// =============================================================================
//  sf_rfc_simt_dec -- operand-use descriptor of one SilicaFlux SFT-1 instruction word (combinational).
//
//  Connects sf_simt_ctrl's issue bus to sf_rfc:   iss_instr_o -> this decoder -> iss_use1/iss_use2/iss_rs1/iss_rs2/
//  iss_wr/iss_rd,   iss_port_o -> iss_cls_i,   iss_slot_o -> iss_tag_i,   iss_warp_o/iss_mask_o -> iss_warp_i/iss_mask_i,
//  iss_instr_o -> iss_payload_i.   Completion: cmpl_{valid,warp,slot,taken}_i <- cmpl_{valid,warp,tag,aux}_o.
//
//  Field layout (sfisa.py / sf_simt_pkg.sv):  [26:22] rd  [21:17] rs1  [16:12] rs2.  A store's data register is rs2.
//  r0 is NOT filtered here (sf_rfc elides r0 reads and discards r0 writes itself); `use`/`wr` say only whether the
//  instruction has that operand.  Control-unit-local opcodes 0x00-0x05 (nop exit ssy sync bar jmp) never reach the
//  backend, so they decode as "no operands".  tb_decode_xcheck compares this module with sf_simt_pkg::sf_predecode
//  for every opcode.
// =============================================================================
`default_nettype none
module sf_rfc_simt_dec (
  input  logic [31:0] instr_i,
  output logic        use1_o,
  output logic        use2_o,
  output logic        wr_o,
  output logic [4:0]  rs1_o,
  output logic [4:0]  rs2_o,
  output logic [4:0]  rd_o,
  output logic        mem_o      // 1 = MEM port (ldg stg lds sts), 0 = ALU port
);
  assign rd_o  = instr_i[26:22];
  assign rs1_o = instr_i[21:17];
  assign rs2_o = instr_i[16:12];

  always_comb begin
    use1_o = 1'b0;
    use2_o = 1'b0;
    wr_o   = 1'b0;
    mem_o  = 1'b0;
    case (instr_i[31:27])
      5'h06, 5'h07: begin use1_o = 1'b1; end                                   // bnz, bz
      5'h08, 5'h09, 5'h0A, 5'h0B, 5'h0C, 5'h0D, 5'h0E, 5'h0F, 5'h10, 5'h11, 5'h12:
                    begin use1_o = 1'b1; use2_o = 1'b1; wr_o = 1'b1; end       // add .. sltu
      5'h13:        begin use1_o = 1'b1; wr_o = 1'b1; end                      // addi
      5'h14, 5'h15: begin wr_o = 1'b1; end                                     // lui, s2r
      5'h18, 5'h1A: begin use1_o = 1'b1; wr_o = 1'b1; mem_o = 1'b1; end        // ldg, lds
      5'h19, 5'h1B: begin use1_o = 1'b1; use2_o = 1'b1; mem_o = 1'b1; end      // stg, sts
      default: ;
    endcase
  end
endmodule
`default_nettype wire
