// =============================================================================
//  sf_rfc -- banked register file + per-instruction operand collector for the SilicaFlux SIMT core.
//
//  Specification: docs/ARCHITECTURE.md.  Summary of the contract (read it before integrating):
//
//  ISSUE   (front end -> here, at most one instruction per cycle)
//    iss_ready_o[c] is a function of REGISTERED state only (never of iss_*), as sf_simt_ctrl requires (D1).
//    On iss_valid_i && iss_ready_o[iss_cls_i] a collector unit (CU) is allocated for the instruction.
//    The front end's scoreboard must already guarantee RAW/WAW freedom (same contract as sf_simt_ctrl).
//    WAR freedom is provided HERE: operands are no longer sampled at the issue handshake but later, so the
//    CUs of one warp dispatch strictly in issue order (s.6) -- a younger instruction can never write a register
//    an older, still-collecting instruction of the same warp has yet to read.
//  COLLECT (per instruction)
//    Each CU holds one instruction and up to two operand slots.  A slot needs a bank read only if the
//    instruction uses it, its register is not r0, the mask is not empty and it is not a duplicate of slot 1.
//    Not-needed operands are delivered as ZERO.  Requests are arbitrated per bank (one read port per bank per
//    cycle); a loser keeps its request and retries -- nothing is ever dropped, conflicts only cost cycles.
//  DISPATCH (here -> execution units, one valid/ready channel per class = backend port)
//    Oldest-ready-first among the CUs of a class that are complete and not held by the in-order rule; once
//    dsp_valid_o is raised the choice (and every payload bit) is held until dsp_ready_i (no retraction).
//  WRITEBACK (execution units -> here, NUM_WB ports, valid/ready)
//    A port with a register write competes for the write port of its destination bank.  Accepted writes
//    apply a per-lane mask (lanes outside the mask are never touched).  A loser sees wb_ready_o = 0 and must
//    hold its record (back-pressure) -- nothing is dropped.  Records without a register write (stores,
//    branches, r0 or empty-mask results) are always accepted; each accepted record raises cmpl_valid_o for
//    exactly that cycle, which is the architectural completion (the write is visible from this cycle on).
//  SAME-CYCLE READ/WRITE: a read launched in cycle t sees every write accepted in cycles <= t (write-through),
//    per lane; see sf_rfc_bank.sv.  Reads and writes of one bank use separate ports and never block each other.
//  RESET: rst_n (synchronous, active low) drops all in-flight work and makes every register read as zero
//    (lazy-zero "clean" bits, no clear sequencer, no busy period).  clr_all_i / clr_warp_i do the same for the
//    whole file / one warp, from the next cycle, and must only be used while that part is quiescent.
// =============================================================================
`default_nettype none

module sf_rfc
  import sf_rfc_pkg::*;
#(
  parameter int unsigned NUM_WARPS = 8,
  parameter int unsigned LANES     = 8,            // warp width (SF-G1: LANES, SIMT: WARP_SIZE)
  parameter int unsigned NUM_BANKS = 4,            // power of two, 1..32
  parameter int unsigned BANK_MAP  = 2,            // 0 LOW, 1 SKEW, 2 XOR  (sf_rfc_pkg.sv); XOR measured best, docs/RESULTS.md
  parameter int unsigned NUM_CU    = 6,            // collector units (a unit is occupied ~4 cycles: >= 5 needed for 1 IPC)
  parameter int unsigned NUM_CLS   = 2,            // dispatch classes (ports): 0 ALU, 1 MEM
  parameter int unsigned NUM_WB    = 2,            // writeback / completion ports
  parameter int unsigned RD_ARB    = 1,            // bank read arbitration: 0 round robin, 1 oldest first
  parameter bit          RD_SHARE  = 1'b0,         // co-grant requests for the same row in one bank read (measured hit rate ~0%)
  parameter bit          FAST_READ = 1'b1,         // first read attempt in the allocation cycle
  parameter bit          WRITE_THROUGH = 1'b1,     // read launched in the cycle a write is accepted sees it (needs a front end that can
                                                   // issue a consumer in the producer's completion cycle; 0 saves the overlay mux)
  parameter int unsigned CLS_CAP   = (NUM_CLS > 1 && NUM_CU > 1) ? NUM_CU - 1 : NUM_CU,  // max CUs per class
  parameter int unsigned TAG_W     = 4,
  parameter int unsigned PAYLOAD_W = 32,
  parameter int unsigned AUX_W     = LANES,        // completion sideband (e.g. branch taken mask)
  parameter int unsigned RAM_STYLE = 0,            // 0 auto, 1 block, 2 distributed
  parameter bit          STRICT    = 1'b0,         // simulation: enable front-end-contract assertions (WAR etc.)
  parameter bit          PERF_EN   = 1'b1,
  localparam int unsigned XLEN     = 32,
  localparam int unsigned W        = LANES * XLEN,
  localparam int unsigned WARP_W   = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1,
  localparam int unsigned CLS_W    = (NUM_CLS > 1) ? $clog2(NUM_CLS) : 1,
  localparam int unsigned NREQ     = 2 * NUM_CU,
  localparam int unsigned CU_W     = (NUM_CU > 1) ? $clog2(NUM_CU) : 1
) (
  input  logic                     clk,
  input  logic                     rst_n,
  // maintenance
  input  logic                     clr_all_i,
  input  logic [NUM_WARPS-1:0]     clr_warp_i,
  output logic                     idle_o,
  // issue
  input  logic                     iss_valid_i,
  output logic [NUM_CLS-1:0]       iss_ready_o,
  input  logic [CLS_W-1:0]         iss_cls_i,
  input  logic [WARP_W-1:0]        iss_warp_i,
  input  logic [TAG_W-1:0]         iss_tag_i,
  input  logic [LANES-1:0]         iss_mask_i,
  input  logic                     iss_use1_i,
  input  logic                     iss_use2_i,
  input  logic [4:0]               iss_rs1_i,
  input  logic [4:0]               iss_rs2_i,
  input  logic                     iss_wr_i,
  input  logic [4:0]               iss_rd_i,
  input  logic [PAYLOAD_W-1:0]     iss_payload_i,
  // dispatch (one channel per class)
  output logic [NUM_CLS-1:0]       dsp_valid_o,
  input  logic [NUM_CLS-1:0]       dsp_ready_i,
  output logic [WARP_W-1:0]        dsp_warp_o    [NUM_CLS],
  output logic [TAG_W-1:0]         dsp_tag_o     [NUM_CLS],
  output logic [LANES-1:0]         dsp_mask_o    [NUM_CLS],
  output logic                     dsp_wr_o      [NUM_CLS],
  output logic [4:0]               dsp_rd_o      [NUM_CLS],
  output logic [PAYLOAD_W-1:0]     dsp_payload_o [NUM_CLS],
  output logic [W-1:0]             dsp_op1_o     [NUM_CLS],
  output logic [W-1:0]             dsp_op2_o     [NUM_CLS],
  // writeback
  input  logic [NUM_WB-1:0]        wb_valid_i,
  output logic [NUM_WB-1:0]        wb_ready_o,
  input  logic [WARP_W-1:0]        wb_warp_i     [NUM_WB],
  input  logic [TAG_W-1:0]         wb_tag_i      [NUM_WB],
  input  logic                     wb_we_i       [NUM_WB],
  input  logic [4:0]               wb_rd_i       [NUM_WB],
  input  logic [LANES-1:0]         wb_mask_i     [NUM_WB],
  input  logic [W-1:0]             wb_data_i     [NUM_WB],
  input  logic [AUX_W-1:0]         wb_aux_i      [NUM_WB],
  // completion (valid exactly in the acceptance cycle)
  output logic [NUM_WB-1:0]        cmpl_valid_o,
  output logic [WARP_W-1:0]        cmpl_warp_o   [NUM_WB],
  output logic [TAG_W-1:0]         cmpl_tag_o    [NUM_WB],
  output logic [AUX_W-1:0]         cmpl_aux_o    [NUM_WB],
  // counters
  /* verilator lint_off UNUSEDSIGNAL */
  input  logic                     perf_clear_i,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]              perf_o        [PERF_N],
  // monitor (verification / observability; unconnected in synthesis)
  output logic [NUM_CU-1:0]        mon_alloc_o,
  output logic [NREQ-1:0]          mon_req_o,
  output logic [NREQ-1:0]          mon_gnt_o,
  output logic [WARP_W-1:0]        mon_rq_warp_o [NREQ],
  output logic [4:0]               mon_rq_reg_o  [NREQ],
  output logic [CU_W-1:0]          mon_dsp_cu_o  [NUM_CLS]
);

  localparam int unsigned BW   = clog2f(NUM_BANKS);
  localparam int unsigned BW1  = (BW > 0) ? BW : 1;
  localparam int unsigned RPW  = 32 >> BW;                       // rows per warp per bank
  localparam int unsigned ROWS = NUM_WARPS * RPW;
  localparam int unsigned AW   = (ROWS > 1) ? $clog2(ROWS) : 1;
  localparam int unsigned RQ_W = (NREQ > 1) ? $clog2(NREQ) : 1;
  localparam int unsigned WB_W = (NUM_WB > 1) ? $clog2(NUM_WB) : 1;

  // ---------------------------------------------------------------- elaboration checks
  if (NUM_BANKS < 1 || NUM_BANKS > 32 || (NUM_BANKS & (NUM_BANKS - 1)) != 0) begin : g_chk_nb
    $fatal(1, "sf_rfc: NUM_BANKS must be a power of two in 1..32");
  end
  if (BANK_MAP > 2) begin : g_chk_map
    $fatal(1, "sf_rfc: BANK_MAP must be 0, 1 or 2");
  end
  if (NUM_CU < 1 || NUM_CLS < 1 || NUM_WB < 1 || LANES < 1 || NUM_WARPS < 1) begin : g_chk_dims
    $fatal(1, "sf_rfc: NUM_CU/NUM_CLS/NUM_WB/LANES/NUM_WARPS must be >= 1");
  end
  if (CLS_CAP < 1 || CLS_CAP > NUM_CU) begin : g_chk_cap
    $fatal(1, "sf_rfc: CLS_CAP must be in 1..NUM_CU");
  end

  // ---------------------------------------------------------------- mapping (sf_rfc_pkg)
  function automatic logic [BW1-1:0] bank_of(input logic [WARP_W-1:0] w, input logic [4:0] r);
    return BW1'(f_bank(BANK_MAP, BW, 5'(w), r));
  endfunction

  function automatic logic [AW-1:0] row_of(input logic [WARP_W-1:0] w, input logic [4:0] r);
    return AW'(int'(w) * RPW) + AW'(r >> BW);
  endfunction

  // ---------------------------------------------------------------- collector-unit state
  logic [NUM_CU-1:0]    cu_v;                       // allocated, not yet dispatched
  logic [CLS_W-1:0]     cu_cls    [NUM_CU];
  logic [WARP_W-1:0]    cu_warp   [NUM_CU];
  logic [TAG_W-1:0]     cu_tag    [NUM_CU];
  logic [LANES-1:0]     cu_mask   [NUM_CU];
  logic [4:0]           cu_rd     [NUM_CU];
  logic                 cu_wr     [NUM_CU];
  logic [PAYLOAD_W-1:0] cu_pay    [NUM_CU];
  logic [4:0]           cu_rs     [NUM_CU][2];
  logic [BW1-1:0]       cu_bank   [NUM_CU][2];
  logic [AW-1:0]        cu_row    [NUM_CU][2];
  logic [NUM_CU-1:0]    cu_alias;                   // slot 2 follows slot 1 (same register)
  /* verilator lint_off UNUSEDSIGNAL */   // used only by some option combinations (RD_ARB, PERF_EN)
  logic [NUM_CU-1:0]    cu_conf;                    // perf: denied at least once
  logic [NUM_CU-1:0]    st_rq [2];                  // slot has a pending (not yet granted) read request
  logic [NUM_CU-1:0]    st_fl [2];                  // read launched last cycle; data is captured this cycle
  logic [W-1:0]         cu_data   [NUM_CU][2];
  logic [NUM_CU-1:0]    older_q   [NUM_CU];         // older_q[a][d] = unit d was allocated before unit a

  // ---------------------------------------------------------------- incoming instruction
  logic                 n_mz, n_alias;
  logic [1:0]           n_need;
  logic [BW1-1:0]       n_bank [2];
  logic [AW-1:0]        n_row  [2];

  always_comb begin
    n_mz      = ~|iss_mask_i;
    n_need[0] = iss_use1_i & (iss_rs1_i != 5'd0) & ~n_mz;
    n_alias   = n_need[0] & iss_use2_i & (iss_rs2_i == iss_rs1_i);
    n_need[1] = iss_use2_i & (iss_rs2_i != 5'd0) & ~n_mz & ~n_alias;
    n_bank[0] = bank_of(iss_warp_i, iss_rs1_i);
    n_row[0]  = row_of(iss_warp_i, iss_rs1_i);
    n_bank[1] = n_alias ? n_bank[0] : bank_of(iss_warp_i, iss_rs2_i);
    n_row[1]  = n_alias ? n_row[0]  : row_of(iss_warp_i, iss_rs2_i);
  end

  // ---------------------------------------------------------------- allocation / issue backpressure
  logic [NUM_CU-1:0]  alloc_oh;
  logic               iss_fire;

  logic [CU_W-1:0] ff_idx;                          // lowest free unit

  // Readiness is REGISTERED.  The occupancy of each class and the number of free units change by at most one per class per
  // cycle (one allocation, one dispatch per class), so they are kept in counters and the next cycle's readiness is computed from
  // their next values.  This is exactly "a unit is free and fewer than CLS_CAP units of the class are allocated", evaluated one
  // cycle early; a simulation assertion (below) checks it against the direct combinational definition every cycle.  It makes
  // iss_ready_o a flip-flop output (sf_simt_ctrl rule D1 holds trivially) and removes the per-class population count from the
  // allocation -> read-request -> arbitration path.
  localparam int unsigned CNT_W = $clog2(NUM_CU + 1);
  logic [CNT_W-1:0]   occ_q [NUM_CLS];
  logic [CNT_W-1:0]   free_q;
  logic [NUM_CLS-1:0] room_q, room_n;
  logic [CNT_W-1:0]   occ_n [NUM_CLS];
  logic [CNT_W-1:0]   free_n;

  always_comb begin
    int unsigned nd;
    nd = 0;
    for (int p = 0; p < NUM_CLS; p++) begin
      occ_n[p] = occ_q[p] + CNT_W'((iss_fire && (int'(iss_cls_i) == p)) ? 1 : 0) - CNT_W'((dsp_valid_o[p] && dsp_ready_i[p]) ? 1 : 0);
      if (dsp_valid_o[p] && dsp_ready_i[p]) nd++;
    end
    free_n = free_q - CNT_W'(iss_fire ? 1 : 0) + CNT_W'(nd);
    for (int p = 0; p < NUM_CLS; p++) room_n[p] = (free_n != '0) && (int'(occ_n[p]) < CLS_CAP);
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int p = 0; p < NUM_CLS; p++) occ_q[p] <= '0;
      free_q <= CNT_W'(NUM_CU);
      room_q <= '1;
    end else begin
      for (int p = 0; p < NUM_CLS; p++) occ_q[p] <= occ_n[p];
      free_q <= free_n;
      room_q <= room_n;
    end
  end

  always_comb begin
    ff_idx = '0;
    for (int c = NUM_CU - 1; c >= 0; c--) if (!cu_v[c]) ff_idx = CU_W'(c);
    iss_ready_o = room_q & {NUM_CLS{rst_n}};              // flip-flop outputs: no transfer completes while in reset
  end

  always_comb begin
    iss_fire = iss_valid_i && (int'(iss_cls_i) < NUM_CLS) && iss_ready_o[iss_cls_i];
    alloc_oh = '0;
    if (iss_fire) alloc_oh[ff_idx] = 1'b1;
  end

  // ---------------------------------------------------------------- effective read requests (r = 2*c + s)
  logic [NREQ-1:0]   req_eff, gnt_vec;
  logic [BW1-1:0]    rq_bank [NREQ];
  logic [AW-1:0]     rq_row  [NREQ];
  logic [NUM_CU-1:0] older_eff [NUM_CU];            // older_eff[a][d]: d is older than a, as seen by the arbiter

  always_comb begin
    for (int c = 0; c < NUM_CU; c++) begin
      for (int s = 0; s < 2; s++) begin
        logic nw;
        nw = FAST_READ && alloc_oh[c];
        req_eff[2*c+s]       = st_rq[s][c] | (nw & n_need[s]);
        rq_bank[2*c+s]       = nw ? n_bank[s] : cu_bank[c][s];
        rq_row[2*c+s]        = nw ? n_row[s]  : cu_row[c][s];
        mon_rq_warp_o[2*c+s] = nw ? iss_warp_i : cu_warp[c];
        mon_rq_reg_o[2*c+s]  = nw ? ((s == 0) ? iss_rs1_i : iss_rs2_i) : cu_rs[c][s];
      end
      for (int d = 0; d < NUM_CU; d++) begin
        if (c == d)                          older_eff[c][d] = 1'b0;
        else if (FAST_READ && alloc_oh[c])   older_eff[c][d] = cu_v[d];      // the new unit is the youngest
        else if (FAST_READ && alloc_oh[d])   older_eff[c][d] = 1'b0;
        else                                 older_eff[c][d] = older_q[c][d];
      end
    end
  end

  // ---------------------------------------------------------------- bank read arbitration
  logic [W-1:0]          bank_rd   [NUM_BANKS];
  logic [NUM_BANKS-1:0]  bank_hit, bank_idle;
  logic [NREQ-1:0]       gnt_b     [NUM_BANKS];
  logic [NREQ-1:0]       mb_b      [NUM_BANKS];
  logic [NUM_BANKS-1:0]  rd_en_b;
  logic [AW-1:0]         rd_row_b  [NUM_BANKS];

  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_rd
    logic [NREQ-1:0] mb, win, cog;
    logic [AW-1:0]   wrow;

    always_comb begin
      mb = '0;
      for (int r = 0; r < NREQ; r++) mb[r] = req_eff[r] && (rq_bank[r] == BW1'(b));
    end

    if (RD_ARB == 0) begin : g_rr
      logic [RQ_W-1:0] ptr;
      always_comb begin
        logic found;
        win   = '0;
        found = 1'b0;
        for (int k = 0; k < NREQ; k++) begin
          logic [RQ_W-1:0] idx;
          idx = RQ_W'((int'(ptr) + k) % NREQ);
          if (!found && mb[idx]) begin win[idx] = 1'b1; found = 1'b1; end
        end
      end
      logic [RQ_W-1:0] widx;
      always_comb begin
        widx = '0;
        for (int r = 0; r < NREQ; r++) if (win[r]) widx = RQ_W'(r);
      end
      always_ff @(posedge clk) begin
        if (!rst_n) ptr <= '0;
        else if (|win) ptr <= RQ_W'((int'(widx) + 1) % NREQ);
      end
    end else begin : g_age
      always_comb begin
        win = '0;
        for (int r = 0; r < NREQ; r++) begin
          logic beaten;
          beaten = 1'b0;
          for (int q = 0; q < NREQ; q++) begin
            if (q != r && mb[q]) begin
              // q beats r if q's unit is older, or same unit and q is the lower slot
              if ((q / 2) != (r / 2)) begin
                if (older_eff[r / 2][q / 2]) beaten = 1'b1;
              end else if ((q % 2) < (r % 2)) beaten = 1'b1;
            end
          end
          win[r] = mb[r] && !beaten;
        end
      end
    end

    always_comb begin
      wrow = '0;
      for (int r = 0; r < NREQ; r++) if (win[r]) wrow = wrow | rq_row[r];
      cog = '0;
      if (RD_SHARE) for (int r = 0; r < NREQ; r++) cog[r] = mb[r] && !win[r] && (rq_row[r] == wrow);
    end

    assign gnt_b[b]    = win | cog;
    assign mb_b[b]     = mb;
    assign rd_en_b[b]  = |mb;
    assign rd_row_b[b] = wrow;
  end

  always_comb begin
    gnt_vec = '0;
    for (int b = 0; b < NUM_BANKS; b++) gnt_vec = gnt_vec | gnt_b[b];
  end

  // ---------------------------------------------------------------- operand capture mux (bank -> slot)
  logic [W-1:0] cap [NUM_CU][2];
  always_comb begin
    for (int c = 0; c < NUM_CU; c++) begin
      for (int s = 0; s < 2; s++) begin
        cap[c][s] = '0;
        for (int b = 0; b < NUM_BANKS; b++)
          if (cu_bank[c][s] == BW1'(b)) cap[c][s] = cap[c][s] | bank_rd[b];
      end
    end
  end

  // ---------------------------------------------------------------- dispatch selection
  logic [NUM_CU-1:0]  done_vec, blocked_vec, blocked_nd_vec, elig_vec, fire_cu;   // blocked_nd: held by an older unit that is NOT yet complete
  logic [NUM_CU-1:0]  sel_oh   [NUM_CLS];
  logic [CU_W-1:0]    sel_idx  [NUM_CLS];
  logic [NUM_CLS-1:0] lock_v;
  logic [CU_W-1:0]    lock_c   [NUM_CLS];

  always_comb begin
    for (int c = 0; c < NUM_CU; c++)
      done_vec[c] = cu_v[c] & ~st_rq[0][c] & ~st_rq[1][c] & ~st_fl[0][c] & ~st_fl[1][c];
    for (int c = 0; c < NUM_CU; c++) begin
      logic blk, blk_nd;
      blk    = 1'b0;
      blk_nd = 1'b0;
      for (int d = 0; d < NUM_CU; d++) begin
        if (d != c && older_q[c][d] && cu_v[d] && (cu_warp[d] == cu_warp[c])) begin
          blk = 1'b1;
          if (!done_vec[d]) blk_nd = 1'b1;
        end
      end
      blocked_vec[c]    = blk;
      blocked_nd_vec[c] = blk_nd;
      elig_vec[c]       = done_vec[c] & ~blk;
    end
    fire_cu = '0;
    for (int p = 0; p < NUM_CLS; p++) begin
      logic [NUM_CU-1:0] ep, arb;
      ep  = '0;
      arb = '0;
      for (int c = 0; c < NUM_CU; c++) ep[c] = elig_vec[c] && (int'(cu_cls[c]) == p);
      for (int c = 0; c < NUM_CU; c++) begin
        logic oldest;
        oldest = 1'b1;
        for (int d = 0; d < NUM_CU; d++) if (d != c && ep[d] && older_q[c][d]) oldest = 1'b0;
        arb[c] = ep[c] && oldest;
      end
      sel_oh[p] = arb;
      if (lock_v[p]) begin
        sel_oh[p] = '0;
        sel_oh[p][lock_c[p]] = 1'b1;
      end
      sel_idx[p] = '0;
      for (int c = 0; c < NUM_CU; c++) if (sel_oh[p][c]) sel_idx[p] = CU_W'(c);
      dsp_valid_o[p] = (|sel_oh[p]) & rst_n;
      for (int c = 0; c < NUM_CU; c++)
        if (sel_oh[p][c] && dsp_ready_i[p]) fire_cu[c] = 1'b1;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      lock_v <= '0;
    end else begin
      for (int p = 0; p < NUM_CLS; p++) lock_v[p] <= dsp_valid_o[p] & ~dsp_ready_i[p];
    end
    for (int p = 0; p < NUM_CLS; p++) lock_c[p] <= sel_idx[p];
  end

  // dispatch payload mux (AND-OR)
  always_comb begin
    for (int p = 0; p < NUM_CLS; p++) begin
      dsp_warp_o[p]    = '0;
      dsp_tag_o[p]     = '0;
      dsp_mask_o[p]    = '0;
      dsp_wr_o[p]      = 1'b0;
      dsp_rd_o[p]      = '0;
      dsp_payload_o[p] = '0;
      dsp_op1_o[p]     = '0;
      dsp_op2_o[p]     = '0;
      for (int c = 0; c < NUM_CU; c++) begin
        if (sel_oh[p][c]) begin
          dsp_warp_o[p]    = dsp_warp_o[p]    | cu_warp[c];
          dsp_tag_o[p]     = dsp_tag_o[p]     | cu_tag[c];
          dsp_mask_o[p]    = dsp_mask_o[p]    | cu_mask[c];
          dsp_wr_o[p]      = dsp_wr_o[p]      | cu_wr[c];
          dsp_rd_o[p]      = dsp_rd_o[p]      | cu_rd[c];
          dsp_payload_o[p] = dsp_payload_o[p] | cu_pay[c];
          dsp_op1_o[p]     = dsp_op1_o[p]     | cu_data[c][0];
          dsp_op2_o[p]     = dsp_op2_o[p]     | cu_data[c][1];
        end
      end
      mon_dsp_cu_o[p] = sel_idx[p];
    end
  end

  // ---------------------------------------------------------------- collector-unit registers
  for (genvar c = 0; c < NUM_CU; c++) begin : g_cu
    logic g0, g1, is_new;
    assign g0     = gnt_vec[2*c];
    assign g1     = gnt_vec[2*c+1];
    assign is_new = alloc_oh[c];

    // control state
    always_ff @(posedge clk) begin
      if (!rst_n) begin
        cu_v[c]    <= 1'b0;
        st_rq[0][c] <= 1'b0;  st_rq[1][c] <= 1'b0;
        st_fl[0][c] <= 1'b0;  st_fl[1][c] <= 1'b0;
        cu_conf[c] <= 1'b0;
      end else begin
        if (is_new) begin
          cu_v[c]     <= 1'b1;
          cu_conf[c]  <= FAST_READ & ((n_need[0] & ~g0) | (n_need[1] & ~g1));
          st_rq[0][c] <= n_need[0] & ~(FAST_READ & g0);
          st_fl[0][c] <= n_need[0] &  (FAST_READ & g0);
          st_rq[1][c] <= n_need[1] & ~(FAST_READ & g1);
          st_fl[1][c] <= (n_need[1] & FAST_READ & g1) | (n_alias & FAST_READ & g0);
        end else if (cu_v[c]) begin
          if (st_fl[0][c]) st_fl[0][c] <= 1'b0;             // captured this cycle
          if (st_fl[1][c]) st_fl[1][c] <= 1'b0;
          if (st_rq[0][c] & g0) begin                       // granted: data arrives (is captured) next cycle
            st_rq[0][c] <= 1'b0;
            st_fl[0][c] <= 1'b1;
            if (cu_alias[c]) st_fl[1][c] <= 1'b1;           // the follower captures the same read
          end
          if (st_rq[1][c] & g1) begin
            st_rq[1][c] <= 1'b0;
            st_fl[1][c] <= 1'b1;
          end
          if ((st_rq[0][c] & ~g0) | (st_rq[1][c] & ~g1)) cu_conf[c] <= 1'b1;
        end
        if (fire_cu[c]) cu_v[c] <= 1'b0;
      end
    end

    // descriptor + age (no reset: gated by cu_v)
    always_ff @(posedge clk) begin
      if (is_new) begin
        cu_cls[c]     <= iss_cls_i;
        cu_warp[c]    <= iss_warp_i;
        cu_tag[c]     <= iss_tag_i;
        cu_mask[c]    <= iss_mask_i;
        cu_rd[c]      <= iss_rd_i;
        cu_wr[c]      <= iss_wr_i;
        cu_pay[c]     <= iss_payload_i;
        cu_rs[c][0]   <= iss_rs1_i;
        cu_rs[c][1]   <= iss_rs2_i;
        cu_bank[c][0] <= n_bank[0];
        cu_bank[c][1] <= n_bank[1];
        cu_row[c][0]  <= n_row[0];
        cu_row[c][1]  <= n_row[1];
        cu_alias[c]   <= n_alias;
        older_q[c]    <= cu_v;
      end else begin
        older_q[c]    <= older_q[c] & ~alloc_oh;
      end
    end

    // operand data: cleared at allocation (no stale data from the previous occupant), captured from the bank
    always_ff @(posedge clk) begin
      if (is_new) begin
        cu_data[c][0] <= '0;
        cu_data[c][1] <= '0;
      end else begin
        if (st_fl[0][c]) cu_data[c][0] <= cap[c][0];
        if (st_fl[1][c]) cu_data[c][1] <= cap[c][1];
      end
    end
  end

  // ---------------------------------------------------------------- writeback arbitration
  logic [NUM_WB-1:0]  w_need, w_acc;
  logic [BW1-1:0]     w_bank [NUM_WB];
  logic [AW-1:0]      w_row  [NUM_WB];
  logic [NUM_WB-1:0]  w_gnt_b [NUM_BANKS];
  logic [NUM_WB-1:0]  w_req_b [NUM_BANKS];
  logic [NUM_BANKS-1:0] bw_en;
  logic [AW-1:0]      bw_row  [NUM_BANKS];
  logic [LANES-1:0]   bw_mask [NUM_BANKS];
  logic [W-1:0]       bw_data [NUM_BANKS];

  always_comb begin
    for (int p = 0; p < NUM_WB; p++) begin
      w_need[p] = wb_valid_i[p] & wb_we_i[p] & (wb_rd_i[p] != 5'd0) & (|wb_mask_i[p]);
      w_bank[p] = bank_of(wb_warp_i[p], wb_rd_i[p]);
      w_row[p]  = row_of(wb_warp_i[p], wb_rd_i[p]);
    end
  end

  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_wr
    logic [NUM_WB-1:0] wreq, wsel;
    logic [WB_W-1:0]   ptr;
    logic              any;
    logic [WB_W-1:0]   fin;

    always_comb begin
      logic [WB_W-1:0] rr;
      logic found;
      wreq = '0;
      for (int p = 0; p < NUM_WB; p++) wreq[p] = w_need[p] && (w_bank[p] == BW1'(b));
      found = 1'b0;
      rr    = '0;
      for (int k = 0; k < NUM_WB; k++) begin
        logic [WB_W-1:0] idx;
        idx = WB_W'((int'(ptr) + k) % NUM_WB);
        if (!found && wreq[idx]) begin rr = idx; found = 1'b1; end
      end
      // Same-row simultaneous writes: the lowest-numbered port is accepted first (higher port = younger).
      fin = rr;
      for (int p = NUM_WB - 1; p >= 0; p--)
        if (found && wreq[p] && (w_row[p] == w_row[rr])) fin = WB_W'(p);
      wsel = '0;
      if (found) wsel[fin] = 1'b1;
      any = found;
    end

    always_ff @(posedge clk) begin
      if (!rst_n) ptr <= '0;
      else if (any) ptr <= WB_W'((int'(fin) + 1) % NUM_WB);
    end

    always_comb begin
      bw_row[b]  = '0;
      bw_mask[b] = '0;
      bw_data[b] = '0;
      for (int p = 0; p < NUM_WB; p++) if (wsel[p]) begin
        bw_row[b]  = bw_row[b]  | w_row[p];
        bw_mask[b] = bw_mask[b] | wb_mask_i[p];
        bw_data[b] = bw_data[b] | wb_data_i[p];
      end
    end
    assign bw_en[b]    = any;
    assign w_gnt_b[b]  = wsel;
    assign w_req_b[b]  = wreq;
  end

  always_comb begin
    for (int p = 0; p < NUM_WB; p++) begin
      logic g;
      g = 1'b0;
      for (int b = 0; b < NUM_BANKS; b++) g = g | w_gnt_b[b][p];
      w_acc[p] = ~w_need[p] | g;
    end
  end

  assign wb_ready_o   = w_acc & {NUM_WB{rst_n}};
  assign cmpl_valid_o = wb_valid_i & wb_ready_o;
  for (genvar p = 0; p < NUM_WB; p++) begin : g_cmpl
    assign cmpl_warp_o[p] = wb_warp_i[p];
    assign cmpl_tag_o[p]  = wb_tag_i[p];
    assign cmpl_aux_o[p]  = wb_aux_i[p];
  end

  // ---------------------------------------------------------------- banks
  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_bank
    sf_rfc_bank #(.ROWS(ROWS), .LANES(LANES), .RPW(RPW), .NUM_WARPS(NUM_WARPS),
                  .RAM_STYLE(RAM_STYLE), .WRITE_THROUGH(WRITE_THROUGH)) u_bank (
      .clk(clk), .rst_n(rst_n), .clr_all(clr_all_i), .clr_warp(clr_warp_i),
      .wr_en(bw_en[b]), .wr_row(bw_row[b]), .wr_mask(bw_mask[b]), .wr_data(bw_data[b]),
      .rd_en(rd_en_b[b]), .rd_row(rd_row_b[b]), .rd_data(bank_rd[b]), .rd_hit(bank_hit[b]),
      .idle(bank_idle[b]));
  end

  assign idle_o      = ~|cu_v & &bank_idle;
  assign mon_alloc_o = alloc_oh;
  assign mon_req_o   = req_eff;
  assign mon_gnt_o   = gnt_vec;

  /* verilator lint_on UNUSEDSIGNAL */

  // ---------------------------------------------------------------- performance counters
  if (PERF_EN) begin : g_perf
    logic [31:0] cnt [PERF_N];
    int unsigned inc [PERF_N];

    always_comb begin
      int unsigned nreq, ngr, nden, nsh, nocc, nblk, nstall, nwbs, nwbc, nfwd, nconf_disp;
      nreq = 0; ngr = 0; nden = 0; nsh = 0; nocc = 0; nblk = 0; nstall = 0; nwbs = 0; nwbc = 0; nfwd = 0; nconf_disp = 0;
      for (int r = 0; r < NREQ; r++) begin
        if (req_eff[r]) nreq++;
        if (req_eff[r] && !gnt_vec[r]) nden++;
      end
      for (int b = 0; b < NUM_BANKS; b++) begin
        if (rd_en_b[b]) ngr++;
        if (bank_hit[b]) nfwd++;
        for (int r = 0; r < NREQ; r++) if (gnt_b[b][r] && mb_b[b][r]) nsh++;
      end
      nsh = nsh - ngr;                                   // grants beyond the one winner per bank are shared reads
      for (int c = 0; c < NUM_CU; c++) begin
        if (cu_v[c]) nocc++;
        if (done_vec[c] && blocked_nd_vec[c]) nblk++;
        if (fire_cu[c] && cu_conf[c]) nconf_disp++;
      end
      for (int p = 0; p < NUM_CLS; p++) if (dsp_valid_o[p] && !dsp_ready_i[p]) nstall++;
      for (int p = 0; p < NUM_WB; p++) if (wb_valid_i[p] && !w_acc[p]) nwbs++;
      for (int b = 0; b < NUM_BANKS; b++) begin
        int unsigned k;
        k = 0;
        for (int p = 0; p < NUM_WB; p++) if (w_req_b[b][p]) k++;
        if (k >= 2) nwbc++;
      end
      for (int i = 0; i < PERF_N; i++) inc[i] = 0;
      inc[PERF_BUSY]        = (|cu_v) ? 1 : 0;
      inc[PERF_ALLOC]       = iss_fire ? 1 : 0;
      inc[PERF_DISPATCH]    = $countones(fire_cu);
      inc[PERF_RD_REQ_CYC]  = nreq;
      inc[PERF_RD_GRANT]    = ngr;
      inc[PERF_RD_CONFLICT] = nden;
      inc[PERF_RD_SHARED]   = nsh;
      inc[PERF_INSTR_CONF]  = nconf_disp;
      inc[PERF_WB_ACCEPT]   = $countones(bw_en);
      inc[PERF_WB_STALL]    = nwbs;
      inc[PERF_WB_BANKCONF] = nwbc;
      inc[PERF_FWD_HIT]     = nfwd;
      inc[PERF_CU_OCC]      = nocc;
      inc[PERF_ORDER_BLK]   = nblk;
      inc[PERF_DSP_STALL]   = nstall;
      inc[PERF_FULL]        = (&cu_v) ? 1 : 0;
    end

    always_ff @(posedge clk) begin
      for (int i = 0; i < PERF_N; i++) begin
        if (!rst_n || perf_clear_i) cnt[i] <= '0;
        else if ((64'(cnt[i]) + 64'(inc[i])) > 64'hFFFF_FFFF) cnt[i] <= 32'hFFFF_FFFF;
        else cnt[i] <= cnt[i] + 32'(inc[i]);
      end
    end
    for (genvar i = 0; i < PERF_N; i++) begin : g_o
      assign perf_o[i] = cnt[i];
    end
  end else begin : g_noperf
    for (genvar i = 0; i < PERF_N; i++) begin : g_o
      assign perf_o[i] = '0;
    end
  end

  // ---------------------------------------------------------------- simulation assertions
`ifndef SYNTHESIS
  // direct definition of readiness, used only to check the registered version above
  logic [NUM_CLS-1:0] ref_room;
  always_comb begin
    int unsigned cnt;
    for (int p = 0; p < NUM_CLS; p++) begin
      cnt = 0;
      for (int c = 0; c < NUM_CU; c++) if (cu_v[c] && (int'(cu_cls[c]) == p)) cnt++;
      ref_room[p] = (|(~cu_v)) && (cnt < CLS_CAP);
    end
  end
  always_ff @(posedge clk) begin
    if (rst_n) begin
      if (room_q !== ref_room) $error("[sf_rfc] registered readiness %b differs from the direct definition %b", room_q, ref_room);
      // one read port per bank: every granted requester of a bank wants exactly the row that is launched
      for (int b = 0; b < NUM_BANKS; b++)
        for (int r = 0; r < NREQ; r++)
          if (gnt_b[b][r] && (rq_row[r] != rd_row_b[b]))
            $error("[sf_rfc] bank %0d granted requester %0d for a row other than the launched one", b, r);
      // slot-state exclusivity and ownership
      for (int c = 0; c < NUM_CU; c++) begin
        for (int s = 0; s < 2; s++) begin
          if (st_rq[s][c] && st_fl[s][c])
            $error("[sf_rfc] unit %0d slot %0d both requesting and in flight", c, s);
          if (!cu_v[c] && (st_rq[s][c] || st_fl[s][c]))
            $error("[sf_rfc] free unit %0d owns an operand slot %0d", c, s);
        end
      end
      // dispatch only complete, unblocked units; only one unit per class
      for (int p = 0; p < NUM_CLS; p++) begin
        if (dsp_valid_o[p] && !$onehot(sel_oh[p])) $error("[sf_rfc] dispatch class %0d select not one-hot", p);
        for (int c = 0; c < NUM_CU; c++)
          if (sel_oh[p][c] && !elig_vec[c]) $error("[sf_rfc] dispatching unit %0d that is not eligible", c);
      end
      // at most one write per bank, completions only for accepted records
      for (int b = 0; b < NUM_BANKS; b++)
        if (!$onehot0(w_gnt_b[b])) $error("[sf_rfc] bank %0d accepted two writes in one cycle", b);
      if (|(cmpl_valid_o & ~wb_valid_i)) $error("[sf_rfc] completion without writeback record");
      // maintenance only when quiescent
      if (clr_all_i && !idle_o) $error("[sf_rfc] clr_all_i while not idle");
      for (int w = 0; w < NUM_WARPS; w++)
        if (clr_warp_i[w])
          for (int c = 0; c < NUM_CU; c++)
            if (cu_v[c] && int'(cu_warp[c]) == w) $error("[sf_rfc] clr_warp_i[%0d] while a unit of that warp is allocated", w);
      // STRICT: contract with the front end (WAR/in-order): a write must not hit a register that an older,
      // not-yet-launched read of the same warp still needs.
      if (STRICT) begin
        for (int p = 0; p < NUM_WB; p++) begin
          if (w_need[p] && w_acc[p]) begin
            for (int c = 0; c < NUM_CU; c++)
              for (int s = 0; s < 2; s++)
                if (cu_v[c] && st_rq[s][c] && cu_warp[c] == wb_warp_i[p] && cu_rs[c][s] == wb_rd_i[p])
                  $error("[sf_rfc] WAR violation: write w%0d r%0d accepted while unit %0d still has to read it",
                         wb_warp_i[p], wb_rd_i[p], c);
          end
        end
      end
    end
  end
`endif
endmodule
`default_nettype wire
