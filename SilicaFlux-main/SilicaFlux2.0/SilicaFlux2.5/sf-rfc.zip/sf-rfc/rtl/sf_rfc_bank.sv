// =============================================================================
//  sf_rfc_bank -- one register-file bank: 1 write + 1 read port, per-lane write enable,
//                 lazy zero ("clean" bits), registered write staging, same-cycle forwarding.
//
//  TIMING (cycle numbers are relative; "accept" = cycle in which wr_en is high):
//
//     accept  c   : wr_en/wr_row/wr_mask/wr_data presented, staged at the end of c.
//     staged  c+1 : the write sits in the staging register (stg_*); it is written into the RAM at the end of c+1
//                   ("landing").  Only this register drives the RAM write port.
//     launch  t   : rd_row presented (rd_en = 1).  The RAM samples it at the end of t.
//     data    t+1 : rd_data is valid during t+1 (consume it, i.e. register it, in t+1).
//
//  VISIBILITY ("same-cycle read/write", docs/ARCHITECTURE.md s.4):
//     A read LAUNCHED in cycle t returns the register content after ALL writes ACCEPTED in cycles <= t.
//     i.e. write-through: a write accepted in the very cycle t is already visible to a read launched in t.
//  How the three cases are covered (the RAM itself is READ_FIRST and never sees them in time):
//     accepted <= t-2 : landed at the end of <= t-1, read from the RAM                          (ram_q)
//     accepted  =  t-1: lands at the END OF t, the same edge at which the RAM samples the read
//                       -> RAM returns the old word; the staged copy captured at launch (f_*) is overlaid
//     accepted  =  t  : staged at the end of t -> stg_* during t+1 is overlaid (a_hit), WRITE_THROUGH = 1 only
//  All overlays are per lane (stg_mask / f_mask): a lane that is not written is never forwarded.
//
//  LAZY ZERO.  RAM contents are undefined at power-up and cannot be reset in one cycle.  Each row has a
//  "clean" flop: set by rst_n / clr_all / clr_warp, cleared when the row first lands a write.  A clean row
//  reads as zero (RAM output ignored); the first write to a clean row writes the WHOLE row (lanes outside
//  the write mask get zero), so partial first writes leave no stale lanes behind.
// =============================================================================
`default_nettype none
module sf_rfc_bank #(
  parameter int unsigned ROWS          = 64,
  parameter int unsigned LANES         = 8,
  parameter int unsigned RPW           = 8,      // rows per warp (32 >> log2(NUM_BANKS))
  parameter int unsigned NUM_WARPS     = 8,
  parameter int unsigned RAM_STYLE     = 0,
  parameter bit          WRITE_THROUGH = 1'b1,
  localparam int unsigned AW           = (ROWS > 1) ? $clog2(ROWS) : 1,
  localparam int unsigned W            = LANES * 32
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic                 clr_all,          // all rows read as zero from the next cycle (quiescent use only)
  input  logic [NUM_WARPS-1:0] clr_warp,         // same for the rows of one warp
  // write: accept cycle
  input  logic                 wr_en,
  input  logic [AW-1:0]        wr_row,
  input  logic [LANES-1:0]     wr_mask,
  input  logic [W-1:0]         wr_data,
  // read: launch cycle t, data in t+1
  input  logic                 rd_en,
  input  logic [AW-1:0]        rd_row,
  output logic [W-1:0]         rd_data,
  output logic                 rd_hit,           // monitor: the data of this read merged an in-flight write
  output logic                 idle              // no staged write pending
);
  // ---------------------------------------------------------------- write staging
  logic              stg_v;
  logic [AW-1:0]     stg_row;
  logic [LANES-1:0]  stg_mask;
  logic [W-1:0]      stg_data;

  always_ff @(posedge clk) begin
    if (!rst_n || clr_all) stg_v <= 1'b0;
    else                   stg_v <= wr_en;
    if (wr_en) begin
      stg_row  <= wr_row;
      stg_mask <= wr_mask;
      stg_data <= wr_data;
    end
  end
  assign idle = ~stg_v;

  // ---------------------------------------------------------------- clean bits
  logic [ROWS-1:0] clean;
  logic            land_clean;
  assign land_clean = clean[stg_row];

  always_ff @(posedge clk) begin
    if (!rst_n || clr_all) begin
      clean <= '1;
    end else begin
      if (stg_v) clean[stg_row] <= 1'b0;
      for (int w = 0; w < NUM_WARPS; w++) begin
        if (clr_warp[w]) clean[w*RPW +: RPW] <= '1;
      end
    end
  end

  // ---------------------------------------------------------------- RAM (one 32-bit memory per lane)
  logic [W-1:0] ram_q;
  for (genvar l = 0; l < LANES; l++) begin : g_lane
    logic        we;
    logic [31:0] wd;
    assign we = stg_v & (stg_mask[l] | land_clean);                   // clean row: write all lanes (zero fill)
    assign wd = stg_mask[l] ? stg_data[l*32 +: 32] : 32'd0;
    sf_rfc_ram #(.ROWS(ROWS), .STYLE(RAM_STYLE)) u_ram (
      .clk(clk), .we(we), .waddr(stg_row), .wdata(wd), .raddr(rd_row), .rdata(ram_q[l*32 +: 32]));
  end

  // ---------------------------------------------------------------- read launch capture
  logic             q_v, q_clean, f_v;
  logic [AW-1:0]    q_row;
  logic [LANES-1:0] f_mask;
  logic [W-1:0]     f_data;

  always_ff @(posedge clk) begin
    if (!rst_n) q_v <= 1'b0;
    else        q_v <= rd_en;
    q_row   <= rd_row;
    q_clean <= clean[rd_row];
    f_v     <= stg_v & (stg_row == rd_row);   // the write landing at this very edge
    f_mask  <= stg_mask;
    f_data  <= stg_data;
  end

  // ---------------------------------------------------------------- merge (cycle t+1)
  logic a_hit;
  assign a_hit = WRITE_THROUGH & stg_v & (stg_row == q_row);          // write accepted in the launch cycle

  for (genvar l = 0; l < LANES; l++) begin : g_merge
    logic [31:0] base, v1;
    assign base = q_clean ? 32'd0 : ram_q[l*32 +: 32];
    assign v1   = (f_v  & f_mask[l])   ? f_data[l*32 +: 32]   : base;
    assign rd_data[l*32 +: 32] = (a_hit & stg_mask[l]) ? stg_data[l*32 +: 32] : v1;
  end

  assign rd_hit = q_v & (f_v | a_hit);

`ifndef SYNTHESIS
  // The bank has one write port: the caller must never present a write while rst/clr is active in a way that
  // would be silently lost.  (Dropped writes are the contract violation this design exists to avoid.)
  always_ff @(posedge clk) begin
    if (rst_n && !clr_all && wr_en && (wr_mask == '0))
      $error("[sf_rfc_bank] write with empty mask accepted (should have been filtered upstream)");
  end
`endif
endmodule
`default_nettype wire
