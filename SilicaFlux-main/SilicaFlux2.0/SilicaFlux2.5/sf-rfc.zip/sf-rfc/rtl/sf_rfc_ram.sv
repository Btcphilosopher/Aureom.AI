// =============================================================================
//  sf_rfc_ram -- ONE 32-bit-wide memory: one write port, one registered read port.
//
//  This is the only place where an array is declared, and it has exactly the ports an FPGA
//  memory has (simple dual-port: 1 write + 1 read).  Nothing above this module ever indexes
//  an array twice in a cycle -- multi-porting is obtained by banking, never assumed.
//
//  Coding style = the standard "READ_FIRST" inference template:
//      always_ff @(posedge clk) begin if (we) mem[waddr] <= wdata;  rdata <= mem[raddr]; end
//  If read and write hit the same address in the same cycle, rdata gets the OLD word.
//  The enclosing bank does not rely on that: it merges the colliding write explicitly, so a tool
//  mapping the memory in WRITE_FIRST (new word) mode is also correct.  NO_CHANGE mode would NOT be
//  (see docs/FPGA_MEMORY.md).
//
//  STYLE: 0 = no attribute (tool decides), 1 = ram_style "block", 2 = ram_style "distributed".
//  Contents are NOT reset (RAM cannot be cleared in one cycle); the bank's per-row "clean" bits make
//  never-written rows read as zero instead.
// =============================================================================
`default_nettype none
module sf_rfc_ram #(
  parameter int unsigned ROWS  = 64,
  parameter int unsigned STYLE = 0,
  localparam int unsigned AW   = (ROWS > 1) ? $clog2(ROWS) : 1
) (
  input  logic          clk,
  input  logic          we,
  input  logic [AW-1:0] waddr,
  input  logic [31:0]   wdata,
  input  logic [AW-1:0] raddr,
  output logic [31:0]   rdata
);
  if (STYLE == 1) begin : g_blk
    (* ram_style = "block" *) logic [31:0] mem [0:ROWS-1];
    always_ff @(posedge clk) begin
      if (we) mem[waddr] <= wdata;
      rdata <= mem[raddr];
    end
  end else if (STYLE == 2) begin : g_dist
    (* ram_style = "distributed" *) logic [31:0] mem [0:ROWS-1];
    always_ff @(posedge clk) begin
      if (we) mem[waddr] <= wdata;
      rdata <= mem[raddr];
    end
  end else begin : g_auto
    logic [31:0] mem [0:ROWS-1];
    always_ff @(posedge clk) begin
      if (we) mem[waddr] <= wdata;
      rdata <= mem[raddr];
    end
  end
endmodule
`default_nettype wire
