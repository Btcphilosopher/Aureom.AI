// =============================================================================
//  sf_rfc_pkg -- constants and the register -> (bank, row) mapping.
//
//  The Python mirror is python/rfref/bankmap.py (bank_of / row_of); the two are
//  cross-checked exhaustively by scripts/check_bankmap.py.  See docs/ARCHITECTURE.md s.2.
//
//  A "warp register" is the pair (warp, reg): one row of LANES x 32 bits.  NUM_BANKS is a
//  power of two, BW = log2(NUM_BANKS), every bank holds ROWS = NUM_WARPS * (32 >> BW) rows:
//
//      row  = warp * (32 >> BW) + (reg >> BW)
//      bank = f_bank(BANK_MAP, ...)  with
//          BANK_MAP 0  LOW :  reg[BW-1:0]
//          BANK_MAP 1  SKEW:  (reg[BW-1:0] + warp) mod NUM_BANKS
//          BANK_MAP 2  XOR :  reg[BW-1:0] ^ ((hi ^ (hi >> BW) ^ warp) mod NUM_BANKS),  hi = reg >> BW
//
//  For every map, with the row fixed, bank is a bijection of reg[BW-1:0]; hence (bank,row) <->
//  (warp,reg) is one-to-one and no two warp registers share storage.
// =============================================================================
`ifndef SF_RFC_PKG_SV
`define SF_RFC_PKG_SV
package sf_rfc_pkg;

  /* verilator lint_off UNUSEDPARAM */
  // performance-counter indices (perf_o[]) ---------------------------------------------------------
  localparam int unsigned PERF_N            = 16;
  localparam int unsigned PERF_BUSY         = 0;   // cycles with at least one collector unit allocated
  localparam int unsigned PERF_ALLOC        = 1;   // instructions accepted
  localparam int unsigned PERF_DISPATCH     = 2;   // instructions dispatched
  localparam int unsigned PERF_RD_REQ_CYC   = 3;   // requester-cycles: sum over cycles of pending read requests
  localparam int unsigned PERF_RD_GRANT     = 4;   // bank read launches
  localparam int unsigned PERF_RD_CONFLICT  = 5;   // requester-cycles denied because the bank read port went to another row
  localparam int unsigned PERF_RD_SHARED    = 6;   // requests satisfied by a co-granted read (same row, same cycle)
  localparam int unsigned PERF_INSTR_CONF   = 7;   // dispatched instructions that were denied at least once
  localparam int unsigned PERF_WB_ACCEPT    = 8;   // register writes accepted into a bank
  localparam int unsigned PERF_WB_STALL     = 9;   // writeback-port-cycles offered but not accepted (back-pressure)
  localparam int unsigned PERF_WB_BANKCONF  = 10;  // bank-cycles in which >=2 writeback ports wanted the same bank
  localparam int unsigned PERF_FWD_HIT      = 11;  // bank reads that merged an in-flight (staged) write
  localparam int unsigned PERF_CU_OCC       = 12;  // sum over cycles of allocated collector units (Little's law)
  localparam int unsigned PERF_ORDER_BLK    = 13;  // unit-cycles complete but held because an OLDER unit of the same warp is not (the WAR rule at work)
  localparam int unsigned PERF_DSP_STALL    = 14;  // dispatch-port-cycles valid but not accepted downstream
  localparam int unsigned PERF_FULL         = 15;  // cycles with no free collector unit
  /* verilator lint_on UNUSEDPARAM */

  function automatic int unsigned clog2f(input int unsigned n);
    int unsigned r;
    r = 0;
    while ((32'd1 << r) < n) r++;
    return r;
  endfunction

  // bank number of warp register (warp, r).  bw = log2(NUM_BANKS).  Only warp[4:0] participates.
  function automatic logic [4:0] f_bank(input int unsigned bmap, input int unsigned bw,
                                        input logic [4:0] warp5, input logic [4:0] r);
    logic [4:0] m, lo, hi, h;
    m  = 5'((32'd1 << bw) - 32'd1);
    lo = r & m;
    hi = r >> bw;
    h  = hi ^ (hi >> bw) ^ warp5;
    case (bmap)
      0:       return lo;
      1:       return 5'(lo + warp5) & m;
      default: return (lo ^ h) & m;
    endcase
  endfunction

endpackage
`endif
