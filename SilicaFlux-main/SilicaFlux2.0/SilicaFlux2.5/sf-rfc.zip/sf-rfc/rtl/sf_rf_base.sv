// =============================================================================
//  sf_rf_base -- BASELINE register file for comparison: the SF-G1 architecture (replicated RAMs, one write
//  port, one in-order operand stage) extended with the warp dimension.  Same ports, same operand/zero/mask
//  contract, same write-through visibility and lazy-zero reset as sf_rfc, so a testbench can swap the two.
//
//    * Two COPIES of the whole register file (copy A serves rs1, copy B serves rs2): both operands are read in
//      the same cycle, there are NO read conflicts -- paid for with 2x the RAM.
//    * ONE write port (both copies are written together): simultaneous writebacks are serialised by an
//      arbiter; the loser is back-pressured (wb_ready_o = 0), never dropped.
//    * ONE operand stage, strictly in issue order across all warps and both classes (a stalled MEM dispatch
//      blocks ALU work of other warps behind it: head-of-line blocking).
//
//    issue t0 -> R (read launched) -> t0+1 data on the bank outputs, captured into O -> t0+2 dispatch.
//  The minimum issue-to-dispatch latency (2 cycles) equals the collector's best case (FAST_READ), so any
//  difference measured against sf_rfc comes from the architecture, not from a deeper/shallower pipeline.
// =============================================================================
`default_nettype none

module sf_rf_base
  import sf_rfc_pkg::*;
#(
  parameter int unsigned NUM_WARPS = 8,
  parameter int unsigned LANES     = 8,
  parameter int unsigned NUM_CU    = 4,            // unused; keeps the monitor port widths identical to sf_rfc
  parameter int unsigned NUM_CLS   = 2,
  parameter int unsigned NUM_WB    = 2,
  parameter int unsigned TAG_W     = 4,
  parameter int unsigned PAYLOAD_W = 32,
  parameter int unsigned AUX_W     = LANES,
  parameter int unsigned RAM_STYLE = 0,
  parameter bit          PERF_EN   = 1'b1,
  parameter bit          WRITE_THROUGH = 1'b1,
  localparam int unsigned XLEN     = 32,
  localparam int unsigned W        = LANES * XLEN,
  localparam int unsigned WARP_W   = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1,
  localparam int unsigned CLS_W    = (NUM_CLS > 1) ? $clog2(NUM_CLS) : 1,
  localparam int unsigned NREQ     = 2 * NUM_CU,
  localparam int unsigned CU_W     = (NUM_CU > 1) ? $clog2(NUM_CU) : 1
) (
  input  logic                     clk,
  input  logic                     rst_n,
  input  logic                     clr_all_i,
  input  logic [NUM_WARPS-1:0]     clr_warp_i,
  output logic                     idle_o,
  input  logic                     iss_valid_i,
  output logic [NUM_CLS-1:0]       iss_ready_o,
  input  logic [CLS_W-1:0]         iss_cls_i,
  input  logic [WARP_W-1:0]        iss_warp_i,
  input  logic [TAG_W-1:0]         iss_tag_i,
  input  logic [LANES-1:0]         iss_mask_i,
  input  logic                     iss_use1_i,
  input  logic                     iss_use2_i,
  input  logic [4:0]               iss_rs1_i,
  input  logic [4:0]               iss_rs2_i,
  input  logic                     iss_wr_i,
  input  logic [4:0]               iss_rd_i,
  input  logic [PAYLOAD_W-1:0]     iss_payload_i,
  output logic [NUM_CLS-1:0]       dsp_valid_o,
  input  logic [NUM_CLS-1:0]       dsp_ready_i,
  output logic [WARP_W-1:0]        dsp_warp_o    [NUM_CLS],
  output logic [TAG_W-1:0]         dsp_tag_o     [NUM_CLS],
  output logic [LANES-1:0]         dsp_mask_o    [NUM_CLS],
  output logic                     dsp_wr_o      [NUM_CLS],
  output logic [4:0]               dsp_rd_o      [NUM_CLS],
  output logic [PAYLOAD_W-1:0]     dsp_payload_o [NUM_CLS],
  output logic [W-1:0]             dsp_op1_o     [NUM_CLS],
  output logic [W-1:0]             dsp_op2_o     [NUM_CLS],
  input  logic [NUM_WB-1:0]        wb_valid_i,
  output logic [NUM_WB-1:0]        wb_ready_o,
  input  logic [WARP_W-1:0]        wb_warp_i     [NUM_WB],
  input  logic [TAG_W-1:0]         wb_tag_i      [NUM_WB],
  input  logic                     wb_we_i       [NUM_WB],
  input  logic [4:0]               wb_rd_i       [NUM_WB],
  input  logic [LANES-1:0]         wb_mask_i     [NUM_WB],
  input  logic [W-1:0]             wb_data_i     [NUM_WB],
  input  logic [AUX_W-1:0]         wb_aux_i      [NUM_WB],
  output logic [NUM_WB-1:0]        cmpl_valid_o,
  output logic [WARP_W-1:0]        cmpl_warp_o   [NUM_WB],
  output logic [TAG_W-1:0]         cmpl_tag_o    [NUM_WB],
  output logic [AUX_W-1:0]         cmpl_aux_o    [NUM_WB],
  /* verilator lint_off UNUSEDSIGNAL */
  input  logic                     perf_clear_i,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]              perf_o        [PERF_N],
  output logic [NUM_CU-1:0]        mon_alloc_o,
  output logic [NREQ-1:0]          mon_req_o,
  output logic [NREQ-1:0]          mon_gnt_o,
  output logic [WARP_W-1:0]        mon_rq_warp_o [NREQ],
  output logic [4:0]               mon_rq_reg_o  [NREQ],
  output logic [CU_W-1:0]          mon_dsp_cu_o  [NUM_CLS]
);
  localparam int unsigned ROWS = NUM_WARPS * 32;
  localparam int unsigned AW   = (ROWS > 1) ? $clog2(ROWS) : 1;
  localparam int unsigned WB_W = (NUM_WB > 1) ? $clog2(NUM_WB) : 1;

  function automatic logic [AW-1:0] row_of(input logic [WARP_W-1:0] w, input logic [4:0] r);
    return AW'(int'(w) * 32) + AW'(r);
  endfunction

  // ---------------------------------------------------------------- stages
  logic              r_v, o_v;
  logic [CLS_W-1:0]  r_cls, o_cls;
  logic [WARP_W-1:0] r_warp, o_warp;
  logic [TAG_W-1:0]  r_tag, o_tag;
  logic [LANES-1:0]  r_mask, o_mask;
  logic [4:0]        r_rd, o_rd;
  logic              r_wr, o_wr;
  logic [PAYLOAD_W-1:0] r_pay, o_pay;
  logic              r_nd0, r_nd1;
  logic [AW-1:0]     r_row0, r_row1;
  logic [W-1:0]      o_d0, o_d1;

  logic o_fire, o_free, r_move, iss_fire, hold;
  logic n_mz, n_nd0, n_nd1;
  logic [AW-1:0] n_row0, n_row1, l_row0, l_row1;

  always_comb begin
    n_mz   = ~|iss_mask_i;
    n_nd0  = iss_use1_i & (iss_rs1_i != 5'd0) & ~n_mz;
    n_nd1  = iss_use2_i & (iss_rs2_i != 5'd0) & ~n_mz;
    n_row0 = row_of(iss_warp_i, iss_rs1_i);
    n_row1 = row_of(iss_warp_i, iss_rs2_i);

    o_fire = o_v & dsp_ready_i[o_cls] & rst_n;
    o_free = ~o_v | o_fire;
    r_move = r_v & o_free;
    hold   = r_v & ~o_free;                              // R must wait: re-launch its read
    iss_ready_o = {NUM_CLS{(~r_v | o_free) & rst_n}};
    iss_fire    = iss_valid_i && (int'(iss_cls_i) < NUM_CLS) && iss_ready_o[iss_cls_i];
    l_row0 = hold ? r_row0 : n_row0;
    l_row1 = hold ? r_row1 : n_row1;
  end

  // ---------------------------------------------------------------- write port: one write per cycle
  logic [NUM_WB-1:0] w_need, w_win, w_acc;
  logic [AW-1:0]     w_row [NUM_WB];
  logic              bw_en;
  logic [AW-1:0]     bw_row;
  logic [LANES-1:0]  bw_mask;
  logic [W-1:0]      bw_data;
  logic [WB_W-1:0]   w_ptr, w_fin;

  always_comb begin
    logic [WB_W-1:0] rr;
    logic found;
    for (int p = 0; p < NUM_WB; p++) begin
      w_need[p] = wb_valid_i[p] & wb_we_i[p] & (wb_rd_i[p] != 5'd0) & (|wb_mask_i[p]);
      w_row[p]  = row_of(wb_warp_i[p], wb_rd_i[p]);
    end
    found = 1'b0;
    rr    = '0;
    for (int k = 0; k < NUM_WB; k++) begin
      logic [WB_W-1:0] idx;
      idx = WB_W'((int'(w_ptr) + k) % NUM_WB);
      if (!found && w_need[idx]) begin rr = idx; found = 1'b1; end
    end
    w_fin = rr;                                          // same-row writes: lowest port first (as in sf_rfc)
    for (int p = NUM_WB - 1; p >= 0; p--)
      if (found && w_need[p] && (w_row[p] == w_row[rr])) w_fin = WB_W'(p);
    w_win = '0;
    if (found) w_win[w_fin] = 1'b1;
    bw_en   = found;
    bw_row  = w_row[w_fin];
    bw_mask = wb_mask_i[w_fin];
    bw_data = wb_data_i[w_fin];
    w_acc   = ~w_need | w_win;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) w_ptr <= '0;
    else if (bw_en) w_ptr <= WB_W'((int'(w_fin) + 1) % NUM_WB);
  end

  assign wb_ready_o   = w_acc & {NUM_WB{rst_n}};
  assign cmpl_valid_o = wb_valid_i & wb_ready_o;
  for (genvar p = 0; p < NUM_WB; p++) begin : g_cmpl
    assign cmpl_warp_o[p] = wb_warp_i[p];
    assign cmpl_tag_o[p]  = wb_tag_i[p];
    assign cmpl_aux_o[p]  = wb_aux_i[p];
  end

  // ---------------------------------------------------------------- the two register-file copies
  logic [W-1:0] rdA, rdB;
  logic         hitA, hitB, idleA, idleB;
  sf_rfc_bank #(.ROWS(ROWS), .LANES(LANES), .RPW(32), .NUM_WARPS(NUM_WARPS), .RAM_STYLE(RAM_STYLE), .WRITE_THROUGH(WRITE_THROUGH)) u_a (
    .clk, .rst_n, .clr_all(clr_all_i), .clr_warp(clr_warp_i),
    .wr_en(bw_en), .wr_row(bw_row), .wr_mask(bw_mask), .wr_data(bw_data),
    .rd_en(1'b1), .rd_row(l_row0), .rd_data(rdA), .rd_hit(hitA), .idle(idleA));
  sf_rfc_bank #(.ROWS(ROWS), .LANES(LANES), .RPW(32), .NUM_WARPS(NUM_WARPS), .RAM_STYLE(RAM_STYLE), .WRITE_THROUGH(WRITE_THROUGH)) u_b (
    .clk, .rst_n, .clr_all(clr_all_i), .clr_warp(clr_warp_i),
    .wr_en(bw_en), .wr_row(bw_row), .wr_mask(bw_mask), .wr_data(bw_data),
    .rd_en(1'b1), .rd_row(l_row1), .rd_data(rdB), .rd_hit(hitB), .idle(idleB));

  // ---------------------------------------------------------------- R / O registers
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      r_v <= 1'b0;
      o_v <= 1'b0;
    end else begin
      if (r_move)       o_v <= 1'b1;
      else if (o_fire)  o_v <= 1'b0;
      if (iss_fire)     r_v <= 1'b1;
      else if (r_move)  r_v <= 1'b0;
    end
    if (r_move) begin
      o_cls <= r_cls;  o_warp <= r_warp;  o_tag <= r_tag;  o_mask <= r_mask;
      o_rd  <= r_rd;   o_wr   <= r_wr;    o_pay <= r_pay;
      o_d0  <= r_nd0 ? rdA : '0;
      o_d1  <= r_nd1 ? rdB : '0;
    end
    if (iss_fire) begin
      r_cls <= iss_cls_i;  r_warp <= iss_warp_i;  r_tag <= iss_tag_i;  r_mask <= iss_mask_i;
      r_rd  <= iss_rd_i;   r_wr   <= iss_wr_i;    r_pay <= iss_payload_i;
      r_nd0 <= n_nd0;      r_nd1  <= n_nd1;
      r_row0 <= n_row0;    r_row1 <= n_row1;
    end
  end

  always_comb begin
    for (int p = 0; p < NUM_CLS; p++) begin
      dsp_valid_o[p]   = o_v & (int'(o_cls) == p) & rst_n;
      dsp_warp_o[p]    = o_warp;
      dsp_tag_o[p]     = o_tag;
      dsp_mask_o[p]    = o_mask;
      dsp_wr_o[p]      = o_wr;
      dsp_rd_o[p]      = o_rd;
      dsp_payload_o[p] = o_pay;
      dsp_op1_o[p]     = o_d0;
      dsp_op2_o[p]     = o_d1;
      mon_dsp_cu_o[p]  = '0;
    end
  end

  assign idle_o = ~r_v & ~o_v & idleA & idleB;

  // ---------------------------------------------------------------- monitor / counters (reduced set)
  assign mon_alloc_o = '0;
  assign mon_req_o   = '0;
  assign mon_gnt_o   = '0;
  for (genvar r = 0; r < NREQ; r++) begin : g_mon
    assign mon_rq_warp_o[r] = '0;
    assign mon_rq_reg_o[r]  = '0;
  end

  if (PERF_EN) begin : g_perf
    logic [31:0] cnt [PERF_N];
    int unsigned inc [PERF_N];
    always_comb begin
      int unsigned nst, nwbs;
      nst = 0; nwbs = 0;
      for (int p = 0; p < NUM_CLS; p++) if (dsp_valid_o[p] && !dsp_ready_i[p]) nst++;
      for (int p = 0; p < NUM_WB; p++) if (wb_valid_i[p] && !w_acc[p]) nwbs++;
      for (int i = 0; i < PERF_N; i++) inc[i] = 0;
      inc[PERF_BUSY]      = (r_v | o_v) ? 1 : 0;
      inc[PERF_ALLOC]     = iss_fire ? 1 : 0;
      inc[PERF_DISPATCH]  = o_fire ? 1 : 0;
      inc[PERF_WB_ACCEPT] = bw_en ? 1 : 0;
      inc[PERF_WB_STALL]  = nwbs;
      inc[PERF_FWD_HIT]   = (r_v & (hitA | hitB)) ? 1 : 0;
      inc[PERF_CU_OCC]    = (r_v ? 1 : 0) + (o_v ? 1 : 0);
      inc[PERF_DSP_STALL] = nst;
      inc[PERF_FULL]      = (r_v & ~o_free) ? 1 : 0;
    end
    always_ff @(posedge clk) begin
      for (int i = 0; i < PERF_N; i++) begin
        if (!rst_n || perf_clear_i) cnt[i] <= '0;
        else if ((64'(cnt[i]) + 64'(inc[i])) > 64'hFFFF_FFFF) cnt[i] <= 32'hFFFF_FFFF;
        else cnt[i] <= cnt[i] + 32'(inc[i]);
      end
    end
    for (genvar i = 0; i < PERF_N; i++) begin : g_o
      assign perf_o[i] = cnt[i];
    end
  end else begin : g_noperf
    for (genvar i = 0; i < PERF_N; i++) begin : g_o
      assign perf_o[i] = '0;
    end
  end
endmodule
`default_nettype wire
