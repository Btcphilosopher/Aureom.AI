# Vendored SilicaFlux SIMT sources

Copied unchanged from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-simt (1).zip` (the SIMT warp scheduler and
control unit of this repository). They are used for three purposes only:

* `model/sfisa.py`, `model/sfref.py`, `model/sfgen.py`, `programs/*.s` -- instruction streams (with real divergence masks) for
  the traces, via `python/rfref/simt_trace.py`;
* `rtl/sf_simt_pkg.sv` -- the decode cross-check `tb/tb_decode_xcheck.sv` against `sf_predecode`;
* `rtl/*.sv` -- the reference integration wrapper `rtl/sf_simt_rfc_top.sv` (lint/elaboration of the interface mapping only).

Nothing here is modified or part of the deliverable's own RTL. The specification of these blocks is the original
`docs/ARCHITECTURE.md` in that archive.
