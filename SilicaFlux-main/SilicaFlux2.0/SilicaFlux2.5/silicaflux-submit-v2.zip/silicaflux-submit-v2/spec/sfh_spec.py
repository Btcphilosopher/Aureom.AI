#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Single source of truth for the SilicaFlux Host Submission Interface (HSI) v2.0.

Generates:
  rtl/sfh_pkg.sv            SystemVerilog package (device side)
  host/include/sfh_abi.h    C header (host side)
  docs/REGMAP.md            register map / descriptor layout reference

Usage:  python3 spec/sfh_spec.py            (write files)
        python3 spec/sfh_spec.py --check    (exit 1 if any generated file is stale)

Every constant shared between the RTL and the host runtime lives here; nothing
shared is hand-typed twice. `make check-gen` runs --check.
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# --------------------------------------------------------------------------------------
# Identity / versioning
# --------------------------------------------------------------------------------------
IDENT = [
    ("CHIP_ID",          0x53464001, "SF-G1 chip family id (unchanged from v1)"),
    ("HW_VERSION",       0x00020000, "HSI contract version: [31:16] major=2, [15:8] minor, [7:0] patch"),
    ("HW_MAJOR",         2,          "host refuses any other major"),
    ("DESC_MAGIC",       0xD5,       "descriptor dw0[7:0]; never a valid v1 opcode byte"),
    ("DESC_VERSION",     2,          "descriptor format version this host emits"),
    ("DESC_VERSIONS",    1 << 2,     "bitmask of descriptor versions the device accepts (bit n = version n)"),
    ("DESC_BYTES",       64,         ""),
    ("DESC_DWORDS",      16,         ""),
    ("DESC_CHECK_SALT",  0x5F5F5F5F, "xor of all 16 descriptor dwords must equal this"),
    ("CQE_BYTES",        16,         ""),
    ("FUNC_RESET_MAGIC", 0x52455345, "write to FUNC_RESET to reset the function ('RESE')"),
]

# Default implementation limits (the device reports its real values in LIMITS0/LIMITS1)
LIMITS = [
    ("NQ",            4,   "queue pairs (one MSI-X vector each)"),
    ("MAX_CTX",       4,   "hardware contexts (device-memory windows)"),
    ("N_ATT",         32,  "DMA mapping-table (ATT) entries"),
    ("FETCH_MAX",     8,   "max descriptors fetched by one burst read"),
    ("Q_LOG2_MIN",    4,   "min ring size 16"),
    ("Q_LOG2_MAX",    12,  "max ring size 4096"),
    ("WIN_LOG2",      20,  "device-memory window per context: 1 MiB"),
    ("DMA_ADDR_BITS", 64,  ""),
    ("MAX_RD_BYTES",  512, "max bytes per DMA read request (never crosses 4 KiB)"),
]

# --------------------------------------------------------------------------------------
# Register map (BAR0, byte offsets, 32-bit little-endian naturally aligned accesses)
# --------------------------------------------------------------------------------------
GLOBAL_REGS = [
    # name, off, access, description
    ("ID",            0x000, "RO", "CHIP_ID"),
    ("HW_VERSION",    0x004, "RO", "contract version"),
    ("CAPS",          0x008, "RO", "capability bits (CAP_*)"),
    ("DESC_VERSIONS", 0x00C, "RO", "accepted descriptor versions (bit n = version n)"),
    ("LIMITS0",       0x010, "RO", "[7:0] NQ, [15:8] MAX_CTX, [23:16] N_ATT, [31:24] FETCH_MAX"),
    ("LIMITS1",       0x014, "RO", "[7:0] DMA_ADDR_BITS, [15:8] WIN_LOG2, [23:16] Q_LOG2_MIN, [31:24] Q_LOG2_MAX"),
    ("TIMEBASE_LO",   0x018, "RO", "device timebase, ns (low)"),
    ("TIMEBASE_HI",   0x01C, "RO", "device timebase, ns (high)"),
    ("CTRL",          0x020, "W1S", "b0 ENGINE_RESET"),
    ("STATUS",        0x024, "RO", "b0 READY, b1 RESET_ACTIVE, b2 SCRUB_BUSY, b3 ATT_SYNC_PEND"),
    ("FUNC_RESET",    0x028, "WO", "write FUNC_RESET_MAGIC -> function reset"),
    ("SCRATCH",       0x02C, "RW", "no side effects"),
    ("CMD_TIMEOUT",   0x030, "RW", "per-command execution watchdog, ns (0 = off)"),
    ("FENCE_TIMEOUT", 0x034, "RW", "FENCE_WAIT timeout, ns (0 = wait forever)"),
    ("DONE_COUNT",    0x038, "RO", "commands retired (all queues, wraps)"),
    ("ERR_COUNT",     0x03C, "RO", "commands retired with error (wraps)"),
    ("DB_ERR_COUNT",  0x040, "RO", "rejected doorbell writes (all queues, wraps)"),
    ("SCRUB",         0x044, "WO", "[3:0] ctx, [31] GO: zero that context's device-memory window"),
    ("RESET_COUNT",   0x048, "RO", "engine+function resets performed"),
    ("ATT_IDX",       0x060, "RW", "mapping-table index for staging/readback"),
    ("ATT_BASE_LO",   0x064, "RW", "staged entry: host bus address / IOVA (low), 8-byte aligned"),
    ("ATT_BASE_HI",   0x068, "RW", "staged entry: host bus address / IOVA (high)"),
    ("ATT_SIZE",      0x06C, "RW", "staged entry: size in bytes (multiple of 8)"),
    ("ATT_CTL",       0x070, "RW", "staged entry: b0 VALID, b1 PERM_R, b2 PERM_W, [11:8] CTX, [31:16] GEN"),
    ("ATT_CMD",       0x074, "WO", "1 = WRITE staged entry to ATT_IDX, 2 = INVALIDATE ATT_IDX"),
    ("ATT_SYNC",      0x078, "WO", "write token; device copies it to ATT_SYNC_ACK once no DMA can still use an invalidated entry"),
    ("ATT_SYNC_ACK",  0x07C, "RO", "last completed ATT_SYNC token"),
]

QREG_BASE = 0x400
QREG_STRIDE = 0x80
QUEUE_REGS = [
    ("QSQ_BASE_LO",   0x00, "RW*", "SQ ring bus address (64-byte aligned)"),
    ("QSQ_BASE_HI",   0x04, "RW*", ""),
    ("QCQ_BASE_LO",   0x08, "RW*", "CQ ring bus address (64-byte aligned)"),
    ("QCQ_BASE_HI",   0x0C, "RW*", ""),
    ("QFENCE_LO",     0x10, "RW*", "8-byte fence slot the device writes on FENCE_SIGNAL (8-byte aligned)"),
    ("QFENCE_HI",     0x14, "RW*", ""),
    ("QSIZE",         0x18, "RW*", "[3:0] SQ log2 entries, [11:8] CQ log2 entries"),
    ("QCFG",          0x1C, "RW*", "[3:0] owner CTX, [31:16] EPOCH"),
    ("QSEQ_BASE",     0x20, "RW*", "sequence number expected in the first descriptor after ENABLE"),
    ("QIMOD_CNT",     0x24, "RW*", "interrupt moderation: fire after this many CQEs (0/1 = every CQE)"),
    ("QIMOD_TIME",    0x28, "RW*", "interrupt moderation: fire this many ns after the first un-signalled CQE (0 = off)"),
    ("QCTL",          0x2C, "W",   "b0 ENABLE (samples config), b1 RESET (stop, abort, quiesce)"),
    ("QSTATUS",       0x30, "RO",  "b0 ENABLED b1 HALTED b2 RESET_DONE b3 WAITING b4 CFG_ERR b5 ACTIVE b6 ARMED b7 ERR_VALID [15:8] ERR_STATUS"),
    ("QSTARTED_SEQ",  0x34, "RO",  "seq of the last command whose execution began (side effects possible)"),
    ("QCOMPLETED_SEQ",0x38, "RO",  "seq of the last command whose execution finished (before its CQE)"),
    ("QERR_SEQ",      0x3C, "RO",  "seq of the command that halted the queue (valid when ERR_VALID)"),
    ("QSQPOS",        0x40, "RO",  "[15:0] SQ head position, [31:16] SQ tail position (free-running)"),
    ("QCQPOS",        0x44, "RO",  "[15:0] CQ head position, [31:16] CQ tail position (free-running)"),
    ("QTIMELINE_LO",  0x48, "RW*", "fence timeline value (writable only while disabled)"),
    ("QTIMELINE_HI",  0x4C, "RW*", ""),
    ("QDB_ERR",       0x50, "RO",  "rejected doorbells on this queue (wraps)"),
    ("QDB_DUP",       0x54, "RO",  "duplicate (no-op) doorbells on this queue (wraps)"),
    ("QIRQ_COUNT",    0x58, "RO",  "interrupt messages sent for this queue (wraps)"),
    ("QFETCH_COUNT",  0x5C, "RO",  "descriptor fetch bursts for this queue (wraps)"),
]

DB_BASE = 0x1000
DB_STRIDE = 0x1000
DOORBELL_REGS = [
    ("DB_SQ_TAIL", 0x0, "W", "new SQ tail position (free-running 16-bit); publishes [old_tail, new_tail)"),
    ("DB_CQ_HEAD", 0x4, "W", "new CQ head position (free-running 16-bit); returns CQ credits"),
    ("DB_CQ_ARM",  0x8, "W", "1 = arm one interrupt for this CQ, 0 = disarm (polling)"),
]
BAR_BYTES = 0x8000

BITS = [
    # capabilities
    ("CAP_ENGINE_RESET", 0), ("CAP_FUNC_RESET", 1), ("CAP_QUEUE_RESET", 2), ("CAP_IMOD", 3),
    ("CAP_FENCE", 4), ("CAP_ATT", 5), ("CAP_CQE_SUPPRESS", 6), ("CAP_BATCH_FETCH", 7),
    ("CAP_SCRUB", 8), ("CAP_WATCHDOG", 9),
    # STATUS / CTRL
    ("STATUS_READY", 0), ("STATUS_RESET_ACTIVE", 1), ("STATUS_SCRUB_BUSY", 2), ("STATUS_ATT_SYNC_PEND", 3),
    ("CTRL_ENGINE_RESET", 0),
    # QCTL / QSTATUS
    ("QCTL_ENABLE", 0), ("QCTL_RESET", 1),
    ("QST_ENABLED", 0), ("QST_HALTED", 1), ("QST_RESET_DONE", 2), ("QST_WAITING", 3),
    ("QST_CFG_ERR", 4), ("QST_ACTIVE", 5), ("QST_ARMED", 6), ("QST_ERR_VALID", 7), ("QST_ERR_STATUS_LSB", 8),
    # ATT_CTL
    ("ATT_VALID", 0), ("ATT_PERM_R", 1), ("ATT_PERM_W", 2), ("ATT_CTX_LSB", 8), ("ATT_GEN_LSB", 16),
]

ATT_CMDS = [("ATT_CMD_WRITE", 1), ("ATT_CMD_INVALIDATE", 2)]

OPCODES = [
    ("OP_NOP",          0, "completes OK; no side effects"),
    ("OP_COPY_H2D",     1, "host mapping -> device window"),
    ("OP_COPY_D2H",     2, "device window -> host mapping"),
    ("OP_KERNEL",       3, "compute on the device window (param1[7:0] = KOP_*)"),
    ("OP_FENCE_SIGNAL", 4, "timeline := param0 (must increase); device writes param0 to the queue's fence slot"),
    ("OP_FENCE_WAIT",   5, "block this queue until timeline[param1] >= param0 (same owner context only)"),
]
OP_COUNT = 6

FLAGS = [
    ("FLAG_SUPPRESS_CQE", 0x01, "no CQE on success (errors always produce a CQE)"),
    ("FLAG_IRQ_NOW",      0x02, "this completion bypasses interrupt moderation"),
]
FLAGS_VALID = 0x03

KOPS = [
    ("KOP_ADD32", 0, "dst[i] = src[i] + param0[31:0]  (u32 lanes, wraps)"),
    ("KOP_XOR64", 1, "dst[i] = src[i] ^ param0          (u64 words)"),
    ("KOP_SUM32", 2, "CQE.result = sum of u32 lanes of src (wraps)"),
    ("KOP_SPIN",  3, "busy for param0 ns (models a long kernel); no memory access"),
]
KOP_COUNT = 4

STATUS = [
    ("ST_OK",            0, "completed"),
    ("ST_BAD_VERSION",   1, "magic or descriptor version not accepted"),
    ("ST_BAD_CHECK",     2, "descriptor check dword mismatch (torn / partially written slot)"),
    ("ST_STALE_EPOCH",   3, "descriptor epoch != queue epoch (written before a reset/re-enable)"),
    ("ST_STALE_SEQ",     4, "descriptor seq != expected seq (stale slot from an earlier lap)"),
    ("ST_BAD_OPCODE",    5, "unknown opcode"),
    ("ST_BAD_ARGS",      6, "reserved/unused field non-zero, bad flag, zero length, bad kop/target"),
    ("ST_BAD_HANDLE",    7, "mapping index out of range, entry invalid, or generation mismatch"),
    ("ST_PERM",          8, "mapping owned by another context, missing R/W permission, cross-context wait"),
    ("ST_ALIGN",         9, "offset/length not 8-byte aligned"),
    ("ST_BOUNDS",        10, "range outside the mapping or the context's device window"),
    ("ST_DMA_ERROR",     11, "bus error on descriptor fetch or data transfer"),
    ("ST_MAP_REVOKED",   12, "mapping invalidated while the transfer was running (partial)"),
    ("ST_TIMEOUT",       13, "execution watchdog expired (partial side effects possible)"),
    ("ST_FENCE_TIMEOUT", 14, "FENCE_WAIT not satisfied within FENCE_TIMEOUT"),
    ("ST_FENCE_ORDER",   15, "FENCE_SIGNAL value not greater than the current timeline"),
]

# Descriptor v2 layout: (field, dword, lsb, width, description)
DESC_FIELDS = [
    ("MAGIC",     0, 0,  8,  "DESC_MAGIC"),
    ("VERSION",   0, 8,  8,  "DESC_VERSION"),
    ("OPCODE",    0, 16, 8,  "OP_*"),
    ("FLAGS",     0, 24, 8,  "FLAG_*; other bits must be 0"),
    ("SEQ",       1, 0,  32, "per-queue sequence number; must equal the device's expected seq"),
    ("EPOCH",     2, 0,  16, "must equal QCFG.EPOCH"),
    ("RSVD2",     2, 16, 16, "must be 0"),
    ("USER_TAG",  3, 0,  32, "opaque, echoed in the CQE"),
    ("HANDLE",    4, 0,  32, "mapping handle: [15:0] ATT index, [31:16] generation (COPY_* only)"),
    ("LEN",       5, 0,  32, "bytes (multiple of 8)"),
    ("HOST_OFF",  6, 0,  64, "byte offset inside the mapping (dw6 low, dw7 high)"),
    ("DEV_OFF",   8, 0,  64, "window-relative offset: H2D dst, D2H src, KERNEL src"),
    ("DEV_OFF2",  10, 0, 64, "window-relative offset: KERNEL dst"),
    ("PARAM0",    12, 0, 64, "KERNEL constant / SPIN ns / fence value"),
    ("PARAM1",    14, 0, 32, "KERNEL kop / FENCE_WAIT target queue"),
    ("CHECK",     15, 0, 32, "DESC_CHECK_SALT ^ xor(dw0..dw14)"),
]

# CQE layout (16 bytes). dw3 carries the phase and is written LAST, in its own write.
CQE_FIELDS = [
    ("RESULT",   0, 0,  32, "op-specific (KOP_SUM32 result), else 0"),
    ("USER_TAG", 1, 0,  32, "echo"),
    ("SEQ",      2, 0,  32, "echo of descriptor seq"),
    ("PHASE",    3, 0,  1,  "1 on the first lap of the CQ, toggles every wrap"),
    ("STATUS",   3, 1,  7,  "ST_*"),
    ("SEQ_LO",   3, 8,  8,  "copy of SEQ[7:0]: lets the host detect a CQE whose dwords are from different writes"),
    ("SQ_HEAD",  3, 16, 16, "SQ head position after this command (frees SQ slots up to here)"),
]

# --------------------------------------------------------------------------------------
GEN_NOTE = "GENERATED by spec/sfh_spec.py -- DO NOT EDIT"


def sv_pkg():
    o = []
    o.append(f"// SPDX-License-Identifier: MIT\n// {GEN_NOTE}\n`timescale 1ns/1ps\npackage sfh_pkg;")
    def lp(name, val, width=32, comment=""):
        c = f"  // {comment}" if comment else ""
        o.append(f"  localparam logic [{width-1}:0] SFH_{name} = {width}'h{val:x};{c}")
    o.append("  // identity / versioning")
    for n, v, c in IDENT:
        lp(n, v, 32, c)
    o.append("  // default limits")
    for n, v, c in LIMITS:
        o.append(f"  localparam int SFH_{n} = {v};  // {c}" if c else f"  localparam int SFH_{n} = {v};")
    o.append("  // global registers")
    for n, off, acc, d in GLOBAL_REGS:
        lp("REG_" + n, off, 16)
    o.append(f"  localparam logic [15:0] SFH_QREG_BASE = 16'h{QREG_BASE:x};")
    o.append(f"  localparam logic [15:0] SFH_QREG_STRIDE = 16'h{QREG_STRIDE:x};")
    o.append("  // per-queue registers (offset within the queue block)")
    for n, off, acc, d in QUEUE_REGS:
        lp(n, off, 8)
    o.append(f"  localparam logic [15:0] SFH_DB_BASE = 16'h{DB_BASE:x};")
    o.append(f"  localparam logic [15:0] SFH_DB_STRIDE = 16'h{DB_STRIDE:x};")
    for n, off, acc, d in DOORBELL_REGS:
        lp(n, off, 12)
    o.append(f"  localparam int SFH_BAR_BYTES = {BAR_BYTES};")
    o.append("  // bit positions")
    for n, b in BITS:
        o.append(f"  localparam int SFH_{n} = {b};")
    for n, v in ATT_CMDS:
        lp(n, v, 32)
    o.append("  // opcodes / flags / kernel ops")
    for n, v, c in OPCODES:
        lp(n, v, 8, c)
    o.append(f"  localparam int SFH_OP_COUNT = {OP_COUNT};")
    for n, v, c in FLAGS:
        lp(n, v, 8, c)
    lp("FLAGS_VALID", FLAGS_VALID, 8)
    for n, v, c in KOPS:
        lp(n, v, 8, c)
    o.append(f"  localparam int SFH_KOP_COUNT = {KOP_COUNT};")
    o.append("  // completion status")
    for n, v, c in STATUS:
        lp(n, v, 7, c)
    o.append("  // descriptor field positions: dword index, lsb, width")
    for n, dw, lsb, w, c in DESC_FIELDS:
        o.append(f"  localparam int SFH_D_{n}_DW = {dw}, SFH_D_{n}_LSB = {lsb}, SFH_D_{n}_W = {w};")
    for n, dw, lsb, w, c in CQE_FIELDS:
        o.append(f"  localparam int SFH_C_{n}_DW = {dw}, SFH_C_{n}_LSB = {lsb}, SFH_C_{n}_W = {w};")
    o.append("endpackage\n")
    return "\n".join(o)


def c_hdr():
    o = []
    o.append(f"/* SPDX-License-Identifier: MIT */\n/* {GEN_NOTE} */")
    o.append("#ifndef SFH_ABI_H\n#define SFH_ABI_H\n#include <stdint.h>\n")
    def d(name, val, comment=""):
        c = f"  /* {comment} */" if comment else ""
        o.append(f"#define SFH_{name} 0x{val:x}u{c}")
    o.append("/* identity / versioning */")
    for n, v, c in IDENT:
        d(n, v, c)
    o.append("\n/* default limits (device reports real values in LIMITS0/LIMITS1) */")
    for n, v, c in LIMITS:
        o.append(f"#define SFH_{n} {v}u")
    o.append("\n/* global registers */")
    for n, off, acc, ds in GLOBAL_REGS:
        d("REG_" + n, off, f"{acc} {ds}")
    o.append(f"\n#define SFH_QREG_BASE 0x{QREG_BASE:x}u\n#define SFH_QREG_STRIDE 0x{QREG_STRIDE:x}u")
    o.append("#define SFH_QREG(q, r) (SFH_QREG_BASE + (uint32_t)(q) * SFH_QREG_STRIDE + (r))")
    for n, off, acc, ds in QUEUE_REGS:
        d(n, off, f"{acc} {ds}")
    o.append(f"\n#define SFH_DB_BASE 0x{DB_BASE:x}u\n#define SFH_DB_STRIDE 0x{DB_STRIDE:x}u")
    o.append("#define SFH_DBREG(q, r) (SFH_DB_BASE + (uint32_t)(q) * SFH_DB_STRIDE + (r))")
    for n, off, acc, ds in DOORBELL_REGS:
        d(n, off, f"{acc} {ds}")
    o.append(f"#define SFH_BAR_BYTES 0x{BAR_BYTES:x}u")
    o.append("\n/* bit positions */")
    for n, b in BITS:
        o.append(f"#define SFH_{n} {b}u")
    for n, v in ATT_CMDS:
        d(n, v)
    o.append("\n/* opcodes */")
    for n, v, c in OPCODES:
        d(n, v, c)
    o.append(f"#define SFH_OP_COUNT {OP_COUNT}u")
    for n, v, c in FLAGS:
        d(n, v, c)
    d("FLAGS_VALID", FLAGS_VALID)
    for n, v, c in KOPS:
        d(n, v, c)
    o.append(f"#define SFH_KOP_COUNT {KOP_COUNT}u")
    o.append("\n/* completion status (CQE.STATUS) */")
    for n, v, c in STATUS:
        d(n, v, c)
    o.append("\n/* descriptor v2 field positions: dword, lsb, width */")
    for n, dw, lsb, w, c in DESC_FIELDS:
        o.append(f"#define SFH_D_{n}_DW {dw}u\n#define SFH_D_{n}_LSB {lsb}u\n#define SFH_D_{n}_W {w}u")
    o.append("\n/* CQE field positions */")
    for n, dw, lsb, w, c in CQE_FIELDS:
        o.append(f"#define SFH_C_{n}_DW {dw}u\n#define SFH_C_{n}_LSB {lsb}u\n#define SFH_C_{n}_W {w}u")
    o.append("""
/* In-memory layouts. Little-endian; the host CPU is assumed little-endian (checked at build). */
typedef struct sfh_desc { uint32_t dw[16]; } sfh_desc;   /* 64 bytes, SQ slot */
typedef struct sfh_cqe  { uint32_t dw[4];  } sfh_cqe;    /* 16 bytes, CQ slot */
#ifdef __cplusplus
static_assert(sizeof(sfh_desc) == 64, "descriptor size");
static_assert(sizeof(sfh_cqe) == 16, "cqe size");
#else
_Static_assert(sizeof(sfh_desc) == 64, "descriptor size");
_Static_assert(sizeof(sfh_cqe) == 16, "cqe size");
#endif
#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error "sfh: big-endian hosts are not supported by this runtime"
#endif
""")
    o.append("static const char *const sfh_status_names[] = {")
    for n, v, c in STATUS:
        o.append(f'  [{v}] = "{n[3:]}",')
    o.append("};\n#endif /* SFH_ABI_H */\n")
    return "\n".join(o)


def regmap_md():
    o = [f"<!-- {GEN_NOTE} -->", "# HSI v2.0 register map and in-memory formats", ""]
    o.append("Normative prose lives in [`CONTRACT.md`](CONTRACT.md); this file is the generated, exact layout.")
    o.append("`RW*` = writable only while the queue is disabled (ignored otherwise).\n")
    o.append("## Identity and limits\n\n| Name | Value | Notes |\n|---|---|---|")
    for n, v, c in IDENT:
        o.append(f"| `{n}` | `0x{v:x}` | {c} |")
    for n, v, c in LIMITS:
        o.append(f"| `{n}` | {v} | {c} |")
    o.append("\n## Global registers (BAR0)\n\n| Offset | Name | Access | Description |\n|---|---|---|---|")
    for n, off, acc, ds in GLOBAL_REGS:
        o.append(f"| `0x{off:03x}` | `{n}` | {acc} | {ds} |")
    o.append(f"\n## Per-queue registers (privileged) — `0x{QREG_BASE:x} + q*0x{QREG_STRIDE:x}`\n")
    o.append("| Offset | Name | Access | Description |\n|---|---|---|---|")
    for n, off, acc, ds in QUEUE_REGS:
        o.append(f"| `+0x{off:02x}` | `{n}` | {acc} | {ds} |")
    o.append(f"\n## Doorbell pages — `0x{DB_BASE:x} + q*0x{DB_STRIDE:x}` (one 4 KiB page per queue)\n")
    o.append("Each page contains only these registers, so a page can be mapped into exactly one process "
             "without exposing anything else. Reads return 0.\n")
    o.append("| Offset | Name | Access | Description |\n|---|---|---|---|")
    for n, off, acc, ds in DOORBELL_REGS:
        o.append(f"| `+0x{off:x}` | `{n}` | {acc} | {ds} |")
    o.append("\n## Bit fields\n\n| Name | Bit |\n|---|---|")
    for n, b in BITS:
        o.append(f"| `{n}` | {b} |")
    o.append("\n## Opcodes\n\n| Value | Name | Semantics |\n|---|---|---|")
    for n, v, c in OPCODES:
        o.append(f"| {v} | `{n}` | {c} |")
    o.append("\n## Flags\n\n| Value | Name | Meaning |\n|---|---|---|")
    for n, v, c in FLAGS:
        o.append(f"| `0x{v:02x}` | `{n}` | {c} |")
    o.append("\n## Kernel ops (`OP_KERNEL`, `param1[7:0]`)\n\n| Value | Name | Semantics |\n|---|---|---|")
    for n, v, c in KOPS:
        o.append(f"| {v} | `{n}` | {c} |")
    o.append("\n## Completion status\n\n| Value | Name | Meaning |\n|---|---|---|")
    for n, v, c in STATUS:
        o.append(f"| {v} | `{n}` | {c} |")
    o.append("\n## Descriptor v2 (64 bytes)\n\n| Field | dword | bits | Description |\n|---|---|---|---|")
    for n, dw, lsb, w, c in DESC_FIELDS:
        bits = f"[{lsb+w-1}:{lsb}]" if w <= 32 else f"dw{dw}..dw{dw+1}"
        o.append(f"| `{n}` | {dw} | {bits} | {c} |")
    o.append("\n## Completion entry (16 bytes)\n\n| Field | dword | bits | Description |\n|---|---|---|---|")
    for n, dw, lsb, w, c in CQE_FIELDS:
        o.append(f"| `{n}` | {dw} | [{lsb+w-1}:{lsb}] | {c} |")
    o.append("")
    return "\n".join(o)


OUTPUTS = {
    "rtl/sfh_pkg.sv": sv_pkg,
    "host/include/sfh_abi.h": c_hdr,
    "docs/REGMAP.md": regmap_md,
}


def main():
    check = "--check" in sys.argv
    stale = []
    for rel, fn in OUTPUTS.items():
        path = os.path.join(ROOT, rel)
        text = fn()
        if check:
            try:
                with open(path) as f:
                    if f.read() != text:
                        stale.append(rel)
            except FileNotFoundError:
                stale.append(rel)
        else:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                f.write(text)
    if check:
        if stale:
            print("STALE generated files:", ", ".join(stale))
            sys.exit(1)
        print(f"generated files up to date ({len(OUTPUTS)})")
    else:
        print("wrote", ", ".join(OUTPUTS))


if __name__ == "__main__":
    main()
