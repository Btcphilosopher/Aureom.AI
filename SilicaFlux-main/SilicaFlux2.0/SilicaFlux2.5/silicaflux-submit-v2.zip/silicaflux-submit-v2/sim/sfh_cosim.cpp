// SPDX-License-Identifier: MIT
// -----------------------------------------------------------------------------
// SilicaFlux HSI v2 — simulation transport: Verilated RTL + virtual-time host model.
// See sfh_cosim.h for the model. Key invariants:
//   * device time (dev_now) never runs ahead of host time when the host mutates
//     shared state: every transport op first advances the device to host_t;
//   * host->device MMIO is one in-order channel (posted writes and read requests);
//   * device->host is one in-order channel carrying posted writes, interrupt
//     messages and MMIO read completions (a completion cannot pass a write);
//   * the IOMMU check happens when an access reaches host memory.
// -----------------------------------------------------------------------------
#include "sfh_cosim.h"
#include "sfh_abi.h"
#include "Vsfh_top.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>

#ifndef SFH_MUTANT
#define SFH_MUTANT 0
#endif

namespace {

constexpr uint64_t IOVA_BASE = 0x1'0000'0000ull;    // exercise >32-bit bus addresses
constexpr size_t   ARENA     = 192u << 20;
constexpr uint64_t NEVER     = ~0ull;

struct Region { uint64_t size; unsigned perm; };
struct MmioOp { uint64_t t; bool rd; uint16_t addr; uint32_t data; };
struct Beat   { uint64_t t; uint64_t data; bool err; };
enum D2HKind { W_MEM, W_MSI, W_RDCPL };
struct D2H    { uint64_t t; D2HKind k; uint64_t addr; uint64_t data; uint8_t be; uint32_t vec; };
struct IrqEv  { uint64_t t; uint32_t vec; };
struct Store  { size_t off; std::vector<uint8_t> bytes; };
struct Tr     { uint64_t t_fetch = 0, t_start = 0, t_end = 0, t_cqe = 0; uint32_t status = 0; bool fetched = false; };

struct Sim {
	VerilatedContext *vc = nullptr;
	Vsfh_top *top = nullptr;
	sfh_sim_profile p{};
	sfh_transport tp{};
	sfh_sim_stats st{};
	uint64_t dev_now = 0, host_t = 0;
	bool skip = true;
	int verbose = 0;
	// host memory
	std::vector<uint8_t> mem;
	std::map<size_t, size_t> free_blocks;     // offset -> size
	std::map<uint64_t, Region> iommu;         // iova -> region
	std::vector<Store> sb;
	bool strict_sb = true;
	// channels
	std::deque<MmioOp> h2d;  uint64_t h2d_last = 0;
	std::deque<Beat>   rsp;  uint64_t rsp_last = 0;
	std::deque<D2H>    d2h;  uint64_t d2h_last = 0;
	std::deque<IrqEv>  irq_ev;               // interrupt messages arrived/arriving at the host
	uint32_t irq_pending = 0;
	bool rd_done = false; uint32_t rd_val = 0; uint64_t rd_t = 0;
	// faults
	uint64_t fi_drop_cqe = 0, fi_dup_cqe = 0, fi_drop_msi = 0, fi_dup_msi = 0, fi_rd_err = 0;
	int freeze_mode = 0;
	// trace
	std::unordered_map<uint64_t, Tr> trace;
	uint64_t hash = 1469598103934665603ull;
	uint64_t last_dw3_t = 0;
	std::vector<std::pair<uint64_t, uint16_t>> db[8];   // (arrival time, new tail) per queue
	size_t db_cur[8] = {0};
};

inline uint64_t key(unsigned q, uint32_t seq) { return (uint64_t(q) << 32) | seq; }
inline void mix(Sim *s, uint64_t v) { s->hash = (s->hash ^ v) * 1099511628211ull; }

// ---------------------------------------------------------------- IOMMU (DMA oracle)
bool iommu_ok(Sim *s, uint64_t a, uint64_t n, unsigned perm) {
	auto it = s->iommu.upper_bound(a);
	if (it == s->iommu.begin()) return false;
	--it;
	if (a < it->first || a + n > it->first + it->second.size || a + n < a) return false;
	return (it->second.perm & perm) == perm;
}
uint8_t *host_ptr(Sim *s, uint64_t iova) { return s->mem.data() + (iova - IOVA_BASE); }
bool in_arena(Sim *s, uint64_t a, uint64_t n) {
	return a >= IOVA_BASE && a + n <= IOVA_BASE + s->mem.size() && a + n >= a;
}
void violation(Sim *s, uint64_t a, const char *what) {
	s->st.iommu_violations++;
	s->st.last_violation_iova = a;
	if (s->verbose) fprintf(stderr, "[cosim] IOMMU VIOLATION %s iova=0x%llx t=%llu\n", what,
	                        (unsigned long long)a, (unsigned long long)s->dev_now);
}

// ---------------------------------------------------------------- device -> host delivery
void apply_d2h(Sim *s, const D2H &w) {
	switch (w.k) {
	case W_MEM: {
		if (!in_arena(s, w.addr, 8) || !iommu_ok(s, w.addr, 8, SFH_IOMMU_DEV_WRITE)) {
			violation(s, w.addr, "write");
			return;
		}
		uint8_t *p = host_ptr(s, w.addr);
		for (int i = 0; i < 8; i++)
			if (w.be & (1u << i)) p[i] = uint8_t(w.data >> (8 * i));
		s->st.dma_wr_bytes += __builtin_popcount(w.be);
		// fault: duplicate a CQE into the next slot (same lap/phase) -> host must reject it
		if (w.be == 0xF0 && s->fi_dup_cqe) {
			uint64_t ent = w.addr - 8, nxt = ent + 16;
			if (iommu_ok(s, nxt, 16, SFH_IOMMU_DEV_WRITE)) {
				s->fi_dup_cqe--;
				memcpy(host_ptr(s, nxt), host_ptr(s, ent), 16);
			}
		}
		break;
	}
	case W_MSI:
		s->irq_ev.push_back({w.t, w.vec});
		s->st.msi_delivered++;
		break;
	case W_RDCPL:
		s->rd_done = true;
		s->rd_t = w.t;
		s->rd_val = uint32_t(w.data);
		break;
	}
}
void drain_d2h(Sim *s, uint64_t upto) {
	while (!s->d2h.empty() && s->d2h.front().t <= upto) {
		D2H w = s->d2h.front();
		s->d2h.pop_front();
		apply_d2h(s, w);
	}
}
void push_d2h(Sim *s, D2H w) {
	if (w.t < s->d2h_last) w.t = s->d2h_last;      // in-order channel
	s->d2h_last = w.t;
	s->d2h.push_back(w);
}

// ---------------------------------------------------------------- one device clock cycle
void cycle(Sim *s) {
	Vsfh_top *t = s->top;
	t->now = s->dev_now;
	// host -> device: at most one MMIO operation per cycle, in order
	t->mmio_wr_valid = 0; t->mmio_rd_valid = 0;
	if (!s->h2d.empty() && s->h2d.front().t <= s->dev_now) {
		MmioOp op = s->h2d.front();
		s->h2d.pop_front();
		if (op.rd) { t->mmio_rd_valid = 1; t->mmio_rd_addr = op.addr; }
		else {
			t->mmio_wr_valid = 1; t->mmio_wr_addr = op.addr; t->mmio_wr_data = op.data;
			if (op.addr >= SFH_DB_BASE && ((op.addr - SFH_DB_BASE) & 0xfff) == SFH_DB_SQ_TAIL) {
				unsigned qq = (op.addr - SFH_DB_BASE) >> 12;
				if (qq < 8) s->db[qq].push_back({s->dev_now, uint16_t(op.data)});
			}
			// freeze faults are cleared by the resets that recover the device
			if (s->freeze_mode == 1 && op.addr == SFH_REG_CTRL && (op.data & 1)) s->freeze_mode = 0;
			if (s->freeze_mode && op.addr == SFH_REG_FUNC_RESET && op.data == SFH_FUNC_RESET_MAGIC) s->freeze_mode = 0;
		}
	}
	t->fi_freeze = s->freeze_mode ? 1 : 0;
	// read response beat
	t->rd_rsp_valid = 0; t->rd_rsp_err = 0;
	if (!s->rsp.empty() && s->rsp.front().t <= s->dev_now) {
		Beat b = s->rsp.front();
		s->rsp.pop_front();
		t->rd_rsp_valid = 1; t->rd_rsp_data = b.data; t->rd_rsp_err = b.err;
	}
	t->rd_req_ready = 1;
	t->wr_ready = 1;
	t->clk = 0;
	t->eval();
	// ---- sample combinational handshakes (they complete at this edge) ----
	if (t->rd_req_valid) {
		uint64_t a = t->rd_req_addr, n = t->rd_req_len;
		bool ok = in_arena(s, a, n) && iommu_ok(s, a, n, SFH_IOMMU_DEV_READ);
		bool err = false;
		if (!ok) { violation(s, a, "read"); err = true; }
		if (s->fi_rd_err) { s->fi_rd_err--; err = true; }
		uint64_t t0 = s->dev_now + s->p.dma_rd_lat_ns;
		if (t0 <= s->rsp_last) t0 = s->rsp_last + 1;
		for (uint64_t i = 0; i < n / 8; i++) {
			uint64_t d = 0;
			if (!err) memcpy(&d, host_ptr(s, a + 8 * i), 8);
			s->rsp.push_back({t0 + i, d, err});
		}
		s->rsp_last = t0 + n / 8 - 1;
		s->st.dma_rd_bytes += n;
	}
	if (t->wr_valid) {
		if (t->wr_msi) {
			uint32_t vec = uint32_t(t->wr_data & 0xff);
			s->st.msi_issued++;
			mix(s, 0x4d5349ull ^ (uint64_t(vec) << 40) ^ s->dev_now);
			if (s->fi_drop_msi) s->fi_drop_msi--;
			else {
				push_d2h(s, {s->dev_now + s->p.dma_wr_lat_ns, W_MSI, 0, 0, 0, vec});
				if (s->fi_dup_msi) {
					s->fi_dup_msi--;
					push_d2h(s, {s->dev_now + s->p.dma_wr_lat_ns + 20000, W_MSI, 0, 0, 0, vec});
				}
			}
		} else {
			bool drop = false;
			if (t->wr_be == 0xF0 && s->fi_drop_cqe) { s->fi_drop_cqe--; drop = true; }
			uint64_t ta = s->dev_now + s->p.dma_wr_lat_ns;
			if (ta < s->d2h_last) ta = s->d2h_last;
			if (t->wr_be == 0xF0) s->last_dw3_t = ta;
			if (!drop) push_d2h(s, {ta, W_MEM, t->wr_addr, t->wr_data, uint8_t(t->wr_be), 0});
		}
	}
	// ---- clock edge ----
	t->clk = 1;
	t->eval();
	s->st.cycles_stepped++;
	// ---- registered outputs (valid for exactly one cycle after the edge) ----
	if (t->mmio_rd_resp_valid)
		push_d2h(s, {s->dev_now + s->p.mmio_rd_rtt_ns / 2, W_RDCPL, 0, t->mmio_rd_data, 0, 0});
	if (t->trc_fetch_v) {
		for (unsigned i = 0; i < t->trc_fetch_n; i++) {
			Tr &r = s->trace[key(t->trc_fetch_q, t->trc_fetch_seq + i)];
			if (!r.fetched) { r.fetched = true; r.t_fetch = s->dev_now; }
		}
		mix(s, 0x46ull ^ (uint64_t(t->trc_fetch_seq) << 8) ^ (s->dev_now << 20) ^ t->trc_fetch_n);
	}
	if (t->trc_start_v) {
		s->trace[key(t->trc_start_q, t->trc_start_seq)].t_start = s->dev_now;
		mix(s, 0x53ull ^ (uint64_t(t->trc_start_seq) << 8) ^ (s->dev_now << 20));
	}
	if (t->trc_end_v) {
		Tr &r = s->trace[key(t->trc_end_q, t->trc_end_seq)];
		r.t_end = s->dev_now; r.status = t->trc_end_status;
		mix(s, 0x45ull ^ (uint64_t(t->trc_end_seq) << 8) ^ (s->dev_now << 20) ^ t->trc_end_status);
	}
	if (t->trc_cqe_v) {
		s->trace[key(t->trc_cqe_q, t->trc_cqe_seq)].t_cqe = s->last_dw3_t;
		mix(s, 0x43ull ^ (uint64_t(t->trc_cqe_seq) << 8) ^ (s->last_dw3_t << 20));
	}
	s->dev_now++;
}

// earliest pending input event for the device
uint64_t next_input(Sim *s) {
	uint64_t n = NEVER;
	if (!s->h2d.empty()) n = s->h2d.front().t;
	if (!s->rsp.empty() && s->rsp.front().t < n) n = s->rsp.front().t;
	return n;
}

// Advance the device to time T. If stop_mask != 0, return early (true) as soon as an
// interrupt message for one of those vectors has been issued (its arrival time is known).
bool advance(Sim *s, uint64_t T, uint32_t stop_mask = 0) {
	while (s->dev_now < T) {
		if (stop_mask) {
			for (auto &e : s->irq_ev) if ((1u << e.vec) & stop_mask) return true;
			for (auto &w : s->d2h) if (w.k == W_MSI && ((1u << w.vec) & stop_mask)) return true;
		}
		if (s->skip) {
			Vsfh_top *t = s->top;
			t->now = s->dev_now; t->mmio_wr_valid = 0; t->mmio_rd_valid = 0; t->rd_rsp_valid = 0;
			t->fi_freeze = s->freeze_mode ? 1 : 0;
			t->clk = 1;
			t->eval();
			uint64_t ni = next_input(s);
			if (t->quiescent && ni > s->dev_now) {
				uint64_t nxt = T;
				if (ni < nxt) nxt = ni;
				if (t->wake_at < nxt) nxt = t->wake_at;
				if (nxt > s->dev_now) {
					s->st.ns_skipped += nxt - s->dev_now;
					s->dev_now = nxt;
					drain_d2h(s, s->dev_now);
					continue;
				}
			}
		}
		cycle(s);
		drain_d2h(s, s->dev_now);
	}
	drain_d2h(s, s->dev_now);
	if (stop_mask) {
		for (auto &e : s->irq_ev) if ((1u << e.vec) & stop_mask) return true;
		for (auto &w : s->d2h) if (w.k == W_MSI && ((1u << w.vec) & stop_mask)) return true;
	}
	return false;
}

// interrupts that reached the host while its thread was running: the ISR preempts it
void take_isrs(Sim *s) {
	while (!s->irq_ev.empty() && s->irq_ev.front().t + s->p.msi_to_isr_ns <= s->host_t) {
		s->irq_pending |= 1u << s->irq_ev.front().vec;
		s->irq_ev.pop_front();
		s->st.isr_runs++;
		s->host_t += s->p.isr_cpu_ns;
		s->st.host_busy_ns += s->p.isr_cpu_ns;
	}
}
void sync_dev(Sim *s) { advance(s, s->host_t); take_isrs(s); }

// ---------------------------------------------------------------- transport ops
uint32_t op_mmio_rd32(void *v, uint32_t off) {
	Sim *s = (Sim *)v;
	sync_dev(s);
	uint64_t t0 = s->host_t;
	uint64_t ta = s->host_t + s->p.mmio_rd_rtt_ns / 2;
	if (ta <= s->h2d_last) ta = s->h2d_last + 1;
	s->h2d_last = ta;
	s->h2d.push_back({ta, true, uint16_t(off), 0});
	s->rd_done = false;
	while (!s->rd_done) advance(s, s->dev_now + 1);
	if (s->rd_t > s->host_t) s->host_t = s->rd_t;
	s->st.host_busy_ns += s->host_t - t0;
	s->st.mmio_rd++;
	take_isrs(s);
	return s->rd_val;
}
void op_mmio_wr32(void *v, uint32_t off, uint32_t val) {
	Sim *s = (Sim *)v;
	sync_dev(s);
	s->host_t += s->p.mmio_wr_cpu_ns;
	s->st.host_busy_ns += s->p.mmio_wr_cpu_ns;
	uint64_t ta = s->host_t + s->p.mmio_wr_lat_ns;
	if (ta <= s->h2d_last) ta = s->h2d_last + 1;
	s->h2d_last = ta;
	s->h2d.push_back({ta, false, uint16_t(off), val});
	s->st.mmio_wr++;
}
int op_dma_alloc(void *v, size_t size, void **cpu, uint64_t *iova) {
	Sim *s = (Sim *)v;
	size = (size + 4095) & ~size_t(4095);
	for (auto it = s->free_blocks.begin(); it != s->free_blocks.end(); ++it) {
		if (it->second >= size) {
			size_t off = it->first, rem = it->second - size;
			s->free_blocks.erase(it);
			if (rem) s->free_blocks[off + size] = rem;
			memset(s->mem.data() + off, 0, size);
			*cpu = s->mem.data() + off;
			*iova = IOVA_BASE + off;
			return 0;
		}
	}
	return -1;
}
void op_dma_free(void *v, void *cpu, uint64_t iova, size_t size) {
	Sim *s = (Sim *)v;
	(void)cpu;
	size = (size + 4095) & ~size_t(4095);
	size_t off = iova - IOVA_BASE;
	memset(s->mem.data() + off, 0xEE, size);   // poison: late device reads/writes are detectable
	auto nx = s->free_blocks.lower_bound(off);
	if (nx != s->free_blocks.end() && nx->first == off + size) { size += nx->second; s->free_blocks.erase(nx); }
	auto pv = s->free_blocks.lower_bound(off);
	if (pv != s->free_blocks.begin()) {
		--pv;
		if (pv->first + pv->second == off) { pv->second += size; return; }
	}
	s->free_blocks[off] = size;
}
int op_iommu_map(void *v, uint64_t iova, size_t size, unsigned perm) {
	Sim *s = (Sim *)v;
	sync_dev(s);
	s->iommu[iova] = {size, perm};
	return 0;
}
void op_iommu_unmap(void *v, uint64_t iova, size_t size) {
	Sim *s = (Sim *)v;
	(void)size;
	sync_dev(s);
	s->iommu.erase(iova);
}
void op_dma_store(void *v, void *dst, const void *src, size_t n) {
	Sim *s = (Sim *)v;
	size_t off = (uint8_t *)dst - s->mem.data();
	if (!s->strict_sb) { memcpy(dst, src, n); return; }
	Store st;
	st.off = off;
	st.bytes.assign((const uint8_t *)src, (const uint8_t *)src + n);
	s->sb.push_back(std::move(st));
}
void op_wmb(void *v) {
	Sim *s = (Sim *)v;
	sync_dev(s);
	for (auto &st : s->sb) memcpy(s->mem.data() + st.off, st.bytes.data(), st.bytes.size());
	s->sb.clear();
	s->host_t += s->p.barrier_ns;
	s->st.host_busy_ns += s->p.barrier_ns;
}
void op_rmb(void *v) {
	Sim *s = (Sim *)v;
	s->host_t += s->p.barrier_ns;
	s->st.host_busy_ns += s->p.barrier_ns;
}
uint32_t op_irq_take(void *v, uint32_t mask) {
	Sim *s = (Sim *)v;
	take_isrs(s);
	uint32_t r = s->irq_pending & mask;
	s->irq_pending &= ~r;
	return r;
}
uint32_t op_irq_wait(void *v, uint32_t mask, uint64_t deadline) {
	Sim *s = (Sim *)v;
	sync_dev(s);
	uint32_t r = s->irq_pending & mask;
	if (r) { s->irq_pending &= ~r; return r; }
	uint64_t t_sleep = s->host_t;
	// sleep: the device runs on until a matching interrupt message is issued or the deadline
	// an unbounded sleep is capped at 10 s of virtual time (nothing in this design sleeps longer)
	uint64_t limit = (deadline == NEVER || deadline > t_sleep + 10000000000ull) ? t_sleep + 10000000000ull : deadline;
	advance(s, limit, mask);
	// find the earliest matching interrupt (arrived or in flight)
	uint64_t t_irq = NEVER;
	for (auto &e : s->irq_ev) if (((1u << e.vec) & mask) && e.t < t_irq) t_irq = e.t;
	for (auto &w : s->d2h) if (w.k == W_MSI && ((1u << w.vec) & mask) && w.t < t_irq) t_irq = w.t;
	if (t_irq != NEVER && t_irq + s->p.msi_to_isr_ns <= limit) {
		uint64_t isr_at = (t_irq > t_sleep ? t_irq : t_sleep) + s->p.msi_to_isr_ns;
		s->host_t = isr_at + s->p.wakeup_lat_ns;      // + ISR time, added by take_isrs below
		s->st.host_busy_ns += s->p.ctxsw_cpu_ns;     // ISR cost is charged by take_isrs
		s->st.wakeups++;
		sync_dev(s);                                  // charges the ISR(s) that ran meanwhile
		r = s->irq_pending & mask;
		s->irq_pending &= ~r;
		return r;
	}
	s->host_t = (limit > t_sleep ? limit : t_sleep) + s->p.timer_lat_ns;
	s->st.host_busy_ns += s->p.ctxsw_cpu_ns;
	s->st.timer_wakeups++;
	sync_dev(s);
	r = s->irq_pending & mask;
	s->irq_pending &= ~r;
	return r;
}
uint64_t op_now(void *v) { return ((Sim *)v)->host_t; }
void op_cpu_cost(void *v, unsigned kind, uint32_t n) {
	Sim *s = (Sim *)v;
	uint64_t ns = 0;
	switch (kind) {
	case SFH_COST_SYSCALL:  ns = s->p.syscall_cpu_ns; break;
	case SFH_COST_KMD_DESC: ns = s->p.kmd_desc_cpu_ns; break;
	case SFH_COST_UMD_DESC: ns = s->p.umd_desc_cpu_ns; break;
	case SFH_COST_CQE:      ns = s->p.cqe_cpu_ns; break;
	case SFH_COST_POLL:     ns = s->p.poll_iter_ns; break;
	}
	ns *= n;
	s->host_t += ns;
	s->st.host_busy_ns += ns;
	if (kind == SFH_COST_POLL) { s->st.host_poll_ns += ns; sync_dev(s); }
}
void op_sync(void *v) { sync_dev((Sim *)v); }

const sfh_transport_ops OPS = {
	op_mmio_rd32, op_mmio_wr32, op_dma_alloc, op_dma_free, op_iommu_map, op_iommu_unmap,
	op_dma_store, op_wmb, op_rmb, op_irq_wait, op_irq_take, op_now, op_cpu_cost, op_sync,
};

} // namespace

// ---------------------------------------------------------------- C API
extern "C" {

void sfh_sim_profile_default(sfh_sim_profile *p) {
	p->mmio_wr_cpu_ns = 60;
	p->mmio_wr_lat_ns = 400;
	p->mmio_rd_rtt_ns = 1000;
	p->dma_rd_lat_ns = 800;
	p->dma_wr_lat_ns = 400;
	p->msi_to_isr_ns = 700;
	p->isr_cpu_ns = 1200;
	p->wakeup_lat_ns = 2500;
	p->ctxsw_cpu_ns = 2000;
	p->timer_lat_ns = 2500;
	p->syscall_cpu_ns = 350;
	p->kmd_desc_cpu_ns = 45;
	p->umd_desc_cpu_ns = 25;
	p->cqe_cpu_ns = 30;
	p->poll_iter_ns = 40;
	p->barrier_ns = 5;
}

int sfh_sim_profile_parse(sfh_sim_profile *p, const char *kv) {
	struct { const char *k; uint32_t *v; } t[] = {
		{"mmio_wr_cpu_ns", &p->mmio_wr_cpu_ns}, {"mmio_wr_lat_ns", &p->mmio_wr_lat_ns},
		{"mmio_rd_rtt_ns", &p->mmio_rd_rtt_ns}, {"dma_rd_lat_ns", &p->dma_rd_lat_ns},
		{"dma_wr_lat_ns", &p->dma_wr_lat_ns}, {"msi_to_isr_ns", &p->msi_to_isr_ns},
		{"isr_cpu_ns", &p->isr_cpu_ns}, {"wakeup_lat_ns", &p->wakeup_lat_ns},
		{"ctxsw_cpu_ns", &p->ctxsw_cpu_ns}, {"timer_lat_ns", &p->timer_lat_ns},
		{"syscall_cpu_ns", &p->syscall_cpu_ns}, {"kmd_desc_cpu_ns", &p->kmd_desc_cpu_ns},
		{"umd_desc_cpu_ns", &p->umd_desc_cpu_ns}, {"cqe_cpu_ns", &p->cqe_cpu_ns},
		{"poll_iter_ns", &p->poll_iter_ns}, {"barrier_ns", &p->barrier_ns},
	};
	std::string s(kv ? kv : "");
	size_t pos = 0;
	while (pos < s.size()) {
		size_t e = s.find(',', pos);
		if (e == std::string::npos) e = s.size();
		std::string item = s.substr(pos, e - pos);
		pos = e + 1;
		if (item.empty()) continue;
		size_t eq = item.find('=');
		if (eq == std::string::npos) return -1;
		std::string k = item.substr(0, eq);
		bool found = false;
		for (auto &x : t)
			if (k == x.k) { *x.v = uint32_t(strtoul(item.c_str() + eq + 1, nullptr, 0)); found = true; }
		if (!found) return -1;
	}
	return 0;
}

void *sfh_sim_create(const sfh_sim_profile *p) {
	Sim *s = new Sim();
	if (p) s->p = *p; else sfh_sim_profile_default(&s->p);
	s->vc = new VerilatedContext();
	s->top = new Vsfh_top(s->vc);
	s->mem.assign(ARENA, 0);
	s->free_blocks[0] = ARENA;
	s->tp.ops = &OPS;
	s->tp.ctx = s;
	s->tp.name = "cosim";
	Vsfh_top *t = s->top;
	t->clk = 0; t->rst_n = 0; t->now = 0;
	t->mmio_wr_valid = 0; t->mmio_rd_valid = 0; t->rd_req_ready = 1; t->rd_rsp_valid = 0;
	t->wr_ready = 1; t->fi_kernel_hang = 0; t->fi_freeze = 0;
	t->eval(); t->clk = 1; t->eval();
	t->rst_n = 1;
	t->eval();
	return s;
}
void sfh_sim_destroy(void *v) {
	Sim *s = (Sim *)v;
	s->top->final();
	delete s->top;
	delete s->vc;
	delete s;
}
const sfh_transport *sfh_sim_transport(void *v) { return &((Sim *)v)->tp; }
int sfh_sim_mutant(void) { return SFH_MUTANT; }

void sfh_sim_fault(void *v, int f, uint64_t arg) {
	Sim *s = (Sim *)v;
	sync_dev(s);
	switch (f) {
	case SFH_FI_DROP_CQE: s->fi_drop_cqe = arg; break;
	case SFH_FI_DUP_CQE: s->fi_dup_cqe = arg; break;
	case SFH_FI_DROP_MSI: s->fi_drop_msi = arg; break;
	case SFH_FI_DUP_MSI: s->fi_dup_msi = arg; break;
	case SFH_FI_KERNEL_HANG: s->top->fi_kernel_hang = arg ? 1 : 0; break;
	case SFH_FI_FREEZE: s->freeze_mode = int(arg); break;
	case SFH_FI_RD_ERR: s->fi_rd_err = arg; break;
	case SFH_FI_STRICT_SB:
		if (!arg) op_wmb(s);
		s->strict_sb = arg != 0;
		break;
	}
}
void sfh_sim_get_stats(void *v, sfh_sim_stats *o) {
	Sim *s = (Sim *)v;
	*o = s->st;
	o->host_ns = s->host_t;
	o->dev_ns = s->dev_now;
}
int sfh_sim_trace_get(void *v, unsigned q, uint32_t seq, sfh_sim_trace *out) {
	Sim *s = (Sim *)v;
	auto it = s->trace.find(key(q, seq));
	if (it == s->trace.end()) { memset(out, 0, sizeof(*out)); return -1; }
	out->t_fetch = it->second.t_fetch; out->t_start = it->second.t_start;
	out->t_end = it->second.t_end; out->t_cqe = it->second.t_cqe;
	out->status = it->second.status; out->valid = 1;
	return 0;
}
uint64_t sfh_sim_db_time(void *v, unsigned q, uint16_t pos) {
	Sim *s = (Sim *)v;
	if (q >= 8) return 0;
	auto &vec = s->db[q];
	size_t &c = s->db_cur[q];
	while (c < vec.size()) {
		uint16_t ahead = uint16_t(vec[c].second - pos);
		if (ahead >= 1 && ahead <= 4096) return vec[c].first;
		c++;
	}
	return 0;
}
uint64_t sfh_sim_trace_hash(void *v) { return ((Sim *)v)->hash; }
void sfh_sim_set_skip(void *v, int en) { ((Sim *)v)->skip = en != 0; }
void sfh_sim_set_verbose(void *v, int en) { ((Sim *)v)->verbose = en; }

} // extern "C"
