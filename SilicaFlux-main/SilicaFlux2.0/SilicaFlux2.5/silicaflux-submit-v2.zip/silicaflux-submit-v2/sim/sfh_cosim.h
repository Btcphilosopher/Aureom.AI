/* SPDX-License-Identifier: MIT */
/*
 * SilicaFlux HSI v2 — simulation transport (co-simulation of the Verilated RTL).
 *
 * Virtual time, conservative lock-step: the device (RTL, 1 cycle = 1 ns) is advanced
 * to the host's virtual clock before every host operation that can observe or change
 * shared state. Link, interrupt and OS costs come from a documented platform profile
 * (sfh_sim_profile); every figure the benchmarks report is derived from the RTL's
 * cycle behaviour plus these parameters, not measured on silicon.
 *
 * The simulated IOMMU is also the DMA oracle: every device memory access must fall in
 * a range the driver mapped with the right permission at the moment the access reaches
 * the host; anything else is blocked (write dropped / read returns an error) and counted.
 */
#ifndef SFH_COSIM_H
#define SFH_COSIM_H
#include <stdint.h>
#include "sfh_transport.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct sfh_sim_profile {
	uint32_t mmio_wr_cpu_ns;    /* CPU cost of one posted MMIO write                       */
	uint32_t mmio_wr_lat_ns;    /* host -> device posted-write flight time                  */
	uint32_t mmio_rd_rtt_ns;    /* non-posted MMIO read round trip (CPU stalls)             */
	uint32_t dma_rd_lat_ns;     /* device read request -> first data beat                   */
	uint32_t dma_wr_lat_ns;     /* device posted write -> visible in host memory            */
	uint32_t msi_to_isr_ns;     /* interrupt message arrival -> ISR running                 */
	uint32_t isr_cpu_ns;        /* CPU time of the interrupt handler                        */
	uint32_t wakeup_lat_ns;     /* ISR -> sleeping thread running again                     */
	uint32_t ctxsw_cpu_ns;      /* CPU cost of one sleep + wake (two context switches)       */
	uint32_t timer_lat_ns;      /* wake at a deadline (hrtimer, or a producer's eventfd)    */
	uint32_t syscall_cpu_ns;    /* one ioctl entry/exit                                     */
	uint32_t kmd_desc_cpu_ns;   /* driver: validate + copy one descriptor                   */
	uint32_t umd_desc_cpu_ns;   /* library: encode one descriptor                           */
	uint32_t cqe_cpu_ns;        /* parse and dispatch one completion                        */
	uint32_t poll_iter_ns;      /* one poll of a CQ slot (cache-hot check + pause)          */
	uint32_t barrier_ns;        /* one wmb/rmb                                              */
} sfh_sim_profile;

void sfh_sim_profile_default(sfh_sim_profile *p);
/* key=value[,key=value...]; returns 0 or -1 on an unknown key */
int  sfh_sim_profile_parse(sfh_sim_profile *p, const char *kv);

enum sfh_sim_fault {
	SFH_FI_DROP_CQE = 1,     /* drop the next N CQE phase-dword writes (completion lost)       */
	SFH_FI_DUP_CQE,          /* next N CQEs are also copied into the following slot            */
	SFH_FI_DROP_MSI,         /* drop the next N interrupt messages                             */
	SFH_FI_DUP_MSI,          /* deliver the next N interrupt messages twice (2nd +20 us)       */
	SFH_FI_KERNEL_HANG,      /* 1 = kernel unit stalls until aborted                           */
	SFH_FI_FREEZE,           /* 1 = command engine hangs until an engine/function reset,
	                            2 = ... until a function reset only                              */
	SFH_FI_RD_ERR,           /* next N device read requests complete with an error             */
	SFH_FI_STRICT_SB,        /* 1 (default) = CPU stores to DMA memory stay invisible until wmb */
};
void sfh_sim_fault(void *sim, int fault, uint64_t arg);

typedef struct sfh_sim_stats {
	uint64_t host_ns, host_busy_ns, host_poll_ns;
	uint64_t dev_ns, cycles_stepped, ns_skipped;
	uint64_t mmio_wr, mmio_rd, msi_issued, msi_delivered, isr_runs, wakeups, timer_wakeups;
	uint64_t dma_rd_bytes, dma_wr_bytes;
	uint64_t iommu_violations;           /* the DMA oracle: must stay 0 in every test */
	uint64_t last_violation_iova;
} sfh_sim_stats;
void sfh_sim_get_stats(void *sim, sfh_sim_stats *s);

typedef struct sfh_sim_trace {
	uint64_t t_fetch, t_start, t_end, t_cqe;   /* device times, ns (t_cqe = CQE visible on host) */
	uint32_t status, valid;
} sfh_sim_trace;
int      sfh_sim_trace_get(void *sim, unsigned q, uint32_t seq, sfh_sim_trace *out);
/* device time at which the first SQ doorbell covering ring position `pos` reached the device
 * (queries must be in increasing position order per queue; returns 0 if none) */
uint64_t sfh_sim_db_time(void *sim, unsigned q, uint16_t pos);
uint64_t sfh_sim_trace_hash(void *sim);       /* hash of every trace event and interrupt (time-stamped) */
void     sfh_sim_set_skip(void *sim, int enable);
void     sfh_sim_set_verbose(void *sim, int v);

/* create/destroy; the returned transport is valid until destroy */
void *sfh_sim_create(const sfh_sim_profile *p);
void  sfh_sim_destroy(void *sim);
const sfh_transport *sfh_sim_transport(void *sim);
int   sfh_sim_mutant(void);                    /* RTL MUTANT value this binary was built with */

#ifdef __cplusplus
}
#endif
#endif
