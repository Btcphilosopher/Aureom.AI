// SPDX-License-Identifier: MIT
/*
 * SilicaFlux HSI v2 — benchmark driver (one configuration per run, JSON on stdout).
 *
 * Workloads
 *   small   OP_KERNEL ADD32 over 64 B      (tens of device cycles: submission overhead dominates)
 *   large   OP_COPY_H2D of 128 KiB          (~17 us of DMA: execution dominates)
 * Patterns
 *   qd1     one command in flight: submit, wait, repeat (latency)
 *   burst   all N commands ready at t=0; submit in batches of B as the ring allows (throughput,
 *           complete-workload time, CPU)
 *   closed  closed loop at queue depth --depth (like fio iodepth): every completion releases a
 *           new command; released commands are submitted together (up to B per call)
 *   open    commands arrive every --rate-ns from an external producer; the submitter wakes at
 *           flush points only: when B commands are pending, or when the oldest pending command
 *           has waited --flush-ns (latency/CPU trade-off of batching)
 * Per command (host clock and device trace share one ns timebase):
 *   t_ready  command exists in the application          t_flush  submit call (syscall/doorbell)
 *   t_fetch  descriptor arrived in the device           t_start/t_end  execution
 *   t_reap   completion handed back to the application
 * Reported: submission latency = t_fetch - t_flush; queue wait = (t_flush - t_ready) +
 * (t_start - t_fetch); execution = t_end - t_start; notification = t_reap - t_end;
 * end-to-end = t_reap - t_ready. CPU = modelled host CPU-busy time (sfh_cosim.h).
 */
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "sfh.h"
#include "sfh_cosim.h"

typedef struct { uint64_t t_ready, t_flush, t_reap; uint32_t qid, seq, status; int done; } rec_t;

static struct {
	const char *workload, *pattern, *notify, *profile, *label;
	unsigned n, batch, imod_cnt, imod_time, poll_budget, coalesce, irq_last, direct, ring, depth;
	uint64_t rate_ns, flush_ns;
} A = { "small", "burst", "irq", "", "", 2000, 1, 0, 0, 5000, 0, 0, 0, 256, 32, 4000, 20000 };

static int cmp_u64(const void *a, const void *b)
{
	uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
	return x < y ? -1 : x > y;
}
static void stat_print(const char *name, uint64_t *v, unsigned n, int last)
{
	double sum = 0;
	for (unsigned i = 0; i < n; i++) sum += (double)v[i];
	qsort(v, n, sizeof(uint64_t), cmp_u64);
	#define PCT(p) (n ? v[(size_t)((double)(n - 1) * (p))] : 0)
	printf("\"%s\":{\"mean\":%.1f,\"p50\":%" PRIu64 ",\"p90\":%" PRIu64 ",\"p99\":%" PRIu64 ",\"max\":%" PRIu64 "}%s",
	       name, n ? sum / n : 0.0, PCT(0.50), PCT(0.90), PCT(0.99), n ? v[n - 1] : 0, last ? "" : ",");
}

static sfh_cmd make_cmd(unsigned i, sfh_buf **bufs)
{
	sfh_cmd c;
	memset(&c, 0, sizeof(c));
	c.user_tag = i;
	if (!strcmp(A.workload, "large")) {
		c.op = SFH_OP_COPY_H2D; c.buf = bufs[i % 4]; c.buf_off = 0;
		c.dev_off = (uint64_t)(i % 4) * 131072; c.len = 131072;
	} else {
		c.op = SFH_OP_KERNEL; c.kop = SFH_KOP_ADD32;
		c.dev_off = (uint64_t)(i % 64) * 64; c.dev_off2 = 8192 + (uint64_t)(i % 64) * 64;
		c.len = 64; c.value = i;
	}
	return c;
}

int main(int argc, char **argv)
{
	if (argc == 2 && !strcmp(argv[1], "--print-profile")) {
		sfh_sim_profile p;
		sfh_sim_profile_default(&p);
		printf("{\"mmio_wr_cpu_ns\":%u,\"mmio_wr_lat_ns\":%u,\"mmio_rd_rtt_ns\":%u,\"dma_rd_lat_ns\":%u,"
		       "\"dma_wr_lat_ns\":%u,\"msi_to_isr_ns\":%u,\"isr_cpu_ns\":%u,\"wakeup_lat_ns\":%u,"
		       "\"ctxsw_cpu_ns\":%u,\"timer_lat_ns\":%u,\"syscall_cpu_ns\":%u,\"kmd_desc_cpu_ns\":%u,"
		       "\"umd_desc_cpu_ns\":%u,\"cqe_cpu_ns\":%u,\"poll_iter_ns\":%u,\"barrier_ns\":%u}\n",
		       p.mmio_wr_cpu_ns, p.mmio_wr_lat_ns, p.mmio_rd_rtt_ns, p.dma_rd_lat_ns, p.dma_wr_lat_ns,
		       p.msi_to_isr_ns, p.isr_cpu_ns, p.wakeup_lat_ns, p.ctxsw_cpu_ns, p.timer_lat_ns,
		       p.syscall_cpu_ns, p.kmd_desc_cpu_ns, p.umd_desc_cpu_ns, p.cqe_cpu_ns, p.poll_iter_ns, p.barrier_ns);
		return 0;
	}
	for (int i = 1; i < argc; i++) {
		const char *k = argv[i], *v = i + 1 < argc ? argv[i + 1] : "";
#define S(name, field) if (!strcmp(k, name)) { A.field = v; i++; continue; }
#define U(name, field) if (!strcmp(k, name)) { A.field = (unsigned)strtoul(v, NULL, 0); i++; continue; }
#define L(name, field) if (!strcmp(k, name)) { A.field = strtoull(v, NULL, 0); i++; continue; }
		S("--workload", workload) S("--pattern", pattern) S("--notify", notify) S("--profile", profile)
		S("--label", label)
		U("--n", n) U("--batch", batch) U("--imod-count", imod_cnt) U("--imod-time", imod_time)
		U("--poll-budget", poll_budget) U("--coalesce", coalesce) U("--irq-last", irq_last)
		U("--direct", direct) U("--ring", ring) U("--depth", depth)
		L("--rate-ns", rate_ns) L("--flush-ns", flush_ns)
		fprintf(stderr, "unknown argument %s\n", k);
		return 2;
	}
	if (!A.batch) A.batch = 1;
	if (A.batch > A.ring) A.batch = A.ring;
	sfh_sim_profile prof;
	sfh_sim_profile_default(&prof);
	if (sfh_sim_profile_parse(&prof, A.profile)) { fprintf(stderr, "bad profile\n"); return 2; }
	struct timespec w0, w1;
	clock_gettime(CLOCK_MONOTONIC, &w0);
	void *sim = sfh_sim_create(&prof);
	sfh_dev *d;
	sfh_dev_params dp = { .cmd_timeout_ns = 50000000, .fence_timeout_ns = 50000000, .reset_timeout_ns = 100000 };
	if (sfh_dev_open(sfh_sim_transport(sim), &dp, &d)) { fprintf(stderr, "dev_open failed\n"); return 1; }
	sfh_ctx *c;
	sfh_ctx_open(d, &c);
	sfh_queue_params qp;
	sfh_queue_params_default(&qp);
	qp.sq_entries = qp.cq_entries = A.ring;
	qp.notify = !strcmp(A.notify, "poll") ? SFH_NOTIFY_POLL : !strcmp(A.notify, "hybrid") ? SFH_NOTIFY_HYBRID : SFH_NOTIFY_IRQ;
	qp.imod_count = A.imod_cnt;
	qp.imod_time_ns = A.imod_time;
	qp.poll_budget_ns = A.poll_budget;
	qp.flags = A.direct ? SFH_QF_DIRECT : 0;
	qp.host_timeout_ns = 200000000ull;
	sfh_queue *q;
	if (sfh_queue_create(c, &qp, &q)) { fprintf(stderr, "queue_create failed\n"); return 1; }
	sfh_buf *bufs[4] = {0};
	if (!strcmp(A.workload, "large"))
		for (int i = 0; i < 4; i++) sfh_buf_alloc(c, 131072, SFH_BUF_DEV_READ, &bufs[i]);
	unsigned sflags = (A.coalesce ? SFH_SUBMIT_COALESCE : 0) | (A.irq_last ? SFH_SUBMIT_IRQ_LAST : 0);

	uint32_t seq0 = sfh_test_next_seq(q);   /* ring position 0 of this queue's epoch */
	/* warm-up (not measured) */
	for (unsigned i = 0; i < 16; i++) {
		sfh_cmd w = make_cmd(i, bufs);
		uint64_t t;
		sfh_completion r;
		sfh_submit(q, &w, 1, 0, &t);
		sfh_wait_ticket(q, t, 100000000ull, &r);
	}
	sfh_sim_stats s0, s1;
	sfh_queue_stats q0, q1;
	sfh_sim_get_stats(sim, &s0);
	sfh_queue_get_stats(q, &q0);

	rec_t *rec = calloc(A.n, sizeof(rec_t));
	uint64_t *tready = calloc(A.n, sizeof(uint64_t));
	sfh_cmd *cmds = calloc(A.batch, sizeof(sfh_cmd));
	int open = !strcmp(A.pattern, "open"), qd1 = !strcmp(A.pattern, "qd1"), closed = !strcmp(A.pattern, "closed");
	if (closed && A.depth > A.ring) A.depth = A.ring;
	uint64_t t_begin = sfh_now(q), first_ticket = 0;
	unsigned submitted = 0, completed = 0, arrived = 0, errors = 0;
	int have_first = 0;
	sfh_completion comp[256];

#define TAKE(nr) do {                                                                       \
	for (int _i = 0; _i < (nr); _i++) {                                                   \
		uint64_t _k = comp[_i].ticket - first_ticket;                                \
		if (_k >= A.n) continue;                                                     \
		rec[_k].t_reap = comp[_i].t_reap; rec[_k].qid = comp[_i].qid;                \
		rec[_k].seq = comp[_i].dev_seq; rec[_k].status = comp[_i].status;            \
		rec[_k].done = 1; completed++;                                               \
		if (comp[_i].status) errors++;                                                \
	}                                                                                     \
} while (0)

	unsigned bmax = qd1 ? 1 : A.batch;
	while (completed < A.n) {
		uint64_t now = sfh_now(q);
		/* arrivals */
		while (arrived < A.n && (!open || t_begin + (uint64_t)arrived * A.rate_ns <= now) &&
		       (!qd1 || arrived == completed) && (!closed || arrived - completed < A.depth)) {
			tready[arrived] = open ? t_begin + (uint64_t)arrived * A.rate_ns : now;
			arrived++;
			if (qd1) break;
		}
		unsigned pending = arrived - submitted;
		unsigned room = A.ring - sfh_queue_inflight(q);
		int flush = pending >= bmax ||
		            (pending && (arrived == A.n || now - tready[submitted] >= A.flush_ns));
		if (qd1) flush = pending && sfh_queue_inflight(q) == 0;
		if (closed) flush = pending > 0;
		if (flush && room) {
			unsigned nb = pending < bmax ? pending : bmax;
			if (nb > room) nb = room;
			for (unsigned i = 0; i < nb; i++) cmds[i] = make_cmd(submitted + i, bufs);
			uint64_t t;
			uint64_t tf = sfh_now(q);
			int rc = sfh_submit(q, cmds, nb, sflags, &t);
			if (rc == 0) {
				if (!have_first) { first_ticket = t; have_first = 1; }
				for (unsigned i = 0; i < nb; i++) {
					rec[submitted + i].t_ready = tready[submitted + i];
					rec[submitted + i].t_flush = tf;
				}
				submitted += nb;
				continue;
			} else if (rc != -EAGAIN) {
				fprintf(stderr, "submit rc=%d\n", rc);
				return 1;
			}
		}
		/* completions */
		int nr = sfh_reap(q, comp, 256);
		if (nr > 0) { TAKE(nr); continue; }
		/* nothing to do right now: wait for a completion or the next arrival/flush deadline */
		/* next flush point: the B-th pending command arrives, or the oldest one times out */
		uint64_t next = UINT64_MAX;
		if (open && submitted < A.n) {
			unsigned last = submitted + bmax - 1 < A.n ? submitted + bmax - 1 : A.n - 1;
			next = t_begin + (uint64_t)last * A.rate_ns;
			uint64_t fl = t_begin + (uint64_t)submitted * A.rate_ns + A.flush_ns;
			if (fl < next) next = fl;
		}
		now = sfh_now(q);
		if (sfh_queue_inflight(q)) {
			uint64_t to = next == UINT64_MAX ? 100000000ull : (next > now ? next - now : 0);
			if (to == 0) continue;
			nr = sfh_wait_any(q, to, comp, 256);
			if (nr > 0) TAKE(nr);
		} else if (next != UINT64_MAX) {
			sfh_idle_until(q, next);
		}
	}
	uint64_t t_end = 0;
	for (unsigned i = 0; i < A.n; i++) if (rec[i].t_reap > t_end) t_end = rec[i].t_reap;
	sfh_sim_get_stats(sim, &s1);
	sfh_queue_get_stats(q, &q1);
	clock_gettime(CLOCK_MONOTONIC, &w1);

	/* decomposition (sums to end-to-end):
	 *   host batching wait  t_flush - t_ready
	 *   submission          t_db    - t_flush   (submit call -> doorbell reaches the device)
	 *   device queue wait   t_start - t_db      (waiting in the SQ, arbitration, descriptor fetch)
	 *   execution           t_end   - t_start
	 *   notification        t_reap  - t_end     (CQE write, moderation, interrupt/poll, wakeup) */
	uint64_t *sub = calloc(A.n, 8), *qw = calloc(A.n, 8), *ex = calloc(A.n, 8), *no = calloc(A.n, 8),
	         *e2e = calloc(A.n, 8), *hostq = calloc(A.n, 8), *devq = calloc(A.n, 8), *fet = calloc(A.n, 8);
	unsigned m = 0;
	for (unsigned i = 0; i < A.n; i++) {
		sfh_sim_trace tr;
		if (sfh_sim_trace_get(sim, rec[i].qid, rec[i].seq, &tr) || !tr.t_end) continue;
		uint64_t tdb = sfh_sim_db_time(sim, rec[i].qid, (uint16_t)(rec[i].seq - seq0));
		if (!tdb || tdb < rec[i].t_flush) tdb = rec[i].t_flush;
		sub[m] = tdb - rec[i].t_flush;
		hostq[m] = rec[i].t_flush - rec[i].t_ready;
		devq[m] = tr.t_start - tdb;
		fet[m] = tr.t_fetch - tdb;
		qw[m] = hostq[m] + devq[m];
		ex[m] = tr.t_end - tr.t_start;
		no[m] = rec[i].t_reap - tr.t_end;
		e2e[m] = rec[i].t_reap - rec[i].t_ready;
		m++;
	}
	double wall = (double)(t_end - t_begin);
	double busy = (double)(s1.host_busy_ns - s0.host_busy_ns);
	double bytes = !strcmp(A.workload, "large") ? 131072.0 * A.n : 64.0 * A.n;
	printf("{\"label\":\"%s\",\"workload\":\"%s\",\"pattern\":\"%s\",\"notify\":\"%s\",\"batch\":%u,\"depth\":%u,"
	       "\"imod_count\":%u,\"imod_time\":%u,\"coalesce\":%u,\"irq_last\":%u,\"direct\":%u,\"ring\":%u,"
	       "\"rate_ns\":%" PRIu64 ",\"flush_ns\":%" PRIu64 ",\"n\":%u,\"errors\":%u,\"profile\":\"%s\",",
	       A.label, A.workload, A.pattern, A.notify, bmax, closed ? A.depth : (qd1 ? 1 : 0), A.imod_cnt, A.imod_time, A.coalesce, A.irq_last,
	       A.direct, A.ring, open ? A.rate_ns : 0, A.flush_ns, A.n, errors, A.profile);
	printf("\"workload_time_ns\":%.0f,\"throughput_cmd_s\":%.1f,\"throughput_gbps\":%.4f,"
	       "\"cpu_busy_ns\":%.0f,\"cpu_ns_per_cmd\":%.1f,\"cpu_util\":%.4f,\"cpu_poll_ns\":%" PRIu64 ",",
	       wall, A.n / (wall * 1e-9), bytes / wall, busy, busy / A.n, busy / wall, s1.host_poll_ns - s0.host_poll_ns);
	printf("\"irqs_per_cmd\":%.4f,\"doorbells_per_cmd\":%.4f,\"cqes_per_cmd\":%.4f,\"mmio_wr_per_cmd\":%.4f,"
	       "\"mmio_rd\":%" PRIu64 ",\"spurious_irqs\":%" PRIu64 ",\"timer_wakeups\":%" PRIu64 ",\"recoveries\":%" PRIu64 ","
	       "\"iommu_violations\":%" PRIu64 ",\"sim_wall_s\":%.3f,\"cycles_stepped\":%" PRIu64 ",\"samples\":%u,",
	       (double)(s1.msi_delivered - s0.msi_delivered) / A.n, (double)(q1.doorbells - q0.doorbells) / A.n,
	       (double)(q1.cqes - q0.cqes) / A.n, (double)(s1.mmio_wr - s0.mmio_wr) / A.n, s1.mmio_rd - s0.mmio_rd,
	       q1.spurious_irqs - q0.spurious_irqs, q1.timer_wakeups - q0.timer_wakeups, q1.recoveries - q0.recoveries,
	       s1.iommu_violations, (double)(w1.tv_sec - w0.tv_sec) + (double)(w1.tv_nsec - w0.tv_nsec) * 1e-9,
	       s1.cycles_stepped, m);
	stat_print("submission_ns", sub, m, 0);
	stat_print("queue_wait_ns", qw, m, 0);
	stat_print("host_batch_wait_ns", hostq, m, 0);
	stat_print("device_queue_ns", devq, m, 0);
	stat_print("db_to_fetch_ns", fet, m, 0);
	stat_print("exec_ns", ex, m, 0);
	stat_print("notify_ns", no, m, 0);
	stat_print("e2e_ns", e2e, m, 1);
	printf("}\n");
	sfh_dev_close(d);
	sfh_sim_destroy(sim);
	return errors ? 1 : 0;
}
