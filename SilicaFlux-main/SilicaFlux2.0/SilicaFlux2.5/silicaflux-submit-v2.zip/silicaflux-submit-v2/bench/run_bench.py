#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
SilicaFlux HSI v2 — benchmark harness.

Runs the co-simulation benchmark driver (bench/sfh_bench.c) over a set of experiments and
writes results/bench_results.json, results/BENCHMARKS.md and results/figures/*.png.

  python3 bench/run_bench.py --bin build/sfh_bench_m0_h0 [--quick] [--jobs N]

Experiments
  E1  burst matrix        small/large x {single, batch16, batch16+coalesced CQE} x {irq, irq+mod, poll, hybrid}
  E2  QD1 latency         small/large x {irq, irq+mod, poll, hybrid} (+ direct submission)
  E3  moderation sweep    open loop 50 k/s (count and timer sweeps) + closed loop QD32 -> latency vs CPU
  E4  batching sweep      open loop, small, batch 1..64, irq and poll -> latency vs CPU trade-off
  E5  load sweep          open loop, small, offered rate sweep, 4 configurations
  E6  sensitivity         key E1/E2 points under two alternative platform profiles

Every number is produced by the RTL (cycle behaviour of fetch, arbitration, moderation,
CQE writes) plus the platform profile in sim/sfh_cosim.cpp. Nothing is measured on silicon.
"""
import argparse
import concurrent.futures as cf
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
FIG = os.path.join(RES, "figures")

NOTIFY = {
    "irq":     ["--notify", "irq"],
    "irq+mod": ["--notify", "irq", "--imod-count", "16", "--imod-time", "20000"],
    "poll":    ["--notify", "poll"],
    "hybrid":  ["--notify", "hybrid", "--poll-budget", "5000"],
}
SUBMIT = {
    "single":           ["--batch", "1"],
    "batch16":          ["--batch", "16"],
    "batch16+coalesce": ["--batch", "16", "--coalesce", "1", "--irq-last", "1"],
}
PROFILES = {
    "default": "",
    "slow-irq": "msi_to_isr_ns=2000,wakeup_lat_ns=8000,isr_cpu_ns=2500,ctxsw_cpu_ns=3000",
    "fast-link": "mmio_wr_lat_ns=250,mmio_rd_rtt_ns=600,dma_rd_lat_ns=500,dma_wr_lat_ns=250",
}

# reference palette (dataviz skill, references/palette.md), fixed slot order
SLOT = ["#257de0", "#f47230", "#00b894", "#f2a600", "#ee7fac", "#008a17", "#6a4ce2", "#ec4647"]
TEXT, TEXT2, GRID = "#191919", "#666666", "#e6e6e6"


def experiments(quick):
    k = 4 if quick else 1
    n_small, n_large = 4000 // k, 200 // k
    ex = []
    for w, n in (("small", n_small), ("large", n_large)):
        for s, sa in SUBMIT.items():
            for m, ma in NOTIFY.items():
                ex.append(dict(exp="E1", workload=w, submit=s, mode=m,
                               args=["--workload", w, "--pattern", "burst", "--n", str(n)] + sa + ma))
    for w, n in (("small", 400 // k), ("large", 60 // k)):
        for m, ma in NOTIFY.items():
            ex.append(dict(exp="E2", workload=w, submit="kernel", mode=m,
                           args=["--workload", w, "--pattern", "qd1", "--n", str(n)] + ma))
    for m in ("irq", "poll"):
        ex.append(dict(exp="E2", workload="small", submit="direct", mode=m,
                       args=["--workload", "small", "--pattern", "qd1", "--n", str(400 // k), "--direct", "1"] + NOTIFY[m]))
    lo = ["--workload", "small", "--pattern", "open", "--rate-ns", "20000", "--n", str(1500 // k), "--notify", "irq"]
    for c in (1, 2, 4, 8):
        ex.append(dict(exp="E3", sweep="count", value=c, args=lo + ["--imod-count", str(c), "--imod-time", "50000"]))
    for t in (2000, 5000, 10000, 15000, 20000, 30000):
        ex.append(dict(exp="E3", sweep="timer", value=t, args=lo + ["--imod-count", "4096", "--imod-time", str(t)]))
    cl = ["--workload", "small", "--pattern", "closed", "--depth", "32", "--batch", "32", "--n", str(4000 // k),
          "--notify", "irq"]
    for c in (1, 4, 16, 32):
        ex.append(dict(exp="E3b", sweep="count", value=c, args=cl + ["--imod-count", str(c), "--imod-time", "50000"]))
    for t in (5000, 20000):
        ex.append(dict(exp="E3b", sweep="timer", value=t, args=cl + ["--imod-count", "4096", "--imod-time", str(t)]))
    base = ["--workload", "small", "--pattern", "open", "--rate-ns", "2000", "--n", str(4000 // k)]
    for m in ("irq", "poll"):
        for b in (1, 2, 4, 8, 16, 32):
            ex.append(dict(exp="E4", mode=m, value=b,
                           args=base + ["--notify", m, "--batch", str(b), "--flush-ns", "100000"]))
    cfgs = {
        "single / irq":  ["--notify", "irq", "--batch", "1"],
        "single / poll": ["--notify", "poll", "--batch", "1"],
        "batch8 / irq":  ["--notify", "irq", "--batch", "8", "--flush-ns", "10000"],
        "batch8 / poll": ["--notify", "poll", "--batch", "8", "--flush-ns", "10000"],
    }
    for name, ca in cfgs.items():
        for r in (8000, 4000, 2000, 1000, 700, 500, 350, 250):
            ex.append(dict(exp="E5", config=name, value=r,
                           args=["--workload", "small", "--pattern", "open", "--rate-ns", str(r),
                                 "--n", str(3000 // k)] + ca))
    for pname, prof in PROFILES.items():
        if pname == "default":
            continue
        for m in ("irq", "poll"):
            ex.append(dict(exp="E6", profile=pname, kind="qd1", mode=m,
                           args=["--workload", "small", "--pattern", "qd1", "--n", str(400 // k),
                                 "--profile", prof] + NOTIFY[m]))
            for s in ("single", "batch16"):
                ex.append(dict(exp="E6", profile=pname, kind="burst " + s, mode=m,
                               args=["--workload", "small", "--pattern", "burst", "--n", str(n_small),
                                     "--profile", prof] + SUBMIT[s] + NOTIFY[m]))
    return ex


def run_one(binary, e):
    t0 = time.time()
    p = subprocess.run([binary] + e["args"], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"{e['args']} failed rc={p.returncode}: {p.stderr[-400:]}")
    r = json.loads(p.stdout.strip().splitlines()[-1])
    r.update({k: v for k, v in e.items() if k != "args"})
    r["cmdline"] = " ".join(e["args"])
    r["harness_s"] = time.time() - t0
    return r


# ------------------------------------------------------------------------------------ formatting
def us(ns):
    return ns / 1000.0


def fmt_us(ns):
    v = ns / 1000.0
    return f"{v:,.2f}" if v < 10 else f"{v:,.1f}" if v < 1000 else f"{v:,.0f}"


def fmt_thr(r):
    return f"{r['throughput_cmd_s'] / 1e6:.3f}" if r["workload"] == "small" else f"{r['throughput_gbps']:.2f}"


def find(rs, **kv):
    out = [r for r in rs if all(r.get(k) == v for k, v in kv.items())]
    return out[0] if out else None


# ------------------------------------------------------------------------------------ figures
def figures(rs):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.size": 9, "axes.edgecolor": "#bdbdbd", "axes.labelcolor": TEXT, "xtick.color": TEXT2,
        "ytick.color": TEXT2, "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlecolor": TEXT,
        "legend.frameon": False, "figure.dpi": 100, "savefig.dpi": 200, "axes.spines.top": False,
        "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
        "axes.axisbelow": True,
    })
    os.makedirs(FIG, exist_ok=True)
    made = []

    # F1: QD1 latency decomposition (horizontal stacked bars, one panel per workload)
    comps = [("submission_ns", "submission (call → doorbell at device)"),
             ("device_queue_ns", "device queue + descriptor fetch"),
             ("exec_ns", "execution"),
             ("notify_ns", "completion notification")]
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.6), gridspec_kw={"width_ratios": [1.15, 1]})
    for ax, w in zip(axes, ("small", "large")):
        rows = [r for r in rs if r["exp"] == "E2" and r["workload"] == w]
        rows.sort(key=lambda r: (r["submit"] != "kernel", list(NOTIFY).index(r["mode"])))
        labels = [f"{r['mode']}" + (" · direct" if r["submit"] == "direct" else "") for r in rows]
        left = [0.0] * len(rows)
        for ci, (key, name) in enumerate(comps):
            vals = [us(r[key]["mean"]) for r in rows]
            ax.barh(range(len(rows)), vals, left=left, color=SLOT[ci], edgecolor="white", linewidth=1.5,
                    height=0.62, label=name)
            left = [a + b for a, b in zip(left, vals)]
        for i, tot in enumerate(left):
            ax.text(tot, i, f"  {tot:,.1f} µs", va="center", fontsize=8, color=TEXT)
        ax.set_yticks(range(len(rows)), labels)
        ax.invert_yaxis()
        ax.set_xlim(0, max(left) * 1.25)
        ax.set_xlabel("mean end-to-end latency at queue depth 1 (µs)")
        ax.set_title(f"{w} command" + (" (64 B kernel)" if w == "small" else " (128 KiB H2D copy)"), loc="left")
        ax.grid(axis="y", visible=False)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=4, fontsize=8, bbox_to_anchor=(0.5, 0.0))
    fig.suptitle("Where the time goes for one command (QD1)", x=0.01, ha="left", fontsize=11, fontweight="bold")
    fig.tight_layout(rect=(0, 0.08, 1, 0.95))
    fig.savefig(os.path.join(FIG, "f1_qd1_latency_breakdown.png"), bbox_inches="tight")
    plt.close(fig)
    made.append("f1_qd1_latency_breakdown.png")

    # F2: burst throughput + CPU per command, grouped bars (2x2 small multiples, one y axis each)
    fig, axes = plt.subplots(2, 2, figsize=(11, 6.4))
    subs = list(SUBMIT)
    modes = list(NOTIFY)
    wbar = 0.19
    for col, w in enumerate(("small", "large")):
        for row, (metric, ylabel) in enumerate(
                (("thr", "throughput (Mcmd/s)" if w == "small" else "throughput (GB/s)"),
                 ("cpu_ns_per_cmd", "host CPU per command (µs)"))):
            ax = axes[row][col]
            for mi, m in enumerate(modes):
                vals = []
                for s in subs:
                    r = find(rs, exp="E1", workload=w, submit=s, mode=m)
                    if metric == "thr":
                        vals.append(r["throughput_cmd_s"] / 1e6 if w == "small" else r["throughput_gbps"])
                    else:
                        vals.append(us(r["cpu_ns_per_cmd"]))
                xs = [i + (mi - 1.5) * (wbar + 0.02) for i in range(len(subs))]
                ax.bar(xs, vals, width=wbar, color=SLOT[mi], edgecolor="white", linewidth=1,
                       label=m if (row == 0 and col == 0) else None)
            ax.set_xticks(range(len(subs)), subs)
            ax.set_ylabel(ylabel)
            ax.grid(axis="x", visible=False)
            if row == 0:
                ax.set_title(f"{w} commands, all ready at t=0 (burst)", loc="left")
    fig.legend(loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.01), title="completion notification")
    fig.suptitle("Single vs batched submission × interrupts vs polling", x=0.01, ha="left", fontsize=11,
                 fontweight="bold")
    fig.tight_layout(rect=(0, 0.06, 1, 0.96))
    fig.savefig(os.path.join(FIG, "f2_burst_throughput_cpu.png"), bbox_inches="tight")
    plt.close(fig)
    made.append("f2_burst_throughput_cpu.png")

    # F3: moderation — swept timer on x; latency and CPU in separate panels (no dual axis)
    cnt = sorted([r for r in rs if r["exp"] == "E3" and r["sweep"] == "count"], key=lambda r: r["value"])
    tmr = sorted([r for r in rs if r["exp"] == "E3" and r["sweep"] == "timer"], key=lambda r: r["value"])
    if cnt and tmr:
        base = cnt[0]
        pts = [(0, base)] + [(r["value"] / 1000, r) for r in tmr]
        fig, axes = plt.subplots(1, 2, figsize=(11, 3.9))
        for ax, (key, yl) in zip(axes, ((lambda r: us(r["e2e_ns"]["mean"]), "mean end-to-end latency (µs)"),
                                         (lambda r: us(r["cpu_ns_per_cmd"]), "host CPU per command (µs)"))):
            xs = [x for x, _ in pts]
            ys = [key(r) for _, r in pts]
            ax.plot(xs, ys, color=SLOT[0], linewidth=2, marker="o", markersize=6, markeredgecolor="white",
                    markeredgewidth=1.5)
            ax.set_ylim(0, max(ys) * 1.3)
            ax.axvline(20, color=TEXT2, linewidth=1, linestyle=(0, (3, 3)))
            ax.annotate("gap between arrivals (20 µs)", (20, max(ys) * 1.27), xytext=(4, 0),
                        textcoords="offset points", fontsize=7.5, color=TEXT2, va="top")
            ax.annotate("off", (0, ys[0]), xytext=(0, -13), textcoords="offset points", fontsize=8, color=TEXT2,
                        ha="center")
            ax.set_xlabel("moderation timer (µs); 0 = no moderation")
            ax.set_ylabel(yl)
        axes[0].set_title("latency added", loc="left")
        axes[1].set_title("CPU saved", loc="left")
        fig.suptitle("Interrupt moderation timer at 50 k commands/s", x=0.01, ha="left", fontsize=11, fontweight="bold")
        fig.text(0.01, -0.03, "Open loop, one 64 B kernel every 20 µs, one command per submission, interrupt notification. "
                 "Below the arrival gap the timer only delays the interrupt; at or above it the next arrival's wake-up "
                 "collects the completion and the interrupt is never needed. A count threshold ≥ 2 behaves like a long timer "
                 "(table E3).", fontsize=8, color=TEXT2, wrap=True)
        fig.tight_layout(rect=(0, 0.02, 1, 0.94))
        fig.savefig(os.path.join(FIG, "f3_moderation_tradeoff.png"), bbox_inches="tight")
        plt.close(fig)
        made.append("f3_moderation_tradeoff.png")

    # F4: batching — batch size on x (log2); latency and CPU in separate panels
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.9))
    for si, m in enumerate(("irq", "poll")):
        pts = sorted([r for r in rs if r["exp"] == "E4" and r["mode"] == m], key=lambda r: r["value"])
        if not pts:
            continue
        xs = [r["value"] for r in pts]
        for ax, key in zip(axes, (lambda r: us(r["e2e_ns"]["mean"]), lambda r: us(r["cpu_ns_per_cmd"]))):
            ys = [key(r) for r in pts]
            ax.plot(xs, ys, color=SLOT[si], linewidth=2, marker="o", markersize=6, markeredgecolor="white",
                    markeredgewidth=1.5, label=m)
            ax.annotate(m, (xs[-1], ys[-1]), xytext=(6, 0), textcoords="offset points", fontsize=8,
                        color=TEXT, va="center")
    for ax, yl, t in zip(axes, ("mean end-to-end latency (µs)", "host CPU per command (µs)"),
                         ("latency added", "CPU saved")):
        ax.set_xscale("log", base=2)
        ax.set_xticks([1, 2, 4, 8, 16, 32], ["1", "2", "4", "8", "16", "32"])
        ax.set_xlabel("commands per submission (B)")
        ax.set_ylabel(yl)
        ax.set_title(t, loc="left")
        ax.set_ylim(bottom=0)
    axes[0].legend(loc="upper left", title="notification")
    fig.suptitle("Submission batching at 500 k commands/s", x=0.01, ha="left", fontsize=11, fontweight="bold")
    fig.text(0.01, -0.03, "Open loop, one 64 B kernel every 2 µs from a producer; the submitter wakes when B commands "
             "are pending (or the oldest has waited 100 µs). Polling burns the whole core regardless of B, so for it "
             "batching only trades latency for fewer doorbells.", fontsize=8, color=TEXT2)
    fig.tight_layout(rect=(0, 0.02, 1, 0.94))
    fig.savefig(os.path.join(FIG, "f4_batching_tradeoff.png"), bbox_inches="tight")
    plt.close(fig)
    made.append("f4_batching_tradeoff.png")

    # F5: load sweep — p99 latency vs achieved throughput, and CPU utilisation (two panels)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    names = ["single / irq", "single / poll", "batch8 / irq", "batch8 / poll"]
    for si, name in enumerate(names):
        pts = sorted([r for r in rs if r["exp"] == "E5" and r["config"] == name], key=lambda r: -r["value"])
        xs = [r["throughput_cmd_s"] / 1e6 for r in pts]
        axes[0].plot(xs, [us(r["e2e_ns"]["p99"]) for r in pts], color=SLOT[si], linewidth=2, marker="o",
                     markersize=5, markeredgecolor="white", markeredgewidth=1, label=name)
        axes[1].plot(xs, [100 * r["cpu_util"] for r in pts], color=SLOT[si], linewidth=2, marker="o",
                     markersize=5, markeredgecolor="white", markeredgewidth=1, label=name)
    axes[0].set_yscale("log")
    axes[0].set_ylabel("p99 end-to-end latency (µs, log)")
    axes[1].set_ylabel("host CPU busy (% of one core)")
    for ax in axes:
        ax.set_xlabel("achieved throughput (M commands/s)")
    axes[0].legend(loc="upper left")
    fig.suptitle("Offered-load sweep (64 B kernels, open loop)", x=0.01, ha="left", fontsize=11, fontweight="bold")
    fig.text(0.01, -0.03, "Offered load from 125 k to 4 M commands/s. Where a line stops moving right the configuration "
             "is saturated and its latency climbs. Both polling configurations sit at 100% CPU (the lines coincide).",
             fontsize=8, color=TEXT2)
    fig.tight_layout(rect=(0, 0.02, 1, 0.95))
    fig.savefig(os.path.join(FIG, "f5_load_sweep.png"), bbox_inches="tight")
    plt.close(fig)
    made.append("f5_load_sweep.png")
    return made


# ------------------------------------------------------------------------------------ report
def report(rs, made, profile_text, elapsed):
    L = []
    a = L.append
    a("<!-- generated by bench/run_bench.py — do not edit by hand; re-run to refresh -->")
    a("# Submission-path benchmarks (co-simulation)")
    a("")
    a("**What these numbers are.** Every figure comes from the Verilated RTL of the device front-end "
      "(descriptor fetch, arbitration, validation, data mover, CQE writes, interrupt moderation, all "
      "cycle-accurate at 1 GHz) driven by the real host runtime, with link, interrupt and OS costs taken "
      "from a *platform profile* (below). CPU consumption is the modelled busy time of the submitting "
      "thread (syscalls, descriptor encode/validate, MMIO writes, CQE parsing, ISRs, context switches and "
      "every nanosecond spent spinning). The model has no OS noise, cache misses or link errors, so tail "
      "latency here comes from queueing, batching and moderation only. **Absolute values depend on the "
      "profile; use the trends, then re-run with a profile measured on your platform** "
      "(`--profile key=value,...`). Nothing here was measured on silicon.")
    a("")
    a("Decomposition used throughout (sums to end-to-end): *host batching wait* (command ready → submit "
      "call) + *submission* (submit call → doorbell reaches the device) + *device queue* (doorbell → "
      "execution starts: waiting in the SQ, arbitration, descriptor fetch) + *execution* + *notification* "
      "(execution ends → completion handed to the application: CQE write, moderation, interrupt or poll, "
      "wake-up). **Queue wait** = host batching wait + device queue.")
    a("")
    a("### Platform profile (default)")
    a("")
    a("| parameter | ns | parameter | ns |")
    a("|---|---|---|---|")
    items = list(profile_text.items())
    for i in range(0, len(items), 2):
        l = items[i]
        r = items[i + 1] if i + 1 < len(items) else ("", "")
        a(f"| `{l[0]}` | {l[1]} | `{r[0]}` | {r[1]} |")
    a("")
    a("Device: 1 GHz, 8-byte data path, descriptor fetch bursts of up to 8 (one 512 B read), data-mover "
      "reads of ≤ 512 B with 4 KiB in flight, kernel-mediated submission (one syscall per batch) unless "
      "marked *direct*.")
    a("")

    # ---- observations (computed) ----
    s_single_irq = find(rs, exp="E1", workload="small", submit="single", mode="irq")
    s_b16_irq = find(rs, exp="E1", workload="small", submit="batch16", mode="irq")
    s_b16c_irq = find(rs, exp="E1", workload="small", submit="batch16+coalesce", mode="irq")
    s_single_poll = find(rs, exp="E1", workload="small", submit="single", mode="poll")
    l_single_irq = find(rs, exp="E1", workload="large", submit="single", mode="irq")
    l_single_poll = find(rs, exp="E1", workload="large", submit="single", mode="poll")
    l_b16_irq = find(rs, exp="E1", workload="large", submit="batch16", mode="irq")
    q_irq = find(rs, exp="E2", workload="small", submit="kernel", mode="irq")
    q_poll = find(rs, exp="E2", workload="small", submit="kernel", mode="poll")
    q_mod = find(rs, exp="E2", workload="small", submit="kernel", mode="irq+mod")
    q_hyb = find(rs, exp="E2", workload="small", submit="kernel", mode="hybrid")
    q_dir = find(rs, exp="E2", workload="small", submit="direct", mode="irq")
    ql_irq = find(rs, exp="E2", workload="large", submit="kernel", mode="irq")
    ql_poll = find(rs, exp="E2", workload="large", submit="kernel", mode="poll")
    cnt = sorted([r for r in rs if r["exp"] == "E3" and r["sweep"] == "count"], key=lambda r: r["value"])
    tmr = sorted([r for r in rs if r["exp"] == "E3" and r["sweep"] == "timer"], key=lambda r: r["value"])
    b_irq = sorted([r for r in rs if r["exp"] == "E4" and r["mode"] == "irq"], key=lambda r: r["value"])
    a("## Key findings")
    a("")
    obs = []
    if s_single_irq and s_b16_irq:
        obs.append(f"**Batching is the biggest lever for small commands.** With all commands ready, one doorbell per "
                   f"16 commands raises throughput from {s_single_irq['throughput_cmd_s']/1e6:.2f} to "
                   f"{s_b16_irq['throughput_cmd_s']/1e6:.2f} M cmd/s "
                   f"(×{s_b16_irq['throughput_cmd_s']/s_single_irq['throughput_cmd_s']:.1f}) and cuts host CPU from "
                   f"{s_single_irq['cpu_ns_per_cmd']:.0f} to {s_b16_irq['cpu_ns_per_cmd']:.0f} ns per command; "
                   f"the 4000-command workload finishes in {fmt_us(s_b16_irq['workload_time_ns'])} µs instead of "
                   f"{fmt_us(s_single_irq['workload_time_ns'])} µs. Coalescing the CQEs of a batch takes CPU to "
                   f"{s_b16c_irq['cpu_ns_per_cmd']:.0f} ns/command.")
    if l_single_irq and l_b16_irq:
        obs.append(f"**For large commands the submission path is noise.** A 128 KiB copy runs ~"
                   f"{fmt_us(ql_irq['exec_ns']['mean'])} µs; single submission already reaches "
                   f"{l_single_irq['throughput_gbps']:.2f} GB/s and batching "
                   + ("leaves it unchanged" if abs(l_b16_irq['throughput_gbps'] / l_single_irq['throughput_gbps'] - 1) < 0.02
                      else f"moves it to {l_b16_irq['throughput_gbps']:.2f} GB/s")
                   + f" (the data mover is the bottleneck). Interrupts cost {l_single_irq['cpu_util']*100:.0f}% of a core "
                   f"versus {l_single_poll['cpu_util']*100:.0f}% for polling at the same throughput — polling buys nothing here.")
    if q_irq and q_poll:
        obs.append(f"**Polling wins latency, interrupts win CPU.** At queue depth 1 a small command completes in "
                   f"{fmt_us(q_poll['e2e_ns']['mean'])} µs with polling vs {fmt_us(q_irq['e2e_ns']['mean'])} µs with "
                   f"interrupts (notification {fmt_us(q_poll['notify_ns']['mean'])} vs {fmt_us(q_irq['notify_ns']['mean'])} µs), "
                   f"but polling keeps the core {q_poll['cpu_util']*100:.0f}% busy against {q_irq['cpu_util']*100:.0f}%. "
                   f"Hybrid (spin 5 µs, then sleep) gives {fmt_us(q_hyb['e2e_ns']['mean'])} µs at "
                   f"{q_hyb['cpu_util']*100:.0f}% CPU here because a small command finishes inside the spin budget; "
                   f"for the large command it falls back to sleeping ({find(rs, exp='E2', workload='large', submit='kernel', mode='hybrid')['cpu_util']*100:.0f}% CPU). For the large "
                   f"command the gap is {fmt_us(ql_irq['e2e_ns']['mean'] - ql_poll['e2e_ns']['mean'])} µs on "
                   f"{fmt_us(ql_irq['e2e_ns']['mean'])} µs.")
    if q_mod:
        obs.append(f"**Moderation is a throughput tool that hurts light load.** At QD1, a 16-CQE threshold with a "
                   f"20 µs timer waits for the timer on every command: {fmt_us(q_mod['e2e_ns']['mean'])} µs instead of "
                   f"{fmt_us(q_irq['e2e_ns']['mean'])} µs. `SFH_SUBMIT_IRQ_LAST` (urgent completion for the last "
                   f"command of a batch) removes that penalty for batch-structured work.")
    if cnt and tmr:
        b0 = cnt[0]
        best = min(cnt + tmr, key=lambda r: (r["cpu_ns_per_cmd"], r["e2e_ns"]["mean"]))
        t2 = tmr[0]
        obs.append(f"**Moderation trade-off (50 k cmd/s, one command per submission).** Without moderation every "
                   f"completion costs an interrupt and a wake-up: {b0['irqs_per_cmd']:.2f} interrupts and "
                   f"{b0['cpu_ns_per_cmd']:.0f} ns CPU per command, {fmt_us(b0['e2e_ns']['mean'])} µs mean latency. "
                   f"Moderating (here {best['sweep']} = "
                   f"{best['value'] if best['sweep'] == 'count' else str(best['value'] // 1000) + ' µs'}) lets the next "
                   f"arrival's wake-up collect the completion: {best['irqs_per_cmd']:.3f} interrupts and "
                   f"{best['cpu_ns_per_cmd']:.0f} ns per command (−{100 * (1 - best['cpu_ns_per_cmd'] / b0['cpu_ns_per_cmd']):.0f}%), "
                   f"but latency rises to {fmt_us(best['e2e_ns']['mean'])} µs. A timer shorter than the gap between "
                   f"arrivals ({t2['value'] // 1000} µs) saves nothing and still adds latency "
                   f"({fmt_us(t2['e2e_ns']['mean'])} µs).")
    c3 = sorted([r for r in rs if r["exp"] == "E3b"], key=lambda r: (r["sweep"], r["value"]))
    if c3:
        c1 = find(rs, exp="E3b", sweep="count", value=1)
        c32 = find(rs, exp="E3b", sweep="count", value=32)
        obs.append(f"**Under saturation moderation only costs.** At queue depth 32 the host never sleeps long: one-shot "
                   f"arming plus drain-until-empty already gathers ~{1 / max(c1['irqs_per_cmd'], 1e-9):.0f} completions per "
                   f"interrupt ({c1['irqs_per_cmd']:.3f}/command), so a 32-CQE threshold leaves CPU per command unchanged "
                   f"({c1['cpu_ns_per_cmd']:.0f} → {c32['cpu_ns_per_cmd']:.0f} ns) while throughput falls "
                   f"{c1['throughput_cmd_s']/1e6:.2f} → {c32['throughput_cmd_s']/1e6:.2f} M cmd/s: nothing is "
                   f"resubmitted until the interrupt fires.")
    if b_irq:
        b1, b64 = b_irq[0], b_irq[-1]
        bl = b64["value"]
        obs.append(f"**Batching trade-off (500 k cmd/s offered, interrupts).** Holding commands to fill a batch "
                   f"cuts CPU from {b1['cpu_ns_per_cmd']:.0f} (B=1) to {b64['cpu_ns_per_cmd']:.0f} ns/command (B={bl}) and "
                   f"doorbells from {b1['doorbells_per_cmd']:.2f} to {b64['doorbells_per_cmd']:.3f} per command, at the "
                   f"price of {fmt_us(b64['host_batch_wait_ns']['mean'])} µs mean host batching wait "
                   f"(mean end-to-end {fmt_us(b1['e2e_ns']['mean'])} → {fmt_us(b64['e2e_ns']['mean'])} µs).")
    if q_dir:
        obs.append(f"**Direct (user-mode) submission** saves the syscall: QD1 submission "
                   f"{fmt_us(q_irq['submission_ns']['mean'])} → {fmt_us(q_dir['submission_ns']['mean'])} µs. The device "
                   f"validates every descriptor either way, so this is a performance choice, not a safety one.")
    for o in obs:
        a(f"- {o}")
    a("")

    # ---- E1 ----
    a("## E1 — single vs batched submission × notification mode (burst)")
    a("")
    a("All commands ready at t = 0 (small: 4000 × 64 B kernel; large: 200 × 128 KiB H2D copy); the "
      "application submits as fast as the 256-entry ring allows and reaps as completions arrive.")
    a("")
    if "f2_burst_throughput_cpu.png" in made:
        a("![burst](figures/f2_burst_throughput_cpu.png)")
        a("")
    for w in ("small", "large"):
        unit = "M cmd/s" if w == "small" else "GB/s"
        a(f"**{w}**")
        a("")
        a(f"| submission | notify | workload time (µs) | throughput ({unit}) | CPU/cmd (ns) | CPU busy | "
          "submission mean (µs) | queue wait mean (µs) | e2e p50 / p99 (µs) | irq/cmd | doorbell/cmd |")
        a("|---|---|---|---|---|---|---|---|---|---|---|")
        for s in SUBMIT:
            for m in NOTIFY:
                r = find(rs, exp="E1", workload=w, submit=s, mode=m)
                if not r:
                    continue
                a(f"| {s} | {m} | {fmt_us(r['workload_time_ns'])} | {fmt_thr(r)} | {r['cpu_ns_per_cmd']:.0f} | "
                  f"{r['cpu_util']*100:.0f}% | {fmt_us(r['submission_ns']['mean'])} | {fmt_us(r['queue_wait_ns']['mean'])} | "
                  f"{fmt_us(r['e2e_ns']['p50'])} / {fmt_us(r['e2e_ns']['p99'])} | {r['irqs_per_cmd']:.3f} | "
                  f"{r['doorbells_per_cmd']:.3f} |")
        a("")
    a("In a burst every command is ready at t = 0, so queue wait (and therefore end-to-end latency) is "
      "dominated by the backlog; the meaningful columns are workload time, throughput and CPU.")
    a("")

    # ---- E2 ----
    a("## E2 — one command at a time (QD1): latency decomposition")
    a("")
    if "f1_qd1_latency_breakdown.png" in made:
        a("![qd1](figures/f1_qd1_latency_breakdown.png)")
        a("")
    a("| workload | path | notify | submission | device queue + fetch | execution | notification | e2e mean (µs) | CPU/cmd (ns) | CPU busy |")
    a("|---|---|---|---|---|---|---|---|---|---|")
    for w in ("small", "large"):
        for r in sorted([r for r in rs if r["exp"] == "E2" and r["workload"] == w],
                        key=lambda r: (r["submit"] != "kernel", list(NOTIFY).index(r["mode"]))):
            a(f"| {w} | {r['submit']} | {r['mode']} | {fmt_us(r['submission_ns']['mean'])} | "
              f"{fmt_us(r['device_queue_ns']['mean'])} | {fmt_us(r['exec_ns']['mean'])} | {fmt_us(r['notify_ns']['mean'])} | "
              f"{fmt_us(r['e2e_ns']['mean'])} | {r['cpu_ns_per_cmd']:.0f} | {r['cpu_util']*100:.0f}% |")
    a("")

    # ---- E3 ----
    a("## E3 — interrupt moderation trade-off")
    a("")
    if "f3_moderation_tradeoff.png" in made:
        a("![moderation](figures/f3_moderation_tradeoff.png)")
        a("")
    a("Open loop, 64 B kernels every 20 µs (50 k cmd/s), one command per submission, interrupt notification.")
    a("")
    a("| sweep | setting | irq/cmd | CPU/cmd (ns) | CPU busy | throughput (M cmd/s) | notification mean (µs) | e2e mean (µs) | e2e p99 (µs) |")
    a("|---|---|---|---|---|---|---|---|---|")
    for r in cnt + tmr:
        setting = f"count {r['value']} (timer 50 µs)" if r["sweep"] == "count" else f"timer {r['value']//1000} µs"
        a(f"| {r['sweep']} | {setting} | {r['irqs_per_cmd']:.3f} | {r['cpu_ns_per_cmd']:.0f} | {r['cpu_util']*100:.0f}% | "
          f"{r['throughput_cmd_s']/1e6:.3f} | {fmt_us(r['notify_ns']['mean'])} | {fmt_us(r['e2e_ns']['mean'])} | "
          f"{fmt_us(r['e2e_ns']['p99'])} |")
    a("")

    a("**Closed loop at queue depth 32** (every completion releases a new command; released commands are "
      "submitted together):")
    a("")
    a("| setting | irq/cmd | CPU/cmd (ns) | CPU busy | throughput (M cmd/s) | e2e mean (µs) | e2e p99 (µs) |")
    a("|---|---|---|---|---|---|---|")
    for r in sorted([r for r in rs if r["exp"] == "E3b"], key=lambda r: (r["sweep"], r["value"])):
        setting = f"count {r['value']} (timer 50 µs)" if r["sweep"] == "count" else f"timer {r['value']//1000} µs"
        a(f"| {setting} | {r['irqs_per_cmd']:.3f} | {r['cpu_ns_per_cmd']:.0f} | {r['cpu_util']*100:.0f}% | "
          f"{r['throughput_cmd_s']/1e6:.3f} | {fmt_us(r['e2e_ns']['mean'])} | {fmt_us(r['e2e_ns']['p99'])} |")
    a("")

    # ---- E4 ----
    a("## E4 — submission batching trade-off")
    a("")
    if "f4_batching_tradeoff.png" in made:
        a("![batching](figures/f4_batching_tradeoff.png)")
        a("")
    a("| notify | batch | doorbell/cmd | irq/cmd | CPU/cmd (ns) | CPU busy | host batching wait mean (µs) | queue wait mean (µs) | e2e mean (µs) | e2e p99 (µs) |")
    a("|---|---|---|---|---|---|---|---|---|---|")
    for m in ("irq", "poll"):
        for r in sorted([r for r in rs if r["exp"] == "E4" and r["mode"] == m], key=lambda r: r["value"]):
            a(f"| {m} | {r['value']} | {r['doorbells_per_cmd']:.3f} | {r['irqs_per_cmd']:.3f} | {r['cpu_ns_per_cmd']:.0f} | "
              f"{r['cpu_util']*100:.0f}% | {fmt_us(r['host_batch_wait_ns']['mean'])} | {fmt_us(r['queue_wait_ns']['mean'])} | "
              f"{fmt_us(r['e2e_ns']['mean'])} | {fmt_us(r['e2e_ns']['p99'])} |")
    a("")

    # ---- E5 ----
    a("## E5 — offered-load sweep")
    a("")
    if "f5_load_sweep.png" in made:
        a("![load](figures/f5_load_sweep.png)")
        a("")
    a("| configuration | offered (M cmd/s) | achieved (M cmd/s) | CPU busy | e2e p50 (µs) | e2e p99 (µs) |")
    a("|---|---|---|---|---|---|")
    for name in ("single / irq", "single / poll", "batch8 / irq", "batch8 / poll"):
        for r in sorted([r for r in rs if r["exp"] == "E5" and r["config"] == name], key=lambda r: -r["value"]):
            a(f"| {name} | {1e3 / r['value']:.3f} | {r['throughput_cmd_s']/1e6:.3f} | {r['cpu_util']*100:.0f}% | "
              f"{fmt_us(r['e2e_ns']['p50'])} | {fmt_us(r['e2e_ns']['p99'])} |")
    a("")
    a("Where achieved < offered the configuration is saturated: the backlog (and latency) grows for the "
      "rest of the run.")
    a("")

    # ---- E6 ----
    a("## E6 — sensitivity to the platform profile")
    a("")
    a("Same small-command experiments under two other profiles: "
      + "; ".join(f"**{k}** = `{v}`" for k, v in PROFILES.items() if k != "default") + ".")
    a("")
    a("| profile | experiment | notify | e2e mean (µs) | CPU/cmd (ns) | throughput (M cmd/s) |")
    a("|---|---|---|---|---|---|")
    for pname in PROFILES:
        for kind in ("qd1", "burst single", "burst batch16"):
            for m in ("irq", "poll"):
                if pname == "default":
                    if kind == "qd1":
                        r = find(rs, exp="E2", workload="small", submit="kernel", mode=m)
                    else:
                        r = find(rs, exp="E1", workload="small", submit=kind.split()[1], mode=m)
                else:
                    r = find(rs, exp="E6", profile=pname, kind=kind, mode=m)
                if r:
                    a(f"| {pname} | {kind} | {m} | {fmt_us(r['e2e_ns']['mean'])} | {r['cpu_ns_per_cmd']:.0f} | "
                      f"{r['throughput_cmd_s']/1e6:.3f} |")
    a("")
    a("The orderings (polling < interrupts in latency, batching ≫ single in CPU and throughput for small "
      "commands, moderation hurting QD1) hold under all three profiles; the magnitudes move with the profile.")
    a("")
    a("## Validity checks on these runs")
    a("")
    viol = sum(r["iommu_violations"] for r in rs)
    errs = sum(r["errors"] for r in rs)
    rec = sum(r["recoveries"] for r in rs)
    spur = sum(r["spurious_irqs"] for r in rs)
    a(f"- {len(rs)} runs; command errors: {errs}; DMA-oracle (IOMMU) violations: {viol}; recoveries: {rec}.")
    sp = [r for r in rs if r["spurious_irqs"]]
    a(f"- Spurious interrupts (an interrupt whose completion had already been consumed by polling or by another "
      f"wake-up — harmless by design, CONTRACT §7): {spur}"
      + (" — in " + "; ".join(f"`{r['cmdline']}`" for r in sp) if sp else "") + ".")
    a(f"- Harness wall time {elapsed:.0f} s. Re-run: `make bench` (or `python3 bench/run_bench.py --bin "
      "build/sfh_bench_m0_h0`). Raw per-run JSON: `results/bench_results.json`.")
    a("")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bin", default=os.path.join(ROOT, "build", "sfh_bench_m0_h0"))
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--quick", action="store_true", help="4x fewer commands per run")
    ap.add_argument("--no-figures", action="store_true")
    a = ap.parse_args()
    ex = experiments(a.quick)
    t0 = time.time()
    rs = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as pool:
        futs = {pool.submit(run_one, a.bin, e): e for e in ex}
        for i, f in enumerate(cf.as_completed(futs)):
            rs.append(f.result())
            if (i + 1) % 10 == 0 or i + 1 == len(ex):
                print(f"  {i + 1}/{len(ex)} runs done ({time.time() - t0:.0f} s)", flush=True)
    rs.sort(key=lambda r: (r["exp"], r.get("workload", ""), r.get("submit", ""), str(r.get("mode", "")),
                           str(r.get("config", "")), str(r.get("sweep", "")), r.get("value", 0) or 0))
    os.makedirs(RES, exist_ok=True)
    with open(os.path.join(RES, "bench_results.json"), "w") as f:
        json.dump(rs, f, indent=1)
    made = [] if a.no_figures else figures(rs)
    # the default platform profile, as compiled into the simulator
    prof = json.loads(subprocess.run([a.bin, "--print-profile"], capture_output=True, text=True, check=True).stdout)
    md = report(rs, made, prof, time.time() - t0)
    with open(os.path.join(RES, "BENCHMARKS.md"), "w") as f:
        f.write(md)
    bad = [r for r in rs if r["errors"] or r["iommu_violations"]]
    print(f"wrote results/BENCHMARKS.md, results/bench_results.json, {len(made)} figures "
          f"({len(rs)} runs, {time.time() - t0:.0f} s)")
    if bad:
        print("WARNING: runs with errors or violations:", [r["cmdline"] for r in bad])
        sys.exit(1)


if __name__ == "__main__":
    main()
