# SilicaFlux SF-G1 — host-to-GPU submission path, v2 (HSI 2.0)

A redesigned submission path for the SilicaFlux SF-G1 accelerator: SystemVerilog device front-end,
C host runtime, Python benchmark harness, a simulation transport so all of it runs without PCIe
hardware, and a documented AXI endpoint adapter for physical deployment.

> **Read first.** Everything here was verified in simulation only (Verilator 5.020). Nothing has
> run on silicon or an FPGA; the VFIO transport is compile-checked only; no PCI IDs exist. Benchmark
> numbers come from the cycle-accurate RTL plus an *assumed* platform latency/CPU profile — use the
> trends, re-run with your platform's numbers. See [`docs/LIMITATIONS.md`](docs/LIMITATIONS.md).

## What it implements

| Feature | Where |
|---|---|
| Versioned submission descriptors (magic + version + `DESC_VERSIONS`, epoch, sequence, check dword) | `docs/CONTRACT.md` §2–3, `rtl/sfh_core.sv` |
| Batched submission (one validation pass, barrier and doorbell per batch; device burst fetch of 8; coalesced CQEs) | `sfh_submit`, `S_FETCH_*` |
| Ring-buffer ownership (free-running positions, explicit slot states, single producer/consumer, back-pressure) | CONTRACT §4 |
| Doorbells (per-queue 4 KiB page, absolute and idempotent, validated) | CONTRACT §5 |
| Completion queues (phase-tagged, dw3 last, sequence check byte) | CONTRACT §6 |
| Interrupt moderation (count + timer, one-shot arming, urgent bypass) | CONTRACT §7 |
| Optional polling (IRQ / POLL / HYBRID per queue) | `sfh_queue_params.notify` |
| Fences (timeline signal to a host slot, cross-queue wait that parks without blocking, timeout) | CONTRACT §8 |
| Timeout recovery (device watchdog, host no-progress detection, per-queue reset, escalation ladder, uncertain-completion classification, opt-in replay) | CONTRACT §11 |
| Driver-authorised DMA (mapping table with owner, permission, generation; live re-check; revocation handshake; IOMMU) | CONTRACT §9, `docs/SECURITY.md` |
| Memory-ordering contract host ↔ device (O1–O16 + barrier mapping) | CONTRACT §10 |
| Simulation transport (virtual-time co-simulation, PCIe-ordered channels, IOMMU oracle, fault injection) | `sim/`, `docs/SIMULATION.md` |
| Endpoint adapter for physical deployment (AXI bridge, ordering guarantees A1–A6) + VFIO host transport | `adapter/`, `host/src/sfh_vfio.c`, `docs/ENDPOINT_ADAPTER.md` |

## Results at a glance

**Verification** ([`docs/VERIFICATION.md`](docs/VERIFICATION.md), logs in `results/evidence/`):
20/20 co-simulation tests (22,506 checks) — wraparound, duplicate notifications, stale descriptors,
process termination, device reset, uncertain completion, validation, isolation, fences, timeouts,
moderation, polling — each ending with **zero** unauthorised DMA in the simulated IOMMU; **15/15
mutants killed** (10 RTL, 5 host); adapter testbench passes and catches both of its ordering mutants;
RTL lint-clean under Verilator `-Wall`.

**Benchmarks** ([`results/BENCHMARKS.md`](results/BENCHMARKS.md), 106 runs, figures in
`results/figures/`):

| | |
|---|---|
| small commands, all ready, single → batch of 16 | 1.92 → 7.48 M cmd/s; host CPU 520 → 133 ns/cmd |
| one small command at a time, interrupts vs polling | 6.55 µs at 59 % CPU vs 2.16 µs at 100 % CPU |
| same, with count moderation (16 CQEs / 20 µs) | 26.6 µs — moderation hurts light load |
| moderation at 50 k cmd/s, one command per submission | −55 % CPU per command, mean latency 9.05 → 22.5 µs |
| batching at 500 k cmd/s, B = 1 → 32 (interrupts) | CPU 1,627 → 284 ns/cmd, mean latency 7.81 → 43.4 µs |
| 128 KiB copies | 4.64 GB/s either way (data mover bound); interrupts 13 % CPU, polling 100 % |

## Layout

```
spec/sfh_spec.py            single source of truth -> rtl/sfh_pkg.sv, host/include/sfh_abi.h, docs/REGMAP.md
rtl/                        device: sfh_core (front-end), sfh_datamover, sfh_kernel, sfh_devmem, sfh_top
adapter/                    PCIe endpoint (AXI bridge) adapter + sfh_ep_top, SV testbench, runner
sim/                        simulation transport: Verilator co-simulation, platform profile, IOMMU oracle, faults
host/include/               sfh.h (API), sfh_abi.h (generated), sfh_transport.h
host/src/                   sfh_kmd.c (driver layer), sfh_umd.c (library), sfh_vfio.c (physical transport)
tests/                      sfh_tests.c (20 tests), run_mutants.sh, run_all_checks.sh
bench/                      sfh_bench.c (driver), run_bench.py (harness, report, figures)
docs/                       CONTRACT, REGMAP, SECURITY, SIMULATION, ENDPOINT_ADAPTER, VERIFICATION,
                            CHANGES_FROM_V1, LIMITATIONS
results/                    BENCHMARKS.md, bench_results.json, figures/, MUTANTS.md, evidence/
```

## Quick start

Requirements: Verilator ≥ 5.0 (`--binary --timing` for the adapter TB), gcc/g++ (C11/C++17), make,
Python 3 with matplotlib for the figures.

```bash
make test
```

```bash
make bench
```

```bash
make all-checks
```

`make test` builds the Verilated device and runs the suite (seconds). `make bench` regenerates
`results/`. `make all-checks` runs spec freshness, lint, tests, adapter TB, VFIO compile and every
mutant from a clean build (about 4 minutes on 4 cores). Variant builds: `make MUTANT=3 HOST_MUTANT=0 test`.
Set `SFH_DEBUG=1` to see the driver's recovery decisions.

Minimal use of the API (`examples/quickstart.c`, runs against the simulator with `make example`):

```c
sfh_dev *d;  sfh_ctx *c;  sfh_queue *q;  sfh_buf *b, *out;
sfh_dev_open(transport, NULL, &d);                 /* driver layer: probe, limits, self-test */
sfh_ctx_open(d, &c);                               /* one per process */
sfh_buf_alloc(c, 1 << 20, SFH_BUF_DEV_READ, &b);   /* driver maps it; the app never sees an address */
sfh_buf_alloc(c, 4096, SFH_BUF_DEV_WRITE, &out);
sfh_queue_params p;  sfh_queue_params_default(&p);
p.notify = SFH_NOTIFY_HYBRID;  p.imod_count = 8;  p.imod_time_ns = 20000;
sfh_queue_create(c, &p, &q);
sfh_cmd cmds[3] = { { .op = SFH_OP_COPY_H2D, .buf = b, .len = 4096 },
                    { .op = SFH_OP_COPY_D2H, .buf = out, .len = 4096 },
                    { .op = SFH_OP_FENCE_SIGNAL, .value = 1 } };
uint64_t t;  sfh_submit(q, cmds, 3, SFH_SUBMIT_COALESCE | SFH_SUBMIT_IRQ_LAST, &t);
sfh_completion r;  sfh_wait_ticket(q, t + 2, 1000000000ull, &r);   /* one CQE for the batch */
```

## Provenance

Built on the SF-G1 v1.0 driver package in this repository (`SilicaFlux-main/silicaflux-sfg1-driver-0.1.0.zip`):
its draft contract, CSR vocabulary and chip ID. [`docs/CHANGES_FROM_V1.md`](docs/CHANGES_FROM_V1.md)
lists what changed. License: MIT (SPDX tags in each file).
