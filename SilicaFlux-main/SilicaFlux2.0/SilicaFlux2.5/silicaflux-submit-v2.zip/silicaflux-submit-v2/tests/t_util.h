/* SPDX-License-Identifier: MIT */
/* Test helpers: one fresh simulated device per test, check macros, small command builders. */
#ifndef T_UTIL_H
#define T_UTIL_H
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sfh.h"
#include "sfh_cosim.h"

static int g_checks, g_fails;
static const char *g_test = "";

#define CHECK(cond, ...) do {                                                        \
	g_checks++;                                                                  \
	if (!(cond)) {                                                               \
		g_fails++;                                                           \
		fprintf(stderr, "  FAIL [%s] %s:%d: %s :: ", g_test, __FILE__, __LINE__, #cond); \
		fprintf(stderr, __VA_ARGS__);                                        \
		fprintf(stderr, "\n");                                               \
	}                                                                            \
} while (0)
#define CHECK_EQ(a, b) do {                                                          \
	unsigned long long _a = (unsigned long long)(a), _b = (unsigned long long)(b);  \
	CHECK(_a == _b, "%s=%llu (0x%llx) expected %llu (0x%llx)", #a, _a, _a, _b, _b); \
} while (0)
#define REQUIRE(cond, ...) do { int _ok = !!(cond); CHECK(_ok, __VA_ARGS__); if (!_ok) return; } while (0)

typedef struct env {
	void *sim;
	const sfh_transport *tp;
	sfh_dev *d;
	uint64_t expect_violations;
} env;

static inline int env_open_p(env *e, const char *profile, const sfh_dev_params *dp)
{
	sfh_sim_profile p;
	sfh_sim_profile_default(&p);
	if (profile && sfh_sim_profile_parse(&p, profile)) return -1;
	memset(e, 0, sizeof(*e));
	e->sim = sfh_sim_create(&p);
	e->tp = sfh_sim_transport(e->sim);
	return sfh_dev_open(e->tp, dp, &e->d);
}
static inline int env_open(env *e) { return env_open_p(e, NULL, NULL); }

/* every test ends here: the DMA oracle must not have seen a single unauthorised access */
static inline void env_close(env *e)
{
	sfh_sim_stats s;
	sfh_sim_get_stats(e->sim, &s);
	CHECK(s.iommu_violations == e->expect_violations,
	      "IOMMU/DMA-oracle violations=%" PRIu64 " (expected %" PRIu64 ") last iova=0x%" PRIx64,
	      s.iommu_violations, e->expect_violations, s.last_violation_iova);
	if (e->d) sfh_dev_close(e->d);
	sfh_sim_get_stats(e->sim, &s);
	CHECK(s.iommu_violations == e->expect_violations, "violations during teardown=%" PRIu64, s.iommu_violations);
	sfh_sim_destroy(e->sim);
}
static inline uint64_t env_violations(env *e)
{
	sfh_sim_stats s;
	sfh_sim_get_stats(e->sim, &s);
	return s.iommu_violations;
}

static inline sfh_queue *mkq(sfh_ctx *c, sfh_notify n, uint32_t entries, uint32_t flags)
{
	sfh_queue_params p;
	sfh_queue_params_default(&p);
	p.notify = n;
	p.sq_entries = entries;
	p.cq_entries = entries;
	p.flags = flags;
	sfh_queue *q = NULL;
	int rc = sfh_queue_create(c, &p, &q);
	CHECK(rc == 0, "queue_create rc=%d", rc);
	return q;
}

static inline sfh_cmd c_nop(uint32_t tag) { sfh_cmd c = {0}; c.op = SFH_OP_NOP; c.user_tag = tag; return c; }
static inline sfh_cmd c_h2d(sfh_buf *b, uint64_t boff, uint64_t doff, uint32_t len)
{
	sfh_cmd c = {0}; c.op = SFH_OP_COPY_H2D; c.buf = b; c.buf_off = boff; c.dev_off = doff; c.len = len; return c;
}
static inline sfh_cmd c_d2h(sfh_buf *b, uint64_t boff, uint64_t doff, uint32_t len)
{
	sfh_cmd c = {0}; c.op = SFH_OP_COPY_D2H; c.buf = b; c.buf_off = boff; c.dev_off = doff; c.len = len; return c;
}
static inline sfh_cmd c_kern(uint8_t kop, uint64_t src, uint64_t dst, uint32_t len, uint64_t k)
{
	sfh_cmd c = {0}; c.op = SFH_OP_KERNEL; c.kop = kop; c.dev_off = src; c.dev_off2 = dst; c.len = len; c.value = k; return c;
}
static inline sfh_cmd c_spin(uint64_t ns) { return c_kern(SFH_KOP_SPIN, 0, 0, 0, ns); }
static inline sfh_cmd c_signal(uint64_t v) { sfh_cmd c = {0}; c.op = SFH_OP_FENCE_SIGNAL; c.value = v; return c; }
static inline sfh_cmd c_wait(sfh_queue *t, uint64_t v) { sfh_cmd c = {0}; c.op = SFH_OP_FENCE_WAIT; c.wait_queue = t; c.value = v; return c; }

/* submit one command and wait for it */
static inline sfh_completion run1(sfh_queue *q, sfh_cmd c)
{
	sfh_completion r;
	memset(&r, 0, sizeof(r));
	uint64_t t = 0;
	int rc = sfh_submit(q, &c, 1, 0, &t);
	CHECK(rc == 0, "submit rc=%d", rc);
	if (rc) { r.status = 0xdead; return r; }
	rc = sfh_wait_ticket(q, t, 100000000ull, &r);
	CHECK(rc == 0, "wait_ticket rc=%d", rc);
	if (rc) r.status = 0xdead;
	return r;
}

/* wait until every in-flight command completed; returns completions collected */
static inline unsigned drain_all(sfh_queue *q, sfh_completion *out, unsigned max)
{
	unsigned n = 0;
	for (int guard = 0; guard < 100000 && (sfh_queue_inflight(q) || n == 0); guard++) {
		sfh_completion tmp[64];
		int r = sfh_wait_any(q, 200000000ull, tmp, 64);
		if (r <= 0) {
			int r2 = sfh_reap(q, tmp, 64);
			if (r2 <= 0) break;
			r = r2;
		}
		for (int i = 0; i < r; i++) if (n < max) out[n++] = tmp[i];
		if (!sfh_queue_inflight(q)) {
			int r3 = sfh_reap(q, tmp, 64);
			for (int i = 0; i < r3; i++) if (n < max) out[n++] = tmp[i];
			break;
		}
	}
	return n;
}

static inline void fill_pattern(void *p, size_t n, uint32_t seed)
{
	uint32_t *w = (uint32_t *)p, x = seed * 2654435761u + 1;
	for (size_t i = 0; i < n / 4; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; w[i] = x; }
}

#endif
