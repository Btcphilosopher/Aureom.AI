// SPDX-License-Identifier: MIT
/*
 * SilicaFlux HSI v2 — co-simulation test suite (host runtime + Verilated RTL).
 *
 * Every test runs against a fresh simulated device and ends in env_close(), which fails
 * the test if the simulated IOMMU (the DMA oracle) saw any device access outside what
 * the driver had mapped at that moment. `./sfh_tests all` or `./sfh_tests <name>`.
 */
#include "t_util.h"

#define MS 1000000ull
#define US 1000ull

static sfh_dev_params fast_params(void)
{
	sfh_dev_params p = { .cmd_timeout_ns = 2000000, .fence_timeout_ns = 5000000, .reset_timeout_ns = 100000 };
	return p;
}

static void check_clean(sfh_queue *q, const char *what)
{
	sfh_queue_stats s;
	sfh_queue_get_stats(q, &s);
	CHECK(s.anomaly_torn == 0 && s.anomaly_stale == 0 && s.anomaly_sqhead == 0,
	      "%s: anomalies torn=%llu stale=%llu sqhead=%llu", what, (unsigned long long)s.anomaly_torn,
	      (unsigned long long)s.anomaly_stale, (unsigned long long)s.anomaly_sqhead);
	CHECK(s.recoveries == 0 && s.host_timeouts == 0, "%s: recoveries=%llu host_timeouts=%llu", what,
	      (unsigned long long)s.recoveries, (unsigned long long)s.host_timeouts);
}

/* raw descriptor submission at the tail (models a direct-submission client) */
static sfh_completion raw1(sfh_queue *q, const sfh_desc *dsc)
{
	uint16_t pos = sfh_test_sq_tail(q);
	sfh_test_write_slot(q, pos, dsc);
	sfh_test_adopt(q, (uint16_t)(pos + 1), sfh_test_next_seq(q) + 1);
	sfh_test_doorbell(q, (uint16_t)(pos + 1));
	sfh_completion r[4];
	memset(r, 0, sizeof(r));
	int n = sfh_wait_any(q, 50 * MS, r, 4);
	CHECK(n == 1, "raw1: %d completions", n);
	return r[0];
}
static sfh_desc rawdesc(sfh_queue *q, sfh_cmd c)
{
	sfh_desc d;
	sfh_test_build(q, &c, sfh_test_next_seq(q), &d);
	return d;
}

/* ================================================================== probe */
static void t_probe(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	CHECK_EQ(sfh_test_mmio_rd(e.d, SFH_REG_ID), SFH_CHIP_ID);
	CHECK_EQ(sfh_test_mmio_rd(e.d, SFH_REG_HW_VERSION) >> 16, 2);
	CHECK_EQ(sfh_test_mmio_rd(e.d, SFH_REG_DESC_VERSIONS), SFH_DESC_VERSIONS);
	uint32_t l0 = sfh_test_mmio_rd(e.d, SFH_REG_LIMITS0);
	CHECK_EQ(l0 & 0xff, SFH_NQ);
	CHECK_EQ((l0 >> 24) & 0xff, SFH_FETCH_MAX);
	/* queue config is refused while enabled; bad config refuses enable */
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_POLL, 16, 0);
	uint32_t base = sfh_test_mmio_rd(e.d, SFH_QREG(sfh_queue_id(q), SFH_QSQ_BASE_LO));
	sfh_test_mmio_wr(e.d, SFH_QREG(sfh_queue_id(q), SFH_QSQ_BASE_LO), 0x40);
	CHECK_EQ(sfh_test_mmio_rd(e.d, SFH_QREG(sfh_queue_id(q), SFH_QSQ_BASE_LO)), base);
	unsigned q3 = 3;
	sfh_test_mmio_wr(e.d, SFH_QREG(q3, SFH_QSIZE), 3);   /* 8 entries: below minimum */
	sfh_test_mmio_wr(e.d, SFH_QREG(q3, SFH_QCTL), 1);
	uint32_t st = sfh_test_mmio_rd(e.d, SFH_QREG(q3, SFH_QSTATUS));
	CHECK(!(st & 1) && (st & (1u << SFH_QST_CFG_ERR)), "bad config must not enable: 0x%x", st);
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.sq_entries = 100;
	sfh_queue *bad;
	CHECK_EQ(sfh_queue_create(c, &p, &bad), -EINVAL);
	sfh_queue_params_default(&p);
	p.imod_count = 8; p.imod_time_ns = 0;
	CHECK_EQ(sfh_queue_create(c, &p, &bad), -EINVAL);
	env_close(&e);
}

/* ================================================================== basic data path */
static void t_basic(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_IRQ, 64, 0);
	sfh_buf *src, *dst;
	REQUIRE(sfh_buf_alloc(c, 4096, SFH_BUF_DEV_READ, &src) == 0, "buf");
	REQUIRE(sfh_buf_alloc(c, 4096, SFH_BUF_DEV_WRITE, &dst) == 0, "buf");
	fill_pattern(sfh_buf_ptr(src), 4096, 7);
	sfh_completion r = run1(q, c_nop(0x1234));
	CHECK_EQ(r.status, SFH_ST_OK);
	CHECK_EQ(r.user_tag, 0x1234);
	r = run1(q, c_h2d(src, 0, 0x100, 4096));
	CHECK_EQ(r.status, SFH_ST_OK);
	r = run1(q, c_d2h(dst, 0, 0x100, 4096));
	CHECK_EQ(r.status, SFH_ST_OK);
	CHECK(memcmp(sfh_buf_ptr(src), sfh_buf_ptr(dst), 4096) == 0, "round trip data mismatch");
	r = run1(q, c_kern(SFH_KOP_ADD32, 0x100, 0x2000, 4096, 5));
	CHECK_EQ(r.status, SFH_ST_OK);
	run1(q, c_d2h(dst, 0, 0x2000, 4096));
	uint32_t *s32 = sfh_buf_ptr(src), *d32 = sfh_buf_ptr(dst);
	int bad = 0;
	uint32_t sum = 0;
	for (int i = 0; i < 1024; i++) { if (d32[i] != s32[i] + 5) bad++; sum += s32[i]; }
	CHECK(bad == 0, "ADD32 wrong in %d lanes", bad);
	r = run1(q, c_kern(SFH_KOP_SUM32, 0x100, 0, 4096, 0));
	CHECK_EQ(r.status, SFH_ST_OK);
	CHECK_EQ(r.result, sum);
	r = run1(q, c_kern(SFH_KOP_XOR64, 0x100, 0x3000, 4096, 0xF0F0F0F0A5A5A5A5ull));
	CHECK_EQ(r.status, SFH_ST_OK);
	run1(q, c_d2h(dst, 0, 0x3000, 4096));
	uint64_t *s64 = sfh_buf_ptr(src), *d64 = sfh_buf_ptr(dst);
	bad = 0;
	for (int i = 0; i < 512; i++) if (d64[i] != (s64[i] ^ 0xF0F0F0F0A5A5A5A5ull)) bad++;
	CHECK(bad == 0, "XOR64 wrong in %d words", bad);
	sfh_buf *big;
	REQUIRE(sfh_buf_alloc(c, 3 * 4096 + 64, SFH_BUF_DEV_READ | SFH_BUF_DEV_WRITE, &big) == 0, "big");
	fill_pattern(sfh_buf_ptr(big), 3 * 4096 + 64, 99);
	r = run1(q, c_h2d(big, 8, 0x8008, 3 * 4096 - 8));
	CHECK_EQ(r.status, SFH_ST_OK);
	run1(q, c_d2h(dst, 0, 0x8008 + 4096, 4096));
	CHECK(memcmp((uint8_t *)sfh_buf_ptr(big) + 8 + 4096, sfh_buf_ptr(dst), 4096) == 0, "unaligned-boundary copy");
	r = run1(q, c_spin(20000));
	CHECK_EQ(r.status, SFH_ST_OK);
	check_clean(q, "basic");
	sfh_queue_stats qs; sfh_queue_get_stats(q, &qs);
	CHECK_EQ(qs.spurious_irqs, 0);
	env_close(&e);
}

/* ================================================================== batching */
static void t_batch(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_IRQ, 64, 0);
	unsigned qid = sfh_queue_id(q);
	sfh_cmd cmds[32];
	for (int i = 0; i < 32; i++) cmds[i] = c_nop(100 + i);
	uint32_t f0 = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QFETCH_COUNT));
	uint64_t t0;
	REQUIRE(sfh_submit(q, cmds, 32, 0, &t0) == 0, "submit");
	sfh_completion r[64];
	unsigned n = drain_all(q, r, 64);
	CHECK_EQ(n, 32);
	for (unsigned i = 0; i < n; i++) {
		CHECK_EQ(r[i].ticket, t0 + i);
		CHECK_EQ(r[i].user_tag, 100 + i);
		CHECK_EQ(r[i].status, SFH_ST_OK);
	}
	uint32_t f1 = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QFETCH_COUNT));
	CHECK(f1 - f0 <= 32 / SFH_FETCH_MAX + 1, "32 descriptors should take ~4 fetch bursts, took %u", f1 - f0);
	sfh_queue_stats s0, s1;
	sfh_queue_get_stats(q, &s0);
	CHECK_EQ(s0.doorbells, 1);
	/* coalesced: one CQE (and at most one interrupt) for the whole batch */
	REQUIRE(sfh_submit(q, cmds, 16, SFH_SUBMIT_COALESCE | SFH_SUBMIT_IRQ_LAST, &t0) == 0, "submit");
	n = drain_all(q, r, 64);
	CHECK_EQ(n, 16);
	for (unsigned i = 0; i < n; i++) { CHECK_EQ(r[i].ticket, t0 + i); CHECK_EQ(r[i].status, SFH_ST_OK); }
	sfh_queue_get_stats(q, &s1);
	CHECK_EQ(s1.cqes - s0.cqes, 1);
	CHECK(s1.irqs - s0.irqs <= 1, "coalesced batch took %llu interrupts", (unsigned long long)(s1.irqs - s0.irqs));
	CHECK_EQ(s1.doorbells - s0.doorbells, 1);
	/* a batch larger than the ring is refused, a batch that does not fit returns EAGAIN */
	sfh_cmd many[80];
	for (int i = 0; i < 80; i++) many[i] = c_nop(i);
	CHECK_EQ(sfh_submit(q, many, 80, 0, NULL), -E2BIG);
	/* an invalid command anywhere rejects the whole batch: nothing is queued */
	cmds[5].op = 77;
	CHECK_EQ(sfh_submit(q, cmds, 8, 0, NULL), -EINVAL);
	CHECK_EQ(sfh_queue_inflight(q), 0);
	check_clean(q, "batch");
	env_close(&e);
}

/* ================================================================== wraparound */
static void t_wraparound(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_POLL, 16, 0);
	/* start the sequence just below 2^32 so it wraps during the run */
	REQUIRE(sfh_test_restart(q, 0xFFFFFF00u) == 0, "restart");
	sfh_buf *b;
	REQUIRE(sfh_buf_alloc(c, 4096, SFH_BUF_DEV_READ | SFH_BUF_DEV_WRITE, &b) == 0, "buf");
	uint64_t expect = 0, got = 0, bad = 0, first = 0;
	unsigned seed = 1;
	/* > 65536 commands: the 16-bit ring positions, the CQ phase and the 32-bit seq all wrap */
	const unsigned TOTAL = 70000;
	while (got < TOTAL) {
		sfh_cmd cmds[16];
		seed = seed * 1103515245u + 12345u;
		unsigned want = 1 + (seed >> 16) % 16, room = 16 - sfh_queue_inflight(q);
		if (expect - got + want > 16 || expect >= TOTAL) want = 0;
		if (want > room) want = room;
		if (expect + want > TOTAL) want = (unsigned)(TOTAL - expect);
		for (unsigned i = 0; i < want; i++) cmds[i] = c_nop((uint32_t)(expect + i));
		if (want) {
			uint64_t t;
			int rc = sfh_submit(q, cmds, want, (seed & 0x100) ? SFH_SUBMIT_COALESCE : 0, &t);
			CHECK(rc == 0, "submit rc=%d", rc);
			if (rc) break;
			if (!expect) first = t;
			expect += want;
		}
		sfh_completion r[16];
		int n = sfh_wait_any(q, 50 * MS, r, 16);
		if (n < 0) { CHECK(0, "wait rc=%d", n); break; }
		for (int i = 0; i < n; i++) {
			if (r[i].ticket != first + got || r[i].user_tag != (uint32_t)got || r[i].status) bad++;
			got++;
		}
	}
	CHECK_EQ(got, TOTAL);
	CHECK_EQ(bad, 0);
	uint32_t pos = sfh_test_mmio_rd(e.d, SFH_QREG(sfh_queue_id(q), SFH_QSQPOS));
	CHECK_EQ(pos & 0xffff, TOTAL & 0xffff);   /* the device's free-running head wrapped too */
	/* data still correct after all the wrapping */
	fill_pattern(sfh_buf_ptr(b), 4096, 3);
	uint8_t ref[4096];
	memcpy(ref, sfh_buf_ptr(b), 4096);
	CHECK_EQ(run1(q, c_h2d(b, 0, 0, 4096)).status, 0);
	memset(sfh_buf_ptr(b), 0, 4096);
	CHECK_EQ(run1(q, c_d2h(b, 0, 0, 4096)).status, 0);
	CHECK(memcmp(ref, sfh_buf_ptr(b), 4096) == 0, "data after wrap");
	check_clean(q, "wraparound");
	env_close(&e);
}

/* ================================================================== doorbells */
static void t_doorbell(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_IRQ, 16, 0);
	unsigned qid = sfh_queue_id(q);
	/* duplicate doorbells: same tail written again (merged / replayed MMIO) is a no-op */
	sfh_cmd cmds[4] = { c_nop(1), c_nop(2), c_nop(3), c_nop(4) };
	uint64_t t;
	REQUIRE(sfh_submit(q, cmds, 4, 0, &t) == 0, "submit");
	uint16_t tail = sfh_test_sq_tail(q);
	for (int i = 0; i < 3; i++) sfh_test_doorbell(q, tail);
	sfh_completion r[16];
	unsigned n = drain_all(q, r, 16);
	CHECK_EQ(n, 4);
	for (unsigned i = 0; i < n; i++) CHECK_EQ(r[i].ticket, t + i);
	sfh_test_doorbell(q, tail);   /* after completion as well */
	CHECK(sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QDB_DUP)) >= 3, "dup doorbells not counted");
	CHECK_EQ(sfh_test_mmio_rd(e.d, SFH_REG_DONE_COUNT), 4);   /* nothing executed twice */
	/* backwards, beyond capacity, CQ head beyond produced: rejected and counted */
	uint32_t err0 = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QDB_ERR));
	sfh_test_doorbell(q, (uint16_t)(tail - 2));
	sfh_test_doorbell(q, (uint16_t)(tail + 17));
	sfh_test_cq_doorbell(q, (uint16_t)(tail + 5));
	uint32_t err1 = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QDB_ERR));
	CHECK_EQ(err1 - err0, 3);
	uint32_t pos = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QSQPOS));
	CHECK_EQ(pos >> 16, tail);   /* tail unchanged */
	/* doorbell on a disabled queue */
	sfh_test_mmio_wr(e.d, SFH_DBREG(3, SFH_DB_SQ_TAIL), 5);
	CHECK(sfh_test_mmio_rd(e.d, SFH_QREG(3, SFH_QDB_ERR)) == 1, "doorbell to disabled queue not rejected");
	/* still fully functional */
	CHECK_EQ(run1(q, c_nop(9)).status, 0);
	CHECK_EQ(sfh_test_mmio_rd(e.d, SFH_REG_DONE_COUNT), 5);
	check_clean(q, "doorbell");
	env_close(&e);
}

/* ================================================================== interrupts: dup / lost / arm race */
static void t_irq(void)
{
	env e;
	sfh_dev_params dp = fast_params();
	REQUIRE(env_open_p(&e, NULL, &dp) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.host_timeout_ns = 300 * US;
	sfh_queue *q; REQUIRE(sfh_queue_create(c, &p, &q) == 0, "q");
	unsigned qid = sfh_queue_id(q);
	/* QD1, no moderation: exactly one useful interrupt per command, none spurious */
	for (int i = 0; i < 20; i++) CHECK_EQ(run1(q, c_nop(i)).status, 0);
	sfh_queue_stats s;
	sfh_queue_get_stats(q, &s);
	CHECK_EQ(s.spurious_irqs, 0);
	CHECK_EQ(s.irqs, 20);
	CHECK_EQ(s.host_timeouts, 0);
	/* duplicated interrupt messages: every completion once, extra wakeups are harmless */
	sfh_sim_fault(e.sim, SFH_FI_DUP_MSI, 10);
	uint64_t t;
	for (int i = 0; i < 10; i++) {
		sfh_cmd cm = c_spin(30000);
		REQUIRE(sfh_submit(q, &cm, 1, 0, &t) == 0, "submit");
		sfh_completion r;
		CHECK_EQ(sfh_wait_ticket(q, t, 50 * MS, &r), 0);
		CHECK_EQ(r.status, 0);
	}
	sfh_completion extra[4];
	CHECK_EQ(sfh_reap(q, extra, 4), 0);
	sfh_queue_get_stats(q, &s);
	CHECK(s.spurious_irqs >= 1, "duplicate MSIs should show up as spurious wakeups");
	CHECK_EQ(s.recoveries, 0);
	CHECK_EQ(run1(q, c_spin(50000)).status, 0);   /* let the last delayed duplicate land first */
	/* lost interrupt messages: the no-progress timeout finds the CQEs; no reset needed */
	sfh_sim_fault(e.sim, SFH_FI_DROP_MSI, 3);
	for (int i = 0; i < 3; i++) CHECK_EQ(run1(q, c_nop(50 + i)).status, 0);
	sfh_queue_get_stats(q, &s);
	CHECK(s.lost_irq_recovered >= 3, "lost interrupts recovered=%llu", (unsigned long long)s.lost_irq_recovered);
	CHECK_EQ(s.recoveries, 0);
	/* arm race: a CQE the host has not consumed when it arms -> immediate interrupt */
	uint32_t irq0 = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QIRQ_COUNT));
	sfh_cmd nop = c_nop(77);
	REQUIRE(sfh_submit(q, &nop, 1, 0, &t) == 0, "submit");
	for (int i = 0; i < 5; i++) sfh_test_mmio_rd(e.d, SFH_REG_SCRATCH);   /* let it complete, unconsumed */
	sfh_test_mmio_wr(e.d, SFH_DBREG(qid, SFH_DB_CQ_ARM), 1);
	sfh_test_mmio_rd(e.d, SFH_REG_SCRATCH);
	uint32_t irq1 = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QIRQ_COUNT));
	CHECK_EQ(irq1 - irq0, 1);
	sfh_completion r;
	CHECK_EQ(sfh_wait_ticket(q, t, 50 * MS, &r), 0);
	CHECK_EQ(r.status, 0);
	sfh_queue_get_stats(q, &s);
	CHECK(s.anomaly_torn == 0 && s.anomaly_stale == 0, "anomalies");
	env_close(&e);
}

/* ================================================================== duplicate CQEs */
static void t_cqe_dup(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_POLL, 32, 0);
	sfh_sim_fault(e.sim, SFH_FI_DUP_CQE, 1000);
	uint64_t next = 0, first = 0, seen = 0, bad = 0;
	for (int round = 0; round < 40; round++) {
		sfh_cmd cmds[3] = { c_spin(500), c_nop(1), c_spin(700) };
		uint64_t t;
		REQUIRE(sfh_submit(q, cmds, 3, 0, &t) == 0, "submit");
		if (!round) first = t;
		next += 3;
		sfh_completion r[8];
		while (seen < next) {
			int n = sfh_wait_any(q, 50 * MS, r, 8);
			if (n <= 0) { CHECK(0, "wait rc=%d", n); break; }
			for (int i = 0; i < n; i++) { if (r[i].ticket != first + seen || r[i].status) bad++; seen++; }
		}
	}
	CHECK_EQ(seen, 120);
	CHECK_EQ(bad, 0);
	sfh_completion r[4];
	CHECK_EQ(sfh_reap(q, r, 4), 0);   /* nothing completed twice */
	sfh_queue_stats s; sfh_queue_get_stats(q, &s);
	CHECK(s.anomaly_stale > 0, "duplicated CQEs must be seen and rejected (stale=%llu)", (unsigned long long)s.anomaly_stale);
	CHECK_EQ(s.recoveries, 0);
	CHECK_EQ(s.completions, 120);
	env_close(&e);
}

/* ================================================================== stale descriptors */
static void t_stale(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_IRQ, 16, 0);
	/* fill the ring once so every slot holds a valid, already-executed descriptor */
	sfh_cmd nops[16];
	for (int i = 0; i < 16; i++) nops[i] = c_nop(i);
	REQUIRE(sfh_submit(q, nops, 16, 0, NULL) == 0, "fill");
	sfh_completion r[32];
	CHECK_EQ(drain_all(q, r, 32), 16);
	/* (a) publish a slot nobody rewrote: the device sees last lap's descriptor */
	uint16_t pos = sfh_test_sq_tail(q);
	sfh_test_adopt(q, (uint16_t)(pos + 1), sfh_test_next_seq(q) + 1);
	sfh_test_doorbell(q, (uint16_t)(pos + 1));
	unsigned n = drain_all(q, r, 32);
	CHECK(n == 1 && r[0].status == SFH_ST_STALE_SEQ, "stale slot: n=%u status=%s", n, n ? sfh_status_str(r[0].status) : "-");
	CHECK_EQ(run1(q, c_nop(1)).status, 0);   /* queue recovered */
	/* (b) a descriptor written before a reset (old epoch), published after it */
	sfh_desc old;
	sfh_cmd nop = c_nop(0xE);
	uint32_t seq_after = sfh_test_next_seq(q);
	sfh_test_build(q, &nop, seq_after, &old);
	REQUIRE(sfh_dev_engine_reset(e.d) == 0, "engine reset");
	CHECK(sfh_test_epoch(q) != (old.dw[2] & 0xffff), "epoch must change across a reset");
	r[0] = raw1(q, &old);
	CHECK(r[0].status == SFH_ST_STALE_EPOCH, "old-epoch descriptor: %s", sfh_status_str(r[0].status));
	CHECK_EQ(run1(q, c_nop(2)).status, 0);
	/* (c) torn slot: half of the descriptor rewritten -> check dword mismatch */
	sfh_desc d = rawdesc(q, c_nop(3));
	d.dw[3] ^= 0x10;
	r[0] = raw1(q, &d);
	CHECK(r[0].status == SFH_ST_BAD_CHECK, "torn: %s", sfh_status_str(r[0].status));
	/* (d) an SF-G1 v1 descriptor (opcode in byte 0, raw host address) */
	memset(&d, 0, sizeof(d));
	d.dw[0] = 1;              /* v1 DMA_H2D, ctx 0 */
	d.dw[4] = 0x1000;         /* v1 host_addr: a raw bus address — never honoured */
	d.dw[6] = 64;
	r[0] = raw1(q, &d);
	CHECK(r[0].status == SFH_ST_BAD_VERSION, "v1 descriptor: %s", sfh_status_str(r[0].status));
	/* (e) correct magic, unknown descriptor version */
	d = rawdesc(q, c_nop(4));
	d.dw[0] = (d.dw[0] & ~0xff00u) | (3u << 8);
	sfh_desc_seal(&d);
	r[0] = raw1(q, &d);
	CHECK(r[0].status == SFH_ST_BAD_VERSION, "v3 descriptor: %s", sfh_status_str(r[0].status));
	/* (f) commands behind a stale one are not executed (or replayed, if asked) */
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.sq_entries = p.cq_entries = 16; p.flags = SFH_QF_REPLAY;
	sfh_queue *q2; REQUIRE(sfh_queue_create(c, &p, &q2) == 0, "q2");
	d = rawdesc(q2, c_nop(5));
	d.dw[1] += 7;                             /* wrong seq */
	sfh_desc_seal(&d);
	pos = sfh_test_sq_tail(q2);
	sfh_test_write_slot(q2, pos, &d);
	sfh_test_adopt(q2, (uint16_t)(pos + 1), sfh_test_next_seq(q2) + 1);
	sfh_cmd tail2[2] = { c_nop(6), c_nop(7) };
	sfh_test_doorbell(q2, (uint16_t)(pos + 1));
	REQUIRE(sfh_submit(q2, tail2, 2, 0, NULL) == 0, "behind");
	n = drain_all(q2, r, 32);
	CHECK_EQ(n, 3);
	CHECK(n == 3 && r[0].status == SFH_ST_STALE_SEQ && r[1].status == 0 && r[2].status == 0 &&
	      (r[1].flags & SFH_CF_REPLAYED), "behind-stale: %s %s %s", sfh_status_str(r[0].status),
	      sfh_status_str(r[1].status), sfh_status_str(r[2].status));
	env_close(&e);
}

/* ================================================================== device-side validation */
static void t_validation(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_IRQ, 16, 0);
	sfh_buf *rb, *wb;
	REQUIRE(sfh_buf_alloc(c, 4096, SFH_BUF_DEV_READ, &rb) == 0, "rb");
	REQUIRE(sfh_buf_alloc(c, 4096, SFH_BUF_DEV_WRITE, &wb) == 0, "wb");
	/* each case is built right before it is published: every error resets the queue and
	 * moves it to a new epoch, so a descriptor built earlier would (correctly) be stale */
#define CASE(nm, cmd, mut, st) do { sfh_desc _d = rawdesc(q, cmd); mut; sfh_desc_seal(&_d); \
	sfh_completion _r = raw1(q, &_d); \
	CHECK(_r.status == (st), "%s: got %s want %s", nm, sfh_status_str(_r.status), sfh_status_str(st)); } while (0)
	uint64_t win = 1ull << SFH_WIN_LOG2;
	CASE("reserved dw2", c_nop(0), _d.dw[2] |= 1u << 20, SFH_ST_BAD_ARGS);
	CASE("bad opcode", c_nop(0), _d.dw[0] = (_d.dw[0] & ~0xff0000u) | (9u << 16), SFH_ST_BAD_OPCODE);
	CASE("bad flag", c_nop(0), _d.dw[0] |= 0x80u << 24, SFH_ST_BAD_ARGS);
	CASE("NOP with payload", c_nop(0), _d.dw[5] = 8, SFH_ST_BAD_ARGS);
	CASE("zero-length copy", c_h2d(rb, 0, 0, 8), _d.dw[5] = 0, SFH_ST_BAD_ARGS);
	CASE("handle out of range", c_h2d(rb, 0, 0, 8), _d.dw[4] = (_d.dw[4] & 0xffff0000u) | 40, SFH_ST_BAD_HANDLE);
	CASE("handle generation", c_h2d(rb, 0, 0, 8), _d.dw[4] += 1u << 16, SFH_ST_BAD_HANDLE);
	CASE("unmapped slot", c_h2d(rb, 0, 0, 8), _d.dw[4] = (_d.dw[4] & 0xffff0000u) | 30, SFH_ST_BAD_HANDLE);
	CASE("H2D from write-only", c_h2d(wb, 0, 0, 8), (void)0, SFH_ST_PERM);
	CASE("D2H into read-only", c_d2h(rb, 0, 0, 8), (void)0, SFH_ST_PERM);
	CASE("misaligned host off", c_h2d(rb, 0, 0, 8), _d.dw[6] = 4, SFH_ST_ALIGN);
	CASE("misaligned len", c_h2d(rb, 0, 0, 8), _d.dw[5] = 12, SFH_ST_ALIGN);
	CASE("host range past end", c_h2d(rb, 0, 0, 8), (_d.dw[6] = 4088, _d.dw[5] = 16), SFH_ST_BOUNDS);
	CASE("host offset overflow", c_h2d(rb, 0, 0, 8), (_d.dw[6] = 0xfffffff8u, _d.dw[7] = 0xffffffffu, _d.dw[5] = 16), SFH_ST_BOUNDS);
	CASE("window past end", c_h2d(rb, 0, 0, 8), (_d.dw[8] = (uint32_t)(win - 8), _d.dw[5] = 16), SFH_ST_BOUNDS);
	CASE("window offset overflow", c_h2d(rb, 0, 0, 8), (_d.dw[8] = 0xfffffff8u, _d.dw[9] = 0xffffffffu), SFH_ST_BOUNDS);
	CASE("kernel dst outside", c_kern(SFH_KOP_ADD32, 0, 0, 64, 1), _d.dw[10] = (uint32_t)(win - 32), SFH_ST_BOUNDS);
	CASE("kernel with handle", c_kern(SFH_KOP_ADD32, 0, 64, 64, 1), _d.dw[4] = 1, SFH_ST_BAD_ARGS);
	CASE("bad kop", c_kern(SFH_KOP_ADD32, 0, 64, 64, 1), _d.dw[14] = 7, SFH_ST_BAD_ARGS);
	CASE("wait target", c_wait(q, 1), _d.dw[14] = 9, SFH_ST_BAD_ARGS);
	CASE("fence not increasing", c_signal(1), _d.dw[12] = 0, SFH_ST_FENCE_ORDER);
	/* use-after-free of a handle: the slot is reused for a new buffer with a new generation */
	uint32_t stale_handle = sfh_test_handle(rb);
	sfh_buf_free(rb);
	sfh_buf *nb;
	REQUIRE(sfh_buf_alloc(c, 4096, SFH_BUF_DEV_READ, &nb) == 0, "nb");
	CHECK_EQ(sfh_test_handle(nb) & 0xffff, stale_handle & 0xffff);
	sfh_desc d = rawdesc(q, c_h2d(nb, 0, 0, 64));
	d.dw[4] = stale_handle;
	sfh_desc_seal(&d);
	CHECK(raw1(q, &d).status == SFH_ST_BAD_HANDLE, "stale handle after slot reuse must be refused");
	/* the library refuses the same mistakes before anything reaches the ring */
	sfh_cmd bad = c_h2d(wb, 0, 0, 8);
	CHECK_EQ(sfh_submit(q, &bad, 1, 0, NULL), -EPERM);
	bad = c_h2d(nb, 4090, 0, 8);
	CHECK_EQ(sfh_submit(q, &bad, 1, 0, NULL), -EINVAL);
	bad = c_h2d(nb, 0, win, 8);
	CHECK_EQ(sfh_submit(q, &bad, 1, 0, NULL), -EINVAL);
	bad = c_kern(9, 0, 0, 8, 0);
	CHECK_EQ(sfh_submit(q, &bad, 1, 0, NULL), -EINVAL);
	CHECK_EQ(run1(q, c_h2d(nb, 0, 0, 4096)).status, 0);
	sfh_dev_stats ds; sfh_dev_get_stats(e.d, &ds);
	CHECK_EQ(ds.engine_resets + ds.function_resets, 0);   /* validation errors only reset the queue */
	env_close(&e);
}

/* ================================================================== isolation */
static void t_isolation(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *a, *b;
	REQUIRE(sfh_ctx_open(e.d, &a) == 0 && sfh_ctx_open(e.d, &b) == 0, "ctx");
	sfh_queue *qa = mkq(a, SFH_NOTIFY_IRQ, 16, 0), *qb = mkq(b, SFH_NOTIFY_IRQ, 16, 0);
	sfh_buf *secret, *aout, *bbuf;
	REQUIRE(sfh_buf_alloc(a, 4096, SFH_BUF_DEV_READ, &secret) == 0, "secret");
	REQUIRE(sfh_buf_alloc(a, 4096, SFH_BUF_DEV_WRITE, &aout) == 0, "aout");
	REQUIRE(sfh_buf_alloc(b, 4096, SFH_BUF_DEV_READ | SFH_BUF_DEV_WRITE, &bbuf) == 0, "bbuf");
	memset(sfh_buf_ptr(secret), 0x5E, 4096);
	CHECK_EQ(run1(qa, c_h2d(secret, 0, 0x1000, 4096)).status, 0);   /* A's secret in A's window */
	/* B forges A's handle: refused by the owner check on the device */
	sfh_desc d = rawdesc(qb, c_h2d(bbuf, 0, 0, 4096));
	d.dw[4] = sfh_test_handle(secret);
	sfh_desc_seal(&d);
	CHECK(raw1(qb, &d).status == SFH_ST_PERM, "forged handle (read)");
	d = rawdesc(qb, c_d2h(bbuf, 0, 0, 4096));
	d.dw[4] = sfh_test_handle(aout);
	sfh_desc_seal(&d);
	CHECK(raw1(qb, &d).status == SFH_ST_PERM, "forged handle (write)");
	/* B cannot address A's device window: offsets are window-relative to B's context */
	memset(sfh_buf_ptr(bbuf), 0, 4096);
	CHECK_EQ(run1(qb, c_d2h(bbuf, 0, 0x1000, 4096)).status, 0);
	int leaked = 0;
	for (int i = 0; i < 4096; i++) leaked += ((uint8_t *)sfh_buf_ptr(bbuf))[i] == 0x5E;
	CHECK(leaked == 0, "%d bytes of A's window visible to B", leaked);
	/* library-level: foreign buffer / foreign queue are refused with EPERM */
	sfh_cmd bad = c_h2d(secret, 0, 0, 64);
	CHECK_EQ(sfh_submit(qb, &bad, 1, 0, NULL), -EPERM);
	bad = c_wait(qa, 1);
	CHECK_EQ(sfh_submit(qb, &bad, 1, 0, NULL), -EPERM);
	/* device-level cross-context fence wait */
	d = rawdesc(qb, c_wait(qb, 1));
	d.dw[14] = sfh_queue_id(qa);
	sfh_desc_seal(&d);
	CHECK(raw1(qb, &d).status == SFH_ST_PERM, "cross-context FENCE_WAIT");
	/* A unaffected by everything B did */
	CHECK_EQ(run1(qa, c_d2h(aout, 0, 0x1000, 4096)).status, 0);
	CHECK(memcmp(sfh_buf_ptr(aout), sfh_buf_ptr(secret), 4096) == 0, "A's data");
	check_clean(qa, "A");
	env_close(&e);
}

/* ================================================================== fences */
static void t_fence(void)
{
	env e;
	sfh_dev_params dp = fast_params();
	dp.fence_timeout_ns = 200 * US;
	REQUIRE(env_open_p(&e, NULL, &dp) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *qa = mkq(c, SFH_NOTIFY_IRQ, 32, 0), *qb = mkq(c, SFH_NOTIFY_IRQ, 32, 0);
	sfh_buf *src, *dst;
	REQUIRE(sfh_buf_alloc(c, 65536, SFH_BUF_DEV_READ, &src) == 0, "src");
	REQUIRE(sfh_buf_alloc(c, 65536, SFH_BUF_DEV_WRITE, &dst) == 0, "dst");
	fill_pattern(sfh_buf_ptr(src), 65536, 11);
	/* data written before a fence is visible once the fence value is observed */
	sfh_cmd cm[3] = { c_h2d(src, 0, 0, 65536), c_d2h(dst, 0, 0, 65536), c_signal(1) };
	cm[2].flags = SFH_FLAG_IRQ_NOW;
	REQUIRE(sfh_submit(qa, cm, 3, SFH_SUBMIT_COALESCE, NULL) == 0, "submit");
	CHECK_EQ(sfh_fence_wait(qa, 1, 50 * MS), 0);
	CHECK_EQ(sfh_fence_read(qa), 1);
	CHECK(memcmp(sfh_buf_ptr(src), sfh_buf_ptr(dst), 65536) == 0, "data not visible at fence");
	sfh_completion r[16];
	drain_all(qa, r, 16);
	/* non-increasing values are refused by the library */
	sfh_cmd s1 = c_signal(1);
	CHECK_EQ(sfh_submit(qa, &s1, 1, 0, NULL), -EINVAL);
	/* cross-queue wait: A waits for B's timeline; B signals after a long kernel */
	sfh_cmd wa[2] = { c_wait(qb, 5), c_nop(0xA) };
	uint64_t ta, tb;
	REQUIRE(sfh_submit(qa, wa, 2, 0, &ta) == 0, "wa");
	sfh_cmd sb[2] = { c_spin(60 * US), c_signal(5) };
	REQUIRE(sfh_submit(qb, sb, 2, 0, &tb) == 0, "sb");
	sfh_completion ca, cb;
	CHECK_EQ(sfh_wait_ticket(qa, ta + 1, 50 * MS, &ca), 0);
	CHECK_EQ(ca.status, 0);
	CHECK_EQ(sfh_wait_ticket(qb, tb + 1, 50 * MS, &cb), 0);
	sfh_sim_trace tra, trb;
	sfh_sim_trace_get(e.sim, sfh_queue_id(qa), ca.dev_seq - 1, &tra);
	sfh_sim_trace_get(e.sim, sfh_queue_id(qb), cb.dev_seq, &trb);
	CHECK(tra.t_end >= trb.t_end && trb.t_end > 0, "wait finished at %llu before signal at %llu",
	      (unsigned long long)tra.t_end, (unsigned long long)trb.t_end);
	uint32_t qst = sfh_test_mmio_rd(e.d, SFH_QREG(sfh_queue_id(qa), SFH_QSTATUS));
	CHECK(!(qst & (1u << SFH_QST_WAITING)), "still waiting");
	drain_all(qa, r, 16);
	drain_all(qb, r, 16);
	/* a parked FENCE_WAIT does not block other queues */
	sfh_cmd w99 = c_wait(qb, 99);
	uint64_t tw;
	REQUIRE(sfh_submit(qa, &w99, 1, 0, &tw) == 0, "w99");
	for (int i = 0; i < 5; i++) CHECK_EQ(run1(qb, c_nop(i)).status, 0);
	/* ...and times out on the device */
	sfh_completion cw;
	CHECK_EQ(sfh_wait_ticket(qa, tw, 50 * MS, &cw), 0);
	CHECK(cw.status == SFH_ST_FENCE_TIMEOUT, "fence wait: %s", sfh_status_str(cw.status));
	CHECK_EQ(run1(qa, c_nop(1)).status, 0);
	env_close(&e);
}

/* ================================================================== timeouts and recovery */
static void t_timeout(void)
{
	env e;
	sfh_dev_params dp = fast_params();
	dp.cmd_timeout_ns = 100 * US;
	REQUIRE(env_open_p(&e, NULL, &dp) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.host_timeout_ns = 400 * US;
	sfh_queue *q; REQUIRE(sfh_queue_create(c, &p, &q) == 0, "q");
	p.flags = SFH_QF_REPLAY;
	sfh_queue *qr; REQUIRE(sfh_queue_create(c, &p, &qr) == 0, "qr");
	/* 1. device watchdog: a 1 ms kernel with a 100 us watchdog; later commands are not executed */
	sfh_cmd cm[3] = { c_spin(1 * MS), c_nop(1), c_nop(2) };
	REQUIRE(sfh_submit(q, cm, 3, 0, NULL) == 0, "submit");
	sfh_completion r[8];
	unsigned n = drain_all(q, r, 8);
	CHECK(n == 3 && r[0].status == SFH_ST_TIMEOUT && r[1].status == SFH_CS_NOT_EXECUTED &&
	      r[2].status == SFH_CS_NOT_EXECUTED, "watchdog: n=%u %s %s %s", n, sfh_status_str(r[0].status),
	      sfh_status_str(r[1].status), sfh_status_str(r[2].status));
	/* ... and with REPLAY they run after the recovery */
	REQUIRE(sfh_submit(qr, cm, 3, 0, NULL) == 0, "submit");
	n = drain_all(qr, r, 8);
	CHECK(n == 3 && r[0].status == SFH_ST_TIMEOUT && r[1].status == 0 && r[2].status == 0 &&
	      (r[1].flags & SFH_CF_REPLAYED), "replay: n=%u %s %s", n, sfh_status_str(r[1].status), sfh_status_str(r[2].status));
	/* 2. hung execution unit: watchdog aborts it */
	sfh_sim_fault(e.sim, SFH_FI_KERNEL_HANG, 1);
	CHECK_EQ(run1(q, c_kern(SFH_KOP_ADD32, 0, 64, 64, 1)).status, SFH_ST_TIMEOUT);
	sfh_sim_fault(e.sim, SFH_FI_KERNEL_HANG, 0);
	CHECK_EQ(run1(q, c_nop(3)).status, 0);
	/* 3. watchdog disabled + hang: only the host's no-progress timeout notices; queue reset
	 *    recovers; the hung command is UNCERTAIN, the rest is replayed */
	sfh_test_mmio_wr(e.d, SFH_REG_CMD_TIMEOUT, 0);
	sfh_sim_fault(e.sim, SFH_FI_KERNEL_HANG, 1);
	sfh_cmd hc[3] = { c_kern(SFH_KOP_ADD32, 0, 64, 64, 1), c_nop(4), c_nop(5) };
	REQUIRE(sfh_submit(qr, hc, 3, 0, NULL) == 0, "submit");
	for (int i = 0; i < 3; i++) sfh_test_mmio_rd(e.d, SFH_REG_SCRATCH);
	sfh_sim_fault(e.sim, SFH_FI_KERNEL_HANG, 0);   /* the abort from the queue reset unsticks it */
	sfh_sim_fault(e.sim, SFH_FI_KERNEL_HANG, 1);
	n = drain_all(qr, r, 8);
	sfh_sim_fault(e.sim, SFH_FI_KERNEL_HANG, 0);
	CHECK(n == 3 && r[0].status == SFH_CS_UNCERTAIN && r[1].status == 0 && r[2].status == 0,
	      "host timeout: n=%u %s %s %s", n, sfh_status_str(r[0].status), sfh_status_str(r[1].status), sfh_status_str(r[2].status));
	sfh_queue_stats s; sfh_queue_get_stats(qr, &s);
	CHECK(s.host_timeouts >= 1 && s.uncertain == 1, "host timeouts=%llu uncertain=%llu",
	      (unsigned long long)s.host_timeouts, (unsigned long long)s.uncertain);
	sfh_test_mmio_wr(e.d, SFH_REG_CMD_TIMEOUT, (uint32_t)(100 * US));
	/* 4. frozen engine (queue reset cannot complete) -> escalation to an engine reset */
	sfh_buf *b; REQUIRE(sfh_buf_alloc(c, 4096, SFH_BUF_DEV_READ | SFH_BUF_DEV_WRITE, &b) == 0, "b");
	fill_pattern(sfh_buf_ptr(b), 4096, 5);
	CHECK_EQ(run1(q, c_h2d(b, 0, 0, 4096)).status, 0);
	sfh_sim_fault(e.sim, SFH_FI_FREEZE, 1);
	sfh_cmd f1[2] = { c_nop(6), c_nop(7) };
	REQUIRE(sfh_submit(qr, f1, 2, 0, NULL) == 0, "submit");
	n = drain_all(qr, r, 8);
	CHECK(n == 2 && r[0].status == 0 && r[1].status == 0, "after engine reset: n=%u %s %s", n,
	      sfh_status_str(r[0].status), sfh_status_str(r[1].status));
	sfh_dev_stats ds; sfh_dev_get_stats(e.d, &ds);
	CHECK(ds.engine_resets >= 1 && ds.escalations >= 1, "engine resets=%llu escalations=%llu",
	      (unsigned long long)ds.engine_resets, (unsigned long long)ds.escalations);
	/* device memory survived the engine reset */
	memset(sfh_buf_ptr(b), 0, 4096);
	CHECK_EQ(run1(q, c_d2h(b, 0, 0, 4096)).status, 0);
	uint8_t ref[4096]; fill_pattern(ref, 4096, 5);
	CHECK(memcmp(ref, sfh_buf_ptr(b), 4096) == 0, "devmem after engine reset");
	/* 5. hard freeze (only a function reset clears it) -> engine reset fails -> function reset;
	 *    the mapping table and queues are restored from the driver's shadow state */
	sfh_sim_fault(e.sim, SFH_FI_FREEZE, 2);
	REQUIRE(sfh_submit(qr, f1, 2, 0, NULL) == 0, "submit");
	n = drain_all(qr, r, 8);
	CHECK(n == 2, "after function reset n=%u", n);
	for (unsigned i = 0; i < n; i++)
		CHECK(r[i].status == 0 || r[i].status == SFH_CS_UNCERTAIN, "func reset outcome %s", sfh_status_str(r[i].status));
	sfh_dev_get_stats(e.d, &ds);
	CHECK(ds.function_resets >= 1 && !ds.dead, "function resets=%llu dead=%llu",
	      (unsigned long long)ds.function_resets, (unsigned long long)ds.dead);
	CHECK(sfh_ctx_devmem_lost(c) >= 1, "context must learn its device memory is gone");
	fill_pattern(sfh_buf_ptr(b), 4096, 6);
	memcpy(ref, sfh_buf_ptr(b), 4096);
	CHECK_EQ(run1(q, c_h2d(b, 0, 0x100, 4096)).status, 0);    /* old handle works: ATT restored */
	memset(sfh_buf_ptr(b), 0, 4096);
	sfh_completion rr = run1(q, c_d2h(b, 0, 0x100, 4096));
	CHECK_EQ(rr.status, 0);
	CHECK(rr.flags & SFH_CF_DEVMEM_LOST, "completion flag DEVMEM_LOST");
	CHECK(memcmp(ref, sfh_buf_ptr(b), 4096) == 0, "data after function reset");
	env_close(&e);
}

/* ================================================================== uncertain completion */
static void t_uncertain(void)
{
	env e;
	sfh_dev_params dp = fast_params();
	REQUIRE(env_open_p(&e, NULL, &dp) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.host_timeout_ns = 300 * US;
	sfh_queue *q; REQUIRE(sfh_queue_create(c, &p, &q) == 0, "q");
	sfh_buf *src, *dst;
	REQUIRE(sfh_buf_alloc(c, 1 << 19, SFH_BUF_DEV_READ, &src) == 0, "src");
	REQUIRE(sfh_buf_alloc(c, 1 << 19, SFH_BUF_DEV_WRITE, &dst) == 0, "dst");
	fill_pattern(sfh_buf_ptr(src), 1 << 19, 21);
	CHECK_EQ(run1(q, c_h2d(src, 0, 0, 1 << 19)).status, 0);
	/* (a) the CQE of a finished command is lost: the outcome comes from COMPLETED_SEQ */
	sfh_sim_fault(e.sim, SFH_FI_DROP_CQE, 1);
	sfh_completion r = run1(q, c_d2h(dst, 0, 0, 4096));
	CHECK(r.status == 0 && (r.flags & SFH_CF_RECOVERED), "lost CQE: %s flags=0x%x", sfh_status_str(r.status), r.flags);
	CHECK(memcmp(sfh_buf_ptr(src), sfh_buf_ptr(dst), 4096) == 0, "data of a recovered completion");
	/* ... and of a failed one: the status comes from the ERR latch */
	sfh_sim_fault(e.sim, SFH_FI_DROP_CQE, 1);
	sfh_desc d = rawdesc(q, c_nop(1));
	d.dw[5] = 8;  sfh_desc_seal(&d);              /* BAD_ARGS */
	uint16_t pos = sfh_test_sq_tail(q);
	sfh_test_write_slot(q, pos, &d);
	sfh_test_adopt(q, (uint16_t)(pos + 1), sfh_test_next_seq(q) + 1);
	sfh_test_doorbell(q, (uint16_t)(pos + 1));
	sfh_completion rs[8];
	unsigned n = drain_all(q, rs, 8);
	CHECK(n == 1 && rs[0].status == SFH_ST_BAD_ARGS && (rs[0].flags & SFH_CF_RECOVERED),
	      "lost error CQE: n=%u %s", n, n ? sfh_status_str(rs[0].status) : "-");
	/* (b) reset while a long transfer runs: it is UNCERTAIN, the commands behind it never ran */
	memset(sfh_buf_ptr(dst), 0, 1 << 19);
	sfh_cmd cm[3] = { c_d2h(dst, 0, 0, 1 << 19), c_nop(2), c_nop(3) };
	uint64_t t0;
	REQUIRE(sfh_submit(q, cm, 3, 0, &t0) == 0, "submit");
	unsigned qid = sfh_queue_id(q);
	uint32_t started = 0;
	for (int i = 0; i < 100; i++) {
		started = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QSTARTED_SEQ));
		if (started == sfh_test_next_seq(q) - 3) break;
	}
	CHECK_EQ(started, sfh_test_next_seq(q) - 3);
	REQUIRE(sfh_dev_engine_reset(e.d) == 0, "engine reset");
	n = drain_all(q, rs, 8);
	CHECK(n == 3 && rs[0].status == SFH_CS_UNCERTAIN && rs[1].status == SFH_CS_NOT_EXECUTED &&
	      rs[2].status == SFH_CS_NOT_EXECUTED, "reset mid-transfer: n=%u %s %s %s", n,
	      sfh_status_str(rs[0].status), sfh_status_str(rs[1].status), sfh_status_str(rs[2].status));
	/* partial data really is partial: some but not all of the 512 KiB arrived */
	size_t same = 0;
	for (size_t i = 0; i < (1u << 19); i += 4096)
		same += memcmp((uint8_t *)sfh_buf_ptr(src) + i, (uint8_t *)sfh_buf_ptr(dst) + i, 4096) == 0;
	CHECK(same > 0 && same < (1u << 19) / 4096, "UNCERTAIN transfer should be partial (%zu/128 pages)", same);
	/* (c) an interrupt lost AND completion lost while armed */
	sfh_sim_fault(e.sim, SFH_FI_DROP_CQE, 1);
	sfh_sim_fault(e.sim, SFH_FI_DROP_MSI, 1);
	r = run1(q, c_nop(9));
	CHECK(r.status == 0 && (r.flags & SFH_CF_RECOVERED), "lost CQE+MSI: %s", sfh_status_str(r.status));
	CHECK_EQ(run1(q, c_nop(10)).status, 0);
	env_close(&e);
}

/* ================================================================== process termination */
static void t_proc_term(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *a, *b;
	REQUIRE(sfh_ctx_open(e.d, &a) == 0 && sfh_ctx_open(e.d, &b) == 0, "ctx");
	unsigned a_id_probe = 0;
	(void)a_id_probe;
	sfh_queue *qa = mkq(a, SFH_NOTIFY_IRQ, 32, 0);
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.notify = SFH_NOTIFY_POLL; p.sq_entries = p.cq_entries = 64;
	sfh_queue *qb; REQUIRE(sfh_queue_create(b, &p, &qb) == 0, "qb");
	sfh_queue *qa2 = mkq(a, SFH_NOTIFY_IRQ, 16, 0);
	sfh_buf *secret, *out, *bb;
	REQUIRE(sfh_buf_alloc(a, 65536, SFH_BUF_DEV_READ, &secret) == 0, "secret");
	REQUIRE(sfh_buf_alloc(a, 1 << 19, SFH_BUF_DEV_WRITE, &out) == 0, "out");
	REQUIRE(sfh_buf_alloc(b, 8192, SFH_BUF_DEV_READ | SFH_BUF_DEV_WRITE, &bb) == 0, "bb");
	memset(sfh_buf_ptr(secret), 0xA7, 65536);
	CHECK_EQ(run1(qa, c_h2d(secret, 0, 0x4000, 65536)).status, 0);
	/* A: long transfers into its own memory + a parked fence wait + an armed interrupt */
	sfh_cmd am[4] = { c_d2h(out, 0, 0, 1 << 19), c_spin(200 * US), c_d2h(out, 0, 0, 1 << 19), c_nop(1) };
	REQUIRE(sfh_submit(qa, am, 4, 0, NULL) == 0, "A work");
	sfh_cmd aw = c_wait(qa, 1000);
	REQUIRE(sfh_submit(qa2, &aw, 1, 0, NULL) == 0, "A wait");
	/* B: steady stream */
	fill_pattern(sfh_buf_ptr(bb), 8192, 8);
	uint8_t ref[8192]; memcpy(ref, sfh_buf_ptr(bb), 8192);
	sfh_cmd bm[8];
	for (int i = 0; i < 8; i++) bm[i] = (i & 1) ? c_d2h(bb, 4096, 0x200, 4096) : c_h2d(bb, 0, 0x200, 4096);
	REQUIRE(sfh_submit(qb, bm, 8, 0, NULL) == 0, "B work");
	uint32_t started = 0;
	for (int i = 0; i < 200 && started != sfh_test_next_seq(qa) - 4; i++)
		started = sfh_test_mmio_rd(e.d, SFH_QREG(sfh_queue_id(qa), SFH_QSTARTED_SEQ));
	CHECK(started == sfh_test_next_seq(qa) - 4, "A's transfer should be running when it dies");
	/* A dies: no cooperation from A */
	sfh_ctx_kill(a);
	CHECK_EQ(env_violations(&e), 0);
	/* B never noticed */
	sfh_completion r[64];
	unsigned n = drain_all(qb, r, 64);
	CHECK_EQ(n, 8);
	for (unsigned i = 0; i < n; i++) CHECK_EQ(r[i].status, 0);
	CHECK(memcmp(ref, (uint8_t *)sfh_buf_ptr(bb) + 4096, 4096) == 0, "B data");
	for (int round = 0; round < 10; round++) {
		REQUIRE(sfh_submit(qb, bm, 8, SFH_SUBMIT_COALESCE, NULL) == 0, "B more");
		CHECK_EQ(drain_all(qb, r, 64), 8);
	}
	check_clean(qb, "B");
	sfh_dev_stats ds; sfh_dev_get_stats(e.d, &ds);
	CHECK_EQ(ds.engine_resets + ds.function_resets, 0);   /* A's release did not reset the device */
	/* C reuses A's context slot: the window was scrubbed */
	sfh_ctx *cc; REQUIRE(sfh_ctx_open(e.d, &cc) == 0, "ctx C");
	sfh_queue *qc = mkq(cc, SFH_NOTIFY_IRQ, 16, 0);
	sfh_buf *cb; REQUIRE(sfh_buf_alloc(cc, 65536, SFH_BUF_DEV_WRITE | SFH_BUF_DEV_READ, &cb) == 0, "cb");
	memset(sfh_buf_ptr(cb), 0x11, 65536);
	CHECK_EQ(run1(qc, c_d2h(cb, 0, 0x4000, 65536)).status, 0);
	int leaked = 0, nonzero = 0;
	for (int i = 0; i < 65536; i++) {
		uint8_t v = ((uint8_t *)sfh_buf_ptr(cb))[i];
		leaked += v == 0xA7; nonzero += v != 0;
	}
	CHECK(leaked == 0 && nonzero == 0, "previous owner's data visible: leaked=%d nonzero=%d", leaked, nonzero);
	/* C publishes a slot it never wrote (ring memory may be A's old, poisoned ring) */
	uint16_t pos = sfh_test_sq_tail(qc);
	sfh_test_adopt(qc, (uint16_t)(pos + 1), sfh_test_next_seq(qc) + 1);
	sfh_test_doorbell(qc, (uint16_t)(pos + 1));
	n = drain_all(qc, r, 8);
	CHECK(n == 1 && r[0].status != 0, "unwritten slot must not execute (%s)", n ? sfh_status_str(r[0].status) : "-");
	CHECK_EQ(run1(qc, c_nop(1)).status, 0);
	/* orderly close of B with work in flight */
	REQUIRE(sfh_submit(qb, bm, 8, 0, NULL) == 0, "B last");
	CHECK_EQ(sfh_ctx_close(b), 0);
	env_close(&e);
}

/* ================================================================== mapping revocation */
static void t_revoke(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_IRQ, 16, 0);
	sfh_buf *out, *in;
	REQUIRE(sfh_buf_alloc(c, 1 << 19, SFH_BUF_DEV_WRITE, &out) == 0, "out");
	REQUIRE(sfh_buf_alloc(c, 1 << 19, SFH_BUF_DEV_READ, &in) == 0, "in");
	uint32_t hout = sfh_test_handle(out);
	(void)hout;
	/* free a buffer while a D2H into it is running: the device stops, memory is released only
	 * after the sync, and the command reports MAP_REVOKED */
	sfh_cmd cm = c_d2h(out, 0, 0, 1 << 19);
	uint64_t t;
	REQUIRE(sfh_submit(q, &cm, 1, 0, &t) == 0, "submit");
	uint32_t started = 0;
	for (int i = 0; i < 100 && started != sfh_test_next_seq(q) - 1; i++)
		started = sfh_test_mmio_rd(e.d, SFH_QREG(sfh_queue_id(q), SFH_QSTARTED_SEQ));
	CHECK_EQ(sfh_buf_free(out), 0);
	CHECK_EQ(env_violations(&e), 0);
	sfh_completion r;
	CHECK_EQ(sfh_wait_ticket(q, t, 50 * MS, &r), 0);
	CHECK(r.status == SFH_ST_MAP_REVOKED, "D2H into revoked mapping: %s", sfh_status_str(r.status));
	/* same for H2D from a revoked mapping */
	cm = c_h2d(in, 0, 0, 1 << 19);
	REQUIRE(sfh_submit(q, &cm, 1, 0, &t) == 0, "submit");
	for (int i = 0; i < 3; i++) sfh_test_mmio_rd(e.d, SFH_REG_SCRATCH);
	CHECK_EQ(sfh_buf_free(in), 0);
	CHECK_EQ(sfh_wait_ticket(q, t, 50 * MS, &r), 0);
	CHECK(r.status == SFH_ST_MAP_REVOKED || r.status == SFH_ST_BAD_HANDLE || r.status == 0,
	      "H2D from revoked mapping: %s", sfh_status_str(r.status));
	CHECK_EQ(run1(q, c_nop(1)).status, 0);
	env_close(&e);
}

/* ================================================================== CQ back-pressure */
static void t_cq_full(void)
{
	env e;
	REQUIRE(env_open(&e) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.notify = SFH_NOTIFY_POLL; p.sq_entries = 64; p.cq_entries = 16;
	sfh_queue *q; REQUIRE(sfh_queue_create(c, &p, &q) == 0, "q");
	unsigned qid = sfh_queue_id(q);
	sfh_cmd cm[40];
	for (int i = 0; i < 40; i++) cm[i] = c_nop(i);
	uint64_t t;
	REQUIRE(sfh_submit(q, cm, 40, 0, &t) == 0, "submit");
	for (int i = 0; i < 30; i++) sfh_test_mmio_rd(e.d, SFH_REG_SCRATCH);   /* host does not consume */
	uint32_t cqpos = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QCQPOS));
	uint32_t sqpos = sfh_test_mmio_rd(e.d, SFH_QREG(qid, SFH_QSQPOS));
	CHECK_EQ((uint16_t)((cqpos >> 16) - (cqpos & 0xffff)), 16);   /* CQ full ... */
	CHECK_EQ(sqpos & 0xffff, 16);                                    /* ... and the queue stalled */
	sfh_completion r[64];
	unsigned n = drain_all(q, r, 64);
	CHECK_EQ(n, 40);
	for (unsigned i = 0; i < n; i++) { CHECK_EQ(r[i].ticket, t + i); CHECK_EQ(r[i].status, 0); }
	check_clean(q, "cq_full");
	env_close(&e);
}

/* ================================================================== notification modes */
static unsigned mode_run(sfh_notify nm, uint32_t icnt, uint32_t itime, uint32_t flags, unsigned sflags,
                         uint64_t *irqs, uint64_t *lat_ns, uint32_t *digest)
{
	env e;
	if (env_open(&e)) return 0;
	sfh_ctx *c; sfh_ctx_open(e.d, &c);
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.notify = nm; p.imod_count = icnt; p.imod_time_ns = itime; p.flags = flags;
	p.sq_entries = p.cq_entries = 64; p.host_timeout_ns = 5 * MS;
	sfh_queue *q; sfh_queue_create(c, &p, &q);
	sfh_buf *b; sfh_buf_alloc(c, 65536, SFH_BUF_DEV_READ | SFH_BUF_DEV_WRITE, &b);
	fill_pattern(sfh_buf_ptr(b), 32768, 17);
	unsigned got = 0;
	uint32_t dg = 0;
	for (int round = 0; round < 4; round++) {
		sfh_cmd cm[32];
		for (int i = 0; i < 32; i++) {
			uint64_t slot = (uint64_t)(i / 4) * 8192;
			cm[i] = (i % 4 == 0) ? c_h2d(b, (uint64_t)(i / 4) * 4096, slot, 4096)
			      : (i % 4 == 1) ? c_kern(SFH_KOP_ADD32, slot, slot + 4096, 4096, (uint32_t)round)
			      : (i % 4 == 2) ? c_kern(SFH_KOP_SUM32, slot + 4096, 0, 4096, 0)
			      : c_d2h(b, 32768, slot + 4096, 4096);
		}
		sfh_submit(q, cm, 32, sflags, NULL);
		sfh_completion r[64];
		unsigned n = drain_all(q, r, 64);
		got += n;
		/* a coalesced command has no CQE, so it has no result value either */
		for (unsigned i = 0; i < n; i++)
			dg = dg * 31 + r[i].status * 7 + ((sflags & SFH_SUBMIT_COALESCE) ? 0 : r[i].result);
		for (int i = 0; i < 4096; i++) dg = dg * 31 + ((uint8_t *)sfh_buf_ptr(b))[32768 + i];
	}
	sfh_queue_stats s; sfh_queue_get_stats(q, &s);
	*irqs = s.irqs;                     /* interrupts of the streaming phase */
	/* QD1 latency */
	uint64_t t0 = e.tp->ops->now_ns(e.tp->ctx);
	for (int i = 0; i < 10; i++) {
		sfh_cmd one = c_nop((uint32_t)i);
		uint64_t t;
		sfh_completion r1;
		CHECK(sfh_submit(q, &one, 1, sflags & SFH_SUBMIT_IRQ_LAST, &t) == 0, "qd1 submit");
		CHECK(sfh_wait_ticket(q, t, 100 * MS, &r1) == 0 && r1.status == 0, "qd1 wait");
	}
	*lat_ns = (e.tp->ops->now_ns(e.tp->ctx) - t0) / 10;
	sfh_queue_get_stats(q, &s);
	CHECK(s.host_timeouts == 0 && s.recoveries == 0, "mode %d: host_timeouts=%llu recoveries=%llu", nm,
	      (unsigned long long)s.host_timeouts, (unsigned long long)s.recoveries);
	/* fault-free: every wakeup is a real interrupt; no completion may wait for a timed wakeup */
	CHECK(s.timer_wakeups == 0 && s.lost_irq_recovered == 0, "mode %d icnt %u: timer wakeups=%llu lost=%llu",
	      nm, icnt, (unsigned long long)s.timer_wakeups, (unsigned long long)s.lost_irq_recovered);
	CHECK(s.anomaly_torn == 0 && s.anomaly_stale == 0, "mode anomalies");
	*digest = dg;
	env_close(&e);
	return got;
}

static void t_modes(void)
{
	uint64_t irq[7], lat[7];
	uint32_t dg[7];
	unsigned n[7];
	n[0] = mode_run(SFH_NOTIFY_IRQ, 0, 0, 0, 0, &irq[0], &lat[0], &dg[0]);
	n[1] = mode_run(SFH_NOTIFY_POLL, 0, 0, 0, 0, &irq[1], &lat[1], &dg[1]);
	n[2] = mode_run(SFH_NOTIFY_HYBRID, 0, 0, 0, 0, &irq[2], &lat[2], &dg[2]);
	n[3] = mode_run(SFH_NOTIFY_IRQ, 16, 20000, 0, 0, &irq[3], &lat[3], &dg[3]);
	n[4] = mode_run(SFH_NOTIFY_IRQ, 16, 20000, 0, SFH_SUBMIT_IRQ_LAST, &irq[4], &lat[4], &dg[4]);
	n[5] = mode_run(SFH_NOTIFY_IRQ, 0, 0, SFH_QF_DIRECT, 0, &irq[5], &lat[5], &dg[5]);
	n[6] = mode_run(SFH_NOTIFY_IRQ, 0, 0, 0, SFH_SUBMIT_COALESCE, &irq[6], &lat[6], &dg[6]);
	for (int i = 0; i < 6; i++) {
		CHECK_EQ(n[i], 128);
		CHECK(dg[i] == dg[0], "mode %d produced different results", i);
	}
	CHECK_EQ(n[6], 128);
	CHECK_EQ(irq[1], 0);                                  /* polling: no interrupts at all */
	CHECK(irq[3] * 2 <= irq[0], "count moderation should at least halve interrupts: %llu vs %llu",
	      (unsigned long long)irq[3], (unsigned long long)irq[0]);
	CHECK(irq[6] <= 4, "coalesced batches: %llu interrupts for 4 batches", (unsigned long long)irq[6]);
	/* QD1 under count moderation waits for the timer: latency >= the 20 us timer ... */
	CHECK(lat[3] >= 20000 && lat[3] > 3 * lat[0], "moderated QD1 latency %llu vs %llu",
	      (unsigned long long)lat[3], (unsigned long long)lat[0]);
	/* ... but no more than the timer plus the normal path: the timer really fires */
	CHECK(lat[3] < 20000 + 2 * lat[0], "moderated QD1 latency %llu: moderation timer did not fire",
	      (unsigned long long)lat[3]);
	CHECK(lat[4] < 2 * lat[0], "IRQ_NOW on the last command should bypass moderation: %llu vs %llu",
	      (unsigned long long)lat[4], (unsigned long long)lat[0]);
	CHECK(lat[1] < lat[0], "polling latency %llu should beat interrupts %llu",
	      (unsigned long long)lat[1], (unsigned long long)lat[0]);
	CHECK(lat[5] < lat[0], "direct submission latency %llu should beat the syscall path %llu",
	      (unsigned long long)lat[5], (unsigned long long)lat[0]);
}

/* ================================================================== CQE ordering (fine-grained polling) */
static void t_ordering(void)
{
	env e;
	/* poll every 1 ns so the host frequently observes the CQ in the middle of a CQE write */
	REQUIRE(env_open_p(&e, "poll_iter_ns=1,cqe_cpu_ns=1", NULL) == 0, "dev_open");
	sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	sfh_queue *q = mkq(c, SFH_NOTIFY_POLL, 16, 0);
	uint64_t got = 0;
	for (int round = 0; round < 300; round++) {
		sfh_cmd cm[16];
		for (int i = 0; i < 16; i++) cm[i] = c_nop((uint32_t)(round * 16 + i));
		REQUIRE(sfh_submit(q, cm, 16, 0, NULL) == 0, "submit");
		sfh_completion r[32];
		unsigned n = drain_all(q, r, 32);
		for (unsigned i = 0; i < n; i++) { CHECK_EQ(r[i].status, 0); CHECK_EQ(r[i].user_tag, got); got++; }
	}
	CHECK_EQ(got, 4800);
	check_clean(q, "ordering");
	env_close(&e);

	/* interrupt ordering: with a zero-latency interrupt path the host reads the CQ the instant
	 * the message lands, so an interrupt that overtakes its CQE shows up as a spurious wakeup */
	REQUIRE(env_open_p(&e, "msi_to_isr_ns=0,wakeup_lat_ns=0,isr_cpu_ns=0,ctxsw_cpu_ns=0", NULL) == 0, "dev_open");
	REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
	q = mkq(c, SFH_NOTIFY_IRQ, 16, 0);
	for (int i = 0; i < 100; i++) CHECK_EQ(run1(q, c_nop((uint32_t)i)).status, 0);
	for (int round = 0; round < 30; round++) {
		sfh_cmd cm[8];
		for (int i = 0; i < 8; i++) cm[i] = (i & 1) ? c_spin(300) : c_nop((uint32_t)i);
		REQUIRE(sfh_submit(q, cm, 8, 0, NULL) == 0, "submit");
		sfh_completion r[16];
		CHECK_EQ(drain_all(q, r, 16), 8);
	}
	sfh_queue_stats st; sfh_queue_get_stats(q, &st);
	CHECK(st.irqs >= 100, "irqs=%llu", (unsigned long long)st.irqs);
	CHECK(st.spurious_irqs == 0, "interrupt arrived before its completion was visible (%llu spurious)",
	      (unsigned long long)st.spurious_irqs);
	check_clean(q, "irq ordering");
	env_close(&e);
}

/* ================================================================== co-sim determinism */
static uint64_t skip_scenario(int skip, uint64_t *host_ns, uint64_t *stepped)
{
	env e;
	sfh_dev_params dp = fast_params();
	if (env_open_p(&e, NULL, &dp)) return 0;
	sfh_sim_set_skip(e.sim, skip);
	sfh_ctx *c; sfh_ctx_open(e.d, &c);
	sfh_queue_params p; sfh_queue_params_default(&p);
	p.imod_count = 4; p.imod_time_ns = 7000;
	sfh_queue *q; sfh_queue_create(c, &p, &q);
	sfh_queue *q2 = mkq(c, SFH_NOTIFY_HYBRID, 32, 0);
	sfh_buf *b; sfh_buf_alloc(c, 65536, 3, &b);
	fill_pattern(sfh_buf_ptr(b), 65536, 1);
	sfh_cmd cm[6] = { c_h2d(b, 0, 0, 32768), c_spin(15000), c_kern(SFH_KOP_SUM32, 0, 0, 32768, 0),
	                  c_d2h(b, 32768, 0, 32768), c_signal(3), c_nop(1) };
	sfh_submit(q, cm, 6, 0, NULL);
	sfh_cmd w[2] = { c_wait(q, 3), c_spin(4000) };
	sfh_submit(q2, w, 2, 0, NULL);
	sfh_completion r[16];
	drain_all(q, r, 16);
	drain_all(q2, r, 16);
	for (int i = 0; i < 5; i++) run1(q, c_nop(i));
	sfh_sim_stats s; sfh_sim_get_stats(e.sim, &s);
	*host_ns = s.host_ns;
	*stepped = s.cycles_stepped;
	uint64_t h = sfh_sim_trace_hash(e.sim);
	env_close(&e);
	return h;
}

static void t_skip_equiv(void)
{
	uint64_t h0, h1, t0, t1, s0, s1;
	h1 = skip_scenario(1, &t1, &s1);
	h0 = skip_scenario(0, &t0, &s0);
	CHECK(h0 == h1, "idle-skipping changed device behaviour: hash %016llx vs %016llx",
	      (unsigned long long)h0, (unsigned long long)h1);
	CHECK_EQ(t0, t1);
	CHECK(s1 < s0, "skipping should step fewer cycles (%llu vs %llu)", (unsigned long long)s1, (unsigned long long)s0);
}

/* ================================================================== randomized stress */
static void t_stress(void)
{
	for (unsigned seed = 1; seed <= 6; seed++) {
		env e;
		sfh_dev_params dp = fast_params();
		REQUIRE(env_open_p(&e, NULL, &dp) == 0, "dev_open");
		sfh_ctx *c; REQUIRE(sfh_ctx_open(e.d, &c) == 0, "ctx");
		sfh_queue_params p; sfh_queue_params_default(&p);
		p.sq_entries = p.cq_entries = 32;
		p.notify = (sfh_notify)(seed % 3);
		if (seed & 1) { p.imod_count = 4; p.imod_time_ns = 5000; }
		p.host_timeout_ns = 2 * MS;
		sfh_queue *q; REQUIRE(sfh_queue_create(c, &p, &q) == 0, "q");
		sfh_buf *b; REQUIRE(sfh_buf_alloc(c, 65536, 3, &b) == 0, "b");
		static uint8_t model[65536];       /* reference model of the first 64 KiB of the window */
		memset(model, 0, sizeof(model));
		CHECK_EQ(run1(q, c_h2d(b, 0, 0, 65536)).status, 0);   /* b is zero */
		uint32_t x = seed * 7919u;
		uint64_t issued = 0, done = 0, first = 0, bad = 0;
		sfh_sim_fault(e.sim, SFH_FI_DUP_MSI, 20);
		sfh_sim_fault(e.sim, SFH_FI_DUP_CQE, 20);
		for (int it = 0; it < 120; it++) {
			x ^= x << 13; x ^= x >> 17; x ^= x << 5;
			unsigned nb = 1 + x % 8;
			sfh_cmd cm[8];
			for (unsigned i = 0; i < nb; i++) {
				x ^= x << 13; x ^= x >> 17; x ^= x << 5;
				uint64_t off = (uint64_t)(x % 15) * 4096;
				uint32_t len = 8 * (1 + (x >> 8) % 512);
				switch ((x >> 20) % 5) {
				case 0: {  /* H2D from the host staging area (only reused once idle) */
					uint8_t *hp = (uint8_t *)sfh_buf_ptr(b) + 32768;
					while (sfh_queue_inflight(q)) {
						sfh_completion rr[32];
						int k = sfh_wait_any(q, 50 * MS, rr, 32);
						if (k <= 0) break;
						for (int j = 0; j < k; j++) { if (rr[j].ticket != first + done || rr[j].status) bad++; done++; }
					}
					fill_pattern(hp, len, x);
					uint64_t doff = off % 32768;
					cm[i] = c_h2d(b, 32768, doff, len);
					memcpy(model + doff, hp, len);
					/* later H2Ds in the batch would overwrite hp: keep one per batch */
					for (unsigned k = i + 1; k < nb; k++) cm[k] = c_nop(k);
					i = nb;
					continue;
				}
				case 1: {
					uint64_t doff = off % 32768;
					cm[i] = c_kern(SFH_KOP_ADD32, doff, doff, len, x & 0xff);
					for (uint32_t k = 0; k < len; k += 4) {
						uint32_t v; memcpy(&v, model + doff + k, 4); v += x & 0xff; memcpy(model + doff + k, &v, 4);
					}
					break;
				}
				case 2: cm[i] = c_spin(x % 3000); break;
				case 3: cm[i] = c_nop(x); break;
				default: cm[i] = c_kern(SFH_KOP_XOR64, off % 32768, off % 32768, len, 0x0101010101010101ull * (x & 0xff));
					{ uint64_t doff = off % 32768;
					  for (uint32_t k = 0; k < len; k++) model[doff + k] ^= (uint8_t)(x & 0xff); }
					break;
				}
			}
			uint64_t t;
			int rc = sfh_submit(q, cm, nb, (x & 1) ? SFH_SUBMIT_COALESCE : 0, &t);
			if (rc == -EAGAIN) { sfh_completion r[32]; int k = sfh_wait_any(q, 50 * MS, r, 32); done += k > 0 ? (unsigned)k : 0; it--; continue; }
			CHECK(rc == 0, "submit rc=%d", rc);
			if (!issued) first = t;
			issued += nb;
			if (x & 0x40) sfh_test_doorbell(q, sfh_test_sq_tail(q));   /* stray duplicate doorbell */
			sfh_completion r[32];
			int k = sfh_reap(q, r, 32);
			for (int i = 0; i < k; i++) { if (r[i].ticket != first + done || r[i].status) bad++; done++; }
		}
		sfh_completion r[64];
		unsigned n;
		while ((n = drain_all(q, r, 64)) > 0)
			for (unsigned i = 0; i < n; i++) { if (r[i].ticket != first + done || r[i].status) bad++; done++; }
		CHECK_EQ(done, issued);
		CHECK_EQ(bad, 0);
		/* compare the device window against the model */
		memset(sfh_buf_ptr(b), 0, 32768);
		CHECK_EQ(run1(q, c_d2h(b, 0, 0, 32768)).status, 0);
		CHECK(memcmp(model, sfh_buf_ptr(b), 32768) == 0, "seed %u: device memory differs from model", seed);
		sfh_queue_stats s; sfh_queue_get_stats(q, &s);
		CHECK(s.recoveries == 0, "seed %u: recoveries=%llu", seed, (unsigned long long)s.recoveries);
		env_close(&e);
	}
}

/* ================================================================== registry */
typedef struct { const char *name; void (*fn)(void); const char *what; } test_t;
static const test_t TESTS[] = {
	{"probe",       t_probe,      "discovery, version/limits, config refused while enabled"},
	{"basic",       t_basic,      "NOP, H2D/D2H round trip, kernel ops, 4 KiB-crossing copies"},
	{"batch",       t_batch,      "one doorbell per batch, burst fetch, coalesced CQEs, all-or-nothing"},
	{"wraparound",  t_wraparound, "70k cmds on a 16-entry ring: positions, phase and 32-bit seq wrap"},
	{"doorbell",    t_doorbell,   "duplicate / backwards / over-capacity / disabled-queue doorbells"},
	{"irq",         t_irq,        "duplicate and lost interrupt messages, arm race"},
	{"cqe_dup",     t_cqe_dup,    "duplicated completion entries are rejected, nothing completes twice"},
	{"stale",       t_stale,      "stale slot, old epoch, torn, v1-format, unknown version descriptors"},
	{"validation",  t_validation, "device-side validation of every descriptor field; stale handles"},
	{"isolation",   t_isolation,  "forged handles, device windows, cross-context waits"},
	{"fence",       t_fence,      "signal visibility, cross-queue wait, wait timeout, no head-of-line block"},
	{"timeout",     t_timeout,    "watchdog, hung unit, host no-progress timeout, engine+function escalation"},
	{"uncertain",   t_uncertain,  "lost CQE / lost MSI / reset mid-transfer classification"},
	{"proc_term",   t_proc_term,  "process killed mid-DMA: release path, other process unaffected, scrub"},
	{"revoke",      t_revoke,     "buffer freed while the device uses it"},
	{"cq_full",     t_cq_full,    "CQ back-pressure: the device never overwrites an unconsumed CQE"},
	{"modes",       t_modes,      "IRQ / poll / hybrid / moderation / direct: identical results"},
	{"ordering",    t_ordering,   "CQE write order observed by a 1 ns poller: no torn entries"},
	{"skip_equiv",  t_skip_equiv, "co-sim idle skipping is exact (same trace hash and timing)"},
	{"stress",      t_stress,     "random batches/ops/modes with dup MSI/CQE/doorbells vs a memory model"},
};

int main(int argc, char **argv)
{
	const char *sel = argc > 1 ? argv[1] : "all";
	int ran = 0, failed_tests = 0;
	printf("sfh_tests: RTL mutant %d, host mutant %d\n", sfh_sim_mutant(), sfh_runtime_mutant());
	for (size_t i = 0; i < sizeof(TESTS) / sizeof(TESTS[0]); i++) {
		if (strcmp(sel, "all")) {
			char pat[64];
			snprintf(pat, sizeof(pat), ",%s,", TESTS[i].name);
			char list[512];
			snprintf(list, sizeof(list), ",%s,", sel);
			if (!strstr(list, pat)) continue;
		}
		g_test = TESTS[i].name;
		int f0 = g_fails, c0 = g_checks;
		TESTS[i].fn();
		ran++;
		int f = g_fails - f0;
		if (f) failed_tests++;
		printf("%-12s %-4s %5d checks  %s\n", TESTS[i].name, f ? "FAIL" : "ok", g_checks - c0, TESTS[i].what);
		fflush(stdout);
	}
	printf("TEST_RESULT %s tests=%d failed=%d checks=%d failed_checks=%d\n",
	       (g_fails || !ran) ? "FAIL" : "PASS", ran, failed_tests, g_checks, g_fails);
	return (g_fails || !ran) ? 1 : 0;
}
