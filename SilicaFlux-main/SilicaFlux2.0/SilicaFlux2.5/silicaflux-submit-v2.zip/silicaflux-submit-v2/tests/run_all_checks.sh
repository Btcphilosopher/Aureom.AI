#!/bin/bash
# SPDX-License-Identifier: MIT
# Every check, from a clean build; logs go to results/evidence/. Exit status 0 only if all pass.
set -uo pipefail
cd "$(dirname "$0")/.."
EV=results/evidence
mkdir -p "$EV"
rc=0
step() { # name, command...
  local name=$1; shift
  local t0=$(date +%s)
  if "$@" > "$EV/$name.log" 2>&1; then r=PASS; else r=FAIL; rc=1; fi
  printf "%-10s %s  (%ss)\n" "$name" "$r" "$(( $(date +%s) - t0 ))" | tee -a "$EV/summary.txt"
}
: > "$EV/summary.txt"
{ echo "host: $(uname -srm)"; verilator --version; gcc --version | head -1; python3 --version; date -u; } > "$EV/toolchain.txt" 2>&1
make clean > /dev/null 2>&1
step spec     make check-gen
step lint     make lint
step tests    make test
step adapter  make adapter
step vfio     make vfio
step example  make example
step mutants  make mutants
[ $rc -eq 0 ] && echo "ALL CHECKS PASS" | tee -a "$EV/summary.txt" || echo "SOME CHECKS FAILED" | tee -a "$EV/summary.txt"
exit $rc
