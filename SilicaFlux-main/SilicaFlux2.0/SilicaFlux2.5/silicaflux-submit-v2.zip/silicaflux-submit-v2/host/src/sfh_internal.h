/* SPDX-License-Identifier: MIT */
/* SilicaFlux HSI v2 host runtime — internal structures shared by the driver and user layers. */
#ifndef SFH_INTERNAL_H
#define SFH_INTERNAL_H
#include <errno.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "sfh.h"

/*
 * SFH_HOST_MUTANT (verification only; 0 in any real build). Each value breaks one host-side
 * rule of docs/CONTRACT.md; tests/run_mutants.sh requires the suite to fail for each:
 *   1 no wmb() between descriptor stores and the doorbell            (rule O1)
 *   2 accept CQEs without the sequence-window check                  (duplicate notifications)
 *   3 free a buffer's memory before the ATT sync acknowledges         (rule O11)
 *   4 re-enable a queue after reset without a new epoch               (rule O13)
 *   5 classify "started but not completed" as completed              (uncertain completion)
 */
#ifndef SFH_HOST_MUTANT
#define SFH_HOST_MUTANT 0
#endif

#define SFH_MAXQ   8
#define SFH_MAXCTX 16
#define SFH_MAXATT 64

typedef struct sfh_slot {
	sfh_cmd  cmd;          /* original request (re-encoded on replay) */
	uint64_t ticket, t_submit;
	uint32_t seq;
	uint8_t  dflags;       /* flags as written into the descriptor */
	uint8_t  replayed;
} sfh_slot;

struct sfh_buf {
	sfh_ctx *c;
	sfh_buf *next;
	void *cpu;
	uint64_t iova;
	size_t size;
	unsigned access;
	int att;
	uint16_t gen;
};

struct sfh_queue {
	sfh_ctx *c;
	sfh_queue *next;
	unsigned qid;
	sfh_queue_params p;
	void *sq_cpu, *cq_cpu, *fence_cpu;
	uint64_t sq_iova, cq_iova, fence_iova;
	size_t sq_bytes, cq_bytes;
	unsigned sq_log2, cq_log2;
	uint16_t sq_tail, sq_head, cq_head, cq_head_reported;   /* free-running positions */
	uint16_t epoch;
	uint32_t next_seq;
	uint64_t next_ticket;
	sfh_slot *slots;
	sfh_completion *done;
	unsigned done_cap, done_head, done_cnt;
	uint32_t last_dev_completed;
	uint64_t last_progress_t, fence_submitted;
	bool armed, need_recover, dead, dying, irq_pending_check;
	unsigned spurious_streak, hang_strikes;
	sfh_queue_stats st;
};

struct sfh_ctx {
	sfh_dev *d;
	unsigned id;
	bool alive;
	sfh_buf *bufs;
	sfh_queue *queues;
	unsigned devmem_lost;
};

typedef struct sfh_att_shadow {
	bool used;
	uint64_t iova;
	uint32_t size;
	unsigned perm, ctx;
	uint16_t gen;
} sfh_att_shadow;

struct sfh_dev {
	const sfh_transport *tp;
	sfh_dev_params p;
	unsigned nq, max_ctx, n_att, fetch_max, win_log2;
	sfh_queue *q[SFH_MAXQ];
	sfh_ctx *ctx[SFH_MAXCTX];
	bool needs_scrub[SFH_MAXCTX];
	sfh_att_shadow att[SFH_MAXATT];
	uint16_t att_gen[SFH_MAXATT];
	uint32_t sync_token;
	uint16_t epoch_ctr;
	bool dead, in_reset;
	sfh_dev_stats st;
};

/* ---- diagnostics: set SFH_DEBUG=1 in the environment ---- */
#include <stdio.h>
void sfh__log(const char *fmt, ...) __attribute__((format(printf, 1, 2)));

/* ---- transport shorthands ---- */
#define TP(d) ((d)->tp)
static inline uint32_t sfh__rd(sfh_dev *d, uint32_t off) { return TP(d)->ops->mmio_rd32(TP(d)->ctx, off); }
static inline void sfh__wr(sfh_dev *d, uint32_t off, uint32_t v) { TP(d)->ops->mmio_wr32(TP(d)->ctx, off, v); }
static inline uint64_t sfh__now(sfh_dev *d) { return TP(d)->ops->now_ns(TP(d)->ctx); }
static inline void sfh__cost(sfh_dev *d, unsigned k, uint32_t n) { TP(d)->ops->cpu_cost(TP(d)->ctx, k, n); }
static inline unsigned sfh__inflight(const sfh_queue *q) { return (uint16_t)(q->sq_tail - q->sq_head); }
static inline uint32_t sfh__qreg(const sfh_queue *q, uint32_t r) { return SFH_QREG(q->qid, r); }
static inline uint32_t sfh__dbreg(const sfh_queue *q, uint32_t r) { return SFH_DBREG(q->qid, r); }
static inline int32_t sfh__sdiff(uint32_t a, uint32_t b) { return (int32_t)(a - b); }

/* ---- driver layer (sfh_kmd.c) ---- */
enum { SFH_RECOVER_ERROR = 1, SFH_RECOVER_LOST_CQE, SFH_RECOVER_HANG };
enum { SFH_LVL_QUEUE = 0, SFH_LVL_ENGINE, SFH_LVL_FUNCTION };
int  sfh__queue_recover(sfh_queue *q, int reason);
int  sfh__dev_reset(sfh_dev *d, int level);
int  sfh__sleep_until(sfh_dev *d, uint64_t t);

/* ---- user layer (sfh_umd.c) ---- */
int  sfh__drain(sfh_queue *q);
void sfh__complete(sfh_queue *q, const sfh_slot *s, uint32_t status, uint32_t result, uint32_t flags);
int  sfh__validate(sfh_queue *q, const sfh_cmd *c);
int  sfh__encode(sfh_queue *q, const sfh_cmd *c, uint32_t seq, uint8_t dflags, sfh_desc *out);
int  sfh__write_batch(sfh_queue *q, sfh_slot *src, unsigned n);   /* replay path: write + doorbell */

#endif
