// SPDX-License-Identifier: MIT
/*
 * SilicaFlux HSI v2 — physical-deployment transport: Linux VFIO + PCIe endpoint.
 *
 * STATUS: compile-checked only (`make vfio`). It has never run: no SF-G1 hardware and no
 * PCI IDs exist. It is the host half of docs/ENDPOINT_ADAPTER.md and is meant for bring-up
 * in a single privileged process (root, or a broker that owns /dev/vfio/N). It is NOT the
 * production model for many applications: there the driver layer (sfh_kmd.c) belongs in a
 * kernel driver that hands each process only its own doorbell page and keeps the IOMMU.
 *
 * What it maps from the transport interface:
 *   mmio_rd32/wr32  -> BAR0 mmap'ed through VFIO (uncached), 32-bit volatile accesses
 *   dma_alloc/free  -> page-aligned, locked anonymous memory + driver-chosen IOVA
 *   iommu_map/unmap -> VFIO_IOMMU_MAP_DMA / UNMAP_DMA (type1v2): the IOMMU confines the
 *                      device to exactly what the driver mapped, a second wall behind the
 *                      device's own mapping table (ATT)
 *   irq_wait/take   -> one eventfd per MSI-X vector (VFIO_DEVICE_SET_IRQS), poll()
 *   wmb/rmb         -> sfence / dmb oshst ; acquire fence / dmb oshld
 *   now_ns          -> CLOCK_MONOTONIC ; cpu_cost -> no-op (POLL -> pause/yield)
 * At open it also enables bus mastering and CLEARS PCIe Relaxed Ordering and No-Snoop
 * enable in Device Control (contract rule O14), independent of firmware defaults.
 */
#include <errno.h>
#include <fcntl.h>
#include <linux/pci_regs.h>
#include <linux/vfio.h>
#include <poll.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/eventfd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include "sfh_transport.h"

#define VF_MAXVEC 8

typedef struct vf {
	int container, group, device;
	volatile uint8_t *bar0;
	size_t bar0_size;
	uint64_t cfg_off;            /* offset of the config-space region in the device fd */
	int efd[VF_MAXVEC];
	unsigned nvec;
	uint32_t pending;
	uint64_t iova_next;
	sfh_transport tp;
} vf;

static inline void vf_wmb(void)
{
#if defined(__x86_64__)
	__asm__ volatile("sfence" ::: "memory");
#elif defined(__aarch64__)
	__asm__ volatile("dmb oshst" ::: "memory");
#else
	__atomic_thread_fence(__ATOMIC_SEQ_CST);
#endif
}
static inline void vf_rmb(void)
{
#if defined(__aarch64__)
	__asm__ volatile("dmb oshld" ::: "memory");
#else
	__atomic_thread_fence(__ATOMIC_ACQUIRE);
#endif
}

static uint32_t op_rd32(void *t, uint32_t off)
{
	vf *v = t;
	if (off + 4 > v->bar0_size) return 0xffffffffu;
	return *(volatile uint32_t *)(v->bar0 + off);   /* LE device, LE host (checked in sfh_abi.h) */
}
static void op_wr32(void *t, uint32_t off, uint32_t val)
{
	vf *v = t;
	if (off + 4 > v->bar0_size) return;
	*(volatile uint32_t *)(v->bar0 + off) = val;
}
static int op_dma_alloc(void *t, size_t size, void **cpu, uint64_t *iova)
{
	vf *v = t;
	size = (size + 4095) & ~(size_t)4095;
	void *p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_LOCKED, -1, 0);
	if (p == MAP_FAILED) return -ENOMEM;
	memset(p, 0, size);
	*cpu = p;
	*iova = v->iova_next;
	v->iova_next += size + 4096;      /* guard page between mappings */
	return 0;
}
static void op_dma_free(void *t, void *cpu, uint64_t iova, size_t size)
{
	(void)t; (void)iova;
	munmap(cpu, (size + 4095) & ~(size_t)4095);
}
/* The IOVA -> vaddr association: dma_alloc hands out (cpu, iova) pairs; iommu_map needs the
 * vaddr again, so this bring-up transport keeps a small table. */
#define VF_MAXMAP 256
static struct { uint64_t iova; void *cpu; size_t size; } vf_map[VF_MAXMAP];
static void remember(uint64_t iova, void *cpu, size_t size)
{
	for (int i = 0; i < VF_MAXMAP; i++)
		if (!vf_map[i].cpu) { vf_map[i].iova = iova; vf_map[i].cpu = cpu; vf_map[i].size = size; return; }
}
static void *lookup(uint64_t iova)
{
	for (int i = 0; i < VF_MAXMAP; i++)
		if (vf_map[i].cpu && iova >= vf_map[i].iova && iova < vf_map[i].iova + vf_map[i].size)
			return (uint8_t *)vf_map[i].cpu + (iova - vf_map[i].iova);
	return NULL;
}
static int op_dma_alloc_tracked(void *t, size_t size, void **cpu, uint64_t *iova)
{
	int rc = op_dma_alloc(t, size, cpu, iova);
	if (!rc) remember(*iova, *cpu, (size + 4095) & ~(size_t)4095);
	return rc;
}
static void op_dma_free_tracked(void *t, void *cpu, uint64_t iova, size_t size)
{
	for (int i = 0; i < VF_MAXMAP; i++)
		if (vf_map[i].cpu == cpu) vf_map[i].cpu = NULL;
	op_dma_free(t, cpu, iova, size);
}
static int op_iommu_map(void *t, uint64_t iova, size_t size, unsigned perm)
{
	vf *v = t;
	void *cpu = lookup(iova);
	if (!cpu) return -EINVAL;
	struct vfio_iommu_type1_dma_map m;
	memset(&m, 0, sizeof(m));
	m.argsz = sizeof(m);
	m.vaddr = (uintptr_t)cpu & ~(uintptr_t)4095;
	m.iova = iova & ~(uint64_t)4095;
	m.size = (size + (iova & 4095) + 4095) & ~(uint64_t)4095;
	m.flags = ((perm & SFH_IOMMU_DEV_READ) ? VFIO_DMA_MAP_FLAG_READ : 0) |
	          ((perm & SFH_IOMMU_DEV_WRITE) ? VFIO_DMA_MAP_FLAG_WRITE : 0);
	return ioctl(v->container, VFIO_IOMMU_MAP_DMA, &m) ? -errno : 0;
}
static void op_iommu_unmap(void *t, uint64_t iova, size_t size)
{
	vf *v = t;
	struct vfio_iommu_type1_dma_unmap u;
	memset(&u, 0, sizeof(u));
	u.argsz = sizeof(u);
	u.iova = iova & ~(uint64_t)4095;
	u.size = (size + (iova & 4095) + 4095) & ~(uint64_t)4095;
	ioctl(v->container, VFIO_IOMMU_UNMAP_DMA, &u);
}
static void op_dma_store(void *t, void *dst, const void *src, size_t n) { (void)t; memcpy(dst, src, n); }
static void op_wmb(void *t) { (void)t; vf_wmb(); }
static void op_rmb(void *t) { (void)t; vf_rmb(); }
static uint64_t op_now(void *t)
{
	(void)t;
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}
static uint32_t collect(vf *v, int timeout_ms)
{
	struct pollfd p[VF_MAXVEC];
	for (unsigned i = 0; i < v->nvec; i++) { p[i].fd = v->efd[i]; p[i].events = POLLIN; p[i].revents = 0; }
	if (poll(p, v->nvec, timeout_ms) > 0)
		for (unsigned i = 0; i < v->nvec; i++)
			if (p[i].revents & POLLIN) {
				uint64_t cnt;
				if (read(v->efd[i], &cnt, sizeof(cnt)) == sizeof(cnt)) v->pending |= 1u << i;
			}
	return v->pending;
}
static uint32_t op_irq_take(void *t, uint32_t mask)
{
	vf *v = t;
	collect(v, 0);
	uint32_t r = v->pending & mask;
	v->pending &= ~r;
	return r;
}
static uint32_t op_irq_wait(void *t, uint32_t mask, uint64_t deadline)
{
	vf *v = t;
	for (;;) {
		uint32_t r = op_irq_take(t, mask);
		if (r) return r;
		uint64_t now = op_now(t);
		if (now >= deadline) return 0;
		uint64_t ms = (deadline - now + 999999) / 1000000;
		collect(v, ms > 1000 ? 1000 : (int)ms);
	}
}
static void op_cpu_cost(void *t, unsigned kind, uint32_t n)
{
	(void)t;
	if (kind != SFH_COST_POLL) return;
	while (n--) {
#if defined(__x86_64__)
		__builtin_ia32_pause();
#elif defined(__aarch64__)
		__asm__ volatile("yield");
#endif
	}
}
static void op_sync(void *t) { (void)t; }

static const sfh_transport_ops VF_OPS = {
	op_rd32, op_wr32, op_dma_alloc_tracked, op_dma_free_tracked, op_iommu_map, op_iommu_unmap,
	op_dma_store, op_wmb, op_rmb, op_irq_wait, op_irq_take, op_now, op_cpu_cost, op_sync,
};

/* ---- config space helpers ---- */
static int cfg_rw(vf *v, int wr, uint32_t off, void *buf, size_t n)
{
	ssize_t r = wr ? pwrite(v->device, buf, n, (off_t)(v->cfg_off + off))
	               : pread(v->device, buf, n, (off_t)(v->cfg_off + off));
	return r == (ssize_t)n ? 0 : -EIO;
}
static int pcie_cap(vf *v)
{
	uint8_t p = 0;
	if (cfg_rw(v, 0, PCI_CAPABILITY_LIST, &p, 1)) return -1;
	for (int guard = 0; p && guard < 48; guard++) {
		uint8_t id = 0, nx = 0;
		cfg_rw(v, 0, p, &id, 1);
		cfg_rw(v, 0, p + 1u, &nx, 1);
		if (id == PCI_CAP_ID_EXP) return p;
		p = nx;
	}
	return -1;
}

/*
 * Open a device bound to vfio-pci. `group_path` is /dev/vfio/<group>, `bdf` e.g. "0000:03:00.0".
 * `nvec` = number of MSI-X vectors to wire (one per queue).
 */
int sfh_vfio_open(const char *group_path, const char *bdf, unsigned nvec, const sfh_transport **out)
{
	vf *v = calloc(1, sizeof(*v));
	if (!v) return -ENOMEM;
	v->iova_next = 0x100000000ull;
	v->container = open("/dev/vfio/vfio", O_RDWR | O_CLOEXEC);
	if (v->container < 0) goto err;
	if (ioctl(v->container, VFIO_GET_API_VERSION) != VFIO_API_VERSION) goto err;
	if (!ioctl(v->container, VFIO_CHECK_EXTENSION, VFIO_TYPE1v2_IOMMU)) goto err;
	v->group = open(group_path, O_RDWR | O_CLOEXEC);
	if (v->group < 0) goto err;
	struct vfio_group_status gs = { .argsz = sizeof(gs) };
	if (ioctl(v->group, VFIO_GROUP_GET_STATUS, &gs) || !(gs.flags & VFIO_GROUP_FLAGS_VIABLE)) goto err;
	if (ioctl(v->group, VFIO_GROUP_SET_CONTAINER, &v->container)) goto err;
	if (ioctl(v->container, VFIO_SET_IOMMU, VFIO_TYPE1v2_IOMMU)) goto err;
	v->device = ioctl(v->group, VFIO_GROUP_GET_DEVICE_FD, bdf);
	if (v->device < 0) goto err;
	/* BAR0 */
	struct vfio_region_info ri = { .argsz = sizeof(ri), .index = VFIO_PCI_BAR0_REGION_INDEX };
	if (ioctl(v->device, VFIO_DEVICE_GET_REGION_INFO, &ri) || !(ri.flags & VFIO_REGION_INFO_FLAG_MMAP) ||
	    ri.size < 0x8000)                          /* BAR0 must cover the HSI v2 register map */
		goto err;
	void *bar = mmap(NULL, ri.size, PROT_READ | PROT_WRITE, MAP_SHARED, v->device, (off_t)ri.offset);
	if (bar == MAP_FAILED) goto err;
	v->bar0 = bar;
	v->bar0_size = ri.size;
	/* config space: bus master on; Relaxed Ordering and No-Snoop OFF (rule O14) */
	struct vfio_region_info ci = { .argsz = sizeof(ci), .index = VFIO_PCI_CONFIG_REGION_INDEX };
	if (ioctl(v->device, VFIO_DEVICE_GET_REGION_INFO, &ci)) goto err;
	v->cfg_off = ci.offset;
	uint16_t cmd = 0;
	if (cfg_rw(v, 0, PCI_COMMAND, &cmd, 2)) goto err;
	cmd |= PCI_COMMAND_MEMORY | PCI_COMMAND_MASTER;
	if (cfg_rw(v, 1, PCI_COMMAND, &cmd, 2)) goto err;
	int pc = pcie_cap(v);
	if (pc > 0) {
		uint16_t dc = 0;
		cfg_rw(v, 0, (uint32_t)pc + PCI_EXP_DEVCTL, &dc, 2);
		dc &= (uint16_t)~(PCI_EXP_DEVCTL_RELAX_EN | PCI_EXP_DEVCTL_NOSNOOP_EN);
		cfg_rw(v, 1, (uint32_t)pc + PCI_EXP_DEVCTL, &dc, 2);
	}
	/* MSI-X: one eventfd per vector */
	if (nvec > VF_MAXVEC) nvec = VF_MAXVEC;
	struct vfio_irq_info ii = { .argsz = sizeof(ii), .index = VFIO_PCI_MSIX_IRQ_INDEX };
	if (ioctl(v->device, VFIO_DEVICE_GET_IRQ_INFO, &ii) || ii.count < nvec) goto err;
	size_t sz = sizeof(struct vfio_irq_set) + nvec * sizeof(int32_t);
	struct vfio_irq_set *is = calloc(1, sz);
	if (!is) goto err;
	is->argsz = (uint32_t)sz;
	is->flags = VFIO_IRQ_SET_DATA_EVENTFD | VFIO_IRQ_SET_ACTION_TRIGGER;
	is->index = VFIO_PCI_MSIX_IRQ_INDEX;
	is->start = 0;
	is->count = nvec;
	for (unsigned i = 0; i < nvec; i++) {
		v->efd[i] = eventfd(0, EFD_CLOEXEC | EFD_NONBLOCK);
		((int32_t *)is->data)[i] = v->efd[i];
	}
	v->nvec = nvec;
	int irc = ioctl(v->device, VFIO_DEVICE_SET_IRQS, is);
	free(is);
	if (irc) goto err;
	v->tp.ops = &VF_OPS;
	v->tp.ctx = v;
	v->tp.name = "vfio";
	*out = &v->tp;
	return 0;
err:
	{
		int e = errno ? -errno : -ENODEV;
		if (v->bar0) munmap((void *)v->bar0, v->bar0_size);
		if (v->device > 0) close(v->device);
		if (v->group > 0) close(v->group);
		if (v->container > 0) close(v->container);
		free(v);
		return e;
	}
}
