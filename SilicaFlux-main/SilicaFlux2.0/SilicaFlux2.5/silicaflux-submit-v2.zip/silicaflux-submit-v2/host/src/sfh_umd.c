// SPDX-License-Identifier: MIT
/*
 * SilicaFlux HSI v2 — user layer: submission, completion, waiting, fences.
 *
 * Host side of the ownership and ordering rules in docs/CONTRACT.md:
 *   O1  descriptors are stored, then wmb(), then ONE doorbell per batch
 *   O2  a slot is reused only after a CQE's sq_head (or recovery) released it
 *   O6  CQE consumption: read dw3 (phase) first, rmb(), then the payload; the
 *       check byte and the sequence window reject torn or duplicated entries
 *   O7  CQ credits are returned with DB_CQ_HEAD, always before arming
 *   O8  arm (one-shot) only after reporting the CQ head; the device fires at once
 *       if anything is still unconsumed, so a completion can never be missed
 */
#include "sfh_internal.h"

#define EV_EVENT   0
#define EV_TIMEOUT 1

static const char *const HOST_ST[] = { "UNCERTAIN", "NOT_EXECUTED", "DEVICE_LOST" };

const char *sfh_status_str(uint32_t st)
{
	if (st < sizeof(sfh_status_names) / sizeof(sfh_status_names[0]) && sfh_status_names[st])
		return sfh_status_names[st];
	if (st >= SFH_CS_UNCERTAIN && st <= SFH_CS_DEVICE_LOST) return HOST_ST[st - SFH_CS_UNCERTAIN];
	return "?";
}

/* ============================== descriptors ============================== */
void sfh_desc_seal(sfh_desc *d)
{
	uint32_t x = SFH_DESC_CHECK_SALT;
	for (int i = 0; i < 15; i++) x ^= d->dw[i];
	d->dw[15] = x;
}
int sfh_desc_check(const sfh_desc *d)
{
	uint32_t x = 0;
	for (int i = 0; i < 16; i++) x ^= d->dw[i];
	return x == SFH_DESC_CHECK_SALT;
}

static bool win_ok(const sfh_queue *q, uint64_t off, uint64_t len)
{
	uint64_t win = (uint64_t)1 << q->c->d->win_log2;
	return off <= win && len <= win - off;
}

/* Library/driver validation. The device repeats every check (it cannot trust the host). */
int sfh__validate(sfh_queue *q, const sfh_cmd *c)
{
	if (c->op >= SFH_OP_COUNT || (c->flags & ~SFH_FLAGS_VALID)) return -EINVAL;
	switch (c->op) {
	case SFH_OP_NOP:
		return 0;
	case SFH_OP_COPY_H2D:
	case SFH_OP_COPY_D2H: {
		const sfh_buf *b = c->buf;
		if (!b) return -EINVAL;
		if (b->c != q->c) return -EPERM;                     /* not this process's buffer */
		unsigned need = c->op == SFH_OP_COPY_H2D ? SFH_BUF_DEV_READ : SFH_BUF_DEV_WRITE;
		if (!(b->access & need)) return -EPERM;
		if (!c->len || (c->len | c->buf_off | c->dev_off) & 7) return -EINVAL;
		if (c->buf_off > b->size || c->len > b->size - c->buf_off) return -EINVAL;
		if (!win_ok(q, c->dev_off, c->len)) return -EINVAL;
		return 0;
	}
	case SFH_OP_KERNEL:
		if (c->kop >= SFH_KOP_COUNT) return -EINVAL;
		if (c->kop == SFH_KOP_SPIN) return c->len ? -EINVAL : 0;
		if (!c->len || (c->len | c->dev_off) & 7 || !win_ok(q, c->dev_off, c->len)) return -EINVAL;
		if (c->kop == SFH_KOP_SUM32) return c->value ? -EINVAL : 0;
		if ((c->dev_off2 & 7) || !win_ok(q, c->dev_off2, c->len)) return -EINVAL;
		return 0;
	case SFH_OP_FENCE_SIGNAL:
		return 0;   /* monotonicity is checked against the batch in sfh_submit */
	case SFH_OP_FENCE_WAIT:
		if (!c->wait_queue) return -EINVAL;
		if (c->wait_queue->c != q->c) return -EPERM;
		return 0;
	}
	return -EINVAL;
}

int sfh__encode(sfh_queue *q, const sfh_cmd *c, uint32_t seq, uint8_t dflags, sfh_desc *o)
{
	memset(o, 0, sizeof(*o));
	o->dw[0] = SFH_DESC_MAGIC | (SFH_DESC_VERSION << 8) | ((uint32_t)c->op << 16) | ((uint32_t)dflags << 24);
	o->dw[1] = seq;
	o->dw[2] = q->epoch;
	o->dw[3] = c->user_tag;
	switch (c->op) {
	case SFH_OP_COPY_H2D:
	case SFH_OP_COPY_D2H:
		o->dw[4] = c->buf ? (((uint32_t)c->buf->gen << 16) | (uint32_t)c->buf->att) : 0;
		o->dw[5] = c->len;
		o->dw[6] = (uint32_t)c->buf_off; o->dw[7] = (uint32_t)(c->buf_off >> 32);
		o->dw[8] = (uint32_t)c->dev_off; o->dw[9] = (uint32_t)(c->dev_off >> 32);
		break;
	case SFH_OP_KERNEL:
		o->dw[5] = c->len;
		o->dw[8] = (uint32_t)c->dev_off; o->dw[9] = (uint32_t)(c->dev_off >> 32);
		if (c->kop == SFH_KOP_ADD32 || c->kop == SFH_KOP_XOR64) {
			o->dw[10] = (uint32_t)c->dev_off2; o->dw[11] = (uint32_t)(c->dev_off2 >> 32);
		}
		o->dw[12] = (uint32_t)c->value; o->dw[13] = (uint32_t)(c->value >> 32);
		o->dw[14] = c->kop;
		break;
	case SFH_OP_FENCE_SIGNAL:
		o->dw[12] = (uint32_t)c->value; o->dw[13] = (uint32_t)(c->value >> 32);
		break;
	case SFH_OP_FENCE_WAIT:
		o->dw[12] = (uint32_t)c->value; o->dw[13] = (uint32_t)(c->value >> 32);
		o->dw[14] = c->wait_queue ? c->wait_queue->qid : 0;
		break;
	default:
		break;
	}
	sfh_desc_seal(o);
	return 0;
}

/* write prepared slots at the current tail and ring the doorbell once (also the replay path) */
int sfh__write_batch(sfh_queue *q, sfh_slot *src, unsigned n)
{
	sfh_dev *d = q->c->d;
	const sfh_transport *tp = TP(d);
	unsigned mask = (1u << q->sq_log2) - 1;
	for (unsigned i = 0; i < n; i++) {
		uint16_t pos = (uint16_t)(q->sq_tail + i);
		sfh_slot *sl = &q->slots[pos & mask];
		*sl = src[i];
		sl->seq = q->next_seq + i;
		sfh_desc desc;
		sfh__encode(q, &sl->cmd, sl->seq, sl->dflags, &desc);
		tp->ops->dma_store(tp->ctx, (uint8_t *)q->sq_cpu + (size_t)(pos & mask) * 64, &desc, sizeof(desc));
	}
#if SFH_HOST_MUTANT != 1
	tp->ops->wmb(tp->ctx);                 /* O1: descriptors visible before the doorbell */
#endif
	if (!sfh__inflight(q)) q->last_progress_t = sfh__now(d);
	q->sq_tail = (uint16_t)(q->sq_tail + n);
	q->next_seq += n;
	sfh__wr(d, sfh__dbreg(q, SFH_DB_SQ_TAIL), q->sq_tail);
	q->st.doorbells++;
	return 0;
}

/* ============================== submission ============================== */
int sfh_submit(sfh_queue *q, const sfh_cmd *cmds, unsigned n, unsigned sflags, uint64_t *first)
{
	sfh_dev *d = q->c->d;
	if (q->dead || !q->c->alive || d->dead) return -ENODEV;
	if (sflags & ~3u) return -EINVAL;
	if (q->need_recover) sfh__queue_recover(q, SFH_RECOVER_ERROR);
	if (!n) return 0;
	unsigned cap = 1u << q->sq_log2;
	if (n > cap) return -E2BIG;
	if (cap - sfh__inflight(q) < n) {
		sfh__drain(q);
		if (q->need_recover) sfh__queue_recover(q, SFH_RECOVER_ERROR);
		if (cap - sfh__inflight(q) < n) return -EAGAIN;
	}
	bool direct = q->p.flags & SFH_QF_DIRECT;
	if (!direct) sfh__cost(d, SFH_COST_SYSCALL, 1);
	/* validate the whole batch before anything is written: all or nothing */
	uint64_t fence = q->fence_submitted;
	for (unsigned i = 0; i < n; i++) {
		int rc = sfh__validate(q, &cmds[i]);
		if (rc) return rc;
		if (cmds[i].op == SFH_OP_FENCE_SIGNAL) {
			if (cmds[i].value <= fence) return -EINVAL;
			fence = cmds[i].value;
		}
	}
	sfh__cost(d, SFH_COST_UMD_DESC, n);
	if (!direct) sfh__cost(d, SFH_COST_KMD_DESC, n);
	q->fence_submitted = fence;
	sfh_slot tmp[64];
	uint64_t now = sfh__now(d), t0 = q->next_ticket;
	for (unsigned base = 0; base < n; base += 64) {
		unsigned m = n - base < 64 ? n - base : 64;
		for (unsigned i = 0; i < m; i++) {
			unsigned k = base + i;
			uint8_t f = cmds[k].flags;
			if ((sflags & SFH_SUBMIT_COALESCE) && k + 1 < n) f |= SFH_FLAG_SUPPRESS_CQE;
			if ((sflags & SFH_SUBMIT_IRQ_LAST) && k + 1 == n) f |= SFH_FLAG_IRQ_NOW;
			tmp[i] = (sfh_slot){ .cmd = cmds[k], .ticket = q->next_ticket++, .t_submit = now, .dflags = f };
		}
		if (base + m < n) {
			/* very large batch: stage all but the last chunk without a doorbell */
			unsigned mask = cap - 1;
			for (unsigned i = 0; i < m; i++) {
				uint16_t pos = (uint16_t)(q->sq_tail + i);
				q->slots[pos & mask] = tmp[i];
				q->slots[pos & mask].seq = q->next_seq + i;
				sfh_desc desc;
				sfh__encode(q, &tmp[i].cmd, q->next_seq + i, tmp[i].dflags, &desc);
				TP(d)->ops->dma_store(TP(d)->ctx, (uint8_t *)q->sq_cpu + (size_t)(pos & mask) * 64, &desc, 64);
			}
			if (!sfh__inflight(q)) q->last_progress_t = sfh__now(d);
			q->sq_tail = (uint16_t)(q->sq_tail + m);
			q->next_seq += m;
		} else {
			sfh__write_batch(q, tmp, m);
		}
	}
	q->st.submits++;
	q->st.cmds += n;
	if (first) *first = t0;
	return 0;
}

/* ============================== completions ============================== */
void sfh__complete(sfh_queue *q, const sfh_slot *s, uint32_t status, uint32_t result, uint32_t flags)
{
	if (q->done_cnt == q->done_cap) {
		unsigned ncap = q->done_cap * 2;
		sfh_completion *n = calloc(ncap, sizeof(*n));
		if (!n) return;   /* out of memory: completion is dropped (reported via stats) */
		for (unsigned i = 0; i < q->done_cnt; i++) n[i] = q->done[(q->done_head + i) % q->done_cap];
		free(q->done);
		q->done = n; q->done_cap = ncap; q->done_head = 0;
	}
	if (s->replayed) flags |= SFH_CF_REPLAYED;
	if (q->c->devmem_lost) flags |= SFH_CF_DEVMEM_LOST;
	sfh_completion *c = &q->done[(q->done_head + q->done_cnt) % q->done_cap];
	q->done_cnt++;
	*c = (sfh_completion){ .ticket = s->ticket, .user_tag = s->cmd.user_tag, .status = status,
	                       .result = result, .flags = flags, .qid = q->qid, .dev_seq = s->seq,
	                       .t_submit = s->t_submit, .t_reap = 0 };
	q->st.completions++;
	q->last_progress_t = sfh__now(q->c->d);
}

static void report_cq_head(sfh_queue *q)
{
	if (q->cq_head != q->cq_head_reported) {
		sfh__wr(q->c->d, sfh__dbreg(q, SFH_DB_CQ_HEAD), q->cq_head);
		q->cq_head_reported = q->cq_head;
	}
}

/* Consume every valid CQE. Never blocks, never recovers (sets need_recover instead). */
int sfh__drain(sfh_queue *q)
{
	sfh_dev *d = q->c->d;
	const sfh_transport *tp = TP(d);
	if (q->dead) return 0;
	tp->ops->sync(tp->ctx);
	unsigned cmask = (1u << q->cq_log2) - 1, smask = (1u << q->sq_log2) - 1;
	int produced = 0;
	for (;;) {
		volatile uint32_t *e = (volatile uint32_t *)((uint8_t *)q->cq_cpu + (size_t)(q->cq_head & cmask) * 16);
		uint32_t dw3 = e[3];
		uint32_t want = ((q->cq_head >> q->cq_log2) & 1u) ^ 1u;
		if ((dw3 & 1u) != want) break;            /* not written yet (this lap) */
		tp->ops->rmb(tp->ctx);                    /* O6: payload after phase */
		uint32_t dw0 = e[0], dw1 = e[1], dw2 = e[2];
		(void)dw1;
		if ((dw2 & 0xffu) != ((dw3 >> 8) & 0xffu)) { q->st.anomaly_torn++; break; }
		unsigned infl = sfh__inflight(q);
		uint32_t oldest = q->slots[q->sq_head & smask].seq;
#if SFH_HOST_MUTANT != 2
		if (!infl || (uint32_t)(dw2 - oldest) >= infl) {
			/* not a command we are waiting for: a duplicated or stale entry. Leave the slot;
			 * the device will overwrite it with the real CQE for this position. */
			q->st.anomaly_stale++;
			break;
		}
#else
		(void)infl; (void)oldest;
#endif
		sfh__cost(d, SFH_COST_CQE, 1);
		uint32_t status = (dw3 >> 1) & 0x7fu;
		uint16_t sqh = (uint16_t)(dw3 >> 16);
		/* in-order completion: everything before this seq finished OK (suppressed CQEs) */
		while (sfh__inflight(q) && sfh__sdiff(q->slots[q->sq_head & smask].seq, dw2) <= 0) {
			sfh_slot *sl = &q->slots[q->sq_head & smask];
			if (sl->seq == dw2) sfh__complete(q, sl, status, dw0, 0);
			else sfh__complete(q, sl, SFH_ST_OK, 0, 0);
			q->sq_head++;
			produced++;
		}
		if (q->sq_head != sqh) q->st.anomaly_sqhead++;
		q->cq_head++;
		q->st.cqes++;
		q->hang_strikes = 0;                     /* real progress */
		if (status != SFH_ST_OK) { q->need_recover = true; break; }   /* the queue is halted */
	}
	if ((uint16_t)(q->cq_head - q->cq_head_reported) >= (cmask + 1) / 4) report_cq_head(q);
	return produced;
}

static bool cq_peek(sfh_queue *q)
{
	const sfh_transport *tp = TP(q->c->d);
	tp->ops->sync(tp->ctx);
	unsigned cmask = (1u << q->cq_log2) - 1;
	volatile uint32_t *e = (volatile uint32_t *)((uint8_t *)q->cq_cpu + (size_t)(q->cq_head & cmask) * 16);
	return (e[3] & 1u) == (((q->cq_head >> q->cq_log2) & 1u) ^ 1u);
}

static unsigned pop_done(sfh_queue *q, sfh_completion *out, unsigned max)
{
	unsigned n = 0;
	uint64_t now = sfh__now(q->c->d);
	while (n < max && q->done_cnt) {
		out[n] = q->done[q->done_head];
		out[n].t_reap = now;
		q->done_head = (q->done_head + 1) % q->done_cap;
		q->done_cnt--;
		n++;
	}
	return n;
}

int sfh_reap(sfh_queue *q, sfh_completion *out, unsigned max)
{
	if (sfh__drain(q) > 0 && q->irq_pending_check) {
		q->irq_pending_check = false;   /* the interrupt we woke on was a real one */
		q->spurious_streak = 0;
	}
	if (q->need_recover) sfh__queue_recover(q, SFH_RECOVER_ERROR);
	return (int)pop_done(q, out, max);
}

unsigned sfh_queue_inflight(sfh_queue *q) { return sfh__inflight(q); }

uint64_t sfh_now(sfh_queue *q) { return sfh__now(q->c->d); }

void sfh_idle_until(sfh_queue *q, uint64_t t)
{
	sfh_dev *d = q->c->d;
	if (q->p.notify == SFH_NOTIFY_POLL) {
		while (sfh__now(d) < t) sfh__cost(d, SFH_COST_POLL, 1);
		return;
	}
	if (sfh__now(d) >= t) return;
	/* sleep; an interrupt for this queue (if armed) ends the sleep early */
	uint32_t r = TP(d)->ops->irq_wait(TP(d)->ctx, sfh__inflight(q) && q->armed ? 1u << q->qid : 0, t);
	if (r) { q->armed = false; q->st.irqs++; q->irq_pending_check = true; }   /* one-shot: consumed */
}

/* Block (per notification mode) until the CQ may have something new, or `deadline`. */
static int wait_event(sfh_queue *q, uint64_t deadline)
{
	sfh_dev *d = q->c->d;
	const sfh_transport *tp = TP(d);
	if (q->p.notify == SFH_NOTIFY_POLL) {
		sfh__cost(d, SFH_COST_POLL, 1);
		q->st.polls++;
		return sfh__now(d) >= deadline ? EV_TIMEOUT : EV_EVENT;
	}
	if (q->p.notify == SFH_NOTIFY_HYBRID) {
		uint64_t t0 = sfh__now(d);
		while (sfh__now(d) - t0 < q->p.poll_budget_ns && sfh__now(d) < deadline) {
			sfh__cost(d, SFH_COST_POLL, 1);
			q->st.polls++;
			if (cq_peek(q)) return EV_EVENT;
		}
		if (sfh__now(d) >= deadline) return EV_TIMEOUT;
	}
	if (!q->armed) {
		report_cq_head(q);                        /* O8: credits before arming */
		sfh__wr(d, sfh__dbreg(q, SFH_DB_CQ_ARM), 1);
		q->armed = true;
		q->st.arms++;
	}
	q->st.irq_waits++;
	uint32_t r = tp->ops->irq_wait(tp->ctx, 1u << q->qid, deadline);
	q->armed = false;   /* one-shot: fired (or, on timeout, re-arm to be safe) */
	if (r) { q->st.irqs++; q->irq_pending_check = true; return EV_EVENT; }
	q->st.timer_wakeups++;
	if (cq_peek(q)) q->st.lost_irq_recovered++;   /* completions were there; the interrupt was not */
	return EV_TIMEOUT;
}

/* No progress for host_timeout_ns: find out why, and recover only if the device is stuck. */
static void host_timeout(sfh_queue *q)
{
	sfh_dev *d = q->c->d;
	q->st.host_timeouts++;
	if (sfh__drain(q)) { q->st.lost_irq_recovered++; return; }
	uint32_t qs = sfh__rd(d, sfh__qreg(q, SFH_QSTATUS));          /* MMIO read: flushes posted writes */
	uint32_t comp = sfh__rd(d, sfh__qreg(q, SFH_QCOMPLETED_SEQ));
	if (sfh__drain(q)) { q->st.lost_irq_recovered++; return; }
	if (q->need_recover || (qs & (1u << SFH_QST_HALTED))) { sfh__queue_recover(q, SFH_RECOVER_ERROR); return; }
	if (qs & (1u << SFH_QST_WAITING)) { q->last_progress_t = sfh__now(d); return; }   /* legit fence wait */
	unsigned smask = (1u << q->sq_log2) - 1;
	for (uint16_t p = q->sq_head; p != q->sq_tail; p++) {
		const sfh_slot *sl = &q->slots[p & smask];
		if (sfh__sdiff(sl->seq, comp) > 0) break;
		if (!(sl->dflags & SFH_FLAG_SUPPRESS_CQE)) {
			sfh__queue_recover(q, SFH_RECOVER_LOST_CQE);   /* finished, but its CQE never arrived */
			return;
		}
	}
	if (comp != q->last_dev_completed) {                      /* slow, not stuck */
		q->last_dev_completed = comp;
		q->last_progress_t = sfh__now(d);
		return;
	}
	sfh__queue_recover(q, SFH_RECOVER_HANG);
}

/* one round of "make progress": drain, recover if needed, otherwise wait once */
static int progress(sfh_queue *q, uint64_t deadline)
{
	sfh_dev *d = q->c->d;
	int got = sfh__drain(q);
	if (q->irq_pending_check) {
		q->irq_pending_check = false;
		if (!got && !q->need_recover) {
			q->st.spurious_irqs++;
			/* repeated empty interrupts: the device believes it posted CQEs we cannot see
			 * (lost completion). Do the no-progress check now instead of storming. */
			if (++q->spurious_streak >= 4) { q->spurious_streak = 0; host_timeout(q); return 0; }
		} else {
			q->spurious_streak = 0;
		}
	}
	if (q->need_recover) { sfh__queue_recover(q, SFH_RECOVER_ERROR); return 0; }
	if (got || q->done_cnt) return 0;
	if (q->dead) return -ENODEV;
	if (!sfh__inflight(q)) return 0;
	uint64_t now = sfh__now(d);
	if (now >= deadline) return -ETIMEDOUT;
	uint64_t slice = q->last_progress_t + q->p.host_timeout_ns;
	if (now >= slice) { host_timeout(q); return 0; }
	wait_event(q, deadline < slice ? deadline : slice);
	return 0;
}

int sfh_wait_any(sfh_queue *q, uint64_t timeout_ns, sfh_completion *out, unsigned max)
{
	sfh_dev *d = q->c->d;
	uint64_t deadline = sfh__now(d) + timeout_ns;
	for (;;) {
		unsigned n = pop_done(q, out, max);
		if (n) return (int)n;
		if (!sfh__inflight(q)) {
			sfh__drain(q);
			n = pop_done(q, out, max);
			return (int)n;
		}
		int rc = progress(q, deadline);
		if (rc) { n = pop_done(q, out, max); return n ? (int)n : rc; }
	}
}

int sfh_wait_ticket(sfh_queue *q, uint64_t ticket, uint64_t timeout_ns, sfh_completion *out)
{
	sfh_dev *d = q->c->d;
	uint64_t deadline = sfh__now(d) + timeout_ns;
	for (;;) {
		for (unsigned i = 0; i < q->done_cnt; i++) {
			unsigned k = (q->done_head + i) % q->done_cap;
			if (q->done[k].ticket != ticket) continue;
			*out = q->done[k];
			out->t_reap = sfh__now(d);
			for (unsigned j = i; j + 1 < q->done_cnt; j++)
				q->done[(q->done_head + j) % q->done_cap] = q->done[(q->done_head + j + 1) % q->done_cap];
			q->done_cnt--;
			return 0;
		}
		if (!sfh__inflight(q) && !q->need_recover) {
			sfh__drain(q);
			bool found = false;
			for (unsigned i = 0; i < q->done_cnt; i++)
				if (q->done[(q->done_head + i) % q->done_cap].ticket == ticket) found = true;
			if (!found) return -ENOENT;
			continue;
		}
		int rc = progress(q, deadline);
		if (rc) return rc;
	}
}

/* ============================== fences ============================== */
uint64_t sfh_fence_read(sfh_queue *q)
{
	const sfh_transport *tp = TP(q->c->d);
	tp->ops->sync(tp->ctx);
	volatile uint64_t *f = (volatile uint64_t *)q->fence_cpu;
	uint64_t v = *f;
	tp->ops->rmb(tp->ctx);   /* O9: data written before the fence is visible after reading it */
	return v;
}

int sfh_fence_wait(sfh_queue *q, uint64_t value, uint64_t timeout_ns)
{
	sfh_dev *d = q->c->d;
	uint64_t deadline = sfh__now(d) + timeout_ns;
	for (;;) {
		if (sfh_fence_read(q) >= value) return 0;
		if (q->dead) return -ENODEV;
		if (!sfh__inflight(q) && sfh_fence_read(q) < value) {
			sfh__drain(q);
			if (sfh_fence_read(q) >= value) return 0;
			return -ENOENT;   /* nothing in flight can ever signal it */
		}
		int rc = progress(q, deadline);
		if (rc) return rc;
	}
}

void sfh_queue_get_stats(sfh_queue *q, sfh_queue_stats *s) { *s = q->st; }

/* ============================== verification hooks ============================== */
int sfh_test_write_slot(sfh_queue *q, uint16_t pos, const sfh_desc *dsc)
{
	const sfh_transport *tp = TP(q->c->d);
	unsigned mask = (1u << q->sq_log2) - 1;
	tp->ops->dma_store(tp->ctx, (uint8_t *)q->sq_cpu + (size_t)(pos & mask) * 64, dsc, 64);
	tp->ops->wmb(tp->ctx);
	return 0;
}
void sfh_test_doorbell(sfh_queue *q, uint16_t tail) { sfh__wr(q->c->d, sfh__dbreg(q, SFH_DB_SQ_TAIL), tail); }
void sfh_test_cq_doorbell(sfh_queue *q, uint16_t head) { sfh__wr(q->c->d, sfh__dbreg(q, SFH_DB_CQ_HEAD), head); }
int sfh_test_build(sfh_queue *q, const sfh_cmd *c, uint32_t seq, sfh_desc *out)
{
	return sfh__encode(q, c, seq, c->flags, out);
}
uint16_t sfh_test_sq_tail(sfh_queue *q) { return q->sq_tail; }
uint32_t sfh_test_next_seq(sfh_queue *q) { return q->next_seq; }
uint16_t sfh_test_epoch(sfh_queue *q) { return q->epoch; }
int sfh_test_adopt(sfh_queue *q, uint16_t tail, uint32_t next_seq)
{
	unsigned mask = (1u << q->sq_log2) - 1;
	uint64_t now = sfh__now(q->c->d);
	if (!sfh__inflight(q)) q->last_progress_t = now;
	while (q->sq_tail != tail) {
		sfh_slot *sl = &q->slots[q->sq_tail & mask];
		memset(sl, 0, sizeof(*sl));
		sl->seq = q->next_seq++;
		sl->ticket = q->next_ticket++;
		sl->t_submit = now;
		q->sq_tail++;
	}
	q->next_seq = next_seq;
	return 0;
}
int sfh_runtime_mutant(void) { return SFH_HOST_MUTANT; }
