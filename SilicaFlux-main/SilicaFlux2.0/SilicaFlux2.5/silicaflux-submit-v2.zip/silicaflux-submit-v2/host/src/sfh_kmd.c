// SPDX-License-Identifier: MIT
/*
 * SilicaFlux HSI v2 — driver layer (privileged).
 *
 * Owns: device discovery, process contexts, the DMA mapping table (ATT) and the IOMMU,
 * queue memory and registers, resets, timeout recovery and the release path that runs
 * when a process terminates. Everything that could give an application access to
 * memory it does not own lives here, behind sfh.h.
 */
#include "sfh_internal.h"

#include <stdarg.h>
void sfh__log(const char *fmt, ...)
{
	static int on = -1;
	if (on < 0) on = getenv("SFH_DEBUG") != NULL;
	if (!on) return;
	va_list ap;
	va_start(ap, fmt);
	fprintf(stderr, "[sfh] ");
	vfprintf(stderr, fmt, ap);
	fputc('\n', stderr);
	va_end(ap);
}

static const sfh_dev_params DEF_PARAMS = {
	.cmd_timeout_ns = 2000000,
	.fence_timeout_ns = 5000000,
	.reset_timeout_ns = 100000,
};

int sfh__sleep_until(sfh_dev *d, uint64_t t)
{
	TP(d)->ops->irq_wait(TP(d)->ctx, 0, t);   /* mask 0: a timed sleep */
	return 0;
}

/* poll a register until (v & mask) == want, sleeping between reads */
static int poll_reg(sfh_dev *d, uint32_t off, uint32_t mask, uint32_t want, uint64_t timeout_ns, uint32_t *last)
{
	uint64_t deadline = sfh__now(d) + timeout_ns;
	uint64_t step = 2000;
	for (;;) {
		uint32_t v = sfh__rd(d, off);
		if (last) *last = v;
		if ((v & mask) == want) return 0;
		if (sfh__now(d) >= deadline) return -ETIMEDOUT;
		sfh__sleep_until(d, sfh__now(d) + step);
		if (step < 20000) step *= 2;
	}
}

/* ============================== discovery ============================== */
int sfh_dev_open(const sfh_transport *tp, const sfh_dev_params *p, sfh_dev **out)
{
	sfh_dev *d = calloc(1, sizeof(*d));
	if (!d) return -ENOMEM;
	d->tp = tp;
	d->p = p ? *p : DEF_PARAMS;
	if (!d->p.reset_timeout_ns) d->p.reset_timeout_ns = DEF_PARAMS.reset_timeout_ns;
	uint32_t id = sfh__rd(d, SFH_REG_ID);
	if (id == 0xffffffffu || id != SFH_CHIP_ID) goto nodev;
	uint32_t ver = sfh__rd(d, SFH_REG_HW_VERSION);
	if ((ver >> 16) != SFH_HW_MAJOR) { free(d); return -EPROTONOSUPPORT; }
	if (poll_reg(d, SFH_REG_STATUS, 1u << SFH_STATUS_READY, 1u << SFH_STATUS_READY, 1000000, NULL)) goto nodev;
	uint32_t caps = sfh__rd(d, SFH_REG_CAPS);
	const uint32_t need = (1u << SFH_CAP_ENGINE_RESET) | (1u << SFH_CAP_FUNC_RESET) |
		(1u << SFH_CAP_QUEUE_RESET) | (1u << SFH_CAP_IMOD) | (1u << SFH_CAP_FENCE) |
		(1u << SFH_CAP_ATT) | (1u << SFH_CAP_CQE_SUPPRESS) | (1u << SFH_CAP_BATCH_FETCH) |
		(1u << SFH_CAP_SCRUB) | (1u << SFH_CAP_WATCHDOG);
	if ((caps & need) != need) goto nodev;
	if (!(sfh__rd(d, SFH_REG_DESC_VERSIONS) & (1u << SFH_DESC_VERSION))) { free(d); return -EPROTONOSUPPORT; }
	uint32_t l0 = sfh__rd(d, SFH_REG_LIMITS0), l1 = sfh__rd(d, SFH_REG_LIMITS1);
	d->nq = l0 & 0xff; d->max_ctx = (l0 >> 8) & 0xff; d->n_att = (l0 >> 16) & 0xff; d->fetch_max = l0 >> 24;
	d->win_log2 = (l1 >> 8) & 0xff;
	/* never trust a limit before range-checking it */
	if (d->nq < 1 || d->nq > SFH_MAXQ || d->max_ctx < 1 || d->max_ctx > SFH_MAXCTX ||
	    d->n_att < 1 || d->n_att > SFH_MAXATT || d->fetch_max < 1 || d->fetch_max > 64 ||
	    (l1 & 0xff) < 32 || d->win_log2 < 12 || d->win_log2 > 30 ||
	    ((l1 >> 16) & 0xff) > SFH_Q_LOG2_MIN || (l1 >> 24) < SFH_Q_LOG2_MAX)
		goto nodev;
	sfh__wr(d, SFH_REG_SCRATCH, 0xA5A5A5A5u);
	if (sfh__rd(d, SFH_REG_SCRATCH) != 0xA5A5A5A5u) goto nodev;
	sfh__wr(d, SFH_REG_SCRATCH, 0x5A5A5A5Au);
	if (sfh__rd(d, SFH_REG_SCRATCH) != 0x5A5A5A5Au) goto nodev;
	sfh__wr(d, SFH_REG_CMD_TIMEOUT, d->p.cmd_timeout_ns);
	sfh__wr(d, SFH_REG_FENCE_TIMEOUT, d->p.fence_timeout_ns);
	for (unsigned i = 0; i < SFH_MAXCTX; i++) d->needs_scrub[i] = true;
	d->epoch_ctr = 1;
	*out = d;
	return 0;
nodev:
	free(d);
	return -ENODEV;
}

void sfh_dev_close(sfh_dev *d)
{
	if (!d) return;
	for (unsigned i = 0; i < SFH_MAXCTX; i++)
		if (d->ctx[i]) sfh_ctx_close(d->ctx[i]);
	free(d);
}

void sfh_dev_get_stats(sfh_dev *d, sfh_dev_stats *s) { *s = d->st; s->dead = d->dead; }
uint32_t sfh_test_mmio_rd(sfh_dev *d, uint32_t off) { return sfh__rd(d, off); }
void sfh_test_mmio_wr(sfh_dev *d, uint32_t off, uint32_t v) { sfh__wr(d, off, v); }

/* ============================== device memory scrub ============================== */
static int scrub_ctx(sfh_dev *d, unsigned id)
{
	sfh__wr(d, SFH_REG_SCRUB, id | (1u << 31));
	/* a scrub writes 1 word/cycle: give it 4x the nominal time */
	uint64_t t = ((uint64_t)1 << (d->win_log2 - 3)) * 4 + 100000;
	if (poll_reg(d, SFH_REG_STATUS, 1u << SFH_STATUS_SCRUB_BUSY, 0, t, NULL)) return -EIO;
	d->needs_scrub[id] = false;
	d->st.scrubs++;
	return 0;
}

/* ============================== contexts ============================== */
int sfh_ctx_open(sfh_dev *d, sfh_ctx **out)
{
	if (d->dead) return -ENODEV;
	for (unsigned i = 0; i < d->max_ctx; i++) {
		if (d->ctx[i]) continue;
		/* the next owner of a window must never see the previous owner's data */
		if (d->needs_scrub[i] && scrub_ctx(d, i)) continue;   /* unconfirmed scrub: withhold the slot */
		sfh_ctx *c = calloc(1, sizeof(*c));
		if (!c) return -ENOMEM;
		c->d = d; c->id = i; c->alive = true;
		d->ctx[i] = c;
		*out = c;
		return 0;
	}
	return -EBUSY;
}

unsigned sfh_ctx_devmem_lost(sfh_ctx *c) { return c->devmem_lost; }

/* ============================== mapping table ============================== */
static void att_program(sfh_dev *d, int idx)
{
	const sfh_att_shadow *a = &d->att[idx];
	sfh__wr(d, SFH_REG_ATT_IDX, (uint32_t)idx);
	sfh__wr(d, SFH_REG_ATT_BASE_LO, (uint32_t)a->iova);
	sfh__wr(d, SFH_REG_ATT_BASE_HI, (uint32_t)(a->iova >> 32));
	sfh__wr(d, SFH_REG_ATT_SIZE, a->size);
	uint32_t ctl = (1u << SFH_ATT_VALID) |
		((a->perm & SFH_BUF_DEV_READ) ? 1u << SFH_ATT_PERM_R : 0) |
		((a->perm & SFH_BUF_DEV_WRITE) ? 1u << SFH_ATT_PERM_W : 0) |
		((uint32_t)a->ctx << SFH_ATT_CTX_LSB) | ((uint32_t)a->gen << SFH_ATT_GEN_LSB);
	sfh__wr(d, SFH_REG_ATT_CTL, ctl);
	sfh__wr(d, SFH_REG_ATT_CMD, SFH_ATT_CMD_WRITE);
}

/* Invalidate + sync: after this returns 0 the device can no longer touch the old mapping,
 * and every write it issued through it has reached memory (the ACK is read over MMIO). */
static int att_revoke(sfh_dev *d, int idx)
{
	sfh__wr(d, SFH_REG_ATT_IDX, (uint32_t)idx);
	sfh__wr(d, SFH_REG_ATT_CMD, SFH_ATT_CMD_INVALIDATE);
	uint32_t tok = ++d->sync_token;
	sfh__wr(d, SFH_REG_ATT_SYNC, tok);
	d->st.att_syncs++;
#if SFH_HOST_MUTANT == 3
	return 0;   /* MUTANT: do not wait for the device to stop using the mapping */
#else
	uint64_t deadline = sfh__now(d) + d->p.cmd_timeout_ns + d->p.reset_timeout_ns;
	while (sfh__rd(d, SFH_REG_ATT_SYNC_ACK) != tok) {
		if (sfh__now(d) >= deadline) {
			/* the device does not acknowledge: stop it before releasing memory */
			d->st.escalations++;
			sfh__log("ATT sync %u not acknowledged -> engine reset", tok);
			if (sfh__dev_reset(d, SFH_LVL_ENGINE)) return -EIO;
			return 0;
		}
		sfh__sleep_until(d, sfh__now(d) + 2000);
	}
	return 0;
#endif
}

int sfh_buf_alloc(sfh_ctx *c, size_t size, unsigned access, sfh_buf **out)
{
	sfh_dev *d = c->d;
	if (!c->alive || d->dead) return -ENODEV;
	if (!size || size > 0xFFFFFFF8u || !access || (access & ~3u)) return -EINVAL;
	size = (size + 7) & ~(size_t)7;
	int idx = -1;
	for (unsigned i = 0; i < d->n_att; i++)
		if (!d->att[i].used) { idx = (int)i; break; }
	if (idx < 0) return -ENOSPC;
	sfh_buf *b = calloc(1, sizeof(*b));
	if (!b) return -ENOMEM;
	if (TP(d)->ops->dma_alloc(TP(d)->ctx, size, &b->cpu, &b->iova)) { free(b); return -ENOMEM; }
	unsigned perm = ((access & SFH_BUF_DEV_READ) ? SFH_IOMMU_DEV_READ : 0) |
	                ((access & SFH_BUF_DEV_WRITE) ? SFH_IOMMU_DEV_WRITE : 0);
	TP(d)->ops->iommu_map(TP(d)->ctx, b->iova, size, perm);
	uint16_t gen = (uint16_t)(d->att_gen[idx] + 1);
	if (!gen) gen = 1;
	d->att_gen[idx] = gen;
	d->att[idx] = (sfh_att_shadow){ .used = true, .iova = b->iova, .size = (uint32_t)size,
	                                .perm = access, .ctx = c->id, .gen = gen };
	att_program(d, idx);
	b->c = c; b->size = size; b->access = access; b->att = idx; b->gen = gen;
	b->next = c->bufs; c->bufs = b;
	*out = b;
	return 0;
}

void  *sfh_buf_ptr(sfh_buf *b) { return b->cpu; }
size_t sfh_buf_size(sfh_buf *b) { return b->size; }
uint32_t sfh_test_handle(sfh_buf *b) { return ((uint32_t)b->gen << 16) | (uint32_t)b->att; }

static void buf_release(sfh_buf *b)
{
	sfh_dev *d = b->c->d;
	if (!d->dead) att_revoke(d, b->att);
	d->att[b->att].used = false;
	TP(d)->ops->iommu_unmap(TP(d)->ctx, b->iova, b->size);
	TP(d)->ops->dma_free(TP(d)->ctx, b->cpu, b->iova, b->size);
}

int sfh_buf_free(sfh_buf *b)
{
	sfh_ctx *c = b->c;
	sfh_buf **pp = &c->bufs;
	while (*pp && *pp != b) pp = &(*pp)->next;
	if (!*pp) return -ENOENT;
	*pp = b->next;
	buf_release(b);
	free(b);
	return 0;
}

/* ============================== queues ============================== */
void sfh_queue_params_default(sfh_queue_params *p)
{
	memset(p, 0, sizeof(*p));
	p->sq_entries = 256;
	p->cq_entries = 256;
	p->notify = SFH_NOTIFY_IRQ;
	p->poll_budget_ns = 5000;
	p->host_timeout_ns = 20000000;
}

static int log2_pow2(uint32_t v)
{
	if (!v || (v & (v - 1))) return -1;
	int l = 0;
	while ((1u << l) < v) l++;
	return l;
}

static void queue_program(sfh_queue *q)
{
	sfh_dev *d = q->c->d;
	sfh__wr(d, sfh__qreg(q, SFH_QSQ_BASE_LO), (uint32_t)q->sq_iova);
	sfh__wr(d, sfh__qreg(q, SFH_QSQ_BASE_HI), (uint32_t)(q->sq_iova >> 32));
	sfh__wr(d, sfh__qreg(q, SFH_QCQ_BASE_LO), (uint32_t)q->cq_iova);
	sfh__wr(d, sfh__qreg(q, SFH_QCQ_BASE_HI), (uint32_t)(q->cq_iova >> 32));
	sfh__wr(d, sfh__qreg(q, SFH_QFENCE_LO), (uint32_t)q->fence_iova);
	sfh__wr(d, sfh__qreg(q, SFH_QFENCE_HI), (uint32_t)(q->fence_iova >> 32));
	sfh__wr(d, sfh__qreg(q, SFH_QSIZE), q->sq_log2 | (q->cq_log2 << 8));
	sfh__wr(d, sfh__qreg(q, SFH_QIMOD_CNT), q->p.imod_count);
	sfh__wr(d, sfh__qreg(q, SFH_QIMOD_TIME), q->p.imod_time_ns);
	sfh__wr(d, sfh__qreg(q, SFH_QTIMELINE_LO), (uint32_t)q->fence_submitted);
	sfh__wr(d, sfh__qreg(q, SFH_QTIMELINE_HI), (uint32_t)(q->fence_submitted >> 32));
}

/* (Re)enable with a fresh epoch. The device must be quiescent for this queue (rule O12). */
static int queue_enable(sfh_queue *q)
{
	sfh_dev *d = q->c->d;
	static const uint8_t zero[64];
	for (size_t off = 0; off < q->cq_bytes; off += sizeof(zero))
		TP(d)->ops->dma_store(TP(d)->ctx, (uint8_t *)q->cq_cpu + off, zero, sizeof(zero));
	TP(d)->ops->wmb(TP(d)->ctx);             /* CQ cleared before the device may write it */
#if SFH_HOST_MUTANT == 4
	if (!q->epoch) q->epoch = d->epoch_ctr++;   /* MUTANT: epoch never changes */
#else
	q->epoch = d->epoch_ctr++;
	if (!d->epoch_ctr) d->epoch_ctr = 1;
#endif
	q->sq_tail = q->sq_head = q->cq_head = q->cq_head_reported = 0;
	q->armed = false;
	q->need_recover = false;
	q->last_dev_completed = q->next_seq - 1;
	q->last_progress_t = sfh__now(d);
	sfh__wr(d, sfh__qreg(q, SFH_QCFG), q->c->id | ((uint32_t)q->epoch << 16));
	sfh__wr(d, sfh__qreg(q, SFH_QSEQ_BASE), q->next_seq);
	sfh__wr(d, sfh__qreg(q, SFH_QCTL), 1u << SFH_QCTL_ENABLE);
	uint32_t st = sfh__rd(d, sfh__qreg(q, SFH_QSTATUS));
	return (st & (1u << SFH_QST_ENABLED)) ? 0 : -EIO;
}

int sfh_queue_create(sfh_ctx *c, const sfh_queue_params *pin, sfh_queue **out)
{
	sfh_dev *d = c->d;
	if (!c->alive || d->dead) return -ENODEV;
	sfh_queue_params p;
	if (pin) p = *pin; else sfh_queue_params_default(&p);
	if (!p.sq_entries) p.sq_entries = 256;
	if (!p.cq_entries) p.cq_entries = p.sq_entries;
	if (!p.host_timeout_ns) p.host_timeout_ns = 20000000;
	int sl = log2_pow2(p.sq_entries), cl = log2_pow2(p.cq_entries);
	if (sl < (int)SFH_Q_LOG2_MIN || sl > (int)SFH_Q_LOG2_MAX || cl < (int)SFH_Q_LOG2_MIN ||
	    cl > (int)SFH_Q_LOG2_MAX || p.notify > SFH_NOTIFY_HYBRID || (p.flags & ~3u) ||
	    (p.imod_count > 1 && !p.imod_time_ns))
		return -EINVAL;
	int qid = -1;
	for (unsigned i = 0; i < d->nq; i++)
		if (!d->q[i]) { qid = (int)i; break; }
	if (qid < 0) return -EBUSY;
	sfh_queue *q = calloc(1, sizeof(*q));
	if (!q) return -ENOMEM;
	q->c = c; q->qid = (unsigned)qid; q->p = p;
	q->sq_log2 = (unsigned)sl; q->cq_log2 = (unsigned)cl;
	q->sq_bytes = (size_t)p.sq_entries * 64; q->cq_bytes = (size_t)p.cq_entries * 16;
	q->slots = calloc(p.sq_entries, sizeof(sfh_slot));
	q->done_cap = p.sq_entries * 2;
	q->done = calloc(q->done_cap, sizeof(sfh_completion));
	void *ops = TP(d)->ctx;
	if (!q->slots || !q->done ||
	    TP(d)->ops->dma_alloc(ops, q->sq_bytes, &q->sq_cpu, &q->sq_iova) ||
	    TP(d)->ops->dma_alloc(ops, q->cq_bytes, &q->cq_cpu, &q->cq_iova) ||
	    TP(d)->ops->dma_alloc(ops, 4096, &q->fence_cpu, &q->fence_iova)) {
		free(q->slots); free(q->done); free(q);
		return -ENOMEM;
	}
	/* device-visible ranges, with the least permission each needs */
	TP(d)->ops->iommu_map(ops, q->sq_iova, q->sq_bytes, SFH_IOMMU_DEV_READ);
	TP(d)->ops->iommu_map(ops, q->cq_iova, q->cq_bytes, SFH_IOMMU_DEV_WRITE);
	TP(d)->ops->iommu_map(ops, q->fence_iova, 8, SFH_IOMMU_DEV_WRITE);
	q->next_seq = 0x1000u * (uint32_t)(qid + 1);
	q->next_ticket = 1;
	queue_program(q);
	if (queue_enable(q)) {
		TP(d)->ops->iommu_unmap(ops, q->sq_iova, q->sq_bytes);
		TP(d)->ops->iommu_unmap(ops, q->cq_iova, q->cq_bytes);
		TP(d)->ops->iommu_unmap(ops, q->fence_iova, 8);
		TP(d)->ops->dma_free(ops, q->sq_cpu, q->sq_iova, q->sq_bytes);
		TP(d)->ops->dma_free(ops, q->cq_cpu, q->cq_iova, q->cq_bytes);
		TP(d)->ops->dma_free(ops, q->fence_cpu, q->fence_iova, 4096);
		free(q->slots); free(q->done); free(q);
		return -EIO;
	}
	d->q[qid] = q;
	q->next = c->queues; c->queues = q;
	*out = q;
	return 0;
}

unsigned sfh_queue_id(sfh_queue *q) { return q->qid; }

/* Stop the queue and wait until the device has quiesced it; after the RESET_DONE read
 * (an MMIO read, which flushes the device's posted writes) its rings may be freed. */
static int queue_stop(sfh_queue *q)
{
	sfh_dev *d = q->c->d;
	if (d->dead) return 0;
	d->st.queue_resets++;
	sfh__wr(d, sfh__qreg(q, SFH_QCTL), 1u << SFH_QCTL_RESET);
	if (poll_reg(d, sfh__qreg(q, SFH_QSTATUS), 1u << SFH_QST_RESET_DONE, 1u << SFH_QST_RESET_DONE,
	             d->p.reset_timeout_ns, NULL) == 0)
		return 0;
	d->st.escalations++;
	sfh__log("queue %u: reset did not complete in %llu ns -> engine reset", q->qid,
	         (unsigned long long)d->p.reset_timeout_ns);
	return sfh__dev_reset(d, SFH_LVL_ENGINE);
}

static void queue_free_mem(sfh_queue *q)
{
	sfh_dev *d = q->c->d;
	void *t = TP(d)->ctx;
	TP(d)->ops->iommu_unmap(t, q->sq_iova, q->sq_bytes);
	TP(d)->ops->iommu_unmap(t, q->cq_iova, q->cq_bytes);
	TP(d)->ops->iommu_unmap(t, q->fence_iova, 8);
	TP(d)->ops->dma_free(t, q->sq_cpu, q->sq_iova, q->sq_bytes);
	TP(d)->ops->dma_free(t, q->cq_cpu, q->cq_iova, q->cq_bytes);
	TP(d)->ops->dma_free(t, q->fence_cpu, q->fence_iova, 4096);
	d->q[q->qid] = NULL;
	free(q->slots);
	free(q->done);
}

static void queue_unlink(sfh_queue *q)
{
	sfh_queue **pp = &q->c->queues;
	while (*pp && *pp != q) pp = &(*pp)->next;
	if (*pp) *pp = q->next;
}

int sfh_queue_destroy(sfh_queue *q)
{
	q->dying = true;
	int rc = queue_stop(q);
	queue_unlink(q);
	queue_free_mem(q);
	free(q);
	return rc;
}

/* ============================== process termination ============================== */
/* The release path: identical whether the process exited, crashed or was killed — the
 * driver gets no cooperation. Order matters:
 *   1. stop every queue of the context and wait for the device to quiesce it
 *      (no further fetches, completions or data DMA for those queues);
 *   2. revoke every mapping (ATT invalidate + sync) and only then unmap/free the memory;
 *   3. scrub the context's device-memory window before the slot can be reused. */
void sfh_ctx_kill(sfh_ctx *c)
{
	sfh_dev *d = c->d;
	c->alive = false;
	for (sfh_queue *q = c->queues; q; q = q->next) q->dying = true;
	while (c->queues) {
		sfh_queue *q = c->queues;
		queue_stop(q);
		c->queues = q->next;
		queue_free_mem(q);
		free(q);
	}
	while (c->bufs) {
		sfh_buf *b = c->bufs;
		c->bufs = b->next;
		buf_release(b);
		free(b);
	}
	d->ctx[c->id] = NULL;
	d->needs_scrub[c->id] = true;
	if (!d->dead) scrub_ctx(d, c->id);
	free(c);
}

int sfh_ctx_close(sfh_ctx *c)
{
	/* orderly close: let in-flight work finish (bounded), then the same release path */
	for (sfh_queue *q = c->queues; q; q = q->next) {
		sfh_completion tmp[16];
		uint64_t deadline = sfh__now(c->d) + 1000000000ull;
		while (sfh_queue_inflight(q) && !q->dead && sfh__now(c->d) < deadline)
			if (sfh_wait_any(q, 10000000, tmp, 16) < 0) break;
	}
	sfh_ctx_kill(c);
	return 0;
}

/* ============================== recovery ============================== */
typedef struct snap { uint32_t started, completed, errseq, qstatus; bool trusted; } snap;

static snap read_snap(sfh_queue *q)
{
	sfh_dev *d = q->c->d;
	snap s;
	s.qstatus = sfh__rd(d, sfh__qreg(q, SFH_QSTATUS));
	s.started = sfh__rd(d, sfh__qreg(q, SFH_QSTARTED_SEQ));
	s.completed = sfh__rd(d, sfh__qreg(q, SFH_QCOMPLETED_SEQ));
	s.errseq = sfh__rd(d, sfh__qreg(q, SFH_QERR_SEQ));
	s.trusted = true;
	return s;
}

/* Classify every command still in flight after the queue (or device) was reset, using the
 * device's STARTED/COMPLETED/ERR snapshot. Returns the number queued for replay in `rep`. */
static unsigned classify(sfh_queue *q, const snap *s, sfh_slot *rep)
{
	unsigned nrep = 0;
	bool errv = (s->qstatus >> SFH_QST_ERR_VALID) & 1;
	uint32_t errst = (s->qstatus >> SFH_QST_ERR_STATUS_LSB) & 0x7f;
	while (sfh__inflight(q)) {
		sfh_slot *sl = &q->slots[q->sq_head & ((1u << q->sq_log2) - 1)];
		int32_t dc = sfh__sdiff(sl->seq, s->completed);
		int32_t ds = sfh__sdiff(sl->seq, s->started);
		if (dc <= 0) {
			/* finished on the device; its CQE never reached us */
			uint32_t st = (errv && sl->seq == s->errseq) ? errst : SFH_ST_OK;
			q->st.recovered_from_snapshot++;
			sfh__complete(q, sl, st, 0, SFH_CF_RECOVERED);
		} else if (ds <= 0 || !s->trusted) {
#if SFH_HOST_MUTANT == 5
			sfh__complete(q, sl, SFH_ST_OK, 0, SFH_CF_RECOVERED);   /* MUTANT: claim success */
#else
			q->st.uncertain++;
			sfh__complete(q, sl, SFH_CS_UNCERTAIN, 0, 0);
#endif
		} else if (q->p.flags & SFH_QF_REPLAY) {
			rep[nrep] = *sl;
			rep[nrep++].replayed = 1;
		} else {
			q->st.not_executed++;
			sfh__complete(q, sl, SFH_CS_NOT_EXECUTED, 0, 0);
		}
		q->sq_head++;
	}
	return nrep;
}

static int requeue(sfh_queue *q, const snap *pre)
{
	sfh_dev *d = q->c->d;
	sfh__drain(q);                      /* completions that landed before the reset */
	snap s = pre ? *pre : read_snap(q);
	sfh_slot *rep = calloc(1u << q->sq_log2, sizeof(*rep));
	if (!rep) return -ENOMEM;
	unsigned nrep = classify(q, &s, rep);
	int rc = queue_enable(q);
	if (rc == 0 && nrep) {
		q->st.replays += nrep;
		rc = sfh__write_batch(q, rep, nrep);
	}
	free(rep);
	(void)d;
	return rc;
}

static void queue_dead(sfh_queue *q)
{
	while (sfh__inflight(q)) {
		sfh__complete(q, &q->slots[q->sq_head & ((1u << q->sq_log2) - 1)], SFH_CS_DEVICE_LOST, 0, 0);
		q->sq_head++;
	}
	q->dead = true;
}

int sfh__queue_recover(sfh_queue *q, int reason)
{
	sfh_dev *d = q->c->d;
	(void)reason;
	if (d->dead) { queue_dead(q); return -ENODEV; }
	if (d->in_reset) return 0;
	q->st.recoveries++;
	sfh__log("queue %u: recover reason=%d strikes=%u", q->qid, reason, q->hang_strikes);
	/* Escalation ladder for hangs: a queue that hangs again before making any progress after
	 * a queue reset is not the queue's fault -> engine reset -> function reset. */
	if (reason == SFH_RECOVER_HANG && ++q->hang_strikes >= 2) {
		d->st.escalations++;
		return sfh__dev_reset(d, q->hang_strikes >= 3 ? SFH_LVL_FUNCTION : SFH_LVL_ENGINE);
	}
	d->st.queue_resets++;
	sfh__wr(d, sfh__qreg(q, SFH_QCTL), 1u << SFH_QCTL_RESET);
	if (poll_reg(d, sfh__qreg(q, SFH_QSTATUS), 1u << SFH_QST_RESET_DONE, 1u << SFH_QST_RESET_DONE,
	             d->p.reset_timeout_ns, NULL)) {
		d->st.escalations++;
		return sfh__dev_reset(d, SFH_LVL_ENGINE);   /* recovers this queue and every other */
	}
	return requeue(q, NULL);
}

static int wait_reset(sfh_dev *d, uint32_t rc0)
{
	uint64_t deadline = sfh__now(d) + d->p.reset_timeout_ns;
	for (;;) {
		uint32_t rc = sfh__rd(d, SFH_REG_RESET_COUNT);
		uint32_t st = sfh__rd(d, SFH_REG_STATUS);
		if (rc != rc0 && (st & (1u << SFH_STATUS_READY))) return 0;
		if (sfh__now(d) >= deadline) return -ETIMEDOUT;
		sfh__sleep_until(d, sfh__now(d) + 2000);
	}
}

int sfh__dev_reset(sfh_dev *d, int level)
{
	if (d->dead) return -ENODEV;
	if (d->in_reset) return 0;
	d->in_reset = true;
	snap pre[SFH_MAXQ];
	int rc = -EIO;
	sfh__log("device reset level=%d", level);
	if (level == SFH_LVL_ENGINE) {
		d->st.engine_resets++;
		uint32_t rc0 = sfh__rd(d, SFH_REG_RESET_COUNT);
		sfh__wr(d, SFH_REG_CTRL, 1u << SFH_CTRL_ENGINE_RESET);
		if (wait_reset(d, rc0) == 0) rc = 0;
		else { d->st.escalations++; level = SFH_LVL_FUNCTION; }
	}
	if (level == SFH_LVL_FUNCTION) {
		/* snapshots do not survive a function reset: take them first and trust only
		 * "completed" — anything later may have started after the snapshot */
		for (unsigned i = 0; i < d->nq; i++)
			if (d->q[i]) { pre[i] = read_snap(d->q[i]); pre[i].trusted = false; pre[i].started = pre[i].completed; }
		d->st.function_resets++;
		uint32_t rc0 = sfh__rd(d, SFH_REG_RESET_COUNT);
		sfh__wr(d, SFH_REG_FUNC_RESET, SFH_FUNC_RESET_MAGIC);
		if (wait_reset(d, rc0)) {
			d->dead = true;
			d->in_reset = false;
			for (unsigned i = 0; i < d->nq; i++) if (d->q[i]) queue_dead(d->q[i]);
			return -ENODEV;
		}
		/* everything the device held is gone: restore it from the driver's shadow state */
		sfh__wr(d, SFH_REG_CMD_TIMEOUT, d->p.cmd_timeout_ns);
		sfh__wr(d, SFH_REG_FENCE_TIMEOUT, d->p.fence_timeout_ns);
		for (unsigned i = 0; i < d->n_att; i++) if (d->att[i].used) att_program(d, (int)i);
		for (unsigned i = 0; i < d->max_ctx; i++) {
			if (d->ctx[i]) d->ctx[i]->devmem_lost++;
			else d->needs_scrub[i] = true;
		}
		for (unsigned i = 0; i < d->nq; i++) if (d->q[i]) queue_program(d->q[i]);
		rc = 0;
	}
	d->in_reset = false;
	for (unsigned i = 0; i < d->nq; i++) {
		sfh_queue *q = d->q[i];
		if (!q || q->dying) continue;
		q->st.recoveries++;
		int r = requeue(q, level == SFH_LVL_FUNCTION ? &pre[i] : NULL);
		if (r && !rc) rc = r;
	}
	return rc;
}

int sfh_test_restart(sfh_queue *q, uint32_t next_seq)
{
	if (sfh__inflight(q)) return -EBUSY;
	int rc = queue_stop(q);
	if (rc) return rc;
	sfh__drain(q);
	q->next_seq = next_seq;
	return queue_enable(q);
}

int sfh_dev_engine_reset(sfh_dev *d) { return sfh__dev_reset(d, SFH_LVL_ENGINE); }
int sfh_dev_function_reset(sfh_dev *d) { return sfh__dev_reset(d, SFH_LVL_FUNCTION); }
