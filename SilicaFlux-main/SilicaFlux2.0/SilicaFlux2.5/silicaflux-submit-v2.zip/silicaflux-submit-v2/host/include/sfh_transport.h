/* SPDX-License-Identifier: MIT */
/*
 * SilicaFlux HSI v2 — host transport interface.
 *
 * The host runtime never touches hardware directly; it calls these operations.
 * Two implementations exist:
 *   sim/sfh_cosim.cpp   co-simulation of the RTL with a platform timing model (default)
 *   host/src/sfh_vfio.c Linux VFIO + PCIe endpoint (physical deployment; see docs/ENDPOINT_ADAPTER.md)
 *
 * Only the privileged driver layer (sfh_kmd.c) holds a transport. Applications get
 * opaque handles and never see BAR offsets, bus addresses or the IOMMU.
 */
#ifndef SFH_TRANSPORT_H
#define SFH_TRANSPORT_H
#include <stddef.h>
#include <stdint.h>

#define SFH_IOMMU_DEV_READ  1u   /* device may read this range (SQ ring, H2D sources) */
#define SFH_IOMMU_DEV_WRITE 2u   /* device may write this range (CQ ring, fence slot, D2H targets) */

enum sfh_cost_kind {
	SFH_COST_SYSCALL = 1,   /* one ioctl entry/exit (kernel-mediated submission)        */
	SFH_COST_KMD_DESC,      /* driver validates + copies one descriptor                  */
	SFH_COST_UMD_DESC,      /* library encodes one descriptor                            */
	SFH_COST_CQE,           /* parse + dispatch one completion entry                     */
	SFH_COST_POLL,          /* one spin-poll iteration                                   */
};

typedef struct sfh_transport_ops {
	/* BAR0 access. Writes are posted (return before the device sees them);
	 * reads are non-posted and, per PCIe ordering, return only after every
	 * posted write the device issued earlier has reached host memory (rule O10). */
	uint32_t (*mmio_rd32)(void *t, uint32_t off);
	void     (*mmio_wr32)(void *t, uint32_t off, uint32_t val);

	/* Pinned, DMA-capable host memory (zeroed). Not yet device-visible. */
	int      (*dma_alloc)(void *t, size_t size, void **cpu, uint64_t *iova);
	void     (*dma_free)(void *t, void *cpu, uint64_t iova, size_t size);
	/* Make [iova, iova+size) visible to the device with the given SFH_IOMMU_* permissions
	 * (IOMMU mapping on hardware; the simulated IOMMU doubles as the DMA oracle). */
	int      (*iommu_map)(void *t, uint64_t iova, size_t size, unsigned perm);
	void     (*iommu_unmap)(void *t, uint64_t iova, size_t size);

	/* CPU stores to memory the device reads (descriptor slots, CQ reset). They are NOT
	 * guaranteed visible to the device until wmb() (rule O1). */
	void     (*dma_store)(void *t, void *dst, const void *src, size_t n);
	void     (*wmb)(void *t);   /* stores to DMA memory before later stores and MMIO writes */
	void     (*rmb)(void *t);   /* loads of DMA memory before later loads */

	/* Interrupts: one vector per queue. wait sleeps until a vector in `mask` fires or the
	 * absolute deadline passes (returns 0). take returns-and-clears pending vectors. */
	uint32_t (*irq_wait)(void *t, uint32_t mask, uint64_t deadline_ns);
	uint32_t (*irq_take)(void *t, uint32_t mask);

	/* Time and CPU accounting. On hardware cpu_cost is a no-op (real code costs real
	 * time) and SFH_COST_POLL is one pause instruction; in the co-simulation each kind
	 * advances the virtual host clock and the CPU-busy counter by the profile's figure. */
	uint64_t (*now_ns)(void *t);
	void     (*cpu_cost)(void *t, unsigned kind, uint32_t count);
	void     (*sync)(void *t);                     /* observe device effects up to now */
} sfh_transport_ops;

typedef struct sfh_transport {
	const sfh_transport_ops *ops;
	void *ctx;
	const char *name;
} sfh_transport;

/* Physical deployment (host/src/sfh_vfio.c, compile-checked only): open a device bound to
 * vfio-pci, e.g. sfh_vfio_open("/dev/vfio/12", "0000:03:00.0", 4, &tp). Privileged. */
int sfh_vfio_open(const char *group_path, const char *bdf, unsigned nvec, const sfh_transport **out);

#endif
