/* SPDX-License-Identifier: MIT */
/*
 * SilicaFlux HSI v2 — host runtime API.
 *
 * Two layers, one library:
 *   driver layer (sfh_kmd.c)  — the privileged part. Owns the transport (BAR, IOMMU,
 *       interrupts), the DMA mapping table, queue creation, resets and recovery.
 *       In a deployment this is the kernel driver or a root-owned broker.
 *   user layer   (sfh_umd.c)  — what an application links against: build and submit
 *       command batches, reap completions, wait (interrupt / poll / hybrid), fences.
 *
 * Applications never see a bus address, a BAR offset or an IOMMU mapping. They name
 * memory by (sfh_buf, offset); the driver turns that into a {generation, index}
 * handle that the DEVICE checks against the mapping table the driver programmed.
 */
#ifndef SFH_H
#define SFH_H
#include <stddef.h>
#include <stdint.h>
#include "sfh_abi.h"
#include "sfh_transport.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct sfh_dev   sfh_dev;
typedef struct sfh_ctx   sfh_ctx;     /* one per process (models one open file) */
typedef struct sfh_queue sfh_queue;
typedef struct sfh_buf   sfh_buf;

/* ---- completion status: device ST_* values (0..15) plus host-side outcomes ---- */
enum {
	SFH_CS_UNCERTAIN    = 64,  /* execution had started when the queue was reset: side effects may be partial */
	SFH_CS_NOT_EXECUTED = 65,  /* never started; safe to resubmit (auto-replayed with SFH_QF_REPLAY) */
	SFH_CS_DEVICE_LOST  = 66,  /* device could not be recovered */
};
#define SFH_CF_RECOVERED    0x1u  /* outcome taken from the device's snapshot registers (CQE was lost) */
#define SFH_CF_REPLAYED     0x2u  /* command was resubmitted after a recovery */
#define SFH_CF_DEVMEM_LOST  0x4u  /* a function reset invalidated this context's device memory */

typedef struct sfh_dev_params {
	uint32_t cmd_timeout_ns;      /* device execution watchdog            (default 2 ms) */
	uint32_t fence_timeout_ns;    /* device FENCE_WAIT timeout             (default 5 ms) */
	uint64_t reset_timeout_ns;    /* driver wait for a reset to complete  (default 100 us) */
} sfh_dev_params;

int  sfh_dev_open(const sfh_transport *tp, const sfh_dev_params *p, sfh_dev **out);
void sfh_dev_close(sfh_dev *d);
int  sfh_dev_engine_reset(sfh_dev *d);      /* administrative; recovers every queue */
int  sfh_dev_function_reset(sfh_dev *d);
typedef struct sfh_dev_stats {
	uint64_t queue_resets, engine_resets, function_resets, escalations, att_syncs, scrubs;
	uint64_t dead;
} sfh_dev_stats;
void sfh_dev_get_stats(sfh_dev *d, sfh_dev_stats *s);

/* ---- process contexts ---- */
int  sfh_ctx_open(sfh_dev *d, sfh_ctx **out);
int  sfh_ctx_close(sfh_ctx *c);            /* orderly: drains in-flight work, then releases */
void sfh_ctx_kill(sfh_ctx *c);             /* process died: the driver's release path, no cooperation */
unsigned sfh_ctx_devmem_lost(sfh_ctx *c);  /* number of function resets this context lived through */

/* ---- buffers: driver-authorised DMA mappings ---- */
#define SFH_BUF_DEV_READ  1u   /* device may read  (COPY_H2D source) */
#define SFH_BUF_DEV_WRITE 2u   /* device may write (COPY_D2H target) */
int    sfh_buf_alloc(sfh_ctx *c, size_t size, unsigned access, sfh_buf **out);
void  *sfh_buf_ptr(sfh_buf *b);
size_t sfh_buf_size(sfh_buf *b);
int    sfh_buf_free(sfh_buf *b);           /* revokes the mapping and waits for the device before freeing */

/* ---- queues ---- */
typedef enum { SFH_NOTIFY_IRQ = 0, SFH_NOTIFY_POLL = 1, SFH_NOTIFY_HYBRID = 2 } sfh_notify;
#define SFH_QF_DIRECT 0x1u   /* user-mode submission (no syscall); the device still validates everything */
#define SFH_QF_REPLAY 0x2u   /* after recovery, resubmit commands that never started */
typedef struct sfh_queue_params {
	uint32_t   sq_entries, cq_entries;     /* powers of two, 16..4096 (default 256/256) */
	sfh_notify notify;
	uint32_t   imod_count;                 /* interrupt moderation: CQEs per interrupt (0/1 = each) */
	uint32_t   imod_time_ns;               /* moderation timer; required when imod_count > 1 */
	uint32_t   poll_budget_ns;             /* HYBRID: spin this long before sleeping (default 5 us) */
	uint32_t   flags;                      /* SFH_QF_* */
	uint64_t   host_timeout_ns;            /* no-progress timeout before recovery (default 20 ms) */
} sfh_queue_params;
void sfh_queue_params_default(sfh_queue_params *p);
int  sfh_queue_create(sfh_ctx *c, const sfh_queue_params *p, sfh_queue **out);
int  sfh_queue_destroy(sfh_queue *q);
unsigned sfh_queue_id(sfh_queue *q);

/* ---- commands ---- */
typedef struct sfh_cmd {
	uint8_t    op;            /* SFH_OP_* */
	uint8_t    flags;         /* SFH_FLAG_* (the runtime may add some, see SFH_SUBMIT_*) */
	uint8_t    kop;           /* OP_KERNEL: SFH_KOP_* */
	sfh_buf   *buf;           /* COPY_*: host buffer */
	uint64_t   buf_off;
	uint64_t   dev_off;       /* window offset: H2D dst, D2H src, KERNEL src */
	uint64_t   dev_off2;      /* window offset: KERNEL dst */
	uint32_t   len;           /* bytes */
	uint64_t   value;         /* KERNEL constant, SPIN ns, fence value */
	sfh_queue *wait_queue;    /* OP_FENCE_WAIT: queue whose timeline is awaited (same context) */
	uint32_t   user_tag;
} sfh_cmd;

#define SFH_SUBMIT_COALESCE 0x1u  /* suppress the CQE of every command but the last in the batch */
#define SFH_SUBMIT_IRQ_LAST 0x2u  /* last command of the batch bypasses interrupt moderation */

typedef struct sfh_completion {
	uint64_t ticket;
	uint32_t user_tag, status, result, flags;
	uint32_t qid, dev_seq;        /* device identity of the command (tracing) */
	uint64_t t_submit, t_reap;    /* host clock: submit call, completion handed to the caller */
} sfh_completion;

/* One batch = one validation pass, one ring write, one barrier, one doorbell (and one
 * syscall unless SFH_QF_DIRECT). All-or-nothing: -EINVAL rejects the whole batch;
 * -EAGAIN when the ring lacks space (reap and retry). */
int sfh_submit(sfh_queue *q, const sfh_cmd *cmds, unsigned n, unsigned sflags, uint64_t *first_ticket);
int sfh_reap(sfh_queue *q, sfh_completion *out, unsigned max);                    /* never blocks */
int sfh_wait_any(sfh_queue *q, uint64_t timeout_ns, sfh_completion *out, unsigned max);
int sfh_wait_ticket(sfh_queue *q, uint64_t ticket, uint64_t timeout_ns, sfh_completion *out);
unsigned sfh_queue_inflight(sfh_queue *q);

/* time helpers for applications driven by external arrivals */
uint64_t sfh_now(sfh_queue *q);                     /* ns, the runtime's clock */
void     sfh_idle_until(sfh_queue *q, uint64_t t);  /* POLL: spin; IRQ/HYBRID: sleep (wakes early on an interrupt) */

/* fences: FENCE_SIGNAL commands publish a value to the queue's fence slot (host memory) */
uint64_t sfh_fence_read(sfh_queue *q);
int      sfh_fence_wait(sfh_queue *q, uint64_t value, uint64_t timeout_ns);

typedef struct sfh_queue_stats {
	uint64_t submits, cmds, doorbells, cqes, completions;
	uint64_t irq_waits, irqs, spurious_irqs, arms, polls, timer_wakeups;
	uint64_t host_timeouts, lost_irq_recovered, recoveries, replays;
	uint64_t uncertain, not_executed, recovered_from_snapshot;
	uint64_t anomaly_torn, anomaly_stale, anomaly_sqhead;
} sfh_queue_stats;
void sfh_queue_get_stats(sfh_queue *q, sfh_queue_stats *s);

/* ---- verification hooks: model a hostile or buggy direct-submission client.
 * They bypass the library's validation; the device must still contain them. ---- */
int      sfh_test_write_slot(sfh_queue *q, uint16_t pos, const sfh_desc *d);   /* store + wmb, no doorbell */
void     sfh_test_doorbell(sfh_queue *q, uint16_t tail);                      /* raw SQ tail doorbell */
void     sfh_test_cq_doorbell(sfh_queue *q, uint16_t head);
int      sfh_test_build(sfh_queue *q, const sfh_cmd *c, uint32_t seq, sfh_desc *out);
uint32_t sfh_test_handle(sfh_buf *b);
uint16_t sfh_test_sq_tail(sfh_queue *q);
uint32_t sfh_test_next_seq(sfh_queue *q);
uint16_t sfh_test_epoch(sfh_queue *q);
int      sfh_test_adopt(sfh_queue *q, uint16_t tail, uint32_t next_seq);       /* account raw slots as in flight */
uint32_t sfh_test_mmio_rd(sfh_dev *d, uint32_t off);
void     sfh_test_mmio_wr(sfh_dev *d, uint32_t off, uint32_t v);
int      sfh_test_restart(sfh_queue *q, uint32_t next_seq);            /* idle queue: reset + re-enable at seq */
int      sfh_runtime_mutant(void);                                        /* SFH_HOST_MUTANT of this build */

/* descriptor helpers (shared by driver, library and tests) */
void     sfh_desc_seal(sfh_desc *d);            /* compute the check dword */
int      sfh_desc_check(const sfh_desc *d);     /* 1 if the check dword matches */
const char *sfh_status_str(uint32_t st);

#ifdef __cplusplus
}
#endif
#endif
