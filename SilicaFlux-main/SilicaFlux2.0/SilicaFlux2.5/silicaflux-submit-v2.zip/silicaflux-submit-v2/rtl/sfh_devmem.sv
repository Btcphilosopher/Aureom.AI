// SPDX-License-Identifier: MIT
// SilicaFlux HSI v2 — device-local memory (behavioural single-port SRAM model, 1-cycle read).
// Stand-in for the card's SRAM/DRAM; partitioned by the front-end into one window per context.
`timescale 1ns/1ps
module sfh_devmem #(
  parameter int MAW = 19
) (
  input  logic           clk,
  input  logic           en,
  input  logic           we,
  input  logic [MAW-1:0] addr,
  input  logic [63:0]    wdata,
  output logic [63:0]    rdata
);
  logic [63:0] mem [0:(1 << MAW) - 1];
  always_ff @(posedge clk) begin
    if (en) begin
      if (we) mem[addr] <= wdata;
      rdata <= mem[addr];
    end
  end
endmodule
