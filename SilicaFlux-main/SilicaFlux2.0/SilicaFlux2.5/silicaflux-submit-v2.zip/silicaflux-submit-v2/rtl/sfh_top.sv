// SPDX-License-Identifier: MIT
// -----------------------------------------------------------------------------
// SilicaFlux HSI v2 — device top. The "transport boundary" of the design:
//   MMIO in, DMA read requests/responses, one ordered posted-write channel
//   (memory writes + interrupt messages), device timebase in.
// In simulation the boundary is driven by sim/sfh_cosim.cpp; on hardware by
// adapter/sfh_ep_axi_adapter.sv in front of a PCIe endpoint IP.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfh_top
  import sfh_pkg::*;
#(
  parameter int NQ        = SFH_NQ,
  parameter int MAX_CTX   = SFH_MAX_CTX,
  parameter int N_ATT     = SFH_N_ATT,
  parameter int FETCH_MAX = SFH_FETCH_MAX,
  parameter int WIN_LOG2  = SFH_WIN_LOG2,
  parameter int RESET_NS  = 200,
  parameter int MUTANT    = 0
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [63:0] now,
  input  logic        mmio_wr_valid,
  input  logic [15:0] mmio_wr_addr,
  input  logic [31:0] mmio_wr_data,
  input  logic        mmio_rd_valid,
  input  logic [15:0] mmio_rd_addr,
  output logic        mmio_rd_resp_valid,
  output logic [31:0] mmio_rd_data,
  output logic        rd_req_valid,
  input  logic        rd_req_ready,
  output logic [63:0] rd_req_addr,
  output logic [9:0]  rd_req_len,
  input  logic        rd_rsp_valid,
  input  logic [63:0] rd_rsp_data,
  input  logic        rd_rsp_err,
  output logic        wr_valid,
  input  logic        wr_ready,
  output logic [63:0] wr_addr,
  output logic [63:0] wr_data,
  output logic [7:0]  wr_be,
  output logic        wr_msi,
  input  logic        fi_kernel_hang,
  input  logic        fi_freeze,
  output logic        quiescent,
  output logic [63:0] wake_at,
  output logic        eng_reset_pulse,
  output logic        trc_fetch_v,
  output logic [7:0]  trc_fetch_q,
  output logic [31:0] trc_fetch_seq,
  output logic [7:0]  trc_fetch_n,
  output logic        trc_start_v,
  output logic [7:0]  trc_start_q,
  output logic [31:0] trc_start_seq,
  output logic        trc_end_v,
  output logic [7:0]  trc_end_q,
  output logic [31:0] trc_end_seq,
  output logic [6:0]  trc_end_status,
  output logic        trc_cqe_v,
  output logic [7:0]  trc_cqe_q,
  output logic [31:0] trc_cqe_seq
);
  sfh_core #(.NQ(NQ), .MAX_CTX(MAX_CTX), .N_ATT(N_ATT), .FETCH_MAX(FETCH_MAX),
             .WIN_LOG2(WIN_LOG2), .RESET_NS(RESET_NS), .MUTANT(MUTANT)) u_core (.*);
endmodule
