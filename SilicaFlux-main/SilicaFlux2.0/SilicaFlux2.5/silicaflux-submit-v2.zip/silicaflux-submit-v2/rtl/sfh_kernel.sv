// SPDX-License-Identifier: MIT
// -----------------------------------------------------------------------------
// SilicaFlux HSI v2 — kernel unit (stand-in for the compute fabric)
//
// The submission path needs *something* to execute with real side effects and a
// controllable duration; the SF-G1 compute fabric is out of scope here. Ops:
//   KOP_ADD32  dst[i] = src[i] + k   (two u32 lanes per 64-bit word)   2 cycles/word
//   KOP_XOR64  dst[i] = src[i] ^ k                                     2 cycles/word
//   KOP_SUM32  result = sum of u32 lanes of src                        1 cycle/word
//   KOP_SPIN   busy for `k` ns of device timebase (models long compute)
// `hang` (simulation fault input) stalls the unit; only `abort` gets it out —
// this is what the execution watchdog and the host-side recovery are tested with.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfh_kernel #(
  parameter int MAW = 19
) (
  input  logic           clk,
  input  logic           rst_n,
  input  logic [63:0]    now,
  input  logic           start,
  input  logic [7:0]     kop,
  input  logic [MAW-1:0] src,
  input  logic [MAW-1:0] dst,
  input  logic [31:0]    len,        // bytes, multiple of 8
  input  logic [63:0]    k,
  input  logic           abort,
  input  logic           ack,
  input  logic           hang,
  output logic           idle,
  output logic           fin,
  output logic           aborted,
  output logic [31:0]    result,
  output logic           quiet,
  output logic [63:0]    wake_at,
  output logic           m_en,
  output logic           m_we,
  output logic [MAW-1:0] m_addr,
  output logic [63:0]    m_wdata,
  input  logic [63:0]    m_rdata
);
  typedef enum logic [1:0] { K_IDLE, K_RUN, K_FIN } kstate_t;
  kstate_t st;
  logic [7:0]     op;
  logic [MAW-1:0] sp, dp;
  logic [31:0]    words, rd_i, wr_i;
  logic [63:0]    kk, t_end;
  logic           ph, inflight;

  wire is_rw   = (op == 8'd0) || (op == 8'd1);
  wire is_sum  = (op == 8'd2);
  wire is_spin = (op == 8'd3);

  function automatic logic [63:0] apply(input logic [63:0] x);
    if (op == 8'd0) apply = {x[63:32] + kk[31:0], x[31:0] + kk[31:0]};
    else            apply = x ^ kk;
  endfunction

  always_comb begin
    m_en = 1'b0; m_we = 1'b0; m_addr = '0; m_wdata = '0;
    if (st == K_RUN && !hang && !abort) begin
      if (is_rw) begin
        if (!ph && rd_i < words) begin m_en = 1'b1; m_addr = sp; end
        else if (ph)             begin m_en = 1'b1; m_we = 1'b1; m_addr = dp; m_wdata = apply(m_rdata); end
      end else if (is_sum && rd_i < words) begin
        m_en = 1'b1; m_addr = sp;
      end
    end
  end

  assign idle    = (st == K_IDLE);
  assign fin     = (st == K_FIN);
  assign quiet   = (st != K_RUN) || hang || (is_spin && now < t_end && !abort);
  assign wake_at = (st == K_RUN && is_spin && !hang) ? t_end : 64'hFFFF_FFFF_FFFF_FFFF;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= K_IDLE; op <= '0; sp <= '0; dp <= '0; words <= '0; rd_i <= '0; wr_i <= '0;
      kk <= '0; t_end <= '0; ph <= 1'b0; inflight <= 1'b0; result <= '0; aborted <= 1'b0;
    end else begin
      case (st)
        K_IDLE: if (start) begin
          op <= kop; sp <= src; dp <= dst; words <= len >> 3; rd_i <= '0; wr_i <= '0;
          kk <= k; t_end <= now + k; ph <= 1'b0; inflight <= 1'b0; result <= '0; aborted <= 1'b0;
          st <= K_RUN;
        end
        K_RUN:
          if (abort) begin
            aborted <= 1'b1; st <= K_FIN;
          end else if (!hang) begin
            if (is_spin) begin
              if (now >= t_end) st <= K_FIN;
            end else if (is_rw) begin
              if (!ph) begin
                if (rd_i < words) begin sp <= sp + 1'b1; rd_i <= rd_i + 32'd1; ph <= 1'b1; end
                else st <= K_FIN;
              end else begin
                dp <= dp + 1'b1; wr_i <= wr_i + 32'd1; ph <= 1'b0;
              end
            end else begin   // SUM32
              if (inflight) result <= result + m_rdata[31:0] + m_rdata[63:32];
              inflight <= (rd_i < words);
              if (rd_i < words) begin sp <= sp + 1'b1; rd_i <= rd_i + 32'd1; end
              else if (!inflight) st <= K_FIN;
            end
          end
        K_FIN: if (ack) st <= K_IDLE;
        default: st <= K_IDLE;
      endcase
    end
  end
endmodule
