// SPDX-License-Identifier: MIT
// -----------------------------------------------------------------------------
// SilicaFlux HSI v2 — host submission front-end (device side)
//
// Implements docs/CONTRACT.md. One module so that every ordering decision is in
// one place:
//   * BAR0 CSR file, per-queue privileged registers, per-queue doorbell pages
//   * NQ submission/completion queue pairs, round-robin arbitration
//   * batched descriptor fetch (up to FETCH_MAX per read, never across the wrap)
//   * descriptor v2 validation in a fixed precedence order (magic/version,
//     check dword, epoch, seq, opcode, args, handle, permission, alignment,
//     bounds, fence order)
//   * driver-authorised DMA: every host address comes from the mapping table
//     (ATT) the kernel driver programs; descriptors carry {index, generation}
//   * phase-tagged CQEs: dw0..dw2 first, dw3 (phase|status|seq_lo|sq_head) LAST,
//     in its own write; CQ back-pressure (never overwrites an unconsumed CQE)
//   * per-queue interrupt moderation (count + time), one-shot arming, urgent
//     bypass for errors and FLAG_IRQ_NOW; MSI issued on the same ordered
//     channel as, and after, the CQE writes it covers
//   * fences (timeline signal with host write; cross-queue wait with timeout)
//   * execution watchdog, queue reset / engine reset / function reset with
//     STARTED/COMPLETED/ERR snapshots for host-side classification
//   * device-memory scrub, ATT invalidation + sync handshake
//   * trace port and quiescent/wake_at outputs for the co-simulation scheduler
//
// MUTANT (verification only; 0 in any real build). Each non-zero value removes
// one rule; tests/run_mutants.sh requires the suite to FAIL for every one:
//   1 CQE dw3 written first        2 MSI may overtake the CQE   3 no seq check
//   4 no ATT generation check      5 no ATT owner check          6 no doorbell validation
//   7 moderation timer ignored     8 queue reset reports done before DMA drains
//   9 no live ATT re-check (in datamover)                       10 CQ overwrite allowed
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfh_core
  import sfh_pkg::*;
#(
  parameter int NQ        = SFH_NQ,          // power of two
  parameter int MAX_CTX   = SFH_MAX_CTX,     // power of two
  parameter int N_ATT     = SFH_N_ATT,       // power of two
  parameter int FETCH_MAX = SFH_FETCH_MAX,   // power of two, <= 8 (one read <= 512 B)
  parameter int WIN_LOG2  = SFH_WIN_LOG2,
  parameter int RESET_NS  = 200,
  parameter int MUTANT    = 0
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [63:0] now,                 // device timebase, ns
  // ---- MMIO (BAR0) ----
  input  logic        mmio_wr_valid,
  input  logic [15:0] mmio_wr_addr,
  input  logic [31:0] mmio_wr_data,
  input  logic        mmio_rd_valid,
  input  logic [15:0] mmio_rd_addr,
  output logic        mmio_rd_resp_valid,
  output logic [31:0] mmio_rd_data,
  // ---- host read port: requests, in-order response beats ----
  output logic        rd_req_valid,
  input  logic        rd_req_ready,
  output logic [63:0] rd_req_addr,
  output logic [9:0]  rd_req_len,
  input  logic        rd_rsp_valid,
  input  logic [63:0] rd_rsp_data,
  input  logic        rd_rsp_err,
  // ---- ordered posted-write channel: memory writes and interrupt messages ----
  output logic        wr_valid,
  input  logic        wr_ready,
  output logic [63:0] wr_addr,
  output logic [63:0] wr_data,
  output logic [7:0]  wr_be,
  output logic        wr_msi,              // 1 = interrupt message, vector in wr_data[7:0]
  // ---- simulation-only fault inputs (tie to 0 in hardware) ----
  input  logic        fi_kernel_hang,
  input  logic        fi_freeze,
  // ---- co-simulation scheduling ----
  output logic        quiescent,
  output logic [63:0] wake_at,
  output logic        eng_reset_pulse,
  // ---- trace (verification / benchmarking only) ----
  output logic        trc_fetch_v,
  output logic [7:0]  trc_fetch_q,
  output logic [31:0] trc_fetch_seq,
  output logic [7:0]  trc_fetch_n,
  output logic        trc_start_v,
  output logic [7:0]  trc_start_q,
  output logic [31:0] trc_start_seq,
  output logic        trc_end_v,
  output logic [7:0]  trc_end_q,
  output logic [31:0] trc_end_seq,
  output logic [6:0]  trc_end_status,
  output logic        trc_cqe_v,
  output logic [7:0]  trc_cqe_q,
  output logic [31:0] trc_cqe_seq
);
  localparam int QW  = (NQ > 1) ? $clog2(NQ) : 1;
  localparam int AW  = (N_ATT > 1) ? $clog2(N_ATT) : 1;
  localparam int CW  = (MAX_CTX > 1) ? $clog2(MAX_CTX) : 1;
  localparam int MAW = WIN_LOG2 - 3 + CW;           // device-memory word address bits
  localparam int BW  = $clog2(FETCH_MAX) + 1;       // holds 0..FETCH_MAX
  localparam int NB  = FETCH_MAX * 8;               // 64-bit beats in the descriptor buffer
  localparam int NBW = $clog2(NB) + 1;
  localparam int SW  = WIN_LOG2 - 3;                // scrub word counter bits
  localparam logic [63:0] WIN   = 64'd1 << WIN_LOG2;
  localparam logic [63:0] NEVER = 64'hFFFF_FFFF_FFFF_FFFF;
  localparam logic [6:0]  ST_ABORTED_TRACE = 7'h7F;  // trace only: aborted by reset, no CQE

  typedef enum logic [3:0] {
    S_IDLE, S_FETCH_REQ, S_FETCH_DATA, S_DECODE, S_EXEC, S_EXEC_ABORT,
    S_FENCE_WR, S_CQE, S_COMMIT, S_ABORT, S_SCRUB
  } state_t;
  state_t st;

  typedef enum logic [2:0] { K_DONE, K_DM, K_KU, K_FSIG, K_FWAIT } kind_t;
  localparam logic [1:0] U_NONE = 2'd0, U_DM = 2'd1, U_KU = 2'd2;

  // ======================= architectural state =======================
  // per-queue configuration (writable only while the queue is disabled)
  logic [63:0] q_sqb   [0:NQ-1];
  logic [63:0] q_cqb   [0:NQ-1];
  logic [63:0] q_fen   [0:NQ-1];
  logic [3:0]  q_sql2  [0:NQ-1];
  logic [3:0]  q_cql2  [0:NQ-1];
  logic [3:0]  q_ctx   [0:NQ-1];
  logic [15:0] q_epoch [0:NQ-1];
  logic [31:0] q_seqb  [0:NQ-1];
  logic [31:0] q_icnt  [0:NQ-1];
  logic [31:0] q_itime [0:NQ-1];
  logic [63:0] q_tl    [0:NQ-1];
  // per-queue run state
  logic        q_en    [0:NQ-1];
  logic        q_halt  [0:NQ-1];
  logic        q_rdone [0:NQ-1];
  logic        q_wait  [0:NQ-1];
  logic        q_wexp  [0:NQ-1];
  logic        q_cfgerr[0:NQ-1];
  logic        q_armed [0:NQ-1];
  logic        q_urgent[0:NQ-1];
  logic        q_rstreq[0:NQ-1];
  logic        q_errv  [0:NQ-1];
  logic [6:0]  q_errst [0:NQ-1];
  logic [15:0] q_sqh   [0:NQ-1];
  logic [15:0] q_sqt   [0:NQ-1];
  logic [15:0] q_cqh   [0:NQ-1];
  logic [15:0] q_cqt   [0:NQ-1];
  logic [31:0] q_exp   [0:NQ-1];
  logic [31:0] q_started  [0:NQ-1];
  logic [31:0] q_completed[0:NQ-1];
  logic [31:0] q_errseq[0:NQ-1];
  logic [QW-1:0] q_wtgt[0:NQ-1];
  logic [63:0] q_wval  [0:NQ-1];
  logic [63:0] q_wdl   [0:NQ-1];
  logic [15:0] q_pend  [0:NQ-1];
  logic [63:0] q_fts   [0:NQ-1];
  logic [31:0] q_dberr [0:NQ-1];
  logic [31:0] q_dbdup [0:NQ-1];
  logic [31:0] q_irqc  [0:NQ-1];
  logic [31:0] q_fetchc[0:NQ-1];

  // global
  logic [31:0] scratch, cmd_tmo, fen_tmo, done_cnt, err_cnt, dberr_cnt, rst_cnt;
  logic        reset_active, eng_req, func_req;
  logic [63:0] reset_until;
  logic        scrub_pend;
  logic [CW-1:0] scrub_ctx;
  logic [SW-1:0] scrub_i;

  // ATT (driver-authorised DMA mapping table)
  logic [63:0] att_base [0:N_ATT-1];
  logic [31:0] att_size [0:N_ATT-1];
  logic        att_v    [0:N_ATT-1];
  logic        att_r    [0:N_ATT-1];
  logic        att_w    [0:N_ATT-1];
  logic [3:0]  att_ctx  [0:N_ATT-1];
  logic [15:0] att_gen  [0:N_ATT-1];
  logic [31:0] att_idx_r, stg_base_lo, stg_base_hi, stg_size, stg_ctl;
  logic        sync_pend;
  logic [31:0] sync_tok, sync_ack;

  // current batch / command
  logic [QW-1:0]  cq_i, rr;
  logic [BW-1:0]  bn, bi;
  logic [NBW-1:0] rcv;
  logic           ferr;
  logic [63:0]    dbuf [0:NB-1];
  logic [6:0]     cst;
  logic [31:0]    cres, cseq, ctag;
  logic [7:0]     cflags;
  logic [1:0]     cunit;
  logic [AW-1:0]  chidx;
  logic [15:0]    chgen;
  logic [63:0]    wd_dl, fval;
  logic [1:0]     cbeat;

  // unit control registers
  logic           dm_start, dm_d2h, ku_start;
  logic [63:0]    dm_haddr, ku_k;
  logic [MAW-1:0] dm_dw, ku_src, ku_dst;
  logic [31:0]    dm_len, ku_len;
  logic [7:0]     ku_op;

  // ======================= helpers =======================
  function automatic logic [15:0] qents(input logic [3:0] l2);
    qents = 16'd1 << l2;
  endfunction
  function automatic logic [15:0] qmask(input logic [3:0] l2);
    qmask = (16'd1 << l2) - 16'd1;
  endfunction
  function automatic logic in_win(input logic [63:0] off, input logic [31:0] l);
    in_win = (off <= WIN) && ({32'd0, l} <= WIN - off);
  endfunction

  wire [QW-1:0] q = cq_i;
  logic any_rstreq;
  always_comb begin
    any_rstreq = 1'b0;
    for (int i = 0; i < NQ; i++) if (q_rstreq[i]) any_rstreq = 1'b1;
  end

  // ======================= descriptor decode (current batch slot) =======================
  logic [31:0] d [0:15];
  always_comb begin
    for (int j = 0; j < 8; j++) begin
      d[2*j]   = dbuf[int'(bi) * 8 + j][31:0];
      d[2*j+1] = dbuf[int'(bi) * 8 + j][63:32];
    end
  end
  wire [7:0]  d_magic = d[0][7:0];
  wire [7:0]  d_ver   = d[0][15:8];
  wire [7:0]  d_op    = d[0][23:16];
  wire [7:0]  d_flags = d[0][31:24];
  wire [31:0] d_seq   = d[1];
  wire [15:0] d_epoch = d[2][15:0];
  wire [15:0] d_rsv2  = d[2][31:16];
  wire [31:0] d_tag   = d[3];
  wire [31:0] d_hdl   = d[4];
  wire [15:0] d_hidx  = d[4][15:0];
  wire [15:0] d_hgen  = d[4][31:16];
  wire [31:0] d_len   = d[5];
  wire [63:0] d_hoff  = {d[7], d[6]};
  wire [63:0] d_doff  = {d[9], d[8]};
  wire [63:0] d_doff2 = {d[11], d[10]};
  wire [63:0] d_p0    = {d[13], d[12]};
  wire [31:0] d_p1    = d[14];
  logic [31:0] d_xor;
  always_comb begin
    d_xor = 32'd0;
    for (int j = 0; j < 16; j++) d_xor = d_xor ^ d[j];
  end

  wire [AW-1:0] hix      = d_hidx[AW-1:0];
  wire          h_inrng  = (d_hidx < 16'(N_ATT));
  wire [63:0]   a_size   = {32'd0, att_size[hix]};
  wire [3:0]    qctx     = q_ctx[q];
  wire [QW-1:0] w_tgt    = d_p1[QW-1:0];
  wire [7:0]    kop      = d_p1[7:0];

  logic [6:0] v_st;
  kind_t      v_kind;
  always_comb begin : validate
    logic is_copy, is_h2d, uses_h, args_ok, perm_ok, align_ok, bounds_ok, rw_kop;
    is_copy = (d_op == SFH_OP_COPY_H2D) || (d_op == SFH_OP_COPY_D2H);
    is_h2d  = (d_op == SFH_OP_COPY_H2D);
    uses_h  = is_copy;
    rw_kop  = (kop == SFH_KOP_ADD32) || (kop == SFH_KOP_XOR64);
    // ---- unused/reserved fields must be zero, per opcode ----
    args_ok = ((d_flags & ~SFH_FLAGS_VALID) == 8'd0) && (d_rsv2 == 16'd0);
    case (d_op)
      SFH_OP_NOP:
        args_ok = args_ok && d_hdl == 0 && d_len == 0 && d_hoff == 0 && d_doff == 0 &&
                  d_doff2 == 0 && d_p0 == 0 && d_p1 == 0;
      SFH_OP_COPY_H2D, SFH_OP_COPY_D2H:
        args_ok = args_ok && d_len != 0 && d_doff2 == 0 && d_p0 == 0 && d_p1 == 0;
      SFH_OP_KERNEL: begin
        args_ok = args_ok && d_hdl == 0 && d_hoff == 0 && d_p1[31:8] == 24'd0 &&
                  kop < 8'(SFH_KOP_COUNT);
        if (rw_kop)                     args_ok = args_ok && d_len != 0;
        else if (kop == SFH_KOP_SUM32)  args_ok = args_ok && d_len != 0 && d_doff2 == 0 && d_p0 == 0;
        else                            args_ok = args_ok && d_len == 0 && d_doff == 0 && d_doff2 == 0;
      end
      SFH_OP_FENCE_SIGNAL:
        args_ok = args_ok && d_hdl == 0 && d_len == 0 && d_hoff == 0 && d_doff == 0 &&
                  d_doff2 == 0 && d_p1 == 0;
      SFH_OP_FENCE_WAIT:
        args_ok = args_ok && d_hdl == 0 && d_len == 0 && d_hoff == 0 && d_doff == 0 &&
                  d_doff2 == 0 && d_p1[31:8] == 24'd0 && d_p1[7:0] < 8'(NQ);
      default: args_ok = 1'b0;
    endcase
    // ---- ownership and permission ----
    perm_ok = 1'b1;
    if (is_copy)
      perm_ok = ((MUTANT == 5) || (att_ctx[hix] == qctx)) && (is_h2d ? att_r[hix] : att_w[hix]);
    else if (d_op == SFH_OP_FENCE_WAIT)
      perm_ok = (q_ctx[w_tgt] == qctx);
    // ---- alignment ----
    align_ok = 1'b1;
    if (is_copy)
      align_ok = d_hoff[2:0] == 0 && d_doff[2:0] == 0 && d_len[2:0] == 0;
    else if (d_op == SFH_OP_KERNEL && rw_kop)
      align_ok = d_doff[2:0] == 0 && d_doff2[2:0] == 0 && d_len[2:0] == 0;
    else if (d_op == SFH_OP_KERNEL && kop == SFH_KOP_SUM32)
      align_ok = d_doff[2:0] == 0 && d_len[2:0] == 0;
    // ---- bounds (overflow-safe: off <= size && len <= size - off) ----
    bounds_ok = 1'b1;
    if (is_copy)
      bounds_ok = (d_hoff <= a_size) && ({32'd0, d_len} <= a_size - d_hoff) && in_win(d_doff, d_len);
    else if (d_op == SFH_OP_KERNEL && rw_kop)
      bounds_ok = in_win(d_doff, d_len) && in_win(d_doff2, d_len);
    else if (d_op == SFH_OP_KERNEL && kop == SFH_KOP_SUM32)
      bounds_ok = in_win(d_doff, d_len);

    v_kind = K_DONE;
    case (d_op)
      SFH_OP_COPY_H2D, SFH_OP_COPY_D2H: v_kind = K_DM;
      SFH_OP_KERNEL:                     v_kind = K_KU;
      SFH_OP_FENCE_SIGNAL:               v_kind = K_FSIG;
      SFH_OP_FENCE_WAIT:                 v_kind = K_FWAIT;
      default:                           v_kind = K_DONE;
    endcase

    // ---- fixed precedence ----
    if (!(d_magic == SFH_DESC_MAGIC[7:0] && d_ver < 8'd32 && SFH_DESC_VERSIONS[d_ver[4:0]]))
      v_st = SFH_ST_BAD_VERSION;
    else if (d_xor != SFH_DESC_CHECK_SALT)                 v_st = SFH_ST_BAD_CHECK;
    else if (d_epoch != q_epoch[q])                        v_st = SFH_ST_STALE_EPOCH;
    else if ((MUTANT != 3) && (d_seq != q_exp[q]))         v_st = SFH_ST_STALE_SEQ;
    else if (d_op >= 8'(SFH_OP_COUNT))                     v_st = SFH_ST_BAD_OPCODE;
    else if (!args_ok)                                     v_st = SFH_ST_BAD_ARGS;
    else if (uses_h && !(h_inrng && att_v[hix] && ((MUTANT == 4) || att_gen[hix] == d_hgen)))
      v_st = SFH_ST_BAD_HANDLE;
    else if (!perm_ok)                                     v_st = SFH_ST_PERM;
    else if (!align_ok)                                    v_st = SFH_ST_ALIGN;
    else if (!bounds_ok)                                   v_st = SFH_ST_BOUNDS;
    else if (d_op == SFH_OP_FENCE_SIGNAL && !(d_p0 > q_tl[q])) v_st = SFH_ST_FENCE_ORDER;
    else                                                   v_st = SFH_ST_OK;
  end

  // ======================= eligibility / arbitration =======================
  logic [NQ-1:0] elig, cq_space;
  always_comb begin
    for (int i = 0; i < NQ; i++) begin
      cq_space[i] = (MUTANT == 10) ? 1'b1 : ((16'(q_cqt[i] - q_cqh[i])) < qents(q_cql2[i]));
      elig[i] = q_en[i] && !q_halt[i] && !q_wait[i] && !q_rstreq[i] && (q_sqt[i] != q_sqh[i]) &&
                cq_space[i] && !reset_active && !eng_req && !func_req;
    end
  end
  logic          arb_found;
  logic [QW-1:0] arb_q;
  always_comb begin
    arb_found = 1'b0; arb_q = '0;
    for (int k = 1; k <= NQ; k++) begin
      logic [QW-1:0] qq;
      qq = rr + QW'(k);
      if (!arb_found && elig[qq]) begin arb_found = 1'b1; arb_q = qq; end
    end
  end
  wire [15:0] a_avail  = q_sqt[arb_q] - q_sqh[arb_q];
  wire [15:0] a_towrap = qents(q_sql2[arb_q]) - (q_sqh[arb_q] & qmask(q_sql2[arb_q]));
  logic [BW-1:0] a_bn;
  always_comb begin
    logic [15:0] m;
    m = (a_avail < a_towrap) ? a_avail : a_towrap;
    a_bn = (m < 16'(FETCH_MAX)) ? BW'(m) : BW'(FETCH_MAX);
  end

  // ======================= interrupt moderation =======================
  logic [NQ-1:0] fire;
  logic          msi_any;
  logic [QW-1:0] msi_q;
  logic [63:0]   mod_wake;
  always_comb begin
    msi_any = 1'b0; msi_q = '0; mod_wake = NEVER;
    for (int i = 0; i < NQ; i++) begin
      logic tmo;
      tmo = (MUTANT != 7) && (q_itime[i] != 0) && (now - q_fts[i] >= {32'd0, q_itime[i]});
      fire[i] = q_armed[i] && (q_pend[i] != 0) &&
                (q_urgent[i] || q_icnt[i] <= 32'd1 || {16'd0, q_pend[i]} >= q_icnt[i] || tmo);
      if (fire[i] && !msi_any) begin msi_any = 1'b1; msi_q = QW'(i); end
      if (q_armed[i] && q_pend[i] != 0 && !fire[i] && q_itime[i] != 0 && MUTANT != 7)
        if (q_fts[i] + {32'd0, q_itime[i]} < mod_wake) mod_wake = q_fts[i] + {32'd0, q_itime[i]};
    end
  end

  // ======================= submodules =======================
  logic           dm_idle, dm_fin, dm_quiet, dm_rd_valid, dm_wr_valid, dm_m_en, dm_m_we;
  logic [1:0]     dm_res;
  logic [63:0]    dm_rd_addr, dm_wr_addr, dm_wr_data, dm_m_wdata;
  logic [9:0]     dm_rd_len;
  logic [MAW-1:0] dm_m_addr;
  logic           ku_idle, ku_fin, ku_aborted, ku_quiet, ku_m_en, ku_m_we;
  logic [31:0]    ku_result;
  logic [63:0]    ku_wake, ku_m_wdata;
  logic [MAW-1:0] ku_m_addr;
  logic           m_en, m_we;
  logic [MAW-1:0] m_addr;
  logic [63:0]    m_wdata, m_rdata;

  wire in_exec   = (st == S_EXEC) || (st == S_EXEC_ABORT) || (st == S_ABORT);
  wire u_abort   = (st == S_EXEC_ABORT) || (st == S_ABORT);
  wire freezable = (st == S_IDLE) || (st == S_DECODE) || (st == S_EXEC) || (st == S_COMMIT);
  wire frozen    = fi_freeze && freezable;
  wire rst_cond  = q_rstreq[q] || eng_req || func_req;
  wire unit_fin  = (cunit == U_DM) ? dm_fin : (cunit == U_KU) ? ku_fin : 1'b0;
  wire unit_quiet= !dm_start && !ku_start && ((cunit == U_DM) ? dm_quiet : (cunit == U_KU) ? ku_quiet : 1'b1);
  wire u_ack     = unit_fin && (((st == S_EXEC) && !frozen && !rst_cond) ||
                                (st == S_EXEC_ABORT) || (st == S_ABORT));
  wire att_live  = att_v[chidx] && (att_gen[chidx] == chgen);
  wire dm_busy   = (cunit == U_DM) && (in_exec || dm_start);

  sfh_datamover #(.MAW(MAW), .MAX_RD(SFH_MAX_RD_BYTES), .MUTANT(MUTANT)) u_dm (
    .clk, .rst_n, .start(dm_start), .d2h(dm_d2h), .haddr(dm_haddr), .dwaddr(dm_dw), .len(dm_len),
    .abort(u_abort && cunit == U_DM), .att_ok(att_live), .ack(u_ack && cunit == U_DM),
    .idle(dm_idle), .fin(dm_fin), .res(dm_res), .quiet(dm_quiet),
    .rd_req_valid(dm_rd_valid), .rd_req_ready(rd_req_ready && st != S_FETCH_REQ),
    .rd_req_addr(dm_rd_addr), .rd_req_len(dm_rd_len),
    .rd_rsp_valid(rd_rsp_valid && st != S_FETCH_DATA), .rd_rsp_data, .rd_rsp_err,
    .wr_valid(dm_wr_valid), .wr_ready(wr_ready), .wr_addr(dm_wr_addr), .wr_data(dm_wr_data),
    .m_en(dm_m_en), .m_we(dm_m_we), .m_addr(dm_m_addr), .m_wdata(dm_m_wdata), .m_rdata);

  sfh_kernel #(.MAW(MAW)) u_ku (
    .clk, .rst_n, .now, .start(ku_start), .kop(ku_op), .src(ku_src), .dst(ku_dst), .len(ku_len),
    .k(ku_k), .abort(u_abort && cunit == U_KU), .ack(u_ack && cunit == U_KU), .hang(fi_kernel_hang),
    .idle(ku_idle), .fin(ku_fin), .aborted(ku_aborted), .result(ku_result), .quiet(ku_quiet),
    .wake_at(ku_wake), .m_en(ku_m_en), .m_we(ku_m_we), .m_addr(ku_m_addr), .m_wdata(ku_m_wdata),
    .m_rdata);

  sfh_devmem #(.MAW(MAW)) u_mem (.clk, .en(m_en), .we(m_we), .addr(m_addr), .wdata(m_wdata), .rdata(m_rdata));

  always_comb begin
    m_en = 1'b0; m_we = 1'b0; m_addr = '0; m_wdata = '0;
    if (st == S_SCRUB) begin
      m_en = 1'b1; m_we = 1'b1; m_addr = {scrub_ctx, scrub_i};
    end else if (cunit == U_DM) begin
      m_en = dm_m_en; m_we = dm_m_we; m_addr = dm_m_addr; m_wdata = dm_m_wdata;
    end else if (cunit == U_KU) begin
      m_en = ku_m_en; m_we = ku_m_we; m_addr = ku_m_addr; m_wdata = ku_m_wdata;
    end
  end

  // ======================= host read port mux =======================
  always_comb begin
    if (st == S_FETCH_REQ) begin
      rd_req_valid = 1'b1;
      rd_req_addr  = q_sqb[q] + {42'd0, (q_sqh[q] & qmask(q_sql2[q])), 6'd0};
      rd_req_len   = {bn, 6'd0};
    end else begin
      rd_req_valid = dm_rd_valid && (cunit == U_DM) && in_exec;
      rd_req_addr  = dm_rd_addr;
      rd_req_len   = dm_rd_len;
    end
  end

  // ======================= ordered write channel mux =======================
  wire        cneed   = !(cflags[0] && cst == SFH_ST_OK);   // FLAG_SUPPRESS_CQE only hides successes
  wire [15:0] cq_slot = q_cqt[q] & qmask(q_cql2[q]);
  wire        cq_ph   = ~q_cqt[q][q_cql2[q]];
  wire [63:0] cq_addr = q_cqb[q] + {44'd0, cq_slot, 4'd0};
  wire [15:0] sqh_nx  = q_sqh[q] + 16'd1;
  wire [31:0] cqe_dw3 = {sqh_nx, cseq[7:0], cst, cq_ph};
  wire        fe_wr_valid = ((st == S_CQE) && cneed) || (st == S_FENCE_WR);
  // write order within one CQE: beat 0 = {dw1,dw0}, beat 1 = dw2, beat 2 = dw3 (LAST)
  wire [1:0]  beat = (MUTANT == 1) ? ((cbeat == 2'd0) ? 2'd2 : cbeat - 2'd1) : cbeat;
  logic sel_dm, sel_fe, sel_msi;
  always_comb begin
    sel_dm = 1'b0; sel_fe = 1'b0; sel_msi = 1'b0;
    wr_addr = '0; wr_data = '0; wr_be = '0; wr_msi = 1'b0;
    if (dm_wr_valid && cunit == U_DM && in_exec) begin
      sel_dm = 1'b1; wr_addr = dm_wr_addr; wr_data = dm_wr_data; wr_be = 8'hFF;
    end else if (fe_wr_valid && !(MUTANT == 2 && msi_any)) begin
      sel_fe = 1'b1;
      if (st == S_FENCE_WR) begin
        wr_addr = q_fen[q]; wr_data = fval; wr_be = 8'hFF;
      end else begin
        case (beat)
          2'd0:    begin wr_addr = cq_addr;         wr_data = {ctag, cres};    wr_be = 8'hFF; end
          2'd1:    begin wr_addr = cq_addr + 64'd8; wr_data = {32'd0, cseq};   wr_be = 8'h0F; end
          default: begin wr_addr = cq_addr + 64'd8; wr_data = {cqe_dw3, 32'd0}; wr_be = 8'hF0; end
        endcase
      end
    end else if (msi_any) begin
      sel_msi = 1'b1; wr_msi = 1'b1; wr_data = {56'd0, 8'(msi_q)};
    end
  end
  assign wr_valid = sel_dm || sel_fe || sel_msi;
  wire fe_acc  = sel_fe && wr_ready;
  wire msi_acc = sel_msi && wr_ready;

  // ======================= CSR read mux =======================
  wire        rq_hit = (mmio_rd_addr >= SFH_QREG_BASE) && (mmio_rd_addr < SFH_QREG_BASE + 16'(NQ * 128));
  wire [15:0] rq_rel = mmio_rd_addr - SFH_QREG_BASE;
  wire [QW-1:0] rqi  = rq_rel[7+QW-1:7];
  wire [7:0]  rqo    = {1'b0, rq_rel[6:0]};
  logic [31:0] csr_rdata;
  always_comb begin
    csr_rdata = 32'd0;
    if (rq_hit) begin
      case (rqo)
        SFH_QSQ_BASE_LO:    csr_rdata = q_sqb[rqi][31:0];
        SFH_QSQ_BASE_HI:    csr_rdata = q_sqb[rqi][63:32];
        SFH_QCQ_BASE_LO:    csr_rdata = q_cqb[rqi][31:0];
        SFH_QCQ_BASE_HI:    csr_rdata = q_cqb[rqi][63:32];
        SFH_QFENCE_LO:      csr_rdata = q_fen[rqi][31:0];
        SFH_QFENCE_HI:      csr_rdata = q_fen[rqi][63:32];
        SFH_QSIZE:          csr_rdata = {20'd0, q_cql2[rqi], 4'd0, q_sql2[rqi]};
        SFH_QCFG:           csr_rdata = {q_epoch[rqi], 12'd0, q_ctx[rqi]};
        SFH_QSEQ_BASE:      csr_rdata = q_seqb[rqi];
        SFH_QIMOD_CNT:      csr_rdata = q_icnt[rqi];
        SFH_QIMOD_TIME:     csr_rdata = q_itime[rqi];
        SFH_QSTATUS:        csr_rdata = {16'd0, 1'b0, q_errst[rqi], q_errv[rqi], q_armed[rqi],
                                         (st != S_IDLE && cq_i == rqi), q_cfgerr[rqi], q_wait[rqi],
                                         q_rdone[rqi], q_halt[rqi], q_en[rqi]};
        SFH_QSTARTED_SEQ:   csr_rdata = q_started[rqi];
        SFH_QCOMPLETED_SEQ: csr_rdata = q_completed[rqi];
        SFH_QERR_SEQ:       csr_rdata = q_errseq[rqi];
        SFH_QSQPOS:         csr_rdata = {q_sqt[rqi], q_sqh[rqi]};
        SFH_QCQPOS:         csr_rdata = {q_cqt[rqi], q_cqh[rqi]};
        SFH_QTIMELINE_LO:   csr_rdata = q_tl[rqi][31:0];
        SFH_QTIMELINE_HI:   csr_rdata = q_tl[rqi][63:32];
        SFH_QDB_ERR:        csr_rdata = q_dberr[rqi];
        SFH_QDB_DUP:        csr_rdata = q_dbdup[rqi];
        SFH_QIRQ_COUNT:     csr_rdata = q_irqc[rqi];
        SFH_QFETCH_COUNT:   csr_rdata = q_fetchc[rqi];
        default:            csr_rdata = 32'd0;
      endcase
    end else begin
      case (mmio_rd_addr)
        SFH_REG_ID:            csr_rdata = SFH_CHIP_ID;
        SFH_REG_HW_VERSION:    csr_rdata = SFH_HW_VERSION;
        SFH_REG_CAPS:          csr_rdata = 32'h3FF;
        SFH_REG_DESC_VERSIONS: csr_rdata = SFH_DESC_VERSIONS;
        SFH_REG_LIMITS0:       csr_rdata = {8'(FETCH_MAX), 8'(N_ATT), 8'(MAX_CTX), 8'(NQ)};
        SFH_REG_LIMITS1:       csr_rdata = {8'(SFH_Q_LOG2_MAX), 8'(SFH_Q_LOG2_MIN), 8'(WIN_LOG2), 8'd64};
        SFH_REG_TIMEBASE_LO:   csr_rdata = now[31:0];
        SFH_REG_TIMEBASE_HI:   csr_rdata = now[63:32];
        SFH_REG_STATUS:        csr_rdata = {28'd0, sync_pend, scrub_pend, reset_active, !reset_active};
        SFH_REG_SCRATCH:       csr_rdata = scratch;
        SFH_REG_CMD_TIMEOUT:   csr_rdata = cmd_tmo;
        SFH_REG_FENCE_TIMEOUT: csr_rdata = fen_tmo;
        SFH_REG_DONE_COUNT:    csr_rdata = done_cnt;
        SFH_REG_ERR_COUNT:     csr_rdata = err_cnt;
        SFH_REG_DB_ERR_COUNT:  csr_rdata = dberr_cnt;
        SFH_REG_RESET_COUNT:   csr_rdata = rst_cnt;
        SFH_REG_ATT_IDX:       csr_rdata = att_idx_r;
        SFH_REG_ATT_BASE_LO:   csr_rdata = stg_base_lo;
        SFH_REG_ATT_BASE_HI:   csr_rdata = stg_base_hi;
        SFH_REG_ATT_SIZE:      csr_rdata = stg_size;
        SFH_REG_ATT_CTL:       csr_rdata = stg_ctl;
        SFH_REG_ATT_SYNC_ACK:  csr_rdata = sync_ack;
        default:               csr_rdata = 32'd0;
      endcase
    end
  end

  // ======================= queue enable check =======================
  function automatic logic cfg_ok(input int i);
    cfg_ok = (q_sql2[i] >= 4'(SFH_Q_LOG2_MIN)) && (q_sql2[i] <= 4'(SFH_Q_LOG2_MAX)) &&
             (q_cql2[i] >= 4'(SFH_Q_LOG2_MIN)) && (q_cql2[i] <= 4'(SFH_Q_LOG2_MAX)) &&
             (q_ctx[i] < 4'(MAX_CTX)) &&
             (q_sqb[i] != 0) && (q_sqb[i][5:0] == 0) && (q_cqb[i] != 0) && (q_cqb[i][5:0] == 0) &&
             (q_fen[i] != 0) && (q_fen[i][2:0] == 0) &&
             !((q_icnt[i] > 32'd1) && (q_itime[i] == 32'd0));
  endfunction

  // ======================= main sequential block =======================
  // Same-cycle priority: FSM, then interrupt-message accounting, then MMIO writes.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; cq_i <= '0; rr <= '0; bn <= '0; bi <= '0; rcv <= '0; ferr <= 1'b0;
      cst <= '0; cres <= '0; cseq <= '0; ctag <= '0; cflags <= '0; cunit <= U_NONE;
      chidx <= '0; chgen <= '0; wd_dl <= '0; fval <= '0; cbeat <= '0;
      dm_start <= 1'b0; dm_d2h <= 1'b0; dm_haddr <= '0; dm_dw <= '0; dm_len <= '0;
      ku_start <= 1'b0; ku_op <= '0; ku_src <= '0; ku_dst <= '0; ku_len <= '0; ku_k <= '0;
      scratch <= '0; cmd_tmo <= '0; fen_tmo <= '0; done_cnt <= '0; err_cnt <= '0;
      dberr_cnt <= '0; rst_cnt <= '0; reset_active <= 1'b0; reset_until <= '0;
      eng_req <= 1'b0; func_req <= 1'b0; scrub_pend <= 1'b0; scrub_ctx <= '0; scrub_i <= '0;
      att_idx_r <= '0; stg_base_lo <= '0; stg_base_hi <= '0; stg_size <= '0; stg_ctl <= '0;
      sync_pend <= 1'b0; sync_tok <= '0; sync_ack <= '0;
      mmio_rd_resp_valid <= 1'b0; mmio_rd_data <= '0; eng_reset_pulse <= 1'b0;
      trc_fetch_v <= 1'b0; trc_fetch_q <= '0; trc_fetch_seq <= '0; trc_fetch_n <= '0;
      trc_start_v <= 1'b0; trc_start_q <= '0; trc_start_seq <= '0;
      trc_end_v <= 1'b0; trc_end_q <= '0; trc_end_seq <= '0; trc_end_status <= '0;
      trc_cqe_v <= 1'b0; trc_cqe_q <= '0; trc_cqe_seq <= '0;
      for (int i = 0; i < NB; i++) dbuf[i] <= '0;
      for (int i = 0; i < N_ATT; i++) begin
        att_base[i] <= '0; att_size[i] <= '0; att_v[i] <= 1'b0; att_r[i] <= 1'b0;
        att_w[i] <= 1'b0; att_ctx[i] <= '0; att_gen[i] <= '0;
      end
      for (int i = 0; i < NQ; i++) begin
        q_sqb[i] <= '0; q_cqb[i] <= '0; q_fen[i] <= '0; q_sql2[i] <= '0; q_cql2[i] <= '0;
        q_ctx[i] <= '0; q_epoch[i] <= '0; q_seqb[i] <= '0; q_icnt[i] <= '0; q_itime[i] <= '0;
        q_tl[i] <= '0; q_en[i] <= 1'b0; q_halt[i] <= 1'b0; q_rdone[i] <= 1'b0; q_wait[i] <= 1'b0;
        q_wexp[i] <= 1'b0; q_cfgerr[i] <= 1'b0; q_armed[i] <= 1'b0; q_urgent[i] <= 1'b0;
        q_rstreq[i] <= 1'b0; q_errv[i] <= 1'b0; q_errst[i] <= '0; q_sqh[i] <= '0; q_sqt[i] <= '0;
        q_cqh[i] <= '0; q_cqt[i] <= '0; q_exp[i] <= '0; q_started[i] <= '0; q_completed[i] <= '0;
        q_errseq[i] <= '0; q_wtgt[i] <= '0; q_wval[i] <= '0; q_wdl[i] <= '0; q_pend[i] <= '0;
        q_fts[i] <= '0; q_dberr[i] <= '0; q_dbdup[i] <= '0; q_irqc[i] <= '0; q_fetchc[i] <= '0;
      end
    end else begin : run
      logic        fin_now;
      logic [6:0]  fin_st;
      fin_now = 1'b0; fin_st = SFH_ST_OK;

      // ---- pulses ----
      mmio_rd_resp_valid <= 1'b0;
      dm_start <= 1'b0; ku_start <= 1'b0; eng_reset_pulse <= 1'b0;
      trc_fetch_v <= 1'b0; trc_start_v <= 1'b0; trc_end_v <= 1'b0; trc_cqe_v <= 1'b0;

      // ---- MMIO read: response one cycle after the request ----
      if (mmio_rd_valid) begin mmio_rd_resp_valid <= 1'b1; mmio_rd_data <= csr_rdata; end

      // ---- FENCE_WAIT monitor ----
      for (int i = 0; i < NQ; i++) begin
        if (q_wait[i]) begin
          if (q_tl[q_wtgt[i]] >= q_wval[i]) q_wait[i] <= 1'b0;
          else if (q_wdl[i] != NEVER && now >= q_wdl[i]) begin q_wait[i] <= 1'b0; q_wexp[i] <= 1'b1; end
        end
      end

      // ---- ATT sync: complete once no data transfer can still be using an old translation.
      //      Only the data mover touches host memory through the ATT (kernels never do). ----
      if (sync_pend && !dm_busy) begin sync_ack <= sync_tok; sync_pend <= 1'b0; end

      // ================= command FSM =================
      if (!frozen) begin
        case (st)
          S_IDLE: begin
            if (eng_req || func_req) begin
              for (int i = 0; i < NQ; i++) begin
                q_en[i] <= 1'b0; q_halt[i] <= 1'b0; q_wait[i] <= 1'b0; q_wexp[i] <= 1'b0;
                q_armed[i] <= 1'b0; q_pend[i] <= '0; q_urgent[i] <= 1'b0; q_rstreq[i] <= 1'b0;
                q_rdone[i] <= 1'b1;
                if (func_req) begin
                  q_sqb[i] <= '0; q_cqb[i] <= '0; q_fen[i] <= '0; q_sql2[i] <= '0; q_cql2[i] <= '0;
                  q_ctx[i] <= '0; q_epoch[i] <= '0; q_seqb[i] <= '0; q_icnt[i] <= '0;
                  q_itime[i] <= '0; q_tl[i] <= '0; q_cfgerr[i] <= 1'b0; q_errv[i] <= 1'b0;
                end
              end
              if (func_req) begin
                for (int i = 0; i < N_ATT; i++) att_v[i] <= 1'b0;
                cmd_tmo <= '0; fen_tmo <= '0; sync_pend <= 1'b0; scrub_pend <= 1'b0;
                done_cnt <= '0; err_cnt <= '0; dberr_cnt <= '0;
              end
              reset_active <= 1'b1; reset_until <= now + 64'(RESET_NS);
              eng_req <= 1'b0; func_req <= 1'b0; rst_cnt <= rst_cnt + 32'd1; eng_reset_pulse <= 1'b1;
            end else if (reset_active) begin
              if (now >= reset_until) reset_active <= 1'b0;
            end else if (any_rstreq) begin
              // queue reset: nothing of this queue is in flight while the FSM is idle
              for (int i = 0; i < NQ; i++) if (q_rstreq[i]) begin
                q_en[i] <= 1'b0; q_halt[i] <= 1'b0; q_wait[i] <= 1'b0; q_wexp[i] <= 1'b0;
                q_armed[i] <= 1'b0; q_pend[i] <= '0; q_urgent[i] <= 1'b0; q_rstreq[i] <= 1'b0;
                q_rdone[i] <= 1'b1;
              end
            end else if (scrub_pend) begin
              scrub_i <= '0; st <= S_SCRUB;
            end else if (arb_found) begin
              cq_i <= arb_q; rr <= arb_q; bn <= a_bn; bi <= '0;
              st <= S_FETCH_REQ;
            end
          end

          S_FETCH_REQ: if (rd_req_ready) begin rcv <= '0; ferr <= 1'b0; st <= S_FETCH_DATA; end

          S_FETCH_DATA: if (rd_rsp_valid) begin
            dbuf[rcv[NBW-2:0]] <= rd_rsp_data;
            if (rd_rsp_err) ferr <= 1'b1;
            rcv <= rcv + 1'b1;
            if (rcv == NBW'({bn, 3'd0}) - 1'b1) begin
              trc_fetch_v <= 1'b1; trc_fetch_q <= 8'(q); trc_fetch_seq <= q_exp[q]; trc_fetch_n <= 8'(bn);
              q_fetchc[q] <= q_fetchc[q] + 32'd1;
              bi <= '0; st <= S_DECODE;
            end
          end

          S_DECODE: begin
            if (rst_cond || !q_en[q] || !cq_space[q]) begin
              st <= S_IDLE;                          // abandon the rest of the batch; refetched later
            end else begin
              cseq <= q_exp[q]; ctag <= d_tag; cflags <= ferr ? 8'd0 : d_flags; cres <= '0;
              trc_start_q <= 8'(q); trc_start_seq <= q_exp[q];
              if (ferr) begin
                trc_start_v <= 1'b1; fin_now = 1'b1; fin_st = SFH_ST_DMA_ERROR;
              end else if (v_st != SFH_ST_OK) begin
                trc_start_v <= 1'b1; fin_now = 1'b1; fin_st = v_st;
              end else begin
                case (v_kind)
                  K_DM: begin
                    dm_start <= 1'b1; dm_d2h <= (d_op == SFH_OP_COPY_D2H);
                    dm_haddr <= att_base[hix] + d_hoff; dm_dw <= {qctx[CW-1:0], d_doff[WIN_LOG2-1:3]};
                    dm_len <= d_len; chidx <= hix; chgen <= d_hgen; cunit <= U_DM;
                    q_started[q] <= q_exp[q]; wd_dl <= now + {32'd0, cmd_tmo};
                    trc_start_v <= 1'b1; st <= S_EXEC;
                  end
                  K_KU: begin
                    ku_start <= 1'b1; ku_op <= kop; ku_src <= {qctx[CW-1:0], d_doff[WIN_LOG2-1:3]};
                    ku_dst <= {qctx[CW-1:0], d_doff2[WIN_LOG2-1:3]}; ku_len <= d_len; ku_k <= d_p0;
                    cunit <= U_KU; q_started[q] <= q_exp[q]; wd_dl <= now + {32'd0, cmd_tmo};
                    trc_start_v <= 1'b1; st <= S_EXEC;
                  end
                  K_FSIG: begin
                    q_tl[q] <= d_p0; fval <= d_p0; q_started[q] <= q_exp[q];
                    trc_start_v <= 1'b1; st <= S_FENCE_WR;
                  end
                  K_FWAIT: begin
                    if (q_tl[w_tgt] >= d_p0) begin
                      q_wexp[q] <= 1'b0; trc_start_v <= 1'b1; fin_now = 1'b1; fin_st = SFH_ST_OK;
                    end else if (q_wexp[q]) begin
                      q_wexp[q] <= 1'b0; trc_start_v <= 1'b1; fin_now = 1'b1; fin_st = SFH_ST_FENCE_TIMEOUT;
                    end else begin
                      q_wait[q] <= 1'b1; q_wtgt[q] <= w_tgt; q_wval[q] <= d_p0;
                      q_wdl[q] <= (fen_tmo != 0) ? now + {32'd0, fen_tmo} : NEVER;
                      st <= S_IDLE;                  // queue parks; others keep running
                    end
                  end
                  default: begin trc_start_v <= 1'b1; fin_now = 1'b1; fin_st = SFH_ST_OK; end
                endcase
              end
            end
          end

          S_EXEC: begin
            if (MUTANT == 8 && q_rstreq[q] && !eng_req && !func_req) begin
              // MUTANT: report the queue reset as done while its transfer is still running
              q_rstreq[q] <= 1'b0; q_en[q] <= 1'b0; q_rdone[q] <= 1'b1; q_armed[q] <= 1'b0;
            end else if (rst_cond) begin
              st <= S_ABORT;
            end else if (unit_fin) begin
              cunit <= U_NONE;
              fin_now = 1'b1;
              if (cunit == U_DM)
                fin_st = (dm_res == 2'd0) ? SFH_ST_OK : (dm_res == 2'd2) ? SFH_ST_MAP_REVOKED : SFH_ST_DMA_ERROR;
              else begin
                fin_st = SFH_ST_OK; cres <= ku_result;
              end
            end else if (cmd_tmo != 0 && now >= wd_dl) begin
              st <= S_EXEC_ABORT;
            end
          end

          S_EXEC_ABORT: if (unit_fin) begin
            // watchdog: the command ends with TIMEOUT (unless it finished in the same instant)
            cunit <= U_NONE; fin_now = 1'b1;
            fin_st = ((cunit == U_DM && dm_res == 2'd0) || (cunit == U_KU && !ku_aborted)) ?
                     SFH_ST_OK : SFH_ST_TIMEOUT;
          end

          S_ABORT: if (unit_fin) begin
            // reset: no completion entry for the aborted command (it stays "started")
            cunit <= U_NONE; st <= S_IDLE;
            trc_end_v <= 1'b1; trc_end_q <= 8'(q); trc_end_seq <= cseq; trc_end_status <= ST_ABORTED_TRACE;
          end

          S_FENCE_WR: if (fe_acc) begin fin_now = 1'b1; fin_st = SFH_ST_OK; end

          S_CQE: begin
            if (!cneed) st <= S_COMMIT;
            else if (fe_acc) begin
              if (MUTANT == 2 && cbeat == 2'd0 && q_armed[q]) begin    // MUTANT: count before visible
                if (q_pend[q] == 0) q_fts[q] <= now;
                q_pend[q] <= q_pend[q] + 16'd1;
                q_urgent[q] <= q_urgent[q] | (cst != SFH_ST_OK) | cflags[1];
              end
              if (cbeat == 2'd2) begin
                trc_cqe_v <= 1'b1; trc_cqe_q <= 8'(q); trc_cqe_seq <= cseq;
                st <= S_COMMIT;
              end
              cbeat <= cbeat + 2'd1;
            end
          end

          S_COMMIT: begin
            q_sqh[q] <= sqh_nx; q_exp[q] <= q_exp[q] + 32'd1; done_cnt <= done_cnt + 32'd1;
            if (cneed) begin
              q_cqt[q] <= q_cqt[q] + 16'd1;
              if (MUTANT != 2 && q_armed[q]) begin
                if (q_pend[q] == 0) q_fts[q] <= now;
                q_pend[q] <= q_pend[q] + 16'd1;
                q_urgent[q] <= q_urgent[q] | (cst != SFH_ST_OK) | cflags[1];
              end
            end
            if (cst != SFH_ST_OK) begin err_cnt <= err_cnt + 32'd1; q_halt[q] <= 1'b1; end
            if (cst == SFH_ST_OK && (bi + 1'b1) < bn && !rst_cond) begin
              bi <= bi + 1'b1; st <= S_DECODE;
            end else begin
              st <= S_IDLE;
            end
          end

          S_SCRUB: begin
            scrub_i <= scrub_i + 1'b1;
            if (&scrub_i) begin scrub_pend <= 1'b0; st <= S_IDLE; end
          end

          default: st <= S_IDLE;
        endcase
      end

      // ---- common completion bookkeeping (execution finished; CQE follows) ----
      if (fin_now) begin
        cst <= fin_st; cbeat <= 2'd0;
        q_completed[q] <= q_exp[q]; q_started[q] <= q_exp[q];
        if (fin_st != SFH_ST_OK) begin q_errv[q] <= 1'b1; q_errst[q] <= fin_st; q_errseq[q] <= q_exp[q]; end
        trc_end_v <= 1'b1; trc_end_q <= 8'(q); trc_end_seq <= q_exp[q]; trc_end_status <= fin_st;
        st <= S_CQE;
      end

      // ================= queue reset of a queue the engine is not working on =================
      // Nothing of such a queue is in flight, so it quiesces at once, whatever the FSM is doing
      // for other queues. (The active queue goes through S_ABORT and the S_IDLE path.)
      if (!reset_active && !eng_req && !func_req) begin
        for (int i = 0; i < NQ; i++) begin
          if (q_rstreq[i] && !(st != S_IDLE && cq_i == QW'(i))) begin
            q_en[i] <= 1'b0; q_halt[i] <= 1'b0; q_wait[i] <= 1'b0; q_wexp[i] <= 1'b0;
            q_armed[i] <= 1'b0; q_pend[i] <= '0; q_urgent[i] <= 1'b0; q_rstreq[i] <= 1'b0;
            q_rdone[i] <= 1'b1;
          end
        end
      end

      // ================= interrupt message accounting (after FSM) =================
      if (msi_acc) begin
        q_armed[msi_q] <= 1'b0; q_pend[msi_q] <= '0; q_urgent[msi_q] <= 1'b0;
        q_irqc[msi_q] <= q_irqc[msi_q] + 32'd1;
      end

      // ================= MMIO writes (last: highest priority) =================
      if (mmio_wr_valid) begin : csr_wr
        logic [15:0] a, rel;
        logic [31:0] v;
        logic [QW-1:0] qi;
        logic [15:0] v16, dh, dt, avail, unc;
        a = mmio_wr_addr; v = mmio_wr_data; v16 = v[15:0];
        if (a < SFH_QREG_BASE) begin
          case (a)
            SFH_REG_CTRL:          if (v[SFH_CTRL_ENGINE_RESET]) eng_req <= 1'b1;
            SFH_REG_FUNC_RESET:    if (v == SFH_FUNC_RESET_MAGIC) func_req <= 1'b1;
            SFH_REG_SCRATCH:       scratch <= v;
            SFH_REG_CMD_TIMEOUT:   cmd_tmo <= v;
            SFH_REG_FENCE_TIMEOUT: fen_tmo <= v;
            SFH_REG_SCRUB:         if (v[31] && !scrub_pend && v[3:0] < 4'(MAX_CTX)) begin
                                     scrub_pend <= 1'b1; scrub_ctx <= v[CW-1:0];
                                   end
            SFH_REG_ATT_IDX:       att_idx_r <= v;
            SFH_REG_ATT_BASE_LO:   stg_base_lo <= v;
            SFH_REG_ATT_BASE_HI:   stg_base_hi <= v;
            SFH_REG_ATT_SIZE:      stg_size <= v;
            SFH_REG_ATT_CTL:       stg_ctl <= v;
            SFH_REG_ATT_CMD:       if (att_idx_r < 32'(N_ATT)) begin
                                     if (v == SFH_ATT_CMD_WRITE) begin
                                       att_base[att_idx_r[AW-1:0]] <= {stg_base_hi, stg_base_lo};
                                       att_size[att_idx_r[AW-1:0]] <= stg_size;
                                       att_v[att_idx_r[AW-1:0]]    <= stg_ctl[SFH_ATT_VALID];
                                       att_r[att_idx_r[AW-1:0]]    <= stg_ctl[SFH_ATT_PERM_R];
                                       att_w[att_idx_r[AW-1:0]]    <= stg_ctl[SFH_ATT_PERM_W];
                                       att_ctx[att_idx_r[AW-1:0]]  <= stg_ctl[SFH_ATT_CTX_LSB +: 4];
                                       att_gen[att_idx_r[AW-1:0]]  <= stg_ctl[SFH_ATT_GEN_LSB +: 16];
                                     end else if (v == SFH_ATT_CMD_INVALIDATE) begin
                                       att_v[att_idx_r[AW-1:0]] <= 1'b0;
                                     end
                                   end
            SFH_REG_ATT_SYNC:      begin sync_tok <= v; sync_pend <= 1'b1; end
            default: ;
          endcase
        end else if (a < SFH_QREG_BASE + 16'(NQ * 128)) begin
          rel = a - SFH_QREG_BASE;
          qi  = rel[7+QW-1:7];
          if (rel[6:0] == 7'(SFH_QCTL)) begin
            if (v[SFH_QCTL_RESET]) begin
              q_rstreq[qi] <= 1'b1;
            end else if (v[SFH_QCTL_ENABLE] && !q_en[qi] && !q_rstreq[qi] && !reset_active &&
                         !eng_req && !func_req) begin
              if (cfg_ok(int'(qi))) begin
                q_en[qi] <= 1'b1; q_cfgerr[qi] <= 1'b0; q_halt[qi] <= 1'b0; q_rdone[qi] <= 1'b0;
                q_wait[qi] <= 1'b0; q_wexp[qi] <= 1'b0; q_armed[qi] <= 1'b0; q_pend[qi] <= '0;
                q_urgent[qi] <= 1'b0; q_errv[qi] <= 1'b0; q_errst[qi] <= '0;
                q_sqh[qi] <= '0; q_sqt[qi] <= '0; q_cqh[qi] <= '0; q_cqt[qi] <= '0;
                q_exp[qi] <= q_seqb[qi];
                q_started[qi] <= q_seqb[qi] - 32'd1; q_completed[qi] <= q_seqb[qi] - 32'd1;
              end else begin
                q_cfgerr[qi] <= 1'b1;
              end
            end
          end else if (!q_en[qi]) begin
            case (8'(rel[6:0]))
              SFH_QSQ_BASE_LO:  q_sqb[qi][31:0]  <= v;
              SFH_QSQ_BASE_HI:  q_sqb[qi][63:32] <= v;
              SFH_QCQ_BASE_LO:  q_cqb[qi][31:0]  <= v;
              SFH_QCQ_BASE_HI:  q_cqb[qi][63:32] <= v;
              SFH_QFENCE_LO:    q_fen[qi][31:0]  <= v;
              SFH_QFENCE_HI:    q_fen[qi][63:32] <= v;
              SFH_QSIZE:        begin q_sql2[qi] <= v[3:0]; q_cql2[qi] <= v[11:8]; end
              SFH_QCFG:         begin q_ctx[qi] <= v[3:0]; q_epoch[qi] <= v[31:16]; end
              SFH_QSEQ_BASE:    q_seqb[qi] <= v;
              SFH_QIMOD_CNT:    q_icnt[qi] <= v;
              SFH_QIMOD_TIME:   q_itime[qi] <= v;
              SFH_QTIMELINE_LO: q_tl[qi][31:0]  <= v;
              SFH_QTIMELINE_HI: q_tl[qi][63:32] <= v;
              default: ;
            endcase
          end
        end else if (a >= SFH_DB_BASE && a < SFH_DB_BASE + 16'(NQ) * SFH_DB_STRIDE) begin
          rel = a - SFH_DB_BASE;
          qi  = rel[12+QW-1:12];
          case (rel[11:0])
            SFH_DB_SQ_TAIL: begin
              dh = v16 - q_sqh[qi]; dt = v16 - q_sqt[qi];
              if (!q_en[qi]) begin
                q_dberr[qi] <= q_dberr[qi] + 32'd1; dberr_cnt <= dberr_cnt + 32'd1;
              end else if (dt == 16'd0) begin
                q_dbdup[qi] <= q_dbdup[qi] + 32'd1;                 // duplicate: idempotent no-op
              end else if ((MUTANT == 6) || (dh <= qents(q_sql2[qi]) && dt <= dh)) begin
                q_sqt[qi] <= v16;                                    // forward, within capacity
              end else begin
                q_dberr[qi] <= q_dberr[qi] + 32'd1; dberr_cnt <= dberr_cnt + 32'd1;  // backwards / overflow
              end
            end
            SFH_DB_CQ_HEAD: begin
              dh = v16 - q_cqh[qi]; avail = q_cqt[qi] - q_cqh[qi];
              if (!q_en[qi]) begin
                q_dberr[qi] <= q_dberr[qi] + 32'd1; dberr_cnt <= dberr_cnt + 32'd1;
              end else if (dh == 16'd0) begin
                q_dbdup[qi] <= q_dbdup[qi] + 32'd1;
              end else if ((MUTANT == 6) || dh <= avail) begin
                q_cqh[qi] <= v16;
              end else begin
                q_dberr[qi] <= q_dberr[qi] + 32'd1; dberr_cnt <= dberr_cnt + 32'd1;  // consumes unwritten CQEs
              end
            end
            SFH_DB_CQ_ARM: if (q_en[qi]) begin
              if (v[0]) begin
                // arm: if the host has not consumed everything already posted, fire immediately
                unc = q_cqt[qi] + ((st == S_COMMIT && cq_i == qi && cneed) ? 16'd1 : 16'd0) - q_cqh[qi];
                q_armed[qi] <= 1'b1;
                q_pend[qi] <= unc; q_urgent[qi] <= (unc != 0); q_fts[qi] <= now;
              end else begin
                q_armed[qi] <= 1'b0; q_pend[qi] <= '0; q_urgent[qi] <= 1'b0;
              end
            end
            default: ;
          endcase
        end
      end
    end
  end

  // ======================= co-simulation scheduling hints =======================
  // quiescent = nothing changes until an input changes or `now` reaches wake_at.
  logic wait_change, idle_work;
  always_comb begin
    wait_change = 1'b0;
    for (int i = 0; i < NQ; i++)
      if (q_wait[i] && (q_tl[q_wtgt[i]] >= q_wval[i] || (q_wdl[i] != NEVER && now >= q_wdl[i])))
        wait_change = 1'b1;
    idle_work = eng_req || func_req || (reset_active && now >= reset_until) || scrub_pend || arb_found ||
                (any_rstreq && !reset_active);
  end
  wire exec_event = unit_fin || rst_cond || (cmd_tmo != 0 && now >= wd_dl);
  wire fsm_quiet  = (frozen && unit_quiet) ||
                    (st == S_IDLE && !idle_work) ||
                    (st == S_FETCH_DATA) ||
                    (st == S_EXEC && unit_quiet && !exec_event);
  assign quiescent = fsm_quiet && !msi_any && !(sync_pend && !dm_busy) && !wait_change &&
                     !(any_rstreq && !reset_active && !eng_req && !func_req && st != S_IDLE) &&
                     !mmio_wr_valid && !mmio_rd_valid;
  always_comb begin
    wake_at = mod_wake;
    if (reset_active && reset_until < wake_at) wake_at = reset_until;
    if (st == S_EXEC && cmd_tmo != 0 && wd_dl < wake_at) wake_at = wd_dl;
    if (cunit == U_KU && ku_wake < wake_at) wake_at = ku_wake;
    for (int i = 0; i < NQ; i++)
      if (q_wait[i] && q_wdl[i] < wake_at) wake_at = q_wdl[i];
  end

endmodule
