// SPDX-License-Identifier: MIT
// -----------------------------------------------------------------------------
// SilicaFlux HSI v2 — data mover (COPY_H2D / COPY_D2H)
//
// * H2D: issues read requests of at most MAX_RD bytes that never cross a 4 KiB
//   boundary, keeps up to CREDIT_BYTES outstanding, writes the in-order
//   response beats into device memory.
// * D2H: streams device memory into posted 8-byte host writes, 1 beat/cycle.
// * Driver-authorised DMA: `att_ok` is the LIVE state of the mapping entry the
//   command was validated against (valid && same generation). It is re-checked
//   before every read request and every write beat, so an entry invalidated by
//   the driver mid-transfer stops all further host accesses (result REVOKED).
// * Abort (watchdog / reset): stop issuing, drain outstanding read beats, finish.
// The result is held in D_FIN until the front-end acknowledges it.
// MUTANT 9 (verification only): no live re-check of the mapping.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfh_datamover #(
  parameter int MAW          = 19,
  parameter int MAX_RD       = 512,
  parameter int CREDIT_BYTES = 4096,
  parameter int MUTANT       = 0
) (
  input  logic           clk,
  input  logic           rst_n,
  input  logic           start,
  input  logic           d2h,
  input  logic [63:0]    haddr,
  input  logic [MAW-1:0] dwaddr,
  input  logic [31:0]    len,
  input  logic           abort,
  input  logic           att_ok,
  input  logic           ack,
  output logic           idle,
  output logic           fin,
  output logic [1:0]     res,        // 0 OK, 1 DMA error, 2 revoked, 3 aborted
  output logic           quiet,
  // host read port (in-order responses)
  output logic           rd_req_valid,
  input  logic           rd_req_ready,
  output logic [63:0]    rd_req_addr,
  output logic [9:0]     rd_req_len,
  input  logic           rd_rsp_valid,
  input  logic [63:0]    rd_rsp_data,
  input  logic           rd_rsp_err,
  // host posted-write port
  output logic           wr_valid,
  input  logic           wr_ready,
  output logic [63:0]    wr_addr,
  output logic [63:0]    wr_data,
  // device memory port (1-cycle read latency)
  output logic           m_en,
  output logic           m_we,
  output logic [MAW-1:0] m_addr,
  output logic [63:0]    m_wdata,
  input  logic [63:0]    m_rdata
);
  typedef enum logic [1:0] { D_IDLE, D_H2D, D_D2H, D_FIN } dstate_t;
  dstate_t st;

  logic [63:0]    h_base;
  logic [31:0]    total, issued, wcnt, mrd, out_bytes;
  logic [MAW-1:0] dptr, sptr;
  logic           stop, err, revoked, aborted;
  logic [63:0]    fifo [0:3];
  logic [1:0]     f_rd, f_wr;
  logic [2:0]     f_cnt;
  logic           inflight;

  wire att_gate = (MUTANT == 9) ? 1'b1 : att_ok;

  // ---- H2D request sizing: min(MAX_RD, remaining, bytes to the next 4 KiB boundary) ----
  wire [63:0] next_addr = h_base + 64'(issued);
  wire [31:0] remain    = total - issued;
  wire [31:0] to_4k     = 32'd4096 - {20'd0, next_addr[11:0]};
  wire [31:0] chunk0    = (remain < 32'(MAX_RD)) ? remain : 32'(MAX_RD);
  wire [31:0] chunk     = (chunk0 < to_4k) ? chunk0 : to_4k;
  wire        h2d_want  = (st == D_H2D) && !stop && !abort && (issued < total) &&
                          (out_bytes + chunk <= 32'(CREDIT_BYTES));

  assign rd_req_valid = h2d_want && att_gate;
  assign rd_req_addr  = next_addr;
  assign rd_req_len   = chunk[9:0];

  // ---- D2H ----
  wire d2h_can_rd = (st == D_D2H) && !abort && att_gate && (mrd < total) &&
                    ((f_cnt + {2'd0, inflight}) <= 3'd2);
  assign wr_valid = (st == D_D2H) && (f_cnt != 0) && att_gate && !abort;
  assign wr_addr  = h_base + 64'(wcnt);
  assign wr_data  = fifo[f_rd];
  wire   pop      = wr_valid && wr_ready;

  // ---- device memory port ----
  always_comb begin
    m_en = 1'b0; m_we = 1'b0; m_addr = '0; m_wdata = '0;
    if (st == D_H2D && rd_rsp_valid && !stop && !abort && !rd_rsp_err) begin
      m_en = 1'b1; m_we = 1'b1; m_addr = dptr; m_wdata = rd_rsp_data;
    end else if (d2h_can_rd) begin
      m_en = 1'b1; m_addr = sptr;
    end
  end

  assign idle  = (st == D_IDLE);
  assign fin   = (st == D_FIN);
  // nothing will change until a read beat arrives (or we are idle / holding a result)
  assign quiet = (st == D_IDLE) || (st == D_FIN) ||
                 ((st == D_H2D) && !h2d_want && !abort && (out_bytes != 0));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= D_IDLE; h_base <= '0; total <= '0; issued <= '0; wcnt <= '0; mrd <= '0;
      out_bytes <= '0; dptr <= '0; sptr <= '0; stop <= 1'b0; err <= 1'b0; revoked <= 1'b0;
      aborted <= 1'b0; res <= '0; f_rd <= '0; f_wr <= '0; f_cnt <= '0; inflight <= 1'b0;
      for (int i = 0; i < 4; i++) fifo[i] <= '0;
    end else begin
      case (st)
        D_IDLE: if (start) begin
          h_base <= haddr; total <= len; issued <= '0; wcnt <= '0; mrd <= '0;
          out_bytes <= '0; dptr <= dwaddr; sptr <= dwaddr; stop <= 1'b0; err <= 1'b0;
          revoked <= 1'b0; aborted <= 1'b0; f_rd <= '0; f_wr <= '0; f_cnt <= '0; inflight <= 1'b0;
          st <= d2h ? D_D2H : D_H2D;
        end

        D_H2D: begin : h2d
          logic s_rev, s_abt, s_err, stp;
          logic [31:0] ob, iss;
          s_rev = revoked; s_abt = aborted; s_err = err; ob = out_bytes; iss = issued;
          if (h2d_want && !att_gate) s_rev = 1'b1;           // mapping gone: issue nothing more
          if (abort) s_abt = 1'b1;
          if (rd_req_valid && rd_req_ready) begin iss = iss + chunk; ob = ob + chunk; end
          if (rd_rsp_valid) begin
            if (rd_rsp_err) s_err = 1'b1;
            if (!stop && !abort && !rd_rsp_err) dptr <= dptr + 1'b1;
            ob = ob - 32'd8;
          end
          stp = stop | s_rev | s_abt | s_err;
          revoked <= s_rev; aborted <= s_abt; err <= s_err; stop <= stp;
          out_bytes <= ob; issued <= iss;
          if (ob == 32'd0 && (iss == total || stp)) begin
            st  <= D_FIN;
            res <= s_abt ? 2'd3 : s_rev ? 2'd2 : s_err ? 2'd1 : 2'd0;
          end
        end

        D_D2H: begin : d2h_blk
          logic [2:0] cnt;
          if (abort) begin
            st <= D_FIN; res <= 2'd3; inflight <= 1'b0; f_cnt <= '0;   // nothing external outstanding
          end else if (!att_gate) begin
            st <= D_FIN; res <= 2'd2; inflight <= 1'b0; f_cnt <= '0;   // drop buffered data
          end else begin
            cnt = f_cnt;
            if (inflight) begin fifo[f_wr] <= m_rdata; f_wr <= f_wr + 1'b1; cnt = cnt + 3'd1; end
            if (pop) begin f_rd <= f_rd + 1'b1; wcnt <= wcnt + 32'd8; cnt = cnt - 3'd1; end
            f_cnt    <= cnt;
            inflight <= d2h_can_rd;
            if (d2h_can_rd) begin sptr <= sptr + 1'b1; mrd <= mrd + 32'd8; end
            if (pop && (wcnt + 32'd8 == total)) begin st <= D_FIN; res <= 2'd0; end
          end
        end

        D_FIN: if (ack) st <= D_IDLE;
        default: st <= D_IDLE;
      endcase
    end
  end
endmodule
