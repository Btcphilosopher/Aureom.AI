# SilicaFlux Host Submission Interface (HSI) v2.0 — normative contract

> **Status.** A proposal implemented by `rtl/sfh_core.sv` (device) and `host/src/` (host), and
> verified only in simulation (`docs/VERIFICATION.md`). It replaces the SF-G1 *v1.0* draft contract
> (`silicaflux-sfg1-driver/docs/02-hw-interface.md`); differences are listed in
> [`CHANGES_FROM_V1.md`](CHANGES_FROM_V1.md). Exact offsets, bit positions and encodings are generated
> from `spec/sfh_spec.py` into [`REGMAP.md`](REGMAP.md), `rtl/sfh_pkg.sv` and `host/include/sfh_abi.h`;
> where this text and REGMAP disagree, REGMAP is right and this file has a bug.

"Must" and "must not" are requirements; "device" is the RTL behind the transport boundary; "driver"
is the privileged host layer (`sfh_kmd.c`); "library" is the user layer (`sfh_umd.c`).

---

## 1. Model

* One PCIe function, BAR0 ≥ 32 KiB: a **global page** (privileged), **per-queue register blocks**
  (privileged) and **one 4 KiB doorbell page per queue** (can be mapped into exactly one process).
* `NQ` queue pairs (default 4). Each pair = a submission queue (SQ, 64-byte descriptors, host memory,
  read by the device) + a completion queue (CQ, 16-byte entries, host memory, written by the device)
  + an 8-byte **fence slot** (host memory, written by the device) + one MSI-X vector.
* `MAX_CTX` hardware contexts (default 4); each owns a disjoint device-memory **window**
  (`2^WIN_LOG2` bytes, default 1 MiB). A queue is bound to one context by the driver.
* A **DMA mapping table (ATT)**, `N_ATT` entries (default 32), programmed only by the driver. It is the
  only source of host addresses for data transfers.
* One execution engine. Queues are served round-robin; within a queue execution and completion are
  strictly in order (rule O7 relies on this).

## 2. Versioning

| Item | Rule |
|---|---|
| `HW_VERSION[31:16]` (major) | Contract-breaking. The driver refuses any major ≠ 2. |
| `HW_VERSION[15:0]` | Informational. New optional behaviour is announced in `CAPS` bits; the driver requires the ten v2 capabilities and ignores unknown ones. |
| `DESC_VERSIONS` | Bitmask of descriptor formats the device accepts (bit *n* = version *n*). v2.0 devices set only bit 2. The library emits version 2 and refuses to open a device without bit 2. |
| Descriptor `MAGIC` (`0xD5`) + `VERSION` byte | Checked **first**. A v1 descriptor (opcode in byte 0, raw host address in the body) cannot carry `0xD5` and is rejected with `BAD_VERSION` before any other field is interpreted. |
| Future descriptor versions | May only reuse fields that are reserved-zero in v2; a device must reject versions it does not list in `DESC_VERSIONS`. |

## 3. Descriptor format v2 (64 bytes, 16 little-endian dwords)

| dw | Field | Notes |
|---|---|---|
| 0 | `MAGIC[7:0]=0xD5`, `VERSION[15:8]=2`, `OPCODE[23:16]`, `FLAGS[31:24]` | flags: `SUPPRESS_CQE` (0x01), `IRQ_NOW` (0x02); other bits must be 0 |
| 1 | `SEQ` | per-queue sequence number; must equal the device's expected value |
| 2 | `EPOCH[15:0]`, reserved `[31:16]=0` | must equal the queue's current epoch |
| 3 | `USER_TAG` | echoed in the CQE |
| 4 | `HANDLE` = `{GEN[31:16], INDEX[15:0]}` | ATT reference (COPY_* only) — never an address |
| 5 | `LEN` (bytes) | multiple of 8 where it is a length |
| 6–7 | `HOST_OFF` | offset inside the mapping |
| 8–9 | `DEV_OFF` | window-relative: H2D destination, D2H source, KERNEL source |
| 10–11 | `DEV_OFF2` | window-relative: KERNEL destination |
| 12–13 | `PARAM0` | KERNEL constant / SPIN ns / fence value |
| 14 | `PARAM1` | KERNEL op / FENCE_WAIT target queue |
| 15 | `CHECK` | `0x5F5F5F5F ^ dw0 ^ … ^ dw14` |

Opcodes: `NOP`, `COPY_H2D`, `COPY_D2H`, `KERNEL` (`ADD32`, `XOR64`, `SUM32`, `SPIN`), `FENCE_SIGNAL`,
`FENCE_WAIT`. Every field an opcode does not use must be zero.

**Device validation order** (first failure wins; the command then completes with that status and
has no side effects): magic/version → check dword → epoch → seq → opcode → unused/reserved fields,
flags, zero lengths, kernel op, wait target → handle (index range, entry valid, generation) →
ownership/permission (entry's context = queue's context; `R` for H2D, `W` for D2H; FENCE_WAIT target
queue in the same context) → alignment → bounds (`off ≤ size ∧ len ≤ size − off`, overflow-safe, for
the mapping and the window) → fence monotonicity.

The library and the driver perform the same checks before a descriptor is written (an invalid batch
is rejected whole, nothing is queued). The device re-checks everything because a direct-submission
client — or a driver bug — can put anything in a ring.

## 4. Ring ownership

Positions are **free-running 16-bit counters**; slot = position mod entries (entries are powers of
two, 16…4096). `tail − head` (mod 2¹⁶) is the occupancy, so a full ring and an empty ring are
distinguishable without a spare slot.

```
SQ slot:  HOST-OWNED --(host writes descriptor, wmb, doorbell past it)--> DEVICE-OWNED
          DEVICE-OWNED --(CQE with SQ_HEAD past it, or queue reset + RESET_DONE read)--> HOST-OWNED
CQ slot:  DEVICE-OWNED --(device writes CQE, dw3 last)--> HOST-OWNED
          HOST-OWNED --(host consumes, DB_CQ_HEAD past it)--> DEVICE-OWNED
fence slot: device-written only; the host reads it
ATT entry: driver-written only (MMIO); the device reads it
```

* A queue has **one producer and one consumer** (the owning context). Threads that need parallel
  submission use separate queues; the library takes no lock.
* The device may read a DEVICE-OWNED SQ slot **more than once** (a batch is re-fetched after a parked
  `FENCE_WAIT` or a full CQ). The host must not touch it (rule O2).
* With `SUPPRESS_CQE`, a later CQE's `SQ_HEAD` releases the suppressed slots before it.

## 5. Doorbells

| Register (per-queue page) | Value | Device behaviour |
|---|---|---|
| `DB_SQ_TAIL` | new tail position | accepted iff `0 < new − tail` and `new − head ≤ entries` (mod 2¹⁶); equal → **duplicate**, ignored, counted in `QDB_DUP`; backwards or beyond capacity → **rejected**, counted in `QDB_ERR`/`DB_ERR_COUNT`; queue disabled → rejected |
| `DB_CQ_HEAD` | new CQ head position | accepted iff `0 < new − head ≤ cq_tail − head`; equal → duplicate; anything else rejected |
| `DB_CQ_ARM` | 1 = arm, 0 = disarm | see §7 |

Doorbell values are absolute, so a duplicated, replayed or merged (write-combined) doorbell is
harmless. **Batching** = write N descriptors, one barrier, one `DB_SQ_TAIL`. The device fetches up
to `FETCH_MAX` (8) consecutive descriptors with one read (never across the ring wrap), which amortises
the device's descriptor-fetch round trip the same way.

## 6. Completion queue

CQE (16 bytes): dw0 `RESULT`, dw1 `USER_TAG`, dw2 `SEQ`, dw3 = `{SQ_HEAD[31:16], SEQ_LO[15:8],
STATUS[7:1], PHASE[0]}`. `PHASE` is 1 on the first lap and toggles every wrap; the host zeroes the
CQ before every enable. `SEQ_LO` repeats `SEQ[7:0]` so the host can detect an entry whose dwords come
from different writes.

* Errors always produce a CQE (even with `SUPPRESS_CQE`) and **halt that queue only**; other queues
  keep running. The error is latched in `QSTATUS.ERR_VALID/ERR_STATUS` and `QERR_SEQ`.
* **Back-pressure:** the device never writes into an unconsumed CQ slot. It does not start a command
  on a queue whose CQ has no free slot; the rest of the fetched batch is discarded and re-fetched once
  the host returns credit. Other queues are unaffected.

## 7. Interrupts, moderation and polling

Per queue (vector = queue index):

* **Arming is one-shot.** `DB_CQ_ARM=1` arms; the device clears the armed state when it sends the
  message. `DB_CQ_ARM=0` disarms (pure polling: never arm).
* **Arming with unconsumed entries fires at once.** On arm, `pending := cq_tail − cq_head`; if
  non-zero, the interrupt is urgent. Together with rule O9 this makes the classic lost-wake-up race
  (entry lands between the host's last check and its arm) impossible.
* **Moderation** (`QIMOD_CNT`, `QIMOD_TIME`): while armed, CQEs increment `pending`; the message is
  sent when `pending ≥ count`, or `time` ns after the first un-signalled CQE, or immediately for an
  **urgent** completion (any error, or `FLAG_IRQ_NOW` — the library sets it on the last command of a
  batch with `SFH_SUBMIT_IRQ_LAST`). `count > 1` requires `time > 0` (enable is refused otherwise),
  so a straggler can never wait forever.
* Host notification modes (library): **IRQ** (arm, sleep), **POLL** (spin on the phase bit, never
  arm), **HYBRID** (spin up to a budget, then arm and sleep).
* Duplicate, spurious or late interrupts are harmless: the host drains by phase + sequence window and
  counts an interrupt that found nothing as spurious.

## 8. Fences

* `FENCE_SIGNAL(v)`: executes after every earlier command of the queue has completed; requires
  `v > timeline` (else `FENCE_ORDER`); sets the queue's timeline to `v` and writes `v` (8 bytes) to the
  queue's fence slot — an address the driver programmed (`QFENCE`), never one from the descriptor.
* `FENCE_WAIT(q, v)`: completes when `timeline[q] ≥ v`. Target queue must belong to the same context
  (`PERM` otherwise). An unsatisfied wait **parks the queue** without blocking the engine: the
  arbiter skips it until the condition holds or `FENCE_TIMEOUT` ns pass (`FENCE_TIMEOUT` status).
* Host-side: `sfh_fence_read()`/`sfh_fence_wait()` read the fence slot (rule O11).

## 9. Driver-authorised DMA

* An ATT entry = `{base IOVA, size, valid, perm R/W, owner context, 16-bit generation}`, written only
  through global registers. The driver bumps the generation each time an index is reused, so a stale
  handle (use after free/unmap) fails the generation check even when the index is live again.
* The device checks a COPY descriptor's handle, owner, permission and bounds before starting, and
  **re-checks the entry (valid and same generation) before every read request and every write beat**.
  If the driver invalidates the entry mid-transfer the transfer stops (`MAP_REVOKED`).
* Revocation handshake (rule O12): invalidate → `ATT_SYNC = token` → read `ATT_SYNC_ACK` until it
  equals the token → only then unmap from the IOMMU and free. The device acknowledges once its data
  mover is idle (kernels never touch host memory).
* Device-memory windows are per context; window-relative offsets cannot reach another context.
  Windows are scrubbed (`SCRUB` register) before a context slot is given to a new owner.
* The SQ, CQ and fence-slot addresses are queue registers (privileged), not descriptor fields.
* On real hardware the IOMMU (VFIO type1 / kernel DMA API) is a second wall: the function can only
  reach what the driver mapped, with the same R/W split. In simulation the IOMMU model is the oracle
  every test checks.

## 10. Memory-ordering contract (normative)

Assumes PCIe semantics end to end: posted writes are delivered in order; a read completion does not
pass earlier posted writes in the same direction; no Relaxed Ordering, no ID-based Ordering, no
No-Snoop. The AXI endpoint adapter re-creates the two properties AXI does not give for free (A2/A3 in
`docs/ENDPOINT_ADAPTER.md`).

| # | Rule | Implemented in |
|---|---|---|
| **O1** | **Publish:** the host stores all 16 dwords of every descriptor, then executes a store barrier, then writes one `DB_SQ_TAIL`. The device reads only slots in `[head, tail)`. | `sfh__write_batch` (`wmb` before the doorbell) |
| **O2** | **Ownership:** a published slot is not modified until released (§4). The device may re-read it. | library slot tracking |
| **O3** | **Doorbells** are absolute and idempotent; the device validates range and direction (§5). | `sfh_core.sv` doorbell decode |
| **O4** | **Descriptor integrity:** magic/version, check dword, epoch and seq are validated before any other field is used; a stale, torn or foreign slot never executes. | `validate` block |
| **O5** | **CQE write order:** the 8-byte write of dw0+dw1, then dw2, then **dw3 alone, last**. The phase bit lives in dw3. | `S_CQE` beat order |
| **O6** | **CQE consumption:** read dw3; if the phase is not the expected one, stop; read barrier; read dw0–dw2; accept only if `SEQ[7:0] == SEQ_LO` and `SEQ` is inside the in-flight window; otherwise treat the slot as not yet written (the device will overwrite it). | `sfh__drain` |
| **O7** | **Data before completion:** every data write of a command (D2H) is issued before its CQE on the same ordered channel; after the host's read barrier in O6 the data is visible. Commands of one queue complete in order, so a CQE also covers every earlier command. | data mover → `S_CQE` |
| **O8** | **Interrupt after completion:** an interrupt message is issued on the same ordered channel after the last write of every CQE it covers. (AXI adapter: requested only after those writes' BRESPs.) | `pend` counted at `S_COMMIT`; adapter A2 |
| **O9** | **Credits before arming:** the host writes `DB_CQ_HEAD` for everything it consumed before `DB_CQ_ARM=1`; the device fires immediately if anything is unconsumed (§7). | `wait_event`, `DB_CQ_ARM` |
| **O10** | **A BAR read flushes the device's posted writes:** the response is returned only after every DMA write the device issued before servicing the read. The driver relies on it after `RESET_DONE`, `ATT_SYNC_ACK` and on host timeouts. (AXI adapter: response held until those BRESPs.) | co-sim channel; adapter A3 |
| **O11** | **Fences:** the fence value write is ordered after all data writes of earlier commands of the queue; a host that reads value ≥ *v* and then executes a read barrier sees that data. | `S_FENCE_WR`, `sfh_fence_read` |
| **O12** | **Mapping revocation:** invalidate, sync, read the acknowledgement (O10), then unmap/free. The device re-checks the entry per request/beat. | `att_revoke`, data mover |
| **O13** | **Queue quiesce:** after `QCTL.RESET` and an MMIO read showing `RESET_DONE`, the device will not access that queue's SQ, CQ or fence slot until it is re-enabled. A queue the engine is not working on quiesces at once; the active one is aborted at a burst boundary (no CQE for the aborted command). | `sfh_core.sv` reset paths |
| **O14** | **Epochs:** every enable uses a new epoch; the host zeroes the CQ and issues a store barrier before `QCTL.ENABLE`. Descriptors written before a reset are rejected (`STALE_EPOCH`) even if their slot is re-published. | `queue_enable` |
| **O15** | **No Relaxed Ordering / No-Snoop** on descriptor reads, data, CQE, fence writes or interrupt messages. The host clears `RELAX_EN`/`NOSNOOP_EN` in Device Control at open. | `sfh_vfio.c`; adapter `AxCACHE=0` |
| **O16** | **CQ back-pressure:** the device never writes a CQE into a slot the host has not released (§6). | `cq_space` |

### Host barrier mapping

| Need | Linux kernel driver | User space, x86-64 | User space, arm64 |
|---|---|---|---|
| O1 store barrier before doorbell | `dma_wmb()` + `writel()` (or `wmb()` for a WC-mapped doorbell page) | stores to WB memory are ordered with UC stores; `sfence` needed if the doorbell page is WC | `dmb oshst` |
| O6/O11 read barrier after phase/fence read | `dma_rmb()` | compiler barrier (loads are ordered) | `dmb oshld` |
| MMIO accessors | `readl`/`writel` | `volatile` 32-bit accesses to the UC mapping | same, device-nGnRE mapping |

The co-simulation models an un-ordered store buffer: descriptor stores become visible to the device
only at the store barrier. Removing that barrier (host mutant 1) makes 18 of the 20 tests fail.

## 11. Resets, timeouts and recovery

### 11.1 Device side

| Mechanism | Trigger | Effect |
|---|---|---|
| Execution watchdog | command runs longer than `CMD_TIMEOUT` ns | command aborted, completes with `TIMEOUT` (side effects partial), queue halted |
| Fence-wait timeout | `FENCE_WAIT` parked longer than `FENCE_TIMEOUT` ns | completes with `FENCE_TIMEOUT`, queue halted |
| Queue reset | `QCTL.RESET` | queue disabled; active command aborted, no CQE; snapshots kept; `RESET_DONE` once quiesced |
| Engine reset | `CTRL.ENGINE_RESET` | every queue reset; ATT, queue configuration and device memory retained; `RESET_COUNT`++ |
| Function reset | `FUNC_RESET = 0x52455345` | engine reset + ATT, queue configuration, timeouts and counters cleared; device memory **undefined** |

**Snapshots** (per queue, survive queue and engine reset, not function reset):
`QSTARTED_SEQ` — last command whose execution began; `QCOMPLETED_SEQ` — last command whose execution
finished (set before its CQE is written); `QERR_SEQ` + `QSTATUS.ERR_*` — the command that halted the
queue.

### 11.2 Host side (driver)

**No-progress timeout.** A wait that sees no completion for `host_timeout_ns` (default 20 ms; must
exceed the device watchdog) does, in order: drain the CQ (a lost interrupt is recovered here); read
`QSTATUS`/`QCOMPLETED_SEQ` over MMIO (O10) and drain again; if halted → recover; if the queue is
parked in a fence wait → keep waiting; if the device completed a CQE-producing command whose CQE never
arrived → recover (lost completion); if `QCOMPLETED_SEQ` moved → slow, not stuck; otherwise → hang.
Four consecutive interrupts that find nothing trigger the same check early.

**Recovery of one queue:** `QCTL.RESET` → wait `RESET_DONE` → drain → read snapshots → classify every
command still in flight → re-enable with a new epoch → optionally replay.

**Uncertain completion — classification** (seq comparisons are mod 2³²):

| Condition | Outcome reported to the application |
|---|---|
| CQE seen | the CQE's status |
| `seq ≤ QCOMPLETED_SEQ` (CQE lost) | `QERR_STATUS` if `seq == QERR_SEQ` and `ERR_VALID`, else `OK`; flag `SFH_CF_RECOVERED` |
| `QCOMPLETED_SEQ < seq ≤ QSTARTED_SEQ` | `SFH_CS_UNCERTAIN` — side effects may be partial; never retried automatically |
| `seq > QSTARTED_SEQ` | `SFH_CS_NOT_EXECUTED`, or replayed (new epoch and seq, same ticket, flag `SFH_CF_REPLAYED`) when the queue was created with `SFH_QF_REPLAY` |
| after a **function** reset | snapshots are read *before* the reset; only `seq ≤ COMPLETED` is trusted, everything else is `UNCERTAIN` |

**Escalation ladder.** Queue reset that does not reach `RESET_DONE` in `reset_timeout_ns` → engine
reset. A queue that hangs again before making any progress after a queue reset → engine reset; a
third time → function reset. Engine reset that does not complete → function reset. Function reset
that does not complete → device lost (`SFH_CS_DEVICE_LOST` for everything in flight). After a function
reset the driver restores the ATT and every queue's configuration from its shadow state, scrubs free
context windows, and marks live contexts `SFH_CF_DEVMEM_LOST`.

### 11.3 Process termination (driver release path)

Identical for exit, crash and kill — the driver gets no cooperation:

1. `QCTL.RESET` every queue of the context; wait `RESET_DONE` (O13). Other contexts' queues keep
   running; a reset of a queue the engine is not working on completes immediately.
2. For every buffer: invalidate + sync (O12), then IOMMU unmap, then free.
3. Free rings only after step 1; scrub the context's device-memory window before the slot is reused.

If step 1 cannot complete the driver escalates to an engine reset; other contexts then see their
in-flight commands classified per §11.2 (and replayed if they asked for it).
