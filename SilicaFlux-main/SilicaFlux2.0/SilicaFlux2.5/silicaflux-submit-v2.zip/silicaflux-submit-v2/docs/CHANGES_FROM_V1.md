# What changed from the SF-G1 v1.0 submission path

Baseline: `SilicaFlux-main/silicaflux-sfg1-driver-0.1.0.zip` — draft contract v1.0
(`docs/02-hw-interface.md`), reference front-end `rtl/sfg1_host_frontend.sv`, Linux DRM-accel driver.
Its reference testbench was re-run here before starting (Verilator 5.020: 566 checks pass, both
ordering mutants caught).

| Area | v1.0 | HSI v2.0 |
|---|---|---|
| Descriptor identity | none; opcode in byte 0 | magic `0xD5` + version byte, `DESC_VERSIONS` capability; v1 descriptors rejected before any field is used |
| Stale / torn / replayed descriptors | not detectable (relies on the host never publishing a bad slot) | per-queue sequence number, per-enable epoch, check dword |
| Host addresses | raw bus address in every DMA descriptor; isolation relied on the kernel writing the right address | `{generation, index}` handle into a driver-programmed mapping table; device checks owner, permission, bounds, and re-checks per request/beat; revocation handshake |
| Queues | one SQ/CQ pair per function | `NQ` pairs, per-queue owner context, per-queue doorbell page, round-robin arbitration |
| Execution | one command per fetch (16 single-dword reads per descriptor) | burst fetch of up to 8 descriptors per read |
| Batching | one doorbell per command in practice | explicit batch API: one validation pass, one barrier, one doorbell, optional coalesced CQEs and urgent last completion |
| Doorbells | index mod ring size, last write wins | free-running absolute positions; duplicates idempotent; backwards/over-capacity rejected and counted |
| Error effect | whole device halted | only the failing queue halts |
| CQ overflow | `FATAL` | back-pressure on that queue only |
| CQE | status + phase, no integrity | adds `SEQ` and a `SEQ_LO` check byte in the phase dword; host rejects torn and duplicated entries |
| Interrupts | one level-derived vector; host acknowledge-then-drain | one vector per queue, one-shot arming that fires at once if anything is unconsumed, count + timer moderation, urgent bypass |
| Polling | not a mode | IRQ / POLL / HYBRID per queue |
| Fences | none (WAIT_JOB only) | timeline FENCE_SIGNAL with host-visible slot, cross-queue FENCE_WAIT that parks without blocking the engine, wait timeout |
| Timeout recovery | job timeout → engine reset → function reset | device watchdog per command; host no-progress detection that separates lost interrupts, lost completions, slow commands, fence waits and real hangs; per-queue reset first; escalation ladder |
| Uncertain completion | in-flight jobs reported as cancelled/timeout | STARTED/COMPLETED/ERR snapshots → completed-but-CQE-lost, UNCERTAIN, NOT_EXECUTED (optionally replayed) |
| Process termination | context teardown + scrub | queue quiesce (other queues unaffected) → mapping revoke + sync → free → scrub |
| Memory-ordering contract | R1–R9 | O1–O16, including the host-side barrier mapping and the AXI-endpoint obligations |
| Physical deployment | PCI glue compile-tested | AXI endpoint adapter with its own ordering guarantees and testbench; VFIO transport compile-checked |
| Verification without hardware | kernel mock (QEMU) + front-end RTL TB | Verilated RTL co-simulation with the real host runtime, simulated IOMMU oracle, fault injection, 15 mutants |

Not carried over: the Linux DRM-accel driver itself (the v2 host runtime is a user-space library with
a driver layer that maps onto the v1 driver's structure — see `docs/LIMITATIONS.md`), and the VEC/TEN
compute opcodes (replaced by a small kernel unit; the compute fabric is out of scope).
