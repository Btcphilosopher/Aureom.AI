# Security model: descriptors, DMA authorisation and isolation

A design-level threat model with the tests that back each claim. It is **not** a security audit;
nothing here has been independently reviewed, fuzzed or run on hardware.

## 1. Assets, adversaries, trust boundary

| | |
|---|---|
| Assets | (a) every process's host buffers; (b) every context's device-memory window; (c) kernel/driver memory and the rest of physical memory; (d) other processes' ability to use the device |
| Adversary A | an unprivileged process that can submit arbitrary descriptors — through the library, or by writing its own ring directly (`SFH_QF_DIRECT`) |
| Adversary B | a second such process trying to reach A's buffers, windows, queues or fences |
| Trusted | the driver layer (`sfh_kmd.c`, kernel driver or root-owned broker in a deployment), the device |
| Out of scope | root, a malicious device or firmware, physical attacks, side channels |

## 2. "Applications never get unrestricted physical-memory access"

* **No addresses cross the API.** Applications name memory as `(sfh_buf *, offset)`. The library
  turns that into a handle `{generation, index}`; the handle is an index into the device's mapping
  table (ATT), which only the driver writes (global BAR page, never mapped to applications).
* **The device decides, not the descriptor.** For every COPY the device checks the handle's index,
  `valid`, generation, owner context (must equal the queue's context, which the driver programmed),
  direction permission (R for H2D, W for D2H) and bounds (`off ≤ size ∧ len ≤ size − off`, 64-bit,
  overflow-safe) before the first byte moves, and re-checks valid + generation before every read
  request and write beat afterwards.
* **Ring, CQ and fence addresses are privileged queue registers**, not descriptor fields. A descriptor
  can only cause DMA to (i) its queue's own fence slot, (ii) mappings its context owns.
* **v1 descriptors carried raw host addresses.** They are rejected by magic/version before any field
  is read (`t_stale` (d)).
* **IOMMU as a second wall** (deployment): the driver maps exactly the rings (SQ read-only for the
  device, CQ/fence write-only) and each buffer with its R/W permission (`sfh_vfio.c`, VFIO type1).
  In simulation the same IOMMU model is the oracle: an access outside a current mapping is blocked
  and counted, and **every test fails on any violation**.
* **No register access for applications.** The only per-process MMIO is the queue's 4 KiB doorbell
  page (three write-only doorbells, reads return 0). Doorbell values are validated (range,
  direction) by the device.

## 3. Attacks and defences

| Attack | Defence | Test |
|---|---|---|
| Forge another process's handle value | owner-context check on the device (`PERM`) | `isolation` (read and write directions); RTL mutant 5 is killed by it |
| Guess handles / out-of-range index / unmapped slot | index range + `valid` (`BAD_HANDLE`) | `validation` |
| Use a handle after the buffer was freed and the index reused | 16-bit generation bumped on every reuse (`BAD_HANDLE`) | `validation` (stale handle after slot reuse); RTL mutant 4 killed |
| Read through a write-only mapping / write through a read-only one | per-direction permission (`PERM`) | `validation` |
| Overflow offset + length (64-bit wrap) | `off ≤ size ∧ len ≤ size − off` | `validation` ("host offset overflow", "window offset overflow") |
| Reach another context's device memory | window-relative offsets, base derived from the queue's context | `isolation` |
| Read a previous owner's device memory | window scrubbed at context release and before reuse; slot withheld if the scrub cannot be confirmed; after a function reset all free windows rescrubbed | `proc_term` (new owner reads zeros where the dead process left a secret) |
| Keep DMA running after the process dies | release path: queue reset → `RESET_DONE` (MMIO read flushes) → mapping revoke + sync → only then unmap/free | `proc_term` (killed during a 512 KiB transfer, zero oracle violations); RTL mutant 8 killed |
| Free a buffer the device is using | revoke + sync before free; device stops the transfer (`MAP_REVOKED`) | `revoke`; RTL mutant 9 and host mutant 3 killed |
| Replay / stale / torn descriptors | epoch, sequence number, check dword | `stale`; RTL mutant 3 and host mutant 4 killed |
| Hostile doorbells (backwards, past capacity, on a disabled queue) | range/direction validation, counted and ignored | `doorbell`; RTL mutant 6 killed |
| Wait on another process's fence timeline | `FENCE_WAIT` target must share the context (`PERM`) | `isolation` |
| Misuse the library (wrong owner, bad offsets, unknown ops) | same checks in the library, whole batch rejected (`-EPERM`/`-EINVAL`) before anything reaches the ring | `validation`, `batch`, `isolation` |

## 4. Availability

| Threat | Mitigation | Residual |
|---|---|---|
| A process's queue errors or hangs | errors halt only that queue; the watchdog aborts long commands; recovery is per queue | a hang the queue reset cannot clear escalates to an engine reset, which affects every queue (their in-flight work is classified and optionally replayed) |
| Flooding | per-queue ring capacity; round-robin between queues; fetch bursts ≤ 8 descriptors | one engine: heavy queues still share it |
| Parked fence waits | a parked queue is skipped by the arbiter; fence-wait timeout | — |
| CQ never drained | back-pressure on that queue only | — |
| Exhausting contexts / ATT entries / queues | fixed small pools, `-EBUSY`/`-ENOSPC` | no per-user quota in this runtime |

## 5. What is not claimed

* No production-grade isolation claim: the device and driver were written together against this
  contract and verified in simulation only.
* No protection against a malicious device, a compromised driver, root, or side channels (timing
  of shared queues and the shared engine leaks activity between contexts).
* The simulated IOMMU checks addresses and permissions; it does not model IOTLB invalidation latency,
  ATS or PASID. Per-process hardware address spaces (PASID) are a possible future revision.
