# The simulation transport (`sim/sfh_cosim.cpp`)

Verification and benchmarks run without PCIe hardware by linking the **real host runtime** to the
**Verilated RTL** through the same `sfh_transport` interface the VFIO transport implements. Nothing
in the driver or library knows which one it talks to.

## 1. Time

* The device runs at 1 GHz: one RTL cycle = 1 ns of device time.
* The host has a **virtual clock**. Every transport operation advances it by a cost from the platform
  profile; spinning advances it by one poll iteration; sleeping jumps it to the wake-up time.
* **Conservative lock-step:** before any host operation that can observe or change shared state
  (MMIO, DMA memory stores, barriers, IOMMU changes, interrupt waits, polls), the device is advanced
  to the host's time. The device never runs ahead of the host when the host acts.
* **Idle skipping:** the RTL exports `quiescent` (nothing changes until an input arrives) and
  `wake_at` (earliest internal deadline: moderation timer, watchdog, fence timeout, reset, SPIN).
  The harness jumps over idle stretches. `skip_equiv` proves this is exact: the same scenario with and
  without skipping produces an identical hash of every time-stamped trace event and interrupt, and
  identical host time.

## 2. Channels (PCIe semantics)

| Channel | Model |
|---|---|
| host → device | one in-order FIFO of posted MMIO writes and MMIO read requests (a read cannot pass an earlier write); one operation delivered per device cycle |
| device → host | one in-order FIFO of posted memory writes, interrupt messages and MMIO read completions; a completion therefore never passes an earlier write (rule O10) |
| DMA reads | request checked by the IOMMU and data captured when issued; beats delivered in order, 8 bytes per ns, starting `dma_rd_lat_ns` later |
| DMA writes | applied to host memory `dma_wr_lat_ns` after issue, in order, IOMMU-checked **on arrival** |
| interrupts | delivered on the device→host channel after the writes before them; ISR starts `msi_to_isr_ns` later |

## 3. Host memory and the DMA oracle

* A 192 MiB arena with IOVAs starting at 4 GiB (exercises 64-bit addresses). Freed memory is
  poisoned with `0xEE`.
* **Simulated IOMMU = DMA oracle.** Every device access must lie inside a range the driver mapped,
  with the needed permission, at the moment it reaches host memory. Violations are blocked (write
  dropped, read returns an error) and counted; every test asserts the count is zero.
* **Store buffer:** CPU stores to DMA memory made through `dma_store` stay invisible to the device
  until `wmb()`. This makes the host side of rule O1 testable (host mutant 1).

## 4. The platform profile (what the CPU and latency numbers rest on)

| Parameter | Default (ns) | Meaning |
|---|---|---|
| `mmio_wr_cpu_ns` | 60 | CPU cost of one posted MMIO write |
| `mmio_wr_lat_ns` | 400 | posted MMIO write flight time |
| `mmio_rd_rtt_ns` | 1000 | MMIO read round trip; the CPU stalls for all of it |
| `dma_rd_lat_ns` | 800 | device read request → first data |
| `dma_wr_lat_ns` | 400 | device write → visible in host memory |
| `msi_to_isr_ns` | 700 | interrupt message arrival → ISR runs |
| `isr_cpu_ns` | 1200 | CPU time of the interrupt handler |
| `wakeup_lat_ns` | 2500 | ISR → sleeping thread runs |
| `ctxsw_cpu_ns` | 2000 | CPU cost of one sleep + wake |
| `timer_lat_ns` | 2500 | wake at a deadline (hrtimer, or a producer's eventfd) |
| `syscall_cpu_ns` | 350 | one ioctl entry/exit (kernel-mediated submission) |
| `kmd_desc_cpu_ns` | 45 | driver validation + copy per descriptor |
| `umd_desc_cpu_ns` | 25 | library encode per descriptor |
| `cqe_cpu_ns` | 30 | parse + dispatch one CQE |
| `poll_iter_ns` | 40 | one spin-poll iteration |
| `barrier_ns` | 5 | one `wmb`/`rmb` |

These are **order-of-magnitude assumptions** for a commodity x86 server with a PCIe Gen4 device,
not measurements. Override any of them with `--profile key=value,...` (bench) or
`sfh_sim_profile_parse()` (tests). `results/BENCHMARKS.md` E6 shows two alternative profiles.

**CPU consumption** = the virtual time the host thread spent busy: syscalls, descriptor work, MMIO
(writes cost `mmio_wr_cpu_ns`; reads stall for the full round trip), CQE parsing, ISRs (charged
whenever an interrupt reaches the host, sleeping or not), context switches, and every polling
iteration. Sleeping costs nothing.

## 5. Fault injection (`sfh_sim_fault`)

| Fault | Used by |
|---|---|
| drop the next N CQE phase-dword writes (completion lost) | `uncertain` |
| copy the next N CQEs into the following slot (duplicate completion) | `cqe_dup`, `stress` |
| drop / duplicate interrupt messages | `irq`, `uncertain`, `stress` |
| hang the kernel unit until aborted | `timeout` |
| freeze the command engine until an engine reset (1) or only a function reset (2) | `timeout` |
| make the next N DMA reads fail | available |
| strict store buffer on/off | default on |

## 6. What the model does not have

No PCIe link layer, credits, TLP splitting or replay; no IOTLB or ATS; no caches, cache-line
granularity, NUMA or memory bandwidth limits on the host; no OS noise, interrupt affinity or
scheduling jitter (so tail latency only reflects queueing, batching and moderation); one host
thread; a 1 GHz device clock with no timing closure behind it.
