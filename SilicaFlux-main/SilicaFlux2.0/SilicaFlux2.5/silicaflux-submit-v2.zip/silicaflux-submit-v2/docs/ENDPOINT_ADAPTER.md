# Physical deployment: the PCIe endpoint adapter

> **Status: untested on hardware.** `adapter/sfh_ep_axi_adapter.sv` is verified only by its
> SystemVerilog testbench against AXI bus-functional models (`make adapter`). `host/src/sfh_vfio.c` is
> compile-checked only (`make vfio`). No PCI vendor/device ID is assigned; none is invented here.

## 1. Where it sits

```
 host CPU ── PCIe link ── [ vendor PCIe endpoint IP, AXI-bridge mode ] ── sfh_ep_axi_adapter ── sfh_top
                           BAR0 → AXI4-Lite master   ───────────────▶ s_axil_*  ─▶ MMIO
                           AXI4 slave → memory TLPs  ◀─────────────── m_axi_*   ◀─ DMA reads / posted writes
                           MSI-X request interface   ◀─────────────── msix_*    ◀─ interrupt messages
```

`sfh_ep_top` (same file) is the integration top: adapter + device. Typical endpoint IPs with this
shape: AMD/Xilinx *DMA/Bridge Subsystem for PCIe* or *QDMA* in AXI-Bridge mode, Intel P-/R-tile
with an AXI bridge, or an open-source endpoint with an AXI front end. The adapter is generic AXI;
the exact signal names of the MSI-X request interface differ per vendor and need a thin shim.

## 2. What the adapter guarantees (and why it must)

The HSI contract assumes PCIe ordering. Inside an endpoint IP, the AXI write-response path, the
AXI-Lite read-data path and the MSI-X request interface are **separate**; nothing orders an MSI-X
request behind AXI writes that are still in the bridge, or a BAR read completion behind them. The
adapter therefore enforces:

| # | Guarantee | Contract rule | Testbench check |
|---|---|---|---|
| A1 | all DMA writes on one AXI ID, single beats, in core order | O5, O7 | data/CQE contents |
| A2 | an interrupt is requested only after every earlier DMA write has its BRESP | O8 | "interrupt before CQE visible" (killed with `ADAPTER_BUG=1`) |
| A3 | a BAR read response is held until every DMA write issued before it was serviced has its BRESP | O10 | "CQ tail read overtakes CQE writes" (killed with `ADAPTER_BUG=2`) |
| A4 | all DMA reads on one AXI ID (in-order data); bursts ≤ 512 B, never across 4 KiB | descriptor/data fetch | 4 KiB-crossing assertion in the memory model |
| A5 | `AxCACHE = 0000`, `AxPROT = 000` | O15 | attribute assertion |
| A6 | BAR accesses one at a time, 32-bit; partial strobes → `SLVERR` | §1 | — |

The testbench's memory model makes a write visible only when its BRESP is sent and randomises
AR/AW/W readiness, read latency (4–40 cycles) and BRESP delay (0–80 cycles). Three seeds pass with
the correct adapter; both mutants fail (9 and 33 failing checks respectively).

## 3. Integration checklist

1. **BAR0**: 32 KiB, 32-bit, non-prefetchable. Map the doorbell pages (`0x1000 + q·0x1000`) to
   user processes only through a driver that gives each process its own page.
2. **Bridge attributes**: confirm in the endpoint documentation how AXI `AxCACHE`/`AxUSER` map to TLP
   attributes and ensure **Relaxed Ordering and No-Snoop are never set** on requests from the adapter.
   The host driver also clears `RELAX_EN`/`NOSNOOP_EN` (Device Control).
3. **Write responses**: confirm what BRESP means in the bridge (accepted into the PCIe ordering
   domain). If the bridge returns BRESP earlier than that, A2/A3 are not sufficient and the shim must
   wait for the bridge's own "write committed" indication.
4. **MSI-X**: one vector per queue (`NQ` vectors); connect `msix_valid/ready/vector` to the vendor
   request interface. If the vendor interface has its own ordering with posted writes, A2 still holds
   (it is conservative).
5. **Timebase**: set `NS_PER_CLK` to the user-clock period (e.g. 4 for 250 MHz). The watchdog,
   moderation and fence timeouts are in ns of this timebase.
6. **Reset**: drive `rst_n` from the endpoint's user reset (link up). Decide whether FLR maps to the
   device's function reset (`FUNC_RESET`) or to `rst_n`; in both cases the host driver restores state
   from its shadow (CONTRACT §11).
7. **DMA error reporting**: `stat_dma_err` is a sticky flag for non-OKAY BRESP/RRESP; wire it to an
   interrupt or AER path. Read errors also reach the core (`DMA_ERROR` completion).
8. **Address width**: the core issues 64-bit addresses (IOVAs); configure the bridge's address
   translation accordingly.
9. **Throughput**: this reference adapter issues single-beat writes (simple, slow); a production
   adapter should merge D2H beats into bursts while keeping A1–A3.
10. **Timing/area**: not synthesised. The core's per-cycle descriptor decode is wide combinational
    logic and will need pipelining for high clock rates.

## 4. Host side: `sfh_vfio.c`

For bring-up in one privileged process: opens the VFIO group/container (type1v2 IOMMU), maps BAR0,
enables bus mastering, clears Relaxed Ordering/No-Snoop, wires one eventfd per MSI-X vector, maps
DMA memory with `VFIO_IOMMU_MAP_DMA` using the same R/W split as the simulated IOMMU, and provides
`sfh_wmb/rmb` as `sfence`/`dmb oshst` and acquire/`dmb oshld`. It implements the same
`sfh_transport` interface as the simulator, so the driver and library run unchanged on it.

For many applications, put the driver layer in a kernel driver (or a broker) that owns VFIO/the IOMMU,
gives each process only its own doorbell page and rings, and implements the release path of
CONTRACT §11.3 in its file-release handler.
