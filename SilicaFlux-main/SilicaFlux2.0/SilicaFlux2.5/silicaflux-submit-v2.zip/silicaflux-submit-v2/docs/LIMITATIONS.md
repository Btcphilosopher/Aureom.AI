# Limitations and claims discipline

## What a passing run means — and does not

Everything here runs in simulation. A pass shows that the RTL, the host runtime and the contract are
**consistent with each other** under the scenarios and faults the tests create, and that each tested
rule has teeth (every mutant that removes one is caught). It does **not** show that the design works
on silicon, on a real PCIe link, behind a real IOMMU, or at any clock frequency, and it is not a
security certification. The RTL and the runtime were written together, so they share the contract's
assumptions.

| Item | Status |
|---|---|
| Device RTL | Verilator 5.020 simulation and lint (`-Wall`) only. Not synthesised, not timed, no DFT, no formal proof. |
| Endpoint adapter | SV testbench against AXI models only. Not integrated with any vendor endpoint IP. |
| VFIO transport | compile-checked with gcc and clang; **never executed**. |
| PCI vendor/device IDs | none assigned, none invented. |
| Benchmarks | cycle behaviour from the RTL + an assumed platform profile; no silicon measurement. |
| Host runtime | user-space library with a privileged driver layer in the same process. Not a Linux kernel driver; the v1 DRM-accel driver has not been ported to v2. |
| Multi-threaded hosts | not exercised; a queue is single-producer/single-consumer by contract, the library holds no locks, the simulator is single-threaded. |
| Process termination | modelled as the driver's release path on a context (what a kernel runs on file release). Real separate OS processes were not used. |

## Functional limitations of HSI v2.0 as implemented

* One execution engine; queues are interleaved, not concurrent. No descriptor prefetch overlapped with
  execution (a fetched batch is executed before the next fetch).
* The data mover keeps at most 4 KiB of reads in flight (≈ 5 GB/s at 800 ns read latency) and writes
  8-byte beats; the reference adapter issues single-beat AXI writes.
* No scatter-gather: a mapping is one contiguous IOVA range (the IOMMU provides the page mapping).
* Mapping table of 32 entries, 4 contexts, 4 queues by default; no per-user quotas.
* Fences: one timeline per queue, waits only within one context, no export to other devices.
* A command's `RESULT` travels only in its CQE: coalesced (`SUPPRESS_CQE`) commands have no result.
* Moderation parameters are fixed at queue enable (no adaptive moderation in hardware); the
  one-shot arm/drain loop provides the adaptive behaviour.
* Function reset leaves device memory undefined; contexts survive but are told (`SFH_CF_DEVMEM_LOST`).
* `UNCERTAIN` commands are never retried automatically; replay is opt-in and only for commands that
  provably never started.
* The kernel unit (`ADD32`, `XOR64`, `SUM32`, `SPIN`) is a stand-in for the SF-G1 compute fabric so
  the submission path has real work to submit; it is not the GPU.

## Verification limitations

* The co-simulation has no OS noise, cache effects, link errors or multiple CPUs; tail latencies in the
  benchmarks come from queueing structure only.
* Randomised stress uses 6 fixed seeds; it is not coverage-closed and not fuzzing.
* The simulated IOMMU checks address ranges and permissions; it does not model IOTLB invalidation
  timing.
* RTL coverage was not measured. The mutation set covers one mutant per ordering/validation rule, not
  every line.
