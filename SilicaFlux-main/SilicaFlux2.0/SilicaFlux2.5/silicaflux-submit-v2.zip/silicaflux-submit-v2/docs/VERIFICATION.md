# Verification

`make all-checks` runs everything below from a clean build and writes logs to
`results/evidence/` (`summary.txt` is the one-page result). Toolchain used: Verilator 5.020,
gcc 13.3, Python 3.13 (`results/evidence/toolchain.txt`).

| Step | What | Result in this package |
|---|---|---|
| `make check-gen` | generated SV package, C header and REGMAP match `spec/sfh_spec.py` | pass |
| `make lint` | Verilator `-Wall` (unused-signal/param and file-name style warnings off) over the device and over adapter + device | clean |
| `make test` | 20 co-simulation tests, real host runtime against the Verilated RTL | **20/20 pass, 22,506 checks, ~6 s** |
| `make adapter` | endpoint-adapter SV testbench, 3 seeds + 2 adapter mutants | 3/3 pass, both mutants caught |
| `make vfio` | VFIO transport compiles (gcc; also checked with clang) | compiles; not executed |
| `make example` | the README example (`examples/quickstart.c`) runs against the simulator | pass |
| `make mutants` | 10 RTL + 5 host mutants, each must make the suite fail | **15/15 killed** (`results/MUTANTS.md`) |

Every test ends by asserting that the simulated IOMMU — the DMA oracle — recorded **zero** device
accesses outside what the driver had mapped at that moment (`env_close`).

## 1. Requested scenarios → tests

| Requirement | Test(s) | What is checked |
|---|---|---|
| Versioned submission descriptors | `stale`, `validation` | v1-format and unknown-version descriptors rejected (`BAD_VERSION`) before any field is used; every other field validated in a fixed order |
| Batched submission | `batch`, `modes`, `stress` | one doorbell per batch; ≤ ⌈32/8⌉+1 fetch bursts for 32 descriptors; coalesced batch → 1 CQE, ≤ 1 interrupt; all-or-nothing validation; `-E2BIG`/`-EAGAIN` |
| Ring-buffer ownership | `wraparound`, `cq_full`, `stale` (f), `proc_term` | slots reused only after release; re-fetch of device-owned slots; CQ never overwritten; rings freed only after quiesce |
| Doorbells | `doorbell`, `stress` | duplicates idempotent and counted; backwards / beyond capacity / disabled-queue / CQ-head-past-tail rejected and counted; nothing executed twice |
| Completion queues | `basic`, `ordering`, `cq_full`, `cqe_dup` | phase protocol over many laps; no torn entries seen by a 1 ns poller; back-pressure |
| Interrupt moderation | `modes`, `batch` | count moderation at least halves interrupts; QD1 latency ≥ timer and < timer + normal path; `IRQ_NOW` bypass; no timer-only wake-ups in fault-free runs |
| Optional polling | `modes`, `ordering`, `wraparound` | POLL and HYBRID give identical results to IRQ; polling never takes an interrupt |
| Fences | `fence` | data visible once the fence value is; non-increasing values refused; cross-queue wait completes only after the signal; a parked wait does not block other queues; wait timeout |
| Timeout recovery | `timeout` | device watchdog; hung unit aborted; host no-progress timeout with watchdog off; frozen engine → engine reset; hard freeze → function reset, mapping table and queues restored, old handles work, `DEVMEM_LOST` reported |
| Queue wraparound | `wraparound` | 70,000 commands on a 16-entry ring: 16-bit positions wrap, the CQ phase flips thousands of times, the 32-bit sequence wraps (starts at 0xFFFFFF00), mixed batch sizes and coalescing, data correct afterwards |
| Duplicate notifications | `irq`, `cqe_dup`, `doorbell`, `stress` | duplicated interrupt messages, duplicated CQEs, duplicated doorbells: every command completes exactly once |
| Stale descriptors | `stale` | unwritten slot from the previous lap (`STALE_SEQ`), descriptor from before a reset (`STALE_EPOCH`), torn slot (`BAD_CHECK`), v1 descriptor, unknown version; commands behind a stale one not executed / replayed |
| Process termination | `proc_term` | process killed while its 512 KiB DMA runs, with a parked fence wait and an armed interrupt: no access after release, the other process's queue never notices (no reset, no recovery), the dead process's window reads as zeros for the next owner, an unwritten slot in reused ring memory never executes |
| Device reset | `timeout`, `uncertain`, `stale` (b) | engine and function resets with work in flight on several queues; device memory survives engine reset; ATT/queues restored after function reset |
| Uncertain completion | `uncertain` | lost CQE of a finished command → `OK` + `RECOVERED` with correct data; lost CQE of a failed command → its real error; reset during a 512 KiB transfer → `UNCERTAIN` (and the data really is partial), commands behind it `NOT_EXECUTED`; lost CQE **and** lost interrupt |
| Validate descriptors | `validation` | 21 malformed-field cases, each with its specific status, plus library-side rejection |
| Driver-authorised DMA / no physical access | `isolation`, `validation`, `revoke`, `proc_term` | forged handles, stale generations, wrong direction, overflow; buffer freed mid-transfer (`MAP_REVOKED`); zero oracle violations everywhere |
| Simulation transport | `skip_equiv` | idle skipping is exact (identical event hash and timing with and without it) |

## 2. Mutation testing

A check that cannot fail proves nothing. Each mutant removes one rule (RTL `MUTANT=n`, host
`SFH_HOST_MUTANT=n`); the suite must fail on every one. Final table: `results/MUTANTS.md`.

| Mutant | Rule removed | Caught by |
|---|---|---|
| RTL 1 | CQE phase dword written first | `ordering`, `wraparound`, `cqe_dup`, `modes` |
| RTL 2 | interrupt may overtake its CQE | `ordering` (zero-latency interrupt profile) |
| RTL 3 | no sequence check | `stale` |
| RTL 4 | no mapping generation check | `validation` |
| RTL 5 | no mapping owner check | `isolation` |
| RTL 6 | no doorbell validation | `doorbell` |
| RTL 7 | moderation timer ignored | `modes` |
| RTL 8 | queue reset reports done while DMA still runs | `proc_term` |
| RTL 9 | no live mapping re-check during a transfer | `revoke` |
| RTL 10 | CQ overwrites unconsumed entries | `cq_full` |
| host 1 | no store barrier before the doorbell | 18 of 20 tests |
| host 2 | no CQE sequence-window check | `cqe_dup`, `stress` |
| host 3 | memory freed before the mapping sync | `revoke` |
| host 4 | no new epoch on re-enable | `stale` |
| host 5 | uncertain completions reported as OK | `timeout`, `uncertain` |

Two mutants (RTL 2 and 7) **survived the first version of the suite**. Both exposed tests that were too
lenient — an interrupt-ordering bug hidden behind a 3 µs modelled interrupt path, and a moderation
check with only a lower latency bound — and the tests were strengthened until both were caught.

## 3. Findings during development (fixed)

The suite found real design problems, not only test bugs:

1. **Queue reset of an idle queue waited for the engine.** A reset was only processed when the command
   FSM was idle, so killing a process whose queue was parked in a fence wait waited behind another
   process's 200 µs kernel, timed out and escalated to an engine reset that disturbed the innocent
   process. Fixed: a queue the engine is not working on quiesces immediately (`proc_term`).
2. **Mapping revocation waited for kernels.** The ATT sync waited for any execution; it now waits only
   for the data mover (kernels never touch host memory).
3. **Recovery loop on a frozen engine.** With the engine frozen while idle, queue resets "succeeded",
   and the driver reset and replayed forever. Fixed with the escalation ladder (a queue that hangs
   again without progress after a queue reset escalates to an engine reset, then a function reset).
4. **Co-simulation skipped over a pending start pulse** (quiescence ignored a registered start), which
   made every command hit the watchdog; caught on the first data-path test, and `skip_equiv` now
   guards the skipping logic.
5. **Lost-CQE interrupt storm.** A lost CQE made every re-arm fire immediately (the device believes the
   entry is unconsumed); four consecutive empty interrupts now trigger the no-progress check early.

## 4. Endpoint adapter testbench

`adapter/tb_ep_axi_adapter.sv`: `sfh_ep_top` (adapter + device) driven over AXI4-Lite, with an AXI4
memory model that randomises ready signals, read latency (4–40 cycles) and write-response delay
(0–80 cycles), and makes a write visible only when its response is sent. 40 commands (H2D, ADD32,
D2H, NOP, FENCE) in random batches through a 16-entry ring; checks A2 at every interrupt and A3 at
every BAR read of the CQ tail, plus all data and the fence value. Correct adapter: pass on 3 seeds
(~606 checks each). `ADAPTER_BUG=1`: 9 failures. `ADAPTER_BUG=2`: 33 failures.

## 5. Baseline

The v1.0 reference front-end testbench from `silicaflux-sfg1-driver-0.1.0` was re-run with the same
Verilator before the redesign: 566 checks pass, both of its ordering mutants are caught.
