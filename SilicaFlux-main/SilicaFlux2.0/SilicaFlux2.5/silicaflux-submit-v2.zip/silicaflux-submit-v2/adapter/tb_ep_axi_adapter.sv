// SPDX-License-Identifier: MIT
// -----------------------------------------------------------------------------
// Testbench: sfh_ep_top (endpoint adapter + device) against AXI bus-functional models.
//   * AXI4-Lite master BFM (the endpoint's BAR0 path)
//   * AXI4 slave memory model with random AR/AW/W ready, random read latency and random
//     DELAYED write responses; a write becomes visible in host memory only when its BRESP
//     is sent (what a bridge acknowledges is what is ordered)
//   * MSI-X sink with random ready
// Checks:
//   A2  when an interrupt is requested, the completion it signals is already visible
//   A3  when a BAR read of the CQ tail returns T, every CQE below T is already visible
//   end-to-end: descriptors fetched over AXI, data copied/computed correctly, fence value
// Run with ADAPTER_BUG = 0 (must PASS), 1 and 2 (must FAIL): adapter/run_adapter_tb.sh
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module tb_ep_axi_adapter;
  import sfh_pkg::*;
  parameter int ADAPTER_BUG = 0;
  parameter int SEED = 1;

  logic clk = 1'b0, rst_n = 1'b0;
  always #2 clk = ~clk;   // 250 MHz

  // ---------------- DUT ports ----------------
  logic s_axil_awvalid = 0, s_axil_awready, s_axil_wvalid = 0, s_axil_wready, s_axil_bvalid, s_axil_bready = 1;
  logic s_axil_arvalid = 0, s_axil_arready, s_axil_rvalid, s_axil_rready = 1;
  logic [15:0] s_axil_awaddr = 0, s_axil_araddr = 0;
  logic [31:0] s_axil_wdata = 0, s_axil_rdata;
  logic [3:0]  s_axil_wstrb = 4'hF;
  logic [1:0]  s_axil_bresp, s_axil_rresp;
  logic m_axi_awvalid, m_axi_awready = 0, m_axi_wvalid, m_axi_wready = 0, m_axi_wlast, m_axi_bvalid = 0, m_axi_bready;
  logic m_axi_arvalid, m_axi_arready = 0, m_axi_rvalid = 0, m_axi_rready, m_axi_rlast = 0;
  logic [63:0] m_axi_awaddr, m_axi_wdata, m_axi_araddr, m_axi_rdata = 0;
  logic [7:0]  m_axi_awlen, m_axi_wstrb, m_axi_arlen;
  logic [2:0]  m_axi_awsize, m_axi_awprot, m_axi_arsize, m_axi_arprot;
  logic [1:0]  m_axi_awburst, m_axi_arburst, m_axi_bresp = 0, m_axi_rresp = 0;
  logic [3:0]  m_axi_awcache, m_axi_arcache;
  logic msix_valid, msix_ready = 0;
  logic [7:0] msix_vector;
  logic stat_dma_err;
  logic [31:0] stat_wr_outstanding;

  sfh_ep_top #(.NS_PER_CLK(4), .WIN_LOG2(16), .ADAPTER_BUG(ADAPTER_BUG)) dut (.*);

  // ---------------- host memory model ----------------
  localparam logic [63:0] HBASE = 64'h1_0000_0000;
  localparam int HWORDS = 8192;                      // 64 KiB
  logic [63:0] hmem [0:HWORDS-1];
  function automatic int widx(input logic [63:0] a); return int'((a - HBASE) >> 3); endfunction
  function automatic logic inr(input logic [63:0] a); return a >= HBASE && a < HBASE + 64'(HWORDS * 8); endfunction

  int errors = 0, checks = 0;
  task automatic fail(input string s); errors++; $display("FAIL @%0t: %s", $time, s); endtask

  // ---------------- AXI4 slave: reads ----------------
  typedef struct { logic [63:0] addr; int beats; int lat; } rreq_t;
  rreq_t rq[$];
  logic [63:0] r_addr; int r_left = 0, r_delay = 0; bit r_active = 0;
  always @(posedge clk) begin
    if (m_axi_arvalid && m_axi_arready) begin
      rreq_t x; x.addr = m_axi_araddr; x.beats = int'(m_axi_arlen) + 1; x.lat = $urandom_range(4, 40);
      if (m_axi_arcache != 4'b0000) fail("ARCACHE must be 0000 (no RO/NS-able attributes)");
      if ((m_axi_araddr[11:0] + 12'((int'(m_axi_arlen) + 1) * 8 - 1)) < m_axi_araddr[11:0]) fail("read burst crosses 4 KiB");
      rq.push_back(x);
    end
    m_axi_arready <= ($urandom_range(0, 3) != 0);
    if (m_axi_rvalid && m_axi_rready) begin
      r_left--; r_addr += 8;
      if (r_left == 0) r_active = 0;
    end
    if (!r_active && rq.size() > 0) begin
      r_addr = rq[0].addr; r_left = rq[0].beats; r_delay = rq[0].lat; rq.pop_front(); r_active = 1;
    end
    if (r_active && r_delay > 0) begin
      r_delay--; m_axi_rvalid <= 1'b0;
    end else if (r_active) begin
      m_axi_rvalid <= 1'b1; m_axi_rlast <= (r_left == 1);
      m_axi_rdata  <= inr(r_addr) ? hmem[widx(r_addr)] : 64'hDEAD_BEEF_DEAD_BEEF;
      m_axi_rresp  <= inr(r_addr) ? 2'b00 : 2'b10;
    end else begin
      m_axi_rvalid <= 1'b0;
    end
  end

  // ---------------- AXI4 slave: writes (visible when the BRESP is sent) ----------------
  typedef struct { logic [63:0] addr; logic [63:0] data; logic [7:0] strb; int delay; } wr_t;
  logic [63:0] awq[$];
  wr_t wq[$], pend[$];
  int nwrites = 0;
  always @(posedge clk) begin
    if (m_axi_awvalid && m_axi_awready) begin
      awq.push_back(m_axi_awaddr);
      if (m_axi_awlen != 0 || m_axi_awcache != 4'b0000) fail("AW attributes");
    end
    if (m_axi_wvalid && m_axi_wready) begin
      wr_t w; w.addr = 0; w.data = m_axi_wdata; w.strb = m_axi_wstrb; w.delay = 0; wq.push_back(w);
    end
    m_axi_awready <= ($urandom_range(0, 3) != 0);
    m_axi_wready  <= ($urandom_range(0, 3) != 0);
    while (awq.size() > 0 && wq.size() > 0) begin
      wr_t w = wq.pop_front();
      w.addr = awq.pop_front(); w.delay = $urandom_range(0, 80);
      pend.push_back(w);
    end
    m_axi_bvalid <= 1'b0;
    if (pend.size() > 0) begin
      if (pend[0].delay > 0) pend[0].delay--;
      else begin
        wr_t w = pend.pop_front();
        if (!inr(w.addr)) fail($sformatf("DMA write outside host memory: %h", w.addr));
        else for (int b = 0; b < 8; b++) if (w.strb[b]) hmem[widx(w.addr)][8*b +: 8] = w.data[8*b +: 8];
        m_axi_bvalid <= 1'b1; m_axi_bresp <= 2'b00; nwrites++;
      end
    end
  end

  // ---------------- queue layout in host memory ----------------
  localparam logic [63:0] SQ  = HBASE + 64'h0000;    // 16 x 64 B
  localparam logic [63:0] CQ  = HBASE + 64'h0400;    // 16 x 16 B
  localparam logic [63:0] FEN = HBASE + 64'h0500;
  localparam logic [63:0] SRC = HBASE + 64'h1000;    // 4 KiB
  localparam logic [63:0] DST = HBASE + 64'h2000;    // 4 KiB
  localparam int N = 40;
  localparam int ENT = 16;
  int host_head = 0;       // CQ position consumed by the host

  function automatic logic cqe_valid(input int pos);
    logic [63:0] w1 = hmem[widx(CQ + 64'((pos % ENT) * 16 + 8))];
    logic ph = ((pos / ENT) % 2 == 0);
    return w1[32] == ph;
  endfunction

  // ---------------- MSI-X sink + check A2 ----------------
  int irqs = 0; bit irq_flag = 0;
  always @(posedge clk) begin
    msix_ready <= ($urandom_range(0, 1) == 1);
    if (msix_valid && msix_ready) begin
      irqs++; irq_flag = 1; checks++;
      if (msix_vector != 0) fail("vector");
      if (!cqe_valid(host_head)) fail($sformatf("A2: interrupt before CQE %0d is visible", host_head));
    end
  end

  // ---------------- AXI4-Lite master BFM ----------------
  // A clocked state machine (samples pre-edge values like the DUT) fed by a command queue;
  // the host program only enqueues and waits for completion.
  typedef struct { bit wr; logic [15:0] a; logic [31:0] d; } lop_t;
  lop_t lq[$];
  int l_issued = 0, l_done = 0;
  logic [31:0] l_rdata;
  typedef enum { L_IDLE, L_W, L_B, L_AR, L_R } lst_t;
  lst_t ls = L_IDLE;
  bit l_awd, l_wd;
  always @(posedge clk) begin
    case (ls)
      L_IDLE: if (lq.size() > 0) begin
        lop_t c = lq.pop_front();
        if (c.wr) begin
          s_axil_awaddr <= c.a; s_axil_wdata <= c.d; s_axil_wstrb <= 4'hF;
          s_axil_awvalid <= 1; s_axil_wvalid <= 1; l_awd = 0; l_wd = 0; ls = L_W;
        end else begin
          s_axil_araddr <= c.a; s_axil_arvalid <= 1; ls = L_AR;
        end
      end
      L_W: begin
        if (s_axil_awvalid && s_axil_awready) begin l_awd = 1; s_axil_awvalid <= 0; end
        if (s_axil_wvalid && s_axil_wready)   begin l_wd = 1;  s_axil_wvalid <= 0; end
        if (l_awd && l_wd) ls = L_B;
      end
      L_B: if (s_axil_bvalid && s_axil_bready) begin
        if (s_axil_bresp != 0) fail("BAR write error");
        l_done++; ls = L_IDLE;
      end
      L_AR: if (s_axil_arvalid && s_axil_arready) begin s_axil_arvalid <= 0; ls = L_R; end
      L_R: if (s_axil_rvalid && s_axil_rready) begin l_rdata = s_axil_rdata; l_done++; ls = L_IDLE; end
      default: ls = L_IDLE;
    endcase
  end
  task automatic axil_write(input logic [15:0] a, input logic [31:0] d);
    lop_t c; int n;
    c.wr = 1; c.a = a; c.d = d; lq.push_back(c); n = ++l_issued;
    while (l_done < n) @(posedge clk);
  endtask
  task automatic axil_read(input logic [15:0] a, output logic [31:0] d);
    lop_t c; int n;
    c.wr = 0; c.a = a; c.d = 0; lq.push_back(c); n = ++l_issued;
    while (l_done < n) @(posedge clk);
    d = l_rdata;
  endtask

  // ---------------- descriptor builder ----------------
  task automatic put_desc(input int pos, input logic [7:0] op, input logic [7:0] fl, input logic [31:0] seq,
                          input logic [31:0] hdl, input logic [31:0] len, input logic [63:0] hoff,
                          input logic [63:0] doff, input logic [63:0] doff2, input logic [63:0] p0, input logic [31:0] p1);
    logic [31:0] w [0:15];
    logic [31:0] x;
    w[0] = {fl, op, 8'd2, 8'hD5}; w[1] = seq; w[2] = 32'd1; w[3] = 32'(pos);
    w[4] = hdl; w[5] = len; w[6] = hoff[31:0]; w[7] = hoff[63:32]; w[8] = doff[31:0]; w[9] = doff[63:32];
    w[10] = doff2[31:0]; w[11] = doff2[63:32]; w[12] = p0[31:0]; w[13] = p0[63:32]; w[14] = p1;
    x = 32'h5F5F5F5F;
    for (int i = 0; i < 15; i++) x ^= w[i];
    w[15] = x;
    for (int i = 0; i < 8; i++) hmem[widx(SQ + 64'((pos % ENT) * 64 + i * 8))] = {w[2*i+1], w[2*i]};
  endtask
  task automatic put_cmd(input int i);
    logic [31:0] seq = 32'd100 + 32'(i);
    case (i % 5)
      0: put_desc(i, 8'd1, 8'd0, seq, 32'h0001_0000, 32'd512, 64'd0, 64'd0, 64'd0, 64'd0, 32'd0);   // H2D
      1: put_desc(i, 8'd3, 8'd0, seq, 32'd0, 32'd512, 64'd0, 64'd0, 64'd1024, 64'(i), 32'd0);       // ADD32
      2: put_desc(i, 8'd2, 8'd0, seq, 32'h0001_0001, 32'd512, 64'((i / 5) * 512), 64'd1024, 64'd0, 64'd0, 32'd0); // D2H
      3: put_desc(i, 8'd0, 8'd0, seq, 32'd0, 32'd0, 64'd0, 64'd0, 64'd0, 64'd0, 32'd0);             // NOP
      default: put_desc(i, 8'd4, 8'd0, seq, 32'd0, 32'd0, 64'd0, 64'd0, 64'd0, 64'(i), 32'd0);      // FENCE
    endcase
  endtask

  // ---------------- host program ----------------
  logic [31:0] rd;
  int published = 0;
  initial begin
    int seed = SEED;
    void'($value$plusargs("SEED=%d", seed));
    void'($urandom(seed));
    for (int i = 0; i < HWORDS; i++) hmem[i] = 64'd0;
    for (int i = 0; i < 512; i++) hmem[widx(SRC) + i] = {32'(i * 7 + 3), 32'(i * 13 + 1)};
    repeat (5) @(posedge clk);
    rst_n = 1'b1;
    repeat (5) @(posedge clk);
    if ($test$plusargs("V")) $display("[tb] reset released @%0t", $time);
    axil_read(SFH_REG_ID, rd);          checks++; if (rd != SFH_CHIP_ID) fail("ID");
    if ($test$plusargs("V")) $display("[tb] ID=%h @%0t", rd, $time);
    axil_read(SFH_REG_HW_VERSION, rd);  checks++; if (rd[31:16] != 16'd2) fail("version");
    // mapping table: entry 0 = SRC (device may read), entry 1 = DST (device may write)
    axil_write(SFH_REG_ATT_IDX, 0); axil_write(SFH_REG_ATT_BASE_LO, SRC[31:0]); axil_write(SFH_REG_ATT_BASE_HI, SRC[63:32]);
    axil_write(SFH_REG_ATT_SIZE, 4096); axil_write(SFH_REG_ATT_CTL, 32'h0001_0003); axil_write(SFH_REG_ATT_CMD, 1);
    axil_write(SFH_REG_ATT_IDX, 1); axil_write(SFH_REG_ATT_BASE_LO, DST[31:0]); axil_write(SFH_REG_ATT_BASE_HI, DST[63:32]);
    axil_write(SFH_REG_ATT_SIZE, 4096); axil_write(SFH_REG_ATT_CTL, 32'h0001_0005); axil_write(SFH_REG_ATT_CMD, 1);
    // queue 0
    axil_write(SFH_QREG_BASE + SFH_QSQ_BASE_LO, SQ[31:0]);  axil_write(SFH_QREG_BASE + SFH_QSQ_BASE_HI, SQ[63:32]);
    axil_write(SFH_QREG_BASE + SFH_QCQ_BASE_LO, CQ[31:0]);  axil_write(SFH_QREG_BASE + SFH_QCQ_BASE_HI, CQ[63:32]);
    axil_write(SFH_QREG_BASE + SFH_QFENCE_LO, FEN[31:0]);   axil_write(SFH_QREG_BASE + SFH_QFENCE_HI, FEN[63:32]);
    axil_write(SFH_QREG_BASE + SFH_QSIZE, 32'h0404);
    axil_write(SFH_QREG_BASE + SFH_QCFG, 32'h0001_0000);   // ctx 0, epoch 1
    axil_write(SFH_QREG_BASE + SFH_QSEQ_BASE, 100);
    axil_write(SFH_QREG_BASE + SFH_QCTL, 1);
    axil_read(SFH_QREG_BASE + SFH_QSTATUS, rd); checks++; if (!rd[0]) fail("queue not enabled");
    if ($test$plusargs("V")) $display("[tb] queue enabled status=%h @%0t", rd, $time);

    while (host_head < N) begin
      // publish a random-size batch that fits
      if (published < N && published - host_head < ENT) begin
        int room = ENT - (published - host_head);
        int nb = $urandom_range(1, 6);
        if (nb > room) nb = room;
        if (nb > N - published) nb = N - published;
        for (int k = 0; k < nb; k++) put_cmd(published + k);
        published += nb;
        axil_write(SFH_DB_BASE + SFH_DB_SQ_TAIL, 32'(published));
        if ($test$plusargs("V")) $display("[tb] published %0d head %0d @%0t", published, host_head, $time);
      end
      repeat ($urandom_range(0, 60)) @(posedge clk);
      // A3: a BAR read of the CQ tail must not overtake the CQE writes below it
      axil_read(SFH_QREG_BASE + SFH_QCQPOS, rd);
      for (int p = host_head; p < int'(rd[31:16]); p++) begin
        checks++;
        if (!cqe_valid(p)) fail($sformatf("A3: CQ tail read %0d but CQE %0d not visible", rd[31:16], p));
      end
      // consume what is visible
      begin
        int got = 0;
        while (host_head < published && cqe_valid(host_head)) begin
          logic [63:0] w0 = hmem[widx(CQ + 64'((host_head % ENT) * 16))];
          logic [63:0] w1 = hmem[widx(CQ + 64'((host_head % ENT) * 16 + 8))];
          checks++;
          if (w1[39:33] != 0) fail($sformatf("cmd %0d status %0d", host_head, w1[39:33]));
          if (w1[31:0] != 32'(100 + host_head)) fail($sformatf("cmd %0d seq %0d", host_head, w1[31:0]));
          if (w0[63:32] != 32'(host_head)) fail("user tag");
          host_head++; got++;
        end
        if (got) axil_write(SFH_DB_BASE + SFH_DB_CQ_HEAD, 32'(host_head));
        if (!got && host_head < published) begin
          int t = 0;
          irq_flag = 0;
          axil_write(SFH_DB_BASE + SFH_DB_CQ_ARM, 1);
          while (!irq_flag && t < 50000) begin @(posedge clk); t++; end
          if (!irq_flag) begin fail("no interrupt"); break; end
        end
      end
    end
    // end-to-end results
    for (int g = 0; g < N / 5; g++)
      for (int j = 0; j < 64; j++) begin
        logic [63:0] s = hmem[widx(SRC) + j], dv = hmem[widx(DST) + g * 64 + j];
        logic [31:0] k = 32'(g * 5 + 1);
        checks++;
        if (dv != {s[63:32] + k, s[31:0] + k}) begin fail($sformatf("data group %0d word %0d", g, j)); break; end
      end
    checks++; if (hmem[widx(FEN)] != 64'(N - 1)) fail("fence value");
    checks++; if (stat_dma_err) fail("DMA error flagged");
    $display("TB_RESULT %s checks=%0d errors=%0d irqs=%0d dma_writes=%0d (ADAPTER_BUG=%0d)",
             errors ? "FAIL" : "PASS", checks, errors, irqs, nwrites, ADAPTER_BUG);
    $finish;
  end
  initial begin #20ms; $display("TB_RESULT FAIL timeout"); $finish; end
endmodule
