// SPDX-License-Identifier: MIT
// -----------------------------------------------------------------------------
// SilicaFlux HSI v2 — PCIe endpoint adapter (AXI bridge flavour)
//
// Connects the core's transport boundary (sfh_top) to a vendor PCIe endpoint IP that
// exposes the link as AXI:
//   * BAR0 accesses arrive on an AXI4-Lite master of the endpoint -> s_axil_* here
//   * device-initiated DMA leaves through an AXI4 slave of the endpoint
//     ("bridge"/"requester" port that turns AXI into memory TLPs) <- m_axi_* here
//   * interrupts are requested on the endpoint's MSI-X request interface -> msix_*
// See docs/ENDPOINT_ADAPTER.md for the integration checklist. NOT validated on hardware.
//
// The HSI ordering contract assumes PCIe semantics end to end. AXI does not give them
// for free, because write responses, read data returned on the AXI-Lite slave and the
// MSI-X request interface are independent paths inside the endpoint. This adapter
// therefore enforces:
//   A1  all DMA writes use one AXI ID, AXI single beats, issued in core order
//       (same-ID writes are ordered by AXI);
//   A2  an interrupt for the core is requested only after every DMA write the core
//       issued before it has received its BRESP (contract rule O5 / "MSI after CQE");
//   A3  a BAR read response is returned only after every DMA write issued before the
//       read was serviced has received its BRESP (rule O10: a read flushes posted writes);
//   A4  all DMA reads use one AXI ID, so read data returns in request order (the core
//       requires in-order beats); bursts never cross 4 KiB (the core never asks it to);
//   A5  AxCACHE = 0000 (device, non-bufferable), AxPROT = 000; the integrator must make
//       sure the endpoint never sets Relaxed Ordering or No-Snoop on these TLPs.
//   A6  BAR accesses are handled one at a time, 32-bit only (partial strobes -> SLVERR).
// It also provides the device timebase (`now`, ns) the core's timers use.
//
// ADAPTER_BUG (verification only; 0 in any real build): 1 = interrupt without waiting
// for BRESPs (breaks A2), 2 = BAR read data without waiting for BRESPs (breaks A3).
// adapter/tb_ep_axi_adapter.sv must FAIL on both.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
module sfh_ep_axi_adapter #(
  parameter int AXIL_AW     = 16,
  parameter int MAX_RD_OUT  = 8,     // outstanding read bursts
  parameter int MAX_WR_OUT  = 16,    // outstanding single-beat writes
  parameter int NS_PER_CLK  = 4,     // timebase increment per clock (250 MHz -> 4)
  parameter int ADAPTER_BUG = 0
) (
  input  logic               clk,
  input  logic               rst_n,
  // ---------------- AXI4-Lite slave: BAR0 ----------------
  input  logic               s_axil_awvalid,
  output logic               s_axil_awready,
  input  logic [AXIL_AW-1:0] s_axil_awaddr,
  input  logic               s_axil_wvalid,
  output logic               s_axil_wready,
  input  logic [31:0]        s_axil_wdata,
  input  logic [3:0]         s_axil_wstrb,
  output logic               s_axil_bvalid,
  input  logic               s_axil_bready,
  output logic [1:0]         s_axil_bresp,
  input  logic               s_axil_arvalid,
  output logic               s_axil_arready,
  input  logic [AXIL_AW-1:0] s_axil_araddr,
  output logic               s_axil_rvalid,
  input  logic               s_axil_rready,
  output logic [31:0]        s_axil_rdata,
  output logic [1:0]         s_axil_rresp,
  // ---------------- AXI4 master: DMA ----------------
  output logic               m_axi_awvalid,
  input  logic               m_axi_awready,
  output logic [63:0]        m_axi_awaddr,
  output logic [7:0]         m_axi_awlen,
  output logic [2:0]         m_axi_awsize,
  output logic [1:0]         m_axi_awburst,
  output logic [3:0]         m_axi_awcache,
  output logic [2:0]         m_axi_awprot,
  output logic               m_axi_wvalid,
  input  logic               m_axi_wready,
  output logic [63:0]        m_axi_wdata,
  output logic [7:0]         m_axi_wstrb,
  output logic               m_axi_wlast,
  input  logic               m_axi_bvalid,
  output logic               m_axi_bready,
  input  logic [1:0]         m_axi_bresp,
  output logic               m_axi_arvalid,
  input  logic               m_axi_arready,
  output logic [63:0]        m_axi_araddr,
  output logic [7:0]         m_axi_arlen,
  output logic [2:0]         m_axi_arsize,
  output logic [1:0]         m_axi_arburst,
  output logic [3:0]         m_axi_arcache,
  output logic [2:0]         m_axi_arprot,
  input  logic               m_axi_rvalid,
  output logic               m_axi_rready,
  input  logic [63:0]        m_axi_rdata,
  input  logic [1:0]         m_axi_rresp,
  input  logic               m_axi_rlast,
  // ---------------- MSI-X request ----------------
  output logic               msix_valid,
  input  logic               msix_ready,
  output logic [7:0]         msix_vector,
  // ---------------- core transport boundary ----------------
  output logic [63:0]        now,
  output logic               core_mmio_wr_valid,
  output logic [15:0]        core_mmio_wr_addr,
  output logic [31:0]        core_mmio_wr_data,
  output logic               core_mmio_rd_valid,
  output logic [15:0]        core_mmio_rd_addr,
  input  logic               core_mmio_rd_resp_valid,
  input  logic [31:0]        core_mmio_rd_data,
  input  logic               core_rd_req_valid,
  output logic               core_rd_req_ready,
  input  logic [63:0]        core_rd_req_addr,
  input  logic [9:0]         core_rd_req_len,
  output logic               core_rd_rsp_valid,
  output logic [63:0]        core_rd_rsp_data,
  output logic               core_rd_rsp_err,
  input  logic               core_wr_valid,
  output logic               core_wr_ready,
  input  logic [63:0]        core_wr_addr,
  input  logic [63:0]        core_wr_data,
  input  logic [7:0]         core_wr_be,
  input  logic               core_wr_msi,
  // ---------------- status ----------------
  output logic               stat_dma_err,      // sticky: a DMA write/read got a non-OKAY response
  output logic [31:0]        stat_wr_outstanding
);
  // ======================= timebase =======================
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) now <= '0; else now <= now + 64'(NS_PER_CLK);

  // ======================= write path (posted writes + interrupt messages) =======================
  localparam int FD = 8;
  typedef struct packed { logic msi; logic [63:0] addr; logic [63:0] data; logic [7:0] be; logic [31:0] tgt; } went_t;
  went_t       wf [0:FD-1];
  logic [2:0]  wf_rd, wf_wr;
  logic [3:0]  wf_cnt;
  logic [31:0] wr_accepted;   // DMA write beats accepted from the core (not interrupts)
  logic [31:0] wr_done;       // BRESPs received
  logic        aw_sent, w_sent;

  assign core_wr_ready = (wf_cnt != 4'(FD));
  wire   push = core_wr_valid && core_wr_ready;
  wire   went_t head = wf[wf_rd];
  wire   have = (wf_cnt != 0);
  // writes issued to AXI but not yet acknowledged
  logic [31:0] axi_out;
  assign stat_wr_outstanding = axi_out;

  // interrupt at the head: wait until every write accepted before it is acknowledged (A2)
  wire msi_clear = (ADAPTER_BUG == 1) ? 1'b1 : ((wr_done - head.tgt) < 32'h8000_0000);
  assign msix_valid  = have && head.msi && msi_clear;
  assign msix_vector = head.data[7:0];
  // write at the head: one AXI single-beat write
  wire wr_head  = have && !head.msi && (axi_out < 32'(MAX_WR_OUT));
  assign m_axi_awvalid = wr_head && !aw_sent;
  assign m_axi_awaddr  = head.addr;
  assign m_axi_awlen   = 8'd0;
  assign m_axi_awsize  = 3'd3;
  assign m_axi_awburst = 2'b01;
  assign m_axi_awcache = 4'b0000;
  assign m_axi_awprot  = 3'b000;
  assign m_axi_wvalid  = wr_head && !w_sent;
  assign m_axi_wdata   = head.data;
  assign m_axi_wstrb   = head.be;
  assign m_axi_wlast   = 1'b1;
  assign m_axi_bready  = 1'b1;
  wire aw_fire = m_axi_awvalid && m_axi_awready;
  wire w_fire  = m_axi_wvalid && m_axi_wready;
  wire beat_done = wr_head && (aw_sent || aw_fire) && (w_sent || w_fire);
  wire pop = beat_done || (msix_valid && msix_ready);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wf_rd <= '0; wf_wr <= '0; wf_cnt <= '0; wr_accepted <= '0; wr_done <= '0;
      aw_sent <= 1'b0; w_sent <= 1'b0; axi_out <= '0; stat_dma_err <= 1'b0;
      for (int i = 0; i < FD; i++) wf[i] <= '0;
    end else begin
      if (push) begin
        wf[wf_wr] <= '{msi: core_wr_msi, addr: core_wr_addr, data: core_wr_data, be: core_wr_be,
                       tgt: wr_accepted};
        wf_wr <= wf_wr + 1'b1;
        if (!core_wr_msi) wr_accepted <= wr_accepted + 32'd1;
      end
      wf_cnt <= wf_cnt + (push ? 4'd1 : 4'd0) - (pop ? 4'd1 : 4'd0);
      if (pop) wf_rd <= wf_rd + 1'b1;
      if (beat_done) begin aw_sent <= 1'b0; w_sent <= 1'b0; end
      else begin
        if (aw_fire) aw_sent <= 1'b1;
        if (w_fire)  w_sent  <= 1'b1;
      end
      axi_out <= axi_out + (beat_done ? 32'd1 : 32'd0) - (m_axi_bvalid ? 32'd1 : 32'd0);
      if (m_axi_bvalid) begin
        wr_done <= wr_done + 32'd1;
        if (m_axi_bresp != 2'b00) stat_dma_err <= 1'b1;
      end
      if (m_axi_rvalid && m_axi_rresp != 2'b00) stat_dma_err <= 1'b1;
    end
  end

  // ======================= read path =======================
  logic [3:0] rd_out;
  assign m_axi_arvalid     = core_rd_req_valid && (rd_out < 4'(MAX_RD_OUT));
  assign core_rd_req_ready = m_axi_arready && (rd_out < 4'(MAX_RD_OUT));
  assign m_axi_araddr      = core_rd_req_addr;
  assign m_axi_arlen       = 8'(core_rd_req_len[9:3] - 7'd1);
  assign m_axi_arsize      = 3'd3;
  assign m_axi_arburst     = 2'b01;
  assign m_axi_arcache     = 4'b0000;
  assign m_axi_arprot      = 3'b000;
  assign m_axi_rready      = 1'b1;
  assign core_rd_rsp_valid = m_axi_rvalid;
  assign core_rd_rsp_data  = m_axi_rdata;
  assign core_rd_rsp_err   = (m_axi_rresp != 2'b00);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rd_out <= '0;
    else rd_out <= rd_out + ((m_axi_arvalid && m_axi_arready) ? 4'd1 : 4'd0)
                          - ((m_axi_rvalid && m_axi_rlast) ? 4'd1 : 4'd0);
  end

  // ======================= BAR0 (AXI4-Lite), one access at a time =======================
  typedef enum logic [2:0] { B_IDLE, B_WR, B_WRESP, B_RD, B_RWAIT, B_RHOLD, B_RRESP } bstate_t;
  bstate_t bs;
  logic [AXIL_AW-1:0] b_addr;
  logic [31:0]        b_wdata, b_rdata, b_tgt;
  logic [3:0]         b_strb;
  logic               aw_got, w_got;

  assign s_axil_awready = (bs == B_IDLE) && !aw_got;
  assign s_axil_wready  = (bs == B_IDLE) && !w_got;
  assign s_axil_arready = (bs == B_IDLE) && !aw_got && !w_got && !s_axil_awvalid && !s_axil_wvalid;
  assign s_axil_bvalid  = (bs == B_WRESP);
  assign s_axil_bresp   = (b_strb == 4'hF) ? 2'b00 : 2'b10;
  assign s_axil_rvalid  = (bs == B_RRESP);
  assign s_axil_rdata   = b_rdata;
  assign s_axil_rresp   = 2'b00;
  assign core_mmio_wr_valid = (bs == B_WR) && (b_strb == 4'hF);
  assign core_mmio_wr_addr  = 16'(b_addr);
  assign core_mmio_wr_data  = b_wdata;
  assign core_mmio_rd_valid = (bs == B_RD);
  assign core_mmio_rd_addr  = 16'(b_addr);
  // all DMA writes the core issued before the read was serviced have been acknowledged (A3)
  wire rd_clear = (ADAPTER_BUG == 2) ? 1'b1 : ((wr_done - b_tgt) < 32'h8000_0000);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bs <= B_IDLE; b_addr <= '0; b_wdata <= '0; b_rdata <= '0; b_tgt <= '0; b_strb <= '0;
      aw_got <= 1'b0; w_got <= 1'b0;
    end else begin
      case (bs)
        B_IDLE: begin
          if (s_axil_awvalid && s_axil_awready) begin aw_got <= 1'b1; b_addr <= {s_axil_awaddr[AXIL_AW-1:2], 2'b00}; end
          if (s_axil_wvalid && s_axil_wready)   begin w_got <= 1'b1; b_wdata <= s_axil_wdata; b_strb <= s_axil_wstrb; end
          if ((aw_got || (s_axil_awvalid && s_axil_awready)) && (w_got || (s_axil_wvalid && s_axil_wready))) begin
            bs <= B_WR;
          end else if (s_axil_arvalid && s_axil_arready) begin
            b_addr <= {s_axil_araddr[AXIL_AW-1:2], 2'b00}; b_strb <= 4'hF; bs <= B_RD;
          end
        end
        B_WR:    begin aw_got <= 1'b0; w_got <= 1'b0; bs <= B_WRESP; end
        B_WRESP: if (s_axil_bready) bs <= B_IDLE;
        B_RD:    begin b_tgt <= wr_accepted; bs <= B_RWAIT; end
        B_RWAIT: if (core_mmio_rd_resp_valid) begin b_rdata <= core_mmio_rd_data; bs <= B_RHOLD; end
        B_RHOLD: if (rd_clear) bs <= B_RRESP;
        B_RRESP: if (s_axil_rready) bs <= B_IDLE;
        default: bs <= B_IDLE;
      endcase
    end
  end
endmodule

// -----------------------------------------------------------------------------
// Endpoint-facing top: adapter + device. This is what an FPGA/ASIC integrator
// instantiates next to the vendor PCIe endpoint.
// -----------------------------------------------------------------------------
module sfh_ep_top #(
  parameter int NS_PER_CLK  = 4,
  parameter int WIN_LOG2    = 20,
  parameter int ADAPTER_BUG = 0
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        s_axil_awvalid, output logic s_axil_awready, input logic [15:0] s_axil_awaddr,
  input  logic        s_axil_wvalid,  output logic s_axil_wready,  input logic [31:0] s_axil_wdata,
  input  logic [3:0]  s_axil_wstrb,
  output logic        s_axil_bvalid,  input  logic s_axil_bready, output logic [1:0] s_axil_bresp,
  input  logic        s_axil_arvalid, output logic s_axil_arready, input logic [15:0] s_axil_araddr,
  output logic        s_axil_rvalid,  input  logic s_axil_rready, output logic [31:0] s_axil_rdata,
  output logic [1:0]  s_axil_rresp,
  output logic        m_axi_awvalid,  input  logic m_axi_awready, output logic [63:0] m_axi_awaddr,
  output logic [7:0]  m_axi_awlen,    output logic [2:0] m_axi_awsize, output logic [1:0] m_axi_awburst,
  output logic [3:0]  m_axi_awcache,  output logic [2:0] m_axi_awprot,
  output logic        m_axi_wvalid,   input  logic m_axi_wready, output logic [63:0] m_axi_wdata,
  output logic [7:0]  m_axi_wstrb,    output logic m_axi_wlast,
  input  logic        m_axi_bvalid,   output logic m_axi_bready, input logic [1:0] m_axi_bresp,
  output logic        m_axi_arvalid,  input  logic m_axi_arready, output logic [63:0] m_axi_araddr,
  output logic [7:0]  m_axi_arlen,    output logic [2:0] m_axi_arsize, output logic [1:0] m_axi_arburst,
  output logic [3:0]  m_axi_arcache,  output logic [2:0] m_axi_arprot,
  input  logic        m_axi_rvalid,   output logic m_axi_rready, input logic [63:0] m_axi_rdata,
  input  logic [1:0]  m_axi_rresp,    input  logic m_axi_rlast,
  output logic        msix_valid,     input  logic msix_ready, output logic [7:0] msix_vector,
  output logic        stat_dma_err,
  output logic [31:0] stat_wr_outstanding
);
  logic [63:0] now;
  logic        mmio_wr_valid, mmio_rd_valid, mmio_rd_resp_valid;
  logic [15:0] mmio_wr_addr, mmio_rd_addr;
  logic [31:0] mmio_wr_data, mmio_rd_data;
  logic        rd_req_valid, rd_req_ready, rd_rsp_valid, rd_rsp_err;
  logic [63:0] rd_req_addr, rd_rsp_data;
  logic [9:0]  rd_req_len;
  logic        wr_valid, wr_ready, wr_msi;
  logic [63:0] wr_addr, wr_data;
  logic [7:0]  wr_be;

  sfh_ep_axi_adapter #(.NS_PER_CLK(NS_PER_CLK), .ADAPTER_BUG(ADAPTER_BUG)) u_adapter (
    .clk, .rst_n,
    .s_axil_awvalid, .s_axil_awready, .s_axil_awaddr, .s_axil_wvalid, .s_axil_wready, .s_axil_wdata,
    .s_axil_wstrb, .s_axil_bvalid, .s_axil_bready, .s_axil_bresp, .s_axil_arvalid, .s_axil_arready,
    .s_axil_araddr, .s_axil_rvalid, .s_axil_rready, .s_axil_rdata, .s_axil_rresp,
    .m_axi_awvalid, .m_axi_awready, .m_axi_awaddr, .m_axi_awlen, .m_axi_awsize, .m_axi_awburst,
    .m_axi_awcache, .m_axi_awprot, .m_axi_wvalid, .m_axi_wready, .m_axi_wdata, .m_axi_wstrb,
    .m_axi_wlast, .m_axi_bvalid, .m_axi_bready, .m_axi_bresp, .m_axi_arvalid, .m_axi_arready,
    .m_axi_araddr, .m_axi_arlen, .m_axi_arsize, .m_axi_arburst, .m_axi_arcache, .m_axi_arprot,
    .m_axi_rvalid, .m_axi_rready, .m_axi_rdata, .m_axi_rresp, .m_axi_rlast,
    .msix_valid, .msix_ready, .msix_vector, .now,
    .core_mmio_wr_valid(mmio_wr_valid), .core_mmio_wr_addr(mmio_wr_addr), .core_mmio_wr_data(mmio_wr_data),
    .core_mmio_rd_valid(mmio_rd_valid), .core_mmio_rd_addr(mmio_rd_addr),
    .core_mmio_rd_resp_valid(mmio_rd_resp_valid), .core_mmio_rd_data(mmio_rd_data),
    .core_rd_req_valid(rd_req_valid), .core_rd_req_ready(rd_req_ready), .core_rd_req_addr(rd_req_addr),
    .core_rd_req_len(rd_req_len), .core_rd_rsp_valid(rd_rsp_valid), .core_rd_rsp_data(rd_rsp_data),
    .core_rd_rsp_err(rd_rsp_err), .core_wr_valid(wr_valid), .core_wr_ready(wr_ready),
    .core_wr_addr(wr_addr), .core_wr_data(wr_data), .core_wr_be(wr_be), .core_wr_msi(wr_msi),
    .stat_dma_err, .stat_wr_outstanding);

  /* verilator lint_off PINCONNECTEMPTY */
  sfh_top #(.WIN_LOG2(WIN_LOG2)) u_dev (
    .clk, .rst_n, .now,
    .mmio_wr_valid, .mmio_wr_addr, .mmio_wr_data, .mmio_rd_valid, .mmio_rd_addr,
    .mmio_rd_resp_valid, .mmio_rd_data,
    .rd_req_valid, .rd_req_ready, .rd_req_addr, .rd_req_len, .rd_rsp_valid, .rd_rsp_data, .rd_rsp_err,
    .wr_valid, .wr_ready, .wr_addr, .wr_data, .wr_be, .wr_msi,
    .fi_kernel_hang(1'b0), .fi_freeze(1'b0),
    .quiescent(), .wake_at(), .eng_reset_pulse(),
    .trc_fetch_v(), .trc_fetch_q(), .trc_fetch_seq(), .trc_fetch_n(),
    .trc_start_v(), .trc_start_q(), .trc_start_seq(),
    .trc_end_v(), .trc_end_q(), .trc_end_seq(), .trc_end_status(),
    .trc_cqe_v(), .trc_cqe_q(), .trc_cqe_seq());
  /* verilator lint_on PINCONNECTEMPTY */
endmodule
