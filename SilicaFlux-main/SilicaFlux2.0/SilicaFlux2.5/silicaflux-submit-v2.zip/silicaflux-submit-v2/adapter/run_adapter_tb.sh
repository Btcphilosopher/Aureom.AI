#!/bin/bash
# SPDX-License-Identifier: MIT
# Endpoint adapter testbench. Needs Verilator >= 5 (--binary --timing).
#   ADAPTER_BUG=0  correct adapter                       -> must PASS (3 seeds)
#   ADAPTER_BUG=1  interrupt without waiting for BRESPs  -> must FAIL
#   ADAPTER_BUG=2  BAR read without waiting for BRESPs   -> must FAIL
set -uo pipefail
cd "$(dirname "$0")/.."
OUT=build/adapter
mkdir -p "$OUT"
SRCS="rtl/sfh_pkg.sv rtl/sfh_devmem.sv rtl/sfh_kernel.sv rtl/sfh_datamover.sv rtl/sfh_core.sv rtl/sfh_top.sv
      adapter/sfh_ep_axi_adapter.sv adapter/tb_ep_axi_adapter.sv"
rc=0
run() { # bug seed expect
  local bug=$1
  local seed=$2
  local expect=$3
  local dir="$OUT/b${bug}"
  if [ ! -x "$dir/sim" ]; then
    verilator --binary --timing -j 4 -Wno-fatal -Wno-lint -Wno-style --top-module tb_ep_axi_adapter \
      -GADAPTER_BUG="$bug" --Mdir "$dir" -o sim $SRCS > "$dir.build.log" 2>&1 || {
        echo "build failed (bug=$bug)"; tail -20 "$dir.build.log"; return 1; }
  fi
  "$dir/sim" +verilator+seed+"$seed" "+SEED=$seed" > "$OUT/run_b${bug}_s${seed}.log" 2>&1
  local res; res=$(grep TB_RESULT "$OUT/run_b${bug}_s${seed}.log" | tail -1)
  local nf; nf=$(grep -c "FAIL @" "$OUT/run_b${bug}_s${seed}.log")
  printf "ADAPTER_BUG=%s seed=%s expect %-4s -> %s (%s failing checks)\n" "$bug" "$seed" "$expect" "${res:-no result}" "$nf"
  if [ "$expect" = PASS ]; then echo "$res" | grep -q "TB_RESULT PASS" || return 1
  else echo "$res" | grep -q "TB_RESULT FAIL" || return 1; fi
}
for s in 1 2 3; do run 0 "$s" PASS || rc=1; done
run 1 1 FAIL || rc=1
run 2 1 FAIL || rc=1
[ $rc -eq 0 ] && echo "ADAPTER TB OK: adapter passes, both ordering mutants are caught" || echo "ADAPTER TB FAILED"
exit $rc
