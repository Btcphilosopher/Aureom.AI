// SPDX-License-Identifier: MIT
/* The README example, runnable against the simulation transport: `make example`. */
#include <stdio.h>
#include <string.h>
#include "sfh.h"
#include "sfh_cosim.h"

int main(void)
{
	void *sim = sfh_sim_create(NULL);                 /* default platform profile */
	const sfh_transport *transport = sfh_sim_transport(sim);

	sfh_dev *d;  sfh_ctx *c;  sfh_queue *q;  sfh_buf *b, *out;
	if (sfh_dev_open(transport, NULL, &d)) return 1;  /* driver layer: probe, limits, self-test */
	sfh_ctx_open(d, &c);                               /* one per process */
	sfh_buf_alloc(c, 1 << 20, SFH_BUF_DEV_READ, &b);   /* driver maps it; the app never sees an address */
	sfh_buf_alloc(c, 4096, SFH_BUF_DEV_WRITE, &out);
	memset(sfh_buf_ptr(b), 0x42, 4096);
	sfh_queue_params p;  sfh_queue_params_default(&p);
	p.notify = SFH_NOTIFY_HYBRID;  p.imod_count = 8;  p.imod_time_ns = 20000;
	sfh_queue_create(c, &p, &q);
	sfh_cmd cmds[3] = { { .op = SFH_OP_COPY_H2D, .buf = b, .len = 4096 },
	                    { .op = SFH_OP_COPY_D2H, .buf = out, .len = 4096 },
	                    { .op = SFH_OP_FENCE_SIGNAL, .value = 1 } };
	uint64_t t;  sfh_submit(q, cmds, 3, SFH_SUBMIT_COALESCE | SFH_SUBMIT_IRQ_LAST, &t);
	sfh_completion r;  int rc = sfh_wait_ticket(q, t + 2, 1000000000ull, &r);

	int same = memcmp(sfh_buf_ptr(b), sfh_buf_ptr(out), 4096) == 0;
	printf("wait rc=%d status=%s fence=%llu data %s, host time %llu ns\n", rc, sfh_status_str(r.status),
	       (unsigned long long)sfh_fence_read(q), same ? "round-tripped" : "MISMATCH",
	       (unsigned long long)sfh_now(q));
	sfh_dev_close(d);
	sfh_sim_destroy(sim);
	return (rc == 0 && r.status == 0 && same) ? 0 : 1;
}
