/* BootWorks - boot status and reporting.
 *
 * Reporting channels (the Albion ControlCore has no UART; these are the real, host-visible paths):
 *   1. MGMT.FW_STATUS     live progress  BW_ST_LIVE(stage,test,failures)  ->  final BW_SIG_PASS / BW_SIG_FAIL
 *      MGMT.FW_HEARTBEAT  number of tests started
 *      MGMT.FW_VERSION    BW_VERSION
 *      MGMT.SCRATCH       final: [31:16] FAIL+TIMEOUT count, [15:0] first failing diagnostic code
 *   2. Mailbox completion queue: BOOT_START and SUMMARY records (host pops via HCPL_*).
 *   3. g_report in SRAM bank 0: every result + a CRC-32 signature. The host reads it after
 *      halting the core (CORE_CTRL.RUN = 0 re-enters BOOT_MODE) - BootWorks never sets BOOT_LOCK.
 */
#include "bw_internal.h"

bw_report_t g_report;

/* Out of line on purpose: an inline 16-byte struct build costs ~14 RV32I instructions (56 B) at every
 * failure site; there are several hundred. */
bw_result_t bw_res(uint32_t outcome, uint32_t diag, uint32_t a0, uint32_t a1, uint32_t a2) {
  bw_result_t r;
  r.diag = (uint16_t)diag; r.outcome = (uint8_t)outcome; r.test = 0;
  r.aux0 = a0; r.aux1 = a1; r.aux2 = a2;
  return r;
}
bw_result_t bw_fail(uint32_t diag, uint32_t a0, uint32_t a1, uint32_t a2) { return bw_res(BW_FAIL, diag, a0, a1, a2); }
bw_result_t bw_tmo(uint32_t diag, uint32_t a0, uint32_t a1, uint32_t a2)  { return bw_res(BW_TIMEOUT, diag, a0, a1, a2); }

static uint32_t crc_tab[16];

/* ---------------------------------------------------------------- CRC-32 (zlib polynomial) */
static void crc_init(void) {
  for (uint32_t i = 0; i < 16u; i++) {
    uint32_t c = i;
    for (int k = 0; k < 4; k++) c = (c & 1u) ? (c >> 1) ^ 0xEDB88320u : (c >> 1);
    crc_tab[i] = c;
  }
}

uint32_t bw_crc32(const void *p, uint32_t len, uint32_t crc) {
  const volatile uint8_t *b = (const volatile uint8_t *)p;
  crc = ~crc;
  while (len--) {
    crc ^= *b++;
    crc = (crc >> 4) ^ crc_tab[crc & 15u];
    crc = (crc >> 4) ^ crc_tab[crc & 15u];
  }
  return ~crc;
}

/* ---------------------------------------------------------------- status */
void bw_status_set(uint32_t v) { BW_MGMT(ALBION_MGMT_FW_STATUS) = v; }

void bw_irq_clear_all(void) { BW_IRQ(ALBION_IRQ_CLEAR) = BW_IRQ_ALL; }

void bw_win_close_all(void) {
  uint32_t nw = g_hw.windows;
  for (uint32_t i = 0; i < nw; i++) {
    uint32_t off = ALBION_PERM_WIN_BASE + i * ALBION_PERM_WIN_BASE_STRIDE;
    BW_PERM(off + 8u) = 0u;     /* invalidate first */
    BW_PERM(off + 0u) = 0u;
    BW_PERM(off + 4u) = 0u;
  }
}

/* Between tests: leave the hardware in a known quiet state so one test cannot colour the next. */
void bw_cleanup_hw(void) {
  BW_CSR_C(mstatus, MSTATUS_MIE);
  BW_CSR_C(mie, MIE_MEIE);
  BW_IRQ(ALBION_IRQ_ENABLE) = 0u;
  bw_irq_clear_all();
  bw_win_close_all();
  BW_TELEM(ALBION_TELEM_CTRL) = 0u;          /* unfreeze */
  BW_RAS(ALBION_RAS_INJ_CTRL) = 0u;          /* disarm injection */
  for (uint32_t i = 0; i < 64u; i++) ((volatile uint32_t *)BW_SYM(bw_sandbox))[i] = 0u;   /* keep the image CRC valid */
  (void)BW_POLL(!(BW_DMA(ALBION_DMA_STATUS) & ALBION_DMA_STATUS_BUSY_MASK), BW_DMA_DEADLINE / 4u);   /* a stuck DMA must not stall every later test */
  bw_tc.irq_count = 0; bw_tc.irq_seen = 0; bw_tc.irq_stuck = 0; bw_tc.irq_ack = 0;
}

/* ---------------------------------------------------------------- report */
void bw_report_init(void) {
  crc_init();
  g_report.magic      = BW_REPORT_MAGIC;
  g_report.layout     = BW_REPORT_LAYOUT;
  g_report.fw_version = BW_VERSION;
  g_report.state      = BW_STATE_RUNNING;
  g_report.n_tests    = BW_NUM_TESTS;
  /* Every slot starts as "never executed" so a hang or skipped table entry is visible. */
  for (uint32_t i = 0; i < BW_NUM_TESTS; i++) {
    g_report.results[i].test    = (uint8_t)i;
    g_report.results[i].outcome = BW_FAIL;
    g_report.results[i].diag    = BW_D_INT_NOT_RUN;
  }
  BW_MGMT(ALBION_MGMT_FW_VERSION)   = BW_VERSION;
  BW_MGMT(ALBION_MGMT_FW_HEARTBEAT) = 0u;
}

static void record(const bw_result_t *r) {
  g_report.results[r->test] = *r;
  g_report.count[r->outcome]++;
  g_report.n_done++;
  if ((r->outcome == BW_FAIL || r->outcome == BW_TIMEOUT) && g_report.first_fail_diag == 0u) {
    g_report.first_fail_diag = r->diag;
    g_report.first_fail_test = r->test;
  }
}

static const uint8_t k_stage[BW_NUM_TESTS] = {
#define BW_X_STAGE(n, s, d) (uint8_t)(s),
  BW_TEST_LIST(BW_X_STAGE)
#undef BW_X_STAGE
};

static uint32_t nfail(void) { return g_report.count[BW_FAIL] + g_report.count[BW_TIMEOUT]; }

/* Runs one test body under a setjmp so an unexpected trap aborts only this test. Isolated in its own function: no runner
 * local is live across the setjmp, so nothing can be clobbered by the longjmp (GCC's -Wclobbered enforces this). */
static __attribute__((noinline)) bw_result_t run_guarded(bw_test_fn f) {
  bw_result_t r;
  bw_tc.armed = 0;
  bw_tc.in_test = 1;
  if (bw_setjmp(&bw_test_ctx) == 0)
    r = f();
  else
    r = BW_FAIL_R(BW_D_INT_UNEXPECTED_TRAP, bw_tc.un_cause, bw_tc.un_epc, bw_tc.un_tval);
  bw_tc.in_test = 0;
  bw_tc.armed = 0;
  return r;
}

void bw_run_tests(const bw_test_fn *fn, const uint8_t *prereq, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) {                           /* test id == table index */
    bw_result_t r;
    if (prereq[i] != BW_T_NONE && g_report.results[prereq[i]].outcome != BW_PASS) {
      r = BW_SKIP_R(BW_D_SKIP_PREREQ, prereq[i]);
    } else {
      bw_status_set(BW_ST_LIVE(k_stage[i], i, nfail()));
      BW_MGMT(ALBION_MGMT_FW_HEARTBEAT) = i + 1u;
      r = run_guarded(fn[i]);
      bw_cleanup_hw();
    }
    r.test = (uint8_t)i;
    record(&r);
  }
}

static void push_record(uint32_t type, uint32_t w1, uint32_t w2, uint32_t w3) {
  BW_MGMT(ALBION_MGMT_FCPL_W0) = (0xB007u << 16) | type;
  BW_MGMT(ALBION_MGMT_FCPL_W1) = w1;
  BW_MGMT(ALBION_MGMT_FCPL_W2) = w2;
  BW_MGMT(ALBION_MGMT_FCPL_W3) = w3;
  BW_MGMT(ALBION_MGMT_FCPL_PUSH) = 1u;
}

void bw_report_finalize(void) {
  g_report.config_id      = g_hw.config_id;
  g_report.feat_impl      = g_hw.feat_impl;
  g_report.banks_and_size = (g_hw.banks << 24) | (g_hw.bank_bytes >> 10);
  g_report.cycles         = bw_cycles();
  g_report.instret        = BW_CSR_R(minstret);
  /* stack high-water mark: first overwritten word scanning up from the guard */
  {
    uint32_t lo = BW_SYM(_stack_limit), hi = BW_SYM(_stack_top), a = lo;
    while (a < hi && *(volatile uint32_t *)a == BW_STACK_CANARY) a += 4u;
    g_report.stack_hwm = hi - a;
  }
  g_report.verdict = (nfail() == 0u && g_report.n_done == BW_NUM_TESTS) ? BW_SIG_PASS : BW_SIG_FAIL;
  g_report.state   = BW_STATE_DONE;
  g_report.crc     = bw_crc32(&g_report, (uint32_t)__builtin_offsetof(bw_report_t, crc), 0u);

  push_record(BW_REC_SUMMARY, g_report.verdict,
              (nfail() << 16) | g_report.count[BW_PASS], g_report.crc);
  BW_MGMT(ALBION_MGMT_SCRATCH) = (nfail() << 16) | (g_report.first_fail_diag & 0xFFFFu);
  BW_MGMT(ALBION_MGMT_FW_HEARTBEAT) = BW_NUM_TESTS;
  bw_status_set(g_report.verdict);           /* written last: the host polls for this value */
}

void bw_report_start_record(void) {
  push_record(BW_REC_START, BW_VERSION, (g_hw.banks << 8) | g_hw.config_id, g_hw.feat_impl);
}
