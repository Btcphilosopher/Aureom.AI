/* BootWorks trigger stubs. Each stub executes ONE instruction of interest at an exported
 * <name>_insn label so the C test can compare mepc against the exact instruction address.
 * Raw .word encodings are used for instructions the base ISA toolchain must not emit
 * (M/A/F): they are executed only to find out whether the core traps. */
    .option norelax
    .section .text, "ax", @progbits

#define STUB(name)          \
    .balign 4;              \
    .globl name;            \
    .type  name, @function; \
name:

#define INSN(name) \
    .globl name##_insn; \
name##_insn:

STUB(bw_trig_ecall)
INSN(bw_trig_ecall)
    ecall
    ret

STUB(bw_trig_ebreak)
INSN(bw_trig_ebreak)
    ebreak
    ret

STUB(bw_trig_illegal)
INSN(bw_trig_illegal)
    .word   0xFFFFFFFF                 /* architecturally reserved: illegal in every encoding space */
    ret

/* jalr x0, 0(a0): a0 has bit 1 set -> instruction-address-misaligned on cores without RVC.
 * a0 points at bw_trig_pad+2; if a core accepts a 2-byte-aligned target it lands on the zero
 * halfword (illegal on every core), never on live code. */
STUB(bw_trig_jalr)
INSN(bw_trig_jalr)
    jalr    x0, 0(a0)
    ret
    .balign 4
    .globl  bw_trig_pad
bw_trig_pad:
    ret                                /* 0x00008067 */
    .word   0

/* fetch fault: jump to the (undecoded) address in a0; the trap handler resumes at ra */
STUB(bw_trig_jump)
    mv      t1, ra
INSN(bw_trig_jump)
    jalr    ra, 0(a0)
    mv      ra, t1
    ret

STUB(bw_trig_lw)
INSN(bw_trig_lw)
    lw      a0, 0(a0)
    ret

STUB(bw_trig_sw)
INSN(bw_trig_sw)
    sw      zero, 0(a0)
    ret

STUB(bw_trig_sb)
INSN(bw_trig_sb)
    sb      zero, 0(a0)
    ret

/* RV32M: mul a0, a0, a1  (0x02B50533) */
STUB(bw_trig_mul)
INSN(bw_trig_mul)
    .word   0x02B50533
    ret

/* RV32A: amoadd.w a0, a1, (a2)  (0x00B6252F); a0 = address of a scratch word */
STUB(bw_trig_amo)
    mv      a2, a0
    li      a1, 1
INSN(bw_trig_amo)
    .word   0x00B6252F
    ret

/* RVC: two c.nop halfwords in one 4-byte aligned fetch word */
STUB(bw_trig_rvc)
INSN(bw_trig_rvc)
    .2byte  0x0001
    .2byte  0x0001
    ret

/* RV32F: fadd.s fa0, fa0, fa0  (0x00A57553) */
STUB(bw_trig_fadd)
INSN(bw_trig_fadd)
    .word   0x00A57553
    ret

/* write to a read-only CSR (mvendorid, 0xF11): must raise illegal-instruction */
STUB(bw_trig_csr_write)
INSN(bw_trig_csr_write)
    csrw    0xF11, zero
    ret

/* absent CSRs: mhpmcounter3 (0xB03) and dcsr (0x7B0) */
STUB(bw_trig_csr_hpm)
INSN(bw_trig_csr_hpm)
    csrr    a0, 0xB03
    ret

STUB(bw_trig_csr_dcsr)
INSN(bw_trig_csr_dcsr)
    csrr    a0, 0x7B0
    ret

/* Exactly 17 instructions retire between the two minstret reads: the first csrr itself
 * plus sixteen nops (a CSR read returns the count of instructions retired BEFORE it). */
STUB(bw_isa_nops17)
    csrr    a0, minstret
    nop; nop; nop; nop; nop; nop; nop; nop
    nop; nop; nop; nop; nop; nop; nop; nop
    csrr    a1, minstret
    sub     a0, a1, a0
    ret

/* Interrupt-latency spin loop: a0 = &flag, a1 = start cycle, a2 = max cycles. Returns 1 when the flag
 * became non-zero, 0 on timeout. An interrupt taken here must report mepc inside [loop, end). */
STUB(bw_irq_spin)
    .globl  bw_irq_spin_loop
bw_irq_spin_loop:
    lw      t0, 0(a0)
    bnez    t0, 1f
    csrr    t1, mcycle
    sub     t1, t1, a1
    bltu    t1, a2, bw_irq_spin_loop
    li      a0, 0
    ret
1:  li      a0, 1
    ret
    .globl  bw_irq_spin_end
bw_irq_spin_end:
