#!/usr/bin/env python3
"""BootWorks negative testing: inject real defects into a copy of the Albion RTL and require the boot to name them.

A self-test that has never failed proves nothing. For each mutant this script
  1. copies rtl/albion, applies ONE small edit (each edit's old text must occur exactly once),
  2. builds a Verilator model of the mutated SoC (CONFIG 0),
  3. boots the unmodified BootWorks image on it with the real harness,
  4. checks the run against the expectation: the named test(s) must FAIL/TIMEOUT with a specific diagnostic code,
     and/or named host-side checks (reset vector, fetch path, reference model) must fail, and/or the boot must end in
     a fatal trap / hang at a specific place.
The baseline (unmutated) design is not run here: `make run` already proves it passes.
"""
import argparse
import concurrent.futures as cf
import json
import os
import shutil
import struct
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))
from bwlib import Elf32, parse_diag_header, OUTCOMES  # noqa: E402

CC = "sf_albion_controlcore.sv"
SPEC = [
    # ---------------------------------------------------------------- CPU / ISA
    dict(name="cpu_sra_is_srl", area="CPU ISA", desc="SRA/SRAI shift right logically instead of arithmetically",
         edits=[(CC, "3'b101: alu_out = f7[5] ? 32'($signed(a) >>> b[4:0]) : (a >> b[4:0]);", "3'b101: alu_out = (a >> b[4:0]);")],
         tests={"ISA_RV32I": [0x1022]}, host=["isa"]),
    dict(name="cpu_sltu_signed", area="CPU ISA", desc="SLTU/SLTIU compare as signed",
         edits=[(CC, "3'b011: alu_out = {31'h0, a < b};", "3'b011: alu_out = {31'h0, $signed(a) < $signed(b)};")],
         tests={"ISA_RV32I": [0x1023]}, host=["isa"]),
    dict(name="cpu_bgeu_gt", area="CPU ISA", desc="BGEU implemented as 'greater than' (equal operands not taken)",
         edits=[(CC, "3'b111: br_take = x1v >= x2v;", "3'b111: br_take = x1v > x2v;")],
         tests={"ISA_RV32I": [0x1025]}, host=["isa"]),
    dict(name="cpu_misa_claims_m", area="CPU ISA", desc="misa advertises the M extension that is not implemented",
         edits=[(CC, "12'h301: csr_rdata = 32'h4000_0100;", "12'h301: csr_rdata = 32'h4000_1100;")],
         tests={"ISA_M": [0x1031]}),
    dict(name="cpu_mtvec_mode_bits", area="CPU CSR", desc="mtvec keeps its low (mode) bits: vectored mode not forced off",
         edits=[(CC, "12'h305: mtvec    <= {ex_csr_wval[31:2], 2'b00};", "12'h305: mtvec    <= ex_csr_wval;")],
         tests={"CSR_BASIC": [0x1052]}),
    dict(name="cpu_instret_double", area="CPU counters", desc="minstret counts two per retired instruction",
         edits=[(CC, "if (retire) minstret <= minstret + 64'd1;", "if (retire) minstret <= minstret + 64'd2;")],
         tests={"CSR_BASIC": [0x1059], "CNT_CYCLE": [0x9002]}),
    # ---------------------------------------------------------------- traps and interrupts
    dict(name="cpu_mpie_not_saved", area="CPU traps", desc="trap entry does not save MIE into MPIE",
         edits=[(CC, "mstatus_mpie <= mstatus_mie;", "mstatus_mpie <= 1'b1;")],
         tests={"TRAP_RETURN": [0x2022]}),
    dict(name="cpu_lw_misalign_ok", area="CPU traps", desc="misaligned LW does not raise load-address-misaligned",
         edits=[(CC, "if ((f3[1:0] == 2'b01 && ex_mem_addr[0]) || (f3[1:0] == 2'b10 && ex_mem_addr[1:0] != 2'b00))",
                 "if ((f3[1:0] == 2'b01 && ex_mem_addr[0]))")],
         tests={"TRAP_CAUSES": [0x200B]}),
    dict(name="cpu_irq_never_taken", area="Interrupts", desc="machine external interrupt is never taken (irq_take stuck 0)",
         edits=[(CC, "assign irq_take    = (state == S_FETCH) && mstatus_mie && irq_pending;", "assign irq_take    = 1'b0;")],
         tests={"IRQ_TAKEN": [0x8031]}),
    dict(name="cpu_wfi_never_wakes", area="Interrupts", desc="WFI never leaves the sleep state",
         edits=[(CC, "S_WFI:      if (irq_pending) begin pc <= pc + 32'd4; state <= S_FETCH; end", "S_WFI:      if (1'b0) begin pc <= pc + 32'd4; state <= S_FETCH; end")],
         end="hang:IRQ_WFI"),
    dict(name="soc_irq_ue_not_wired", area="Interrupts", desc="ECC_UE interrupt source tied low",
         edits=[("sf_albion_cloud_top.sv", "irq_pulse[sf_albion_regs_pkg::IRQ_ECC_UE_BIT]    = |ecc_ue;", "irq_pulse[sf_albion_regs_pkg::IRQ_ECC_UE_BIT]    = 1'b0;")],
         tests={"ECC_UE": [0x6015]}),
    # ---------------------------------------------------------------- reset and fetch path
    dict(name="cpu_wrong_reset_vector", area="Reset", desc="RESET_PC = 0x100 instead of 0x0", stall=400000,
         edits=[(CC, "parameter logic [31:0] RESET_PC = 32'h0000_0000,", "parameter logic [31:0] RESET_PC = 32'h0000_0100,")],
         host=["reset"]),
    dict(name="cpu_fetch_bit_flip", area="Fetch path", desc="one bit of the fetched instruction word is corrupted on its way into the decoder (at the entry of boot_main)", dyn="pc",
         edits=[(CC, "S_FETCH_WAIT: if (rsp_valid) begin ir <= rsp_rdata; state <= S_EXEC; end",
                 "S_FETCH_WAIT: if (rsp_valid) begin ir <= (pc == 32'h@PC@) ? (rsp_rdata ^ 32'h0000_0080) : rsp_rdata; state <= S_EXEC; end")],
         host=["fetch"], stall=1500000),
    # ---------------------------------------------------------------- SRAM
    dict(name="sram_one_cell_flips_1bit", area="SRAM", desc="one SRAM cell (word 100 of every bank) stores a codeword with 1 bit inverted: ECC corrects it, so only the RAS counter shows it",
         edits=[("sf_albion_sram_macro.sv", "if (we) mem[addr] <= wdata;", "if (we) mem[addr] <= wdata ^ ((addr == 12'd100) ? 39'h4 : 39'h0);")],
         tests={"BANK0_SWEEP": [0x5012]}),
    dict(name="sram_cell_pair_flips_2bit", area="SRAM", desc="two bits of one SRAM word hold the inverse (uncorrectable) inside boot_main's code", dyn="ue_in_code",
         edits=[("sf_albion_sram_macro.sv", "if (we) mem[addr] <= wdata;", "if (we) mem[addr] <= wdata ^ ((addr == 12'd@IDX@) ? 39'h6 : 39'h0);")],
         end="fatal", fatal_cause=1),
    dict(name="sram_bank2_addr_bit_stuck", area="SRAM", desc="word-address bit 4 of SRAM bank 2 stuck at 0",
         edits=[("sf_albion_cloud_top.sv", ".req_word(a[BANK_SHIFT-1:2]),", ".req_word((b == 2) ? {a[BANK_SHIFT-1:7], 1'b0, a[5:2]} : a[BANK_SHIFT-1:2]),")],
         tests={"MEM_ADDRBUS": [0x5041, 0x5042]}),
    dict(name="fabric_bank3_aliases_bank2", area="SRAM", desc="the DataFabric routes bank 3 accesses to bank 2",
         edits=[("sf_albion_datafabric.sv", "tgt[m*SW +: SW]    = SW'(bank);", "tgt[m*SW +: SW]    = SW'((bank == 3) ? 2 : bank);")],
         tests={"MEM_BANKSEL": [0x5051]}),
    # ---------------------------------------------------------------- DMA and protection
    dict(name="dma_drops_last_word", area="DMA", desc="DMA moves one word fewer than LEN",
         edits=[("sf_albion_dma.sv", "nwords <= {2'b00, r_len[31:2]};", "nwords <= {2'b00, r_len[31:2]} - 32'd1;")],
         tests={"DMA_FILL": [0x7012]}),
    dict(name="dma_corrupts_copy_data", area="DMA", desc="DMA copy flips data bit 4",
         edits=[("sf_albion_dma.sv", "assign wr_req_wdata = r_mode_fill ? r_fill : f_head;", "assign wr_req_wdata = r_mode_fill ? r_fill : (f_head ^ 32'h0000_0010);")],
         tests={"DMA_COPY": [0x7022]}),
    dict(name="dma_never_completes", area="DMA", desc="DMA engine stays BUSY forever",
         edits=[("sf_albion_dma.sv", "          busy  <= 1'b0;", "          busy  <= 1'b1;")],
         tests={"DMA_FILL": [0x7015]}),
    dict(name="fabric_dma_reaches_bank0", area="Protection", desc="hardware invariant broken: DMA may write the firmware bank (BootWorks aims at a sandbox)",
         edits=[("sf_albion_datafabric.sv", "data_bank = is_sram && (bank >= FWB);", "data_bank = is_sram;")],
         tests={"DMA_FWBANK": [0x7061, 0x7062]}, intact=True),
    dict(name="perm_ignores_domain", area="Protection", desc="permission windows match any domain",
         edits=[("sf_albion_datafabric.sv", "if (at[0] && (at[11:8] == dom) && (we ? at[2] : at[1]) &&", "if (at[0] && 1'b1 && (we ? at[2] : at[1]) &&")],
         tests={"DMA_PERM": [0x7075]}),
    # ---------------------------------------------------------------- registers
    dict(name="regs_wrong_chip_id", area="Registers", desc="CHIP_ID constant differs (0x53464191)",
         edits=[("sf_albion_regs_pkg.sv", "localparam logic [31:0] CHIP_ID = 32'h53464190;", "localparam logic [31:0] CHIP_ID = 32'h53464191;")],
         tests={"PLAT_ID": [0x3001]}),
    dict(name="telem_freeze_ignored", area="Registers", desc="TELEM freeze does not stop the counters",
         edits=[("sf_albion_telemetry.sv", "else if (!freeze) cnt[i*64 +: 64]", "else if (1'b1) cnt[i*64 +: 64]")],
         tests={"REG_TELEM": [0x4043]}),
    # ---------------------------------------------------------------- loader
    dict(name="image_bit_flipped_in_sram", area="Boot image", desc="one bit of the image flips in SRAM after the host's own verify (a word of code that never executes, so only the CRC can notice)", harness=["--corrupt-sandbox-word"], norebuild=True,
         tests={"IMG_CRC": [0x5002]}),
]


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def run_mutant(m, a, ctx):
    t0 = time.time()
    d = os.path.join(a.out, m["name"])
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    res = dict(name=m["name"], area=m["area"], desc=m["desc"], ok=False, evidence=[], seconds=0)
    sim_dir = os.path.join(a.root, "build", "bootworks", "sim", "cfg0")   # baseline sim for no-rebuild mutants
    binary = os.path.join(sim_dir, "bootworks_tb")
    if not m.get("norebuild"):
        rtl = os.path.join(d, "rtl")
        shutil.copytree(os.path.join(a.root, "rtl", "albion"), rtl)
        for f, old, new in m["edits"]:
            new = new.replace("@IDX@", str(ctx["ue_idx"])).replace("@PC@", "%08X" % ctx["boot_main"])
            p = os.path.join(rtl, f)
            s = open(p).read()
            if s.count(old) != 1:
                res["evidence"].append(f"edit target not unique/missing in {f} ({s.count(old)} matches)")
                return res
            open(p, "w").write(s.replace(old, new))
        flist = [l.strip() for l in open(os.path.join(a.root, "rtl", "albion", "sf_albion.f")) if l.strip()]
        fl = os.path.join(d, "files.f")
        open(fl, "w").write("\n".join(os.path.join(rtl, os.path.basename(l)) for l in flist) + "\n")
        vlt = [os.path.join(a.root, "rtl", "albion", "lint", "verilator.vlt"), os.path.join(a.bw_dir, "sim", "bootworks.vlt")]
        mdir = os.path.join(d, "sim")
        r = sh(["verilator", "--cc", "--exe", "--build", "-j", "2", "-O3", "--x-assign", "fast", "--x-initial", "unique", "-Wno-UNUSEDPARAM"] + vlt +
               ["-f", fl, os.path.join(a.bw_dir, "sim", "bootworks_tb.cpp"), "--top-module", "sf_albion_cloud_top", "-GCONFIG=0",
                "-CFLAGS", f"-I{a.bw_dir}/include -std=c++17 -O3", "-Mdir", mdir, "-o", "bootworks_tb"], cwd=d)
        if r.returncode != 0:
            res["evidence"].append("verilator build of the mutant failed: " + (r.stdout + r.stderr)[-300:])
            return res
        binary = os.path.join(mdir, "bootworks_tb")
    jpath = os.path.join(d, "run.json")
    args = [binary, f"--image={ctx['bin']}", f"--expect={ctx['expect']}", f"--json={jpath}", f"--stall-cycles={m.get('stall', a.stall)}",
            "+verilator+rand+reset+2", "+verilator+seed+7"]
    for h in m.get("harness", []):
        args.append(f"--corrupt-word={ctx['sandbox_word']}" if h == "--corrupt-sandbox-word" else h)
    r = sh(args, timeout=a.timeout)
    open(os.path.join(d, "run.log"), "w").write(r.stdout + r.stderr)
    res["seconds"] = round(time.time() - t0)
    if not os.path.exists(jpath):
        asserted = "%Error" in (r.stdout + r.stderr)
        res["evidence"].append("simulation aborted by an RTL assertion: " + next((l for l in (r.stdout + r.stderr).splitlines() if "%Error" in l), "")[:160])
        res["ok"] = asserted and m.get("assert_ok", False)
        return res
    j = json.load(open(jpath))
    chk = sh([sys.executable, os.path.join(a.bw_dir, "tools", "bw_check.py"), jpath, "--bw-dir", a.bw_dir, "--bin", ctx["bin"],
              "--summary", os.path.join(d, "check.json")])
    summ = json.load(open(os.path.join(d, "check.json")))
    results = {t["name"]: t for t in j["report"].get("results", [])}
    ok = True
    for tname, diags in m.get("tests", {}).items():
        t = results.get(tname)
        got = (OUTCOMES[t["outcome"]], t["diag"]) if t else ("?", 0)
        hit = bool(t) and t["outcome"] in (1, 2) and t["diag"] in diags
        ok &= hit
        dn = ctx["dtext"].get(got[1], ("", ""))[0]
        res["evidence"].append(f"{tname}: {got[0]} 0x{got[1]:04X} {dn} aux {[hex(x) for x in t['aux']] if t else ''}" + ("" if hit else
                               f"   <-- expected FAIL with {', '.join('0x%04X' % x for x in diags)}"))
    for hname in m.get("host", []):
        hit = summ["checks"].get(hname) is False
        ok &= hit
        res["evidence"].append(f"host check '{hname}' " + ("FAILED as it must" if hit else "did not fail"))
    end = m.get("end")
    if end == "fatal":
        st = j["run"]["fw_status"]
        hit = (st >> 16) == 0xDEAD and (st & 0xFFFF) == m.get("fatal_cause", 0) and j["run"]["scratch"] == ctx["ue_mepc"]
        ok &= hit
        res["evidence"].append(f"fatal trap: FW_STATUS=0x{st:08X} (cause {st & 0xFFFF}) SCRATCH(mepc)=0x{j['run']['scratch']:X}; the corrupted word is at 0x{ctx['ue_mepc']:X}" + ("" if hit else "   <-- not as expected"))
    elif end and end.startswith("hang:"):
        want = end.split(":")[1]
        tl = j["timeline"]
        st = tl[-1][1] if tl else 0
        stage, tid = (st >> 16) & 0xFF, (st >> 8) & 0xFF
        name = ctx["tname"][tid] if (st >> 24) == 0xB1 and tid < len(ctx["tname"]) else "?"
        hit = j["run"]["end_reason"].startswith("TIMEOUT") and name == want
        ok &= hit
        res["evidence"].append(f"host watchdog: {j['run']['end_reason']}; FW_STATUS=0x{st:08X} -> stage 0x{stage:02X}, test {name}" + ("" if hit else f"   <-- expected hang in {want}"))
    if m.get("intact"):
        hit = results.get("IMG_CRC_POST", {}).get("outcome") == 0 and j["host"]["image_changed_words"] == 0
        ok &= hit
        res["evidence"].append("firmware image intact after the invariant violation (IMG_CRC_POST PASS, 0 words changed): " + ("yes" if hit else "NO"))
    res["ok"] = ok
    res["first_fail"] = (f"0x{j['report'].get('first_fail_diag', 0):04X}" if j["report"].get("read") else "report incomplete")
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--bw-dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--report")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", help="comma list of mutant names")
    ap.add_argument("--stall", type=int, default=3000000)
    ap.add_argument("--timeout", type=int, default=900)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    bdir = os.path.join(a.root, "build", "bootworks")
    elf = Elf32(os.path.join(bdir, "bootworks.elf"))
    tests, diags, _ = parse_diag_header(os.path.join(a.bw_dir, "include", "bw_diag.h"))
    bm = elf.sym("boot_main") + 12                      # an instruction executed exactly once, early in boot
    ctx = dict(bin=os.path.join(bdir, "bootworks.bin"), expect=os.path.join(bdir, "bootworks.expect"),
               dtext={c: (n, t) for n, c, t in diags}, tname=[n for n, _, _ in tests],
               ue_idx=(bm // 4) & 0xFFF, ue_mepc=bm, boot_main=elf.sym("boot_main"), sandbox_word=(elf.sym("bw_fatal") + 4) // 4)   # a word inside bw_fatal: code that a passing boot never executes
    sel = [m for m in SPEC if not a.only or m["name"] in a.only.split(",")]
    t0 = time.time()
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = {ex.submit(run_mutant, m, a, ctx): m for m in sel}
        results = []
        for f in cf.as_completed(futs):
            r = f.result()
            results.append(r)
            print(f"[{'DETECTED' if r['ok'] else 'MISSED  '}] {r['name']:<28} {r['seconds']:>4}s  " + (r["evidence"][0] if r["evidence"] else ""), flush=True)
    results.sort(key=lambda r: [m["name"] for m in SPEC].index(r["name"]))
    nd = sum(r["ok"] for r in results)
    print(f"mutation result: {nd}/{len(results)} injected defects detected and named ({round(time.time() - t0)} s)")
    if a.report:
        L = ["# BootWorks mutation (negative-test) report", "",
             f"{nd} of {len(results)} injected RTL defects were detected and attributed to the correct test and diagnostic code.", "",
             "Each row is a real, one-line change to a copy of the Albion RTL; the unmodified BootWorks image was booted on the mutated design.",
             "", "| mutant | area | injected defect | detected | what BootWorks reported |", "|---|---|---|---|---|"]
        for r in results:
            L.append(f"| `{r['name']}` | {r['area']} | {r['desc']} | {'**yes**' if r['ok'] else 'NO'} | " + "<br>".join(r["evidence"]).replace("|", "/") + " |")
        os.makedirs(os.path.dirname(a.report), exist_ok=True)
        open(a.report, "w").write("\n".join(L) + "\n")
        json.dump(results, open(os.path.join(a.out, "mutation_results.json"), "w"), indent=1)
    sys.exit(0 if nd == len(results) else 1)


if __name__ == "__main__":
    main()
