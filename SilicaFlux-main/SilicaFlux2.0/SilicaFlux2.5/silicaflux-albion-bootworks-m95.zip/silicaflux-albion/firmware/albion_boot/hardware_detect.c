/* BootWorks - hardware identification.
 *
 * Nothing is assumed: ISA extensions are PROBED by executing an instruction of that extension and
 * seeing whether the core traps, then cross-checked against misa. Absent hardware is reported as
 * UNSUPPORTED with a reason code; present-but-undriveable hardware as SKIPPED. The Albion ControlCore
 * is documented (and measured) as RV32I + Zicsr only, M-mode only - this module is how the firmware
 * finds that out for itself.
 */
#include "bw_internal.h"

bw_hw_t g_hw;

#define ILLEGAL_INSN 2u

void bw_hw_detect(void) {
  g_hw.chip_id      = BW_MGMT(ALBION_MGMT_CHIP_ID);
  g_hw.rtl_version  = BW_MGMT(ALBION_MGMT_VERSION);
  g_hw.config_id    = BW_MGMT(ALBION_MGMT_CONFIG_ID);
  g_hw.feat_impl    = BW_MGMT(ALBION_MGMT_FEAT_IMPL);
  g_hw.feat_req     = BW_MGMT(ALBION_MGMT_FEAT_REQ);
  g_hw.feat_unavail = BW_MGMT(ALBION_MGMT_FEAT_UNAVAIL);
  g_hw.banks        = BW_MGMT(ALBION_MGMT_SRAM_BANKS);
  g_hw.bank_bytes   = BW_MGMT(ALBION_MGMT_SRAM_BANK_BYTES);
  g_hw.windows      = BW_MGMT(ALBION_MGMT_NUM_WINDOWS);
  g_hw.cmdq_depth   = BW_MGMT(ALBION_MGMT_CMDQ_DEPTH);
  g_hw.cplq_depth   = BW_MGMT(ALBION_MGMT_CPLQ_DEPTH);
  g_hw.domains      = BW_MGMT(ALBION_MGMT_NUM_DOMAINS);
  g_hw.misa         = BW_CSR_R(misa);
  g_hw.mvendorid    = BW_CSR_R(mvendorid);
  g_hw.marchid      = BW_CSR_R(marchid);
  g_hw.mimpid       = BW_CSR_R(mimpid);
  g_hw.mhartid      = BW_CSR_R(mhartid);

  /* Reset-state snapshot: taken before any test or init step changes the hardware. */
  g_hw.snap_dev_status  = BW_MGMT(ALBION_MGMT_DEV_STATUS);
  g_hw.dbg_strap        = (g_hw.snap_dev_status & ALBION_MGMT_DEV_STATUS_DBG_STRAP_MASK) ? 1u : 0u;
  g_hw.snap_irq_pending = BW_IRQ(ALBION_IRQ_PENDING);
  g_hw.snap_irq_enable  = BW_IRQ(ALBION_IRQ_ENABLE);
  g_hw.snap_mip         = BW_CSR_R(mip);
  g_hw.snap_dma_status  = BW_DMA(ALBION_DMA_STATUS);
  g_hw.snap_ras_status  = BW_RAS(ALBION_RAS_ERR_STATUS);
  g_hw.snap_ce          = BW_RAS(ALBION_RAS_CE_COUNT);
  g_hw.snap_ue          = BW_RAS(ALBION_RAS_UE_COUNT);
  g_hw.snap_scrub       = BW_RAS(ALBION_RAS_SCRUB_STATUS);
  g_hw.snap_viol_count  = BW_PERM(ALBION_PERM_VIOL_COUNT);
  g_hw.snap_viol_info   = BW_PERM(ALBION_PERM_VIOL_INFO);
  g_hw.snap_fcmdq       = BW_MGMT(ALBION_MGMT_FCMDQ_STATUS);
  g_hw.snap_fcplq       = BW_MGMT(ALBION_MGMT_FCPLQ_STATUS);
  g_hw.snap_win_valid   = 0u;
  for (uint32_t i = 0; i < g_hw.windows && i < 32u; i++)
    if (BW_PERM(ALBION_PERM_WIN_ATTR + i * ALBION_PERM_WIN_ATTR_STRIDE) & ALBION_PERM_WIN_ATTR_VALID_MASK)
      g_hw.snap_win_valid |= 1u << i;
}

/* =========================================================================== CPU identification */

bw_result_t bw_test_CPU_IDENT(void) {
  uint32_t misa = g_hw.misa;
  if ((misa >> 30) != 1u)       return BW_FAIL_R(BW_D_CPU_MISA_MXL, misa, 1u << 30, misa & 0xC0000000u);
  if (!(misa & (1u << 8)))      return BW_FAIL_R(BW_D_CPU_MISA_NO_I, misa, 1u << 8, misa & 0x3FFFFFFu);
  return BW_PASS_A(misa, g_hw.mvendorid, g_hw.mimpid);
}

/* Trap raised by a probe: must be illegal-instruction at the probe's instruction. */
static int probe_trap_ok(const void *insn) {
  return bw_tc.cause == ILLEGAL_INSN && bw_tc.epc == (uint32_t)(uintptr_t)insn;
}

bw_result_t bw_test_ISA_M(void) {
  uint32_t misa_m = (g_hw.misa >> 12) & 1u;
  bw_catch(BW_RESUME_SKIP);
  uint32_t prod = bw_trig_mul(7u, 6u);
  if (bw_caught()) {
    if (!probe_trap_ok(bw_trig_mul_insn)) return BW_FAIL_R(BW_D_ISA_PROBE_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
    if (misa_m) return BW_FAIL_R(BW_D_ISA_M_MISA_LIES, g_hw.misa, 0, 1);
    return BW_UNSUP_R(BW_D_UNSUP_ISA_M, g_hw.misa);
  }
  if (!misa_m) return BW_FAIL_R(BW_D_ISA_M_MISA_LIES, g_hw.misa, 1, 0);
  if (prod != 42u) return BW_FAIL_R(BW_D_ISA_M_WRONG, 7u * 6u, 42u, prod);
  return BW_PASS_A(g_hw.misa, 0, 0);
}

bw_result_t bw_test_ISA_A(void) {
  uint32_t misa_a = g_hw.misa & 1u;
  volatile uint32_t *w = (volatile uint32_t *)BW_SYM(_scratch_start);
  *w = 5u;
  bw_catch(BW_RESUME_SKIP);
  uint32_t old = bw_trig_amo(BW_SYM(_scratch_start));
  if (bw_caught()) {
    if (!probe_trap_ok(bw_trig_amo_insn)) return BW_FAIL_R(BW_D_ISA_PROBE_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
    if (misa_a) return BW_FAIL_R(BW_D_ISA_A_MISA_LIES, g_hw.misa, 0, 1);
    return BW_UNSUP_R(BW_D_UNSUP_ISA_A, g_hw.misa);
  }
  if (!misa_a) return BW_FAIL_R(BW_D_ISA_A_MISA_LIES, g_hw.misa, 1, 0);
  if (old != 5u || *w != 6u) return BW_FAIL_R(BW_D_ISA_A_WRONG, 5u, old, *w);
  return BW_PASS_A(g_hw.misa, 0, 0);
}

bw_result_t bw_test_ISA_C(void) {
  uint32_t misa_c = (g_hw.misa >> 2) & 1u;
  bw_catch(BW_RESUME_SKIP);
  (void)bw_trig_rvc(0u);
  if (bw_caught()) {
    if (!probe_trap_ok(bw_trig_rvc_insn)) return BW_FAIL_R(BW_D_ISA_PROBE_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
    if (misa_c) return BW_FAIL_R(BW_D_ISA_C_MISA_LIES, g_hw.misa, 0, 1);
    return BW_UNSUP_R(BW_D_UNSUP_ISA_C, g_hw.misa);
  }
  if (!misa_c) return BW_FAIL_R(BW_D_ISA_C_MISA_LIES, g_hw.misa, 1, 0);
  return BW_PASS_A(g_hw.misa, 0, 0);
}

bw_result_t bw_test_ISA_F(void) {
  uint32_t misa_f = ((g_hw.misa >> 5) & 1u) | ((g_hw.misa >> 3) & 1u);   /* F or D */
  bw_catch(BW_RESUME_SKIP);
  (void)bw_trig_fadd(0u);
  if (bw_caught()) {
    if (!probe_trap_ok(bw_trig_fadd_insn)) return BW_FAIL_R(BW_D_ISA_PROBE_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
    if (misa_f) return BW_FAIL_R(BW_D_ISA_F_MISA_LIES, g_hw.misa, 0, 1);
    return BW_UNSUP_R(BW_D_UNSUP_ISA_F, g_hw.misa);
  }
  if (!misa_f) return BW_FAIL_R(BW_D_ISA_F_MISA_LIES, g_hw.misa, 1, 0);
  return BW_PASS_A(g_hw.misa, 0, 0);
}

bw_result_t bw_test_CSR_ABSENT(void) {
  bw_catch(BW_RESUME_SKIP);
  uint32_t v = bw_trig_csr_hpm();
  if (bw_caught()) {
    if (!probe_trap_ok(bw_trig_csr_hpm_insn)) return BW_FAIL_R(BW_D_CSR_ABSENT_BAD_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
    return BW_UNSUP_R(BW_D_UNSUP_CSR_HPM, 0xB03u);
  }
  return BW_PASS_A(0xB03u, v, 0);          /* implemented: report, nothing to verify */
}

/* =========================================================================== platform identity */

bw_result_t bw_test_PLAT_ID(void) {
  if (g_hw.chip_id != ALBION_CHIP_ID)
    return BW_FAIL_R(BW_D_PLAT_CHIP_ID, 0, ALBION_CHIP_ID, g_hw.chip_id);
  if ((g_hw.rtl_version >> 16) != (ALBION_RTL_VERSION >> 16))
    return BW_FAIL_R(BW_D_PLAT_RTL_MAJOR, 0, ALBION_RTL_VERSION, g_hw.rtl_version);
  return BW_PASS_A(g_hw.chip_id, g_hw.rtl_version, g_hw.config_id);
}

static const struct { uint32_t banks, bytes, win, q; } k_cfg[3] = {
  { 4u, 16384u, 8u, 4u }, { 8u, 16384u, 16u, 8u }, { 8u, 32768u, 16u, 16u }
};

bw_result_t bw_test_PLAT_CONFIG(void) {
  uint32_t c = g_hw.config_id;
  if (c > 2u) return BW_FAIL_R(BW_D_PLAT_CFG_ID, c, 2u, c);
  if (g_hw.banks != k_cfg[c].banks || g_hw.bank_bytes != k_cfg[c].bytes ||
      g_hw.windows != k_cfg[c].win || g_hw.cmdq_depth != k_cfg[c].q || g_hw.cplq_depth != k_cfg[c].q ||
      g_hw.domains != ALBION_NUM_DOMAINS)
    return BW_FAIL_R(BW_D_PLAT_CFG_MISMATCH, (g_hw.banks << 16) | g_hw.windows,
                     (k_cfg[c].banks << 16) | k_cfg[c].win, g_hw.bank_bytes);
  if ((g_hw.bank_bytes & (g_hw.bank_bytes - 1u)) != 0u || g_hw.bank_bytes < 16384u || bw_ndata() < 1u)
    return BW_FAIL_R(BW_D_PLAT_GEOMETRY, g_hw.banks, 16384u, g_hw.bank_bytes);
  return BW_PASS_A(g_hw.banks, g_hw.bank_bytes, g_hw.windows);
}

bw_result_t bw_test_PLAT_FEATURES(void) {
  uint32_t need = ALBION_FEAT_CONTROLCORE | ALBION_FEAT_DATAFABRIC;
  if ((g_hw.feat_impl & need) != need) return BW_FAIL_R(BW_D_PLAT_FEAT_CORE, g_hw.feat_impl, need, g_hw.feat_impl & need);
  if (g_hw.feat_unavail != (g_hw.feat_req & ~g_hw.feat_impl))
    return BW_FAIL_R(BW_D_PLAT_FEAT_UNAVAIL, g_hw.feat_unavail, g_hw.feat_req & ~g_hw.feat_impl, g_hw.feat_req);
  if (g_hw.feat_impl & ~g_hw.feat_req) return BW_FAIL_R(BW_D_PLAT_FEAT_SUBSET, g_hw.feat_impl, g_hw.feat_req, g_hw.feat_impl & ~g_hw.feat_req);
  return BW_PASS_A(g_hw.feat_impl, g_hw.feat_req, g_hw.feat_unavail);
}

/* =========================================================================== absent / host-dependent hardware */

/* No boot ROM exists in the Albion address map. Evidence gathered at run time: this code runs from
 * SRAM bank 0 and bank 0 holds writable RAM (scratch window round-trip). */
bw_result_t bw_test_BOOT_ROM(void) {
  uint32_t pc;
  __asm__ volatile("auipc %0, 0" : "=r"(pc));
  if (pc >= bw_fw_banks() * g_hw.bank_bytes) return BW_FAIL_R(BW_D_PLAT_BOOTMEM_PC, pc, bw_fw_banks() * g_hw.bank_bytes, pc);
  volatile uint32_t *w = (volatile uint32_t *)BW_SYM(_scratch_start);
  *w = 0xA5C3E1F0u;
  uint32_t v = *w;
  if (v != 0xA5C3E1F0u) return BW_FAIL_R(BW_D_PLAT_BOOTMEM_RW, BW_SYM(_scratch_start), 0xA5C3E1F0u, v);
  return BW_UNSUP_R(BW_D_UNSUP_BOOT_ROM, pc);
}

/* No UART in the Albion regmap. The first unpopulated MMIO page must answer DECERR (load access fault). */
bw_result_t bw_test_UART(void) {
  bw_catch(BW_RESUME_SKIP);
  uint32_t v = bw_trig_lw(BW_MMIO_UNMAPPED_PAGE);
  if (!bw_caught()) return BW_FAIL_R(BW_D_PLAT_UART_PROBE, BW_MMIO_UNMAPPED_PAGE, 0, v);
  if (bw_tc.cause != 5u) return BW_FAIL_R(BW_D_PLAT_UART_PROBE, bw_tc.cause, 5u, bw_tc.tval);
  return BW_UNSUP_R(BW_D_UNSUP_UART, BW_MMIO_UNMAPPED_PAGE);
}

bw_result_t bw_test_DEBUG(void) {
  bw_catch(BW_RESUME_SKIP);
  (void)bw_trig_csr_dcsr();
  if (bw_caught()) {
    if (!probe_trap_ok(bw_trig_csr_dcsr_insn)) return BW_FAIL_R(BW_D_CSR_ABSENT_BAD_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
    bw_result_t r = BW_UNSUP_R(BW_D_UNSUP_DEBUG, 0x7B0u);
    r.aux1 = g_hw.dbg_strap;                 /* debug strap pin state (enables RAW_DMA only) */
    return r;
  }
  return BW_SKIP_R(BW_D_SKIP_NO_DRIVER, 0x7B0u);
}

bw_result_t bw_test_VECTOR(void) {
  /* The Albion feature set (FEAT_* in regmap.json) defines no vector unit; nothing to detect or drive. */
  bw_result_t r = BW_UNSUP_R(BW_D_UNSUP_VECTOR, g_hw.feat_impl);
  r.aux1 = g_hw.feat_req;
  return r;
}

bw_result_t bw_test_TENSOR(void) {
  if (g_hw.feat_impl & ALBION_FEAT_COMPUTEWORKS) return BW_SKIP_R(BW_D_SKIP_NO_DRIVER, g_hw.feat_impl);
  bw_result_t r = BW_UNSUP_R(BW_D_UNSUP_TENSOR, g_hw.feat_impl);
  r.aux1 = g_hw.feat_req & ALBION_FEAT_COMPUTEWORKS;   /* requested-but-unavailable shows up here (ALBION_HPC) */
  return r;
}

bw_result_t bw_test_ACCEL_OTHER(void) {
  uint32_t m = ALBION_FEAT_PACKETFORGE | ALBION_FEAT_VIRTUALFOUNDRY;
  if (g_hw.feat_impl & m) return BW_SKIP_R(BW_D_SKIP_NO_DRIVER, g_hw.feat_impl & m);
  bw_result_t r = BW_UNSUP_R(BW_D_UNSUP_ACCEL_OTHER, g_hw.feat_impl);
  r.aux1 = g_hw.feat_req & m;
  return r;
}

/* The core can reach host memory (0x80000000.., "debug" path) but whether that address is mapped by the
 * host IOMMU is a host decision, not a hardware property; BootWorks does not touch it. */
bw_result_t bw_test_HOSTMEM(void) {
  return BW_SKIP_R(BW_D_SKIP_HOST_DEPENDENT, ALBION_HOSTMEM_BASE);
}

/* =========================================================================== mailbox */

static int q_ok(uint32_t st, uint32_t depth) {
  uint32_t count = st & 0xFFu, full = (st >> 8) & 1u, empty = (st >> 9) & 1u;
  return count <= depth && empty == (uint32_t)(count == 0u) && full == (uint32_t)(count == depth);
}

bw_result_t bw_test_MAILBOX(void) {
  if (!q_ok(g_hw.snap_fcmdq, g_hw.cmdq_depth)) return BW_FAIL_R(BW_D_PLAT_MBX_FCMDQ, g_hw.snap_fcmdq, g_hw.cmdq_depth, 0);
  if (!q_ok(g_hw.snap_fcplq, g_hw.cplq_depth)) return BW_FAIL_R(BW_D_PLAT_MBX_FCPLQ, g_hw.snap_fcplq, g_hw.cplq_depth, 0);
  uint32_t before = BW_MGMT(ALBION_MGMT_FCPLQ_STATUS) & 0xFFu;
  bw_report_start_record();                  /* BOOT_START record, host-visible via HCPL_* */
  uint32_t after = BW_MGMT(ALBION_MGMT_FCPLQ_STATUS) & 0xFFu;
  if (before >= g_hw.cplq_depth) return BW_SKIP_R(BW_D_SKIP_HOST_DEPENDENT, before);   /* host has not drained it */
  if (after != before + 1u) return BW_FAIL_R(BW_D_PLAT_MBX_PUSH, before, before + 1u, after);
  return BW_PASS_A(before, after, 0);
}
