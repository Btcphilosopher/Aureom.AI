# SilicaFlux BootWorks - Module 95: RISC-V boot and self-test firmware

*Aureom.AI / SilicaFlux Albion.* A real, minimal firmware boot environment for the Albion **ControlCore** (RV32I + Zicsr, machine mode),
booted from the real reset vector on the real RTL, running 60 hardware self-tests and reporting through the hardware's own host-visible
channels. Delivered as an archive; **nothing was committed**.

**Status: BootWorks boots and passes on the unmodified Albion RTL in simulation for all three configurations (ALBION_MIN, CLOUD, HPC),
with an independent instruction-level cross-check, a negative-test campaign, a second-toolchain build and a verified FPGA host
sequence.** No board, no silicon and no gate-level run exists: see `docs/05_LIMITATIONS.md`.

## The demonstrable boot (ALBION_MIN, seed 1)

```
[host] CHIP_ID=0x53464190 CONFIG=0 SRAM=4 x 16 KiB, image 28556 bytes
[host] scrub-on-reset complete after ~4100 cycles, DEV_STATUS=0x00000011 (BOOT_MODE=1 CORE_RUN=0)
[host] image written and read back through the host port: 7139 words, 0 write errors, 0 mismatches
[host] CORE_CTRL.RUN = 1: ControlCore leaves reset at PC 0x00000000
[host] run ended: completion signature after 8.67 M cycles, FW_STATUS=0xB007600D          <- BOOT PASS
tests 60/60  PASS 47  FAIL 0  TIMEOUT 0  SKIPPED 1  UNSUPPORTED 12
[host] fetch-path: 2,568,715 instruction fetches, 0 image mismatches | reference model: 2,568,678 instructions checked, 0 mismatches
```

Full logs: `reports/bootworks/boot_log_cfg*_seed1.txt` (console-style), `boot_report_cfg*_seed1.md` (every test, code and auxiliary word,
and a per-test cycle timeline), `run_cfg*_seed1.log`.

## Results

Every row below is one boot of the final image on the unmodified RTL with random power-on state (seed in the name); the GCC row is the same sources built by GNU (it owns 3 banks, leaving one data bank); the replay row boots via the generated FPGA host sequence. All eight host-side checks passed in every run (`reports/bootworks/check_*.json`).

| run | SRAM | verdict | run cycles | instr. fetched / retired | reference-model mismatches | fetch-vs-image mismatches | PASS / UNSUPPORTED / SKIPPED / FAIL+TIMEOUT | instruction coverage |
|---|---|---|---|---|---|---|---|---|
| `cfg0_seed1` (clang) | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg0_seed2` | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg0_seed3` | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg1_seed1` | 8 x 16 KiB | **PASS** (`0xB007600D`) | 15,578,991 | 4,648,436 / 4,648,399 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg2_seed1` | 8 x 32 KiB | **PASS** (`0xB007600D`) | 29,626,485 | 8,885,174 / 8,885,137 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `gnu_cfg0` (**GCC build**) | 4 x 16 KiB | **PASS** (`0xB007600D`) | 7,456,792 | 2,183,419 / 2,183,382 | 0 | 0 | 47 / 12 / 1 / 0 | 75.3 % |
| `seq_cfg0` (host-sequence replay) | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |


Negative testing (inject one-line RTL defects, boot the unmodified image, require the right diagnostic): **25 of 25 injected RTL defects were detected and attributed to the correct test and diagnostic code.**
See `reports/bootworks/mutation_report.md`.

## Quick start

Needs: `clang`, `lld`, `llvm-objcopy/objdump` (18), `verilator` (5.020), `python3`, `make`; optional `riscv64-unknown-elf-gcc` for the cross-check.

```bash
make albion-bootworks            # build: ELF, .bin, .hex, .dis, .map, toolchain manifest (+ diagnostic gate, ISA gate)
make albion-bootworks-run        # boot on the RTL for CONFIG 0/1/2, check, write reports/bootworks/   (HPC takes several minutes)
make albion-bootworks-mutants    # negative tests (~15-25 min)
make albion-bootworks-gnu        # same sources, GCC toolchain, booted on the RTL
make albion-bootworks-seq        # replay the generated FPGA host sequence against the RTL
make -C firmware/albion_boot repro   # bit-for-bit reproducible build check
```
`CONFIGS="0"` and `SEEDS="1 2 3"` limit or extend `run`. Artifacts: `build/bootworks/` (copies in `reports/bootworks/`).

## Layout (`firmware/albion_boot/`)

| path | what |
|---|---|
| `startup.S` | reset entry at 0x0, early trap, full trap entry, `setjmp/longjmp`; `.data` copy, `.bss` clear, stack canary |
| `linker.ld` | 32 KiB firmware layout derived from one symbol; DMA sandbox, image trailer, scratch window, stack; every boundary `ASSERT`ed |
| `boot.c` | reset sequence, peripheral init, the 60-entry test table with prerequisites |
| `hardware_detect.c` | identification and **probing** (ISA extensions cross-checked against `misa`, ids, geometry, features, absent hardware) + reset-state snapshot |
| `memory_test.c` | image CRC, bank sweep, stack, data/address-line, bank-select, March C-, patterns, byte/halfword, **ECC injection** |
| `dma_test.c` | memory-to-memory transfers, sizes, bad parameters, first-failing-beat, hardware invariants, tenant windows (table-driven) |
| `boot_status.c` | outcomes, unique diagnostic codes, the CRC-protected report, mailbox records, `FW_STATUS` signatures |
| `cpu_test.c` `reg_test.c` `irq_test.c` `trap.c` `probes.S` `libc.c` | CPU/CSR/trap/counter tests, register tests, interrupt tests, trap dispatcher, trigger stubs, freestanding libc |
| `include/` | `bw_diag.h` (test list + **all diagnostic codes**), `bw_status.h` (report layout shared with the harness), platform/internal headers |
| `tools/` | `bw_diag_tool` (uniqueness/reference gate, docs), `bw_patch_image` (CRC trailer into the ELF), `bw_isa_check` (toolchain-defect gate), `bw_manifest`, `bw_expect`, `bw_check` (run validation + reports), `bw_load_sequence` (FPGA), `bw_summary` |
| `sim/` | `bootworks_tb.cpp` Verilator host harness: loads through the host port, fetch-path monitor, RV32I reference model, coverage |
| `tests/bw_mutants.py` | RTL mutation (negative test) campaign |
| `docs/` | `00` architecture audit - `01` boot sequence and reporting - `02` self-tests - `03` verification - `04` FPGA - `05` limitations - `DIAGNOSTIC_CODES.md` |

## Brief -> where it is met

| § | requirement | where |
|---|---|---|
| 1 | architecture audit: ISA, reset vector, width, memory map, boot ROM, SRAM, traps, timer/interrupts, debug/UART; no compliance assumed | `docs/00_ARCHITECTURE_AUDIT.md`; probed at run time by `hardware_detect.c` |
| 2 | `startup.S linker.ld boot.c memory_test.c dma_test.c hardware_detect.c boot_status.c` | this directory |
| 3 | reset sequence: real reset vector, stack, `.data`/`.bss`, trap handling, identify hardware, init peripherals, report progress | `startup.S`, `boot.c`; `docs/01_BOOT_SEQUENCE.md` |
| 4 | self-test: SRAM integrity, address lines, byte writes, DMA mem-to-mem, registers, interrupts, vector/tensor where implemented; never corrupt firmware/stack | `docs/02_SELF_TESTS.md` (vector/tensor are **not implemented in the RTL**: reported `UNSUPPORTED`) |
| 5 | outcomes PASS / FAIL / TIMEOUT / SKIPPED / UNSUPPORTED, unique code per failure | `include/bw_status.h`, `docs/DIAGNOSTIC_CODES.md` (223+ codes, uniqueness enforced at build) |
| 6 | compile real RISC-V; ELF, disassembly, memory image, linker map, toolchain manifest; load into the RTL boot memory; genuine fetch path; expected instructions execute; valid completion signature | `make albion-bootworks[-run]`; `build/bootworks/bootworks.{elf,dis,bin,hex,map,manifest.json}`; `docs/03_VERIFICATION.md` |
| 7 | FPGA support without inventing hardware | `docs/04_FPGA_BRINGUP.md`, `tools/bw_load_sequence.py`, `bootworks_load.seq` |
| - | "if boot fails, identify the precise CPU/ISA/memory/toolchain defect" | `docs/03_VERIFICATION.md` §6; the mutation campaign |

## Key decisions (and why)

1. **Target = Albion ControlCore**, not the Project 21 ControlCore: the directory name, module numbering (P90 -> M94 -> M95) and address
   map are Albion's. The audit lists the alternatives.
2. **No UART exists**, so reporting uses `FW_STATUS`/`SCRATCH`/`FW_HEARTBEAT`, the mailbox completion queue and a CRC-protected report
   in SRAM that the host reads after halting the core. BootWorks never sets `BOOT_LOCK` (it is bring-up firmware).
3. **The firmware owns two 16 KiB banks** (60 tests are ~28 KB of RV32I). Code cannot be tested destructively in place, so those banks get
   CRC/sweep/canary/scratch-window coverage and every other bank gets the full destructive suite. This is stated, not hidden.
4. **SECDED masks single-bit faults**, so memory tests also require the corrected-error counter not to move.
5. **Mutation testing found a hole in my own tests** (no equal-operand ISA vector) - fixed and re-run.

## Not done / not claimed

No FPGA board, silicon or gate-level run; no host bridge (none exists in the repository); no RISC-V compliance claim; vector and tensor
units do not exist in this RTL. Details: `docs/05_LIMITATIONS.md`.
