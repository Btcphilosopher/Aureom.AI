/* BootWorks - register-access tests (table-driven).
 *
 * "Does a register behave as its row in the regmap says?" Read-only registers must fault on write
 * (the MMIO slave answers SLVERR, which the core takes as a store access fault), writer-restricted
 * registers must refuse the wrong master, read/write registers must hold what was written and mask
 * unused bits, unmapped addresses must fault. Stores to read-only registers write ZERO via a trigger
 * stub, so even a defective (accepting) register only loses a counter value, never live state.
 */
#include "bw_internal.h"

#define STORE_FAULT 7u
#define LOAD_FAULT  5u

enum { K_RW, K_RO, K_EQ, K_LF, K_SF };       /* read/write pattern, store faults, equals, load faults, store faults (any) */

typedef struct { uint32_t addr; uint32_t arg; uint16_t diag; uint8_t kind; } regcase_t;

/* true when fn(arg) raised exactly the expected exception cause */
static int faults(uint32_t (*fn)(uint32_t), uint32_t arg, uint32_t cause) {
  bw_catch(BW_RESUME_SKIP);
  (void)fn(arg);
  return bw_caught() && bw_tc.cause == cause;
}

static bw_result_t run_cases(const regcase_t *c, uint32_t n) {
  static const uint32_t pat[] = { 0xA5A5A5A4u, 0x5A5A5A58u, 0xFFFFFFFFu, 0u };
  for (uint32_t i = 0; i < n; i++, c++) {
    switch (c->kind) {
      case K_RW:                                   /* arg = bit mask that is implemented */
        for (uint32_t j = 0; j < sizeof(pat) / sizeof(pat[0]); j++) {
          BW_REG(c->addr) = pat[j];
          uint32_t v = BW_REG(c->addr);
          if (v != (pat[j] & c->arg)) return BW_FAIL_R(c->diag, c->addr, pat[j] & c->arg, v);
        }
        BW_REG(c->addr) = 0u;
        break;
      case K_EQ: {                                 /* arg = expected value */
        uint32_t v = BW_REG(c->addr);
        if (v != c->arg) return BW_FAIL_R(c->diag, c->addr, c->arg, v);
        break;
      }
      case K_LF:
        if (!faults(bw_trig_lw, c->addr, LOAD_FAULT)) return BW_FAIL_R(c->diag, c->addr, LOAD_FAULT, bw_tc.hit ? bw_tc.cause : 0xFFFFFFFFu);
        break;
      default:                                     /* K_RO, K_SF: a store must fault */
        if (!faults(bw_trig_sw, c->addr, STORE_FAULT)) return BW_FAIL_R(c->diag, c->addr, STORE_FAULT, bw_tc.hit ? bw_tc.cause : 0xFFFFFFFFu);
        break;
    }
  }
  return BW_PASS_R();
}
#define RUN(tbl) run_cases(tbl, sizeof(tbl) / sizeof(tbl[0]))
#define MG(o) (ALBION_MGMT_BASE + (o))

/* =========================================================================== MGMT */

bw_result_t bw_test_REG_MGMT(void) {
  static const regcase_t c[] = {
    { MG(ALBION_MGMT_CHIP_ID),   0, BW_D_REG_CHIPID_WRITE, K_RO },
    { MG(ALBION_MGMT_CHIP_ID),   ALBION_CHIP_ID, BW_D_REG_RO_CHANGED, K_EQ },
    { MG(ALBION_MGMT_SCRATCH),   0xFFFFFFFFu, BW_D_REG_SCRATCH, K_RW },
    { MG(ALBION_MGMT_FW_VERSION), BW_VERSION, BW_D_REG_FWVER, K_EQ },
    { MG(ALBION_MGMT_HCMD_W0),   0, BW_D_REG_HOSTONLY, K_RO },    /* the writer column: the core may not write host-only registers */
  };
  return RUN(c);
}

/* =========================================================================== IRQ */

bw_result_t bw_test_REG_IRQ(void) {
  static const regcase_t c[] = {
    { ALBION_IRQ_BASE + ALBION_IRQ_ENABLE,  BW_IRQ_ALL, BW_D_REG_IRQ_ENABLE, K_RW },   /* 6 sources: unused bits read 0 */
    { ALBION_IRQ_BASE + ALBION_IRQ_PENDING, 0, BW_D_REG_IRQ_RO, K_RO },
    { ALBION_IRQ_BASE + ALBION_IRQ_RAW,     0, BW_D_REG_IRQ_RO, K_RO },
  };
  return RUN(c);
}

/* =========================================================================== DMA */

bw_result_t bw_test_REG_DMA(void) {
  uint32_t st = g_hw.snap_dma_status;
  if (st & (ALBION_DMA_STATUS_BUSY_MASK | ALBION_DMA_STATUS_DONE_MASK | ALBION_DMA_STATUS_ERROR_MASK | ALBION_DMA_STATUS_ERR_CODE_MASK))
    return BW_FAIL_R(BW_D_REG_DMA_RESET, 0, 0, st);
  static const regcase_t c[] = {
    { ALBION_DMA_BASE + ALBION_DMA_SRC,          0xFFFFFFFFu, BW_D_REG_DMA_RW, K_RW },
    { ALBION_DMA_BASE + ALBION_DMA_DST,          0xFFFFFFFFu, BW_D_REG_DMA_RW, K_RW },
    { ALBION_DMA_BASE + ALBION_DMA_LEN,          0xFFFFFFFFu, BW_D_REG_DMA_RW, K_RW },
    { ALBION_DMA_BASE + ALBION_DMA_FILL_PATTERN, 0xFFFFFFFFu, BW_D_REG_DMA_RW, K_RW },
    { ALBION_DMA_BASE + ALBION_DMA_DOMAIN,       0xFu,        BW_D_REG_DMA_RW, K_RW },
    { ALBION_DMA_BASE + ALBION_DMA_STATUS,       0, BW_D_REG_DMA_RO, K_RO },
  };
  return RUN(c);
}

/* =========================================================================== PERM */

bw_result_t bw_test_REG_PERM(void) {
  uint32_t v, nw = g_hw.windows;
  v = BW_PERM(ALBION_PERM_NUM_WIN);
  if (v != nw) return BW_FAIL_R(BW_D_REG_PERM_NUMWIN, 0, nw, v);
  if (g_hw.snap_win_valid) return BW_FAIL_R(BW_D_REG_PERM_RESET, 0, 0, g_hw.snap_win_valid);
  if (g_hw.snap_viol_count || (g_hw.snap_viol_info & 0x80000000u))
    return BW_FAIL_R(BW_D_REG_PERM_VIOL_RO, g_hw.snap_viol_count, 0, g_hw.snap_viol_info);
  for (uint32_t i = 0; i < nw; i++) {
    uint32_t o = ALBION_PERM_WIN_BASE + i * ALBION_PERM_WIN_BASE_STRIDE;
    uint32_t pb = 0xA5A5A5A4u ^ (i << 8), pl = 0x5A5A5A5Bu ^ (i << 16);
    BW_PERM(o + 0u) = pb;
    BW_PERM(o + 4u) = pl;
    BW_PERM(o + 8u) = 0xFFFFFFFEu;                       /* VALID stays 0; reserved bits must read 0 */
    v = BW_PERM(o + 0u); if (v != pb) return BW_FAIL_R(BW_D_REG_PERM_RW, o, pb, v);
    v = BW_PERM(o + 4u); if (v != pl) return BW_FAIL_R(BW_D_REG_PERM_RW, o + 4u, pl, v);
    v = BW_PERM(o + 8u); if (v != 0xF06u) return BW_FAIL_R(BW_D_REG_PERM_ATTR, o + 8u, 0xF06u, v);
    BW_PERM(o + 8u) = 0u; BW_PERM(o + 0u) = 0u; BW_PERM(o + 4u) = 0u;
  }
  static const regcase_t c[] = { { ALBION_PERM_BASE + ALBION_PERM_VIOL_COUNT, 0, BW_D_REG_PERM_VIOL_RO, K_RO } };
  return RUN(c);
}

/* =========================================================================== TELEM */

#define TCNT(i) BW_TELEM(ALBION_TELEM_CNT_LO + (i) * ALBION_TELEM_CNT_LO_STRIDE)

bw_result_t bw_test_REG_TELEM(void) {
  static const regcase_t c[] = {
    { ALBION_TELEM_BASE + ALBION_TELEM_NUM_COUNTERS, ALBION_NUM_TCOUNTERS, BW_D_REG_TELEM_NUM, K_EQ },
    { ALBION_TELEM_BASE + ALBION_TELEM_CNT_LO,       0, BW_D_REG_TELEM_RO, K_RO },
  };
  bw_result_t r = RUN(c);
  if (r.outcome != BW_PASS) return r;
  uint32_t c0 = TCNT(ALBION_TC_CYCLES), i0 = TCNT(ALBION_TC_CORE_INSTRET);
  for (volatile uint32_t k = 0; k < 50u; k++) { }
  uint32_t c1 = TCNT(ALBION_TC_CYCLES), i1 = TCNT(ALBION_TC_CORE_INSTRET);
  if (c1 <= c0) return BW_FAIL_R(BW_D_REG_TELEM_COUNT, ALBION_TC_CYCLES, c0, c1);
  if (i1 <= i0) return BW_FAIL_R(BW_D_REG_TELEM_COUNT, ALBION_TC_CORE_INSTRET, i0, i1);
  BW_TELEM(ALBION_TELEM_CTRL) = 1u;                      /* FREEZE */
  uint32_t f0 = TCNT(ALBION_TC_CYCLES);
  for (volatile uint32_t k = 0; k < 50u; k++) { }
  uint32_t f1 = TCNT(ALBION_TC_CYCLES);
  BW_TELEM(ALBION_TELEM_CTRL) = 0u;
  if (f1 != f0) return BW_FAIL_R(BW_D_REG_TELEM_FREEZE, 0, f0, f1);
  uint32_t u0 = TCNT(ALBION_TC_CYCLES);
  for (volatile uint32_t k = 0; k < 20u; k++) { }
  uint32_t u1 = TCNT(ALBION_TC_CYCLES);
  if (u1 <= u0) return BW_FAIL_R(BW_D_REG_TELEM_FREEZE, 1, u0, u1);
  return BW_PASS_R();
}

/* =========================================================================== RAS */

bw_result_t bw_test_REG_RAS(void) {
  if (g_hw.snap_scrub != 1u) return BW_FAIL_R(BW_D_REG_RAS_SCRUB, 0, 1u, g_hw.snap_scrub);
  if ((g_hw.snap_ras_status & 1u) || g_hw.snap_ce || g_hw.snap_ue)
    return BW_FAIL_R(BW_D_REG_RAS_DIRTY, g_hw.snap_ras_status, g_hw.snap_ce, g_hw.snap_ue);
  static const regcase_t c[] = {
    { ALBION_RAS_BASE + ALBION_RAS_INJ_ADDR,    0xFFFFFFFFu, BW_D_REG_RAS_INJ_RW, K_RW },
    { ALBION_RAS_BASE + ALBION_RAS_INJ_MASK_LO, 0xFFFFFFFFu, BW_D_REG_RAS_INJ_RW, K_RW },
    { ALBION_RAS_BASE + ALBION_RAS_INJ_MASK_HI, 0x7Fu,       BW_D_REG_RAS_INJ_RW, K_RW },   /* 39-bit codeword: 7 high mask bits */
    { ALBION_RAS_BASE + ALBION_RAS_CE_COUNT,    0, BW_D_REG_RAS_RO, K_RO },
  };
  bw_result_t r = RUN(c);
  if (r.outcome != BW_PASS) return r;
  BW_RAS(ALBION_RAS_INJ_CTRL) = 3u << 4;                 /* bank 3, NOT armed (bit 0 = 0) */
  uint32_t v = BW_RAS(ALBION_RAS_INJ_CTRL);
  BW_RAS(ALBION_RAS_INJ_CTRL) = 0u;
  if (v != 0x30u) return BW_FAIL_R(BW_D_REG_RAS_INJ_RW, ALBION_RAS_INJ_CTRL, 0x30u, v);
  return BW_PASS_R();
}

/* =========================================================================== decode / fault behaviour */

bw_result_t bw_test_REG_FAULTS(void) {
  static const regcase_t c[] = {
    { BW_MMIO_UNMAPPED_PAGE,      0, BW_D_REG_FAULT_PAGE_R,   K_LF },
    { BW_MMIO_UNMAPPED_PAGE,      0, BW_D_REG_FAULT_PAGE_W,   K_SF },
    { ALBION_MGMT_BASE + 0xFFCu,  0, BW_D_REG_FAULT_OFFSET,   K_LF },
    { BW_UNDECODED_ADDR,          0, BW_D_REG_FAULT_UNDEC_R,  K_LF },
    { BW_UNDECODED_ADDR,          0, BW_D_REG_FAULT_UNDEC_W,  K_SF },
  };
  bw_result_t r = RUN(c);
  if (r.outcome != BW_PASS) return r;

  /* MMIO registers are word-wide: a byte store (partial strobe) is rejected and changes nothing */
  BW_MGMT(ALBION_MGMT_SCRATCH) = 0x11223344u;
  int f = faults(bw_trig_sb, ALBION_MGMT_BASE + ALBION_MGMT_SCRATCH, STORE_FAULT);
  uint32_t v = BW_MGMT(ALBION_MGMT_SCRATCH);
  BW_MGMT(ALBION_MGMT_SCRATCH) = 0u;
  if (!f || v != 0x11223344u) return BW_FAIL_R(BW_D_REG_FAULT_PARTIAL, f, 0x11223344u, v);

  /* decoding is exact: the first address past the last bank must not alias into SRAM */
  uint32_t end = g_hw.banks * g_hw.bank_bytes;
  if (!faults(bw_trig_lw, end, LOAD_FAULT)) return BW_FAIL_R(BW_D_REG_FAULT_SRAM_END, end, LOAD_FAULT, bw_tc.hit ? bw_tc.cause : 0xFFFFFFFFu);
  return BW_PASS_R();
}
