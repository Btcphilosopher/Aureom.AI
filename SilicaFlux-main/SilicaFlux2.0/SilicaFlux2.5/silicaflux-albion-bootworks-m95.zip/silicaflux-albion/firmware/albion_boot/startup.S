/* BootWorks reset entry - SilicaFlux Albion ControlCore (RV32I + Zicsr, machine mode).
 *
 * The core leaves reset at PC 0x00000000 (sf_albion_controlcore RESET_PC) after the host
 * writes MGMT.CORE_CTRL.RUN. There is no boot ROM: the host has loaded this image into
 * SRAM bank 0 while the core was held in reset (DEV_STATUS.BOOT_MODE = 1).
 *
 * Sequence (nothing before step 3 touches memory other than the single MMIO store):
 *   1. MGMT.FW_STATUS = BW_ST_ENTRY        first observable proof that fetch + store work
 *   2. capture reset-state CSRs in s2..s9  (stored once RAM is initialised)
 *   3. install the early trap vector       (reports and parks; no stack needed)
 *   4. stack pointer, .data copy, .bss clear, stack canary paint
 *   5. save the entry state, install the full trap vector, call boot_main
 */
    .option norelax
    .equ MGMT_BASE,      0x40000000
    .equ MGMT_FW_STATUS, 0x050
    .equ MGMT_SCRATCH,   0x05C
    .equ MGMT_FW_ATTN,   0x068
    .equ ST_ENTRY,       0xB1000001      /* BW_ST_ENTRY    (checked by _Static_assert in boot.c) */
    .equ ST_CRT_DONE,    0xB1000002      /* BW_ST_CRT_DONE */
    .equ CANARY,         0xC0DEC0DE      /* BW_STACK_CANARY */

    .section .text.start, "ax", @progbits
    .globl  _start
    .type   _start, @function
_start:
    li      t6, MGMT_BASE
    li      t5, ST_ENTRY
    sw      t5, MGMT_FW_STATUS(t6)

    csrr    s2, mstatus
    csrr    s3, mie
    csrr    s4, mtvec
    csrr    s5, mepc
    csrr    s6, mcause
    csrr    s7, mcycle
    csrr    s8, minstret
    csrr    s9, mhartid

    la      t0, bw_early_trap
    csrw    mtvec, t0
    la      sp, _stack_top

    /* .data: copy the initial values that the image carries (LMA) to their run address */
    la      t0, _data_lma
    la      t1, _data_start
    la      t2, _data_end
1:  bgeu    t1, t2, 2f
    lw      t3, 0(t0)
    sw      t3, 0(t1)
    addi    t0, t0, 4
    addi    t1, t1, 4
    j       1b
2:
    /* .bss (includes the report block) */
    la      t0, _bss_start
    la      t1, _bss_end
3:  bgeu    t0, t1, 4f
    sw      zero, 0(t0)
    addi    t0, t0, 4
    j       3b
4:
    /* stack canary: paint the whole stack area; the guard/high-water logic scans it later */
    la      t0, _stack_limit
    la      t1, _stack_top
    li      t2, CANARY
5:  bgeu    t0, t1, 6f
    sw      t2, 0(t0)
    addi    t0, t0, 4
    j       5b
6:
    la      t0, g_entry
    sw      s2,  0(t0)
    sw      s3,  4(t0)
    sw      s4,  8(t0)
    sw      s5, 12(t0)
    sw      s6, 16(t0)
    sw      s7, 20(t0)
    sw      s8, 24(t0)
    sw      s9, 28(t0)

    la      t0, bw_trap_entry
    csrw    mtvec, t0
    li      t5, ST_CRT_DONE
    sw      t5, MGMT_FW_STATUS(t6)

    call    boot_main
    /* boot_main never returns; if it does, park with the last status in place */
7:  wfi
    j       7b
    .size   _start, . - _start

/* ---------------------------------------------------------------------------
 * Early trap: a trap before the C environment exists. Reports and parks.
 * FW_STATUS = 0xDEAD0000 | mcause[15:0], SCRATCH = mepc, FW_ATTN = 1 (stock-firmware convention).
 */
    .balign 4
    .type   bw_early_trap, @function
bw_early_trap:
    csrr    t0, mcause
    csrr    t1, mepc
    li      t6, MGMT_BASE
    slli    t0, t0, 16
    srli    t0, t0, 16
    lui     t2, 0xDEAD0
    or      t2, t2, t0
    sw      t2, MGMT_FW_STATUS(t6)
    sw      t1, MGMT_SCRATCH(t6)
    li      t2, 1
    sw      t2, MGMT_FW_ATTN(t6)
1:  wfi
    j       1b
    .size   bw_early_trap, . - bw_early_trap

/* ---------------------------------------------------------------------------
 * Full trap entry. Saves the caller-saved registers (64 B frame = bw_frame_t), calls
 * bw_trap_dispatch(frame, mcause, mepc, mtval) which returns the mepc to resume at.
 */
    .balign 4
    .globl  bw_trap_entry
    .type   bw_trap_entry, @function
bw_trap_entry:
    addi    sp, sp, -64
    sw      ra,  0(sp)
    sw      t0,  4(sp)
    sw      t1,  8(sp)
    sw      t2, 12(sp)
    sw      a0, 16(sp)
    sw      a1, 20(sp)
    sw      a2, 24(sp)
    sw      a3, 28(sp)
    sw      a4, 32(sp)
    sw      a5, 36(sp)
    sw      a6, 40(sp)
    sw      a7, 44(sp)
    sw      t3, 48(sp)
    sw      t4, 52(sp)
    sw      t5, 56(sp)
    sw      t6, 60(sp)
    mv      a0, sp
    csrr    a1, mcause
    csrr    a2, mepc
    csrr    a3, mtval
    call    bw_trap_dispatch
    csrw    mepc, a0
    lw      ra,  0(sp)
    lw      t0,  4(sp)
    lw      t1,  8(sp)
    lw      t2, 12(sp)
    lw      a0, 16(sp)
    lw      a1, 20(sp)
    lw      a2, 24(sp)
    lw      a3, 28(sp)
    lw      a4, 32(sp)
    lw      a5, 36(sp)
    lw      a6, 40(sp)
    lw      a7, 44(sp)
    lw      t3, 48(sp)
    lw      t4, 52(sp)
    lw      t5, 56(sp)
    lw      t6, 60(sp)
    addi    sp, sp, 64
    mret
    .size   bw_trap_entry, . - bw_trap_entry

/* ---------------------------------------------------------------------------
 * bw_setjmp / bw_longjmp: callee-saved context for aborting a test after an
 * unexpected trap. bw_jmp_t = { ra, sp, s0..s11 } (14 words).
 */
    .balign 4
    .globl  bw_setjmp
    .type   bw_setjmp, @function
bw_setjmp:
    sw      ra,  0(a0)
    sw      sp,  4(a0)
    sw      s0,  8(a0)
    sw      s1, 12(a0)
    sw      s2, 16(a0)
    sw      s3, 20(a0)
    sw      s4, 24(a0)
    sw      s5, 28(a0)
    sw      s6, 32(a0)
    sw      s7, 36(a0)
    sw      s8, 40(a0)
    sw      s9, 44(a0)
    sw      s10, 48(a0)
    sw      s11, 52(a0)
    li      a0, 0
    ret
    .size   bw_setjmp, . - bw_setjmp

    .globl  bw_longjmp
    .type   bw_longjmp, @function
bw_longjmp:
    lw      ra,  0(a0)
    lw      sp,  4(a0)
    lw      s0,  8(a0)
    lw      s1, 12(a0)
    lw      s2, 16(a0)
    lw      s3, 20(a0)
    lw      s4, 24(a0)
    lw      s5, 28(a0)
    lw      s6, 32(a0)
    lw      s7, 36(a0)
    lw      s8, 40(a0)
    lw      s9, 44(a0)
    lw      s10, 48(a0)
    lw      s11, 52(a0)
    mv      a0, a1
    bnez    a0, 1f
    li      a0, 1
1:  ret
    .size   bw_longjmp, . - bw_longjmp
