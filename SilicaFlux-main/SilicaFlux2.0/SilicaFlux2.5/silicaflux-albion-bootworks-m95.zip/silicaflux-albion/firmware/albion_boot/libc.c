/* BootWorks - freestanding libc subset. RV32I has no M extension, so the compiler's integer
 * multiply/divide helpers are provided here (shift-and-add / restoring division, RISC-V M
 * division-by-zero semantics). Nothing in the boot path divides at run time except where
 * the compiler folds a constant, but a stray call must not leave an undefined symbol. */
#include <stdint.h>
#include "bw_internal.h"

void *memset(void *d, int c, uint32_t n) {
  volatile uint8_t *p = (volatile uint8_t *)d;
  while (n--) *p++ = (uint8_t)c;
  return d;
}

void *memcpy(void *d, const void *s, uint32_t n) {
  volatile uint8_t *p = (volatile uint8_t *)d;
  const volatile uint8_t *q = (const volatile uint8_t *)s;
  while (n--) *p++ = *q++;
  return d;
}

uint32_t __mulsi3(uint32_t a, uint32_t b) {
  uint32_t r = 0;
  while (b) { if (b & 1u) r += a; a <<= 1; b >>= 1; }
  return r;
}

static uint32_t udivmod(uint32_t n, uint32_t d, uint32_t *rem) {
  uint32_t q = 0, r = 0;
  if (d == 0u) { *rem = n; return 0xFFFFFFFFu; }
  for (int i = 31; i >= 0; i--) {
    r = (r << 1) | ((n >> i) & 1u);
    if (r >= d) { r -= d; q |= 1u << i; }
  }
  *rem = r;
  return q;
}

uint32_t __udivsi3(uint32_t n, uint32_t d) { uint32_t r; return udivmod(n, d, &r); }
uint32_t __umodsi3(uint32_t n, uint32_t d) { uint32_t r; udivmod(n, d, &r); return r; }
