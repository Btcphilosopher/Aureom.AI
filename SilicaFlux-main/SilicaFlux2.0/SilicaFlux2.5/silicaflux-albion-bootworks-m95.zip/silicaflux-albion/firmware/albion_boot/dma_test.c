/* BootWorks - DMA self-tests (memory-to-memory, protection, error semantics), table-driven.
 *
 * All transfers run in the FIRMWARE domain (0) between DATA banks (banks above the firmware's first 32 KiB),
 * or in a tenant domain through real permission windows. The protection tests deliberately aim at forbidden
 * targets, but only at targets where a broken invariant cannot hurt: a 256-byte zero SANDBOX inside bank 0 as a
 * destination (restored after every test), read-only sources (the sandbox, an MMIO identity word). Nothing
 * here ever targets code or stack.
 *
 * Every case is one row of data: where the transfer goes, what the hardware must answer (status, error code,
 * BYTES_DONE, ERR_ADDR) and what must / must not have happened to the data. One executor checks all of it.
 */
#include "bw_internal.h"

#define SENTINEL 0xDEADBEEFu
#define W(a) ((volatile uint32_t *)(uintptr_t)(a))

void bw_win_set(uint32_t idx, uint32_t base, uint32_t limit, uint32_t attr) {
  uint32_t o = ALBION_PERM_WIN_BASE + idx * ALBION_PERM_WIN_BASE_STRIDE;
  BW_PERM(o + 8u) = 0u;                  /* invalidate, program, validate last */
  BW_PERM(o + 0u) = base;
  BW_PERM(o + 4u) = limit;
  BW_PERM(o + 8u) = attr;
}

bw_dma_res_t bw_dma_run(uint32_t src, uint32_t dst, uint32_t len, uint32_t domain, uint32_t fill, uint32_t pattern) {
  bw_dma_res_t r;
  BW_DMA(ALBION_DMA_SRC)    = src;
  BW_DMA(ALBION_DMA_DST)    = dst;
  BW_DMA(ALBION_DMA_LEN)    = len;
  BW_DMA(ALBION_DMA_DOMAIN) = domain;
  if (fill) BW_DMA(ALBION_DMA_FILL_PATTERN) = pattern;
  BW_DMA(ALBION_DMA_CTRL)   = 1u | (fill ? 2u : 0u);
  r.timed_out = !BW_POLL((BW_DMA(ALBION_DMA_STATUS) & (ALBION_DMA_STATUS_BUSY_MASK | ALBION_DMA_STATUS_DONE_MASK)) ==
                         ALBION_DMA_STATUS_DONE_MASK, BW_DMA_DEADLINE);
  r.status   = BW_DMA(ALBION_DMA_STATUS);
  r.bytes    = BW_DMA(ALBION_DMA_BYTES_DONE);
  r.err_addr = BW_DMA(ALBION_DMA_ERR_ADDR);
  r.cycles   = BW_DMA(ALBION_DMA_CYCLES);
  return r;
}

static uint32_t xs32(uint32_t s) { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }

static void fill_prbs(uint32_t a, uint32_t nbytes, uint32_t seed) {
  for (uint32_t i = 0; i < nbytes; i += 4u) { seed = xs32(seed); *W(a + i) = seed; }
}
/* returns the address of the first mismatch, or 0xFFFFFFFF if the range matches */
static uint32_t check_prbs(uint32_t a, uint32_t nbytes, uint32_t seed) {
  for (uint32_t i = 0; i < nbytes; i += 4u) { seed = xs32(seed); if (*W(a + i) != seed) return a + i; }
  return 0xFFFFFFFFu;
}
static void fill_const(uint32_t a, uint32_t nbytes, uint32_t v) { for (uint32_t i = 0; i < nbytes; i += 4u) *W(a + i) = v; }
static uint32_t check_const(uint32_t a, uint32_t nbytes, uint32_t v) {
  for (uint32_t i = 0; i < nbytes; i += 4u) if (*W(a + i) != v) return a + i;
  return 0xFFFFFFFFu;
}

#define NEED_BANKS() do { if (bw_ndata() < 1u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.banks); } while (0)
#define OK_STATUS(st) (((st) & (BW_DMA_ST_DONE | BW_DMA_ST_ERROR)) == BW_DMA_ST_DONE)

/* second data bank for cross-bank copies; falls back to the same bank at a disjoint offset */
static uint32_t bank_b(void) { return bw_ndata() > 1u ? 1u : 0u; }

/* =========================================================================== case executor */

enum { AK_NONE, AK_DATA0, AK_DATAB, AK_SANDBOX, AK_SRAMEND, AK_MMIO };    /* address kinds */
enum { W_NONE, W_RW, W_SHORT, W_RO, W_ADMIN };                             /* permission-window setups */
#define F_FILL    1u    /* fill mode                                                            */
#define F_VERIFY  2u    /* destination prefix (BYTES_DONE) must hold the source / fill data      */
#define F_EA_DST  4u    /* ERR_ADDR must equal dst + BYTES_DONE                                   */
#define F_EA_SRC  8u    /* ERR_ADDR must equal src + BYTES_DONE                                   */
#define F_SRCKEEP 16u   /* the source range must be unchanged afterwards                          */
#define OKCODE    0xFFu /* the transfer must succeed                                              */
#define FILLPAT   0x4D4D4D4Du

typedef struct {
  uint32_t len;
  int16_t  so, dof;                       /* offsets from the address kinds                        */
  uint8_t  sk, dk, dom, flags, win, ecode;
  uint16_t ebytes;                        /* expected BYTES_DONE when an error is expected          */
  uint16_t spre, dpre;                    /* source PRBS words / destination SENTINEL words to prefill */
  uint16_t dg_fail;                       /* status wrong                                          */
  uint16_t dg_code;                       /* error code wrong                                      */
  uint16_t dg_bytes;                      /* BYTES_DONE, ERR_ADDR or moved data wrong              */
  uint16_t dg_over;                       /* data changed where nothing may change                 */
  uint16_t dg_src;                        /* source modified                                       */
} dcase_t;

static uint32_t g_last_cycles;

static uint32_t addr_of(uint32_t k, int32_t off) {
  switch (k) {
    case AK_DATA0:   return bw_data_base(0u) + (uint32_t)off;
    case AK_DATAB:   return bw_data_base(bank_b()) + (uint32_t)off;
    case AK_SANDBOX: return BW_SYM(bw_sandbox) + (uint32_t)off;
    case AK_SRAMEND: return g_hw.banks * g_hw.bank_bytes + (uint32_t)off;
    case AK_MMIO:    return ALBION_MMIO_BASE + (uint32_t)off;
    default:         return (uint32_t)off;
  }
}

#define ATTR(dom, r, w) (1u | ((r) ? 2u : 0u) | ((w) ? 4u : 0u) | ((uint32_t)(dom) << 8))

static void win_setup(uint32_t w, uint32_t src, uint32_t dst, uint32_t len) {
  bw_win_close_all();
  if (w == W_NONE) return;
  uint32_t dom = (w == W_ADMIN) ? 1u : 2u;
  bw_win_set(0u, src, src + len - 1u, ATTR(dom, 1, w == W_ADMIN));
  bw_win_set(1u, dst, dst + (w == W_SHORT ? 127u : len - 1u), ATTR(dom, 1, w != W_RO));
}

#define DFAIL(d, a, b, c) return BW_FAIL_R((d), (a), (b), (c))

static bw_result_t run_dcases(const dcase_t *c, uint32_t n, uint16_t tmo_diag) {
  for (uint32_t i = 0; i < n; i++, c++) {
    uint32_t src = addr_of(c->sk, c->so), dst = addr_of(c->dk, c->dof), seed = 0x7E4A47u + i, bad;
    win_setup(c->win, src, dst, c->len);
    /* cases may use deliberately unaligned DMA addresses; the CPU's own prefill/verify accesses stay word aligned */
    if (c->spre) fill_prbs(src & ~3u, 4u * c->spre, seed);
    if (c->dpre) fill_const(dst & ~3u, 4u * c->dpre, SENTINEL);
    bw_dma_res_t r = bw_dma_run(src, dst, c->len, c->dom, c->flags & F_FILL, FILLPAT);
    if (r.timed_out) return BW_TMO_R(tmo_diag, i, r.status, r.bytes);
    g_last_cycles = r.cycles;
    uint32_t eb = (c->ecode == OKCODE) ? c->len : c->ebytes;
    if (c->ecode == OKCODE) {
      if (!OK_STATUS(r.status)) DFAIL(c->dg_fail, i, BW_DMA_ST_DONE, r.status);
    } else {
      if (!(r.status & BW_DMA_ST_ERROR)) DFAIL(c->dg_fail, i, c->ecode, r.status);
      if (BW_DMA_ERRCODE(r.status) != c->ecode) DFAIL(c->dg_code, i, c->ecode, BW_DMA_ERRCODE(r.status));
    }
    if (r.bytes != eb) DFAIL(c->dg_bytes, i, eb, r.bytes);
    if ((c->flags & F_EA_DST) && r.err_addr != dst + eb) DFAIL(c->dg_bytes, i, dst + eb, r.err_addr);
    if ((c->flags & F_EA_SRC) && r.err_addr != src + eb) DFAIL(c->dg_bytes, i, src + eb, r.err_addr);
    if ((c->flags & F_VERIFY) && eb) {
      bad = (c->flags & F_FILL) ? check_const(dst & ~3u, eb, FILLPAT) : check_prbs(dst & ~3u, eb, seed);
      if (bad != 0xFFFFFFFFu) DFAIL(c->dg_bytes, bad, i, *W(bad));
    }
    if (4u * c->dpre > eb && (bad = check_const((dst & ~3u) + eb, 4u * c->dpre - eb, SENTINEL)) != 0xFFFFFFFFu)
      DFAIL(c->dg_over, bad, SENTINEL, *W(bad));            /* data moved where nothing may move */
    if ((c->flags & F_SRCKEEP) && (bad = check_prbs(src & ~3u, c->len, seed)) != 0xFFFFFFFFu)
      DFAIL(c->dg_src, bad, i, *W(bad));
  }
  bw_win_close_all();
  return BW_PASS_A(n, g_last_cycles, 0);
}
#define RUN_D(tbl, tmo) run_dcases(tbl, sizeof(tbl) / sizeof(tbl[0]), (tmo))

/* =========================================================================== idle */

bw_result_t bw_test_DMA_IDLE(void) {
  uint32_t st = BW_DMA(ALBION_DMA_STATUS);
  if ((st & 0xFFFFu) || BW_DMA(ALBION_DMA_BYTES_DONE) || BW_DMA(ALBION_DMA_CYCLES) || BW_DMA(ALBION_DMA_ERR_ADDR))
    return BW_FAIL_R(BW_D_DMA_NOT_IDLE, st, BW_DMA(ALBION_DMA_BYTES_DONE), BW_DMA(ALBION_DMA_CYCLES));
  return BW_PASS_R();
}

/* =========================================================================== fill and copy */

bw_result_t bw_test_DMA_FILL(void) {
  NEED_BANKS();
  static const dcase_t c[] = {
    { 256u, 0, 0x100, AK_NONE, AK_DATA0, 0, F_FILL | F_VERIFY, W_NONE, OKCODE, 0, 0, 65,        /* +1 guard word */
      BW_D_DMA_FILL_STATUS, BW_D_DMA_FILL_STATUS, BW_D_DMA_FILL_DATA, BW_D_DMA_FILL_OVERRUN, 0 },
  };
  bw_result_t r = RUN_D(c, BW_D_DMA_FILL_TIMEOUT);
  if (r.outcome == BW_PASS && g_last_cycles == 0u) return BW_FAIL_R(BW_D_DMA_FILL_STATUS, 0, 1u, 0u);
  return r;
}

bw_result_t bw_test_DMA_COPY(void) {
  NEED_BANKS();
  #define CP(len_, dk_, dof_) { len_, 0x400, dof_, AK_DATA0, dk_, 0, F_VERIFY | F_SRCKEEP, W_NONE, OKCODE, 0, (len_) / 4, (len_) / 4 + 1, \
      BW_D_DMA_COPY_STATUS, BW_D_DMA_COPY_STATUS, BW_D_DMA_COPY_DATA, BW_D_DMA_COPY_OVERRUN, BW_D_DMA_COPY_SRC }
  static const dcase_t c[] = {
    CP(1024u, AK_DATAB, 0x2040),                       /* across banks (same bank on a one-data-bank part, disjoint range) */
    CP(512u,  AK_DATA0, 0x1000),                       /* within one bank, disjoint ranges */
  };
  #undef CP
  return RUN_D(c, BW_D_DMA_COPY_TIMEOUT);
}

/* One word up to a full bank. Throughput bounds: cannot beat one word per cycle, must not be absurdly slow. */
bw_result_t bw_test_DMA_SIZES(void) {
  NEED_BANKS();
  static const uint16_t sz[] = { 4u, 8u, 12u, 64u, 252u, 4096u };
  const uint32_t same = (bank_b() == 0u);
  const uint32_t maxlen = same ? g_hw.bank_bytes / 2u - 4u : g_hw.bank_bytes;
  for (uint32_t i = 0; i <= sizeof(sz) / sizeof(sz[0]); i++) {
    uint32_t len = (i < sizeof(sz) / sizeof(sz[0])) ? sz[i] : maxlen;
    uint32_t guard = (i < sizeof(sz) / sizeof(sz[0])) || same;        /* a full bank has no addressable word after it */
    dcase_t c = { len, 0, (int16_t)(same ? g_hw.bank_bytes / 2u : 0u), AK_DATA0, AK_DATAB, 0, F_VERIFY, W_NONE, OKCODE, 0,
                  (uint16_t)(len / 4u), (uint16_t)(len / 4u + guard),
                  BW_D_DMA_SIZE_BYTES, BW_D_DMA_SIZE_BYTES, BW_D_DMA_SIZE_DATA, BW_D_DMA_SIZE_DATA, 0 };
    bw_result_t r = run_dcases(&c, 1u, BW_D_DMA_SIZE_TIMEOUT);
    if (r.outcome != BW_PASS) { r.aux0 = len; return r; }
    uint32_t words = len >> 2;
    if (g_last_cycles < words || g_last_cycles > 200u + 16u * words) return BW_FAIL_R(BW_D_DMA_SIZE_CYCLES, len, g_last_cycles, words);
  }
  return BW_PASS_A(maxlen, g_last_cycles, 0);
}

/* =========================================================================== parameter checking */

bw_result_t bw_test_DMA_BADPARAM(void) {
  NEED_BANKS();
  #define BP(so_, dof_, len_, fl) { len_, so_, dof_, AK_DATA0, AK_DATA0, 0, fl, W_NONE, ALBION_DMAE_BADPARAM, 0, 4, 4, \
                                    BW_D_DMA_BAD_NOERR, BW_D_DMA_BAD_CODE, BW_D_DMA_BAD_NOERR, BW_D_DMA_BAD_NOERR, 0 }
  static const dcase_t c[] = {
    BP(0x2000, 0x2400, 0u, 0u),                         /* LEN == 0                 */
    BP(0x2000, 0x2400, 6u, 0u),                         /* LEN not a multiple of 4  */
    BP(0x2001, 0x2400, 8u, 0u),                         /* unaligned source (copy)  */
    BP(0x2000, 0x2402, 8u, 0u),                         /* unaligned destination    */
    BP(0x2000, 0x2400, ALBION_DMA_MAX_LEN + 4u, 0u),    /* LEN > DMA_MAX_LEN        */
    BP(0x2000, 0x2402, 8u, F_FILL),                     /* unaligned destination (fill) */
  };
  #undef BP
  return RUN_D(c, BW_D_DMA_BAD_TIMEOUT);
}

/* =========================================================================== first failing beat */

bw_result_t bw_test_DMA_ERRORS(void) {
  NEED_BANKS();
  /* both cases cross the end of SRAM after two words: BYTES_DONE = 8, ERR_ADDR = the first undecoded address */
  #define EDG BW_D_DMA_ERR_NOERR, BW_D_DMA_ERR_CODE, BW_D_DMA_ERR_BYTES, BW_D_DMA_ERR_BYTES, 0
  static const dcase_t c[] = {
    { 16u, 0, -8, AK_NONE, AK_SRAMEND, 0, F_FILL | F_VERIFY | F_EA_DST, W_NONE, ALBION_DMAE_DECERR, 8, 0, 2, EDG },   /* write beat 2 fails */
    { 16u, -8, 0x3000, AK_SRAMEND, AK_DATA0, 0, F_VERIFY | F_EA_SRC, W_NONE, ALBION_DMAE_DECERR, 8, 2, 4, EDG },     /* read beat 2 fails  */
  };
  #undef EDG
  return RUN_D(c, BW_D_DMA_ERR_TIMEOUT);
}

/* =========================================================================== hardware invariants */

bw_result_t bw_test_DMA_FWBANK(void) {
  NEED_BANKS();
  /* forbidden targets, each chosen so a broken invariant cannot hurt. Domain 0 (firmware) in all three. */
  #define FW(w_) w_, BW_D_DMA_FW_CODE, w_, w_, 0
  static const dcase_t c[] = {
    { 16u, 0, 0, AK_NONE, AK_SANDBOX, 0, F_FILL | F_EA_DST, W_NONE, ALBION_DMAE_PERM, 0, 0, 4, FW(BW_D_DMA_FW_WRITE) },   /* write into bank 0 */
    { 16u, 0, 0x3000, AK_SANDBOX, AK_DATA0, 0, F_EA_SRC, W_NONE, ALBION_DMAE_PERM, 0, 4, 4, FW(BW_D_DMA_FW_READ) },       /* read from bank 0  */
    { 4u, 0, 0x3000, AK_MMIO, AK_DATA0, 0, F_EA_SRC, W_NONE, ALBION_DMAE_PERM, 0, 0, 1, FW(BW_D_DMA_FW_MMIO) },           /* read an MMIO word */
  };
  #undef FW
  BW_PERM(ALBION_PERM_VIOL_CLEAR) = 1u;
  uint32_t v0 = BW_PERM(ALBION_PERM_VIOL_COUNT);
  bw_result_t r = RUN_D(c, BW_D_DMA_FW_TIMEOUT);
  if (r.outcome != BW_PASS) return r;
  /* all three denials were logged; the log holds the first: DMA write port, domain 0, a write, to the sandbox */
  uint32_t info = BW_PERM(ALBION_PERM_VIOL_INFO);
  if (BW_PERM(ALBION_PERM_VIOL_COUNT) != v0 + 3u || !(info & 0x80000000u) || ((info >> 4) & 3u) != ALBION_M_DMAWR ||
      (info & 0xFu) != ALBION_DOM_FIRMWARE || !(info & 0x100u) || BW_PERM(ALBION_PERM_VIOL_ADDR) != BW_SYM(bw_sandbox))
    return BW_FAIL_R(BW_D_DMA_FW_VIOL, BW_PERM(ALBION_PERM_VIOL_ADDR), BW_SYM(bw_sandbox), info);
  BW_PERM(ALBION_PERM_VIOL_CLEAR) = 1u;
  return BW_PASS_R();
}

/* =========================================================================== tenant permission windows */

bw_result_t bw_test_DMA_PERM(void) {
  NEED_BANKS();
  if (g_hw.windows < 2u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.windows);
  #define PC(win_, dom_, ecode_, eb, fl, dg) { 256u, 0x2000, 0x2800, AK_DATA0, AK_DATAB, dom_, fl, win_, ecode_, eb, 64, 64, \
                                               dg, BW_D_DMA_PERM_CODE, dg, dg, 0 }
  static const dcase_t c[] = {
    PC(W_NONE,  2, ALBION_DMAE_PERM, 0,   0,                   BW_D_DMA_PERM_DENY),      /* tenant, no window: denied before data moves */
    PC(W_RW,    2, OKCODE,           256, F_VERIFY,            BW_D_DMA_PERM_ALLOW),     /* windows RW: succeeds                         */
    PC(W_SHORT, 2, ALBION_DMAE_PERM, 128, F_VERIFY | F_EA_DST, BW_D_DMA_PERM_BOUNDARY),  /* destination window ends after 128 B: write beat 32 fails */
    PC(W_RO,    2, ALBION_DMAE_PERM, 0,   0,                   BW_D_DMA_PERM_RO),        /* window without W: denied at the first write  */
    PC(W_RW,    3, ALBION_DMAE_PERM, 0,   0,                   BW_D_DMA_PERM_DOMAIN),    /* windows belong to domain 2                   */
    PC(W_ADMIN, 1, ALBION_DMAE_PERM, 0,   0,                   BW_D_DMA_PERM_ADMIN),     /* HOST_ADMIN is always denied                  */
  };
  #undef PC
  return RUN_D(c, BW_D_DMA_PERM_TIMEOUT);
}
