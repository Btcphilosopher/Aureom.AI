#!/usr/bin/env python3
"""Toolchain manifest: exact tool versions, flags, source and artifact hashes. Reproducible: no timestamps
unless SOURCE_DATE_EPOCH is set, no host names."""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwlib import Elf32  # noqa: E402


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def ver(cmd):
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return (out.stdout or out.stderr).strip().splitlines()[0]
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--build-dir", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--bw-dir", required=True)
    ap.add_argument("--cflags", default="")
    ap.add_argument("--ldflags", default="")
    a = ap.parse_args()
    root = os.path.abspath(os.path.join(a.bw_dir, "..", ".."))
    arts = {}
    for ext in ("elf", "bin", "hex", "dis", "map"):
        p = os.path.join(a.build_dir, f"{a.name}.{ext}")
        if os.path.exists(p):
            arts[f"{a.name}.{ext}"] = dict(bytes=os.path.getsize(p), sha256=sha(p))
    srcs = {}
    for f in sorted(os.listdir(a.bw_dir)):
        if f.endswith((".c", ".S")):
            srcs[f"firmware/albion_boot/{f}"] = sha(os.path.join(a.bw_dir, f))
    for sub in ("include", "tools"):
        for f in sorted(os.listdir(os.path.join(a.bw_dir, sub))):
            if f.endswith((".h", ".py")):
                srcs[f"firmware/albion_boot/{sub}/{f}"] = sha(os.path.join(a.bw_dir, sub, f))
    srcs["firmware/albion_boot/linker.ld"] = sha(os.path.join(a.bw_dir, "linker.ld"))
    srcs["firmware/albion/include/albion_regs.h"] = sha(os.path.join(root, "firmware/albion/include/albion_regs.h"))
    srcs["spec/albion/regmap.json"] = sha(os.path.join(root, "spec/albion/regmap.json"))
    elf = Elf32(os.path.join(a.build_dir, f"{a.name}.elf"))
    keysyms = ["_start", "bw_sandbox", "bw_image_trailer", "g_report", "_scratch_start", "_scratch_end", "_stack_limit",
               "_stack_top", "_bss_end", "_data_lma", "_image_end", "boot_main", "bw_trap_entry"]
    m = dict(
        project="SilicaFlux BootWorks (Module 95)", target="SilicaFlux Albion ControlCore: RV32I + Zicsr, M-mode",
        isa=dict(march="rv32i_zicsr", mabi="ilp32", strict_align=True, extensions_not_used="M A C F D"),
        tools=dict(clang=ver(["clang", "--version"]), lld=ver(["ld.lld", "--version"]), objcopy=ver(["llvm-objcopy", "--version"]),
                   objdump=ver(["llvm-objdump", "--version"]), python=sys.version.split()[0],
                   gnu_gcc_crosscheck=ver(["riscv64-unknown-elf-gcc", "--version"]),
                   verilator=ver(["verilator", "--version"]), yosys=ver(["yosys", "-V"])),
        host=dict(system=platform.system(), machine=platform.machine()),
        cflags=a.cflags, ldflags=a.ldflags,
        layout=dict(entry=f"0x{elf.entry:X}", image_bytes=elf.sym("_image_end"),
                    symbols={k: f"0x{elf.sym(k):X}" for k in keysyms if k in elf.symbols}),
        sections={s["name"]: dict(addr=f"0x{s['addr']:X}", bytes=s["size"]) for s in elf.sections if s["name"] and s["addr"] is not None and s["size"]
                  and s["name"] in (".text", ".rodata", ".data", ".trailer", ".bss")},
        artifacts=arts, sources=srcs)
    if os.environ.get("SOURCE_DATE_EPOCH"):
        m["source_date_epoch"] = int(os.environ["SOURCE_DATE_EPOCH"])
    json.dump(m, open(a.out, "w"), indent=1, sort_keys=True)
    print(f"bw_manifest: {a.out}")


if __name__ == "__main__":
    main()
