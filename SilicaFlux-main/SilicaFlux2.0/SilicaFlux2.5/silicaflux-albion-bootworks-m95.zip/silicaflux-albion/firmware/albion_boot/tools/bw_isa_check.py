#!/usr/bin/env python3
"""Toolchain-defect gate: every instruction the toolchain emitted must be in the ISA the core implements.

The Albion ControlCore is RV32I + Zicsr (plus FENCE/FENCE.I as no-ops), M-mode, no M, no A, no C, no F/D. A compiler,
assembler or library that slips in a MUL, an AMO or a 16-bit compressed instruction produces firmware that traps with
'illegal instruction' on this core. This check decodes every 32-bit word of .text and fails the build, naming the
address, the function and the encoding, when it finds anything else. The deliberate probe encodings in probes.S and the
256-byte DMA sandbox are whitelisted by symbol.
"""
import argparse
import json
import os
import struct
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwlib import Elf32  # noqa: E402

SYS_WORDS = {0x00000073: "ecall", 0x00100073: "ebreak", 0x30200073: "mret", 0x10500073: "wfi"}
CSR = {1: "csrrw", 2: "csrrs", 3: "csrrc", 5: "csrrwi", 6: "csrrsi", 7: "csrrci"}


def classify(w):
    """Return a mnemonic class for an implemented encoding, or None."""
    if w & 3 != 3:
        return None
    op, f3, f7 = w & 0x7F, (w >> 12) & 7, w >> 25
    if op == 0x37: return "lui"
    if op == 0x17: return "auipc"
    if op == 0x6F: return "jal"
    if op == 0x67: return "jalr" if f3 == 0 else None
    if op == 0x63: return "branch" if f3 in (0, 1, 4, 5, 6, 7) else None
    if op == 0x03: return "load" if f3 in (0, 1, 2, 4, 5) else None
    if op == 0x23: return "store" if f3 in (0, 1, 2) else None
    if op == 0x13:
        if f3 == 1: return "slli" if f7 == 0 else None
        if f3 == 5: return "srli/srai" if f7 in (0, 0x20) else None
        return "op-imm"
    if op == 0x33:
        if f7 == 0 or (f7 == 0x20 and f3 in (0, 5)): return "op"
        return None                                   # funct7 == 1 would be RV32M
    if op == 0x0F: return "fence" if f3 == 0 else ("fence.i" if f3 == 1 else None)
    if op == 0x73:
        if f3 == 0: return SYS_WORDS.get(w)
        return CSR.get(f3)
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("elf")
    ap.add_argument("--objdump", default="llvm-objdump")
    ap.add_argument("--report")
    a = ap.parse_args()
    elf = Elf32(a.elf)
    text = elf.section(".text")
    data = elf.data[text["offset"]:text["offset"] + text["size"]]
    base = text["addr"]
    allowed = set()
    sb = elf.sym("bw_sandbox")
    pad_lo = elf.sym("bw_longjmp") + elf.symbols["bw_longjmp"]["size"]      # end of the startup code
    allowed.update(range(pad_lo, sb + 256, 4))                               # linker padding (zeros) + the 256-byte sandbox
    for n in ("bw_trig_mul_insn", "bw_trig_amo_insn", "bw_trig_fadd_insn", "bw_trig_rvc_insn", "bw_trig_illegal_insn"):
        allowed.add(elf.sym(n))
    allowed.add(elf.sym("bw_trig_pad") + 4)          # `.word 0` after the pad ret
    hist, bad = Counter(), []
    for off in range(0, len(data) - 3, 4):
        addr = base + off
        w = struct.unpack_from("<I", data, off)[0]
        if addr in allowed:
            hist["(probe/sandbox word)"] += 1
            continue
        c = classify(w)
        if c is None:
            bad.append((addr, w))
        else:
            hist[c] += 1
    rep = dict(elf=os.path.basename(a.elf), text_bytes=len(data), instructions=sum(hist.values()),
               histogram=dict(sorted(hist.items())), violations=[dict(addr=f"0x{x:08X}", word=f"0x{w:08X}", function=elf.symbol_at(x)) for x, w in bad])
    if elf.entry != 0:
        bad.append((elf.entry, 0))
        rep["violations"].append(dict(addr=f"0x{elf.entry:08X}", word="entry", function="entry point is not the reset vector 0x0"))
    if a.report:
        json.dump(rep, open(a.report, "w"), indent=1)
    if bad:
        print("bw_isa_check: TOOLCHAIN DEFECT - instruction outside RV32I+Zicsr emitted:", file=sys.stderr)
        for v in rep["violations"][:20]:
            print(f"   {v['addr']}: {v['word']} in {v['function']}", file=sys.stderr)
        sys.exit(1)
    print(f"bw_isa_check: {rep['instructions']} instructions, all RV32I+Zicsr "
          f"({', '.join(f'{k}={v}' for k, v in sorted(hist.items()))})")


if __name__ == "__main__":
    main()
