#!/usr/bin/env python3
"""Patch the image trailer (size + CRC-32 + version) into the ELF itself.

The firmware verifies its own image against this trailer at boot (IMG_CRC), so the CRC must be part of the
same artifacts the host loads. Patching the ELF (not only the .bin) keeps ELF, .bin, .hex, disassembly and map
describing one image. The CRC covers the whole image [0, _image_end) - code, sandbox, rodata and the .data load image - with the 16 trailer bytes taken as zero.
"""
import argparse
import os
import re
import struct
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwlib import Elf32, crc32  # noqa: E402


def hdr_const(bw_dir, name):
    s = open(os.path.join(bw_dir, "include", "bw_status.h")).read()
    m = re.search(r"#define\s+%s\s+(0x[0-9A-Fa-f]+)u" % name, s)
    return int(m.group(1), 16)


def flat(objcopy, elf, out):
    subprocess.run([objcopy, "-O", "binary", elf, out], check=True)
    return open(out, "rb").read()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--elf", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--objcopy", default="llvm-objcopy")
    a = ap.parse_args()
    bw_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    magic, version = hdr_const(bw_dir, "BW_TRAILER_MAGIC"), hdr_const(bw_dir, "BW_VERSION")
    elf = Elf32(a.elf)
    taddr = elf.sym("bw_image_trailer")
    tsec = elf.section(".trailer")
    if tsec is None or tsec["size"] != 16 or tsec["addr"] != taddr:
        sys.exit("bw_patch_image: .trailer section missing, not 16 bytes, or not at bw_image_trailer")
    with tempfile.TemporaryDirectory() as td:
        img = flat(a.objcopy, a.elf, os.path.join(td, "raw.bin"))
        iend = elf.sym("_image_end")
        if len(img) != iend or not (0 < taddr and taddr + 16 <= iend):
            sys.exit(f"bw_patch_image: flat image is {len(img)} bytes but _image_end is 0x{iend:X} (gap or overlap in the load image)")
        crc = crc32(img[:taddr] + bytes(16) + img[taddr + 16:])
        tb = struct.pack("<IIII", magic, iend, crc, version)
        tp = os.path.join(td, "trailer.bin")
        open(tp, "wb").write(tb)
        subprocess.run([a.objcopy, "--update-section", f".trailer={tp}", a.elf, a.out], check=True)
        img2 = flat(a.objcopy, a.out, os.path.join(td, "patched.bin"))
        m2, s2, c2, v2 = struct.unpack_from("<IIII", img2, taddr)
        if (m2, s2, c2, v2) != (magic, iend, crc, version) or crc32(img2[:taddr] + bytes(16) + img2[taddr + 16:]) != c2 or len(img2) != iend:
            sys.exit("bw_patch_image: verification of the patched image failed")
    print(f"bw_patch_image: image {iend} bytes, CRC-32 0x{crc:08X} (trailer at 0x{taddr:X} taken as zero)")


if __name__ == "__main__":
    main()
