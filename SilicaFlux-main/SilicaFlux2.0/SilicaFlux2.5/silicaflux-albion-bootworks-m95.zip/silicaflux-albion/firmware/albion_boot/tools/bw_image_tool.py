#!/usr/bin/env python3
"""bin -> memory images.  hex: one little-endian 32-bit word per line (Verilog $readmemh)."""
import struct
import sys


def main():
    cmd, src, dst = sys.argv[1:4]
    d = open(src, "rb").read()
    d += b"\0" * (-len(d) % 4)
    words = struct.unpack("<%dI" % (len(d) // 4), d)
    if cmd == "hex":
        open(dst, "w").write("".join("%08x\n" % w for w in words))
    else:
        sys.exit("unknown command " + cmd)


if __name__ == "__main__":
    main()
