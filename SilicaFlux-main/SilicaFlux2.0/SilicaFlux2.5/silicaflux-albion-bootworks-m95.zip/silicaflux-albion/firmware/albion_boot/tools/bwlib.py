"""BootWorks build/test helper library: minimal ELF32 reader, CRC, diag-table parser. No third-party deps."""
import re
import struct
import zlib


class Elf32:
    """Just enough ELF32-LE to read sections and symbols of the firmware image."""

    def __init__(self, path):
        self.path = path
        self.data = open(path, "rb").read()
        d = self.data
        if d[:4] != b"\x7fELF" or d[4] != 1 or d[5] != 1:
            raise ValueError(f"{path}: not a 32-bit little-endian ELF")
        (self.e_type, self.e_machine, _v, self.entry, self.phoff, self.shoff, _fl, _eh,
         self.phentsize, self.phnum, self.shentsize, self.shnum, self.shstrndx) = struct.unpack_from("<HHIIIIIHHHHHH", d, 16)
        if self.e_machine != 243:
            raise ValueError(f"{path}: not RISC-V (e_machine={self.e_machine})")
        self.sections = []
        for i in range(self.shnum):
            off = self.shoff + i * self.shentsize
            (nm, ty, fl, addr, offs, size, link, info, align, entsz) = struct.unpack_from("<IIIIIIIIII", d, off)
            self.sections.append(dict(name_off=nm, type=ty, flags=fl, addr=addr, offset=offs, size=size,
                                      link=link, info=info, align=align, entsize=entsz))
        stro = self.sections[self.shstrndx]
        for s in self.sections:
            s["name"] = self._cstr(stro["offset"] + s["name_off"])
        self.symbols = {}
        for s in self.sections:
            if s["type"] == 2:   # SHT_SYMTAB
                strsec = self.sections[s["link"]]
                for k in range(s["size"] // 16):
                    nm, val, sz, info, other, shndx = struct.unpack_from("<IIIBBH", d, s["offset"] + 16 * k)
                    name = self._cstr(strsec["offset"] + nm)
                    if name:
                        self.symbols[name] = dict(value=val, size=sz, info=info, shndx=shndx)

    def _cstr(self, off):
        end = self.data.index(b"\0", off)
        return self.data[off:end].decode("ascii", "replace")

    def section(self, name):
        for s in self.sections:
            if s["name"] == name:
                return s
        return None

    def sym(self, name):
        return self.symbols[name]["value"]

    def symbol_at(self, addr):
        """Name of the function/object symbol covering addr (for diagnostics)."""
        best = None
        for n, s in self.symbols.items():
            if s["value"] <= addr and (best is None or s["value"] > best[1]) and (s["info"] & 0xF) in (1, 2):
                if s["size"] == 0 or addr < s["value"] + s["size"]:
                    best = (n, s["value"])
        return best[0] if best else None


def crc32(b):
    return zlib.crc32(b) & 0xFFFFFFFF


DIAG_RE = re.compile(r'X\(\s*([A-Z0-9_]+)\s*,\s*(0x[0-9A-Fa-f]+)\s*,\s*"((?:[^"\\]|\\.)*)"\s*\)')
TEST_RE = re.compile(r'X\(\s*([A-Z0-9_]+)\s*,\s*(BW_STAGE_[A-Z]+)\s*,\s*"((?:[^"\\]|\\.)*)"\s*\)')
STAGE_RE = re.compile(r'#define\s+(BW_STAGE_[A-Z]+)\s+(0x[0-9A-Fa-f]+)u')


def parse_diag_header(path):
    """Returns (tests, diags, stages). tests: list of (name, stage_name, text); diags: list of (name, code, text)."""
    s = open(path).read()
    stages = {m.group(1): int(m.group(2), 16) for m in STAGE_RE.finditer(s)}
    test_block = s[s.index("#define BW_TEST_LIST"):s.index("/* X(name, code, description) */")]
    diag_block = s[s.index("#define BW_DIAG_LIST"):]
    tests = [(m.group(1), m.group(2), m.group(3)) for m in TEST_RE.finditer(test_block)]
    diags = [(m.group(1), int(m.group(2), 16), m.group(3)) for m in DIAG_RE.finditer(diag_block)]
    return tests, diags, stages


GROUP_NAMES = {0x10: "CPU/ISA", 0x20: "TRAP", 0x30: "PLATFORM", 0x40: "REGISTER", 0x50: "SRAM", 0x60: "ECC",
               0x70: "DMA", 0x80: "INTERRUPT", 0x90: "COUNTER/TIMER", 0xE0: "INTERNAL", 0xF0: "SKIPPED", 0xF1: "UNSUPPORTED"}
OUTCOMES = ["PASS", "FAIL", "TIMEOUT", "SKIPPED", "UNSUPPORTED"]
