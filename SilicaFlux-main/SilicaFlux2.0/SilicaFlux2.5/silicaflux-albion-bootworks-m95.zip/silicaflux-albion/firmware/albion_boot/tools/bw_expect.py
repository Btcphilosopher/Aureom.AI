#!/usr/bin/env python3
"""Generate the expectation file the Verilator harness reads: symbol addresses, text range, function ranges,
data-inside-text words (excluded from instruction coverage), and one milestone per function entry."""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwlib import Elf32  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("elf")
    ap.add_argument("out")
    a = ap.parse_args()
    elf = Elf32(a.elf)
    text = elf.section(".text")
    lo, hi = text["addr"], text["addr"] + text["size"]
    L = [f"entry 0x{elf.entry:X}", f"text 0x{lo:X} 0x{hi:X}", f"image_end 0x{elf.sym('_image_end'):X}"]
    for n in ("g_report", "bw_sandbox", "bw_image_trailer", "bw_trap_entry", "bw_early_trap", "boot_main", "_scratch_start",
              "_scratch_end", "_stack_limit", "_stack_top", "_bss_end"):
        if n in elf.symbols:
            L.append(f"sym {n} 0x{elf.sym(n):X}")
    funcs = sorted(((s["value"], n, s["size"]) for n, s in elf.symbols.items()
                    if (s["info"] & 0xF) == 2 and lo <= s["value"] < hi), key=lambda t: t[0])
    for i, (addr, n, size) in enumerate(funcs):
        if size == 0:
            nxt = funcs[i + 1][0] if i + 1 < len(funcs) else hi
            size = nxt - addr
        L.append(f"func {n} 0x{addr:X} 0x{size:X}")
        L.append(f"milestone {n} 0x{addr:X}")
    pad_lo = elf.sym("bw_longjmp") + elf.symbols["bw_longjmp"]["size"]
    L.append(f"exclude 0x{pad_lo:X} 0x{elf.sym('bw_sandbox') + 256:X}")
    for n in ("bw_trig_mul_insn", "bw_trig_amo_insn", "bw_trig_fadd_insn", "bw_trig_rvc_insn", "bw_trig_illegal_insn"):
        L.append(f"exclude 0x{elf.sym(n):X} 0x{elf.sym(n) + 4:X}")
    L.append(f"exclude 0x{elf.sym('bw_trig_pad') + 4:X} 0x{elf.sym('bw_trig_pad') + 8:X}")
    open(a.out, "w").write("\n".join(L) + "\n")
    print(f"bw_expect: {len(funcs)} functions -> {a.out}")


if __name__ == "__main__":
    main()
