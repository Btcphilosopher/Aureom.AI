#!/usr/bin/env python3
"""Validate a BootWorks RTL run (JSON from sim/bootworks_tb) and render the boot report.

Checks, each reported PASS/FAIL (exit status 1 if any FAIL):
  load        image reached SRAM bank 0.. through the host port intact (BOOT_MODE protocol)
  reset       first retired instruction is at the reset vector 0x0 and is the first word of the image
  fetch       every instruction fetch on the fabric returned the image word; every retirement matches its fetch
  isa         the reference RV32I model agreed with the RTL on every retired instruction
  coverage    every function that must run did; instruction coverage reported
  signature   FW_STATUS / FW_VERSION / FW_HEARTBEAT / SCRATCH / mailbox / SRAM report CRC agree with each other
  integrity   the firmware did not change its own image
  outcomes    each test ended as the architecture audit predicts for the unmodified Albion RTL (unless --expect-fail)
"""
import argparse
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bwlib import OUTCOMES, parse_diag_header, crc32  # noqa: E402

BW_VERSION = 0x00950100
SIG_PASS, SIG_FAIL = 0xB007600D, 0xB007FA11

# What the audit of the Albion P90 RTL predicts (docs/00_ARCHITECTURE_AUDIT.md): everything PASSes except hardware that is
# absent (UNSUPPORTED, with the reason code) or host-dependent (SKIPPED).
EXPECTED_NON_PASS = {
    "ISA_M": ("UNSUPPORTED", 0xF101), "ISA_A": ("UNSUPPORTED", 0xF102), "ISA_C": ("UNSUPPORTED", 0xF103),
    "ISA_F": ("UNSUPPORTED", 0xF104), "CSR_ABSENT": ("UNSUPPORTED", 0xF105), "TIMER_IRQ": ("UNSUPPORTED", 0xF106),
    "BOOT_ROM": ("UNSUPPORTED", 0xF107), "UART": ("UNSUPPORTED", 0xF108), "DEBUG": ("UNSUPPORTED", 0xF109),
    "VECTOR": ("UNSUPPORTED", 0xF10A), "TENSOR": ("UNSUPPORTED", 0xF10B), "ACCEL_OTHER": ("UNSUPPORTED", 0xF10C),
    "HOSTMEM": ("SKIPPED", 0xF002),
}
FAILURE_ONLY_FUNCS = {"bw_early_trap", "bw_fatal", "bw_longjmp", "bw_fail", "bw_tmo", "memset", "memcpy",
                      "__mulsi3", "__udivsi3", "__umodsi3", "udivmod"}


def decode_live(st):
    if st >> 24 == 0xB1:
        stage, test, nf = (st >> 16) & 0xFF, (st >> 8) & 0xFF, st & 0xFF
        return stage, test, nf
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run_json")
    ap.add_argument("--bw-dir", required=True)
    ap.add_argument("--bin", required=True)
    ap.add_argument("--md")
    ap.add_argument("--log")
    ap.add_argument("--summary")
    ap.add_argument("--expect-fail", help="negative test: comma list of diag codes (hex) that MUST be the first failure; skips the all-pass profile")
    ap.add_argument("--label", default="")
    a = ap.parse_args()

    j = json.load(open(a.run_json))
    tests, diags, stages = parse_diag_header(os.path.join(a.bw_dir, "include", "bw_diag.h"))
    dtext = {c: (n, t) for n, c, t in diags}
    tname = [n for n, _, _ in tests]
    img = open(a.bin, "rb").read()
    rep = j["report"]
    results = rep.get("results", [])
    checks = []

    def chk(name, ok, detail):
        checks.append((name, bool(ok), detail))

    h = j["host"]
    chk("load", h["boot_mode_before_load"] and h["load_write_errors"] == 0 and h["load_verify_mismatches"] == 0 and h["halted_boot_mode"],
        f"BOOT_MODE before load, {len(img) // 4} words written+read back through the host port: {h['load_write_errors']} write errors, "
        f"{h['load_verify_mismatches']} mismatches; core halted back into BOOT_MODE: {h['halted_boot_mode']}")
    r = j["retire"]
    w0 = struct.unpack_from("<I", img, 0)[0]
    chk("reset", r["first_pc"] == 0 and r["first_insn"] == w0,
        f"first retired instruction: pc 0x{r['first_pc']:08X} word 0x{r['first_insn']:08X} (image word 0 = 0x{w0:08X}), {r['first_cycle'] and ''}"
        f"retired {r['first_cycle']} cycles into the run window")
    f = j["fetch"]
    deliberate = {0x20000000}
    unexpected_err = [p for p in f["error_pcs"] if p not in deliberate]
    chk("fetch", f["handshakes"] > 0 and f["image_mismatches"] == 0 and f["retire_vs_fetch_mismatches"] == 0 and not unexpected_err,
        f"{f['handshakes']} instruction fetches on fabric master 0: {f['image_mismatches']} differ from the image, {f['retire_vs_fetch_mismatches']} "
        f"retirements differ from their fetch, {len(f['error_pcs'])} fetch error(s) (deliberate: {', '.join(hex(p) for p in f['error_pcs']) or 'none'})")
    ref = j["reference_model"]
    chk("isa", ref["enabled"] and ref["checked"] > 0 and ref["mismatches"] == 0,
        f"reference RV32I+Zicsr model checked {ref['checked']} retired instructions against the RTL trace: {ref['mismatches']} mismatches")

    cov = j["coverage"]
    ran = {tname[t["id"]]: t["outcome"] for t in results}
    never = []
    for fn, hits in cov["milestones"].items():
        if hits:
            continue
        if fn in FAILURE_ONLY_FUNCS or fn.startswith("OUTLINED_FUNCTION_"):     # abort/failure paths; compiler-outlined helpers
            continue
        if fn.startswith("bw_test_") and ran.get(fn[8:]) == 3:            # SKIPPED test: its body legitimately did not run
            continue
        never.append(fn)
    pct = 100.0 * cov["hit"] / max(1, cov["words"])
    chk("coverage", not never, f"{cov['hit']}/{cov['words']} instruction words retired ({pct:.1f}%); required functions never entered: {never or 'none'}")

    nfail = (rep.get("counts", [0, 0, 0, 0, 0])[1] + rep.get("counts", [0, 0, 0, 0, 0])[2]) if rep.get("read") else -1
    mb = j["mailbox"]
    start = [m for m in mb if m[0] == 0xB0070001]
    summ = [m for m in mb if m[0] == 0xB0070002]
    run = j["run"]
    sig_ok = (run["end_reason"] == "completion signature" and rep.get("valid") and run["fw_status"] == rep["verdict"] and rep["verdict"] in (SIG_PASS, SIG_FAIL) and
              run["fw_version"] == BW_VERSION and rep["fw_version"] == BW_VERSION and run["heartbeat"] == rep["n_tests"] and
              run["scratch"] == ((nfail << 16) | rep["first_fail_diag"]) and sum(rep["counts"]) == rep["n_tests"] and
              len(start) == 1 and start[0][1] == BW_VERSION and len(summ) == 1 and summ[0][1] == rep["verdict"] and
              summ[0][2] == ((nfail << 16) | rep["counts"][0]) and summ[0][3] == rep["crc_stored"] == rep["crc_computed"])
    stalled = ""
    if run["end_reason"].startswith("TIMEOUT") and j["timeline"]:
        d = decode_live(j["timeline"][-1][1])
        if d and d[1] < len(tname):
            stalled = f"; HANG: FW_STATUS stalled in stage 0x{d[0]:02X}, test {d[1]} `{tname[d[1]]}` after {d[2]} failure(s) so far"
    chk("signature", sig_ok,
        f"FW_STATUS=0x{run['fw_status']:08X} FW_VERSION=0x{run['fw_version']:08X} HEARTBEAT={run['heartbeat']} SCRATCH=0x{run['scratch']:08X}; "
        f"SRAM report magic/CRC {'valid' if rep.get('valid') else 'INVALID'} (0x{rep['crc_stored']:08X}); mailbox: {len(start)} START + {len(summ)} SUMMARY record(s); end: {run['end_reason']}{stalled}")
    chk("integrity", h["image_changed_words"] == 0 and rep.get("stack_hwm", 1 << 30) <= 768,
        f"{h['image_changed_words']} image words changed after the run; peak stack {rep.get('stack_hwm')} B (limit 768 of 1024)")

    # per-test outcomes
    deviations = []
    expect_fail = {int(x, 16) for x in a.expect_fail.split(",")} if a.expect_fail else None
    if rep.get("read"):
        for t in results:
            n = tname[t["id"]]
            exp = EXPECTED_NON_PASS.get(n, ("PASS", 0))
            got = (OUTCOMES[t["outcome"]], t["diag"])
            if expect_fail is None and got != exp:
                deviations.append((n, exp, got))
    if expect_fail is None:
        chk("outcomes", rep.get("read") and not deviations,
            "every test ended as the architecture audit predicts" if not deviations else
            "; ".join(f"{n}: expected {e[0]} got {g[0]} diag 0x{g[1]:04X}" for n, e, g in deviations))
    else:
        first = rep.get("first_fail_diag", 0)
        chk("detects", first in expect_fail, f"first failing diagnostic 0x{first:04X} ({dtext.get(first, ('?', ''))[0]}); expected one of "
            f"{', '.join('0x%04X' % x for x in sorted(expect_fail))}")

    all_ok = all(ok for _, ok, _ in checks)

    # ------------------------------------------------------------ timeline -> per-test start cycle and duration
    tl = j["timeline"]
    starts = {}
    for cyc, st, hb in tl:
        d = decode_live(st)
        if d and d[0] != 0 and d[1] not in starts:        # stage 0 = early-boot milestones (0xB1000001..3), not a test
            starts[d[1]] = cyc
    order = sorted(starts.items(), key=lambda kv: kv[1])
    dur = {}
    for i, (tid, c0) in enumerate(order):
        c1 = order[i + 1][1] if i + 1 < len(order) else run["cycles"]
        dur[tid] = c1 - c0

    L = []
    L.append(f"# BootWorks boot report {a.label}".rstrip())
    L.append("")
    L.append(f"* RTL: SilicaFlux Albion `sf_albion_cloud_top` CONFIG {j['config']} - {j['banks']} SRAM banks x {j['bank_bytes'] // 1024} KiB")
    L.append(f"* Image: {j['image_bytes']} bytes, loaded through the host MMIO port in BOOT_MODE, read back and verified")
    L.append(f"* Run: {run['cycles']} cycles from CORE_CTRL.RUN to the completion signature (`{run['end_reason']}`)")
    L.append(f"* Verdict: **{'PASS' if rep.get('verdict') == SIG_PASS else 'FAIL' if rep.get('verdict') == SIG_FAIL else 'NO SIGNATURE'}** "
             f"(FW_STATUS `0x{run['fw_status']:08X}`) - " + (", ".join(f"{OUTCOMES[i]} {rep['counts'][i]}" for i in range(5)) if rep.get("read") else "report unreadable"))
    L.append("")
    L.append("## Host-side verification")
    L.append("")
    L.append("| check | result | detail |")
    L.append("|---|---|---|")
    for n, ok, d in checks:
        L.append(f"| {n} | {'PASS' if ok else '**FAIL**'} | {d} |")
    L.append("")
    L.append("## Self-test results (read back from SRAM through the host port)")
    L.append("")
    L.append("| id | test | outcome | diag | meaning | aux0 / aux1 / aux2 | start cycle | cycles |")
    L.append("|---|---|---|---|---|---|---|---|")
    for t in results:
        n = tname[t["id"]]
        dg = t["diag"]
        meaning = f"`{dtext[dg][0]}`: {dtext[dg][1]}" if dg in dtext else ""
        aux = " / ".join(f"0x{x:08X}" for x in t["aux"]) if dg else ""
        L.append(f"| {t['id']} | `{n}` | {OUTCOMES[t['outcome']]} | {('0x%04X' % dg) if dg else ''} | {meaning} | {aux} | {starts.get(t['id'], '')} | {dur.get(t['id'], '')} |")
    L.append("")
    L.append("## What executed on the CPU")
    L.append("")
    L.append(f"* {r['retired']} instructions retired, {r['traps']} traps taken (cause: count) - "
             + ", ".join(f"{(('interrupt 0x%X' % int(k)) if int(k) & 0x80000000 else int(k))}: {v}" for k, v in sorted(r['trap_causes'].items(), key=lambda kv: int(kv[0]))))
    L.append("* instruction classes retired: " + ", ".join(f"{k} {v}" for k, v in sorted(r["classes"].items(), key=lambda kv: -kv[1])))
    L.append(f"* function entry coverage and instruction coverage: {cov['hit']}/{cov['words']} words ({pct:.1f}%)")
    unrun = sorted(fn for fn, (words, hit) in cov["functions"].items() if words and hit == 0)
    L.append("* functions never executed (all are failure/abort paths or tests that were skipped by design): " + (", ".join(f"`{x}`" for x in unrun) or "none"))
    L.append("")
    open(a.md, "w").write("\n".join(L) + "\n") if a.md else None

    # ------------------------------------------------------------ console-style boot log
    if a.log:
        G = [f"BootWorks boot log - Albion CONFIG {j['config']}  ({run['cycles']} cycles; times are core cycles since CORE_CTRL.RUN)", ""]
        events = []
        for cyc, st, hb in tl:
            if st == 0xB1000001:
                events.append((cyc, "reset vector 0x00000000: first instruction fetched from SRAM, FW_STATUS = ENTRY (0xB1000001)"))
            elif st == 0xB1000002:
                events.append((cyc, ".data copied, .bss cleared, stack canary painted, trap vector installed (0xB1000002)"))
            elif st == 0xB1000003:
                events.append((cyc, "boot_main entered; hardware identified; peripherals initialised (0xB1000003)"))
        for tid, c0 in order:
            res = results[tid] if tid < len(results) else None
            if res:
                dg = res["diag"]
                extra = f"  diag 0x{dg:04X} {dtext[dg][0]}" if dg else ""
                events.append((c0, f"test {tid:2d} {tname[tid]:<14} -> {OUTCOMES[res['outcome']]}{extra}"))
        events.append((run["cycles"], f"completion signature FW_STATUS=0x{run['fw_status']:08X} ({'BOOT PASS' if run['fw_status'] == SIG_PASS else 'BOOT FAIL' if run['fw_status'] == SIG_FAIL else '?'}), "
                                      f"SCRATCH=0x{run['scratch']:08X}, mailbox SUMMARY posted"))
        for cyc, msg in sorted(events, key=lambda e: e[0]):
            G.append(f"[{cyc:>9}] {msg}")
        open(a.log, "w").write("\n".join(G) + "\n")

    summary = dict(label=a.label, config=j["config"], ok=all_ok, checks={n: ok for n, ok, _ in checks}, run_cycles=run["cycles"],
                   retired=r["retired"], counts=dict(zip(OUTCOMES, rep.get("counts", []))), first_fail_diag=rep.get("first_fail_diag"),
                   coverage_pct=round(pct, 1), deviations=[(n, e, g) for n, e, g in deviations])
    if a.summary:
        json.dump(summary, open(a.summary, "w"), indent=1)
    for n, ok, d in checks:
        print(f"  [{'PASS' if ok else 'FAIL'}] {n:<10} {d}")
    print(("BOOTWORKS CHECK PASS" if all_ok else "BOOTWORKS CHECK FAIL") + (f"  ({a.label})" if a.label else ""))
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
