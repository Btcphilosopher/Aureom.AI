#!/usr/bin/env python3
"""Render result tables (markdown) from the machine-readable run and mutation results, so documentation cannot drift from data.
usage: bw_summary.py runs <run_json>...   |   bw_summary.py mutants <mutation_results.json>"""
import json
import sys

OUT = ["PASS", "FAIL", "TIMEOUT", "SKIPPED", "UNSUPPORTED"]


def runs(paths):
    print("| run | SRAM | verdict | run cycles | instr. fetched / retired | reference-model mismatches | fetch-vs-image mismatches | "
          "PASS / UNSUPPORTED / SKIPPED / FAIL+TIMEOUT | instruction coverage |")
    print("|---|---|---|---|---|---|---|---|---|")
    for p in paths:
        j = json.load(open(p))
        r, rep, c = j["retire"], j["report"], j["coverage"]
        cnt = rep["counts"]
        name = p.split("run_")[-1].replace(".json", "")
        print(f"| `{name}` | {j['banks']} x {j['bank_bytes'] // 1024} KiB | **{'PASS' if rep['verdict'] == 0xB007600D else 'FAIL'}** "
              f"(`0x{rep['verdict']:08X}`) | {j['run']['cycles']:,} | {j['fetch']['handshakes']:,} / {r['retired']:,} | {j['reference_model']['mismatches']} | "
              f"{j['fetch']['image_mismatches'] + j['fetch']['retire_vs_fetch_mismatches']} | {cnt[0]} / {cnt[4]} / {cnt[3]} / {cnt[1] + cnt[2]} | "
              f"{100.0 * c['hit'] / max(1, c['words']):.1f} % |")


def mutants(path):
    res = json.load(open(path))
    nd = sum(r["ok"] for r in res)
    print(f"**{nd} of {len(res)} injected RTL defects were detected and attributed to the correct test and diagnostic code.**\n")
    print("| mutant | area | injected defect | detected | first evidence |")
    print("|---|---|---|---|---|")
    for r in res:
        ev = (r["evidence"][0] if r["evidence"] else "").replace("|", "/")
        print(f"| `{r['name']}` | {r['area']} | {r['desc']} | {'**yes**' if r['ok'] else 'NO'} | {ev} |")


if __name__ == "__main__":
    if sys.argv[1] == "runs":
        runs(sys.argv[2:])
    else:
        mutants(sys.argv[2])
