/* BootWorks - trap handling.
 *
 * Three behaviours, selected by state, never by guesswork:
 *   - machine external interrupt (mcause 0x8000000B): service the IRQ page (ISR below);
 *   - exception while a test has armed bw_catch(): record cause/epc/tval/mstatus and resume
 *     (this is how tests PROVOKE faults and check the RTL's trap behaviour);
 *   - any other exception: inside a test it aborts that test (longjmp to the runner, the
 *     test is reported FAIL with INT_UNEXPECTED_TRAP); outside a test it is fatal.
 */
#include "bw_internal.h"

bw_trapctl_t bw_tc;
bw_jmp_t     bw_test_ctx;

void bw_catch(uint32_t resume) {
  bw_tc.hit = 0; bw_tc.cause = 0; bw_tc.epc = 0; bw_tc.tval = 0; bw_tc.mstatus = 0;
  bw_tc.resume = resume;
  bw_tc.armed = 1;
}

uint32_t bw_caught(void) {
  bw_tc.armed = 0;
  return bw_tc.hit;
}

void bw_fatal(uint32_t cause, uint32_t epc) {
  BW_MGMT(ALBION_MGMT_FW_STATUS) = BW_ST_FATAL(cause);
  BW_MGMT(ALBION_MGMT_SCRATCH)   = epc;
  BW_MGMT(ALBION_MGMT_FW_ATTN)   = 1u;
  for (;;) __asm__ volatile("wfi");
}

/* Machine external interrupt service: acknowledge the sticky sources the running test asked
 * to acknowledge (irq_ack), remember what was pending, and mask anything that is still
 * pending afterwards so a source that does not clear cannot cause a re-trigger storm. */
static void irq_isr(uint32_t mepc) {
  uint32_t pend = BW_IRQ(ALBION_IRQ_PENDING);
  if (bw_tc.irq_count == 0u) { bw_tc.irq_epc = mepc; bw_tc.irq_mstatus = BW_CSR_R(mstatus); }
  bw_tc.irq_count++;
  bw_tc.irq_seen |= pend;
  BW_IRQ(ALBION_IRQ_CLEAR) = pend & bw_tc.irq_ack;
  uint32_t left = BW_IRQ(ALBION_IRQ_PENDING) & BW_IRQ(ALBION_IRQ_ENABLE);
  if (left) {
    bw_tc.irq_stuck |= left;
    BW_IRQ(ALBION_IRQ_ENABLE) = BW_IRQ(ALBION_IRQ_ENABLE) & ~left;
  }
}

uint32_t bw_trap_dispatch(bw_frame_t *f, uint32_t mcause, uint32_t mepc, uint32_t mtval) {
  if (mcause == MCAUSE_MEI) {
    irq_isr(mepc);
    return mepc;
  }
  if (mcause & 0x80000000u) {                 /* an interrupt this core is not documented to raise */
    bw_tc.irq_badcause = mcause;
    BW_CSR_W(mie, 0u);                        /* silence every enable so it cannot storm */
    return mepc;
  }
  if (bw_tc.armed && !(mcause & 0x80000000u)) {
    bw_tc.armed  = 0;
    bw_tc.hit++;
    bw_tc.cause  = mcause;
    bw_tc.epc    = mepc;
    bw_tc.tval   = mtval;
    bw_tc.mstatus = BW_CSR_R(mstatus);
    return (bw_tc.resume == BW_RESUME_RA) ? f->ra : mepc + 4u;
  }
  bw_tc.un_cause = mcause;
  bw_tc.un_epc   = mepc;
  bw_tc.un_tval  = mtval;
  if (bw_tc.in_test) bw_longjmp(&bw_test_ctx, 1);
  bw_fatal(mcause, mepc);
}
