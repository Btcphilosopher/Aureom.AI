/* BootWorks - boot orchestration for the SilicaFlux Albion ControlCore.
 *
 * Reset sequence (startup.S has already run steps 1-4):
 *   1. reset vector 0x0, FW_STATUS = ENTRY                       (startup.S)
 *   2. stack, .data, .bss, stack canary, trap vector             (startup.S)
 *   3. boot_main: report init, hardware identification + reset-state snapshot
 *   4. peripheral initialisation (interrupts masked, windows closed, telemetry running, RAS log clear)
 *   5. self-test table, in order, each bounded by cycle deadlines
 *   6. final report: FW_STATUS = PASS/FAIL signature, mailbox summary, CRC-protected report in SRAM
 * BootWorks never sets BOOT_LOCK: it is bring-up firmware, the host may halt it and read the report.
 */
#include "bw_internal.h"

/* the assembly and C sides must agree on these constants */
_Static_assert(BW_ST_ENTRY == 0xB1000001u && BW_ST_CRT_DONE == 0xB1000002u, "startup.S status constants");
_Static_assert(BW_STACK_CANARY == 0xC0DEC0DEu, "startup.S canary constant");
_Static_assert(sizeof(bw_frame_t) == 64u, "trap frame size is hard-coded in startup.S");
_Static_assert(sizeof(bw_jmp_t) == 56u, "jmp_buf size is hard-coded in startup.S");
_Static_assert(sizeof(bw_entry_t) == 32u, "entry state layout is hard-coded in startup.S");
_Static_assert(sizeof(bw_result_t) == 16u, "result layout");
_Static_assert(sizeof(bw_report_t) == (23u + 4u * BW_NUM_TESTS + 1u) * 4u, "report layout is mirrored by tools/bw_load_sequence.py");
_Static_assert(BW_NUM_TESTS < 0xFEu, "test id must fit in a byte below BW_T_NONE");

bw_entry_t g_entry;

/* Image trailer: size/crc are patched into the linked ELF by tools/bw_patch_image.py (never at run time). */
const bw_trailer_t bw_trailer __attribute__((section(".trailer"), used)) = { BW_TRAILER_MAGIC, 0u, 0u, BW_VERSION };

#define NONE BW_T_NONE

/* Execution order = BW_TEST_LIST order (the index IS the test id). prereq: the test is SKIPPED unless that test PASSed.
 * Stored as two parallel arrays (function pointers, prerequisites) - no per-entry id or padding. */
#define BW_TABLE(T) \
  T(CPU_ENTRY, NONE)  T(CPU_IDENT, NONE)   T(ISA_RV32I, NONE)  T(ISA_M, NONE) \
  T(ISA_A, NONE)      T(ISA_C, NONE)       T(ISA_F, NONE)       T(ISA_FENCE, NONE) \
  T(CSR_BASIC, NONE)  T(CSR_ABSENT, NONE) \
  T(TRAP_CAUSES, NONE) T(TRAP_RETURN, BW_T_TRAP_CAUSES) \
  T(CNT_CYCLE, NONE)  T(TIMER_IRQ, NONE)   T(POLL_TIMEOUT, NONE) \
  T(PLAT_ID, NONE)    T(PLAT_CONFIG, BW_T_PLAT_ID)  T(PLAT_FEATURES, BW_T_PLAT_ID) \
  T(BOOT_ROM, NONE)   T(UART, NONE)        T(DEBUG, NONE)       T(VECTOR, NONE) \
  T(TENSOR, NONE)     T(ACCEL_OTHER, NONE) T(HOSTMEM, NONE)     T(MAILBOX, BW_T_PLAT_ID) \
  T(REG_MGMT, BW_T_PLAT_ID) T(REG_IRQ, BW_T_PLAT_ID) T(REG_DMA, BW_T_PLAT_ID) \
  T(REG_PERM, BW_T_PLAT_ID) T(REG_TELEM, BW_T_PLAT_ID) T(REG_RAS, BW_T_PLAT_ID) \
  T(REG_FAULTS, BW_T_PLAT_CONFIG) \
  T(IMG_CRC, NONE)    T(BANK0_SWEEP, NONE) T(STACK, NONE) \
  T(MEM_DATABUS, BW_T_PLAT_CONFIG) T(MEM_ADDRBUS, BW_T_MEM_DATABUS) T(MEM_BANKSEL, BW_T_PLAT_CONFIG) \
  T(MEM_MARCH, BW_T_MEM_ADDRBUS) T(MEM_PATTERN, BW_T_MEM_MARCH) T(MEM_BYTE, BW_T_PLAT_CONFIG) \
  T(ECC_CE, BW_T_REG_RAS) T(ECC_UE, BW_T_ECC_CE) \
  T(DMA_IDLE, BW_T_REG_DMA) T(DMA_FILL, BW_T_DMA_IDLE) T(DMA_COPY, BW_T_DMA_FILL) \
  T(DMA_SIZES, BW_T_DMA_COPY) T(DMA_BADPARAM, BW_T_DMA_IDLE) T(DMA_ERRORS, BW_T_DMA_FILL) \
  T(DMA_FWBANK, BW_T_DMA_IDLE) T(DMA_PERM, BW_T_DMA_COPY) \
  T(IRQ_BASE, NONE)   T(IRQ_MASK, BW_T_REG_IRQ) T(IRQ_WFI, BW_T_DMA_FILL) \
  T(IRQ_TAKEN, BW_T_DMA_FILL) T(IRQ_SOURCES, BW_T_IRQ_MASK) T(IRQ_MULTI, BW_T_IRQ_TAKEN) \
  T(IMG_CRC_POST, BW_T_IMG_CRC) T(STACK_POST, BW_T_STACK)

#define BW_T_FN(n, pre)   bw_test_##n,
#define BW_T_PRE(n, pre)  (uint8_t)(pre),
static const bw_test_fn k_fn[BW_NUM_TESTS]      = { BW_TABLE(BW_T_FN) };
static const uint8_t    k_prereq[BW_NUM_TESTS]  = { BW_TABLE(BW_T_PRE) };
#undef BW_T_FN
#undef BW_T_PRE

/* Peripheral bring-up: after hardware identification and the reset-state snapshot, put every
 * supported peripheral into a known quiet state. */
static void periph_init(void) {
  BW_CSR_C(mstatus, MSTATUS_MIE);
  BW_CSR_C(mie, MIE_MEIE);
  BW_IRQ(ALBION_IRQ_ENABLE) = 0u;             /* interrupt sources masked until a test enables one */
  bw_irq_clear_all();
  bw_win_close_all();                          /* no permission window valid */
  BW_TELEM(ALBION_TELEM_CTRL) = 0u;            /* counters running */
  BW_RAS(ALBION_RAS_INJ_CTRL) = 0u;
  BW_RAS(ALBION_RAS_ERR_CLEAR) = 1u;           /* clean error log (counters are left alone) */
  BW_MGMT(ALBION_MGMT_FW_ATTN) = 0u;
}

void boot_main(void) {
  bw_status_set(BW_ST_MAIN);
  bw_hw_detect();
  bw_report_init();
  bw_mem_init();
  periph_init();
  bw_run_tests(k_fn, k_prereq, BW_NUM_TESTS);
  bw_report_finalize();
  for (;;) __asm__ volatile("wfi");            /* parked: host halts the core and reads the report */
}
