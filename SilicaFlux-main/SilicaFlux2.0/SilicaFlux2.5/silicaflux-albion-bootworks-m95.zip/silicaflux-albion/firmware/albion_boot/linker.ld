/* BootWorks linker script - SilicaFlux Albion ControlCore.
 *
 * The firmware owns the first 32 KiB of SRAM: SRAM bank 0 and bank 1 in ALBION_MIN / ALBION_CLOUD
 * (16 KiB banks), bank 0 alone in ALBION_HPC (32 KiB bank). The host loads the image at address 0
 * while the core is held in reset (any bank is host-writable in BOOT_MODE); the core resets to PC 0.
 * Banks above 32 KiB belong to the tests and are exercised destructively.
 *
 *   0x0000 +----------------------+
 *          | .text (reset vector) |  image area (IMG): host-loaded, read-only by convention
 *          |  + 256 B DMA sandbox |  zeros inside bank 0, target of the "DMA must not reach bank 0" test
 *          | .rodata              |
 *          | .trailer (16 B)      |  image size + CRC-32, patched after link by tools/bw_patch_image.py
 *          | .data  load image    |  initial values, copied to RAM by startup.S
 *   0x7000 +----------------------+
 *          | .data (run address)  |  RAM area, 2 KiB
 *          | .bss  (incl. report) |
 *   0x7800 +----------------------+
 *          | test scratch window  |  1 KiB, 1 KiB-aligned: the ONLY destructive-test area in the firmware banks
 *   0x7C00 +----------------------+
 *          | stack (1 KiB)        |  painted with a canary; guard words at the bottom
 *   0x8000 +----------------------+
 *
 * The split is fixed and every boundary is ASSERTed, so a growing image fails the link
 * instead of silently overlapping a test region.
 */
OUTPUT_ARCH(riscv)
ENTRY(_start)

/* The whole layout derives from ONE number, the top of the firmware-owned SRAM. Default 0x8000 (32 KiB). The GNU cross-check
 * build overrides it (--defsym=BW_FW_TOP_OVERRIDE=...) because GCC's output is larger; the firmware reads _stack_top at run
 * time (bw_fw_banks) so it adapts. Everything below is computed from it and every boundary is ASSERTed. */
BW_FW_TOP      = DEFINED(BW_FW_TOP_OVERRIDE) ? BW_FW_TOP_OVERRIDE : 0x00008000;
_stack_top     = BW_FW_TOP;
_stack_limit   = _stack_top - 0x400;        /* 1 KiB stack  */
_scratch_end   = _stack_limit;
_scratch_start = _scratch_end - 0x400;      /* 1 KiB test scratch window, 1 KiB aligned */
BW_RAM_BASE    = _scratch_start - 0x800;    /* 2 KiB .data/.bss/report */

SECTIONS
{
  .text 0x0 : {
    _text_start = .;
    KEEP(*(.text.start))
    . = ALIGN(256);
    bw_sandbox = .;                  /* 256 zero bytes in bank 0: DMA-denial target, restored after the test */
    . += 256;
    *(.text .text.*)
  }

  .rodata : ALIGN(4) {
    *(.rodata .rodata.* .srodata .srodata.*)
  }

  /* image trailer: 16 bytes after .rodata. size/CRC are patched into the ELF after linking (tools/bw_patch_image.py);
   * the CRC covers the WHOLE image [0, _image_end) with these 16 bytes taken as zero. */
  .trailer : ALIGN(4) {
    bw_image_trailer = .;
    KEEP(*(.trailer))
  }

  _data_lma = ALIGN(4);

  .data BW_RAM_BASE : AT(_data_lma) {
    _data_start = .;
    *(.data .data.* .sdata .sdata.*)
    . = ALIGN(4);
    _data_end = .;
  }
  _image_end = _data_lma + SIZEOF(.data);

  .bss (_data_end) (NOLOAD) : ALIGN(4) {
    _bss_start = .;
    *(.bss .bss.* .sbss .sbss.* COMMON)
    . = ALIGN(4);
    _bss_end = .;
  }

  /DISCARD/ : { *(.comment) *(.note*) *(.riscv.attributes) *(.eh_frame*) }
}

ASSERT(_start == 0x0, "reset vector (_start) must sit at address 0")
ASSERT(bw_sandbox + 256 <= 0x00004000, "DMA sandbox must lie inside SRAM bank 0 (16 KiB minimum)")
ASSERT(_image_end <= BW_RAM_BASE, "image (text+rodata+data copy+trailer) exceeds the image area below RAM")
ASSERT(_bss_end <= _scratch_start, "data+bss exceeds the RAM area below the test scratch window")
ASSERT((_scratch_start & 0x3FF) == 0, "scratch window must be 1 KiB aligned for the address-line test")
ASSERT((_stack_top & 0x3FFF) == 0, "firmware top must be a 16 KiB bank boundary")
