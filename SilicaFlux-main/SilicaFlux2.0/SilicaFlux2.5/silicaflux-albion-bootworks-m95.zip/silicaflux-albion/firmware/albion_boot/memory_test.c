/* BootWorks - SRAM self-tests.
 *
 * SAFETY RULE: BootWorks never writes memory it does not own. Destructive tests (data bus, address
 * bus, bank decode, March C-, patterns, byte/halfword stores, ECC injection) run ONLY on regions built
 * by bw_mem_init() from linker symbols:
 *     - the 2 KiB scratch window inside bank 0 (the only writable test area in bank 0),
 *     - the part of bank 0 above the linked 16 KiB, if the configuration has a bigger bank (ALBION_HPC),
 *     - every data bank 1..N-1 (BootWorks keeps no tenant data there).
 * Every region is checked against the code/data/bss and stack ranges before any test starts; a violation
 * is reported as INT_REGION_UNSAFE and no test touches memory. Code, rodata, .data and the stack are
 * covered by NON-destructive checks only: image CRC (before and after the destructive tests), a
 * read-only sweep of the firmware banks, and the stack canary.
 */
#include "bw_internal.h"

bw_region_t g_regions[BW_MAX_REGIONS];
uint32_t    g_nregions;

uint32_t bw_fw_banks(void)  { return (BW_SYM(_stack_top) + g_hw.bank_bytes - 1u) / g_hw.bank_bytes; }
uint32_t bw_ndata(void)     { uint32_t f = bw_fw_banks(); return g_hw.banks > f ? g_hw.banks - f : 0u; }
uint32_t bw_data_bank(uint32_t i) { return bw_fw_banks() + i; }
uint32_t bw_data_base(uint32_t i) { return bw_data_bank(i) * g_hw.bank_bytes; }

static int is_pow2(uint32_t v) { return v && !(v & (v - 1u)); }

static int region_safe(uint32_t base, uint32_t len) {
  uint32_t end = base + len;
  uint32_t fw_lo = 0u, fw_hi = BW_SYM(_scratch_start);             /* text, rodata, data, bss, report  */
  uint32_t st_lo = BW_SYM(_stack_limit), st_hi = BW_SYM(_stack_top);
  if (len == 0u || !is_pow2(len) || (base & (len - 1u))) return 0;  /* address-line test needs pow2, aligned */
  if (base < fw_hi && end > fw_lo) return 0;
  if (base < st_hi && end > st_lo) return 0;
  return 1;
}

void bw_mem_init(void) {
  uint32_t n = 0, ok = 1;
  g_regions[n].base = BW_SYM(_scratch_start); g_regions[n].bytes = BW_SYM(_scratch_end) - BW_SYM(_scratch_start); n++;
  for (uint32_t i = 0; i < bw_ndata() && n < BW_MAX_REGIONS; i++) {
    g_regions[n].base = bw_data_base(i); g_regions[n].bytes = g_hw.bank_bytes; n++;
  }
  for (uint32_t k = 0; k < n; k++)
    if (!region_safe(g_regions[k].base, g_regions[k].bytes)) ok = 0;
  g_nregions = ok ? n : 0u;
}

#define NEED_REGIONS() do { if (g_nregions == 0u) return BW_FAIL_R(BW_D_INT_REGION_UNSAFE, 0, 0, 0); } while (0)
#define W(base) ((volatile uint32_t *)(uintptr_t)(base))

/* =========================================================================== image integrity */

/* CRC-32 over the whole image [0, _image_end) with the 16 trailer bytes taken as zero (the same definition as
 * tools/bw_patch_image.py): code, sandbox, rodata and the .data load image are all covered. */
static bw_result_t crc_check(uint32_t diag_crc) {
  const volatile bw_trailer_t *t = (const volatile bw_trailer_t *)bw_image_trailer;
  uint32_t taddr = BW_SYM(bw_image_trailer), size = BW_SYM(_image_end);
  if (t->magic != BW_TRAILER_MAGIC || t->size != size)
    return BW_FAIL_R(BW_D_IMG_TRAILER, t->magic, BW_TRAILER_MAGIC, t->size);
  static const uint8_t zero16[16];
  uint32_t crc = bw_crc32((const void *)BW_SYM(_text_start), taddr, 0u);
  crc = bw_crc32(zero16, sizeof(zero16), crc);
  crc = bw_crc32((const void *)(taddr + sizeof(zero16)), size - taddr - (uint32_t)sizeof(zero16), crc);
  if (crc != t->crc) return BW_FAIL_R(diag_crc, crc, t->crc, size);
  return BW_PASS_A(crc, size, 0);
}

bw_result_t bw_test_IMG_CRC(void)      { return crc_check(BW_D_IMG_CRC); }
bw_result_t bw_test_IMG_CRC_POST(void) { return crc_check(BW_D_IMG_CRC_POST); }

/* Read-only: every word of the firmware banks must read without an access fault and without ECC events. */
bw_result_t bw_test_BANK0_SWEEP(void) {
  uint32_t ce0 = BW_RAS(ALBION_RAS_CE_COUNT), ue0 = BW_RAS(ALBION_RAS_UE_COUNT);
  volatile uint32_t sink = 0;
  uint32_t a;
  uint32_t fwbytes = bw_fw_banks() * g_hw.bank_bytes;
  for (a = 0; a < fwbytes; a += 4u) {
    bw_catch(BW_RESUME_SKIP);
    sink ^= *W(a);
    if (bw_caught()) return BW_FAIL_R(BW_D_MEM_B0_UE, bw_tc.tval, 0, bw_tc.cause);
  }
  (void)sink;
  uint32_t ce1 = BW_RAS(ALBION_RAS_CE_COUNT), ue1 = BW_RAS(ALBION_RAS_UE_COUNT);
  if (ue1 != ue0) return BW_FAIL_R(BW_D_MEM_B0_UE, BW_RAS(ALBION_RAS_ERR_ADDR), ue0, ue1);
  if (ce1 != ce0) return BW_FAIL_R(BW_D_MEM_B0_CE, BW_RAS(ALBION_RAS_ERR_ADDR), ce0, ce1);
  return BW_PASS_A(fwbytes, 0, 0);
}

/* =========================================================================== stack */

static bw_result_t stack_check(uint32_t post) {
  uint32_t sp, lo = BW_SYM(_stack_limit), hi = BW_SYM(_stack_top), a;
  __asm__ volatile("mv %0, sp" : "=r"(sp));
  if (!post && (sp & 15u)) return BW_FAIL_R(BW_D_STACK_ALIGN, sp, 0, sp & 15u);
  if (sp < lo + 16u || sp > hi) return BW_FAIL_R(post ? BW_D_STACK_GUARD_POST : BW_D_STACK_GUARD, sp, lo + 16u, hi);
  for (a = lo; a < lo + 16u; a += 4u) {                              /* guard words at the bottom */
    uint32_t v = *W(a);
    if (v != BW_STACK_CANARY) return BW_FAIL_R(post ? BW_D_STACK_GUARD_POST : BW_D_STACK_GUARD, a, BW_STACK_CANARY, v);
  }
  while (a < hi && *W(a) == BW_STACK_CANARY) a += 4u;               /* a = deepest word ever used */
  uint32_t used = hi - a;
  if (used > (hi - lo) * 3u / 4u) return BW_FAIL_R(BW_D_STACK_CANARY_FILL, used, (hi - lo) * 3u / 4u, hi - lo);
  return BW_PASS_A(used, hi - lo, sp);
}

bw_result_t bw_test_STACK(void)      { return stack_check(0u); }
bw_result_t bw_test_STACK_POST(void) { return stack_check(1u); }

/* SECDED masks a single stuck or weak bit: the CPU reads the CORRECTED data, so pattern tests alone would pass. Every
 * destructive memory test therefore also requires that the RAS correctable-error counter did not move while it ran. */
static bw_result_t guarded(bw_result_t (*body)(void)) {
  uint32_t ce0 = BW_RAS(ALBION_RAS_CE_COUNT);
  bw_result_t r = body();
  uint32_t ce1 = BW_RAS(ALBION_RAS_CE_COUNT);
  if (r.outcome == BW_PASS && ce1 != ce0) return BW_FAIL_R(BW_D_MEM_CE_MASKED, BW_RAS(ALBION_RAS_ERR_ADDR), ce0, ce1);
  return r;
}
#define GUARDED(NAME) bw_result_t bw_test_##NAME(void) { return guarded(NAME##_body); }

/* =========================================================================== data bus */

static bw_result_t MEM_DATABUS_body(void) {
  NEED_REGIONS();
  for (uint32_t k = 0; k < g_nregions; k++) {
    volatile uint32_t *w = W(g_regions[k].base);
    for (uint32_t p = 1; p != 0u; p <<= 1) {
      w[0] = p;  w[1] = ~p;                                          /* neighbour carries the complement */
      uint32_t v = w[0];
      if (v != p) return BW_FAIL_R(BW_D_MEM_DATABUS, g_regions[k].base, p, v);
      v = w[1];
      if (v != ~p) return BW_FAIL_R(BW_D_MEM_DATABUS, g_regions[k].base + 4u, ~p, v);
      w[0] = ~p;  w[1] = p;
      v = w[0];
      if (v != ~p) return BW_FAIL_R(BW_D_MEM_DATABUS, g_regions[k].base, ~p, v);
      v = w[1];
      if (v != p) return BW_FAIL_R(BW_D_MEM_DATABUS, g_regions[k].base + 4u, p, v);
    }
  }
  return BW_PASS_A(g_nregions, 0, 0);
}

/* =========================================================================== address bus (Barr) */

static bw_result_t MEM_ADDRBUS_body(void) {
  NEED_REGIONS();
  const uint32_t pattern = 0xAAAAAAAAu, anti = 0x55555555u;
  for (uint32_t k = 0; k < g_nregions; k++) {
    volatile uint32_t *w = W(g_regions[k].base);
    uint32_t nw = g_regions[k].bytes >> 2, off, t;
    for (off = 1; off < nw; off <<= 1) w[off] = pattern;
    w[0] = anti;                                                     /* stuck-HIGH / alias check */
    for (off = 1; off < nw; off <<= 1)
      if (w[off] != pattern) return BW_FAIL_R(BW_D_MEM_ADDR_HIGH, g_regions[k].base + 4u * off, pattern, w[off]);
    w[0] = pattern;
    for (t = 1; t < nw; t <<= 1) {                                   /* stuck-LOW / short check */
      w[t] = anti;
      if (w[0] != pattern) return BW_FAIL_R(BW_D_MEM_ADDR_LOW, g_regions[k].base + 4u * t, pattern, w[0]);
      for (off = 1; off < nw; off <<= 1)
        if (off != t && w[off] != pattern) return BW_FAIL_R(BW_D_MEM_ADDR_LOW, g_regions[k].base + 4u * t, pattern, w[off]);
      w[t] = pattern;
    }
  }
  return BW_PASS_A(g_nregions, 0, 0);
}

/* =========================================================================== bank decode */

static bw_result_t MEM_BANKSEL_body(void) {
  NEED_REGIONS();
  for (uint32_t k = 0; k < g_nregions; k++) {
    volatile uint32_t *w = W(g_regions[k].base);
    uint32_t n = g_regions[k].bytes >> 2;
    w[0] = 0xB0A00000u + k; w[n / 2u] = 0xB0B00000u + k; w[n - 1u] = 0xB0C00000u + k;
  }
  for (uint32_t k = 0; k < g_nregions; k++) {                        /* verify only after ALL tags are written */
    volatile uint32_t *w = W(g_regions[k].base);
    uint32_t n = g_regions[k].bytes >> 2, v;
    v = w[0];          if (v != 0xB0A00000u + k) return BW_FAIL_R(BW_D_MEM_BANK_ALIAS, g_regions[k].base, 0xB0A00000u + k, v);
    v = w[n / 2u];     if (v != 0xB0B00000u + k) return BW_FAIL_R(BW_D_MEM_BANK_ALIAS, g_regions[k].base + (n / 2u) * 4u, 0xB0B00000u + k, v);
    v = w[n - 1u];     if (v != 0xB0C00000u + k) return BW_FAIL_R(BW_D_MEM_BANK_ALIAS, g_regions[k].base + (n - 1u) * 4u, 0xB0C00000u + k, v);
  }
  return BW_PASS_A(g_nregions, 0, 0);
}

/* =========================================================================== March C- */

static bw_result_t MEM_MARCH_body(void) {
  NEED_REGIONS();
  for (uint32_t k = 0; k < g_nregions; k++) {
    volatile uint32_t *w = W(g_regions[k].base);
    uint32_t n = g_regions[k].bytes >> 2, i, v;
    for (i = 0; i < n; i++) w[i] = 0u;                               /* M0: up (w0) */
    for (i = 0; i < n; i++) {                                        /* M1: up (r0,w1) */
      v = w[i]; if (v != 0u) return BW_FAIL_R(BW_D_MEM_MARCH_E1, g_regions[k].base + 4u * i, 0u, v);
      w[i] = 0xFFFFFFFFu;
    }
    for (i = 0; i < n; i++) {                                        /* M2: up (r1,w0) */
      v = w[i]; if (v != 0xFFFFFFFFu) return BW_FAIL_R(BW_D_MEM_MARCH_E2, g_regions[k].base + 4u * i, 0xFFFFFFFFu, v);
      w[i] = 0u;
    }
    for (i = n; i-- > 0u;) {                                         /* M3: down (r0,w1) */
      v = w[i]; if (v != 0u) return BW_FAIL_R(BW_D_MEM_MARCH_E3, g_regions[k].base + 4u * i, 0u, v);
      w[i] = 0xFFFFFFFFu;
    }
    for (i = n; i-- > 0u;) {                                         /* M4: down (r1,w0) */
      v = w[i]; if (v != 0xFFFFFFFFu) return BW_FAIL_R(BW_D_MEM_MARCH_E4, g_regions[k].base + 4u * i, 0xFFFFFFFFu, v);
      w[i] = 0u;
    }
    for (i = 0; i < n; i++) {                                        /* M5: up (r0) */
      v = w[i]; if (v != 0u) return BW_FAIL_R(BW_D_MEM_MARCH_E5, g_regions[k].base + 4u * i, 0u, v);
    }
  }
  return BW_PASS_A(g_nregions, 0, 0);
}

/* =========================================================================== data patterns */

static uint32_t xs32(uint32_t s) { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }

static bw_result_t MEM_PATTERN_body(void) {
  NEED_REGIONS();
  for (uint32_t k = 0; k < g_nregions; k++) {
    volatile uint32_t *w = W(g_regions[k].base);
    uint32_t n = g_regions[k].bytes >> 2, i, v, e, s;
    for (uint32_t inv = 0; inv < 2u; inv++) {                        /* address-as-data, then its complement */
      uint32_t x = inv ? 0xFFFFFFFFu : 0u;
      for (i = 0; i < n; i++) w[i] = ((uint32_t)(uintptr_t)&w[i] ^ 0xA5C3E1F0u) ^ x;
      for (i = 0; i < n; i++) {
        e = ((uint32_t)(uintptr_t)&w[i] ^ 0xA5C3E1F0u) ^ x; v = w[i];
        if (v != e) return BW_FAIL_R(BW_D_MEM_PAT_ADDR, g_regions[k].base + 4u * i, e, v);
      }
    }
    for (uint32_t sw = 0; sw < 2u; sw++) {                           /* checkerboard, then inverse checkerboard */
      for (i = 0; i < n; i++) w[i] = ((i ^ sw) & 1u) ? 0xAAAAAAAAu : 0x55555555u;
      for (i = 0; i < n; i++) {
        e = ((i ^ sw) & 1u) ? 0xAAAAAAAAu : 0x55555555u; v = w[i];
        if (v != e) return BW_FAIL_R(BW_D_MEM_PAT_CHECKER, g_regions[k].base + 4u * i, e, v);
      }
    }
    s = 0x2545F491u ^ k;                                             /* pseudo-random fill, verified from the same seed */
    for (i = 0; i < n; i++) { s = xs32(s); w[i] = s; }
    s = 0x2545F491u ^ k;
    for (i = 0; i < n; i++) {
      s = xs32(s); v = w[i];
      if (v != s) return BW_FAIL_R(BW_D_MEM_PAT_PRBS, g_regions[k].base + 4u * i, s, v);
    }
  }
  return BW_PASS_A(g_nregions, 0, 0);
}

/* =========================================================================== byte / halfword stores */

/* Sub-word stores are read-modify-write inside the ECC bank; check lanes and neighbouring words. */
static bw_result_t byte_one(uint32_t base, uint32_t n, uint32_t idx) {
  volatile uint32_t *w = W(base);
  volatile uint8_t  *b = (volatile uint8_t *)(uintptr_t)(base + 4u * idx);
  volatile uint16_t *h = (volatile uint16_t *)(uintptr_t)(base + 4u * idx);
  uint32_t addr = base + 4u * idx, v;
  const uint32_t nl = 0xDEADBEEFu, nr = 0xCAFEF00Du;
  if (idx > 0u)      w[idx - 1u] = nl;
  if (idx + 1u < n)  w[idx + 1u] = nr;
  w[idx] = 0u;
  for (uint32_t lane = 0; lane < 4u; lane++) {
    b[lane] = (uint8_t)(0x11u * (lane + 1u));
    uint32_t e = 0u;
    for (uint32_t j = 0; j <= lane; j++) e |= (0x11u * (j + 1u)) << (8u * j);
    v = w[idx];
    if (v != e) return BW_FAIL_R(BW_D_MEM_BYTE_WRITE, addr + lane, e, v);
  }
  w[idx] = 0xFFFFFFFFu;
  h[0] = 0x1234u; h[1] = 0xABCDu;
  v = w[idx];
  if (v != 0xABCD1234u) return BW_FAIL_R(BW_D_MEM_HALF_WRITE, addr, 0xABCD1234u, v);
  if (idx > 0u && w[idx - 1u] != nl)     return BW_FAIL_R(BW_D_MEM_BYTE_NEIGHBOR, addr - 4u, nl, w[idx - 1u]);
  if (idx + 1u < n && w[idx + 1u] != nr) return BW_FAIL_R(BW_D_MEM_BYTE_NEIGHBOR, addr + 4u, nr, w[idx + 1u]);
  w[idx] = 0x80FF7F01u;
  {
    uint32_t a = addr, lb, lbu, lh, lhu;
    __asm__ volatile("lb %0, 2(%4)\n lbu %1, 3(%4)\n lh %2, 2(%4)\n lhu %3, 0(%4)"
                     : "=&r"(lb), "=&r"(lbu), "=&r"(lh), "=&r"(lhu) : "r"(a));
    if (lb != 0xFFFFFFFFu || lbu != 0x80u || lh != 0xFFFF80FFu || lhu != 0x7F01u)
      return BW_FAIL_R(BW_D_MEM_LOAD_EXT, addr, (lb << 24) ^ lbu, (lh << 16) ^ lhu);
  }
  w[idx] = 0u;
  return BW_PASS_R();
}

static bw_result_t MEM_BYTE_body(void) {
  NEED_REGIONS();
  for (uint32_t k = 0; k < g_nregions; k++) {
    uint32_t n = g_regions[k].bytes >> 2;
    uint32_t idx[3] = { 0u, n / 2u, n - 1u };
    for (uint32_t j = 0; j < 3u; j++) {
      bw_result_t r = byte_one(g_regions[k].base, n, idx[j]);
      if (r.outcome != BW_PASS) return r;
    }
  }
  return BW_PASS_A(g_nregions, 0, 0);
}

GUARDED(MEM_DATABUS)
GUARDED(MEM_ADDRBUS)
GUARDED(MEM_BANKSEL)
GUARDED(MEM_MARCH)
GUARDED(MEM_PATTERN)
GUARDED(MEM_BYTE)

/* =========================================================================== ECC (SECDED) via RAS injection */

#define ECC_WORD 5u
#define ECC_VAL  0x13579BDFu

static void ras_reset_log(void) { BW_RAS(ALBION_RAS_ERR_CLEAR) = 1u; bw_irq_clear_all(); }

static void inject(uint32_t bank, uint32_t word, uint32_t lo, uint32_t hi) {
  BW_RAS(ALBION_RAS_INJ_MASK_LO) = lo;
  BW_RAS(ALBION_RAS_INJ_MASK_HI) = hi;
  BW_RAS(ALBION_RAS_INJ_ADDR)    = word;
  BW_RAS(ALBION_RAS_INJ_CTRL)    = 1u | (bank << 4);          /* ARM: applied to the next full-word write to the word */
}

/* inject mask, write ECC_VAL, return 1 if the injector reports it fired */
static int inject_write(volatile uint32_t *p, uint32_t lo, uint32_t hi) {
  inject(bw_data_bank(0u), ECC_WORD, lo, hi);
  *p = ECC_VAL;
  return (BW_RAS(ALBION_RAS_INJ_CTRL) & 2u) != 0u;
}

bw_result_t bw_test_ECC_CE(void) {
  if (bw_ndata() < 1u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.banks);
  uint32_t addr = bw_data_base(0u) + 4u * ECC_WORD;
  volatile uint32_t *p = W(addr);
  uint32_t got, ce0, st;

  *p = ECC_VAL;
  ras_reset_log();
  ce0 = BW_RAS(ALBION_RAS_CE_COUNT);

  /* (a) one data bit flipped in the stored codeword: corrected, counted, logged, interrupt source set */
  if (!inject_write(p, 1u << 5, 0u)) return BW_FAIL_R(BW_D_ECC_INJ_NOHIT, addr, 1u, BW_RAS(ALBION_RAS_INJ_CTRL));
  bw_catch(BW_RESUME_SKIP);
  got = *p;
  if (bw_caught()) return BW_FAIL_R(BW_D_ECC_CE_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
  if (got != ECC_VAL) return BW_FAIL_R(BW_D_ECC_CE_DATA, addr, ECC_VAL, got);
  if (BW_RAS(ALBION_RAS_CE_COUNT) != ce0 + 1u) return BW_FAIL_R(BW_D_ECC_CE_COUNT, addr, ce0 + 1u, BW_RAS(ALBION_RAS_CE_COUNT));
  st = BW_RAS(ALBION_RAS_ERR_STATUS);
  if ((st & 1u) == 0u || ((st >> 4) & 0xFu) != 1u || BW_RAS(ALBION_RAS_ERR_ADDR) != addr ||
      BW_RAS(ALBION_RAS_ERR_SYNDROME) == 0u || (BW_RAS(ALBION_RAS_ERR_SOURCE) & 0xF3Fu) != bw_data_bank(0u))
    return BW_FAIL_R(BW_D_ECC_CE_LOG, BW_RAS(ALBION_RAS_ERR_ADDR), addr, (st << 16) | (BW_RAS(ALBION_RAS_ERR_SOURCE) & 0xFFFFu));
  if (!(BW_IRQ(ALBION_IRQ_PENDING) & ALBION_IRQ_ECC_CE)) return BW_FAIL_R(BW_D_ECC_CE_IRQ, BW_IRQ(ALBION_IRQ_PENDING), ALBION_IRQ_ECC_CE, 0);

  /* (b) a byte store to a word holding a correctable error reads it (corrected), merges and rewrites clean */
  *(volatile uint8_t *)(uintptr_t)addr = 0x11u;
  uint32_t ce1 = BW_RAS(ALBION_RAS_CE_COUNT);
  got = *p;
  if (got != ((ECC_VAL & ~0xFFu) | 0x11u)) return BW_FAIL_R(BW_D_ECC_RMW_HEAL, addr, (ECC_VAL & ~0xFFu) | 0x11u, got);
  if (BW_RAS(ALBION_RAS_CE_COUNT) != ce1) return BW_FAIL_R(BW_D_ECC_RMW_HEAL, addr, ce1, BW_RAS(ALBION_RAS_CE_COUNT));

  /* (c) every one of the 39 codeword bits (data and check bits, whatever the layout): single flip is corrected */
  for (uint32_t bit = 0; bit < 39u; bit++) {
    uint32_t lo = bit < 32u ? (1u << bit) : 0u, hi = bit >= 32u ? (1u << (bit - 32u)) : 0u;
    uint32_t c = BW_RAS(ALBION_RAS_CE_COUNT);
    if (!inject_write(p, lo, hi)) return BW_FAIL_R(BW_D_ECC_INJ_NOHIT, addr, bit, BW_RAS(ALBION_RAS_INJ_CTRL));
    got = *p;
    if (got != ECC_VAL || BW_RAS(ALBION_RAS_CE_COUNT) != c + 1u) return BW_FAIL_R(BW_D_ECC_CHECKBIT, bit, ECC_VAL, got);
  }
  *p = 0u;
  ras_reset_log();
  return BW_PASS_R();
}

bw_result_t bw_test_ECC_UE(void) {
  if (bw_ndata() < 1u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.banks);
  uint32_t addr = bw_data_base(0u) + 4u * ECC_WORD;
  volatile uint32_t *p = W(addr);
  uint32_t got, ue0, st;

  ras_reset_log();
  if (!inject_write(p, (1u << 3) | (1u << 20), 0u)) return BW_FAIL_R(BW_D_ECC_INJ_NOHIT, addr, 2u, BW_RAS(ALBION_RAS_INJ_CTRL));
  ras_reset_log();
  ue0 = BW_RAS(ALBION_RAS_UE_COUNT);
  bw_catch(BW_RESUME_SKIP);
  got = *p;
  (void)got;
  if (!bw_caught() || bw_tc.cause != 5u) return BW_FAIL_R(BW_D_ECC_UE_NOTRAP, addr, 5u, bw_tc.hit ? bw_tc.cause : 0xFFFFFFFFu);
  if (bw_tc.tval != addr) return BW_FAIL_R(BW_D_ECC_UE_TVAL, addr, addr, bw_tc.tval);
  if (BW_RAS(ALBION_RAS_UE_COUNT) != ue0 + 1u) return BW_FAIL_R(BW_D_ECC_UE_COUNT, addr, ue0 + 1u, BW_RAS(ALBION_RAS_UE_COUNT));
  st = BW_RAS(ALBION_RAS_ERR_STATUS);
  if ((st & 1u) == 0u || ((st >> 4) & 0xFu) != 2u || BW_RAS(ALBION_RAS_ERR_ADDR) != addr)
    return BW_FAIL_R(BW_D_ECC_UE_LOG, BW_RAS(ALBION_RAS_ERR_ADDR), addr, st);
  if (!(BW_IRQ(ALBION_IRQ_PENDING) & ALBION_IRQ_ECC_UE)) return BW_FAIL_R(BW_D_ECC_UE_IRQ, BW_IRQ(ALBION_IRQ_PENDING), ALBION_IRQ_ECC_UE, 0);

  /* a full-word write replaces the codeword: the word must read back clean, no further events */
  *p = ECC_VAL;
  bw_catch(BW_RESUME_SKIP);
  got = *p;
  if (bw_caught() || got != ECC_VAL || BW_RAS(ALBION_RAS_UE_COUNT) != ue0 + 1u)
    return BW_FAIL_R(BW_D_ECC_UE_RECOVER, addr, ECC_VAL, got);
  *p = 0u;
  ras_reset_log();
  return BW_PASS_R();
}
