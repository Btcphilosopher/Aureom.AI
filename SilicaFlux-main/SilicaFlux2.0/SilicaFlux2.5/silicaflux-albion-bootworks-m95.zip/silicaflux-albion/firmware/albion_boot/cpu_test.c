/* BootWorks - CPU, CSR, trap, counter and timeout self-tests.
 *
 * Independent reference: the expected values of every ISA check are C constant expressions folded by
 * the HOST compiler at build time, while the instruction under test is emitted verbatim with
 * inline asm. An instruction is therefore never compared against itself.
 */
#include "bw_internal.h"

/* =========================================================================== reset entry */

bw_result_t bw_test_CPU_ENTRY(void) {
  if (g_entry.mstatus != 0x1800u) return BW_FAIL_R(BW_D_CPU_ENTRY_MSTATUS, 0, 0x1800u, g_entry.mstatus);
  if (g_entry.mie)     return BW_FAIL_R(BW_D_CPU_ENTRY_MIE, 0, 0, g_entry.mie);
  if (g_entry.mepc)    return BW_FAIL_R(BW_D_CPU_ENTRY_MEPC, 0, 0, g_entry.mepc);
  if (g_entry.mcause)  return BW_FAIL_R(BW_D_CPU_ENTRY_MCAUSE, 0, 0, g_entry.mcause);
  if (g_entry.mtvec)   return BW_FAIL_R(BW_D_CPU_ENTRY_MTVEC, 0, 0, g_entry.mtvec);
  if (g_entry.mhartid) return BW_FAIL_R(BW_D_CPU_ENTRY_HARTID, 0, 0, g_entry.mhartid);
  if (g_entry.mcycle > 400u) return BW_FAIL_R(BW_D_CPU_ENTRY_LATE, 0, 400u, g_entry.mcycle);
  return BW_PASS_A(g_entry.mcycle, g_entry.minstret, 0);
}

/* =========================================================================== RV32I instruction checks */

typedef struct {
  uint32_t a, b;
  uint32_t add, sub, and_, or_, xor_, sll, srl, sra, slt, sltu;                 /* register-register */
  uint32_t addi_m1, addi_7ff, andi, ori, xori, slti, sltiu, slli, srli, srai;   /* register-immediate */
  uint32_t br;                                                                    /* beq bne blt bge bltu bgeu */
} isa_row_t;

#define S(x) ((int32_t)(x##u))
#define ISA_ROWS(R) \
  R(0x7FFFFFFF, 0x00000001) R(0x80000000, 0xFFFFFFFF) R(0x12345678, 0xDEADBEEF) \
  R(0xA5A5A5A5, 0xA5A5A5A5)   /* shifts 1 / 31 / 15 / 5, overflow, signs, and EQUAL operands (>=, <=, ==, zero results) */
#define ISA_ROW(a, b) { a##u, b##u,                                                              \
  (uint32_t)(a##u + b##u), (uint32_t)(a##u - b##u), a##u & b##u, a##u | b##u, a##u ^ b##u,        \
  (uint32_t)(a##u << (b##u & 31u)), a##u >> (b##u & 31u), (uint32_t)(S(a) >> (b##u & 31u)),        \
  (uint32_t)(S(a) < S(b)), (uint32_t)(a##u < b##u),                                                \
  (uint32_t)(a##u + 0xFFFFFFFFu), (uint32_t)(a##u + 0x7FFu), a##u & 0xFFFFFF0Fu, a##u | 0x555u,    \
  ~a##u, (uint32_t)(S(a) < -1), (uint32_t)(a##u < 0xFFFFFFFFu),                                    \
  (uint32_t)(a##u << 5), a##u >> 5, (uint32_t)(S(a) >> 5),                                         \
  (uint32_t)(((a##u == b##u) ? 1u : 0u) | ((a##u != b##u) ? 2u : 0u) | ((S(a) < S(b)) ? 4u : 0u) | \
             ((S(a) >= S(b)) ? 8u : 0u) | ((a##u < b##u) ? 16u : 0u) | ((a##u >= b##u) ? 32u : 0u)) },

static const isa_row_t k_rows[] = { ISA_ROWS(ISA_ROW) };
#define NROWS (sizeof(k_rows) / sizeof(k_rows[0]))

#define CHK_RR(op, id, field, diag) do {                                              \
    __asm__ volatile(op " %0, %1, %2" : "=r"(x) : "r"(a), "r"(b));                  \
    if (x != r->field) return BW_FAIL_R(diag, (i << 8) | (id), r->field, x); } while (0)
#define CHK_RI(op, imm, id, field, diag) do {                                         \
    __asm__ volatile(op " %0, %1, " #imm : "=r"(x) : "r"(a));                       \
    if (x != r->field) return BW_FAIL_R(diag, (i << 8) | (id), r->field, x); } while (0)
#define CHK_BR(op, bit) do {                                                          \
    uint32_t t_;                                                                      \
    __asm__ volatile("li %0, 1\n " op " %1, %2, 1f\n li %0, 0\n 1:" : "=&r"(t_) : "r"(a), "r"(b)); \
    if (t_ != ((r->br >> (bit)) & 1u)) return BW_FAIL_R(BW_D_ISA_BRANCH, (i << 8) | (bit), (r->br >> (bit)) & 1u, t_); } while (0)

bw_result_t bw_test_ISA_RV32I(void) {
  for (uint32_t i = 0; i < NROWS; i++) {
    const isa_row_t *r = &k_rows[i];
    uint32_t a = r->a, b = r->b, x;
    CHK_RR("add", 0, add, BW_D_ISA_ARITH);   CHK_RR("sub", 1, sub, BW_D_ISA_ARITH);
    CHK_RR("and", 2, and_, BW_D_ISA_ARITH);  CHK_RR("or", 3, or_, BW_D_ISA_ARITH);
    CHK_RR("xor", 4, xor_, BW_D_ISA_ARITH);
    CHK_RR("sll", 5, sll, BW_D_ISA_SHIFT);   CHK_RR("srl", 6, srl, BW_D_ISA_SHIFT);
    CHK_RR("sra", 7, sra, BW_D_ISA_SHIFT);
    CHK_RR("slt", 8, slt, BW_D_ISA_CMP);     CHK_RR("sltu", 9, sltu, BW_D_ISA_CMP);
    CHK_RI("addi", -1, 10, addi_m1, BW_D_ISA_ARITH);   CHK_RI("addi", 2047, 11, addi_7ff, BW_D_ISA_ARITH);
    CHK_RI("andi", -241, 12, andi, BW_D_ISA_ARITH);    CHK_RI("ori", 1365, 13, ori, BW_D_ISA_ARITH);
    CHK_RI("xori", -1, 14, xori, BW_D_ISA_ARITH);
    CHK_RI("slti", -1, 15, slti, BW_D_ISA_CMP);        CHK_RI("sltiu", -1, 16, sltiu, BW_D_ISA_CMP);
    CHK_RI("slli", 5, 17, slli, BW_D_ISA_SHIFT);       CHK_RI("srli", 5, 18, srli, BW_D_ISA_SHIFT);
    CHK_RI("srai", 5, 19, srai, BW_D_ISA_SHIFT);
    CHK_BR("beq", 0);  CHK_BR("bne", 1);  CHK_BR("blt", 2);
    CHK_BR("bge", 3);  CHK_BR("bltu", 4); CHK_BR("bgeu", 5);
  }
  {   /* lui / auipc */
    uint32_t u, p0, p1;
    __asm__ volatile("lui %0, 0x12345" : "=r"(u));
    if (u != 0x12345000u) return BW_FAIL_R(BW_D_ISA_UPPER, 0, 0x12345000u, u);
    __asm__ volatile("auipc %0, 0\n auipc %1, 1" : "=r"(p0), "=r"(p1));
    if (p1 - p0 != 0x1004u) return BW_FAIL_R(BW_D_ISA_UPPER, 1, 0x1004u, p1 - p0);
  }
  {   /* jal: link = address after the jal, target skips one instruction */
    uint32_t link, flag, pc0;
    __asm__ volatile("li %1, 0\n auipc %2, 0\n jal %0, 1f\n li %1, 1\n 1:"
                     : "=&r"(link), "=&r"(flag), "=&r"(pc0));
    if (flag != 0u || link != pc0 + 8u) return BW_FAIL_R(BW_D_ISA_JUMP, 0, pc0 + 8u, link);
  }
  {   /* jalr: link = address after the jalr, bit 0 of the target is cleared */
    uint32_t link, flag, pc0, tmp;
    __asm__ volatile("li %1, 0\n auipc %2, 0\n addi %3, %2, 17\n jalr %0, 0(%3)\n li %1, 1\n"
                     : "=&r"(link), "=&r"(flag), "=&r"(pc0), "=&r"(tmp));
    if (flag != 0u || link != pc0 + 12u) return BW_FAIL_R(BW_D_ISA_JUMP, 1, pc0 + 12u, link);
  }
  {   /* x0 is hard-wired to zero */
    uint32_t z;
    __asm__ volatile("addi x0, x0, 5\n mv %0, x0" : "=r"(z));
    if (z != 0u) return BW_FAIL_R(BW_D_ISA_X0, 0, 0, z);
  }
  {   /* loads / stores in the scratch window: sign/zero extension and sub-word stores */
    volatile uint32_t *w = (volatile uint32_t *)(BW_SYM(_scratch_start) + 0x40u);
    uint32_t base = (uint32_t)(uintptr_t)w, v;
    *w = 0x80FF7F01u;
    __asm__ volatile("lb %0, 0(%1)" : "=r"(v) : "r"(base)); if (v != 0x00000001u) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 0, 0x00000001u, v);
    __asm__ volatile("lb %0, 2(%1)" : "=r"(v) : "r"(base)); if (v != 0xFFFFFFFFu) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 1, 0xFFFFFFFFu, v);
    __asm__ volatile("lb %0, 3(%1)" : "=r"(v) : "r"(base)); if (v != 0xFFFFFF80u) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 2, 0xFFFFFF80u, v);
    __asm__ volatile("lbu %0, 3(%1)" : "=r"(v) : "r"(base)); if (v != 0x00000080u) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 3, 0x80u, v);
    __asm__ volatile("lh %0, 2(%1)" : "=r"(v) : "r"(base)); if (v != 0xFFFF80FFu) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 4, 0xFFFF80FFu, v);
    __asm__ volatile("lhu %0, 2(%1)" : "=r"(v) : "r"(base)); if (v != 0x000080FFu) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 5, 0x80FFu, v);
    __asm__ volatile("lh %0, 0(%1)" : "=r"(v) : "r"(base)); if (v != 0x00007F01u) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 6, 0x7F01u, v);
    __asm__ volatile("sb %1, 1(%0)" :: "r"(base), "r"(0x5Au) : "memory");
    __asm__ volatile("sh %1, 2(%0)" :: "r"(base), "r"(0xBEEFu) : "memory");
    if (*w != 0xBEEF5A01u) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 7, 0xBEEF5A01u, *w);
    __asm__ volatile("sw %1, 0(%0)" :: "r"(base), "r"(0x01234567u) : "memory");
    __asm__ volatile("lw %0, 0(%1)" : "=r"(v) : "r"(base)); if (v != 0x01234567u) return BW_FAIL_R(BW_D_ISA_LOADSTORE, 8, 0x01234567u, v);
  }
  return BW_PASS_A(NROWS, 0, 0);
}

bw_result_t bw_test_ISA_FENCE(void) {
  bw_catch(BW_RESUME_SKIP);
  __asm__ volatile("fence\n .word 0x0000100F\n fence rw, rw" ::: "memory");   /* fence; fence.i; fence rw,rw */
  if (bw_caught()) return BW_FAIL_R(BW_D_ISA_FENCE_TRAP, bw_tc.cause, bw_tc.epc, bw_tc.tval);
  return BW_PASS_R();
}

/* =========================================================================== CSRs */

bw_result_t bw_test_CSR_BASIC(void) {
  static const uint32_t pat[] = { 0u, 0xFFFFFFFFu, 0xA5A5A5A5u, 0x5A5A5A5Au, 0x80000000u, 1u };
  uint32_t v, rd;
  for (uint32_t i = 0; i < sizeof(pat) / sizeof(pat[0]); i++) {
    BW_CSR_W(mscratch, pat[i]);
    v = BW_CSR_R(mscratch);
    if (v != pat[i]) return BW_FAIL_R(BW_D_CSR_MSCRATCH, i, pat[i], v);
  }
  {   /* mtvec is direct-mode only: low two bits read as zero. Restore the live vector immediately. */
    uint32_t old = BW_CSR_R(mtvec);
    BW_CSR_W(mtvec, 0x00001003u);
    v = BW_CSR_R(mtvec);
    BW_CSR_W(mtvec, old);
    if (v != 0x00001000u) return BW_FAIL_R(BW_D_CSR_MTVEC_WARL, 0, 0x1000u, v);
  }
  BW_CSR_W(mepc, 0x00001003u);
  v = BW_CSR_R(mepc);
  if (v != 0x00001000u) return BW_FAIL_R(BW_D_CSR_MEPC_ALIGN, 0, 0x1000u, v);

  BW_CSR_W(mscratch, 0xF0F0F0F0u);
  __asm__ volatile("csrrs %0, mscratch, %1" : "=r"(rd) : "r"(0x0000FF00u));
  v = BW_CSR_R(mscratch);
  if (rd != 0xF0F0F0F0u || v != 0xF0F0FFF0u) return BW_FAIL_R(BW_D_CSR_RMW, 0, 0xF0F0FFF0u, v);
  __asm__ volatile("csrrc %0, mscratch, %1" : "=r"(rd) : "r"(0x000000F0u));
  v = BW_CSR_R(mscratch);
  if (rd != 0xF0F0FFF0u || v != 0xF0F0FF00u) return BW_FAIL_R(BW_D_CSR_RMW, 1, 0xF0F0FF00u, v);
  __asm__ volatile("csrrw %0, mscratch, %1" : "=r"(rd) : "r"(0x13572468u));
  v = BW_CSR_R(mscratch);
  if (rd != 0xF0F0FF00u || v != 0x13572468u) return BW_FAIL_R(BW_D_CSR_RMW, 2, 0x13572468u, v);
  __asm__ volatile("csrrwi %0, mscratch, 21" : "=r"(rd));
  v = BW_CSR_R(mscratch);
  if (rd != 0x13572468u || v != 21u) return BW_FAIL_R(BW_D_CSR_RMW, 3, 21u, v);
  __asm__ volatile("csrrsi %0, mscratch, 10" : "=r"(rd));
  v = BW_CSR_R(mscratch);
  if (rd != 21u || v != 31u) return BW_FAIL_R(BW_D_CSR_RMW, 4, 31u, v);
  __asm__ volatile("csrrci %0, mscratch, 5" : "=r"(rd));
  v = BW_CSR_R(mscratch);
  if (rd != 31u || v != 26u) return BW_FAIL_R(BW_D_CSR_RMW, 5, 26u, v);
  BW_CSR_W(mscratch, 0u);

  /* mstatus: MIE and MPIE writable, MPP hard-wired to machine (11). IRQ.ENABLE is 0, so setting MIE is safe. */
  BW_CSR_S(mstatus, MSTATUS_MIE | MSTATUS_MPIE);
  v = BW_CSR_R(mstatus);
  if ((v & 0x1888u) != 0x1888u) return BW_FAIL_R(BW_D_CSR_MSTATUS, 0, 0x1888u, v);
  BW_CSR_C(mstatus, 0x1888u);
  v = BW_CSR_R(mstatus);
  if ((v & 0x1888u) != 0x1800u) return BW_FAIL_R(BW_D_CSR_MSTATUS, 1, 0x1800u, v);

  BW_CSR_W(mie, 0xFFFFFFFFu);
  v = BW_CSR_R(mie);
  BW_CSR_W(mie, 0u);
  if (v != MIE_MEIE) return BW_FAIL_R(BW_D_CSR_MIE_MASK, 0, MIE_MEIE, v);

  BW_CSR_W(mip, 0xFFFFFFFFu);
  v = BW_CSR_R(mip);
  if (v != 0u) return BW_FAIL_R(BW_D_CSR_MIP_RO, 0, 0u, v);

  bw_catch(BW_RESUME_SKIP);
  (void)bw_trig_csr_write();
  if (!bw_caught() || bw_tc.cause != 2u) return BW_FAIL_R(BW_D_CSR_RO_WRITE, bw_tc.hit, 2u, bw_tc.cause);

  {   /* user-level aliases read the same counters; both reads in one asm block so the distance is exact */
    uint32_t c0, c1, i0, i1;
    __asm__ volatile("csrr %0, cycle\n csrr %1, mcycle" : "=r"(c0), "=r"(c1));
    if (c1 - c0 == 0u || c1 - c0 > 64u) return BW_FAIL_R(BW_D_CSR_ALIAS, 0, c0, c1);
    __asm__ volatile("csrr %0, instret\n csrr %1, minstret" : "=r"(i0), "=r"(i1));
    if (i1 - i0 != 1u) return BW_FAIL_R(BW_D_CSR_ALIAS, 1, i0, i1);
  }
  return BW_PASS_R();
}

/* =========================================================================== traps */

enum { A_NONE, A_UNDEC, A_SCR1, A_SCR2, A_PAD2 };
enum { TV_ZERO, TV_PC, TV_ARG, TV_INSN };
enum { EP_INSN, EP_ARG };

typedef struct {
  uint32_t (*fn)(uint32_t);
  const void *insn;
  uint8_t arg, cause, tval, epc, resume;
  uint16_t dc, ds;                          /* diag: wrong/missing trap or cause; wrong mepc/mtval */
} tcase_t;

#define TC(fn_, insn_, arg_, cause_, tv_, ep_, rs_, dc_, ds_) { fn_, insn_, arg_, cause_, tv_, ep_, rs_, dc_, ds_ }
static const tcase_t k_tc[] = {
  TC(bw_trig_ecall,   bw_trig_ecall_insn,   A_NONE,  11, TV_ZERO, EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_ECALL_CAUSE, BW_D_TRAP_ECALL_STATE),
  TC(bw_trig_ebreak,  bw_trig_ebreak_insn,  A_NONE,   3, TV_PC,   EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_EBREAK_CAUSE, BW_D_TRAP_EBREAK_STATE),
  TC(bw_trig_illegal, bw_trig_illegal_insn, A_NONE,   2, TV_INSN, EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_ILLEGAL_CAUSE, BW_D_TRAP_ILLEGAL_STATE),
  TC(bw_trig_jalr,    bw_trig_jalr_insn,    A_PAD2,   0, TV_ARG,  EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_IMIS_CAUSE, BW_D_TRAP_IMIS_STATE),
  TC(bw_trig_jump,    bw_trig_jump_insn,    A_UNDEC,  1, TV_ARG,  EP_ARG,  BW_RESUME_RA,   BW_D_TRAP_IFAULT_CAUSE, BW_D_TRAP_IFAULT_STATE),
  TC(bw_trig_lw,      bw_trig_lw_insn,      A_SCR1,   4, TV_ARG,  EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_LMIS_CAUSE, BW_D_TRAP_LMIS_STATE),
  TC(bw_trig_lw,      bw_trig_lw_insn,      A_UNDEC,  5, TV_ARG,  EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_LFAULT_CAUSE, BW_D_TRAP_LFAULT_STATE),
  TC(bw_trig_sw,      bw_trig_sw_insn,      A_SCR2,   6, TV_ARG,  EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_SMIS_CAUSE, BW_D_TRAP_SMIS_STATE),
  TC(bw_trig_sw,      bw_trig_sw_insn,      A_UNDEC,  7, TV_ARG,  EP_INSN, BW_RESUME_SKIP, BW_D_TRAP_SFAULT_CAUSE, BW_D_TRAP_SFAULT_STATE),
};
#undef TC
extern char bw_trig_pad[];

static uint32_t trap_arg(uint32_t kind) {
  switch (kind) {
    case A_UNDEC: return BW_UNDECODED_ADDR;
    case A_SCR1:  return BW_SYM(_scratch_start) + 0x81u;     /* misaligned, inside the scratch window */
    case A_SCR2:  return BW_SYM(_scratch_start) + 0x82u;
    case A_PAD2:  return BW_SYM(bw_trig_pad) + 2u;
    default:      return 0u;
  }
}

bw_result_t bw_test_TRAP_CAUSES(void) {
  for (uint32_t i = 0; i < sizeof(k_tc) / sizeof(k_tc[0]); i++) {
    const tcase_t *c = &k_tc[i];
    uint32_t arg = trap_arg(c->arg);
    bw_catch(c->resume);
    (void)c->fn(arg);
    uint32_t hit = bw_caught();
    uint32_t dc = c->dc;
    if (!hit || bw_tc.cause != c->cause) return BW_FAIL_R(dc, hit ? bw_tc.cause : 0xFFFFFFFFu, c->cause, bw_tc.epc);
    uint32_t want_epc = (c->epc == EP_ARG) ? arg : BW_SYM(c->insn);
    uint32_t want_tv = c->tval == TV_ZERO ? 0u : c->tval == TV_PC ? bw_tc.epc : c->tval == TV_ARG ? arg : 0xFFFFFFFFu;
    if (bw_tc.epc != want_epc) return BW_FAIL_R(c->ds, bw_tc.epc, want_epc, bw_tc.tval);
    if (bw_tc.tval != want_tv) return BW_FAIL_R(c->ds, bw_tc.tval, want_tv, bw_tc.epc);
  }
  return BW_PASS_A(sizeof(k_tc) / sizeof(k_tc[0]), 0, 0);
}

bw_result_t bw_test_TRAP_RETURN(void) {
  uint32_t after;
  /* entry with MIE = 1: handler must see MIE=0, MPIE=1; after mret: MIE=1 again, MPIE=1 */
  BW_CSR_S(mstatus, MSTATUS_MIE);
  bw_catch(BW_RESUME_SKIP);
  (void)bw_trig_ecall(0u);
  after = BW_CSR_R(mstatus);
  BW_CSR_C(mstatus, MSTATUS_MIE | MSTATUS_MPIE);
  if (!bw_caught()) return BW_FAIL_R(BW_D_TRAP_MRET_PC, 0, 1u, 0);
  if ((bw_tc.mstatus & (MSTATUS_MIE | MSTATUS_MPIE)) != MSTATUS_MPIE)
    return BW_FAIL_R(BW_D_TRAP_MSTATUS_ENTRY, 0, MSTATUS_MPIE, bw_tc.mstatus & (MSTATUS_MIE | MSTATUS_MPIE));
  if ((after & (MSTATUS_MIE | MSTATUS_MPIE)) != (MSTATUS_MIE | MSTATUS_MPIE))
    return BW_FAIL_R(BW_D_TRAP_MSTATUS_MRET, 0, MSTATUS_MIE | MSTATUS_MPIE, after & (MSTATUS_MIE | MSTATUS_MPIE));
  /* entry with MIE = 0: MPIE must read back 0 inside the handler; mret leaves MIE=0 and sets MPIE=1 */
  bw_catch(BW_RESUME_SKIP);
  (void)bw_trig_ecall(0u);
  after = BW_CSR_R(mstatus);
  if (!bw_caught()) return BW_FAIL_R(BW_D_TRAP_MRET_PC, 1, 1u, 0);
  if ((bw_tc.mstatus & (MSTATUS_MIE | MSTATUS_MPIE)) != 0u)
    return BW_FAIL_R(BW_D_TRAP_MSTATUS_ENTRY, 1, 0, bw_tc.mstatus & (MSTATUS_MIE | MSTATUS_MPIE));
  if ((after & (MSTATUS_MIE | MSTATUS_MPIE)) != MSTATUS_MPIE)
    return BW_FAIL_R(BW_D_TRAP_MSTATUS_MRET, 1, MSTATUS_MPIE, after & (MSTATUS_MIE | MSTATUS_MPIE));
  BW_CSR_C(mstatus, MSTATUS_MPIE);
  return BW_PASS_R();
}

/* =========================================================================== counters and timer */

bw_result_t bw_test_CNT_CYCLE(void) {
  uint32_t c0 = bw_cycles();
  for (volatile uint32_t k = 0; k < 20u; k++) { }
  uint32_t c1 = bw_cycles();
  if (c1 == c0) return BW_FAIL_R(BW_D_CNT_MCYCLE_STUCK, 0, c0, c1);

  uint32_t d = bw_isa_nops17();
  if (d != 17u) return BW_FAIL_R(BW_D_CNT_INSTRET, 0, 17u, d);

  /* CPI of a plain loop: the multi-cycle core is documented at 4-6; accept 2..32 */
  uint32_t m0 = BW_CSR_R(mcycle), n0 = BW_CSR_R(minstret);
  for (volatile uint32_t k = 0; k < 200u; k++) { }
  uint32_t m1 = BW_CSR_R(mcycle), n1 = BW_CSR_R(minstret);
  uint32_t dc = m1 - m0, di = n1 - n0;
  if (di == 0u || dc < 2u * di || dc > 32u * di) return BW_FAIL_R(BW_D_CNT_CPI, dc, di, 0);

  /* Independent counters (CPU mcycle, fabric TELEM.CYCLES) must advance by the same amount. */
  uint32_t t0 = BW_TELEM(ALBION_TELEM_CNT_LO + ALBION_TC_CYCLES * ALBION_TELEM_CNT_LO_STRIDE);
  m0 = bw_cycles();
  for (volatile uint32_t k = 0; k < 300u; k++) { }
  uint32_t t1 = BW_TELEM(ALBION_TELEM_CNT_LO + ALBION_TC_CYCLES * ALBION_TELEM_CNT_LO_STRIDE);
  m1 = bw_cycles();
  uint32_t dt = t1 - t0, dm = m1 - m0;
  uint32_t diff = dt > dm ? dt - dm : dm - dt;
  if (diff > 64u) return BW_FAIL_R(BW_D_CNT_TELEM, dt, dm, diff);
  return BW_PASS_A(dc, di, dt);
}

bw_result_t bw_test_TIMER_IRQ(void) {
  /* mie.MTIE (7) and mie.MSIE (3): on a core with a CLINT they are writable. Global interrupts are off. */
  BW_CSR_S(mie, 0x88u);
  uint32_t v = BW_CSR_R(mie) & 0x88u;
  BW_CSR_C(mie, 0x88u);
  if (v == 0u) return BW_UNSUP_R(BW_D_UNSUP_TIMER_IRQ, 0u);
  return BW_SKIP_R(BW_D_SKIP_TIMER_UNTESTABLE, v);
}

bw_result_t bw_test_POLL_TIMEOUT(void) {
  uint32_t t0 = bw_cycles();
  int ok = BW_POLL(0, 1000u);
  uint32_t e = bw_cycles() - t0;
  if (ok || e < 1000u) return BW_FAIL_R(BW_D_TIMEOUT_EARLY, e, 1000u, (uint32_t)ok);
  if (e > 4000u) return BW_FAIL_R(BW_D_TIMEOUT_LATE, e, 1000u, 0);
  return BW_PASS_A(e, 0, 0);
}
