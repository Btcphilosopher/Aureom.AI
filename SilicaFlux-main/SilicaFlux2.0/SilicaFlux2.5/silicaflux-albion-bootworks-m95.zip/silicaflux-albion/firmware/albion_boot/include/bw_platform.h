/* BootWorks - platform access helpers for the Albion ControlCore (RV32I + Zicsr, M-mode). */
#ifndef BW_PLATFORM_H
#define BW_PLATFORM_H

#include <stdint.h>
#include "albion_regs.h"          /* generated from spec/albion/regmap.json - single source of truth */
#include "bw_status.h"

#define BW_REG(a)    (*(volatile uint32_t *)(uintptr_t)(a))
#define BW_MGMT(o)   BW_REG(ALBION_MGMT_BASE  + (o))
#define BW_IRQ(o)    BW_REG(ALBION_IRQ_BASE   + (o))
#define BW_DMA(o)    BW_REG(ALBION_DMA_BASE   + (o))
#define BW_PERM(o)   BW_REG(ALBION_PERM_BASE  + (o))
#define BW_TELEM(o)  BW_REG(ALBION_TELEM_BASE + (o))
#define BW_RAS(o)    BW_REG(ALBION_RAS_BASE   + (o))

#define BW_NIRQ      6u
#define BW_IRQ_ALL   ((1u << BW_NIRQ) - 1u)
#define BW_MMIO_UNMAPPED_PAGE  (ALBION_MMIO_BASE + 6u * ALBION_MMIO_PAGE_BYTES)
#define BW_UNDECODED_ADDR      0x20000000u   /* between SRAM and MMIO: no slave */

/* CSR access: name is a literal CSR name or number. */
#define BW_CSR_R(csr)      ({ uint32_t _v; __asm__ volatile("csrr %0, " #csr : "=r"(_v)); _v; })
#define BW_CSR_W(csr, v)   __asm__ volatile("csrw " #csr ", %0" :: "r"((uint32_t)(v)))
#define BW_CSR_S(csr, v)   __asm__ volatile("csrs " #csr ", %0" :: "r"((uint32_t)(v)))
#define BW_CSR_C(csr, v)   __asm__ volatile("csrc " #csr ", %0" :: "r"((uint32_t)(v)))

#define MSTATUS_MIE   (1u << 3)
#define MSTATUS_MPIE  (1u << 7)
#define MIE_MEIE      (1u << 11)
#define MIP_MEIP      (1u << 11)
#define MCAUSE_MEI    0x8000000Bu

static inline uint32_t bw_cycles(void) { return BW_CSR_R(mcycle); }

/* Bounded poll: evaluates `cond` until true or until `max` cycles elapse.
 * Evaluates to 1 when cond became true, 0 on timeout. All waits in BootWorks use this,
 * so a hardware hang becomes a TIMEOUT outcome instead of a hung boot. */
#define BW_POLL(cond, max)                                            \
  ({ uint32_t _t0 = bw_cycles(); int _ok = 0;                         \
     for (;;) { if (cond) { _ok = 1; break; }                         \
                if ((uint32_t)(bw_cycles() - _t0) > (uint32_t)(max)) break; } \
     _ok; })

#define BW_DMA_DEADLINE   200000u   /* cycles; a 16 KiB copy needs ~4.2 k */
#define BW_STACK_CANARY   0xC0DEC0DEu   /* painted by startup.S (ST: keep in sync, see boot.c) */

#endif /* BW_PLATFORM_H */
