/* BootWorks - outcome types, in-SRAM report layout and host-visible signatures.
 * Plain C/C++-compatible: the Verilator harness (sim/bootworks_tb.cpp) includes this
 * header so the firmware and the host-side checker cannot disagree on the layout. */
#ifndef BW_STATUS_H
#define BW_STATUS_H

#include <stdint.h>
#include "bw_diag.h"

/* --------------------------------------------------------------- outcomes */
#define BW_PASS        0u   /* test ran and the hardware behaved as specified              */
#define BW_FAIL        1u   /* test ran and detected a defect (diag code names the mode)   */
#define BW_TIMEOUT     2u   /* an operation did not finish inside its cycle deadline       */
#define BW_SKIPPED     3u   /* not executed (prerequisite failed / host dependent / no driver) */
#define BW_UNSUPPORTED 4u   /* hardware feature is absent (reason code in diag)            */
#define BW_NUM_OUTCOMES 5u

/* --------------------------------------------------------------- test ids */
enum {
#define BW_X_ID(n, s, d) BW_T_##n,
  BW_TEST_LIST(BW_X_ID)
#undef BW_X_ID
  BW_NUM_TESTS,
  BW_T_NONE = 0xFFu
};

/* --------------------------------------------------------------- diag codes */
enum {
#define BW_X_DIAG(n, c, d) BW_D_##n = c,
  BW_DIAG_LIST(BW_X_DIAG)
#undef BW_X_DIAG
  BW_D_NONE = 0
};

/* --------------------------------------------------------------- result */
typedef struct {
  uint16_t diag;      /* 0 for PASS; otherwise the failure/skip/unsupported reason code */
  uint8_t  outcome;   /* BW_PASS .. BW_UNSUPPORTED                                      */
  uint8_t  test;      /* BW_T_* id                                                      */
  uint32_t aux0;      /* diag-specific: usually the failing (fabric) address / count    */
  uint32_t aux1;      /* usually the expected value                                     */
  uint32_t aux2;      /* usually the observed value                                     */
} bw_result_t;

/* --------------------------------------------------------------- report (in SRAM) */
#define BW_REPORT_MAGIC   0x50525742u   /* bytes 'B','W','R','P' */
#define BW_REPORT_LAYOUT  1u
#define BW_STATE_RUNNING  1u
#define BW_STATE_DONE     2u

typedef struct {
  uint32_t magic;
  uint32_t layout;
  uint32_t fw_version;
  uint32_t state;              /* BW_STATE_*                                          */
  uint32_t verdict;            /* BW_SIG_PASS / BW_SIG_FAIL once state == DONE        */
  uint32_t n_tests;            /* BW_NUM_TESTS                                        */
  uint32_t n_done;             /* tests recorded so far                               */
  uint32_t count[BW_NUM_OUTCOMES];
  uint32_t first_fail_diag;    /* first FAIL/TIMEOUT diag code, 0 if none             */
  uint32_t first_fail_test;
  uint32_t config_id;
  uint32_t feat_impl;
  uint32_t banks_and_size;     /* [31:24] banks, [23:0] bank bytes / 1024            */
  uint32_t cycles;             /* mcycle at finalisation                              */
  uint32_t instret;            /* minstret at finalisation                            */
  uint32_t stack_hwm;          /* peak stack bytes used                               */
  uint32_t reserved[3];
  bw_result_t results[BW_NUM_TESTS];
  uint32_t crc;                /* CRC-32 (zlib) over every byte above this field      */
} bw_report_t;

/* --------------------------------------------------------------- host-visible signatures */
#define BW_VERSION        0x00950100u   /* module 95, v1.0 -> MGMT.FW_VERSION          */
#define BW_SIG_PASS       0xB007600Du   /* MGMT.FW_STATUS: boot finished, no FAIL/TIMEOUT */
#define BW_SIG_FAIL       0xB007FA11u   /* MGMT.FW_STATUS: boot finished, >=1 FAIL/TIMEOUT */
#define BW_ST_LIVE(stage, test, nfail) \
  (0xB1000000u | (((uint32_t)(stage) & 0xFFu) << 16) | (((uint32_t)(test) & 0xFFu) << 8) | ((uint32_t)(nfail) & 0xFFu))
#define BW_ST_ENTRY       0xB1000001u   /* first instruction executed                  */
#define BW_ST_CRT_DONE    0xB1000002u   /* .data copied, .bss cleared, stack painted   */
#define BW_ST_MAIN        0xB1000003u   /* boot_main entered                           */
#define BW_ST_FATAL(c)    (0xDEAD0000u | ((uint32_t)(c) & 0xFFFFu))   /* same as stock firmware */

/* mailbox completion record types: w0 = (0xB007 << 16) | type */
#define BW_REC_START      0x0001u
#define BW_REC_SUMMARY    0x0002u

/* image trailer, 16 bytes after .rodata; tools/bw_patch_image.py fills in size and crc */
#define BW_TRAILER_MAGIC  0x4D495742u   /* bytes 'B','W','I','M' */
typedef struct {
  uint32_t magic;
  uint32_t size;       /* total image bytes [0, _image_end)                          */
  uint32_t crc;        /* CRC-32 (zlib) of the image with these 16 bytes taken as 0  */
  uint32_t version;
} bw_trailer_t;

#endif /* BW_STATUS_H */
