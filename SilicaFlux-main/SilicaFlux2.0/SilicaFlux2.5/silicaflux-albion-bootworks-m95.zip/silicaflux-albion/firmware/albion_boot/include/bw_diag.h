/* BootWorks (Module 95) - test list and diagnostic-code table.
 *
 * Single source of truth for:
 *   - BW_TEST_LIST: every self-test, in execution order (id = position).
 *   - BW_DIAG_LIST: every diagnostic code. A code names one failure MODE; each is unique.
 *
 * tools/bw_diag_tool.py parses this file (regex over the X(...) lines), enforces code
 * uniqueness and that every code is referenced by firmware source, and generates
 * docs/DIAGNOSTIC_CODES.md. Keep each X(...) on ONE line.
 *
 * Code layout: 0xGGNN, GG = group, NN = sequence.
 *   0x10 CPU/ISA   0x20 TRAP   0x30 PLATFORM   0x40 REGISTER  0x50 SRAM
 *   0x60 ECC       0x70 DMA    0x80 INTERRUPT  0x90 COUNTER/TIMER
 *   0xE0 firmware-internal     0xF0 SKIPPED reasons   0xF1 UNSUPPORTED reasons
 */
#ifndef BW_DIAG_H
#define BW_DIAG_H

#define BW_STAGE_CPU   0x10u
#define BW_STAGE_TRAP  0x20u
#define BW_STAGE_PLAT  0x30u
#define BW_STAGE_REG   0x40u
#define BW_STAGE_MEM   0x50u
#define BW_STAGE_ECC   0x60u
#define BW_STAGE_DMA   0x70u
#define BW_STAGE_IRQ   0x80u
#define BW_STAGE_TIMER 0x90u
#define BW_STAGE_POST  0xA0u

/* X(name, stage, description) - in execution order */
#define BW_TEST_LIST(X) \
  X(CPU_ENTRY,     BW_STAGE_CPU,   "reset-entry CSR state matches RTL reset values") \
  X(CPU_IDENT,     BW_STAGE_CPU,   "misa/mvendorid/marchid/mimpid/mhartid identify an RV32I hart") \
  X(ISA_RV32I,     BW_STAGE_CPU,   "RV32I arithmetic, shift, compare, branch, jump, load/store") \
  X(ISA_M,         BW_STAGE_CPU,   "RV32M multiply/divide probe, cross-checked against misa") \
  X(ISA_A,         BW_STAGE_CPU,   "RV32A atomics probe, cross-checked against misa") \
  X(ISA_C,         BW_STAGE_CPU,   "RVC compressed-instruction probe, cross-checked against misa") \
  X(ISA_F,         BW_STAGE_CPU,   "RV32F floating-point probe, cross-checked against misa") \
  X(ISA_FENCE,     BW_STAGE_CPU,   "FENCE and FENCE.I execute") \
  X(CSR_BASIC,     BW_STAGE_CPU,   "CSR read/write/set/clear semantics and WARL fields") \
  X(CSR_ABSENT,    BW_STAGE_CPU,   "hpm counters and debug CSRs are absent (illegal instruction)") \
  X(TRAP_CAUSES,   BW_STAGE_TRAP,  "every synchronous exception cause, mepc and mtval") \
  X(TRAP_RETURN,   BW_STAGE_TRAP,  "trap entry/MRET mstatus handling and resume address") \
  X(CNT_CYCLE,     BW_STAGE_TIMER, "mcycle/instret behave and agree with the TELEM cycle counter") \
  X(TIMER_IRQ,     BW_STAGE_TIMER, "machine timer / software interrupt availability") \
  X(POLL_TIMEOUT,  BW_STAGE_TIMER, "the cycle-deadline polling mechanism used for TIMEOUT detection") \
  X(PLAT_ID,       BW_STAGE_PLAT,  "CHIP_ID and RTL version") \
  X(PLAT_CONFIG,   BW_STAGE_PLAT,  "CONFIG_ID and SRAM/window/queue geometry are consistent") \
  X(PLAT_FEATURES, BW_STAGE_PLAT,  "FEAT_REQ / FEAT_IMPL / FEAT_UNAVAIL consistency") \
  X(BOOT_ROM,      BW_STAGE_PLAT,  "boot ROM presence (reset vector lives in host-loaded SRAM)") \
  X(UART,          BW_STAGE_PLAT,  "UART / console peripheral presence") \
  X(DEBUG,         BW_STAGE_PLAT,  "RISC-V debug module presence") \
  X(VECTOR,        BW_STAGE_PLAT,  "vector command unit") \
  X(TENSOR,        BW_STAGE_PLAT,  "tensor (INT8 GEMM) command unit") \
  X(ACCEL_OTHER,   BW_STAGE_PLAT,  "packet / virtual-I/O accelerators") \
  X(HOSTMEM,       BW_STAGE_PLAT,  "core access to host memory (host-IOMMU dependent)") \
  X(MAILBOX,       BW_STAGE_PLAT,  "firmware command/completion queue status and completion push") \
  X(REG_MGMT,      BW_STAGE_REG,   "MGMT page: read-only, writer-restricted and read/write registers") \
  X(REG_IRQ,       BW_STAGE_REG,   "IRQ page registers") \
  X(REG_DMA,       BW_STAGE_REG,   "DMA page registers") \
  X(REG_PERM,      BW_STAGE_REG,   "PERM page: window table and violation registers") \
  X(REG_TELEM,     BW_STAGE_REG,   "TELEM page: counters, freeze, read-only access") \
  X(REG_RAS,       BW_STAGE_REG,   "RAS page: scrub status, clean log, injection registers") \
  X(REG_FAULTS,    BW_STAGE_REG,   "unmapped, partial-strobe and past-end accesses fault (exact decode)") \
  X(IMG_CRC,       BW_STAGE_MEM,   "firmware image CRC32 matches the build-time trailer") \
  X(BANK0_SWEEP,   BW_STAGE_MEM,   "every word of firmware bank 0 reads clean (no ECC events)") \
  X(STACK,         BW_STAGE_MEM,   "stack alignment, canary guard and high-water mark") \
  X(MEM_DATABUS,   BW_STAGE_MEM,   "SRAM data lines: walking ones/zeros") \
  X(MEM_ADDRBUS,   BW_STAGE_MEM,   "SRAM address lines: stuck/shorted detection") \
  X(MEM_BANKSEL,   BW_STAGE_MEM,   "SRAM bank-select decode: no aliasing between banks") \
  X(MEM_MARCH,     BW_STAGE_MEM,   "SRAM integrity: March C- over every testable word") \
  X(MEM_PATTERN,   BW_STAGE_MEM,   "SRAM integrity: address-as-data, checkerboard, PRBS patterns") \
  X(MEM_BYTE,      BW_STAGE_MEM,   "byte and halfword stores (SRAM read-modify-write) and load extension") \
  X(ECC_CE,        BW_STAGE_ECC,   "single-bit ECC injection: corrected, counted, logged, interrupt, RMW heal") \
  X(ECC_UE,        BW_STAGE_ECC,   "double-bit ECC injection: load access fault, counted, logged, recoverable") \
  X(DMA_IDLE,      BW_STAGE_DMA,   "DMA idle at reset") \
  X(DMA_FILL,      BW_STAGE_DMA,   "DMA fill into a data bank, status/bytes/guards") \
  X(DMA_COPY,      BW_STAGE_DMA,   "DMA memory-to-memory copy across and within banks") \
  X(DMA_SIZES,     BW_STAGE_DMA,   "DMA transfer sizes from one word to a full bank, throughput bounds") \
  X(DMA_BADPARAM,  BW_STAGE_DMA,   "DMA parameter checking (BADPARAM, nothing moved)") \
  X(DMA_ERRORS,    BW_STAGE_DMA,   "DMA first-failing-beat semantics at the end of SRAM") \
  X(DMA_FWBANK,    BW_STAGE_DMA,   "hardware invariants: DMA cannot reach firmware bank, MMIO") \
  X(DMA_PERM,      BW_STAGE_DMA,   "permission windows enforced per DMA beat for tenant domains") \
  X(IRQ_BASE,      BW_STAGE_IRQ,   "no spurious interrupt state after reset") \
  X(IRQ_MASK,      BW_STAGE_IRQ,   "IRQ enable gating of mip.MEIP, sticky W1C clear") \
  X(IRQ_WFI,       BW_STAGE_IRQ,   "WFI wakes on an enabled interrupt with MSTATUS.MIE clear") \
  X(IRQ_TAKEN,     BW_STAGE_IRQ,   "machine external interrupt taken: cause, mepc, mstatus, resume") \
  X(IRQ_SOURCES,   BW_STAGE_IRQ,   "DMA_ERR / PERM_VIOL / ECC_CE / ECC_UE interrupt sources") \
  X(IRQ_MULTI,     BW_STAGE_IRQ,   "simultaneous sources: one trap, all bits visible, no retrigger") \
  X(IMG_CRC_POST,  BW_STAGE_POST,  "firmware image CRC32 unchanged after all destructive tests") \
  X(STACK_POST,    BW_STAGE_POST,  "stack canary intact after all tests")

/* X(name, code, description) */
#define BW_DIAG_LIST(X) \
  X(CPU_ENTRY_MSTATUS,     0x1001, "mstatus at reset entry is not 0x1800 (MIE=0, MPP=M)") \
  X(CPU_ENTRY_MIE,         0x1002, "mie is non-zero at reset entry") \
  X(CPU_ENTRY_MEPC,        0x1003, "mepc is non-zero at reset entry") \
  X(CPU_ENTRY_MCAUSE,      0x1004, "mcause is non-zero at reset entry") \
  X(CPU_ENTRY_MTVEC,       0x1005, "mtvec is non-zero at reset entry") \
  X(CPU_ENTRY_HARTID,      0x1006, "mhartid is not 0") \
  X(CPU_ENTRY_LATE,        0x1007, "first instruction retired too long after core reset (mcycle at entry)") \
  X(CPU_MISA_MXL,          0x1011, "misa.MXL is not 1 (RV32)") \
  X(CPU_MISA_NO_I,         0x1012, "misa.I (base integer ISA) not set") \
  X(ISA_ARITH,             0x1021, "add/sub/and/or/xor/addi/andi/ori/xori result wrong") \
  X(ISA_SHIFT,             0x1022, "sll/srl/sra/slli/srli/srai result wrong") \
  X(ISA_CMP,               0x1023, "slt/sltu/slti/sltiu result wrong") \
  X(ISA_UPPER,             0x1024, "lui/auipc result wrong") \
  X(ISA_BRANCH,            0x1025, "beq/bne/blt/bge/bltu/bgeu taken/not-taken wrong") \
  X(ISA_JUMP,              0x1026, "jal/jalr target or link register wrong") \
  X(ISA_LOADSTORE,         0x1027, "lb/lh/lw/lbu/lhu/sb/sh/sw result wrong") \
  X(ISA_X0,                0x1028, "register x0 is not hard-wired to zero") \
  X(ISA_M_MISA_LIES,       0x1031, "misa.M disagrees with whether mul executes") \
  X(ISA_M_WRONG,           0x1032, "M extension present but mul/div result wrong") \
  X(ISA_A_MISA_LIES,       0x1033, "misa.A disagrees with whether amoadd.w executes") \
  X(ISA_C_MISA_LIES,       0x1034, "misa.C disagrees with whether a compressed instruction executes") \
  X(ISA_F_MISA_LIES,       0x1035, "misa.F/D disagrees with whether a floating-point instruction executes") \
  X(ISA_A_WRONG,           0x1037, "A extension present but amoadd.w result wrong") \
  X(ISA_PROBE_TRAP,        0x1036, "unsupported-instruction probe trapped with cause/mtval other than illegal-instruction") \
  X(ISA_FENCE_TRAP,        0x1041, "fence or fence.i raised an exception") \
  X(CSR_MSCRATCH,          0x1051, "mscratch does not hold written patterns") \
  X(CSR_MTVEC_WARL,        0x1052, "mtvec mode bits not forced to direct mode") \
  X(CSR_MEPC_ALIGN,        0x1053, "mepc low bits not cleared") \
  X(CSR_RMW,               0x1054, "csrrw/csrrs/csrrc/csrrwi/csrrsi/csrrci semantics wrong") \
  X(CSR_MSTATUS,           0x1055, "mstatus MIE/MPIE not writable or MPP not constant M") \
  X(CSR_MIE_MASK,          0x1056, "mie has writable bits other than MEIE") \
  X(CSR_MIP_RO,            0x1057, "mip is writable") \
  X(CSR_RO_WRITE,          0x1058, "write to a read-only CSR did not raise illegal-instruction") \
  X(CSR_ALIAS,             0x1059, "cycle/instret user aliases disagree with mcycle/minstret") \
  X(CSR_ABSENT_BAD_TRAP,   0x1061, "absent-CSR probe trapped with a cause other than illegal-instruction") \
  X(TRAP_ECALL_CAUSE,      0x2001, "ecall: missing trap or cause != 11") \
  X(TRAP_ECALL_STATE,      0x2002, "ecall: mepc or mtval wrong") \
  X(TRAP_EBREAK_CAUSE,     0x2003, "ebreak: missing trap or cause != 3") \
  X(TRAP_EBREAK_STATE,     0x2004, "ebreak: mepc or mtval wrong") \
  X(TRAP_ILLEGAL_CAUSE,    0x2005, "illegal instruction: missing trap or cause != 2") \
  X(TRAP_ILLEGAL_STATE,    0x2006, "illegal instruction: mepc or mtval wrong") \
  X(TRAP_IMIS_CAUSE,       0x2007, "misaligned jump target: missing trap or cause != 0") \
  X(TRAP_IMIS_STATE,       0x2008, "misaligned jump target: mepc or mtval wrong") \
  X(TRAP_IFAULT_CAUSE,     0x2009, "fetch from undecoded address: missing trap or cause != 1") \
  X(TRAP_IFAULT_STATE,     0x200A, "fetch from undecoded address: mepc or mtval wrong") \
  X(TRAP_LMIS_CAUSE,       0x200B, "misaligned load: missing trap or cause != 4") \
  X(TRAP_LMIS_STATE,       0x200C, "misaligned load: mepc or mtval wrong") \
  X(TRAP_LFAULT_CAUSE,     0x200D, "load from undecoded address: missing trap or cause != 5") \
  X(TRAP_LFAULT_STATE,     0x200E, "load access fault: mepc or mtval wrong") \
  X(TRAP_SMIS_CAUSE,       0x200F, "misaligned store: missing trap or cause != 6") \
  X(TRAP_SMIS_STATE,       0x2010, "misaligned store: mepc or mtval wrong") \
  X(TRAP_SFAULT_CAUSE,     0x2011, "store to undecoded address: missing trap or cause != 7") \
  X(TRAP_SFAULT_STATE,     0x2012, "store access fault: mepc or mtval wrong") \
  X(TRAP_MRET_PC,          0x2021, "mret did not resume at mepc") \
  X(TRAP_MSTATUS_ENTRY,    0x2022, "trap entry did not clear MIE / save MPIE") \
  X(TRAP_MSTATUS_MRET,     0x2023, "mret did not restore MIE from MPIE and set MPIE") \
  X(PLAT_CHIP_ID,          0x3001, "CHIP_ID is not 0x53464190") \
  X(PLAT_RTL_MAJOR,        0x3002, "RTL major version is not supported by this BootWorks (1)") \
  X(PLAT_CFG_ID,           0x3011, "CONFIG_ID is not 0, 1 or 2") \
  X(PLAT_CFG_MISMATCH,     0x3012, "SRAM/window/queue geometry inconsistent with CONFIG_ID") \
  X(PLAT_GEOMETRY,         0x3013, "SRAM geometry unusable (bank size not a power of two, < 16 KiB, or < 2 banks)") \
  X(PLAT_FEAT_CORE,        0x3021, "CONTROLCORE or DATAFABRIC feature bit missing while executing") \
  X(PLAT_FEAT_UNAVAIL,     0x3022, "FEAT_UNAVAIL != FEAT_REQ & ~FEAT_IMPL") \
  X(PLAT_FEAT_SUBSET,      0x3023, "FEAT_IMPL has bits not present in FEAT_REQ") \
  X(PLAT_BOOTMEM_PC,       0x3031, "executing outside SRAM bank 0 (reset vector not in firmware bank)") \
  X(PLAT_BOOTMEM_RW,       0x3032, "boot memory scratch window is not writable RAM") \
  X(PLAT_UART_PROBE,       0x3041, "an unexpected peripheral answers at the first unpopulated MMIO page") \
  X(PLAT_MBX_FCMDQ,        0x3061, "firmware command queue status inconsistent (count/empty/full)") \
  X(PLAT_MBX_FCPLQ,        0x3062, "firmware completion queue status inconsistent at boot") \
  X(PLAT_MBX_PUSH,         0x3063, "completion push did not raise the queue count") \
  X(REG_CHIPID_WRITE,      0x4001, "write to read-only CHIP_ID did not fault") \
  X(REG_RO_CHANGED,        0x4002, "read-only register value changed after a write attempt") \
  X(REG_SCRATCH,           0x4003, "SCRATCH read-back mismatch") \
  X(REG_FWVER,             0x4004, "FW_VERSION read-back mismatch") \
  X(REG_HOSTONLY,          0x4005, "core write to host-only register did not fault") \
  X(REG_IRQ_ENABLE,        0x4011, "IRQ.ENABLE read-back mismatch (unused bits must read 0)") \
  X(REG_IRQ_RO,            0x4012, "IRQ.PENDING/RAW accepted a write") \
  X(REG_DMA_RW,            0x4021, "DMA SRC/DST/LEN/DOMAIN/FILL read-back mismatch") \
  X(REG_DMA_RO,            0x4022, "DMA STATUS accepted a write") \
  X(REG_DMA_RESET,         0x4023, "DMA status not idle/clear at reset") \
  X(REG_PERM_NUMWIN,       0x4031, "PERM.NUM_WIN disagrees with MGMT.NUM_WINDOWS") \
  X(REG_PERM_RESET,        0x4032, "a permission window is valid at reset") \
  X(REG_PERM_RW,           0x4033, "window base/limit read-back mismatch") \
  X(REG_PERM_ATTR,         0x4034, "window attribute read-back mismatch (reserved bits must read 0)") \
  X(REG_PERM_VIOL_RO,      0x4035, "PERM violation registers accepted a write or were dirty at reset") \
  X(REG_TELEM_NUM,         0x4041, "TELEM.NUM_COUNTERS is not 48") \
  X(REG_TELEM_COUNT,       0x4042, "TELEM cycle counter is not counting") \
  X(REG_TELEM_FREEZE,      0x4043, "TELEM freeze did not hold / release the counters") \
  X(REG_TELEM_RO,          0x4044, "write to a TELEM counter did not fault") \
  X(REG_RAS_SCRUB,         0x4051, "RAS.SCRUB_STATUS reports banks not initialised") \
  X(REG_RAS_DIRTY,         0x4052, "RAS log valid or error counters non-zero at reset") \
  X(REG_RAS_INJ_RW,        0x4053, "RAS injection register read-back mismatch") \
  X(REG_RAS_RO,            0x4054, "RAS counter accepted a write") \
  X(REG_FAULT_PAGE_R,      0x4061, "read of an unpopulated MMIO page did not fault") \
  X(REG_FAULT_PAGE_W,      0x4062, "write to an unpopulated MMIO page did not fault") \
  X(REG_FAULT_OFFSET,      0x4063, "read of an unpopulated MGMT offset did not fault") \
  X(REG_FAULT_PARTIAL,     0x4064, "byte store to an MMIO register did not fault or modified it") \
  X(REG_FAULT_UNDEC_R,     0x4065, "load from an undecoded address did not fault") \
  X(REG_FAULT_UNDEC_W,     0x4066, "store to an undecoded address did not fault") \
  X(REG_FAULT_SRAM_END,    0x4067, "load past the last SRAM bank did not fault (address alias)") \
  X(IMG_TRAILER,           0x5001, "image trailer magic missing") \
  X(IMG_CRC,               0x5002, "image CRC32 mismatch (corrupted load or SRAM bit error in code)") \
  X(MEM_B0_UE,             0x5011, "uncorrectable error / access fault reading bank 0") \
  X(MEM_B0_CE,             0x5012, "correctable ECC event while reading bank 0 (latent bit error)") \
  X(STACK_GUARD,           0x5021, "stack guard canary damaged (overflow)") \
  X(STACK_ALIGN,           0x5022, "stack pointer not 16-byte aligned at test entry") \
  X(STACK_CANARY_FILL,     0x5023, "stack usage above 75% of the stack area (overflow risk)") \
  X(MEM_DATABUS,           0x5031, "SRAM data line stuck or shorted (walking pattern mismatch)") \
  X(MEM_ADDR_HIGH,         0x5041, "SRAM address line stuck high / alias (address-bus test)") \
  X(MEM_ADDR_LOW,          0x5042, "SRAM address line stuck low or shorted (address-bus test)") \
  X(MEM_BANK_ALIAS,        0x5051, "bank-select decode aliases two banks") \
  X(MEM_MARCH_E1,          0x5061, "March C- element 1 (r0,w1 ascending) mismatch") \
  X(MEM_MARCH_E2,          0x5062, "March C- element 2 (r1,w0 ascending) mismatch") \
  X(MEM_MARCH_E3,          0x5063, "March C- element 3 (r0,w1 descending) mismatch") \
  X(MEM_MARCH_E4,          0x5064, "March C- element 4 (r1,w0 descending) mismatch") \
  X(MEM_MARCH_E5,          0x5065, "March C- element 5 (r0 final) mismatch") \
  X(MEM_PAT_ADDR,          0x5071, "address-as-data pattern mismatch") \
  X(MEM_PAT_CHECKER,       0x5072, "checkerboard pattern mismatch") \
  X(MEM_PAT_PRBS,          0x5073, "pseudo-random pattern mismatch") \
  X(MEM_BYTE_WRITE,        0x5081, "byte store changed other bytes of the word") \
  X(MEM_BYTE_NEIGHBOR,     0x5082, "sub-word store modified an adjacent word") \
  X(MEM_HALF_WRITE,        0x5083, "halfword store changed other bytes of the word") \
  X(MEM_LOAD_EXT,          0x5084, "lb/lbu/lh/lhu sign or zero extension wrong") \
  X(MEM_CE_MASKED,         0x50A1, "correctable ECC events during a memory test: a stuck or weak bit that SECDED masked") \
  X(IMG_CRC_POST,          0x5091, "image CRC32 changed after the destructive tests") \
  X(STACK_GUARD_POST,      0x5092, "stack canary damaged by the tests") \
  X(ECC_INJ_NOHIT,         0x6001, "error injection did not trigger on the armed write") \
  X(ECC_CE_DATA,           0x6002, "single-bit error not corrected (read-back data wrong)") \
  X(ECC_CE_TRAP,           0x6003, "correctable error raised an exception") \
  X(ECC_CE_COUNT,          0x6004, "RAS.CE_COUNT did not increase") \
  X(ECC_CE_LOG,            0x6005, "RAS error log type/address/source wrong for CE") \
  X(ECC_CE_IRQ,            0x6006, "ECC_CE interrupt source not pending after CE") \
  X(ECC_RMW_HEAL,          0x6007, "byte store to a CE word lost data or left the error in place") \
  X(ECC_CHECKBIT,          0x6008, "flip of an ECC check bit not corrected") \
  X(ECC_UE_NOTRAP,         0x6011, "uncorrectable error did not raise load access fault") \
  X(ECC_UE_TVAL,           0x6012, "UE load fault mtval does not hold the address") \
  X(ECC_UE_COUNT,          0x6013, "RAS.UE_COUNT did not increase") \
  X(ECC_UE_LOG,            0x6014, "RAS error log type/address wrong for UE") \
  X(ECC_UE_IRQ,            0x6015, "ECC_UE interrupt source not pending after UE") \
  X(ECC_UE_RECOVER,        0x6016, "rewriting the word did not clear the uncorrectable state") \
  X(DMA_NOT_IDLE,          0x7001, "DMA busy or has stale DONE/ERROR at reset") \
  X(DMA_FILL_STATUS,       0x7011, "DMA fill: STATUS not DONE/clean") \
  X(DMA_FILL_DATA,         0x7012, "DMA fill: destination data wrong") \
  X(DMA_FILL_OVERRUN,      0x7014, "DMA fill: wrote outside the destination range") \
  X(DMA_FILL_TIMEOUT,      0x7015, "DMA fill did not finish within the deadline") \
  X(DMA_COPY_STATUS,       0x7021, "DMA copy: STATUS not DONE/clean") \
  X(DMA_COPY_DATA,         0x7022, "DMA copy: destination data wrong") \
  X(DMA_COPY_SRC,          0x7023, "DMA copy: source data modified") \
  X(DMA_COPY_OVERRUN,      0x7024, "DMA copy: wrote outside the destination range") \
  X(DMA_COPY_TIMEOUT,      0x7025, "DMA copy did not finish within the deadline") \
  X(DMA_SIZE_DATA,         0x7031, "DMA size sweep: destination data wrong") \
  X(DMA_SIZE_BYTES,        0x7032, "DMA size sweep: BYTES_DONE != LEN") \
  X(DMA_SIZE_CYCLES,       0x7033, "DMA size sweep: CYCLES outside plausible bounds") \
  X(DMA_SIZE_TIMEOUT,      0x7034, "DMA size sweep: transfer did not finish within the deadline") \
  X(DMA_BAD_NOERR,         0x7041, "illegal DMA parameters accepted without error") \
  X(DMA_BAD_CODE,          0x7042, "illegal DMA parameters: ERR_CODE is not BADPARAM") \
  X(DMA_BAD_TIMEOUT,       0x7044, "illegal-parameter DMA did not complete") \
  X(DMA_ERR_NOERR,         0x7051, "DMA beyond SRAM end completed without error") \
  X(DMA_ERR_CODE,          0x7052, "DMA beyond SRAM end: ERR_CODE is not DECERR") \
  X(DMA_ERR_BYTES,         0x7054, "DMA beyond SRAM end: BYTES_DONE, ERR_ADDR or moved data wrong (4 * failing beat index)") \
  X(DMA_ERR_TIMEOUT,       0x7055, "DMA beyond SRAM end did not complete") \
  X(DMA_FW_WRITE,          0x7061, "DMA wrote to the firmware-private bank (invariant broken)") \
  X(DMA_FW_READ,           0x7062, "DMA read from the firmware-private bank (invariant broken)") \
  X(DMA_FW_CODE,           0x7063, "firmware-bank DMA denied with an error code other than PERM") \
  X(DMA_FW_VIOL,           0x7064, "firmware-bank DMA denial not logged by the permission unit") \
  X(DMA_FW_MMIO,           0x7065, "DMA read of an MMIO register was not denied (invariant broken)") \
  X(DMA_FW_TIMEOUT,        0x7066, "invariant-check DMA did not complete") \
  X(DMA_PERM_DENY,         0x7071, "tenant DMA without a window was not denied") \
  X(DMA_PERM_ALLOW,        0x7072, "tenant DMA inside an open window failed") \
  X(DMA_PERM_BOUNDARY,     0x7073, "tenant DMA crossing a window edge: BYTES_DONE/ERR_ADDR not at the edge") \
  X(DMA_PERM_RO,           0x7074, "tenant DMA wrote through a read-only window") \
  X(DMA_PERM_DOMAIN,       0x7075, "DMA in another domain used a window it does not own") \
  X(DMA_PERM_ADMIN,        0x7076, "DMA in HOST_ADMIN domain was not denied") \
  X(DMA_PERM_CODE,         0x7078, "denied tenant DMA reported an error code other than PERM") \
  X(DMA_PERM_TIMEOUT,      0x7077, "permission DMA did not complete") \
  X(IRQ_SPURIOUS,          0x8001, "interrupt sources pending at reset") \
  X(IRQ_MEIP_STUCK,        0x8002, "mip.MEIP set while every source is disabled") \
  X(IRQ_MASK_NOT_GATED,    0x8011, "mip.MEIP asserted although IRQ.ENABLE masks the source") \
  X(IRQ_MASK_NOT_RAISED,   0x8012, "mip.MEIP not asserted for a pending, enabled source") \
  X(IRQ_CLEAR_STUCK,       0x8013, "W1C clear did not clear a sticky source") \
  X(IRQ_MIE_BLOCK,         0x8014, "interrupt taken while mstatus.MIE=0") \
  X(IRQ_WFI_NOPEND,        0x8021, "source not pending after the DMA completed") \
  X(IRQ_WFI_TRAP,          0x8022, "WFI wake-up with MIE=0 took a trap") \
  X(IRQ_NOT_TAKEN,         0x8031, "enabled interrupt not taken within the deadline") \
  X(IRQ_CAUSE,             0x8032, "interrupt mcause is not 0x8000000B") \
  X(IRQ_EPC,               0x8033, "interrupt mepc outside the interrupted loop") \
  X(IRQ_MSTATUS,           0x8034, "mstatus inside the ISR: MIE must be 0 and MPIE 1") \
  X(IRQ_COUNT,             0x8035, "more than one interrupt trap for one event") \
  X(IRQ_RESUME,            0x8036, "mstatus.MIE not restored by mret") \
  X(IRQ_STUCK,             0x8037, "source remained pending after W1C (re-trigger storm)") \
  X(IRQ_SRC_DMA_ERR,       0x8041, "DMA_ERR source did not pend on a failing DMA") \
  X(IRQ_SRC_PERM,          0x8042, "PERM_VIOL source did not pend on a permission violation") \
  X(IRQ_SRC_ECC_CE,        0x8043, "ECC_CE source did not pend on a corrected error") \
  X(IRQ_SRC_ECC_UE,        0x8044, "ECC_UE source did not pend on an uncorrectable error") \
  X(IRQ_SRC_EXTRA,         0x8045, "an unrelated interrupt source pended") \
  X(IRQ_MULTI_MISSING,     0x8051, "not every simultaneous source was visible to the ISR") \
  X(IRQ_MULTI_RETRIGGER,   0x8052, "interrupt re-triggered after all sources were cleared") \
  X(CNT_MCYCLE_STUCK,      0x9001, "mcycle is not advancing") \
  X(CNT_INSTRET,           0x9002, "minstret delta over a straight-line sequence is not exact") \
  X(CNT_CPI,               0x9003, "cycles per instruction outside 2..32") \
  X(CNT_TELEM,             0x9004, "mcycle and TELEM.CYCLES disagree over the same interval") \
  X(TIMEOUT_EARLY,         0x9021, "poll deadline expired earlier than requested") \
  X(TIMEOUT_LATE,          0x9022, "poll deadline overran by more than 4x") \
  X(INT_REGION_UNSAFE,     0xE001, "internal: memory test region overlaps firmware code, data or stack") \
  X(INT_UNEXPECTED_TRAP,   0xE002, "an unexpected trap aborted the test (aux: mcause, mepc, mtval)") \
  X(INT_NOT_RUN,           0xE003, "test table entry was never executed") \
  X(SKIP_PREREQ,           0xF001, "skipped: a prerequisite test did not pass (aux0 = prerequisite test id)") \
  X(SKIP_HOST_DEPENDENT,   0xF002, "skipped: result depends on host/IOMMU configuration, not exercised") \
  X(SKIP_NO_DRIVER,        0xF003, "skipped: hardware present but the register map is not in the Albion regmap, so no driver exists") \
  X(SKIP_TIMER_UNTESTABLE, 0xF004, "skipped: timer/software interrupt bit is writable but no timer register is defined") \
  X(SKIP_NO_DATA_BANK,     0xF005, "skipped: fewer than two data banks to run the test on") \
  X(UNSUP_ISA_M,           0xF101, "RV32M not implemented (mul raised illegal-instruction)") \
  X(UNSUP_ISA_A,           0xF102, "RV32A not implemented (amoadd.w raised illegal-instruction)") \
  X(UNSUP_ISA_C,           0xF103, "RVC not implemented (compressed encoding raised illegal-instruction)") \
  X(UNSUP_ISA_F,           0xF104, "RV32F not implemented (fadd.s raised illegal-instruction)") \
  X(UNSUP_CSR_HPM,         0xF105, "hardware performance-monitor and debug CSRs not implemented") \
  X(UNSUP_TIMER_IRQ,       0xF106, "no machine timer or software interrupt (mie.MTIE/MSIE read-only zero)") \
  X(UNSUP_BOOT_ROM,        0xF107, "no boot ROM: reset vector is host-loaded SRAM bank 0") \
  X(UNSUP_UART,            0xF108, "no UART/console peripheral in the regmap; next MMIO page returns DECERR") \
  X(UNSUP_DEBUG,           0xF109, "no debug module (debug CSRs illegal)") \
  X(UNSUP_VECTOR,          0xF10A, "no vector command unit exists in the Albion feature set") \
  X(UNSUP_TENSOR,          0xF10B, "ComputeWorks (INT8 GEMM) not implemented: FEAT_IMPL bit clear") \
  X(UNSUP_ACCEL_OTHER,     0xF10C, "PacketForge/VirtualFoundry not implemented: FEAT_IMPL bits clear")

#endif /* BW_DIAG_H */
