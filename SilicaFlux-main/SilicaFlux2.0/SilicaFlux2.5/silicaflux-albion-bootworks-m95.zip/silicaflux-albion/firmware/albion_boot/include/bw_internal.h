/* BootWorks - internal interfaces shared by the firmware modules. */
#ifndef BW_INTERNAL_H
#define BW_INTERNAL_H

#include "bw_platform.h"

/* ------------------------------------------------------------ result helpers */
bw_result_t bw_res(uint32_t outcome, uint32_t diag, uint32_t a0, uint32_t a1, uint32_t a2) __attribute__((noinline));
#define BW_PASS_R()            bw_res(BW_PASS, 0, 0, 0, 0)
#define BW_PASS_A(a0, a1, a2)  bw_res(BW_PASS, 0, (a0), (a1), (a2))
bw_result_t bw_fail(uint32_t diag, uint32_t a0, uint32_t a1, uint32_t a2);   /* FAIL: one fewer argument per call site */
bw_result_t bw_tmo(uint32_t diag, uint32_t a0, uint32_t a1, uint32_t a2);    /* TIMEOUT */
#define BW_FAIL_R(d, a0, a1, a2) bw_fail((d), (a0), (a1), (a2))
#define BW_TMO_R(d, a0, a1, a2)  bw_tmo((d), (a0), (a1), (a2))
#define BW_SKIP_R(d, a0)       bw_res(BW_SKIPPED, (d), (a0), 0, 0)
#define BW_UNSUP_R(d, a0)      bw_res(BW_UNSUPPORTED, (d), (a0), 0, 0)

/* ------------------------------------------------------------ linker symbols */
extern char _text_start[], _image_end[], _data_start[], _data_end[], _data_lma[];
extern char _bss_start[], _bss_end[], _scratch_start[], _scratch_end[];
extern char _stack_limit[], _stack_top[], bw_image_trailer[], bw_sandbox[];
#define BW_SYM(s) ((uint32_t)(uintptr_t)(s))

/* ------------------------------------------------------------ reset-entry state (startup.S) */
typedef struct {            /* order = store order in startup.S */
  uint32_t mstatus, mie, mtvec, mepc, mcause, mcycle, minstret, mhartid;
} bw_entry_t;
extern bw_entry_t g_entry;

/* ------------------------------------------------------------ hardware inventory */
typedef struct {
  uint32_t chip_id, rtl_version, config_id, feat_impl, feat_req, feat_unavail;
  uint32_t banks, bank_bytes, windows, cmdq_depth, cplq_depth, domains;
  uint32_t misa, mvendorid, marchid, mimpid, mhartid;
  uint32_t dbg_strap;
  /* reset-state snapshot, taken before any test mutates the hardware */
  uint32_t snap_dev_status, snap_irq_pending, snap_irq_enable, snap_mip;
  uint32_t snap_dma_status, snap_ras_status, snap_ce, snap_ue, snap_scrub;
  uint32_t snap_viol_count, snap_viol_info, snap_win_valid, snap_fcmdq, snap_fcplq;
} bw_hw_t;
extern bw_hw_t g_hw;
void bw_hw_detect(void);

/* ------------------------------------------------------------ trap control (trap.c / startup.S) */
typedef struct { uint32_t ra, t0, t1, t2, a0, a1, a2, a3, a4, a5, a6, a7, t3, t4, t5, t6; } bw_frame_t;

typedef struct {
  volatile uint32_t armed, resume;          /* catch mode                                  */
  volatile uint32_t hit, cause, epc, tval, mstatus; /* first exception captured while armed (+mstatus)*/
  volatile uint32_t in_test;                /* an unexpected exception aborts the test     */
  volatile uint32_t un_cause, un_epc, un_tval;
  volatile uint32_t irq_count, irq_seen, irq_epc, irq_mstatus, irq_ack, irq_stuck, irq_badcause;
} bw_trapctl_t;
extern bw_trapctl_t bw_tc;

#define BW_RESUME_SKIP 0u   /* continue at mepc + 4                                   */
#define BW_RESUME_RA   1u   /* continue at the ra value saved at trap time            */
void     bw_catch(uint32_t resume);   /* arm: capture (and resume from) the next exception */
uint32_t bw_caught(void);             /* disarm; returns the number captured (0 or 1)      */
void     bw_fatal(uint32_t cause, uint32_t epc) __attribute__((noreturn));

typedef struct { uint32_t r[14]; } bw_jmp_t;
int  bw_setjmp(bw_jmp_t *c) __attribute__((returns_twice));
void bw_longjmp(bw_jmp_t *c, int v) __attribute__((noreturn));
extern bw_jmp_t bw_test_ctx;

/* ------------------------------------------------------------ trigger stubs (probes.S) */
/* Each stub executes exactly one instruction of interest at the exported *_insn label. */
extern uint32_t bw_trig_ecall(uint32_t), bw_trig_ebreak(uint32_t), bw_trig_illegal(uint32_t);
extern uint32_t bw_trig_jalr(uint32_t), bw_trig_jump(uint32_t);
extern uint32_t bw_trig_lw(uint32_t), bw_trig_sw(uint32_t), bw_trig_sb(uint32_t);
extern uint32_t bw_trig_mul(uint32_t, uint32_t), bw_trig_amo(uint32_t), bw_trig_rvc(uint32_t), bw_trig_fadd(uint32_t);
extern uint32_t bw_trig_csr_read(void), bw_trig_csr_write(void);
extern uint32_t bw_trig_csr_hpm(void), bw_trig_csr_dcsr(void);
extern char bw_trig_ecall_insn[], bw_trig_ebreak_insn[], bw_trig_illegal_insn[];
extern char bw_trig_jalr_insn[], bw_trig_jump_insn[], bw_trig_lw_insn[], bw_trig_sw_insn[], bw_trig_sb_insn[];
extern char bw_trig_mul_insn[], bw_trig_amo_insn[], bw_trig_rvc_insn[], bw_trig_fadd_insn[];
extern char bw_trig_csr_write_insn[], bw_trig_csr_hpm_insn[], bw_trig_csr_dcsr_insn[];
extern uint32_t bw_isa_nops17(void);   /* retires exactly 17 instructions between two minstret reads */
/* spin until *flag != 0 or `max` cycles after `start`; the loop body is [bw_irq_spin_loop, bw_irq_spin_end) */
extern uint32_t bw_irq_spin(volatile uint32_t *flag, uint32_t start, uint32_t max);
extern char bw_irq_spin_loop[], bw_irq_spin_end[];

/* ------------------------------------------------------------ library (libc.c, boot_status.c) */
void    *memset(void *d, int c, uint32_t n);
void    *memcpy(void *d, const void *s, uint32_t n);
uint32_t bw_crc32(const void *p, uint32_t len, uint32_t crc);

/* ------------------------------------------------------------ test infrastructure (boot_status.c) */
typedef bw_result_t (*bw_test_fn)(void);
extern bw_report_t g_report;
void bw_status_set(uint32_t v);                 /* MGMT.FW_STATUS */
void bw_report_init(void);
void bw_run_tests(const bw_test_fn *fn, const uint8_t *prereq, uint32_t n);
void bw_report_finalize(void);
void bw_report_start_record(void);
void bw_cleanup_hw(void);                       /* between tests: windows closed, IRQ off, sticky cleared */
void bw_irq_clear_all(void);
void bw_win_close_all(void);

/* ------------------------------------------------------------ memory test support (memory_test.c) */
typedef struct { uint32_t base, bytes; } bw_region_t;
#define BW_MAX_REGIONS 10u
extern bw_region_t g_regions[BW_MAX_REGIONS];
extern uint32_t g_nregions;
void bw_mem_init(void);                         /* paint stack canary, build safe region list */
uint32_t bw_fw_banks(void);                     /* banks that hold firmware (first 32 KiB): 2 (16 KiB banks) or 1 (32 KiB) */
uint32_t bw_ndata(void);                        /* banks above the firmware: destructive-test and DMA targets */
uint32_t bw_data_bank(uint32_t i);              /* physical bank number of data bank i */
uint32_t bw_data_base(uint32_t i);              /* byte address of data bank i */
uint32_t bw_image_crc(void);

/* ------------------------------------------------------------ DMA helper (dma_test.c) */
typedef struct { uint32_t status, bytes, err_addr, cycles; uint32_t timed_out; } bw_dma_res_t;
bw_dma_res_t bw_dma_run(uint32_t src, uint32_t dst, uint32_t len, uint32_t domain, uint32_t fill, uint32_t pattern);
#define BW_DMA_ST_DONE   ALBION_DMA_STATUS_DONE_MASK
#define BW_DMA_ST_ERROR  ALBION_DMA_STATUS_ERROR_MASK
#define BW_DMA_ERRCODE(st) (((st) & ALBION_DMA_STATUS_ERR_CODE_MASK) >> ALBION_DMA_STATUS_ERR_CODE_LSB)
void bw_win_set(uint32_t idx, uint32_t base, uint32_t limit, uint32_t attr);

/* ------------------------------------------------------------ test entry points */
#define BW_X_PROTO(n, s, d) bw_result_t bw_test_##n(void);
BW_TEST_LIST(BW_X_PROTO)
#undef BW_X_PROTO

#endif /* BW_INTERNAL_H */
