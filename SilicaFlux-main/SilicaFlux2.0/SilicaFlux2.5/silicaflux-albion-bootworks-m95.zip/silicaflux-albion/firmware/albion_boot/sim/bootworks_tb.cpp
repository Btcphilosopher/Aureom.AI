// BootWorks RTL boot harness - SilicaFlux Albion (Module 95).
//
// Plays the HOST around sf_albion_cloud_top exactly as the hardware boot protocol defines:
//   1. pin reset, wait for SRAM scrub-on-reset (DEV_STATUS.INIT_DONE)
//   2. BOOT_MODE: write the firmware image into SRAM bank 0.. through the host MMIO port, read it back word by word
//   3. MGMT.CORE_CTRL.RUN = 1: the ControlCore leaves reset at PC 0 and fetches the image from the RTL SRAM
//   4. watch the run (no host traffic that could perturb timing): live FW_STATUS timeline, host watchdog
//   5. on completion: halt the core (RUN = 0 re-enters BOOT_MODE), read the CRC-protected report out of SRAM,
//      pop the mailbox completion records, validate the completion signature
//
// While the CPU runs, three independent checkers watch the REAL RTL every cycle:
//   * fetch-path monitor : every instruction-fetch handshake on fabric master 0 (address, response word, error)
//                          is compared with the firmware image; every retired instruction must be the word fetched
//   * reference model    : an RV32I+Zicsr model re-computes every retired instruction (rd value, next PC, branch
//                          decision, trap vector, mret target) from the retirement trace; any divergence is a CPU defect
//   * coverage           : which instruction words and which function entries actually retired
//
// Output: a JSON result file (consumed by tools/bw_check.py) and a human-readable boot log on stdout.
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>

#include "Vsf_albion_cloud_top.h"
#include "Vsf_albion_cloud_top___024root.h"
#include "verilated.h"
#include "bw_status.h"

#define R(sig) (top_->rootp->sf_albion_cloud_top__DOT__##sig)

namespace {

constexpr uint32_t MGMT = 0x40000000u;
enum { O_CHIP = 0x000, O_CFG = 0x008, O_FEATI = 0x00C, O_NB = 0x018, O_BB = 0x01C, O_DEVST = 0x040, O_CORECTRL = 0x044,
       O_FWSTATUS = 0x050, O_FWVER = 0x054, O_HB = 0x058, O_SCRATCH = 0x05C, O_HCPL0 = 0x140, O_HCPLPOP = 0x150, O_HCPLQ = 0x154 };

uint32_t crc32_zlib(const uint8_t *p, size_t n, uint32_t crc = 0) {
  crc = ~crc;
  for (size_t i = 0; i < n; i++) {
    crc ^= p[i];
    for (int k = 0; k < 8; k++) crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
  }
  return ~crc;
}

std::string hex(uint32_t v) { char b[16]; snprintf(b, sizeof b, "0x%08X", v); return b; }
std::string jstr(const std::string &s) {
  std::string o = "\"";
  for (char c : s) { if (c == '"' || c == '\\') o += '\\'; if (c == '\n') o += "\\n"; else o += c; }
  return o + "\"";
}

// ------------------------------------------------------------------------------------------ expectation file
struct Expect {
  uint32_t entry = 0, text_lo = 0, text_hi = 0, image_end = 0;
  std::map<std::string, uint32_t> sym;
  struct Func { std::string name; uint32_t addr, size; };
  std::vector<Func> funcs;                       // every function with its address range
  std::vector<std::pair<std::string, uint32_t>> milestones;
  std::vector<uint32_t> excluded;                // word addresses that are data inside .text (sandbox, padding, probe words)
  bool load(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return false;
    char line[512];
    while (fgets(line, sizeof line, f)) {
      char a[128]; unsigned x, y;
      if (sscanf(line, "entry %x", &x) == 1) entry = x;
      else if (sscanf(line, "text %x %x", &x, &y) == 2) { text_lo = x; text_hi = y; }
      else if (sscanf(line, "image_end %x", &x) == 1) image_end = x;
      else if (sscanf(line, "sym %127s %x", a, &x) == 2) sym[a] = x;
      else if (sscanf(line, "func %127s %x %x", a, &x, &y) == 3) funcs.push_back({a, x, y});
      else if (sscanf(line, "milestone %127s %x", a, &x) == 2) milestones.push_back({a, x});
      else if (sscanf(line, "exclude %x %x", &x, &y) == 2) for (uint32_t w = x; w < y; w += 4) excluded.push_back(w);
    }
    fclose(f);
    return true;
  }
};

// ------------------------------------------------------------------------------------------ reference model
struct Ev { bool trap; uint32_t pc, insn, cause; bool rd_we; uint32_t rd, rd_wdata; };

struct Mismatch { uint64_t cycle; std::string kind; uint32_t pc, insn, expected, actual; };

class RefModel {
 public:
  uint32_t x[32] = {0};
  uint32_t mepc = 0; bool mepc_known = false;
  bool have_next = false; uint32_t next = 0; uint32_t prev_pc = 0, prev_insn = 0;
  bool after_trap = false;
  bool first = true;
  uint64_t checked = 0, nmis = 0;
  std::vector<Mismatch> mis;
  uint32_t trap_vec_a = 0, trap_vec_b = 0;

  void fail(uint64_t cyc, const char *k, uint32_t pc, uint32_t insn, uint32_t e, uint32_t a) {
    nmis++;
    if (mis.size() < 24) mis.push_back({cyc, k, pc, insn, e, a});
  }

  void step(uint64_t cyc, const Ev &ev) {
    if (first) { if (ev.pc != 0) fail(cyc, "reset vector: first event not at PC 0", ev.pc, ev.insn, 0, ev.pc); first = false; }
    if (have_next) {
      if (ev.pc != next) fail(cyc, "next-pc continuity", prev_pc, prev_insn, next, ev.pc);
      have_next = false;
    }
    if (after_trap) {
      if (ev.pc != trap_vec_a && ev.pc != trap_vec_b) fail(cyc, "trap vector", ev.pc, ev.insn, trap_vec_b, ev.pc);
      after_trap = false;
    }
    if (ev.trap) { mepc = ev.pc; mepc_known = true; after_trap = true; return; }

    checked++;
    const uint32_t w = ev.insn, pc = ev.pc;
    const uint32_t opc = w & 0x7F, rd = (w >> 7) & 31, f3 = (w >> 12) & 7, rs1 = (w >> 15) & 31, rs2 = (w >> 20) & 31, f7 = w >> 25;
    const int32_t imm_i = (int32_t)w >> 20;
    const int32_t imm_b = (int32_t)(((int32_t)(w & 0x80000000u) >> 19) | ((w & 0x80u) << 4) | ((w >> 20) & 0x7E0u) | ((w >> 7) & 0x1Eu));
    const uint32_t imm_u = w & 0xFFFFF000u;
    const int32_t imm_j = (int32_t)(((int32_t)(w & 0x80000000u) >> 11) | (w & 0xFF000u) | ((w >> 9) & 0x800u) | ((w >> 20) & 0x7FEu));
    const uint32_t a = x[rs1], b = x[rs2];
    bool has_rd_exp = false; uint32_t erd = 0; bool has_next = true; uint32_t enext = pc + 4;
    bool writes_rd = false;                                  // does this instruction have a destination register at all?
    int cls = C_OTHER;
    switch (opc) {
      case 0x37: cls = C_LUI;   writes_rd = has_rd_exp = true; erd = imm_u; break;
      case 0x17: cls = C_AUIPC; writes_rd = has_rd_exp = true; erd = pc + imm_u; break;
      case 0x6F: cls = C_JAL;   writes_rd = has_rd_exp = true; erd = pc + 4; enext = pc + (uint32_t)imm_j; break;
      case 0x67: cls = C_JALR;  writes_rd = has_rd_exp = true; erd = pc + 4; enext = (a + (uint32_t)imm_i) & ~1u; break;
      case 0x63: {
        cls = C_BRANCH; bool t = false;
        switch (f3) {
          case 0: t = a == b; break; case 1: t = a != b; break;
          case 4: t = (int32_t)a < (int32_t)b; break; case 5: t = (int32_t)a >= (int32_t)b; break;
          case 6: t = a < b; break; case 7: t = a >= b; break;
        }
        if (t) enext = pc + (uint32_t)imm_b;
        break;
      }
      case 0x03: cls = C_LOAD; writes_rd = true; break;
      case 0x23: cls = C_STORE; break;
      case 0x13: {
        cls = C_OPIMM; writes_rd = has_rd_exp = true; const uint32_t sh = rs2;
        switch (f3) {
          case 0: erd = a + (uint32_t)imm_i; break;
          case 2: erd = (int32_t)a < imm_i; break;
          case 3: erd = a < (uint32_t)imm_i; break;
          case 4: erd = a ^ (uint32_t)imm_i; break;
          case 6: erd = a | (uint32_t)imm_i; break;
          case 7: erd = a & (uint32_t)imm_i; break;
          case 1: erd = a << sh; break;
          case 5: erd = (f7 & 0x20) ? (uint32_t)((int32_t)a >> sh) : (a >> sh); break;
        }
        break;
      }
      case 0x33: {
        cls = C_OP; writes_rd = has_rd_exp = true;
        switch (f3) {
          case 0: erd = (f7 & 0x20) ? a - b : a + b; break;
          case 1: erd = a << (b & 31); break;
          case 2: erd = (int32_t)a < (int32_t)b; break;
          case 3: erd = a < b; break;
          case 4: erd = a ^ b; break;
          case 5: erd = (f7 & 0x20) ? (uint32_t)((int32_t)a >> (b & 31)) : (a >> (b & 31)); break;
          case 6: erd = a | b; break;
          case 7: erd = a & b; break;
        }
        break;
      }
      case 0x0F: cls = C_FENCE; break;
      case 0x73:
        if (f3 == 0) {
          if (w == 0x30200073u) { cls = C_MRET; if (mepc_known) enext = mepc; else has_next = false; }
          else if (w == 0x10500073u) cls = C_WFI;
          else cls = C_SYSTEM;
        } else {
          cls = C_CSR; writes_rd = true;
          if ((w >> 20) == 0x341) {                         // track writes to mepc (the trap handler rewrites it)
            if (f3 == 1)      { mepc = a; mepc_known = true; }
            else if (f3 == 5) { mepc = rs1; mepc_known = true; }
            else if (f3 != 2 && f3 != 3 && f3 != 6 && f3 != 7) mepc_known = false;
            else if (rs1 != 0) mepc_known = false;          // read-modify-write with unknown old value
          }
        }
        break;
      default: fail(cyc, "retired an instruction outside RV32I+Zicsr", pc, w, 0, w); has_next = false; break;
    }
    hist[cls]++;
    if (!writes_rd) {
      if (ev.rd_we) fail(cyc, "instruction without a destination wrote a register", pc, w, 0, ev.rd);
    } else if (rd != 0) {
      if (!ev.rd_we || ev.rd != rd) fail(cyc, "destination register write missing/wrong", pc, w, rd, ev.rd_we ? ev.rd : 0xFFFFFFFFu);
      else if (has_rd_exp && ev.rd_wdata != erd) fail(cyc, "rd value", pc, w, erd, ev.rd_wdata);
    } else if (ev.rd_we) fail(cyc, "write to x0", pc, w, 0, ev.rd_wdata);
    if (ev.rd_we && ev.rd != 0) x[ev.rd] = ev.rd_wdata;
    if (has_next) { have_next = true; next = enext; prev_pc = pc; prev_insn = w; }
  }
  enum { C_OTHER, C_LUI, C_AUIPC, C_JAL, C_JALR, C_BRANCH, C_LOAD, C_STORE, C_OPIMM, C_OP, C_FENCE, C_MRET, C_WFI, C_SYSTEM, C_CSR, C_N };
  static constexpr const char *cname[C_N] = { "other", "lui", "auipc", "jal", "jalr", "branch", "load", "store", "op-imm", "op", "fence", "mret", "wfi", "system", "csr" };
  uint64_t hist[C_N] = {0};
};
constexpr const char *RefModel::cname[RefModel::C_N];

// ------------------------------------------------------------------------------------------ simulation
class Sim {
 public:
  Sim(VerilatedContext *ctx) : top_(new Vsf_albion_cloud_top{ctx}) {
    // Power-on: rst_ni is asserted ASYNCHRONOUSLY (sf_albion_rstctl, negedge rst_ni). A pin that is low from t=0 creates no
    // edge in simulation, so with randomised initial state the internal reset would hold a random value until the first
    // clock. Pulse the pin high then low, which is what a board's power-good release/assert does.
    top_->clk_i = 0; top_->rst_ni = 1; top_->dbg_strap_i = 0; top_->h_req_valid_i = 0;
    top_->hm_req_ready_i = 1; top_->hm_rsp_valid_i = 0; top_->eval();
    top_->rst_ni = 0; top_->eval();
  }
  ~Sim() { top_->final(); }

  uint64_t cycle = 0;
  bool monitor = false;                       // fetch / reference / coverage monitors on
  const std::vector<uint8_t> *image = nullptr;
  const Expect *ex = nullptr;
  RefModel ref;
  bool use_ref = true;
  FILE *trace = nullptr;

  // fetch-path monitor results
  uint64_t fetch_ok = 0, fetch_err = 0, fetch_img_mismatch = 0, retire_vs_fetch_mismatch = 0, fetch_total = 0;
  std::vector<Mismatch> fetch_mis;
  uint32_t last_fetch_pc = 0xFFFFFFFFu, last_fetch_word = 0;
  uint64_t first_retire_cycle = 0, retired = 0, traps = 0;
  uint32_t first_pc = 0xFFFFFFFFu, first_insn = 0;
  std::vector<uint32_t> pc_hits = std::vector<uint32_t>(0x4000, 0);   // word index (pc>>2, first 64 KiB) -> retire count
  std::vector<uint32_t> trap_hits = std::vector<uint32_t>(0x4000, 0); // word index -> synchronous exceptions raised BY that instruction
  std::map<uint32_t, uint64_t> trap_causes;
  std::vector<uint32_t> fetch_err_pcs;

  void tick() {
    top_->clk_i = 0;
    const bool rsp_now = hm_pending_ && cycle >= hm_due_;
    top_->hm_rsp_valid_i = rsp_now;
    top_->hm_rsp_rdata_i = rsp_now ? hm_rdata_ : 0;
    top_->hm_rsp_err_i = rsp_now ? hm_err_ : 0;
    top_->hm_req_ready_i = !hm_pending_ || rsp_now;
    top_->eval();

    const bool hm_hs = top_->hm_req_valid_o && top_->hm_req_ready_i;
    const uint32_t hm_addr = top_->hm_req_addr_o, hm_wdata = top_->hm_req_wdata_o;
    const bool hm_we = top_->hm_req_we_o;
    h_hs_ = top_->h_req_valid_i && top_->h_req_ready_o;
    h_rsp_ = top_->h_rsp_valid_o; h_rsp_data_ = top_->h_rsp_rdata_o; h_rsp_err_ = top_->h_rsp_err_o;
    if (monitor) observe();

    top_->clk_i = 1;
    top_->eval();
    cycle++;
    if (rsp_now) hm_pending_ = false;
    if (hm_hs) {                              // simple host-memory model: nothing here is needed by BootWorks
      hm_err_ = hm_addr >= 0x40000000u;
      if (hm_we) hm_mem_[hm_addr & ~3u] = hm_wdata; else hm_rdata_ = hm_mem_.count(hm_addr & ~3u) ? hm_mem_[hm_addr & ~3u] : 0;
      hm_pending_ = true; hm_due_ = cycle;
    }
    if (h_hs_) top_->h_req_valid_i = 0;
  }

  void reset() {
    top_->rst_ni = 0; top_->h_req_valid_i = 0; hm_pending_ = false;
    for (int i = 0; i < 8; i++) tick();
    top_->rst_ni = 1;
    for (int i = 0; i < 4; i++) tick();
  }

  bool mmio(uint32_t addr, bool we, uint32_t wdata, uint32_t &rdata, uint32_t &err) {
    top_->h_req_valid_i = 1; top_->h_req_addr_i = addr; top_->h_req_we_i = we; top_->h_req_wdata_i = wdata; top_->h_req_wstrb_i = 0xF;
    bool acc = false;
    for (int i = 0; i < 100000 && !acc; i++) { tick(); acc = h_hs_; }
    if (!acc) { top_->h_req_valid_i = 0; return false; }
    for (int i = 0; i < 100000; i++) { tick(); if (h_rsp_) { rdata = h_rsp_data_; err = h_rsp_err_; return true; } }
    return false;
  }
  uint32_t rd(uint32_t addr, uint32_t *err = nullptr) { uint32_t d = 0, e = 0xFFFF; mmio(addr, false, 0, d, e); if (err) *err = e; return d; }
  uint32_t wr(uint32_t addr, uint32_t v) { uint32_t d, e = 0xFFFF; mmio(addr, true, v, d, e); return e; }

  // live peeks (no bus traffic, no perturbation)
  uint32_t fw_status() { return R(u_mgmt__DOT__fw_status); }
  uint32_t fw_heartbeat() { return R(u_mgmt__DOT__fw_heartbeat); }
  bool irq_line() { return top_->host_irq_o; }

 private:
  void observe() {
    const uint32_t state = R(u_core__DOT__state);
    const uint32_t pc = R(u_core__DOT__pc);
    // -- fetch handshake response: core in FETCH_WAIT (state 1) and fabric answers master 0
    if (state == 1 && (R(m_rsp_valid) & 1u)) {
      const uint32_t word = R(m_rsp_rdata)[0];
      const uint32_t err = R(m_rsp_err) & 7u;
      fetch_total++;
      last_fetch_pc = pc; last_fetch_word = word;
      if (err) {
        fetch_err++; if (fetch_err_pcs.size() < 16) fetch_err_pcs.push_back(pc);
      } else {
        fetch_ok++;
        if (image && ex && pc < ex->image_end && pc + 4 <= image->size()) {
          uint32_t want; memcpy(&want, image->data() + pc, 4);
          if (want != word) { fetch_img_mismatch++; if (fetch_mis.size() < 16) fetch_mis.push_back({cycle, "fetched word differs from image", pc, word, want, word}); }
        }
      }
    }
    // -- retirement / trap trace
    if (top_->trace_valid_o) {
      Ev ev{(bool)top_->trace_trap_o, top_->trace_pc_o, top_->trace_insn_o, top_->trace_cause_o, (bool)top_->trace_rd_we_o,
            top_->trace_rd_o, top_->trace_rd_wdata_o};
      if (trace) fprintf(trace, "%llu %08x %08x %d %d %08x %08x\n", (unsigned long long)cycle, ev.pc, ev.insn, ev.trap, ev.rd_we, ev.rd_wdata, ev.cause);
      if (ev.trap) {
        traps++; trap_causes[ev.cause]++;
        if (!(ev.cause & 0x80000000u) && (ev.pc >> 2) < trap_hits.size()) trap_hits[ev.pc >> 2]++;   // the faulting instruction was reached
      }
      else {
        retired++;
        if (first_pc == 0xFFFFFFFFu) { first_pc = ev.pc; first_insn = ev.insn; first_retire_cycle = cycle; }
        if ((ev.pc >> 2) < pc_hits.size()) pc_hits[ev.pc >> 2]++;
        if (ev.pc != last_fetch_pc || ev.insn != last_fetch_word) {
          retire_vs_fetch_mismatch++;
          if (fetch_mis.size() < 16) fetch_mis.push_back({cycle, "retired instruction is not the word fetched", ev.pc, ev.insn, last_fetch_word, ev.insn});
        }
      }
      if (use_ref) ref.step(cycle, ev);
    }
  }

  std::unique_ptr<Vsf_albion_cloud_top> top_;
  bool hm_pending_ = false, hm_err_ = false, h_hs_ = false, h_rsp_ = false;
  uint64_t hm_due_ = 0;
  uint32_t hm_rdata_ = 0, h_rsp_data_ = 0, h_rsp_err_ = 0;
  std::map<uint32_t, uint32_t> hm_mem_;
};

}  // namespace

// ------------------------------------------------------------------------------------------ main
int main(int argc, char **argv) {
  auto ctx = std::make_unique<VerilatedContext>();
  ctx->commandArgs(argc, argv);
  std::string image_path, expect_path, json_path, trace_path, seq_path;
  uint64_t max_cycles = 60000000ull, stall_cycles = 8000000ull;
  bool use_ref = true, quiet = false, stall_given = false;
  int inject_corrupt = -1;                       // test hook: flip a bit of the loaded image word N after verification passes (negative test)
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    auto val = [&](const char *p) { return a.substr(strlen(p)); };
    if (a.rfind("--image=", 0) == 0) image_path = val("--image=");
    else if (a.rfind("--expect=", 0) == 0) expect_path = val("--expect=");
    else if (a.rfind("--json=", 0) == 0) json_path = val("--json=");
    else if (a.rfind("--trace=", 0) == 0) trace_path = val("--trace=");
    else if (a.rfind("--seq=", 0) == 0) seq_path = val("--seq=");
    else if (a.rfind("--max-cycles=", 0) == 0) max_cycles = strtoull(val("--max-cycles=").c_str(), nullptr, 0);
    else if (a.rfind("--stall-cycles=", 0) == 0) { stall_cycles = strtoull(val("--stall-cycles=").c_str(), nullptr, 0); stall_given = true; }
    else if (a == "--no-ref") use_ref = false;
    else if (a == "--quiet") quiet = true;
    else if (a.rfind("--corrupt-word=", 0) == 0) inject_corrupt = (int)strtol(val("--corrupt-word=").c_str(), nullptr, 0);
  }
  if (image_path.empty() || expect_path.empty()) { fprintf(stderr, "usage: bootworks_tb --image=bin --expect=file [--json=out] [--trace=file] [--max-cycles=N] [--stall-cycles=N]\n"); return 2; }

  std::vector<uint8_t> img;
  { FILE *f = fopen(image_path.c_str(), "rb"); if (!f) { perror(image_path.c_str()); return 2; }
    uint8_t buf[4096]; size_t n; while ((n = fread(buf, 1, sizeof buf, f)) > 0) img.insert(img.end(), buf, buf + n); fclose(f); }
  while (img.size() % 4) img.push_back(0);
  Expect ex;
  if (!ex.load(expect_path.c_str())) { fprintf(stderr, "cannot read %s\n", expect_path.c_str()); return 2; }

  Sim sim(ctx.get());
  sim.image = &img; sim.ex = &ex; sim.use_ref = use_ref;
  sim.ref.trap_vec_a = ex.sym.count("bw_trap_entry") ? ex.sym["bw_trap_entry"] : 0;
  sim.ref.trap_vec_b = ex.sym.count("bw_early_trap") ? ex.sym["bw_early_trap"] : sim.ref.trap_vec_a;
  if (!trace_path.empty()) sim.trace = fopen(trace_path.c_str(), "w");

  std::vector<std::string> notes;          // host-side findings (human readable), emitted in the JSON
  auto say = [&](const std::string &s) { if (!quiet) { fputs(s.c_str(), stdout); fputc('\n', stdout); fflush(stdout); } };
  char tmp[512];

  // ---- 1-3. reset, scrub, load, verify, release the core: either the built-in host flow or a replay of the generated sequence
  uint64_t scrub_cycles = 0, run0 = 0; uint32_t chip = 0, cfg = 0, nb = 0, bb = 0, dev = 0;
  uint32_t load_errs = 0, verify_bad = 0, first_bad = 0xFFFFFFFFu; bool boot_mode_ok = false;
  uint32_t seq_ops = 0, seq_bad = 0, seq_timeouts = 0;
  sim.reset();
  chip = sim.rd(MGMT + O_CHIP); cfg = sim.rd(MGMT + O_CFG); nb = sim.rd(MGMT + O_NB); bb = sim.rd(MGMT + O_BB);
  // Host watchdog: no change of FW_STATUS/FW_HEARTBEAT for this long means a hang. The longest test sweeps every word of every data
  // bank ~10 times at ~50 cycles per word, so the limit scales with the SRAM size (explicit --stall-cycles overrides it).
  if (!stall_given) stall_cycles = 8000000ull + (uint64_t)nb * (bb / 4) * 600ull;
  snprintf(tmp, sizeof tmp, "[host] CHIP_ID=%s CONFIG=%u SRAM=%u x %u KiB, image %zu bytes%s", hex(chip).c_str(), cfg, nb, bb / 1024, img.size(),
           seq_path.empty() ? "" : " (replaying the generated host sequence)");
  say(tmp);
  if (seq_path.empty()) {
    uint64_t scrub0 = sim.cycle;
    while (sim.cycle - scrub0 < 400000ull) { dev = sim.rd(MGMT + O_DEVST); if (dev & 1u) break; }   // bounded by cycles, not polls
    scrub_cycles = sim.cycle - scrub0;
    snprintf(tmp, sizeof tmp, "[host] scrub-on-reset complete after %llu cycles, DEV_STATUS=%s (BOOT_MODE=%u CORE_RUN=%u)",
             (unsigned long long)sim.cycle, hex(dev).c_str(), (dev >> 4) & 1u, (dev >> 1) & 1u);
    say(tmp);
    boot_mode_ok = (dev & 0x11u) == 0x11u && !(dev & 0x6u);
    if (!boot_mode_ok) { say("[host] ERROR: device did not reach BOOT_MODE after reset (INIT_DONE / BOOT_MODE not set)"); return 3; }
    uint64_t t_load = sim.cycle;
    for (size_t i = 0; i < img.size(); i += 4) { uint32_t w; memcpy(&w, &img[i], 4); load_errs += sim.wr((uint32_t)i, w) != 0; }
    for (size_t i = 0; i < img.size(); i += 4) {
      uint32_t w; memcpy(&w, &img[i], 4); uint32_t e; uint32_t v = sim.rd((uint32_t)i, &e);
      if (v != w || e != 0) { if (!verify_bad) first_bad = (uint32_t)i; verify_bad++; }
    }
    snprintf(tmp, sizeof tmp, "[host] image written and read back through the host port: %zu words, %u write errors, %u mismatches (%llu cycles)",
             img.size() / 4, load_errs, verify_bad, (unsigned long long)(sim.cycle - t_load));
    say(tmp);
    if (inject_corrupt >= 0 && (size_t)inject_corrupt * 4 < img.size()) {   // negative-test hook: image damaged AFTER the host's own verify
      uint32_t w = sim.rd(inject_corrupt * 4); sim.wr(inject_corrupt * 4, w ^ 0x00000400u);
      say("[host] TEST HOOK: flipped one bit of image word " + std::to_string(inject_corrupt));
    }
    sim.monitor = true;
    run0 = sim.cycle;
    sim.wr(MGMT + O_CORECTRL, 1u);
    say("[host] CORE_CTRL.RUN = 1: ControlCore leaves reset at PC 0x00000000");
  } else {
    struct Op { char op; uint32_t addr, a, b, t; bool eq; std::string sec; };
    std::vector<Op> ops; std::string sec;
    { FILE *f = fopen(seq_path.c_str(), "r"); if (!f) { perror(seq_path.c_str()); return 2; } char line[512];
      while (fgets(line, sizeof line, f)) {
        if (strncmp(line, "#SECTION ", 9) == 0) { char n[64]; sscanf(line + 9, "%63s", n); sec = n; continue; }
        if (line[0] == '#' || line[0] == '\n') continue;
        char *c = strchr(line, '#'); if (c) *c = 0;
        Op o{}; o.sec = sec; char opc[8]; unsigned x, y, z, w; char kw[8];
        if (sscanf(line, "%7s", opc) != 1) continue;
        o.op = opc[0] == 'P' && opc[1] == 'A' ? 'A' : opc[0];
        if (o.op == 'W' && sscanf(line, "W %x %x", &x, &y) == 2) { o.addr = x; o.a = y; }
        else if (o.op == 'R') { if (sscanf(line, "R %x %7s %x", &x, kw, &y) == 3) { o.addr = x; o.a = y; o.eq = true; } else if (sscanf(line, "R %x", &x) == 1) o.addr = x; else continue; }
        else if (o.op == 'P' && sscanf(line, "P %x %x %x %u", &x, &y, &z, &w) == 4) { o.addr = x; o.a = y; o.b = z; o.t = w; }
        else if (o.op == 'A' && sscanf(line, "PA %x %x %x %u", &x, &y, &z, &w) == 4) { o.addr = x; o.a = y; o.b = z; o.t = w; }
        else continue;
        ops.push_back(o);
      }
      fclose(f); }
    uint64_t t_load = sim.cycle; bool running = false;
    for (auto &o : ops) {
      if (o.sec == "wait-complete") break;                                  // the watch loop below takes over
      if (o.sec == "run" && !running) { sim.monitor = true; run0 = sim.cycle; running = true; }
      seq_ops++;
      if (o.op == 'W') { uint32_t e = sim.wr(o.addr, o.a); if (e) { seq_bad++; if (o.sec == "load") load_errs++; } }
      else if (o.op == 'R') { uint32_t e, v = sim.rd(o.addr, &e); if (e || (o.eq && v != o.a)) { seq_bad++; if (o.sec == "verify") { if (!verify_bad) first_bad = o.addr; verify_bad++; } } }
      else if (o.op == 'P') { uint64_t t0 = sim.cycle; bool ok = false; uint32_t v = 0;
        while (sim.cycle - t0 < o.t) { v = sim.rd(o.addr); if ((v & o.a) == o.b) { ok = true; break; } }
        if (!ok) { seq_timeouts++; } if (o.sec == "reset-wait") { scrub_cycles = sim.cycle - t0; dev = v; boot_mode_ok = ok; } }
    }
    snprintf(tmp, sizeof tmp, "[host] sequence replay: %u transactions (load %llu cycles), %u mismatches/errors, %u poll timeouts; core released",
             seq_ops, (unsigned long long)(sim.cycle - t_load), seq_bad, seq_timeouts);
    say(tmp);
    if (!boot_mode_ok) { say("[host] ERROR: BOOT_MODE not reached"); return 3; }
  }

  // ---- 4. watch the run
  struct Tl { uint64_t cycle; uint32_t status; uint32_t hb; };
  std::vector<Tl> timeline;
  uint32_t last_status = 0xFFFFFFFFu, last_hb = 0xFFFFFFFFu; uint64_t last_change = sim.cycle;
  std::string end_reason = "running";
  while (true) {
    sim.tick();
    uint32_t st = sim.fw_status(), hb = sim.fw_heartbeat();
    if (st != last_status || hb != last_hb) {
      if (st != last_status && timeline.size() < 4096) timeline.push_back({sim.cycle - run0, st, hb});
      last_status = st; last_hb = hb; last_change = sim.cycle;
      if (st == BW_SIG_PASS || st == BW_SIG_FAIL) { end_reason = "completion signature"; break; }
      if ((st >> 16) == 0xDEADu) { end_reason = "fatal trap signature"; break; }
    }
    if (sim.cycle - run0 > max_cycles) { end_reason = "TIMEOUT: max cycles"; break; }
    if (sim.cycle - last_change > stall_cycles) { end_reason = "TIMEOUT: host watchdog (FW_STATUS/FW_HEARTBEAT stalled)"; break; }
  }
  const uint64_t run_cycles = sim.cycle - run0;
  for (int i = 0; i < 40; i++) sim.tick();                // let the last stores and the mailbox push settle
  sim.monitor = false;
  snprintf(tmp, sizeof tmp, "[host] run ended: %s after %llu cycles, FW_STATUS=%s", end_reason.c_str(), (unsigned long long)run_cycles, hex(last_status).c_str());
  say(tmp);

  // ---- 5. host-side readout
  const uint32_t fw_status = sim.rd(MGMT + O_FWSTATUS), fw_ver = sim.rd(MGMT + O_FWVER), hb = sim.rd(MGMT + O_HB), scratch = sim.rd(MGMT + O_SCRATCH);
  const uint32_t dev_run = sim.rd(MGMT + O_DEVST);
  std::vector<std::array<uint32_t, 4>> mbx;
  { uint32_t cnt = sim.rd(MGMT + O_HCPLQ) & 0xFF;
    for (uint32_t i = 0; i < cnt && i < 16; i++) {
      std::array<uint32_t, 4> r{}; for (int k = 0; k < 4; k++) r[k] = sim.rd(MGMT + O_HCPL0 + 4 * k);
      mbx.push_back(r); sim.wr(MGMT + O_HCPLPOP, 1u);
    } }
  sim.wr(MGMT + O_CORECTRL, 0u);                          // halt: BOOT_MODE again, SRAM readable by the host
  const uint32_t dev_halt = sim.rd(MGMT + O_DEVST);
  const bool halted = ((dev_halt >> 4) & 1u) && !((dev_halt >> 1) & 1u);
  bw_report_t rep; memset(&rep, 0, sizeof rep);
  bool report_read = false;
  if (halted && ex.sym.count("g_report")) {
    uint32_t base = ex.sym["g_report"]; uint32_t *p = (uint32_t *)&rep; report_read = true;
    for (size_t i = 0; i < sizeof rep / 4; i++) { uint32_t e; p[i] = sim.rd(base + 4 * (uint32_t)i, &e); if (e) report_read = false; }
  }
  const uint32_t rep_crc = report_read ? crc32_zlib((const uint8_t *)&rep, offsetof(bw_report_t, crc)) : 0;
  // post-run image integrity as seen by the host: the firmware must not have altered its own code
  uint32_t image_changed = 0, first_changed = 0xFFFFFFFFu;
  if (halted) for (size_t i = 0; i < ex.image_end && i + 4 <= img.size(); i += 4) {
    uint32_t w; memcpy(&w, &img[i], 4); uint32_t e; uint32_t v = sim.rd((uint32_t)i, &e);
    if (v != w) { if (!image_changed) first_changed = (uint32_t)i; image_changed++; }
  }

  // ---- 6. report
  const bool sig_pass = fw_status == BW_SIG_PASS;
  const bool report_valid = report_read && rep.magic == BW_REPORT_MAGIC && rep.layout == BW_REPORT_LAYOUT && rep.crc == rep_crc &&
                            rep.state == BW_STATE_DONE && rep.n_tests == BW_NUM_TESTS && rep.n_done == BW_NUM_TESTS && rep.verdict == fw_status;
  static const char *names[] = { "PASS", "FAIL", "TIMEOUT", "SKIPPED", "UNSUPPORTED" };
  static const char *tname[] = {
#define BW_X_NAME(n, s, d) #n,
    BW_TEST_LIST(BW_X_NAME)
#undef BW_X_NAME
  };
  say("");
  say("================ BootWorks boot report (read from SRAM through the host port) ================");
  if (report_read) {
    snprintf(tmp, sizeof tmp, "report: magic %s layout %u  version %s  verdict %s  CRC %s (%s)", hex(rep.magic).c_str(), rep.layout, hex(rep.fw_version).c_str(),
             rep.verdict == BW_SIG_PASS ? "PASS" : rep.verdict == BW_SIG_FAIL ? "FAIL" : "?", hex(rep.crc).c_str(), rep.crc == rep_crc ? "valid" : "BAD");
    say(tmp);
    snprintf(tmp, sizeof tmp, "tests %u/%u  PASS %u  FAIL %u  TIMEOUT %u  SKIPPED %u  UNSUPPORTED %u   cycles %u  instret %u  stack peak %u B",
             rep.n_done, rep.n_tests, rep.count[0], rep.count[1], rep.count[2], rep.count[3], rep.count[4], rep.cycles, rep.instret, rep.stack_hwm);
    say(tmp);
    for (uint32_t i = 0; i < BW_NUM_TESTS && i < rep.n_tests; i++) {
      const bw_result_t &r = rep.results[i];
      snprintf(tmp, sizeof tmp, "  %2u %-14s %-11s %s%s", i, tname[i], r.outcome < 5 ? names[r.outcome] : "?", r.diag ? "diag " : "", r.diag ? hex(r.diag).c_str() : "");
      std::string line = tmp;
      if (r.diag) { snprintf(tmp, sizeof tmp, "  aux %s %s %s", hex(r.aux0).c_str(), hex(r.aux1).c_str(), hex(r.aux2).c_str()); line += tmp; }
      say(line);
    }
  } else say("report could not be read (core not halted or report region unreadable)");

  // ---- JSON
  if (!json_path.empty()) {
    FILE *j = fopen(json_path.c_str(), "w");
    fprintf(j, "{\n \"config\": %u, \"banks\": %u, \"bank_bytes\": %u, \"image_bytes\": %zu,\n", cfg, nb, bb, img.size());
    fprintf(j, " \"host\": {\"seq_replay\": %s, \"seq_ops\": %u, \"seq_errors\": %u, \"seq_poll_timeouts\": %u, \"chip_id\": %u, \"scrub_cycles\": %llu, \"boot_mode_before_load\": %s, \"load_write_errors\": %u, \"load_verify_mismatches\": %u,"
               " \"first_bad_word\": %u, \"halted_boot_mode\": %s, \"image_changed_words\": %u, \"first_changed\": %u, \"dev_status_running\": %u},\n",
            seq_path.empty() ? "false" : "true", seq_ops, seq_bad, seq_timeouts, chip, (unsigned long long)scrub_cycles, boot_mode_ok ? "true" : "false", load_errs, verify_bad, first_bad, halted ? "true" : "false", image_changed, first_changed, dev_run);
    fprintf(j, " \"run\": {\"end_reason\": %s, \"cycles\": %llu, \"fw_status\": %u, \"fw_version\": %u, \"heartbeat\": %u, \"scratch\": %u, \"signature_pass\": %s},\n",
            jstr(end_reason).c_str(), (unsigned long long)run_cycles, fw_status, fw_ver, hb, scratch, sig_pass ? "true" : "false");
    fprintf(j, " \"timeline\": [");
    for (size_t i = 0; i < timeline.size(); i++) fprintf(j, "%s[%llu,%u,%u]", i ? "," : "", (unsigned long long)timeline[i].cycle, timeline[i].status, timeline[i].hb);
    fprintf(j, "],\n \"mailbox\": [");
    for (size_t i = 0; i < mbx.size(); i++) fprintf(j, "%s[%u,%u,%u,%u]", i ? "," : "", mbx[i][0], mbx[i][1], mbx[i][2], mbx[i][3]);
    fprintf(j, "],\n \"report\": {\"read\": %s, \"valid\": %s, \"crc_stored\": %u, \"crc_computed\": %u", report_read ? "true" : "false", report_valid ? "true" : "false", rep.crc, rep_crc);
    if (report_read) {
      fprintf(j, ", \"magic\": %u, \"layout\": %u, \"fw_version\": %u, \"state\": %u, \"verdict\": %u, \"n_tests\": %u, \"n_done\": %u, \"counts\": [%u,%u,%u,%u,%u],"
                 " \"first_fail_diag\": %u, \"first_fail_test\": %u, \"config_id\": %u, \"feat_impl\": %u, \"banks_and_size\": %u, \"cycles\": %u, \"instret\": %u, \"stack_hwm\": %u,\n  \"results\": [",
              rep.magic, rep.layout, rep.fw_version, rep.state, rep.verdict, rep.n_tests, rep.n_done, rep.count[0], rep.count[1], rep.count[2], rep.count[3], rep.count[4],
              rep.first_fail_diag, rep.first_fail_test, rep.config_id, rep.feat_impl, rep.banks_and_size, rep.cycles, rep.instret, rep.stack_hwm);
      for (uint32_t i = 0; i < BW_NUM_TESTS; i++) { const bw_result_t &r = rep.results[i];
        fprintf(j, "%s{\"id\": %u, \"name\": %s, \"outcome\": %u, \"diag\": %u, \"aux\": [%u,%u,%u]}", i ? ",\n   " : "\n   ", i, jstr(tname[i]).c_str(), r.outcome, r.diag, r.aux0, r.aux1, r.aux2); }
      fprintf(j, "]");
    }
    fprintf(j, "},\n \"fetch\": {\"handshakes\": %llu, \"ok\": %llu, \"errors\": %llu, \"image_mismatches\": %llu, \"retire_vs_fetch_mismatches\": %llu, \"error_pcs\": [",
            (unsigned long long)sim.fetch_total, (unsigned long long)sim.fetch_ok, (unsigned long long)sim.fetch_err, (unsigned long long)sim.fetch_img_mismatch,
            (unsigned long long)sim.retire_vs_fetch_mismatch);
    for (size_t i = 0; i < sim.fetch_err_pcs.size(); i++) fprintf(j, "%s%u", i ? "," : "", sim.fetch_err_pcs[i]);
    fprintf(j, "], \"mismatches\": [");
    for (size_t i = 0; i < sim.fetch_mis.size(); i++) { auto &m = sim.fetch_mis[i];
      fprintf(j, "%s{\"cycle\": %llu, \"kind\": %s, \"pc\": %u, \"insn\": %u, \"expected\": %u, \"actual\": %u}", i ? "," : "", (unsigned long long)m.cycle, jstr(m.kind).c_str(), m.pc, m.insn, m.expected, m.actual); }
    fprintf(j, "]},\n \"retire\": {\"retired\": %llu, \"traps\": %llu, \"first_pc\": %u, \"first_insn\": %u, \"first_cycle\": %llu, \"trap_causes\": {",
            (unsigned long long)sim.retired, (unsigned long long)sim.traps, sim.first_pc, sim.first_insn, (unsigned long long)sim.first_retire_cycle);
    { bool f = true; for (auto &kv : sim.trap_causes) { fprintf(j, "%s\"%u\": %llu", f ? "" : ",", kv.first, (unsigned long long)kv.second); f = false; } }
    fprintf(j, "}, \"classes\": {");
    { bool f = true; for (int c = 0; c < RefModel::C_N; c++) if (sim.ref.hist[c]) { fprintf(j, "%s%s: %llu", f ? "" : ",", jstr(RefModel::cname[c]).c_str(), (unsigned long long)sim.ref.hist[c]); f = false; } }
    fprintf(j, "}},\n \"reference_model\": {\"enabled\": %s, \"checked\": %llu, \"mismatches\": %llu, \"first\": [", use_ref ? "true" : "false",
            (unsigned long long)sim.ref.checked, (unsigned long long)sim.ref.nmis);
    for (size_t i = 0; i < sim.ref.mis.size(); i++) { auto &m = sim.ref.mis[i];
      fprintf(j, "%s{\"cycle\": %llu, \"kind\": %s, \"pc\": %u, \"insn\": %u, \"expected\": %u, \"actual\": %u}", i ? "," : "", (unsigned long long)m.cycle, jstr(m.kind).c_str(), m.pc, m.insn, m.expected, m.actual); }
    fprintf(j, "]},\n \"coverage\": {\"milestones\": {");
    { bool f = true; for (auto &m : ex.milestones) {
        size_t wi = m.second >> 2; unsigned long long h = wi < sim.pc_hits.size() ? (unsigned long long)sim.pc_hits[wi] + sim.trap_hits[wi] : 0;
        fprintf(j, "%s%s: %llu", f ? "" : ",", jstr(m.first).c_str(), h); f = false; } }
    fprintf(j, "}, \"functions\": {");
    { std::set<uint32_t> excl(ex.excluded.begin(), ex.excluded.end()); bool f = true; uint64_t tot_words = 0, tot_hit = 0;
      for (auto &fn : ex.funcs) { uint32_t words = 0, hit = 0;
        for (uint32_t a = fn.addr; a < fn.addr + fn.size; a += 4) { if (excl.count(a)) continue; words++; if ((a >> 2) < sim.pc_hits.size() && (sim.pc_hits[a >> 2] || sim.trap_hits[a >> 2])) hit++; }
        tot_words += words; tot_hit += hit;
        fprintf(j, "%s%s: [%u,%u]", f ? "" : ",", jstr(fn.name).c_str(), words, hit); f = false; }
      fprintf(j, "}, \"words\": %llu, \"hit\": %llu", (unsigned long long)tot_words, (unsigned long long)tot_hit); }
    fprintf(j, "},\n \"signature\": {\"report_valid\": %s, \"fw_status_is_pass\": %s}\n}\n", report_valid ? "true" : "false", sig_pass ? "true" : "false");
    fclose(j);
  }
  if (sim.trace) fclose(sim.trace);

  const bool ok = sig_pass && report_valid && verify_bad == 0 && sim.fetch_img_mismatch == 0 && sim.retire_vs_fetch_mismatch == 0 && sim.ref.nmis == 0 && image_changed == 0;
  say("");
  snprintf(tmp, sizeof tmp, "[host] fetch-path: %llu instruction fetches, %llu image mismatches, %llu errors | reference model: %llu instructions checked, %llu mismatches",
           (unsigned long long)sim.fetch_total, (unsigned long long)sim.fetch_img_mismatch, (unsigned long long)sim.fetch_err, (unsigned long long)sim.ref.checked, (unsigned long long)sim.ref.nmis);
  say(tmp);
  snprintf(tmp, sizeof tmp, "[host] completion signature: FW_STATUS=%s (%s), report CRC %s, mailbox records %zu  ==> %s",
           hex(fw_status).c_str(), sig_pass ? "BOOT PASS" : fw_status == BW_SIG_FAIL ? "BOOT FAIL" : "no signature", report_valid ? "valid" : "INVALID", mbx.size(), ok ? "BOOT OK" : "BOOT NOT OK");
  say(tmp);
  return ok ? 0 : 1;
}
