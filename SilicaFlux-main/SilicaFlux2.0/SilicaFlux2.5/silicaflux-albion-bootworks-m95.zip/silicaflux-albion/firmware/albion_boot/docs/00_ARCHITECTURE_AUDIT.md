# 00 - Architecture audit of the SilicaFlux Albion control processor

Module 95 starts from the RTL, not from the RISC-V specification. Every statement below is traced to a line of the RTL in
`rtl/albion/` **and** was confirmed at run time by BootWorks itself on the Verilated RTL (the "measured" column names the
test and the value it read). Where the two disagreed the RTL won and the firmware was changed; they did not disagree.

> **No full RISC-V compliance is assumed or claimed.** The core implements a small, documented subset (below). BootWorks
> detects what is present by executing it, cross-checks the result against `misa`, and reports what is absent as
> `UNSUPPORTED` rather than failing or pretending.

## 0. Which processor is "the SilicaFlux control processor"?

The repository contains several RISC-V implementations. The target is **`sf_albion_controlcore`** (Albion, Project 90).

| candidate | where | ISA | verdict |
|---|---|---|---|
| **Albion ControlCore** `sf_albion_controlcore.sv` | `silicaflux-albion-p90.zip`, `rtl/albion/` | RV32I + Zicsr, M-mode | **chosen** |
| Project 21 ControlCore (`silicaflux-controlcore.zip`) | separate project, own boot ROM / UART / vector+tensor tiles | RV32IM_Zicsr | different RTL, not integrated in Albion |
| other RISC-V cores present (`rv32i_core.sv` in `RISC-V CPU.zip`, SilicaFlux-V, MCU-I) | various archives | not inspected beyond their file lists | not the Albion SoC |

Reasons for the choice: the requested directory `firmware/albion_boot/` sits beside the existing `firmware/albion/`; the module
numbering continues the Albion line (P90 platform, M94 formal, **M95 boot**); and the brief's "boot memory", "DMA
memory-to-memory", "interrupts where implemented" and "tensor where implemented" map onto Albion's SRAM banks, protected
DMA, IRQ page and (unavailable) ComputeWorks. The Project 21 core has a boot ROM and a UART that Albion does not; retargeting
BootWorks there is a different, larger job (see `05_LIMITATIONS.md`).

## 1. The answers

| question | answer | RTL evidence | measured by BootWorks |
|---|---|---|---|
| **Implemented ISA** | RV32I base (all 37 integer instructions), Zicsr (6 CSR instructions), `FENCE`/`FENCE.I` (accepted, no-ops), `ECALL`, `EBREAK`, `MRET`, `WFI`. **Not** implemented: M, A, C, F/D, S/U modes, PMP, debug | decode `sf_albion_controlcore.sv:166-241`; header comment lines 1-14 | `ISA_RV32I` PASS (every integer instruction class); `ISA_M/A/C/F` probes trap *illegal instruction* -> `UNSUPPORTED`; `ISA_FENCE` PASS |
| **Register width** | XLEN = 32 | `misa = 0x4000_0100` (`:105`): MXL=1, I only | `CPU_IDENT` read `misa = 0x40000100` |
| **Reset vector** | `RESET_PC = 0x0000_0000` (module parameter, not overridden by the SoC) | `:16`; instance `sf_albion_cloud_top.sv:144`; core is held in reset until `MGMT.CORE_CTRL.RUN=1` (`:142`, `sf_albion_mgmt.sv:214`) | harness: first retired instruction at PC 0 and equal to image word 0 on every run |
| **Memory map** | SRAM `0x0000_0000` (config: 4x16 KiB / 8x16 KiB / 8x32 KiB); MMIO `0x4000_0000`, six 4 KiB pages (MGMT, IRQ, DMA, PERM, TELEM, RAS); HOSTMEM `0x8000_0000` (host IOVA). **Exact decode**: any other address, including the first byte past the last SRAM bank and MMIO pages 6-15, returns DECERR (no aliasing) | `sf_albion_datafabric.sv:103-105`; `sf_albion_mmio.sv:38`; `docs/albion/register_map.md` | `REG_FAULTS`: unmapped page/offset, undecoded `0x2000_0000` and `SRAM_END` all fault; `MEM_BANKSEL`: no bank aliasing |
| **Boot ROM location** | **There is none.** The reset vector points into SRAM bank 0, which the *host* loads while the core is in reset (`DEV_STATUS.BOOT_MODE`), and every SRAM word is **scrubbed to zero on every reset** | `sf_albion_mgmt.sv:119` (`boot_mode = init_done & !core_run & !boot_lock`); `sf_albion_sram_bank.sv:48`; `docs/albion/clock_reset.md` | `BOOT_ROM` -> `UNSUPPORTED` (`0xF107`) with the evidence that the PC is inside SRAM and the scratch window is writable RAM |
| **SRAM availability** | per config: ALBION_MIN 4x16 KiB, CLOUD 8x16 KiB, HPC 8x32 KiB. Single-port banks, **SECDED (39,32)**, scrub-on-reset (4096 / 8192 cycles), partial writes are read-modify-write, built-in error injection. DMA can never reach bank 0 | `sf_albion_sram_bank.sv`, `sf_albion_secded.sv`, `sf_albion_datafabric.sv:20-24` | `PLAT_CONFIG` read the geometry for all three configs; scrub measured 4090 / 4090 / 8186 cycles; ECC tests below |
| **Trap handling** | Precise synchronous traps: instruction-address-misaligned (0), instruction access fault (1), illegal instruction (2), breakpoint (3), load misaligned (4), load access fault (5), store misaligned (6), store access fault (7), ECALL-from-M (11); machine external interrupt (`0x8000_000B`). `mtvec` **direct mode only** (low 2 bits forced 0). `mepc` low 2 bits forced 0. `mtval` carries the faulting address (0 for ECALL, the instruction word for illegal). `mstatus`: MIE, MPIE writable, MPP hard-wired to 11 | `:293-315` (cause logic), `:336` (vector), `:97` (mstatus), `:365-367` (CSR writes) | `TRAP_CAUSES` provokes all nine causes and checks `mepc` and `mtval` of each; `TRAP_RETURN` checks the `mstatus` MIE/MPIE shuffle on entry and `MRET`; `CSR_BASIC` checks the WARL fields |
| **Timer support** | **No machine timer and no software interrupt**: no `mtime`/`mtimecmp`, no CLINT, `mie` implements only MEIE, `mip` only MEIP. Time is available only as `mcycle`/`minstret` (and their user aliases) | `:97-99`, CSR list `:101-123` | `TIMER_IRQ` writes `mie.MTIE/MSIE`: read back 0 -> `UNSUPPORTED`; `CNT_CYCLE` validates `mcycle`, `minstret` (exactly 17 over a 17-instruction sequence), CPI, and agreement with the independent fabric counter `TELEM.CYCLES` |
| **Interrupt support** | One line: machine external interrupt from the IRQ page (6 sources: CMDQ level; DMA_DONE, DMA_ERR, PERM_VIOL, ECC_CE, ECC_UE sticky, write-1-to-clear). Taken only at instruction boundaries when `mstatus.MIE & mie.MEIE & pending`. `WFI` wakes on `pending & enable` **regardless of `mstatus.MIE`** | `:248`, `:312`/`:387`; `sf_albion_irq.sv:19`; `sf_albion_regs_pkg.sv:188` | `IRQ_MASK`, `IRQ_WFI`, `IRQ_TAKEN` (cause, `mepc` inside the interrupted loop, `mstatus` in the ISR, `MRET` restores MIE), `IRQ_SOURCES` (each of 4 sources), `IRQ_MULTI` (two simultaneous sources -> one trap, no retrigger) |
| **UART** | **None** in the regmap (pages 0-5 only; page 6 returns DECERR) | `docs/albion/register_map.md`; `sf_albion_mmio.sv:38` | `UART` probes page 6: load access fault -> `UNSUPPORTED` (`0xF108`) |
| **Debug interface** | **No** RISC-V debug module, no JTAG. A `dbg_strap_i` pin exists but only enables the `RAW_DMA` mailbox command. A retirement **trace port** (`trace_*`) exists for verification / FPGA debug | `sf_albion_cloud_top.sv:27`, trace ports `:54-61`; `docs/albion/known_limitations.md` | `DEBUG` probes `dcsr`: illegal instruction -> `UNSUPPORTED`; the strap value is reported in `aux1` |
| **Vector / tensor** | **Not implemented.** No vector unit exists in the feature set; ComputeWorks (INT8 GEMM, "tensor") is `FEAT_UNAVAIL` in ALBION_HPC and not even requested in MIN/CLOUD; PacketForge / VirtualFoundry likewise | `sf_albion_regs_pkg.sv:40` (`FEAT_AVAILABLE_MASK = 0x8FF`); `known_limitations.md` | `VECTOR`, `TENSOR`, `ACCEL_OTHER` -> `UNSUPPORTED`; on HPC the `TENSOR` aux shows `FEAT_REQ & COMPUTEWORKS = 0x400` (requested, unavailable) |
| **Host-visible reporting channels** | No UART, so: `MGMT.FW_STATUS`, `FW_VERSION`, `FW_HEARTBEAT`, `SCRATCH`; the mailbox completion queue (`FCPL_*` -> `HCPL_*`); and SRAM itself, readable by the host in `BOOT_MODE` after it halts the core | `sf_albion_mgmt.sv` | BootWorks uses all three (`01_BOOT_SEQUENCE.md`) |

## 2. Hardware invariants BootWorks relies on and tests

From the `sf_albion_datafabric.sv` header (`:20-24`), each verified at run time by `DMA_FWBANK` / `DMA_PERM`:

* DMA never reaches firmware-private bank 0, MMIO, or anything undecoded;
* DMA in domain `HOST_ADMIN` (1) is always denied, whatever the windows say;
* DMA in domain `FIRMWARE` (0) reaches SRAM **data** banks only;
* the host reaches SRAM only in `BOOT_MODE`, and MGMT/TELEM/RAS only as the writer column allows;
* MMIO registers are word-wide: a byte store (partial strobe) is rejected with SLVERR (`sf_albion_mmio.sv:39`).

## 3. Findings

**No CPU, ISA, memory or toolchain defect was found in the unmodified Albion RTL.** On the unmodified design BootWorks ran
every implemented self-test to its predicted outcome on all three configurations, and a reference RV32I model agreed with the
RTL on every one of ~2.5 - 5.4 million retired instructions per run. The mutation campaign (`03_VERIFICATION.md`) shows the
tests would have caught defects of these kinds.

Observations that matter to anyone bringing this silicon up (limitations of the design, not bugs):

1. **No watchdog and no timer interrupt.** A `WFI` that never receives its interrupt sleeps forever, and nothing on the chip
   can time out a hung firmware. Detection is the host's job (watch `FW_STATUS`/`FW_HEARTBEAT`). BootWorks bounds every
   *polling* wait with a cycle deadline (`TIMEOUT` outcome); the one unboundable wait is the `IRQ_WFI` test, which is why
   it only runs after the DMA test has shown the wake source works (prerequisite).
2. **SECDED hides single-bit SRAM faults from data tests.** A stuck or weak cell returns *corrected* data, so a pure
   pattern test passes while the RAS counter records every read. BootWorks therefore also requires `RAS.CE_COUNT` not to
   move during the destructive memory tests (`MEM_CE_MASKED`).
3. **`mip.MEIP` is gated by `IRQ.ENABLE`.** In RISC-V terms `MEIP` is normally the raw external line; here the SoC's IRQ
   controller masks it before the core. Tested as the documented behaviour (`IRQ_MASK`).
4. **Reset is asynchronous-assert (`negedge rst_ni`).** A simulation that holds `rst_ni` low from time 0 creates no edge, so with
   randomised power-on state the internal reset keeps a random value until the first clock; the RTL's own FIFO assertion then
   fires at time 0. This is a testbench artefact, not a design bug; the BootWorks harness pulses the pin (what a board's
   power-good does). The stock Albion harness never randomises runtime state, so it never saw it.
5. **Boot is host-driven and unauthenticated** (no secure boot, no signature check; Citadel P89 absent). BootWorks verifies
   a CRC-32 of its own image - an *integrity* check against load errors and SRAM bit errors, not an authentication.

## 4. Method

* Read: `sf_albion_controlcore.sv` (all 408 lines), `sf_albion_cloud_top.sv`, `sf_albion_datafabric.sv`, `sf_albion_mgmt.sv`,
  `sf_albion_mmio.sv`, `sf_albion_sram_bank.sv`, `sf_albion_dma.sv`, `sf_albion_irq.sv`, `sf_albion_perm.sv`,
  `sf_albion_ras.sv`, `sf_albion_telemetry.sv`, `sf_albion_rstctl.sv`, the generated register package and the register map.
* Baseline before any new code: built the stock Verilator model, built the stock `firmware/albion` with clang/lld, loaded it
  through the host port and booted it (`FW_STATUS = 2`), proving the toolchain and simulation path.
* Then every row of the table above was turned into a test and run on the RTL.
