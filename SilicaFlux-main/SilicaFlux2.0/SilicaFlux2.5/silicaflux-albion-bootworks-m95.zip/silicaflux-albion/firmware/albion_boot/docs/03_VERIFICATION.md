# 03 - Simulation integration and verification

## 1. What "running on the real RTL" means here

* **The RTL** is `rtl/albion/*.sv` unmodified, Verilated for each of CONFIG 0 (ALBION_MIN), 1 (CLOUD), 2 (HPC) with
  `--x-initial unique` and **random power-on state at run time** (`+verilator+rand+reset+2 +verilator+seed+N`).
* **The firmware** is the ELF's flat image (`bootworks.bin`), loaded into SRAM through the host MMIO port in `BOOT_MODE` and read back
  word for word. There is no back-door load, no ROM stub, no instruction-set simulator in the loop: the Albion ControlCore RTL fetches
  every instruction through the DataFabric from the SRAM bank RTL, including SECDED decode.
* **The harness** (`sim/bootworks_tb.cpp`) plays only the host, as the hardware defines it. It cannot influence the run once the core
  is released; it peeks signals (read-only) and checks.

## 2. Checks applied to every run (`tools/bw_check.py`)

| check | what is verified |
|---|---|
| `load` | the device reached `BOOT_MODE` after the scrub; every image word was written and read back through the host port with no error; after the run the core could be halted back into `BOOT_MODE` |
| `reset` | the **first retired instruction** is at PC `0x00000000` and equals image word 0 - the real reset vector |
| `fetch` | every **instruction-fetch handshake** on fabric master 0 (the CPU's real fetch path) returned exactly the image word at that address; every retired instruction is the word that was fetched for it; the only fetch error is the deliberate fetch-from-undecoded-address probe |
| `isa` | an independent **RV32I+Zicsr reference model** re-computed every retired instruction (rd value, next PC, branch decision, jump link, `MRET` target, trap vector, x0 writes, instructions without a destination) from the retirement trace: **0 divergences** over millions of instructions |
| `coverage` | every function that must run did enter (functions only on failure/abort paths excepted); instruction-word coverage is reported, and exception-trapped instructions count as reached |
| `signature` | completion signature valid: `FW_STATUS` = verdict, report magic/layout/CRC-32 (recomputed by the harness, independent code), mailbox BOOT_START + SUMMARY consistent, `FW_VERSION`, `FW_HEARTBEAT = 60`, `SCRATCH`; on a hang, the stalled stage/test |
| `integrity` | no image word changed during the run (seen by the host after halting); stack peak < 75 % |
| `outcomes` | each of the 60 tests ended as the architecture audit predicts |

"Expected instructions execute" is therefore established three ways: milestone/function entry coverage, the lock-step reference model
(the instruction stream is *architecturally correct*, not just present), and the fetch/retire identity (what executed is what is in
memory).

## 3. Results (final image)

Image: `bootworks.bin`, 28 556 bytes, SHA-256 `c8714751...365b`, built identically by clang/lld and re-built bit-for-bit from a different
directory (see `repro`). Full machine-readable results are in `reports/bootworks/`.

Every row below is one boot of the final image on the unmodified RTL with random power-on state (seed in the name); the GCC row is the same sources built by GNU (it owns 3 banks, leaving one data bank); the replay row boots via the generated FPGA host sequence. All eight host-side checks passed in every run (`reports/bootworks/check_*.json`).

| run | SRAM | verdict | run cycles | instr. fetched / retired | reference-model mismatches | fetch-vs-image mismatches | PASS / UNSUPPORTED / SKIPPED / FAIL+TIMEOUT | instruction coverage |
|---|---|---|---|---|---|---|---|---|
| `cfg0_seed1` (clang) | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg0_seed2` | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg0_seed3` | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg1_seed1` | 8 x 16 KiB | **PASS** (`0xB007600D`) | 15,578,991 | 4,648,436 / 4,648,399 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `cfg2_seed1` | 8 x 32 KiB | **PASS** (`0xB007600D`) | 29,626,485 | 8,885,174 / 8,885,137 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |
| `gnu_cfg0` (**GCC build**) | 4 x 16 KiB | **PASS** (`0xB007600D`) | 7,456,792 | 2,183,419 / 2,183,382 | 0 | 0 | 47 / 12 / 1 / 0 | 75.3 % |
| `seq_cfg0` (host-sequence replay) | 4 x 16 KiB | **PASS** (`0xB007600D`) | 8,674,780 | 2,568,715 / 2,568,678 | 0 | 0 | 47 / 12 / 1 / 0 | 74.8 % |


## 4. Negative testing: do the self-tests actually catch hardware defects?

A self-test that has never failed proves nothing. `tests/bw_mutants.py` injects one-line defects into a *copy* of the RTL, rebuilds the
Verilator model, boots the **unmodified** image on it and requires the right test to fail with the right diagnostic code - or the host
checks to fail, or the boot to end in a named fatal trap / hang. Results: `reports/bootworks/mutation_report.md`.

**25 of 25 injected RTL defects were detected and attributed to the correct test and diagnostic code.**

| mutant | area | injected defect | detected | first evidence |
|---|---|---|---|---|
| `cpu_sra_is_srl` | CPU ISA | SRA/SRAI shift right logically instead of arithmetically | **yes** | ISA_RV32I: FAIL 0x1022 ISA_SHIFT aux ['0x107', '0xffffffff', '0x1'] |
| `cpu_sltu_signed` | CPU ISA | SLTU/SLTIU compare as signed | **yes** | ISA_RV32I: FAIL 0x1023 ISA_CMP aux ['0x10', '0x1', '0x0'] |
| `cpu_bgeu_gt` | CPU ISA | BGEU implemented as 'greater than' (equal operands not taken) | **yes** | ISA_RV32I: FAIL 0x1025 ISA_BRANCH aux ['0x305', '0x1', '0x0'] |
| `cpu_misa_claims_m` | CPU ISA | misa advertises the M extension that is not implemented | **yes** | ISA_M: FAIL 0x1031 ISA_M_MISA_LIES aux ['0x40001100', '0x0', '0x1'] |
| `cpu_mtvec_mode_bits` | CPU CSR | mtvec keeps its low (mode) bits: vectored mode not forced off | **yes** | CSR_BASIC: FAIL 0x1052 CSR_MTVEC_WARL aux ['0x0', '0x1000', '0x1003'] |
| `cpu_instret_double` | CPU counters | minstret counts two per retired instruction | **yes** | CSR_BASIC: FAIL 0x1059 CSR_ALIAS aux ['0x1', '0x4c38', '0x4c3a'] |
| `cpu_mpie_not_saved` | CPU traps | trap entry does not save MIE into MPIE | **yes** | TRAP_RETURN: FAIL 0x2022 TRAP_MSTATUS_ENTRY aux ['0x1', '0x0', '0x80'] |
| `cpu_lw_misalign_ok` | CPU traps | misaligned LW does not raise load-address-misaligned | **yes** | TRAP_CAUSES: FAIL 0x200B TRAP_LMIS_CAUSE aux ['0xffffffff', '0x4', '0x0'] |
| `cpu_irq_never_taken` | Interrupts | machine external interrupt is never taken (irq_take stuck 0) | **yes** | IRQ_TAKEN: TIMEOUT 0x8031 IRQ_NOT_TAKEN aux ['0x4e20', '0x0', '0x4e5e'] |
| `cpu_wfi_never_wakes` | Interrupts | WFI never leaves the sleep state | **yes** | host watchdog: TIMEOUT: host watchdog (FW_STATUS/FW_HEARTBEAT stalled); FW_STATUS=0xB1803600 -> stage 0x80, test IRQ_WFI |
| `soc_irq_ue_not_wired` | Interrupts | ECC_UE interrupt source tied low | **yes** | ECC_UE: FAIL 0x6015 ECC_UE_IRQ aux ['0x0', '0x20', '0x0'] |
| `cpu_wrong_reset_vector` | Reset | RESET_PC = 0x100 instead of 0x0 | **yes** | host check 'reset' FAILED as it must |
| `cpu_fetch_bit_flip` | Fetch path | one bit of the fetched instruction word is corrupted on its way into the decoder (at the entry of boot_main) | **yes** | host check 'fetch' FAILED as it must |
| `sram_one_cell_flips_1bit` | SRAM | one SRAM cell (word 100 of every bank) stores a codeword with 1 bit inverted: ECC corrects it, so only the RAS counter shows it | **yes** | BANK0_SWEEP: FAIL 0x5012 MEM_B0_CE aux ['0x190', '0x2b', '0x2d'] |
| `sram_cell_pair_flips_2bit` | SRAM | two bits of one SRAM word hold the inverse (uncorrectable) inside boot_main's code | **yes** | fatal trap: FW_STATUS=0xDEAD0001 (cause 1) SCRATCH(mepc)=0x514; the corrupted word is at 0x514 |
| `sram_bank2_addr_bit_stuck` | SRAM | word-address bit 4 of SRAM bank 2 stuck at 0 | **yes** | MEM_ADDRBUS: FAIL 0x5041 MEM_ADDR_HIGH aux ['0x8040', '0xaaaaaaaa', '0x55555555'] |
| `fabric_bank3_aliases_bank2` | SRAM | the DataFabric routes bank 3 accesses to bank 2 | **yes** | MEM_BANKSEL: FAIL 0x5051 MEM_BANK_ALIAS aux ['0x8000', '0xb0a00001', '0xb0a00002'] |
| `dma_drops_last_word` | DMA | DMA moves one word fewer than LEN | **yes** | DMA_FILL: FAIL 0x7012 DMA_FILL_DATA aux ['0x0', '0x100', '0xfc'] |
| `dma_corrupts_copy_data` | DMA | DMA copy flips data bit 4 | **yes** | DMA_COPY: FAIL 0x7022 DMA_COPY_DATA aux ['0xe040', '0x0', '0xefef154c'] |
| `dma_never_completes` | DMA | DMA engine stays BUSY forever | **yes** | DMA_FILL: TIMEOUT 0x7015 DMA_FILL_TIMEOUT aux ['0x0', '0x3', '0x100'] |
| `fabric_dma_reaches_bank0` | Protection | hardware invariant broken: DMA may write the firmware bank (BootWorks aims at a sandbox) | **yes** | DMA_FWBANK: FAIL 0x7061 DMA_FW_WRITE aux ['0x0', '0x2', '0x2'] |
| `perm_ignores_domain` | Protection | permission windows match any domain | **yes** | DMA_PERM: FAIL 0x7075 DMA_PERM_DOMAIN aux ['0x4', '0x2', '0x2'] |
| `regs_wrong_chip_id` | Registers | CHIP_ID constant differs (0x53464191) | **yes** | PLAT_ID: FAIL 0x3001 PLAT_CHIP_ID aux ['0x0', '0x53464190', '0x53464191'] |
| `telem_freeze_ignored` | Registers | TELEM freeze does not stop the counters | **yes** | REG_TELEM: FAIL 0x4043 REG_TELEM_FREEZE aux ['0x0', '0x22024', '0x224ec'] |
| `image_bit_flipped_in_sram` | Boot image | one bit of the image flips in SRAM after the host's own verify (a word of code that never executes, so only the CRC can notice) | **yes** | IMG_CRC: FAIL 0x5002 IMG_CRC aux ['0xbe8c5b0a', '0x86d411b4', '0x6f8c'] |


What the misses taught (all fixed and re-run): an ISA vector set without equal operands cannot see `>=` implemented as `>`;
a corruption injected into code that never executes is only visible to the CRC; and a mutant that corrupts fetched bits must target
an instruction that really runs. Mutation testing found a hole in *my* tests that the passing runs never could have.

## 5. Cross-toolchain, reproducibility, host sequence

| experiment | command | result |
|---|---|---|
| **Second toolchain** | `make albion-bootworks-gnu` | the same sources built with `riscv64-unknown-elf-gcc 13.2` (a different compiler, assembler and linker) under `-Wall -Wextra -Werror`, pass the ISA gate, and boot on the RTL (`reports/bootworks/boot_report_gnu_cfg0.md`). GCC's larger image owns 48 KiB, which leaves **one** data bank in ALBION_MIN instead of two. That exposed two real defects in the firmware that clang's layout hid, both fixed: (1) GCC's `-Wclobbered` flagged a `setjmp` hazard in the test runner (a loop counter live across `setjmp`); (2) the first run of the GCC image **hung in `IRQ_WFI`**, and `bw_check.py` named the stalled test from `FW_STATUS`: the interrupt tests started their DMA at data-bank offset `0x4000`, one whole 16 KiB bank away, which is only valid when a second data bank exists. Offsets now stay inside the first 16 KiB. The single-data-bank code paths of the DMA tests are exercised by this build. |
| **Reproducible build** | `make -C firmware/albion_boot repro` | two builds into different directories give identical `.bin` and `.elf` (SHA-256 equal) |
| **Toolchain gate** | part of every build | `bw_isa_check.py` decodes every instruction word of `.text` and fails the build on anything outside RV32I+Zicsr (e.g. a compiler emitting `mul`, an AMO, or a compressed instruction) |
| **Host sequence replay** | `make albion-bootworks-seq` | the generated FPGA-bridge sequence replayed against the RTL boots to the same verdict |
| **Random power-on state** | every run | `+verilator+rand+reset+2`, seeds recorded in the report file names. Randomisation is genuinely active (it tripped the RTL's own FIFO assertion at time 0 before the harness applied the asynchronous reset edge, see the audit). Three seeds of CONFIG 0 give **identical** cycle counts and results: reset initialises everything the boot depends on, so the boot does not depend on power-on state. |

## 6. How a failing boot is diagnosed (the "precise defect" requirement)

| symptom the host sees | where the cause is |
|---|---|
| no `FW_STATUS` change after `RUN`, or first retired PC != 0 | reset vector / core reset (`reset` check; mutant `cpu_wrong_reset_vector`) |
| `FW_STATUS = 0xB1000001` then nothing | instruction fetch or MMIO store path |
| `FW_STATUS = 0xDEAD0000 \| cause`, `SCRATCH = mepc` | fatal trap: cause + address (mutant `sram_cell_pair_flips_2bit`: instruction access fault at the exact word with the uncorrectable ECC error) |
| `FW_STATUS` frozen at `0xB1 SS TT` | hang in stage `SS` test `TT` (mutant `cpu_wfi_never_wakes`: stage 0x80, `IRQ_WFI`) |
| `0xB007FA11` + `SCRATCH` | failures: report block lists each test's unique diagnostic code and `aux = (address, expected, observed)` |
| `fetch` / `isa` host checks fail | CPU defect located to the instruction: pc, word, expected and actual value |
| toolchain gate fails at build | an instruction the core does not implement was emitted (address, function, encoding) |
| `IMG_CRC` fails | the image was damaged in load or in SRAM (host read-back at load would have caught a bus error) |
