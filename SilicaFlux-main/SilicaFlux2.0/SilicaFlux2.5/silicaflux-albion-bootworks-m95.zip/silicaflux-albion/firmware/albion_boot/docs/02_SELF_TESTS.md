# 02 - Hardware self-tests

60 tests in 10 stages, executed in this order (the list lives in `include/bw_diag.h`; `DIAGNOSTIC_CODES.md` has every test and all 223+
failure-mode codes). Each test returns one of `PASS / FAIL / TIMEOUT / SKIPPED / UNSUPPORTED`, a unique diagnostic code and three
auxiliary words (usually *address, expected, observed*).

## What each stage proves

| stage | tests | what is exercised on the RTL |
|---|---|---|
| **CPU / ISA** `0x10` | `CPU_ENTRY` `CPU_IDENT` `ISA_RV32I` `ISA_M/A/C/F` `ISA_FENCE` `CSR_BASIC` `CSR_ABSENT` | reset-entry CSR values; `misa`/ids; all 37 RV32I integer instructions against **host-compiler-folded** expected values (never an instruction compared with itself); extension *probes* - execute `mul`, `amoadd.w`, a 16-bit encoding, `fadd.s`, see the illegal-instruction trap, and **cross-check against `misa`** so a core that lies about its extensions is caught; CSR read/write/set/clear + immediates, WARL fields (`mtvec`, `mepc`, `mstatus`, `mie`, `mip`), read-only CSR write traps, user aliases; absent CSRs (hpm, debug) trap |
| **Traps** `0x20` | `TRAP_CAUSES` `TRAP_RETURN` | all nine synchronous causes provoked deliberately, each checked for `mcause`, `mepc` (the exact instruction address) and `mtval`; `mstatus` MIE/MPIE on entry and `MRET` |
| **Counters / timer** `0x90` | `CNT_CYCLE` `TIMER_IRQ` `POLL_TIMEOUT` | `mcycle` advances; `minstret` delta over 17 instructions is exactly 17; CPI plausible; CPU `mcycle` and fabric `TELEM.CYCLES` agree over the same interval (two independent counters); no timer interrupt; the cycle-deadline mechanism itself measures correctly |
| **Platform** `0x30` | `PLAT_ID/CONFIG/FEATURES` `BOOT_ROM` `UART` `DEBUG` `VECTOR` `TENSOR` `ACCEL_OTHER` `HOSTMEM` `MAILBOX` | chip id, version, geometry vs. `CONFIG_ID`, feature-mask consistency; absent hardware reported `UNSUPPORTED` with reason; host-dependent `SKIPPED`; completion-queue status and a real push |
| **Registers** `0x40` | `REG_MGMT` `REG_IRQ` `REG_DMA` `REG_PERM` `REG_TELEM` `REG_RAS` `REG_FAULTS` | read-only registers fault on write; writer-restricted registers refuse the core; read/write registers hold patterns and mask unused bits; windows invalid at reset; counters count and freeze; unmapped page / offset / undecoded address / past-the-end all fault; a byte store to an MMIO register is rejected and changes nothing |
| **SRAM** `0x50` | `IMG_CRC` `BANK0_SWEEP` `STACK` `MEM_DATABUS` `MEM_ADDRBUS` `MEM_BANKSEL` `MEM_MARCH` `MEM_PATTERN` `MEM_BYTE` | **data-line** (walking 1/0 with complement neighbour), **address-line** (Barr: stuck-high, stuck-low, shorted), **bank-select aliasing**, **March C-** (6 elements, up/down), address-as-data / checkerboard / PRBS patterns, **byte and halfword stores** (the bank's read-modify-write path) with neighbour checks and `lb/lbu/lh/lhu` extension; every destructive test also fails if the ECC corrected-error counter moved |
| **ECC** `0x60` | `ECC_CE` `ECC_UE` | uses the real RAS **error injection**: a flipped data bit is corrected, counted, logged (type/address/syndrome/source) and raises the IRQ source; a byte store *heals* it (RMW); **every one of the 39 codeword bits** (data and check bits) flipped in turn is corrected; a double-bit error raises a load access fault with the right `mtval`, is counted/logged, raises its interrupt source and is cleared by rewriting |
| **DMA** `0x70` | `DMA_IDLE` `DMA_FILL` `DMA_COPY` `DMA_SIZES` `DMA_BADPARAM` `DMA_ERRORS` `DMA_FWBANK` `DMA_PERM` | memory-to-memory copy across and within banks (source untouched, no overrun past the destination); fill; sizes from one word to a full bank with throughput bounds; illegal parameters (BADPARAM, nothing moved); first-failing-beat semantics at the end of SRAM (`BYTES_DONE = 4 x beat`, `ERR_ADDR`, words before written, none after); the hardware invariants (DMA cannot read/write bank 0 or read MMIO) with the violation log; tenant windows enforced **per beat** (no window, RW, window ending mid-transfer, read-only, wrong domain, HOST_ADMIN) |
| **Interrupts** `0x80` | `IRQ_BASE` `IRQ_MASK` `IRQ_WFI` `IRQ_TAKEN` `IRQ_SOURCES` `IRQ_MULTI` | no spurious state after reset; `mip.MEIP` gated by `IRQ.ENABLE`; pending-but-masked is *not* taken; W1C; `WFI` wakes with `MIE=0` and the sleep is visible in telemetry; an interrupt **is taken** (`mcause = 0x8000000B`, `mepc` inside the interrupted loop, `mstatus` MIE=0/MPIE=1 inside, MIE restored by `MRET`, exactly one trap, nothing left pending); four distinct sources; two simultaneous sources -> one trap, no retrigger |
| **Post-checks** `0xA0` | `IMG_CRC_POST` `STACK_POST` | after every destructive test the image CRC-32 is unchanged and the stack canary intact - the proof that the tests did not corrupt the running firmware |

## Safety: never corrupt the running firmware or stack

1. Destructive tests touch **only** regions built by `bw_mem_init()` from linker symbols: the 1 KiB scratch window and the data
   banks above the firmware's 32 KiB. Every region is checked against the code/data/bss and stack ranges first; a violation is
   `INT_REGION_UNSAFE` and no test touches memory.
2. Code, rodata, `.data` image and stack get *non-destructive* checks only: CRC-32 over the whole image before **and** after all
   destructive tests, a read-only sweep of every word of the firmware banks (no access fault, no ECC event), the stack
   canary (16 guard words + painted fill), and a 75 % high-water limit.
3. Forbidden-target DMA tests aim only at places where a *broken* hardware invariant cannot hurt: a 256-byte zero sandbox in
   bank 0 (restored after every test, so the image CRC stays valid), read-only sources, an MMIO identity word - never code, never
   stack, and never a destination that a working design would accept.
4. ECC injection is restricted to data banks; DMA targets only data banks (or the sandbox, expecting denial).
5. Interrupts are enabled only inside the interrupt tests and are switched off, with all sources cleared, between every test.
6. Unexpected traps cannot spread: a test that traps unexpectedly is abandoned via `longjmp` and reported `FAIL` with cause/PC/address.
7. The negative-test campaign includes a mutant that **breaks the "DMA cannot reach bank 0" invariant**; BootWorks reports
   `DMA_FW_WRITE` while the image stays intact (`IMG_CRC_POST` passes).

## Timeouts

Every polling wait is a `BW_POLL(cond, cycles)` against `mcycle`. A DMA that never finishes is `TIMEOUT` (`DMA_*_TIMEOUT`), an
interrupt that is never taken is `TIMEOUT` (`IRQ_NOT_TAKEN`). Tests that depend on a working DMA are skipped (`SKIPPED`,
`SKIP_PREREQ`) when the DMA test failed, so a stuck DMA produces one `TIMEOUT` and a list of skipped dependents, not a cascade.
The **only unboundable wait** is `WFI` (no timer interrupt exists to wake it); it runs only after the DMA test proved its wake source,
and the host watchdog identifies it if it ever hangs (`03_VERIFICATION.md`, mutant `cpu_wfi_never_wakes`).

## Prerequisites (a failed prerequisite makes dependents `SKIPPED`)

`TRAP_RETURN <- TRAP_CAUSES`; `PLAT_CONFIG, PLAT_FEATURES, MAILBOX, REG_* <- PLAT_ID` (`REG_FAULTS, MEM_* <- PLAT_CONFIG`);
`MEM_ADDRBUS <- MEM_DATABUS <- ...`; `MEM_MARCH <- MEM_ADDRBUS`; `MEM_PATTERN <- MEM_MARCH`; `ECC_CE <- REG_RAS`; `ECC_UE <- ECC_CE`;
`DMA_IDLE <- REG_DMA`; `DMA_FILL <- DMA_IDLE`; `DMA_COPY <- DMA_FILL`; `DMA_SIZES, DMA_PERM <- DMA_COPY`; `DMA_BADPARAM, DMA_FWBANK <- DMA_IDLE`;
`DMA_ERRORS <- DMA_FILL`; `IRQ_MASK <- REG_IRQ`; `IRQ_WFI, IRQ_TAKEN <- DMA_FILL`; `IRQ_SOURCES <- IRQ_MASK`; `IRQ_MULTI <- IRQ_TAKEN`;
`IMG_CRC_POST <- IMG_CRC`; `STACK_POST <- STACK`. The authoritative table is `BW_TABLE` in `boot.c`.

## Expected outcomes on the unmodified Albion RTL

`PASS` for 47 tests. `UNSUPPORTED` for 12: `ISA_M` `ISA_A` `ISA_C` `ISA_F` (`0xF101-4`), `CSR_ABSENT` (`0xF105`), `TIMER_IRQ` (`0xF106`),
`BOOT_ROM` (`0xF107`), `UART` (`0xF108`), `DEBUG` (`0xF109`), `VECTOR` (`0xF10A`), `TENSOR` (`0xF10B`), `ACCEL_OTHER` (`0xF10C`).
`SKIPPED` for 1: `HOSTMEM` (`0xF002`, host/IOMMU dependent). `bw_check.py` compares every run against exactly this table.
