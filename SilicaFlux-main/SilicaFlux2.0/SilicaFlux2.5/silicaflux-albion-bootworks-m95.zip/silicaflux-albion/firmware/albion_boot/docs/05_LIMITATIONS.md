# 05 - Limitations and honest scope

What BootWorks is: a real firmware image, built by real RISC-V toolchains, booted from the real reset vector on the real RTL of the
Albion control processor (Verilated), executing 60 self-tests whose results the host reads back through the real hardware
boot protocol. What it is not:

## Evidence level

* **Simulation only.** Everything ran on a Verilator model of `sf_albion_cloud_top`. **No FPGA board, no silicon, no gate-level
  simulation** was involved, and 2-state Verilator semantics (random initial values) cannot show X-propagation problems.
* **Not a compliance suite.** `ISA_RV32I` checks every RV32I integer instruction with directed vectors, not exhaustively;
  it is not `riscv-tests`, not `riscv-formal` and says nothing about behaviours it does not probe (e.g. CSR corner cases beyond the
  listed ones, instruction-fetch interaction with every address). The core is **not claimed to be RISC-V compliant**; it is
  characterised as RV32I+Zicsr with documented gaps.
* **Coverage is measured, not assumed:** ~75 % of the firmware's instruction words retire in a passing run; the rest are failure,
  abort and `TIMEOUT` paths, which the mutation campaign exercises (`03_VERIFICATION.md`). The firmware banks are tested
  **non-destructively**; destructive coverage is every bank above the first 32 KiB (50 % of SRAM in ALBION_MIN).
* **One thread of control, one core.** No multi-hart, no cache, no coherence: none exists in the RTL.

## Hardware not covered because it does not exist (reported `UNSUPPORTED`)

Boot ROM, UART/console, debug module/JTAG, machine timer and software interrupts, RV32M/A/C/F, performance-monitor CSRs, vector unit,
ComputeWorks tensor unit, PacketForge, VirtualFoundry. BootWorks **detects** their absence; when they arrive the corresponding tests
must be replaced by real ones (the feature bits are already read; `TENSOR`/`ACCEL_OTHER` become `SKIPPED/no driver` if a bit appears
without a regmap entry, never a false `PASS`).

## Hardware present but deliberately not exercised

* **HOSTMEM from the core** (`0x8000_0000`): whether the host IOMMU maps it is a host decision -> `SKIPPED` (`0xF002`).
* **The host command queue** (`CMDQ` interrupt source, host mailbox commands): BootWorks does not process commands; it is a boot
  stage, not the command processor (`firmware/albion`). Interrupt tests use the DMA, permission and ECC sources.
* **Soft reset, `BOOT_LOCK`, `CORE_CTRL` after lock**: BootWorks never locks boot (it is bring-up firmware - the host must be able to
  halt it and read the report). Production firmware locks; BootWorks is not that firmware.
* **Host-side registers** (host interrupt enable, host command staging): the core cannot write them (and the test proves it).

## Design limits that shaped the firmware

* **The `WFI` wait cannot be bounded on-chip** (no timer interrupt, no watchdog); it is gated behind a passing DMA test and caught by
  the host watchdog otherwise.
* **No UART:** boot progress is a 32-bit status word, a CRC-protected binary report and two mailbox records, not text. A
  human-readable boot log is *rendered by the host tools* (`boot_log_*.txt`); the firmware prints nothing.
* **Image budget:** 28.5 KB of a 28 KiB-class area; there are ~120 bytes of headroom (an `ASSERT` in `linker.ld` fails the link when it
  runs out). Adding tests means moving some table data or logic into the second firmware bank's spare space, or raising `BW_FW_TOP`.
* **Two banks of firmware** are untestable destructively (code cannot be overwritten in place). A relocating build (copy the test kernel
  elsewhere, test, copy back) would cover them; it is not implemented.
* **The boot integrity check is a CRC-32**, not a signature: it detects load and SRAM errors, not an adversary (no secure boot exists).
* **The report block is read by the host only after halting the core** (BOOT_MODE). If the integrator sets `BOOT_LOCK`, the host loses
  SRAM access and only the `MGMT` registers and the mailbox records remain.

## Verification limits

* The mutation campaign injects 25 specific, single-point defects; absence of a detected defect elsewhere is not proof of absence.
* The reference RV32I model (in the harness) shares my reading of the spec; it was cross-checked only against the RTL and the
  directed tests, not against an independent golden model such as Spike.
* Expected outcomes for the unmodified RTL come from the audit (`00_ARCHITECTURE_AUDIT.md`); an RTL change that legitimately adds a
  feature will make `bw_check.py` report a deviation until the expectation table is updated.

## Retargeting

* **Project 21 ControlCore (RV32IM, boot ROM, UART, vector/tensor tiles):** needs a different `linker.ld`, a UART text channel, the real
  accelerator ABIs and a boot-ROM handoff; the core, trap, CSR, memory-test and diagnostic frameworks carry over.
* **Other Albion configurations:** CONFIG 0/1/2 are built and run. A future configuration with fewer than 2 x 16 KiB of SRAM would not fit
  (`PLAT_GEOMETRY`).
