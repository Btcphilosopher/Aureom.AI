# 01 - Boot sequence, memory layout and reporting

## 1. The boot protocol (defined by the RTL, not by BootWorks)

```
host                                   Albion SoC (sf_albion_cloud_top)
----                                   --------------------------------
pin reset (async assert)  ------------> sf_albion_rstctl; every SRAM bank scrubs itself to encode(0)  (4096 / 8192 cycles)
poll DEV_STATUS == INIT_DONE|BOOT_MODE  <- core held in reset, host may write SRAM
write image to SRAM 0x0000_0000.. -----> host port (master 3), allowed only in BOOT_MODE
read it back, compare
MGMT.CORE_CTRL.RUN = 1  --------------> ControlCore leaves reset at PC 0x0000_0000
                                        BootWorks runs ... FW_STATUS = live progress ...
watch FW_STATUS  <-------------------   FW_STATUS = 0xB007600D (PASS) or 0xB007FA11 (FAIL)
MGMT.CORE_CTRL.RUN = 0  --------------> core in reset again, DEV_STATUS.BOOT_MODE = 1 (BootWorks never sets BOOT_LOCK)
read the report out of SRAM, pop the mailbox records
```

`tools/bw_load_sequence.py` writes this exact transaction list to `build/bootworks/bootworks_load.seq`; the Verilator harness
can replay it (`--seq=`), and a future FPGA host bridge implements it (`04_FPGA_BRINGUP.md`).

## 2. What the firmware does after PC 0 (`startup.S`, `boot.c`)

| step | where | observable |
|---|---|---|
| 1. first instruction: `MGMT.FW_STATUS = 0xB1000001` (ENTRY) - one store, no stack, no memory | `startup.S` | proves the real fetch path, decode and an MMIO store work |
| 2. capture reset-state CSRs (`mstatus mie mtvec mepc mcause mcycle minstret mhartid`) in registers | `startup.S` | tested later by `CPU_ENTRY` |
| 3. install the **early** trap vector (reports `0xDEAD0000\|mcause`, `SCRATCH=mepc`, parks) - needs no stack | `startup.S` | a trap before C exists is still reported |
| 4. `sp = _stack_top`; copy `.data` from its load image; clear `.bss` (includes the report block); paint the whole stack with a canary | `startup.S` | `FW_STATUS = 0xB1000002` |
| 5. save the entry state, install the full trap vector (`bw_trap_entry`) | `startup.S` | |
| 6. `boot_main`: `FW_STATUS = 0xB1000003`; **identify hardware** (`bw_hw_detect`: chip id, config, geometry, features, CSR ids) and take a **reset-state snapshot** of every peripheral before anything mutates it | `hardware_detect.c` | |
| 7. **initialise peripherals**: interrupts masked, IRQ sources cleared, all permission windows invalidated, telemetry running, RAS log cleared | `boot.c` | |
| 8. run the 60-entry test table in order; each test is bounded, guarded by `setjmp`, and followed by a hardware clean-up | `boot_status.c` | live `FW_STATUS = 0xB1<stage><test><failures>`, `FW_HEARTBEAT` = tests started |
| 9. finalise: report block + CRC-32, mailbox SUMMARY record, `SCRATCH`, then `FW_STATUS = PASS/FAIL signature` **last** | `boot_status.c` | the host polls for this value |
| 10. park in `wfi` (host halts the core and reads the report) | `boot.c` | |

Why the report is not on a UART: **there is no UART** (`00_ARCHITECTURE_AUDIT.md`). The three channels that exist are used
instead.

## 3. Memory layout (`linker.ld`)

The firmware owns the **first 32 KiB** of SRAM - bank 0 and bank 1 in ALBION_MIN/CLOUD (16 KiB banks), bank 0 alone in
ALBION_HPC (32 KiB). Everything above is handed to the tests. The whole layout derives from one symbol (`BW_FW_TOP`,
default `0x8000`) and every boundary is `ASSERT`ed at link time.

```
0x0000 +----------------------+ <- reset vector: _start
       | .text.start          |   startup.S: reset entry, early trap, trap entry, setjmp/longjmp
       | (padding)            |
0x0300 | DMA sandbox (256 B)  |   zeros inside bank 0; destination of the "DMA must NOT reach bank 0" test; restored after every test
       | .text                |   all C code and trigger stubs
       | .rodata              |
       | .trailer (16 B)      |   magic, image size, CRC-32 (patched into the ELF after link), version
       | .data load image     |   initial values, copied to RAM by startup.S
0x7000 +----------------------+
       | .data / .bss         |   2 KiB: includes the 1.06 KiB report block `g_report`
0x7800 +----------------------+
       | test scratch window  |   1 KiB, 1 KiB-aligned: the ONLY destructive-test area in the firmware banks
0x7C00 +----------------------+
       | stack (1 KiB)        |   canary-painted; 16 guard words at the bottom; peak use measured ~390 B
0x8000 +----------------------+
       | data banks ...       |   destructively tested: March C-, patterns, address/data lines, ECC injection, DMA targets
```

Why two banks: 60 self-tests are ~28 KB of RV32I code (4 bytes per instruction, no compressed set). Code cannot be
destructively tested in place, so the firmware banks get **non-destructive** coverage (image CRC before *and after* all
destructive tests, a read-only sweep of every word, the stack canary, and a 1 KiB scratch window for the instruction-level
tests); every other bank gets the full destructive suite. In ALBION_MIN that is 32 of 64 KiB destructively; in CLOUD 96 of 128 KiB;
in HPC 224 of 256 KiB.

## 4. Reporting channels and encodings

### `MGMT.FW_STATUS` (host-pollable, cycle-accurate, no host traffic needed to produce it)

| value | meaning |
|---|---|
| `0xB1000001` / `0xB1000002` / `0xB1000003` | ENTRY / C runtime ready / `boot_main` |
| `0xB1 SS TT FF` | running: stage `SS` (see below), test id `TT`, `FF` = FAIL+TIMEOUT count so far |
| `0xB007600D` | **finished, BOOT PASS** - no test FAILed or TIMEDOUT |
| `0xB007FA11` | **finished, BOOT FAIL** |
| `0xDEAD0000 \| mcause` | fatal trap outside any test (same convention as the stock firmware); `SCRATCH = mepc`; `FW_ATTN = 1` |

Stages: `0x10` CPU/ISA, `0x20` traps, `0x30` platform, `0x40` registers, `0x50` SRAM, `0x60` ECC, `0x70` DMA, `0x80` interrupts,
`0x90` counters/timer, `0xA0` post-checks. A host watchdog that sees `FW_STATUS` stall therefore knows **which test hung**
(`bw_check.py` prints it).

### Other registers

`FW_VERSION = 0x00950100` (module 95 v1.0) - `FW_HEARTBEAT` = tests started (= 60 at the end) - `SCRATCH` = `(FAIL+TIMEOUT count << 16) | first failing diagnostic`.

### Mailbox completion queue (host pops via `HCPL_W0..3`)

| record | `w0` | `w1` | `w2` | `w3` |
|---|---|---|---|---|
| BOOT_START | `0xB0070001` | `BW_VERSION` | `banks << 8 \| config` | `FEAT_IMPL` |
| SUMMARY | `0xB0070002` | verdict signature | `failures << 16 \| passes` | report CRC-32 |

### The report block (`g_report`, read from SRAM after the host halts the core)

`bw_report_t` (`include/bw_status.h`, shared byte-for-byte with the simulation harness): magic `'BWRP'`, layout, version, state,
verdict, counts per outcome, first failing diagnostic and test, config, features, geometry, cycles, instructions retired, stack
high-water mark, then **one 16-byte result per test** `{diag, outcome, test, aux0, aux1, aux2}` and a CRC-32 over everything
above it. A **valid completion signature** is: `FW_STATUS` = verdict = report verdict, report magic/layout/state correct,
`n_done = 60`, outcome counts sum to 60, CRC-32 recomputed by the host equals the stored one and the mailbox SUMMARY, `FW_VERSION`
and `FW_HEARTBEAT` as expected, `SCRATCH` consistent. `bw_check.py` verifies every item.

## 5. Outcomes

| outcome | meaning | verdict |
|---|---|---|
| `PASS` | ran, hardware behaved as specified | ok |
| `FAIL` | ran and detected a defect; `diag` names the failure mode (unique code); `aux` = address / expected / observed | **BOOT FAIL** |
| `TIMEOUT` | an operation did not finish inside its cycle deadline (`BW_POLL`, deadline in `mcycle`) | **BOOT FAIL** |
| `SKIPPED` | not executed: a prerequisite test did not pass (`0xF001`, aux = prerequisite), the result depends on the host (`0xF002`), hardware present but no driver in the regmap (`0xF003`) | ok |
| `UNSUPPORTED` | the hardware feature is absent, with a reason code (`0xF1xx`): ISA extension, CSR, timer interrupt, ROM, UART, debug, vector, tensor, accelerators | ok |

The boot verdict is PASS iff no test FAILed or TIMEDOUT and all 60 are accounted for. Every code is listed in `DIAGNOSTIC_CODES.md`
(generated from `include/bw_diag.h`; the build fails on duplicate codes or on a code no test can emit).

## 6. Trap and interrupt handling

* `bw_trap_entry` saves the 16 caller-saved registers and calls `bw_trap_dispatch(frame, mcause, mepc, mtval)`.
* A machine external interrupt runs the ISR (acknowledges the sticky sources the running test asked for; **masks any source that
  stays pending after W1C** so a stuck line cannot storm; records `mepc`, `mstatus`, counts).
* A synchronous exception while a test has armed `bw_catch()` is *captured and resumed* - this is how tests **provoke** faults and
  check the RTL's `mcause/mepc/mtval/mstatus`.
* An unexpected exception inside a test aborts only that test (`longjmp` to the runner): `FAIL`, `INT_UNEXPECTED_TRAP`
  (`0xE002`), aux = cause / mepc / mtval - which is exactly how a firmware or hardware bug is localised.
* An exception outside any test is fatal: `FW_STATUS = 0xDEAD0000 | cause`.

## 7. Build and run

```bash
make albion-bootworks            # firmware: ELF, .bin, .hex, .dis, .map, manifest; diagnostic-table gate; ISA gate
make albion-bootworks-run        # Verilate CONFIG 0/1/2, boot on the RTL, check, write reports/bootworks/
make albion-bootworks-mutants    # inject RTL defects, require BootWorks to name them
make albion-bootworks-gnu        # same sources with GCC: cross-toolchain build + ISA gate (+ boot on the RTL: gnu-run)
```

Equivalent direct form: `make -C firmware/albion_boot {all|run|mutants|gnu|gnu-run|repro|seq-run}`; `CONFIGS="0 1 2"`, `SEEDS="1 2 3"`.
