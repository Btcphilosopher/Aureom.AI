/* BootWorks - interrupt self-tests.
 *
 * Implemented in the RTL: ONE machine external interrupt (MEI, mcause 0x8000000B) fed by the IRQ page
 * (6 sources: CMDQ level, DMA_DONE / DMA_ERR / PERM_VIOL / ECC_CE / ECC_UE sticky). WFI wakes on
 * (IRQ pending & enable) regardless of mstatus.MIE. NOT implemented (reported by CSR/TIMER_IRQ tests):
 * machine timer interrupt, software interrupt, vectored mtvec, nested interrupts.
 *
 * A WFI cannot be bounded by a cycle deadline (there is no timer interrupt to wake it); the DMA that
 * produces the wake event is therefore started first, and a hang here is caught by the host-side watchdog,
 * which reports the stage/test from MGMT.FW_STATUS.
 */
#include "bw_internal.h"

#define BIT(n) (1u << (n))
#define W(a)   ((volatile uint32_t *)(uintptr_t)(a))

static void irq_quiet(void) {
  BW_CSR_C(mstatus, MSTATUS_MIE);
  BW_CSR_C(mie, MIE_MEIE);
  BW_IRQ(ALBION_IRQ_ENABLE) = 0u;
  bw_irq_clear_all();
  bw_tc.irq_count = 0; bw_tc.irq_seen = 0; bw_tc.irq_stuck = 0; bw_tc.irq_ack = 0; bw_tc.irq_badcause = 0;
}

static uint32_t data_addr(uint32_t off) { return bw_data_base(0u) + off; }

/* start a fill DMA without waiting for it (domain 0, data bank) */
static void dma_start_fill(uint32_t dst, uint32_t len) {
  BW_DMA(ALBION_DMA_DST)          = dst;
  BW_DMA(ALBION_DMA_LEN)          = len;
  BW_DMA(ALBION_DMA_DOMAIN)       = ALBION_DOM_FIRMWARE;
  BW_DMA(ALBION_DMA_FILL_PATTERN) = 0x6A6A6A6Au;
  BW_DMA(ALBION_DMA_CTRL)         = 3u;
}

/* =========================================================================== baseline */

bw_result_t bw_test_IRQ_BASE(void) {
  /* bit 0 is the CMDQ level source: the host may legitimately have queued a command already */
  if (g_hw.snap_irq_pending & ~BIT(0)) return BW_FAIL_R(BW_D_IRQ_SPURIOUS, g_hw.snap_irq_pending, 0u, g_hw.snap_irq_enable);
  if (g_hw.snap_irq_enable || (g_hw.snap_mip & MIP_MEIP)) return BW_FAIL_R(BW_D_IRQ_MEIP_STUCK, g_hw.snap_mip, 0u, g_hw.snap_irq_enable);
  return BW_PASS_R();
}

/* =========================================================================== gating and clearing */

bw_result_t bw_test_IRQ_MASK(void) {
  irq_quiet();
  bw_dma_res_t r = bw_dma_run(0u, 0u, 0u, 0u, 0u, 0u);               /* LEN=0: immediate BADPARAM -> DMA_ERR pulse */
  if (r.timed_out) return BW_TMO_R(BW_D_IRQ_SRC_DMA_ERR, 0, 0, 0);
  uint32_t pend = BW_IRQ(ALBION_IRQ_PENDING);
  if (!(pend & BIT(2))) return BW_FAIL_R(BW_D_IRQ_SRC_DMA_ERR, pend, BIT(2), BW_IRQ(ALBION_IRQ_RAW));

  if (BW_CSR_R(mip) & MIP_MEIP) return BW_FAIL_R(BW_D_IRQ_MASK_NOT_GATED, BW_CSR_R(mip), 0u, pend);   /* ENABLE = 0 */
  BW_IRQ(ALBION_IRQ_ENABLE) = BIT(2);
  if (!(BW_CSR_R(mip) & MIP_MEIP)) return BW_FAIL_R(BW_D_IRQ_MASK_NOT_RAISED, BW_CSR_R(mip), MIP_MEIP, pend);

  /* MEIE set, MIE clear: the interrupt is pending but must not be taken */
  BW_CSR_S(mie, MIE_MEIE);
  for (volatile uint32_t k = 0; k < 40u; k++) { }
  if (bw_tc.irq_count != 0u) return BW_FAIL_R(BW_D_IRQ_MIE_BLOCK, bw_tc.irq_count, 0u, bw_tc.irq_epc);
  BW_CSR_C(mie, MIE_MEIE);

  /* write-1-to-clear */
  BW_IRQ(ALBION_IRQ_CLEAR) = BIT(2);
  if ((BW_IRQ(ALBION_IRQ_PENDING) & BIT(2)) || (BW_CSR_R(mip) & MIP_MEIP))
    return BW_FAIL_R(BW_D_IRQ_CLEAR_STUCK, BW_IRQ(ALBION_IRQ_PENDING), 0u, BW_CSR_R(mip));
  irq_quiet();
  return BW_PASS_R();
}

/* =========================================================================== WFI */

bw_result_t bw_test_IRQ_WFI(void) {
  if (bw_ndata() < 1u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.banks);
  irq_quiet();
  uint32_t sleep0 = BW_TELEM(ALBION_TELEM_CNT_LO + ALBION_TC_CORE_SLEEP_CYCLES * ALBION_TELEM_CNT_LO_STRIDE);
  BW_IRQ(ALBION_IRQ_ENABLE) = BIT(1);                                /* DMA_DONE */
  BW_CSR_S(mie, MIE_MEIE);                                           /* wake source enabled, MIE stays 0 */
  dma_start_fill(data_addr(0x3000u), 1024u);      /* inside the first 16 KiB of data bank 0: valid with a single data bank */
  __asm__ volatile("wfi" ::: "memory");
  uint32_t pend = BW_IRQ(ALBION_IRQ_PENDING);
  uint32_t trapped = bw_tc.irq_count;
  uint32_t slept = BW_TELEM(ALBION_TELEM_CNT_LO + ALBION_TC_CORE_SLEEP_CYCLES * ALBION_TELEM_CNT_LO_STRIDE) - sleep0;
  irq_quiet();
  if (trapped) return BW_FAIL_R(BW_D_IRQ_WFI_TRAP, trapped, 0u, 0u);
  if (!(pend & BIT(1))) return BW_FAIL_R(BW_D_IRQ_WFI_NOPEND, pend, BIT(1), 0u);
  return BW_PASS_A(slept, 0, 0);
}

/* =========================================================================== taken interrupt */

bw_result_t bw_test_IRQ_TAKEN(void) {
  if (bw_ndata() < 1u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.banks);
  irq_quiet();
  bw_tc.irq_ack = BIT(1);
  BW_IRQ(ALBION_IRQ_ENABLE) = BIT(1);
  BW_CSR_S(mie, MIE_MEIE);
  uint32_t t0 = bw_cycles();
  dma_start_fill(data_addr(0x3800u), 256u);
  BW_CSR_S(mstatus, MSTATUS_MIE);                                    /* from here the interrupt may be taken */
  uint32_t ok = bw_irq_spin(&bw_tc.irq_count, t0, 20000u);
  uint32_t after_mstatus = BW_CSR_R(mstatus);                        /* mret must have restored MIE = MPIE = 1 */
  BW_CSR_C(mstatus, MSTATUS_MIE);
  (void)BW_POLL(!(BW_DMA(ALBION_DMA_STATUS) & ALBION_DMA_STATUS_BUSY_MASK), BW_DMA_DEADLINE);
  uint32_t lat = bw_cycles() - t0;
  uint32_t count = bw_tc.irq_count, epc = bw_tc.irq_epc, ms = bw_tc.irq_mstatus, stuck = bw_tc.irq_stuck;
  uint32_t bad = bw_tc.irq_badcause, pend = BW_IRQ(ALBION_IRQ_PENDING);
  irq_quiet();
  if (bad)   return BW_FAIL_R(BW_D_IRQ_CAUSE, bad, MCAUSE_MEI, 0u);
  if (!ok)   return BW_TMO_R(BW_D_IRQ_NOT_TAKEN, 20000u, 0u, lat);
  if (epc < BW_SYM(bw_irq_spin_loop) || epc >= BW_SYM(bw_irq_spin_end))
    return BW_FAIL_R(BW_D_IRQ_EPC, epc, BW_SYM(bw_irq_spin_loop), BW_SYM(bw_irq_spin_end));
  if ((ms & (MSTATUS_MIE | MSTATUS_MPIE)) != MSTATUS_MPIE) return BW_FAIL_R(BW_D_IRQ_MSTATUS, ms, MSTATUS_MPIE, 0u);
  if (count != 1u) return BW_FAIL_R(BW_D_IRQ_COUNT, count, 1u, 0u);
  if (!(after_mstatus & MSTATUS_MIE)) return BW_FAIL_R(BW_D_IRQ_RESUME, after_mstatus, MSTATUS_MIE, 0u);
  if (stuck || (pend & BIT(1))) return BW_FAIL_R(BW_D_IRQ_STUCK, stuck, pend, 0u);
  return BW_PASS_A(lat, epc, count);
}

/* =========================================================================== individual sources */

static uint32_t pending_after(void (*trigger)(void)) {
  bw_irq_clear_all();
  trigger();
  return BW_IRQ(ALBION_IRQ_PENDING) & BW_IRQ_ALL & ~BIT(0);
}

static void trig_dma_err(void)  { (void)bw_dma_run(0u, 0u, 0u, 0u, 0u, 0u); }
static void trig_perm(void)     { (void)bw_dma_run(data_addr(0x2000u), data_addr(0x2400u), 16u, 2u, 0u, 0u); }

#define SRC_WORD 9u
static void ecc_event(uint32_t lo, uint32_t hi, int read_it) {
  volatile uint32_t *p = W(data_addr(4u * SRC_WORD));
  BW_RAS(ALBION_RAS_INJ_MASK_LO) = lo;
  BW_RAS(ALBION_RAS_INJ_MASK_HI) = hi;
  BW_RAS(ALBION_RAS_INJ_ADDR)    = SRC_WORD;
  BW_RAS(ALBION_RAS_INJ_CTRL)    = 1u | (bw_data_bank(0u) << 4);
  *p = 0x0BADCAFEu;
  if (read_it) { bw_catch(BW_RESUME_SKIP); volatile uint32_t v = *p; (void)v; (void)bw_caught(); }
}
static void trig_ce(void) { ecc_event(1u << 7, 0u, 1); }
static void trig_ue(void) { ecc_event((1u << 2) | (1u << 11), 0u, 1); }

bw_result_t bw_test_IRQ_SOURCES(void) {
  if (bw_ndata() < 1u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.banks);
  irq_quiet();
  uint32_t p;
  p = pending_after(trig_dma_err);
  if (!(p & BIT(2))) return BW_FAIL_R(BW_D_IRQ_SRC_DMA_ERR, p, BIT(2), 0u);
  if (p & ~BIT(2))   return BW_FAIL_R(BW_D_IRQ_SRC_EXTRA, p, BIT(2), p & ~BIT(2));
  p = pending_after(trig_perm);                                       /* denied tenant DMA: violation + DMA error */
  if (!(p & BIT(3))) return BW_FAIL_R(BW_D_IRQ_SRC_PERM, p, BIT(3), 0u);
  if (p & ~(BIT(2) | BIT(3))) return BW_FAIL_R(BW_D_IRQ_SRC_EXTRA, p, BIT(2) | BIT(3), p & ~(BIT(2) | BIT(3)));
  p = pending_after(trig_ce);
  if (!(p & BIT(4))) return BW_FAIL_R(BW_D_IRQ_SRC_ECC_CE, p, BIT(4), 0u);
  if (p & ~BIT(4))   return BW_FAIL_R(BW_D_IRQ_SRC_EXTRA, p, BIT(4), p & ~BIT(4));
  p = pending_after(trig_ue);
  if (!(p & BIT(5))) return BW_FAIL_R(BW_D_IRQ_SRC_ECC_UE, p, BIT(5), 0u);
  if (p & ~BIT(5))   return BW_FAIL_R(BW_D_IRQ_SRC_EXTRA, p, BIT(5), p & ~BIT(5));
  *W(data_addr(4u * SRC_WORD)) = 0u;                                  /* leave the word clean */
  BW_RAS(ALBION_RAS_ERR_CLEAR) = 1u;
  irq_quiet();
  return BW_PASS_R();
}

/* =========================================================================== simultaneous sources */

bw_result_t bw_test_IRQ_MULTI(void) {
  if (bw_ndata() < 1u) return BW_SKIP_R(BW_D_SKIP_NO_DATA_BANK, g_hw.banks);
  irq_quiet();
  bw_tc.irq_ack = BIT(2) | BIT(3);
  BW_IRQ(ALBION_IRQ_ENABLE) = BIT(2) | BIT(3);
  BW_CSR_S(mie, MIE_MEIE);                                            /* MIE still 0: let both sources pend first */
  trig_perm();
  uint32_t pend = BW_IRQ(ALBION_IRQ_PENDING);
  if ((pend & (BIT(2) | BIT(3))) != (BIT(2) | BIT(3))) { irq_quiet(); return BW_FAIL_R(BW_D_IRQ_MULTI_MISSING, pend, BIT(2) | BIT(3), 0u); }
  uint32_t t0 = bw_cycles();
  BW_CSR_S(mstatus, MSTATUS_MIE);                                     /* one trap must serve both */
  uint32_t ok = bw_irq_spin(&bw_tc.irq_count, t0, 20000u);
  for (volatile uint32_t k = 0; k < 60u; k++) { }                     /* any re-trigger would land here */
  BW_CSR_C(mstatus, MSTATUS_MIE);
  uint32_t count = bw_tc.irq_count, seen = bw_tc.irq_seen, stuck = bw_tc.irq_stuck;
  irq_quiet();
  if (!ok) return BW_TMO_R(BW_D_IRQ_NOT_TAKEN, 1u, 0u, 0u);
  if ((seen & (BIT(2) | BIT(3))) != (BIT(2) | BIT(3))) return BW_FAIL_R(BW_D_IRQ_MULTI_MISSING, seen, BIT(2) | BIT(3), count);
  if (count != 1u || stuck) return BW_FAIL_R(BW_D_IRQ_MULTI_RETRIGGER, count, 1u, stuck);
  return BW_PASS_R();
}
