# SilicaFlux Albion — Project 90 · ALBIONCLOUD

*Aureom.AI / SilicaFlux Albion* — integrated cloud semiconductor platform.

This repository is a working hardware/software platform: synthesizable SystemVerilog for a programmable cloud SoC, RV32I firmware that boots on its ControlCore, and a Rust host runtime with a C ABI that runs real workloads through a cycle-accurate RTL simulation. Everything in it can be rebuilt and re-measured with one command each.

**Status: ALBION_MIN is complete and verified in simulation.** ALBION_CLOUD and ALBION_HPC elaborate, boot and run every implemented workload. They report their missing accelerators (PacketForge P86, VirtualFoundry P87, ComputeWorks P88) as unavailable instead of stubbing them. None of the nine preceding foundations (P81–P89) were present in this workspace (see [`docs/albion/hardware_dependencies.md`](docs/albion/hardware_dependencies.md)). The blocks ALBION_MIN needs were therefore built here as clearly labelled P90-local implementations and verified.

## What is in ALBION_MIN

```
 Host (PCIe BAR in silicon / harness in sim)            Host memory (IOMMU-protected IOVA)
        │ MMIO, domain HOST_ADMIN                                   ▲ DMA beats, window-checked
        ▼                                                           │
 ┌──────────────────────────── sf_albion_cloud_top ────────────────────────────────┐
 │  ControlCore RV32I ─┐                               ┌─ SRAM bank 0  (firmware)   │
 │  DMA read port ─────┤   DataFabric 4×6 crossbar     ├─ SRAM bank 1..3 (SECDED)   │
 │  DMA write port ────┼─► + permission unit ─────────►├─ MMIO: MGMT/mailbox, IRQ,  │
 │  Host MMIO ─────────┘   (decode → check → arbitrate)│        DMA, PERM, TELEM, RAS│
 │                                                     └─ HOSTMEM → host_if         │
 └──────────────────────────────────────────────────────────────────────────────────┘
```

| Block | RTL | Notes |
|---|---|---|
| ControlCore | `sf_albion_controlcore.sv` | RV32I + Zicsr, M-mode, precise traps, WFI, retirement trace |
| DataFabric | `sf_albion_datafabric.sv` | 4 masters × (banks+2) slaves, per-slave round robin, permission check before arbitration |
| Banked SRAM | `sf_albion_sram_bank.sv`, `sf_albion_secded.sv` | (39,32) SECDED, scrub-on-reset, RMW partial writes, fault injection |
| Protected DMA | `sf_albion_dma.sv` | copy/fill, split read/write ports, prefetch FIFO, first-failing-beat error semantics |
| Mailbox & mgmt | `sf_albion_mgmt.sv` | identity, feature report, boot lock, command/completion queues |
| Permission | `sf_albion_perm.sv` + fabric | domain windows and hardware invariants no window can override |
| Telemetry | `sf_albion_telemetry.sv` | 48 64-bit counters incl. per-domain DMA bytes |
| RAS | `sf_albion_ras.sv` | error log, syndrome/source, CE/UE counters, injection |
| Host interface | `sf_albion_host_if.sv` | host MMIO target + host-memory requester |
| Config | `sf_albion_cloud_config.sv` | ALBION_MIN / CLOUD / HPC (generated from `spec/albion/regmap.json`) |

## Build and run

```bash
make albion-lint        # generated-file check, Verilator -Wall, Yosys elaboration (3 configs)
make albion-firmware    # RV32I firmware (clang + lld) -> build/firmware/albion_fw.bin
make albion-sim         # Verilator full-chip simulators, one per configuration
make albion-runtime     # Rust runtime (rlib/staticlib/cdylib), unit tests, C ABI smoke
make albion-test        # module TBs + system tests on both backends + C ABI -> reports/test
make albion-formal      # SECDED / permission / FIFO / DMA-bounds proofs -> reports/formal
make albion-pdk albion-synth   # sky130 standard-cell estimates -> reports/synth
make albion-bench       # AlbionBench on the RTL -> reports/bench
make albion-fpga        # ECP5 place-and-route estimate + bitstream (no board) -> reports/fpga
make albion-coverage    # coverage-instrumented system run -> reports/coverage
make albion-floorplan   # OpenROAD flow; exits 2 listing what is missing (it is, here)
make albion-report      # provenance + performance report + engineering terminal
make albion-bootworks-run      # Module 95 BootWorks: boot + self-test firmware on the RTL, all 3 configs -> reports/bootworks
make albion-bootworks-mutants  # Module 95: inject RTL defects, BootWorks must name each one
```

**Module 95 - BootWorks** (`firmware/albion_boot/`, start at its `README.md`): RV32I boot and 60-test hardware self-test
firmware for the ControlCore, booted from the reset vector on this RTL, with ELF/disassembly/memory image/map/toolchain manifest,
a lock-step instruction check, a negative-test (mutation) campaign and an FPGA host-sequence.

Tool versions are captured in `reports/provenance.json`. The tools are Verilator 5.020, Yosys 0.33, nextpnr-ecp5 0.6, clang/LLD 18 and rustc 1.97. Rust code has no external crate dependencies.

```rust
use sf_albion::*;
let mut dev = Device::open(&OpenOptions { backend: Backend::RtlSim { binary: None }, ..Default::default() })?;
let host = dev.alloc(MemKind::Host, 4096)?;
let sram = dev.alloc(MemKind::DeviceSram, 4096)?;
dev.host_write(&host, 0, &data)?;
let c = dev.run(&Work::DmaCopy { src: host.addr, dst: sram.addr, len: 4096 })?;   // submit + wait
assert!(c.status.is_ok());
let crc = dev.run(&Work::Crc32 { addr: sram.addr, len: 4096 })?;                  // runs on the ControlCore
dev.close()?;
```

## Where to look

* `docs/albion/` — architecture, register map, transaction protocol, clock/reset, security model, firmware and runtime APIs, test plan, dependencies, physical-design assumptions, performance report, known limitations, Linux/VFIO and Kubernetes plans, FPGA notes.
* `tools/albion_terminal/albion_terminal.html` — the engineering terminal. Every value in it comes from `reports/`.
* `reports/` — test results, formal results, coverage, synthesis, benchmarks, FPGA estimate, provenance.

## What this is not (yet)

There is no silicon and no FPGA board run. The ECP5 flow is place-and-route only, and it reaches 19.45 MHz post-route, missing the 50 MHz target; the critical path and the pipelining plan are documented. There is also no PCIe endpoint, no compiled SRAM macro and no OpenROAD run, so physical design is configured but not executed and no tapeout readiness is claimed. Packet, virtual-I/O and tensor workloads stay unavailable until their foundations exist. See [`docs/albion/known_limitations.md`](docs/albion/known_limitations.md).
