# BootWorks boot report GNU toolchain, CONFIG 0

* RTL: SilicaFlux Albion `sf_albion_cloud_top` CONFIG 0 - 4 SRAM banks x 16 KiB
* Image: 29768 bytes, loaded through the host MMIO port in BOOT_MODE, read back and verified
* Run: 7456792 cycles from CORE_CTRL.RUN to the completion signature (`completion signature`)
* Verdict: **PASS** (FW_STATUS `0xB007600D`) - PASS 47, FAIL 0, TIMEOUT 0, SKIPPED 1, UNSUPPORTED 12

## Host-side verification

| check | result | detail |
|---|---|---|
| load | PASS | BOOT_MODE before load, 7442 words written+read back through the host port: 0 write errors, 0 mismatches; core halted back into BOOT_MODE: True |
| reset | PASS | first retired instruction: pc 0x00000000 word 0x40000FB7 (image word 0 = 0x40000FB7), retired 33881 cycles into the run window |
| fetch | PASS | 2183419 instruction fetches on fabric master 0: 0 differ from the image, 0 retirements differ from their fetch, 1 fetch error(s) (deliberate: 0x20000000) |
| isa | PASS | reference RV32I+Zicsr model checked 2183382 retired instructions against the RTL trace: 0 mismatches |
| coverage | PASS | 5144/6833 instruction words retired (75.3%); required functions never entered: none |
| signature | PASS | FW_STATUS=0xB007600D FW_VERSION=0x00950100 HEARTBEAT=60 SCRATCH=0x00000000; SRAM report magic/CRC valid (0x27CDAB98); mailbox: 1 START + 1 SUMMARY record(s); end: completion signature |
| integrity | PASS | 0 image words changed after the run; peak stack 404 B (limit 768 of 1024) |
| outcomes | PASS | every test ended as the architecture audit predicts |

## Self-test results (read back from SRAM through the host port)

| id | test | outcome | diag | meaning | aux0 / aux1 / aux2 | start cycle | cycles |
|---|---|---|---|---|---|---|---|
| 0 | `CPU_ENTRY` | PASS |  |  |  | 16490 | 2065 |
| 1 | `CPU_IDENT` | PASS |  |  |  | 18555 | 2025 |
| 2 | `ISA_RV32I` | PASS |  |  |  | 20580 | 3612 |
| 3 | `ISA_M` | UNSUPPORTED | 0xF101 | `UNSUP_ISA_M`: RV32M not implemented (mul raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 24192 | 2490 |
| 4 | `ISA_A` | UNSUPPORTED | 0xF102 | `UNSUP_ISA_A`: RV32A not implemented (amoadd.w raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 26682 | 2556 |
| 5 | `ISA_C` | UNSUPPORTED | 0xF103 | `UNSUP_ISA_C`: RVC not implemented (compressed encoding raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 29238 | 2477 |
| 6 | `ISA_F` | UNSUPPORTED | 0xF104 | `UNSUP_ISA_F`: RV32F not implemented (fadd.s raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 31715 | 2483 |
| 7 | `ISA_FENCE` | PASS |  |  |  | 34198 | 2091 |
| 8 | `CSR_BASIC` | PASS |  |  |  | 36289 | 2799 |
| 9 | `CSR_ABSENT` | UNSUPPORTED | 0xF105 | `UNSUP_CSR_HPM`: hardware performance-monitor and debug CSRs not implemented | 0x00000B03 / 0x00000000 / 0x00000000 | 39088 | 2442 |
| 10 | `TRAP_CAUSES` | PASS |  |  |  | 41530 | 6681 |
| 11 | `TRAP_RETURN` | PASS |  |  |  | 48211 | 2872 |
| 12 | `CNT_CYCLE` | PASS |  |  |  | 51083 | 14686 |
| 13 | `TIMER_IRQ` | UNSUPPORTED | 0xF106 | `UNSUP_TIMER_IRQ`: no machine timer or software interrupt (mie.MTIE/MSIE read-only zero) | 0x00000000 / 0x00000000 / 0x00000000 | 65769 | 2010 |
| 14 | `POLL_TIMEOUT` | PASS |  |  |  | 67779 | 3036 |
| 15 | `PLAT_ID` | PASS |  |  |  | 70815 | 2045 |
| 16 | `PLAT_CONFIG` | PASS |  |  |  | 72860 | 2959 |
| 17 | `PLAT_FEATURES` | PASS |  |  |  | 75819 | 2040 |
| 18 | `BOOT_ROM` | UNSUPPORTED | 0xF107 | `UNSUP_BOOT_ROM`: no boot ROM: reset vector is host-loaded SRAM bank 0 | 0x00001828 / 0x00000000 / 0x00000000 | 77859 | 3196 |
| 19 | `UART` | UNSUPPORTED | 0xF108 | `UNSUP_UART`: no UART/console peripheral in the regmap; next MMIO page returns DECERR | 0x40006000 / 0x00000000 / 0x00000000 | 81055 | 2415 |
| 20 | `DEBUG` | UNSUPPORTED | 0xF109 | `UNSUP_DEBUG`: no debug module (debug CSRs illegal) | 0x000007B0 / 0x00000000 / 0x00000000 | 83470 | 2920 |
| 21 | `VECTOR` | UNSUPPORTED | 0xF10A | `UNSUP_VECTOR`: no vector command unit exists in the Albion feature set | 0x000008FF / 0x000008FF / 0x00000000 | 86390 | 2023 |
| 22 | `TENSOR` | UNSUPPORTED | 0xF10B | `UNSUP_TENSOR`: ComputeWorks (INT8 GEMM) not implemented: FEAT_IMPL bit clear | 0x000008FF / 0x00000000 / 0x00000000 | 88413 | 2516 |
| 23 | `ACCEL_OTHER` | UNSUPPORTED | 0xF10C | `UNSUP_ACCEL_OTHER`: PacketForge/VirtualFoundry not implemented: FEAT_IMPL bits clear | 0x000008FF / 0x00000000 / 0x00000000 | 90929 | 2516 |
| 24 | `HOSTMEM` | SKIPPED | 0xF002 | `SKIP_HOST_DEPENDENT`: skipped: result depends on host/IOMMU configuration, not exercised | 0x80000000 / 0x00000000 / 0x00000000 | 93445 | 2012 |
| 25 | `MAILBOX` | PASS |  |  |  | 95457 | 2358 |
| 26 | `REG_MGMT` | PASS |  |  |  | 97815 | 3450 |
| 27 | `REG_IRQ` | PASS |  |  |  | 101265 | 3380 |
| 28 | `REG_DMA` | PASS |  |  |  | 104645 | 3729 |
| 29 | `REG_PERM` | PASS |  |  |  | 108374 | 3449 |
| 30 | `REG_TELEM` | PASS |  |  |  | 111823 | 5803 |
| 31 | `REG_RAS` | PASS |  |  |  | 117626 | 3431 |
| 32 | `REG_FAULTS` | PASS |  |  |  | 121057 | 6047 |
| 33 | `IMG_CRC` | PASS |  |  |  | 127104 | 1699117 |
| 34 | `BANK0_SWEEP` | PASS |  |  |  | 1826221 | 1367127 |
| 35 | `STACK` | PASS |  |  |  | 3193348 | 5255 |
| 36 | `MEM_DATABUS` | PASS |  |  |  | 3198603 | 6808 |
| 37 | `MEM_ADDRBUS` | PASS |  |  |  | 3205411 | 9012 |
| 38 | `MEM_BANKSEL` | PASS |  |  |  | 3214423 | 2988 |
| 39 | `MEM_MARCH` | PASS |  |  |  | 3217411 | 677393 |
| 40 | `MEM_PATTERN` | PASS |  |  |  | 3894804 | 1252004 |
| 41 | `MEM_BYTE` | PASS |  |  |  | 5146808 | 4768 |
| 42 | `ECC_CE` | PASS |  |  |  | 5151576 | 42632 |
| 43 | `ECC_UE` | PASS |  |  |  | 5194208 | 5591 |
| 44 | `DMA_IDLE` | PASS |  |  |  | 5199799 | 2071 |
| 45 | `DMA_FILL` | PASS |  |  |  | 5201870 | 7799 |
| 46 | `DMA_COPY` | PASS |  |  |  | 5209669 | 56750 |
| 47 | `DMA_SIZES` | PASS |  |  |  | 5266419 | 297762 |
| 48 | `DMA_BADPARAM` | PASS |  |  |  | 5564181 | 23070 |
| 49 | `DMA_ERRORS` | PASS |  |  |  | 5587251 | 6978 |
| 50 | `DMA_FWBANK` | PASS |  |  |  | 5594229 | 8603 |
| 51 | `DMA_PERM` | PASS |  |  |  | 5602832 | 53074 |
| 52 | `IRQ_BASE` | PASS |  |  |  | 5655906 | 2054 |
| 53 | `IRQ_MASK` | PASS |  |  |  | 5657960 | 3480 |
| 54 | `IRQ_WFI` | PASS |  |  |  | 5661440 | 4554 |
| 55 | `IRQ_TAKEN` | PASS |  |  |  | 5665994 | 4859 |
| 56 | `IRQ_SOURCES` | PASS |  |  |  | 5670853 | 11676 |
| 57 | `IRQ_MULTI` | PASS |  |  |  | 5682529 | 7425 |
| 58 | `IMG_CRC_POST` | PASS |  |  |  | 5689954 | 1699134 |
| 59 | `STACK_POST` | PASS |  |  |  | 7389088 | 67704 |

## What executed on the CPU

* 2183382 instructions retired, 38 traps taken (cause: count) - 0: 1, 1: 1, 2: 8, 3: 1, 4: 1, 5: 8, 6: 1, 7: 12, 11: 3, interrupt 0x8000000B: 2
* instruction classes retired: op-imm 758819, op 474495, load 275649, branch 255881, store 177475, jal 135001, jalr 51816, lui 27397, auipc 25806, csr 1001, mret 38, fence 3, wfi 1
* function entry coverage and instruction coverage: 5144/6833 words (75.3%)
* functions never executed (all are failure/abort paths or tests that were skipped by design): `bw_early_trap`, `bw_fail`, `bw_fatal`, `bw_longjmp`, `bw_tmo`

