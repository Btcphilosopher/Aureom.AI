# BootWorks boot report CONFIG 0 seed 3

* RTL: SilicaFlux Albion `sf_albion_cloud_top` CONFIG 0 - 4 SRAM banks x 16 KiB
* Image: 28556 bytes, loaded through the host MMIO port in BOOT_MODE, read back and verified
* Run: 8674780 cycles from CORE_CTRL.RUN to the completion signature (`completion signature`)
* Verdict: **PASS** (FW_STATUS `0xB007600D`) - PASS 47, FAIL 0, TIMEOUT 0, SKIPPED 1, UNSUPPORTED 12

## Host-side verification

| check | result | detail |
|---|---|---|
| load | PASS | BOOT_MODE before load, 7139 words written+read back through the host port: 0 write errors, 0 mismatches; core halted back into BOOT_MODE: True |
| reset | PASS | first retired instruction: pc 0x00000000 word 0x40000FB7 (image word 0 = 0x40000FB7), retired 32669 cycles into the run window |
| fetch | PASS | 2568715 instruction fetches on fabric master 0: 0 differ from the image, 0 retirements differ from their fetch, 1 fetch error(s) (deliberate: 0x20000000) |
| isa | PASS | reference RV32I+Zicsr model checked 2568678 retired instructions against the RTL trace: 0 mismatches |
| coverage | PASS | 4753/6356 instruction words retired (74.8%); required functions never entered: none |
| signature | PASS | FW_STATUS=0xB007600D FW_VERSION=0x00950100 HEARTBEAT=60 SCRATCH=0x00000000; SRAM report magic/CRC valid (0x13B46322); mailbox: 1 START + 1 SUMMARY record(s); end: completion signature |
| integrity | PASS | 0 image words changed after the run; peak stack 392 B (limit 768 of 1024) |
| outcomes | PASS | every test ended as the architecture audit predicts |

## Self-test results (read back from SRAM through the host port)

| id | test | outcome | diag | meaning | aux0 / aux1 / aux2 | start cycle | cycles |
|---|---|---|---|---|---|---|---|
| 0 | `CPU_ENTRY` | PASS |  |  |  | 15835 | 1843 |
| 1 | `CPU_IDENT` | PASS |  |  |  | 17678 | 1785 |
| 2 | `ISA_RV32I` | PASS |  |  |  | 19463 | 3367 |
| 3 | `ISA_M` | UNSUPPORTED | 0xF101 | `UNSUP_ISA_M`: RV32M not implemented (mul raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 22830 | 2272 |
| 4 | `ISA_A` | UNSUPPORTED | 0xF102 | `UNSUP_ISA_A`: RV32A not implemented (amoadd.w raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 25102 | 2286 |
| 5 | `ISA_C` | UNSUPPORTED | 0xF103 | `UNSUP_ISA_C`: RVC not implemented (compressed encoding raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 27388 | 2266 |
| 6 | `ISA_F` | UNSUPPORTED | 0xF104 | `UNSUP_ISA_F`: RV32F not implemented (fadd.s raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 29654 | 2263 |
| 7 | `ISA_FENCE` | PASS |  |  |  | 31917 | 1867 |
| 8 | `CSR_BASIC` | PASS |  |  |  | 33784 | 2600 |
| 9 | `CSR_ABSENT` | UNSUPPORTED | 0xF105 | `UNSUP_CSR_HPM`: hardware performance-monitor and debug CSRs not implemented | 0x00000B03 / 0x00000000 / 0x00000000 | 36384 | 2234 |
| 10 | `TRAP_CAUSES` | PASS |  |  |  | 38618 | 6328 |
| 11 | `TRAP_RETURN` | PASS |  |  |  | 44946 | 2644 |
| 12 | `CNT_CYCLE` | PASS |  |  |  | 47590 | 14450 |
| 13 | `TIMER_IRQ` | UNSUPPORTED | 0xF106 | `UNSUP_TIMER_IRQ`: no machine timer or software interrupt (mie.MTIE/MSIE read-only zero) | 0x00000000 / 0x00000000 / 0x00000000 | 62040 | 1767 |
| 14 | `POLL_TIMEOUT` | PASS |  |  |  | 63807 | 2787 |
| 15 | `PLAT_ID` | PASS |  |  |  | 66594 | 1805 |
| 16 | `PLAT_CONFIG` | PASS |  |  |  | 68399 | 3966 |
| 17 | `PLAT_FEATURES` | PASS |  |  |  | 72365 | 1797 |
| 18 | `BOOT_ROM` | UNSUPPORTED | 0xF107 | `UNSUP_BOOT_ROM`: no boot ROM: reset vector is host-loaded SRAM bank 0 | 0x00001660 / 0x00000000 / 0x00000000 | 74162 | 3257 |
| 19 | `UART` | UNSUPPORTED | 0xF108 | `UNSUP_UART`: no UART/console peripheral in the regmap; next MMIO page returns DECERR | 0x40006000 / 0x00000000 / 0x00000000 | 77419 | 2222 |
| 20 | `DEBUG` | UNSUPPORTED | 0xF109 | `UNSUP_DEBUG`: no debug module (debug CSRs illegal) | 0x000007B0 / 0x00000000 / 0x00000000 | 79641 | 2222 |
| 21 | `VECTOR` | UNSUPPORTED | 0xF10A | `UNSUP_VECTOR`: no vector command unit exists in the Albion feature set | 0x000008FF / 0x000008FF / 0x00000000 | 81863 | 1823 |
| 22 | `TENSOR` | UNSUPPORTED | 0xF10B | `UNSUP_TENSOR`: ComputeWorks (INT8 GEMM) not implemented: FEAT_IMPL bit clear | 0x000008FF / 0x00000000 / 0x00000000 | 83686 | 1835 |
| 23 | `ACCEL_OTHER` | UNSUPPORTED | 0xF10C | `UNSUP_ACCEL_OTHER`: PacketForge/VirtualFoundry not implemented: FEAT_IMPL bits clear | 0x000008FF / 0x00000000 / 0x00000000 | 85521 | 1820 |
| 24 | `HOSTMEM` | SKIPPED | 0xF002 | `SKIP_HOST_DEPENDENT`: skipped: result depends on host/IOMMU configuration, not exercised | 0x80000000 / 0x00000000 / 0x00000000 | 87341 | 1766 |
| 25 | `MAILBOX` | PASS |  |  |  | 89107 | 2052 |
| 26 | `REG_MGMT` | PASS |  |  |  | 91159 | 3254 |
| 27 | `REG_IRQ` | PASS |  |  |  | 94413 | 3178 |
| 28 | `REG_DMA` | PASS |  |  |  | 97591 | 3592 |
| 29 | `REG_PERM` | PASS |  |  |  | 101183 | 3232 |
| 30 | `REG_TELEM` | PASS |  |  |  | 104415 | 5583 |
| 31 | `REG_RAS` | PASS |  |  |  | 109998 | 3283 |
| 32 | `REG_FAULTS` | PASS |  |  |  | 113281 | 5650 |
| 33 | `IMG_CRC` | PASS |  |  |  | 118931 | 1629686 |
| 34 | `BANK0_SWEEP` | PASS |  |  |  | 1748617 | 887958 |
| 35 | `STACK` | PASS |  |  |  | 2636575 | 4451 |
| 36 | `MEM_DATABUS` | PASS |  |  |  | 2641026 | 7897 |
| 37 | `MEM_ADDRBUS` | PASS |  |  |  | 2648923 | 12127 |
| 38 | `MEM_BANKSEL` | PASS |  |  |  | 2661050 | 2398 |
| 39 | `MEM_MARCH` | PASS |  |  |  | 2663448 | 1134283 |
| 40 | `MEM_PATTERN` | PASS |  |  |  | 3797731 | 2401844 |
| 41 | `MEM_BYTE` | PASS |  |  |  | 6199575 | 8044 |
| 42 | `ECC_CE` | PASS |  |  |  | 6207619 | 65683 |
| 43 | `ECC_UE` | PASS |  |  |  | 6273302 | 5722 |
| 44 | `DMA_IDLE` | PASS |  |  |  | 6279024 | 1804 |
| 45 | `DMA_FILL` | PASS |  |  |  | 6280828 | 8285 |
| 46 | `DMA_COPY` | PASS |  |  |  | 6289113 | 58845 |
| 47 | `DMA_SIZES` | PASS |  |  |  | 6347958 | 476076 |
| 48 | `DMA_BADPARAM` | PASS |  |  |  | 6824034 | 30625 |
| 49 | `DMA_ERRORS` | PASS |  |  |  | 6854659 | 7487 |
| 50 | `DMA_FWBANK` | PASS |  |  |  | 6862146 | 10035 |
| 51 | `DMA_PERM` | PASS |  |  |  | 6872181 | 64156 |
| 52 | `IRQ_BASE` | PASS |  |  |  | 6936337 | 1805 |
| 53 | `IRQ_MASK` | PASS |  |  |  | 6938142 | 3235 |
| 54 | `IRQ_WFI` | PASS |  |  |  | 6941377 | 5572 |
| 55 | `IRQ_TAKEN` | PASS |  |  |  | 6946949 | 5879 |
| 56 | `IRQ_SOURCES` | PASS |  |  |  | 6952828 | 16550 |
| 57 | `IRQ_MULTI` | PASS |  |  |  | 6969378 | 9095 |
| 58 | `IMG_CRC_POST` | PASS |  |  |  | 6978473 | 1629700 |
| 59 | `STACK_POST` | PASS |  |  |  | 8608173 | 66607 |

## What executed on the CPU

* 2568678 instructions retired, 38 traps taken (cause: count) - 0: 1, 1: 1, 2: 8, 3: 1, 4: 1, 5: 8, 6: 1, 7: 12, 11: 3, interrupt 0x8000000B: 2
* instruction classes retired: op-imm 1126521, op 503858, branch 370858, load 298685, store 185494, jalr 35837, lui 18446, auipc 17847, jal 10157, csr 933, mret 38, fence 3, wfi 1
* function entry coverage and instruction coverage: 4753/6356 words (74.8%)
* functions never executed (all are failure/abort paths or tests that were skipped by design): `OUTLINED_FUNCTION_0`, `OUTLINED_FUNCTION_10`, `bw_early_trap`, `bw_fail`, `bw_fatal`, `bw_longjmp`, `bw_tmo`

