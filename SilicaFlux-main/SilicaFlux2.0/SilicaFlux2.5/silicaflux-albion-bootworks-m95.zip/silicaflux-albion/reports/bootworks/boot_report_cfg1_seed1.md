# BootWorks boot report CONFIG 1 seed 1

* RTL: SilicaFlux Albion `sf_albion_cloud_top` CONFIG 1 - 8 SRAM banks x 16 KiB
* Image: 28556 bytes, loaded through the host MMIO port in BOOT_MODE, read back and verified
* Run: 15578991 cycles from CORE_CTRL.RUN to the completion signature (`completion signature`)
* Verdict: **PASS** (FW_STATUS `0xB007600D`) - PASS 47, FAIL 0, TIMEOUT 0, SKIPPED 1, UNSUPPORTED 12

## Host-side verification

| check | result | detail |
|---|---|---|
| load | PASS | BOOT_MODE before load, 7139 words written+read back through the host port: 0 write errors, 0 mismatches; core halted back into BOOT_MODE: True |
| reset | PASS | first retired instruction: pc 0x00000000 word 0x40000FB7 (image word 0 = 0x40000FB7), retired 32669 cycles into the run window |
| fetch | PASS | 4648436 instruction fetches on fabric master 0: 0 differ from the image, 0 retirements differ from their fetch, 1 fetch error(s) (deliberate: 0x20000000) |
| isa | PASS | reference RV32I+Zicsr model checked 4648399 retired instructions against the RTL trace: 0 mismatches |
| coverage | PASS | 4753/6356 instruction words retired (74.8%); required functions never entered: none |
| signature | PASS | FW_STATUS=0xB007600D FW_VERSION=0x00950100 HEARTBEAT=60 SCRATCH=0x00000000; SRAM report magic/CRC valid (0x401A94BE); mailbox: 1 START + 1 SUMMARY record(s); end: completion signature |
| integrity | PASS | 0 image words changed after the run; peak stack 392 B (limit 768 of 1024) |
| outcomes | PASS | every test ended as the architecture audit predicts |

## Self-test results (read back from SRAM through the host port)

| id | test | outcome | diag | meaning | aux0 / aux1 / aux2 | start cycle | cycles |
|---|---|---|---|---|---|---|---|
| 0 | `CPU_ENTRY` | PASS |  |  |  | 17875 | 2035 |
| 1 | `CPU_IDENT` | PASS |  |  |  | 19910 | 1977 |
| 2 | `ISA_RV32I` | PASS |  |  |  | 21887 | 3559 |
| 3 | `ISA_M` | UNSUPPORTED | 0xF101 | `UNSUP_ISA_M`: RV32M not implemented (mul raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 25446 | 2464 |
| 4 | `ISA_A` | UNSUPPORTED | 0xF102 | `UNSUP_ISA_A`: RV32A not implemented (amoadd.w raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 27910 | 2478 |
| 5 | `ISA_C` | UNSUPPORTED | 0xF103 | `UNSUP_ISA_C`: RVC not implemented (compressed encoding raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 30388 | 2458 |
| 6 | `ISA_F` | UNSUPPORTED | 0xF104 | `UNSUP_ISA_F`: RV32F not implemented (fadd.s raised illegal-instruction) | 0x40000100 / 0x00000000 / 0x00000000 | 32846 | 2455 |
| 7 | `ISA_FENCE` | PASS |  |  |  | 35301 | 2059 |
| 8 | `CSR_BASIC` | PASS |  |  |  | 37360 | 2792 |
| 9 | `CSR_ABSENT` | UNSUPPORTED | 0xF105 | `UNSUP_CSR_HPM`: hardware performance-monitor and debug CSRs not implemented | 0x00000B03 / 0x00000000 / 0x00000000 | 40152 | 2426 |
| 10 | `TRAP_CAUSES` | PASS |  |  |  | 42578 | 6520 |
| 11 | `TRAP_RETURN` | PASS |  |  |  | 49098 | 2836 |
| 12 | `CNT_CYCLE` | PASS |  |  |  | 51934 | 14642 |
| 13 | `TIMER_IRQ` | UNSUPPORTED | 0xF106 | `UNSUP_TIMER_IRQ`: no machine timer or software interrupt (mie.MTIE/MSIE read-only zero) | 0x00000000 / 0x00000000 / 0x00000000 | 66576 | 1959 |
| 14 | `POLL_TIMEOUT` | PASS |  |  |  | 68535 | 2979 |
| 15 | `PLAT_ID` | PASS |  |  |  | 71514 | 1997 |
| 16 | `PLAT_CONFIG` | PASS |  |  |  | 73511 | 4158 |
| 17 | `PLAT_FEATURES` | PASS |  |  |  | 77669 | 1989 |
| 18 | `BOOT_ROM` | UNSUPPORTED | 0xF107 | `UNSUP_BOOT_ROM`: no boot ROM: reset vector is host-loaded SRAM bank 0 | 0x00001660 / 0x00000000 / 0x00000000 | 79658 | 3449 |
| 19 | `UART` | UNSUPPORTED | 0xF108 | `UNSUP_UART`: no UART/console peripheral in the regmap; next MMIO page returns DECERR | 0x40006000 / 0x00000000 / 0x00000000 | 83107 | 2414 |
| 20 | `DEBUG` | UNSUPPORTED | 0xF109 | `UNSUP_DEBUG`: no debug module (debug CSRs illegal) | 0x000007B0 / 0x00000000 / 0x00000000 | 85521 | 2414 |
| 21 | `VECTOR` | UNSUPPORTED | 0xF10A | `UNSUP_VECTOR`: no vector command unit exists in the Albion feature set | 0x000008FF / 0x00000BFF / 0x00000000 | 87935 | 2015 |
| 22 | `TENSOR` | UNSUPPORTED | 0xF10B | `UNSUP_TENSOR`: ComputeWorks (INT8 GEMM) not implemented: FEAT_IMPL bit clear | 0x000008FF / 0x00000000 / 0x00000000 | 89950 | 2027 |
| 23 | `ACCEL_OTHER` | UNSUPPORTED | 0xF10C | `UNSUP_ACCEL_OTHER`: PacketForge/VirtualFoundry not implemented: FEAT_IMPL bits clear | 0x000008FF / 0x00000300 / 0x00000000 | 91977 | 2012 |
| 24 | `HOSTMEM` | SKIPPED | 0xF002 | `SKIP_HOST_DEPENDENT`: skipped: result depends on host/IOMMU configuration, not exercised | 0x80000000 / 0x00000000 / 0x00000000 | 93989 | 1958 |
| 25 | `MAILBOX` | PASS |  |  |  | 95947 | 2244 |
| 26 | `REG_MGMT` | PASS |  |  |  | 98191 | 3446 |
| 27 | `REG_IRQ` | PASS |  |  |  | 101637 | 3370 |
| 28 | `REG_DMA` | PASS |  |  |  | 105007 | 3784 |
| 29 | `REG_PERM` | PASS |  |  |  | 108791 | 4096 |
| 30 | `REG_TELEM` | PASS |  |  |  | 112887 | 5775 |
| 31 | `REG_RAS` | PASS |  |  |  | 118662 | 3475 |
| 32 | `REG_FAULTS` | PASS |  |  |  | 122137 | 5863 |
| 33 | `IMG_CRC` | PASS |  |  |  | 128000 | 1629878 |
| 34 | `BANK0_SWEEP` | PASS |  |  |  | 1757878 | 888150 |
| 35 | `STACK` | PASS |  |  |  | 2646028 | 4643 |
| 36 | `MEM_DATABUS` | PASS |  |  |  | 2650671 | 16009 |
| 37 | `MEM_ADDRBUS` | PASS |  |  |  | 2666680 | 28631 |
| 38 | `MEM_BANKSEL` | PASS |  |  |  | 2695311 | 3134 |
| 39 | `MEM_MARCH` | PASS |  |  |  | 2698445 | 3330315 |
| 40 | `MEM_PATTERN` | PASS |  |  |  | 6028760 | 7055824 |
| 41 | `MEM_BYTE` | PASS |  |  |  | 13084584 | 16068 |
| 42 | `ECC_CE` | PASS |  |  |  | 13100652 | 65875 |
| 43 | `ECC_UE` | PASS |  |  |  | 13166527 | 5914 |
| 44 | `DMA_IDLE` | PASS |  |  |  | 13172441 | 1996 |
| 45 | `DMA_FILL` | PASS |  |  |  | 13174437 | 8861 |
| 46 | `DMA_COPY` | PASS |  |  |  | 13183298 | 59613 |
| 47 | `DMA_SIZES` | PASS |  |  |  | 13242911 | 478956 |
| 48 | `DMA_BADPARAM` | PASS |  |  |  | 13721867 | 32161 |
| 49 | `DMA_ERRORS` | PASS |  |  |  | 13754028 | 8297 |
| 50 | `DMA_FWBANK` | PASS |  |  |  | 13762325 | 10995 |
| 51 | `DMA_PERM` | PASS |  |  |  | 13773320 | 65692 |
| 52 | `IRQ_BASE` | PASS |  |  |  | 13839012 | 1997 |
| 53 | `IRQ_MASK` | PASS |  |  |  | 13841009 | 3427 |
| 54 | `IRQ_WFI` | PASS |  |  |  | 13844436 | 5764 |
| 55 | `IRQ_TAKEN` | PASS |  |  |  | 13850200 | 6071 |
| 56 | `IRQ_SOURCES` | PASS |  |  |  | 13856271 | 16742 |
| 57 | `IRQ_MULTI` | PASS |  |  |  | 13873013 | 9287 |
| 58 | `IMG_CRC_POST` | PASS |  |  |  | 13882300 | 1629892 |
| 59 | `STACK_POST` | PASS |  |  |  | 15512192 | 66799 |

## What executed on the CPU

* 4648399 instructions retired, 38 traps taken (cause: count) - 0: 1, 1: 1, 2: 8, 3: 1, 4: 1, 5: 8, 6: 1, 7: 12, 11: 3, interrupt 0x8000000B: 2
* instruction classes retired: op-imm 2130785, branch 866509, op 734648, load 463989, store 352714, jalr 35893, jal 26561, lui 18450, auipc 17875, csr 933, mret 38, fence 3, wfi 1
* function entry coverage and instruction coverage: 4753/6356 words (74.8%)
* functions never executed (all are failure/abort paths or tests that were skipped by design): `OUTLINED_FUNCTION_0`, `OUTLINED_FUNCTION_10`, `bw_early_trap`, `bw_fail`, `bw_fatal`, `bw_longjmp`, `bw_tmo`

