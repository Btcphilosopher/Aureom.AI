# BootWorks mutation (negative-test) report

25 of 25 injected RTL defects were detected and attributed to the correct test and diagnostic code.

Each row is a real, one-line change to a copy of the Albion RTL; the unmodified BootWorks image was booted on the mutated design.

| mutant | area | injected defect | detected | what BootWorks reported |
|---|---|---|---|---|
| `cpu_sra_is_srl` | CPU ISA | SRA/SRAI shift right logically instead of arithmetically | **yes** | ISA_RV32I: FAIL 0x1022 ISA_SHIFT aux ['0x107', '0xffffffff', '0x1']<br>host check 'isa' FAILED as it must |
| `cpu_sltu_signed` | CPU ISA | SLTU/SLTIU compare as signed | **yes** | ISA_RV32I: FAIL 0x1023 ISA_CMP aux ['0x10', '0x1', '0x0']<br>host check 'isa' FAILED as it must |
| `cpu_bgeu_gt` | CPU ISA | BGEU implemented as 'greater than' (equal operands not taken) | **yes** | ISA_RV32I: FAIL 0x1025 ISA_BRANCH aux ['0x305', '0x1', '0x0']<br>host check 'isa' FAILED as it must |
| `cpu_misa_claims_m` | CPU ISA | misa advertises the M extension that is not implemented | **yes** | ISA_M: FAIL 0x1031 ISA_M_MISA_LIES aux ['0x40001100', '0x0', '0x1'] |
| `cpu_mtvec_mode_bits` | CPU CSR | mtvec keeps its low (mode) bits: vectored mode not forced off | **yes** | CSR_BASIC: FAIL 0x1052 CSR_MTVEC_WARL aux ['0x0', '0x1000', '0x1003'] |
| `cpu_instret_double` | CPU counters | minstret counts two per retired instruction | **yes** | CSR_BASIC: FAIL 0x1059 CSR_ALIAS aux ['0x1', '0x4c38', '0x4c3a']<br>CNT_CYCLE: FAIL 0x9002 CNT_INSTRET aux ['0x0', '0x11', '0x22'] |
| `cpu_mpie_not_saved` | CPU traps | trap entry does not save MIE into MPIE | **yes** | TRAP_RETURN: FAIL 0x2022 TRAP_MSTATUS_ENTRY aux ['0x1', '0x0', '0x80'] |
| `cpu_lw_misalign_ok` | CPU traps | misaligned LW does not raise load-address-misaligned | **yes** | TRAP_CAUSES: FAIL 0x200B TRAP_LMIS_CAUSE aux ['0xffffffff', '0x4', '0x0'] |
| `cpu_irq_never_taken` | Interrupts | machine external interrupt is never taken (irq_take stuck 0) | **yes** | IRQ_TAKEN: TIMEOUT 0x8031 IRQ_NOT_TAKEN aux ['0x4e20', '0x0', '0x4e5e'] |
| `cpu_wfi_never_wakes` | Interrupts | WFI never leaves the sleep state | **yes** | host watchdog: TIMEOUT: host watchdog (FW_STATUS/FW_HEARTBEAT stalled); FW_STATUS=0xB1803600 -> stage 0x80, test IRQ_WFI |
| `soc_irq_ue_not_wired` | Interrupts | ECC_UE interrupt source tied low | **yes** | ECC_UE: FAIL 0x6015 ECC_UE_IRQ aux ['0x0', '0x20', '0x0'] |
| `cpu_wrong_reset_vector` | Reset | RESET_PC = 0x100 instead of 0x0 | **yes** | host check 'reset' FAILED as it must |
| `cpu_fetch_bit_flip` | Fetch path | one bit of the fetched instruction word is corrupted on its way into the decoder (at the entry of boot_main) | **yes** | host check 'fetch' FAILED as it must |
| `sram_one_cell_flips_1bit` | SRAM | one SRAM cell (word 100 of every bank) stores a codeword with 1 bit inverted: ECC corrects it, so only the RAS counter shows it | **yes** | BANK0_SWEEP: FAIL 0x5012 MEM_B0_CE aux ['0x190', '0x2b', '0x2d'] |
| `sram_cell_pair_flips_2bit` | SRAM | two bits of one SRAM word hold the inverse (uncorrectable) inside boot_main's code | **yes** | fatal trap: FW_STATUS=0xDEAD0001 (cause 1) SCRATCH(mepc)=0x514; the corrupted word is at 0x514 |
| `sram_bank2_addr_bit_stuck` | SRAM | word-address bit 4 of SRAM bank 2 stuck at 0 | **yes** | MEM_ADDRBUS: FAIL 0x5041 MEM_ADDR_HIGH aux ['0x8040', '0xaaaaaaaa', '0x55555555'] |
| `fabric_bank3_aliases_bank2` | SRAM | the DataFabric routes bank 3 accesses to bank 2 | **yes** | MEM_BANKSEL: FAIL 0x5051 MEM_BANK_ALIAS aux ['0x8000', '0xb0a00001', '0xb0a00002'] |
| `dma_drops_last_word` | DMA | DMA moves one word fewer than LEN | **yes** | DMA_FILL: FAIL 0x7012 DMA_FILL_DATA aux ['0x0', '0x100', '0xfc'] |
| `dma_corrupts_copy_data` | DMA | DMA copy flips data bit 4 | **yes** | DMA_COPY: FAIL 0x7022 DMA_COPY_DATA aux ['0xe040', '0x0', '0xefef154c'] |
| `dma_never_completes` | DMA | DMA engine stays BUSY forever | **yes** | DMA_FILL: TIMEOUT 0x7015 DMA_FILL_TIMEOUT aux ['0x0', '0x3', '0x100'] |
| `fabric_dma_reaches_bank0` | Protection | hardware invariant broken: DMA may write the firmware bank (BootWorks aims at a sandbox) | **yes** | DMA_FWBANK: FAIL 0x7061 DMA_FW_WRITE aux ['0x0', '0x2', '0x2']<br>firmware image intact after the invariant violation (IMG_CRC_POST PASS, 0 words changed): yes |
| `perm_ignores_domain` | Protection | permission windows match any domain | **yes** | DMA_PERM: FAIL 0x7075 DMA_PERM_DOMAIN aux ['0x4', '0x2', '0x2'] |
| `regs_wrong_chip_id` | Registers | CHIP_ID constant differs (0x53464191) | **yes** | PLAT_ID: FAIL 0x3001 PLAT_CHIP_ID aux ['0x0', '0x53464190', '0x53464191'] |
| `telem_freeze_ignored` | Registers | TELEM freeze does not stop the counters | **yes** | REG_TELEM: FAIL 0x4043 REG_TELEM_FREEZE aux ['0x0', '0x22024', '0x224ec'] |
| `image_bit_flipped_in_sram` | Boot image | one bit of the image flips in SRAM after the host's own verify (a word of code that never executes, so only the CRC can notice) | **yes** | IMG_CRC: FAIL 0x5002 IMG_CRC aux ['0xbe8c5b0a', '0x86d411b4', '0x6f8c'] |
