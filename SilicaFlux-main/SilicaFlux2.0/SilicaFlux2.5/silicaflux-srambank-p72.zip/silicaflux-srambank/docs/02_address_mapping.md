# 02 — Address mapping (normative)

Implemented by `sf_sram_bank_addr_decode` (hardware), specified executably by `model/sf_bank_map.py` (plain integer `/` and
`%`, no bit slicing), proven per configuration by `tb_sf_sram_bank_addr_decode`, and cross-checked by every system-level
testbench, which uses a **byte-accurate reference model indexed by external byte address** (it knows nothing about
banks, so any mapping or aliasing bug shows up as a data mismatch).

## 1. The mapping

For a byte-addressed external request (`BPW` = `BYTES_PER_WORD` = `DATA_WIDTH/BYTE_WIDTH`, a power of two):

```
word_index = byte_address / BPW                 (floor division)
byte_off   = byte_address % BPW
bank_index = word_index % NUM_BANKS             ← the brief's formula (SEQ)
local_word = word_index / NUM_BANKS
```

The general form (B = `BLOCK_WORDS`, 1 for `SEQ`):

```
blk  = word_index / B        sub  = word_index % B
sel  = blk % NUM_BANKS       rowb = blk / NUM_BANKS

SEQ    B = 1                 bank = sel                              local = rowb*B + sub
BLOCK  B = BLOCK_WORDS       bank = sel                              local = rowb*B + sub
XOR    B = BLOCK_WORDS       bank = sel ^ (rowb % NUM_BANKS)         local = rowb*B + sub     (NUM_BANKS power of two)
```

* **SEQ — sequential interleave.** Consecutive words go to consecutive banks.
* **BLOCK — block interleave.** Runs of `B` consecutive words share a bank; the runs rotate over the banks.
  `B = BANK_DEPTH` gives contiguous regions (bank *b* holds words `b·D … (b+1)·D−1`).
* **XOR — skewed sequential/block.** The bank is skewed by the low bits of the row, so power-of-two strides that
  collapse onto one bank under `SEQ` spread out (§6 — with honest limits).
* **Configurable bank selection** = `MAP_MODE` + `BLOCK_WORDS` (+ `NUM_BANKS`); the presets for 2/4/8/16 banks are in
  `examples/sf_sram_bank_presets.svh`. The mode is an elaboration-time parameter: a runtime-switchable map is **not**
  implemented (it would have to re-layout the data).

Worked example (4 banks × 1024 words × 4 bytes; `bank / local`):

| word | byte addr | SEQ | BLOCK B=4 | XOR |
|---|---|---|---|---|
| 0 | 0x0000 | b0 / 0 | b0 / 0 | b0 / 0 |
| 1 | 0x0004 | b1 / 0 | b0 / 1 | b1 / 0 |
| 2 | 0x0008 | b2 / 0 | b0 / 2 | b2 / 0 |
| 3 | 0x000c | b3 / 0 | b0 / 3 | b3 / 0 |
| 4 | 0x0010 | b0 / 1 | b1 / 0 | b1 / 1 |
| 5 | 0x0014 | b1 / 1 | b1 / 1 | b0 / 1 |
| 6 | 0x0018 | b2 / 1 | b1 / 2 | b3 / 1 |
| 7 | 0x001c | b3 / 1 | b1 / 3 | b2 / 1 |
| 8 | 0x0020 | b0 / 2 | b2 / 0 | b2 / 2 |
| 12 | 0x0030 | b0 / 3 | b3 / 0 | b3 / 3 |
| 15 | 0x003c | b3 / 3 | b3 / 3 | b0 / 3 |

## 2. Exact supported address range

```
supported byte addresses :  0  …  NUM_BANKS * BANK_DEPTH * BYTES_PER_WORD − 1
supported word indices   :  0  …  NUM_BANKS * BANK_DEPTH − 1
```

| Configuration (32-bit words, 1024 words/bank) | Capacity | Last valid byte address |
|---|---|---|
| 2 banks | 8 KiB | `0x1FFF` |
| 4 banks | 16 KiB | `0x3FFF` |
| 8 banks | 32 KiB | `0x7FFF` |
| 16 banks | 64 KiB | `0xFFFF` |

* The window is **absolute from address 0**: there is no base-address parameter. The fabric strips the window base
  (the DataFabric SRAM slave passes only the low address bits). If `ADDR_WIDTH` is wider than the capacity needs, **every
  address above the capacity is rejected** (`RANGE`), including every pattern of the high bits — it is never folded back
  onto a valid word (no wrap, no truncation, no mirror). This is the repository-wide policy (library `sram_bank_controller`,
  Module 04 scratchpad `hpc_spm_addr_map`).
* When the capacity is exactly `2^ADDR_WIDTH` the range check is the constant 1 and costs nothing; when only the capacity
  is a power of two it is a NOR of the high bits; otherwise one comparator against a constant.
* `byte_off` is reported by the decoder. With `STRICT_ALIGN=0` it is **ignored** (floor division — exactly the brief's
  formula): sub-word access is expressed by the byte-enable mask, not by the address. With `STRICT_ALIGN=1` a misaligned
  address is rejected (`ALIGN`; `RANGE` has priority).

## 3. Elaboration rules (illegal values fail with a message)

`NUM_BANKS` 2…64 · `BANK_DEPTH` ≥ 2 · capacity ≤ 2²⁴ words · `BYTES_PER_WORD` a power of two ≤ 128 · `BLOCK_WORDS` a power
of two that **divides `BANK_DEPTH`** (otherwise the map would not be a bijection) · `XOR` needs a power-of-two
`NUM_BANKS` · `ADDR_WIDTH` ≥ `clog2(capacity bytes)`, ≤ 32.

## 4. Invertibility and coverage — proved, not argued

For every legal configuration the map `word_index ↦ (bank, local)` is a **bijection** between the `NUM_BANKS·BANK_DEPTH`
words and the `(bank, local)` pairs with `bank < NUM_BANKS`, `local < BANK_DEPTH`:

* `blk ↦ (sel, rowb)` is the division with remainder by `NUM_BANKS` (a bijection from `[0, NUM_BANKS·D/B)` onto
  `[0, NUM_BANKS) × [0, D/B)` — this is where `B | D` is needed); `(rowb, sub) ↦ rowb·B + sub` is a bijection onto
  `[0, D)`; for `XOR`, `sel ↦ sel ^ f(rowb)` is a bijection of `[0, NUM_BANKS)` for fixed `rowb` because `NUM_BANKS` is a
  power of two.
* The inverse is `sf_sram_bank_addr_unmap`.

**Hardware evidence** (`tb_sf_sram_bank_addr_decode`, per configuration): for *every* word the decoder output equals the integer
definition; a coverage array over the physical `(bank, local)` space ends with every cell hit **exactly once** (no
aliasing, no gap); `unmap(decode(a)) == a` for every word and `decode(unmap(b, l)) == (b, l)` for every pair; every
address ≥ the capacity (first invalid word, every single high bit, all-ones, random) is `RANGE`-rejected; strict alignment
flags exactly the misaligned in-range addresses. The Python model proves the same independently, and every RTL dump is
compared against it (`MODEL_COMPARE PASS`). Coverage of the matrix: the `decode` suite in `reports/regression_*.md`.

## 5. Cost: power-of-two versus anything else

* **Power-of-two `NUM_BANKS`**: every `/` and `%` above is a constant shift or mask, i.e. **a bit slice of the address**.
  The generate branch writes it as slices explicitly (it does not rely on the synthesis tool recognising the pattern).
  Bank index and local index are wires; `XOR` adds one XOR gate per bank-index bit.
* **Non-power-of-two `NUM_BANKS`** (`SEQ`, `BLOCK` only): the generate branch uses real constant division and modulo, which
  synthesise to adder / compare networks. This is **not** assumed to be as cheap as slicing — the measured LUT counts are
  in `reports/synth.md` §4 (Yosys, xc7; evidence only).
* A non-power-of-two `BANK_DEPTH` costs one range comparator and nothing in the slicing (it is only the capacity that is
  not a power of two).

## 6. Choosing a mode — what each one helps, measured

Banks touched by 64 accesses at a constant word stride (from `model/sf_bank_map.py`):

| stride (words) | 4 banks SEQ | 4 banks XOR | 8 banks SEQ | 8 banks XOR | 16 banks SEQ | 16 banks XOR |
|---|---|---|---|---|---|---|
| 1 | 4 | 4 | 8 | 8 | 16 | 16 |
| 2 | 2 | 4 | 4 | 8 | 8 | 16 |
| 3 | 4 | 4 | 8 | 8 | 16 | 12 |
| 4 | 1 | 4 | 2 | 8 | 4 | 16 |
| 5 | 4 | 4 | 8 | 8 | 16 | 11 |
| 8 | 1 | 2 | 1 | 8 | 2 | 16 |
| 16 | 1 | 1 | 1 | 4 | 1 | 16 |
| 64 | 1 | 1 | 1 | 1 | 1 | 4 |
| 256 | 1 | 1 | 1 | 1 | 1 | 1 |

* `SEQ` serves unit-stride and odd-stride streams on all banks, and **collapses** onto one bank when the stride is a
  multiple of `NUM_BANKS`.
* `XOR` spreads a stride of `NUM_BANKS` words over **all** banks, spreads larger power-of-two strides over progressively
  fewer banks, and collapses onto one bank at a stride of `NUM_BANKS²` (4 banks: 16; 8 banks: 64; 16 banks: 256). It is
  **not a universal fix**, and for some odd strides it touches *fewer* banks than `SEQ` (16 banks, stride 3: 12 vs 16).
* `BLOCK` keeps short bursts in one bank and suits master-per-region traffic; with `B = BANK_DEPTH` it gives every
  master its own bank. It is the wrong choice for a unit-stride stream from one master.
* Whichever mode is chosen, **same-bank collisions still cost cycles**; software-visible stride awareness remains the
  real fix for a pathological access pattern.
