# 04 — Verification

Everything below is simulation (Verilator 5.020, Icarus 12.0) plus Yosys 0.33. The numbers in the generated blocks come
from the JSON reports of the final run (`make bank-all`; `scripts/make_summary.py` fills them), not from hand-typed
figures.

## 1. Structure

| Layer | File | What it proves |
|---|---|---|
| Mapping | `tb_sf_sram_bank_addr_decode.sv` + `model/sf_bank_map.py` | **exhaustively**, per configuration: every word maps to the integer-definition (bank, local); the physical `(bank, local)` space is covered exactly once (no aliasing, no gap); the RTL inverse round-trips; every address ≥ capacity is `RANGE`; strict alignment. Three independent implementations agree: RTL, TB integer arithmetic, Python model (every RTL dump compared) |
| Per-bank interface | `tb_sf_sram_bank_array.sv` | independent enables / addresses / ops on all banks in the same cycle; per-bank byte-accurate reference; response timing, ID, error for invalid local addresses (non-power-of-two depth, posted writes included), reset, events and busy |
| System | `tb_sf_sram_bank.sv` | lanes → decode → interlock → banks → routing → counters, against a byte-accurate model **indexed by external byte address**, a cycle-exact scoreboard, a backdoor placement check and an independent counter model |

**Byte-accurate reference model.** `ref_b/ref_k` hold every byte by *external byte address* and know nothing of banks; a
byte never written (and with no `INIT_MODE` content) is *unknown* and never compared — unwritten SRAM is not assumed to be
zero. `INIT_MODE=ZERO/PATTERN` configurations define content from the start (the pattern is bank-local, so a mis-placed word
is visible even before the first write).

**Cycle-exact scoreboard** (every clock edge, every lane and bank): recomputes the expected decode of each lane with integer
`/` and `%`; the expected same-bank outcome and compares `req_ready` of every lane; checks each lane's response — valid,
kind, error, `ecode`, ID, data on all known bytes, zero data otherwise — so spurious, missing, late or misrouted responses
fail; checks `st_ready/st_busy/st_access/st_conflict`; and compares **all** performance counters against an independent
event model in every cycle (saturation modelled; a 5-bit counter configuration proves it).

**Backdoor placement check** (`verify_backdoor`, after every phase): peeks every bank array and requires every known byte to
sit at the (bank, row, lane) the mapping defines — independent of the read path, so aliasing and cross-bank corruption cannot hide.

**Closed-form directed checks** read the DUT outputs directly so the checker cannot just agree with an RTL bug:
*n* lanes onto one bank must give exactly *n−1* conflict events, *n(n−1)/2* stalled lane-cycles, one active bank per cycle;
independent banks must all be granted in one cycle with `hist[n] = 2`; the lowest lane must win; the denied lane must be
granted next cycle; a denied-and-withdrawn request must have no effect.

## 2. The brief's test list → where it is covered

| Brief item | Phase / TB |
|---|---|
| Every bank | `every_bank` (every row of every bank written and read back) |
| Sequential address mapping | `sequential_map`; the mapping TB; Python model |
| Simultaneous independent accesses | `parallel_independent` (one write per bank in one cycle, a 16-cycle sustained stream, `hist[n]` closed form); `tb_sf_sram_bank_array` |
| Same-bank contention | `same_bank_contention` (a–f: two lanes, all lanes, same word, read vs write, withdrawn request, mixed with independent banks) |
| Partial byte writes | `partial_byte_writes` (every single lane, every mask — exhaustive up to 8 lanes — zero strobes, several lanes at once) |
| Back-to-back operations | `back_to_back` (W/R/W/R same bank, R-W-R, W-W-R, alternating banks, all lanes every cycle) |
| Reset | `reset` (contents survive, in-flight dropped, request during reset not accepted, counters cleared) + random resets inside traffic |
| Invalid addresses | `invalid_addresses` (first invalid word, every power of two above the capacity, all-ones, misaligned; interleaved with valid traffic; no corruption) |
| Random bank traffic | `random_traffic` (hot bank, few-row reuse, stride-NB, sequential, random gaps, invalid addresses, resets) |
| No cross-bank corruption | `cross_bank_isolation` (each bank rewritten in turn while all others are backdoor-compared) + `verify_backdoor` after every phase |

## 3. Results

<!--RESULTS-->
| Check | Result | Notes |
|---|---|---|
| Lint: Verilator `-Wall` (zero warnings) + Icarus `-Wall` elaboration | 48 pass / 0 fail | sf_sram_bank over 12 configurations x {with, without `SYNTHESIS`}, every sub-module, decoder matrix |
| Illegal parameterisations rejected | 69 pass / 0 fail | 23 cases x Verilator, Icarus, Yosys; explicit message reached in 40/69 (a tool may abort on its own width error first) |
| Address mapping proof (exhaustive): correct / injective / surjective / invertible / bounded | 50 pass / 0 fail | 1,048,817 checks; 50 RTL dumps identical to the Python model; SEQ, BLOCK, XOR; 2-16 banks and 3,5,6,7,12 |
| Per-bank interface (independent enables / addresses), `sf_sram_bank_array` | 19 pass / 0 fail | 6,899,481 checks, 1-16 banks, latency 1-3, posted writes, non-power-of-two depth |
| `sf_sram_bank` self-checking simulation, **TWO banks** | 23 pass / 0 fail | 8,465,573 scoreboard checks; Verilator vs Icarus: 6/6 identical check counts (same stimulus); bank counts exercised: 2 (PASS) |
| `sf_sram_bank` self-checking simulation, **FOUR banks** | 29 pass / 0 fail | 23,754,176 scoreboard checks; Verilator vs Icarus: 9/9 identical check counts (same stimulus); bank counts exercised: 4 (PASS) |
| `sf_sram_bank` self-checking simulation, EIGHT and SIXTEEN banks | 21 pass / 0 fail | 100,665,287 scoreboard checks; Verilator vs Icarus: 5/5 identical check counts (same stimulus); bank counts exercised: 8, 16 (PASS) |
| `sf_sram_bank` self-checking simulation, non-power-of-two bank counts | 5 pass / 0 fail | 3,542,632 scoreboard checks; Verilator vs Icarus: 1/1 identical check counts (same stimulus); bank counts exercised: 3, 5, 6, 12 (PASS) |
| **Bank-conflict gate** (before 8/16 banks): interlock + conflict-counter mutants killed on 2 AND 4 banks | PASS | 14 mutants |
| Mutation sanity: injected RTL bugs | 53 killed / 0 survived / 0 invalid | of 53; `reports/mutants.md` |
| Yosys: one memory inferred per bank, zero latches | PASS | 72 synthesis rows (generic, xc7, ice40, ecp5, depth sweep, decoder cost); `reports/synth.md` |

Tools: verilator `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`; iverilog `Icarus Verilog version 12.0 (stable) ()`; yosys `Yosys 0.33 (git sha1 2584903a060)`; python `3.13.18`.  Not installed: vivado, quartus, openroad.  RTL sha256 `7a24d142887dc87d…`.
<!--/RESULTS-->

The 2-bank and 4-bank stages ran first; the 8/16-bank stage ran only after the conflict gate passed for the exact RTL.

## 4. Mutation sanity — would the testbench notice?

One RTL bug at a time is injected into a scratch copy of `rtl/bank` (the delivered RTL is never touched) and the testbench
must **fail**. The unmutated RTL is run first on the same pairs and must pass. `INVALID` = the patch did not apply or the
mutant did not compile (it proves nothing and is reported as such); `SURVIVED` = the testbench would not notice the bug.
The `conflict` group is the **gate** between 4 and 8/16 banks.

<!--MUT-->
| id | group | status | what was broken | killed by |
|---|---|---|---|---|
| C01 | conflict | KILLED | highest lane index wins instead of the lowest | bank:b2_seq, bank:b4_seq |
| C02 | conflict | KILLED | losing lane is never marked denied | bank:b2_seq, bank:b4_seq |
| C03 | conflict | KILLED | req_ready ignores the interlock: a denied lane believes it was accepted | bank:b2_seq, bank:b4_seq |
| C04 | conflict | KILLED | conflict event needs three requesters instead of two | bank:b2_seq, bank:b4_seq |
| C05 | conflict | KILLED | stall count is requesters, not requesters-1 | bank:b2_seq, bank:b4_seq |
| C06 | conflict | KILLED | bank writes lane 0's data whichever lane won | bank:b4_seq |
| C07 | conflict | KILLED | bank uses lane 0's byte enables whichever lane won | bank:b4_seq |
| C08 | conflict | KILLED | bank uses lane 0's write enable whichever lane won | bank:b4_seq |
| C09 | conflict | KILLED | rejected (invalid) requests enter the bank interlock | bank:b2_awx3, bank:b4_awx2 |
| C10 | conflict | KILLED | per-bank conflict status stuck low | bank:b2_seq, bank:b4_seq |
| C11 | conflict | KILLED | on a collision nobody is granted (all lanes denied) | bank:b2_seq, bank:b4_seq |
| C12 | conflict | KILLED | conflict counter never counts | bank:b2_seq, bank:b4_seq |
| C13 | conflict | KILLED | stall counter never counts | bank:b2_seq, bank:b4_seq |
| C14 | conflict | KILLED | bank address taken from lane 0 whichever lane won | bank:b4_seq |
| M01 | map | KILLED | bank-select mask one bit short | decode:d4_seq, bank:b4_seq |
| M02 | map | KILLED | row index drops a bit: two words alias | decode:d4_seq, bank:b4_seq |
| M03 | map | KILLED | XOR skew disabled | decode:d4_xor, bank:b4_xor |
| M04 | map | KILLED | off-by-one in the range check (non-power-of-two capacity) | decode:d4_d1000_blk8, bank:b4_d1000 |
| M05 | map | KILLED | high address bits ignored: out-of-range addresses alias | decode:d4_wide, bank:b4_awx2 |
| M06 | map | KILLED | STRICT_ALIGN ignored (always strict) | decode:d4_seq, bank:b4_seq |
| M07 | map | KILLED | ALIGN takes priority over RANGE | decode:d4_wide_strict_xor |
| M08 | map | KILLED | intra-block offset mask wrong | decode:d4_blk4, bank:b4_block4 |
| M09 | map | KILLED | intra-block offset dropped from the local address | decode:d4_blk4, bank:b4_block4 |
| M10 | map | KILLED | byte offset taken from the wrong address bits | decode:d4_seq, bank:b4_strict_xor |
| M11 | map | KILLED | generic (non-power-of-two) branch: bank = quotient | decode:dx_b3_seq |
| M12 | map | KILLED | generic (non-power-of-two) branch: row = remainder | decode:dx_b5_seq |
| M13 | map | KILLED | inverse mapping drops the bank | decode:d4_seq |
| R01 | resp | KILLED | transaction ID not forwarded to the bank | bank:b4_seq |
| R02 | resp | KILLED | every response is routed to lane 0 | bank:b4_seq |
| R03 | resp | KILLED | error response of a posted write is dropped | bank:b4_strict_posted, bank:b2_awx3_posted |
| R04 | resp | KILLED | read data leaks onto write acknowledgements | bank:b4_seq |
| R05 | resp | KILLED | rejected-request response not aligned to READ_LATENCY | bank:b4_awx2_lat3, bank:b4_strict_posted |
| R06 | resp | KILLED | error code inverted | bank:b4_awx2 |
| R07 | resp | KILLED | rejected write reported as a read response | bank:b4_awx2 |
| R08 | resp | KILLED | response ID taken from the lane-index field | bank:b4_seq |
| A01 | array | KILLED | posted writes are acknowledged | array:a4_lat3_na, bank:b4_lat3_noack |
| A02 | array | KILLED | ID pipeline: later stages reload stage 0 (equivalent at latency 2: needs 3) | array:a4_lat3 |
| A03 | array | KILLED | busy ignores operations in the read pipeline | array:a4, bank:b4_seq |
| A04 | array | KILLED | completion event raised at issue instead of at the response | array:a4, bank:b4_seq |
| A05 | array | KILLED | bank ready during reset | array:a4, bank:b4_seq |
| A06 | array | KILLED | in-flight responses survive reset | array:a4, bank:b4_seq |
| A07 | array | KILLED | write-error flag lost in the latency pipeline | array:a4_d100_l2na |
| A08 | array | KILLED | invalid-address writes are not reported | array:a4_d100 |
| A09 | array | KILLED | access event ignores reset | array:a4 |
| P01 | perf | KILLED | concurrency histogram shifted by one | bank:b4_seq |
| P02 | perf | KILLED | idle counter counts busy cycles | bank:b4_seq |
| P03 | perf | KILLED | counters wrap instead of saturating | bank:b4_cnt5, bank:b2_cnt5 |
| P04 | perf | KILLED | perf_clear leaves the histogram | bank:b4_seq |
| P05 | perf | KILLED | every rejected request counted as RANGE | bank:b4_strict_xor |
| P06 | perf | KILLED | busy counter counts accesses only | bank:b4_seq |
| P07 | perf | KILLED | cycle counter counts only active cycles | bank:b4_seq |
| P08 | perf | KILLED | access counter counts completions | bank:b4_seq |
| X01 | misc | KILLED | lanes ready during reset | bank:b4_seq |
<!--/MUT-->

What the mutation runs taught while this package was developed (kept here because it is the honest history of the
verification, not only its end state):

* Four mutants first came out `INVALID` because Icarus rejects constant part-selects inside `always_comb` (a property of the
  mutant text, not a verdict on the testbench). Mutant C09 (invalid requests entering the interlock) first *survived* because I
  had assigned it a configuration in which no invalid address can exist.
* The first **full** run on the final RTL found **five survivors**. Analysis: **four were real gaps in what had been
  verified** and **one was an equivalent mutant**.
  * R03 / R05 (posted-write errors; rejected-request responses at latency ≥ 2): the configurations that had posted writes or
    latency > 1 had *no way to produce an invalid address*, so that path was never exercised at system level. Added
    `b2_awx3_posted`, `b4_awx2_lat3`, `b4_strict_posted` (invalid / misaligned addresses × posted writes × latency 2–3).
  * A02 (ID pipeline reload): equivalent at latency 2, so it needs latency 3; the array testbench gained an `a4_lat3` run.
  * A09 (access event ignores reset): **no testbench ever presented a request while `rst_n` was low** (the system block gates it
    away; the array testbench cleared its requests before asserting reset). The array testbench gained a `request_during_reset`
    phase (writes and reads held through the reset; no event, no busy, no response, and the contents unchanged afterwards).
  * X02 (a rejected lane "also" required not to lose arbitration): a rejected lane can never lose arbitration, so the
    mutation cannot change behaviour. Removed as an equivalent mutant rather than counted as a kill or a miss.
* Separately, the 8/16-bank stage once silently ran **no 16-bank configuration** (a mis-tagged table entry); a coverage record
  per stage now fails the run unless every bank count the stage claims was actually simulated.

## 5. Simulator notes (things that bit during development)

* **Verilator 5.020 `--timing`, part-select drive.** The first system run failed with every access going to row 0. It looked
  like an RTL bug; it was not. A minimal reproduction showed Icarus correct, and Verilator correct only when the testbench
  assigned the DUT input vector **whole** instead of by part-select (`addr[10:0] = …`): with a part-select the combinational
  logic downstream of the decoder's output port stayed stale. The testbenches therefore drive whole vectors. Observed and
  worked around; **not root-caused** inside Verilator.
* **Icarus 12 limits** worked around in the testbenches: no `break`, no `return` in tasks, array elements as task outputs can
  crash `vvp`, `automatic` variables inside processes unsupported, constant part-selects in `always_*` print `sorry:`.
* **Same seed → same stimulus.** SystemVerilog leaves the evaluation order of side-effecting calls inside one expression
  unspecified; random draws are therefore sequenced statement by statement, and the two simulators report **identical check
  counts** for the same seed (the `*-xsim` records).
* **Yosys 0.33** rejects packed two-dimensional arrays; the RTL uses flat vectors with `+:` slicing. It was found by the
  synthesis run, not by simulation — simulators accepted the original.
* **Lint** is Verilator `-Wall -fno-inline` with zero warnings. `-fno-inline` avoids a `VARHIDDEN` between two *vendored,
  unmodified* P71 files that only appears when Verilator inlines ≥ 16 core instances.

## 6. Measured concurrency (workloads)

Simulation of this RTL with fixed-priority interlock and requesters that hold until accepted: 400 ops per lane, 70 % reads
/ 30 % writes. `ops/cycle` = lane requests served per active cycle. **One single-port bank cannot exceed 1.0**; the banked
subsystem approaches `NUM_BANKS` only when concurrent requests fall on different banks.

<!--CONC-->
`ops/cycle` = lane requests served per active clock cycle.  One single-port bank can never exceed 1.0; the banked subsystem reaches up to NUM_BANKS only when concurrent requests fall on different banks.

| config | workload | banks | lanes | map | ops | active cycles | ops/cycle | peak banks in one cycle | conflict events | stalled lane-cycles |
|---|---|---|---|---|---|---|---|---|---|---|
| b2_seq | unit | 2 | 2 | SEQ | 800 | 400 | 2.00 | 2 | 0 | 0 |
| b2_seq | stride | 2 | 2 | SEQ | 800 | 800 | 1.00 | 1 | 400 | 400 |
| b2_seq | region | 2 | 2 | SEQ | 800 | 401 | 2.00 | 2 | 1 | 1 |
| b2_seq | random | 2 | 2 | SEQ | 800 | 622 | 1.29 | 2 | 222 | 222 |
| b2_seq | hot | 2 | 2 | SEQ | 800 | 668 | 1.20 | 2 | 268 | 268 |
| b2_seq | samebank | 2 | 2 | SEQ | 800 | 800 | 1.00 | 1 | 400 | 400 |
| b4_seq | unit | 4 | 4 | SEQ | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_seq | stride | 4 | 4 | SEQ | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b4_seq | region | 4 | 4 | SEQ | 1600 | 403 | 3.97 | 4 | 3 | 6 |
| b4_seq | random | 4 | 4 | SEQ | 1600 | 735 | 2.18 | 4 | 537 | 663 |
| b4_seq | hot | 4 | 4 | SEQ | 1600 | 1095 | 1.46 | 3 | 727 | 1347 |
| b4_seq | samebank | 4 | 4 | SEQ | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b4_contig | unit | 4 | 4 | BLOCK(B=256) | 1600 | 592 | 2.70 | 4 | 192 | 384 |
| b4_contig | stride | 4 | 4 | BLOCK(B=256) | 1600 | 448 | 3.57 | 4 | 48 | 96 |
| b4_contig | region | 4 | 4 | BLOCK(B=256) | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_contig | random | 4 | 4 | BLOCK(B=256) | 1600 | 738 | 2.17 | 4 | 524 | 647 |
| b4_contig | hot | 4 | 4 | BLOCK(B=256) | 1600 | 1102 | 1.45 | 4 | 728 | 1340 |
| b4_contig | samebank | 4 | 4 | BLOCK(B=256) | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b4_xor | unit | 4 | 4 | XOR | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_xor | stride | 4 | 4 | XOR | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_xor | region | 4 | 4 | XOR | 1600 | 669 | 2.39 | 4 | 269 | 275 |
| b4_xor | random | 4 | 4 | XOR | 1600 | 737 | 2.17 | 4 | 536 | 670 |
| b4_xor | hot | 4 | 4 | XOR | 1600 | 1092 | 1.47 | 3 | 709 | 1332 |
| b4_xor | samebank | 4 | 4 | XOR | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b8_seq | unit | 8 | 8 | SEQ | 3200 | 400 | 8.00 | 8 | 0 | 0 |
| b8_seq | stride | 8 | 8 | SEQ | 3200 | 3200 | 1.00 | 1 | 2800 | 11200 |
| b8_seq | region | 8 | 8 | SEQ | 3200 | 407 | 7.86 | 8 | 7 | 28 |
| b8_seq | random | 8 | 8 | SEQ | 3200 | 806 | 3.97 | 7 | 1134 | 1569 |
| b8_seq | hot | 8 | 8 | SEQ | 3200 | 1894 | 1.69 | 4 | 1555 | 5790 |
| b8_seq | samebank | 8 | 8 | SEQ | 3200 | 3200 | 1.00 | 1 | 2800 | 11200 |
| b8_xor | unit | 8 | 8 | XOR | 3200 | 400 | 8.00 | 8 | 0 | 0 |
| b8_xor | stride | 8 | 8 | XOR | 3200 | 400 | 8.00 | 8 | 0 | 0 |
| b8_xor | region | 8 | 8 | XOR | 3200 | 720 | 4.44 | 8 | 631 | 770 |
| b8_xor | random | 8 | 8 | XOR | 3200 | 811 | 3.95 | 7 | 1136 | 1616 |
| b8_xor | hot | 8 | 8 | XOR | 3200 | 1898 | 1.69 | 5 | 1544 | 5786 |
| b8_xor | samebank | 8 | 8 | XOR | 3200 | 3200 | 1.00 | 1 | 2800 | 11200 |
| b16_seq | unit | 16 | 16 | SEQ | 6400 | 400 | 16.00 | 16 | 0 | 0 |
| b16_seq | stride | 16 | 16 | SEQ | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
| b16_seq | region | 16 | 16 | SEQ | 6400 | 415 | 15.42 | 16 | 15 | 120 |
| b16_seq | random | 16 | 16 | SEQ | 6400 | 828 | 7.73 | 13 | 2303 | 3321 |
| b16_seq | hot | 16 | 16 | SEQ | 6400 | 3520 | 1.82 | 8 | 3182 | 24618 |
| b16_seq | samebank | 16 | 16 | SEQ | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
| b16_xor | unit | 16 | 16 | XOR | 6400 | 400 | 16.00 | 16 | 0 | 0 |
| b16_xor | stride | 16 | 16 | XOR | 6400 | 400 | 16.00 | 16 | 0 | 0 |
| b16_xor | region | 16 | 16 | XOR | 6400 | 731 | 8.76 | 16 | 1151 | 1704 |
| b16_xor | random | 16 | 16 | XOR | 6400 | 832 | 7.69 | 13 | 2323 | 3489 |
| b16_xor | hot | 16 | 16 | XOR | 6400 | 3522 | 1.82 | 9 | 3193 | 24583 |
| b16_xor | samebank | 16 | 16 | XOR | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
| b16_block4 | unit | 16 | 16 | BLOCK(B=4) | 6400 | 403 | 15.88 | 16 | 12 | 24 |
| b16_block4 | stride | 16 | 16 | BLOCK(B=4) | 6400 | 1600 | 4.00 | 4 | 4800 | 9600 |
| b16_block4 | region | 16 | 16 | BLOCK(B=4) | 6400 | 460 | 13.91 | 16 | 60 | 480 |
| b16_block4 | random | 16 | 16 | BLOCK(B=4) | 6400 | 829 | 7.72 | 13 | 2341 | 3432 |
| b16_block4 | hot | 16 | 16 | BLOCK(B=4) | 6400 | 3510 | 1.82 | 7 | 3178 | 24501 |
| b16_block4 | samebank | 16 | 16 | BLOCK(B=4) | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
<!--/CONC-->

How to read it (all of it measured, none assumed):

* **`samebank` is exactly 1.00 for every configuration and every map** — every lane on one bank is served one access per cycle,
  the single-port limit. The conflict counts match the closed form (4 lanes × 400 ops: 1,200 conflict events, 400·(3+2+1) = 2,400
  stalled lane-cycles). Banking does not, and cannot, beat this.
* **`unit` reaches NUM_BANKS** (2 / 4 / 8 / 16 ops per cycle) under `SEQ` and `XOR` with no conflicts: the concurrency is real
  and the banks work independently.
* **`stride` (multiples of `NUM_BANKS` words)** collapses to 1.00 under `SEQ` and is fully spread by `XOR` (stride = `NUM_BANKS`
  only — docs/02 §6 shows `XOR` collapses again at `NUM_BANKS²`). `BLOCK(B=4)` on 16 banks serves 4.00.
* **`region`** (each lane streams its own contiguous region): under `SEQ` the lanes collide at the start, are *skewed* by one
  cycle each by the retries, and then stream conflict-free (3 / 7 / 15 conflict events for 4 / 8 / 16 lanes) — a dynamic of lanes that
  hold until accepted, **not a guarantee**: `XOR` drops to 2.39 / 4.44 / 8.76 on the same traffic and only `BLOCK` with one region per
  bank is conflict-free by construction (`b4_contig`: 4.00).
* **`random`** lands at about half of `NUM_BANKS` (1.29 / 2.18 / 3.97 / 7.73) and **`hot`** (half the traffic on bank 0) is
  bounded near 1.2 – 1.8 whatever the bank count: contention on one bank, not the number of banks, sets the throughput.
* `peak banks in one cycle` is taken from the workload's own concurrency histogram, not from the testbench lifetime.

Workloads: `unit` striped unit stride (lane *p* takes words *p, p+NP, …*); `stride` every access a multiple of `NUM_BANKS`
words; `region` each lane streams its own contiguous region; `random` uniform; `hot` half of all traffic on bank 0;
`samebank` every lane on bank 0 (the worst case: serialised to 1 op per cycle).

## 7. What is not verified

No formal proof, no gate-level simulation, no real macro, no vendor FPGA tool, no timing. Coverage is simulation-based (the
random phases use a deterministic PRNG with the listed seeds). The Verilator-vs-Icarus equality of check counts shows the
stimulus is identical, not that either simulator is bug-free.
