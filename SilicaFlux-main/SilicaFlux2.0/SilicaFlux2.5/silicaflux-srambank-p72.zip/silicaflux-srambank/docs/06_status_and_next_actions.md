# 06 — Status and next actions

## Definition of done — where it stands

> *Multiple SRAM banks operate independently with correct mapping and measurable concurrency, without violating
> individual macro-port constraints.*

| Clause | Evidence | Status |
|---|---|---|
| Multiple SRAM banks operate independently | `sf_sram_bank_array` drives every bank from its own port in the same cycle; `tb_sf_sram_bank_array` and `perf_hist[NUM_BANKS] > 0` show all banks served together (docs/04) | met in simulation |
| Correct mapping | exhaustive per-configuration proof (correct, injective, surjective, invertible, bounded), RTL = TB integer model = Python model; system testbenches use a byte-accurate reference indexed by external byte address | met |
| Measurable concurrency | `perf_hist`, per-bank access / busy / idle / conflict / stall counters, cross-checked against an independent model every cycle; workload table in `reports/concurrency.md` | met in simulation |
| Without violating individual macro-port constraints | every bank is one single-port `sf_sram_core`; the interlock guarantees **at most one access per bank per cycle** (a mutant that removes it is caught, docs/04 §4); nothing claims more than one access per bank per cycle | met at the RTL level; **no real macro was instantiated** (below) |
| Order of the brief: 2 banks → 4 banks → validate conflicts → 8/16 | run in that order; the 8/16 stage refuses to run without a conflict-gate result for the exact RTL | followed |

## What is *not* done (and not claimed)

* **No vendor tool.** FPGA inference was checked with Yosys 0.33 only. Vivado / Quartus mapping, read-during-write mode and
  whether a `READ_LATENCY ≥ 2` stage merges into the RAM output register are **unverified**. `synth/vivado/synth_srambank.tcl`
  exists to check them and was **not run**.
* **No timing, no area in µm², no power.** The combinational path `req_addr → decode → interlock → req_ready` and the
  per-bank request mux grow with `NUM_PORTS × NUM_BANKS`; they were not timed.
* **No ASIC macro.** `sf_sram_core` is a behavioural single-port macro model. Mapping a bank to a real compiler macro
  (its own cycle, enable, write-mask and power rules) is a replacement of the array behind the same raw interface (P71
  docs/03), not exercised here.
* **No formal proof** of the interlock or the mapping (the mapping is proved exhaustively by simulation per configuration).
* **No gate-level simulation** of the synthesised netlists (P71 did one for the core).
* The interlock is **fixed priority**; there is no fairness, no response back-pressure, no credits (SRAMController).
* The XOR skew is not a general stride cure; there is no runtime-switchable interleave.

## Next actions, in order of value

1. **SRAMController** (the next module in the series): per-bank fair arbitration in front of `sf_sram_bank_array` or of the
   lanes, response credits/FIFOs, QoS. Integration contract: docs/03 §3. Acceptance check that comes for free: with a
   conforming controller `perf_conflict` and `perf_stall` stay zero.
2. **Run `synth/vivado/synth_srambank.tcl`** (and a Quartus equivalent) on the real target and compare with `reports/synth.md`.
3. **Per-bank ECC / parity** by widening `DATA_WIDTH` and `BYTE_WIDTH=9`, or by the RAS project's SECDED around each bank.
4. **Formal**: prove "at most one grant per bank per cycle", "grant ⊆ request", and response-lane uniqueness with SymbiYosys
   (the library already does this for `sram_bank_controller`).
5. **Timing**: place-and-route at the target clock for `NUM_PORTS × NUM_BANKS` = 4×4 … 16×16; the decode → interlock →
   request-mux cone is the likely long path; a registered request stage (one more latency cycle) is the usual fix and is not
   implemented.
6. **Macro mapping**: replace the array of each bank by a technology macro behind the same raw interface and re-run the
   byte-accurate scoreboard.
