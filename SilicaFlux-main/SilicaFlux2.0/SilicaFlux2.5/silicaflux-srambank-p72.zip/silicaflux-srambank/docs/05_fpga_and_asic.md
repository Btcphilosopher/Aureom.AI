# 05 — FPGA and ASIC implementation

**Evidence level: Yosys 0.33 inference only.** No Vivado / Quartus / Radiant, no place-and-route, no timing, no board, no
ASIC flow. Full tables: `reports/synth.md` (every row's exact Yosys script is in `reports/synth.json`).

## 1. One physical memory block per logical bank — checked

Each bank is one `sf_sram_core` → one `sf_sram_array` → one inferred memory (coding template: single clock, read in the
`else` of the write enable, per-lane write enables, no reset on storage — the single-port byte-write template recognised by
the vendor tools; no `ram_style` attribute, the tool chooses).

| Check (Yosys, 32-bit × 1024 words per bank) | 2 banks | 4 banks | 8 banks | 16 banks |
|---|---|---|---|---|
| memories inferred (generic synthesis) | 2 | 4 | 8 | 16 |
| latches | 0 | 0 | 0 | 0 |
| xc7 `RAMB36E1` | 2 | 4 | 8 | 16 |
| ice40 `SB_RAM40_4K` | 16 | 32 | 64 | 128 |
| ECP5 `DP16KD` | 4 | 8 | 16 | 32 |

`memories == banks` at every size and `check -assert` is clean. Per bank that is **1 × RAMB36E1** (xc7), **8 × SB_RAM40_4K**
(ice40), **2 × DP16KD** (ECP5): the number of primitives per bank is a property of the *target and the bank shape*, not of
this design.

## 2. An inferred bank is not always a block RAM

Depth sweep, 4 banks × 32 bits, xc7 (counters off):

| words per bank | what Yosys built |
|---|---|
| 16, 32 | distributed RAM (`RAM32M`), **no block RAM** |
| 64 | distributed RAM (`RAM64X1S` × 128) |
| 128 | distributed RAM (`RAM128X1S` × 128) |
| 256, 512 | block RAM, one `RAMB18E1` per bank |
| 1024 | one `RAMB36E1` per bank |
| 2048 / 4096 | 2 / 4 `RAMB36E1` per bank |

So a design with small banks will not get one dedicated BRAM per bank on this target, and a deep bank spans several
primitives. Other devices and tool versions will differ — **check the real mapping** with `synth/vivado/synth_srambank.tcl`
(prints one line per RAM cell with its hierarchical name, `g_bank[b]`), which was **not run** here.

## 3. Things Yosys cannot tell you

* **Read-during-write mode.** A bank performs one operation per cycle (a read *or* a write), so a same-cycle read/write to
  one word cannot occur *within* a bank; the next-cycle read-after-write is a normal synchronous-read RAM case. How a vendor tool
  chooses the RAM's read-during-write mode for the template was not checked.
* **`READ_LATENCY ≥ 2`.** The extra stage may or may not merge into the block RAM's optional output register (P71 notes Yosys
  0.33 does not merge it). Not checked with a vendor tool.
* **Byte-enable mapping** was inferred by Yosys without error into the block-RAM primitives above; the exact write-enable
  wiring per target was not inspected.
* **Single port is a design choice, not a device limit.** Many FPGA block RAMs are physically true-dual-port. This design
  uses one port per bank, and **claims nothing more**: concurrency comes only from banking.

## 4. What the lane front end costs

`sf_sram_bank` contains a full lane × bank crossbar (request mux per bank, response routing per lane). Yosys LUT counts on
xc7 (32-bit × 1024 per bank, counters off, `NUM_PORTS = NUM_BANKS`): **203 / 1,242 / 4,126 / 18,225** LUTs for 2 / 4 / 8 / 16 banks —
roughly proportional to lanes × banks — against **16 / 32 / 64 / 128** LUTs for the crossbar-free `sf_sram_bank_array`. The RTL
is not area-tuned and these are scaling evidence, not an area claim. For large bank counts a controller that arbitrates per
bank and drives `sf_sram_bank_array` directly avoids the crossbar; the lane front end is the convenient self-checking option
for small bank counts. The performance counters (up to 7 × `NUM_BANKS` + (`NUM_BANKS`+1) + 3 32-bit counters) are a separate, optional
cost (`PERF_EN=0`): e.g. 4 banks, 2,123 LUTs / 992 FFs with counters versus 1,242 LUTs / 32 FFs without. (992 − 32 = 960 flops = 30
counters, not the 36 defined: Yosys prunes counters that are provably zero in that configuration — the bank-error counters, and
the range/align counters when no invalid address can occur.)

## 5. Address decoding cost

Power-of-two `NUM_BANKS` decode with bit slices: **0 LUTs** for `SEQ` and `BLOCK` (capacity exactly 2ⁿ bytes), 1–4 LUTs for
`XOR` (one XOR per bank-index bit), 2 LUTs for a two-bit range check or the strict-alignment flag. A non-power-of-two bank
count costs **368–669 LUTs and 135–181 CARRY4** for the decoder alone (3 … 15 banks): Yosys 0.33 builds a general divider for a
constant divisor, so this is an upper-end figure — a vendor tool may reduce constant division — but it is never free, and the
power-of-two path needs none of it. Keep `NUM_BANKS` a power of two unless there is a reason not to.

## 6. ASIC

**Not done.** `sf_sram_core` is a behavioural single-port macro model; no liberty file, SRAM compiler or PDK was available and no
area, power or access-time number exists. What the architecture already guarantees for a real macro:

* **at most one access per bank per cycle** (the interlock, or the single request port of `sf_sram_bank_array`) — the macro's
  port limit is never exceeded, and a mutant that removes the interlock is caught by the testbench;
* each bank sits behind the raw interface `ce / we / wmask / addr / wdata / rdata` with fixed `READ_LATENCY`, so a technology
  macro replaces the array of a bank behind the same interface (P71 `docs/03` §4); the byte-accurate scoreboard can then be re-run
  unchanged. A macro with different cycle/enable/write-mask semantics needs a wrapper; **none was written or exercised**.
* every bank is an independent macro instance: `NUM_BANKS` macros, floorplanning and the `NUM_PORTS × NUM_BANKS` crossbar wiring
  are physical-design questions that were not assessed; MBIST is not provided (the library's collar can be added per bank).
