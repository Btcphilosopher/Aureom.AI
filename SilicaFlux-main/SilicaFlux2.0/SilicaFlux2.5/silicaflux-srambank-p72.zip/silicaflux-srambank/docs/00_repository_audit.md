# 00 — Repository audit

Scope: everything in the repository that touches SRAM cores and wrappers, banking, scratchpads, memory controllers,
DataFabric, tensor/vector memories, address conventions and test infrastructure — read **before** writing RTL.

## 1. Method, and what was run versus only read

The repository (`Btcphilosopher/Aureom.AI`) is a collection of delivered archives; the SilicaFlux material is under
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` as `.zip` files, plus loose `.sf` files (SystemVerilog under a different
extension). Relevant archives were extracted into a scratch directory (never into the repository) and read.

| Activity | Status |
|---|---|
| `silicaflux-sramcore-p71.zip` (**`sf_sram_core`**) extracted; its `SHA256SUMS` checked against every file | done: all OK |
| `sf_sram_core` primary regression (`make sram-primary`, Verilator 5.020 + Icarus 12.0) **re-run in this environment** | done: 4 pass / 0 fail |
| The three core files and `tb_common.svh` vendored here: SHA-256 compared with the P71 manifest | identical |
| Source read in full: `sf_sram_core.sv`, `sf_sram_array.sv`, `sf_sram_defs.svh`, `sram_bank_controller.sv` (header, interface, decode), `hpc_spm_addr_map.sv`, `hpc_spm_perf.sv`, `hpc_spm_bank_arb.sv` (header), `sfmem_banked.sv` (header), `sfb_sram_slave.sv` (header), `sram-decoder.sf`, `memory_controller.sf` (header) | read |
| Docs read: P71 `00_repository_audit.md`, `01_interface_and_semantics.md`; library `03_banking.md` | read |
| Tensor operand/output buffers and the vector-memory side: located (they instantiate the library's `sram_sp`; `tb_tob_bank_arb.sv` tests operand-buffer bank arbitration) | **located, not read in depth** |
| Other reports in other archives (regression counts, synthesis tables) | **not re-run**; nothing here relies on their numbers |

## 2. What exists

| Area | Where | Finding |
|---|---|---|
| **`sf_sram_core`** | `silicaflux-sramcore-p71.zip` → `rtl/sram/` | The verified single-port core this block is built from: synchronous, byte-lane writes, fixed `READ_LATENCY`, `rd_valid`/`rd_err`/`wr_ack`/`wr_err`, bounds policy (invalid ⇒ flagged, never aliased), storage never reset. **No `rtl/sram/` directory exists at the repository tree level**; the file lives only inside that archive |
| **Common SRAM "package"** | `sf_sram_defs.svh` (P71), `sram_defs.svh` (library) | `` `define `` headers, not SV packages (Yosys 0.33 cannot resolve package references in parameter lists). Reused: `SF_SRAM_INIT_*`, `SF_SRAM_CFG_FATAL` |
| **Banking, multi-master** | `silicaflux-sramlib.zip` → `sram_bank_controller.sv`, `docs/mem/03_banking.md` | `NUM_MASTERS × NUM_BANKS` single-port banks, per-bank round-robin or fixed arbitration, `LOW`/`HIGH` interleave, word/byte addressing, response credits, ID tags, MBIST. **This is the multi-master arbiter** — the later SRAMController territory |
| **Banked memory subsystem** | `silicaflux-memorycore1.zip` → `sfmem_banked.sv` | wraps `sram_bank_controller` unmodified (6 ports × 8 banks shared SRAM) |
| **Vector scratchpad** | `silicaflux-hpc-m04-scratchpad.zip` → `hpc_spm_addr_map.sv`, `hpc_spm_bank_arb.sv`, `hpc_spm_perf.sv` | byte address → (bank, row, byte offset, error) with `LOW`/`XOR`/`HIGH` maps, range-window check, error priority RANGE > ALIGN > STROBE; saturating event counters incl. conflicts |
| **DataFabric** | `silicaflux-datafabric.zip` → `rtl/mem/sfb_sram_slave.sv` | SFB2 slave on `sram_sp`: byte address `req_addr[OFF +: AW]` (upper bits "decoded by the crossbar"), one response per request, out-of-range ⇒ `rsp_error` |
| **Unified scratchpad controller (2.x)** | `memory_controller.sf` | documents the same low-order line interleave: `paddr = aperture tag \| row \| bank \| lane \| byte`; "each requester targets exactly one bank, so up to `NUM_REQ` accesses issue per cycle when bank-disjoint" |
| **Earlier decoder** | `sram-decoder.sf` | a 16-line module **named `sf_sram_bank_decode`**: `bank = addr[OFFSET_W +: BANK_W]`, power-of-two banks only |
| **Buffers** | `silicaflux-buffercore-p55.zip` → `sfsb_sram_bank.sv` | `sram_sp` as 8 lanes × 9 bits (`{parity, byte}`) — why `BYTE_WIDTH` is a free parameter here |
| **Large banked arrays** | `silicaflux-sramgrid-p33.zip` | macro abstracts, placement, ECC width cost (not used) |

## 3. Conventions adopted

* **Word-granular banks**, little-endian lanes, `wmask` bit *l* = lane *l*; flat packed-vector ports (no interfaces or
  unpacked arrays on ports), `Classification: SYNTHESIZABLE` header comments, `g_err_*` generate blocks for illegal parameters.
* **Low-order interleave is the repository default** (`SRAM_ILV_LOW`, `HPC_SPM_MAP_LOW`, `sram-decoder.sf`,
  `memory_controller.sf`): the `SEQ` mode here is exactly that. `BLOCK` ≙ `SRAM_ILV_HIGH` when `BLOCK_WORDS = BANK_DEPTH`;
  `XOR` follows `HPC_SPM_MAP_XOR`.
* **Out-of-range ⇒ error, never alias**; error priority RANGE before ALIGN (as `hpc_spm_addr_map`).
* Array and data never reset; control/valid state reset by `rst_n` (asynchronous assert, synchronous release).
* Test infrastructure: deterministic xorshift PRNG and the `SRAM_RESULT <PASS|FAIL> tb=… seed=… checks=… errors=…` line
  from `tb_common.svh` (vendored unmodified); Verilator + Icarus runners; provenance-carrying JSON reports; mutation sanity.

## 4. Reuse decisions

| Item | Decision | Why |
|---|---|---|
| `sf_sram_core`, `sf_sram_array`, `sf_sram_defs.svh`, `tb_common.svh` | **vendored unmodified** (`third_party/silicaflux-sramcore/`, SHA-256 verified) | the verified single-port macro model: one instance per bank. Not copied into new RTL, not edited |
| `sram_bank_controller` | **not a dependency, not duplicated** | it is multi-master arbitration with credits/FIFOs/MBIST — the later SRAMController. This block is the layer below: decode, per-bank ports, a minimal deterministic interlock, status and counters |
| `hpc_spm_addr_map`, `hpc_spm_perf` | **conventions followed, code not copied** | same map names and error-priority; this decoder adds `BLOCK_WORDS` (configurable block size), non-power-of-two `NUM_BANKS` and a hardware inverse |
| `sram-decoder.sf` | **not reused; name collision avoided** | its module is called `sf_sram_bank_decode`; the decoder here is therefore named **`sf_sram_bank_addr_decode`** so both can be compiled together. Its mapping equals `SEQ` for power-of-two banks (`bank = address bits above the line offset`) |

## 5. Not present, not assumed, not built here

Multi-master arbitration, response credits/FIFOs, QoS, ECC / parity generation, MBIST, a dual-port or multi-port bank, a
runtime-switchable interleave, ASIC macro mapping. `sf_sram_core` has no dual-port option and this block does not create one.
