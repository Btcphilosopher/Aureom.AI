# 01 — Architecture and interface (normative)

## 1. What this block is — and what it is not

`sf_sram_bank` is a **distributed multibank SRAM**: `NUM_BANKS` independent single-port banks, each exactly one verified
`sf_sram_core` (Project 71), with `NUM_PORTS` byte-addressed request lanes in front.

**Banking adds concurrency between banks, never ports to a bank.**

* Every bank is a **single-port** memory. It serves **at most one access per clock cycle** — one read *or* one write.
  Nothing in this package changes that, and nothing in it claims otherwise.
* What banking raises is the number of accesses the *subsystem* can serve in one cycle: up to `NUM_BANKS`, **when the
  accesses fall on different banks** and something upstream supplies them in the same cycle.
* Two requests for the **same bank in the same cycle** can never both be served in that cycle. This block denies the
  second one (it stalls) and counts the event. There is **no** conflict-free access to one physical port.
* Banking therefore helps access patterns whose concurrent requests land on different banks (unit-stride streams under
  `SEQ`, region-per-master traffic under `BLOCK`, …) and does **not** help a pattern that hammers one bank. The measured
  numbers are in `reports/concurrency.md` (docs/04 §6).

```
                         sf_sram_bank
  lane 0 ──► sf_sram_bank_addr_decode ──┐                                   ┌──► bank 0  (sf_sram_core, 1 port)
  lane 1 ──► sf_sram_bank_addr_decode ──┤   same-bank interlock             ├──► bank 1
   ...                             ├─► (lowest lane index wins,  ──────┤     ...          sf_sram_bank_array
  lane N ──► sf_sram_bank_addr_decode ──┘    others denied, counted)        └──► bank B-1
                                                                              │ responses, READ_LATENCY cycles later
  rsp lane 0 ◄──┐                                                             │ (lane index travels in the ID)
  rsp lane 1 ◄──┼── response routing ◄────────────────────────────────────────┘
   ...          │   + rejected-request responses (RANGE / ALIGN) from the decode stage
  per-bank status (st_*) and bank-level counters (perf_*, sf_sram_bank_perf) observe everything
```

Division of labour with the SRAMController that comes later: **this block contains no fairness, no credits, no response
FIFOs and no QoS.** Its same-bank interlock is the minimum that keeps a single port safe and the behaviour
deterministic (lowest lane index wins). A multi-master controller arbitrates *in front of* it and then presents at most
one request per bank per cycle; the conflict counters then stay at zero and double as a check that it does (§8).

## 2. Files

| File | Module | Role |
|---|---|---|
| `rtl/bank/sf_sram_bank.sv` | `sf_sram_bank` | **primary**: lanes → decode → interlock → banks → response routing, status, counters |
| `rtl/bank/sf_sram_bank_array.sv` | `sf_sram_bank_array` | the **per-bank interface**: `NUM_BANKS` single-port banks, each with its own enable / address / op / mask / data / ID |
| `rtl/bank/sf_sram_bank_addr_decode.sv` | `sf_sram_bank_addr_decode` | **bank address decoder**: byte address → (bank, local word, byte offset, error) |
| `rtl/bank/sf_sram_bank_addr_unmap.sv` | `sf_sram_bank_addr_unmap` | exact inverse of the decoder (used to prove invertibility; handy for error reporting) |
| `rtl/bank/sf_sram_bank_perf.sv` | `sf_sram_bank_perf` | bank-level **performance counters** |
| `rtl/bank/sf_sram_bank_defs.svh` | — | **interleaving configuration** constants (`MAP_MODE`, error codes); includes the common `sf_sram_defs.svh` |
| `third_party/silicaflux-sramcore/rtl/sram/` | `sf_sram_core`, `sf_sram_array`, `sf_sram_defs.svh` | the verified Project 71 SRAM, vendored **unmodified** (SHA-256 checked against its manifest) |

"Common SilicaFlux SRAM package": in this repository that is `sf_sram_defs.svh`, a `` `define `` header rather than a
SystemVerilog package, because Yosys 0.33 cannot resolve package references in module parameter lists
(documented in the header itself). `sf_sram_bank_defs.svh` extends it without modifying it (`SF_SRAM_BANK_` prefix).

## 3. `sf_sram_bank` parameters

Illegal values fail elaboration with a message (`g_err_*` generate blocks); see the `neg` suite in `reports/regression_*.md`.

| Parameter | Default | Meaning / rule |
|---|---|---|
| `NUM_BANKS` | 4 | 2 … 64. Power of two ⇒ bit-slice decode (docs/02 §5). Non-powers of two work for `SEQ`/`BLOCK` and cost real logic |
| `NUM_PORTS` | `NUM_BANKS` | request lanes, 1 … 32 |
| `DATA_WIDTH` | 32 | bits per word, multiple of `BYTE_WIDTH` |
| `BYTE_WIDTH` | 8 | lane width; 9 supports `{parity, byte}` lanes. "Byte" below means one lane |
| `BANK_DEPTH` | 1024 | words per bank, ≥ 2, any value (not only powers of two) |
| `ADDR_WIDTH` | `clog2(NUM_BANKS·BANK_DEPTH·LANES)` | byte-address width of a lane, ≥ the default, ≤ 32. Wider ⇒ addresses above the capacity are *rejected*, never aliased |
| `MAP_MODE` | `SF_SRAM_BANK_MAP_SEQ` | `SEQ` / `BLOCK` / `XOR` (docs/02) |
| `BLOCK_WORDS` | 1 | run length for `BLOCK` / `XOR`: power of two dividing `BANK_DEPTH` |
| `STRICT_ALIGN` | 0 | 1: a byte address that is not word-aligned is rejected (`ALIGN`); 0: the byte offset is ignored (floor division) |
| `READ_LATENCY` | 1 | ≥ 1, cycles from request to response (passed to every bank) |
| `WRITE_ACK` | 1 | 1: every accepted write is acknowledged; 0: posted (errors are still reported) |
| `ID_WIDTH` | 4 | ≥ 1, transaction ID width |
| `INIT_MODE`, `INIT_FILE` | `NONE`, `""` | passed to **every** bank unchanged (`sf_sram_defs.svh`; only `NONE` matches an ASIC macro). With `FILE`, every bank loads the *same* image — a global image is not split across banks; initialise through the lanes instead if that matters |
| `OOB_ASSERT` | 1 | simulation assertion inside each bank for invalid *local* addresses (the decoder never produces one) |
| `PERF_EN` | 1 | 0 removes every counter |
| `CNT_W` | 32 | counter width, 2 … 64; counters **saturate**, they never wrap |

`LANES = DATA_WIDTH / BYTE_WIDTH` must be a power of two (it is the byte-address granularity: `BYTES_PER_WORD`).

## 4. `sf_sram_bank` ports

Lane `p` owns slice `p` of every lane bus; bank `b` owns bit/slice `b` of every status bus. All buses are flat vectors.

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `clk`, `rst_n` | in | 1 | rising-edge clock; `rst_n` active low, asynchronous assert, **synchronous release** |
| `req_valid` | in | `NUM_PORTS` | lane has a request |
| `req_ready` | out | `NUM_PORTS` | **combinational**: 1 = not denied this cycle. Accepted ⇔ `req_valid & req_ready`. Idle lanes read 1; 0 during reset |
| `req_we` | in | `NUM_PORTS` | 1 write, 0 read |
| `req_addr` | in | `NUM_PORTS·ADDR_WIDTH` | **byte** address |
| `req_wmask` | in | `NUM_PORTS·LANES` | byte enables (little-endian); sub-word writes live here, not in the address |
| `req_wdata` | in | `NUM_PORTS·DATA_WIDTH` | write data |
| `req_id` | in | `NUM_PORTS·ID_WIDTH` | transaction identity, returned in `rsp_id` |
| `rsp_valid` | out | `NUM_PORTS` | a response for this lane this cycle |
| `rsp_rdata` | out | `NUM_PORTS·DATA_WIDTH` | read data; **zero whenever it is not a read response without error** |
| `rsp_we` | out | `NUM_PORTS` | the response answers a write |
| `rsp_err` | out | `NUM_PORTS` | the request was rejected / failed (`rsp_rdata` = 0) |
| `rsp_ecode` | out | `NUM_PORTS·2` | `0` none, `1` RANGE, `2` ALIGN, `3` BANK |
| `rsp_id` | out | `NUM_PORTS·ID_WIDTH` | the request's ID |
| `st_ready` | out | `NUM_BANKS` | bank out of reset |
| `st_busy` | out | `NUM_BANKS` | bank has an operation in progress: issued this cycle or still in the `READ_LATENCY` pipeline (the response cycle included) |
| `st_access` | out | `NUM_BANKS` | bank accessed this cycle |
| `st_conflict` | out | `NUM_BANKS` | two or more lanes requested the bank this cycle |
| `perf_clear` | in | 1 | synchronous clear of every counter |
| `perf_*` | out | see docs/03 | counters |

**Request protocol.** A requester holds `req_valid` and every request field stable until `req_ready` is 1. A *denied*
request (`req_ready=0`) is **not accepted** and has no effect on any memory, response or counter other than the
conflict/stall counters; withdrawing it is legal.

## 5. Timing and responses

A "cycle *t*" is the cycle in which a request is presented; it is sampled at the clock edge that ends it. An accepted
request yields **at most one response, exactly `READ_LATENCY` cycles later, on the same lane**.

| Request (accepted in cycle *t*) | Response in cycle *t* + `READ_LATENCY` |
|---|---|
| read | `rsp_valid`, `rsp_rdata`, `rsp_we=0`, `rsp_err=0` |
| write, `WRITE_ACK=1` | `rsp_valid`, `rsp_we=1`, `rsp_err=0` |
| write, `WRITE_ACK=0` (posted) | none |
| rejected (RANGE / ALIGN), any kind | `rsp_valid`, `rsp_err=1`, `rsp_ecode`, `rsp_we` = the request's kind — **always**, also for posted writes ("errors are never silent") |

* Writes are acknowledged at the **read latency** (not `sf_sram_core`'s one cycle) so that a lane's responses are in
  request order by construction and a lane never receives two responses in one cycle. A simulation assertion checks this.
* A write is performed at the edge that ends its accept cycle; any request accepted in a later cycle observes it
  (read-after-write in the next cycle returns the new data). A read accepted before a write to the same word returns the
  old data (write-after-read).
* Different banks proceed independently: in a cycle where lanes hit *k* different banks, *k* accesses are served.
* There is **no response back-pressure**: the consumer must accept a response in the cycle it is presented (the
  SRAMController is expected to bring its own credits/FIFOs, as the library's `sram_bank_controller` does).

## 6. Reset

`rst_n` low: no lane is ready, nothing is accepted, in-flight responses are dropped, every counter and pipeline is
cleared. **The storage is never reset** (the `sf_sram_core` contract): the contents survive a reset, and never-written
words are *not* assumed to be zero anywhere in the verification. Release it synchronously (from a reset synchroniser).

## 7. Errors

| Code | Cause | Effect |
|---|---|---|
| `RANGE` (1) | byte address ≥ `NUM_BANKS·BANK_DEPTH·BYTES_PER_WORD` | rejected at the decoder; **never reaches a bank, never aliases**; counted in `perf_err_range` |
| `ALIGN` (2) | `STRICT_ALIGN=1` and the byte address is not word-aligned (`RANGE` has priority) | rejected at the decoder; counted in `perf_err_align` |
| `BANK` (3) | the bank itself flagged an invalid local word (only possible via `sf_sram_bank_array` with a non-power-of-two `BANK_DEPTH`; the decoder never produces one) | `b_rsp_err` / `perf_err[b]`; an assertion in `sf_sram_bank` fires if it ever happens there |

## 8. Using the per-bank interface directly (`sf_sram_bank_array`)

A controller that decodes and arbitrates itself skips the lanes and the interlock and drives the banks directly:
**one request port per bank**, all independent in the same cycle.

| Port (bank *b* = slice *b*) | Dir | Meaning |
|---|---|---|
| `b_req` | in | bank enable: one access to bank *b* this cycle |
| `b_we`, `b_addr`, `b_wmask`, `b_wdata`, `b_id` | in | write enable, **bank-local word** address (`clog2(BANK_DEPTH)` bits), byte enables, data, ID |
| `b_ready` | out | out of reset (the bank has no wait states: it accepts every access in the cycle it is presented) |
| `b_rsp_valid`, `b_rsp_rdata`, `b_rsp_we`, `b_rsp_err`, `b_rsp_id` | out | response, same rules as §5 |
| `b_busy`, `ev_access`, `ev_ok`, `ev_err` | out | status and one-cycle event pulses for `sf_sram_bank_perf` |

A second request for a bank **cannot be expressed** on its port, so there is nothing to arbitrate here. The controller
uses `sf_sram_bank_addr_decode` (same parameters) to learn each master's bank, arbitrates per bank, and drives `b_*`. It should
instantiate `sf_sram_bank_perf` itself with its own conflict events. `tb_sf_sram_bank_array` verifies this interface on
its own.

## 9. Simulator note (testbench-side)

With Verilator 5.020 `--timing`, a testbench process that changes a DUT input *vector* by **part-select assignment**
(`req_addr[p*AW +: AW] = …`) can leave part of the downstream combinational logic stale; the same RTL was correct in
Icarus and with whole-vector driving. The delivered testbenches therefore build whole vectors and assign them once.
Anyone driving `sf_sram_bank` from a Verilator `--timing` testbench should do the same. The RTL itself is plain
synthesizable SystemVerilog; this was observed, not root-caused inside Verilator.
