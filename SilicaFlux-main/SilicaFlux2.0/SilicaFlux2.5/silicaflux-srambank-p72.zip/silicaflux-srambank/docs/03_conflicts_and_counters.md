# 03 — Bank conflicts, counters, and the SRAMController contract

## 1. The conflict rule

Per cycle and per bank, `sf_sram_bank` collects the lanes that request it (a lane requests a bank when `req_valid`, the
address decodes without error, and the block is out of reset). Then:

| Lanes requesting bank *b* | Outcome |
|---|---|
| 0 | bank idle |
| 1 | that lane is granted |
| *n* ≥ 2 | the **lowest-index lane is granted**, the other *n−1* lanes get `req_ready=0` (stalled, **not accepted**) |

* Deterministic: the same request pattern always gives the same grants. Lane index is the only priority.
* Lanes on **different banks do not interfere**: a collision on bank 0 never stalls a lane that targets bank 1 (tested).
* A rejected request (`RANGE`/`ALIGN`) needs no bank, so it never competes and is accepted at once.
* A denied requester keeps `req_valid` and its fields; it is retried every cycle and **loses again** while a lower-index
  lane keeps requesting the same bank. **This is not fair.** A persistently higher-priority lane can starve the others;
  fairness belongs to the SRAMController (below). The testbench shows the starvation-free case only because its lanes
  finish their queues.
* Not duplicated here, on purpose: round-robin / rotating priority, response credits and FIFOs, QoS, multi-master
  bookkeeping. The library's `sram_bank_controller` already provides full multi-master arbitration (its `ARB=FIXED`
  policy is the same lowest-index-wins rule); this block must not grow a second arbiter.

## 2. Counters (`sf_sram_bank_perf`)

Saturating (they stop at all-ones), `CNT_W` bits, reset by `rst_n` (asynchronous assert) and by `perf_clear`
(synchronous). All of them are updated by the same clock edge from one-cycle event pulses, so they describe exactly the
same set of cycles. "Cycle" = a clock edge with `rst_n=1` since the last reset/clear.

| Counter | Per | Definition |
|---|---|---|
| `perf_cycles` | — | cycles observed |
| `perf_access[b]` | bank | **bank accesses**: accesses issued to bank *b* — its single port was used this cycle |
| `perf_ok[b]` | bank | **successful operations**: accesses that *completed* without error, counted in the cycle the response is due (`READ_LATENCY` after issue; a posted write is counted although it has no response) |
| `perf_err[b]` | bank | accesses that completed with a bank error (0 for decoded addresses) |
| `perf_conflict[b]` | bank | **conflict events**: cycles in which ≥ 2 lanes requested bank *b* — one event per (bank, cycle) however many collide |
| `perf_stall[b]` | bank | lane-cycles lost to bank *b*: a collision of *n* lanes denies *n−1*; a requester that retries is counted again every cycle it loses |
| `perf_busy[b]` | bank | **busy cycles**: an operation in progress — issued this cycle or still in the `READ_LATENCY` pipeline (the response cycle included) |
| `perf_idle[b]` | bank | **bank idle cycles**: no operation in progress |
| `perf_err_range`, `perf_err_align` | global | accepted lane requests rejected by the decoder (never reach a bank) |
| `perf_hist[k]`, k = 0…`NUM_BANKS` | global | cycles in which exactly *k* banks were accessed — the **concurrency measurement** |

Invariants (checked by the testbench against the DUT outputs, until a counter saturates):

```
perf_busy[b] + perf_idle[b] == perf_cycles                    for every bank
sum_k perf_hist[k]          == perf_cycles
sum_k k * perf_hist[k]      == sum_b perf_access[b]
perf_ok[b] == perf_access[b]      once the pipeline has drained and no bank errors exist
```

`perf_hist[k ≥ 2] > 0` proves that independent banks served accesses **in the same cycle**; `perf_hist[NUM_BANKS]` counts the
cycles in which every bank was busy at once. Average accesses per cycle = `sum_b perf_access[b] / perf_cycles`. A single
bank can never exceed 1.0; there is no way to read 2 from one port.

The testbench compares **every counter against an independent event model in every cycle** (not just at the end), and
checks saturation with a 5-bit counter configuration.

## 3. What the SRAMController must do (contract for the later block)

1. **Decode** each master request with `sf_sram_bank_addr_decode` (same `NUM_BANKS`, `BANK_DEPTH`, `BYTES_PER_WORD`,
   `MAP_MODE`, `BLOCK_WORDS`, `ADDR_WIDTH`) — or let `sf_sram_bank` do it and read `rsp_ecode`.
2. **Arbitrate per bank**, with whatever fairness policy the system needs, so that **at most one request per bank per cycle**
   reaches this block. Then `req_ready` is 1 for every lane, the conflict and stall counters stay at 0, and
   `perf_hist` shows the achieved concurrency. A non-zero `perf_conflict` in a system with a conforming controller is a
   controller bug, and the counter finds it.
3. **Accept responses when they arrive.** There is no back-pressure on `rsp_*` and no response storage here; use credits
   or per-master FIFOs (as `sram_bank_controller` does) if a master can stall.
4. **Use `req_id`** to tie responses back to masters; responses return on the lane that issued the request, in order, at
   the fixed latency.
5. Alternatively drive `sf_sram_bank_array` directly (docs/01 §8): the single-port rule is then enforced by the interface.
6. **No coherence, no ordering across banks**: two requests to different banks in one cycle are independent; software
   that needs ordering must wait for the response.

## 4. Honest limits

* The interlock is a fixed-priority safety net, not an arbiter (§1).
* Conflict counters count *cycles and lane-cycles*, not distinct requests; a denied request that retries 5 times adds
  5 to `perf_stall`.
* `perf_ok` lags `perf_access` by `READ_LATENCY` cycles; compare them only after the pipeline drains.
* The counters are read as raw outputs (no register file, no snapshot): reading them while traffic runs gives a
  consistent set (same edge) but not an atomic "read-and-clear".
