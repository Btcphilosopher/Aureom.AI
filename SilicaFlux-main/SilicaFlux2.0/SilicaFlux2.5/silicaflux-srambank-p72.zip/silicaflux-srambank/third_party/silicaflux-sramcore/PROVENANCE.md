# Provenance — vendored SilicaFlux SRAMCore subset (Project 71)

Source archive: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramcore-p71.zip` (repository `Btcphilosopher/Aureom.AI`),
member `silicaflux-sramcore/`. The files below are copied **unmodified**; their SHA-256 values equal the entries of that
archive's own `SHA256SUMS` (compared when this package was built, and the P71 primary regression was re-run first:
4 pass / 0 fail with Verilator 5.020 and Icarus 12.0).

| file | SHA-256 | used by |
|---|---|---|
| `rtl/sram/sf_sram_core.sv` | `6516d1b5ee90ddc38f16e847746188cf1dce158cb7276f11232fa51a9a251068` | one instance per bank (`sf_sram_bank_array`) |
| `rtl/sram/sf_sram_array.sv` | `2f19335dc35b7a353d0b91a20cbea4cc244cf506dbb071c54a1e8bea8c831751` | the inferred storage inside `sf_sram_core` |
| `rtl/sram/sf_sram_defs.svh` | `ad933db0a02c0af1d218faea690641d4d031958b693f5acf370ee1ad21406776` | the common SilicaFlux SRAM header (`INIT_MODE`, `SF_SRAM_CFG_FATAL`); included by `sf_sram_bank_defs.svh` |
| `tb/mem/tb_common.svh` | `01546c6c2100b87ecbeaddaa43964213c80f496b16de5535782f54c841876364` | PRNG, `tb_check`, the `SRAM_RESULT` line (every testbench). Originates from the SRAM Wrapper Library (Project 01) and is vendored by P71 under `third_party/silicaflux-sramlib/tb/mem/` |

Nothing under `rtl/bank/` modifies these files. The package's own checksum manifest (`SHA256SUMS`) covers them too.
The P71 documentation (`docs/01_interface_and_semantics.md`) is the normative description of the core; this package's
`docs/01_architecture_and_interface.md` describes only what is added on top.
