# SilicaFlux SRAMBank (`silicaflux-srambank`) — distributed multibank SRAM

**Primary RTL:** `rtl/bank/sf_sram_bank.sv` · Project 72 · Aureom.AI | SilicaFlux Semiconductor Systems

A configurable banked SRAM subsystem built from verified `sf_sram_core` (Project 71) instances: **2, 4, 8 and 16 banks**
(any `NUM_BANKS` from 2 to 64), deterministic address interleaving (sequential, block, XOR-skewed), independent per-bank
enables/addresses/ops, byte-enable writes, per-bank status, a same-bank conflict interlock with deterministic conflict
reporting, and bank-level performance counters that make the achieved concurrency measurable.

> **Banking adds concurrency *between* banks. It does not add ports to a bank.** Every bank is a single-port SRAM and
> serves at most **one** access per cycle. The subsystem can serve up to `NUM_BANKS` accesses per cycle *only when
> concurrent requests fall on different banks*; two requests for the same bank in one cycle can never both be served.
> There is no conflict-free access to a single physical port anywhere in this package.

> **Not committed to GitHub** — delivered as a plain archive, like the other SilicaFlux modules. Evidence is
> **simulation (Verilator 5.020, Icarus 12.0) and Yosys 0.33 only**: no vendor FPGA tool, no board, no silicon, and **no
> frequency, ASIC area, power or access-time figure** anywhere in this package.

## Quick start (the order of the brief)

```
make bank-2        # TWO banks first: lint, illegal params, decoder proof, per-bank interface, sf_sram_bank @ 2 banks
make bank-4        # then FOUR banks
make bank-gate     # VALIDATE BANK CONFLICTS (mutation gate at 2 AND 4 banks) - required before 8/16
make bank-8-16     # only then 8 and 16 banks   (refuses to run without a gate result for the current RTL)
make bank-extra    # non-power-of-two bank counts
make bank-mutants  # full mutation sanity
make bank-perf     # measured concurrency -> reports/concurrency.md
make bank-synth    # Yosys: memories per bank, FPGA RAM mapping, depth sweep, decoder cost
make bank-all      # everything, in that order, then the summary
make package       # silicaflux-srambank-p72.zip (outside git)
```
Requirements: Verilator ≥ 5.020, Icarus Verilog 12, Yosys 0.33, Python ≥ 3.10 (standard library only). Start reading at
`reports/SUMMARY.md`, then `docs/01_architecture_and_interface.md`.

## The block in one screen

```systemverilog
sf_sram_bank #(.NUM_BANKS(4), .NUM_PORTS(4), .DATA_WIDTH(32), .BANK_DEPTH(1024)) u_banks (   // 16 KiB, SEQ interleave
  .clk, .rst_n,
  .req_valid, .req_ready, .req_we, .req_addr /*byte*/, .req_wmask, .req_wdata, .req_id,
  .rsp_valid, .rsp_rdata, .rsp_we, .rsp_err, .rsp_ecode, .rsp_id,
  .st_ready, .st_busy, .st_access, .st_conflict, .perf_clear, .perf_* );
```

| | |
|---|---|
| Banks | `NUM_BANKS` independent single-port `sf_sram_core` instances, one inferred memory each |
| Mapping | `bank = word % NUM_BANKS`, `local = word / NUM_BANKS` (`SEQ`); optional `BLOCK` (runs of `BLOCK_WORDS`) and `XOR` skew; power-of-two ⇒ bit slices; all proven bijective, invertible and non-aliasing |
| Range | `[0, NUM_BANKS·BANK_DEPTH·BYTES_PER_WORD)`; everything above is rejected (`RANGE`), never aliased |
| Parallelism | lanes on **different banks** are served in the same cycle (measured: `perf_hist`, `reports/concurrency.md`) |
| Conflicts | same-bank requests: lowest lane index wins, others stall (`req_ready=0`) and are counted. Deterministic, **not fair** — fairness is the SRAMController's job |
| Responses | exactly `READ_LATENCY` cycles after acceptance, same lane, in order, with the request ID; errors are never silent |
| Per bank | `st_ready / st_busy / st_access / st_conflict` + counters: accesses, successful ops, conflict events, stalls, busy, idle, concurrency histogram |
| Per-bank interface | `sf_sram_bank_array`: one independent request port per bank (bank enable, bank-local address, write enable, byte mask, data, ID) |
| Reset | async assert / sync release; drops in-flight work, clears counters; **storage never reset** |

## Deliverables → location

| Brief item | Where |
|---|---|
| `sf_sram_bank.sv` | `rtl/bank/sf_sram_bank.sv` (+ `sf_sram_bank_array.sv`) over the vendored `sf_sram_core` |
| Bank address decoder | `rtl/bank/sf_sram_bank_addr_decode.sv` (+ exact inverse `sf_sram_bank_addr_unmap.sv`); executable spec `model/sf_bank_map.py` |
| Bank interleaving configuration | `rtl/bank/sf_sram_bank_defs.svh` (`MAP_MODE`, error codes), presets `examples/sf_sram_bank_presets.svh` for 2/4/8/16 banks |
| Bank-level performance counters | `rtl/bank/sf_sram_bank_perf.sv`; definitions in `docs/03_conflicts_and_counters.md` |
| Testbench | `tb/bank/tb_sf_sram_bank.sv` (system), `tb_sf_sram_bank_array.sv` (per-bank interface), `tb_sf_sram_bank_addr_decode.sv` (exhaustive mapping proof) |
| Synthesis scripts | `scripts/run_synth.py` (Yosys matrix), `synth/run_yosys.sh`, `synth/vivado/synth_srambank.tcl` (**not run**, no Vivado here) |
| Documentation | `docs/00 … 06`, `reports/` |
| Repository audit | `docs/00_repository_audit.md` |

## Layout

```
rtl/bank/       sf_sram_bank.sv  sf_sram_bank_array.sv  sf_sram_bank_addr_decode.sv  sf_sram_bank_addr_unmap.sv
                sf_sram_bank_perf.sv  sf_sram_bank_defs.svh  files.f
tb/bank/        tb_sf_sram_bank.sv  tb_sf_sram_bank_array.sv  tb_sf_sram_bank_addr_decode.sv
model/          sf_bank_map.py      executable reference of the address mapping (+ RTL-dump comparison)
scripts/        common.py run_regress.py run_mutants.py run_synth.py make_summary.py gen_examples.py package.sh
synth/          run_yosys.sh  vivado/synth_srambank.tcl (not run)
examples/       presets for 2/4/8/16 banks + generated, linted wrappers
third_party/    silicaflux-sramcore/   sf_sram_core / sf_sram_array / sf_sram_defs.svh / tb_common.svh, UNMODIFIED, SHA-256 verified
docs/           00 audit · 01 architecture & interface · 02 address mapping · 03 conflicts & counters · 04 verification · 05 FPGA/ASIC · 06 status
reports/        SUMMARY.md regression_*.{md,json} mutants*.{md,json} gate.json synth.{md,json} concurrency.md
SHA256SUMS      every delivered file
```

## Results (generated from the JSON reports of the final run)

<!--RESULTS-->
| Check | Result | Notes |
|---|---|---|
| Lint: Verilator `-Wall` (zero warnings) + Icarus `-Wall` elaboration | 48 pass / 0 fail | sf_sram_bank over 12 configurations x {with, without `SYNTHESIS`}, every sub-module, decoder matrix |
| Illegal parameterisations rejected | 69 pass / 0 fail | 23 cases x Verilator, Icarus, Yosys; explicit message reached in 40/69 (a tool may abort on its own width error first) |
| Address mapping proof (exhaustive): correct / injective / surjective / invertible / bounded | 50 pass / 0 fail | 1,048,817 checks; 50 RTL dumps identical to the Python model; SEQ, BLOCK, XOR; 2-16 banks and 3,5,6,7,12 |
| Per-bank interface (independent enables / addresses), `sf_sram_bank_array` | 19 pass / 0 fail | 6,899,481 checks, 1-16 banks, latency 1-3, posted writes, non-power-of-two depth |
| `sf_sram_bank` self-checking simulation, **TWO banks** | 23 pass / 0 fail | 8,465,573 scoreboard checks; Verilator vs Icarus: 6/6 identical check counts (same stimulus); bank counts exercised: 2 (PASS) |
| `sf_sram_bank` self-checking simulation, **FOUR banks** | 29 pass / 0 fail | 23,754,176 scoreboard checks; Verilator vs Icarus: 9/9 identical check counts (same stimulus); bank counts exercised: 4 (PASS) |
| `sf_sram_bank` self-checking simulation, EIGHT and SIXTEEN banks | 21 pass / 0 fail | 100,665,287 scoreboard checks; Verilator vs Icarus: 5/5 identical check counts (same stimulus); bank counts exercised: 8, 16 (PASS) |
| `sf_sram_bank` self-checking simulation, non-power-of-two bank counts | 5 pass / 0 fail | 3,542,632 scoreboard checks; Verilator vs Icarus: 1/1 identical check counts (same stimulus); bank counts exercised: 3, 5, 6, 12 (PASS) |
| **Bank-conflict gate** (before 8/16 banks): interlock + conflict-counter mutants killed on 2 AND 4 banks | PASS | 14 mutants |
| Mutation sanity: injected RTL bugs | 53 killed / 0 survived / 0 invalid | of 53; `reports/mutants.md` |
| Yosys: one memory inferred per bank, zero latches | PASS | 72 synthesis rows (generic, xc7, ice40, ecp5, depth sweep, decoder cost); `reports/synth.md` |

Tools: verilator `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`; iverilog `Icarus Verilog version 12.0 (stable) ()`; yosys `Yosys 0.33 (git sha1 2584903a060)`; python `3.13.18`.  Not installed: vivado, quartus, openroad.  RTL sha256 `7a24d142887dc87d…`.
<!--/RESULTS-->

## Measured concurrency (simulation of this RTL, generated)

<!--CONCSUM-->
| config (banks x lanes) | unit | stride | region | random | hot | samebank |
|---|---|---|---|---|---|---|
| `b2_seq` (2x2) | 2.00 | 1.00 | 2.00 | 1.29 | 1.20 | 1.00 |
| `b4_seq` (4x4) | 4.00 | 1.00 | 3.97 | 2.18 | 1.46 | 1.00 |
| `b4_contig` (4x4) | 2.70 | 3.57 | 4.00 | 2.17 | 1.45 | 1.00 |
| `b4_xor` (4x4) | 4.00 | 4.00 | 2.39 | 2.17 | 1.47 | 1.00 |
| `b8_seq` (8x8) | 8.00 | 1.00 | 7.86 | 3.97 | 1.69 | 1.00 |
| `b8_xor` (8x8) | 8.00 | 8.00 | 4.44 | 3.95 | 1.69 | 1.00 |
| `b16_seq` (16x16) | 16.00 | 1.00 | 15.42 | 7.73 | 1.82 | 1.00 |
| `b16_xor` (16x16) | 16.00 | 16.00 | 8.76 | 7.69 | 1.82 | 1.00 |
| `b16_block4` (16x16) | 15.88 | 4.00 | 13.91 | 7.72 | 1.82 | 1.00 |

Lane requests served per active clock cycle (400 per lane). One single-port bank can never exceed 1.00; the maximum here is the number of lanes. `samebank` (every lane on one bank) is the serialised worst case. Detail: `reports/concurrency.md`.
<!--/CONCSUM-->

## Honest limits

* **Evidence is simulation + Yosys.** Block-RAM inference was checked with Yosys only; Vivado / Quartus behaviour is
  **unverified** (`synth/vivado/synth_srambank.tcl` is the way to check; it was not run). Shallow banks do not map to block
  RAM at all (depth sweep in `reports/synth.md`): an inferred bank is never assumed to be a dedicated BRAM.
* The conflict interlock is **fixed priority, not fair**; multi-master arbitration, response credits/FIFOs and QoS belong to
  the later SRAMController and are deliberately not duplicated here. There is no response back-pressure.
* No formal proofs, no timing, no gate-level simulation, no ASIC macro mapping (`sf_sram_core` is a behavioural macro
  model; a real compiler macro with its own port rules replaces it per docs/05), no ECC, no MBIST.
* `XOR` skew is not a universal stride fix (docs/02 §6). A runtime-switchable interleave is not implemented.
* Verilator 5.020 `--timing` quirk when a testbench drives a DUT vector by part-select: the testbenches drive whole vectors
  (docs/01 §9, docs/04 §5). Observed, not root-caused inside Verilator.
