#!/usr/bin/env python3
"""Yosys synthesis / FPGA memory-inference checks for SRAMBank.   Output: reports/synth.md / synth.json

generic   technology-independent `synth -run :fine` (hierarchy flattened, stopped before memory mapping): elaboration
          with `hierarchy -check`, `check -assert`, latch count (must be 0), and THE NUMBER OF MEMORIES Yosys infers
          (the claim to check: one memory per logical bank).
fpga      vendor flows (synth_xilinx -family xc7, synth_ice40, synth_ecp5): which RAM primitive each bank really maps
          to, how many, and what is left in LUTs / flip-flops.  A depth sweep shows where a bank stops mapping to block
          RAM (small banks go to distributed RAM / LUTs): an inferred bank is NOT assumed to be a dedicated BRAM.
decode    cost of the address decoder alone on xc7: power-of-two NUM_BANKS (bit slices) versus non-power-of-two
          (constant divide / modulo).
INFERENCE EVIDENCE ONLY.  No vendor tool (Vivado, Quartus, Radiant), no place-and-route, no timing, no board, no ASIC
flow: nothing here is a frequency, area-in-um2, power or access-time figure.  Every row records the exact Yosys script.
"""
from __future__ import annotations

import json
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, RTL, TP, provenance, rtl_files, sh, write_json  # noqa: E402

FILES = " ".join(str(f) for f in rtl_files())
INC = f"-I{RTL} -I{TP / 'rtl/sram'}"
WORK = BUILD / "ys"


def chparam(top: str, p: dict) -> str:
    """ONE chparam command carrying every override (Yosys 0.33 re-validates the module after each separate -set), and it
    must come BEFORE `hierarchy`, which discards the un-derived templates."""
    return f"chparam {' '.join(f'-set {k} {v}' for k, v in p.items())} {top};" if p else ""


def ys(script: str, tag: str, timeout=1800) -> tuple[dict, str]:
    WORK.mkdir(parents=True, exist_ok=True)
    js = WORK / f"{tag}.json"
    full = f"{script} tee -q -o {js} stat -json;"
    r = sh(["yosys", "-p", full], timeout=timeout)
    data = None
    if js.exists():
        try:
            data = json.loads(js.read_text())
        except Exception:
            data = None
    return {"rc": r["rc"], "log": r["out"], "stat": data, "secs": r["secs"]}, full


def cells(stat) -> dict:
    return dict(stat.get("design", {}).get("num_cells_by_type", {})) if stat else {}


def cnt(c: dict, pat: str) -> int:
    return sum(v for k, v in c.items() if re.search(pat, k))


def warnings(log: str) -> int:
    return len(re.findall(r"^Warning:", log, re.M))


PARAMS = dict(DATA_WIDTH=32, BANK_DEPTH=1024, PERF_EN=1)


def row_generic(nb: int, d: int, perf: int, extra=None):
    p = {**PARAMS, "NUM_BANKS": nb, "NUM_PORTS": nb, "BANK_DEPTH": d, "PERF_EN": perf, **(extra or {})}
    tag = f"gen_b{nb}_d{d}_p{perf}"
    script = (f"read_verilog -sv {INC} {FILES}; {chparam('sf_sram_bank', p)} hierarchy -check -top sf_sram_bank; "
              f"synth -top sf_sram_bank -flatten -run :fine; check -assert;")
    r, full = ys(script, tag)
    c = cells(r["stat"])
    dump = WORK / f"{tag}.dump"
    sh(["yosys", "-q", "-p", f"{script} tee -o {dump} dump t:$mem_v2;"])
    shape = ""
    if dump.exists():
        t = dump.read_text()
        w = re.findall(r"parameter \\WIDTH (\d+)", t)
        s = re.findall(r"parameter \\SIZE (\d+)", t)
        shape = f"{w[0] if w else '?'}b x {s[0] if s else '?'}" if w and s else ""
    return {"kind": "generic", "banks": nb, "depth": d, "perf_en": perf, "rc": r["rc"], "memories": c.get("$mem_v2", 0),
            "mem_shape": shape, "latches": cnt(c, r"dlatch|DLATCH"), "warnings": warnings(r["log"]), "script": full}


FPGA = {
    "xc7":   ("synth_xilinx -family xc7 -flatten -top sf_sram_bank", r"^RAMB(36|18)", r"^(RAM(32|64|128|256)|SRL|SRLC)"),
    "ice40": ("synth_ice40 -flatten -top sf_sram_bank", r"^SB_RAM40_4K", None),
    "ecp5":  ("synth_ecp5 -top sf_sram_bank", r"^DP16KD", r"TRELLIS_DPR16X4"),
}


def row_fpga(target: str, nb: int, d: int, perf: int = 1, dw: int = 32, extra=None):
    p = {**PARAMS, "NUM_BANKS": nb, "NUM_PORTS": nb, "BANK_DEPTH": d, "PERF_EN": perf, "DATA_WIDTH": dw, **(extra or {})}
    cmd, bram_pat, lram_pat = FPGA[target]
    tag = f"{target}_b{nb}_d{d}_w{dw}_p{perf}"
    script = f"read_verilog -sv {INC} {FILES}; {chparam('sf_sram_bank', p)} hierarchy -check -top sf_sram_bank; {cmd};"
    r, full = ys(script, tag)
    c = cells(r["stat"])
    bram = {k: v for k, v in c.items() if re.search(bram_pat, k)}
    lram = {k: v for k, v in c.items() if lram_pat and re.search(lram_pat, k)}
    return {"kind": "fpga", "target": target, "banks": nb, "depth": d, "data_width": dw, "perf_en": perf, "rc": r["rc"],
            "block_ram": bram, "dist_ram": lram, "luts": cnt(c, r"^(LUT\d|SB_LUT4|LUT4)"), "ffs": cnt(c, r"^(FD|SB_DFF|TRELLIS_FF)"),
            "carry": cnt(c, r"CARRY"), "cells_total": sum(c.values()), "warnings": warnings(r["log"]), "secs": r["secs"], "script": full}


def row_array(nb: int, d: int = 1024):
    p = dict(NUM_BANKS=nb, BANK_DEPTH=d, DATA_WIDTH=32, ID_WIDTH=6)
    tag = f"arr_b{nb}_d{d}"
    script = (f"read_verilog -sv {INC} {FILES}; {chparam('sf_sram_bank_array', p)} hierarchy -check -top sf_sram_bank_array; "
              f"synth_xilinx -family xc7 -flatten -top sf_sram_bank_array;")
    r, full = ys(script, tag)
    c = cells(r["stat"])
    return {"kind": "array", "banks": nb, "depth": d, "rc": r["rc"], "block_ram": {k: v for k, v in c.items() if re.search(r"^RAMB(36|18)", k)},
            "luts": cnt(c, r"^LUT\d"), "ffs": cnt(c, r"^FD"), "script": full}


def row_decode(nb: int, d: int, mode: int, blk: int, aw_extra: int = 0, strict: int = 0, bpw: int = 4):
    cap = nb * d * bpw
    aw = (cap - 1).bit_length() + aw_extra
    p = dict(NUM_BANKS=nb, BANK_DEPTH=d, BYTES_PER_WORD=bpw, ADDR_WIDTH=aw, MAP_MODE=mode, BLOCK_WORDS=blk, STRICT_ALIGN=strict)
    tag = f"dec_b{nb}_d{d}_m{mode}_{blk}_{aw_extra}_{strict}"
    script = (f"read_verilog -sv {INC} {FILES}; {chparam('sf_sram_bank_addr_decode', p)} hierarchy -check -top sf_sram_bank_addr_decode; "
              f"synth_xilinx -family xc7 -flatten -top sf_sram_bank_addr_decode;")
    r, full = ys(script, tag, timeout=600)
    c = cells(r["stat"])
    return {"kind": "decode", "banks": nb, "depth": d, "mode": ["SEQ", "BLOCK", "XOR"][mode], "block": blk, "aw_extra": aw_extra, "strict": strict,
            "rc": r["rc"], "luts": cnt(c, r"^LUT\d"), "carry": cnt(c, r"CARRY"), "cells_total": sum(c.values()), "script": full}


def jobs():
    j = []
    for nb in (2, 4, 8, 16):
        j.append(("generic", lambda nb=nb: row_generic(nb, 1024, 1)))
        j.append(("generic", lambda nb=nb: row_generic(nb, 1024, 0)))
    for t in ("xc7", "ice40", "ecp5"):
        for nb in (2, 4, 8, 16):
            j.append(("fpga", lambda t=t, nb=nb: row_fpga(t, nb, 1024)))
    for nb in (2, 4, 8, 16):                                             # counters off: the banking logic without the counters
        j.append(("fpga", lambda nb=nb: row_fpga("xc7", nb, 1024, perf=0)))
    for d in (16, 32, 64, 128, 256, 512, 2048, 4096):                    # depth sweep: where does a bank stop being block RAM?
        j.append(("sweep", lambda d=d: row_fpga("xc7", 4, d, perf=0)))
    j.append(("sweep", lambda: row_fpga("xc7", 4, 512, perf=0, dw=64)))
    j.append(("sweep", lambda: row_fpga("xc7", 4, 256, perf=0, dw=72, extra=dict(BYTE_WIDTH=9))))
    for nb in (2, 4, 8, 16):                                             # decoder cost: powers of two
        for mode, blk in ((0, 1), (1, 8), (2, 1)):
            j.append(("decode", lambda nb=nb, mode=mode, blk=blk: row_decode(nb, 256, mode, blk)))
        j.append(("decode", lambda nb=nb: row_decode(nb, 256, 0, 1, aw_extra=2)))
        j.append(("decode", lambda nb=nb: row_decode(nb, 256, 0, 1, strict=1)))
    for nb in (3, 5, 6, 7, 9, 12, 15):                                   # non-powers of two: generic branch
        j.append(("decode", lambda nb=nb: row_decode(nb, 256, 0, 1)))
        j.append(("decode", lambda nb=nb: row_decode(nb, 256, 1, 8)))
    return j


def main() -> int:
    append = "--append" in sys.argv
    if "--report-only" in sys.argv:               # regenerate reports/synth.md from the stored rows (no synthesis)
        return finish(json.loads((REPORTS / "synth.json").read_text())["rows"])
    rows = []
    if append:                                    # keep every existing row, add the array-only rows, regenerate the report
        rows = [r for r in json.loads((REPORTS / "synth.json").read_text())["rows"] if r["kind"] != "array"]
        have = {(r["banks"]) for r in rows if r["kind"] == "fpga" and r["target"] == "xc7" and r["depth"] == 1024 and r["data_width"] == 32 and not r["perf_en"]}
        rows += [row_fpga("xc7", nb, 1024, perf=0) for nb in (2, 4, 8, 16) if nb not in have]
        rows += [row_array(nb) for nb in (2, 4, 8, 16)]
        return finish(rows)
    return finish(run_all(rows))


def run_all(rows):
    with ThreadPoolExecutor(3) as ex:
        futs = [(k, ex.submit(f)) for k, f in jobs()]
        for k, f in futs:
            rows.append(f.result())
            print(f"  done {len(rows)}/{len(futs)}", end="\r", flush=True)
    print()
    rows += [row_array(nb) for nb in (2, 4, 8, 16)]
    return rows


def finish(rows) -> int:
    gen = [r for r in rows if r["kind"] == "generic"]
    fp = [r for r in rows if r["kind"] == "fpga"]
    dec = [r for r in rows if r["kind"] == "decode"]
    arr = [r for r in rows if r["kind"] == "array"]
    ok_all = all(r["rc"] == 0 for r in rows)

    L = ["# Synthesis and FPGA memory-inference report", "",
         "**Inference evidence only.**  Yosys " + provenance()["tools"]["yosys"] + ".  No vendor tool (Vivado / Quartus / Radiant), no "
         "place-and-route, no timing, no board, no ASIC flow: there is **no frequency, area in um2, power or access-time figure anywhere in this "
         "package**.  Whether a bank maps to a block RAM on a given device depends on the tool version, the device family and the bank shape; "
         "re-check with the vendor tool (`synth/vivado/synth_srambank.tcl`, not run here).", "",
         "## 1. One memory per logical bank (generic synthesis, 32-bit x 1024 words per bank)", "",
         "| banks | counters | memories inferred | shape | latches | warnings | exit |", "|---|---|---|---|---|---|---|"]
    for r in gen:
        L.append(f"| {r['banks']} | {'on' if r['perf_en'] else 'off'} | **{r['memories']}** | {r['mem_shape']} | {r['latches']} | {r['warnings']} | {r['rc']} |")
    L += ["", "Expected and observed: `memories == banks`, 0 latches, `check -assert` clean.", "",
          "## 2. What the memories become on FPGA targets (Yosys vendor flows, 32-bit x 1024 words per bank)", "",
          "| target | banks | block RAM primitives | RAM per bank | distributed RAM | LUTs | FFs | counters |", "|---|---|---|---|---|---|---|---|"]
    for r in [x for x in fp if x["depth"] == 1024 and x["data_width"] == 32]:
        br = ", ".join(f"{k}: {v}" for k, v in sorted(r["block_ram"].items())) or "none"
        tot = sum(r["block_ram"].values())
        per = f"{tot / r['banks']:g}" if tot else "0"
        dr = ", ".join(f"{k}: {v}" for k, v in sorted(r["dist_ram"].items())) or "-"
        L.append(f"| {r['target']} | {r['banks']} | {br} | {per} | {dr} | {r['luts']} | {r['ffs']} | {'on' if r['perf_en'] else 'off'} |")
    L += ["", "The LUT / FF columns of the `counters on` rows are dominated by the performance counters (up to 7 x NUM_BANKS + (NUM_BANKS+1) + 3 32-bit "
          "counters; Yosys prunes those that are provably zero in the configuration), not by the banking logic; compare the `counters off` rows.", "",
          "## 3. Depth sweep, 4 banks, xc7 (counters off): where does a bank stop being a block RAM?", "",
          "| depth x width | block RAM | distributed RAM | LUTs | FFs |", "|---|---|---|---|---|"]
    sw = [x for x in fp if x["target"] == "xc7" and x["banks"] == 4 and not x["perf_en"]]
    for r in sorted(sw, key=lambda x: (x["data_width"], x["depth"])):
        br = ", ".join(f"{k}: {v}" for k, v in sorted(r["block_ram"].items())) or "none"
        dr = ", ".join(f"{k}: {v}" for k, v in sorted(r["dist_ram"].items())) or "none"
        L.append(f"| {r['depth']} x {r['data_width']} | {br} | {dr} | {r['luts']} | {r['ffs']} |")
    L += ["", "Shallow banks do not use a block RAM at all: this is why the inference is *checked* rather than assumed.", "",
          "## 3b. Cost of the lane front end (xc7, 32-bit x 1024 words per bank, counters off, `NUM_PORTS = NUM_BANKS`)", "",
          "`sf_sram_bank` puts a full **lane x bank crossbar** in front of the banks (request mux per bank, response routing per lane, decoders, "
          "interlock); it scales as NUM_PORTS x NUM_BANKS.  `sf_sram_bank_array` is the per-bank interface with **no** crossbar (one request port per "
          "bank, response pipelines only).  Yosys LUT counts, evidence of scaling only -- not an area or timing figure, and the RTL is not tuned for area:", "",
          "| banks | `sf_sram_bank` LUTs (counters off) | `sf_sram_bank_array` LUTs | `sf_sram_bank_array` FFs | RAMB36E1 (both) |", "|---|---|---|---|---|"]
    offr = {r["banks"]: r for r in fp if r["target"] == "xc7" and r["depth"] == 1024 and r["data_width"] == 32 and not r["perf_en"]}
    for a in sorted(arr, key=lambda x: x["banks"]):
        n = a["banks"]
        L.append(f"| {n} | {offr[n]['luts']} | {a['luts']} | {a['ffs']} | {sum(a['block_ram'].values())} |")
    L += ["", "Reading: the banks themselves are cheap; the lane crossbar dominates and grows ~NUM_PORTS x NUM_BANKS.  A controller that arbitrates "
          "per bank and drives `sf_sram_bank_array` directly avoids it; the lane front end is the convenient, self-checking option for small bank counts.", "",
          "## 4. Address decoder cost (xc7 LUT6 count of `sf_sram_bank_addr_decode` alone, 4-byte words, 256 words per bank)", "",
          "| banks | map | extra address bits | strict align | LUTs | CARRY4 |", "|---|---|---|---|---|---|"]
    for r in dec:
        pw2 = (r["banks"] & (r["banks"] - 1)) == 0
        mp = r["mode"] if r["mode"] == "SEQ" else f"{r['mode']} B={r['block']}"
        L.append(f"| {r['banks']}{'' if pw2 else ' (not 2^n)'} | {mp} | {r['aw_extra']} | {r['strict']} | {r['luts']} | {r['carry']} |")
    L += ["", "Power-of-two bank counts decode with bit slices (0 LUTs for SEQ / BLOCK when the capacity is exactly 2^n bytes; one XOR per bank-index bit for XOR); "
          "a non-power-of-two count needs the generic constant divide / modulo, which costs real logic -- the numbers above are the evidence.  Caveat: Yosys 0.33 "
          "maps a constant divisor to a general divider array, so these counts are an upper-end figure; a vendor tool may reduce constant division "
          "(e.g. by reciprocal multiplication), but it is never free, and the power-of-two path needs none of it.", "",
          "## Scripts", "", "Every row's exact Yosys script is stored in `reports/synth.json` (`script`)."]
    (REPORTS / "synth.md").write_text("\n".join(L) + "\n")
    write_json(REPORTS / "synth.json", {"provenance": provenance(), "rows": rows, "all_exit_zero": ok_all})
    bad = [r for r in gen if r["memories"] != r["banks"] or r["latches"]]
    print(f"SYNTH_RESULT {'PASS' if ok_all and not bad else 'FAIL'} rows={len(rows)} exit_zero={ok_all} memory_count_mismatch={len(bad)}")
    return 0 if ok_all and not bad else 1


if __name__ == "__main__":
    sys.exit(main())
