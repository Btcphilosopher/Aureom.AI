#!/usr/bin/env bash
# Builds the deliverable archive OUTSIDE git: SHA256SUMS of every delivered file, then a zip next to the package folder.
# Nothing is committed or pushed.  Usage: bash scripts/package.sh [output-dir]
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
name="$(basename "$here")"
out="${1:-$(dirname "$here")}"
mkdir -p "$out"
cd "$here"
rm -f SHA256SUMS
find . -type f ! -path './build*' ! -path './.git/*' ! -name 'SHA256SUMS' ! -name '*.pyc' ! -path '*/__pycache__/*' ! -name '*.chain.log' | LC_ALL=C sort | sed 's|^\./||' | xargs sha256sum > SHA256SUMS
cd "$(dirname "$here")"
rm -f "$out/silicaflux-srambank-p72.zip"
zip -q -r "$out/silicaflux-srambank-p72.zip" "$name" -x "$name/build*" -x "$name/*/__pycache__/*" -x "$name/__pycache__/*" -x "$name/*.chain.log"
echo "wrote $out/silicaflux-srambank-p72.zip ($(unzip -Z1 "$out/silicaflux-srambank-p72.zip" | wc -l) entries)"
