#!/usr/bin/env python3
"""SRAMBank regression runner.  Suites (comma separated, or `all`):

  lint     Verilator -Wall (zero warnings required; -fno-inline, see docs/04) and Icarus -Wall elaboration of every RTL
           module over a configuration matrix, with and without SYNTHESIS defined
  neg      illegal parameterisations must fail elaboration in Verilator, Icarus AND Yosys (message checked)
  decode   exhaustive decoder proof (tb_sf_sram_bank_addr_decode) + comparison of every RTL dump with the Python model
  array    per-bank interface testbench (tb_sf_sram_bank_array)
  stage2   sf_sram_bank, TWO banks      (the first thing validated)
  stage4   sf_sram_bank, FOUR banks     (the validation target; the conflict tests are part of every run)
  stage8   EIGHT and SIXTEEN banks      REFUSES TO RUN unless reports/gate.json says the bank-conflict gate passed for
                                        the CURRENT RTL (python3 scripts/run_mutants.py --group conflict --gate)
  extra    non-power-of-two bank counts (SEQ / BLOCK: generic divider branch)
  perf     measured concurrency of the workloads (reports/concurrency.md)
Every run records commands, exit codes, tool versions and the RTL hash.  Same seed -> same stimulus in Verilator and
Icarus: the number of checks must be identical (suite xsim is folded into the stage suites).
  python3 scripts/run_regress.py --suite lint,neg,decode,array,stage2,stage4,stage8,extra --out regression [--jobs 4]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (ARRAY_CONFIGS, BANK_FILES, BUILD, CONFIGS, CORE_FILES, DECODE_CONFIGS, MODEL, NEGATIVE, REPORTS, ROOT, RTL,  # noqa: E402
                    TB, TP, build_sim, cleanup_build, inc_dirs, provenance, rtl_files, run_sim, sh, src_hash, write_json)

SYS_TB, ARR_TB, DEC_TB = TB / "tb_sf_sram_bank.sv", TB / "tb_sf_sram_bank_array.sv", TB / "tb_sf_sram_bank_addr_decode.sv"
INC = [f"-I{d}" for d in inc_dirs()]


def rec(suite, name, tool, result, **kw):
    return {"suite": suite, "cfg": name, "tool": tool, "result": result, **kw}


# --------------------------------------------------------------------------------------------------------- lint
LINT_CFGS = [
    {}, dict(NUM_BANKS=2, NUM_PORTS=2), dict(NUM_BANKS=4, NUM_PORTS=1), dict(NUM_BANKS=8, NUM_PORTS=8, READ_LATENCY=2),
    dict(NUM_BANKS=16, NUM_PORTS=16, MAP_MODE=2), dict(NUM_BANKS=16, NUM_PORTS=3, MAP_MODE=1, BLOCK_WORDS=8),
    dict(NUM_BANKS=4, NUM_PORTS=6, READ_LATENCY=3, WRITE_ACK=0, STRICT_ALIGN=1),
    dict(NUM_BANKS=3, BANK_DEPTH=100, NUM_PORTS=2), dict(PERF_EN=0), dict(DATA_WIDTH=72, BYTE_WIDTH=9, BANK_DEPTH=64),
    dict(DATA_WIDTH=64, ID_WIDTH=1, CNT_W=8), dict(NUM_BANKS=4, ADDR_WIDTH=20),
]


def suite_lint(jobs):
    files = [str(f) for f in rtl_files()]
    out = []

    def one(item):
        top, ovr, defs = item
        g = [f"-G{k}={v}" for k, v in ovr.items()]
        v = sh(["verilator", "--lint-only", "-Wall", "-fno-inline", *INC, *[f"-D{d}" for d in defs], *g, "--top-module", top, *files], timeout=300)
        warns = len(re.findall(r"^%(Warning|Error)", v["out"], re.M))
        name = f"{top}{'+' + ','.join(f'{k}={x}' for k, x in ovr.items()) if ovr else ''}{' [SYNTHESIS]' if defs else ''}"
        return rec("lint", name, "verilator -Wall", "PASS" if v["rc"] == 0 and warns == 0 else "FAIL", warnings=warns,
                   cmd=v["cmd"][-300:], log="" if warns == 0 else v["out"][-800:])

    items = [("sf_sram_bank", o, d) for o in LINT_CFGS for d in ((), ("SYNTHESIS",))]
    items += [(t, {}, d) for t in ("sf_sram_bank_array", "sf_sram_bank_perf", "sf_sram_bank_addr_decode", "sf_sram_bank_addr_unmap") for d in ((), ("SYNTHESIS",))]
    items += [("sf_sram_bank_addr_decode", dict(NUM_BANKS=n, BANK_DEPTH=d_, BYTES_PER_WORD=b, MAP_MODE=m, BLOCK_WORDS=k, STRICT_ALIGN=s), ())
              for (n, d_, b, m, k, s) in [(4, 256, 4, 1, 8, 1), (3, 100, 4, 0, 1, 0), (16, 64, 4, 2, 1, 1), (8, 1000, 8, 0, 1, 0), (12, 64, 4, 1, 4, 0), (2, 300, 1, 1, 4, 0)]]
    with ThreadPoolExecutor(jobs) as ex:
        out += list(ex.map(one, items))
    # the four initial configurations (2 / 4 / 8 / 16 banks), instantiated from their preset macros
    ex_inc = [*INC, f"-I{ROOT / 'examples'}"]
    ex_file = str(ROOT / "examples/sf_sram_bank_examples.sv")
    for nb in (2, 4, 8, 16):
        top = f"sf_srambank_{nb}x1024x32"
        v = sh(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-fno-inline", *ex_inc, "--top-module", top, *files, ex_file], timeout=300)
        warns = len(re.findall(r"^%(Warning|Error)", v["out"], re.M))
        out.append(rec("lint", top, "verilator -Wall (example preset)", "PASS" if v["rc"] == 0 and warns == 0 else "FAIL", warnings=warns,
                       log="" if warns == 0 else v["out"][-600:]))
        r = sh(["iverilog", "-g2012", "-Wall", *ex_inc, "-s", top, "-o", BUILD / "lint_ex.vvp", *files, ex_file], timeout=300)
        bad = bool(re.search(r"\berror\b|sorry:", r["out"], re.I))
        out.append(rec("lint", top, "iverilog -Wall (example preset)", "PASS" if r["rc"] == 0 and not bad else "FAIL", log="" if not bad else r["out"][-600:]))
    for top in ("sf_sram_bank", "sf_sram_bank_array"):
        r = sh(["iverilog", "-g2012", "-Wall", *INC, "-s", top, "-o", BUILD / "lint_ic.vvp", *files], timeout=300)
        bad = bool(re.search(r"\berror\b|sorry:", r["out"], re.I))
        out.append(rec("lint", top, "iverilog -Wall", "PASS" if r["rc"] == 0 and not bad else "FAIL", log="" if not bad else r["out"][-600:]))
    return out


# --------------------------------------------------------------------------------------------------------- neg
def suite_neg(jobs):
    files = [str(f) for f in rtl_files()]
    ys_files = " ".join(files)

    def one(case):
        name, mod, ovr, frag = case
        res = []
        g = [f"-G{k}={v}" for k, v in ovr.items()]
        v = sh(["verilator", "--lint-only", *INC, *g, "--top-module", mod, *files], timeout=300)
        # PASS = the illegal configuration is REJECTED (non-zero exit).  `msg` records whether the explicit message
        # was reached: a tool may abort on its own width/size error first (e.g. NUM_PORTS=0), which still rejects it.
        ok = v["rc"] != 0
        res.append(rec("neg", name, "verilator", "PASS" if ok else "FAIL", expected=frag, msg=frag in v["out"], log="" if ok else "accepted an illegal configuration"))
        # Icarus: the generate-time $fatal is an `initial $fatal` there; run the elaborated model for 0 time
        pv = [f"-P{mod}.{k}={v_}" for k, v_ in ovr.items()]
        out = BUILD / "neg" / f"{name}.vvp"
        out.parent.mkdir(parents=True, exist_ok=True)
        b = sh(["iverilog", "-g2012", *INC, *pv, "-s", mod, "-o", out, *files], timeout=300)
        if b["rc"] == 0:
            r = sh(["vvp", "-n", out], timeout=120)
            ok = r["rc"] != 0
            res.append(rec("neg", name, "iverilog", "PASS" if ok else "FAIL", expected=frag, msg=frag in r["out"], log="" if ok else "accepted an illegal configuration"))
        else:
            res.append(rec("neg", name, "iverilog", "PASS", expected=frag, msg=frag in b["out"], log="rejected at elaboration"))
        # Yosys 0.33 aborts on the $fatal; the message is encoded in the g_err_* block name
        ch = " ".join(f"-set {k} {v_}" for k, v_ in ovr.items())
        y = sh(["yosys", "-q", "-p", f"read_verilog -sv -I{RTL} -I{TP / 'rtl/sram'} {ys_files}; hierarchy -top {mod}; chparam {ch} {mod}; hierarchy -check -top {mod}"], timeout=300)
        res.append(rec("neg", name, "yosys", "PASS" if y["rc"] != 0 else "FAIL", expected=frag, msg=frag in y["out"], log="" if y["rc"] != 0 else "accepted an illegal configuration"))
        return res

    out = []
    with ThreadPoolExecutor(jobs) as ex:
        for r in ex.map(one, NEGATIVE):
            out += r
    return out


# --------------------------------------------------------------------------------------------------------- decode
def suite_decode(jobs):
    def one(c):
        tag = f"dec_{c['name']}"
        d = BUILD / tag
        res = []
        for sim in ["vl"] + (["ic"] if c["ic"] else []):
            o = d / sim
            b = build_sim(sim, "tb_sf_sram_bank_addr_decode", [DEC_TB], RTL, c["p"], o, jobs=1, extra_rtl=[RTL / "sf_sram_bank_addr_decode.sv", RTL / "sf_sram_bank_addr_unmap.sv"])
            if b["rc"] != 0:
                res.append(rec("decode", c["name"], sim, "BUILD_FAIL", log=b["out"][-500:]))
                continue
            dump = o / "dump.txt"
            r = run_sim(sim, b["exe"], [f"+dump={dump}"])
            ok = r["result"] == "PASS"
            spec = ",".join(f"{k}={v}" for k, v in c["p"].items()).replace("MODE", "MODE").replace("BLK", "B").replace("BPW", "BPW")
            m = sh([sys.executable, "-I", MODEL, "--compare", dump, spec]) if ok else {"rc": 1, "out": "skipped"}
            mc = m["rc"] == 0
            res.append(rec("decode", c["name"], sim, "PASS" if ok and mc else "FAIL", checks=r["checks"], errors=r["errors"],
                           model_compare="PASS" if mc else "FAIL", log="" if ok and mc else (r["out"][-400:] + m["out"][-300:])))
            cleanup_build(o)
        return res

    out = []
    with ThreadPoolExecutor(jobs) as ex:
        for r in ex.map(one, DECODE_CONFIGS):
            out += r
    return out


# --------------------------------------------------------------------------------------------------------- simulation suites
def run_cfg(suite: str, c: dict, tbfile: Path, top: str, args_for_seed, sims=None) -> list[dict]:
    res, counts = [], {}
    for sim in sims or (["vl"] + (["ic"] if c.get("ic") else [])):
        o = BUILD / f"{suite}_{c['name']}" / sim
        b = build_sim(sim, top, [tbfile], RTL, c["p"], o, jobs=1)
        if b["rc"] != 0:
            res.append(rec(suite, c["name"], sim, "BUILD_FAIL", log=b["out"][-800:]))
            continue
        for seed in c.get("seeds", [1]):
            r = run_sim(sim, b["exe"], args_for_seed(c, seed))
            res.append(rec(suite, c["name"], sim, r["result"], seed=seed, checks=r["checks"], errors=r["errors"], secs=r["secs"],
                           phases=len(r["phases"]), perf=r["perf"], log="" if r["result"] == "PASS" else "\n".join(r["err_lines"]) + r["out"][-400:]))
            counts.setdefault(seed, {})[sim] = r["checks"]
        cleanup_build(o)
    # same seed -> same stimulus: the check counts of the two simulators must be identical
    for seed, d in counts.items():
        if len(d) == 2:
            res.append(rec(suite + "-xsim", c["name"], "vl==ic", "PASS" if d["vl"] == d["ic"] and d["vl"] > 0 else "FAIL", seed=seed,
                           checks_vl=d["vl"], checks_ic=d["ic"]))
    return res


def suite_stage(stage, jobs, suite_name, perf=False):
    cfgs = [c for c in CONFIGS if str(c["stage"]) == str(stage)]

    def args(c, seed):
        return [f"+seed={seed}", f"+nrand={c['nrand']}"] + ([] if perf else ["+nowl"])
    out = []
    with ThreadPoolExecutor(jobs) as ex:
        for r in ex.map(lambda c: run_cfg(suite_name, c, SYS_TB, "tb_sf_sram_bank", args), cfgs):
            out += r
    # COVERAGE: a stage must really exercise the bank counts it claims (a mis-tagged configuration once silently dropped
    # every 16-bank run from the 8/16-bank stage; this record makes that impossible to miss)
    need = {"2": {2}, "4": {4}, "8": {8, 16}, "x": {3, 5, 6, 12}}.get(str(stage))
    if need:
        ran = {c["p"]["NB"] for c in cfgs}
        out.append(rec(suite_name + "-coverage", f"stage {stage}", "run_regress", "PASS" if need <= ran else "FAIL",
                       banks_run=sorted(ran), banks_required=sorted(need)))
    return out


def suite_array(jobs):
    def args(c, seed):
        return [f"+seed={seed}", "+ncyc=8000"]
    out = []
    with ThreadPoolExecutor(jobs) as ex:
        for r in ex.map(lambda c: run_cfg("array", dict(c, seeds=[1, 2] if c["name"] == "a4" else [1]), ARR_TB, "tb_sf_sram_bank_array", args), ARRAY_CONFIGS):
            out += r
    return out


PERF_CFGS = ["b2_seq", "b4_seq", "b4_xor", "b4_contig", "b8_seq", "b8_xor", "b16_seq", "b16_xor", "b16_block4"]


def suite_perf(jobs):
    out = []
    cfgs = [dict(c, seeds=[1], ic=False) for c in CONFIGS if c["name"] in PERF_CFGS]

    def args(c, seed):
        return [f"+seed={seed}", "+nrand=200"]
    with ThreadPoolExecutor(jobs) as ex:
        for r in ex.map(lambda c: run_cfg("perf", c, SYS_TB, "tb_sf_sram_bank", args), cfgs):
            out += r
    return out


def gate_ok() -> tuple[bool, str]:
    g = REPORTS / "gate.json"
    if not g.exists():
        return False, "reports/gate.json missing: run `python3 scripts/run_mutants.py --group conflict --gate` first"
    d = json.loads(g.read_text())
    if d.get("conflict_gate") != "PASS":
        return False, "the bank-conflict gate did not pass"
    if d.get("provenance", {}).get("rtl_sha256") != src_hash([*RTL.glob("*.sv"), *RTL.glob("*.svh")]):
        return False, "reports/gate.json was produced for a different RTL: rerun the conflict gate"
    return True, "gate PASS for the current RTL"


# --------------------------------------------------------------------------------------------------------- reporting
def summarise(recs):
    by = {}
    for r in recs:
        by.setdefault(r["suite"], []).append(r)
    return by


def write_perf_md(recs):
    rows = []
    for r in recs:
        for line in r.get("perf", []):
            kv = dict(re.findall(r"(\w+)=(\S+)", line))
            kv["cfg"] = r["cfg"]
            rows.append(kv)
    if not rows:
        return
    names = {"0": "SEQ", "1": "BLOCK", "2": "XOR"}
    lines = ["# Measured concurrency (simulation, this RTL, fixed-priority interlock, requesters hold until accepted)", "",
             "`ops/cycle` = lane requests served per active clock cycle.  One single-port bank can never exceed 1.0; the banked "
             "subsystem reaches up to NUM_BANKS only when concurrent requests fall on different banks.", "",
             "| config | workload | banks | lanes | map | ops | active cycles | ops/cycle | peak banks in one cycle | conflict events | stalled lane-cycles |",
             "|---|---|---|---|---|---|---|---|---|---|---|"]
    for k in rows:
        ops, act = int(k["ops"]), max(int(k["active_cycles"]), 1)
        mp = names.get(k["map"], k["map"]) + (f"(B={k['blk']})" if k["map"] == "1" else "")
        hist = [int(x) for x in k["hist"].split(",")]                    # cycles with exactly k banks accessed, since the workload began
        peak = max((i for i, v in enumerate(hist) if v), default=0)
        lines.append(f"| {k['cfg']} | {k['wl']} | {k['nb']} | {k['np']} | {mp} | {ops} | {act} | {ops / act:.2f} | {peak} | {k['conflict_events']} | {k['stalled_lane_cycles']} |")
    (REPORTS / "concurrency.md").write_text("\n".join(lines) + "\n")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--suite", default="all")
    ap.add_argument("--out", default="regression")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    suites = ["lint", "neg", "decode", "array", "stage2", "stage4", "stage8", "extra", "perf"] if a.suite == "all" else a.suite.split(",")

    recs: list[dict] = []
    refused = None
    for s in suites:
        print(f"== suite {s}", flush=True)
        if s == "lint":
            recs += suite_lint(a.jobs)
        elif s == "neg":
            recs += suite_neg(a.jobs)
        elif s == "decode":
            recs += suite_decode(a.jobs)
        elif s == "array":
            recs += suite_array(a.jobs)
        elif s == "stage2":
            recs += suite_stage(2, a.jobs, "bank2")
        elif s == "stage4":
            recs += suite_stage(4, a.jobs, "bank4")
        elif s == "stage8":
            ok, why = gate_ok()
            if not ok:
                refused = why
                print(f"   REFUSED: {why}")
                recs.append(rec("bank8-16", "gate", "run_regress", "REFUSED", log=why))
                continue
            print(f"   {why}")
            recs += suite_stage(8, a.jobs, "bank8-16")
        elif s == "extra":
            recs += suite_stage("x", a.jobs, "bank-nonpow2")
        elif s == "perf":
            p = suite_perf(a.jobs)
            recs += p
            write_perf_md(p)
        else:
            print(f"unknown suite {s}")
            return 2
        sm = [r for r in recs if r["suite"].startswith({"stage2": "bank2", "stage4": "bank4", "stage8": "bank8-16", "extra": "bank-nonpow2"}.get(s, s))]
        print(f"   {sum(r['result'] == 'PASS' for r in sm)} pass / {sum(r['result'] != 'PASS' for r in sm)} not-pass", flush=True)

    by = summarise(recs)
    nfail = sum(r["result"] not in ("PASS",) for r in recs)
    total_checks = sum(r.get("checks", 0) or 0 for r in recs if r["suite"] != "perf")
    write_json(REPORTS / f"{a.out}.json", {"provenance": provenance(), "records": recs, "total_checks": total_checks, "not_pass": nfail, "refused": refused})
    lines = [f"# Regression `{a.out}`", "", f"Total: {len(recs)} records, {nfail} not passing, {total_checks:,} scoreboard checks.", "",
             "| suite | pass | not pass |", "|---|---|---|"]
    for s, rs in by.items():
        lines.append(f"| {s} | {sum(r['result'] == 'PASS' for r in rs)} | {sum(r['result'] != 'PASS' for r in rs)} |")
    lines += ["", "## Records", "", "| suite | config | tool | seed | result | checks | notes |", "|---|---|---|---|---|---|---|"]
    for r in recs:
        note = (r.get("log", "") or "").strip().replace("\n", " ")[:120]
        lines.append(f"| {r['suite']} | {r['cfg']} | {r['tool']} | {r.get('seed', '')} | {r['result']} | {r.get('checks', '')} | {note} |")
    (REPORTS / f"{a.out}.md").write_text("\n".join(lines) + "\n")
    print(f"wrote reports/{a.out}.md  records={len(recs)} not_pass={nfail} checks={total_checks:,}")
    return 0 if nfail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
