#!/usr/bin/env python3
"""Aggregate reports/*.json into reports/SUMMARY.md and fill the results block of README.md (between the
<!--RESULTS--> markers).  Every number comes from a JSON report of the final run; nothing is typed in by hand."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, ROOT, provenance, src_hash, RTL  # noqa: E402


def load(name):
    p = REPORTS / f"{name}.json"
    return json.loads(p.read_text()) if p.exists() else None


def recs(*names):
    out = []
    for n in names:
        d = load(n)
        if d:
            out += d["records"]
    return out


def tally(rs, suite=None, tool=None):
    rs = [r for r in rs if (suite is None or r["suite"] == suite) and (tool is None or r["tool"] == tool)]
    return sum(r["result"] == "PASS" for r in rs), sum(r["result"] != "PASS" for r in rs), sum(r.get("checks", 0) or 0 for r in rs)


def main() -> int:
    names = sorted(f.stem for f in REPORTS.glob("regression_*.json"))        # every regression report present, whatever `--out` named it
    allr = recs(*names)
    mut = load("mutants")
    gate = load("gate")
    syn = load("synth")
    cur = src_hash([*RTL.glob("*.sv"), *RTL.glob("*.svh")])
    stale = [n for n in (*names, "mutants", "gate", "synth")
             if (d := load(n)) and d.get("provenance", {}).get("rtl_sha256") != cur]

    rows = []
    p, f, _ = tally(allr, "lint")
    rows.append(("Lint: Verilator `-Wall` (zero warnings) + Icarus `-Wall` elaboration", f"{p} pass / {f} fail", "sf_sram_bank over 12 configurations x {with, without `SYNTHESIS`}, every sub-module, decoder matrix"))
    neg = [r for r in allr if r["suite"] == "neg"]
    msg = sum(bool(r.get("msg")) for r in neg)
    rows.append(("Illegal parameterisations rejected", f"{sum(r['result'] == 'PASS' for r in neg)} pass / {sum(r['result'] != 'PASS' for r in neg)} fail",
                 f"{len(neg) // 3} cases x Verilator, Icarus, Yosys; explicit message reached in {msg}/{len(neg)} (a tool may abort on its own width error first)"))
    p, f, c = tally(allr, "decode")
    cmp_ok = sum(r.get("model_compare") == "PASS" for r in allr if r["suite"] == "decode")
    rows.append(("Address mapping proof (exhaustive): correct / injective / surjective / invertible / bounded", f"{p} pass / {f} fail",
                 f"{c:,} checks; {cmp_ok} RTL dumps identical to the Python model; SEQ, BLOCK, XOR; 2-16 banks and 3,5,6,7,12"))
    p, f, c = tally(allr, "array")
    rows.append(("Per-bank interface (independent enables / addresses), `sf_sram_bank_array`", f"{p} pass / {f} fail", f"{c:,} checks, 1-16 banks, latency 1-3, posted writes, non-power-of-two depth"))
    for key, label in (("bank2", "**TWO banks**"), ("bank4", "**FOUR banks**"), ("bank8-16", "EIGHT and SIXTEEN banks"), ("bank-nonpow2", "non-power-of-two bank counts")):
        p, f, c = tally(allr, key)
        if p + f:
            xs = [r for r in allr if r["suite"] == key + "-xsim"]
            cov = [r for r in allr if r["suite"] == key + "-coverage"]
            cv = (f"; bank counts exercised: {', '.join(map(str, cov[0]['banks_run']))} ({cov[0]['result']})" if cov else "")
            rows.append((f"`sf_sram_bank` self-checking simulation, {label}", f"{p} pass / {f} fail",
                         f"{c:,} scoreboard checks; Verilator vs Icarus: {sum(r['result'] == 'PASS' for r in xs)}/{len(xs)} identical check counts (same stimulus){cv}"))
        elif key == "bank8-16":
            rows.append((f"`sf_sram_bank` simulation, {label}", "NOT RUN", "gate refused or not requested"))
    if gate:
        rows.append(("**Bank-conflict gate** (before 8/16 banks): interlock + conflict-counter mutants killed on 2 AND 4 banks",
                     gate["conflict_gate"], f"{len(gate['mutants'])} mutants"))
    if mut:
        rows.append(("Mutation sanity: injected RTL bugs", f"{mut['killed']} killed / {len(mut['survived'])} survived / {len(mut['invalid'])} invalid",
                     f"of {mut['total']}; `reports/mutants.md`"))
    if syn:
        gen = [r for r in syn["rows"] if r["kind"] == "generic"]
        ok = all(r["memories"] == r["banks"] and r["latches"] == 0 for r in gen)
        rows.append(("Yosys: one memory inferred per bank, zero latches", "PASS" if ok else "FAIL", f"{len(syn['rows'])} synthesis rows (generic, xc7, ice40, ecp5, depth sweep, decoder cost); `reports/synth.md`"))

    tl = provenance()["tools"]
    block = ["| Check | Result | Notes |", "|---|---|---|"] + [f"| {a} | {b} | {c} |" for a, b, c in rows]
    block += ["", f"Tools: verilator `{tl['verilator']}`; iverilog `{tl['iverilog']}`; yosys `{tl['yosys']}`; python `{tl['python']}`.  "
              f"Not installed: vivado, quartus, openroad.  RTL sha256 `{cur[:16]}…`."]
    if stale:
        block += ["", f"**WARNING: reports produced for a different RTL than the one delivered: {', '.join(stale)}.**"]
    text = "\n".join(block)
    (REPORTS / "SUMMARY.md").write_text("# SRAMBank results (generated from the JSON reports of the final run)\n\n" + text + "\n")
    def fill(path: Path, tag: str, body: str) -> None:
        if not path.exists():
            return
        t = path.read_text()
        a, b = f"<!--{tag}-->", f"<!--/{tag}-->"
        if a in t and b in t:
            path.write_text(t[:t.index(a) + len(a)] + "\n" + body + "\n" + t[t.index(b):])

    fill(ROOT / "README.md", "RESULTS", text)
    fill(ROOT / "docs/04_verification.md", "RESULTS", text)
    if mut:
        ml = ["| id | group | status | what was broken | killed by |", "|---|---|---|---|---|"]
        for r in mut["results"]:
            ml.append(f"| {r['id']} | {r['group']} | {r['status']} | {r['desc']} | {', '.join(r.get('killed_by', [])) or '-'} |")
        fill(ROOT / "docs/04_verification.md", "MUT", "\n".join(ml))
    # compact pivot for the README: config x workload -> served lane requests per active cycle
    import re as _re
    perf = load("regression_perf")
    if perf:                                              # (written by `make bank-perf`)
        cells, wls, cfgs = {}, [], []
        for r in perf["records"]:
            for line in r.get("perf", []):
                kv = dict(_re.findall(r"(\w+)=(\S+)", line))
                if r["cfg"] not in cfgs:
                    cfgs.append(r["cfg"])
                if kv["wl"] not in wls:
                    wls.append(kv["wl"])
                cells[(r["cfg"], kv["wl"])] = (int(kv["ops"]) / max(int(kv["active_cycles"]), 1), kv["nb"], kv["np"])
        piv = ["| config (banks x lanes) | " + " | ".join(wls) + " |", "|---|" + "---|" * len(wls)]
        for c in cfgs:
            nb, npp = next(v for (cc, _), v in cells.items() if cc == c)[1:]
            piv.append(f"| `{c}` ({nb}x{npp}) | " + " | ".join(f"{cells[(c, w)][0]:.2f}" if (c, w) in cells else "-" for w in wls) + " |")
        piv += ["", "Lane requests served per active clock cycle (400 per lane). One single-port bank can never exceed 1.00; the maximum here "
                "is the number of lanes. `samebank` (every lane on one bank) is the serialised worst case. Detail: `reports/concurrency.md`."]
        fill(ROOT / "README.md", "CONCSUM", "\n".join(piv))
    conc = REPORTS / "concurrency.md"
    if conc.exists():
        body = conc.read_text().split("\n", 1)[1]            # drop the title line
        fill(ROOT / "docs/04_verification.md", "CONC", body.strip())
        fill(ROOT / "README.md", "CONC", body.strip())
    print(text)
    return 1 if stale else 0


if __name__ == "__main__":
    sys.exit(main())
