#!/usr/bin/env python3
"""Mutation sanity for the SRAMBank testbenches: inject one RTL bug at a time and require the testbench to FAIL.

A mutant is applied to a scratch copy of rtl/bank (the delivered RTL is never touched), built with Icarus (identical
stimulus and check counts to Verilator on the unmutated RTL, see docs/04_verification.md; ~10x faster to build) and run
on the listed (testbench, configuration) pairs.  KILLED = some run reported FAIL (or crashed on an assertion).
SURVIVED = every run passed: the testbench would not notice this bug.  INVALID = the patch did not apply exactly once
or the mutant did not compile; it proves nothing and is reported as such.  Before any mutant runs, the UNMUTATED RTL is
run on the same pairs and must PASS.

Groups:  conflict (the interlock and its counters: also the GATE between 4 and 8/16 banks), map (decoder), resp
(response routing / errors), array (per-bank interface), perf (counters), misc.
  python3 scripts/run_mutants.py [--group G[,G]] [--ids C01,M03] [--jobs 4] [--gate]
--gate writes reports/gate.json: PASS only if EVERY conflict mutant is killed on the 2-bank AND the 4-bank
configuration; scripts/run_regress.py --suite stage8 refuses to run without it.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (ARRAY_CONFIGS, BUILD, CONFIGS, DECODE_CONFIGS, REPORTS, ROOT, RTL, TB, build_sim, cleanup_build, provenance,  # noqa: E402
                    rtl_files, run_sim, write_json)

SYS_TB = TB / "tb_sf_sram_bank.sv"
ARR_TB = TB / "tb_sf_sram_bank_array.sv"
DEC_TB = TB / "tb_sf_sram_bank_addr_decode.sv"


def M(id_, group, file, old, new, desc, runs, count=1):
    return dict(id=id_, group=group, file=file, old=old, new=new, desc=desc, runs=runs, count=count)


TOP, DEC, ARR, PERF = "sf_sram_bank.sv", "sf_sram_bank_addr_decode.sv", "sf_sram_bank_array.sv", "sf_sram_bank_perf.sv"
B2, B4 = ("bank", "b2_seq"), ("bank", "b4_seq")

MUTANTS = [
    # ------------------------------------------------------------------ conflict / interlock (the gate)
    M("C01", "conflict", TOP, "      for (int p = 0; p < NUM_PORTS; p++) begin\n        if (want[p] && d_bank[p*BW +: BW] == BW'(b)) begin",
       "      for (int p = NUM_PORTS - 1; p >= 0; p--) begin\n        if (want[p] && d_bank[p*BW +: BW] == BW'(b)) begin",
       "highest lane index wins instead of the lowest", [B2, B4]),
    M("C02", "conflict", TOP, "            lose[p] = 1'b1;                       // an earlier", "            lose[p] = 1'b0;                       // an earlier",
       "losing lane is never marked denied", [B2, B4]),
    M("C03", "conflict", TOP, "assign req_ready = ~lose & {NUM_PORTS{rst_n}};", "assign req_ready = {NUM_PORTS{rst_n}};",
       "req_ready ignores the interlock: a denied lane believes it was accepted", [B2, B4]),
    M("C04", "conflict", TOP, "ev_conflict[b] = (cnt_b[b*INC_W +: INC_W] > INC_W'(1));", "ev_conflict[b] = (cnt_b[b*INC_W +: INC_W] > INC_W'(2));",
       "conflict event needs three requesters instead of two", [B2, B4]),
    M("C05", "conflict", TOP, "(cnt_b[b*INC_W +: INC_W] - INC_W'(1)) : '0;", "(cnt_b[b*INC_W +: INC_W]) : '0;",
       "stall count is requesters, not requesters-1", [B2, B4]),
    M("C06", "conflict", TOP, "req_wdata[win_p[b*LW +: LW]*DATA_WIDTH +: DATA_WIDTH];", "req_wdata[(win_p[b*LW +: LW]*0)*DATA_WIDTH +: DATA_WIDTH];",
       "bank writes lane 0's data whichever lane won", [B4]),
    M("C07", "conflict", TOP, "req_wmask[win_p[b*LW +: LW]*LANES +: LANES];", "req_wmask[(win_p[b*LW +: LW]*0)*LANES +: LANES];",
       "bank uses lane 0's byte enables whichever lane won", [B4]),
    M("C08", "conflict", TOP, "b_we[b]                              = req_we[win_p[b*LW +: LW]];", "b_we[b]                              = req_we[win_p[b*LW +: LW] & LW'(0)];",
       "bank uses lane 0's write enable whichever lane won", [B4]),
    M("C09", "conflict", TOP, "want[p] = req_valid[p] & d_ok[p] & rst_n;", "want[p] = req_valid[p] & rst_n;",
       "rejected (invalid) requests enter the bank interlock", [("bank", "b2_awx3"), ("bank", "b4_awx2")]),
    M("C10", "conflict", TOP, "assign st_conflict = ev_conflict;", "assign st_conflict = '0;",
       "per-bank conflict status stuck low", [B2, B4]),
    M("C11", "conflict", TOP, "      win_v[b] = seen_v;", "      win_v[b] = seen_v & (n_req < INC_W'(2));",
       "on a collision nobody is granted (all lanes denied)", [B2, B4]),
    M("C12", "conflict", TOP, ".ev_conflict, .ev_stall, .ev_busy(r_busy)", ".ev_conflict('0), .ev_stall, .ev_busy(r_busy)",
       "conflict counter never counts", [B2, B4]),
    M("C13", "conflict", TOP, ".ev_conflict, .ev_stall, .ev_busy(r_busy)", ".ev_conflict, .ev_stall('0), .ev_busy(r_busy)",
       "stall counter never counts", [B2, B4]),
    M("C14", "conflict", TOP, "b_addr[b*LAW +: LAW]                 = d_local[win_p[b*LW +: LW]*LAW +: LAW];", "b_addr[b*LAW +: LAW]                 = d_local[(win_p[b*LW +: LW]*0)*LAW +: LAW];",
       "bank address taken from lane 0 whichever lane won", [B4]),
    # ------------------------------------------------------------------ address mapping
    M("M01", "map", DEC, "assign bsel = blk & WIW'(NUM_BANKS - 1);", "assign bsel = blk & WIW'(NUM_BANKS - 2);",
       "bank-select mask one bit short", [("decode", "d4_seq"), B4]),
    M("M02", "map", DEC, "assign rowb = blk >> BW;", "assign rowb = blk >> (BW + 1);",
       "row index drops a bit: two words alias", [("decode", "d4_seq"), B4]),
    M("M03", "map", DEC, "assign bxor = USE_XOR ? (rowb & WIW'(NUM_BANKS - 1)) : '0;", "assign bxor = '0;",
       "XOR skew disabled", [("decode", "d4_xor"), ("bank", "b4_xor")]),
    M("M04", "map", DEC, "assign in_range = ({1'b0, wfull} < CAP_W);", "assign in_range = ({1'b0, wfull} <= CAP_W);",
       "off-by-one in the range check (non-power-of-two capacity)", [("decode", "d4_d1000_blk8"), ("bank", "b4_d1000")]),
    M("M05", "map", DEC, "assign in_range = ~|(wfull >> WIW);", "assign in_range = 1'b1;",
       "high address bits ignored: out-of-range addresses alias", [("decode", "d4_wide"), ("bank", "b4_awx2")]),
    M("M06", "map", DEC, "wire misaligned = (OFFW > 0) && (STRICT_ALIGN != 0) && (byte_off != '0);", "wire misaligned = (OFFW > 0) && (byte_off != '0);",
       "STRICT_ALIGN ignored (always strict)", [("decode", "d4_seq"), B4]),
    M("M07", "map", DEC, "    if (!in_range)       err_code = `SF_SRAM_BANK_ERR_RANGE;\n    else if (misaligned) err_code = `SF_SRAM_BANK_ERR_ALIGN;",
       "    if (misaligned)      err_code = `SF_SRAM_BANK_ERR_ALIGN;\n    else if (!in_range)  err_code = `SF_SRAM_BANK_ERR_RANGE;",
       "ALIGN takes priority over RANGE", [("decode", "d4_wide_strict_xor"), ("bank", "b4_strict_xor")]),
    M("M08", "map", DEC, "assign sub_bits = wlow & WIW'((1 << LB) - 1);", "assign sub_bits = wlow & WIW'((1 << LB));",
       "intra-block offset mask wrong", [("decode", "d4_blk4"), ("bank", "b4_block4")]),
    M("M09", "map", DEC, "assign local_word = LAW'((rowb << LB) | sub_bits);", "assign local_word = LAW'((rowb << LB));",
       "intra-block offset dropped from the local address", [("decode", "d4_blk4"), ("bank", "b4_block4")]),
    M("M10", "map", DEC, "assign byte_off = addr[OFFW-1:0];", "assign byte_off = addr[OFFW:1];",
       "byte offset taken from the wrong address bits", [("decode", "d4_seq"), ("bank", "b4_strict_xor")]),
    M("M11", "map", DEC, "assign bank = BW'(blk % NB_W);", "assign bank = BW'(blk / NB_W);",
       "generic (non-power-of-two) branch: bank = quotient", [("decode", "dx_b3_seq")]),
    M("M12", "map", DEC, "assign rowb = blk / NB_W;", "assign rowb = blk % NB_W;",
       "generic (non-power-of-two) branch: row = remainder", [("decode", "dx_b5_seq")]),
    M("M13", "map", "sf_sram_bank_addr_unmap.sv", "assign blk        = rowb * NB_W + sel;", "assign blk        = rowb * NB_W;",
       "inverse mapping drops the bank", [("decode", "d4_seq")]),
    # ------------------------------------------------------------------ responses, errors, routing
    M("R01", "resp", TOP, "{req_id[win_p[b*LW +: LW]*ID_WIDTH +: ID_WIDTH], win_p[b*LW +: LW]};", "{ID_WIDTH'(0), win_p[b*LW +: LW]};",
       "transaction ID not forwarded to the bank", [B4]),
    M("R02", "resp", TOP, "assign hit[b] = r_valid[b] & (r_id[b*IDA +: LW] == LW'(p));", "assign hit[b] = r_valid[b] & (LW'(0) == LW'(p));",
       "every response is routed to lane 0", [B4]),
    M("R03", "resp", TOP, "      if (le_v) begin ", "      if (le_v && !(le_we && WRITE_ACK == 0)) begin ",
       "error response of a posted write is dropped", [("bank", "b4_strict_posted"), ("bank", "b2_awx3_posted")]),
    M("R04", "resp", TOP, "s_data = r_rdata[b*DATA_WIDTH +: DATA_WIDTH] & {DATA_WIDTH{~r_we[b] & ~r_err[b]}};", "s_data = r_rdata[b*DATA_WIDTH +: DATA_WIDTH];",
       "read data leaks onto write acknowledgements", [B4]),
    M("R05", "resp", TOP, "assign lane_err_valid[p]          = v_q[READ_LATENCY-1];", "assign lane_err_valid[p]          = v_q[0];",
       "rejected-request response not aligned to READ_LATENCY", [("bank", "b4_awx2_lat3"), ("bank", "b4_strict_posted")]),
    M("R06", "resp", TOP, "c_q[0 +: 2]        <= d_ecode[p*2 +: 2];", "c_q[0 +: 2]        <= ~d_ecode[p*2 +: 2];",
       "error code inverted", [("bank", "b4_awx2")]),
    M("R07", "resp", TOP, "        s_we  = le_we;", "        s_we  = 1'b0;",
       "rejected write reported as a read response", [("bank", "b4_awx2")]),
    M("R08", "resp", TOP, "s_id   = r_id[b*IDA + LW +: ID_WIDTH];", "s_id   = r_id[b*IDA +: ID_WIDTH];",
       "response ID taken from the lane-index field", [B4]),
    # ------------------------------------------------------------------ per-bank interface (array testbench)
    M("A01", "array", ARR, "assign b_rsp_valid[b] = v_l & (~w_l | (WRITE_ACK != 0) | ew_last);", "assign b_rsp_valid[b] = v_l;",
       "posted writes are acknowledged", [("array", "a4_lat3_na"), ("bank", "b4_lat3_noack")]),
    M("A02", "array", ARR, "          id_q[k*ID_WIDTH +: ID_WIDTH] <= id_q[(k-1)*ID_WIDTH +: ID_WIDTH];", "          id_q[k*ID_WIDTH +: ID_WIDTH] <= id_q[0 +: ID_WIDTH];",
       "ID pipeline: later stages reload stage 0 (equivalent at latency 2: needs 3)", [("array", "a4_lat3")]),
    M("A03", "array", ARR, "assign b_busy[b]      = acc | (|v_q);", "assign b_busy[b]      = acc;",
       "busy ignores operations in the read pipeline", [("array", "a4"), B4]),
    M("A04", "array", ARR, "assign ev_ok[b]       = v_l & ~err_l;", "assign ev_ok[b]       = acc & ~err_l;",
       "completion event raised at issue instead of at the response", [("array", "a4"), B4]),
    M("A05", "array", ARR, "assign b_ready = {NUM_BANKS{rst_n}};", "assign b_ready = {NUM_BANKS{1'b1}};",
       "bank ready during reset", [("array", "a4"), B4]),
    M("A06", "array", ARR, "        v_q  <= '0;\n        w_q  <= '0;", "        v_q  <= v_q;\n        w_q  <= '0;",
       "in-flight responses survive reset", [("array", "a4"), B4]),
    M("A07", "array", ARR, "          ew_q[0] <= c_wr_err;", "          ew_q[0] <= 1'b0;",
       "write-error flag lost in the latency pipeline", [("array", "a4_d100_l2na")]),
    M("A08", "array", ARR, "wire err_l = v_l & (w_l ? ew_last : c_rd_err);", "wire err_l = v_l & (w_l ? 1'b0 : c_rd_err);",
       "invalid-address writes are not reported", [("array", "a4_d100")]),
    M("A09", "array", ARR, "assign ev_access[b]   = acc;", "assign ev_access[b]   = b_req[b];",
       "access event ignores reset", [("array", "a4"), B4]),
    # ------------------------------------------------------------------ counters
    M("P01", "perf", PERF, "one(ev_nacc == HW'(k))", "one(ev_nacc == HW'(k + 1))",
       "concurrency histogram shifted by one", [B4]),
    M("P02", "perf", PERF, "one(~ev_busy[b])", "one(ev_busy[b])",
       "idle counter counts busy cycles", [B4]),
    M("P03", "perf", PERF, "sat_add = s[CNT_W] ? MAXV : s[CNT_W-1:0];", "sat_add = s[CNT_W-1:0];",
       "counters wrap instead of saturating", [("bank", "b4_cnt5"), ("bank", "b2_cnt5")]),
    M("P04", "perf", PERF, "end else if (clear) begin\n        cycles <= '0; access <= '0; ok <= '0; err <= '0; conflict <= '0; stall <= '0;\n        busy <= '0; idle <= '0; err_range <= '0; err_align <= '0; hist <= '0;",
       "end else if (clear) begin\n        cycles <= '0; access <= '0; ok <= '0; err <= '0; conflict <= '0; stall <= '0;\n        busy <= '0; idle <= '0; err_range <= '0; err_align <= '0;",
       "perf_clear leaves the histogram", [B4]),
    M("P05", "perf", TOP, "if (rej[p] && d_ecode[p*2 +: 2] == `SF_SRAM_BANK_ERR_RANGE) n_range = n_range + INC_W'(1);", "if (rej[p]) n_range = n_range + INC_W'(1);",
       "every rejected request counted as RANGE", [("bank", "b4_strict_xor"), ("bank", "b4_awx2")]),
    M("P06", "perf", TOP, ".ev_busy(r_busy)", ".ev_busy(ev_access)",
       "busy counter counts accesses only", [B4]),
    M("P07", "perf", PERF, "cycles    <= sat_add(cycles, one(1'b1));", "cycles    <= sat_add(cycles, one(|ev_access));",
       "cycle counter counts only active cycles", [B4]),
    M("P08", "perf", PERF, "access[b*CNT_W +: CNT_W]   <= sat_add(access[b*CNT_W +: CNT_W],   one(ev_access[b]));", "access[b*CNT_W +: CNT_W]   <= sat_add(access[b*CNT_W +: CNT_W],   one(ev_ok[b]));",
       "access counter counts completions", [B4]),
    # ------------------------------------------------------------------ misc
    M("X01", "misc", TOP, "assign req_ready = ~lose & {NUM_PORTS{rst_n}};", "assign req_ready = ~lose;",
       "lanes ready during reset", [B4]),
]


def cfg_by_name(kind: str, name: str) -> dict:
    table = {"bank": CONFIGS, "array": ARRAY_CONFIGS, "decode": DECODE_CONFIGS}[kind]
    for c in table:
        if c["name"] == name:
            return c
    raise KeyError((kind, name))


def build_and_run(tag: str, kind: str, name: str, rtl_dir: Path, seed: int = 1) -> dict:
    c = cfg_by_name(kind, name)
    out = BUILD / "mut" / tag / f"{kind}_{name}"
    if kind == "bank":
        top, tbf, args = "tb_sf_sram_bank", [SYS_TB], [f"+seed={seed}", "+nrand=1500", "+nowl"]
    elif kind == "array":
        top, tbf, args = "tb_sf_sram_bank_array", [ARR_TB], [f"+seed={seed}", "+ncyc=3000"]
    else:
        top, tbf, args = "tb_sf_sram_bank_addr_decode", [DEC_TB], [f"+seed={seed}"]
    if kind == "decode":
        files = [rtl_dir / "sf_sram_bank_addr_decode.sv", rtl_dir / "sf_sram_bank_addr_unmap.sv"]
    elif kind == "array":
        files = [*rtl_files(rtl_dir)[:2], rtl_dir / "sf_sram_bank_array.sv"]
    else:
        files = None
    params = dict(c["p"])
    b = build_sim("ic", top, tbf, rtl_dir, params, out, extra_rtl=files, timeout=900)
    if b["rc"] != 0:
        return {"result": "BUILD_FAIL", "log": b["out"][-600:]}
    r = run_sim("ic", b["exe"], args, timeout=900)
    cleanup_build(out)
    if r["rc"] != 0 and r["result"] == "NO_RESULT":
        r["result"] = "CRASH"           # an uncaught $fatal / assertion also counts as the testbench noticing the bug
    return r


def apply_patch(m: dict, dst: Path) -> str | None:
    f = dst / m["file"]
    s = f.read_text()
    n = s.count(m["old"])
    if n != m["count"]:
        return f"patch text found {n}x, expected {m['count']}x"
    f.write_text(s.replace(m["old"], m["new"]))
    return None


def run_mutant(m: dict) -> dict:
    tag = m["id"]
    dst = BUILD / "mut" / tag / "rtl"
    if dst.parent.exists():
        shutil.rmtree(dst.parent)
    shutil.copytree(RTL, dst)
    err = apply_patch(m, dst)
    if err:
        return {"id": tag, "status": "INVALID", "why": err, **{k: m[k] for k in ("group", "desc")}, "runs": []}
    runs, killed_by, invalid = [], [], False
    for kind, name in m["runs"]:
        r = build_and_run(tag, kind, name, dst)
        verdict = r["result"]
        runs.append({"tb": kind, "cfg": name, "result": verdict})
        if verdict in ("FAIL", "CRASH"):
            killed_by.append(f"{kind}:{name}")
        elif verdict == "BUILD_FAIL":
            invalid = True
            runs[-1]["log"] = r.get("log", "")
    status = "KILLED" if killed_by else ("INVALID" if invalid else "SURVIVED")
    return {"id": tag, "status": status, "group": m["group"], "desc": m["desc"], "runs": runs, "killed_by": killed_by}


def baseline(pairs: list[tuple[str, str]], jobs: int) -> list[dict]:
    def one(p):
        kind, name = p
        r = build_and_run("baseline", kind, name, RTL)
        return {"tb": kind, "cfg": name, "result": r["result"], "checks": r.get("checks", 0)}
    with ThreadPoolExecutor(jobs) as ex:
        return list(ex.map(one, pairs))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--group", default="all")
    ap.add_argument("--ids", default="")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--gate", action="store_true", help="write reports/gate.json from the conflict group")
    ap.add_argument("--out", default="mutants")
    a = ap.parse_args()

    sel = MUTANTS
    if a.group != "all":
        groups = set(a.group.split(","))
        sel = [m for m in sel if m["group"] in groups]
    if a.ids:
        ids = set(a.ids.split(","))
        sel = [m for m in sel if m["id"] in ids]
    pairs = sorted({p for m in sel for p in m["runs"]})
    print(f"baseline: unmutated RTL on {len(pairs)} (testbench, configuration) pairs")
    base = baseline(pairs, a.jobs)
    for b in base:
        print(f"  {b['tb']:6s} {b['cfg']:22s} {b['result']}  checks={b['checks']}")
    if any(b["result"] != "PASS" for b in base):
        print("ABORT: the unmutated RTL must pass every pair used by the mutants")
        return 2

    results = []
    with ThreadPoolExecutor(a.jobs) as ex:
        for r in ex.map(run_mutant, sel):
            results.append(r)
            print(f"  {r['id']}  {r['status']:9s} [{r['group']}] {r['desc']}" + (f"  <- {', '.join(r['killed_by'])}" if r.get("killed_by") else "")
                  + (f"  ({r.get('why')})" if r.get("why") else ""))
    killed = sum(r["status"] == "KILLED" for r in results)
    surv = [r["id"] for r in results if r["status"] == "SURVIVED"]
    inval = [r["id"] for r in results if r["status"] == "INVALID"]
    print(f"MUTANT_RESULT killed={killed} survived={len(surv)} invalid={len(inval)} of {len(results)}")
    write_json(REPORTS / f"{a.out}.json", {"provenance": provenance(), "baseline": base, "results": results,
                                            "killed": killed, "survived": surv, "invalid": inval, "total": len(results)})
    lines = ["# Mutation sanity", "",
             f"{killed} killed / {len(surv)} survived / {len(inval)} invalid of {len(results)} injected RTL bugs.", "",
             "| id | group | status | what was broken | killed by |", "|---|---|---|---|---|"]
    for r in results:
        lines.append(f"| {r['id']} | {r['group']} | {r['status']} | {r['desc']} | {', '.join(r.get('killed_by', [])) or '-'} |")
    (REPORTS / f"{a.out}.md").write_text("\n".join(lines) + "\n")

    if a.gate:
        conf = [r for r in results if r["group"] == "conflict"]
        ok = bool(conf) and all(r["status"] == "KILLED" for r in conf)
        # require the kill on BOTH the 2-bank and 4-bank runs wherever both were listed
        need = {m["id"]: m["runs"] for m in MUTANTS if m["group"] == "conflict"}
        per_run_ok = True
        for r in conf:
            for run in r["runs"]:
                if run["result"] not in ("FAIL", "CRASH") and (run["tb"], run["cfg"]) in need[r["id"]]:
                    per_run_ok = False
        write_json(REPORTS / "gate.json", {"provenance": provenance(), "conflict_gate": "PASS" if ok and per_run_ok else "FAIL",
                                           "mutants": [{"id": r["id"], "status": r["status"], "runs": r["runs"]} for r in conf]})
        print("GATE conflict_gate=" + ("PASS" if ok and per_run_ok else "FAIL"))
        return 0 if ok and per_run_ok else 1
    return 0 if not surv and not inval else 1


if __name__ == "__main__":
    sys.exit(main())
