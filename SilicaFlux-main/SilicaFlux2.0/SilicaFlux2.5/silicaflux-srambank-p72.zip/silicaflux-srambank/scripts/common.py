"""Shared helpers for the SRAMBank scripts: paths, tool versions, configuration tables, build/run helpers with
provenance (every report records commands, exit codes and tool versions).  Python >= 3.10, standard library only."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "rtl/bank"
TB = ROOT / "tb/bank"
TP = ROOT / "third_party/silicaflux-sramcore"
BUILD = Path(os.environ.get("SRAMBANK_BUILD", ROOT / "build"))      # override for a guaranteed-clean run
REPORTS = ROOT / "reports"
BUILD.mkdir(parents=True, exist_ok=True)                           # a fresh SRAMBANK_BUILD directory must work
REPORTS.mkdir(parents=True, exist_ok=True)
MODEL = ROOT / "model/sf_bank_map.py"

CORE_FILES = [TP / "rtl/sram/sf_sram_array.sv", TP / "rtl/sram/sf_sram_core.sv"]
BANK_FILES = ["sf_sram_bank_addr_decode.sv", "sf_sram_bank_addr_unmap.sv", "sf_sram_bank_perf.sv", "sf_sram_bank_array.sv", "sf_sram_bank.sv"]

VL_SIM_FLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "--assert", "-DSF_SRAM_POISON",
                "--x-assign", "unique", "--x-initial", "unique", "-Wno-fatal", "-Wno-DECLFILENAME",
                "-Wno-MULTITOP", "-Wno-UNUSEDSIGNAL", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-Wno-UNUSEDPARAM"]


def rtl_files(rtl_dir: Path = RTL) -> list[Path]:
    return [*CORE_FILES, *(rtl_dir / f for f in BANK_FILES)]


def inc_dirs(rtl_dir: Path = RTL) -> list[Path]:
    return [rtl_dir, TP / "rtl/sram", TP / "tb/mem"]


# ------------------------------------------------------------------------------------------------ configurations
# Parameters are the TB parameter names of tb_sf_sram_bank:
#   NB NP DW BW D MAP(0 SEQ,1 BLOCK,2 XOR) BLK STRICT LAT WACK IDW INITM AWX NRAND CNTW
# "seeds": regression seeds; "ic": also run in Icarus; "stage": 2 / 4 / 8 (8 and 16 banks) / x (extra, non-power-of-two)
def C(name, stage, seeds=(1,), ic=False, nrand=4000, **p):
    return dict(name=name, stage=stage, p=p, seeds=list(seeds), ic=ic, nrand=nrand)


CONFIGS = [
    # ---- stage 2: TWO banks
    C("b2_seq",        2, (1, 2), True,  NB=2, NP=2),
    C("b2_block4",     2, (1,), False,   NB=2, NP=2, MAP=1, BLK=4),
    C("b2_contig",     2, (1,), False,   NB=2, NP=2, MAP=1, BLK=256),
    C("b2_xor",        2, (1,), True,    NB=2, NP=2, MAP=2),
    C("b2_xor8_w64",   2, (1,), False,   NB=2, NP=2, MAP=2, BLK=8, DW=64),
    C("b2_strict",     2, (1,), False,   NB=2, NP=2, STRICT=1),
    C("b2_lat2",       2, (1,), True,    NB=2, NP=2, LAT=2),
    C("b2_lat3_noack", 2, (1,), False,   NB=2, NP=2, LAT=3, WACK=0),
    C("b2_awx3",       2, (1,), True,    NB=2, NP=2, AWX=3),
    C("b2_np1",        2, (1,), False,   NB=2, NP=1),
    C("b2_np3",        2, (1,), False,   NB=2, NP=3),
    C("b2_zero",       2, (1,), False,   NB=2, NP=2, INITM=1),
    C("b2_pattern_xor",2, (1,), False,   NB=2, NP=2, INITM=3, MAP=2),
    C("b2_d300",       2, (1,), False,   NB=2, NP=2, D=300),
    C("b2_cnt5",       2, (1,), False,   NB=2, NP=2, CNTW=5),
    C("b2_awx3_posted",2, (1,), True,    NB=2, NP=2, AWX=3, WACK=0, LAT=2),          # invalid addresses + posted writes + latency 2
    # ---- stage 4: FOUR banks (the validation target)
    C("b4_seq",        4, (1, 2, 3), True, NB=4, NP=4),
    C("b4_block4",     4, (1,), False,   NB=4, NP=4, MAP=1, BLK=4),
    C("b4_contig",     4, (1,), True,    NB=4, NP=4, MAP=1, BLK=256),
    C("b4_xor",        4, (1, 2), True,  NB=4, NP=4, MAP=2),
    C("b4_xor8_w64",   4, (1,), False,   NB=4, NP=4, MAP=2, BLK=8, DW=64),
    C("b4_strict_xor", 4, (1,), False,   NB=4, NP=4, STRICT=1, MAP=2),
    C("b4_lat2",       4, (1,), True,    NB=4, NP=4, LAT=2),
    C("b4_lat3_noack", 4, (1,), False,   NB=4, NP=4, LAT=3, WACK=0),
    C("b4_awx2",       4, (1,), False,   NB=4, NP=4, AWX=2),
    C("b4_np6",        4, (1,), False,   NB=4, NP=6),
    C("b4_np2",        4, (1,), False,   NB=4, NP=2),
    C("b4_d1000",      4, (1,), False,   NB=4, NP=4, D=1000, nrand=3000),
    C("b4_pattern",    4, (1,), False,   NB=4, NP=4, INITM=3),
    C("b4_bw9",        4, (1,), False,   NB=4, NP=4, DW=72, BW=9, D=64),
    C("b4_cnt5",       4, (1,), True,    NB=4, NP=4, CNTW=5),
    C("b4_awx2_lat3",  4, (1,), True,    NB=4, NP=4, AWX=2, LAT=3),                  # rejected requests must also be answered at latency 3
    C("b4_strict_posted", 4, (1,), False, NB=4, NP=4, STRICT=1, WACK=0, LAT=2, AWX=1, MAP=1, BLK=4),   # ALIGN + RANGE errors on posted writes
    # ---- stage 8: EIGHT and SIXTEEN banks (only after the conflict gate passed on 2 and 4 banks)
    C("b8_seq",        8, (1, 2), True,  NB=8, NP=8),
    C("b8_block8",     8, (1,), False,   NB=8, NP=8, MAP=1, BLK=8),
    C("b8_xor",        8, (1,), False,   NB=8, NP=8, MAP=2),
    C("b8_lat2",       8, (1,), False,   NB=8, NP=8, LAT=2),
    C("b8_np12",       8, (1,), False,   NB=8, NP=12),
    C("b8_np3",        8, (1,), False,   NB=8, NP=3),
    C("b8_d96_block32",8, (1,), False,   NB=8, NP=8, D=96, MAP=1, BLK=32),
    C("b16_seq",      8, (1, 2), True,  NB=16, NP=16),
    C("b16_xor",      8, (1,), True,    NB=16, NP=16, MAP=2),
    C("b16_block4",   8, (1,), False,   NB=16, NP=16, MAP=1, BLK=4),
    C("b16_strict",   8, (1,), False,   NB=16, NP=16, STRICT=1),
    C("b16_np4",      8, (1,), False,   NB=16, NP=4),
    C("b16_np20",     8, (1,), False,   NB=16, NP=20),
    C("b16_w64_lat2", 8, (1,), False,   NB=16, NP=16, DW=64, LAT=2, D=128),
    # ---- extra: non-power-of-two bank counts (SEQ / BLOCK use the generic divider branch)
    C("x_b3_seq",      "x", (1,), True,  NB=3, NP=3, D=100),
    C("x_b5_seq",      "x", (1,), False, NB=5, NP=5, D=64),
    C("x_b6_block8",   "x", (1,), False, NB=6, NP=6, D=128, MAP=1, BLK=8),
    C("x_b12_block4",  "x", (1,), False, NB=12, NP=12, D=64, MAP=1, BLK=4),
]

# per-bank interface testbench (sf_sram_bank_array): parameters of tb_sf_sram_bank_array
ARRAY_CONFIGS = [
    dict(name="a1",          p=dict(NB=1),                               ic=False),
    dict(name="a2",          p=dict(NB=2),                               ic=False),
    dict(name="a4",          p=dict(NB=4),                               ic=True),
    dict(name="a8",          p=dict(NB=8),                               ic=False),
    dict(name="a16",         p=dict(NB=16),                              ic=False),
    dict(name="a4_d100",     p=dict(NB=4, D=100),                        ic=True),
    dict(name="a4_lat2",     p=dict(NB=4, LAT=2),                        ic=False),
    dict(name="a4_lat3",     p=dict(NB=4, LAT=3),                        ic=True),
    dict(name="a4_lat3_na",  p=dict(NB=4, LAT=3, WACK=0),                ic=False),
    dict(name="a4_d100_l2na",p=dict(NB=4, D=100, LAT=2, WACK=0),         ic=False),
    dict(name="a4_dw64",     p=dict(NB=4, DW=64),                        ic=False),
    dict(name="a4_bw9",      p=dict(NB=4, DW=72, BW=9),                  ic=False),
    dict(name="a4_pattern",  p=dict(NB=4, INITM=3),                      ic=False),
    dict(name="a4_idw1",     p=dict(NB=4, IDW=1),                        ic=False),
]

# decoder testbench: NB D BPW MODE BLK STRICT [AW]
DECODE_CONFIGS = [
    dict(name=f"d{nb}_{mn}", p=dict(NB=nb, D=d, BPW=bpw, MODE=mode, BLK=blk, STRICT=st, **({"AW": aw} if aw else {})), ic=ic)
    for nb in (2, 4, 8, 16)
    for (mn, d, bpw, mode, blk, st, aw, ic) in [
        ("seq", 256, 4, 0, 1, 0, 0, nb in (2, 4)),
        ("blk4", 256, 4, 1, 4, 0, 0, False),
        ("contig", 256, 8, 1, 256, 0, 0, False),
        ("xor", 256, 4, 2, 1, 0, 0, nb in (2, 4)),
        ("xor8_b8", 256, 8, 2, 8, 0, 0, False),
        ("strict", 256, 4, 2, 2, 1, 0, False),
        ("d1000_blk8", 1000, 4, 1, 8, 0, 0, False),
        ("wide", 256, 4, 0, 1, 0, 20, False),
        ("wide_strict_xor", 128, 4, 2, 2, 1, 18, False),
        ("bpw1", 256, 1, 0, 1, 0, 0, False),
    ]
] + [
    dict(name=f"dx_b{nb}_{mn}", p=dict(NB=nb, D=d, BPW=bpw, MODE=mode, BLK=blk, STRICT=0), ic=(nb == 3))
    for (nb, mn, d, bpw, mode, blk) in [(3, "seq", 100, 4, 0, 1), (5, "seq", 64, 4, 0, 1), (6, "blk16", 128, 8, 1, 16),
                                         (7, "seq", 32, 4, 0, 1), (12, "blk4", 64, 4, 1, 4)]
]

# illegal parameterisations: (name, DUT module, parameter overrides, expected message fragment)
NEGATIVE = [
    ("banks_1",              "sf_sram_bank_addr_decode", dict(NUM_BANKS=1),                                       "NUM_BANKS must be in 2..64"),
    ("banks_65",             "sf_sram_bank_addr_decode", dict(NUM_BANKS=65, BANK_DEPTH=16),                       "NUM_BANKS must be in 2..64"),
    ("depth_1",              "sf_sram_bank_addr_decode", dict(BANK_DEPTH=1),                                      "BANK_DEPTH must be >= 2"),
    ("bpw_3",                "sf_sram_bank_addr_decode", dict(BYTES_PER_WORD=3),                                  "power of two"),
    ("map_mode_7",           "sf_sram_bank_addr_decode", dict(MAP_MODE=7),                                        "MAP_MODE must be"),
    ("block_words_3",        "sf_sram_bank_addr_decode", dict(MAP_MODE=1, BLOCK_WORDS=3),                         "BLOCK_WORDS must be a power of two"),
    ("block_words_0",        "sf_sram_bank_addr_decode", dict(MAP_MODE=1, BLOCK_WORDS=0),                         "BLOCK_WORDS must be a power of two"),
    ("block_not_divisor",    "sf_sram_bank_addr_decode", dict(MAP_MODE=1, BLOCK_WORDS=64, BANK_DEPTH=96),         "must divide BANK_DEPTH"),
    ("block_over_depth",     "sf_sram_bank_addr_decode", dict(MAP_MODE=1, BLOCK_WORDS=512, BANK_DEPTH=256),       "must divide BANK_DEPTH"),
    ("xor_nonpow2_banks",    "sf_sram_bank_addr_decode", dict(MAP_MODE=2, NUM_BANKS=3),                           "requires a power-of-two NUM_BANKS"),
    ("strict_2",             "sf_sram_bank_addr_decode", dict(STRICT_ALIGN=2),                                    "STRICT_ALIGN must be 0 or 1"),
    ("addr_width_small",     "sf_sram_bank_addr_decode", dict(ADDR_WIDTH=10),                                     "ADDR_WIDTH must be in"),
    ("addr_width_33",        "sf_sram_bank_addr_decode", dict(ADDR_WIDTH=33),                                     "ADDR_WIDTH must be in"),
    ("capacity_over_2_24",   "sf_sram_bank_addr_decode", dict(NUM_BANKS=64, BANK_DEPTH=1 << 20),                  "<= 2**24"),
    ("top_ports_0",          "sf_sram_bank",        dict(NUM_PORTS=0),                                       "NUM_PORTS must be in 1..32"),
    ("top_ports_33",         "sf_sram_bank",        dict(NUM_PORTS=33),                                      "NUM_PORTS must be in 1..32"),
    ("top_lanes_not_pow2",   "sf_sram_bank",        dict(DATA_WIDTH=24),                                     "power of two"),
    ("top_xor_nonpow2",      "sf_sram_bank",        dict(MAP_MODE=2, NUM_BANKS=6, NUM_PORTS=2),              "requires a power-of-two NUM_BANKS"),
    ("top_write_ack_2",      "sf_sram_bank",        dict(WRITE_ACK=2),                                       "WRITE_ACK must be 0 or 1"),
    ("top_id_width_0",       "sf_sram_bank",        dict(ID_WIDTH=0),                                        "ID_WIDTH must be >= 1"),
    ("top_core_latency_0",   "sf_sram_bank",        dict(READ_LATENCY=0),                                    "READ_LATENCY must be >= 1"),
    ("array_banks_0",        "sf_sram_bank_array",  dict(NUM_BANKS=0),                                       "NUM_BANKS must be >= 1"),
    ("perf_cnt_w_1",         "sf_sram_bank_perf",   dict(CNT_W=1),                                           "CNT_W must be in 2..64"),
]


# ------------------------------------------------------------------------------------------------ process helpers
def sh(cmd, cwd=None, timeout=3600, env=None) -> dict:
    t0 = time.time()
    try:
        p = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        rc, out = p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        rc = -9
        out = "TIMEOUT after %ss\n%s" % (timeout, e.stdout.decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or ""))
    return {"cmd": " ".join(str(c) for c in cmd), "rc": rc, "out": out, "secs": round(time.time() - t0, 2)}


def tool_versions() -> dict:
    def first_line(cmd):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return (r.stdout + r.stderr).strip().splitlines()[0]
        except Exception:
            return "NOT INSTALLED"
    return {
        "verilator": first_line(["verilator", "--version"]),
        "iverilog": first_line(["iverilog", "-V"]),
        "yosys": first_line(["yosys", "-V"]),
        "python": platform.python_version(),
        "vivado": "NOT INSTALLED" if not shutil.which("vivado") else "present",
        "quartus": "NOT INSTALLED" if not shutil.which("quartus_sh") else "present",
        "openroad": "NOT INSTALLED" if not shutil.which("openroad") else "present",
    }


def src_hash(files) -> str:
    h = hashlib.sha256()
    for f in sorted(str(x) for x in files):
        h.update(f.encode().split(str(ROOT).encode())[-1])
        h.update(Path(f).read_bytes())
    return h.hexdigest()


def provenance(extra=None) -> dict:
    d = {"generated": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
         "tools": tool_versions(),
         "rtl_sha256": src_hash([*RTL.glob("*.sv"), *RTL.glob("*.svh")])}
    if extra:
        d.update(extra)
    return d


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, sort_keys=False) + "\n")


# ------------------------------------------------------------------------------------------------ build / run
def build_sim(sim: str, top: str, tb_files, rtl_dir: Path, params: dict, outdir: Path, extra_defs=(), jobs: int = 2,
              extra_rtl=None, timeout=1800) -> dict:
    """Compile a testbench with Verilator (sim='vl') or Icarus ('ic').  Returns {'exe', 'rc', 'out', 'cmd'}."""
    outdir.mkdir(parents=True, exist_ok=True)
    files = [*(extra_rtl if extra_rtl is not None else rtl_files(rtl_dir)), *tb_files]
    inc = [f"-I{d}" for d in inc_dirs(rtl_dir)]
    defs = [f"-D{d}" for d in extra_defs]
    if sim == "ic":
        exe = outdir / "sim.vvp"
        pv = [f"-P{top}.{k}={v}" for k, v in params.items()]
        r = sh(["iverilog", "-g2012", "-Wall", *inc, *defs, *pv, "-s", top, "-o", exe, *files], timeout=timeout)
        # a build that printed "error" / "sorry" did not produce a faithful model
        bad = re.search(r"\berror\b|sorry:", r["out"], re.I)
        if r["rc"] == 0 and bad:
            r["rc"] = 1
        r["exe"] = exe
        return r
    exe = outdir / "obj/sim"
    pv = [f"-G{k}={v}" for k, v in params.items()]
    r = sh(["verilator", *VL_SIM_FLAGS, *inc, *defs, *pv, "--top-module", top, "-Mdir", outdir / "obj", *files, "-o", "sim", "-j", str(jobs)],
           timeout=timeout)
    r["exe"] = exe
    return r


def cleanup_build(outdir: Path) -> None:
    """Delete the compiled testbench of one configuration (Verilator object directory / Icarus vvp) after it ran: a full
    regression otherwise leaves ~14 GB of object files behind."""
    shutil.rmtree(outdir / "obj", ignore_errors=True)
    try:
        (outdir / "sim.vvp").unlink()
    except OSError:
        pass


def run_sim(sim: str, exe: Path, plusargs=(), timeout=1800) -> dict:
    cmd = ["vvp", "-n", exe, *plusargs] if sim == "ic" else [exe, *plusargs]
    r = sh(cmd, timeout=timeout)
    m = re.search(r"SRAM_RESULT (PASS|FAIL) tb=(\S+) seed=(\d+) checks=(\d+) errors=(\d+)", r["out"])
    r["result"] = m.group(1) if m else "NO_RESULT"
    r["checks"] = int(m.group(4)) if m else 0
    r["errors"] = int(m.group(5)) if m else -1
    r["phases"] = re.findall(r"SRAM_PHASE (\S+)", r["out"])
    r["perf"] = re.findall(r"^SRAM_PERF .*$", r["out"], re.M)
    r["err_lines"] = re.findall(r"^SRAM_ERROR .*$", r["out"], re.M)[:5] + re.findall(r"^.*SF_SRAM_\w*ASSERT.*$", r["out"], re.M)[:5]
    return r
