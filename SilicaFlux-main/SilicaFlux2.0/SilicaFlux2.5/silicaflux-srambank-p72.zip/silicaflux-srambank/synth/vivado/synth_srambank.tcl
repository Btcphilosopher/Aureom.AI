# =============================================================================
# SilicaFlux SRAMBank (Project 72) -- Vivado out-of-context synthesis to CHECK THE REAL RAM MAPPING.
#
#   NOT RUN: no Vivado was available when this package was built.  The Yosys evidence in reports/synth.md is the only
#   inference evidence delivered; this script is how to confirm (or refute) it with the vendor tool.
#
#   vivado -mode batch -source synth/vivado/synth_srambank.tcl -tclargs <part> <NUM_BANKS> <BANK_DEPTH> [DATA_WIDTH] [MAP_MODE] [BLOCK_WORDS]
#   e.g.   vivado -mode batch -source synth/vivado/synth_srambank.tcl -tclargs xc7a100tcsg324-1 4 1024
#
# It prints (1) the block-RAM / distributed-RAM cell count, (2) one line per bank with the primitive it became,
# (3) the utilization report.  Expected from the brief, to be verified here: ONE memory block per logical bank where the
# device and the bank shape allow it; a shallow bank may legitimately become LUT RAM instead.  Clock period below is a
# placeholder for out-of-context synthesis only; no timing claim is made by this package.
# =============================================================================
set part  [lindex $argv 0]
set nb    [lindex $argv 1]
set depth [lindex $argv 2]
set dw    [expr {[llength $argv] > 3 ? [lindex $argv 3] : 32}]
set map   [expr {[llength $argv] > 4 ? [lindex $argv 4] : 0}]
set blk   [expr {[llength $argv] > 5 ? [lindex $argv 5] : 1}]
set root  [file normalize [file join [file dirname [info script]] ../..]]

read_verilog -sv [list \
  $root/third_party/silicaflux-sramcore/rtl/sram/sf_sram_array.sv \
  $root/third_party/silicaflux-sramcore/rtl/sram/sf_sram_core.sv \
  $root/rtl/bank/sf_sram_bank_addr_decode.sv $root/rtl/bank/sf_sram_bank_addr_unmap.sv $root/rtl/bank/sf_sram_bank_perf.sv \
  $root/rtl/bank/sf_sram_bank_array.sv $root/rtl/bank/sf_sram_bank.sv]
set_property include_dirs [list $root/rtl/bank $root/third_party/silicaflux-sramcore/rtl/sram] [current_fileset]

synth_design -top sf_sram_bank -part $part -mode out_of_context \
  -generic NUM_BANKS=$nb -generic NUM_PORTS=$nb -generic BANK_DEPTH=$depth -generic DATA_WIDTH=$dw \
  -generic MAP_MODE=$map -generic BLOCK_WORDS=$blk -generic PERF_EN=0
create_clock -name clk -period 10.0 [get_ports clk]        ;# placeholder, out-of-context only

set bram [get_cells -hier -filter {PRIMITIVE_TYPE =~ BMEM.*}]
set lram [get_cells -hier -filter {PRIMITIVE_TYPE =~ DMEM.*}]
puts "SRAMBANK_RESULT banks=$nb depth=$depth width=$dw block_ram_cells=[llength $bram] dist_ram_cells=[llength $lram]"
foreach c $bram { puts "  BRAM  [get_property REF_NAME $c]  $c" }
foreach c $lram { puts "  LUTRAM [get_property REF_NAME $c]  $c" }
report_utilization -file srambank_utilization.rpt
report_utilization
# Check by eye or script: the BRAM cell names contain g_bank[<b>]; each logical bank should own its own block(s).
