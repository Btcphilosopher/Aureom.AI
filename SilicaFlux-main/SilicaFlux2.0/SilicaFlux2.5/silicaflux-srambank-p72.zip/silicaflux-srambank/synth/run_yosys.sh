#!/usr/bin/env bash
# SilicaFlux SRAMBank (Project 72) -- one Yosys synthesis run of sf_sram_bank for a chosen target.
#   synth/run_yosys.sh <generic|xc7|ice40|ecp5> <NUM_BANKS> <BANK_DEPTH> [DATA_WIDTH=32] [MAP_MODE=0] [BLOCK_WORDS=1] [PERF_EN=1]
#   MAP_MODE: 0 SEQ, 1 BLOCK, 2 XOR.   Needs Yosys (0.33 tested).  NUM_PORTS = NUM_BANKS.
# Prints the memories Yosys inferred and the cell statistics.  Inference evidence only: this is not Vivado / Quartus,
# and the result is neither a timing nor an area-in-um2 figure.  scripts/run_synth.py runs the full matrix.
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
tgt="${1:?target: generic|xc7|ice40|ecp5}"; nb="${2:?NUM_BANKS}"; depth="${3:?BANK_DEPTH}"
dw="${4:-32}"; map="${5:-0}"; blk="${6:-1}"; perf="${7:-1}"
files="$here/third_party/silicaflux-sramcore/rtl/sram/sf_sram_array.sv $here/third_party/silicaflux-sramcore/rtl/sram/sf_sram_core.sv
       $here/rtl/bank/sf_sram_bank_addr_decode.sv $here/rtl/bank/sf_sram_bank_addr_unmap.sv $here/rtl/bank/sf_sram_bank_perf.sv
       $here/rtl/bank/sf_sram_bank_array.sv $here/rtl/bank/sf_sram_bank.sv"
# ONE chparam carrying every override, BEFORE hierarchy (Yosys 0.33)
cp="chparam -set NUM_BANKS $nb -set NUM_PORTS $nb -set BANK_DEPTH $depth -set DATA_WIDTH $dw -set MAP_MODE $map -set BLOCK_WORDS $blk -set PERF_EN $perf sf_sram_bank;"
case "$tgt" in
  generic) flow="synth -top sf_sram_bank -flatten -run :fine; check -assert; select -count t:\$mem_v2; stat" ;;
  xc7)     flow="synth_xilinx -family xc7 -flatten -top sf_sram_bank; stat" ;;
  ice40)   flow="synth_ice40 -flatten -top sf_sram_bank; stat" ;;
  ecp5)    flow="synth_ecp5 -top sf_sram_bank; stat" ;;
  *) echo "unknown target $tgt" >&2; exit 2 ;;
esac
yosys -p "read_verilog -sv -I$here/rtl/bank -I$here/third_party/silicaflux-sramcore/rtl/sram $files; $cp hierarchy -check -top sf_sram_bank; $flow" 2>&1 \
  | grep -E "mem_v2|RAMB|RAM32M|RAM64M|SB_RAM40|DP16KD|LUT|FDRE|FDCE|CARRY|SB_DFF|Number of cells|objects|ERROR|Warning" || true
