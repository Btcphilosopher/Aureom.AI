# Regression `regression_s816`

Total: 34 records, 0 not passing, 104,207,919 scoreboard checks.

| suite | pass | not pass |
|---|---|---|
| bank8-16 | 21 | 0 |
| bank8-16-xsim | 5 | 0 |
| bank8-16-coverage | 1 | 0 |
| bank-nonpow2 | 5 | 0 |
| bank-nonpow2-xsim | 1 | 0 |
| bank-nonpow2-coverage | 1 | 0 |

## Records

| suite | config | tool | seed | result | checks | notes |
|---|---|---|---|---|---|---|
| bank8-16 | b8_seq | vl | 1 | PASS | 2128337 |  |
| bank8-16 | b8_seq | vl | 2 | PASS | 2115008 |  |
| bank8-16 | b8_seq | ic | 1 | PASS | 2128337 |  |
| bank8-16 | b8_seq | ic | 2 | PASS | 2115008 |  |
| bank8-16-xsim | b8_seq | vl==ic | 1 | PASS |  |  |
| bank8-16-xsim | b8_seq | vl==ic | 2 | PASS |  |  |
| bank8-16 | b8_block8 | vl | 1 | PASS | 2088841 |  |
| bank8-16 | b8_xor | vl | 1 | PASS | 2082393 |  |
| bank8-16 | b8_lat2 | vl | 1 | PASS | 2139589 |  |
| bank8-16 | b8_np12 | vl | 1 | PASS | 2391191 |  |
| bank8-16 | b8_np3 | vl | 1 | PASS | 2203643 |  |
| bank8-16 | b8_d96_block32 | vl | 1 | PASS | 1043305 |  |
| bank8-16 | b16_seq | vl | 1 | PASS | 7507580 |  |
| bank8-16 | b16_seq | vl | 2 | PASS | 7494015 |  |
| bank8-16 | b16_seq | ic | 1 | PASS | 7507580 |  |
| bank8-16 | b16_seq | ic | 2 | PASS | 7494015 |  |
| bank8-16-xsim | b16_seq | vl==ic | 1 | PASS |  |  |
| bank8-16-xsim | b16_seq | vl==ic | 2 | PASS |  |  |
| bank8-16 | b16_xor | vl | 1 | PASS | 7416196 |  |
| bank8-16 | b16_xor | ic | 1 | PASS | 7416196 |  |
| bank8-16-xsim | b16_xor | vl==ic | 1 | PASS |  |  |
| bank8-16 | b16_block4 | vl | 1 | PASS | 7432056 |  |
| bank8-16 | b16_strict | vl | 1 | PASS | 7450855 |  |
| bank8-16 | b16_np4 | vl | 1 | PASS | 7505620 |  |
| bank8-16 | b16_np20 | vl | 1 | PASS | 8124949 |  |
| bank8-16 | b16_w64_lat2 | vl | 1 | PASS | 4880573 |  |
| bank8-16-coverage | stage 8 | run_regress |  | PASS |  |  |
| bank-nonpow2 | x_b3_seq | vl | 1 | PASS | 345337 |  |
| bank-nonpow2 | x_b3_seq | ic | 1 | PASS | 345337 |  |
| bank-nonpow2-xsim | x_b3_seq | vl==ic | 1 | PASS |  |  |
| bank-nonpow2 | x_b5_seq | vl | 1 | PASS | 489158 |  |
| bank-nonpow2 | x_b6_block8 | vl | 1 | PASS | 868256 |  |
| bank-nonpow2 | x_b12_block4 | vl | 1 | PASS | 1494544 |  |
| bank-nonpow2-coverage | stage x | run_regress |  | PASS |  |  |
