# Mutation sanity

53 killed / 0 survived / 0 invalid of 53 injected RTL bugs.

| id | group | status | what was broken | killed by |
|---|---|---|---|---|
| C01 | conflict | KILLED | highest lane index wins instead of the lowest | bank:b2_seq, bank:b4_seq |
| C02 | conflict | KILLED | losing lane is never marked denied | bank:b2_seq, bank:b4_seq |
| C03 | conflict | KILLED | req_ready ignores the interlock: a denied lane believes it was accepted | bank:b2_seq, bank:b4_seq |
| C04 | conflict | KILLED | conflict event needs three requesters instead of two | bank:b2_seq, bank:b4_seq |
| C05 | conflict | KILLED | stall count is requesters, not requesters-1 | bank:b2_seq, bank:b4_seq |
| C06 | conflict | KILLED | bank writes lane 0's data whichever lane won | bank:b4_seq |
| C07 | conflict | KILLED | bank uses lane 0's byte enables whichever lane won | bank:b4_seq |
| C08 | conflict | KILLED | bank uses lane 0's write enable whichever lane won | bank:b4_seq |
| C09 | conflict | KILLED | rejected (invalid) requests enter the bank interlock | bank:b2_awx3, bank:b4_awx2 |
| C10 | conflict | KILLED | per-bank conflict status stuck low | bank:b2_seq, bank:b4_seq |
| C11 | conflict | KILLED | on a collision nobody is granted (all lanes denied) | bank:b2_seq, bank:b4_seq |
| C12 | conflict | KILLED | conflict counter never counts | bank:b2_seq, bank:b4_seq |
| C13 | conflict | KILLED | stall counter never counts | bank:b2_seq, bank:b4_seq |
| C14 | conflict | KILLED | bank address taken from lane 0 whichever lane won | bank:b4_seq |
| M01 | map | KILLED | bank-select mask one bit short | decode:d4_seq, bank:b4_seq |
| M02 | map | KILLED | row index drops a bit: two words alias | decode:d4_seq, bank:b4_seq |
| M03 | map | KILLED | XOR skew disabled | decode:d4_xor, bank:b4_xor |
| M04 | map | KILLED | off-by-one in the range check (non-power-of-two capacity) | decode:d4_d1000_blk8, bank:b4_d1000 |
| M05 | map | KILLED | high address bits ignored: out-of-range addresses alias | decode:d4_wide, bank:b4_awx2 |
| M06 | map | KILLED | STRICT_ALIGN ignored (always strict) | decode:d4_seq, bank:b4_seq |
| M07 | map | KILLED | ALIGN takes priority over RANGE | decode:d4_wide_strict_xor |
| M08 | map | KILLED | intra-block offset mask wrong | decode:d4_blk4, bank:b4_block4 |
| M09 | map | KILLED | intra-block offset dropped from the local address | decode:d4_blk4, bank:b4_block4 |
| M10 | map | KILLED | byte offset taken from the wrong address bits | decode:d4_seq, bank:b4_strict_xor |
| M11 | map | KILLED | generic (non-power-of-two) branch: bank = quotient | decode:dx_b3_seq |
| M12 | map | KILLED | generic (non-power-of-two) branch: row = remainder | decode:dx_b5_seq |
| M13 | map | KILLED | inverse mapping drops the bank | decode:d4_seq |
| R01 | resp | KILLED | transaction ID not forwarded to the bank | bank:b4_seq |
| R02 | resp | KILLED | every response is routed to lane 0 | bank:b4_seq |
| R03 | resp | KILLED | error response of a posted write is dropped | bank:b4_strict_posted, bank:b2_awx3_posted |
| R04 | resp | KILLED | read data leaks onto write acknowledgements | bank:b4_seq |
| R05 | resp | KILLED | rejected-request response not aligned to READ_LATENCY | bank:b4_awx2_lat3, bank:b4_strict_posted |
| R06 | resp | KILLED | error code inverted | bank:b4_awx2 |
| R07 | resp | KILLED | rejected write reported as a read response | bank:b4_awx2 |
| R08 | resp | KILLED | response ID taken from the lane-index field | bank:b4_seq |
| A01 | array | KILLED | posted writes are acknowledged | array:a4_lat3_na, bank:b4_lat3_noack |
| A02 | array | KILLED | ID pipeline: later stages reload stage 0 (equivalent at latency 2: needs 3) | array:a4_lat3 |
| A03 | array | KILLED | busy ignores operations in the read pipeline | array:a4, bank:b4_seq |
| A04 | array | KILLED | completion event raised at issue instead of at the response | array:a4, bank:b4_seq |
| A05 | array | KILLED | bank ready during reset | array:a4, bank:b4_seq |
| A06 | array | KILLED | in-flight responses survive reset | array:a4, bank:b4_seq |
| A07 | array | KILLED | write-error flag lost in the latency pipeline | array:a4_d100_l2na |
| A08 | array | KILLED | invalid-address writes are not reported | array:a4_d100 |
| A09 | array | KILLED | access event ignores reset | array:a4 |
| P01 | perf | KILLED | concurrency histogram shifted by one | bank:b4_seq |
| P02 | perf | KILLED | idle counter counts busy cycles | bank:b4_seq |
| P03 | perf | KILLED | counters wrap instead of saturating | bank:b4_cnt5, bank:b2_cnt5 |
| P04 | perf | KILLED | perf_clear leaves the histogram | bank:b4_seq |
| P05 | perf | KILLED | every rejected request counted as RANGE | bank:b4_strict_xor |
| P06 | perf | KILLED | busy counter counts accesses only | bank:b4_seq |
| P07 | perf | KILLED | cycle counter counts only active cycles | bank:b4_seq |
| P08 | perf | KILLED | access counter counts completions | bank:b4_seq |
| X01 | misc | KILLED | lanes ready during reset | bank:b4_seq |
