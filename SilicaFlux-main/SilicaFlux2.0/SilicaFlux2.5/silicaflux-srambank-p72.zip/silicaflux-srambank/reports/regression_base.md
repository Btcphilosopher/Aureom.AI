# Regression `regression_base`

Total: 190 records, 0 not passing, 7,948,298 scoreboard checks.

| suite | pass | not pass |
|---|---|---|
| lint | 48 | 0 |
| neg | 69 | 0 |
| decode | 50 | 0 |
| array | 19 | 0 |
| array-xsim | 4 | 0 |

## Records

| suite | config | tool | seed | result | checks | notes |
|---|---|---|---|---|---|---|
| lint | sf_sram_bank | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=2,NUM_PORTS=2 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=2,NUM_PORTS=2 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=4,NUM_PORTS=1 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=4,NUM_PORTS=1 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=8,NUM_PORTS=8,READ_LATENCY=2 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=8,NUM_PORTS=8,READ_LATENCY=2 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=16,NUM_PORTS=16,MAP_MODE=2 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=16,NUM_PORTS=16,MAP_MODE=2 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=16,NUM_PORTS=3,MAP_MODE=1,BLOCK_WORDS=8 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=16,NUM_PORTS=3,MAP_MODE=1,BLOCK_WORDS=8 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=4,NUM_PORTS=6,READ_LATENCY=3,WRITE_ACK=0,STRICT_ALIGN=1 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=4,NUM_PORTS=6,READ_LATENCY=3,WRITE_ACK=0,STRICT_ALIGN=1 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=3,BANK_DEPTH=100,NUM_PORTS=2 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=3,BANK_DEPTH=100,NUM_PORTS=2 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+PERF_EN=0 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+PERF_EN=0 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+DATA_WIDTH=72,BYTE_WIDTH=9,BANK_DEPTH=64 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+DATA_WIDTH=72,BYTE_WIDTH=9,BANK_DEPTH=64 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+DATA_WIDTH=64,ID_WIDTH=1,CNT_W=8 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+DATA_WIDTH=64,ID_WIDTH=1,CNT_W=8 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=4,ADDR_WIDTH=20 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank+NUM_BANKS=4,ADDR_WIDTH=20 [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_array | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_array [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_perf | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_perf [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_unmap | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_unmap [SYNTHESIS] | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode+NUM_BANKS=4,BANK_DEPTH=256,BYTES_PER_WORD=4,MAP_MODE=1,BLOCK_WORDS=8,STRICT_ALIGN=1 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode+NUM_BANKS=3,BANK_DEPTH=100,BYTES_PER_WORD=4,MAP_MODE=0,BLOCK_WORDS=1,STRICT_ALIGN=0 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode+NUM_BANKS=16,BANK_DEPTH=64,BYTES_PER_WORD=4,MAP_MODE=2,BLOCK_WORDS=1,STRICT_ALIGN=1 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode+NUM_BANKS=8,BANK_DEPTH=1000,BYTES_PER_WORD=8,MAP_MODE=0,BLOCK_WORDS=1,STRICT_ALIGN=0 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode+NUM_BANKS=12,BANK_DEPTH=64,BYTES_PER_WORD=4,MAP_MODE=1,BLOCK_WORDS=4,STRICT_ALIGN=0 | verilator -Wall |  | PASS |  |  |
| lint | sf_sram_bank_addr_decode+NUM_BANKS=2,BANK_DEPTH=300,BYTES_PER_WORD=1,MAP_MODE=1,BLOCK_WORDS=4,STRICT_ALIGN=0 | verilator -Wall |  | PASS |  |  |
| lint | sf_srambank_2x1024x32 | verilator -Wall (example preset) |  | PASS |  |  |
| lint | sf_srambank_2x1024x32 | iverilog -Wall (example preset) |  | PASS |  |  |
| lint | sf_srambank_4x1024x32 | verilator -Wall (example preset) |  | PASS |  |  |
| lint | sf_srambank_4x1024x32 | iverilog -Wall (example preset) |  | PASS |  |  |
| lint | sf_srambank_8x1024x32 | verilator -Wall (example preset) |  | PASS |  |  |
| lint | sf_srambank_8x1024x32 | iverilog -Wall (example preset) |  | PASS |  |  |
| lint | sf_srambank_16x1024x32 | verilator -Wall (example preset) |  | PASS |  |  |
| lint | sf_srambank_16x1024x32 | iverilog -Wall (example preset) |  | PASS |  |  |
| lint | sf_sram_bank | iverilog -Wall |  | PASS |  |  |
| lint | sf_sram_bank_array | iverilog -Wall |  | PASS |  |  |
| neg | banks_1 | verilator |  | PASS |  |  |
| neg | banks_1 | iverilog |  | PASS |  |  |
| neg | banks_1 | yosys |  | PASS |  |  |
| neg | banks_65 | verilator |  | PASS |  |  |
| neg | banks_65 | iverilog |  | PASS |  |  |
| neg | banks_65 | yosys |  | PASS |  |  |
| neg | depth_1 | verilator |  | PASS |  |  |
| neg | depth_1 | iverilog |  | PASS |  |  |
| neg | depth_1 | yosys |  | PASS |  |  |
| neg | bpw_3 | verilator |  | PASS |  |  |
| neg | bpw_3 | iverilog |  | PASS |  |  |
| neg | bpw_3 | yosys |  | PASS |  |  |
| neg | map_mode_7 | verilator |  | PASS |  |  |
| neg | map_mode_7 | iverilog |  | PASS |  |  |
| neg | map_mode_7 | yosys |  | PASS |  |  |
| neg | block_words_3 | verilator |  | PASS |  |  |
| neg | block_words_3 | iverilog |  | PASS |  |  |
| neg | block_words_3 | yosys |  | PASS |  |  |
| neg | block_words_0 | verilator |  | PASS |  |  |
| neg | block_words_0 | iverilog |  | PASS |  |  |
| neg | block_words_0 | yosys |  | PASS |  |  |
| neg | block_not_divisor | verilator |  | PASS |  |  |
| neg | block_not_divisor | iverilog |  | PASS |  |  |
| neg | block_not_divisor | yosys |  | PASS |  |  |
| neg | block_over_depth | verilator |  | PASS |  |  |
| neg | block_over_depth | iverilog |  | PASS |  |  |
| neg | block_over_depth | yosys |  | PASS |  |  |
| neg | xor_nonpow2_banks | verilator |  | PASS |  |  |
| neg | xor_nonpow2_banks | iverilog |  | PASS |  |  |
| neg | xor_nonpow2_banks | yosys |  | PASS |  |  |
| neg | strict_2 | verilator |  | PASS |  |  |
| neg | strict_2 | iverilog |  | PASS |  |  |
| neg | strict_2 | yosys |  | PASS |  |  |
| neg | addr_width_small | verilator |  | PASS |  |  |
| neg | addr_width_small | iverilog |  | PASS |  |  |
| neg | addr_width_small | yosys |  | PASS |  |  |
| neg | addr_width_33 | verilator |  | PASS |  |  |
| neg | addr_width_33 | iverilog |  | PASS |  |  |
| neg | addr_width_33 | yosys |  | PASS |  |  |
| neg | capacity_over_2_24 | verilator |  | PASS |  |  |
| neg | capacity_over_2_24 | iverilog |  | PASS |  |  |
| neg | capacity_over_2_24 | yosys |  | PASS |  |  |
| neg | top_ports_0 | verilator |  | PASS |  |  |
| neg | top_ports_0 | iverilog |  | PASS |  | rejected at elaboration |
| neg | top_ports_0 | yosys |  | PASS |  |  |
| neg | top_ports_33 | verilator |  | PASS |  |  |
| neg | top_ports_33 | iverilog |  | PASS |  |  |
| neg | top_ports_33 | yosys |  | PASS |  |  |
| neg | top_lanes_not_pow2 | verilator |  | PASS |  |  |
| neg | top_lanes_not_pow2 | iverilog |  | PASS |  |  |
| neg | top_lanes_not_pow2 | yosys |  | PASS |  |  |
| neg | top_xor_nonpow2 | verilator |  | PASS |  |  |
| neg | top_xor_nonpow2 | iverilog |  | PASS |  |  |
| neg | top_xor_nonpow2 | yosys |  | PASS |  |  |
| neg | top_write_ack_2 | verilator |  | PASS |  |  |
| neg | top_write_ack_2 | iverilog |  | PASS |  |  |
| neg | top_write_ack_2 | yosys |  | PASS |  |  |
| neg | top_id_width_0 | verilator |  | PASS |  |  |
| neg | top_id_width_0 | iverilog |  | PASS |  | rejected at elaboration |
| neg | top_id_width_0 | yosys |  | PASS |  |  |
| neg | top_core_latency_0 | verilator |  | PASS |  |  |
| neg | top_core_latency_0 | iverilog |  | PASS |  | rejected at elaboration |
| neg | top_core_latency_0 | yosys |  | PASS |  |  |
| neg | array_banks_0 | verilator |  | PASS |  |  |
| neg | array_banks_0 | iverilog |  | PASS |  | rejected at elaboration |
| neg | array_banks_0 | yosys |  | PASS |  |  |
| neg | perf_cnt_w_1 | verilator |  | PASS |  |  |
| neg | perf_cnt_w_1 | iverilog |  | PASS |  |  |
| neg | perf_cnt_w_1 | yosys |  | PASS |  |  |
| decode | d2_seq | vl |  | PASS | 5124 |  |
| decode | d2_seq | ic |  | PASS | 5124 |  |
| decode | d2_blk4 | vl |  | PASS | 5124 |  |
| decode | d2_contig | vl |  | PASS | 5124 |  |
| decode | d2_xor | vl |  | PASS | 5124 |  |
| decode | d2_xor | ic |  | PASS | 5124 |  |
| decode | d2_xor8_b8 | vl |  | PASS | 5124 |  |
| decode | d2_strict | vl |  | PASS | 4612 |  |
| decode | d2_d1000_blk8 | vl |  | PASS | 20286 |  |
| decode | d2_wide | vl |  | PASS | 13243 |  |
| decode | d2_wide_strict_xor | vl |  | PASS | 10412 |  |
| decode | d2_bpw1 | vl |  | PASS | 3076 |  |
| decode | d4_seq | vl |  | PASS | 10244 |  |
| decode | d4_seq | ic |  | PASS | 10244 |  |
| decode | d4_blk4 | vl |  | PASS | 10244 |  |
| decode | d4_contig | vl |  | PASS | 10244 |  |
| decode | d4_xor | vl |  | PASS | 10244 |  |
| decode | d4_xor | ic |  | PASS | 10244 |  |
| decode | d4_xor8_b8 | vl |  | PASS | 10244 |  |
| decode | d4_strict | vl |  | PASS | 9220 |  |
| decode | d4_d1000_blk8 | vl |  | PASS | 40488 |  |
| decode | d4_wide | vl |  | PASS | 18348 |  |
| decode | d4_wide_strict_xor | vl |  | PASS | 12701 |  |
| decode | d4_bpw1 | vl |  | PASS | 6148 |  |
| decode | d8_seq | vl |  | PASS | 20484 |  |
| decode | d8_blk4 | vl |  | PASS | 20484 |  |
| decode | d8_contig | vl |  | PASS | 20484 |  |
| decode | d8_xor | vl |  | PASS | 20484 |  |
| decode | d8_xor8_b8 | vl |  | PASS | 20484 |  |
| decode | d8_strict | vl |  | PASS | 18436 |  |
| decode | d8_d1000_blk8 | vl |  | PASS | 80866 |  |
| decode | d8_wide | vl |  | PASS | 28565 |  |
| decode | d8_wide_strict_xor | vl |  | PASS | 17270 |  |
| decode | d8_bpw1 | vl |  | PASS | 12292 |  |
| decode | d16_seq | vl |  | PASS | 40964 |  |
| decode | d16_blk4 | vl |  | PASS | 40964 |  |
| decode | d16_contig | vl |  | PASS | 40964 |  |
| decode | d16_xor | vl |  | PASS | 40964 |  |
| decode | d16_xor8_b8 | vl |  | PASS | 40964 |  |
| decode | d16_strict | vl |  | PASS | 36868 |  |
| decode | d16_d1000_blk8 | vl |  | PASS | 161650 |  |
| decode | d16_wide | vl |  | PASS | 49009 |  |
| decode | d16_wide_strict_xor | vl |  | PASS | 26421 |  |
| decode | d16_bpw1 | vl |  | PASS | 24580 |  |
| decode | dx_b3_seq | vl |  | PASS | 5439 |  |
| decode | dx_b3_seq | ic |  | PASS | 5439 |  |
| decode | dx_b5_seq | vl |  | PASS | 5398 |  |
| decode | dx_b6_blk16 | vl |  | PASS | 10719 |  |
| decode | dx_b7_seq | vl |  | PASS | 2840 |  |
| decode | dx_b12_blk4 | vl |  | PASS | 9675 |  |
| array | a1 | vl | 1 | PASS | 78610 |  |
| array | a2 | vl | 1 | PASS | 156860 |  |
| array | a4 | vl | 1 | PASS | 313504 |  |
| array | a4 | vl | 2 | PASS | 312672 |  |
| array | a4 | ic | 1 | PASS | 313504 |  |
| array | a4 | ic | 2 | PASS | 312672 |  |
| array-xsim | a4 | vl==ic | 1 | PASS |  |  |
| array-xsim | a4 | vl==ic | 2 | PASS |  |  |
| array | a8 | vl | 1 | PASS | 627123 |  |
| array | a16 | vl | 1 | PASS | 1253458 |  |
| array | a4_d100 | vl | 1 | PASS | 309603 |  |
| array | a4_d100 | ic | 1 | PASS | 309603 |  |
| array-xsim | a4_d100 | vl==ic | 1 | PASS |  |  |
| array | a4_lat2 | vl | 1 | PASS | 313719 |  |
| array | a4_lat3 | vl | 1 | PASS | 313953 |  |
| array | a4_lat3 | ic | 1 | PASS | 313953 |  |
| array-xsim | a4_lat3 | vl==ic | 1 | PASS |  |  |
| array | a4_lat3_na | vl | 1 | PASS | 281745 |  |
| array | a4_d100_l2na | vl | 1 | PASS | 278720 |  |
| array | a4_dw64 | vl | 1 | PASS | 391387 |  |
| array | a4_bw9 | vl | 1 | PASS | 391387 |  |
| array | a4_pattern | vl | 1 | PASS | 313504 |  |
| array | a4_idw1 | vl | 1 | PASS | 313504 |  |
