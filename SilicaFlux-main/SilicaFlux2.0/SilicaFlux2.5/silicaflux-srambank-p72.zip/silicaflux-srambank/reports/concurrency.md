# Measured concurrency (simulation, this RTL, fixed-priority interlock, requesters hold until accepted)

`ops/cycle` = lane requests served per active clock cycle.  One single-port bank can never exceed 1.0; the banked subsystem reaches up to NUM_BANKS only when concurrent requests fall on different banks.

| config | workload | banks | lanes | map | ops | active cycles | ops/cycle | peak banks in one cycle | conflict events | stalled lane-cycles |
|---|---|---|---|---|---|---|---|---|---|---|
| b2_seq | unit | 2 | 2 | SEQ | 800 | 400 | 2.00 | 2 | 0 | 0 |
| b2_seq | stride | 2 | 2 | SEQ | 800 | 800 | 1.00 | 1 | 400 | 400 |
| b2_seq | region | 2 | 2 | SEQ | 800 | 401 | 2.00 | 2 | 1 | 1 |
| b2_seq | random | 2 | 2 | SEQ | 800 | 622 | 1.29 | 2 | 222 | 222 |
| b2_seq | hot | 2 | 2 | SEQ | 800 | 668 | 1.20 | 2 | 268 | 268 |
| b2_seq | samebank | 2 | 2 | SEQ | 800 | 800 | 1.00 | 1 | 400 | 400 |
| b4_seq | unit | 4 | 4 | SEQ | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_seq | stride | 4 | 4 | SEQ | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b4_seq | region | 4 | 4 | SEQ | 1600 | 403 | 3.97 | 4 | 3 | 6 |
| b4_seq | random | 4 | 4 | SEQ | 1600 | 735 | 2.18 | 4 | 537 | 663 |
| b4_seq | hot | 4 | 4 | SEQ | 1600 | 1095 | 1.46 | 3 | 727 | 1347 |
| b4_seq | samebank | 4 | 4 | SEQ | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b4_contig | unit | 4 | 4 | BLOCK(B=256) | 1600 | 592 | 2.70 | 4 | 192 | 384 |
| b4_contig | stride | 4 | 4 | BLOCK(B=256) | 1600 | 448 | 3.57 | 4 | 48 | 96 |
| b4_contig | region | 4 | 4 | BLOCK(B=256) | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_contig | random | 4 | 4 | BLOCK(B=256) | 1600 | 738 | 2.17 | 4 | 524 | 647 |
| b4_contig | hot | 4 | 4 | BLOCK(B=256) | 1600 | 1102 | 1.45 | 4 | 728 | 1340 |
| b4_contig | samebank | 4 | 4 | BLOCK(B=256) | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b4_xor | unit | 4 | 4 | XOR | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_xor | stride | 4 | 4 | XOR | 1600 | 400 | 4.00 | 4 | 0 | 0 |
| b4_xor | region | 4 | 4 | XOR | 1600 | 669 | 2.39 | 4 | 269 | 275 |
| b4_xor | random | 4 | 4 | XOR | 1600 | 737 | 2.17 | 4 | 536 | 670 |
| b4_xor | hot | 4 | 4 | XOR | 1600 | 1092 | 1.47 | 3 | 709 | 1332 |
| b4_xor | samebank | 4 | 4 | XOR | 1600 | 1600 | 1.00 | 1 | 1200 | 2400 |
| b8_seq | unit | 8 | 8 | SEQ | 3200 | 400 | 8.00 | 8 | 0 | 0 |
| b8_seq | stride | 8 | 8 | SEQ | 3200 | 3200 | 1.00 | 1 | 2800 | 11200 |
| b8_seq | region | 8 | 8 | SEQ | 3200 | 407 | 7.86 | 8 | 7 | 28 |
| b8_seq | random | 8 | 8 | SEQ | 3200 | 806 | 3.97 | 7 | 1134 | 1569 |
| b8_seq | hot | 8 | 8 | SEQ | 3200 | 1894 | 1.69 | 4 | 1555 | 5790 |
| b8_seq | samebank | 8 | 8 | SEQ | 3200 | 3200 | 1.00 | 1 | 2800 | 11200 |
| b8_xor | unit | 8 | 8 | XOR | 3200 | 400 | 8.00 | 8 | 0 | 0 |
| b8_xor | stride | 8 | 8 | XOR | 3200 | 400 | 8.00 | 8 | 0 | 0 |
| b8_xor | region | 8 | 8 | XOR | 3200 | 720 | 4.44 | 8 | 631 | 770 |
| b8_xor | random | 8 | 8 | XOR | 3200 | 811 | 3.95 | 7 | 1136 | 1616 |
| b8_xor | hot | 8 | 8 | XOR | 3200 | 1898 | 1.69 | 5 | 1544 | 5786 |
| b8_xor | samebank | 8 | 8 | XOR | 3200 | 3200 | 1.00 | 1 | 2800 | 11200 |
| b16_seq | unit | 16 | 16 | SEQ | 6400 | 400 | 16.00 | 16 | 0 | 0 |
| b16_seq | stride | 16 | 16 | SEQ | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
| b16_seq | region | 16 | 16 | SEQ | 6400 | 415 | 15.42 | 16 | 15 | 120 |
| b16_seq | random | 16 | 16 | SEQ | 6400 | 828 | 7.73 | 13 | 2303 | 3321 |
| b16_seq | hot | 16 | 16 | SEQ | 6400 | 3520 | 1.82 | 8 | 3182 | 24618 |
| b16_seq | samebank | 16 | 16 | SEQ | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
| b16_xor | unit | 16 | 16 | XOR | 6400 | 400 | 16.00 | 16 | 0 | 0 |
| b16_xor | stride | 16 | 16 | XOR | 6400 | 400 | 16.00 | 16 | 0 | 0 |
| b16_xor | region | 16 | 16 | XOR | 6400 | 731 | 8.76 | 16 | 1151 | 1704 |
| b16_xor | random | 16 | 16 | XOR | 6400 | 832 | 7.69 | 13 | 2323 | 3489 |
| b16_xor | hot | 16 | 16 | XOR | 6400 | 3522 | 1.82 | 9 | 3193 | 24583 |
| b16_xor | samebank | 16 | 16 | XOR | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
| b16_block4 | unit | 16 | 16 | BLOCK(B=4) | 6400 | 403 | 15.88 | 16 | 12 | 24 |
| b16_block4 | stride | 16 | 16 | BLOCK(B=4) | 6400 | 1600 | 4.00 | 4 | 4800 | 9600 |
| b16_block4 | region | 16 | 16 | BLOCK(B=4) | 6400 | 460 | 13.91 | 16 | 60 | 480 |
| b16_block4 | random | 16 | 16 | BLOCK(B=4) | 6400 | 829 | 7.72 | 13 | 2341 | 3432 |
| b16_block4 | hot | 16 | 16 | BLOCK(B=4) | 6400 | 3510 | 1.82 | 7 | 3178 | 24501 |
| b16_block4 | samebank | 16 | 16 | BLOCK(B=4) | 6400 | 6400 | 1.00 | 1 | 6000 | 48000 |
