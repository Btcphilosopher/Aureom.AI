# Regression `regression_s24`

Total: 69 records, 0 not passing, 32,219,749 scoreboard checks.

| suite | pass | not pass |
|---|---|---|
| bank2 | 23 | 0 |
| bank2-xsim | 6 | 0 |
| bank2-coverage | 1 | 0 |
| bank4 | 29 | 0 |
| bank4-xsim | 9 | 0 |
| bank4-coverage | 1 | 0 |

## Records

| suite | config | tool | seed | result | checks | notes |
|---|---|---|---|---|---|---|
| bank2 | b2_seq | vl | 1 | PASS | 359663 |  |
| bank2 | b2_seq | vl | 2 | PASS | 359868 |  |
| bank2 | b2_seq | ic | 1 | PASS | 359663 |  |
| bank2 | b2_seq | ic | 2 | PASS | 359868 |  |
| bank2-xsim | b2_seq | vl==ic | 1 | PASS |  |  |
| bank2-xsim | b2_seq | vl==ic | 2 | PASS |  |  |
| bank2 | b2_block4 | vl | 1 | PASS | 357709 |  |
| bank2 | b2_contig | vl | 1 | PASS | 383277 |  |
| bank2 | b2_xor | vl | 1 | PASS | 356451 |  |
| bank2 | b2_xor | ic | 1 | PASS | 356451 |  |
| bank2-xsim | b2_xor | vl==ic | 1 | PASS |  |  |
| bank2 | b2_xor8_w64 | vl | 1 | PASS | 458817 |  |
| bank2 | b2_strict | vl | 1 | PASS | 350996 |  |
| bank2 | b2_lat2 | vl | 1 | PASS | 362103 |  |
| bank2 | b2_lat2 | ic | 1 | PASS | 362103 |  |
| bank2-xsim | b2_lat2 | vl==ic | 1 | PASS |  |  |
| bank2 | b2_lat3_noack | vl | 1 | PASS | 343811 |  |
| bank2 | b2_awx3 | vl | 1 | PASS | 359653 |  |
| bank2 | b2_awx3 | ic | 1 | PASS | 359653 |  |
| bank2-xsim | b2_awx3 | vl==ic | 1 | PASS |  |  |
| bank2 | b2_np1 | vl | 1 | PASS | 421148 |  |
| bank2 | b2_np3 | vl | 1 | PASS | 404523 |  |
| bank2 | b2_zero | vl | 1 | PASS | 359663 |  |
| bank2 | b2_pattern_xor | vl | 1 | PASS | 356451 |  |
| bank2 | b2_d300 | vl | 1 | PASS | 390268 |  |
| bank2 | b2_cnt5 | vl | 1 | PASS | 359656 |  |
| bank2 | b2_awx3_posted | vl | 1 | PASS | 341889 |  |
| bank2 | b2_awx3_posted | ic | 1 | PASS | 341889 |  |
| bank2-xsim | b2_awx3_posted | vl==ic | 1 | PASS |  |  |
| bank2-coverage | stage 2 | run_regress |  | PASS |  |  |
| bank4 | b4_seq | vl | 1 | PASS | 766096 |  |
| bank4 | b4_seq | vl | 2 | PASS | 768175 |  |
| bank4 | b4_seq | vl | 3 | PASS | 765479 |  |
| bank4 | b4_seq | ic | 1 | PASS | 766096 |  |
| bank4 | b4_seq | ic | 2 | PASS | 768175 |  |
| bank4 | b4_seq | ic | 3 | PASS | 765479 |  |
| bank4-xsim | b4_seq | vl==ic | 1 | PASS |  |  |
| bank4-xsim | b4_seq | vl==ic | 2 | PASS |  |  |
| bank4-xsim | b4_seq | vl==ic | 3 | PASS |  |  |
| bank4 | b4_block4 | vl | 1 | PASS | 751792 |  |
| bank4 | b4_contig | vl | 1 | PASS | 823984 |  |
| bank4 | b4_contig | ic | 1 | PASS | 823984 |  |
| bank4-xsim | b4_contig | vl==ic | 1 | PASS |  |  |
| bank4 | b4_xor | vl | 1 | PASS | 748336 |  |
| bank4 | b4_xor | vl | 2 | PASS | 748879 |  |
| bank4 | b4_xor | ic | 1 | PASS | 748336 |  |
| bank4 | b4_xor | ic | 2 | PASS | 748879 |  |
| bank4-xsim | b4_xor | vl==ic | 1 | PASS |  |  |
| bank4-xsim | b4_xor | vl==ic | 2 | PASS |  |  |
| bank4 | b4_xor8_w64 | vl | 1 | PASS | 1014613 |  |
| bank4 | b4_strict_xor | vl | 1 | PASS | 728857 |  |
| bank4 | b4_lat2 | vl | 1 | PASS | 771136 |  |
| bank4 | b4_lat2 | ic | 1 | PASS | 771136 |  |
| bank4-xsim | b4_lat2 | vl==ic | 1 | PASS |  |  |
| bank4 | b4_lat3_noack | vl | 1 | PASS | 743664 |  |
| bank4 | b4_awx2 | vl | 1 | PASS | 767596 |  |
| bank4 | b4_np6 | vl | 1 | PASS | 867884 |  |
| bank4 | b4_np2 | vl | 1 | PASS | 823209 |  |
| bank4 | b4_d1000 | vl | 1 | PASS | 2194814 |  |
| bank4 | b4_pattern | vl | 1 | PASS | 766096 |  |
| bank4 | b4_bw9 | vl | 1 | PASS | 515914 |  |
| bank4 | b4_cnt5 | vl | 1 | PASS | 766083 |  |
| bank4 | b4_cnt5 | ic | 1 | PASS | 766083 |  |
| bank4-xsim | b4_cnt5 | vl==ic | 1 | PASS |  |  |
| bank4 | b4_awx2_lat3 | vl | 1 | PASS | 777692 |  |
| bank4 | b4_awx2_lat3 | ic | 1 | PASS | 777692 |  |
| bank4-xsim | b4_awx2_lat3 | vl==ic | 1 | PASS |  |  |
| bank4 | b4_strict_posted | vl | 1 | PASS | 708017 |  |
| bank4-coverage | stage 4 | run_regress |  | PASS |  |  |
