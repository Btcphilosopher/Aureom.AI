# Regression `regression_perf`

Total: 9 records, 0 not passing, 0 scoreboard checks.

| suite | pass | not pass |
|---|---|---|
| perf | 9 | 0 |

## Records

| suite | config | tool | seed | result | checks | notes |
|---|---|---|---|---|---|---|
| perf | b2_seq | vl | 1 | PASS | 381864 |  |
| perf | b4_seq | vl | 1 | PASS | 1026777 |  |
| perf | b4_contig | vl | 1 | PASS | 1038841 |  |
| perf | b4_xor | vl | 1 | PASS | 965817 |  |
| perf | b8_seq | vl | 1 | PASS | 3214873 |  |
| perf | b8_xor | vl | 1 | PASS | 2904437 |  |
| perf | b16_seq | vl | 1 | PASS | 11717453 |  |
| perf | b16_xor | vl | 1 | PASS | 10328477 |  |
| perf | b16_block4 | vl | 1 | PASS | 10555641 |  |
