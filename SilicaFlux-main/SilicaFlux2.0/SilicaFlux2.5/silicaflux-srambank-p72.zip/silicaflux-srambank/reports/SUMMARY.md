# SRAMBank results (generated from the JSON reports of the final run)

| Check | Result | Notes |
|---|---|---|
| Lint: Verilator `-Wall` (zero warnings) + Icarus `-Wall` elaboration | 48 pass / 0 fail | sf_sram_bank over 12 configurations x {with, without `SYNTHESIS`}, every sub-module, decoder matrix |
| Illegal parameterisations rejected | 69 pass / 0 fail | 23 cases x Verilator, Icarus, Yosys; explicit message reached in 40/69 (a tool may abort on its own width error first) |
| Address mapping proof (exhaustive): correct / injective / surjective / invertible / bounded | 50 pass / 0 fail | 1,048,817 checks; 50 RTL dumps identical to the Python model; SEQ, BLOCK, XOR; 2-16 banks and 3,5,6,7,12 |
| Per-bank interface (independent enables / addresses), `sf_sram_bank_array` | 19 pass / 0 fail | 6,899,481 checks, 1-16 banks, latency 1-3, posted writes, non-power-of-two depth |
| `sf_sram_bank` self-checking simulation, **TWO banks** | 23 pass / 0 fail | 8,465,573 scoreboard checks; Verilator vs Icarus: 6/6 identical check counts (same stimulus); bank counts exercised: 2 (PASS) |
| `sf_sram_bank` self-checking simulation, **FOUR banks** | 29 pass / 0 fail | 23,754,176 scoreboard checks; Verilator vs Icarus: 9/9 identical check counts (same stimulus); bank counts exercised: 4 (PASS) |
| `sf_sram_bank` self-checking simulation, EIGHT and SIXTEEN banks | 21 pass / 0 fail | 100,665,287 scoreboard checks; Verilator vs Icarus: 5/5 identical check counts (same stimulus); bank counts exercised: 8, 16 (PASS) |
| `sf_sram_bank` self-checking simulation, non-power-of-two bank counts | 5 pass / 0 fail | 3,542,632 scoreboard checks; Verilator vs Icarus: 1/1 identical check counts (same stimulus); bank counts exercised: 3, 5, 6, 12 (PASS) |
| **Bank-conflict gate** (before 8/16 banks): interlock + conflict-counter mutants killed on 2 AND 4 banks | PASS | 14 mutants |
| Mutation sanity: injected RTL bugs | 53 killed / 0 survived / 0 invalid | of 53; `reports/mutants.md` |
| Yosys: one memory inferred per bank, zero latches | PASS | 72 synthesis rows (generic, xc7, ice40, ecp5, depth sweep, decoder cost); `reports/synth.md` |

Tools: verilator `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`; iverilog `Icarus Verilog version 12.0 (stable) ()`; yosys `Yosys 0.33 (git sha1 2584903a060)`; python `3.13.18`.  Not installed: vivado, quartus, openroad.  RTL sha256 `7a24d142887dc87d…`.
