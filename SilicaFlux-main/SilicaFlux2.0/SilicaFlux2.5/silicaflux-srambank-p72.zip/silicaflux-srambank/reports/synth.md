# Synthesis and FPGA memory-inference report

**Inference evidence only.**  Yosys Yosys 0.33 (git sha1 2584903a060).  No vendor tool (Vivado / Quartus / Radiant), no place-and-route, no timing, no board, no ASIC flow: there is **no frequency, area in um2, power or access-time figure anywhere in this package**.  Whether a bank maps to a block RAM on a given device depends on the tool version, the device family and the bank shape; re-check with the vendor tool (`synth/vivado/synth_srambank.tcl`, not run here).

## 1. One memory per logical bank (generic synthesis, 32-bit x 1024 words per bank)

| banks | counters | memories inferred | shape | latches | warnings | exit |
|---|---|---|---|---|---|---|
| 2 | on | **2** | 32b x 1024 | 0 | 0 | 0 |
| 2 | off | **2** | 32b x 1024 | 0 | 0 | 0 |
| 4 | on | **4** | 32b x 1024 | 0 | 0 | 0 |
| 4 | off | **4** | 32b x 1024 | 0 | 0 | 0 |
| 8 | on | **8** | 32b x 1024 | 0 | 0 | 0 |
| 8 | off | **8** | 32b x 1024 | 0 | 0 | 0 |
| 16 | on | **16** | 32b x 1024 | 0 | 0 | 0 |
| 16 | off | **16** | 32b x 1024 | 0 | 0 | 0 |

Expected and observed: `memories == banks`, 0 latches, `check -assert` clean.

## 2. What the memories become on FPGA targets (Yosys vendor flows, 32-bit x 1024 words per bank)

| target | banks | block RAM primitives | RAM per bank | distributed RAM | LUTs | FFs | counters |
|---|---|---|---|---|---|---|---|
| xc7 | 2 | RAMB36E1: 2 | 1 | - | 735 | 526 | on |
| xc7 | 4 | RAMB36E1: 4 | 1 | - | 2123 | 992 | on |
| xc7 | 8 | RAMB36E1: 8 | 1 | - | 6075 | 1928 | on |
| xc7 | 16 | RAMB36E1: 16 | 1 | - | 22290 | 3808 | on |
| ice40 | 2 | SB_RAM40_4K: 16 | 8 | - | 1290 | 526 | on |
| ice40 | 4 | SB_RAM40_4K: 32 | 8 | - | 3179 | 992 | on |
| ice40 | 8 | SB_RAM40_4K: 64 | 8 | - | 9998 | 1928 | on |
| ice40 | 16 | SB_RAM40_4K: 128 | 8 | - | 33504 | 3808 | on |
| ecp5 | 2 | DP16KD: 4 | 2 | - | 1341 | 526 | on |
| ecp5 | 4 | DP16KD: 8 | 2 | - | 3731 | 992 | on |
| ecp5 | 8 | DP16KD: 16 | 2 | - | 12588 | 1928 | on |
| ecp5 | 16 | DP16KD: 32 | 2 | - | 43176 | 3808 | on |
| xc7 | 4 | RAMB36E1: 4 | 1 | - | 1242 | 32 | off |
| xc7 | 16 | RAMB36E1: 16 | 1 | - | 18225 | 160 | off |
| xc7 | 2 | RAMB36E1: 2 | 1 | - | 203 | 14 | off |
| xc7 | 8 | RAMB36E1: 8 | 1 | - | 4126 | 72 | off |

The LUT / FF columns of the `counters on` rows are dominated by the performance counters (up to 7 x NUM_BANKS + (NUM_BANKS+1) + 3 32-bit counters; Yosys prunes those that are provably zero in the configuration), not by the banking logic; compare the `counters off` rows.

## 3. Depth sweep, 4 banks, xc7 (counters off): where does a bank stop being a block RAM?

| depth x width | block RAM | distributed RAM | LUTs | FFs |
|---|---|---|---|---|
| 16 x 32 | none | RAM32M: 16 | 974 | 160 |
| 32 x 32 | none | RAM32M: 16 | 1110 | 160 |
| 64 x 32 | none | RAM64X1S: 128 | 1082 | 160 |
| 128 x 32 | none | RAM128X1S: 128 | 1124 | 160 |
| 256 x 32 | RAMB18E1: 4 | none | 990 | 32 |
| 512 x 32 | RAMB18E1: 4 | none | 1138 | 32 |
| 1024 x 32 | RAMB36E1: 4 | none | 1242 | 32 |
| 2048 x 32 | RAMB36E1: 8 | none | 1038 | 32 |
| 4096 x 32 | RAMB36E1: 16 | none | 1238 | 32 |
| 512 x 64 | RAMB36E1: 4 | none | 2274 | 32 |
| 256 x 72 | RAMB36E1: 4 | none | 3658 | 32 |

Shallow banks do not use a block RAM at all: this is why the inference is *checked* rather than assumed.

## 3b. Cost of the lane front end (xc7, 32-bit x 1024 words per bank, counters off, `NUM_PORTS = NUM_BANKS`)

`sf_sram_bank` puts a full **lane x bank crossbar** in front of the banks (request mux per bank, response routing per lane, decoders, interlock); it scales as NUM_PORTS x NUM_BANKS.  `sf_sram_bank_array` is the per-bank interface with **no** crossbar (one request port per bank, response pipelines only).  Yosys LUT counts, evidence of scaling only -- not an area or timing figure, and the RTL is not tuned for area:

| banks | `sf_sram_bank` LUTs (counters off) | `sf_sram_bank_array` LUTs | `sf_sram_bank_array` FFs | RAMB36E1 (both) |
|---|---|---|---|---|
| 2 | 203 | 16 | 16 | 2 |
| 4 | 1242 | 32 | 32 | 4 |
| 8 | 4126 | 64 | 64 | 8 |
| 16 | 18225 | 128 | 128 | 16 |

Reading: the banks themselves are cheap; the lane crossbar dominates and grows ~NUM_PORTS x NUM_BANKS.  A controller that arbitrates per bank and drives `sf_sram_bank_array` directly avoids it; the lane front end is the convenient, self-checking option for small bank counts.

## 4. Address decoder cost (xc7 LUT6 count of `sf_sram_bank_addr_decode` alone, 4-byte words, 256 words per bank)

| banks | map | extra address bits | strict align | LUTs | CARRY4 |
|---|---|---|---|---|---|
| 2 | SEQ | 0 | 0 | 0 | 0 |
| 2 | BLOCK B=8 | 0 | 0 | 0 | 0 |
| 2 | XOR B=1 | 0 | 0 | 1 | 0 |
| 2 | SEQ | 2 | 0 | 2 | 0 |
| 2 | SEQ | 0 | 1 | 2 | 0 |
| 4 | SEQ | 0 | 0 | 0 | 0 |
| 4 | BLOCK B=8 | 0 | 0 | 0 | 0 |
| 4 | XOR B=1 | 0 | 0 | 2 | 0 |
| 4 | SEQ | 2 | 0 | 2 | 0 |
| 4 | SEQ | 0 | 1 | 2 | 0 |
| 8 | SEQ | 0 | 0 | 0 | 0 |
| 8 | BLOCK B=8 | 0 | 0 | 0 | 0 |
| 8 | XOR B=1 | 0 | 0 | 3 | 0 |
| 8 | SEQ | 2 | 0 | 2 | 0 |
| 8 | SEQ | 0 | 1 | 2 | 0 |
| 16 | SEQ | 0 | 0 | 0 | 0 |
| 16 | BLOCK B=8 | 0 | 0 | 0 | 0 |
| 16 | XOR B=1 | 0 | 0 | 4 | 0 |
| 16 | SEQ | 2 | 0 | 2 | 0 |
| 16 | SEQ | 0 | 1 | 2 | 0 |
| 3 (not 2^n) | SEQ | 0 | 0 | 440 | 135 |
| 3 (not 2^n) | BLOCK B=8 | 0 | 0 | 368 | 135 |
| 5 (not 2^n) | SEQ | 0 | 0 | 542 | 157 |
| 5 (not 2^n) | BLOCK B=8 | 0 | 0 | 509 | 157 |
| 6 (not 2^n) | SEQ | 0 | 0 | 544 | 157 |
| 6 (not 2^n) | BLOCK B=8 | 0 | 0 | 501 | 157 |
| 7 (not 2^n) | SEQ | 0 | 0 | 545 | 157 |
| 7 (not 2^n) | BLOCK B=8 | 0 | 0 | 492 | 157 |
| 9 (not 2^n) | SEQ | 0 | 0 | 658 | 181 |
| 9 (not 2^n) | BLOCK B=8 | 0 | 0 | 683 | 181 |
| 12 (not 2^n) | SEQ | 0 | 0 | 663 | 181 |
| 12 (not 2^n) | BLOCK B=8 | 0 | 0 | 657 | 181 |
| 15 (not 2^n) | SEQ | 0 | 0 | 669 | 181 |
| 15 (not 2^n) | BLOCK B=8 | 0 | 0 | 652 | 181 |

Power-of-two bank counts decode with bit slices (0 LUTs for SEQ / BLOCK when the capacity is exactly 2^n bytes; one XOR per bank-index bit for XOR); a non-power-of-two count needs the generic constant divide / modulo, which costs real logic -- the numbers above are the evidence.  Caveat: Yosys 0.33 maps a constant divisor to a general divider array, so these counts are an upper-end figure; a vendor tool may reduce constant division (e.g. by reciprocal multiplication), but it is never free, and the power-of-two path needs none of it.

## Scripts

Every row's exact Yosys script is stored in `reports/synth.json` (`script`).
