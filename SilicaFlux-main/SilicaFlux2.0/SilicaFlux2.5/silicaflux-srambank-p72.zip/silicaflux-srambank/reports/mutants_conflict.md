# Mutation sanity

14 killed / 0 survived / 0 invalid of 14 injected RTL bugs.

| id | group | status | what was broken | killed by |
|---|---|---|---|---|
| C01 | conflict | KILLED | highest lane index wins instead of the lowest | bank:b2_seq, bank:b4_seq |
| C02 | conflict | KILLED | losing lane is never marked denied | bank:b2_seq, bank:b4_seq |
| C03 | conflict | KILLED | req_ready ignores the interlock: a denied lane believes it was accepted | bank:b2_seq, bank:b4_seq |
| C04 | conflict | KILLED | conflict event needs three requesters instead of two | bank:b2_seq, bank:b4_seq |
| C05 | conflict | KILLED | stall count is requesters, not requesters-1 | bank:b2_seq, bank:b4_seq |
| C06 | conflict | KILLED | bank writes lane 0's data whichever lane won | bank:b4_seq |
| C07 | conflict | KILLED | bank uses lane 0's byte enables whichever lane won | bank:b4_seq |
| C08 | conflict | KILLED | bank uses lane 0's write enable whichever lane won | bank:b4_seq |
| C09 | conflict | KILLED | rejected (invalid) requests enter the bank interlock | bank:b2_awx3, bank:b4_awx2 |
| C10 | conflict | KILLED | per-bank conflict status stuck low | bank:b2_seq, bank:b4_seq |
| C11 | conflict | KILLED | on a collision nobody is granted (all lanes denied) | bank:b2_seq, bank:b4_seq |
| C12 | conflict | KILLED | conflict counter never counts | bank:b2_seq, bank:b4_seq |
| C13 | conflict | KILLED | stall counter never counts | bank:b2_seq, bank:b4_seq |
| C14 | conflict | KILLED | bank address taken from lane 0 whichever lane won | bank:b4_seq |
