// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: tb_sf_sram_bank            (self-checking)
// Testbench for sf_sram_bank: NP request lanes, NB single-port banks.
//
// Verification structure
//   * BYTE-ACCURATE REFERENCE MODEL indexed by EXTERNAL BYTE ADDRESS (ref_b/ref_k):
//     it knows nothing about banks, so any mapping, aliasing or cross-bank bug
//     shows up as a data mismatch.  A byte whose value was never written (and
//     whose INIT_MODE gives no content) is "unknown": it is never assumed zero
//     and is not compared.
//   * CYCLE-EXACT SCOREBOARD (always @(posedge clk), samples the cycle that ends
//     at the edge): every cycle it recomputes, with plain integer / and %, the
//     expected decode of each lane, the expected same-bank interlock outcome and
//     compares req_ready of every lane; checks every lane's response (valid, kind,
//     error, ecode, ID, data on all known bytes, zero data otherwise) EVERY cycle,
//     so spurious, missing, late or misrouted responses fail; checks the
//     per-bank status (ready/busy/access/conflict) and ALL performance counters
//     against an independent event model.
//   * BACKDOOR PLACEMENT CHECK: peeks every bank array and verifies each stored
//     byte sits at the (bank, row) the mapping defines (no aliasing, no cross-
//     bank corruption), independent of the read path.
//   * CLOSED-FORM DIRECTED CHECKS read the DUT outputs directly (e.g. NP lanes
//     onto one bank must give exactly NP-1 conflict events and NP(NP-1)/2 stalls)
//     so the checker cannot simply agree with an RTL bug.
//   * Directed phases + constrained-random multi-lane traffic (hot banks, strides,
//     random gaps, invalid addresses, mid-traffic resets) + workload runs that
//     print SRAM_PERF lines (measured concurrency).
// Plusargs: +seed=<n> +nrand=<n> +nowl (skip the workload runs)
// Result line (same format as the SilicaFlux SRAM regressions):
//   SRAM_RESULT <PASS|FAIL> tb=<name> seed=<n> checks=<n> errors=<n>
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "sf_sram_bank_defs.svh"

module tb_sf_sram_bank;
  parameter int NB     = 4;
  parameter int NP     = NB;
  parameter int DW     = 32;
  parameter int BW     = 8;
  parameter int D      = 256;
  parameter int MAP    = `SF_SRAM_BANK_MAP_SEQ;
  parameter int BLK    = 1;
  parameter int STRICT = 0;
  parameter int LAT    = 1;
  parameter int WACK   = 1;
  parameter int IDW    = 4;
  parameter int INITM  = 0;
  parameter int AWX    = 0;           // address-port bits above the minimum (invalid addresses on a power-of-two capacity)
  parameter int NRAND  = 20000;
  parameter int CNTW   = 32;

  localparam int LANES = DW / BW;
  localparam int BPW   = LANES;
  localparam int CAPW  = NB * D;
  localparam int CAPB  = CAPW * BPW;
  localparam int AWMIN = $clog2(CAPB);
  localparam int AW    = AWMIN + AWX;
  localparam int NCHUNK = (DW + 31) / 32;
  localparam int QD    = 2048;
  localparam int QW    = 8 + IDW + DW + LANES + 1 + AW;
  localparam string TBNAME = "tb_sf_sram_bank";

  `include "tb_common.svh"

  // ---------------------------------------------------------------- DUT
  logic                    clk   = 1'b0;
  logic                    rst_n = 1'b1;
  logic [NP-1:0]           req_valid = '0;
  wire  [NP-1:0]           req_ready;
  logic [NP-1:0]           req_we    = '0;
  logic [NP*AW-1:0]        req_addr  = '0;
  logic [NP*LANES-1:0]     req_wmask = '0;
  logic [NP*DW-1:0]        req_wdata = '0;
  logic [NP*IDW-1:0]       req_id    = '0;
  wire  [NP-1:0]           rsp_valid, rsp_we, rsp_err;
  wire  [NP*DW-1:0]        rsp_rdata;
  wire  [NP*2-1:0]         rsp_ecode;
  wire  [NP*IDW-1:0]       rsp_id;
  wire  [NB-1:0]           st_ready, st_busy, st_access, st_conflict;
  logic                    perf_clear = 1'b0;
  wire  [CNTW-1:0]         perf_cycles, perf_err_range, perf_err_align;
  wire  [NB*CNTW-1:0]      perf_access, perf_ok, perf_err, perf_conflict, perf_stall, perf_busy, perf_idle;
  wire  [(NB+1)*CNTW-1:0]  perf_hist;

  sf_sram_bank #(
    .NUM_BANKS(NB), .NUM_PORTS(NP), .DATA_WIDTH(DW), .BYTE_WIDTH(BW), .BANK_DEPTH(D), .ADDR_WIDTH(AW),
    .MAP_MODE(MAP), .BLOCK_WORDS(BLK), .STRICT_ALIGN(STRICT), .READ_LATENCY(LAT), .WRITE_ACK(WACK),
    .ID_WIDTH(IDW), .INIT_MODE(INITM), .OOB_ASSERT(1), .PERF_EN(1), .CNT_W(CNTW)
  ) dut (.*);

  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;          // a real falling edge for the asynchronous reset

  // ---------------------------------------------------------------- bookkeeping
  string phase = "init";
  task automatic fail(input string s);
    tb_errors++;
    if (tb_errors <= tb_max_print) $display("SRAM_ERROR t=%0t [%s] %s", $time, phase, s);
  endtask
  `define CHK(c, s) begin tb_checks++; if (!(c)) fail(s); end
  task automatic phase_begin(input string n);
    phase = n;
    $display("SRAM_PHASE %s", n);
  endtask

  // ---------------------------------------------------------------- reference model (by external byte address)
  logic [BW-1:0] ref_b [CAPB];
  bit            ref_k [CAPB];

  function automatic logic [DW-1:0] pat_word(input int unsigned i);       // == sf_sram_array init_pattern
    logic [DW-1:0] w;
    logic [31:0]   h;
    w = '0;
    for (int k = 0; k < NCHUNK; k++) begin
      h = (32'(i) * 32'h9E3779B1) ^ (32'(k + 1) * 32'h85EBCA6B) ^ 32'hC2B2AE35;
      h = h ^ (h >> 15);
      h = h * 32'h2C1B3C6D;
      h = h ^ (h >> 12);
      for (int b = 0; b < 32; b++) if (k * 32 + b < DW) w[k * 32 + b] = h[b];
    end
    pat_word = w;
  endfunction

  // independent integer definition of the mapping (docs/02): word w -> (bank, local), and its inverse
  function automatic longint unsigned map_w(input longint unsigned w);
    longint unsigned b, blk, sub, sel, rb, bk, lc;
    b   = (MAP == `SF_SRAM_BANK_MAP_SEQ) ? 1 : BLK;
    blk = w / b;  sub = w % b;  sel = blk % NB;  rb = blk / NB;
    bk  = (MAP == `SF_SRAM_BANK_MAP_XOR) ? (sel ^ (rb % NB)) : sel;
    lc  = rb * b + sub;
    map_w = {bk[31:0], lc[31:0]};
  endfunction
  function automatic longint unsigned unmap_w(input int bank, input int loc);
    longint unsigned b, rb, sub, sel, blk;
    b   = (MAP == `SF_SRAM_BANK_MAP_SEQ) ? 1 : BLK;
    rb  = loc / b;  sub = loc % b;
    sel = (MAP == `SF_SRAM_BANK_MAP_XOR) ? (bank ^ (rb % NB)) : bank;
    blk = rb * NB + sel;
    unmap_w = blk * b + sub;
  endfunction
  function automatic longint unsigned addr_of(input int bank, input int loc, input int boff);
    addr_of = unmap_w(bank, loc) * BPW + boff;
  endfunction
  function automatic int bank_of(input longint unsigned a);
    longint unsigned m;
    m = map_w(a / BPW);
    bank_of = int'(m >> 32);
  endfunction
  function automatic int loc_of(input longint unsigned a);
    longint unsigned m;
    m = map_w(a / BPW);
    loc_of = int'(m & 64'hFFFF_FFFF);
  endfunction

  // expected decode of a byte address
  task automatic dec_exp(input longint unsigned a, output bit ok, output logic [1:0] ec, output int bank, output int loc);
    longint unsigned w, m;
    w = a / BPW;
    ok = 1'b1;  ec = `SF_SRAM_BANK_ERR_NONE;  bank = 0;  loc = 0;
    if (w >= CAPW) begin
      ok = 1'b0;  ec = `SF_SRAM_BANK_ERR_RANGE;
    end else begin
      m = map_w(w);  bank = int'(m >> 32);  loc = int'(m & 64'hFFFF_FFFF);
      if (STRICT != 0 && (a % BPW) != 0) begin ok = 1'b0; ec = `SF_SRAM_BANK_ERR_ALIGN; end
    end
  endtask

  task automatic ref_init();
    longint unsigned m;
    logic [DW-1:0] pw;
    for (int a = 0; a < CAPB; a++) begin
      ref_k[a] = (INITM == `SF_SRAM_INIT_ZERO) || (INITM == `SF_SRAM_INIT_PATTERN);
      ref_b[a] = '0;
      if (INITM == `SF_SRAM_INIT_PATTERN) begin
        m  = map_w(a / BPW);
        pw = pat_word(int'(m & 64'hFFFF_FFFF));
        ref_b[a] = pw[(a % BPW) * BW +: BW];
      end
    end
  endtask

  // ---------------------------------------------------------------- expectation pipelines (per lane, LAT slots)
  bit               ex_v  [NP*LAT];
  bit               ex_we [NP*LAT];
  bit               ex_er [NP*LAT];
  logic [1:0]       ex_ec [NP*LAT];
  logic [IDW-1:0]   ex_id [NP*LAT];
  logic [DW-1:0]    ex_dt [NP*LAT];
  logic [LANES-1:0] ex_dk [NP*LAT];
  int               n_pending = 0;

  // lane driver state
  logic [QW-1:0]    q_buf [NP*QD];
  int               q_head [NP], q_cnt [NP], gap_cnt [NP];
  bit               have_gap [NP];
  bit               lane_acc [NP];
  bit               l_busy [NP];
  int               last_nacc = 0, max_nacc = 0;
  longint           cyc_total = 0;

  // expected counters (independent event model)
  longint unsigned x_cycles, x_err_range, x_err_align;
  longint unsigned x_access [NB], x_ok [NB], x_conf [NB], x_stall [NB], x_busy [NB], x_idle [NB];
  longint unsigned x_hist [NB+1];
  logic [LAT:0]     acc_hist [NB];

  // per-cycle scratch of the monitor
  bit               m_ok [NP];
  logic [1:0]       m_ec [NP];
  int               m_bank [NP], m_loc [NP];
  bit               m_acc [NP];
  int               n_req_b [NB];
  bit               acc_ev [NB];

  task automatic model_reset();
    x_cycles = 0; x_err_range = 0; x_err_align = 0;
    for (int b = 0; b < NB; b++) begin
      x_access[b] = 0; x_ok[b] = 0; x_conf[b] = 0; x_stall[b] = 0; x_busy[b] = 0; x_idle[b] = 0; acc_hist[b] = '0;
    end
    for (int k = 0; k <= NB; k++) x_hist[k] = 0;
  endtask

  task automatic pipes_clear();
    for (int i = 0; i < NP * LAT; i++) ex_v[i] = 1'b0;
    n_pending = 0;
  endtask

  function automatic longint unsigned cnt_at(input logic [1023:0] v, input int idx);   // CNTW-bit field idx of a flat vector
    cnt_at = 64'(v[idx * CNTW +: CNTW]);
  endfunction

  // ---------------------------------------------------------------- the scoreboard
  task automatic mon_cycle();
    bit              lose;
    logic [DW-1:0]   rd;
    longint unsigned a, w;
    int              nacc, idx;
    logic [1023:0]   v;
    bit              t_ok;
    logic [1:0]      t_ec;
    int              t_bank, t_loc;

    cyc_total++;
    if (!rst_n) begin
      // reset cycle: the DUT must be quiet and its counters cleared
      `CHK(req_ready === '0, "req_ready must be 0 while rst_n=0");
      `CHK(rsp_valid === '0, "rsp_valid must be 0 while rst_n=0");
      `CHK(st_ready === '0, "st_ready must be 0 while rst_n=0");
      `CHK(perf_cycles === '0 && perf_err_range === '0 && perf_err_align === '0, "counters must be cleared by reset");
      pipes_clear();
      model_reset();
      for (int p = 0; p < NP; p++) lane_acc[p] = 1'b0;
    end else begin
      // ---- 1. expected decode and interlock
      for (int b = 0; b < NB; b++) begin n_req_b[b] = 0; acc_ev[b] = 1'b0; end
      for (int p = 0; p < NP; p++) begin
        a = 64'(req_addr[p*AW +: AW]);
        dec_exp(a, t_ok, t_ec, t_bank, t_loc);              // scalar temporaries: Icarus 12 mishandles array elements as task outputs
        m_ok[p] = t_ok;  m_ec[p] = t_ec;  m_bank[p] = t_bank;  m_loc[p] = t_loc;
      end
      for (int p = 0; p < NP; p++) begin
        lose = 1'b0;
        if (req_valid[p] && m_ok[p]) begin
          for (int q = 0; q < p; q++)
            if (req_valid[q] && m_ok[q] && m_bank[q] == m_bank[p]) lose = 1'b1;
          n_req_b[m_bank[p]] = n_req_b[m_bank[p]] + 1;
        end
        m_acc[p] = req_valid[p] && !lose;
        tb_checks++;
        if (req_ready[p] !== !lose)
          fail($sformatf("lane %0d req_ready=%b expected %b (valid=%b addr=%0h bank=%0d)", p, req_ready[p], !lose, req_valid[p], req_addr[p*AW +: AW], m_bank[p]));
      end
      // ---- 2. responses due this cycle
      for (int p = 0; p < NP; p++) begin
        idx = p * LAT;
        tb_checks++;
        if (rsp_valid[p] !== ex_v[idx])
          fail($sformatf("lane %0d rsp_valid=%b expected %b", p, rsp_valid[p], ex_v[idx]));
        else if (ex_v[idx]) begin
          `CHK(rsp_we[p] === ex_we[idx], $sformatf("lane %0d rsp_we=%b expected %b", p, rsp_we[p], ex_we[idx]));
          `CHK(rsp_err[p] === ex_er[idx], $sformatf("lane %0d rsp_err=%b expected %b", p, rsp_err[p], ex_er[idx]));
          `CHK(rsp_ecode[p*2 +: 2] === ex_ec[idx], $sformatf("lane %0d rsp_ecode=%0d expected %0d", p, rsp_ecode[p*2 +: 2], ex_ec[idx]));
          `CHK(rsp_id[p*IDW +: IDW] === ex_id[idx], $sformatf("lane %0d rsp_id=%0h expected %0h", p, rsp_id[p*IDW +: IDW], ex_id[idx]));
          rd = rsp_rdata[p*DW +: DW];
          if (!ex_we[idx] && !ex_er[idx]) begin
            for (int l = 0; l < LANES; l++) begin
              if (ex_dk[idx][l]) begin
                tb_checks++;
                if (rd[l*BW +: BW] !== ex_dt[idx][l*BW +: BW])
                  fail($sformatf("lane %0d read data byte %0d = %0h expected %0h", p, l, rd[l*BW +: BW], ex_dt[idx][l*BW +: BW]));
              end
            end
          end else begin
            `CHK(rd === '0, $sformatf("lane %0d rsp_rdata must be 0 for a non-read response, got %0h", p, rd));
          end
        end else begin
          `CHK(rsp_rdata[p*DW +: DW] === '0, $sformatf("lane %0d rsp_rdata must be 0 without a response", p));
        end
      end
      // ---- 3. expected per-bank events of THIS cycle
      for (int p = 0; p < NP; p++) if (m_acc[p] && m_ok[p]) acc_ev[m_bank[p]] = 1'b1;
      nacc = 0;
      for (int b = 0; b < NB; b++) begin
        acc_hist[b] = {acc_hist[b][LAT-1:0], acc_ev[b]};
        if (acc_ev[b]) nacc++;
      end
      last_nacc = nacc;
      if (nacc > max_nacc) max_nacc = nacc;
      for (int b = 0; b < NB; b++) begin
        `CHK(st_ready[b] === 1'b1, $sformatf("st_ready[%0d] must be 1 out of reset", b));
        `CHK(st_access[b] === acc_ev[b], $sformatf("st_access[%0d]=%b expected %b", b, st_access[b], acc_ev[b]));
        `CHK(st_conflict[b] === (n_req_b[b] >= 2), $sformatf("st_conflict[%0d]=%b expected %b (n_req=%0d)", b, st_conflict[b], n_req_b[b] >= 2, n_req_b[b]));
        `CHK(st_busy[b] === (|acc_hist[b]), $sformatf("st_busy[%0d]=%b expected %b", b, st_busy[b], |acc_hist[b]));
      end
      // ---- 4. counters: the DUT shows the events of all PREVIOUS cycles
      `CHK(perf_cycles === CNTW'(x_cycles), $sformatf("perf_cycles=%0d expected %0d", perf_cycles, x_cycles));
      `CHK(perf_err_range === CNTW'(x_err_range), $sformatf("perf_err_range=%0d expected %0d", perf_err_range, x_err_range));
      `CHK(perf_err_align === CNTW'(x_err_align), $sformatf("perf_err_align=%0d expected %0d", perf_err_align, x_err_align));
      v = 1024'(perf_hist);
      for (int k = 0; k <= NB; k++)
        `CHK(cnt_at(v, k) == x_hist[k], $sformatf("perf_hist[%0d]=%0d expected %0d", k, cnt_at(v, k), x_hist[k]));
      for (int b = 0; b < NB; b++) begin
        v = 1024'(perf_access);   `CHK(cnt_at(v, b) == x_access[b], $sformatf("perf_access[%0d]=%0d expected %0d", b, cnt_at(v, b), x_access[b]));
        v = 1024'(perf_ok);       `CHK(cnt_at(v, b) == x_ok[b],     $sformatf("perf_ok[%0d]=%0d expected %0d", b, cnt_at(v, b), x_ok[b]));
        v = 1024'(perf_err);      `CHK(cnt_at(v, b) == 0,           $sformatf("perf_err[%0d]=%0d expected 0", b, cnt_at(v, b)));
        v = 1024'(perf_conflict); `CHK(cnt_at(v, b) == x_conf[b],   $sformatf("perf_conflict[%0d]=%0d expected %0d", b, cnt_at(v, b), x_conf[b]));
        v = 1024'(perf_stall);    `CHK(cnt_at(v, b) == x_stall[b],  $sformatf("perf_stall[%0d]=%0d expected %0d", b, cnt_at(v, b), x_stall[b]));
        v = 1024'(perf_busy);     `CHK(cnt_at(v, b) == x_busy[b],   $sformatf("perf_busy[%0d]=%0d expected %0d", b, cnt_at(v, b), x_busy[b]));
        v = 1024'(perf_idle);     `CHK(cnt_at(v, b) == x_idle[b],   $sformatf("perf_idle[%0d]=%0d expected %0d", b, cnt_at(v, b), x_idle[b]));
      end
      // ---- 5. pop the response slot, shift the pipelines
      for (int p = 0; p < NP; p++) begin
        if (ex_v[p*LAT]) n_pending--;
        for (int s = 0; s < LAT - 1; s++) begin
          idx = p * LAT + s;
          ex_v[idx] = ex_v[idx+1];  ex_we[idx] = ex_we[idx+1];  ex_er[idx] = ex_er[idx+1];
          ex_ec[idx] = ex_ec[idx+1]; ex_id[idx] = ex_id[idx+1]; ex_dt[idx] = ex_dt[idx+1]; ex_dk[idx] = ex_dk[idx+1];
        end
        ex_v[p*LAT + LAT - 1] = 1'b0;
      end
      // ---- 6. apply the accepted requests: reference model + new expectations
      for (int p = 0; p < NP; p++) begin
        lane_acc[p] = lane_acc[p] | m_acc[p];
        if (m_acc[p]) begin
          a   = 64'(req_addr[p*AW +: AW]);
          w   = a / BPW;
          idx = p * LAT + LAT - 1;
          ex_id[idx] = req_id[p*IDW +: IDW];
          ex_we[idx] = req_we[p];
          ex_er[idx] = !m_ok[p];
          ex_ec[idx] = m_ec[p];
          ex_dt[idx] = '0;  ex_dk[idx] = '0;
          if (!m_ok[p]) begin
            ex_v[idx] = 1'b1;  n_pending++;                       // errors are always answered, also for posted writes
          end else if (req_we[p]) begin
            for (int l = 0; l < LANES; l++)
              if (req_wmask[p*LANES + l]) begin
                ref_b[w*BPW + l] = req_wdata[p*DW + l*BW +: BW];
                ref_k[w*BPW + l] = 1'b1;
              end
            ex_v[idx] = (WACK != 0);
            if (WACK != 0) n_pending++;
          end else begin
            for (int l = 0; l < LANES; l++) begin
              ex_dt[idx][l*BW +: BW] = ref_b[w*BPW + l];
              ex_dk[idx][l]          = ref_k[w*BPW + l];
            end
            ex_v[idx] = 1'b1;  n_pending++;
          end
        end
      end
      // ---- 7. counters: events of this cycle
      if (perf_clear) begin
        model_reset();
      end else begin
        x_cycles++;
        for (int p = 0; p < NP; p++)
          if (m_acc[p] && !m_ok[p]) begin
            if (m_ec[p] == `SF_SRAM_BANK_ERR_RANGE) x_err_range++;
            if (m_ec[p] == `SF_SRAM_BANK_ERR_ALIGN) x_err_align++;
          end
        for (int b = 0; b < NB; b++) begin
          if (acc_ev[b])          x_access[b]++;
          if (acc_hist[b][LAT])   x_ok[b]++;
          if (n_req_b[b] >= 2)  begin x_conf[b]++; x_stall[b] += n_req_b[b] - 1; end
          if (|acc_hist[b]) x_busy[b]++; else x_idle[b]++;
        end
        x_hist[last_nacc]++;
        clamp_counters();
      end
    end
  endtask

  // the DUT counters SATURATE at all-ones (they never wrap): the model does the same
  task automatic clamp_counters();
    longint unsigned mx;
    mx = (CNTW >= 63) ? 64'h7FFF_FFFF_FFFF_FFFF : ((64'd1 << CNTW) - 1);
    if (x_cycles > mx) x_cycles = mx;
    if (x_err_range > mx) x_err_range = mx;
    if (x_err_align > mx) x_err_align = mx;
    for (int b = 0; b < NB; b++) begin
      if (x_access[b] > mx) x_access[b] = mx;
      if (x_ok[b]     > mx) x_ok[b]     = mx;
      if (x_conf[b]   > mx) x_conf[b]   = mx;
      if (x_stall[b]  > mx) x_stall[b]  = mx;
      if (x_busy[b]   > mx) x_busy[b]   = mx;
      if (x_idle[b]   > mx) x_idle[b]   = mx;
    end
    for (int k = 0; k <= NB; k++) if (x_hist[k] > mx) x_hist[k] = mx;
  endtask

  always @(posedge clk) mon_cycle();

  // ---------------------------------------------------------------- lane driver (called by the test thread only)
  // NOTE (Verilator 5.020 --timing): a process that changes a DUT input vector by PART-SELECT assignment can
  // leave part of the downstream combinational logic stale.  Every DUT input vector is therefore built in a
  // temporary and assigned as a WHOLE vector (see docs/04_verification.md).
  task automatic drive_once();
    logic [QW-1:0]      e;
    logic [NP-1:0]      n_valid, n_we;
    logic [NP*AW-1:0]   n_addr;
    logic [NP*LANES-1:0] n_wmask;
    logic [NP*DW-1:0]   n_wdata;
    logic [NP*IDW-1:0]  n_id;
    n_valid = req_valid;  n_we = req_we;  n_addr = req_addr;  n_wmask = req_wmask;  n_wdata = req_wdata;  n_id = req_id;
    for (int p = 0; p < NP; p++) begin
      if (l_busy[p] && lane_acc[p]) begin           // accepted at the edge that just passed
        l_busy[p] = 1'b0;
        n_valid[p] = 1'b0;
      end
      lane_acc[p] = 1'b0;
      if (!l_busy[p] && q_cnt[p] > 0) begin
        e = q_buf[p*QD + q_head[p]];
        if (!have_gap[p]) begin gap_cnt[p] = int'(e[QW-1 -: 8]); have_gap[p] = 1'b1; end
        if (gap_cnt[p] == 0) begin
          n_valid[p] = 1'b1;
          n_addr[p*AW +: AW]        = e[AW-1:0];
          n_we[p]                   = e[AW];
          n_wmask[p*LANES +: LANES] = e[AW+1 +: LANES];
          n_wdata[p*DW +: DW]       = e[AW+1+LANES +: DW];
          n_id[p*IDW +: IDW]        = e[AW+1+LANES+DW +: IDW];
          l_busy[p] = 1'b1;
          have_gap[p] = 1'b0;
          q_head[p] = (q_head[p] + 1) % QD;
          q_cnt[p]--;
        end else gap_cnt[p]--;
      end
    end
    req_valid = n_valid;  req_we = n_we;  req_addr = n_addr;  req_wmask = n_wmask;  req_wdata = n_wdata;  req_id = n_id;
  endtask

  task automatic step();
    @(negedge clk);
    drive_once();
  endtask
  task automatic steps(input int n);
    for (int i = 0; i < n; i++) step();
  endtask

  function automatic bit lanes_idle();
    lanes_idle = 1'b1;
    for (int p = 0; p < NP; p++) if (q_cnt[p] != 0 || l_busy[p]) lanes_idle = 1'b0;
  endfunction

  int unsigned wd_limit = 5000000;
  task automatic run();                              // run until every queued request is accepted and answered
    int unsigned n;
    n = 0;
    step();
    while ((!lanes_idle() || n_pending != 0) && n <= wd_limit) begin
      step();
      n++;
    end
    if (n > wd_limit) fail("watchdog: run() did not drain");
    steps(1);
  endtask

  task automatic qpush(input int p, input bit we, input longint unsigned a, input logic [LANES-1:0] wm,
                       input logic [DW-1:0] wd, input int gap);
    logic [QW-1:0] e;
    while (q_cnt[p] >= QD) step();
    e = {8'(gap), IDW'(rnd32()), wd, wm, we, AW'(a)};
    q_buf[p*QD + ((q_head[p] + q_cnt[p]) % QD)] = e;
    q_cnt[p]++;
  endtask
  task automatic wr(input int p, input longint unsigned a, input logic [DW-1:0] wd, input logic [LANES-1:0] wm);
    qpush(p, 1'b1, a, wm, wd, 0);
  endtask
  // PRNG draws happen in statement order, never inside one expression: SV leaves the evaluation order of
  // side-effecting calls within an expression unspecified, and a seed must reproduce the same stimulus everywhere.
  task automatic wr_rnd(input int p, input longint unsigned a, input bit rnd_mask, input int gap);
    logic [DW-1:0]    d;
    logic [LANES-1:0] m;
    d = rv();
    m = rnd_mask ? rmask() : fullmask();
    qpush(p, 1'b1, a, m, d, gap);
  endtask
  task automatic rd(input int p, input longint unsigned a);
    qpush(p, 1'b0, a, '0, '0, 0);
  endtask
  task automatic flush_queues();
    for (int p = 0; p < NP; p++) begin q_cnt[p] = 0; q_head[p] = 0; have_gap[p] = 1'b0; l_busy[p] = 1'b0; lane_acc[p] = 1'b0; end
    req_valid = '0;
  endtask
  task automatic drop_lane(input int p);              // withdraw lane p's pending request without any effect
    logic [NP-1:0] t;
    q_cnt[p] = 0; q_head[p] = 0; l_busy[p] = 1'b0; have_gap[p] = 1'b0; lane_acc[p] = 1'b0;
    t = req_valid;  t[p] = 1'b0;  req_valid = t;
  endtask

  task automatic do_reset(input int n);
    @(negedge clk);
    rst_n = 1'b0;
    flush_queues();
    pipes_clear();
    repeat (n) @(negedge clk);
    rst_n = 1'b1;
    // first active cycle starts at the next posedge
  endtask

  task automatic clear_perf();
    @(negedge clk);
    perf_clear = 1'b1;
    @(negedge clk);
    perf_clear = 1'b0;
  endtask

  // ---------------------------------------------------------------- data helpers
  function automatic logic [DW-1:0] hw(input int unsigned a, input int unsigned s);       // lane-diverse deterministic word
    logic [NCHUNK*32-1:0] w;
    logic [31:0]          h;
    for (int k = 0; k < NCHUNK; k++) begin
      h = 32'(a) * 32'h9E3779B1 + 32'(s) * 32'h7F4A7C15 + 32'(k) * 32'h85EBCA6B + 32'h01234567;
      h = h ^ (h >> 16);  h = h * 32'h7FEB352D;  h = h ^ (h >> 15);  h = h * 32'h846CA68B;  h = h ^ (h >> 16);
      w[k*32 +: 32] = h;
    end
    hw = w[DW-1:0];
  endfunction
  function automatic logic [DW-1:0] rv();
    logic [1023:0] t;
    t = rnd_vec();
    rv = t[DW-1:0];
  endfunction
  function automatic logic [LANES-1:0] fullmask();
    fullmask = '1;
  endfunction
  function automatic logic [LANES-1:0] rmask();
    logic [31:0] r;
    r = rnd32();
    rmask = LANES'(r);
  endfunction
  function automatic longint unsigned rand_addr_inrange();
    rand_addr_inrange = 64'(rnd_below(CAPB));
  endfunction

  // ---------------------------------------------------------------- backdoor: peek one bank word
  int          bd_idx = 0;
  logic        bd_go  = 1'b0;
  logic [DW-1:0] bd_data [NB];
  for (genvar b = 0; b < NB; b++) begin : g_bd
    always @(bd_go) bd_data[b] = dut.u_array.g_bank[b].u_core.u_array.mem[bd_idx];
  end
  task automatic peek(input int b, input int i, output logic [DW-1:0] d);
    bd_idx = i;
    bd_go  = ~bd_go;
    #1;
    d = bd_data[b];
  endtask

  // every known reference byte must sit at its (bank, row) and nowhere else (physical placement, aliasing, corruption)
  task automatic verify_backdoor(input string tag);
    logic [DW-1:0] d;
    int bk, lc, bad;
    bad = 0;
    for (int w = 0; w < CAPW; w++) begin
      bk = bank_of(w * BPW);
      lc = loc_of(w * BPW);
      peek(bk, lc, d);
      for (int l = 0; l < LANES; l++) begin
        tb_checks++;
        if (ref_k[w*BPW + l] && d[l*BW +: BW] !== ref_b[w*BPW + l]) begin
          bad++;
          if (bad <= 4) fail($sformatf("%s: byte %0h (bank %0d row %0d lane %0d) holds %0h expected %0h", tag, w*BPW + l, bk, lc, l, d[l*BW +: BW], ref_b[w*BPW + l]));
        end
      end
    end
  endtask

  // read every word through the lanes (data is checked by the scoreboard)
  task automatic read_all(input int lanes_used);
    for (int w = 0; w < CAPW; w++) rd(w % lanes_used, 64'(w) * BPW);
    run();
  endtask

  // ---------------------------------------------------------------- directed phases
  function automatic longint unsigned pc(input logic [1023:0] v, input int i);
    pc = 64'(v[i * CNTW +: CNTW]);
  endfunction

  task automatic t_reset_basic();
    phase_begin("reset_basic");
    do_reset(3);
    steps(3);
    `CHK(perf_cycles <= 3, "counters restart from zero after reset");
    for (int b = 0; b < NB; b++) `CHK(st_ready[b] === 1'b1, "banks ready after reset");
  endtask

  // one lane, one op per cycle: every bank, every row
  task automatic t_every_bank();
    phase_begin("every_bank");
    for (int b = 0; b < NB; b++) begin
      for (int i = 0; i < D; i++) wr(0, addr_of(b, i, 0), hw(b * D + i, 1), fullmask());
      run();
      for (int i = 0; i < D; i++) rd(0, addr_of(b, i, 0));
      run();
    end
    verify_backdoor("every_bank");
  endtask

  // sequential words: bank placement is checked by the scoreboard (st_access) and the backdoor
  task automatic t_sequential();
    phase_begin("sequential_map");
    for (int w = 0; w < 4 * NB + 3; w++) wr(0, 64'(w) * BPW, hw(w, 2), fullmask());
    run();
    for (int w = 0; w < 4 * NB + 3; w++) rd(0, 64'(w) * BPW);
    run();
    verify_backdoor("sequential_map");
    if (MAP == `SF_SRAM_BANK_MAP_SEQ) begin     // the documented formula, spelled out
      for (int w = 0; w < 4 * NB; w++) begin
        `CHK(bank_of(64'(w) * BPW) == (w % NB), "SEQ: bank = word_index % NUM_BANKS");
        `CHK(loc_of(64'(w) * BPW) == (w / NB), "SEQ: local = word_index / NUM_BANKS");
      end
    end
  endtask

  // distinct banks in the same cycle: all served together
  task automatic t_parallel();
    int nl;
    nl = (NP < NB) ? NP : NB;
    phase_begin("parallel_independent");
    clear_perf();
    // NL writes in ONE cycle, lane p -> bank p
    for (int p = 0; p < nl; p++) wr(p, addr_of(p, 5, 0), hw(p, 3), fullmask());
    step();
    snap_check_all_granted(nl);
    run();
    for (int p = 0; p < nl; p++) rd(p, addr_of(p, 5, 0));
    step();
    snap_check_all_granted(nl);
    run();
    steps(LAT + 2);
    begin
      logic [1023:0] h, ac, cf, sl;
      h = 1024'(perf_hist); ac = 1024'(perf_access); cf = 1024'(perf_conflict); sl = 1024'(perf_stall);
      `CHK(pc(h, nl) == 2, $sformatf("hist[%0d] = %0d, expected 2 cycles with %0d concurrent banks", nl, pc(h, nl), nl));
      for (int b = 0; b < nl; b++) begin
        `CHK(pc(ac, b) == 2, $sformatf("bank %0d accesses = %0d expected 2", b, pc(ac, b)));
        `CHK(pc(cf, b) == 0 && pc(sl, b) == 0, "no conflict events for distinct banks");
      end
    end
    `CHK(max_nacc >= nl, $sformatf("peak concurrency %0d < %0d lanes", max_nacc, nl));
    // sustained: every lane streams to its own bank for 32 cycles, one access per bank per cycle
    clear_perf();
    for (int k = 0; k < 16; k++)
      for (int p = 0; p < nl; p++) wr(p, addr_of(p, k, 0), hw(p * 64 + k, 4), fullmask());
    run();
    steps(LAT + 2);
    begin
      logic [1023:0] h, cf, ac;
      h = 1024'(perf_hist); cf = 1024'(perf_conflict); ac = 1024'(perf_access);
      `CHK(pc(h, nl) == 16, $sformatf("sustained: hist[%0d] = %0d, expected 16", nl, pc(h, nl)));
      for (int b = 0; b < nl; b++) `CHK(pc(cf, b) == 0 && pc(ac, b) == 16, "sustained: 16 accesses and no conflict per bank");
    end
    verify_backdoor("parallel_independent");
  endtask

  task automatic snap_check_all_granted(input int nl);        // called right after a step(): the cycle is in flight
    #2;                                                       // combinational outputs settled (clk low phase)
    for (int p = 0; p < nl; p++) `CHK(req_ready[p] === 1'b1, $sformatf("independent banks: lane %0d must be granted", p));
    `CHK(int'($countones(st_access)) == nl, $sformatf("independent banks: %0d banks accessed, expected %0d", $countones(st_access), nl));
  endtask

  // same-bank contention: deterministic, lowest lane wins, closed-form counters
  task automatic t_conflict();
    int n;
    longint unsigned a0, a1;
    logic [1023:0] cf, sl, ac, h;
    phase_begin("same_bank_contention");
    // ---- (a) two lanes, one bank (needs NP >= 2)
    if (NP >= 2) begin
      clear_perf();
      a0 = addr_of(0, 10, 0);  a1 = addr_of(0, 11, 0);
      wr(0, a0, hw(10, 5), fullmask());
      wr(1, a1, hw(11, 5), fullmask());
      step();                                      // both present, same bank, same cycle
      #2;
      `CHK(req_ready[0] === 1'b1, "conflict: lowest lane (0) must be granted");
      `CHK(req_ready[1] === 1'b0, "conflict: lane 1 must be denied (stalled), not accepted");
      `CHK(st_conflict[0] === 1'b1, "conflict: st_conflict[0] must flag the collision");
      `CHK(st_access[0] === 1'b1 && int'($countones(st_access)) == 1, "conflict: exactly one access to the single port");
      step();
      #2;
      `CHK(req_ready[1] === 1'b1, "conflict: the denied lane is granted in the next cycle");
      `CHK(st_conflict[0] === 1'b0, "conflict: no collision once lane 0 is through");
      run();
      steps(LAT + 2);
      cf = 1024'(perf_conflict); sl = 1024'(perf_stall); ac = 1024'(perf_access); h = 1024'(perf_hist);
      `CHK(pc(cf, 0) == 1, $sformatf("2 lanes/1 bank: conflict events = %0d expected 1", pc(cf, 0)));
      `CHK(pc(sl, 0) == 1, $sformatf("2 lanes/1 bank: stalled lane-cycles = %0d expected 1", pc(sl, 0)));
      `CHK(pc(ac, 0) == 2, $sformatf("2 lanes/1 bank: accesses = %0d expected 2", pc(ac, 0)));
      `CHK(pc(h, 1) == 2 && pc(h, 2) == 0, "2 lanes/1 bank: never 2 banks active (one bank, one port)");
      rd(0, a0); rd(1, a1); run();                 // both writes must have landed
    end
    // ---- (b) all lanes onto bank 0: serialised one per cycle, closed form
    n = NP;
    if (n >= 2) begin
      clear_perf();
      for (int p = 0; p < n; p++) wr(p, addr_of(0, 20 + p, 0), hw(p, 6), fullmask());
      step();
      for (int c = 0; c < n; c++) begin
        #2;
        for (int p = 0; p < n; p++) `CHK(req_ready[p] === (p <= c), $sformatf("%0d lanes/1 bank, cycle %0d: lane %0d ready=%b expected %b", n, c, p, req_ready[p], (p <= c)));
        if (c != n - 1) step();
      end
      run();
      steps(LAT + 2);
      cf = 1024'(perf_conflict); sl = 1024'(perf_stall); ac = 1024'(perf_access); h = 1024'(perf_hist);
      `CHK(pc(cf, 0) == n - 1,        $sformatf("%0d lanes/1 bank: conflict events = %0d expected %0d", n, pc(cf, 0), n - 1));
      `CHK(pc(sl, 0) == n * (n - 1) / 2, $sformatf("%0d lanes/1 bank: stalls = %0d expected %0d", n, pc(sl, 0), n * (n - 1) / 2));
      `CHK(pc(ac, 0) == n,            $sformatf("%0d lanes/1 bank: accesses = %0d expected %0d", n, pc(ac, 0), n));
      `CHK(pc(h, 1) == n,             $sformatf("%0d lanes/1 bank: %0d cycles with exactly one bank active, got %0d", n, n, pc(h, 1)));
      for (int p = 0; p < n; p++) rd(p, addr_of(0, 20 + p, 0));
      run();
    end
    // ---- (c) two writers, same word: priority order, the LATER accepted write wins
    if (NP >= 2) begin
      a0 = addr_of(0, 40, 0);
      wr(0, a0, hw(1, 7), fullmask());
      wr(1, a0, hw(2, 7), fullmask());
      run();
      rd(0, a0); run();                            // scoreboard: must read lane 1's data (accepted one cycle after lane 0's)
    end
    // ---- (d) a read and a write to the same word in the same cycle: the read is served first (lower lane), sees the OLD data
    if (NP >= 2) begin
      a0 = addr_of(0, 41, 0);
      wr(0, a0, hw(3, 8), fullmask()); run();
      rd(0, a0);
      wr(1, a0, hw(4, 8), fullmask());
      run();
      rd(1, a0); run();
    end
    // ---- (e) a denied request that is withdrawn has no effect
    if (NP >= 2) begin
      a0 = addr_of(0, 42, 0);  a1 = addr_of(0, 43, 0);
      wr(0, a1, hw(5, 9), fullmask()); run();
      wr(0, a0, hw(6, 9), fullmask());
      qpush(1, 1'b1, a1, fullmask(), hw(7, 9), 0);   // lane 1 loses to lane 0 ...
      step();
      #2;
      `CHK(req_ready[1] === 1'b0, "withdrawn-request test: lane 1 must be denied");
      drop_lane(1);                                  // ... and withdraws
      run();
      rd(0, a1); rd(0, a0); run();                   // a1 still holds hw(5,9); a0 holds hw(6,9)
    end
    // ---- (f) lanes on distinct banks while others collide elsewhere
    if (NP >= 3 && NB >= 2) begin
      clear_perf();
      wr(0, addr_of(0, 50, 0), hw(8, 10), fullmask());
      wr(1, addr_of(0, 51, 0), hw(9, 10), fullmask());    // collides with lane 0
      wr(2, addr_of(1, 50, 0), hw(10, 10), fullmask());   // independent bank
      step();
      #2;
      `CHK(req_ready[0] === 1'b1 && req_ready[1] === 1'b0 && req_ready[2] === 1'b1, "mixed: collision on bank 0 must not stall the lane on bank 1");
      `CHK(int'($countones(st_access)) == 2, "mixed: bank 0 and bank 1 both accessed");
      run();
    end
    verify_backdoor("same_bank_contention");
  endtask

  task automatic t_byte_writes();
    longint unsigned a;
    logic [DW-1:0] base, d;
    phase_begin("partial_byte_writes");
    a = addr_of(NB - 1, 3, 0);
    // every single lane over a known word, then every mask combination (exhaustive up to 8 lanes)
    for (int l = 0; l < LANES; l++) begin
      wr(0, a, hw(l, 11), fullmask());
      d = rv();
      wr(0, a, d, LANES'(1) << l);
      rd(0, a);
      run();
    end
    for (int m = 0; m < ((LANES <= 8) ? (1 << LANES) : 512); m++) begin
      base = rv();  d = rv();
      wr(0, a, base, fullmask());
      wr(0, a, d, (LANES <= 8) ? LANES'(m) : ((m < LANES) ? (LANES'(1) << m) : ((m < 2 * LANES) ? ~(LANES'(1) << (m - LANES)) : rmask())));
      rd(0, a);
      run();
    end
    wr(0, a, hw(99, 12), fullmask());
    wr(0, a, rv(), '0);                              // zero strobes: a legal write that changes nothing
    rd(0, a);
    run();
    // neighbouring words and other banks untouched, partial writes from several lanes at once
    for (int p = 0; p < NP; p++) wr(p, addr_of(p % NB, 100 + p, 0), hw(p, 13), fullmask());
    run();
    for (int p = 0; p < NP; p++) wr_rnd(p, addr_of(p % NB, 100 + p, 0), 1'b1, 0);
    run();
    for (int p = 0; p < NP; p++) rd(p, addr_of(p % NB, 100 + p, 0));
    run();
    // byte offsets inside a word do not change which word is written (non-strict) - exercised in the invalid phase for strict
    verify_backdoor("partial_byte_writes");
  endtask

  task automatic t_back_to_back();
    longint unsigned a, b2;
    phase_begin("back_to_back");
    a = addr_of(0, 60, 0);  b2 = addr_of(NB - 1, 60, 0);
    // write, read, write, read ... on one bank, one op per cycle, every cycle
    for (int i = 0; i < 40; i++) begin
      wr(0, a, hw(i, 14), fullmask());
      rd(0, a);                                       // read-after-write, next cycle: must see the NEW data
    end
    run();
    // read, write, read: write-after-read returns the OLD data
    for (int i = 0; i < 20; i++) begin
      rd(0, a); wr(0, a, hw(i + 100, 14), fullmask()); rd(0, a);
    end
    run();
    // write, write, read: the later write wins
    for (int i = 0; i < 20; i++) begin
      wr(0, a, hw(i, 15), fullmask()); wr(0, a, hw(i, 16), fullmask()); rd(0, a);
    end
    run();
    // alternate banks every cycle on one lane
    for (int i = 0; i < 64; i++) begin
      wr(0, (i % 2) ? a : b2, hw(i, 17), fullmask());
      rd(0, (i % 2) ? a : b2);
    end
    run();
    // all lanes streaming back-to-back to their own banks, every cycle
    for (int i = 0; i < 64; i++)
      for (int p = 0; p < NP; p++) begin
        wr(p, addr_of(p % NB, 70 + (i % 16), 0), hw(p * 1000 + i, 18), rmask());
        rd(p, addr_of(p % NB, 70 + (i % 16), 0));
      end
    run();
    verify_backdoor("back_to_back");
  endtask

  task automatic t_reset_behaviour();
    longint unsigned a;
    phase_begin("reset");
    // contents written before a reset must survive it (the array is never reset)
    for (int i = 0; i < 8; i++) wr(0, addr_of(i % NB, 80 + i, 0), hw(i, 19), fullmask());
    run();
    // reset with responses in flight and requests presented
    for (int p = 0; p < NP; p++) wr(p, addr_of(p % NB, 90, 0), hw(p, 20), fullmask());
    for (int p = 0; p < NP; p++) rd(p, addr_of(p % NB, 90, 0));
    step(); step();
    do_reset(2);                                      // drops everything in flight; queues flushed; model re-synchronised
    // a request presented during reset is not accepted
    @(negedge clk);
    rst_n = 1'b0;
    begin
      logic [NP-1:0]       t_v, t_we;
      logic [NP*AW-1:0]    t_a;
      logic [NP*LANES-1:0] t_m;
      logic [NP*DW-1:0]    t_d;
      t_v = '0;  t_v[0] = 1'b1;  t_we = '0;  t_we[0] = 1'b1;
      t_a = '0;  t_a[0*AW +: AW] = AW'(addr_of(0, 99, 0));
      t_m = '0;  t_m[0*LANES +: LANES] = '1;
      t_d = '0;  t_d[0*DW +: DW] = DW'(64'hDEAD_BEEF_DEAD_BEEF);
      req_valid = t_v;  req_we = t_we;  req_addr = t_a;  req_wmask = t_m;  req_wdata = t_d;
    end
    #2;
    `CHK(req_ready === '0, "no lane may be ready during reset");
    @(negedge clk);
    req_valid = '0;
    rst_n = 1'b1;
    steps(LAT + 3);
    // everything written before must still be readable (and unknown bytes stay unknown, never zero)
    read_all(NP);
    verify_backdoor("after_reset");
    clear_perf();
    `CHK(perf_cycles === '0 || perf_cycles <= 1, "perf_clear clears the counters");
  endtask

  task automatic t_invalid();
    longint unsigned a;
    int nerr;
    phase_begin("invalid_addresses");
    // valid data everywhere first, so a stray write would be visible
    for (int w = 0; w < CAPW; w++) wr(w % NP, 64'(w) * BPW, hw(w, 21), fullmask());
    run();
    clear_perf();
    nerr = 0;
    for (int p = 0; p < NP; p++) begin
      // first invalid address, one past, far above, every power of two above the capacity, all ones
      if (CAPB + BPW + 1 < (64'd1 << AW)) begin
        wr_rnd(p, CAPB, 1'b0, 0);                    nerr++;
        rd(p, CAPB);                                 nerr++;
        wr_rnd(p, CAPB + BPW, 1'b0, 0);              nerr++;
        rd(p, CAPB + BPW + (BPW > 1 ? 1 : 0));       nerr++;
        for (int k = 0; k < AW; k++)
          if ((64'd1 << k) >= CAPB) begin
            wr_rnd(p, 64'd1 << k, 1'b0, 0);            nerr++;
            rd(p, (64'd1 << k) | 64'd1);               nerr++;
          end
        wr_rnd(p, (64'd1 << AW) - 1, 1'b0, 0);       nerr++;
        rd(p, (64'd1 << AW) - 1);                    nerr++;
      end
      // the last valid address is fine
      rd(p, CAPB - BPW);
    end
    run();
    steps(LAT + 2);
    if (CAPB + BPW + 1 < (64'd1 << AW)) begin
      `CHK(int'(perf_err_range) == nerr, $sformatf("perf_err_range = %0d expected %0d", perf_err_range, nerr));
      `CHK(perf_err_align === '0, "no ALIGN errors expected here");
    end
    // misaligned in-range addresses: floor division (non-strict) or ALIGN errors (strict)
    if (BPW > 1) begin
      for (int p = 0; p < NP; p++) begin
        a = addr_of(p % NB, 130 + p, 0);
        wr(p, a + 1, hw(p, 22), fullmask());
        rd(p, a + BPW - 1);
        wr(p, a + (BPW / 2), hw(p, 23), '0);
      end
      run();
    end
    // errors interleaved with valid traffic on every lane: valid traffic is unaffected
    for (int i = 0; i < 100; i++)
      for (int p = 0; p < NP; p++) begin
        longint unsigned r;
        if ((i + p) % 3 == 0 && CAPB + (64'd1 << (AW > 16 ? 16 : AW)) < (64'd1 << AW)) begin
          r = 64'(rnd_below(1 << (AW > 16 ? 16 : AW)));
          wr_rnd(p, CAPB + r, 1'b0, 0);
        end
        else if ((i + p) % 3 == 1) wr_rnd(p, addr_of((i + p) % NB, 140 + (i % 8), 0), 1'b1, 0);
        else rd(p, addr_of((i + 2 * p) % NB, 140 + (i % 8), 0));
      end
    run();
    verify_backdoor("invalid_addresses");
    read_all(NP);
  endtask

  task automatic t_random(input int nops);
    int kind, p, o, gap, r;
    bit is_wr;
    longint unsigned a;
    phase_begin("random_traffic");
    clear_perf();
    for (int i = 0; i < nops; i++) begin
      p    = rnd_below(NP);
      kind = rnd_below(100);
      if (kind < 3 && CAPB + (64'd1 << (AW > 20 ? 20 : AW)) < (64'd1 << AW)) begin             // invalid
        r = rnd_below(1 << (AW > 20 ? 20 : AW));
        a = CAPB + 64'(r);
      end else if (kind < 40) begin                                                                // anywhere
        r = rnd_below(CAPW);
        o = rnd_pct(30) ? rnd_below(BPW) : 0;
        a = 64'(r) * BPW + 64'(o);
      end else if (kind < 65) begin                                                                // hot bank 0
        r = rnd_below(D);
        o = rnd_pct(30) ? rnd_below(BPW) : 0;
        a = addr_of(0, r, o);
      end else if (kind < 80) begin                                                                // few rows: heavy same-word reuse
        r = rnd_below(NB);
        o = rnd_below(8);
        a = addr_of(r, o, 0);
      end else if (kind < 90) begin                                                                // stride NB words
        r = rnd_below(CAPW / NB);
        a = (64'(r) * NB) * BPW;
      end else a = 64'(i % CAPW) * BPW;                                                            // sequential
      is_wr = rnd_pct(55);
      gap   = rnd_pct(15) ? rnd_below(4) : 0;
      if (is_wr) wr_rnd(p, a, 1'b1, gap);
      else       qpush(p, 1'b0, a, '0, '0, gap);
      if (rnd_below(5000) == 0) begin run(); do_reset(1 + rnd_below(3)); steps(2); end     // occasional reset inside traffic
    end
    run();
    verify_backdoor("random_traffic");
    read_all(NP);
    verify_backdoor("random_traffic_final");
  endtask

  // one bank at a time rewritten while every other bank is checked for corruption
  task automatic t_cross_bank();
    phase_begin("cross_bank_isolation");
    for (int w = 0; w < CAPW; w++) wr(w % NP, 64'(w) * BPW, hw(w, 30), fullmask());
    run();
    verify_backdoor("cross_bank_baseline");
    for (int b = 0; b < NB; b++) begin
      for (int i = 0; i < D; i++) wr(i % NP, addr_of(b, i, 0), hw(b * 7919 + i, 31), fullmask());
      run();
      verify_backdoor($sformatf("cross_bank_after_bank_%0d", b));
    end
    read_all(NP);
  endtask

  // final relations that hold for ANY traffic (checked against the DUT counters directly)
  task automatic t_counter_relations();
    logic [1023:0] ac, ok_, er, bz, id, h;
    longint unsigned sum_ac, sum_k, sum_h, cyc;
    phase_begin("counter_relations");
    steps(LAT + 3);
    ac = 1024'(perf_access); ok_ = 1024'(perf_ok); er = 1024'(perf_err); bz = 1024'(perf_busy); id = 1024'(perf_idle); h = 1024'(perf_hist);
    cyc = 64'(perf_cycles);
    if (CNTW < 24) begin
      // small counters: after this much traffic they must have SATURATED (stuck at all-ones), never wrapped
      `CHK(perf_cycles === {CNTW{1'b1}}, $sformatf("perf_cycles=%0d, expected saturation at %0d", perf_cycles, (1 << CNTW) - 1));
    end else begin
      sum_ac = 0; sum_k = 0; sum_h = 0;
      for (int b = 0; b < NB; b++) begin
        `CHK(pc(bz, b) + pc(id, b) == cyc, $sformatf("bank %0d: busy+idle = %0d, cycles = %0d", b, pc(bz, b) + pc(id, b), cyc));
        `CHK(pc(ok_, b) == pc(ac, b), $sformatf("bank %0d: after drain every access completed OK (%0d vs %0d)", b, pc(ok_, b), pc(ac, b)));
        `CHK(pc(er, b) == 0, "no bank errors for decoded addresses");
        sum_ac += pc(ac, b);
      end
      for (int k = 0; k <= NB; k++) begin sum_h += pc(h, k); sum_k += k * pc(h, k); end
      `CHK(sum_h == cyc, $sformatf("sum(hist) = %0d, cycles = %0d", sum_h, cyc));
      `CHK(sum_k == sum_ac, $sformatf("sum(k*hist[k]) = %0d, sum(access) = %0d", sum_k, sum_ac));
    end
  endtask

  // ---------------------------------------------------------------- workloads (measured concurrency)
  task automatic run_workload(input string name, input int nper);
    longint unsigned c0, ops;
    logic [1023:0] ac, cf, sl, h;
    longint unsigned tot_conf, tot_stall, tot_acc, c_end;
    int r_w;
    flush_queues();
    clear_perf();
    steps(2);
    c0 = cyc_total;
    ops = 0;
    for (int i = 0; i < nper; i++)
      for (int p = 0; p < NP; p++) begin
        longint unsigned a;
        case (name)
          "unit":    a = 64'(p + i * NP) % CAPW;                                  // striped unit stride
          "stride":  a = (64'(p + i * NP) * NB) % CAPW;                           // every access a multiple of NUM_BANKS words
          "random":  begin r_w = rnd_below(CAPW); a = 64'(r_w); end
          "hot":     begin
                       if (rnd_pct(50)) begin r_w = rnd_below(D);    a = unmap_w(0, r_w); end
                       else             begin r_w = rnd_below(CAPW); a = 64'(r_w); end
                     end
          "samebank":a = unmap_w(0, (p * 7 + i) % D);
          "region":  a = (64'(p) * D + i) % CAPW;                                 // lane p streams its own contiguous region
          default:   a = 0;
        endcase
        if (rnd_pct(30)) wr_rnd(p, a * BPW, 1'b0, 0);
        else             qpush(p, 1'b0, a * BPW, '0, '0, 0);
        ops++;
      end
    run();
    steps(LAT + 2);
    ac = 1024'(perf_access); cf = 1024'(perf_conflict); sl = 1024'(perf_stall); h = 1024'(perf_hist);
    tot_conf = 0; tot_stall = 0; tot_acc = 0;
    for (int b = 0; b < NB; b++) begin tot_conf += pc(cf, b); tot_stall += pc(sl, b); tot_acc += pc(ac, b); end
    c_end = pc(h, 0);
    $display("SRAM_PERF wl=%s nb=%0d np=%0d map=%0d blk=%0d ops=%0d accesses=%0d cycles=%0d active_cycles=%0d conflict_events=%0d stalled_lane_cycles=%0d peak_banks=%0d hist=%s",
             name, NB, NP, MAP, BLK, ops, tot_acc, perf_cycles, perf_cycles - c_end, tot_conf, tot_stall, max_nacc, hist_str(h));
  endtask

  function automatic string hist_str(input logic [1023:0] h);
    string s;
    s = "";
    for (int k = 0; k <= NB; k++) s = {s, $sformatf("%0d%s", pc(h, k), (k == NB) ? "" : ",")};
    hist_str = s;
  endfunction

  // ---------------------------------------------------------------- main
  int nrand_i;
  initial begin
    tb_seed_init();
    if (!$value$plusargs("nrand=%d", nrand_i)) nrand_i = NRAND;
    if (!$value$plusargs("maxprint=%d", tb_max_print)) tb_max_print = 20;
    if ($test$plusargs("vcd")) begin $dumpfile("tb_sf_sram_bank.vcd"); $dumpvars(0, tb_sf_sram_bank); end
    for (int p = 0; p < NP; p++) begin q_head[p] = 0; q_cnt[p] = 0; gap_cnt[p] = 0; have_gap[p] = 1'b0; lane_acc[p] = 1'b0; l_busy[p] = 1'b0; end
    for (int i = 0; i < NP * LAT; i++) ex_v[i] = 1'b0;
    ref_init();
    model_reset();
    $display("SRAM_INFO bank nb=%0d np=%0d dw=%0d bw=%0d d=%0d map=%0d blk=%0d strict=%0d lat=%0d wack=%0d idw=%0d initm=%0d aw=%0d capacity_bytes=%0d",
             NB, NP, DW, BW, D, MAP, BLK, STRICT, LAT, WACK, IDW, INITM, AW, CAPB);

    // ---- stage order of the brief: reset, then conflicts and parallelism are validated BEFORE anything is scaled
    t_reset_basic();
    t_every_bank();
    t_sequential();
    t_parallel();
    t_conflict();
    t_byte_writes();
    t_back_to_back();
    t_reset_behaviour();
    t_invalid();
    t_cross_bank();
    t_random(nrand_i);
    t_counter_relations();
    if (!$test$plusargs("nowl")) begin
      phase_begin("workloads");
      run_workload("unit",     400);
      run_workload("stride",   400);
      run_workload("region",   400);
      run_workload("random",   400);
      run_workload("hot",      400);
      run_workload("samebank", 400);
    end
    steps(LAT + 4);
    tb_finish(TBNAME);
  end

  // global watchdog
  initial begin
    #200_000_000;
    fail("global timeout");
    tb_finish(TBNAME);
  end
endmodule

`default_nettype wire
