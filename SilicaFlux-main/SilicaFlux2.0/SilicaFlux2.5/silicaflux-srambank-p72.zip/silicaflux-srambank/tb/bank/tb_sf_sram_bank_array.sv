// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: tb_sf_sram_bank_array      (self-checking)
// Testbench for the per-bank interface sf_sram_bank_array: every bank has its
// OWN enable, local word address, write enable, byte mask, write data and ID, and
// all of them are driven independently in the SAME cycle.
//   * per-bank byte-accurate reference model (never-written bytes are unknown);
//   * cycle-exact scoreboard on every bank, every cycle: b_rsp_valid / we / err /
//     id / data (known bytes), b_ready, b_busy, ev_access / ev_ok / ev_err;
//   * a bank is single-port: at most ONE access per bank per cycle is expressed,
//     and the scoreboard asserts exactly one response per accepted access;
//   * invalid local addresses (BANK_DEPTH not a power of two) are answered with
//     b_rsp_err for reads and for writes, also when writes are posted, and never
//     corrupt a valid word;
//   * reset mid-traffic drops in-flight responses and keeps the contents.
// Whole-vector input driving (Verilator 5.020 --timing part-select quirk, see
// docs/04_verification.md).
// Result line: SRAM_RESULT <PASS|FAIL> tb=tb_sf_sram_bank_array seed=.. checks=.. errors=..
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "sf_sram_bank_defs.svh"

module tb_sf_sram_bank_array;
  parameter int NB    = 4;
  parameter int DW    = 32;
  parameter int BW    = 8;
  parameter int D     = 128;
  parameter int LAT   = 1;
  parameter int WACK  = 1;
  parameter int IDW   = 6;
  parameter int INITM = 0;
  parameter int NCYC  = 20000;

  localparam int LANES = DW / BW;
  localparam int LAW   = $clog2(D);
  localparam int NADDR = 1 << LAW;               // addresses the port can carry
  localparam string TBNAME = "tb_sf_sram_bank_array";

  `include "tb_common.svh"

  logic                    clk = 1'b0, rst_n = 1'b1;
  logic [NB-1:0]           b_req = '0, b_we = '0;
  logic [NB*LAW-1:0]       b_addr = '0;
  logic [NB*LANES-1:0]     b_wmask = '0;
  logic [NB*DW-1:0]        b_wdata = '0;
  logic [NB*IDW-1:0]       b_id = '0;
  wire  [NB-1:0]           b_ready, b_rsp_valid, b_rsp_we, b_rsp_err, b_busy, ev_access, ev_ok, ev_err;
  wire  [NB*DW-1:0]        b_rsp_rdata;
  wire  [NB*IDW-1:0]       b_rsp_id;

  sf_sram_bank_array #(.NUM_BANKS(NB), .DATA_WIDTH(DW), .BYTE_WIDTH(BW), .BANK_DEPTH(D), .READ_LATENCY(LAT),
                       .WRITE_ACK(WACK), .ID_WIDTH(IDW), .INIT_MODE(INITM), .OOB_ASSERT(0)) dut (.*);

  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;

  string phase = "init";
  task automatic fail(input string s);
    tb_errors++;
    if (tb_errors <= tb_max_print) $display("SRAM_ERROR t=%0t [%s] %s", $time, phase, s);
  endtask
  `define CHK(c, s) begin tb_checks++; if (!(c)) fail(s); end

  // ---------------------------------------------------------------- reference: bytes per bank
  logic [BW-1:0] rb [NB*D*LANES];
  bit            rk [NB*D*LANES];

  // expectation pipelines, per bank, LAT slots (slot 0 = due now)
  bit               xv [NB*LAT];
  bit               xw [NB*LAT];
  bit               xe [NB*LAT];
  logic [IDW-1:0]   xi [NB*LAT];
  logic [DW-1:0]    xd [NB*LAT];
  logic [LANES-1:0] xk [NB*LAT];
  logic [LAT:0]     hist [NB];                   // bit k: accessed k cycles ago
  int               n_pending = 0;
  longint           n_acc_total = 0, n_resp_total = 0, n_err_total = 0, n_conc_cycles = 0;
  int               max_conc = 0;

  task automatic exp_reset();
    for (int i = 0; i < NB * LAT; i++) xv[i] = 1'b0;
    for (int b = 0; b < NB; b++) hist[b] = '0;
    n_pending = 0;
  endtask

  function automatic logic [DW-1:0] pat_word(input int unsigned i);
    logic [DW-1:0] w;
    logic [31:0]   h;
    w = '0;
    for (int k = 0; k < (DW + 31) / 32; k++) begin
      h = (32'(i) * 32'h9E3779B1) ^ (32'(k + 1) * 32'h85EBCA6B) ^ 32'hC2B2AE35;
      h = h ^ (h >> 15);  h = h * 32'h2C1B3C6D;  h = h ^ (h >> 12);
      for (int b = 0; b < 32; b++) if (k * 32 + b < DW) w[k * 32 + b] = h[b];
    end
    pat_word = w;
  endfunction

  task automatic ref_init();
    logic [DW-1:0] pw;
    for (int b = 0; b < NB; b++)
      for (int a = 0; a < D; a++) begin
        pw = pat_word(a);
        for (int l = 0; l < LANES; l++) begin
          rk[(b*D + a)*LANES + l] = (INITM == `SF_SRAM_INIT_ZERO) || (INITM == `SF_SRAM_INIT_PATTERN);
          rb[(b*D + a)*LANES + l] = (INITM == `SF_SRAM_INIT_PATTERN) ? pw[l*BW +: BW] : '0;
        end
      end
  endtask

  // ---------------------------------------------------------------- scoreboard
  logic [NB*LAW-1:0] a_snap;
  task automatic mon_cycle();
    int unsigned a;
    int idx, nacc;
    bit acc, ok_a, err_e, busy_e, okev;
    logic [DW-1:0] rd;
    if (!rst_n) begin
      `CHK(b_rsp_valid === '0, "b_rsp_valid must be 0 in reset")
      `CHK(b_ready === '0, "b_ready must be 0 in reset")
      `CHK(ev_access === '0 && ev_ok === '0 && ev_err === '0 && b_busy === '0, "events and busy must be 0 in reset")
      exp_reset();
    end else begin
      nacc = 0;
      for (int b = 0; b < NB; b++) begin
        idx = b * LAT;
        `CHK(b_ready[b] === 1'b1, $sformatf("bank %0d b_ready", b))
        // ---- response due now
        tb_checks++;
        if (b_rsp_valid[b] !== xv[idx]) fail($sformatf("bank %0d b_rsp_valid=%b expected %b", b, b_rsp_valid[b], xv[idx]));
        else if (xv[idx]) begin
          `CHK(b_rsp_we[b] === xw[idx], $sformatf("bank %0d b_rsp_we=%b expected %b", b, b_rsp_we[b], xw[idx]))
          `CHK(b_rsp_err[b] === xe[idx], $sformatf("bank %0d b_rsp_err=%b expected %b", b, b_rsp_err[b], xe[idx]))
          `CHK(b_rsp_id[b*IDW +: IDW] === xi[idx], $sformatf("bank %0d b_rsp_id=%0h expected %0h", b, b_rsp_id[b*IDW +: IDW], xi[idx]))
          if (!xw[idx] && !xe[idx]) begin
            rd = b_rsp_rdata[b*DW +: DW];
            for (int l = 0; l < LANES; l++)
              if (xk[idx][l]) begin
                tb_checks++;
                if (rd[l*BW +: BW] !== xd[idx][l*BW +: BW])
                  fail($sformatf("bank %0d read byte %0d = %0h expected %0h", b, l, rd[l*BW +: BW], xd[idx][l*BW +: BW]));
              end
          end
          n_resp_total++;
          if (xe[idx]) n_err_total++;
        end
        // ---- this cycle's access
        acc = b_req[b];
        a = int'(b_addr[b*LAW +: LAW]);
        hist[b] = {hist[b][LAT-1:0], acc};
        busy_e = |hist[b];
        okev   = hist[b][LAT];
        // completion event of the access issued LAT cycles ago: ok unless it was an invalid-address access
        `CHK(ev_access[b] === acc, $sformatf("bank %0d ev_access=%b expected %b", b, ev_access[b], acc))
        `CHK(b_busy[b] === busy_e, $sformatf("bank %0d b_busy=%b expected %b", b, b_busy[b], busy_e))
        if (acc) nacc++;
        // ---- pop / shift
        if (xv[idx]) n_pending--;
        for (int s = 0; s < LAT - 1; s++) begin
          xv[idx+s] = xv[idx+s+1]; xw[idx+s] = xw[idx+s+1]; xe[idx+s] = xe[idx+s+1];
          xi[idx+s] = xi[idx+s+1]; xd[idx+s] = xd[idx+s+1]; xk[idx+s] = xk[idx+s+1];
        end
        xv[idx+LAT-1] = 1'b0;
        // ---- apply the access to the reference and queue its response
        if (acc) begin
          n_acc_total++;
          ok_a = (a < D);
          idx = b * LAT + LAT - 1;
          xi[idx] = b_id[b*IDW +: IDW];
          xw[idx] = b_we[b];
          xe[idx] = !ok_a;
          xd[idx] = '0;  xk[idx] = '0;
          if (!ok_a) begin
            xv[idx] = 1'b1;  n_pending++;                       // errors are never silent, also for posted writes
          end else if (b_we[b]) begin
            for (int l = 0; l < LANES; l++)
              if (b_wmask[b*LANES + l]) begin
                rb[(b*D + a)*LANES + l] = b_wdata[b*DW + l*BW +: BW];
                rk[(b*D + a)*LANES + l] = 1'b1;
              end
            xv[idx] = (WACK != 0);
            if (WACK != 0) n_pending++;
          end else begin
            for (int l = 0; l < LANES; l++) begin
              xd[idx][l*BW +: BW] = rb[(b*D + a)*LANES + l];
              xk[idx][l]          = rk[(b*D + a)*LANES + l];
            end
            xv[idx] = 1'b1;  n_pending++;
          end
        end
      end
      // completion events: ev_ok / ev_err of the access issued LAT cycles ago (hist bit LAT, before this cycle's shift)
      if (nacc > max_conc) max_conc = nacc;
      if (nacc >= 2) n_conc_cycles++;
    end
  endtask
  always @(posedge clk) mon_cycle();

  // ev_ok / ev_err are checked with their own small model: the access of LAT cycles ago, valid or not
  logic [NB-1:0] acc_q [LAT+1];
  logic [NB-1:0] bad_q [LAT+1];
  always @(posedge clk) begin
    if (rst_n) begin
      for (int b = 0; b < NB; b++) begin
        // issue-time record
        // (shift below, evaluated after the checks so that index LAT-1 is the access of LAT cycles ago)
        `CHK(ev_ok[b] === (acc_q[LAT-1][b] && !bad_q[LAT-1][b]), $sformatf("bank %0d ev_ok=%b expected %b", b, ev_ok[b], (acc_q[LAT-1][b] && !bad_q[LAT-1][b])))
        `CHK(ev_err[b] === (acc_q[LAT-1][b] && bad_q[LAT-1][b]), $sformatf("bank %0d ev_err=%b expected %b", b, ev_err[b], (acc_q[LAT-1][b] && bad_q[LAT-1][b])))
      end
      for (int k = LAT; k > 0; k--) begin acc_q[k] <= acc_q[k-1]; bad_q[k] <= bad_q[k-1]; end
      for (int b = 0; b < NB; b++) begin
        acc_q[0][b] <= b_req[b];
        bad_q[0][b] <= (int'(b_addr[b*LAW +: LAW]) >= D);
      end
    end else begin
      for (int k = 0; k <= LAT; k++) begin acc_q[k] <= '0; bad_q[k] <= '0; end
    end
  end

  // ---------------------------------------------------------------- stimulus: whole-vector drives at negedge
  logic [NB-1:0]       n_req, n_we;
  logic [NB*LAW-1:0]   n_addr;
  logic [NB*LANES-1:0] n_wmask;
  logic [NB*DW-1:0]    n_wdata;
  logic [NB*IDW-1:0]   n_id;

  task automatic lane_clear();
    n_req = '0; n_we = '0; n_addr = '0; n_wmask = '0; n_wdata = '0; n_id = '0;
  endtask
  task automatic lane_set(input int b, input bit we, input int unsigned a, input logic [DW-1:0] wd, input logic [LANES-1:0] wm);
    logic [31:0] r;
    n_req[b] = 1'b1;  n_we[b] = we;
    n_addr[b*LAW +: LAW] = LAW'(a);
    n_wmask[b*LANES +: LANES] = wm;
    n_wdata[b*DW +: DW] = wd;
    r = rnd32();
    n_id[b*IDW +: IDW] = IDW'(r);
  endtask
  task automatic cycle();                          // present the staged cycle, wait for it to complete
    @(negedge clk);
    b_req = n_req; b_we = n_we; b_addr = n_addr; b_wmask = n_wmask; b_wdata = n_wdata; b_id = n_id;
    lane_clear();
  endtask
  task automatic idle(input int n);
    repeat (n) begin lane_clear(); cycle(); end
  endtask
  task automatic drain();
    int unsigned n;
    n = 0;
    lane_clear(); cycle();
    while (n_pending != 0 && n < 100) begin cycle(); n++; end
    cycle();
  endtask
  task automatic do_reset(input int n);
    @(negedge clk);
    rst_n = 1'b0;
    b_req = '0;
    exp_reset();
    repeat (n) @(negedge clk);
    rst_n = 1'b1;
  endtask

  function automatic logic [DW-1:0] hw(input int unsigned a, input int unsigned s);
    logic [31:0] h;
    h = 32'(a) * 32'h9E3779B1 + 32'(s) * 32'h7F4A7C15 + 32'h01234567;
    h = h ^ (h >> 16);  h = h * 32'h7FEB352D;  h = h ^ (h >> 15);  h = h * 32'h846CA68B;  h = h ^ (h >> 16);
    hw = {((DW + 31) / 32){h}};
  endfunction
  function automatic logic [LANES-1:0] rmask();
    logic [31:0] r;
    r = rnd32();
    rmask = LANES'(r);
  endfunction

  // ---------------------------------------------------------------- phases
  task automatic t_basic();
    phase = "independent_banks_same_cycle";
    // all banks written in ONE cycle with different addresses and data
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 3 + b, hw(b, 1), '1);
    cycle();
    #1;                                           // the events are combinational on the request: let them settle
    `CHK(ev_access === {NB{1'b1}}, "all banks must be accessed in the same cycle")
    // mixed: half read, half write, different rows, same cycle
    lane_clear();
    for (int b = 0; b < NB; b++) begin
      if (b % 2 == 0) lane_set(b, 1'b0, 3 + b, '0, '0);
      else            lane_set(b, 1'b1, 10 + b, hw(b, 2), '1);
    end
    cycle();
    drain();
    // the same address in every bank is four different words
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 7, hw(100 + b, 3), '1);
    cycle();
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b0, 7, '0, '0);
    cycle();
    drain();
    `CHK(max_conc == NB, $sformatf("peak concurrency %0d, expected %0d independent single-port accesses", max_conc, NB))
  endtask

  task automatic t_every_bank_every_row();
    phase = "every_bank_every_row";
    for (int a = 0; a < D; a++) begin
      lane_clear();
      for (int b = 0; b < NB; b++) lane_set(b, 1'b1, a, hw(a * NB + b, 4), '1);
      cycle();
    end
    for (int a = 0; a < D; a++) begin
      lane_clear();
      for (int b = 0; b < NB; b++) lane_set(b, 1'b0, a, '0, '0);
      cycle();
    end
    drain();
  endtask

  task automatic t_bytes();
    phase = "byte_enables";
    for (int m = 0; m < ((LANES <= 8) ? (1 << LANES) : 256); m++) begin
      lane_clear();
      for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 20, hw(m, 5 + b), '1);
      cycle();
      lane_clear();
      for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 20, hw(m + 77, 9 + b), (LANES <= 8) ? LANES'(m) : rmask());
      cycle();
      lane_clear();
      for (int b = 0; b < NB; b++) lane_set(b, 1'b0, 20, '0, '0);
      cycle();
    end
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 21, hw(b, 6), '1);
    cycle();
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 21, hw(b + 50, 6), '0);     // zero strobes: changes nothing
    cycle();
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b0, 21, '0, '0);
    cycle();
    drain();
  endtask

  task automatic t_invalid_local();
    phase = "invalid_local_address";
    if (D != NADDR) begin
      for (int a = D; a < NADDR; a++) begin
        lane_clear();
        for (int b = 0; b < NB; b++) lane_set(b, (a + b) % 2, a, hw(a, 7), '1);
        cycle();
      end
      lane_clear();
      for (int b = 0; b < NB; b++) lane_set(b, 1'b0, D - 1, '0, '0);           // the last valid word is fine
      cycle();
      drain();
    end
  endtask

  task automatic t_reset();
    phase = "reset";
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 30 + b, hw(b, 8), '1);
    cycle();
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b0, 30 + b, '0, '0);
    cycle();
    do_reset(2);                                  // read responses in flight are dropped
    idle(2);
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b0, 30 + b, '0, '0);   // the contents survived the reset
    cycle();
    drain();
  endtask

  // requests PRESENTED while rst_n is low must be ignored: no access event, no busy, no response, no state change
  task automatic t_request_in_reset();
    phase = "request_during_reset";
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b1, 40, hw(b, 31), '1);
    cycle();
    drain();                                         // known contents at row 40 of every bank
    @(negedge clk);
    rst_n = 1'b0;
    exp_reset();
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, (b % 2) == 0, 40, hw(b + 500, 32), '1);   // writes AND reads, held through the reset
    b_req = n_req; b_we = n_we; b_addr = n_addr; b_wmask = n_wmask; b_wdata = n_wdata; b_id = n_id;
    lane_clear();
    repeat (3) @(negedge clk);
    b_req = '0;
    rst_n = 1'b1;
    idle(2);
    lane_clear();
    for (int b = 0; b < NB; b++) lane_set(b, 1'b0, 40, '0, '0);                       // the writes made during reset left no trace
    cycle();
    drain();
  endtask

  task automatic t_random(input int n);
    int unsigned a;
    logic [31:0] r, r2;
    logic [DW-1:0] wdv;
    logic [LANES-1:0] wmv;
    phase = "random_bank_traffic";
    for (int i = 0; i < n; i++) begin
      lane_clear();
      for (int b = 0; b < NB; b++) begin
        r = rnd32();
        if (r[7:0] < 160) begin                                  // ~62%: this bank is accessed this cycle
          if (r[15:8] < 6 && D != NADDR) a = D + (int'(r[23:16]) % (NADDR - D));    // invalid
          else if (r[15:8] < 100) a = int'(r[23:16]) % 8;           // few rows: heavy reuse
          else a = int'(r[23:16]) % D;
          r2  = rnd32();
          wdv = {((DW + 31) / 32){r2}} ^ DW'(r << 3);
          wmv = rmask();
          lane_set(b, r[24], a, wdv, wmv);
        end
      end
      cycle();
      if (rnd_below(4000) == 0) do_reset(1 + rnd_below(3));
    end
    drain();
  endtask

  task automatic t_final();
    phase = "final_readback";
    for (int a = 0; a < D; a++) begin
      lane_clear();
      for (int b = 0; b < NB; b++) lane_set(b, 1'b0, a, '0, '0);
      cycle();
    end
    drain();
  endtask

  int ncyc_i;
  initial begin
    tb_seed_init();
    if (!$value$plusargs("ncyc=%d", ncyc_i)) ncyc_i = NCYC;
    for (int k = 0; k <= LAT; k++) begin acc_q[k] = '0; bad_q[k] = '0; end
    lane_clear();
    ref_init();
    exp_reset();
    $display("SRAM_INFO array nb=%0d dw=%0d bw=%0d d=%0d lat=%0d wack=%0d idw=%0d initm=%0d", NB, DW, BW, D, LAT, WACK, IDW, INITM);
    do_reset(3);
    idle(2);
    t_basic();
    t_every_bank_every_row();
    t_bytes();
    t_invalid_local();
    t_reset();
    t_request_in_reset();
    t_random(ncyc_i);
    t_final();
    idle(LAT + 3);
    `CHK(n_acc_total > 1000, "enough accesses were exercised")
    `CHK(n_resp_total > 500, "enough responses were observed")
    $display("SRAM_PERF array accesses=%0d responses=%0d error_responses=%0d multi_bank_cycles=%0d peak_banks=%0d", n_acc_total, n_resp_total, n_err_total, n_conc_cycles, max_conc);
    tb_finish(TBNAME);
  end
  initial begin
    #50_000_000;
    fail("global timeout");
    tb_finish(TBNAME);
  end
endmodule

`default_nettype wire
