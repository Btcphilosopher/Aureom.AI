// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: tb_sf_sram_bank_addr_decode     (self-checking)
// Exhaustive proof, per configuration, that the address mapping is
//   * correct     : equals the integer / and % definition (docs/02) for every word,
//   * injective   : no two words land on the same (bank, local)   -> no aliasing,
//   * surjective  : every (bank, local) of the supported capacity is hit exactly
//                   once                                           -> full coverage,
//   * invertible  : sf_sram_bank_addr_unmap(decode(a)) == a and
//                   decode(unmap(bank, local)) == (bank, local) for every pair,
//   * bounded     : every address at or above the capacity is RANGE-rejected,
//   * aligned     : STRICT_ALIGN flags exactly the misaligned in-range addresses.
// +dump=<file> additionally writes `<addr_hex> <ok> <err> <bank> <local> <off>`
// for model/sf_bank_map.py --compare (the third, independent implementation).
// Result line: SRAM_RESULT <PASS|FAIL> tb=tb_sf_sram_bank_addr_decode seed=.. checks=.. errors=..
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "sf_sram_bank_defs.svh"

module tb_sf_sram_bank_addr_decode;
  parameter int NB     = 4;
  parameter int D      = 256;
  parameter int BPW    = 4;
  parameter int MODE   = `SF_SRAM_BANK_MAP_SEQ;
  parameter int BLK    = 1;
  parameter int STRICT = 0;
  parameter int AW     = $clog2(NB * D * BPW);

  localparam int CAPW = NB * D;
  localparam int CAPB = CAPW * BPW;
  localparam int BW   = $clog2(NB);
  localparam int LAW  = $clog2(D);
  localparam int WIW  = $clog2(CAPW);
  localparam int OFFX = (BPW > 1) ? $clog2(BPW) : 1;
  localparam string TBNAME = "tb_sf_sram_bank_addr_decode";

  `include "tb_common.svh"

  // ---------------------------------------------------------------- DUTs
  logic [AW-1:0]   addr = '0;
  wire             ok;
  wire  [1:0]      err;
  wire  [BW-1:0]   bank;
  wire  [LAW-1:0]  lw;
  wire  [OFFX-1:0] off;

  sf_sram_bank_addr_decode #(.NUM_BANKS(NB), .BANK_DEPTH(D), .BYTES_PER_WORD(BPW), .ADDR_WIDTH(AW),
                        .MAP_MODE(MODE), .BLOCK_WORDS(BLK), .STRICT_ALIGN(STRICT)) dut (
    .addr, .ok, .err_code(err), .bank, .local_word(lw), .byte_off(off));

  logic [BW-1:0]   ub = '0;
  logic [LAW-1:0]  ul = '0;
  wire  [WIW-1:0]  uw;
  wire  [AW-1:0]   ua;
  sf_sram_bank_addr_unmap #(.NUM_BANKS(NB), .BANK_DEPTH(D), .BYTES_PER_WORD(BPW), .ADDR_WIDTH(AW),
                       .MAP_MODE(MODE), .BLOCK_WORDS(BLK)) u_unmap (
    .bank(ub), .local_word(ul), .word_index(uw), .byte_addr(ua));

  wire             ok2;
  wire  [1:0]      err2;
  wire  [BW-1:0]   bank2;
  wire  [LAW-1:0]  lw2;
  wire  [OFFX-1:0] off2;
  sf_sram_bank_addr_decode #(.NUM_BANKS(NB), .BANK_DEPTH(D), .BYTES_PER_WORD(BPW), .ADDR_WIDTH(AW),
                        .MAP_MODE(MODE), .BLOCK_WORDS(BLK), .STRICT_ALIGN(STRICT)) dut2 (
    .addr(ua), .ok(ok2), .err_code(err2), .bank(bank2), .local_word(lw2), .byte_off(off2));

  // ---------------------------------------------------------------- independent integer model
  task automatic tb_map(input int unsigned w, output int unsigned bk, output int unsigned lc);
    int unsigned b, blk, sub, sel, rb;
    b   = (MODE == `SF_SRAM_BANK_MAP_SEQ) ? 1 : BLK;
    blk = w / b;
    sub = w % b;
    sel = blk % NB;
    rb  = blk / NB;
    bk  = (MODE == `SF_SRAM_BANK_MAP_XOR) ? (sel ^ (rb % NB)) : sel;
    lc  = rb * b + sub;
  endtask

  int fd = 0;
  int unsigned seen [CAPW];
  int          n_oor_checked = 0;
  int          n_align_checked = 0;

  task automatic probe(input logic [AW-1:0] a);
    addr = a;
    #1;
    if (fd != 0) $fdisplay(fd, "%0h %0d %0d %0d %0d %0d", a, ok, err, bank, lw, off);
  endtask

  task automatic check_oor(input logic [AW-1:0] a);
    probe(a);
    tb_check(!ok && err == `SF_SRAM_BANK_ERR_RANGE,
             $sformatf("addr %0h >= capacity %0d must be RANGE-rejected (ok=%0d err=%0d)", a, CAPB, ok, err));
    n_oor_checked++;
  endtask

  initial begin
    int unsigned bk, lc;
    logic [AW-1:0] a;
    logic [63:0] big;
    string dumpf;
    tb_seed_init();
    if ($value$plusargs("dump=%s", dumpf)) fd = $fopen(dumpf, "w");
    for (int i = 0; i < CAPW; i++) seen[i] = 0;

    // ---- every word, aligned and (when BPW > 1) with the maximum byte offset
    for (int unsigned w = 0; w < CAPW; w++) begin
      tb_map(w, bk, lc);
      for (int o = 0; o < ((BPW > 1) ? 2 : 1); o++) begin
        a = AW'(w * BPW + ((o == 0) ? 0 : (BPW - 1)));
        probe(a);
        if (o == 0 || STRICT == 0) begin
          tb_check(ok && err == `SF_SRAM_BANK_ERR_NONE, $sformatf("word %0d (off %0d) must be ok (err=%0d)", w, o, err));
          tb_check(bank == BW'(bk) && lw == LAW'(lc),
                   $sformatf("word %0d: rtl bank/local = %0d/%0d, definition = %0d/%0d", w, bank, lw, bk, lc));
        end else begin
          tb_check(!ok && err == `SF_SRAM_BANK_ERR_ALIGN, $sformatf("word %0d misaligned must be ALIGN (ok=%0d err=%0d)", w, ok, err));
          n_align_checked++;
        end
        if (BPW > 1) tb_check(off == OFFX'((o == 0) ? 0 : (BPW - 1)), $sformatf("word %0d byte offset %0d", w, off));
        if (o == 0) begin
          tb_check(bank < BW'(NB) || NB == (1 << BW), $sformatf("bank %0d out of range", bank));
          tb_check(int'(lw) < D, $sformatf("local word %0d >= BANK_DEPTH", lw));
          if (int'(bank) < NB && int'(lw) < D) begin
            // coverage of the physical space: index by (bank, local)
            if (seen[int'(bank) * D + int'(lw)] != 0) tb_check(1'b0, $sformatf("ALIAS: word %0d re-hits bank %0d local %0d", w, bank, lw));
            seen[int'(bank) * D + int'(lw)]++;
          end
          // invertibility, forward direction
          ub = bank; ul = lw; #1;
          tb_check(uw == WIW'(w) && ua == a, $sformatf("unmap(decode(%0h)) = word %0d addr %0h, expected word %0d", a, uw, ua, w));
        end
      end
    end
    // ---- surjective: every physical (bank, local) was hit exactly once
    begin
      int missing, aliased;
      missing = 0; aliased = 0;
      for (int i = 0; i < CAPW; i++) begin
        if (seen[i] == 0) missing++;
        if (seen[i] > 1)  aliased++;
      end
      tb_check(missing == 0, $sformatf("%0d physical words never addressed (capacity not covered)", missing));
      tb_check(aliased == 0, $sformatf("%0d physical words addressed twice (aliasing)", aliased));
    end
    // ---- inverse direction: every (bank, local) -> address -> same (bank, local)
    for (int b = 0; b < NB; b++) begin
      for (int l = 0; l < D; l++) begin
        ub = BW'(b); ul = LAW'(l); #1;
        tb_check(ok2 && bank2 == BW'(b) && lw2 == LAW'(l) && off2 == '0,
                 $sformatf("decode(unmap(%0d,%0d)) = ok%0d bank %0d local %0d", b, l, ok2, bank2, lw2));
      end
    end
    // ---- out of range: first invalid address and everything just above, every single high bit, all ones, random
    for (int unsigned k = 0; k < 4096 && (CAPB + k) < (64'd1 << AW); k++) check_oor(AW'(CAPB + k));
    for (int k = 0; k < AW; k++) begin
      big = 64'd1 << k;
      if (big >= CAPB) begin
        check_oor(AW'(big));
        check_oor(AW'(big | 64'(rnd32() & ((1 << k) - 1))));
        check_oor(AW'(big | 64'd1));
      end
    end
    if (((64'd1 << AW) - 1) >= CAPB) check_oor('1);
    for (int i = 0; i < 4000; i++) begin
      big = {32'd0, rnd32()} & ((64'd1 << AW) - 1);
      if (big >= CAPB) check_oor(AW'(big));
    end
    // ---- last valid word and first invalid word, explicitly
    probe(AW'(CAPB - 1));
    tb_check((STRICT == 0 && BPW > 1) ? ok : (BPW == 1 ? ok : (!ok && err == `SF_SRAM_BANK_ERR_ALIGN)), "last byte of the capacity");
    probe(AW'(CAPB - BPW));
    tb_check(ok, "last aligned word of the capacity must be ok");
    if (fd != 0) $fclose(fd);
    $display("SRAM_INFO decode nb=%0d d=%0d bpw=%0d mode=%0d blk=%0d strict=%0d aw=%0d cap_words=%0d oor_checked=%0d align_checked=%0d",
             NB, D, BPW, MODE, BLK, STRICT, AW, CAPW, n_oor_checked, n_align_checked);
    tb_finish(TBNAME);
  end
endmodule

`default_nettype wire
