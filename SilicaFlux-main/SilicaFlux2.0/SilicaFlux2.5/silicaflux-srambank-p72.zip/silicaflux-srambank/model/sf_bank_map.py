#!/usr/bin/env python3
"""Executable reference of the SRAMBank address mapping (docs/02_address_mapping.md).

Deliberately written with plain integer division and modulo -- no bit slicing -- so that it is an
independent implementation of the contract, not a transliteration of sf_sram_bank_addr_decode.sv.

  w         = byte_address // BYTES_PER_WORD            (word index; floor division)
  blk       = w // B           sub = w % B              (B = BLOCK_WORDS, 1 for SEQ)
  sel       = blk % NUM_BANKS  rowb = blk // NUM_BANKS
  SEQ/BLOCK : bank = sel
  XOR       : bank = sel ^ (rowb % NUM_BANKS)           (NUM_BANKS power of two)
  local     = rowb * B + sub
  supported byte range: [0, NUM_BANKS * BANK_DEPTH * BYTES_PER_WORD)

Usage
  python3 model/sf_bank_map.py --selftest                 exhaustive proof for the whole config table
  python3 model/sf_bank_map.py --compare DUMP CFGSPEC     compare an RTL decoder dump (tb_sf_sram_bank_addr_decode +dump=)
  python3 model/sf_bank_map.py --stride NB D BPW MODE [B] bank-spread of strided streams (documentation aid)
Python >= 3.10, standard library only.
"""
from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass

SEQ, BLOCK, XOR = 0, 1, 2
MODE_NAMES = {SEQ: "SEQ", BLOCK: "BLOCK", XOR: "XOR"}
ERR_NONE, ERR_RANGE, ERR_ALIGN = 0, 1, 2


def clog2(n: int) -> int:
    return 0 if n <= 1 else (n - 1).bit_length()


def is_pow2(n: int) -> bool:
    return n > 0 and (n & (n - 1)) == 0


@dataclass(frozen=True)
class BankMap:
    num_banks: int
    bank_depth: int
    bytes_per_word: int = 4
    mode: int = SEQ
    block_words: int = 1
    strict_align: bool = False
    addr_width: int | None = None          # None -> minimum

    # ------------------------------------------------------------ derived
    @property
    def cap_words(self) -> int:
        return self.num_banks * self.bank_depth

    @property
    def cap_bytes(self) -> int:
        return self.cap_words * self.bytes_per_word

    @property
    def b(self) -> int:
        return 1 if self.mode == SEQ else self.block_words

    @property
    def aw(self) -> int:
        return clog2(self.cap_bytes) if self.addr_width is None else self.addr_width

    def validate(self) -> None:
        """Same rules as the elaboration checks in sf_sram_bank_addr_decode.sv."""
        errs = []
        if not 2 <= self.num_banks <= 64: errs.append("NUM_BANKS must be in 2..64")
        if self.bank_depth < 2: errs.append("BANK_DEPTH must be >= 2")
        if self.cap_words > 1 << 24: errs.append("capacity over 2**24 words")
        if not (1 <= self.bytes_per_word <= 128 and is_pow2(self.bytes_per_word)): errs.append("BYTES_PER_WORD")
        if self.mode not in MODE_NAMES: errs.append("MAP_MODE")
        elif self.mode != SEQ:
            if not (self.block_words >= 1 and is_pow2(self.block_words)): errs.append("BLOCK_WORDS not pow2")
            elif self.block_words > self.bank_depth or self.bank_depth % self.block_words: errs.append("BLOCK_WORDS must divide BANK_DEPTH")
        if self.mode == XOR and not is_pow2(self.num_banks): errs.append("XOR needs power-of-two NUM_BANKS")
        if self.aw < clog2(self.cap_bytes) or self.aw > 32: errs.append("ADDR_WIDTH")
        if errs:
            raise ValueError("; ".join(errs))

    # ------------------------------------------------------------ mapping
    def decode(self, addr: int):
        """-> (ok, err_code, bank, local_word, byte_off); bank/local are None unless the address is in range."""
        if not 0 <= addr < (1 << self.aw):
            raise ValueError("address does not fit the port")
        off = addr % self.bytes_per_word
        w = addr // self.bytes_per_word
        if w >= self.cap_words:
            return (False, ERR_RANGE, None, None, off)
        b = self.b
        blk, sub = w // b, w % b
        sel, rowb = blk % self.num_banks, blk // self.num_banks
        bank = sel ^ (rowb % self.num_banks) if self.mode == XOR else sel
        local = rowb * b + sub
        if self.strict_align and off:
            return (False, ERR_ALIGN, bank, local, off)
        return (True, ERR_NONE, bank, local, off)

    def encode(self, bank: int, local: int) -> int:
        """Inverse: (bank, local) -> word index."""
        b = self.b
        rowb, sub = local // b, local % b
        sel = bank ^ (rowb % self.num_banks) if self.mode == XOR else bank
        return (rowb * self.num_banks + sel) * b + sub

    # ------------------------------------------------------------ proofs
    def check_bijection(self) -> dict:
        """Exhaustive: every word -> distinct in-range (bank, local); every (bank, local) is hit once; inverse round-trips."""
        self.validate()
        seen = [[0] * self.bank_depth for _ in range(self.num_banks)]
        for w in range(self.cap_words):
            ok, err, bank, local, _ = self.decode(w * self.bytes_per_word)
            assert ok and err == ERR_NONE, (w, err)
            assert 0 <= bank < self.num_banks and 0 <= local < self.bank_depth, (w, bank, local)
            seen[bank][local] += 1
            assert self.encode(bank, local) == w, ("inverse", w, bank, local)
        missing = sum(1 for r in seen for c in r if c == 0)
        aliased = sum(1 for r in seen for c in r if c > 1)
        assert missing == 0 and aliased == 0, (missing, aliased)
        # out-of-range: first invalid word, last representable address, every high-bit pattern
        for a in {self.cap_bytes, (1 << self.aw) - 1, *(1 << k for k in range(clog2(self.cap_bytes), self.aw))}:
            if a >= self.cap_bytes and a < (1 << self.aw):
                ok, err, *_ = self.decode(a)
                assert not ok and err == ERR_RANGE, ("range", a)
        return {"words": self.cap_words, "banks": self.num_banks, "depth": self.bank_depth,
                "bank_hits": [sum(r) for r in seen]}

    # ------------------------------------------------------------ analysis aid
    def banks_touched(self, start_word: int, stride_words: int, n: int) -> int:
        return len({self.decode(((start_word + i * stride_words) % self.cap_words) * self.bytes_per_word)[2] for i in range(n)})


# --------------------------------------------------------------------------- self-test table
def selftest_table():
    t = []
    for nb in (2, 4, 8, 16):                                     # the four initial configurations
        for bpw in (4, 8):
            t.append(BankMap(nb, 256, bpw, SEQ))
            t.append(BankMap(nb, 256, bpw, BLOCK, 4))
            t.append(BankMap(nb, 256, bpw, BLOCK, 256))          # contiguous regions
            t.append(BankMap(nb, 256, bpw, XOR, 1))
            t.append(BankMap(nb, 256, bpw, XOR, 8))
    t += [BankMap(4, 1024, 4, SEQ), BankMap(16, 1024, 4, XOR),   # the sizes the synthesis reports use
          BankMap(4, 1000, 4, SEQ), BankMap(4, 1000, 4, BLOCK, 8), BankMap(2, 300, 4, SEQ), BankMap(8, 96, 4, BLOCK, 32),
          BankMap(3, 100, 4, SEQ), BankMap(5, 64, 4, SEQ), BankMap(6, 128, 8, BLOCK, 16), BankMap(7, 32, 4, SEQ),
          BankMap(12, 64, 4, BLOCK, 4), BankMap(4, 256, 1, SEQ), BankMap(4, 256, 4, SEQ, addr_width=20),
          BankMap(4, 256, 4, SEQ, strict_align=True), BankMap(2, 128, 4, XOR, 2, True, 14)]
    return t


def cfg_str(m: BankMap) -> str:
    return (f"NB={m.num_banks} D={m.bank_depth} BPW={m.bytes_per_word} {MODE_NAMES[m.mode]}"
            f"{'' if m.mode == SEQ else f' B={m.block_words}'}{' STRICT' if m.strict_align else ''} AW={m.aw}")


def selftest() -> int:
    n = 0
    for m in selftest_table():
        r = m.check_bijection()
        hits = set(r["bank_hits"])
        assert len(hits) == 1, ("banks unbalanced", cfg_str(m), r["bank_hits"])    # every bank holds exactly BANK_DEPTH words
        n += 1
        print(f"  ok  {cfg_str(m):52s} {r['words']:6d} words  bijective, balanced, inverse round-trips")
    # negative: illegal configurations must be rejected
    bad = [BankMap(1, 64), BankMap(4, 1), BankMap(4, 64, 3), BankMap(4, 64, 4, BLOCK, 3), BankMap(4, 64, 4, BLOCK, 128),
           BankMap(4, 100, 4, BLOCK, 8), BankMap(3, 64, 4, XOR), BankMap(4, 64, 4, 9), BankMap(4, 64, 4, SEQ, addr_width=5)]
    for m in bad:
        try:
            m.validate()
        except ValueError:
            continue
        raise AssertionError(f"illegal config accepted: {m}")
    print(f"  ok  {len(bad)} illegal configurations rejected")
    # the documented pathological stride: SEQ collapses onto one bank, XOR spreads it
    s = BankMap(4, 256, 4, SEQ)
    x = BankMap(4, 256, 4, XOR)
    assert s.banks_touched(0, 4, 16) == 1 and x.banks_touched(0, 4, 16) == 4
    print("  ok  stride-by-NUM_BANKS: SEQ touches 1 bank, XOR touches 4")
    print(f"MODEL_RESULT PASS configs={n} negative={len(bad)}")
    return 0


# --------------------------------------------------------------------------- RTL dump comparison
def parse_cfg(spec: str) -> BankMap:
    kv = dict(p.split("=") for p in spec.split(","))
    return BankMap(int(kv["NB"]), int(kv["D"]), int(kv.get("BPW", 4)), int(kv.get("MODE", 0)), int(kv.get("B", 1)),
                   bool(int(kv.get("STRICT", 0))), int(kv["AW"]) if "AW" in kv else None)


def compare(dump: str, spec: str) -> int:
    """Dump lines: `<addr_hex> <ok> <err> <bank> <local> <off>` (bank/local printed only when the RTL says ok or ALIGN)."""
    m = parse_cfg(spec)
    m.validate()
    n = bad = 0
    for line in open(dump):
        f = line.split()
        if not f:
            continue
        addr, ok, err, bank, local, off = int(f[0], 16), int(f[1]), int(f[2]), int(f[3]), int(f[4]), int(f[5])
        eok, eerr, ebank, elocal, eoff = m.decode(addr)
        n += 1
        mism = (bool(ok) != eok) or err != eerr or off != eoff
        if eok and not mism:
            mism = bank != ebank or local != elocal
        if mism:
            bad += 1
            if bad <= 10:
                print(f"MISMATCH addr={addr:#x} rtl=(ok={ok} err={err} bank={bank} local={local} off={off}) "
                      f"model=(ok={int(eok)} err={eerr} bank={ebank} local={elocal} off={eoff})")
    print(f"MODEL_COMPARE {'PASS' if bad == 0 and n > 0 else 'FAIL'} lines={n} mismatches={bad} cfg={spec}")
    return 0 if bad == 0 and n > 0 else 1


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--compare", nargs=2, metavar=("DUMP", "CFGSPEC"))
    a = ap.parse_args()
    if a.compare:
        return compare(*a.compare)
    return selftest()


if __name__ == "__main__":
    sys.exit(main())
