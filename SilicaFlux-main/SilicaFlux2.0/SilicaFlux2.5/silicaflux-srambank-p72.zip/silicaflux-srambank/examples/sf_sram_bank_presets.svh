// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: sf_sram_bank_presets.svh
// Interleaving configuration presets for the four initial configurations:
// 2, 4, 8 and 16 banks of 1024 x 32-bit words (4 KiB per bank), NUM_PORTS = NUM_BANKS lanes.
// Each macro is a parameter-override list for sf_sram_bank / sf_sram_bank_addr_decode:
//
//     `include "sf_sram_bank_defs.svh"
//     `include "sf_sram_bank_presets.svh"
//     sf_sram_bank #(`SF_SRAM_BANK_PRESET_4_SEQ) u_banks ( ... );
//
// SEQ   sequential word interleave: bank = word % NUM_BANKS            (unit-stride streams rotate over the banks)
// BLK   block interleave, 16-word runs per bank                       (short bursts stay in one bank)
// XOR   sequential interleave with a per-row XOR skew                 (power-of-two strides spread over the banks)
// Supported byte range per preset: 0 .. NUM_BANKS * 4096 - 1  (2 banks: 8 KiB ... 16 banks: 64 KiB).
// These are starting points, not requirements: every parameter of sf_sram_bank can be overridden after the macro.
// =============================================================================
`ifndef SF_SRAM_BANK_PRESETS_SVH
`define SF_SRAM_BANK_PRESETS_SVH
`include "sf_sram_bank_defs.svh"

`define SF_SRAM_BANK_PRESET_2_SEQ   .NUM_BANKS(2),  .NUM_PORTS(2),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_SEQ)
`define SF_SRAM_BANK_PRESET_4_SEQ   .NUM_BANKS(4),  .NUM_PORTS(4),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_SEQ)
`define SF_SRAM_BANK_PRESET_8_SEQ   .NUM_BANKS(8),  .NUM_PORTS(8),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_SEQ)
`define SF_SRAM_BANK_PRESET_16_SEQ  .NUM_BANKS(16), .NUM_PORTS(16), .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_SEQ)

`define SF_SRAM_BANK_PRESET_2_BLK   .NUM_BANKS(2),  .NUM_PORTS(2),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_BLOCK), .BLOCK_WORDS(16)
`define SF_SRAM_BANK_PRESET_4_BLK   .NUM_BANKS(4),  .NUM_PORTS(4),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_BLOCK), .BLOCK_WORDS(16)
`define SF_SRAM_BANK_PRESET_8_BLK   .NUM_BANKS(8),  .NUM_PORTS(8),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_BLOCK), .BLOCK_WORDS(16)
`define SF_SRAM_BANK_PRESET_16_BLK  .NUM_BANKS(16), .NUM_PORTS(16), .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_BLOCK), .BLOCK_WORDS(16)

`define SF_SRAM_BANK_PRESET_2_XOR   .NUM_BANKS(2),  .NUM_PORTS(2),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_XOR)
`define SF_SRAM_BANK_PRESET_4_XOR   .NUM_BANKS(4),  .NUM_PORTS(4),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_XOR)
`define SF_SRAM_BANK_PRESET_8_XOR   .NUM_BANKS(8),  .NUM_PORTS(8),  .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_XOR)
`define SF_SRAM_BANK_PRESET_16_XOR  .NUM_BANKS(16), .NUM_PORTS(16), .DATA_WIDTH(32), .BANK_DEPTH(1024), .MAP_MODE(`SF_SRAM_BANK_MAP_XOR)

`endif // SF_SRAM_BANK_PRESETS_SVH
