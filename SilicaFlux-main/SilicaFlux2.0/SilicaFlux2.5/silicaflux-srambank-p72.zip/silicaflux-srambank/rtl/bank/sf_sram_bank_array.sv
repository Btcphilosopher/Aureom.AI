// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: sf_sram_bank_array
// NUM_BANKS independent single-port banks, each ONE verified sf_sram_core, each
// with its OWN request port: bank enable, bank-local word address, write
// enable, byte-enable mask, write data, transaction ID.  This is the bank
// interface a controller drives once it has decoded and arbitrated.
//
//   * Banking multiplies the number of accesses the array can serve per cycle
//     (up to NUM_BANKS, one per bank).  It does NOT add ports to a bank:
//     every bank is a single-port memory and serves at most ONE access per
//     cycle.  There is nothing here to arbitrate -- a second request for a bank
//     cannot even be expressed on its port.  Same-bank contention is resolved
//     (or reported) by whoever fans requests into these ports; see
//     sf_sram_bank for the minimal deterministic interlock.
//   * Each bank accepts every access in the cycle it is presented (no wait
//     states): b_ready is the out-of-reset flag, not a flow-control signal.
//   * Responses.  Every accepted access yields at most one response, EXACTLY
//     READ_LATENCY cycles after it was issued, whatever its kind (writes are
//     aligned to the read latency here, so a bank never delivers two responses
//     in one cycle and per-requester order is preserved by construction):
//        read             : b_rsp_valid, b_rsp_rdata (b_rsp_err -> rdata unusable)
//        write, WRITE_ACK : b_rsp_valid, b_rsp_we=1
//        write, posted    : no response, unless the bank flagged an error
//     Errors are never silent: an invalid local address (possible only when
//     BANK_DEPTH is not a power of two) gives b_rsp_err on reads and writes.
//     b_rsp_id returns the request's ID.  b_rsp_rdata/we/err/id are meaningful
//     only while b_rsp_valid=1; rdata only for a read without error.
//   * Reset (rst_n: asynchronous assert, synchronous release) drops requests and
//     in-flight responses and clears the pipelines; the storage is never reset
//     (sf_sram_core contract), so the contents survive.
//   * Status/events (one-cycle pulses, for sf_sram_bank_perf):
//        b_busy    an operation is in progress: issued this cycle or still in
//                  the READ_LATENCY pipeline (the response cycle included)
//        ev_access issued to the array this cycle
//        ev_ok / ev_err   completed without / with a bank error (response cycle)
// Classification: SYNTHESIZABLE (one inferred memory per bank)
// =============================================================================
`include "sf_sram_bank_defs.svh"
`default_nettype none

module sf_sram_bank_array #(
  parameter int NUM_BANKS    = 4,
  parameter int DATA_WIDTH   = 32,
  parameter int BYTE_WIDTH   = 8,
  parameter int BANK_DEPTH   = 1024,
  parameter int READ_LATENCY = 1,
  parameter int WRITE_ACK    = 1,
  parameter int ID_WIDTH     = 4,
  parameter int INIT_MODE    = `SF_SRAM_INIT_NONE,
  parameter     INIT_FILE    = "",
  parameter int OOB_ASSERT   = 1,
  localparam int LANES       = DATA_WIDTH / BYTE_WIDTH,
  localparam int LAW         = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1
) (
  input  wire logic                            clk,
  input  wire logic                            rst_n,
  // ---------------------------------------------------- bank request ports (bank b = slice b)
  input  wire logic [NUM_BANKS-1:0]            b_req,       // bank enable: one access to bank b this cycle
  input  wire logic [NUM_BANKS-1:0]            b_we,        // 1 write, 0 read
  input  wire logic [NUM_BANKS*LAW-1:0]        b_addr,      // bank-local WORD address
  input  wire logic [NUM_BANKS*LANES-1:0]      b_wmask,     // byte enables, lane 0 = least-significant byte
  input  wire logic [NUM_BANKS*DATA_WIDTH-1:0] b_wdata,
  input  wire logic [NUM_BANKS*ID_WIDTH-1:0]   b_id,
  output logic      [NUM_BANKS-1:0]            b_ready,     // out of reset: the bank accepts this cycle
  // ---------------------------------------------------- bank response ports
  output logic      [NUM_BANKS-1:0]            b_rsp_valid,
  output logic      [NUM_BANKS*DATA_WIDTH-1:0] b_rsp_rdata,
  output logic      [NUM_BANKS-1:0]            b_rsp_we,
  output logic      [NUM_BANKS-1:0]            b_rsp_err,
  output logic      [NUM_BANKS*ID_WIDTH-1:0]   b_rsp_id,
  // ---------------------------------------------------- per-bank status and events
  output logic      [NUM_BANKS-1:0]            b_busy,
  output logic      [NUM_BANKS-1:0]            ev_access,
  output logic      [NUM_BANKS-1:0]            ev_ok,
  output logic      [NUM_BANKS-1:0]            ev_err
);

  if (NUM_BANKS < 1) begin : g_err_num_banks_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_bank_array: NUM_BANKS must be >= 1")
  end
  if (ID_WIDTH < 1) begin : g_err_id_width_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_bank_array: ID_WIDTH must be >= 1")
  end
  if (WRITE_ACK != 0 && WRITE_ACK != 1) begin : g_err_write_ack_not_0_or_1
    `SF_SRAM_CFG_FATAL("sf_sram_bank_array: WRITE_ACK must be 0 or 1")
  end
  // DATA_WIDTH / BYTE_WIDTH / BANK_DEPTH / READ_LATENCY / INIT_* are checked by sf_sram_core.

  assign b_ready = {NUM_BANKS{rst_n}};

  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_bank
    logic [DATA_WIDTH-1:0] c_rdata;
    logic                  c_rd_err, c_wr_err;
    /* verilator lint_off UNUSEDSIGNAL */
    logic                  c_rd_valid;                // cross-checked in simulation only
    logic                  c_wr_ack;                  // posted-write core: tied low, acks are made below
    /* verilator lint_on UNUSEDSIGNAL */

    // ------------------------------------------------ the verified single-port macro model
    sf_sram_core #(
      .DATA_WIDTH(DATA_WIDTH), .DEPTH_WORDS(BANK_DEPTH), .ADDR_WIDTH(LAW), .BYTE_WIDTH(BYTE_WIDTH),
      .READ_LATENCY(READ_LATENCY), .INIT_MODE(INIT_MODE), .INIT_FILE(INIT_FILE),
      .WRITE_ACK(0), .OOB_ASSERT(OOB_ASSERT)
    ) u_core (
      .clk, .rst_n,
      .ce(b_req[b]), .we(b_we[b]), .addr(b_addr[b*LAW +: LAW]),
      .wmask(b_wmask[b*LANES +: LANES]), .wdata(b_wdata[b*DATA_WIDTH +: DATA_WIDTH]),
      .rdata(c_rdata), .rd_valid(c_rd_valid), .rd_err(c_rd_err), .wr_ack(c_wr_ack), .wr_err(c_wr_err)
    );

    // ------------------------------------------------ in-flight tracking, aligned to READ_LATENCY
    // Stage k (0-based) holds the access issued k+1 cycles ago; stage READ_LATENCY-1
    // is the response stage.  Control state: reset by rst_n.
    logic                         acc;
    logic [READ_LATENCY-1:0]      v_q, w_q;
    logic [READ_LATENCY*ID_WIDTH-1:0] id_q;      // stage k = id_q[k*ID_WIDTH +: ID_WIDTH] (flat: Yosys 0.33 has no packed 2-D arrays)
    assign acc = b_req[b] & rst_n;

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        v_q  <= '0;
        w_q  <= '0;
        id_q <= '0;
      end else begin
        v_q[0]  <= acc;
        w_q[0]  <= acc & b_we[b];
        id_q[0 +: ID_WIDTH] <= b_id[b*ID_WIDTH +: ID_WIDTH];
        for (int k = 1; k < READ_LATENCY; k++) begin
          v_q[k]  <= v_q[k-1];
          w_q[k]  <= w_q[k-1];
          id_q[k*ID_WIDTH +: ID_WIDTH] <= id_q[(k-1)*ID_WIDTH +: ID_WIDTH];
        end
      end
    end

    // the core flags an invalid WRITE one cycle after issue (always, also when posted);
    // carry that flag to the response stage
    logic ew_last;
    if (READ_LATENCY == 1) begin : g_ew1
      assign ew_last = c_wr_err;
    end else begin : g_ewn
      logic [READ_LATENCY-2:0] ew_q;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          ew_q <= '0;
        end else begin
          ew_q[0] <= c_wr_err;
          for (int k = 1; k < READ_LATENCY - 1; k++) ew_q[k] <= ew_q[k-1];
        end
      end
      assign ew_last = ew_q[READ_LATENCY-2];
    end

    wire v_l   = v_q[READ_LATENCY-1];
    wire w_l   = w_q[READ_LATENCY-1];
    wire err_l = v_l & (w_l ? ew_last : c_rd_err);

    assign b_rsp_valid[b] = v_l & (~w_l | (WRITE_ACK != 0) | ew_last);
    assign b_rsp_rdata[b*DATA_WIDTH +: DATA_WIDTH] = c_rdata;
    assign b_rsp_we[b]    = w_l;
    assign b_rsp_err[b]   = err_l;
    assign b_rsp_id[b*ID_WIDTH +: ID_WIDTH] = id_q[(READ_LATENCY-1)*ID_WIDTH +: ID_WIDTH];

    assign b_busy[b]      = acc | (|v_q);
    assign ev_access[b]   = acc;
    assign ev_ok[b]       = v_l & ~err_l;
    assign ev_err[b]      = err_l;

`ifndef SYNTHESIS
    // The core's own read timing must agree with the in-flight tracking, every cycle.
    always @(posedge clk) begin
      if (rst_n) begin
        assert (c_rd_valid === (v_l & ~w_l))
          else $error("SF_SRAM_BANK_ASSERT_INT %m: core rd_valid (%b) disagrees with the in-flight tracking (%b)",
                      c_rd_valid, v_l & ~w_l);
      end
    end
`endif
  end

endmodule

`default_nettype wire
