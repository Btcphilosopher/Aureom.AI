// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: sf_sram_bank_addr_decode     -- bank address decoder
// Byte address -> (bank, local word index, byte offset, error).  Pure
// combinational; one instance per requester lane.  The mapping is the contract
// of docs/02_address_mapping.md; model/sf_bank_map.py is its executable
// reference and tb_sf_sram_bank_addr_decode proves it exhaustively.
//
//   BPW   = BYTES_PER_WORD (power of two)      OFFW = log2(BPW)
//   w     = byte_address / BPW  = addr[ADDR_WIDTH-1:OFFW]          (word index)
//   byte_off = byte_address % BPW = addr[OFFW-1:0]
//   CAP_WORDS = NUM_BANKS * BANK_DEPTH ;  supported byte range [0, CAP_WORDS*BPW)
//
//   SEQ    bank = w % NUM_BANKS        local = w / NUM_BANKS
//   BLOCK  B = BLOCK_WORDS : blk = w / B, sub = w % B
//          bank = blk % NUM_BANKS      local = (blk / NUM_BANKS) * B + sub
//   XOR    as BLOCK, bank = (blk % NUM_BANKS) ^ ((blk / NUM_BANKS) % NUM_BANKS)
//          (power-of-two NUM_BANKS only)
//
// Cost.  When NUM_BANKS is a power of two every / and % above is a constant
// shift or mask, i.e. a bit-slice of the address: the bank index and the local
// index are WIRES (the XOR mode adds one XOR gate per bank-index bit).  When
// NUM_BANKS is NOT a power of two (SEQ and BLOCK only) the generate branch
// uses real constant division and modulo, which synthesise to adder/compare
// networks -- measured in reports/synth.md, not assumed to be free.
//
// Range.  A byte address is valid iff it is below CAP_WORDS*BPW.  Anything
// else (including every address the port can carry above that, when
// ADDR_WIDTH is wider than needed) gets ok=0, err_code=RANGE; it is never
// folded back onto a valid word.  With STRICT_ALIGN=1 a misaligned byte
// address is ok=0, err_code=ALIGN (RANGE has priority); with STRICT_ALIGN=0 the
// byte offset is reported and ignored, exactly byte_address / BPW as floor
// division, and sub-word access is expressed by the byte-enable mask.
// bank / local_word / byte_off are meaningful only while ok=1 (byte_off also
// while err_code=ALIGN).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sram_bank_defs.svh"
`default_nettype none

module sf_sram_bank_addr_decode #(
  parameter int NUM_BANKS      = 4,
  parameter int BANK_DEPTH     = 1024,
  parameter int BYTES_PER_WORD = 4,
  parameter int ADDR_WIDTH     = $clog2(NUM_BANKS * BANK_DEPTH * BYTES_PER_WORD),
  parameter int MAP_MODE       = `SF_SRAM_BANK_MAP_SEQ,
  parameter int BLOCK_WORDS    = 1,
  parameter int STRICT_ALIGN   = 0,
  localparam int BW            = (NUM_BANKS > 1) ? $clog2(NUM_BANKS) : 1,
  localparam int LAW           = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int OFFX          = (BYTES_PER_WORD > 1) ? $clog2(BYTES_PER_WORD) : 1
) (
  input  wire logic [ADDR_WIDTH-1:0] addr,
  output logic                       ok,
  output logic [1:0]                 err_code,
  output logic [BW-1:0]              bank,
  output logic [LAW-1:0]             local_word,
  output logic [OFFX-1:0]            byte_off
);

  localparam int CAP_WORDS = NUM_BANKS * BANK_DEPTH;
  localparam int OFFW      = (BYTES_PER_WORD > 1) ? $clog2(BYTES_PER_WORD) : 0;
  localparam int WIW       = (CAP_WORDS > 1) ? $clog2(CAP_WORDS) : 1;   // bits of an in-range word index
  localparam int WAW       = ADDR_WIDTH - OFFW;                         // word-index bits at the port
  localparam int LB        = (MAP_MODE == `SF_SRAM_BANK_MAP_SEQ) ? 0 : $clog2(BLOCK_WORDS);
  localparam bit NB_POW2   = (NUM_BANKS > 0) && ((NUM_BANKS & (NUM_BANKS - 1)) == 0);
  localparam bit USE_XOR   = (MAP_MODE == `SF_SRAM_BANK_MAP_XOR);
  localparam bit CAP_POW2  = (CAP_WORDS == (1 << WIW));

  // ------------------------------------------------ illegal parameterisations
  if (NUM_BANKS < 2 || NUM_BANKS > 64) begin : g_err_num_banks_not_2_to_64
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: NUM_BANKS must be in 2..64 (use sf_sram_core directly for one bank)")
  end
  if (BANK_DEPTH < 2) begin : g_err_bank_depth_lt_2
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: BANK_DEPTH must be >= 2")
  end
  if (NUM_BANKS * BANK_DEPTH > (1 << 24)) begin : g_err_capacity_over_2_24_words
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: NUM_BANKS*BANK_DEPTH must be <= 2**24 words")
  end
  if (BYTES_PER_WORD < 1 || BYTES_PER_WORD > 128 || (BYTES_PER_WORD & (BYTES_PER_WORD - 1)) != 0) begin : g_err_bytes_per_word_not_pow2
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: BYTES_PER_WORD must be a power of two in 1..128")
  end
  if (MAP_MODE != `SF_SRAM_BANK_MAP_SEQ && MAP_MODE != `SF_SRAM_BANK_MAP_BLOCK && MAP_MODE != `SF_SRAM_BANK_MAP_XOR) begin : g_err_map_mode_invalid
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: MAP_MODE must be SF_SRAM_BANK_MAP_SEQ/BLOCK/XOR")
  end
  if (MAP_MODE != `SF_SRAM_BANK_MAP_SEQ &&
      (BLOCK_WORDS < 1 || (BLOCK_WORDS & (BLOCK_WORDS - 1)) != 0)) begin : g_err_block_words_not_pow2
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: BLOCK_WORDS must be a power of two >= 1")
  end
  if (MAP_MODE != `SF_SRAM_BANK_MAP_SEQ && BLOCK_WORDS >= 1 &&
      (BLOCK_WORDS > BANK_DEPTH || (BANK_DEPTH % BLOCK_WORDS) != 0)) begin : g_err_block_words_must_divide_bank_depth
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: BLOCK_WORDS must divide BANK_DEPTH (the map would not be a bijection)")
  end
  if (USE_XOR && !NB_POW2) begin : g_err_xor_needs_pow2_banks
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: MAP_MODE=XOR requires a power-of-two NUM_BANKS")
  end
  if (STRICT_ALIGN != 0 && STRICT_ALIGN != 1) begin : g_err_strict_align_not_0_or_1
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: STRICT_ALIGN must be 0 or 1")
  end
  if (ADDR_WIDTH < WIW + OFFW || ADDR_WIDTH > 32) begin : g_err_addr_width_cannot_reach_all_words
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_decode: ADDR_WIDTH must be in clog2(capacity bytes)..32 (some words would be unreachable)")
  end

  // ------------------------------------------------ word index and byte offset
  logic [WAW-1:0] wfull;
  assign wfull = addr[ADDR_WIDTH-1:OFFW];

  if (OFFW > 0) begin : g_off
    assign byte_off = addr[OFFW-1:0];
  end else begin : g_no_off
    assign byte_off = 1'b0;
  end

  // ------------------------------------------------ range check
  // Costs nothing when the capacity is exactly 2**WAW words; a high-bit NOR
  // when only the capacity is a power of two; one comparator against a
  // constant otherwise.
  logic in_range;
  if (CAP_POW2 && WAW == WIW) begin : g_all_valid
    assign in_range = 1'b1;
  end else if (CAP_POW2) begin : g_hi_bits_zero
    assign in_range = ~|(wfull >> WIW);
  end else begin : g_compare
    localparam logic [WAW:0] CAP_W = (WAW + 1)'(CAP_WORDS);
    assign in_range = ({1'b0, wfull} < CAP_W);
  end

  // ------------------------------------------------ bank / local word
  logic [WIW-1:0] wlow, blk, rowb, sub_bits;
  assign wlow     = wfull[WIW-1:0];
  assign blk      = wlow >> LB;
  assign sub_bits = wlow & WIW'((1 << LB) - 1);

  if (NB_POW2) begin : g_pow2_banks
    // bit-slice decode: no divider, no modulo
    logic [WIW-1:0] bsel, bxor;
    assign rowb = blk >> BW;
    assign bsel = blk & WIW'(NUM_BANKS - 1);
    assign bxor = USE_XOR ? (rowb & WIW'(NUM_BANKS - 1)) : '0;
    assign bank = BW'(bsel ^ bxor);
  end else begin : g_generic_banks
    // constant division / modulo (SEQ and BLOCK only; XOR is rejected above)
    localparam logic [WIW-1:0] NB_W = WIW'(NUM_BANKS);
    assign rowb = blk / NB_W;
    assign bank = BW'(blk % NB_W);
  end

  assign local_word = LAW'((rowb << LB) | sub_bits);

  // ------------------------------------------------ errors
  wire misaligned = (OFFW > 0) && (STRICT_ALIGN != 0) && (byte_off != '0);

  always_comb begin
    if (!in_range)       err_code = `SF_SRAM_BANK_ERR_RANGE;
    else if (misaligned) err_code = `SF_SRAM_BANK_ERR_ALIGN;
    else                 err_code = `SF_SRAM_BANK_ERR_NONE;
  end
  assign ok = (err_code == `SF_SRAM_BANK_ERR_NONE);

endmodule

`default_nettype wire
