// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: sf_sram_bank_defs.svh
//
// Constants of the banked SRAM subsystem: the interleaving configuration
// (MAP_MODE) and the error codes.  Extends the common SilicaFlux SRAM header
// sf_sram_defs.svh (Project 71: INIT_MODE values, SF_SRAM_CFG_FATAL) without
// modifying it, and is a `define header rather than a package for the same
// reason: Yosys 0.33 cannot resolve package references in module parameter
// lists.  All names carry the SF_SRAM_BANK_ prefix.
//
// Values are part of the public contract: never renumber, only append.
// =============================================================================
`ifndef SF_SRAM_BANK_DEFS_SVH
`define SF_SRAM_BANK_DEFS_SVH

`include "sf_sram_defs.svh"

// ------------------------------------------------------------------ MAP_MODE
// Interleaving configuration.  Let B = BLOCK_WORDS (a power of two that divides
// BANK_DEPTH), w = word index = byte_address / BYTES_PER_WORD, and
//   blk = w / B     sub = w % B     sel = blk % NUM_BANKS     rowb = blk / NUM_BANKS
//   SEQ   : B = 1 (BLOCK_WORDS ignored)       bank = w % NUM_BANKS      local = w / NUM_BANKS
//           sequential words rotate through the banks.
//   BLOCK : bank = sel                        local = rowb * B + sub
//           runs of B consecutive words share a bank; the runs rotate through
//           the banks.  B = BANK_DEPTH gives contiguous regions, one per bank.
//   XOR   : bank = sel ^ (rowb % NUM_BANKS)   local = rowb * B + sub
//           (NUM_BANKS must be a power of two)  skews the bank per row so that
//           power-of-two strides, which collapse onto one bank under SEQ,
//           spread across the banks.  B = BLOCK_WORDS (default 1).
// All three are bijections between the NUM_BANKS*BANK_DEPTH words and the
// (bank, local) pairs; docs/02_address_mapping.md has the proof sketch and
// tb_sf_sram_bank_addr_decode proves it exhaustively per configuration.
`define SF_SRAM_BANK_MAP_SEQ    0
`define SF_SRAM_BANK_MAP_BLOCK  1
`define SF_SRAM_BANK_MAP_XOR    2

// ---------------------------------------------------------------- error codes
// Response / decoder error code (2 bits).  Priority: RANGE > ALIGN.
//   RANGE : byte address >= NUM_BANKS * BANK_DEPTH * BYTES_PER_WORD.  Never
//           reaches a bank, never aliases (no wrap, no truncation).
//   ALIGN : STRICT_ALIGN=1 and the byte address is not word-aligned.
//   BANK  : the bank itself flagged the access (local word >= BANK_DEPTH, only
//           possible through sf_sram_bank_array with a non-power-of-two depth).
`define SF_SRAM_BANK_ERR_NONE   2'd0
`define SF_SRAM_BANK_ERR_RANGE  2'd1
`define SF_SRAM_BANK_ERR_ALIGN  2'd2
`define SF_SRAM_BANK_ERR_BANK   2'd3

`endif // SF_SRAM_BANK_DEFS_SVH
