# SilicaFlux SRAMBank (Project 72) - compile order (paths relative to the package root)
+incdir+rtl/bank
+incdir+third_party/silicaflux-sramcore/rtl/sram
third_party/silicaflux-sramcore/rtl/sram/sf_sram_array.sv
third_party/silicaflux-sramcore/rtl/sram/sf_sram_core.sv
rtl/bank/sf_sram_bank_addr_decode.sv
rtl/bank/sf_sram_bank_addr_unmap.sv
rtl/bank/sf_sram_bank_perf.sv
rtl/bank/sf_sram_bank_array.sv
rtl/bank/sf_sram_bank.sv
