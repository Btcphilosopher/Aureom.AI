// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: sf_sram_bank_perf       -- bank-level counters
// Saturating event counters, CNT_W bits each, reset by rst_n (asynchronous
// assert, as every SilicaFlux counter block) and by `clear` (synchronous).  A
// counter that reaches all-ones stays there instead of wrapping.  Every
// counter is updated by the same clock edge from one-cycle event pulses, so
// all of them describe exactly the same set of cycles.
//
// Definitions (one counted unit per event pulse; "cycle" = a clock edge with
// rst_n=1 since the last reset/clear):
//   cycles       cycles observed.
//   access[b]    accesses issued to bank b: its single port was used this cycle.
//   ok[b]        accesses of bank b that COMPLETED without error (counted in the
//                cycle the response is due, READ_LATENCY cycles after issue; a
//                posted write is counted although it produces no response).
//   err[b]       accesses of bank b that completed with a bank error.
//   conflict[b]  CONFLICT EVENTS: cycles in which two or more lanes requested
//                bank b.  One event per (bank, cycle), however many lanes collide.
//   stall[b]     lane-cycles lost to bank b: a conflict between n lanes denies
//                n-1 of them that cycle.  A requester that keeps retrying is
//                counted again every cycle it loses.
//   busy[b]      cycles in which bank b had an operation in progress: issued
//                this cycle or still in the READ_LATENCY pipeline (including
//                the cycle its response is delivered).
//   idle[b]      cycles in which bank b had no operation in progress.
//                busy[b] + idle[b] == cycles  (until saturation).
//   err_range / err_align
//                accepted lane requests rejected by the address decoder.  They
//                never touch a bank, so they appear in no per-bank counter.
//   hist[k]      cycles in which exactly k banks were accessed (k = 0..NUM_BANKS).
//                sum(hist) == cycles ; sum(k * hist[k]) == sum(access[b]).
//                hist is the concurrency measurement: hist[k>=2] > 0 proves
//                that independent banks served accesses in the same cycle.
// PERF_EN=0 removes every counter (outputs tie to 0).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sram_bank_defs.svh"
`default_nettype none

module sf_sram_bank_perf #(
  parameter int  NUM_BANKS = 4,
  parameter int  CNT_W     = 32,
  parameter int  INC_W     = 2,        // width of the per-cycle multi-lane increments (>= clog2(NUM_PORTS+1))
  parameter int  PERF_EN   = 1,
  localparam int HW        = $clog2(NUM_BANKS + 1)
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  input  wire logic                         clear,
  input  wire logic [NUM_BANKS-1:0]         ev_access,
  input  wire logic [NUM_BANKS-1:0]         ev_ok,
  input  wire logic [NUM_BANKS-1:0]         ev_err,
  input  wire logic [NUM_BANKS-1:0]         ev_conflict,
  input  wire logic [NUM_BANKS*INC_W-1:0]   ev_stall,
  input  wire logic [NUM_BANKS-1:0]         ev_busy,
  input  wire logic [INC_W-1:0]             ev_err_range,
  input  wire logic [INC_W-1:0]             ev_err_align,
  input  wire logic [HW-1:0]                ev_nacc,
  output logic      [CNT_W-1:0]             cycles,
  output logic      [NUM_BANKS*CNT_W-1:0]   access,
  output logic      [NUM_BANKS*CNT_W-1:0]   ok,
  output logic      [NUM_BANKS*CNT_W-1:0]   err,
  output logic      [NUM_BANKS*CNT_W-1:0]   conflict,
  output logic      [NUM_BANKS*CNT_W-1:0]   stall,
  output logic      [NUM_BANKS*CNT_W-1:0]   busy,
  output logic      [NUM_BANKS*CNT_W-1:0]   idle,
  output logic      [CNT_W-1:0]             err_range,
  output logic      [CNT_W-1:0]             err_align,
  output logic      [(NUM_BANKS+1)*CNT_W-1:0] hist
);

  if (NUM_BANKS < 1) begin : g_err_num_banks_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_bank_perf: NUM_BANKS must be >= 1")
  end
  if (CNT_W < 2 || CNT_W > 64) begin : g_err_cnt_w_range
    `SF_SRAM_CFG_FATAL("sf_sram_bank_perf: CNT_W must be in 2..64")
  end
  if (INC_W < 1) begin : g_err_inc_w_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_bank_perf: INC_W must be >= 1")
  end

  if (PERF_EN == 0) begin : g_off
    assign cycles    = '0;
    assign access    = '0;
    assign ok        = '0;
    assign err       = '0;
    assign conflict  = '0;
    assign stall     = '0;
    assign busy      = '0;
    assign idle      = '0;
    assign err_range = '0;
    assign err_align = '0;
    assign hist      = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_ok = &{1'b0, clk, rst_n, clear, ev_access, ev_ok, ev_err, ev_conflict, ev_stall, ev_busy,
                       ev_err_range, ev_err_align, ev_nacc};
    /* verilator lint_on UNUSEDSIGNAL */
  end else begin : g_on

    localparam logic [CNT_W-1:0] MAXV = {CNT_W{1'b1}};

    // saturating add of an INC_W-bit increment (no `return`: Yosys 0.33 front end)
    function automatic logic [CNT_W-1:0] sat_add(input logic [CNT_W-1:0] v, input logic [INC_W-1:0] inc);
      logic [CNT_W:0] s;
      s = {1'b0, v} + {{(CNT_W + 1 - INC_W){1'b0}}, inc};
      sat_add = s[CNT_W] ? MAXV : s[CNT_W-1:0];
    endfunction

    // a one-bit event as an INC_W-bit increment
    function automatic logic [INC_W-1:0] one(input logic e);
      one = {{(INC_W - 1){1'b0}}, e};
    endfunction

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        cycles <= '0; access <= '0; ok <= '0; err <= '0; conflict <= '0; stall <= '0;
        busy <= '0; idle <= '0; err_range <= '0; err_align <= '0; hist <= '0;
      end else if (clear) begin
        cycles <= '0; access <= '0; ok <= '0; err <= '0; conflict <= '0; stall <= '0;
        busy <= '0; idle <= '0; err_range <= '0; err_align <= '0; hist <= '0;
      end else begin
        cycles    <= sat_add(cycles, one(1'b1));
        err_range <= sat_add(err_range, ev_err_range);
        err_align <= sat_add(err_align, ev_err_align);
        for (int b = 0; b < NUM_BANKS; b++) begin
          access[b*CNT_W +: CNT_W]   <= sat_add(access[b*CNT_W +: CNT_W],   one(ev_access[b]));
          ok[b*CNT_W +: CNT_W]       <= sat_add(ok[b*CNT_W +: CNT_W],       one(ev_ok[b]));
          err[b*CNT_W +: CNT_W]      <= sat_add(err[b*CNT_W +: CNT_W],      one(ev_err[b]));
          conflict[b*CNT_W +: CNT_W] <= sat_add(conflict[b*CNT_W +: CNT_W], one(ev_conflict[b]));
          stall[b*CNT_W +: CNT_W]    <= sat_add(stall[b*CNT_W +: CNT_W],    ev_stall[b*INC_W +: INC_W]);
          busy[b*CNT_W +: CNT_W]     <= sat_add(busy[b*CNT_W +: CNT_W],     one(ev_busy[b]));
          idle[b*CNT_W +: CNT_W]     <= sat_add(idle[b*CNT_W +: CNT_W],     one(~ev_busy[b]));
        end
        for (int k = 0; k <= NUM_BANKS; k++)
          hist[k*CNT_W +: CNT_W] <= sat_add(hist[k*CNT_W +: CNT_W], one(ev_nacc == HW'(k)));
      end
    end
  end

endmodule

`default_nettype wire
