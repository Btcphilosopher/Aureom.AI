// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: sf_sram_bank_addr_unmap      -- inverse mapping
// (bank, local word index) -> word index and word-aligned byte address: the
// exact inverse of sf_sram_bank_addr_decode for in-range addresses, same parameters.
//
//   rowb = local / B     sub = local % B     (B = BLOCK_WORDS, 1 for SEQ)
//   SEQ/BLOCK : sel = bank
//   XOR       : sel = bank ^ (rowb % NUM_BANKS)
//   blk = rowb * NUM_BANKS + sel          w = blk * B + sub          addr = w * BPW
//
// It exists so that invertibility is checked in hardware form rather than
// argued: tb_sf_sram_bank_addr_decode feeds every (bank, local) pair through it and
// requires decode(unmap(bank, local)) == (bank, local).  It is also what a
// controller needs to turn a bank-local error report back into a byte address.
// Pure combinational.  (bank, local) must be a valid pair (bank < NUM_BANKS,
// local < BANK_DEPTH); other inputs give don't-care outputs.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sram_bank_defs.svh"
`default_nettype none

module sf_sram_bank_addr_unmap #(
  parameter int NUM_BANKS      = 4,
  parameter int BANK_DEPTH     = 1024,
  parameter int BYTES_PER_WORD = 4,
  parameter int ADDR_WIDTH     = $clog2(NUM_BANKS * BANK_DEPTH * BYTES_PER_WORD),
  parameter int MAP_MODE       = `SF_SRAM_BANK_MAP_SEQ,
  parameter int BLOCK_WORDS    = 1,
  localparam int BW            = (NUM_BANKS > 1) ? $clog2(NUM_BANKS) : 1,
  localparam int LAW           = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int WIW           = ((NUM_BANKS * BANK_DEPTH) > 1) ? $clog2(NUM_BANKS * BANK_DEPTH) : 1
) (
  input  wire logic [BW-1:0]         bank,
  input  wire logic [LAW-1:0]        local_word,
  output logic      [WIW-1:0]        word_index,
  output logic      [ADDR_WIDTH-1:0] byte_addr
);

  localparam int OFFW    = (BYTES_PER_WORD > 1) ? $clog2(BYTES_PER_WORD) : 0;
  localparam int LB      = (MAP_MODE == `SF_SRAM_BANK_MAP_SEQ) ? 0 : $clog2(BLOCK_WORDS);
  localparam bit NB_POW2 = (NUM_BANKS > 0) && ((NUM_BANKS & (NUM_BANKS - 1)) == 0);
  localparam bit USE_XOR = (MAP_MODE == `SF_SRAM_BANK_MAP_XOR);

  if (NUM_BANKS < 2 || NUM_BANKS > 64) begin : g_err_num_banks_not_2_to_64
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_unmap: NUM_BANKS must be in 2..64")
  end
  if (USE_XOR && !NB_POW2) begin : g_err_xor_needs_pow2_banks
    `SF_SRAM_CFG_FATAL("sf_sram_bank_addr_unmap: MAP_MODE=XOR requires a power-of-two NUM_BANKS")
  end

  logic [WIW-1:0] lw, rowb, sub_bits, sel, blk, w;
  localparam logic [WIW-1:0] NB_W = WIW'(NUM_BANKS);

  assign lw       = WIW'(local_word);
  assign rowb     = lw >> LB;
  assign sub_bits = lw & WIW'((1 << LB) - 1);

  if (USE_XOR) begin : g_xor
    assign sel = WIW'(bank) ^ (rowb & WIW'(NUM_BANKS - 1));
  end else begin : g_plain
    assign sel = WIW'(bank);
  end

  assign blk        = rowb * NB_W + sel;
  assign w          = (blk << LB) | sub_bits;
  assign word_index = w;
  assign byte_addr  = ADDR_WIDTH'({{(ADDR_WIDTH > WIW ? ADDR_WIDTH - WIW : 1){1'b0}}, w} << OFFW);

endmodule

`default_nettype wire
