// =============================================================================
// SilicaFlux SRAMBank (Project 72) :: sf_sram_bank            -- primary RTL
// Distributed multibank SRAM: NUM_BANKS independent single-port banks (each one
// verified sf_sram_core), NUM_PORTS byte-addressed request lanes in front.
// Aureom.AI | SilicaFlux Semiconductor Systems
//
//   lane 0 ─► addr_decode ─┐                              ┌─► bank 0   (sf_sram_core, 1 port)
//   lane 1 ─► addr_decode ─┼─► same-bank interlock ───────┼─► bank 1
//    ...                   │   (lowest lane index wins)   │    ...         = sf_sram_bank_array
//   lane N ─► addr_decode ─┘                              └─► bank B-1
//   rsp lane p ◄─ response routing ◄──────────────────────────  READ_LATENCY cycles later
//   per-bank status (st_*) and bank-level counters (perf_*) observe everything
//   (addr_decode = sf_sram_bank_addr_decode)
//
// WHAT BANKING DOES AND DOES NOT DO.  Every bank is a single-port memory: it
// serves at most ONE access per cycle.  Banking adds no port to any bank; it
// raises the number of accesses the SUBSYSTEM can serve per cycle to as many as
// there are distinct banks being addressed (up to NUM_BANKS), because the banks
// work independently.  Two lanes that address the same bank in the same cycle
// can never both be served in that cycle -- see the interlock below.  Nothing
// in this file claims conflict-free access to one physical port.
//
// Request lanes (req_*): a byte-addressed valid/ready request, one per lane per
// cycle.  req_ready[p] is combinational: 1 when lane p is not denied this
// cycle.  A requester must keep req_valid and the request fields stable until
// req_ready (a denied request is NOT accepted and has no effect).  Accepted =
// req_valid & req_ready.  Idle lanes (req_valid=0) are ready.
//   req_addr    byte address, ADDR_WIDTH bits, decoded by sf_sram_bank_addr_decode:
//               word w = addr / BYTES_PER_WORD, bank/local per MAP_MODE.
//               BYTES_PER_WORD = DATA_WIDTH/BYTE_WIDTH = number of byte lanes
//               ("byte" = one BYTE_WIDTH-bit lane; 9 for {parity, byte} lanes).
//   req_wmask   one byte enable per lane of the word (little-endian), applies to
//               writes; sub-word writes are expressed here, not in the address.
//   req_id      transaction identity, returned in rsp_id.
// Supported byte range: [0, NUM_BANKS*BANK_DEPTH*BYTES_PER_WORD).  Anything
// else is answered with rsp_err, rsp_ecode=RANGE; it never reaches a bank and
// never aliases (docs/02_address_mapping.md).  STRICT_ALIGN=1 also rejects
// misaligned byte addresses (ALIGN).
//
// Same-bank interlock (NOT an arbiter).  Per cycle and per bank, if several
// lanes request the bank, the lane with the LOWEST INDEX is granted and every
// other one is denied (req_ready=0) and counted as a conflict.  This is the
// minimum needed to keep the single port safe and the behaviour deterministic.
// It has no fairness: a persistently higher-priority lane can starve the rest.
// Multi-master arbitration (round-robin, credits, response FIFOs, QoS) belongs
// to the SRAMController, which should present at most one request per bank per
// cycle to this block; the conflict counters then stay at zero and double as a
// check that it does.  The SilicaFlux library's sram_bank_controller provides the
// full multi-master arbitration (per-bank round-robin, response credits); its
// ARB=FIXED policy is the same lowest-index-wins rule used here.  None of that
// is duplicated in this block.
//
// Responses (rsp_*): one response per accepted request, EXACTLY READ_LATENCY
// cycles later, on the same lane (so each lane sees responses in request order):
//   read              rsp_valid, rsp_rdata (valid when rsp_err=0), rsp_we=0
//   write             rsp_valid, rsp_we=1 when WRITE_ACK=1; none when posted
//   rejected request  rsp_valid, rsp_err=1, rsp_ecode, rsp_we = the request's kind,
//                     always (also for posted writes: errors are never silent)
// rsp_rdata is zero whenever it is not a read response without error.
//
// Per-bank status (st_*) and bank-level performance counters (perf_*, see
// sf_sram_bank_perf for the exact definitions) make concurrency measurable.
// Reset: rst_n asynchronous assert, synchronous release; drops everything in
// flight and clears counters, never the storage.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_sram_bank_defs.svh"
`default_nettype none

module sf_sram_bank #(
  parameter int NUM_BANKS      = 4,
  parameter int NUM_PORTS      = NUM_BANKS,
  parameter int DATA_WIDTH     = 32,
  parameter int BYTE_WIDTH     = 8,
  parameter int BANK_DEPTH     = 1024,
  localparam int LANES         = DATA_WIDTH / BYTE_WIDTH,
  parameter int ADDR_WIDTH     = $clog2(NUM_BANKS * BANK_DEPTH * LANES),
  parameter int MAP_MODE       = `SF_SRAM_BANK_MAP_SEQ,
  parameter int BLOCK_WORDS    = 1,
  parameter int STRICT_ALIGN   = 0,
  parameter int READ_LATENCY   = 1,
  parameter int WRITE_ACK      = 1,
  parameter int ID_WIDTH       = 4,
  parameter int INIT_MODE      = `SF_SRAM_INIT_NONE,
  parameter     INIT_FILE      = "",
  parameter int OOB_ASSERT     = 1,
  parameter int PERF_EN        = 1,
  parameter int CNT_W          = 32,
  localparam int LW            = (NUM_PORTS > 1) ? $clog2(NUM_PORTS) : 1,
  localparam int IDA           = ID_WIDTH + LW,
  localparam int LAW           = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int BW            = (NUM_BANKS > 1) ? $clog2(NUM_BANKS) : 1,
  localparam int INC_W         = $clog2(NUM_PORTS + 1),
  localparam int HW            = $clog2(NUM_BANKS + 1)
) (
  input  wire logic                              clk,
  input  wire logic                              rst_n,
  // ---------------------------------------------------- request lanes (lane p = slice p)
  input  wire logic [NUM_PORTS-1:0]              req_valid,
  output logic      [NUM_PORTS-1:0]              req_ready,
  input  wire logic [NUM_PORTS-1:0]              req_we,
  input  wire logic [NUM_PORTS*ADDR_WIDTH-1:0]   req_addr,
  input  wire logic [NUM_PORTS*LANES-1:0]        req_wmask,
  input  wire logic [NUM_PORTS*DATA_WIDTH-1:0]   req_wdata,
  input  wire logic [NUM_PORTS*ID_WIDTH-1:0]     req_id,
  // ---------------------------------------------------- response lanes
  output logic      [NUM_PORTS-1:0]              rsp_valid,
  output logic      [NUM_PORTS*DATA_WIDTH-1:0]   rsp_rdata,
  output logic      [NUM_PORTS-1:0]              rsp_we,
  output logic      [NUM_PORTS-1:0]              rsp_err,
  output logic      [NUM_PORTS*2-1:0]            rsp_ecode,
  output logic      [NUM_PORTS*ID_WIDTH-1:0]     rsp_id,
  // ---------------------------------------------------- per-bank status (this cycle)
  output logic      [NUM_BANKS-1:0]              st_ready,      // out of reset
  output logic      [NUM_BANKS-1:0]              st_busy,       // operation in progress (issue .. response)
  output logic      [NUM_BANKS-1:0]              st_access,     // accessed this cycle
  output logic      [NUM_BANKS-1:0]              st_conflict,   // >= 2 lanes requested the bank this cycle
  // ---------------------------------------------------- bank-level performance counters
  input  wire logic                              perf_clear,
  output logic      [CNT_W-1:0]                  perf_cycles,
  output logic      [NUM_BANKS*CNT_W-1:0]        perf_access,
  output logic      [NUM_BANKS*CNT_W-1:0]        perf_ok,
  output logic      [NUM_BANKS*CNT_W-1:0]        perf_err,
  output logic      [NUM_BANKS*CNT_W-1:0]        perf_conflict,
  output logic      [NUM_BANKS*CNT_W-1:0]        perf_stall,
  output logic      [NUM_BANKS*CNT_W-1:0]        perf_busy,
  output logic      [NUM_BANKS*CNT_W-1:0]        perf_idle,
  output logic      [CNT_W-1:0]                  perf_err_range,
  output logic      [CNT_W-1:0]                  perf_err_align,
  output logic      [(NUM_BANKS+1)*CNT_W-1:0]    perf_hist
);

  localparam int BPW = LANES;       // bytes (lanes) per word: the byte-address granularity

  if (NUM_PORTS < 1 || NUM_PORTS > 32) begin : g_err_num_ports_not_1_to_32
    `SF_SRAM_CFG_FATAL("sf_sram_bank: NUM_PORTS must be in 1..32")
  end
  if (BPW < 1 || (BPW & (BPW - 1)) != 0) begin : g_err_lanes_not_pow2
    `SF_SRAM_CFG_FATAL("sf_sram_bank: DATA_WIDTH/BYTE_WIDTH (bytes per word) must be a power of two for byte addressing")
  end
  // NUM_BANKS / BANK_DEPTH / MAP_MODE / BLOCK_WORDS / ADDR_WIDTH / STRICT_ALIGN: sf_sram_bank_addr_decode.
  // DATA_WIDTH / BYTE_WIDTH / READ_LATENCY / INIT_*: sf_sram_core.  ID_WIDTH / WRITE_ACK: sf_sram_bank_array.

  // ===========================================================================
  // 1. per-lane address decode
  // ===========================================================================
  logic [NUM_PORTS-1:0]     d_ok;
  logic [NUM_PORTS*2-1:0]   d_ecode;
  logic [NUM_PORTS*BW-1:0]  d_bank;
  logic [NUM_PORTS*LAW-1:0] d_local;

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_dec
    /* verilator lint_off UNUSEDSIGNAL */
    logic [((BPW > 1) ? $clog2(BPW) : 1)-1:0] off_p;     // byte offset: reported by the decoder, not needed here
    /* verilator lint_on UNUSEDSIGNAL */
    sf_sram_bank_addr_decode #(
      .NUM_BANKS(NUM_BANKS), .BANK_DEPTH(BANK_DEPTH), .BYTES_PER_WORD(BPW), .ADDR_WIDTH(ADDR_WIDTH),
      .MAP_MODE(MAP_MODE), .BLOCK_WORDS(BLOCK_WORDS), .STRICT_ALIGN(STRICT_ALIGN)
    ) u_dec (
      .addr(req_addr[p*ADDR_WIDTH +: ADDR_WIDTH]),
      .ok(d_ok[p]), .err_code(d_ecode[p*2 +: 2]), .bank(d_bank[p*BW +: BW]),
      .local_word(d_local[p*LAW +: LAW]), .byte_off(off_p)
    );
  end

  // ===========================================================================
  // 2. same-bank interlock: lowest lane index wins, the others are denied
  // ===========================================================================
  logic [NUM_PORTS-1:0]     want;        // valid, decodable, out of reset: needs a bank
  logic [NUM_PORTS-1:0]     lose;        // denied this cycle
  logic [NUM_BANKS-1:0]     win_v;       // bank has a granted lane
  logic [NUM_BANKS*LW-1:0]  win_p;       // ... which one
  logic [NUM_BANKS*INC_W-1:0] cnt_b;     // lanes requesting each bank this cycle
  logic                     seen_v;
  logic [LW-1:0]            first_p;
  logic [INC_W-1:0]         n_req;

  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++) want[p] = req_valid[p] & d_ok[p] & rst_n;
    lose  = '0;
    win_v = '0;
    win_p = '0;
    cnt_b = '0;
    seen_v  = 1'b0;
    first_p = '0;
    n_req   = '0;
    for (int b = 0; b < NUM_BANKS; b++) begin
      seen_v  = 1'b0;
      first_p = '0;
      n_req   = '0;
      for (int p = 0; p < NUM_PORTS; p++) begin
        if (want[p] && d_bank[p*BW +: BW] == BW'(b)) begin
          n_req = n_req + INC_W'(1);
          if (seen_v) begin
            lose[p] = 1'b1;                       // an earlier (lower-index) lane already holds the bank
          end else begin
            seen_v  = 1'b1;
            first_p = LW'(p);
          end
        end
      end
      win_v[b] = seen_v;
      win_p[b*LW +: LW] = first_p;
      cnt_b[b*INC_W +: INC_W] = n_req;
    end
  end

  assign req_ready = ~lose & {NUM_PORTS{rst_n}};

  // ===========================================================================
  // 3. fan the granted lanes out to the bank ports
  // ===========================================================================
  logic [NUM_BANKS-1:0]            b_req, b_we;
  logic [NUM_BANKS*LAW-1:0]        b_addr;
  logic [NUM_BANKS*LANES-1:0]      b_wmask;
  logic [NUM_BANKS*DATA_WIDTH-1:0] b_wdata;
  logic [NUM_BANKS*IDA-1:0]        b_id;

  always_comb begin
    b_req   = win_v;
    b_we    = '0;
    b_addr  = '0;
    b_wmask = '0;
    b_wdata = '0;
    b_id    = '0;
    for (int b = 0; b < NUM_BANKS; b++) begin
      if (win_v[b]) begin
        b_we[b]                              = req_we[win_p[b*LW +: LW]];
        b_addr[b*LAW +: LAW]                 = d_local[win_p[b*LW +: LW]*LAW +: LAW];
        b_wmask[b*LANES +: LANES]            = req_wmask[win_p[b*LW +: LW]*LANES +: LANES];
        b_wdata[b*DATA_WIDTH +: DATA_WIDTH]  = req_wdata[win_p[b*LW +: LW]*DATA_WIDTH +: DATA_WIDTH];
        b_id[b*IDA +: IDA]                   = {req_id[win_p[b*LW +: LW]*ID_WIDTH +: ID_WIDTH], win_p[b*LW +: LW]};
      end
    end
  end

  logic [NUM_BANKS-1:0]            r_valid, r_we, r_err, r_busy, ev_access, ev_ok, ev_err;
  logic [NUM_BANKS*DATA_WIDTH-1:0] r_rdata;
  logic [NUM_BANKS*IDA-1:0]        r_id;

  sf_sram_bank_array #(
    .NUM_BANKS(NUM_BANKS), .DATA_WIDTH(DATA_WIDTH), .BYTE_WIDTH(BYTE_WIDTH), .BANK_DEPTH(BANK_DEPTH),
    .READ_LATENCY(READ_LATENCY), .WRITE_ACK(WRITE_ACK), .ID_WIDTH(IDA),
    .INIT_MODE(INIT_MODE), .INIT_FILE(INIT_FILE), .OOB_ASSERT(OOB_ASSERT)
  ) u_array (
    .clk, .rst_n,
    .b_req, .b_we, .b_addr, .b_wmask, .b_wdata, .b_id,
    .b_ready(st_ready),
    .b_rsp_valid(r_valid), .b_rsp_rdata(r_rdata), .b_rsp_we(r_we), .b_rsp_err(r_err), .b_rsp_id(r_id),
    .b_busy(r_busy), .ev_access, .ev_ok, .ev_err
  );

  // ===========================================================================
  // 4. rejected requests (RANGE / ALIGN): answered here, in order, same latency
  // ===========================================================================
  logic [NUM_PORTS-1:0]   rej;                       // accepted request that the decoder rejected
  assign rej = req_valid & ~d_ok & {NUM_PORTS{rst_n}};

  logic [NUM_PORTS-1:0]   lane_err_valid;
  logic [NUM_PORTS-1:0]   lane_err_we;
  logic [NUM_PORTS*2-1:0] lane_err_code;
  logic [NUM_PORTS*ID_WIDTH-1:0] lane_err_id;

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_rej
    logic [READ_LATENCY-1:0]                v_q, w_q;
    logic [READ_LATENCY*2-1:0]              c_q;           // stage k = c_q[k*2 +: 2]            (flat vectors: Yosys 0.33
    logic [READ_LATENCY*ID_WIDTH-1:0]       i_q;           // stage k = i_q[k*ID_WIDTH +: ID_WIDTH]  has no packed 2-D arrays)
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        v_q <= '0; w_q <= '0; c_q <= '0; i_q <= '0;
      end else begin
        v_q[0] <= rej[p];
        w_q[0] <= req_we[p];
        c_q[0 +: 2]        <= d_ecode[p*2 +: 2];
        i_q[0 +: ID_WIDTH] <= req_id[p*ID_WIDTH +: ID_WIDTH];
        for (int k = 1; k < READ_LATENCY; k++) begin
          v_q[k] <= v_q[k-1];
          w_q[k] <= w_q[k-1];
          c_q[k*2 +: 2]                <= c_q[(k-1)*2 +: 2];
          i_q[k*ID_WIDTH +: ID_WIDTH]  <= i_q[(k-1)*ID_WIDTH +: ID_WIDTH];
        end
      end
    end
    assign lane_err_valid[p]          = v_q[READ_LATENCY-1];
    assign lane_err_we[p]             = w_q[READ_LATENCY-1];
    assign lane_err_code[p*2 +: 2]    = c_q[(READ_LATENCY-1)*2 +: 2];
    assign lane_err_id[p*ID_WIDTH +: ID_WIDTH] = i_q[(READ_LATENCY-1)*ID_WIDTH +: ID_WIDTH];
  end

  // ===========================================================================
  // 5. response routing: bank response -> the lane that issued it (lane index travels in the ID)
  // ===========================================================================
`ifndef SYNTHESIS
  logic [NUM_PORTS-1:0] multi_src;             // simulation-only check, see the end of the file
`endif
  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_rsp
    logic                  s_v, s_we, s_err;
    logic [1:0]            s_ec;
    logic [DATA_WIDTH-1:0] s_data;
    logic [ID_WIDTH-1:0]   s_id;
    logic [NUM_BANKS-1:0]  hit;
    for (genvar b = 0; b < NUM_BANKS; b++) begin : g_hit
      assign hit[b] = r_valid[b] & (r_id[b*IDA +: LW] == LW'(p));
    end
`ifndef SYNTHESIS
    // more than one response source for this lane in one cycle (must never happen)
    assign multi_src[p] = (|(hit & (hit - NUM_BANKS'(1)))) | (lane_err_valid[p] & (|hit));
`endif

    wire                  le_v    = lane_err_valid[p];
    wire                  le_we   = lane_err_we[p];
    wire [1:0]            le_code = lane_err_code[p*2 +: 2];
    wire [ID_WIDTH-1:0]   le_id   = lane_err_id[p*ID_WIDTH +: ID_WIDTH];

    always_comb begin
      s_v = 1'b0; s_we = 1'b0; s_err = 1'b0; s_ec = `SF_SRAM_BANK_ERR_NONE; s_data = '0; s_id = '0;
      for (int b = 0; b < NUM_BANKS; b++) begin
        if (hit[b]) begin                                    // at most one bank answers a lane per cycle
          s_v    = 1'b1;
          s_we   = r_we[b];
          s_err  = r_err[b];
          s_ec   = r_err[b] ? `SF_SRAM_BANK_ERR_BANK : `SF_SRAM_BANK_ERR_NONE;
          s_data = r_rdata[b*DATA_WIDTH +: DATA_WIDTH] & {DATA_WIDTH{~r_we[b] & ~r_err[b]}};
          s_id   = r_id[b*IDA + LW +: ID_WIDTH];
        end
      end
      if (le_v) begin                                        // ... or the decoder rejected the request
        s_v   = 1'b1;
        s_we  = le_we;
        s_err = 1'b1;
        s_ec  = le_code;
        s_data = '0;
        s_id  = le_id;
      end
    end

    assign rsp_valid[p]                          = s_v;
    assign rsp_we[p]                             = s_we;
    assign rsp_err[p]                            = s_err;
    assign rsp_ecode[p*2 +: 2]                   = s_ec;
    assign rsp_rdata[p*DATA_WIDTH +: DATA_WIDTH] = s_data;
    assign rsp_id[p*ID_WIDTH +: ID_WIDTH]        = s_id;
  end

  // ===========================================================================
  // 6. status, events and counters
  // ===========================================================================
  logic [NUM_BANKS-1:0]       ev_conflict;
  logic [NUM_BANKS*INC_W-1:0] ev_stall;
  logic [INC_W-1:0]           n_range, n_align;
  logic [HW-1:0]              n_acc;

  always_comb begin
    n_range = '0;
    n_align = '0;
    n_acc   = '0;
    for (int p = 0; p < NUM_PORTS; p++) begin
      if (rej[p] && d_ecode[p*2 +: 2] == `SF_SRAM_BANK_ERR_RANGE) n_range = n_range + INC_W'(1);
      if (rej[p] && d_ecode[p*2 +: 2] == `SF_SRAM_BANK_ERR_ALIGN) n_align = n_align + INC_W'(1);
    end
    for (int b = 0; b < NUM_BANKS; b++) begin
      if (ev_access[b]) n_acc = n_acc + HW'(1);
    end
  end

  // Conflict events: >= 2 lanes asked for the bank this cycle; n lanes colliding deny n-1 of them.
  if (NUM_PORTS > 1) begin : g_conflict
    always_comb begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        ev_conflict[b] = (cnt_b[b*INC_W +: INC_W] > INC_W'(1));
        ev_stall[b*INC_W +: INC_W] = (cnt_b[b*INC_W +: INC_W] > INC_W'(1)) ? (cnt_b[b*INC_W +: INC_W] - INC_W'(1)) : '0;
      end
    end
  end else begin : g_no_conflict                       // a single lane can never collide with itself
    assign ev_conflict = '0;
    assign ev_stall    = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_cnt = &{1'b0, cnt_b};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  assign st_busy     = r_busy;
  assign st_access   = ev_access;
  assign st_conflict = ev_conflict;

  sf_sram_bank_perf #(.NUM_BANKS(NUM_BANKS), .CNT_W(CNT_W), .INC_W(INC_W), .PERF_EN(PERF_EN)) u_perf (
    .clk, .rst_n, .clear(perf_clear),
    .ev_access, .ev_ok, .ev_err, .ev_conflict, .ev_stall, .ev_busy(r_busy),
    .ev_err_range(n_range), .ev_err_align(n_align), .ev_nacc(n_acc),
    .cycles(perf_cycles), .access(perf_access), .ok(perf_ok), .err(perf_err), .conflict(perf_conflict),
    .stall(perf_stall), .busy(perf_busy), .idle(perf_idle),
    .err_range(perf_err_range), .err_align(perf_err_align), .hist(perf_hist)
  );

`ifndef SYNTHESIS
  // ===========================================================================
  // simulation-only checks
  // ===========================================================================
  logic [NUM_PORTS-1:0] lane_x;     // a lane presents a request whose we/addr is X/Z
  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_xchk
    assign lane_x[p] = (req_valid[p] === 1'b1) && $isunknown({req_we[p], req_addr[p*ADDR_WIDTH +: ADDR_WIDTH]});
  end
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!$isunknown(req_valid)) else $error("SF_SRAM_BANK_ASSERT_X %m: req_valid is X/Z");
      assert (lane_x == '0) else $error("SF_SRAM_BANK_ASSERT_X %m: a lane presents a request with X/Z we/addr (lane_x=%b)", lane_x);
    end
  end
  // a lane never receives two responses in one cycle (equal latency for every path)
  always @(posedge clk) begin
    if (rst_n) begin
      assert (multi_src == '0) else $error("SF_SRAM_BANK_ASSERT_INT %m: a lane got two responses in one cycle (multi_src=%b)", multi_src);
    end
  end
  // the decoder never hands a bank an invalid local address, so no bank may flag an error here
  always @(posedge clk) begin
    if (rst_n) begin
      assert (ev_err == '0) else $error("SF_SRAM_BANK_ASSERT_INT %m: bank error flagged for a decoded address");
    end
  end
`endif

endmodule

`default_nettype wire
