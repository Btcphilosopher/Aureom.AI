#!/usr/bin/env bash
# Yosys synthesis ESTIMATES (no place & route, no timing closure).
#   usage: synth/synth.sh <name> <top> [chparam args...]
# Example: synth/synth.sh cache_pf gc_cache -set PF_ENABLE 1
# Target: generic Xilinx 7-series mapping via `synth_xilinx` (LUT6/FF/BRAM/LUTRAM).
# These numbers are FPGA technology-mapping estimates only.  They are NOT
# FPGA measurements (nothing was placed, routed or run on hardware) and they
# are NOT ASIC area/power/frequency predictions.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
NAME=$1; TOP=$2; shift 2
OUT="$ROOT/results/synth"; mkdir -p "$OUT"
SRC="$ROOT/rtl/gc_pkg.sv $ROOT/rtl/gc_fifo.sv $ROOT/rtl/gc_rr_arb.sv $ROOT/rtl/gc_sram_1r1w.sv \
     $ROOT/rtl/gc_ctrl_fsm.sv $ROOT/rtl/gc_perf.sv $ROOT/rtl/gc_pf_stride.sv \
     $ROOT/rtl/gc_uncached.sv $ROOT/rtl/gc_cache.sv"
CHP=""
if [ $# -gt 0 ]; then CHP="chparam $* $TOP;"; fi
yosys -q -l "$OUT/$NAME.log" -p "read_verilog -sv $SRC; $CHP synth_xilinx -top $TOP -flatten; tee -o $OUT/$NAME.stat stat"
echo "wrote $OUT/$NAME.stat"
