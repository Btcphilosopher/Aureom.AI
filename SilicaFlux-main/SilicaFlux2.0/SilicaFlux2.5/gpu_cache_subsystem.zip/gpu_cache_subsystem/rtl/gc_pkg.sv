// -----------------------------------------------------------------------------
// gc_pkg.sv - shared encodings for the GPU cache subsystem
//
// Coding note: the RTL is written in a SystemVerilog subset accepted by both
// the Verilator 5.x and Yosys 0.33 built-in front ends.  Consequently:
//   * no packed multi-dimensional arrays (multi-port buses are flattened),
//   * no `import` (package items are referenced as gc_pkg::NAME),
//   * no `return` in functions, no structs/enums.
// -----------------------------------------------------------------------------
package gc_pkg;

  // ---- core request opcodes (req_op) ----------------------------------------
  localparam logic [1:0] OP_LOAD  = 2'd0;   // 32-bit load
  localparam logic [1:0] OP_STORE = 2'd1;   // 32-bit store with byte strobes
  // 2'd2, 2'd3 are reserved -> error response

  // ---- control opcodes (ctrl_op) --------------------------------------------
  localparam logic [1:0] CTRL_FENCE = 2'd0; // wait until all prior ops performed
  localparam logic [1:0] CTRL_FLUSH = 2'd1; // fence + clean (no-op in WT) + invalidate all
  localparam logic [1:0] CTRL_INVAL = 2'd2; // fence + invalidate all
  // 2'd3 reserved -> immediate error completion

  // ---- performance / debug event indices ------------------------------------
  localparam int EV_LD         = 0;  // demand load committed (well-formed)
  localparam int EV_LD_HIT     = 1;  // demand load hit
  localparam int EV_LD_MISS    = 2;  // demand load primary miss (MSHR allocated)
  localparam int EV_LD_MERGE   = 3;  // demand load merged into in-flight MSHR
  localparam int EV_ST         = 4;  // store committed (well-formed)
  localparam int EV_ST_HIT     = 5;  // store hit (line updated in place)
  localparam int EV_RPL_MSHR   = 6;  // replay: no free MSHR / target slots full
  localparam int EV_RPL_STHAZ  = 7;  // replay: store to line with pending fill
  localparam int EV_RPL_RES    = 8;  // replay: response FIFO / mem queue / write credit
  localparam int EV_MEM_RD_DEM = 9;  // demand line read sent to memory queue
  localparam int EV_MEM_RD_PF  = 10; // prefetch line read sent to memory queue
  localparam int EV_MEM_WR     = 11; // write-through sent to memory queue
  localparam int EV_FILL       = 12; // line installed
  localparam int EV_EVICT      = 13; // valid line evicted by a fill
  localparam int EV_PF_CAND    = 14; // prefetcher produced a candidate (queued)
  localparam int EV_PF_FILT    = 15; // candidate dropped: line present or in flight
  localparam int EV_PF_DROP    = 16; // candidate dropped: resources / queue full / disabled
  localparam int EV_PF_USEFUL  = 17; // first demand hit on a prefetched line (timely)
  localparam int EV_PF_LATE    = 18; // demand merged into an in-flight prefetch
  localparam int EV_PF_USELESS = 19; // prefetched line evicted/invalidated unused
  localparam int EV_POLLUTION  = 20; // demand miss on a line evicted by a prefetch fill
  localparam int EV_ERR_RSP    = 21; // error response returned to a core port
  localparam int EV_MEM_ERR    = 22; // memory returned an error
  localparam int EV_SPURIOUS   = 23; // memory response with no matching request
  localparam int EV_CTRL       = 24; // control operation completed
  localparam int EV_FILL_ERR   = 25; // fill not installed because of a memory error
  localparam int N_EV          = 26;

  // ---- sticky error status bits (err_status) --------------------------------
  localparam int ERR_MISALIGNED = 0; // request address not 4-byte aligned
  localparam int ERR_BADOP      = 1; // reserved request opcode
  localparam int ERR_MEM_RD     = 2; // memory read error (data not cached)
  localparam int ERR_MEM_WR     = 3; // memory write error (reported at next ctrl op)
  localparam int ERR_SPURIOUS   = 4; // unexpected memory response (dropped)
  localparam int ERR_CTRL_BADOP = 5; // reserved control opcode
  localparam int N_ERR          = 8;

endpackage
