// -----------------------------------------------------------------------------
// gc_sram_1r1w - behavioural 1-read/1-write synchronous RAM with lane enables.
//   * read data is registered (available the cycle after `re`), and holds its
//     value while `re` is low (models an SRAM/BRAM output latch).
//   * write lanes are W/LANES bits wide (LANES=1 -> whole word).
//   * read and write of the same address in the same cycle is NOT used by the
//     cache (S0 bubbles instead); a simulation check flags it.
//   * contents are not reset: valid bits live in flops in the cache.
// Maps to FPGA block RAM (simple dual port) or an ASIC 2-port SRAM macro; the
// behavioural model says nothing about the timing/area of either.
// -----------------------------------------------------------------------------
module gc_sram_1r1w #(
  parameter int W     = 32,
  parameter int DEPTH = 64,
  parameter int LANES = 1,
  parameter int AW    = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  logic             clk,
  input  logic             re,
  input  logic [AW-1:0]    raddr,
  output logic [W-1:0]     rdata,
  input  logic             we,
  input  logic [AW-1:0]    waddr,
  input  logic [W-1:0]     wdata,
  input  logic [LANES-1:0] wlane
);
  localparam int LW = W / LANES;

  // one storage array per write lane (byte-enable RAM = LANES narrow RAMs)
  for (genvar l = 0; l < LANES; l++) begin : g_lane
    logic [LW-1:0] mem [0:DEPTH-1];
    logic [LW-1:0] q;
    always_ff @(posedge clk) begin
      if (we && wlane[l]) mem[waddr] <= wdata[l*LW +: LW];
    end
    always_ff @(posedge clk) begin
      if (re) q <= mem[raddr];
    end
    assign rdata[l*LW +: LW] = q;
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (re && we && (raddr == waddr) && (|wlane))
      $error("%m: read/write collision on address %0d", raddr);
  end
`endif
endmodule
