// -----------------------------------------------------------------------------
// gc_pf_stride - conservative line-granular stride prefetcher (optional)
//
// Training : committed, well-formed DEMAND LOADS only (hits and misses).
//            Stores, prefetches and erroring requests never train.
// Table    : ENTRIES direct-mapped entries indexed by a rotate-fold of {port, pc}
//            and tagged with the full {port, pc} key ("reference prediction
//            table" keyed by the requesting instruction stream).
// Per entry: last line address, signed line stride (STRIDE_W bits),
//            2-bit saturating confidence, last line prefetched.
// Update   : repeated accesses to the same line are ignored (delta == 0).
//            delta == stride -> confidence++ ; otherwise stride := delta,
//            confidence := 0.  |delta| that does not fit STRIDE_W -> stride 0.
// Issue    : only when delta == stride != 0 AND confidence >= CONF_TH
//            target = line + stride * dist   (dist = runtime input, 0 -> 1)
//            suppressed if the target leaves the 4 KiB (PAGE_SHIFT) page of
//            the triggering access, or equals the entry's last prefetch.
//            Degree is 1: at most one candidate per training event.
// Output   : a small candidate queue (QDEPTH); candidates are dropped when
//            the queue is full.  The cache treats candidates as the lowest
//            priority pipeline source and may filter or drop them.
// Clear    : `clear` empties table and queue; `enable`=0 empties the queue
//            and stops training (the table is kept for FENCE).
// -----------------------------------------------------------------------------
module gc_pf_stride #(
  parameter int ADDR_W     = 32,
  parameter int LSH        = 6,     // log2(line bytes)
  parameter int PORT_W     = 2,
  parameter int PC_W       = 8,
  parameter int ENTRIES    = 16,
  parameter int CONF_TH    = 2,
  parameter int PAGE_SHIFT = 12,
  parameter int STRIDE_W   = 8,
  parameter int QDEPTH     = 2,
  parameter int LA_W       = ADDR_W - LSH
) (
  input  logic              clk,
  input  logic              rst,
  input  logic              clear,
  input  logic              enable,
  input  logic [3:0]        dist_in,
  input  logic              train_valid,
  input  logic [PORT_W-1:0] train_port,
  input  logic [PC_W-1:0]   train_pc,
  /* verilator lint_off UNUSEDSIGNAL */
  input  logic [ADDR_W-1:0] train_addr,   // low LSH bits unused (line granularity)
  /* verilator lint_on UNUSEDSIGNAL */
  output logic              q_valid,
  output logic [LA_W-1:0]   q_line,
  input  logic              q_pop,
  output logic              ev_cand,
  output logic              ev_drop
);
  localparam int IDX_W  = (ENTRIES > 1) ? $clog2(ENTRIES) : 1;
  localparam int KEY_W  = PORT_W + PC_W;
  localparam int PG_LSB = PAGE_SHIFT - LSH;   // line-address bit where the page number starts

  // ---- stage 1: register the training event --------------------------------
  logic              t_v;
  logic [KEY_W-1:0]  t_key;
  logic [LA_W-1:0]   t_line;

  always_ff @(posedge clk) begin
    if (rst || clear || !enable) begin
      t_v <= 1'b0;
    end else begin
      t_v <= train_valid;
    end
    t_key  <= {train_port, train_pc};
    t_line <= train_addr[ADDR_W-1:LSH];
  end

  // ---- table ---------------------------------------------------------------
  logic                e_v      [0:ENTRIES-1];
  logic [KEY_W-1:0]    e_key    [0:ENTRIES-1];
  logic [LA_W-1:0]     e_last   [0:ENTRIES-1];
  logic [STRIDE_W-1:0] e_stride [0:ENTRIES-1];
  logic [1:0]          e_conf   [0:ENTRIES-1];
  logic [LA_W-1:0]     e_lastpf [0:ENTRIES-1];

  function automatic logic [IDX_W-1:0] fold_key(input logic [KEY_W-1:0] k);
    logic [IDX_W-1:0] r;
    r = '0;
    // rotate-fold: chunk c of the key is rotated by c before XOR-folding, so
    // keys made of repeated nibbles (e.g. pc 0x11, 0x44) do not all alias
    for (int i = 0; i < KEY_W; i++) r[(i + i / IDX_W) % IDX_W] = r[(i + i / IDX_W) % IDX_W] ^ k[i];
    fold_key = r;
  endfunction

  logic [IDX_W-1:0]    idx;
  logic                key_hit, delta_zero, delta_fits, same;
  logic [LA_W-1:0]     delta, stride_ext, target;
  logic [STRIDE_W-1:0] d_s;
  logic [1:0]          conf_n;
  logic [3:0]          dist_eff;
  logic                want, page_ok, is_new;
  logic                q_full, q_push;

  always_comb begin
    idx        = fold_key(t_key);
    key_hit    = e_v[idx] && (e_key[idx] == t_key);
    delta      = t_line - e_last[idx];
    delta_zero = (delta == '0);
    // delta fits in STRIDE_W signed bits iff the upper bits are a sign extension
    delta_fits = (delta[LA_W-1:STRIDE_W-1] == '0) || (delta[LA_W-1:STRIDE_W-1] == '1);
    d_s        = delta[STRIDE_W-1:0];
    same       = delta_fits && (d_s == e_stride[idx]) && (e_stride[idx] != '0);
    conf_n     = same ? ((e_conf[idx] == 2'd3) ? 2'd3 : e_conf[idx] + 2'd1) : 2'd0;
    dist_eff   = (dist_in == 4'd0) ? 4'd1 : dist_in;
    stride_ext = {{(LA_W-STRIDE_W){e_stride[idx][STRIDE_W-1]}}, e_stride[idx]};
    target     = t_line + LA_W'(stride_ext * LA_W'(dist_eff));
    page_ok    = (target[LA_W-1:PG_LSB] == t_line[LA_W-1:PG_LSB]);
    is_new     = (target != e_lastpf[idx]);
    want       = t_v && key_hit && !delta_zero && same && (32'(conf_n) >= CONF_TH) &&
                 page_ok && is_new;
    q_push     = want && !q_full;
  end

  assign ev_cand = q_push;
  assign ev_drop = want && q_full;

  always_ff @(posedge clk) begin
    if (rst || clear) begin
      for (int i = 0; i < ENTRIES; i++) e_v[i] <= 1'b0;
    end else if (t_v) begin
      if (!key_hit) begin
        e_v[idx]      <= 1'b1;
        e_key[idx]    <= t_key;
        e_last[idx]   <= t_line;
        e_stride[idx] <= '0;
        e_conf[idx]   <= 2'd0;
        e_lastpf[idx] <= t_line;
      end else if (!delta_zero) begin
        e_last[idx] <= t_line;
        e_conf[idx] <= conf_n;
        if (!same) e_stride[idx] <= delta_fits ? d_s : '0;
        if (want)  e_lastpf[idx] <= target;
      end
    end
  end

  // ---- candidate queue -------------------------------------------------------
  logic q_empty;
  gc_fifo #(.W(LA_W), .DEPTH(QDEPTH)) u_q (
    .clk, .rst(rst || clear || !enable),
    .push(q_push), .wdata(target), .pop(q_pop && q_valid), .rdata(q_line),
    .empty(q_empty), .full(q_full), .count()
  );
  assign q_valid = !q_empty;
endmodule
