// -----------------------------------------------------------------------------
// gc_uncached - UNCACHED BASELINE with the same external interface as gc_cache.
//
//  * NUM_PORTS core ports -> per-port input FIFO -> round-robin issue (1/cycle)
//  * every well-formed load becomes a memory read of ONE WORD (byte enables
//    select 4 bytes; the memory model charges sector-granular bandwidth)
//  * every well-formed store becomes a posted memory write; the core gets an
//    ack as soon as the write is queued (same contract as the cache)
//  * up to N_OT loads outstanding; responses may return out of order and are
//    routed back to the requesting port by the outstanding table (OT)
//  * FENCE / FLUSH / INVAL all reduce to "drain everything" (nothing cached)
//  * errors: misaligned / reserved op -> error response, memory read error ->
//    error response, memory write error -> sticky + reported at next ctrl op
// The commit point of a request (dbg_commit_*) is the cycle it is issued into
// the in-order memory request queue.
// -----------------------------------------------------------------------------
module gc_uncached #(
  parameter int NUM_PORTS  = 4,
  parameter int ADDR_W     = 32,
  parameter int LINE_BYTES = 64,
  parameter int N_OT       = 16,
  parameter int IN_DEPTH   = 2,
  parameter int RSP_DEPTH  = 16,
  parameter int MEMQ_DEPTH = 4,
  parameter int TAG_W      = 8,
  parameter int PC_W       = 8,
  parameter int WR_OUT_MAX = 63,
  parameter int MEM_ID_W   = (N_OT > 1) ? $clog2(N_OT) : 1,
  parameter int PORT_W     = (NUM_PORTS > 1) ? $clog2(NUM_PORTS) : 1,
  parameter int LINE_BITS  = LINE_BYTES * 8
) (
  input  logic                        clk,
  input  logic                        rst,
  // ---- core ports (flattened: port p uses slice p) ----
  input  logic [NUM_PORTS-1:0]        req_valid,
  output logic [NUM_PORTS-1:0]        req_ready,
  input  logic [NUM_PORTS*2-1:0]      req_op,
  input  logic [NUM_PORTS*ADDR_W-1:0] req_addr,
  input  logic [NUM_PORTS*32-1:0]     req_wdata,
  input  logic [NUM_PORTS*4-1:0]      req_wstrb,
  input  logic [NUM_PORTS*TAG_W-1:0]  req_tag,
  input  logic [NUM_PORTS*PC_W-1:0]   req_pc,
  output logic [NUM_PORTS-1:0]        rsp_valid,
  input  logic [NUM_PORTS-1:0]        rsp_ready,
  output logic [NUM_PORTS*TAG_W-1:0]  rsp_tag,
  output logic [NUM_PORTS*32-1:0]     rsp_rdata,
  output logic [NUM_PORTS-1:0]        rsp_err,
  output logic [NUM_PORTS-1:0]        rsp_is_store,
  // ---- control ----
  input  logic                        ctrl_valid,
  output logic                        ctrl_ready,
  input  logic [1:0]                  ctrl_op,
  output logic                        ctrl_done,
  output logic                        ctrl_err,
  /* verilator lint_off UNUSEDSIGNAL */
  input  logic                        pf_enable,   // interface compatibility only
  input  logic [3:0]                  pf_dist,     // interface compatibility only
  /* verilator lint_on UNUSEDSIGNAL */
  // ---- memory ----
  output logic                        mem_req_valid,
  input  logic                        mem_req_ready,
  output logic                        mem_req_we,
  output logic [ADDR_W-1:0]           mem_req_addr,
  output logic [LINE_BITS-1:0]        mem_req_wdata,
  output logic [LINE_BYTES-1:0]       mem_req_be,
  output logic [MEM_ID_W-1:0]         mem_req_id,
  output logic                        mem_req_pf,
  input  logic                        mem_rsp_valid,
  output logic                        mem_rsp_ready,
  input  logic                        mem_rsp_we,
  input  logic [MEM_ID_W-1:0]         mem_rsp_id,
  input  logic [LINE_BITS-1:0]        mem_rsp_rdata,
  input  logic                        mem_rsp_err,
  // ---- status ----
  output logic [gc_pkg::N_ERR-1:0]    err_status,
  output logic [gc_pkg::N_EV*32-1:0]  perf_count,
  output logic                        busy,
  // ---- debug commit stream (verification / tracing) ----
  output logic                        dbg_commit_valid,
  output logic [PORT_W-1:0]           dbg_commit_port,
  output logic [TAG_W-1:0]            dbg_commit_tag,
  output logic [1:0]                  dbg_commit_op,
  output logic [ADDR_W-1:0]           dbg_commit_addr,
  output logic [31:0]                 dbg_commit_wdata,
  output logic [3:0]                  dbg_commit_wstrb,
  output logic                        dbg_commit_err
);
  // ---------------------------------------------------------------------------
  localparam int WPL    = LINE_BYTES / 4;
  localparam int WOFF_W = $clog2(WPL);
  localparam int LSH    = $clog2(LINE_BYTES);
  localparam int LA_W   = ADDR_W - LSH;
  localparam int IN_W   = 2 + ADDR_W + 32 + 4 + TAG_W + PC_W;
  localparam int RSP_W  = 2 + TAG_W + 32;
  localparam int MQ_W   = 1 + LA_W + WOFF_W + 32 + 4 + MEM_ID_W + 1 + 1;
  localparam int WRC_W  = $clog2(WR_OUT_MAX + 1);
  localparam int INC_W  = 12;
  localparam int OTI_W  = (N_OT > 1) ? $clog2(N_OT) : 1;
  localparam int RCNT_W = $clog2(RSP_DEPTH + 1);

  localparam logic [1:0] OT_FREE = 2'd0;
  localparam logic [1:0] OT_PEND = 2'd1;
  localparam logic [1:0] OT_DONE = 2'd2;

  // ---------------------------------------------------------------------------
  // control FSM
  // ---------------------------------------------------------------------------
  logic quiesced, wr_err_flag, draining, act_inval, act_done, ctrl_bad;

  gc_ctrl_fsm u_ctrl (
    .clk, .rst, .ctrl_valid, .ctrl_ready, .ctrl_op, .ctrl_done, .ctrl_err,
    .quiesced, .wr_err_pending(wr_err_flag), .draining, .act_inval, .act_done,
    .bad_op(ctrl_bad)
  );

  // ---------------------------------------------------------------------------
  // input FIFOs
  // ---------------------------------------------------------------------------
  logic [NUM_PORTS-1:0] in_empty, in_full, in_pop;
  logic [IN_W-1:0]      in_head [0:NUM_PORTS-1];
  logic [1:0]           h_op    [0:NUM_PORTS-1];
  logic [ADDR_W-1:0]    h_addr  [0:NUM_PORTS-1];
  logic [31:0]          h_wdata [0:NUM_PORTS-1];
  logic [3:0]           h_wstrb [0:NUM_PORTS-1];
  logic [TAG_W-1:0]     h_tag   [0:NUM_PORTS-1];

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_in
    gc_fifo #(.W(IN_W), .DEPTH(IN_DEPTH)) u_in (
      .clk, .rst,
      .push  (req_valid[p] && req_ready[p]),
      .wdata ({req_pc[p*PC_W +: PC_W], req_tag[p*TAG_W +: TAG_W], req_wstrb[p*4 +: 4],
               req_wdata[p*32 +: 32], req_addr[p*ADDR_W +: ADDR_W], req_op[p*2 +: 2]}),
      .pop   (in_pop[p]),
      .rdata (in_head[p]),
      .empty (in_empty[p]),
      .full  (in_full[p]),
      .count ()
    );
    assign req_ready[p] = !rst && !in_full[p] && !draining;
  end

  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++) begin
      h_op[p]    = in_head[p][1:0];
      h_addr[p]  = in_head[p][2 +: ADDR_W];
      h_wdata[p] = in_head[p][2 + ADDR_W +: 32];
      h_wstrb[p] = in_head[p][2 + ADDR_W + 32 +: 4];
      h_tag[p]   = in_head[p][2 + ADDR_W + 36 +: TAG_W];
    end
  end

  // ---------------------------------------------------------------------------
  // response FIFOs
  // ---------------------------------------------------------------------------
  logic [NUM_PORTS-1:0] rsp_full, rsp_empty, rsp_push;
  logic [RSP_W-1:0]     rsp_wdata [0:NUM_PORTS-1];
  logic [RSP_W-1:0]     rsp_head  [0:NUM_PORTS-1];
  logic [RCNT_W-1:0]    rsp_cnt   [0:NUM_PORTS-1];
  logic [RCNT_W-1:0]    pend_ot   [0:NUM_PORTS-1];   // reserved response slots
  logic [NUM_PORTS-1:0] rsv_ok;

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_rsp
    gc_fifo #(.W(RSP_W), .DEPTH(RSP_DEPTH)) u_rsp (
      .clk, .rst,
      .push  (rsp_push[p]),
      .wdata (rsp_wdata[p]),
      .pop   (rsp_valid[p] && rsp_ready[p]),
      .rdata (rsp_head[p]),
      .empty (rsp_empty[p]),
      .full  (rsp_full[p]),
      .count (rsp_cnt[p])
    );
    assign rsv_ok[p] = ({1'b0, rsp_cnt[p]} + {1'b0, pend_ot[p]}) < (RCNT_W + 1)'(RSP_DEPTH);
    assign rsp_valid[p]            = !rsp_empty[p];
    assign rsp_rdata[p*32 +: 32]   = rsp_head[p][31:0];
    assign rsp_tag[p*TAG_W +: TAG_W] = rsp_head[p][32 +: TAG_W];
    assign rsp_err[p]              = rsp_head[p][32 + TAG_W];
    assign rsp_is_store[p]         = rsp_head[p][33 + TAG_W];
  end

  // ---------------------------------------------------------------------------
  // outstanding-load table
  // ---------------------------------------------------------------------------
  logic [1:0]        ot_state [0:N_OT-1];
  logic [PORT_W-1:0] ot_port  [0:N_OT-1];
  logic [TAG_W-1:0]  ot_tag   [0:N_OT-1];
  logic [WOFF_W-1:0] ot_off   [0:N_OT-1];
  logic [31:0]       ot_data  [0:N_OT-1];
  logic              ot_err   [0:N_OT-1];

  logic              ot_free_any, ot_all_free;
  logic [OTI_W-1:0]  ot_free_idx;
  logic              drn_push;
  logic [OTI_W-1:0]  drn_idx;
  logic [PORT_W-1:0] drn_port;

  always_comb begin
    ot_free_any = 1'b0;
    ot_free_idx = '0;
    ot_all_free = 1'b1;
    drn_push    = 1'b0;
    drn_idx     = '0;
    for (int i = 0; i < N_OT; i++) begin
      if (ot_state[i] != OT_FREE) ot_all_free = 1'b0;
      if (!ot_free_any && ot_state[i] == OT_FREE) begin
        ot_free_any = 1'b1;
        ot_free_idx = OTI_W'(i);
      end
      if (!drn_push && ot_state[i] == OT_DONE && !rsp_full[ot_port[i]]) begin
        drn_push = 1'b1;
        drn_idx  = OTI_W'(i);
      end
    end
    drn_port = ot_port[drn_idx];
  end

  // ---------------------------------------------------------------------------
  // memory request queue
  // ---------------------------------------------------------------------------
  logic              mq_push, mq_empty, mq_full;
  logic [MQ_W-1:0]   mq_wdata, mq_head;
  logic [WRC_W-1:0]  wr_out;
  logic              wr_ok;

  gc_fifo #(.W(MQ_W), .DEPTH(MEMQ_DEPTH)) u_mq (
    .clk, .rst, .push(mq_push), .wdata(mq_wdata),
    .pop(mem_req_valid && mem_req_ready), .rdata(mq_head),
    .empty(mq_empty), .full(mq_full), .count()
  );

  assign wr_ok = (wr_out < WRC_W'(WR_OUT_MAX));

  // ---------------------------------------------------------------------------
  // issue (single stage, one request per cycle, RR among ports that can go)
  // ---------------------------------------------------------------------------
  logic [NUM_PORTS-1:0] h_bad, rsp_space, can;
  logic                 iss;
  logic [PORT_W-1:0]    sel;

  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++) begin
      h_bad[p]     = h_op[p][1] || (h_addr[p][1:0] != 2'b00);
      rsp_space[p] = rsv_ok[p] && !(drn_push && (drn_port == PORT_W'(p)));
      if (in_empty[p])                     can[p] = 1'b0;
      else if (h_bad[p])                   can[p] = rsp_space[p];
      else if (h_op[p] == gc_pkg::OP_LOAD) can[p] = ot_free_any && !mq_full && rsv_ok[p];
      else                                 can[p] = !mq_full && rsp_space[p] && wr_ok;
    end
  end

  gc_rr_arb #(.N(NUM_PORTS), .IW(PORT_W)) u_arb (
    .clk, .rst, .req(can), .advance(1'b1), .any(iss), .gnt_idx(sel)
  );

  logic [1:0]        s_op;
  logic [ADDR_W-1:0] s_addr;
  logic [31:0]       s_wdata;
  logic [3:0]        s_wstrb;
  logic [TAG_W-1:0]  s_tag;
  logic              s_bad, s_load, s_store;

  assign s_op    = h_op[sel];
  assign s_addr  = h_addr[sel];
  assign s_wdata = h_wdata[sel];
  assign s_wstrb = h_wstrb[sel];
  assign s_tag   = h_tag[sel];
  assign s_bad   = h_bad[sel];
  assign s_load  = iss && !s_bad && (s_op == gc_pkg::OP_LOAD);
  assign s_store = iss && !s_bad && (s_op == gc_pkg::OP_STORE);

  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++) begin
      in_pop[p] = iss && (sel == PORT_W'(p));
      if (drn_push && drn_port == PORT_W'(p)) begin
        rsp_push[p]  = 1'b1;
        rsp_wdata[p] = {1'b0, ot_err[drn_idx], ot_tag[drn_idx],
                        ot_err[drn_idx] ? 32'h0 : ot_data[drn_idx]};
      end else begin
        rsp_push[p]  = iss && (sel == PORT_W'(p)) && (s_bad || s_op == gc_pkg::OP_STORE);
        rsp_wdata[p] = {(s_op == gc_pkg::OP_STORE), s_bad, s_tag, 32'h0};
      end
    end
  end

  assign mq_push  = s_load || s_store;
  // {full, pf, id, wstrb, wdata, woff, line, we}
  assign mq_wdata = {1'b0, 1'b0,
                     s_load ? MEM_ID_W'(ot_free_idx) : MEM_ID_W'(0),
                     s_load ? 4'hF : s_wstrb,
                     s_wdata,
                     s_addr[2 +: WOFF_W],
                     s_addr[ADDR_W-1:LSH],
                     s_store};

  // ---------------------------------------------------------------------------
  // memory interface
  // ---------------------------------------------------------------------------
  logic              mq_we, mq_full_line;
  logic [LA_W-1:0]   mq_line;
  logic [WOFF_W-1:0] mq_woff;
  logic [31:0]       mq_wd;
  logic [3:0]        mq_ws;

  assign mq_we         = mq_head[0];
  assign mq_line       = mq_head[1 +: LA_W];
  assign mq_woff       = mq_head[1 + LA_W +: WOFF_W];
  assign mq_wd         = mq_head[1 + LA_W + WOFF_W +: 32];
  assign mq_ws         = mq_head[1 + LA_W + WOFF_W + 32 +: 4];
  assign mem_req_id    = mq_head[1 + LA_W + WOFF_W + 36 +: MEM_ID_W];
  assign mem_req_pf    = mq_head[1 + LA_W + WOFF_W + 36 + MEM_ID_W];
  assign mq_full_line  = mq_head[2 + LA_W + WOFF_W + 36 + MEM_ID_W];

  assign mem_req_valid = !mq_empty;
  assign mem_req_we    = mq_we;
  assign mem_req_addr  = {mq_line, {LSH{1'b0}}};
  assign mem_req_wdata = {WPL{mq_wd}};
  assign mem_req_be    = mq_full_line ? {LINE_BYTES{1'b1}}
                                      : (LINE_BYTES'(mq_ws) << {mq_woff, 2'b00});
  assign mem_rsp_ready = 1'b1;

  // ---------------------------------------------------------------------------
  // memory responses
  // ---------------------------------------------------------------------------
  logic rd_ok, wr_dec, spurious;

  assign rd_ok    = mem_rsp_valid && !mem_rsp_we && (32'(mem_rsp_id) < N_OT) &&
                    (ot_state[OTI_W'(mem_rsp_id)] == OT_PEND);
  assign wr_dec   = mem_rsp_valid && mem_rsp_we && (wr_out != '0);
  assign spurious = mem_rsp_valid && (mem_rsp_we ? (wr_out == '0) : !rd_ok);

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int i = 0; i < N_OT; i++) ot_state[i] <= OT_FREE;
    end else begin
      if (s_load) begin
        ot_state[ot_free_idx] <= OT_PEND;
        ot_port[ot_free_idx]  <= sel;
        ot_tag[ot_free_idx]   <= s_tag;
        ot_off[ot_free_idx]   <= s_addr[2 +: WOFF_W];
      end
      if (rd_ok) begin
        ot_state[OTI_W'(mem_rsp_id)] <= OT_DONE;
        ot_data[OTI_W'(mem_rsp_id)]  <= mem_rsp_rdata[ot_off[OTI_W'(mem_rsp_id)]*32 +: 32];
        ot_err[OTI_W'(mem_rsp_id)]   <= mem_rsp_err;
      end
      if (drn_push) ot_state[drn_idx] <= OT_FREE;
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int p = 0; p < NUM_PORTS; p++) pend_ot[p] <= '0;
    end else begin
      for (int p = 0; p < NUM_PORTS; p++) begin
        if (s_load && sel == PORT_W'(p) && !(drn_push && drn_port == PORT_W'(p)))
          pend_ot[p] <= pend_ot[p] + 1'b1;
        else if (drn_push && drn_port == PORT_W'(p) && !(s_load && sel == PORT_W'(p)))
          pend_ot[p] <= pend_ot[p] - 1'b1;
      end
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      wr_out      <= '0;
      wr_err_flag <= 1'b0;
      err_status  <= '0;
    end else begin
      if (s_store && !wr_dec)      wr_out <= wr_out + 1'b1;
      else if (wr_dec && !s_store) wr_out <= wr_out - 1'b1;
      if (wr_dec && mem_rsp_err)   wr_err_flag <= 1'b1;
      else if (act_done)           wr_err_flag <= 1'b0;
      if (iss && s_addr[1:0] != 2'b00) err_status[gc_pkg::ERR_MISALIGNED] <= 1'b1;
      if (iss && s_op[1])              err_status[gc_pkg::ERR_BADOP]      <= 1'b1;
      if (drn_push && ot_err[drn_idx]) err_status[gc_pkg::ERR_MEM_RD]     <= 1'b1;
      if (wr_dec && mem_rsp_err)       err_status[gc_pkg::ERR_MEM_WR]     <= 1'b1;
      if (spurious)                    err_status[gc_pkg::ERR_SPURIOUS]   <= 1'b1;
      if (ctrl_bad)                    err_status[gc_pkg::ERR_CTRL_BADOP] <= 1'b1;
    end
  end

  assign quiesced = (&in_empty) && ot_all_free && mq_empty && (wr_out == '0);
  assign busy     = !quiesced;

  // ---------------------------------------------------------------------------
  // performance counters
  // ---------------------------------------------------------------------------
  logic [gc_pkg::N_EV*INC_W-1:0] ev_inc;
  always_comb begin
    ev_inc = '0;
    ev_inc[gc_pkg::EV_LD*INC_W +: INC_W]         = INC_W'(s_load);
    ev_inc[gc_pkg::EV_ST*INC_W +: INC_W]         = INC_W'(s_store);
    ev_inc[gc_pkg::EV_MEM_RD_DEM*INC_W +: INC_W] = INC_W'(s_load);
    ev_inc[gc_pkg::EV_MEM_WR*INC_W +: INC_W]     = INC_W'(s_store);
    ev_inc[gc_pkg::EV_ERR_RSP*INC_W +: INC_W]    = INC_W'(iss && s_bad) +
                                                   INC_W'(drn_push && ot_err[drn_idx]);
    ev_inc[gc_pkg::EV_MEM_ERR*INC_W +: INC_W]    = INC_W'((rd_ok || wr_dec) && mem_rsp_err);
    ev_inc[gc_pkg::EV_SPURIOUS*INC_W +: INC_W]   = INC_W'(spurious);
    ev_inc[gc_pkg::EV_CTRL*INC_W +: INC_W]       = INC_W'(act_done || ctrl_bad);
  end

  gc_perf #(.N_EV(gc_pkg::N_EV), .INC_W(INC_W)) u_perf (
    .clk, .rst, .inc(ev_inc), .count(perf_count)
  );

  // ---------------------------------------------------------------------------
  // debug commit stream
  // ---------------------------------------------------------------------------
  assign dbg_commit_valid = iss;
  assign dbg_commit_port  = sel;
  assign dbg_commit_tag   = s_tag;
  assign dbg_commit_op    = s_op;
  assign dbg_commit_addr  = s_addr;
  assign dbg_commit_wdata = s_wdata;
  assign dbg_commit_wstrb = s_wstrb;
  assign dbg_commit_err   = s_bad;

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_ok;
  assign unused_ok = act_inval ^ (|in_head[0]);
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
