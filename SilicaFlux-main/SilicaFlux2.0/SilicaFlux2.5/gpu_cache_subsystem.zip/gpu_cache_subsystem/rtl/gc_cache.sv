// -----------------------------------------------------------------------------
// gc_cache - configurable non-blocking GPU L1-style data cache
//
// Policy summary (full specification: docs/SPEC.md)
//   * NUM_SETS x NUM_WAYS x LINE_BYTES, physically indexed/tagged byte address
//   * replacement: REPL=0 true LRU, 1 FIFO, 2 pseudo-random (LFSR);
//     an invalid way is always chosen first
//   * write-through, no-write-allocate; store hits update the line in place;
//     stores are posted (ack when queued), failures surface at the next ctrl op
//   * N_MSHR miss-status holding registers, each tracking one line and up to
//     N_TGT merged load targets {port, tag, word}; secondary misses merge
//   * stores to a line with a pending fill are replayed until the fill lands
//   * one request per cycle through a 2-stage pipeline:
//        S0: pick source (fill > core ports RR > prefetch), read tag/data RAMs
//        S1: compare, then COMMIT or REPLAY (never stalls in place)
//     a replayed core request stays at the head of its port FIFO, so per-port
//     program order is preserved; a port has at most one request in S1
//   * responses are routed to per-port response FIFOs; fills drain their
//     merged targets one per cycle
//   * FENCE/FLUSH/INVAL through gc_ctrl_fsm; FLUSH == INVAL under write-through
//   * optional conservative stride prefetcher (PF_ENABLE=1, runtime pf_enable)
// The commit point (dbg_commit_*) is the S1 cycle in which a core request
// commits; the cache is linearizable w.r.t. this order (verified by the TB).
// -----------------------------------------------------------------------------
module gc_cache #(
  parameter int NUM_PORTS     = 4,
  parameter int ADDR_W        = 32,
  parameter int LINE_BYTES    = 64,
  parameter int NUM_SETS      = 64,
  parameter int NUM_WAYS      = 4,
  parameter int REPL          = 0,     // 0 LRU, 1 FIFO, 2 RANDOM
  parameter int N_MSHR        = 16,
  parameter int N_TGT         = 8,
  parameter int IN_DEPTH      = 2,
  parameter int RSP_DEPTH     = 16,    // also = max undelivered responses per port
  parameter int MEMQ_DEPTH    = 4,
  parameter int TAG_W         = 8,
  parameter int PC_W          = 8,
  parameter int WR_OUT_MAX    = 63,
  parameter int PF_ENABLE     = 0,     // 1 = build the stride prefetcher
  parameter int PF_ENTRIES    = 16,
  parameter int PF_CONF_TH    = 2,
  parameter int PF_MSHR_RSV   = 2,     // MSHRs always left free for demand misses
  parameter int PF_PAGE_SHIFT = 12,
  parameter int PF_QDEPTH     = 2,
  parameter int POLL_ENTRIES  = 64,    // pollution filter entries (metric only)
  parameter int MEM_ID_W      = (N_MSHR > 1) ? $clog2(N_MSHR) : 1,
  parameter int PORT_W        = (NUM_PORTS > 1) ? $clog2(NUM_PORTS) : 1,
  parameter int LINE_BITS     = LINE_BYTES * 8
) (
  input  logic                        clk,
  input  logic                        rst,
  // ---- core ports (flattened: port p uses slice p) ----
  input  logic [NUM_PORTS-1:0]        req_valid,
  output logic [NUM_PORTS-1:0]        req_ready,
  input  logic [NUM_PORTS*2-1:0]      req_op,
  input  logic [NUM_PORTS*ADDR_W-1:0] req_addr,
  input  logic [NUM_PORTS*32-1:0]     req_wdata,
  input  logic [NUM_PORTS*4-1:0]      req_wstrb,
  input  logic [NUM_PORTS*TAG_W-1:0]  req_tag,
  input  logic [NUM_PORTS*PC_W-1:0]   req_pc,
  output logic [NUM_PORTS-1:0]        rsp_valid,
  input  logic [NUM_PORTS-1:0]        rsp_ready,
  output logic [NUM_PORTS*TAG_W-1:0]  rsp_tag,
  output logic [NUM_PORTS*32-1:0]     rsp_rdata,
  output logic [NUM_PORTS-1:0]        rsp_err,
  output logic [NUM_PORTS-1:0]        rsp_is_store,
  // ---- control ----
  input  logic                        ctrl_valid,
  output logic                        ctrl_ready,
  input  logic [1:0]                  ctrl_op,
  output logic                        ctrl_done,
  output logic                        ctrl_err,
  input  logic                        pf_enable,
  /* verilator lint_off UNUSEDSIGNAL */
  input  logic [3:0]                  pf_dist,
  /* verilator lint_on UNUSEDSIGNAL */
  // ---- memory ----
  output logic                        mem_req_valid,
  input  logic                        mem_req_ready,
  output logic                        mem_req_we,
  output logic [ADDR_W-1:0]           mem_req_addr,
  output logic [LINE_BITS-1:0]        mem_req_wdata,
  output logic [LINE_BYTES-1:0]       mem_req_be,
  output logic [MEM_ID_W-1:0]         mem_req_id,
  output logic                        mem_req_pf,
  input  logic                        mem_rsp_valid,
  output logic                        mem_rsp_ready,
  input  logic                        mem_rsp_we,
  input  logic [MEM_ID_W-1:0]         mem_rsp_id,
  input  logic [LINE_BITS-1:0]        mem_rsp_rdata,
  input  logic                        mem_rsp_err,
  // ---- status ----
  output logic [gc_pkg::N_ERR-1:0]    err_status,
  output logic [gc_pkg::N_EV*32-1:0]  perf_count,
  output logic                        busy,
  // ---- debug commit stream (verification / tracing) ----
  output logic                        dbg_commit_valid,
  output logic [PORT_W-1:0]           dbg_commit_port,
  output logic [TAG_W-1:0]            dbg_commit_tag,
  output logic [1:0]                  dbg_commit_op,
  output logic [ADDR_W-1:0]           dbg_commit_addr,
  output logic [31:0]                 dbg_commit_wdata,
  output logic [3:0]                  dbg_commit_wstrb,
  output logic                        dbg_commit_err
);
  // ---------------------------------------------------------------------------
  // derived parameters
  // ---------------------------------------------------------------------------
  localparam int WPL    = LINE_BYTES / 4;
  localparam int WOFF_W = $clog2(WPL);
  localparam int LSH    = $clog2(LINE_BYTES);
  localparam int SET_W  = $clog2(NUM_SETS);
  localparam int TAGB   = ADDR_W - LSH - SET_W;
  localparam int LA_W   = ADDR_W - LSH;
  localparam int WAY_W  = (NUM_WAYS > 1) ? $clog2(NUM_WAYS) : 1;
  localparam int MI_W   = MEM_ID_W;
  localparam int TGT_W  = (N_TGT > 1) ? $clog2(N_TGT) : 1;
  localparam int TCNT_W = $clog2(N_TGT + 1);
  localparam int MCNT_W = $clog2(N_MSHR + 1);
  localparam int IN_W   = 2 + ADDR_W + 32 + 4 + TAG_W + PC_W;
  localparam int RSP_W  = 2 + TAG_W + 32;
  localparam int MQ_W   = 1 + LA_W + WOFF_W + 32 + 4 + MEM_ID_W + 1 + 1;
  localparam int WRC_W  = $clog2(WR_OUT_MAX + 1);
  localparam int NLINES = NUM_SETS * NUM_WAYS;
  localparam int INC_W  = ($clog2(NLINES + 1) > 4) ? $clog2(NLINES + 1) : 4;
  localparam int TE_W   = PORT_W + TAG_W + WOFF_W;   // MSHR target entry
  localparam int RCNT_W = $clog2(RSP_DEPTH + 1);
  // never reserve every MSHR (a 2-entry file would otherwise never prefetch)
  localparam int PF_RSV = (PF_MSHR_RSV < N_MSHR) ? PF_MSHR_RSV : N_MSHR - 1;

  localparam logic [1:0] SRC_PORT = 2'd0;
  localparam logic [1:0] SRC_FILL = 2'd1;
  localparam logic [1:0] SRC_PF   = 2'd2;

  localparam logic [1:0] MS_FREE   = 2'd0;
  localparam logic [1:0] MS_PEND   = 2'd1;  // read queued/outstanding
  localparam logic [1:0] MS_FILLED = 2'd2;  // data back, waiting to install
  localparam logic [1:0] MS_DRAIN  = 2'd3;  // installed (or errored), returning targets

  // ---------------------------------------------------------------------------
  // control FSM
  // ---------------------------------------------------------------------------
  logic quiesced, wr_err_flag, draining, act_inval, act_done, ctrl_bad;

  gc_ctrl_fsm u_ctrl (
    .clk, .rst, .ctrl_valid, .ctrl_ready, .ctrl_op, .ctrl_done, .ctrl_err,
    .quiesced, .wr_err_pending(wr_err_flag), .draining, .act_inval, .act_done,
    .bad_op(ctrl_bad)
  );

  // ---------------------------------------------------------------------------
  // input FIFOs (a request leaves its FIFO only when it COMMITS in S1)
  // ---------------------------------------------------------------------------
  logic [NUM_PORTS-1:0] in_empty, in_full, in_pop;
  logic [IN_W-1:0]      in_head [0:NUM_PORTS-1];
  logic [1:0]           h_op    [0:NUM_PORTS-1];
  logic [ADDR_W-1:0]    h_addr  [0:NUM_PORTS-1];
  logic [31:0]          h_wdata [0:NUM_PORTS-1];
  logic [3:0]           h_wstrb [0:NUM_PORTS-1];
  logic [TAG_W-1:0]     h_tag   [0:NUM_PORTS-1];
  /* verilator lint_off UNUSEDSIGNAL */
  logic [PC_W-1:0]      h_pc    [0:NUM_PORTS-1];
  /* verilator lint_on UNUSEDSIGNAL */

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_in
    gc_fifo #(.W(IN_W), .DEPTH(IN_DEPTH)) u_in (
      .clk, .rst,
      .push  (req_valid[p] && req_ready[p]),
      .wdata ({req_pc[p*PC_W +: PC_W], req_tag[p*TAG_W +: TAG_W], req_wstrb[p*4 +: 4],
               req_wdata[p*32 +: 32], req_addr[p*ADDR_W +: ADDR_W], req_op[p*2 +: 2]}),
      .pop   (in_pop[p]),
      .rdata (in_head[p]),
      .empty (in_empty[p]),
      .full  (in_full[p]),
      .count ()
    );
    assign req_ready[p] = !rst && !in_full[p] && !draining;
  end

  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++) begin
      h_op[p]    = in_head[p][1:0];
      h_addr[p]  = in_head[p][2 +: ADDR_W];
      h_wdata[p] = in_head[p][2 + ADDR_W +: 32];
      h_wstrb[p] = in_head[p][2 + ADDR_W + 32 +: 4];
      h_tag[p]   = in_head[p][2 + ADDR_W + 36 +: TAG_W];
      h_pc[p]    = in_head[p][2 + ADDR_W + 36 + TAG_W +: PC_W];
    end
  end

  // ---------------------------------------------------------------------------
  // response FIFOs (one per port; written by S1 or by the MSHR drain unit)
  // ---------------------------------------------------------------------------
  logic [NUM_PORTS-1:0] rsp_full, rsp_empty, rsp_push;
  logic [RSP_W-1:0]     rsp_wdata [0:NUM_PORTS-1];
  logic [RSP_W-1:0]     rsp_head  [0:NUM_PORTS-1];
  logic [RCNT_W-1:0]    rsp_cnt   [0:NUM_PORTS-1];
  // Response-slot reservation: a load miss/merge reserves a slot in its
  // port's response FIFO at commit (pend_tgt).  Every commit that will
  // produce a response requires rsp_cnt + pend_tgt < RSP_DEPTH, so the drain
  // unit can always deliver: a port that stops accepting responses can never
  // pin shared MSHRs and block the other ports.
  logic [RCNT_W-1:0]    pend_tgt  [0:NUM_PORTS-1];
  logic [NUM_PORTS-1:0] rsv_ok;

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_rsp
    gc_fifo #(.W(RSP_W), .DEPTH(RSP_DEPTH)) u_rsp (
      .clk, .rst,
      .push  (rsp_push[p]),
      .wdata (rsp_wdata[p]),
      .pop   (rsp_valid[p] && rsp_ready[p]),
      .rdata (rsp_head[p]),
      .empty (rsp_empty[p]),
      .full  (rsp_full[p]),
      .count (rsp_cnt[p])
    );
    assign rsv_ok[p] = ({1'b0, rsp_cnt[p]} + {1'b0, pend_tgt[p]}) < (RCNT_W + 1)'(RSP_DEPTH);
    assign rsp_valid[p]              = !rsp_empty[p];
    assign rsp_rdata[p*32 +: 32]     = rsp_head[p][31:0];
    assign rsp_tag[p*TAG_W +: TAG_W] = rsp_head[p][32 +: TAG_W];
    assign rsp_err[p]                = rsp_head[p][32 + TAG_W];
    assign rsp_is_store[p]           = rsp_head[p][33 + TAG_W];
  end

  // ---------------------------------------------------------------------------
  // MSHR file
  // ---------------------------------------------------------------------------
  logic [1:0]          ms_state [0:N_MSHR-1];
  logic [LA_W-1:0]     ms_line  [0:N_MSHR-1];
  logic                ms_pf    [0:N_MSHR-1];   // allocated by a prefetch
  logic                ms_dem   [0:N_MSHR-1];   // has (had) a demand target
  logic                ms_err   [0:N_MSHR-1];
  logic [LINE_BITS-1:0] ms_data [0:N_MSHR-1];   // fill buffer
  logic [TCNT_W-1:0]   ms_ntgt  [0:N_MSHR-1];
  logic [TGT_W-1:0]    ms_dptr  [0:N_MSHR-1];
  logic [TE_W-1:0]     ms_tgt   [0:N_MSHR*N_TGT-1];  // {port, tag, word}

  // ---------------------------------------------------------------------------
  // memory request queue (in order: preserves RAW/WAW order to memory)
  // ---------------------------------------------------------------------------
  logic             mq_push, mq_empty, mq_full;
  logic [MQ_W-1:0]  mq_wdata, mq_head;
  logic [WRC_W-1:0] wr_out;
  logic             wr_ok;

  gc_fifo #(.W(MQ_W), .DEPTH(MEMQ_DEPTH)) u_mq (
    .clk, .rst, .push(mq_push), .wdata(mq_wdata),
    .pop(mem_req_valid && mem_req_ready), .rdata(mq_head),
    .empty(mq_empty), .full(mq_full), .count()
  );
  assign wr_ok = (wr_out < WRC_W'(WR_OUT_MAX));

  // ---------------------------------------------------------------------------
  // tag/data arrays, valid / prefetched bits, replacement state
  // ---------------------------------------------------------------------------
  logic [NUM_WAYS-1:0]       valid_q [0:NUM_SETS-1];
  logic [NUM_WAYS-1:0]       pfbit_q [0:NUM_SETS-1];   // prefetched, not yet used
  logic [NUM_WAYS*WAY_W-1:0] age_q   [0:NUM_SETS-1];   // LRU ages (0 = MRU)
  logic [WAY_W-1:0]          fifo_q  [0:NUM_SETS-1];   // FIFO pointer
  logic [15:0]               lfsr_q;

  logic                      arr_re;
  logic [SET_W-1:0]          arr_raddr;
  logic [TAGB-1:0]           tag_rd  [0:NUM_WAYS-1];
  logic [LINE_BITS-1:0]      data_rd [0:NUM_WAYS-1];
  logic [NUM_WAYS-1:0]       tag_we, data_we;
  logic [SET_W-1:0]          arr_waddr;
  logic [TAGB-1:0]           tag_wdata;
  logic [LINE_BITS-1:0]      data_wdata;
  logic [LINE_BYTES-1:0]     data_wlane;

  for (genvar w = 0; w < NUM_WAYS; w++) begin : g_way
    gc_sram_1r1w #(.W(TAGB), .DEPTH(NUM_SETS), .LANES(1)) u_tag (
      .clk, .re(arr_re), .raddr(arr_raddr), .rdata(tag_rd[w]),
      .we(tag_we[w]), .waddr(arr_waddr), .wdata(tag_wdata), .wlane(1'b1)
    );
    gc_sram_1r1w #(.W(LINE_BITS), .DEPTH(NUM_SETS), .LANES(LINE_BYTES)) u_data (
      .clk, .re(arr_re), .raddr(arr_raddr), .rdata(data_rd[w]),
      .we(data_we[w]), .waddr(arr_waddr), .wdata(data_wdata), .wlane(data_wlane)
    );
  end

  // ---------------------------------------------------------------------------
  // S1 pipeline register (declared early: S0 hazards look at it)
  // ---------------------------------------------------------------------------
  logic              s1_valid;
  logic [1:0]        s1_src;
  logic [PORT_W-1:0] s1_port;
  logic [MI_W-1:0]   s1_mshr;
  logic [LA_W-1:0]   s1_pfline;

  /* verilator lint_off UNUSEDSIGNAL */
  logic [ADDR_W-1:0] s1_addr;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [LA_W-1:0]   s1_line;
  logic [SET_W-1:0]  s1_set;
  logic [TAGB-1:0]   s1_tagb;
  logic [WOFF_W-1:0] s1_woff;
  logic [1:0]        s1_op;
  logic              s1_wr_haz;

  always_comb begin
    case (s1_src)
      SRC_FILL: s1_addr = {ms_line[s1_mshr], {LSH{1'b0}}};
      SRC_PF:   s1_addr = {s1_pfline, {LSH{1'b0}}};
      default:  s1_addr = h_addr[s1_port];
    endcase
    s1_line = s1_addr[ADDR_W-1:LSH];
    s1_set  = s1_addr[LSH +: SET_W];
    s1_tagb = s1_addr[ADDR_W-1 -: TAGB];
    s1_woff = s1_addr[2 +: WOFF_W];
    s1_op   = h_op[s1_port];
    // anything in S1 that may write the tag/data arrays this cycle
    s1_wr_haz = s1_valid && ((s1_src == SRC_FILL) ||
                             (s1_src == SRC_PORT && s1_op == gc_pkg::OP_STORE));
  end

  // ---------------------------------------------------------------------------
  // prefetcher (optional)
  // ---------------------------------------------------------------------------
  logic            pf_on;
  /* verilator lint_off UNUSEDSIGNAL */
  logic            pfq_valid, pfq_pop;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [LA_W-1:0] pfq_line;
  logic            pf_ev_cand, pf_ev_drop;
  /* verilator lint_off UNUSEDSIGNAL */
  logic            train_v;
  /* verilator lint_on UNUSEDSIGNAL */

  assign pf_on = (PF_ENABLE != 0) && pf_enable;

  if (PF_ENABLE != 0) begin : g_pf
    gc_pf_stride #(
      .ADDR_W(ADDR_W), .LSH(LSH), .PORT_W(PORT_W), .PC_W(PC_W),
      .ENTRIES(PF_ENTRIES), .CONF_TH(PF_CONF_TH), .PAGE_SHIFT(PF_PAGE_SHIFT),
      .QDEPTH(PF_QDEPTH)
    ) u_pf (
      .clk, .rst,
      .clear      (act_inval || !pf_enable),
      .enable     (pf_on && !draining),
      .dist_in    (pf_dist),
      .train_valid(train_v),
      .train_port (s1_port),
      .train_pc   (h_pc[s1_port]),
      .train_addr (h_addr[s1_port]),
      .q_valid    (pfq_valid),
      .q_line     (pfq_line),
      .q_pop      (pfq_pop),
      .ev_cand    (pf_ev_cand),
      .ev_drop    (pf_ev_drop)
    );
  end else begin : g_nopf
    assign pfq_valid  = 1'b0;
    assign pfq_line   = '0;
    assign pf_ev_cand = 1'b0;
    assign pf_ev_drop = 1'b0;
  end

  // ---------------------------------------------------------------------------
  // replay sleep: a port whose head request replayed for an MSHR reason
  // (no free MSHR, target slots full, store to a pending line) is not
  // re-arbitrated until some MSHR changes state (a fill is processed or an
  // entry is freed).  Saves pipeline slots (which prefetches and other ports
  // can use) without affecting ordering.
  // ---------------------------------------------------------------------------
  logic [NUM_PORTS-1:0] wait_q;
  logic                 ms_event;

  // ---------------------------------------------------------------------------
  // S0: source selection and array read
  // ---------------------------------------------------------------------------
  logic [N_MSHR-1:0]    fill_ok;
  logic                 fill_any;
  logic [MI_W-1:0]      fill_sel;
  logic [NUM_PORTS-1:0] port_ok;
  logic                 port_any;
  logic [PORT_W-1:0]    port_sel;
  logic                 pf_ok;
  logic                 s0_issue;
  logic [1:0]           s0_src;
  logic [SET_W-1:0]     s0_set;

  always_comb begin
    for (int m = 0; m < N_MSHR; m++)
      fill_ok[m] = (ms_state[m] == MS_FILLED) &&
                   !(s1_wr_haz && (ms_line[m][SET_W-1:0] == s1_set));
    fill_any = 1'b0;
    fill_sel = '0;
    for (int m = 0; m < N_MSHR; m++) begin
      if (!fill_any && fill_ok[m]) begin
        fill_any = 1'b1;
        fill_sel = MI_W'(m);
      end
    end
    for (int p = 0; p < NUM_PORTS; p++)
      port_ok[p] = !in_empty[p] && !wait_q[p] &&
                   !(s1_valid && s1_src == SRC_PORT && s1_port == PORT_W'(p)) &&
                   !(s1_wr_haz && (h_addr[p][LSH +: SET_W] == s1_set));
    pf_ok = pfq_valid && pf_on && !draining &&
            !(s1_wr_haz && (pfq_line[SET_W-1:0] == s1_set));
  end

  gc_rr_arb #(.N(NUM_PORTS), .IW(PORT_W)) u_arb (
    .clk, .rst, .req(port_ok), .advance(!fill_any), .any(port_any), .gnt_idx(port_sel)
  );

  always_comb begin
    if (fill_any) begin
      s0_src = SRC_FILL;
      s0_set = ms_line[fill_sel][SET_W-1:0];
    end else if (port_any) begin
      s0_src = SRC_PORT;
      s0_set = h_addr[port_sel][LSH +: SET_W];
    end else begin
      s0_src = SRC_PF;
      s0_set = pfq_line[SET_W-1:0];
    end
    s0_issue = fill_any || port_any || pf_ok;
  end

  assign arr_re    = s0_issue;
  assign arr_raddr = s0_set;
  assign pfq_pop   = s0_issue && (s0_src == SRC_PF);

  always_ff @(posedge clk) begin
    if (rst) begin
      s1_valid <= 1'b0;
    end else begin
      s1_valid <= s0_issue;
    end
    if (s0_issue) begin
      s1_src    <= s0_src;
      s1_port   <= port_sel;
      s1_mshr   <= fill_sel;
      s1_pfline <= pfq_line;
    end
  end

  // ---------------------------------------------------------------------------
  // S1: lookup
  // ---------------------------------------------------------------------------
  logic [NUM_WAYS-1:0] way_hit;
  logic                hit;
  logic [WAY_W-1:0]    hit_way;
  logic [31:0]         hit_word;
  logic [N_MSHR-1:0]   m_match;
  logic                match_any;
  logic [MI_W-1:0]     match_idx;
  logic                free_any;
  logic [MI_W-1:0]     free_idx;
  logic [MCNT_W-1:0]   free_cnt;
  logic                all_free;

  always_comb begin
    hit     = 1'b0;
    hit_way = '0;
    for (int w = 0; w < NUM_WAYS; w++) begin
      way_hit[w] = valid_q[s1_set][w] && (tag_rd[w] == s1_tagb);
      if (!hit && way_hit[w]) begin
        hit     = 1'b1;
        hit_way = WAY_W'(w);
      end
    end
    hit_word = data_rd[hit_way][s1_woff*32 +: 32];

    match_any = 1'b0;
    match_idx = '0;
    free_any  = 1'b0;
    free_idx  = '0;
    free_cnt  = '0;
    all_free  = 1'b1;
    for (int m = 0; m < N_MSHR; m++) begin
      m_match[m] = ((ms_state[m] == MS_PEND) || (ms_state[m] == MS_FILLED)) &&
                   (ms_line[m] == s1_line);
      if (!match_any && m_match[m]) begin
        match_any = 1'b1;
        match_idx = MI_W'(m);
      end
      if (ms_state[m] == MS_FREE) begin
        free_cnt = free_cnt + 1'b1;
        if (!free_any) begin
          free_any = 1'b1;
          free_idx = MI_W'(m);
        end
      end else begin
        all_free = 1'b0;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // drain unit: returns one merged target per cycle from a DRAIN MSHR
  // ---------------------------------------------------------------------------
  logic              drn_push;
  logic [MI_W-1:0]   drn_idx;
  logic [TE_W-1:0]   drn_te;
  logic [PORT_W-1:0] drn_port;
  logic [TAG_W-1:0]  drn_tag;
  logic [WOFF_W-1:0] drn_off;
  logic [31:0]       drn_word;
  logic              drn_last;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [TE_W-1:0]   te_tmp;
  /* verilator lint_on UNUSEDSIGNAL */

  always_comb begin
    drn_push = 1'b0;
    drn_idx  = '0;
    for (int m = 0; m < N_MSHR; m++) begin
      te_tmp = ms_tgt[m*N_TGT + 32'(ms_dptr[m])];
      if (!drn_push && ms_state[m] == MS_DRAIN && !rsp_full[te_tmp[TE_W-1 -: PORT_W]]) begin
        drn_push = 1'b1;
        drn_idx  = MI_W'(m);
      end
    end
    drn_te   = ms_tgt[32'(drn_idx)*N_TGT + 32'(ms_dptr[drn_idx])];
    drn_port = drn_te[TE_W-1 -: PORT_W];
    drn_tag  = drn_te[WOFF_W +: TAG_W];
    drn_off  = drn_te[WOFF_W-1:0];
    drn_word = ms_err[drn_idx] ? 32'h0 : ms_data[drn_idx][drn_off*32 +: 32];
    drn_last = (TCNT_W'(ms_dptr[drn_idx]) + 1'b1) == ms_ntgt[drn_idx];
  end

  // ---------------------------------------------------------------------------
  // S1: decision (commit / replay) and side effects
  // ---------------------------------------------------------------------------
  logic              s1_bad, rsp_space_s1;
  logic              p_commit, p_replay;
  logic              rpl_mshr, rpl_sthaz, rpl_res;
  logic              s1_rsp_push;
  logic [RSP_W-1:0]  s1_rsp_data;
  logic              ms_alloc, ms_alloc_pf, ms_merge;
  logic              ld_hit_c, st_hit_c, ld_miss_c, st_c, ld_c;
  logic              pf_useful_c, pf_late_c, pf_filt_c, pf_drop_c;
  logic              fill_c, fill_err_c, fill_inst;
  logic [WAY_W-1:0]  victim;
  logic              victim_valid, victim_pf;
  logic [NUM_WAYS-1:0] inv_ways;
  logic              lru_touch;
  logic [WAY_W-1:0]  touch_way;

  assign s1_bad       = h_op[s1_port][1] || (h_addr[s1_port][1:0] != 2'b00);
  assign rsp_space_s1 = rsv_ok[s1_port] && !(drn_push && drn_port == s1_port);

  // victim selection (used by fills)
  always_comb begin
    inv_ways = ~valid_q[s1_set];
    victim   = '0;
    if (NUM_WAYS > 1) begin
      if (|inv_ways) begin
        for (int w = NUM_WAYS - 1; w >= 0; w--) if (inv_ways[w]) victim = WAY_W'(w);
      end else if (REPL == 1) begin
        victim = fifo_q[s1_set];
      end else if (REPL == 2) begin
        victim = lfsr_q[WAY_W-1:0];
      end else begin
        for (int w = 0; w < NUM_WAYS; w++)
          if (age_q[s1_set][w*WAY_W +: WAY_W] == WAY_W'(NUM_WAYS - 1)) victim = WAY_W'(w);
      end
    end
    victim_valid = valid_q[s1_set][victim];
    victim_pf    = victim_valid && pfbit_q[s1_set][victim];
  end

  always_comb begin
    p_commit    = 1'b0;  p_replay  = 1'b0;
    rpl_mshr    = 1'b0;  rpl_sthaz = 1'b0;  rpl_res = 1'b0;
    s1_rsp_push = 1'b0;
    s1_rsp_data = {(s1_op == gc_pkg::OP_STORE), 1'b0, h_tag[s1_port], hit_word};
    mq_push     = 1'b0;
    mq_wdata    = '0;
    ms_alloc    = 1'b0;  ms_alloc_pf = 1'b0;  ms_merge = 1'b0;
    ld_c = 1'b0; ld_hit_c = 1'b0; ld_miss_c = 1'b0; st_c = 1'b0; st_hit_c = 1'b0;
    pf_useful_c = 1'b0;  pf_late_c = 1'b0;  pf_filt_c = 1'b0;  pf_drop_c = 1'b0;
    fill_c = 1'b0;  fill_err_c = 1'b0;  fill_inst = 1'b0;
    lru_touch = 1'b0;  touch_way = hit_way;
    tag_we = '0;  data_we = '0;
    arr_waddr  = s1_set;
    tag_wdata  = s1_tagb;
    data_wdata = {WPL{h_wdata[s1_port]}};
    data_wlane = LINE_BYTES'(h_wstrb[s1_port]) << {s1_woff, 2'b00};

    if (s1_valid) begin
      case (s1_src)
        // ------------------------------------------------------------ core ---
        SRC_PORT: begin
          if (s1_bad) begin
            if (rsp_space_s1) begin
              p_commit    = 1'b1;
              s1_rsp_push = 1'b1;
              s1_rsp_data = {(s1_op == gc_pkg::OP_STORE), 1'b1, h_tag[s1_port], 32'h0};
            end else begin
              p_replay = 1'b1;  rpl_res = 1'b1;
            end
          end else if (s1_op == gc_pkg::OP_LOAD) begin
            if (hit) begin
              if (rsp_space_s1) begin
                p_commit    = 1'b1;  ld_c = 1'b1;  ld_hit_c = 1'b1;
                s1_rsp_push = 1'b1;
                lru_touch   = 1'b1;  touch_way = hit_way;
                pf_useful_c = pfbit_q[s1_set][hit_way];
              end else begin
                p_replay = 1'b1;  rpl_res = 1'b1;
              end
            end else if (!rsv_ok[s1_port]) begin
              p_replay = 1'b1;  rpl_res = 1'b1;   // no response slot to reserve
            end else if (match_any) begin
              if (ms_ntgt[match_idx] < TCNT_W'(N_TGT)) begin
                p_commit  = 1'b1;  ld_c = 1'b1;
                ms_merge  = 1'b1;
                pf_late_c = ms_pf[match_idx] && !ms_dem[match_idx];
              end else begin
                p_replay = 1'b1;  rpl_mshr = 1'b1;
              end
            end else if (free_any && !mq_full) begin
              p_commit  = 1'b1;  ld_c = 1'b1;  ld_miss_c = 1'b1;
              ms_alloc  = 1'b1;
              mq_push   = 1'b1;
              mq_wdata  = {1'b1, 1'b0, MEM_ID_W'(free_idx), 4'hF, 32'h0,
                           WOFF_W'(0), s1_line, 1'b0};
            end else begin
              p_replay = 1'b1;
              if (!free_any) rpl_mshr = 1'b1; else rpl_res = 1'b1;
            end
          end else begin  // OP_STORE
            if (match_any) begin
              p_replay = 1'b1;  rpl_sthaz = 1'b1;
            end else if (!mq_full && rsp_space_s1 && wr_ok) begin
              p_commit    = 1'b1;  st_c = 1'b1;
              mq_push     = 1'b1;
              mq_wdata    = {1'b0, 1'b0, MEM_ID_W'(0), h_wstrb[s1_port], h_wdata[s1_port],
                             s1_woff, s1_line, 1'b1};
              s1_rsp_push = 1'b1;
              s1_rsp_data = {1'b1, 1'b0, h_tag[s1_port], 32'h0};
              if (hit) begin
                st_hit_c  = 1'b1;
                data_we   = NUM_WAYS'(1) << hit_way;
                lru_touch = 1'b1;  touch_way = hit_way;
              end
            end else begin
              p_replay = 1'b1;  rpl_res = 1'b1;
            end
          end
        end
        // ------------------------------------------------------------ fill ---
        SRC_FILL: begin
          fill_c = 1'b1;
          if (ms_err[s1_mshr]) begin
            fill_err_c = 1'b1;
          end else begin
            fill_inst  = 1'b1;
            tag_we     = NUM_WAYS'(1) << victim;
            data_we    = NUM_WAYS'(1) << victim;
            data_wdata = ms_data[s1_mshr];
            data_wlane = '1;
            lru_touch  = 1'b1;  touch_way = victim;
          end
        end
        // -------------------------------------------------------- prefetch ---
        SRC_PF: begin
          if (hit || match_any) begin
            pf_filt_c = 1'b1;
          end else if (pf_on && !draining && (32'(free_cnt) > PF_RSV) && !mq_full) begin
            ms_alloc    = 1'b1;
            ms_alloc_pf = 1'b1;
            mq_push     = 1'b1;
            mq_wdata    = {1'b1, 1'b1, MEM_ID_W'(free_idx), 4'hF, 32'h0,
                           WOFF_W'(0), s1_line, 1'b0};
          end else begin
            pf_drop_c = 1'b1;
          end
        end
        default: ;
      endcase
    end
  end

  assign train_v = p_commit && ld_c;

  assign ms_event = fill_c || (drn_push && drn_last);
  always_ff @(posedge clk) begin
    if (rst) begin
      wait_q <= '0;
    end else begin
      for (int p = 0; p < NUM_PORTS; p++)
        wait_q[p] <= !ms_event &&
                     (wait_q[p] || ((rpl_mshr || rpl_sthaz) && s1_port == PORT_W'(p)));
    end
  end

  // pop the port FIFO on commit
  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++)
      in_pop[p] = p_commit && (s1_port == PORT_W'(p));
  end

  // response FIFO writes: drain unit has priority (S1 checked rsp_space_s1)
  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++) begin
      if (drn_push && drn_port == PORT_W'(p)) begin
        rsp_push[p]  = 1'b1;
        rsp_wdata[p] = {1'b0, ms_err[drn_idx], drn_tag, drn_word};
      end else begin
        rsp_push[p]  = s1_rsp_push && (s1_port == PORT_W'(p));
        rsp_wdata[p] = s1_rsp_data;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // memory interface
  // ---------------------------------------------------------------------------
  logic              mq_we, mq_full_line;
  logic [LA_W-1:0]   mq_line;
  logic [WOFF_W-1:0] mq_woff;
  logic [31:0]       mq_wd;
  logic [3:0]        mq_ws;

  assign mq_we         = mq_head[0];
  assign mq_line       = mq_head[1 +: LA_W];
  assign mq_woff       = mq_head[1 + LA_W +: WOFF_W];
  assign mq_wd         = mq_head[1 + LA_W + WOFF_W +: 32];
  assign mq_ws         = mq_head[1 + LA_W + WOFF_W + 32 +: 4];
  assign mem_req_id    = mq_head[1 + LA_W + WOFF_W + 36 +: MEM_ID_W];
  assign mem_req_pf    = mq_head[1 + LA_W + WOFF_W + 36 + MEM_ID_W];
  assign mq_full_line  = mq_head[2 + LA_W + WOFF_W + 36 + MEM_ID_W];

  assign mem_req_valid = !mq_empty;
  assign mem_req_we    = mq_we;
  assign mem_req_addr  = {mq_line, {LSH{1'b0}}};
  assign mem_req_wdata = {WPL{mq_wd}};
  assign mem_req_be    = mq_full_line ? {LINE_BYTES{1'b1}}
                                      : (LINE_BYTES'(mq_ws) << {mq_woff, 2'b00});
  assign mem_rsp_ready = 1'b1;   // fill buffers are per-MSHR: never back-pressure

  logic rd_ok, wr_dec, spurious;
  assign rd_ok    = mem_rsp_valid && !mem_rsp_we && (32'(mem_rsp_id) < N_MSHR) &&
                    (ms_state[mem_rsp_id] == MS_PEND);
  assign wr_dec   = mem_rsp_valid && mem_rsp_we && (wr_out != '0);
  assign spurious = mem_rsp_valid && (mem_rsp_we ? (wr_out == '0) : !rd_ok);

  // ---------------------------------------------------------------------------
  // MSHR state updates
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int m = 0; m < N_MSHR; m++) ms_state[m] <= MS_FREE;
    end else begin
      if (ms_alloc) begin
        ms_state[free_idx] <= MS_PEND;
        ms_line[free_idx]  <= s1_line;
        ms_pf[free_idx]    <= ms_alloc_pf;
        ms_dem[free_idx]   <= !ms_alloc_pf;
        ms_err[free_idx]   <= 1'b0;
        ms_dptr[free_idx]  <= '0;
        ms_ntgt[free_idx]  <= ms_alloc_pf ? TCNT_W'(0) : TCNT_W'(1);
        ms_tgt[32'(free_idx)*N_TGT] <= {s1_port, h_tag[s1_port], s1_woff};
      end
      if (ms_merge) begin
        ms_tgt[32'(match_idx)*N_TGT + 32'(ms_ntgt[match_idx])] <= {s1_port, h_tag[s1_port], s1_woff};
        ms_ntgt[match_idx] <= ms_ntgt[match_idx] + 1'b1;
        ms_dem[match_idx]  <= 1'b1;
      end
      if (rd_ok) begin
        ms_state[mem_rsp_id] <= MS_FILLED;
        ms_data[mem_rsp_id]  <= mem_rsp_rdata;
        ms_err[mem_rsp_id]   <= mem_rsp_err;
      end
      if (fill_c) begin
        ms_state[s1_mshr] <= (ms_ntgt[s1_mshr] == '0) ? MS_FREE : MS_DRAIN;
      end
      if (drn_push) begin
        if (drn_last) ms_state[drn_idx] <= MS_FREE;
        ms_dptr[drn_idx] <= ms_dptr[drn_idx] + 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // valid / prefetched bits and replacement state
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (rst || act_inval) begin
      for (int s = 0; s < NUM_SETS; s++) begin
        valid_q[s] <= '0;
        pfbit_q[s] <= '0;
        fifo_q[s]  <= '0;
        for (int w = 0; w < NUM_WAYS; w++) age_q[s][w*WAY_W +: WAY_W] <= WAY_W'(w);
      end
    end else begin
      if (fill_inst) begin
        valid_q[s1_set][victim] <= 1'b1;
        pfbit_q[s1_set][victim] <= ms_pf[s1_mshr] && !ms_dem[s1_mshr];
        if (!(|inv_ways)) fifo_q[s1_set] <= (victim == WAY_W'(NUM_WAYS - 1)) ? '0 : victim + 1'b1;
      end
      if (pf_useful_c) pfbit_q[s1_set][hit_way] <= 1'b0;
      if (lru_touch && NUM_WAYS > 1) begin
        for (int w = 0; w < NUM_WAYS; w++) begin
          if (WAY_W'(w) == touch_way)
            age_q[s1_set][w*WAY_W +: WAY_W] <= '0;
          else if (age_q[s1_set][w*WAY_W +: WAY_W] < age_q[s1_set][touch_way*WAY_W +: WAY_W])
            age_q[s1_set][w*WAY_W +: WAY_W] <= age_q[s1_set][w*WAY_W +: WAY_W] + 1'b1;
        end
      end
    end
  end

  always_ff @(posedge clk) begin
    if (rst) lfsr_q <= 16'hACE1;
    else     lfsr_q <= {lfsr_q[14:0], lfsr_q[15] ^ lfsr_q[13] ^ lfsr_q[12] ^ lfsr_q[10]};
  end

  // number of still-unused prefetched lines destroyed by an invalidate
  logic [INC_W-1:0] inval_pf_cnt;
  always_comb begin
    inval_pf_cnt = '0;
    for (int s = 0; s < NUM_SETS; s++)
      for (int w = 0; w < NUM_WAYS; w++)
        inval_pf_cnt = inval_pf_cnt + INC_W'(valid_q[s][w] && pfbit_q[s][w]);
  end

  // ---------------------------------------------------------------------------
  // pollution filter (metric only): lines evicted by prefetch fills
  // ---------------------------------------------------------------------------
  logic pollution_c;
  if (PF_ENABLE != 0) begin : g_poll
    localparam int PI_W = $clog2(POLL_ENTRIES);
    logic              pol_v    [0:POLL_ENTRIES-1];
    logic [LA_W-1:0]   pol_line [0:POLL_ENTRIES-1];
    logic [LA_W-1:0]   vic_line;
    logic [PI_W-1:0]   ins_idx, chk_idx;
    logic              ins;

    assign vic_line = {tag_rd[victim], s1_set};
    assign ins_idx  = vic_line[PI_W-1:0] ^ vic_line[2*PI_W-1:PI_W];
    assign chk_idx  = s1_line[PI_W-1:0] ^ s1_line[2*PI_W-1:PI_W];
    assign ins      = fill_inst && ms_pf[s1_mshr] && !ms_dem[s1_mshr] &&
                      victim_valid && !victim_pf;
    assign pollution_c = ld_miss_c && pol_v[chk_idx] && (pol_line[chk_idx] == s1_line);

    always_ff @(posedge clk) begin
      if (rst || act_inval) begin
        for (int i = 0; i < POLL_ENTRIES; i++) pol_v[i] <= 1'b0;
      end else begin
        if (ins) begin
          pol_v[ins_idx]    <= 1'b1;
          pol_line[ins_idx] <= vic_line;
        end
        if (pollution_c) pol_v[chk_idx] <= 1'b0;
      end
    end
  end else begin : g_nopoll
    assign pollution_c = 1'b0;
  end

  // ---------------------------------------------------------------------------
  // write credit, error status
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int p = 0; p < NUM_PORTS; p++) pend_tgt[p] <= '0;
    end else begin
      for (int p = 0; p < NUM_PORTS; p++) begin
        if ((ld_miss_c || ms_merge) && s1_port == PORT_W'(p) && !(drn_push && drn_port == PORT_W'(p)))
          pend_tgt[p] <= pend_tgt[p] + 1'b1;
        else if (drn_push && drn_port == PORT_W'(p) && !((ld_miss_c || ms_merge) && s1_port == PORT_W'(p)))
          pend_tgt[p] <= pend_tgt[p] - 1'b1;
      end
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      wr_out      <= '0;
      wr_err_flag <= 1'b0;
      err_status  <= '0;
    end else begin
      if (st_c && !wr_dec)      wr_out <= wr_out + 1'b1;
      else if (wr_dec && !st_c) wr_out <= wr_out - 1'b1;
      if (wr_dec && mem_rsp_err) wr_err_flag <= 1'b1;
      else if (act_done)         wr_err_flag <= 1'b0;
      if (p_commit && h_addr[s1_port][1:0] != 2'b00) err_status[gc_pkg::ERR_MISALIGNED] <= 1'b1;
      if (p_commit && s1_op[1])                      err_status[gc_pkg::ERR_BADOP]      <= 1'b1;
      if (drn_push && ms_err[drn_idx])               err_status[gc_pkg::ERR_MEM_RD]     <= 1'b1; // demand-visible only
      if (wr_dec && mem_rsp_err)                     err_status[gc_pkg::ERR_MEM_WR]     <= 1'b1;
      if (spurious)                                  err_status[gc_pkg::ERR_SPURIOUS]   <= 1'b1;
      if (ctrl_bad)                                  err_status[gc_pkg::ERR_CTRL_BADOP] <= 1'b1;
    end
  end

  assign quiesced = (&in_empty) && !s1_valid && all_free && mq_empty && (wr_out == '0);
  assign busy     = !quiesced;

  // ---------------------------------------------------------------------------
  // performance counters
  // ---------------------------------------------------------------------------
  logic [gc_pkg::N_EV*INC_W-1:0] ev_inc;
  always_comb begin
    ev_inc = '0;
    ev_inc[gc_pkg::EV_LD*INC_W +: INC_W]         = INC_W'(p_commit && ld_c);
    ev_inc[gc_pkg::EV_LD_HIT*INC_W +: INC_W]     = INC_W'(ld_hit_c);
    ev_inc[gc_pkg::EV_LD_MISS*INC_W +: INC_W]    = INC_W'(ld_miss_c);
    ev_inc[gc_pkg::EV_LD_MERGE*INC_W +: INC_W]   = INC_W'(ms_merge);
    ev_inc[gc_pkg::EV_ST*INC_W +: INC_W]         = INC_W'(st_c);
    ev_inc[gc_pkg::EV_ST_HIT*INC_W +: INC_W]     = INC_W'(st_hit_c);
    ev_inc[gc_pkg::EV_RPL_MSHR*INC_W +: INC_W]   = INC_W'(rpl_mshr);
    ev_inc[gc_pkg::EV_RPL_STHAZ*INC_W +: INC_W]  = INC_W'(rpl_sthaz);
    ev_inc[gc_pkg::EV_RPL_RES*INC_W +: INC_W]    = INC_W'(rpl_res);
    ev_inc[gc_pkg::EV_MEM_RD_DEM*INC_W +: INC_W] = INC_W'(ms_alloc && !ms_alloc_pf);
    ev_inc[gc_pkg::EV_MEM_RD_PF*INC_W +: INC_W]  = INC_W'(ms_alloc_pf);
    ev_inc[gc_pkg::EV_MEM_WR*INC_W +: INC_W]     = INC_W'(st_c);
    ev_inc[gc_pkg::EV_FILL*INC_W +: INC_W]       = INC_W'(fill_inst);
    ev_inc[gc_pkg::EV_EVICT*INC_W +: INC_W]      = INC_W'(fill_inst && victim_valid);
    ev_inc[gc_pkg::EV_PF_CAND*INC_W +: INC_W]    = INC_W'(pf_ev_cand);
    ev_inc[gc_pkg::EV_PF_FILT*INC_W +: INC_W]    = INC_W'(pf_filt_c);
    ev_inc[gc_pkg::EV_PF_DROP*INC_W +: INC_W]    = INC_W'(pf_drop_c) + INC_W'(pf_ev_drop);
    ev_inc[gc_pkg::EV_PF_USEFUL*INC_W +: INC_W]  = INC_W'(pf_useful_c);
    ev_inc[gc_pkg::EV_PF_LATE*INC_W +: INC_W]    = INC_W'(pf_late_c);
    ev_inc[gc_pkg::EV_PF_USELESS*INC_W +: INC_W] = INC_W'(fill_inst && victim_pf) +
                                                   (act_inval ? inval_pf_cnt : '0);
    ev_inc[gc_pkg::EV_POLLUTION*INC_W +: INC_W]  = INC_W'(pollution_c);
    ev_inc[gc_pkg::EV_ERR_RSP*INC_W +: INC_W]    = INC_W'(p_commit && s1_bad) +
                                                   INC_W'(drn_push && ms_err[drn_idx]);
    ev_inc[gc_pkg::EV_MEM_ERR*INC_W +: INC_W]    = INC_W'((rd_ok || wr_dec) && mem_rsp_err);
    ev_inc[gc_pkg::EV_SPURIOUS*INC_W +: INC_W]   = INC_W'(spurious);
    ev_inc[gc_pkg::EV_CTRL*INC_W +: INC_W]       = INC_W'(act_done || ctrl_bad);
    ev_inc[gc_pkg::EV_FILL_ERR*INC_W +: INC_W]   = INC_W'(fill_err_c);
  end

  gc_perf #(.N_EV(gc_pkg::N_EV), .INC_W(INC_W)) u_perf (
    .clk, .rst, .inc(ev_inc), .count(perf_count)
  );

  // ---------------------------------------------------------------------------
  // debug commit stream
  // ---------------------------------------------------------------------------
  assign dbg_commit_valid = s1_valid && (s1_src == SRC_PORT) && p_commit;
  assign dbg_commit_port  = s1_port;
  assign dbg_commit_tag   = h_tag[s1_port];
  assign dbg_commit_op    = s1_op;
  assign dbg_commit_addr  = h_addr[s1_port];
  assign dbg_commit_wdata = h_wdata[s1_port];
  assign dbg_commit_wstrb = h_wstrb[s1_port];
  assign dbg_commit_err   = s1_bad;

  // ---------------------------------------------------------------------------
  // simulation-only invariant checks
  // ---------------------------------------------------------------------------
`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (!rst) begin
      // a fill must never install a line that is already present
      if (s1_valid && s1_src == SRC_FILL && hit && !ms_err[s1_mshr])
        $error("%m: fill installs a line that is already cached (line %h)", s1_line);
      // at most one hit way per lookup
      if (s1_valid && $countones(way_hit) > 1)
        $error("%m: multiple ways hit in set %0d", s1_set);
      // at most one PEND/FILLED MSHR per line
      if (s1_valid && $countones(m_match) > 1)
        $error("%m: duplicate in-flight MSHRs for line %h", s1_line);
      // a replay must never coexist with a commit
      if (p_commit && p_replay) $error("%m: commit and replay together");
      // response FIFO single-writer discipline
      if (s1_rsp_push && drn_push && drn_port == s1_port)
        $error("%m: two writers to response FIFO %0d", s1_port);
      if (ms_merge && ms_ntgt[match_idx] >= TCNT_W'(N_TGT))
        $error("%m: MSHR target overflow");
      // reservation guarantees the drain unit never finds a full FIFO
      for (int m = 0; m < N_MSHR; m++)
        if (ms_state[m] == MS_DRAIN && rsp_full[ms_tgt[m*N_TGT + 32'(ms_dptr[m])][TE_W-1 -: PORT_W]])
          $error("%m: drain blocked by a full response FIFO despite reservation");
    end
  end
`endif
endmodule
