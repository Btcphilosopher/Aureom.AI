// -----------------------------------------------------------------------------
// gc_ctrl_fsm - FENCE / FLUSH / INVALIDATE sequencing (shared by both DUTs)
//
//   IDLE  --ctrl_valid & op<3-->  DRAIN  --quiesced-->  IDLE (+ctrl_done pulse)
//   IDLE  --ctrl_valid & op==3--> IDLE (+ctrl_done pulse with ctrl_err=1)
//
// While DRAIN: the owning block must stop accepting new core requests
// (req_ready=0) and stop issuing prefetches.  Requests accepted in the SAME
// cycle as the control op are ordered before it.  ctrl_done is a single-cycle
// pulse; ctrl_err is valid only with ctrl_done.  For FENCE/FLUSH/INVAL,
// ctrl_err reports any memory write error observed since the previous control
// completion (stores are posted, so this is where their failures surface).
// -----------------------------------------------------------------------------
module gc_ctrl_fsm (
  input  logic       clk,
  input  logic       rst,
  input  logic       ctrl_valid,
  output logic       ctrl_ready,
  input  logic [1:0] ctrl_op,
  output logic       ctrl_done,
  output logic       ctrl_err,
  input  logic       quiesced,       // nothing accepted is still outstanding
  input  logic       wr_err_pending, // a write error has been seen since last done
  output logic       draining,       // block new requests / prefetches
  output logic       act_inval,      // pulse: invalidate all lines now
  output logic       act_done,       // pulse: control op completes this cycle
  output logic       bad_op          // pulse: reserved op accepted
);
  logic       state_q;   // 0 = IDLE, 1 = DRAIN
  logic [1:0] op_q;
  logic       done_q, err_q;
  logic       accept;

  assign ctrl_ready = !rst && !state_q;
  assign accept     = ctrl_valid && ctrl_ready;
  assign bad_op     = accept && (ctrl_op == 2'd3);
  assign draining   = state_q;
  assign act_done   = state_q && quiesced;
  assign act_inval  = act_done && (op_q != gc_pkg::CTRL_FENCE);
  assign ctrl_done  = done_q;
  assign ctrl_err   = err_q;

  always_ff @(posedge clk) begin
    if (rst) begin
      state_q <= 1'b0;
      op_q    <= 2'd0;
      done_q  <= 1'b0;
      err_q   <= 1'b0;
    end else begin
      done_q <= 1'b0;
      err_q  <= 1'b0;
      if (accept) begin
        if (ctrl_op == 2'd3) begin
          done_q <= 1'b1;
          err_q  <= 1'b1;
        end else begin
          state_q <= 1'b1;
          op_q    <= ctrl_op;
        end
      end else if (act_done) begin
        state_q <= 1'b0;
        done_q  <= 1'b1;
        err_q   <= wr_err_pending;
      end
    end
  end
endmodule
