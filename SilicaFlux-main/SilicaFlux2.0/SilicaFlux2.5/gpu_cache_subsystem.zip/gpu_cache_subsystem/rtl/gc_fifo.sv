// -----------------------------------------------------------------------------
// gc_fifo - synchronous FIFO, combinational head read (first-word fall-through)
//   * push is ignored when full, pop is ignored when empty (callers must check;
//     simulation assertions flag violations).
//   * synchronous active-high reset clears pointers/count (data not reset).
// -----------------------------------------------------------------------------
module gc_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 2,
  parameter int CNT_W = $clog2(DEPTH + 1)
) (
  input  logic             clk,
  input  logic             rst,
  input  logic             push,
  input  logic [W-1:0]     wdata,
  input  logic             pop,
  output logic [W-1:0]     rdata,
  output logic             empty,
  output logic             full,
  output logic [CNT_W-1:0] count
);
  localparam int PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;

  logic [W-1:0]     mem [0:DEPTH-1];
  logic [PW-1:0]    rptr, wptr;
  logic [CNT_W-1:0] cnt;
  logic             do_push, do_pop;

  assign empty   = (cnt == '0);
  assign full    = (cnt == CNT_W'(DEPTH));
  assign count   = cnt;
  assign rdata   = mem[rptr];
  assign do_push = push && !full;
  assign do_pop  = pop && !empty;

  always_ff @(posedge clk) begin
    if (do_push) mem[wptr] <= wdata;
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      rptr <= '0;
      wptr <= '0;
      cnt  <= '0;
    end else begin
      if (do_push) wptr <= (wptr == PW'(DEPTH - 1)) ? '0 : wptr + 1'b1;
      if (do_pop)  rptr <= (rptr == PW'(DEPTH - 1)) ? '0 : rptr + 1'b1;
      if (do_push && !do_pop)      cnt <= cnt + 1'b1;
      else if (do_pop && !do_push) cnt <= cnt - 1'b1;
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (!rst) begin
      if (push && full)  $error("%m: push while full");
      if (pop  && empty) $error("%m: pop while empty");
    end
  end
`endif
endmodule
