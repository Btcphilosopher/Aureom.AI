// -----------------------------------------------------------------------------
// gc_rr_arb - round-robin arbiter.
//   The requester after the last *advanced* grant has highest priority.
//   `advance` must be asserted in the cycle the grant is actually used.
// -----------------------------------------------------------------------------
module gc_rr_arb #(
  parameter int N  = 4,
  parameter int IW = (N > 1) ? $clog2(N) : 1
) (
  input  logic          clk,
  input  logic          rst,
  input  logic [N-1:0]  req,
  input  logic          advance,
  output logic          any,
  output logic [IW-1:0] gnt_idx
);
  logic [IW-1:0] ptr;
  logic          found;
  int            idx;

  always_comb begin
    found   = 1'b0;
    gnt_idx = '0;
    for (int i = 0; i < N; i++) begin
      idx = i + 32'(ptr);
      if (idx >= N) idx = idx - N;
      if (!found && req[idx]) begin
        found   = 1'b1;
        gnt_idx = IW'(idx);
      end
    end
    any = found;
  end

  always_ff @(posedge clk) begin
    if (rst) ptr <= '0;
    else if (advance && any) ptr <= (gnt_idx == IW'(N - 1)) ? '0 : gnt_idx + 1'b1;
  end
endmodule
