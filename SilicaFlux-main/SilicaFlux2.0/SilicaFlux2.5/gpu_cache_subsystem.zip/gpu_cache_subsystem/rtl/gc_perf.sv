// -----------------------------------------------------------------------------
// gc_perf - bank of 32-bit wrapping event counters.
//   inc is a flattened vector of N_EV increments, INC_W bits each.
// -----------------------------------------------------------------------------
module gc_perf #(
  parameter int N_EV  = 26,
  parameter int INC_W = 12
) (
  input  logic                clk,
  input  logic                rst,
  input  logic [N_EV*INC_W-1:0] inc,
  output logic [N_EV*32-1:0]  count
);
  logic [31:0] cnt [0:N_EV-1];

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int e = 0; e < N_EV; e++) cnt[e] <= '0;
    end else begin
      for (int e = 0; e < N_EV; e++) cnt[e] <= cnt[e] + 32'(inc[e*INC_W +: INC_W]);
    end
  end

  always_comb begin
    for (int e = 0; e < N_EV; e++) count[e*32 +: 32] = cnt[e];
  end
endmodule
