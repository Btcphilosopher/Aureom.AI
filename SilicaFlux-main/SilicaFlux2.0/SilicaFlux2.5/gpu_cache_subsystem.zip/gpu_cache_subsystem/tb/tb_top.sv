// -----------------------------------------------------------------------------
// tb_top - self-checking testbench for gc_uncached (DUT_KIND=0) and gc_cache
//          (DUT_KIND=1).  Simulation only (Verilator 5, --binary --timing).
//
// Checking strategy ("commit-order oracle"):
//   * every request handshake is recorded per (port, tag)
//   * the DUT's dbg_commit stream gives the serialization order; at commit
//     the scoreboard applies stores to a reference memory and computes the
//     expected load value / error from it
//   * every response must match the expectation for its (port, tag): this
//     checks data, error, response routing and exactly-once delivery
//   * per port, commits must occur in acceptance order (program order)
//   * at every control-op completion: every request accepted before the op
//     has committed, the memory model has nothing in flight, and memory
//     content == reference content (fence/flush semantics)
//   * global deadlock watchdog
//
// Run modes (+test=<name>): all | basic | simul | sameline | mshrfull |
//   evict_stall | flush_pending | fence | errors | reset | prefetch |
//   random | trace
// -----------------------------------------------------------------------------
module tb_top;
  import tb_pkg::*;

  // ---- DUT configuration (override with -G) ----
  parameter int DUT_KIND   = 1;
  parameter int NUM_PORTS  = 4;
  parameter int LINE_BYTES = 64;
  parameter int NUM_SETS   = 64;
  parameter int NUM_WAYS   = 4;
  parameter int REPL       = 0;
  parameter int N_MSHR     = 16;
  parameter int N_TGT      = 8;
  parameter int IN_DEPTH   = 2;
  parameter int RSP_DEPTH  = 16;
  parameter int MEMQ_DEPTH = 4;
  parameter int PF_ENABLE  = 1;
  parameter int PF_ENTRIES = 16;
  parameter int PF_CONF_TH = 2;
  parameter int PF_MSHR_RSV = 2;
  parameter int PF_QDEPTH  = 2;
  parameter int N_OT       = 16;

  localparam int ADDR_W  = 32;
  localparam int TAG_W   = 8;
  localparam int PC_W    = 8;
  localparam int ID_W    = 8;
  localparam int LB      = LINE_BYTES * 8;
  localparam int PORT_W  = (NUM_PORTS > 1) ? $clog2(NUM_PORTS) : 1;
  localparam int DID_W   = (DUT_KIND != 0) ? ((N_MSHR > 1) ? $clog2(N_MSHR) : 1)
                                           : ((N_OT > 1) ? $clog2(N_OT) : 1);
  localparam int LSH     = $clog2(LINE_BYTES);
  localparam int SET_W   = $clog2(NUM_SETS);
  localparam int N_EV    = gc_pkg::N_EV;
  localparam int LAT_BINS = 8192;
  localparam bit IS_CACHE = (DUT_KIND != 0);
  localparam bit HAS_PF   = (DUT_KIND != 0) && (PF_ENABLE != 0);
  // (simulator workaround) Verilator 5.020 mis-handles arrays of queues whose size is not a power of
  // two (>= 2); all per-port TB arrays are therefore padded to NPA entries.
  localparam int NPA      = (NUM_PORTS <= 2) ? 2 : (1 << $clog2(NUM_PORTS));

  // ---------------------------------------------------------------------------
  // clock / reset
  // ---------------------------------------------------------------------------
  logic   clk = 1'b0;
  logic   rst = 1'b1;
  longint cycle = 0;
  always #5 clk = ~clk;
  always @(posedge clk) cycle <= cycle + 1;

  // ---------------------------------------------------------------------------
  // DUT interface
  // ---------------------------------------------------------------------------
  logic [NUM_PORTS-1:0]        req_valid = '0, req_ready;
  logic [NUM_PORTS*2-1:0]      req_op = '0;
  logic [NUM_PORTS*ADDR_W-1:0] req_addr = '0;
  logic [NUM_PORTS*32-1:0]     req_wdata = '0;
  logic [NUM_PORTS*4-1:0]      req_wstrb = '0;
  logic [NUM_PORTS*TAG_W-1:0]  req_tag = '0;
  logic [NUM_PORTS*PC_W-1:0]   req_pc = '0;
  logic [NUM_PORTS-1:0]        rsp_valid, rsp_ready = '1, rsp_err, rsp_is_store;
  logic [NUM_PORTS*TAG_W-1:0]  rsp_tag;
  logic [NUM_PORTS*32-1:0]     rsp_rdata;
  logic                        ctrl_valid = 1'b0, ctrl_ready, ctrl_done, ctrl_err;
  logic [1:0]                  ctrl_op = 2'd0;
  logic                        pf_enable = 1'b0;
  logic [3:0]                  pf_dist = 4'd4;
  logic                        mem_req_valid, mem_req_ready, mem_req_we, mem_req_pf;
  logic [ADDR_W-1:0]           mem_req_addr;
  logic [LB-1:0]               mem_req_wdata;
  logic [LINE_BYTES-1:0]       mem_req_be;
  logic [ID_W-1:0]             mem_req_id;
  logic                        mem_rsp_valid, mem_rsp_ready, mem_rsp_we, mem_rsp_err;
  logic [ID_W-1:0]             mem_rsp_id;
  logic [LB-1:0]               mem_rsp_rdata;
  logic [gc_pkg::N_ERR-1:0]    err_status;
  logic [N_EV*32-1:0]          perf_count;
  logic                        busy;
  logic                        dbg_commit_valid, dbg_commit_err;
  logic [PORT_W-1:0]           dbg_commit_port;
  logic [TAG_W-1:0]            dbg_commit_tag;
  logic [1:0]                  dbg_commit_op;
  logic [ADDR_W-1:0]           dbg_commit_addr;
  logic [31:0]                 dbg_commit_wdata;
  logic [3:0]                  dbg_commit_wstrb;

  assign mem_req_id[ID_W-1:DID_W] = '0;

  if (DUT_KIND == 0) begin : g_dut
    gc_uncached #(
      .NUM_PORTS(NUM_PORTS), .ADDR_W(ADDR_W), .LINE_BYTES(LINE_BYTES), .N_OT(N_OT),
      .IN_DEPTH(IN_DEPTH), .RSP_DEPTH(RSP_DEPTH), .MEMQ_DEPTH(MEMQ_DEPTH),
      .TAG_W(TAG_W), .PC_W(PC_W)
    ) u_dut (
      .clk, .rst,
      .req_valid, .req_ready, .req_op, .req_addr, .req_wdata, .req_wstrb, .req_tag, .req_pc,
      .rsp_valid, .rsp_ready, .rsp_tag, .rsp_rdata, .rsp_err, .rsp_is_store,
      .ctrl_valid, .ctrl_ready, .ctrl_op, .ctrl_done, .ctrl_err, .pf_enable, .pf_dist,
      .mem_req_valid, .mem_req_ready, .mem_req_we, .mem_req_addr, .mem_req_wdata,
      .mem_req_be, .mem_req_id(mem_req_id[DID_W-1:0]), .mem_req_pf,
      .mem_rsp_valid, .mem_rsp_ready, .mem_rsp_we, .mem_rsp_id(mem_rsp_id[DID_W-1:0]),
      .mem_rsp_rdata, .mem_rsp_err,
      .err_status, .perf_count, .busy,
      .dbg_commit_valid, .dbg_commit_port, .dbg_commit_tag, .dbg_commit_op,
      .dbg_commit_addr, .dbg_commit_wdata, .dbg_commit_wstrb, .dbg_commit_err
    );
  end else begin : g_dut
    gc_cache #(
      .NUM_PORTS(NUM_PORTS), .ADDR_W(ADDR_W), .LINE_BYTES(LINE_BYTES),
      .NUM_SETS(NUM_SETS), .NUM_WAYS(NUM_WAYS), .REPL(REPL),
      .N_MSHR(N_MSHR), .N_TGT(N_TGT), .IN_DEPTH(IN_DEPTH), .RSP_DEPTH(RSP_DEPTH),
      .MEMQ_DEPTH(MEMQ_DEPTH), .TAG_W(TAG_W), .PC_W(PC_W),
      .PF_ENABLE(PF_ENABLE), .PF_ENTRIES(PF_ENTRIES), .PF_CONF_TH(PF_CONF_TH),
      .PF_MSHR_RSV(PF_MSHR_RSV), .PF_QDEPTH(PF_QDEPTH)
    ) u_dut (
      .clk, .rst,
      .req_valid, .req_ready, .req_op, .req_addr, .req_wdata, .req_wstrb, .req_tag, .req_pc,
      .rsp_valid, .rsp_ready, .rsp_tag, .rsp_rdata, .rsp_err, .rsp_is_store,
      .ctrl_valid, .ctrl_ready, .ctrl_op, .ctrl_done, .ctrl_err, .pf_enable, .pf_dist,
      .mem_req_valid, .mem_req_ready, .mem_req_we, .mem_req_addr, .mem_req_wdata,
      .mem_req_be, .mem_req_id(mem_req_id[DID_W-1:0]), .mem_req_pf,
      .mem_rsp_valid, .mem_rsp_ready, .mem_rsp_we, .mem_rsp_id(mem_rsp_id[DID_W-1:0]),
      .mem_rsp_rdata, .mem_rsp_err,
      .err_status, .perf_count, .busy,
      .dbg_commit_valid, .dbg_commit_port, .dbg_commit_tag, .dbg_commit_op,
      .dbg_commit_addr, .dbg_commit_wdata, .dbg_commit_wstrb, .dbg_commit_err
    );
  end

  tb_mem #(.LINE_BYTES(LINE_BYTES), .ID_W(ID_W), .ADDR_W(ADDR_W)) u_mem (
    .clk, .rst,
    .req_valid(mem_req_valid), .req_ready(mem_req_ready), .req_we(mem_req_we),
    .req_addr(mem_req_addr), .req_wdata(mem_req_wdata), .req_be(mem_req_be),
    .req_id(mem_req_id), .req_pf(mem_req_pf),
    .rsp_valid(mem_rsp_valid), .rsp_ready(mem_rsp_ready), .rsp_we(mem_rsp_we),
    .rsp_id(mem_rsp_id), .rsp_rdata(mem_rsp_rdata), .rsp_err(mem_rsp_err)
  );

  // ---------------------------------------------------------------------------
  // event names (JSON / reports)
  // ---------------------------------------------------------------------------
  string ev_name [N_EV] = '{
    "ld", "ld_hit", "ld_miss", "ld_merge", "st", "st_hit",
    "rpl_mshr", "rpl_sthaz", "rpl_res", "mem_rd_dem", "mem_rd_pf", "mem_wr",
    "fill", "evict", "pf_cand", "pf_filt", "pf_drop", "pf_useful", "pf_late",
    "pf_useless", "pollution", "err_rsp", "mem_err", "spurious", "ctrl", "fill_err"
  };

  function automatic longint perf(input int ev);
    return longint'(perf_count[ev*32 +: 32]);
  endfunction

  longint snap [N_EV];
  task automatic snap_take();
    for (int e = 0; e < N_EV; e++) snap[e] = perf(e);
  endtask
  function automatic longint dlt(input int ev);
    return perf(ev) - snap[ev];
  endfunction

  // ---------------------------------------------------------------------------
  // error reporting
  // ---------------------------------------------------------------------------
  int n_errors = 0;
  function automatic void fail(input string msg);
    n_errors++;
    if (n_errors <= 25) $display("[%0d] ERROR: %s", cycle, msg);
  endfunction
  function automatic void expect_true(input bit c, input string msg);
    if (!c) fail(msg);
  endfunction

  // ---------------------------------------------------------------------------
  // stimulus queues and driver state
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [1:0]  op;
    logic [31:0] addr;
    logic [31:0] wdata;
    logic [3:0]  wstrb;
    logic [7:0]  pc;
    int          gap;
  } req_t;

  typedef struct packed {
    req_t        r;
    longint      t_pres;
    longint      t_acc;
    longint      seq;
    logic        committed;
    logic        pre_ctrl;
    logic        exp_err;
    logic [31:0] exp_data;
  } infl_t;

  req_t   pq       [NPA][$];
  req_t   p_cur    [NPA];
  int     p_out    [NPA];
  int     p_wait   [NPA];
  bit     p_gapld  [NPA];
  logic [7:0] p_ntag [NPA];
  longint p_acc_seq [NPA];
  longint p_cmt_seq [NPA];
  longint p_last_rsp [NPA];
  longint p_first_acc [NPA];
  longint p_pres_t [NPA];          // cycle the current request was first presented
  longint p_bp_cycles [NPA];       // cycles with req_valid && !req_ready
  int     rsp_mode [NPA];      // 0 always ready, 1 random, 2 forced low
  int     rsp_ready_pct = 100;
  int     mlp = 8;
  bit     drv_enable = 1'b1;

  infl_t  infl   [NPA][256];
  bit     infl_v [NPA][256];

  // reference memory
  logic [31:0] ref_mem [logic [31:0]];
  function automatic logic [31:0] ref_read(input logic [31:0] a);
    logic [31:0] k;
    k = {a[31:2], 2'b00};
    if (ref_mem.exists(k)) return ref_mem[k];
    return init_word(k);
  endfunction
  function automatic void ref_write(input logic [31:0] a, input logic [31:0] d, input logic [3:0] s);
    logic [31:0] k, v;
    k = {a[31:2], 2'b00};
    v = ref_read(k);
    for (int b = 0; b < 4; b++) if (s[b]) v[b*8 +: 8] = d[b*8 +: 8];
    ref_mem[k] = v;
  endfunction

  // statistics
  longint lat_hist [LAT_BINS];
  longint lat_sum, lat_n, lat_max;
  longint e2e_hist [LAT_BINS];       // first presentation -> response (incl. back-pressure)
  longint e2e_sum;
  longint n_acc, n_cmt, n_rsp, n_ld_ok, n_st_ok, n_err_rsp;
  longint last_progress;
  longint tot_acc = 0, tot_cmt = 0, tot_rsp = 0;

  // control-op tracking
  bit     ctrl_pending;
  logic [1:0] ctrl_pend_op;
  bit     ctrl_busy_at_accept;
  int     ctrl_pre_outstanding;
  int     n_ctrl_done;
  bit     last_ctrl_err;
  bit     mem_quiet_check = 1'b1;

  function automatic void clear_stats();
    for (int i = 0; i < LAT_BINS; i++) begin
      lat_hist[i] = 0;
      e2e_hist[i] = 0;
    end
    lat_sum = 0; lat_n = 0; lat_max = 0; e2e_sum = 0;
    n_acc = 0; n_cmt = 0; n_rsp = 0; n_ld_ok = 0; n_st_ok = 0; n_err_rsp = 0;
    for (int p = 0; p < NPA; p++) begin
      p_last_rsp[p]  = 0;
      p_first_acc[p] = -1;
      p_bp_cycles[p] = 0;
    end
  endfunction

  function automatic int total_outstanding();
    int t;
    t = 0;
    for (int p = 0; p < NUM_PORTS; p++) t += p_out[p] + pq[p].size() + int'(req_valid[p]);
    return t;
  endfunction

  // memory == reference (called at every control completion)
  function automatic void check_mem_matches_ref(input string where);
    int bad;
    bad = 0;
    foreach (ref_mem[k]) begin
      if (mem_read(k) !== ref_mem[k]) begin
        bad++;
        if (bad <= 3) fail($sformatf("%s: mem[%h]=%h ref=%h", where, k, mem_read(k), ref_mem[k]));
      end
    end
    foreach (mem_store[k]) begin
      if (mem_store[k] !== ref_read(k)) begin
        bad++;
        if (bad <= 3) fail($sformatf("%s: stray mem[%h]=%h ref=%h", where, k, mem_store[k], ref_read(k)));
      end
    end
  endfunction

  // ---------------------------------------------------------------------------
  // the monitor / driver (all bookkeeping happens here, at posedge)
  // ---------------------------------------------------------------------------
  always @(posedge clk) begin
    if (rst) begin
      req_valid <= '0;
      for (int p = 0; p < NUM_PORTS; p++) begin
        p_out[p] = 0;
        p_gapld[p] = 1'b0;
        p_acc_seq[p] = 0;
        p_cmt_seq[p] = 0;
        for (int t = 0; t < 256; t++) infl_v[p][t] = 1'b0;
      end
      ctrl_pending = 1'b0;
      // memory side is reset together with the DUT; the backing store survives,
      // so the reference re-synchronises to what memory actually holds
      ref_mem = mem_store;
      last_progress = cycle;
    end else begin
      // ---- (a) control completion ------------------------------------------
      if (ctrl_done) begin
        n_ctrl_done++;
        last_ctrl_err = ctrl_err;
        last_progress = cycle;
        if (ctrl_pending) begin
          for (int p = 0; p < NUM_PORTS; p++)
            for (int t = 0; t < 256; t++)
              if (infl_v[p][t] && infl[p][t].pre_ctrl && !infl[p][t].committed)
                fail($sformatf("ctrl done but p%0d tag %0d (accepted before) not performed", p, t));
          if (mem_quiet_check) begin
            expect_true(mem_pend_cnt == 0 && !mem_rsp_valid,
                        $sformatf("ctrl done with %0d memory transactions in flight", mem_pend_cnt));
            check_mem_matches_ref("ctrl-done");
          end
          expect_true(!busy, "ctrl done while DUT busy");
          ctrl_pending = 1'b0;
        end
      end
      // ---- (b) request handshakes ------------------------------------------
      for (int p = 0; p < NUM_PORTS; p++) begin
        if (req_valid[p] && req_ready[p]) begin
          logic [7:0] tg;
          tg = req_tag[p*TAG_W +: TAG_W];
          if (ctrl_pending) fail($sformatf("p%0d request accepted while control op draining", p));
          if (infl_v[p][tg]) fail($sformatf("p%0d tag %0d reused while in flight", p, tg));
          infl_v[p][tg]           = 1'b1;
          infl[p][tg].r           = p_cur[p];
          infl[p][tg].t_pres      = p_pres_t[p];
          infl[p][tg].t_acc       = cycle;
          infl[p][tg].seq         = p_acc_seq[p]++;
          infl[p][tg].committed   = 1'b0;
          infl[p][tg].pre_ctrl    = 1'b0;
          infl[p][tg].exp_err     = 1'b0;
          infl[p][tg].exp_data    = '0;
          p_out[p]++;
          n_acc++;
          tot_acc++;
          if (p_first_acc[p] < 0) p_first_acc[p] = cycle;
          last_progress = cycle;
        end
      end
      // ---- (c) control acceptance --------------------------------------------
      if (ctrl_valid && ctrl_ready && ctrl_op != 2'd3) begin
        ctrl_pending = 1'b1;
        ctrl_pend_op = ctrl_op;
        ctrl_busy_at_accept = busy || (mem_pend_cnt != 0);
        ctrl_pre_outstanding = 0;
        for (int p = 0; p < NUM_PORTS; p++)
          for (int t = 0; t < 256; t++)
            if (infl_v[p][t]) begin
              infl[p][t].pre_ctrl = 1'b1;
              if (!infl[p][t].committed) ctrl_pre_outstanding++;
            end
      end
      // ---- (d) commit stream -------------------------------------------------
      if (dbg_commit_valid) begin
        int p;
        logic [7:0] tg;
        p  = int'(dbg_commit_port);
        tg = dbg_commit_tag;
        last_progress = cycle;
        n_cmt++;
        tot_cmt++;
        if (!infl_v[p][tg]) begin
          fail($sformatf("commit of unknown request p%0d tag %0d", p, tg));
        end else if (infl[p][tg].committed) begin
          fail($sformatf("double commit p%0d tag %0d", p, tg));
        end else begin
          req_t r;
          bit   bad;
          r   = infl[p][tg].r;
          bad = r.op[1] || (r.addr[1:0] != 2'b00);
          if (infl[p][tg].seq != p_cmt_seq[p])
            fail($sformatf("p%0d commit out of program order (seq %0d expected %0d)",
                           p, infl[p][tg].seq, p_cmt_seq[p]));
          p_cmt_seq[p] = infl[p][tg].seq + 1;
          if (dbg_commit_op != r.op || dbg_commit_addr != r.addr ||
              (r.op == gc_pkg::OP_STORE && (dbg_commit_wdata != r.wdata || dbg_commit_wstrb != r.wstrb)))
            fail($sformatf("p%0d tag %0d commit fields differ from request", p, tg));
          if (dbg_commit_err != bad)
            fail($sformatf("p%0d tag %0d commit error flag %0d expected %0d", p, tg, dbg_commit_err, bad));
          infl[p][tg].committed = 1'b1;
          if (bad) begin
            infl[p][tg].exp_err = 1'b1;
          end else if (r.op == gc_pkg::OP_LOAD) begin
            infl[p][tg].exp_err  = in_err(r.addr);
            infl[p][tg].exp_data = in_err(r.addr) ? 32'h0 : ref_read(r.addr);
          end else begin
            infl[p][tg].exp_err = 1'b0;
            if (!in_err(r.addr)) ref_write(r.addr, r.wdata, r.wstrb);
          end
        end
      end
      // ---- (e) responses -----------------------------------------------------
      for (int p = 0; p < NUM_PORTS; p++) begin
        if (rsp_valid[p] && rsp_ready[p]) begin
          logic [7:0] tg;
          tg = rsp_tag[p*TAG_W +: TAG_W];
          last_progress = cycle;
          n_rsp++;
          tot_rsp++;
          if (!infl_v[p][tg]) begin
            fail($sformatf("response on p%0d for unknown tag %0d (misrouted/duplicate)", p, tg));
          end else if (!infl[p][tg].committed) begin
            fail($sformatf("response on p%0d tag %0d before commit", p, tg));
          end else begin
            req_t r;
            r = infl[p][tg].r;
            if (rsp_is_store[p] != (r.op == gc_pkg::OP_STORE))
              fail($sformatf("p%0d tag %0d response type mismatch", p, tg));
            if (rsp_err[p] != infl[p][tg].exp_err)
              fail($sformatf("p%0d tag %0d err=%0d expected %0d (addr %h op %0d)",
                             p, tg, rsp_err[p], infl[p][tg].exp_err, r.addr, r.op));
            else if (!rsp_err[p] && r.op == gc_pkg::OP_LOAD &&
                     rsp_rdata[p*32 +: 32] != infl[p][tg].exp_data)
              fail($sformatf("p%0d tag %0d load %h data %h expected %h",
                             p, tg, r.addr, rsp_rdata[p*32 +: 32], infl[p][tg].exp_data));
            if (rsp_err[p]) n_err_rsp++;
            else if (r.op == gc_pkg::OP_LOAD) begin
              longint l;
              l = cycle - infl[p][tg].t_acc;
              n_ld_ok++;
              lat_sum += l; lat_n++;
              if (l > lat_max) lat_max = l;
              lat_hist[(l < LAT_BINS) ? int'(l) : LAT_BINS - 1]++;
              l = cycle - infl[p][tg].t_pres;
              e2e_sum += l;
              e2e_hist[(l < LAT_BINS) ? int'(l) : LAT_BINS - 1]++;
            end else n_st_ok++;
            infl_v[p][tg] = 1'b0;
            p_out[p]--;
            p_last_rsp[p] = cycle;
          end
        end
      end
      // ---- (f) drive requests --------------------------------------------------
      for (int p = 0; p < NUM_PORTS; p++) begin
        bit holding;
        holding = req_valid[p] && !req_ready[p];
        if (holding) p_bp_cycles[p]++;
        if (!holding) begin
          if (!drv_enable || pq[p].size() == 0) begin
            req_valid[p] <= 1'b0;
          end else begin
            if (!p_gapld[p]) begin
              p_wait[p]  = pq[p][0].gap;
              p_gapld[p] = 1'b1;
            end
            if (p_wait[p] > 0) begin
              p_wait[p]--;
              req_valid[p] <= 1'b0;
            end else if (p_out[p] < mlp && !infl_v[p][p_ntag[p]]) begin
              p_cur[p]   = pq[p].pop_front();
              p_gapld[p] = 1'b0;
              p_pres_t[p] = cycle + 1;   // visible to the DUT from the next cycle
              req_valid[p]                  <= 1'b1;
              req_op[p*2 +: 2]              <= p_cur[p].op;
              req_addr[p*ADDR_W +: ADDR_W]  <= p_cur[p].addr;
              req_wdata[p*32 +: 32]         <= p_cur[p].wdata;
              req_wstrb[p*4 +: 4]           <= p_cur[p].wstrb;
              req_pc[p*PC_W +: PC_W]        <= p_cur[p].pc;
              req_tag[p*TAG_W +: TAG_W]     <= p_ntag[p];
              p_ntag[p] = p_ntag[p] + 1;
            end else begin
              req_valid[p] <= 1'b0;
            end
          end
        end
      end
      // ---- (g) response back-pressure ------------------------------------------
      for (int p = 0; p < NUM_PORTS; p++) begin
        case (rsp_mode[p])
          1:       rsp_ready[p] <= (($urandom % 100) < rsp_ready_pct);
          2:       rsp_ready[p] <= 1'b0;
          default: rsp_ready[p] <= 1'b1;
        endcase
      end
      // ---- (h) watchdog ------------------------------------------------------------
      if ((total_outstanding() > 0 || ctrl_pending) && (cycle - last_progress > 20000)) begin
        fail("DEADLOCK: no progress for 20000 cycles");
        finish_sim();
      end
    end
  end

  // ---------------------------------------------------------------------------
  // test-thread helpers (all operate at the negative edge)
  // ---------------------------------------------------------------------------
  task automatic tick(input int n = 1);
    repeat (n) @(negedge clk);
  endtask

  function automatic logic [31:0] la(input int set, input int tg, input int word = 0);
    return 32'h0010_0000 + (32'(tg) << (LSH + SET_W)) + (32'(set) << LSH) + (32'(word) << 2);
  endfunction

  function automatic void push(input int p, input logic [1:0] op, input logic [31:0] addr,
                               input logic [31:0] wdata = 32'h0, input logic [3:0] wstrb = 4'hF,
                               input int gap = 0, input logic [7:0] pc = 8'h0);
    req_t r;
    r.op = op; r.addr = addr; r.wdata = wdata; r.wstrb = wstrb; r.pc = pc; r.gap = gap;
    pq[p].push_back(r);
  endfunction

  function automatic void ld(input int p, input logic [31:0] a, input int gap = 0, input logic [7:0] pc = 8'h0);
    push(p, gc_pkg::OP_LOAD, a, 32'h0, 4'hF, gap, pc);
  endfunction
  function automatic void st(input int p, input logic [31:0] a, input logic [31:0] d,
                             input logic [3:0] s = 4'hF, input int gap = 0);
    push(p, gc_pkg::OP_STORE, a, d, s, gap, 8'h0);
  endfunction

  task automatic wait_idle(input int timeout = 200000);
    int n, t;
    bit b;
    n = 0;
    forever begin
      t = total_outstanding();
      b = busy || ctrl_pending || ctrl_valid;
      if (t == 0 && !b) break;
      if (n >= timeout) break;
      tick();
      n++;
    end
    if (n >= timeout) fail("wait_idle timeout");
    tick(2);
  endtask

  task automatic do_ctrl(input logic [1:0] op, output bit err);
    @(negedge clk);
    ctrl_valid = 1'b1;
    ctrl_op    = op;
    while (!ctrl_ready) @(negedge clk);
    @(negedge clk);
    ctrl_valid = 1'b0;
    while (!ctrl_done) @(negedge clk);
    err = ctrl_err;
  endtask

  task automatic reset_dut(input int n = 4);
    @(negedge clk);
    rst = 1'b1;
    for (int p = 0; p < NUM_PORTS; p++) begin
      pq[p].delete();
      rsp_mode[p] = 0;
    end
    ctrl_valid = 1'b0;
    tick(n);
    rst = 1'b0;
    tick(2);
  endtask

  // run one named test and report
  int  test_fail_cnt = 0;
  int  test_pass_cnt = 0;
  task automatic report(input string name, input int err_before);
    if (n_errors == err_before) begin
      $display("TEST %-14s PASS", name);
      test_pass_cnt++;
    end else begin
      $display("TEST %-14s FAIL (%0d errors)", name, n_errors - err_before);
      test_fail_cnt++;
    end
  endtask

  // ---------------------------------------------------------------------------
  // directed tests
  // ---------------------------------------------------------------------------
  task automatic t_basic();
    logic [31:0] A, B;
    A = la(3, 1);
    B = la(5, 2);
    snap_take();
    ld(0, A);           wait_idle();
    ld(0, A + 4);       wait_idle();
    st(0, A, 32'hDEAD_BEEF);
    ld(0, A);
    st(0, A + 8, 32'h1234_5678, 4'b0101);
    ld(0, A + 8);
    st(0, B, 32'hCAFE_BABE);
    ld(0, B);
    wait_idle();
    if (IS_CACHE) begin
      expect_true(dlt(gc_pkg::EV_LD_MISS) == 2, $sformatf("basic: misses %0d != 2", dlt(gc_pkg::EV_LD_MISS)));
      expect_true(dlt(gc_pkg::EV_LD_HIT) == 3,  $sformatf("basic: hits %0d != 3", dlt(gc_pkg::EV_LD_HIT)));
      expect_true(dlt(gc_pkg::EV_ST_HIT) == 2,  $sformatf("basic: store hits %0d != 2", dlt(gc_pkg::EV_ST_HIT)));
    end
    expect_true(dlt(gc_pkg::EV_ST) == 3, "basic: store count");
    expect_true(dlt(gc_pkg::EV_MEM_WR) == 3, "basic: write-through count");
  endtask

  task automatic t_simul();
    int npar;
    // (1) distinct lines, distinct sets, same cycle on every port
    mem_stats_clear();
    snap_take();
    for (int p = 0; p < NUM_PORTS; p++) ld(p, la(p + 1, 7, p));
    wait_idle();
    npar = IS_CACHE ? N_MSHR : N_OT;
    if (npar > NUM_PORTS) npar = NUM_PORTS;
    expect_true(mem_n_rd_dem == NUM_PORTS, $sformatf("simul: %0d reads != %0d", mem_n_rd_dem, NUM_PORTS));
    expect_true(mem_max_rd_out >= npar,
                $sformatf("simul: only %0d misses overlapped (expected %0d)", mem_max_rd_out, npar));
    if (IS_CACHE) expect_true(dlt(gc_pkg::EV_LD_MISS) == NUM_PORTS, "simul: miss count");
    // (2) distinct lines all in ONE set, 2 per port (more lines than ways)
    snap_take();
    for (int p = 0; p < NUM_PORTS; p++) begin
      ld(p, la(9, 10 + 2 * p));
      ld(p, la(9, 11 + 2 * p));
    end
    wait_idle();
    // (3) re-read them all: correctness after evictions
    for (int p = 0; p < NUM_PORTS; p++) begin
      ld(p, la(9, 11 + 2 * p, 3));
      ld(p, la(9, 10 + 2 * p, 5));
    end
    wait_idle();
    if (IS_CACHE && 2 * NUM_PORTS > NUM_WAYS)
      expect_true(dlt(gc_pkg::EV_EVICT) > 0, "simul: expected evictions in the shared set");
  endtask

  task automatic t_sameline();
    logic [31:0] L, L2;
    int words;
    words = LINE_BYTES / 4;
    L  = la(6, 33);
    L2 = la(7, 34);
    mem_stats_clear();
    snap_take();
    // wave 1: every port, same line, different words, same cycle; then 3 more each
    for (int p = 0; p < NUM_PORTS; p++)
      for (int k = 0; k < 4; k++) ld(p, L + 32'(((p * 4 + k) % words) * 4));
    wait_idle();
    if (IS_CACHE) begin
      expect_true(mem_n_rd_dem == 1, $sformatf("sameline: %0d memory reads for one line", mem_n_rd_dem));
      expect_true(dlt(gc_pkg::EV_LD_MISS) == 1, "sameline: exactly one primary miss");
      begin
        int conc;   // loads that can be outstanding on the line at once
        conc = NUM_PORTS * ((RSP_DEPTH < 4) ? RSP_DEPTH : 4);
        expect_true(dlt(gc_pkg::EV_LD_MERGE) >= longint'(((N_TGT < conc) ? N_TGT : conc) - 1),
                    $sformatf("sameline: merges %0d", dlt(gc_pkg::EV_LD_MERGE)));
        if (conc > N_TGT)
          expect_true(dlt(gc_pkg::EV_RPL_MSHR) > 0, "sameline: expected target-full replays");
      end
    end else begin
      expect_true(mem_n_rd_dem == 4 * NUM_PORTS, "sameline: uncached must read every word");
    end
    // store to a line whose fill is pending must not be lost or overtaken
    snap_take();
    ld(0, L2);
    if (NUM_PORTS > 1) begin
      st(1, L2 + 4, 32'hA5A5_0001, 4'hF, 3);
      ld(1, L2 + 4);
      st(1, L2, 32'hA5A5_0002, 4'b0011);
      ld(1, L2);
    end else begin
      st(0, L2 + 4, 32'hA5A5_0001, 4'hF, 3);
      ld(0, L2 + 4);
    end
    ld(0, L2 + 4, 2);
    wait_idle();
    if (IS_CACHE) expect_true(dlt(gc_pkg::EV_RPL_STHAZ) > 0, "sameline: store hazard replay not exercised");
  endtask

  task automatic t_mshrfull();
    int save_mlp;
    save_mlp = mlp;
    mlp = 16;
    mem_stats_clear();
    snap_take();
    for (int p = 0; p < NUM_PORTS; p++)
      for (int k = 0; k < 8; k++) ld(p, la((p * 8 + k) % NUM_SETS, 40 + p * 8 + k));
    wait_idle();
    if (IS_CACHE) begin
      int conc;
      conc = NUM_PORTS * ((RSP_DEPTH < 8) ? RSP_DEPTH : 8);
      if (conc > N_MSHR)
        expect_true(dlt(gc_pkg::EV_RPL_MSHR) > 0, "mshrfull: no MSHR-full replays");
      expect_true(mem_max_rd_out == ((conc < N_MSHR) ? conc : N_MSHR),
                  $sformatf("mshrfull: peak outstanding %0d (N_MSHR %0d)", mem_max_rd_out, N_MSHR));
    end else begin
      expect_true(mem_max_rd_out <= N_OT, "mshrfull: uncached exceeded N_OT");
    end
    mlp = save_mlp;
  endtask

  task automatic t_evict_stall();
    int S, save_mlp;
    S = 12 % NUM_SETS;
    save_mlp = mlp;
    mlp = 32;
    // warm the set with NUM_WAYS lines
    for (int w = 0; w < NUM_WAYS; w++) ld(0, la(S, 20 + w));
    wait_idle();
    snap_take();
    rsp_mode[0] = 2;  // port 0 stops accepting responses
    for (int k = 0; k < 3 * RSP_DEPTH; k++) ld(0, la(S, 20 + (k % NUM_WAYS), k % (LINE_BYTES / 4)));
    ld(0, la(S, 30));                       // a miss whose drain is blocked
    for (int p = 1; p < NUM_PORTS; p++) begin
      for (int k = 0; k < 2 * NUM_WAYS; k++) ld(p, la(S, 40 + p * 16 + k));   // evicting fills
      st(p, la(S, 20 + (p % NUM_WAYS), 1), 32'hBEEF_0000 + 32'(p));          // stores into victims
      ld(p, la(S, 20 + (p % NUM_WAYS), 1));
    end
    tick(1500);
    if (IS_CACHE) begin
      expect_true(dlt(gc_pkg::EV_RPL_RES) > 0, "evict_stall: port-0 replays not observed");
      if (NUM_PORTS > 1) expect_true(dlt(gc_pkg::EV_EVICT) > 0, "evict_stall: no evictions during stall");
    end
    for (int p = 1; p < NUM_PORTS; p++)
      expect_true(p_out[p] == 0 && pq[p].size() == 0,
                  $sformatf("evict_stall: port %0d blocked by port 0 back-pressure", p));
    expect_true(p_out[0] > 0, "evict_stall: port 0 should still have outstanding loads");
    rsp_mode[0] = 0;
    wait_idle();
    // re-read everything after the storm
    for (int w = 0; w < NUM_WAYS; w++) ld(0, la(S, 20 + w, 1));
    wait_idle();
    mlp = save_mlp;
  endtask

  task automatic t_flush_pending();
    bit e;
    int save_mlp;
    logic [1:0] ops [3];
    ops[0] = gc_pkg::CTRL_FENCE; ops[1] = gc_pkg::CTRL_FLUSH; ops[2] = gc_pkg::CTRL_INVAL;
    save_mlp = mlp;
    mlp = 16;
    for (int i = 0; i < 3; i++) begin
      // W1 (sets 0..7): touched by the burst; W2 (sets 16..23): untouched afterwards
      for (int k = 0; k < 8; k++) begin
        ld(k % NUM_PORTS, la(k % NUM_SETS, 50 + i));
        ld(k % NUM_PORTS, la((16 + k) % NUM_SETS, 150 + 8 * i + k));
      end
      wait_idle();
      // burst of misses, hits and stores on every port (sets 0..15)
      for (int p = 0; p < NUM_PORTS; p++) begin
        for (int k = 0; k < 6; k++) begin
          ld(p, la((8 + k) % NUM_SETS, 60 + 8 * i + p));
          st(p, la((8 + k) % NUM_SETS, 61 + 8 * i + p, 2), 32'hF00D_0000 + 32'(p * 16 + k));
          ld(p, la(k % 8 % NUM_SETS, 50 + i, 1));
          st(p, la(k % 8 % NUM_SETS, 50 + i, 3), 32'hD00D_0000 + 32'(p * 16 + k));
        end
      end
      tick(6);
      do_ctrl(ops[i], e);
      expect_true(!e, "flush_pending: unexpected ctrl_err");
      expect_true(ctrl_busy_at_accept && ctrl_pre_outstanding > 0,
                  $sformatf("flush_pending[%0d]: control op did not overlap pending work", i));
      wait_idle();
      // W2 lines: after FLUSH/INVAL nothing may hit; after FENCE they still hit
      snap_take();
      for (int k = 0; k < 8; k++) ld(k % NUM_PORTS, la((16 + k) % NUM_SETS, 150 + 8 * i + k, 2));
      wait_idle();
      if (IS_CACHE) begin
        if (ops[i] == gc_pkg::CTRL_FENCE) begin
          if (NUM_SETS >= 32 && NUM_WAYS >= 2)
            expect_true(dlt(gc_pkg::EV_LD_HIT) == 8, $sformatf("fence: lines lost (%0d hits)", dlt(gc_pkg::EV_LD_HIT)));
        end else begin
          expect_true(dlt(gc_pkg::EV_LD_HIT) == 0, $sformatf("flush/inval: %0d stale hits", dlt(gc_pkg::EV_LD_HIT)));
        end
      end
    end
    mlp = save_mlp;
  endtask

  task automatic t_fence();
    bit e;
    // stores on every port immediately followed by a fence; the monitor checks
    // that memory == reference at completion and that nothing was accepted
    // while the fence drained
    for (int p = 0; p < NUM_PORTS; p++)
      for (int k = 0; k < 6; k++) st(p, la((p + 2 * k) % NUM_SETS, 70 + k, p), 32'h5EED_0000 + 32'(p * 64 + k));
    for (int p = 0; p < NUM_PORTS; p++) ld(p, la(p % NUM_SETS, 70, p), 20);  // presented during the fence
    tick(3);
    do_ctrl(gc_pkg::CTRL_FENCE, e);
    expect_true(!e, "fence: unexpected error");
    wait_idle();
  endtask

  task automatic t_errors();
    bit e;
    logic [31:0] EB;
    EB = 32'h0020_0800;
    snap_take();
    // malformed requests
    ld(0, la(1, 3) + 1);
    st(0 % NUM_PORTS, la(1, 3) + 2, 32'h1, 4'hF);
    push(1 % NUM_PORTS, 2'd2, la(1, 3), 0, 4'hF);
    push(2 % NUM_PORTS, 2'd3, la(1, 3), 0, 4'hF);
    wait_idle();
    expect_true(dlt(gc_pkg::EV_ERR_RSP) == 4, $sformatf("errors: %0d error responses != 4", dlt(gc_pkg::EV_ERR_RSP)));
    expect_true(err_status[gc_pkg::ERR_MISALIGNED] && err_status[gc_pkg::ERR_BADOP], "errors: status bits");
    // memory error region
    err_base = EB;
    err_size = 32'(4 * LINE_BYTES);
    snap_take();
    for (int p = 0; p < NUM_PORTS; p++) ld(p, EB + 32'(4 * p));   // merged on the cache
    wait_idle();
    expect_true(err_status[gc_pkg::ERR_MEM_RD], "errors: MEM_RD status not set");
    if (IS_CACHE) begin
      expect_true(dlt(gc_pkg::EV_FILL_ERR) >= 1, "errors: errored fill not reported");
      expect_true(dlt(gc_pkg::EV_FILL) == 0, "errors: errored line was installed");
      snap_take();
      ld(0, EB);
      wait_idle();
      expect_true(dlt(gc_pkg::EV_LD_MISS) == 1, "errors: errored line must not be cached");
    end
    st(0, EB + 32'(LINE_BYTES), 32'h0BAD_0BAD);
    wait_idle();
    do_ctrl(gc_pkg::CTRL_FENCE, e);
    expect_true(e, "errors: fence did not report the failed store");
    expect_true(err_status[gc_pkg::ERR_MEM_WR], "errors: MEM_WR status not set");
    do_ctrl(gc_pkg::CTRL_FENCE, e);
    expect_true(!e, "errors: write error not cleared by previous completion");
    // reserved control opcode
    do_ctrl(2'd3, e);
    expect_true(e, "errors: reserved ctrl op not rejected");
    expect_true(err_status[gc_pkg::ERR_CTRL_BADOP], "errors: CTRL_BADOP status not set");
    // prefetch running into the error region must be silent
    if (HAS_PF) begin
      int save_mlp;
      save_mlp  = mlp;
      mlp       = 1;          // blocking stream: leaves MSHRs free for prefetches
      pf_enable = 1'b1;
      pf_dist   = 4'd2;
      snap_take();
      for (int k = 16; k >= 1; k--) ld(0, EB - 32'(k * LINE_BYTES), 0, 8'h7);
      wait_idle();
      if (N_MSHR >= 4)
        expect_true(dlt(gc_pkg::EV_MEM_RD_PF) > 0, "errors: prefetcher did not run");
      expect_true(dlt(gc_pkg::EV_ERR_RSP) == 0, "errors: prefetch error leaked to a core");
      pf_enable = 1'b0;
      mlp       = save_mlp;
    end
    // spurious responses (nothing outstanding)
    mem_quiet_check = 1'b0;
    snap_take();
    begin
      inj_t q;
      q.we = 1'b0; q.id = 8'd0; inject_q.push_back(q);
      q.we = 1'b1; q.id = 8'd0; inject_q.push_back(q);
    end
    tick(10);
    expect_true(dlt(gc_pkg::EV_SPURIOUS) == 2, $sformatf("errors: %0d spurious detected != 2", dlt(gc_pkg::EV_SPURIOUS)));
    expect_true(err_status[gc_pkg::ERR_SPURIOUS], "errors: SPURIOUS status not set");
    mem_quiet_check = 1'b1;
    err_size = 0;
    // normal traffic still works
    gen_random(40, 8, 0, 0);
    wait_idle();
  endtask

  // random traffic generator: n requests per port over a small line pool
  // (few sets, more lines than ways) to force merges, conflicts and evictions
  function automatic void gen_random(input int n, input int pool_sets, input int bad_pct,
                                     input int err_pct);
    int nsets, ntags;
    nsets = (pool_sets < NUM_SETS) ? pool_sets : NUM_SETS;
    ntags = 2 * NUM_WAYS + 2;
    for (int p = 0; p < NUM_PORTS; p++) begin
      int k;
      k = 0;
      while (k < n) begin
        int r;
        r = $urandom % 100;
        if (r < 8) begin
          // short sequential run (prefetch training) with a stable pc
          logic [31:0] base;
          int len;
          base = la($urandom % nsets, $urandom % ntags);
          len  = 4 + ($urandom % 12);
          for (int j = 0; j < len && k < n; j++, k++)
            ld(p, base + 32'(j * 4 * (1 + ($urandom % 2))), $urandom % 2, 8'h10 + 8'(p));
        end else begin
          logic [31:0] a;
          logic [1:0]  op;
          a  = la($urandom % nsets, $urandom % ntags, $urandom % (LINE_BYTES / 4));
          op = (($urandom % 100) < 60) ? gc_pkg::OP_LOAD : gc_pkg::OP_STORE;
          if (($urandom % 100) < bad_pct) begin
            if ($urandom % 2) a = a + 32'(1 + $urandom % 3);
            else op = 2'd2 + 2'($urandom % 2);
          end
          if (($urandom % 100) < err_pct) a = err_base + 32'(($urandom % (err_size / 4)) * 4);
          push(p, op, a, $urandom, 4'($urandom % 16), $urandom % 3, 8'($urandom % 4));
          k++;
        end
      end
    end
  endfunction

  task automatic t_random(input int n, input int iters);
    bit e;
    int save_mlp;
    save_mlp = mlp;
    for (int it = 0; it < iters; it++) begin
      mlp = 1 + $urandom % 24;
      mem_lat    = 5 + $urandom % 120;
      mem_jitter = $urandom % 60;
      mem_bp_pct = $urandom % 30;
      mem_bw     = 4 << ($urandom % 4);
      for (int p = 0; p < NUM_PORTS; p++) rsp_mode[p] = ($urandom % 3 == 0) ? 1 : 0;
      rsp_ready_pct = 40 + $urandom % 60;
      err_base = 32'h0030_0000;
      err_size = 32'(2 * LINE_BYTES);
      pf_enable = HAS_PF && ($urandom % 2);
      pf_dist   = 4'(1 + $urandom % 8);
      gen_random(n, 2 + $urandom % 6, 4, 3);
      // interleave control operations with the traffic
      forever begin
        int t;
        t = total_outstanding();
        if (t == 0) break;
        tick(50 + $urandom % 400);
        t = total_outstanding();
        if (t > 0) do_ctrl(2'($urandom % 4), e);
      end
      wait_idle();
      do_ctrl(gc_pkg::CTRL_FENCE, e);
      for (int p = 0; p < NUM_PORTS; p++) rsp_mode[p] = 0;
    end
    mlp = save_mlp;
    err_size = 0;
    mem_jitter = 0; mem_bp_pct = 0; mem_lat = 100; mem_bw = 16;
    pf_enable = 1'b0;
  endtask

  task automatic t_reset(input int iters);
    bit e;
    int save_mlp;
    save_mlp = mlp;
    mlp = 16;
    for (int it = 0; it < iters; it++) begin
      logic [31:0] hot;
      hot = la(2, 90);
      ld(0, hot);
      wait_idle();
      mem_jitter = $urandom % 40;
      pf_enable  = HAS_PF;
      gen_random(200, 4, 2, 0);
      tick(30 + $urandom % 300);
      if ($urandom % 2) begin
        // also leave a control operation in flight
        @(negedge clk);
        ctrl_valid = 1'b1;
        ctrl_op    = 2'($urandom % 3);
        tick(1 + $urandom % 3);
      end
      // ---- asynchronous-to-traffic reset (synchronous to clk) ----
      @(negedge clk);
      rst = 1'b1;
      ctrl_valid = 1'b0;
      for (int p = 0; p < NUM_PORTS; p++) pq[p].delete();
      tick(1);
      expect_true(req_ready == '0 && !ctrl_ready, "reset: ready asserted during reset");
      tick($urandom % 4);
      rst = 1'b0;
      tick(1);
      // immediately after reset: idle, clean, counters zero
      expect_true(rsp_valid == '0 && !mem_req_valid && !busy && !ctrl_done,
                  "reset: DUT not idle after reset");
      expect_true(err_status == '0, "reset: error status not cleared");
      for (int ev = 0; ev < N_EV; ev++)
        expect_true(perf(ev) == 0, $sformatf("reset: counter %s not cleared", ev_name[ev]));
      // the cache must be empty after reset
      snap_take();
      ld(0, hot);
      wait_idle();
      if (IS_CACHE) expect_true(dlt(gc_pkg::EV_LD_HIT) == 0, "reset: stale line survived reset");
      // and fully functional
      gen_random(150, 4, 2, 0);
      wait_idle();
      do_ctrl(gc_pkg::CTRL_FENCE, e);
      pf_enable = 1'b0;
    end
    mem_jitter = 0;
    mlp = save_mlp;
  endtask

  task automatic t_prefetch();
    bit e;
    longint iss, use_;
    if (!HAS_PF) begin
      $display("  (no prefetcher in this build: prefetch test is a no-op)");
      return;
    end
    // (1) single-port unit-stride stream: useful prefetches, correct data
    pf_enable = 1'b1;
    pf_dist   = 4'd4;
    mlp = 8;
    snap_take();
    for (int k = 0; k < 64 * (LINE_BYTES / 4); k++) ld(0, 32'h0040_0000 + 32'(k * 4), 0, 8'h21);
    wait_idle();
    iss  = dlt(gc_pkg::EV_MEM_RD_PF);
    use_ = dlt(gc_pkg::EV_PF_USEFUL) + dlt(gc_pkg::EV_PF_LATE);
    $display("  prefetch stream: issued=%0d useful=%0d late=%0d demand_misses=%0d",
             iss, dlt(gc_pkg::EV_PF_USEFUL), dlt(gc_pkg::EV_PF_LATE), dlt(gc_pkg::EV_LD_MISS));
    if (N_MSHR >= 4) begin
      expect_true(iss > 32, "prefetch: too few prefetches on a stream");
      expect_true(use_ * 10 >= iss * 8, "prefetch: accuracy below 80% on a pure stream");
    end
    // (2) random accesses: prefetcher must stay quiet
    snap_take();
    for (int k = 0; k < 1000; k++) ld(k % NUM_PORTS, 32'h0080_0000 + 32'(($urandom % 262144) * 4), 0, 8'h22);
    wait_idle();
    $display("  prefetch random: issued=%0d for 1000 loads", dlt(gc_pkg::EV_MEM_RD_PF));
    expect_true(dlt(gc_pkg::EV_MEM_RD_PF) <= 20, "prefetch: not conservative on random traffic");
    // (3) stores racing in-flight prefetches + invalidate with prefetches in flight
    snap_take();
    for (int k = 0; k < 24; k++) begin
      ld(0, 32'h00C0_0000 + 32'(k * LINE_BYTES), 0, 8'h23);
      if (NUM_PORTS > 1) st(1, 32'h00C0_0000 + 32'((k + 4) * LINE_BYTES + 4), 32'h7777_0000 + 32'(k), 4'hF, 1);
    end
    tick(40);
    do_ctrl(gc_pkg::CTRL_INVAL, e);
    wait_idle();
    for (int k = 0; k < 28; k++) ld(k % NUM_PORTS, 32'h00C0_0000 + 32'(k * LINE_BYTES + 4));
    wait_idle();
    // (4) prefetch whose target already has a DEMAND miss in flight must be
    //     filtered (one MSHR per line), never allocate a second MSHR
    if (NUM_PORTS > 1) begin
      logic [31:0] B;
      B = 32'h00E0_0000;
      pf_dist = 4'd4;
      mem_lat = 300;                       // keep the demand miss in flight
      snap_take();
      ld(1, B + 32'(7 * LINE_BYTES + 8));  // demand miss on the future prefetch target
      for (int k = 0; k < 4; k++) ld(0, B + 32'(k * LINE_BYTES), 2, 8'h25);
      wait_idle();
      ld(1, B + 32'(7 * LINE_BYTES + 12));
      wait_idle();
      mem_lat = 100;
      if (N_MSHR >= 4)
        expect_true(dlt(gc_pkg::EV_PF_FILT) > 0, "prefetch: in-flight target not filtered");
    end
    // (5) runtime disable
    pf_enable = 1'b0;
    snap_take();
    for (int k = 0; k < 512; k++) ld(0, 32'h0050_0000 + 32'(k * 4), 0, 8'h24);
    wait_idle();
    expect_true(dlt(gc_pkg::EV_MEM_RD_PF) == 0, "prefetch: issued while disabled");
  endtask

  // ---------------------------------------------------------------------------
  // trace mode
  // ---------------------------------------------------------------------------
  task automatic load_traces(input string dir);
    for (int p = 0; p < NUM_PORTS; p++) begin
      int fd, cnt;
      string fn;
      fn = $sformatf("%s/p%0d.trc", dir, p);
      fd = $fopen(fn, "r");
      if (fd == 0) begin
        fail($sformatf("cannot open %s", fn));
        continue;
      end
      cnt = 0;
      while (!$feof(fd)) begin
        int op, gap, n;
        logic [31:0] a, d;
        logic [3:0]  s;
        logic [7:0]  pc;
        n = $fscanf(fd, "%d %h %h %h %h %d\n", op, a, d, s, pc, gap);
        if (n == 6) begin
          push(p, 2'(op), a, d, s, gap, pc);
          cnt++;
        end else break;
      end
      $fclose(fd);
      $display("  trace p%0d: %0d requests", p, cnt);
    end
  endtask

  task automatic write_stats(input string fn, input string label);
    int fd;
    longint run, first_acc;
    string dutname;
    fd = $fopen(fn, "w");
    if (IS_CACHE) dutname = "cache"; else dutname = "uncached";
    begin
      longint t0, t1;
      t0 = -1; t1 = 0;
      for (int p = 0; p < NUM_PORTS; p++) begin
        if (p_first_acc[p] >= 0 && (t0 < 0 || p_first_acc[p] < t0)) t0 = p_first_acc[p];
        if (p_last_rsp[p] > t1) t1 = p_last_rsp[p];
      end
      first_acc = t0;
      run = t1 - t0;
    end
    $fwrite(fd, "{\n  \"label\": \"%s\",\n", label);
    $fwrite(fd, "  \"config\": {\"dut\": \"%s\", \"ports\": %0d, \"line_bytes\": %0d, \"sets\": %0d, \"ways\": %0d, \"repl\": %0d, \"mshr\": %0d, \"tgt\": %0d, \"pf_built\": %0d, \"pf_enable\": %0d, \"pf_dist\": %0d, \"mlp\": %0d, \"mem_lat\": %0d, \"mem_jitter\": %0d, \"mem_bw\": %0d},\n",
            dutname, NUM_PORTS, LINE_BYTES, NUM_SETS, NUM_WAYS, REPL, IS_CACHE ? N_MSHR : N_OT, N_TGT,
            PF_ENABLE, pf_enable, pf_dist, mlp, mem_lat, mem_jitter, mem_bw);
    $fwrite(fd, "  \"cycles\": %0d,\n  \"accepted\": %0d,\n  \"loads_ok\": %0d,\n  \"stores_ok\": %0d,\n  \"err_rsp\": %0d,\n",
            run, n_acc, n_ld_ok, n_st_ok, n_err_rsp);
    $fwrite(fd, "  \"lat_sum\": %0d,\n  \"lat_n\": %0d,\n  \"lat_max\": %0d,\n  \"e2e_sum\": %0d,\n", lat_sum, lat_n, lat_max, e2e_sum);
    $fwrite(fd, "  \"bp_cycles\": [");
    for (int p = 0; p < NUM_PORTS; p++)
      $fwrite(fd, "%0d%s", p_bp_cycles[p], (p == NUM_PORTS - 1) ? "" : ", ");
    $fwrite(fd, "],\n  \"e2e_hist\": [");
    begin
      bit first;
      first = 1'b1;
      for (int i = 0; i < LAT_BINS; i++)
        if (e2e_hist[i] != 0) begin
          $fwrite(fd, "%s[%0d, %0d]", first ? "" : ", ", i, e2e_hist[i]);
          first = 1'b0;
        end
    end
    $fwrite(fd, "],\n");
    $fwrite(fd, "  \"mem\": {\"rd_dem_bytes\": %0d, \"rd_pf_bytes\": %0d, \"wr_bytes\": %0d, \"n_rd_dem\": %0d, \"n_rd_pf\": %0d, \"n_wr\": %0d, \"busy_cycles\": %0d},\n",
            mem_rd_dem_bytes, mem_rd_pf_bytes, mem_wr_bytes, mem_n_rd_dem, mem_n_rd_pf, mem_n_wr, mem_busy_cycles);
    $fwrite(fd, "  \"perf\": {");
    for (int ev = 0; ev < N_EV; ev++)
      $fwrite(fd, "\"%s\": %0d%s", ev_name[ev], perf(ev), (ev == N_EV - 1) ? "" : ", ");
    $fwrite(fd, "},\n  \"port_finish\": [");
    for (int p = 0; p < NUM_PORTS; p++)
      $fwrite(fd, "%0d%s", p_last_rsp[p] - first_acc, (p == NUM_PORTS - 1) ? "" : ", ");
    $fwrite(fd, "],\n  \"lat_hist\": [");
    begin
      bit first;
      first = 1'b1;
      for (int i = 0; i < LAT_BINS; i++)
        if (lat_hist[i] != 0) begin
          $fwrite(fd, "%s[%0d, %0d]", first ? "" : ", ", i, lat_hist[i]);
          first = 1'b0;
        end
    end
    $fwrite(fd, "],\n  \"errors\": %0d\n}\n", n_errors);
    $fclose(fd);
  endtask

  // ---------------------------------------------------------------------------
  // main
  // ---------------------------------------------------------------------------
  task automatic finish_sim();
    $display("TB_SUMMARY: cycles=%0d accepted=%0d committed=%0d responses=%0d ctrl_done=%0d",
             cycle, tot_acc, tot_cmt, tot_rsp, n_ctrl_done);
    if (n_errors == 0 && test_fail_cnt == 0) $display("TB_RESULT: PASS (tests passed=%0d)", test_pass_cnt);
    else $display("TB_RESULT: FAIL (errors=%0d, tests failed=%0d)", n_errors, test_fail_cnt);
    $finish;
  endtask

  initial begin
    string test, tdir, sfile, label;
    int    e0, n_rand, iters, tmp;
    bit    e;
    if (!$value$plusargs("test=%s", test)) test = "all";
    if (!$value$plusargs("rand_n=%d", n_rand)) n_rand = 300;
    if (!$value$plusargs("iters=%d", iters)) iters = 4;
    if ($value$plusargs("mem_lat=%d", tmp))    mem_lat = tmp;
    if ($value$plusargs("mem_bw=%d", tmp))     mem_bw = tmp;
    if ($value$plusargs("mem_jitter=%d", tmp)) mem_jitter = tmp;
    if ($value$plusargs("mlp=%d", tmp))        mlp = tmp;
    if ($value$plusargs("pf_en=%d", tmp))      pf_enable = (tmp != 0);
    if ($value$plusargs("pf_dist=%d", tmp))    pf_dist = 4'(tmp);
    for (int p = 0; p < NUM_PORTS; p++) begin
      rsp_mode[p] = 0;
      p_ntag[p] = 8'd0;
    end
    mem_stats_clear();
    clear_stats();
    $display("tb_top: DUT=%s ports=%0d line=%0dB sets=%0d ways=%0d repl=%0d mshr=%0d tgt=%0d pf_built=%0d test=%s",
             IS_CACHE ? "cache" : "uncached", NUM_PORTS, LINE_BYTES, NUM_SETS, NUM_WAYS, REPL,
             N_MSHR, N_TGT, PF_ENABLE, test);
    rst = 1'b1;
    tick(5);
    rst = 1'b0;
    tick(2);

    if (test == "trace") begin
      if (!$value$plusargs("trace_dir=%s", tdir)) tdir = ".";
      if (!$value$plusargs("stats=%s", sfile)) sfile = "stats.json";
      if (!$value$plusargs("label=%s", label)) label = "run";
      load_traces(tdir);
      mem_stats_clear();
      clear_stats();
      wait_idle(5000000);
      do_ctrl(gc_pkg::CTRL_FENCE, e);
      write_stats(sfile, label);
      finish_sim();
    end

    if (test == "all" || test == "basic")         begin e0 = n_errors; t_basic();               report("basic", e0);         reset_dut(); end
    if (test == "all" || test == "simul")         begin e0 = n_errors; t_simul();               report("simul", e0);         reset_dut(); end
    if (test == "all" || test == "sameline")      begin e0 = n_errors; t_sameline();            report("sameline", e0);      reset_dut(); end
    if (test == "all" || test == "mshrfull")      begin e0 = n_errors; t_mshrfull();            report("mshrfull", e0);      reset_dut(); end
    if (test == "all" || test == "evict_stall")   begin e0 = n_errors; t_evict_stall();         report("evict_stall", e0);   reset_dut(); end
    if (test == "all" || test == "flush_pending") begin e0 = n_errors; t_flush_pending();       report("flush_pending", e0); reset_dut(); end
    if (test == "all" || test == "fence")         begin e0 = n_errors; t_fence();               report("fence", e0);         reset_dut(); end
    if (test == "all" || test == "errors")        begin e0 = n_errors; t_errors();              report("errors", e0);        reset_dut(); end
    if (test == "all" || test == "prefetch")      begin e0 = n_errors; t_prefetch();            report("prefetch", e0);      reset_dut(); end
    if (test == "all" || test == "reset")         begin e0 = n_errors; t_reset(iters + 2);      report("reset", e0);         reset_dut(); end
    if (test == "all" || test == "random")        begin e0 = n_errors; t_random(n_rand, iters); report("random", e0);        reset_dut(); end
    if (test != "trace") finish_sim();
  end
endmodule
