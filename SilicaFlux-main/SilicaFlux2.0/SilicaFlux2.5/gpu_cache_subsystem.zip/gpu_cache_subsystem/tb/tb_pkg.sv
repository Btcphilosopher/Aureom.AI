// -----------------------------------------------------------------------------
// tb_pkg - testbench-global state shared by the memory model and tb_top.
// (Simulation only; uses full SystemVerilog as supported by Verilator 5.)
// -----------------------------------------------------------------------------
package tb_pkg;

  // deterministic initial memory content: every word has a unique-ish value
  function automatic logic [31:0] init_word(input logic [31:0] a);
    logic [31:0] x;
    x = {a[31:2], 2'b00} ^ 32'h9E37_79B9;
    x = x ^ (x >> 16);
    x = x * 32'h85EB_CA6B;
    x = x ^ (x >> 13);
    x = x * 32'hC2B2_AE35;
    x = x ^ (x >> 16);
    return x;
  endfunction

  // ---- memory model configuration (set from plusargs / tests) --------------
  int          mem_lat      = 100;   // cycles from end of data transfer to response
  int          mem_jitter   = 0;     // + uniform [0, jitter] cycles (=> out-of-order)
  int          mem_bw       = 16;    // bytes per cycle (shared read+write)
  int          mem_max_out  = 64;    // max requests in flight inside the model
  int          mem_bp_pct   = 0;     // random request back-pressure probability (%)
  int          mem_window   = 256;   // max cycles of queued transfer backlog
  int          sector_bytes = 32;    // DRAM access granularity for accounting
  logic [31:0] err_base     = 32'h0;
  logic [31:0] err_size     = 32'h0; // 0 = no error region

  function automatic bit in_err(input logic [31:0] a);
    return (err_size != 0) && (a >= err_base) && (a < err_base + err_size);
  endfunction

  // ---- backing store (word address -> data) --------------------------------
  logic [31:0] mem_store [logic [31:0]];

  function automatic logic [31:0] mem_read(input logic [31:0] a);
    logic [31:0] k;
    k = {a[31:2], 2'b00};
    if (mem_store.exists(k)) return mem_store[k];
    return init_word(k);
  endfunction

  // ---- statistics ------------------------------------------------------------
  longint mem_rd_dem_bytes, mem_rd_pf_bytes, mem_wr_bytes;
  longint mem_n_rd_dem, mem_n_rd_pf, mem_n_wr;
  longint mem_busy_cycles;
  int     mem_pend_cnt;      // transactions inside the model (updated every cycle)
  int     mem_rd_out;        // reads inside the model
  int     mem_max_rd_out;    // high-water mark of mem_rd_out

  function automatic void mem_stats_clear();
    mem_rd_dem_bytes = 0; mem_rd_pf_bytes = 0; mem_wr_bytes = 0;
    mem_n_rd_dem = 0; mem_n_rd_pf = 0; mem_n_wr = 0; mem_busy_cycles = 0;
    mem_max_rd_out = 0;
  endfunction

  // ---- fault injection: spurious responses -------------------------------------
  typedef struct packed { logic we; logic [7:0] id; } inj_t;
  inj_t inject_q [$];

endpackage
