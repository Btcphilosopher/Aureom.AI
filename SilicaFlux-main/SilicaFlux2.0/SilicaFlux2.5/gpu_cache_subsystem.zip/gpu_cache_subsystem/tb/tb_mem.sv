// -----------------------------------------------------------------------------
// tb_mem - behavioural memory model (simulation only)
//
// PLATFORM ASSUMPTIONS (see docs/PLATFORM_ASSUMPTIONS.md):
//   * ordering point = request acceptance: writes are applied and read data is
//     sampled in the cycle the request handshake completes
//   * one shared data "bus" of mem_bw bytes/cycle; each request occupies it for
//     ceil(bytes/mem_bw) cycles, where bytes = (#32B sectors touched) * 32
//   * response time = end of transfer + mem_lat + U[0, mem_jitter]
//     (jitter > 0 => responses return out of order)
//   * acceptance is throttled when mem_max_out transactions are inside or the
//     queued transfer backlog exceeds mem_window cycles; optional random
//     back-pressure (mem_bp_pct)
//   * addresses in [err_base, err_base+err_size) return an error: reads get
//     zero data + err, writes are dropped + err ack
//   * reset drops every in-flight transaction (backing store is preserved)
// There is no DRAM bank/row model, no refresh, no L2, no interconnect.
// -----------------------------------------------------------------------------
module tb_mem #(
  parameter int LINE_BYTES = 64,
  parameter int ID_W       = 8,
  parameter int ADDR_W     = 32
) (
  input  logic                    clk,
  input  logic                    rst,
  input  logic                    req_valid,
  output logic                    req_ready,
  input  logic                    req_we,
  input  logic [ADDR_W-1:0]       req_addr,
  input  logic [LINE_BYTES*8-1:0] req_wdata,
  input  logic [LINE_BYTES-1:0]   req_be,
  input  logic [ID_W-1:0]         req_id,
  input  logic                    req_pf,
  output logic                    rsp_valid,
  input  logic                    rsp_ready,
  output logic                    rsp_we,
  output logic [ID_W-1:0]         rsp_id,
  output logic [LINE_BYTES*8-1:0] rsp_rdata,
  output logic                    rsp_err
);
  import tb_pkg::*;

  localparam int LB  = LINE_BYTES * 8;
  localparam int WPL = LINE_BYTES / 4;

  typedef struct packed {
    longint          t;
    logic            we;
    logic [ID_W-1:0] id;
    logic [LB-1:0]   data;
    logic            err;
  } pend_t;

  pend_t  pend [$];
  longint cyc;
  longint bus_free;

  initial begin
    cyc = 0;
    bus_free = 0;
    rsp_valid = 1'b0;
    req_ready = 1'b0;
  end

  function automatic void accept();
    pend_t       e;
    int          sec, nsec, bytes;
    longint      start, xfer;
    logic [31:0] a, old, nw;
    sec  = (LINE_BYTES < sector_bytes) ? LINE_BYTES : sector_bytes;
    nsec = 0;
    for (int s = 0; s < LINE_BYTES / sec; s++) begin
      bit touched;
      touched = 1'b0;
      for (int b = 0; b < sec; b++) if (req_be[s*sec + b]) touched = 1'b1;
      if (touched) nsec++;
    end
    bytes = nsec * sec;
    xfer  = (bytes + mem_bw - 1) / mem_bw;
    start = (bus_free > cyc) ? bus_free : cyc;
    bus_free = start + xfer;
    mem_busy_cycles += xfer;
    e.t    = bus_free + mem_lat + ((mem_jitter > 0) ? longint'($urandom % (mem_jitter + 1)) : 0);
    e.we   = req_we;
    e.id   = req_id;
    e.err  = in_err(req_addr);
    e.data = '0;
    if (req_we) begin
      mem_wr_bytes += bytes;
      mem_n_wr++;
      if (!e.err) begin
        for (int w = 0; w < WPL; w++) begin
          if (|req_be[w*4 +: 4]) begin
            a   = req_addr + 32'(w * 4);
            old = mem_read(a);
            nw  = old;
            for (int b = 0; b < 4; b++)
              if (req_be[w*4 + b]) nw[b*8 +: 8] = req_wdata[w*32 + b*8 +: 8];
            mem_store[a] = nw;
          end
        end
      end
    end else begin
      if (req_pf) begin mem_rd_pf_bytes += bytes; mem_n_rd_pf++; end
      else        begin mem_rd_dem_bytes += bytes; mem_n_rd_dem++; end
      if (!e.err)
        for (int w = 0; w < WPL; w++) e.data[w*32 +: 32] = mem_read(req_addr + 32'(w * 4));
      mem_rd_out++;
      if (mem_rd_out > mem_max_rd_out) mem_max_rd_out = mem_rd_out;
    end
    pend.push_back(e);
  endfunction

  always @(posedge clk) begin
    if (rst) begin
      pend.delete();
      rsp_valid   <= 1'b0;
      req_ready   <= 1'b0;
      bus_free     = cyc;
      mem_rd_out   = 0;
      mem_pend_cnt = 0;
      inject_q.delete();
    end else begin
      // fault injection (spurious responses)
      while (inject_q.size() > 0) begin
        pend_t e;
        inj_t  q;
        q      = inject_q.pop_front();
        e.t    = cyc;
        e.we   = q.we;
        e.id   = ID_W'(q.id);
        e.data = '0;
        e.err  = 1'b0;
        pend.push_back(e);
        if (!q.we) mem_rd_out++;
      end
      // present the next response (oldest ready first)
      if (!rsp_valid || rsp_ready) begin
        int best;
        best = -1;
        for (int i = 0; i < pend.size(); i++)
          if (pend[i].t <= cyc && (best < 0 || pend[i].t < pend[best].t)) best = i;
        if (best >= 0) begin
          rsp_valid <= 1'b1;
          rsp_we    <= pend[best].we;
          rsp_id    <= pend[best].id;
          rsp_rdata <= pend[best].data;
          rsp_err   <= pend[best].err;
          if (!pend[best].we) mem_rd_out--;
          pend.delete(best);
        end else begin
          rsp_valid <= 1'b0;
        end
      end
      // accept a request
      if (req_valid && req_ready) accept();
      // registered ready for the next cycle
      req_ready <= (pend.size() < mem_max_out) && ((bus_free - cyc) < longint'(mem_window)) &&
                   !((mem_bp_pct > 0) && (($urandom % 100) < mem_bp_pct));
      mem_pend_cnt = pend.size();
    end
    cyc++;
  end
endmodule
