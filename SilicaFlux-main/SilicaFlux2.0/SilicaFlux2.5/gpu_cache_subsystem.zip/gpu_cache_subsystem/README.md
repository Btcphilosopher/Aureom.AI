# GPU cache subsystem (SystemVerilog) with Python workload analysis

A small, configurable, non-blocking GPU L1-style data cache in synthesizable
SystemVerilog, an uncached baseline with the same interface, an optional
conservative stride prefetcher, a self-checking Verilator testbench, and a
reproducible Python experiment and analysis flow.

> **Platform label.** Performance results come from **cycle-accurate RTL simulation
> with a behavioural memory model**, in abstract clock cycles. No FPGA was used and
> nothing is an ASIC prediction; synthesis numbers are Yosys mapping estimates.
> See [`docs/PLATFORM_ASSUMPTIONS.md`](docs/PLATFORM_ASSUMPTIONS.md).

## What is where

| Path | Content |
|---|---|
| `rtl/gc_cache.sv` | the cache: MSHRs, merging, LRU/FIFO/RANDOM, write-through, response routing, fence/flush/inval, errors |
| `rtl/gc_uncached.sv` | uncached baseline, identical interface |
| `rtl/gc_pf_stride.sv` | conservative stride prefetcher (optional, `PF_ENABLE=1`) |
| `rtl/gc_*.sv` | FIFO, round-robin arbiter, SRAM model, control FSM, counters, package |
| `tb/` | testbench (`tb_top.sv`: commit-order oracle + directed/random tests) and memory model (`tb_mem.sv`) |
| `python/` | workloads, reference model, regression, mutation test, experiments, analysis, report |
| `docs/SPEC.md` | **the cache policy specification**: line size, associativity, replacement, write policy, miss tracking, merging, response routing, flush/invalidate, fence, errors, reset, scope |
| `docs/PREFETCHER.md` | prefetcher design, demand/prefetch separation, metric definitions |
| `docs/VERIFICATION.md` | test plan, oracle, assertions, mutation testing, bugs found, limits |
| `docs/PLATFORM_ASSUMPTIONS.md` | what the numbers mean and do not mean |
| `results/RESULTS.md` | **the evaluation report** (generated) |
| `results/` | verification summaries, raw run JSON, CSV tables, figures, synthesis logs |

## Requirements

* Verilator ≥ 5.020 (tested with 5.020), a C++ compiler, GNU make
* Python ≥ 3.10 with numpy, pandas, matplotlib
* Yosys (optional, only for `make synth`; tested with 0.33)

On Debian/Ubuntu: `apt-get install verilator yosys` and `pip install numpy pandas matplotlib`.

## Reproduce

```bash
make all          # lint, regression, cross-check, mutation, experiments, figures, synth, report
make test-quick   # ~1 min smoke test
```

Every run is seeded; with identical sources and tool versions (recorded in
`results/ENVIRONMENT.txt`) the numbers are bit-identical. Changing any source file,
even the testbench, reshuffles the simulated memory jitter and moves results by up
to ≈0.5 %, inside the reported seed spread. `make all` takes ≈20 min on 4 cores
(about half of it Yosys; the clean-room log is `results/make_all.log`); individual steps: `make help`.

## Headline results (details and caveats in `results/RESULTS.md`)

* Cache vs. uncached: large wins on reuse, stream and mixed traffic, but **~5 % slower
  with 2× the memory traffic on random and large-stride access** (64 B line fills
  for one useful word).
* Stride prefetcher: **≈1.46× on unit-stride streams** (≈99 % accuracy, < 1 % extra
  traffic), no effect on random/reuse/stride, and on the mixed workloads it **raises
  the hit rate yet makes the run ≈1–2 % slower in every seed**, because a few low-value
  prefetches occupy MSHRs (an isolation run shows the pipeline cost is zero).
* Hit rate is never used as evidence on its own: verdicts require a runtime gain in
  every seed plus traffic and tail-latency limits.

## Scope

Host/device coherence and coherence between several cache instances are **out of
scope** (software uses FLUSH/INVAL at synchronization points). `docs/SPEC.md` §1 and §6
list everything not implemented and the known limitations.
