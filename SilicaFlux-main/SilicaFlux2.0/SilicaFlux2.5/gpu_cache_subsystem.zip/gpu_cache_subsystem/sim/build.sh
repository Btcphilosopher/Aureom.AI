#!/usr/bin/env bash
# Build one Verilator simulation of tb_top.
#   usage: sim/build.sh <build_dir> [-G<param>=<value> ...]
# The executable is <build_dir>/sim.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=$1; shift
JOBS=${VERILATOR_JOBS:-4}
verilator --binary --timing --timescale 1ns/1ps -j "$JOBS" \
  -Wno-fatal -Wno-lint -Wno-style \
  --x-assign unique --x-initial unique -O2 --unroll-count 4096 \
  --top-module tb_top "$@" \
  "$ROOT/rtl/gc_pkg.sv" "$ROOT/tb/tb_pkg.sv" \
  "$ROOT/rtl/gc_fifo.sv" "$ROOT/rtl/gc_rr_arb.sv" "$ROOT/rtl/gc_sram_1r1w.sv" \
  "$ROOT/rtl/gc_ctrl_fsm.sv" "$ROOT/rtl/gc_perf.sv" "$ROOT/rtl/gc_pf_stride.sv" \
  "$ROOT/rtl/gc_uncached.sv" "$ROOT/rtl/gc_cache.sv" \
  "$ROOT/tb/tb_mem.sv" "$ROOT/tb/tb_top.sv" \
  -Mdir "$OUT" -o sim > "$OUT.build.log" 2>&1 || { cat "$OUT.build.log"; exit 1; }
