# Platform assumptions — read before using any number

**Every performance number in this package comes from cycle-accurate RTL
simulation (Verilator) of the cache RTL driven by a behavioural testbench and a
behavioural memory model.** No FPGA was programmed and no hardware was measured.
Synthesis numbers come from Yosys technology mapping only.

## 1. What is modelled exactly

* The cache and uncached-baseline RTL, cycle by cycle: arbitration, pipeline,
  replays, MSHRs, merging, response FIFOs, fences, prefetcher.

## 2. What is abstracted (labelled assumptions)

| Aspect | Assumption | Consequence |
|---|---|---|
| Clock | Results are in **cycles** of one clock domain. No frequency is assumed or claimed. | Runtimes cannot be converted to seconds without a timing-closed implementation. |
| SRAMs | Ideal synchronous 1R1W arrays, one-cycle read, no bank conflicts, no read/write port timing. | Real SRAM macros or FPGA BRAMs may need extra pipeline stages at high frequency. |
| Memory | `tb/tb_mem.sv`: ordering point at request acceptance; one shared data bus of `mem_bw` B/cycle (default 16); every access costs whole 32 B sectors; response = end of transfer + `mem_lat` (default 100) + U[0, `mem_jitter`] (default 16, gives out-of-order returns); at most 64 transactions inside; acceptance throttled at a 256-cycle backlog. | No DRAM banks/rows/refresh, no L2, no interconnect contention beyond the bandwidth cap, no write-combining. Absolute latencies are illustrative; trends (e.g. benefit vs latency) are the useful output, and sensitivity sweeps are provided. |
| Cores | 4 ports, each a closed-loop requester with ≤ 8 outstanding requests (`mlp`), 0–2 idle cycles between requests, word-sized requests, no warp coalescing, no data dependences. | Models a latency-hiding throughput machine, not a specific GPU. Coalesced 128 B warp requests would change merge/hit statistics. |
| Workloads | Synthetic traces (`python/workloads.py`), 8000 requests per port, deterministic seeds. | Representative access *patterns*, not real applications. |
| Statistics | Main study: 5 seeds; sweeps: 3 seeds. Seeds change trace randomness and memory jitter. | Run-to-run spread is reported (sd or min–max). |

## 3. FPGA vs ASIC — how to read the synthesis numbers

`results/synth/*.stat` are produced by `yosys synth_xilinx` (generic 7-series
cell library: LUT6, FDRE, CARRY4, RAM32M/RAM64M, RAMB18/36).

* They are **technology-mapping estimates**: no placement, no routing, no timing
  closure, no vendor tool. They are **not FPGA measurements** — nothing was
  implemented or run on an FPGA.
* They are **not ASIC predictions**. LUT/FF counts do not translate to ASIC gate
  area, an FPGA memory primitive count says nothing about SRAM macro area, and no
  frequency or power figure is derived. An ASIC estimate needs a standard-cell
  library, SRAM compiler data and a synthesis/STA flow, none of which is part of
  this package.
* The behavioural SRAM is written as one narrow array per byte lane (needed for
  byte-enable writes in a portable subset of SystemVerilog). This maps to
  distributed RAM rather than block RAM, so even as an FPGA estimate the memory
  mapping is pessimistic; a production flow would instantiate vendor or
  compiler macros.
* Use the numbers only for *relative* comparisons between configurations
  (e.g. cost of the prefetcher logic, of more MSHRs).

## 4. Tool versions used

Recorded in `results/ENVIRONMENT.txt` by `make env`.
