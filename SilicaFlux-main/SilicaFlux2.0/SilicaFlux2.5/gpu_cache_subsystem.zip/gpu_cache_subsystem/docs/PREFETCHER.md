# Conservative stride prefetcher

`rtl/gc_pf_stride.sv`, instantiated by `gc_cache` when `PF_ENABLE=1` and
switched on at run time with `pf_enable`. It was added **after** the baseline
cache had passed the full regression; with `pf_enable=0` the netlist behaves
exactly like the prefetch-less cache (same hit/miss counters), which is what
makes the A/B experiments a fair comparison on one netlist.

## 1. Algorithm

| Step | Rule |
|---|---|
| Training input | committed, well-formed **demand loads** only (hits, misses and merges). Stores, prefetches and erroring requests never train. |
| Table | `PF_ENTRIES` (16) direct-mapped entries, index = rotate-fold of `{port, pc}`, tagged with the full key. Entry: last line, signed line stride (8 bits), 2-bit confidence, last line prefetched. |
| Update | line delta 0 → ignored (word accesses inside one line). delta == stride ≠ 0 → confidence + 1 (saturating). Otherwise stride := delta (0 if it does not fit 8 bits), confidence := 0. |
| Issue | only if delta == stride ≠ 0 **and** confidence ≥ `PF_CONF_TH` (2): a stream needs four distinct, equally spaced lines before its first prefetch. Target = line + stride × `pf_dist`. **Degree 1.** |
| Suppression | target outside the 4 KiB page of the trigger; target equal to the entry's last prefetch; candidate queue (`PF_QDEPTH`=2) full. |
| In the cache | candidates are the **lowest-priority** pipeline source (only when no fill and no core request can issue). In S1 a candidate is **filtered** if the line hits or has an MSHR, and **dropped** unless more than `PF_MSHR_RSV` (2) MSHRs are free and the memory queue has room. Prefetches are disabled during control operations; INVAL/FLUSH clear the table. |

"Conservative" therefore means: high confidence threshold, degree 1, page
bounded, deduplicated, lowest priority, never allowed to consume the last MSHRs,
and dropped rather than queued when resources are short.

## 2. Demand vs prefetch tracking

| Where | What is tracked separately |
|---|---|
| MSHR | `is_prefetch`, `demanded` (a demand load merged into it) |
| cache line | `pfbit`: prefetched and not yet touched by a demand load |
| memory request | `mem_req_pf` bit; the memory model accounts demand-read, prefetch-read and write bytes separately |
| counters | `mem_rd_dem` vs `mem_rd_pf`; `pf_cand`, `pf_filt`, `pf_drop`, `pf_useful`, `pf_late`, `pf_useless`, `pollution` |
| status | prefetch read errors never set `ERR_MEM_RD` and never reach a core |

## 3. Metric definitions (used in `results/RESULTS.md`)

| Metric | Definition |
|---|---|
| issued | prefetch line reads sent to memory (`mem_rd_pf`) |
| useful (timely) | first demand **load hit** on a prefetched line (`pf_useful`) |
| late | demand load merged into an in-flight prefetch MSHR (`pf_late`) |
| accuracy | (useful + late) / issued |
| coverage | 1 − demand line reads with prefetching / demand line reads without (same trace, same seed) |
| late fraction | late / (useful + late) |
| useless | prefetched lines evicted or invalidated before any demand use |
| pollution | demand misses on a line that a prefetch fill evicted, detected by a 64-entry tagged filter of prefetch victims (can under-count). The Python model also gives an order-exact count under ideal timing. |
| extra traffic | total memory bytes with prefetching / without − 1 |

**Hit rate is reported but never used as evidence of improvement.** The verdict
in `results/RESULTS.md` requires the run to be faster in every seed with a
geometric-mean speedup of at least 2 %, within traffic and tail-latency limits;
a hit-rate gain without a runtime gain is flagged as a *hit-rate trap*.

## 4. What the experiments showed (details in `results/RESULTS.md`)

* **Unit-stride streams**: ≈ 1.46× faster at the default point, ≈ 99 % accuracy,
  < 1 % extra traffic; the benefit grows with memory latency (≈ 1.18× at 50 cycles,
  ≈ 2.6× at 400).
* **Large-stride and random** traffic keeps all MSHRs busy with demand misses,
  so the MSHR reserve keeps the prefetcher out (stride: ≈ 24 k candidates dropped
  per run, < 0.1 % effect) even though an ideal, perfectly timely prefetcher would
  turn 75 % of those misses into hits. This is the conservative rule doing its job,
  and it leaves performance on the table.
* **Mixed** (stream + table + gather + stores): the few prefetches that pass the
  reserve each hold an MSHR in an MSHR-bound workload; runtime is ≈ 1–2 % *worse*
  in every seed while the hit rate *rises* — the hit-rate trap. An isolation run in
  which candidates flow through the pipeline but may never allocate shows zero
  cost, which pins the loss on MSHR occupancy, not on pipeline slots.

Candidate next steps (not implemented): accuracy- or occupancy-based throttling,
prefetching into a separate buffer instead of MSHRs, insertion at low LRU
priority, and a set-associative training table.
