# GPU cache subsystem — specification

This document specifies the behaviour of the two RTL blocks in `rtl/`:

* **`gc_cache`** — a configurable, non-blocking, write-through L1-style data
  cache for several GPU load/store ports, with an optional stride prefetcher;
* **`gc_uncached`** — the uncached baseline with the *same external interface*.

Everything here is implemented and verified (see `docs/VERIFICATION.md`)
unless it is listed under *Out of scope* or *Known limitations*.

---

## 1. Scope

| In scope | Out of scope (not implemented) |
|---|---|
| One cache instance shared by `NUM_PORTS` core ports | **Host/device coherence** and any coherence between several cache instances (no snooping, no directory, no invalidation messages). Software must use `FLUSH`/`INVAL` at synchronization points. |
| 32-bit loads, 32-bit stores with byte strobes | Sub-word loads, atomics/RMW, gathers wider than one word, warp-level coalescing (each lane access is one request) |
| Write-through, no-write-allocate | Write-back, write-allocate, dirty-line management |
| Non-blocking misses (MSHRs), secondary-miss merging | Virtual memory / TLB, permissions, MMIO side effects |
| FENCE / FLUSH / INVALIDATE (global) | Per-line or per-address-range flush/invalidate |
| Error reporting for malformed requests and memory errors | ECC/parity on the tag and data arrays |
| Optional conservative stride prefetcher | Other prefetchers, prefetch throttling by feedback |

---

## 2. Interfaces

All buses for several ports are **flattened**: port *p* uses slice
`[p*W +: W]` of each bus (the RTL avoids packed multi-dimensional arrays so
that the Yosys 0.33 front end can read it).

### 2.1 Core ports (one per port *p*)

| Signal | Dir | Width | Meaning |
|---|---|---|---|
| `req_valid` / `req_ready` | in / out | 1 | valid/ready handshake; `req_valid` must stay high and the payload stable until accepted |
| `req_op` | in | 2 | `0` LOAD, `1` STORE, `2`/`3` reserved → error response |
| `req_addr` | in | 32 | byte address; must be 4-byte aligned (otherwise error response) |
| `req_wdata`, `req_wstrb` | in | 32, 4 | store data and byte strobes (ignored for loads) |
| `req_tag` | in | `TAG_W` | opaque; returned unchanged in the response. The requester must not reuse a tag that is still outstanding on the same port |
| `req_pc` | in | `PC_W` | instruction id hint; only used to train the prefetcher |
| `rsp_valid` / `rsp_ready` | out / in | 1 | response handshake (per port) |
| `rsp_tag`, `rsp_rdata`, `rsp_err`, `rsp_is_store` | out | — | tag of the request, load data (0 on error), error flag, response kind |

Every accepted request receives **exactly one** response on the port it came
from. Responses may return **out of order** (match them by tag). A store's
response is an *acknowledgement that the store is ordered* (see §4.3), not that
memory has been updated.

The requester must eventually accept responses (`rsp_ready`); while a port
refuses responses, that port alone stalls (other ports are isolated, §4.6), but
a control operation cannot complete (§4.8).

### 2.2 Control

| Signal | Dir | Meaning |
|---|---|---|
| `ctrl_valid` / `ctrl_ready` / `ctrl_op[1:0]` | in/out/in | `0` FENCE, `1` FLUSH, `2` INVAL, `3` reserved |
| `ctrl_done` | out | one-cycle completion pulse |
| `ctrl_err` | out | valid with `ctrl_done`: reserved op, or a memory **write** error was seen since the previous completion |
| `pf_enable`, `pf_dist[3:0]` | in | prefetcher run-time enable and distance (strides ahead, 0 is treated as 1). Ignored by `gc_uncached` and when `PF_ENABLE=0` |

### 2.3 Memory side (one request and one response channel)

| Signal | Meaning |
|---|---|
| `mem_req_valid/ready` | handshake |
| `mem_req_we` | 1 = write, 0 = read |
| `mem_req_addr` | line-aligned byte address |
| `mem_req_wdata[LINE_BITS]`, `mem_req_be[LINE_BYTES]` | write data (the store word replicated) and byte enables; for reads `be` marks the bytes needed (cache: whole line; uncached: one word) |
| `mem_req_id` | read: MSHR / outstanding-table index; write: 0 |
| `mem_req_pf` | 1 = prefetch read (accounting only; memory may treat it identically) |
| `mem_rsp_valid` / `mem_rsp_ready` | the DUT always accepts (`mem_rsp_ready = 1`) |
| `mem_rsp_we`, `mem_rsp_id`, `mem_rsp_rdata`, `mem_rsp_err` | write ack or read data (any order between ids) |

**Memory ordering contract.** The memory side must perform requests in the
order they are *accepted* on `mem_req` with respect to the same address
(an accept-ordered memory). Read data may return in any order. The cache relies
on this to keep write-through stores and later miss reads ordered.

### 2.4 Status and debug

| Signal | Meaning |
|---|---|
| `err_status[7:0]` | sticky error bits (§4.10), cleared only by reset |
| `perf_count[N_EV*32]` | 32-bit wrapping event counters (`gc_pkg::EV_*`), cleared by reset |
| `busy` | something accepted is still outstanding (inverse of "quiesced") |
| `dbg_commit_*` | one record per committed core request in commit order (used by the testbench oracle; can be left unconnected) |

---

## 3. Parameters (`gc_cache`)

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `NUM_PORTS` | 4 | ≥1 | core ports |
| `LINE_BYTES` | 64 | power of 2, ≥8 | **line size** |
| `NUM_SETS` | 64 | power of 2, ≥2 | sets |
| `NUM_WAYS` | 4 | power of 2, ≥1 | **associativity** (1 = direct mapped) |
| `REPL` | 0 | 0/1/2 | **replacement**: 0 true LRU, 1 FIFO, 2 pseudo-random |
| `N_MSHR` | 16 | ≥1 | **miss tracking** entries (also bounds outstanding line reads) |
| `N_TGT` | 8 | ≥1 | merged load targets per MSHR (**request merging** window) |
| `IN_DEPTH` | 2 | ≥1 | per-port input FIFO |
| `RSP_DEPTH` | 16 | ≥1 | per-port response FIFO = max undelivered responses per port |
| `MEMQ_DEPTH` | 4 | ≥1 | in-order memory request queue |
| `TAG_W`, `PC_W` | 8, 8 | | request tag / pc widths |
| `WR_OUT_MAX` | 63 | | posted writes in flight before stores stall |
| `PF_ENABLE` | 0 | 0/1 | build the stride prefetcher |
| `PF_ENTRIES` | 16 | power of 2 ≥2 | prefetcher table entries |
| `PF_CONF_TH` | 2 | 0..3 | confidence needed to issue |
| `PF_MSHR_RSV` | 2 | | MSHRs a prefetch may never take (clamped to `N_MSHR-1`) |
| `PF_PAGE_SHIFT` | 12 | > log2(LINE_BYTES) | prefetches never cross this boundary |
| `PF_QDEPTH` | 2 | ≥1 | prefetch candidate queue |
| `POLL_ENTRIES` | 64 | power of 2 | pollution-filter entries (metric only) |

Capacity = `NUM_SETS × NUM_WAYS × LINE_BYTES` (default 16 KiB).
Address split: `tag = addr[31 : log2(LINE_BYTES)+log2(NUM_SETS)]`,
`set = addr[.. : log2(LINE_BYTES)]`, `word = addr[log2(LINE_BYTES)-1 : 2]`.

---

## 4. Cache policy

### 4.1 Organisation

Per way: a tag RAM (`NUM_SETS × tag`) and a data RAM
(`NUM_SETS × LINE_BITS`, byte-lane write enables), both modelled as
synchronous 1-read/1-write SRAMs (`gc_sram_1r1w`). Valid bits, the
"prefetched-unused" bits and replacement state live in flip-flops so that
reset and invalidate-all take one cycle.

### 4.2 Associativity and replacement

* Lookup compares all ways in parallel; at most one way may hit (asserted).
* **Victim choice on a fill:** the lowest-numbered **invalid** way if any;
  otherwise by `REPL`:
  * **LRU** — per-way age counters (`log2(NUM_WAYS)` bits, 0 = most recent).
    A *touch* of way *w* sets its age to 0 and increments every age smaller than
    the old age of *w*; the victim is the way with age `NUM_WAYS-1`.
    Touches happen on load hits, store hits and fills (prefetch fills too —
    prefetched lines are inserted as most-recently-used).
  * **FIFO** — a per-set pointer, advanced only when a *valid* line is replaced.
  * **RANDOM** — a free-running 16-bit LFSR (low bits).
* Eviction is silent (write-through: no dirty data).
* The Python reference model (`python/cache_model.py`) implements the same
  rules; LRU and FIFO are cross-checked counter-for-counter against the RTL.

### 4.3 Write policy — write-through, no-write-allocate

* **Store hit:** the bytes selected by `wstrb` are written into the line (in
  the commit cycle) **and** a write of the same bytes is queued to memory.
* **Store miss:** no line is allocated; the write goes to memory only.
* **Posted stores:** the store's response is produced at commit; the store is
  then *ordered* — every later-committed load on any port observes it — but not
  yet *performed* in memory. Memory write errors therefore cannot be returned
  per store; they set `err_status.MEM_WR` and are reported by `ctrl_err` at the
  next FENCE/FLUSH/INVAL completion.
* **Store to a line with a pending fill** (an MSHR in PEND or FILLED for the
  same line, including a prefetch) is **replayed** until that fill has been
  installed. Without this rule the fill, sampled by memory before the write,
  would overwrite the newer data.
* All memory requests (miss reads and write-throughs) leave through one
  **in-order** queue, so a read issued after a write to the same line is
  accepted by memory after it.

### 4.4 Miss tracking (MSHRs)

Each MSHR holds: state, line address, a full-line fill buffer, error flag,
`is_prefetch` and `demanded` flags, up to `N_TGT` targets `{port, tag, word}`
and a drain pointer.

```
FREE --(demand miss / prefetch allocates)--> PEND --(memory data)--> FILLED
FILLED --(fill processed in the pipeline)--> DRAIN   (no targets -> FREE)
DRAIN --(last target returned)--> FREE
```

* A **primary miss** allocates the lowest free MSHR and queues one line read.
  If no MSHR is free, or the memory queue is full, the request is replayed.
* At most one MSHR per line can be in PEND/FILLED (asserted).
* Memory data is written into the MSHR fill buffer, so the memory response
  channel is never back-pressured.
* The fill is installed by a pipeline operation that has priority over core
  requests; error fills are *not* installed.
* Lines are never reserved at miss time; the victim is chosen at install
  time, so an outstanding miss never blocks a way.

### 4.5 Request merging

* A load that misses but finds an MSHR for its line in **PEND or FILLED** is
  a **secondary miss**: it is appended as a target (no memory traffic).
  Merging stops once the line is installed (later loads simply hit).
* If the MSHR's `N_TGT` slots are full the load is replayed (and the port
  sleeps until an MSHR changes state).
* Merging into a prefetch MSHR is allowed; it marks the MSHR `demanded` and is
  counted as a **late prefetch**.
* Two requests to the same line in the same cycle are serialized by the
  arbiter: the first allocates, the second merges one cycle later.

### 4.6 Response routing

* Each port has its own response FIFO (`RSP_DEPTH`). Hits, store acks and
  error responses are written by the pipeline; merged targets are written by
  the **drain unit**, one target per cycle, from the MSHR fill buffer, using
  the `{port, tag, word}` recorded at merge time. Drain has priority over the
  pipeline for a FIFO's single write port.
* **Response-slot reservation (port isolation).** Every request that will
  produce a response may commit only if
  `responses_in_fifo[p] + undrained_targets[p] < RSP_DEPTH`. Undrained miss
  targets therefore always have a FIFO slot, so the drain unit can never block,
  MSHRs are always released, and a port that stops accepting responses cannot
  stall the other ports (tested by `evict_stall`; removing the rule is caught by
  the mutation test). Consequence: at most `RSP_DEPTH` responses per port can be
  outstanding.

### 4.7 Pipeline, replay and hazards

```
S0: choose source  (fill install > core ports, round-robin > prefetch candidate)
    read tag + data RAMs of the selected set
S1: tag compare, MSHR CAM, decide COMMIT or REPLAY (never stalls in place)
```

* A core request stays at the head of its port's input FIFO until it
  **commits**; a replayed request is simply re-arbitrated, so per-port program
  order is preserved by construction. A port has at most one request in S1
  (per-port issue rate ≤ 1 request / 2 cycles; aggregate ≤ 1 request / cycle).
* **Replay sleep:** a port whose head replayed for an MSHR reason (no free
  MSHR, target slots full, store to a pending line) is not re-arbitrated until
  some MSHR changes state.
* **Read-after-write bubble:** if S1 may write the arrays (a fill or a store),
  S0 does not issue another access to the same set in that cycle.
* The **commit** of a core request is its serialization point. Load value =
  the most recent committed store to that address (or memory's value), which
  the testbench checks for every load.

### 4.8 Flush and invalidate

| op | effect |
|---|---|
| `FLUSH` (1) | FENCE, then invalidate every line. Under write-through there is no dirty data, so the *clean* step is empty and FLUSH ≡ INVAL; the opcode is kept for a future write-back variant. |
| `INVAL` (2) | FENCE, then invalidate every line, clear prefetched-line bits (counted as useless if unused), reset replacement state, clear the prefetcher table and the pollution filter. |

Invalidation is applied only after **all** in-flight fills (demand and
prefetch) have been installed or dropped, so no line fetched before the
operation can appear in the cache afterwards.

### 4.9 Fence

`FENCE` (and the drain phase of FLUSH/INVAL):

1. Requests accepted **in the same cycle** as the control op, or earlier, are
   *before* the fence; all port `req_ready` go low from the next cycle until
   `ctrl_done`, and the prefetcher stops issuing (its queue is flushed).
2. `ctrl_done` is pulsed when everything accepted before it has been
   **performed**: every request committed, every miss filled and its targets
   placed in response FIFOs, the memory queue empty and every posted write
   acknowledged by memory, all MSHRs free (prefetches included).
3. Responses may still be sitting in response FIFOs; their values are already
   bound. A fence does not wait for the requester to consume them.

At completion, memory holds exactly the effect of every store committed before
the fence (checked by the testbench at every control completion).

### 4.10 Error handling

| Condition | Behaviour | Status bit |
|---|---|---|
| `req_addr[1:0] ≠ 0` | error response (`rsp_err=1`, data 0), no memory access | `MISALIGNED` |
| `req_op` 2 or 3 | error response | `BADOP` |
| memory read error, demand | line **not installed**; every merged target receives an error response; a later access retries memory | `MEM_RD` (set when an error response is delivered) |
| memory read error, prefetch only | silently dropped, not installed, no status bit (counted in `EV_MEM_ERR`, `EV_FILL_ERR`) | — |
| memory write error | write dropped by memory; reported by `ctrl_err` at the next control completion | `MEM_WR` |
| memory response for an id that is not PEND, or a write ack with none outstanding | ignored | `SPURIOUS` |
| `ctrl_op = 3` | `ctrl_done` next cycle with `ctrl_err=1`, no drain | `CTRL_BADOP` |

### 4.11 Reset

* Synchronous, active-high `rst`. While asserted: `req_ready=0`,
  `ctrl_ready=0`; after the first reset edge all FIFOs are empty, all MSHRs
  free, all lines invalid, replacement state, prefetcher, error status and
  counters cleared. RAM contents are not reset (valid bits gate them).
* Reset abandons all in-flight work. **The memory side must be reset at the
  same time** (or drained first): a read response from before the reset whose
  id is re-allocated afterwards cannot be distinguished from a new one (there
  is no epoch tag). Responses for ids that are not PEND are dropped as spurious.
* Writes accepted by memory before reset remain in memory; writes still in the
  cache's queue are lost.

### 4.12 Ordering guarantees (single cache instance)

* Per port: requests commit in program order (same-address RAW/WAW/WAR within
  a port are respected); responses may be reordered.
* Across ports: all ports observe one total order of committed loads and
  stores (the commit order); the cache behaves as a linearizable memory at the
  commit point.
* Memory reflects stores only after they are performed; use FENCE to wait.

---

## 5. Uncached baseline (`gc_uncached`) differences

Same ports, control, error handling, reset and fence semantics. Each well-formed
load becomes a one-word memory read (sector-granular traffic), each store a
posted write; `N_OT` (default 16) loads may be outstanding, routed back by an
outstanding table with the same response-slot reservation. No merging, no
caching; FLUSH and INVAL reduce to FENCE. The commit point is the cycle a request
enters the in-order memory queue.

---

## 6. Known limitations

* Per-port issue rate is at most one request every two cycles (one request per
  port in S1); the aggregate is one per cycle.
* No starvation-freedom proof under persistent MSHR contention (round-robin
  arbitration makes starvation unlikely but not impossible).
* A control operation cannot complete while a port that has accepted requests
  refuses responses.
* Stale memory responses across a reset are only safe if memory is reset too.
* The pollution counter uses a 64-entry tagged filter: it can under-count
  (overwrites), never over-count.
* The prefetcher table is direct-mapped; badly aliasing `{port, pc}` keys
  thrash (the rotate-fold index was chosen because a plain XOR fold aliased
  the synthetic workloads' pcs).
