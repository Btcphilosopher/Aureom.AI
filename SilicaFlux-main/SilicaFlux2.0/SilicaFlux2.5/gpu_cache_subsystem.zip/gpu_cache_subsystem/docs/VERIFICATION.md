# Verification

The uncached baseline was verified first with the same testbench, then the cache
(prefetcher not built), then the cache with the prefetcher. All three are
re-verified by `make test`.

## 1. Strategy

### 1.1 Commit-order oracle (data, routing, exactly-once)

`tb/tb_top.sv` records every request handshake per `(port, tag)`. The DUT's
`dbg_commit_*` stream gives the serialization order. At each commit the
scoreboard:

* checks the commit matches an accepted, not-yet-committed request with
  identical fields (op, address, data, strobes) — catches mis-routing inside
  the DUT;
* checks per-port commits happen in acceptance order (program order);
* applies stores to a reference memory and computes the expected value / error
  of every load from it.

Every response must then match its `(port, tag)` expectation: data, error
flag, response kind, and it must be the only response. This checks the
cache's linearizability at the commit point, response routing and
exactly-once delivery for **every** request of every test, including the
constrained-random ones.

### 1.2 Control-operation checks (fence / flush semantics)

At every `ctrl_done` the testbench checks that every request accepted before
the control op has committed, that the memory model has nothing in flight,
that the DUT is idle, and that **memory content equals the reference memory**
(every committed store has been performed, nothing else has). It also checks
that no request is accepted while a control operation drains.

### 1.3 RTL invariants (simulation-only assertions in the RTL)

Fill never installs a line that is already present; at most one hit way; at
most one in-flight MSHR per line; never commit and replay together; single
writer per response FIFO; no MSHR target overflow; drain never finds a full
response FIFO (reservation invariant); FIFO overflow/underflow; SRAM
read/write collision.

### 1.4 Exact model cross-check (policy, not just data)

The functional oracle cannot see *performance* bugs (a wrong victim is still
functionally correct). `python/model_crosscheck.py` runs the RTL with one port
and one request outstanding (trace order = processing order) and compares
loads, hits, misses, stores, store hits, fills and evictions with the untimed
Python model — they must be equal, for 5 geometries (DM, 2/4/8-way, LRU and
FIFO, 16–128 B lines) × 3 workloads × 2 seeds. Result:
`results/verification/model_crosscheck.md` (all exact).

### 1.5 Randomized initial state

All builds use `--x-assign unique --x-initial unique` and run with
`+verilator+rand+reset+2`, so every flop and RAM bit that reset does not
initialise starts random (different per seed). Reset logic that forgets
something shows up as a failure (see the `mshr_not_reset` mutation).

## 2. Tests

| Test | Requested scenario | What it does | Key checks (beyond the oracle) |
|---|---|---|---|
| `basic` | — | miss, hit, store hit, partial store, store miss (no allocate), load after write-around | exact hit/miss/store-hit counts |
| `simul` | **simultaneous misses** | every port misses on a different line in the *same cycle*; then 2×ports lines in one set (more than the ways) and re-read | one memory read per line; misses really overlapped in memory (peak outstanding ≥ min(ports, MSHRs)); evictions |
| `sameline` | **same-line requests** | every port loads different words of one line in the same cycle, 4 loads each; then a store to a line with a pending miss | exactly one memory read; merges; target-full replays; store-hazard replay; stored value visible to later loads |
| `mshrfull` | MSHR exhaustion | 8 distinct misses per port | MSHR-full replays; peak outstanding reads equals the MSHR count |
| `evict_stall` | **eviction during stalls** | port 0 stops accepting responses while it has hits and a pending miss on set S; the other ports miss into set S (evicting port 0's lines) and store into them | other ports finish while port 0 is stalled (isolation); replays and evictions occurred; after release all data correct |
| `flush_pending` | **flush with pending work** | warm lines, issue a burst of misses, hits and stores on all ports, issue FENCE / FLUSH / INVAL 6 cycles later | the op really overlapped pending work; completion only when everything before it is performed; memory == reference; no acceptance while draining; after FLUSH/INVAL no stale hit, after FENCE lines retained |
| `fence` | fence | stores on all ports immediately followed by FENCE, with loads presented during the fence | memory == reference at completion; loads held back until completion |
| `errors` | error handling | misaligned and reserved-op requests; demand loads (merged) into an error region; store into it; reserved ctrl op; prefetch stream running into the error region; injected spurious responses | error responses, status bits, errored lines not cached, write error reported by the *next* fence only, prefetch errors silent, spurious responses ignored, normal traffic afterwards |
| `prefetch` | prefetcher | unit-stride stream; random traffic; stores racing in-flight prefetches + INVAL; a prefetch whose target already has a demand miss in flight; run-time disable | accuracy ≥ 80 % on the stream; ≤ 20 prefetches for 1000 random loads; in-flight targets filtered; nothing issued when disabled |
| `reset` | **reset recovery** | random traffic with misses, stores and sometimes a control op in flight, reset asserted at a random cycle for a random length, ×(iters+2) | ready low during reset; immediately after reset: no responses, no memory requests, not busy, status and all counters zero; a previously hot line misses; then a checked random phase and a fence |
| `random` | stress | per iteration random MLP, memory latency/jitter/bandwidth/back-pressure, response back-pressure, error region, prefetch on/off and distance; traffic concentrated on a few sets with more lines than ways; ~4 % malformed requests; random FENCE/FLUSH/INVAL/reserved ops interleaved | everything in §1 |

## 3. Configurations (`python/run_tests.py`, 4 seeds each)

| Config | Why |
|---|---|
| `uncached`, `uncached_tiny` (3 ports, 3 OT, 1–2 deep queues) | baseline, non-power-of-2 ports, minimal buffering |
| `cache_base` (experiment config, no prefetcher) | the validated baseline cache |
| `cache_pf` (experiment config with prefetcher) | the evaluated design |
| `cache_m8` (8 MSHR × 4 targets) | resource pressure |
| `cache_tiny` (4 sets × 2 ways × 16 B, 2 MSHR × 1 target, 1-deep queues) | maximal conflicts, replays, back-pressure |
| `cache_dm` (direct mapped, 32 B) | associativity 1 |
| `cache_fifo8` (8-way FIFO, 128 B, 16 MSHR × 8) | wide lines, FIFO policy |
| `cache_rand3p` (3 ports, 2-way RANDOM, 5 MSHR) | non-power-of-2 ports and MSHRs, random replacement |
| `cache_1port` | single requester |

Results: `results/verification/summary.md`.

## 4. Testbench sensitivity (mutation test)

`python/mutation_test.py` injects 13 one-line bugs (store-hazard check
removed, read-after-write bubble removed, wrong drained word, corrupted merge
tag, fence not waiting for write acks, invalidate not clearing, no merge after
data return, MSHRs not reset, response reservation removed, store hit not
written through, prefetch not filtered against in-flight lines, uncached
mis-routing, LRU evicting the MRU way). Every mutation is detected — 12 by the
functional testbench, the performance-only LRU bug by the model cross-check.
Results: `results/verification/mutations.md`.

The prefetch-filter mutation initially **survived**; that exposed a missing
scenario (prefetch whose target already has a *demand* miss in flight), which
was added to the `prefetch` test.

## 5. Bugs and issues found during development

| Found by | Issue | Fix |
|---|---|---|
| `evict_stall` | a port refusing responses could pin shared MSHRs in DRAIN and block every other port | response-slot reservation (§4.6 of SPEC) |
| first performance runs | ports whose head replayed on a full MSHR re-arbitrated every other cycle (hundreds of thousands of wasted pipeline slots), starving the lowest-priority prefetch queue | replay sleep until an MSHR changes state |
| first performance runs | prefetcher table index (plain XOR fold) aliased the workloads' pcs (0x11, 0x44, …) onto one entry | rotate-fold index |
| workload analysis | per-port arrays exactly 16 MiB apart alias onto one set (all streams + their prefetches in the same set) | default workloads skewed by 65 lines; the aliased layout kept as `mixed_aliased` |
| simulator | Verilator 5.020: function calls in `while` conditions of timed tasks evaluated stale; arrays of queues with non-power-of-2 size corrupt data; some scalars shared between a timed thread and an `always` block not updated | testbench workarounds (documented in comments) |

## 6. Limits of this verification

* Simulation only: no formal proof (no SymbiYosys in the environment), no
  4-state (X-propagation) simulation, no gate-level simulation.
* No structural coverage tool was used; coverage is argued by scenario
  (table above), counters asserted in tests, and mutation results.
* The memory model is accept-ordered; a memory system that reorders same-address
  requests would violate the interface contract and is not tested.
* Timing (Fmax) is not analysed; the S1 path (tag compare → MSHR CAM →
  commit/replay decision → array write enables) is a single cycle.
