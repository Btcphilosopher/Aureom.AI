#!/usr/bin/env python3
"""Mutation test: inject realistic bugs into the RTL and confirm the
self-checking testbench detects each one.  A mutation is "caught" when the
simulation reports TB_RESULT: FAIL, an RTL assertion fires, or the run
deadlocks/times out.  Writes results/verification/mutations.md.

Performance-only mutations (e.g. a broken replacement policy) are expected
to pass the functional testbench; they are caught by the Python reference
model cross-check (python/model_crosscheck.py), which is reported there.
"""
import concurrent.futures as cf
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import simlib  # noqa: E402

CACHE = dict(DUT_KIND=1, PF_ENABLE=1)
UNC = dict(DUT_KIND=0)

# (name, file, old, new, params, what it models)
MUTATIONS = [
    ("store_hazard_removed", "gc_cache.sv",
     "            if (match_any) begin\n              p_replay = 1'b1;  rpl_sthaz = 1'b1;",
     "            if (1'b0) begin\n              p_replay = 1'b1;  rpl_sthaz = 1'b1;",
     CACHE, "store to a line with a pending fill is not held back"),
    ("s0_bubble_removed", "gc_cache.sv",
     "s1_wr_haz = s1_valid && (", "s1_wr_haz = 1'b0 && (",
     CACHE, "no read-after-write bubble between S1 array write and S0 read"),
    ("drain_wrong_word", "gc_cache.sv",
     "ms_data[drn_idx][drn_off*32 +: 32]", "ms_data[drn_idx][(drn_off + 1'b1)*32 +: 32]",
     CACHE, "merged target receives the neighbouring word"),
    ("merge_tag_corrupt", "gc_cache.sv",
     "ms_tgt[32'(match_idx)*N_TGT + 32'(ms_ntgt[match_idx])] <= {s1_port, h_tag[s1_port], s1_woff};",
     "ms_tgt[32'(match_idx)*N_TGT + 32'(ms_ntgt[match_idx])] <= {s1_port, h_tag[s1_port] ^ 8'h01, s1_woff};",
     CACHE, "secondary-miss response carries the wrong tag (mis-routing)"),
    ("fence_ignores_write_acks", "gc_cache.sv",
     "mq_empty && (wr_out == '0);", "mq_empty;",
     CACHE, "fence completes before posted writes are acknowledged"),
    ("inval_keeps_lines", "gc_cache.sv",
     "    if (rst || act_inval) begin\n      for (int s = 0; s < NUM_SETS; s++) begin\n        valid_q[s] <= '0;",
     "    if (rst) begin\n      for (int s = 0; s < NUM_SETS; s++) begin\n        valid_q[s] <= '0;",
     CACHE, "INVAL/FLUSH do not clear valid bits"),
    ("no_merge_after_data", "gc_cache.sv",
     "((ms_state[m] == MS_PEND) || (ms_state[m] == MS_FILLED))", "(ms_state[m] == MS_PEND)",
     CACHE, "line with data back but not installed is not matched"),
    ("mshr_not_reset", "gc_cache.sv",
     "      for (int m = 0; m < N_MSHR; m++) ms_state[m] <= MS_FREE;", "      ;",
     CACHE, "reset does not free the MSHR file"),
    ("no_response_reservation", "gc_cache.sv",
     "assign rsv_ok[p] = ({1'b0, rsp_cnt[p]} + {1'b0, pend_tgt[p]}) < (RCNT_W + 1)'(RSP_DEPTH);",
     "assign rsv_ok[p] = 1'b1;",
     CACHE, "a stalled port can pin shared MSHRs (cross-port blocking)"),
    ("store_hit_not_written_through", "gc_cache.sv",
     "              p_commit    = 1'b1;  st_c = 1'b1;\n              mq_push     = 1'b1;",
     "              p_commit    = 1'b1;  st_c = 1'b1;\n              mq_push     = !hit;",
     CACHE, "write-through dropped for store hits"),
    ("prefetch_not_filtered", "gc_cache.sv",
     "          if (hit || match_any) begin\n            pf_filt_c = 1'b1;",
     "          if (hit) begin\n            pf_filt_c = 1'b1;",
     CACHE, "prefetch allocates a second MSHR for an in-flight line"),
    ("uncached_misroute", "gc_uncached.sv",
     "        ot_port[ot_free_idx]  <= sel;", "        ot_port[ot_free_idx]  <= sel + 1'b1;",
     UNC, "uncached load response routed to the wrong port"),
    ("lru_evicts_mru", "gc_cache.sv",
     "== WAY_W'(NUM_WAYS - 1)) victim = WAY_W'(w);", "== WAY_W'(0)) victim = WAY_W'(w);",
     CACHE, "PERFORMANCE bug: LRU evicts the MRU way (functionally correct)"),
]


def run_one(m):
    name, fn, old, new, params, desc = m
    root = os.path.join(simlib.BUILD, "mut", name)
    if os.path.exists(root):
        shutil.rmtree(root)
    for d in ("rtl", "tb", "sim"):
        shutil.copytree(os.path.join(simlib.ROOT, d), os.path.join(root, d))
    path = os.path.join(root, "rtl", fn)
    src = open(path).read()
    assert src.count(old) == 1, f"{name}: pattern found {src.count(old)} times"
    open(path, "w").write(src.replace(old, new))
    out = os.path.join(root, "bld")
    args = [os.path.join(root, "sim", "build.sh"), out] + [f"-G{k}={v}" for k, v in params.items()]
    subprocess.run(args, check=True, env=dict(os.environ, VERILATOR_JOBS="2"))
    verdicts = []
    for seed in (1, 2):
        try:
            ok, log = simlib.run(os.path.join(out, "sim"), ["test=all", "rand_n=300", "iters=3"],
                                 seed=seed, timeout=600)
        except subprocess.TimeoutExpired:
            ok, log = False, "TIMEOUT"
        first = next((l for l in log.splitlines() if "ERROR" in l or "%Error" in l), "")
        verdicts.append((ok, first.strip()[:110]))
    caught = any(not ok for ok, _ in verdicts)
    model = "-"
    if desc.startswith("PERFORMANCE"):
        from model_crosscheck import crosscheck
        rows = crosscheck(os.path.join(out, "sim"), 64, 4, 64, "lru", 4, n=1500, seeds=(1,))
        model = "**yes**" if not all(r[4] for r in rows) else "no"
    return name, desc, caught, next((f for ok, f in verdicts if not ok), ""), model


def main():
    jobs = int(os.environ.get("JOBS", os.cpu_count() or 2))
    with cf.ThreadPoolExecutor(max_workers=max(1, jobs // 2)) as ex:
        res = list(ex.map(run_one, MUTATIONS))
    lines = ["# Mutation test (testbench sensitivity)", "",
             "Generated by `python3 python/mutation_test.py`. Each mutation is a one-line "
             "RTL change; the full directed + random suite is run with 2 seeds.", "",
             "| mutation | injected bug | detected by functional TB | detected by model cross-check | first failure |",
             "|---|---|---|---|---|"]
    for name, desc, caught, first, model in res:
        lines.append(f"| `{name}` | {desc} | {'**yes**' if caught else 'no'} | {model} | "
                     f"{first.replace('|', '/') or '-'} |")
    lines += ["", "`lru_evicts_mru` is functionally correct by design (only hit rate changes), so "
              "the data-checking testbench cannot see it; the exact counter cross-check against "
              "the Python model (`python/model_crosscheck.py`) is what detects it."]
    out = os.path.join(simlib.ROOT, "results", "verification", "mutations.md")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))
    missed = [n for n, d, c, _, m in res
              if not c and not (d.startswith("PERFORMANCE") and m == "**yes**")]
    print("undetected mutations:", missed or "none")
    sys.exit(1 if missed else 0)


if __name__ == "__main__":
    main()
