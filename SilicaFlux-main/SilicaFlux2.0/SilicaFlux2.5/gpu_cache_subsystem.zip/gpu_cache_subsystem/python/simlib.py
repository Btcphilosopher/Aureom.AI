"""Shared helpers: build Verilator configurations and run the testbench."""
import hashlib
import os
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
SRC_DIRS = ("rtl", "tb", "sim")


def _src_hash(params):
    h = hashlib.sha1()
    for d in SRC_DIRS:
        for fn in sorted(os.listdir(os.path.join(ROOT, d))):
            if fn.endswith((".sv", ".sh")):
                with open(os.path.join(ROOT, d, fn), "rb") as f:
                    h.update(fn.encode())
                    h.update(f.read())
    h.update(repr(sorted(params.items())).encode())
    return h.hexdigest()[:12]


def build(name, params):
    """Build (or reuse) a simulator for a parameter set; returns the exe path."""
    os.makedirs(BUILD, exist_ok=True)
    out = os.path.join(BUILD, name)
    stamp = os.path.join(out, ".stamp")
    key = _src_hash(params)
    exe = os.path.join(out, "sim")
    if os.path.exists(exe) and os.path.exists(stamp) and open(stamp).read() == key:
        return exe
    args = [os.path.join(ROOT, "sim", "build.sh"), out] + [f"-G{k}={v}" for k, v in params.items()]
    subprocess.run(args, check=True)
    with open(stamp, "w") as f:
        f.write(key)
    return exe


def run(exe, plusargs, seed=1, timeout=1800, log=None):
    """Run a simulator; returns (passed, stdout)."""
    cmd = [exe, f"+verilator+seed+{seed}", "+verilator+rand+reset+2"] + [f"+{a}" for a in plusargs]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    out = p.stdout + p.stderr
    if log:
        with open(log, "w") as f:
            f.write(" ".join(cmd) + "\n" + out)
    passed = (p.returncode == 0) and ("TB_RESULT: PASS" in out)
    return passed, out
