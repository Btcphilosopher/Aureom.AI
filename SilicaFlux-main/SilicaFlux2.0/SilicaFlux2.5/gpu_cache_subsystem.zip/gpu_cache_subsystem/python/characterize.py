#!/usr/bin/env python3
"""Workload characterisation with the untimed reference model (no RTL).

For each workload (seed 1, same traces as the experiments) on the 16 KiB,
4-way, 64 B LRU geometry: footprint, model hit rate, 3C miss breakdown,
stride-prefetch potential under *ideal* timeliness, and an order-exact
pollution count (loads that hit without prefetching but miss with it).
The model feeds ports round-robin, an approximation of RTL arbitration;
the numbers characterise the workloads, they are not RTL results.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import simlib  # noqa: E402
from cache_model import CacheModel, StridePF, classify_3c, run_interleaved  # noqa: E402
from workloads import WORKLOADS, generate  # noqa: E402

SETS, WAYS, LINE = 64, 4, 64


def main():
    rows = []
    for wl in WORKLOADS:
        tr = generate(wl, 8000, 1)
        lines = {a >> 6 for t in tr for (_o, a, *_r) in t}
        loads = sum(1 for t in tr for r in t if r[0] == 0)
        stores = sum(1 for t in tr for r in t if r[0] == 1)
        base = CacheModel(SETS, WAYS, LINE, "lru")
        hb = run_interleaved(tr, base, record=True)
        comp, cap, conf = classify_3c([l for l, _ in hb], SETS * WAYS, [h for _, h in hb])
        pfm = CacheModel(SETS, WAYS, LINE, "lru", pf=StridePF(LINE, dist=4))
        hp = run_interleaved(tr, pfm, record=True)
        pollution = sum(1 for (_, a), (_, b) in zip(hb, hp) if a and not b)
        rows.append(dict(workload=wl, loads=loads, stores=stores, footprint_kib=len(lines) * LINE / 1024,
                         hit_rate=base.st["ld_hit"] / max(1, base.st["ld"]),
                         compulsory=comp, capacity=cap, conflict=conf,
                         ideal_pf_hit_rate=pfm.st["ld_hit"] / max(1, pfm.st["ld"]),
                         ideal_pf_issued=pfm.st["pf_issued"], ideal_pf_useful=pfm.st["pf_useful"],
                         ideal_pollution=pollution))
    hdr = list(rows[0])
    fmt = dict(footprint_kib="{:.0f}", hit_rate="{:.3f}", ideal_pf_hit_rate="{:.3f}")
    md = ["| " + " | ".join(hdr) + " |", "|" + "---|" * len(hdr)]
    for r in rows:
        md.append("| " + " | ".join(fmt.get(k, "{}").format(r[k]) for k in hdr) + " |")
    tab = os.path.join(simlib.ROOT, "results", "tables")
    os.makedirs(tab, exist_ok=True)
    with open(os.path.join(tab, "workload_characterization.md"), "w") as f:
        f.write("\n".join(md) + "\n")
    json.dump(rows, open(os.path.join(tab, "workload_characterization.json"), "w"), indent=1)
    print("\n".join(md))


if __name__ == "__main__":
    main()
