#!/usr/bin/env python3
"""Turn results/experiments/raw/*.json into CSV tables, figures and the data
section of results/RESULTS.md.

Metric definitions (all demand metrics exclude prefetches):
  runtime        cycles from first request accepted to last response
  hit rate       demand-load hits / committed demand loads   (merges are NOT hits)
  latency (e2e)  demand-load latency from the cycle the port first presents the
                 request to the response handshake: includes back-pressure
                 (input-FIFO full) time.  This is the primary latency metric.
  service lat.   request *accepted* -> response (excludes back-pressure)
  traffic        bytes moved by the memory model; every access is charged in
                 32-byte sectors (demand reads, prefetch reads, writes separately)
  accuracy       (timely + late useful prefetches) / prefetches issued
  coverage       1 - demand line reads(with pf) / demand line reads(without pf)
  late fraction  late useful / all useful (a demand hit the in-flight prefetch)
  useless        prefetched lines evicted/invalidated before any demand use
  pollution      demand misses on lines that a prefetch fill evicted
                 (RTL counter, 64-entry tagged filter: an estimate)
  extra traffic  total bytes(with pf) / total bytes(without pf) - 1
"""
import glob
import json
import math
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import simlib  # noqa: E402

RES = os.path.join(simlib.ROOT, "results")
FIG = os.path.join(RES, "figures")
TAB = os.path.join(RES, "tables")

# validated categorical slots (references: dataviz palette, light mode)
C_UNC, C_CACHE, C_PF = "#2a78d6", "#eb6834", "#1baf7a"
C_TR = {"demand read": "#eda100", "prefetch read": "#e87ba4", "write": "#008300"}
INK, INK2, MUTED, GRID, AXIS, SURF = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#fcfcfb"
CFG_COLOR = {"uncached": C_UNC, "cache": C_CACHE, "cache+pf": C_PF}
WL_ORDER = ["stream", "stride", "random", "reuse", "mixed", "mixed_aliased"]


def pct(hist, q):
    tot = sum(c for _, c in hist)
    if tot == 0:
        return float("nan")
    acc = 0
    for lat, c in hist:
        acc += c
        if acc >= q * tot:
            return lat
    return hist[-1][0]


def load():
    rows = []
    for fn in glob.glob(os.path.join(RES, "experiments", "raw", "*.json")):
        d = json.load(open(fn))
        p, m = d["perf"], d["mem"]
        tot = m["rd_dem_bytes"] + m["rd_pf_bytes"] + m["wr_bytes"]
        is_cache = d["config"]["dut"].strip() == "cache"
        r = dict(study=d["study"], build=d["build"], workload=d["workload"], seed=d["seed"],
                 label=d["label"], pf=d["run"].get("pf_en", 0), pf_dist=d["run"]["pf_dist"],
                 mem_lat=d["run"]["mem_lat"], mem_bw=d["run"]["mem_bw"],
                 line=d["config"]["line_bytes"], ways=d["config"]["ways"], sets=d["config"]["sets"],
                 repl=d["config"]["repl"], mshr=d["config"]["mshr"], tgt=d["config"]["tgt"],
                 cycles=d["cycles"], requests=d["accepted"], loads=d["loads_ok"],
                 svc_mean=d["lat_sum"] / max(1, d["lat_n"]),
                 svc_p95=pct(d["lat_hist"], .95),
                 lat_mean=d["e2e_sum"] / max(1, d["lat_n"]),
                 lat_p50=pct(d["e2e_hist"], .50), lat_p95=pct(d["e2e_hist"], .95),
                 lat_p99=pct(d["e2e_hist"], .99),
                 bp_cycles=sum(d["bp_cycles"]),
                 hit_rate=(p["ld_hit"] / p["ld"]) if is_cache and p["ld"] else 0.0,
                 merge_rate=(p["ld_merge"] / p["ld"]) if is_cache and p["ld"] else 0.0,
                 miss_rate=(p["ld_miss"] / p["ld"]) if is_cache and p["ld"] else 1.0,
                 bytes_dem=m["rd_dem_bytes"], bytes_pf=m["rd_pf_bytes"], bytes_wr=m["wr_bytes"],
                 bytes_total=tot, n_rd_dem=m["n_rd_dem"], n_rd_pf=m["n_rd_pf"],
                 bw=tot / d["cycles"], bytes_per_req=tot / d["accepted"],
                 pf_issued=p["mem_rd_pf"], pf_useful=p["pf_useful"], pf_late=p["pf_late"],
                 pf_useless=p["pf_useless"], pf_cand=p["pf_cand"], pf_filt=p["pf_filt"],
                 pf_drop=p["pf_drop"], pollution=p["pollution"], evict=p["evict"],
                 replays=p["rpl_mshr"] + p["rpl_sthaz"] + p["rpl_res"])
        rows.append(r)
    return pd.DataFrame(rows)


def paired(df, base_sel, test_sel, keys=("workload", "seed")):
    """Join two run sets on (workload, seed) and compute prefetch metrics."""
    b = df[base_sel].set_index(list(keys))
    t = df[test_sel].set_index(list(keys))
    j = t.join(b, rsuffix="_b", how="inner")
    out = pd.DataFrame(index=j.index)
    out["speedup"] = j["cycles_b"] / j["cycles"]
    out["lat_change"] = j["lat_mean"] / j["lat_mean_b"] - 1
    out["svc_change"] = j["svc_mean"] / j["svc_mean_b"] - 1
    out["bp_change"] = j["bp_cycles"] / j["bp_cycles_b"].where(j["bp_cycles_b"] > 0) - 1
    out["p95_change"] = j["lat_p95"] / j["lat_p95_b"] - 1
    out["hit_delta_pp"] = 100 * (j["hit_rate"] - j["hit_rate_b"])
    out["traffic_ratio"] = j["bytes_total"] / j["bytes_total_b"]
    out["coverage"] = 1 - j["n_rd_dem"] / j["n_rd_dem_b"].where(j["n_rd_dem_b"] > 0)
    used = j["pf_useful"] + j["pf_late"]
    out["accuracy"] = used / j["pf_issued"].where(j["pf_issued"] > 0)
    out["late_frac"] = j["pf_late"] / used.where(used > 0)
    for c in ("pf_issued", "pf_useful", "pf_late", "pf_useless", "pollution", "pf_drop", "pf_filt"):
        out[c] = j[c]
    out["unused_bytes"] = (j["pf_issued"] - used) * j["line"]
    out["extra_bytes"] = j["bytes_total"] - j["bytes_total_b"]
    return out.reset_index()


def verdict(g):
    """Multi-metric verdict for a prefetch configuration on one workload.

    Sign-consistency across seeds (all 5 seeds in the same direction has a
    one-sided sign-test p = 1/32 ~ 0.03) plus a minimum effect size.
    Hit rate is reported but never used to declare a benefit."""
    sp = g["speedup"]
    gm = math.exp(np.log(sp).mean())
    tr = g["traffic_ratio"].mean()
    p95 = g["p95_change"].mean()
    if (sp > 1.0).all() and gm >= 1.02:
        v = "BENEFIT" if (tr <= 1.10 and p95 <= 0.02) else "BENEFIT WITH COST"
    elif (sp < 1.0).all() and gm <= 0.995:
        v = "HARM"
    else:
        v = "NO MEASURABLE EFFECT"
    trap = (g["hit_delta_pp"].mean() >= 0.1) and gm <= 1.0
    return v, gm, trap


def setup_mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": AXIS,
        "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
        "grid.color": GRID, "grid.linewidth": 0.6, "axes.axisbelow": True,
        "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
        "legend.frameon": False, "axes.titlesize": 10, "axes.titlecolor": INK,
        "lines.linewidth": 2, "lines.markersize": 6,
    })
    return plt


def bar_group(ax, cats, series, values, colors, errs=None, width=0.26, fmt=None):
    n = len(series)
    x = np.arange(len(cats))
    for i, s in enumerate(series):
        xs = x + (i - (n - 1) / 2) * width
        ax.bar(xs, values[i], width * 0.9, color=colors[i], label=s,
               yerr=None if errs is None else errs[i], ecolor=INK2, capsize=2,
               error_kw=dict(lw=0.8))
        if fmt:
            for xx, v in zip(xs, values[i]):
                ax.text(xx, v, fmt(v), ha="center", va="bottom", fontsize=7, color=INK2)
    ax.set_xticks(x)
    ax.set_xticklabels(cats)
    ax.grid(axis="x", visible=False)


def figures(df, pr):
    plt = setup_mpl()
    os.makedirs(FIG, exist_ok=True)
    main = df[df.study == "main"]
    cfgs = ["uncached", "cache", "cache+pf"]
    cols = [CFG_COLOR[c] for c in cfgs]

    # 1. runtime normalised to uncached (per seed, then mean +- std)
    norm = {}
    for c in cfgs:
        v, e = [], []
        for w in WL_ORDER:
            a = main[(main.workload == w) & (main.label == c)].set_index("seed").cycles
            u = main[(main.workload == w) & (main.label == "uncached")].set_index("seed").cycles
            r = (a / u).dropna()
            v.append(r.mean()); e.append(r.std())
        norm[c] = (v, e)
    fig, ax = plt.subplots(figsize=(8.4, 3.2))
    bar_group(ax, WL_ORDER, cfgs, [norm[c][0] for c in cfgs], cols, [norm[c][1] for c in cfgs],
              fmt=lambda v: f"{v:.2f}")
    ax.axhline(1.0, color=AXIS, lw=1)
    ax.set_ylabel("runtime / uncached runtime\n(lower is better)")
    ax.set_title("Runtime relative to the uncached baseline (mean of 5 seeds, bars = ±1 sd)", loc="left")
    ax.set_ylim(0, 1.32)
    ax.legend(ncol=3, loc="upper right", fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig1_runtime.png"), dpi=160); plt.close(fig)

    # 2. demand latency: mean and p95 (two panels, one axis each)
    fig, axs = plt.subplots(1, 2, figsize=(11, 3.0))
    for ax, col, title in ((axs[0], "lat_mean", "Mean demand-load latency (end-to-end)"),
                           (axs[1], "lat_p95", "95th-percentile demand-load latency (end-to-end)")):
        vals = [[main[(main.workload == w) & (main.label == c)][col].mean() for w in WL_ORDER] for c in cfgs]
        bar_group(ax, WL_ORDER, cfgs, vals, cols, fmt=lambda v: f"{v:.0f}")
        ax.set_ylabel("cycles")
        ax.set_title(title, loc="left")
    axs[0].legend(ncol=3, loc="upper left", fontsize=7)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig2_latency.png"), dpi=160); plt.close(fig)

    # 3. memory traffic per request, stacked by class
    fig, ax = plt.subplots(figsize=(10.5, 3.3))
    xt, xl = [], []
    pos = 0
    for w in WL_ORDER:
        for c in cfgs:
            s = main[(main.workload == w) & (main.label == c)]
            parts = [s.bytes_dem.mean() / s.requests.mean(), s.bytes_pf.mean() / s.requests.mean(),
                     s.bytes_wr.mean() / s.requests.mean()]
            bottom = 0
            for (name, colr), v in zip(C_TR.items(), parts):
                ax.bar(pos, v, 0.8, bottom=bottom, color=colr, edgecolor=SURF, linewidth=1,
                       label=name if (w == WL_ORDER[0] and c == cfgs[0]) else None)
                bottom += v
            ax.text(pos, bottom, f"{bottom:.1f}", ha="center", va="bottom", fontsize=7, color=INK2)
            xt.append(pos); xl.append({"uncached": "U", "cache": "C", "cache+pf": "C+P"}[c])
            pos += 1
        ax.text(pos - 2, -0.16, w, transform=ax.get_xaxis_transform(), ha="center", color=INK, fontsize=9)
        pos += 0.6
    ax.set_xticks(xt); ax.set_xticklabels(xl, fontsize=7)
    ax.grid(axis="x", visible=False)
    ax.set_ylabel("memory bytes per request")
    ax.set_ylim(0, 78)
    ax.set_title("Memory traffic per core request (U = uncached, C = cache, C+P = cache + prefetch)", loc="left")
    ax.legend(ncol=3, loc="upper right", fontsize=8)
    fig.tight_layout(); fig.subplots_adjust(bottom=0.2)
    fig.savefig(os.path.join(FIG, "fig3_traffic.png"), dpi=160); plt.close(fig)

    # 4. prefetch quality per workload (small multiples, one entity colour)
    m = pr[pr.study == "main"].groupby("workload").mean(numeric_only=True).reindex(WL_ORDER)
    fig, axs = plt.subplots(1, 4, figsize=(11, 2.8), sharex=True)
    for ax, col, title, scale in ((axs[0], "accuracy", "Accuracy", 100), (axs[1], "coverage", "Coverage", 100),
                                  (axs[2], "late_frac", "Late fraction of useful", 100),
                                  (axs[3], "pf_issued", "Prefetches issued", 1)):
        v = (m[col] * scale).fillna(0).values
        ax.bar(range(len(WL_ORDER)), v, 0.6, color=C_PF)
        for i, x in enumerate(v):
            lab = "n/a" if (col != "pf_issued" and np.isnan(m[col].values[i])) else (f"{x:.0f}" + ("%" if scale == 100 else ""))
            ax.text(i, x, lab, ha="center", va="bottom", fontsize=7, color=INK2)
        ax.set_xticks(range(len(WL_ORDER))); ax.set_xticklabels(WL_ORDER, rotation=35, fontsize=7)
        ax.set_title(title, loc="left"); ax.grid(axis="x", visible=False)
    fig.suptitle("Stride-prefetcher quality (cache + prefetch vs. the same cache without it)", x=0.01, ha="left",
                 fontsize=10, color=INK)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig4_prefetch_quality.png"), dpi=160); plt.close(fig)

    # 5. prefetch distance sweep: runtime and traffic change (separate rows, no dual axis)
    pd_ = pr[pr.study == "pfdist"]
    wls = ["stream", "stride", "mixed"]
    fig, axs = plt.subplots(2, 3, figsize=(9.6, 4.9), sharex=True)
    for j, w in enumerate(wls):
        g = pd_[pd_.workload == w].groupby("pf_dist")
        for i, (col, ylab, tf) in enumerate((("speedup", "runtime improvement (%)", lambda v: 100 * (1 - 1 / v)),
                                             ("traffic_ratio", "extra memory traffic (%)", lambda v: 100 * (v - 1)))):
            ax = axs[i, j]
            mu = tf(g[col].mean()); lo = tf(g[col].min()); hi = tf(g[col].max())
            ax.fill_between(mu.index, lo, hi, color=C_PF, alpha=0.18, lw=0)
            ax.plot(mu.index, mu.values, "-o", color=C_PF, label="cache + prefetch (mean, band = min–max of 3 seeds)")
            ax.axhline(0.0, color=C_CACHE, lw=1.5, ls="--", label="cache without prefetch (reference)")
            ax.ticklabel_format(axis="y", useOffset=False, style="plain")
            if i == 0:
                ax.set_title(w, loc="left")
            if j == 0:
                ax.set_ylabel(ylab)
            if i == 1:
                ax.set_xlabel("prefetch distance (strides ahead)")
            ax.set_xticks([1, 2, 4, 8, 12])
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=2, fontsize=8)
    fig.suptitle("Prefetch distance sweep", x=0.01, ha="left", fontsize=10, color=INK)
    fig.tight_layout(rect=(0, 0.06, 1, 1)); fig.savefig(os.path.join(FIG, "fig5_pf_distance.png"), dpi=160)
    plt.close(fig)

    # 6/7. memory latency and bandwidth sensitivity (runtime, two series)
    for study, xcol, xlabel, fname, title in (
            ("memlat", "mem_lat", "memory latency (cycles)", "fig6_mem_latency.png",
             "Sensitivity to memory latency"),
            ("membw", "mem_bw", "memory bandwidth (bytes/cycle)", "fig7_mem_bandwidth.png",
             "Sensitivity to memory bandwidth")):
        s = df[df.study == study]
        fig, axs = plt.subplots(2, 2, figsize=(9.2, 4.8), sharex=True)
        for j, w in enumerate(("stream", "mixed")):
            for pf, lab, colr in ((0, "cache", C_CACHE), (1, "cache+pf", C_PF)):
                g = s[(s.workload == w) & (s.pf == pf)].groupby(xcol)
                axs[0, j].plot(g.cycles.mean().index, g.cycles.mean().values / 1e3, "-o", color=colr, label=lab)
            b = s[(s.workload == w) & (s.pf == 0)].groupby(xcol).bytes_total.mean()
            t = s[(s.workload == w) & (s.pf == 1)].groupby(xcol).bytes_total.mean()
            axs[1, j].plot(t.index, 100 * (t / b - 1), "-o", color=C_PF, label="cache+pf")
            axs[1, j].axhline(0, color=C_CACHE, lw=1.5, ls="--", label="cache (reference)")
            axs[1, j].ticklabel_format(axis="y", useOffset=False, style="plain")
            axs[0, j].set_title(w, loc="left")
            axs[1, j].set_xlabel(xlabel)
            axs[1, j].set_xscale("log", base=2)
            axs[1, j].set_xticks(sorted(s[xcol].unique()))
            axs[1, j].get_xaxis().set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:g}"))
        axs[0, 0].set_ylabel("runtime (k cycles)")
        axs[1, 0].set_ylabel("extra traffic vs. no prefetch (%)")
        axs[0, 0].legend(fontsize=7)
        fig.suptitle(title + " (mean of 3 seeds)", x=0.01, ha="left", fontsize=10, color=INK)
        fig.tight_layout(); fig.savefig(os.path.join(FIG, fname), dpi=160); plt.close(fig)

    # 8. hit-rate change next to runtime change: hit rate is not the improvement metric
    m8 = pr[pr.study == "main"].groupby("workload")[["hit_delta_pp", "speedup"]].mean().reindex(WL_ORDER)
    fig, axs = plt.subplots(1, 2, figsize=(9.2, 2.9), sharey=True)
    y = np.arange(len(WL_ORDER))[::-1]
    for ax, vals, title, xl in ((axs[0], m8.hit_delta_pp.values, "Change in demand hit rate", "percentage points"),
                                (axs[1], 100 * (1 - 1 / m8.speedup.values), "Change in runtime (positive = faster)", "%")):
        ax.barh(y, vals, 0.55, color=C_PF)
        ax.axvline(0, color=AXIS, lw=1)
        lim = max(abs(vals).max(), 1e-9)
        for yy, v in zip(y, vals):
            ax.text(v + (0.02 * lim if v >= 0 else -0.02 * lim), yy, f"{v:+.2f}", va="center",
                    ha="left" if v >= 0 else "right", fontsize=7, color=INK2)
        ax.set_xlim(-0.25 * lim, 1.25 * lim)
        ax.set_title(title, loc="left"); ax.set_xlabel(xl); ax.grid(axis="y", visible=False)
    axs[0].set_yticks(y); axs[0].set_yticklabels(WL_ORDER)
    fig.suptitle("Effect of enabling the prefetcher (mean of 5 seeds): in mixed the hit rate rises but the run gets slower",
                 x=0.01, ha="left", fontsize=10, color=INK)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig8_hitrate_vs_speedup.png"), dpi=160); plt.close(fig)

    # 9. geometry / replacement (no prefetch): runtime relative to 4-way LRU
    s = df[df.study == "geometry"]
    order = ["g_dm", "g_2w", "g_4w", "g_8w", "g_4w_fifo", "g_4w_rand", "g_l32", "g_l128"]
    names = ["DM", "2-way", "4-way", "8-way", "4w FIFO", "4w RAND", "32B line", "128B line"]
    fig, axs = plt.subplots(1, 3, figsize=(10, 2.9), sharey=False)
    for ax, w in zip(axs, ("reuse", "mixed", "stream")):
        base = s[(s.workload == w) & (s.build == "g_4w")].cycles.mean()
        v = [s[(s.workload == w) & (s.build == b)].cycles.mean() / base for b in order]
        ax.bar(range(len(order)), v, 0.6, color=C_CACHE)
        for i, x in enumerate(v):
            ax.text(i, x, f"{x:.2f}", ha="center", va="bottom", fontsize=7, color=INK2)
        ax.axhline(1.0, color=AXIS, lw=1)
        ax.set_xticks(range(len(order))); ax.set_xticklabels(names, rotation=40, fontsize=7)
        ax.set_title(w, loc="left"); ax.grid(axis="x", visible=False)
    axs[0].set_ylabel("runtime / 4-way LRU 64B")
    fig.suptitle("16 KiB geometry and replacement policy (no prefetch, mean of 3 seeds)", x=0.01, ha="left",
                 fontsize=10, color=INK)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig9_geometry.png"), dpi=160); plt.close(fig)

    # 10. miss tracking: runtime vs number of MSHRs
    s = df[df.study == "mshr"]
    fig, axs = plt.subplots(1, 3, figsize=(10, 2.8))
    for ax, w in zip(axs, ("stream", "random", "mixed")):
        g = s[(s.workload == w) & (s.tgt == 8)].groupby("mshr").cycles.mean()
        ax.plot(g.index, g.values / 1e3, "-o", color=C_CACHE, label="8 targets / MSHR")
        t2 = s[(s.workload == w) & (s.tgt == 2)].cycles.mean() / 1e3
        ax.plot([16], [t2], "s", color=C_CACHE, mfc=SURF, mew=2, label="16 MSHR, 2 targets")
        ax.set_xscale("log", base=2); ax.set_xticks([4, 8, 16, 32])
        ax.get_xaxis().set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:g}"))
        ax.set_title(w, loc="left"); ax.set_xlabel("MSHR entries")
    axs[0].set_ylabel("runtime (k cycles)")
    axs[0].legend(fontsize=7)
    fig.suptitle("Miss tracking capacity (no prefetch, mean of 3 seeds)", x=0.01, ha="left", fontsize=10, color=INK)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig10_mshr.png"), dpi=160); plt.close(fig)


def md_table(df, fmt):
    cols = list(df.columns)
    out = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    def cell(c, v):
        if isinstance(v, float) and math.isnan(v):
            return "n/a"
        return fmt.get(c, "{}").format(v)
    for _, r in df.iterrows():
        out.append("| " + " | ".join(cell(c, r[c]) for c in cols) + " |")
    return "\n".join(out)


def main():
    df = load()
    os.makedirs(TAB, exist_ok=True)
    df.sort_values(["study", "workload", "build", "label", "seed"]).to_csv(os.path.join(TAB, "all_runs.csv"), index=False)

    # paired prefetch comparisons
    pr_parts = []
    c = df[(df.study == "main") & (df.label == "cache")]
    t = df[(df.study == "main") & (df.label == "cache+pf")]
    x = paired(pd.concat([c, t]), pd.concat([c, t]).label == "cache", pd.concat([c, t]).label == "cache+pf")
    x["study"] = "main"; pr_parts.append(x)
    base_main = df[(df.study == "main") & (df.label == "cache")]
    for d in sorted(df[df.study == "pfdist"].pf_dist.unique()):
        t = df[(df.study == "pfdist") & (df.pf_dist == d)]
        both = pd.concat([base_main[base_main.seed.isin(t.seed)], t])
        x = paired(both, both.study == "main", both.study == "pfdist")
        x["study"] = "pfdist"; x["pf_dist"] = d; pr_parts.append(x)
    for study, col in (("memlat", "mem_lat"), ("membw", "mem_bw")):
        for v in sorted(df[df.study == study][col].unique()):
            s = df[(df.study == study) & (df[col] == v)]
            x = paired(s, s.pf == 0, s.pf == 1)
            x["study"] = study; x[col] = v; pr_parts.append(x)
    pr = pd.concat(pr_parts, ignore_index=True)
    pr.to_csv(os.path.join(TAB, "prefetch_paired.csv"), index=False)

    # ---- main summary table ------------------------------------------------------
    main = df[df.study == "main"]
    agg = main.groupby(["workload", "label"]).agg(
        runtime=("cycles", "mean"), runtime_sd=("cycles", "std"), hit_rate=("hit_rate", "mean"),
        merge_rate=("merge_rate", "mean"), lat_mean=("lat_mean", "mean"), lat_p95=("lat_p95", "mean"),
        lat_p99=("lat_p99", "mean"), svc_mean=("svc_mean", "mean"), bp_cycles=("bp_cycles", "mean"),
        bw=("bw", "mean"), bytes_per_req=("bytes_per_req", "mean"),
        kib_total=("bytes_total", lambda v: v.mean() / 1024), kib_pf=("bytes_pf", lambda v: v.mean() / 1024),
    ).reset_index()
    agg["workload"] = pd.Categorical(agg["workload"], WL_ORDER)
    agg["label"] = pd.Categorical(agg["label"], ["uncached", "cache", "cache+pf"])
    agg = agg.sort_values(["workload", "label"])
    agg.to_csv(os.path.join(TAB, "main_summary.csv"), index=False)

    # ---- verdicts ------------------------------------------------------------------
    vrows = []
    for w in WL_ORDER:
        g = pr[(pr.study == "main") & (pr.workload == w)]
        v, gm, trap = verdict(g)
        vrows.append(dict(workload=w, verdict=v, speedup_gmean=gm,
                          speedup_range=f"{g.speedup.min():.3f}–{g.speedup.max():.3f}",
                          hit_delta_pp=g.hit_delta_pp.mean(), lat_change=100 * g.lat_change.mean(),
                          svc_change=100 * g.svc_change.mean(), bp_change=100 * g.bp_change.mean(),
                          p95_change=100 * g.p95_change.mean(), traffic_change=100 * (g.traffic_ratio.mean() - 1),
                          accuracy=100 * g.accuracy.mean(), coverage=100 * g.coverage.mean(),
                          late=100 * g.late_frac.mean(), issued=g.pf_issued.mean(),
                          useless=g.pf_useless.mean(), pollution=g.pollution.mean(),
                          dropped=g.pf_drop.mean(), hit_rate_trap="YES" if trap else ""))
    ver = pd.DataFrame(vrows)
    ver.to_csv(os.path.join(TAB, "prefetch_verdicts.csv"), index=False)

    # cache vs uncached
    crows = []
    for w in WL_ORDER:
        u = main[(main.workload == w) & (main.label == "uncached")].set_index("seed")
        c = main[(main.workload == w) & (main.label == "cache")].set_index("seed")
        sp = u.cycles / c.cycles
        crows.append(dict(workload=w, speedup_gmean=math.exp(np.log(sp).mean()),
                          speedup_range=f"{sp.min():.2f}–{sp.max():.2f}",
                          latency_change=100 * (c.lat_mean.mean() / u.lat_mean.mean() - 1),
                          traffic_ratio=c.bytes_total.mean() / u.bytes_total.mean(),
                          hit_rate=100 * c.hit_rate.mean(), merge_rate=100 * c.merge_rate.mean()))
    cvu = pd.DataFrame(crows)
    cvu.to_csv(os.path.join(TAB, "cache_vs_uncached.csv"), index=False)

    figures(df, pr)

    # ---- markdown fragments for RESULTS.md ----------------------------------------
    frag = {}
    frag["main"] = md_table(agg.rename(columns={"label": "config"}), {
        "runtime": "{:.0f}", "runtime_sd": "{:.0f}", "hit_rate": "{:.3f}", "merge_rate": "{:.3f}",
        "lat_mean": "{:.1f}", "lat_p95": "{:.0f}", "lat_p99": "{:.0f}", "svc_mean": "{:.1f}",
        "bp_cycles": "{:.0f}", "bw": "{:.2f}",
        "bytes_per_req": "{:.1f}", "kib_total": "{:.0f}", "kib_pf": "{:.1f}"})
    frag["cvu"] = md_table(cvu, {"speedup_gmean": "{:.2f}", "latency_change": "{:+.0f}%",
                                 "traffic_ratio": "{:.2f}", "hit_rate": "{:.1f}%", "merge_rate": "{:.1f}%"})
    frag["verdict"] = md_table(ver, {
        "speedup_gmean": "{:.3f}", "hit_delta_pp": "{:+.2f}", "lat_change": "{:+.1f}%", "p95_change": "{:+.1f}%",
        "svc_change": "{:+.1f}%", "bp_change": "{:+.0f}%",
        "traffic_change": "{:+.1f}%", "accuracy": "{:.0f}%", "coverage": "{:.0f}%", "late": "{:.0f}%",
        "issued": "{:.0f}", "useless": "{:.0f}", "pollution": "{:.0f}", "dropped": "{:.0f}"})
    pdist = pr[pr.study == "pfdist"].groupby(["workload", "pf_dist"]).agg(
        speedup=("speedup", "mean"), speedup_min=("speedup", "min"), speedup_max=("speedup", "max"),
        traffic_ratio=("traffic_ratio", "mean"), accuracy=("accuracy", "mean"),
        coverage=("coverage", "mean"), late_frac=("late_frac", "mean"), useless=("pf_useless", "mean"),
        pollution=("pollution", "mean")).reset_index()
    pdist.to_csv(os.path.join(TAB, "pf_distance.csv"), index=False)
    frag["pfdist"] = md_table(pdist, {"speedup": "{:.3f}", "speedup_min": "{:.3f}", "speedup_max": "{:.3f}",
                                      "traffic_ratio": "{:.3f}", "accuracy": "{:.2f}", "coverage": "{:.2f}",
                                      "late_frac": "{:.2f}", "useless": "{:.0f}", "pollution": "{:.0f}"})
    sens = []
    for study, col in (("memlat", "mem_lat"), ("membw", "mem_bw")):
        g = pr[pr.study == study].groupby(["workload", col]).agg(
            speedup=("speedup", "mean"), traffic_ratio=("traffic_ratio", "mean"),
            coverage=("coverage", "mean"), dropped=("pf_drop", "mean")).reset_index()
        g.insert(0, "parameter", col)
        g = g.rename(columns={col: "value"})
        sens.append(g)
    sens = pd.concat(sens)
    sens.to_csv(os.path.join(TAB, "sensitivity.csv"), index=False)
    frag["sens"] = md_table(sens, {"speedup": "{:.3f}", "traffic_ratio": "{:.3f}", "coverage": "{:.2f}",
                                   "dropped": "{:.0f}"})
    geo = df[df.study == "geometry"].groupby(["workload", "build"]).agg(
        runtime=("cycles", "mean"), hit_rate=("hit_rate", "mean"), lat_mean=("lat_mean", "mean"),
        evictions=("evict", "mean"), kib_total=("bytes_total", lambda v: v.mean() / 1024)).reset_index()
    geo.to_csv(os.path.join(TAB, "geometry.csv"), index=False)
    frag["geo"] = md_table(geo, {"runtime": "{:.0f}", "hit_rate": "{:.3f}", "lat_mean": "{:.1f}",
                                 "evictions": "{:.0f}", "kib_total": "{:.0f}"})
    iso = []
    for lab, sel in (("prefetch off", (df.study == "main") & (df.workload == "mixed") & (df.label == "cache")),
                     ("prefetch on", (df.study == "main") & (df.workload == "mixed") & (df.label == "cache+pf")),
                     ("prefetch on, never allocates (PF_MSHR_RSV=15)", df.study == "isolation")):
        g = df[sel]
        iso.append(dict(configuration=lab, runtime=g.cycles.mean(), backpressure_cycles=g.bp_cycles.mean(),
                        prefetches_issued=g.pf_issued.mean(), candidates=g.pf_cand.mean(),
                        lat_mean=g.lat_mean.mean()))
    iso = pd.DataFrame(iso)
    iso.to_csv(os.path.join(TAB, "isolation.csv"), index=False)
    frag["iso"] = md_table(iso, {"runtime": "{:.0f}", "backpressure_cycles": "{:.0f}",
                                 "prefetches_issued": "{:.1f}", "candidates": "{:.0f}", "lat_mean": "{:.2f}"})
    ms = df[df.study == "mshr"].groupby(["workload", "mshr", "tgt"]).agg(
        runtime=("cycles", "mean"), lat_mean=("lat_mean", "mean"), merge_rate=("merge_rate", "mean"),
        replays=("replays", "mean")).reset_index()
    ms.to_csv(os.path.join(TAB, "mshr.csv"), index=False)
    frag["mshr"] = md_table(ms, {"runtime": "{:.0f}", "lat_mean": "{:.1f}", "merge_rate": "{:.3f}",
                                 "replays": "{:.0f}"})
    json.dump(frag, open(os.path.join(TAB, "fragments.json"), "w"), indent=1)
    print(ver.to_string())
    print(cvu.to_string())
    print(pdist.to_string())
    print(sens.to_string())


if __name__ == "__main__":
    main()
