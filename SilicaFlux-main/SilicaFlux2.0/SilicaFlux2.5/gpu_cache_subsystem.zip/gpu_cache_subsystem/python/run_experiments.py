#!/usr/bin/env python3
"""Run the performance experiments (trace-driven, Verilator RTL simulation).

Every run is the *RTL* (gc_uncached or gc_cache) driven by tb_top in trace
mode, with the behavioural memory model of tb/tb_mem.sv.  Results are raw
JSON files in results/experiments/raw/ (one per run); python/analyze.py turns
them into tables, figures and results/RESULTS.md.

    python3 python/run_experiments.py              # everything (~10 min, 4 cores)
    python3 python/run_experiments.py --only main  # one study
"""
import argparse
import concurrent.futures as cf
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import simlib  # noqa: E402
from workloads import WORKLOADS, generate, write_traces  # noqa: E402

N_PER_PORT = 8000
MAIN_SEEDS = (1, 2, 3, 4, 5)
SWEEP_SEEDS = (1, 2, 3)

# Default system point (see docs/PLATFORM_ASSUMPTIONS.md)
DEFAULT_RUN = dict(mlp=8, mem_lat=100, mem_bw=16, mem_jitter=16, pf_dist=4)

# RTL builds used by the studies.  "cache" builds include the prefetcher
# hardware; prefetching is switched on/off at run time (pf_en), so the
# "cache" and "cache+pf" points use the identical netlist.
BUILDS = {
    "uncached": dict(DUT_KIND=0, N_OT=16),
    "cache":    dict(DUT_KIND=1, PF_ENABLE=1),                       # 16 KiB 4w LRU 64B, 16 MSHR x8
    # geometry / replacement study (16 KiB total, prefetcher not built)
    "g_dm":     dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=1, NUM_SETS=256),
    "g_2w":     dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=2, NUM_SETS=128),
    "g_4w":     dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=4, NUM_SETS=64),
    "g_8w":     dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=8, NUM_SETS=32),
    "g_4w_fifo": dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=4, NUM_SETS=64, REPL=1),
    "g_4w_rand": dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=4, NUM_SETS=64, REPL=2),
    "g_l32":    dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=4, NUM_SETS=128, LINE_BYTES=32),
    "g_l128":   dict(DUT_KIND=1, PF_ENABLE=0, NUM_WAYS=4, NUM_SETS=32, LINE_BYTES=128),
    # miss-tracking study
    "m4":       dict(DUT_KIND=1, PF_ENABLE=0, N_MSHR=4, N_TGT=8),
    "m8":       dict(DUT_KIND=1, PF_ENABLE=0, N_MSHR=8, N_TGT=8),
    "m32":      dict(DUT_KIND=1, PF_ENABLE=0, N_MSHR=32, N_TGT=8),
    "m16_t2":   dict(DUT_KIND=1, PF_ENABLE=0, N_MSHR=16, N_TGT=2),
    # isolation: prefetcher trains and generates candidates that flow through
    # the pipeline, but may only allocate an MSHR when 16 of 16 are free
    "iso_rsv15": dict(DUT_KIND=1, PF_ENABLE=1, PF_MSHR_RSV=15),
}


def studies():
    """Yield (study, build, workload, seed, run-overrides, label)."""
    for wl in WORKLOADS:
        for s in MAIN_SEEDS:
            yield ("main", "uncached", wl, s, dict(pf_en=0), "uncached")
            yield ("main", "cache", wl, s, dict(pf_en=0), "cache")
            yield ("main", "cache", wl, s, dict(pf_en=1), "cache+pf")
    for wl in ("stream", "stride", "mixed"):
        for d in (1, 2, 4, 8, 12):
            for s in SWEEP_SEEDS:
                yield ("pfdist", "cache", wl, s, dict(pf_en=1, pf_dist=d), f"d={d}")
    for wl in ("stream", "mixed"):
        for lat in (50, 100, 200, 400):
            for s in SWEEP_SEEDS:
                for pf in (0, 1):
                    yield ("memlat", "cache", wl, s, dict(pf_en=pf, mem_lat=lat),
                           f"lat={lat}/{'pf' if pf else 'nopf'}")
        for bw in (4, 8, 16, 32):
            for s in SWEEP_SEEDS:
                for pf in (0, 1):
                    yield ("membw", "cache", wl, s, dict(pf_en=pf, mem_bw=bw),
                           f"bw={bw}/{'pf' if pf else 'nopf'}")
    for b in ("g_dm", "g_2w", "g_4w", "g_8w", "g_4w_fifo", "g_4w_rand", "g_l32", "g_l128"):
        for wl in ("reuse", "mixed", "stream"):
            for s in SWEEP_SEEDS:
                yield ("geometry", b, wl, s, dict(pf_en=0), b)
    for s in MAIN_SEEDS:
        yield ("isolation", "iso_rsv15", "mixed", s, dict(pf_en=1), "pf, never allocates")
    for b in ("m4", "m8", "cache", "m32", "m16_t2"):
        for wl in ("stream", "random", "mixed"):
            for s in SWEEP_SEEDS:
                yield ("mshr", b, wl, s, dict(pf_en=0), "m16" if b == "cache" else b)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None, help="run a single study")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    args = ap.parse_args()

    raw = os.path.join(simlib.ROOT, "results", "experiments", "raw")
    tdir = os.path.join(simlib.ROOT, "build", "traces")
    os.makedirs(raw, exist_ok=True)
    runs = [r for r in studies() if args.only in (None, r[0])]

    t0 = time.time()
    need_builds = sorted({r[1] for r in runs})
    exes = {}
    with cf.ThreadPoolExecutor(max_workers=max(1, args.jobs // 2)) as ex:
        futs = {ex.submit(simlib.build, "x_" + b, BUILDS[b]): b for b in need_builds}
        for f in cf.as_completed(futs):
            exes[futs[f]] = f.result()
    print(f"{len(exes)} builds ready after {time.time() - t0:.0f}s")

    for wl, s in sorted({(r[2], r[3]) for r in runs}):
        d = os.path.join(tdir, f"{wl}_s{s}")
        if not os.path.exists(os.path.join(d, "p3.trc")):
            write_traces(generate(wl, N_PER_PORT, s), d)

    def one(r):
        study, b, wl, s, ov, label = r
        cfg = dict(DEFAULT_RUN, **ov)
        tag = f"{study}__{b}__{wl}__s{s}__" + "_".join(f"{k}{v}" for k, v in sorted(ov.items()))
        out = os.path.join(raw, tag + ".json")
        if os.path.exists(out):
            return tag, True
        plus = ["test=trace", f"trace_dir={os.path.join(tdir, f'{wl}_s{s}')}", f"stats={out}.tmp",
                f"label={label}"] + [f"{k}={v}" for k, v in cfg.items()]
        ok, log = simlib.run(exes[b], plus, seed=s, timeout=3600)
        if ok:
            d = json.load(open(out + ".tmp"))
            d.update(study=study, build=b, workload=wl, seed=s, label=label, run=cfg)
            json.dump(d, open(out, "w"), indent=1)
            os.remove(out + ".tmp")
        else:
            print(log[-2000:])
        return tag, ok

    n_ok = 0
    with cf.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        for i, (tag, ok) in enumerate(ex.map(one, runs)):
            n_ok += ok
            if not ok:
                print("FAILED:", tag)
            if (i + 1) % 50 == 0:
                print(f"  {i + 1}/{len(runs)} runs ({time.time() - t0:.0f}s)")
    print(f"{n_ok}/{len(runs)} runs OK in {time.time() - t0:.0f}s")
    sys.exit(0 if n_ok == len(runs) else 1)


if __name__ == "__main__":
    main()
