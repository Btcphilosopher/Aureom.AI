#!/usr/bin/env python3
"""Synthetic GPU-style workloads -> per-port trace files for tb_top (+test=trace).

Trace line format (one request):  <op> <addr hex> <wdata hex> <wstrb hex> <pc hex> <gap>
  op   : 0 load, 1 store
  pc   : 8-bit "instruction" id (the stride prefetcher keys its table on {port, pc})
  gap  : idle cycles the port waits before presenting this request (compute time)

Each port models one load/store unit issuing word (4 B) requests with a bounded
number of outstanding requests (tb_top +mlp).  Warp-level coalescing is NOT
modelled: every lane access is a separate request.

Workloads (all deterministic for a given seed):
  stream  : each port reads its own large array sequentially (unit stride)
  stride  : each port reads one word every 256 B (4 lines at 64 B), large region
  random  : uniform random words over a 64 MiB region (gather)
  reuse   : random reads of a shared 8 KiB table (fits in a 16 KiB cache)
  mixed   : per element: stream load in[i], table lookup, every 4th element a
            random gather, every 2nd element a streaming store out[i/2]
  mixed_aliased : identical to mixed, but the per-port arrays are exactly
            16 MiB apart, so the four ports' stream lines (and their
            prefetches) always map to the same cache set (set aliasing)

Per-port arrays are normally skewed by 65 lines (16 MiB + 4160 B apart) so
that the ports' streams do not alias onto the same set by construction.
"""
import argparse
import os

import numpy as np

PORTS = 4
WORKLOADS = ("stream", "stride", "random", "reuse", "mixed", "mixed_aliased")

PORT_REGION = 0x0100_0000 + 65 * 64   # 16 MiB + 65 lines apart per port (skewed)
PORT_REGION_ALIGNED = 0x0100_0000     # power-of-two aligned (mixed_aliased)
STREAM_BASE = 0x1000_0000
STRIDE_BASE = 0x2000_0000
RANDOM_BASE = 0x4000_0000
RANDOM_SPAN = 64 << 20
TABLE_BASE = 0x3000_0000
TABLE_BYTES = 8 << 10
OUT_BASE = 0x5000_0000
GATHER_BASE = 0x6000_0000
GATHER_SPAN = 32 << 20

PC_STREAM, PC_STRIDE, PC_RANDOM, PC_TABLE, PC_STORE = 0x11, 0x22, 0x33, 0x44, 0x55


def _gap(rng):
    # 0..2 idle cycles between requests (light compute between memory ops)
    return int(rng.integers(0, 3))


def gen_port(workload, port, n, rng):
    """Return a list of (op, addr, wdata, wstrb, pc, gap) for one port."""
    out = []
    if workload == "stream":
        base = STREAM_BASE + port * PORT_REGION
        for i in range(n):
            out.append((0, base + 4 * i, 0, 0xF, PC_STREAM, _gap(rng)))
    elif workload == "stride":
        base = STRIDE_BASE + port * PORT_REGION
        for i in range(n):
            out.append((0, base + 256 * i, 0, 0xF, PC_STRIDE, _gap(rng)))
    elif workload == "random":
        words = rng.integers(0, RANDOM_SPAN // 4, size=n)
        for w in words:
            out.append((0, RANDOM_BASE + 4 * int(w), 0, 0xF, PC_RANDOM, _gap(rng)))
    elif workload == "reuse":
        words = rng.integers(0, TABLE_BYTES // 4, size=n)
        for w in words:
            out.append((0, TABLE_BASE + 4 * int(w), 0, 0xF, PC_TABLE, _gap(rng)))
    elif workload in ("mixed", "mixed_aliased"):
        region = PORT_REGION if workload == "mixed" else PORT_REGION_ALIGNED
        sbase = STREAM_BASE + port * region
        obase = OUT_BASE + port * region
        i = 0
        while len(out) < n:
            out.append((0, sbase + 4 * i, 0, 0xF, PC_STREAM, _gap(rng)))
            t = int(rng.integers(0, TABLE_BYTES // 4))
            out.append((0, TABLE_BASE + 4 * t, 0, 0xF, PC_TABLE, 0))
            if i % 4 == 0:
                g = int(rng.integers(0, GATHER_SPAN // 4))
                out.append((0, GATHER_BASE + 4 * g, 0, 0xF, PC_RANDOM, 0))
            if i % 2 == 0:
                out.append((1, obase + 4 * (i // 2), int(rng.integers(0, 1 << 32)), 0xF, PC_STORE, 0))
            i += 1
        out = out[:n]
    else:
        raise ValueError(workload)
    return out


def generate(workload, n_per_port, seed, ports=PORTS):
    rng = np.random.default_rng(seed * 1000 + WORKLOADS.index(workload))
    return [gen_port(workload, p, n_per_port, rng) for p in range(ports)]


def write_traces(traces, outdir):
    os.makedirs(outdir, exist_ok=True)
    for p, tr in enumerate(traces):
        with open(os.path.join(outdir, f"p{p}.trc"), "w") as f:
            for op, a, d, s, pc, gap in tr:
                f.write(f"{op} {a:08x} {d:08x} {s:x} {pc:02x} {gap}\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("workload", choices=WORKLOADS)
    ap.add_argument("--n", type=int, default=8000, help="requests per port")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--ports", type=int, default=PORTS)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    write_traces(generate(a.workload, a.n, a.seed, a.ports), a.out)


if __name__ == "__main__":
    main()
