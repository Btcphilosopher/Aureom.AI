#!/usr/bin/env python3
"""Untimed functional reference model of the gc_cache policy.

Mirrors the RTL policy decisions exactly where they are timing-independent:
  * set-associative, invalid-way-first victim selection
  * LRU with the same age-counter update as the RTL (0 = MRU),
    FIFO with the same per-set pointer, RANDOM (not cycle-exact: the RTL
    LFSR advances every clock, so only LRU/FIFO are cross-checked exactly)
  * write-through, no-write-allocate; store hits update recency
  * the same stride-prefetcher training/issue rules as gc_pf_stride

Being untimed, fills (and prefetches) are installed instantly, so the model
gives *upper bounds* for prefetch timeliness.  It is used for:
  1. exact cross-checking of RTL hit/miss/evict counters in blocking
     single-port runs (python/model_crosscheck.py),
  2. workload characterisation (3C miss classification, footprint), and
  3. an order-exact pollution estimate (hit without prefetch, miss with it).
"""
from collections import OrderedDict

import numpy as np


class StridePF:
    """Python twin of rtl/gc_pf_stride.sv (degree 1, page-bounded)."""

    def __init__(self, line=64, entries=16, conf_th=2, page=4096, stride_bits=8, dist=4, port_bits=2):
        self.lsh = line.bit_length() - 1
        self.entries, self.conf_th, self.dist = entries, conf_th, max(1, dist)
        self.pg_lines = page // line
        self.smax = 1 << (stride_bits - 1)
        self.tab = {}
        self.port_bits = port_bits

    def _idx(self, port, pc):
        key = (port << 8) | pc
        iw = self.entries.bit_length() - 1
        r = 0
        for i in range(8 + self.port_bits):
            if (key >> i) & 1:
                r ^= 1 << ((i + i // iw) % iw)
        return r, key

    def train(self, port, pc, addr):
        """Return a target line address or None."""
        line = addr >> self.lsh
        idx, key = self._idx(port, pc)
        e = self.tab.get(idx)
        if e is None or e["key"] != key:
            self.tab[idx] = dict(key=key, last=line, stride=0, conf=0, lastpf=line)
            return None
        delta = line - e["last"]
        if delta == 0:
            return None
        fits = -self.smax <= delta < self.smax
        same = fits and delta == e["stride"] and e["stride"] != 0
        conf = min(3, e["conf"] + 1) if same else 0
        e["last"], e["conf"] = line, conf
        if not same:
            e["stride"] = delta if fits else 0
            return None
        if conf < self.conf_th:
            return None
        tgt = line + e["stride"] * self.dist
        if tgt // self.pg_lines != line // self.pg_lines or tgt == e["lastpf"]:
            return None
        e["lastpf"] = tgt
        return tgt


class CacheModel:
    def __init__(self, sets=64, ways=4, line=64, repl="lru", pf=None, seed=1):
        self.sets, self.ways, self.line = sets, ways, line
        self.lsh = line.bit_length() - 1
        self.repl = repl
        self.pf = pf
        self.rng = np.random.default_rng(seed)
        self.tag = [[None] * ways for _ in range(sets)]
        self.pfb = [[False] * ways for _ in range(sets)]
        self.age = [list(range(ways)) for _ in range(sets)]
        self.fifo = [0] * sets
        self.st = dict(ld=0, ld_hit=0, ld_miss=0, st=0, st_hit=0, fill=0, evict=0,
                       pf_issued=0, pf_filt=0, pf_useful=0, pf_useless=0)

    # -- helpers -------------------------------------------------------------
    def _loc(self, line):
        s = line % self.sets
        t = line // self.sets
        for w in range(self.ways):
            if self.tag[s][w] == t:
                return s, w
        return s, None

    def _touch(self, s, w):
        a = self.age[s]
        aw = a[w]
        for i in range(self.ways):
            if i == w:
                a[i] = 0
            elif a[i] < aw:
                a[i] += 1

    def _victim(self, s):
        for w in range(self.ways):
            if self.tag[s][w] is None:
                return w, False
        if self.repl == "fifo":
            w = self.fifo[s]
            self.fifo[s] = (w + 1) % self.ways
        elif self.repl == "random":
            w = int(self.rng.integers(0, self.ways))
        else:
            w = self.age[s].index(self.ways - 1)
        return w, True

    def _install(self, line, prefetched):
        s = line % self.sets
        w, evict = self._victim(s)
        if evict:
            self.st["evict"] += 1
            if self.pfb[s][w]:
                self.st["pf_useless"] += 1
        self.tag[s][w] = line // self.sets
        self.pfb[s][w] = prefetched
        self.st["fill"] += 1
        self._touch(s, w)

    def contains(self, addr):
        return self._loc(addr >> self.lsh)[1] is not None

    # -- public --------------------------------------------------------------
    def access(self, op, addr, port=0, pc=0):
        """Process one well-formed request; returns True on hit."""
        line = addr >> self.lsh
        s, w = self._loc(line)
        if op == 1:  # store: write-through, no allocate
            self.st["st"] += 1
            if w is not None:
                self.st["st_hit"] += 1
                self._touch(s, w)
            return w is not None
        self.st["ld"] += 1
        hit = w is not None
        if hit:
            self.st["ld_hit"] += 1
            if self.pfb[s][w]:
                self.st["pf_useful"] += 1
                self.pfb[s][w] = False
            self._touch(s, w)
        else:
            self.st["ld_miss"] += 1
            self._install(line, False)
        if self.pf is not None:
            tgt = self.pf.train(port, pc, addr)
            if tgt is not None:
                if self._loc(tgt)[1] is None:
                    self.st["pf_issued"] += 1
                    self._install(tgt, True)
                else:
                    self.st["pf_filt"] += 1
        return hit


def classify_3c(trace_lines, capacity_lines, model_hits):
    """3C classification of the misses of `model_hits` (per access, loads only)."""
    seen = set()
    fa = OrderedDict()
    comp = cap = conf = 0
    for line, hit in zip(trace_lines, model_hits):
        fa_hit = line in fa
        if fa_hit:
            fa.move_to_end(line)
        else:
            fa[line] = True
            if len(fa) > capacity_lines:
                fa.popitem(last=False)
        if not hit:
            if line not in seen:
                comp += 1
            elif not fa_hit:
                cap += 1
            else:
                conf += 1
        seen.add(line)
    return comp, cap, conf


def run_interleaved(traces, model, record=False):
    """Feed per-port traces round-robin (an approximation of the RTL's
    arbitration order for characterisation only)."""
    hits = []
    idx = [0] * len(traces)
    remaining = sum(len(t) for t in traces)
    while remaining:
        for p, tr in enumerate(traces):
            if idx[p] < len(tr):
                op, a, _d, _s, pc, _g = tr[idx[p]]
                h = model.access(op, a, p, pc)
                if record and op == 0:
                    hits.append((a >> model.lsh, h))
                idx[p] += 1
                remaining -= 1
    return hits
