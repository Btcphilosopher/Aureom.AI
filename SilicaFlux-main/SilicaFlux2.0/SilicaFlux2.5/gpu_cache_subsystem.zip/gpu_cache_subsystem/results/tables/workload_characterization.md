| workload | loads | stores | footprint_kib | hit_rate | compulsory | capacity | conflict | ideal_pf_hit_rate | ideal_pf_issued | ideal_pf_useful | ideal_pollution |
|---|---|---|---|---|---|---|---|---|---|---|---|
| stream | 32000 | 0 | 125 | 0.938 | 2000 | 0 | 0 | 0.996 | 1876 | 1860 | 0 |
| stride | 32000 | 0 | 2000 | 0.000 | 32000 | 0 | 0 | 0.750 | 23988 | 23988 | 0 |
| random | 32000 | 0 | 1968 | 0.000 | 31492 | 497 | 3 | 0.000 | 0 | 0 | 0 |
| reuse | 32000 | 0 | 8 | 0.996 | 128 | 0 | 0 | 0.996 | 0 | 0 | 0 |
| mixed | 26184 | 5816 | 258 | 0.830 | 3759 | 186 | 511 | 0.822 | 684 | 5 | 215 |
| mixed_aliased | 26184 | 5816 | 258 | 0.793 | 3760 | 213 | 1451 | 0.783 | 684 | 0 | 270 |
