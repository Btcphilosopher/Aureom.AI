# ARCHITECTURE: sf_memory_matrix

Labels used in this document set: **RTL-SIMULATION** (Verilator run of the RTL), **FORMAL** (SymbiYosys / z3 proof, bounded unless stated),
**SYNTHESIS** (Yosys result of this package), **MODEL** (Python enumeration or analytic model), **ESTIMATE / ASSUMED** (a number that rests on
an assumption). Nothing in this package is a silicon measurement.

## 1. What it is

`sf_memory_matrix` is a banked single-port SRAM subsystem that sits where `sf_sram_controller` sits in the existing SilicaFlux memory stack and
feeds the ControlCore, the TensorCore, the FP32 vector engine and CloudDMA / DataFabric.

```
 CTRL        TENSOR       VECTOR       DMA                 request : valid/ready, we, byte addr, size, wdata, be, id, prot
  |            |            |            |                 response: valid/ready, rdata, id, we, status, ce
  v            v            v            v
 +------------------------------------------------------------------------------+
 | per master  sf_memory_matrix_decoder  bounds | alignment | size | permission | (bank,row) of up to K words |
 |             split into <= K word operations (byte-lane shift, misalignment, bank spanning)                   |
 |             slot table = bounded request queue + reorder buffer (NSLOT entries, ISSUE_WINDOW candidates)    |
 +------------------------------------------------------------------------------+
        |  one pending word per (master, bank)
        v
 +---------+ +---------+ +---------+ +---------+
 | arbiter | | arbiter | | arbiter | | arbiter |   sf_memory_matrix_arbiter, round robin, one grant per bank per cycle
 +----+----+ +----+----+ +----+----+ +----+----+
      v           v           v           v
 +---------+ +---------+ +---------+ +---------+
 | sf_sram | | sf_sram | | sf_sram | | sf_sram |   REUSED UNMODIFIED: 1RW array, optional SECDED + atomic RMW, init engine,
 | _bank 0 | | _bank 1 | | _bank 2 | | _bank 3 |   scrubber, MBIST port, backend = behavioural | FPGA block RAM | ASIC macro tiling
 +----+----+ +----+----+ +----+----+ +----+----+
      +-----------+-----------+-----------+--- word responses tagged {master, slot, word}
 per master: gather words -> re-align bytes -> in-order response -> sf_memory_matrix_perf (counters)
```

| file | role |
|---|---|
| `rtl/memory/sf_memory_matrix.sv` | top: front end, slot tables, routing, banks, flush / quiesce / idle, instrumentation hook-up |
| `rtl/memory/sf_memory_matrix_decoder.sv` | address decode, boundary / alignment / size / permission checks; also the inverse map `sf_memory_matrix_unmap` |
| `rtl/memory/sf_memory_matrix_arbiter.sv` | per-bank round-robin (or fixed priority) arbiter |
| `rtl/memory/sf_memory_matrix_perf.sv` | performance counters |
| `rtl/memory/sf_mm_defs.svh`, `sf_mm_map.svh` | constants; the forward / inverse address map functions (one text shared by decoder and unmap) |
| `rtl/memory/third_party/...` | the existing SilicaFlux modules, **byte-identical** (`SHA256SUMS`, `PROVENANCE.md`) |

## 2. Parameters

| parameter | default | meaning |
|---|---|---|
| `NUM_BANKS` | 4 | independent SRAM banks; power of two, 2..32 (4, 8, 16 are the configurations evaluated) |
| `BANK_DEPTH` | 1024 | words per bank (any value >= 2; a multiple of the granule for LOW / XOR) |
| `WORD_WIDTH` | 64 | physical SRAM word, power of two >= 16 (32 / 64 / 128 are exercised, also with ECC) |
| `DATA_WIDTH` | 256 | master data bus = largest single access (16..512, power of two); 128-bit and 256-bit vector loads are 16 / 32-byte accesses |
| `READ_LATENCY` | 1 | bank array read latency; ECC adds 1 |
| `NUM_MASTERS` | 4 | 1..16; the default class map is 0 CTRL, 1 TENSOR, 2 VECTOR, 3 DMA (`MCLASS`) |
| `ENABLE_ECC` | 0 | SECDED per physical word inside every bank (72,64 for the 64-bit word) |
| `NSLOT` | 8 | outstanding requests per master = depth of the bounded queue |
| `ISSUE_WINDOW` | 1 | requests per master whose words may be issued out of order (1 = strictly in order) |
| `INTERLEAVE_MODE`, `ILV_GRAN_LOG2` | LOW, 0 | address interleaving (see ADDRESS_MAP.md) |
| `MISALIGN_EN` | 1 | 1: any byte address, split over the words; 0: natural alignment required (`SF_ST_ALIGN`) |
| `NUM_REGIONS`, `DEFAULT_ALLOW` | 0, 1 | permission regions; bytes outside every region |
| `ARB` | RR | `SF_ARB_RR` or `SF_ARB_FIXED` (kept for comparison; can starve) |
| `BACKEND`, `SCRUB_EN`, `SCRUB_WAIT`, `INIT_ON_RESET`, `SIM_INIT`, `FAULT_INJECT` | behavioural, 0, 64, ENABLE_ECC, 2, 0 | passed to the banks, see the existing package's documentation |

`K` (words one access can touch) is derived: `(DATA_WIDTH/8 + 2*WORD_BYTES - 2) / WORD_BYTES` with `MISALIGN_EN = 1`, e.g. 5 for 256-bit accesses on 64-bit
words; `ceil(DATA_BYTES / WORD_BYTES)` with `MISALIGN_EN = 0`. Elaboration fails (`$fatal`) for an unsupported combination.

## 3. Master port (superset of the `sf_sram_controller` master port)

Request: `m_req_valid/ready, m_req_we, m_req_addr[AW] (byte), m_req_size (log2 bytes), m_req_wdata, m_req_be, m_req_id, m_req_prot {secure, priv}`.

* **Read**: bytes `[addr, addr + 2^size)` come back in `rdata` lanes `0 .. 2^size-1`; the lanes above are 0. `be` is ignored (as for the controller, whose clients drive
  `be = 0` on reads).
* **Write**: byte `j < 2^size` with `be[j] = 1` is written; `be[j] = 0` bytes are never modified; `be == 0` is an acknowledged no-op. Lane `j` is the byte at `addr + j`
  (relative lanes), so a misaligned access needs no pre-shifting by the master.
* `m_req_ready` depends on **registered state only** (a free slot, flush, quiesce): never on `m_req_valid`, on other masters or on the arbiters. It is exactly
  `outstanding < NSLOT` (checked on every cycle by the testbench; a bounded model check of a tiny configuration found no counterexample up to the depth stated in VERIFICATION.md, it is not an unbounded proof).
* Response: `m_rsp_valid/ready, m_rsp_rdata, m_rsp_id, m_rsp_we, m_rsp_status, m_rsp_ce`. One response per accepted request, in acceptance order, stable until accepted.

Drop-in use: with `DATA_WIDTH` = the controller's line width (128), `m_req_size` tied to 4, `m_req_prot` tied to 2'b11 and aligned addresses, the existing
`sf_vector_scratchpad` and `sf_tensor_scratchpad` run unchanged on the matrix: their **original testbenches** pass on it (RTL-SIMULATION, 10 configurations, see VERIFICATION.md).

Status codes (`sf_sram_defs.svh` plus `SF_ST_PERM = 6`): `OK 0, RANGE 1, ALIGN 2, ECC_UE 3, OWNER 4 (adapters), BADOP 5, PERM 6`. Precedence: BADOP > RANGE > ALIGN > PERM.
A rejected request causes no array access, returns `rdata = 0`, and still produces exactly one in-order response.

## 4. How a request is processed

1. **Decode** (combinational, per master): size legality, last-byte bounds check (no wrap-around), alignment, permission of the first and last byte, the physical
   `(bank, row)` of each of the K words the access can span.
2. **Split**: write data and byte enables are shifted to their word lanes (`wd << 8*offset`), giving per-word 64-bit data and 8-bit byte masks. A word with no active byte
   is not accessed (no spurious bank cycle, no spurious ECC read-modify-write).
3. **Slot**: the request is stored in a slot (`NSLOT` per master). The slot is simultaneously the request queue entry and the reorder-buffer entry; it is allocated at
   accept, which is what makes the response path always able to accept bank responses (the banks have no response ready).
4. **Issue**: words are offered to their banks, one pending word per (master, bank) per cycle (the oldest). With an empty queue the request is issued in the cycle it is
   accepted (cut-through). With `ISSUE_WINDOW > 1` words of younger requests may be offered while an older request waits for a busy bank.
5. **Arbitration**: each bank's arbiter grants at most one master per cycle and only when the bank is ready; the granted word's row, data, byte mask and tag
   `{master, slot, word}` drive the bank request. A single-port bank therefore never sees more than one operation per cycle: no multiport behaviour is synthesised.
6. **Response**: bank responses are matched to `(master, slot, word)`; read words are stored, status / corrected-error flags accumulate (`ECC_UE` wins). When all needed words
   of the oldest slot have answered, the bytes are masked and shifted back to lane 0 and the response is presented.

## 5. Contract (what the tests check)

| rule | statement |
|---|---|
| M1 | Per master, **conflicting accesses stay in program order**: two accesses to the same word reach the bank in acceptance order (RAW, WAW, WAR hold). With `ISSUE_WINDOW = 1` all words of a request issue before the next request starts. With a window, words of different banks may pass each other; same-word order follows from one word being one bank and a master offering its oldest pending word of a bank first. |
| M2 | Responses of one master return in acceptance order, errors included. |
| M3 | Per-bank serialisation: a read accepted by a bank at edge *t* sees every write accepted by that bank at edges < *t*, across all masters. |
| M4 | Atomicity is **one word** (one bank access). A request spanning several words is a set of independent word accesses; another master can observe it half performed. No atomicity across requests. The ECC read-modify-write of a partial word write is atomic inside the bank. |
| M5 | No coherence, no locks. A producer hands data over by waiting for the write response. |
| M6 | Fairness: round robin per bank; a master that keeps requesting a ready bank is granted within `NUM_MASTERS` grants (FORMAL, bounded and by induction for the arbiter). |
| M7 | `flush_i`: no new accept, no more issue, in-flight words retire, all slots are discarded, no response from the flush cycle on. Accepted words **stay written** (torn writes possible). |
| M8 | Reset clears control state only. Memory contents are not reset (non-ECC); ECC builds re-initialise the arrays with the bank init engine. Masters keep `m_req_valid` low while `rst_n` is low. |

Latency of a lone request with an idle queue and free banks: `READ_LATENCY + (ECC ? 1 : 0) + 1` cycles from the accepting edge to the response handshake (checked exactly in T02).

## 6. Bounded queues and back-pressure

Per master `NSLOT` outstanding requests, then `m_req_ready = 0`. Response back-pressure (`m_rsp_ready = 0`) fills the slots and so stops the request side; nothing is dropped
or reordered. A master can keep one request per cycle in flight only if its slots cover the round trip; `NSLOT >= READ_LATENCY (+1 ECC) + 3` is the condition under which test T04 requires one request per cycle per master (it is *sufficient*, necessity was not established). `NSLOT = 2` and `3` configurations pass every functional test; their throughput was not benchmarked. `NSLOT = 16` and `READ_LATENCY = 2` made no measurable difference to the benchmark workloads at 4 and 16 banks.

## 7. Reuse of existing SilicaFlux modules

| reused (byte-identical) | used for |
|---|---|
| `sf_sram_core` | the single-port array and its explicit semantics (never reset, read-during-write policy, `SIM_INIT` poison image) |
| `sf_sram_bank` | request / response wrapper, SECDED + atomic RMW, init engine, scrubber, MBIST test port, CE / UE counters |
| `sf_sram_macro_wrapper` + backends | technology-aware integration: behavioural, FPGA block-RAM template, SKY130 macro tiling (with the labelled stand-in model) |
| `sf_ecc_enc/dec/counters`, `ras_secded` | the verified SECDED codec |
| `sf_vector_scratchpad`, `sf_tensor_scratchpad`, `sf_ts_port`, `sf_sync_fifo` | run on top of the matrix in the integration tests |
| `sf_sram_controller` | kept as the baseline in the benchmark comparison and as the origin of the master-port semantics |

Not reused: the controller's fixed 128-bit line interleave and its non-splitting master port were the reason for a new front end (configurable interleave, 64-bit words,
splitting of 128 / 256-bit, misaligned and bank-spanning accesses, permission metadata, richer instrumentation).
