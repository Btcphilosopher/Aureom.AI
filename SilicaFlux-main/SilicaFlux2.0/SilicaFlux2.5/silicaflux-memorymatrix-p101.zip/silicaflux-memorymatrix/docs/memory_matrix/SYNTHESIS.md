# SYNTHESIS and physical integration

**Two kinds of numbers are kept apart here.**

* **ACTUAL** (section 1): read from the Yosys log of this package's run (`reports/synth.json`, raw logs reproducible with `scripts/run_synth.py`). Yosys 0.71 (YoWASP build).
  Technology-independent or FPGA-mapped *structure counts*: cells, flip-flops, LUT4, block RAM primitives, longest topological path in generic gates.
* **ESTIMATE / ASSUMED** (section 3): a number that rests on an assumption stated next to it. Nothing in section 3 was measured; there is no place-and-route, no static timing
  analysis, no Liberty library, no SRAM macro timing in this repository.


## 1. ACTUAL: Yosys synthesis results

### 1.1 sf_memory_matrix (4 masters, 64-bit words, 256-bit master bus, `NSLOT = 8`, `ISSUE_WINDOW = 1` unless stated)

Flows: `generic` = `synth -flatten -run :fine`, `techmap`, `abc` to {AND, NAND, OR, NOR, XOR, XNOR, ANDNOT, ORNOT, MUX} (memories are **not** mapped: they stay `$mem_v2` RAM cells); `ecp5` = `synth_ecp5`. `ltp` = longest topological path in generic gates (a logic DEPTH, not a time; reported for the generic flow only: in the ECP5 netlist Yosys counts every carry-chain cell as a level, which is not comparable). The SRAM arrays are included: in the generic flow they are **left as RAM cells (`$mem_v2`) and not counted in the logic** (the flow stops before memory mapping, as the existing package's synthesis flow does; mapping them to flip-flops would give about 262k flip-flops and 1024:1 read muxes and says nothing about the architecture); in the ECP5 flow they are mapped to block RAM.

| configuration | flow | cells | flip-flops | LUT4 | RAM primitives | ltp (levels) | latches | seconds |
|---|---|---|---|---|---|---|---|---|
| nb16_nm4 | ecp5 | **ERROR** (see 1.3) | | | | | | 1142 |
| nb16_nm4 | generic | 519,053 | 19,817 | 0 | 16 x $mem_v2 | 108 | 0 | 302 |
| nb16_nm4_win4 | generic | 714,290 | 19,817 | 0 | 16 x $mem_v2 | 115 | 0 | 527 |
| nb4_nm4 | ecp5 | 114,217 | 17,565 | 84,085 | 16 x DP16KD | n/a | 0 | 525 |
| nb4_nm4 | generic | 205,929 | 17,533 | 0 | 4 x $mem_v2 | 106 | 0 | 111 |
| nb4_nm4_ecc | ecp5 | 127,336 | 18,513 | 91,430 | 16 x DP16KD | n/a | 0 | 432 |
| nb4_nm4_ecc | generic | 206,886 | 18,481 | 0 | 4 x $mem_v2 | 96 | 0 | 174 |
| nb4_nm4_win4 | generic | 293,396 | 17,533 | 0 | 4 x $mem_v2 | 110 | 0 | 185 |
| nb8_nm4 | generic | 324,792 | 18,297 | 0 | 8 x $mem_v2 | 105 | 0 | 177 |

### 1.2 The SRAM bank alone: is FPGA RAM inference preserved?

`sf_sram_bank` (1024 rows, 64-bit word, behavioural backend) through `synth_ecp5` and `synth_xilinx`:

| bank | flow | cells | flip-flops | LUT | RAM primitives |
|---|---|---|---|---|---|
| ecp5_nb4_w64 | ecp5 | 254 | 28 | 201 | 4 x DP16KD |
| ecp5_nb4_w64_ecc | ecp5 | 1,810 | 188 | 1,084 | 4 x DP16KD |
| generic_nb4_w64 | generic | 326 | 28 | 0 | 1 x $mem_v2 |
| generic_nb4_w64_ecc | generic | 1,587 | 188 | 0 | 1 x $mem_v2 |
| xilinx_nb4_w64 | xilinx | 108 | 186 | 496 | 4 x RAMB36E1 |
| xilinx_nb4_w64_ecc | xilinx | 108 | 526 | 1,860 | 4 x RAMB36E1 |

Reading: the bank array is **inferred as block RAM** (the array in `sf_sram_core` is a plain `mem[addr]` with one registered read and per-lane write enables, no reset): nothing in the
matrix defeats the inference, because the matrix touches the banks only through their request / response ports. The ECC bank keeps the array in block RAM and puts the codec and the
read-modify-write FSM in logic.

### 1.3 Findings

* All configurations in the table synthesized without latches (`latches` column) and without errors except: ecp5_nb16_nm4 (ERROR).
* **Total cell counts are only reliable to a few percent between configurations.** The plain and ECC 4-bank matrices differ by +957 cells in total, although four ECC banks must add several thousand gates (the bank alone grows by +1,261 cells, see 1.2): ABC restructured the large select trees differently in the two runs (AND+NAND -25,759, MUX+OR +23,170 at identical function). What does move reliably is the codec: XOR + XNOR cells 1,222 -> 3,312 (+2,090). Read the ECC cost from the bank-alone rows, the XOR / XNOR count and the ECP5 LUT delta (+7,345 LUT4, +948 flip-flops).
* `ecp5_nb16_nm4`: **ERROR, no result.** `synth_ecp5` completed but the final `ltp` pass overflowed the WASM call stack on the deep carry-chain netlist (`wasm trap: call stack exhausted`) after 19 minutes; the run was not repeated without `ltp` for time. The ECP5 flow therefore has results for the 4-bank matrix and the 4-bank ECC matrix only (`ltp` was removed from the ECP5 flow afterwards).
* **`ISSUE_WINDOW = 4` is expensive**: it adds only combinational logic (the flip-flop count is unchanged) but +87,467 generic cells at 4 banks (42 %) and +195,237 at 16 banks (38 %), with a longest path that grows by +4 / +7 levels. The measured bandwidth gain (BENCHMARKS.md section 5) has to be weighed against this.
* **The flip-flops (17.5 k at 4 banks, 18.3 k at 8, 19.8 k at 16) are almost all the per-master slot tables**: 4 masters x `NSLOT = 8` entries, each holding the pre-shifted write
  / read data (5 words x 64 bit for a 256-bit bus), byte masks, bank / row of each word, status. They barely grow with the bank count (the banks add only their small FSMs and counters); the
  SRAM arrays are RAM cells (generic flow) or block RAM (ECP5 flow), not flip-flops. Area levers that were **not** explored: fewer or narrower slots (`NSLOT`, `DATA_WIDTH`), storing write data
  unshifted and shifting at issue, and `MISALIGN_EN = 0` (one word fewer per access).
* ECC adds the encoder / decoder / read-modify-write logic to every bank (see the bank-alone rows in 1.2).
## 3. ESTIMATE / ASSUMED (not a measurement)

The only timing-related quantity Yosys gives is `ltp`, the longest path in generic gates. Converting it to a time needs a gate delay, which **this repository does not supply**.
For orientation only, assume **30 ps per generic-gate level** (an arbitrary round number for a modern mid-size logic process; NOT a library value, NOT derived from any PDK here):

| configuration (generic flow) | ltp levels | ASSUMED logic delay |
|---|---|---|
| nb16_nm4 | 108 | ~3.2 ns (levels x 30 ps) |
| nb16_nm4_win4 | 115 | ~3.5 ns (levels x 30 ps) |
| nb4_nm4 | 106 | ~3.2 ns (levels x 30 ps) |
| nb4_nm4_ecc | 96 | ~2.9 ns (levels x 30 ps) |
| nb4_nm4_win4 | 110 | ~3.3 ns (levels x 30 ps) |
| nb8_nm4 | 105 | ~3.1 ns (levels x 30 ps) |

**What the longest path actually is (read from the `ltp` reports of these runs).** In five of the six generic runs it **starts at a master request input (`m_req_size`) and ends at bit 31 of a 32-bit
`c_lost` performance counter**, in the sixth at an arithmetic (`maccmap`) cell of the same kind: it runs through the decoder, the per-bank requester count and a 32-bit ripple adder
(`c_lost + requesters - accepted`). So the depth in the table is **set by the instrumentation's counter adder, not by the memory datapath**; the datapath path (decode -> per-bank selection -> arbiter ->
bank request) is shorter and was **not separately extracted** (that would need the counters excluded, or a static timing run). A cheap improvement that was not made: register the per-bank
requester count and accepted flag before the counter adders (or narrow / pipeline the counters), which would remove them from the longest path at the cost of one cycle of counter skew.
`m_req_ready` is not on any combinational request path (it depends on registered state only). **A real clock frequency needs the SRAM macro access time and setup (unknown here), wire delay and
clock tree; none can be estimated honestly from this data.** The numbers above must not be quoted as Fmax.

Other assumptions that are NOT results: block-RAM counts depend on the target FPGA's primitive size (ECP5 DP16KD 16 kbit, Xilinx RAMB36E1 36 kbit); the area of an ASIC implementation is
unknown (no standard-cell library; macro areas from the existing package's manifests were not used).
