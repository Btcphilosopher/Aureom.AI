# VERIFICATION

Labels: **RTL-SIMULATION** = Verilator 5.49 two-state simulation; **FORMAL** = SymbiYosys + z3 (BMC is bounded, `prove` is unbounded k-induction). Every table below is generated from `reports/*.json` by `tests/memory_matrix/make_verification_md.py`; re-run the commands in the README to reproduce. Nothing is a silicon result.

## 1. Method

* **Independent byte-addressable reference model** (`tests/memory_matrix/tb_memory_matrix.sv`): a byte image of the whole aperture plus a *known* flag per byte, so nothing is assumed
  about power-up contents (non-ECC arrays are unknown until written; ECC arrays are known-zero only after the init engine has run). A power-up poison image (`SIM_INIT = 2`) is used and T01
  checks the array is not silently zero.
* The expected **bank, row, word and bytes** of every access are derived from the *byte address alone* with the testbench's own integer arithmetic (divide / modulo), not from the DUT's
  decoder. The model is applied at the edge a bank **accepts** a word (trace port), the serialisation point of the bank; each accepted word is checked against its expected bank / row,
  for double access and for spurious access (a word with no active byte).
* At each response: order, id, `we`, status (predicted from the specification: BADOP / RANGE / ALIGN / PERM), rdata lanes (known bytes only; lanes above the size and every error / write
  response must be 0), corrected-error flag, completeness (every expected word was accessed), and stability of a stalled response.
* **Per-master program order** of conflicting accesses (M1) is checked from the request stream alone (the byte model follows the DUT's accept order and cannot see a reordering).
* **Bounded queue**: `m_req_ready == (outstanding < NSLOT)` is checked on **every cycle** (registered-state-only back-pressure).
* **Performance counters** are mirrored (accesses per bank, useful bytes, latency sum, requests, rejects, cycles) and compared for **exact equality** at the end of each window.
* Every DUT input is driven by one clocked process (found necessary: a second driver raced with the model at the clock edge).
* The existing adapters' **original testbenches** run on the matrix (section 5).

## 2. Test list (tb_memory_matrix)

| id | content |
|---|---|
| T01 | reset and power-up: no stale response, free queue, counters, poison image not zero (non-ECC) / init image zero (ECC) |
| T02 | all sizes x byte offsets, bank-spanning, exact lone-request latency (`READ_LATENCY + ECC + 1`) |
| T03 | address boundaries: first / last byte and word, access straddling the end, address == capacity, top of the address space, illegal size, alignment, rejected writes have no effect, `be = 0` write |
| T04 | simultaneous independent banks: one master per bank, no conflicts, no arbitration stalls, one request per cycle per master (when `NSLOT` covers the latency), counters exact |
| T05 / T05b | same-bank collisions: single-port invariant (cycles >= accesses), round-robin fairness / fixed-priority behaviour, exact two-master conflict accounting |
| T06 | permission regions (privilege, secure, master mask, read-only, straddling access) |
| T07a-f | random traffic: full speed, request gaps + 50 % response ready, hot words across masters, narrow partial writes, full-width with 10 % response ready (queue full), bank-targeted |
| T08 | ECC: single-bit errors across the whole codeword, double-bit error, partial write onto an uncorrectable word (aborted), full write repair, RMW on a healthy word, event address, scrubber |
| T09 | six rounds of flush under heavy partially-issued traffic, quiesce |
| T10 | reset during traffic; memory contents persist (non-ECC) / init re-zeroes (ECC) |
| T11 | full-capacity read-back against the model |

## 3. Regression (RTL-SIMULATION)

**64 of 64 cases pass, 52,909,026 self-checks.**

### 3.1 System testbench: configurations

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| base_4b_64w_256d | defaults | 16 | 947,441 | 0 | PASS |
| nb8 | NUM_BANKS=8, BANK_DEPTH=128 | 16 | 934,825 | 0 | PASS |
| nb16 | NUM_BANKS=16, BANK_DEPTH=64 | 16 | 931,565 | 0 | PASS |
| nb2 | NUM_BANKS=2, BANK_DEPTH=256 | 16 | 830,087 | 0 | PASS |
| L2 | READ_LATENCY=2 | 16 | 952,392 | 0 | PASS |
| L3_nslot6 | READ_LATENCY=3, NSLOT=6 | 16 | 949,967 | 0 | PASS |
| ecc_L1 | ENABLE_ECC=1, BANK_DEPTH=128 | 17 | 943,865 | 0 | PASS |
| ecc_L2 | ENABLE_ECC=1, READ_LATENCY=2, BANK_DEPTH=128 | 17 | 943,937 | 0 | PASS |
| ecc_scrub | ENABLE_ECC=1, BANK_DEPTH=32, SCRUB_EN=1, SCRUB_WAIT=6 | 17 | 927,706 | 0 | PASS |
| ecc_nb8 | ENABLE_ECC=1, NUM_BANKS=8, BANK_DEPTH=64 | 17 | 938,202 | 0 | PASS |
| ecc_word32 | ENABLE_ECC=1, WORD_WIDTH=32, BANK_DEPTH=128 | 17 | 995,530 | 0 | PASS |
| ecc_word128 | ENABLE_ECC=1, WORD_WIDTH=128, BANK_DEPTH=64 | 17 | 918,040 | 0 | PASS |
| nm1 | NUM_MASTERS=1 | 15 | 224,033 | 0 | PASS |
| nm2 | NUM_MASTERS=2 | 16 | 489,639 | 0 | PASS |
| nm8_nb4 | NUM_MASTERS=8 | 16 | 1,644,671 | 0 | PASS |
| data64 | DATA_WIDTH=64 | 16 | 613,628 | 0 | PASS |
| data32 | DATA_WIDTH=32 | 16 | 570,425 | 0 | PASS |
| data128 | DATA_WIDTH=128 | 16 | 723,608 | 0 | PASS |
| data512_nb8 | DATA_WIDTH=512, NUM_BANKS=8, BANK_DEPTH=64 | 16 | 1,371,584 | 0 | PASS |
| word32 | WORD_WIDTH=32, BANK_DEPTH=256 | 16 | 1,000,799 | 0 | PASS |
| word128 | WORD_WIDTH=128, BANK_DEPTH=128 | 16 | 920,640 | 0 | PASS |
| misalign0 | MISALIGN_EN=0 | 16 | 911,106 | 0 | PASS |
| ilv_xor | INTERLEAVE_MODE=1 | 16 | 945,638 | 0 | PASS |
| ilv_xor_nb8 | INTERLEAVE_MODE=1, NUM_BANKS=8, BANK_DEPTH=128 | 16 | 935,647 | 0 | PASS |
| ilv_gran2 | ILV_GRAN_LOG2=2 | 16 | 954,291 | 0 | PASS |
| ilv_xor_gran1_nb16 | INTERLEAVE_MODE=1, ILV_GRAN_LOG2=1, NUM_BANKS=16, BANK_DEPTH=64 | 16 | 935,249 | 0 | PASS |
| ilv_linear | INTERLEAVE_MODE=2 | 16 | 948,797 | 0 | PASS |
| ilv_linear_dep100 | INTERLEAVE_MODE=2, BANK_DEPTH=100 | 16 | 927,121 | 0 | PASS |
| regions3 | NUM_REGIONS=3 | 16 | 776,225 | 0 | PASS |
| regions2_deny | NUM_REGIONS=2, DEFAULT_ALLOW=0 | 16 | 533,754 | 0 | PASS |
| arb_fixed | ARB=0 | 16 | 951,934 | 0 | PASS |
| win2 | ISSUE_WINDOW=2 | 16 | 947,198 | 0 | PASS |
| win4 | ISSUE_WINDOW=4 | 16 | 944,335 | 0 | PASS |
| win8_nb8 | ISSUE_WINDOW=8, NUM_BANKS=8, BANK_DEPTH=128 | 16 | 933,236 | 0 | PASS |
| win4_ecc_L2 | ISSUE_WINDOW=4, ENABLE_ECC=1, READ_LATENCY=2, BANK_DEPTH=128 | 17 | 941,497 | 0 | PASS |
| win4_nb16_xor | ISSUE_WINDOW=4, NUM_BANKS=16, BANK_DEPTH=64, INTERLEAVE_MODE=1 | 16 | 931,430 | 0 | PASS |
| win3_nslot3_misal0 | ISSUE_WINDOW=3, NSLOT=3, MISALIGN_EN=0 | 16 | 903,261 | 0 | PASS |
| nslot2 | NSLOT=2 | 16 | 951,965 | 0 | PASS |
| nslot3 | NSLOT=3 | 16 | 944,088 | 0 | PASS |
| depth100_nonpow2 | BANK_DEPTH=100 | 16 | 930,424 | 0 | PASS |
| seed2 | SEED=1592590338, NRAND=1200 | 16 | 1,503,674 | 0 | PASS |
| seed3_nb8_ecc | SEED=1592590339, ENABLE_ECC=1, NUM_BANKS=8, BANK_DEPTH=64, READ_LATENCY=2 | 17 | 941,022 | 0 | PASS |
| fpga_bram | BACKEND=1 | 16 | 942,885 | 0 | PASS |
| fpga_bram_ecc_L2 | BACKEND=1, ENABLE_ECC=1, READ_LATENCY=2, BANK_DEPTH=128, FAULT_INJECT=0 | 16 | 936,636 | 0 | PASS |
| asic_standin_L2 | BACKEND=2, READ_LATENCY=2, BANK_DEPTH=256 | 16 | 946,473 | 0 | PASS |

### 3.2 Address-map testbench (exhaustive)

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| dec_nb4_low | defaults | 1 | 1,217,590 | 0 | PASS |
| dec_nb8_xor | NB=8, DEPTH=32, MODE=1 | 1 | 1,217,590 | 0 | PASS |
| dec_nb16_low_g2 | NB=16, DEPTH=16, MODE=0, GRAN=2 | 1 | 1,217,590 | 0 | PASS |
| dec_nb4_linear | MODE=2, DEPTH=100 | 1 | 1,219,030 | 0 | PASS |
| dec_nb4_xor_g2 | MODE=1, GRAN=2, DEPTH=60, MISALIGN_EN=0 | 1 | 1,217,430 | 0 | PASS |
| dec_nb16_xor | NB=16, DEPTH=64, MODE=1, NRG=0, MISALIGN_EN=0, K=4 | 1 | 1,224,250 | 0 | PASS |
| dec_nb2_low | NB=2, DEPTH=128 | 1 | 1,217,590 | 0 | PASS |
| dec_word32 | LB=2, SZ_MAX=4, K=4 | 1 | 655,370 | 0 | PASS |
| dec_word128 | LB=4, SZ_MAX=6, K=5, DEPTH=32 | 1 | 2,360,758 | 0 | PASS |

## 4. Existing adapters on the matrix: their ORIGINAL testbenches

`sf_vector_scratchpad` and `sf_tensor_scratchpad` with the byte-identical original testbenches (controller block replaced by `sf_memory_matrix`, see `make_integration_tb.py`). `MM_WORD_P = 128` gives the matrix the controller's line width; `64` runs the same line as two rows of one bank.

| case | overrides | tests | checks | errors | status |
|---|---|---|---|---|---|
| int_vsp_w128 | defaults | 1 | 11,013 | 0 | PASS |
| int_vsp_w64 | MM_WORD_P=64 | 1 | 11,013 | 0 | PASS |
| int_vsp_vl2_w128 | VEC_LINES=2 | 1 | 11,501 | 0 | PASS |
| int_vsp_vl4_w64 | VEC_LINES=4, MM_WORD_P=64 | 1 | 11,497 | 0 | PASS |
| int_vsp_ecc_w128_L2 | ECC_EN=1, READ_LATENCY=2 | 1 | 11,013 | 0 | PASS |
| int_vsp_ecc_w64 | ECC_EN=1, MM_WORD_P=64 | 1 | 11,013 | 0 | PASS |
| int_tsp_w128 | defaults | 1 | 1,077 | 0 | PASS |
| int_tsp_w64 | MM_WORD_P=64 | 1 | 1,077 | 0 | PASS |
| int_tsp_ecc_w128 | ECC_EN=1 | 1 | 1,077 | 0 | PASS |
| int_tsp_nb8_w64 | NB=8, MM_WORD_P=64 | 1 | 1,077 | 0 | PASS |

## 5. Mutation testing of the testbench

One deliberate fault per mutant is injected into a private copy of the matrix RTL; the testbench must fail. **32 of 32 mutants killed.**

| mutant | status | caught by | models |
|---|---|---|---|
| dec_last_gt | KILLED | ERROR @cyc 927: bank 0 accessed for a request that must be rejected (status 1) | boundary off-by-one: an access whose last byte is the first byte past the end is accepted |
| dec_last_plus1 | KILLED | ERROR @cyc 898: m0 status 1 expected 0 (addr 8191 size 0 we 1) | last byte computed one too high: legal accesses at the very end are rejected |
| dec_perm_first | KILLED | ERROR @cyc 4391: bank 0 accessed for a request that must be rejected (status 6) | permission checked on the first byte only (straddling access slips through) |
| dec_align_inv | KILLED | ERROR @cyc 9: m0 status 2 expected 0 (addr 0 size 3 we 0) | alignment check inverted |
| dec_perm_status | KILLED | ERROR @cyc 963: m0 status 2 expected 6 (addr 4256 size 3 we 1) | wrong status code for a permission fault |
| dec_badop_missing | KILLED | ERROR @cyc 936: bank 0 accessed for a request that must be rejected (status 5) | illegal size accepted |
| mm_shift_resp | KILLED | ERROR @cyc 82: m0 READ MISMATCH addr 0+8 lane 0: got 2 exp 46 | read data re-alignment wrong by one byte |
| mm_shift_wr | KILLED | ERROR @cyc 98: m1 READ MISMATCH addr 65+1 lane 0: got b5 exp cd | write data not shifted to its byte lane (misaligned writes corrupt) |
| mm_be_ignored | KILLED | ERROR @cyc 951: m0 slot 4: SPURIOUS word access k=0 (expected mask 0000000000000000) | byte enables ignored: partial writes become full writes |
| mm_queue_depth | KILLED | ERROR @cyc 2888: m0 m_req_ready=0 but outstanding=7 (NSLOT=8) | bounded queue one entry short (back-pressure error) |
| mm_double_issue | KILLED | ERROR @cyc 733: m0 slot 3: word k=0 accessed twice | words issued in the accepting cycle are issued again (double access) |
| mm_ue_dropped | KILLED | ERROR @cyc 16500: m0 status 0 expected 3 (addr 328 size 3 we 0) | uncorrectable ECC status lost |
| mm_ce_dropped | KILLED | ERROR @cyc 16329: m0 ce flag 0 unexpected | corrected-error flag lost |
| mm_wr_rdata | KILLED | ERROR @cyc 78: m0 non-read / error response with rdata != 0 | write response carries data |
| mm_row_queued | KILLED | ERROR @cyc 2881: m2 word 532 went to row 132, expected 133 | row corrupted on the queued (non cut-through) path |
| mm_rd_word0 | KILLED | ERROR @cyc 71: T01: power-up image is all zero although SIM_INIT=2 (poison) was requested | read data of word 0 never stored |
| mm_tag_slot | KILLED | hang/timeout | responses routed to slot 0 |
| mm_id_inv | KILLED | ERROR @cyc 10: m0 id ff expected 0 | transaction id corrupted |
| mm_flush_noclr | KILLED | ERROR @cyc 15467: T09: response presented during flush | flush never discards the slots |
| mm_ev_addr | KILLED | ERROR @cyc 16975: T08: ev_addr 3bf, expected 3b8 | ECC event address off inside the word |
| mm_selw_dup | KILLED | hang/timeout | two words of one request to the same bank selected in one cycle |
| mm_cand_done | KILLED | hang/timeout | request retired while word 0 is still pending (lost word) |
| mm_need_word0 | KILLED | ERROR @cyc 921: bank 0 accessed for a request that must be rejected (status 1) | spurious access of word 0 for sparse byte enables |
| arb_ptr_stuck | KILLED | ERROR @cyc 4885: T05: round-robin unfair: mean latencies range 2..30 | round-robin pointer never rotates (fixed priority) |
| arb_ignore_ready | KILLED | [9425000] %Error: sf_memory_matrix.sv:745: Assertion failed in tb_memory_matrix.dut.unnamedblk29: sf | grant while the bank cannot accept (RMW busy) |
| perf_bytes_swap | KILLED | ERROR @cyc 2877: T04: perf bytes_rd[0] dut=6016 mirror=5984 | write bytes counted as read bytes and vice versa |
| perf_lat_off | KILLED | ERROR @cyc 2877: T04: perf lat_sum[0] dut=4500 mirror=3000 | latency sum off by one per request |
| perf_conf_ge3 | KILLED | ERROR @cyc 5694: T05b: bank 0 conflict cycles 0 of 806 (two masters requesting continuously) | two-way bank conflicts not counted |
| win_youngest_first | KILLED | ERROR @cyc 3750: PROGRAM ORDER: m3 request #2118 word 708 overtook older request #2116 (we 1/0) on t | per-bank selection takes the YOUNGEST word first: a master's own same-word accesses are reordered (breaks per-address program order) |
| win_grant_route | KILLED | hang/timeout | words granted to a younger request recorded on the wrong window slot |
| win_valid_off | KILLED | ERROR @cyc 15134: m2 slot 2: SPURIOUS word access k=0 (expected mask 0000000000000000) | window includes one unallocated (stale) slot |
| map_xor_fold | KILLED | ERROR @cyc 24: m0 word 4 went to bank 0, expected 1 | XOR hash folds the wrong row bits (aliasing) |

**What mutation testing found in the testbench itself** (all fixed, listed because they show what the tests did *not* check at first):

1. `perf_conf_ge3` survived: conflict counters were only bounded, never compared exactly. Added T05b (exact two-master accounting).
2. Two window mutants (`hazard check removed`) survived even after a program-order checker was added. Analysis showed they were **equivalent mutants**: two accesses to the same word are
   accesses to the same bank and the per-(master, bank) selection already takes the oldest first, so the extra hazard logic was dead. It was **deleted from the RTL**, and replaced
   by the mutant that really breaks the mechanism (`win_youngest_first`), which the new program-order checker kills with a precise diagnostic.
3. `win_valid_off` (a stale slot left after a flush) survived a single flush test; the flush test now runs six rounds under heavy partially-issued traffic.
4. Order of conflicting accesses within one master (M1) was **not checked at all** (the model follows the DUT's accept order); this applies to the in-order design as well.

Detection strength: most mutants are caught by a specific, named check (the message is in the table). **Four are caught only by a hang** (`mm_tag_slot`, `mm_selw_dup`,
`mm_cand_done`, `win_grant_route`: the DUT deadlocks and the 240 s run limit expires; the testbench's own drain time-outs also fire). That is a weaker form of detection than a
mismatch report and means the testbench would not localise those faults.

Not mutated: the reused third-party modules (they have their own regressions), and mutants of the testbench's expected values. A full kill count says nothing about faults nobody thought to inject.

## 6. Formal (SymbiYosys + z3)

**20 of 22 jobs PASS.** `bmc` is bounded to the stated depth; `prove` is an unbounded k-induction proof; the address-map jobs are stateless, so one step covers every input.

| job | mode | depth | status | seconds | note |
|---|---|---|---|---|---|
| map_nb4_d16_m0_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb4_d16_m0_g2 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb4_d16_m1_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb4_d12_m1_g2 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb8_d8_m1_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb8_d8_m0_g1 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb16_d4_m1_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb16_d8_m0_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb4_d6_m2_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb4_d5_m2_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| map_nb2_d8_m1_g0 | bmc | 1 | PASS | 1 | stateless: complete over all inputs |
| arb_rr_nm2 | bmc | 16 | PASS | 1 |  |
| arb_rr_nm2_prove | prove | 10 | PASS | 1 | unbounded (k-induction) |
| arb_rr_nm3 | bmc | 16 | PASS | 2 |  |
| arb_rr_nm3_prove | prove | 10 | PASS | 2 | unbounded (k-induction) |
| arb_rr_nm4 | bmc | 16 | PASS | 4 |  |
| arb_rr_nm4_prove | prove | 10 | PASS | 2 | unbounded (k-induction) |
| arb_rr_nm5 | bmc | 16 | PASS | 7 |  |
| arb_rr_nm5_prove | prove | 10 | PASS | 4 | unbounded (k-induction) |
| top_data_cover | cover | 12 | PASS | 4 | non-vacuity: the antecedent of the data-integrity assertion is reachable |
| top_data_nm1 | bmc | 11 | TIMEOUT | 1501 | time limit: BMC completed steps 0..6 (of 11 requested), no counterexample up to that depth (steps counted from 0; the cover job shows the checked scenario is reachable from step 4) |
| top_struct_nm2 | bmc | 10 | TIMEOUT | 1502 | time limit: BMC completed steps 0..8 (of 10 requested), no counterexample up to that depth |

**The formal properties can fail** (`reports/formal_mutants.json`): run against a map with the block-row shift one bit too small (aliasing) and against a round-robin pointer that always returns to 0,
`map_nb4_d16_m0_g0`, `arb_rr_nm3` (BMC) and `arb_rr_nm3_prove` (induction base case) all report FAIL. The data-integrity assertion is **not vacuous**: the job `top_data_cover` reaches its antecedent
(a read of the tracked byte answered after a write to it) at step 4, the minimum possible (reset, write, read, bank response, answer).

Properties: address map **bijective, in range, onto** (no aliasing); arbiter **exclusive, no grant while the bank is not ready, work conserving, round-robin bound** (unbounded, with an
inductive auxiliary invariant `others[k] + dist(ptr,k) <= NM-1`); tiny-configuration matrix: **exact bounded queue (`ready == outstanding < NSLOT`), conservation (no response without
a request), stalled-response stability, grant exclusivity** (2 masters) and **read-after-write data integrity of a symbolic byte** through the splitter / shifters / banks (1 master).
Both matrix-top jobs hit their 25-minute limit with z3 (`TIMEOUT` in the table): the structural job completed steps 0..8 and the data job steps 0..6 with **no counterexample**; nothing is claimed beyond those depths.
The array contents are unconstrained at start (nothing is assumed zero). Formal results are **bounded** for the matrix top (depth in the table) and say nothing beyond that depth or beyond
the tiny configuration (2 banks x 4 words, 16-bit words, 32-bit bus).

## 7. Defects found and fixed during verification

The first full regression (`reports/history/regress_first_full_run_42_of_48.json`) had **6 of 48 cases failing**. Honest classification:

| finding | where | what happened |
|---|---|---|
| **RTL defect** | `sf_memory_matrix_perf` / `sf_memory_matrix` | the per-bank requester count was a `ceil(log2(NM+1))`-bit field; for `NUM_MASTERS = 1` that is 1 bit, so the constant `2` of the conflict test truncated to 0 and **every cycle with a request was counted as a conflict**. Found by the `nm1` case (T04: 1507 conflicts with disjoint banks); fixed (field >= 2 bits). |
| RTL dead logic | issue window | a same-word hazard check was added and then **removed**: mutation testing showed it could never matter (same word = same bank, oldest word is always offered first). |
| testbench race | `tb_memory_matrix` | a second process drove DUT inputs at the clock edge and raced with the model (a perf-window clear was seen by the DUT but not by the mirror); all DUT inputs are now driven by one clocked process. |
| testbench race | `tb_memory_matrix` | checking was disabled in the same time step as a reset edge, so a write accepted at that edge was missing from the model (the DUT held the *newer* value). Requests are now withdrawn first and the checker runs through the reset edge. |
| testbench assumption | T04 / T05 / T03 / T08 / T10 | assumed a full-width word access on a 32-bit bus (size 8 B is `BADOP` there), that every request reaches a bank (permission denials do not), that an FPGA-backend configuration can inject faults, that a word written before a reset is untouched by later random traffic, and that fixed priority behaves like round robin. |
| testbench hole | whole TB | per-master program order (M1) was **not checked**; the exact conflict counters were only bounded; the stale-slot-after-flush case was untested. Found by the mutation campaign (section 5) and closed. |

No defect other than the first was found in the decoder, the arbiter, the splitter / shifters, the slot tables or the response path by the tests; that is a statement about what the tests exercised (see below),
not a proof of absence.

## 8. What the verification does NOT show

* Behaviour beyond the tested parameter sets (the matrix of configurations above is a sample, not all combinations).
* X-propagation / four-state behaviour (Verilator is two-state); gate-level and post-layout behaviour.
* The third-party banks' internals beyond what the matrix exercises (their own regressions are quoted, not re-run, except the controller testbench at `DW = 64`).
* Any property of the real silicon macros: the ASIC backend runs against a labelled stand-in model.
* Liveness / absence of deadlock beyond the bounded checks and the testbench's drain timeouts.
