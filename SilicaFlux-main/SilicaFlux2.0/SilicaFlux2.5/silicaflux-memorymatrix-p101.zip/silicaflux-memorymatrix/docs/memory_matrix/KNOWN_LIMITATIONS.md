# KNOWN LIMITATIONS

Ordered by how much they could mislead.

## Not done / not claimed

1. **No silicon, no physical timing, no power.** Every number is an RTL-simulation result, a Yosys synthesis count, an exact enumeration or an explicitly marked assumption. No Liberty,
   LEF, GDS, SPICE or PDK exists in the repository for the SRAM macros, and no place-and-route tool was available. See SYNTHESIS.md for the split between ACTUAL and ESTIMATE.
2. **Not ASIC-ready.** The ASIC backend is the existing SKY130 macro-tiling wrapper, simulated against the existing *stand-in* model. `BACKEND = 2` requires `READ_LATENCY >= 2`.
   FPGA block-RAM inference is not evidence for an ASIC macro.
3. **Formal results are bounded or tiny.** The matrix-top checks are bounded model checks of a 2-bank, 4-word, 16-bit-word configuration that hit their time limit (structural: steps 0..8, data integrity: steps 0..6, no counterexample; VERIFICATION.md). Only the address
   map (complete over all inputs for the stated sizes) and the arbiter (unbounded) have unbounded results.
4. **No comparison against `sf_sram_controller` on identical traffic** was run, and the SilicaFlux clients were not simulated: the workloads are synthetic address patterns shaped after
   their documentation.
5. **`silicaflux-memorycore1.zip` (`sfmem_*`) was not evaluated**, nor were the SFB3 data-fabric adapter (`sf_sram_datafabric`) and the MBIST sequencer run on top of the matrix. The
   matrix exposes the MBIST test port but it was not exercised.
6. The CloudDMA data width was assumed (256-bit stream), not read from its RTL.

## Behaviour to know about

7. **Multi-word requests are not atomic** (contract M4): another master can observe a bank-spanning write half done. No locks, no atomic read-modify-write operations, no coherence.
8. **Flush leaves accepted words written**, so a flushed multi-word write can be torn.
9. **Reset**: masters must keep `m_req_valid` low while `rst_n` is low; the array has no reset (an ECC build re-zeroes it with the init engine, which takes `BANK_DEPTH` cycles during which requests queue).
10. **ECC**: SECDED corrects 1 bit and detects 2; >= 3-bit errors may be miscorrected (inherited). Partial word writes cost `READ_LATENCY + 1` bank cycles. A partial write onto an
    uncorrectable word is aborted. ECC fault injection exists only for the behavioural backend.
11. **Permission metadata is not a security boundary**: `prot` bits are taken at face value, the region table is static configuration, there are no lock bits and no regions per
    byte-lane.
12. **No latency-priority class.** A ControlCore request shares the per-bank round-robin arbiter with streaming masters. In the `mix_system` benchmark its mean latency stays low
    (3.9 cycles at 4 banks) only because its load is light.
13. **`ARB = SF_ARB_FIXED` can starve** lower-priority masters (kept for comparison).
14. **In-order issue loses throughput to head-of-line blocking** (random 8-byte traffic: 65 % of the offered load at 4 banks). `ISSUE_WINDOW > 1` recovers much of it but costs area
    (+42 % generic cells at 4 banks, +38 % at 16 for `W = 4`) and is not always positive (a 4-bank GEMM mix drops 3 % with `W = 8`).
15. **Placement matters.** A pitch that is a multiple of the bank count (column walks), or a one-word skew for 4-word vector accesses, can cost 60-75 % of the bandwidth. The planner
    (`mm_layout.py`) helps only if software uses it.
16. `m_req_ready` is exact (`outstanding < NSLOT`), so a master cannot rely on "ready until the response is back" for more than `NSLOT` requests; `NSLOT >= READ_LATENCY + (ECC) + 3`
    is sufficient for one request per cycle per master (necessity and the throughput of `NSLOT` 2 / 3 were not measured).
17. A 4-byte (or smaller) access still costs one whole 8-byte bank access (useful fraction 50 % or less); a misaligned 256-bit access reads 5 words for 32 bytes (80 %).
18. `perf_*` counters are 32-bit and wrap (not saturating); windows are expected to be far shorter than 2^32 cycles.

## Toolchain notes

* Verilator 5.49 from a pip wheel needed `-CFLAGS -std=c++20` and `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include` (its precompiled-header configuration is empty); `scripts/vbuild.sh` and `VEXTRA` carry this.
* Yosys 0.71 (YoWASP build) asserts in `hierarchy` when `-chparam` is used on this code base (`sf_sram_bank` with ECC); the synthesis script therefore patches parameter *defaults* in a private copy
  (and uses a literal-parameter wrapper for the bank alone). It also only sees its working directory, so SBY jobs list all sources under `[files]`.
* The third-party `sf_sram_core` uses `$error` under `SF_ASSERT`, which Yosys cannot elaborate; the formal flow uses the matrix's own guard `SF_MM_ASSERT` instead.
* Simulation is two-state: X behaviour is not exercised (`SIM_INIT = 2` fills the arrays with a poison pattern instead).
