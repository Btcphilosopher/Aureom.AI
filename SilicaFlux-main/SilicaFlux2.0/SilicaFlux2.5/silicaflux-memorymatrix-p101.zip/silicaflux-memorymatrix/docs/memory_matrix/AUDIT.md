# AUDIT of the existing SilicaFlux memory code

Scope: what exists in the repository, what is implemented, what is tested, and what this package reused, changed or did not examine.
"VERIFIED HERE" means a command in this package was run and its output is in `reports/`; "CLAIMED" means it is a statement of the existing package's own
documentation that was not re-run here.

## 1. Where the code is

The repository has **no HDL source tree at its root**: SilicaFlux is stored as ZIP archives, many nested (`SilicaFlux-main/`, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`).
The modules named in the brief live in:

| module (brief) | found in | note |
|---|---|---|
| `sf_sram_core.sv`, `sf_sram_bank.sv`, `sf_sram_controller.sv`, `sf_sram_macro_wrapper.sv` | `silicaflux-memorycore-sram.zip` (the copy in `SilicaFlux-main/` and the one in `SilicaFlux2.5/` are **byte-identical**, SHA-256 `b6a9b5ed...`) | the baseline used here |
| `sf_sram_datafabric.sv` | same archive; also `silicaflux-sramfabric-p74.zip` | SFB3 target adapter |
| `sf_sram_ecc.sv` | **only** `silicaflux-eccmemory-p77.zip` (`sf_sram_ecc*.sv`: ecc, ram, scrub, ras, sys, fi) | a stand-alone ECC-RAM system; not used, see 3 |
| "TensorScratch", "VectorScratch" | `sf_tensor_scratchpad.sv`, `sf_ts_port.sv`, `sf_vector_scratchpad.sv` in the memorycore archive | integrated and tested here |
| ControlCore / TensorCore / vector engine / CloudDMA | `silicaflux-controlcore.zip` (RV32IM MCU on an SFB2 crossbar), `silicaflux-tensorcore08` (4x4 INT8 systolic, 8x8 / 2x2 configurable), `silicaflux-hpc-m03-vector-array.zip` (FP32, 1..16 lanes), `silicaflux-clouddma-p64.zip` | client widths taken from their READMEs / interface documents; the CloudDMA data width was **not read from its RTL** and is assumed to be a 256-bit stream |

Other memory variants found and **inventoried only, not used**: p71 `sramcore`, p72 `srambank` (bank array, address decode, perf), p73 `sramcontroller` / `sf_sram_subsystem`,
p79 `srammacrobridge`, p80 `sramlab`, p33 `sramgrid` (`silicaflux_sram_macro_wrapper`), `memoryflow` (a different `sf_sram_bank`), HPC m04 `hpc_scratchpad`, the legacy
`memory_controller.sf`. **`silicaflux-memorycore1.zip`** (`sfmem_*`, 411 files, with its own memory-map generator and HPC-system integration) is a separate, larger memory subsystem
that was **not evaluated** at all; whether it should replace or complement this work is an open question.

## 2. What is implemented and tested (baseline `silicaflux-memorycore-sram`)

| module | implemented | evidence |
|---|---|---|
| `sf_sram_core` | single-port 1RW, byte enables, explicit read-during-write policy, `READ_LATENCY >= 1`, array never reset, `SIM_INIT` poison image, simulation-only fault models | CLAIMED: 52/52 regression cases. **VERIFIED HERE**: rebuilt with Verilator 5.49 and re-ran the controller testbench at `DW = 64`: 172,228 checks, 0 errors (`reports/baseline_controller_dw64.log`) |
| `sf_sram_bank` | wrapper with SECDED, atomic RMW for partial writes, init engine, scrubber, MBIST test port, CE / UE counters | CLAIMED (their ECC suite). Exercised heavily here through the matrix (all ECC configurations) |
| `sf_sram_controller` | 4 banks x 128-bit lines, fixed line interleave, per-bank arbitration, reorder slots, ids, flush / quiesce, counters | CLAIMED 21/21 configurations. VERIFIED HERE (one configuration). |
| `sf_sram_macro_wrapper` + backends | behavioural / FPGA block-RAM template / SKY130 macro tiling with a labelled **stand-in** model | exercised here (all three backends elaborate and pass the system testbench; the ASIC one only against the stand-in) |
| `sf_vector_scratchpad`, `sf_tensor_scratchpad` | sub-word / multi-line vector access, DMA address generator, ping-pong ownership FSM | their ORIGINAL testbenches re-run here on top of the matrix: 10 / 10 pass |
| `sf_sram_datafabric` (SFB3 adapter) | lane steering, `(src,id)` pinning | CLAIMED (behind the real NoC). **Not re-run** here (needs the NoC sources); not integrated |
| `sf_sram_mbist_ctl` | March C- sequencer | CLAIMED. The matrix exposes the MBIST test port; the sequencer was **not** attached or tested |

## 3. What is missing for the brief (the gap this package fills)

| brief requirement | existing | this package |
|---|---|---|
| 4 / 8 / 16 banks | controller has `NB`; fixed 128-bit lines, only line interleave | `NUM_BANKS` 2..32, 64-bit words, three interleave modes with a granule |
| byte-addressed map with word / bank / row / offset / bounds / permission metadata | line map + RANGE / ALIGN | full decoder, permission regions, formal no-aliasing proof |
| 128 / 256-bit loads, partial vector writes, misalignment, bank spanning | `sf_vector_scratchpad` splits **aligned** vectors itself (the controller rejects misaligned) | split inside the matrix, any byte address |
| bank conflicts, bytes / cycle, average latency, arbitration stalls, tensor / vector starvation, read / write utilisation | `acc`, `conf`, `busy`, per-master stall | `sf_memory_matrix_perf` (class aware, latency, bytes, utilisation) |
| tensor placement analysis | tensor scratchpad has a bank-skew switch | exact enumeration + a layout planner + RTL measurement |
| head-of-line blocking | in-order, one request per master | optional `ISSUE_WINDOW` |

Why `sf_sram_ecc.sv` (P77) was not used: the memorycore bank already contains the verified SECDED path (encoder / decoder wrappers, atomic RMW, scrubber, counters)
and is the module the controller is built on; P77's `sf_sram_ecc*` is a separate ECC-RAM system with its own RAS block. Using it would have placed a second ECC wrapper around an
array that already has one. The leaf codec is the same (`sfras_secded_*`).

## 4. What was NOT changed

No existing file was modified. Reused files are copied **byte-identical** into `rtl/memory/third_party/` (`SHA256SUMS`, `PROVENANCE.md`); the original testbenches are
copied unchanged and the two integration testbenches are generated from them by replacing only the controller instantiation
(`tests/memory_matrix/make_integration_tb.py`, which fails if the original text no longer matches).

## 5. Findings about the existing code that matter for integration

* The controller **ignores `be` on reads** and its clients drive `be = 0`; a master port that treated `be` as a read mask would break them. The matrix therefore has an explicit
  `size` field.
* The controller **rejects unaligned addresses** (`SF_ST_ALIGN`); misaligned access is possible only through the adapters. The matrix accepts any byte address.
* `sf_sram_bank` has **no response ready**: the consumer must always accept. The matrix reserves the storage at accept time, which is why a slot is both queue entry and
  reorder buffer.
* The array has **no reset**; a request issued while `rst_n` is low would still write it. The matrix contract requires masters to keep `m_req_valid` low during reset
  (found and fixed in the testbench, documented as M8).
* Two different packages called `silicaflux_pkg` exist in the repository (known to the existing documentation); this package uses only `` `define `` headers and no packages.
