# ADDRESS MAP and ACCESS CHECKS

Implemented in `rtl/memory/sf_memory_matrix_decoder.sv`; the map functions are `rtl/memory/sf_mm_map.svh` (one text, included by the decoder and by the inverse map).

## 1. Byte address -> physical location

```
byte address a (AW bits, matrix-local; the fabric adapter strips the aperture base)
   offset  = a mod WORD_BYTES                      byte offset inside the physical word
   w       = a / WORD_BYTES                        word index          (an access spans words w .. w+K-1)
   {row, bank} = map(w)                            physical bank and LOCAL SRAM row
capacity = NUM_BANKS * BANK_DEPTH * WORD_BYTES bytes
```

Interleave modes (`INTERLEAVE_MODE`, granule `G = 2^ILV_GRAN_LOG2` words):

| mode | map | use |
|---|---|---|
| `SF_MM_ILV_LOW` | `bank = (w / G) mod NB`, `row = ((w / (G*NB)) * G) + (w mod G)` | streams; with `G = 1` and a power-of-two `NB` the bank is simply `w[BW-1:0]` and the row `w >> BW` (plain bit selection, no logic) |
| `SF_MM_ILV_XOR` | LOW, then `bank ^= fold(row)`, `fold` = XOR of the BW-bit slices of `row` | breaks power-of-two column strides (pitch 512) |
| `SF_MM_ILV_LINEAR` | `bank = w / BANK_DEPTH`, `row = w mod BANK_DEPTH` | software places operands in banks by address (A in bank 0, B in bank 1, ...) |

**No address aliasing.** For all three modes `map` is a bijection between `{0 .. NB*DEPTH-1}` and `{bank < NB} x {row < DEPTH}`:

* **FORMAL, complete for the instantiated configuration** (a stateless function checked for all inputs): `formal/memory_matrix/fv_mm_map.sv` proves
  `unmap(map(w)) == w` (injective), `bank < NB && row < DEPTH` (in range) and `map(unmap(b, r)) == (b, r)` (onto) for 11 configurations
  (NB 2 / 4 / 8 / 16, depths including non-powers-of-two 5, 6, 12, all three modes, granules 1 / 4 words).
* **RTL-SIMULATION, exhaustive**: `tests/memory_matrix/tb_mm_decoder.sv` visits every word index of 9 configurations, compares against an independent integer divide / modulo
  formulation, marks every (bank,row) in a bitmap (each exactly once, none missed) and round-trips through the inverse.
* **Mutation** (a manual campaign, not part of `reports/mutation.json`): three deliberately aliasing maps are all caught by that test: the XOR fold shifted by one bit (960 errors), the block-row shift one bit too small (1765 errors), and an inverse map without the XOR term (192 errors). The system-level mutant `map_xor_fold` is part of the automated campaign.
* The system testbench checks the bank and row of **every word access** against its own copy of the map.

## 2. Access checks (first match wins)

| status | condition |
|---|---|
| `SF_ST_BADOP` | `size > log2(DATA_WIDTH/8)` |
| `SF_ST_RANGE` | any covered byte `>= capacity`; computed from the **last byte** in `AW+2` bits, so an access cannot wrap around the address space |
| `SF_ST_ALIGN` | `MISALIGN_EN = 0` and `addr` not a multiple of `2^size` |
| `SF_ST_PERM` | the permission table denies the first or the last covered byte |

A failing request is never sent to a bank. Write data of a rejected write is dropped; a rejected read returns 0.

## 3. Permission metadata

`m_req_prot = {secure, privileged}`. `NUM_REGIONS` regions, each `[base, last]` (inclusive byte addresses), permission bits `{enabled, secure-only, priv-only, W, R}` and a
per-master allow mask (`rg_base_i, rg_last_i, rg_perm_i, rg_mmask_i`, static configuration ports). For a byte the **lowest-numbered enabled region** containing it decides; a byte in
no region follows `DEFAULT_ALLOW`. An access is allowed only if **both** its first and last byte are allowed, so an access straddling two regions needs both to permit it.
`NUM_REGIONS = 0` removes the logic. This is access-permission *metadata* checked in the memory front end; it is not a security boundary by itself (no authentication of the
`prot` bits, no region lock bits).

## 4. Byte lanes, misalignment, bank spanning

An access of `2^size` bytes at byte address `a` touches words `w .. w + ceil((offset + 2^size)/WORD_BYTES) - 1`. For 64-bit words:

| access | aligned | misaligned |
|---|---|---|
| 128-bit (16 B) | 2 words | 3 words |
| 256-bit (32 B) | 4 words | 5 words |

Under LOW interleave with `G = 1` consecutive words are in consecutive banks, so an aligned 256-bit access hits 4 different banks and issues in one cycle on 4, 8 or 16 banks.
A misaligned 256-bit access needs 5 words: on 4 banks words 0 and 4 share a bank (two cycles, counted as a self conflict), on 8 and 16 banks it issues in one cycle.
`MISALIGN_EN = 0` removes the extra word and the shifter range (natural alignment required).
Partial vector writes use sparse byte enables: only words with an enabled byte are written, and on ECC banks only those words perform a read-modify-write.
