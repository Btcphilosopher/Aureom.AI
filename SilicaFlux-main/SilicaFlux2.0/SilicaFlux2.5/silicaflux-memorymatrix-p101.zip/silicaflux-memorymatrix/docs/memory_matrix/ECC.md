# ECC in the MemoryMatrix

`ENABLE_ECC = 1` turns on the **existing, previously verified SilicaFlux SECDED logic** inside every bank: `sf_sram_bank` instantiates `sf_ecc_enc` / `sf_ecc_dec`
(wrappers over the RAS project's `sfras_secded_*`). The matrix adds no new codec. For the 64-bit word the stored codeword is **72 bits** (SECDED 72,64: 64 data + 7 check + 1 overall
parity, 12.5 % more storage); for 32 / 128-bit words 39 / 137 bits.

## What the matrix relies on, and what it tested itself

| requirement | how it is met | evidence in this package |
|---|---|---|
| data encoding | every full-word write is encoded by the bank | all ECC random phases; the testbench checks every read against the byte model |
| data correction | a single-bit error in any stored bit (data or check) is corrected on read, `m_rsp_ce = 1`, `ce_cnt_o[bank]` increments | T08: single-bit errors injected at stored bit positions across the whole codeword, data compared |
| double-bit error reporting | `m_rsp_status = SF_ST_ECC_UE`, the data is **not** valid, `ue_cnt_o[bank]` increments | T08: double-bit injection |
| partial writes | **atomic read-modify-write inside the bank**: the bank accepts nothing else for `READ_LATENCY + 1` cycles, so no other access can see or change the word in between. A byte write is never applied to a codeword directly. | T07d / random partial writes on ECC configurations against the byte model; T08 byte writes at every offset; benchmark busy-cycle counters |
| partial write onto an uncorrectable word | the write is **aborted** (word left as found), the response carries `SF_ST_ECC_UE`; a **full-word** write needs no old data and repairs it | T08 (`send_ovr` with `no-apply`, then repair and read-back) |
| uninitialised memory | the bank init engine writes valid-ECC zero words after reset (`INIT_ON_RESET`, default = `ENABLE_ECC`); `req_ready` of a bank stays low meanwhile, so requests queue. Check-bit inversion makes an *uninitialised* all-zero word decode as uncorrectable, so a never-written row can not be read as valid data | T01, T10 (re-zeroed after reset) |
| scrubbing interface | `SCRUB_EN = 1` and `scrub_en_i`: at most one scrub step per `SCRUB_WAIT` cycles, started only in a cycle in which no request is presented to that bank; a corrected word is written back; events are counted | T08 with `SCRUB_EN`: an injected single-bit error is found and repaired without any master access |
| error reporting | `ev_ce_o[b]`, `ev_ue_o[b]` pulses, `ev_addr_o[b]` = **byte address** of the failing word (bank row mapped back through the inverse address map), `ce_cnt_o`, `ue_cnt_o` (saturating, `ecc_clr_i`) | T08 checks `ev_addr_o` against the independent address model |

## Cost (measured, RTL-SIMULATION)

* One extra cycle of latency (`BANK_LAT = READ_LATENCY + 1`), checked exactly.
* A partial word write occupies its bank `READ_LATENCY + 1` cycles instead of 1. The matrix issues a write word as a partial write only when some, but not all, bytes
  of that word are enabled; a write that covers whole words is one array cycle. The benchmark tables report the busy-cycle counters.
* 8 check bits per 64-bit word. Sub-word reads still decode a whole word.

## Limits (inherited from the reused code, unchanged)

* SECDED corrects 1 bit and **detects** 2. **Three or more bit errors may be silently miscorrected** (the existing package measured 243 of 300 triple-bit words miscorrected).
  The testbenches do not claim detection of >= 3-bit errors.
* The codeword covers the whole physical word, no bit interleaving across words, no DEC-TED.
* Fault injection (`FAULT_INJECT = 1`, `seu_*`) exists only in the behavioural backend and is simulation-only; the FPGA and ASIC backends have no fault models, so the
  injection tests (T08) are skipped for them while the functional ECC traffic tests still run.
* Scrubbing finds errors only in rows it visits; the interval is `SCRUB_WAIT` cycles per row when the bank is otherwise idle.
