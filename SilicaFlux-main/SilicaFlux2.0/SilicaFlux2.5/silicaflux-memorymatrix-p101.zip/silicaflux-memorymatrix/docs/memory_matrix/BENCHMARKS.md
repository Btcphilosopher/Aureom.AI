# BENCHMARKS: 4 banks first, then 8 and 16 on identical workloads

All numbers are **RTL-SIMULATION** results (Verilator, two-state). They are not silicon, not timing, not power. Every table is generated from `reports/bench.json`
(`benchmarks/memory_matrix/run_bench.py`) into `BENCH_TABLES.md`; the numbers quoted below are copied from those tables.

## 1. Method

* 4 masters mapped to the SilicaFlux client classes (0 CTRL, 1 TENSOR, 2 VECTOR, 3 DMA), 64-bit words, 64 KiB footprint, 3000 requests per master, seed 1.
* The request stream is a **pure function of (workload, master, request index)**: it contains no bank number, so 4, 8 and 16 banks (and every interleave mode / ECC / window
  setting) see byte-identical traffic. The footprint is the same, so `BANK_DEPTH` shrinks as the bank count grows.
* Memory is pre-filled with `content(a) = hash(a)` through the DUT; every read of every run is checked against it (**0 integrity errors in 276 runs**).
* Counters are the DUT's own (`sf_memory_matrix_perf`), the makespan comes from the testbench. Definitions are in the header of `sf_memory_matrix_perf.sv`.
* The whole sweep was run **twice** (the second time after read / write utilisation was added to the report): every number the two runs have in common is identical (the simulation is deterministic).
* **Useful bandwidth** counts requested bytes only (read: `2^size`, write: enabled bytes). It is compared with the **offered load** (what the four masters could consume
  from an infinitely wide memory) rather than with the raw peak: a streaming workload that offers 32 B/cycle can never use more than 32 B/cycle of a 128 B/cycle memory,
  so "% of peak" falling from 100 % to 25 % between 4 and 16 banks says nothing about efficiency.

## 2. Four banks (the baseline, verified first)

At 4 banks the peak is 32 B/cycle (4 words of 8 B). From `BENCH_TABLES.md`:

* **Streams reach the offered load**: `seq8_naive` 31.9 and `seq8_skew` 32.0 B/cycle with 0.0 % bank-conflict cycles. Naive (bank-aligned) and skewed bases perform alike
  here: after the first conflicts round robin de-synchronises the four streams into a conflict-free staggered pattern (the *dynamic* version of the placement advice).
* **256-bit vector traffic is bank-limited, at 100 % of the physical peak** (`vec256_naive` / `vec256_skew`: 32.0 B/cycle, bank utilisation 99.9 %): four 4-word requests per
  cycle cannot fit in four banks, so the arbiters are saturated and latency rises to 30.9 cycles.
* **Random 8-byte traffic reaches 20.7 B/cycle = 65 % of the offered 32.** That is head-of-line blocking: a master's oldest request waits for a busy bank while later requests
  to idle banks sit behind it. 64.6 % is what the classical result for a 4 x 4 input-queued switch with FIFO queues predicts (about 0.655, Karol, Hluchyj and Morgan 1987);
  the agreement is a useful sanity check of the measurement, not a proof.
* **Column walks**: with a row pitch of 512 words every master hits one bank in every cycle (`col_pitch_pow2`: 8.2 B/cycle, 74 % arbitration stalls); padding the pitch to
  513 words gives 32.0 B/cycle with no conflicts. Same traffic, same hardware.
* **ECC** costs nothing on these workloads except where partial words are written: `mix_system` (CTRL 4-byte writes) drops from 28.5 to 26.5 B/cycle (-7 %); every other row
  differs by at most 0.15 B/cycle (e.g. 64.0 vs 63.9, 25.9 vs 25.8).
* A 256-bit access at a non-8-byte-aligned address reads 5 words for 32 requested bytes: **physical efficiency 80 %** and 16.0 B/cycle useful at 4 banks (half of the aligned 32).

## 3. Eight and sixteen banks, identical workloads

(useful B/cycle, `% of min(offered, peak)` in brackets)

| workload | offered | 4 banks | 8 banks | 16 banks |
|---|---|---|---|---|
| seq8_skew | 32 | 32.0 (100 %) | 32.0 (100 %) | 32.0 (100 %) |
| rand8 | 32 | 20.7 (65 %) | 25.9 (81 %) | 28.8 (90 %) |
| vec256_naive | 128 | 32.0 (100 %) | 64.0 (100 %) | 127.7 (100 %) |
| vec256_skew | 128 | 32.0 (100 %) | 63.9 (100 %) | 79.9 (62 %) |
| vec256_mis4 | 128 | 16.0 (50 %) | 32.0 (50 %) | 53.0 (41 %) |
| col_pitch_pow2 | 32 | 8.2 (26 %) | 8.2 (26 %) | 8.2 (26 %) |
| gemm_aware | 37.3 | 27.3 (85 %) | 32.8 (88 %) | 37.3 (100 %) |
| mix_system | 31.0 | 28.5 (92 %) | 31.0 (100 %) | 31.0 (100 %) |

What more banks do and do not buy:

1. **More banks lift the physical ceiling and cut conflicts, but only workloads that offer more than 32 B/cycle can use it.** Random 8-byte conflicts fall from 26.5 % of
   bank-cycles (4 banks) to 8.3 % (8) and 2.3 % (16); the useful bandwidth rises from 65 % to 81 % to 90 % of what is offered. Mean latency falls from 11.2 to 8.8 to 7.7 cycles.
2. **Aligned 256-bit streams scale linearly with the banks** (32 -> 64 -> 127.7 B/cycle, 99.8 % of offered at 16 banks) *if the master bases are placed correctly*.
3. **Placement still matters at 16 banks, and a skew of one word can hurt.** `vec256_skew` shifts each master by one word; a 256-bit request spans four words, so the
   skewed requests overlap and collide: 79.9 B/cycle (62 %) against 127.7 for the un-skewed bases. The skew must be at least the access width in words
   (`mm_layout.py` computes it).
4. **The pitch-512 column walk does not improve with more banks** (8.2 B/cycle at 4, 8 and 16): a power-of-two stride keeps all four masters on one bank under LOW interleave
   whatever the bank count. Padding or XOR hashing fixes it (section 4).
5. **Misaligned vectors never reach the aligned throughput**: 5 words for 32 bytes caps physical efficiency at 80 %, and the extra word creates bank collisions
   between overlapping requests (53.0 vs 127.7 B/cycle at 16 banks).

## 4. Interleave mode (useful B/cycle)

| workload | LOW 4 | XOR 4 | LOW 16 | XOR 16 |
|---|---|---|---|---|
| seq8_skew | 32.0 | 24.8 | 32.0 | 31.7 |
| col_pitch_pow2 | 8.2 | 24.7 | 8.2 | 32.0 |
| col_pitch_pad | 32.0 | 21.1 | 32.0 | 30.3 |
| mix_system | 28.5 | 23.9 | 31.0 | 31.0 |

XOR hashing is a trade-off, not an upgrade: it repairs the power-of-two column stride (8.2 -> 24.7 at 4 banks, -> 32.0 at 8 and 16) but costs streaming traffic at 4 banks
(`seq8_skew` -32.0 -> 24.8) and defeats padding (`col_pitch_pad` 32.0 -> 21.1). A 4-word granule (`G4`, 32-byte interleave) is poor for these workloads (e.g. `seq8_naive` 9.8 B/cycle):
it only makes sense when whole 32-byte tiles are meant to live in one bank. **Recommendation: LOW with granule 1 for streamed operands; pad pitches (or use XOR) where
column walks dominate; do not mix the two assumptions.** `ANALYSIS` (section A of `TENSOR_VECTOR.md`) reproduces the same preferences by exact enumeration.

## 5. Optimising useful bandwidth: the issue window

Head-of-line blocking is the measured limiter, so the matrix has an optional **issue window**: with `ISSUE_WINDOW = W` the words of the next `W-1` requests of a master may
be issued to idle banks while an older request waits (same-word order is kept, see the contract M1 in ARCHITECTURE.md; responses stay in order).

| workload | 4 banks W=1 | W=2 | W=4 | W=8 | 8 banks W=1 | W=4 | 16 banks W=1 | W=4 |
|---|---|---|---|---|---|---|---|---|
| rand8 | 20.7 | 23.6 | 26.1 | 27.0 | 25.9 | 31.6 | 28.8 | 31.9 |
| vec256_skew | 32.0 | 32.0 | 32.0 | 32.0 | 63.9 | 63.9 | 79.9 | 127.4 |
| vec256_mis4 | 16.0 | 16.0 | 16.0 | 16.0 | 32.0 | 32.0 | 53.0 | 63.9 |
| gemm_aware | 27.3 | 28.0 | 27.1 | 26.4 | 32.8 | 37.3 | 37.3 | 37.3 |
| mix_system | 28.5 | 29.5 | 30.0 | 30.2 | 31.0 | 31.0 | 31.0 | 31.0 |

* Random 8-byte traffic goes from 81 % to 99 % of offered at 8 banks and from 90 % to 99.7 % at 16 banks with `W = 4`; at 4 banks `W = 8` recovers 27.0 of 32.
* `vec256_skew` at 16 banks: 79.9 -> 127.4 B/cycle (+59 %).
* **It is not free and not always positive**: bank-bound workloads do not change (4-bank `vec256`), and `gemm_aware` at 4 banks falls slightly with a larger window (27.3 -> 26.4 at
  `W = 8`: the DMA's 32-byte writes take bank slots from the operand streams). The window costs area: **+87,467 generic cells (+42 %) at 4 banks and +195,237 (+38 %) at 16 banks for `W = 4`** (Yosys, SYNTHESIS.md 1.3; combinational only, no extra flip-flops). `W = 1` is the default
  and is the configuration exercised first and most; whether the extra bandwidth is worth that area is a system decision this package does not make.

## 6. Latency, starvation, arbitration (full tables in BENCH_TABLES.md)

* Unloaded latency is `READ_LATENCY + (ECC ? 1 : 0) + 1` = 2 cycles (`seq8_skew` / `col_pitch_pad`, every master 2.0).
* In `mix_system` the light ControlCore load keeps a low latency under round robin: 3.9 cycles at 4 banks (2.5 at 8, 2.2 at 16), while the heavy TENSOR / VECTOR / DMA streams see
  11.8 / 20.3 / 20.3 cycles at 4 banks. There is no latency priority class: a ControlCore request still shares the bank arbiter with streaming masters.
* Tensor starvation (a tensor-class master had pending words and received none): 22.7 % of cycles at 4 banks in `mix_system`, 12.6 % at 8, 7.1 % at 16. **Class assignment is
  positional**: in the `gemm_*` workloads master 1 (TENSOR slot) is the B stream and master 2 (VECTOR slot) is the C partial-sum stream; the starved stream there is C
  (43.9 % at 4 banks, 18.8 % at 16) against 0.0 % for B at 4 banks, because the DMA tile fill (256-bit writes) competes for the same banks.
* **Read / write utilisation** (accepted word accesses per bank-cycle): in `gemm_aware` the banks spend 31 % of their cycles on reads and 55 % on writes at 4 banks (the DMA tile fill and
  the partial-sum writes), 10 % / 19 % at 16 banks; `mix_system` is 44 % / 50 % at 4 banks and 12 % / 14 % at 16; the pure-read vector workloads show 100 % / 0 % at 4 banks.
  In the 4-bank `rand8` case reads and writes use 45 % and 19 % of the bank cycles (70 % reads offered).
* Arbitration stalls track bank conflicts: 74.4 % of master-cycles in the pitch-512 column walk at any bank count, 0.0 % with the padded pitch.

## 7. What this does NOT show

* No comparison against `sf_sram_controller` on the same traffic was run (its master port has no size field; the 64-bit controller configuration would have to be wrapped).
* Single seed per workload (3000 requests per master); the random workloads carry sampling noise of a fraction of a percent (their 4-bank figure, 64.6 %, is close to but not identical with the theoretical 65.5 %).
* The workloads are synthetic address patterns shaped after the client documentation, not traces of the ControlCore, TensorCore, vector array or CloudDMA RTL.
* Throughput is in bytes per **clock cycle**: no clock frequency, no physical timing.
