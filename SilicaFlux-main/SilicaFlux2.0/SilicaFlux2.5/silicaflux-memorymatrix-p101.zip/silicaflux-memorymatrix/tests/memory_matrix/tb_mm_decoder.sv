// =============================================================================
// tb_mm_decoder -- exhaustive check of the address organisation (sf_memory_matrix_decoder / _unmap)
//
//  1. NO ALIASING, EXHAUSTIVE: for every word index w < NB*DEPTH the decoder gives (bank,row) with bank < NB, row < DEPTH,
//     and every (bank,row) pair is produced EXACTLY ONCE (bitmap), i.e. the map is a bijection onto the physical array.
//  2. INDEPENDENT REFERENCE: the expected (bank,row) is computed here with integer divide / modulo (a different
//     formulation from the DUT's bit slicing) for the three interleave modes.
//  3. ROUND TRIP: unmap(bank,row) == w for every word.
//  4. K-word consistency: word k of an access at w gives the map of w+k.
//  5. Bounds / size / alignment / permission rules (see the decoder header) on directed and randomised addresses, with a
//     byte-level reference written from the specification.
// Prints  RESULT tb=mm_decoder ... checks=N errors=E PASS|FAIL
// =============================================================================
`timescale 1ns/1ps
`include "sf_mm_defs.svh"

module tb_mm_decoder #(
  parameter int NB            = 4,
  parameter int DEPTH         = 64,
  parameter int LB            = 3,
  parameter int AW            = 20,
  parameter int SZ_MAX        = 5,
  parameter int K             = 5,
  parameter int MODE          = 0,
  parameter int GRAN          = 0,
  parameter int MISALIGN_EN   = 1,
  parameter int NRG           = 3,
  parameter int DEFAULT_ALLOW = 1,
  parameter int NM            = 4,
  parameter int SEED          = 32'hC0FFEE01
);
  localparam int DBYTES = 1 << SZ_MAX;
  localparam int SZW    = (SZ_MAX > 0) ? $clog2(SZ_MAX + 1) : 1;
  localparam int MW     = (NM > 1) ? $clog2(NM) : 1;
  localparam int BW     = $clog2(NB);
  localparam int ROW_W  = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int WIW    = $clog2(NB * DEPTH);
  localparam int NRGW   = (NRG > 0) ? NRG : 1;
  localparam int WB     = 1 << LB;
  localparam int CAPW   = NB * DEPTH;
  localparam longint CAPB = longint'(CAPW) * WB;

  logic [AW-1:0]       addr;
  logic [SZW-1:0]      size;
  logic                we;
  logic [1:0]          prot;
  logic [MW-1:0]       mid;
  logic [NRGW*AW-1:0]  rg_base, rg_last;
  logic [NRGW*5-1:0]   rg_perm;
  logic [NRGW*NM-1:0]  rg_mmask;
  wire                 err;
  wire [2:0]           status;
  wire [LB-1:0]        off;
  wire [DBYTES-1:0]    smask;
  wire [K*BW-1:0]      bank_o;
  wire [K*ROW_W-1:0]   row_o;

  sf_memory_matrix_decoder #(.NB(NB), .DEPTH(DEPTH), .LB(LB), .AW(AW), .SZ_MAX(SZ_MAX), .K(K), .MODE(MODE), .GRAN(GRAN),
                             .MISALIGN_EN(MISALIGN_EN), .NRG(NRG), .DEFAULT_ALLOW(DEFAULT_ALLOW), .NM(NM)) dut (
    .addr_i(addr), .size_i(size), .we_i(we), .prot_i(prot), .mid_i(mid),
    .rg_base_i(rg_base), .rg_last_i(rg_last), .rg_perm_i(rg_perm), .rg_mmask_i(rg_mmask),
    .err_o(err), .status_o(status), .off_o(off), .smask_o(smask), .bank_o(bank_o), .row_o(row_o));

  logic [BW-1:0]    u_bank;
  logic [ROW_W-1:0] u_row;
  wire  [WIW-1:0]   u_word;
  sf_memory_matrix_unmap #(.NB(NB), .DEPTH(DEPTH), .MODE(MODE), .GRAN(GRAN)) u_un (.bank_i(u_bank), .row_i(u_row), .word_o(u_word));

  int errors = 0, checks = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin
      errors++;
      if (errors <= 20) $display("  ERROR: %s", msg);
    end
  endtask

  // ---- independent reference of the map (integer arithmetic only)
  function automatic int ref_fold(input int row);
    int f, r;
    begin
      f = 0; r = row;
      while (r > 0) begin f = f ^ (r % NB); r = r / NB; end
      ref_fold = f;
    end
  endfunction
  function automatic void ref_map(input int w, output int bank, output int row);
    int g;
    begin
      g = 1 << GRAN;
      if (MODE == `SF_MM_ILV_LINEAR) begin
        bank = w / DEPTH; row = w % DEPTH;
      end else begin
        bank = (w / g) % NB;
        row  = (w / (g * NB)) * g + (w % g);
        if (MODE == `SF_MM_ILV_XOR) bank = bank ^ ref_fold(row);
      end
    end
  endfunction

  // ---- independent reference of status / permission
  function automatic bit ref_byte_ok(input longint p, input bit is_we, input bit [1:0] pr, input int m);
    bit found, ok;
    begin
      found = 0; ok = (DEFAULT_ALLOW != 0);
      for (int r = 0; r < NRG; r++) begin
        if (!found && rg_perm[r*5 + 4] && p >= longint'(rg_base[r*AW +: AW]) && p <= longint'(rg_last[r*AW +: AW])) begin
          found = 1;
          ok = (is_we ? rg_perm[r*5 + 1] : rg_perm[r*5 + 0]) && (!rg_perm[r*5 + 2] || pr[0]) &&
               (!rg_perm[r*5 + 3] || pr[1]) && rg_mmask[r*NM + m];
        end
      end
      ref_byte_ok = ok;
    end
  endfunction

  function automatic [2:0] ref_status(input longint a, input int sz, input bit is_we, input bit [1:0] pr, input int m);
    longint nb, last;
    begin
      nb = (sz > SZ_MAX) ? 1 : (longint'(1) << sz);
      last = a + nb - 1;
      if (sz > SZ_MAX)                                        ref_status = `SF_ST_BADOP;
      else if (a >= CAPB || last >= CAPB)                     ref_status = `SF_ST_RANGE;
      else if (MISALIGN_EN == 0 && (a % nb) != 0)             ref_status = `SF_ST_ALIGN;
      else if (NRG > 0 && !(ref_byte_ok(a, is_we, pr, m) && ref_byte_ok(last, is_we, pr, m))) ref_status = `SF_ST_PERM;
      else                                                    ref_status = `SF_ST_OK;
    end
  endfunction

  bit seen [0:CAPW-1];     // indexed by bank*DEPTH + row
  int seed;
  function automatic int rnd();
    seed = seed ^ (seed << 13); seed = seed ^ (seed >>> 17); seed = seed ^ (seed << 5);
    rnd = seed & 32'h7FFF_FFFF;
  endfunction

  initial begin
    int eb, er;
    seed = SEED;
    addr = '0; size = '0; we = 0; prot = 0; mid = '0; u_bank = '0; u_row = '0;
    rg_base = '0; rg_last = '0; rg_perm = '0; rg_mmask = '0;
    for (int i = 0; i < CAPW; i++) seen[i] = 0;
    #1;
    $display("tb_mm_decoder NB=%0d DEPTH=%0d MODE=%0d GRAN=%0d MISALIGN_EN=%0d K=%0d NRG=%0d", NB, DEPTH, MODE, GRAN, MISALIGN_EN, K, NRG);

    // ---------------------------------------------------- 1-4: exhaustive map checks (permission logic off: whole space allowed)
    if (NRG > 0) begin
      for (int r = 0; r < NRG; r++) begin
        rg_perm[r*5 +: 5] = 5'b0_0_0_0_0;                // regions disabled -> DEFAULT_ALLOW decides
      end
    end
    for (int w = 0; w < CAPW; w++) begin
      addr = AW'(longint'(w) * WB); size = '0; we = 0; #1;
      ref_map(w, eb, er);
      chk(int'(bank_o[0 +: BW]) == eb, $sformatf("bank of word %0d: got %0d want %0d", w, bank_o[0 +: BW], eb));
      chk(int'(row_o[0 +: ROW_W]) == er, $sformatf("row of word %0d: got %0d want %0d", w, row_o[0 +: ROW_W], er));
      chk(int'(bank_o[0 +: BW]) < NB && int'(row_o[0 +: ROW_W]) < DEPTH, $sformatf("word %0d outside the array", w));
      if (int'(bank_o[0 +: BW]) < NB && int'(row_o[0 +: ROW_W]) < DEPTH) begin
        chk(!seen[int'(bank_o[0 +: BW]) * DEPTH + int'(row_o[0 +: ROW_W])], $sformatf("ALIASING: word %0d hits an already used (bank,row)", w));
        seen[int'(bank_o[0 +: BW]) * DEPTH + int'(row_o[0 +: ROW_W])] = 1;
      end
      u_bank = bank_o[0 +: BW]; u_row = row_o[0 +: ROW_W]; #1;
      chk(int'(u_word) == w, $sformatf("round trip word %0d -> unmap -> %0d", w, u_word));
      // K-word consistency (words past the end are not checked: the decoder never receives them in a legal request)
      for (int k = 1; k < K; k++) begin
        if (w + k < CAPW) begin
          ref_map(w + k, eb, er);
          chk(int'(bank_o[k*BW +: BW]) == eb && int'(row_o[k*ROW_W +: ROW_W]) == er,
              $sformatf("word %0d lane %0d: got (%0d,%0d) want (%0d,%0d)", w, k, bank_o[k*BW +: BW], row_o[k*ROW_W +: ROW_W], eb, er));
        end
      end
    end
    for (int i = 0; i < CAPW; i++) chk(seen[i], $sformatf("(bank,row) index %0d never produced: the map is not onto", i));

    // ---------------------------------------------------- 5: permission regions + status, randomised against the reference
    if (NRG > 0) begin
      // region 0: low quarter, R/W, any master; region 1: next quarter, read only, priv only; region 2: secure only RW, masters {0,1}
      rg_base[0*AW +: AW] = AW'(0);                 rg_last[0*AW +: AW] = AW'(CAPB / 4 - 1);       rg_perm[0*5 +: 5] = 5'b1_0_0_1_1; rg_mmask[0*NM +: NM] = '1;
      rg_base[1*AW +: AW] = AW'(CAPB / 4);          rg_last[1*AW +: AW] = AW'(CAPB / 2 - 1);       rg_perm[1*5 +: 5] = 5'b1_0_1_0_1; rg_mmask[1*NM +: NM] = '1;
      if (NRG > 2) begin
        rg_base[2*AW +: AW] = AW'(CAPB / 2);        rg_last[2*AW +: AW] = AW'(CAPB / 2 + CAPB / 8 - 1); rg_perm[2*5 +: 5] = 5'b1_1_0_1_1; rg_mmask[2*NM +: NM] = NM'(3);
      end
    end
    for (int t = 0; t < 40000; t++) begin
      int sz;
      longint a;
      sz = rnd() % (SZ_MAX + 2);                    // includes one illegal size
      case (rnd() % 4)
        0: a = longint'(rnd()) % (CAPB + 64);
        1: a = CAPB - 1 - (rnd() % 40);             // around the end
        2: a = (longint'(rnd()) % CAPB) & ~((longint'(1) << ((sz > SZ_MAX) ? 0 : sz)) - 1);   // aligned
        default: a = (CAPB / 4) - 8 + (rnd() % 16); // around a region boundary
      endcase
      if (a >= (longint'(1) << AW)) a = a % (longint'(1) << AW);
      addr = AW'(a); size = SZW'(sz); we = rnd() & 1; prot = 2'(rnd()); mid = MW'(rnd() % NM); #1;
      chk(status == ref_status(a, sz, we, prot, int'(mid)),
          $sformatf("status a=%0d size=%0d we=%0d prot=%0d m=%0d: got %0d want %0d", a, sz, we, prot, mid, status, ref_status(a, sz, we, prot, int'(mid))));
      chk(err == (status != `SF_ST_OK), "err_o disagrees with status_o");
      chk(int'(off) == int'(a % WB), $sformatf("byte offset a=%0d: got %0d", a, off));
      if (sz <= SZ_MAX) begin
        for (int j = 0; j < DBYTES; j++) chk(smask[j] == (j < (1 << sz)), $sformatf("smask size=%0d lane %0d", sz, j));
      end
    end

    $display("RESULT tb=mm_decoder NB=%0d DEPTH=%0d MODE=%0d GRAN=%0d MISALIGN_EN=%0d NRG=%0d checks=%0d errors=%0d %s",
             NB, DEPTH, MODE, GRAN, MISALIGN_EN, NRG, checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule
