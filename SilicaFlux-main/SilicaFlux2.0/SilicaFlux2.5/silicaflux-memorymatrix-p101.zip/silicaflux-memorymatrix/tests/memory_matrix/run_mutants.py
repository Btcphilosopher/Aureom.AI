#!/usr/bin/env python3
"""Mutation testing of sf_memory_matrix* with tb_memory_matrix.   Run from the package root.

  python3 tests/memory_matrix/run_mutants.py [--jobs N] [--only NAME ...] [--out reports/mutation.json]

Every mutant is ONE deliberate fault injected into a private copy of rtl/ (decoder, arbiter, perf, matrix, address map).  The
mutant is built into the system testbench under a configuration chosen to expose it and the testbench must FAIL (errors > 0,
a hang, or a testbench assertion).  A mutant that still passes SURVIVED: the testbench has a hole (or the mutant is equivalent,
which is then argued in docs/memory_matrix/VERIFICATION.md).  A mutant that does not compile is INVALID, never counted as killed.
The third-party SilicaFlux modules (sf_sram_bank, ECC, ...) are NOT mutated here: they are reused unmodified and have their own
regressions (see docs/memory_matrix/AUDIT.md).
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.getcwd()
TB = "tests/memory_matrix/tb_memory_matrix.sv"
M = "rtl/memory/sf_memory_matrix.sv"
D = "rtl/memory/sf_memory_matrix_decoder.sv"
A = "rtl/memory/sf_memory_matrix_arbiter.sv"
P = "rtl/memory/sf_memory_matrix_perf.sv"
H = "rtl/memory/sf_mm_map.svh"

ECC = {"ENABLE_ECC": 1, "BANK_DEPTH": 64}
RG = {"NUM_REGIONS": 3}
MIS0 = {"MISALIGN_EN": 0}
XOR = {"INTERLEAVE_MODE": 1}
WIN4 = {"ISSUE_WINDOW": 4}

# (name, file, find, replace, config, what it models)
MUT = [
    ("dec_last_gt",       D, "(last_ext >= XW'(CAP_B))", "(last_ext > XW'(CAP_B))", {}, "boundary off-by-one: an access whose last byte is the first byte past the end is accepted"),
    ("dec_last_plus1",    D, "last_ext = a_ext + nbytes - XW'(1);", "last_ext = a_ext + nbytes;", {}, "last byte computed one too high: legal accesses at the very end are rejected"),
    ("dec_perm_first",    D, "perm_ok = byte_allowed(a_ext) && byte_allowed(last_byte);", "perm_ok = byte_allowed(a_ext);", RG, "permission checked on the first byte only (straddling access slips through)"),
    ("dec_align_inv",     D, "((a_ext & (nbytes - XW'(1))) != '0)", "((a_ext & (nbytes - XW'(1))) == '0)", MIS0, "alignment check inverted"),
    ("dec_perm_status",   D, "else if (!perm_ok) status_o = `SF_ST_PERM;", "else if (!perm_ok) status_o = `SF_ST_ALIGN;", RG, "wrong status code for a permission fault"),
    ("dec_badop_missing", D, "badop    = (size_i > SZW'(SZ_MAX));", "badop    = 1'b0;", {}, "illegal size accepted"),
    ("mm_shift_resp",     M, "h_sh = h_msk >> {h_off, 3'b000};", "h_sh = h_msk >> ({h_off, 3'b000} + 8);", {}, "read data re-alignment wrong by one byte"),
    ("mm_shift_wr",       M, "(K*WORD_WIDTH)'(wd_i) << {fe_off, 3'b000};", "(K*WORD_WIDTH)'(wd_i);", {}, "write data not shifted to its byte lane (misaligned writes corrupt)"),
    ("mm_be_ignored",     M, "wire [DBYTES-1:0]        fe_be_eff = we_i ? (be_i & fe_smask) : fe_smask;", "wire [DBYTES-1:0]        fe_be_eff = fe_smask;", {}, "byte enables ignored: partial writes become full writes"),
    ("mm_queue_depth",    M, "assign can_alloc[i] = (cnt != (SW+1)'(NSLOT)) & ~blocked;", "assign can_alloc[i] = (cnt != (SW+1)'(NSLOT - 1)) & ~blocked;", {}, "bounded queue one entry short (back-pressure error)"),
    ("mm_double_issue",   M, "iss_q <= byp ? g_i : '0;", "iss_q <= '0;", {}, "words issued in the accepting cycle are issued again (double access)"),
    ("mm_ue_dropped",     M, "if (h_ue) st_q <= `SF_ST_ECC_UE;", "if (1'b0) st_q <= `SF_ST_ECC_UE;", ECC, "uncorrectable ECC status lost"),
    ("mm_ce_dropped",     M, "if (h_ce) ce_q <= 1'b1;", "if (1'b0) ce_q <= 1'b1;", ECC, "corrected-error flag lost"),
    ("mm_wr_rdata",       M, "= h_we ? '0 : h_sh[DATA_WIDTH-1:0];", "= h_sh[DATA_WIDTH-1:0];", {}, "write response carries data"),
    ("mm_row_queued",     M, "bank_q <= fe_bank; row_q <= fe_row;", "bank_q <= fe_bank; row_q <= fe_row ^ 1;", {}, "row corrupted on the queued (non cut-through) path"),
    ("mm_rd_word0",       M, "if (hit_k[k]) wd_q[k*WORD_WIDTH +: WORD_WIDTH] <= hdata[k*WORD_WIDTH +: WORD_WIDTH];", "if (hit_k[k] && k != 0) wd_q[k*WORD_WIDTH +: WORD_WIDTH] <= hdata[k*WORD_WIDTH +: WORD_WIDTH];", {}, "read data of word 0 never stored"),
    ("mm_tag_slot",       M, "tg  = tg  | {MW'(i), c_slot_f[(i*WIN + k / K)*SW +: SW], KW'(k % K)};", "tg  = tg  | {MW'(i), SW'(0), KW'(k % K)};", {}, "responses routed to slot 0"),
    ("mm_id_inv",         M, "id_q <= m_req_id[i*IDW +: IDW];", "id_q <= ~m_req_id[i*IDW +: IDW];", {}, "transaction id corrupted"),
    ("mm_flush_noclr",    M, "        end else if (clear_all) begin\n          sv <= 1'b0;", "        end else if (1'b0) begin\n          sv <= 1'b0;", {}, "flush never discards the slots"),
    ("mm_ev_addr",        M, "AW'({ev_word, {LB{1'b0}}})", "AW'({ev_word, {LB{1'b1}}})", ECC, "ECC event address off inside the word"),
    ("mm_selw_dup",       M, "selw[i*LN + k] = cand[k] & ~seen;", "selw[i*LN + k] = cand[k];", {}, "two words of one request to the same bank selected in one cycle"),
    ("mm_cand_done",      M, "cand_done = w_valid[0] & ((w_pend[K-1:0] & ~g_i) == '0);", "cand_done = w_valid[0] & ((w_pend[K-1:0] & ~g_i & {{(K-1){1'b1}}, 1'b0}) == '0);", {}, "request retired while word 0 is still pending (lost word)"),
    ("mm_need_word0",     M, "for (int k = 0; k < K; k++) fe_need[k] = |fe_wm[k*WB +: WB];", "for (int k = 0; k < K; k++) fe_need[k] = |fe_wm[k*WB +: WB] | (k == 0);", {}, "spurious access of word 0 for sparse byte enables"),
    ("arb_ptr_stuck",     A, "if (gnt_o[i]) ptr <= (i == NM - 1) ? '0 : MW'(i + 1);", "if (gnt_o[i]) ptr <= '0;", {}, "round-robin pointer never rotates (fixed priority)"),
    ("arb_ignore_ready",  A, "    if (ready_i) begin\n      for (int k = 0; k < NM; k++) begin", "    if (1'b1) begin\n      for (int k = 0; k < NM; k++) begin", ECC, "grant while the bank cannot accept (RMW busy)"),
    ("perf_bytes_swap",   P, "if (ev_pop_we_i[i]) c_bw <= c_bw + 32'(ub);", "if (!ev_pop_we_i[i]) c_bw <= c_bw + 32'(ub);", {}, "write bytes counted as read bytes and vice versa"),
    ("perf_lat_off",      P, "c_ls <= c_ls + 40'(lat);", "c_ls <= c_ls + 40'(lat) + 40'd1;", {}, "latency sum off by one per request"),
    ("perf_conf_ge3",     P, "if (nreq >= NRW'(2))                c_conf <= c_conf + 32'd1;", "if (nreq >= NRW'(3))                c_conf <= c_conf + 32'd1;", {}, "two-way bank conflicts not counted"),
    ("win_youngest_first", M, "        for (int k = 0; k < LN; k++) begin\n          selw[i*LN + k] = cand[k] & ~seen;", "        for (int k = LN - 1; k >= 0; k--) begin\n          selw[i*LN + k] = cand[k] & ~seen;", WIN4, "per-bank selection takes the YOUNGEST word first: a master's own same-word accesses are reordered (breaks per-address program order)"),
    ("win_grant_route",   M, "g_slot = g_all[w*K +: K];", "g_slot = g_all[K-1:0];", WIN4, "words granted to a younger request recorded on the wrong window slot"),
    ("win_valid_off",     M, "w_valid[w] = issue_en & ((SW+1)'(w) < icnt);", "w_valid[w] = issue_en & ((SW+1)'(w) <= icnt);", WIN4, "window includes one unallocated (stale) slot"),
    ("map_xor_fold",      H, "for (int s = 0; s < ROW_W; s += BW) f = f ^ BW'(r >> s);", "for (int s = 0; s < ROW_W; s += BW) f = f ^ BW'(r >> (s + 1));", XOR, "XOR hash folds the wrong row bits (aliasing)"),
]


def run_one(m, outroot):
    name, f, find, repl, cfg, doc = m
    d = os.path.join(outroot, name)
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    for sub in ("rtl", "tests", "scripts"):
        shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub))
    p = os.path.join(d, f)
    src = open(p).read()
    if src.count(find) != 1:
        return dict(name=name, status="STALE", detail=f"find-string occurs {src.count(find)} times", doc=doc)
    open(p, "w").write(src.replace(find, repl))
    env = dict(os.environ)
    env.setdefault("VOPT", "-O0")
    g = [f"-G{k}={v}" for k, v in cfg.items()]
    b = subprocess.run(["bash", "scripts/vbuild.sh", os.path.join(d, "b"), "tb_memory_matrix", TB] + g, cwd=d, env=env, capture_output=True, text=True)
    exe = os.path.join(d, "b", "sim.bin")
    if b.returncode != 0 or not os.path.exists(exe):
        return dict(name=name, status="INVALID", detail=(b.stdout + b.stderr)[-400:], doc=doc)
    try:
        r = subprocess.run([exe], cwd=d, env=env, capture_output=True, text=True, timeout=240)
    except subprocess.TimeoutExpired:
        return dict(name=name, status="KILLED", how="hang/timeout", doc=doc)
    out = r.stdout + r.stderr
    mm = re.search(r"RESULT .*? checks=(\d+) errors=(\d+)(?: cycles=\d+)? (PASS|FAIL)", out)
    first = next((l.strip() for l in out.splitlines() if "ERROR" in l or "%Error" in l or "Assertion" in l or "WATCHDOG" in l), "")
    if mm and mm.group(3) == "PASS" and r.returncode == 0:
        res = dict(name=name, status="SURVIVED", doc=doc)
    else:
        res = dict(name=name, status="KILLED", how=(first or "no RESULT line")[:160], errors=int(mm.group(2)) if mm else None, doc=doc)
    shutil.rmtree(d, ignore_errors=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out", default="reports/mutation.json")
    ap.add_argument("--build", default="build/mut")
    a = ap.parse_args()
    muts = [m for m in MUT if not a.only or m[0] in a.only]
    os.makedirs(a.build, exist_ok=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(lambda m: run_one(m, a.build), muts))
    for r in res:
        print(f'{r["status"]:9s} {r["name"]:18s} {r.get("how", r.get("detail", ""))[:110]}')
    k = sum(1 for r in res if r["status"] == "KILLED")
    bad = [r["name"] for r in res if r["status"] in ("SURVIVED", "INVALID", "STALE")]
    print(f"\n{k}/{len(res)} mutants killed; not killed: {bad}   ({time.time() - t0:.0f} s)")
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(dict(mutants=res, killed=k, total=len(res)), open(a.out, "w"), indent=1)
    return 0 if k == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
