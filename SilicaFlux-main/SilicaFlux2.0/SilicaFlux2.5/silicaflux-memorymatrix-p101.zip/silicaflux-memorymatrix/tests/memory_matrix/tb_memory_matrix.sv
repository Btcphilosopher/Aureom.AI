// =============================================================================
// tb_memory_matrix -- self-checking system testbench for sf_memory_matrix
//
// INDEPENDENT REFERENCE MODEL
//   * ref_mem[byte] / ref_known[byte]: a byte-addressable image of the whole aperture.  Nothing is assumed about power-up
//     contents (non-ECC arrays are unknown until written; ECC arrays are known-zero only after the init engine ran).
//   * A request is a byte range [addr, addr+2^size) with byte enables.  The TB derives, from the BYTE ADDRESS ALONE and with
//     its own integer-arithmetic map (not the DUT's bit slicing), which words / banks / rows the request must touch.
//   * The model is applied at the edge a bank ACCEPTS a word (DUT trace port trc_*): the serialisation point of the bank
//     (contract M3).  Each accepted word is checked against the expected (bank, row, word index), against double access
//     and against spurious access (a word with no active byte); writes update ref_mem, reads capture the expected bytes.
//   * At the response handshake the TB checks: order (per master), id, we, status (predicted from the spec: RANGE / ALIGN /
//     BADOP / PERM), rdata lanes (known bytes only; lanes above the size and every error / write response must read 0),
//     ce flag, that every expected word was accessed, and stability of a stalled response.
//   * m_req_ready is checked EXACTLY: ready == (outstanding < NSLOT) when no flush / quiesce is active (registered-state-only
//     bounded queue, correct back-pressure).
//   * Performance counters are mirrored (accesses per bank, useful bytes, latency, requests, rejects, cycles) and compared
//     for exact equality at the end of each measurement window.
// Everything is cycle based (one clocked process) so it runs on Verilator without fork/join.
// Prints  RESULT tb=memory_matrix <config> tests=T checks=N errors=E cycles=C PASS|FAIL
// =============================================================================
`timescale 1ns/1ps
`include "sf_mm_defs.svh"

module tb_memory_matrix #(
  parameter int NUM_BANKS       = 4,
  parameter int BANK_DEPTH      = 256,
  parameter int WORD_WIDTH      = 64,
  parameter int DATA_WIDTH      = 256,
  parameter int READ_LATENCY    = 1,
  parameter int NUM_MASTERS     = 4,
  parameter int ENABLE_ECC      = 0,
  parameter int AW              = 24,
  parameter int IDW             = 8,
  parameter int NSLOT           = 8,
  parameter int ISSUE_WINDOW    = 1,
  parameter int ARB             = 1,
  parameter int INTERLEAVE_MODE = 0,
  parameter int ILV_GRAN_LOG2   = 0,
  parameter int MISALIGN_EN     = 1,
  parameter int NUM_REGIONS     = 0,
  parameter int DEFAULT_ALLOW   = 1,
  parameter int BACKEND         = 0,
  parameter int SCRUB_EN        = 0,
  parameter int SCRUB_WAIT      = 8,
  parameter int SIM_INIT        = 2,
  parameter int FAULT_INJECT    = ENABLE_ECC,
  parameter int SEED            = 32'h1234ABCD,
  parameter int NRAND           = 600,       // requests per master in a random phase
  parameter int FULL_READBACK   = 1
);
  // ------------------------------------------------------------ derived (same formulas as the DUT; TB-local copies)
  localparam int NB     = NUM_BANKS;
  localparam int NM     = NUM_MASTERS;
  localparam int WB     = WORD_WIDTH / 8;
  localparam int LB     = $clog2(WB);
  localparam int DBYTES = DATA_WIDTH / 8;
  localparam int SZ_MAX = $clog2(DBYTES);
  localparam int SZW    = (SZ_MAX > 0) ? $clog2(SZ_MAX + 1) : 1;
  localparam int K      = (MISALIGN_EN != 0) ? (DBYTES + 2 * WB - 2) / WB : (DBYTES + WB - 1) / WB;
  localparam int KW     = (K > 1) ? $clog2(K) : 1;
  localparam int BW     = $clog2(NB);
  localparam int ROW_W  = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1;
  localparam int MW     = (NM > 1) ? $clog2(NM) : 1;
  localparam int SW     = (NSLOT > 1) ? $clog2(NSLOT) : 1;
  localparam int R_ECC  = $clog2(WORD_WIDTH + $clog2(WORD_WIDTH + 1) + 1);
  localparam int STORE_W = (ENABLE_ECC != 0) ? WORD_WIDTH + R_ECC + 1 : WORD_WIDTH;
  localparam int FBW    = (STORE_W > 1) ? $clog2(STORE_W) : 1;
  localparam int LAT_W  = 20;
  localparam int NRGW   = (NUM_REGIONS > 0) ? NUM_REGIONS : 1;
  localparam int CAPW   = NB * BANK_DEPTH;
  localparam longint CAPB = longint'(CAPW) * WB;
  localparam int CAPBI = CAPW * WB;
  localparam int CNT_W  = 16;
  localparam int BANK_LAT = READ_LATENCY + ((ENABLE_ECC != 0) ? 1 : 0);
  localparam int WSZ    = (LB <= SZ_MAX) ? LB : SZ_MAX;      // largest legal 'one word' access on this bus (log2 bytes)
  localparam int WBITS  = 8 << WSZ;

  // ------------------------------------------------------------ DUT
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic [NM-1:0]             m_req_valid;
  wire  [NM-1:0]             m_req_ready;
  logic [NM-1:0]             m_req_we;
  logic [NM*AW-1:0]          m_req_addr;
  logic [NM*SZW-1:0]         m_req_size;
  logic [NM*DATA_WIDTH-1:0]  m_req_wdata;
  logic [NM*DBYTES-1:0]      m_req_be;
  logic [NM*IDW-1:0]         m_req_id;
  logic [NM*2-1:0]           m_req_prot;
  wire  [NM-1:0]             m_rsp_valid;
  logic [NM-1:0]             m_rsp_ready;
  wire  [NM*DATA_WIDTH-1:0]  m_rsp_rdata;
  wire  [NM*IDW-1:0]         m_rsp_id;
  wire  [NM-1:0]             m_rsp_we;
  wire  [NM*3-1:0]           m_rsp_status;
  wire  [NM-1:0]             m_rsp_ce;
  logic [NRGW*AW-1:0]        rg_base, rg_last;
  logic [NRGW*5-1:0]         rg_perm;
  logic [NRGW*NM-1:0]        rg_mmask;
  logic                      flush_i = 1'b0, quiesce_i = 1'b0, init_start_i = 1'b0, scrub_en_i = 1'b0, ecc_clr_i = 1'b0, perf_clr_i = 1'b0;
  // The test thread NEVER drives DUT inputs.  It sets these request variables; the clocked process p_main is the only
  // driver of every DUT input (non-blocking), so the DUT and the model see every control change at the same edge.
  bit            c_rst_n = 1'b0, c_quiesce = 1'b0, c_scrub = 1'b0;
  bit            c_flush_req = 1'b0, c_clr_req = 1'b0, c_seu_req = 1'b0;
  logic [BW-1:0]     c_fi_bank = '0;
  logic [ROW_W-1:0]  c_seu_row = '0;
  logic [STORE_W-1:0] c_seu_mask = '0;
  wire                       flush_busy_o, idle_o, init_busy_o;
  wire  [NB-1:0]             ev_ce_o, ev_ue_o;
  wire  [NB*AW-1:0]          ev_addr_o;
  wire  [NB*CNT_W-1:0]       ce_cnt_o, ue_cnt_o;
  wire  [31:0]               perf_cycles_o, perf_rej_o;
  wire  [NB*32-1:0]          perf_acc_rd_o, perf_acc_wr_o, perf_conf_o, perf_lost_o, perf_busy_o;
  wire  [NM*32-1:0]          perf_mstall_o, perf_arbstall_o, perf_busystall_o, perf_selfconf_o, perf_starve_o;
  wire  [4*32-1:0]           perf_starve_cls_o;
  wire  [NM*32-1:0]          perf_reqs_o, perf_bytes_rd_o, perf_bytes_wr_o, perf_lat_cnt_o;
  wire  [NM*40-1:0]          perf_lat_sum_o;
  wire  [NM*LAT_W-1:0]       perf_lat_max_o;
  wire  [NB-1:0]             trc_acc_o, trc_we_o;
  wire  [NB*MW-1:0]          trc_m_o;
  wire  [NB*SW-1:0]          trc_slot_o;
  wire  [NB*KW-1:0]          trc_k_o;
  wire  [NB*ROW_W-1:0]       trc_row_o;
  logic [BW-1:0]             fi_bank;
  logic [3:0]                fi_type;
  logic [ROW_W-1:0]          fi_row, fi_row2, seu_row;
  logic [FBW-1:0]            fi_bit, fi_bit2;
  logic                      fi_val, fi_val2, seu_pulse;
  logic [STORE_W-1:0]        seu_mask;
  wire  [NB*STORE_W-1:0]     tst_rdata_o;

  sf_memory_matrix #(
    .NUM_BANKS(NUM_BANKS), .BANK_DEPTH(BANK_DEPTH), .WORD_WIDTH(WORD_WIDTH), .DATA_WIDTH(DATA_WIDTH), .READ_LATENCY(READ_LATENCY),
    .NUM_MASTERS(NUM_MASTERS), .ENABLE_ECC(ENABLE_ECC), .AW(AW), .IDW(IDW), .NSLOT(NSLOT), .ISSUE_WINDOW(ISSUE_WINDOW), .ARB(ARB),
    .INTERLEAVE_MODE(INTERLEAVE_MODE), .ILV_GRAN_LOG2(ILV_GRAN_LOG2), .MISALIGN_EN(MISALIGN_EN), .NUM_REGIONS(NUM_REGIONS),
    .DEFAULT_ALLOW(DEFAULT_ALLOW), .SIM_INIT(SIM_INIT), .FAULT_INJECT(FAULT_INJECT), .BACKEND(BACKEND), .SCRUB_EN(SCRUB_EN),
    .SCRUB_WAIT(SCRUB_WAIT), .CNT_W(CNT_W)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_size(m_req_size),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id), .m_req_prot(m_req_prot),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we),
    .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .rg_base_i(rg_base), .rg_last_i(rg_last), .rg_perm_i(rg_perm), .rg_mmask_i(rg_mmask),
    .flush_i(flush_i), .flush_busy_o(flush_busy_o), .quiesce_i(quiesce_i), .idle_o(idle_o), .init_start_i(init_start_i),
    .init_busy_o(init_busy_o), .scrub_en_i(scrub_en_i),
    .ecc_clr_i(ecc_clr_i), .ev_ce_o(ev_ce_o), .ev_ue_o(ev_ue_o), .ev_addr_o(ev_addr_o), .ce_cnt_o(ce_cnt_o), .ue_cnt_o(ue_cnt_o),
    .perf_clr_i(perf_clr_i), .perf_cycles_o(perf_cycles_o), .perf_acc_rd_o(perf_acc_rd_o), .perf_acc_wr_o(perf_acc_wr_o),
    .perf_conf_o(perf_conf_o), .perf_lost_o(perf_lost_o), .perf_busy_o(perf_busy_o), .perf_mstall_o(perf_mstall_o),
    .perf_arbstall_o(perf_arbstall_o), .perf_busystall_o(perf_busystall_o), .perf_selfconf_o(perf_selfconf_o),
    .perf_starve_o(perf_starve_o), .perf_starve_cls_o(perf_starve_cls_o), .perf_reqs_o(perf_reqs_o),
    .perf_bytes_rd_o(perf_bytes_rd_o), .perf_bytes_wr_o(perf_bytes_wr_o), .perf_lat_sum_o(perf_lat_sum_o),
    .perf_lat_cnt_o(perf_lat_cnt_o), .perf_lat_max_o(perf_lat_max_o), .perf_rej_o(perf_rej_o),
    .trc_acc_o(trc_acc_o), .trc_we_o(trc_we_o), .trc_m_o(trc_m_o), .trc_slot_o(trc_slot_o), .trc_k_o(trc_k_o), .trc_row_o(trc_row_o),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W{1'b0}}),
    .tst_wdata_i({STORE_W{1'b0}}), .tst_rdata_o(tst_rdata_o),
    .fi_bank(fi_bank), .fi_type(fi_type), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2),
    .fi_val(fi_val), .fi_val2(fi_val2), .seu_pulse(seu_pulse), .seu_row(seu_row), .seu_mask(seu_mask));

  // ------------------------------------------------------------ bookkeeping
  int errors = 0, checks = 0, tests = 0;
  int tb_cyc = 0;
  task automatic chk(input bit ok, input string msg);
    checks++;
    if (!ok) begin
      errors++;
      if (errors <= 25) $display("  ERROR @cyc %0d: %s", tb_cyc, msg);
      if (errors == 100) begin        // a broken DUT is not simulated to the end
        $display("RESULT tb=memory_matrix ABORT after 100 errors tests=%0d checks=%0d errors=%0d cycles=%0d FAIL", tests, checks, errors, tb_cyc);
        $finish;
      end
    end
  endtask

  int seed;
  function automatic int rnd();
    seed = seed ^ (seed << 13); seed = seed ^ (seed >>> 17); seed = seed ^ (seed << 5);
    rnd = seed & 32'h7FFF_FFFF;
  endfunction
  function automatic logic [511:0] rnd512();
    logic [511:0] v;
    begin
      for (int i = 0; i < 16; i++) v[i*32 +: 32] = 32'(rnd()) ^ (32'(rnd()) << 16);
      rnd512 = v;
    end
  endfunction
  function automatic bit pct(input int p);       // true with probability p percent
    pct = ((rnd() % 100) < p);
  endfunction

  // ------------------------------------------------------------ independent address map (integer arithmetic)
  function automatic int ref_fold(input int row);
    int f, r;
    begin f = 0; r = row; while (r > 0) begin f = f ^ (r % NB); r = r / NB; end ref_fold = f; end
  endfunction
  function automatic int tb_bank_of(input int w);
    int g, b, row;
    begin
      g = 1 << ILV_GRAN_LOG2;
      if (INTERLEAVE_MODE == `SF_MM_ILV_LINEAR) b = w / BANK_DEPTH;
      else begin
        b = (w / g) % NB; row = (w / (g * NB)) * g + (w % g);
        if (INTERLEAVE_MODE == `SF_MM_ILV_XOR) b = b ^ ref_fold(row);
      end
      tb_bank_of = b;
    end
  endfunction
  function automatic int tb_row_of(input int w);
    int g;
    begin
      g = 1 << ILV_GRAN_LOG2;
      if (INTERLEAVE_MODE == `SF_MM_ILV_LINEAR) tb_row_of = w % BANK_DEPTH;
      else tb_row_of = (w / (g * NB)) * g + (w % g);
    end
  endfunction
  function automatic int tb_unmap(input int b, input int row);
    int g, lb_, rhi, low;
    begin
      g = 1 << ILV_GRAN_LOG2;
      if (INTERLEAVE_MODE == `SF_MM_ILV_LINEAR) tb_unmap = b * BANK_DEPTH + row;
      else begin
        lb_ = b;
        if (INTERLEAVE_MODE == `SF_MM_ILV_XOR) lb_ = b ^ ref_fold(row);
        rhi = row / g; low = row % g;
        tb_unmap = ((rhi * NB + lb_) * g) + low;
      end
    end
  endfunction

  // ------------------------------------------------------------ reference status prediction (written from the spec)
  function automatic bit ref_byte_ok(input longint p, input bit is_we, input bit [1:0] pr, input int m);
    bit found, ok;
    begin
      found = 0; ok = (DEFAULT_ALLOW != 0);
      for (int r = 0; r < NUM_REGIONS; r++) begin
        if (!found && rg_perm[r*5 + 4] && p >= longint'(rg_base[r*AW +: AW]) && p <= longint'(rg_last[r*AW +: AW])) begin
          found = 1;
          ok = (is_we ? rg_perm[r*5 + 1] : rg_perm[r*5 + 0]) && (!rg_perm[r*5 + 2] || pr[0]) &&
               (!rg_perm[r*5 + 3] || pr[1]) && rg_mmask[r*NM + m];
        end
      end
      ref_byte_ok = ok;
    end
  endfunction
  function automatic [2:0] ref_status(input longint a, input int sz, input bit is_we, input bit [1:0] pr, input int m);
    longint nb, last;
    begin
      nb = (sz > SZ_MAX) ? 1 : (longint'(1) << sz);
      last = a + nb - 1;
      if (sz > SZ_MAX)                                        ref_status = `SF_ST_BADOP;
      else if (a >= CAPB || last >= CAPB)                     ref_status = `SF_ST_RANGE;
      else if (MISALIGN_EN == 0 && (a % nb) != 0)             ref_status = `SF_ST_ALIGN;
      else if (NUM_REGIONS > 0 && !(ref_byte_ok(a, is_we, pr, m) && ref_byte_ok(last, is_we, pr, m))) ref_status = `SF_ST_PERM;
      else                                                    ref_status = `SF_ST_OK;
    end
  endfunction

  // ------------------------------------------------------------ byte image of the aperture
  logic [7:0] ref_mem   [0:CAPBI-1];
  bit         ref_known [0:CAPBI-1];
  task automatic model_forget_all();
    for (longint i = 0; i < CAPB; i++) ref_known[i] = 0;
  endtask
  task automatic model_zero_all();
    for (longint i = 0; i < CAPB; i++) begin ref_known[i] = 1; ref_mem[i] = 8'h00; end
  endtask

  // ------------------------------------------------------------ request records (one ring of NSLOT per master)
  localparam int NREC = NM * NSLOT;
  longint        r_addr  [0:NREC-1];
  int            r_size  [0:NREC-1];
  bit            r_we    [0:NREC-1];
  logic [63:0]   r_be    [0:NREC-1];
  logic [511:0]  r_wd    [0:NREC-1];
  logic [IDW-1:0] r_id   [0:NREC-1];
  logic [2:0]    r_stat  [0:NREC-1];
  int            r_t0    [0:NREC-1];
  logic [15:0]   r_kexp  [0:NREC-1];
  logic [15:0]   r_kdone [0:NREC-1];
  logic [511:0]  r_rd    [0:NREC-1];
  logic [63:0]   r_known [0:NREC-1];
  bit            r_live  [0:NREC-1];
  bit            r_ovr   [0:NREC-1];       // directed expectation override (ECC tests)
  logic [2:0]    r_ostat [0:NREC-1];
  bit            r_oce   [0:NREC-1];
  bit            r_onoapp[0:NREC-1];       // the write is expected to be aborted (no memory effect)
  bit            r_ochkd [0:NREC-1];       // compare read data even though the override is active
  int            acc_n [0:NM-1];
  int            pop_n [0:NM-1];

  // last response seen per master (for directed tests)
  logic [2:0]    last_status [0:NM-1];
  bit            last_ce     [0:NM-1];
  logic [511:0]  last_rdata  [0:NM-1];
  int            last_lat    [0:NM-1];

  // ------------------------------------------------------------ driver shadow state
  bit            d_valid [0:NM-1];
  longint        d_addr  [0:NM-1];
  int            d_size  [0:NM-1];
  bit            d_we    [0:NM-1];
  logic [63:0]   d_be    [0:NM-1];
  logic [511:0]  d_wd    [0:NM-1];
  logic [IDW-1:0] d_id   [0:NM-1];
  logic [1:0]    d_prot  [0:NM-1];
  bit            d_ovr   [0:NM-1];
  logic [2:0]    d_ostat [0:NM-1];
  bit            d_oce   [0:NM-1];
  bit            d_onoapp[0:NM-1];
  bit            d_ochkd [0:NM-1];
  bit            d_rrdy  [0:NM-1];
  int            idseq   [0:NM-1];

  // directed one-shot request (set by tasks)
  bit            dir_pend [0:NM-1];
  longint        dir_addr [0:NM-1];
  int            dir_size [0:NM-1];
  bit            dir_we   [0:NM-1];
  logic [63:0]   dir_be   [0:NM-1];
  logic [511:0]  dir_wd   [0:NM-1];
  logic [1:0]    dir_prot [0:NM-1];
  bit            dir_ovr  [0:NM-1];
  logic [2:0]    dir_ostat[0:NM-1];
  bit            dir_oce  [0:NM-1];
  bit            dir_onoapp[0:NM-1];
  bit            dir_ochkd[0:NM-1];

  // random generator configuration (a "phase")
  bit            g_en     [0:NM-1];
  int            g_left   [0:NM-1];       // requests still to issue
  int            g_pvalid, g_prsp, g_pwr;
  int            g_amode;                 // 0 uniform, 1 hot words, 2 bank-targeted, 3 sweep
  int            g_bank   [0:NM-1];       // target bank for amode 2 (or -1)
  int            g_hotn;                  // number of hot words
  int            g_perr;                  // percent of out-of-range / illegal-size requests
  int            g_sizemode;              // 0 mixed sizes, 1 always full width, 2 always one word, 3 narrow (1..4 bytes)
  int            g_bemode;                // 0 mixed, 1 all ones
  longint        g_sweep  [0:NM-1];
  int            hot_wi   [0:63];
  bit            stop_trace;              // (debug)
  // ------------------------------------------------------------ perf mirror
  int            mi_cycles;
  int            mi_acc_rd [0:NB-1];
  int            mi_acc_wr [0:NB-1];
  int            mi_reqs   [0:NM-1];
  int            mi_brd    [0:NM-1];
  int            mi_bwr    [0:NM-1];
  longint        mi_lsum   [0:NM-1];
  int            mi_lcnt   [0:NM-1];
  int            mi_rej;
  int            tot_acc_cycles;          // cycles with at least one bank access (for throughput checks)
  int            tot_acc_words;
  int            tot_pops;

  function automatic int popcnt64(input logic [63:0] v);
    int c;
    begin c = 0; for (int i = 0; i < 64; i++) c += int'(v[i]); popcnt64 = c; end
  endfunction

  task automatic mirror_clear();
    mi_cycles = 0; mi_rej = 0; tot_acc_cycles = 0; tot_acc_words = 0; tot_pops = 0;
    for (int b = 0; b < NB; b++) begin mi_acc_rd[b] = 0; mi_acc_wr[b] = 0; end
    for (int m = 0; m < NM; m++) begin mi_reqs[m] = 0; mi_brd[m] = 0; mi_bwr[m] = 0; mi_lsum[m] = 0; mi_lcnt[m] = 0; end
  endtask

  task automatic perf_compare(input string tag);
    @(negedge clk);                       // sample when both the DUT counters and the mirror are settled
    for (int b = 0; b < NB; b++) begin
      chk(int'(perf_acc_rd_o[b*32 +: 32]) == mi_acc_rd[b], $sformatf("%s: perf acc_rd[%0d] dut=%0d mirror=%0d", tag, b, perf_acc_rd_o[b*32 +: 32], mi_acc_rd[b]));
      chk(int'(perf_acc_wr_o[b*32 +: 32]) == mi_acc_wr[b], $sformatf("%s: perf acc_wr[%0d] dut=%0d mirror=%0d", tag, b, perf_acc_wr_o[b*32 +: 32], mi_acc_wr[b]));
      chk(perf_conf_o[b*32 +: 32] <= perf_cycles_o, $sformatf("%s: conflict cycles exceed cycles (bank %0d)", tag, b));
      chk(perf_busy_o[b*32 +: 32] <= perf_cycles_o, $sformatf("%s: busy cycles exceed cycles (bank %0d)", tag, b));
    end
    for (int m = 0; m < NM; m++) begin
      chk(int'(perf_reqs_o[m*32 +: 32]) == mi_reqs[m], $sformatf("%s: perf reqs[%0d] dut=%0d mirror=%0d", tag, m, perf_reqs_o[m*32 +: 32], mi_reqs[m]));
      chk(int'(perf_bytes_rd_o[m*32 +: 32]) == mi_brd[m], $sformatf("%s: perf bytes_rd[%0d] dut=%0d mirror=%0d", tag, m, perf_bytes_rd_o[m*32 +: 32], mi_brd[m]));
      chk(int'(perf_bytes_wr_o[m*32 +: 32]) == mi_bwr[m], $sformatf("%s: perf bytes_wr[%0d] dut=%0d mirror=%0d", tag, m, perf_bytes_wr_o[m*32 +: 32], mi_bwr[m]));
      chk(longint'(perf_lat_sum_o[m*40 +: 40]) == mi_lsum[m], $sformatf("%s: perf lat_sum[%0d] dut=%0d mirror=%0d", tag, m, perf_lat_sum_o[m*40 +: 40], mi_lsum[m]));
      chk(int'(perf_lat_cnt_o[m*32 +: 32]) == mi_lcnt[m], $sformatf("%s: perf lat_cnt[%0d] dut=%0d mirror=%0d", tag, m, perf_lat_cnt_o[m*32 +: 32], mi_lcnt[m]));
      chk(perf_starve_o[m*32 +: 32] <= perf_cycles_o, $sformatf("%s: starve cycles exceed cycles (master %0d)", tag, m));
    end
    chk(int'(perf_rej_o) == mi_rej, $sformatf("%s: perf rej dut=%0d mirror=%0d", tag, perf_rej_o, mi_rej));
    chk(int'(perf_cycles_o) == mi_cycles, $sformatf("%s: perf cycles dut=%0d mirror=%0d", tag, perf_cycles_o, mi_cycles));
  endtask

  // ------------------------------------------------------------ expected-word helper
  // lane j of a request <-> global byte addr + j ; word index relative to the first word
  function automatic logic [15:0] exp_kmask(input longint a, input int sz, input bit is_we, input logic [63:0] be);
    logic [15:0] km;
    longint g;
    int nb;
    begin
      km = '0; nb = 1 << sz;
      for (int j = 0; j < nb && j < 64; j++) begin
        if (!is_we || be[j]) begin
          g = a + j;
          km[int'((g / WB) - (a / WB))] = 1'b1;
        end
      end
      exp_kmask = km;
    end
  endfunction

  // ------------------------------------------------------------ the clocked checker / driver
  logic          pr_valid [0:NM-1];
  logic          pr_ready [0:NM-1];
  logic [DATA_WIDTH-1:0] pr_rdata [0:NM-1];
  logic [IDW-1:0] pr_id   [0:NM-1];
  logic          pr_we    [0:NM-1];
  logic [2:0]    pr_st    [0:NM-1];
  logic          pr_ce    [0:NM-1];
  bit            checks_en = 0;           // off during reset
  bit            ready_check_en = 1;
  int            out_pre [0:NM-1];
  bit            clr_now;

  always @(posedge clk) begin : p_main
    tb_cyc <= tb_cyc + 1;
    if (checks_en) begin
      // outstanding requests BEFORE this edge: m_req_ready seen in the cycle that ends at this edge depends on these
      for (int m = 0; m < NM; m++) out_pre[m] = acc_n[m] - pop_n[m];
      clr_now = perf_clr_i;
      // the DUT clears its counters at this edge: events of this edge are not counted

      // ---------- 1. request accepts
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && m_req_ready[m]) begin
          int mi, sl;
          sl = acc_n[m] % NSLOT; mi = m * NSLOT + sl;
          chk(!r_live[mi], $sformatf("m%0d slot %0d accepted while still live", m, sl));
          r_addr[mi] = d_addr[m]; r_size[mi] = d_size[m]; r_we[mi] = d_we[m]; r_be[mi] = d_be[m]; r_wd[mi] = d_wd[m];
          r_id[mi] = d_id[m]; r_t0[mi] = tb_cyc; r_kdone[mi] = '0; r_rd[mi] = '0; r_known[mi] = '0; r_live[mi] = 1;
          r_stat[mi] = ref_status(d_addr[m], d_size[m], d_we[m], d_prot[m], m);
          r_kexp[mi] = (r_stat[mi] == `SF_ST_OK) ? exp_kmask(d_addr[m], d_size[m], d_we[m], d_be[m]) : 16'd0;
          r_ovr[mi] = d_ovr[m]; r_ostat[mi] = d_ostat[m]; r_oce[mi] = d_oce[m]; r_onoapp[mi] = d_onoapp[m]; r_ochkd[mi] = d_ochkd[m];
          d_ovr[m] = 0; d_onoapp[m] = 0; d_ochkd[m] = 0; d_oce[m] = 0;
          acc_n[m]++;
        end
      end

      // ---------- 2. bank accepts (serialisation points)
      for (int b = 0; b < NB; b++) begin
        if (trc_acc_o[b]) begin
          int tm, ts, tk, mi;
          longint wi;
          tm = int'(trc_m_o[b*MW +: MW]); ts = int'(trc_slot_o[b*SW +: SW]); tk = int'(trc_k_o[b*KW +: KW]);
          mi = tm * NSLOT + ts;
          tot_acc_words++;
          if (trc_we_o[b]) mi_acc_wr[b]++; else mi_acc_rd[b]++;
          if (tm >= NM || ts >= NSLOT || !r_live[mi]) begin
            chk(0, $sformatf("bank %0d accepted a word for non-live request (m%0d slot %0d k%0d)", b, tm, ts, tk));
          end else begin
            wi = (r_addr[mi] / WB) + tk;
            chk(r_stat[mi] == `SF_ST_OK, $sformatf("bank %0d accessed for a request that must be rejected (status %0d)", b, r_stat[mi]));
            chk(r_kexp[mi][tk] === 1'b1, $sformatf("m%0d slot %0d: SPURIOUS word access k=%0d (expected mask %b)", tm, ts, tk, r_kexp[mi]));
            chk(r_kdone[mi][tk] === 1'b0, $sformatf("m%0d slot %0d: word k=%0d accessed twice", tm, ts, tk));
            chk(b == tb_bank_of(int'(wi)), $sformatf("m%0d word %0d went to bank %0d, expected %0d", tm, wi, b, tb_bank_of(int'(wi))));
            chk(int'(trc_row_o[b*ROW_W +: ROW_W]) == tb_row_of(int'(wi)), $sformatf("m%0d word %0d went to row %0d, expected %0d", tm, wi, trc_row_o[b*ROW_W +: ROW_W], tb_row_of(int'(wi))));
            chk(trc_we_o[b] == r_we[mi], $sformatf("m%0d word %0d: bank saw we=%0d, request we=%0d", tm, wi, trc_we_o[b], r_we[mi]));
            // PER-MASTER PROGRAM ORDER (contract M1): a word access must not pass an OLDER request of the same master that
            // still has an un-accessed word on the SAME physical word when at least one of the two is a write (RAW / WAW / WAR).
            // This is checked from the request stream alone; the byte model follows the DUT's accept order and would not see it.
            for (int n = pop_n[tm]; n < acc_n[tm]; n++) begin
              int mi2, k2;
              longint d2;
              mi2 = tm * NSLOT + (n % NSLOT);
              if (mi2 != mi && r_live[mi2] && ((n % NSLOT) != ts)) begin
                // is request n older than the accessing request?  seq(accessing) = the n' in [pop_n, acc_n) with n' % NSLOT == ts
                int seq_y;
                seq_y = -1;
                for (int q = pop_n[tm]; q < acc_n[tm]; q++) if ((q % NSLOT) == ts) seq_y = q;
                if (n < seq_y) begin
                  d2 = wi - (r_addr[mi2] / WB);
                  if (d2 >= 0 && d2 < 16) begin
                    k2 = int'(d2);
                    if (r_stat[mi2] == `SF_ST_OK && r_kexp[mi2][k2] && !r_kdone[mi2][k2] && (r_we[mi2] || r_we[mi]))
                      chk(0, $sformatf("PROGRAM ORDER: m%0d request #%0d word %0d overtook older request #%0d (we %0d/%0d) on the same word", tm, seq_y, wi, n, r_we[mi], r_we[mi2]));
                  end
                end
              end
            end
            r_kdone[mi][tk] = 1'b1;
            // apply to / capture from the byte image
            for (int j = 0; j < (1 << r_size[mi]) && j < 64; j++) begin
              longint g;
              g = r_addr[mi] + j;
              if ((g / WB) == wi) begin
                if (r_we[mi]) begin
                  if (r_be[mi][j] && !r_onoapp[mi]) begin
                    ref_mem[g] = r_wd[mi][j*8 +: 8]; ref_known[g] = 1;
                  end
                end else begin
                  r_rd[mi][j*8 +: 8] = ref_mem[g]; r_known[mi][j] = ref_known[g];
                end
              end
            end
          end
        end
      end
      begin
        int na;
        na = 0;
        for (int b = 0; b < NB; b++) na += int'(trc_acc_o[b]);
        if (na > 0) tot_acc_cycles++;
      end

      // ---------- 3. responses
      for (int m = 0; m < NM; m++) begin
        // stability of a stalled response (flush may withdraw it: contract M7)
        if (pr_valid[m] && !pr_ready[m] && !flush_busy_o && rst_n) begin
          chk(m_rsp_valid[m], $sformatf("m%0d response dropped while stalled", m));
          chk(m_rsp_rdata[m*DATA_WIDTH +: DATA_WIDTH] === pr_rdata[m] && m_rsp_id[m*IDW +: IDW] === pr_id[m] && m_rsp_we[m] === pr_we[m] &&
              m_rsp_status[m*3 +: 3] === pr_st[m] && m_rsp_ce[m] === pr_ce[m], $sformatf("m%0d response payload changed while stalled", m));
        end
        pr_valid[m] = m_rsp_valid[m]; pr_ready[m] = m_rsp_ready[m];
        pr_rdata[m] = m_rsp_rdata[m*DATA_WIDTH +: DATA_WIDTH]; pr_id[m] = m_rsp_id[m*IDW +: IDW]; pr_we[m] = m_rsp_we[m];
        pr_st[m] = m_rsp_status[m*3 +: 3]; pr_ce[m] = m_rsp_ce[m];

        if (m_rsp_valid[m]) begin
          chk(pop_n[m] < acc_n[m], $sformatf("m%0d response with nothing outstanding", m));
        end
        if (m_rsp_valid[m] && m_rsp_ready[m] && pop_n[m] < acc_n[m]) begin
          int mi, sl, nb;
          logic [2:0] est;
          sl = pop_n[m] % NSLOT; mi = m * NSLOT + sl; nb = 1 << r_size[mi];
          est = r_ovr[mi] ? r_ostat[mi] : r_stat[mi];
          chk(r_live[mi], $sformatf("m%0d response for a non-live record", m));
          chk(m_rsp_id[m*IDW +: IDW] === r_id[mi], $sformatf("m%0d id %0h expected %0h", m, m_rsp_id[m*IDW +: IDW], r_id[mi]));
          chk(m_rsp_we[m] === r_we[mi], $sformatf("m%0d rsp_we %0d expected %0d", m, m_rsp_we[m], r_we[mi]));
          chk(m_rsp_status[m*3 +: 3] === est, $sformatf("m%0d status %0d expected %0d (addr %0d size %0d we %0d)", m, m_rsp_status[m*3 +: 3], est, r_addr[mi], r_size[mi], r_we[mi]));
          chk(m_rsp_ce[m] === (r_ovr[mi] ? r_oce[mi] : 1'b0), $sformatf("m%0d ce flag %0d unexpected", m, m_rsp_ce[m]));
          if (!r_ovr[mi] || est != `SF_ST_ECC_UE) begin
            chk(r_kdone[mi] == r_kexp[mi], $sformatf("m%0d request completed with word mask %b, expected %b", m, r_kdone[mi], r_kexp[mi]));
          end
          if (r_we[mi] || est != `SF_ST_OK) begin
            if (est != `SF_ST_ECC_UE || r_we[mi])
              chk(m_rsp_rdata[m*DATA_WIDTH +: DATA_WIDTH] === '0, $sformatf("m%0d non-read / error response with rdata != 0", m));
          end else if (!r_ovr[mi] || r_ochkd[mi]) begin
            for (int j = 0; j < DBYTES; j++) begin
              logic [7:0] got;
              got = m_rsp_rdata[m*DATA_WIDTH + j*8 +: 8];
              if (j >= nb)               chk(got === 8'h00, $sformatf("m%0d lane %0d above size %0d not zero: %0h", m, j, nb, got));
              else if (r_known[mi][j])   chk(got === r_rd[mi][j*8 +: 8], $sformatf("m%0d READ MISMATCH addr %0d+%0d lane %0d: got %0h exp %0h", m, r_addr[mi], nb, j, got, r_rd[mi][j*8 +: 8]));
            end
          end
          last_status[m] = m_rsp_status[m*3 +: 3]; last_ce[m] = m_rsp_ce[m]; last_rdata[m] = 512'(m_rsp_rdata[m*DATA_WIDTH +: DATA_WIDTH]);
          last_lat[m] = tb_cyc - r_t0[mi];
          mi_reqs[m]++; tot_pops++;
          if (r_we[mi]) mi_bwr[m] += (est == `SF_ST_OK || est == `SF_ST_ECC_UE) ? popcnt64(r_be[mi] & ((nb >= 64) ? 64'hFFFF_FFFF_FFFF_FFFF : ((64'd1 << nb) - 64'd1))) : 0;
          else          mi_brd[m] += (est == `SF_ST_OK || est == `SF_ST_ECC_UE) ? nb : 0;
          mi_lsum[m] += longint'(tb_cyc - r_t0[mi]); mi_lcnt[m]++;
          if (est != `SF_ST_OK) mi_rej++;
          r_live[mi] = 0; pop_n[m]++;
        end
      end

      // ---------- 4. exact queue-depth / ready check (registered-state-only back-pressure)
      if (ready_check_en && !flush_i && !quiesce_i && !flush_busy_o) begin
        for (int m = 0; m < NM; m++)
          chk(m_req_ready[m] === (out_pre[m] < NSLOT),
              $sformatf("m%0d m_req_ready=%0d but outstanding=%0d (NSLOT=%0d)", m, m_req_ready[m], out_pre[m], NSLOT));
      end

      // ---------- perf mirror window
      if (clr_now) mirror_clear(); else mi_cycles++;

      // ---------- 5. next request / response-ready values
      for (int m = 0; m < NM; m++) begin
        if (d_valid[m] && m_req_ready[m]) d_valid[m] = 0;
        if (!d_valid[m]) begin
          if (dir_pend[m]) begin
            d_valid[m] = 1; d_addr[m] = dir_addr[m]; d_size[m] = dir_size[m]; d_we[m] = dir_we[m]; d_be[m] = dir_be[m]; d_wd[m] = dir_wd[m];
            d_prot[m] = dir_prot[m]; d_ovr[m] = dir_ovr[m]; d_ostat[m] = dir_ostat[m]; d_oce[m] = dir_oce[m];
            d_onoapp[m] = dir_onoapp[m]; d_ochkd[m] = dir_ochkd[m];
            d_id[m] = IDW'(idseq[m] * 7 + m); idseq[m]++;
            dir_pend[m] = 0;
          end else if (g_en[m] && g_left[m] > 0 && pct(g_pvalid)) begin
            gen_request(m);
            d_valid[m] = 1; g_left[m]--;
          end
        end
        d_rrdy[m] = pct(g_prsp);
      end
    end
    // ---------- drive (non-blocking so the DUT sees the values after this edge)
    rst_n       <= c_rst_n;
    flush_i     <= c_flush_req;   c_flush_req = 0;
    perf_clr_i  <= c_clr_req;     c_clr_req   = 0;
    quiesce_i   <= c_quiesce;
    scrub_en_i  <= c_scrub;
    seu_pulse   <= c_seu_req;     c_seu_req   = 0;
    fi_bank     <= c_fi_bank;  seu_row <= c_seu_row;  seu_mask <= c_seu_mask;
    for (int m = 0; m < NM; m++) begin
      m_req_valid[m] <= d_valid[m] & c_rst_n;
      m_req_we[m] <= d_we[m];
      m_req_addr[m*AW +: AW] <= AW'(d_addr[m]);
      m_req_size[m*SZW +: SZW] <= SZW'(d_size[m]);
      m_req_wdata[m*DATA_WIDTH +: DATA_WIDTH] <= d_wd[m][DATA_WIDTH-1:0];
      m_req_be[m*DBYTES +: DBYTES] <= d_be[m][DBYTES-1:0];
      m_req_id[m*IDW +: IDW] <= d_id[m];
      m_req_prot[m*2 +: 2] <= d_prot[m];
      m_rsp_ready[m] <= d_rrdy[m];
    end
  end

  // ------------------------------------------------------------ random request generator
  task automatic gen_request(input int m);
    int sz, nbm, bk, row;
    longint a, wi;
    bit we;
    begin
      we = pct(g_pwr);
      case (g_sizemode)
        1: sz = SZ_MAX;
        2: sz = (LB <= SZ_MAX) ? LB : SZ_MAX;
        3: sz = rnd() % ((SZ_MAX >= 2) ? 3 : (SZ_MAX + 1));
        default: sz = rnd() % (SZ_MAX + 1);
      endcase
      if (pct(g_perr) && g_perr > 0) begin
        // out-of-range or illegal size
        case (rnd() % 4)
          0: a = CAPB - 1 - (rnd() % 16);
          1: a = CAPB + (rnd() % 64);
          2: a = (longint'(1) << AW) - 1 - (rnd() % 8);
          default: a = CAPB - (longint'(1) << sz) + (rnd() % 4);
        endcase
        if ((SZW > 0) && ((1 << SZW) > SZ_MAX + 1) && pct(25)) sz = SZ_MAX + 1 + (rnd() % ((1 << SZW) - SZ_MAX - 1));
      end else begin
        case (g_amode)
          1: begin
               wi = hot_wi[rnd() % g_hotn];
               a = wi * WB + (pct(50) ? (rnd() % WB) : 0);
             end
          2: begin
               bk = (g_bank[m] >= 0) ? g_bank[m] : (rnd() % NB);
               row = rnd() % BANK_DEPTH;
               a = longint'(tb_unmap(bk, row)) * WB;
               sz = (sz > LB) ? LB : sz;
             end
          3: begin
               a = g_sweep[m]; g_sweep[m] = g_sweep[m] + DBYTES; if (g_sweep[m] >= CAPB) g_sweep[m] = 0;
               sz = SZ_MAX;
             end
          default: a = longint'(rnd()) % CAPB;
        endcase
        if (g_amode != 2 && g_amode != 3) begin
          if (MISALIGN_EN != 0) begin
            if (pct(50)) a = a & ~((longint'(1) << sz) - 1);
          end else begin
            if (pct(90)) a = a & ~((longint'(1) << sz) - 1);
          end
        end
        if (g_amode == 3) a = a & ~((longint'(1) << sz) - 1);
      end
      d_addr[m] = a; d_size[m] = sz; d_we[m] = we; d_wd[m] = rnd512();
      case ((g_bemode == 1) ? 1 : (rnd() % 4))
        0: d_be[m] = {rnd512()} ;
        1: d_be[m] = 64'hFFFF_FFFF_FFFF_FFFF;
        2: d_be[m] = 64'(rnd()) & 64'(rnd()) & 64'(rnd());
        default: d_be[m] = 64'(1) << (rnd() % 64);
      endcase
      if (pct(20) && g_bemode != 1) d_be[m] = '0;
      d_prot[m] = 2'(rnd());
      d_id[m] = IDW'(idseq[m] * 7 + m); idseq[m]++;
      d_ovr[m] = 0; d_onoapp[m] = 0; d_ochkd[m] = 0; d_oce[m] = 0;
    end
  endtask

  // ------------------------------------------------------------ test infrastructure
  task automatic do_clr();                          // start a measurement window (DUT counters and mirror cleared together)
    c_clr_req = 1;
    repeat (3) @(posedge clk);
  endtask
  task automatic idle_all();
    for (int m = 0; m < NM; m++) begin g_en[m] = 0; g_left[m] = 0; end
  endtask
  task automatic cfg_default();
    g_pvalid = 100; g_prsp = 100; g_pwr = 50; g_amode = 0; g_hotn = 16; g_perr = 0; g_sizemode = 0; g_bemode = 0;
    for (int m = 0; m < NM; m++) begin g_bank[m] = -1; g_sweep[m] = longint'(m) * DBYTES; end
    for (int i = 0; i < 64; i++) hot_wi[i] = rnd() % CAPW;
  endtask
  // wait until every issued request is answered and the DUT is idle
  task automatic drain(input int maxcyc);
    int t;
    bit busy;
    t = 0; busy = 1;
    while (busy && t < maxcyc) begin
      @(posedge clk); t++;
      busy = 0;
      for (int m = 0; m < NM; m++) begin
        if (g_en[m] && g_left[m] > 0) busy = 1;
        if (acc_n[m] != pop_n[m] || d_valid[m] || dir_pend[m]) busy = 1;
      end
    end
    chk(!busy, $sformatf("drain timed out after %0d cycles (deadlock or lost response)", maxcyc));
    repeat (3) @(posedge clk);
  endtask
  task automatic run_phase(input string name, input int n, input int maxcyc);
    tests++;
    for (int m = 0; m < NM; m++) begin g_en[m] = 1; g_left[m] = n; end
    $display("[%0t] %s", $time, name);
    drain(maxcyc);
    idle_all();
  endtask

  // directed request; returns after the response has been checked
  task automatic send(input int m, input longint a, input int sz, input bit we, input logic [63:0] be, input logic [511:0] wd, input logic [1:0] pr = 2'b11);
    int target;
    int t;
    begin
      target = acc_n[m] + (dir_pend[m] ? 1 : 0) + (d_valid[m] ? 1 : 0) + 1;
      while (dir_pend[m]) @(posedge clk);
      dir_addr[m] = a; dir_size[m] = sz; dir_we[m] = we; dir_be[m] = be; dir_wd[m] = wd; dir_prot[m] = pr; dir_pend[m] = 1;
      t = 0;
      while (pop_n[m] < target && t < 5000) begin @(posedge clk); t++; end
      chk(pop_n[m] >= target, $sformatf("directed request m%0d addr %0d timed out", m, a));
    end
  endtask
  task automatic send_ovr(input int m, input longint a, input int sz, input bit we, input logic [63:0] be, input logic [511:0] wd,
                          input logic [2:0] ostat, input bit oce, input bit noapp, input bit chkd);
    begin
      while (dir_pend[m]) @(posedge clk);
      dir_ovr[m] = 1; dir_ostat[m] = ostat; dir_oce[m] = oce; dir_onoapp[m] = noapp; dir_ochkd[m] = chkd;
      send(m, a, sz, we, be, wd);
      dir_ovr[m] = 0; dir_onoapp[m] = 0; dir_ochkd[m] = 0; dir_oce[m] = 0;
    end
  endtask
  function automatic logic [63:0] ones(input int n);
    ones = (n >= 64) ? 64'hFFFF_FFFF_FFFF_FFFF : ((64'd1 << n) - 64'd1);
  endfunction

  task automatic do_reset(input int cycles);
    // Requests are withdrawn first (a master is idle while rst_n is low, as for any valid/ready bus), the checker keeps
    // running through the reset edge so every word a bank accepted before the reset is in the model (the model is exact:
    // nothing is rolled back by reset), then all control state is re-synchronised.
    for (int m = 0; m < NM; m++) begin g_en[m] = 0; g_left[m] = 0; d_valid[m] = 0; dir_pend[m] = 0; end
    repeat (2) @(posedge clk);
    c_rst_n = 0;
    repeat (3) @(posedge clk);
    checks_en = 0;
    for (int m = 0; m < NM; m++) begin
      acc_n[m] = 0; pop_n[m] = 0; d_valid[m] = 0; dir_pend[m] = 0; pr_valid[m] = 0; pr_ready[m] = 0;
      for (int s = 0; s < NSLOT; s++) r_live[m * NSLOT + s] = 0;
    end
    repeat (cycles) @(posedge clk);
    c_rst_n = 1;
    if (ENABLE_ECC != 0) model_zero_all();            // the init engine re-zeroes every row (an in-flight RMW is lost)
    mirror_clear();
    @(posedge clk);
    checks_en = 1;
  endtask
  task automatic wait_idle(input int maxcyc);
    int t;
    t = 0;
    while (!idle_o && t < maxcyc) begin @(posedge clk); t++; end
    chk(idle_o, "idle_o never rose");
    repeat (2) @(posedge clk);
  endtask

  // ECC fault injection on a word (global word index): XOR mask into the stored codeword
  task automatic inject(input int wi, input logic [STORE_W-1:0] mask);
    begin
      c_fi_bank = BW'(tb_bank_of(wi)); c_seu_row = ROW_W'(tb_row_of(wi)); c_seu_mask = mask;
      c_seu_req = 1;
      repeat (4) @(posedge clk);
    end
  endtask

  // ------------------------------------------------------------ the test sequence
  logic [511:0] w1, w2;
  int   lat_ref, cyc0;
  logic [NB*32-1:0] snap;
  int   na, nb_, cnt_snap;
  longint ad;
  int   tp;

  initial begin
    seed = SEED;
    clk = 0; rst_n = 0; c_rst_n = 0;
    m_req_valid = '0; m_req_we = '0; m_req_addr = '0; m_req_size = '0; m_req_wdata = '0; m_req_be = '0; m_req_id = '0; m_req_prot = '0;
    m_rsp_ready = '1;
    rg_base = '0; rg_last = '0; rg_perm = '0; rg_mmask = '0;
    fi_bank = '0; fi_type = '0; fi_row = '0; fi_row2 = '0; fi_bit = '0; fi_bit2 = '0; fi_val = 0; fi_val2 = 0; seu_pulse = 0; seu_row = '0; seu_mask = '0;
    for (int m = 0; m < NM; m++) begin
      acc_n[m] = 0; pop_n[m] = 0; d_valid[m] = 0; d_addr[m] = 0; d_size[m] = 0; d_we[m] = 0; d_be[m] = 0; d_wd[m] = 0; d_id[m] = 0; d_prot[m] = 0;
      d_ovr[m] = 0; d_ostat[m] = 0; d_oce[m] = 0; d_onoapp[m] = 0; d_ochkd[m] = 0; d_rrdy[m] = 1; idseq[m] = 0;
      dir_pend[m] = 0; dir_ovr[m] = 0; dir_onoapp[m] = 0; dir_ochkd[m] = 0; dir_oce[m] = 0; dir_prot[m] = 3;
      g_en[m] = 0; g_left[m] = 0; pr_valid[m] = 0; pr_ready[m] = 0; last_status[m] = 0; last_ce[m] = 0; last_rdata[m] = 0; last_lat[m] = 0;
      for (int s = 0; s < NSLOT; s++) r_live[m * NSLOT + s] = 0;
    end
    cfg_default(); mirror_clear(); model_forget_all();
    if (NUM_REGIONS > 0) begin
      // r0: first quarter RW any master; r1: second quarter read-only priv-only; r2: secure-only RW for masters {0,1}
      rg_base[0*AW +: AW] = AW'(0);          rg_last[0*AW +: AW] = AW'(CAPB / 4 - 1);   rg_perm[0*5 +: 5] = 5'b1_0_0_1_1; rg_mmask[0*NM +: NM] = '1;
      rg_base[1*AW +: AW] = AW'(CAPB / 4);   rg_last[1*AW +: AW] = AW'(CAPB / 2 - 1);   rg_perm[1*5 +: 5] = 5'b1_0_1_0_1; rg_mmask[1*NM +: NM] = '1;
      if (NUM_REGIONS > 2) begin
        rg_base[2*AW +: AW] = AW'(CAPB / 2); rg_last[2*AW +: AW] = AW'(CAPB / 2 + CAPB / 8 - 1); rg_perm[2*5 +: 5] = 5'b1_1_0_1_1; rg_mmask[2*NM +: NM] = NM'(3);
      end
    end
    repeat (4) @(posedge clk);
    c_rst_n = 1;
    $display("tb_memory_matrix NB=%0d DEPTH=%0d WORD=%0d DATA=%0d L=%0d NM=%0d ECC=%0d NSLOT=%0d ARB=%0d ILV=%0d/%0d MISALIGN=%0d REGIONS=%0d BACKEND=%0d K=%0d",
             NB, BANK_DEPTH, WORD_WIDTH, DATA_WIDTH, READ_LATENCY, NM, ENABLE_ECC, NSLOT, ARB, INTERLEAVE_MODE, ILV_GRAN_LOG2, MISALIGN_EN, NUM_REGIONS, BACKEND, K);
    if (ENABLE_ECC != 0) begin
      // the init engine zeroes the arrays after reset; wait for it
      repeat (3) @(posedge clk);
      wait_idle(BANK_DEPTH * 4 + 200);
      model_zero_all();
    end
    mirror_clear();
    @(posedge clk); checks_en = 1;
    do_clr();

    // ============================================================ T01 reset / power-up behaviour
    tests++;
    $display("[%0t] T01 reset and power-up", $time);
    chk(m_rsp_valid === '0, "T01: response valid after reset");
    chk(m_req_ready === {NM{1'b1}}, "T01: m_req_ready low after reset / init (a free queue slot must accept)");
    chk(perf_cycles_o < 32'd20, "T01: perf counters not cleared by reset/clear");
    chk(ce_cnt_o === '0 && ue_cnt_o === '0, "T01: ECC counters not zero");
    if (ENABLE_ECC == 0) begin
      // never-written words must NOT be assumed zero: the simulation image is a poison pattern (SIM_INIT=2)
      if (SIM_INIT == 2 && BACKEND == 0) begin
        int nz;
        nz = 0;
        for (int w = 0; w < 16; w++) begin
          send(0, longint'(w) * WB, WSZ, 0, '0, '0);
          if (last_rdata[0][WBITS-1:0] != '0) nz++;
        end
        chk(nz > 0, "T01: power-up image is all zero although SIM_INIT=2 (poison) was requested");
      end
    end else begin
      // ECC: the init engine wrote valid-ECC zero lines: every word reads zero with status OK and no CE
      for (int w = 0; w < 8; w++) begin
        send(0, longint'(w * 37 % CAPW) * WB, WSZ, 0, '0, '0);
        chk(last_status[0] == `SF_ST_OK && last_rdata[0][WBITS-1:0] == '0, "T01: ECC init image not zero");
      end
    end
    drain(2000);

    // ============================================================ T02 directed read / write, all sizes and offsets, latency
    tests++;
    $display("[%0t] T02 directed accesses (sizes, offsets, bank spanning)", $time);
    w1 = rnd512();
    // single aligned word write + read, minimum latency
    send(0, 0, WSZ, 1, ones(1 << WSZ), w1);
    chk(last_lat[0] == BANK_LAT + 1, $sformatf("T02: lone write latency %0d, expected %0d", last_lat[0], BANK_LAT + 1));
    send(0, 0, WSZ, 0, '0, '0);
    chk(last_lat[0] == BANK_LAT + 1, $sformatf("T02: lone read latency %0d, expected %0d", last_lat[0], BANK_LAT + 1));
    chk(last_rdata[0][WBITS-1:0] == w1[WBITS-1:0], "T02: word read-back");
    for (int sz = 0; sz <= SZ_MAX; sz++) begin
      for (int off = 0; off < ((MISALIGN_EN != 0) ? 2 * WB : 1); off++) begin
        ad = 64 + longint'(sz) * 256 + off + ((MISALIGN_EN != 0) ? 0 : 0);
        if (MISALIGN_EN == 0) ad = (ad + (1 << sz) - 1) & ~((longint'(1) << sz) - 1);
        send(0, ad, sz, 1, ones(1 << sz), rnd512());
        send(1 % NM, ad, sz, 0, '0, '0);            // read back through another master
      end
    end
    // lone request spanning two banks completes in the same time as a one-word request
    if (K >= 2 && MISALIGN_EN != 0 && DBYTES > WB) begin
      send(0, 3 * WB - 2, SZ_MAX, 0, '0, '0);
      chk(last_status[0] == `SF_ST_OK, "T02: bank-spanning read must complete OK");
    end
    drain(2000);

    // ============================================================ T03 address boundaries
    tests++;
    $display("[%0t] T03 address boundaries and illegal requests", $time);
    send(0, 0, 0, 1, 64'h1, 512'hAA);                        send(0, 0, 0, 0, '0, '0);
    send(0, CAPB - 1, 0, 1, 64'h1, 512'h5C);                 send(0, CAPB - 1, 0, 0, '0, '0);
    chk(last_status[0] != `SF_ST_OK || last_rdata[0][7:0] == 8'h5C, "T03: last byte of the aperture");
    chk(ref_status(CAPB - 1, 0, 0, 2'b11, 0) != `SF_ST_OK || last_status[0] == `SF_ST_OK, "T03: last byte of the aperture must be accessible");
    send(0, CAPB - WB, WSZ, 1, ones(1 << WSZ), rnd512());           send(0, CAPB - WB, WSZ, 0, '0, '0);
    send(0, CAPB - DBYTES, SZ_MAX, 1, ones(DBYTES), rnd512()); send(0, CAPB - DBYTES, SZ_MAX, 0, '0, '0);
    send(0, CAPB, 0, 0, '0, '0);                             chk(last_status[0] == `SF_ST_RANGE, "T03: address == capacity must be RANGE");
    send(0, CAPB, 0, 1, 64'h1, 512'h11);                     chk(last_status[0] == `SF_ST_RANGE, "T03: write at capacity must be RANGE");
    send(0, CAPB - DBYTES + 1, SZ_MAX, 0, '0, '0);           chk(last_status[0] == `SF_ST_RANGE || MISALIGN_EN == 0 && last_status[0] == `SF_ST_ALIGN, "T03: access straddling the end must be RANGE");
    send(0, (longint'(1) << AW) - 1, 0, 0, '0, '0);          chk(last_status[0] == `SF_ST_RANGE, "T03: top of the address space must be RANGE");
    send(0, (longint'(1) << AW) - DBYTES, SZ_MAX, 1, ones(DBYTES), '0); chk(last_status[0] == `SF_ST_RANGE, "T03: wrap-around candidate must be RANGE");
    if (((1 << SZW) - 1) > SZ_MAX) begin
      send(0, 0, SZ_MAX + 1, 0, '0, '0);                     chk(last_status[0] == `SF_ST_BADOP, "T03: illegal size must be BADOP");
    end
    if (MISALIGN_EN == 0) begin
      send(0, 1, 1, 0, '0, '0);                              chk(last_status[0] == `SF_ST_ALIGN, "T03: misaligned access must be ALIGN");
    end
    // a rejected write has no side effect
    send(0, 8, WSZ, 1, ones(1 << WSZ), 512'h77); send(0, 8, WSZ, 0, '0, '0);
    // zero byte-enable write is an acknowledged no-op
    send(0, 16, WSZ, 1, ones(1 << WSZ), 512'h1234567); send(0, 16, WSZ, 1, '0, rnd512()); send(0, 16, WSZ, 0, '0, '0);
    chk(last_status[0] != `SF_ST_OK || last_rdata[0][WBITS-1:0] == WBITS'(512'h1234567), "T03: write with be=0 modified memory");
    drain(2000);

    // ============================================================ T04 simultaneous independent banks (full bank parallelism)
    tests++;
    $display("[%0t] T04 simultaneous independent banks", $time);
    begin
      int act, nreq_;
      act = (NM < NB) ? NM : NB;
      cfg_default(); g_amode = 2; g_pwr = 0; g_sizemode = 2; g_perr = 0;
      // pre-fill so reads are meaningful (written through the DUT, checked by the model)
      for (int m = 0; m < act; m++) g_bank[m] = m;
      g_pwr = 100; g_bemode = 1;
      for (int m = 0; m < NM; m++) begin g_en[m] = (m < act); g_left[m] = (m < act) ? 400 : 0; end
      drain(40000); idle_all();
      g_pwr = 50;
      do_clr();
      cyc0 = tb_cyc; nreq_ = 1500;
      for (int m = 0; m < NM; m++) begin g_en[m] = (m < act); g_left[m] = (m < act) ? nreq_ : 0; end
      drain(40000); idle_all();
      // every active master owns a bank: no master may ever lose arbitration to another, and throughput must be 1 word/master/cycle
      for (int b = 0; b < NB; b++) chk(perf_conf_o[b*32 +: 32] == 0, $sformatf("T04: conflicts counted on bank %0d with disjoint banks: %0d", b, perf_conf_o[b*32 +: 32]));
      for (int m = 0; m < act; m++) chk(perf_arbstall_o[m*32 +: 32] == 0, $sformatf("T04: master %0d arbitration stalls %0d (must be 0)", m, perf_arbstall_o[m*32 +: 32]));
      // sustained rate: act words per cycle apart from queue fill / drain: total cycles <= requests + latency slack
      if (NSLOT >= BANK_LAT + 3) chk((tb_cyc - cyc0) <= nreq_ + BANK_LAT + 12, $sformatf("T04: %0d requests per master took %0d cycles; independent banks must sustain 1 request/cycle/master (NSLOT=%0d)", nreq_, tb_cyc - cyc0, NSLOT));
      perf_compare("T04");
    end

    // ============================================================ T05 same-bank collisions and round-robin fairness
    tests++;
    $display("[%0t] T05 same-bank collisions, fairness", $time);
    if (NM >= 2) begin
      cfg_default(); g_amode = 2; g_pwr = 30; g_sizemode = 2; g_bemode = 1;
      for (int m = 0; m < NM; m++) g_bank[m] = 0;
      do_clr();
      cyc0 = tb_cyc;
      for (int m = 0; m < NM; m++) begin g_en[m] = 1; g_left[m] = 500; end
      drain(200000); idle_all();
      // one single-port bank: 1 access per cycle in total, so cycles >= total words
      chk((tb_cyc - cyc0) >= mi_acc_rd[0] + mi_acc_wr[0], $sformatf("T05: %0d word accesses to one bank in %0d cycles (a single port accepts at most 1 per cycle)", mi_acc_rd[0] + mi_acc_wr[0], tb_cyc - cyc0));
      chk(perf_conf_o[0*32 +: 32] > 100, $sformatf("T05: bank 0 conflict cycles %0d: collisions were not counted", perf_conf_o[0*32 +: 32]));
      for (int b = 1; b < NB; b++) chk(perf_acc_rd_o[b*32 +: 32] + perf_acc_wr_o[b*32 +: 32] == 0, $sformatf("T05: bank %0d accessed although every request targets bank 0", b));
      // fairness: with RR every master finishes together
      if (ARB == 1) begin
        int mn, mx;
        mn = 1 << 30; mx = 0;
        for (int m = 0; m < NM; m++) begin
          mn = (perf_lat_sum_o[m*40 +: 40] / perf_lat_cnt_o[m*32 +: 32] < mn) ? int'(perf_lat_sum_o[m*40 +: 40] / perf_lat_cnt_o[m*32 +: 32]) : mn;
          mx = (perf_lat_sum_o[m*40 +: 40] / perf_lat_cnt_o[m*32 +: 32] > mx) ? int'(perf_lat_sum_o[m*40 +: 40] / perf_lat_cnt_o[m*32 +: 32]) : mx;
        end
        chk(mx <= mn + NM + 2, $sformatf("T05: round-robin unfair: mean latencies range %0d..%0d", mn, mx));
        chk(perf_lat_max_o[0*LAT_W +: LAT_W] < 4 * NM * NSLOT + 40, $sformatf("T05: master 0 max latency %0d unbounded for round robin", perf_lat_max_o[0*LAT_W +: LAT_W]));
      end
      perf_compare("T05");
    end

    // ============================================================ T05b two masters on one bank: exact conflict accounting
    if (NM >= 2 && (NUM_REGIONS == 0)) begin
      tests++;
      $display("[%0t] T05b two-way conflicts: counters", $time);
      cfg_default(); g_amode = 2; g_pwr = 50; g_sizemode = 2; g_bemode = 1;
      for (int m = 0; m < NM; m++) g_bank[m] = 0;
      do_clr();
      cyc0 = tb_cyc;
      for (int m = 0; m < NM; m++) begin g_en[m] = (m < 2); g_left[m] = (m < 2) ? 400 : 0; end
      drain(100000); idle_all();
      begin
        int words, cyc_w;
        words = int'(perf_acc_rd_o[0*32 +: 32]) + int'(perf_acc_wr_o[0*32 +: 32]);
        cyc_w = tb_cyc - cyc0;
        // exactly 800 single-word requests reached bank 0, nobody else did
        chk(words == 800, $sformatf("T05b: %0d word accesses on bank 0, expected 800", words));
        if (ARB == 1) begin
          // round robin: the two masters alternate, a conflict in (almost) every cycle, one loser per cycle
          chk(int'(perf_conf_o[0*32 +: 32]) * 10 >= cyc_w * 7, $sformatf("T05b: bank 0 conflict cycles %0d of %0d (two masters requesting continuously)", perf_conf_o[0*32 +: 32], cyc_w));
          chk(int'(perf_lost_o[0*32 +: 32]) * 10 >= words * 7, $sformatf("T05b: lost arbitrations %0d for %0d accesses", perf_lost_o[0*32 +: 32], words));
          chk(int'(perf_arbstall_o[0*32 +: 32]) > 100 && int'(perf_arbstall_o[1*32 +: 32]) > 100, "T05b: both masters must see arbitration stalls");
        end else begin
          // fixed priority: master 0 never loses and finishes first, so the two masters conflict only while master 0 still has requests
          chk(int'(perf_conf_o[0*32 +: 32]) * 10 >= cyc_w * 4, $sformatf("T05b (fixed): bank 0 conflict cycles %0d of %0d", perf_conf_o[0*32 +: 32], cyc_w));
          chk(int'(perf_lost_o[0*32 +: 32]) * 10 >= words * 4, $sformatf("T05b (fixed): lost arbitrations %0d for %0d accesses", perf_lost_o[0*32 +: 32], words));
          chk(perf_arbstall_o[0*32 +: 32] == 0, "T05b (fixed): the highest-priority master lost an arbitration");
          chk(int'(perf_arbstall_o[1*32 +: 32]) > 100, "T05b (fixed): the lower-priority master saw no arbitration stalls");
        end
        chk(int'(perf_lost_o[0*32 +: 32]) <= words + 8, $sformatf("T05b: lost arbitrations %0d exceed one per access (%0d)", perf_lost_o[0*32 +: 32], words));
        for (int m = 2; m < NM; m++) chk(perf_arbstall_o[m*32 +: 32] == 0 && perf_starve_o[m*32 +: 32] == 0, $sformatf("T05b: idle master %0d reports stalls", m));
        perf_compare("T05b");
      end
    end

    // ============================================================ T06 permission metadata
    if (NUM_REGIONS > 0) begin
      tests++;
      $display("[%0t] T06 permission regions", $time);
      // region 0 [0, CAP/4): RW; region 1 [CAP/4, CAP/2): read-only, privileged; DEFAULT outside
      send(0, 0, WSZ, 1, ones(1 << WSZ), rnd512(), 2'b00);               chk(last_status[0] == `SF_ST_OK, "T06: write in RW region");
      send(0, CAPB / 4, WSZ, 0, '0, '0, 2'b00);                    chk(last_status[0] == `SF_ST_PERM, "T06: unprivileged read of a priv-only region");
      send(0, CAPB / 4, WSZ, 0, '0, '0, 2'b01);                    chk(last_status[0] == `SF_ST_OK, "T06: privileged read of a priv-only region");
      send(0, CAPB / 4, WSZ, 1, ones(1 << WSZ), rnd512(), 2'b01);        chk(last_status[0] == `SF_ST_PERM, "T06: write to a read-only region");
      send(0, CAPB / 4 - 4, 3, 0, '0, '0, 2'b00);                 chk(last_status[0] == `SF_ST_PERM || MISALIGN_EN == 0, "T06: access straddling into a denied region");
      send(0, CAPB / 4 - 8, 3, 0, '0, '0, 2'b00);                 chk(last_status[0] == `SF_ST_OK, "T06: access ending at the last byte of a region");
      if (NM > 2) begin
        send(NM - 1, CAPB / 2, WSZ, 0, '0, '0, 2'b11);             chk(NUM_REGIONS < 3 || last_status[NM-1] == `SF_ST_PERM, "T06: master outside the region mask");
      end
      send(0, CAPB / 2, WSZ, 0, '0, '0, 2'b00);                    chk(NUM_REGIONS < 3 || last_status[0] == `SF_ST_PERM, "T06: non-secure access to secure-only region");
      send(0, CAPB / 2, WSZ, 1, ones(1 << WSZ), 512'h99, 2'b10);         chk(NUM_REGIONS < 3 || last_status[0] == `SF_ST_OK, "T06: secure access to secure-only region");
      drain(2000);
    end

    // ============================================================ T07 random traffic, increasing hostility
    cfg_default(); g_perr = 3;
    run_phase("T07a random, all masters, no back-pressure", NRAND, 400000);
    cfg_default(); g_perr = 3; g_pvalid = 60; g_prsp = 50;
    run_phase("T07b random, request gaps + 50% response ready", NRAND, 800000);
    cfg_default(); g_amode = 1; g_hotn = 12; g_pwr = 55; g_prsp = 25; g_pvalid = 90;
    run_phase("T07c hot words (RAW/WAW across masters), 25% response ready", NRAND, 900000);
    cfg_default(); g_sizemode = 3; g_pwr = 60; g_bemode = 0; g_prsp = 80;
    run_phase("T07d narrow partial writes", NRAND, 600000);
    cfg_default(); g_sizemode = 1; g_pwr = 50; g_perr = 2; g_pvalid = 100; g_prsp = 10;
    run_phase("T07e full-width accesses, 10% response ready (queue full / back-pressure)", NRAND / 2, 1500000);
    cfg_default(); g_amode = 2; g_pwr = 50; g_sizemode = 0;
    run_phase("T07f random banks (bank-targeted, mixed sizes)", NRAND, 600000);
    perf_compare("T07");

    // ============================================================ T08 ECC
    if (ENABLE_ECC != 0 && FAULT_INJECT != 0) begin
      tests++;
      $display("[%0t] T08 ECC: correction, double errors, partial writes, scrubbing interface", $time);
      begin
        int wi1, wi2, bk1, cnt0, uecnt0;
        logic [WBITS-1:0] pat;
        wi1 = 5 + (rnd() % (CAPW - 8)); bk1 = tb_bank_of(wi1);
        pat = WBITS'(rnd512());
        send(0, longint'(wi1) * WB, WSZ, 1, ones(1 << WSZ), 512'(pat));
        // ---- single-bit data/check errors are corrected, flagged, counted
        for (int bit_i = 0; bit_i < STORE_W; bit_i += (STORE_W / 9)) begin
          cnt0 = int'(ce_cnt_o[bk1*CNT_W +: CNT_W]);
          inject(wi1, STORE_W'(1) << bit_i);
          send_ovr(0, longint'(wi1) * WB, WSZ, 0, '0, '0, `SF_ST_OK, 1'b1, 1'b0, 1'b1);
          chk(last_rdata[0][WBITS-1:0] == pat, $sformatf("T08: single-bit error at stored bit %0d not corrected", bit_i));
          chk(int'(ce_cnt_o[bk1*CNT_W +: CNT_W]) == cnt0 + 1, $sformatf("T08: ce counter %0d -> %0d after a single-bit error", cnt0, ce_cnt_o[bk1*CNT_W +: CNT_W]));
          send(0, longint'(wi1) * WB, WSZ, 1, ones(1 << WSZ), 512'(pat));          // a full write repairs the word
          send(0, longint'(wi1) * WB, WSZ, 0, '0, '0);                       // clean read: no CE
        end
        // ---- double-bit error: uncorrectable, reported, never delivered as valid data
        uecnt0 = int'(ue_cnt_o[bk1*CNT_W +: CNT_W]);
        inject(wi1, (STORE_W'(1) << 2) | (STORE_W'(1) << (STORE_W - 3)));
        send_ovr(0, longint'(wi1) * WB, WSZ, 0, '0, '0, `SF_ST_ECC_UE, 1'b0, 1'b0, 1'b0);
        chk(int'(ue_cnt_o[bk1*CNT_W +: CNT_W]) == uecnt0 + 1, "T08: ue counter after a double-bit error");
        // event address (unmap) of the last UE
        // ---- a PARTIAL write to an uncorrectable word is aborted (no memory effect), a full write repairs it
        send_ovr(0, longint'(wi1) * WB + 1, 1, 1, 64'h3, 512'hDEAD, `SF_ST_ECC_UE, 1'b0, 1'b1, 1'b0);
        send_ovr(0, longint'(wi1) * WB, WSZ, 0, '0, '0, `SF_ST_ECC_UE, 1'b0, 1'b0, 1'b0);
        send(0, longint'(wi1) * WB, WSZ, 1, ones(1 << WSZ), 512'(pat));
        send(0, longint'(wi1) * WB, WSZ, 0, '0, '0);
        chk(last_status[0] == `SF_ST_OK && last_rdata[0][WBITS-1:0] == pat, "T08: full write did not repair an uncorrectable word");
        // ---- partial writes on a healthy word (read-modify-write inside the bank)
        for (int off = 0; off < WB; off++) begin
          send(0, longint'(wi1) * WB + off, 0, 1, 64'h1, 512'(rnd512()));
          send(0, longint'(wi1) * WB, WSZ, 0, '0, '0);
          chk(last_status[0] == `SF_ST_OK && last_ce[0] == 0, "T08: partial write left an ECC error");
        end
        // ---- partial-write throughput cost: RMW occupies the bank READ_LATENCY+1 cycles
        cfg_default(); g_amode = 2; g_sizemode = 0; g_pwr = 100; g_bemode = 0;
        for (int m = 0; m < NM; m++) g_bank[m] = 0;
        do_clr();
        for (int m = 0; m < NM; m++) begin g_en[m] = (m < 1); g_left[m] = (m < 1) ? 300 : 0; end
        drain(100000); idle_all();
        chk(perf_busy_o[0*32 +: 32] > 0, "T08: RMW partial writes did not show bank busy cycles");
        perf_compare("T08");
        // ---- events carry the byte address of the failing word
        wi2 = 9 + (rnd() % (CAPW - 16));
        send(0, longint'(wi2) * WB, WSZ, 1, ones(1 << WSZ), 512'(pat));
        inject(wi2, STORE_W'(1) << 7);
        begin
          bit seen_ev;
          int t;
          seen_ev = 0; t = 0;
          // issue the read and watch ev_ce_o / ev_addr_o
          dir_addr[0] = longint'(wi2) * WB; dir_size[0] = LB; dir_we[0] = 0; dir_be[0] = '0; dir_wd[0] = '0; dir_prot[0] = 3;
          dir_ovr[0] = 1; dir_ostat[0] = `SF_ST_OK; dir_oce[0] = 1; dir_ochkd[0] = 1; dir_pend[0] = 1;
          while (t < 200 && !seen_ev) begin
            @(posedge clk); t++;
            if (ev_ce_o[tb_bank_of(wi2)]) begin
              seen_ev = 1;
              chk(longint'(ev_addr_o[tb_bank_of(wi2)*AW +: AW]) == longint'(wi2) * WB, $sformatf("T08: ev_addr %0h, expected %0h", ev_addr_o[tb_bank_of(wi2)*AW +: AW], longint'(wi2) * WB));
            end
          end
          dir_ovr[0] = 0; dir_oce[0] = 0; dir_ochkd[0] = 0;
          chk(seen_ev, "T08: no ev_ce_o pulse for a corrected error");
          drain(2000);
          send(0, longint'(wi2) * WB, WSZ, 1, ones(1 << WSZ), 512'(pat));
        end
        // ---- scrubber: a single-bit error disappears without any master access
        if (SCRUB_EN != 0) begin
          int wi3, bk3, t3, c0;
          wi3 = 3; bk3 = tb_bank_of(wi3);
          send(0, longint'(wi3) * WB, WSZ, 1, ones(1 << WSZ), 512'(pat));
          c0 = int'(ce_cnt_o[bk3*CNT_W +: CNT_W]);
          inject(wi3, STORE_W'(1) << 11);
          c_scrub = 1;
          t3 = 0;
          while (int'(ce_cnt_o[bk3*CNT_W +: CNT_W]) == c0 && t3 < (BANK_DEPTH + 4) * (SCRUB_WAIT + READ_LATENCY + 8)) begin @(posedge clk); t3++; end
          chk(int'(ce_cnt_o[bk3*CNT_W +: CNT_W]) == c0 + 1, "T08: scrubber never found the injected single-bit error");
          repeat (4 * (SCRUB_WAIT + 8)) @(posedge clk);
          c_scrub = 0;
          repeat (10) @(posedge clk);
          c0 = int'(ce_cnt_o[bk3*CNT_W +: CNT_W]);
          send(0, longint'(wi3) * WB, WSZ, 0, '0, '0);            // would be flagged CE by the checker if the scrubber had not repaired it
          chk(last_ce[0] == 0 && int'(ce_cnt_o[bk3*CNT_W +: CNT_W]) == c0, "T08: scrubbed word still reports a corrected error");
        end
      end
      drain(5000);
    end

    // ============================================================ T09 flush and quiesce
    tests++;
    $display("[%0t] T09 flush / quiesce (several rounds, partially issued requests)", $time);
    for (int round = 0; round < 6; round++) begin
      int tmo;
      cfg_default();
      g_pwr = 70; g_prsp = 30 + 10 * round;
      case (round % 3)
        0: begin g_sizemode = 1; g_amode = 1; g_hotn = 6; end        // full-width requests on a few hot words: partial issue guaranteed
        1: begin g_sizemode = 0; g_amode = 0; end
        default: begin g_sizemode = 1; g_amode = 2; end
      endcase
      for (int m = 0; m < NM; m++) begin g_en[m] = 1; g_left[m] = 200; end
      repeat (23 + 13 * round) @(posedge clk);
      ready_check_en = 0;
      // flush: pending responses are discarded; words already accepted by a bank STAY written and are in the model (exact)
      for (int m = 0; m < NM; m++) begin
        // stop the generator and withdraw the presented request BEFORE flush: nothing may be accepted after the flush
        g_left[m] = 0; g_en[m] = 0; d_valid[m] = 0; dir_pend[m] = 0;
      end
      repeat (2) @(posedge clk);                 // the withdrawn request has left the DUT inputs
      c_flush_req = 1; repeat (2) @(posedge clk);
      tmo = 0;
      while (flush_busy_o && tmo < 3000) begin
        @(posedge clk); tmo++;
        for (int m = 0; m < NM; m++) chk(m_rsp_valid[m] === 1'b0, "T09: response presented during flush");
      end
      chk(!flush_busy_o, "T09: flush never completed");
      // resynchronise the checker with the (now empty) DUT queues
      for (int m = 0; m < NM; m++) begin
        for (int s_ = 0; s_ < NSLOT; s_++) r_live[m * NSLOT + s_] = 0;
        acc_n[m] = 0; pop_n[m] = 0; d_valid[m] = 0; dir_pend[m] = 0; pr_valid[m] = 0;
      end
      repeat (6) @(posedge clk);                 // any stale (flushed) word that is issued now is reported by the bank-accept checker
      chk(idle_o, "T09: not idle after flush");
      ready_check_en = 1;
      // the DUT must work normally again
      send(0, 40, WSZ, 1, ones(1 << WSZ), 512'hCAFE); send(0, 40, WSZ, 0, '0, '0);
      chk(last_status[0] != `SF_ST_OK || last_rdata[0][15:0] == 16'hCAFE, "T09: data path broken after flush");
    end
    // quiesce refuses new requests but lets in-flight ones finish
    c_quiesce = 1; repeat (3) @(posedge clk);
    chk(m_req_ready === '0, "T09: quiesce must refuse new requests");
    c_quiesce = 0; repeat (3) @(posedge clk);
    chk(m_req_ready === {NM{1'b1}}, "T09: ready after quiesce released");

    // ============================================================ T10 reset: control state cleared, memory contents are NOT reset
    tests++;
    $display("[%0t] T10 reset during traffic; memory contents persist (non-ECC)", $time);
    begin
      logic [WBITS-1:0] keep;
      keep = WBITS'(rnd512());
      send(0, 24, WSZ, 1, ones(1 << WSZ), 512'(keep));
      cfg_default(); g_pwr = 60; g_prsp = 40;
      for (int m = 0; m < NM; m++) begin g_en[m] = 1; g_left[m] = 150; end
      repeat (35) @(posedge clk);
      ready_check_en = 0;
      do_reset(3);
      ready_check_en = 1;
      if (ENABLE_ECC != 0) begin repeat (3) @(posedge clk); wait_idle(BANK_DEPTH * 4 + 200); end
      chk(m_rsp_valid === '0, "T10: stale response after reset");
      chk(perf_cycles_o < 32'd40 + BANK_DEPTH * 4, "T10: perf counters not cleared by reset");
      send(0, 24, WSZ, 0, '0, '0);
      if (ENABLE_ECC == 0) begin
        // the array must NOT be reset: the word still holds what the model says (random traffic may have rewritten it)
        logic [WBITS-1:0] expw;
        bit allk;
        expw = '0; allk = 1;
        for (int j = 0; j < (1 << WSZ); j++) begin allk = allk & ref_known[24 + j]; expw[j*8 +: 8] = ref_mem[24 + j]; end
        chk(!allk || last_status[0] != `SF_ST_OK || last_rdata[0][WBITS-1:0] == expw, "T10: memory contents were lost by reset (the array must not be reset)");
      end
      if (ENABLE_ECC != 0) chk(last_rdata[0][WBITS-1:0] == '0, "T10: ECC init engine did not zero the array after reset");
      cfg_default();
      run_phase("T10 traffic after reset", NRAND / 2, 400000);
    end

    // ============================================================ T11 full-capacity read-back against the model
    if (FULL_READBACK != 0) begin
      tests++;
      $display("[%0t] T11 full-capacity read-back", $time);
      cfg_default(); g_amode = 3; g_pwr = 0; g_sizemode = 1;
      for (int m = 0; m < NM; m++) begin g_en[m] = (m == 0); g_left[m] = (m == 0) ? int'(CAPB / DBYTES) : 0; g_sweep[m] = 0; end
      drain(CAPW * 10 + 20000);
      idle_all();
      // narrow sweep as well (every byte through byte reads)
      g_sizemode = 2; g_amode = 2; g_pwr = 0;
      begin
        int nk;
        nk = 0;
        for (longint a = 0; a < CAPB; a += WB * 5 + 1) begin
          send(0, a, 0, 0, '0, '0); nk++;
        end
      end
    end

    // ============================================================ conservation
    drain(20000);
    for (int m = 0; m < NM; m++) chk(acc_n[m] == pop_n[m], $sformatf("master %0d: %0d accepted, %0d answered", m, acc_n[m], pop_n[m]));
    $display("RESULT tb=memory_matrix NB=%0d WORD=%0d DATA=%0d L=%0d NM=%0d ECC=%0d NSLOT=%0d ARB=%0d ILV=%0d/%0d MIS=%0d RG=%0d BACKEND=%0d SEED=%0d tests=%0d checks=%0d errors=%0d cycles=%0d %s",
             NB, WORD_WIDTH, DATA_WIDTH, READ_LATENCY, NM, ENABLE_ECC, NSLOT, ARB, INTERLEAVE_MODE, ILV_GRAN_LOG2, MISALIGN_EN, NUM_REGIONS, BACKEND, SEED,
             tests, checks, errors, tb_cyc, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end

  // watchdog
  initial begin
    #(64'd2_000_000_000);
    $display("RESULT tb=memory_matrix WATCHDOG tests=%0d checks=%0d errors=%0d FAIL", tests, checks, errors + 1);
    $finish;
  end
endmodule
