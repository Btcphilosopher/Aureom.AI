#!/usr/bin/env python3
"""SilicaFlux MemoryMatrix regression runner (Verilator --binary --timing).

  python3 tests/memory_matrix/run_regress.py [--suite sys|dec|all] [--jobs N] [--only NAME ...] [--out reports/regress.json]
  python3 tests/memory_matrix/run_regress.py --list

Run from the package root.  Every case is built into build/<suite>_<name>/ and run; a case passes ONLY if the testbench printed
a RESULT line with errors=0 and PASS, the process exited 0 and no assertion / $fatal text appeared.
Environment: VERILATOR (executable), VEXTRA (extra verilator flags), VOPT (C++ -O flag, default -O0 here for build speed).
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.getcwd()
SYS_TB = "tests/memory_matrix/tb_memory_matrix.sv"
DEC_TB = "tests/memory_matrix/tb_mm_decoder.sv"
STANDIN = "rtl/memory/third_party/memorycore/sim_models/sky130_sram_standin.sv"
TPR = "rtl/memory/third_party/memorycore/rtl"
INTSRC = [f"{TPR}/sf_sync_fifo.sv", f"{TPR}/sf_vector_scratchpad.sv", f"{TPR}/sf_ts_port.sv", f"{TPR}/sf_tensor_scratchpad.sv"]
VSP = "tests/memory_matrix/tb_mm_vsp.sv"
TSP = "tests/memory_matrix/tb_mm_tsp.sv"


def case(name, top, tb, over=None, extra=()):
    return dict(name=name, top=top, tb=tb, over=over or {}, extra=list(extra))


SYS = [
    case("base_4b_64w_256d",  "tb_memory_matrix", SYS_TB, {}),
    case("nb8",               "tb_memory_matrix", SYS_TB, {"NUM_BANKS": 8, "BANK_DEPTH": 128}),
    case("nb16",              "tb_memory_matrix", SYS_TB, {"NUM_BANKS": 16, "BANK_DEPTH": 64}),
    case("nb2",               "tb_memory_matrix", SYS_TB, {"NUM_BANKS": 2, "BANK_DEPTH": 256}),
    case("L2",                "tb_memory_matrix", SYS_TB, {"READ_LATENCY": 2}),
    case("L3_nslot6",         "tb_memory_matrix", SYS_TB, {"READ_LATENCY": 3, "NSLOT": 6}),
    case("ecc_L1",            "tb_memory_matrix", SYS_TB, {"ENABLE_ECC": 1, "BANK_DEPTH": 128}),
    case("ecc_L2",            "tb_memory_matrix", SYS_TB, {"ENABLE_ECC": 1, "READ_LATENCY": 2, "BANK_DEPTH": 128}),
    case("ecc_scrub",         "tb_memory_matrix", SYS_TB, {"ENABLE_ECC": 1, "BANK_DEPTH": 32, "SCRUB_EN": 1, "SCRUB_WAIT": 6}),
    case("ecc_nb8",           "tb_memory_matrix", SYS_TB, {"ENABLE_ECC": 1, "NUM_BANKS": 8, "BANK_DEPTH": 64}),
    case("ecc_word32",        "tb_memory_matrix", SYS_TB, {"ENABLE_ECC": 1, "WORD_WIDTH": 32, "BANK_DEPTH": 128}),
    case("ecc_word128",       "tb_memory_matrix", SYS_TB, {"ENABLE_ECC": 1, "WORD_WIDTH": 128, "BANK_DEPTH": 64}),
    case("nm1",               "tb_memory_matrix", SYS_TB, {"NUM_MASTERS": 1}),
    case("nm2",               "tb_memory_matrix", SYS_TB, {"NUM_MASTERS": 2}),
    case("nm8_nb4",           "tb_memory_matrix", SYS_TB, {"NUM_MASTERS": 8}),
    case("data64",            "tb_memory_matrix", SYS_TB, {"DATA_WIDTH": 64}),
    case("data32",            "tb_memory_matrix", SYS_TB, {"DATA_WIDTH": 32}),
    case("data128",           "tb_memory_matrix", SYS_TB, {"DATA_WIDTH": 128}),
    case("data512_nb8",       "tb_memory_matrix", SYS_TB, {"DATA_WIDTH": 512, "NUM_BANKS": 8, "BANK_DEPTH": 64}),
    case("word32",           "tb_memory_matrix", SYS_TB, {"WORD_WIDTH": 32, "BANK_DEPTH": 256}),
    case("word128",          "tb_memory_matrix", SYS_TB, {"WORD_WIDTH": 128, "BANK_DEPTH": 128}),
    case("misalign0",         "tb_memory_matrix", SYS_TB, {"MISALIGN_EN": 0}),
    case("ilv_xor",           "tb_memory_matrix", SYS_TB, {"INTERLEAVE_MODE": 1}),
    case("ilv_xor_nb8",       "tb_memory_matrix", SYS_TB, {"INTERLEAVE_MODE": 1, "NUM_BANKS": 8, "BANK_DEPTH": 128}),
    case("ilv_gran2",         "tb_memory_matrix", SYS_TB, {"ILV_GRAN_LOG2": 2}),
    case("ilv_xor_gran1_nb16","tb_memory_matrix", SYS_TB, {"INTERLEAVE_MODE": 1, "ILV_GRAN_LOG2": 1, "NUM_BANKS": 16, "BANK_DEPTH": 64}),
    case("ilv_linear",        "tb_memory_matrix", SYS_TB, {"INTERLEAVE_MODE": 2}),
    case("ilv_linear_dep100", "tb_memory_matrix", SYS_TB, {"INTERLEAVE_MODE": 2, "BANK_DEPTH": 100}),
    case("regions3",          "tb_memory_matrix", SYS_TB, {"NUM_REGIONS": 3}),
    case("regions2_deny",     "tb_memory_matrix", SYS_TB, {"NUM_REGIONS": 2, "DEFAULT_ALLOW": 0}),
    case("arb_fixed",         "tb_memory_matrix", SYS_TB, {"ARB": 0}),
    case("win2",              "tb_memory_matrix", SYS_TB, {"ISSUE_WINDOW": 2}),
    case("win4",              "tb_memory_matrix", SYS_TB, {"ISSUE_WINDOW": 4}),
    case("win8_nb8",          "tb_memory_matrix", SYS_TB, {"ISSUE_WINDOW": 8, "NUM_BANKS": 8, "BANK_DEPTH": 128}),
    case("win4_ecc_L2",       "tb_memory_matrix", SYS_TB, {"ISSUE_WINDOW": 4, "ENABLE_ECC": 1, "READ_LATENCY": 2, "BANK_DEPTH": 128}),
    case("win4_nb16_xor",     "tb_memory_matrix", SYS_TB, {"ISSUE_WINDOW": 4, "NUM_BANKS": 16, "BANK_DEPTH": 64, "INTERLEAVE_MODE": 1}),
    case("win3_nslot3_misal0","tb_memory_matrix", SYS_TB, {"ISSUE_WINDOW": 3, "NSLOT": 3, "MISALIGN_EN": 0}),
    case("nslot2",            "tb_memory_matrix", SYS_TB, {"NSLOT": 2}),
    case("nslot3",            "tb_memory_matrix", SYS_TB, {"NSLOT": 3}),
    case("depth100_nonpow2",  "tb_memory_matrix", SYS_TB, {"BANK_DEPTH": 100}),
    case("seed2",             "tb_memory_matrix", SYS_TB, {"SEED": 0x5EED0002, "NRAND": 1200}),
    case("seed3_nb8_ecc",     "tb_memory_matrix", SYS_TB, {"SEED": 0x5EED0003, "ENABLE_ECC": 1, "NUM_BANKS": 8, "BANK_DEPTH": 64, "READ_LATENCY": 2}),
    case("fpga_bram",         "tb_memory_matrix", SYS_TB, {"BACKEND": 1}),
    case("fpga_bram_ecc_L2",  "tb_memory_matrix", SYS_TB, {"BACKEND": 1, "ENABLE_ECC": 1, "READ_LATENCY": 2, "BANK_DEPTH": 128, "FAULT_INJECT": 0}),
    case("asic_standin_L2",   "tb_memory_matrix", SYS_TB, {"BACKEND": 2, "READ_LATENCY": 2, "BANK_DEPTH": 256}, extra=[STANDIN]),
]
DEC = [
    case("dec_nb4_low",       "tb_mm_decoder", DEC_TB, {}),
    case("dec_nb8_xor",       "tb_mm_decoder", DEC_TB, {"NB": 8, "DEPTH": 32, "MODE": 1}),
    case("dec_nb16_low_g2",   "tb_mm_decoder", DEC_TB, {"NB": 16, "DEPTH": 16, "MODE": 0, "GRAN": 2}),
    case("dec_nb4_linear",    "tb_mm_decoder", DEC_TB, {"MODE": 2, "DEPTH": 100}),
    case("dec_nb4_xor_g2",    "tb_mm_decoder", DEC_TB, {"MODE": 1, "GRAN": 2, "DEPTH": 60, "MISALIGN_EN": 0}),
    case("dec_nb16_xor",      "tb_mm_decoder", DEC_TB, {"NB": 16, "DEPTH": 64, "MODE": 1, "NRG": 0, "MISALIGN_EN": 0, "K": 4}),
    case("dec_nb2_low",       "tb_mm_decoder", DEC_TB, {"NB": 2, "DEPTH": 128}),
    case("dec_word32",        "tb_mm_decoder", DEC_TB, {"LB": 2, "SZ_MAX": 4, "K": 4}),
    case("dec_word128",       "tb_mm_decoder", DEC_TB, {"LB": 4, "SZ_MAX": 6, "K": 5, "DEPTH": 32}),
]

# Existing SilicaFlux adapters (sf_vector_scratchpad, sf_tensor_scratchpad) and THEIR ORIGINAL testbenches, running on sf_memory_matrix
INTEG = [
    case("int_vsp_w128",        "tb_mm_vsp", VSP, {}, extra=INTSRC),
    case("int_vsp_w64",         "tb_mm_vsp", VSP, {"MM_WORD_P": 64}, extra=INTSRC),
    case("int_vsp_vl2_w128",    "tb_mm_vsp", VSP, {"VEC_LINES": 2}, extra=INTSRC),
    case("int_vsp_vl4_w64",     "tb_mm_vsp", VSP, {"VEC_LINES": 4, "MM_WORD_P": 64}, extra=INTSRC),
    case("int_vsp_ecc_w128_L2", "tb_mm_vsp", VSP, {"ECC_EN": 1, "READ_LATENCY": 2}, extra=INTSRC),
    case("int_vsp_ecc_w64",     "tb_mm_vsp", VSP, {"ECC_EN": 1, "MM_WORD_P": 64}, extra=INTSRC),
    case("int_tsp_w128",        "tb_mm_tsp", TSP, {}, extra=INTSRC),
    case("int_tsp_w64",         "tb_mm_tsp", TSP, {"MM_WORD_P": 64}, extra=INTSRC),
    case("int_tsp_ecc_w128",    "tb_mm_tsp", TSP, {"ECC_EN": 1}, extra=INTSRC),
    case("int_tsp_nb8_w64",     "tb_mm_tsp", TSP, {"NB": 8, "MM_WORD_P": 64}, extra=INTSRC),
]
INT_RE = re.compile(r"RESULT\s+tb=mm_(?:vsp|tsp).*?checks=(\d+)\s+errors=(\d+)\b[^\n]*?\b(PASS|FAIL)\s*$", re.M)

RESULT_RE = re.compile(r"RESULT\s+tb=(\S+)(.*?)\btests=(\d+)\s+checks=(\d+)\s+errors=(\d+)(?:\s+cycles=(\d+))?\s+(PASS|FAIL)")
DEC_RE = re.compile(r"RESULT\s+tb=mm_decoder.*?checks=(\d+)\s+errors=(\d+)\s+(PASS|FAIL)")


def run_case(c, outroot):
    d = os.path.join(outroot, c["name"])
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d, exist_ok=True)
    env = dict(os.environ)
    env.setdefault("VOPT", "-O0")
    gflags = [f"-G{k}={v}" for k, v in c["over"].items()]
    cmd = ["bash", "scripts/vbuild.sh", d, c["top"], c["tb"]] + c["extra"] + gflags
    t0 = time.time()
    b = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True)
    res = dict(name=c["name"], overrides=c["over"], build_s=round(time.time() - t0, 1))
    exe = os.path.join(d, "sim.bin")
    if b.returncode != 0 or not os.path.exists(exe):
        res.update(status="BUILD_FAIL", detail=(b.stdout + b.stderr)[-1500:])
        return res
    t1 = time.time()
    try:
        r = subprocess.run([exe], cwd=ROOT, env=env, capture_output=True, text=True, timeout=1500)
    except subprocess.TimeoutExpired:
        res.update(status="TIMEOUT")
        return res
    out = r.stdout + r.stderr
    res["run_s"] = round(time.time() - t1, 1)
    keep = os.environ.get("MM_KEEP_BUILD")
    bad = re.findall(r"(%Error.*|%Fatal.*|Assertion.*|\$fatal.*|\$error.*)", out)
    m = RESULT_RE.search(out)
    if c["top"] in ("tb_mm_vsp", "tb_mm_tsp"):
        mi = INT_RE.search(out)
        if mi:
            res.update(checks=int(mi.group(1)), errors=int(mi.group(2)), tests=1)
            res["status"] = "PASS" if (mi.group(3) == "PASS" and r.returncode == 0 and not bad and res["errors"] == 0) else "FAIL"
        else:
            res["status"] = "NO_RESULT"
    elif c["top"] == "tb_mm_decoder":
        m2 = DEC_RE.search(out)
        if m2:
            res.update(checks=int(m2.group(1)), errors=int(m2.group(2)), tests=1)
            res["status"] = "PASS" if (m2.group(3) == "PASS" and r.returncode == 0 and not bad and res["errors"] == 0) else "FAIL"
        else:
            res["status"] = "NO_RESULT"
    elif m:
        res.update(tests=int(m.group(3)), checks=int(m.group(4)), errors=int(m.group(5)), cycles=int(m.group(6) or 0))
        res["status"] = "PASS" if (m.group(7) == "PASS" and r.returncode == 0 and not bad and res["errors"] == 0) else "FAIL"
    else:
        res["status"] = "NO_RESULT"
    if res["status"] != "PASS":
        res["detail"] = "\n".join([l for l in out.splitlines() if "ERROR" in l or "RESULT" in l or "%" in l][:12])
    if not keep:
        shutil.rmtree(d, ignore_errors=True)       # ~100 MB of objects per case; results are already parsed
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", default="all", choices=["sys", "dec", "int", "all"])
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out", default="reports/regress.json")
    ap.add_argument("--build", default=os.environ.get("MM_BUILD", "build/regress"))
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    cases = (SYS if a.suite in ("sys", "all") else []) + (DEC if a.suite in ("dec", "all") else []) + (INTEG if a.suite in ("int", "all") else [])
    if a.only:
        cases = [c for c in cases if c["name"] in a.only]
    if a.list:
        for c in cases:
            print(c["name"], c["over"])
        return 0
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        results = list(ex.map(lambda c: run_case(c, a.build), cases))
    npass = sum(1 for r in results if r["status"] == "PASS")
    tot = sum(r.get("checks", 0) for r in results)
    for r in results:
        print(f'{r["status"]:10s} {r["name"]:22s} checks={r.get("checks", "-")} errors={r.get("errors", "-")} {r.get("detail", "")[:300] if r["status"] != "PASS" else ""}')
    print(f"\n{npass}/{len(results)} cases pass, {tot:,} self-checks, {time.time() - t0:.0f} s")
    json.dump(dict(cases=results, passed=npass, total=len(results), checks=tot), open(a.out, "w"), indent=1)
    return 0 if npass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
