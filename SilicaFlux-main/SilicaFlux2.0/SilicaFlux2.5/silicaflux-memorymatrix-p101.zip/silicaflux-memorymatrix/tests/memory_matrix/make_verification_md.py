#!/usr/bin/env python3
"""Generate docs/memory_matrix/VERIFICATION.md from reports/regress.json, reports/mutation.json, reports/formal.json.  Run from the package root."""
import json, os, sys

R = json.load(open("reports/regress.json"))
M = json.load(open("reports/mutation.json")) if os.path.exists("reports/mutation.json") else None
F = json.load(open("reports/formal.json")) if os.path.exists("reports/formal.json") else None

cases = R["cases"]
sysc = [c for c in cases if c["name"] in {x["name"] for x in cases} and not c["name"].startswith(("dec_", "int_"))]
decc = [c for c in cases if c["name"].startswith("dec_")]
intc = [c for c in cases if c["name"].startswith("int_")]


def ov(c):
    return ", ".join(f"{k}={v}" for k, v in c["overrides"].items()) or "defaults"


def tab(cs, cols):
    out = ["| case | overrides | tests | checks | errors | status |", "|---|---|---|---|---|---|"]
    for c in cs:
        out.append(f"| {c['name']} | {ov(c)} | {c.get('tests', '-')} | {c.get('checks', 0):,} | {c.get('errors', '-')} | {c['status']} |")
    return "\n".join(out)


md = []
md.append("# VERIFICATION\n")
md.append("Labels: **RTL-SIMULATION** = Verilator 5.49 two-state simulation; **FORMAL** = SymbiYosys + z3 (BMC is bounded, `prove` is unbounded k-induction). Every table below is generated "
          "from `reports/*.json` by `tests/memory_matrix/make_verification_md.py`; re-run the commands in the README to reproduce. Nothing is a silicon result.\n")
md.append("## 1. Method\n")
md.append("""* **Independent byte-addressable reference model** (`tests/memory_matrix/tb_memory_matrix.sv`): a byte image of the whole aperture plus a *known* flag per byte, so nothing is assumed
  about power-up contents (non-ECC arrays are unknown until written; ECC arrays are known-zero only after the init engine has run). A power-up poison image (`SIM_INIT = 2`) is used and T01
  checks the array is not silently zero.
* The expected **bank, row, word and bytes** of every access are derived from the *byte address alone* with the testbench's own integer arithmetic (divide / modulo), not from the DUT's
  decoder. The model is applied at the edge a bank **accepts** a word (trace port), the serialisation point of the bank; each accepted word is checked against its expected bank / row,
  for double access and for spurious access (a word with no active byte).
* At each response: order, id, `we`, status (predicted from the specification: BADOP / RANGE / ALIGN / PERM), rdata lanes (known bytes only; lanes above the size and every error / write
  response must be 0), corrected-error flag, completeness (every expected word was accessed), and stability of a stalled response.
* **Per-master program order** of conflicting accesses (M1) is checked from the request stream alone (the byte model follows the DUT's accept order and cannot see a reordering).
* **Bounded queue**: `m_req_ready == (outstanding < NSLOT)` is checked on **every cycle** (registered-state-only back-pressure).
* **Performance counters** are mirrored (accesses per bank, useful bytes, latency sum, requests, rejects, cycles) and compared for **exact equality** at the end of each window.
* Every DUT input is driven by one clocked process (found necessary: a second driver raced with the model at the clock edge).
* The existing adapters' **original testbenches** run on the matrix (section 5).

## 2. Test list (tb_memory_matrix)

| id | content |
|---|---|
| T01 | reset and power-up: no stale response, free queue, counters, poison image not zero (non-ECC) / init image zero (ECC) |
| T02 | all sizes x byte offsets, bank-spanning, exact lone-request latency (`READ_LATENCY + ECC + 1`) |
| T03 | address boundaries: first / last byte and word, access straddling the end, address == capacity, top of the address space, illegal size, alignment, rejected writes have no effect, `be = 0` write |
| T04 | simultaneous independent banks: one master per bank, no conflicts, no arbitration stalls, one request per cycle per master (when `NSLOT` covers the latency), counters exact |
| T05 / T05b | same-bank collisions: single-port invariant (cycles >= accesses), round-robin fairness / fixed-priority behaviour, exact two-master conflict accounting |
| T06 | permission regions (privilege, secure, master mask, read-only, straddling access) |
| T07a-f | random traffic: full speed, request gaps + 50 % response ready, hot words across masters, narrow partial writes, full-width with 10 % response ready (queue full), bank-targeted |
| T08 | ECC: single-bit errors across the whole codeword, double-bit error, partial write onto an uncorrectable word (aborted), full write repair, RMW on a healthy word, event address, scrubber |
| T09 | six rounds of flush under heavy partially-issued traffic, quiesce |
| T10 | reset during traffic; memory contents persist (non-ECC) / init re-zeroes (ECC) |
| T11 | full-capacity read-back against the model |

## 3. Regression (RTL-SIMULATION)
""")
md.append(f"**{R['passed']} of {R['total']} cases pass, {R['checks']:,} self-checks.**\n")
md.append("### 3.1 System testbench: configurations\n")
md.append(tab(sysc, None) + "\n")
md.append("### 3.2 Address-map testbench (exhaustive)\n")
md.append(tab(decc, None) + "\n")
md.append("## 4. Existing adapters on the matrix: their ORIGINAL testbenches\n")
md.append("`sf_vector_scratchpad` and `sf_tensor_scratchpad` with the byte-identical original testbenches (controller block replaced by `sf_memory_matrix`, see `make_integration_tb.py`). "
          "`MM_WORD_P = 128` gives the matrix the controller's line width; `64` runs the same line as two rows of one bank.\n")
md.append(tab(intc, None) + "\n")

if M:
    k = M["killed"]
    md.append("## 5. Mutation testing of the testbench\n")
    md.append(f"One deliberate fault per mutant is injected into a private copy of the matrix RTL; the testbench must fail. **{k} of {M['total']} mutants killed.**\n")
    md.append("| mutant | status | caught by | models |\n|---|---|---|---|")
    for m in M["mutants"]:
        how = (m.get("how") or "").replace("|", "/")[:100]
        md.append(f"| {m['name']} | {m['status']} | {how} | {m.get('doc', '')} |")
    md.append("""
**What mutation testing found in the testbench itself** (all fixed, listed because they show what the tests did *not* check at first):

1. `perf_conf_ge3` survived: conflict counters were only bounded, never compared exactly. Added T05b (exact two-master accounting).
2. Two window mutants (`hazard check removed`) survived even after a program-order checker was added. Analysis showed they were **equivalent mutants**: two accesses to the same word are
   accesses to the same bank and the per-(master, bank) selection already takes the oldest first, so the extra hazard logic was dead. It was **deleted from the RTL**, and replaced
   by the mutant that really breaks the mechanism (`win_youngest_first`), which the new program-order checker kills with a precise diagnostic.
3. `win_valid_off` (a stale slot left after a flush) survived a single flush test; the flush test now runs six rounds under heavy partially-issued traffic.
4. Order of conflicting accesses within one master (M1) was **not checked at all** (the model follows the DUT's accept order); this applies to the in-order design as well.

Detection strength: most mutants are caught by a specific, named check (the message is in the table). **Four are caught only by a hang** (`mm_tag_slot`, `mm_selw_dup`,
`mm_cand_done`, `win_grant_route`: the DUT deadlocks and the 240 s run limit expires; the testbench's own drain time-outs also fire). That is a weaker form of detection than a
mismatch report and means the testbench would not localise those faults.

Not mutated: the reused third-party modules (they have their own regressions), and mutants of the testbench's expected values. A full kill count says nothing about faults nobody thought to inject.
""")
if F:
    md.append("## 6. Formal (SymbiYosys + z3)\n")
    n = sum(1 for f in F if f["status"] == "PASS")
    md.append(f"**{n} of {len(F)} jobs PASS.** `bmc` is bounded to the stated depth; `prove` is an unbounded k-induction proof; the address-map jobs are stateless, so one step covers every input.\n")
    md.append("| job | mode | depth | status | seconds | note |\n|---|---|---|---|---|---|")
    for f in F:
        md.append(f"| {f['name']} | {f['mode']} | {f['depth']} | {f['status']} | {f['secs']} | {f.get('note', '')} |")
    md.append("""
**The formal properties can fail** (`reports/formal_mutants.json`): run against a map with the block-row shift one bit too small (aliasing) and against a round-robin pointer that always returns to 0,
`map_nb4_d16_m0_g0`, `arb_rr_nm3` (BMC) and `arb_rr_nm3_prove` (induction base case) all report FAIL. The data-integrity assertion is **not vacuous**: the job `top_data_cover` reaches its antecedent
(a read of the tracked byte answered after a write to it) at step 4, the minimum possible (reset, write, read, bank response, answer).

Properties: address map **bijective, in range, onto** (no aliasing); arbiter **exclusive, no grant while the bank is not ready, work conserving, round-robin bound** (unbounded, with an
inductive auxiliary invariant `others[k] + dist(ptr,k) <= NM-1`); tiny-configuration matrix: **exact bounded queue (`ready == outstanding < NSLOT`), conservation (no response without
a request), stalled-response stability, grant exclusivity** (2 masters) and **read-after-write data integrity of a symbolic byte** through the splitter / shifters / banks (1 master).
Both matrix-top jobs hit their 25-minute limit with z3 (`TIMEOUT` in the table): the structural job completed steps 0..8 and the data job steps 0..6 with **no counterexample**; nothing is claimed beyond those depths.
The array contents are unconstrained at start (nothing is assumed zero). Formal results are **bounded** for the matrix top (depth in the table) and say nothing beyond that depth or beyond
the tiny configuration (2 banks x 4 words, 16-bit words, 32-bit bus).
""")
md.append("""## 7. Defects found and fixed during verification

The first full regression (`reports/history/regress_first_full_run_42_of_48.json`) had **6 of 48 cases failing**. Honest classification:

| finding | where | what happened |
|---|---|---|
| **RTL defect** | `sf_memory_matrix_perf` / `sf_memory_matrix` | the per-bank requester count was a `ceil(log2(NM+1))`-bit field; for `NUM_MASTERS = 1` that is 1 bit, so the constant `2` of the conflict test truncated to 0 and **every cycle with a request was counted as a conflict**. Found by the `nm1` case (T04: 1507 conflicts with disjoint banks); fixed (field >= 2 bits). |
| RTL dead logic | issue window | a same-word hazard check was added and then **removed**: mutation testing showed it could never matter (same word = same bank, oldest word is always offered first). |
| testbench race | `tb_memory_matrix` | a second process drove DUT inputs at the clock edge and raced with the model (a perf-window clear was seen by the DUT but not by the mirror); all DUT inputs are now driven by one clocked process. |
| testbench race | `tb_memory_matrix` | checking was disabled in the same time step as a reset edge, so a write accepted at that edge was missing from the model (the DUT held the *newer* value). Requests are now withdrawn first and the checker runs through the reset edge. |
| testbench assumption | T04 / T05 / T03 / T08 / T10 | assumed a full-width word access on a 32-bit bus (size 8 B is `BADOP` there), that every request reaches a bank (permission denials do not), that an FPGA-backend configuration can inject faults, that a word written before a reset is untouched by later random traffic, and that fixed priority behaves like round robin. |
| testbench hole | whole TB | per-master program order (M1) was **not checked**; the exact conflict counters were only bounded; the stale-slot-after-flush case was untested. Found by the mutation campaign (section 5) and closed. |

No defect other than the first was found in the decoder, the arbiter, the splitter / shifters, the slot tables or the response path by the tests; that is a statement about what the tests exercised (see below),
not a proof of absence.

## 8. What the verification does NOT show

* Behaviour beyond the tested parameter sets (the matrix of configurations above is a sample, not all combinations).
* X-propagation / four-state behaviour (Verilator is two-state); gate-level and post-layout behaviour.
* The third-party banks' internals beyond what the matrix exercises (their own regressions are quoted, not re-run, except the controller testbench at `DW = 64`).
* Any property of the real silicon macros: the ASIC backend runs against a labelled stand-in model.
* Liveness / absence of deadlock beyond the bounded checks and the testbench's drain timeouts.
""")
open("docs/memory_matrix/VERIFICATION.md", "w").write("\n".join(md))
print("wrote docs/memory_matrix/VERIFICATION.md")
