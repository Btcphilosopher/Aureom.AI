// =============================================================================
// fv_mm_top -- bounded formal harness for sf_memory_matrix on a TINY configuration
//   2 banks x 4 words x 16 bit, 32-bit master bus, 2 masters (structural properties) or 1 master (data integrity), 2 slots.
//   `define FV_DATA selects the single-master data-integrity harness; otherwise the multi-master structural harness.
//   The array contents are UNCONSTRAINED at start (the formal model has no power-up value: nothing may be assumed zero).
//
//   Structural (NM = 2):
//     S1  m_req_ready[i] == (outstanding[i] < NSLOT)               exact, registered-state-only bounded queue
//     S2  a response is valid only when a request is outstanding (conservation: never more answers than accepts)
//     S3  a stalled response (valid, !ready) stays valid with identical payload next cycle
//     S4  at most one grant per bank per cycle and no grant while the bank is not ready  (embedded checks, -DSF_ASSERT)
//     S5  outstanding[i] <= NSLOT
//   Data integrity (NM = 1, FV_DATA): ONE symbolic byte address A is tracked.  A write that covers A updates the ghost byte
//     at ACCEPT time; a read that covers A snapshots the ghost at accept time; the response lane that holds A must equal
//     the snapshot.  (For one master the accept order IS the bank order: M1.)  This covers the byte-lane shifter, the split into
//     words / banks, misalignment, partial byte enables and the response re-alignment for every legal request.
// =============================================================================
`include "sf_mm_defs.svh"
module fv_mm_top (
  input  wire              clk,
  input  wire              rst_in,
  input  wire [1:0]        m_req_valid_f,
  input  wire [1:0]        m_req_we_f,
  input  wire [15:0]       m_req_addr_f,
  input  wire [3:0]        m_req_size_f,
  input  wire [63:0]       m_req_wdata_f,
  input  wire [7:0]        m_req_be_f,
  input  wire [1:0]        m_rsp_ready_f
);
`ifdef FV_DATA
  localparam int NM = 1;
`else
  localparam int NM = 2;
`endif
  localparam int NB = 2, DEPTH = 4, WW = 16, DW = 32, NSLOT = 2, AW = 8, IDW = 2;
  localparam int WB = WW / 8, DBYTES = DW / 8, SZ_MAX = 2, SZW = 2;
  localparam longint CAPB = NB * DEPTH * WB;
  localparam int ROW_W = $clog2(DEPTH), BW = $clog2(NB), SW = $clog2(NSLOT);
  localparam int K = (DBYTES + 2 * WB - 2) / WB, KW = (K > 1) ? $clog2(K) : 1, MW = (NM > 1) ? $clog2(NM) : 1;

  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  // ---- inputs shaped per instantiation
  wire [NM-1:0]          m_req_valid = m_req_valid_f[NM-1:0];
  wire [NM-1:0]          m_req_we    = m_req_we_f[NM-1:0];
  wire [NM*AW-1:0]       m_req_addr  = m_req_addr_f[NM*AW-1:0];          // every master gets its own slice of the free inputs
  wire [NM*SZW-1:0]      m_req_size  = m_req_size_f[NM*SZW-1:0];
  wire [NM*DW-1:0]       m_req_wdata = m_req_wdata_f[NM*DW-1:0];
  wire [NM*DBYTES-1:0]   m_req_be    = m_req_be_f[NM*DBYTES-1:0];
  wire [NM-1:0]          m_rsp_ready = m_rsp_ready_f[NM-1:0];
  wire [NM-1:0]          m_req_ready, m_rsp_valid, m_rsp_we, m_rsp_ce;
  wire [NM*DW-1:0]       m_rsp_rdata;
  wire [NM*IDW-1:0]      m_rsp_id;
  wire [NM*3-1:0]        m_rsp_status;
  wire [31:0]            pc, pr;
  wire [NB-1:0]          trc_acc, trc_we;
  wire [NB*MW-1:0]       trc_m;  wire [NB*SW-1:0] trc_s;  wire [NB*KW-1:0] trc_k;  wire [NB*ROW_W-1:0] trc_r;
  wire                   flush_busy, idle, init_busy;
  wire [NB-1:0]          ev_ce, ev_ue;
  wire [NB*AW-1:0]       ev_addr;
  wire [NB*16-1:0]       cc, uc;
  wire [NB*32-1:0]       p_ar, p_aw, p_cf, p_ls, p_bz;
  wire [NM*32-1:0]       p_ms, p_as, p_bs, p_sc, p_st, p_rq, p_br, p_bw, p_lc;
  wire [4*32-1:0]        p_cls;
  wire [NM*40-1:0]       p_ls40;
  wire [NM*20-1:0]       p_lm;
  wire [NB*WW-1:0]       tstr;

  sf_memory_matrix #(.NUM_BANKS(NB), .BANK_DEPTH(DEPTH), .WORD_WIDTH(WW), .DATA_WIDTH(DW), .READ_LATENCY(1), .NUM_MASTERS(NM),
                     .ENABLE_ECC(0), .AW(AW), .IDW(IDW), .NSLOT(NSLOT), .MISALIGN_EN(1), .NUM_REGIONS(0), .SIM_INIT(0)) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_size(m_req_size),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id({NM*IDW{1'b0}}), .m_req_prot({NM*2{1'b1}}),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we),
    .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .rg_base_i({AW{1'b0}}), .rg_last_i({AW{1'b0}}), .rg_perm_i(5'd0), .rg_mmask_i({NM{1'b0}}),
    .flush_i(1'b0), .flush_busy_o(flush_busy), .quiesce_i(1'b0), .idle_o(idle), .init_start_i(1'b0), .init_busy_o(init_busy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue), .ev_addr_o(ev_addr), .ce_cnt_o(cc), .ue_cnt_o(uc),
    .perf_clr_i(1'b0), .perf_cycles_o(pc), .perf_acc_rd_o(p_ar), .perf_acc_wr_o(p_aw), .perf_conf_o(p_cf), .perf_lost_o(p_ls), .perf_busy_o(p_bz),
    .perf_mstall_o(p_ms), .perf_arbstall_o(p_as), .perf_busystall_o(p_bs), .perf_selfconf_o(p_sc), .perf_starve_o(p_st), .perf_starve_cls_o(p_cls),
    .perf_reqs_o(p_rq), .perf_bytes_rd_o(p_br), .perf_bytes_wr_o(p_bw), .perf_lat_sum_o(p_ls40), .perf_lat_cnt_o(p_lc), .perf_lat_max_o(p_lm), .perf_rej_o(pr),
    .trc_acc_o(trc_acc), .trc_we_o(trc_we), .trc_m_o(trc_m), .trc_slot_o(trc_s), .trc_k_o(trc_k), .trc_row_o(trc_r),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W{1'b0}}), .tst_wdata_i({WW{1'b0}}), .tst_rdata_o(tstr),
    .fi_bank({BW{1'b0}}), .fi_type(4'd0), .fi_row({ROW_W{1'b0}}), .fi_row2({ROW_W{1'b0}}), .fi_bit(4'd0), .fi_bit2(4'd0),
    .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({ROW_W{1'b0}}), .seu_mask({WW{1'b0}}));

  // ---- bus protocol assumptions on the environment: payload stable until accepted; legal in-range requests only
  reg [NM-1:0] pv, pa;
  reg [AW-1:0] paddr; reg [SZW-1:0] psz; reg [DW-1:0] pwd; reg [DBYTES-1:0] pbe; reg pwe;
  reg past_valid = 1'b0;
  always @(posedge clk) begin
    past_valid <= 1'b1;
    pv <= m_req_valid; pa <= m_req_ready; paddr <= m_req_addr[AW-1:0]; psz <= m_req_size[SZW-1:0]; pwd <= m_req_wdata[DW-1:0]; pbe <= m_req_be[DBYTES-1:0]; pwe <= m_req_we[0];
  end
  always @* begin
    if (init) assume (m_req_valid == '0);
    if (past_valid && pv[0] && !pa[0]) assume (m_req_valid[0] && m_req_addr[AW-1:0] == paddr && m_req_size[SZW-1:0] == psz && m_req_wdata[DW-1:0] == pwd && m_req_be[DBYTES-1:0] == pbe && m_req_we[0] == pwe);
    if (m_req_valid[0]) begin
      assume (m_req_size[SZW-1:0] <= SZ_MAX);
      assume (({1'b0, m_req_addr[AW-1:0]} + (9'd1 << m_req_size[SZW-1:0])) <= CAPB);   // legal, in range (errors are covered by tb_memory_matrix)
    end
  end
  // master 1 (structural harness): same payload rules on its own copy of the bus
  generate if (NM > 1) begin : g_m1
    reg pv1, pa1; reg [AW-1:0] pa_addr1;
    always @(posedge clk) begin pv1 <= m_req_valid[1]; pa1 <= m_req_ready[1]; pa_addr1 <= m_req_addr[AW +: AW]; end
    always @* begin
      if (past_valid && pv1 && !pa1) assume (m_req_valid[1] && m_req_addr[AW +: AW] == pa_addr1);
      if (m_req_valid[1]) begin
        assume (m_req_size[SZW +: SZW] <= SZ_MAX);
        assume (({1'b0, m_req_addr[AW +: AW]} + (9'd1 << m_req_size[SZW +: SZW])) <= CAPB);
      end
    end
  end endgenerate

  // ---- shadow queue counters
  reg [3:0] acc [0:NM-1];
  reg [3:0] pop [0:NM-1];
  integer i1, i2, i3;
  initial for (i1 = 0; i1 < NM; i1 = i1 + 1) begin acc[i1] = 0; pop[i1] = 0; end
  always @(posedge clk) begin
    for (i2 = 0; i2 < NM; i2 = i2 + 1) begin
      if (!rst_n) begin acc[i2] <= 0; pop[i2] <= 0; end
      else begin
        if (m_req_valid[i2] && m_req_ready[i2]) acc[i2] <= acc[i2] + 4'd1;
        if (m_rsp_valid[i2] && m_rsp_ready[i2]) pop[i2] <= pop[i2] + 4'd1;
      end
    end
  end
  // ---- stalled-response stability
  reg [NM-1:0] rv, rr; reg [NM*DW-1:0] rd; reg [NM*3-1:0] rs; reg [NM-1:0] rw;
  always @(posedge clk) begin rv <= m_rsp_valid; rr <= m_rsp_ready; rd <= m_rsp_rdata; rs <= m_rsp_status; rw <= m_rsp_we; end

  always @* begin
    if (rst_n && !init) begin
      for (i3 = 0; i3 < NM; i3 = i3 + 1) begin
        assert (m_req_ready[i3] == ((acc[i3] - pop[i3]) < NSLOT));              // S1
        assert ((acc[i3] - pop[i3]) <= NSLOT);                                  // S5
        if (m_rsp_valid[i3]) assert (acc[i3] != pop[i3]);                       // S2
        if (past_valid && rv[i3] && !rr[i3]) begin                              // S3
          assert (m_rsp_valid[i3]);
          assert (m_rsp_rdata[i3*DW +: DW] == rd[i3*DW +: DW] && m_rsp_status[i3*3 +: 3] == rs[i3*3 +: 3] && m_rsp_we[i3] == rw[i3]);
        end
      end
    end
  end

`ifdef FV_DATA
  // ---- single-byte ghost memory (NM = 1)
  (* anyconst *) reg [AW-1:0] A;
  reg        g_valid = 1'b0;
  reg [7:0]  g_data;
  reg        s_valid [0:NSLOT-1];
  reg [7:0]  s_data  [0:NSLOT-1];
  reg        s_lane_v[0:NSLOT-1];
  reg [2:0]  s_lane  [0:NSLOT-1];
  reg [3:0]  accn, popn;
  integer i4;
  initial begin accn = 0; popn = 0; for (i4 = 0; i4 < NSLOT; i4 = i4 + 1) begin s_valid[i4] = 0; s_lane_v[i4] = 0; s_data[i4] = 0; s_lane[i4] = 0; end end
  wire [AW:0]  a_end = {1'b0, m_req_addr[AW-1:0]} + (9'd1 << m_req_size[SZW-1:0]);
  wire         covers = ({1'b0, A} >= {1'b0, m_req_addr[AW-1:0]}) && ({1'b0, A} < a_end);
  wire [AW-1:0] lane = A - m_req_addr[AW-1:0];
  wire         acc_now = m_req_valid[0] && m_req_ready[0];
  always @(posedge clk) begin
    if (!rst_n) begin accn <= 0; popn <= 0; g_valid <= 0; end
    else begin
      if (acc_now) begin
        accn <= accn + 4'd1;
        s_lane_v[accn % NSLOT] <= covers && !m_req_we[0];
        s_lane[accn % NSLOT]   <= lane[2:0];
        s_valid[accn % NSLOT]  <= g_valid;
        s_data[accn % NSLOT]   <= g_data;
        if (covers && m_req_we[0] && m_req_be[0*DBYTES + lane[2:0]]) begin
          g_valid <= 1'b1; g_data <= m_req_wdata[lane[2:0]*8 +: 8];
        end
      end
      if (m_rsp_valid[0] && m_rsp_ready[0]) popn <= popn + 4'd1;
    end
  end
  always @* begin
    if (rst_n && !init && m_rsp_valid[0] && !m_rsp_we[0] && s_lane_v[popn % NSLOT] && s_valid[popn % NSLOT]) begin
      assert (m_rsp_status[2:0] == 3'd0);
      assert (m_rsp_rdata[s_lane[popn % NSLOT]*8 +: 8] == s_data[popn % NSLOT]);      // D1: read-after-write integrity of the tracked byte
    end
  end
  // NON-VACUITY: the antecedent of D1 is reachable (a read that covers the tracked byte, issued after a write to it, is answered).  Run in cover mode.
  always @* begin
    cover (rst_n && !init && m_rsp_valid[0] && !m_rsp_we[0] && s_lane_v[popn % NSLOT] && s_valid[popn % NSLOT]);
  end
`endif
endmodule
