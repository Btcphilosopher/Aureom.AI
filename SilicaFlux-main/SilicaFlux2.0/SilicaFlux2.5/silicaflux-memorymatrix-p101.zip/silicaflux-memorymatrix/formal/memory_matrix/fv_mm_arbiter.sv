// =============================================================================
// fv_mm_arbiter -- formal properties of sf_memory_matrix_arbiter (the per-bank arbiter), free requests and free bank-ready.
//   A1 grant is a subset of the requests, at most one bit (exclusive)
//   A2 no grant while the bank is not ready (a single-port bank accepts one operation per cycle only when ready)
//   A3 work conserving: ready && some request  =>  some grant
//   A4 ROUND-ROBIN BOUND: a master that requests continuously is granted after at most NM-1 grants to OTHER masters
//      (the pointer only moves on a grant, so a stalled bank never disturbs fairness)
// =============================================================================
`include "sf_mm_defs.svh"
module fv_mm_arbiter #(parameter int NM = 3, parameter int ARB = 1, parameter int MW = (NM > 1) ? $clog2(NM) : 1) (
  input wire             clk,
  input wire [NM-1:0]    req,
  input wire             ready
);
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;                       // reset only in the first cycle (formal start state)
  wire [NM-1:0] gnt;
  wire          gv;
  wire [MW-1:0] ptr;
  sf_memory_matrix_arbiter #(.NM(NM), .ARB(ARB)) dut (.clk(clk), .rst_n(rst_n), .req_i(req), .ready_i(ready), .gnt_o(gnt), .gnt_v_o(gv), .ptr_o(ptr));

  always @* begin
    assert ((gnt & ~req) == '0);
    assert ($onehot0(gnt));
    if (!ready) assert (gnt == '0);
    if (ready && req != '0) assert (gnt != '0);
    assert (gv == (gnt != '0));
    assert (ptr < NM);
  end

  // A4: count grants to others while master i keeps requesting without being granted
  reg [3:0] others [0:NM-1];
  integer k;
  initial for (k = 0; k < NM; k = k + 1) others[k] = 4'd0;
  always @(posedge clk) begin
    for (k = 0; k < NM; k = k + 1) begin
      if (!rst_n || !req[k] || gnt[k]) others[k] <= 4'd0;
      else if (gv)                     others[k] <= others[k] + 4'd1;
    end
  end
  always @* begin
    for (k = 0; k < NM; k = k + 1) if (ARB == `SF_ARB_RR) assert (others[k] <= NM - 1);
  end
  // Auxiliary INDUCTIVE invariant that makes A4 provable without a depth bound: dist(k) = number of masters between the pointer and k
  // in round-robin order.  Every grant to another master j moves the pointer past j, which is at most dist(k)-1 positions away
  // (k itself is requesting, so the grant cannot skip over it), so dist(k) shrinks by at least one per foreign grant.
  integer dk;
  always @* begin
    for (k = 0; k < NM; k = k + 1) begin
      dk = (k >= ptr) ? (k - ptr) : (k + NM - ptr);
      if (ARB == `SF_ARB_RR) assert (others[k] + dk <= NM - 1);
    end
  end
endmodule
