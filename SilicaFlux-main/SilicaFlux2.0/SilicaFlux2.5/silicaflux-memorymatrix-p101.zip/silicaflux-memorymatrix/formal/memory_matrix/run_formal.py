#!/usr/bin/env python3
"""Run the SilicaFlux MemoryMatrix formal jobs with SymbiYosys (Yosys + z3 via smtbmc).  Run from the package root.

  python3 formal/memory_matrix/run_formal.py [--only NAME ...] [--out reports/formal.json] [--timeout S]

Requires: sby, yosys, yosys-smtbmc and z3 on PATH.  Each job writes its own .sby into build/formal/ and the result
(PASS / FAIL / TIMEOUT / ERROR) with the engine status line is collected.  A job that times out is reported as TIMEOUT:
nothing is claimed for it.  `bmc` results are BOUNDED (depth stated); `prove` results are unbounded (k-induction).
"""
import argparse, json, os, re, subprocess, sys, time

ROOT = os.getcwd()
INC = os.path.join(ROOT, "rtl/memory")
FV = os.path.join(ROOT, "formal/memory_matrix")
TP = os.path.join(ROOT, "rtl/memory/third_party/memorycore/rtl")
RAS = os.path.join(ROOT, "rtl/memory/third_party/ras_secded")
BUILD = os.path.join(ROOT, "build/formal")

CORE = [f"{TP}/sf_sram_core.sv", f"{TP}/backends/sf_sram_fpga_bram.sv", f"{TP}/backends/sf_sram_asic_sky130.sv",
        f"{TP}/sf_sram_macro_wrapper.sv", f"{TP}/sf_ecc_enc.sv", f"{TP}/sf_ecc_dec.sv", f"{TP}/sf_ecc_counters.sv", f"{TP}/sf_sram_bank.sv",
        f"{RAS}/sfras_secded_enc.sv", f"{RAS}/sfras_secded_dec.sv"]
MM = [f"{INC}/sf_memory_matrix_decoder.sv", f"{INC}/sf_memory_matrix_arbiter.sv", f"{INC}/sf_memory_matrix_perf.sv", f"{INC}/sf_memory_matrix.sv"]


def job(name, mode, depth, top, files, params=None, defs="", engine="smtbmc z3", note="", timeout=0):
    return dict(name=name, mode=mode, depth=depth, top=top, files=files, params=params or {}, defs=defs, engine=engine, note=note, timeout=timeout)


JOBS = []
# ---- address map: stateless => one BMC step is a complete proof over all inputs
for nb, dep, mode, gran in [(4, 16, 0, 0), (4, 16, 0, 2), (4, 16, 1, 0), (4, 12, 1, 2), (8, 8, 1, 0), (8, 8, 0, 1), (16, 4, 1, 0), (16, 8, 0, 0),
                            (4, 6, 2, 0), (4, 5, 2, 0), (2, 8, 1, 0)]:
    JOBS.append(job(f"map_nb{nb}_d{dep}_m{mode}_g{gran}", "bmc", 1, "fv_mm_map", [f"{FV}/fv_mm_map.sv"],
                    dict(NB=nb, DEPTH=dep, MODE=mode, GRAN=gran), note="stateless: complete over all inputs"))
# ---- arbiter
for nm in (2, 3, 4, 5):
    JOBS.append(job(f"arb_rr_nm{nm}", "bmc", 16, "fv_mm_arbiter", [f"{FV}/fv_mm_arbiter.sv"] + [f"{INC}/sf_memory_matrix_arbiter.sv"], dict(NM=nm, ARB=1)))
    JOBS.append(job(f"arb_rr_nm{nm}_prove", "prove", 10, "fv_mm_arbiter", [f"{FV}/fv_mm_arbiter.sv"] + [f"{INC}/sf_memory_matrix_arbiter.sv"], dict(NM=nm, ARB=1),
                    note="unbounded (k-induction)"))
# ---- matrix top, tiny configuration
JOBS.append(job("top_struct_nm2", "bmc", 10, "fv_mm_top", [f"{FV}/fv_mm_top.sv"] + CORE + MM, defs="-DSF_MM_ASSERT -DFORMAL", timeout=1500))
JOBS.append(job("top_data_cover", "cover", 12, "fv_mm_top", [f"{FV}/fv_mm_top.sv"] + CORE + MM, defs="-DSF_MM_ASSERT -DFORMAL -DFV_DATA", timeout=900,
                note="non-vacuity: the antecedent of the data-integrity assertion is reachable"))
JOBS.append(job("top_data_nm1", "bmc", 11, "fv_mm_top", [f"{FV}/fv_mm_top.sv"] + CORE + MM, defs="-DSF_MM_ASSERT -DFORMAL -DFV_DATA", timeout=1500))


HEADERS = [f"{INC}/sf_mm_defs.svh", f"{INC}/sf_mm_map.svh", f"{TP}/sf_sram_defs.svh", f"{RAS}/sfras_ecc_funcs.svh", f"{RAS}/sfras_defs.svh"]


def sby_text(j):
    # The Yosys used here is a WASM build that only sees its working directory: SBY copies everything listed under [files]
    # into src/ (flat, by basename), so the script reads by basename and includes from ".".
    chp = "".join(f"chparam -set {k} {v} {j['top']}\n" for k, v in j["params"].items())
    reads = "".join(f"read -formal -I. {j['defs']} {os.path.basename(f)}\n" for f in j["files"])
    files = "".join(f"{f}\n" for f in j["files"] + HEADERS)
    return f"""[options]
mode {j['mode']}
depth {j['depth']}
{('timeout ' + str(j['timeout'])) if j.get('timeout') else ''}
[engines]
{j['engine']}
[script]
{reads}{chp}prep -top {j['top']}
memory_map -rom-only
[files]
{files}"""


def run(j, timeout):
    os.makedirs(BUILD, exist_ok=True)
    f = os.path.join(BUILD, j["name"] + ".sby")
    open(f, "w").write(sby_text(j))
    t0 = time.time()
    try:
        r = subprocess.run(["sby", "-f", f], capture_output=True, text=True, timeout=timeout, cwd=BUILD)
    except subprocess.TimeoutExpired:
        return dict(name=j["name"], mode=j["mode"], depth=j["depth"], status="TIMEOUT", secs=round(time.time() - t0), note=j["note"])
    out = r.stdout + r.stderr
    st = "PASS" if re.search(r"DONE \(PASS", out) else ("FAIL" if re.search(r"DONE \(FAIL", out) else ("TIMEOUT" if re.search(r"DONE \((TIMEOUT|UNKNOWN)", out) else "ERROR"))
    steps = re.findall(r"Checking assertions in step (\d+)", out)
    reached = int(steps[-1]) if steps else None
    eng = re.findall(r"summary: .*?(returned \w+.*)", out)
    res = dict(name=j["name"], mode=j["mode"], depth=j["depth"], status=st, secs=round(time.time() - t0), engine=(eng[-1] if eng else ""), note=j["note"])
    if st == "TIMEOUT":
        done = (reached - 1) if reached is not None else None      # "Checking assertions in step N" is printed when step N STARTS
        res["note"] = (j["note"] + " " if j["note"] else "") + f"time limit: BMC completed steps 0..{done} (of {j['depth']} requested), no counterexample up to that depth"
        res["depth_reached"] = done
    if st == "ERROR":
        res["detail"] = "\n".join(out.splitlines()[-6:])
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out", default="reports/formal.json")
    ap.add_argument("--timeout", type=int, default=2400)
    a = ap.parse_args()
    jobs = [j for j in JOBS if not a.only or j["name"] in a.only]
    res = []
    for j in jobs:
        r = run(j, a.timeout)
        res.append(r)
        print(f'{r["status"]:8s} {r["name"]:28s} {r["mode"]:6s} depth={r["depth"]:<3d} {r["secs"]:>5d}s {r.get("engine", "")}  {r.get("detail", "")}', flush=True)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(res, open(a.out, "w"), indent=1)
    n = sum(1 for r in res if r["status"] == "PASS")
    print(f"\n{n}/{len(res)} formal jobs PASS")
    return 0 if n == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
