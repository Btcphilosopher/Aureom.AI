// =============================================================================
// fv_mm_map -- formal proof that the address map has NO ALIASING.
// The module is STATELESS (pure combinational), so a single BMC step with free inputs covers every input value:
// for the instantiated (NB, DEPTH, MODE, GRAN) the properties below are PROVED for ALL word indices / (bank,row) pairs.
//   P1 (injective)  w < NB*DEPTH  =>  unmap(map(w)) == w            (two different words can never share a physical location)
//   P2 (in range)   w < NB*DEPTH  =>  bank < NB and row < DEPTH     (every word lands inside the array)
//   P3 (onto)       bank < NB, row < DEPTH  =>  map(unmap(bank,row)) == (bank,row) and unmap(...) < NB*DEPTH
// The functions are the very text the RTL decoder / unmap modules include (rtl/memory/sf_mm_map.svh).
// =============================================================================
`include "sf_mm_defs.svh"
module fv_mm_map #(
  parameter int NB = 4, parameter int DEPTH = 16, parameter int MODE = 0, parameter int GRAN = 0,
  parameter int BW = $clog2(NB), parameter int ROW_W = $clog2(DEPTH), parameter int WIW = $clog2(NB * DEPTH)
) (
  input wire [WIW-1:0]    w,
  input wire [BW-1:0]     bnk,
  input wire [ROW_W-1:0]  r
);
  `include "sf_mm_map.svh"
  wire [BW+ROW_W-1:0] m = mm_map(w);
  always @* begin
    if ({1'b0, w} < (WIW + 1)'(NB * DEPTH)) begin   // one extra bit: NB*DEPTH may be exactly 2^WIW
      assert (mm_unmap(m[BW-1:0], m[BW +: ROW_W]) == w);
      assert (m[BW-1:0] < BW'(NB) || NB == (1 << BW));
      assert ({1'b0, m[BW +: ROW_W]} < (ROW_W + 1)'(DEPTH));
    end
    if ({1'b0, bnk} < (BW + 1)'(NB) && {1'b0, r} < (ROW_W + 1)'(DEPTH)) begin
      assert (mm_map(mm_unmap(bnk, r)) == {r, bnk});
      assert ({1'b0, mm_unmap(bnk, r)} < (WIW + 1)'(NB * DEPTH));
    end
  end
endmodule
