// SilicaFlux MemoryMatrix RTL file list (paths relative to the package root)
+incdir+rtl/memory
+incdir+rtl/memory/third_party/memorycore/rtl
+incdir+rtl/memory/third_party/ras_secded
rtl/memory/third_party/memorycore/rtl/sf_sram_core.sv
rtl/memory/third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv
rtl/memory/third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv
rtl/memory/third_party/memorycore/rtl/sf_sram_macro_wrapper.sv
rtl/memory/third_party/memorycore/rtl/sf_ecc_enc.sv
rtl/memory/third_party/memorycore/rtl/sf_ecc_dec.sv
rtl/memory/third_party/memorycore/rtl/sf_ecc_counters.sv
rtl/memory/third_party/memorycore/rtl/sf_sram_bank.sv
rtl/memory/third_party/ras_secded/sfras_secded_enc.sv
rtl/memory/third_party/ras_secded/sfras_secded_dec.sv
rtl/memory/sf_memory_matrix_decoder.sv
rtl/memory/sf_memory_matrix_arbiter.sv
rtl/memory/sf_memory_matrix_perf.sv
rtl/memory/sf_memory_matrix.sv
