// =============================================================================
// SilicaFlux MemoryCore :: sf_ecc_counters -- saturating correctable / uncorrectable event counters with
// first-error address capture and synchronous software clear.  See docs/ECC.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ecc_counters #(
  parameter int CNT_W = 16,
  parameter int AW    = 10
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             clr_i,       // synchronous clear of counters and captured addresses
  input  wire logic             ce_ev_i,     // one correctable event (pulse)
  input  wire logic             ue_ev_i,     // one uncorrectable event (pulse)
  input  wire logic [AW-1:0]    addr_i,      // location of the event
  output logic      [CNT_W-1:0] ce_cnt_o,    // saturating
  output logic      [CNT_W-1:0] ue_cnt_o,    // saturating
  output logic      [AW-1:0]    first_ce_addr_o,
  output logic      [AW-1:0]    first_ue_addr_o,
  output logic                  ce_seen_o,
  output logic                  ue_seen_o
);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ce_cnt_o <= '0; ue_cnt_o <= '0; first_ce_addr_o <= '0; first_ue_addr_o <= '0;
      ce_seen_o <= 1'b0; ue_seen_o <= 1'b0;
    end else if (clr_i) begin
      ce_cnt_o <= '0; ue_cnt_o <= '0; ce_seen_o <= 1'b0; ue_seen_o <= 1'b0;
    end else begin
      if (ce_ev_i) begin
        if (ce_cnt_o != {CNT_W{1'b1}}) ce_cnt_o <= ce_cnt_o + 1'b1;
        if (!ce_seen_o) begin first_ce_addr_o <= addr_i; ce_seen_o <= 1'b1; end
      end
      if (ue_ev_i) begin
        if (ue_cnt_o != {CNT_W{1'b1}}) ue_cnt_o <= ue_cnt_o + 1'b1;
        if (!ue_seen_o) begin first_ue_addr_o <= addr_i; ue_seen_o <= 1'b1; end
      end
    end
  end
endmodule

`default_nettype wire
