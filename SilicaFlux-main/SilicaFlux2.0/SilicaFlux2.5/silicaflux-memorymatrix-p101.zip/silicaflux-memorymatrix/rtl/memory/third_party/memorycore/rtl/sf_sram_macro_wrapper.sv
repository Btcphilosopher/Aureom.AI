// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_macro_wrapper
// One port list, three interchangeable memory backends (parameter BACKEND):
//   SF_BACKEND_BEHAV (0)  behavioural RTL array = sf_sram_core (simulation, formal, fault models, MBIST/ECC
//                         campaigns, logic synthesis to flops or inferred RAM)
//   SF_BACKEND_FPGA  (1)  inferred block RAM template (rtl/backends/sf_sram_fpga_bram.sv)
//   SF_BACKEND_ASIC  (2)  OpenRAM SKY130 hard-macro tiling (rtl/backends/sf_sram_asic_sky130.sv)
// Every backend presents the same contract: one access per edge (en/we/addr/wdata/be), result
// (rvalid/rwe/rtag/rdata) READ_LATENCY cycles after the accepting edge, no array reset.
// Differences (all enforced at elaboration or documented here):
//   * fault injection (fi_*, seu_*) exists only in BEHAV (simulation-only models); tied off otherwise.
//   * ASIC: READ_LATENCY >= 2 (macro output is not held), lanes multiple of 8 bits, SKY130 only.
//   * FPGA: READ-FIRST write mode; optional INIT_FILE.
// ASIC READINESS requires, per macro: functional model + SPICE netlist + Liberty timing/power + LEF
// abstract + GDS + technology/process data (physical/asic_readiness.md lists what the repository
// actually contains: geometry numbers and port/behaviour data only).  Selecting BACKEND = ASIC in
// simulation with the stand-in model is a STRUCTURAL check, not an ASIC-readiness claim.
// Classification: SYNTHESIZABLE / STRUCTURAL
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_macro_wrapper #(
  parameter int BACKEND      = `SF_BACKEND_BEHAV,
  parameter int DEPTH        = 1024,
  parameter int DATA_W       = 128,
  parameter int BE_W         = DATA_W / 8,
  parameter int READ_LATENCY = 1,
  parameter int RDW          = `SF_RDW_READ_FIRST,
  parameter int SIM_INIT     = 2,
  parameter int TAG_W        = 1,
  parameter int FAULT_INJECT = 0,
  parameter INIT_FILE = "",
  parameter int AW           = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int FBW          = (DATA_W > 1) ? $clog2(DATA_W) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              en,
  input  wire logic              we,
  input  wire logic [AW-1:0]     addr,
  input  wire logic [DATA_W-1:0] wdata,
  input  wire logic [BE_W-1:0]   be,
  input  wire logic [TAG_W-1:0]  tag_i,
  output logic                   rvalid,
  output logic                   rwe,
  output logic [TAG_W-1:0]       rtag,
  output logic [DATA_W-1:0]      rdata,
  input  wire logic [3:0]        fi_type,
  input  wire logic [AW-1:0]     fi_row,
  input  wire logic [AW-1:0]     fi_row2,
  input  wire logic [FBW-1:0]    fi_bit,
  input  wire logic [FBW-1:0]    fi_bit2,
  input  wire logic              fi_val,
  input  wire logic              fi_val2,
  input  wire logic              seu_pulse,
  input  wire logic [AW-1:0]     seu_row,
  input  wire logic [DATA_W-1:0] seu_mask
);
  if (BACKEND < 0 || BACKEND > 2) begin : g_err_be
    `SF_CFG_FATAL("sf_sram_macro_wrapper: BACKEND must be 0 (behavioural), 1 (FPGA BRAM) or 2 (ASIC macro)")
  end
  if (BACKEND != `SF_BACKEND_BEHAV && FAULT_INJECT != 0) begin : g_err_fi
    `SF_CFG_FATAL("sf_sram_macro_wrapper: fault injection exists only in the behavioural backend")
  end
  if (BACKEND != `SF_BACKEND_BEHAV && RDW != `SF_RDW_READ_FIRST) begin : g_err_rdw
    `SF_CFG_FATAL("sf_sram_macro_wrapper: only the behavioural backend supports RDW policies other than READ_FIRST")
  end

  if (BACKEND == `SF_BACKEND_BEHAV) begin : g_behav
    sf_sram_core #(.DEPTH(DEPTH), .DATA_W(DATA_W), .BE_W(BE_W), .READ_LATENCY(READ_LATENCY), .RDW(RDW),
                   .SIM_INIT(SIM_INIT), .TAG_W(TAG_W), .FAULT_INJECT(FAULT_INJECT)) u_mem (
      .clk(clk), .rst_n(rst_n), .en(en), .we(we), .addr(addr), .wdata(wdata), .be(be), .tag_i(tag_i),
      .rvalid(rvalid), .rwe(rwe), .rtag(rtag), .rdata(rdata),
      .fi_type(fi_type), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2),
      .fi_val(fi_val), .fi_val2(fi_val2), .seu_pulse(seu_pulse), .seu_row(seu_row), .seu_mask(seu_mask));
  end else if (BACKEND == `SF_BACKEND_FPGA) begin : g_fpga
    sf_sram_fpga_bram #(.DEPTH(DEPTH), .DATA_W(DATA_W), .BE_W(BE_W), .READ_LATENCY(READ_LATENCY),
                        .TAG_W(TAG_W), .INIT_FILE(INIT_FILE)) u_mem (
      .clk(clk), .rst_n(rst_n), .en(en), .we(we), .addr(addr), .wdata(wdata), .be(be), .tag_i(tag_i),
      .rvalid(rvalid), .rwe(rwe), .rtag(rtag), .rdata(rdata));
    wire unused_fi = &{1'b0, fi_type, fi_row, fi_row2, fi_bit, fi_bit2, fi_val, fi_val2, seu_pulse, seu_row, seu_mask};
  end else begin : g_asic
    sf_sram_asic_sky130 #(.DEPTH(DEPTH), .DATA_W(DATA_W), .BE_W(BE_W), .READ_LATENCY(READ_LATENCY), .TAG_W(TAG_W)) u_mem (
      .clk(clk), .rst_n(rst_n), .en(en), .we(we), .addr(addr), .wdata(wdata), .be(be), .tag_i(tag_i),
      .rvalid(rvalid), .rwe(rwe), .rtag(rtag), .rdata(rdata));
    wire unused_fi = &{1'b0, fi_type, fi_row, fi_row2, fi_bit, fi_bit2, fi_val, fi_val2, seu_pulse, seu_row, seu_mask, SIM_INIT[0]};
  end
endmodule

`default_nettype wire
