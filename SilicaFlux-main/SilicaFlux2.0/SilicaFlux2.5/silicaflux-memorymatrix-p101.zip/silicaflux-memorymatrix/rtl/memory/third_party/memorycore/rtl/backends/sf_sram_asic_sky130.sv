// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_asic_sky130   (backend C of sf_sram_macro_wrapper)
// Tiles the OpenRAM SKY130 macro  sky130_sram_1kbyte_1rw1r_32x256_8  (32-bit x 256 words, 4 byte
// masks, port 0 = read/write) into a DATA_W x DEPTH memory.  Port 1 (read-only) is tied off.
//
// Macro facts used (all from manifests/sky130_sram_1kbyte_1rw1r_32x256_8.json of the SRAM library,
// extracted from the vendor Verilog model / LEF; pinned commit in that manifest):
//   csb0 active-low chip select, web0 active-low write enable, wmask0[3:0] active-high byte masks,
//   rising-edge registered inputs, dout0 NOT held: "valid only in the cycle after the read: capture,
//   never rely on hold".  Therefore the result is captured by a register one cycle after the access
//   and the minimum latency of this backend is READ_LATENCY = 2 (enforced at elaboration).
//   A write needs the word's byte lanes: DATA_W with BE_W lanes must map onto 8-bit macro masks
//   (LANE_W multiple of 8, or BE_W = 1 whole-word writes as used by the ECC bank).
//
// STATUS: structural adapter.  Simulation uses sim_models/sky130_sram_standin.sv (a stand-in written
// from the manifest, NOT the vendor model).  No Liberty/LEF/GDS/SPICE is in the repository, so
// nothing here is ASIC-ready: see physical/asic_readiness.md.  In synthesis the macro is a black box.
// Classification: STRUCTURAL (requires the macro library)
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_asic_sky130 #(
  parameter int DEPTH        = 1024,
  parameter int DATA_W       = 128,
  parameter int BE_W         = DATA_W / 8,
  parameter int READ_LATENCY = 2,
  parameter int TAG_W        = 1,
  parameter int AW           = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              en,
  input  wire logic              we,
  input  wire logic [AW-1:0]     addr,
  input  wire logic [DATA_W-1:0] wdata,
  input  wire logic [BE_W-1:0]   be,
  input  wire logic [TAG_W-1:0]  tag_i,
  output logic                   rvalid,
  output logic                   rwe,
  output logic [TAG_W-1:0]       rtag,
  output logic [DATA_W-1:0]      rdata
);
  localparam int MW   = 32;                       // macro word width
  localparam int MD   = 256;                      // macro depth
  localparam int MAW  = 8;
  localparam int NWT  = (DATA_W + MW - 1) / MW;   // macros across the word
  localparam int NDT  = (DEPTH + MD - 1) / MD;    // macros down the depth
  localparam int LANE_W = DATA_W / BE_W;
  localparam int DTW  = (NDT > 1) ? $clog2(NDT) : 1;

  if (READ_LATENCY < 2) begin : g_e_lat
    `SF_CFG_FATAL("sf_sram_asic_sky130: the macro output is not held; capture needs READ_LATENCY >= 2")
  end
  if (DATA_W % BE_W != 0 || (BE_W > 1 && (LANE_W % 8) != 0)) begin : g_e_lane
    `SF_CFG_FATAL("sf_sram_asic_sky130: byte lanes must be a multiple of the 8-bit macro mask granularity (or BE_W = 1)")
  end

  // per-bit byte-mask of the whole word -> macro masks (one mask bit per 8 data bits)
  logic [NWT*MW-1:0] wd_pad;
  logic [NWT*(MW/8)-1:0] wm_pad;
  always_comb begin
    wd_pad = '0; wm_pad = '0;
    wd_pad[DATA_W-1:0] = wdata;
    for (int bt = 0; bt < NWT * (MW / 8); bt++) begin
      if (BE_W == 1)           wm_pad[bt] = be[0];
      else if (bt * 8 < DATA_W) wm_pad[bt] = be[(bt * 8) / LANE_W];
    end
  end

  wire [DTW-1:0] dsel = (NDT > 1) ? addr[AW-1:MAW] : '0;
  logic [DTW-1:0] dsel_q;                         // depth tile of the access, aligned with the macro output
  always_ff @(posedge clk) if (en) dsel_q <= dsel;

  logic [NDT*NWT*MW-1:0] mdout;
  for (genvar dt = 0; dt < NDT; dt++) begin : g_dt
    for (genvar wt = 0; wt < NWT; wt++) begin : g_wt
      wire sel = en & (dsel == DTW'(dt));
      wire [MW-1:0] unused_d1;
      sky130_sram_1kbyte_1rw1r_32x256_8 u_macro (
        .clk0(clk), .csb0(~sel), .web0(~we), .wmask0(wm_pad[wt*(MW/8) +: (MW/8)]),
        .addr0(addr[MAW-1:0]), .din0(wd_pad[wt*MW +: MW]), .dout0(mdout[(dt*NWT+wt)*MW +: MW]),
        .clk1(clk), .csb1(1'b1), .addr1({MAW{1'b0}}), .dout1(unused_d1));
    end
  end

  // capture one cycle after the access (macro output is not held), then pad to READ_LATENCY
  logic [NWT*MW-1:0] cap;
  always_comb begin
    cap = '0;
    for (int dt = 0; dt < NDT; dt++)
      if (dsel_q == DTW'(dt)) cap = mdout[dt*NWT*MW +: NWT*MW];
  end
  logic [NWT*MW-1:0] cap_q;
  always_ff @(posedge clk) cap_q <= cap;           // valid in the cycle 2 after the access edge

  logic [READ_LATENCY-1:0] vpipe, wpipe;
  logic [TAG_W-1:0] tpipe [0:READ_LATENCY-1];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin vpipe <= '0; wpipe <= '0; end
    else begin
      vpipe[0] <= en; wpipe[0] <= we;
      for (int s = 1; s < READ_LATENCY; s++) begin vpipe[s] <= vpipe[s-1]; wpipe[s] <= wpipe[s-1]; end
    end
  end
  always_ff @(posedge clk) begin
    tpipe[0] <= tag_i;
    for (int s = 1; s < READ_LATENCY; s++) tpipe[s] <= tpipe[s-1];
  end
  if (READ_LATENCY == 2) begin : g_l2
    assign rdata = cap_q[DATA_W-1:0];
  end else begin : g_ln
    logic [DATA_W-1:0] dq [2:READ_LATENCY-1];
    always_ff @(posedge clk) begin
      dq[2] <= cap_q[DATA_W-1:0];
      for (int s = 3; s < READ_LATENCY; s++) dq[s] <= dq[s-1];
    end
    assign rdata = dq[READ_LATENCY-1];
  end
  assign rvalid = vpipe[READ_LATENCY-1];
  assign rwe    = wpipe[READ_LATENCY-1];
  assign rtag   = tpipe[READ_LATENCY-1];
  localparam int PADW = NWT * MW - DATA_W;
  if (PADW > 0) begin : g_pad
    wire unused_pad = &{1'b0, cap_q[NWT*MW-1:DATA_W]};
  end
endmodule

`default_nettype wire
