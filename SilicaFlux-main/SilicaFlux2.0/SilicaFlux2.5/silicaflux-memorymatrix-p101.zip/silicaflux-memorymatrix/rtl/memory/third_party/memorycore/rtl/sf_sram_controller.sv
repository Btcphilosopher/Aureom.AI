// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_controller
// NM masters x NB single-port SRAM banks (sf_sram_bank), line-interleaved.
//
// ---------------------------------------------------------------- address map
//   Byte address a (AW bits).  LB = log2(DW/8) (4 for 128-bit lines).
//       line = a >> LB;   bank = line % NB;   row = line / NB          (NB power of two)
//   | row (ROW_W) | bank (BW) | byte offset (LB) |   -> consecutive lines rotate through the banks.
//   Capacity = NB * DEPTH * DW/8 bytes.  Error precedence: RANGE (line >= NB*DEPTH) over ALIGN.
//   ALIGN_MODE = 1: a request with a[LB-1:0] != 0 is answered SF_ST_ALIGN, no array access.
//   ALIGN_MODE = 0: the low LB bits are ignored.  Sub-line byte positions are always expressed with
//   the byte enables (wstrb) over the 16 byte lanes of the line (adapters shift data/strobes).
//
// ---------------------------------------------------------------- request / response channels (per master i)
//   m_req_* : valid/ready; {we, addr, wdata, be, id}.  A request is accepted when valid && ready; the
//             payload must be held until accepted (no cancellation).  m_req_ready is a function of registered
//             state, of this master's own valid/address AND of the other masters' requests (they compete for the
//             same bank through the arbiter) -- never of m_rsp_ready, so no combinational loop through responses.
//   m_rsp_* : valid/ready; {rdata, id, we, status, ce}.  Exactly one response per accepted request.
//             A presented response stays valid and unchanged until accepted.
//
// ---------------------------------------------------------------- ORDERING AND ATOMICITY CONTRACT
//   O1  Per-master issue order: a master's requests are accepted, and reach their bank, in the order
//       presented (one request per master per cycle; the next is not accepted before the previous one).
//   O2  Per-master response order: responses return in acceptance order, INCLUDING error responses and
//       requests to banks of different latency (RMW, scrub, init stalls).  Implemented by per-master
//       reorder slots (NSLOT): a slot is allocated in acceptance order, filled by the bank/error path
//       out of order, and released strictly from the oldest.  A master can have at most NSLOT requests
//       outstanding (response buffering == backpressure).
//   O3  Per-bank serialisation: every bank performs one access per cycle; the accesses to one bank are
//       totally ordered by acceptance (arbitration) order.  A read accepted at cycle t observes exactly
//       the writes accepted at cycles < t to the same line (read-after-write, write-after-write and
//       write-after-read hold per line, across ALL masters).
//   O4  Atomicity: ONE request is atomic at line granularity: all byte lanes of one access become visible
//       together, to every other master, at the accepting edge.  The ECC read-modify-write of a partial
//       write is atomic too (the bank accepts nothing else meanwhile).  There is NO atomicity across
//       requests (no locks, no atomic read-modify-write operations, no multi-line atomicity); a burst is
//       a sequence of independent line accesses that other masters' accesses may interleave with.
//   O5  Cross-master order: none, except through O3 for accesses to the same bank.  A producer makes
//       data visible to a consumer by waiting for the write RESPONSE before signalling.
//   O6  Fairness: ARB = RR: a continuously requesting master is granted by a bank within NM grants of
//       that bank (waiting bound NM-1 other grants).  ARB = FIXED: master 0 highest, starvation possible.
//   O7  flush_i (pulse): requests presented in the flush cycle are not accepted; no response is presented
//       from that cycle on; the controller waits for in-flight bank operations to retire, then discards
//       every slot and resumes.  Writes already accepted by a bank REMAIN committed (flush discards
//       responses, never memory effects).  flush_busy_o is high from the flush cycle until resumed.
//   O8  Reset clears all control state; memory contents are NOT reset (see sf_sram_core).  ECC builds
//       (or INIT_ON_RESET = 1) initialise the arrays after reset; req_ready of a bank stays low meanwhile.
//
// ---------------------------------------------------------------- latency
//   Bank latency BANK_LAT = READ_LATENCY (+1 with ECC).  An accepted request's slot is written
//   BANK_LAT cycles after acceptance and the response is visible the cycle after:  m_rsp_valid appears
//   BANK_LAT + 1 cycles after the accepting edge when not back-pressured.  Sustaining one access per
//   cycle per master needs NSLOT >= BANK_LAT + 2.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_controller #(
  parameter int NM            = 4,
  parameter int NB            = 4,
  parameter int DEPTH         = 1024,     // rows (lines) per bank
  parameter int DW            = 128,
  parameter int AW            = 32,
  parameter int IDW           = 8,
  parameter int READ_LATENCY  = 1,
  parameter int ECC_EN        = 0,
  parameter int NSLOT         = 8,
  parameter int ARB           = `SF_ARB_RR,
  parameter int ALIGN_MODE    = 1,
  parameter int INIT_ON_RESET = ECC_EN,
  parameter int SIM_INIT      = 2,
  parameter int FAULT_INJECT  = 0,
  parameter int BACKEND       = `SF_BACKEND_BEHAV,
  parameter int SCRUB_EN      = 0,
  parameter int SCRUB_WAIT    = 64,
  parameter int CNT_W         = 16,
  // ---- derived (do not override)
  parameter int LB            = $clog2(DW / 8),
  parameter int BW            = (NB > 1) ? $clog2(NB) : 1,
  parameter int ROW_W         = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int BE_W          = DW / 8,
  parameter int R             = $clog2(DW + $clog2(DW + 1) + 1),
  parameter int STORE_W       = (ECC_EN != 0) ? DW + R + 1 : DW,
  parameter int FBW           = (STORE_W > 1) ? $clog2(STORE_W) : 1,
  parameter int MW            = (NM > 1) ? $clog2(NM) : 1,
  parameter int SW            = (NSLOT > 1) ? $clog2(NSLOT) : 1,
  parameter int TAG_W         = MW + SW
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------------- master request channels
  input  wire logic [NM-1:0]          m_req_valid,
  output logic      [NM-1:0]          m_req_ready,
  input  wire logic [NM-1:0]          m_req_we,
  input  wire logic [NM*AW-1:0]       m_req_addr,
  input  wire logic [NM*DW-1:0]       m_req_wdata,
  input  wire logic [NM*BE_W-1:0]     m_req_be,
  input  wire logic [NM*IDW-1:0]      m_req_id,
  // ---------------------------------------------------------------- master response channels
  output logic      [NM-1:0]          m_rsp_valid,
  input  wire logic [NM-1:0]          m_rsp_ready,
  output logic      [NM*DW-1:0]       m_rsp_rdata,
  output logic      [NM*IDW-1:0]      m_rsp_id,
  output logic      [NM-1:0]          m_rsp_we,
  output logic      [NM*3-1:0]        m_rsp_status,
  output logic      [NM-1:0]          m_rsp_ce,
  // ---------------------------------------------------------------- control / status
  input  wire logic                   flush_i,
  output logic                        flush_busy_o,
  input  wire logic                   quiesce_i,        // refuse new requests (used before MBIST)
  output logic                        idle_o,           // nothing in flight, every bank idle
  input  wire logic                   init_start_i,     // (re)initialise all banks (zero lines, valid ECC)
  output logic                        init_busy_o,
  input  wire logic                   scrub_en_i,
  // ---------------------------------------------------------------- ECC
  input  wire logic                   ecc_clr_i,
  output logic      [NB-1:0]          ev_ce_o,
  output logic      [NB-1:0]          ev_ue_o,
  output logic      [NB*CNT_W-1:0]    ce_cnt_o,
  output logic      [NB*CNT_W-1:0]    ue_cnt_o,
  // ---------------------------------------------------------------- performance counters (32 bit, free running)
  output logic      [NB*32-1:0]       perf_acc_o,       // accesses accepted per bank
  output logic      [NB*32-1:0]       perf_conf_o,      // cycles with >=2 masters requesting the bank; only requests that hold a free
                                                          // response slot and are not rejected with RANGE/ALIGN are counted
  output logic      [NB*32-1:0]       perf_busy_o,      // cycles a requested bank was not ready
  output logic      [NM*32-1:0]       perf_stall_o,     // cycles master i had a request presented but not accepted
  output logic      [NB-1:0]          bank_acc_o,       // per-cycle trace: bank accepted an access
  // ---------------------------------------------------------------- MBIST raw test port (collar-compatible)
  input  wire logic                   tst_active_i,
  input  wire logic [NB-1:0]          tst_sel_i,
  input  wire logic                   tst_ce_i,
  input  wire logic                   tst_we_i,
  input  wire logic [ROW_W-1:0]       tst_addr_i,
  input  wire logic [STORE_W-1:0]     tst_wdata_i,
  output logic      [NB*STORE_W-1:0]  tst_rdata_o,
  // ---------------------------------------------------------------- simulation-only fault injection (selected bank)
  input  wire logic [BW-1:0]          fi_bank,
  input  wire logic [3:0]             fi_type,
  input  wire logic [ROW_W-1:0]       fi_row,
  input  wire logic [ROW_W-1:0]       fi_row2,
  input  wire logic [FBW-1:0]         fi_bit,
  input  wire logic [FBW-1:0]         fi_bit2,
  input  wire logic                   fi_val,
  input  wire logic                   fi_val2,
  input  wire logic                   seu_pulse,
  input  wire logic [ROW_W-1:0]       seu_row,
  input  wire logic [STORE_W-1:0]     seu_mask
);
  // ------------------------------------------------------------ parameter validation
  if (NM < 1 || NM > 32) begin : g_err_nm
    `SF_CFG_FATAL("sf_sram_controller: NM must be 1..32")
  end
  if (NB < 1 || (NB & (NB - 1)) != 0) begin : g_err_nb
    `SF_CFG_FATAL("sf_sram_controller: NB must be a power of two")
  end
  if (DEPTH < 2) begin : g_err_depth
    `SF_CFG_FATAL("sf_sram_controller: DEPTH must be >= 2")
  end
  if (NSLOT < 2) begin : g_err_nslot
    `SF_CFG_FATAL("sf_sram_controller: NSLOT must be >= 2")
  end
  if (AW <= LB || AW > 32) begin : g_err_aw
    `SF_CFG_FATAL("sf_sram_controller: AW must be in (log2(DW/8), 32]")
  end
  if (DW != 32 && DW != 64 && DW != 128 && DW != 256 && DW != 512) begin : g_err_dw
    `SF_CFG_FATAL("sf_sram_controller: DW must be 32, 64, 128, 256 or 512")
  end
  if (IDW < 1) begin : g_err_idw
    `SF_CFG_FATAL("sf_sram_controller: IDW must be >= 1")
  end

  localparam int LINEW = AW - LB;
  localparam int CAPW  = LINEW + 1;
  localparam int CAP_LINES = NB * DEPTH;
  localparam bit CAP_COVERS = (CAP_LINES >= (1 << LINEW));   // aperture covers every address bit pattern

  // ------------------------------------------------------------ per-master decode
  logic [NM-1:0]      err_v;
  logic [NM*3-1:0]    errst_v;
  logic [NM*BW-1:0]   bank_v;
  logic [NM*ROW_W-1:0] row_v;

  for (genvar i = 0; i < NM; i++) begin : g_dec
    wire [AW-1:0]    a    = m_req_addr[i*AW +: AW];
    wire [LINEW-1:0] line = a[AW-1:LB];
    wire oor = CAP_COVERS ? 1'b0 : ({1'b0, line} >= CAPW'(CAP_LINES));
    wire mis = (ALIGN_MODE != 0) && (a[LB-1:0] != '0);
    assign err_v[i]   = oor | mis;
    assign errst_v[i*3 +: 3] = oor ? `SF_ST_RANGE : (mis ? `SF_ST_ALIGN : `SF_ST_OK);
    if (NB > 1) begin : g_nb
      assign bank_v[i*BW +: BW] = line[BW-1:0];
      assign row_v[i*ROW_W +: ROW_W] = ROW_W'(line >> BW);
    end else begin : g_1b
      assign bank_v[i*BW +: BW] = '0;
      assign row_v[i*ROW_W +: ROW_W] = ROW_W'(line);
    end
  end

  // ------------------------------------------------------------ bank interfaces
  logic [NB-1:0]           b_req_valid, b_req_ready, b_req_we;
  logic [NB*ROW_W-1:0]     b_req_row;
  logic [NB*DW-1:0]        b_req_wdata;
  logic [NB*BE_W-1:0]      b_req_be;
  logic [NB*TAG_W-1:0]     b_req_tag;
  logic [NB-1:0]           b_rsp_valid, b_rsp_we, b_rsp_ce;
  logic [NB*DW-1:0]        b_rsp_rdata;
  logic [NB*TAG_W-1:0]     b_rsp_tag;
  logic [NB*3-1:0]         b_rsp_status;
  logic [NB-1:0]           b_idle, b_initbusy;

  // ------------------------------------------------------------ slot state (per master) -> flat views
  logic [NM-1:0]      can_alloc;
  logic [NM*SW-1:0]   tail_v;
  logic [NM-1:0]      pop_v;
  logic               flushing, clear_all;
  wire                blocked = flushing | flush_i | quiesce_i;

  // ------------------------------------------------------------ arbitration
  logic [NB*NM-1:0] rq_f;                          // masters requesting bank b this cycle
  logic [NB*NM-1:0] gnt_f;                         // one-hot grant per bank
  logic [NM-1:0]    gnt_any;                       // master i granted by some bank

  for (genvar b = 0; b < NB; b++) begin : g_arb
    logic [NM-1:0] rq, gnt;
    logic [MW-1:0] rr_ptr;
    always_comb begin : p_rq
      for (int i = 0; i < NM; i++)
        rq[i] = m_req_valid[i] & ~err_v[i] & can_alloc[i] & (bank_v[i*BW +: BW] == BW'(b));
    end
    always_comb begin : p_gnt
      logic   found;
      /* verilator lint_off UNUSEDSIGNAL */
      integer idx, ptr_i;
      /* verilator lint_on UNUSEDSIGNAL */
      gnt = '0; found = 1'b0; idx = 0; ptr_i = 0;
      ptr_i = {{(32-MW){1'b0}}, rr_ptr};
      if (b_req_ready[b]) begin
        for (int k = 0; k < NM; k++) begin
          idx = (ARB == `SF_ARB_RR) ? ((ptr_i + k) % NM) : k;
          if (!found && rq[idx]) begin gnt[idx] = 1'b1; found = 1'b1; end
        end
      end
    end
    always_ff @(posedge clk or negedge rst_n) begin : p_rr
      if (!rst_n) rr_ptr <= '0;
      else if (ARB == `SF_ARB_RR && (|gnt)) begin
        for (int i = 0; i < NM; i++)
          if (gnt[i]) rr_ptr <= (i == NM - 1) ? '0 : MW'(i + 1);
      end
    end
    assign rq_f[b*NM +: NM]  = rq;
    assign gnt_f[b*NM +: NM] = gnt;
    // bank request mux (one-hot AND-OR)
    always_comb begin : p_bq
      logic             v, w;
      logic [ROW_W-1:0] row;
      logic [DW-1:0]    wd;
      logic [BE_W-1:0]  be;
      logic [TAG_W-1:0] tg;
      v = 1'b0; w = 1'b0; row = '0; wd = '0; be = '0; tg = '0;
      for (int i = 0; i < NM; i++) begin
        if (gnt[i]) begin
          v = 1'b1;
          w = m_req_we[i];
          row = row | row_v[i*ROW_W +: ROW_W];
          wd  = wd  | m_req_wdata[i*DW +: DW];
          be  = be  | m_req_be[i*BE_W +: BE_W];
          tg  = tg  | {MW'(i), tail_v[i*SW +: SW]};
        end
      end
      b_req_valid[b] = v; b_req_we[b] = w;
      b_req_row[b*ROW_W +: ROW_W] = row; b_req_wdata[b*DW +: DW] = wd;
      b_req_be[b*BE_W +: BE_W] = be; b_req_tag[b*TAG_W +: TAG_W] = tg;
    end
  end

  always_comb begin
    gnt_any = '0;
    for (int b = 0; b < NB; b++) gnt_any = gnt_any | gnt_f[b*NM +: NM];
  end

  // master-side handshake
  for (genvar i = 0; i < NM; i++) begin : g_hs
    assign m_req_ready[i] = can_alloc[i] & (err_v[i] | gnt_any[i]);
  end
  wire [NM-1:0] acc_v = m_req_valid & m_req_ready;          // accepted this cycle (error or bank)

  // ------------------------------------------------------------ banks
  for (genvar b = 0; b < NB; b++) begin : g_bank
    wire fi_here = (fi_bank == BW'(b));
    wire [ROW_W-1:0] ev_row_u, fce_u, fue_u;
    wire [1:0] ev_kind_u;
    wire unused_b = &{1'b0, ev_row_u, ev_kind_u, fce_u, fue_u};
    sf_sram_bank #(
      .DEPTH(DEPTH), .DW(DW), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN), .TAG_W(TAG_W),
      .INIT_ON_RESET(INIT_ON_RESET), .SIM_INIT(SIM_INIT), .FAULT_INJECT(FAULT_INJECT), .BACKEND(BACKEND),
      .SCRUB_EN(SCRUB_EN), .SCRUB_WAIT(SCRUB_WAIT), .CNT_W(CNT_W)
    ) u_bank (
      .clk(clk), .rst_n(rst_n),
      .req_valid(b_req_valid[b]), .req_ready(b_req_ready[b]), .req_we(b_req_we[b]),
      .req_row(b_req_row[b*ROW_W +: ROW_W]), .req_wdata(b_req_wdata[b*DW +: DW]),
      .req_be(b_req_be[b*BE_W +: BE_W]), .req_tag(b_req_tag[b*TAG_W +: TAG_W]),
      .rsp_valid(b_rsp_valid[b]), .rsp_rdata(b_rsp_rdata[b*DW +: DW]), .rsp_tag(b_rsp_tag[b*TAG_W +: TAG_W]),
      .rsp_we(b_rsp_we[b]), .rsp_status(b_rsp_status[b*3 +: 3]), .rsp_ce(b_rsp_ce[b]),
      .init_start_i(init_start_i), .init_busy_o(b_initbusy[b]), .scrub_en_i(scrub_en_i), .idle_o(b_idle[b]),
      .ev_ce_o(ev_ce_o[b]), .ev_ue_o(ev_ue_o[b]), .ev_row_o(ev_row_u), .ev_kind_o(ev_kind_u),
      .cnt_clr_i(ecc_clr_i), .ce_cnt_o(ce_cnt_o[b*CNT_W +: CNT_W]), .ue_cnt_o(ue_cnt_o[b*CNT_W +: CNT_W]),
      .first_ce_row_o(fce_u), .first_ue_row_o(fue_u),
      .tst_active_i(tst_active_i), .tst_ce_i(tst_active_i & tst_sel_i[b] & tst_ce_i), .tst_we_i(tst_we_i),
      .tst_addr_i(tst_addr_i), .tst_wdata_i(tst_wdata_i), .tst_rdata_o(tst_rdata_o[b*STORE_W +: STORE_W]),
      .fi_type(fi_here ? fi_type : 4'd0), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2),
      .fi_val(fi_val), .fi_val2(fi_val2), .seu_pulse(seu_pulse & fi_here), .seu_row(seu_row), .seu_mask(seu_mask));
  end

  assign init_busy_o = |b_initbusy;

  // ------------------------------------------------------------ in-flight tracking, flush, quiesce
  logic [15:0] inflight;
  logic [7:0]  inf_acc, inf_rsp;
  always_comb begin : p_inf_n
    integer a_n, r_n;
    a_n = 0; r_n = 0;
    for (int b = 0; b < NB; b++) begin
      if (b_req_valid[b] && b_req_ready[b]) a_n = a_n + 1;
      if (b_rsp_valid[b]) r_n = r_n + 1;
    end
    inf_acc = a_n[7:0]; inf_rsp = r_n[7:0];
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) inflight <= '0;
    else        inflight <= inflight + 16'(inf_acc) - 16'(inf_rsp);
  end

  assign clear_all    = flushing & (inflight == '0);
  assign flush_busy_o = flushing | flush_i;
  assign idle_o       = (inflight == '0) & (&b_idle);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)          flushing <= 1'b0;
    else if (clear_all)  flushing <= 1'b0;
    else if (flush_i)    flushing <= 1'b1;
  end

  // ------------------------------------------------------------ per-master reorder slots
  for (genvar i = 0; i < NM; i++) begin : g_m
    logic [SW-1:0]       head, tail;
    logic [SW:0]         cnt;
    logic [NSLOT-1:0]    sv, sd, swe, sce;
    logic [NSLOT*DW-1:0] sdata;
    logic [NSLOT*3-1:0]  sstat;
    logic [NSLOT*IDW-1:0] sid;

    assign can_alloc[i] = (cnt != (SW+1)'(NSLOT)) & ~blocked;
    assign tail_v[i*SW +: SW] = tail;

    wire head_done = sv[head] & sd[head];
    assign m_rsp_valid[i] = head_done & ~flushing & ~flush_i;
    assign m_rsp_rdata[i*DW +: DW]   = sdata[head*DW +: DW];
    assign m_rsp_id[i*IDW +: IDW]    = sid[head*IDW +: IDW];
    assign m_rsp_we[i]               = swe[head];
    assign m_rsp_status[i*3 +: 3]    = sstat[head*3 +: 3];
    assign m_rsp_ce[i]               = sce[head];
    assign pop_v[i] = m_rsp_valid[i] & m_rsp_ready[i];

    wire alloc = acc_v[i];
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        head <= '0; tail <= '0; cnt <= '0;
      end else if (clear_all) begin
        head <= '0; tail <= '0; cnt <= '0;
      end else begin
        if (alloc)    tail <= (tail == SW'(NSLOT - 1)) ? '0 : tail + 1'b1;
        if (pop_v[i]) head <= (head == SW'(NSLOT - 1)) ? '0 : head + 1'b1;
        cnt <= cnt + (SW+1)'(alloc) - (SW+1)'(pop_v[i]);
      end
    end

    for (genvar s = 0; s < NSLOT; s++) begin : g_s
      logic             hit;
      logic [DW-1:0]    hdata;
      logic [2:0]       hstat;
      logic             hce, hwe;
      always_comb begin : p_hit
        hit = 1'b0; hdata = '0; hstat = '0; hce = 1'b0; hwe = 1'b0;
        for (int b = 0; b < NB; b++) begin
          if (b_rsp_valid[b] && b_rsp_tag[b*TAG_W + SW +: MW] == MW'(i) && b_rsp_tag[b*TAG_W +: SW] == SW'(s)) begin
            hit   = 1'b1;
            hwe   = b_rsp_we[b];
            hdata = b_rsp_we[b] ? '0 : b_rsp_rdata[b*DW +: DW];     // write responses carry rdata == 0
            hstat = b_rsp_status[b*3 +: 3];
            hce   = b_rsp_ce[b];
          end
        end
      end
      wire a_here = alloc && (tail == SW'(s));
      wire p_here = pop_v[i] && (head == SW'(s));
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          sv[s] <= 1'b0; sd[s] <= 1'b0; swe[s] <= 1'b0; sce[s] <= 1'b0;
          sdata[s*DW +: DW] <= '0; sstat[s*3 +: 3] <= '0; sid[s*IDW +: IDW] <= '0;
        end else if (clear_all) begin
          sv[s] <= 1'b0; sd[s] <= 1'b0;
        end else begin
          if (p_here) begin sv[s] <= 1'b0; sd[s] <= 1'b0; end
          if (a_here) begin
            sv[s] <= 1'b1; sid[s*IDW +: IDW] <= m_req_id[i*IDW +: IDW]; swe[s] <= m_req_we[i];
            sce[s] <= 1'b0;
            if (err_v[i]) begin
              sd[s] <= 1'b1; sdata[s*DW +: DW] <= '0; sstat[s*3 +: 3] <= errst_v[i*3 +: 3];
            end else begin
              sd[s] <= 1'b0; sstat[s*3 +: 3] <= `SF_ST_OK;
            end
          end else if (hit) begin
            sd[s] <= 1'b1; sdata[s*DW +: DW] <= hdata; sstat[s*3 +: 3] <= hstat; sce[s] <= hce; swe[s] <= hwe;
          end
        end
      end
    end
  end

  // ------------------------------------------------------------ performance counters
  for (genvar b = 0; b < NB; b++) begin : g_perf_b
    logic [31:0] c_acc, c_conf, c_busy;
    wire [NM-1:0] r = rq_f[b*NM +: NM];
    wire two = (|(r & (r - 1'b1)));                            // >= 2 requesters
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin c_acc <= '0; c_conf <= '0; c_busy <= '0; end
      else begin
        if (b_req_valid[b] && b_req_ready[b]) c_acc  <= c_acc + 1'b1;
        if (two)                              c_conf <= c_conf + 1'b1;
        if ((|r) && !b_req_ready[b])          c_busy <= c_busy + 1'b1;
      end
    end
    assign perf_acc_o[b*32 +: 32]  = c_acc;
    assign perf_conf_o[b*32 +: 32] = c_conf;
    assign perf_busy_o[b*32 +: 32] = c_busy;
    assign bank_acc_o[b] = b_req_valid[b] & b_req_ready[b];
  end
  for (genvar i = 0; i < NM; i++) begin : g_perf_m
    logic [31:0] c_stall;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) c_stall <= '0;
      else if (m_req_valid[i] && !m_req_ready[i]) c_stall <= c_stall + 1'b1;
    end
    assign perf_stall_o[i*32 +: 32] = c_stall;
  end

  // ------------------------------------------------------------ embedded checks
  `ifdef SF_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    for (int b = 0; b < NB; b++) begin
      `SF_CHK($onehot0(gnt_f[b*NM +: NM]), "sf_sram_controller: bank grant not exclusive")
      if (|gnt_f[b*NM +: NM]) `SF_CHK(b_req_ready[b], "sf_sram_controller: grant while bank not ready")
    end
    for (int i = 0; i < NM; i++) begin : a_m
      integer g;
      g = 0;
      for (int b = 0; b < NB; b++) g = g + (gnt_f[b*NM + i] ? 1 : 0);
      `SF_CHK(g <= 1, "sf_sram_controller: master granted by more than one bank")
    end
    `SF_CHK(inflight < 16'd4096, "sf_sram_controller: in-flight counter runaway")
  end
  `endif
endmodule

`default_nettype wire
