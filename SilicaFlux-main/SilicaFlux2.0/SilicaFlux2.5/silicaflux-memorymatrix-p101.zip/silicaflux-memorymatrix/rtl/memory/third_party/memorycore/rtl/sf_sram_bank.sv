// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_bank
// One single-port SRAM bank: request/response wrapper around sf_sram_core.
// DW-bit lines (128 by default), byte write enables, optional SECDED protection,
// init engine, opportunistic scrubber, raw MBIST test port, ECC event counters.
//
// ---------------------------------------------------------------- port contract
//   Request  (req_valid/req_ready): at most ONE access is accepted per clock edge
//     (single-port bank).  A request transfers when req_valid && req_ready; the
//     array is accessed at that same edge, so a request accepted at edge t is
//     ordered before every request accepted at a later edge.  req_ready is a
//     function of registered state only (never of req_valid).
//   Response (rsp_valid, no ready): the consumer MUST always accept; the
//     controller guarantees this by reserving the response slot at issue time.
//     Exactly one response per accepted request, in acceptance order, carrying
//     the request's tag.  Latency from acceptance edge to the cycle rsp_valid is
//     visible:
//         BANK_LAT = READ_LATENCY + (ECC_EN ? 1 : 0)        (reads, writes, RMW alike)
//   rsp_status: SF_ST_OK or SF_ST_ECC_UE (uncorrectable).  rsp_ce = a single-bit
//     error was corrected on the way (data returned is the corrected data).
//
// ---------------------------------------------------------------- ECC (ECC_EN = 1)
//   Stored word = SECDED(137,128) of the whole line (sf_ecc_enc / sf_ecc_dec).
//   * full-line write  : encoded and written, one array cycle.
//   * read             : decoded; single-bit error corrected (rsp_ce = 1);
//                        uncorrectable -> rsp_status = SF_ST_ECC_UE and rsp_rdata
//                        is the stored (uncorrected) data, never presented as valid.
//   * PARTIAL write (0 < be < all ones): the check bits cover the whole line, so the
//     bank performs an atomic read-modify-write: read, decode+correct, merge the
//     written bytes, re-encode, write back.  The bank accepts nothing else during
//     the READ_LATENCY cycles in between, so no other access can see or change the
//     line in between (atomic).  If the old line is UNCORRECTABLE the bytes it
//     contributes are unknown: the write is ABORTED (line left as found), the
//     response carries SF_ST_ECC_UE.  A full-line write never needs the old data
//     and therefore repairs an uncorrectable line.
//     Throughput cost: a partial write occupies the bank READ_LATENCY+1 cycles.
//   * be == 0 write    : acknowledged no-op (no array access effect).
//   Check-bit inversion (library default) makes an all-zero stored word decode as
//   UNCORRECTABLE: a row that was never initialised cannot be read as valid data.
//
// ---------------------------------------------------------------- maintenance
//   init_start_i (pulse) / INIT_ON_RESET: after the bank is idle, every row is
//     written with the all-zero line (valid ECC) one per cycle; req_ready = 0 and
//     init_busy_o = 1 meanwhile.  This is the explicit initialisation mechanism;
//     the array itself is never reset.
//   scrub (SCRUB_EN & ECC_EN & scrub_en_i): at most one scrub step per SCRUB_WAIT
//     cycles, started only in a cycle in which NO request is presented to the bank.
//     A step reads one row (round-robin), writes it back corrected if a single-bit
//     error was found (counts as a CE event) and reports UEs.  A step never delays a
//     request that is already presented; a request arriving DURING a step waits
//     READ_LATENCY cycles (the bank is busy until the scrub read returns).
//
// ---------------------------------------------------------------- MBIST test port
//   tst_active_i: the array belongs to the test bus (functional req_ready = 0).
//   tst_ce_i/tst_we_i/tst_addr_i/tst_wdata_i: one raw operation per cycle on the
//   STORED word (data AND check bits are tested).  tst_rdata_o = the raw word
//   exactly READ_LATENCY cycles after a test read.  The controller drives the bus
//   only after quiescing the bank (idle_o = 1).  MBIST is destructive; the
//   controller re-initialises the bank afterwards.
// Classification: SYNTHESIZABLE (FAULT_INJECT = 0)
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_bank #(
  parameter int DEPTH         = 1024,
  parameter int DW            = 128,
  parameter int READ_LATENCY  = 1,
  parameter int ECC_EN        = 0,
  parameter int TAG_W         = 4,
  parameter int RDW           = `SF_RDW_READ_FIRST,
  parameter int INIT_ON_RESET = ECC_EN,
  parameter int SIM_INIT      = 2,
  parameter int FAULT_INJECT  = 0,
  parameter int BACKEND       = `SF_BACKEND_BEHAV,
  parameter int SCRUB_EN      = 0,
  parameter int SCRUB_WAIT    = 64,
  parameter int CNT_W         = 16,
  parameter int AW            = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int BE_W          = DW / 8,
  parameter int R             = $clog2(DW + $clog2(DW + 1) + 1),
  parameter int STORE_W       = (ECC_EN != 0) ? DW + R + 1 : DW,
  parameter int FBW           = (STORE_W > 1) ? $clog2(STORE_W) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---------------------------------------------------------------- request
  input  wire logic                req_valid,
  output logic                     req_ready,
  input  wire logic                req_we,
  input  wire logic [AW-1:0]       req_row,
  input  wire logic [DW-1:0]       req_wdata,
  input  wire logic [BE_W-1:0]     req_be,
  input  wire logic [TAG_W-1:0]    req_tag,
  // ---------------------------------------------------------------- response
  output logic                     rsp_valid,
  output logic [DW-1:0]            rsp_rdata,
  output logic [TAG_W-1:0]         rsp_tag,
  output logic                     rsp_we,
  output logic [2:0]               rsp_status,
  output logic                     rsp_ce,
  // ---------------------------------------------------------------- maintenance
  input  wire logic                init_start_i,
  output logic                     init_busy_o,
  input  wire logic                scrub_en_i,
  output logic                     idle_o,
  // ---------------------------------------------------------------- ECC events / counters
  output logic                     ev_ce_o,
  output logic                     ev_ue_o,
  output logic [AW-1:0]            ev_row_o,
  output logic [1:0]               ev_kind_o,
  input  wire logic                cnt_clr_i,
  output logic [CNT_W-1:0]         ce_cnt_o,
  output logic [CNT_W-1:0]         ue_cnt_o,
  output logic [AW-1:0]            first_ce_row_o,
  output logic [AW-1:0]            first_ue_row_o,
  // ---------------------------------------------------------------- MBIST raw test port
  input  wire logic                tst_active_i,
  input  wire logic                tst_ce_i,
  input  wire logic                tst_we_i,
  input  wire logic [AW-1:0]       tst_addr_i,
  input  wire logic [STORE_W-1:0]  tst_wdata_i,
  output logic [STORE_W-1:0]       tst_rdata_o,
  // ---------------------------------------------------------------- simulation-only fault injection
  input  wire logic [3:0]          fi_type,
  input  wire logic [AW-1:0]       fi_row,
  input  wire logic [AW-1:0]       fi_row2,
  input  wire logic [FBW-1:0]      fi_bit,
  input  wire logic [FBW-1:0]      fi_bit2,
  input  wire logic                fi_val,
  input  wire logic                fi_val2,
  input  wire logic                seu_pulse,
  input  wire logic [AW-1:0]       seu_row,
  input  wire logic [STORE_W-1:0]  seu_mask
);
  // ------------------------------------------------------------ parameter validation
  if (ECC_EN != 0 && ECC_EN != 1) begin : g_err_ecc
    `SF_CFG_FATAL("sf_sram_bank: ECC_EN must be 0 or 1")
  end
  if (DW < 8 || (DW % 8) != 0) begin : g_err_dw
    `SF_CFG_FATAL("sf_sram_bank: DW must be a multiple of 8")
  end
  if (SCRUB_EN != 0 && ECC_EN == 0) begin : g_err_scrub
    `SF_CFG_FATAL("sf_sram_bank: SCRUB_EN requires ECC_EN")
  end
  if (READ_LATENCY < 1) begin : g_err_lat
    `SF_CFG_FATAL("sf_sram_bank: READ_LATENCY must be >= 1")
  end

  localparam int TAGC_W = TAG_W + AW + 2;          // core tag: {ackonly, int, row, tag}
  localparam int PEND_W = 8;
  localparam int CBE_W  = (ECC_EN != 0) ? 1 : BE_W;  // core write-enable lanes (ECC words are written whole)
  localparam int IW_D   = $clog2(STORE_W);
  localparam int ST_W   = $clog2(SCRUB_WAIT + 2);

  // ------------------------------------------------------------ FSM
  localparam logic [1:0] S_IDLE = 2'd0, S_RMW = 2'd1, S_SCRUB = 2'd2, S_INIT = 2'd3;
  logic [1:0] state;
  logic       init_pend;
  logic [AW-1:0] init_row;
  logic [AW-1:0] rmw_row, scrub_ptr;
  logic [DW-1:0] rmw_wdata;
  logic [BE_W-1:0] rmw_be;
  logic [TAG_W-1:0] rmw_tag;
  logic [ST_W-1:0] scrub_timer;

  // ------------------------------------------------------------ core interface
  logic                 c_en, c_we;
  logic [AW-1:0]        c_addr;
  logic [STORE_W-1:0]   c_wdata;
  logic [CBE_W-1:0]     c_be;
  logic [TAGC_W-1:0]    c_tag;
  logic                 k_valid, k_we;
  logic [TAGC_W-1:0]    k_tag;
  logic [STORE_W-1:0]   k_data;

  sf_sram_macro_wrapper #(.BACKEND(BACKEND), .DEPTH(DEPTH), .DATA_W(STORE_W), .BE_W(CBE_W), .READ_LATENCY(READ_LATENCY),
                          .RDW(RDW), .SIM_INIT(SIM_INIT), .TAG_W(TAGC_W), .FAULT_INJECT(FAULT_INJECT)) u_core (
    .clk(clk), .rst_n(rst_n), .en(c_en), .we(c_we), .addr(c_addr), .wdata(c_wdata), .be(c_be), .tag_i(c_tag),
    .rvalid(k_valid), .rwe(k_we), .rtag(k_tag), .rdata(k_data),
    .fi_type(fi_type), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2),
    .fi_val(fi_val), .fi_val2(fi_val2), .seu_pulse(seu_pulse), .seu_row(seu_row), .seu_mask(seu_mask));

  assign tst_rdata_o = k_data;

  wire                 k_ackonly = k_tag[TAG_W + AW + 1];
  wire                 k_int     = k_tag[TAG_W + AW];
  wire [AW-1:0]        k_row     = k_tag[TAG_W +: AW];
  wire [TAG_W-1:0]     k_utag    = k_tag[TAG_W-1:0];

  // ------------------------------------------------------------ in-flight tracking (for idle_o)
  logic [PEND_W-1:0] pend;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pend <= '0;
    else        pend <= pend + PEND_W'(c_en) - PEND_W'(k_valid);
  end

  // ------------------------------------------------------------ ready / maintenance decisions
  wire idle_st = (state == S_IDLE);
  assign req_ready = idle_st & ~init_pend & ~tst_active_i;
  wire acc = req_valid & req_ready;
  assign init_busy_o = (state == S_INIT);
  assign idle_o = idle_st & ~init_pend & (pend == '0);

  wire scrub_go = (SCRUB_EN != 0) & (ECC_EN != 0) & scrub_en_i & idle_st & ~init_pend & ~tst_active_i &
                  ~req_valid & (scrub_timer == '0);

  // ------------------------------------------------------------ ECC datapath
  logic [STORE_W-1:0] enc_new_cw, enc_zero_cw, enc_mrg_cw;
  logic [DW-1:0]      dec_data;
  logic [STORE_W-1:0] dec_cwc;
  logic               dec_ce, dec_ue;
  logic [2:0]         dec_class;
  logic [DW-1:0]      mrg_data;
  logic [DW-1:0]      be_mask;

  always_comb begin
    for (int l = 0; l < BE_W; l++) be_mask[l*8 +: 8] = {8{rmw_be[l]}};
  end
  assign mrg_data = (dec_data & ~be_mask) | (rmw_wdata & be_mask);

  if (ECC_EN != 0) begin : g_ecc
    logic [IW_D-1:0] idx_unused;
    sf_ecc_enc #(.K(DW)) u_enc_new  (.data_i(req_wdata),  .cw_o(enc_new_cw));
    sf_ecc_enc #(.K(DW)) u_enc_zero (.data_i('0),         .cw_o(enc_zero_cw));
    sf_ecc_enc #(.K(DW)) u_enc_mrg  (.data_i(mrg_data),   .cw_o(enc_mrg_cw));
    sf_ecc_dec #(.K(DW)) u_dec (.cw_i(k_data), .data_o(dec_data), .cw_corr_o(dec_cwc), .ce_o(dec_ce),
                                .ue_o(dec_ue), .class_o(dec_class), .err_idx_o(idx_unused));
  end else begin : g_noecc
    assign enc_new_cw = '0; assign enc_zero_cw = '0; assign enc_mrg_cw = '0;
    assign dec_data = '0; assign dec_cwc = '0; assign dec_ce = 1'b0; assign dec_ue = 1'b0; assign dec_class = '0;
  end
  wire part_wr = req_we & (req_be != '0) & (req_be != {BE_W{1'b1}});
  wire zero_wr = req_we & (req_be == '0);

  wire rmw_data_back = (state == S_RMW)   & k_valid & k_int & ~k_we;
  wire scr_data_back = (state == S_SCRUB) & k_valid & k_int & ~k_we;

  // ------------------------------------------------------------ core operation select
  always_comb begin
    c_en = 1'b0; c_we = 1'b0; c_addr = '0; c_wdata = '0; c_be = '0; c_tag = '0;
    if (tst_ce_i) begin
      c_en = 1'b1; c_we = tst_we_i; c_addr = tst_addr_i; c_wdata = tst_wdata_i; c_be = '1;
      c_tag = TAGC_W'(1) << (TAG_W + AW);                         // int
    end else begin
      case (state)
        S_INIT: begin
          c_en = 1'b1; c_we = 1'b1; c_addr = init_row; c_be = '1;
          c_wdata = (ECC_EN != 0) ? enc_zero_cw : '0;
          c_tag = TAGC_W'(1) << (TAG_W + AW);
        end
        S_RMW: if (rmw_data_back && !dec_ue) begin
          c_en = 1'b1; c_we = 1'b1; c_addr = rmw_row; c_be = '1; c_wdata = enc_mrg_cw;
          c_tag = TAGC_W'(1) << (TAG_W + AW);
        end
        S_SCRUB: if (scr_data_back && dec_ce && !dec_ue) begin
          c_en = 1'b1; c_we = 1'b1; c_addr = scrub_ptr; c_be = '1; c_wdata = dec_cwc;
          c_tag = TAGC_W'(1) << (TAG_W + AW);
        end
        default: begin
          if (scrub_go) begin
            c_en = 1'b1; c_we = 1'b0; c_addr = scrub_ptr;
            c_tag = TAGC_W'(1) << (TAG_W + AW);
          end else if (acc) begin
            c_en = 1'b1; c_addr = req_row;
            c_tag = {1'b0, 1'b0, req_row, req_tag};
            if (ECC_EN != 0) begin
              if (part_wr) begin                                   // read half of a read-modify-write
                c_we = 1'b0; c_tag = {1'b0, 1'b1, req_row, req_tag};
              end else if (zero_wr) begin                          // acknowledged no-op
                c_we = 1'b0; c_tag = {1'b1, 1'b0, req_row, req_tag};
              end else begin
                c_we = req_we; c_wdata = enc_new_cw; c_be = CBE_W'(1);
              end
            end else begin
              c_we = req_we; c_wdata = STORE_W'(req_wdata); c_be = CBE_W'(req_be);
            end
          end
        end
      endcase
    end
  end

  // ------------------------------------------------------------ FSM registers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; init_pend <= (INIT_ON_RESET != 0); init_row <= '0;
      scrub_ptr <= '0; scrub_timer <= ST_W'(SCRUB_WAIT);
      rmw_row <= '0; rmw_wdata <= '0; rmw_be <= '0; rmw_tag <= '0;
    end else begin
      if (init_start_i) init_pend <= 1'b1;
      if (scrub_en_i && idle_st && scrub_timer != '0) scrub_timer <= scrub_timer - 1'b1;
      case (state)
        S_IDLE: begin
          if (init_pend && !tst_active_i) begin
            state <= S_INIT; init_pend <= 1'b0; init_row <= '0;
          end else if (scrub_go) begin
            state <= S_SCRUB;
          end else if (acc && ECC_EN != 0 && part_wr) begin
            state <= S_RMW; rmw_row <= req_row; rmw_wdata <= req_wdata; rmw_be <= req_be; rmw_tag <= req_tag;
          end
        end
        S_RMW:   if (rmw_data_back) state <= S_IDLE;
        S_SCRUB: if (scr_data_back) begin
          state <= S_IDLE;
          scrub_ptr <= (scrub_ptr == AW'(DEPTH - 1)) ? '0 : scrub_ptr + 1'b1;
          scrub_timer <= ST_W'(SCRUB_WAIT);
        end
        S_INIT: begin
          if (init_row == AW'(DEPTH - 1)) state <= S_IDLE;
          else                            init_row <= init_row + 1'b1;
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------ response / event path
  logic               d_valid, d_we, d_ce;
  logic [DW-1:0]      d_data;
  logic [TAG_W-1:0]   d_tag;
  logic [2:0]         d_status;
  logic               e_ce, e_ue;
  logic [AW-1:0]      e_row;
  logic [1:0]         e_kind;

  always_comb begin
    d_valid = 1'b0; d_we = 1'b0; d_ce = 1'b0; d_data = '0; d_tag = '0; d_status = `SF_ST_OK;
    e_ce = 1'b0; e_ue = 1'b0; e_row = '0; e_kind = `SF_EVK_READ;
    if (ECC_EN != 0) begin
      if (k_valid && !k_int) begin                                  // functional result from the array
        d_valid = 1'b1; d_tag = k_utag; d_we = k_we | k_ackonly;
        if (!k_we && !k_ackonly) begin                              // read: decode
          d_data = dec_data; d_ce = dec_ce; d_status = dec_ue ? `SF_ST_ECC_UE : `SF_ST_OK;
          e_ce = dec_ce; e_ue = dec_ue; e_row = k_row; e_kind = `SF_EVK_READ;
        end
      end
      if (rmw_data_back) begin                                      // RMW completes: acknowledge the write
        d_valid = 1'b1; d_tag = rmw_tag; d_we = 1'b1; d_ce = dec_ce; d_status = dec_ue ? `SF_ST_ECC_UE : `SF_ST_OK;
        e_ce = dec_ce; e_ue = dec_ue; e_row = rmw_row; e_kind = `SF_EVK_RMW;
      end
      if (scr_data_back) begin                                      // scrub observation
        e_ce = dec_ce; e_ue = dec_ue; e_row = scrub_ptr; e_kind = `SF_EVK_SCRUB;
      end
    end else begin
      if (k_valid && !k_int) begin
        d_valid = 1'b1; d_tag = k_utag; d_we = k_we; d_data = DW'(k_data);
      end
    end
  end

  if (ECC_EN != 0) begin : g_out_reg
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        rsp_valid <= 1'b0; ev_ce_o <= 1'b0; ev_ue_o <= 1'b0;
        rsp_rdata <= '0; rsp_tag <= '0; rsp_we <= 1'b0; rsp_status <= '0; rsp_ce <= 1'b0;
        ev_row_o <= '0; ev_kind_o <= '0;
      end else begin
        rsp_valid <= d_valid; rsp_rdata <= d_data; rsp_tag <= d_tag; rsp_we <= d_we;
        rsp_status <= d_status; rsp_ce <= d_ce;
        ev_ce_o <= e_ce; ev_ue_o <= e_ue; ev_row_o <= e_row; ev_kind_o <= e_kind;
      end
    end
  end else begin : g_out_comb
    assign rsp_valid = d_valid; assign rsp_rdata = d_data; assign rsp_tag = d_tag; assign rsp_we = d_we;
    assign rsp_status = d_status; assign rsp_ce = d_ce;
    assign ev_ce_o = 1'b0; assign ev_ue_o = 1'b0; assign ev_row_o = '0; assign ev_kind_o = '0;
  end

  logic ce_seen_unused, ue_seen_unused;
  sf_ecc_counters #(.CNT_W(CNT_W), .AW(AW)) u_cnt (
    .clk(clk), .rst_n(rst_n), .clr_i(cnt_clr_i), .ce_ev_i(ev_ce_o), .ue_ev_i(ev_ue_o), .addr_i(ev_row_o),
    .ce_cnt_o(ce_cnt_o), .ue_cnt_o(ue_cnt_o), .first_ce_addr_o(first_ce_row_o), .first_ue_addr_o(first_ue_row_o),
    .ce_seen_o(ce_seen_unused), .ue_seen_o(ue_seen_unused));

  // ------------------------------------------------------------ embedded checks
  `ifdef SF_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    // one response per cycle: the RMW acknowledge never coincides with a functional array result
    if (rmw_data_back) `SF_CHK(!(k_valid && !k_int), "sf_sram_bank: RMW ack collides with a functional result")
    // the controller must quiesce the bank before driving the test port
    if (tst_ce_i) `SF_CHK(state == S_IDLE, "sf_sram_bank: test access while the bank FSM is busy")
    if (acc) `SF_CHK(req_row < AW'(DEPTH) || (DEPTH & (DEPTH - 1)) == 0, "sf_sram_bank: row beyond DEPTH")
  end
  `endif

  wire unused_ok = &{1'b0, dec_class, mrg_data, e_ce, e_ue, e_row, e_kind, ce_seen_unused, ue_seen_unused};
endmodule

`default_nettype wire
