// =============================================================================
// SilicaFlux MemoryCore :: sf_ecc_dec -- SECDED decoder + error classifier (wrapper over sfras_secded_dec).
// class_o: SF_ECC_NONE / CE_DATA / CE_CHECK / UE_DOUBLE / UE_INVALID (>=3 errors, syndrome names no bit).  See docs/ECC.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ecc_dec #(
  parameter int K   = 128,
  parameter int R   = $clog2(K + $clog2(K + 1) + 1),
  parameter int N   = K + R + 1,
  parameter int IW  = $clog2(N)
) (
  input  wire logic [N-1:0] cw_i,
  output logic      [K-1:0] data_o,      // corrected data (the stored data bits on UE)
  output logic      [N-1:0] cw_corr_o,   // corrected stored codeword (unchanged on UE)
  output logic              ce_o,        // a single bit was corrected
  output logic              ue_o,        // uncorrectable error detected
  output logic      [2:0]   class_o,     // SF_ECC_* classification
  output logic      [IW-1:0] err_idx_o   // stored-bit index of the corrected bit (valid with ce_o)
);
  /* verilator lint_off VARHIDDEN */
  `include "sfras_ecc_funcs.svh"
  /* verilator lint_on VARHIDDEN */
  localparam int INV = sfras_ecc_default_inv(K);
  logic none_w, inval_w, cedata_w;
  logic [R:0] syn_unused;
  sfras_secded_dec #(.K(K), .INV(INV)) u_dec (
    .cw_i(cw_i), .data_o(data_o), .cw_corr_o(cw_corr_o), .none_o(none_w), .ce_o(ce_o), .ue_o(ue_o),
    .ue_inval_o(inval_w), .ce_data_o(cedata_w), .err_idx_o(err_idx_o), .syn_o(syn_unused));
  always_comb begin
    if (none_w)                 class_o = `SF_ECC_NONE;
    else if (ce_o && cedata_w)  class_o = `SF_ECC_CE_DATA;
    else if (ce_o)              class_o = `SF_ECC_CE_CHECK;
    else if (inval_w)           class_o = `SF_ECC_UE_INVALID;
    else                        class_o = `SF_ECC_UE_DOUBLE;
  end
endmodule

`default_nettype wire
