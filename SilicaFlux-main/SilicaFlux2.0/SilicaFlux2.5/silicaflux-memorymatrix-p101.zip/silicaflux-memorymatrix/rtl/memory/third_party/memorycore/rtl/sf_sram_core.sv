// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_core
// Single-port (1RW) synchronous SRAM storage core, behavioural backend.
//
// ---------------------------------------------------------------- port timing
//   One access per clock edge: en=1 selects the row addr; we=1 writes the byte
//   lanes whose be bit is set, we=0 reads.  Every enabled access produces
//   exactly one result, READ_LATENCY cycles after the edge that accepted it:
//     rvalid / rwe / rtag / rdata   (rwe echoes the operation, rtag the caller's tag)
//   READ_LATENCY >= 1: stage 0 is the synchronous read register, stages
//   1..READ_LATENCY-1 are plain pipeline registers.
//
// ---------------------------------------------------------------- semantics (explicit)
//   * A write is committed at the accepting edge: a read accepted at ANY later
//     edge returns the written bytes ("reads observe all earlier writes").
//   * Read-during-write (RDW) applies to the data the result carries for a
//     WRITE access (a single port cannot read and write different data in one
//     cycle; this is what the output register shows on a write cycle):
//       SF_RDW_READ_FIRST  : the row's OLD contents (before this write)
//       SF_RDW_WRITE_FIRST : the row's NEW contents (written lanes merged)
//       SF_RDW_NO_CHANGE   : the output register keeps its previous value
//     For a read access rdata is always the row contents at the accepting edge.
//   * An access with addr >= DEPTH (non-power-of-two DEPTH only) is ignored:
//     no write, read result 0.  The controller never issues one.
//   * The array is NEVER reset (a reset would prevent SRAM / block-RAM
//     inference).  Only the result-valid pipeline has a reset.  Contents after
//     power-up are undefined; SIM_INIT selects what SIMULATION shows:
//       0 leave uninitialised (X in 4-state simulators)
//       1 zero          2 poison pattern (default: catches reads of never-written rows)
//     Initialisation / scrubbing of a real array is an explicit operation of
//     sf_sram_bank (init engine), never an implicit reset.
//   * Byte lanes: DATA_W = BE_W * LANE_W; BE_W = 1 gives a whole-word write.
//
// ---------------------------------------------------------------- sim-only fault models
//   FAULT_INJECT = 1 compiles the fault models of `SF_FT_* (used by the MBIST
//   coverage campaign and the ECC tests); FAULT_INJECT = 0 (default) removes them
//   completely: no logic, no ports used.  They model the classic memory fault
//   classes (stuck-at, transition, address-decoder, coupling) and a one-shot
//   soft-error bit flip (seu_*).  They are behavioural models of fault
//   CLASSES, not of any process.
// Classification: SYNTHESIZABLE (FAULT_INJECT = 0); SIMULATION-ONLY (FAULT_INJECT = 1)
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_core #(
  parameter int DEPTH        = 1024,
  parameter int DATA_W       = 128,
  parameter int BE_W         = DATA_W / 8,
  parameter int READ_LATENCY = 1,
  parameter int RDW          = `SF_RDW_READ_FIRST,
  parameter int SIM_INIT     = 2,
  parameter int TAG_W        = 1,
  parameter int FAULT_INJECT = 0,
  parameter int AW           = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int FBW          = (DATA_W > 1) ? $clog2(DATA_W) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,         // resets the result-valid pipeline ONLY
  input  wire logic              en,
  input  wire logic              we,
  input  wire logic [AW-1:0]     addr,
  input  wire logic [DATA_W-1:0] wdata,
  input  wire logic [BE_W-1:0]   be,
  input  wire logic [TAG_W-1:0]  tag_i,
  output logic                   rvalid,
  output logic                   rwe,
  output logic [TAG_W-1:0]       rtag,
  output logic [DATA_W-1:0]      rdata,
  // simulation-only fault injection (ignored when FAULT_INJECT = 0)
  input  wire logic [3:0]        fi_type,
  input  wire logic [AW-1:0]     fi_row,
  input  wire logic [AW-1:0]     fi_row2,
  input  wire logic [FBW-1:0]    fi_bit,
  input  wire logic [FBW-1:0]    fi_bit2,
  input  wire logic              fi_val,
  input  wire logic              fi_val2,
  input  wire logic              seu_pulse,     // one-shot soft error: XOR seu_mask into row seu_row
  input  wire logic [AW-1:0]     seu_row,
  input  wire logic [DATA_W-1:0] seu_mask
);
  localparam int LANE_W = DATA_W / BE_W;

  // ------------------------------------------------------------ parameter validation
  if (DEPTH < 2) begin : g_err_depth
    `SF_CFG_FATAL("sf_sram_core: DEPTH must be >= 2")
  end
  if (DATA_W < 1 || BE_W < 1 || (DATA_W % BE_W) != 0) begin : g_err_width
    `SF_CFG_FATAL("sf_sram_core: DATA_W must be a positive multiple of BE_W")
  end
  if (READ_LATENCY < 1) begin : g_err_latency
    `SF_CFG_FATAL("sf_sram_core: READ_LATENCY must be >= 1")
  end
  if (RDW < 0 || RDW > 2) begin : g_err_rdw
    `SF_CFG_FATAL("sf_sram_core: RDW must be 0 (READ_FIRST), 1 (WRITE_FIRST) or 2 (NO_CHANGE)")
  end
  if (SIM_INIT < 0 || SIM_INIT > 2) begin : g_err_siminit
    `SF_CFG_FATAL("sf_sram_core: SIM_INIT must be 0, 1 or 2")
  end
  if (TAG_W < 1) begin : g_err_tag
    `SF_CFG_FATAL("sf_sram_core: TAG_W must be >= 1")
  end

  localparam bit POW2 = ((DEPTH & (DEPTH - 1)) == 0);

  // ------------------------------------------------------------ storage
  logic [DATA_W-1:0] mem [0:DEPTH-1];
  logic [DATA_W-1:0] rd0;                 // stage 0: synchronous read / RDW register

`ifndef SYNTHESIS
  // simulation initial contents (never part of synthesis; the array has no reset)
  logic [31:0] init_pat;
  initial begin
    for (int i = 0; i < DEPTH; i++) begin
      init_pat = 32'hA5C3_0000 ^ (32'(i) * 32'h9E37_79B1);
      if (SIM_INIT == 1)      mem[i] = '0;
      else if (SIM_INIT == 2) mem[i] = DATA_W'({(DATA_W / 32 + 1){init_pat}});
    end
  end
`endif

  // compare in AW+1 bits: AW'(DEPTH) would wrap to 0 for a power-of-two DEPTH
  wire in_range = POW2 ? 1'b1 : ({1'b0, addr} < (AW+1)'(DEPTH));

  if (FAULT_INJECT == 0) begin : g_plain
    // --------------------------------------------------------- plain array (infers RAM)
    wire do_wr = en & we & in_range;
    always_ff @(posedge clk) begin
      if (do_wr) begin
        for (int l = 0; l < BE_W; l++)
          if (be[l]) mem[addr][l*LANE_W +: LANE_W] <= wdata[l*LANE_W +: LANE_W];
      end
      if (en) begin
        if (!in_range) begin
          rd0 <= '0;
        end else if (!we) begin
          rd0 <= mem[addr];
        end else if (RDW == `SF_RDW_READ_FIRST) begin
          rd0 <= mem[addr];
        end else if (RDW == `SF_RDW_WRITE_FIRST) begin
          for (int l = 0; l < BE_W; l++)
            rd0[l*LANE_W +: LANE_W] <= be[l] ? wdata[l*LANE_W +: LANE_W] : mem[addr][l*LANE_W +: LANE_W];
        end
        // RDW == NO_CHANGE: rd0 holds on a write cycle
      end
    end
    wire unused_fi = &{1'b0, fi_type, fi_row, fi_row2, fi_bit, fi_bit2, fi_val, fi_val2, seu_pulse, seu_row, seu_mask};
  end else begin : g_fault
    // --------------------------------------------------------- fault-injected array (simulation only)
    // Blocking semantics on purpose: a fault can touch a second row in the same edge.
    /* verilator lint_off BLKSEQ */
    function automatic logic [DATA_W-1:0] fview(input logic [AW-1:0] r, input logic [DATA_W-1:0] stored);
      logic [DATA_W-1:0] v;
      begin
        v = stored;
        if (fi_type == `SF_FT_SAF && r == fi_row) v[fi_bit] = fi_val;
        if (fi_type == `SF_FT_CFST && r == fi_row2 && mem[fi_row][fi_bit] == fi_val) v[fi_bit2] = fi_val2;
        fview = v;
      end
    endfunction

    logic [DATA_W-1:0] oldv, newv, rowv;
    logic [AW-1:0]     tgt;
    always @(posedge clk) begin : p_fault
      integer l;
      logic   tgt2_v;
      logic [AW-1:0] tgt2;
      if (seu_pulse && ({1'b0, seu_row} < (AW+1)'(DEPTH))) mem[seu_row] = mem[seu_row] ^ seu_mask;
      if (en && in_range) begin
        // ---- address-decoder mapping
        tgt = addr; tgt2_v = 1'b0; tgt2 = addr;
        if (fi_type == `SF_FT_AF_ALI && addr == fi_row) tgt = fi_row2;
        if (fi_type == `SF_FT_AF_MUL && addr == fi_row) begin tgt2_v = 1'b1; tgt2 = fi_row2; end
        if (we) begin
          if (!(fi_type == `SF_FT_AF_NA && addr == fi_row)) begin
            // ---- write to target row(s)
            for (int pass = 0; pass < 2; pass++) begin
              if (pass == 0 || tgt2_v) begin
                if (pass == 1) tgt = tgt2;
                oldv = mem[tgt]; newv = oldv;
                for (l = 0; l < BE_W; l++)
                  if (be[l]) newv[l*LANE_W +: LANE_W] = wdata[l*LANE_W +: LANE_W];
                // transition fault on the faulty cell
                if (fi_type == `SF_FT_TF && tgt == fi_row) begin
                  if (fi_val  && !oldv[fi_bit] &&  newv[fi_bit]) newv[fi_bit] = 1'b0;   // 0->1 blocked
                  if (!fi_val &&  oldv[fi_bit] && !newv[fi_bit]) newv[fi_bit] = 1'b1;   // 1->0 blocked
                end
                mem[tgt] = newv;
                // coupling: aggressor transition drives the victim
                if ((fi_type == `SF_FT_CFIN || fi_type == `SF_FT_CFID) && tgt == fi_row &&
                    oldv[fi_bit] != newv[fi_bit] && newv[fi_bit] == fi_val) begin
                  rowv = mem[fi_row2];
                  if (fi_type == `SF_FT_CFIN) rowv[fi_bit2] = ~rowv[fi_bit2];
                  else                        rowv[fi_bit2] = fi_val2;
                  mem[fi_row2] = rowv;
                end
              end
            end
          end
        end
        // ---- result register
        if (!we || RDW != `SF_RDW_NO_CHANGE) begin
          if (fi_type == `SF_FT_AF_NA && addr == fi_row)      rd0 <= '0;
          else if (fi_type == `SF_FT_AF_MUL && addr == fi_row && !(we && RDW == `SF_RDW_WRITE_FIRST))
                                                              rd0 <= fview(addr, mem[addr]) | fview(fi_row2, mem[fi_row2]);
          else if (we && RDW == `SF_RDW_READ_FIRST)           rd0 <= fview(tgt, oldv);
          else                                                rd0 <= fview(tgt, mem[tgt]);
        end
      end else if (en && !in_range) begin
        rd0 <= '0;
      end
    end
    /* verilator lint_on BLKSEQ */
  end

  // ------------------------------------------------------------ result pipeline
  logic [READ_LATENCY-1:0] vpipe, wpipe;
  logic [TAG_W-1:0]  tpipe [0:READ_LATENCY-1];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      vpipe <= '0; wpipe <= '0;
    end else begin
      vpipe[0] <= en;
      wpipe[0] <= we;
      for (int s = 1; s < READ_LATENCY; s++) begin vpipe[s] <= vpipe[s-1]; wpipe[s] <= wpipe[s-1]; end
    end
  end
  always_ff @(posedge clk) begin
    tpipe[0] <= tag_i;
    for (int s = 1; s < READ_LATENCY; s++) tpipe[s] <= tpipe[s-1];
  end

  if (READ_LATENCY == 1) begin : g_lat1
    assign rdata = rd0;
  end else begin : g_latn
    logic [DATA_W-1:0] dq [1:READ_LATENCY-1];     // stages after the read register
    always_ff @(posedge clk) begin
      dq[1] <= rd0;
      for (int s = 2; s < READ_LATENCY; s++) dq[s] <= dq[s-1];
    end
    assign rdata = dq[READ_LATENCY-1];
  end

  assign rvalid = vpipe[READ_LATENCY-1];
  assign rwe    = wpipe[READ_LATENCY-1];
  assign rtag   = tpipe[READ_LATENCY-1];

`ifdef SF_ASSERT
  // an enabled access must always see an in-range address (the controller guarantees it)
  always_ff @(posedge clk) if (rst_n && en && !in_range) $error("%m: access beyond DEPTH ignored");
`endif
endmodule

`default_nettype wire
