// =============================================================================
// SilicaFlux MemoryCore :: tb_vector_scratchpad
// sf_vector_scratchpad on a REAL sf_sram_controller (NB banks).  Expectations are computed INDEPENDENTLY of the DUT
// from a byte-accurate model at the moment a vector request is accepted (vector traffic and DMA traffic use disjoint
// address regions in the concurrent tests, so that instant is unambiguous):
//   * sub-word (1/2/4/8 B) and line (16 B) reads: right-justified, zero / sign extended;  writes: byte lanes only
//   * alignment rules (ALIGN_RULE 0 natural / 1 in-line) -> ST_ALIGN, no side effect;  unsupported size -> ST_ALIGN
//   * multi-line vectors (VEC_LINES 2 / 4): 32 B / 64 B aligned; a vector straddling the aperture end performs its
//     in-range lines and reports ST_RANGE
//   * DMA LOAD (stream -> SRAM) / STORE (SRAM -> stream): positive, zero, negative and gapped strides; beats beyond the
//     aperture are skipped with dma_err_o / ST_RANGE; stream backpressure on both directions
//   * concurrent DMA + vector traffic on the same banks: data integrity, conflict counter, DMA rate with/without contention
// RESULT line at the end.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_vector_scratchpad #(
  parameter int VEC_LINES = 1,
  parameter int ALIGN_RULE = 1,
  parameter int NB = 4,
  parameter int DEPTH = 64,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NSLOT = 8,
  parameter int NRAND = 2000,
  parameter int SEED = 32'hFACEFEED
);
  localparam int AW = 20, IDW = 4, LB = 4, LINE_W = 128;
  localparam int VEC_W = VEC_LINES * LINE_W;
  localparam int NPORT = VEC_LINES + 1;
  localparam int CAP_LINES = NB * DEPTH;
  localparam int CAP_BYTES = CAP_LINES * 16;
  localparam int R_ECC = $clog2(LINE_W + $clog2(LINE_W + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? LINE_W + R_ECC + 1 : LINE_W;
  localparam int BW = (NB > 1) ? $clog2(NB) : 1;
  localparam int ROW_W = $clog2(DEPTH);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT
  logic              v_req_valid = 1'b0, v_req_ready, v_req_we = 1'b0, v_req_sext = 1'b0, v_rsp_valid, v_rsp_ready = 1'b0, v_rsp_we;
  logic [AW-1:0]     v_req_addr = '0;
  logic [2:0]        v_req_size = '0, v_rsp_status;
  logic [VEC_W-1:0]  v_req_wdata = '0, v_rsp_rdata;
  logic [IDW-1:0]    v_req_id = '0, v_rsp_id;
  logic              dma_start = 1'b0, dma_dir = 1'b0, dma_busy, dma_done, dma_err, dma_in_valid = 1'b0, dma_in_ready, dma_out_valid, dma_out_ready = 1'b0;
  logic [AW-1:0]     dma_base = '0, dma_stride = '0;
  logic [15:0]       dma_len = '0, dma_beats;
  logic [2:0]        dma_err_code;
  logic [LINE_W-1:0] dma_in_data = '0, dma_out_data;
  logic              conflict_vec, conflict_dma;
  logic [15:0]       conflict_cnt;

  logic [NPORT-1:0]            c_req_valid, c_req_ready, c_req_we, c_rsp_valid, c_rsp_ready, c_rsp_we, c_rsp_ce;
  logic [NPORT*AW-1:0]         c_req_addr;
  logic [NPORT*LINE_W-1:0]     c_req_wdata, c_rsp_rdata;
  logic [NPORT*(LINE_W/8)-1:0] c_req_be;
  logic [NPORT*3-1:0]          c_rsp_status;
  logic [NPORT-1:0]            c_rsp_id_unused;
  logic [NPORT*1-1:0]          c_rsp_id;
  logic                        c_idle;
  logic [NB*STORE_W-1:0]       tst_rdata;
  logic [NB*32-1:0]            perf_acc, perf_conf, perf_busy;

  sf_vector_scratchpad #(.AW(AW), .IDW(IDW), .NB(NB), .CAP_LINES(CAP_LINES), .VEC_LINES(VEC_LINES), .ALIGN_RULE(ALIGN_RULE),
                         .DMA_OUT(NSLOT), .META_DEPTH(NSLOT)) dut (
    .clk(clk), .rst_n(rst_n),
    .v_req_valid(v_req_valid), .v_req_ready(v_req_ready), .v_req_we(v_req_we), .v_req_addr(v_req_addr), .v_req_size(v_req_size),
    .v_req_sext(v_req_sext), .v_req_wdata(v_req_wdata), .v_req_id(v_req_id),
    .v_rsp_valid(v_rsp_valid), .v_rsp_ready(v_rsp_ready), .v_rsp_rdata(v_rsp_rdata), .v_rsp_id(v_rsp_id), .v_rsp_we(v_rsp_we), .v_rsp_status(v_rsp_status),
    .dma_start_i(dma_start), .dma_dir_i(dma_dir), .dma_base_i(dma_base), .dma_len_i(dma_len), .dma_stride_i(dma_stride),
    .dma_busy_o(dma_busy), .dma_done_o(dma_done), .dma_err_o(dma_err), .dma_err_code_o(dma_err_code), .dma_beats_o(dma_beats),
    .dma_in_valid(dma_in_valid), .dma_in_ready(dma_in_ready), .dma_in_data(dma_in_data),
    .dma_out_valid(dma_out_valid), .dma_out_ready(dma_out_ready), .dma_out_data(dma_out_data),
    .conflict_vec_o(conflict_vec), .conflict_dma_o(conflict_dma), .conflict_cnt_o(conflict_cnt),
    .c_req_valid(c_req_valid), .c_req_ready(c_req_ready), .c_req_we(c_req_we), .c_req_addr(c_req_addr), .c_req_wdata(c_req_wdata),
    .c_req_be(c_req_be), .c_rsp_valid(c_rsp_valid), .c_rsp_ready(c_rsp_ready), .c_rsp_rdata(c_rsp_rdata), .c_rsp_status(c_rsp_status));

  sf_sram_controller #(.NM(NPORT), .NB(NB), .DEPTH(DEPTH), .DW(LINE_W), .AW(AW), .IDW(1), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
                       .NSLOT(NSLOT), .INIT_ON_RESET(1), .SIM_INIT(2)) ctl (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(c_req_valid), .m_req_ready(c_req_ready), .m_req_we(c_req_we), .m_req_addr(c_req_addr), .m_req_wdata(c_req_wdata),
    .m_req_be(c_req_be), .m_req_id({NPORT{1'b0}}),
    .m_rsp_valid(c_rsp_valid), .m_rsp_ready(c_rsp_ready), .m_rsp_rdata(c_rsp_rdata), .m_rsp_id(c_rsp_id), .m_rsp_we(c_rsp_we),
    .m_rsp_status(c_rsp_status), .m_rsp_ce(c_rsp_ce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(1'b0), .idle_o(c_idle), .init_start_i(1'b0), .init_busy_o(), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(), .ev_ue_o(), .ce_cnt_o(), .ue_cnt_o(), .perf_acc_o(perf_acc), .perf_conf_o(perf_conf),
    .perf_busy_o(perf_busy), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0), .tst_rdata_o(tst_rdata),
    .fi_bank('0), .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  // ---------------------------------------------------------------- model + bookkeeping
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int rndn(input int n); logic [31:0] r; r = rnd(); return int'(r % 32'(n)); endfunction

  byte unsigned ref_mem [CAP_BYTES];
  typedef struct { logic [IDW-1:0] id; logic we; logic [2:0] st; logic [VEC_W-1:0] data; } vexp_t;
  localparam int VQ = 4096;
  vexp_t va [VQ];
  int vh = 0, vt = 0;
  logic [AW-1:0] ea_q [VQ];                   // independently computed DMA beat addresses: base + k*stride (checked at acceptance)
  int eah = 0, eat = 0;
  logic [LINE_W-1:0] oa [VQ];                 // DMA STORE stream expectations
  int oh = 0, ot = 0;
  int n_checks = 0, n_err = 0, n_vreq = 0, n_vrsp = 0, dma_accepted = 0;
  int rsp_pct = 100, out_pct = 100;
  string cur = "";
  longint cycle = 0;
  task automatic fail(input string m); n_err++; if (n_err <= 25) $display("  [FAIL] %s @cycle %0d (%s)", m, cycle, cur); endtask
  task automatic check(input bit c, input string m); n_checks++; if (!c) fail(m); endtask

  function automatic int size_bytes(input int sz); return (sz <= 4) ? (1 << sz) : (16 << (sz - 4)); endfunction

  // independent expectation of one vector request at acceptance; also applies its side effects to the model
  function automatic vexp_t predict(input logic [AW-1:0] a, input logic we, input logic [2:0] sz, input logic sext, input logic [VEC_W-1:0] wd, input logic [IDW-1:0] id);
    vexp_t e;
    int nb, nl, off, line0;
    bit ok, multi;
    e.id = id; e.we = we; e.st = `SF_ST_OK; e.data = '0;
    nb = (sz <= 6) ? size_bytes(int'(sz)) : 0;
    multi = (sz >= 5);
    nl = multi ? (nb / 16) : 1;
    off = int'(a & AW'(15));
    ok = (sz <= 6) && (nl <= VEC_LINES);
    if (ok) begin
      if (multi || sz == 4) ok = ((a & AW'(nb - 1)) == '0);
      else if (ALIGN_RULE == 0) ok = ((a & AW'(nb - 1)) == '0);
      else ok = (off + nb <= 16);
    end
    if (!ok) begin e.st = `SF_ST_ALIGN; return e; end
    if (!multi) begin
      line0 = int'(a >> LB);
      if (line0 >= CAP_LINES) begin e.st = `SF_ST_RANGE; return e; end
      if (we) begin
        for (int b = 0; b < nb; b++) ref_mem[line0 * 16 + off + b] = wd[b*8 +: 8];
      end else begin
        for (int b = 0; b < nb; b++) e.data[b*8 +: 8] = ref_mem[line0 * 16 + off + b];
        if (sext && nb < VEC_W / 8) for (int b = nb; b < VEC_W / 8; b++) e.data[b*8 +: 8] = {8{e.data[nb*8 - 1]}};
      end
    end else begin
      for (int l = 0; l < nl; l++) begin
        line0 = int'(a >> LB) + l;
        if (line0 >= CAP_LINES) begin if (e.st == `SF_ST_OK) e.st = `SF_ST_RANGE; end
        else if (we) for (int b = 0; b < 16; b++) ref_mem[line0 * 16 + b] = wd[l*128 + b*8 +: 8];
        else         for (int b = 0; b < 16; b++) e.data[l*128 + b*8 +: 8] = ref_mem[line0 * 16 + b];
      end
      if (e.st != `SF_ST_OK) e.data = '0;
    end
    return e;
  endfunction

  // ---- monitors
  always @(posedge clk) begin
    cycle <= cycle + 1;
    if (rst_n) begin
      if (v_req_valid && v_req_ready) begin
        vexp_t e;
        e = predict(v_req_addr, v_req_we, v_req_size, v_req_sext, v_req_wdata, v_req_id);
        va[vt % VQ] = e; vt = vt + 1; n_vreq++;
      end
      if (v_rsp_valid && v_rsp_ready) begin
        n_vrsp++;
        if (vt == vh) fail("vector response with nothing outstanding");
        else begin
          vexp_t e;
          e = va[vh % VQ]; vh = vh + 1;
          check(v_rsp_id == e.id, $sformatf("vector rsp id %0d != %0d", v_rsp_id, e.id));
          check(v_rsp_we == e.we, "vector rsp we");
          check(v_rsp_status == e.st, $sformatf("vector rsp status %0d != %0d", v_rsp_status, e.st));
          check(v_rsp_rdata == e.data, $sformatf("vector rsp data %h != %h", v_rsp_rdata, e.data));
        end
      end
      // DMA port acceptance -> model (DMA region is disjoint from vector traffic in concurrent tests)
      if (c_req_valid[VEC_LINES] && c_req_ready[VEC_LINES]) begin
        int ln;
        ln = int'(c_req_addr[VEC_LINES*AW +: AW] >> LB);
        dma_accepted++;
        if (eah == eat) fail("DMA beat accepted that was not programmed");
        else begin
          check(c_req_addr[VEC_LINES*AW +: AW] == ea_q[eah % VQ], $sformatf("DMA beat %0d address %h != programmed %h (base + k*stride)", eah, c_req_addr[VEC_LINES*AW +: AW], ea_q[eah % VQ]));
          eah++;
        end
        if (ln < CAP_LINES) begin
          if (c_req_we[VEC_LINES]) for (int b = 0; b < 16; b++) ref_mem[ln * 16 + b] = c_req_wdata[VEC_LINES*LINE_W + b*8 +: 8];
          else begin
            logic [LINE_W-1:0] d;
            for (int b = 0; b < 16; b++) d[b*8 +: 8] = ref_mem[ln * 16 + b];
            oa[ot % VQ] = d; ot = ot + 1;
          end
        end else if (!c_req_we[VEC_LINES]) begin oa[ot % VQ] = '0; ot = ot + 1; end   // out-of-range read: error beat, data 0
      end
      if (dma_out_valid && dma_out_ready) begin
        if (oh == ot) fail("DMA STORE: stream beat with no expectation");
        else begin
          check(dma_out_data == oa[oh % VQ], $sformatf("DMA STORE beat %0d: %h != %h", oh, dma_out_data, oa[oh % VQ]));
          oh = oh + 1;
        end
      end
    end
  end

  // ---- vector driver (queue of requests as circular buffer) and ready generators
  typedef struct { logic [AW-1:0] a; logic we; logic [2:0] sz; logic sext; logic [VEC_W-1:0] wd; logic [IDW-1:0] id; int delay; } vstim_t;
  vstim_t sa [VQ];
  int sh = 0, st_ = 0, vdly = 0;
  always @(posedge clk) begin
    if (!rst_n) v_req_valid <= 1'b0;
    else begin
      logic accepted;
      accepted = v_req_valid && v_req_ready;
      if (accepted) v_req_valid <= 1'b0;
      if ((!v_req_valid || accepted) && st_ > sh) begin
        if (vdly >= sa[sh % VQ].delay) begin
          vstim_t s;
          s = sa[sh % VQ]; sh = sh + 1; vdly = 0;
          v_req_valid <= 1'b1; v_req_addr <= s.a; v_req_we <= s.we; v_req_size <= s.sz; v_req_sext <= s.sext; v_req_wdata <= s.wd; v_req_id <= s.id;
        end else vdly = vdly + 1;
      end
    end
    v_rsp_ready <= (rndn(100) < rsp_pct);
    dma_out_ready <= (rndn(100) < out_pct);
  end

  logic [IDW-1:0] nid = '0;
  task automatic vput(input logic [AW-1:0] a, input logic we, input int sz, input logic sext, input logic [VEC_W-1:0] wd, input int delay = 0);
    vstim_t s;
    s.a = a; s.we = we; s.sz = 3'(sz); s.sext = sext; s.wd = wd; s.id = nid; s.delay = delay; nid = nid + 1'b1;
    sa[st_ % VQ] = s; st_ = st_ + 1;
  endtask
  function automatic logic [VEC_W-1:0] mkdata(); logic [VEC_W-1:0] d; for (int w = 0; w < VEC_W / 32; w++) d[w*32 +: 32] = rnd(); return d; endfunction

  // ---- DMA helpers: stream source with its own queue
  logic [LINE_W-1:0] da [VQ];
  int dah = 0, dat = 0;
  int in_pct = 100;
  always @(posedge clk) begin
    if (!rst_n) dma_in_valid <= 1'b0;
    else begin
      if (dma_in_valid && dma_in_ready) dma_in_valid <= 1'b0;
      if ((!dma_in_valid || dma_in_ready) && dat > dah && rndn(100) < in_pct) begin
        dma_in_valid <= 1'b1; dma_in_data <= da[dah % VQ]; dah = dah + 1;
      end
    end
  end
  task automatic dma_run(input bit dir, input logic [AW-1:0] base, input int len, input logic [AW-1:0] stride, output int cycles);
    longint c0;
    dma_dir = dir; dma_base = base; dma_len = 16'(len); dma_stride = stride;
    for (int k = 0; k < len; k++) begin ea_q[eat % VQ] = base + AW'(k) * stride; eat++; end
    c0 = cycle;
    @(negedge clk); dma_start = 1'b1; @(negedge clk); dma_start = 1'b0;
    repeat (2) @(posedge clk);
    while (dma_busy) @(posedge clk);
    cycles = int'(cycle - c0);
    repeat (3) @(posedge clk);
  endtask

  task automatic drain(input int maxc = 200000);
    int n; bit busy;
    n = 0;
    do begin
      @(posedge clk); n++;
      busy = (vt != vh) || (st_ != sh) || v_req_valid || dma_busy || !c_idle || (ot != oh) || (dat != dah) || (eah != eat);
    end while (busy && n < maxc);
    if (busy) fail("drain timeout");
    repeat (3) @(posedge clk);
  endtask

  task automatic begin_phase(input string s); cur = s; $display("[%0t] %s", $time, s); endtask
  int e0, cyc, k, ln0;
  logic [AW-1:0] ad;

  initial begin
    for (int i = 0; i < CAP_BYTES; i++) ref_mem[i] = 8'h00;
    repeat (6) @(posedge clk); rst_n = 1'b1;
    repeat (CAP_LINES / NB + 12) @(posedge clk); while (!c_idle) @(posedge clk);
    $display("CONFIG VEC_LINES=%0d ALIGN_RULE=%0d NB=%0d DEPTH=%0d READ_LATENCY=%0d ECC_EN=%0d NSLOT=%0d", VEC_LINES, ALIGN_RULE, NB, DEPTH, READ_LATENCY, ECC_EN, NSLOT);

    // ---- V1 sub-word and line accesses at every legal offset; zero and sign extension
    begin_phase("V1 sub-word / line reads and writes, every size and offset, zero + sign extension"); e0 = n_err; rsp_pct = 100;
    for (int sz = 0; sz <= 4; sz++) begin
      int nb;
      nb = 1 << sz;
      for (int off = 0; off < 16; off++) begin
        ad = AW'(16 * 9 + off);
        vput(AW'(16 * 9), 1'b1, 4, 1'b0, '0);                           // clear the line
        vput(ad, 1'b1, sz, 1'b0, mkdata());
        vput(ad, 1'b0, sz, 1'b0, '0);
        vput(ad, 1'b0, sz, 1'b1, '0);                                    // sign extended
        vput(AW'(16 * 9), 1'b0, 4, 1'b0, '0);                            // whole line shows exactly the written bytes
      end
    end
    drain(); $display("    V1 %s", (n_err == e0) ? "PASS" : "FAIL");

    // ---- V2 alignment violations: no side effect
    begin_phase("V2 alignment / size violations -> ST_ALIGN, no side effect"); e0 = n_err;
    vput(AW'(16 * 20), 1'b1, 4, 1'b0, '0);
    for (int sz = 1; sz <= 4; sz++)
      for (int off = 1; off < 16; off++) begin
        vput(AW'(16 * 20 + off), 1'b1, sz, 1'b0, {VEC_W{1'b1}});        // natural: misaligned; in-line: only line-crossing ones fail
        vput(AW'(16 * 20 + off), 1'b0, sz, 1'b0, '0);
      end
    vput(AW'(16 * 20), 1'b1, 3'd7, 1'b0, {VEC_W{1'b1}});                  // unsupported size code 7
    if (VEC_LINES < 4) vput(AW'(16 * 24), 1'b1, 6, 1'b0, {VEC_W{1'b1}});  // 64 B vector on a narrower scratchpad
    if (VEC_LINES < 2) vput(AW'(16 * 24), 1'b0, 5, 1'b0, '0);
    vput(AW'(16 * 20), 1'b0, 4, 1'b0, '0);
    drain(); $display("    V2 %s", (n_err == e0) ? "PASS" : "FAIL");

    // ---- V3 multi-line vectors
    if (VEC_LINES >= 2) begin
      begin_phase("V3 multi-line vectors (parallel banks), aperture end, misalignment"); e0 = n_err;
      for (int n = 0; n < 40; n++) begin
        int base_l;
        base_l = (rndn((CAP_LINES - 4) / 4)) * 4;
        vput(AW'(base_l * 16), 1'b1, (VEC_LINES >= 4 && rndn(2) == 0) ? 6 : 5, 1'b0, mkdata());
        vput(AW'(base_l * 16), 1'b0, (VEC_LINES >= 4 && rndn(2) == 0) ? 6 : 5, 1'b0, '0);
        vput(AW'(base_l * 16), 1'b0, 4, 1'b0, '0);
      end
      vput(AW'((CAP_LINES - 1) * 16), 1'b1, 5, 1'b0, mkdata());           // straddles the aperture end: line 0 written, RANGE
      vput(AW'((CAP_LINES - 1) * 16), 1'b0, 5, 1'b0, '0);
      vput(AW'(16 * 4 + 16), 1'b1, 5, 1'b0, mkdata());                    // 32 B vector at a 16 B boundary: misaligned
      drain(); $display("    V3 %s", (n_err == e0) ? "PASS" : "FAIL");
    end

    // ---- V4 DMA LOAD with several strides, out-of-range beats, stream gaps
    begin_phase("V4 DMA LOAD (stride 16 / 32 / 0 / negative), out-of-range beats skipped, stream gaps"); e0 = n_err; in_pct = 60;
    for (int t = 0; t < 4; t++) begin
      int len, stride_b, base_ln;
      len = 24; base_ln = 40;
      case (t)
        0: stride_b = 16;
        1: stride_b = 32;
        2: stride_b = 0;
        default: begin stride_b = -16; base_ln = 100; end
      endcase
      for (int b = 0; b < len; b++) begin da[dat % VQ] = {rnd(), rnd(), rnd(), rnd()}; dat = dat + 1; end
      dma_run(1'b0, AW'(base_ln * 16), len, AW'(stride_b), cyc);
      check(!dma_err, "DMA LOAD in range reported an error");
      check(dma_beats == 16'(len), $sformatf("DMA LOAD beats %0d != %0d", dma_beats, len));
      for (int b = 0; b < len; b += 5) vput(AW'((base_ln + (stride_b / 16) * b) * 16), 1'b0, 4, 1'b0, '0);
      drain();
    end
    for (int b = 0; b < 8; b++) begin da[dat % VQ] = {rnd(), rnd(), rnd(), rnd()}; dat = dat + 1; end
    dma_run(1'b0, AW'((CAP_LINES - 4) * 16), 8, AW'(16), cyc);            // last 4 beats run off the end of the aperture
    check(dma_err && dma_err_code == `SF_ST_RANGE, $sformatf("DMA beyond the aperture: err=%b code=%0d", dma_err, dma_err_code));
    check(dma_beats == 16'd8, "DMA with errors must still complete all beats");
    vput(AW'((CAP_LINES - 4) * 16), 1'b0, 4, 1'b0, '0); vput(AW'((CAP_LINES - 1) * 16), 1'b0, 4, 1'b0, '0);
    drain(); in_pct = 100; $display("    V4 %s", (n_err == e0) ? "PASS" : "FAIL");

    // ---- V5 DMA STORE with stream backpressure
    begin_phase("V5 DMA STORE (scratchpad -> stream) with stream backpressure"); e0 = n_err;
    for (int p = 0; p < 2; p++) begin
      out_pct = (p == 0) ? 100 : 15;
      dma_run(1'b1, AW'(40 * 16), 24, AW'(16), cyc);
      drain();
      check(oh == ot, "DMA STORE: not every expected beat was delivered");
    end
    dma_run(1'b1, AW'((CAP_LINES - 2) * 16), 5, AW'(16), cyc);            // reads run off the end: zero beats + RANGE
    drain();
    check(dma_err && dma_err_code == `SF_ST_RANGE, "DMA STORE beyond the aperture must flag RANGE");
    out_pct = 100; $display("    V5 %s", (n_err == e0) ? "PASS" : "FAIL");

    // ---- V6 concurrent DMA + vector traffic on the SAME banks (disjoint addresses)
    begin_phase("V6 concurrent DMA LOAD + vector traffic on shared banks: integrity, conflicts, DMA rate"); e0 = n_err; rsp_pct = 100;
    begin
      int cyc_alone, cyc_busy; int c0cnt; int n;
      n = 64;
      for (int b = 0; b < n; b++) begin da[dat % VQ] = {rnd(), rnd(), rnd(), rnd()}; dat = dat + 1; end
      dma_run(1'b0, AW'(128 * 16), n, AW'(16), cyc_alone);
      drain();
      c0cnt = int'(conflict_cnt);
      for (int b = 0; b < n; b++) begin da[dat % VQ] = {rnd(), rnd(), rnd(), rnd()}; dat = dat + 1; end
      for (int v = 0; v < 120; v++)                                        // vector traffic in lines 0..127 (DMA uses 128..191)
        vput(AW'(((v * 4 + 0) % 128) * 16 + rndn(16)), rndn(3) == 0, rndn(3), rndn(2) == 0, mkdata());
      dma_run(1'b0, AW'(128 * 16), n, AW'(16), cyc_busy);
      drain();
      $display("    DMA LOAD of %0d beats: %0d cycles alone, %0d cycles with concurrent vector traffic; bank conflicts seen by the scratchpad: %0d",
               n, cyc_alone, cyc_busy, int'(conflict_cnt) - c0cnt);
      check(int'(conflict_cnt) > c0cnt, "no DMA/vector bank conflict recorded although both hit the same banks");
    end
    $display("    V6 %s", (n_err == e0) ? "PASS" : "FAIL");

    // ---- V7 randomized vector traffic with backpressure
    begin_phase("V7 randomized vector traffic (all sizes, strobes, sign extension, backpressure)"); e0 = n_err;
    for (int pass = 0; pass < 3; pass++) begin
      rsp_pct = (pass == 0) ? 100 : (pass == 1) ? 35 : 8;
      for (int n = 0; n < NRAND / 3; n++) begin
        int sz; logic [AW-1:0] a;
        sz = (VEC_LINES > 1 && rndn(8) == 0) ? 5 + rndn(VEC_LINES >= 4 ? 2 : 1) : rndn(5);
        a = AW'(rndn(CAP_LINES) * 16 + rndn(16));
        if (rndn(100) < 4) a = AW'(CAP_BYTES + rndn(256));                // out of range
        vput(a, rndn(2) == 0, sz, rndn(2) == 0, mkdata(), rndn(5) == 0 ? rndn(3) : 0);
      end
      drain();
    end
    rsp_pct = 100;
    $display("    V7 %s", (n_err == e0) ? "PASS" : "FAIL");

    check(n_vreq == n_vrsp, $sformatf("vector conservation: %0d requests, %0d responses", n_vreq, n_vrsp));
    $display("RESULT tb=vector_scratchpad VEC_LINES=%0d ALIGN_RULE=%0d NB=%0d READ_LATENCY=%0d ECC_EN=%0d vector_requests=%0d dma_beats_accepted=%0d checks=%0d errors=%0d %s",
             VEC_LINES, ALIGN_RULE, NB, READ_LATENCY, ECC_EN, n_vreq, dma_accepted, n_checks, n_err, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #(64'd900_000_000);
    $display("RESULT tb=vector_scratchpad errors=1 WATCHDOG TIMEOUT FAIL");
    $finish;
  end
endmodule
