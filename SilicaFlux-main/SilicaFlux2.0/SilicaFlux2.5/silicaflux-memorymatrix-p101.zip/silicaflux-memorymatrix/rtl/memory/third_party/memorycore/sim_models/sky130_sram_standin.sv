// =============================================================================
// FUNCTIONAL STAND-IN for  sky130_sram_1kbyte_1rw1r_32x256_8   -- SIMULATION ONLY
// Written from the SilicaFlux SRAM library manifest (port list, polarities, "dout not held,
// sample one cycle after the read"), NOT copied from the vendor model and NOT a substitute for it.
// Replace with the vendor Verilog model (efabless/sky130_sram_macros, pinned commit in the manifest)
// for any sign-off or gate-level simulation.  Timing here: input registered at the rising edge,
// dout0 updated after the following falling edge, X from T_HOLD after every rising edge
// (documented OpenRAM behaviour) -- so a consumer that does not capture exactly one cycle later
// reads X in 4-state simulators.
// =============================================================================
`timescale 1ns/1ps
module sky130_sram_1kbyte_1rw1r_32x256_8 #(
  parameter NUM_WMASKS = 4, parameter DATA_WIDTH = 32, parameter ADDR_WIDTH = 8, parameter RAM_DEPTH = 256
) (
  input  wire                    clk0, csb0, web0,
  input  wire [NUM_WMASKS-1:0]   wmask0,
  input  wire [ADDR_WIDTH-1:0]   addr0,
  input  wire [DATA_WIDTH-1:0]   din0,
  output reg  [DATA_WIDTH-1:0]   dout0,
  input  wire                    clk1, csb1,
  input  wire [ADDR_WIDTH-1:0]   addr1,
  output reg  [DATA_WIDTH-1:0]   dout1
);
  reg [DATA_WIDTH-1:0] mem [0:RAM_DEPTH-1];
  reg                  csb0_q, web0_q;
  reg [NUM_WMASKS-1:0] wmask0_q;
  reg [ADDR_WIDTH-1:0] addr0_q;
  reg [DATA_WIDTH-1:0] din0_q;
  integer i;
  initial for (i = 0; i < RAM_DEPTH; i = i + 1) mem[i] = {DATA_WIDTH{1'bx}};
  initial dout1 = {DATA_WIDTH{1'bx}};

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ports = &{1'b0, clk1, csb1, addr1, wmask0_q, din0_q};
  /* verilator lint_on UNUSEDSIGNAL */
  // single block sensitive to both edges: dout0 has exactly one driver
  always @(clk0) begin
    if (clk0) begin                                       // rising edge
      csb0_q <= csb0; web0_q <= web0; wmask0_q <= wmask0; addr0_q <= addr0; din0_q <= din0;
      if (!csb0) begin
        if (!web0) begin
          for (i = 0; i < NUM_WMASKS; i = i + 1)
            if (wmask0[i]) mem[addr0][i*8 +: 8] <= din0[i*8 +: 8];
        end
        dout0 <= {DATA_WIDTH{1'bx}};                      // X after every rising edge (not held)
      end
    end else begin                                        // falling edge
      if (!csb0_q && web0_q) dout0 <= mem[addr0_q];       // updated after the falling edge of a read cycle
    end
  end
endmodule
