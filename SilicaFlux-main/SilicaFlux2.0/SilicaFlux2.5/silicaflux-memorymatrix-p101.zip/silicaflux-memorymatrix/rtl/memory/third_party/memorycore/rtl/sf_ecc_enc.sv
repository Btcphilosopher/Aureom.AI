// =============================================================================
// SilicaFlux MemoryCore :: sf_ecc_enc -- SECDED encoder (wrapper over third_party/ras_secded sfras_secded_enc,
// default check-bit inversion: an all-zero stored word decodes as UNCORRECTABLE).  See docs/ECC.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ecc_enc #(
  parameter int K   = 128,
  parameter int R   = $clog2(K + $clog2(K + 1) + 1),
  parameter int N   = K + R + 1
) (
  input  wire logic [K-1:0] data_i,
  output logic      [N-1:0] cw_o
);
  /* verilator lint_off VARHIDDEN */
  `include "sfras_ecc_funcs.svh"
  /* verilator lint_on VARHIDDEN */
  localparam int INV = sfras_ecc_default_inv(K);
  sfras_secded_enc #(.K(K), .INV(INV)) u_enc (.data_i(data_i), .cw_o(cw_o));
endmodule

`default_nettype wire
