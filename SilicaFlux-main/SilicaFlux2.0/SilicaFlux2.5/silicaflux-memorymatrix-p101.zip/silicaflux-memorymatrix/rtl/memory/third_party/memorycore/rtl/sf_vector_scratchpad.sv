// =============================================================================
// SilicaFlux MemoryCore :: sf_vector_scratchpad
// Vector / scalar-subword front end and burst DMA engine for the banked SRAM controller.
// It owns VEC_LINES + 1 controller master ports: ports 0..VEC_LINES-1 carry the vector lines, port VEC_LINES the DMA.
//
// ---------------------------------------------------------------- vector port
//   v_req: {we, addr (byte), size, sext, wdata (VEC_W bits), id}.  size encodes the access width:
//       0:1 B  1:2 B  2:4 B  3:8 B  4:16 B (one line)  5:32 B  6:64 B  (multi-line: 2 / 4 lines, needs VEC_LINES >= 2 / 4)
//   * sub-line accesses (size <= 3) use byte enables inside one 128-bit line; a read returns the value RIGHT-JUSTIFIED in
//     rdata (zero- or sign-extended per sext); a write takes its data from wdata[8*N-1:0].
//   * multi-line accesses (size >= 4) occupy 2^(size-4) consecutive lines, line i on controller port i.  Consecutive lines
//     rotate through the banks, so with NB >= lines they hit distinct banks and issue in the SAME cycle.
//   Alignment rule (ALIGN_RULE, configurable):
//     0 NATURAL   addr must be a multiple of the access size                      (else status SF_ST_ALIGN)
//     1 IN-LINE   a sub-line access may start at any byte but must not cross a 16 B line; multi-line accesses must be
//                 size aligned                                                   (else SF_ST_ALIGN)
//   A rejected request is not sent to the SRAM; its response still arrives in order, with the error status and rdata 0.
//   (Implemented by redirecting it to an out-of-aperture address: the controller answers SF_ST_RANGE, mapped to SF_ST_ALIGN
//   here by the per-port metadata FIFO, so ordering is preserved and no array access happens.)
//   Responses return in request order (the controller's per-port in-order contract).
//
// ---------------------------------------------------------------- bank-conflict detection
//   conflict_vec_o   pulse: the accepted multi-line vector maps two of its lines to one bank (lines > NB)
//   conflict_dma_o   pulse: in one cycle a vector line and the DMA both present a request to the SAME bank (they will be
//                    serialised by the bank arbiter); conflict_cnt_o counts both kinds.
//
// ---------------------------------------------------------------- burst DMA (independent address generation)
//   dma_start_i with dma_dir_i / dma_base_i (line aligned byte address) / dma_len_i (beats, 1..65535) / dma_stride_i (bytes,
//   multiple of 16, may be 0 or negative as two's complement): the DMA address generator produces base + i*stride with NO
//   involvement of the vector port, so scalar/vector traffic and DMA run concurrently and are arbitrated per bank.
//     dir 0 LOAD  : stream (dma_in_*) -> scratchpad, one 128-bit beat per line, full byte enables
//     dir 1 STORE : scratchpad -> stream (dma_out_*)
//   dma_busy_o until the last response is back; dma_done_o pulses; dma_err_o (sticky until the next start) with
//   dma_err_code_o = first error status (e.g. SF_ST_RANGE: a beat outside the aperture; it is skipped and the burst continues).
//   Outstanding beats are bounded by DMA_OUT (controller slots); STORE staging is credit based, so the stream backpressure
//   never reaches the controller.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_vector_scratchpad #(
  parameter int AW         = 32,
  parameter int IDW        = 4,
  parameter int NB         = 4,            // banks of the controller (for conflict detection)
  parameter int CAP_LINES  = 1024,         // aperture size in lines (= controller NB*DEPTH); rejects go beyond it
  parameter int VEC_LINES  = 1,            // 1, 2 or 4 -> VEC_W = 128 / 256 / 512
  parameter int ALIGN_RULE = 1,
  parameter int DMA_OUT    = 8,            // max DMA beats in flight (<= controller NSLOT)
  parameter int META_DEPTH = 8,            // max vector requests in flight (<= controller NSLOT)
  parameter int LINE_W     = 128,
  parameter int CNT_W      = 16,
  parameter int VEC_W      = VEC_LINES * LINE_W,
  parameter int NPORT      = VEC_LINES + 1,
  parameter int PW         = $clog2(DMA_OUT + 1)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------------- vector request / response
  input  wire logic                   v_req_valid,
  output logic                        v_req_ready,
  input  wire logic                   v_req_we,
  input  wire logic [AW-1:0]          v_req_addr,
  input  wire logic [2:0]             v_req_size,
  input  wire logic                   v_req_sext,
  input  wire logic [VEC_W-1:0]       v_req_wdata,
  input  wire logic [IDW-1:0]         v_req_id,
  output logic                        v_rsp_valid,
  input  wire logic                   v_rsp_ready,
  output logic [VEC_W-1:0]            v_rsp_rdata,
  output logic [IDW-1:0]              v_rsp_id,
  output logic                        v_rsp_we,
  output logic [2:0]                  v_rsp_status,
  // ---------------------------------------------------------------- DMA
  input  wire logic                   dma_start_i,
  input  wire logic                   dma_dir_i,         // 0 load (stream -> SRAM), 1 store (SRAM -> stream)
  input  wire logic [AW-1:0]          dma_base_i,
  input  wire logic [15:0]            dma_len_i,
  input  wire logic [AW-1:0]          dma_stride_i,
  output logic                        dma_busy_o,
  output logic                        dma_done_o,
  output logic                        dma_err_o,
  output logic [2:0]                  dma_err_code_o,
  output logic [15:0]                 dma_beats_o,       // beats completed so far
  input  wire logic                   dma_in_valid,
  output logic                        dma_in_ready,
  input  wire logic [LINE_W-1:0]      dma_in_data,
  output logic                        dma_out_valid,
  input  wire logic                   dma_out_ready,
  output logic [LINE_W-1:0]           dma_out_data,
  // ---------------------------------------------------------------- conflict reporting
  output logic                        conflict_vec_o,
  output logic                        conflict_dma_o,
  output logic [CNT_W-1:0]            conflict_cnt_o,
  // ---------------------------------------------------------------- controller master ports (NPORT)
  output logic [NPORT-1:0]            c_req_valid,
  input  wire logic [NPORT-1:0]       c_req_ready,
  output logic [NPORT-1:0]            c_req_we,
  output logic [NPORT*AW-1:0]         c_req_addr,
  output logic [NPORT*LINE_W-1:0]     c_req_wdata,
  output logic [NPORT*(LINE_W/8)-1:0] c_req_be,
  input  wire logic [NPORT-1:0]       c_rsp_valid,
  output logic [NPORT-1:0]            c_rsp_ready,
  input  wire logic [NPORT*LINE_W-1:0] c_rsp_rdata,
  input  wire logic [NPORT*3-1:0]     c_rsp_status
);
  localparam int LB = 4;                        // 16-byte lines
  localparam int BEW = LINE_W / 8;
  localparam logic [AW-1:0] REJECT_ADDR = {{(AW-LB){1'b1}}, {LB{1'b0}}};   // top of the address space, line aligned

  if (VEC_LINES != 1 && VEC_LINES != 2 && VEC_LINES != 4) begin : g_err_vl
    `SF_CFG_FATAL("sf_vector_scratchpad: VEC_LINES must be 1, 2 or 4")
  end
  if (ALIGN_RULE != 0 && ALIGN_RULE != 1) begin : g_err_ar
    `SF_CFG_FATAL("sf_vector_scratchpad: ALIGN_RULE must be 0 (natural) or 1 (in-line); cross-line splitting is not implemented")
  end
  if (CAP_LINES >= (1 << (AW - LB))) begin : g_err_cap
    `SF_CFG_FATAL("sf_vector_scratchpad: the aperture must be smaller than the address space (rejects are redirected beyond it)")
  end

  // ------------------------------------------------------------ vector request decode
  logic [4:0]  nbytes;                           // access bytes (1..64)
  logic [2:0]  nlines;                           // lines occupied (1..4)
  always_comb begin
    case (v_req_size)
      3'd0: begin nbytes = 5'd1;  nlines = 3'd1; end
      3'd1: begin nbytes = 5'd2;  nlines = 3'd1; end
      3'd2: begin nbytes = 5'd4;  nlines = 3'd1; end
      3'd3: begin nbytes = 5'd8;  nlines = 3'd1; end
      3'd4: begin nbytes = 5'd16; nlines = 3'd1; end
      3'd5: begin nbytes = 5'd0;  nlines = 3'd2; end        // 32 B (nbytes unused for multi-line)
      default: begin nbytes = 5'd0; nlines = 3'd4; end
    endcase
  end
  wire        multi   = (v_req_size >= 3'd5);
  wire [3:0]  off     = v_req_addr[LB-1:0];
  // size mask over the address: natural alignment means addr % size == 0
  logic [AW-1:0] size_mask;
  always_comb begin
    case (v_req_size)
      3'd0: size_mask = '0;
      3'd1: size_mask = AW'(1);
      3'd2: size_mask = AW'(3);
      3'd3: size_mask = AW'(7);
      3'd4: size_mask = AW'(15);
      3'd5: size_mask = AW'(31);
      default: size_mask = AW'(63);
    endcase
  end
  wire natural_ok = ((v_req_addr & size_mask) == '0);
  wire [5:0] endoff = {2'b00, off} + {1'b0, nbytes} ;            // sub-line: offset + bytes must stay inside the line
  wire in_line_ok = (endoff <= 6'd16);
  wire size_ok    = (v_req_size <= 3'd6) && (nlines <= 3'(VEC_LINES));
  wire align_ok   = size_ok && ((multi || v_req_size == 3'd4) ? natural_ok : ((ALIGN_RULE == 0) ? natural_ok : in_line_ok));
  wire reject     = ~align_ok;

  // ------------------------------------------------------------ request stage (one request held until all its lines are issued)
  logic              rq_v, rq_we, rq_rej, rq_multi, rq_sext;
  logic [AW-1:0]     rq_addr;
  logic [2:0]        rq_nl;
  logic [4:0]        rq_nbytes;
  logic [3:0]        rq_off;
  logic [VEC_W-1:0]  rq_wd;
  logic [IDW-1:0]    rq_id;
  logic [VEC_LINES-1:0] issued;
  logic [VEC_LINES-1:0] active, line_valid, line_acc;
  logic              all_issued_now;

  always_comb begin
    for (int p = 0; p < VEC_LINES; p++) active[p] = (3'(p) < rq_nl);
    for (int p = 0; p < VEC_LINES; p++) line_valid[p] = rq_v & active[p] & ~issued[p];
    for (int p = 0; p < VEC_LINES; p++) line_acc[p] = line_valid[p] & c_req_ready[p];
    all_issued_now = rq_v;
    for (int p = 0; p < VEC_LINES; p++) if (active[p] && !issued[p] && !c_req_ready[p]) all_issued_now = 1'b0;
  end
  // metadata FIFO: one entry per accepted vector request, popped when its response is delivered
  localparam int MW = IDW + 1 + 1 + 1 + 3 + 5 + 4 + 1;      // {id, we, sext, rej, nlines, nbytes, off, multi}
  logic [MW-1:0] meta_in, meta_out;
  logic          meta_push, meta_pop, meta_empty, meta_full;
  logic [$clog2(META_DEPTH + 1)-1:0] meta_cnt;
  // the request leaves the stage only when its LAST line issues and its metadata can be stored (never lose an entry)
  wire finish = rq_v & all_issued_now & ~meta_full;
  assign meta_in   = {rq_id, rq_we, rq_sext, rq_rej, rq_nl, rq_nbytes, rq_off, rq_multi};
  assign meta_push = finish;
  sf_sync_fifo #(.W(MW), .DEPTH(META_DEPTH)) u_meta (.clk(clk), .rst_n(rst_n), .clr_i(1'b0), .push_i(meta_push), .din_i(meta_in),
                                                    .pop_i(meta_pop), .dout_o(meta_out), .empty_o(meta_empty), .full_o(meta_full), .count_o(meta_cnt));
  assign v_req_ready = ~rq_v | finish;
  wire unused_meta = &{1'b0, meta_cnt};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rq_v <= 1'b0; issued <= '0; rq_we <= 1'b0; rq_rej <= 1'b0; rq_multi <= 1'b0; rq_sext <= 1'b0; rq_addr <= '0; rq_nl <= '0;
      rq_nbytes <= '0; rq_off <= '0; rq_wd <= '0; rq_id <= '0;
    end else begin
      if (rq_v && !finish) issued <= issued | line_acc;           // lines accepted while the request waits for its metadata slot
      if (v_req_valid && v_req_ready) begin
        rq_v <= 1'b1; issued <= '0; rq_we <= v_req_we; rq_rej <= reject; rq_addr <= v_req_addr; rq_sext <= v_req_sext;
        rq_nl <= (reject ? 3'd1 : nlines); rq_nbytes <= nbytes; rq_off <= off; rq_wd <= v_req_wdata; rq_id <= v_req_id;
        rq_multi <= multi;
      end else if (finish) begin
        rq_v <= 1'b0; issued <= '0;
      end
    end
  end

  // ------------------------------------------------------------ vector -> controller lines
  logic [LINE_W-1:0]  sub_wd;
  logic [BEW-1:0]     sub_be;
  always_comb begin
    integer ioff, inb;
    ioff = {28'd0, rq_off}; inb = {27'd0, rq_nbytes};
    sub_wd = '0; sub_be = '0;
    for (int b = 0; b < BEW; b++) begin
      if (b >= ioff && b < ioff + inb) begin
        sub_be[b] = 1'b1;
        sub_wd[b*8 +: 8] = rq_wd[(b - ioff)*8 +: 8];
      end
    end
  end

  logic [NPORT-1:0]            cv;
  logic [NPORT*AW-1:0]         ca;
  logic [NPORT*LINE_W-1:0]     cd;
  logic [NPORT*BEW-1:0]        cb;
  logic [NPORT-1:0]            cw;
  // DMA side signals (defined below)
  logic                dma_req_v, dma_req_w, dma_rsp_ready;
  logic [AW-1:0]       dma_req_a;
  logic [LINE_W-1:0]   dma_req_d;

  always_comb begin
    cv = '0; ca = '0; cd = '0; cb = '0; cw = '0;
    for (int p = 0; p < VEC_LINES; p++) begin
      cv[p] = line_valid[p];
      cw[p] = rq_we & ~rq_rej;
      ca[p*AW +: AW] = rq_rej ? REJECT_ADDR : ((rq_addr & ~AW'(15)) + AW'(p * 16));
      if (rq_multi) begin
        cd[p*LINE_W +: LINE_W] = rq_wd[p*LINE_W +: LINE_W];
        cb[p*BEW +: BEW]       = {BEW{rq_we & ~rq_rej}};
      end else begin
        cd[p*LINE_W +: LINE_W] = sub_wd;
        cb[p*BEW +: BEW]       = (rq_we & ~rq_rej) ? sub_be : '0;
      end
    end
    cv[VEC_LINES] = dma_req_v;
    cw[VEC_LINES] = dma_req_w;
    ca[VEC_LINES*AW +: AW] = dma_req_a;
    cd[VEC_LINES*LINE_W +: LINE_W] = dma_req_d;
    cb[VEC_LINES*BEW +: BEW] = {BEW{dma_req_w}};
  end
  assign c_req_valid = cv; assign c_req_we = cw; assign c_req_addr = ca; assign c_req_wdata = cd; assign c_req_be = cb;

  // ------------------------------------------------------------ vector response assembly
  logic [MW-1:0] mo;
  assign mo = meta_out;
  wire [IDW-1:0] m_id    = mo[MW-1 -: IDW];
  wire           m_we    = mo[MW-IDW-1];
  wire           m_sext  = mo[MW-IDW-2];
  wire           m_rej   = mo[MW-IDW-3];
  wire [2:0]     m_nl    = mo[MW-IDW-4 -: 3];
  wire [4:0]     m_nb    = mo[MW-IDW-7 -: 5];
  wire [3:0]     m_off   = mo[MW-IDW-12 -: 4];
  wire           m_multi = mo[0];

  logic [VEC_LINES-1:0] m_active;
  integer imnb, imoff;
  logic                 all_have;
  logic [2:0]           worst;
  logic [VEC_W-1:0]     assembled;
  logic [LINE_W-1:0]    l0;
  logic [VEC_W-1:0]     sub_val;
  always_comb begin
    for (int p = 0; p < VEC_LINES; p++) m_active[p] = (3'(p) < m_nl);
    all_have = ~meta_empty;
    for (int p = 0; p < VEC_LINES; p++) if (m_active[p] && !c_rsp_valid[p]) all_have = 1'b0;
    worst = `SF_ST_OK;
    for (int p = 0; p < VEC_LINES; p++)
      if (m_active[p] && worst == `SF_ST_OK) worst = c_rsp_status[p*3 +: 3];
    assembled = '0;
    // only the lines that belong to THIS request: an inactive port shows stale data on its response bus
    for (int p = 0; p < VEC_LINES; p++) if (m_active[p]) assembled[p*LINE_W +: LINE_W] = c_rsp_rdata[p*LINE_W +: LINE_W];
    // sub-line: shift the addressed bytes down, zero / sign extend
    l0 = c_rsp_rdata[0 +: LINE_W];
    sub_val = '0;
    imnb = {27'd0, m_nb}; imoff = {28'd0, m_off};
    for (int b = 0; b < VEC_W / 8; b++) begin
      if (b < imnb && (imoff + b) < BEW) sub_val[b*8 +: 8] = l0[(imoff + b)*8 +: 8];
    end
    if (m_sext && imnb != 0) begin
      for (int b = 0; b < VEC_W / 8; b++)
        if (b >= imnb) sub_val[b*8 +: 8] = {8{sub_val[imnb*8 - 1]}};
    end
  end
  wire m_err = (m_rej) || (worst != `SF_ST_OK);
  assign v_rsp_valid  = all_have;
  assign v_rsp_id     = m_id;
  assign v_rsp_we     = m_we;
  assign v_rsp_status = m_rej ? `SF_ST_ALIGN : worst;
  assign v_rsp_rdata  = (m_we || m_err) ? '0 : (m_multi ? assembled : sub_val);
  assign meta_pop     = v_rsp_valid & v_rsp_ready;
  always_comb begin
    c_rsp_ready = '0;
    for (int p = 0; p < VEC_LINES; p++) c_rsp_ready[p] = meta_pop & m_active[p];
    c_rsp_ready[VEC_LINES] = dma_rsp_ready;
  end

  // ------------------------------------------------------------ DMA engine
  typedef enum logic [1:0] {D_IDLE, D_RUN, D_FLUSH} dstate_e;
  dstate_e       dst;
  logic          ddir;
  logic [AW-1:0] daddr, dstride;
  logic [15:0]   dlen, dissued, dresp;
  logic [2:0]    derr_code;
  logic [PW-1:0] dout_pend;
  wire  [LINE_W-1:0] st_data = c_rsp_rdata[VEC_LINES*LINE_W +: LINE_W];
  wire  [2:0]        st_stat = c_rsp_status[VEC_LINES*3 +: 3];
  wire               st_valid = c_rsp_valid[VEC_LINES];
  // STORE staging FIFO (credit based: a read is issued only when a slot is certain, so the stream never backpressures the controller)
  logic              sf_push, sf_pop, sf_empty, sf_full;
  logic [LINE_W-1:0] sf_dout;
  logic [PW-1:0] sf_cnt;
  sf_sync_fifo #(.W(LINE_W), .DEPTH(DMA_OUT)) u_stage (.clk(clk), .rst_n(rst_n), .clr_i(1'b0), .push_i(sf_push),
                                                   .din_i(st_data), .pop_i(sf_pop), .dout_o(sf_dout), .empty_o(sf_empty), .full_o(sf_full), .count_o(sf_cnt));
  wire issue_more = (dissued != dlen);
  wire [31:0] pend32 = {{(32-PW){1'b0}}, dout_pend};
  wire [31:0] used32 = pend32 + {{(32-PW){1'b0}}, sf_cnt};
  wire can_credit = ddir ? (used32 < DMA_OUT) : (pend32 < DMA_OUT);
  always_comb begin
    dma_req_v = 1'b0; dma_req_w = 1'b0; dma_req_a = daddr; dma_req_d = dma_in_data; dma_in_ready = 1'b0;
    if (dst == D_RUN && issue_more && can_credit) begin
      if (!ddir) begin                                         // LOAD: a beat needs stream data
        dma_req_v = dma_in_valid; dma_req_w = 1'b1; dma_in_ready = c_req_ready[VEC_LINES] & dma_in_valid;
      end else begin
        dma_req_v = 1'b1; dma_req_w = 1'b0;
      end
    end
  end
  wire d_acc = dma_req_v & c_req_ready[VEC_LINES];
  assign dma_rsp_ready = ddir ? ~sf_full : 1'b1;
  assign sf_push = ddir & st_valid & ~sf_full;
  wire   d_resp = st_valid & dma_rsp_ready;
  assign dma_out_valid = ~sf_empty;
  assign dma_out_data  = sf_dout;
  assign sf_pop        = dma_out_valid & dma_out_ready;
  assign dma_busy_o    = (dst != D_IDLE);
  wire   last_resp = (({1'b0, dresp} + {16'd0, d_resp}) == {1'b0, dlen}) && (({1'b0, dissued} + {16'd0, d_acc}) == {1'b0, dlen});

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      dst <= D_IDLE; ddir <= 1'b0; daddr <= '0; dstride <= '0; dlen <= '0; dissued <= '0; dresp <= '0; dout_pend <= '0;
      dma_done_o <= 1'b0; dma_err_o <= 1'b0; derr_code <= '0; dma_beats_o <= '0;
    end else begin
      dma_done_o <= 1'b0;
      dout_pend <= dout_pend + PW'(d_acc) - PW'(d_resp);
      case (dst)
        D_IDLE: if (dma_start_i && dma_len_i != '0) begin
          dst <= D_RUN; ddir <= dma_dir_i; daddr <= dma_base_i; dstride <= dma_stride_i; dlen <= dma_len_i;
          dissued <= '0; dresp <= '0; dma_err_o <= 1'b0; derr_code <= '0; dma_beats_o <= '0;
        end
        D_RUN: begin
          if (d_acc) begin dissued <= dissued + 1'b1; daddr <= daddr + dstride; end
          if (d_resp) begin
            dresp <= dresp + 1'b1; dma_beats_o <= dma_beats_o + 1'b1;
            if (st_stat != `SF_ST_OK) begin
              dma_err_o <= 1'b1;
              if (!dma_err_o) derr_code <= st_stat;
            end
          end
          if (last_resp) dst <= D_FLUSH;                           // all beats answered; a STORE waits until the stream consumer took its data
        end
        D_FLUSH: if (sf_empty || !ddir) begin dst <= D_IDLE; dma_done_o <= 1'b1; end
        default: dst <= D_IDLE;
      endcase
    end
  end
  assign dma_err_code_o = derr_code;

  // ------------------------------------------------------------ bank conflict detection
  function automatic integer bank_of(input logic [AW-1:0] a);
    logic [AW-1:0] ln;
    begin
      ln = a >> LB;
      bank_of = (NB > 1) ? (ln % NB) : 0;
    end
  endfunction
  logic cv_dma;
  always_comb begin
    cv_dma = 1'b0;
    for (int p = 0; p < VEC_LINES; p++)
      if (line_valid[p] && dma_req_v && !rq_rej && bank_of(ca[p*AW +: AW]) == bank_of(dma_req_a)) cv_dma = 1'b1;
  end
  // intra-vector conflict is a property of the accepted request: more lines than banks wrap onto the same bank
  wire vec_acc = v_req_valid & v_req_ready & ~reject & (nlines > 3'(NB));
  assign conflict_vec_o = vec_acc;
  assign conflict_dma_o = cv_dma;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) conflict_cnt_o <= '0;
    else if ((conflict_vec_o | conflict_dma_o) && conflict_cnt_o != {CNT_W{1'b1}}) conflict_cnt_o <= conflict_cnt_o + 1'b1;
  end
endmodule

`default_nettype wire
