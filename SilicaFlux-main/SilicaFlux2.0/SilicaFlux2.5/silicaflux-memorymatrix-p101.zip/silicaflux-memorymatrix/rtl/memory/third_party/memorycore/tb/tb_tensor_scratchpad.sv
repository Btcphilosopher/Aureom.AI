// =============================================================================
// SilicaFlux MemoryCore :: tb_tensor_scratchpad
// sf_tensor_scratchpad on a real 4-port sf_sram_controller.
//   TensorCore model : per tile, P passes of  C[k] += A[k]*B[k] + pass  (per 32-bit word, mod 2^32) with A, B, C streamed
//                      lock-step through three ports (C is read, updated, written back: partial sums, read-modify-write)
//   DMA model        : FILL  = write the A and B tiles and a zero C tile;  DRAIN = read C back and compare with the reference
//   Pipeline         : three concurrent processes (fill / compute / drain) running NTILES tiles over NBUF buffers
// Checks: every drained C line equals the independent reference (so any overwrite of operands during READY / COMPUTE, any
// lost write, any early completion shows up as a data mismatch); ownership state sequence; the rejection tests below;
// and the buffers' phase overlap with NBUF = 2.
//   N1 DMA writes into a READY buffer       N2 DMA writes into the COMPUTE buffer       N3 TensorCore access without ownership
//   N4 DMA reads of A / B, DMA read of C while FILLING     N5 out-of-tile coordinates / lines (RANGE)
//   N6 DMA write into a DRAINING buffer
// Every rejected request must (a) answer SF_ST_OWNER / SF_ST_RANGE in order, (b) leave the SRAM untouched, (c) be counted.
// Prints BENCH lines (cycles per tile, bank conflict cycles) used by benchmarks/run_bench.py.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"

module tb_tensor_scratchpad #(
  parameter int NBUF = 2,
  parameter int NB = 4,
  parameter int DEPTH = 64,
  parameter int N = 8,                   // lines per tile (A_ROWS = B_ROWS = C_ROWS = N, one line per row)
  parameter int SKEW = 1,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NSLOT = 8,
  parameter int NTILES = 8,
  parameter int PASSES = 3,
  parameter int COMPUTE_EXTRA = 0,       // extra engine cycles per pass (models a deeper TensorCore pipeline)
  parameter int EARLY_DONE = 0,          // 1: the DMA / TensorCore model signals *_done IMMEDIATELY after issuing its last access, without waiting for
                                         //    the responses: the scratchpad itself must defer completion until every access is acknowledged
  parameter int SEED = 32'h7E57C0DE
);
  localparam int AW = 20, LINE_W = 128, LB = 4;
  localparam int CAP_LINES = NB * DEPTH;
  localparam int R_ECC = $clog2(LINE_W + $clog2(LINE_W + 1) + 1);
  localparam int STORE_W = (ECC_EN != 0) ? LINE_W + R_ECC + 1 : LINE_W;
  localparam int BUFW = (NBUF > 1) ? $clog2(NBUF) : 1;
  localparam int RW = (N > 1) ? $clog2(N) : 1;
  localparam int LW = RW;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT
  logic fill_req = 0, fill_done = 0, fill_grant, te_req = 0, te_done = 0, te_owned, drain_req = 0, drain_done = 0, drain_grant;
  logic [BUFW-1:0] fill_buf, te_buf, drain_buf;
  logic [NBUF*3-1:0] buf_state;
  logic ev_fill, ev_comp, ev_drain, irq;
  logic [15:0] own_viol, rng_viol;
  logic a_req_valid = 0, a_req_ready, a_rsp_valid, a_rsp_ready = 1, b_req_valid = 0, b_req_ready, b_rsp_valid, b_rsp_ready = 1;
  logic [RW-1:0] a_row = 0, b_row = 0, c_row = 0;
  logic [0:0] a_col = 0, b_col = 0, c_col = 0;
  logic [LINE_W-1:0] a_data, b_data, c_data;
  logic [2:0] a_st, b_st, c_st;
  logic c_req_valid = 0, c_req_ready, c_req_we = 0, c_rsp_valid, c_rsp_ready = 1, c_rsp_we;
  logic [LINE_W-1:0] c_wdata = 0;
  logic [LINE_W/8-1:0] c_be = '1;
  logic d_req_valid = 0, d_req_ready, d_req_we = 0, d_rsp_valid, d_rsp_ready = 1, d_rsp_we;
  logic [1:0] d_region = 0;
  logic [BUFW-1:0] d_buf = 0;
  logic [LW-1:0] d_line = 0;
  logic [LINE_W-1:0] d_wdata = 0, d_data;
  logic [LINE_W/8-1:0] d_be = '1;
  logic [2:0] d_st;
  logic [3:0] m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_ready;
  logic [4*AW-1:0] m_req_addr;
  logic [4*LINE_W-1:0] m_req_wdata, m_rsp_rdata;
  logic [4*(LINE_W/8)-1:0] m_req_be;
  logic [4*3-1:0] m_rsp_status;
  logic [3:0] m_rsp_we, m_rsp_ce;
  logic [4*1-1:0] m_rsp_id;
  logic c_idle;
  logic [NB*32-1:0] perf_acc, perf_conf, perf_busy;
  logic [NB*STORE_W-1:0] tst_rdata;

  sf_tensor_scratchpad #(.AW(AW), .NB(NB), .CAP_LINES(CAP_LINES), .NBUF(NBUF), .A_ROWS(N), .A_LPR(1), .B_ROWS(N), .B_LPR(1),
                         .C_ROWS(N), .C_LPR(1), .SKEW(SKEW), .META_DEPTH(NSLOT)) dut (
    .clk(clk), .rst_n(rst_n),
    .fill_req_i(fill_req), .fill_done_i(fill_done), .fill_grant_o(fill_grant), .fill_buf_o(fill_buf),
    .te_req_i(te_req), .te_done_i(te_done), .te_owned_o(te_owned), .te_buf_o(te_buf),
    .drain_req_i(drain_req), .drain_done_i(drain_done), .drain_grant_o(drain_grant), .drain_buf_o(drain_buf),
    .buf_state_o(buf_state), .ev_fill_complete_o(ev_fill), .ev_compute_complete_o(ev_comp), .ev_drain_complete_o(ev_drain), .irq_o(irq),
    .owner_viol_cnt_o(own_viol), .range_viol_cnt_o(rng_viol),
    .a_req_valid(a_req_valid), .a_req_ready(a_req_ready), .a_req_row(a_row), .a_req_col(a_col), .a_rsp_valid(a_rsp_valid), .a_rsp_ready(a_rsp_ready),
    .a_rsp_data(a_data), .a_rsp_status(a_st),
    .b_req_valid(b_req_valid), .b_req_ready(b_req_ready), .b_req_row(b_row), .b_req_col(b_col), .b_rsp_valid(b_rsp_valid), .b_rsp_ready(b_rsp_ready),
    .b_rsp_data(b_data), .b_rsp_status(b_st),
    .c_req_valid(c_req_valid), .c_req_ready(c_req_ready), .c_req_we(c_req_we), .c_req_row(c_row), .c_req_col(c_col), .c_req_wdata(c_wdata), .c_req_be(c_be),
    .c_rsp_valid(c_rsp_valid), .c_rsp_ready(c_rsp_ready), .c_rsp_data(c_data), .c_rsp_we(c_rsp_we), .c_rsp_status(c_st),
    .d_req_valid(d_req_valid), .d_req_ready(d_req_ready), .d_req_we(d_req_we), .d_req_region(d_region), .d_req_buf(d_buf), .d_req_line(d_line),
    .d_req_wdata(d_wdata), .d_req_be(d_be), .d_rsp_valid(d_rsp_valid), .d_rsp_ready(d_rsp_ready), .d_rsp_data(d_data), .d_rsp_we(d_rsp_we), .d_rsp_status(d_st),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_be(m_req_be),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_status(m_rsp_status));

  sf_sram_controller #(.NM(4), .NB(NB), .DEPTH(DEPTH), .DW(LINE_W), .AW(AW), .IDW(1), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
                       .NSLOT(NSLOT), .INIT_ON_RESET(1), .SIM_INIT(2)) ctl (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata),
    .m_req_be(m_req_be), .m_req_id(4'b0), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id),
    .m_rsp_we(m_rsp_we), .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(1'b0), .idle_o(c_idle), .init_start_i(1'b0), .init_busy_o(), .scrub_en_i(1'b0), .ecc_clr_i(1'b0),
    .ev_ce_o(), .ev_ue_o(), .ce_cnt_o(), .ue_cnt_o(), .perf_acc_o(perf_acc), .perf_conf_o(perf_conf), .perf_busy_o(perf_busy), .perf_stall_o(), .bank_acc_o(),
    .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0), .tst_rdata_o(tst_rdata),
    .fi_bank('0), .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  // ---------------------------------------------------------------- generic state
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  int n_checks = 0, n_err = 0;
  longint cycle = 0;
  string cur = "";
  task automatic fail(input string m); n_err++; if (n_err <= 25) $display("  [FAIL] %s @cycle %0d (%s)", m, cycle, cur); endtask
  task automatic check(input bit c, input string m); n_checks++; if (!c) fail(m); endtask
  always @(posedge clk) cycle <= cycle + 1;

  // ---------------------------------------------------------------- per-port stimulus queues (circular) + response collectors
  localparam int QD = 512;
  // A / B read queues
  logic [RW-1:0] aq_row [QD]; int aqh = 0, aqt = 0;
  logic [RW-1:0] bq_row [QD]; int bqh = 0, bqt = 0;
  logic [RW-1:0] cq_row [QD]; logic cq_we [QD]; logic [LINE_W-1:0] cq_data [QD]; int cqh = 0, cqt = 0;
  logic dq_we [QD]; logic [1:0] dq_reg [QD]; logic [BUFW-1:0] dq_buf [QD]; logic [LW-1:0] dq_line [QD]; logic [LINE_W-1:0] dq_data [QD]; int dqh = 0, dqt = 0;
  logic [LINE_W-1:0] a_got [QD]; logic [2:0] a_gst [QD]; int a_n = 0;
  logic [LINE_W-1:0] b_got [QD]; logic [2:0] b_gst [QD]; int b_n = 0;
  logic [LINE_W-1:0] c_got [QD]; logic [2:0] c_gst [QD]; logic c_gwe [QD]; int c_n = 0;
  logic [LINE_W-1:0] d_got [QD]; logic [2:0] d_gst [QD]; logic d_gwe [QD]; int d_n = 0;

  always @(posedge clk) begin
    if (!rst_n) begin a_req_valid <= 0; b_req_valid <= 0; c_req_valid <= 0; d_req_valid <= 0; end
    else begin
      if (a_req_valid && a_req_ready) a_req_valid <= 0;
      if ((!a_req_valid || a_req_ready) && aqt > aqh) begin a_req_valid <= 1; a_row <= aq_row[aqh % QD]; a_col <= 0; aqh++; end
      if (b_req_valid && b_req_ready) b_req_valid <= 0;
      if ((!b_req_valid || b_req_ready) && bqt > bqh) begin b_req_valid <= 1; b_row <= bq_row[bqh % QD]; b_col <= 0; bqh++; end
      if (c_req_valid && c_req_ready) c_req_valid <= 0;
      if ((!c_req_valid || c_req_ready) && cqt > cqh) begin
        c_req_valid <= 1; c_row <= cq_row[cqh % QD]; c_col <= 0; c_req_we <= cq_we[cqh % QD]; c_wdata <= cq_data[cqh % QD]; c_be <= '1; cqh++;
      end
      if (d_req_valid && d_req_ready) d_req_valid <= 0;
      if ((!d_req_valid || d_req_ready) && dqt > dqh) begin
        d_req_valid <= 1; d_req_we <= dq_we[dqh % QD]; d_region <= dq_reg[dqh % QD]; d_buf <= dq_buf[dqh % QD]; d_line <= dq_line[dqh % QD];
        d_wdata <= dq_data[dqh % QD]; d_be <= '1; dqh++;
      end
      if (a_rsp_valid && a_rsp_ready) begin a_got[a_n % QD] = a_data; a_gst[a_n % QD] = a_st; a_n++; end
      if (b_rsp_valid && b_rsp_ready) begin b_got[b_n % QD] = b_data; b_gst[b_n % QD] = b_st; b_n++; end
      if (c_rsp_valid && c_rsp_ready) begin c_got[c_n % QD] = c_data; c_gst[c_n % QD] = c_st; c_gwe[c_n % QD] = c_rsp_we; c_n++; end
      if (d_rsp_valid && d_rsp_ready) begin d_got[d_n % QD] = d_data; d_gst[d_n % QD] = d_st; d_gwe[d_n % QD] = d_rsp_we; d_n++; end
    end
  end

  // ---------------------------------------------------------------- data model
  logic [LINE_W-1:0] refA [NTILES][N], refB [NTILES][N], refC [NTILES][N];
  function automatic logic [LINE_W-1:0] mac(input logic [LINE_W-1:0] c, input logic [LINE_W-1:0] a, input logic [LINE_W-1:0] b, input int p);
    logic [LINE_W-1:0] r;
    for (int w = 0; w < LINE_W / 32; w++) r[w*32 +: 32] = c[w*32 +: 32] + a[w*32 +: 32] * b[w*32 +: 32] + 32'(p);
    return r;
  endfunction
  task automatic gen_tiles();
    for (int t = 0; t < NTILES; t++)
      for (int k = 0; k < N; k++) begin
        logic [LINE_W-1:0] c;
        for (int w = 0; w < 4; w++) begin refA[t][k][w*32 +: 32] = rnd(); refB[t][k][w*32 +: 32] = rnd(); end
        c = '0;
        for (int p = 0; p < PASSES; p++) c = mac(c, refA[t][k], refB[t][k], p);
        refC[t][k] = c;
      end
  endtask

  // ---------------------------------------------------------------- DMA / TE batch operations
  bit dma_lock = 0;
  task automatic dma_acquire(); while (dma_lock) @(posedge clk); dma_lock = 1; endtask
  task automatic dma_release(); dma_lock = 0; endtask
  task automatic dma_wait(input int cnt); int g; g = 0; while (d_n < cnt && g < 20000) begin @(posedge clk); g++; end if (g >= 20000) fail("DMA batch timeout"); endtask

  task automatic dma_fill(input int bufi, input int t, input bit early = 1'b0);
    dma_acquire(); d_n = 0;
    for (int k = 0; k < N; k++) begin
      dq_we[dqt % QD] = 1; dq_reg[dqt % QD] = 2'd0; dq_buf[dqt % QD] = BUFW'(bufi); dq_line[dqt % QD] = LW'(k); dq_data[dqt % QD] = refA[t][k]; dqt++;
      dq_we[dqt % QD] = 1; dq_reg[dqt % QD] = 2'd1; dq_buf[dqt % QD] = BUFW'(bufi); dq_line[dqt % QD] = LW'(k); dq_data[dqt % QD] = refB[t][k]; dqt++;
      dq_we[dqt % QD] = 1; dq_reg[dqt % QD] = 2'd2; dq_buf[dqt % QD] = BUFW'(bufi); dq_line[dqt % QD] = LW'(k); dq_data[dqt % QD] = '0;        dqt++;
    end
    if (!early) begin
      dma_wait(3 * N);
      for (int i = 0; i < 3 * N; i++) check(d_gst[i % QD] == `SF_ST_OK, $sformatf("fill write %0d status %0d", i, d_gst[i % QD]));
      dma_release();
    end                                               // EARLY_DONE: p_fill signals fill_done now and checks the completion itself
  endtask
  task automatic dma_drain(input int bufi, input int t);
    dma_acquire(); d_n = 0;
    for (int k = 0; k < N; k++) begin dq_we[dqt % QD] = 0; dq_reg[dqt % QD] = 2'd2; dq_buf[dqt % QD] = BUFW'(bufi); dq_line[dqt % QD] = LW'(k); dq_data[dqt % QD] = '0; dqt++; end
    dma_wait(N);
    for (int k = 0; k < N; k++) begin
      check(d_gst[k % QD] == `SF_ST_OK, $sformatf("drain read status %0d", d_gst[k % QD]));
      check(d_got[k % QD] === refC[t][k], $sformatf("tile %0d C[%0d] = %h, expected %h", t, k, d_got[k % QD], refC[t][k]));
    end
    dma_release();
  endtask

  task automatic te_wait(input int na, input int nb_, input int nc); int g; g = 0; while ((a_n < na || b_n < nb_ || c_n < nc) && g < 20000) begin @(posedge clk); g++; end if (g >= 20000) fail("TE batch timeout"); endtask
  task automatic te_compute(input int t, input bit early = 1'b0);
    logic [LINE_W-1:0] newc [N];
    for (int p = 0; p < PASSES; p++) begin
      a_n = 0; b_n = 0; c_n = 0;
      for (int k = 0; k < N; k++) begin
        aq_row[aqt % QD] = RW'(k); aqt++; bq_row[bqt % QD] = RW'(k); bqt++;
        cq_row[cqt % QD] = RW'(k); cq_we[cqt % QD] = 0; cq_data[cqt % QD] = '0; cqt++;
      end
      te_wait(N, N, N);
      for (int k = 0; k < N; k++) begin
        check(a_gst[k] == `SF_ST_OK && b_gst[k] == `SF_ST_OK && c_gst[k] == `SF_ST_OK, "TE operand read status");
        newc[k] = mac(c_got[k], a_got[k], b_got[k], p);
        // the operands must be exactly what the DMA delivered (an overwrite during READY / COMPUTE would show here)
        check(a_got[k] === refA[t][k], $sformatf("tile %0d A[%0d] corrupted: %h != %h", t, k, a_got[k], refA[t][k]));
        check(b_got[k] === refB[t][k], $sformatf("tile %0d B[%0d] corrupted: %h != %h", t, k, b_got[k], refB[t][k]));
      end
      repeat (COMPUTE_EXTRA) @(posedge clk);
      for (int k = 0; k < N; k++) begin cq_row[cqt % QD] = RW'(k); cq_we[cqt % QD] = 1; cq_data[cqt % QD] = newc[k]; cqt++; end
      if (!(early && p == PASSES - 1)) te_wait(N, N, 2 * N);     // EARLY_DONE: the last pass's write acknowledgements are NOT awaited
    end
  endtask

  // ---------------------------------------------------------------- pipeline processes
  int t_fill_done = 0, t_comp_done = 0, t_drain_done = 0;
  int ovl_cycles = 0;
  task automatic p_fill();
    for (int t = 0; t < NTILES; t++) begin
      fill_req = 1; while (!fill_grant) @(posedge clk);
      fill_req = 0;
      dma_fill(int'(fill_buf), t, EARLY_DONE != 0);
      if (EARLY_DONE != 0) begin                                         // every access ISSUED (accepted by the port); responses are not awaited
        while (dqh != dqt) @(posedge clk);
        d_rsp_ready = 1'b0;                                              // withhold the write acknowledgements: they stay outstanding while fill_done is given
        while (d_req_valid) @(posedge clk);
      end
      @(negedge clk); fill_done = 1; @(negedge clk); fill_done = 0;
      if (EARLY_DONE != 0) begin                                         // completion MUST wait for the withheld acknowledgements
        repeat (12) @(posedge clk);
        check(fill_grant && buf_state[fill_buf*3 +: 3] == 3'd1, "fill completed while its write acknowledgements were still outstanding");
        d_rsp_ready = 1'b1;
      end
      while (fill_grant) @(posedge clk);
      if (EARLY_DONE != 0) begin                                         // completion must have waited for every write acknowledgement
        check(d_n == 3 * N, $sformatf("fill completed with only %0d of %0d writes acknowledged", d_n, 3 * N));
        for (int i = 0; i < 3 * N; i++) check(d_gst[i % QD] == `SF_ST_OK, $sformatf("fill write %0d status %0d", i, d_gst[i % QD]));
        dma_release();
      end
      t_fill_done++;
    end
  endtask
  task automatic p_comp();
    for (int t = 0; t < NTILES; t++) begin
      te_req = 1; while (!te_owned) @(posedge clk);
      te_req = 0;
      te_compute(t, EARLY_DONE != 0);
      if (EARLY_DONE != 0) begin
        while (cqh != cqt || aqh != aqt || bqh != bqt) @(posedge clk);
        a_rsp_ready = 1'b0; b_rsp_ready = 1'b0; c_rsp_ready = 1'b0;      // withhold the acknowledgements / read data: they stay outstanding while te_done is given
        while (c_req_valid || a_req_valid || b_req_valid) @(posedge clk);
      end
      @(negedge clk); te_done = 1; @(negedge clk); te_done = 0;
      if (EARLY_DONE != 0) begin                                         // completion MUST wait for the withheld responses
        repeat (12) @(posedge clk);
        check(te_owned, "compute completed while its accesses were still outstanding");
        a_rsp_ready = 1'b1; b_rsp_ready = 1'b1; c_rsp_ready = 1'b1;
      end
      while (te_owned) @(posedge clk);
      if (EARLY_DONE != 0) check(c_n == 2 * N && !c_req_valid && cqh == cqt, $sformatf("compute completed with %0d of %0d C accesses acknowledged", c_n, 2 * N));
      t_comp_done++;
    end
  endtask
  task automatic p_drain();
    for (int t = 0; t < NTILES; t++) begin
      drain_req = 1; while (!drain_grant) @(posedge clk);
      drain_req = 0;
      dma_drain(int'(drain_buf), t);
      @(negedge clk); drain_done = 1; @(negedge clk); drain_done = 0;
      while (drain_grant) @(posedge clk);
      t_drain_done++;
    end
  endtask
  bit run_pipe = 1'b0, done_f = 1'b0, done_c = 1'b0, done_d = 1'b0;
  initial begin wait (run_pipe); p_fill();  done_f = 1'b1; end
  initial begin wait (run_pipe); p_comp();  done_c = 1'b1; end
  initial begin wait (run_pipe); p_drain(); done_d = 1'b1; end
  // phase overlap monitor: cycles during which one buffer is being filled/drained while another is computed
  always @(posedge clk) if (rst_n && NBUF > 1) begin
    int comp, other;
    comp = 0; other = 0;
    for (int i = 0; i < NBUF; i++) begin
      if (buf_state[i*3 +: 3] == 3'd3) comp++;
      if (buf_state[i*3 +: 3] == 3'd1 || buf_state[i*3 +: 3] == 3'd5) other++;
    end
    if (comp > 0 && other > 0) ovl_cycles++;
  end
  bit trace = $test$plusargs("DASHTRACE");
  always @(posedge clk) if (trace && rst_n && run_pipe && cycle < 5000 && (a_req_valid & a_req_ready | b_req_valid & b_req_ready | c_req_valid & c_req_ready | d_req_valid & d_req_ready))
    $display("DT tsp ports cycle=%0d a=%0d b=%0d c=%0d dma=%0d cwe=%0d dwe=%0d", cycle, a_req_valid & a_req_ready, b_req_valid & b_req_ready, c_req_valid & c_req_ready, d_req_valid & d_req_ready, c_req_we, d_req_we);
  // ownership-state sequence monitor: legal transitions only
  logic [2:0] prev_st [NBUF];
  always @(posedge clk) if (rst_n) begin
    for (int i = 0; i < NBUF; i++) begin
      logic [2:0] s;
      s = buf_state[i*3 +: 3];
      if (s != prev_st[i]) begin
        if (trace && run_pipe) $display("DT tsp state cycle=%0d buf=%0d from=%0d to=%0d", cycle, i, prev_st[i], s);
        check((prev_st[i] == 3'd0 && s == 3'd1) || (prev_st[i] == 3'd1 && s == 3'd2) || (prev_st[i] == 3'd2 && s == 3'd3) ||
              (prev_st[i] == 3'd3 && s == 3'd4) || (prev_st[i] == 3'd4 && s == 3'd5) || (prev_st[i] == 3'd5 && s == 3'd0),
              $sformatf("illegal buffer %0d transition %0d -> %0d", i, prev_st[i], s));
      end
      prev_st[i] <= s;
    end
  end

  // ---------------------------------------------------------------- negative tests
  task automatic wait_a(input int cnt); int g; g = 0; while (a_n < cnt && g < 5000) begin @(posedge clk); g++; end endtask
  task automatic wait_d(input int cnt); int g; g = 0; while (d_n < cnt && g < 5000) begin @(posedge clk); g++; end endtask
  task automatic neg_tests();
    int v0, r0;
    cur = "N negative tests";
    $display("[%0t] N1..N6 ownership / range rejections", $time);
    // -- N3 TensorCore access without ownership (no buffer in COMPUTE)
    v0 = int'(own_viol); a_n = 0;
    aq_row[aqt % QD] = RW'(1); aqt++;
    wait_a(1);
    check(a_gst[0] == `SF_ST_OWNER && a_got[0] === '0, "N3: TensorCore read without ownership must answer SF_ST_OWNER with rdata 0");
    check(int'(own_viol) == v0 + 1, "N3: violation not counted");
    // -- prepare: fill tile 0 into the next buffer, leave it READY
    fill_req = 1; while (!fill_grant) @(posedge clk); fill_req = 0;
    dma_fill(int'(fill_buf), 0);
    // -- N1/N4 while FILLING, N4: DMA read of C while FILLING and of A/B
    v0 = int'(own_viol); dma_acquire(); d_n = 0;
    dq_we[dqt % QD] = 0; dq_reg[dqt % QD] = 2'd2; dq_buf[dqt % QD] = fill_buf; dq_line[dqt % QD] = 0; dq_data[dqt % QD] = '0; dqt++;     // read C while FILLING
    dq_we[dqt % QD] = 0; dq_reg[dqt % QD] = 2'd0; dq_buf[dqt % QD] = fill_buf; dq_line[dqt % QD] = 0; dq_data[dqt % QD] = '0; dqt++;     // read A
    wait_d(2);
    check(d_gst[0] == `SF_ST_OWNER && d_gst[1] == `SF_ST_OWNER && d_got[0] === '0 && d_got[1] === '0, "N4: DMA read of C while FILLING / read of A must answer SF_ST_OWNER");
    check(int'(own_viol) == v0 + 2, "N4: violations not counted");
    dma_release();
    @(negedge clk); fill_done = 1; @(negedge clk); fill_done = 0;
    repeat (3) @(posedge clk);
    // buffer is READY now: N1 DMA write into READY buffer
    begin
      int rb;
      rb = (NBUF > 1) ? 0 : 0;
      v0 = int'(own_viol); dma_acquire(); d_n = 0;
      dq_we[dqt % QD] = 1; dq_reg[dqt % QD] = 2'd0; dq_buf[dqt % QD] = BUFW'(rb); dq_line[dqt % QD] = 0; dq_data[dqt % QD] = {LINE_W{1'b1}}; dqt++;
      dq_we[dqt % QD] = 1; dq_reg[dqt % QD] = 2'd2; dq_buf[dqt % QD] = BUFW'(rb); dq_line[dqt % QD] = 1; dq_data[dqt % QD] = {LINE_W{1'b1}}; dqt++;
      wait_d(2);
      check(d_gst[0] == `SF_ST_OWNER && d_gst[1] == `SF_ST_OWNER, "N1: DMA write into a READY buffer must answer SF_ST_OWNER");
      check(int'(own_viol) == v0 + 2, "N1: violations not counted");
      dma_release();
    end
    // -- compute it (N2: DMA write while COMPUTE, in the middle of the TE phase), then verify results via drain
    te_req = 1; while (!te_owned) @(posedge clk); te_req = 0;
    begin
      v0 = int'(own_viol);
      dma_acquire(); d_n = 0;
      dq_we[dqt % QD] = 1; dq_reg[dqt % QD] = 2'd1; dq_buf[dqt % QD] = te_buf; dq_line[dqt % QD] = 2; dq_data[dqt % QD] = {LINE_W{1'b1}}; dqt++;
      wait_d(1);
      check(d_gst[0] == `SF_ST_OWNER, "N2: DMA write into the COMPUTE buffer must answer SF_ST_OWNER");
      check(int'(own_viol) == v0 + 1, "N2: violation not counted");
      dma_release();
      // TE out-of-tile row (only expressible when N is not a power of two; otherwise skipped)
    end
    te_compute(0);
    @(negedge clk); te_done = 1; @(negedge clk); te_done = 0;
    drain_req = 1; while (!drain_grant) @(posedge clk); drain_req = 0;
    // N6: DMA write into a DRAINING buffer
    v0 = int'(own_viol); dma_acquire(); d_n = 0;
    dq_we[dqt % QD] = 1; dq_reg[dqt % QD] = 2'd2; dq_buf[dqt % QD] = drain_buf; dq_line[dqt % QD] = 0; dq_data[dqt % QD] = {LINE_W{1'b1}}; dqt++;
    // N5: DMA line beyond the tile
    r0 = int'(rng_viol);
    if (N != (1 << LW)) begin dq_we[dqt % QD] = 0; dq_reg[dqt % QD] = 2'd2; dq_buf[dqt % QD] = drain_buf; dq_line[dqt % QD] = LW'(N); dq_data[dqt % QD] = '0; dqt++; end
    dq_we[dqt % QD] = 0; dq_reg[dqt % QD] = 2'd3; dq_buf[dqt % QD] = drain_buf; dq_line[dqt % QD] = 0; dq_data[dqt % QD] = '0; dqt++;        // invalid region code
    wait_d((N != (1 << LW)) ? 3 : 2);
    check(d_gst[0] == `SF_ST_OWNER, "N6: DMA write into a DRAINING buffer must answer SF_ST_OWNER");
    check(d_gst[(N != (1 << LW)) ? 2 : 1] == `SF_ST_RANGE, "N5: invalid DMA region must answer SF_ST_RANGE");
    check(int'(own_viol) == v0 + 1, "N6: violation not counted");
    check(int'(rng_viol) >= r0 + 1, "N5: range violation not counted");
    dma_release();
    dma_drain(int'(drain_buf), 0);                                           // the rejected writes must not have changed anything
    @(negedge clk); drain_done = 1; @(negedge clk); drain_done = 0;
    repeat (4) @(posedge clk);
  endtask

  // ---------------------------------------------------------------- main
  int ev_f, ev_c, ev_d;
  longint c0;
  initial begin
    for (int i = 0; i < NBUF; i++) prev_st[i] = 3'd0;
    gen_tiles();
    repeat (6) @(posedge clk); rst_n = 1;
    repeat (CAP_LINES / NB + 12) @(posedge clk); while (!c_idle) @(posedge clk);
    $display("CONFIG NBUF=%0d NB=%0d SKEW=%0d N=%0d NTILES=%0d PASSES=%0d READ_LATENCY=%0d ECC_EN=%0d COMPUTE_EXTRA=%0d", NBUF, NB, SKEW, N, NTILES, PASSES, READ_LATENCY, ECC_EN, COMPUTE_EXTRA);
    neg_tests();
    check(int'(own_viol) >= 7, "expected the rejection tests to be counted");
    // ---- full pipeline
    cur = "P tile pipeline";
    $display("[%0t] P %0d tiles through %0d buffer(s)", $time, NTILES, NBUF);
    ev_f = 0; ev_c = 0; ev_d = 0;
    c0 = cycle;
    begin
      int conf0, busy0;
      conf0 = 0; for (int b = 0; b < NB; b++) conf0 += int'(perf_conf[b*32 +: 32]);
      busy0 = 0; for (int b = 0; b < NB; b++) busy0 += int'(perf_busy[b*32 +: 32]);
      run_pipe = 1'b1;                                  // the three processes below start together (no fork/join: Verilator 5.020 miscompiles it)
      wait (done_f && done_c && done_d);
      repeat (6) @(posedge clk);
      begin
        longint tot;
        int conf1, busy1;
        tot = cycle - c0;
        conf1 = 0; for (int b = 0; b < NB; b++) conf1 += int'(perf_conf[b*32 +: 32]);
        busy1 = 0; for (int b = 0; b < NB; b++) busy1 += int'(perf_busy[b*32 +: 32]);
        $display("BENCH tensor nbuf=%0d skew=%0d nb=%0d n=%0d tiles=%0d passes=%0d compute_extra=%0d read_latency=%0d ecc=%0d total_cycles=%0d cycles_per_tile=%0d overlap_cycles=%0d bank_conflict_cycles=%0d bank_busy_stalls=%0d",
                 NBUF, SKEW, NB, N, NTILES, PASSES, COMPUTE_EXTRA, READ_LATENCY, ECC_EN, tot, int'(tot) / NTILES, ovl_cycles, conf1 - conf0, busy1 - busy0);
      end
    end
    check(t_fill_done == NTILES && t_comp_done == NTILES && t_drain_done == NTILES, "not every tile completed all three phases");
    if (NBUF > 1) check(ovl_cycles > 0, "NBUF=2 but DMA and compute never overlapped");
    if (NBUF == 1) check(ovl_cycles == 0, "NBUF=1 must not overlap phases");
    $display("RESULT tb=tensor_scratchpad NBUF=%0d SKEW=%0d READ_LATENCY=%0d ECC_EN=%0d tiles=%0d checks=%0d errors=%0d owner_violations_counted=%0d %s",
             NBUF, SKEW, READ_LATENCY, ECC_EN, NTILES, n_checks, n_err, int'(own_viol), (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin
    #(64'd900_000_000);
    $display("RESULT tb=tensor_scratchpad errors=1 WATCHDOG TIMEOUT FAIL");
    $finish;
  end
endmodule
