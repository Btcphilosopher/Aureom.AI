// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_defs.svh
// Constants shared by every sf_* module.  A `define header and not a package:
// the repository's tool-portability rules (Yosys 0.33 cannot resolve package
// references in parameter lists; see third_party/PROVENANCE.md and the
// DataFabric PROTOCOL.md section 9) apply to all synthesizable RTL here.
// Values are part of the interface contract (docs/CONTRACT.md): never renumber.
// =============================================================================
`ifndef SF_SRAM_DEFS_SVH
`define SF_SRAM_DEFS_SVH

// ------------------------------------------------------------ response status (3 bits)
`define SF_ST_OK      3'd0   // completed normally (a corrected ECC error is still OK, see rsp_ce)
`define SF_ST_RANGE   3'd1   // address outside the SRAM aperture: no array access, no side effect
`define SF_ST_ALIGN   3'd2   // request not line aligned (ALIGN_MODE = 1): no array access, no side effect
`define SF_ST_ECC_UE  3'd3   // uncorrectable ECC error: read data is the stored (uncorrected) word; a partial write was ABORTED
`define SF_ST_OWNER   3'd4   // scratchpad ownership violation (tensor scratchpad): no side effect
`define SF_ST_BADOP   3'd5   // unsupported operation / opcode (adapters)

// ------------------------------------------------------------ read-during-write policy of sf_sram_core
`define SF_RDW_READ_FIRST   0  // output register gets the OLD contents of the addressed row
`define SF_RDW_WRITE_FIRST  1  // output register gets the NEW contents (written bytes merged)
`define SF_RDW_NO_CHANGE    2  // output register keeps its previous value on a write cycle

// ------------------------------------------------------------ arbitration
`define SF_ARB_FIXED   0       // master 0 highest; lower masters can starve (documented)
`define SF_ARB_RR      1       // per-bank round robin; waiting bound NM-1 grants

// ------------------------------------------------------------ memory backends (sf_sram_macro_wrapper)
`define SF_BACKEND_BEHAV  0    // behavioural RTL array (simulation, formal, logic synthesis to flops/BRAM)
`define SF_BACKEND_FPGA   1    // inferred block RAM template
`define SF_BACKEND_ASIC   2    // hard macro tiling (requires macro collateral; see physical/asic_readiness.md)

// ------------------------------------------------------------ sim-only fault models (sf_sram_core FAULT_INJECT=1)
`define SF_FT_NONE   4'd0
`define SF_FT_SAF    4'd1      // stuck-at: cell (fi_row,fi_bit) reads fi_val regardless of what was written
`define SF_FT_TF     4'd2      // transition fault: fi_val=1 -> 0->1 transition fails; fi_val=0 -> 1->0 fails
`define SF_FT_AF_NA  4'd3      // address decoder: address fi_row reaches no cell (write lost, read 0)
`define SF_FT_AF_ALI 4'd4      // address decoder: address fi_row is aliased to fi_row2 (own cell never accessed)
`define SF_FT_AF_MUL 4'd5      // address decoder: address fi_row reaches its own cell AND fi_row2 (write both, read OR)
`define SF_FT_CFIN   4'd6      // inversion coupling: aggressor (fi_row,fi_bit) transition to fi_val inverts victim (fi_row2,fi_bit2)
`define SF_FT_CFID   4'd7      // idempotent coupling: aggressor transition to fi_val forces victim to fi_val2
`define SF_FT_CFST   4'd8      // state coupling: while aggressor == fi_val the victim reads fi_val2

// ------------------------------------------------------------ ECC event source (bank ev_kind)
`define SF_EVK_READ   2'd0
`define SF_EVK_RMW    2'd1
`define SF_EVK_SCRUB  2'd2

// ------------------------------------------------------------ ECC classes (sf_ecc_dec class_o)
`define SF_ECC_NONE        3'd0
`define SF_ECC_CE_DATA     3'd1   // single-bit error in a data bit, corrected
`define SF_ECC_CE_CHECK    3'd2   // single-bit error in a check / parity bit, corrected (data untouched)
`define SF_ECC_UE_DOUBLE   3'd3   // double (even-weight) error detected
`define SF_ECC_UE_INVALID  3'd4   // syndrome names no bit: >=3 errors detected

// ------------------------------------------------------------ configuration errors (elaboration time)
`ifdef __ICARUS__
  `define SF_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SF_CFG_FATAL(msg) $fatal(1, msg);
`endif

// ------------------------------------------------------------ embedded checkers
// SF_ASSERT enables simulation assertions; FORMAL turns the same checks into formal assertions.
`ifdef FORMAL
  `define SF_CHK(cond, msg) assert (cond);
`else
  `ifdef SF_ASSERT
    `define SF_CHK(cond, msg) assert (cond) else $error(msg);
  `else
    `define SF_CHK(cond, msg)
  `endif
`endif

`endif // SF_SRAM_DEFS_SVH
