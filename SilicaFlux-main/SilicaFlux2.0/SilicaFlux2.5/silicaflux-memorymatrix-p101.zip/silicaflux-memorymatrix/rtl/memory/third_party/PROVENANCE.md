# PROVENANCE of the reused SilicaFlux modules

Every file under `rtl/memory/third_party/` is a **byte-identical copy** of a file in the repository's existing SilicaFlux archives (checked with `cmp` / SHA-256, list in `SHA256SUMS`).
None was edited. They are copied (not referenced) so that this package builds on its own.

| copied to | origin (archive inside the repository, path inside the archive) |
|---|---|
| `memorycore/rtl/*.sv, *.svh` (`sf_sram_core`, `sf_sram_bank`, `sf_sram_macro_wrapper`, `sf_sram_controller`, `sf_ecc_enc/dec/counters`, `sf_sync_fifo`, `sf_sram_defs.svh`, `sf_vector_scratchpad`, `sf_ts_port`, `sf_tensor_scratchpad`) | `SilicaFlux-main/silicaflux-memorycore-sram.zip` : `silicaflux-memorycore-sram/rtl/` (identical copy at `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memorycore-sram.zip`, SHA-256 of the archive `b6a9b5ed0adb51915a954f67e8a69e4915e2b515d15bb77d4797ca2398807771`) |
| `memorycore/rtl/backends/*.sv` | same archive, `.../rtl/backends/` |
| `memorycore/sim_models/sky130_sram_standin.sv` | same archive, `.../sim_models/` (a **stand-in**, not the vendor model) |
| `memorycore/tb/tb_vector_scratchpad.sv`, `tb_tensor_scratchpad.sv` | same archive, `.../tb/` (the originals; `tests/memory_matrix/make_integration_tb.py` generates the matrix variants from them) |
| `ras_secded/*` | same archive, `.../third_party/ras_secded/` (itself reused by that archive from the RAS project, as its own PROVENANCE states) |

Licence: no licence file is present in the source archives; the files are reused under the same terms as the rest of the SilicaFlux repository, which are not stated here.
