// =============================================================================
// SilicaFlux MemoryCore :: sf_sync_fifo
// Small synchronous first-word-fall-through FIFO (flop based, any DEPTH >= 2) used for per-port transaction
// metadata and DMA stream staging.  Push when !full, pop when !empty; push and pop in the same cycle are legal
// (also when full: the pop frees the slot only for the NEXT cycle, i.e. full blocks push).  No reset of the storage.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sync_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 4,
  parameter int CW    = $clog2(DEPTH + 1),
  parameter int PW    = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         clr_i,        // synchronous flush
  input  wire logic         push_i,
  input  wire logic [W-1:0] din_i,
  input  wire logic         pop_i,
  output logic [W-1:0]      dout_o,       // valid when !empty_o
  output logic              empty_o,
  output logic              full_o,
  output logic [CW-1:0]     count_o
);
  if (DEPTH < 2) begin : g_err
    `SF_CFG_FATAL("sf_sync_fifo: DEPTH must be >= 2")
  end
  logic [W-1:0] mem [0:DEPTH-1];
  logic [PW-1:0] rp, wp;
  logic [CW-1:0] cnt;
  wire do_push = push_i & ~full_o;
  wire do_pop  = pop_i & ~empty_o;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rp <= '0; wp <= '0; cnt <= '0; end
    else if (clr_i) begin rp <= '0; wp <= '0; cnt <= '0; end
    else begin
      if (do_push) wp <= (wp == PW'(DEPTH - 1)) ? '0 : wp + 1'b1;
      if (do_pop)  rp <= (rp == PW'(DEPTH - 1)) ? '0 : rp + 1'b1;
      cnt <= cnt + CW'(do_push) - CW'(do_pop);
    end
  end
  always_ff @(posedge clk) if (do_push) mem[wp] <= din_i;
  assign dout_o  = mem[rp];
  assign empty_o = (cnt == '0);
  assign full_o  = (cnt == CW'(DEPTH));
  assign count_o = cnt;
endmodule

`default_nettype wire
