// =============================================================================
// SilicaFlux MemoryCore :: sf_tensor_scratchpad
// Operand / partial-sum storage for the TensorCore on top of the banked SRAM controller.
//
// ---------------------------------------------------------------- storage layout (in controller lines)
//   Three regions, NBUF buffers each:  A operand tile (A_ROWS x A_LPR lines), B operand tile (B_ROWS x B_LPR), C partial
//   sums (C_ROWS x C_LPR).  A tile line = row * LPR + col  ("tile addressing": the TensorCore gives (row, col)).
//   Region base for buffer b:  BASE_LINE + R_OFF + b * R_STR,  R_STR = tile lines rounded up to a multiple of NB.
//   SKEW = 1 shifts the regions by 0 / 1 / 2 banks (A / B / C): a lock-step stream A[k], B[k], C[k] then hits THREE
//   DIFFERENT banks every cycle and never self-conflicts (SKEW = 0 puts all three on the same bank sequence: measured in
//   the benchmarks).  FOOT_LINES must fit the aperture (checked at elaboration).
//
// ---------------------------------------------------------------- ownership (hardware enforced)
//   Every buffer (one A + one B + one C tile) is in exactly one state:
//     FREE -> FILLING (DMA writes A, B and initial C) -> READY -> COMPUTE (TensorCore reads A, B, reads/writes C)
//          -> DONE (C holds the result) -> DRAINING (DMA reads C) -> FREE
//   Tiles are used in ring order (fill_ptr, comp_ptr, drain_ptr advance modulo NBUF), so tile order is preserved.
//   Requests (level-sensitive): fill_req_i, te_req_i, drain_req_i; grant outputs name the buffer.  *_done_i pulses end
//   an ownership phase, but a phase ends only after every access the owner issued has been ACKNOWLEDGED by the SRAM
//   (completion = data is committed): READY therefore implies the tile is fully visible; DONE implies every partial sum
//   was written.  Access rules (violations are REJECTED: no SRAM access, status SF_ST_OWNER / SF_ST_RANGE, counted):
//     DMA write A/B/C : buffer must be FILLING        DMA read C : buffer must be DRAINING     DMA read A/B : never
//     TensorCore A/B read, C read/write : te_owned (a buffer in COMPUTE) and the (row, col) inside the tile
//   => a DMA prefetch can NEVER overwrite operands of a buffer that is READY or being computed on, and a drain can never see
//   a half-written C.  With NBUF = 1 the phases are strictly sequential (single buffering); NBUF = 2 overlaps DMA of tile
//   n+1 with compute of tile n (ping-pong).
//
// ---------------------------------------------------------------- ports to the controller
//   4 master ports: 0 = A (TensorCore read), 1 = B (TensorCore read), 2 = C (TensorCore read/write), 3 = DMA.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_tensor_scratchpad #(
  parameter int AW         = 32,
  parameter int NB         = 4,
  parameter int CAP_LINES  = 1024,
  parameter int BASE_LINE  = 0,
  parameter int LINE_W     = 128,
  parameter int NBUF       = 2,
  parameter int A_ROWS     = 4, parameter int A_LPR = 1,
  parameter int B_ROWS     = 4, parameter int B_LPR = 1,
  parameter int C_ROWS     = 4, parameter int C_LPR = 1,
  parameter int SKEW       = 1,
  parameter int META_DEPTH = 8,
  parameter int CNT_W      = 16,
  // ---- derived
  parameter int A_LINES    = A_ROWS * A_LPR,
  parameter int B_LINES    = B_ROWS * B_LPR,
  parameter int C_LINES    = C_ROWS * C_LPR,
  parameter int MAXL       = (A_LINES > B_LINES) ? ((A_LINES > C_LINES) ? A_LINES : C_LINES) : ((B_LINES > C_LINES) ? B_LINES : C_LINES),
  parameter int LW         = (MAXL > 1) ? $clog2(MAXL) : 1,
  parameter int BUFW       = (NBUF > 1) ? $clog2(NBUF) : 1,
  parameter int A_RW       = (A_ROWS > 1) ? $clog2(A_ROWS) : 1, parameter int A_CW = (A_LPR > 1) ? $clog2(A_LPR) : 1,
  parameter int B_RW       = (B_ROWS > 1) ? $clog2(B_ROWS) : 1, parameter int B_CW = (B_LPR > 1) ? $clog2(B_LPR) : 1,
  parameter int C_RW       = (C_ROWS > 1) ? $clog2(C_ROWS) : 1, parameter int C_CW = (C_LPR > 1) ? $clog2(C_LPR) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------------- ownership / completion
  input  wire logic                   fill_req_i,
  input  wire logic                   fill_done_i,
  output logic                        fill_grant_o,
  output logic [BUFW-1:0]             fill_buf_o,
  input  wire logic                   te_req_i,
  input  wire logic                   te_done_i,
  output logic                        te_owned_o,
  output logic [BUFW-1:0]             te_buf_o,
  input  wire logic                   drain_req_i,
  input  wire logic                   drain_done_i,
  output logic                        drain_grant_o,
  output logic [BUFW-1:0]             drain_buf_o,
  output logic [NBUF*3-1:0]           buf_state_o,          // FREE 0, FILLING 1, READY 2, COMPUTE 3, DONE 4, DRAINING 5
  output logic                        ev_fill_complete_o,   // pulse: a tile became READY
  output logic                        ev_compute_complete_o,// pulse: a tile became DONE
  output logic                        ev_drain_complete_o,  // pulse: a buffer became FREE
  output logic                        irq_o,
  output logic [CNT_W-1:0]            owner_viol_cnt_o,
  output logic [CNT_W-1:0]            range_viol_cnt_o,
  // ---------------------------------------------------------------- TensorCore ports
  input  wire logic                   a_req_valid,
  output logic                        a_req_ready,
  input  wire logic [A_RW-1:0]        a_req_row,
  input  wire logic [A_CW-1:0]        a_req_col,
  output logic                        a_rsp_valid,
  input  wire logic                   a_rsp_ready,
  output logic [LINE_W-1:0]           a_rsp_data,
  output logic [2:0]                  a_rsp_status,
  input  wire logic                   b_req_valid,
  output logic                        b_req_ready,
  input  wire logic [B_RW-1:0]        b_req_row,
  input  wire logic [B_CW-1:0]        b_req_col,
  output logic                        b_rsp_valid,
  input  wire logic                   b_rsp_ready,
  output logic [LINE_W-1:0]           b_rsp_data,
  output logic [2:0]                  b_rsp_status,
  input  wire logic                   c_req_valid,
  output logic                        c_req_ready,
  input  wire logic                   c_req_we,
  input  wire logic [C_RW-1:0]        c_req_row,
  input  wire logic [C_CW-1:0]        c_req_col,
  input  wire logic [LINE_W-1:0]      c_req_wdata,
  input  wire logic [LINE_W/8-1:0]    c_req_be,
  output logic                        c_rsp_valid,
  input  wire logic                   c_rsp_ready,
  output logic [LINE_W-1:0]           c_rsp_data,
  output logic                        c_rsp_we,
  output logic [2:0]                  c_rsp_status,
  // ---------------------------------------------------------------- DMA port
  input  wire logic                   d_req_valid,
  output logic                        d_req_ready,
  input  wire logic                   d_req_we,
  input  wire logic [1:0]             d_req_region,        // 0 A, 1 B, 2 C
  input  wire logic [BUFW-1:0]        d_req_buf,
  input  wire logic [LW-1:0]          d_req_line,
  input  wire logic [LINE_W-1:0]      d_req_wdata,
  input  wire logic [LINE_W/8-1:0]    d_req_be,
  output logic                        d_rsp_valid,
  input  wire logic                   d_rsp_ready,
  output logic [LINE_W-1:0]           d_rsp_data,
  output logic                        d_rsp_we,
  output logic [2:0]                  d_rsp_status,
  // ---------------------------------------------------------------- controller master ports (4)
  output logic [3:0]                  m_req_valid,
  input  wire logic [3:0]             m_req_ready,
  output logic [3:0]                  m_req_we,
  output logic [4*AW-1:0]             m_req_addr,
  output logic [4*LINE_W-1:0]         m_req_wdata,
  output logic [4*(LINE_W/8)-1:0]     m_req_be,
  input  wire logic [3:0]             m_rsp_valid,
  output logic [3:0]                  m_rsp_ready,
  input  wire logic [4*LINE_W-1:0]    m_rsp_rdata,
  input  wire logic [4*3-1:0]         m_rsp_status
);
  localparam int LB = 4;
  // ------------------------------------------------------------ layout
  function automatic integer align_up(input integer x, input integer n);
    align_up = ((x + n - 1) / n) * n;
  endfunction
  localparam int A_STR = align_up(A_LINES, NB);
  localparam int B_STR = align_up(B_LINES, NB);
  localparam int C_STR = align_up(C_LINES, NB);
  localparam int A_OFF = 0;
  localparam int B_OFF = align_up(A_OFF + NBUF * A_STR, NB) + ((SKEW != 0) ? (1 % NB) : 0);
  localparam int C_OFF = align_up(B_OFF + NBUF * B_STR, NB) + ((SKEW != 0) ? (2 % NB) : 0);
  localparam int FOOT_LINES = C_OFF + NBUF * C_STR;
  localparam logic [AW-1:0] REJECT_ADDR = {{(AW-LB){1'b1}}, {LB{1'b0}}};

  if (NBUF != 1 && NBUF != 2) begin : g_err_nbuf
    `SF_CFG_FATAL("sf_tensor_scratchpad: NBUF must be 1 (single buffer) or 2 (ping-pong)")
  end
  if (BASE_LINE + FOOT_LINES > CAP_LINES) begin : g_err_foot
    `SF_CFG_FATAL("sf_tensor_scratchpad: the tile buffers do not fit the aperture")
  end
  if (CAP_LINES >= (1 << (AW - LB))) begin : g_err_cap
    `SF_CFG_FATAL("sf_tensor_scratchpad: aperture must be smaller than the address space (rejects are redirected beyond it)")
  end


  // ------------------------------------------------------------ buffer state machine
  localparam logic [2:0] S_FREE = 3'd0, S_FILLING = 3'd1, S_READY = 3'd2, S_COMPUTE = 3'd3, S_DONE = 3'd4, S_DRAINING = 3'd5;
  logic [2:0] bst [NBUF];
  logic [BUFW-1:0] fill_ptr, comp_ptr, drain_ptr;
  logic            fill_v, te_v, drain_v;
  logic [BUFW-1:0] fill_b, te_b, drain_b;
  logic            fill_fin_pend, te_fin_pend, drain_fin_pend;
  wire  [$clog2(META_DEPTH + 1)-1:0] out_a, out_b, out_c, out_d;
  wire te_idle   = (out_a == '0) && (out_b == '0) && (out_c == '0);
  // DMA outstanding accesses, split by EFFECTIVE type (a rejected write is carried as a read): a fill completes when its
  // WRITES are acknowledged, a drain when its READS are, independent of the other role's traffic
  localparam int DC = $clog2(META_DEPTH + 1);
  logic [DC-1:0] dwr, drd;
  wire dma_wr_idle = (dwr == '0);
  wire dma_rd_idle = (drd == '0);

  assign fill_grant_o = fill_v;  assign fill_buf_o = fill_b;
  assign te_owned_o   = te_v;    assign te_buf_o   = te_b;
  assign drain_grant_o = drain_v; assign drain_buf_o = drain_b;
  always_comb begin
    for (int i = 0; i < NBUF; i++) buf_state_o[i*3 +: 3] = bst[i];
  end

  wire d_wr_acc  = d_req_valid & d_req_ready & d_req_we & (d_rej == 2'd0);
  wire d_rd_acc  = d_req_valid & d_req_ready & ~(d_req_we & (d_rej == 2'd0));
  wire fill_fin  = fill_v & (fill_done_i | fill_fin_pend) & dma_wr_idle & ~d_wr_acc;
  wire te_fin    = te_v & (te_done_i | te_fin_pend) & te_idle & ~((a_req_valid & a_req_ready) | (b_req_valid & b_req_ready) | (c_req_valid & c_req_ready));
  wire drain_fin = drain_v & (drain_done_i | drain_fin_pend) & dma_rd_idle & ~d_rd_acc;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NBUF; i++) bst[i] <= S_FREE;
      fill_ptr <= '0; comp_ptr <= '0; drain_ptr <= '0;
      fill_v <= 1'b0; te_v <= 1'b0; drain_v <= 1'b0; fill_b <= '0; te_b <= '0; drain_b <= '0;
      fill_fin_pend <= 1'b0; te_fin_pend <= 1'b0; drain_fin_pend <= 1'b0;
      ev_fill_complete_o <= 1'b0; ev_compute_complete_o <= 1'b0; ev_drain_complete_o <= 1'b0;
    end else begin
      ev_fill_complete_o <= 1'b0; ev_compute_complete_o <= 1'b0; ev_drain_complete_o <= 1'b0;
      // ---- grants (ring order)
      if (fill_req_i && !fill_v && bst[fill_ptr] == S_FREE) begin
        bst[fill_ptr] <= S_FILLING; fill_v <= 1'b1; fill_b <= fill_ptr;
      end
      if (te_req_i && !te_v && bst[comp_ptr] == S_READY) begin
        bst[comp_ptr] <= S_COMPUTE; te_v <= 1'b1; te_b <= comp_ptr;
      end
      if (drain_req_i && !drain_v && bst[drain_ptr] == S_DONE) begin
        bst[drain_ptr] <= S_DRAINING; drain_v <= 1'b1; drain_b <= drain_ptr;
      end
      // ---- completion: only after every access of the owner was acknowledged
      if (fill_v && fill_done_i && !fill_fin) fill_fin_pend <= 1'b1;
      if (te_v && te_done_i && !te_fin) te_fin_pend <= 1'b1;
      if (drain_v && drain_done_i && !drain_fin) drain_fin_pend <= 1'b1;
      if (fill_fin) begin
        bst[fill_b] <= S_READY; fill_v <= 1'b0; fill_fin_pend <= 1'b0; ev_fill_complete_o <= 1'b1;
        fill_ptr <= (fill_ptr == BUFW'(NBUF - 1)) ? '0 : fill_ptr + 1'b1;
      end
      if (te_fin) begin
        bst[te_b] <= S_DONE; te_v <= 1'b0; te_fin_pend <= 1'b0; ev_compute_complete_o <= 1'b1;
        comp_ptr <= (comp_ptr == BUFW'(NBUF - 1)) ? '0 : comp_ptr + 1'b1;
      end
      if (drain_fin) begin
        bst[drain_b] <= S_FREE; drain_v <= 1'b0; drain_fin_pend <= 1'b0; ev_drain_complete_o <= 1'b1;
        drain_ptr <= (drain_ptr == BUFW'(NBUF - 1)) ? '0 : drain_ptr + 1'b1;
      end
    end
  end
  wire d_rsp_fire = d_rsp_valid & d_rsp_ready;
  wire d_wr_fin   = d_rsp_fire & d_rsp_we;
  wire d_rd_fin   = d_rsp_fire & ~d_rsp_we;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin dwr <= '0; drd <= '0; end
    else begin
      dwr <= dwr + DC'(d_wr_acc) - DC'(d_wr_fin);
      drd <= drd + DC'(d_rd_acc) - DC'(d_rd_fin);
    end
  end
  assign irq_o = ev_fill_complete_o | ev_compute_complete_o | ev_drain_complete_o;

  // ------------------------------------------------------------ TensorCore request checks + addresses
  logic [AW-1:0] a_addr, b_addr, c_addr, d_addr;
  logic [1:0]    a_rej, b_rej, c_rej, d_rej;
  always_comb begin
    integer tb_i;
    tb_i = {{(32-BUFW){1'b0}}, te_b};
    a_rej = 2'd0; b_rej = 2'd0; c_rej = 2'd0;
    // A
    if (!te_v) a_rej = 2'd1;
    else if (A_ROWS != (1 << A_RW) && {{(32-A_RW){1'b0}}, a_req_row} >= A_ROWS) a_rej = 2'd2;
    else if (A_LPR  != (1 << A_CW) && {{(32-A_CW){1'b0}}, a_req_col} >= A_LPR)  a_rej = 2'd2;
    a_addr = AW'(BASE_LINE + A_OFF + tb_i * A_STR + {{(32-A_RW){1'b0}}, a_req_row} * A_LPR + {{(32-A_CW){1'b0}}, a_req_col}) << LB;
    // B
    if (!te_v) b_rej = 2'd1;
    else if (B_ROWS != (1 << B_RW) && {{(32-B_RW){1'b0}}, b_req_row} >= B_ROWS) b_rej = 2'd2;
    else if (B_LPR  != (1 << B_CW) && {{(32-B_CW){1'b0}}, b_req_col} >= B_LPR)  b_rej = 2'd2;
    b_addr = AW'(BASE_LINE + B_OFF + tb_i * B_STR + {{(32-B_RW){1'b0}}, b_req_row} * B_LPR + {{(32-B_CW){1'b0}}, b_req_col}) << LB;
    // C
    if (!te_v) c_rej = 2'd1;
    else if (C_ROWS != (1 << C_RW) && {{(32-C_RW){1'b0}}, c_req_row} >= C_ROWS) c_rej = 2'd2;
    else if (C_LPR  != (1 << C_CW) && {{(32-C_CW){1'b0}}, c_req_col} >= C_LPR)  c_rej = 2'd2;
    c_addr = AW'(BASE_LINE + C_OFF + tb_i * C_STR + {{(32-C_RW){1'b0}}, c_req_row} * C_LPR + {{(32-C_CW){1'b0}}, c_req_col}) << LB;
  end

  // ------------------------------------------------------------ DMA request checks
  always_comb begin
    integer region_lines, roff, rstr;
    d_rej = 2'd0;
    case (d_req_region)
      2'd0: begin region_lines = A_LINES; roff = A_OFF; rstr = A_STR; end
      2'd1: begin region_lines = B_LINES; roff = B_OFF; rstr = B_STR; end
      default: begin region_lines = C_LINES; roff = C_OFF; rstr = C_STR; end
    endcase
    if (d_req_region == 2'd3 || ({{(32-BUFW){1'b0}}, d_req_buf} >= NBUF) || ({{(32-LW){1'b0}}, d_req_line} >= region_lines)) d_rej = 2'd2;
    else if (d_req_we) begin
      if (bst[d_req_buf] != S_FILLING) d_rej = 2'd1;
    end else begin
      if (d_req_region != 2'd2 || bst[d_req_buf] != S_DRAINING) d_rej = 2'd1;
    end
    d_addr = AW'((BASE_LINE + roff + {{(32-BUFW){1'b0}}, d_req_buf} * rstr + {{(32-LW){1'b0}}, d_req_line})) << LB;
  end

  // violation counters (counted when the rejected request is ACCEPTED by its port)
  wire a_acc = a_req_valid & a_req_ready, b_acc = b_req_valid & b_req_ready, c_acc = c_req_valid & c_req_ready, d_acc = d_req_valid & d_req_ready;
  wire a_own = a_acc & (a_rej == 2'd1), b_own = b_acc & (b_rej == 2'd1), c_own = c_acc & (c_rej == 2'd1), d_own = d_acc & (d_rej == 2'd1);
  wire a_rng = a_acc & (a_rej == 2'd2), b_rng = b_acc & (b_rej == 2'd2), c_rng = c_acc & (c_rej == 2'd2), d_rng = d_acc & (d_rej == 2'd2);
  wire [2:0] own_inc = {2'b00, a_own} + {2'b00, b_own} + {2'b00, c_own} + {2'b00, d_own};
  wire [2:0] rng_inc = {2'b00, a_rng} + {2'b00, b_rng} + {2'b00, c_rng} + {2'b00, d_rng};
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin owner_viol_cnt_o <= '0; range_viol_cnt_o <= '0; end
    else begin
      if (own_inc != 3'd0 && owner_viol_cnt_o != {CNT_W{1'b1}}) owner_viol_cnt_o <= owner_viol_cnt_o + CNT_W'(own_inc);
      if (rng_inc != 3'd0 && range_viol_cnt_o != {CNT_W{1'b1}}) range_viol_cnt_o <= range_viol_cnt_o + CNT_W'(rng_inc);
    end
  end

  // ------------------------------------------------------------ ports
  wire [LINE_W/8-1:0] ones = '1;
  wire a_rsp_we_u, b_rsp_we_u;
  sf_ts_port #(.AW(AW), .LINE_W(LINE_W), .DEPTH(META_DEPTH), .REJECT_ADDR(REJECT_ADDR)) u_pa (
    .clk(clk), .rst_n(rst_n), .req_valid(a_req_valid), .req_ready(a_req_ready), .req_we(1'b0), .req_addr(a_addr), .req_wdata('0),
    .req_be(ones), .req_rej(a_rej), .rsp_valid(a_rsp_valid), .rsp_ready(a_rsp_ready), .rsp_rdata(a_rsp_data), .rsp_we(a_rsp_we_u),
    .rsp_status(a_rsp_status), .c_req_valid(m_req_valid[0]), .c_req_ready(m_req_ready[0]), .c_req_we(m_req_we[0]),
    .c_req_addr(m_req_addr[0*AW +: AW]), .c_req_wdata(m_req_wdata[0*LINE_W +: LINE_W]), .c_req_be(m_req_be[0*(LINE_W/8) +: LINE_W/8]),
    .c_rsp_valid(m_rsp_valid[0]), .c_rsp_ready(m_rsp_ready[0]), .c_rsp_rdata(m_rsp_rdata[0*LINE_W +: LINE_W]),
    .c_rsp_status(m_rsp_status[0*3 +: 3]), .out_cnt_o(out_a));
  sf_ts_port #(.AW(AW), .LINE_W(LINE_W), .DEPTH(META_DEPTH), .REJECT_ADDR(REJECT_ADDR)) u_pb (
    .clk(clk), .rst_n(rst_n), .req_valid(b_req_valid), .req_ready(b_req_ready), .req_we(1'b0), .req_addr(b_addr), .req_wdata('0),
    .req_be(ones), .req_rej(b_rej), .rsp_valid(b_rsp_valid), .rsp_ready(b_rsp_ready), .rsp_rdata(b_rsp_data), .rsp_we(b_rsp_we_u),
    .rsp_status(b_rsp_status), .c_req_valid(m_req_valid[1]), .c_req_ready(m_req_ready[1]), .c_req_we(m_req_we[1]),
    .c_req_addr(m_req_addr[1*AW +: AW]), .c_req_wdata(m_req_wdata[1*LINE_W +: LINE_W]), .c_req_be(m_req_be[1*(LINE_W/8) +: LINE_W/8]),
    .c_rsp_valid(m_rsp_valid[1]), .c_rsp_ready(m_rsp_ready[1]), .c_rsp_rdata(m_rsp_rdata[1*LINE_W +: LINE_W]),
    .c_rsp_status(m_rsp_status[1*3 +: 3]), .out_cnt_o(out_b));
  sf_ts_port #(.AW(AW), .LINE_W(LINE_W), .DEPTH(META_DEPTH), .REJECT_ADDR(REJECT_ADDR)) u_pc (
    .clk(clk), .rst_n(rst_n), .req_valid(c_req_valid), .req_ready(c_req_ready), .req_we(c_req_we), .req_addr(c_addr), .req_wdata(c_req_wdata),
    .req_be(c_req_be), .req_rej(c_rej), .rsp_valid(c_rsp_valid), .rsp_ready(c_rsp_ready), .rsp_rdata(c_rsp_data), .rsp_we(c_rsp_we),
    .rsp_status(c_rsp_status), .c_req_valid(m_req_valid[2]), .c_req_ready(m_req_ready[2]), .c_req_we(m_req_we[2]),
    .c_req_addr(m_req_addr[2*AW +: AW]), .c_req_wdata(m_req_wdata[2*LINE_W +: LINE_W]), .c_req_be(m_req_be[2*(LINE_W/8) +: LINE_W/8]),
    .c_rsp_valid(m_rsp_valid[2]), .c_rsp_ready(m_rsp_ready[2]), .c_rsp_rdata(m_rsp_rdata[2*LINE_W +: LINE_W]),
    .c_rsp_status(m_rsp_status[2*3 +: 3]), .out_cnt_o(out_c));
  sf_ts_port #(.AW(AW), .LINE_W(LINE_W), .DEPTH(META_DEPTH), .REJECT_ADDR(REJECT_ADDR)) u_pd (
    .clk(clk), .rst_n(rst_n), .req_valid(d_req_valid), .req_ready(d_req_ready), .req_we(d_req_we), .req_addr(d_addr), .req_wdata(d_req_wdata),
    .req_be(d_req_be), .req_rej(d_rej), .rsp_valid(d_rsp_valid), .rsp_ready(d_rsp_ready), .rsp_rdata(d_rsp_data), .rsp_we(d_rsp_we),
    .rsp_status(d_rsp_status), .c_req_valid(m_req_valid[3]), .c_req_ready(m_req_ready[3]), .c_req_we(m_req_we[3]),
    .c_req_addr(m_req_addr[3*AW +: AW]), .c_req_wdata(m_req_wdata[3*LINE_W +: LINE_W]), .c_req_be(m_req_be[3*(LINE_W/8) +: LINE_W/8]),
    .c_rsp_valid(m_rsp_valid[3]), .c_rsp_ready(m_rsp_ready[3]), .c_rsp_rdata(m_rsp_rdata[3*LINE_W +: LINE_W]),
    .c_rsp_status(m_rsp_status[3*3 +: 3]), .out_cnt_o(out_d));
  wire unused_ok = &{1'b0, out_d, a_rsp_we_u, b_rsp_we_u};
endmodule

`default_nettype wire
