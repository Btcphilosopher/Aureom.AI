// =============================================================================
// SilicaFlux MemoryCore :: sf_sram_fpga_bram   (backend B of sf_sram_macro_wrapper)
// FPGA block-RAM inference template: single-port, byte-write enables, synchronous read,
// optional $readmemh image.  READ-FIRST write mode (the mode every FPGA family infers for a
// read register in the same process as a masked write).  Same port list and result timing as
// sf_sram_core (result visible READ_LATENCY cycles after the accepting edge).
//
// EVIDENCE LIMIT: this is an inference TEMPLATE.  Yosys can be asked to map it to a block-RAM
// primitive (syn/ reports show the $mem cell), but no FPGA bitstream was built and nothing ran on
// a board.  FPGA-inferred memory is NOT evidence of ASIC readiness (physical/asic_readiness.md).
// Classification: SYNTHESIZABLE (FPGA)
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_fpga_bram #(
  parameter int DEPTH        = 1024,
  parameter int DATA_W       = 128,
  parameter int BE_W         = DATA_W / 8,
  parameter int READ_LATENCY = 1,
  parameter int TAG_W        = 1,
  parameter INIT_FILE = "",
  parameter int AW           = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              en,
  input  wire logic              we,
  input  wire logic [AW-1:0]     addr,
  input  wire logic [DATA_W-1:0] wdata,
  input  wire logic [BE_W-1:0]   be,
  input  wire logic [TAG_W-1:0]  tag_i,
  output logic                   rvalid,
  output logic                   rwe,
  output logic [TAG_W-1:0]       rtag,
  output logic [DATA_W-1:0]      rdata
);
  localparam int LANE_W = DATA_W / BE_W;
  if (READ_LATENCY < 1)               begin : g_e1 `SF_CFG_FATAL("sf_sram_fpga_bram: READ_LATENCY must be >= 1") end
  if (DATA_W < 1 || (DATA_W % BE_W) != 0) begin : g_e2 `SF_CFG_FATAL("sf_sram_fpga_bram: DATA_W must be a multiple of BE_W") end

  (* ram_style = "block" *) logic [DATA_W-1:0] mem [0:DEPTH-1];
  logic [DATA_W-1:0] rd0;

`ifndef SYNTHESIS
  if (INIT_FILE != "") begin : g_init
    initial $readmemh(INIT_FILE, mem);
  end
`endif

  always_ff @(posedge clk) begin
    if (en) begin
      if (we) begin
        for (int l = 0; l < BE_W; l++)
          if (be[l]) mem[addr][l*LANE_W +: LANE_W] <= wdata[l*LANE_W +: LANE_W];
      end
      rd0 <= mem[addr];                                  // READ_FIRST
    end
  end

  logic [READ_LATENCY-1:0] vpipe, wpipe;
  logic [TAG_W-1:0] tpipe [0:READ_LATENCY-1];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin vpipe <= '0; wpipe <= '0; end
    else begin
      vpipe[0] <= en; wpipe[0] <= we;
      for (int s = 1; s < READ_LATENCY; s++) begin vpipe[s] <= vpipe[s-1]; wpipe[s] <= wpipe[s-1]; end
    end
  end
  always_ff @(posedge clk) begin
    tpipe[0] <= tag_i;
    for (int s = 1; s < READ_LATENCY; s++) tpipe[s] <= tpipe[s-1];
  end
  if (READ_LATENCY == 1) begin : g_l1
    assign rdata = rd0;
  end else begin : g_ln
    logic [DATA_W-1:0] dq [1:READ_LATENCY-1];
    always_ff @(posedge clk) begin
      dq[1] <= rd0;
      for (int s = 2; s < READ_LATENCY; s++) dq[s] <= dq[s-1];
    end
    assign rdata = dq[READ_LATENCY-1];
  end
  assign rvalid = vpipe[READ_LATENCY-1];
  assign rwe    = wpipe[READ_LATENCY-1];
  assign rtag   = tpipe[READ_LATENCY-1];
endmodule

`default_nettype wire
