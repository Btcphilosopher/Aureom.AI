// =============================================================================
// SilicaFlux MemoryCore :: sf_ts_port
// One client port of a scratchpad onto one sf_sram_controller master port, with permission rejects that keep
// the controller's per-port in-order response contract:
//   * A request carries a reject code (req_rej: 0 none, 1 OWNER violation, 2 RANGE violation).  A rejected request is
//     redirected to REJECT_ADDR (beyond the aperture, line aligned) as a READ with no byte enables, so it causes NO array
//     access and NO side effect, and its response arrives IN ORDER with the status SF_ST_OWNER / SF_ST_RANGE and rdata 0.
//   * Metadata (reject code, write flag) is held in a FIFO of DEPTH entries (<= the controller's NSLOT); req_ready
//     drops when it is full, so metadata can never be lost.
//   * out_cnt_o = requests accepted and not yet answered (used for completion tracking).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ts_port #(
  parameter int AW     = 32,
  parameter int LINE_W = 128,
  parameter int DEPTH  = 8,
  parameter logic [AW-1:0] REJECT_ADDR = {{(AW-4){1'b1}}, 4'b0000},
  parameter int CW     = $clog2(DEPTH + 1)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // client side
  input  wire logic                req_valid,
  output logic                     req_ready,
  input  wire logic                req_we,
  input  wire logic [AW-1:0]       req_addr,
  input  wire logic [LINE_W-1:0]   req_wdata,
  input  wire logic [LINE_W/8-1:0] req_be,
  input  wire logic [1:0]          req_rej,
  output logic                     rsp_valid,
  input  wire logic                rsp_ready,
  output logic [LINE_W-1:0]        rsp_rdata,
  output logic                     rsp_we,
  output logic [2:0]               rsp_status,
  // controller side
  output logic                     c_req_valid,
  input  wire logic                c_req_ready,
  output logic                     c_req_we,
  output logic [AW-1:0]            c_req_addr,
  output logic [LINE_W-1:0]        c_req_wdata,
  output logic [LINE_W/8-1:0]      c_req_be,
  input  wire logic                c_rsp_valid,
  output logic                     c_rsp_ready,
  input  wire logic [LINE_W-1:0]   c_rsp_rdata,
  input  wire logic [2:0]          c_rsp_status,
  // tracking
  output logic [CW-1:0]            out_cnt_o
);
  logic        m_empty, m_full;
  logic [2:0]  m_in, m_out;
  logic [CW-1:0] m_cnt;
  wire rej = (req_rej != 2'd0);
  assign m_in = {req_rej, req_we & ~rej};
  assign c_req_valid = req_valid & ~m_full;
  assign req_ready   = c_req_ready & ~m_full;
  assign c_req_we    = req_we & ~rej;
  assign c_req_addr  = rej ? REJECT_ADDR : req_addr;
  assign c_req_wdata = req_wdata;
  assign c_req_be    = rej ? '0 : req_be;
  wire acc = req_valid & req_ready;
  wire fin = rsp_valid & rsp_ready;
  sf_sync_fifo #(.W(3), .DEPTH(DEPTH)) u_meta (.clk(clk), .rst_n(rst_n), .clr_i(1'b0), .push_i(acc), .din_i(m_in), .pop_i(fin),
                                              .dout_o(m_out), .empty_o(m_empty), .full_o(m_full), .count_o(m_cnt));
  assign out_cnt_o   = m_cnt;
  wire [1:0] o_rej = m_out[2:1];
  wire       o_we  = m_out[0];
  assign rsp_valid   = c_rsp_valid & ~m_empty;
  assign c_rsp_ready = rsp_ready & ~m_empty;
  assign rsp_we      = o_we;
  assign rsp_status  = (o_rej == 2'd1) ? `SF_ST_OWNER : (o_rej == 2'd2) ? `SF_ST_RANGE : c_rsp_status;
  assign rsp_rdata   = (o_we || o_rej != 2'd0 || c_rsp_status != `SF_ST_OK) ? '0 : c_rsp_rdata;
endmodule

`default_nettype wire
