// =============================================================================
// SilicaFlux MemoryMatrix :: sf_memory_matrix
// NUM_MASTERS clients x NUM_BANKS independent single-port SRAM banks (sf_sram_bank, reused unmodified).
// Feeds ControlCore, TensorCore, the FP32 vector engine and CloudDMA / DataFabric.
//
//   masters (CTRL, TENSOR, VECTOR, DMA)                         request: valid/ready, we, byte addr, size, wdata, be, id, prot
//        |  per master: decoder (bounds / align / perm / bank,row)  -> split into <= K word operations (bank spanning,
//        |              misaligned, 1..DATA_WIDTH/8 bytes)         -> slot table (bounded queue AND reorder buffer)
//        v
//   per-bank round-robin arbiters (sf_memory_matrix_arbiter)  one grant per bank per cycle
//        v
//   NUM_BANKS x sf_sram_bank  (1RW array, optional SECDED(72,64) + atomic read-modify-write, init, scrubber)
//        v  word responses (tag = {master, slot, word})
//   per-master response gather -> byte-lane re-alignment -> in-order response (valid/ready, id, we, status, ce)
//
// ---------------------------------------------------------------- memory port semantics actually used
//   A bank accepts AT MOST ONE operation per clock (req_valid && req_ready); the array is accessed at that edge;
//   READ_LATENCY (+1 with ECC) cycles later exactly one response per accepted operation comes back, in acceptance order,
//   without a ready (the consumer must always accept: the slot table reserves the storage at ACCEPT time).  req_ready is a
//   function of registered bank state only.  The array is never reset (contents are undefined after power-up; ECC builds
//   initialise it with the bank init engine, INIT_ON_RESET).  No multi-port behaviour is synthesised: two operations to
//   one bank are always serialised by that bank's arbiter.
//
// ---------------------------------------------------------------- request channel (per master i)
//   m_req_valid/ready   m_req_ready depends on REGISTERED state only (free slot, flush, quiesce): never on valid, on other
//                       masters or on the arbiters.  Accept = valid && ready; the payload must be stable until accepted.
//   m_req_we, m_req_addr (byte address, AW bits, matrix-local), m_req_size (log2 bytes, 0..log2(DATA_WIDTH/8)),
//   m_req_wdata / m_req_be (lane j = byte addr+j; the lane mask is relative to addr), m_req_id (IDW), m_req_prot ({secure, priv})
//     READ : returns bytes [addr, addr + 2^size - 1] in rdata lanes 0..2^size-1 (higher lanes 0).  be is ignored.
//     WRITE: writes the bytes j < 2^size whose be[j] is 1.  be[j] = 0 bytes are never modified.  be == 0 -> acknowledged no-op.
//     The access may start at any byte (MISALIGN_EN = 1) and spans up to K words / banks.
//   The port is a strict superset of the sf_sram_controller master port: with DATA_WIDTH = the controller's line width,
//   size tied to log2(DATA_WIDTH/8) and aligned addresses, the existing sf_vector_scratchpad / sf_tensor_scratchpad /
//   sf_sram_datafabric adapters can be attached unchanged (be is ignored on reads in both).
//
// ---------------------------------------------------------------- response channel (per master i)
//   m_rsp_valid/ready, m_rsp_rdata, m_rsp_id, m_rsp_we, m_rsp_status, m_rsp_ce.  Exactly one response per accepted request;
//   responses of one master return in ACCEPTANCE ORDER; a presented response stays stable until accepted.  A write response
//   is produced after every word of the write has been performed by its bank (acknowledged write).
//   status: SF_ST_OK, SF_ST_RANGE, SF_ST_ALIGN, SF_ST_PERM, SF_ST_BADOP (no array access, rdata 0), SF_ST_ECC_UE
//           (an uncorrectable word was read / a partial write was aborted; rdata is not valid).  m_rsp_ce: a single-bit
//           error was corrected on the way.
//
// ---------------------------------------------------------------- ordering and atomicity (the contract the tests check)
//   M1 per-master order of CONFLICTING accesses: two accesses of one master to the same word reach the bank in acceptance order
//      (RAW, WAW, WAR hold per address).  ISSUE_WINDOW = 1: all words of request n are issued before request n+1 starts.
//      ISSUE_WINDOW = W > 1: words of the next W-1 requests may be issued to banks that are free while an older request still waits
//      for a busy bank (out-of-order issue, same words stay ordered because one word is always one bank and a master offers its
//      OLDEST pending word of a bank first).  Responses are always returned in acceptance order (M2).
//   M2 per-master response order = acceptance order (slot table, released from the oldest).
//   M3 per-bank serialisation: accesses to one bank are totally ordered by the bank-accept edge; a read accepted by the
//      bank at edge t observes every write accepted by that bank at edges < t, across all masters.
//   M4 atomicity is ONE WORD (WORD_WIDTH bits) = one bank access.  A request that spans several words is a set of independent
//      word accesses: another master can observe it half-performed (torn).  There is no atomicity across requests.  The ECC
//      read-modify-write of a partial word write is atomic inside the bank.
//   M5 coherence: none.  A producer hands data to a consumer by waiting for the write RESPONSE.
//   M6 fairness: round-robin per bank (ARB = SF_ARB_RR): a master that keeps requesting a ready bank is granted within NM
//      grants of that bank.  ARB = SF_ARB_FIXED can starve (kept for comparison).
//   M7 flush_i: no new request is accepted, no more words are issued, in-flight words retire, every slot is discarded, no
//      response is presented from the flush cycle on.  Words already accepted by a bank STAY written (torn writes possible).
//   M8 reset clears control state only; memory contents are not reset.  Like any valid/ready bus the masters keep m_req_valid
//      LOW while rst_n is low (the array has no reset, so a request issued during reset would still write it).
//
// ---------------------------------------------------------------- latency (READ_LATENCY = L, ECC adds 1)
//   Request accepted and its words granted in the same cycle (empty queue, free banks): response visible
//   L + (ECC ? 1 : 0) + 1 cycles after the accepting edge.  A queued request waits for its turn.
//
// ---------------------------------------------------------------- bounded queues / back-pressure
//   Each master owns NSLOT slots (ISSUE_WINDOW of them are candidates for issue).  A slot is allocated at accept (the queue entry), holds the request, then the response
//   words, and is released when the master takes the response.  At most NSLOT requests are outstanding per master; the
//   (NSLOT+1)-th is refused with m_req_ready = 0.  Response back-pressure (m_rsp_ready = 0) fills the slots and thereby
//   back-pressures the request side.  Nothing is dropped or reordered.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_mm_defs.svh"
`default_nettype none

module sf_memory_matrix #(
  // ---- architecture
  parameter int NUM_BANKS       = 4,          // 2, 4, 8, 16 (power of two)
  parameter int BANK_DEPTH      = 1024,       // words per bank
  parameter int WORD_WIDTH      = 64,         // physical SRAM word (32 / 64 / 128 verified with ECC)
  parameter int DATA_WIDTH      = 256,        // master data bus = largest access (power of two, bits)
  parameter int READ_LATENCY    = 1,          // bank array read latency (>= 1)
  parameter int NUM_MASTERS     = 4,          // 1..16
  parameter int ENABLE_ECC      = 0,          // SECDED per word (bank wrapper), RMW on partial writes
  // ---- address / queue / policy
  parameter int AW              = 32,         // byte address width
  parameter int IDW             = 8,
  parameter int NSLOT           = 8,          // outstanding requests per master (queue depth)
  parameter int ISSUE_WINDOW    = 1,          // requests per master whose words may issue out of order (1 = strictly in order)
  parameter int ARB             = `SF_ARB_RR,
  parameter int INTERLEAVE_MODE = `SF_MM_ILV_LOW,
  parameter int ILV_GRAN_LOG2   = 0,          // interleave granule = 2^this words (LOW / XOR)
  parameter int MISALIGN_EN     = 1,          // 1: any byte address is split over words; 0: natural alignment required
  parameter int NUM_REGIONS     = 0,          // permission regions (0: no permission logic)
  parameter int DEFAULT_ALLOW   = 1,          // bytes outside every region
  // ---- bank / technology
  parameter int INIT_ON_RESET   = ENABLE_ECC,
  parameter int SIM_INIT        = 2,          // 0 X, 1 zero, 2 poison (simulation image of the never-reset array)
  parameter int FAULT_INJECT    = 0,          // simulation-only fault models (behavioural backend)
  parameter int BACKEND         = `SF_BACKEND_BEHAV,   // behavioural / FPGA block RAM / ASIC macro tiling
  parameter int SCRUB_EN        = 0,
  parameter int SCRUB_WAIT      = 64,
  parameter int CNT_W           = 16,
  parameter int MCLASS          = 32'hFFFFFFE4,   // 2 bits per master: 0 CTRL 1 TENSOR 2 VECTOR 3 DMA
  // ---- derived (do not override)
  parameter int NB              = NUM_BANKS,
  parameter int NM              = NUM_MASTERS,
  parameter int WB              = WORD_WIDTH / 8,
  parameter int LB              = $clog2(WB),
  parameter int DBYTES          = DATA_WIDTH / 8,
  parameter int SZ_MAX          = $clog2(DBYTES),
  parameter int SZW             = (SZ_MAX > 0) ? $clog2(SZ_MAX + 1) : 1,
  parameter int K               = (MISALIGN_EN != 0) ? (DBYTES + 2 * WB - 2) / WB : (DBYTES + WB - 1) / WB,
  parameter int KW              = (K > 1) ? $clog2(K) : 1,
  parameter int WIN             = ISSUE_WINDOW,
  parameter int LN              = WIN * K,      // word lanes per master: lane = window position * K + word
  parameter int BW              = $clog2(NB),
  parameter int ROW_W           = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  parameter int WIW             = $clog2(NB * BANK_DEPTH),
  parameter int MW              = (NM > 1) ? $clog2(NM) : 1,
  parameter int SW              = (NSLOT > 1) ? $clog2(NSLOT) : 1,
  parameter int TAG_W           = MW + SW + KW,
  parameter int R               = $clog2(WORD_WIDTH + $clog2(WORD_WIDTH + 1) + 1),
  parameter int STORE_W         = (ENABLE_ECC != 0) ? WORD_WIDTH + R + 1 : WORD_WIDTH,
  parameter int FBW             = (STORE_W > 1) ? $clog2(STORE_W) : 1,
  parameter int UBW             = $clog2(DBYTES + 1),
  parameter int LAT_W           = 20,
  parameter int NRW             = (NM > 1) ? $clog2(NM + 1) : 2,      // >= 2 bits: the conflict test compares against 2
  parameter int NRGW            = (NUM_REGIONS > 0) ? NUM_REGIONS : 1
) (
  input  wire logic                      clk,
  input  wire logic                      rst_n,
  // ---------------------------------------------------------------- master request channels
  input  wire logic [NM-1:0]             m_req_valid,
  output logic      [NM-1:0]             m_req_ready,
  input  wire logic [NM-1:0]             m_req_we,
  input  wire logic [NM*AW-1:0]          m_req_addr,
  input  wire logic [NM*SZW-1:0]         m_req_size,
  input  wire logic [NM*DATA_WIDTH-1:0]  m_req_wdata,
  input  wire logic [NM*DBYTES-1:0]      m_req_be,
  input  wire logic [NM*IDW-1:0]         m_req_id,
  input  wire logic [NM*2-1:0]           m_req_prot,
  // ---------------------------------------------------------------- master response channels
  output logic      [NM-1:0]             m_rsp_valid,
  input  wire logic [NM-1:0]             m_rsp_ready,
  output logic      [NM*DATA_WIDTH-1:0]  m_rsp_rdata,
  output logic      [NM*IDW-1:0]         m_rsp_id,
  output logic      [NM-1:0]             m_rsp_we,
  output logic      [NM*3-1:0]           m_rsp_status,
  output logic      [NM-1:0]             m_rsp_ce,
  // ---------------------------------------------------------------- permission regions (static configuration)
  input  wire logic [NRGW*AW-1:0]        rg_base_i,
  input  wire logic [NRGW*AW-1:0]        rg_last_i,
  input  wire logic [NRGW*5-1:0]         rg_perm_i,
  input  wire logic [NRGW*NM-1:0]        rg_mmask_i,
  // ---------------------------------------------------------------- control / status
  input  wire logic                      flush_i,
  output logic                           flush_busy_o,
  input  wire logic                      quiesce_i,
  output logic                           idle_o,
  input  wire logic                      init_start_i,
  output logic                           init_busy_o,
  input  wire logic                      scrub_en_i,
  // ---------------------------------------------------------------- ECC
  input  wire logic                      ecc_clr_i,
  output logic      [NB-1:0]             ev_ce_o,
  output logic      [NB-1:0]             ev_ue_o,
  output logic      [NB*AW-1:0]          ev_addr_o,       // byte address of the word of the event (valid with ev_*_o)
  output logic      [NB*CNT_W-1:0]       ce_cnt_o,
  output logic      [NB*CNT_W-1:0]       ue_cnt_o,
  // ---------------------------------------------------------------- performance counters (sf_memory_matrix_perf)
  input  wire logic                      perf_clr_i,
  output logic      [31:0]               perf_cycles_o,
  output logic      [NB*32-1:0]          perf_acc_rd_o,
  output logic      [NB*32-1:0]          perf_acc_wr_o,
  output logic      [NB*32-1:0]          perf_conf_o,
  output logic      [NB*32-1:0]          perf_lost_o,
  output logic      [NB*32-1:0]          perf_busy_o,
  output logic      [NM*32-1:0]          perf_mstall_o,
  output logic      [NM*32-1:0]          perf_arbstall_o,
  output logic      [NM*32-1:0]          perf_busystall_o,
  output logic      [NM*32-1:0]          perf_selfconf_o,
  output logic      [NM*32-1:0]          perf_starve_o,
  output logic      [4*32-1:0]           perf_starve_cls_o,
  output logic      [NM*32-1:0]          perf_reqs_o,
  output logic      [NM*32-1:0]          perf_bytes_rd_o,
  output logic      [NM*32-1:0]          perf_bytes_wr_o,
  output logic      [NM*40-1:0]          perf_lat_sum_o,
  output logic      [NM*32-1:0]          perf_lat_cnt_o,
  output logic      [NM*LAT_W-1:0]       perf_lat_max_o,
  output logic      [31:0]               perf_rej_o,
  // ---------------------------------------------------------------- per-cycle trace of bank accepts (verification / waves)
  output logic      [NB-1:0]             trc_acc_o,
  output logic      [NB-1:0]             trc_we_o,
  output logic      [NB*MW-1:0]          trc_m_o,
  output logic      [NB*SW-1:0]          trc_slot_o,
  output logic      [NB*KW-1:0]          trc_k_o,
  output logic      [NB*ROW_W-1:0]       trc_row_o,
  // ---------------------------------------------------------------- MBIST raw test port (collar-compatible with sf_sram_controller)
  input  wire logic                      tst_active_i,
  input  wire logic [NB-1:0]             tst_sel_i,
  input  wire logic                      tst_ce_i,
  input  wire logic                      tst_we_i,
  input  wire logic [ROW_W-1:0]          tst_addr_i,
  input  wire logic [STORE_W-1:0]        tst_wdata_i,
  output logic      [NB*STORE_W-1:0]     tst_rdata_o,
  // ---------------------------------------------------------------- simulation-only fault injection (selected bank)
  input  wire logic [BW-1:0]             fi_bank,
  input  wire logic [3:0]                fi_type,
  input  wire logic [ROW_W-1:0]          fi_row,
  input  wire logic [ROW_W-1:0]          fi_row2,
  input  wire logic [FBW-1:0]            fi_bit,
  input  wire logic [FBW-1:0]            fi_bit2,
  input  wire logic                      fi_val,
  input  wire logic                      fi_val2,
  input  wire logic                      seu_pulse,
  input  wire logic [ROW_W-1:0]          seu_row,
  input  wire logic [STORE_W-1:0]        seu_mask
);
  // ------------------------------------------------------------ parameter validation
  if (NB < 2 || NB > 32 || (NB & (NB - 1)) != 0) begin : g_err_nb
    `SF_CFG_FATAL("sf_memory_matrix: NUM_BANKS must be a power of two in 2..32")
  end
  if (NM < 1 || NM > 16) begin : g_err_nm
    `SF_CFG_FATAL("sf_memory_matrix: NUM_MASTERS must be 1..16")
  end
  if (BANK_DEPTH < 2) begin : g_err_depth
    `SF_CFG_FATAL("sf_memory_matrix: BANK_DEPTH must be >= 2")
  end
  if (NSLOT < 2) begin : g_err_nslot
    `SF_CFG_FATAL("sf_memory_matrix: NSLOT must be >= 2")
  end
  if (WORD_WIDTH < 16 || (WORD_WIDTH & (WORD_WIDTH - 1)) != 0) begin : g_err_ww
    `SF_CFG_FATAL("sf_memory_matrix: WORD_WIDTH must be a power of two >= 16")
  end
  if (DATA_WIDTH < 16 || (DATA_WIDTH & (DATA_WIDTH - 1)) != 0 || DATA_WIDTH > 512) begin : g_err_dw
    `SF_CFG_FATAL("sf_memory_matrix: DATA_WIDTH must be a power of two in 16..512")
  end
  if (AW < 8 || AW > 32) begin : g_err_aw
    `SF_CFG_FATAL("sf_memory_matrix: AW must be 8..32")
  end
  if (IDW < 1) begin : g_err_idw
    `SF_CFG_FATAL("sf_memory_matrix: IDW must be >= 1")
  end
  if (ISSUE_WINDOW < 1 || ISSUE_WINDOW > NSLOT) begin : g_err_win
    `SF_CFG_FATAL("sf_memory_matrix: ISSUE_WINDOW must be 1..NSLOT")
  end
  if (READ_LATENCY < 1) begin : g_err_lat
    `SF_CFG_FATAL("sf_memory_matrix: READ_LATENCY must be >= 1")
  end

  // ------------------------------------------------------------ shared flat views
  // candidate (the request a master is trying to issue this cycle) -> bank routing
  logic [NM*LN-1:0]             c_pend_f;               // pending words of the issue window, oldest first
  logic [NM*LN*BW-1:0]          c_bank_f;
  logic [NM*LN*ROW_W-1:0]       c_row_f;
  logic [NM*LN*WORD_WIDTH-1:0]  c_wd_f;
  logic [NM*LN*WB-1:0]          c_wm_f;
  logic [NM*WIN-1:0]            c_we_f;                 // per window position
  logic [NM*WIN*SW-1:0]         c_slot_f;               // per window position
  logic [NM-1:0]                c_self_f;               // two pending words of this master map to one bank
  // routing result
  logic [NM*LN-1:0]             g_f;                    // words accepted by a bank this cycle
  logic [NB*NM-1:0]             rq_f, gnt_f;            // bank requests / grants

  // bank side
  logic [NB-1:0]                b_req_valid, b_req_ready, b_req_we;
  logic [NB*ROW_W-1:0]          b_req_row;
  logic [NB*WORD_WIDTH-1:0]     b_req_wdata;
  logic [NB*WB-1:0]             b_req_be;
  logic [NB*TAG_W-1:0]          b_req_tag;
  logic [NB-1:0]                b_rsp_valid, b_rsp_we, b_rsp_ce;
  logic [NB*WORD_WIDTH-1:0]     b_rsp_rdata;
  logic [NB*TAG_W-1:0]          b_rsp_tag;
  logic [NB*3-1:0]              b_rsp_status;
  logic [NB-1:0]                b_idle, b_initbusy;

  // master side state shared with flush / quiesce
  logic [NM-1:0]                can_alloc;
  logic [NM-1:0]                m_empty;                // no outstanding request in this master
  logic                         flushing, clear_all;
  wire                          blocked   = flushing | flush_i | quiesce_i;
  wire                          issue_en  = ~flushing & ~flush_i;

  // cycle counter for latency measurement
  logic [LAT_W-1:0]             cyc;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cyc <= '0;
    else        cyc <= cyc + 1'b1;
  end

  // perf events from the masters
  logic [NM-1:0]                ev_pop_f, ev_pop_we_f, ev_pop_bad_f;
  logic [NM*LAT_W-1:0]          ev_pop_lat_f;
  logic [NM*UBW-1:0]            ev_pop_ub_f;

  function automatic [UBW-1:0] popc(input [DBYTES-1:0] v);
    logic [UBW-1:0] c;
    begin
      c = '0;
      for (int j = 0; j < DBYTES; j++) c = c + UBW'(v[j]);
      popc = c;
    end
  endfunction

  // ============================================================ per-master front end, slot table, response path
  for (genvar i = 0; i < NM; i++) begin : g_m
    // ---------------------------------------------------------- decode
    wire [AW-1:0]          a_i    = m_req_addr[i*AW +: AW];
    wire [SZW-1:0]         sz_i   = m_req_size[i*SZW +: SZW];
    wire [DATA_WIDTH-1:0]  wd_i   = m_req_wdata[i*DATA_WIDTH +: DATA_WIDTH];
    wire [DBYTES-1:0]      be_i   = m_req_be[i*DBYTES +: DBYTES];
    wire                   we_i   = m_req_we[i];
    logic                  fe_err;
    logic [2:0]            fe_status;
    logic [LB-1:0]         fe_off;
    logic [DBYTES-1:0]     fe_smask;
    logic [K*BW-1:0]       fe_bank;
    logic [K*ROW_W-1:0]    fe_row;

    sf_memory_matrix_decoder #(
      .NB(NB), .DEPTH(BANK_DEPTH), .LB(LB), .AW(AW), .SZ_MAX(SZ_MAX), .K(K), .MODE(INTERLEAVE_MODE),
      .GRAN(ILV_GRAN_LOG2), .MISALIGN_EN(MISALIGN_EN), .NRG(NUM_REGIONS), .DEFAULT_ALLOW(DEFAULT_ALLOW), .NM(NM)
    ) u_dec (
      .addr_i(a_i), .size_i(sz_i), .we_i(we_i), .prot_i(m_req_prot[i*2 +: 2]), .mid_i(MW'(i)),
      .rg_base_i(rg_base_i), .rg_last_i(rg_last_i), .rg_perm_i(rg_perm_i), .rg_mmask_i(rg_mmask_i),
      .err_o(fe_err), .status_o(fe_status), .off_o(fe_off), .smask_o(fe_smask), .bank_o(fe_bank), .row_o(fe_row));

    // ---------------------------------------------------------- split into word lanes (pre-shifted write data / byte masks)
    wire [DBYTES-1:0]        fe_be_eff = we_i ? (be_i & fe_smask) : fe_smask;
    wire [K*WORD_WIDTH-1:0]  fe_wd     = (K*WORD_WIDTH)'(wd_i) << {fe_off, 3'b000};
    wire [K*WB-1:0]          fe_wm     = fe_err ? '0 : ((K*WB)'(fe_be_eff) << fe_off);
    logic [K-1:0]            fe_need;
    always_comb begin
      for (int k = 0; k < K; k++) fe_need[k] = |fe_wm[k*WB +: WB];
    end
    wire [UBW-1:0]           fe_ub     = fe_err ? '0 : popc(fe_be_eff);

    // ---------------------------------------------------------- pointers
    logic [SW-1:0]  head, tail, ip;
    logic [SW:0]    cnt, icnt;
    wire            q_has = (icnt != '0);                 // an accepted request still has words to issue
    assign can_alloc[i] = (cnt != (SW+1)'(NSLOT)) & ~blocked;
    assign m_req_ready[i] = can_alloc[i];
    wire            alloc = m_req_valid[i] & can_alloc[i];
    wire            byp   = ~q_has & alloc;               // cut-through: issue in the accepting cycle
    assign m_empty[i] = (cnt == '0);

    // ---------------------------------------------------------- slot storage views
    logic [NSLOT-1:0]                 s_sv;
    logic [NSLOT*LB-1:0]              s_off_f;
    logic [NSLOT-1:0]                 s_we_f;
    logic [NSLOT*IDW-1:0]             s_id_f;
    logic [NSLOT*K*BW-1:0]            s_bank_f;
    logic [NSLOT*K*ROW_W-1:0]         s_row_f;
    logic [NSLOT*K-1:0]               s_need_f, s_iss_f, s_rd_f;
    logic [NSLOT*K*WORD_WIDTH-1:0]    s_wd_f;
    logic [NSLOT*K*WB-1:0]            s_wm_f;
    logic [NSLOT*3-1:0]               s_st_f;
    logic [NSLOT-1:0]                 s_ce_f;
    logic [NSLOT*LAT_W-1:0]           s_ts_f;
    logic [NSLOT*UBW-1:0]             s_ub_f;

    // ---------------------------------------------------------- issue window (queued requests or the cut-through request)
    //   Window position w holds the request in slot ip+w (w < icnt); with an empty queue position 0 is the request being accepted
    //   this cycle (cut-through).  Lanes are ordered OLDEST FIRST (position, then word).  Every pending word of the window can
    //   request its bank; per (master, bank) the bank-side selection (g_b) takes the OLDEST lane.
    //   PER-ADDRESS PROGRAM ORDER needs no extra hazard logic: two accesses to the same word are accesses to the same BANK, a master
    //   offers its oldest pending word of a bank first, so they reach that bank in program order (RAW, WAW, WAR); words of different
    //   banks never conflict and may pass each other.  ISSUE_WINDOW = 1 is strictly in-order issue.
    logic [LN-1:0]            w_pend;
    logic [LN*BW-1:0]         w_bank;
    logic [LN*ROW_W-1:0]      w_row;
    logic [LN*WORD_WIDTH-1:0] w_wd;
    logic [LN*WB-1:0]         w_wm;
    logic [WIN-1:0]           w_we;
    logic [WIN*SW-1:0]        w_slot;
    logic [WIN-1:0]           w_valid;
    always_comb begin
      for (int w = 0; w < WIN; w++) begin
        int           sidx;
        logic [K-1:0] nd, is;
        sidx = (int'(ip) + w) % NSLOT;
        if (w == 0 && !q_has) begin
          w_valid[w] = issue_en & byp;
          nd = fe_need; is = '0;
          w_bank[w*K*BW +: K*BW]                     = fe_bank;
          w_row[w*K*ROW_W +: K*ROW_W]                = fe_row;
          w_wd[w*K*WORD_WIDTH +: K*WORD_WIDTH]       = fe_wd;
          w_wm[w*K*WB +: K*WB]                       = fe_wm;
          w_we[w]                                    = we_i;
          w_slot[w*SW +: SW]                         = tail;
        end else begin
          w_valid[w] = issue_en & ((SW+1)'(w) < icnt);
          nd = s_need_f[sidx*K +: K];
          is = s_iss_f[sidx*K +: K];
          w_bank[w*K*BW +: K*BW]                     = s_bank_f[sidx*K*BW +: K*BW];
          w_row[w*K*ROW_W +: K*ROW_W]                = s_row_f[sidx*K*ROW_W +: K*ROW_W];
          w_wd[w*K*WORD_WIDTH +: K*WORD_WIDTH]       = s_wd_f[sidx*K*WORD_WIDTH +: K*WORD_WIDTH];
          w_wm[w*K*WB +: K*WB]                       = s_wm_f[sidx*K*WB +: K*WB];
          w_we[w]                                    = s_we_f[sidx];
          w_slot[w*SW +: SW]                         = SW'(sidx);
        end
        w_pend[w*K +: K] = (nd & ~is) & {K{w_valid[w]}};
      end
    end
    assign c_pend_f[i*LN +: LN]                     = w_pend;
    assign c_bank_f[i*LN*BW +: LN*BW]               = w_bank;
    assign c_row_f[i*LN*ROW_W +: LN*ROW_W]          = w_row;
    assign c_wd_f[i*LN*WORD_WIDTH +: LN*WORD_WIDTH] = w_wd;
    assign c_wm_f[i*LN*WB +: LN*WB]                 = w_wm;
    assign c_we_f[i*WIN +: WIN]                     = w_we;
    assign c_slot_f[i*WIN*SW +: WIN*SW]             = w_slot;

    always_comb begin                                    // two pending words of this master in one bank (serialised by the single port)
      logic sc;
      sc = 1'b0;
      for (int a = 0; a < LN; a++)
        for (int b = a + 1; b < LN; b++)
          if (w_pend[a] && w_pend[b] && w_bank[a*BW +: BW] == w_bank[b*BW +: BW]) sc = 1'b1;
      c_self_f[i] = sc;
    end

    wire [LN-1:0] g_all    = g_f[i*LN +: LN];
    wire [K-1:0]  g_i      = g_all[K-1:0];                                     // words of window position 0 accepted this cycle
    wire          cand_done = w_valid[0] & ((w_pend[K-1:0] & ~g_i) == '0);     // position 0: every word issued (or none to issue)

    // ---------------------------------------------------------- slot table
    wire h_sv_w;
    for (genvar s = 0; s < NSLOT; s++) begin : g_s
      logic                    sv, we_q, ce_q;
      logic [LB-1:0]           off_q;
      logic [IDW-1:0]          id_q;
      logic [K*BW-1:0]         bank_q;
      logic [K*ROW_W-1:0]      row_q;
      logic [K-1:0]            need_q, iss_q, rd_q;
      logic [K*WORD_WIDTH-1:0] wd_q;
      logic [K*WB-1:0]         wm_q;
      logic [2:0]              st_q;
      logic [LAT_W-1:0]        ts_q;
      logic [UBW-1:0]          ub_q;

      // word responses addressed to this slot
      logic [K-1:0]            hit_k;
      logic [K*WORD_WIDTH-1:0] hdata;
      logic                    h_ue, h_ce;
      always_comb begin
        hit_k = '0; hdata = '0; h_ue = 1'b0; h_ce = 1'b0;
        for (int b = 0; b < NB; b++) begin
          if (b_rsp_valid[b] && b_rsp_tag[b*TAG_W + SW + KW +: MW] == MW'(i) && b_rsp_tag[b*TAG_W + KW +: SW] == SW'(s)) begin
            h_ue = h_ue | (b_rsp_status[b*3 +: 3] == `SF_ST_ECC_UE);
            h_ce = h_ce | b_rsp_ce[b];
            for (int k = 0; k < K; k++) begin
              if (b_rsp_tag[b*TAG_W +: KW] == KW'(k)) begin
                hit_k[k] = 1'b1;
                hdata[k*WORD_WIDTH +: WORD_WIDTH] = hdata[k*WORD_WIDTH +: WORD_WIDTH] | b_rsp_rdata[b*WORD_WIDTH +: WORD_WIDTH];
              end
            end
          end
        end
      end

      wire a_here = alloc & (tail == SW'(s));
      // window offset of this slot relative to ip, and the words accepted for it this cycle
      localparam int SIDX = s;
      wire [SW:0]   woff    = (SW+1)'(((SIDX + NSLOT) - int'(ip)) % NSLOT);
      wire          q_here  = (woff < (SW+1)'(WIN)) & (woff < icnt);
      logic [K-1:0] g_slot;
      always_comb begin
        g_slot = '0;
        for (int w = 0; w < WIN; w++) if (woff == (SW+1)'(w)) g_slot = g_all[w*K +: K];
      end
      wire p_here = ev_pop_f[i] & (head == SW'(s));

      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          sv <= 1'b0; we_q <= 1'b0; ce_q <= 1'b0; off_q <= '0; id_q <= '0; bank_q <= '0; row_q <= '0;
          need_q <= '0; iss_q <= '0; rd_q <= '0; wd_q <= '0; wm_q <= '0; st_q <= '0; ts_q <= '0; ub_q <= '0;
        end else if (clear_all) begin
          sv <= 1'b0;
        end else begin
          if (p_here) sv <= 1'b0;
          if (a_here) begin
            sv <= 1'b1; we_q <= we_i; ce_q <= 1'b0; off_q <= fe_off; id_q <= m_req_id[i*IDW +: IDW];
            bank_q <= fe_bank; row_q <= fe_row; need_q <= fe_need; rd_q <= '0;
            iss_q <= byp ? g_i : '0;
            wd_q <= fe_wd; wm_q <= fe_wm; st_q <= fe_status; ts_q <= cyc; ub_q <= fe_ub;
          end else begin
            if (q_here) iss_q <= iss_q | g_slot;
            if (|hit_k) begin
              rd_q <= rd_q | hit_k;
              if (!we_q) begin
                for (int k = 0; k < K; k++)
                  if (hit_k[k]) wd_q[k*WORD_WIDTH +: WORD_WIDTH] <= hdata[k*WORD_WIDTH +: WORD_WIDTH];
              end
              if (h_ue) st_q <= `SF_ST_ECC_UE;
              if (h_ce) ce_q <= 1'b1;
            end
          end
        end
      end

      assign s_sv[s]                                   = sv;
      assign s_we_f[s]                                 = we_q;
      assign s_ce_f[s]                                 = ce_q;
      assign s_off_f[s*LB +: LB]                       = off_q;
      assign s_id_f[s*IDW +: IDW]                      = id_q;
      assign s_bank_f[s*K*BW +: K*BW]                  = bank_q;
      assign s_row_f[s*K*ROW_W +: K*ROW_W]             = row_q;
      assign s_need_f[s*K +: K]                        = need_q;
      assign s_iss_f[s*K +: K]                         = iss_q;
      assign s_rd_f[s*K +: K]                          = rd_q;
      assign s_wd_f[s*K*WORD_WIDTH +: K*WORD_WIDTH]    = wd_q;
      assign s_wm_f[s*K*WB +: K*WB]                    = wm_q;
      assign s_st_f[s*3 +: 3]                          = st_q;
      assign s_ts_f[s*LAT_W +: LAT_W]                  = ts_q;
      assign s_ub_f[s*UBW +: UBW]                      = ub_q;
    end

    // ---------------------------------------------------------- pointer / counter update
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        head <= '0; tail <= '0; ip <= '0; cnt <= '0; icnt <= '0;
      end else if (clear_all) begin
        head <= '0; tail <= '0; ip <= '0; cnt <= '0; icnt <= '0;
      end else begin
        if (alloc)      tail <= (tail == SW'(NSLOT - 1)) ? '0 : tail + 1'b1;
        if (cand_done)  ip   <= (ip == SW'(NSLOT - 1)) ? '0 : ip + 1'b1;
        if (ev_pop_f[i]) head <= (head == SW'(NSLOT - 1)) ? '0 : head + 1'b1;
        cnt  <= cnt  + (SW+1)'(alloc) - (SW+1)'(ev_pop_f[i]);
        icnt <= icnt + (SW+1)'(alloc) - (SW+1)'(cand_done);
      end
    end

    // ---------------------------------------------------------- response presentation (oldest slot, in order)
    wire [K-1:0]               h_need = s_need_f[int'(head)*K +: K];
    wire [K-1:0]               h_rd   = s_rd_f[int'(head)*K +: K];
    wire                       h_done = s_sv[head] & (h_rd == h_need);
    wire [K*WORD_WIDTH-1:0]    h_wd   = s_wd_f[int'(head)*K*WORD_WIDTH +: K*WORD_WIDTH];
    wire [K*WB-1:0]            h_wm   = s_wm_f[int'(head)*K*WB +: K*WB];
    wire [LB-1:0]              h_off  = s_off_f[int'(head)*LB +: LB];
    wire                       h_we   = s_we_f[head];
    wire [2:0]                 h_st   = s_st_f[int'(head)*3 +: 3];
    logic [K*WORD_WIDTH-1:0]   h_msk;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [K*WORD_WIDTH-1:0]   h_sh;                 // bits above DATA_WIDTH are dropped on purpose
    /* verilator lint_on UNUSEDSIGNAL */
    always_comb begin
      for (int j = 0; j < K*WB; j++) h_msk[j*8 +: 8] = h_wd[j*8 +: 8] & {8{h_wm[j]}};
      h_sh = h_msk >> {h_off, 3'b000};
    end
    assign m_rsp_valid[i]                       = h_done & ~flushing & ~flush_i;
    assign m_rsp_rdata[i*DATA_WIDTH +: DATA_WIDTH] = h_we ? '0 : h_sh[DATA_WIDTH-1:0];
    assign m_rsp_id[i*IDW +: IDW]               = s_id_f[int'(head)*IDW +: IDW];
    assign m_rsp_we[i]                          = h_we;
    assign m_rsp_status[i*3 +: 3]               = h_st;
    assign m_rsp_ce[i]                          = s_ce_f[head];

    assign ev_pop_f[i]                          = m_rsp_valid[i] & m_rsp_ready[i];
    assign ev_pop_we_f[i]                       = h_we;
    assign ev_pop_bad_f[i]                      = (h_st != `SF_ST_OK);
    assign ev_pop_lat_f[i*LAT_W +: LAT_W]       = cyc - s_ts_f[int'(head)*LAT_W +: LAT_W];
    assign ev_pop_ub_f[i*UBW +: UBW]            = s_ub_f[int'(head)*UBW +: UBW];
    assign h_sv_w = s_sv[head];
    wire unused_m = &{1'b0, h_sv_w, s_sv[0]};
  end

  // ============================================================ per-bank routing, arbitration, SRAM bank
  logic [NB*NM*LN-1:0] gk_all;
  for (genvar b = 0; b < NB; b++) begin : g_b
    logic [NM-1:0]    rq, gnt;
    logic [NM*LN-1:0] selw;
    logic [MW-1:0]    rr_unused;
    logic             gv_unused;

    always_comb begin
      for (int i = 0; i < NM; i++) begin
        logic [LN-1:0] cand;
        logic          seen;
        for (int k = 0; k < LN; k++)
          cand[k] = c_pend_f[i*LN + k] && (c_bank_f[(i*LN + k)*BW +: BW] == BW'(b));
        rq[i] = |cand;
        seen = 1'b0;
        for (int k = 0; k < LN; k++) begin
          selw[i*LN + k] = cand[k] & ~seen;          // OLDEST eligible word of master i that maps to this bank
          seen = seen | cand[k];
        end
      end
    end

    sf_memory_matrix_arbiter #(.NM(NM), .ARB(ARB)) u_arb (
      .clk(clk), .rst_n(rst_n), .req_i(rq), .ready_i(b_req_ready[b]), .gnt_o(gnt), .gnt_v_o(gv_unused), .ptr_o(rr_unused));

    assign rq_f[b*NM +: NM]  = rq;
    assign gnt_f[b*NM +: NM] = gnt;

    always_comb begin
      logic              v, w;
      logic [ROW_W-1:0]  row;
      logic [WORD_WIDTH-1:0] wd;
      logic [WB-1:0]     wm;
      logic [TAG_W-1:0]  tg;
      v = 1'b0; w = 1'b0; row = '0; wd = '0; wm = '0; tg = '0;
      for (int i = 0; i < NM; i++) begin
        for (int k = 0; k < LN; k++) begin
          gk_all[(b*NM + i)*LN + k] = gnt[i] & selw[i*LN + k];
          if (gnt[i] && selw[i*LN + k]) begin
            v   = 1'b1;
            w   = c_we_f[i*WIN + k / K];
            row = row | c_row_f[(i*LN + k)*ROW_W +: ROW_W];
            wd  = wd  | c_wd_f[(i*LN + k)*WORD_WIDTH +: WORD_WIDTH];
            wm  = wm  | c_wm_f[(i*LN + k)*WB +: WB];
            tg  = tg  | {MW'(i), c_slot_f[(i*WIN + k / K)*SW +: SW], KW'(k % K)};
          end
        end
      end
      b_req_valid[b] = v; b_req_we[b] = w;
      b_req_row[b*ROW_W +: ROW_W]          = row;
      b_req_wdata[b*WORD_WIDTH +: WORD_WIDTH] = wd;
      b_req_be[b*WB +: WB]                 = wm;
      b_req_tag[b*TAG_W +: TAG_W]          = tg;
    end

    wire fi_here = (fi_bank == BW'(b));
    wire [ROW_W-1:0] ev_row_w, fce_u, fue_u;
    wire [1:0]       ev_kind_u;
    sf_sram_bank #(
      .DEPTH(BANK_DEPTH), .DW(WORD_WIDTH), .READ_LATENCY(READ_LATENCY), .ECC_EN(ENABLE_ECC), .TAG_W(TAG_W),
      .INIT_ON_RESET(INIT_ON_RESET), .SIM_INIT(SIM_INIT), .FAULT_INJECT(FAULT_INJECT), .BACKEND(BACKEND),
      .SCRUB_EN(SCRUB_EN), .SCRUB_WAIT(SCRUB_WAIT), .CNT_W(CNT_W)
    ) u_bank (
      .clk(clk), .rst_n(rst_n),
      .req_valid(b_req_valid[b]), .req_ready(b_req_ready[b]), .req_we(b_req_we[b]),
      .req_row(b_req_row[b*ROW_W +: ROW_W]), .req_wdata(b_req_wdata[b*WORD_WIDTH +: WORD_WIDTH]),
      .req_be(b_req_be[b*WB +: WB]), .req_tag(b_req_tag[b*TAG_W +: TAG_W]),
      .rsp_valid(b_rsp_valid[b]), .rsp_rdata(b_rsp_rdata[b*WORD_WIDTH +: WORD_WIDTH]), .rsp_tag(b_rsp_tag[b*TAG_W +: TAG_W]),
      .rsp_we(b_rsp_we[b]), .rsp_status(b_rsp_status[b*3 +: 3]), .rsp_ce(b_rsp_ce[b]),
      .init_start_i(init_start_i), .init_busy_o(b_initbusy[b]), .scrub_en_i(scrub_en_i), .idle_o(b_idle[b]),
      .ev_ce_o(ev_ce_o[b]), .ev_ue_o(ev_ue_o[b]), .ev_row_o(ev_row_w), .ev_kind_o(ev_kind_u),
      .cnt_clr_i(ecc_clr_i), .ce_cnt_o(ce_cnt_o[b*CNT_W +: CNT_W]), .ue_cnt_o(ue_cnt_o[b*CNT_W +: CNT_W]),
      .first_ce_row_o(fce_u), .first_ue_row_o(fue_u),
      .tst_active_i(tst_active_i), .tst_ce_i(tst_active_i & tst_sel_i[b] & tst_ce_i), .tst_we_i(tst_we_i),
      .tst_addr_i(tst_addr_i), .tst_wdata_i(tst_wdata_i), .tst_rdata_o(tst_rdata_o[b*STORE_W +: STORE_W]),
      .fi_type(fi_here ? fi_type : 4'd0), .fi_row(fi_row), .fi_row2(fi_row2), .fi_bit(fi_bit), .fi_bit2(fi_bit2),
      .fi_val(fi_val), .fi_val2(fi_val2), .seu_pulse(seu_pulse & fi_here), .seu_row(seu_row), .seu_mask(seu_mask));

    // ECC event address: (bank, row) -> byte address of the word
    wire [WIW-1:0] ev_word;
    sf_memory_matrix_unmap #(.NB(NB), .DEPTH(BANK_DEPTH), .MODE(INTERLEAVE_MODE), .GRAN(ILV_GRAN_LOG2)) u_unmap (
      .bank_i(BW'(b)), .row_i(ev_row_w), .word_o(ev_word));
    assign ev_addr_o[b*AW +: AW] = AW'({ev_word, {LB{1'b0}}});

    // trace
    assign trc_acc_o[b]                 = b_req_valid[b] & b_req_ready[b];
    assign trc_we_o[b]                  = b_req_we[b];
    assign trc_m_o[b*MW +: MW]          = b_req_tag[b*TAG_W + SW + KW +: MW];
    assign trc_slot_o[b*SW +: SW]       = b_req_tag[b*TAG_W + KW +: SW];
    assign trc_k_o[b*KW +: KW]          = b_req_tag[b*TAG_W +: KW];
    assign trc_row_o[b*ROW_W +: ROW_W]  = b_req_row[b*ROW_W +: ROW_W];

    wire unused_b = &{1'b0, fce_u, fue_u, ev_kind_u, rr_unused, gv_unused, b_rsp_we[b]};
  end

  // words accepted by a bank, per master and word lane
  always_comb begin
    g_f = '0;
    for (int b = 0; b < NB; b++) g_f = g_f | gk_all[b*NM*LN +: NM*LN];
  end

  assign init_busy_o = |b_initbusy;

  // ============================================================ in-flight words, flush, idle
  logic [15:0] inflight;
  logic [7:0]  inf_acc, inf_rsp;
  always_comb begin
    integer a_n, r_n;
    a_n = 0; r_n = 0;
    for (int b = 0; b < NB; b++) begin
      if (b_req_valid[b] && b_req_ready[b]) a_n = a_n + 1;
      if (b_rsp_valid[b]) r_n = r_n + 1;
    end
    inf_acc = a_n[7:0]; inf_rsp = r_n[7:0];
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) inflight <= '0;
    else        inflight <= inflight + 16'(inf_acc) - 16'(inf_rsp);
  end
  assign clear_all    = flushing & (inflight == '0);
  assign flush_busy_o = flushing | flush_i;
  assign idle_o       = (inflight == '0) & (&b_idle) & (&m_empty);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)         flushing <= 1'b0;
    else if (clear_all) flushing <= 1'b0;
    else if (flush_i)   flushing <= 1'b1;
  end

  // ============================================================ performance events
  logic [NB-1:0]      ev_acc, ev_busy;
  logic [NB*NRW-1:0]  ev_nreq;
  logic [NM-1:0]      ev_mstall, ev_arbstall, ev_busystall, ev_starve;
  always_comb begin
    for (int b = 0; b < NB; b++) begin
      logic [NRW-1:0] n;
      n = '0;
      for (int i = 0; i < NM; i++) n = n + NRW'(rq_f[b*NM + i]);
      ev_nreq[b*NRW +: NRW] = n;
      ev_acc[b]  = b_req_valid[b] & b_req_ready[b];
      ev_busy[b] = (n != '0) & ~b_req_ready[b];
    end
    for (int i = 0; i < NM; i++) begin
      logic la, lb;
      la = 1'b0; lb = 1'b0;
      for (int b = 0; b < NB; b++) begin
        if (rq_f[b*NM + i] &&  b_req_ready[b] && !gnt_f[b*NM + i]) la = 1'b1;
        if (rq_f[b*NM + i] && !b_req_ready[b])                      lb = 1'b1;
      end
      ev_mstall[i]    = m_req_valid[i] & ~m_req_ready[i];
      ev_arbstall[i]  = la;
      ev_busystall[i] = lb;
      ev_starve[i]    = (|c_pend_f[i*LN +: LN]) & ~(|g_f[i*LN +: LN]);
    end
  end

  sf_memory_matrix_perf #(.NB(NB), .NM(NM), .LAT_W(LAT_W), .UBW(UBW), .MCLASS(MCLASS)) u_perf (
    .clk(clk), .rst_n(rst_n), .clr_i(perf_clr_i),
    .ev_acc_i(ev_acc), .ev_acc_we_i(b_req_we), .ev_nreq_i(ev_nreq), .ev_busy_i(ev_busy),
    .ev_mstall_i(ev_mstall), .ev_arbstall_i(ev_arbstall), .ev_busystall_i(ev_busystall),
    .ev_selfconf_i(c_self_f), .ev_starve_i(ev_starve),
    .ev_pop_i(ev_pop_f), .ev_pop_we_i(ev_pop_we_f), .ev_pop_bad_i(ev_pop_bad_f), .ev_pop_lat_i(ev_pop_lat_f), .ev_pop_ub_i(ev_pop_ub_f),
    .perf_cycles_o(perf_cycles_o), .perf_acc_rd_o(perf_acc_rd_o), .perf_acc_wr_o(perf_acc_wr_o), .perf_conf_o(perf_conf_o),
    .perf_lost_o(perf_lost_o), .perf_busy_o(perf_busy_o), .perf_mstall_o(perf_mstall_o), .perf_arbstall_o(perf_arbstall_o),
    .perf_busystall_o(perf_busystall_o), .perf_selfconf_o(perf_selfconf_o), .perf_starve_o(perf_starve_o),
    .perf_starve_cls_o(perf_starve_cls_o), .perf_reqs_o(perf_reqs_o), .perf_bytes_rd_o(perf_bytes_rd_o),
    .perf_bytes_wr_o(perf_bytes_wr_o), .perf_lat_sum_o(perf_lat_sum_o), .perf_lat_cnt_o(perf_lat_cnt_o),
    .perf_lat_max_o(perf_lat_max_o), .perf_rej_o(perf_rej_o));

  // ============================================================ embedded checks (simulation / formal)
  `ifdef SF_MM_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    for (int b = 0; b < NB; b++) begin
      `SF_CHK($onehot0(gnt_f[b*NM +: NM]), "sf_memory_matrix: bank grant not exclusive")
      if (|gnt_f[b*NM +: NM]) `SF_CHK(b_req_ready[b], "sf_memory_matrix: grant while bank not ready")
    end
    `SF_CHK(inflight < 16'd4096, "sf_memory_matrix: in-flight counter runaway")
  end
  `endif

endmodule

`default_nettype wire
