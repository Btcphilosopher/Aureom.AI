// =============================================================================
// SilicaFlux MemoryMatrix :: sf_memory_matrix_arbiter
// Per-bank master arbiter (one instance per SRAM bank).  Grants at most ONE requester per cycle, only when the bank
// can accept an access (ready_i), because a single-port bank performs one operation per cycle.
//
//   ARB = SF_ARB_RR (1)    round robin.  ptr names the highest-priority master; after a grant to master i the pointer
//                          moves to i+1 (mod NM).  A master that keeps requesting while the bank is ready is granted
//                          within NM grants of that bank: at most NM-1 other grants occur before it (checked in
//                          tests/memory_matrix and by formal/memory_matrix/fv_mm_arbiter.sv).
//   ARB = SF_ARB_FIXED (0) master 0 highest; lower masters may starve (kept for comparison, as in sf_sram_controller).
//
// The grant is a combinational function of req_i, ready_i and the registered pointer.  The pointer only moves on a
// grant, so back-pressure from the bank (ready_i = 0) never disturbs fairness.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_mm_defs.svh"
`default_nettype none

module sf_memory_matrix_arbiter #(
  parameter int NM  = 4,
  parameter int ARB = `SF_ARB_RR,
  parameter int MW  = (NM > 1) ? $clog2(NM) : 1
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic [NM-1:0] req_i,
  input  wire logic          ready_i,
  output logic      [NM-1:0] gnt_o,
  output logic               gnt_v_o,
  output logic      [MW-1:0] ptr_o
);
  logic [MW-1:0] ptr;
  assign ptr_o = ptr;

  always_comb begin
    logic found;
    int   idx;
    gnt_o = '0;
    found = 1'b0;
    idx   = 0;
    if (ready_i) begin
      for (int k = 0; k < NM; k++) begin
        if (ARB == `SF_ARB_RR) begin
          idx = int'(ptr) + k;
          if (idx >= NM) idx = idx - NM;
        end else begin
          idx = k;
        end
        if (!found && req_i[idx]) begin
          gnt_o[idx] = 1'b1;
          found = 1'b1;
        end
      end
    end
    gnt_v_o = found;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ptr <= '0;
    end else if (ARB == `SF_ARB_RR && gnt_v_o) begin
      for (int i = 0; i < NM; i++)
        if (gnt_o[i]) ptr <= (i == NM - 1) ? '0 : MW'(i + 1);
    end
  end
endmodule

`default_nettype wire
