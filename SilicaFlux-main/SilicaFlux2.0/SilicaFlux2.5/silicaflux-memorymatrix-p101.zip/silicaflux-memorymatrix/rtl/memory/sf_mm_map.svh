// =============================================================================
// SilicaFlux MemoryMatrix :: sf_mm_map.svh
// Word-index <-> (bank, row) mapping functions.  INCLUDED INSIDE a module body that declares the localparams
//   NB, BW, DEPTH, ROW_W, WIW, MODE, GRAN        (NB power of two >= 2; GRAN = log2 of the interleave granule in words)
// so the forward map (sf_memory_matrix_decoder) and the inverse (sf_memory_matrix_unmap) are literally the same text.
//
//   MODE LOW   : G = 2^GRAN.   low = w[GRAN-1:0] ; blk = w >> GRAN ; bank = blk mod NB ; row = ((blk / NB) << GRAN) | low
//   MODE XOR   : as LOW, then bank ^= fold(row).  fold(row) XORs the BW-bit slices of row.  For a fixed row the map
//                bank_low -> bank is a bijection (XOR with a constant), so the whole map is a bijection.
//   MODE LINEAR: bank = w / DEPTH ; row = w mod DEPTH
// Both directions are bijections between {0 .. NB*DEPTH-1} and {bank < NB} x {row < DEPTH}: no address aliasing
// (checked exhaustively in tests/memory_matrix/tb_mm_decoder.sv and by formal/memory_matrix/fv_mm_map.sv).
// DEPTH must be a multiple of 2^GRAN for LOW / XOR (checked at elaboration).
// =============================================================================
  function automatic [BW-1:0] mm_fold(input [ROW_W-1:0] r);
    logic [BW-1:0] f;
    begin
      f = '0;
      for (int s = 0; s < ROW_W; s += BW) f = f ^ BW'(r >> s);
      mm_fold = f;
    end
  endfunction

  // forward: word index -> {row, bank}
  function automatic [BW+ROW_W-1:0] mm_map(input [WIW-1:0] w);
    logic [WIW-1:0]   blk;
    logic [WIW-1:0]   rhi;
    logic [BW-1:0]    bnk;
    logic [ROW_W-1:0] row;
    logic [WIW-1:0]   low;
    begin
      if (MODE == `SF_MM_ILV_LINEAR) begin
        bnk = BW'(w / WIW'(DEPTH));
        row = ROW_W'(w % WIW'(DEPTH));
      end else begin
        low = w & ((WIW'(1) << GRAN) - WIW'(1));
        blk = w >> GRAN;
        bnk = BW'(blk);                              // blk mod NB (NB is a power of two)
        rhi = blk >> BW;
        row = ROW_W'((rhi << GRAN) | low);
        if (MODE == `SF_MM_ILV_XOR) bnk = bnk ^ mm_fold(row);
      end
      mm_map = {row, bnk};
    end
  endfunction

  // inverse: (bank, row) -> word index
  function automatic [WIW-1:0] mm_unmap(input [BW-1:0] bank, input [ROW_W-1:0] row);
    logic [BW-1:0]  bnk;
    logic [WIW-1:0] rhi;
    logic [WIW-1:0] low;
    logic [WIW-1:0] blk;
    begin
      if (MODE == `SF_MM_ILV_LINEAR) begin
        mm_unmap = WIW'(WIW'(bank) * WIW'(DEPTH) + WIW'(row));
      end else begin
        bnk = bank;
        if (MODE == `SF_MM_ILV_XOR) bnk = bank ^ mm_fold(row);
        rhi = WIW'(row) >> GRAN;
        low = WIW'(row) & ((WIW'(1) << GRAN) - WIW'(1));
        blk = (rhi << BW) | WIW'(bnk);
        mm_unmap = (blk << GRAN) | low;
      end
    end
  endfunction
