// =============================================================================
// SilicaFlux MemoryMatrix :: sf_mm_defs.svh
// Constants shared by the sf_memory_matrix* modules.  A `define header and not a package
// (same portability rule as sf_sram_defs.svh: older Yosys cannot resolve package references
// in parameter lists).  It EXTENDS sf_sram_defs.svh and never renumbers anything in it.
// =============================================================================
`ifndef SF_MM_DEFS_SVH
`define SF_MM_DEFS_SVH

`include "sf_sram_defs.svh"

// ------------------------------------------------------------ response status additions (3 bits, sf_sram_defs.svh uses 0..5)
`define SF_ST_PERM       3'd6   // access permission fault (region table): no array access, no side effect

// ------------------------------------------------------------ address interleaving (INTERLEAVE_MODE)
//   word index w = byte_address / WORD_BYTES ; G = 2^ILV_GRAN_LOG2 words
`define SF_MM_ILV_LOW     0     // low-order: bank = (w / G) mod NB ; consecutive G-word groups rotate through the banks
`define SF_MM_ILV_XOR     1     // permutation hash: LOW with bank ^= fold(row) ; breaks power-of-two stride conflicts
`define SF_MM_ILV_LINEAR  2     // high-order: bank = w / BANK_DEPTH ; software places operands in banks by address

// ------------------------------------------------------------ master classes (perf starvation counters)
`define SF_MC_CTRL    2'd0      // ControlCore
`define SF_MC_TENSOR  2'd1      // TensorCore
`define SF_MC_VECTOR  2'd2      // FP32 vector engine
`define SF_MC_DMA     2'd3      // CloudDMA / DataFabric

// ------------------------------------------------------------ prot metadata (m_req_prot, 2 bits)
//   prot[0] = privileged access, prot[1] = secure access
// ------------------------------------------------------------ region permission word (5 bits per region)
//   [0] read allowed  [1] write allowed  [2] privileged only  [3] secure only  [4] region enabled
`define SF_RG_R    0
`define SF_RG_W    1
`define SF_RG_PRIV 2
`define SF_RG_SEC  3
`define SF_RG_EN   4

// ------------------------------------------------------------ embedded checks of the matrix
// SF_MM_ASSERT enables the matrix's own simulation / formal checks.  SF_ASSERT (used by the reused modules) implies it; the formal flow defines
// SF_MM_ASSERT alone because the reused sf_sram_core uses `$error` under SF_ASSERT, which Yosys cannot elaborate.
`ifdef SF_ASSERT
  `ifndef SF_MM_ASSERT
    `define SF_MM_ASSERT
  `endif
`endif

`endif // SF_MM_DEFS_SVH
