// =============================================================================
// SilicaFlux MemoryMatrix :: sf_memory_matrix_decoder
// Combinational decode of ONE master request: byte address -> word addresses -> (bank, local row) for the K words
// the request can touch, plus boundary / alignment / size / permission checks.  One instance per master.
//
// ---------------------------------------------------------------- byte-addressed memory map
//   byte address a (AW bits, matrix-local: the fabric adapter strips the aperture base)
//     off   = a mod WORD_BYTES                       byte offset inside the physical word        (off_o)
//     w0    = a / WORD_BYTES                         first word index                           (internal)
//     word k (k = 0..K-1)  = w0 + k                  consecutive words an access can span
//     {row_k, bank_k} = map(w0 + k)                  physical bank and LOCAL SRAM ROW           (bank_o / row_o)
//   map() is selected by INTERLEAVE_MODE / ILV_GRAN_LOG2 (sf_mm_map.svh): LOW (plain bit selection for the
//   power-of-two bank count: bank = word[BW-1:0] when the granule is one word), XOR, LINEAR.
//   Capacity = NB * DEPTH * WORD_BYTES bytes.  map() is a bijection on [0, capacity/WORD_BYTES): no aliasing.
//
// ---------------------------------------------------------------- request fields
//   size_i  : log2 of the access size in bytes, 0 .. SZ_MAX  (SZ_MAX = log2(DATA_WIDTH/8)); larger -> SF_ST_BADOP
//   addr_i  : first byte; the access covers bytes [a, a + 2^size - 1]; it may start at any byte address
//             (MISALIGN_EN = 1: split over the words it touches) or must be naturally aligned (MISALIGN_EN = 0)
//   smask_o : lane mask, bit j = (j < 2^size): the lanes of the request that belong to the access
//
// ---------------------------------------------------------------- checks and status (first match wins)
//   SF_ST_BADOP  size_i > SZ_MAX
//   SF_ST_RANGE  any covered byte >= capacity (the check uses the LAST byte, computed without wrap-around)
//   SF_ST_ALIGN  MISALIGN_EN = 0 and a is not a multiple of 2^size
//   SF_ST_PERM   region table denies the first or the last covered byte (see below)
//   A request with a non-OK status causes no array access.
//
// ---------------------------------------------------------------- permission metadata
//   prot_i = {secure, privileged}.  NRG regions, each [base, last] (inclusive byte addresses) with permission bits
//   {en, secure_only, priv_only, W, R} and a per-master allow mask.  For a byte the LOWEST-numbered enabled region
//   containing it decides; a byte in no region follows DEFAULT_ALLOW.  An access is allowed only if BOTH its first
//   and its last byte are allowed, so an access that straddles two regions needs both to permit it.  NRG = 0
//   removes the logic (always allowed).
// Classification: SYNTHESIZABLE (combinational)
// =============================================================================
`timescale 1ns/1ps
`include "sf_mm_defs.svh"
`default_nettype none

module sf_memory_matrix_decoder #(
  parameter int NB            = 4,
  parameter int DEPTH         = 1024,       // rows (words) per bank
  parameter int LB            = 3,          // log2(WORD_BYTES)
  parameter int AW            = 32,
  parameter int SZ_MAX        = 5,          // log2(DATA_WIDTH/8)
  parameter int K             = 5,          // words an access can span
  parameter int MODE          = `SF_MM_ILV_LOW,
  parameter int GRAN          = 0,
  parameter int MISALIGN_EN   = 1,
  parameter int NRG           = 0,
  parameter int DEFAULT_ALLOW = 1,
  parameter int NM            = 4,
  // ---- derived (do not override)
  parameter int DBYTES        = 1 << SZ_MAX,
  parameter int SZW           = (SZ_MAX > 0) ? $clog2(SZ_MAX + 1) : 1,
  parameter int MW            = (NM > 1) ? $clog2(NM) : 1,
  parameter int BW            = $clog2(NB),
  parameter int ROW_W         = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int WIW           = $clog2(NB * DEPTH),
  parameter int NRGW          = (NRG > 0) ? NRG : 1
) (
  input  wire logic [AW-1:0]          addr_i,
  input  wire logic [SZW-1:0]         size_i,
  input  wire logic                   we_i,
  input  wire logic [1:0]             prot_i,
  input  wire logic [MW-1:0]          mid_i,        // master index (constant per instance)
  // region table (static configuration)
  input  wire logic [NRGW*AW-1:0]     rg_base_i,
  input  wire logic [NRGW*AW-1:0]     rg_last_i,
  input  wire logic [NRGW*5-1:0]      rg_perm_i,
  input  wire logic [NRGW*NM-1:0]     rg_mmask_i,
  // decoded request
  output logic                        err_o,
  output logic [2:0]                  status_o,
  output logic [LB-1:0]               off_o,
  output logic [DBYTES-1:0]           smask_o,
  output logic [K*BW-1:0]             bank_o,
  output logic [K*ROW_W-1:0]          row_o
);
  `include "sf_mm_map.svh"

  localparam int WB = 1 << LB;

  if (NB < 2 || (NB & (NB - 1)) != 0) begin : g_err_nb
    `SF_CFG_FATAL("sf_memory_matrix_decoder: NB must be a power of two >= 2")
  end
  if (MODE < 0 || MODE > 2) begin : g_err_mode
    `SF_CFG_FATAL("sf_memory_matrix_decoder: MODE must be 0 (LOW), 1 (XOR) or 2 (LINEAR)")
  end
  if (MODE != `SF_MM_ILV_LINEAR && (DEPTH % (1 << GRAN)) != 0) begin : g_err_gran
    `SF_CFG_FATAL("sf_memory_matrix_decoder: BANK_DEPTH must be a multiple of the interleave granule")
  end
  if ((NB * DEPTH * WB) > (64'd1 << AW)) begin : g_err_cap
    `SF_CFG_FATAL("sf_memory_matrix_decoder: capacity exceeds the 2^AW byte address space")
  end

  localparam longint unsigned CAP_B = 64'(NB) * 64'(DEPTH) * 64'(WB);
  localparam int XW = AW + 2;                                    // wide enough for addr + size without wrap

  // ------------------------------------------------------------ size, bounds, alignment
  logic [XW-1:0] nbytes, a_ext, last_ext;
  logic          badop, oor, mis;
  always_comb begin
    badop    = (size_i > SZW'(SZ_MAX));
    nbytes   = badop ? XW'(1) : (XW'(1) << size_i);
    a_ext    = XW'(addr_i);
    last_ext = a_ext + nbytes - XW'(1);
    oor      = (a_ext >= XW'(CAP_B)) || (last_ext >= XW'(CAP_B));
    mis      = (MISALIGN_EN == 0) && ((a_ext & (nbytes - XW'(1))) != '0);
    for (int j = 0; j < DBYTES; j++) smask_o[j] = (XW'(j) < nbytes) && !badop;
  end
  assign off_o = addr_i[LB-1:0];

  // ------------------------------------------------------------ permission regions
  logic [XW-1:0] last_byte;
  assign last_byte = last_ext;

  function automatic logic byte_allowed(input logic [XW-1:0] p);
    logic found, ok;
    logic [4:0]     pm;
    logic [NM-1:0]  mm;
    logic [AW-1:0]  rb, rl;
    begin
      found = 1'b0; ok = (DEFAULT_ALLOW != 0);
      for (int r = 0; r < NRG; r++) begin
        rb = rg_base_i[r*AW +: AW];
        rl = rg_last_i[r*AW +: AW];
        pm = rg_perm_i[r*5 +: 5];
        mm = rg_mmask_i[r*NM +: NM];
        if (!found && pm[`SF_RG_EN] && p >= XW'(rb) && p <= XW'(rl)) begin
          found = 1'b1;
          ok = (we_i ? pm[`SF_RG_W] : pm[`SF_RG_R]) && (!pm[`SF_RG_PRIV] || prot_i[0]) &&
               (!pm[`SF_RG_SEC] || prot_i[1]) && mm[mid_i];
        end
      end
      byte_allowed = ok;
    end
  endfunction

  logic perm_ok;
  always_comb begin
    if (NRG == 0) perm_ok = 1'b1;
    else          perm_ok = byte_allowed(a_ext) && byte_allowed(last_byte);
  end

  always_comb begin
    status_o = `SF_ST_OK;
    if      (badop)   status_o = `SF_ST_BADOP;
    else if (oor)     status_o = `SF_ST_RANGE;
    else if (mis)     status_o = `SF_ST_ALIGN;
    else if (!perm_ok) status_o = `SF_ST_PERM;
    err_o = (status_o != `SF_ST_OK);
  end

  // ------------------------------------------------------------ word / bank / row
  logic [WIW-1:0] w0;
  always_comb begin
    w0 = WIW'(addr_i >> LB);
    for (int k = 0; k < K; k++) begin
      logic [BW+ROW_W-1:0] m;
      m = mm_map(w0 + WIW'(k));
      bank_o[k*BW +: BW]      = m[BW-1:0];
      row_o[k*ROW_W +: ROW_W] = m[BW +: ROW_W];
    end
  end

  wire unused_ok = &{1'b0, mm_unmap(BW'(0), ROW_W'(0))};
endmodule

// =============================================================================
// SilicaFlux MemoryMatrix :: sf_memory_matrix_unmap
// Inverse map: (bank, local row) -> word index.  Used to report ECC event addresses as byte addresses and by the
// verification environment (round trip with the decoder proves the map is a bijection).
// =============================================================================
module sf_memory_matrix_unmap #(
  parameter int NB    = 4,
  parameter int DEPTH = 1024,
  parameter int MODE  = `SF_MM_ILV_LOW,
  parameter int GRAN  = 0,
  parameter int BW    = $clog2(NB),
  parameter int ROW_W = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int WIW   = $clog2(NB * DEPTH)
) (
  input  wire logic [BW-1:0]    bank_i,
  input  wire logic [ROW_W-1:0] row_i,
  output logic      [WIW-1:0]   word_o
);
  `include "sf_mm_map.svh"
  assign word_o = mm_unmap(bank_i, row_i);
  wire unused_ok = &{1'b0, mm_map(WIW'(0))};
endmodule

`default_nettype wire
