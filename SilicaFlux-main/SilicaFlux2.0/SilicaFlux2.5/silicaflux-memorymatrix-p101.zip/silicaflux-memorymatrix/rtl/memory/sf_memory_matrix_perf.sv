// =============================================================================
// SilicaFlux MemoryMatrix :: sf_memory_matrix_perf
// Performance instrumentation.  Pure event counting: it never influences the datapath.  All counters are free running,
// synchronously cleared by clr_i (a "measurement window" starts at the clear), 32 bit (latency sum 40 bit), and wrap on
// overflow (not saturating; 2^32 cycles = 4.3 s at 1 GHz, so windows are expected to be shorter).
//
// Definitions (cycle = one clk period; "word access" = one physical operation on one bank):
//   cycles            clocks since clr_i
//   acc_rd / acc_wr   [bank]  word accesses accepted by the bank (reads / writes).  Read utilisation of a bank
//                      = acc_rd / cycles, write utilisation = acc_wr / cycles.  A partial write on an ECC bank is ONE
//                      accepted access; its read-modify-write occupancy shows up as "busy" cycles of that bank.
//   conf              [bank]  cycles in which >= 2 masters requested this bank at the same time  (bank conflicts)
//   lost              [bank]  requester-cycles lost at this bank = requesters - accepted access (0 or 1 accepted)
//   busy              [bank]  cycles in which this bank was requested but could not accept (ECC RMW, init, scrub, test)
//   mstall            [master] cycles with m_req_valid && !m_req_ready (request queue full: back-pressure on the master)
//   arbstall          [master] cycles in which the master's request lost the bank arbitration for at least one word
//                      although the bank was ready (arbitration stall: someone else was served)
//   busystall         [master] cycles in which a word of the master's request waited for a bank that was not ready
//   selfconf          [master] cycles in which two pending words of ONE request map to the same bank (serialised
//                      by the single port: bank-spanning request with more words than distinct banks)
//   starve            [master] cycles in which the master had issue work pending but not a single word was accepted
//   starve_cls        [class]  the same, summed over the masters of a class (CTRL / TENSOR / VECTOR / DMA):
//                      "tensor starvation" = starve_cls[TENSOR], "vector starvation" = starve_cls[VECTOR]
//   reqs, bytes_rd, bytes_wr [master] completed requests; USEFUL bytes (read: 2^size, write: enabled bytes)
//   lat_sum / lat_cnt / lat_max [master] request latency = cycles from the accepting edge to the response handshake,
//                      response back-pressure included; average = lat_sum / lat_cnt
//   rej               completed requests whose status is not OK (range / align / perm / ECC)
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_mm_defs.svh"
`default_nettype none

module sf_memory_matrix_perf #(
  parameter int NB     = 4,
  parameter int NM     = 4,
  parameter int LAT_W  = 20,
  parameter int UBW    = 6,                // width of the useful-byte count of one request
  parameter int MCLASS = 32'hFFFFFFE4,     // 2 bits per master
  parameter int NRW    = (NM > 1) ? $clog2(NM + 1) : 2        // >= 2 bits: the conflict test compares against 2
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                clr_i,
  // ---- per bank, per cycle
  input  wire logic [NB-1:0]       ev_acc_i,
  input  wire logic [NB-1:0]       ev_acc_we_i,
  input  wire logic [NB*NRW-1:0]   ev_nreq_i,        // number of masters requesting the bank
  input  wire logic [NB-1:0]       ev_busy_i,        // requested and not ready
  // ---- per master, per cycle
  input  wire logic [NM-1:0]       ev_mstall_i,
  input  wire logic [NM-1:0]       ev_arbstall_i,
  input  wire logic [NM-1:0]       ev_busystall_i,
  input  wire logic [NM-1:0]       ev_selfconf_i,
  input  wire logic [NM-1:0]       ev_starve_i,
  // ---- completions (response handshake), per master
  input  wire logic [NM-1:0]       ev_pop_i,
  input  wire logic [NM-1:0]       ev_pop_we_i,
  input  wire logic [NM-1:0]       ev_pop_bad_i,     // status != OK
  input  wire logic [NM*LAT_W-1:0] ev_pop_lat_i,
  input  wire logic [NM*UBW-1:0]   ev_pop_ub_i,
  // ---- counters
  output logic [31:0]              perf_cycles_o,
  output logic [NB*32-1:0]         perf_acc_rd_o,
  output logic [NB*32-1:0]         perf_acc_wr_o,
  output logic [NB*32-1:0]         perf_conf_o,
  output logic [NB*32-1:0]         perf_lost_o,
  output logic [NB*32-1:0]         perf_busy_o,
  output logic [NM*32-1:0]         perf_mstall_o,
  output logic [NM*32-1:0]         perf_arbstall_o,
  output logic [NM*32-1:0]         perf_busystall_o,
  output logic [NM*32-1:0]         perf_selfconf_o,
  output logic [NM*32-1:0]         perf_starve_o,
  output logic [4*32-1:0]          perf_starve_cls_o,
  output logic [NM*32-1:0]         perf_reqs_o,
  output logic [NM*32-1:0]         perf_bytes_rd_o,
  output logic [NM*32-1:0]         perf_bytes_wr_o,
  output logic [NM*40-1:0]         perf_lat_sum_o,
  output logic [NM*32-1:0]         perf_lat_cnt_o,
  output logic [NM*LAT_W-1:0]      perf_lat_max_o,
  output logic [31:0]              perf_rej_o
);
  // ------------------------------------------------------------ global
  logic [31:0] c_cycles, c_rej;
  logic [31:0] rej_now;
  always_comb begin
    rej_now = '0;
    for (int i = 0; i < NM; i++) rej_now = rej_now + 32'(ev_pop_i[i] & ev_pop_bad_i[i]);
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c_cycles <= '0; c_rej <= '0;
    end else if (clr_i) begin
      c_cycles <= '0; c_rej <= '0;
    end else begin
      c_cycles <= c_cycles + 32'd1;
      c_rej    <= c_rej + rej_now;
    end
  end
  assign perf_cycles_o = c_cycles;
  assign perf_rej_o    = c_rej;

  // ------------------------------------------------------------ per bank
  for (genvar b = 0; b < NB; b++) begin : g_b
    logic [31:0] c_rd, c_wr, c_conf, c_lost, c_busy;
    wire [NRW-1:0] nreq = ev_nreq_i[b*NRW +: NRW];
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        c_rd <= '0; c_wr <= '0; c_conf <= '0; c_lost <= '0; c_busy <= '0;
      end else if (clr_i) begin
        c_rd <= '0; c_wr <= '0; c_conf <= '0; c_lost <= '0; c_busy <= '0;
      end else begin
        if (ev_acc_i[b] && !ev_acc_we_i[b]) c_rd <= c_rd + 32'd1;
        if (ev_acc_i[b] &&  ev_acc_we_i[b]) c_wr <= c_wr + 32'd1;
        if (nreq >= NRW'(2))                c_conf <= c_conf + 32'd1;
        if (nreq != '0)                     c_lost <= c_lost + 32'(nreq) - 32'(ev_acc_i[b]);
        if (ev_busy_i[b])                   c_busy <= c_busy + 32'd1;
      end
    end
    assign perf_acc_rd_o[b*32 +: 32] = c_rd;
    assign perf_acc_wr_o[b*32 +: 32] = c_wr;
    assign perf_conf_o[b*32 +: 32]   = c_conf;
    assign perf_lost_o[b*32 +: 32]   = c_lost;
    assign perf_busy_o[b*32 +: 32]   = c_busy;
  end

  // ------------------------------------------------------------ per master
  for (genvar i = 0; i < NM; i++) begin : g_m
    logic [31:0]       c_ms, c_as, c_bs, c_sc, c_st, c_rq, c_br, c_bw, c_lc;
    logic [39:0]       c_ls;
    logic [LAT_W-1:0]  c_lm;
    wire  [LAT_W-1:0]  lat = ev_pop_lat_i[i*LAT_W +: LAT_W];
    wire  [UBW-1:0]    ub  = ev_pop_ub_i[i*UBW +: UBW];
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        c_ms <= '0; c_as <= '0; c_bs <= '0; c_sc <= '0; c_st <= '0; c_rq <= '0; c_br <= '0; c_bw <= '0; c_lc <= '0;
        c_ls <= '0; c_lm <= '0;
      end else if (clr_i) begin
        c_ms <= '0; c_as <= '0; c_bs <= '0; c_sc <= '0; c_st <= '0; c_rq <= '0; c_br <= '0; c_bw <= '0; c_lc <= '0;
        c_ls <= '0; c_lm <= '0;
      end else begin
        if (ev_mstall_i[i])    c_ms <= c_ms + 32'd1;
        if (ev_arbstall_i[i])  c_as <= c_as + 32'd1;
        if (ev_busystall_i[i]) c_bs <= c_bs + 32'd1;
        if (ev_selfconf_i[i])  c_sc <= c_sc + 32'd1;
        if (ev_starve_i[i])    c_st <= c_st + 32'd1;
        if (ev_pop_i[i]) begin
          c_rq <= c_rq + 32'd1;
          if (ev_pop_we_i[i]) c_bw <= c_bw + 32'(ub);
          else                c_br <= c_br + 32'(ub);
          c_ls <= c_ls + 40'(lat);
          c_lc <= c_lc + 32'd1;
          if (lat > c_lm) c_lm <= lat;
        end
      end
    end
    assign perf_mstall_o[i*32 +: 32]    = c_ms;
    assign perf_arbstall_o[i*32 +: 32]  = c_as;
    assign perf_busystall_o[i*32 +: 32] = c_bs;
    assign perf_selfconf_o[i*32 +: 32]  = c_sc;
    assign perf_starve_o[i*32 +: 32]    = c_st;
    assign perf_reqs_o[i*32 +: 32]      = c_rq;
    assign perf_bytes_rd_o[i*32 +: 32]  = c_br;
    assign perf_bytes_wr_o[i*32 +: 32]  = c_bw;
    assign perf_lat_sum_o[i*40 +: 40]   = c_ls;
    assign perf_lat_cnt_o[i*32 +: 32]   = c_lc;
    assign perf_lat_max_o[i*LAT_W +: LAT_W] = c_lm;
  end

  // ------------------------------------------------------------ starvation per master class
  logic [4*32-1:0] cls_o;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cls_o <= '0;
    end else if (clr_i) begin
      cls_o <= '0;
    end else begin
      for (int i = 0; i < NM; i++) begin
        if (ev_starve_i[i]) begin
          for (int c = 0; c < 4; c++)
            if (((MCLASS >> (2 * i)) & 3) == c) cls_o[c*32 +: 32] <= cls_o[c*32 +: 32] + 32'd1;
        end
      end
    end
  end
  assign perf_starve_cls_o = cls_o;
endmodule

`default_nettype wire
