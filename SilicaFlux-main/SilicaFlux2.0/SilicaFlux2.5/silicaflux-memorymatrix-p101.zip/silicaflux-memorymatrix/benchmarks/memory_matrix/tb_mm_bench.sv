// =============================================================================
// tb_mm_bench -- identical-workload benchmark for sf_memory_matrix  (measures USEFUL bandwidth, not peak)
//
//  * The offered load is a pure function of (workload, master, request index n): request n of master m always has the same
//    byte address, size, direction and idle gap, whatever NUM_BANKS / interleave / ECC the DUT is built with.  The footprint is
//    fixed at 64 KiB (BANK_DEPTH * NUM_BANKS * WORD_WIDTH/8 must be >= 64 KiB).  So 4, 8 and 16 banks see EXACTLY the same traffic.
//  * Workload and length come from plusargs (+WL=n +NREQ=n +SEED=n) so one build per hardware configuration runs every workload.
//  * Every number is read from the DUT's own performance counters (sf_memory_matrix_perf); the TB adds only the makespan and a
//    data-integrity check: memory is pre-filled with content(a) = hash(a); every read must return that content.
//  * One line per run:  BENCH wl=<name> key=value ...
//
// Workloads (4 masters: 0 CTRL, 1 TENSOR, 2 VECTOR, 3 DMA)
//   0 seq8_naive      all masters stream 8-byte reads from bases that are multiples of the bank period (worst case for LOW interleave)
//   1 seq8_skew       same, bases skewed by one word per master
//   2 rand8           uniform random 8-byte accesses, 70 % reads
//   3 vec256_naive    32-byte (256-bit) aligned sequential reads, bases not skewed
//   4 vec256_skew     32-byte aligned sequential reads, bases skewed by one word per master
//   5 vec256_mis4     32-byte sequential reads starting at byte offset 4 (every access spans 5 words)
//   6 col_pitch_pow2  all masters walk the SAME column of a row-major matrix on adjacent rows, pitch 512 words (every access of every
//                     master maps to one bank under LOW interleave: the classic transpose conflict)
//   7 col_pitch_pad   the same walk with the pitch padded to 513 words (adjacent rows land in adjacent banks)
//   8 gemm_aware      TensorCore tile: A stream, B stream, C read/write partial sums, DMA tile fill; bases bank-skewed
//   9 gemm_naive      same streams, all bases aligned to the bank period
//  10 mix_system      CTRL random 4-byte (30 % duty), TENSOR A/B streaming, VECTOR 256-bit 3 reads : 1 write, DMA 256-bit writes (50 % duty)
//  11 vec128_skew     16-byte aligned sequential reads (two words), skewed bases
// =============================================================================
`timescale 1ns/1ps
`include "sf_mm_defs.svh"

module tb_mm_bench #(
  parameter int NUM_BANKS       = 4,
  parameter int BANK_DEPTH      = 2048,
  parameter int WORD_WIDTH      = 64,
  parameter int DATA_WIDTH      = 256,
  parameter int READ_LATENCY    = 1,
  parameter int NUM_MASTERS     = 4,
  parameter int ENABLE_ECC      = 0,
  parameter int NSLOT           = 8,
  parameter int ISSUE_WINDOW    = 1,
  parameter int ARB             = 1,
  parameter int INTERLEAVE_MODE = 0,
  parameter int ILV_GRAN_LOG2   = 0,
  parameter int MISALIGN_EN     = 1
);
  localparam int AW     = 20;
  localparam int IDW    = 8;
  localparam int NB     = NUM_BANKS;
  localparam int NM     = NUM_MASTERS;
  localparam int WB     = WORD_WIDTH / 8;
  localparam int LB     = $clog2(WB);
  localparam int DBYTES = DATA_WIDTH / 8;
  localparam int SZ_MAX = $clog2(DBYTES);
  localparam int SZW    = $clog2(SZ_MAX + 1);
  localparam int MW     = (NM > 1) ? $clog2(NM) : 1;
  localparam int K      = (MISALIGN_EN != 0) ? (DBYTES + 2 * WB - 2) / WB : (DBYTES + WB - 1) / WB;
  localparam int KW     = (K > 1) ? $clog2(K) : 1;
  localparam int SW     = (NSLOT > 1) ? $clog2(NSLOT) : 1;
  localparam int BW     = $clog2(NB);
  localparam int ROW_W  = $clog2(BANK_DEPTH);
  localparam int R_ECC  = $clog2(WORD_WIDTH + $clog2(WORD_WIDTH + 1) + 1);
  localparam int STORE_W = (ENABLE_ECC != 0) ? WORD_WIDTH + R_ECC + 1 : WORD_WIDTH;
  localparam int FBW    = (STORE_W > 1) ? $clog2(STORE_W) : 1;
  localparam int LAT_W  = 20;
  localparam int CAPB   = NB * BANK_DEPTH * WB;
  localparam int FOOT   = 65536;
  localparam int REG    = 16384;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NM-1:0]             m_req_valid;
  wire  [NM-1:0]             m_req_ready;
  logic [NM-1:0]             m_req_we;
  logic [NM*AW-1:0]          m_req_addr;
  logic [NM*SZW-1:0]         m_req_size;
  logic [NM*DATA_WIDTH-1:0]  m_req_wdata;
  logic [NM*DBYTES-1:0]      m_req_be;
  logic [NM*IDW-1:0]         m_req_id;
  wire  [NM-1:0]             m_rsp_valid;
  logic [NM-1:0]             m_rsp_ready = '1;
  wire  [NM*DATA_WIDTH-1:0]  m_rsp_rdata;
  wire  [NM*3-1:0]           m_rsp_status;
  wire  [NM-1:0]             m_rsp_we, m_rsp_ce;
  wire  [NM*IDW-1:0]         m_rsp_id;
  logic                      perf_clr_i = 0;
  wire  [31:0]               perf_cycles_o, perf_rej_o;
  wire  [NB*32-1:0]          perf_acc_rd_o, perf_acc_wr_o, perf_conf_o, perf_lost_o, perf_busy_o;
  wire  [NM*32-1:0]          perf_mstall_o, perf_arbstall_o, perf_busystall_o, perf_selfconf_o, perf_starve_o, perf_reqs_o, perf_bytes_rd_o, perf_bytes_wr_o, perf_lat_cnt_o;
  wire  [4*32-1:0]           perf_starve_cls_o;
  wire  [NM*40-1:0]          perf_lat_sum_o;
  wire  [NM*LAT_W-1:0]       perf_lat_max_o;
  wire  [NB-1:0]             trc_acc_o, trc_we_o;
  wire  [NB*MW-1:0]          trc_m_o;
  wire  [NB*SW-1:0]          trc_slot_o;
  wire  [NB*KW-1:0]          trc_k_o;
  wire  [NB*ROW_W-1:0]       trc_row_o;
  wire  [NB*STORE_W-1:0]     tst_rdata_o;
  wire  [NB-1:0]             ev_ce_o, ev_ue_o;
  wire  [NB*AW-1:0]          ev_addr_o;
  wire  [NB*16-1:0]          ce_cnt_o, ue_cnt_o;
  wire                       idle_o, init_busy_o, flush_busy_o;

  sf_memory_matrix #(
    .NUM_BANKS(NUM_BANKS), .BANK_DEPTH(BANK_DEPTH), .WORD_WIDTH(WORD_WIDTH), .DATA_WIDTH(DATA_WIDTH), .READ_LATENCY(READ_LATENCY),
    .NUM_MASTERS(NUM_MASTERS), .ENABLE_ECC(ENABLE_ECC), .AW(AW), .IDW(IDW), .NSLOT(NSLOT), .ISSUE_WINDOW(ISSUE_WINDOW), .ARB(ARB),
    .INTERLEAVE_MODE(INTERLEAVE_MODE), .ILV_GRAN_LOG2(ILV_GRAN_LOG2), .MISALIGN_EN(MISALIGN_EN), .NUM_REGIONS(0), .FAULT_INJECT(0)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we), .m_req_addr(m_req_addr), .m_req_size(m_req_size),
    .m_req_wdata(m_req_wdata), .m_req_be(m_req_be), .m_req_id(m_req_id), .m_req_prot({NM{2'b11}}),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_id(m_rsp_id), .m_rsp_we(m_rsp_we),
    .m_rsp_status(m_rsp_status), .m_rsp_ce(m_rsp_ce),
    .rg_base_i({AW{1'b0}}), .rg_last_i({AW{1'b0}}), .rg_perm_i(5'd0), .rg_mmask_i({NM{1'b0}}),
    .flush_i(1'b0), .flush_busy_o(flush_busy_o), .quiesce_i(1'b0), .idle_o(idle_o), .init_start_i(1'b0), .init_busy_o(init_busy_o), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(ev_ce_o), .ev_ue_o(ev_ue_o), .ev_addr_o(ev_addr_o), .ce_cnt_o(ce_cnt_o), .ue_cnt_o(ue_cnt_o),
    .perf_clr_i(perf_clr_i), .perf_cycles_o(perf_cycles_o), .perf_acc_rd_o(perf_acc_rd_o), .perf_acc_wr_o(perf_acc_wr_o),
    .perf_conf_o(perf_conf_o), .perf_lost_o(perf_lost_o), .perf_busy_o(perf_busy_o), .perf_mstall_o(perf_mstall_o),
    .perf_arbstall_o(perf_arbstall_o), .perf_busystall_o(perf_busystall_o), .perf_selfconf_o(perf_selfconf_o),
    .perf_starve_o(perf_starve_o), .perf_starve_cls_o(perf_starve_cls_o), .perf_reqs_o(perf_reqs_o),
    .perf_bytes_rd_o(perf_bytes_rd_o), .perf_bytes_wr_o(perf_bytes_wr_o), .perf_lat_sum_o(perf_lat_sum_o),
    .perf_lat_cnt_o(perf_lat_cnt_o), .perf_lat_max_o(perf_lat_max_o), .perf_rej_o(perf_rej_o),
    .trc_acc_o(trc_acc_o), .trc_we_o(trc_we_o), .trc_m_o(trc_m_o), .trc_slot_o(trc_slot_o), .trc_k_o(trc_k_o), .trc_row_o(trc_row_o),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W{1'b0}}), .tst_wdata_i({STORE_W{1'b0}}),
    .tst_rdata_o(tst_rdata_o),
    .fi_bank({BW{1'b0}}), .fi_type(4'd0), .fi_row({ROW_W{1'b0}}), .fi_row2({ROW_W{1'b0}}), .fi_bit({FBW{1'b0}}), .fi_bit2({FBW{1'b0}}),
    .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({ROW_W{1'b0}}), .seu_mask({STORE_W{1'b0}}));

  // ------------------------------------------------------------ content pattern and hashing
  function automatic logic [7:0] pat(input int a);
    logic [31:0] x;
    begin x = 32'(a) * 32'h9E3779B1; x = x ^ (x >> 15); x = x * 32'h85EBCA6B; pat = x[23:16] ^ x[7:0]; end
  endfunction
  function automatic logic [31:0] hash3(input int a, input int b, input int c);
    logic [31:0] x;
    begin
      x = 32'(a) * 32'h9E3779B1 ^ 32'(b) * 32'h85EBCA6B ^ 32'(c) * 32'hC2B2AE35;
      x = x ^ (x >> 16); x = x * 32'h7FEB352D; x = x ^ (x >> 15); x = x * 32'h846CA68B; x = x ^ (x >> 16);
      hash3 = x;
    end
  endfunction

  // ------------------------------------------------------------ the workloads: (m, n) -> address, size, direction, idle gap
  int  WL, NREQ, SEED;
  function automatic void gen(input int wl, input int m, input int n, output int a, output int sz, output bit we, output int gap);
    int p, row, col, h, base, st;
    int unsigned hh;
    begin
      sz = LB; we = 0; gap = 0; a = 0;
      hh = hash3(SEED, m, n);
      case (wl)
        0: begin a = (m * REG + 8 * n) % FOOT; end
        1: begin a = (m * REG + 8 * m + 8 * n) % FOOT; end
        2: begin a = (hh >> 8) % (FOOT / 8) * 8; we = ((hh & 255) < 77); end
        3: begin sz = SZ_MAX; a = (m * REG + 32 * n) % FOOT; end
        4: begin sz = SZ_MAX; a = (m * REG + 8 * m + 32 * n) % FOOT; end
        5: begin sz = SZ_MAX; a = (m * REG + 4 + 32 * n) % FOOT; end
        6: begin p = 512; row = n % 32 + m; col = (n / 32) % 16; a = ((row * p + col) * 8) % FOOT; end
        7: begin p = 513; row = n % 32 + m; col = (n / 32) % 16; a = ((row * p + col) * 8) % FOOT; end
        8, 9: begin
             st = (wl == 8) ? 1 : 0;
             case (m)
               0: begin a = (0 * REG + 8 * st * 0 + 8 * n) % FOOT; end                           // A stream: 8 B per cycle
               1: begin a = (1 * REG + 8 * st * 1 + 8 * n) % FOOT; end                           // B stream
               2: begin a = (2 * REG + 8 * st * 2 + 8 * (n / 2)) % FOOT; we = n[0]; end          // C partial sums: read then write same word
               default: begin sz = SZ_MAX; a = (3 * REG + 8 * st * 3 + 32 * n) % FOOT; we = 1; gap = (n % 2); end   // DMA fills the next tile (256-bit writes)
             endcase
           end
        10: begin
             case (m)
               0: begin sz = 2; a = ((hh >> 8) % 1024) * 4; we = ((hh & 255) < 90); gap = ((hh >> 20) % 100 < 70) ? 2 : 0; end   // CTRL ~30 % duty
               1: begin a = (1 * REG + 8 + 8 * n) % FOOT; end                                                                  // TENSOR stream
               2: begin sz = SZ_MAX; a = (2 * REG + 16 + 32 * (n - n / 4)) % FOOT; we = (n % 4 == 3); end                       // VECTOR 3 reads : 1 write
               default: begin sz = SZ_MAX; a = (3 * REG + 24 + 32 * n) % FOOT; we = 1; gap = (n % 2); end                       // DMA 50 % duty
             endcase
           end
        11: begin sz = (SZ_MAX >= 4) ? 4 : SZ_MAX; a = (m * REG + 8 * m + 16 * n) % FOOT; end
        default: begin a = (hh >> 8) % (FOOT / 8) * 8; end
      endcase
    end
  endfunction

  function automatic string wl_name(input int wl);
    case (wl)
      0: wl_name = "seq8_naive";  1: wl_name = "seq8_skew";      2: wl_name = "rand8";         3: wl_name = "vec256_naive";
      4: wl_name = "vec256_skew"; 5: wl_name = "vec256_mis4";    6: wl_name = "col_pitch_pow2"; 7: wl_name = "col_pitch_pad";
      8: wl_name = "gemm_aware";  9: wl_name = "gemm_naive";     10: wl_name = "mix_system";   11: wl_name = "vec128_skew";
      default: wl_name = "other";
    endcase
  endfunction

  // ------------------------------------------------------------ driver (single clocked process, NBA only)
  int  errors = 0, checks = 0;
  int  issued [0:NM-1];
  int  gap_left [0:NM-1];
  int  rcvd [0:NM-1];
  int  mode;                                   // 0 idle, 1 prefill, 2 workload
  int  pf_next;                                // prefill address
  bit  v_q [0:NM-1];
  int  a_q [0:NM-1];
  int  s_q [0:NM-1];
  bit  w_q [0:NM-1];
  int  cyc = 0;
  bit  clr_req = 0;
  bit  rst_req = 0;
  longint total_rsp = 0;
  // outstanding expected read contents per master (FIFO of (addr, size, we)) -- responses return in order
  int  q_addr [0:NM-1][0:63];
  int  q_size [0:NM-1][0:63];
  bit  q_we   [0:NM-1][0:63];
  int  q_hd [0:NM-1];
  int  q_tl [0:NM-1];

  always @(posedge clk) begin
    cyc <= cyc + 1;
    // ---- accept / response bookkeeping
    for (int m = 0; m < NM; m++) begin
      if (m_req_valid[m] && m_req_ready[m]) begin
        q_addr[m][q_tl[m] % 64] = a_q[m]; q_size[m][q_tl[m] % 64] = s_q[m]; q_we[m][q_tl[m] % 64] = w_q[m]; q_tl[m]++;
        v_q[m] = 0; issued[m]++;
      end
      if (m_rsp_valid[m] && m_rsp_ready[m]) begin
        int qa, qs;
        bit qw;
        qa = q_addr[m][q_hd[m] % 64]; qs = q_size[m][q_hd[m] % 64]; qw = q_we[m][q_hd[m] % 64]; q_hd[m]++;
        rcvd[m]++; total_rsp++;
        checks++;
        if (m_rsp_status[m*3 +: 3] != 3'd0) begin errors++; if (errors < 10) $display("  ERROR m%0d status %0d addr %0d", m, m_rsp_status[m*3 +: 3], qa); end
        if (!qw && mode == 2) begin
          for (int j = 0; j < (1 << qs); j++) begin
            checks++;
            if (m_rsp_rdata[m*DATA_WIDTH + 8*j +: 8] !== pat(qa + j)) begin
              errors++;
              if (errors < 10) $display("  ERROR m%0d data mismatch addr %0d lane %0d: got %0h want %0h", m, qa, j, m_rsp_rdata[m*DATA_WIDTH + 8*j +: 8], pat(qa + j));
            end
          end
        end
      end
    end
    // ---- next requests
    for (int m = 0; m < NM; m++) begin
      if (!v_q[m]) begin
        if (mode == 1 && m == 0 && pf_next < FOOT) begin                       // prefill: 32-byte writes of the content pattern
          v_q[m] = 1; a_q[m] = pf_next; s_q[m] = SZ_MAX; w_q[m] = 1; pf_next += DBYTES;
        end else if (mode == 2 && issued[m] < NREQ) begin
          if (gap_left[m] > 0) gap_left[m]--;
          else begin
            int a, sz, gp;
            bit we;
            gen(WL, m, issued[m], a, sz, we, gp);
            if (a + (1 << sz) > FOOT) a = a % (FOOT - (1 << sz));
            v_q[m] = 1; a_q[m] = a; s_q[m] = sz; w_q[m] = we;
            gap_left[m] = gp;
          end
        end
      end
    end
    for (int m = 0; m < NM; m++) begin
      m_req_valid[m] <= v_q[m] & rst_n;
      m_req_we[m]    <= w_q[m];
      m_req_addr[m*AW +: AW] <= AW'(a_q[m]);
      m_req_size[m*SZW +: SZW] <= SZW'(s_q[m]);
      m_req_be[m*DBYTES +: DBYTES] <= '1;
      m_req_id[m*IDW +: IDW] <= IDW'(issued[m]);
      for (int j = 0; j < DBYTES; j++) m_req_wdata[m*DATA_WIDTH + 8*j +: 8] <= pat(a_q[m] + j);
    end
    perf_clr_i <= clr_req; clr_req = 0;
    rst_n <= rst_req;
  end

  longint sum_rd, sum_wr, sum_acc, sum_bytes, sum_conf, sum_lost, sum_busy, sum_as, sum_bs, sum_sc, sum_mst, sum_st, sum_reqs;
  longint lat100 [0:NM-1];
  int     latmax [0:NM-1];
  int     t0, t1;
  string  name;

  initial begin
    if (NM != 4) begin $display("BENCH ERROR the workloads assume NUM_MASTERS = 4"); $finish; end
    if (!$value$plusargs("WL=%d", WL)) WL = 0;
    if (!$value$plusargs("NREQ=%d", NREQ)) NREQ = 3000;
    if (!$value$plusargs("SEED=%d", SEED)) SEED = 1;
    for (int m = 0; m < NM; m++) begin issued[m] = 0; rcvd[m] = 0; gap_left[m] = 0; v_q[m] = 0; a_q[m] = 0; s_q[m] = 0; w_q[m] = 0; q_hd[m] = 0; q_tl[m] = 0; end
    m_req_valid = '0; m_req_we = '0; m_req_addr = '0; m_req_size = '0; m_req_wdata = '0; m_req_be = '0; m_req_id = '0;
    mode = 0; pf_next = 0;
    if (CAPB < FOOT) begin $display("BENCH ERROR capacity %0d < footprint %0d", CAPB, FOOT); $finish; end
    repeat (4) @(posedge clk);
    rst_req = 1;
    repeat (3) @(posedge clk);
    while (!idle_o) @(posedge clk);                      // ECC: wait for the init engine
    repeat (4) @(posedge clk);
    // prefill the footprint with content(a) = pat(a)
    mode = 1;
    while (pf_next < FOOT || rcvd[0] < FOOT / DBYTES) @(posedge clk);
    mode = 0;
    repeat (6) @(posedge clk);
    // measurement window
    for (int m = 0; m < NM; m++) begin issued[m] = 0; rcvd[m] = 0; end
    clr_req = 1;
    repeat (3) @(posedge clk);
    t0 = cyc;
    mode = 2;
    begin
      bit done;
      done = 0;
      while (!done) begin
        @(posedge clk);
        done = 1;
        for (int m = 0; m < NM; m++) if (rcvd[m] < NREQ) done = 0;
        if (cyc - t0 > 4000000) begin $display("BENCH ERROR timeout"); errors++; done = 1; end
      end
    end
    t1 = cyc;
    @(negedge clk);
    sum_rd = 0; sum_wr = 0; sum_acc = 0; sum_bytes = 0; sum_conf = 0; sum_lost = 0; sum_busy = 0; sum_as = 0; sum_bs = 0; sum_sc = 0; sum_mst = 0; sum_st = 0; sum_reqs = 0;
    for (int b = 0; b < NB; b++) begin
      sum_rd   += perf_acc_rd_o[b*32 +: 32]; sum_wr += perf_acc_wr_o[b*32 +: 32];
      sum_acc  += perf_acc_rd_o[b*32 +: 32] + perf_acc_wr_o[b*32 +: 32];
      sum_conf += perf_conf_o[b*32 +: 32]; sum_lost += perf_lost_o[b*32 +: 32]; sum_busy += perf_busy_o[b*32 +: 32];
    end
    for (int m = 0; m < NM; m++) begin
      sum_bytes += perf_bytes_rd_o[m*32 +: 32] + perf_bytes_wr_o[m*32 +: 32];
      sum_reqs  += perf_reqs_o[m*32 +: 32];
      sum_as += perf_arbstall_o[m*32 +: 32]; sum_bs += perf_busystall_o[m*32 +: 32]; sum_sc += perf_selfconf_o[m*32 +: 32];
      sum_mst += perf_mstall_o[m*32 +: 32]; sum_st += perf_starve_o[m*32 +: 32];
      lat100[m] = (perf_lat_cnt_o[m*32 +: 32] != 0) ? (100 * longint'(perf_lat_sum_o[m*40 +: 40])) / longint'(perf_lat_cnt_o[m*32 +: 32]) : 0;
      latmax[m] = int'(perf_lat_max_o[m*LAT_W +: LAT_W]);
    end
    name = wl_name(WL);
    $display("BENCH wl=%s banks=%0d ecc=%0d ilv=%0d/%0d L=%0d nslot=%0d nreq=%0d makespan=%0d perf_cycles=%0d reqs=%0d useful_bytes=%0d bank_accesses=%0d acc_rd=%0d acc_wr=%0d bank_conf_cycles=%0d bank_lost=%0d bank_busy=%0d arb_stall=%0d busy_stall=%0d self_conf=%0d mstall=%0d starve_total=%0d starve_ctrl=%0d starve_tensor=%0d starve_vector=%0d starve_dma=%0d lat100_0=%0d lat100_1=%0d lat100_2=%0d lat100_3=%0d latmax0=%0d latmax1=%0d latmax2=%0d latmax3=%0d integrity_errors=%0d checks=%0d",
             name, NB, ENABLE_ECC, INTERLEAVE_MODE, ILV_GRAN_LOG2, READ_LATENCY, NSLOT, NREQ, t1 - t0, perf_cycles_o, sum_reqs,
             sum_bytes, sum_acc, sum_rd, sum_wr, sum_conf, sum_lost, sum_busy, sum_as, sum_bs, sum_sc, sum_mst, sum_st,
             perf_starve_cls_o[0 +: 32], perf_starve_cls_o[32 +: 32], perf_starve_cls_o[64 +: 32], perf_starve_cls_o[96 +: 32],
             lat100[0], lat100[1], lat100[2], lat100[3], latmax[0], latmax[1], latmax[2], latmax[3], errors, checks);
    $finish;
  end
endmodule
