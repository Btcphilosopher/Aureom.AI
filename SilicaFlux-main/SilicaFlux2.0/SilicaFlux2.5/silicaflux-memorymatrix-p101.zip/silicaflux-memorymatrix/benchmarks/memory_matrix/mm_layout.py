#!/usr/bin/env python3
"""Data placement for tiled matrix multiplication on sf_memory_matrix (A operands, B operands, partial sums C, DMA fill buffer).

  python3 benchmarks/memory_matrix/mm_layout.py [--nb 4] [--mode 0] [--gran 0] [--tile 8 8 32] [--md reports/layout.md]

What it decides (all by EXACT enumeration over the same address map the RTL implements, benchmarks/memory_matrix/mm_analysis.py):
  * the row PITCH of every operand tile: padded so that walking a column (the access a systolic array makes to B, or a transpose of A)
    spreads over the banks instead of hitting one bank (pitch 512 words -> 1 bank; 513 -> all banks for LOW interleave);
  * the BASE ADDRESS of every operand stream, skewed so that the streams the compute unit reads in LOCK STEP (A[k], B[k], C[k],
    and the DMA filling the next buffer) address DIFFERENT banks in every cycle;
  * the number of ping-pong buffers and the footprint.
Each result is re-verified: lock-step streams are replayed and counted, the column walk is replayed and counted.  If no
conflict-free placement exists (more streams than banks) the tool says so instead of returning a placement.
"""
import argparse, itertools, sys
from mm_analysis import AddrMap, mode_name

WB = 8   # bytes per physical word


def column_distinct(m, pitch, masters=4, rows=64):
    """mean distinct banks over `rows` steps when `masters` masters read the same column on adjacent rows"""
    tot = 0
    for r in range(rows):
        tot += len({m.bank((r + mm) * pitch) for mm in range(masters)})
    return tot / rows


def best_pitch(m, pmin, masters=4, span=None):
    """smallest pitch >= pmin (in words) with the best column-walk bank parallelism"""
    span = span or 2 * m.nb + 1
    best = None
    for p in range(pmin, pmin + span):
        d = column_distinct(m, p, masters)
        if best is None or d > best[1] + 1e-9:
            best = (p, d)
        if d >= masters - 1e-9:
            return p, d
    return best


def lockstep_conflicts(m, bases, steps=512, stop_after=None):
    """number of cycles (of `steps`) in which two lock-step unit-stride streams address one bank (stops early after `stop_after`)"""
    bad = 0
    for k in range(steps):
        banks = [m.bank(b + k) for b in bases]
        bad += (len(set(banks)) != len(banks))
        if stop_after is not None and bad > stop_after:
            break
    return bad


def skew_bases(m, nstreams, region_words, steps=512, span=None):
    """choose base word offsets (stream 0 at 0) minimising lock-step conflicts; streams live in separate regions of region_words"""
    span = span or max(2 * m.nb, m.nb * (1 << m.gran))
    best = None
    for offs in itertools.product(range(span), repeat=nstreams - 1):
        bases = [0] + [o + (i + 1) * region_words for i, o in enumerate(offs)]
        c = lockstep_conflicts(m, bases, steps, stop_after=(best[0] if best else None))
        if best is None or c < best[0]:
            best = (c, bases)
        if c == 0:
            break
    return best


def plan(nb, mode, gran, tm, tn, tk, a_bytes=1, b_bytes=1, c_bytes=4, nbuf=2, depth=4096):
    m = AddrMap(nb, depth, mode, gran)
    # row pitches in words: A is tm x tk (row-major, k contiguous), B is tk x tn (row-major, n contiguous), C is tm x tn
    a_pw = max(1, -(-tk * a_bytes // WB))
    b_pw = max(1, -(-tn * b_bytes // WB))
    c_pw = max(1, -(-tn * c_bytes // WB))
    a_p, a_d = best_pitch(m, a_pw)
    b_p, b_d = best_pitch(m, b_pw)
    c_p, c_d = best_pitch(m, c_pw)
    a_words, b_words, c_words = tm * a_p, tk * b_p, tm * c_p
    region = max(a_words, b_words, c_words)
    region = -(-region // (nb * (1 << gran))) * (nb * (1 << gran))          # regions start on a bank period: only the SKEW decides the bank phase
    c, bases = skew_bases(m, 4, region)
    res = dict(nb=nb, mode=mode_name(mode, gran), tile=(tm, tn, tk),
               A=dict(base_words=bases[0], pitch_words=a_p, col_distinct=a_d, words=a_words),
               B=dict(base_words=bases[1], pitch_words=b_p, col_distinct=b_d, words=b_words),
               C=dict(base_words=bases[2], pitch_words=c_p, col_distinct=c_d, words=c_words),
               DMA=dict(base_words=bases[3]), lockstep_conflict_cycles_of_512=c,
               footprint_bytes=(bases[3] - bases[0] + region) * WB * nbuf // 1, nbuf=nbuf,
               conflict_free=(c == 0))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nb", type=int, default=0)
    ap.add_argument("--mode", type=int, default=0)
    ap.add_argument("--gran", type=int, default=0)
    ap.add_argument("--tile", type=int, nargs=3, default=[8, 8, 32])
    ap.add_argument("--md", default="reports/layout.md")
    a = ap.parse_args()
    nbs = [a.nb] if a.nb else [4, 8, 16]
    md = ["# MemoryMatrix tile placement (exact enumeration)\n",
          "Tile = (M, N, K) elements; A is M x K INT8, B is K x N INT8, C is M x N INT32 (partial sums).  Four lock-step streams: "
          "A[k], B[k], C (read-modify-write) and the DMA fill of the next buffer.  `naive` = every operand at a bank-period boundary "
          "with the minimal pitch; `planned` = padded pitch + skewed bases chosen by this tool.\n",
          "| banks | interleave | tile | A pitch | B pitch | C pitch | bases A/B/C/DMA (words mod NB) | lock-step conflict cycles of 512: naive -> planned | column distinct banks B: naive -> planned |",
          "|---|---|---|---|---|---|---|---|---|"]
    for nb in nbs:
        for mode, gran in ([(a.mode, a.gran)] if a.nb else [(0, 0), (1, 0), (0, 2)]):
            p = plan(nb, mode, gran, *a.tile)
            m = AddrMap(nb, 4096, mode, gran)
            region = max(p["A"]["words"], p["B"]["words"], p["C"]["words"])
            region = -(-region // (nb * (1 << gran))) * (nb * (1 << gran))
            naive_bases = [0, region, 2 * region, 3 * region]
            naive_c = lockstep_conflicts(m, naive_bases)
            b_pw = max(1, -(-a.tile[1] * 1 // WB))
            naive_col = column_distinct(m, b_pw)
            bm = [p[k]["base_words"] % nb for k in ("A", "B", "C", "DMA")]
            md.append(f"| {nb} | {p['mode']} | {a.tile} | {p['A']['pitch_words']} | {p['B']['pitch_words']} | {p['C']['pitch_words']} | {bm} | "
                      f"{naive_c} -> {p['lockstep_conflict_cycles_of_512']} | {naive_col:.2f} -> {p['B']['col_distinct']:.2f} |")
    md.append("\nReading: a plan with 0 lock-step conflict cycles feeds A, B, C and the DMA at one word per stream per cycle with NO bank "
              "conflict; any non-zero value means no placement exists for that interleave (e.g. XOR hashing breaks unit-stride lock step at "
              "4 banks: use LOW for streamed tiles and XOR/padding only where column walks dominate).")
    open(a.md, "w").write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    sys.exit(main())
