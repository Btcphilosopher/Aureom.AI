#!/usr/bin/env python3
"""Analytical model of sf_memory_matrix address organisation and bandwidth ceilings (independent of the RTL).

  python3 benchmarks/memory_matrix/mm_analysis.py [--out reports/analysis.json] [--md reports/analysis.md]

Everything here is EXACT ENUMERATION / ARITHMETIC over the address map, not simulation:
  A  tensor operand streams (A, B, C in lock step, one word per cycle each): for which base placements are they conflict free?
  B  column walks of a row-major matrix (pitch padding): bank parallelism per interleave mode
  C  vector loads of 128 / 256 bit at every byte misalignment: words, banks, self conflicts, useful fraction
  D  client bandwidth demand vs. bank supply (TensorCore 4x4 / 8x8 INT8, FP32 vector array N lanes)
  E  lower bounds on the makespan of the benchmark workloads (bit-exact mirror of the address generator in tb_mm_bench.sv);
     the RTL measurement is compared with these bounds by run_bench.py
No claim here is a silicon or timing result.
"""
import argparse, itertools, json, math, sys

M32 = 0xFFFFFFFF


# ------------------------------------------------------------------------------------------------ address map (integer maths)
class AddrMap:
    def __init__(self, nb, depth, mode=0, gran=0):
        self.nb, self.depth, self.mode, self.gran = nb, depth, mode, gran

    @staticmethod
    def _fold(row, nb):
        f = 0
        while row > 0:
            f ^= row % nb
            row //= nb
        return f

    def bank_row(self, w):
        g = 1 << self.gran
        if self.mode == 2:
            return w // self.depth, w % self.depth
        b = (w // g) % self.nb
        row = (w // (g * self.nb)) * g + (w % g)
        if self.mode == 1:
            b ^= self._fold(row, self.nb)
        return b, row

    def bank(self, w):
        return self.bank_row(w)[0]


def mode_name(mode, gran):
    return {0: "LOW", 1: "XOR", 2: "LINEAR"}[mode] + (f"/g{1 << gran}" if gran and mode != 2 else "")


MODES = [(0, 0), (0, 2), (1, 0), (2, 0)]
NBS = [4, 8, 16]


# ------------------------------------------------------------------------------------------------ A. tensor streams
def streams_conflict_free(nb, mode, gran, s, depth=4096, steps=None):
    """Fraction of base placements (offset tuples, first stream fixed at 0) for which S unit-stride streams advancing one word
    per cycle never address one bank in the same cycle.  Exhaustive over offsets in [0, max(2*NB, NB*G)) (the LOW map is periodic in NB*G words; XOR folds row bits, so 8*NB*G steps are tracked)."""
    m = AddrMap(nb, depth, mode, gran)
    steps = steps or 8 * nb * (1 << gran)
    span = max(2 * nb, nb * (1 << gran))      # one full bank period at least (the period is NB*G words for granule G)
    ok = tot = 0
    for offs in itertools.product(range(span), repeat=s - 1):
        bases = (0,) + offs
        good = True
        for k in range(steps):
            banks = [m.bank(b + k) for b in bases]
            if len(set(banks)) != len(banks):
                good = False
                break
        ok += good
        tot += 1
    return ok / tot


# ------------------------------------------------------------------------------------------------ B. column walks
def column_walk_parallelism(nb, mode, gran, pitch, masters=4, rows=64, depth=4096):
    """All masters walk the same column on adjacent rows (row = r + m).  Returns the mean number of DISTINCT banks hit per step
    (= masters is conflict free) and the resulting serialisation factor (cycles per step = max requests per bank)."""
    m = AddrMap(nb, depth, mode, gran)
    dist = 0.0
    cyc = 0.0
    for r in range(rows):
        banks = [m.bank((r + mm) * pitch) for mm in range(masters)]
        dist += len(set(banks))
        cyc += max(banks.count(b) for b in set(banks))
    return dist / rows, cyc / rows


# ------------------------------------------------------------------------------------------------ C. vector splits
def vector_split(nb, mode, gran, size, off, wb=8, depth=4096):
    """Bytes [off, off+size) from word-aligned start: words touched, banks touched, cycles when one master issues one word per bank
    per cycle (= max words per bank), useful fraction."""
    m = AddrMap(nb, depth, mode, gran)
    w0 = off // wb
    w1 = (off + size - 1) // wb
    words = list(range(w0, w1 + 1))
    banks = [m.bank(w) for w in words]
    cyc = max(banks.count(b) for b in set(banks))
    return dict(words=len(words), banks=len(set(banks)), cycles=cyc, useful=size / (len(words) * wb))


# ------------------------------------------------------------------------------------------------ D. client demand vs supply
def client_demand():
    rows = []
    # TensorCore08: systolic ARRAY_ROWS x ARRAY_COLS, INT8 operands, INT32 accumulate; per cycle one A column slice and one B row slice
    for dim in (4, 8):
        rows.append(dict(client=f"TensorCore {dim}x{dim} INT8 systolic", read_Bpc=2 * dim, write_Bpc=0,
                         note="A column slice + B row slice per cycle; C tile (INT32, %d B) written once per K loop" % (4 * dim * dim)))
    for n in (2, 4, 8, 16):
        rows.append(dict(client=f"FP32 vector array {n} lanes", read_Bpc=3 * 4 * n, write_Bpc=4 * n,
                         note="operands a, b, c (3 x N x 4 B) read and N x 4 B written per beat, one beat per cycle"))
    rows.append(dict(client="ControlCore RV32 load/store", read_Bpc=4, write_Bpc=0, note="at most one 4-byte access per cycle (typically far less)"))
    rows.append(dict(client="CloudDMA 256-bit stream", read_Bpc=32, write_Bpc=0, note="one 32-byte beat per cycle when streaming"))
    for r in rows:
        r["total_Bpc"] = r["read_Bpc"] + r["write_Bpc"]
        r["words64_per_cycle"] = r["total_Bpc"] / 8
        r["min_banks_conflict_free"] = math.ceil(r["total_Bpc"] / 8)
    return rows


# ------------------------------------------------------------------------------------------------ E. workload mirror
def hash3(a, b, c):
    x = ((a * 0x9E3779B1) & M32) ^ ((b * 0x85EBCA6B) & M32) ^ ((c * 0xC2B2AE35) & M32)
    x ^= x >> 16
    x = (x * 0x7FEB352D) & M32
    x ^= x >> 15
    x = (x * 0x846CA68B) & M32
    x ^= x >> 16
    return x


FOOT, REG = 65536, 16384
WL_NAMES = ["seq8_naive", "seq8_skew", "rand8", "vec256_naive", "vec256_skew", "vec256_mis4", "col_pitch_pow2", "col_pitch_pad",
            "gemm_aware", "gemm_naive", "mix_system", "vec128_skew"]


def gen(wl, m, n, seed, sz_max=5, lb=3):
    """Bit-exact mirror of gen() in tb_mm_bench.sv.  Returns (addr, size_log2, is_write, gap)."""
    hh = hash3(seed, m, n)
    sz, we, gap, a = lb, 0, 0, 0
    if wl == 0:
        a = (m * REG + 8 * n) % FOOT
    elif wl == 1:
        a = (m * REG + 8 * m + 8 * n) % FOOT
    elif wl == 2:
        a = ((hh >> 8) % (FOOT // 8)) * 8
        we = 1 if (hh & 255) < 77 else 0
    elif wl == 3:
        sz = sz_max
        a = (m * REG + 32 * n) % FOOT
    elif wl == 4:
        sz = sz_max
        a = (m * REG + 8 * m + 32 * n) % FOOT
    elif wl == 5:
        sz = sz_max
        a = (m * REG + 4 + 32 * n) % FOOT
    elif wl in (6, 7):
        p = 512 if wl == 6 else 513
        row = n % 32 + m
        col = (n // 32) % 16
        a = ((row * p + col) * 8) % FOOT
    elif wl in (8, 9):
        st = 1 if wl == 8 else 0
        if m == 0:
            a = (0 * REG + 8 * st * 0 + 8 * n) % FOOT
        elif m == 1:
            a = (1 * REG + 8 * st * 1 + 8 * n) % FOOT
        elif m == 2:
            a = (2 * REG + 8 * st * 2 + 8 * (n // 2)) % FOOT
            we = n & 1
        else:
            sz = sz_max
            a = (3 * REG + 8 * st * 3 + 32 * n) % FOOT
            we = 1
            gap = n % 2
    elif wl == 10:
        if m == 0:
            sz = 2
            a = ((hh >> 8) % 1024) * 4
            we = 1 if (hh & 255) < 90 else 0
            gap = 2 if ((hh >> 20) % 100) < 70 else 0
        elif m == 1:
            a = (1 * REG + 8 + 8 * n) % FOOT
        elif m == 2:
            sz = sz_max
            a = (2 * REG + 16 + 32 * (n - n // 4)) % FOOT
            we = 1 if n % 4 == 3 else 0
        else:
            sz = sz_max
            a = (3 * REG + 24 + 32 * n) % FOOT
            we = 1
            gap = n % 2
    elif wl == 11:
        sz = 4 if sz_max >= 4 else sz_max
        a = (m * REG + 8 * m + 16 * n) % FOOT
    else:
        a = ((hh >> 8) % (FOOT // 8)) * 8
    if a + (1 << sz) > FOOT:
        a = a % (FOOT - (1 << sz))
    return a, sz, we, gap


def makespan_bound(wl, nb, mode, gran, nreq, seed=1, wb=8, depth=None):
    """Lower bound on the cycles to complete NREQ requests per master (4 masters) with one single-port bank accepting one
    word per cycle and a master issuing one request per cycle at most.  Not an estimate of the RTL: a bound it cannot beat."""
    depth = depth or (FOOT // (nb * wb))
    m = AddrMap(nb, depth, mode, gran)
    load = [0] * nb
    master_cyc = [0] * 4
    useful = 0
    words_total = 0
    for mm in range(4):
        for n in range(nreq):
            a, sz, we, gap = gen(wl, mm, n, seed)
            w0, w1 = a // wb, (a + (1 << sz) - 1) // wb
            per = [0] * nb
            for w in range(w0, w1 + 1):
                b = m.bank(w)
                load[b] += 1
                per[b] += 1
                words_total += 1
            master_cyc[mm] += max(1, max(per)) + gap
            useful += 1 << sz
    bound = max(max(load), max(master_cyc))
    return dict(bound_cycles=bound, bank_bound=max(load), master_bound=max(master_cyc), words=words_total, useful_bytes=useful,
                useful_Bpc_ceiling=useful / bound, peak_Bpc=nb * wb, efficiency_ceiling=useful / (words_total * wb))


def offered_Bpc(wl, nreq, seed=1):
    """Offered load: useful bytes per cycle if memory were infinitely wide (each master issues one request per cycle, plus its idle gaps).
    This is the ceiling of a workload whatever the number of banks: the yardstick for 'how much of what could be served WAS served'."""
    useful = 0
    mc = [0] * 4
    for mm in range(4):
        for n in range(nreq):
            a, sz, we, gap = gen(wl, mm, n, seed)
            useful += 1 << sz
            mc[mm] += 1 + gap
    return useful / max(mc)


# ------------------------------------------------------------------------------------------------ report
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="reports/analysis.json")
    ap.add_argument("--md", default="reports/analysis.md")
    a = ap.parse_args()
    R = {}
    md = []
    md.append("# MemoryMatrix analytical study (exact enumeration, no simulation)\n")

    md.append("## A. Tensor operand streams: are lock-step A / B / C streams conflict free?\n")
    md.append("S unit-stride streams advance one 64-bit word per cycle in lock step (the TensorCore reading A[k], B[k], C[k]). "
              "A placement is the tuple of base word offsets; the table gives the fraction of ALL placements (offsets over at least one full bank period, NB*G words) that never "
              "hit one bank twice in one cycle.  100 % means any placement works, below that the tile bases must be chosen (skewed).\n")
    md.append("| banks | interleave | S=2 | S=3 | S=4 |\n|---|---|---|---|---|")
    R["streams"] = []
    for nb in NBS:
        for mode, gran in MODES:
            row = [streams_conflict_free(nb, mode, gran, s) for s in (2, 3, 4)] if nb <= 8 or True else None
            R["streams"].append(dict(nb=nb, mode=mode_name(mode, gran), s2=row[0], s3=row[1], s4=row[2]))
            md.append(f"| {nb} | {mode_name(mode, gran)} | " + " | ".join(f"{100 * v:5.1f} %" for v in row) + " |")
    md.append("\nReading: with LOW interleave and S streams on NB banks only NB*(NB-1)*...*(NB-S+1)/NB^S of placements are conflict free "
              "(e.g. 3 streams on 4 banks: 37.5 %), so the tile layout MUST skew the bases (A, B, C on banks +0, +1, +2): the placement helper "
              "benchmarks/memory_matrix/mm_layout.py does that.  LINEAR (bank per region) is conflict free only if the streams live in different "
              "banks; unit-stride streams inside one bank serialise completely.\n")

    md.append("## B. Column walk of a row-major matrix: effect of the row pitch\n")
    md.append("Four masters walk the SAME column on adjacent rows (row = r + m): the transpose pattern.  'distinct' = mean banks hit per step "
              "(4.00 = conflict free); 'slowdown' = mean cycles per step (1.00 = no serialisation).\n")
    md.append("| banks | interleave | pitch 512 words: distinct / slowdown | pitch 513 words (padded): distinct / slowdown |\n|---|---|---|---|")
    R["columns"] = []
    for nb in NBS:
        for mode, gran in MODES:
            d0, c0 = column_walk_parallelism(nb, mode, gran, 512)
            d1, c1 = column_walk_parallelism(nb, mode, gran, 513)
            R["columns"].append(dict(nb=nb, mode=mode_name(mode, gran), pow2_distinct=d0, pow2_slowdown=c0, pad_distinct=d1, pad_slowdown=c1))
            md.append(f"| {nb} | {mode_name(mode, gran)} | {d0:.2f} / {c0:.2f}x | {d1:.2f} / {c1:.2f}x |")
    md.append("")

    md.append("## C. Vector loads: bank spanning and misalignment (single master, one word per bank per cycle)\n")
    md.append("Bytes [off, off+size) from a word-aligned start; 'cycles' = cycles one master needs to issue all words (words > banks or a "
              "granule that keeps neighbours in one bank serialise); 'useful' = requested bytes / bytes physically read.\n")
    md.append("| size | byte offset | words | NB=4: banks / cycles | NB=8: banks / cycles | NB=16: banks / cycles | useful |\n|---|---|---|---|---|---|---|")
    R["vector"] = []
    for size in (16, 32):
        for off in range(0, 8):
            v = {nb: vector_split(nb, 0, 0, size, off) for nb in NBS}
            R["vector"].append(dict(size=size, off=off, **{f"nb{nb}": v[nb] for nb in NBS}))
            md.append(f"| {size * 8} bit | {off} | {v[4]['words']} | {v[4]['banks']} / {v[4]['cycles']} | {v[8]['banks']} / {v[8]['cycles']} | "
                      f"{v[16]['banks']} / {v[16]['cycles']} | {100 * v[4]['useful']:.0f} % |")
    md.append("\nA 256-bit access that is not 8-byte aligned touches 5 words: on 4 banks words 0 and 4 share a bank (2 cycles, "
              "'self conflict'); on 8 and 16 banks it issues in one cycle.  Useful fraction is 32/40 = 80 % for any misaligned offset: "
              "the extra word is read and discarded.\n")

    md.append("## D. Client bandwidth demand vs. bank supply\n")
    md.append("Supply = NUM_BANKS words (8 B) per cycle at peak.  Demand is the client's own steady-state requirement (from the TensorCore08 "
              "and HPC vector-array documentation).  'min banks' assumes perfectly conflict-free placement; real requirement is higher "
              "(section E measures how much).\n")
    md.append("| client | read B/cycle | write B/cycle | total B/cycle | 64-bit words/cycle | min banks (ideal) |\n|---|---|---|---|---|---|")
    R["clients"] = client_demand()
    for r in R["clients"]:
        md.append(f"| {r['client']} | {r['read_Bpc']} | {r['write_Bpc']} | {r['total_Bpc']} | {r['words64_per_cycle']:.1f} | {r['min_banks_conflict_free']} |")
    md.append("")

    md.append("## E. Lower bounds for the benchmark workloads (4 masters, NREQ requests each, seed 1)\n")
    md.append("Ceiling = bytes / max(busiest bank load, busiest master's issue time).  The RTL cannot beat it; run_bench.py reports the RTL result next to it.\n")
    md.append("| workload | banks | ceiling useful B/cycle | peak B/cycle | useful fraction of physical |\n|---|---|---|---|---|")
    R["bounds"] = []
    nreq = 3000
    for wl in range(12):
        for nb in NBS:
            b = makespan_bound(wl, nb, 0, 0, nreq)
            R["bounds"].append(dict(wl=WL_NAMES[wl], nb=nb, **b))
            md.append(f"| {WL_NAMES[wl]} | {nb} | {b['useful_Bpc_ceiling']:.2f} | {b['peak_Bpc']} | {100 * b['efficiency_ceiling']:.0f} % |")
    open(a.md, "w").write("\n".join(md) + "\n")
    json.dump(R, open(a.out, "w"), indent=1)
    print("\n".join(md))


if __name__ == "__main__":
    sys.exit(main())
