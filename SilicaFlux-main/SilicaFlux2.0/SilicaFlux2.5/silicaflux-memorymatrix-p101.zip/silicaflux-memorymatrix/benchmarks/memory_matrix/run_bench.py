#!/usr/bin/env python3
"""Run the MemoryMatrix benchmarks (RTL simulation) and build the 4 / 8 / 16-bank comparison.   Run from the package root.

  python3 benchmarks/memory_matrix/run_bench.py [--jobs 3] [--nreq 3000] [--seed 1] [--out reports/bench.json]
                                                [--configs name ...] [--build build/bench]

One Verilator build per hardware configuration (tb_mm_bench.sv); every workload then runs with plusargs, so EVERY bank count / interleave
sees byte-identical request streams.  All numbers are read from the DUT's own performance counters (sf_memory_matrix_perf) plus the
makespan measured by the testbench.  These are RTL-simulation results (Verilator, 2-state): not silicon, not timing.

Derived metrics (per workload and configuration)
  useful_Bpc      useful bytes (read: 2^size, write: enabled bytes) per cycle of the makespan
  peak_Bpc        NUM_BANKS * WORD_BYTES: what the banks could move if every bank accepted a word every cycle
  of_peak         useful_Bpc / peak_Bpc                      (how much of the theoretical peak is turned into useful traffic)
  bank_util       accepted word accesses / (NUM_BANKS * makespan)
  phys_eff        useful bytes / (accepted words * WORD_BYTES)   (waste from sub-word, misaligned and bank-spanning accesses)
  conf_frac       bank-cycles with >= 2 requesters / (NUM_BANKS * makespan)
  lat_*           mean request latency per master (accept -> response handshake), cycles
  starve_tensor / starve_vector   % of the makespan the master class had issue work pending and was granted nothing
"""
import argparse, csv, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.getcwd()
sys.path.insert(0, os.path.join(ROOT, "benchmarks", "memory_matrix"))
import mm_analysis as AN   # noqa: E402

TB = "benchmarks/memory_matrix/tb_mm_bench.sv"
WL = AN.WL_NAMES
WB = 8
FOOT = 65536


def cfg(name, nb, **kw):
    d = dict(NUM_BANKS=nb, BANK_DEPTH=FOOT // (nb * WB))
    d.update(kw)
    return name, d


CONFIGS = [
    cfg("low_nb4", 4), cfg("low_nb8", 8), cfg("low_nb16", 16),
    cfg("xor_nb4", 4, INTERLEAVE_MODE=1), cfg("xor_nb8", 8, INTERLEAVE_MODE=1), cfg("xor_nb16", 16, INTERLEAVE_MODE=1),
    cfg("g4_nb4", 4, ILV_GRAN_LOG2=2), cfg("g4_nb8", 8, ILV_GRAN_LOG2=2), cfg("g4_nb16", 16, ILV_GRAN_LOG2=2),
    cfg("ecc_low_nb4", 4, ENABLE_ECC=1), cfg("ecc_low_nb8", 8, ENABLE_ECC=1), cfg("ecc_low_nb16", 16, ENABLE_ECC=1),
    cfg("low_nb4_slot16", 4, NSLOT=16), cfg("low_nb16_slot16", 16, NSLOT=16),
    cfg("low_nb4_L2", 4, READ_LATENCY=2), cfg("low_nb16_L2", 16, READ_LATENCY=2),
    cfg("win2_nb4", 4, ISSUE_WINDOW=2), cfg("win4_nb4", 4, ISSUE_WINDOW=4), cfg("win8_nb4", 4, ISSUE_WINDOW=8),
    cfg("win4_nb8", 8, ISSUE_WINDOW=4), cfg("win4_nb16", 16, ISSUE_WINDOW=4), cfg("win8_nb16", 16, ISSUE_WINDOW=8),
    cfg("ecc_win4_nb4", 4, ENABLE_ECC=1, ISSUE_WINDOW=4),
]

KV = re.compile(r"(\w+)=(\S+)")


def build_and_run(c, a):
    name, over = c
    d = os.path.join(a.build, name)
    os.makedirs(d, exist_ok=True)
    env = dict(os.environ)
    env.setdefault("VOPT", "-O1")
    g = [f"-G{k}={v}" for k, v in over.items()]
    t0 = time.time()
    b = subprocess.run(["bash", "scripts/vbuild.sh", d, "tb_mm_bench", TB] + g, cwd=ROOT, env=env, capture_output=True, text=True)
    exe = os.path.join(d, "sim.bin")
    if b.returncode != 0 or not os.path.exists(exe):
        return name, [], (b.stdout + b.stderr)[-800:]
    rows = []
    for w in range(len(WL)):
        r = subprocess.run([exe, f"+WL={w}", f"+NREQ={a.nreq}", f"+SEED={a.seed}"], cwd=ROOT, env=env, capture_output=True, text=True, timeout=1800)
        line = next((l for l in (r.stdout + r.stderr).splitlines() if l.startswith("BENCH ")), None)
        if line is None or "ERROR" in line:
            rows.append(dict(wl=WL[w], error=(r.stdout + r.stderr)[-300:]))
            continue
        kv = {k: v for k, v in KV.findall(line)}
        rows.append(kv)
    if not os.environ.get("MM_KEEP_BUILD"):
        import shutil
        shutil.rmtree(d, ignore_errors=True)         # each build is ~120 MB of objects: results are already parsed
    return name, rows, f"{time.time() - t0:.0f}s"


def derive(kv, nb, a):
    f = lambda k: float(kv[k])
    mk = f("makespan")
    peak = nb * WB
    useful = f("useful_bytes") / mk
    d = dict(wl=kv["wl"], banks=nb, makespan=int(mk), reqs=int(f("reqs")), useful_Bpc=useful, peak_Bpc=peak, of_peak=useful / peak,
             bank_util=f("bank_accesses") / (nb * mk), rd_util=f("acc_rd") / (nb * mk), wr_util=f("acc_wr") / (nb * mk), phys_eff=f("useful_bytes") / (f("bank_accesses") * WB),
             conf_frac=f("bank_conf_cycles") / (nb * mk), arb_stall_pct=100 * f("arb_stall") / (4 * mk), busy_stall_pct=100 * f("busy_stall") / (4 * mk),
             self_conf_pct=100 * f("self_conf") / (4 * mk), mstall_pct=100 * f("mstall") / (4 * mk),
             starve_ctrl=100 * f("starve_ctrl") / mk, starve_tensor=100 * f("starve_tensor") / mk, starve_vector=100 * f("starve_vector") / mk,
             starve_dma=100 * f("starve_dma") / mk,
             lat=[f(f"lat100_{m}") / 100 for m in range(4)], latmax=[int(f(f"latmax{m}")) for m in range(4)],
             integrity_errors=int(f("integrity_errors")), checks=int(f("checks")))
    return d


def svg_bars(title, groups, series, data, ymax, ylabel, path, fmt="{:.1f}"):
    """grouped bar chart: groups on x, one bar per series; self-contained SVG, light/dark safe (explicit colours)"""
    W, H, ml, mr, mt, mb = 1100, 420, 60, 20, 50, 110
    pw, ph = W - ml - mr, H - mt - mb
    cols = ["#4C78A8", "#F58518", "#54A24B", "#B279A2", "#E45756", "#72B7B2"]
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="Helvetica,Arial,sans-serif" font-size="11">',
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
           f'<text x="{W / 2}" y="22" text-anchor="middle" font-size="15" font-weight="bold" fill="#222">{title}</text>']
    for i in range(6):
        y = mt + ph - ph * i / 5
        out.append(f'<line x1="{ml}" y1="{y}" x2="{W - mr}" y2="{y}" stroke="#dddddd"/>')
        out.append(f'<text x="{ml - 6}" y="{y + 4}" text-anchor="end" fill="#444">{ymax * i / 5:.0f}</text>')
    out.append(f'<text x="14" y="{mt + ph / 2}" transform="rotate(-90 14 {mt + ph / 2})" text-anchor="middle" fill="#444">{ylabel}</text>')
    gw = pw / len(groups)
    bw = gw * 0.8 / len(series)
    for gi, g in enumerate(groups):
        x0 = ml + gi * gw + gw * 0.1
        for si, s in enumerate(series):
            v = data[si][gi]
            h = ph * min(v, ymax) / ymax
            out.append(f'<rect x="{x0 + si * bw:.1f}" y="{mt + ph - h:.1f}" width="{bw - 1:.1f}" height="{h:.1f}" fill="{cols[si % 6]}"/>')
            if len(series) <= 3:
                out.append(f'<text x="{x0 + si * bw + bw / 2:.1f}" y="{mt + ph - h - 3:.1f}" text-anchor="middle" font-size="9" fill="#333">{fmt.format(v)}</text>')
        out.append(f'<text x="{ml + gi * gw + gw / 2:.1f}" y="{mt + ph + 14}" text-anchor="end" transform="rotate(-35 {ml + gi * gw + gw / 2:.1f} {mt + ph + 14})" fill="#333">{g}</text>')
    for si, s in enumerate(series):
        out.append(f'<rect x="{ml + si * 130}" y="{H - 24}" width="12" height="12" fill="{cols[si % 6]}"/><text x="{ml + si * 130 + 17}" y="{H - 14}" fill="#333">{s}</text>')
    out.append("</svg>")
    open(path, "w").write("\n".join(out))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--nreq", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--configs", nargs="*")
    ap.add_argument("--out", default="reports/bench.json")
    ap.add_argument("--build", default="build/bench")
    a = ap.parse_args()
    cfgs = [c for c in CONFIGS if not a.configs or c[0] in a.configs]
    os.makedirs(a.build, exist_ok=True)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        results = list(ex.map(lambda c: build_and_run(c, a), cfgs))
    R = {}
    bad = []
    for (name, over), (n2, rows, info) in zip(cfgs, results):
        nb = over["NUM_BANKS"]
        if not rows:
            bad.append((name, info))
            continue
        R[name] = dict(over=over, rows=[])
        for kv in rows:
            if "error" in kv:
                bad.append((name + "/" + kv["wl"], kv["error"]))
                continue
            R[name]["rows"].append(derive(kv, nb, a))
        print(f"{name:18s} {len(R[name]['rows'])} workloads   {info}", flush=True)
    # analytic static ceilings for the LOW configurations
    ceil = {}
    for wl in range(len(WL)):
        for nb in (4, 8, 16):
            ceil[(WL[wl], nb)] = AN.makespan_bound(wl, nb, 0, 0, a.nreq, a.seed)["useful_Bpc_ceiling"]
    json.dump(dict(nreq=a.nreq, seed=a.seed, configs=R, failures=bad, ceilings={f"{k[0]}|{k[1]}": v for k, v in ceil.items()}), open(a.out, "w"), indent=1)
    with open(a.out.replace(".json", ".csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["config", "workload", "banks", "makespan", "reqs", "useful_Bpc", "peak_Bpc", "of_peak", "bank_util", "rd_util", "wr_util", "phys_eff", "conf_frac", "arb_stall_pct",
                    "busy_stall_pct", "self_conf_pct", "mstall_pct", "starve_ctrl_pct", "starve_tensor_pct", "starve_vector_pct", "starve_dma_pct",
                    "lat_ctrl", "lat_tensor", "lat_vector", "lat_dma", "latmax_ctrl", "latmax_tensor", "latmax_vector", "latmax_dma", "integrity_errors"])
        for name, v in R.items():
            for r in v["rows"]:
                w.writerow([name, r["wl"], r["banks"], r["makespan"], r["reqs"], f"{r['useful_Bpc']:.3f}", r["peak_Bpc"], f"{r['of_peak']:.4f}", f"{r['bank_util']:.4f}", f"{r['rd_util']:.4f}", f"{r['wr_util']:.4f}",
                            f"{r['phys_eff']:.4f}", f"{r['conf_frac']:.4f}", f"{r['arb_stall_pct']:.2f}", f"{r['busy_stall_pct']:.2f}", f"{r['self_conf_pct']:.2f}",
                            f"{r['mstall_pct']:.2f}", f"{r['starve_ctrl']:.2f}", f"{r['starve_tensor']:.2f}", f"{r['starve_vector']:.2f}", f"{r['starve_dma']:.2f}",
                            *[f"{x:.2f}" for x in r["lat"]], *r["latmax"], r["integrity_errors"]])
    # charts
    if all(f"low_nb{n}" in R for n in (4, 8, 16)):
        groups = [r["wl"] for r in R["low_nb4"]["rows"]]
        ser = [f"{n} banks" for n in (4, 8, 16)]
        data = [[r["useful_Bpc"] for r in R[f"low_nb{n}"]["rows"]] for n in (4, 8, 16)]
        svg_bars("Useful bandwidth, identical workloads (LOW interleave, 64-bit words)", groups, ser, data, 140, "useful bytes / cycle", "reports/bench_useful_Bpc.svg")
        data = [[100 * r["of_peak"] for r in R[f"low_nb{n}"]["rows"]] for n in (4, 8, 16)]
        svg_bars("Useful bandwidth as % of the theoretical peak (NUM_BANKS x 8 B / cycle)", groups, ser, data, 100, "% of peak", "reports/bench_of_peak.svg", "{:.0f}")
        data = [[100 * r["bank_util"] for r in R[f"low_nb{n}"]["rows"]] for n in (4, 8, 16)]
        svg_bars("Bank utilisation (accepted word accesses / bank-cycles)", groups, ser, data, 100, "% of bank-cycles", "reports/bench_bank_util.svg", "{:.0f}")
    print(f"\n{sum(len(v['rows']) for v in R.values())} runs, {len(bad)} failures, {time.time() - t0:.0f} s")
    for b in bad:
        print("FAILED:", b)
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
