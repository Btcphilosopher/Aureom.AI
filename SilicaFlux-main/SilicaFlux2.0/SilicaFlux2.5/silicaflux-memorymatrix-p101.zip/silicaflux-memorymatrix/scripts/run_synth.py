#!/usr/bin/env python3
"""Yosys synthesis runs for sf_memory_matrix.   Run from the package root.

  python3 scripts/run_synth.py [--only NAME ...] [--out reports/synth.json] [--yosys yosys] [--timeout 1500]

Flows (every number below is read from the Yosys log of THIS run; nothing is estimated here):
  generic_<cfg>   synth -flatten + abc to the generic gate library {AND NAND OR NOR XOR XNOR ANDNOT ORNOT MUX}: cell counts, flip-flops,
                  and the longest topological path in generic gates (`ltp`): a logic DEPTH, not a time.
  ecp5_<cfg>      synth_ecp5 : LUT4 / flip-flop / DP16KD block RAM / distributed RAM counts.  Shows whether the SRAM bank arrays are
                  INFERRED AS RAM (FPGA RAM inference preserved) instead of flip-flops.
  bank_ram_<cfg>  the sf_sram_bank alone (the array + ECC wrapper) for ecp5 and xilinx: the RAM primitives it maps to.
Not done here: place and route, timing closure, power, any ASIC liberty mapping (no liberty / PDK in the repository): see
docs/memory_matrix/SYNTHESIS.md for what is ACTUAL and what is only an assumption-based ESTIMATE.
"""
import argparse, json, os, re, subprocess, sys, time

ROOT = os.getcwd()
TP = "rtl/memory/third_party/memorycore/rtl"
RAS = "rtl/memory/third_party/ras_secded"
FILES = [f"{TP}/sf_sram_core.sv", f"{TP}/backends/sf_sram_fpga_bram.sv", f"{TP}/backends/sf_sram_asic_sky130.sv", f"{TP}/sf_sram_macro_wrapper.sv",
         f"{TP}/sf_ecc_enc.sv", f"{TP}/sf_ecc_dec.sv", f"{TP}/sf_ecc_counters.sv", f"{TP}/sf_sram_bank.sv",
         f"{RAS}/sfras_secded_enc.sv", f"{RAS}/sfras_secded_dec.sv",
         "rtl/memory/sf_memory_matrix_decoder.sv", "rtl/memory/sf_memory_matrix_arbiter.sv", "rtl/memory/sf_memory_matrix_perf.sv",
         "rtl/memory/sf_memory_matrix.sv"]
HEAD = ["rtl/memory/sf_mm_defs.svh", "rtl/memory/sf_mm_map.svh", f"{TP}/sf_sram_defs.svh", f"{RAS}/sfras_ecc_funcs.svh", f"{RAS}/sfras_defs.svh"]

GEN = "-g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX"


def cfg(name, **p):
    return name, p


CONFIGS = [
    cfg("nb4_nm4", NUM_BANKS=4, BANK_DEPTH=1024),
    cfg("nb8_nm4", NUM_BANKS=8, BANK_DEPTH=512),
    cfg("nb16_nm4", NUM_BANKS=16, BANK_DEPTH=256),
    cfg("nb4_nm4_ecc", NUM_BANKS=4, BANK_DEPTH=1024, ENABLE_ECC=1),
    cfg("nb4_nm4_win4", NUM_BANKS=4, BANK_DEPTH=1024, ISSUE_WINDOW=4),
    cfg("nb16_nm4_win4", NUM_BANKS=16, BANK_DEPTH=256, ISSUE_WINDOW=4),
]
ECP5_ONLY = {"nb4_nm4", "nb16_nm4", "nb4_nm4_ecc"}      # the full ECP5 mapping is run for these (RAM inference of the whole matrix)


BANK_WRAP = '''module syn_bank_top (
  input  wire clk, rst_n, req_valid, req_we, input wire [{AWm}:0] req_row, input wire [{DWm}:0] req_wdata, input wire [{BEm}:0] req_be, input wire [3:0] req_tag,
  output wire req_ready, rsp_valid, output wire [{DWm}:0] rsp_rdata, output wire [3:0] rsp_tag, output wire rsp_we, output wire [2:0] rsp_status, output wire rsp_ce,
  input wire init_start_i, scrub_en_i, output wire init_busy_o, idle_o
);
  wire [{SWm}:0] trd; wire [15:0] cc, uc; wire [{AWm}:0] fc, fu; wire ec, eu; wire [{AWm}:0] er; wire [1:0] ek;
  sf_sram_bank #(.DEPTH({DEPTH}), .DW({DW}), .READ_LATENCY(1), .ECC_EN({ECC}), .TAG_W(4), .INIT_ON_RESET({ECC}), .SCRUB_EN(0)) u (
    .clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready), .req_we(req_we), .req_row(req_row), .req_wdata(req_wdata), .req_be(req_be), .req_tag(req_tag),
    .rsp_valid(rsp_valid), .rsp_rdata(rsp_rdata), .rsp_tag(rsp_tag), .rsp_we(rsp_we), .rsp_status(rsp_status), .rsp_ce(rsp_ce),
    .init_start_i(init_start_i), .init_busy_o(init_busy_o), .scrub_en_i(scrub_en_i), .idle_o(idle_o),
    .ev_ce_o(ec), .ev_ue_o(eu), .ev_row_o(er), .ev_kind_o(ek), .cnt_clr_i(1'b0), .ce_cnt_o(cc), .ue_cnt_o(uc), .first_ce_row_o(fc), .first_ue_row_o(fu),
    .tst_active_i(1'b0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({AW}'d0), .tst_wdata_i({SW}'d0), .tst_rdata_o(trd),
    .fi_type(4'd0), .fi_row({AW}'d0), .fi_row2({AW}'d0), .fi_bit({FW}'d0), .fi_bit2({FW}'d0), .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({AW}'d0), .seu_mask({SW}'d0));
endmodule
'''


def patch_defaults(text, params):
    """set the DEFAULT of top-level parameters in a private copy of the source (Yosys 0.71 asserts in `hierarchy` when -chparam is used on this code base)"""
    for k, v in params.items():
        text, n = re.subn(rf"(parameter int {k}\s*=\s*)([^,\n/]+)", rf"\g<1>{v}", text, count=1)
        if n != 1:
            raise SystemExit(f"cannot patch parameter {k}")
    return text


def script(top, params, flow, rd_files):
    reads = "".join(f"read_verilog -sv -I. {os.path.basename(f)}\n" for f in rd_files)
    chp = ""                                   # parameters are patched into the sources, see patch_defaults()
    if flow == "generic":
        # stop before memory mapping (as the existing package's synthesis flow does): the SRAM arrays stay RAM cells ($mem_v2) instead of
        # becoming 262k flip-flops with 1024:1 read muxes, so the counts are the LOGIC of the matrix + banks, with the RAMs listed separately
        body = (f"hierarchy -check -top {top}\nsynth -flatten -top {top} -run :fine\nopt -fast -full\ntechmap\nopt -fast\nabc {GEN}\nopt_clean\n"
                f"tee -o ltp.txt ltp -noff\nstat\n")
    elif flow == "ecp5":
        body = f"hierarchy -check -top {top}\nsynth_ecp5 -top {top}\nstat\n"      # no ltp: it overflows the WASM stack on the deep carry-chain netlists
    elif flow == "xilinx":
        body = f"hierarchy -check -top {top}\nsynth_xilinx -top {top}\nstat\n"
    else:
        raise ValueError(flow)
    return reads + body


def parse_stat(out):
    """last 'Number of cells' block of the log"""
    blk = out.rsplit("Printing statistics.", 1)[-1]
    cells = {}
    total = None
    for m in re.finditer(r"^\s+(\d+)\s+(?:[\d.]+\s+)?([$\w\\]+)\s*$", blk, re.M):
        cells[m.group(2)] = cells.get(m.group(2), 0) + int(m.group(1))
    m = re.search(r"^\s*(\d+)\s+(?:[\d.]+\s+)?cells\s*$", blk, re.M)
    if m:
        total = int(m.group(1))
    return total, cells


def run(name, top, params, flow, files, yosys, timeout):
    d = os.path.join(ROOT, "build", "synth", name)
    os.makedirs(d, exist_ok=True)
    for f in files + HEAD:
        dst = os.path.join(d, os.path.basename(f))
        txt = open(os.path.join(ROOT, f)).read()
        if os.path.basename(f) == "sf_memory_matrix.sv":
            txt = patch_defaults(txt, params)
        open(dst, "w").write(txt)
    if top == "syn_bank_top":
        dw, depth, ecc = params["DW"], params["DEPTH"], params["ECC_EN"]
        import math
        R = math.ceil(math.log2(dw + math.ceil(math.log2(dw + 1)) + 1))
        sw = dw + R + 1 if ecc else dw
        txt = BANK_WRAP.format(AWm=int(math.log2(depth)) - 1, DWm=dw - 1, BEm=dw // 8 - 1, SWm=sw - 1, SW=sw, AW=int(math.log2(depth)), FW=max(1, math.ceil(math.log2(sw))),
                               DEPTH=depth, DW=dw, ECC=ecc)
        open(os.path.join(d, "syn_bank_top.sv"), "w").write(txt)
        files = files + ["syn_bank_top.sv"]
    ys = os.path.join(d, "run.ys")
    open(ys, "w").write(script(top, params, flow, files))
    t0 = time.time()
    try:
        r = subprocess.run([yosys, "-q", "-l", "yosys.log", "-s", "run.ys"], cwd=d, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return dict(name=name, status="TIMEOUT", secs=round(time.time() - t0))
    log = open(os.path.join(d, "yosys.log")).read() if os.path.exists(os.path.join(d, "yosys.log")) else r.stdout
    res = dict(name=name, top=top, flow=flow, params=params, secs=round(time.time() - t0), status="OK" if r.returncode == 0 else "ERROR")
    if r.returncode != 0:
        res["detail"] = (r.stdout + r.stderr)[-800:]
        return res
    total, cells = parse_stat(log)
    res["cells_total"] = total
    res["cells"] = cells
    res["latches"] = sum(v for k, v in cells.items() if "LATCH" in k.upper() or "DLATCH" in k.upper())
    ff = sum(v for k, v in cells.items() if re.search(r"DFF|TRELLIS_FF|FDRE|FDCE|FDPE|FDSE|SDFF", k))
    res["flip_flops"] = ff
    res["luts"] = sum(v for k, v in cells.items() if re.search(r"LUT", k))
    res["ram_primitives"] = {k: v for k, v in cells.items() if re.search(r"DP16KD|TRELLIS_DPR16X4|RAMB|RAM64|RAM32|RAM128|RAM256|\$mem|\$__ECP5", k)}
    p = os.path.join(d, "ltp.txt")
    if os.path.exists(p):
        m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", open(p).read())
        if m:
            res["ltp_levels"] = int(m.group(1))
    warn = re.findall(r"Warning: (.*)", log)
    res["warnings"] = len(warn)
    res["latch_warnings"] = len([w for w in warn if "latch" in w.lower()])
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out", default="reports/synth.json")
    ap.add_argument("--yosys", default="yosys")
    ap.add_argument("--timeout", type=int, default=1500)
    ap.add_argument("--flows", nargs="*", default=["generic", "ecp5"])
    a = ap.parse_args()
    jobs = []
    for name, p in CONFIGS:
        for fl in a.flows:
            if fl == "ecp5" and name not in ECP5_ONLY:
                continue
            jobs.append((f"{fl}_{name}", "sf_memory_matrix", p, fl, FILES))
    for name, p in [("nb4_w64", dict(DEPTH=1024, DW=64, ECC_EN=0)), ("nb4_w64_ecc", dict(DEPTH=1024, DW=64, ECC_EN=1, INIT_ON_RESET=1))]:
        for fl in ("ecp5", "xilinx"):
            jobs.append((f"bank_ram_{fl}_{name}", "syn_bank_top", p, fl, [f for f in FILES if "matrix" not in f]))
    res = []
    for n, top, p, fl, fs in jobs:
        if a.only and n not in a.only:
            continue
        r = run(n, top, p, fl, fs, a.yosys, a.timeout)
        res.append(r)
        print(f'{r["status"]:7s} {n:34s} {r.get("secs", 0):>5}s cells={r.get("cells_total")} ff={r.get("flip_flops")} lut={r.get("luts")} ram={r.get("ram_primitives")} ltp={r.get("ltp_levels")} latch={r.get("latches")}', flush=True)
        os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
        json.dump(res, open(a.out, "w"), indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
