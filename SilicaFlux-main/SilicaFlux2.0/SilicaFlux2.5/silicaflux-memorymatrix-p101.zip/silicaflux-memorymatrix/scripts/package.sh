#!/bin/bash
# package.sh [outfile.zip]   (run from the package root)  -> a ZIP of this package (no build products, no VCS metadata).  Never touches git.
set -e
OUT=${1:-../silicaflux-memorymatrix-p101.zip}
ROOT=$(basename "$PWD")
rm -f "$OUT"
( cd .. && zip -r -q -X "$OUT" "$ROOT" -x "$ROOT/build/*" "*/__pycache__/*" "*.pyc" "*/.git/*" "$ROOT/.pytest_cache/*" )
sha256sum "$OUT"
echo "wrote $OUT"
