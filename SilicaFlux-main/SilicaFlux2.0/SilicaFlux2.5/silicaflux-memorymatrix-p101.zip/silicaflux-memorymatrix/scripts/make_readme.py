#!/usr/bin/env python3
"""Compose README.md from the result files in reports/.   Run from the package root (after the campaigns)."""
import json, os

def load(p):
    return json.load(open(p)) if os.path.exists(p) else None

R = load("reports/regress.json")
M = load("reports/mutation.json")
F = load("reports/formal.json")
B = load("reports/bench.json")
S = load("reports/synth.json")

reg = f"**{R['passed']} / {R['total']}** cases, {R['checks']:,} self-checks" if R else "not run"
mut = f"**{M['killed']} / {M['total']}** mutants killed" if M else "not run"
if F:
    fp = [f for f in F if f["status"] == "PASS"]
    ft = [f for f in F if f["status"] == "TIMEOUT"]
    fo = [f for f in F if f["status"] not in ("PASS", "TIMEOUT")]
    frm = f"**{len(fp)} / {len(F)}** jobs PASS" + (f", {len(ft)} time-limited (depth reached stated in VERIFICATION.md)" if ft else "") + (f", {len(fo)} NOT passing: {', '.join(f['name'] for f in fo)}" if fo else "")
else:
    frm = "not run"
nruns = sum(len(v["rows"]) for v in B["configs"].values()) if B else 0
nchk = sum(r["checks"] for v in B["configs"].values() for r in v["rows"]) if B else 0
sy = [r for r in (S or []) if r.get("status") == "OK"]
syn = f"{len(sy)} Yosys runs OK" + (f", {len(S) - len(sy)} not OK" if S and len(S) != len(sy) else "") if S else "not run"

md = f"""# SilicaFlux Project 101: MemoryMatrix, advanced banked SRAM architecture

Aureom.AI / SilicaFlux Semiconductor Systems. Primary RTL: `rtl/memory/sf_memory_matrix.sv`.

> **Read first.** This package contains **no silicon data**. Every number is an RTL-simulation result (Verilator), a formal result (SymbiYosys / z3), a Yosys structure count, an exact
> enumeration, or an explicitly labelled assumption. It is **not ASIC-ready** (no Liberty / LEF / GDS / PDK for the SRAM macros exists in the repository, and the ASIC backend runs only
> against a labelled stand-in model); no physical timing or power was measured. Nothing in this package was committed to git: it is delivered as a ZIP.

## What it is

`sf_memory_matrix` is a multi-bank, single-port SRAM subsystem for the ControlCore, TensorCore, FP32 vector engine and CloudDMA / DataFabric:

* `NUM_BANKS` independent banks (4, 8, 16 evaluated), 64-bit words, any byte address, per-bank **round-robin arbitration**, bounded per-master queues with exact back-pressure,
  one response per request in order, transaction ids preserved;
* **configurable interleaving** (word / granule, XOR hash, linear) with an alias-free map (proved formally for 11 configurations, simulated exhaustively for 9); boundary, alignment, size and **permission** checks;
* 128- / 256-bit loads, partial vector writes, misaligned and **bank-spanning** accesses split into legal word operations;
* optional **SECDED ECC** with atomic read-modify-write, double-error reporting, scrubbing interface (the existing verified logic, reused);
* **performance counters**: bytes per cycle, bank conflicts, latency, arbitration stalls, tensor / vector starvation, read / write utilisation;
* an optional **issue window** that recovers bandwidth lost to head-of-line blocking.

It **reuses the existing SilicaFlux modules unmodified**: `sf_sram_bank` (array, ECC, init, scrub), `sf_sram_core`, `sf_sram_macro_wrapper` (behavioural / FPGA / ASIC backends), the SECDED codec;
and the existing `sf_vector_scratchpad` / `sf_tensor_scratchpad` run on top of it with their **original testbenches**.

## Results at a glance (all regenerated from `reports/`)

| area | result | source |
|---|---|---|
| RTL regression (Verilator 5.49) | {reg}: system testbench over 40+ configurations (4 / 8 / 16 banks, ECC, latencies, widths, interleave modes, windows, regions, backends), exhaustive address-map testbench, existing adapters on the matrix | `reports/regress.json`, `docs/memory_matrix/VERIFICATION.md` |
| independent reference model | byte-addressable model, expected bank / row / bytes derived from the byte address alone, exact queue-depth check every cycle, exact performance-counter mirror, per-master program-order checker | `tests/memory_matrix/tb_memory_matrix.sv` |
| mutation testing | {mut} (deliberate faults in the decoder, shifters, byte enables, arbitration, queue depth, ECC status, permissions, counters, flush, issue window, address map); the first campaign found testbench holes that were fixed | `reports/mutation.json` |
| formal | {frm} | `reports/formal.json` |
| lint | Verilator `-Wall` clean on 23 parameter sets | `reports/lint_verilator.log` |
| benchmarks | {nruns} RTL runs, identical request streams for 4 / 8 / 16 banks, {nchk:,} data-integrity checks, 0 errors | `reports/bench.csv`, `docs/memory_matrix/BENCHMARKS.md` |
| synthesis | {syn} (generic gates and ECP5; block-RAM inference of the banks preserved; **no timing, no area in a real library**) | `reports/synth.json`, `docs/memory_matrix/SYNTHESIS.md` |

Headline benchmark findings (details and caveats in `BENCHMARKS.md`):

* Useful bandwidth is reported against the **offered load**, not the raw peak. Streams reach 100 % of what they offer at any bank count; aligned 256-bit streams scale 32 -> 64 -> 127.7 B/cycle from 4 to 16 banks.
* Random 8-byte traffic is head-of-line limited: 65 % / 81 % / 90 % of the offered load at 4 / 8 / 16 banks; `ISSUE_WINDOW = 4` raises that to about 99 % at 8 and 16 banks.
* **Placement beats bank count**: a pitch-512 column walk stays at 8.2 B/cycle on 4, 8 and 16 banks (one bank for all masters), padding to 513 gives 32.0; a one-word skew can cost 37 % at 16 banks for 256-bit streams.
* XOR interleave repairs power-of-two strides but hurts unit-stride streams (and padding); LOW with a one-word granule is the default to keep.
* ECC costs nothing measurable except where partial words are written (-7 % on the mixed workload at 4 banks).

## Quick start

```bash
# tools: Verilator 5.x, Python 3, Yosys, SymbiYosys + z3.   Pip-packaged Verilator wheels need:
export VEXTRA="-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include"
make regress      # 64 simulation cases (~12 min on 3 jobs)            -> reports/regress.json
make mutate       # 32 mutants                                         -> reports/mutation.json
make bench        # 4 / 8 / 16 banks, 12 workloads, 23 configurations  -> reports/bench.csv, bench_*.svg, docs/memory_matrix/BENCH_TABLES.md
make analysis     # exact enumeration + tile planner                   -> reports/analysis.md, layout.md
make formal       # SymbiYosys jobs                                    -> reports/formal.json
make synth        # Yosys                                              -> reports/synth.json
make lint
```

Build products go to `build/` (safe to delete; the runners delete each case's objects after parsing the result).

## Layout

| path | content |
|---|---|
| `rtl/memory/` | `sf_memory_matrix.sv`, `_arbiter.sv`, `_decoder.sv` (+ inverse map), `_perf.sv`, `sf_mm_defs.svh`, `sf_mm_map.svh`, `files.f` |
| `rtl/memory/third_party/` | the reused SilicaFlux modules, **byte-identical** (`SHA256SUMS`, `PROVENANCE.md`) |
| `tests/memory_matrix/` | `tb_memory_matrix.sv` (system TB + reference model), `tb_mm_decoder.sv` (exhaustive map), generated integration TBs, `run_regress.py`, `run_mutants.py` |
| `formal/memory_matrix/` | `fv_mm_map.sv`, `fv_mm_arbiter.sv`, `fv_mm_top.sv`, `run_formal.py` |
| `benchmarks/memory_matrix/` | `tb_mm_bench.sv`, `run_bench.py`, `mm_analysis.py`, `mm_layout.py`, report generator |
| `docs/memory_matrix/` | ARCHITECTURE, ADDRESS_MAP, ECC, AUDIT, VERIFICATION, BENCHMARKS (+ BENCH_TABLES), TENSOR_VECTOR, SYNTHESIS, KNOWN_LIMITATIONS |
| `reports/` | JSON / CSV / SVG / log of every run quoted in the documents |
| `scripts/` | `vbuild.sh` (Verilator build), `run_synth.py`, `package.sh` |

## Brief -> where it is met

| brief item | where |
|---|---|
| 1 repository inspection | `docs/memory_matrix/AUDIT.md` |
| 2 core architecture (banks, interleave, routing, per-bank arbitration, read / write response, ECC, counters) | `ARCHITECTURE.md`, `rtl/memory/` |
| 3 configurations 4 / 8 / 16 banks and the parameter list | `ARCHITECTURE.md` section 2; regression + benchmarks over 4, 8, 16 |
| 4 address organisation, no aliasing | `ADDRESS_MAP.md`; formal `fv_mm_map`; exhaustive `tb_mm_decoder` |
| 5 parallelism / single-port rule | `ARCHITECTURE.md` section 4; tests T04, T05 |
| 6 arbitration, ids, bounded queues | `sf_memory_matrix_arbiter.sv`; formal `fv_mm_arbiter` (unbounded fairness bound) |
| 7 tensor placement and lane analysis | `TENSOR_VECTOR.md`, `mm_layout.py`, benchmarks |
| 8 vector 128 / 256-bit, partial, misaligned, bank spanning | `ADDRESS_MAP.md` section 4; tests T02, T07; benchmarks `vec*` |
| 9 ECC | `ECC.md`; test T08 |
| 10 instrumentation | `sf_memory_matrix_perf.sv`; `BENCHMARKS.md` |
| 11 verification | `VERIFICATION.md` |
| 12 synthesis and physical integration | `SYNTHESIS.md` |
| 13 deliverable paths | the layout above |

## Definition of done: status

> *The subsystem correctly handles concurrent transactions across physical SRAM banks, with independently verified data integrity and measured bank conflicts.*

* **Concurrent transactions across banks**: done in RTL-SIMULATION (T04: one request per cycle per master on independent banks; T05 / T05b: serialisation and fairness on one bank).
* **Independently verified data integrity**: done against a byte-addressable model whose expectations do not come from the DUT's decoder, in 40+ configurations, plus the original adapter testbenches; mutation-tested.
* **Measured bank conflicts**: done (counters mirrored exactly; per-workload conflict, arbitration-stall and starvation figures in `BENCHMARKS.md`).
* **Not done**: ASIC readiness, physical timing, power, any silicon data, unbounded formal proofs of the matrix top (only tiny-configuration bounded checks), a comparison against the old controller on identical traffic,
  attachment of the MBIST sequencer and the SFB3 data-fabric adapter. See `docs/memory_matrix/KNOWN_LIMITATIONS.md`.
"""
open("README.md", "w").write(md)
print("wrote README.md")
