#!/bin/bash
# vbuild.sh <outdir> <top> <extra verilator args...>   (run from the package root)
# Builds a self-contained Verilator --binary simulation.  Environment:
#   VERILATOR   verilator executable (default: verilator)
#   VEXTRA      extra flags, e.g. the two below for pip-packaged Verilator wheels whose PCH config is empty:
#                 VEXTRA="-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include"
#   VCXXSTD     C++ standard for --timing (coroutines need C++20), default c++20
#   VOPT        C++ optimisation flag for the generated model, default -O1 (use -O0 for the fastest build)
set -e
OUT=$1; TOP=$2; shift 2
V=${VERILATOR:-verilator}
mkdir -p "$OUT"
exec $V --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-DECLFILENAME --assert -DSF_ASSERT \
     -f rtl/memory/files.f --top-module "$TOP" -Mdir "$OUT" -o sim.bin \
     -CFLAGS ${VOPT:--O1} -CFLAGS -std=${VCXXSTD:-c++20} $VEXTRA "$@" 2>&1
