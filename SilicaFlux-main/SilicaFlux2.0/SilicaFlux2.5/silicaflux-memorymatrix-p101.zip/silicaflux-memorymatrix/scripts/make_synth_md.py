#!/usr/bin/env python3
"""Generate docs/memory_matrix/SYNTHESIS.md from reports/synth.json.   Run from the package root."""
import json, os

S = json.load(open("reports/synth.json"))
ok = [r for r in S if r.get("status") == "OK"]
bad = [r for r in S if r.get("status") != "OK"]
by = {r["name"]: r for r in S}

ASSUMED_PS_PER_LEVEL = 30     # assumption for the ESTIMATE section only: NOT a measurement


def g(name, key, default="-"):
    r = by.get(name)
    return default if not r or r.get("status") != "OK" or r.get(key) is None else r[key]


def fmt(v):
    return f"{v:,}" if isinstance(v, int) else str(v)


md = []
md.append("# SYNTHESIS and physical integration\n")
md.append("""**Two kinds of numbers are kept apart here.**

* **ACTUAL** (section 1): read from the Yosys log of this package's run (`reports/synth.json`, raw logs reproducible with `scripts/run_synth.py`). Yosys 0.71 (YoWASP build).
  Technology-independent or FPGA-mapped *structure counts*: cells, flip-flops, LUT4, block RAM primitives, longest topological path in generic gates.
* **ESTIMATE / ASSUMED** (section 3): a number that rests on an assumption stated next to it. Nothing in section 3 was measured; there is no place-and-route, no static timing
  analysis, no Liberty library, no SRAM macro timing in this repository.

""")
md.append("## 1. ACTUAL: Yosys synthesis results\n")
md.append("### 1.1 sf_memory_matrix (4 masters, 64-bit words, 256-bit master bus, `NSLOT = 8`, `ISSUE_WINDOW = 1` unless stated)\n")
md.append("Flows: `generic` = `synth -flatten -run :fine`, `techmap`, `abc` to {AND, NAND, OR, NOR, XOR, XNOR, ANDNOT, ORNOT, MUX} (memories are **not** mapped: they stay `$mem_v2` RAM cells); `ecp5` = `synth_ecp5`. `ltp` = longest topological path in generic gates "
          "(a logic DEPTH, not a time; reported for the generic flow only: in the ECP5 netlist Yosys counts every carry-chain cell as a level, which is not comparable). The SRAM arrays are included: in the generic flow they are **left as RAM cells (`$mem_v2`) and not counted in the logic** (the flow stops before memory mapping, as the existing package's synthesis flow does; mapping them to flip-flops would give about 262k flip-flops and 1024:1 read muxes and says nothing about the architecture); in the ECP5 flow they are mapped to block RAM.\n")
md.append("| configuration | flow | cells | flip-flops | LUT4 | RAM primitives | ltp (levels) | latches | seconds |\n|---|---|---|---|---|---|---|---|---|")
for name in sorted(by, key=lambda n: (n.split("_", 1)[1], n.split("_", 1)[0])):
    r = by[name]
    if name.startswith("bank_ram"):
        continue
    if r.get("status") != "OK":
        md.append(f"| {name.split('_', 1)[1]} | {name.split('_', 1)[0]} | **{r.get('status')}** (see 1.3) | | | | | | {r.get('secs', '')} |")
        continue
    ram = ", ".join(f"{v} x {k}" for k, v in (r.get("ram_primitives") or {}).items()) or "none"
    ltp = r.get('ltp_levels', '-') if r['flow'] == 'generic' else 'n/a'
    md.append(f"| {name.split('_', 1)[1]} | {r['flow']} | {fmt(r['cells_total'])} | {fmt(r['flip_flops'])} | {fmt(r['luts'])} | {ram} | {ltp} | {r.get('latches', 0)} | {r['secs']} |")
md.append("")
md.append("### 1.2 The SRAM bank alone: is FPGA RAM inference preserved?\n")
md.append("`sf_sram_bank` (1024 rows, 64-bit word, behavioural backend) through `synth_ecp5` and `synth_xilinx`:\n")
md.append("| bank | flow | cells | flip-flops | LUT | RAM primitives |\n|---|---|---|---|---|---|")
for name in sorted(by):
    r = by[name]
    if not name.startswith("bank_ram"):
        continue
    if r.get("status") != "OK":
        md.append(f"| {name} | | {r.get('status')} | | | |")
        continue
    ram = ", ".join(f"{v} x {k}" for k, v in (r.get("ram_primitives") or {}).items()) or "none"
    md.append(f"| {name.replace('bank_ram_', '')} | {r['flow']} | {fmt(r['cells_total'])} | {fmt(r['flip_flops'])} | {fmt(r['luts'])} | {ram} |")
md.append("""
Reading: the bank array is **inferred as block RAM** (the array in `sf_sram_core` is a plain `mem[addr]` with one registered read and per-lane write enables, no reset): nothing in the
matrix defeats the inference, because the matrix touches the banks only through their request / response ports. The ECC bank keeps the array in block RAM and puts the codec and the
read-modify-write FSM in logic.

### 1.3 Findings
""")
md.append(f"* All configurations in the table synthesized without latches (`latches` column) and without errors" + (f" except: {', '.join(r['name'] + ' (' + str(r.get('status')) + ')' for r in bad)}" if bad else "") + ".")
def cell(name, key):
    r = by.get(name)
    return None if not r or r.get("status") != "OK" else (r.get("cells") or {}).get(key, 0)


plain, ecc = "generic_nb4_nm4", "generic_nb4_nm4_ecc"
xo = lambda n: (cell(n, "$_XOR_") or 0) + (cell(n, "$_XNOR_") or 0)
if cell(plain, "$_XOR_") is not None and cell(ecc, "$_XOR_") is not None:
    md.append(f"* **Total cell counts are only reliable to a few percent between configurations.** The plain and ECC 4-bank matrices differ by {by[ecc]['cells_total'] - by[plain]['cells_total']:+,} cells in total, "
              f"although four ECC banks must add several thousand gates (the bank alone grows by {by['bank_ram_generic_nb4_w64_ecc']['cells_total'] - by['bank_ram_generic_nb4_w64']['cells_total']:+,} cells, see 1.2): "
              f"ABC restructured the large select trees differently in the two runs (AND+NAND {(cell(ecc, '$_AND_') + cell(ecc, '$_NAND_')) - (cell(plain, '$_AND_') + cell(plain, '$_NAND_')):+,}, MUX+OR "
              f"{(cell(ecc, '$_MUX_') + cell(ecc, '$_OR_')) - (cell(plain, '$_MUX_') + cell(plain, '$_OR_')):+,} at identical function). What does move reliably is the codec: XOR + XNOR cells "
              f"{xo(plain):,} -> {xo(ecc):,} ({xo(ecc) - xo(plain):+,}). Read the ECC cost from the bank-alone rows, the XOR / XNOR count and the ECP5 LUT delta "
              f"({by['ecp5_nb4_nm4_ecc']['luts'] - by['ecp5_nb4_nm4']['luts']:+,} LUT4, {by['ecp5_nb4_nm4_ecc']['flip_flops'] - by['ecp5_nb4_nm4']['flip_flops']:+,} flip-flops).")
if "ecp5_nb16_nm4" in by and by["ecp5_nb16_nm4"].get("status") != "OK":
    md.append("* `ecp5_nb16_nm4`: **ERROR, no result.** `synth_ecp5` completed but the final `ltp` pass overflowed the WASM call stack on the deep carry-chain netlist (`wasm trap: call stack exhausted`) "
              "after 19 minutes; the run was not repeated without `ltp` for time. The ECP5 flow therefore has results for the 4-bank matrix and the 4-bank ECC matrix only (`ltp` was removed from the ECP5 flow afterwards).")
md.append(f"""* **`ISSUE_WINDOW = 4` is expensive**: it adds only combinational logic (the flip-flop count is unchanged) but {(by['generic_nb4_nm4_win4']['cells_total'] - by['generic_nb4_nm4']['cells_total']):+,} generic cells at 4 banks ({100 * (by['generic_nb4_nm4_win4']['cells_total'] / by['generic_nb4_nm4']['cells_total'] - 1):.0f} %) and {(by['generic_nb16_nm4_win4']['cells_total'] - by['generic_nb16_nm4']['cells_total']):+,} at 16 banks ({100 * (by['generic_nb16_nm4_win4']['cells_total'] / by['generic_nb16_nm4']['cells_total'] - 1):.0f} %), with a longest path that grows by {by['generic_nb4_nm4_win4']['ltp_levels'] - by['generic_nb4_nm4']['ltp_levels']:+d} / {by['generic_nb16_nm4_win4']['ltp_levels'] - by['generic_nb16_nm4']['ltp_levels']:+d} levels. The measured bandwidth gain (BENCHMARKS.md section 5) has to be weighed against this.""")
md.append("""* **The flip-flops (17.5 k at 4 banks, 18.3 k at 8, 19.8 k at 16) are almost all the per-master slot tables**: 4 masters x `NSLOT = 8` entries, each holding the pre-shifted write
  / read data (5 words x 64 bit for a 256-bit bus), byte masks, bank / row of each word, status. They barely grow with the bank count (the banks add only their small FSMs and counters); the
  SRAM arrays are RAM cells (generic flow) or block RAM (ECP5 flow), not flip-flops. Area levers that were **not** explored: fewer or narrower slots (`NSLOT`, `DATA_WIDTH`), storing write data
  unshifted and shifting at issue, and `MISALIGN_EN = 0` (one word fewer per access).
* ECC adds the encoder / decoder / read-modify-write logic to every bank (see the bank-alone rows in 1.2).""")
md.append("## 3. ESTIMATE / ASSUMED (not a measurement)\n")
md.append(f"""The only timing-related quantity Yosys gives is `ltp`, the longest path in generic gates. Converting it to a time needs a gate delay, which **this repository does not supply**.
For orientation only, assume **{ASSUMED_PS_PER_LEVEL} ps per generic-gate level** (an arbitrary round number for a modern mid-size logic process; NOT a library value, NOT derived from any PDK here):
""")
md.append("| configuration (generic flow) | ltp levels | ASSUMED logic delay |\n|---|---|---|")
for name in sorted(by):
    r = by[name]
    if name.startswith("bank_ram"):
        continue
    if r.get("flow") == "generic" and r.get("status") == "OK" and r.get("ltp_levels"):
        md.append(f"| {name.split('_', 1)[1]} | {r['ltp_levels']} | ~{r['ltp_levels'] * ASSUMED_PS_PER_LEVEL / 1000:.1f} ns (levels x {ASSUMED_PS_PER_LEVEL} ps) |")
md.append("""
**What the longest path actually is (read from the `ltp` reports of these runs).** In five of the six generic runs it **starts at a master request input (`m_req_size`) and ends at bit 31 of a 32-bit
`c_lost` performance counter**, in the sixth at an arithmetic (`maccmap`) cell of the same kind: it runs through the decoder, the per-bank requester count and a 32-bit ripple adder
(`c_lost + requesters - accepted`). So the depth in the table is **set by the instrumentation's counter adder, not by the memory datapath**; the datapath path (decode -> per-bank selection -> arbiter ->
bank request) is shorter and was **not separately extracted** (that would need the counters excluded, or a static timing run). A cheap improvement that was not made: register the per-bank
requester count and accepted flag before the counter adders (or narrow / pipeline the counters), which would remove them from the longest path at the cost of one cycle of counter skew.
`m_req_ready` is not on any combinational request path (it depends on registered state only). **A real clock frequency needs the SRAM macro access time and setup (unknown here), wire delay and
clock tree; none can be estimated honestly from this data.** The numbers above must not be quoted as Fmax.

Other assumptions that are NOT results: block-RAM counts depend on the target FPGA's primitive size (ECP5 DP16KD 16 kbit, Xilinx RAMB36E1 36 kbit); the area of an ASIC implementation is
unknown (no standard-cell library; macro areas from the existing package's manifests were not used).
""")
open("docs/memory_matrix/SYNTHESIS.md", "w").write("\n".join(md))
print("wrote docs/memory_matrix/SYNTHESIS.md")
