# reports/ index

Every file is the output of a command in the top-level `Makefile`; none is hand-edited. All simulation numbers are Verilator RTL-SIMULATION results, not silicon.

| file | produced by | content |
|---|---|---|
| `regress.json` | `make regress` | 64 simulation cases (system TB over configurations, exhaustive address-map TB, existing adapters on the matrix): status, checks, errors |
| `mutation.json` | `make mutate` | 32 deliberate-fault mutants against the system testbench |
| `history/mutation_campaign1_before_window.json` | first campaign | 28 of 29 killed: `perf_conf_ge3` survived (a testbench hole, fixed) |
| `history/mutation_perf_conf_rerun.json`, `history/mutation_window_mutants_rerun.json` | reruns after fixes | the surviving mutant killed; window mutants after the program-order checker (two were equivalent mutants and were removed together with the dead RTL) |
| `history/regress_first_full_run_42_of_48.json` | first sweep | 6 failures: one real RTL defect (`NUM_MASTERS = 1` conflict counter) and five testbench assumptions |
| `formal.json` | `make formal` | 22 SymbiYosys jobs (address map, arbiter, matrix top); `formal_mutants.json`: the same properties failing on deliberately broken designs |
| `bench.json`, `bench.csv`, `bench_*.svg` | `make bench` | 276 benchmark runs: workloads x 23 hardware configurations |
| `analysis.json`, `analysis.md`, `layout.md` | `make analysis` | exact enumeration (tensor streams, column walks, vector splits, client demand), tile placement planner |
| `synth.json` | `make synth` | Yosys results (generic gates, ECP5, bank RAM inference) |
| `lint_verilator.log` | `make lint` loop in docs | Verilator `-Wall` over 23 parameter sets |
| `baseline_controller_dw64.log` | rerun of the existing controller testbench | the existing 4-bank controller at DW = 64: 172,228 checks, 0 errors (Verilator 5.49) |
