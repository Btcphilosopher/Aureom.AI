# MemoryMatrix tile placement (exact enumeration)

Tile = (M, N, K) elements; A is M x K INT8, B is K x N INT8, C is M x N INT32 (partial sums).  Four lock-step streams: A[k], B[k], C (read-modify-write) and the DMA fill of the next buffer.  `naive` = every operand at a bank-period boundary with the minimal pitch; `planned` = padded pitch + skewed bases chosen by this tool.

| banks | interleave | tile | A pitch | B pitch | C pitch | bases A/B/C/DMA (words mod NB) | lock-step conflict cycles of 512: naive -> planned | column distinct banks B: naive -> planned |
|---|---|---|---|---|---|---|---|---|
| 4 | LOW | [8, 8, 32] | 5 | 1 | 5 | [0, 1, 2, 3] | 512 -> 0 | 4.00 -> 4.00 |
| 4 | XOR | [8, 8, 32] | 4 | 1 | 4 | [0, 0, 0, 0] | 320 -> 320 | 3.34 -> 3.34 |
| 4 | LOW/g4 | [8, 8, 32] | 4 | 4 | 4 | [0, 0, 0, 0] | 512 -> 0 | 1.75 -> 4.00 |
| 8 | LOW | [8, 8, 32] | 5 | 1 | 5 | [0, 1, 2, 3] | 512 -> 0 | 4.00 -> 4.00 |
| 8 | XOR | [8, 8, 32] | 4 | 1 | 4 | [0, 0, 0, 0] | 0 -> 0 | 3.88 -> 3.88 |
| 8 | LOW/g4 | [8, 8, 32] | 4 | 4 | 4 | [0, 4, 0, 4] | 512 -> 0 | 1.75 -> 4.00 |
| 16 | LOW | [8, 8, 32] | 4 | 1 | 4 | [0, 1, 2, 3] | 512 -> 0 | 4.00 -> 4.00 |
| 16 | XOR | [8, 8, 32] | 4 | 1 | 4 | [0, 0, 0, 0] | 0 -> 0 | 4.00 -> 4.00 |
| 16 | LOW/g4 | [8, 8, 32] | 4 | 4 | 4 | [0, 4, 8, 12] | 512 -> 0 | 1.75 -> 4.00 |

Reading: a plan with 0 lock-step conflict cycles feeds A, B, C and the DMA at one word per stream per cycle with NO bank conflict; any non-zero value means no placement exists for that interleave (e.g. XOR hashing breaks unit-stride lock step at 4 banks: use LOW for streamed tiles and XOR/padding only where column walks dominate).
