# MemoryMatrix analytical study (exact enumeration, no simulation)

## A. Tensor operand streams: are lock-step A / B / C streams conflict free?

S unit-stride streams advance one 64-bit word per cycle in lock step (the TensorCore reading A[k], B[k], C[k]). A placement is the tuple of base word offsets; the table gives the fraction of ALL placements (offsets 0 .. 2*NB-1) that never hit one bank twice in one cycle.  100 % means any placement works, below that the tile bases must be chosen (skewed).

| banks | interleave | S=2 | S=3 | S=4 |
|---|---|---|---|---|
| 4 | LOW |  75.0 % |  37.5 % |   9.4 % |
| 4 | LOW/g4 |  50.0 % |   0.0 % |   0.0 % |
| 4 | XOR |   0.0 % |   0.0 % |   0.0 % |
| 4 | LINEAR |   0.0 % |   0.0 % |   0.0 % |
| 8 | LOW |  87.5 % |  65.6 % |  41.0 % |
| 8 | LOW/g4 |  75.0 % |  28.1 % |   2.9 % |
| 8 | XOR |  18.8 % |   2.3 % |   0.1 % |
| 8 | LINEAR |   0.0 % |   0.0 % |   0.0 % |
| 16 | LOW |  93.8 % |  82.0 % |  66.7 % |
| 16 | LOW/g4 |  87.5 % |  58.6 % |  28.2 % |
| 16 | XOR |  34.4 % |   9.6 % |   2.2 % |
| 16 | LINEAR |   0.0 % |   0.0 % |   0.0 % |

Reading: with LOW interleave and S streams on NB banks only NB*(NB-1)*...*(NB-S+1)/NB^S of placements are conflict free (e.g. 3 streams on 4 banks: 37.5 %), so the tile layout MUST skew the bases (A, B, C on banks +0, +1, +2): the placement helper benchmarks/memory_matrix/mm_layout.py does that.  LINEAR (bank per region) is conflict free only if the streams live in different banks; unit-stride streams inside one bank serialise completely.

## B. Column walk of a row-major matrix: effect of the row pitch

Four masters walk the SAME column on adjacent rows (row = r + m): the transpose pattern.  'distinct' = mean banks hit per step (4.00 = conflict free); 'slowdown' = mean cycles per step (1.00 = no serialisation).

| banks | interleave | pitch 512 words: distinct / slowdown | pitch 513 words (padded): distinct / slowdown |
|---|---|---|---|
| 4 | LOW | 1.00 / 4.00x | 4.00 / 1.00x |
| 4 | LOW/g4 | 1.00 / 4.00x | 1.75 / 3.00x |
| 4 | XOR | 3.34 / 1.56x | 2.00 / 2.34x |
| 4 | LINEAR | 1.38 / 3.50x | 1.38 / 3.50x |
| 8 | LOW | 1.00 / 4.00x | 4.00 / 1.00x |
| 8 | LOW/g4 | 1.00 / 4.00x | 1.75 / 3.00x |
| 8 | XOR | 3.88 / 1.09x | 1.00 / 4.00x |
| 8 | LINEAR | 1.38 / 3.50x | 1.38 / 3.50x |
| 16 | LOW | 1.00 / 4.00x | 4.00 / 1.00x |
| 16 | LOW/g4 | 1.00 / 4.00x | 1.75 / 3.00x |
| 16 | XOR | 4.00 / 1.00x | 3.62 / 1.28x |
| 16 | LINEAR | 1.38 / 3.50x | 1.38 / 3.50x |

## C. Vector loads: bank spanning and misalignment (single master, one word per bank per cycle)

Bytes [off, off+size) from a word-aligned start; 'cycles' = cycles one master needs to issue all words (words > banks or a granule that keeps neighbours in one bank serialise); 'useful' = requested bytes / bytes physically read.

| size | byte offset | words | NB=4: banks / cycles | NB=8: banks / cycles | NB=16: banks / cycles | useful |
|---|---|---|---|---|---|---|
| 128 bit | 0 | 2 | 2 / 1 | 2 / 1 | 2 / 1 | 100 % |
| 128 bit | 1 | 3 | 3 / 1 | 3 / 1 | 3 / 1 | 67 % |
| 128 bit | 2 | 3 | 3 / 1 | 3 / 1 | 3 / 1 | 67 % |
| 128 bit | 3 | 3 | 3 / 1 | 3 / 1 | 3 / 1 | 67 % |
| 128 bit | 4 | 3 | 3 / 1 | 3 / 1 | 3 / 1 | 67 % |
| 128 bit | 5 | 3 | 3 / 1 | 3 / 1 | 3 / 1 | 67 % |
| 128 bit | 6 | 3 | 3 / 1 | 3 / 1 | 3 / 1 | 67 % |
| 128 bit | 7 | 3 | 3 / 1 | 3 / 1 | 3 / 1 | 67 % |
| 256 bit | 0 | 4 | 4 / 1 | 4 / 1 | 4 / 1 | 100 % |
| 256 bit | 1 | 5 | 4 / 2 | 5 / 1 | 5 / 1 | 80 % |
| 256 bit | 2 | 5 | 4 / 2 | 5 / 1 | 5 / 1 | 80 % |
| 256 bit | 3 | 5 | 4 / 2 | 5 / 1 | 5 / 1 | 80 % |
| 256 bit | 4 | 5 | 4 / 2 | 5 / 1 | 5 / 1 | 80 % |
| 256 bit | 5 | 5 | 4 / 2 | 5 / 1 | 5 / 1 | 80 % |
| 256 bit | 6 | 5 | 4 / 2 | 5 / 1 | 5 / 1 | 80 % |
| 256 bit | 7 | 5 | 4 / 2 | 5 / 1 | 5 / 1 | 80 % |

A 256-bit access that is not 8-byte aligned touches 5 words: on 4 banks words 0 and 4 share a bank (2 cycles, 'self conflict'); on 8 and 16 banks it issues in one cycle.  Useful fraction is 32/40 = 80 % for any misaligned offset: the extra word is read and discarded.

## D. Client bandwidth demand vs. bank supply

Supply = NUM_BANKS words (8 B) per cycle at peak.  Demand is the client's own steady-state requirement (from the TensorCore08 and HPC vector-array documentation).  'min banks' assumes perfectly conflict-free placement; real requirement is higher (section E measures how much).

| client | read B/cycle | write B/cycle | total B/cycle | 64-bit words/cycle | min banks (ideal) |
|---|---|---|---|---|---|
| TensorCore 4x4 INT8 systolic | 8 | 0 | 8 | 1.0 | 1 |
| TensorCore 8x8 INT8 systolic | 16 | 0 | 16 | 2.0 | 2 |
| FP32 vector array 2 lanes | 24 | 8 | 32 | 4.0 | 4 |
| FP32 vector array 4 lanes | 48 | 16 | 64 | 8.0 | 8 |
| FP32 vector array 8 lanes | 96 | 32 | 128 | 16.0 | 16 |
| FP32 vector array 16 lanes | 192 | 64 | 256 | 32.0 | 32 |
| ControlCore RV32 load/store | 4 | 0 | 4 | 0.5 | 1 |
| CloudDMA 256-bit stream | 32 | 0 | 32 | 4.0 | 4 |

## E. Lower bounds for the benchmark workloads (4 masters, NREQ requests each, seed 1)

Ceiling = bytes / max(busiest bank load, busiest master's issue time).  The RTL cannot beat it; run_bench.py reports the RTL result next to it.

| workload | banks | ceiling useful B/cycle | peak B/cycle | useful fraction of physical |
|---|---|---|---|---|
| seq8_naive | 4 | 32.00 | 32 | 100 % |
| seq8_naive | 8 | 32.00 | 64 | 100 % |
| seq8_naive | 16 | 32.00 | 128 | 100 % |
| seq8_skew | 4 | 32.00 | 32 | 100 % |
| seq8_skew | 8 | 32.00 | 64 | 100 % |
| seq8_skew | 16 | 32.00 | 128 | 100 % |
| rand8 | 4 | 31.82 | 32 | 100 % |
| rand8 | 8 | 32.00 | 64 | 100 % |
| rand8 | 16 | 32.00 | 128 | 100 % |
| vec256_naive | 4 | 32.00 | 32 | 100 % |
| vec256_naive | 8 | 64.00 | 64 | 100 % |
| vec256_naive | 16 | 128.00 | 128 | 100 % |
| vec256_skew | 4 | 32.00 | 32 | 100 % |
| vec256_skew | 8 | 63.96 | 64 | 100 % |
| vec256_skew | 16 | 127.83 | 128 | 100 % |
| vec256_mis4 | 4 | 16.00 | 32 | 80 % |
| vec256_mis4 | 8 | 32.00 | 64 | 80 % |
| vec256_mis4 | 16 | 63.95 | 128 | 80 % |
| col_pitch_pow2 | 4 | 31.25 | 32 | 100 % |
| col_pitch_pow2 | 8 | 32.00 | 64 | 100 % |
| col_pitch_pow2 | 16 | 32.00 | 128 | 100 % |
| col_pitch_pad | 4 | 32.00 | 32 | 100 % |
| col_pitch_pad | 8 | 32.00 | 64 | 100 % |
| col_pitch_pad | 16 | 32.00 | 128 | 100 % |
| gemm_aware | 4 | 32.00 | 32 | 100 % |
| gemm_aware | 8 | 37.33 | 64 | 100 % |
| gemm_aware | 16 | 37.33 | 128 | 100 % |
| gemm_naive | 4 | 32.00 | 32 | 100 % |
| gemm_naive | 8 | 37.33 | 64 | 100 % |
| gemm_naive | 16 | 37.33 | 128 | 100 % |
| mix_system | 4 | 30.30 | 32 | 95 % |
| mix_system | 8 | 31.00 | 64 | 95 % |
| mix_system | 16 | 31.00 | 128 | 95 % |
| vec128_skew | 4 | 31.99 | 32 | 100 % |
| vec128_skew | 8 | 63.98 | 64 | 100 % |
| vec128_skew | 16 | 64.00 | 128 | 100 % |
