// generated wrapper: fixes the parameters of sf_asoc_sfb2_init for the unit test (Verilator -G cannot take 64/128-bit values portably)
`default_nettype none
module wrap_sfb2_init (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // ---------------------------------------------------------------- SFB2 slave side (from ControlCore ext_*)
  input  wire logic        s_req_valid_i,
  output logic             s_req_ready_o,
  input  wire logic        s_req_write_i,
  input  wire logic [31:0] s_req_addr_i,
  input  wire logic [31:0] s_req_wdata_i,
  input  wire logic [3:0]  s_req_wstrb_i,
  output logic             s_rsp_valid_o,
  input  wire logic        s_rsp_ready_i,
  output logic [31:0]      s_rsp_rdata_o,
  output logic             s_rsp_error_o,
  // ---------------------------------------------------------------- ALP master side (128-bit)
  output logic                                      m_req_valid_o,
  input  wire logic                                 m_req_ready_i,
  output logic [sf_albion_pkg::SF_OP_W-1:0]         m_req_op_o,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]        m_req_tag_o,
  output logic [sf_albion_pkg::SF_DOM_W-1:0]        m_req_dom_o,
  output logic [sf_albion_pkg::SF_ATTR_W-1:0]       m_req_attr_o,
  output logic [sf_albion_pkg::SF_ADDR_W-1:0]       m_req_addr_o,
  output logic [sf_albion_pkg::SF_BE_W-1:0]         m_req_be_o,
  output logic [sf_albion_pkg::SF_DATA_W-1:0]       m_req_data_o,
  input  wire logic                                 m_rsp_valid_i,
  output logic                                      m_rsp_ready_o,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]   m_rsp_tag_i,
  input  wire logic [sf_albion_pkg::SF_STATUS_W-1:0] m_rsp_status_i,
  input  wire logic [sf_albion_pkg::SF_CMETA_W-1:0] m_rsp_meta_i,
  input  wire logic [sf_albion_pkg::SF_DATA_W-1:0]  m_rsp_data_i,
  // ---------------------------------------------------------------- event pulses (for counters)
  output logic             evt_req_o,       // an SFB2 request was accepted
  output logic             evt_err_o,       // an error response was returned to SFB2
  output logic             evt_miss_o       // the request hit no window (answered locally)
);
  sf_asoc_sfb2_init #(
    .NW(2),
    .WIN_BASE({32'h28000000, 32'h20000000}),
    .WIN_MASK({32'hFFFFF000, 32'hFFFF0000}),
    .WIN_DST({64'h0000_0001_8000_0000, 64'h0000_0001_1000_0000}),
    .DOM(8'd0), .ATTR(8'h66)
  ) u (.*);
endmodule
`default_nettype wire
