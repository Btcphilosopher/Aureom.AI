"""sf_asoc_regtgt: ALP v1 target link -> 32-bit register bus.  Python reference decides every expected status / access."""
import os, random
import cocotb
from harness import *


class RegBus:
    """register-bus slave model: 32-bit regs, random response latency, a few undefined offsets answer an error"""
    def __init__(self, dut, rnd):
        self.d, self.rnd = dut, rnd
        self.regs = {}
        self.log = []                 # (we, addr, wdata, dom, priv)
        self.pending = None
        self.rv, self.rdata, self.err = 0, 0, 0

    def known(self, a):
        return a < 0x400

    def drive(self):
        self.d.rb_rvalid_i.value = self.rv
        self.d.rb_rdata_i.value = self.rdata
        self.d.rb_err_i.value = self.err

    def sample(self):
        # response timing: issued the cycle after a request strobe + random extra latency
        self.rv = 0
        if self.pending is not None:
            self.pending[0] -= 1
            if self.pending[0] <= 0:
                we, a, wd = self.pending[1:]
                self.rv = 1
                if not self.known(a):
                    self.rdata, self.err = 0, 1
                else:
                    self.err = 0
                    if we:
                        self.regs[a] = wd
                        self.rdata = 0
                    else:
                        self.rdata = self.regs.get(a, 0xC0DE0000 | a)
                self.pending = None
        if val(self.d.rb_valid_o):
            assert self.pending is None, "second register request while one is outstanding"
            we, a, wd = val(self.d.rb_we_o), val(self.d.rb_addr_o), val(self.d.rb_wdata_o)
            self.log.append((we, a, wd, val(self.d.rb_dom_o), val(self.d.rb_priv_o)))
            self.pending = [1 + self.rnd.r.randint(0, 3), we, a, wd]


class AlpMaster:
    """drives one request at a time and checks the response against an expectation callback"""
    def __init__(self, dut, rnd):
        self.d, self.rnd = dut, rnd
        self.cur = None
        self.q = []
        self.done = []
        self.rdy_rsp = 1

    def drive(self):
        d = self.d
        if self.cur is None and self.q and self.rnd.chance(70):
            self.cur = self.q.pop(0)
        if self.cur:
            r = self.cur
            d.s_req_valid_i.value = 1
            d.s_req_op_i.value, d.s_req_tag_i.value, d.s_req_dom_i.value = r["op"], r["tag"], r["dom"]
            d.s_req_attr_i.value, d.s_req_addr_i.value, d.s_req_be_i.value, d.s_req_data_i.value = r["attr"], r["addr"], r["be"], r["data"]
        else:
            d.s_req_valid_i.value = 0
        self.rdy_rsp = 0 if self.rnd.chance(30) else 1
        d.s_rsp_ready_i.value = self.rdy_rsp

    def sample(self):
        d = self.d
        if self.cur and val(d.s_req_valid_i) and val(d.s_req_ready_o):
            self.cur["accepted"] = True
            self.done.append(self.cur)
            self.cur = None
        if val(d.s_rsp_valid_o) and self.rdy_rsp:
            self.rsp = (val(d.s_rsp_tag_o), val(d.s_rsp_status_o), val(d.s_rsp_meta_o), val(d.s_rsp_data_o))
            self.on_rsp(self.rsp)

    def on_rsp(self, rsp):
        pass


def expect(req, regs_model):
    """independent expectation: (status, performs_access, lane)"""
    op, addr, be = req["op"], req["addr"], req["be"]
    if op not in (OP_READ, OP_WRITE):
        return ST_BADOP, False, 0
    if addr & 0xF:
        return ST_ALIGN, False, 0
    if be == 0:
        return ST_BADBE, False, 0
    lanes = [l for l in range(4) if (be >> (4 * l)) & 0xF]
    full = [l for l in lanes if ((be >> (4 * l)) & 0xF) == 0xF]
    if len(lanes) != 1 or len(full) != 1:
        return ST_TARGET, False, 0
    return None, True, lanes[0]


@cocotb.test()
async def regtgt_random(dut):
    rnd = Rand(int(os.environ.get("SEED", "7")))
    bus, m = RegBus(dut, rnd), AlpMaster(dut, rnd)
    expected = {}                      # tag -> (status, lane, op, addr, wdata)
    order = []
    errors = []

    def on_rsp(rsp):
        tag, st, meta, data = rsp
        want = order.pop(0)
        if want["tag"] != tag:
            errors.append("tag order %d != %d" % (tag, want["tag"]))
        if st != want["status"]:
            errors.append("status %d != %d for %s" % (st, want["status"], want))
        if meta != (0b10 | (1 if want["op"] == OP_WRITE else 0)):
            errors.append("meta %02x" % meta)
        if st != 0 or want["op"] == OP_WRITE:
            if data != 0:
                errors.append("data not zero")
        elif want["status"] == 0:
            exp = want["rdata"] << (32 * want["lane"])
            if data != exp:
                errors.append("read data %032x != %032x" % (data, exp))
    m.on_rsp = on_rsp
    await reset(dut)
    n_req = 600
    model_regs = {}
    for i in range(n_req):
        kind = rnd.r.random()
        lane = rnd.r.randint(0, 3)
        off = rnd.r.randint(0, 0x3F) * 16
        r = dict(op=OP_READ if rnd.r.random() < 0.5 else OP_WRITE, tag=i & 0xFF, dom=rnd.r.choice([0, 1, 5]), attr=rnd.r.choice([0x66, 0x22, 0x06]),
                 addr=off, be=0xF << (4 * lane), data=rnd.r.getrandbits(128))
        if kind < 0.12: r["op"] = rnd.r.choice([0, 3, 4, 7, 15])
        elif kind < 0.20: r["addr"] |= rnd.r.randint(1, 15)
        elif kind < 0.28: r["be"] = 0
        elif kind < 0.36: r["be"] = rnd.r.choice([0x1, 0x7, 0xFF, 0xF00F, 0xFFFF, 0x0030])
        elif kind < 0.42: r["addr"] = 0x400 + 16 * rnd.r.randint(0, 0x2F)                          # undefined register (offset >= 0x400) -> register error
        st, access, lane_e = expect(r, None)
        rec = dict(tag=r["tag"], op=r["op"], status=st, lane=lane_e)
        if access:
            a = (r["addr"] & 0xFFF & ~0xF) | (lane_e * 4)
            rec["a"] = a
            if not bus.known(a):
                rec["status"] = ST_TARGET
            elif r["op"] == OP_READ:
                rec["status"] = 0
                rec["rdata_from"] = a
            else:
                rec["status"] = 0
                rec["wd"] = (r["data"] >> (32 * lane_e)) & 0xFFFFFFFF
        order.append(rec)
        m.q.append(r)
    # precompute read data lazily: needs the register file state at the time of the access -> compute at response time using bus.regs
    orig = m.on_rsp
    def fix(rsp):
        want = order[0]
        if "rdata_from" in want:
            want["rdata"] = bus.regs.get(want["rdata_from"], 0xC0DE0000 | want["rdata_from"])
        orig(rsp)
    m.on_rsp = fix
    await run(dut, [bus, m], 60000, done=lambda: len(order) == 0)
    assert not order, "%d responses missing" % len(order)
    assert not errors, errors[:10]
    # every legal access reached the bus exactly once, with the right address / data / hardware domain / privilege
    legal = [r for r in m.done]
    expect_log = []
    for r in legal:
        st, access, lane_e = expect(r, None)
        if access:
            a = (r["addr"] & 0xFFF & ~0xF) | (lane_e * 4)
            expect_log.append((1 if r["op"] == OP_WRITE else 0, a, (r["data"] >> (32 * lane_e)) & 0xFFFFFFFF if r["op"] == OP_WRITE else 0,
                               r["dom"], (r["attr"] >> 2) & 1))
    got = [(we, a, wd if we else 0, dom, pv) for we, a, wd, dom, pv in bus.log]
    assert got == expect_log, "register bus access log differs (%d vs %d entries)" % (len(got), len(expect_log))
    dut._log.info("regtgt: %d requests, %d register accesses, all responses as expected", len(legal), len(got))
