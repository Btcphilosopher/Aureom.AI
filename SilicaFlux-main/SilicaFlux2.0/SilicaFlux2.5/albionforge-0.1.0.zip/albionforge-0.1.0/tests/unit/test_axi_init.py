"""sf_asoc_axi_init: CloudDMA AXI4 memory port -> ALP v1 initiator (burst splitting, IDs, error mapping, second-check refusals)."""
import os
import cocotb
from harness import *

ID_W, AW, DOM_W = 3, 40, 4
EXPECT_DOM = 1
ZONE_TARGET_ERR = (0xE000, 0xF000)
ZONE_DECODE_ERR = (0xF000, 0x10000)
READ_ZONE = (0x0000, 0x4000)
WRITE_ZONE = (0x4000, 0x8000)


def zone_status(addr):
    if ZONE_TARGET_ERR[0] <= addr < ZONE_TARGET_ERR[1]:
        return ST_TARGET
    if ZONE_DECODE_ERR[0] <= addr < ZONE_DECODE_ERR[1]:
        return ST_DECODE
    return ST_OKAY


class AlpTarget:
    """in-order ALP target with random accept / response latency; memory of bytes; logs every request"""
    def __init__(self, dut, rnd, mem):
        self.d, self.rnd, self.mem = dut, rnd, mem
        self.reqlog, self.q, self.cur = [], [], None
        self.accept = 1
        self.outstanding_tags = []
        self.rsp_hold = None

    def drive(self):
        d = self.d
        self.accept = 1 if self.rnd.chance(75) else 0
        d.m_req_ready_i.value = self.accept
        if self.rsp_hold is None and self.q and self.q[0][0] <= 0 and self.rnd.chance(80):
            self.rsp_hold = self.q.pop(0)[1]
        if self.rsp_hold:
            tag, st, meta, data = self.rsp_hold
            d.m_rsp_valid_i.value = 1
            d.m_rsp_tag_i.value, d.m_rsp_status_i.value, d.m_rsp_meta_i.value, d.m_rsp_data_i.value = tag, st, meta, data
        else:
            d.m_rsp_valid_i.value = 0

    def sample(self):
        d = self.d
        for e in self.q:
            e[0] -= 1
        if val(d.m_rsp_valid_i) and val(d.m_rsp_ready_o):
            self.rsp_hold = None
        if val(d.m_req_valid_o) and self.accept:
            op, tag, addr = val(d.m_req_op_o), val(d.m_req_tag_o), val(d.m_req_addr_o)
            be, data = val(d.m_req_be_o), val(d.m_req_data_o)
            assert val(d.m_req_dom_o) == 1 and val(d.m_req_attr_o) == 0x22, "domain / attribute stamped on the request"
            assert addr % 16 == 0 and be != 0
            assert tag not in self.outstanding_tags, "tag reused while outstanding"
            self.outstanding_tags.append(tag)
            assert len(self.outstanding_tags) <= 16
            st = zone_status(addr)
            self.reqlog.append((op, addr, be, data if op == OP_WRITE else 0))
            rdata = 0
            if st == ST_OKAY:
                if op == OP_WRITE:
                    for b in range(16):
                        if (be >> b) & 1:
                            self.mem[addr + b] = (data >> (8 * b)) & 0xFF
                else:
                    for b in range(16):
                        rdata |= self.mem.get(addr + b, 0) << (8 * b)
            self.q.append([self.rnd.r.randint(0, 4), (tag, st, 0b10 | (1 if op == OP_WRITE else 0), rdata)])
            # tag leaves the outstanding list when its response is accepted: modelled by the in-order pop below
        # responses accepted this cycle free their tag
        if val(d.m_rsp_valid_i) and val(d.m_rsp_ready_o):
            self.outstanding_tags.pop(0)


class AxiMaster:
    def __init__(self, dut, rnd):
        self.d, self.rnd = dut, rnd
        self.ar, self.aw = [], []            # bursts waiting for the address channel
        self.w = []                          # W beats waiting (only after their AW was accepted)
        self.exp_r, self.exp_b = [], []
        self.cur_ar = self.cur_aw = self.cur_w = None
        self.rready = 1
        self.bready = 1
        self.errors = []
        self.r_beats = self.b_resps = 0
        self.r_err_beats = self.b_err = 0

    def drive(self):
        d = self.d
        if self.cur_ar is None and self.ar and self.rnd.chance(60): self.cur_ar = self.ar.pop(0)
        if self.cur_aw is None and self.aw and self.rnd.chance(60): self.cur_aw = self.aw.pop(0)
        for name, cur in (("ar", self.cur_ar), ("aw", self.cur_aw)):
            v = getattr(d, name + "_valid_i")
            if cur:
                v.value = 1
                getattr(d, name + "_id_i").value = cur["id"]
                getattr(d, name + "_addr_i").value = cur["addr"]
                getattr(d, name + "_len_i").value = cur["len"]
                getattr(d, name + "_size_i").value = cur["size"]
                getattr(d, name + "_burst_i").value = cur["burst"]
                getattr(d, name + "_asid_i").value = cur["asid"]
                getattr(d, name + "_domain_i").value = cur["dom"]
            else:
                v.value = 0
        if self.cur_w is None and self.w and self.rnd.chance(75): self.cur_w = self.w.pop(0)
        if self.cur_w:
            d.w_valid_i.value = 1
            d.w_data_i.value, d.w_strb_i.value, d.w_last_i.value = self.cur_w
        else:
            d.w_valid_i.value = 0
        self.rready = 1 if self.rnd.chance(80) else 0
        self.bready = 1 if self.rnd.chance(80) else 0
        d.r_ready_i.value, d.b_ready_i.value = self.rready, self.bready

    def sample(self):
        d = self.d
        if self.cur_ar and val(d.ar_ready_o):
            self.cur_ar = None
        if self.cur_aw and val(d.aw_ready_o):
            burst = self.cur_aw
            for i in range(burst["len"] + 1):                  # W beats become available once the AW was accepted
                self.w.append((burst["wdata"][i], burst["wstrb"][i], 1 if i == burst["len"] else 0))
            self.cur_aw = None
        if self.cur_w and val(d.w_ready_o):
            self.cur_w = None
        if val(d.r_valid_o) and self.rready:
            exp = self.exp_r.pop(0) if self.exp_r else None
            got = (val(d.r_id_o), val(d.r_resp_o), val(d.r_last_o), val(d.r_data_o))
            if exp != got:
                self.errors.append("R beat %d: got %s expected %s" % (self.r_beats, got, exp))
            self.r_beats += 1
            if got[1] != 0: self.r_err_beats += 1
        if val(d.b_valid_o) and self.bready:
            exp = self.exp_b.pop(0) if self.exp_b else None
            got = (val(d.b_id_o), val(d.b_resp_o))
            if exp != got:
                self.errors.append("B %d: got %s expected %s" % (self.b_resps, got, exp))
            self.b_resps += 1
            if got[1] != 0: self.b_err += 1


@cocotb.test()
async def axi_init_random(dut):
    rnd = Rand(int(os.environ.get("SEED", "3")))
    mem = {}
    model = {}                                   # independent model of what the target memory must hold
    for a in range(0, 0x4000):
        v = rnd.r.getrandbits(8)
        mem[a] = v
        model[a] = v
    tgt, axi = AlpTarget(dut, rnd, mem), AxiMaster(dut, rnd)
    exp_reads, exp_writes = [], []
    n_bad = n_err_expected = 0

    def bad_fields(rnd):
        kind = rnd.r.choice(["dom", "asid", "size", "burst", "align"])
        f = dict(dom=EXPECT_DOM, asid=0, size=4, burst=1)
        if kind == "dom": f["dom"] = rnd.r.choice([0, 2, 3, 15])
        elif kind == "asid": f["asid"] = rnd.r.randint(1, 15)
        elif kind == "size": f["size"] = rnd.r.choice([0, 2, 3, 5])
        elif kind == "burst": f["burst"] = rnd.r.choice([0, 2, 3])
        return f, kind

    await reset(dut)
    for n in range(260):
        is_wr = rnd.r.random() < 0.5
        length = rnd.r.choice([0, 0, 1, 3, 7, 15, 31])
        beats = length + 1
        zone = WRITE_ZONE if is_wr else READ_ZONE
        base = rnd.r.randrange(zone[0], zone[1] - 16 * beats, 16)
        # keep inside one 4 KiB page
        base = base & ~0xFFF | (base & 0xFFF if (base & 0xFFF) + 16 * beats <= 0x1000 else 0)
        r = rnd.r.random()
        bad, kind, fields = False, None, dict(dom=EXPECT_DOM, asid=0, size=4, burst=1)
        if r < 0.10:
            fields, kind = bad_fields(rnd); bad = True
            if kind == "align": base += rnd.r.randint(1, 15)
        elif r < 0.18: base = 0xE000 + (base & 0xFF0) % 0x800       # target error zone
        elif r < 0.24: base = 0xF000 + (base & 0xFF0) % 0x800       # decode error zone
        base &= ~0xFFF if False else ~0
        bid = rnd.r.randrange(0, 8)
        b = dict(id=bid, addr=base, len=length, size=fields["size"], burst=fields["burst"], asid=fields["asid"], dom=fields["dom"])
        if bad: n_bad += 1
        resp_from_zone = {ST_OKAY: 0, ST_TARGET: 2, ST_DECODE: 3}
        if not is_wr:
            axi.ar.append(b)
            for i in range(beats):
                a = base + 16 * i
                if bad:
                    axi.exp_r.append((bid, 2, 1 if i == length else 0, 0)); n_err_expected += 1
                else:
                    st = zone_status(a)
                    data = 0
                    if st == ST_OKAY:
                        for k in range(16): data |= model.get(a + k, 0) << (8 * k)
                    axi.exp_r.append((bid, resp_from_zone[st], 1 if i == length else 0, data))
                    if st != ST_OKAY: n_err_expected += 1
                    exp_reads.append((OP_READ, a, 0xFFFF, 0))
        else:
            b["wdata"] = [rnd.r.getrandbits(128) for _ in range(beats)]
            b["wstrb"] = [rnd.r.choice([0xFFFF, 0xFFFF, 0x00FF, 0xFF00, 0x0001, 0x8000, 0x0F0F, rnd.r.randint(1, 0xFFFF)]) for _ in range(beats)]
            axi.aw.append(b)
            st_first = zone_status(base)
            if bad:
                axi.exp_b.append((bid, 2)); n_err_expected += 1
            else:
                axi.exp_b.append((bid, resp_from_zone[st_first]))
                if st_first != ST_OKAY: n_err_expected += 1
                for i in range(beats):
                    a = base + 16 * i
                    exp_writes.append((OP_WRITE, a, b["wstrb"][i], b["wdata"][i]))
                    if st_first == ST_OKAY:
                        for k in range(16):
                            if (b["wstrb"][i] >> k) & 1: model[a + k] = (b["wdata"][i] >> (8 * k)) & 0xFF
    n_refused = 0
    evt = {"err": 0, "refused": 0}

    class Evt:
        def drive(self): pass
        def sample(self):
            evt["err"] += val(dut.evt_err_o)
            evt["refused"] += val(dut.evt_refused_o)
    total = len(axi.exp_r) + len(axi.exp_b)
    await run(dut, [tgt, axi, Evt()], 400000, done=lambda: not axi.exp_r and not axi.exp_b and not axi.ar and not axi.aw and not axi.w and axi.cur_ar is None and axi.cur_aw is None and axi.cur_w is None)
    assert not axi.errors, axi.errors[:8]
    assert not axi.exp_r and not axi.exp_b, "responses missing: %d R, %d B" % (len(axi.exp_r), len(axi.exp_b))
    rd = [x for x in tgt.reqlog if x[0] == OP_READ]
    wr = [x for x in tgt.reqlog if x[0] == OP_WRITE]
    assert rd == exp_reads, "ALP read requests differ from the bursts (%d vs %d)" % (len(rd), len(exp_reads))
    assert wr == exp_writes, "ALP write requests differ from the bursts (%d vs %d)" % (len(wr), len(exp_writes))
    for a, v in model.items():
        if a < 0x8000:
            assert mem.get(a, 0) == v, "memory byte %x: %02x != %02x" % (a, mem.get(a, 0), v)
    assert evt["refused"] == n_bad, "refused events %d != bad bursts %d" % (evt["refused"], n_bad)
    assert evt["err"] == n_err_expected, "error events %d != expected %d" % (evt["err"], n_err_expected)
    dut._log.info("axi_init: %d R beats, %d B responses, %d ALP reads, %d ALP writes, %d bad bursts refused, %d error completions",
                  axi.r_beats, axi.b_resps, len(rd), len(wr), n_bad, n_err_expected)
