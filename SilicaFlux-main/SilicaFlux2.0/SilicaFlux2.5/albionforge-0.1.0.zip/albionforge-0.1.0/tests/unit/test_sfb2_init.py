"""sf_asoc_sfb2_init: ControlCore SFB2 master -> ALP v1 initiator (window translation, lane steering, local errors)."""
import os
import cocotb
from harness import *

WINDOWS = [(0x20000000, 0xFFFF0000, 0x1_1000_0000), (0x28000000, 0xFFFFF000, 0x1_8000_0000)]   # (cc base, mask, alp base)
DOM, ATTR = 0, 0x66


def translate(a):
    for base, mask, dst in WINDOWS:
        if a & mask == base:
            return dst | (a & ~mask & 0xFFFFFFFF)
    return None


class Sfb2Master:
    def __init__(self, dut, rnd):
        self.d, self.rnd = dut, rnd
        self.q, self.cur, self.waiting = [], None, False
        self.results = []
        self.rrdy = 1

    def drive(self):
        d = self.d
        if self.cur is None and not self.waiting and self.q and self.rnd.chance(60):
            self.cur = self.q.pop(0)
        if self.cur:
            d.s_req_valid_i.value = 1
            d.s_req_write_i.value, d.s_req_addr_i.value = self.cur["we"], self.cur["addr"]
            d.s_req_wdata_i.value, d.s_req_wstrb_i.value = self.cur["wd"], self.cur["ws"]
        else:
            d.s_req_valid_i.value = 0
        self.rrdy = 1 if self.rnd.chance(70) else 0
        d.s_rsp_ready_i.value = self.rrdy

    def sample(self):
        d = self.d
        if self.cur and val(d.s_req_ready_o):
            self.cur["t"] = "sent"
            self.waiting = True
            self.sent = self.cur
            self.cur = None
        if val(d.s_rsp_valid_o) and self.rrdy:
            assert self.waiting, "SFB2 response without a request"
            self.waiting = False
            self.results.append((self.sent, val(d.s_rsp_rdata_o), val(d.s_rsp_error_o)))


class AlpTarget:
    def __init__(self, dut, rnd):
        self.d, self.rnd = dut, rnd
        self.mem = {}                 # 16-byte word address -> int
        self.log = []
        self.q, self.hold, self.acc = [], None, 1

    def drive(self):
        d = self.d
        self.acc = 1 if self.rnd.chance(70) else 0
        d.m_req_ready_i.value = self.acc
        if self.hold is None and self.q and self.q[0][0] <= 0 and self.rnd.chance(80):
            self.hold = self.q.pop(0)[1]
        if self.hold:
            tag, st, meta, data = self.hold
            d.m_rsp_valid_i.value = 1
            d.m_rsp_tag_i.value, d.m_rsp_status_i.value, d.m_rsp_meta_i.value, d.m_rsp_data_i.value = tag, st, meta, data
        else:
            d.m_rsp_valid_i.value = 0

    def sample(self):
        d = self.d
        for e in self.q: e[0] -= 1
        if val(d.m_rsp_valid_i) and val(d.m_rsp_ready_o): self.hold = None
        if val(d.m_req_valid_o) and self.acc:
            op, tag, addr, be, data = val(d.m_req_op_o), val(d.m_req_tag_o), val(d.m_req_addr_o), val(d.m_req_be_o), val(d.m_req_data_o)
            assert val(d.m_req_dom_o) == DOM and val(d.m_req_attr_o) == ATTR
            assert addr % 16 == 0
            self.log.append((op, addr, be, data if op == OP_WRITE else 0))
            st = ST_TARGET if (addr & 0xFF0) == 0xFF0 else ST_OKAY             # a fault zone at the end of every 4 KiB page
            rd = 0
            if st == ST_OKAY:
                w = self.mem.get(addr, 0)
                if op == OP_WRITE:
                    for b in range(16):
                        if (be >> b) & 1:
                            w = (w & ~(0xFF << (8 * b))) | (((data >> (8 * b)) & 0xFF) << (8 * b))
                    self.mem[addr] = w
                else:
                    rd = w
            self.q.append([self.rnd.r.randint(0, 3), (tag, st, 0b10 | (op == OP_WRITE), rd)])


@cocotb.test()
async def sfb2_init_random(dut):
    rnd = Rand(int(os.environ.get("SEED", "5")))
    cpu, tgt = Sfb2Master(dut, rnd), AlpTarget(dut, rnd)
    await reset(dut)
    model = {}                                   # independent model: 16-byte words
    expect, exp_log = [], []
    n_miss = n_nowrite = 0
    for i in range(700):
        r = rnd.r.random()
        win = rnd.r.choice(WINDOWS)
        a = win[0] + (rnd.r.randrange(0, 0x1000 if win[1] == 0xFFFFF000 else 0x4000) & ~3)
        if r < 0.12: a = rnd.r.choice([0x2001_0000, 0x2B00_0000, 0x3FFF_FFFC, 0x0000_1000, 0x2800_1000])     # no window
        we = rnd.r.random() < 0.55
        ws = rnd.r.choice([0xF, 0xF, 0x1, 0x2, 0x4, 0x8, 0x3, 0xC, 0x6, 0x0 if rnd.r.random() < 0.2 else 0xF, rnd.r.randint(1, 15)])
        wd = rnd.r.getrandbits(32)
        cpu.q.append(dict(we=int(we), addr=a, wd=wd, ws=ws if we else 0xF))
        dst = translate(a)
        if dst is None:
            expect.append(("miss", None)); n_miss += 1
            continue
        if we and ws == 0:
            expect.append(("nowrite", None)); n_nowrite += 1
            continue
        word, lane = dst & ~0xF, (dst >> 2) & 3
        be = (ws if we else 0xF) << (4 * lane)
        err = (word & 0xFF0) == 0xFF0
        rdata = 0
        if not err:
            w = model.get(word, 0)
            if we:
                for b in range(4):
                    if (ws >> b) & 1:
                        sh = 32 * lane + 8 * b
                        w = (w & ~(0xFF << sh)) | (((wd >> (8 * b)) & 0xFF) << sh)
                model[word] = w
            else:
                rdata = (w >> (32 * lane)) & 0xFFFFFFFF
        expect.append(("alp", dict(err=err, rdata=rdata)))
        exp_log.append((OP_WRITE if we else OP_READ, word, be, (wd << (32 * lane)) if we else 0))
    await run(dut, [cpu, tgt], 200000, done=lambda: len(cpu.results) == 700)
    assert len(cpu.results) == 700, "only %d of 700 SFB2 responses" % len(cpu.results)
    for idx, ((req, rdata, err), (kind, e)) in enumerate(zip(cpu.results, expect)):
        if kind in ("miss",):
            assert err == 1 and rdata == 0, "window miss must give an SFB2 error with zero data: %s" % req
        elif kind == "nowrite":
            assert err == 0 and rdata == 0
        else:
            assert err == int(e["err"]), (idx, hex(req['addr']), req, err, e, 'alp log so far', len(tgt.log))
            assert rdata == (0 if (e["err"] or req["we"]) else e["rdata"]), (req, hex(rdata), hex(e["rdata"]))
    # exact ALP traffic: only legal requests, translated, lane-steered, in order
    def norm(x):
        op, a, be, d = x
        if op == OP_WRITE:
            d = d & sum(0xFF << (8 * b) for b in range(16) if (be >> b) & 1)
        return (op, a, be, d)
    assert [norm(x) for x in tgt.log] == [norm(x) for x in exp_log], "ALP request stream differs (%d vs %d)" % (len(tgt.log), len(exp_log))
    dut._log.info("sfb2_init: 700 SFB2 transactions, %d window misses answered locally, %d no-strobe writes completed locally, %d ALP requests", n_miss, n_nowrite, len(tgt.log))
