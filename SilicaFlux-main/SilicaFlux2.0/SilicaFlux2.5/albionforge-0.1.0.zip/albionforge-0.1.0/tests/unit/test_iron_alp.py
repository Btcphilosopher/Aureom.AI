"""sf_asoc_iron_alp: IronMemory (ECC SRAM, buffer manager) behind two ALP v1 target links (128-bit -> 64-bit adaptation).

Independent model: a byte array per port zone, buffer permissions (domain 1 may not write the upper quarter), ALP legality
precedence.  Two masters use disjoint write zones so the expected data is well defined without modelling arbitration."""
import os
import cocotb
from harness import *

BASE = 0x1_1000_0000
SIZE = 0x10000
ST = dict(OK=0, DECODE=1, DENIED=2, BADOP=3, BADBE=4, ALIGN=5)


VEC = {}


class Port:
    def __init__(self, dut, idx, rnd, mem, model):
        self.d, self.i, self.rnd, self.mem = dut, idx, rnd, mem
        self.q, self.cur, self.waiting, self.rrdy = [], None, False, 1
        self.done = []
        self.errors = []

    def drive(self):
        d, i = self.d, self.i
        if self.cur is None and not self.waiting and self.q and self.rnd.chance(70):
            self.cur = self.q.pop(0)
        def setv(name, w, v):
            # shared cache: cocotb writes are not visible until the next delta, so never read-modify-write the DUT signal
            cur = VEC.get(name, 0)
            mask = ((1 << w) - 1) << (w * i)
            cur = (cur & ~mask) | ((v & ((1 << w) - 1)) << (w * i))
            VEC[name] = cur
            getattr(d, name).value = cur
        if self.cur:
            r = self.cur
            setv("s_req_valid_i", 1, 1)
            setv("s_req_op_i", 4, r["op"]); setv("s_req_tag_i", 8, r["tag"]); setv("s_req_dom_i", 8, r["dom"])
            setv("s_req_attr_i", 8, 0x22); setv("s_req_addr_i", 64, r["addr"]); setv("s_req_be_i", 16, r["be"]); setv("s_req_data_i", 128, r["data"])
        else:
            setv("s_req_valid_i", 1, 0)
        self.rrdy = 1 if self.rnd.chance(70) else 0
        setv("s_rsp_ready_i", 1, self.rrdy)

    def sample(self):
        d, i = self.d, self.i
        g = lambda name, w: (val(getattr(d, name)) >> (w * i)) & ((1 << w) - 1)
        if self.cur and g("s_req_valid_i", 1) and g("s_req_ready_o", 1):
            self.sent, self.cur, self.waiting = self.cur, None, True
        if g("s_rsp_valid_o", 1) and self.rrdy:
            assert self.waiting, "response without a request on port %d" % i
            self.waiting = False
            self.done.append((self.sent, g("s_rsp_tag_o", 8), g("s_rsp_status_o", 4), g("s_rsp_meta_o", 8), g("s_rsp_data_o", 128)))


async def bm(dut, op, id_, start, ln, owner, rd, wr, typ=0):
    await FallingEdge(dut.clk_i)
    dut.bm_cmd_valid_i.value = 1
    for n, v in (("op", op), ("requester", 0), ("id", id_), ("btype", typ), ("start", start), ("len", ln), ("owner", owner), ("rd_mask", rd), ("wr_mask", wr)):
        getattr(dut, "bm_cmd_%s_i" % n).value = v
    while True:
        await Timer(1, units="ns")
        if val(dut.bm_cmd_ready_o):
            break
        await FallingEdge(dut.clk_i)
    await RisingEdge(dut.clk_i)
    await FallingEdge(dut.clk_i)
    dut.bm_cmd_valid_i.value = 0
    for _ in range(20000):
        await RisingEdge(dut.clk_i)
        if val(dut.bm_rsp_valid_o):
            return val(dut.bm_rsp_status_o)
    raise AssertionError("buffer manager did not answer")


@cocotb.test()
async def iron_alp_random(dut):
    rnd = Rand(int(os.environ.get("SEED", "9")))
    for n in ("s_req_valid_i", "s_req_op_i", "s_req_tag_i", "s_req_dom_i", "s_req_attr_i", "s_req_addr_i", "s_req_be_i", "s_req_data_i", "s_rsp_ready_i"):
        getattr(dut, n).value = 0
    for n in ("bm_cmd_valid_i", "csr_valid_i", "csr_we_i", "csr_addr_i", "csr_wdata_i"):
        getattr(dut, n).value = 0
    await reset(dut)
    for _ in range(40000):
        await RisingEdge(dut.clk_i)
        if val(dut.init_done_o):
            break
    assert val(dut.init_done_o), "IronMemory init sweep did not finish"
    # buffers: lower three quarters read/write for domains 0 and 1 EXCEPT the quarter [0xC000,0x10000) which domain 1 may only read
    assert await bm(dut, 1, 0, BASE, 0xC000, 0, 0b11, 0b11) == 0
    assert await bm(dut, 1, 1, BASE + 0xC000, 0x4000, 0, 0b11, 0b01) == 0
    mem = {}
    model = {}
    ports = [Port(dut, 0, rnd, mem, model), Port(dut, 1, rnd, mem, model)]
    exp = [[], []]
    zones = {0: [(0x0000, 0x4000), (0x8000, 0xB000), (0xC000, 0x10000)], 1: [(0x4000, 0x8000)]}
    def legality(r, port):
        """independent expectation: ALP legality precedence, then window decode, then buffer permission"""
        if r["op"] not in (OP_READ, OP_WRITE): return ST["BADOP"]
        if r["addr"] & 0xF: return ST["ALIGN"]
        if r["be"] == 0: return ST["BADBE"]
        off = r["addr"] - BASE
        if not (0 <= off < SIZE): return ST["DECODE"]
        if r["op"] == OP_WRITE and port == 1 and off >= 0xC000: return ST["DENIED"]
        return ST["OK"]

    for p in (0, 1):
        for i in range(260):
            kind = rnd.r.random()
            z = rnd.r.choice(zones[p])
            off = rnd.r.randrange(z[0], z[1], 16)
            op = OP_WRITE if rnd.r.random() < 0.55 else OP_READ
            be = rnd.r.choice([0xFFFF, 0xFFFF, 0x00FF, 0xFF00, 0x000F, 0x00F0, 0xF000, 0x0001, 0x8000, rnd.r.randint(1, 0xFFFF)])
            if op == OP_READ and rnd.r.random() < 0.6: be = 0xFFFF
            addr = BASE + off
            if p == 1 and rnd.r.random() < 0.2: addr, op = BASE + rnd.r.randrange(0xC000, 0x10000, 16), OP_WRITE   # write into the read-only quarter
            if kind < 0.07: op = rnd.r.choice([0, 3, 5, 15])
            elif kind < 0.13: addr += rnd.r.randint(1, 15)
            elif kind < 0.19: be = 0
            elif kind < 0.25: addr = BASE + SIZE + 16 * rnd.r.randint(0, 100)
            r = dict(op=op, tag=(i * 2 + p) & 0xFF, dom=p, addr=addr, be=be, data=rnd.r.getrandbits(128))
            ports[p].q.append(r)
            e = dict(r, status=legality(r, p))
            off = r["addr"] - BASE
            if e["status"] == ST["OK"] and op == OP_WRITE:
                for b in range(16):
                    if (be >> b) & 1: model[off + b] = (r["data"] >> (8 * b)) & 0xFF
            if e["status"] == ST["OK"] and op == OP_READ:
                w = 0
                for b in range(16):
                    if (be >> b) & 1: w |= model.get(off + b, 0) << (8 * b)
                e["rdata"] = w
            exp[p].append(e)
    await run(dut, ports, int(os.environ.get("CYCLES", "100000")), done=lambda: len(ports[0].done) == 260 and len(ports[1].done) == 260)
    nerr = 0
    for p in (0, 1):
        assert len(ports[p].done) == 260, "port %d: %d responses" % (p, len(ports[p].done))
        for (sent, tag, st, meta, data), e in zip(ports[p].done, exp[p]):
            assert tag == e["tag"], (p, "tag", tag, e)
            assert st == e["status"], (p, "status got", st, "expected", e["status"], "op", e["op"], "addr", hex(e["addr"]), "be", hex(e["be"]))
            assert meta == (0b10 | (e["op"] == OP_WRITE)), (p, "meta", meta, e)
            if st != 0 or e["op"] == OP_WRITE:
                assert data == 0, (p, "data must be zero", e)
            else:
                lanes = sum(0xFF << (8 * b) for b in range(16) if (e["be"] >> b) & 1)      # only the enabled lanes carry read data
                assert data & lanes == e["rdata"], (p, "read data %032x != %032x" % (data & lanes, e["rdata"]), e)
            nerr += st != 0
    dut._log.info("iron_alp: 520 transactions on 2 ports, %d refused / illegal answered with the right ALP status, data matched the model", nerr)
