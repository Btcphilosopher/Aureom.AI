"""AlbionForge unit-test harness (cocotb 1.9.2 + Verilator 5.020).

Every bus model is a pair of methods: drive() sets the DUT inputs for the coming rising edge (called on the falling edge),
sample() reads the settled outputs and updates the model with the handshakes that WILL happen on that rising edge.
All expected results are computed here, in Python, independently of the RTL.
"""
import random
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, Timer, RisingEdge

ST_OKAY, ST_DECODE, ST_DENIED, ST_BADOP, ST_BADBE, ST_ALIGN, ST_BADATTR, ST_TARGET = 0, 1, 2, 3, 4, 5, 6, 7
OP_READ, OP_WRITE = 1, 2
MASK128 = (1 << 128) - 1


def val(sig):
    v = sig.value
    return int(v) if v.is_resolvable else 0


async def reset(dut, rst="rst_ni", clk="clk_i", cycles=4):
    getattr(dut, rst).value = 0
    cocotb.start_soon(Clock(getattr(dut, clk), 10, units="ns").start())
    for _ in range(cycles):
        await RisingEdge(getattr(dut, clk))
    await FallingEdge(getattr(dut, clk))
    getattr(dut, rst).value = 1


async def run(dut, models, cycles, clk="clk_i", done=None):
    c = getattr(dut, clk)
    for n in range(cycles):
        await FallingEdge(c)
        for m in models:
            m.drive()
        await Timer(1, units="ns")
        for m in models:
            m.sample()
        if done is not None and done():
            return n
    return cycles


class Rand:
    def __init__(self, seed):
        self.r = random.Random(seed)

    def chance(self, pct):
        return self.r.random() * 100.0 < pct
