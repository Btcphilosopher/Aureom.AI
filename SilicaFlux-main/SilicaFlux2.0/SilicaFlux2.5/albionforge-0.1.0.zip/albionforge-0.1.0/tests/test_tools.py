"""pytest: tests of the build tooling itself (map validation, source lists, vendoring provenance, report schema, parsers).
The RTL is tested by tools/run_unit.py (cocotb) and tools/run_sims.py (system simulation)."""
import json, os, subprocess, sys, textwrap, shutil
import pytest, yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'tools'))


def run(*args, cwd=ROOT):
    return subprocess.run(list(args), cwd=cwd, capture_output=True, text=True)


def cfg_with(tmp_path, edit):
    cfg = yaml.safe_load(open(os.path.join(ROOT, 'config', 'albion_soc.yaml')))
    edit(cfg)
    p = tmp_path / 'cfg.yaml'
    p.write_text(yaml.safe_dump(cfg))
    return str(p)


def test_reference_map_is_legal():
    r = run(sys.executable, 'tools/gen_soc.py', '--validate-only')
    assert r.returncode == 0, r.stdout + r.stderr


def test_generated_files_are_fresh():
    r = run(sys.executable, 'tools/gen_soc.py', '--check')
    assert r.returncode == 0, r.stdout


@pytest.mark.parametrize('name,edit,needle', [
    ('overlap', lambda c: c['catalogue_extension'][0].update(base=0x1_1000_0000), 'illegal address map'),               # sram_ctl on top of sram
    ('legacy window', lambda c: c['catalogue_extension'][0].update(base=0x2000_0000), 'illegal address map'),           # inside the reserved 4 GiB
    ('misaligned', lambda c: c['catalogue_extension'][0].update(base=0x1_8000_0800), 'illegal address map'),
    ('not a power of two', lambda c: c['regions'].update(sram={'size': 0x18000}), 'illegal address map'),
    ('memory size mismatch', lambda c: c['iron'].update(depth=1024), 'capacity'),
    ('cc window overlap', lambda c: c['cc_windows'][1].update(cc_base=0x20000000), 'overlap'),
    ('cc window outside EXT', lambda c: c['cc_windows'][0].update(cc_base=0x10000000), 'outside the ControlCore EXT'),
    ('policy too big', lambda c: c['meridian'].update(CIT_NENT=2), 'boot policy needs'),
])
def test_illegal_maps_are_refused(tmp_path, name, edit, needle):
    r = run(sys.executable, 'tools/gen_soc.py', '--validate-only', '--config', cfg_with(tmp_path, edit))
    assert r.returncode != 0, name
    assert needle in (r.stdout + r.stderr), (name, r.stdout + r.stderr)


def test_srclist_orders_packages_first_and_resolves_everything(tmp_path):
    out = tmp_path / 'x.f'
    r = run(sys.executable, 'tools/srclist.py', '--top', 'sf_asoc_regtgt', '--roots', 'rtl/soc', 'ip/albioncore/rtl/albion', '--out', str(out))
    assert r.returncode == 0, r.stdout + r.stderr
    files = [l for l in out.read_text().splitlines() if l and not l.startswith(('//', '+'))]
    assert files[0].endswith('sf_albion_pkg.sv') and files[-1].endswith('sf_asoc_regtgt.sv')
    assert 'unresolved=0' in r.stdout


def test_srclist_reports_missing_modules(tmp_path):
    d = tmp_path / 'src'
    d.mkdir()
    (d / 'top.sv').write_text('module top;\n  nowhere u ();\nendmodule\n')
    r = run(sys.executable, 'tools/srclist.py', '--top', 'top', '--roots', str(d), '--out', str(tmp_path / 'a.f'))
    assert 'unresolved: nowhere' in r.stdout


def test_srclist_detects_package_cycles(tmp_path):
    d = tmp_path / 'src'
    d.mkdir()
    (d / 'a.sv').write_text('package pa; localparam int X = pb::Y; endpackage\n')
    (d / 'b.sv').write_text('package pb; localparam int Y = pa::X; endpackage\n')
    (d / 'c.sv').write_text('module top2; localparam int Z = pb::Y; endmodule\n')
    r = run(sys.executable, 'tools/srclist.py', '--top', 'top2', '--roots', str(d), '--out', str(tmp_path / 'a.f'))
    assert r.returncode != 0 and 'cycle' in (r.stdout + r.stderr)


def test_vendored_ip_matches_provenance():
    r = run(sys.executable, 'tools/vendor.py', '--verify', '--dest', 'ip')
    assert r.returncode == 0, r.stdout
    prov = json.load(open(os.path.join(ROOT, 'ip', 'PROVENANCE.json')))
    assert prov['meridian']['patched_files'] and prov['ironmemory']['patched_files']
    assert not prov['albioncore']['patched_files'] and not prov['clouddma']['patched_files'] and not prov['controlcore']['patched_files']


def test_vendor_verify_detects_tampering(tmp_path):
    shutil.copytree(os.path.join(ROOT, 'ip', 'albioncore', 'rtl'), tmp_path / 'ip' / 'albioncore' / 'rtl')
    shutil.copy(os.path.join(ROOT, 'ip', 'PROVENANCE.json'), tmp_path / 'ip' / 'PROVENANCE.json')
    prov = json.load(open(tmp_path / 'ip' / 'PROVENANCE.json'))
    # keep only the copied files in the record, then modify one
    prov = {'albioncore': {**prov['albioncore'], 'files': {k: v for k, v in prov['albioncore']['files'].items() if k.startswith('rtl/')}}}
    json.dump(prov, open(tmp_path / 'ip' / 'PROVENANCE.json', 'w'))
    target = tmp_path / 'ip' / 'albioncore' / 'rtl' / 'albion' / 'sf_albion_fifo.sv'
    target.write_text(target.read_text() + '\n// tampered\n')
    r = run(sys.executable, os.path.join(ROOT, 'tools', 'vendor.py'), '--verify', '--dest', str(tmp_path / 'ip'))
    assert r.returncode != 0 and 'MODIFIED outside the patch series' in r.stdout


def test_synth_stat_parser(tmp_path):
    import synth
    p = tmp_path / 's.txt'
    p.write_text(textwrap.dedent('''\
        === top ===

           Number of cells:                  12
             $adff_8                         3
             $adffe_32                       2
             $mem_v2                         1
             $and_1                          5
    '''))
    cells, _ = synth.parse_stat(str(p))
    assert cells == {'$adff_8': 3, '$adffe_32': 2, '$mem_v2': 1, '$and_1': 5}
    assert synth.flop_bits(cells) == 3 * 8 + 2 * 32


def test_firmware_header_matches_generated_map():
    h = open(os.path.join(ROOT, 'fw/include/albion_soc_map.h')).read()
    sv = open(os.path.join(ROOT, 'rtl/soc/gen/sf_asoc_cfg_pkg.sv')).read()
    assert 'ALB_SRAM_BASE        0x20000000u' in h and "R_SOC_PERF_DATA" in sv and 'ALB_SOC_PERF_DATA' in h


def test_report_schema_if_present():
    p = os.path.join(ROOT, 'reports', 'albion_report.json')
    if not os.path.exists(p):
        pytest.skip('report not generated yet')
    j = json.load(open(p))
    for k in ('summary', 'tests', 'performance', 'synthesis', 'tool_versions', 'known_limitations', 'next_actions', 'definition_of_done'):
        assert k in j
