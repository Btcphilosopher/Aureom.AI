# Test summary

45 of 45 test groups / runs pass.

| group | what | result | detail |
|---|---|---|---|
| lint | firmware -Wall -Wextra | PASS | 0 warnings |
| lint | generated SoC files are fresh | PASS | gen_soc --check: 0 stale file(s) |
| lint | python sources compile | PASS |  |
| lint | sf_iron_defs.svh == body of sf_iron_pkg | PASS | no drift |
| lint | vendored IP == archives + patch series | PASS | verify: 0 problem(s); 343 files recorded; patched files: {'albioncore': 0, 'clouddma': 0, 'controlcore': 0, 'ironmemory': 10, 'meridian': 6} |
| lint | verilator -Wall SoC top (STALL_PCT=0) | PASS | 0 warnings in project files, 0 in vendored IP |
| lint | verilator -Wall SoC top (STALL_PCT=25) | PASS | 0 warnings in project files, 0 in vendored IP |
| lint | verilator -Wall each glue module as a top | PASS | 11 modules checked |
| lint | yosys 0.33 elaboration + check -assert | PASS | rc=0 latches=0 unresolved=[] |
| unit (cocotb) | axi_init seed 3 | PASS |  |
| unit (cocotb) | axi_init seed 11 | PASS |  |
| unit (cocotb) | axi_init seed 29 | PASS |  |
| unit (cocotb) | axi_init seed 47 | PASS |  |
| unit (cocotb) | axi_init_stall40 seed 5 | PASS |  |
| unit (cocotb) | axi_init_stall40 seed 13 | PASS |  |
| unit (cocotb) | iron_alp seed 9 | PASS |  |
| unit (cocotb) | iron_alp seed 33 | PASS |  |
| unit (cocotb) | iron_alp seed 44 | PASS |  |
| unit (cocotb) | regtgt seed 7 | PASS |  |
| unit (cocotb) | regtgt seed 8 | PASS |  |
| unit (cocotb) | regtgt seed 9 | PASS |  |
| unit (cocotb) | sfb2_init seed 5 | PASS |  |
| unit (cocotb) | sfb2_init seed 6 | PASS |  |
| unit (cocotb) | sfb2_init seed 7 | PASS |  |
| tool tests (pytest) | 18 tests | PASS | 0 skipped |
| firmware | boot ROM rebuilt == RTL image | PASS | sha256 8e1e488b8348c37c |
| firmware | deterministic build, -Wall -Wextra clean | PASS | mkimage: ../build/fw/albion_fw.img 16468 B (25% of IMEM) entry 0x00010100 crc32 0x604b5fb2 |
| system simulation | 00_normal_s0 | PASS | cycles=1222924 fw=124/0 backdoor=11776/0 scoreboard=5195661 checks 0 errors |
| system simulation | 01_normal_s15 | PASS | cycles=1238616 fw=124/0 backdoor=11776/0 scoreboard=5267010 checks 0 errors |
| system simulation | 02_normal_s40 | PASS | cycles=1261451 fw=124/0 backdoor=11776/0 scoreboard=5372540 checks 0 errors |
| system simulation | 03_normal_s70 | PASS | cycles=1286913 fw=124/0 backdoor=11776/0 scoreboard=5491848 checks 0 errors |
| system simulation | 04_normal_s0_hostbp60 | PASS | cycles=1226714 fw=124/0 backdoor=11776/0 scoreboard=5210821 checks 0 errors |
| system simulation | 05_reset_mid_dma_s0_rst_at0 | PASS | cycles=1815028 fw=124/0 backdoor=11776/0 scoreboard=7591802 checks 0 errors |
| system simulation | 06_reset_mid_dma_s0_rst_at37 | PASS | cycles=1815065 fw=124/0 backdoor=11776/0 scoreboard=7592066 checks 0 errors |
| system simulation | 07_reset_mid_dma_s0_rst_at300 | PASS | cycles=1815328 fw=124/0 backdoor=11776/0 scoreboard=7594588 checks 0 errors |
| system simulation | 08_reset_mid_dma_s40_rst_at11 | PASS | cycles=1857451 fw=124/0 backdoor=11776/0 scoreboard=7786867 checks 0 errors |
| system simulation | 09_reset_early_s0_rst_at5 | PASS | cycles=1744095 fw=124/0 backdoor=11776/0 scoreboard=7280268 checks 0 errors |
| system simulation | 10_reset_async_s0_rst_at0 | PASS | cycles=1814828 fw=124/0 backdoor=11776/0 scoreboard=7591037 checks 0 errors |
| system simulation | 11_reset_async_s0_rst_at120 | PASS | cycles=1814948 fw=124/0 backdoor=11776/0 scoreboard=7592129 checks 0 errors |
| system simulation | 12_reset_async_s40_rst_at75 | PASS | cycles=1857130 fw=124/0 backdoor=11776/0 scoreboard=7785634 checks 0 errors |
| fpga wrapper simulation | boots firmware by itself (hardware loader + UART + LEDs) | PASS | TB FPGA RESULT PASS: leds=01001101 uart_result_seen=1 uart_pass=1 cycles=1333774 |
| mutation (glue) | 15 mutants | PASS | 15 killed, survivors: none |
| synthesis (yosys coarse) | coarse | PASS | {"flop_bits": 29008, "inferred_memories": 37, "memory_bits": 1528078, "seconds": 432.3, "word_level_cells": 31118} |
| synthesis (yosys elab) | elab | PASS | {"latches": 0, "seconds": 82.0, "unresolved_modules": []} |
| synthesis (yosys fpga) | fpga | PASS | {"bram": 103, "flops": 36851, "longest_path_cells": null, "luts": 978540, "seconds": null, "total_cells": 1036349} |
