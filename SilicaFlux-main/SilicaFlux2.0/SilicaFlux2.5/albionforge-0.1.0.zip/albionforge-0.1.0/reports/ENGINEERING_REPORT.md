# AlbionForge engineering report -- minimum Albion SoC

Generated 2026-11-16T11:06:12Z by `make albion-report` from the result files of the other targets (nothing below is typed in by hand except the limitations and next actions).

## 1. Result

The minimum Albion SoC (ControlCore -> Meridian -> IronMemory <- BridgeEngine/CloudDMA, host interface) builds, runs its cross-compiled firmware in RTL simulation, copies data by DMA through real SRAM, refuses unauthorised accesses and reports real counters; all of it is reproducible with make. Simulation and generic synthesis only: no hardware run.

**Definition of done: MET.**

| Definition-of-done item | met | evidence |
|---|---|---|
| builds successfully | yes | lint.json (all gates), firmware.json (boot ROM + firmware, deterministic), simulation / unit builds |
| executes compiled firmware in RTL simulation | yes | sim.json 00_normal_s0: real boot ROM validates the riscv64-unknown-elf-gcc image, firmware prints ALBION RESULT PASS (124 checks) |
| reads and writes real SRAM contents | yes | testbench backdoor compares 11776 SRAM bytes of IronMemory's banks with independently computed xorshift32 patterns: 0 mismatches; CPU word/half/byte stores incl. ECC read-modify-write checked by firmware and scoreboard |
| performs a real DMA transfer | yes | CloudDMA counters: 7017 bytes written, 7257 bytes read, 10 OK transactions; copies of 64 B .. 4 KiB incl. partial beats and a 2-element chain |
| preserves data | yes | scoreboard (5195661 checks, reference memory built from acknowledged writes) 0 data errors; DMA CRC-32 equals the firmware CRC-32; destination == source, guard bytes untouched |
| rejects unauthorised accesses | yes | six DMA refusal paths (unmapped IOVA, read-only mapping, wrong domain claim, buffer ownership, unmanaged memory, control window) + Citadel policy revocations in both directions; fabric security events: 6, DMA domain DENIED 5 times; scoreboard: the DMA link never got OKAY outside the SRAM window |
| produces real counters | yes | Meridian (96), IronMemory (per bank / port) and CloudDMA counters read by the firmware over the real register paths (see performance) |
| passes reproducible regression tests | yes | 13 system runs (back-pressure 0/15/40/70 %, host reset / async reset with transactions in flight), 15 unit runs, deterministic firmware image; every target re-runnable with `make albion-all` |

**Not claimed:** any FPGA / silicon frequency, area, power or bandwidth; any hardware run; security of the boot path. See section 8.

## 2. What was built

One SoC, assembled from the existing SilicaFlux IP (nothing replaced by a stand-in):

```
host (testbench BFM | sf_asoc_host_loader)  -- hs_* SFB2 -->  ControlCore P21 (RV32IM, boot ROM, I/D SRAM, mailbox)
                                            ext_* SFB2 | sf_asoc_sfb2_init (32->128 bit, window translation)   = ALP master 0, domain 0
CloudDMA P64 (BridgeEngine)  AXI4 -> sf_asoc_axi_init (burst -> ALP words, IDs, second-check refusals)       = ALP master 1, domain 1
                                            both -> sf_asoc_mer_core = Meridian P83 fabric (2 x 4, reference Citadel)
        targets: t0 sram -> IronMemory P84 (ECC, 2 ports, buffer manager)   t1 sram_ctl (IronMemory CSRs + buffer-manager shim)
                 t2 dma -> CloudDMA CSRs + submission + permission-table shim   t3 soc_ctl (Citadel policy, Meridian counters / error log)
```

The shared transaction contract is **ALP v1** (AlbionCore): 64-bit address, 128-bit data, 8-bit tag / domain / attributes, in-order completion. Every IP boundary is converted to and from it by a glue module (docs/ARCHITECTURE.md). The generated memory map: docs/MEMORY_MAP_SOC.md. Domains are bound by hardware at each master port.

## 3. Audit (priority 1)

The SilicaFlux work lives in 164 nested archives holding 6863 HDL files (1955 distinct module / package names; 1144 declared in more than one archive, 168 with divergent bodies) -- nothing in the repository tree is directly buildable. The curated, measured manifest of the 97 source files the SoC compiles is `audit/MANIFEST.md` / `audit/manifest.json`.

### Integration problems found and resolved

| id | problem | resolution |
|---|---|---|
| IP-01 | Meridian does not lint under Verilator 5.020 | patches/meridian/0002 (blocking clear); regression re-run: 15 tests, 114,721 checks PASS |
| IP-02 | Meridian and IronMemory do not parse with Yosys 0.33 (the tool every other SilicaFlux flow and AlbionCore pin) | patches/meridian/0001, patches/ironmemory/0001 (casts, assignments to the function name, include file with the package body); IronMemory's own regression: identical 213,697 checks before and after |
| IP-03 | THREE incompatible Albion transaction formats and one non-Albion bus in the same repository | ALP v1 is the SoC contract: five glue modules convert at every IP boundary (sf_asoc_sfb2_init, sf_asoc_axi_init, sf_asoc_mer_core, sf_asoc_mer_tgt, sf_asoc_iron_port); every conversion is unit tested against an independent Python model |
| IP-04 | Data width mismatch: ALP 128 bit vs ControlCore 32 bit vs IronMemory 64 bit | AlbionCore width adapter UPSIZE 32 -> 128 in the CPU bridge and DOWNSIZE 128 -> 64 in front of IronMemory (one wide transaction in flight per port: ~1 byte/cycle, stated in docs/PERFORMANCE.md) |
| IP-05 | Meridian narrows the information an ALP request carries | domain, privilege and QoS are hardware-bound at the initiator adapters and stamped from config; domains >= 8 and reserved opcodes are forwarded as the reserved opcode and answered PROTOCOL_ERR; the narrowing is documented as limitations L-06 / L-07 |
| IP-06 | CloudDMA cannot be started by software | sf_asoc_dma_ctl: SUBMIT_* registers (the command DOMAIN is a module parameter, never a register), DONE_* capture, PTBL_* programming port; reachable only by the ControlCore domain (Citadel policy) |
| IP-07 | IronMemory's buffer-manager command port has no register interface and needs a hardware-sourced requester | sf_asoc_iron_ctl: requester = the domain of the access that wrote BM_GO (verified by Meridian at the master port) |
| IP-08 | Address-map collision: ControlCore EXT window (0x2000_0000..0x3FFF_FFFF, 32-bit) vs the Albion 64-bit map | config/albion_soc.yaml: sram_ctl region added to the catalogue (checked by AlbionCore's own collision checker, 8 negative tests); generated window table SFB2 -> ALP; generated C / SV / Markdown from one source |
| IP-09 | Reset inconsistency risk: ControlCore resets itself (soft / watchdog / host) but the rest of the SoC would not | fabric, memory, DMA and bridges run in the ControlCore-derived `acc_rst_no` domain; 5 reset scenarios (host reset and asynchronous reset with 1..5 transactions in flight) pass with no stale response |
| IP-10 | Invalid / unrepresentable transaction fields | tags: free-running counters checked on every response; AXI IDs kept in the in-order queue; unrepresentable domains become the reserved opcode (PROTOCOL_ERR) |
| IP-11 | Read / write handshake errors found by the independent models | both fixed in the new glue before they could reach the IP; regression tests kept |
| IP-12 | Package conflicts | the SoC imports none of the divergent packages; every package comes from exactly one archive (srclist.py refuses a name declared in two files) |

### Major IP that does not exist (not faked)

| item | handling |
|---|---|
| Citadel (protection / policy unit) | No module with this name or function exists in the repository; Meridian ships a REFERENCE policy table. NOT replaced by anything pretending to be a Citadel: the SoC uses the reference table, programmed by a hardware boot loader + firmware. |
| IOMMU | None exists. CloudDMA's simulation permission table is used (a verified model of isolation, not hardware isolation by itself). |
| BridgeEngine as a named block | Does not exist; it is CloudDMA (P64) + the AXI bridge + sf_asoc_dma_ctl (as the Meridian audit maps it). |
| ControlCore accelerators (vector tile, tensor unit) | Not part of the minimum SoC; their register pages answer a bus error. |
| Interrupt wiring from DMA / memory to the CPU | Not implemented; firmware polls. The two interrupt lines feed the RAS SoC-warning input only. |
| Real host interface (PCIe / HostLink) | Not part of the minimum SoC; the Host Simulation Interface is a testbench BFM and a hardware twin (sf_asoc_host_loader) that loads the firmware. |
| External memory | IronMemory supports it; it is not connected (EXT_EN = 0). |

## 4. Verification

Independent expected results: xorshift32 patterns recomputed by the testbench; a byte-accurate reference memory built by the scoreboard from acknowledged writes; Python models in the cocotb tests; the DMA CRC-32 against the firmware's own CRC-32.

| group | what | result | detail |
|---|---|---|---|
| lint | firmware -Wall -Wextra | PASS | 0 warnings |
| lint | generated SoC files are fresh | PASS | gen_soc --check: 0 stale file(s) |
| lint | python sources compile | PASS |  |
| lint | sf_iron_defs.svh == body of sf_iron_pkg | PASS | no drift |
| lint | vendored IP == archives + patch series | PASS | verify: 0 problem(s); 343 files recorded; patched files: {'albioncore': 0, 'clouddma': 0, 'controlcore': 0, 'ironmemory': 10, 'meridian': 6} |
| lint | verilator -Wall SoC top (STALL_PCT=0) | PASS | 0 warnings in project files, 0 in vendored IP |
| lint | verilator -Wall SoC top (STALL_PCT=25) | PASS | 0 warnings in project files, 0 in vendored IP |
| lint | verilator -Wall each glue module as a top | PASS | 11 modules checked |
| lint | yosys 0.33 elaboration + check -assert | PASS | rc=0 latches=0 unresolved=[] |
| unit (cocotb) | axi_init seed 3 | PASS |  |
| unit (cocotb) | axi_init seed 11 | PASS |  |
| unit (cocotb) | axi_init seed 29 | PASS |  |
| unit (cocotb) | axi_init seed 47 | PASS |  |
| unit (cocotb) | axi_init_stall40 seed 5 | PASS |  |
| unit (cocotb) | axi_init_stall40 seed 13 | PASS |  |
| unit (cocotb) | iron_alp seed 9 | PASS |  |
| unit (cocotb) | iron_alp seed 33 | PASS |  |
| unit (cocotb) | iron_alp seed 44 | PASS |  |
| unit (cocotb) | regtgt seed 7 | PASS |  |
| unit (cocotb) | regtgt seed 8 | PASS |  |
| unit (cocotb) | regtgt seed 9 | PASS |  |
| unit (cocotb) | sfb2_init seed 5 | PASS |  |
| unit (cocotb) | sfb2_init seed 6 | PASS |  |
| unit (cocotb) | sfb2_init seed 7 | PASS |  |
| tool tests (pytest) | 18 tests | PASS | 0 skipped |
| firmware | boot ROM rebuilt == RTL image | PASS | sha256 8e1e488b8348c37c |
| firmware | deterministic build, -Wall -Wextra clean | PASS | mkimage: ../build/fw/albion_fw.img 16468 B (25% of IMEM) entry 0x00010100 crc32 0x604b5fb2 |
| system simulation | 00_normal_s0 | PASS | cycles=1222924 fw=124/0 backdoor=11776/0 scoreboard=5195661 checks 0 errors |
| system simulation | 01_normal_s15 | PASS | cycles=1238616 fw=124/0 backdoor=11776/0 scoreboard=5267010 checks 0 errors |
| system simulation | 02_normal_s40 | PASS | cycles=1261451 fw=124/0 backdoor=11776/0 scoreboard=5372540 checks 0 errors |
| system simulation | 03_normal_s70 | PASS | cycles=1286913 fw=124/0 backdoor=11776/0 scoreboard=5491848 checks 0 errors |
| system simulation | 04_normal_s0_hostbp60 | PASS | cycles=1226714 fw=124/0 backdoor=11776/0 scoreboard=5210821 checks 0 errors |
| system simulation | 05_reset_mid_dma_s0_rst_at0 | PASS | cycles=1815028 fw=124/0 backdoor=11776/0 scoreboard=7591802 checks 0 errors |
| system simulation | 06_reset_mid_dma_s0_rst_at37 | PASS | cycles=1815065 fw=124/0 backdoor=11776/0 scoreboard=7592066 checks 0 errors |
| system simulation | 07_reset_mid_dma_s0_rst_at300 | PASS | cycles=1815328 fw=124/0 backdoor=11776/0 scoreboard=7594588 checks 0 errors |
| system simulation | 08_reset_mid_dma_s40_rst_at11 | PASS | cycles=1857451 fw=124/0 backdoor=11776/0 scoreboard=7786867 checks 0 errors |
| system simulation | 09_reset_early_s0_rst_at5 | PASS | cycles=1744095 fw=124/0 backdoor=11776/0 scoreboard=7280268 checks 0 errors |
| system simulation | 10_reset_async_s0_rst_at0 | PASS | cycles=1814828 fw=124/0 backdoor=11776/0 scoreboard=7591037 checks 0 errors |
| system simulation | 11_reset_async_s0_rst_at120 | PASS | cycles=1814948 fw=124/0 backdoor=11776/0 scoreboard=7592129 checks 0 errors |
| system simulation | 12_reset_async_s40_rst_at75 | PASS | cycles=1857130 fw=124/0 backdoor=11776/0 scoreboard=7785634 checks 0 errors |
| fpga wrapper simulation | boots firmware by itself (hardware loader + UART + LEDs) | PASS | TB FPGA RESULT PASS: leds=01001101 uart_result_seen=1 uart_pass=1 cycles=1333774 |
| mutation (glue) | 15 mutants | PASS | 15 killed, survivors: none |
| synthesis (yosys coarse) | coarse | PASS | {"flop_bits": 29008, "inferred_memories": 37, "memory_bits": 1528078, "seconds": 432.3, "word_level_cells": 31118} |
| synthesis (yosys elab) | elab | PASS | {"latches": 0, "seconds": 82.0, "unresolved_modules": []} |
| synthesis (yosys fpga) | fpga | PASS | {"bram": 103, "flops": 36851, "longest_path_cells": null, "luts": 978540, "seconds": null, "total_cells": 1036349} |

45 of 45 checks pass.

## 5. Performance (priority 6)

run 00_normal_s0 (STALL_PCT=0, no host back-pressure), RTL simulation cycles of a 10 ns clock; NO silicon / FPGA claim

**Not a bandwidth claim**: simulated cycles of a 10 ns testbench clock.

| DMA copy of | completion latency (cycles, submit -> done) | copy bytes / cycle | link bytes / cycle (read + write) |
|---|---|---|---|
| 64 B | 125 | 0.512 | 1.024 |
| 256 B | 311 | 0.823 | 1.646 |
| 1024 B | 1081 | 0.947 | 1.895 |
| 4096 B | 4153 | 0.986 | 1.973 |

Total simulated cycles of the full run (boot ROM, image load, firmware self-test): 1222924; the firmware self-test itself took 700848 CPU cycles.

| memory access latency (cycles) | reads (mean / min / max) | writes (mean / min / max) |
|---|---|---|
| cpu_link | 9.14 / 1 / 12 | 8.94 / 6 / 12 |
| dma_link | 33.79 / 8 / 40 | 36.69 / 1 / 40 |

request accepted at the Meridian master port -> response accepted, measured by the testbench scoreboard (includes the fabric, the 128->64 adaptation and IronMemory RL+3); the DMA link includes queueing behind its own earlier words

| counter | value |
|---|---|
| dma_bytes_transferred.read | 7257 |
| dma_bytes_transferred.written | 7017 |
| dma_bytes_transferred.bursts_ok | 10 |
| dma_bytes_transferred.bursts_error | 8 |
| arbitration_stalls.meridian_total | 6086 |
| arbitration_stalls.meridian_target0 | 6086 |
| arbitration_stalls.dma_master_stall_in | 5772 |
| arbitration_stalls.iron_bank_wait_p0 | 20 |
| arbitration_stalls.iron_bank_wait_p1 | 4 |
| arbitration_stalls.iron_conflict_losses | 0 |
| busy_cycles.meridian_busy | 190708 |
| busy_cycles.meridian_cycles | 1167510 |
| busy_cycles.dma_active | 8245 |
| busy_cycles.iron_bank_busy_sum_of_4_banks | 34252 |
| busy_cycles.iron_rmw_operations | 12143 |
| fabric_traffic.requests | 21407 |
| fabric_traffic.completions | 21408 |
| fabric_traffic.payload_bytes | 174293 |
| fabric_traffic.denied_cpu | 1 |
| fabric_traffic.denied_dma | 5 |
| fabric_traffic.security_events | 6 |
| fabric_traffic.error_log_entries | 5 |

Sensitivity to random back-pressure (same firmware):

| STALL_PCT | testbench cycles |
|---|---|
| 0 | 1222924 |
| 15 | 1238616 |
| 40 | 1261451 |
| 70 | 1286913 |

Why only about 1 byte per cycle: see limitation L-08 (128 -> 64-bit adaptation, one wide transaction at a time per port).

## 6. Hardware readiness (priority 7)

Hardware readiness = what real synthesis says. It does NOT claim the design has run on hardware.

* **Elaboration (Yosys 0.33, `proc; check -assert`)**: 0 latches, unresolved modules / black boxes: none, 0 warnings (memory-to-register notices only).
* **Word-level synthesis (flattened)**: 31118 cells, 29008 flip-flop bits outside memories, **37 inferred memories, 1528078 memory bits** (kept as memories).
* Longest word-level topological path of the flattened SoC (each operator counts 1; before ABC, so **not** a LUT depth or a frequency): 302 operators, running through `sfdma_crc.sv`.

Largest inferred memories:

| words | width | bits | cell |
|---|---|---|---|
| 16384 | 36 | 589824 | u_cc.u_imem.u_sram.u_array.g_generic.u_mem.mem |
| 8192 | 36 | 294912 | u_cc.u_dmem.u_sram.u_array.g_generic.u_mem.mem |
| 2048 | 72 | 147456 | u_iron.u_iron.g_bank[0].u_bank.genblk1.g_fpga.u_sram.ram |
| 2048 | 72 | 147456 | u_iron.u_iron.g_bank[1].u_bank.genblk1.g_fpga.u_sram.ram |
| 2048 | 72 | 147456 | u_iron.u_iron.g_bank[2].u_bank.genblk1.g_fpga.u_sram.ram |
| 2048 | 72 | 147456 | u_iron.u_iron.g_bank[3].u_bank.genblk1.g_fpga.u_sram.ram |
| 1024 | 32 | 32768 | $flatten\u_cc.\u_rom.\u_img.$auto$proc_rom.cc:150:do_switch$42095 |
| 1024 | 8 | 8192 | u_dma.g_ch[0].u_ch.u_bc.u_buf.mem |
| 32 | 96 | 3072 | u_dma.u_trace.u_f.mem |
| 256 | 8 | 2048 | u_cc.u_mbox.fifo_q |

* **FPGA-primitive mapping (`synth_ecp5`, hierarchical: synth_ecp5 -noflatten -run begin:check (stops before the memory-hungry autoname pass), totals from stat -top; generic stand-in, no P&R, not a device-utilisation figure)**: 978540 LUT-class cells (LUT4 + PFUMX + L6MUX21), 36851 flip-flops (TRELLIS_FF), 103 DP16KD block RAMs, 880 distributed-RAM (TRELLIS_DPR16X4) cells, 19971 carry cells, 4 MULT18X18D (1036349 cells total).
* Longest path of the mapped netlist: not reported (not measured on the mapped netlist: ltp reports false loops through un-flattened hierarchy (it wrote 7 GB) and a flattened mapping does not fit in 16 GB).

Largest modules in the mapping (own cells, per module definition):

| module | cells | share of all cells | LUT-class | flip-flops | DP16KD | dist. RAM |
|---|---|---|---|---|---|---|
| sfdma_bytebuf | 777425 | 75.0 % | 769014 | 8192 | 0 | 0 |
| sf_iron_memory | 29564 | 2.9 % | 25223 | 2807 | 0 | 0 |
| sf_meridian_citadel_ref | 25551 | 2.5 % | 24348 | 1136 | 0 | 0 |
| sf_iron_buffer_manager | 23509 | 2.3 % | 12555 | 2031 | 0 | 0 |
| sfdma_perf | 15776 | 1.5 % | 13358 | 1600 | 0 | 0 |
| sf_meridian_perf | 13076 | 1.3 % | 8871 | 2652 | 0 | 0 |
| sfdma_perm_table | 12812 | 1.2 % | 8835 | 2192 | 0 | 0 |
| sf_meridian_mport | 12779 | 1.2 % | 10962 | 1471 | 0 | 0 |
* Timing assumptions: none verified: one clock; every register is a clocked flop with asynchronous-assert / synchronous-release reset; no timing constraints, no timing analysis, no place-and-route; the only depth figure is the word-level (pre-ABC) one above, which is not a LUT depth.
* Board-neutral wrapper: `rtl/fpga/sf_albion_fpga_top.sv` -- boots the firmware by itself in simulation (loader done, test done, no fail, UART result PASS)

Tool limitations:

* Yosys 0.33 (apt) - no SystemVerilog interface / package-import support: the IP was patched (patches/), the glue follows the AlbionCore NAMING_RULES
* synth_ecp5 is used as a stand-in technology; no vendor tool was run
* no SymbiYosys; no timing analysis (nextpnr / OpenSTA not run)
* synth_ecp5 on the FPGA wrapper is memory-bound in Yosys 0.33: a flattened and a hierarchical run were each killed by the 16 GB limit (about 14 GB resident, measured) in the final autoname pass; the reported mapping is hierarchical (-noflatten) and stops before autoname (-run begin:check). The longest path of the mapped netlist is NOT reported (ltp finds false loops through un-flattened hierarchy)
* memories: inferred as $mem cells (4 x 2048 x 72 IronMemory banks, ControlCore I / D SRAM with parity, FIFOs); mapping to block RAM is the board flow's decision

## 7. Reproducibility

Tools: verilator 5.020, yosys 0.33, iverilog 12.0, riscv_gcc 13.2.0, riscv_objcopy 2.42, python 3.13, cocotb 1.9.2, pytest 9.2.0, pyyaml 6.0.3, z3 4.8.12, make 4.3. Build manifest with SHA-256 of every project source, IP provenance and artefacts: `reports/BUILD_MANIFEST.json`.

```
make albion-all   # doctor, lint, test, firmware, sim, synth, report
```

## 8. Known limitations

| id | limitation | detail |
|---|---|---|
| L-01 | Simulation and generic synthesis only | Nothing has run on a board. No place-and-route, timing closure, power or silicon result exists. The synthesis figures are Yosys technology-mapping estimates (a generic ECP5 LUT4 library as a stand-in for "an FPGA"); the longest-path figure is a topological LUT depth, not a frequency. |
| L-02 | Simulated cycle counts are not bandwidth | Bytes per cycle are measured in RTL simulation cycles. They say nothing about FPGA or silicon bandwidth: that needs a clock the implementation actually reaches and a memory that behaves like the model. |
| L-03 | The Citadel is a reference model | The repository contains no Citadel. Meridian's sf_meridian_citadel_ref (a default-deny table) enforces the policy; a hardware boot loader writes the generated boot policy after reset and the ControlCore firmware may rewrite it. This is configuration, not a security product. |
| L-04 | DMA isolation uses CloudDMA's simulation permission table | There is no IOMMU in the repository. The permission table is a verified MODEL of isolation; real isolation also needs the platform properties listed in CloudDMA docs/03_PROTECTION.md (single memory path, hardware-bound domains: both hold in this SoC by construction, but are not formally proven). |
| L-05 | No interrupts from the DMA / memory to the CPU | Firmware polls. IronMemory and CloudDMA interrupt lines feed only the RAS "SoC warning" input. Accelerator pages 8..15 of the ControlCore answer a bus error. |
| L-06 | Meridian drops ALP attribute bits | secure, instr and mem_type do not cross the fabric (only priv and a 2-bit QoS class do). Region access rules are therefore enforced by the Citadel table (domain / source / privilege / read / write), not by sf_access_check_bits. |
| L-07 | Status detail narrows across the fabric | Meridian targets may answer only OKAY or SLVERR: an IronMemory ownership refusal (ALP ACCESS_DENIED) or ECC error reaches the initiator as TARGET_ERR. Fabric-generated statuses (DENIED, DECODE_ERR, TIMEOUT, PROTOCOL_ERR) are preserved. IronMemory's CSRs / counters still say what happened. |
| L-08 | Throughput is limited by the 128 -> 64-bit adaptation | IronMemory is verified at 64 bit only; the AlbionCore downsizing adapter handles ONE wide transaction at a time per port, so a 16-byte word costs two memory beats plus handshake: about 1 byte per cycle of copy bandwidth (2 bytes per cycle on the link). CloudDMA alone sustains 8 B/cycle at 64-bit width. Raising it means verifying IronMemory at 128 bit or pipelining the adapter (next action NA-03). |
| L-09 | Formal verification and mutation of the vendored IP were not re-run | SymbiYosys is not installable here; AlbionCore's ABC-PDR proofs and the IP projects' own mutation campaigns were not repeated. The NEW glue has simulation evidence (cocotb unit tests against independent models, system scoreboard) and a 15-mutant check (reports/mutation.json), but no proof. |
| L-10 | Single clock, no CDC, clock gating unused | ControlCore's gated accelerator clock is ignored; the fabric domain is the ControlCore-derived reset domain only. A multi-clock SoC needs the AlbionCore CDC primitives and a CDC review. |
| L-11 | Small configuration | 64 KiB shared SRAM (4 banks x 2048 x 64 bit + ECC), one DMA channel, two Meridian masters, four targets, 8 Citadel entries (5 used). Larger configurations are parameters but only this one was verified. |
| L-12 | Firmware is integrity-checked, not authenticated | CRC-32 only (ControlCore limitation, documented by that project); the hardware image loader inherits this. Do not treat the boot path as secure boot. |
| L-13 | Device-memory boot and the ControlCore accelerators are unsupported | boot_mode 1 needs a 1 MiB device window at 0x200F_0000; this SoC has a 64 KiB SRAM. Boot is host-load (testbench or sf_asoc_host_loader). |
| L-14 | The FPGA wrapper has never met a board | Board-neutral by construction (one clock, one reset, a UART pin, LEDs) and verified in simulation (it boots the real firmware by itself); pin assignments, clocking, block-RAM mapping of the SRAMs and timing are the board project's job (docs/FPGA.md). |
| L-15 | Test coverage is directed + constrained-random, not exhaustive | Scenario matrix: 4 back-pressure levels, 5 reset instants, 1 firmware. Two initiators only; no multi-channel DMA, no ECC fault injection through the SoC (IronMemory's own tests cover ECC), no error injection on the AXI side beyond the refusal paths. |
| L-16 | CloudDMA's data buffer is a flop array | sfdma_bytebuf (1 KiB per channel) has a combinational read of sixteen byte lanes and sixteen write ports, so it is built from flip-flops and wide multiplexers, not block RAM. In the reference synthesis it is 75 % of all mapped cells (section 6, largest modules) and the reason a generic FPGA mapping of the SoC is about a million cells and does not fit a small device. Functionally correct (verified); not area-efficient. |

## 9. Next engineering actions

| id | action | detail |
|---|---|---|
| NA-01 | Place-and-route the wrapper for one real FPGA and read the real critical path | Pick a board with enough block RAM for 64 KiB + ECC + the ControlCore SRAMs, constrain the clock, close timing, then run the wrapper on the board. Until then no frequency or resource claim is possible. |
| NA-02 | Replace the reference Citadel and the DMA permission table with real IP | Write (or locate) a Citadel that implements the check port of Meridian docs/meridian/03_ACCESS_CONTROL.md, and an IOMMU for CloudDMA's iommu_* interface; re-run the refusal tests (firmware t_dma_perm / t_policy) unchanged. |
| NA-03 | Lift the ~1 byte/cycle copy ceiling | Verify IronMemory at DW = 128 (the IP states support, its tests run at 64 only) and drop the downsizing adapter, or give the adapter MAX_OUT > 1 pipelining; re-measure with the same sweep (firmware t_dma_sweep, link scoreboard). |
| NA-04 | Interrupts | Route CloudDMA done/error and IronMemory UE/violation lines to ControlCore interrupt sources (the vector / tensor lines are free in this SoC) and replace the polling; extend the firmware with handlers and the testbench with an interrupt-latency measurement. |
| NA-05 | Carry ALP attributes and status through Meridian | Add a user sideband (attr: secure / instr / mem_type) and a wider target status to Meridian (RTL + its regression + mutants), then enforce sf_access_check_bits at the targets as AlbionCore intends. |
| NA-06 | Formal and mutation evidence for the glue | Install SymbiYosys (or run Yosys smtbmc directly) and prove the ALP handshake rules of the five bridges (valid held, in-order, no loss) with unbounded proofs where the state space allows; grow tools/mutate.py to cover sf_asoc_mer_tgt / mer_core / soc_ctl / dma_ctl registers with dedicated unit benches. |
| NA-07 | Second DMA channel and a larger SRAM | Exercise NUM_CH = 2 (CloudDMA is verified up to 8) through Meridian master 2 with its own domain, and scale the IronMemory banks; re-run the scoreboard under contention and the arbitration-fairness checks of Meridian. |
| NA-08 | Accelerator integration | Connect the ControlCore accelerator pages 8..15 (HPC tile / tensor unit from the repository) as additional Meridian targets and masters using the same ALP adapters, keeping the firmware self-test as the regression. |
| NA-09 | Upstream the IP fixes | The Meridian (patches 0001/0002) and IronMemory (0001) fixes belong in their projects: apply them there, re-run those projects' own regressions and mutation campaigns, and drop the patch series here. |
| NA-10 | Licence and provenance | The repository has no licence file; ip/PROVENANCE.json records the source archive and SHA-256 of every vendored file. Decide the licence before publishing the project. |
| NA-11 | Re-architect the DMA data buffer for block RAM | Replace sfdma_bytebuf by a registered-read, lane-banked memory (one RAM per byte lane, rotate on the read side) so the buffer maps to block RAM / a macro; re-run the CloudDMA regression, the system matrix and the synthesis stage, and compare LUT / flip-flop figures with the ones in this report. |
