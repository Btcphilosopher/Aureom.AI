# AlbionForge -- the minimum Albion SoC: integration, build and verification foundation

SilicaFlux Albion / Aureom.AI.  This project turns the SilicaFlux Albion IP that already exists in the repository into **one buildable, executable,
verifiable minimum cloud processor**:

```
host --> ControlCore (RV32IM) --> Meridian fabric --> IronMemory (ECC SRAM)
                  CloudDMA ("BridgeEngine") ---^
```

It runs real firmware (cross-compiled with `riscv64-unknown-elf-gcc`) on the RTL in simulation: boot, SRAM controller initialisation, DMA configuration, issue,
completion wait, data check, performance counters, PASS / FAIL.  Nothing was committed to GitHub; this archive is the deliverable.

**Read first:** `reports/ENGINEERING_REPORT.md` (results, audit, tests, performance, synthesis, limitations, next actions) and `audit/MANIFEST.md` (the audit).

## Status in one paragraph

Built, linted, unit-tested (cocotb, independent Python models), simulated (real boot ROM + real firmware; scoreboard, SRAM backdoor, random back-pressure,
host / asynchronous reset with transactions in flight), synthesised with Yosys (elaboration, inferred memories, FPGA-primitive mapping).
**Simulation and generic synthesis only: nothing has run on a board; no frequency, area, power or bandwidth claim is made** (`reports/KNOWN_LIMITATIONS.md`).
The Citadel and the IOMMU do not exist in the repository: Meridian's reference policy table and CloudDMA's simulation permission table are used and labelled as such.

## What is where

| path | content |
|---|---|
| `rtl/soc/` | **new**: the SoC top `sf_albion_soc_min` and the glue that converts every IP to the shared ALP v1 contract (10 modules + a verification-only back-pressure gate); `gen/` is generated |
| `rtl/fpga/` | board-neutral FPGA wrapper + hardware image loader (the synthesizable twin of the Host Simulation Interface) |
| `ip/` | the existing SilicaFlux IP vendored from the repository archives (AlbionCore, Meridian, IronMemory, CloudDMA, ControlCore), `PROVENANCE.json` = archive + SHA-256 of every file; **fixes are explicit patches** in `patches/` (Meridian x2, IronMemory x1) |
| `fw/` | firmware: self-test of the SoC (`app/albion_main.c`), platform layer derived from ControlCore's, generated map header |
| `tb/`, `tests/` | system testbench / Host Simulation Interface / scoreboard; cocotb unit tests; pytest tool tests |
| `config/albion_soc.yaml` | the one configuration: address map, Meridian parameters, Citadel boot policy, ControlCore window table, IP parameters, tool pins |
| `tools/` | doctor, generators, dependency-aware source lists, vendoring, lint / test / sim / synth / report drivers, mutation check, audit scripts |
| `audit/` | inventory of all 6,863 HDL files in the repository archives, the measured + curated manifest of the 97 files the SoC compiles, baseline logs of the IP's own flows |
| `docs/` | architecture, build, verification, performance method, FPGA wrapper, limitations; `MEMORY_MAP_SOC.md` is generated |
| `reports/`, `results/` | generated engineering report, JSON results, test summary, build manifest; the raw results they were made from |

## Quick start

```bash
sudo apt-get install -y make build-essential python3 python3-yaml python3-pip verilator yosys iverilog z3 gcc-riscv64-unknown-elf binutils-riscv64-unknown-elf
pip install "cocotb==1.9.2" pytest pyyaml
make albion-lint        # static gates
make albion-test        # RTL unit tests + tool tests
make albion-firmware    # boot ROM rebuild + firmware image (deterministic)
make albion-sim         # system simulation matrix (needs the firmware)
make albion-synth       # Yosys synthesis (slow)
make albion-report      # reports/
```

Every target performs real work with the real tools; see `docs/BUILD.md`.  Tested with Verilator 5.020, Yosys 0.33, GNU RISC-V gcc 13.2.0, cocotb 1.9.2, Python 3.13.

## What the existing IP needed (audit highlights)

* Meridian does not lint under Verilator 5.020 and, like IronMemory, does not parse under Yosys 0.33 (the tool every other SilicaFlux flow is pinned to): fixed by patches; each project's own regression gives identical results before and after.
* Five incompatible bus / transaction formats had to be reconciled (ALP v1, Meridian, IronMemory, SFB2, AXI4): converted at every boundary, each conversion unit-tested against an independent model.
* CloudDMA could not be started by software, IronMemory's buffer manager had no register interface, the ControlCore's 32-bit windows collided with the Albion 64-bit map: interfaces written in `rtl/soc/`, map generated and checked with AlbionCore's own collision checker.
* Defects found by the independent models while building: lane taken from the address in the register bridge; lost DECERR class on write bursts (both fixed in the new glue).

## Licence and provenance

The repository has no licence file; none is added here.  `ip/PROVENANCE.json` records where every vendored byte came from.  Decide the licence before publishing.
