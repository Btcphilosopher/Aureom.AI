// =============================================================================
// AlbionForge :: sf_albion_fpga_top -- BOARD-NEUTRAL integration wrapper of the minimum Albion SoC
//
// Contains no pin, PLL, clock-gate, memory-macro or vendor primitive.  A board project supplies: a clock of CLK_HZ, an
// asynchronous active-low reset input (push button / power-good), a UART TX pin, LEDs; it constrains the clock and maps these
// five ports.  The wrapper adds only what a board needs and the SoC deliberately does not contain:
//   * reset: asynchronous assert, SYNCHRONOUS release (2-flop) -> the single `rst_ni` of the SoC;
//   * image loader: sf_asoc_host_loader (ROM <- IMAGE_FILE) boots the firmware through ControlCore's host port, no external host;
//   * console: ControlCore's DIAG_TX character stream -> 256-byte FIFO -> UART 8N1 at BAUD;
//   * status LEDs: heartbeat, loader done / error, firmware test DONE / FAIL, RAS fatal, CPU sleep, IronMemory init done.
// Status    Simulated (tb/tb_fpga_top.sv boots the real firmware through this wrapper).  Synthesised with Yosys.  NEVER run on a
//           board: no place-and-route, no timing closure, no hardware result exists.  See docs/FPGA.md for the assumptions a
//           board bring-up must verify (clock frequency vs the unconstrained critical path, block-RAM mapping of the SRAMs).
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sf_albion_fpga_top #(
  parameter int     CLK_HZ     = 25_000_000,
  parameter int     BAUD       = 115_200,
  parameter         IMAGE_FILE = "build/fw/albion_fw.hex",
  parameter int     IMG_WORDS  = 8192,
  parameter int     CON_DEPTH  = 16384            // console FIFO bytes: the firmware prints ~10 KB at 100 MHz-class speed, the UART drains it slowly
) (
  input  wire logic       clk_i,
  input  wire logic       rst_ni,            // asynchronous, active low
  output logic            uart_tx_o,         // console, idle high
  output logic [7:0]      led_o              // [7] heartbeat [6] cpu sleep [5] ras fatal [4] test fail [3] test done [2] iron init [1] loader err [0] loader done
);
  localparam int BAUD_DIV = CLK_HZ / BAUD;

  // ---- reset synchroniser (asynchronous assert, synchronous release)
  logic [1:0] rs_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) rs_q <= 2'b00; else rs_q <= {rs_q[0], 1'b1};
  end
  wire rst_n = rs_q[1];

  // ---- SoC + loader
  logic        hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error, host_irq, host_ready, ras_fatal;
  logic [31:0] hs_req_addr, hs_req_wdata, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb;
  logic        diag_valid, test_done, test_fail, cpu_sleep, iron_init, fabric_rst_n, ld_done, ld_err;
  logic [7:0]  diag_char;
  logic [15:0] test_code;

  sf_albion_soc_min #(.CC_SRAM_BACKEND(`SRAM_BACKEND_FPGA)) u_soc (
    .clk(clk_i), .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(2'b00), .host_rst_req_i(1'b0),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(host_irq), .host_ready_o(host_ready), .ras_fatal_o(ras_fatal),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail), .test_code_o(test_code),
    .cpu_sleep_o(cpu_sleep), .iron_init_done_o(iron_init), .fabric_rst_no_o(fabric_rst_n));

  sf_asoc_host_loader #(.IMG_WORDS(IMG_WORDS), .IMAGE_FILE(IMAGE_FILE)) u_loader (
    .clk_i, .rst_ni(rst_n), .restart_i(1'b0),
    .hs_req_valid_o(hs_req_valid), .hs_req_ready_i(hs_req_ready), .hs_req_write_o(hs_req_write), .hs_req_addr_o(hs_req_addr),
    .hs_req_wdata_o(hs_req_wdata), .hs_req_wstrb_o(hs_req_wstrb), .hs_rsp_valid_i(hs_rsp_valid), .hs_rsp_ready_o(hs_rsp_ready),
    .hs_rsp_rdata_i(hs_rsp_rdata), .hs_rsp_error_i(hs_rsp_error), .host_irq_i(host_irq), .done_o(ld_done), .err_o(ld_err));

  // ---- console UART (DIAG_TX -> FIFO -> 8N1).  The FIFO is deep enough for the whole firmware run (a full FIFO would drop characters)
  localparam int CW = $clog2(CON_DEPTH);
  logic [7:0]  cf [CON_DEPTH];
  logic [CW-1:0] cwp, crp;
  logic [7:0]  tx_byte;
  logic [15:0] cnt_q;
  logic [3:0]  bit_q;
  logic [9:0]  sh_q;
  logic        busy_q;
  always_ff @(posedge clk_i) begin
    if (diag_valid && (cwp + CW'(1)) != crp) cf[cwp] <= diag_char;
    tx_byte <= cf[crp];                       // synchronous read: block RAM
  end
  logic [1:0] rd_dly_q;
  always_ff @(posedge clk_i or negedge rst_n) begin
    if (!rst_n) begin
      cwp <= '0; crp <= '0; cnt_q <= '0; bit_q <= '0; sh_q <= '1; busy_q <= 1'b0; rd_dly_q <= 2'd0;
    end else begin
      if (diag_valid && (cwp + CW'(1)) != crp) cwp <= cwp + CW'(1);
      if (!busy_q) begin
        if (crp != cwp) begin
          if (rd_dly_q != 2'd2) rd_dly_q <= rd_dly_q + 2'd1;                        // let the synchronous FIFO read settle
          else begin sh_q <= {1'b1, tx_byte, 1'b0}; crp <= crp + CW'(1); busy_q <= 1'b1; bit_q <= '0; cnt_q <= '0; rd_dly_q <= 2'd0; end
        end
      end else if (cnt_q == 16'(BAUD_DIV - 1)) begin
        cnt_q <= '0; sh_q <= {1'b1, sh_q[9:1]};
        if (bit_q == 4'd9) busy_q <= 1'b0;
        bit_q <= bit_q + 4'd1;
      end else cnt_q <= cnt_q + 16'd1;
    end
  end
  assign uart_tx_o = busy_q ? sh_q[0] : 1'b1;

  logic [23:0] hb_q;
  always_ff @(posedge clk_i or negedge rst_n) if (!rst_n) hb_q <= '0; else hb_q <= hb_q + 24'd1;
  assign led_o = {hb_q[23], cpu_sleep, ras_fatal, test_fail, test_done, iron_init, ld_err, ld_done};

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^{host_ready, fabric_rst_n, test_code};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
