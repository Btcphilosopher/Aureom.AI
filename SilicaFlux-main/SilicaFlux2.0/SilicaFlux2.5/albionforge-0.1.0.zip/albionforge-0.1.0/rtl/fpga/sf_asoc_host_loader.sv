// =============================================================================
// AlbionForge :: sf_asoc_host_loader -- hardware twin of the Host Simulation Interface (synthesizable)
//
// Role      Drives ControlCore's host access port (SFB2 master) exactly as tb/tb_albion_soc.sv does in simulation:
//             1. poll SYSCTRL.BOOT_STAGE until the boot ROM reports WAIT_IMAGE (3);
//             2. write the firmware image (a ROM initialised from IMAGE_FILE, a $readmemh file: bitstream / block-RAM initial
//                contents on an FPGA) into instruction SRAM word by word; the length is the image_size field of the image header
//                (word 2 of the image), so no length parameter has to be kept in step with the firmware build;
//             3. write H2F_MSG0 = IMAGE_READY and ring the mailbox doorbell;
//             4. wait for the boot ROM's answer (host_irq), read the 8 answer words, acknowledge (F2H_ACK), then go idle (done_o).
//           A non-zero ROM status word sets err_o (sticky).  After a ControlCore reset (host_rst / watchdog) `restart_i` re-runs it.
// Not a security mechanism: the image is integrity-checked (CRC-32) by the boot ROM, NOT authenticated (ControlCore limitation).
// Reset     rst_ni asynchronous assert.
// =============================================================================
`default_nettype none

module sf_asoc_host_loader #(
  parameter int    IMG_WORDS  = 8192,
  parameter        IMAGE_FILE = ""
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  input  wire logic        restart_i,
  output logic             hs_req_valid_o,
  input  wire logic        hs_req_ready_i,
  output logic             hs_req_write_o,
  output logic [31:0]      hs_req_addr_o,
  output logic [31:0]      hs_req_wdata_o,
  output logic [3:0]       hs_req_wstrb_o,
  input  wire logic        hs_rsp_valid_i,
  output logic             hs_rsp_ready_o,
  input  wire logic [31:0] hs_rsp_rdata_i,
  input  wire logic        hs_rsp_error_i,
  input  wire logic        host_irq_i,
  output logic             done_o,
  output logic             err_o
);
  /* verilator lint_off UNUSEDPARAM */
  `include "cc_memmap_defs.svh"
  /* verilator lint_on UNUSEDPARAM */
  localparam int AWL = $clog2(IMG_WORDS);

  // image ROM (inferred block RAM / ROM); content from IMAGE_FILE
  logic [31:0] rom [IMG_WORDS];
  initial if (IMAGE_FILE != "") $readmemh(IMAGE_FILE, rom);
  logic [AWL-1:0] ra_q;
  logic [31:0]    rd_q;
  always_ff @(posedge clk_i) rd_q <= rom[ra_q];

  localparam logic [3:0] S_POLL = 4'd0, S_POLLW = 4'd1, S_WR = 4'd2, S_WRW = 4'd3, S_MSG = 4'd4, S_RING = 4'd5, S_IRQ = 4'd6,
                         S_RD = 4'd7, S_ACK = 4'd8, S_DONE = 4'd9, S_PAUSE = 4'd10, S_LEN = 4'd11;
  logic [3:0]  st_q;
  logic [15:0] idx_q, wait_q;
  logic [3:0]  rdi_q;
  logic        wr_q, req_q, err_q;
  logic [31:0] a_q, d_q;
  logic        stat_bad_q;
  logic [15:0] nw_q;                 // words in the image (header.image_size / 4)

  assign hs_req_valid_o = req_q;
  assign hs_req_write_o = wr_q;
  assign hs_req_addr_o  = a_q;
  assign hs_req_wdata_o = d_q;
  assign hs_req_wstrb_o = 4'hF;
  assign hs_rsp_ready_o = 1'b1;
  assign done_o = (st_q == S_DONE);
  assign err_o  = err_q;

  logic [15:0] RSP_WAIT;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= S_LEN; idx_q <= 16'd0; wait_q <= 16'd0; rdi_q <= 4'd0; wr_q <= 1'b0; req_q <= 1'b0; err_q <= 1'b0;
      a_q <= 32'd0; d_q <= 32'd0; ra_q <= '0; stat_bad_q <= 1'b0; nw_q <= 16'd0;
    end else begin
      if (restart_i) begin
        st_q <= S_PAUSE; idx_q <= 16'd0; req_q <= 1'b0; wait_q <= 16'd0; err_q <= 1'b0; stat_bad_q <= 1'b0;
      end else case (st_q)
        S_LEN: begin                         // header word 2 = image size in bytes
          if (wait_q == 16'd0)      begin ra_q <= AWL'(2); wait_q <= 16'd1; end
          else if (wait_q == 16'd1) begin wait_q <= 16'd2; end
          else begin nw_q <= rd_q[17:2]; st_q <= S_PAUSE; wait_q <= 16'd0; end
        end
        S_PAUSE: begin                       // give the ControlCore time to come out of reset and run its boot ROM
          wait_q <= wait_q + 16'd1;
          if (wait_q == 16'hFFFF) begin st_q <= S_POLL; wait_q <= 16'd0; end
        end
        S_POLL: begin                        // read BOOT_STAGE
          a_q <= CC_SYSCTRL_BASE + {20'd0, CC_SYSCTRL_BOOT_STAGE}; wr_q <= 1'b0; req_q <= 1'b1; st_q <= S_POLLW;
        end
        S_POLLW: begin
          if (req_q && hs_req_ready_i) req_q <= 1'b0;
          if (hs_rsp_valid_i) begin
            if (!hs_rsp_error_i && hs_rsp_rdata_i == CC_BOOT_STAGE_WAIT_IMAGE) begin st_q <= S_WR; idx_q <= 16'd0; ra_q <= '0; end
            else begin st_q <= S_PAUSE; wait_q <= 16'hFF00; end        // not there yet: poll again after a short pause
          end
        end
        S_WR: begin                          // present ROM word idx_q at IMEM + 4*idx_q (synchronous ROM: two cycles from address to data)
          if (wait_q == 16'd0)      begin wait_q <= 16'd1; ra_q <= AWL'(idx_q); end
          else if (wait_q == 16'd1) begin wait_q <= 16'd2; end
          else begin
            a_q <= CC_IMEM_BASE + {14'd0, idx_q, 2'b00}; d_q <= rd_q; wr_q <= 1'b1; req_q <= 1'b1; st_q <= S_WRW; wait_q <= 16'd0;
          end
        end
        S_WRW: begin
          if (req_q && hs_req_ready_i) req_q <= 1'b0;
          if (hs_rsp_valid_i) begin
            if (hs_rsp_error_i) err_q <= 1'b1;
            if (idx_q + 16'd1 == nw_q) st_q <= S_MSG; else begin idx_q <= idx_q + 16'd1; st_q <= S_WR; end
          end
        end
        S_MSG: begin                         // H2F_MSG0 = IMAGE_READY
          a_q <= CC_MAILBOX_BASE + {20'd0, CC_MBOX_H2F_MSG0}; d_q <= CC_MBOX_CMD_IMAGE_READY; wr_q <= 1'b1; req_q <= 1'b1; st_q <= S_RING; idx_q <= 16'd0;
        end
        S_RING: begin
          if (req_q && hs_req_ready_i) req_q <= 1'b0;
          if (hs_rsp_valid_i) begin
            if (idx_q == 16'd0) begin           // doorbell
              a_q <= CC_MAILBOX_BASE + {20'd0, CC_MBOX_H2F_RING}; d_q <= CC_MBOX_CMD_IMAGE_READY; req_q <= 1'b1; idx_q <= 16'd1;
            end else st_q <= S_IRQ;
          end
        end
        S_IRQ: if (host_irq_i) begin st_q <= S_RD; rdi_q <= 4'd0; a_q <= CC_MAILBOX_BASE + {20'd0, CC_MBOX_F2H_MSG0}; wr_q <= 1'b0; req_q <= 1'b1; end
        S_RD: begin                          // read the 8 answer words; word 0 low byte is the ROM status
          if (req_q && hs_req_ready_i) req_q <= 1'b0;
          if (hs_rsp_valid_i) begin
            if (rdi_q == 4'd0 && hs_rsp_rdata_i[7:0] != 8'd0) stat_bad_q <= 1'b1;
            if (rdi_q == 4'd7) begin st_q <= S_ACK; a_q <= CC_MAILBOX_BASE + {20'd0, CC_MBOX_F2H_ACK}; d_q <= 32'd0; wr_q <= 1'b1; req_q <= 1'b1; end
            else begin rdi_q <= rdi_q + 4'd1; a_q <= a_q + 32'd4; req_q <= 1'b1; end
          end
        end
        S_ACK: begin
          if (req_q && hs_req_ready_i) req_q <= 1'b0;
          if (hs_rsp_valid_i) begin st_q <= S_DONE; if (stat_bad_q) err_q <= 1'b1; end
        end
        default: ;                           // S_DONE
      endcase
    end
  end
  assign RSP_WAIT = 16'd0;
  /* verilator lint_off UNUSEDSIGNAL */
  logic unused;
  assign unused = ^RSP_WAIT ^ ^rd_q[0];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
