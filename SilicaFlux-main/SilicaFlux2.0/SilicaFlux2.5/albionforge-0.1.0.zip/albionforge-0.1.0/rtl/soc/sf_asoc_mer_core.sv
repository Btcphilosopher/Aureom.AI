// =============================================================================
// AlbionForge :: sf_asoc_mer_core -- Meridian fabric with ALP initiator ports
//
// Role      Instantiates sf_meridian_fabric (Project 83, unmodified apart from the tool-compatibility patches in
//           patches/meridian) with the parameters generated into sf_asoc_cfg_pkg, and presents each master port as an ALP v1
//           initiator link.  The target side stays in Meridian format (sf_asoc_mer_tgt adapts each target).
// Mapping   ALP op READ/WRITE -> Meridian 0/1; any other opcode, or a domain that Meridian's DOMW bits cannot represent, is
//           forwarded as the reserved opcode 3 so the fabric answers it PROTOCOL_ERR instead of misrouting it.
//           attr.priv -> priv; attr.qos -> tc = {0, qos}; secure / instr / mem_type are not carried (limitation L-06).
//           Meridian status -> ALP status: OKAY 0, SLVERR TARGET_ERR, DECERR DECODE_ERR, DENIED ACCESS_DENIED,
//           TIMEOUT TIMEOUT, PROTO PROTOCOL_ERR.  Completion metadata: last = 1, is_write from the echoed opcode.
// Reset     rst_ni: asynchronous assert (Meridian rst_n).  No transaction survives reset.
// =============================================================================
`default_nettype none

module sf_asoc_mer_core #(
  parameter int unsigned NM = sf_asoc_cfg_pkg::MER_NM,
  parameter int unsigned NT = sf_asoc_cfg_pkg::MER_NT,
  parameter int unsigned STALL_PCT = 0,                  // verification: random request back-pressure on every master port
  parameter logic [31:0] STALL_SEED = 32'h1BADB002
) (
  input  wire logic            clk_i,
  input  wire logic            rst_ni,
  // ---------------------------------------------------------------- ALP initiator links (one per master port)
  input  wire logic [NM-1:0]   m_req_valid_i,
  output logic      [NM-1:0]   m_req_ready_o,
  input  wire logic [NM*4-1:0] m_req_op_i,
  input  wire logic [NM*8-1:0] m_req_tag_i,
  input  wire logic [NM*8-1:0] m_req_dom_i,
  input  wire logic [NM*8-1:0] m_req_attr_i,
  input  wire logic [NM*64-1:0]  m_req_addr_i,
  input  wire logic [NM*16-1:0]  m_req_be_i,
  input  wire logic [NM*128-1:0] m_req_data_i,
  output logic      [NM-1:0]   m_rsp_valid_o,
  input  wire logic [NM-1:0]   m_rsp_ready_i,
  output logic      [NM*8-1:0] m_rsp_tag_o,
  output logic      [NM*4-1:0] m_rsp_status_o,
  output logic      [NM*8-1:0] m_rsp_meta_o,
  output logic      [NM*128-1:0] m_rsp_data_o,
  // ---------------------------------------------------------------- Meridian target-side ports
  output logic      [NT-1:0]   t_req_valid_o,
  input  wire logic [NT-1:0]   t_req_ready_i,
  output logic      [NT*sf_meridian_pkg::clog2c(NM)-1:0] t_req_src_o,
  output logic      [NT*2-1:0] t_req_op_o,
  output logic      [NT*sf_asoc_cfg_pkg::MER_TAGW-1:0] t_req_tag_o,
  output logic      [NT*sf_asoc_cfg_pkg::MER_DOMW-1:0] t_req_dom_o,
  output logic      [NT-1:0]   t_req_priv_o,
  output logic      [NT*3-1:0] t_req_tc_o,
  output logic      [NT*64-1:0]  t_req_addr_o,
  output logic      [NT*128-1:0] t_req_wdata_o,
  output logic      [NT*16-1:0]  t_req_wstrb_o,
  input  wire logic [NT-1:0]   t_rsp_valid_i,
  output logic      [NT-1:0]   t_rsp_ready_o,
  input  wire logic [NT*sf_meridian_pkg::clog2c(NM)-1:0] t_rsp_src_i,
  input  wire logic [NT*sf_asoc_cfg_pkg::MER_TAGW-1:0] t_rsp_tag_i,
  input  wire logic [NT*sf_asoc_cfg_pkg::MER_DOMW-1:0] t_rsp_dom_i,
  input  wire logic [NT*2-1:0] t_rsp_op_i,
  input  wire logic [NT*3-1:0] t_rsp_status_i,
  input  wire logic [NT*128-1:0] t_rsp_rdata_i,
  // ---------------------------------------------------------------- management (SoC-control block)
  input  wire logic            pol_we_i,
  input  wire logic [sf_meridian_pkg::clog2c(sf_asoc_cfg_pkg::MER_CIT_NENT)-1:0] pol_idx_i,
  input  wire logic            pol_valid_i,
  input  wire logic [NM-1:0]   pol_src_i,
  input  wire logic [(1<<sf_asoc_cfg_pkg::MER_DOMW)-1:0] pol_dom_i,
  input  wire logic            pol_priv_i,
  input  wire logic [63:0]     pol_base_i,
  input  wire logic [63:0]     pol_mask_i,
  input  wire logic            pol_rd_i,
  input  wire logic            pol_wr_i,
  input  wire logic [NT-1:0]   iso_clear_i,
  input  wire logic            zomb_flush_i,
  output logic      [NM*NT-1:0] iso_o,
  input  wire logic            elog_clear_i,
  output logic                 elog_valid_o,
  output logic      [sf_meridian_pkg::clog2c(NM)-1:0] elog_src_o,
  output logic      [2:0]      elog_status_o,
  output logic      [3:0]      elog_fault_o,
  output logic      [63:0]     elog_addr_o,
  output logic      [sf_asoc_cfg_pkg::MER_DOMW-1:0] elog_dom_o,
  output logic      [sf_asoc_cfg_pkg::MER_TAGW-1:0] elog_tag_o,
  output logic      [sf_meridian_pkg::clog2c(NT)-1:0] elog_tgt_o,
  output logic      [31:0]     elog_count_o,
  output logic                 evt_err_o,
  output logic                 evt_sec_o,
  input  wire logic            perf_clear_i,
  input  wire logic            perf_freeze_i,
  input  wire logic [sf_meridian_pkg::clog2c(sf_meridian_pkg::pf_n(sf_asoc_cfg_pkg::MER_NM, sf_asoc_cfg_pkg::MER_NT))-1:0] perf_sel_i,
  output logic      [31:0]     perf_data_o
);
  localparam int unsigned DOMW = sf_asoc_cfg_pkg::MER_DOMW;
  localparam int unsigned TAGW = sf_asoc_cfg_pkg::MER_TAGW;

  // ---------------------------------------------------------------- master-side field mapping
  logic [NM*2-1:0]    f_op;
  logic [NM*DOMW-1:0] f_dom;
  logic [NM-1:0]      f_priv;
  logic [NM*3-1:0]    f_tc;
  /* verilator lint_off UNUSEDSIGNAL */   // ALP attr bits secure / instr / mem_type / rsvd are not carried by Meridian (limitation L-06)
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      logic [3:0] op;
      logic [7:0] dm, at;
      op = m_req_op_i[m*4 +: 4];
      dm = m_req_dom_i[m*8 +: 8];
      at = m_req_attr_i[m*8 +: 8];
      if (dm[7:DOMW] != '0)  f_op[m*2 +: 2] = 2'd3;      // unrepresentable domain -> reserved opcode -> PROTOCOL_ERR
      else if (op == 4'h1)   f_op[m*2 +: 2] = 2'd0;
      else if (op == 4'h2)   f_op[m*2 +: 2] = 2'd1;
      else                   f_op[m*2 +: 2] = 2'd3;
      f_dom [m*DOMW +: DOMW] = dm[DOMW-1:0];
      f_priv[m]              = at[2];
      f_tc  [m*3 +: 3]       = {1'b0, at[6:5]};
    end
  end
  /* verilator lint_on UNUSEDSIGNAL */

  logic [NM*TAGW-1:0] r_tag;
  logic [NM*DOMW-1:0] r_dom;
  logic [NM*2-1:0]    r_op;
  logic [NM*3-1:0]    r_status;
  logic [NM*128-1:0]  r_rdata;
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      logic [2:0] st;
      st = r_status[m*3 +: 3];
      m_rsp_tag_o[m*8 +: 8] = r_tag[m*TAGW +: TAGW];
      case (st)
        3'd0:    m_rsp_status_o[m*4 +: 4] = 4'h0;   // OKAY
        3'd1:    m_rsp_status_o[m*4 +: 4] = 4'h7;   // SLVERR   -> TARGET_ERR
        3'd2:    m_rsp_status_o[m*4 +: 4] = 4'h1;   // DECERR   -> DECODE_ERR
        3'd3:    m_rsp_status_o[m*4 +: 4] = 4'h2;   // DENIED   -> ACCESS_DENIED
        3'd4:    m_rsp_status_o[m*4 +: 4] = 4'h8;   // TIMEOUT  -> TIMEOUT
        default: m_rsp_status_o[m*4 +: 4] = 4'hB;   // PROTO / reserved -> PROTOCOL_ERR
      endcase
      m_rsp_meta_o[m*8 +: 8]    = {4'b0000, 1'b0, 1'b0, 1'b1, (r_op[m*2 +: 2] == 2'd1)};
      m_rsp_data_o[m*128 +: 128] = (st == 3'd0) ? r_rdata[m*128 +: 128] : 128'd0;
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM*DOMW-1:0] r_dom_unused;
  assign r_dom_unused = r_dom;
  /* verilator lint_on UNUSEDSIGNAL */

  // random back-pressure (default off): a block starts only while the master has no request pending
  logic [NM-1:0] m_blk, m_req_valid_g, m_req_ready_f;
  generate
    for (genvar m = 0; m < NM; m++) begin : g_gate
      sf_asoc_gate #(.PCT(STALL_PCT), .SEED(STALL_SEED + 32'(m) * 32'h9E3779B1)) u_gate (
        .clk_i, .rst_ni, .pending_i(m_req_valid_i[m]), .block_o(m_blk[m]));
    end
  endgenerate
  assign m_req_valid_g = m_req_valid_i & ~m_blk;
  assign m_req_ready_o = m_req_ready_f & ~m_blk;

  sf_meridian_fabric #(
    .NM(NM), .NT(NT), .AW(64), .DW(128),
    .TAGW(TAGW), .DOMW(DOMW),
    .TGT_BASE(sf_asoc_cfg_pkg::MER_TGT_BASE),
    .TGT_MASK(sf_asoc_cfg_pkg::MER_TGT_MASK),
    .CONN(sf_asoc_cfg_pkg::MER_CONN),
    .REQ_DEPTH(sf_asoc_cfg_pkg::MER_REQ_DEPTH),
    .MST_MAXO(sf_asoc_cfg_pkg::MER_MST_MAXO),
    .MST_OOO({NM{1'b0}}),
    .MST_DOM_ALLOW(sf_asoc_cfg_pkg::MER_MST_DOM_ALLOW),
    .ARB_MODE(sf_asoc_cfg_pkg::MER_ARB_MODE),
    .STARVE(sf_asoc_cfg_pkg::MER_STARVE),
    .CITADEL_MODE(sf_asoc_cfg_pkg::MER_CITADEL_MODE),
    .CIT_NENT(sf_asoc_cfg_pkg::MER_CIT_NENT),
    .CIT_LAT(sf_asoc_cfg_pkg::MER_CIT_LAT),
    .TMO(sf_asoc_cfg_pkg::MER_TMO),
    .ISOLATE(sf_asoc_cfg_pkg::MER_ISOLATE)
  ) u_fabric (
    .clk(clk_i), .rst_n(rst_ni),
    .m_req_valid(m_req_valid_g), .m_req_ready(m_req_ready_f), .m_req_op(f_op), .m_req_tag(m_req_tag_i),
    .m_req_dom(f_dom), .m_req_priv(f_priv), .m_req_tc(f_tc), .m_req_addr(m_req_addr_i),
    .m_req_wdata(m_req_data_i), .m_req_wstrb(m_req_be_i),
    .m_rsp_valid(m_rsp_valid_o), .m_rsp_ready(m_rsp_ready_i), .m_rsp_tag(r_tag), .m_rsp_dom(r_dom),
    .m_rsp_op(r_op), .m_rsp_status(r_status), .m_rsp_rdata(r_rdata),
    .t_req_valid(t_req_valid_o), .t_req_ready(t_req_ready_i), .t_req_src(t_req_src_o), .t_req_op(t_req_op_o),
    .t_req_tag(t_req_tag_o), .t_req_dom(t_req_dom_o), .t_req_priv(t_req_priv_o), .t_req_tc(t_req_tc_o),
    .t_req_addr(t_req_addr_o), .t_req_wdata(t_req_wdata_o), .t_req_wstrb(t_req_wstrb_o),
    .t_rsp_valid(t_rsp_valid_i), .t_rsp_ready(t_rsp_ready_o), .t_rsp_src(t_rsp_src_i), .t_rsp_tag(t_rsp_tag_i),
    .t_rsp_dom(t_rsp_dom_i), .t_rsp_op(t_rsp_op_i), .t_rsp_status(t_rsp_status_i), .t_rsp_rdata(t_rsp_rdata_i),
    // external Citadel ports unused: CITADEL_MODE = reference table inside the fabric
    .cit_req_valid(), .cit_req_ready({NM{1'b1}}), .cit_req_dom(), .cit_req_priv(), .cit_req_write(), .cit_req_addr(),
    .cit_rsp_valid({NM{1'b0}}), .cit_rsp_ok({NM{1'b0}}), .cit_rsp_fault({(NM*4){1'b0}}),
    .pol_we(pol_we_i), .pol_idx(pol_idx_i), .pol_valid(pol_valid_i), .pol_src(pol_src_i), .pol_dom(pol_dom_i),
    .pol_priv(pol_priv_i), .pol_base(pol_base_i), .pol_mask(pol_mask_i), .pol_rd(pol_rd_i), .pol_wr(pol_wr_i),
    .tst_cit_stall({NM{1'b0}}),
    .iso_clear(iso_clear_i), .zomb_flush(zomb_flush_i), .o_iso(iso_o), .o_cit_orphan(),
    .elog_clear(elog_clear_i), .elog_valid(elog_valid_o), .elog_src(elog_src_o), .elog_status(elog_status_o),
    .elog_fault(elog_fault_o), .elog_addr(elog_addr_o), .elog_dom(elog_dom_o), .elog_tag(elog_tag_o),
    .elog_tgt(elog_tgt_o), .elog_count(elog_count_o), .evt_err(evt_err_o), .evt_sec(evt_sec_o),
    .perf_clear(perf_clear_i), .perf_freeze(perf_freeze_i), .perf_sel(perf_sel_i), .perf_data(perf_data_o)
  );
endmodule

`default_nettype wire
