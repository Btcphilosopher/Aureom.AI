// =============================================================================
// AlbionForge :: sf_asoc_dma_ctl -- CloudDMA (BridgeEngine) control registers behind the 32-bit register bus
//
// Role      Integration glue for the `dma` region.  Offsets 0x000..0x7FF go straight to CloudDMA's CSR port (ID, CTRL, IRQ,
//           timeout, performance-counter select, channel status: ip/clouddma/docs/04_INTEGRATION.md section 5).
//           Offsets 0x800.. add the interfaces CloudDMA expects the platform to provide but the repository does not:
//             * submission : CloudDMA takes commands on a hardware `cmd_*` port, not through its CSRs.  SUBMIT_HEAD /
//                            SUBMIT_GO form that queue front end.  The command domain is BIND_DOM, a module parameter: it is
//                            hardware-bound and NO register can change it (CloudDMA integration rule section 4).
//             * completion : the `done_*` record is captured (count, last status / error / fault, bytes, CRC) and the
//                            submit-to-completion latency is measured in cycles.
//             * permission table: the IOMMU model's programming port `ptbl_*` as registers (management plane only: this
//                            window is reachable by the ControlCore domain only, enforced by the Citadel policy).
// Behaviour One outstanding submission at a time from this front end; SUBMIT_GO while one is pending or outstanding sets the
//           sticky "refused" flag and returns a register error.  Reset clears everything; the DMA is disabled until firmware
//           writes CTRL.enable.
// =============================================================================
`default_nettype none

module sf_asoc_dma_ctl #(
  parameter int unsigned AW       = 40,
  parameter int unsigned DOM_W    = 4,
  parameter logic [DOM_W-1:0] BIND_DOM = 4'd1
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // register bus (slave)
  input  wire logic        rb_valid_i,
  input  wire logic        rb_we_i,
  input  wire logic [11:0] rb_addr_i,
  input  wire logic [31:0] rb_wdata_i,
  output logic             rb_rvalid_o,
  output logic [31:0]      rb_rdata_o,
  output logic             rb_err_o,
  // CloudDMA CSR port
  output logic             csr_req_valid_o,
  input  wire logic        csr_req_ready_i,
  output logic             csr_req_write_o,
  output logic [11:0]      csr_req_addr_o,
  output logic [31:0]      csr_req_wdata_o,
  input  wire logic        csr_rsp_valid_i,
  input  wire logic [31:0] csr_rsp_rdata_i,
  input  wire logic        csr_rsp_err_i,
  // CloudDMA command / completion ports (one channel)
  output logic             cmd_valid_o,
  input  wire logic        cmd_ready_i,
  output logic [63:0]      cmd_head_o,
  output logic [DOM_W-1:0] cmd_domain_o,
  output logic [3:0]       cmd_asid_o,
  input  wire logic        done_valid_i,
  output logic             done_ready_o,
  input  wire logic [15:0] done_txn_i,
  input  wire logic [3:0]  done_status_i,
  input  wire logic [7:0]  done_err_i,
  input  wire logic [3:0]  done_fault_i,
  input  wire logic [31:0] done_bytes_i,
  input  wire logic [31:0] done_crc_i,
  input  wire logic        viol_evt_i,
  // permission-table programming port
  output logic             ptbl_en_o,
  output logic [3:0]       ptbl_idx_o,
  output logic             ptbl_valid_o,
  output logic [DOM_W-1:0] ptbl_domain_o,
  output logic [3:0]       ptbl_asid_o,
  output logic [AW-1:0]    ptbl_base_o,
  output logic [AW:0]      ptbl_size_o,
  output logic [AW-1:0]    ptbl_pa_o,
  output logic [1:0]       ptbl_perm_o,
  input  wire logic        ptbl_rej_i,
  // events from the AXI -> ALP bridge
  input  wire logic        br_err_evt_i,
  input  wire logic        br_refused_evt_i
);
  // ---- CSR passthrough
  assign csr_req_valid_o = rb_valid_i && !rb_addr_i[11];
  assign csr_req_write_o = rb_we_i;
  assign csr_req_addr_o  = rb_addr_i;
  assign csr_req_wdata_o = rb_wdata_i;

  // ---- shim
  logic shim_req, shim_wr;
  assign shim_req = rb_valid_i && rb_addr_i[11];
  assign shim_wr  = shim_req && rb_we_i;

  logic [31:0] head_lo_q, head_hi_q;
  logic [3:0]  asid_q;
  logic        pend_q, outst_q, refused_q;
  logic [31:0] cyc_q, start_q, lat_q, done_cnt_q, viol_cnt_q, bytes_q, crc_q;
  logic [15:0] txn_q;
  logic [3:0]  st_q, fault_q;
  logic [7:0]  err_q_r;
  logic [15:0] br_err_cnt_q, br_ref_cnt_q;

  logic [3:0]  p_idx_q, p_dom_q, p_asid_q;
  logic [31:0] p_base_lo_q, p_base_hi_q, p_size_lo_q, p_size_hi_q, p_pa_lo_q, p_pa_hi_q;
  logic [2:0]  p_flags_q;
  logic        p_en_q, p_rej_q;

  assign cmd_valid_o  = pend_q;
  assign cmd_head_o   = {head_hi_q, head_lo_q};
  assign cmd_domain_o = BIND_DOM;                  // hardware binding, not a register
  assign cmd_asid_o   = asid_q;
  assign done_ready_o = 1'b1;

  assign ptbl_en_o     = p_en_q;
  assign ptbl_idx_o    = p_idx_q;
  assign ptbl_valid_o  = p_flags_q[0];
  assign ptbl_domain_o = p_dom_q[DOM_W-1:0];
  assign ptbl_asid_o   = p_asid_q;
  assign ptbl_base_o   = {p_base_hi_q[AW-33:0], p_base_lo_q};
  assign ptbl_size_o   = {p_size_hi_q[AW-32:0], p_size_lo_q};
  assign ptbl_pa_o     = {p_pa_hi_q[AW-33:0], p_pa_lo_q};
  assign ptbl_perm_o   = {p_flags_q[2], p_flags_q[1]};

  logic go_ok, go_refuse;
  assign go_ok     = shim_wr && (rb_addr_i == sf_asoc_cfg_pkg::R_DMA_SUBMIT_GO) && !pend_q && !outst_q;
  assign go_refuse = shim_wr && (rb_addr_i == sf_asoc_cfg_pkg::R_DMA_SUBMIT_GO) && (pend_q || outst_q);

  logic [31:0] rd_val;
  logic        known_reg;
  always_comb begin
    rd_val = 32'd0; known_reg = 1'b1;
    case (rb_addr_i)
      sf_asoc_cfg_pkg::R_DMA_SUBMIT_HEAD_LO: rd_val = head_lo_q;
      sf_asoc_cfg_pkg::R_DMA_SUBMIT_HEAD_HI: rd_val = head_hi_q;
      sf_asoc_cfg_pkg::R_DMA_SUBMIT_ASID:    rd_val = 32'(asid_q);
      sf_asoc_cfg_pkg::R_DMA_SUBMIT_GO:      rd_val = 32'd0;
      sf_asoc_cfg_pkg::R_DMA_SUBMIT_STATUS:  rd_val = {29'd0, refused_q, outst_q || pend_q, !pend_q};
      sf_asoc_cfg_pkg::R_DMA_DONE_COUNT:     rd_val = done_cnt_q;
      sf_asoc_cfg_pkg::R_DMA_DONE_LAST:      rd_val = {txn_q, err_q_r, fault_q, st_q};
      sf_asoc_cfg_pkg::R_DMA_DONE_BYTES:     rd_val = bytes_q;
      sf_asoc_cfg_pkg::R_DMA_DONE_CRC:       rd_val = crc_q;
      sf_asoc_cfg_pkg::R_DMA_VIOL_COUNT:     rd_val = viol_cnt_q;
      sf_asoc_cfg_pkg::R_DMA_LAT_LAST:       rd_val = lat_q;
      sf_asoc_cfg_pkg::R_DMA_BIND_DOM:       rd_val = 32'(BIND_DOM);
      sf_asoc_cfg_pkg::R_DMA_AXI_ERRS:       rd_val = {br_ref_cnt_q, br_err_cnt_q};
      sf_asoc_cfg_pkg::R_DMA_PTBL_IDX:       rd_val = 32'(p_idx_q);
      sf_asoc_cfg_pkg::R_DMA_PTBL_DOM:       rd_val = 32'(p_dom_q);
      sf_asoc_cfg_pkg::R_DMA_PTBL_ASID:      rd_val = 32'(p_asid_q);
      sf_asoc_cfg_pkg::R_DMA_PTBL_BASE_LO:   rd_val = p_base_lo_q;
      sf_asoc_cfg_pkg::R_DMA_PTBL_BASE_HI:   rd_val = p_base_hi_q;
      sf_asoc_cfg_pkg::R_DMA_PTBL_SIZE_LO:   rd_val = p_size_lo_q;
      sf_asoc_cfg_pkg::R_DMA_PTBL_SIZE_HI:   rd_val = p_size_hi_q;
      sf_asoc_cfg_pkg::R_DMA_PTBL_PA_LO:     rd_val = p_pa_lo_q;
      sf_asoc_cfg_pkg::R_DMA_PTBL_PA_HI:     rd_val = p_pa_hi_q;
      sf_asoc_cfg_pkg::R_DMA_PTBL_FLAGS:     rd_val = 32'(p_flags_q);
      sf_asoc_cfg_pkg::R_DMA_PTBL_GO:        rd_val = 32'd0;
      sf_asoc_cfg_pkg::R_DMA_PTBL_STATUS:    rd_val = {31'd0, p_rej_q};
      default: known_reg = 1'b0;
    endcase
  end

  logic rv_q, er_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      head_lo_q <= 32'd0; head_hi_q <= 32'd0; asid_q <= 4'd0;
      pend_q <= 1'b0; outst_q <= 1'b0; refused_q <= 1'b0;
      cyc_q <= 32'd0; start_q <= 32'd0; lat_q <= 32'd0; done_cnt_q <= 32'd0; viol_cnt_q <= 32'd0;
      bytes_q <= 32'd0; crc_q <= 32'd0; txn_q <= 16'd0; st_q <= 4'd0; fault_q <= 4'd0; err_q_r <= 8'd0;
      br_err_cnt_q <= 16'd0; br_ref_cnt_q <= 16'd0;
      p_idx_q <= 4'd0; p_dom_q <= 4'd0; p_asid_q <= 4'd0; p_base_lo_q <= 32'd0; p_base_hi_q <= 32'd0;
      p_size_lo_q <= 32'd0; p_size_hi_q <= 32'd0; p_pa_lo_q <= 32'd0; p_pa_hi_q <= 32'd0; p_flags_q <= 3'd0;
      p_en_q <= 1'b0; p_rej_q <= 1'b0;
      rv_q <= 1'b0; er_q <= 1'b0;
    end else begin
      cyc_q <= cyc_q + 32'd1;
      rv_q  <= shim_req;
      er_q  <= shim_req && (!known_reg || go_refuse);
      p_en_q <= 1'b0;
      if (shim_wr) begin
        case (rb_addr_i)
          sf_asoc_cfg_pkg::R_DMA_SUBMIT_HEAD_LO: head_lo_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_SUBMIT_HEAD_HI: head_hi_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_SUBMIT_ASID:    asid_q    <= rb_wdata_i[3:0];
          sf_asoc_cfg_pkg::R_DMA_SUBMIT_STATUS:  if (rb_wdata_i[2]) refused_q <= 1'b0;
          sf_asoc_cfg_pkg::R_DMA_PTBL_IDX:       p_idx_q   <= rb_wdata_i[3:0];
          sf_asoc_cfg_pkg::R_DMA_PTBL_DOM:       p_dom_q   <= rb_wdata_i[3:0];
          sf_asoc_cfg_pkg::R_DMA_PTBL_ASID:      p_asid_q  <= rb_wdata_i[3:0];
          sf_asoc_cfg_pkg::R_DMA_PTBL_BASE_LO:   p_base_lo_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_PTBL_BASE_HI:   p_base_hi_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_PTBL_SIZE_LO:   p_size_lo_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_PTBL_SIZE_HI:   p_size_hi_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_PTBL_PA_LO:     p_pa_lo_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_PTBL_PA_HI:     p_pa_hi_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_DMA_PTBL_FLAGS:     p_flags_q <= rb_wdata_i[2:0];
          sf_asoc_cfg_pkg::R_DMA_PTBL_GO:        if (rb_wdata_i[0]) p_en_q <= 1'b1;
          sf_asoc_cfg_pkg::R_DMA_PTBL_STATUS:    if (rb_wdata_i[0]) p_rej_q <= 1'b0;
          default: ;
        endcase
      end
      if (ptbl_rej_i) p_rej_q <= 1'b1;
      if (go_refuse) refused_q <= 1'b1;
      if (go_ok && rb_wdata_i[0]) begin pend_q <= 1'b1; outst_q <= 1'b1; start_q <= cyc_q; end
      if (pend_q && cmd_ready_i) pend_q <= 1'b0;
      if (done_valid_i) begin
        outst_q    <= 1'b0;
        done_cnt_q <= done_cnt_q + 32'd1;
        txn_q      <= done_txn_i;
        st_q       <= done_status_i;
        err_q_r    <= done_err_i;
        fault_q    <= done_fault_i;
        bytes_q    <= done_bytes_i;
        crc_q      <= done_crc_i;
        lat_q      <= cyc_q - start_q;
      end
      if (viol_evt_i)        viol_cnt_q   <= viol_cnt_q + 32'd1;
      if (br_err_evt_i && br_err_cnt_q != 16'hFFFF)    br_err_cnt_q <= br_err_cnt_q + 16'd1;
      if (br_refused_evt_i && br_ref_cnt_q != 16'hFFFF) br_ref_cnt_q <= br_ref_cnt_q + 16'd1;
    end
  end

  assign rb_rvalid_o = csr_rsp_valid_i || rv_q;
  assign rb_rdata_o  = rv_q ? rd_val : csr_rsp_rdata_i;
  assign rb_err_o    = rv_q ? er_q : csr_rsp_err_i;

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused;
  assign unused = csr_req_ready_i ^ (^p_base_hi_q[31:AW-32]) ^ (^p_size_hi_q[31:AW-31]) ^ (^p_pa_hi_q[31:AW-32]) ^ (^head_hi_q[0]);
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
