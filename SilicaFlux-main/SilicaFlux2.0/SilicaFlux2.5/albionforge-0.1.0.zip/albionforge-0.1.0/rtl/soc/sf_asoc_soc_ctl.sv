// =============================================================================
// AlbionForge :: sf_asoc_soc_ctl -- SoC control registers: Citadel policy port, Meridian counters / error log
//
// Role      Integration glue for the `perf` region (the only window that reaches the fabric's management plane).
//             * Citadel policy: Meridian's reference Citadel is DEFAULT-DENY (no entry valid after reset: every request is
//               refused).  A hardware boot loader writes the generated boot policy (sf_asoc_cfg_pkg::POL_*: which master may
//               reach which region) right after reset, so the ControlCore can run; firmware may then rewrite any entry
//               through POL_* (this window is itself reachable only by the ControlCore domain).
//             * observability: Meridian's performance counters (96 for the 2 x 4 configuration, read through PERF_SEL /
//               PERF_DATA), the first-fault error log, the security-event count, a 64-bit free-running cycle counter.
// Honesty   The Citadel is a REFERENCE MODEL (sf_meridian_citadel_ref).  The repository contains no Citadel IP; the boot policy
//           loaded here is configuration, not a substitute for one (limitation L-03).
// Reset     rst_ni asynchronous assert; the loader restarts on every reset.
// =============================================================================
`default_nettype none

module sf_asoc_soc_ctl #(
  parameter int unsigned NM    = sf_asoc_cfg_pkg::MER_NM,
  parameter int unsigned NT    = sf_asoc_cfg_pkg::MER_NT,
  parameter int unsigned NENT  = sf_asoc_cfg_pkg::MER_CIT_NENT,
  parameter int unsigned NDOM  = (1 << sf_asoc_cfg_pkg::MER_DOMW),
  parameter int unsigned NCNT  = sf_meridian_pkg::pf_n(sf_asoc_cfg_pkg::MER_NM, sf_asoc_cfg_pkg::MER_NT)
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // register bus (slave)
  input  wire logic        rb_valid_i,
  input  wire logic        rb_we_i,
  input  wire logic [11:0] rb_addr_i,
  input  wire logic [31:0] rb_wdata_i,
  output logic             rb_rvalid_o,
  output logic [31:0]      rb_rdata_o,
  output logic             rb_err_o,
  // Meridian management plane
  output logic             pol_we_o,
  output logic [sf_meridian_pkg::clog2c(NENT)-1:0] pol_idx_o,
  output logic             pol_valid_o,
  output logic [NM-1:0]    pol_src_o,
  output logic [NDOM-1:0]  pol_dom_o,
  output logic             pol_priv_o,
  output logic [63:0]      pol_base_o,
  output logic [63:0]      pol_mask_o,
  output logic             pol_rd_o,
  output logic             pol_wr_o,
  output logic [NT-1:0]    iso_clear_o,
  output logic             zomb_flush_o,
  input  wire logic [NM*NT-1:0] iso_i,
  output logic             elog_clear_o,
  input  wire logic        elog_valid_i,
  input  wire logic [sf_meridian_pkg::clog2c(NM)-1:0] elog_src_i,
  input  wire logic [2:0]  elog_status_i,
  input  wire logic [3:0]  elog_fault_i,
  input  wire logic [63:0] elog_addr_i,
  input  wire logic [sf_asoc_cfg_pkg::MER_DOMW-1:0] elog_dom_i,
  input  wire logic [sf_asoc_cfg_pkg::MER_TAGW-1:0] elog_tag_i,
  input  wire logic [sf_meridian_pkg::clog2c(NT)-1:0] elog_tgt_i,
  input  wire logic [31:0] elog_count_i,
  input  wire logic        evt_sec_i,
  output logic             perf_clear_o,
  output logic             perf_freeze_o,
  output logic [sf_meridian_pkg::clog2c(NCNT)-1:0] perf_sel_o,
  input  wire logic [31:0] perf_data_i,
  // status
  input  wire logic        iron_init_i
);
  localparam int unsigned IW  = sf_meridian_pkg::clog2c(NENT);
  localparam int unsigned PIW = sf_meridian_pkg::clog2c(sf_asoc_cfg_pkg::POL_N + 1);

  // ---- boot policy loader
  logic [PIW-1:0] ld_q;
  logic           ld_busy, ld_we;
  assign ld_busy = (ld_q != PIW'(sf_asoc_cfg_pkg::POL_N));
  assign ld_we   = ld_busy;

  logic [NM-1:0]   ld_src;
  logic [NDOM-1:0] ld_dom;
  logic            ld_priv, ld_rd, ld_wr;
  logic [63:0]     ld_base, ld_mask;
  always_comb begin
    ld_src = '0; ld_dom = '0; ld_priv = 1'b0; ld_rd = 1'b0; ld_wr = 1'b0; ld_base = '0; ld_mask = '0;
    for (int e = 0; e < sf_asoc_cfg_pkg::POL_N; e++) begin
      if (ld_q == PIW'(e)) begin
        ld_src  = sf_asoc_cfg_pkg::POL_SRC[e*NM +: NM];
        ld_dom  = sf_asoc_cfg_pkg::POL_DOM[e*NDOM +: NDOM];
        ld_priv = sf_asoc_cfg_pkg::POL_PRIV[e];
        ld_base = sf_asoc_cfg_pkg::POL_BASE[e*64 +: 64];
        ld_mask = sf_asoc_cfg_pkg::POL_MASK[e*64 +: 64];
        ld_rd   = sf_asoc_cfg_pkg::POL_RD[e];
        ld_wr   = sf_asoc_cfg_pkg::POL_WR[e];
      end
    end
  end

  // ---- registers
  logic [31:0] cyc_lo_q, cyc_hi_q, cyc_hi_latch_q;
  logic [31:0] sec_q;
  logic        freeze_q;
  logic [6:0]  psel_q;
  logic [2:0]  p_idx_q;
  logic [NM-1:0]  p_src_q;
  logic [NDOM-1:0] p_dom_q;
  logic [3:0]  p_flags_q;
  logic [31:0] p_base_lo_q, p_base_hi_q, p_mask_lo_q, p_mask_hi_q;
  logic        p_go_q;
  logic        clr_q, eclr_q, zf_q;
  logic [NT-1:0] isoc_q;
  logic        rv_q, er_q;
  logic [31:0] rd_q;

  logic req, wr;
  assign req = rb_valid_i;
  assign wr  = rb_valid_i && rb_we_i;

  assign pol_we_o    = ld_we || p_go_q;
  assign pol_idx_o   = ld_busy ? IW'(ld_q) : IW'(p_idx_q);
  assign pol_valid_o = ld_busy ? 1'b1 : p_flags_q[0];
  assign pol_src_o   = ld_busy ? ld_src : p_src_q;
  assign pol_dom_o   = ld_busy ? ld_dom : p_dom_q;
  assign pol_priv_o  = ld_busy ? ld_priv : p_flags_q[1];
  assign pol_base_o  = ld_busy ? ld_base : {p_base_hi_q, p_base_lo_q};
  assign pol_mask_o  = ld_busy ? ld_mask : {p_mask_hi_q, p_mask_lo_q};
  assign pol_rd_o    = ld_busy ? ld_rd : p_flags_q[2];
  assign pol_wr_o    = ld_busy ? ld_wr : p_flags_q[3];
  assign iso_clear_o = isoc_q;
  assign zomb_flush_o = zf_q;
  assign elog_clear_o = eclr_q;
  assign perf_clear_o = clr_q;
  assign perf_freeze_o = freeze_q;
  assign perf_sel_o   = psel_q[sf_meridian_pkg::clog2c(NCNT)-1:0];

  logic [31:0] rd_val;
  logic        known;
  always_comb begin
    rd_val = 32'd0; known = 1'b1;
    case (rb_addr_i)
      sf_asoc_cfg_pkg::R_SOC_ID:          rd_val = 32'h414C424E;
      sf_asoc_cfg_pkg::R_SOC_VERSION:     rd_val = 32'h0001_0000;
      sf_asoc_cfg_pkg::R_SOC_CONFIG:      rd_val = {8'(NCNT), 8'(NENT), 8'(NT), 8'(NM)};
      sf_asoc_cfg_pkg::R_SOC_STATUS:      rd_val = {29'd0, iron_init_i, ld_busy, !ld_busy};
      sf_asoc_cfg_pkg::R_SOC_CYCLES_LO:   rd_val = cyc_lo_q;
      sf_asoc_cfg_pkg::R_SOC_CYCLES_HI:   rd_val = cyc_hi_latch_q;
      sf_asoc_cfg_pkg::R_SOC_CTRL:        rd_val = {30'd0, freeze_q, 1'b0};
      sf_asoc_cfg_pkg::R_SOC_ISO:         rd_val = 32'(iso_i);
      sf_asoc_cfg_pkg::R_SOC_PERF_SEL:    rd_val = 32'(psel_q);
      sf_asoc_cfg_pkg::R_SOC_PERF_DATA:   rd_val = perf_data_i;
      sf_asoc_cfg_pkg::R_SOC_ELOG_VALID:  rd_val = 32'(elog_valid_i);
      sf_asoc_cfg_pkg::R_SOC_ELOG_INFO:   rd_val = {elog_tag_i, 4'd0, 1'b0, elog_dom_i, 2'b00, elog_tgt_i, 3'b000, elog_src_i, 1'b0, elog_status_i, elog_fault_i};
      sf_asoc_cfg_pkg::R_SOC_ELOG_ADDR_LO: rd_val = elog_addr_i[31:0];
      sf_asoc_cfg_pkg::R_SOC_ELOG_ADDR_HI: rd_val = elog_addr_i[63:32];
      sf_asoc_cfg_pkg::R_SOC_ELOG_COUNT:  rd_val = elog_count_i;
      sf_asoc_cfg_pkg::R_SOC_POL_IDX:     rd_val = 32'(p_idx_q);
      sf_asoc_cfg_pkg::R_SOC_POL_SRC:     rd_val = 32'(p_src_q);
      sf_asoc_cfg_pkg::R_SOC_POL_DOM:     rd_val = 32'(p_dom_q);
      sf_asoc_cfg_pkg::R_SOC_POL_FLAGS:   rd_val = 32'(p_flags_q);
      sf_asoc_cfg_pkg::R_SOC_POL_BASE_LO: rd_val = p_base_lo_q;
      sf_asoc_cfg_pkg::R_SOC_POL_BASE_HI: rd_val = p_base_hi_q;
      sf_asoc_cfg_pkg::R_SOC_POL_MASK_LO: rd_val = p_mask_lo_q;
      sf_asoc_cfg_pkg::R_SOC_POL_MASK_HI: rd_val = p_mask_hi_q;
      sf_asoc_cfg_pkg::R_SOC_POL_GO:      rd_val = 32'd0;
      sf_asoc_cfg_pkg::R_SOC_POL_ENTRIES: rd_val = 32'(NENT);
      sf_asoc_cfg_pkg::R_SOC_SEC_EVENTS:  rd_val = sec_q;
      default: known = 1'b0;
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ld_q <= '0;
      cyc_lo_q <= 32'd0; cyc_hi_q <= 32'd0; cyc_hi_latch_q <= 32'd0; sec_q <= 32'd0;
      freeze_q <= 1'b0; psel_q <= 7'd0; p_idx_q <= 3'd0; p_src_q <= '0; p_dom_q <= '0; p_flags_q <= 4'd0;
      p_base_lo_q <= 32'd0; p_base_hi_q <= 32'd0; p_mask_lo_q <= 32'd0; p_mask_hi_q <= 32'd0;
      p_go_q <= 1'b0; clr_q <= 1'b0; eclr_q <= 1'b0; zf_q <= 1'b0; isoc_q <= '0;
      rv_q <= 1'b0; er_q <= 1'b0; rd_q <= 32'd0;
    end else begin
      if (ld_busy) ld_q <= ld_q + PIW'(1);
      {cyc_hi_q, cyc_lo_q} <= {cyc_hi_q, cyc_lo_q} + 64'd1;
      if (evt_sec_i && sec_q != 32'hFFFFFFFF) sec_q <= sec_q + 32'd1;
      rv_q <= req;
      er_q <= req && (!known || (wr && rb_addr_i == sf_asoc_cfg_pkg::R_SOC_POL_GO && ld_busy));
      clr_q <= 1'b0; eclr_q <= 1'b0; zf_q <= 1'b0; isoc_q <= '0; p_go_q <= 1'b0;
      if (req && !rb_we_i && rb_addr_i == sf_asoc_cfg_pkg::R_SOC_CYCLES_LO) cyc_hi_latch_q <= cyc_hi_q;
      if (wr) begin
        case (rb_addr_i)
          sf_asoc_cfg_pkg::R_SOC_CTRL: begin
            clr_q    <= rb_wdata_i[0];
            freeze_q <= rb_wdata_i[1];
            eclr_q   <= rb_wdata_i[2];
            zf_q     <= rb_wdata_i[3];
            isoc_q   <= rb_wdata_i[4 +: NT];
          end
          sf_asoc_cfg_pkg::R_SOC_PERF_SEL:    psel_q      <= rb_wdata_i[6:0];
          sf_asoc_cfg_pkg::R_SOC_POL_IDX:     p_idx_q     <= rb_wdata_i[2:0];
          sf_asoc_cfg_pkg::R_SOC_POL_SRC:     p_src_q     <= rb_wdata_i[NM-1:0];
          sf_asoc_cfg_pkg::R_SOC_POL_DOM:     p_dom_q     <= rb_wdata_i[NDOM-1:0];
          sf_asoc_cfg_pkg::R_SOC_POL_FLAGS:   p_flags_q   <= rb_wdata_i[3:0];
          sf_asoc_cfg_pkg::R_SOC_POL_BASE_LO: p_base_lo_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_SOC_POL_BASE_HI: p_base_hi_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_SOC_POL_MASK_LO: p_mask_lo_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_SOC_POL_MASK_HI: p_mask_hi_q <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_SOC_POL_GO:      if (rb_wdata_i[0] && !ld_busy) p_go_q <= 1'b1;
          default: ;
        endcase
      end
      rd_q <= rd_val;
    end
  end

  assign rb_rvalid_o = rv_q;
  assign rb_rdata_o  = rd_q;
  assign rb_err_o    = er_q;

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused;
  assign unused = ^rb_wdata_i[31:7];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
