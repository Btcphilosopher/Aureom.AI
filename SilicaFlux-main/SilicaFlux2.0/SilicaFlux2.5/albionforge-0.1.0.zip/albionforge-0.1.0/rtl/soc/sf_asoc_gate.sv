// =============================================================================
// AlbionForge :: sf_asoc_gate -- random back-pressure generator (verification aid, absent from the default build)
//
// Role      Produces `block_o`, a registered level a handshake owner ANDs into its valid / ready so that transfers are
//           delayed by a random number of cycles.  It is legal for every valid/ready channel because of ONE rule:
//             a block may START only while nothing is pending (pending_i = 0), and may only be RELEASED while something
//             is pending.  A valid that has been presented is therefore never withdrawn and no field changes under it.
// Param     PCT   probability (percent) that an idle cycle starts a block; 0 removes the logic (the default for synthesis).
//           SEED  xorshift32 seed (non-zero), different per instance.
// =============================================================================
`default_nettype none

module sf_asoc_gate #(
  parameter int unsigned PCT  = 0,
  parameter logic [31:0] SEED = 32'h1
) (
  input  wire logic clk_i,
  input  wire logic rst_ni,
  input  wire logic pending_i,
  output logic      block_o
);
  generate
    if (PCT == 0) begin : g_off
      assign block_o = 1'b0;
      /* verilator lint_off UNUSEDSIGNAL */
      logic unused;
      assign unused = clk_i ^ rst_ni ^ pending_i;
      /* verilator lint_on UNUSEDSIGNAL */
    end else begin : g_on
      localparam logic [15:0] THR = 16'((PCT * 65536) / 100);
      logic [31:0] x_q;
      logic        blk_q;
      logic [31:0] x_n;
      always_comb begin
        x_n = x_q;
        x_n = x_n ^ (x_n << 13);
        x_n = x_n ^ (x_n >> 17);
        x_n = x_n ^ (x_n << 5);
      end
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          x_q   <= (SEED == 32'd0) ? 32'h1 : SEED;
          blk_q <= 1'b0;
        end else begin
          x_q <= x_n;
          if (!pending_i)                     blk_q <= (x_n[15:0] < THR);      // start only while idle
          else if (blk_q && x_n[31:30] != 0) blk_q <= 1'b0;                  // release (3 in 4 per cycle) only while pending
        end
      end
      assign block_o = blk_q;
    end
  endgenerate
endmodule

`default_nettype wire
