// =============================================================================
// AlbionForge :: sf_asoc_axi_init -- CloudDMA AXI4 memory port -> ALP initiator (BridgeEngine memory port)
//
// Role      Integration glue.  CloudDMA's memory master (AXI4 subset: INCR bursts of up to 256 beats of 16 bytes,
//           IDs, no narrow transfers) becomes an ALP v1 initiator.  ALP has no bursts, so every burst is split into
//           single-word transactions: beat i of a burst at address A is the ALP word at A + 16*i.
// Contract  docs/albion/ARCHITECTURE_CONTRACT.md (ALP v1: one in-order link, 8-bit tags, bounded outstanding);
//           CloudDMA docs/04_INTEGRATION.md section 3 (memory-port contract the platform must honour).
//
// Resolves  * burst vs single-beat      split in the issue stage; the read and write issue paths share the one ALP link
//                                       (round robin when both are ready); one combined in-order queue remembers, for each
//                                       accepted word, what to do with its response (R beat / write-beat completion).
//           * IDs                       AXI IDs are kept in the queue and returned on R / B; ALP tags are an independent
//                                       free-running counter and are checked on every response (in-order link).
//           * domain binding            the ALP domain is a hardware parameter (DOM).  The AXI `domain` sideband the DMA
//                                       drives is only an INDEPENDENT SECOND CHECK (CloudDMA integration rule): a burst
//                                       whose sideband differs from EXPECT_DOM is refused locally.
//           * unsupported transfers     asid != 0 (only the device address space is reachable), size != 16 bytes,
//                                       burst != INCR or an address that is not 16-byte aligned are refused locally:
//                                       the burst is answered with SLVERR on every beat (reads: len+1 beats; writes: the
//                                       W beats are consumed and discarded, one B).  Nothing reaches the fabric.
//           * error mapping             ALP status OKAY -> OKAY; DECODE_ERR -> DECERR; every other status -> SLVERR.
//
// Ordering  Responses to reads and writes leave in the order the words were accepted on the link (ALP-ORD-01).
//           A write completes (B) only when ALL its beats have been acknowledged by the target (the DMA treats B as
//           "committed").  One error beat makes the whole burst's B an error.
// Capacity  Up to OQ_DEPTH words in flight; bursts wait in AR/AW FIFOs.  r_ready / b_ready may be low.
// Reset     rst_ni asynchronous assert.  No stale response survives (all FIFOs are cleared).
// =============================================================================
`default_nettype none

module sf_asoc_axi_init #(
  parameter int unsigned    ID_W       = 3,
  parameter int unsigned    AW         = 40,
  parameter int unsigned    DOM_W      = 4,
  parameter logic [DOM_W-1:0] EXPECT_DOM = 4'd1,
  parameter logic [7:0]     DOM        = 8'd1,
  parameter logic [7:0]     ATTR       = 8'h22,
  parameter int unsigned    AR_DEPTH   = 4,
  parameter int unsigned    AW_DEPTH   = 4,
  parameter int unsigned    OQ_DEPTH   = 16,
  parameter int unsigned    STALL_PCT  = 0,
  parameter logic [31:0]    STALL_SEED = 32'h4BADB002
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // ---------------------------------------------------------------- AXI4 slave side (from CloudDMA m_*)
  input  wire logic              ar_valid_i,
  output logic                   ar_ready_o,
  input  wire logic [ID_W-1:0]   ar_id_i,
  input  wire logic [AW-1:0]     ar_addr_i,
  input  wire logic [7:0]        ar_len_i,
  input  wire logic [2:0]        ar_size_i,
  input  wire logic [1:0]        ar_burst_i,
  input  wire logic [3:0]        ar_asid_i,
  input  wire logic [DOM_W-1:0]  ar_domain_i,
  output logic                   r_valid_o,
  input  wire logic              r_ready_i,
  output logic [ID_W-1:0]        r_id_o,
  output logic [127:0]           r_data_o,
  output logic [1:0]             r_resp_o,
  output logic                   r_last_o,
  input  wire logic              aw_valid_i,
  output logic                   aw_ready_o,
  input  wire logic [ID_W-1:0]   aw_id_i,
  input  wire logic [AW-1:0]     aw_addr_i,
  input  wire logic [7:0]        aw_len_i,
  input  wire logic [2:0]        aw_size_i,
  input  wire logic [1:0]        aw_burst_i,
  input  wire logic [3:0]        aw_asid_i,
  input  wire logic [DOM_W-1:0]  aw_domain_i,
  input  wire logic              w_valid_i,
  output logic                   w_ready_o,
  input  wire logic [127:0]      w_data_i,
  input  wire logic [15:0]       w_strb_i,
  input  wire logic              w_last_i,
  output logic                   b_valid_o,
  input  wire logic              b_ready_i,
  output logic [ID_W-1:0]        b_id_o,
  output logic [1:0]             b_resp_o,
  // ---------------------------------------------------------------- ALP master side
  output logic                                      m_req_valid_o,
  input  wire logic                                 m_req_ready_i,
  output logic [sf_albion_pkg::SF_OP_W-1:0]         m_req_op_o,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]        m_req_tag_o,
  output logic [sf_albion_pkg::SF_DOM_W-1:0]        m_req_dom_o,
  output logic [sf_albion_pkg::SF_ATTR_W-1:0]       m_req_attr_o,
  output logic [sf_albion_pkg::SF_ADDR_W-1:0]       m_req_addr_o,
  output logic [sf_albion_pkg::SF_BE_W-1:0]         m_req_be_o,
  output logic [sf_albion_pkg::SF_DATA_W-1:0]       m_req_data_o,
  input  wire logic                                 m_rsp_valid_i,
  output logic                                      m_rsp_ready_o,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]   m_rsp_tag_i,
  input  wire logic [sf_albion_pkg::SF_STATUS_W-1:0] m_rsp_status_i,
  input  wire logic [sf_albion_pkg::SF_CMETA_W-1:0] m_rsp_meta_i,
  input  wire logic [sf_albion_pkg::SF_DATA_W-1:0]  m_rsp_data_i,
  // ---------------------------------------------------------------- event pulses
  output logic             evt_err_o,        // an error response (SLVERR / DECERR) was returned to the DMA (per R beat / per B)
  output logic             evt_refused_o,    // a burst was refused locally (sideband / unsupported transfer)
  output logic             evt_proto_o       // an ALP response whose tag was not the expected one
);
  localparam logic [3:0] ST_OK  = 4'h0;
  localparam logic [3:0] ST_DEC = 4'h1;

  // ------------------------------------------------------------------ AR / AW queues
  localparam int unsigned ARW = 1 + ID_W + AW + 8;
  logic              arq_v, arq_r;
  logic [ARW-1:0]    arq_d;
  logic              awq_v, awq_r;
  logic [ARW-1:0]    awq_d;
  logic              ar_in_ready, aw_in_ready;

  logic ar_bad_in, aw_bad_in;
  assign ar_bad_in = (ar_domain_i != EXPECT_DOM) || (ar_asid_i != 4'd0) || (ar_size_i != 3'd4) ||
                     (ar_burst_i != 2'b01) || (ar_addr_i[3:0] != 4'd0);
  assign aw_bad_in = (aw_domain_i != EXPECT_DOM) || (aw_asid_i != 4'd0) || (aw_size_i != 3'd4) ||
                     (aw_burst_i != 2'b01) || (aw_addr_i[3:0] != 4'd0);

  sf_albion_fifo #(.WIDTH(ARW), .DEPTH(AR_DEPTH)) u_arq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i(ar_valid_i), .in_ready_o(ar_in_ready), .in_data_i({ar_bad_in, ar_id_i, ar_addr_i, ar_len_i}),
    .out_valid_o(arq_v), .out_ready_i(arq_r), .out_data_o(arq_d),
    .count_o(), .full_o(), .empty_o());
  sf_albion_fifo #(.WIDTH(ARW), .DEPTH(AW_DEPTH)) u_awq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i(aw_valid_i), .in_ready_o(aw_in_ready), .in_data_i({aw_bad_in, aw_id_i, aw_addr_i, aw_len_i}),
    .out_valid_o(awq_v), .out_ready_i(awq_r), .out_data_o(awq_d),
    .count_o(), .full_o(), .empty_o());
  assign ar_ready_o = ar_in_ready;
  assign aw_ready_o = aw_in_ready;
  assign evt_refused_o = (ar_valid_i && ar_in_ready && ar_bad_in) || (aw_valid_i && aw_in_ready && aw_bad_in);

  logic              ar_bad, aw_bad;
  logic [ID_W-1:0]   ar_id, aw_id;
  logic [AW-1:0]     ar_addr, aw_addr;
  logic [7:0]        ar_len, aw_len;
  assign {ar_bad, ar_id, ar_addr, ar_len} = arq_d;
  assign {aw_bad, aw_id, aw_addr, aw_len} = awq_d;

  // ------------------------------------------------------------------ outstanding queue (in-order responses)
  localparam int unsigned OQW = 3 + ID_W;       // {is_wr, local, last, id}
  logic            oq_in_v, oq_in_ready, oq_out_v, oq_out_r;
  logic [OQW-1:0]  oq_in_d, oq_out_d;
  sf_albion_fifo #(.WIDTH(OQW), .DEPTH(OQ_DEPTH)) u_oq (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i(oq_in_v), .in_ready_o(oq_in_ready), .in_data_i(oq_in_d),
    .out_valid_o(oq_out_v), .out_ready_i(oq_out_r), .out_data_o(oq_out_d),
    .count_o(), .full_o(), .empty_o());

  // ------------------------------------------------------------------ issue stage
  logic [8:0]  ar_beat_q, aw_beat_q;
  logic        turn_q;                       // 0: read side preferred, 1: write side preferred
  logic [7:0]  tag_q;
  logic        rd_cand, wr_cand, pick_rd, pick_wr, rd_last, wr_last, rd_fire, wr_fire;

  assign rd_last = (ar_beat_q[7:0] == ar_len);
  assign wr_last = (aw_beat_q[7:0] == aw_len);
  logic lock_q, lock_wr_q;                   // an ALP request was presented and not yet accepted: keep the side (ALP: hold valid + fields)
  logic pick_rd_raw, pick_wr_raw;
  assign rd_cand = arq_v && oq_in_ready;
  assign wr_cand = awq_v && w_valid_i && oq_in_ready;
  assign pick_rd_raw = rd_cand && (!wr_cand || !turn_q);
  assign pick_wr_raw = wr_cand && (!rd_cand || turn_q);
  assign pick_rd = lock_q ? !lock_wr_q : pick_rd_raw;
  assign pick_wr = lock_q ?  lock_wr_q : pick_wr_raw;

  assign m_req_valid_o = (pick_rd && !ar_bad) || (pick_wr && !aw_bad);
  assign m_req_op_o    = pick_wr ? 4'h2 : 4'h1;
  assign m_req_tag_o   = tag_q;
  assign m_req_dom_o   = DOM;
  assign m_req_attr_o  = ATTR;
  assign m_req_addr_o  = pick_wr ? ({{(64-AW){1'b0}}, aw_addr} + {51'd0, aw_beat_q, 4'd0})
                                 : ({{(64-AW){1'b0}}, ar_addr} + {51'd0, ar_beat_q, 4'd0});
  assign m_req_be_o    = pick_wr ? w_strb_i : 16'hFFFF;
  assign m_req_data_o  = pick_wr ? w_data_i : 128'd0;

  assign rd_fire = pick_rd && (ar_bad || m_req_ready_i);
  assign wr_fire = pick_wr && (aw_bad || m_req_ready_i);
  assign w_ready_o = wr_fire;
  assign arq_r = rd_fire && rd_last;
  assign awq_r = wr_fire && wr_last;

  assign oq_in_v = rd_fire || wr_fire;
  assign oq_in_d = wr_fire ? {1'b1, aw_bad, wr_last, aw_id} : {1'b0, ar_bad, rd_last, ar_id};

  logic alp_fire;
  assign alp_fire = m_req_valid_o && m_req_ready_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ar_beat_q <= 9'd0;
      aw_beat_q <= 9'd0;
      turn_q    <= 1'b0;
      tag_q     <= 8'd0;
      lock_q    <= 1'b0;
      lock_wr_q <= 1'b0;
    end else begin
      if (m_req_valid_o && !m_req_ready_i) begin lock_q <= 1'b1; lock_wr_q <= pick_wr; end
      else                                  lock_q <= 1'b0;
      if (rd_fire) ar_beat_q <= rd_last ? 9'd0 : ar_beat_q + 9'd1;
      if (wr_fire) aw_beat_q <= wr_last ? 9'd0 : aw_beat_q + 9'd1;
      if (rd_fire || wr_fire) turn_q <= pick_rd;      // the other side goes first next time
      if (alp_fire) tag_q <= tag_q + 8'd1;
    end
  end

  // ------------------------------------------------------------------ response stage
  logic              h_wr, h_local, h_last;
  logic [ID_W-1:0]   h_id;
  assign {h_wr, h_local, h_last, h_id} = oq_out_d;

  logic [7:0]  exp_tag_q;
  logic        werr_q;
  logic        rsp_tag_ok, rsp_ok, rsp_dec;
  assign rsp_tag_ok = (m_rsp_tag_i == exp_tag_q);
  assign rsp_ok     = (m_rsp_status_i == ST_OK) && rsp_tag_ok;
  assign rsp_dec    = (m_rsp_status_i == ST_DEC) && rsp_tag_ok;

  logic [1:0] rd_resp;
  always_comb begin
    if (h_local)      rd_resp = 2'b10;
    else if (rsp_ok)  rd_resp = 2'b00;
    else if (rsp_dec) rd_resp = 2'b11;
    else              rd_resp = 2'b10;
  end

  logic head_rd, head_wr_mid, head_wr_last;
  logic blk;
  sf_asoc_gate #(.PCT(STALL_PCT), .SEED(STALL_SEED)) u_gate (
    .clk_i, .rst_ni, .pending_i(oq_out_v && (h_local || m_rsp_valid_i)), .block_o(blk));
  assign head_rd      = oq_out_v && !h_wr && !blk;
  assign head_wr_mid  = oq_out_v && h_wr && !h_last && !blk;
  assign head_wr_last = oq_out_v && h_wr && h_last && !blk;

  assign r_valid_o = head_rd && (h_local || m_rsp_valid_i);
  assign r_id_o    = h_id;
  assign r_data_o  = (h_local || !rsp_ok) ? 128'd0 : m_rsp_data_i;
  assign r_resp_o  = rd_resp;
  assign r_last_o  = h_last;

  // write burst completion: any failed beat makes the burst an error; DECERR only if EVERY failed beat was a decode error
  logic       this_err, this_dec, any_err, all_dec, wdec_q;
  logic [1:0] wb_resp;
  assign this_err = h_local || !rsp_ok;
  assign this_dec = !h_local && rsp_dec;
  assign any_err  = werr_q || this_err;
  assign all_dec  = (werr_q ? wdec_q : 1'b1) && (this_err ? this_dec : 1'b1);
  assign wb_resp  = !any_err ? 2'b00 : (all_dec ? 2'b11 : 2'b10);
  assign b_valid_o = head_wr_last && (h_local || m_rsp_valid_i);
  assign b_id_o    = h_id;
  assign b_resp_o  = wb_resp;

  // ALP response ready: the head is a forwarded word and its consumer can take it
  assign m_rsp_ready_o = oq_out_v && !h_local && !blk && (h_wr ? (h_last ? b_ready_i : 1'b1) : r_ready_i);

  logic rd_pop, wr_mid_pop, wr_last_pop, rsp_consume;
  assign rd_pop      = r_valid_o && r_ready_i;
  assign wr_mid_pop  = head_wr_mid && (h_local || m_rsp_valid_i);
  assign wr_last_pop = b_valid_o && b_ready_i;
  assign oq_out_r    = rd_pop || wr_mid_pop || wr_last_pop;
  assign rsp_consume = m_rsp_valid_i && m_rsp_ready_o;

  assign evt_proto_o = rsp_consume && !rsp_tag_ok;
  assign evt_err_o   = (rd_pop && (r_resp_o != 2'b00)) || (wr_last_pop && (b_resp_o != 2'b00));

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      exp_tag_q <= 8'd0;
      werr_q    <= 1'b0;
      wdec_q    <= 1'b0;
    end else begin
      if (rsp_consume) exp_tag_q <= exp_tag_q + 8'd1;
      if (wr_last_pop) begin
        werr_q <= 1'b0;
        wdec_q <= 1'b0;
      end else if (wr_mid_pop && this_err) begin
        werr_q <= 1'b1;
        wdec_q <= (werr_q ? wdec_q : 1'b1) && this_dec;
      end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_meta;
  assign unused_meta = (^m_rsp_meta_i) ^ w_last_i;   // w_last is implied by the AW length (checked by the DMA bench)
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
