// =============================================================================
// AlbionForge :: sf_asoc_iron_alp -- IronMemory (Project 84) behind NP ALP v1 target links
//
// Role      The shared device SRAM of the minimum Albion SoC.  Instantiates sf_iron_memory (NUM_PORTS = NP, ECC SECDED,
//           four word-interleaved banks) and presents each of its master ports as an ALP v1 target at 128-bit width:
//           per port  128-bit ALP link -> sf_albion_width_adapter (DOWNSIZE, 2 beats of 64 bit) -> sf_asoc_iron_port.
//           Port p carries the traffic of source master p; IronMemory's PORT_DOMAIN_MAP binds port p to ownership domain p
//           (port 0 = ControlCore domain 0, port 1 = BridgeEngine domain 1) in hardware.
// Also      exposes IronMemory's CSR port and buffer-manager command port (driven by sf_asoc_iron_ctl) and init_done / irq.
//           The external-memory channel is not used (EXT_EN = 0): its ports are tied off.
// Contract  ALP v1 (wide side) / IronMemory interfaces (narrow side).  The downsizing adapter handles one wide transaction
//           at a time per port, so one 16-byte word costs two memory beats: stated in docs/PERFORMANCE.md.
// Reset     rst_ni asynchronous assert; IronMemory initialises (zeroes + ECC) its arrays after reset (init_done).
// =============================================================================
`default_nettype none

module sf_asoc_iron_alp #(
  parameter int unsigned NP = 2
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  // ---------------------------------------------------------------- ALP target links (NP copies, concatenated)
  input  wire logic [NP-1:0]     s_req_valid_i,
  output logic      [NP-1:0]     s_req_ready_o,
  input  wire logic [NP*4-1:0]   s_req_op_i,
  input  wire logic [NP*8-1:0]   s_req_tag_i,
  input  wire logic [NP*8-1:0]   s_req_dom_i,
  input  wire logic [NP*8-1:0]   s_req_attr_i,
  input  wire logic [NP*64-1:0]  s_req_addr_i,
  input  wire logic [NP*16-1:0]  s_req_be_i,
  input  wire logic [NP*128-1:0] s_req_data_i,
  output logic      [NP-1:0]     s_rsp_valid_o,
  input  wire logic [NP-1:0]     s_rsp_ready_i,
  output logic      [NP*8-1:0]   s_rsp_tag_o,
  output logic      [NP*4-1:0]   s_rsp_status_o,
  output logic      [NP*8-1:0]   s_rsp_meta_o,
  output logic      [NP*128-1:0] s_rsp_data_o,
  // ---------------------------------------------------------------- buffer-manager command port
  input  wire logic              bm_cmd_valid_i,
  output logic                   bm_cmd_ready_o,
  input  wire logic [2:0]        bm_cmd_op_i,
  input  wire logic [2:0]        bm_cmd_requester_i,
  input  wire logic [3:0]        bm_cmd_id_i,
  input  wire logic [2:0]        bm_cmd_btype_i,
  input  wire logic [39:0]       bm_cmd_start_i,
  input  wire logic [16:0]       bm_cmd_len_i,
  input  wire logic [2:0]        bm_cmd_owner_i,
  input  wire logic [4:0]        bm_cmd_rd_mask_i,
  input  wire logic [4:0]        bm_cmd_wr_mask_i,
  output logic                   bm_rsp_valid_o,
  output logic [3:0]             bm_rsp_status_o,
  output logic [3:0]             bm_rsp_id_o,
  output logic                   bm_rsp_in_use_o,
  output logic [2:0]             bm_rsp_btype_o,
  output logic [39:0]            bm_rsp_start_o,
  output logic [16:0]            bm_rsp_len_o,
  output logic [2:0]             bm_rsp_owner_o,
  output logic [4:0]             bm_rsp_rd_mask_o,
  output logic [4:0]             bm_rsp_wr_mask_o,
  output logic [7:0]             bm_rsp_err_bits_o,
  // ---------------------------------------------------------------- CSR port
  input  wire logic              csr_valid_i,
  input  wire logic              csr_we_i,
  input  wire logic [11:0]       csr_addr_i,
  input  wire logic [31:0]       csr_wdata_i,
  output logic                   csr_rvalid_o,
  output logic [31:0]            csr_rdata_o,
  output logic                   csr_err_o,
  // ---------------------------------------------------------------- status
  output logic                   init_done_o,
  output logic                   irq_o
);
  localparam int unsigned AW = sf_asoc_cfg_pkg::IRON_AW;

  logic [NP-1:0]    i_req_valid, i_req_ready, i_rsp_valid, i_rsp_ready, i_rsp_corr;
  logic [NP*AW-1:0] i_req_addr;
  logic [NP*3-1:0]  i_req_size, i_rsp_err;
  logic [NP-1:0]    i_req_we;
  logic [NP*64-1:0] i_req_wdata, i_rsp_rdata;
  logic [NP*8-1:0]  i_req_wstrb;

  generate
    for (genvar p = 0; p < NP; p++) begin : g_port
      // wide -> narrow
      logic        n_req_valid, n_req_ready, n_rsp_valid, n_rsp_ready;
      logic [3:0]  n_req_op;
      logic [7:0]  n_req_tag, n_req_dom, n_req_attr;
      logic [63:0] n_req_addr;
      logic [7:0]  n_req_be;
      logic [63:0] n_req_data;
      logic [7:0]  n_rsp_tag, n_rsp_meta;
      logic [3:0]  n_rsp_status;
      logic [63:0] n_rsp_data;

      sf_albion_width_adapter #(.DOWNSIZE(1'b1), .NARROW_W(64), .MAX_OUT(2)) u_dn (
        .clk_i, .rst_ni,
        .s_req_valid_i (s_req_valid_i[p]),
        .s_req_ready_o (s_req_ready_o[p]),
        .s_req_op_i    (s_req_op_i[p*4 +: 4]),
        .s_req_tag_i   (s_req_tag_i[p*8 +: 8]),
        .s_req_dom_i   (s_req_dom_i[p*8 +: 8]),
        .s_req_attr_i  (s_req_attr_i[p*8 +: 8]),
        .s_req_addr_i  (s_req_addr_i[p*64 +: 64]),
        .s_req_be_i    (s_req_be_i[p*16 +: 16]),
        .s_req_data_i  (s_req_data_i[p*128 +: 128]),
        .s_rsp_valid_o (s_rsp_valid_o[p]),
        .s_rsp_ready_i (s_rsp_ready_i[p]),
        .s_rsp_tag_o   (s_rsp_tag_o[p*8 +: 8]),
        .s_rsp_status_o(s_rsp_status_o[p*4 +: 4]),
        .s_rsp_meta_o  (s_rsp_meta_o[p*8 +: 8]),
        .s_rsp_data_o  (s_rsp_data_o[p*128 +: 128]),
        .m_req_valid_o (n_req_valid), .m_req_ready_i(n_req_ready),
        .m_req_op_o    (n_req_op), .m_req_tag_o(n_req_tag), .m_req_dom_o(n_req_dom), .m_req_attr_o(n_req_attr),
        .m_req_addr_o  (n_req_addr), .m_req_be_o(n_req_be), .m_req_data_o(n_req_data),
        .m_rsp_valid_i (n_rsp_valid), .m_rsp_ready_o(n_rsp_ready), .m_rsp_tag_i(n_rsp_tag),
        .m_rsp_status_i(n_rsp_status), .m_rsp_meta_i(n_rsp_meta), .m_rsp_data_i(n_rsp_data));

      /* verilator lint_off UNUSEDSIGNAL */
      logic unused_dom_attr;
      assign unused_dom_attr = ^n_req_dom ^ ^n_req_attr;    // ownership is the port's hardware domain binding
      /* verilator lint_on UNUSEDSIGNAL */

      sf_asoc_iron_port #(.AW(AW), .QD(4)) u_port (
        .clk_i, .rst_ni,
        .s_req_valid_i (n_req_valid), .s_req_ready_o(n_req_ready),
        .s_req_op_i    (n_req_op), .s_req_tag_i(n_req_tag), .s_req_addr_i(n_req_addr),
        .s_req_be_i    (n_req_be), .s_req_data_i(n_req_data),
        .s_rsp_valid_o (n_rsp_valid), .s_rsp_ready_i(n_rsp_ready), .s_rsp_tag_o(n_rsp_tag),
        .s_rsp_status_o(n_rsp_status), .s_rsp_meta_o(n_rsp_meta), .s_rsp_data_o(n_rsp_data),
        .i_req_valid_o (i_req_valid[p]), .i_req_ready_i(i_req_ready[p]),
        .i_req_addr_o  (i_req_addr[p*AW +: AW]), .i_req_size_o(i_req_size[p*3 +: 3]), .i_req_we_o(i_req_we[p]),
        .i_req_wdata_o (i_req_wdata[p*64 +: 64]), .i_req_wstrb_o(i_req_wstrb[p*8 +: 8]),
        .i_rsp_valid_i (i_rsp_valid[p]), .i_rsp_ready_o(i_rsp_ready[p]), .i_rsp_rdata_i(i_rsp_rdata[p*64 +: 64]),
        .i_rsp_err_i   (i_rsp_err[p*3 +: 3]), .i_rsp_corr_i(i_rsp_corr[p]));
    end
  endgenerate

  sf_iron_memory #(
    .NUM_PORTS(NP),
    .PORT_DOMAIN_MAP(24'o00000010),       // port 0 -> domain 0 (ControlCore), port 1 -> domain 1 (BridgeEngine)
    .AW(AW),
    .DW(64),
    .NUM_BANKS(sf_asoc_cfg_pkg::IRON_BANKS),
    .BANK_DEPTH(sf_asoc_cfg_pkg::IRON_DEPTH),
    .RL(sf_asoc_cfg_pkg::IRON_RL),
    .INTERLEAVE(1),
    .SRAM_BASE(sf_asoc_cfg_pkg::IRON_SRAM_BASE),
    .ECC_EN(sf_asoc_cfg_pkg::IRON_ECC),
    .BACKEND(sf_asoc_cfg_pkg::IRON_BACKEND),
    .MAX_OUT(sf_asoc_cfg_pkg::IRON_MAX_OUT),
    .NUM_DESC(sf_asoc_cfg_pkg::IRON_NUM_DESC),
    .GRAN_BYTES(sf_asoc_cfg_pkg::IRON_GRAN_BYTES),
    .EXT_EN(sf_asoc_cfg_pkg::IRON_EXT_EN)
  ) u_iron (
    .clk(clk_i), .rst_n(rst_ni),
    .m_req_valid(i_req_valid), .m_req_ready(i_req_ready), .m_req_addr(i_req_addr), .m_req_size(i_req_size),
    .m_req_we(i_req_we), .m_req_wdata(i_req_wdata), .m_req_wstrb(i_req_wstrb),
    .m_rsp_valid(i_rsp_valid), .m_rsp_ready(i_rsp_ready), .m_rsp_rdata(i_rsp_rdata), .m_rsp_err(i_rsp_err),
    .m_rsp_ecc_corr(i_rsp_corr),
    .bm_cmd_valid(bm_cmd_valid_i), .bm_cmd_ready(bm_cmd_ready_o), .bm_cmd_op(bm_cmd_op_i),
    .bm_cmd_requester(bm_cmd_requester_i), .bm_cmd_id(bm_cmd_id_i), .bm_cmd_btype(bm_cmd_btype_i),
    .bm_cmd_start(bm_cmd_start_i), .bm_cmd_len(bm_cmd_len_i), .bm_cmd_owner(bm_cmd_owner_i),
    .bm_cmd_rd_mask(bm_cmd_rd_mask_i), .bm_cmd_wr_mask(bm_cmd_wr_mask_i),
    .bm_rsp_valid(bm_rsp_valid_o), .bm_rsp_status(bm_rsp_status_o), .bm_rsp_id(bm_rsp_id_o),
    .bm_rsp_in_use(bm_rsp_in_use_o), .bm_rsp_btype(bm_rsp_btype_o), .bm_rsp_start(bm_rsp_start_o),
    .bm_rsp_len(bm_rsp_len_o), .bm_rsp_owner(bm_rsp_owner_o), .bm_rsp_rd_mask(bm_rsp_rd_mask_o),
    .bm_rsp_wr_mask(bm_rsp_wr_mask_o), .bm_rsp_err_bits(bm_rsp_err_bits_o),
    .csr_valid(csr_valid_i), .csr_we(csr_we_i), .csr_addr(csr_addr_i), .csr_wdata(csr_wdata_i),
    .csr_rvalid(csr_rvalid_o), .csr_rdata(csr_rdata_o), .csr_err(csr_err_o),
    // external memory channel: not used (EXT_EN = 0)
    .ext_cmd_valid(), .ext_cmd_ready(1'b0), .ext_cmd_we(), .ext_cmd_addr(), .ext_cmd_wdata(), .ext_cmd_wstrb(),
    .ext_cmd_tag(), .ext_rsp_valid(1'b0), .ext_rsp_ready(), .ext_rsp_rdata('0), .ext_rsp_err(1'b0), .ext_rsp_tag('0),
    .init_done(init_done_o), .irq(irq_o),
    .trc_valid(), .trc_port(), .trc_seq(), .trc_we(), .trc_word(), .trc_be(), .trc_wdata()
  );
endmodule

`default_nettype wire
