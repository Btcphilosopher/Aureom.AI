// =============================================================================
// AlbionForge :: sf_albion_soc_min -- the minimum Albion SoC (top level)
//
//   host (hs_* SFB2 slave) --> ControlCore (RV32IM, boot ROM, I/D SRAM, mailbox, perf)  [Project 21, unmodified]
//                                   | ext_* (SFB2 master, 32-bit)
//                          sf_asoc_sfb2_init  (SFB2 -> ALP v1, window translation)           master 0, domain 0
//                                   |
//   CloudDMA (BridgeEngine) --AXI4--> sf_asoc_axi_init (burst -> ALP words)                  master 1, domain 1
//                                   |
//                          sf_asoc_mer_core = Meridian fabric [Project 83] (2 x 4, Citadel reference policy)
//                                   |  t0 sram      t1 sram_ctl     t2 dma         t3 soc_ctl
//                          sf_asoc_mer_tgt x4   (Meridian target format -> ALP links)
//                                   |            regtgt + iron_ctl  regtgt + dma_ctl regtgt + soc_ctl
//                          sf_asoc_iron_alp = IronMemory [Project 84] (ECC SRAM, 2 ports, buffer manager)
//
//   Everything below the ControlCore runs in the ControlCore-derived `acc_rst_no` domain, so a ControlCore soft / watchdog /
//   host reset resets the fabric, memory and DMA together (no stale transaction survives).  One clock.
//
// Not implemented here (documented limitations, docs/LIMITATIONS.md): real Citadel (reference model only), ControlCore
// accelerators (register pages 8..15 answer a bus error), device-memory boot (boot_mode 1), interrupts from the DMA and the
// memory (polled; the lines feed the RAS "SoC warning" input), clock gating (acc_clk_o is not used), external memory.
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sf_albion_soc_min #(
  parameter int CC_SRAM_BACKEND = `SRAM_BACKEND_GENERIC,  // ControlCore control SRAMs: generic arrays or FPGA block RAM
  parameter int unsigned STALL_PCT = 0,                   // verification: random back-pressure on the fabric / bridge handshakes (0 = none, no logic)
  parameter logic [31:0] STALL_SEED = 32'h1BADB002        // verification: seed of the back-pressure generators
) (
  input  wire logic        clk,
  input  wire logic        rst_ni,
  input  wire logic        test_mode,
  input  wire logic [1:0]  boot_mode_i,
  input  wire logic        host_rst_req_i,
  // ---------------------------------------------------------------- host access port (ControlCore SFB2 slave)
  input  wire logic        hs_req_valid,
  output logic             hs_req_ready,
  input  wire logic        hs_req_write,
  input  wire logic [31:0] hs_req_addr,
  input  wire logic [31:0] hs_req_wdata,
  input  wire logic [3:0]  hs_req_wstrb,
  output logic             hs_rsp_valid,
  input  wire logic        hs_rsp_ready,
  output logic [31:0]      hs_rsp_rdata,
  output logic             hs_rsp_error,
  output logic             host_irq_o,
  output logic             host_ready_o,
  output logic             ras_fatal_o,
  // ---------------------------------------------------------------- diagnostics (simulation / lab taps)
  output logic             diag_valid_o,
  output logic [7:0]       diag_char_o,
  output logic             test_done_o,
  output logic             test_fail_o,
  output logic [15:0]      test_code_o,
  output logic             cpu_sleep_o,
  output logic             iron_init_done_o,
  output logic             fabric_rst_no_o
);
  localparam int unsigned NM = sf_asoc_cfg_pkg::MER_NM;
  localparam int unsigned NT = sf_asoc_cfg_pkg::MER_NT;
  localparam int unsigned DOMW = sf_asoc_cfg_pkg::MER_DOMW;
  localparam int unsigned TAGW = sf_asoc_cfg_pkg::MER_TAGW;
  localparam int unsigned SRCW = sf_meridian_pkg::clog2c(NM);
  localparam int unsigned DAW  = sf_asoc_cfg_pkg::DMA_AW;
  localparam int unsigned DDW  = sf_asoc_cfg_pkg::DMA_DOM_W;
  // CloudDMA ID width: {channel, class, slot} -- 1 + (log2(max(RD_OUT,WR_OUT)) + 1) for one channel
  localparam int unsigned DMA_MXO  = (sf_asoc_cfg_pkg::DMA_RD_OUT > sf_asoc_cfg_pkg::DMA_WR_OUT) ? sf_asoc_cfg_pkg::DMA_RD_OUT : sf_asoc_cfg_pkg::DMA_WR_OUT;
  localparam int unsigned DMA_SW   = (DMA_MXO > 1) ? $clog2(DMA_MXO) : 1;
  localparam int unsigned DMA_IDW  = 1 + DMA_SW + 1;

  // ------------------------------------------------------------------ ControlCore
  logic        acc_rst_n, acc_clk_unused;
  logic        ext_req_valid, ext_req_ready, ext_req_write, ext_rsp_valid, ext_rsp_ready, ext_rsp_error;
  logic [31:0] ext_req_addr, ext_req_wdata, ext_rsp_rdata;
  logic [3:0]  ext_req_wstrb;
  logic        iron_irq, dma_irq;
  logic        cmdproc_ready_unused;

  silicaflux_control_core #(.RV32M(1), .SRAM_PARITY(1), .SRAM_BACKEND(CC_SRAM_BACKEND)) u_cc (
    .clk, .rst_ni, .test_mode, .boot_mode_i, .host_rst_req_i,
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o, .host_ready_o, .cmdproc_ready_o(cmdproc_ready_unused), .ras_fatal_o,
    // accelerator register pages 8..15: no accelerator in the minimum SoC -> bus error
    .acc_rb_sel(), .acc_rb_we(), .acc_rb_addr(), .acc_rb_wdata(), .acc_rb_rdata(32'd0), .acc_rb_err(1'b1),
    .ext_req_valid, .ext_req_ready, .ext_req_write, .ext_req_addr, .ext_req_wdata, .ext_req_wstrb,
    .ext_rsp_valid, .ext_rsp_ready, .ext_rsp_rdata, .ext_rsp_error,
    .acc_clk_o(acc_clk_unused), .acc_rst_no(acc_rst_n),
    .acc_vec_irq_i(1'b0), .acc_tsu_irq_i(1'b0), .acc_vec_busy_i(1'b0), .acc_tsu_busy_i(1'b0), .acc_tsu_halted_i(1'b0),
    .ext_warn_i(iron_irq || dma_irq), .ext_fatal_i(1'b0),
    .diag_valid_o, .diag_char_o, .test_done_o, .test_fail_o, .test_code_o, .cpu_sleep_o
  );
  assign fabric_rst_no_o = acc_rst_n;

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_cc;
  assign unused_cc = acc_clk_unused ^ cmdproc_ready_unused;
  /* verilator lint_on UNUSEDSIGNAL */

  // ------------------------------------------------------------------ master 0: ControlCore ext port -> ALP
  logic        c_req_valid, c_req_ready, c_rsp_valid, c_rsp_ready;
  logic [3:0]  c_req_op, c_rsp_status;
  logic [7:0]  c_req_tag, c_req_dom, c_req_attr, c_rsp_tag, c_rsp_meta;
  logic [63:0] c_req_addr;
  logic [15:0] c_req_be;
  logic [127:0] c_req_data, c_rsp_data;
  logic        c_evt_req, c_evt_err, c_evt_miss;

  sf_asoc_sfb2_init #(
    .NW(sf_asoc_cfg_pkg::CCW_N), .WIN_BASE(sf_asoc_cfg_pkg::CCW_SRC_BASE), .WIN_MASK(sf_asoc_cfg_pkg::CCW_SRC_MASK),
    .WIN_DST(sf_asoc_cfg_pkg::CCW_DST_BASE), .DOM(sf_asoc_cfg_pkg::DOM_CC), .ATTR(sf_asoc_cfg_pkg::ATTR_CC),
    .STALL_PCT(STALL_PCT), .STALL_SEED(STALL_SEED ^ 32'h3BADB002)
  ) u_cc_init (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .s_req_valid_i(ext_req_valid), .s_req_ready_o(ext_req_ready), .s_req_write_i(ext_req_write),
    .s_req_addr_i(ext_req_addr), .s_req_wdata_i(ext_req_wdata), .s_req_wstrb_i(ext_req_wstrb),
    .s_rsp_valid_o(ext_rsp_valid), .s_rsp_ready_i(ext_rsp_ready), .s_rsp_rdata_o(ext_rsp_rdata), .s_rsp_error_o(ext_rsp_error),
    .m_req_valid_o(c_req_valid), .m_req_ready_i(c_req_ready), .m_req_op_o(c_req_op), .m_req_tag_o(c_req_tag),
    .m_req_dom_o(c_req_dom), .m_req_attr_o(c_req_attr), .m_req_addr_o(c_req_addr), .m_req_be_o(c_req_be),
    .m_req_data_o(c_req_data),
    .m_rsp_valid_i(c_rsp_valid), .m_rsp_ready_o(c_rsp_ready), .m_rsp_tag_i(c_rsp_tag), .m_rsp_status_i(c_rsp_status),
    .m_rsp_meta_i(c_rsp_meta), .m_rsp_data_i(c_rsp_data),
    .evt_req_o(c_evt_req), .evt_err_o(c_evt_err), .evt_miss_o(c_evt_miss));

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_cevt;
  assign unused_cevt = c_evt_req ^ c_evt_err ^ c_evt_miss;
  /* verilator lint_on UNUSEDSIGNAL */

  // ------------------------------------------------------------------ master 1: CloudDMA (BridgeEngine)
  logic                 d_ar_valid, d_ar_ready, d_r_valid, d_r_ready, d_r_last;
  logic [DMA_IDW-1:0]   d_ar_id, d_r_id, d_aw_id, d_b_id;
  logic [DAW-1:0]       d_ar_addr, d_aw_addr;
  logic [7:0]           d_ar_len, d_aw_len;
  logic [2:0]           d_ar_size, d_aw_size;
  logic [1:0]           d_ar_burst, d_aw_burst, d_r_resp, d_b_resp;
  logic [3:0]           d_ar_asid, d_aw_asid;
  logic [DDW-1:0]       d_ar_domain, d_aw_domain;
  logic [127:0]         d_r_data, d_w_data;
  logic                 d_aw_valid, d_aw_ready, d_w_valid, d_w_ready, d_w_last, d_b_valid, d_b_ready;
  logic [15:0]          d_w_strb;

  logic                 d_csr_valid, d_csr_ready, d_csr_write, d_csr_rsp_valid, d_csr_rsp_err;
  logic [11:0]          d_csr_addr;
  logic [31:0]          d_csr_wdata, d_csr_rdata;
  logic                 d_cmd_valid, d_cmd_ready, d_done_valid, d_done_ready, d_viol;
  logic [63:0]          d_cmd_head;
  logic [DDW-1:0]       d_cmd_domain;
  logic [3:0]           d_cmd_asid, d_done_status, d_done_fault;
  logic [15:0]          d_done_txn;
  logic [7:0]           d_done_err;
  logic [DDW-1:0]       d_done_domain;
  logic [31:0]          d_done_bytes, d_done_crc;
  logic                 pt_en, pt_valid, pt_rej;
  logic [3:0]           pt_idx, pt_asid;
  logic [DDW-1:0]       pt_domain;
  logic [DAW-1:0]       pt_base, pt_pa;
  logic [DAW:0]         pt_size;
  logic [1:0]           pt_perm;

  silicaflux_cloud_dma #(
    .NUM_CH(1), .DW(128), .AW(DAW), .DOM_W(DDW), .MAX_BURST_BEATS(sf_asoc_cfg_pkg::DMA_MAX_BURST_BEATS),
    .RD_OUT(sf_asoc_cfg_pkg::DMA_RD_OUT), .WR_OUT(sf_asoc_cfg_pkg::DMA_WR_OUT), .BUF_BYTES(sf_asoc_cfg_pkg::DMA_BUF_BYTES),
    .REORDER_OK(1'b0), .USE_EXT_IOMMU(1'b0)
  ) u_dma (
    .clk, .rst_n(acc_rst_n),
    .csr_req_valid(d_csr_valid), .csr_req_ready(d_csr_ready), .csr_req_write(d_csr_write), .csr_req_addr(d_csr_addr),
    .csr_req_wdata(d_csr_wdata), .csr_rsp_valid(d_csr_rsp_valid), .csr_rsp_rdata(d_csr_rdata), .csr_rsp_err(d_csr_rsp_err),
    .irq(dma_irq),
    .cmd_valid(d_cmd_valid), .cmd_ready(d_cmd_ready), .cmd_head(d_cmd_head), .cmd_domain(d_cmd_domain), .cmd_asid(d_cmd_asid),
    .done_valid(d_done_valid), .done_ready(d_done_ready), .done_txn(d_done_txn), .done_status(d_done_status),
    .done_err(d_done_err), .done_fault(d_done_fault), .done_domain(d_done_domain), .done_bytes(d_done_bytes),
    .done_crc(d_done_crc), .viol_evt(d_viol),
    .m_ar_valid(d_ar_valid), .m_ar_ready(d_ar_ready), .m_ar_id(d_ar_id), .m_ar_addr(d_ar_addr), .m_ar_len(d_ar_len),
    .m_ar_size(d_ar_size), .m_ar_burst(d_ar_burst), .m_ar_asid(d_ar_asid), .m_ar_domain(d_ar_domain),
    .m_r_valid(d_r_valid), .m_r_ready(d_r_ready), .m_r_id(d_r_id), .m_r_data(d_r_data), .m_r_resp(d_r_resp), .m_r_last(d_r_last),
    .m_aw_valid(d_aw_valid), .m_aw_ready(d_aw_ready), .m_aw_id(d_aw_id), .m_aw_addr(d_aw_addr), .m_aw_len(d_aw_len),
    .m_aw_size(d_aw_size), .m_aw_burst(d_aw_burst), .m_aw_asid(d_aw_asid), .m_aw_domain(d_aw_domain),
    .m_w_valid(d_w_valid), .m_w_ready(d_w_ready), .m_w_data(d_w_data), .m_w_strb(d_w_strb), .m_w_last(d_w_last),
    .m_b_valid(d_b_valid), .m_b_ready(d_b_ready), .m_b_id(d_b_id), .m_b_resp(d_b_resp),
    // external IOMMU interface: unused (the simulation permission table is the platform's isolation MODEL, see L-04)
    .iommu_req_valid(), .iommu_req_ready(1'b0), .iommu_req_domain(), .iommu_req_asid(), .iommu_req_write(),
    .iommu_req_addr(), .iommu_req_bytes(), .iommu_req_id(), .iommu_rsp_valid(1'b0), .iommu_rsp_ready(),
    .iommu_rsp_id('0), .iommu_rsp_ok(1'b0), .iommu_rsp_fault(4'd0), .iommu_rsp_pa('0),
    .ptbl_en(pt_en), .ptbl_idx(pt_idx), .ptbl_valid(pt_valid), .ptbl_domain(pt_domain), .ptbl_asid(pt_asid),
    .ptbl_base(pt_base), .ptbl_size(pt_size), .ptbl_pa(pt_pa), .ptbl_perm(pt_perm), .ptbl_rej(pt_rej)
  );

  logic        d_req_valid, d_req_ready, d_rsp_valid, d_rsp_ready;
  logic [3:0]  d_req_op, d_rsp_status;
  logic [7:0]  d_req_tag, d_req_dom, d_req_attr, d_rsp_tag, d_rsp_meta;
  logic [63:0] d_req_addr;
  logic [15:0] d_req_be;
  logic [127:0] d_req_data, d_rsp_data;
  logic        br_err_evt, br_ref_evt, br_proto_evt;

  sf_asoc_axi_init #(
    .ID_W(DMA_IDW), .AW(DAW), .DOM_W(DDW), .EXPECT_DOM(DDW'(sf_asoc_cfg_pkg::DMA_BIND_DOM)),
    .DOM(sf_asoc_cfg_pkg::DOM_DMA), .ATTR(sf_asoc_cfg_pkg::ATTR_DMA), .STALL_PCT(STALL_PCT), .STALL_SEED(STALL_SEED ^ 32'h4BADB002)
  ) u_dma_init (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .ar_valid_i(d_ar_valid), .ar_ready_o(d_ar_ready), .ar_id_i(d_ar_id), .ar_addr_i(d_ar_addr), .ar_len_i(d_ar_len),
    .ar_size_i(d_ar_size), .ar_burst_i(d_ar_burst), .ar_asid_i(d_ar_asid), .ar_domain_i(d_ar_domain),
    .r_valid_o(d_r_valid), .r_ready_i(d_r_ready), .r_id_o(d_r_id), .r_data_o(d_r_data), .r_resp_o(d_r_resp), .r_last_o(d_r_last),
    .aw_valid_i(d_aw_valid), .aw_ready_o(d_aw_ready), .aw_id_i(d_aw_id), .aw_addr_i(d_aw_addr), .aw_len_i(d_aw_len),
    .aw_size_i(d_aw_size), .aw_burst_i(d_aw_burst), .aw_asid_i(d_aw_asid), .aw_domain_i(d_aw_domain),
    .w_valid_i(d_w_valid), .w_ready_o(d_w_ready), .w_data_i(d_w_data), .w_strb_i(d_w_strb), .w_last_i(d_w_last),
    .b_valid_o(d_b_valid), .b_ready_i(d_b_ready), .b_id_o(d_b_id), .b_resp_o(d_b_resp),
    .m_req_valid_o(d_req_valid), .m_req_ready_i(d_req_ready), .m_req_op_o(d_req_op), .m_req_tag_o(d_req_tag),
    .m_req_dom_o(d_req_dom), .m_req_attr_o(d_req_attr), .m_req_addr_o(d_req_addr), .m_req_be_o(d_req_be),
    .m_req_data_o(d_req_data),
    .m_rsp_valid_i(d_rsp_valid), .m_rsp_ready_o(d_rsp_ready), .m_rsp_tag_i(d_rsp_tag), .m_rsp_status_i(d_rsp_status),
    .m_rsp_meta_i(d_rsp_meta), .m_rsp_data_i(d_rsp_data),
    .evt_err_o(br_err_evt), .evt_refused_o(br_ref_evt), .evt_proto_o(br_proto_evt));

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_dma;
  assign unused_dma = br_proto_evt ^ (^d_done_domain);
  /* verilator lint_on UNUSEDSIGNAL */

  // ------------------------------------------------------------------ Meridian fabric
  logic [NT-1:0]            t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready, t_req_priv;
  logic [NT*SRCW-1:0]       t_req_src, t_rsp_src;
  logic [NT*2-1:0]          t_req_op, t_rsp_op;
  logic [NT*TAGW-1:0]       t_req_tag, t_rsp_tag;
  logic [NT*DOMW-1:0]       t_req_dom, t_rsp_dom;
  logic [NT*3-1:0]          t_req_tc, t_rsp_status;
  logic [NT*64-1:0]         t_req_addr;
  logic [NT*128-1:0]        t_req_wdata, t_rsp_rdata;
  logic [NT*16-1:0]         t_req_wstrb;

  logic                     pol_we, pol_valid, pol_priv, pol_rd, pol_wr;
  logic [sf_meridian_pkg::clog2c(sf_asoc_cfg_pkg::MER_CIT_NENT)-1:0] pol_idx;
  logic [NM-1:0]            pol_src;
  logic [(1<<DOMW)-1:0]     pol_dom;
  logic [63:0]              pol_base, pol_mask;
  logic [NT-1:0]            iso_clear;
  logic                     zomb_flush, elog_clear, elog_valid, evt_err, evt_sec, perf_clear, perf_freeze;
  logic [NM*NT-1:0]         iso;
  logic [SRCW-1:0]          elog_src;
  logic [2:0]               elog_status;
  logic [3:0]               elog_fault;
  logic [63:0]              elog_addr;
  logic [DOMW-1:0]          elog_dom;
  logic [TAGW-1:0]          elog_tag;
  logic [sf_meridian_pkg::clog2c(NT)-1:0] elog_tgt;
  logic [31:0]              elog_count, perf_data;
  logic [sf_meridian_pkg::clog2c(sf_meridian_pkg::pf_n(NM, NT))-1:0] perf_sel;

  sf_asoc_mer_core #(.STALL_PCT(STALL_PCT), .STALL_SEED(STALL_SEED)) u_mer (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .m_req_valid_i({d_req_valid, c_req_valid}), .m_req_ready_o({d_req_ready, c_req_ready}),
    .m_req_op_i({d_req_op, c_req_op}), .m_req_tag_i({d_req_tag, c_req_tag}), .m_req_dom_i({d_req_dom, c_req_dom}),
    .m_req_attr_i({d_req_attr, c_req_attr}), .m_req_addr_i({d_req_addr, c_req_addr}), .m_req_be_i({d_req_be, c_req_be}),
    .m_req_data_i({d_req_data, c_req_data}),
    .m_rsp_valid_o({d_rsp_valid, c_rsp_valid}), .m_rsp_ready_i({d_rsp_ready, c_rsp_ready}),
    .m_rsp_tag_o({d_rsp_tag, c_rsp_tag}), .m_rsp_status_o({d_rsp_status, c_rsp_status}),
    .m_rsp_meta_o({d_rsp_meta, c_rsp_meta}), .m_rsp_data_o({d_rsp_data, c_rsp_data}),
    .t_req_valid_o(t_req_valid), .t_req_ready_i(t_req_ready), .t_req_src_o(t_req_src), .t_req_op_o(t_req_op),
    .t_req_tag_o(t_req_tag), .t_req_dom_o(t_req_dom), .t_req_priv_o(t_req_priv), .t_req_tc_o(t_req_tc),
    .t_req_addr_o(t_req_addr), .t_req_wdata_o(t_req_wdata), .t_req_wstrb_o(t_req_wstrb),
    .t_rsp_valid_i(t_rsp_valid), .t_rsp_ready_o(t_rsp_ready), .t_rsp_src_i(t_rsp_src), .t_rsp_tag_i(t_rsp_tag),
    .t_rsp_dom_i(t_rsp_dom), .t_rsp_op_i(t_rsp_op), .t_rsp_status_i(t_rsp_status), .t_rsp_rdata_i(t_rsp_rdata),
    .pol_we_i(pol_we), .pol_idx_i(pol_idx), .pol_valid_i(pol_valid), .pol_src_i(pol_src), .pol_dom_i(pol_dom),
    .pol_priv_i(pol_priv), .pol_base_i(pol_base), .pol_mask_i(pol_mask), .pol_rd_i(pol_rd), .pol_wr_i(pol_wr),
    .iso_clear_i(iso_clear), .zomb_flush_i(zomb_flush), .iso_o(iso),
    .elog_clear_i(elog_clear), .elog_valid_o(elog_valid), .elog_src_o(elog_src), .elog_status_o(elog_status),
    .elog_fault_o(elog_fault), .elog_addr_o(elog_addr), .elog_dom_o(elog_dom), .elog_tag_o(elog_tag),
    .elog_tgt_o(elog_tgt), .elog_count_o(elog_count), .evt_err_o(evt_err), .evt_sec_o(evt_sec),
    .perf_clear_i(perf_clear), .perf_freeze_i(perf_freeze), .perf_sel_i(perf_sel), .perf_data_o(perf_data));

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_mer;
  assign unused_mer = evt_err;
  /* verilator lint_on UNUSEDSIGNAL */

  // ------------------------------------------------------------------ target adapters
  // t0: IronMemory data port (one ALP link per source master -> one IronMemory port each)
  logic [NM-1:0]      i0_req_valid, i0_req_ready, i0_rsp_valid, i0_rsp_ready;
  logic [NM*4-1:0]    i0_req_op, i0_rsp_status;
  logic [NM*8-1:0]    i0_req_tag, i0_req_dom, i0_req_attr, i0_rsp_tag, i0_rsp_meta;
  logic [NM*64-1:0]   i0_req_addr;
  logic [NM*16-1:0]   i0_req_be;
  logic [NM*128-1:0]  i0_req_data, i0_rsp_data;
  logic               t0_orphan, t0_slverr;

  sf_asoc_mer_tgt #(.NSRC(NM), .SRCW(SRCW), .DOMW(DOMW), .TAGW(TAGW), .CTX_DEPTH(4), .MEM_TYPE(2'd0),
                    .STALL_PCT(STALL_PCT), .STALL_SEED(STALL_SEED ^ 32'h5000_0001)) u_t0 (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .t_req_valid_i(t_req_valid[0]), .t_req_ready_o(t_req_ready[0]), .t_req_src_i(t_req_src[0*SRCW +: SRCW]),
    .t_req_op_i(t_req_op[0*2 +: 2]), .t_req_tag_i(t_req_tag[0*TAGW +: TAGW]), .t_req_dom_i(t_req_dom[0*DOMW +: DOMW]),
    .t_req_priv_i(t_req_priv[0]), .t_req_tc_i(t_req_tc[0*3 +: 3]), .t_req_addr_i(t_req_addr[0*64 +: 64]),
    .t_req_wdata_i(t_req_wdata[0*128 +: 128]), .t_req_wstrb_i(t_req_wstrb[0*16 +: 16]),
    .t_rsp_valid_o(t_rsp_valid[0]), .t_rsp_ready_i(t_rsp_ready[0]), .t_rsp_src_o(t_rsp_src[0*SRCW +: SRCW]),
    .t_rsp_tag_o(t_rsp_tag[0*TAGW +: TAGW]), .t_rsp_dom_o(t_rsp_dom[0*DOMW +: DOMW]), .t_rsp_op_o(t_rsp_op[0*2 +: 2]),
    .t_rsp_status_o(t_rsp_status[0*3 +: 3]), .t_rsp_rdata_o(t_rsp_rdata[0*128 +: 128]),
    .m_req_valid_o(i0_req_valid), .m_req_ready_i(i0_req_ready), .m_req_op_o(i0_req_op), .m_req_tag_o(i0_req_tag),
    .m_req_dom_o(i0_req_dom), .m_req_attr_o(i0_req_attr), .m_req_addr_o(i0_req_addr), .m_req_be_o(i0_req_be),
    .m_req_data_o(i0_req_data),
    .m_rsp_valid_i(i0_rsp_valid), .m_rsp_ready_o(i0_rsp_ready), .m_rsp_tag_i(i0_rsp_tag), .m_rsp_status_i(i0_rsp_status),
    .m_rsp_meta_i(i0_rsp_meta), .m_rsp_data_i(i0_rsp_data),
    .evt_orphan_o(t0_orphan), .evt_slverr_o(t0_slverr));

  // IronMemory control + buffer-manager ports
  logic        bm_valid, bm_ready, bm_rvalid, bm_rin_use, csr_valid, csr_we, csr_rvalid, csr_err, iron_init;
  logic [2:0]  bm_op, bm_requester, bm_btype, bm_owner, bm_rbtype, bm_rowner;
  logic [3:0]  bm_id, bm_rstatus, bm_rid;
  logic [39:0] bm_start, bm_rstart;
  logic [16:0] bm_len, bm_rlen;
  logic [4:0]  bm_rdm, bm_wrm, bm_rrdm, bm_rwrm;
  logic [7:0]  bm_rerr;
  logic [11:0] csr_addr;
  logic [31:0] csr_wdata, csr_rdata;

  sf_asoc_iron_alp #(.NP(NM)) u_iron (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .s_req_valid_i(i0_req_valid), .s_req_ready_o(i0_req_ready), .s_req_op_i(i0_req_op), .s_req_tag_i(i0_req_tag),
    .s_req_dom_i(i0_req_dom), .s_req_attr_i(i0_req_attr), .s_req_addr_i(i0_req_addr), .s_req_be_i(i0_req_be),
    .s_req_data_i(i0_req_data),
    .s_rsp_valid_o(i0_rsp_valid), .s_rsp_ready_i(i0_rsp_ready), .s_rsp_tag_o(i0_rsp_tag), .s_rsp_status_o(i0_rsp_status),
    .s_rsp_meta_o(i0_rsp_meta), .s_rsp_data_o(i0_rsp_data),
    .bm_cmd_valid_i(bm_valid), .bm_cmd_ready_o(bm_ready), .bm_cmd_op_i(bm_op), .bm_cmd_requester_i(bm_requester),
    .bm_cmd_id_i(bm_id), .bm_cmd_btype_i(bm_btype), .bm_cmd_start_i(bm_start), .bm_cmd_len_i(bm_len),
    .bm_cmd_owner_i(bm_owner), .bm_cmd_rd_mask_i(bm_rdm), .bm_cmd_wr_mask_i(bm_wrm),
    .bm_rsp_valid_o(bm_rvalid), .bm_rsp_status_o(bm_rstatus), .bm_rsp_id_o(bm_rid), .bm_rsp_in_use_o(bm_rin_use),
    .bm_rsp_btype_o(bm_rbtype), .bm_rsp_start_o(bm_rstart), .bm_rsp_len_o(bm_rlen), .bm_rsp_owner_o(bm_rowner),
    .bm_rsp_rd_mask_o(bm_rrdm), .bm_rsp_wr_mask_o(bm_rwrm), .bm_rsp_err_bits_o(bm_rerr),
    .csr_valid_i(csr_valid), .csr_we_i(csr_we), .csr_addr_i(csr_addr), .csr_wdata_i(csr_wdata),
    .csr_rvalid_o(csr_rvalid), .csr_rdata_o(csr_rdata), .csr_err_o(csr_err),
    .init_done_o(iron_init), .irq_o(iron_irq));
  assign iron_init_done_o = iron_init;

  // t1..t3: register targets (NSRC = 1)
  // register targets t1..t3 (flattened vectors, element t at [(t-1)*W +: W]; Yosys 0.33 has no packed multi-dimensional arrays)
  logic [3:1]        r_req_valid, r_req_ready, r_rsp_valid, r_rsp_ready;
  logic [3*4-1:0]    r_req_op, r_rsp_status;
  logic [3*8-1:0]    r_req_tag, r_req_dom, r_req_attr, r_rsp_tag, r_rsp_meta;
  logic [3*64-1:0]   r_req_addr;
  logic [3*16-1:0]   r_req_be;
  logic [3*128-1:0]  r_req_data, r_rsp_data;
  logic [3:1]        r_orphan, r_slverr;
  logic [3:1]        rb_valid, rb_we, rb_priv, rb_rvalid, rb_err;
  logic [3*12-1:0]   rb_addr;
  logic [3*32-1:0]   rb_wdata, rb_rdata;
  logic [3*8-1:0]    rb_dom;

  generate
    for (genvar t = 1; t < 4; t++) begin : g_reg
      sf_asoc_mer_tgt #(.NSRC(1), .SRCW(SRCW), .DOMW(DOMW), .TAGW(TAGW), .CTX_DEPTH(2), .MEM_TYPE(2'd2),
                        .STALL_PCT(STALL_PCT), .STALL_SEED(STALL_SEED ^ (32'h6000_0001 + 32'(t) * 32'h1234567))) u_t (
        .clk_i(clk), .rst_ni(acc_rst_n),
        .t_req_valid_i(t_req_valid[t]), .t_req_ready_o(t_req_ready[t]), .t_req_src_i(t_req_src[t*SRCW +: SRCW]),
        .t_req_op_i(t_req_op[t*2 +: 2]), .t_req_tag_i(t_req_tag[t*TAGW +: TAGW]), .t_req_dom_i(t_req_dom[t*DOMW +: DOMW]),
        .t_req_priv_i(t_req_priv[t]), .t_req_tc_i(t_req_tc[t*3 +: 3]), .t_req_addr_i(t_req_addr[t*64 +: 64]),
        .t_req_wdata_i(t_req_wdata[t*128 +: 128]), .t_req_wstrb_i(t_req_wstrb[t*16 +: 16]),
        .t_rsp_valid_o(t_rsp_valid[t]), .t_rsp_ready_i(t_rsp_ready[t]), .t_rsp_src_o(t_rsp_src[t*SRCW +: SRCW]),
        .t_rsp_tag_o(t_rsp_tag[t*TAGW +: TAGW]), .t_rsp_dom_o(t_rsp_dom[t*DOMW +: DOMW]), .t_rsp_op_o(t_rsp_op[t*2 +: 2]),
        .t_rsp_status_o(t_rsp_status[t*3 +: 3]), .t_rsp_rdata_o(t_rsp_rdata[t*128 +: 128]),
        .m_req_valid_o(r_req_valid[t]), .m_req_ready_i(r_req_ready[t]), .m_req_op_o(r_req_op[(t-1)*4 +: 4]), .m_req_tag_o(r_req_tag[(t-1)*8 +: 8]),
        .m_req_dom_o(r_req_dom[(t-1)*8 +: 8]), .m_req_attr_o(r_req_attr[(t-1)*8 +: 8]), .m_req_addr_o(r_req_addr[(t-1)*64 +: 64]), .m_req_be_o(r_req_be[(t-1)*16 +: 16]),
        .m_req_data_o(r_req_data[(t-1)*128 +: 128]),
        .m_rsp_valid_i(r_rsp_valid[t]), .m_rsp_ready_o(r_rsp_ready[t]), .m_rsp_tag_i(r_rsp_tag[(t-1)*8 +: 8]),
        .m_rsp_status_i(r_rsp_status[(t-1)*4 +: 4]), .m_rsp_meta_i(r_rsp_meta[(t-1)*8 +: 8]), .m_rsp_data_i(r_rsp_data[(t-1)*128 +: 128]),
        .evt_orphan_o(r_orphan[t]), .evt_slverr_o(r_slverr[t]));

      sf_asoc_regtgt u_rt (
        .clk_i(clk), .rst_ni(acc_rst_n),
        .s_req_valid_i(r_req_valid[t]), .s_req_ready_o(r_req_ready[t]), .s_req_op_i(r_req_op[(t-1)*4 +: 4]), .s_req_tag_i(r_req_tag[(t-1)*8 +: 8]),
        .s_req_dom_i(r_req_dom[(t-1)*8 +: 8]), .s_req_attr_i(r_req_attr[(t-1)*8 +: 8]), .s_req_addr_i(r_req_addr[(t-1)*64 +: 64]), .s_req_be_i(r_req_be[(t-1)*16 +: 16]),
        .s_req_data_i(r_req_data[(t-1)*128 +: 128]),
        .s_rsp_valid_o(r_rsp_valid[t]), .s_rsp_ready_i(r_rsp_ready[t]), .s_rsp_tag_o(r_rsp_tag[(t-1)*8 +: 8]),
        .s_rsp_status_o(r_rsp_status[(t-1)*4 +: 4]), .s_rsp_meta_o(r_rsp_meta[(t-1)*8 +: 8]), .s_rsp_data_o(r_rsp_data[(t-1)*128 +: 128]),
        .rb_valid_o(rb_valid[t]), .rb_we_o(rb_we[t]), .rb_addr_o(rb_addr[(t-1)*12 +: 12]), .rb_wdata_o(rb_wdata[(t-1)*32 +: 32]),
        .rb_dom_o(rb_dom[(t-1)*8 +: 8]), .rb_priv_o(rb_priv[t]),
        .rb_rvalid_i(rb_rvalid[t]), .rb_rdata_i(rb_rdata[(t-1)*32 +: 32]), .rb_err_i(rb_err[t]));
    end
  endgenerate

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_tg;
  assign unused_tg = t0_orphan ^ t0_slverr ^ (^r_orphan) ^ (^r_slverr) ^ (^rb_priv) ^ (^rb_dom[23:8]);
  /* verilator lint_on UNUSEDSIGNAL */

  // t1: IronMemory control
  sf_asoc_iron_ctl u_iron_ctl (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .rb_valid_i(rb_valid[1]), .rb_we_i(rb_we[1]), .rb_addr_i(rb_addr[(1-1)*12 +: 12]), .rb_wdata_i(rb_wdata[(1-1)*32 +: 32]), .rb_dom_i(rb_dom[(1-1)*8 +: 8]),
    .rb_rvalid_o(rb_rvalid[1]), .rb_rdata_o(rb_rdata[(1-1)*32 +: 32]), .rb_err_o(rb_err[1]),
    .csr_valid_o(csr_valid), .csr_we_o(csr_we), .csr_addr_o(csr_addr), .csr_wdata_o(csr_wdata),
    .csr_rvalid_i(csr_rvalid), .csr_rdata_i(csr_rdata), .csr_err_i(csr_err),
    .bm_cmd_valid_o(bm_valid), .bm_cmd_ready_i(bm_ready), .bm_cmd_op_o(bm_op), .bm_cmd_requester_o(bm_requester),
    .bm_cmd_id_o(bm_id), .bm_cmd_btype_o(bm_btype), .bm_cmd_start_o(bm_start), .bm_cmd_len_o(bm_len),
    .bm_cmd_owner_o(bm_owner), .bm_cmd_rd_mask_o(bm_rdm), .bm_cmd_wr_mask_o(bm_wrm),
    .bm_rsp_valid_i(bm_rvalid), .bm_rsp_status_i(bm_rstatus), .bm_rsp_id_i(bm_rid), .bm_rsp_in_use_i(bm_rin_use),
    .bm_rsp_btype_i(bm_rbtype), .bm_rsp_start_i(bm_rstart), .bm_rsp_len_i(bm_rlen), .bm_rsp_owner_i(bm_rowner),
    .bm_rsp_rd_mask_i(bm_rrdm), .bm_rsp_wr_mask_i(bm_rwrm), .bm_rsp_err_bits_i(bm_rerr));

  // t2: CloudDMA control
  sf_asoc_dma_ctl #(.AW(DAW), .DOM_W(DDW), .BIND_DOM(DDW'(sf_asoc_cfg_pkg::DMA_BIND_DOM))) u_dma_ctl (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .rb_valid_i(rb_valid[2]), .rb_we_i(rb_we[2]), .rb_addr_i(rb_addr[(2-1)*12 +: 12]), .rb_wdata_i(rb_wdata[(2-1)*32 +: 32]),
    .rb_rvalid_o(rb_rvalid[2]), .rb_rdata_o(rb_rdata[(2-1)*32 +: 32]), .rb_err_o(rb_err[2]),
    .csr_req_valid_o(d_csr_valid), .csr_req_ready_i(d_csr_ready), .csr_req_write_o(d_csr_write), .csr_req_addr_o(d_csr_addr),
    .csr_req_wdata_o(d_csr_wdata), .csr_rsp_valid_i(d_csr_rsp_valid), .csr_rsp_rdata_i(d_csr_rdata), .csr_rsp_err_i(d_csr_rsp_err),
    .cmd_valid_o(d_cmd_valid), .cmd_ready_i(d_cmd_ready), .cmd_head_o(d_cmd_head), .cmd_domain_o(d_cmd_domain),
    .cmd_asid_o(d_cmd_asid),
    .done_valid_i(d_done_valid), .done_ready_o(d_done_ready), .done_txn_i(d_done_txn), .done_status_i(d_done_status),
    .done_err_i(d_done_err), .done_fault_i(d_done_fault), .done_bytes_i(d_done_bytes), .done_crc_i(d_done_crc),
    .viol_evt_i(d_viol),
    .ptbl_en_o(pt_en), .ptbl_idx_o(pt_idx), .ptbl_valid_o(pt_valid), .ptbl_domain_o(pt_domain), .ptbl_asid_o(pt_asid),
    .ptbl_base_o(pt_base), .ptbl_size_o(pt_size), .ptbl_pa_o(pt_pa), .ptbl_perm_o(pt_perm), .ptbl_rej_i(pt_rej),
    .br_err_evt_i(br_err_evt), .br_refused_evt_i(br_ref_evt));

  // t3: SoC control
  sf_asoc_soc_ctl u_soc_ctl (
    .clk_i(clk), .rst_ni(acc_rst_n),
    .rb_valid_i(rb_valid[3]), .rb_we_i(rb_we[3]), .rb_addr_i(rb_addr[(3-1)*12 +: 12]), .rb_wdata_i(rb_wdata[(3-1)*32 +: 32]),
    .rb_rvalid_o(rb_rvalid[3]), .rb_rdata_o(rb_rdata[(3-1)*32 +: 32]), .rb_err_o(rb_err[3]),
    .pol_we_o(pol_we), .pol_idx_o(pol_idx), .pol_valid_o(pol_valid), .pol_src_o(pol_src), .pol_dom_o(pol_dom),
    .pol_priv_o(pol_priv), .pol_base_o(pol_base), .pol_mask_o(pol_mask), .pol_rd_o(pol_rd), .pol_wr_o(pol_wr),
    .iso_clear_o(iso_clear), .zomb_flush_o(zomb_flush), .iso_i(iso),
    .elog_clear_o(elog_clear), .elog_valid_i(elog_valid), .elog_src_i(elog_src), .elog_status_i(elog_status),
    .elog_fault_i(elog_fault), .elog_addr_i(elog_addr), .elog_dom_i(elog_dom), .elog_tag_i(elog_tag),
    .elog_tgt_i(elog_tgt), .elog_count_i(elog_count), .evt_sec_i(evt_sec),
    .perf_clear_o(perf_clear), .perf_freeze_o(perf_freeze), .perf_sel_o(perf_sel), .perf_data_i(perf_data),
    .iron_init_i(iron_init));
endmodule

`default_nettype wire
