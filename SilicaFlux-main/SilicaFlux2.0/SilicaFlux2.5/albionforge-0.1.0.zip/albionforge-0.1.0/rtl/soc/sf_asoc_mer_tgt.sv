// =============================================================================
// AlbionForge :: sf_asoc_mer_tgt -- Meridian target port -> ALP initiator link(s)
//
// Role      Integration glue.  One Meridian target port (request carries src, op, tag, dom, priv, tc, address, data,
//           strobes; the target must echo {src, tag, dom, op} in its response and may answer in any order) is presented
//           to the logic behind it as NSRC independent ALP v1 initiator links (one per source master when NSRC > 1).
// Contract  Meridian docs/meridian/02_PROTOCOL.md (target rules T1..T3); Albion ALP v1 (in-order link, 8-bit tag).
//
// Resolves  * format: Meridian op (2 bit) -> ALP op (4 bit); {priv, tc} -> ALP attr (qos = tc[1:0], priv, mem_type = MEM_TYPE,
//                     instr = secure = 0: Meridian does not carry them); the domain is zero-extended to ALP's 8 bits.
//           * identity: {src, dom, op} are kept per link in an in-order context FIFO and re-attached to the response, so the
//                     fabric's echo checks see exactly what they sent; the tag is the ALP response tag.
//           * status:  Meridian targets may answer only OKAY or SLVERR: ALP OKAY -> OKAY, every other ALP status -> SLVERR
//                     (the detailed ALP status is NOT visible across the fabric; documented limitation L-07).
//           * ordering: responses of one link are in order (ALP); responses of different links are merged round robin, which
//                     the fabric permits (targets may answer in any order).  A response with no matching context is dropped
//                     and counted (evt_orphan_o), never forwarded.
// Reset     rst_ni asynchronous assert; all context is cleared.
// =============================================================================
`default_nettype none

module sf_asoc_mer_tgt #(
  parameter int unsigned NSRC      = 1,
  parameter int unsigned SRCW      = 1,
  parameter int unsigned DOMW      = 3,
  parameter int unsigned TAGW      = 8,
  parameter int unsigned CTX_DEPTH = 4,
  parameter logic [1:0]  MEM_TYPE  = 2'd2,
  parameter int unsigned STALL_PCT = 0,
  parameter logic [31:0] STALL_SEED = 32'h2BADB002
) (
  input  wire logic                    clk_i,
  input  wire logic                    rst_ni,
  // ---------------------------------------------------------------- Meridian target-side port
  input  wire logic                    t_req_valid_i,
  output logic                         t_req_ready_o,
  input  wire logic [SRCW-1:0]         t_req_src_i,
  input  wire logic [1:0]              t_req_op_i,
  input  wire logic [TAGW-1:0]         t_req_tag_i,
  input  wire logic [DOMW-1:0]         t_req_dom_i,
  input  wire logic                    t_req_priv_i,
  input  wire logic [2:0]              t_req_tc_i,
  input  wire logic [63:0]             t_req_addr_i,
  input  wire logic [127:0]            t_req_wdata_i,
  input  wire logic [15:0]             t_req_wstrb_i,
  output logic                         t_rsp_valid_o,
  input  wire logic                    t_rsp_ready_i,
  output logic [SRCW-1:0]              t_rsp_src_o,
  output logic [TAGW-1:0]              t_rsp_tag_o,
  output logic [DOMW-1:0]              t_rsp_dom_o,
  output logic [1:0]                   t_rsp_op_o,
  output logic [2:0]                   t_rsp_status_o,
  output logic [127:0]                 t_rsp_rdata_o,
  // ---------------------------------------------------------------- ALP initiator links (NSRC copies, concatenated)
  output logic [NSRC-1:0]              m_req_valid_o,
  input  wire logic [NSRC-1:0]         m_req_ready_i,
  output logic [NSRC*4-1:0]            m_req_op_o,
  output logic [NSRC*8-1:0]            m_req_tag_o,
  output logic [NSRC*8-1:0]            m_req_dom_o,
  output logic [NSRC*8-1:0]            m_req_attr_o,
  output logic [NSRC*64-1:0]           m_req_addr_o,
  output logic [NSRC*16-1:0]           m_req_be_o,
  output logic [NSRC*128-1:0]          m_req_data_o,
  input  wire logic [NSRC-1:0]         m_rsp_valid_i,
  output logic [NSRC-1:0]              m_rsp_ready_o,
  input  wire logic [NSRC*8-1:0]       m_rsp_tag_i,
  input  wire logic [NSRC*4-1:0]       m_rsp_status_i,
  input  wire logic [NSRC*8-1:0]       m_rsp_meta_i,
  input  wire logic [NSRC*128-1:0]     m_rsp_data_i,
  // ---------------------------------------------------------------- events
  output logic                         evt_orphan_o,
  output logic                         evt_slverr_o
);
  if (TAGW != 8) begin : gen_param_check_tag
    $error("sf_asoc_mer_tgt: Meridian TAGW must equal the ALP tag width (8)");
  end

  localparam int unsigned CW = SRCW + DOMW + 2;
  localparam int unsigned SW = (NSRC > 1) ? $clog2(NSRC) : 1;

  // ---------------------------------------------------------------- request side
  logic [SW-1:0] sel;
  logic [NSRC-1:0] ctx_full, ctx_empty, ctx_in_ready, ctx_out_valid;
  logic [NSRC-1:0] acc;
  logic [CW-1:0]   ctx_out [NSRC];

  always_comb begin
    sel = '0;
    if (NSRC > 1) begin
      for (int i = 0; i < NSRC; i++) if (t_req_src_i == SRCW'(i)) sel = SW'(i);
    end
  end

  logic [3:0] alp_op;
  logic [7:0] alp_attr;
  always_comb begin
    if (t_req_op_i == 2'd0)      alp_op = 4'h1;
    else if (t_req_op_i == 2'd1) alp_op = 4'h2;
    else                         alp_op = 4'h0;
    alp_attr = {1'b0, t_req_tc_i[1:0], 1'b0, 1'b0, t_req_priv_i, MEM_TYPE};
  end

  logic blk;
  sf_asoc_gate #(.PCT(STALL_PCT), .SEED(STALL_SEED)) u_gate (.clk_i, .rst_ni, .pending_i(t_req_valid_i), .block_o(blk));

  always_comb begin
    t_req_ready_o = 1'b0;
    for (int i = 0; i < NSRC; i++) begin
      m_req_valid_o[i] = t_req_valid_i && (sel == SW'(i)) && ctx_in_ready[i] && !blk;
      m_req_op_o  [i*4   +: 4]   = alp_op;
      m_req_tag_o [i*8   +: 8]   = t_req_tag_i;
      m_req_dom_o [i*8   +: 8]   = 8'(t_req_dom_i);
      m_req_attr_o[i*8   +: 8]   = alp_attr;
      m_req_addr_o[i*64  +: 64]  = t_req_addr_i;
      m_req_be_o  [i*16  +: 16]  = t_req_wstrb_i;
      m_req_data_o[i*128 +: 128] = t_req_wdata_i;
      acc[i] = m_req_valid_o[i] && m_req_ready_i[i];
      if (sel == SW'(i)) t_req_ready_o = ctx_in_ready[i] && m_req_ready_i[i] && !blk;
    end
  end

  // ---------------------------------------------------------------- per-link context FIFOs
  logic [NSRC-1:0] pop;
  generate
    for (genvar i = 0; i < NSRC; i++) begin : g_ctx
      sf_albion_fifo #(.WIDTH(CW), .DEPTH(CTX_DEPTH)) u_ctx (
        .clk_i, .rst_ni, .flush_i(1'b0),
        .in_valid_i (acc[i]),
        .in_ready_o (ctx_in_ready[i]),
        .in_data_i  ({t_req_src_i, t_req_dom_i, t_req_op_i}),
        .out_valid_o(ctx_out_valid[i]),
        .out_ready_i(pop[i]),
        .out_data_o (ctx_out[i]),
        .count_o(), .full_o(ctx_full[i]), .empty_o(ctx_empty[i]));
    end
  endgenerate

  // ---------------------------------------------------------------- response side: time-sliced merge
  // A rotating turn pointer (state only) selects the link allowed to answer; it advances every cycle unless the link
  // whose turn it is holds a response that the fabric has not yet accepted.  No ready output depends on a valid input
  // (ALP: ready is a function of registered state and downstream ready only).  A link with no context (an answer to a
  // request that was never forwarded) is drained at once and counted; it is never forwarded.
  logic [SW-1:0] turn_q;
  logic          gvalid;
  logic [CW-1:0]  gx_ctx;
  logic [3:0]     g_status;
  logic [127:0]   g_data;
  logic [7:0]     g_tag;
  always_comb begin
    gvalid = 1'b0; gx_ctx = '0; g_status = 4'h0; g_data = '0; g_tag = '0;
    for (int i = 0; i < NSRC; i++) begin
      if (turn_q == SW'(i)) begin
        gvalid   = ctx_out_valid[i] && m_rsp_valid_i[i];
        gx_ctx    = ctx_out[i];
        g_status = m_rsp_status_i[i*4 +: 4];
        g_data   = m_rsp_data_i[i*128 +: 128];
        g_tag    = m_rsp_tag_i[i*8 +: 8];
      end
    end
  end

  logic [SRCW-1:0] c_src;
  logic [DOMW-1:0] c_dom;
  logic [1:0]      c_op;
  assign {c_src, c_dom, c_op} = gx_ctx;

  assign t_rsp_valid_o  = gvalid;
  assign t_rsp_src_o    = c_src;
  assign t_rsp_dom_o    = c_dom;
  assign t_rsp_op_o     = c_op;
  assign t_rsp_tag_o    = g_tag[TAGW-1:0];
  assign t_rsp_status_o = (g_status == sf_albion_pkg::SF_ST_OKAY) ? 3'd0 : 3'd1;
  assign t_rsp_rdata_o  = (g_status == sf_albion_pkg::SF_ST_OKAY && c_op == 2'd0) ? g_data : 128'd0;

  always_comb begin
    for (int i = 0; i < NSRC; i++) begin
      m_rsp_ready_o[i] = !ctx_out_valid[i] || ((turn_q == SW'(i)) && t_rsp_ready_i);
      pop[i]           = ctx_out_valid[i] && m_rsp_valid_i[i] && (turn_q == SW'(i)) && t_rsp_ready_i;
    end
  end

  logic hs;
  assign hs = t_rsp_valid_o && t_rsp_ready_i;
  assign evt_slverr_o = hs && (t_rsp_status_o != 3'd0);
  always_comb begin
    evt_orphan_o = 1'b0;
    for (int i = 0; i < NSRC; i++) if (m_rsp_valid_i[i] && !ctx_out_valid[i]) evt_orphan_o = 1'b1;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) turn_q <= '0;
    else if (!(t_rsp_valid_o && !t_rsp_ready_i)) turn_q <= (32'(turn_q) + 1 >= NSRC) ? '0 : SW'(32'(turn_q) + 1);
  end

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused;
  assign unused = (^m_rsp_meta_i) ^ (^ctx_full) ^ (^ctx_empty) ^ t_req_tc_i[2];   // ALP qos is 2 bits: Meridian class bit 2 (management) is not representable
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
