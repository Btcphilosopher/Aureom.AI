// =============================================================================
// AlbionForge :: sf_asoc_sfb2_init -- ControlCore SFB2 master -> ALP initiator
//
// Role      Integration glue.  ControlCore's external data port (SFB2: 32-bit address, 32-bit data, 4 byte strobes,
//           one transaction in flight, in-order) becomes an Albion Link Protocol v1 initiator (64-bit address,
//           128-bit data, 16 byte-enables, 8-bit tag, 8-bit domain).
// Contract  docs/albion/ARCHITECTURE_CONTRACT.md (ALP v1); SFB2 rules R1..R11 (DataFabric).
//
// Resolves  * width mismatch   32 -> 128: the existing sf_albion_width_adapter (UPSIZE) places the word in its lane
//                              (addr[3:2]) and selects the byte enables of that lane; read data is extracted.
//           * address-map collision: the ControlCore EXT window (0x2000_0000..0x3FFF_FFFF) is translated window by
//                              window to the 64-bit Albion map; an address that hits no window is answered locally with
//                              an SFB2 error and never reaches the fabric.
//           * domain / privilege: the domain, privilege and QoS stamped on every request are module parameters
//                              (hardware binding); software cannot choose them.
//           * tags: a free-running 8-bit counter, so the tag of a new request never equals an outstanding tag
//                              (at most one is outstanding).
//
// Behaviour One SFB2 transaction at a time.  req_ready is high only in IDLE (a function of registered state).
//           A response is held (valid, rdata, error) until rsp_ready.  Any non-OKAY ALP status, a response tag that
//           is not the request tag, or a window miss gives rsp_error = 1 and rdata = 0 (SFB2 R8).
//           A write with no byte strobe set is completed locally without a bus access (there is nothing to write).
// Reset     rst_ni asynchronous assert (active low), as everywhere in Albion.  No transaction survives reset.
// =============================================================================
`default_nettype none

module sf_asoc_sfb2_init #(
  parameter int unsigned                  NW        = 1,
  parameter logic [NW*32-1:0]             WIN_BASE  = '0,
  parameter logic [NW*32-1:0]             WIN_MASK  = '0,
  parameter logic [NW*64-1:0]             WIN_DST   = '0,
  parameter logic [7:0]                   DOM       = 8'd0,
  parameter logic [7:0]                   ATTR      = 8'h00,
  parameter int unsigned                  STALL_PCT = 0,
  parameter logic [31:0]                  STALL_SEED = 32'h3BADB002
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // ---------------------------------------------------------------- SFB2 slave side (from ControlCore ext_*)
  input  wire logic        s_req_valid_i,
  output logic             s_req_ready_o,
  input  wire logic        s_req_write_i,
  input  wire logic [31:0] s_req_addr_i,
  input  wire logic [31:0] s_req_wdata_i,
  input  wire logic [3:0]  s_req_wstrb_i,
  output logic             s_rsp_valid_o,
  input  wire logic        s_rsp_ready_i,
  output logic [31:0]      s_rsp_rdata_o,
  output logic             s_rsp_error_o,
  // ---------------------------------------------------------------- ALP master side (128-bit)
  output logic                                      m_req_valid_o,
  input  wire logic                                 m_req_ready_i,
  output logic [sf_albion_pkg::SF_OP_W-1:0]         m_req_op_o,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]        m_req_tag_o,
  output logic [sf_albion_pkg::SF_DOM_W-1:0]        m_req_dom_o,
  output logic [sf_albion_pkg::SF_ATTR_W-1:0]       m_req_attr_o,
  output logic [sf_albion_pkg::SF_ADDR_W-1:0]       m_req_addr_o,
  output logic [sf_albion_pkg::SF_BE_W-1:0]         m_req_be_o,
  output logic [sf_albion_pkg::SF_DATA_W-1:0]       m_req_data_o,
  input  wire logic                                 m_rsp_valid_i,
  output logic                                      m_rsp_ready_o,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]   m_rsp_tag_i,
  input  wire logic [sf_albion_pkg::SF_STATUS_W-1:0] m_rsp_status_i,
  input  wire logic [sf_albion_pkg::SF_CMETA_W-1:0] m_rsp_meta_i,
  input  wire logic [sf_albion_pkg::SF_DATA_W-1:0]  m_rsp_data_i,
  // ---------------------------------------------------------------- event pulses (for counters)
  output logic             evt_req_o,       // an SFB2 request was accepted
  output logic             evt_err_o,       // an error response was returned to SFB2
  output logic             evt_miss_o       // the request hit no window (answered locally)
);
  localparam logic [2:0] S_IDLE = 3'd0, S_ISSUE = 3'd1, S_WAIT = 3'd2, S_RESP = 3'd3, S_LOCAL = 3'd4;

  logic [2:0]  state_q;
  logic        wr_q;
  logic [31:0] wdata_q;
  logic [3:0]  wstrb_q;
  logic [63:0] dst_q;
  logic [7:0]  tag_q, tag_used_q;
  logic [31:0] rdata_q;
  logic        err_q;

  // ---- window lookup on the incoming request (combinational, used only in the accept cycle)
  logic        hit;
  logic [63:2] dst;                           // word address: SFB2 addresses are word aligned, strobes select bytes
  always_comb begin
    hit = 1'b0;
    dst = '0;
    for (int w = 0; w < NW; w++) begin
      if (!hit && ((s_req_addr_i & WIN_MASK[w*32 +: 32]) == WIN_BASE[w*32 +: 32])) begin
        hit = 1'b1;
        dst = WIN_DST[w*64+2 +: 62] | {32'd0, s_req_addr_i[31:2] & ~WIN_MASK[w*32+2 +: 30]};
      end
    end
  end

  logic accept;
  assign s_req_ready_o = (state_q == S_IDLE);
  assign accept        = s_req_valid_i && s_req_ready_o;

  // ---- narrow (32-bit) ALP link into the width adapter
  logic        n_req_valid, n_req_ready;
  logic [3:0]  n_req_be;
  logic [31:0] n_req_data;
  logic        n_rsp_valid, n_rsp_ready;
  logic [sf_albion_pkg::SF_TAG_W-1:0]    n_rsp_tag;
  logic [sf_albion_pkg::SF_STATUS_W-1:0] n_rsp_status;
  logic [sf_albion_pkg::SF_CMETA_W-1:0]  n_rsp_meta;
  logic [31:0] n_rsp_data;

  assign n_req_valid = (state_q == S_ISSUE);
  assign n_req_be    = wr_q ? wstrb_q : 4'hF;
  assign n_req_data  = wr_q ? wdata_q : 32'd0;
  logic blk;
  sf_asoc_gate #(.PCT(STALL_PCT), .SEED(STALL_SEED)) u_gate (.clk_i, .rst_ni, .pending_i(n_rsp_valid), .block_o(blk));
  assign n_rsp_ready = (state_q == S_WAIT) && !blk;

  sf_albion_width_adapter #(.DOWNSIZE(1'b0), .NARROW_W(32), .MAX_OUT(1)) u_up (
    .clk_i, .rst_ni,
    .s_req_valid_i (n_req_valid),
    .s_req_ready_o (n_req_ready),
    .s_req_op_i    (wr_q ? 4'h2 : 4'h1),
    .s_req_tag_i   (tag_q),
    .s_req_dom_i   (DOM),
    .s_req_attr_i  (ATTR),
    .s_req_addr_i  (dst_q),
    .s_req_be_i    (n_req_be),
    .s_req_data_i  (n_req_data),
    .s_rsp_valid_o (n_rsp_valid),
    .s_rsp_ready_i (n_rsp_ready),
    .s_rsp_tag_o   (n_rsp_tag),
    .s_rsp_status_o(n_rsp_status),
    .s_rsp_meta_o  (n_rsp_meta),
    .s_rsp_data_o  (n_rsp_data),
    .m_req_valid_o, .m_req_ready_i, .m_req_op_o, .m_req_tag_o, .m_req_dom_o, .m_req_attr_o,
    .m_req_addr_o, .m_req_be_o, .m_req_data_o,
    .m_rsp_valid_i, .m_rsp_ready_o, .m_rsp_tag_i, .m_rsp_status_i, .m_rsp_meta_i, .m_rsp_data_i
  );

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_meta;
  assign unused_meta = ^n_rsp_meta;
  /* verilator lint_on UNUSEDSIGNAL */

  assign s_rsp_valid_o = (state_q == S_RESP) || (state_q == S_LOCAL);
  assign s_rsp_rdata_o = (state_q == S_RESP) ? rdata_q : 32'd0;
  assign s_rsp_error_o = (state_q == S_LOCAL) ? 1'b1 : err_q;

  assign evt_req_o  = accept;
  assign evt_miss_o = accept && !hit;
  assign evt_err_o  = s_rsp_valid_o && s_rsp_ready_i && s_rsp_error_o;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q    <= S_IDLE;
      wr_q       <= 1'b0;
      wdata_q    <= 32'd0;
      wstrb_q    <= 4'd0;
      dst_q      <= 64'd0;
      tag_q      <= 8'd0;
      tag_used_q <= 8'd0;
      rdata_q    <= 32'd0;
      err_q      <= 1'b0;
    end else begin
      case (state_q)
        S_IDLE: begin
          if (accept) begin
            wr_q    <= s_req_write_i;
            wdata_q <= s_req_wdata_i;
            wstrb_q <= s_req_wstrb_i;
            dst_q   <= {dst, 2'b00};
            if (!hit)                                      state_q <= S_LOCAL;   // no window: SFB2 error
            else if (s_req_write_i && s_req_wstrb_i == 4'd0) begin
              rdata_q <= 32'd0; err_q <= 1'b0;             state_q <= S_RESP;    // nothing to write: done
            end else                                        state_q <= S_ISSUE;
          end
        end
        S_ISSUE: begin
          if (n_req_valid && n_req_ready) begin
            tag_used_q <= tag_q;
            tag_q      <= tag_q + 8'd1;
            state_q    <= S_WAIT;
          end
        end
        S_WAIT: begin
          if (n_rsp_valid && n_rsp_ready) begin
            if (n_rsp_status == sf_albion_pkg::SF_ST_OKAY && n_rsp_tag == tag_used_q) begin
              err_q   <= 1'b0;
              rdata_q <= wr_q ? 32'd0 : n_rsp_data;
            end else begin
              err_q   <= 1'b1;
              rdata_q <= 32'd0;
            end
            state_q <= S_RESP;
          end
        end
        S_RESP:  if (s_rsp_ready_i) state_q <= S_IDLE;
        S_LOCAL: if (s_rsp_ready_i) state_q <= S_IDLE;
        default: state_q <= S_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
