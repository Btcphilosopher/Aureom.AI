// =============================================================================
// AlbionForge :: sf_asoc_iron_port -- 64-bit ALP target link -> one IronMemory master port
//
// Role      Integration glue.  IronMemory (Project 84) is a multi-port memory whose master ports are valid/ready with
//           {addr, size, we, wdata, wstrb} and an in-order response {rdata, err[2:0], ecc_corr}.  This module presents
//           ONE such port as an ALP v1 target at 64-bit width (the width IronMemory was verified at).
// Contract  ALP v1 target rules; IronMemory docs/iron_memory/interfaces.md (master ports).
//
// Behaviour Every accepted ALP request becomes one IronMemory access of size 8 bytes (log2 = 3) with the request's byte
//           enables as strobes (writes).  Opcodes other than READ / WRITE are answered locally with BAD_OPCODE and never
//           reach the memory.  Tags are kept in an in-order FIFO and re-attached to the response.
//           IronMemory response code -> ALP status:  OK -> OKAY, DECODE -> DECODE_ERR, ALIGN -> ALIGN_ERR,
//           PERM / BOUNDS -> ACCESS_DENIED, ECC_UE -> ECC_UNCORR (poisoned), EXT -> TARGET_ERR.
//           Read data is returned only with OKAY; a corrected ECC error sets meta.corrected.
//           The port's ownership domain is the HARDWARE binding of this port in IronMemory (PORT_DOMAIN_MAP); the domain
//           field of the ALP request is not used for the memory's ownership check.
// Reset     rst_ni asynchronous assert; no request survives.
// =============================================================================
`default_nettype none

module sf_asoc_iron_port #(
  parameter int unsigned AW   = 40,
  parameter int unsigned QD   = 4
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // ---------------------------------------------------------------- ALP target link, 64-bit data
  input  wire logic                                      s_req_valid_i,
  output logic                                           s_req_ready_o,
  input  wire logic [sf_albion_pkg::SF_OP_W-1:0]         s_req_op_i,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]        s_req_tag_i,
  input  wire logic [sf_albion_pkg::SF_ADDR_W-1:0]       s_req_addr_i,
  input  wire logic [7:0]                                s_req_be_i,
  input  wire logic [63:0]                               s_req_data_i,
  output logic                                           s_rsp_valid_o,
  input  wire logic                                      s_rsp_ready_i,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]             s_rsp_tag_o,
  output logic [sf_albion_pkg::SF_STATUS_W-1:0]          s_rsp_status_o,
  output logic [sf_albion_pkg::SF_CMETA_W-1:0]           s_rsp_meta_o,
  output logic [63:0]                                    s_rsp_data_o,
  // ---------------------------------------------------------------- IronMemory master port
  output logic             i_req_valid_o,
  input  wire logic        i_req_ready_i,
  output logic [AW-1:0]    i_req_addr_o,
  output logic [2:0]       i_req_size_o,
  output logic             i_req_we_o,
  output logic [63:0]      i_req_wdata_o,
  output logic [7:0]       i_req_wstrb_o,
  input  wire logic        i_rsp_valid_i,
  output logic             i_rsp_ready_o,
  input  wire logic [63:0] i_rsp_rdata_i,
  input  wire logic [2:0]  i_rsp_err_i,
  input  wire logic        i_rsp_corr_i
);
  // context FIFO: {is_write, tag, local_status[3:0], local}; local entries are answered without a memory access
  localparam int unsigned CW = 1 + 8 + 4 + 1;
  logic          q_in_ready, q_out_v, q_out_r, q_push;
  logic [CW-1:0] q_in_d, q_out_d;
  sf_albion_fifo #(.WIDTH(CW), .DEPTH(QD)) u_q (
    .clk_i, .rst_ni, .flush_i(1'b0),
    .in_valid_i(q_push), .in_ready_o(q_in_ready), .in_data_i(q_in_d),
    .out_valid_o(q_out_v), .out_ready_i(q_out_r), .out_data_o(q_out_d),
    .count_o(), .full_o(), .empty_o());

  logic op_rd, op_wr, op_ok;
  assign op_rd = (s_req_op_i == 4'h1);
  assign op_wr = (s_req_op_i == 4'h2);
  assign op_ok = op_rd || op_wr;

  // Request: the FIFO push and the memory access are one event.  ready depends on registered state and the memory's ready.
  logic fire;
  assign i_req_valid_o = s_req_valid_i && q_in_ready && op_ok;
  assign s_req_ready_o = q_in_ready && i_req_ready_i;     // never a function of valid or payload (ALP)
  assign fire          = s_req_valid_i && s_req_ready_o;
  assign q_push        = fire;
  assign q_in_d        = {op_wr, s_req_tag_i, op_ok ? 4'h0 : 4'h3, !op_ok};
  assign i_req_addr_o  = s_req_addr_i[AW-1:0];
  assign i_req_size_o  = 3'd3;
  assign i_req_we_o    = op_wr;
  assign i_req_wdata_o = s_req_data_i;
  assign i_req_wstrb_o = s_req_be_i;

  // Response
  logic        h_wr, h_local;
  logic [7:0]  h_tag;
  logic [3:0]  h_st;
  assign {h_wr, h_tag, h_st, h_local} = q_out_d;

  logic [3:0] mst;
  always_comb begin
    case (i_rsp_err_i)
      3'd0:    mst = 4'h0;   // OK
      3'd1:    mst = 4'h1;   // DECODE  -> DECODE_ERR
      3'd2:    mst = 4'h5;   // ALIGN   -> ALIGN_ERR
      3'd3:    mst = 4'h2;   // PERM    -> ACCESS_DENIED
      3'd4:    mst = 4'hA;   // ECC_UE  -> ECC_UNCORR
      3'd6:    mst = 4'h2;   // BOUNDS  -> ACCESS_DENIED
      default: mst = 4'h7;   // EXT / reserved -> TARGET_ERR
    endcase
  end

  assign s_rsp_valid_o  = q_out_v && (h_local || i_rsp_valid_i);
  assign s_rsp_tag_o    = h_tag;
  assign s_rsp_status_o = h_local ? h_st : mst;
  assign s_rsp_meta_o   = {4'b0000, (!h_local && i_rsp_corr_i && mst == 4'h0), (!h_local && mst == 4'hA), 1'b1, h_wr};
  assign s_rsp_data_o   = (!h_local && mst == 4'h0 && !h_wr) ? i_rsp_rdata_i : 64'd0;
  assign i_rsp_ready_o  = q_out_v && !h_local && s_rsp_ready_i;
  assign q_out_r        = s_rsp_valid_o && s_rsp_ready_i;

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused;
  assign unused = ^s_req_addr_i[63:40];       // the window was decoded by the fabric; IronMemory sees AW bits
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
