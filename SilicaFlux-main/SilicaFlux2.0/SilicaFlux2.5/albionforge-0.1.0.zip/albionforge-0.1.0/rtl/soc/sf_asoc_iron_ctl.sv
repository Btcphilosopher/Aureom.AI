// =============================================================================
// AlbionForge :: sf_asoc_iron_ctl -- control registers of IronMemory behind the 32-bit register bus
//
// Role      Integration glue for the `sram_ctl` region.  Offsets 0x000..0x7FF go straight to IronMemory's CSR port
//           (ID, CONFIG, STATUS, CTRL, ECC injection, error logs, performance counters: docs/iron_memory/csr_map.md).
//           Offsets 0x800.. are a small register shim that drives IronMemory's buffer-manager command port, which has no
//           register interface of its own (the IP says: "bm_cmd_requester must be driven by the interconnect").
// Resolves  missing interface: the buffer manager had no software-visible command path.
//           domain binding: bm_cmd_requester is the HARDWARE-sourced domain of the access that wrote BM_GO (the fabric has
//                     verified it at the master port); no software-writable field can choose it.
// Behaviour BM registers are plain read/write.  A write to BM_GO issues the command with the staged fields; a second GO
//           while one is outstanding is refused (register error).  BM_STATUS.busy / done / status report completion.
//           The response fields of the last command stay readable until the next GO.
// Reset     rst_ni asynchronous assert.
// =============================================================================
`default_nettype none

module sf_asoc_iron_ctl (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // register bus (slave)
  input  wire logic        rb_valid_i,
  input  wire logic        rb_we_i,
  input  wire logic [11:0] rb_addr_i,
  input  wire logic [31:0] rb_wdata_i,
  input  wire logic [7:0]  rb_dom_i,
  output logic             rb_rvalid_o,
  output logic [31:0]      rb_rdata_o,
  output logic             rb_err_o,
  // IronMemory CSR port
  output logic             csr_valid_o,
  output logic             csr_we_o,
  output logic [11:0]      csr_addr_o,
  output logic [31:0]      csr_wdata_o,
  input  wire logic        csr_rvalid_i,
  input  wire logic [31:0] csr_rdata_i,
  input  wire logic        csr_err_i,
  // IronMemory buffer-manager command port
  output logic             bm_cmd_valid_o,
  input  wire logic        bm_cmd_ready_i,
  output logic [2:0]       bm_cmd_op_o,
  output logic [2:0]       bm_cmd_requester_o,
  output logic [3:0]       bm_cmd_id_o,
  output logic [2:0]       bm_cmd_btype_o,
  output logic [39:0]      bm_cmd_start_o,
  output logic [16:0]      bm_cmd_len_o,
  output logic [2:0]       bm_cmd_owner_o,
  output logic [4:0]       bm_cmd_rd_mask_o,
  output logic [4:0]       bm_cmd_wr_mask_o,
  input  wire logic        bm_rsp_valid_i,
  input  wire logic [3:0]  bm_rsp_status_i,
  input  wire logic [3:0]  bm_rsp_id_i,
  input  wire logic        bm_rsp_in_use_i,
  input  wire logic [2:0]  bm_rsp_btype_i,
  input  wire logic [39:0] bm_rsp_start_i,
  input  wire logic [16:0] bm_rsp_len_i,
  input  wire logic [2:0]  bm_rsp_owner_i,
  input  wire logic [4:0]  bm_rsp_rd_mask_i,
  input  wire logic [4:0]  bm_rsp_wr_mask_i,
  input  wire logic [7:0]  bm_rsp_err_bits_i
);
  // ---- passthrough to the IronMemory CSR port
  assign csr_valid_o = rb_valid_i && !rb_addr_i[11];
  assign csr_we_o    = rb_we_i;
  assign csr_addr_o  = rb_addr_i;
  assign csr_wdata_o = rb_wdata_i;

  // ---- BM shim state
  logic [3:0]  id_q;
  logic [2:0]  type_q, owner_q, op_q, req_q;
  logic [39:0] start_q;
  logic [16:0] len_q;
  logic [4:0]  rd_q, wr_q;
  logic        busy_q, done_q, cmd_v_q;
  logic [3:0]  r_status_q, r_id_q;
  logic        r_inuse_q;
  logic [2:0]  r_type_q, r_owner_q;
  logic [39:0] r_start_q;
  logic [16:0] r_len_q;
  logic [4:0]  r_rd_q, r_wr_q;
  logic [7:0]  r_err_q;

  logic        shim_req, shim_wr, shim_rd;
  assign shim_req = rb_valid_i && rb_addr_i[11];
  assign shim_wr  = shim_req && rb_we_i;
  assign shim_rd  = shim_req && !rb_we_i;

  assign bm_cmd_valid_o     = cmd_v_q;
  assign bm_cmd_op_o        = op_q;
  assign bm_cmd_requester_o = req_q;
  assign bm_cmd_id_o        = id_q;
  assign bm_cmd_btype_o     = type_q;
  assign bm_cmd_start_o     = start_q;
  assign bm_cmd_len_o       = len_q;
  assign bm_cmd_owner_o     = owner_q;
  assign bm_cmd_rd_mask_o   = rd_q;
  assign bm_cmd_wr_mask_o   = wr_q;

  logic        rv_q, err_q;
  logic [31:0] rd_val;
  always_comb begin
    rd_val = 32'd0;
    case (rb_addr_i)
      sf_asoc_cfg_pkg::R_IRON_BM_ID:          rd_val = 32'(id_q);
      sf_asoc_cfg_pkg::R_IRON_BM_TYPE:        rd_val = 32'(type_q);
      sf_asoc_cfg_pkg::R_IRON_BM_START_LO:    rd_val = start_q[31:0];
      sf_asoc_cfg_pkg::R_IRON_BM_START_HI:    rd_val = 32'(start_q[39:32]);
      sf_asoc_cfg_pkg::R_IRON_BM_LEN:         rd_val = 32'(len_q);
      sf_asoc_cfg_pkg::R_IRON_BM_OWNER:       rd_val = 32'(owner_q);
      sf_asoc_cfg_pkg::R_IRON_BM_RDMASK:      rd_val = 32'(rd_q);
      sf_asoc_cfg_pkg::R_IRON_BM_WRMASK:      rd_val = 32'(wr_q);
      sf_asoc_cfg_pkg::R_IRON_BM_STATUS:      rd_val = {24'd0, r_status_q, 2'b00, done_q, busy_q};
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_ID:      rd_val = 32'(r_id_q);
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_INFO:    rd_val = {21'd0, r_owner_q, 1'b0, r_type_q, 3'b000, r_inuse_q};
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_START_LO: rd_val = r_start_q[31:0];
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_START_HI: rd_val = 32'(r_start_q[39:32]);
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_LEN:     rd_val = 32'(r_len_q);
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_RDMASK:  rd_val = 32'(r_rd_q);
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_WRMASK:  rd_val = 32'(r_wr_q);
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_ERRBITS: rd_val = 32'(r_err_q);
      sf_asoc_cfg_pkg::R_IRON_BM_REQUESTER:   rd_val = 32'(req_q);
      default: rd_val = 32'd0;
    endcase
  end
  logic known_reg;
  always_comb begin
    case (rb_addr_i)
      sf_asoc_cfg_pkg::R_IRON_BM_ID, sf_asoc_cfg_pkg::R_IRON_BM_TYPE, sf_asoc_cfg_pkg::R_IRON_BM_START_LO,
      sf_asoc_cfg_pkg::R_IRON_BM_START_HI, sf_asoc_cfg_pkg::R_IRON_BM_LEN, sf_asoc_cfg_pkg::R_IRON_BM_OWNER,
      sf_asoc_cfg_pkg::R_IRON_BM_RDMASK, sf_asoc_cfg_pkg::R_IRON_BM_WRMASK, sf_asoc_cfg_pkg::R_IRON_BM_GO,
      sf_asoc_cfg_pkg::R_IRON_BM_STATUS, sf_asoc_cfg_pkg::R_IRON_BM_RSP_ID, sf_asoc_cfg_pkg::R_IRON_BM_RSP_INFO,
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_START_LO, sf_asoc_cfg_pkg::R_IRON_BM_RSP_START_HI, sf_asoc_cfg_pkg::R_IRON_BM_RSP_LEN,
      sf_asoc_cfg_pkg::R_IRON_BM_RSP_RDMASK, sf_asoc_cfg_pkg::R_IRON_BM_RSP_WRMASK, sf_asoc_cfg_pkg::R_IRON_BM_RSP_ERRBITS,
      sf_asoc_cfg_pkg::R_IRON_BM_REQUESTER: known_reg = 1'b1;
      default: known_reg = 1'b0;
    endcase
  end

  logic go_ok;
  assign go_ok = shim_wr && (rb_addr_i == sf_asoc_cfg_pkg::R_IRON_BM_GO) && !busy_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      id_q <= 4'd0; type_q <= 3'd0; owner_q <= 3'd0; op_q <= 3'd0; req_q <= 3'd0;
      start_q <= 40'd0; len_q <= 17'd0; rd_q <= 5'd0; wr_q <= 5'd0;
      busy_q <= 1'b0; done_q <= 1'b0; cmd_v_q <= 1'b0;
      r_status_q <= 4'd0; r_id_q <= 4'd0; r_inuse_q <= 1'b0; r_type_q <= 3'd0; r_owner_q <= 3'd0;
      r_start_q <= 40'd0; r_len_q <= 17'd0; r_rd_q <= 5'd0; r_wr_q <= 5'd0; r_err_q <= 8'd0;
      rv_q <= 1'b0; err_q <= 1'b0;
    end else begin
      rv_q  <= shim_req;
      err_q <= shim_req && (!known_reg || (shim_wr && rb_addr_i == sf_asoc_cfg_pkg::R_IRON_BM_GO && busy_q));
      if (shim_wr) begin
        case (rb_addr_i)
          sf_asoc_cfg_pkg::R_IRON_BM_ID:       id_q    <= rb_wdata_i[3:0];
          sf_asoc_cfg_pkg::R_IRON_BM_TYPE:     type_q  <= rb_wdata_i[2:0];
          sf_asoc_cfg_pkg::R_IRON_BM_START_LO: start_q[31:0]  <= rb_wdata_i;
          sf_asoc_cfg_pkg::R_IRON_BM_START_HI: start_q[39:32] <= rb_wdata_i[7:0];
          sf_asoc_cfg_pkg::R_IRON_BM_LEN:      len_q   <= rb_wdata_i[16:0];
          sf_asoc_cfg_pkg::R_IRON_BM_OWNER:    owner_q <= rb_wdata_i[2:0];
          sf_asoc_cfg_pkg::R_IRON_BM_RDMASK:   rd_q    <= rb_wdata_i[4:0];
          sf_asoc_cfg_pkg::R_IRON_BM_WRMASK:   wr_q    <= rb_wdata_i[4:0];
          default: ;
        endcase
      end
      if (go_ok) begin
        op_q    <= rb_wdata_i[2:0];
        req_q   <= rb_dom_i[2:0];           // hardware-sourced requester domain
        busy_q  <= 1'b1;
        done_q  <= 1'b0;
        cmd_v_q <= 1'b1;
      end
      if (cmd_v_q && bm_cmd_ready_i) cmd_v_q <= 1'b0;
      if (bm_rsp_valid_i && busy_q) begin
        busy_q     <= 1'b0;
        done_q     <= 1'b1;
        r_status_q <= bm_rsp_status_i;
        r_id_q     <= bm_rsp_id_i;
        r_inuse_q  <= bm_rsp_in_use_i;
        r_type_q   <= bm_rsp_btype_i;
        r_owner_q  <= bm_rsp_owner_i;
        r_start_q  <= bm_rsp_start_i;
        r_len_q    <= bm_rsp_len_i;
        r_rd_q     <= bm_rsp_rd_mask_i;
        r_wr_q     <= bm_rsp_wr_mask_i;
        r_err_q    <= bm_rsp_err_bits_i;
      end
    end
  end

  assign rb_rvalid_o = csr_rvalid_i || rv_q;
  assign rb_rdata_o  = rv_q ? rd_val : csr_rdata_i;
  assign rb_err_o    = rv_q ? err_q : csr_err_i;

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused;
  assign unused = shim_rd ^ (^rb_dom_i[7:3]);
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
