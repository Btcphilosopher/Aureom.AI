// =============================================================================
// AlbionForge :: sf_asoc_regtgt -- ALP target link -> 32-bit register bus
//
// Role      Integration glue.  A 4 KiB control-register window behind an ALP v1 target link (128-bit words).  Register
//           blocks of the SilicaFlux IP (IronMemory CSR port, CloudDMA CSR port, ...) are 32-bit with a one-strobe
//           request and a valid/data/error response one or more cycles later; this module is that bridge.
// Contract  ALP v1 target rules (in-order, one response per accepted request, legality statuses of ALP-LEG-01).
//
// Behaviour One request in flight (req_ready is high only when idle).  A request is a legal register access iff
//           op is READ or WRITE, addr[3:0] = 0 (ALP words are 16-byte aligned), exactly one 32-bit lane has its four byte enables set
//           and no other lane has any (the lane index is the register offset bits [3:2]).  The 32-bit sub-word is taken from / returned in that lane (the same lane rule as
//           sf_albion_width_adapter).  Illegal requests are answered locally and never reach the register bus:
//              op not READ/WRITE -> BAD_OPCODE, addr[3:0] != 0 -> ALIGN_ERR, no enabled lane -> BAD_BE,
//              partial / multi-lane enable -> TARGET_ERR (registers are accessed one whole word at a time).
//           A register error (rb_err_i) -> TARGET_ERR with zero data.  The response carries the request tag.
//           The requester's domain and privilege are passed on (rb_dom_o, rb_priv_o) so register blocks can use the
//           HARDWARE-bound domain (Meridian verified it at the master port), never a software-written field.
// Reset     rst_ni asynchronous assert; no request survives.
// =============================================================================
`default_nettype none

module sf_asoc_regtgt (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // ---------------------------------------------------------------- ALP target link (we are the target)
  input  wire logic                                      s_req_valid_i,
  output logic                                           s_req_ready_o,
  input  wire logic [sf_albion_pkg::SF_OP_W-1:0]         s_req_op_i,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]        s_req_tag_i,
  input  wire logic [sf_albion_pkg::SF_DOM_W-1:0]        s_req_dom_i,
  input  wire logic [sf_albion_pkg::SF_ATTR_W-1:0]       s_req_attr_i,
  input  wire logic [sf_albion_pkg::SF_ADDR_W-1:0]       s_req_addr_i,
  input  wire logic [sf_albion_pkg::SF_BE_W-1:0]         s_req_be_i,
  input  wire logic [sf_albion_pkg::SF_DATA_W-1:0]       s_req_data_i,
  output logic                                           s_rsp_valid_o,
  input  wire logic                                      s_rsp_ready_i,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]             s_rsp_tag_o,
  output logic [sf_albion_pkg::SF_STATUS_W-1:0]          s_rsp_status_o,
  output logic [sf_albion_pkg::SF_CMETA_W-1:0]           s_rsp_meta_o,
  output logic [sf_albion_pkg::SF_DATA_W-1:0]            s_rsp_data_o,
  // ---------------------------------------------------------------- register bus (we are the master)
  output logic             rb_valid_o,        // one-cycle request strobe
  output logic             rb_we_o,
  output logic [11:0]      rb_addr_o,
  output logic [31:0]      rb_wdata_o,
  output logic [7:0]       rb_dom_o,
  output logic             rb_priv_o,
  input  wire logic        rb_rvalid_i,       // response (one per request), 1 or more cycles later
  input  wire logic [31:0] rb_rdata_i,
  input  wire logic        rb_err_i
);
  localparam logic [1:0] S_IDLE = 2'd0, S_REQ = 2'd1, S_WAIT = 2'd2, S_RESP = 2'd3;
  localparam logic [3:0] ST_OK = 4'h0, ST_BADOP = 4'h3, ST_BADBE = 4'h4, ST_ALIGN = 4'h5, ST_TGT = 4'h7;

  logic [1:0]  state_q;
  logic        wr_q, priv_q;
  logic [7:0]  tag_q, dom_q;
  logic [11:0] addr_q;
  logic [31:0] wdata_q, rdata_q;
  logic [1:0]  lane_q;
  logic [3:0]  st_q;

  // ---- legality of the incoming request.  An ALP word address is always 16-byte aligned (addr[3:0] = 0): the 32-bit lane
  // that was addressed travels ONLY in the byte enables (sf_albion_width_adapter, UPSIZE), so the lane is derived from them.
  logic [1:0]  lane;
  logic [3:0]  nib;
  logic        one_lane, op_ok, al_ok;
  logic [3:0]  st_in;
  always_comb begin
    lane = 2'd0;
    nib  = 4'h0;
    for (int l = 3; l >= 0; l--) if (s_req_be_i[l*4 +: 4] != 4'h0) begin lane = 2'(l); nib = s_req_be_i[l*4 +: 4]; end
    op_ok    = (s_req_op_i == 4'h1) || (s_req_op_i == 4'h2);
    al_ok    = (s_req_addr_i[3:0] == 4'b0000);
    one_lane = (nib == 4'hF) && ((s_req_be_i & ~(16'hF << (lane * 4))) == 16'h0000);
    if (!op_ok)                  st_in = ST_BADOP;
    else if (!al_ok)             st_in = ST_ALIGN;
    else if (s_req_be_i == 16'h0) st_in = ST_BADBE;
    else if (!one_lane)          st_in = ST_TGT;
    else                         st_in = ST_OK;
  end

  logic accept;
  assign s_req_ready_o = (state_q == S_IDLE);
  assign accept        = s_req_valid_i && s_req_ready_o;

  assign rb_valid_o = (state_q == S_REQ);
  assign rb_we_o    = wr_q;
  assign rb_addr_o  = addr_q;
  assign rb_wdata_o = wdata_q;
  assign rb_dom_o   = dom_q;
  assign rb_priv_o  = priv_q;

  logic [31:0] wsel;
  always_comb begin
    wsel = 32'd0;
    for (int l = 0; l < 4; l++) if (lane == 2'(l)) wsel = s_req_data_i[l*32 +: 32];
  end

  assign s_rsp_valid_o  = (state_q == S_RESP);
  assign s_rsp_tag_o    = tag_q;
  assign s_rsp_status_o = st_q;
  assign s_rsp_meta_o   = {4'b0000, 1'b0, 1'b0, 1'b1, wr_q};
  always_comb begin
    s_rsp_data_o = 128'd0;
    if (st_q == ST_OK && !wr_q) begin
      for (int l = 0; l < 4; l++) if (lane_q == 2'(l)) s_rsp_data_o[l*32 +: 32] = rdata_q;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= S_IDLE;
      wr_q    <= 1'b0;
      priv_q  <= 1'b0;
      tag_q   <= 8'd0;
      dom_q   <= 8'd0;
      addr_q  <= 12'd0;
      wdata_q <= 32'd0;
      rdata_q <= 32'd0;
      lane_q  <= 2'd0;
      st_q    <= ST_OK;
    end else begin
      case (state_q)
        S_IDLE: if (accept) begin
          wr_q    <= (s_req_op_i == 4'h2);
          priv_q  <= s_req_attr_i[2];
          tag_q   <= s_req_tag_i;
          dom_q   <= s_req_dom_i;
          addr_q  <= {s_req_addr_i[11:4], lane, 2'b00};
          lane_q  <= lane;
          wdata_q <= wsel;
          st_q    <= st_in;
          state_q <= (st_in == ST_OK) ? S_REQ : S_RESP;
        end
        S_REQ:  state_q <= S_WAIT;
        S_WAIT: if (rb_rvalid_i) begin
          rdata_q <= rb_rdata_i;
          st_q    <= rb_err_i ? ST_TGT : ST_OK;
          state_q <= S_RESP;
        end
        S_RESP: if (s_rsp_ready_i) state_q <= S_IDLE;
        default: state_q <= S_IDLE;
      endcase
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused;
  assign unused = ^s_req_attr_i[7:3] ^ ^s_req_attr_i[1:0] ^ ^s_req_addr_i[63:12];   // region decode happened in the fabric
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
