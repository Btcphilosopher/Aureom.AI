#!/usr/bin/env python3
"""albion-lint: static gates.  Every gate runs a real tool; the JSON result is build/reports/lint.json.

  1  generated files are fresh (gen_soc --check) and the vendored IP equals vendor(repo archives) + patch series (--verify)
  2  IronMemory's sf_iron_defs.svh is textually the body of sf_iron_pkg (the Yosys 0.33 import workaround must not drift)
  3  Verilator -Wall --lint-only of the SoC top, STALL_PCT = 0 and 25: ZERO warnings in project files (rtl/soc, tb); vendored-IP
     warnings are counted and reported, not hidden
  4  Verilator -Wall of every new glue module as its own top
  5  Yosys elaboration (hierarchy -check, proc, check -assert): no latch, no unresolved module, no multiple driver
  6  firmware: cross-compile with -Wall -Wextra, zero warnings
  7  python tools byte-compile
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

GLUE = ['sf_asoc_sfb2_init', 'sf_asoc_axi_init', 'sf_asoc_mer_tgt', 'sf_asoc_mer_core', 'sf_asoc_regtgt', 'sf_asoc_iron_port',
        'sf_asoc_iron_alp', 'sf_asoc_iron_ctl', 'sf_asoc_dma_ctl', 'sf_asoc_soc_ctl', 'sf_asoc_gate']


def warnings_of(out):
    return [l for l in out.splitlines() if re.match(r'%(Warning|Error)', l)]


def split(w):
    mine = [x for x in w if re.search(r'(^|[:\s])(rtl/soc/|tb/)', x) and 'ip/' not in x.split(':')[0]]
    return mine, [x for x in w if x not in mine]


def main():
    res = dict(gates={}, ok=True)

    def gate(name, ok, **kw):
        res['gates'][name] = dict(ok=bool(ok), **kw)
        res['ok'] = res['ok'] and bool(ok)
        print('%-44s %s %s' % (name, 'PASS' if ok else 'FAIL', kw.get('summary', '')))

    rc, dt, o = sh('python3 -I tools/gen_soc.py --check')
    gate('generated SoC files are fresh', rc == 0, summary=o.strip().splitlines()[-1] if o.strip() else '')
    rc, dt, o = sh('python3 -I tools/vendor.py --verify --dest ip')
    gate('vendored IP == archives + patch series', rc == 0, summary=o.strip().splitlines()[-1])

    pkg = open(os.path.join(ROOT, 'ip/ironmemory/rtl/albion/sf_iron_pkg.sv')).read()
    body = pkg[pkg.index('package sf_iron_pkg;') + len('package sf_iron_pkg;'):pkg.index('endpackage')].strip('\n')
    defs = open(os.path.join(ROOT, 'ip/ironmemory/rtl/albion/sf_iron_defs.svh')).read()
    gate('sf_iron_defs.svh == body of sf_iron_pkg', body.strip() in defs, summary='no drift')

    filelist()
    for stall in (0, 25):
        rc, dt, o = sh('verilator --lint-only -Wall --timescale 1ns/1ps lint/albion.vlt -f build/filelists/soc.f -GSTALL_PCT=%d --top-module sf_albion_soc_min' % stall)
        w = warnings_of(o)
        mine, vend = split(w)
        gate('verilator -Wall SoC top (STALL_PCT=%d)' % stall, not mine and rc == 0 or (not mine and all('Exiting' in x for x in w if x.startswith('%Error'))),
             summary='%d warnings in project files, %d in vendored IP' % (len(mine), len(vend)), project_warnings=mine[:20], vendored_warnings=len(vend))
    bad = {}
    srcs = open(os.path.join(ROOT, 'build/filelists/soc.f')).read().split()
    for g in GLUE:
        rc, dt, o = sh('verilator --lint-only -Wall --timescale 1ns/1ps lint/albion.vlt -f build/filelists/soc.f --top-module %s' % g)
        mine, vend = split(warnings_of(o))
        if mine:
            bad[g] = mine[:5]
    gate('verilator -Wall each glue module as a top', not bad, summary='%d modules checked' % len(GLUE), failures=bad)

    rc, dt, o = sh('python3 -I tools/synth.py --top sf_albion_soc_min --filelist build/filelists/soc.f --out build/lint_synth --stages elab --timeout 900')
    try:
        s = json.load(open(os.path.join(BUILD, 'lint_synth', 'synth_summary.json')))['stages']['elab']
    except Exception:
        s = dict(rc=1, latches=-1, unresolved_modules=['?'])
    gate('yosys 0.33 elaboration + check -assert', s['rc'] == 0 and s['latches'] == 0 and not s['unresolved_modules'],
         summary='rc=%s latches=%s unresolved=%s' % (s['rc'], s['latches'], s['unresolved_modules']), seconds=s.get('seconds'))

    rc, dt, o = sh('make -s -C fw clean all 2>&1 | grep -E "warning|error"; true')
    fw_warn = [l for l in o.splitlines() if 'warning' in l or 'error' in l]
    gate('firmware -Wall -Wextra', not fw_warn, summary='%d warnings' % len(fw_warn))

    rc, dt, o = sh('python3 -m compileall -q tools tests')
    gate('python sources compile', rc == 0, summary='')
    write_json('lint.json', res)
    sys.exit(0 if res['ok'] else 1)


if __name__ == '__main__':
    main()
