#!/usr/bin/env python3
"""AlbionForge dependency-aware source list generator.

Given a top module and a set of source roots, scans every SystemVerilog source under the roots for
declarations (module / package / interface), instantiations, package scopes (`pkg::name`, `import pkg::`) and
`include files, resolves what the top module really needs, and writes a Verilator / Yosys / Icarus compatible
file list (`+incdir+` lines, then files in dependency order: packages first, a file after everything it needs).

  srclist.py --top sf_albion_soc_min --roots rtl/soc ip/... --out build/filelists/soc.f [--exclude GLOB ...]
             [--force FILE ...] [--json build/filelists/soc.json]

Errors out (exit 1) on: a needed module / package that no root declares, a name declared by two different files,
a dependency cycle between packages.  The JSON output lists, per file, what it provides and what it needs (this is
the machine-readable dependency graph used by the build manifest).
"""
import argparse, fnmatch, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
EXT = ('.sv', '.v', '.svh', '.vh')
RE_BLOCK = re.compile(r'/\*.*?\*/', re.S)
RE_LINE = re.compile(r'//[^\n]*')
RE_STR = re.compile(r'"(?:\\.|[^"\\])*"')
RE_DECL = re.compile(r'^\s*(?:(?:extern|virtual)\s+)?(module|macromodule|package|interface)\s+(?:automatic\s+|static\s+)?([A-Za-z_]\w*)', re.M)
RE_INST = re.compile(r'^\s*([A-Za-z_]\w*)\s*(?:#\s*\((?:[^;]*?)\)\s*|\s+)([A-Za-z_]\w*)\s*(?:\[[^\]]*\]\s*)*\(', re.M)
RE_SCOPE = re.compile(r'\b([A-Za-z_]\w*)::')
RE_IMPORT = re.compile(r'\bimport\s+([A-Za-z_]\w*)\s*::')
RE_INCLUDE = re.compile(r'`include\s+"([^"]+)"')
KW = set('''if else for while case casez casex begin end assign always always_ff always_comb always_latch initial final generate
endgenerate function task return wire logic reg input output inout parameter localparam typedef struct enum union import export
module endmodule package endpackage interface endinterface assert assume cover property sequence modport genvar integer int bit
byte automatic static unique priority default disable wait fork join forever repeat posedge negedge or and not xor nand nor buf
class program string real time var const virtual extern timeunit timeprecision bind endcase endfunction endtask endmodule endpackage endinterface endgenerate endclass endsequence endproperty'''.split())


def strip(text):
    text = RE_BLOCK.sub(lambda m: re.sub(r'[^\n]', ' ', m.group(0)), text)
    text = RE_LINE.sub('', text)
    return RE_STR.sub('""', text)


def scan(path):
    raw = open(path, errors='replace').read()
    clean = strip(raw)
    decl = [(k, n) for k, n in RE_DECL.findall(clean)]
    names = {n for _, n in decl}
    inst = {m.group(1) for m in RE_INST.finditer(clean) if m.group(1) not in KW}
    scopes = set(RE_SCOPE.findall(clean)) | set(RE_IMPORT.findall(clean))
    incs = set(RE_INCLUDE.findall(raw))
    return dict(decl=decl, provides=names, inst=inst - names, scopes=scopes - names, includes=incs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--top', required=True)
    ap.add_argument('--roots', nargs='+', required=True)
    ap.add_argument('--exclude', nargs='*', default=[])
    ap.add_argument('--force', nargs='*', default=[], help='files to include even if nothing instantiates them')
    ap.add_argument('--out', required=True)
    ap.add_argument('--json')
    ap.add_argument('--prefix-dir', default=ROOT, help='paths in the list are relative to this directory')
    a = ap.parse_args()

    files = {}
    incdirs_all = {}
    for root in a.roots:
        for dp, _, fns in os.walk(os.path.join(ROOT, root) if not os.path.isabs(root) else root):
            for fn in sorted(fns):
                if not fn.endswith(EXT):
                    continue
                p = os.path.join(dp, fn)
                rel = os.path.relpath(p, ROOT)
                if any(fnmatch.fnmatch(rel, g) for g in a.exclude):
                    continue
                if fn.endswith(('.svh', '.vh')):
                    incdirs_all.setdefault(fn, []).append(os.path.dirname(rel))
                    continue
                files[rel] = scan(p)
    provider = {}
    for rel, f in files.items():
        for n in f['provides']:
            if n in provider and provider[n] != rel:
                sys.exit('ERROR: %s declared in both %s and %s' % (n, provider[n], rel))
            provider[n] = rel
    if a.top not in provider:
        sys.exit('ERROR: top module %s not declared under the given roots' % a.top)

    order, state, incdirs, missing = [], {}, set(), set()

    def visit(rel, stack):
        if state.get(rel) == 2:
            return
        if state.get(rel) == 1:
            sys.exit('ERROR: dependency cycle: ' + ' -> '.join(stack + [rel]))
        state[rel] = 1
        f = files[rel]
        deps = set()
        for n in sorted(f['inst'] | f['scopes']):
            if n in provider:
                if provider[n] != rel:
                    deps.add(provider[n])
            else:
                missing.add((n, rel))
        for inc in f['includes']:
            if inc in incdirs_all:
                for d in incdirs_all[inc]:
                    incdirs.add(d)
            else:
                hit = [r for r in files if os.path.basename(r) == inc]
                if hit:
                    incdirs.add(os.path.dirname(hit[0]))          # an included .sv file: found as a source, directory on the include path
                else:
                    missing.add(('`include "%s"' % inc, rel))
        # packages first, then the rest, for stable and tool-friendly order
        for d in sorted(deps, key=lambda r: (not any(k == 'package' for k, _ in files[r]['decl']), r)):
            visit(d, stack + [rel])
        state[rel] = 2
        order.append(rel)

    for fr in a.force:
        if fr in files:
            visit(fr, [])
    visit(provider[a.top], [])
    # report missing names that look like real modules (not primitives / system tasks)
    real_missing = sorted(m for m in missing if not m[0].startswith('`') or True)
    hard = [m for m in real_missing if not m[0].startswith('illegal_parameter')]
    os.makedirs(os.path.dirname(os.path.join(ROOT, a.out)), exist_ok=True)
    with open(os.path.join(ROOT, a.out), 'w') as f:
        f.write('// generated by tools/srclist.py -- top %s; paths relative to the project root\n' % a.top)
        for d in sorted(incdirs):
            f.write('+incdir+%s\n' % d)
        for rel in order:
            f.write(rel + '\n')
    if a.json:
        with open(os.path.join(ROOT, a.json), 'w') as f:
            json.dump(dict(top=a.top, files=[dict(file=r, provides=sorted(files[r]['provides']),
                                                  needs=sorted(provider[n] for n in (files[r]['inst'] | files[r]['scopes']) if n in provider and provider[n] != r)) for r in order],
                           incdirs=sorted(incdirs), unresolved=sorted('%s (in %s)' % m for m in hard)), f, indent=1)
    print('srclist: top=%s files=%d incdirs=%d unresolved=%d' % (a.top, len(order), len(incdirs), len(hard)))
    for m in hard:
        print('  unresolved: %s in %s' % m)
    sys.exit(0)


if __name__ == '__main__':
    main()
