#!/usr/bin/env python3
"""AlbionForge: record and check the tool versions (reproducibility).  Writes build/reports/tool_versions.json.
Exit status 1 if a REQUIRED tool is missing; version drift from the pins in config/albion_soc.yaml is reported as a warning."""
import json, os, re, shutil, subprocess, sys, platform, time
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60)
        return (r.stdout + r.stderr).strip()
    except Exception as e:
        return ''


def first(pattern, text):
    m = re.search(pattern, text)
    return m.group(1) if m else None


def main():
    pins = yaml.safe_load(open(os.path.join(ROOT, 'config', 'albion_soc.yaml')))['tools']
    t = {}
    t['verilator'] = dict(required=True, version=first(r'Verilator (\d+\.\d+)', run('verilator --version')), path=shutil.which('verilator'))
    t['yosys'] = dict(required=True, version=first(r'Yosys (\d+\.\d+)', run('yosys -V')), path=shutil.which('yosys'), full=run('yosys -V'))
    t['iverilog'] = dict(required=False, version=first(r'version (\d+\.\d+)', run('iverilog -V | head -1')), path=shutil.which('iverilog'))
    t['riscv_gcc'] = dict(required=True, version=first(r'\) (\d+\.\d+\.\d+)', run('riscv64-unknown-elf-gcc --version | head -1')), path=shutil.which('riscv64-unknown-elf-gcc'))
    t['riscv_objcopy'] = dict(required=True, version=first(r'(\d+\.\d+)', run('riscv64-unknown-elf-objcopy --version | head -1')), path=shutil.which('riscv64-unknown-elf-objcopy'))
    t['python'] = dict(required=True, version='%d.%d' % sys.version_info[:2], path=sys.executable)
    cv = run("python3 -c 'import cocotb; print(cocotb.__version__)'")
    t['cocotb'] = dict(required=True, version=cv or None, path=shutil.which('cocotb-config'))
    t['pytest'] = dict(required=True, version=first(r'pytest (\d+\.\d+\.\d+)', run('python3 -m pytest --version')))
    t['pyyaml'] = dict(required=True, version=first(r'(\d+\.\d+(\.\d+)?)', run("python3 -c 'import yaml; print(yaml.__version__)'")))
    t['z3'] = dict(required=False, version=first(r'(\d+\.\d+\.\d+)', run('z3 --version')), path=shutil.which('z3'))
    t['make'] = dict(required=True, version=first(r'GNU Make (\d+\.\d+)', run('make --version | head -1')), path=shutil.which('make'))
    t['sby'] = dict(required=False, version=None, path=shutil.which('sby'), note='SymbiYosys is not packaged for this distribution; formal checks that need it are not run (see docs/LIMITATIONS.md)')
    t['sv2v'] = dict(required=False, version=None, path=shutil.which('sv2v'), note='not needed: the vendored IP was patched to parse with Yosys 0.33 directly')
    bad, warn = [], []
    for name, d in t.items():
        if d['required'] and not d['version']:
            bad.append(name)
    for k, pin in (('verilator', pins['verilator']), ('yosys', pins['yosys']), ('iverilog', pins['iverilog'])):
        v = t[k]['version']
        if v and not v.startswith(pin):
            warn.append('%s %s differs from the pinned %s' % (k, v, pin))
    for k, pin in (('riscv_gcc', pins['riscv_gcc']), ('cocotb', pins['cocotb']), ('z3', pins['z3'])):
        v = t[k]['version']
        if v and not v.startswith(pin):
            warn.append('%s %s differs from the pinned %s' % (k, v, pin))
    out = dict(generated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), host=dict(os=platform.platform(), machine=platform.machine()),
               pins=pins, tools=t, missing_required=bad, warnings=warn)
    os.makedirs(os.path.join(ROOT, 'build', 'reports'), exist_ok=True)
    json.dump(out, open(os.path.join(ROOT, 'build', 'reports', 'tool_versions.json'), 'w'), indent=1)
    for k, d in t.items():
        print('%-14s %-10s %s' % (k, d.get('version') or '-', d.get('path') or ''))
    for w in warn: print('WARNING:', w)
    if bad:
        print('MISSING REQUIRED TOOLS:', ', '.join(bad)); sys.exit(1)


if __name__ == '__main__':
    main()
