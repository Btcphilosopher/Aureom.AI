#!/usr/bin/env python3
"""albion-synth: real synthesis with Yosys (open source).
  SoC top        sf_albion_soc_min   : elaboration checks (latches, unresolved modules / black boxes, multiple drivers), word-level synthesis with the
                                       memories kept as inferred memories ($mem), flop-bit count, per-module breakdown
  wrapper top    sf_albion_fpga_top  : FPGA-primitive mapping (synth_ecp5: LUT4 / TRELLIS_FF / DP16KD / CCU2C) and the longest topological path
Result: build/reports/synth.json.  Estimates from a generic technology; no timing, no place-and-route, no board.  `--reuse` keeps an existing stage result."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *


def main():
    reuse = '--reuse' in sys.argv
    filelist()
    filelist(top='sf_albion_fpga_top', out='build/filelists/fpga.f', roots=SOC_ROOTS + ['rtl/fpga'])
    res = {}
    a = os.path.join(BUILD, 'synth', 'synth_summary.json')
    if not (reuse and os.path.exists(a)):
        rc, dt, out = sh('python3 -I tools/synth.py --top sf_albion_soc_min --filelist build/filelists/soc.f --out build/synth --stages elab,coarse --timeout 5400')
        print(out.strip())
    s1 = json.load(open(a))
    b = os.path.join(BUILD, 'synth_fpga', 'synth_summary.json')
    if not (reuse and os.path.exists(b)):
        rc, dt, out = sh('python3 -I tools/synth.py --top sf_albion_fpga_top --filelist build/filelists/fpga.f --out build/synth_fpga --stages fpga --timeout 7200')
        print(out.strip())
    s2 = json.load(open(b))
    merged = dict(tool=s1['tool'], top=s1['top'], fpga_top=s2['top'], defines=s1['defines'], stages=dict(s1['stages'], **s2['stages']))
    write_json('synth.json', merged)
    ok = all(v.get('rc') == 0 for v in merged['stages'].values())
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
