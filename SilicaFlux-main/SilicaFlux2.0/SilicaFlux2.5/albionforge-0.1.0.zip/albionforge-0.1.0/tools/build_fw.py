#!/usr/bin/env python3
"""albion-firmware: reproducible firmware build.
  1. rebuild the ControlCore BOOT ROM from its sources (ip/controlcore/firmware) in build/ and compare it byte for byte with the
     image compiled into the RTL (ip/controlcore/rtl/generated/sfv_bootrom_image.sv)
  2. cross-compile the Albion firmware (riscv64-unknown-elf-gcc, rv32im) with -Wall -Wextra, make the CRC-protected image + hex
  3. report sizes, entry point, image CRC and the SHA-256 of every artefact (build/reports/firmware.json); the build is run twice and
     the artefacts must be identical (determinism)."""
import hashlib, json, os, re, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def main():
    res = dict(ok=True)
    # ---- boot ROM: rebuild in a scratch copy of the firmware tree so the vendored sources stay untouched
    scratch = os.path.join(BUILD, 'rom_rebuild')
    shutil.rmtree(scratch, ignore_errors=True)
    os.makedirs(scratch)
    for d in ('firmware', 'scripts', 'rtl', 'config', 'third_party'):
        src = os.path.join(ROOT, 'ip/controlcore', d)
        if os.path.exists(src):
            shutil.copytree(src, os.path.join(scratch, d), ignore=shutil.ignore_patterns('__pycache__'))
    rc, dt, out = sh('make -C %s/firmware rom' % scratch, log=os.path.join(BUILD, 'logs', 'bootrom.log'))
    rom_new = os.path.join(scratch, 'rtl/generated/sfv_bootrom_image.sv')
    rom_ref = os.path.join(ROOT, 'ip/controlcore/rtl/generated/sfv_bootrom_image.sv')
    same = rc == 0 and os.path.exists(rom_new) and sha(rom_new) == sha(rom_ref)
    m = re.search(r'gen_rom: (\d+) words \((\d+) bytes\) of (\d+), sha256 (\w+)', out)
    res['bootrom'] = dict(rebuilt=rc == 0, identical_to_rtl_image=same, words=int(m.group(1)) if m else None, bytes=int(m.group(2)) if m else None,
                          capacity_words=int(m.group(3)) if m else None, sha256_prefix=m.group(4) if m else None, rtl_image_sha256=sha(rom_ref))
    print('boot ROM rebuilt from source: %s; identical to the image in the RTL: %s' % (rc == 0, same))
    res['ok'] = res['ok'] and same
    # ---- firmware (twice: determinism)
    shas = []
    for i in range(2):
        rc, dt, out = sh('make -C fw clean all', log=os.path.join(BUILD, 'logs', 'fw_build_%d.log' % i))
        if rc:
            print(out[-3000:]); sys.exit('firmware build failed')
        art = {n: sha(os.path.join(BUILD, 'fw', n)) for n in ('albion_fw.elf', 'albion_fw.img', 'albion_fw.hex', 'albion_fw.payload.bin')}
        shas.append(art)
    # the ELF embeds the build path in debug info only; compare the image, hex and payload (what the hardware sees)
    det = all(shas[0][k] == shas[1][k] for k in ('albion_fw.img', 'albion_fw.hex', 'albion_fw.payload.bin'))
    warn = [l for l in out.splitlines() if 'warning' in l]
    size = [l for l in out.splitlines() if re.match(r'\s+\d+\s+\d+\s+\d+', l)]
    mk = [l for l in out.splitlines() if l.startswith('mkimage')]
    res['firmware'] = dict(artefacts=shas[1], deterministic=det, warnings=len(warn), size_line=size[-1].split() if size else None, mkimage=mk[-1] if mk else None)
    meta = json.load(open(os.path.join(BUILD, 'fw', 'albion_fw.json'))) if os.path.exists(os.path.join(BUILD, 'fw', 'albion_fw.json')) else {}
    res['firmware']['image_meta'] = meta
    res['ok'] = res['ok'] and det and not warn
    print('firmware: %s; deterministic image/hex: %s; warnings: %d; %s' % (res['firmware']['mkimage'], det, len(warn), res['firmware']['size_line']))
    # ---- toolchain
    tv = os.path.join(REPORTS, 'tool_versions.json')
    if os.path.exists(tv):
        res['toolchain'] = json.load(open(tv))['tools']['riscv_gcc']
    write_json('firmware.json', res)
    sys.exit(0 if res['ok'] else 1)


if __name__ == '__main__':
    main()
