"""AlbionForge shared helpers for the build tools."""
import json, os, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, 'build')
REPORTS = os.path.join(BUILD, 'reports')

IP_ROOTS = ['ip/albioncore/rtl/albion', 'ip/meridian/rtl', 'ip/meridian/third_party', 'ip/ironmemory/rtl', 'ip/clouddma/rtl',
            'ip/clouddma/third_party', 'ip/controlcore/rtl', 'ip/controlcore/third_party']
SOC_ROOTS = ['rtl/soc'] + IP_ROOTS
FORCE = ['ip/controlcore/rtl/generated/cc_memmap_pkg.sv']
EXCLUDE = ['*/sim/*']


def sh(cmd, cwd=ROOT, log=None, timeout=None, env=None):
    """run a shell command; returns (rc, seconds, output tail)"""
    t0 = time.time()
    e = dict(os.environ)
    if env:
        e.update(env)
    try:
        p = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=e)
        out = p.stdout + p.stderr
        rc = p.returncode
    except subprocess.TimeoutExpired as ex:
        out = (ex.stdout or '') + (ex.stderr or '') if isinstance(ex.stdout, str) else 'TIMEOUT'
        rc = -9
    if log:
        os.makedirs(os.path.dirname(log), exist_ok=True)
        open(log, 'w').write(out)
    return rc, time.time() - t0, out


def write_json(name, obj):
    os.makedirs(REPORTS, exist_ok=True)
    path = os.path.join(REPORTS, name)
    json.dump(obj, open(path, 'w'), indent=1, sort_keys=True)
    return path


def filelist(top='sf_albion_soc_min', out='build/filelists/soc.f', extra=(), roots=None):
    """(re)generate the dependency-ordered source list"""
    cmd = 'python3 -I tools/srclist.py --top %s --roots %s --exclude %s --force %s %s --out %s --json %s' % (
        top, ' '.join(roots or SOC_ROOTS), ' '.join('"%s"' % x for x in EXCLUDE), ' '.join(FORCE), ' '.join(extra), out, out.replace('.f', '.json'))
    rc, dt, o = sh(cmd)
    if rc:
        sys.exit('srclist failed:\n' + o)
    return out
