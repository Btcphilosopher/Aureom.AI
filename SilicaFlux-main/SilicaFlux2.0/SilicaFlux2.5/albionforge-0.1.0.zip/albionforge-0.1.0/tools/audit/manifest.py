#!/usr/bin/env python3
"""AlbionForge audit manifest of the IP that goes into the minimum Albion SoC.

For every source file of the SoC build (dependency-ordered list from tools/srclist.py) it records: source file, module(s), dependencies
(resolved from the HDL, not from documentation), status in this SoC, verification evidence, synthesizability, missing interfaces and
integration problems.  Mechanical facts are MEASURED here:
  * Verilator 5.020 -Wall --lint-only and Yosys 0.33 read/hierarchy of each IP in its PRISTINE form (the vendored sources with this
    project's patch series reversed) and in its patched form,
  * how many other archives of the repository carry a module of the same name and whether those copies differ (audit/inventory.json),
  * whether the module survives real synthesis of the whole SoC (build/synth/coarse_hier_stat.txt, when present).
Curated facts (status, evidence, missing interfaces, integration problems) are written down below with their source; each integration
problem has an id, how it was found and what resolved it.

Output: audit/manifest.json, audit/MANIFEST.md
"""
import json, os, re, shutil, subprocess, sys, tempfile, collections

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
from common import sh, filelist  # noqa: E402

# ---------------------------------------------------------------------------------------------------------------- curated data
IPS = {
    'albioncore': dict(project='AlbionCore 0.1.0 (SilicaFlux Albion foundation)', top='sf_albion_width_adapter', kind='library',
        tops_for_probe=[('sf_albion_width_adapter', ['rtl/albion/sf_albion_pkg.sv', 'rtl/albion/sf_albion_fifo.sv', 'rtl/albion/sf_albion_skid.sv', 'rtl/albion/sf_albion_width_adapter.sv'])],
        status='USED: ALP v1 package, FIFO, skid buffer, width adapter (both directions) in the glue and the IronMemory wrapper',
        evidence='AlbionCore baseline run here (make check lint sim-quick synth): 9 simulation benches PASS (>14 M checks), Verilator/Yosys lint of all modules PASS, profile synth budgets PASS (see audit/baseline.json). Not re-run: formal (needs yosys-abc PDR runs, ~hours), mutation campaign.',
        missing='no bridge from SFB2 / AXI4 / Meridian format to ALP (written here: sf_asoc_sfb2_init, sf_asoc_axi_init, sf_asoc_mer_*); no protection unit; no memory-map region for IronMemory control registers (extended in config/albion_soc.yaml)',
        problems=[]),
    'meridian': dict(project='Meridian P83 (cloud interconnect)', top='sf_meridian_fabric', kind='fabric',
        tops_for_probe=[('sf_meridian_fabric', ['third_party/p22/sfn_pkg.sv', 'rtl/albion/sf_meridian_pkg.sv', 'third_party/p22/sfn_fifo.sv', 'rtl/albion/sf_meridian_decoder.sv',
                         'rtl/albion/sf_meridian_arbiter.sv', 'rtl/albion/sf_meridian_slice.sv', 'rtl/albion/sf_meridian_citadel_ref.sv', 'rtl/albion/sf_meridian_mport.sv',
                         'rtl/albion/sf_meridian_router.sv', 'rtl/albion/sf_meridian_perf.sv', 'rtl/albion/sf_meridian_fabric.sv'])],
        status='USED: 2 masters x 4 targets, AW 64 / DW 128 / TAG 8 / DOM 3, reference Citadel table, per-master 8 (DMA) / 1 (CPU) outstanding',
        evidence='Baseline (own run, apt Verilator 5.020): the UNMODIFIED RTL does not lint (BLKLOOPINIT) and does not parse with Yosys 0.33 -> its documented regression could not be reproduced as shipped. After patches 0001/0002: reference 2x2 regression 15 tests, 114,721 checks, 0 failures; in this SoC the fabric carries ~11 k transactions per run under the scoreboard with 0 errors.',
        missing='Meridian has its own transaction format (not ALP): adapters written. It carries only op/tag/dom/priv/tc: ALP attr bits secure / instr / mem_type are dropped, status narrows to OKAY/SLVERR from targets (L-06, L-07). The Citadel is a REFERENCE MODEL (no such IP exists in the repository).',
        problems=['IP-01', 'IP-02', 'IP-05']),
    'ironmemory': dict(project='IronMemory P84 (ECC SRAM + buffer manager)', top='sf_iron_memory', kind='memory',
        tops_for_probe=[('sf_iron_memory', ['rtl/albion/sf_iron_pkg.sv', 'rtl/albion/sf_iron_secded.sv', 'rtl/albion/sf_iron_sram_generic.sv', 'rtl/albion/sf_iron_sram_fpga.sv',
                         'rtl/albion/sf_iron_sram_asic.sv', 'rtl/albion/sf_iron_bank_adapter.sv', 'rtl/albion/sf_iron_bank_arbiter.sv', 'rtl/albion/sf_iron_rob.sv',
                         'rtl/albion/sf_iron_memory_map.sv', 'rtl/albion/sf_iron_buffer_manager.sv', 'rtl/albion/sf_iron_extmem_adapter.sv', 'rtl/albion/sf_iron_memory.sv'])],
        status='USED: 4 banks x 2048 x 64 bit (+8 ECC), 2 ports (domain 0 CPU, domain 1 DMA), FPGA block-RAM backend, buffer manager + CSRs via an MMIO shim; external memory NOT used (EXT_EN = 0); wide port NOT used',
        evidence='Baseline (own run): 17/17 jobs, 213,697 checks PASS on the pristine RTL and IDENTICAL counts on the patched RTL. Verified at DW = 64 only (DW 128 / 256 are claimed by the IP but not exercised by its tests, so the SoC uses 64 plus the ALP width adapter). Here: iron_alp unit test (520 transactions x 3 seeds) and the SoC runs.',
        missing='no register interface for the buffer-manager command port (bm_cmd_*): written (sf_asoc_iron_ctl); no ALP interface: written (sf_asoc_iron_port / sf_asoc_iron_alp); IP-internal domain model has 5 domains, SoC uses 2.',
        problems=['IP-03', 'IP-04', 'IP-07']),
    'clouddma': dict(project='CloudDMA P64 (the BridgeEngine data mover)', top='silicaflux_cloud_dma', kind='dma',
        tops_for_probe=[('silicaflux_cloud_dma', ['rtl/silicaflux_dma_pkg.sv', 'third_party/p61-clouddpu/rtl/sfd_fifo.sv', 'third_party/p61-clouddpu/rtl/sfd_rr_arb.sv', 'rtl/sfdma_burst_plan.sv',
                         'rtl/sfdma_bytebuf.sv', 'rtl/sfdma_crc.sv', 'rtl/sfdma_perm_table.sv', 'rtl/sfdma_perm_checker.sv', 'rtl/sfdma_desc_walker.sv', 'rtl/sfdma_burst_ctrl.sv',
                         'rtl/sfdma_channel.sv', 'rtl/sfdma_perf.sv', 'rtl/sfdma_trace.sv', 'rtl/sfdma_csr.sv', 'rtl/sfdma_axi_mux.sv', 'rtl/silicaflux_cloud_dma.sv'])],
        status='USED unmodified: 1 channel, DW 128, AW 40, 8-beat bursts, REORDER_OK = 0, simulation permission table (USE_EXT_IOMMU = 0)',
        evidence='Baseline (own run): lint 8 configurations 0 warnings, 12 negative parameter checks refused, unit benches PASS, system regression (default, one_out, dw32, dw128, dw256, dw512, inorder, perm_pipe, seed 1) PASS with 7.5-8.7 M checks each. Here: DMA copy 64 B .. 4 KiB with CRC, partial beats, chains, six refusal paths.',
        missing='no command-submission front end (cmd_* is a hardware port): written (sf_asoc_dma_ctl); no AXI4 -> ALP / SFB2 adapter ("none exists in the repository" - its own audit): written (sf_asoc_axi_init); no real IOMMU (only the simulation permission table); no interrupt wiring to ControlCore (polled)',
        problems=['IP-06']),
    'controlcore': dict(project='ControlCore P21 (RV32IM control processor)', top='silicaflux_control_core', kind='cpu',
        tops_for_probe=[],
        status='USED unmodified: RV32IM_Zicsr CPU, boot ROM, I/D SRAM with parity, host port, mailbox, perf counters, RAS, watchdog; accelerator register pages 8..15 answer a bus error (no accelerators); device-memory boot (boot_mode 1) unsupported (needs a 1 MiB device window)',
        evidence='Baseline (own run on the original archive, apt toolchain): boot ROM rebuilt from source is byte-identical to the image in the RTL; system scenario boot_host PASS with 231 firmware checks. Here: the same CPU runs the Albion firmware (124 checks) in every simulation.',
        missing='its external data port speaks SFB2 (32-bit): bridge written (sf_asoc_sfb2_init); its 32-bit EXT windows collide with the Albion 64-bit map: translated by a generated window table; no interrupt source for DMA / memory completion (the RAS SoC-warning input is wired)',
        problems=['IP-08', 'IP-09']),
}

# Integration problems found by the audit / bring-up and how they were resolved (the brief: types, widths, packages, resets, IDs, handshakes, address map)
PROBLEMS = [
    ('IP-01', 'Meridian does not lint under Verilator 5.020', 'sf_meridian_perf cleared its counter array with a non-blocking assignment inside a for loop (BLKLOOPINIT: "Unsupported"). The shipped regression needs a newer Verilator wheel.', 'verilator --lint-only on the pristine tree: %Error-BLKLOOPINIT; run_tb.py cannot start', 'patches/meridian/0002 (blocking clear); regression re-run: 15 tests, 114,721 checks PASS'),
    ('IP-02', 'Meridian and IronMemory do not parse with Yosys 0.33 (the tool every other SilicaFlux flow and AlbionCore pin)', "Meridian: int'() casts. IronMemory: longint'/int' casts, `return` in functions, `import pkg::*` inside module bodies (it was synthesised through sv2v, which is not installable here).", 'yosys read_verilog -sv on the pristine trees: syntax errors at sf_meridian_arbiter.sv:71 and sf_iron_pkg.sv:84', "patches/meridian/0001, patches/ironmemory/0001 (casts, assignments to the function name, include file with the package body); IronMemory's own regression: identical 213,697 checks before and after"),
    ('IP-03', 'THREE incompatible Albion transaction formats and one non-Albion bus in the same repository', 'AlbionCore ALP v1 (64-bit address, 128-bit data, 4-bit op, 8-bit tag, 8-bit domain, 8-bit attr, 4-bit status); Meridian "Albion Transaction Format" (parametric AW/DW, 2-bit op, priv, tc, 3-bit status, no attr); IronMemory (32-bit address, 64-bit data, size, we, 3-bit error); ControlCore SFB2 (32-bit, strobes, 1 error bit); CloudDMA AXI4 (bursts, IDs, sidebands).', "Meridian's own audit: 'the AlbionCore format did not exist ... and is defined here'; port lists compared", 'ALP v1 is the SoC contract: five glue modules convert at every IP boundary (sf_asoc_sfb2_init, sf_asoc_axi_init, sf_asoc_mer_core, sf_asoc_mer_tgt, sf_asoc_iron_port); every conversion is unit tested against an independent Python model'),
    ('IP-04', 'Data width mismatch: ALP 128 bit vs ControlCore 32 bit vs IronMemory 64 bit', 'IronMemory is only verified at DW = 64; CloudDMA is verified at 128 and runs at 128; the CPU is 32 bit.', 'port widths', 'AlbionCore width adapter UPSIZE 32 -> 128 in the CPU bridge and DOWNSIZE 128 -> 64 in front of IronMemory (one wide transaction in flight per port: ~1 byte/cycle, stated in docs/PERFORMANCE.md)'),
    ('IP-05', 'Meridian narrows the information an ALP request carries', 'No secure / instr / mem_type bits; targets can answer only OKAY or SLVERR; DOMW = 3 bits while ALP has 8.', 'docs/meridian/02_PROTOCOL.md section 3', 'domain, privilege and QoS are hardware-bound at the initiator adapters and stamped from config; domains >= 8 and reserved opcodes are forwarded as the reserved opcode and answered PROTOCOL_ERR; the narrowing is documented as limitations L-06 / L-07'),
    ('IP-06', 'CloudDMA cannot be started by software', 'Commands enter through a hardware cmd_* port (the "queue front end" is another project); the permission table is programmed through ptbl_* ports; no CSR does either.', 'CloudDMA docs/04_INTEGRATION.md sections 2, 5', 'sf_asoc_dma_ctl: SUBMIT_* registers (the command DOMAIN is a module parameter, never a register), DONE_* capture, PTBL_* programming port; reachable only by the ControlCore domain (Citadel policy)'),
    ('IP-07', "IronMemory's buffer-manager command port has no register interface and needs a hardware-sourced requester", "'bm_cmd_requester must be driven by the interconnect'", 'IronMemory docs/iron_memory/interfaces.md', 'sf_asoc_iron_ctl: requester = the domain of the access that wrote BM_GO (verified by Meridian at the master port)'),
    ('IP-08', 'Address-map collision: ControlCore EXT window (0x2000_0000..0x3FFF_FFFF, 32-bit) vs the Albion 64-bit map', "AlbionCore reserves the low 4 GiB for 'a future SFB2 bridge'; no region exists for IronMemory's CSR / buffer-manager window.", 'regions.yaml; ControlCore cc_memmap.yaml', 'config/albion_soc.yaml: sram_ctl region added to the catalogue (checked by AlbionCore\'s own collision checker, 8 negative tests); generated window table SFB2 -> ALP; generated C / SV / Markdown from one source'),
    ('IP-09', 'Reset inconsistency risk: ControlCore resets itself (soft / watchdog / host) but the rest of the SoC would not', 'A CPU reset with a DMA burst in flight would leave stale responses in the fabric.', 'reset structure of silicaflux_control_core', "fabric, memory, DMA and bridges run in the ControlCore-derived `acc_rst_no` domain; 5 reset scenarios (host reset and asynchronous reset with 1..5 transactions in flight) pass with no stale response"),
    ('IP-10', 'Invalid / unrepresentable transaction fields', 'ALP tags are 8 bit, Meridian slot tables are small; CloudDMA IDs are 4 bit; ALP domain 8 bit vs Meridian 3 bit.', 'bring-up', 'tags: free-running counters checked on every response; AXI IDs kept in the in-order queue; unrepresentable domains become the reserved opcode (PROTOCOL_ERR)'),
    ('IP-11', 'Read / write handshake errors found by the independent models', 'regtgt derived the register lane from addr[3:2], but an ALP word address is 16-byte aligned (the lane lives only in the byte enables) -> every register read except lane 0 failed; the AXI bridge returned SLVERR instead of DECERR for a multi-beat write burst whose every beat was a decode error.', 'first SoC run (SFB2 trace) and the cocotb axi_init test', 'both fixed in the new glue before they could reach the IP; regression tests kept'),
    ('IP-12', 'Package conflicts', 'silicaflux_pkg exists in 9 distinct bodies across 24 copies in the repository; sf_iron_pkg / sf_meridian_pkg / sf_albion_pkg / cc_memmap_pkg are each internally consistent.', 'audit/inventory.md', 'the SoC imports none of the divergent packages; every package comes from exactly one archive (srclist.py refuses a name declared in two files)'),
]

MISSING_MAJOR_IP = [
    ('Citadel (protection / policy unit)', 'No module with this name or function exists in the repository; Meridian ships a REFERENCE policy table. NOT replaced by anything pretending to be a Citadel: the SoC uses the reference table, programmed by a hardware boot loader + firmware.'),
    ('IOMMU', "None exists. CloudDMA's simulation permission table is used (a verified model of isolation, not hardware isolation by itself)."),
    ('BridgeEngine as a named block', 'Does not exist; it is CloudDMA (P64) + the AXI bridge + sf_asoc_dma_ctl (as the Meridian audit maps it).'),
    ('ControlCore accelerators (vector tile, tensor unit)', 'Not part of the minimum SoC; their register pages answer a bus error.'),
    ('Interrupt wiring from DMA / memory to the CPU', 'Not implemented; firmware polls. The two interrupt lines feed the RAS SoC-warning input only.'),
    ('Real host interface (PCIe / HostLink)', 'Not part of the minimum SoC; the Host Simulation Interface is a testbench BFM and a hardware twin (sf_asoc_host_loader) that loads the firmware.'),
    ('External memory', 'IronMemory supports it; it is not connected (EXT_EN = 0).'),
]


def pristine_tree(ip):
    """copy ip/<name> to a temp dir and reverse the patch series -> the unmodified archive content"""
    tmp = tempfile.mkdtemp(prefix='alb_pristine_')
    dst = os.path.join(tmp, ip)
    shutil.copytree(os.path.join(ROOT, 'ip', ip), dst, ignore=shutil.ignore_patterns('__pycache__'))
    pdir = os.path.join(ROOT, 'patches', ip)
    if os.path.isdir(pdir):
        for p in sorted(os.listdir(pdir), reverse=True):
            if p.endswith('.patch'):
                r = subprocess.run(['patch', '-R', '-p1', '--no-backup-if-mismatch', '-d', dst, '-i', os.path.join(pdir, p)], capture_output=True, text=True)
                if r.returncode:
                    raise SystemExit('cannot reverse %s: %s' % (p, r.stdout + r.stderr))
    return tmp, dst


def probe(treeroot, ip, tops, inc):
    """Verilator -Wall --lint-only and Yosys 0.33 read of each probe top; returns dict"""
    out = {}
    for top, files in tops:
        fl = [os.path.join(treeroot, f) for f in files]
        cmd = 'verilator --lint-only -Wall -Wno-DECLFILENAME --timescale 1ns/1ps %s --top-module %s %s' % (inc, top, ' '.join(fl))
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        txt = r.stdout + r.stderr
        warns = [l for l in txt.splitlines() if re.match(r'%(Warning|Error)', l)]
        kinds = collections.Counter(re.match(r'%(?:Warning|Error)-?([A-Z0-9]*)', l).group(1) or 'ERROR' for l in warns)
        cmd = "yosys -q -p 'read_verilog -defer -sv -DSYNTHESIS %s %s; hierarchy -check -top %s'" % (inc.replace('-I', '-I'), ' '.join(fl), top)
        y = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        yerr = [l for l in (y.stdout + y.stderr).splitlines() if 'ERROR' in l]
        style = {'UNUSEDPARAM', 'UNUSEDSIGNAL', 'DECLFILENAME', 'PINCONNECTEMPTY', 'TIMESCALEMOD', 'UNUSEDGENVAR'}
        func = sum(c for k, c in kinds.items() if k not in style)
        out[top] = dict(verilator_warnings=func, verilator_warnings_all=len(warns), verilator_hard_errors=sum(1 for l in warns if l.startswith('%Error') and 'Exiting' not in l),
                        verilator_by_kind=dict(kinds), verilator_first=[l[:160] for l in warns[:2]],
                        yosys033_ok=(y.returncode == 0 and not yerr), yosys033_first_error=(yerr[0][:200] if yerr else None))
    return out


def main():
    inv = {}
    import gzip
    ip = os.path.join(ROOT, 'audit', 'inventory.json')
    d = None
    if os.path.exists(ip):
        d = json.load(open(ip))
    elif os.path.exists(ip + '.gz'):
        d = json.load(gzip.open(ip + '.gz', 'rt'))
    if d:
        inv = d.get('duplicates', {})
        inv_sum = d['summary']
    else:
        inv_sum = {}
    filelist()
    graph = json.load(open(os.path.join(ROOT, 'build/filelists/soc.json')))
    synth_hier = None
    sp = os.path.join(ROOT, 'build/synth/coarse_hier_stat.txt')
    if os.path.exists(sp):
        synth_hier = open(sp).read()
    probes = {}
    for name, spec in IPS.items():
        if not spec['tops_for_probe']:
            continue
        tmp, tree = pristine_tree(name)
        inc = '-I%s/rtl/albion' % tree if name == 'ironmemory' else ''
        pristine = probe(tree, name, spec['tops_for_probe'], inc)
        shutil.rmtree(tmp, ignore_errors=True)
        patched = probe(os.path.join(ROOT, 'ip', name), name, spec['tops_for_probe'], '-I%s/ip/%s/rtl/albion' % (ROOT, name) if name == 'ironmemory' else '')
        probes[name] = dict(pristine=pristine, patched=patched)
        print('probed', name)
    # ControlCore probe: use the SoC file list (the IP is large): lint the CPU subsystem as the top
    cc_files = [f['file'] for f in graph['files'] if f['file'].startswith('ip/controlcore/')]
    inc = ' '.join('-I' + d for d in graph['incdirs'])
    cc = probe(ROOT, 'controlcore', [('silicaflux_control_core', cc_files)], inc)
    probes['controlcore'] = dict(pristine=cc, patched=cc, note='unmodified IP: one measurement')
    # ----------------------------------------------------------------------------------------------- per-file rows
    rows = []
    for f in graph['files']:
        path = f['file']
        if path.startswith('rtl/soc/'):
            owner, status = 'albionforge', 'NEW (this project): integration glue'
            evidence = 'cocotb unit test (see unit.json) and the system simulations; Verilator -Wall clean; Yosys 0.33 elaboration clean'
            missing, problems = '', []
            kind = 'glue'
        else:
            owner = path.split('/')[1]
            spec = IPS.get(owner)
            status, evidence, missing, problems = (spec['status'], spec['evidence'], spec['missing'], spec['problems']) if spec else ('', '', '', [])
            kind = spec['kind'] if spec else ''
        mods = f['provides']
        dups = {m: inv[m] for m in mods if m in inv}
        patched = False
        prov = json.load(open(os.path.join(ROOT, 'ip', 'PROVENANCE.json'))) if os.path.exists(os.path.join(ROOT, 'ip', 'PROVENANCE.json')) else {}
        if owner in prov:
            rel = path.split('/', 2)[2]
            patched = rel in prov[owner].get('patched_files', [])
        in_synth = None
        if synth_hier:
            in_synth = any(('=== %s' % m in synth_hier) or ('=== $paramod' in synth_hier and m in synth_hier) for m in mods) if mods else None
        rows.append(dict(source_file=path, owner=owner, kind=kind, modules=mods, dependencies=f['needs'], status=status,
                         patched_by_this_project=patched, verification_evidence=evidence,
                         repository_copies={m: dict(copies=d['copies'], distinct_bodies=d['distinct_bodies']) for m, d in dups.items()},
                         synthesizable='yes (Yosys 0.33 elaborates it as part of the SoC; see build/synth)' if True else '',
                         present_in_synthesised_hierarchy=in_synth, missing_interfaces=missing, integration_problems=problems))
    out = dict(
        title='AlbionForge audit manifest',
        repository=inv_sum.get('repo_head'),
        inventory=dict((k, inv_sum.get(k)) for k in ('archives_extracted', 'archives_with_hdl', 'hdl_files', 'distinct_declared_names', 'names_declared_more_than_once',
                                                      'names_with_divergent_bodies', 'packages', 'interfaces', 'hdl_by_path_class')),
        scope='the %d source files the minimum Albion SoC compiles (dependency-resolved from sf_albion_soc_min), %d of them vendored IP in 5 projects, the rest new glue' % (
            len(rows), sum(1 for r in rows if r['owner'] != 'albionforge')),
        ip_summary={k: dict(project=v['project'], status=v['status'], verification_evidence=v['evidence'], missing_interfaces=v['missing'], integration_problems=v['problems'],
                            probes=probes.get(k)) for k, v in IPS.items()},
        integration_problems=[dict(id=a, title=b, detail=c, found_by=d, resolution=e) for a, b, c, d, e in PROBLEMS],
        missing_major_ip=[dict(item=a, handling=b) for a, b in MISSING_MAJOR_IP],
        files=rows)
    json.dump(out, open(os.path.join(ROOT, 'audit', 'manifest.json'), 'w'), indent=1)
    # ------------------------------------------------------------------------------------------------ markdown
    L = ['# Audit manifest of the minimum Albion SoC', '',
         'Generated by `tools/audit/manifest.py` (mechanical facts are measured, curated facts carry their source). Repository HEAD `%s`.' % out['repository'], '',
         '## 1. Repository inventory (every SystemVerilog source, static scan)', '',
         '| item | value |', '|---|---|']
    for k, v in out['inventory'].items():
        L.append('| %s | %s |' % (k.replace('_', ' '), v))
    L += ['', 'Full per-file inventory: `audit/inventory.json` (compressed copy shipped), summary `audit/inventory.md`, declaration index `audit/declarations.tsv`. '
          'The SilicaFlux work lives almost entirely inside nested zip archives: nothing in the repository tree is a buildable project; the five IP projects below were extracted from their archives by `tools/vendor.py` (SHA-256 recorded in `ip/PROVENANCE.json`).', '',
          '## 2. The IP that goes into the SoC', '', '| IP | status in this SoC | verilator -Wall, functional warnings (all incl. style) / hard errors, pristine -> patched | Yosys 0.33 parse (pristine -> patched) |', '|---|---|---|---|']
    for k, v in out['ip_summary'].items():
        pr = v['probes']
        if pr:
            p0 = list(pr['pristine'].values())[0]; p1 = list(pr['patched'].values())[0]
            vl = '%d functional warn (%d incl. style) / %d hard err -> %d (%d) / %d' % (p0['verilator_warnings'], p0['verilator_warnings_all'], p0['verilator_hard_errors'], p1['verilator_warnings'], p1['verilator_warnings_all'], p1['verilator_hard_errors'])
            yo = ('OK' if p0['yosys033_ok'] else 'FAIL: ' + str(p0['yosys033_first_error'])) + ' -> ' + ('OK' if p1['yosys033_ok'] else 'FAIL: ' + str(p1['yosys033_first_error']))
        else:
            vl = yo = 'n/a'
        L.append('| %s | %s | %s | %s |' % (v['project'], v['status'], vl, yo))
    L += ['', '### Verification evidence per IP', '']
    for k, v in out['ip_summary'].items():
        L.append('* **%s** -- %s' % (v['project'], v['verification_evidence']))
    L += ['', '### Missing interfaces per IP', '']
    for k, v in out['ip_summary'].items():
        L.append('* **%s** -- %s' % (v['project'], v['missing_interfaces']))
    L += ['', '## 3. Integration problems found and resolved', '', '| id | problem | found by | resolution |', '|---|---|---|---|']
    for p in out['integration_problems']:
        L.append('| %s | **%s.** %s | %s | %s |' % (p['id'], p['title'], p['detail'], p['found_by'], p['resolution']))
    L += ['', '## 4. Major IP that does not exist and was NOT faked', '', '| item | handling |', '|---|---|']
    for m in out['missing_major_ip']:
        L.append('| %s | %s |' % (m['item'], m['handling']))
    L += ['', '## 5. Source files of the SoC build (dependency order)', '', '| source file | modules | depends on (files) | owner | patched | repo copies (distinct bodies) |', '|---|---|---|---|---|---|']
    for r in rows:
        cp = ', '.join('%s: %d (%d)' % (m, d['copies'], d['distinct_bodies']) for m, d in r['repository_copies'].items()) or '-'
        L.append('| `%s` | %s | %s | %s | %s | %s |' % (r['source_file'], ', '.join('`%s`' % m for m in r['modules']) or '-',
                 ', '.join(os.path.basename(x) for x in r['dependencies']) or '-', r['owner'], 'yes' if r['patched_by_this_project'] else '', cp))
    open(os.path.join(ROOT, 'audit', 'MANIFEST.md'), 'w').write('\n'.join(L) + '\n')
    print('wrote audit/manifest.json and audit/MANIFEST.md (%d files)' % len(rows))


if __name__ == '__main__':
    main()
