#!/usr/bin/env python3
"""AlbionForge repository audit -- inventory of every HDL source in the Aureom.AI repository.

The SilicaFlux work lives almost entirely inside zip archives (often nested).  This tool

  1. walks the repository, lists every archive (name list only for the unrelated ones),
  2. safely extracts the HDL / flow / firmware members of every SilicaFlux archive, recursively,
     into an isolated work directory (nothing extracted is ever executed),
  3. scans every .sv/.svh/.v/.vh/.sf source for module / package / interface declarations,
     instantiations, package scopes, `include files, simulation-only constructs,
  4. resolves instantiation dependencies against the set of declared module names and
     fingerprints each declaration (comment-stripped body hash) so that divergent copies of
     the "same" module are found,
  5. writes inventory.json (machine readable) and inventory.md (summary).

Static analysis only: it does NOT lint or synthesise.  The per-module build status of the
minimum-SoC subset is produced by tools/audit/manifest.py, which runs Verilator and Yosys.

Usage: inventory.py --repo <repo root> --work <scratch dir> --out <output dir>
"""
import argparse, hashlib, io, json, os, re, sys, tarfile, zipfile, collections, time

HDL_EXT = {'.sv', '.svh', '.v', '.vh', '.sf'}
KEEP_EXT = HDL_EXT | {'.sfx', '.f', '.ys', '.sby', '.tcl', '.sdc', '.xdc', '.lpf', '.mk', '.yaml', '.yml',
                      '.c', '.h', '.S', '.ld', '.py', '.md', '.vlt', '.cfg', '.json'}
KEEP_NAMES = {'Makefile', 'makefile'}
MAX_DEPTH = 5
MAX_MEMBER = 8 * 1024 * 1024          # skip individual members bigger than this (never HDL)

KW_NOT_MODULES = {
    'if', 'else', 'for', 'while', 'case', 'casez', 'casex', 'begin', 'end', 'assign', 'always', 'always_ff',
    'always_comb', 'always_latch', 'initial', 'final', 'generate', 'endgenerate', 'function', 'task', 'return',
    'wire', 'logic', 'reg', 'input', 'output', 'inout', 'parameter', 'localparam', 'typedef', 'struct', 'enum',
    'union', 'import', 'export', 'module', 'endmodule', 'package', 'endpackage', 'interface', 'endinterface',
    'assert', 'assume', 'cover', 'property', 'sequence', 'modport', 'genvar', 'integer', 'int', 'bit', 'byte',
    'automatic', 'static', 'unique', 'priority', 'default', 'disable', 'wait', 'fork', 'join', 'forever',
    'repeat', 'posedge', 'negedge', 'or', 'and', 'not', 'xor', 'nand', 'nor', 'buf', 'class', 'program',
    'string', 'real', 'time', 'var', 'const', 'virtual', 'extern', 'timeunit', 'timeprecision', 'bind',
}

RE_BLOCK_COMMENT = re.compile(r'/\*.*?\*/', re.S)
RE_LINE_COMMENT = re.compile(r'//[^\n]*')
RE_STRING = re.compile(r'"(?:\\.|[^"\\])*"')
RE_DECL = re.compile(r'^\s*(?:(?:extern|virtual)\s+)?(module|macromodule|package|interface|program|class)\s+'
                     r'(?:automatic\s+|static\s+)?([A-Za-z_]\w*)', re.M)
RE_INST = re.compile(r'^\s*([A-Za-z_]\w*)\s*(?:#\s*\((?:[^;]*?)\)\s*|\s+)([A-Za-z_]\w*)\s*(?:\[[^\]]*\]\s*)*\(', re.M)
RE_IMPORT = re.compile(r'\bimport\s+([A-Za-z_]\w*)\s*::')
RE_SCOPE = re.compile(r'\b([A-Za-z_]\w*)::[A-Za-z_*]')
RE_INCLUDE = re.compile(r'`include\s+"([^"]+)"')
RE_CLASSIFY = re.compile(r'Classification\s*:\s*([A-Z][A-Z _/-]+)')
SIM_ONLY_PATTERNS = {
    'initial': re.compile(r'^\s*initial\b', re.M),
    'delay': re.compile(r'(^|[;\s])#\s*\d', re.M),
    'display': re.compile(r'\$(display|write|monitor|finish|stop|fatal|error|warning|info)\b'),
    'fileio': re.compile(r'\$(fopen|fwrite|fdisplay|readmem[hb]|fscanf|fgets|fclose)\b'),
    'class': re.compile(r'^\s*class\b', re.M),
    'program': re.compile(r'^\s*program\b', re.M),
    'random': re.compile(r'\$(urandom|random|urandom_range)\b'),
    'force': re.compile(r'\b(force|release)\b'),
    'assert': re.compile(r'\bassert\b'),
}


def strip_comments(text):
    text = RE_BLOCK_COMMENT.sub(lambda m: re.sub(r'[^\n]', ' ', m.group(0)), text)
    text = RE_LINE_COMMENT.sub('', text)
    return RE_STRING.sub('""', text)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def classify_path(p):
    q = p.lower()
    if re.search(r'(^|/)(tb|tests?|testbench|sim|bench|verif|verification|formal|fv|uvm|cocotb)(/|$)', q) or \
            re.search(r'(^|/)(tb|fv)_[^/]*$', q) or re.search(r'_tb\.[a-z]+$', q):
        return 'testbench/formal'
    if '/third_party/' in q or '/vendor/' in q:
        return 'vendored-copy'
    if '/synth' in q or '/syn/' in q or '/fpga' in q:
        return 'flow-wrapper'
    return 'rtl'


class Extractor:
    def __init__(self, work):
        self.work = work
        self.archives = []     # dicts
        self.files = []        # dicts of extracted files of interest
        self.skipped = []

    def safe_dest(self, base, member):
        dest = os.path.normpath(os.path.join(base, member))
        if not dest.startswith(os.path.normpath(base) + os.sep):
            return None
        return dest

    def handle_bytes(self, data, name, chain, base, depth):
        low = name.lower()
        try:
            if low.endswith('.zip'):
                zf = zipfile.ZipFile(io.BytesIO(data))
                self.handle_zip(zf, chain + [name], base, depth)
            elif low.endswith(('.tar.gz', '.tgz', '.tar')):
                tf = tarfile.open(fileobj=io.BytesIO(data))
                self.handle_tar(tf, chain + [name], base, depth)
        except Exception as e:  # corrupt / unsupported archive
            self.skipped.append({'chain': chain + [name], 'reason': 'unreadable archive: %s' % e})

    def want(self, name):
        ext = os.path.splitext(name)[1]
        return ext in KEEP_EXT or os.path.basename(name) in KEEP_NAMES

    def record(self, chain, member, data, base):
        ext = os.path.splitext(member)[1]
        rel = '/'.join(chain + [member])
        dest = self.safe_dest(base, member)
        if dest is None:
            self.skipped.append({'chain': chain, 'member': member, 'reason': 'path traversal refused'})
            return
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, 'wb') as f:
            f.write(data)
        self.files.append({'archive_chain': chain, 'member': member, 'ext': ext, 'size': len(data),
                           'sha256': sha(data), 'path': dest, 'display': rel})

    def handle_zip(self, zf, chain, base, depth):
        arch_dir = os.path.join(base, 'a%04d' % len(self.archives))
        n_hdl = 0
        self.archives.append({'chain': chain, 'members': len(zf.namelist())})
        idx = len(self.archives) - 1
        for info in zf.infolist():
            if info.is_dir() or info.file_size > MAX_MEMBER:
                continue
            name = info.filename
            low = name.lower()
            if low.endswith(('.zip', '.tar.gz', '.tgz')) and depth < MAX_DEPTH:
                try:
                    self.handle_bytes(zf.read(info), name, chain, os.path.join(arch_dir, 'n'), depth + 1)
                except Exception as e:
                    self.skipped.append({'chain': chain, 'member': name, 'reason': str(e)})
            elif self.want(name):
                try:
                    data = zf.read(info)
                except Exception as e:
                    self.skipped.append({'chain': chain, 'member': name, 'reason': str(e)})
                    continue
                self.record(chain, name, data, arch_dir)
                if os.path.splitext(name)[1] in HDL_EXT:
                    n_hdl += 1
        self.archives[idx]['hdl_files'] = n_hdl

    def handle_tar(self, tf, chain, base, depth):
        arch_dir = os.path.join(base, 'a%04d' % len(self.archives))
        n_hdl = 0
        self.archives.append({'chain': chain, 'members': len(tf.getnames())})
        idx = len(self.archives) - 1
        for m in tf.getmembers():
            if not m.isfile() or m.size > MAX_MEMBER:
                continue
            name = m.name
            if name.lower().endswith(('.zip', '.tar.gz', '.tgz')) and depth < MAX_DEPTH:
                self.handle_bytes(tf.extractfile(m).read(), name, chain, os.path.join(arch_dir, 'n'), depth + 1)
            elif self.want(name):
                self.record(chain, name, tf.extractfile(m).read(), arch_dir)
                if os.path.splitext(name)[1] in HDL_EXT:
                    n_hdl += 1
        self.archives[idx]['hdl_files'] = n_hdl


def scan_hdl(path, member):
    raw = open(path, 'rb').read().decode('utf-8', 'replace')
    clean = strip_comments(raw)
    decls = [(k, n) for k, n in RE_DECL.findall(clean) if k != 'class' or True]
    info = {
        'lines': raw.count('\n') + 1,
        'declares': [{'kind': k, 'name': n} for k, n in decls],
        'imports': sorted(set(RE_IMPORT.findall(clean))),
        'scopes': sorted(set(RE_SCOPE.findall(clean))),
        'includes': sorted(set(RE_INCLUDE.findall(raw))),
        'sim_constructs': sorted(k for k, rx in SIM_ONLY_PATTERNS.items() if rx.search(clean)),
        'declared_class': (RE_CLASSIFY.search(raw[:6000]).group(1).strip() if RE_CLASSIFY.search(raw[:6000]) else None),
        'path_class': classify_path(member),
    }
    # split into declaration bodies for fingerprinting + instantiation search
    bodies = {}
    spans = [(m.start(), m.group(1), m.group(2)) for m in RE_DECL.finditer(clean)]
    for i, (s, kind, name) in enumerate(spans):
        e = spans[i + 1][0] if i + 1 < len(spans) else len(clean)
        body = clean[s:e]
        norm = re.sub(r'\s+', ' ', body).strip()
        bodies[name] = {'kind': kind, 'hash': hashlib.sha256(norm.encode()).hexdigest()[:16], 'text': body}
    return info, bodies


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', required=True)
    ap.add_argument('--work', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--scope', default='SilicaFlux',
                    help='only archives whose repo-relative path contains this text are extracted (others: name list only)')
    args = ap.parse_args()
    t0 = time.time()
    os.makedirs(args.work, exist_ok=True)
    os.makedirs(args.out, exist_ok=True)
    ex = Extractor(args.work)
    other_archives = []
    loose = []
    for root, dirs, files in os.walk(args.repo):
        dirs[:] = [d for d in dirs if d != '.git']
        for fn in sorted(files):
            full = os.path.join(root, fn)
            rel = os.path.relpath(full, args.repo)
            low = fn.lower()
            ext = os.path.splitext(fn)[1]
            if low.endswith(('.zip', '.tar.gz', '.tgz')):
                if args.scope.lower() in rel.lower():
                    with open(full, 'rb') as f:
                        data = f.read()
                    ex.handle_bytes(data, rel, [], os.path.join(args.work, 'r%05d' % len(ex.archives)), 0)
                else:
                    try:
                        names = zipfile.ZipFile(full).namelist() if low.endswith('.zip') else []
                    except Exception:
                        names = []
                    hdl = [n for n in names if os.path.splitext(n)[1] in HDL_EXT]
                    other_archives.append({'path': rel, 'members': len(names), 'hdl_members': len(hdl)})
            elif ext in HDL_EXT:
                data = open(full, 'rb').read()
                ex.files.append({'archive_chain': [], 'member': rel, 'ext': ext, 'size': len(data), 'sha256': sha(data),
                                 'path': full, 'display': rel})
                loose.append(rel)

    # ---- scan
    records = []
    decl_index = collections.defaultdict(list)       # name -> list of (record idx, kind, hash)
    all_bodies = []
    for f in ex.files:
        if f['ext'] not in HDL_EXT:
            continue
        info, bodies = scan_hdl(f['path'], f['member'])
        rec = {'file': f['display'], 'ext': f['ext'], 'size': f['size'], 'sha256': f['sha256'],
               'archive_chain': f['archive_chain'], 'member': f['member'], **info, 'instances': []}
        ri = len(records)
        records.append(rec)
        all_bodies.append(bodies)
        for name, b in bodies.items():
            decl_index[name].append((ri, b['kind'], b['hash']))

    names = set(decl_index)
    for ri, rec in enumerate(records):
        bodies = all_bodies[ri]
        inst = collections.Counter()
        for dname, b in bodies.items():
            if b['kind'] not in ('module', 'macromodule', 'interface', 'program'):
                continue
            for m in RE_INST.finditer(b['text']):
                t = m.group(1)
                if t in KW_NOT_MODULES or t == dname:
                    continue
                if t in names:
                    inst[(dname, t)] += 1
        rec['instances'] = [{'in': a, 'module': b, 'count': c} for (a, b), c in sorted(inst.items())]

    # ---- summary statistics
    dup = {}
    for name, lst in decl_index.items():
        if len(lst) > 1:
            dup[name] = {'copies': len(lst), 'distinct_bodies': len({h for _, _, h in lst}),
                         'kind': lst[0][1]}
    cls_counts = collections.Counter(r['path_class'] for r in records)
    ext_counts = collections.Counter(r['ext'] for r in records)
    pkgs = sorted(n for n, l in decl_index.items() if l[0][1] == 'package')
    ifaces = sorted(n for n, l in decl_index.items() if l[0][1] == 'interface')
    flows = collections.Counter(f['ext'] for f in ex.files if f['ext'] in {'.ys', '.sby', '.tcl', '.sdc', '.xdc', '.lpf', '.mk'})
    inv = {
        'generated_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'repo_head': None,
        'archives_extracted': len(ex.archives),
        'archives_with_hdl': sum(1 for a in ex.archives if a.get('hdl_files', 0) > 0),
        'hdl_files': len(records),
        'hdl_by_ext': dict(ext_counts),
        'hdl_by_path_class': dict(cls_counts),
        'distinct_declared_names': len(decl_index),
        'names_declared_more_than_once': len(dup),
        'names_with_divergent_bodies': sum(1 for d in dup.values() if d['distinct_bodies'] > 1),
        'packages': len(pkgs), 'interfaces': len(ifaces),
        'flow_files': dict(flows),
        'loose_hdl_in_repo_tree': loose,
        'other_archives_scanned_by_name': len(other_archives),
        'other_archives_with_hdl': [a for a in other_archives if a['hdl_members']],
        'skipped': ex.skipped[:200],
        'seconds': round(time.time() - t0, 1),
    }
    try:
        import subprocess
        inv['repo_head'] = subprocess.check_output(['git', '-C', args.repo, 'rev-parse', 'HEAD'], text=True).strip()
    except Exception:
        pass
    with open(os.path.join(args.out, 'inventory.json'), 'w') as f:
        json.dump({'summary': inv, 'duplicates': dup, 'packages': pkgs, 'interfaces': ifaces,
                   'archives': [{'chain': a['chain'], 'hdl_files': a.get('hdl_files', 0)} for a in ex.archives],
                   'files': [{k: v for k, v in r.items()} for r in records]}, f, indent=1, sort_keys=True)
    # compact declaration index (module -> where)
    with open(os.path.join(args.out, 'declarations.tsv'), 'w') as f:
        f.write('name\tkind\tcopies\tdistinct_bodies\tfirst_file\n')
        for name in sorted(decl_index):
            lst = decl_index[name]
            f.write('%s\t%s\t%d\t%d\t%s\n' % (name, lst[0][1], len(lst), len({h for _, _, h in lst}), records[lst[0][0]]['file']))
    with open(os.path.join(args.out, 'inventory.md'), 'w') as f:
        f.write('# HDL inventory of the Aureom.AI repository\n\n')
        f.write('Generated by `tools/audit/inventory.py` (static analysis: no lint, no synthesis).  Repository HEAD `%s`.\n\n' % inv['repo_head'])
        f.write('| Item | Value |\n|---|---|\n')
        for k in ('archives_extracted', 'archives_with_hdl', 'hdl_files', 'distinct_declared_names',
                  'names_declared_more_than_once', 'names_with_divergent_bodies', 'packages', 'interfaces',
                  'other_archives_scanned_by_name'):
            f.write('| %s | %s |\n' % (k.replace('_', ' '), inv[k]))
        f.write('| HDL files by extension | %s |\n' % json.dumps(inv['hdl_by_ext']))
        f.write('| HDL files by path class | %s |\n' % json.dumps(inv['hdl_by_path_class']))
        f.write('| flow files | %s |\n' % json.dumps(inv['flow_files']))
        f.write('| loose HDL files checked into the repository tree | %d |\n' % len(loose))
        f.write('| archives outside the SilicaFlux scope that contain HDL | %d |\n\n' % len(inv['other_archives_with_hdl']))
        f.write('## Packages declared in more than one distinct body (divergent copies)\n\n| package | copies | distinct bodies |\n|---|---|---|\n')
        for n in pkgs:
            d = dup.get(n)
            if d and d['distinct_bodies'] > 1:
                f.write('| `%s` | %d | %d |\n' % (n, d['copies'], d['distinct_bodies']))
        f.write('\n## Most duplicated module names (top 25)\n\n| module | copies | distinct bodies |\n|---|---|---|\n')
        for n, d in sorted(dup.items(), key=lambda kv: -kv[1]['copies'])[:25]:
            f.write('| `%s` | %d | %d |\n' % (n, d['copies'], d['distinct_bodies']))
    print(json.dumps({k: v for k, v in inv.items() if not isinstance(v, (list, dict)) or k in ('hdl_by_ext', 'hdl_by_path_class')}, indent=1))


if __name__ == '__main__':
    main()
