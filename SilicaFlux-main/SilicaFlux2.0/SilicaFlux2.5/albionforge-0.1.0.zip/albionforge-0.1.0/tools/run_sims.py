#!/usr/bin/env python3
"""albion-sim: build the system simulation variants and run the scenario matrix.  The DUT executes the REAL boot ROM and the
cross-compiled firmware image; the testbench (tb/tb_albion_soc.sv) is the host + independent checker.
Result: build/reports/sim.json (per-run JSON from the testbench is kept in build/run/)."""
import concurrent.futures as cf, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

VARIANTS = [(0, 0x1BADB002), (15, 11), (40, 22), (70, 33)]            # (STALL_PCT, STALL_SEED)
RUNS = [  # (variant stall pct, scenario, extra plusargs)
    (0, 'normal', ''), (15, 'normal', ''), (40, 'normal', ''), (70, 'normal', ''),
    (0, 'normal', '+hostbp=60'),
    (0, 'reset_mid_dma', '+rst_at=0'), (0, 'reset_mid_dma', '+rst_at=37'), (0, 'reset_mid_dma', '+rst_at=300'),
    (40, 'reset_mid_dma', '+rst_at=11'),
    (0, 'reset_early', '+rst_at=5'), (0, 'reset_async', '+rst_at=0'), (0, 'reset_async', '+rst_at=120'), (40, 'reset_async', '+rst_at=75'),
]
FW = 'build/fw/albion_fw.hex'


def build(stall, seed):
    mdir = 'build/sim_s%d' % stall
    cmd = ('verilator --binary --timing -O2 -j 4 -Wno-fatal -Wno-lint -Wno-style --timescale 1ns/1ps lint/albion.vlt --top-module tb_albion_soc '
           '-Mdir %s -o vtb_albion_soc -f build/filelists/soc.f tb/alp_scoreboard.sv tb/tb_albion_soc.sv -GSTALL_PCT=%d -GSTALL_SEED=%d' % (mdir, stall, seed))
    rc, dt, out = sh(cmd, log=os.path.join(BUILD, 'logs', 'sim_build_s%d.log' % stall))
    return stall, rc, dt


def run(i, stall, scen, extra):
    name = '%02d_%s_s%d%s' % (i, scen, stall, extra.replace('+', '_').replace('=', ''))
    out = os.path.join(BUILD, 'run', name + '.json')
    log = os.path.join(BUILD, 'run', name + '.log')
    cmd = 'build/sim_s%d/vtb_albion_soc +scenario=%s +fw=%s +out=%s +log=%s +timeout=12000000 %s' % (stall, scen, FW, out, log + '.console', extra)
    rc, dt, o = sh(cmd, log=log, timeout=1800)
    try:
        j = json.load(open(out))
    except Exception:
        j = {}
    return dict(name=name, scenario=scen, stall_pct=stall, args=extra, rc=rc, seconds=round(dt, 1), pass_=(rc == 0 and j.get('pass') == 1), json=os.path.relpath(out, ROOT), result=j)


def main():
    if not os.path.exists(os.path.join(ROOT, FW)):
        sys.exit('firmware image missing: run `make albion-firmware` first')
    os.makedirs(os.path.join(BUILD, 'run'), exist_ok=True)
    filelist()
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        b = list(ex.map(lambda v: build(*v), VARIANTS))
    for stall, rc, dt in b:
        print('build STALL_PCT=%-3d rc=%d %.0fs' % (stall, rc, dt))
        if rc:
            sys.exit('simulation build failed: see build/logs/sim_build_s%d.log' % stall)
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get('JOBS', '4'))) as ex:
        res = list(ex.map(lambda a: run(a[0], *a[1]), enumerate(RUNS)))
    for r in res:
        j = r['result']
        sb = j.get('scoreboard', {})
        print('%-40s %s %5.1fs  cycles=%-8s fw=%s/%s backdoor=%s scoreboard=%s checks/%s err' % (
            r['name'], 'PASS' if r['pass_'] else 'FAIL', r['seconds'], j.get('cycles'), j.get('firmware', {}).get('checks'),
            j.get('firmware', {}).get('fails'), j.get('backdoor', {}).get('checks'), sb.get('checks'), sb.get('errors')))
    ok = all(r['pass_'] for r in res)
    # ---- board-neutral FPGA wrapper: boots the real firmware by itself (hardware loader, UART, LEDs)
    filelist(top='sf_albion_fpga_top', out='build/filelists/fpga.f', roots=SOC_ROOTS + ['rtl/fpga'])
    rc, dt, out = sh('verilator --binary --timing -O2 -j 4 -Wno-fatal -Wno-lint -Wno-style --timescale 1ns/1ps lint/albion.vlt --top-module tb_fpga_top -Mdir build/sim_fpga '
                     '-o vtb_fpga_top -f build/filelists/fpga.f tb/tb_fpga_top.sv', log=os.path.join(BUILD, 'logs', 'sim_build_fpga.log'))
    fp = {'pass_': False, 'pass': False, 'summary': 'build failed'}
    if rc == 0:
        rc, dt, out = sh('build/sim_fpga/vtb_fpga_top', log=os.path.join(BUILD, 'run', 'fpga_top.log'), timeout=3600)
        line = [l for l in out.splitlines() if l.startswith('TB FPGA RESULT')]
        ok_ = rc == 0 and bool(line) and 'PASS' in line[-1]
        fp = {'pass_': ok_, 'pass': ok_, 'summary': line[-1] if line else 'no result line', 'seconds': round(dt, 1)}
    write_json('fpga_sim.json', fp)
    print('fpga wrapper simulation: %s' % fp['summary'])
    ok = ok and fp['pass']
    slim = []
    for r in res:
        j = r['result']
        slim.append(dict(name=r['name'], scenario=r['scenario'], stall_pct=r['stall_pct'], args=r['args'], pass_=r['pass_'], seconds=r['seconds'],
                         cycles=j.get('cycles'), firmware=j.get('firmware'), backdoor=j.get('backdoor'), sfb2_monitor=j.get('sfb2_monitor'),
                         scoreboard={k: v for k, v in j.get('scoreboard', {}).items() if k != 'links'}, links=j.get('scoreboard', {}).get('links'),
                         firmware_perf=j.get('firmware_perf'), json=r['json']))
    write_json('sim.json', dict(ok=ok, runs=slim, total=len(res), passed=sum(r['pass_'] for r in res), firmware=FW))
    print('system simulations: %d/%d runs passed' % (sum(r['pass_'] for r in res), len(res)))
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
