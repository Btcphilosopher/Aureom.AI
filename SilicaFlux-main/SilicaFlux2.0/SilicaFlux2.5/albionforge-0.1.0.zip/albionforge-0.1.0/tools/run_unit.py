#!/usr/bin/env python3
"""albion-test (RTL unit tests): cocotb 1.9.2 + Verilator 5.020 tests of every new glue module, each against an INDEPENDENT Python
model (the expected results are computed in the test, never read from the RTL).  Several seeds / back-pressure variants.
Result: build/reports/unit.json."""
import concurrent.futures as cf, json, os, re, sys, xml.etree.ElementTree as ET
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

ALB = ['ip/albioncore/rtl/albion/' + f for f in ('sf_albion_pkg.sv', 'sf_albion_fifo.sv', 'sf_albion_skid.sv', 'sf_albion_regslice.sv', 'sf_albion_width_adapter.sv')]
IRON = ['ip/ironmemory/rtl/albion/' + f for f in ('sf_iron_pkg.sv', 'sf_iron_secded.sv', 'sf_iron_sram_generic.sv', 'sf_iron_sram_fpga.sv', 'sf_iron_sram_asic.sv',
        'sf_iron_bank_adapter.sv', 'sf_iron_bank_arbiter.sv', 'sf_iron_rob.sv', 'sf_iron_memory_map.sv', 'sf_iron_buffer_manager.sv',
        'sf_iron_extmem_adapter.sv', 'sf_iron_memory.sv')]
TESTS = [
    dict(name='regtgt', top='sf_asoc_regtgt', mod='test_regtgt', srcs=['ip/albioncore/rtl/albion/sf_albion_pkg.sv', 'rtl/soc/sf_asoc_regtgt.sv'], params='', seeds=[7, 8, 9]),
    dict(name='axi_init', top='sf_asoc_axi_init', mod='test_axi_init', srcs=ALB[:2] + ['rtl/soc/sf_asoc_gate.sv', 'rtl/soc/sf_asoc_axi_init.sv'], params='', seeds=[3, 11, 29, 47]),
    dict(name='axi_init_stall40', top='sf_asoc_axi_init', mod='test_axi_init', srcs=ALB[:2] + ['rtl/soc/sf_asoc_gate.sv', 'rtl/soc/sf_asoc_axi_init.sv'], params='-GSTALL_PCT=40', seeds=[5, 13]),
    dict(name='sfb2_init', top='wrap_sfb2_init', mod='test_sfb2_init', srcs=ALB + ['rtl/soc/sf_asoc_gate.sv', 'rtl/soc/sf_asoc_sfb2_init.sv', 'tests/unit/wrap_sfb2_init.sv'], params='', seeds=[5, 6, 7]),
    dict(name='iron_alp', top='sf_asoc_iron_alp', mod='test_iron_alp', srcs=ALB + ['rtl/soc/gen/sf_asoc_cfg_pkg.sv'] + IRON + ['rtl/soc/sf_asoc_iron_port.sv', 'rtl/soc/sf_asoc_iron_alp.sv'],
         params='-I%s/ip/ironmemory/rtl/albion' % ROOT, seeds=[9, 33, 44]),
]


def run_one(t, seed):
    d = os.path.join(BUILD, 'unit')
    os.makedirs(d + '/logs', exist_ok=True)
    res = os.path.join(d, 'logs', '%s_s%d.xml' % (t['name'], seed))
    log = os.path.join(d, 'logs', '%s_s%d.log' % (t['name'], seed))
    cmd = 'make -C tests/unit -f Makefile.unit TOP=%s MOD=%s SRCS="%s" PARAMS="%s" SIM_BUILD=%s/%s' % (
        t['top'], t['mod'], ' '.join(t['srcs']), t['params'], d, t['name'])
    rc, dt, out = sh(cmd, log=log, env=dict(SEED=str(seed), COCOTB_RESULTS_FILE=res, PYTHONPATH=os.path.join(ROOT, 'tests/unit')), timeout=1200)
    info = [l.split('INFO', 1)[1].strip() for l in out.splitlines() if 'INFO' in l and t['name'].replace('_stall40', '') in l.split('INFO')[0] and ':' in l.split('INFO')[1]]
    tests = fails = 0
    try:
        for tc in ET.parse(res).getroot().iter('testcase'):
            tests += 1
            if tc.find('failure') is not None or tc.find('error') is not None:
                fails += 1
    except Exception:
        fails = 1
    return dict(name=t['name'], seed=seed, rc=rc, tests=tests, failures=fails, seconds=round(dt, 1), pass_=(rc == 0 and tests > 0 and fails == 0), summary=info[-1] if info else '')


def main():
    # build once per DUT (first seed), then the other seeds reuse the build
    results = []
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get('JOBS', '4'))) as ex:
        firsts = {t['name']: ex.submit(run_one, t, t['seeds'][0]) for t in TESTS}
        for t in TESTS:
            results.append(firsts[t['name']].result())
        rest = [ex.submit(run_one, t, s) for t in TESTS for s in t['seeds'][1:]]
        for f in rest:
            results.append(f.result())
    results.sort(key=lambda r: (r['name'], r['seed']))
    for r in results:
        print('%-18s seed %-3d %s  %5.1fs  %s' % (r['name'], r['seed'], 'PASS' if r['pass_'] else 'FAIL', r['seconds'], r['summary'][:110]))
    ok = all(r['pass_'] for r in results)
    write_json('unit.json', dict(ok=ok, runs=results, total=len(results), passed=sum(r['pass_'] for r in results)))
    print('unit tests: %d/%d runs passed' % (sum(r['pass_'] for r in results), len(results)))
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
