#!/usr/bin/env python3
"""AlbionForge SoC generator.

Reads  config/albion_soc.yaml  and the AlbionCore region catalogue, validates the resulting address map with
AlbionCore's own collision checker (E_OVERLAP / E_ALIGN / E_RESERVED ...), and writes

    rtl/soc/gen/sf_asoc_cfg_pkg.sv       SystemVerilog constants (Meridian parameters, windows, boot policy, registers)
    fw/include/albion_soc_map.h          the same numbers for firmware (C)
    docs/MEMORY_MAP_SOC.md               human-readable map
    reports/memory_map_soc.json          machine-readable map

so that RTL, firmware and documentation cannot disagree.  `--check` fails if the committed files are stale.
Nothing is written when the map is illegal.
"""
import argparse, json, os, sys, textwrap

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ALB = os.path.join(ROOT, 'ip', 'albioncore')
sys.path.insert(0, os.path.join(ALB, 'tools', 'albion', 'build'))
import yaml  # noqa: E402
import gen_memmap as gm  # noqa: E402  (AlbionCore's checker: refuses overlapping / misaligned regions)

# ----------------------------------------------------------------------------------------------------------------------
# Register maps of the three MMIO shims (offsets inside the 4 KiB region window).  Single source for SV, C and docs.
# (name, offset, access, description)
REGS = {
    'SOC': [  # region `perf`: SoC control
        ('ID',            0x000, 'RO', '0x414C424E "ALBN"'),
        ('VERSION',       0x004, 'RO', 'SoC integration version 1.0 = 0x0001_0000'),
        ('CONFIG',        0x008, 'RO', '[7:0] NM, [15:8] NT, [23:16] policy entries, [31:24] Meridian counter count'),
        ('STATUS',        0x00C, 'RO', '[0] policy_ready (boot policy loaded), [1] policy_busy'),
        ('CYCLES_LO',     0x010, 'RO', 'free-running cycle counter since reset, low word'),
        ('CYCLES_HI',     0x014, 'RO', 'high word (reading LO latches HI)'),
        ('CTRL',          0x018, 'RW', 'W1S self-clearing: [0] perf_clear [2] elog_clear [3] zombie flush [7:4] iso_clear per target; RW: [1] perf_freeze'),
        ('ISO',           0x01C, 'RO', 'Meridian o_iso: [m*NT+t] target t isolated for master port m'),
        ('PERF_SEL',      0x020, 'RW', 'Meridian counter index'),
        ('PERF_DATA',     0x024, 'RO', 'Meridian counter value selected by PERF_SEL (32-bit saturating)'),
        ('ELOG_VALID',    0x030, 'RO', '[0] error log holds a fault (sticky until ELOG clear)'),
        ('ELOG_INFO',     0x034, 'RO', '[3:0] fault code F_*, [6:4] status ST_*, [11:8] src master, [15:12] target, [19:16] dom, [31:24] tag'),
        ('ELOG_ADDR_LO',  0x038, 'RO', 'address of the first fault, low word'),
        ('ELOG_ADDR_HI',  0x03C, 'RO', 'address of the first fault, high word'),
        ('ELOG_COUNT',    0x040, 'RO', 'faults since reset'),
        ('POL_IDX',       0x050, 'RW', 'Citadel policy entry index'),
        ('POL_SRC',       0x054, 'RW', 'entry: master mask'),
        ('POL_DOM',       0x058, 'RW', 'entry: domain mask'),
        ('POL_FLAGS',     0x05C, 'RW', 'entry: [0] valid [1] need_priv [2] read [3] write'),
        ('POL_BASE_LO',   0x060, 'RW', 'entry: base, low word'),
        ('POL_BASE_HI',   0x064, 'RW', 'entry: base, high word'),
        ('POL_MASK_LO',   0x068, 'RW', 'entry: mask, low word'),
        ('POL_MASK_HI',   0x06C, 'RW', 'entry: mask, high word'),
        ('POL_GO',        0x070, 'WO', 'write 1: write the entry (refused while the boot loader is busy)'),
        ('POL_ENTRIES',   0x074, 'RO', 'number of policy entries in the table'),
        ('SEC_EVENTS',    0x078, 'RO', 'security events: requests DENIED by the fabric since reset'),
    ],
    'IRON': [  # region `sram_ctl`: IronMemory CSR passthrough at 0x000..0x7FF + buffer-manager command shim at 0x800
        ('BM_ID',         0x800, 'RW', 'descriptor id for FREE / TRANSFER / QUERY / CLEAR_ERR'),
        ('BM_TYPE',       0x804, 'RW', 'buffer type'),
        ('BM_START_LO',   0x808, 'RW', 'ALLOC_AT start address (byte), low word'),
        ('BM_START_HI',   0x80C, 'RW', 'ALLOC_AT start address, high word'),
        ('BM_LEN',        0x810, 'RW', 'length in bytes'),
        ('BM_OWNER',      0x814, 'RW', 'owner domain'),
        ('BM_RDMASK',     0x818, 'RW', 'per-domain read permission mask'),
        ('BM_WRMASK',     0x81C, 'RW', 'per-domain write permission mask'),
        ('BM_GO',         0x820, 'WO', 'write the operation code (0 ALLOC 1 ALLOC_AT 2 FREE 3 TRANSFER 4 QUERY 5 CLEAR_ERR): issue; requester = dom of this access'),
        ('BM_STATUS',     0x824, 'RO', '[0] busy [1] done (response of the last command valid) [7:4] response status BMS_*'),
        ('BM_RSP_ID',     0x828, 'RO', 'response: descriptor id'),
        ('BM_RSP_INFO',   0x82C, 'RO', 'response: [0] in_use [6:4] type [10:8] owner'),
        ('BM_RSP_START_LO', 0x830, 'RO', 'response: buffer start, low word'),
        ('BM_RSP_START_HI', 0x834, 'RO', 'response: buffer start, high word'),
        ('BM_RSP_LEN',    0x838, 'RO', 'response: buffer length'),
        ('BM_RSP_RDMASK', 0x83C, 'RO', 'response: read mask'),
        ('BM_RSP_WRMASK', 0x840, 'RO', 'response: write mask'),
        ('BM_RSP_ERRBITS', 0x844, 'RO', 'response: [0] read-perm [1] write-perm [2] bounds [3] ECC CE [4] ECC UE'),
        ('BM_REQUESTER',  0x848, 'RO', 'domain that issued the last command (hardware-sourced)'),
    ],
    'DMA': [  # region `dma`: CloudDMA CSR passthrough at 0x000..0x7FF + submission / completion / permission-table shims
        ('SUBMIT_HEAD_LO', 0x800, 'RW', 'IOVA of the head descriptor, low word'),
        ('SUBMIT_HEAD_HI', 0x804, 'RW', 'IOVA of the head descriptor, high word'),
        ('SUBMIT_ASID',   0x808, 'RW', 'address space of the descriptors'),
        ('SUBMIT_GO',     0x80C, 'WO', 'write 1: submit the command; the domain is bound by hardware (BIND_DOM), never by software'),
        ('SUBMIT_STATUS', 0x810, 'RO', '[0] command port ready [1] outstanding command [2] a submit was refused (sticky, W1C)'),
        ('DONE_COUNT',    0x814, 'RO', 'completions seen'),
        ('DONE_LAST',     0x818, 'RO', '[3:0] status (0 OK 1 ERROR 2 ABORTED) [7:4] fault [15:8] err [31:16] txn'),
        ('DONE_BYTES',    0x81C, 'RO', 'destination bytes acknowledged by the last completion'),
        ('DONE_CRC',      0x820, 'RO', 'CRC of the last completion (when enabled)'),
        ('VIOL_COUNT',    0x824, 'RO', 'isolation violations signalled by the DMA'),
        ('LAT_LAST',      0x828, 'RO', 'cycles from SUBMIT_GO to the completion of the last command'),
        ('BIND_DOM',      0x82C, 'RO', 'hardware binding of the submission queue (domain)'),
        ('AXI_ERRS',      0x830, 'RO', 'AXI-to-ALP bridge: [15:0] error responses returned to the DMA, [31:16] requests refused locally (sideband check)'),
        ('PTBL_IDX',      0x840, 'RW', 'permission-table entry index'),
        ('PTBL_DOM',      0x844, 'RW', 'entry: domain'),
        ('PTBL_ASID',     0x848, 'RW', 'entry: address space'),
        ('PTBL_BASE_LO',  0x84C, 'RW', 'entry: IOVA base, low word'),
        ('PTBL_BASE_HI',  0x850, 'RW', 'entry: IOVA base, high word'),
        ('PTBL_SIZE_LO',  0x854, 'RW', 'entry: size, low word'),
        ('PTBL_SIZE_HI',  0x858, 'RW', 'entry: size, high word'),
        ('PTBL_PA_LO',    0x85C, 'RW', 'entry: physical base, low word'),
        ('PTBL_PA_HI',    0x860, 'RW', 'entry: physical base, high word'),
        ('PTBL_FLAGS',    0x864, 'RW', 'entry: [0] valid [1] read [2] write'),
        ('PTBL_GO',       0x868, 'WO', 'write 1: write the entry'),
        ('PTBL_STATUS',   0x86C, 'RO', '[0] an entry write was refused (sticky, W1C)'),
    ],
}

PORT_REGION_OF_BLOCK = {'SOC': 'perf', 'IRON': 'sram_ctl', 'DMA': 'dma'}


CONFIG = os.path.join(ROOT, 'config', 'albion_soc.yaml')


def load(config=None):
    cfg = yaml.safe_load(open(config or CONFIG))
    cat = yaml.safe_load(open(os.path.join(ALB, 'tools', 'albion', 'config', 'regions.yaml')))
    return cfg, cat


def attr_bits(a):
    """AlbionCore region-attribute byte (sf_region_attr_t) from a catalogue attr dict."""
    mt = {'normal_wb': 0, 'normal_nc': 1, 'device': 2}[a.get('mem_type', 'normal_wb')]
    v = (mt << 6) | (int(a.get('cacheable', False)) << 5) | (int(a.get('secure_only', False)) << 4) \
        | (int(a.get('priv_only', False)) << 3) | (int(a.get('exec', False)) << 2) \
        | (int(a.get('write', False)) << 1) | int(a.get('read', False))
    return v


def build_model(config=None):
    cfg, cat = load(config)
    regs = {r['name']: dict(r) for r in cat['regions']}
    for r in cfg.get('catalogue_extension', []):
        if r['name'] in regs:
            raise SystemExit('catalogue_extension region %s already exists in the catalogue' % r['name'])
        regs[r['name']] = dict(r)
    used = []
    for name, ov in cfg['regions'].items():
        if name not in regs:
            raise SystemExit('region %s is not in the catalogue' % name)
        r = dict(regs[name])
        r['size'] = ov['size']
        used.append(r)
    # ---- validation with AlbionCore's checker
    errs = gm.check_regions(used, cat.get('reserved', []), cat['address_width'], cat['min_region_bytes'])
    if errs:
        raise SystemExit('illegal address map:\n' + '\n'.join('  %s: %s' % e for e in errs))
    # ---- targets
    by_name = {r['name']: r for r in used}
    targets = sorted(cfg['targets'], key=lambda t: t['index'])
    assert [t['index'] for t in targets] == list(range(len(targets)))
    for t in targets:
        r = by_name[t['region']]
        t['base'] = r['base']; t['size'] = r['size']; t['mask'] = ((1 << 64) - 1) & ~(r['size'] - 1)
        t['attr'] = attr_bits(r['attr']); t['priv_only'] = bool(r['attr'].get('priv_only', False))
    masters = sorted(cfg['masters'], key=lambda m: m['index'])
    mi = {m['name']: m for m in masters}
    # ---- boot policy
    pol = []
    for p in cfg['boot_policy']:
        t = next(t for t in targets if t['region'] == p['region'])
        for mname in p['masters']:
            m = mi[mname]
            pol.append(dict(src=1 << m['index'], dom=1 << m['dom'], priv=int(t['priv_only']), base=t['base'],
                            mask=t['mask'], rd=int(p['rd']), wr=int(p['wr']), desc='%s -> %s' % (mname, p['region'])))
    if len(pol) > cfg['meridian']['CIT_NENT']:
        raise SystemExit('boot policy needs %d entries, CIT_NENT is %d' % (len(pol), cfg['meridian']['CIT_NENT']))
    # ---- ControlCore windows
    ccw = []
    for w in cfg['cc_windows']:
        r = by_name[w['region']]
        ccw.append(dict(region=w['region'], cc_base=w['cc_base'], size=r['size'], mask=(0xFFFFFFFF & ~(r['size'] - 1)),
                        alp_base=r['base']))
    # ControlCore EXT window sanity + non-overlap
    for w in ccw:
        if not (0x20000000 <= w['cc_base'] and w['cc_base'] + w['size'] <= 0x40000000):
            raise SystemExit('cc window %s is outside the ControlCore EXT window' % w['region'])
        if w['cc_base'] % w['size']:
            raise SystemExit('cc window %s is not aligned to its size' % w['region'])
    for i, a in enumerate(ccw):
        for b in ccw[i + 1:]:
            if a['cc_base'] < b['cc_base'] + b['size'] and b['cc_base'] < a['cc_base'] + a['size']:
                raise SystemExit('cc windows %s and %s overlap' % (a['region'], b['region']))
    # physical memory must match the window
    iron = cfg['iron']
    phys = iron['banks'] * iron['depth'] * 8
    sram = by_name['sram']['size']
    if phys != sram:
        raise SystemExit('IronMemory capacity %d B != sram region size %d B' % (phys, sram))
    return cfg, used, targets, masters, pol, ccw


def sv_hex(v, bits):
    return "%d'h%0*X" % (bits, (bits + 3) // 4, v)


def concat(vals, bits):
    """SystemVerilog concatenation, element 0 in the least-significant position."""
    return '{' + ', '.join(sv_hex(v, bits) for v in reversed(vals)) + '}'


def emit_sv(cfg, used, targets, masters, pol, ccw):
    m = cfg['meridian']; NM, NT = m['NM'], m['NT']; iron = cfg['iron']; dma = cfg['dma']
    L = []
    A = L.append
    A('// GENERATED by tools/gen_soc.py from config/albion_soc.yaml -- do not edit.')
    A('// AlbionForge: constants of the minimum Albion SoC (address map, Meridian parameters, boot policy, registers).')
    A('`default_nettype none')
    A('')
    A('/* verilator lint_off UNUSEDPARAM */')
    A('package sf_asoc_cfg_pkg;')
    A('  // ---- Meridian fabric')
    for k in ('NM', 'NT', 'DOMW', 'TAGW', 'REQ_DEPTH', 'ARB_MODE', 'STARVE', 'CITADEL_MODE', 'CIT_NENT', 'CIT_LAT', 'TMO', 'ISOLATE'):
        A('  localparam int unsigned MER_%-12s = %d;' % (k, m[k]))
    A('  localparam int unsigned ALP_AW = 64;')
    A('  localparam int unsigned ALP_DW = 128;')
    A('  localparam logic [%d:0] MER_TGT_BASE = %s;' % (NT * 64 - 1, concat([t['base'] for t in targets], 64)))
    A('  localparam logic [%d:0] MER_TGT_MASK = %s;' % (NT * 64 - 1, concat([t['mask'] for t in targets], 64)))
    A('  localparam logic [%d:0] MER_MST_MAXO = %s;' % (NM * 8 - 1, concat([mm['maxo'] for mm in masters], 8)))
    nd = 1 << m['DOMW']
    A('  localparam logic [%d:0] MER_MST_DOM_ALLOW = %s;' % (NM * nd - 1, concat([1 << mm['dom'] for mm in masters], nd)))
    A('  localparam logic [%d:0] MER_CONN = %d\'b%s;' % (NM * NT - 1, NM * NT, '1' * (NM * NT)))
    A('  // ---- masters: hardware-bound domain, privilege and QoS stamped by the initiator adapters')
    for mm in masters:
        n = mm['name'].upper()
        A('  localparam logic [7:0] DOM_%s  = 8\'d%d;' % (n, mm['dom']))
        A('  localparam logic [7:0] ATTR_%s = 8\'h%02X;   // qos=%d priv=%d mem_type=device(2)' % (
            n, (mm['qos'] << 5) | (int(mm['priv']) << 2) | 2, mm['qos'], int(mm['priv'])))
    A('  // ---- regions of this SoC (ALP addresses)')
    for t in targets:
        n = t['region'].upper()
        A('  localparam logic [63:0] REG_%s_BASE = %s;' % (n, sv_hex(t['base'], 64)))
        A('  localparam logic [63:0] REG_%s_SIZE = %s;' % (n, sv_hex(t['size'], 64)))
        A('  localparam logic [63:0] REG_%s_MASK = %s;' % (n, sv_hex(t['mask'], 64)))
        A('  localparam int unsigned TGT_%s = %d;' % (t['name'].upper(), t['index']))
    A('  // ---- Citadel boot policy (default-deny table loaded by hardware after reset)')
    P = len(pol)
    A('  localparam int unsigned POL_N = %d;' % P)
    A('  localparam logic [%d:0] POL_SRC  = %s;' % (P * NM - 1, concat([p['src'] for p in pol], NM)))
    A('  localparam logic [%d:0] POL_DOM  = %s;' % (P * nd - 1, concat([p['dom'] for p in pol], nd)))
    A('  localparam logic [%d:0] POL_PRIV = %s;' % (P - 1, concat([p['priv'] for p in pol], 1)))
    A('  localparam logic [%d:0] POL_BASE = %s;' % (P * 64 - 1, concat([p['base'] for p in pol], 64)))
    A('  localparam logic [%d:0] POL_MASK = %s;' % (P * 64 - 1, concat([p['mask'] for p in pol], 64)))
    A('  localparam logic [%d:0] POL_RD   = %s;' % (P - 1, concat([p['rd'] for p in pol], 1)))
    A('  localparam logic [%d:0] POL_WR   = %s;' % (P - 1, concat([p['wr'] for p in pol], 1)))
    for i, p in enumerate(pol):
        A('  // entry %d: %s' % (i, p['desc']))
    A('  // ---- ControlCore external window -> ALP translation')
    W = len(ccw)
    A('  localparam int unsigned CCW_N = %d;' % W)
    A('  localparam logic [%d:0] CCW_SRC_BASE = %s;' % (W * 32 - 1, concat([w['cc_base'] for w in ccw], 32)))
    A('  localparam logic [%d:0] CCW_SRC_MASK = %s;' % (W * 32 - 1, concat([w['mask'] for w in ccw], 32)))
    A('  localparam logic [%d:0] CCW_DST_BASE = %s;' % (W * 64 - 1, concat([w['alp_base'] for w in ccw], 64)))
    A('  // ---- IronMemory')
    for k in ('banks', 'depth', 'ports', 'backend', 'ecc', 'rl', 'ext_en', 'gran_bytes', 'num_desc', 'max_out'):
        A('  localparam int unsigned IRON_%-10s = %d;' % (k.upper(), iron[k]))
    A('  localparam int unsigned IRON_AW = 40;')
    A('  localparam logic [39:0] IRON_SRAM_BASE = %s;' % sv_hex(next(t for t in targets if t['region'] == 'sram')['base'], 40))
    A('  // ---- CloudDMA (BridgeEngine)')
    for k in ('dw', 'aw', 'dom_w', 'max_burst_beats', 'rd_out', 'wr_out', 'buf_bytes', 'bind_dom'):
        A('  localparam int unsigned DMA_%-16s = %d;' % (k.upper(), dma[k]))
    A('  // ---- register offsets of the MMIO shims (inside the region window)')
    for blk, lst in REGS.items():
        for name, off, acc, desc in lst:
            A('  localparam logic [11:0] R_%s_%-16s = 12\'h%03X;   // %s' % (blk, name, off, acc))
    A('  // Iron CSR passthrough window / shim split: offsets with bit 11 clear go to the IP CSR port')
    A('endpackage')
    A('/* verilator lint_on UNUSEDPARAM */')
    A('')
    A('`default_nettype wire')
    return '\n'.join(L) + '\n'


def emit_c(cfg, used, targets, masters, pol, ccw):
    L = []
    A = L.append
    A('/* GENERATED by tools/gen_soc.py from config/albion_soc.yaml -- do not edit. */')
    A('#ifndef ALBION_SOC_MAP_H')
    A('#define ALBION_SOC_MAP_H')
    A('')
    A('/* ControlCore external-window address of every Albion region (what firmware dereferences) and the ALP address it maps to. */')
    for w in ccw:
        n = w['region'].upper()
        A('#define ALB_%s_BASE        0x%08Xu   /* ControlCore address */' % (n, w['cc_base']))
        A('#define ALB_%s_SIZE        0x%Xu' % (n, w['size']))
        A('#define ALB_%s_ALP_BASE    0x%016XULL   /* ALP device address */' % (n, w['alp_base']))
    A('')
    A('#define ALB_NM %d' % cfg['meridian']['NM'])
    A('#define ALB_NT %d' % cfg['meridian']['NT'])
    A('#define ALB_POLICY_ENTRIES %d' % cfg['meridian']['CIT_NENT'])
    A('#define ALB_BOOT_POLICY_ENTRIES %d' % len(pol))
    A('#define ALB_DOM_CC  %d' % next(m for m in masters if m['name'] == 'cc')['dom'])
    A('#define ALB_DOM_DMA %d' % next(m for m in masters if m['name'] == 'dma')['dom'])
    A('')
    blk_base = {'SOC': 'PERF', 'IRON': 'SRAM_CTL', 'DMA': 'DMA'}
    for blk, lst in REGS.items():
        A('/* ---- %s register block at ALB_%s_BASE (%s) */' % (blk, blk_base[blk], PORT_REGION_OF_BLOCK[blk]))
        for name, off, acc, desc in lst:
            A('#define ALB_%s_%-16s 0x%03Xu   /* %s: %s */' % (blk, name, off, acc, desc.replace('*/', '* /')))
        A('')
    A('#endif')
    return '\n'.join(L) + '\n'


def emit_md(cfg, used, targets, masters, pol, ccw):
    L = []
    A = L.append
    A('# SoC memory map (albion_min) -- GENERATED by tools/gen_soc.py, do not edit\n')
    A('The map is validated with AlbionCore\'s `gen_memmap.check_regions` (overlap, alignment, reserved legacy window).\n')
    A('| Region | Meridian target | ALP base | size | ControlCore address | attr |')
    A('|---|---|---|---|---|---|')
    for t in targets:
        w = next(w for w in ccw if w['region'] == t['region'])
        A('| `%s` | %d (`%s`) | `0x%016X` | 0x%X | `0x%08X` | `0x%02X` |' % (t['region'], t['index'], t['name'], t['base'], t['size'], w['cc_base'], t['attr']))
    A('\n## Masters\n')
    A('| port | name | domain (bound by hardware) | priv | qos | max outstanding |')
    A('|---|---|---|---|---|---|')
    for m in masters:
        A('| %d | %s | %d | %s | %d | %d |' % (m['index'], m['name'], m['dom'], m['priv'], m['qos'], m['maxo']))
    A('\n## Citadel boot policy (default deny; loaded by hardware after reset)\n')
    A('| # | grant | src mask | dom mask | priv | rd | wr |')
    A('|---|---|---|---|---|---|---|')
    for i, p in enumerate(pol):
        A('| %d | %s | 0x%X | 0x%X | %d | %d | %d |' % (i, p['desc'], p['src'], p['dom'], p['priv'], p['rd'], p['wr']))
    for blk, lst in REGS.items():
        A('\n## Register block `%s` (region `%s`)\n' % (blk, PORT_REGION_OF_BLOCK[blk]))
        A('| offset | name | access | description |')
        A('|---|---|---|---|')
        for name, off, acc, desc in lst:
            A('| 0x%03X | %s | %s | %s |' % (off, name, acc, desc))
    A('\nOffsets 0x000..0x7FF of `sram_ctl` and `dma` pass through to the IronMemory CSR port and the CloudDMA CSR port '
      '(see the IP documentation: `ip/ironmemory/docs/iron_memory/csr_map.md`, `ip/clouddma/docs/04_INTEGRATION.md` section 5).')
    return '\n'.join(L) + '\n'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', action='store_true', help='fail if the generated files are stale')
    ap.add_argument('--config', help='alternative SoC configuration (used by the negative tests; nothing is written with --validate-only)')
    ap.add_argument('--validate-only', action='store_true', help='validate the configuration and exit (non-zero if the map is illegal)')
    a = ap.parse_args()
    cfg, used, targets, masters, pol, ccw = build_model(a.config)
    if a.validate_only:
        print('map is legal: %d regions, %d boot-policy entries' % (len(used), len(pol)))
        return
    outs = {
        'rtl/soc/gen/sf_asoc_cfg_pkg.sv': emit_sv(cfg, used, targets, masters, pol, ccw),
        'fw/include/albion_soc_map.h': emit_c(cfg, used, targets, masters, pol, ccw),
        'docs/MEMORY_MAP_SOC.md': emit_md(cfg, used, targets, masters, pol, ccw),
        'reports/memory_map_soc.json': json.dumps(dict(
            regions=[dict(name=t['region'], target=t['index'], base='0x%016X' % t['base'], size=t['size'], attr=t['attr']) for t in targets],
            cc_windows=[dict(region=w['region'], cc_base='0x%08X' % w['cc_base'], size=w['size']) for w in ccw],
            boot_policy=[dict(desc=p['desc'], src=p['src'], dom=p['dom'], priv=p['priv'], rd=p['rd'], wr=p['wr']) for p in pol],
            registers={b: [dict(name=n, offset='0x%03X' % o, access=ac) for n, o, ac, d in l] for b, l in REGS.items()}), indent=1) + '\n',
    }
    stale = 0
    for rel, text in outs.items():
        path = os.path.join(ROOT, rel)
        if a.check:
            cur = open(path).read() if os.path.exists(path) else None
            if cur != text:
                print('STALE', rel); stale += 1
        else:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            open(path, 'w').write(text)
            print('wrote', rel)
    if a.check:
        print('gen_soc --check: %d stale file(s)' % stale)
        sys.exit(1 if stale else 0)


if __name__ == '__main__':
    main()
