#!/usr/bin/env python3
"""albion-dist: deterministic zip of the project (sorted entries, fixed timestamps).  Excludes build/ and caches; includes the generated reports,
the audit outputs and `results/` (copies of the JSON results and the firmware image the reports were produced from)."""
import os, shutil, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

EXCLUDE_DIRS = {'__pycache__', '.git', 'audit_work', '.pytest_cache'}
EXCLUDE_TOP = {'build'}                       # only the project's own build/ (IP trees contain directories called build)
NAME = 'albionforge-0.1.0'


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, NAME + '.zip')
    # results/: what the reports were generated from (so the claims can be checked without re-running anything)
    res = os.path.join(ROOT, 'results')
    shutil.rmtree(res, ignore_errors=True)
    os.makedirs(res + '/run')
    for f in ('tool_versions', 'lint', 'unit', 'firmware', 'sim', 'synth', 'mutation', 'fpga_sim', 'pytest'):
        for ext in ('json', 'xml'):
            p = os.path.join(REPORTS, f + '.' + ext)
            if os.path.exists(p):
                shutil.copy(p, res)
    for p in sorted(os.listdir(os.path.join(BUILD, 'run'))) if os.path.isdir(os.path.join(BUILD, 'run')) else []:
        if p.endswith('.json') or p.endswith('.log.console'):   # result + the firmware console transcript of each run
            shutil.copy(os.path.join(BUILD, 'run', p), res + '/run')
    fwd = os.path.join(BUILD, 'fw')
    if os.path.isdir(fwd):
        os.makedirs(res + '/firmware', exist_ok=True)
        for p in ('albion_fw.hex', 'albion_fw.img', 'albion_fw.dis', 'albion_fw.map', 'albion_fw.json'):
            if os.path.exists(os.path.join(fwd, p)):
                shutil.copy(os.path.join(fwd, p), res + '/firmware')
    for sd in ('synth', 'synth_fpga'):
        d = os.path.join(BUILD, sd)
        if os.path.isdir(d):
            os.makedirs(res + '/' + sd, exist_ok=True)
            for p in os.listdir(d):
                if p.endswith(('_stat.txt', '.json', 'ltp.txt')) and not p.endswith('soc_ecp5.json') and not p.endswith('coarse_flat.json'):
                    shutil.copy(os.path.join(d, p), res + '/' + sd)
    files = []
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = sorted(d for d in dns if d not in EXCLUDE_DIRS and not (dp == ROOT and d in EXCLUDE_TOP))
        for fn in sorted(fns):
            p = os.path.join(dp, fn)
            if fn.endswith('.zip') or fn.endswith('.pyc'):
                continue
            files.append(p)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(files):
            rel = os.path.join(NAME, os.path.relpath(p, ROOT))
            zi = zipfile.ZipInfo(rel, date_time=(2026, 11, 16, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = (0o755 if os.access(p, os.X_OK) else 0o644) << 16
            z.writestr(zi, open(p, 'rb').read())
    print('wrote %s: %d files, %.1f MB' % (out, len(files), os.path.getsize(out) / 1e6))


if __name__ == '__main__':
    main()
