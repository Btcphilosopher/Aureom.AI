#!/usr/bin/env python3
"""albion-mutate (optional, ~5 min): mutation check of the NEW glue.  Each mutant is one deliberate RTL defect; the unit test (or, for the
system-level mutants, the full SoC simulation with the real firmware) of that module MUST fail.  A surviving mutant is a hole in the tests.
Result: build/reports/mutation.json."""
import concurrent.futures as cf, json, os, re, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import run_unit

U = {t['name']: t for t in run_unit.TESTS}
# (id, file, old, new, test, description)
MUTANTS = [
    ('regtgt-lane-from-address', 'rtl/soc/sf_asoc_regtgt.sv', "    for (int l = 3; l >= 0; l--) if (s_req_be_i[l*4 +: 4] != 4'h0) begin lane = 2'(l); nib = s_req_be_i[l*4 +: 4]; end", "    lane = s_req_addr_i[3:2]; nib = s_req_be_i[lane*4 +: 4];", 'regtgt', 'the original lane bug (IP-11): lane taken from the address'),
    ('regtgt-no-align-check', 'rtl/soc/sf_asoc_regtgt.sv', "al_ok    = (s_req_addr_i[3:0] == 4'b0000);", "al_ok    = 1'b1;", 'regtgt', 'misaligned requests accepted'),
    ('regtgt-multi-lane-ok', 'rtl/soc/sf_asoc_regtgt.sv', "    one_lane = (nib == 4'hF) && ((s_req_be_i & ~(16'hF << (lane * 4))) == 16'h0000);", "    one_lane = (nib == 4'hF);", 'regtgt', 'several enabled lanes accepted'),
    ('regtgt-error-ignored', 'rtl/soc/sf_asoc_regtgt.sv', "st_q    <= rb_err_i ? ST_TGT : ST_OK;", "st_q    <= ST_OK;", 'regtgt', 'register-bus error not reported'),
    ('axi-decerr-lost', 'rtl/soc/sf_asoc_axi_init.sv', "    else if (rsp_dec) rd_resp = 2'b11;\n", "", 'axi_init', 'DECODE_ERR reported as SLVERR on reads'),
    ('axi-strobes-ignored', 'rtl/soc/sf_asoc_axi_init.sv', "assign m_req_be_o    = pick_wr ? w_strb_i : 16'hFFFF;", "assign m_req_be_o    = 16'hFFFF;", 'axi_init', 'write strobes dropped'),
    ('axi-domain-check-off', 'rtl/soc/sf_asoc_axi_init.sv', "assign ar_bad_in = (ar_domain_i != EXPECT_DOM) ||", "assign ar_bad_in = 1'b0 ||", 'axi_init', 'AXI domain sideband (independent second check) not enforced on reads'),
    ('axi-burst-off-by-one', 'rtl/soc/sf_asoc_axi_init.sv', "assign rd_last = (ar_beat_q[7:0] == ar_len);", "assign rd_last = (ar_beat_q[7:0] == ar_len + 8'd1);", 'axi_init', 'one beat too many per read burst'),
    ('axi-write-error-class', 'rtl/soc/sf_asoc_axi_init.sv', "assign wb_resp  = !any_err ? 2'b00 : (all_dec ? 2'b11 : 2'b10);", "assign wb_resp  = !any_err ? 2'b00 : 2'b10;", 'axi_init', 'the first defect found by the independent model: DECERR lost on write bursts'),
    ('sfb2-strobes-ignored', 'rtl/soc/sf_asoc_sfb2_init.sv', "assign n_req_be    = wr_q ? wstrb_q : 4'hF;", "assign n_req_be    = 4'hF;", 'sfb2_init', 'byte stores become word stores'),
    ('sfb2-window-miss-forwarded', 'rtl/soc/sf_asoc_sfb2_init.sv', "            if (!hit)                                      state_q <= S_LOCAL;", "            if (1'b0)                                      state_q <= S_LOCAL;", 'sfb2_init', 'window miss not answered locally'),
    ('iron-perm-status', 'rtl/soc/sf_asoc_iron_port.sv', "      3'd3:    mst = 4'h2;   // PERM    -> ACCESS_DENIED", "      3'd3:    mst = 4'h7;", 'iron_alp', 'ownership refusal reported as TARGET_ERR'),
    ('iron-strobes-full', 'rtl/soc/sf_asoc_iron_port.sv', "assign i_req_wstrb_o = s_req_be_i;", "assign i_req_wstrb_o = 8'hFF;", 'iron_alp', 'partial writes overwrite the whole word'),
]
SYSTEM = [  # mutants caught by the full system simulation (build ~20 s + run ~15 s)
    ('sys-dma-domain-from-register', 'rtl/soc/sf_asoc_dma_ctl.sv', "assign cmd_domain_o = BIND_DOM;                  // hardware binding, not a register", "assign cmd_domain_o = asid_q;", 'software-writable command domain (the isolation hole CloudDMA warns about)'),
    ('sys-bm-requester-wired', 'rtl/soc/sf_asoc_iron_ctl.sv', "req_q   <= rb_dom_i[2:0];           // hardware-sourced requester domain", "req_q   <= 3'd1;", 'buffer-manager requester not taken from the verified access domain'),
]


def run_unit_mutant(m):
    mid, f, old, new, tname, desc = m
    src = open(os.path.join(ROOT, f)).read()
    if old not in src:
        return dict(id=mid, desc=desc, killed=None, note='pattern not found: mutant stale')
    d = os.path.join(BUILD, 'mutants', mid)
    os.makedirs(d, exist_ok=True)
    mp = os.path.join('build', 'mutants', mid, os.path.basename(f))
    open(os.path.join(ROOT, mp), 'w').write(src.replace(old, new, 1))
    t = dict(U[tname])
    t['srcs'] = [mp if s == f else s for s in t['srcs']]
    t['name'] = 'mut_' + mid
    r = run_unit.run_one(t, t['seeds'][0])
    return dict(id=mid, desc=desc, test=tname, killed=not r['pass_'], seconds=r['seconds'])


def run_system_mutant(m):
    mid, f, old, new, desc = m
    src = open(os.path.join(ROOT, f)).read()
    if old not in src:
        return dict(id=mid, desc=desc, killed=None, note='pattern not found: mutant stale')
    d = os.path.join(BUILD, 'mutants', mid)
    os.makedirs(d, exist_ok=True)
    mp = os.path.join('build', 'mutants', mid, os.path.basename(f))
    open(os.path.join(ROOT, mp), 'w').write(src.replace(old, new, 1))
    fl = [l.strip() for l in open(os.path.join(ROOT, 'build/filelists/soc.f'))]
    fl = [mp if l == f else l for l in fl]
    flp = os.path.join(d, 'soc.f')
    open(flp, 'w').write('\n'.join(fl) + '\n')
    mdir = 'build/mutants/%s/sim' % mid
    rc, dt, out = sh('verilator --binary --timing -O1 -j 2 -Wno-fatal -Wno-lint -Wno-style --timescale 1ns/1ps lint/albion.vlt --top-module tb_albion_soc -Mdir %s -o vtb -f %s '
                     'tb/alp_scoreboard.sv tb/tb_albion_soc.sv' % (mdir, os.path.relpath(flp, ROOT)))
    if rc:
        return dict(id=mid, desc=desc, killed=None, note='mutant does not build')
    rc, dt2, out = sh('%s/vtb +scenario=normal +fw=build/fw/albion_fw.hex +timeout=3000000' % mdir)
    ok = rc == 0 and 'TB RESULT PASS' in out
    return dict(id=mid, desc=desc, test='system simulation', killed=not ok, seconds=round(dt + dt2, 1))


def main():
    filelist()
    res = []
    with cf.ThreadPoolExecutor(max_workers=int(os.environ.get('JOBS', '4'))) as ex:
        futs = [ex.submit(run_unit_mutant, m) for m in MUTANTS] + [ex.submit(run_system_mutant, m) for m in SYSTEM]
        for f in futs:
            res.append(f.result())
    for r in res:
        print('%-30s %-8s %s' % (r['id'], {True: 'KILLED', False: 'SURVIVED', None: 'n/a'}[r['killed']], r['desc']))
    killed = sum(1 for r in res if r['killed'])
    survived = [r['id'] for r in res if r['killed'] is False]
    write_json('mutation.json', dict(total=len(res), killed=killed, survived=survived, mutants=res, ok=not survived and all(r['killed'] is not None for r in res)))
    print('mutation: %d/%d killed; survivors: %s' % (killed, len(res), survived or 'none'))
    sys.exit(0 if not survived else 1)


if __name__ == '__main__':
    main()
