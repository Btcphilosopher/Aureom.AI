#!/usr/bin/env python3
"""AlbionForge: vendor the existing SilicaFlux IP out of the Aureom.AI repository archives.

The IP lives inside zip archives of the repository.  This tool copies exactly the members the
minimum Albion SoC needs into ip/<name>/ (preserving relative paths), records the SHA-256 of every
member as read from the archive (PRISTINE), applies the patch series in patches/<name>/*.patch
(every fix to existing IP is an explicit, reviewable diff -- nothing is edited in place) and records
the hash of every file after patching.

  vendor.py --repo <Aureom.AI checkout> --dest ip [--patches patches]   fetch + patch + write ip/PROVENANCE.json
  vendor.py --verify --dest ip                                          check the tree against PROVENANCE.json

Nothing extracted is executed.  Zip member paths are normalised and refused if they escape the destination.
"""
import argparse, fnmatch, hashlib, json, os, subprocess, sys, zipfile

SF = 'SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/'
IPS = {
    'albioncore': dict(
        zip=SF + 'albioncore-0.1.0.zip', prefix='albioncore-0.1.0/',
        include=['rtl/albion/*', 'include/albion/*', 'tools/albion/*', 'tests/albion/common/*', 'tests/albion/unit/*',
                 'tests/albion/system/*', 'tests/albion/formal/*', 'tests/albion/cdc/*', 'tests/albion/tools/*', 'tests/albion/fixtures/*',
                 'tests/__init__.py', 'tests/albion/__init__.py', 'docs/albion/*.md', 'Makefile', 'README.md'],
        exclude=[]),
    'meridian': dict(
        zip=SF + 'silicaflux-meridian-p83.zip', prefix='silicaflux-meridian-p83/',
        include=['rtl/*', 'third_party/p22/sfn_pkg.sv', 'third_party/p22/sfn_fifo.sv', 'third_party/p22/SHA256SUMS',
                 'docs/meridian/*.md', 'tests/meridian/*', 'scripts/*', 'README.md', 'Makefile'],
        exclude=[]),
    'ironmemory': dict(
        zip=SF + 'silicaflux-p84-ironmemory.zip', prefix='silicaflux-ironmemory/',
        include=['rtl/*', 'tests/*', 'docs/iron_memory/*.md', 'syn/*', 'tools/*', 'README.md'],
        exclude=[]),
    'clouddma': dict(
        zip=SF + 'silicaflux-clouddma-p64.zip', prefix='',   # prefix is detected below
        include=['rtl/*', 'third_party/*', 'tb/*', 'scripts/*', 'docs/*.md', 'README.md', 'Makefile', 'MANIFEST.sha256'],
        exclude=['reports/*']),
    'controlcore': dict(
        zip=SF + 'silicaflux-controlcore.zip', prefix='silicaflux-controlcore/',
        include=['rtl/*', 'config/*', 'firmware/common/*', 'firmware/bootrom/*', 'firmware/include/*', 'firmware/Makefile',
                 'firmware/app/platform.c', 'firmware/app/fw.h', 'firmware/app/libc_min.c',
                 'scripts/gen_memmap.py', 'scripts/mkimage.py', 'scripts/generated/*',
                 'docs/HW_SW_INTERFACE.md', 'docs/MEMORY_MAP.md', 'docs/03_BOOT.md', 'docs/02_CPU.md', 'docs/09_LIMITATIONS.md',
                 'third_party/PROVENANCE.md', 'third_party/SHA256SUMS',
                 'third_party/silicaflux-mcu-i/rtl/*', 'third_party/silicaflux-mcu-i/docs/*.md',
                 'third_party/silicaflux-v/rtl/*', 'third_party/silicaflux-v/scripts/*',
                 'third_party/silicaflux-datafabric/rtl/interconnect/*',
                 'third_party/silicaflux-sramlib/rtl/mem/*', 'README.md'],
        exclude=['firmware/build/*']),
}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def detect_prefix(names):
    tops = {n.split('/')[0] for n in names if '/' in n}
    return (sorted(tops)[0] + '/') if len(tops) == 1 else ''


def fetch(repo, dest):
    prov = {}
    for name, spec in IPS.items():
        zpath = os.path.join(repo, spec['zip'])
        with open(zpath, 'rb') as f:
            zbytes = f.read()
        zf = zipfile.ZipFile(zpath)
        prefix = spec['prefix'] or detect_prefix(zf.namelist())
        entry = {'archive': spec['zip'], 'archive_sha256': sha(zbytes), 'prefix': prefix, 'files': {}}
        for info in zf.infolist():
            if info.is_dir() or not info.filename.startswith(prefix):
                continue
            rel = info.filename[len(prefix):]
            if not any(fnmatch.fnmatch(rel, p) for p in spec['include']):
                continue
            if any(fnmatch.fnmatch(rel, p) for p in spec['exclude']):
                continue
            norm = os.path.normpath(rel)
            if norm.startswith('..') or os.path.isabs(norm):
                raise SystemExit('refusing path %s' % rel)
            data = zf.read(info)
            out = os.path.join(dest, name, norm)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with open(out, 'wb') as f:
                f.write(data)
            entry['files'][norm] = {'pristine_sha256': sha(data), 'bytes': len(data)}
        prov[name] = entry
        print('%-12s %4d files  <- %s' % (name, len(entry['files']), spec['zip']))
    return prov


def apply_patches(dest, patch_dir, prov):
    series = []
    for name in IPS:
        d = os.path.join(patch_dir, name)
        if not os.path.isdir(d):
            continue
        for p in sorted(os.listdir(d)):
            if p.endswith('.patch'):
                series.append((name, os.path.join(d, p)))
    for name, p in series:
        r = subprocess.run(['patch', '-p1', '--no-backup-if-mismatch', '-d', os.path.join(dest, name), '-i', os.path.abspath(p)],
                           capture_output=True, text=True)
        print('patch %-12s %-60s rc=%d' % (name, os.path.basename(p), r.returncode))
        if r.returncode != 0:
            print(r.stdout + r.stderr)
            raise SystemExit(1)
        prov[name].setdefault('patches', []).append(os.path.basename(p))


def finalize(dest, prov):
    for name, entry in prov.items():
        patched = []
        for rel, f in entry['files'].items():
            path = os.path.join(dest, name, rel)
            h = sha(open(path, 'rb').read())
            f['sha256'] = h
            if h != f['pristine_sha256']:
                patched.append(rel)
        entry['patched_files'] = sorted(patched)
    with open(os.path.join(dest, 'PROVENANCE.json'), 'w') as f:
        json.dump(prov, f, indent=1, sort_keys=True)


def new_files(dest, prov):
    """Files added by patches (not in the archive) are recorded too."""
    for name, entry in prov.items():
        base = os.path.join(dest, name)
        for root, _, files in os.walk(base):
            for fn in files:
                rel = os.path.relpath(os.path.join(root, fn), base)
                if rel not in entry['files']:
                    data = open(os.path.join(root, fn), 'rb').read()
                    entry['files'][rel] = {'pristine_sha256': None, 'bytes': len(data), 'added_by_patch': True}


def verify(dest):
    prov = json.load(open(os.path.join(dest, 'PROVENANCE.json')))
    bad = 0
    for name, entry in prov.items():
        for rel, f in entry['files'].items():
            path = os.path.join(dest, name, rel)
            if not os.path.exists(path):
                print('MISSING', name, rel); bad += 1; continue
            if sha(open(path, 'rb').read()) != f['sha256']:
                print('MODIFIED outside the patch series:', name, rel); bad += 1
    print('verify: %d problem(s); %d files recorded; patched files: %s' % (
        bad, sum(len(e['files']) for e in prov.values()),
        {n: len(e['patched_files']) for n, e in prov.items()}))
    return 1 if bad else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo')
    ap.add_argument('--dest', default='ip')
    ap.add_argument('--patches', default='patches')
    ap.add_argument('--verify', action='store_true')
    a = ap.parse_args()
    if a.verify:
        sys.exit(verify(a.dest))
    if not a.repo:
        ap.error('--repo is required')
    prov = fetch(a.repo, a.dest)
    apply_patches(a.dest, a.patches, prov)
    new_files(a.dest, prov)
    finalize(a.dest, prov)
    print('wrote', os.path.join(a.dest, 'PROVENANCE.json'))


if __name__ == '__main__':
    main()
