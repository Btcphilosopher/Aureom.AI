#!/usr/bin/env python3
"""albion-report: collect every result of the other targets into
     reports/albion_report.json      machine-readable (all results, performance, synthesis, limitations, next actions, definition of done)
     reports/ENGINEERING_REPORT.md   the human-readable engineering report
     reports/TEST_SUMMARY.md         pass / fail table of every test run
     reports/BUILD_MANIFEST.json     sources, artefacts (SHA-256), tool versions, IP provenance
     reports/KNOWN_LIMITATIONS.md    what is NOT claimed
     reports/NEXT_ACTIONS.md         the next engineering steps, in order
Nothing here is computed from documentation: every number comes from a result file written by a tool in this repository."""
import glob, hashlib, json, os, re, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

OUT = os.path.join(ROOT, 'reports')


def load(name, default=None):
    p = os.path.join(REPORTS, name)
    if os.path.exists(p):
        return json.load(open(p))
    return default


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def parse_perf(lines):
    d = {}
    for l in lines or []:
        for k, v in re.findall(r'(\w+)=(\d+)', l):
            d[k] = int(v)
    return d


def sweep(lines):
    rows = []
    for l in lines or []:
        m = re.search(r'dmasz len=(\d+) latency=(\d+) fabric_cycles=(\d+)', l)
        if m:
            n, lat = int(m.group(1)), int(m.group(2))
            rows.append(dict(bytes=n, latency_cycles=lat, copy_bytes_per_cycle=round(n / lat, 3), link_bytes_per_cycle=round(2 * n / lat, 3)))
    return rows


LIMITS = [
    ('L-01', 'Simulation and generic synthesis only', 'Nothing has run on a board. No place-and-route, timing closure, power or silicon result exists. The synthesis figures are Yosys technology-mapping estimates (a generic ECP5 LUT4 library as a stand-in for "an FPGA"); the longest-path figure is a topological LUT depth, not a frequency.'),
    ('L-02', 'Simulated cycle counts are not bandwidth', 'Bytes per cycle are measured in RTL simulation cycles. They say nothing about FPGA or silicon bandwidth: that needs a clock the implementation actually reaches and a memory that behaves like the model.'),
    ('L-03', 'The Citadel is a reference model', 'The repository contains no Citadel. Meridian\'s sf_meridian_citadel_ref (a default-deny table) enforces the policy; a hardware boot loader writes the generated boot policy after reset and the ControlCore firmware may rewrite it. This is configuration, not a security product.'),
    ('L-04', "DMA isolation uses CloudDMA's simulation permission table", 'There is no IOMMU in the repository. The permission table is a verified MODEL of isolation; real isolation also needs the platform properties listed in CloudDMA docs/03_PROTECTION.md (single memory path, hardware-bound domains: both hold in this SoC by construction, but are not formally proven).'),
    ('L-05', 'No interrupts from the DMA / memory to the CPU', 'Firmware polls. IronMemory and CloudDMA interrupt lines feed only the RAS "SoC warning" input. Accelerator pages 8..15 of the ControlCore answer a bus error.'),
    ('L-06', 'Meridian drops ALP attribute bits', 'secure, instr and mem_type do not cross the fabric (only priv and a 2-bit QoS class do). Region access rules are therefore enforced by the Citadel table (domain / source / privilege / read / write), not by sf_access_check_bits.'),
    ('L-07', 'Status detail narrows across the fabric', 'Meridian targets may answer only OKAY or SLVERR: an IronMemory ownership refusal (ALP ACCESS_DENIED) or ECC error reaches the initiator as TARGET_ERR. Fabric-generated statuses (DENIED, DECODE_ERR, TIMEOUT, PROTOCOL_ERR) are preserved. IronMemory\'s CSRs / counters still say what happened.'),
    ('L-08', 'Throughput is limited by the 128 -> 64-bit adaptation', 'IronMemory is verified at 64 bit only; the AlbionCore downsizing adapter handles ONE wide transaction at a time per port, so a 16-byte word costs two memory beats plus handshake: about 1 byte per cycle of copy bandwidth (2 bytes per cycle on the link). CloudDMA alone sustains 8 B/cycle at 64-bit width. Raising it means verifying IronMemory at 128 bit or pipelining the adapter (next action NA-03).'),
    ('L-09', 'Formal verification and mutation of the vendored IP were not re-run', 'SymbiYosys is not installable here; AlbionCore\'s ABC-PDR proofs and the IP projects\' own mutation campaigns were not repeated. The NEW glue has simulation evidence (cocotb unit tests against independent models, system scoreboard) and a 15-mutant check (reports/mutation.json), but no proof.'),
    ('L-10', 'Single clock, no CDC, clock gating unused', 'ControlCore\'s gated accelerator clock is ignored; the fabric domain is the ControlCore-derived reset domain only. A multi-clock SoC needs the AlbionCore CDC primitives and a CDC review.'),
    ('L-11', 'Small configuration', '64 KiB shared SRAM (4 banks x 2048 x 64 bit + ECC), one DMA channel, two Meridian masters, four targets, 8 Citadel entries (5 used). Larger configurations are parameters but only this one was verified.'),
    ('L-12', 'Firmware is integrity-checked, not authenticated', 'CRC-32 only (ControlCore limitation, documented by that project); the hardware image loader inherits this. Do not treat the boot path as secure boot.'),
    ('L-13', 'Device-memory boot and the ControlCore accelerators are unsupported', 'boot_mode 1 needs a 1 MiB device window at 0x200F_0000; this SoC has a 64 KiB SRAM. Boot is host-load (testbench or sf_asoc_host_loader).'),
    ('L-14', 'The FPGA wrapper has never met a board', 'Board-neutral by construction (one clock, one reset, a UART pin, LEDs) and verified in simulation (it boots the real firmware by itself); pin assignments, clocking, block-RAM mapping of the SRAMs and timing are the board project\'s job (docs/FPGA.md).'),
    ('L-15', 'Test coverage is directed + constrained-random, not exhaustive', 'Scenario matrix: 4 back-pressure levels, 5 reset instants, 1 firmware. Two initiators only; no multi-channel DMA, no ECC fault injection through the SoC (IronMemory\'s own tests cover ECC), no error injection on the AXI side beyond the refusal paths.'),
    ('L-16', 'CloudDMA\'s data buffer is a flop array', 'sfdma_bytebuf (1 KiB per channel) has a combinational read of sixteen byte lanes and sixteen write ports, so it is built from flip-flops and wide multiplexers, not block RAM. In the reference synthesis it is 75 % of all mapped cells (section 6, largest modules) and the reason a generic FPGA mapping of the SoC is about a million cells and does not fit a small device. Functionally correct (verified); not area-efficient.'),
]

NEXT = [
    ('NA-01', 'Place-and-route the wrapper for one real FPGA and read the real critical path', 'Pick a board with enough block RAM for 64 KiB + ECC + the ControlCore SRAMs, constrain the clock, close timing, then run the wrapper on the board. Until then no frequency or resource claim is possible.'),
    ('NA-02', 'Replace the reference Citadel and the DMA permission table with real IP', 'Write (or locate) a Citadel that implements the check port of Meridian docs/meridian/03_ACCESS_CONTROL.md, and an IOMMU for CloudDMA\'s iommu_* interface; re-run the refusal tests (firmware t_dma_perm / t_policy) unchanged.'),
    ('NA-03', 'Lift the ~1 byte/cycle copy ceiling', 'Verify IronMemory at DW = 128 (the IP states support, its tests run at 64 only) and drop the downsizing adapter, or give the adapter MAX_OUT > 1 pipelining; re-measure with the same sweep (firmware t_dma_sweep, link scoreboard).'),
    ('NA-04', 'Interrupts', 'Route CloudDMA done/error and IronMemory UE/violation lines to ControlCore interrupt sources (the vector / tensor lines are free in this SoC) and replace the polling; extend the firmware with handlers and the testbench with an interrupt-latency measurement.'),
    ('NA-05', 'Carry ALP attributes and status through Meridian', 'Add a user sideband (attr: secure / instr / mem_type) and a wider target status to Meridian (RTL + its regression + mutants), then enforce sf_access_check_bits at the targets as AlbionCore intends.'),
    ('NA-06', 'Formal and mutation evidence for the glue', 'Install SymbiYosys (or run Yosys smtbmc directly) and prove the ALP handshake rules of the five bridges (valid held, in-order, no loss) with unbounded proofs where the state space allows; grow tools/mutate.py to cover sf_asoc_mer_tgt / mer_core / soc_ctl / dma_ctl registers with dedicated unit benches.'),
    ('NA-07', 'Second DMA channel and a larger SRAM', 'Exercise NUM_CH = 2 (CloudDMA is verified up to 8) through Meridian master 2 with its own domain, and scale the IronMemory banks; re-run the scoreboard under contention and the arbitration-fairness checks of Meridian.'),
    ('NA-08', 'Accelerator integration', 'Connect the ControlCore accelerator pages 8..15 (HPC tile / tensor unit from the repository) as additional Meridian targets and masters using the same ALP adapters, keeping the firmware self-test as the regression.'),
    ('NA-09', 'Upstream the IP fixes', 'The Meridian (patches 0001/0002) and IronMemory (0001) fixes belong in their projects: apply them there, re-run those projects\' own regressions and mutation campaigns, and drop the patch series here.'),
    ('NA-10', 'Licence and provenance', 'The repository has no licence file; ip/PROVENANCE.json records the source archive and SHA-256 of every vendored file. Decide the licence before publishing the project.'),
    ('NA-11', 'Re-architect the DMA data buffer for block RAM', 'Replace sfdma_bytebuf by a registered-read, lane-banked memory (one RAM per byte lane, rotate on the read side) so the buffer maps to block RAM / a macro; re-run the CloudDMA regression, the system matrix and the synthesis stage, and compare LUT / flip-flop figures with the ones in this report.'),
]


def main():
    os.makedirs(OUT, exist_ok=True)
    tv = load('tool_versions.json', {})
    lint = load('lint.json')
    unit = load('unit.json')
    fw = load('firmware.json')
    sim = load('sim.json')
    synth = load('synth.json')
    mut = load('mutation.json')
    fpga = load('fpga_sim.json')
    manifest = json.load(open(os.path.join(ROOT, 'audit', 'manifest.json'))) if os.path.exists(os.path.join(ROOT, 'audit', 'manifest.json')) else {}
    pytest_res = None
    if os.path.exists(os.path.join(REPORTS, 'pytest.xml')):
        import xml.etree.ElementTree as ET
        r = ET.parse(os.path.join(REPORTS, 'pytest.xml')).getroot()
        ts = r if r.tag == 'testsuite' else r.find('testsuite')
        pytest_res = dict(tests=int(ts.get('tests')), failures=int(ts.get('failures')), errors=int(ts.get('errors')), skipped=int(ts.get('skipped')))

    # ---------------------------------------------------------------- simulation digest + performance
    runs = (sim or {}).get('runs', [])
    base = next((r for r in runs if r['name'].startswith('00_normal_s0') and not r['args']), None)
    perf = {}
    if base:
        c = parse_perf(base['firmware_perf'])
        links = base['links'] or []
        perf['basis'] = 'run %s (STALL_PCT=0, no host back-pressure), RTL simulation cycles of a 10 ns clock; NO silicon / FPGA claim' % base['name']
        perf['total_cycles_testbench'] = base['cycles']
        perf['total_cycles_firmware_selftest'] = (base['firmware'] or {}).get('selftest_cpu_cycles')
        perf['soc_cycle_counter_at_report'] = c.get('soc_cycles')
        perf['cpu_cycle_counter_at_report'] = c.get('cpu_cycles')
        perf['dma_bytes_transferred'] = dict(read=c.get('dma_bytes_rd'), written=c.get('dma_bytes_wr'), bursts_ok=c.get('dma_xact_ok'), bursts_error=c.get('dma_xact_err'))
        perf['dma_copy_sweep'] = sweep(base['firmware_perf'])
        sw = perf['dma_copy_sweep']
        perf['dma_bytes_per_cycle_sustained_4KiB'] = sw[-1]['copy_bytes_per_cycle'] if sw else None
        perf['memory_access_latency_cycles'] = {('cpu_link' if l['link'] == 0 else 'dma_link'): dict(read=l['read_latency'], write=l['write_latency']) for l in links}
        perf['memory_access_latency_note'] = 'request accepted at the Meridian master port -> response accepted, measured by the testbench scoreboard (includes the fabric, the 128->64 adaptation and IronMemory RL+3); the DMA link includes queueing behind its own earlier words'
        perf['arbitration_stalls'] = dict(meridian_total=c.get('mer_arbstall'), meridian_target0=c.get('t0_arbstall'), dma_master_stall_in=c.get('m1_stall_in'),
                                          iron_bank_wait_p0=c.get('iron_p0_bank_wait'), iron_bank_wait_p1=c.get('iron_p1_bank_wait'), iron_conflict_losses=(c.get('iron_p0_conflict', 0) or 0) + (c.get('iron_p1_conflict', 0) or 0))
        perf['busy_cycles'] = dict(meridian_busy=c.get('mer_busy'), meridian_cycles=c.get('mer_cycles'), dma_active=c.get('dma_active'), iron_bank_busy_sum_of_4_banks=c.get('iron_bank_busy'), iron_rmw_operations=c.get('iron_rmw'))
        perf['completion_latency_cycles'] = {('%dB' % r['bytes']): r['latency_cycles'] for r in sw}
        perf['fabric_traffic'] = dict(requests=c.get('mer_req'), completions=c.get('mer_cpl'), payload_bytes=c.get('mer_bytes'), denied_cpu=c.get('m0_denied'), denied_dma=c.get('m1_denied'),
                                      security_events=c.get('sec_events'), error_log_entries=c.get('elog_count'))
        perf['link_bytes'] = [dict(link=l['link'], bytes_read=l['bytes_read'], bytes_written=l['bytes_written'], requests=l['requests'], max_outstanding=l['max_outstanding']) for l in links]
        # sensitivity to random back-pressure (same firmware)
        perf['stall_sensitivity'] = [dict(stall_pct=r['stall_pct'], testbench_cycles=r['cycles']) for r in runs if r['scenario'] == 'normal' and not r['args']]
    # ---------------------------------------------------------------- tests summary
    rows = []
    if lint:
        for k, g in lint['gates'].items():
            rows.append(('lint', k, g['ok'], g.get('summary', '')))
    if unit:
        for r in unit['runs']:
            rows.append(('unit (cocotb)', '%s seed %d' % (r['name'], r['seed']), r['pass_'], r['summary'][:140]))
    if pytest_res:
        rows.append(('tool tests (pytest)', '%d tests' % pytest_res['tests'], pytest_res['failures'] + pytest_res['errors'] == 0, '%d skipped' % pytest_res['skipped']))
    if fw:
        rows.append(('firmware', 'boot ROM rebuilt == RTL image', fw['bootrom']['identical_to_rtl_image'], 'sha256 %s' % fw['bootrom']['rtl_image_sha256'][:16]))
        rows.append(('firmware', 'deterministic build, -Wall -Wextra clean', fw['firmware']['deterministic'] and fw['firmware']['warnings'] == 0, fw['firmware']['mkimage'] or ''))
    for r in runs:
        j = r
        rows.append(('system simulation', r['name'], r['pass_'], 'cycles=%s fw=%s/%s backdoor=%s/%s scoreboard=%s checks %s errors' % (
            r['cycles'], (r['firmware'] or {}).get('checks'), (r['firmware'] or {}).get('fails'), (r['backdoor'] or {}).get('checks'), (r['backdoor'] or {}).get('mismatches'),
            (r['scoreboard'] or {}).get('checks'), (r['scoreboard'] or {}).get('errors'))))
    if fpga:
        rows.append(('fpga wrapper simulation', 'boots firmware by itself (hardware loader + UART + LEDs)', fpga.get('pass'), fpga.get('summary', '')))
    if mut:
        rows.append(('mutation (glue)', '%d mutants' % mut['total'], mut['ok'], '%d killed, survivors: %s' % (mut['killed'], mut['survived'] or 'none')))
    if synth:
        for k, s in synth['stages'].items():
            rows.append(('synthesis (yosys %s)' % k, k, s.get('rc') == 0 and (k != 'elab' or (s['latches'] == 0 and not s['unresolved_modules'])), json.dumps({a: b for a, b in s.items() if a in ('latches', 'unresolved_modules', 'word_level_cells', 'flop_bits', 'inferred_memories', 'memory_bits', 'total_cells', 'luts', 'flops', 'bram', 'longest_path_cells', 'seconds')})))
    total = len(rows)
    passed = sum(1 for r in rows if r[2])

    # ---------------------------------------------------------------- definition of done
    sim_ok = bool(sim and sim['ok'])
    base_fw = (base or {}).get('firmware') or {}
    base_bd = (base or {}).get('backdoor') or {}
    base_sb = (base or {}).get('scoreboard') or {}
    c = parse_perf((base or {}).get('firmware_perf'))
    dod = [
        ('builds successfully', bool(lint and lint['ok'] and fw and fw['ok'] and unit is not None), 'lint.json (all gates), firmware.json (boot ROM + firmware, deterministic), simulation / unit builds'),
        ('executes compiled firmware in RTL simulation', bool(base and base['pass_'] and base_fw.get('result_seen') and base_fw.get('pass')), 'sim.json %s: real boot ROM validates the riscv64-unknown-elf-gcc image, firmware prints ALBION RESULT PASS (%s checks)' % ((base or {}).get('name'), base_fw.get('checks'))),
        ('reads and writes real SRAM contents', bool(base_bd.get('checks', 0) > 1000 and base_bd.get('mismatches') == 0), 'testbench backdoor compares %s SRAM bytes of IronMemory\'s banks with independently computed xorshift32 patterns: %s mismatches; CPU word/half/byte stores incl. ECC read-modify-write checked by firmware and scoreboard' % (base_bd.get('checks'), base_bd.get('mismatches'))),
        ('performs a real DMA transfer', bool(c.get('dma_bytes_wr', 0) >= 1024 and c.get('dma_xact_ok', 0) >= 6), 'CloudDMA counters: %s bytes written, %s bytes read, %s OK transactions; copies of 64 B .. 4 KiB incl. partial beats and a 2-element chain' % (c.get('dma_bytes_wr'), c.get('dma_bytes_rd'), c.get('dma_xact_ok'))),
        ('preserves data', bool(base_sb.get('data_errors') == 0 and base_bd.get('mismatches') == 0 and (base_sb.get('checks') or 0) > 10000), 'scoreboard (%s checks, reference memory built from acknowledged writes) 0 data errors; DMA CRC-32 equals the firmware CRC-32; destination == source, guard bytes untouched' % base_sb.get('checks')),
        ('rejects unauthorised accesses', bool(c.get('sec_events', 0) >= 5 and base_sb.get('security_errors') == 0), 'six DMA refusal paths (unmapped IOVA, read-only mapping, wrong domain claim, buffer ownership, unmanaged memory, control window) + Citadel policy revocations in both directions; fabric security events: %s, DMA domain DENIED %s times; scoreboard: the DMA link never got OKAY outside the SRAM window' % (c.get('sec_events'), c.get('m1_denied'))),
        ('produces real counters', bool(c.get('mer_req', 0) > 0 and c.get('dma_active', 0) > 0 and c.get('iron_bank_busy', 0) > 0), 'Meridian (96), IronMemory (per bank / port) and CloudDMA counters read by the firmware over the real register paths (see performance)'),
        ('passes reproducible regression tests', bool(sim_ok and unit and unit['ok'] and fw and fw['firmware']['deterministic']), '%s system runs (back-pressure 0/15/40/70 %%, host reset / async reset with transactions in flight), %s unit runs, deterministic firmware image; every target re-runnable with `make albion-all`' % ((sim or {}).get('total'), (unit or {}).get('total'))),
    ]
    dod_met = all(d[1] for d in dod)

    # ---------------------------------------------------------------- build manifest
    files = []
    for pat in ('rtl/**/*.sv', 'fw/**/*.[ch]', 'fw/Makefile', 'tb/*.sv', 'tests/**/*.py', 'tests/unit/*.sv', 'tools/**/*.py', 'config/*.yaml', 'lint/*.vlt', 'Makefile', 'patches/**/*.patch'):
        for p in sorted(glob.glob(os.path.join(ROOT, pat), recursive=True)):
            if os.path.isfile(p) and '__pycache__' not in p:
                files.append(dict(path=os.path.relpath(p, ROOT), sha256=sha(p), bytes=os.path.getsize(p)))
    prov = json.load(open(os.path.join(ROOT, 'ip', 'PROVENANCE.json')))
    bm = dict(generated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), project='AlbionForge 0.1.0', tool_versions={k: v.get('version') for k, v in tv.get('tools', {}).items()},
              project_sources=files,
              ip={n: dict(archive=e['archive'], archive_sha256=e['archive_sha256'], files=len(e['files']), patched_files=e['patched_files'], patches=e.get('patches', [])) for n, e in prov.items()},
              artefacts=dict(firmware=(fw or {}).get('firmware', {}).get('artefacts'), bootrom_rtl_image_sha256=(fw or {}).get('bootrom', {}).get('rtl_image_sha256'),
                             filelist=sha(os.path.join(ROOT, 'build/filelists/soc.f')) if os.path.exists(os.path.join(ROOT, 'build/filelists/soc.f')) else None),
              source_list=json.load(open(os.path.join(ROOT, 'build/filelists/soc.json'))) if os.path.exists(os.path.join(ROOT, 'build/filelists/soc.json')) else None)
    json.dump(bm, open(os.path.join(OUT, 'BUILD_MANIFEST.json'), 'w'), indent=1)

    # ---------------------------------------------------------------- synthesis digest
    syn = {}
    if synth:
        st = synth['stages']
        syn = dict(tool=synth.get('tool'), top=synth.get('top'), stages=st)
    hw = dict(note='Hardware readiness = what real synthesis says. It does NOT claim the design has run on hardware.',
              synthesis=syn, fpga_wrapper='rtl/fpga/sf_albion_fpga_top.sv (board-neutral); simulated: %s' % (fpga or {}),
              unresolved_black_boxes=(synth or {}).get('stages', {}).get('elab', {}).get('unresolved_modules'),
              timing_assumptions='none verified: one clock; every register is a clocked flop with asynchronous-assert / synchronous-release reset; no timing constraints, no timing analysis, no place-and-route; the only depth figure is the word-level (pre-ABC) one above, which is not a LUT depth.',
              tool_limitations=['Yosys 0.33 (apt) - no SystemVerilog interface / package-import support: the IP was patched (patches/), the glue follows the AlbionCore NAMING_RULES',
                                'synth_ecp5 is used as a stand-in technology; no vendor tool was run', 'no SymbiYosys; no timing analysis (nextpnr / OpenSTA not run)',
                                'synth_ecp5 on the FPGA wrapper is memory-bound in Yosys 0.33: a flattened and a hierarchical run were each killed by the 16 GB limit (about 14 GB resident, measured) in the final autoname pass; the reported mapping is hierarchical (-noflatten) and stops before autoname (-run begin:check). The longest path of the mapped netlist is NOT reported (ltp finds false loops through un-flattened hierarchy)',
                                'memories: inferred as $mem cells (4 x 2048 x 72 IronMemory banks, ControlCore I / D SRAM with parity, FIFOs); mapping to block RAM is the board flow\'s decision'])
    report = dict(
        project='AlbionForge: integration, build and verification foundation of the minimum Albion SoC', version='0.1.0', generated_utc=bm['generated_utc'],
        repository_head=(manifest or {}).get('repository'),
        summary=dict(definition_of_done_met=dod_met, checks_total=total, checks_passed=passed, headline=(
            'The minimum Albion SoC (ControlCore -> Meridian -> IronMemory <- BridgeEngine/CloudDMA, host interface) builds, runs its cross-compiled firmware in RTL simulation, '
            'copies data by DMA through real SRAM, refuses unauthorised accesses and reports real counters; all of it is reproducible with make. Simulation and generic synthesis only: no hardware run.')),
        definition_of_done=[dict(item=a, met=b, evidence=c_) for a, b, c_ in dod],
        tests=dict(rows=[dict(group=a, name=b, ok=c_, detail=d) for a, b, c_, d in rows], lint=lint, unit=unit, tool_tests=pytest_res, firmware=fw, system_simulation=sim, mutation=mut, fpga_wrapper_simulation=fpga),
        performance=perf, hardware_readiness=hw, synthesis=syn, tool_versions=tv,
        audit=dict(inventory=manifest.get('inventory'), integration_problems=manifest.get('integration_problems'), missing_major_ip=manifest.get('missing_major_ip'), files=len(manifest.get('files', []))),
        known_limitations=[dict(id=a, title=b, detail=c_) for a, b, c_ in LIMITS], next_actions=[dict(id=a, title=b, detail=c_) for a, b, c_ in NEXT])
    json.dump(report, open(os.path.join(OUT, 'albion_report.json'), 'w'), indent=1)

    # ---------------------------------------------------------------- markdown
    def table(head, rws):
        return ['| ' + ' | '.join(head) + ' |', '|' + '---|' * len(head)] + ['| ' + ' | '.join(str(x) for x in r) + ' |' for r in rws]
    M = ['# AlbionForge engineering report -- minimum Albion SoC', '',
         'Generated %s by `make albion-report` from the result files of the other targets (nothing below is typed in by hand except the limitations and next actions).' % bm['generated_utc'], '',
         '## 1. Result', '', report['summary']['headline'], '', '**Definition of done: %s.**' % ('MET' if dod_met else 'NOT MET'), '']
    M += table(['Definition-of-done item', 'met', 'evidence'], [(a, 'yes' if b else '**NO**', c_) for a, b, c_ in dod])
    M += ['', '**Not claimed:** any FPGA / silicon frequency, area, power or bandwidth; any hardware run; security of the boot path. See section 8.', '',
          '## 2. What was built', '',
          'One SoC, assembled from the existing SilicaFlux IP (nothing replaced by a stand-in):', '',
          '```', 'host (testbench BFM | sf_asoc_host_loader)  -- hs_* SFB2 -->  ControlCore P21 (RV32IM, boot ROM, I/D SRAM, mailbox)',
          '                                            ext_* SFB2 | sf_asoc_sfb2_init (32->128 bit, window translation)   = ALP master 0, domain 0',
          'CloudDMA P64 (BridgeEngine)  AXI4 -> sf_asoc_axi_init (burst -> ALP words, IDs, second-check refusals)       = ALP master 1, domain 1',
          '                                            both -> sf_asoc_mer_core = Meridian P83 fabric (2 x 4, reference Citadel)',
          '        targets: t0 sram -> IronMemory P84 (ECC, 2 ports, buffer manager)   t1 sram_ctl (IronMemory CSRs + buffer-manager shim)',
          '                 t2 dma -> CloudDMA CSRs + submission + permission-table shim   t3 soc_ctl (Citadel policy, Meridian counters / error log)', '```', '',
          'The shared transaction contract is **ALP v1** (AlbionCore): 64-bit address, 128-bit data, 8-bit tag / domain / attributes, in-order completion. Every IP boundary is converted to and from it by a glue module (docs/ARCHITECTURE.md). '
          'The generated memory map: docs/MEMORY_MAP_SOC.md. Domains are bound by hardware at each master port.', '',
          '## 3. Audit (priority 1)', '',
          'The SilicaFlux work lives in %s nested archives holding %s HDL files (%s distinct module / package names; %s declared in more than one archive, %s with divergent bodies) -- nothing in the repository tree is directly buildable. '
          'The curated, measured manifest of the %s source files the SoC compiles is `audit/MANIFEST.md` / `audit/manifest.json`.' % (
              (manifest or {}).get('inventory', {}).get('archives_extracted'), (manifest or {}).get('inventory', {}).get('hdl_files'), (manifest or {}).get('inventory', {}).get('distinct_declared_names'),
              (manifest or {}).get('inventory', {}).get('names_declared_more_than_once'), (manifest or {}).get('inventory', {}).get('names_with_divergent_bodies'), (manifest or {}).get('files') and len(manifest['files'])), '',
          '### Integration problems found and resolved', '']
    M += table(['id', 'problem', 'resolution'], [(p['id'], p['title'], p['resolution']) for p in (manifest or {}).get('integration_problems', [])])
    M += ['', '### Major IP that does not exist (not faked)', ''] + table(['item', 'handling'], [(m['item'], m['handling']) for m in (manifest or {}).get('missing_major_ip', [])])
    M += ['', '## 4. Verification', '', 'Independent expected results: xorshift32 patterns recomputed by the testbench; a byte-accurate reference memory built by the scoreboard from acknowledged writes; Python models in the cocotb tests; the DMA CRC-32 against the firmware\'s own CRC-32.', '']
    M += table(['group', 'what', 'result', 'detail'], [(a, b, 'PASS' if c_ else '**FAIL**', d) for a, b, c_, d in rows])
    M += ['', '%d of %d checks pass.' % (passed, total), '', '## 5. Performance (priority 6)', '']
    if perf:
        M += [perf['basis'], '', '**Not a bandwidth claim**: simulated cycles of a 10 ns testbench clock.', '']
        M += table(['DMA copy of', 'completion latency (cycles, submit -> done)', 'copy bytes / cycle', 'link bytes / cycle (read + write)'], [('%d B' % r['bytes'], r['latency_cycles'], r['copy_bytes_per_cycle'], r['link_bytes_per_cycle']) for r in perf['dma_copy_sweep']])
        M += ['', 'Total simulated cycles of the full run (boot ROM, image load, firmware self-test): %s; the firmware self-test itself took %s CPU cycles.' % (perf['total_cycles_testbench'], perf['total_cycles_firmware_selftest']), '']
        lat = perf['memory_access_latency_cycles']
        M += table(['memory access latency (cycles)', 'reads (mean / min / max)', 'writes (mean / min / max)'], [(k, '%s / %s / %s' % (v['read']['mean'], v['read']['min'], v['read']['max']), '%s / %s / %s' % (v['write']['mean'], v['write']['min'], v['write']['max'])) for k, v in lat.items()])
        M += ['', perf['memory_access_latency_note'], '', '| counter | value |', '|---|---|']
        for grp in ('dma_bytes_transferred', 'arbitration_stalls', 'busy_cycles', 'fabric_traffic'):
            for k, v in perf[grp].items():
                M.append('| %s.%s | %s |' % (grp, k, v))
        M += ['', 'Sensitivity to random back-pressure (same firmware):', ''] + table(['STALL_PCT', 'testbench cycles'], [(r['stall_pct'], r['testbench_cycles']) for r in perf['stall_sensitivity']])
        M += ['', 'Why only about 1 byte per cycle: see limitation L-08 (128 -> 64-bit adaptation, one wide transaction at a time per port).']
    M += ['', '## 6. Hardware readiness (priority 7)', '', hw['note'], '']
    st = (synth or {}).get('stages', {})
    if 'elab' in st:
        e = st['elab']
        M.append('* **Elaboration (Yosys %s, `proc; check -assert`)**: %s latches, unresolved modules / black boxes: %s, %s warnings (memory-to-register notices only).' % ((synth.get('tool') or '').split()[1] if synth.get('tool') else '?', e['latches'], e['unresolved_modules'] or 'none', e['warnings']))
    if 'coarse' in st:
        co = st['coarse']
        M.append('* **Word-level synthesis (flattened)**: %s cells, %s flip-flop bits outside memories, **%s inferred memories, %s memory bits** (kept as memories).' % (co['word_level_cells'], co['flop_bits'], co['inferred_memories'], co['memory_bits']))
        if co.get('word_level_longest_path'):
            M.append('* Longest word-level topological path of the flattened SoC (each operator counts 1; before ABC, so **not** a LUT depth or a frequency): %s operators, running through `%s`.' % (co['word_level_longest_path'], co.get('word_level_longest_path_through', '')))
        M += ['', 'Largest inferred memories:', ''] + table(['words', 'width', 'bits', 'cell'], [(m['words'], m['width'], m['bits'], m['name'][:70]) for m in co['memories'][:10]])
    if 'fpga' in st:
        fp = st['fpga']
        if fp.get('rc') == 0 and fp.get('total_cells'):
            M += ['', '* **FPGA-primitive mapping (`synth_ecp5`, %s; generic stand-in, no P&R, not a device-utilisation figure)**: %s LUT-class cells (LUT4 + PFUMX + L6MUX21), %s flip-flops (TRELLIS_FF), %s DP16KD block RAMs, %s distributed-RAM (TRELLIS_DPR16X4) cells, %s carry cells, %s MULT18X18D (%s cells total).' % (fp.get('mode', ''), fp.get('luts'), fp.get('flops'), fp.get('bram'), fp.get('dist_ram'), fp.get('carry'), fp.get('mult18'), fp.get('total_cells')),
                  '* Longest path of the mapped netlist: not reported (%s).' % fp.get('longest_path_note', 'not measured')]
            if fp.get('largest_modules'):
                tot = max(1, fp.get('total_cells') or 1)
                M += ['', 'Largest modules in the mapping (own cells, per module definition):', ''] + table(['module', 'cells', 'share of all cells', 'LUT-class', 'flip-flops', 'DP16KD', 'dist. RAM'], [(m['module'], m['cells'], '%.1f %%' % (100.0 * m['cells'] / tot), m['lut_class'], m['flops'], m['bram'], m['dist_ram']) for m in fp['largest_modules'][:8]])
        else:
            M += ['', '* **FPGA-primitive mapping (`synth_ecp5`)**: DID NOT COMPLETE (rc=%s after %ss) -- no resource figures are claimed.' % (fp.get('rc'), fp.get('seconds'))]
    M += ['* Timing assumptions: %s' % hw['timing_assumptions'], '* Board-neutral wrapper: `rtl/fpga/sf_albion_fpga_top.sv` -- %s' % ('boots the firmware by itself in simulation (loader done, test done, no fail, UART result PASS)' if (fpga or {}).get('pass') else 'simulation result missing'), '', 'Tool limitations:', ''] + ['* ' + t for t in hw['tool_limitations']]
    M += ['', '## 7. Reproducibility', '', 'Tools: ' + ', '.join('%s %s' % (k, v.get('version')) for k, v in tv.get('tools', {}).items() if v.get('version')) + '. Build manifest with SHA-256 of every project source, IP provenance and artefacts: `reports/BUILD_MANIFEST.json`.', '',
          '```', 'make albion-all   # doctor, lint, test, firmware, sim, synth, report', '```', '', '## 8. Known limitations', '']
    M += table(['id', 'limitation', 'detail'], [(a, b, c_) for a, b, c_ in LIMITS])
    M += ['', '## 9. Next engineering actions', ''] + table(['id', 'action', 'detail'], [(a, b, c_) for a, b, c_ in NEXT])
    open(os.path.join(OUT, 'ENGINEERING_REPORT.md'), 'w').write('\n'.join(M) + '\n')
    T = ['# Test summary', '', '%d of %d test groups / runs pass.' % (passed, total), ''] + table(['group', 'what', 'result', 'detail'], [(a, b, 'PASS' if c_ else 'FAIL', d) for a, b, c_, d in rows])
    open(os.path.join(OUT, 'TEST_SUMMARY.md'), 'w').write('\n'.join(T) + '\n')
    open(os.path.join(OUT, 'KNOWN_LIMITATIONS.md'), 'w').write('\n'.join(['# Known limitations (what is NOT claimed)', ''] + table(['id', 'limitation', 'detail'], [(a, b, c_) for a, b, c_ in LIMITS])) + '\n')
    open(os.path.join(OUT, 'NEXT_ACTIONS.md'), 'w').write('\n'.join(['# Next engineering actions', ''] + table(['id', 'action', 'detail'], [(a, b, c_) for a, b, c_ in NEXT])) + '\n')
    print('report: %d/%d checks pass; definition of done %s' % (passed, total, 'MET' if dod_met else 'NOT MET'))
    for d in dod:
        print('  [%s] %s' % ('x' if d[1] else ' ', d[0]))
    sys.exit(0 if (dod_met and passed == total) else 1)


if __name__ == '__main__':
    main()
