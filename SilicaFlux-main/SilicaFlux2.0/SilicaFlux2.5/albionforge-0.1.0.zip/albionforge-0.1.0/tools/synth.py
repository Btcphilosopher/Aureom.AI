#!/usr/bin/env python3
"""AlbionForge synthesis flow (Yosys, open source): real synthesis of the minimum Albion SoC.

  synth.py --top sf_albion_soc_min --filelist build/filelists/soc.f --out build/synth [--stages elab,coarse,fpga] [--timeout S]

Stages (each writes a log, a stat report and a JSON summary):
  elab    read_verilog -defer, hierarchy -check, proc: structural problems, undriven / multiply driven nets, latches,
          unresolved modules (black boxes)  -> must be clean
  coarse  synth -flatten -run begin:fine : word-level netlist; $mem cells = INFERRED MEMORIES (kept as memories, not mapped
          to flip-flops); per-module breakdown from the non-flattened design
  fpga    synth_ecp5 (LUT4 / DP16KD / carry primitives): the resource estimate (hierarchical; totals and per-module table from `stat`).
          The technology is only a stand-in for "a generic FPGA": NO place-and-route, NO timing closure, NO board is implied.
Tool limits are recorded in the JSON (Yosys version, flags).  Numbers are synthesis estimates, not area / timing / power claims.
"""
import argparse, json, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def sh(cmd, log, timeout=None):
    t0 = time.time()
    with open(log, 'w') as f:
        try:
            p = subprocess.run(cmd, shell=True, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
            rc = p.returncode
        except subprocess.TimeoutExpired:
            rc = -9
    return rc, time.time() - t0


def parse_stat(path, width_suffix=False):
    """parse a Yosys `stat` report -> ({cell_type: count}, text).  With stat -width the suffix of a cell type is its bit width."""
    cells = {}
    txt = open(path).read() if os.path.exists(path) else ''
    sec = txt.split('design hierarchy ===')[-1] if 'design hierarchy ===' in txt else txt.split('\n=== ')[-1]
    for m in re.finditer(r'^\s+(\S+)\s+(\d+)\s*$', sec, re.M):
        name = m.group(1)
        if name.startswith('$') or name.isupper() or re.match(r'^[A-Z0-9_]+$', name):
            cells[name] = cells.get(name, 0) + int(m.group(2))
    return cells, txt


def flop_bits(cells):
    tot = 0
    for n, c in cells.items():
        m = re.match(r'^\$(adff|adffe|dff|dffe|sdff|sdffe|sdffce|dffsr|dffsre|aldff|aldffe|dlatch|adlatch)_(\d+)$', n)
        if m:
            tot += c * int(m.group(2))
    return tot


def memories(json_path):
    """inferred memories ($mem_v2 cells) from a Yosys JSON netlist"""
    out = []
    if not os.path.exists(json_path):
        return out
    d = json.load(open(json_path))
    for mname, mod in d['modules'].items():
        for cname, c in mod['cells'].items():
            if c['type'] in ('$mem_v2', '$mem'):
                pr = c['parameters']
                def iv(k):
                    v = pr.get(k, '0')
                    return int(v, 2) if isinstance(v, str) else int(v)
                out.append(dict(name=cname.split('.')[0] if False else cname, words=iv('SIZE'), width=iv('WIDTH'), bits=iv('SIZE') * iv('WIDTH'),
                                rd_ports=iv('RD_PORTS'), wr_ports=iv('WR_PORTS'), src=c.get('attributes', {}).get('src', '')))
    return sorted(out, key=lambda m: -m['bits'])


def parse_ltp(text):
    """(length, source file the path mostly runs through) from a Yosys `ltp` report"""
    m = re.search(r'Longest topological path in (\S+) \(length=(\d+)\)', text)
    if not m:
        return None, ''
    seg = text[text.index('Longest topological path'):][:400000]
    seg = seg.split('Longest topological path', 2)[1] if seg.count('Longest topological path') > 1 else seg
    files = re.findall(r'/([A-Za-z0-9_]+\.sv):\d+', seg)
    where = max(set(files), key=files.count) if files else ''
    return int(m.group(2)), where


def fpga_summary(out, rc, dt):
    cells, txt = parse_stat(os.path.join(out, 'fpga_stat.txt'))
    cells = {n: c for n, c in cells.items() if re.match(r'^[A-Z][A-Z0-9_]*$', n)}   # primitives only (the hierarchy lines list module instances)
    # per-module (own cells, not instances) table: which module is the resource
    mods = []
    for sec in re.split(r'\n=== ', txt):
        mh = re.match(r'(.+?) ===', sec)
        if not mh or 'design hierarchy' in mh.group(1):
            continue
        def cnt(k, sec=sec):
            mm = re.search(r'^\s+%s\s+(\d+)\s*$' % k, sec, re.M)
            return int(mm.group(1)) if mm else 0
        nc = re.search(r'Number of cells:\s+(\d+)', sec)
        mods.append(dict(module=re.sub(r'^\$paramod(\$[0-9a-f]+)?\\?', '', mh.group(1).strip())[:60], lut_class=cnt('LUT4') + cnt('PFUMX') + cnt('L6MUX21'),
                         flops=cnt('TRELLIS_FF'), bram=cnt('DP16KD'), dist_ram=cnt('TRELLIS_DPR16X4'), cells=int(nc.group(1)) if nc else 0))
    mods.sort(key=lambda m: -m['cells'])
    return dict(rc=rc, seconds=(round(dt, 1) if dt is not None else None), mode='hierarchical: synth_ecp5 -noflatten -run begin:check (stops before the memory-hungry autoname pass), totals from stat -top',
                                 cells=cells, total_cells=sum(cells.values()),
                                 luts=sum(c for n, c in cells.items() if n.startswith('LUT') or n == 'PFUMX' or n == 'L6MUX21'),
                                 flops=cells.get('TRELLIS_FF', 0), bram=cells.get('DP16KD', 0), carry=cells.get('CCU2C', 0),
                                 dist_ram=cells.get('TRELLIS_DPR16X4', 0), mult18=cells.get('MULT18X18D', 0),
                                 largest_modules=mods[:12],
                                 source=('mapping run in this invocation' if dt is not None else 'statistics re-parsed (--reuse-stat) from the mapping run whose output is fpga_stat.txt; that run took about 15 minutes and about 9 GB resident'),
                                 longest_path_cells=None,
                                 longest_path_note='not measured on the mapped netlist: ltp reports false loops through un-flattened hierarchy (it wrote 7 GB) and a flattened mapping does not fit in 16 GB')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--top', required=True)
    ap.add_argument('--filelist', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--stages', default='elab,coarse,fpga')
    ap.add_argument('--timeout', type=int, default=3600)
    ap.add_argument('--reuse-stat', action='store_true', help='fpga stage: re-parse an existing fpga_stat.txt instead of re-running the 15-25 minute mapping')
    ap.add_argument('--defines', default='-DSYNTHESIS -DSFV_NO_CLOCK_GATE')
    a = ap.parse_args()
    out = os.path.join(ROOT, a.out)
    os.makedirs(out, exist_ok=True)
    files = [l.strip() for l in open(os.path.join(ROOT, a.filelist)) if l.strip() and not l.startswith(('//', '+incdir'))]
    incs = ['-I' + l.strip()[len('+incdir+'):] for l in open(os.path.join(ROOT, a.filelist)) if l.startswith('+incdir')]
    read = 'read_verilog -defer -sv %s %s %s; hierarchy -check -top %s' % (a.defines, ' '.join(incs), ' '.join(files), a.top)
    ver = subprocess.run(['yosys', '-V'], capture_output=True, text=True).stdout.strip()
    res = {'tool': ver, 'top': a.top, 'defines': a.defines, 'stages': {}}
    stages = a.stages.split(',')

    if 'elab' in stages:
        log = os.path.join(out, 'elab.log')
        script = read + '; proc; opt_clean; check -assert; tee -o %s/elab_stat.txt stat -width' % out
        rc, dt = sh("yosys -q -l %s -p '%s'" % (log, script.replace("'", "'\\''")), log + '.out', a.timeout)
        txt = open(log).read() if os.path.exists(log) else ''
        warn = [l for l in txt.splitlines() if 'Warning:' in l and 'Replacing memory' not in l]
        latch = len(re.findall(r'Latch inferred', txt))
        blackbox = sorted(set(re.findall(r"Module `?\\?([\w$.]+)'? is not part of the design|Re-definition of module|isn't defined", txt)))
        unresolved = re.findall(r'ERROR: Module `\\?([\w$.]+)\' referenced .* is not part of the design', txt)
        multi = len(re.findall(r'multiple conflicting drivers|has multiple drivers', txt))
        undrv = len(re.findall(r'has no driver|is used but has no driver|Warning: Wire .* is used but has no driver', txt))
        res['stages']['elab'] = dict(rc=rc, seconds=round(dt, 1), latches=latch, unresolved_modules=unresolved,
                                     multiple_driver_reports=multi, undriven_reports=undrv, warnings=len(warn),
                                     warning_sample=warn[:12])
        print('elab: rc=%d latches=%d unresolved=%s warnings=%d (%.0fs)' % (rc, latch, unresolved, len(warn), dt))

    if 'coarse' in stages:
        log = os.path.join(out, 'coarse.log')
        # non-flattened for the per-module table, flattened for the totals
        script = read + '; synth -run begin:fine -top %s; opt_clean; tee -o %s/coarse_hier_stat.txt stat -width' % (a.top, out)
        rc, dt = sh("yosys -q -l %s -p '%s'" % (log, script), log + '.out', a.timeout)
        script = read + '; synth -flatten -run begin:fine -top %s; opt_clean; tee -o %s/coarse_flat_stat.txt stat -width; write_json %s/coarse_flat.json' % (a.top, out, out)
        rc2, dt2 = sh("yosys -q -l %s -p '%s'" % (os.path.join(out, 'coarse_flat.log'), script), os.path.join(out, 'coarse_flat.out'), a.timeout)
        cells, txt = parse_stat(os.path.join(out, 'coarse_flat_stat.txt'))
        mems = memories(os.path.join(out, 'coarse_flat.json'))
        # word-level longest topological path (each word-level operator counts 1; pre-ABC, so NOT a LUT depth).  The output is size-capped:
        # ltp prints one line per detected loop and an un-flattened netlist makes that unbounded (it filled a disk once).
        ltp_path = os.path.join(out, 'coarse_ltp.txt')
        sh("ulimit -f 40000; yosys -q -p 'read_json %s/coarse_flat.json; tee -o %s ltp -noff'" % (out, ltp_path), os.path.join(out, 'coarse_ltp.out'), min(a.timeout, 900))
        ltp_word, ltp_where = parse_ltp(open(ltp_path).read() if os.path.exists(ltp_path) else '')
        res['stages']['coarse'] = dict(rc=rc, rc_flat=rc2, seconds=round(dt + dt2, 1), word_level_cells=sum(cells.values()), flop_bits=flop_bits(cells),
                                       cell_types=cells, inferred_memories=len(mems), memory_bits=sum(m['bits'] for m in mems), memories=mems[:40],
                                       word_level_longest_path=ltp_word, word_level_longest_path_through=ltp_where)
        print('coarse: rc=%d/%d (%.0fs) word-level cells=%d flop bits=%d memories=%d (%d bits)' % (rc, rc2, dt + dt2, sum(cells.values()), flop_bits(cells), len(mems), sum(m['bits'] for m in mems)))

    if 'fpga' in stages:
        # Measured with Yosys 0.33 on this design: the last pass of synth_ecp5 (`autoname`, label `check`) needs > 14 GB for the ~1 M
        # mapped cells and was killed by the 16 GB limit, both for the flattened and for the hierarchical mapping.  autoname only renames
        # cells, so mapping stops before that label (-run begin:check) and the statistics are taken from the mapped netlist.
        # -noflatten: ABC runs per module and `stat -top` gives hierarchy totals.  No ltp here: on an un-flattened netlist it reports false loops.
        log = os.path.join(out, 'fpga.log')
        script = (read + '; synth_ecp5 -noflatten -top %s -run begin:check; hierarchy -check -top %s; tee -o %s/fpga_stat.txt stat -top %s') % (a.top, a.top, out, a.top)
        if a.reuse_stat and os.path.exists(os.path.join(out, 'fpga_stat.txt')):
            rc, dt = 0, None
        else:
            rc, dt = sh("yosys -q -l %s -p '%s'" % (log, script), log + '.out', a.timeout)
        res['stages']['fpga'] = fpga_summary(out, rc, dt)
        cells = res['stages']['fpga']['cells']
        mods = res['stages']['fpga']['largest_modules']
        print('fpga: rc=%d (%ss) cells=%d luts=%d ffs=%d dp16kd=%d largest=%s' % (rc, res['stages']['fpga']['seconds'], sum(cells.values()), res['stages']['fpga']['luts'], res['stages']['fpga']['flops'], res['stages']['fpga']['bram'], mods[0]['module'] if mods else None))

    path = os.path.join(out, 'synth_summary.json')
    json.dump(res, open(path, 'w'), indent=1)
    print('wrote', path)


if __name__ == '__main__':
    main()
