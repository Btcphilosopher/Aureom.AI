# Albion architecture contract

Status: **ALP v1.0, library 0.1.0**.  This document is the contract every Albion module obeys and every
dependent project may rely on.  The **primary source** of every constant in it is
[`rtl/albion/sf_albion_pkg.sv`](../../rtl/albion/sf_albion_pkg.sv); C and Rust definitions are generated from that file
(`include/albion/albion_proto.{h,rs}`).  Every rule has an id (`ALP-xxx-nn`) that appears in the checkers, tests and
proofs that enforce it; the matrix is in [TRACEABILITY.md](generated/TRACEABILITY.md) and is checked by `make check`.

What this contract does **not** claim is listed in section 12.

## 1. Scope and vocabulary

| Term | Meaning |
|---|---|
| **Link** | one request channel (initiator to target) plus one response channel (target to initiator) |
| **Initiator** | the agent that sends requests and receives responses (CPU, DMA, tensor engine, ...) |
| **Target** | the agent that executes requests and returns responses (memory, register block, error responder, ...) |
| **Word** | the data width of a link: 128 bit (16 byte lanes) for the baseline |
| **Accepted** | a request that has completed its valid/ready handshake |
| **Outstanding** | accepted but whose response has not yet been accepted by the initiator |

ALP v1 defines **two operations, READ and WRITE**, single-beat (no bursts), non-posted writes, in-order completion,
and eight-bit tags.  Atomic operations, out-of-order completion, bursts and coherence are deliberately **not** part of
v1 (section 10).

## 2. Baseline types and widths

The package types are **fixed**: 64-bit address, 128-bit data, 16-bit byte mask, 8-bit tag, 8-bit protection-domain
id.  Other widths are supported only through an explicit conversion adapter (`sf_albion_width_adapter`, section 9) or a
future generated package; a hardware profile that asks for other widths is refused by `validate_params.py` (ALP-WID-01).

<!-- BEGIN GEN:STRUCT_TABLES -->
### Operation codes (`sf_op_e`, 4 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_OP_NONE` |  |
| `0x1` | `SF_OP_READ` |  |
| `0x2` | `SF_OP_WRITE` |  |

### Status codes (`sf_status_e`, 4 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_ST_OKAY` | completed successfully |
| `0x1` | `SF_ST_DECODE_ERR` | address maps to no region / no target |
| `0x2` | `SF_ST_ACCESS_DENIED` | region permission, privilege, security or domain check failed |
| `0x3` | `SF_ST_BAD_OPCODE` | opcode not READ/WRITE (reserved, atomic family, or NONE) |
| `0x4` | `SF_ST_BAD_BE` | byte-enable mask is zero |
| `0x5` | `SF_ST_ALIGN_ERR` | address is not aligned to the data word |
| `0x6` | `SF_ST_BAD_ATTR` | reserved attribute bits set, or memory type not allowed |
| `0x7` | `SF_ST_TARGET_ERR` | generic target / device failure |
| `0x8` | `SF_ST_TIMEOUT` | target did not complete within its watchdog window |
| `0x9` | `SF_ST_CANCELLED` | locally synthesised completion for an abandoned request |
| `0xA` | `SF_ST_ECC_UNCORR` | uncorrectable data error; data is poisoned |
| `0xB` | `SF_ST_PROTOCOL_ERR` | link protocol violation detected by a component |

### Memory types (`sf_mem_type_e`, 2 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_MEM_NORMAL_WB` | normal memory, cacheable write-back |
| `0x1` | `SF_MEM_NORMAL_NC` | normal memory, non-cacheable |
| `0x2` | `SF_MEM_DEVICE` | device memory: strongly ordered, no merging or speculation |

### Address-space identifiers (`sf_asid_e`, 4 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_AS_DEVICE` | device-local memory (SRAM, scratchpads) |
| `0x1` | `SF_AS_CONFIG` | control / status registers (MMIO) |
| `0x2` | `SF_AS_EXTERNAL` | external memory reached through an adapter |
| `0x3` | `SF_AS_HOST` | host physical memory (reserved; DMA / PCIe path) |
| `0x4` | `SF_AS_SECURE` | secure-only memory and key storage |

### Request payload (`sf_req_t`, 236 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [235:232] | `op` | 4 | [235:232] operation |
| [231:224] | `tag` | 8 | [231:224] initiator transaction tag (opaque to targets) |
| [223:216] | `dom` | 8 | [223:216] protection domain |
| [215:208] | `attr` | 8 | [215:208] access attributes |
| [207:144] | `addr` | 64 | [207:144] byte address, lane-aligned (addr[3:0] == 0) |
| [143:128] | `be` | 16 | [143:128] byte-lane enables |
| [127:0] | `data` | 128 | [127:0]   write data (don't-care for reads, ignored) |

### Response payload (`sf_rsp_t`, 148 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [147:140] | `tag` | 8 | [147:140] echoed request tag |
| [139:136] | `status` | 4 | [139:136] sf_status_e |
| [135:128] | `meta` | 8 | [135:128] completion metadata |
| [127:0] | `data` | 128 | [127:0]   read data; all-zero for writes and for non-OKAY status |

### Access attributes (`sf_attr_t`, 8 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [7] | `rsvd` | 1 | [7]   must be 0           (else SF_ST_BAD_ATTR) |
| [6:5] | `qos` | 2 | [6:5] priority class hint, 0 = lowest .. 3 = highest |
| [4] | `instr` | 1 | [4]   instruction fetch (execute intent) |
| [3] | `secure` | 1 | [3]   1 = secure access |
| [2] | `priv` | 1 | [2]   1 = privileged access |
| [1:0] | `mem_type` | 2 | [1:0] sf_mem_type_e; 2'd3 reserved (else SF_ST_BAD_ATTR) |

### Region attributes (`sf_region_attr_t`, 8 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [7:6] | `mem_type` | 2 | [7:6] sf_mem_type_e of the region |
| [5] | `cacheable` | 1 | [5]   initiators may cache this region |
| [4] | `secure_only` | 1 | [4]   only secure accesses allowed |
| [3] | `priv_only` | 1 | [3]   only privileged accesses allowed |
| [2] | `exec` | 1 | [2]   instruction fetch allowed |
| [1] | `write` | 1 | [1]   writes allowed |
| [0] | `read` | 1 | [0]   reads allowed |

### Completion metadata (`sf_cmeta_t`, 8 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [7:4] | `rsvd` | 4 | [7:4] must be 0 |
| [3] | `corrected` | 1 | [3]   a correctable error was repaired (informational) |
| [2] | `poisoned` | 1 | [2]   data lanes must not be consumed (== status ECC_UNCORR) |
| [1] | `last` | 1 | [1]   last beat of the transaction (always 1 in ALP v1) |
| [0] | `is_write` | 1 | [0]   0 = read completion, 1 = write completion |

### Device capabilities (`sf_caps_t`, 64 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [63:60] | `proto_major` | 4 | [63:60] ALP major version |
| [59:56] | `proto_minor` | 4 | [59:56] ALP minor version |
| [55:48] | `addr_w` | 8 | [55:48] address width in bits |
| [47:44] | `data_bytes_log2` | 4 | [47:44] log2(data bytes): 4 = 16 bytes = 128 bit |
| [43:40] | `tag_w` | 4 | [43:40] tag width in bits |
| [39:36] | `dom_w` | 4 | [39:36] domain-id width in bits |
| [35:32] | `rsvd` | 4 | [35:32] reserved, 0 |
| [31:16] | `max_outstanding` | 16 | [31:16] outstanding transactions per link |
| [15:0] | `features` | 16 | [15:0]  SF_FEAT_* bit map |

### Fixed widths

| Constant | Value |
|---|---|
| `SF_ADDR_W` | 64 |
| `SF_DATA_W` | 128 |
| `SF_BE_W` | 16 |
| `SF_TAG_W` | 8 |
| `SF_DOM_W` | 8 |
| `SF_REQ_W` | 236 |
| `SF_RSP_W` | 148 |
| `SF_MAX_OUTSTANDING_LIMIT` | 256 |
<!-- END GEN:STRUCT_TABLES -->

Notes on the fields:

* **Address.** A byte address aligned to the word: `addr[3:0]` must be 0.  Byte lane *i* of the word at `addr`
  is the byte at `addr + i`.  Sub-word accesses are expressed by byte enables, not by address bits.
* **Byte enables (`be`).** One bit per byte lane.  `be == 0` is illegal.  For a WRITE the enabled lanes of `data` are
  written; for a READ the enabled lanes are returned and all other lanes of the response are **zero** (ALP-RSP-07,
  checked by the link checkers; adapters rely on it and do not mask the lanes themselves).
* **Tag.** Chosen by the initiator, echoed unchanged by the target.  Targets, fabrics and one-to-one adapters treat it as
  opaque.  An adapter that splits one request into several on its master link (the downsizer of
  `sf_albion_width_adapter`) is the initiator of that link and allocates the tags there (the beat index, unique among the
  beats in flight); it restores the parent's tag on the wide response (ALP-TAG-03).
* **Domain.** 0x00 root, 0x01 management, 0x02 system DMA, 0x03..0x0F reserved system, 0x10..0xFE tenants, 0xFF invalid
  (never legal on the wire).  Domains are carried and checked for validity; **enforcing per-domain permissions is the job
  of a protection unit that is not part of this foundation** (no `domain_check` feature is claimed by any profile).
* **Attributes.** `mem_type` (normal write-back / normal non-cacheable / device), privileged, secure, instruction-fetch
  and a two-bit QoS hint.  Bit 7 is reserved and `mem_type == 3` is reserved.

## 3. Handshakes

Both channels use an independent `valid`/`ready` pair.  A transfer happens on a rising clock edge at which both are high.

Example of back-pressure on the request channel (one row per clock cycle; a transfer happens at the end of a cycle in which both
signals are high):

| Cycle | `req_valid` | `req_ready` | Payload | What happens |
|---|---|---|---|---|
| 1 | 1 | 0 | request A | offered, target not ready: nothing transfers, A **must be held** (ALP-REQ-02) |
| 2 | 1 | 0 | request A (unchanged) | still not ready |
| 3 | 1 | 1 | request A (unchanged) | **A is accepted** at the end of cycle 3 (ALP-REQ-01) |
| 4 | 1 | 1 | request B | B offered and accepted back to back (one transfer per cycle is possible) |
| 5 | 0 | x | - | nothing offered |

* **Request** (`ALP-REQ-01/02/03`): once `req_valid` is high it stays high with an unchanged payload until accepted.
  `req_valid` never depends on `req_ready`.  No library component has a combinational path from `valid` or data to a
  `ready` output; `ready` may depend on registered state, on `flush` and on the downstream `ready` (a *ready chain*).
* **Response** (`ALP-RSP-01/02`): same rules mirrored on the response channel.
* **Independence** (`ALP-RSP-06`): an initiator must be able to accept responses without first issuing a request, i.e.
  `rsp_ready` never depends on `req_ready`.  This is what makes the pair deadlock-free.

## 4. Transaction lifecycle

| Cycle | Request channel | Response channel |
|---|---|---|
| *n* | request R (tag 5) **accepted** | no response for R may be visible (ALP-RSP-03) |
| *n+1* or later | - | response for tag 5 may be presented; held until accepted (ALP-RSP-02) |

* **Acceptance.** The commit point for ordering and for outstanding-request accounting.
* **Read completion.** A response with `meta.is_write = 0` carrying the enabled lanes (others zero) and a status.
* **Write completion.** A response with `meta.is_write = 1`, all-zero data and a status.  Writes are **not posted**: the
  response is produced only when the write is visible to every later request accepted at that target (ALP-ORD-03).
* **Backpressure.** `req_ready` low stalls the initiator; `rsp_ready` low stalls the target.  Nothing is dropped,
  reordered or duplicated by back-pressure on either channel.  A target may refuse new requests while its response
  buffers are full.
* **Response format** (ALP-RSP-05).  Defined status code; `meta.last = 1`; reserved metadata bits 0; **any status other than
  OKAY returns all-zero data** (nothing is leaked by an error response); `meta.poisoned` is set exactly for
  `ECC_UNCORR`.
* **Minimum latency.** A response is never visible in the cycle its request is accepted (ALP-RSP-03); there is no
  combinational request-to-response path.

## 5. Ordering

* **In order** (ALP-ORD-01): on one link, responses return in the order the requests were accepted, whatever their type.
  A fabric that reaches targets of different latency must restore this order.  `sf_albion_ref_subsystem` shows how: an
  *order queue* records which target each request went to and the merge releases responses in that order; the system test
  exercises the case where an error response is ready before an older memory response and must wait.
* **Sequential execution** (ALP-ORD-02): a target behaves as if it executed accepted requests one at a time in acceptance
  order, so a READ accepted after a WRITE to the same bytes observes the written data.
* **Visibility** (ALP-ORD-03): after a write response is accepted, every later request at that target observes it.
* There is **no ordering guarantee between different links or different initiators**, except what a write response gives.
* **Several targets behind one link.**  Their regions are disjoint, so a request to one target can never observe data of
  another; the only guarantee between them is the response order of ALP-ORD-01 (a response never overtakes an older one).
  Execution of requests to different targets may overlap in time.

## 6. Outstanding requests and tags

* **Limit** (ALP-OUT-01): a request is accepted only when fewer than the link's limit are outstanding at the start of the
  cycle.  The absolute ceiling is 256 (one per tag value).
* **Advertised capacity** (ALP-OUT-02): a target advertises an **upper bound** in its capability word and never accepts
  more; it may back-pressure earlier when response buffers fill.  For `sf_albion_ref_subsystem` the bound is
  `MAX_OUT + 4` (input skid 2 + order queue `MAX_OUT` + output skid 2); the system test asserts it through the link checker
  whenever the initiator's tag pool is larger.
* **Uniqueness** (ALP-TAG-01): an initiator never issues a tag equal to one of its outstanding tags.  A tag is reusable in the
  cycle **after** its response is accepted (never in the same cycle).
* **Echo** (ALP-TAG-02): the response tag equals the tag of the oldest outstanding request.
* **Outstanding bounds of the library components.**  `sf_albion_width_adapter` upsizing: at most `MAX_OUT` requests on its
  wide link and `MAX_OUT + 2` on its narrow link (order queue plus the two-entry response skid); downsizing: one wide
  transaction, i.e. at most `128 / NARROW_W` narrow beats, in flight.  The narrow-link checker
  (`sf_albion_link_checker_narrow`) asserts these bounds in the width-adapter tests.
* `sf_albion_tag_tracker` implements the initiator side: lowest-free allocation, per-tag context, abandon, in-order check.
  **Usage rule.**  `alloc_tag_o` is the lowest free tag *now*; it changes in any cycle in which a tag is freed.  A request that
  is held on a link under back-pressure must keep its tag, so the tag has to be taken (`alloc_valid_i` with `alloc_ready_o`)
  when the request is *created*, e.g. when it is loaded into the register that drives the link, and must not be re-read from
  `alloc_tag_o` later.  Allocating when the link accepts is correct only for a request that is generated in the very cycle in which
  it is accepted.  The system test shows the intended pattern (a staging register).

## 7. Reset and cancellation

* **Reset** (ALP-RST-01/02/03): both ends of a link share one active-low reset, which may be asserted asynchronously and is
  released synchronously ([RESET_CLOCK_CONTRACT.md](RESET_CLOCK_CONTRACT.md)).  While reset is asserted both `valid`
  signals are low.  Reset **abandons every outstanding transaction**: no response is ever generated for a request
  accepted before reset, and the outstanding count is zero afterwards.
* **Accepted requests cannot be recalled** (ALP-CAN-01).  Cancellation is therefore done at the initiator:
  * **Abandon** (ALP-CAN-02): the tracker marks an outstanding tag (or all of them) abandoned.  The tag stays busy until its
    response arrives; the response is then reported with `drop` so the initiator discards it.  An abandon issued in the cycle
    the response arrives is too late and the response is delivered.  A local `CANCELLED` completion for the client can be
    produced with `sf_albion_err_resp` (`status_i = SF_ST_CANCELLED`): it answers every request with `status_i`, except that
    with `CHECK_LEGALITY = 1` (the default) a request that is illegal gets its legality status instead, because legality has
    precedence (ALP-LEG-01); set `CHECK_LEGALITY = 0` to receive `status_i` unconditionally.
  * **Flush** (ALP-CAN-03): a queue *inside* a component may be flushed (`sf_albion_fifo.flush_i`).  A flush is the only event
    that may withdraw a `valid`, and it is never visible on a link because a registered stage separates the queue from the link.
    A flush empties that queue only: entries that were already handed on to a following stage (for example a skid buffer
    behind the FIFO) are not recalled.
  * **Reset** is the hard cancel.
* After a **protocol violation** detected by the tracker (a response for a tag that is not outstanding, or out of order) the
  tracker latches a fatal error, stops allocating and recovers only through reset.

## 8. Legality, error handling and status precedence

A request is **legal** when (checked in this order; the first failure decides the status, ALP-LEG-01):

| # | Condition | Status |
|---|---|---|
| 1 | `op` is READ or WRITE (codes 4..7 are the reserved atomic family: ALP-ATM-01) | `BAD_OPCODE` |
| 2 | `addr[3:0] == 0` (aligned to the link word) | `ALIGN_ERR` |
| 3 | `be != 0` | `BAD_BE` |
| 4 | `attr.rsvd == 0` and `attr.mem_type != 3` | `BAD_ATTR` |
| 5 | `dom != 0xFF` | `ACCESS_DENIED` |

An illegal request is **answered, never dropped**, and never reaches memory.  Legality is evaluated **before** address
decode.  Then, for a legal request (ALP-LEG-02): an address outside every region gives `DECODE_ERR`; a region whose attributes
forbid the access gives `ACCESS_DENIED` (read / write / execute permission, privilege, security level) or `BAD_ATTR` (device region accessed
without the device memory type), in that order; a device-level offset beyond the backed memory gives `DECODE_ERR` again.
The full code list with meanings is in [ERROR_CODES.md](ERROR_CODES.md).

Legality is defined **per link word**: on a link of width *W* the alignment is *W*/8 bytes and `be` has *W*/8 bits.

## 9. Width conversion (ALP-WID-01/02)

`sf_albion_width_adapter` connects links of different data widths (128 <-> 8/16/32/64).  *Down-sizing* splits a wide
transaction into narrow beats (empty beats skipped, one wide transaction in flight, read data reassembled and zeroed on any
error, writes are **not atomic across beats**).  *Up-sizing* maps one narrow transaction onto one wide transaction in its
lane and extracts the lane from the response, keeping responses in order together with locally generated error responses.
Each side applies the legality rules of its own word size and answers illegal requests itself.

Rules that apply to both adapters (ALP-WID-01/02, ALP-TAG-03, ALP-RSP-05/07):

* **Tags.**  The up-sizer passes the tag through.  The down-sizer is the initiator of its narrow link: the tag of a beat is its
  beat index, unique among the beats in flight; the parent's tag is restored on the wide response.
* **Non-conforming responses.**  A response of the target behind an adapter (a beat response for the down-sizer, the wide
  response for the up-sizer) is non-conforming if its tag or operation flag is not the expected one or it is not well-formed
  (ALP-RSP-05).  A non-conforming response is never forwarded: it becomes `PROTOCOL_ERR` with zero data and regenerated
  metadata.  For the down-sizer `PROTOCOL_ERR` wins over every other status of the transaction, whatever the beat order;
  without a non-conforming beat the status of the **first** failing beat is returned, else `OKAY`.
* **Metadata.**  `last = 1`, `poisoned` exactly for `ECC_UNCORR`, `is_write` from the request.  `corrected` is informational and
  independent of the status: the down-sizer returns the OR of the flags of its conforming beats, the up-sizer forwards the
  flag of a conforming wide response; a non-conforming response contributes no flag.
* **Lanes.**  Targets return zero in the lanes that were not enabled (ALP-RSP-07); the adapters rely on it and do not mask.
* **Bounds.**  See section 6.

Details and parameters: [INTERFACE_SPEC.md](INTERFACE_SPEC.md).

## 10. Capability word and versioning

A device advertises one 64-bit `sf_caps_t`: protocol version, widths, tag/domain widths, outstanding bound and a feature
bit map.  Features this version does not implement are **always zero**: atomics (ALP-ATM-01), out-of-order completion, ECC,
poison, domain checking.  The generator computes each profile's word from the package layout
(`tools/albion/build/albion_profile.py`).

**Atomic operations are deliberately not defined.**  Opcodes 4..7 are reserved and rejected.  They may only be introduced
after an atomicity specification exists (single-copy atomicity granule, interaction with width adapters, which split
transactions, exclusive monitors versus AMO operations, ordering and error semantics) and has been formally verified.

Compatibility: a change of the major version may change anything; a minor version only adds code points in unused
space.  Library version 0.1.0 implements ALP 1.0.

## 11. The rules

<!-- BEGIN GEN:CONTRACT_RULES -->
| Rule | Title | Verified by | Statement |
|---|---|---|---|
| `ALP-REQ-01` | Acceptance | checked every cycle by an assertion | A request is accepted in a clock cycle in which req_valid and req_ready are both high. Acceptance is the commit point for ordering and for outstanding-request accounting. |
| `ALP-REQ-02` | Request held until accepted | checked every cycle by an assertion | Once req_valid is raised it stays high, with an unchanged payload, until the request is accepted. Only reset (ALP-RST-01) ends this; the flush of an internal queue (ALP-CAN-03) is never visible on a link. |
| `ALP-REQ-03` | No combinational path from valid to ready | design rule (structural) | No library component has a combinational path from any valid or payload input to a ready output of the same or the opposite channel. Ready may depend on registered state, on flush and on the downstream ready (ready chains), never on valid. |
| `ALP-RSP-01` | Response acceptance | checked every cycle by an assertion | A response is accepted in a cycle in which rsp_valid and rsp_ready are both high. |
| `ALP-RSP-02` | Response held until accepted | checked every cycle by an assertion | Once rsp_valid is raised it stays high, with an unchanged payload, until the response is accepted. |
| `ALP-RSP-03` | No unsolicited response, minimum latency of one cycle | checked every cycle by an assertion | A response never appears unless an earlier accepted request is still unanswered. A response is therefore visible at the earliest one cycle after its request was accepted. |
| `ALP-RSP-04` | Operation echo | checked every cycle by an assertion | meta.is_write of a response equals (op == WRITE) of the request it answers: a read is answered by a read completion, a write by a write completion. |
| `ALP-RSP-05` | Well-formed responses | proved formally and tested | Every response obeys the static format rules: defined status code; meta.last = 1 and reserved bits 0; any non-OKAY status and every write completion carry all-zero data; meta.poisoned is set exactly when status is ECC_UNCORR. |
| `ALP-RSP-07` | Read data only in enabled lanes | checked every cycle by an assertion | The response to a READ carries zero in every byte lane that was not enabled by the request's byte enables. Initiators may rely on this; adapters do not mask the lanes themselves. |
| `ALP-RSP-06` | Response progress independent of request progress | design rule (structural) | An initiator must be able to accept responses without first being able to issue requests: rsp_ready never depends on req_ready. This is what makes the request / response pair deadlock-free. |
| `ALP-ORD-01` | In-order completion | checked every cycle by an assertion | On one link, responses return in the order in which requests were accepted, regardless of operation type. A fabric that reaches several targets must restore this order (see the order queue of sf_albion_ref_subsystem). |
| `ALP-ORD-02` | Sequential execution | self-checking test with a reference model | A target behaves as if it executed accepted requests one at a time in acceptance order: a request observes the effect of every earlier accepted request of the same link. |
| `ALP-ORD-03` | Write completion implies visibility | self-checking test with a reference model | When a write response has been accepted by the initiator, the written data is visible to every request accepted later at that target. Writes are never posted. |
| `ALP-OUT-01` | Outstanding-request limit | checked every cycle by an assertion | The number of accepted-but-unanswered requests on a link never exceeds the link's limit. A request is accepted only when fewer than the limit are outstanding at the start of the cycle. |
| `ALP-OUT-02` | Advertised capacity | self-checking test with a reference model | A target advertises an upper bound on outstanding requests in its capability word and never accepts more; it may back-pressure earlier when its response buffers fill. For sf_albion_ref_subsystem the bound is MAX_OUT + 4. |
| `ALP-TAG-01` | Tag uniqueness | checked every cycle by an assertion | An initiator never issues a request whose tag equals the tag of one of its outstanding requests. A tag becomes reusable in the cycle AFTER its response is accepted. |
| `ALP-TAG-02` | Tag echo | checked every cycle by an assertion | A response carries the tag of the request it answers, unchanged (checked against the oldest outstanding request). |
| `ALP-TAG-03` | Tags are opaque to targets; splitting adapters allocate their own | design rule (structural) | Only the initiator that allocated a tag interprets it. Targets, fabrics and one-to-one adapters copy it unchanged. An adapter that splits one request into several on its master link (the downsizer) is the initiator of that link: it allocates tags there (the beat index, unique among the beats in flight) and restores the parent's tag on the response, so ALP-TAG-01 holds on every link. |
| `ALP-RST-01` | Link-wide reset; valids low in reset | checked every cycle by an assertion | Both ends of a link are reset by the same active-low reset. While reset is asserted req_valid and rsp_valid are low. |
| `ALP-RST-02` | Reset abandons outstanding transactions | checked every cycle by an assertion | Reset discards every outstanding transaction: no response is ever generated for a request accepted before reset, and the outstanding count is zero after reset. A tracker leaves its fatal-error state only through reset. |
| `ALP-RST-03` | Asynchronous assertion, synchronous deassertion | self-checking test with a reference model | Reset may be asserted asynchronously. It is released only synchronously to the clock of its domain (sf_albion_reset_sync): the release happens on a clock edge, a fixed number of edges after the asynchronous input is released. |
| `ALP-CAN-01` | Accepted requests cannot be recalled | design rule (structural) | Once a request is accepted it cannot be withdrawn: the target will produce its response. Cancellation therefore works by abandoning the transaction at the initiator (ALP-CAN-02) or by resetting the link. |
| `ALP-CAN-02` | Abandon | proved formally and tested | An initiator may abandon an outstanding tag (or all of them). The tag stays busy until its response arrives, and the response is then reported as 'drop' so the initiator discards it. Abandoning in the cycle the response arrives is too late: the response is delivered. |
| `ALP-CAN-03` | Flush of internal queues only | proved formally and tested | A queue inside a component may be flushed (sf_albion_fifo flush_i); a flush is the only event that may withdraw a valid, and it is never visible on a link because a registered stage sits between the queue and the link. |
| `ALP-LEG-01` | Request legality and status precedence | proved formally and tested | A request that is not READ or WRITE, is not aligned to the link word, has no byte enable, carries reserved attribute bits, or uses the invalid domain is answered with BAD_OPCODE, ALIGN_ERR, BAD_BE, BAD_ATTR or ACCESS_DENIED respectively, in that precedence order; it never reaches memory. Legality is checked before address decode. |
| `ALP-LEG-02` | Region access check | proved formally and tested | A legal request to a mapped region is checked against the region attributes: read / write / execute permission, privilege, security level (ACCESS_DENIED) and device memory type (BAD_ATTR). |
| `ALP-ATM-01` | No atomic operations | enforced by a build tool | Opcodes 4..7 are reserved for a future atomic family and every reserved opcode is answered with BAD_OPCODE. No atomic semantics may be defined or implemented before an atomicity specification has been written and formally verified; profiles cannot enable the feature. |
| `ALP-WID-01` | Fixed package widths; other widths only through an adapter | enforced by a build tool | The package types are fixed at 64-bit address, 128-bit data, 16-bit byte mask, 8-bit tag and 8-bit domain. A profile that asks for other widths is refused: they need sf_albion_width_adapter or a generated package. |
| `ALP-WID-02` | Width adapter semantics | self-checking test with a reference model | sf_albion_width_adapter converts a link between the 128-bit word and a narrower word of 8, 16, 32 or 64 bits: it splits and merges transactions, skips empty beats, merges beat statuses (first error wins), answers illegal requests itself and keeps responses in order. |
| `ALP-CLK-01` | One functional clock | design rule (structural) | The baseline uses a single functional clock and one active-low asynchronous reset. Every library flip-flop is clocked by the module's clk_i. |
| `ALP-CLK-02` | Clock-domain crossings only through the optional CDC modules | enforced by a build tool | A crossing between clock domains uses sf_albion_cdc_bit_sync (one bit), sf_albion_cdc_pulse (event with acknowledge) or sf_albion_async_fifo (Gray-coded pointers). There is no bare multibit synchroniser. The CDC modules are optional: no baseline module depends on them. |
| `ALP-ADR-01` | Address-map legality | enforced by a build tool | Region sizes are powers of two, bases are aligned to their sizes, regions lie inside the address space and do not overlap each other or a reserved window. The generator refuses to emit an illegal map. |
| `ALP-ADR-02` | One memory map in every language | enforced by a build tool | SystemVerilog, C, Rust and the Python model of a profile's memory map are generated from one source and compared line by line. |
<!-- END GEN:CONTRACT_RULES -->

Kinds: *checked every cycle by an assertion* (`sf_albion_link_checker`, `sf_albion_chan_checker`); *proved formally and
tested* (Yosys + ABC proofs plus simulation); *self-checking test with a reference model*; *enforced by a build tool*;
*design rule (structural)* for rules no tool can observe, where the traceability matrix shows where the RTL realises it.

## 12. What this contract does not claim

* No bursts, no posted writes, no atomics, no coherence, no out-of-order completion, no QoS arbitration (the QoS bits are carried only).
* No per-domain access enforcement and no security guarantee: the domain and security attributes are carried and checked for
  legality; a protection unit is future work.
* No timing, area, power or process-node claim.  Synthesis numbers in the reports are technology-independent gate counts for
  regression only.
* Simulation is cycle-based and two-state (Verilator): metastability is not modelled and X propagation is not observable;
  see the CDC section of [RESET_CLOCK_CONTRACT.md](RESET_CLOCK_CONTRACT.md).
* Formal results are for small parameterisations (the proofs are unbounded in time, bounded in size); larger sizes are covered by simulation.
