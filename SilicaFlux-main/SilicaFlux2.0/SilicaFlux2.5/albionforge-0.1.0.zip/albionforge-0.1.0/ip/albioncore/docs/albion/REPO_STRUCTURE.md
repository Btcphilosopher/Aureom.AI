# Repository structure

```text
albioncore/
  Makefile                      all entry points (make help)
  README.md
  .github/workflows/albion-ci.yml
  include/albion/               generated C / Rust definitions (protocol, memory map)
  rtl/albion/                   core library              <- sf_albion_pkg, fifo, skid, regslice, width_adapter,
    cdc/                        optional CDC modules         tag_tracker, err_resp
    ref/                        reference design             sf_albion_ref_mem / _subsystem / _top
    generated/                  committed generated packages (memory map)
  tools/albion/
    config/                     region catalogue, hardware profiles, manifest, test registry,
                                contract rules, mutation catalogue, legacy-name snapshot
    build/                      generators, checkers, runners (Python 3 + PyYAML only)
  tests/albion/
    common/                     checkers, scoreboards, models, stall generator, sim main
    unit/  system/  cdc/        self-checking testbenches
    formal/                     formal wrappers (Yosys + ABC)
    fixtures/                   inputs that must be REFUSED by the tools
    tools/                      self-tests of the tools (unittest)
  docs/albion/                  documentation; generated/ holds machine-written tables
  reports/albion/               snapshot of the verification reports of the delivered version
  build/                        (created by make) simulation, formal, synthesis, report output
```

## File groups (`tools/albion/config/manifest.yaml`)

Every source file belongs to exactly one group, and `make check` fails if a file is missing from the manifest or a listed file
does not exist (rule D01).  The dependency rules between groups are enforced (D06).

<!-- BEGIN GEN:GROUPS -->
| Group | Role | Files |
|---|---|---|
| core | foundation library (depends only on core) | `rtl/albion/sf_albion_pkg.sv`<br>`rtl/albion/sf_albion_fifo.sv`<br>`rtl/albion/sf_albion_skid.sv`<br>`rtl/albion/sf_albion_regslice.sv`<br>`rtl/albion/sf_albion_width_adapter.sv`<br>`rtl/albion/sf_albion_tag_tracker.sv`<br>`rtl/albion/sf_albion_err_resp.sv` |
| cdc | optional CDC modules (depend only on cdc) | `rtl/albion/cdc/sf_albion_cdc_bit_sync.sv`<br>`rtl/albion/cdc/sf_albion_reset_sync.sv`<br>`rtl/albion/cdc/sf_albion_cdc_pulse.sv`<br>`rtl/albion/cdc/sf_albion_async_fifo.sv` |
| ref | reference design (depends on core) | `rtl/albion/ref/sf_albion_ref_mem.sv`<br>`rtl/albion/ref/sf_albion_ref_subsystem.sv`<br>`rtl/albion/ref/sf_albion_ref_top.sv` |
| generated | committed generated packages | `rtl/albion/generated/sf_albion_memmap_pkg.sv` |
| tb_common | shared verification code | `tests/albion/common/sf_albion_tb_pkg.sv`<br>`tests/albion/common/sf_albion_tb_stall.sv`<br>`tests/albion/common/sf_albion_chan_checker.sv`<br>`tests/albion/common/sf_albion_link_checker.sv`<br>`tests/albion/common/sf_albion_link_checker_narrow.sv`<br>`tests/albion/common/sf_albion_stream_scoreboard.sv`<br>`tests/albion/common/sf_albion_tb_stage_harness.sv`<br>`tests/albion/common/sf_albion_tb_stage_sweep.sv`<br>`tests/albion/common/sf_albion_tb_wa_nar_mem.sv`<br>`tests/albion/common/sf_albion_tb_wa_case.sv`<br>`tests/albion/common/sf_albion_tb_err_case.sv`<br>`tests/albion/common/sf_albion_tb_trk_case.sv` |
| tests | testbenches and formal wrappers | `tests/albion/unit/tb_sf_albion_pkg.sv`<br>`tests/albion/unit/tb_sf_albion_fifo.sv`<br>`tests/albion/unit/tb_sf_albion_skid.sv`<br>`tests/albion/unit/tb_sf_albion_regslice.sv`<br>`tests/albion/unit/tb_sf_albion_tag_tracker.sv`<br>`tests/albion/unit/tb_sf_albion_err_resp.sv`<br>`tests/albion/unit/tb_sf_albion_width_adapter.sv`<br>`tests/albion/unit/tb_sf_albion_memmap.sv`<br>`tests/albion/system/tb_sf_albion_system.sv`<br>`tests/albion/system/sf_albion_tb_sys_case.sv`<br>`tests/albion/cdc/tb_sf_albion_cdc.sv`<br>`tests/albion/formal/fv_sf_albion_pkg_funcs.sv`<br>`tests/albion/formal/fv_sf_albion_fifo.sv`<br>`tests/albion/formal/fv_sf_albion_regslice.sv`<br>`tests/albion/formal/fv_sf_albion_tag_tracker.sv`<br>`tests/albion/formal/fv_sf_albion_err_resp.sv` |
<!-- END GEN:GROUPS -->

## Overlaying onto the SilicaFlux repository

All paths are namespaced under `albion` (`rtl/albion`, `tools/albion`, `tests/albion`, `docs/albion`, `include/albion`), so the
contents of the zip can be copied onto a repository root without overwriting anything.  The only top-level items are `Makefile`,
`README.md` and `.github/workflows/albion-ci.yml`; rename or merge them if the target repository already has files of those
names.  AlbionCore has **no dependency** on any SilicaFlux file; the relation to the existing IP is described in
[REPO_AUDIT.md](REPO_AUDIT.md).
