# Memory map

The memory map is a **configurable catalogue of regions** with a generator that refuses illegal maps and emits matching
SystemVerilog, C, Rust and Markdown.  Source of truth: [`tools/albion/config/regions.yaml`](../../tools/albion/config/regions.yaml);
each hardware profile enables and sizes regions (`tools/albion/config/albion_*.yaml`).

## 1. Rules (enforced by `gen_memmap.py`, ALP-ADR-01)

| Rule | Error code |
|---|---|
| region names are unique `lower_snake_case` | `E_NAME_DUP`, `E_NAME_FMT` |
| sizes are powers of two and at least `min_region_bytes` (4 KiB) | `E_SIZE_POW2`, `E_SIZE_MIN` |
| the base is **aligned to the size**, so every region decodes with one base/mask compare (`(addr & mask) == base`) | `E_ALIGN` |
| `base + size` fits the 64-bit address space | `E_RANGE` |
| **enabled regions never overlap each other** | `E_OVERLAP` |
| enabled regions never overlap a **reserved** window | `E_RESERVED` |
| attribute and address-space names are known | `E_ATTR`, `E_ASID` |
| profile enables only catalogue regions; `sram` must be enabled for the reference design | `E_PROFILE` |

The generator reports **all** collisions with names and ranges and writes nothing when the map is illegal.  The decision is tested three ways:
fixtures with one defect each, a randomised comparison with a page-granular brute-force oracle (4,000 random maps), and an independent
overlap check in SystemVerilog (`tb_sf_albion_memmap`).  Python, the generated C table, the generated Rust table and the SystemVerilog
constants of every profile are compared line by line (`check_memmap_xlang.py`, ALP-ADR-02).

## 2. The full catalogue

All regions enabled, default sizes.  Addresses are device-side 64-bit addresses.  The **low 4 GiB are reserved** for a future SFB2
bridge: the existing SilicaFlux SoCs use mutually inconsistent 32-bit windows (for example `0x2000_0000` is the tile scratchpad in
SilicaFlux-V + DataFabric, the ControlCore *device window* in ControlCore and the local SRAM window in CloudDPU; see
[REPO_AUDIT.md](REPO_AUDIT.md)), so the new map does not pretend to be compatible with any of them.

<!-- BEGIN GEN:MEMMAP_FULL -->
Profile: **full catalogue (all regions enabled)** -- 64-bit address space

| # | Region | Base | Last byte | Size | Space | Attributes | State | Owner |
|---|---|---|---|---|---|---|---|---|
| 0 | `controlcore` | `0x0000000100000000` | `0x000000010FFFFFFF` | 256 MiB | device | `rwxp-- normal_nc` | enabled | SilicaFlux ControlCore (Project 21): boot ROM, IMEM, DMEM, peripheral pages |
| 1 | `sram` | `0x0000000110000000` | `0x000000011FFFFFFF` | 256 MiB | device | `rwx--c normal_wb` | enabled | SilicaFlux SRAM Wrapper Library / MemoryCore: shared device SRAM |
| 2 | `dma` | `0x0000000120000000` | `0x00000001200FFFFF` | 1 MiB | config | `rw-p-- device` | enabled | SilicaFlux CloudDMA (Project 64) / DataFabric DMA: descriptor and control registers |
| 3 | `network` | `0x0000000130000000` | `0x0000000130FFFFFF` | 16 MiB | config | `rw---- device` | enabled | SilicaFlux PacketCore (Project 62): queue and offload registers |
| 4 | `virtio` | `0x0000000140000000` | `0x0000000140FFFFFF` | 16 MiB | config | `rw---- device` | enabled | SilicaFlux VirtualIO (Project 63): virtio device windows |
| 5 | `tensor_vector` | `0x0000000150000000` | `0x000000015FFFFFFF` | 256 MiB | device | `rw---- normal_nc` | enabled | SilicaFlux TensorCore / HPC vector engines: command registers and tile scratchpads |
| 6 | `security` | `0x0000000160000000` | `0x00000001600FFFFF` | 1 MiB | secure | `rw-ps- device` | enabled | SilicaFlux SecureStore (Project 59) / SecureBoot: key and policy registers |
| 7 | `perf` | `0x0000000170000000` | `0x00000001700FFFFF` | 1 MiB | config | `rw-p-- device` | enabled | SilicaFlux performance counters (HPC Module 07) |
| 8 | `extmem` | `0x0000004000000000` | `0x0000007FFFFFFFFF` | 256 GiB | external | `rwx--c normal_wb` | enabled | external-memory adapters (ExtMem bridge Project 24, HBMCore): off-chip memory window |

Reserved windows (no region may overlap):

- `legacy_sfb2`: `0x0000000000000000` .. `0x00000000FFFFFFFF` (4 GiB) -- reserved for a future SFB2 -> ALP bridge; no Albion region may overlap it

Attribute key: r read, w write, x execute, p privileged-only, s secure-only, c cacheable.
<!-- END GEN:MEMMAP_FULL -->

Region contents (the sub-layout of each region is owned by the module behind it):

| Region | Intended owner |
|---|---|
| `controlcore` | ControlCore: boot ROM, instruction / data SRAM, peripheral pages |
| `sram` | shared device SRAM (SRAM Wrapper Library / MemoryCore); served by `sf_albion_ref_subsystem` in the reference design |
| `dma` | descriptor and control registers of the DMA engines |
| `network` | packet-engine queue and offload registers |
| `virtio` | virtio device windows |
| `tensor_vector` | tensor / vector engine command registers and tile scratchpads |
| `security` | key and policy registers (secure, privileged only) |
| `perf` | performance counters |
| `extmem` | off-chip memory through the external-memory adapters |

## 3. Attributes and address spaces

Each region carries an `sf_region_attr_t` word (read, write, execute, privileged-only, secure-only, cacheable, memory type) and an
address-space id (`device`, `config`, `external`, `host`, `secure`).  `sf_albion_pkg::sf_access_check_bits` applies the attributes to a
request (see [ARCHITECTURE_CONTRACT.md](ARCHITECTURE_CONTRACT.md) section 8).  The attribute word of every region is part of the generated
constants (`SF_MM_<REGION>_ATTR`).

## 4. Profiles

<!-- BEGIN GEN:MEMMAP_PROFILES -->
#### Profile `cloud`

| Region | Base | Size | Space | Attributes |
|---|---|---|---|---|
| controlcore | 0x0000000100000000 | 256 MiB | device | `rwxp-- normal_nc` |
| sram | 0x0000000110000000 | 1 MiB | device | `rwx--c normal_wb` |
| dma | 0x0000000120000000 | 1 MiB | config | `rw-p-- device` |
| network | 0x0000000130000000 | 16 MiB | config | `rw---- device` |
| virtio | 0x0000000140000000 | 16 MiB | config | `rw---- device` |
| security | 0x0000000160000000 | 1 MiB | secure | `rw-ps- device` |
| perf | 0x0000000170000000 | 1 MiB | config | `rw-p-- device` |
| extmem | 0x0000004000000000 | 256 GiB | external | `rwx--c normal_wb` |

Disabled: `tensor_vector`.

#### Profile `hpc`

| Region | Base | Size | Space | Attributes |
|---|---|---|---|---|
| controlcore | 0x0000000100000000 | 256 MiB | device | `rwxp-- normal_nc` |
| sram | 0x0000000110000000 | 16 MiB | device | `rwx--c normal_wb` |
| dma | 0x0000000120000000 | 1 MiB | config | `rw-p-- device` |
| tensor_vector | 0x0000000150000000 | 256 MiB | device | `rw---- normal_nc` |
| perf | 0x0000000170000000 | 1 MiB | config | `rw-p-- device` |
| extmem | 0x0000004000000000 | 256 GiB | external | `rwx--c normal_wb` |

Disabled: `network`, `virtio`, `security`.

#### Profile `min`

| Region | Base | Size | Space | Attributes |
|---|---|---|---|---|
| controlcore | 0x0000000100000000 | 64 KiB | device | `rwxp-- normal_nc` |
| sram | 0x0000000110000000 | 64 KiB | device | `rwx--c normal_wb` |
| perf | 0x0000000170000000 | 4 KiB | config | `rw-p-- device` |

Disabled: `dma`, `network`, `virtio`, `tensor_vector`, `security`, `extmem`.
<!-- END GEN:MEMMAP_PROFILES -->

## 5. Using the map

SystemVerilog (generated per profile in `build/gen/<profile>/`, committed for the full catalogue):

```systemverilog
// base/mask decode of one region
if ((addr & sf_albion_memmap_pkg::SF_MM_SRAM_MASK) == sf_albion_memmap_pkg::SF_MM_SRAM_BASE) ...
// vectors for a generic decoder: entry i at [i*64 +: 64]
sf_albion_memmap_pkg::SF_MM_BASES, SF_MM_MASKS, SF_MM_SIZES, SF_MM_ATTRS, SF_MM_ASIDS, SF_MM_ENABLED
```

C and Rust:

```c
#include "albion_memmap.h"
const struct albion_region *r = albion_region_lookup(addr);   /* NULL if unmapped or disabled */
```

```rust
#[path = "albion_memmap.rs"] mod mm;
let r = mm::lookup(addr);          // Option<&Region>
```

## 5.1 Adding or moving a region

Edit `regions.yaml`, run `make gen check`; if the new region collides, the generator names the regions and ranges involved and refuses to write
anything.  Never edit a generated file: `make check` fails if one is stale.
