# Verification

Principle from the brief: **test the foundational libraries before allowing dependent projects to use them.**  Nothing here is
a claim of silicon readiness; every statement below is backed by a command in [BUILD.md](BUILD.md) and a file in `reports/albion/`.

## 1. Strategy

| Layer | What it gives | Where |
|---|---|---|
| **Protocol checker** | the ALP contract as immediate assertions on every cycle of every system simulation; the *same module* is used as `assume`/`assert` in formal proofs; a flat-port twin checks every narrow link of the width-adapter tests (tag uniqueness, outstanding bound, legality, response order, lane rule) | `tests/albion/common/sf_albion_{chan,link}_checker.sv`, `sf_albion_link_checker_narrow.sv` |
| **Independent reference models** | each response is compared field by field with a model written separately from the RTL: a behavioural memory + legality rules in the system test; a beat-level model with fault injection for the width adapter; a cycle-accurate model for the tag tracker; a restated legality/format rule set for the package; an independent Python implementation (vectors) | `tests/albion/common/*`, `tools/albion/build/gen_vectors.py` |
| **Scoreboards** | in-order, loss-free, duplicate-free comparison for stages; transaction scoreboard with an expected-response queue for links | `sf_albion_stream_scoreboard.sv`, `tb_sf_albion_system.sv` |
| **Random back-pressure** | every source/sink regime (always, 50 %, 10 %, 90 %, bursty, long stalls, alternating) on **both** sides, 49 combinations per stage, plus directed fill, exhaustion and drain | `sf_albion_tb_stall.sv`, `sf_albion_tb_stage_sweep.sv` |
| **Directed protocol tests** | reset state, full throughput, fill to capacity, tag exhaustion, abandon, fatal-error recovery, asynchronous reset in the middle of traffic | each testbench |
| **Formal proofs** | **unbounded** proofs (ABC property-directed reachability) of FIFO, skid, all register-slice modes, tag tracker (well-behaved and arbitrary environment) and error responder, and equality of the Yosys-elaborated package functions with an independent reference for *all* inputs; cover points show the proofs are not vacuous | `tests/albion/formal/`, `tools/albion/build/formal.py` |
| **Mutation campaign** | injected bugs across every module (the count and the score of the delivered version are in section 4); each must be rejected by at least one simulation or proof | `tools/albion/config/mutations.yaml`, `mutate.py` |
| **Coverage** | functional-coverage bins printed by the testbenches with **goals that fail the build**; Verilator line coverage of the RTL merged over all simulations | `cover_goals` in `tests.yaml`, `report.py` |
| **Traceability** | every contract rule -> checker / test / proof / tool; evidence tokens verified present | `contract_trace.py`, [TRACEABILITY.md](generated/TRACEABILITY.md) |
| **Tool self-tests** | the checkers are themselves tested with inputs they must refuse (style fixtures, dependency violations, malformed maps and profiles, a brute-force overlap oracle) | `tests/albion/tools/test_tools.py` |

## 2. What is verified where

<!-- BEGIN GEN:TEST_INVENTORY -->
| Simulation | Group | Profiles | What it covers |
|---|---|---|---|
| `tb_sf_albion_pkg` | unit | - | package types, layouts, code points, legality / access / well-formedness functions vs three implementations |
| `tb_sf_albion_fifo` | unit | - | FIFO, 8 configurations (depth 1..16, width 1..236), 49 back-pressure regimes, flush, async reset |
| `tb_sf_albion_skid` | unit | - | skid buffer, 4 widths, 49 regimes, async reset |
| `tb_sf_albion_regslice` | unit | - | register slice, all 4 modes, 8 configurations |
| `tb_sf_albion_tag_tracker` | unit | - | tag tracker vs cycle-accurate model, 9 configurations, injected faults |
| `tb_sf_albion_err_resp` | unit | - | error responder, 4 configurations, all 16 status inputs |
| `tb_sf_albion_width_adapter` | unit | - | width adapter: down / up / chain, widths 8..64, fault-injecting narrow memory |
| `tb_sf_albion_cdc` | cdc | - | reset synchroniser, bit / pulse crossings, async FIFO over unrelated clocks |
| `tb_sf_albion_memmap` | unit | per profile | generated memory map: SV self-check and dump compared with C / Rust / Python |
| `tb_sf_albion_system` | system | per profile | randomised ALP traffic through tracker + decode + memory + error target + ordering merge |
<!-- END GEN:TEST_INVENTORY -->

Formal jobs:

<!-- BEGIN GEN:FORMAL_JOBS -->
| Job | Wrapper | Parameters | Cover points that must be reachable | Must be unreachable |
|---|---|---|---|---|
| `pkg_funcs` | `fv_sf_albion_pkg_funcs` | - | - | - |
| `fifo_w2_d1` | `fv_sf_albion_fifo` | WIDTH=2, DEPTH=1 | 0,2,3,5 | 1,4 |
| `fifo_w2_d2` | `fv_sf_albion_fifo` | WIDTH=2, DEPTH=2 | 0,1,2,3,4,5 | - |
| `fifo_w2_d3` | `fv_sf_albion_fifo` | WIDTH=2, DEPTH=3 | 0,1,2,3,4,5 | - |
| `fifo_w2_d4` | `fv_sf_albion_fifo` | WIDTH=2, DEPTH=4 | 0,1,2,3,4,5 | - |
| `skid` | `fv_sf_albion_regslice` | KIND=1 | 0,1,3,4 | - |
| `regslice_bypass` | `fv_sf_albion_regslice` | MODE=0 | 1,2,3,4 | - |
| `regslice_fwd` | `fv_sf_albion_regslice` | MODE=1 | 0,1,3,4 | - |
| `regslice_bwd` | `fv_sf_albion_regslice` | MODE=2 | 0,1,2,3,4 | - |
| `regslice_full` | `fv_sf_albion_regslice` | MODE=3 | 0,1,3,4 | - |
| `tracker_ordered` | `fv_sf_albion_tag_tracker` | NUM_TAGS=3, CTX_W=2, CHECK_ORDER=1, WELL=1 | 0,1,2,3 | - |
| `tracker_unordered` | `fv_sf_albion_tag_tracker` | NUM_TAGS=3, CTX_W=2, CHECK_ORDER=0, WELL=1 | 0,1,2,3 | - |
| `tracker_1tag` | `fv_sf_albion_tag_tracker` | NUM_TAGS=1, CTX_W=1, CHECK_ORDER=1, WELL=1 | - | - |
| `tracker_4tag` | `fv_sf_albion_tag_tracker` | NUM_TAGS=4, CTX_W=1, CHECK_ORDER=1, WELL=1 | - | - |
| `tracker_arbitrary_env` | `fv_sf_albion_tag_tracker` | NUM_TAGS=3, CTX_W=2, CHECK_ORDER=0, WELL=0 | 4,5 | - |
| `err_resp_d1` | `fv_sf_albion_err_resp` | DEPTH=1, CHECK_LEGALITY=1 | - | - |
| `err_resp_d2` | `fv_sf_albion_err_resp` | DEPTH=2, CHECK_LEGALITY=1 | 0,1,2,3 | - |
| `err_resp_d2_nolegal` | `fv_sf_albion_err_resp` | DEPTH=2, CHECK_LEGALITY=0 | - | - |
<!-- END GEN:FORMAL_JOBS -->

How to read a formal result: a job passes only when ABC reports **"Property proved"** (an unbounded proof of every assertion in the wrapper, for all
input sequences the assumptions allow) **and** every listed cover point behaves as specified: *reachable* points show a witness trace exists (so the proof
is not vacuous); *unreachable* points are confirmed by exhaustive state-space exploration or by an unbounded proof, or, if neither completes, by a
bounded search of `cover_depth` frames (the report says which).  A timeout is a failure.  The proofs use small parameterisations (for example a 3-entry FIFO
with 2-bit data, a 3-tag tracker) with a symbolic "watch item": the property is proved for an arbitrary item, hence for any data value and any position.  Larger sizes
are covered by simulation.

### Environment assumptions in the proofs

Pass-through stages (bypass and backward register slices) forward `in_valid` / `in_data` combinationally, so their output stability only holds if the *initiator*
obeys the contract; the proof therefore **assumes ALP-REQ-02 and ALP-RST-01 on the input** (the same checker in `ASSUME_MODE`).  The tag tracker is proved
twice: once against any environment that returns only outstanding tags in order, and once against an **arbitrary** environment (spurious, duplicate and
out-of-order frees, abandons of any tag).  The error responder is proved against any initiator that obeys the request-side rules.

## 3. Findings made while verifying (all fixed or documented)

* **Yosys 0.33 resolves identifiers of a package function in the caller's scope**: an unqualified enum member in a package function became an undriven wire.
  Verilator was fine.  Fixed by qualifying every package item inside function bodies, and guarded by a formal equivalence proof of the elaborated functions plus
  the lint/synth rule that fails on "implicitly declared" / "has no driver".
* The width adapter's downsizer first inferred a **latch** in Yosys (a temporary assigned only in a branch); found by the Yosys elaboration check, not by Verilator.
* Several **testbench** faults were found and fixed by the checkers themselves: simulation races between blocking updates at the clock edge and DUT inputs, a
  reset initialised low producing no asynchronous event, "never-ready" stimulus modes included in sweeps, and over-strong expectations (tag exhaustion when the tag
  pool is larger than the target's capacity).
* A `MODE`-0 register slice left `clk_i`/`rst_ni` unused (lint); made explicit.
* The error responder passed undefined status codes (12..15) through; it now clamps them to `TARGET_ERR` so it can never emit an ill-formed response.
* The advertised outstanding capacity of the reference subsystem was measured (not assumed): the provable upper bound is `MAX_OUT + 4`, which the system test asserts.

### Findings of the mutation campaign and of the independent review

A first campaign over 53 mutants **killed 49 and let 4 survive** (`wa_first_error`, `sub_access`, `sub_bound`, `sub_decode_legal`).  An independent
adversarial review of the whole tree, which did not see the campaign, found no functional RTL bug but reported the same blind spots and several contract
problems.  All of them were turned into changes, tests or documentation:

| Finding | Kind | Resolution |
|---|---|---|
| The down-sizer sent all beats of one wide request with the **same tag** on the narrow link (ALP-TAG-01 broken there); the link checker only watched the wide link | contract / RTL | the narrow tag is now the beat index; `sf_albion_link_checker_narrow` asserts tag uniqueness, the outstanding bound, request legality and response order on every narrow link; rule ALP-TAG-03 rewritten |
| The region **access check** was never exercised: all profiles use one attribute word under which it cannot fail (mutants `sub_access`, `sub_bound` survived) | test gap | `tb_sf_albion_system` runs the profile plus eight region-attribute cases with boundary-targeted addresses; new bins count access denials, device-type failures and requests where the decode error must win over the access error |
| The decode repeated the legality check that both targets already perform (mutant `sub_decode_legal` could not be distinguished: an equivalent mutant) | redundancy | removed from `sf_albion_ref_subsystem`; legality precedence is provided by the targets (mutant `sub_err_legal` covers it); the always-true lower-bound compare was removed too |
| Width-adapter **protocol-error and metadata paths had no stimulus**: seven independent mutations survived together; the narrow target never misbehaved, the wide target was always conforming, addresses stayed below 8 KiB, at most 6 beats were ever in flight | test gap | the narrow memory injects 7 kinds of response violation and `corrected` flags on error beats; a shim does the same for the wide target; addresses cover all 64 bits; up to 24 beats can be outstanding; 12 new mutants cover the paths |
| Status and metadata semantics of the adapters were undefined and inconsistent (a wrong tag after an ordinary error was hidden; `corrected` merged from error beats; the up-sizer forwarded ill-formed wide responses) | contract / RTL | defined in ARCHITECTURE_CONTRACT section 9: `PROTOCOL_ERR` wins, first failing beat otherwise, `corrected` from conforming responses only; the up-sizer now replaces any non-conforming wide response |
| "Read data is zero in lanes that were not enabled" was stated but checked nowhere | contract | new rule ALP-RSP-07, asserted by both link checkers; the redundant lane mask of the down-sizer was removed |
| `alloc_tag_o` of the tag tracker changes when a tag is freed, so allocating when a held request is accepted is wrong | usage hazard | usage rule documented (ARCHITECTURE_CONTRACT section 6, tracker header) |
| CDC constraint advice (false path) was unsafe for the Gray-coded pointer bus; reset sequencing of the CDC modules not enforceable | documentation | RESET_CLOCK_CONTRACT rewritten: bus-skew / max-delay constraints, one-sided reset is outside the contract, not detected and not tested |
| "Every buffering testbench resets in the middle of traffic" was not true for the error responder and the tag tracker | test gap | both testbenches now reset asynchronously in the middle of traffic (coverage goals added) |
| Other claims that were too strong: "drifting phases" (not the 10:10 CDC cases), "CANCELLED from the error responder" (not for illegal requests), the bounds of the up-sizer | documentation | corrected |

## 4. Results of the delivered version

Produced by `make ci` and `make mutate` in a **clean unpacked copy of the delivered zip** (4 cores; `make ci` took about 10 minutes, `make mutate` about 55).
The full reports are in `reports/albion/` (`summary.md`, `coverage.md`, `junit.xml`, `mutation_summary.json`).

| Item | Result |
|---|---|
| Static gates (style 17 rules, dependencies / layering, parameters, generated files, traceability of 33 contract rules, 35 tool self-tests) | all pass |
| Lint (Verilator -Wall and Yosys elaboration) | 40 jobs, all clean |
| Simulations | 14 runs (system test on 3 profiles), **all pass**, 20,530,514 checks, 0 errors |
| Functional-coverage goals | 55 goals, all met |
| Line coverage of the RTL (Verilator, merged over the 14 simulations) | **99.5 %** (570 of 573 lines); the 3 uncovered lines are in `sf_albion_ref_subsystem.sv` (1) and `sf_albion_width_adapter.sv` (2) and are listed in `coverage.md` |
| Formal | 18 jobs: unbounded proofs (ABC PDR) and cover checks, all pass |
| Synthesis (generic Yosys) | 17 targets, 0 latches; profile budgets met (min 5,444 cells / 2,656 flops, cloud 37,600 / 18,624, hpc 70,699 / 35,020) |
| Mutation campaign | **67 mutants: 67 killed, 0 survived, 0 invalid** (100 %) |

The mutation score of 100 % is the result **after** the fixes listed in section 3: the first campaign killed 49 of 53 mutants.  Synthesis figures are
technology-independent gate counts for regression, not area, timing or power.

## 5. Limitations (honest scope)

* **Simulation**: Verilator is two-state and cycle-based; X propagation and metastability are not observable.  Reset-value coverage relies on randomised initial values
  (`randReset(2)`) which expose missing resets, but is not a substitute for a four-state run.
* **Formal**: proofs are on small parameterisations and are single-clock; the CDC modules, the width adapters, `sf_albion_ref_mem` and the reference subsystem
  are verified by simulation only.  The proof flow replaces uninitialised storage by zero (`setundef -zero`), so a missing reset of a register that is read before
  it is written would not be found by the proofs (simulation randomises initial values for that).  The tracker's arbitrary-environment proof is run without the
  order check (`CHECK_ORDER = 0`); the order check is covered by the ordered proof for well-behaved environments and by simulation.
* **Combinational independence** (no `ready` output depends on an input): proved for FIFO, skid and register slices by the formal jobs; for the other modules it was
  checked structurally by a one-off Yosys cone-of-influence script during review (not part of `make ci`).
* **Coverage** is line and functional-bin coverage; toggle coverage is collected by Verilator but not gated.  100 % line coverage is not claimed: uncovered lines are listed in
  `coverage.md` (defensive parameter checks and unused branches of parameter variants).
* **Mutation score** measures the detection power of *these* tests against *these* mutants; it is evidence, not a guarantee.
* **Not verified**: timing, area, power, physical design, DFT, any foundry or FPGA flow, interoperability with the legacy SFB2 / `sram_if` / NoC protocols (no bridge exists yet).
