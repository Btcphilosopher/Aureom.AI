# Dependency manifest

## 1. External tools

| Tool | Version used | Needed for | Required |
|---|---|---|---|
| GNU make | 4.3 | entry points | yes |
| Python 3 | 3.13 (>= 3.8) | generators, checkers, runners | yes |
| PyYAML | 6.0 | configuration files | yes (`python3-yaml`) |
| Verilator | 5.020 (>= 5.0) | lint (`-Wall`), simulation with `--timing`, coverage | yes |
| Yosys | 0.33 | elaboration checks, generic synthesis, formal front end | yes |
| `yosys-abc` (ABC, shipped with Yosys) | 0.33 | unbounded proofs (`pdr`), cover search (`bmc3`) | yes |
| C compiler | gcc 13 (C11) | generated C header check, memory-map cross-language test | yes |
| rustc | 1.97 (edition 2021) | generated Rust definitions check | optional |
| Icarus Verilog | 12 | not used by the flow (second-simulator experiments only) | no |
| z3 / SymbiYosys | - | **not used**: z3-based BMC proved too slow, and SymbiYosys is not in the distribution; ABC covers proofs and covers | no |

No proprietary tool, PDK, licence, container image or network access is required.  The versions match those already used by
the existing SilicaFlux projects (DataFabric: Verilator 5.020, Icarus 12, Yosys 0.33), so Albion adds no new tool to the repository's flows.

## 2. Python modules

Standard library plus **PyYAML** only.  The build tools never execute design code and never `eval` configuration text
(constant expressions of the package are evaluated by a restricted evaluator).

## 3. Internal dependencies (derived from the sources)

`check_deps.py` derives these from the sources and fails the build on a cycle, an undefined module, or a layering violation
(core -> only core; cdc -> only cdc; ref -> core; nothing depends on tests).

<!-- BEGIN GEN:DEP_GRAPH -->
| Module / package | Group | Depends on |
|---|---|---|
| `sf_albion_async_fifo` | cdc | `sf_albion_cdc_bit_sync` |
| `sf_albion_cdc_bit_sync` | cdc | - |
| `sf_albion_cdc_pulse` | cdc | `sf_albion_cdc_bit_sync` |
| `sf_albion_err_resp` | core | `sf_albion_fifo`, `sf_albion_pkg` |
| `sf_albion_fifo` | core | - |
| `sf_albion_memmap_pkg` | generated | - |
| `sf_albion_pkg` | core | - |
| `sf_albion_ref_mem` | ref | `sf_albion_fifo`, `sf_albion_pkg`, `sf_albion_skid` |
| `sf_albion_ref_subsystem` | ref | `sf_albion_err_resp`, `sf_albion_fifo`, `sf_albion_pkg`, `sf_albion_ref_mem`, `sf_albion_skid` |
| `sf_albion_ref_top` | ref | `sf_albion_pkg`, `sf_albion_ref_subsystem` |
| `sf_albion_regslice` | core | `sf_albion_skid` |
| `sf_albion_reset_sync` | cdc | - |
| `sf_albion_skid` | core | - |
| `sf_albion_tag_tracker` | core | `sf_albion_fifo`, `sf_albion_pkg` |
| `sf_albion_width_adapter` | core | `sf_albion_fifo`, `sf_albion_pkg`, `sf_albion_skid` |

```mermaid
graph LR
  sf_albion_async_fifo --> sf_albion_cdc_bit_sync
  sf_albion_cdc_pulse --> sf_albion_cdc_bit_sync
  sf_albion_err_resp --> sf_albion_fifo
  sf_albion_err_resp --> sf_albion_pkg
  sf_albion_ref_mem --> sf_albion_fifo
  sf_albion_ref_mem --> sf_albion_pkg
  sf_albion_ref_mem --> sf_albion_skid
  sf_albion_ref_subsystem --> sf_albion_err_resp
  sf_albion_ref_subsystem --> sf_albion_fifo
  sf_albion_ref_subsystem --> sf_albion_pkg
  sf_albion_ref_subsystem --> sf_albion_ref_mem
  sf_albion_ref_subsystem --> sf_albion_skid
  sf_albion_ref_top --> sf_albion_pkg
  sf_albion_ref_top --> sf_albion_ref_subsystem
  sf_albion_regslice --> sf_albion_skid
  sf_albion_tag_tracker --> sf_albion_fifo
  sf_albion_tag_tracker --> sf_albion_pkg
  sf_albion_width_adapter --> sf_albion_fifo
  sf_albion_width_adapter --> sf_albion_pkg
  sf_albion_width_adapter --> sf_albion_skid
```
<!-- END GEN:DEP_GRAPH -->

## 4. Relation to the existing SilicaFlux IP

AlbionCore **depends on nothing** from `SilicaFlux-main/` and modifies nothing in it.  The audit found 1,697 unit names in
the existing archives; `tools/albion/config/legacy_names.txt` snapshots them and `check_deps.py` refuses any Albion
definition that reuses one (rule D07).  Integration points (bridges to SFB2, `sram_if` and the NoC) are listed as
**missing dependencies** in [REPO_AUDIT.md](REPO_AUDIT.md); they are future work, not hidden requirements.

## 5. Generated files and how they stay current

| Generated file | Source | Staleness check |
|---|---|---|
| `include/albion/albion_proto.{h,rs}`, `docs/albion/generated/PROTOCOL_TABLES.md` | `rtl/albion/sf_albion_pkg.sv` | `gen_proto.py --check` |
| `rtl/albion/generated/sf_albion_memmap_pkg.sv`, `include/albion/albion_memmap.{h,rs}`, `MEMORY_MAP_FULL.md` | `tools/albion/config/regions.yaml` | `gen_memmap.py --check` |
| `build/gen/<profile>/*` (configuration package, per-profile map) | profile + catalogue | regenerated on demand |
| `docs/albion/generated/CONTRACT_RULES.md`, `TRACEABILITY.md` | `contract_rules.yaml` | `contract_trace.py --check` |
| generated regions inside `docs/albion/*.md` | RTL headers, configs | `gen_docs.py --check` |
