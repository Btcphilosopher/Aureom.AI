# Clock and reset contract

## 1. Clock

* The baseline uses **one functional clock** (`clk_i`).  Every library flip-flop is clocked by its module's `clk_i` on the
  rising edge (rule ALP-CLK-01; enforced for sequential blocks by style rule S10).
* Clock gating, multiple functional clocks and DVFS are **not** part of the foundation.  Where a design needs more than one
  clock, the crossing goes through the optional CDC modules of section 4 (ALP-CLK-02), which no baseline module depends on
  (dependency rule D06, `make check`).
* No process node, frequency or timing figure is assumed anywhere in the library.

## 2. Reset convention

| Property | Rule |
|---|---|
| Polarity and name | **active low**; input `rst_ni` (a second domain uses a prefix: `wr_rst_ni`, `dst_rst_ni`) |
| Assertion | **asynchronous**: every control flip-flop is `always_ff @(posedge clk_i or negedge rst_ni)` |
| Deassertion | **synchronous** to the clock of the domain; the reset that reaches a domain is the output of `sf_albion_reset_sync` unless the surrounding system already guarantees it |
| Scope | one reset per clock domain; both ends of a link are reset together (ALP-RST-01) |
| Reset values | all `valid` outputs low; occupancy, pointers, counters and state machines at their idle state |
| Datapath storage | **not reset** (FIFO memories, skid data registers, adapter payload registers).  Data outputs are meaningful only while the matching `valid` is high |
| Outputs during reset | every `valid` is low; `ready` outputs are unconstrained |
| Effect on transactions | reset **abandons** all outstanding transactions; no response is produced for them afterwards (ALP-RST-02) |
| Memory contents | `sf_albion_ref_mem` clears itself after reset (`INIT_ZERO = 1`) and refuses requests until done (`WORDS` cycles, at most the memory depth: the unavailability after reset is bounded by the memory size, not by the protocol); **a write accepted before a reset does not persist** (the array is cleared), other storage keeps stale data that is never exposed |
| Reset of a part of a system | Resetting one component while its link partner keeps running is outside the contract: the partner's outstanding transactions get no response (ALP-RST-02) and an initiator must be reset together with its target.  Within one clock domain the whole transaction path (initiator, adapters, fabric, target) is reset together |

Why asynchronous assertion with synchronous release: assertion must be immediate and independent of a possibly stopped
clock; release must not violate the recovery/removal time of flip-flops that see the clock, so it is aligned to a clock edge.

```text
arst_ni  ``````\__________________/`````````````````
clk_i    _|`|_|`|_|`|_|`|_|`|_|`|_|`|_|`|_|`|_|`|_|`|_
rst_no   ``````\_______________________/````````````   falls immediately; rises on a clock edge,
                                       ^               STAGES edges after arst_ni was released
```

### Reset checks

* `a_alp_rst_01_*` / `a_alp_rst_02` in `sf_albion_link_checker` check, on every cycle of every system simulation, that the
  valids are low in reset and that the outstanding count is zero after it.
* Every buffering or stateful testbench (FIFO, skid buffer, register slice, error responder, tag tracker, width adapter,
  system test, async FIFO) applies an **asynchronous reset in the middle of traffic**, at a time not aligned to any clock
  edge, several times, and then proves full recovery (the tag tracker is also reset to recover from its fatal-error latch).
  In every one of these tests all resets of a test come from a single asynchronous reset source.
* `tb_sf_albion_cdc` checks `sf_albion_reset_sync` for 60 random release times per instance: it falls in the time step of the
  asynchronous assertion, rises only in the time step of a clock edge, and exactly `STAGES` edges after the release (ALP-RST-03).

## 3. Reset sequencing

1. Hold the asynchronous reset low long enough for every domain to see at least two clock edges (the reset synchroniser
   needs `STAGES` edges to release).
2. Release asynchronous reset; each domain's `rst_no` rises `STAGES` edges later, in its own domain.
3. Do not start traffic on a link until **both** ends have left reset.
4. `sf_albion_ref_mem` needs `WORDS` further cycles to clear its array (`req_ready_o` stays low until then).

## 4. Clock-domain-crossing primitives (optional, independently verified)

| Module | Crosses | Rules of use |
|---|---|---|
| `sf_albion_cdc_bit_sync` | **one bit**, any domain to `dst_clk_i` | source from a flip-flop, held >= 1 destination period; never one instance per bus bit; the path into the first flop may be constrained as a false path or a max-delay path |
| `sf_albion_reset_sync` | reset release | one per domain at the boundary |
| `sf_albion_cdc_pulse` | one event per accepted request, with acknowledge | rare control events; `src_ready_o` low while an event is in flight; reset both sides together (a one-sided reset can emit a spurious pulse) |
| `sf_albion_async_fifo` | a **bus**, via Gray-coded pointers | reset both sides together and carry no traffic while either side is in reset (see "Reset sequencing of the CDC modules"); the only multibit crossing provided |

**There is deliberately no multibit synchroniser.**  Synchronising the bits of a bus independently can capture a mix of old and
new bits; the library offers only the two safe patterns: Gray-coded pointers (one bit changes per step) and a request /
acknowledge handshake.

### What the CDC verification does and does not show

Verified (`tb_sf_albion_cdc`, 17 sub-testbenches over unrelated clock ratios; all periods are integer nanoseconds, so
ratios such as 10:7 or 6:34 drift through all relative phases while the two equal-period cases (10:10) keep a fixed phase
offset):

* `sf_albion_cdc_bit_sync`: the output equals the source sampled exactly `STAGES` destination edges earlier (exact latency, no
  glitch), and changes only in the time step of a destination edge.
* `sf_albion_cdc_pulse`: every accepted event gives exactly one one-cycle pulse; none lost or duplicated, across clock ratios from 1:3.7 to 3.7:1, 6 rounds each.
* `sf_albion_async_fifo`: in order, loss-free, duplicate-free under random back-pressure on both sides for 9 configurations
  (widths 5..148, depths 4..32, ratios from 1:5.7 to 5.7:1), Gray pointers change by at most one bit per cycle, occupancy never exceeds the depth, and
  4 resets in the middle of traffic.

**Not** verified, and not claimed:

* **Metastability.**  Verilator is a two-state, cycle-based simulator; the synchroniser flops behave as ideal delays.  Whether the
  synchroniser is deep enough for a given clock frequency and technology (MTBF) is a back-end question.
* **Structural CDC sign-off.**  Nothing here proves that *other* logic does not cross domains.  Use a CDC-aware tool in the back-end
  flow.
* **Timing constraints of the crossings.**  Simulation samples every bit on the same edge, so it cannot show the hazards that
  the constraints below prevent.  A back-end flow must provide them (nothing here checks or generates them):
  * single bits (`sf_albion_cdc_bit_sync`, the toggle and acknowledge wires of `sf_albion_cdc_pulse`): the path into the first
    flop is an asynchronous path (false path or max delay);
  * the Gray pointers of `sf_albion_async_fifo` are a **bus** of `ADDR_W + 1` bits whose "one bit changes per step"
    argument needs all bits to arrive within about one destination period of each other.  Do **not** declare them false paths:
    constrain each pointer with a bus-skew (or max-delay on the data path only) constraint;
  * `rd_data_o` is read combinationally from the storage array, which is clocked by the write clock.  It is safe because a word is
    written at least one write edge before the pointer that exposes it and is read only after that pointer has crossed the
    synchroniser, but the path from the array to the read domain still needs a max-delay constraint (a false path would hide
    a real timing hazard).
* **Reset of one side of a crossing.**  See the next section: not detected, not tested.
* **Formal proofs** of the CDC modules: the formal flow here is single-clock.

### Reset sequencing of the CDC modules

`sf_albion_async_fifo` and `sf_albion_cdc_pulse` keep state in both domains (pointers, toggle flops).  The supported
sequence is the one of section 3: both resets are asserted together (one asynchronous source, each domain's release
synchronised to its own clock) and no transfer is attempted on either side until both domains have left reset.  What happens
otherwise is **outside the contract** and is not detected: for example, resetting only the read side after traffic returns
its read pointer to zero while the write pointer is not, so the words in the array are delivered again; resetting either
side is a multibit jump of a Gray pointer and breaks the one-bit-per-step property for one cycle; a one-sided reset of
`sf_albion_cdc_pulse` can emit a spurious pulse.  The rule "neither side may transfer while the other is in reset" is
sufficient, not necessary (writing early while the read side is held in reset also delivered every word exactly once in an
experiment), but it is the only rule that is stated.  The testbench applies the reset-in-traffic case only through a single
shared asynchronous reset and gates its one-bit-per-cycle monitor while a reset is active.
