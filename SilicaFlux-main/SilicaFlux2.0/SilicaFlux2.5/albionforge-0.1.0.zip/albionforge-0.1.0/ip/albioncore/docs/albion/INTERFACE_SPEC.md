# Module interface specification

This document is **generated from the RTL**: each section shows the header comment of the module (its behavioural contract), its
parameters with defaults, and its ports with direction and type.  It cannot drift from the code; `make check` regenerates it and
fails if it is stale (`gen_docs.py --check`).

Conventions common to all modules (details in [ARCHITECTURE_CONTRACT.md](ARCHITECTURE_CONTRACT.md) and [NAMING_RULES.md](NAMING_RULES.md)):

* `clk_i`: rising-edge clock; `rst_ni`: active-low, asynchronous assertion, synchronous release.
* Channels use `<x>_valid` / `<x>_ready` / payload; a transfer happens when both are high; `valid` is held until accepted.
* No `ready` output depends combinationally on a `valid` or payload input.
* Payload structs (`sf_albion_pkg::sf_req_t`, `sf_rsp_t`) are 236 and 148 bits; the generic stages (`fifo`, `skid`, `regslice`) carry any `WIDTH`.
* Data outputs are meaningful only while the matching `valid` is high.

Summary of the stage types:

| Stage | Registers on | Storage | `in_ready` depends on | Combinational paths left |
|---|---|---|---|---|
| `sf_albion_skid` | valid + data + ready | 2 | state only | none |
| `sf_albion_regslice` MODE 0 | - | 0 | `out_ready` | all |
| `sf_albion_regslice` MODE 1 (forward) | valid + data | 1 | state, `out_ready` | `out_ready -> in_ready` |
| `sf_albion_regslice` MODE 2 (backward) | ready | 1 | state only | `in_valid/data -> out_valid/data` |
| `sf_albion_regslice` MODE 3 (full) | valid + data + ready | 2 | state only | none |
| `sf_albion_fifo` | storage + pointers | `DEPTH` | state, `flush_i` | none |

<!-- BEGIN GEN:INTERFACES -->
## Core library

### `sf_albion_pkg`  (package `rtl/albion/sf_albion_pkg.sv`)

```text
Project   : Aureom.AI / SilicaFlux Albion (AlbionCore foundation)
Role      : Single source of truth for the Albion Link Protocol (ALP) v1:
            address / data / tag / domain types, operation codes, status
            codes, memory attributes, address-space identifiers, region
            attributes, device capability fields and the pure functions that
            define request legality and response well-formedness.
Contract  : docs/albion/ARCHITECTURE_CONTRACT.md  (rule ids "ALP-xxx-nn")
C / Rust  : include/albion/albion_proto.h and .rs are GENERATED from this
            file by tools/albion/build/gen_proto.py; do not edit them.
Baseline  : 64-bit address, 128-bit data, 16-bit byte mask, 8-bit tag,
            8-bit protection-domain id.  The package types are FIXED.
            Other bus widths are supported only through the explicit width
            adapter (sf_albion_width_adapter) or a future generated package;
            never by overriding these widths.
Tool rules (see docs/albion/NAMING_RULES.md, section "Tool compatibility"):
  * synthesizable-subset only: no classes, no dynamic types, no `define.
  * struct fields are plain logic vectors; enums name the code points and
    are used in comparisons / case labels.  They are never cast, because
    the Yosys 0.33 front end rejects enum casts.
  * modules reference this package with scoped names (sf_albion_pkg::NAME);
    there is no wildcard import, so the package cannot collide with the
    many other sf_* / silicaflux_* packages already in the repository.
  * functions assign to their own name (no `return`, a Yosys 0.33 limit).
  * Yosys 0.33 cannot elaborate a call whose FORMAL argument is a package
    struct.  Every checking function therefore exists twice: a `_bits`
    version taking a flat vector (the synthesizable API, used by rtl/ and by
    formal) and a struct-argument wrapper for simulation convenience that
    simply forwards to it.  Layout offsets are published as SF_*_LSB
    constants and verified against the structs by tb_sf_albion_pkg.
  * Yosys 0.33 resolves the identifiers inside a package function in the
    CALLER's scope, so an unqualified enum member silently becomes an
    undriven wire.  Inside function bodies every package item is therefore
    written with its full scope (sf_albion_pkg::NAME).  The synthesis flow
    fails on any "implicitly declared" / "no driver" report.
This file contains no process-node, timing or performance claims.
```

### `sf_albion_fifo`  (module `rtl/albion/sf_albion_fifo.sv`)

```text
Single-clock, first-word-fall-through FIFO with independent valid/ready
handshakes on both sides.
Parameters
  WIDTH  payload width in bits                       (>= 1)
  DEPTH  number of entries; any integer >= 1, it need not be a power of two
Interface contract
  push side  in_valid_i / in_ready_o / in_data_i
  pop  side  out_valid_o / out_ready_i / out_data_o   (head shown directly)
  flush_i    synchronous clear (cancellation, rule ALP-CAN-03)
  count_o / full_o / empty_o   occupancy, for flow control and test
Behaviour
  * A push is accepted in a cycle with in_valid_i && in_ready_o.
    A pop happens in a cycle with out_valid_o && out_ready_i.
  * in_ready_o  = !full && !flush_i.  It depends only on registered state
    and flush_i: there is NO combinational path from out_ready_i or
    in_valid_i to in_ready_o.  A full FIFO therefore does not accept a push
    in the cycle in which it is popped.  Sustained one-transfer-per-cycle
    throughput needs DEPTH >= 2; use sf_albion_skid / sf_albion_regslice
    for single-entry stages.
  * out_valid_o = !empty, a function of registered state only.
  * Data is delivered in push order, with no loss and no duplication.
  * out_data_o is stable while out_valid_o && !out_ready_i, except across
    a flush (the only event allowed to withdraw a valid).
  * flush_i takes effect at the next clock edge: the FIFO becomes empty.  It
    empties this queue only: entries already handed on to a following stage
    (for example a skid buffer behind the FIFO) are not recalled.
    A pop in the flush cycle is still delivered; no push is accepted
    (in_ready_o is low while flush_i is high).
  * Storage is not reset (only pointers and the count are); out_data_o is
    meaningful only while out_valid_o is high.
Reset: asynchronous assertion, active-low rst_ni, see RESET_CLOCK_CONTRACT.
```

| Parameter | Type | Default |
|---|---|---|
| WIDTH | `int unsigned` | `8` |
| DEPTH | `int unsigned` | `4` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `flush_i` | input | `logic` |
| `in_valid_i` | input | `logic` |
| `in_ready_o` | output | `logic` |
| `in_data_i` | input | `logic [WIDTH-1:0]` |
| `out_valid_o` | output | `logic` |
| `out_ready_i` | input | `logic` |
| `out_data_o` | output | `logic [WIDTH-1:0]` |
| `count_o` | output | `logic [$clog2(DEPTH+1)-1:0]` |
| `full_o` | output | `logic` |
| `empty_o` | output | `logic` |

### `sf_albion_skid`  (module `rtl/albion/sf_albion_skid.sv`)

```text
A full-throughput pipeline stage that cuts BOTH the forward (valid/data)
and the backward (ready) paths.  Storage: one output register plus one
spill register.
Parameter
  WIDTH  payload width in bits (>= 1)
Behaviour
  * in_ready_o = !spill_valid.  Registered state only: no combinational
    path from out_ready_i, in_valid_i or in_data_i to in_ready_o.
  * out_valid_o / out_data_o come straight from the output register.
  * One transfer per cycle in steady state (input and output both moving).
  * When the output stalls, the one extra item the upstream already
    committed to is caught in the spill register; nothing is lost or
    duplicated; order is preserved.
  * Output data and valid are stable while out_valid_o && !out_ready_i.
There is no flush: a skid stage is a short pipeline element that drains on
its own.  Cancellation is handled at the transaction level (tag tracker)
and by flushing queues that are internal to a component (sf_albion_fifo).
```

| Parameter | Type | Default |
|---|---|---|
| WIDTH | `int unsigned` | `8` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `in_valid_i` | input | `logic` |
| `in_ready_o` | output | `logic` |
| `in_data_i` | input | `logic [WIDTH-1:0]` |
| `out_valid_o` | output | `logic` |
| `out_ready_i` | input | `logic` |
| `out_data_o` | output | `logic [WIDTH-1:0]` |

### `sf_albion_regslice`  (module `rtl/albion/sf_albion_regslice.sv`)

```text
Inserts pipeline registers into a valid/ready channel for timing closure.
MODE chooses which paths are registered:
  MODE  name    registered paths                  storage      comb. paths left
  ----  ------  --------------------------------  -----------  -------------------------
   0    BYPASS  none (wires)                      none         all
   1    FWD     valid + data  (forward)           1 entry      ready: out_ready -> in_ready
   2    BWD     ready         (backward)          1 spill      valid/data: in -> out
   3    FULL    valid, data and ready             2 entries    none (this is a skid buffer)
All modes are loss-free, order-preserving and allow one transfer per cycle
in steady state.  Output valid and data are stable while
out_valid_o && !out_ready_i in every mode.
In no mode is there a combinational path from any valid or data input to
an in_ready_o output, so chains of slices can never form a combinational
loop between valid and ready.
Parameters
  WIDTH  payload width in bits (>= 1)
  MODE   0..3 as above
```

| Parameter | Type | Default |
|---|---|---|
| WIDTH | `int unsigned` | `8` |
| MODE | `int unsigned` | `3` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `in_valid_i` | input | `logic` |
| `in_ready_o` | output | `logic` |
| `in_data_i` | input | `logic [WIDTH-1:0]` |
| `out_valid_o` | output | `logic` |
| `out_ready_i` | input | `logic` |
| `out_data_o` | output | `logic [WIDTH-1:0]` |

### `sf_albion_width_adapter`  (module `rtl/albion/sf_albion_width_adapter.sv`)

```text
ALP v1 fixes the package data width at 128 bits.  Other widths are reached
through this adapter.  It connects a "slave-side" link (this module is the
TARGET of that link) to a "master-side" link (this module is the INITIATOR
of that link).  Both links carry the same request / response fields; only
the data / byte-enable widths differ.  All port signals are flat so the
narrow link needs no package type.
  DOWNSIZE = 1   slave side WIDE (128), master side NARROW_W
  DOWNSIZE = 0   slave side NARROW_W,   master side WIDE (128)
Parameters
  DOWNSIZE  see above
  NARROW_W  narrow data width in bits: 8, 16, 32 or 64
  MAX_OUT   DOWNSIZE = 0 only: size of the order queue.  At most MAX_OUT requests
            are outstanding on the wide (master) link and at most MAX_OUT + 2 on
            the narrow (slave) link (the order queue plus the two entries of the
            response skid buffer).
Link word size and legality
  A link of data width W obeys the ALP rules with W/8-byte words: addresses
  are aligned to W/8 bytes, byte enables have W/8 bits.  The adapter checks
  every slave-side request with the package legality rules (ALP-LEG-01).
  An illegal request is never forwarded; the adapter answers it locally
  with the legality status, in order with all other responses.
DOWNSIZE = 1  (wide request -> RATIO = 128/NARROW_W narrow beats)
  * One wide transaction is in flight at a time: s_req_ready_o is high only
    when idle.  Beats are issued back to back and their responses collected
    in order.
  * A beat whose byte-enable slice is all zero is skipped.  Beat k carries
    wide bytes [k*NB +: NB] at address {wide_addr[63:4], 4'b0} + k*NB, and
    the parent's op, domain and attributes.
  * Narrow tag (ALP-TAG-01): the tag of a beat on the narrow link is its beat
    index k (0 .. RATIO-1), NOT the parent's tag.  Up to RATIO beats can be
    outstanding at once and their tags are pairwise different; the next
    parent starts only after every beat of the previous one has responded.
    The parent's tag is kept inside the adapter and returned on the wide link.
  * Response rules.  A beat response is NON-CONFORMING if its tag is not the
    beat's tag, its is_write flag is not the parent's, or it is not
    well-formed (sf_rsp_wellformed_bits).  The wide status is
      1. SF_ST_PROTOCOL_ERR if any beat response was non-conforming
         (this wins over every other status, whatever the beat order),
      2. else the status of the FIRST non-OKAY beat in beat order,
      3. else OKAY.
    Read data is reassembled from the beats; unless the status is OKAY the
    data is all-zero (ALP-RSP-05).  The completion metadata is regenerated
    (last = 1, poisoned == (status == ECC_UNCORR), is_write from the parent);
    meta.corrected is the OR of the corrected flags of the CONFORMING beat
    responses, whatever their status (it is informational).
  * Atomicity: a wide write is NOT atomic across beats.  If a beat fails,
    earlier beats have already been performed (ALP does not define atomics).
DOWNSIZE = 0  (narrow request -> one wide request)
  * The narrow word is placed in its lane of the wide word chosen by
    addr[3:log2(NARROW_W/8)]; the wide byte enables select only that lane.
    Read data is extracted from the same lane.
  * Up to MAX_OUT transactions are outstanding on the wide link; responses
    return in order (forwarded and locally generated ones are merged by an
    order queue).  The tag is passed through unchanged.
  * A wide response that is NON-CONFORMING (wrong tag, wrong is_write flag or
    not well-formed) is replaced by SF_ST_PROTOCOL_ERR with zero data and
    regenerated metadata (corrected = 0).  A conforming response is forwarded
    with its status and metadata; the data lane is extracted.
Timing.  No ready output depends combinationally on any input.  DOWNSIZE: the
slave-side ready and every response signal come from registers; the master-side
request fields are combinational functions of registers only.  UPSIZE: requests
and responses pass through skid buffers.
```

| Parameter | Type | Default |
|---|---|---|
| DOWNSIZE | `bit` | `1'b1` |
| NARROW_W | `int unsigned` | `32` |
| MAX_OUT | `int unsigned` | `4` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `s_req_valid_i` | input | `logic` |
| `s_req_ready_o` | output | `logic` |
| `s_req_op_i` | input | `logic [sf_albion_pkg::SF_OP_W-1:0]` |
| `s_req_tag_i` | input | `logic [sf_albion_pkg::SF_TAG_W-1:0]` |
| `s_req_dom_i` | input | `logic [sf_albion_pkg::SF_DOM_W-1:0]` |
| `s_req_attr_i` | input | `logic [sf_albion_pkg::SF_ATTR_W-1:0]` |
| `s_req_addr_i` | input | `logic [sf_albion_pkg::SF_ADDR_W-1:0]` |
| `s_req_be_i` | input | `logic [(DOWNSIZE ? sf_albion_pkg::SF_BE_W : NARROW_W/8)-1:0]` |
| `s_req_data_i` | input | `logic [(DOWNSIZE ? sf_albion_pkg::SF_DATA_W : NARROW_W)-1:0]` |
| `s_rsp_valid_o` | output | `logic` |
| `s_rsp_ready_i` | input | `logic` |
| `s_rsp_tag_o` | output | `logic [sf_albion_pkg::SF_TAG_W-1:0]` |
| `s_rsp_status_o` | output | `logic [sf_albion_pkg::SF_STATUS_W-1:0]` |
| `s_rsp_meta_o` | output | `logic [sf_albion_pkg::SF_CMETA_W-1:0]` |
| `s_rsp_data_o` | output | `logic [(DOWNSIZE ? sf_albion_pkg::SF_DATA_W : NARROW_W)-1:0]` |
| `m_req_valid_o` | output | `logic` |
| `m_req_ready_i` | input | `logic` |
| `m_req_op_o` | output | `logic [sf_albion_pkg::SF_OP_W-1:0]` |
| `m_req_tag_o` | output | `logic [sf_albion_pkg::SF_TAG_W-1:0]` |
| `m_req_dom_o` | output | `logic [sf_albion_pkg::SF_DOM_W-1:0]` |
| `m_req_attr_o` | output | `logic [sf_albion_pkg::SF_ATTR_W-1:0]` |
| `m_req_addr_o` | output | `logic [sf_albion_pkg::SF_ADDR_W-1:0]` |
| `m_req_be_o` | output | `logic [(DOWNSIZE ? NARROW_W/8 : sf_albion_pkg::SF_BE_W)-1:0]` |
| `m_req_data_o` | output | `logic [(DOWNSIZE ? NARROW_W : sf_albion_pkg::SF_DATA_W)-1:0]` |
| `m_rsp_valid_i` | input | `logic` |
| `m_rsp_ready_o` | output | `logic` |
| `m_rsp_tag_i` | input | `logic [sf_albion_pkg::SF_TAG_W-1:0]` |
| `m_rsp_status_i` | input | `logic [sf_albion_pkg::SF_STATUS_W-1:0]` |
| `m_rsp_meta_i` | input | `logic [sf_albion_pkg::SF_CMETA_W-1:0]` |
| `m_rsp_data_i` | input | `logic [(DOWNSIZE ? NARROW_W : sf_albion_pkg::SF_DATA_W)-1:0]` |

### `sf_albion_tag_tracker`  (module `rtl/albion/sf_albion_tag_tracker.sv`)

```text
Allocates transaction tags, enforces the outstanding-request limit, keeps a
per-tag context word, supports cancellation by abandoning a tag, and
(optionally) checks that responses return in request order.
Implements the initiator obligations ALP-TAG-01, ALP-OUT-01 and the
abandon form of cancellation, ALP-CAN-02.
Parameters
  NUM_TAGS     number of tags = maximum outstanding transactions.
               1 .. 256.  Tag values are 0 .. NUM_TAGS-1.
  CTX_W        width of the per-tag context word (>= 1), returned when the
               tag is freed (e.g. original request id, destination index)
  CHECK_ORDER  1: flag any response that is not for the oldest outstanding
               transaction (ALP-ORD-01) -- costs a NUM_TAGS-deep FIFO
Allocation   (alloc_valid_i / alloc_ready_o, handshake)
  alloc_ready_o is high while a tag is free and no fatal error is latched.
  alloc_tag_o shows the lowest free tag NOW, which is the tag assigned when
  alloc_valid_i is high in this cycle.  It changes in any cycle in which a tag
  is freed, so the caller must take the tag when it CREATES the request (assert
  alloc_valid_i when the request is loaded into the register that drives the
  link, and keep the tag in that register).  A request that is held on a link
  under back-pressure must not re-read alloc_tag_o.  alloc_ctx_i is stored with
  the tag.
Completion   (free_valid_i, free_tag_i; one response accepted per cycle)
  Combinational flags, valid while free_valid_i is high:
    free_ctx_o         the context stored when the tag was allocated
    free_drop_o        the tag was abandoned: DISCARD this response
    free_unexpected_o  the tag is not outstanding (spurious or duplicate
                       response); latches the fatal error
    free_order_err_o   response is for a tag other than the oldest
                       outstanding (CHECK_ORDER); latches the fatal error
  A tag freed in a cycle becomes allocatable in the NEXT cycle, so a tag
  is never reused in the cycle its response is accepted.
Cancellation
  abandon_valid_i / abandon_tag_i   mark one outstanding tag abandoned
  abandon_all_i                     mark every tag outstanding at the start
                                    of the cycle abandoned
  An abandoned tag STAYS busy until its response arrives (the target will
  still produce it, ALP-CAN-01); the response is then reported with
  free_drop_o.  Abandoning in the cycle the response arrives is too late:
  the response is delivered normally.
Fatal error: after free_unexpected_o or free_order_err_o the link has
violated the protocol.  sticky_err_o latches and alloc_ready_o stays low
until reset (ALP-RST-02).  full_o reports only that every tag is busy; it
does not include the fatal error (alloc_ready_o is the authoritative flag).
```

| Parameter | Type | Default |
|---|---|---|
| NUM_TAGS | `int unsigned` | `8` |
| CTX_W | `int unsigned` | `1` |
| CHECK_ORDER | `bit` | `1'b1` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `alloc_valid_i` | input | `logic` |
| `alloc_ready_o` | output | `logic` |
| `alloc_tag_o` | output | `logic [sf_albion_pkg::SF_TAG_W-1:0]` |
| `alloc_ctx_i` | input | `logic [CTX_W-1:0]` |
| `free_valid_i` | input | `logic` |
| `free_tag_i` | input | `logic [sf_albion_pkg::SF_TAG_W-1:0]` |
| `free_ctx_o` | output | `logic [CTX_W-1:0]` |
| `free_drop_o` | output | `logic` |
| `free_unexpected_o` | output | `logic` |
| `free_order_err_o` | output | `logic` |
| `abandon_valid_i` | input | `logic` |
| `abandon_tag_i` | input | `logic [sf_albion_pkg::SF_TAG_W-1:0]` |
| `abandon_all_i` | input | `logic` |
| `outstanding_o` | output | `logic [$clog2(NUM_TAGS+1)-1:0]` |
| `full_o` | output | `logic` |
| `empty_o` | output | `logic` |
| `sticky_err_o` | output | `logic` |

### `sf_albion_err_resp`  (module `rtl/albion/sf_albion_err_resp.sv`)

```text
Accepts requests and completes every one of them with an ERROR response.
Use it as
  * the default target of an address decoder (unmapped address -> DECODE_ERR),
  * the sink for requests rejected by a protection check (ACCESS_DENIED),
  * the local completion for an abandoned / cancelled request (CANCELLED; an
    illegal request still gets its legality status when CHECK_LEGALITY = 1,
    because legality has precedence -- use CHECK_LEGALITY = 0 to force status_i).
It never touches memory and never returns data.
Status selection, per request (ALP-LEG-01 precedence is preserved):
  1. if CHECK_LEGALITY and the request is itself illegal
     (sf_albion_pkg::sf_req_check_bits != OKAY) -> that legality status
  2. else status_i, supplied by the caller together with the request
  3. else, if status_i is OKAY (a caller error)        -> SF_ST_DECODE_ERR
  4. else, if status_i is an undefined code (> 11)     -> SF_ST_TARGET_ERR
     The generator can therefore never return success or an undefined code.
Response format (always well-formed, ALP-RSP-05):
  tag        echo of the request tag
  status     as selected above
  meta       last = 1, is_write = (op == WRITE), poisoned = (status == ECC_UNCORR)
  data       all-zero
Timing / buffering
  A DEPTH-entry in-order response FIFO decouples the two channels:
  req_ready_o is high while the FIFO has room.  Responses appear at least
  one cycle after their request is accepted (ALP-RSP-03) and are held
  until accepted.  DEPTH >= 2 sustains one request per cycle.
  The request-to-response path is combinational only up to the FIFO
  storage; there is no combinational valid -> ready path.
```

| Parameter | Type | Default |
|---|---|---|
| DEPTH | `int unsigned` | `2` |
| CHECK_LEGALITY | `bit` | `1'b1` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `req_valid_i` | input | `logic` |
| `req_ready_o` | output | `logic` |
| `req_i` | input | `sf_albion_pkg::sf_req_t` |
| `status_i` | input | `logic [sf_albion_pkg::SF_STATUS_W-1:0]` |
| `rsp_valid_o` | output | `logic` |
| `rsp_ready_i` | input | `logic` |
| `rsp_o` | output | `sf_albion_pkg::sf_rsp_t` |

## Optional clock-domain-crossing modules

### `sf_albion_cdc_bit_sync`  (module `rtl/albion/cdc/sf_albion_cdc_bit_sync.sv`)

```text
OPTIONAL module (not used by the single-clock baseline).
Passes ONE bit from any other clock domain into dst_clk_i through STAGES
flip-flops in series.  Rules of use:
  * the source signal must come directly from a flip-flop in its own domain
    (no combinational logic before the first synchroniser flop) and must be
    held long enough to be sampled (>= 1 dst clock period + setup);
  * the signal must be ONE bit.  NEVER connect several of these to the bits
    of a bus: bits can be captured on different dst edges.  A bus needs the
    Gray-coded sf_albion_async_fifo (or a handshake, sf_albion_cdc_pulse).
  * the first flop is the one that may go metastable.  Constrain the path into
    it as an asynchronous path in the back-end flow (false path or max delay),
    and keep the flops together.  Simulation does not model metastability.
    This advice is for a SINGLE bit.  The Gray pointers of sf_albion_async_fifo
    form a bus and need the bus constraints of docs/albion/RESET_CLOCK_CONTRACT.md.
Latency: STAGES dst_clk_i edges.  Reset: asynchronous, active low, to RESET_VALUE
(release this reset with sf_albion_reset_sync in the dst domain).
```

| Parameter | Type | Default |
|---|---|---|
| STAGES | `int unsigned` | `2` |
| RESET_VALUE | `bit` | `1'b0` |

| Port | Dir | Type / width |
|---|---|---|
| `dst_clk_i` | input | `logic` |
| `dst_rst_ni` | input | `logic` |
| `src_i` | input | `logic` |
| `dst_o` | output | `logic` |

### `sf_albion_reset_sync`  (module `rtl/albion/cdc/sf_albion_reset_sync.sv`)

```text
                             synchronous deassertion
Implements the Albion reset convention (docs/albion/RESET_CLOCK_CONTRACT.md):
  * assertion is asynchronous: rst_no goes low as soon as arst_ni goes low;
  * deassertion is synchronous: rst_no rises only on a clk_i edge, STAGES
    edges after arst_ni was released, so that every flop in the domain
    leaves reset in the same cycle and no flop sees reset removal near its
    clock edge (recovery / removal).
Instantiate one per clock domain at the domain boundary; fan rst_no out to
all logic of that domain.  OPTIONAL when the whole design shares one clock
and an external, already synchronised reset.
Parameter  STAGES  number of flops in series (>= 2)
```

| Parameter | Type | Default |
|---|---|---|
| STAGES | `int unsigned` | `2` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `arst_ni` | input | `logic` |
| `rst_no` | output | `logic` |

### `sf_albion_cdc_pulse`  (module `rtl/albion/cdc/sf_albion_cdc_pulse.sv`)

```text
OPTIONAL module.  Sends one event per accepted source request from the src
domain to the dst domain, with a full request / acknowledge round trip so
that events can never be lost or merged, whatever the clock ratio.
  src domain:  src_valid_i / src_ready_o handshake.  An event is accepted when
               src_valid_i && src_ready_o; src_ready_o is low while the
               previous event is still in flight.
  dst domain:  pulse_o is high for exactly ONE dst_clk_i cycle per event.
Mechanism: a toggle flop in the source domain flips per event; the toggle is
carried through sf_albion_cdc_bit_sync (one bit: safe) to the dst domain where
an edge detector produces the pulse; the dst-side toggle copy is carried back
through a second sf_albion_cdc_bit_sync as the acknowledge.
Throughput: one event per (2 * SYNC_STAGES + 2) clock periods of the slower
domain, approximately.  Use for rare control events, not data.
Reset: each domain has its own active-low reset; both must be asserted
together (overlapping) and released synchronously in their own domain.
```

| Parameter | Type | Default |
|---|---|---|
| SYNC_STAGES | `int unsigned` | `2` |

| Port | Dir | Type / width |
|---|---|---|
| `src_clk_i` | input | `logic` |
| `src_rst_ni` | input | `logic` |
| `src_valid_i` | input | `logic` |
| `src_ready_o` | output | `logic` |
| `dst_clk_i` | input | `logic` |
| `dst_rst_ni` | input | `logic` |
| `pulse_o` | output | `logic` |

### `sf_albion_async_fifo`  (module `rtl/albion/cdc/sf_albion_async_fifo.sv`)

```text
OPTIONAL module.  The multibit data path between two unrelated clock
domains.  Data never crosses through synchronisers; only the write and read
POINTERS do, and they are Gray coded so that at most one pointer bit changes
per increment -- each bit goes through its own sf_albion_cdc_bit_sync, which
is therefore safe.  (This is the only multibit crossing the library provides.)
Parameters
  WIDTH       payload width (>= 1)
  ADDR_W      log2(depth); depth = 2**ADDR_W, ADDR_W >= 2
  SYNC_STAGES synchroniser depth for the pointers (>= 2)
Interface: valid/ready on both sides.  wr_ready_o is the (registered, pessimistic)
"not full" flag in the write domain; rd_valid_o is the "not empty" flag in the
read domain; rd_data_o shows the head word while rd_valid_o is high.
Latency: a word written at write edge t becomes visible after the write
pointer has crossed (SYNC_STAGES read edges) -- the FIFO never shows data
early and never loses or duplicates data; flags are conservative.
Reset: wr_rst_ni and rd_rst_ni are separate (one per clock domain, each
released synchronously, see sf_albion_reset_sync) but they MUST OVERLAP: both
must be low at the same time, and neither side may transfer while the other is
in reset.  Resetting ONE side only is outside the contract and is not detected
(for example a read-side-only reset re-delivers the words still in the array).
Back-end constraints (not checked here, see docs/albion/RESET_CLOCK_CONTRACT.md):
the ADDR_W + 1 Gray bits of each pointer are a BUS: constrain them with a bus-skew
/ max-delay constraint, not a false path.  rd_data_o is read combinationally from
the write-clock storage array and needs a max-delay constraint as well.
```

| Parameter | Type | Default |
|---|---|---|
| WIDTH | `int unsigned` | `8` |
| ADDR_W | `int unsigned` | `3` |
| SYNC_STAGES | `int unsigned` | `2` |

| Port | Dir | Type / width |
|---|---|---|
| `wr_clk_i` | input | `logic` |
| `wr_rst_ni` | input | `logic` |
| `wr_valid_i` | input | `logic` |
| `wr_ready_o` | output | `logic` |
| `wr_data_i` | input | `logic [WIDTH-1:0]` |
| `rd_clk_i` | input | `logic` |
| `rd_rst_ni` | input | `logic` |
| `rd_valid_o` | output | `logic` |
| `rd_ready_i` | input | `logic` |
| `rd_data_o` | output | `logic [WIDTH-1:0]` |

## Reference design

### `sf_albion_ref_mem`  (module `rtl/albion/ref/sf_albion_ref_mem.sv`)

```text
A small, synthesizable memory that serves READ and WRITE requests with byte
enables.  It is the reference TARGET used by the system tests and by the
profile-elaboration builds; it shows how a target meets the ALP contract.
Parameters
  WORDS      number of 16-byte words (>= 1).  Offsets beyond WORDS*16 return
             SF_ST_DECODE_ERR (device-level decode, distinct from the
             fabric-level decode in sf_albion_ref_subsystem).
  RSP_DEPTH  response FIFO depth (>= 1)
  EXTRA_LAT  extra response pipeline stages (0..8), each a skid buffer; used
             to give different targets different latencies
  INIT_ZERO  1: after reset the memory is cleared word by word and
             req_ready_o stays low until the clear finishes, so unwritten
             locations read as zero.  0: contents are undefined until written.
Behaviour (each rule id refers to docs/albion/ARCHITECTURE_CONTRACT.md)
  * Requests execute in acceptance order, one at a time (ALP-ORD-02): a
    WRITE takes effect at acceptance; a READ samples memory at acceptance.
  * Illegal requests (sf_req_check_bits) return their legality status and
    do not touch memory (ALP-LEG-01).  An offset outside the memory returns
    SF_ST_DECODE_ERR.
  * READ returns the enabled byte lanes, other lanes zero; any non-OKAY
    response and every write response carries all-zero data (ALP-RSP-05).
  * The response is visible at least one cycle after acceptance (ALP-RSP-03),
    is held until accepted (ALP-RSP-02) and returns in order (ALP-ORD-01).
  * Write completion means the data is visible to any later read (ALP-ORD-03).
```

| Parameter | Type | Default |
|---|---|---|
| WORDS | `int unsigned` | `64` |
| RSP_DEPTH | `int unsigned` | `2` |
| EXTRA_LAT | `int unsigned` | `0` |
| INIT_ZERO | `bit` | `1'b1` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `req_valid_i` | input | `logic` |
| `req_ready_o` | output | `logic` |
| `req_i` | input | `sf_albion_pkg::sf_req_t` |
| `rsp_valid_o` | output | `logic` |
| `rsp_ready_i` | input | `logic` |
| `rsp_o` | output | `sf_albion_pkg::sf_rsp_t` |

### `sf_albion_ref_subsystem`  (module `rtl/albion/ref/sf_albion_ref_subsystem.sv`)

```text
One initiator-facing ALP link in; a one-region memory map behind it.
    req_i --> input skid --> decode --+--> sf_albion_ref_mem   (the region)
                                      |
                                      +--> sf_albion_err_resp  (everything else)
    rsp_o <-- output skid <-- in-order response merge <--+
Decode:
  1. address outside [REGION_BASE, +REGION_BYTES) -> err_resp, SF_ST_DECODE_ERR
  2. region access check fails                    -> err_resp, ACCESS_DENIED / BAD_ATTR
  3. otherwise                                    -> ref_mem at offset (addr - REGION_BASE)
Legality (ALP-LEG-01) is not repeated here: BOTH targets check the request they
receive and give the legality status precedence over every other status (ref_mem
and an sf_albion_err_resp with CHECK_LEGALITY = 1), so an illegal request is
answered with its legality status wherever the decode sends it and never changes
memory.  The decode only chooses the target.
Ordering (ALP-ORD-01): the two targets have different latencies; an order
queue records which target each accepted request went to, and the merge
releases responses strictly in that order.  MAX_OUT bounds the requests in
flight in the subsystem (ALP-OUT-01).
Parameters
  MAX_OUT       order-queue depth, 1..256.  Requests in flight in the subsystem are
                bounded by MAX_OUT + 4 (input skid 2 + order queue + output skid 2)
  REGION_BASE   base address of the region (aligned to REGION_BYTES)
  REGION_BYTES  region size, a power of two >= 16
  REGION_ATTR   sf_region_attr_t word of the region
  MEM_WORDS     16-byte words actually backed by memory (<= REGION_BYTES/16)
  MEM_RSP_DEPTH / MEM_EXTRA_LAT / ERR_RSP_DEPTH   buffering and latency of the targets
```

| Parameter | Type | Default |
|---|---|---|
| MAX_OUT | `int unsigned` | `8` |
| REGION_BASE | `logic [63:0]` | `64'h0000_0001_0000_0000` |
| REGION_BYTES | `int unsigned` | `4096` |
| REGION_ATTR | `logic [7:0]` | `8'b00_0_0_0_0_11` |
| MEM_WORDS | `int unsigned` | `64` |
| MEM_RSP_DEPTH | `int unsigned` | `2` |
| MEM_EXTRA_LAT | `int unsigned` | `2` |
| ERR_RSP_DEPTH | `int unsigned` | `2` |

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `req_valid_i` | input | `logic` |
| `req_ready_o` | output | `logic` |
| `req_i` | input | `sf_albion_pkg::sf_req_t` |
| `rsp_valid_o` | output | `logic` |
| `rsp_ready_i` | input | `logic` |
| `rsp_o` | output | `sf_albion_pkg::sf_rsp_t` |

### `sf_albion_ref_top`  (module `rtl/albion/ref/sf_albion_ref_top.sv`)

```text
Instantiates sf_albion_ref_subsystem with every parameter taken from the
generated sf_albion_cfg_pkg of the selected hardware profile
(tools/albion/config/albion_{min,cloud,hpc}.yaml).  This is the design that
is elaborated, simulated and synthesized to check a profile's resource budget.
```

| Port | Dir | Type / width |
|---|---|---|
| `clk_i` | input | `logic` |
| `rst_ni` | input | `logic` |
| `req_valid_i` | input | `logic` |
| `req_ready_o` | output | `logic` |
| `req_i` | input | `sf_albion_pkg::sf_req_t` |
| `rsp_valid_o` | output | `logic` |
| `rsp_ready_i` | input | `logic` |
| `rsp_o` | output | `sf_albion_pkg::sf_rsp_t` |
<!-- END GEN:INTERFACES -->
