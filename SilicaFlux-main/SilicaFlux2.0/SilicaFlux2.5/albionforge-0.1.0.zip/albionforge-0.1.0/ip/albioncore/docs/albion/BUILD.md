# Build instructions

A clean checkout (or the unzipped archive) builds, lints and tests the foundation **without any undocumented dependency**:
only open-source tools, all available as packages on Ubuntu 24.04.

## 1. Prerequisites

```bash
sudo apt-get install -y make build-essential python3 python3-yaml verilator yosys rustc   # rustc is optional
make doctor
```

`make doctor` prints the installed versions and fails if something required is missing or too old.  The project was developed
and verified with **Verilator 5.020, Yosys 0.33 (with `yosys-abc`), Python 3.13 with PyYAML 6, GNU make 4.3, gcc 13**
and rustc 1.97; see [DEPENDENCIES.md](DEPENDENCIES.md).  No proprietary tool, licence, network access or Python package other
than PyYAML is needed.

## 2. The one-command flow

```bash
make ci          # = doctor check lint sim formal synth report   (about 10 minutes from a clean checkout, measured)
```

| Target | What it does | Typical time (4 cores) |
|---|---|---|
| `make gen` | regenerates C / Rust / SV definitions, memory maps, configuration packages, traceability, doc regions, test vectors, filelists | seconds |
| `make check` | static gates: style (17 rules), dependencies and layering, parameter validation, generated files up to date, contract traceability, **tool self-tests** | seconds |
| `make lint` | Verilator `-Wall` (fatal) **and** Yosys elaboration checks for every module, 23 parameter variants and every profile's reference top | ~15 s |
| `make sim` | every self-checking Verilator simulation (system test for each profile), line coverage, memory-map cross-language check | ~7 min cold (Verilator builds dominate) |
| `make sim-quick` | unit tests and the `min` system test only | a few min |
| `make formal` | 18 formal jobs: unbounded proofs (ABC PDR) and cover reachability | ~2 min |
| `make synth` | generic Yosys synthesis of 14 targets and every profile top; latch check; resource budgets | ~1 min |
| `make report` | `build/reports/summary.md`, `coverage.md`, `junit.xml` | seconds |
| `make mutate` | mutation campaign (67 injected bugs); slow, run before release; needs a few GB of disk while it runs | ~55 min |
| `make dist` | deterministic zip in `dist/` | seconds |

Select profiles with `make sim PROFILES=min` (default `min cloud hpc`).  Results are **cached by content hash**: a re-run only
rebuilds and re-runs what changed.  `make clean` removes `build/` and `dist/`.

## 3. Individual tools

All tools are in `tools/albion/build/` and print `--help`.

| Tool | Purpose |
|---|---|
| `gen_proto.py` | C / Rust / Markdown protocol definitions from `sf_albion_pkg.sv` (`--check` for staleness) |
| `gen_memmap.py` | memory map with **collision detection** -> SV / C / Rust / Markdown (`--profile`, `--check-only`) |
| `gen_cfg.py`, `validate_params.py` | per-profile configuration package; parameter validator |
| `gen_filelist.py` | dependency-ordered filelists derived from the sources (`--top`, `--all`) |
| `check_deps.py` | dependency checker (manifest, layering, cycles, undefined modules, naming conflicts with SilicaFlux) |
| `style_check.py`, `lint.py` | coding-rule checker; Verilator + Yosys lint |
| `run_sim.py`, `run_all_sims.py` | build + run one / all simulations with coverage |
| `formal.py`, `synth.py` | formal and synthesis runners |
| `contract_trace.py`, `gen_docs.py` | contract <-> evidence matrix; generated documentation regions |
| `mutate.py`, `report.py`, `make_dist.py`, `doctor.py` | mutation campaign, reports, distribution, tool check |

Examples:

```bash
python3 tools/albion/build/gen_filelist.py --top tb_sf_albion_fifo --relative     # exactly the files that test needs
python3 tools/albion/build/run_sim.py --test tb_sf_albion_system --profile cloud --force
python3 tools/albion/build/formal.py --job tracker_ordered
python3 tools/albion/build/gen_memmap.py --profile hpc --check-only
verilator --lint-only -Wall --top-module sf_albion_fifo $(python3 tools/albion/build/gen_filelist.py --top sf_albion_fifo)
```

## 4. Using the library in another project

Compile `rtl/albion/sf_albion_pkg.sv` first, then the modules you need.  `gen_filelist.py --top <your_top>` produces the
ordered list for any top that instantiates Albion modules.  Reference the package with scoped names (`sf_albion_pkg::sf_req_t`).
For C / Rust, include `include/albion/albion_proto.{h,rs}` and the memory map of your profile
(`build/gen/<profile>/albion_memmap.{h,rs}` after `make gen`, or `include/albion/albion_memmap.*` for the full catalogue).

## 5. Extending

* **New module**: add the file under `rtl/albion/`, list it in `manifest.yaml`, give it a unit test (`tests/albion/unit`), a
  line in `tests.yaml` (`sims`, `lint_variants`, `synth`, `cover_goals`), and ideally a formal wrapper and mutants.  `make check` tells you what is missing.
* **New region**: add it to `regions.yaml` and enable it in the profiles that have it; the generator refuses collisions.
* **New profile**: copy `albion_min.yaml` to `albion_<name>.yaml`; `validate_params.py` explains what is wrong.
* **New contract rule**: add it to `contract_rules.yaml` with evidence and mention it in `ARCHITECTURE_CONTRACT.md`.

## 6. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `make doctor` says Verilator too old | the testbenches need `--timing` (Verilator >= 5.0); the flow is tested on 5.020 |
| formal job reports `UNKNOWN` | ABC hit its timeout; this is a **failure**, never a pass: shrink the wrapper parameters or raise `pdr_timeout_s` in `tests.yaml` |
| `D01` from `check_deps.py` | a new file is not in `manifest.yaml` |
| `style_check.py` reports `S15` | a construct Yosys 0.33 cannot elaborate; see NAMING_RULES.md section 3 |
| a simulation is "cached" but you changed something | only files reachable from the testbench are hashed; use `--force` or `make clean` |

## 7. Continuous integration

`.github/workflows/albion-ci.yml` runs `make doctor check lint sim formal synth report` on Ubuntu 24.04 with the distribution's
Verilator 5.020 and Yosys 0.33 and uploads the reports; a manual `workflow_dispatch` also runs the mutation campaign.  The same
commands were run from a clean unzip of the delivered archive (see [VERIFICATION.md](VERIFICATION.md)).
