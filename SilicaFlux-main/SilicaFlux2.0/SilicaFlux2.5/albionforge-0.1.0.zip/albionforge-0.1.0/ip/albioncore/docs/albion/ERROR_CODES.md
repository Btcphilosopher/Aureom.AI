# Error and status codes

Every response carries a 4-bit `status`.  `OKAY` is the only success code.  For **every other** status the response data
is all-zero, so an error never leaks data (ALP-RSP-05).  The generated tables below are produced from
`sf_albion_pkg.sv` (single source of truth); the C and Rust values are in `include/albion/albion_proto.{h,rs}`.

<!-- BEGIN GEN:STATUS_TABLES -->
### Operation codes (`sf_op_e`, 4 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_OP_NONE` |  |
| `0x1` | `SF_OP_READ` |  |
| `0x2` | `SF_OP_WRITE` |  |

### Status codes (`sf_status_e`, 4 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_ST_OKAY` | completed successfully |
| `0x1` | `SF_ST_DECODE_ERR` | address maps to no region / no target |
| `0x2` | `SF_ST_ACCESS_DENIED` | region permission, privilege, security or domain check failed |
| `0x3` | `SF_ST_BAD_OPCODE` | opcode not READ/WRITE (reserved, atomic family, or NONE) |
| `0x4` | `SF_ST_BAD_BE` | byte-enable mask is zero |
| `0x5` | `SF_ST_ALIGN_ERR` | address is not aligned to the data word |
| `0x6` | `SF_ST_BAD_ATTR` | reserved attribute bits set, or memory type not allowed |
| `0x7` | `SF_ST_TARGET_ERR` | generic target / device failure |
| `0x8` | `SF_ST_TIMEOUT` | target did not complete within its watchdog window |
| `0x9` | `SF_ST_CANCELLED` | locally synthesised completion for an abandoned request |
| `0xA` | `SF_ST_ECC_UNCORR` | uncorrectable data error; data is poisoned |
| `0xB` | `SF_ST_PROTOCOL_ERR` | link protocol violation detected by a component |

### Memory types (`sf_mem_type_e`, 2 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_MEM_NORMAL_WB` | normal memory, cacheable write-back |
| `0x1` | `SF_MEM_NORMAL_NC` | normal memory, non-cacheable |
| `0x2` | `SF_MEM_DEVICE` | device memory: strongly ordered, no merging or speculation |

### Address-space identifiers (`sf_asid_e`, 4 bit)

| Value | Name | Meaning |
|---|---|---|
| `0x0` | `SF_AS_DEVICE` | device-local memory (SRAM, scratchpads) |
| `0x1` | `SF_AS_CONFIG` | control / status registers (MMIO) |
| `0x2` | `SF_AS_EXTERNAL` | external memory reached through an adapter |
| `0x3` | `SF_AS_HOST` | host physical memory (reserved; DMA / PCIe path) |
| `0x4` | `SF_AS_SECURE` | secure-only memory and key storage |

### Request payload (`sf_req_t`, 236 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [235:232] | `op` | 4 | [235:232] operation |
| [231:224] | `tag` | 8 | [231:224] initiator transaction tag (opaque to targets) |
| [223:216] | `dom` | 8 | [223:216] protection domain |
| [215:208] | `attr` | 8 | [215:208] access attributes |
| [207:144] | `addr` | 64 | [207:144] byte address, lane-aligned (addr[3:0] == 0) |
| [143:128] | `be` | 16 | [143:128] byte-lane enables |
| [127:0] | `data` | 128 | [127:0]   write data (don't-care for reads, ignored) |

### Response payload (`sf_rsp_t`, 148 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [147:140] | `tag` | 8 | [147:140] echoed request tag |
| [139:136] | `status` | 4 | [139:136] sf_status_e |
| [135:128] | `meta` | 8 | [135:128] completion metadata |
| [127:0] | `data` | 128 | [127:0]   read data; all-zero for writes and for non-OKAY status |

### Access attributes (`sf_attr_t`, 8 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [7] | `rsvd` | 1 | [7]   must be 0           (else SF_ST_BAD_ATTR) |
| [6:5] | `qos` | 2 | [6:5] priority class hint, 0 = lowest .. 3 = highest |
| [4] | `instr` | 1 | [4]   instruction fetch (execute intent) |
| [3] | `secure` | 1 | [3]   1 = secure access |
| [2] | `priv` | 1 | [2]   1 = privileged access |
| [1:0] | `mem_type` | 2 | [1:0] sf_mem_type_e; 2'd3 reserved (else SF_ST_BAD_ATTR) |

### Region attributes (`sf_region_attr_t`, 8 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [7:6] | `mem_type` | 2 | [7:6] sf_mem_type_e of the region |
| [5] | `cacheable` | 1 | [5]   initiators may cache this region |
| [4] | `secure_only` | 1 | [4]   only secure accesses allowed |
| [3] | `priv_only` | 1 | [3]   only privileged accesses allowed |
| [2] | `exec` | 1 | [2]   instruction fetch allowed |
| [1] | `write` | 1 | [1]   writes allowed |
| [0] | `read` | 1 | [0]   reads allowed |

### Completion metadata (`sf_cmeta_t`, 8 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [7:4] | `rsvd` | 4 | [7:4] must be 0 |
| [3] | `corrected` | 1 | [3]   a correctable error was repaired (informational) |
| [2] | `poisoned` | 1 | [2]   data lanes must not be consumed (== status ECC_UNCORR) |
| [1] | `last` | 1 | [1]   last beat of the transaction (always 1 in ALP v1) |
| [0] | `is_write` | 1 | [0]   0 = read completion, 1 = write completion |

### Device capabilities (`sf_caps_t`, 64 bits)

| Bits | Field | Width | Notes |
|---|---|---|---|
| [63:60] | `proto_major` | 4 | [63:60] ALP major version |
| [59:56] | `proto_minor` | 4 | [59:56] ALP minor version |
| [55:48] | `addr_w` | 8 | [55:48] address width in bits |
| [47:44] | `data_bytes_log2` | 4 | [47:44] log2(data bytes): 4 = 16 bytes = 128 bit |
| [43:40] | `tag_w` | 4 | [43:40] tag width in bits |
| [39:36] | `dom_w` | 4 | [39:36] domain-id width in bits |
| [35:32] | `rsvd` | 4 | [35:32] reserved, 0 |
| [31:16] | `max_outstanding` | 16 | [31:16] outstanding transactions per link |
| [15:0] | `features` | 16 | [15:0]  SF_FEAT_* bit map |

### Fixed widths

| Constant | Value |
|---|---|
| `SF_ADDR_W` | 64 |
| `SF_DATA_W` | 128 |
| `SF_BE_W` | 16 |
| `SF_TAG_W` | 8 |
| `SF_DOM_W` | 8 |
| `SF_REQ_W` | 236 |
| `SF_RSP_W` | 148 |
| `SF_MAX_OUTSTANDING_LIMIT` | 256 |
<!-- END GEN:STATUS_TABLES -->

## Who produces which code

| Status | Produced by | Notes |
|---|---|---|
| `OKAY` | any target | the only success |
| `DECODE_ERR` | decoder default target (`sf_albion_err_resp`), memory targets for offsets beyond their backing | no region / no device at that address |
| `ACCESS_DENIED` | region access check, `sf_req_check` (invalid domain) | permission, privilege or security level insufficient |
| `BAD_OPCODE` | every target (legality) | includes the reserved atomic opcodes 4..7 (ALP-ATM-01) |
| `BAD_BE` | every target (legality) | byte-enable mask is zero |
| `ALIGN_ERR` | every target (legality) | address not aligned to the link word |
| `BAD_ATTR` | legality, region check | reserved attribute bits, memory type 3, or a request to a device region that is not marked device |
| `TARGET_ERR` | a target / device | generic failure; also the clamp for an undefined status given to `sf_albion_err_resp` |
| `TIMEOUT` | a target with a watchdog | the library has no watchdog; the code is reserved for targets |
| `CANCELLED` | `sf_albion_err_resp` with `status_i = CANCELLED` | locally synthesised completion for an abandoned request; with `CHECK_LEGALITY = 1` an illegal request gets its legality status instead |
| `ECC_UNCORR` | a target with ECC | `meta.poisoned` is set; the data lanes are zero |
| `PROTOCOL_ERR` | `sf_albion_width_adapter` | the target behind the adapter returned a non-conforming response: wrong tag, wrong operation flag, or not well-formed (status above 11, `last` = 0, reserved metadata bit, inconsistent `poisoned`, data on an error or write completion) |

Codes 12..15 are reserved; no component emits them, and `sf_albion_err_resp` maps an undefined input code to `TARGET_ERR`
so that it can never produce an ill-formed response.

## Precedence

When more than one condition holds, the **first** applies:

1. request legality: `BAD_OPCODE` > `ALIGN_ERR` > `BAD_BE` > `BAD_ATTR` > `ACCESS_DENIED` (invalid domain)
2. address decode: `DECODE_ERR`
3. region access: `ACCESS_DENIED` (read, write, execute, privilege, security in that order) > `BAD_ATTR` (memory type)
4. device level: `DECODE_ERR` for an offset beyond the backed memory
5. execution: target-specific (`TARGET_ERR`, `TIMEOUT`, `ECC_UNCORR`)

For a transaction split into beats by the width adapter, the response status is `PROTOCOL_ERR` if any beat response was
non-conforming (whatever its position), otherwise the status of the **first** failing beat in beat order.

## Handling guidance

* `DECODE_ERR`, `ACCESS_DENIED`, `BAD_*`, `ALIGN_ERR`: software/programming errors; retrying the same request gives the same result.
* `TARGET_ERR`, `TIMEOUT`: may be transient; a retry policy belongs to the initiator.
* `ECC_UNCORR`: the data is poisoned and must not be consumed.
* `CANCELLED`: delivered locally; the real response is dropped by the tracker when it arrives (ALP-CAN-02).
* `PROTOCOL_ERR`: a link bug; treat as fatal for the link and reset it.
