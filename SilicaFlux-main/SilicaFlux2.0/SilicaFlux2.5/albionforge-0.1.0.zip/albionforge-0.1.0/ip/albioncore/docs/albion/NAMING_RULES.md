# Naming rules and coding style

The style is derived from the **lowRISC Verilog Coding Style Guide** (lower_snake_case names, `_i` / `_o` / `_ni`
port suffixes, `_q` / `_d` for register output / next value, `u_` instance prefix, `gen_` generate labels), with deliberate
deviations that are listed here.  Every rule below is **checked mechanically** by `tools/albion/build/style_check.py`
(`make check`); the checker itself is tested with fixtures that make each rule fire
(`tests/albion/tools/test_tools.py`).

## 1. Names

| Item | Rule | Example |
|---|---|---|
| Module | `sf_albion_<lower_snake>`; the file is named like the module; one module per file | `sf_albion_tag_tracker` |
| Package | `sf_albion_<...>_pkg` (stems end in `_pkg`) | `sf_albion_pkg` |
| Signals, functions, struct fields | `lower_snake_case` | `rd_ptr_q` |
| Parameters, localparams, enum members | `UPPER_SNAKE_CASE` (**deviation from lowRISC**, matches the existing SilicaFlux code and C/Rust constants) | `DEPTH`, `SF_ST_OKAY` |
| Types | `lower_snake_case`, `_t` (typedef / struct) or `_e` (enum) | `sf_req_t`, `sf_status_e` |
| Ports | suffix `_i` input, `_o` output, `_io` inout; `_ni` / `_no` for active low | `clk_i`, `rst_ni`, `in_valid_i`, `rst_no` |
| Clock / reset | `clk_i`, `rst_ni`; a second domain prefixes them (`wr_clk_i`, `dst_rst_ni`) | |
| Flip-flop output / next value | `_q` / `_d` | `count_q`, `count_d` |
| Generate blocks | `gen_<what>`; parameter checks `gen_param_check*` | `gen_fifo` |
| Instances | `u_<what>` | `u_order` |
| Handshake channels | `<chan>_valid` / `<chan>_ready` / payload; `in_*` / `out_*` for stages, `s_*` / `m_*` for adapters | `s_req_valid_i` |
| Package constants | `SF_<AREA>_<NAME>`; generated memory map `SF_MM_<REGION>_<FIELD>`; generated configuration `CFG_<NAME>` | `SF_ADDR_W`, `SF_MM_SRAM_BASE` |
| Testbench files | `tb_<module>`; shared verification `sf_albion_tb_*`, `sf_albion_*_checker`; formal wrappers `fv_<module>` | |
| Rule ids | `ALP-<AREA>-<nn>`; labels of checker assertions `a_alp_<area>_<nn>` | `a_alp_ord_01` |

The prefix `sf_albion_` keeps the library clear of the roughly 1,700 unit names already used in the SilicaFlux
repository (see [REPO_AUDIT.md](REPO_AUDIT.md)); `check_deps.py` compares every definition with that inventory (rule D07).

## 2. RTL rules

* **SystemVerilog-2017-compatible, synthesizable subset.**  `always_ff` for sequential logic with **non-blocking**
  assignments only; `always_comb` for combinational logic; `assign` for continuous assignment; no `always @`, no `always_latch`.
* Every `always_ff` is `@(posedge clk_i)` or `@(posedge clk_i or negedge rst_ni)`; no negative-edge clocks, no second clock in one block.
* **No inferred latches**: every `always_comb` assigns every output on every path (a default first).  Yosys reports latches and the
  flow fails on them (`lint.py`, `synth.py`).
* **No implicit nets**: every file starts with `` `default_nettype none `` and ends with `` `default_nettype wire ``.
* **Explicit widths**: parameters are typed (`int unsigned`, `bit`, `logic [..]`), ports carry an explicit `logic` or package type, and
  Verilator `-Wall` (width warnings are fatal) must be clean for every module and parameter variant.
* **No simulation constructs inside production RTL**: no `initial`, `final`, `$display`, `$finish`, `$random`, delays, `force`, `fork`,
  `assert`/`assume`/`cover`, classes.  Assertions live in separate checker modules (`tests/albion/common`) so that the RTL is exactly what is synthesized.
  The single exception is `$error` inside a generate block named `gen_param_check*`, an **elaboration-time** parameter check that
  both Verilator and Yosys evaluate.
* **No process-node or performance claims** in code or documentation.
* **Preprocessor**: nothing except `` `default_nettype ``: no `` `define ``, `` `include ``, `` `ifdef ``.  Configuration comes from packages and parameters.
* **Flat ports for synthesizable modules.**  SystemVerilog interfaces are not used (the existing SilicaFlux flows run Yosys 0.33, which
  does not accept them).  Packed structs are used only as port/payload *types*.

## 3. Tool-compatibility rules (learned the hard way)

These are limits of the **Yosys 0.33** front end that the project must run on; each was found by experiment and is
guarded by a rule or a test.  Verilator 5.020 accepts all of them, which is why they are easy to miss.

| Rule | Why | Guard |
|---|---|---|
| No `import pkg::*`; write `sf_albion_pkg::NAME` | Yosys 0.33 does not accept package import statements | S15, D09 |
| **Inside package functions, qualify every package item** (`sf_albion_pkg::SF_ST_OKAY`) | Yosys resolves identifiers of a package function in the *caller's* scope: an unqualified enum member silently becomes an **undriven wire** | `fv_sf_albion_pkg_funcs` proves the Yosys-elaborated functions equal an independent reference; a mutation test confirms the guard fires |
| Package functions take **flat vectors** (`sf_req_check_bits(logic [235:0])`); struct-argument versions are simulation-only wrappers | a package struct as a function *formal argument* crashes or mis-elaborates in Yosys 0.33 | package header comment, `pkg_funcs` proof |
| No casts to package enums (`sf_status_e'(x)`), no `int'()` casts, no struct assignment patterns in constants, no `return` | rejected by the Yosys 0.33 parser | S15 |
| Struct fields are plain `logic` typedefs; enums name code points and are used in comparisons and `case` labels | follows from the previous rule | package |
| `unique case`, arrays of struct, functions with side effects: avoided | not exercised by the flow | review |
| Temporaries assigned in only some branches of an `always_comb` create latches in Yosys | found in the width adapter (`next_beat`) | `make lint` (Yosys check) |

## 4. Verification code

Testbench code (`tests/`) may use the full simulation subset, with these house rules: stimulus changes only on the falling clock
edge (never at the sampling edge), everything that reaches a DUT input changes through non-blocking assignment, each testbench prints
exactly one `ALBION_TB_RESULT` line plus its coverage bins, and reset is applied as a real `negedge` event at power-on (a reset
that starts low produces no event for asynchronous-reset flops).

## 5. The style rules

<!-- BEGIN GEN:STYLE_RULES -->
| Rule | Meaning |
|---|---|
| `S01` | file begins with a header comment block |
| `S02` | `default_nettype none before the first module/package and `default_nettype wire at the end |
| `S03` | module names are sf_albion_<lower_snake>; package names end in _pkg |
| `S04` | parameter, localparam and enum member names are UPPER_SNAKE_CASE |
| `S05` | signal, function, typedef and field names are lower_snake_case; typedefs end in _t or _e |
| `S06` | port suffixes: input _i or _ni, output _o or _no, inout _io |
| `S07` | always_ff uses non-blocking assignments only |
| `S08` | always_comb uses no non-blocking assignments |
| `S09` | only always_ff, always_comb and assign: no always @, always #, always_latch |
| `S10` | always_ff sensitivity is `posedge clk` or `posedge clk or negedge rst` (asynchronous low reset) |
| `S11` | no simulation constructs (initial, final, $display, $finish, $random, #delay, force, fork, assert, ...) |
| `S12` | $error only inside a generate block named gen_param_check* |
| `S13` | generate blocks are named gen_*; instances are named u_* |
| `S14` | no tabs, no trailing white space, lines <= 120 columns |
| `S15` | tool compatibility: no int'() cast, no return, no assignment pattern, no import |
| `S16` | no preprocessor use other than `default_nettype |
| `S17` | explicit types: parameters are typed; ports have an explicit logic or package data type |
<!-- END GEN:STYLE_RULES -->
