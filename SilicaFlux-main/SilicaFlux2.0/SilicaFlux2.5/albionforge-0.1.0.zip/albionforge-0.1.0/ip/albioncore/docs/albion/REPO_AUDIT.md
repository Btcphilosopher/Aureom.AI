# Repository audit

Audit of the existing SilicaFlux material in `btcphilosopher/Aureom.AI` (`SilicaFlux-main/`) before AlbionCore was written, as required
by the brief: compatible components, missing dependencies, naming conflicts, and the IP that must be preserved.
**Nothing in the existing repository was modified**; AlbionCore is a new, self-contained tree.

## 1. Method

* `SilicaFlux-main/` contains 14 loose `.sf` files, several directories of `.sf`/`.sfx` files and **many archives**.  All 138 archives
  (including nested ones) were extracted into an isolated scratch directory and only **read** (names, declarations, READMEs); no
  archive content was executed.
* Every `.sv`, `.svh`, `.v` and `.sf` file was scanned for `module`, `package` and `interface` declarations (comments stripped).
* The earlier DataFabric audit shipped in the repository (`silicaflux-datafabric.zip`, `docs/datafabric/AUDIT.md`) was read and its findings reused.
* Tools available and probed: Verilator 5.020, Yosys 0.33 + ABC, Icarus 12, z3 (the same versions the existing projects report).

## 2. Inventory

| Item | Count |
|---|---|
| HDL source files found (including duplicates across archive versions) | 6,287 (`.sv` 5,601, `.svh` 551, `.sf` 84, `.v` 51) |
| archives containing HDL | 118 |
| distinct module / package / interface names | **1,697** (snapshot in `tools/albion/config/legacy_names.txt`) |
| names declared in more than one archive | 723 (mostly version snapshots of the same IP) |
| distinct package names | 80 |
| interface types | 11 (`sram_if`, `sfb_if`, `noc_if`, `soc_bus_if`, `fifo_if`, ...) |
| EDA flow files | 222 `.tcl`, 52 `.sdc`, 15 `.xdc`, 360 `.ys`, 62 `.sby`, 20 `.mk`; GitHub-Actions workflows in at least 8 projects |

**`.sf` is plain SystemVerilog** with a custom extension (confirmed by the DataFabric audit and by the existing `run_sim.sh`, which passes
`*.sf` straight to `iverilog -g2012`).  AlbionCore uses `.sv`.

## 3. Findings that shaped AlbionCore

1. **Massive private duplication of the foundational primitives** -- exactly the gap this project fills:

   | Primitive | Distinct private implementations found |
   |---|---|
   | FIFOs (sync / async, any prefix) | 23 (`sf_fifo`, `sfb_...`, `sfv_fifo`, `sfn_fifo`, `sfx_fifo`, `sf_sync_fifo`, `dma_fifo`, `async_fifo`, ...) |
   | skid buffers | 4 (`sf_skid_buffer`, `sfb_skid_buffer`, `sfx_skid_buffer`, `sf_sdf_skid`) |
   | register slices | 2 (`sfb_reg_slice`, `sf_ts_slice`) |
   | reset synchronisers | 11 |
   | single-bit / pulse synchronisers | 14 |
   | arbiters | 10 |
   | tag / request trackers | 2 |

2. **No common transaction protocol.**  Memory and bus protocols in use: SFB / SFB2 (SilicaFlux-V and DataFabric), `sram_if` (SRAM library),
   `sf_sramc_txn_pkg`, `soc_bus_if`, NoC flits (`sfn_pkg`, `noc_if`), AXI4 (CloudDMA, StorageFabric), APB (MemoryFlow DMA).  Most have no tag,
   no domain and no attribute field.
3. **Memory maps are mutually inconsistent** (five `*_memmap_pkg` families, all 32-bit): `0x2000_0000` is the tile scratchpad (SilicaFlux-V +
   DataFabric), the ControlCore device window (ControlCore) and the local-SRAM window (CloudDPU).  `PERIPH` at `0x4000_0000` is common to
   most, `EXT` differs.  Albion therefore starts a new 64-bit map and **reserves the low 4 GiB** for a bridge.
4. **Divergent copies of "the" package**: `silicaflux_pkg` exists in **9 distinct bodies across 19 archive copies**; other packages are consistent
   (`sfv_pkg`: 1 body in 13 copies).  Albion defines its own package with scoped references and imports none of them.
5. **Tool limits already documented by the existing flows**: Yosys 0.33 does not accept SystemVerilog interfaces (existing rule: flat ports) -- Albion
   uses flat ports and additionally found that it rejects `import`, scoped enum casts and struct-argument package functions
   ([NAMING_RULES.md](NAMING_RULES.md) section 3).
6. **Defects in legacy modules reported by earlier audits** (not re-verified here; none of these modules is used by Albion): Gen-1 NoC router
   duplicates flits; `soc_sram` can lose responses; the FSM-library round-robin arbiter fails above 4 requesters; `axi_lite_slave` read-back.

## 4. Compatibility matrix

| Area (brief) | Existing IP found | Interface / protocol | Albion status |
|---|---|---|---|
| Packages and interfaces | 80 packages, 11 interfaces | struct-less constants, flat/`interface` mixes | **No dependency.**  `sf_albion_pkg` is new; no name collides (`check_deps.py` D07) |
| DataFabric | `sfb_crossbar`, `sfb_skid_buffer`, `sfb_reg_slice`, DMA; unbounded formal proofs (ABC PDR) | SFB2: **32-bit address, 32-bit data**, valid/ready both ways, error, no tags | **Compatible in spirit** (same handshake discipline, same flat-port rule, same proof flow).  Needs an **SFB2 <-> ALP bridge** (width up-conversion + tag/domain assignment): *missing dependency* |
| SRAM | SRAM Wrapper Library (`sram_if`, 3 backends, MBIST), `sf_sync_fifo` | `req_valid/ready`, `we`, `wmask`, `id`, response FIFO | **Compatible**: `id` maps to the tag, `wmask` to the byte mask.  Needs a thin `sram_if` adapter: *missing* |
| ControlCore | RV32IM, SFB2 master/slave, 8 KiB ROM, parity SRAM, mailbox, RAS | SFB2 | Reached through the SFB2 bridge; region `controlcore` reserved |
| Tensor / vector engines | TensorCore 01-10, HPC vector lane/array, vector scratch | command ABIs over SFB2 / register buses | region `tensor_vector` reserved; no RTL dependency |
| DMA | CloudDMA P64 (descriptor engine, permission checker, AXI4), HPC DMA adapter, DataFabric DMA | AXI4 / SFB2 | region `dma`; the **permission-check idea** is mirrored by `sf_access_check_bits`; no code shared |
| StorageCore | StorageCore P51 (reuses ControlCore), NAND, buffers | storage fabric, AXI | out of scope for the foundation |
| Security modules | SecureStore P59, secure boot | register maps | region `security` (secure-only, privileged-only) reserved; domain enforcement is future work |
| Clock / reset | CLOCKTREE P35 (`sf_crt_*` CDC library), POWERCLOCK P27 (`sf_cdc_*`, clock gate), per-IP `*_rst_sync` | async-assert / sync-release resets | Albion provides **one** library (`reset_sync`, `cdc_bit_sync`, `cdc_pulse`, `async_fifo`); the legacy ones remain untouched.  Convention (active-low, async assert) is **identical** |
| Test infrastructure | testcore (MBIST/JTAG/DFT), `UVM_Inspired_Architecture`, `formal_verification.zip`, HPC M09 verification | Verilator / Icarus benches, SVA targeting commercial tools, ABC / smtbmc proofs | Albion's flow **reuses the same open-source tools**; its assertions are written as immediate assertions so the same checker runs in Verilator and in Yosys formal |
| FPGA / OpenROAD | FLOORPLANBUILD P40 (Nangate45, OpenROAD), FloorplanLab, TimingFlow, DE10 synthesis, `.sdc` / `.xdc` | physical-design scripts | **Not touched.**  Albion stops at technology-independent Yosys synthesis; its `synth.py` reports are suitable inputs for those flows |

## 5. Naming conflicts

* **None**: no existing declaration starts with `sf_albion_`, and no existing name equals any Albion name (checked against all 1,697).
* **Latent risk avoided**: unprefixed generic names exist in the repository (`sync_fifo`, `async_fifo`, `decoder`, `round_robin_arbiter`,
  `priority_arbiter`); Albion never uses unprefixed names.
* **Style difference** (not a conflict): the existing code uses UPPER_SNAKE constants and `clk` / `rst_n`; Albion keeps the constants rule and uses
  `clk_i` / `rst_ni` (lowRISC suffixes).  Adapting a legacy module is a rename at the instantiation.

## 6. Missing dependencies (future work, none hidden)

| Needed to connect Albion to existing IP | Why it is not in the foundation |
|---|---|
| `sf_albion_sfb2_bridge` (32-bit SFB2 <-> ALP, tag and domain assignment) | needs a decision on the domain id of each legacy master; the width adapter and tag tracker are its building blocks |
| `sf_albion_sram_if_adapter` (`sram_if` <-> ALP) | thin; deferred until an SRAM instance is integrated |
| per-domain protection unit | no domain policy exists in the repository |
| SDC / OpenROAD constraints for the CDC modules | belongs to the physical-design flow |

## 7. Existing verified IP is preserved

No file of `SilicaFlux-main/` was added, changed or removed.  The DataFabric crossbar proofs, the SRAM library regressions, ControlCore firmware
tests and all other existing verification remain exactly as they were.  Albion's formal flow is intentionally the same style (flat wrappers,
Yosys front end, ABC engines) so results can be compared.
