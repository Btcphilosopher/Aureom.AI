// =============================================================================
//  tb_sf_albion_skid.sv  --  self-checking test of sf_albion_skid
// =============================================================================
`default_nettype none
module tb_sf_albion_skid;
  localparam int unsigned N = 4;
  logic [N-1:0] fin;
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_skid"), .ID(0), .KIND(1), .WIDTH(1), .DEPTH(1), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_0 (.finished_o(fin[0]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_skid"), .ID(1), .KIND(1), .WIDTH(8), .DEPTH(1), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_1 (.finished_o(fin[1]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_skid"), .ID(2), .KIND(1), .WIDTH(148), .DEPTH(1), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_2 (.finished_o(fin[2]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_skid"), .ID(3), .KIND(1), .WIDTH(236), .DEPTH(1), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_3 (.finished_o(fin[3]));

  initial begin
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_skid");
    $finish;
  end
endmodule
`default_nettype wire
