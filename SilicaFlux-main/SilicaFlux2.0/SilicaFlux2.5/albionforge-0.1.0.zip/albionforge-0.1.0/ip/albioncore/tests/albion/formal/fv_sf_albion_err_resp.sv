// =============================================================================
//  fv_sf_albion_err_resp.sv  --  formal wrapper for sf_albion_err_resp
// -----------------------------------------------------------------------------
//  Proved for every initiator that obeys the request-side contract (request
//  held until accepted, unique tags, bounded outstanding -- assumptions of
//  sf_albion_link_checker in ASSUME_REQ mode):
//    ER-1  the response channel obeys ALP-RSP-02/03, ORD-01, TAG-02, RSP-04,
//          RSP-05 and (when CHECK_LEGALITY) LEG-01 -- asserted by the checker
//    ER-2  the response to a symbolic watch request is EXACTLY the one the
//          selection rules define (status choice, tag echo, metadata, zero
//          data), whatever the request, status_i and timing
//    ER-3  the generator never returns success (status != OKAY) or an
//          undefined status
//    ER-4  at most DEPTH requests are outstanding
//  COVER_IDX >= 0 selects reachability mode (see fv_sf_albion_fifo.sv).
// =============================================================================
module fv_sf_albion_err_resp #(
  parameter integer DEPTH          = 2,
  parameter integer CHECK_LEGALITY = 1,
  parameter integer COVER_IDX      = -1
) (
  input  wire         clk_i,
  input  wire         rst_ni,
  input  wire         req_valid_i,
  input  wire [235:0] req_i,
  input  wire [3:0]   status_i,
  input  wire         rsp_ready_i
);
  localparam PROVE = (COVER_IDX < 0);
  localparam IW    = 2;                                   // modulus 4 > DEPTH + 1 for DEPTH <= 2; widened below
  localparam integer IWID = (DEPTH + 1 > 3) ? 3 : 2;

  wire         req_ready;
  wire         rsp_valid;
  wire [147:0] rsp;

  sf_albion_err_resp #(.DEPTH(DEPTH), .CHECK_LEGALITY(CHECK_LEGALITY != 0)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .req_valid_i(req_valid_i), .req_ready_o(req_ready), .req_i(req_i), .status_i(status_i),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready_i), .rsp_o(rsp));

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  // Environment: the initiator obeys ALP (assumed by the checker's ASSUME_REQ mode).
  always @(*) if (!rst_ni) assume (!req_valid_i);
  wire [15:0] outstanding;
  sf_albion_link_checker #(.MAX_OUTSTANDING(DEPTH + 2), .CHECK_LEGALITY(CHECK_LEGALITY != 0), .ASSUME_REQ(1'b1), .ASSUME_RSP(1'b0)) u_link (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .req_valid_i(req_valid_i), .req_ready_i(req_ready), .req_i(req_i),
    .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready_i), .rsp_i(rsp),
    .waive_req_i(1'b0), .outstanding_o(outstanding));

  // ---------------- independent expected response (plain operators, decimal constants)
  function [147:0] expect_rsp;
    input [235:0] r;
    input [3:0]   st_in;
    reg   [3:0]   op, leg, st;
    reg   [7:0]   dom, attr;
    reg   [63:0]  addr;
    reg   [15:0]  be;
    begin
      op = r[235:232]; dom = r[223:216]; attr = r[215:208]; addr = r[207:144]; be = r[143:128];
      leg = 4'd0;
      if (op != 4'd1 && op != 4'd2)           leg = 4'd3;
      else if (addr[3:0] != 4'd0)             leg = 4'd5;
      else if (be == 16'd0)                   leg = 4'd4;
      else if (attr[7] || attr[1:0] == 2'd3)  leg = 4'd6;
      else if (dom == 8'd255)                 leg = 4'd2;
      if (CHECK_LEGALITY != 0 && leg != 4'd0) st = leg;
      else if (st_in == 4'd0)                 st = 4'd1;
      else if (st_in > 4'd11)                 st = 4'd7;
      else                                    st = st_in;
      expect_rsp = {r[231:224], st, 4'b0000, 1'b0, (st == 4'd10), 1'b1, (op == 4'd2), 128'd0};
    end
  endfunction

  wire push = req_valid_i && req_ready;
  wire pop  = rsp_valid && rsp_ready_i;
  (* anyconst *) reg [IWID-1:0] watch_n;
  reg [IWID-1:0]  push_idx_q, pop_idx_q;
  reg [147:0]     watch_exp_q;
  reg             watch_stored_q;
  wire [IWID-1:0] count = push_idx_q - pop_idx_q;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      push_idx_q <= {IWID{1'b0}}; pop_idx_q <= {IWID{1'b0}}; watch_stored_q <= 1'b0; watch_exp_q <= 148'd0;
    end else begin
      if (push) push_idx_q <= push_idx_q + 1'b1;
      if (pop)  pop_idx_q  <= pop_idx_q + 1'b1;
      if (push && push_idx_q == watch_n) begin watch_stored_q <= 1'b1; watch_exp_q <= expect_rsp(req_i, status_i); end
    end
  end

  always @(posedge clk_i) begin
    if (PROVE && rst_ni && !init_q) begin
      if (pop && pop_idx_q == watch_n) a_er_2_exact: assert (watch_stored_q && rsp == watch_exp_q);
      if (rsp_valid) a_er_3_status: assert (rsp[139:136] != 4'd0 && rsp[139:136] <= 4'd11);
      a_er_4_capacity: assert (outstanding <= DEPTH);
    end
  end

  wire [3:0] cov_vec;
  assign cov_vec[0] = rst_ni && !init_q && push && pop;
  assign cov_vec[1] = rst_ni && !init_q && pop && pop_idx_q == watch_n && watch_stored_q;
  assign cov_vec[2] = rst_ni && !init_q && outstanding == DEPTH;
  assign cov_vec[3] = rst_ni && !init_q && pop && rsp[139:136] == 4'd10;
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
