// expect: S16
`default_nettype none
`define SOMETHING 1
module sf_albion_fixture_a (input wire logic d_i, output logic q_o);
  assign q_o = d_i;
endmodule
`default_nettype wire
