// =============================================================================
//  sf_albion_tb_pkg.sv  --  testbench-only helpers (never synthesized)
// -----------------------------------------------------------------------------
//  * deterministic PRNG (xorshift64*) so a given seed gives identical stimulus
//    on every simulator and every host,
//  * check / failure counters and a single end-of-test report,
//  * functional-coverage bins (named counters) printed in a machine-readable
//    form that tools/albion/build/report.py aggregates,
//  * an INDEPENDENT reference implementation of the request-legality rules.
//    It is written from the contract text (docs/albion/ARCHITECTURE_CONTRACT.md)
//    using raw bit offsets and integer arithmetic, deliberately NOT calling
//    sf_albion_pkg::sf_req_check, so the two implementations can disagree and
//    the package self-test (tb_sf_albion_pkg) will notice.
// =============================================================================
`default_nettype none

package sf_albion_tb_pkg;

  // ---------------------------------------------------------------------------
  // Global state (one testbench per simulation binary)
  // ---------------------------------------------------------------------------
  int unsigned tb_errors = 0;
  int unsigned tb_checks = 0;
  logic [63:0] tb_rng_state = 64'h9E37_79B9_7F4A_7C15;
  int unsigned tb_cov_cnt [string];
  // +albion_failfast: end the simulation at the first failed check.  Used by
  // the mutation runner so that a broken design is rejected immediately.
  bit          tb_failfast_checked = 1'b0;
  bit          tb_failfast = 1'b0;

  // ---------------------------------------------------------------------------
  // PRNG
  // ---------------------------------------------------------------------------
  function automatic void tb_seed(input int unsigned seed);
    // Mix the seed so that small seeds (1, 2, 3 ...) give unrelated streams.
    tb_rng_state = {32'(seed) ^ 32'hA5A5_5A5A, 32'(seed) * 32'h9E37_79B1 + 32'h7F4A_7C15};
    if (tb_rng_state == 64'h0) tb_rng_state = 64'h1;
  endfunction

  function automatic logic [63:0] tb_rand64();
    logic [63:0] x;
    x = tb_rng_state;
    x = x ^ (x >> 12);
    x = x ^ (x << 25);
    x = x ^ (x >> 27);
    tb_rng_state = x;
    return x * 64'h2545_F491_4F6C_DD1D;
  endfunction

  function automatic logic [31:0] tb_rand32();
    logic [63:0] r;
    r = tb_rand64();
    return r[63:32];
  endfunction

  // Uniform value in [0, n).  n == 0 returns 0.
  function automatic int unsigned tb_below(input int unsigned n);
    logic [31:0] r;
    if (n == 0) return 0;
    r = tb_rand32();
    return int'(r % n);
  endfunction

  // True with probability pct / 100.
  function automatic logic tb_pct(input int unsigned pct);
    return tb_below(100) < pct;
  endfunction

  function automatic logic [127:0] tb_rand128();
    return {tb_rand64(), tb_rand64()};
  endfunction

  // ---------------------------------------------------------------------------
  // Checks and coverage
  // ---------------------------------------------------------------------------
  function automatic void tb_note_failure(input string msg);
    tb_errors++;
    if (tb_errors <= 20) $display("TB_ERROR: %s", msg);
    if (!tb_failfast_checked) begin
      tb_failfast_checked = 1'b1;
      tb_failfast = $test$plusargs("albion_failfast");
    end
    if (tb_failfast) begin
      $display("ALBION_TB_RESULT failfast FAIL checks=%0d errors=%0d", tb_checks, tb_errors);
      $finish;
    end
  endfunction

  function automatic void tb_check(input logic cond, input string msg);
    tb_checks++;
    if (!cond) tb_note_failure(msg);
  endfunction

  function automatic void tb_fail(input string msg);
    tb_checks++;
    tb_note_failure(msg);
  endfunction

  function automatic void tb_cov(input string bin_name);
    if (tb_cov_cnt.exists(bin_name)) tb_cov_cnt[bin_name]++;
    else                             tb_cov_cnt[bin_name] = 1;
  endfunction

  // Declare a bin with zero hits so an un-hit bin is reported, not silently absent.
  function automatic void tb_cov_declare(input string bin_name);
    if (!tb_cov_cnt.exists(bin_name)) tb_cov_cnt[bin_name] = 0;
  endfunction

  // Print the end-of-test report.  Output format (parsed by report.py):
  //   COV <testbench> <bin> <count>
  //   ALBION_TB_RESULT <testbench> PASS|FAIL checks=<n> errors=<n>
  function automatic void tb_report(input string tb_name);
    string key;
    if (tb_cov_cnt.first(key)) begin
      do begin
        $display("COV %s %s %0d", tb_name, key, tb_cov_cnt[key]);
      end while (tb_cov_cnt.next(key));
    end
    if (tb_errors == 0 && tb_checks > 0)
      $display("ALBION_TB_RESULT %s PASS checks=%0d errors=%0d", tb_name, tb_checks, tb_errors);
    else
      $display("ALBION_TB_RESULT %s FAIL checks=%0d errors=%0d", tb_name, tb_checks, tb_errors);
  endfunction

  // ---------------------------------------------------------------------------
  // Contract constants, restated independently of sf_albion_pkg.
  // Bit offsets of sf_req_t / sf_rsp_t as published in the contract.
  // ---------------------------------------------------------------------------
  localparam int unsigned REQ_OP_LSB   = 232;  // [235:232]
  localparam int unsigned REQ_TAG_LSB  = 224;  // [231:224]
  localparam int unsigned REQ_DOM_LSB  = 216;  // [223:216]
  localparam int unsigned REQ_ATTR_LSB = 208;  // [215:208]
  localparam int unsigned REQ_ADDR_LSB = 144;  // [207:144]
  localparam int unsigned REQ_BE_LSB   = 128;  // [143:128]
  localparam int unsigned REQ_BITS     = 236;
  localparam int unsigned RSP_TAG_LSB  = 140;  // [147:140]
  localparam int unsigned RSP_ST_LSB   = 136;  // [139:136]
  localparam int unsigned RSP_META_LSB = 128;  // [135:128]
  localparam int unsigned RSP_BITS     = 148;

  // Independent reference for ALP-LEG-01: expected status of a request that
  // has no other fault.  `raw` is the 236-bit request vector.
  function automatic logic [3:0] tb_ref_legal_status(input logic [REQ_BITS-1:0] raw);
    logic [3:0]  op;
    logic [63:0] addr;
    logic [15:0] be;
    logic [7:0]  attr;
    logic [7:0]  dom;
    op   = raw[REQ_OP_LSB +: 4];
    addr = raw[REQ_ADDR_LSB +: 64];
    be   = raw[REQ_BE_LSB +: 16];
    attr = raw[REQ_ATTR_LSB +: 8];
    dom  = raw[REQ_DOM_LSB +: 8];
    // opcode: only 1 (READ) and 2 (WRITE) are defined
    if (op != 4'd1 && op != 4'd2)        return 4'h3;  // BAD_OPCODE
    // address must be 16-byte aligned
    if ((addr % 16) != 0)                return 4'h5;  // ALIGN_ERR
    // at least one byte lane must be enabled
    if (be == 16'h0)                     return 4'h4;  // BAD_BE
    // attr[7] reserved must be 0; attr[1:0] == 3 reserved
    if (attr >= 8'd128 || (attr % 4) == 3) return 4'h6;  // BAD_ATTR
    // domain 255 is invalid
    if (dom == 8'd255)                   return 4'h2;  // ACCESS_DENIED
    return 4'h0;
  endfunction

  // Independent reference for the region access check.  ra is the 8-bit
  // region attribute word: [0] read [1] write [2] exec [3] priv_only
  // [4] secure_only [5] cacheable [7:6] memory type.  The request attribute
  // byte: [2] priv [3] secure [4] instr [1:0] memory type.
  function automatic logic [3:0] tb_ref_access_status(input logic [7:0]          ra,
                                                      input logic [REQ_BITS-1:0] raw);
    logic [3:0] op;
    logic [7:0] attr;
    logic       reg_read, reg_write, reg_exec, reg_priv_only, reg_sec_only;
    logic [1:0] reg_mt, req_mt;
    logic       req_priv, req_secure, req_instr;
    op            = raw[REQ_OP_LSB +: 4];
    attr          = raw[REQ_ATTR_LSB +: 8];
    reg_read      = ra[0];
    reg_write     = ra[1];
    reg_exec      = ra[2];
    reg_priv_only = ra[3];
    reg_sec_only  = ra[4];
    reg_mt        = ra[7:6];
    req_mt        = attr[1:0];
    req_priv      = attr[2];
    req_secure    = attr[3];
    req_instr     = attr[4];
    if (op == 4'd1 && !reg_read)                 return 4'h2;
    if (op == 4'd2 && !reg_write)                return 4'h2;
    if (req_instr && !reg_exec)                  return 4'h2;
    if (reg_priv_only && !req_priv)              return 4'h2;
    if (reg_sec_only && !req_secure)             return 4'h2;
    if (reg_mt == 2'd2 && req_mt != 2'd2)        return 4'h6;
    return 4'h0;
  endfunction

endpackage

`default_nettype wire
