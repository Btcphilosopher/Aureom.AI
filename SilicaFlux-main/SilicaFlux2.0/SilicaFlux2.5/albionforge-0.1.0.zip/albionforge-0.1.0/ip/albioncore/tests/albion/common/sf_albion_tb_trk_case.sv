// =============================================================================
//  sf_albion_tb_trk_case.sv  --  one sf_albion_tag_tracker test case
//  (testbench only)
// -----------------------------------------------------------------------------
//  A cycle-accurate behavioural model of the documented tracker semantics is
//  compared with EVERY combinational output EVERY cycle:
//    alloc_ready_o / alloc_tag_o (lowest free tag), free_ctx_o, free_drop_o,
//    free_unexpected_o, free_order_err_o, outstanding_o, full_o, empty_o,
//    sticky_err_o.
//  Traffic: random allocate / in-order free / abandon-one / abandon-all, tag
//  exhaustion, simultaneous allocate and free, and injected faults (spurious
//  and out-of-order responses) that must latch the fatal error, block
//  allocation until reset, and leave state otherwise consistent.
// =============================================================================
`default_nettype none

module sf_albion_tb_trk_case #(
  parameter string       NAME        = "trk",
  parameter int unsigned ID          = 0,
  parameter int unsigned NUM_TAGS    = 8,
  parameter int unsigned CTX_W       = 8,
  parameter bit          CHECK_ORDER = 1'b1
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;

  localparam int unsigned CNT_W = $clog2(NUM_TAGS + 1);

  logic clk_i = 1'b0;
  logic rst_ni = 1'b1;
  always #5 clk_i = ~clk_i;

  logic                 alloc_valid, alloc_ready;
  logic [7:0]           alloc_tag;
  logic [CTX_W-1:0]     alloc_ctx;
  logic                 free_valid;
  logic [7:0]           free_tag;
  logic [CTX_W-1:0]     free_ctx;
  logic                 free_drop, free_unexpected, free_order_err;
  logic                 abandon_valid, abandon_all;
  logic [7:0]           abandon_tag;
  logic [CNT_W-1:0]     outstanding;
  logic                 full, empty, sticky;

  sf_albion_tag_tracker #(.NUM_TAGS(NUM_TAGS), .CTX_W(CTX_W), .CHECK_ORDER(CHECK_ORDER)) u_dut (
    .clk_i, .rst_ni,
    .alloc_valid_i(alloc_valid), .alloc_ready_o(alloc_ready), .alloc_tag_o(alloc_tag), .alloc_ctx_i(alloc_ctx),
    .free_valid_i(free_valid), .free_tag_i(free_tag), .free_ctx_o(free_ctx), .free_drop_o(free_drop),
    .free_unexpected_o(free_unexpected), .free_order_err_o(free_order_err),
    .abandon_valid_i(abandon_valid), .abandon_tag_i(abandon_tag), .abandon_all_i(abandon_all),
    .outstanding_o(outstanding), .full_o(full), .empty_o(empty), .sticky_err_o(sticky));

  // ---------------------------------------------------------------- model
  bit          m_busy  [NUM_TAGS];
  bit          m_aband [NUM_TAGS];
  logic [CTX_W-1:0] m_ctx [NUM_TAGS];
  int unsigned m_order [$];
  bit          m_sticky;
  string       pfx;

  int unsigned p_alloc, p_free, p_abandon, p_abandon_all, p_fault;
  int unsigned sticky_cycles;
  bit          need_reset;
  int unsigned ctx_counter;

  function automatic int unsigned count_busy();
    int unsigned n;
    n = 0;
    for (int i = 0; i < NUM_TAGS; i++) if (m_busy[i]) n++;
    return n;
  endfunction

  function automatic int lowest_free();
    for (int i = 0; i < NUM_TAGS; i++) if (!m_busy[i]) return i;
    return -1;
  endfunction

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      alloc_valid <= 1'b0; alloc_ctx <= '0; free_valid <= 1'b0; free_tag <= '0;
      abandon_valid <= 1'b0; abandon_tag <= '0; abandon_all <= 1'b0;
      for (int i = 0; i < NUM_TAGS; i++) begin m_busy[i] = 1'b0; m_aband[i] = 1'b0; m_ctx[i] = '0; end
      m_order.delete();
      m_sticky = 1'b0;
      sticky_cycles = 0;
      need_reset = 1'b0;
      ctx_counter = 1;
    end else begin
      int lf;
      bit exp_ready, tag_busy, exp_unexp, exp_order, exp_ok, exp_drop, alloc_fire;
      bit pre_busy [NUM_TAGS];
      // -------- A. compare the DUT's combinational outputs with the model
      lf        = lowest_free();
      exp_ready = (lf >= 0) && !m_sticky;
      tag_busy  = (free_tag < NUM_TAGS) && m_busy[free_tag % NUM_TAGS];
      exp_unexp = free_valid && !tag_busy;
      exp_order = free_valid && tag_busy && CHECK_ORDER && (m_order.size() == 0 || m_order[0] != int'(free_tag));
      exp_ok    = free_valid && tag_busy && !exp_order;
      exp_drop  = exp_ok && m_aband[free_tag % NUM_TAGS];
      alloc_fire = alloc_valid && exp_ready;
      tb_check(alloc_ready === exp_ready, $sformatf("%s: alloc_ready %b expected %b", pfx, alloc_ready, exp_ready));
      if (exp_ready) tb_check(int'(alloc_tag) == lf, $sformatf("%s: alloc_tag %0d expected lowest free %0d", pfx, alloc_tag, lf));
      tb_check(free_unexpected === exp_unexp, $sformatf("%s: free_unexpected %b expected %b", pfx, free_unexpected, exp_unexp));
      tb_check(free_order_err  === exp_order, $sformatf("%s: free_order_err %b expected %b", pfx, free_order_err, exp_order));
      tb_check(free_drop       === exp_drop,  $sformatf("%s: free_drop %b expected %b", pfx, free_drop, exp_drop));
      if (exp_ok) begin
        tb_check(free_ctx === m_ctx[free_tag % NUM_TAGS], $sformatf("%s: free_ctx %h expected %h", pfx, free_ctx, m_ctx[free_tag % NUM_TAGS]));
        tb_cov({pfx, ".ctx_returned"});
      end
      tb_check(int'(outstanding) == count_busy(), $sformatf("%s: outstanding %0d expected %0d", pfx, outstanding, count_busy()));
      tb_check(full  === (lf < 0),              $sformatf("%s: full wrong", pfx));
      tb_check(empty === (count_busy() == 0),   $sformatf("%s: empty wrong", pfx));
      tb_check(sticky === m_sticky,             $sformatf("%s: sticky_err %b expected %b", pfx, sticky, m_sticky));
      if (alloc_valid && !exp_ready && lf < 0)  tb_cov({pfx, ".alloc_blocked_full"});
      if (alloc_valid && !exp_ready && m_sticky) tb_cov({pfx, ".alloc_blocked_by_fatal_error"});
      if (alloc_fire && exp_ok)                 tb_cov({pfx, ".alloc_and_free_same_cycle"});
      if (exp_drop)                             tb_cov({pfx, ".abandoned_response_flagged_drop"});
      if (exp_unexp)                            tb_cov({pfx, ".unexpected_response_flagged"});
      if (exp_order)                            tb_cov({pfx, ".out_of_order_response_flagged"});
      if (abandon_all)                          tb_cov({pfx, ".abandon_all"});
      if (abandon_valid)                        tb_cov({pfx, ".abandon_one"});
      if (alloc_fire && lf >= 0 && lf < int'(NUM_TAGS) && alloc_tag == 8'd0 && count_busy() != 0) tb_cov({pfx, ".tag0_reused_while_others_busy"});
      // -------- B. update the model with this cycle's inputs
      for (int i = 0; i < NUM_TAGS; i++) pre_busy[i] = m_busy[i];
      if (abandon_all)
        for (int i = 0; i < NUM_TAGS; i++) if (pre_busy[i]) m_aband[i] = 1'b1;
      if (abandon_valid && abandon_tag < NUM_TAGS && pre_busy[abandon_tag % NUM_TAGS]) m_aband[abandon_tag % NUM_TAGS] = 1'b1;
      if (exp_ok) begin
        m_busy[free_tag % NUM_TAGS]  = 1'b0;
        m_aband[free_tag % NUM_TAGS] = 1'b0;
        if (CHECK_ORDER) void'(m_order.pop_front());
      end
      if (alloc_fire) begin
        m_busy[lf]  = 1'b1;
        m_aband[lf] = 1'b0;
        m_ctx[lf]   = alloc_ctx;
        if (CHECK_ORDER) m_order.push_back(lf);
      end
      if (exp_unexp || exp_order) m_sticky = 1'b1;
      if (m_sticky) sticky_cycles = sticky_cycles + 1; else sticky_cycles = 0;
      if (sticky_cycles > 8) need_reset = 1'b1;
      // -------- C. choose the inputs of the next cycle
      alloc_valid   <= tb_below(100) < p_alloc;
      alloc_ctx     <= CTX_W'(ctx_counter);
      ctx_counter    = ctx_counter + 1;
      free_valid    <= 1'b0;
      abandon_valid <= 1'b0;
      abandon_all   <= (tb_below(1000) < p_abandon_all);
      abandon_tag   <= 8'(tb_below(NUM_TAGS + 2));
      if (tb_below(100) < p_abandon) abandon_valid <= 1'b1;
      if (tb_below(100) < p_free) begin
        int unsigned nb;
        nb = count_busy();
        if (tb_below(100) < p_fault) begin
          // injected fault: a tag that is not outstanding, an out-of-range tag, or (when
          // order is checked) an outstanding tag that is not the oldest
          int unsigned kind;
          kind = tb_below(3);
          free_valid <= 1'b1;
          if (kind == 0)      free_tag <= 8'(NUM_TAGS + tb_below(200));
          else if (kind == 1) free_tag <= 8'(tb_below(NUM_TAGS));
          else begin
            free_tag <= 8'(tb_below(NUM_TAGS));
            if (CHECK_ORDER && m_order.size() >= 2) free_tag <= 8'(m_order[1]);
          end
        end else if (nb != 0) begin
          free_valid <= 1'b1;
          if (CHECK_ORDER) free_tag <= 8'(m_order[0]);
          else begin
            // any outstanding tag
            int unsigned pick, seen;
            pick = tb_below(nb); seen = 0;
            for (int i = 0; i < NUM_TAGS; i++) if (m_busy[i]) begin
              if (seen == pick) free_tag <= 8'(i);
              seen++;
            end
          end
        end
      end
    end
  end

  task automatic phase(input int unsigned pa, input int unsigned pf, input int unsigned pab, input int unsigned pall,
                       input int unsigned pfault, input int unsigned cycles);
    @(negedge clk_i);
    p_alloc = pa; p_free = pf; p_abandon = pab; p_abandon_all = pall; p_fault = pfault;
    repeat (cycles) begin
      @(posedge clk_i);
      if (need_reset) begin
        // fatal error latched for a while: recover by reset (ALP-RST-02)
        #3 rst_ni = 1'b0;
        repeat (2) @(posedge clk_i);
        @(negedge clk_i);
        rst_ni = 1'b1;
        tb_cov({pfx, ".reset_recovery_from_fatal_error"});
      end
    end
  endtask

  initial begin
    finished_o = 1'b0;
    pfx = $sformatf("%s%0d", NAME, ID);
    p_alloc = 0; p_free = 0; p_abandon = 0; p_abandon_all = 0; p_fault = 0;
    foreach (m_busy[i]) m_busy[i] = 1'b0;
    for (int b = 0; b < 12; b++) begin end
    tb_cov_declare({pfx, ".ctx_returned"}); tb_cov_declare({pfx, ".alloc_blocked_full"});
    tb_cov_declare({pfx, ".alloc_and_free_same_cycle"}); tb_cov_declare({pfx, ".abandoned_response_flagged_drop"});
    tb_cov_declare({pfx, ".abandon_all"}); tb_cov_declare({pfx, ".abandon_one"});
    tb_cov_declare({pfx, ".unexpected_response_flagged"}); tb_cov_declare({pfx, ".alloc_blocked_by_fatal_error"});
    tb_cov_declare({pfx, ".reset_recovery_from_fatal_error"}); tb_cov_declare({pfx, ".out_of_order_response_flagged"});
    tb_cov_declare({pfx, ".async_reset_mid_traffic"});
    #1 rst_ni = 1'b0;
    repeat (3) @(posedge clk_i);
    @(negedge clk_i);
    rst_ni = 1'b1;
    // exhaust, then drain
    phase(100,   0, 0, 0, 0, 3 * NUM_TAGS + 6);
    phase(  0, 100, 0, 0, 0, 3 * NUM_TAGS + 6);
    // steady states
    phase( 50,  50, 0, 0, 0, 3000);
    phase( 90,  20, 0, 0, 0, 3000);
    phase( 20,  90, 0, 0, 0, 3000);
    phase(100, 100, 0, 0, 0, 2000);                 // simultaneous allocate and free
    // cancellation
    phase( 60,  40, 15, 0, 0, 3000);
    phase( 60,  40, 10, 30, 0, 3000);
    phase( 90,  50, 40, 60, 0, 3000);
    // asynchronous reset in the middle of normal traffic (tags outstanding, some abandoned); every output is
    // compared with the model in every cycle afterwards
    for (int r = 0; r < 6; r++) begin
      phase( 70,  40, 15, 5, 0, 20 + tb_below(60));
      #3 rst_ni = 1'b0;
      repeat (2) @(posedge clk_i);
      @(negedge clk_i);
      rst_ni = 1'b1;
      tb_cov({pfx, ".async_reset_mid_traffic"});
    end
    phase( 60,  50, 10, 5, 0, 300);
    // faults (spurious / out-of-order responses), each followed by a reset recovery
    for (int r = 0; r < 8; r++) phase(60, 50, 10, 10, 6, 600);
    // and back to normal after the last recovery
    phase( 50,  50, 5, 5, 0, 2000);
    finished_o = 1'b1;
  end
endmodule

`default_nettype wire
