// =============================================================================
//  sim_main.cpp  --  generic Verilator main for AlbionCore testbenches
// -----------------------------------------------------------------------------
//  Verilator's generated --binary main does not write coverage data, so the
//  build uses this main instead.  It
//    * runs the timing-aware event loop until $finish or no events remain,
//    * writes line/toggle coverage to the file named by +albion_cov=<path>
//      (default: none),
//    * returns non-zero when the testbench stopped on an error ($fatal, $stop,
//      or a failed assertion).
//
//  Build with  -CFLAGS -DTB_HDR=\"Vxxx.h\" -CFLAGS -DTB_CLS=Vxxx
// =============================================================================
#include <memory>
#include <string>
#include <cstring>
#include <verilated.h>
#include <verilated_cov.h>

#include TB_HDR

int main(int argc, char** argv) {
    const std::unique_ptr<VerilatedContext> ctx{new VerilatedContext};
    ctx->commandArgs(argc, argv);
    ctx->randReset(2);          // randomise initial values: exposes missing resets
    ctx->randSeed(1);

    std::string cov_path;
    for (int i = 1; i < argc; ++i) {
        if (std::strncmp(argv[i], "+albion_cov=", 12) == 0) cov_path = argv[i] + 12;
    }

    const std::unique_ptr<TB_CLS> top{new TB_CLS{ctx.get(), "TOP"}};
    while (!ctx->gotFinish()) {
        top->eval();
        if (!top->eventsPending()) break;
        ctx->time(top->nextTimeSlot());
    }
    top->final();

#if VM_COVERAGE
    if (!cov_path.empty()) ctx->coveragep()->write(cov_path.c_str());
#endif
    return ctx->gotError() ? 1 : 0;
}
