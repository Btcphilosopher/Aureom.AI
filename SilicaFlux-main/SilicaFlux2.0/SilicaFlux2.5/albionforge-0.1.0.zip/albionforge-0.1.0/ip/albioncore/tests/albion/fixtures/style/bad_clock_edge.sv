// expect: S10
`default_nettype none
module sf_albion_fixture_a (input wire logic clk_i, input wire logic d_i, output logic q_o);
  always_ff @(negedge clk_i) q_o <= d_i;
endmodule
`default_nettype wire
