// =============================================================================
//  tb_sf_albion_tag_tracker.sv  --  self-checking test of sf_albion_tag_tracker
//  Tag counts 1,2,3,5,7,8,16,32,256; ordered and unordered completion.
// =============================================================================
`default_nettype none
module tb_sf_albion_tag_tracker;
  localparam int unsigned N = 9;
  logic [N-1:0] fin;
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(0), .NUM_TAGS(1), .CTX_W(3), .CHECK_ORDER(1'b1)) u_case_0 (.finished_o(fin[0]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(1), .NUM_TAGS(2), .CTX_W(8), .CHECK_ORDER(1'b1)) u_case_1 (.finished_o(fin[1]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(2), .NUM_TAGS(3), .CTX_W(5), .CHECK_ORDER(1'b1)) u_case_2 (.finished_o(fin[2]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(3), .NUM_TAGS(5), .CTX_W(16), .CHECK_ORDER(1'b1)) u_case_3 (.finished_o(fin[3]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(4), .NUM_TAGS(8), .CTX_W(8), .CHECK_ORDER(1'b0)) u_case_4 (.finished_o(fin[4]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(5), .NUM_TAGS(16), .CTX_W(8), .CHECK_ORDER(1'b1)) u_case_5 (.finished_o(fin[5]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(6), .NUM_TAGS(7), .CTX_W(4), .CHECK_ORDER(1'b0)) u_case_6 (.finished_o(fin[6]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(7), .NUM_TAGS(32), .CTX_W(12), .CHECK_ORDER(1'b1)) u_case_7 (.finished_o(fin[7]));
  sf_albion_tb_trk_case #(.NAME("tb_sf_albion_tag_tracker"), .ID(8), .NUM_TAGS(256), .CTX_W(8), .CHECK_ORDER(1'b1)) u_case_8 (.finished_o(fin[8]));

  initial begin
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_tag_tracker");
    $finish;
  end
endmodule
`default_nettype wire
