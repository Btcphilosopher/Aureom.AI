// expect:
// A conforming module: no rule may fire on it.
`default_nettype none

module sf_albion_fixture_good #(
  parameter int unsigned WIDTH = 8
) (
  input  wire logic             clk_i,
  input  wire logic             rst_ni,
  input  wire logic [WIDTH-1:0] d_i,
  output logic [WIDTH-1:0]      q_o
);
  if (WIDTH < 1) begin : gen_param_check
    $error("sf_albion_fixture_good: WIDTH must be >= 1");
  end

  logic [WIDTH-1:0] q_d;
  logic [WIDTH-1:0] q_q;

  always_comb q_d = d_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) q_q <= '0;
    else         q_q <= q_d;
  end

  assign q_o = q_q;
endmodule

`default_nettype wire
