// =============================================================================
//  sf_albion_tb_sys_case.sv  --  one randomised system test of the ALP v1 contract
// -----------------------------------------------------------------------------
//  Device under test : the reference target (input skid -> decode -> {ref memory |
//                      error responder} -> in-order merge -> output skid).  With
//                      REGION_ATTR equal to the profile's region attribute word the DUT
//                      is sf_albion_ref_top (the design configured by sf_albion_cfg_pkg);
//                      with another value it is sf_albion_ref_subsystem with the same
//                      parameters, so that every rule of the region access check
//                      (read / write / execute / privilege / security / device type)
//                      can fail and be checked.
//
//  Initiator model   : behavioural driver that uses the RTL sf_albion_tag_tracker
//                      to allocate tags, retire them on responses, abandon
//                      requests, and check ordering.
//
//  Independent checks
//    * sf_albion_link_checker on the link : ALP-REQ-02, RSP-02/03/04/05/07, ORD-01,
//      TAG-01/02, OUT-01, LEG-01, RST-01/02 as assertions on every cycle.
//    * Reference model (this file): a behavioural memory plus the legality /
//      access rules restated in sf_albion_tb_pkg.  Every response is compared
//      field by field (tag, status, metadata, data) with the model's
//      prediction, in order (ALP-ORD-01..03).
//    * Client-level: the tracker's drop / context / error outputs are compared
//      with the driver's own bookkeeping (abandon semantics, ALP-CAN-02).
//
//  Stimulus
//    legal reads / writes with full, partial and single-byte enables, hot-spot
//    addresses (read-after-write), addresses inside the region but beyond the
//    backed memory, addresses outside the region and exactly on / next to both region
//    boundaries, illegal opcodes (including the reserved atomic range), misaligned
//    addresses, zero byte enables, bad attributes, invalid domain, instruction
//    fetches, random and region-tuned privilege / security / memory-type attributes;
//    random back-pressure on both sides in all modes of sf_albion_tb_stall; tag
//    exhaustion; abandoned tags; asynchronous reset in the middle of traffic.
//  FULL = 1 runs the complete schedule (all back-pressure regimes, exhaustion,
//  abandon sweeps, reset rounds, long mixed run); FULL = 0 a shorter one.
//  Coverage bins are named "<NAME>.<bin>" (just "<bin>" when NAME is empty).
// =============================================================================
`default_nettype none

module sf_albion_tb_sys_case #(
  parameter string       NAME        = "",
  parameter int unsigned ID          = 0,
  parameter logic [7:0]  REGION_ATTR = sf_albion_cfg_pkg::CFG_REGION_ATTR,
  parameter bit          FULL        = 1'b1
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;

  localparam string PFX = (NAME == "") ? "" : {NAME, "."};

  localparam int unsigned NUM_TAGS     = sf_albion_cfg_pkg::CFG_NUM_TAGS;
  localparam logic [63:0] REGION_BASE  = sf_albion_cfg_pkg::CFG_REGION_BASE;
  localparam int unsigned REGION_BYTES = sf_albion_cfg_pkg::CFG_REGION_BYTES;
  localparam bit          USE_TOP      = (REGION_ATTR == sf_albion_cfg_pkg::CFG_REGION_ATTR);
  localparam int unsigned MEM_WORDS    = sf_albion_cfg_pkg::CFG_MEM_WORDS;
  localparam int unsigned HOT_WORDS    = (MEM_WORDS < 6) ? MEM_WORDS : 6;
  // Advertised upper bound on outstanding requests of the reference subsystem:
  // input skid (2) + order queue (CFG_MAX_OUT) + output skid (2).  The link checker
  // asserts ALP-OUT-01 against min(tags, bound), so a subsystem that ever accepted
  // more than its advertised bound would be caught whenever the tag pool is larger.
  localparam int unsigned ADVERTISED_MAX_OUT = sf_albion_cfg_pkg::CFG_MAX_OUT + 4;
  localparam int unsigned LINK_MAX           = (NUM_TAGS < ADVERTISED_MAX_OUT) ? NUM_TAGS : ADVERTISED_MAX_OUT;

  logic clk_i = 1'b0;
  logic rst_ni = 1'b1;          // power-on: reset is asserted asynchronously at 1 ns (a real negedge event)
  always #5 clk_i = ~clk_i;

  // ---------------------------------------------------------------- link and DUT
  logic                   req_valid;
  logic                   req_ready;
  sf_albion_pkg::sf_req_t req;
  logic                   rsp_valid;
  logic                   rsp_ready;
  sf_albion_pkg::sf_rsp_t rsp;

  logic probe_merge_err_released, probe_merge_err_waits_for_mem;
  if (USE_TOP) begin : gen_top
    sf_albion_ref_top u_dut (
      .clk_i, .rst_ni,
      .req_valid_i(req_valid), .req_ready_o(req_ready), .req_i(req),
      .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp)
    );
    assign probe_merge_err_released     = u_dut.u_sub.ord_valid && !u_dut.u_sub.ord_head_mem && u_dut.u_sub.err_rsp_valid;
    assign probe_merge_err_waits_for_mem = u_dut.u_sub.ord_valid && u_dut.u_sub.ord_head_mem &&
                                           !u_dut.u_sub.mem_rsp_valid && u_dut.u_sub.err_rsp_valid;
  end else begin : gen_sub
    sf_albion_ref_subsystem #(
      .MAX_OUT       (sf_albion_cfg_pkg::CFG_MAX_OUT),
      .REGION_BASE   (REGION_BASE),
      .REGION_BYTES  (REGION_BYTES),
      .REGION_ATTR   (REGION_ATTR),
      .MEM_WORDS     (MEM_WORDS),
      .MEM_RSP_DEPTH (sf_albion_cfg_pkg::CFG_MEM_RSP_DEPTH),
      .MEM_EXTRA_LAT (sf_albion_cfg_pkg::CFG_MEM_EXTRA_LAT),
      .ERR_RSP_DEPTH (sf_albion_cfg_pkg::CFG_ERR_RSP_DEPTH)
    ) u_dut (
      .clk_i, .rst_ni,
      .req_valid_i(req_valid), .req_ready_o(req_ready), .req_i(req),
      .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp)
    );
    assign probe_merge_err_released     = u_dut.ord_valid && !u_dut.ord_head_mem && u_dut.err_rsp_valid;
    assign probe_merge_err_waits_for_mem = u_dut.ord_valid && u_dut.ord_head_mem &&
                                           !u_dut.mem_rsp_valid && u_dut.err_rsp_valid;
  end

  // ---------------------------------------------------------------- back-pressure
  logic [2:0] src_mode, snk_mode;
  logic       src_go, snk_go;
  sf_albion_tb_stall #(.SEED(32'hC0DE_0001 + 32'(ID) * 32'h1_0000)) u_src_stall (.clk_i, .rst_ni, .mode_i(src_mode), .go_o(src_go));
  sf_albion_tb_stall #(.SEED(32'hC0DE_0002 + 32'(ID) * 32'h1_0000)) u_snk_stall (.clk_i, .rst_ni, .mode_i(snk_mode), .go_o(snk_go));
  assign rsp_ready = snk_go;

  // ---------------------------------------------------------------- protocol checker
  logic [15:0] link_outstanding;
  sf_albion_link_checker #(.MAX_OUTSTANDING(LINK_MAX), .CHECK_LEGALITY(1'b1)) u_link_chk (
    .clk_i, .rst_ni,
    .req_valid_i(req_valid), .req_ready_i(req_ready), .req_i(req),
    .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_i(rsp),
    .waive_req_i(1'b0), .outstanding_o(link_outstanding)
  );

  // ---------------------------------------------------------------- tag tracker (RTL)
  logic                                 trk_alloc_valid;
  logic                                 trk_alloc_ready;
  logic [sf_albion_pkg::SF_TAG_W-1:0]   trk_alloc_tag;
  logic [31:0]                          trk_alloc_ctx;
  logic                                 trk_free_valid;
  logic [sf_albion_pkg::SF_TAG_W-1:0]   trk_free_tag;
  logic [31:0]                          trk_free_ctx;
  logic                                 trk_free_drop, trk_free_unexpected, trk_free_order_err;
  logic                                 trk_abandon_valid, trk_abandon_all;
  logic [sf_albion_pkg::SF_TAG_W-1:0]   trk_abandon_tag;
  logic [$clog2(NUM_TAGS+1)-1:0]        trk_outstanding;
  logic                                 trk_full, trk_empty, trk_sticky;

  sf_albion_tag_tracker #(.NUM_TAGS(NUM_TAGS), .CTX_W(32), .CHECK_ORDER(1'b1)) u_trk (
    .clk_i, .rst_ni,
    .alloc_valid_i(trk_alloc_valid), .alloc_ready_o(trk_alloc_ready), .alloc_tag_o(trk_alloc_tag),
    .alloc_ctx_i(trk_alloc_ctx),
    .free_valid_i(trk_free_valid), .free_tag_i(trk_free_tag), .free_ctx_o(trk_free_ctx),
    .free_drop_o(trk_free_drop), .free_unexpected_o(trk_free_unexpected), .free_order_err_o(trk_free_order_err),
    .abandon_valid_i(trk_abandon_valid), .abandon_tag_i(trk_abandon_tag), .abandon_all_i(trk_abandon_all),
    .outstanding_o(trk_outstanding), .full_o(trk_full), .empty_o(trk_empty), .sticky_err_o(trk_sticky)
  );

  assign trk_free_valid = rsp_valid && rsp_ready;
  assign trk_free_tag   = rsp.tag;

  // ---------------------------------------------------------------- reference model
  typedef struct {
    sf_albion_pkg::sf_rsp_t rsp;
    int unsigned            desc_id;
  } exp_t;

  bit [7:0]    model_mem [bit [63:0]];
  exp_t        exp_q [$];

  function automatic bit [7:0] model_rd(input bit [63:0] a);
    if (model_mem.exists(a)) return model_mem[a];
    return 8'h00;
  endfunction

  // Predict the response to `r` and apply its effect to the model memory.
  // Independent of the RTL: uses the raw-bit rules of sf_albion_tb_pkg.
  function automatic sf_albion_pkg::sf_rsp_t model_exec(input sf_albion_pkg::sf_req_t r);
    logic [235:0]            raw;
    logic [3:0]              st;
    logic [63:0]             off;
    sf_albion_pkg::sf_rsp_t  p;
    raw = r;
    p   = '0;
    st  = tb_ref_legal_status(raw);
    off = r.addr - REGION_BASE;
    if (st == 4'h0) begin
      if (r.addr < REGION_BASE || off >= 64'(REGION_BYTES)) begin                    // fabric decode error
        st = 4'h1;
        // decode wins over the access check: count the requests where both would have failed
        if (tb_ref_access_status(REGION_ATTR, raw) != 4'h0) tb_cov({PFX, "decode_precedes_access"});
      end
    end
    if (st == 4'h0) begin                                                             // access / attribute
      st = tb_ref_access_status(REGION_ATTR, raw);
      if (st == 4'h2) tb_cov({PFX, "region_access_denied"});
      if (st == 4'h6) tb_cov({PFX, "region_bad_attr"});
    end
    if (st == 4'h0 && (off >> 4) >= 64'(MEM_WORDS)) st = 4'h1;                        // device decode error
    p.tag         = r.tag;
    p.status      = st;
    p.meta.last   = 1'b1;
    p.meta.is_write = (r.op == 4'd2);
    if (st == 4'h0) begin
      for (int b = 0; b < 16; b++) begin
        if (r.be[b]) begin
          if (r.op == 4'd2) model_mem[off + 64'(b)] = r.data[b*8 +: 8];
          else              p.data[b*8 +: 8]        = model_rd(off + 64'(b));
        end
      end
    end
    return p;
  endfunction

  // ---------------------------------------------------------------- stimulus generation
  function automatic sf_albion_pkg::sf_req_t gen_req(input logic [7:0] tag);
    sf_albion_pkg::sf_req_t r;
    int unsigned k;
    int unsigned beroll;
    logic [63:0] rnd;
    r = '0;
    r.tag  = tag;
    r.data = tb_rand128();
    // ---- address
    k = tb_below(100);
    if (k < 50)       r.addr = REGION_BASE + 64'(16 * tb_below(HOT_WORDS));
    else if (k < 60)  r.addr = REGION_BASE + 64'(16 * tb_below(MEM_WORDS));
    else if (k < 66)  r.addr = REGION_BASE + 64'(REGION_BYTES) - 64'(16 * (1 + tb_below(REGION_BYTES / 16)));
    else if (k < 70)  r.addr = (REGION_BASE - 64'(16 * (1 + tb_below(64))));
    else if (k < 74)  r.addr = REGION_BASE + 64'(REGION_BYTES) + 64'(16 * tb_below(64));
    else if (k < 90) begin
      // exactly on, just below and just above the two region boundaries (decode versus access precedence)
      case (tb_below(6))
        0:       r.addr = REGION_BASE - 64'd16;
        1:       r.addr = REGION_BASE;
        2:       r.addr = REGION_BASE + 64'(REGION_BYTES) - 64'd16;
        3:       r.addr = REGION_BASE + 64'(REGION_BYTES);
        4:       r.addr = REGION_BASE + 64'(REGION_BYTES) + 64'd16;
        default: r.addr = REGION_BASE + 64'(16 * (MEM_WORDS - 1));          // last backed word
      endcase
    end
    else if (k < 94)  begin rnd = tb_rand64(); r.addr = {rnd[63:4], 4'h0}; end
    else              r.addr = REGION_BASE + 64'(tb_below(REGION_BYTES));      // frequently misaligned
    if (tb_below(100) < 3) r.addr[3:0] = 4'(1 + tb_below(15));                // deliberate misalignment
    // ---- operation
    k = tb_below(100);
    if (k < 46)       r.op = 4'd2;
    else if (k < 92)  r.op = 4'd1;
    else              r.op = 4'(tb_below(16));                                // includes 0 and the atomic range
    // ---- byte enables
    beroll = tb_below(100);
    if (beroll < 50)       r.be = 16'hFFFF;
    else if (beroll < 80)  r.be = 16'(tb_rand32());
    else if (beroll < 92)  r.be = 16'h1 << tb_below(16);
    else                   r.be = 16'h0000;
    // ---- attributes and domain
    r.attr.mem_type = (tb_below(100) < 70) ? 2'(tb_below(3)) : 2'(tb_below(4));
    r.attr.priv     = tb_pct(50);
    r.attr.secure   = tb_pct(50);
    r.attr.instr    = tb_pct(12);
    r.attr.qos      = 2'(tb_below(4));
    r.attr.rsvd     = tb_pct(2);
    r.dom           = tb_pct(2) ? 8'hFF : 8'(tb_below(255));
    // Half of the requests are tuned to the region so that the permissive path is also exercised
    // when the region is strict: they carry the privilege, security level and memory type it asks for.
    if (tb_pct(50)) begin
      if (REGION_ATTR[sf_albion_pkg::SF_RATTR_PRIV_ONLY_BIT])   r.attr.priv     = 1'b1;
      if (REGION_ATTR[sf_albion_pkg::SF_RATTR_SECURE_ONLY_BIT]) r.attr.secure   = 1'b1;
      if (REGION_ATTR[sf_albion_pkg::SF_RATTR_MEMTYPE_LSB +: 2] == 2'd2) r.attr.mem_type = 2'd2;
      if (!REGION_ATTR[sf_albion_pkg::SF_RATTR_EXEC_BIT])        r.attr.instr    = 1'b0;
    end
    return r;
  endfunction

  // ---------------------------------------------------------------- driver state
  sf_albion_pkg::sf_req_t stg_req;           // allocated, waiting to be presented
  logic                   stg_valid;
  int unsigned            stg_desc;
  int unsigned            req_desc;          // descriptor id of the request currently on the link
  int unsigned            next_desc;
  int unsigned            target_total;      // descriptors to issue in total (cumulative)
  int unsigned            issued;
  int unsigned            accepted_reqs;
  int unsigned            completed;
  int unsigned            dropped;
  int unsigned            abandon_pct;       // per-cycle probability, in 1/1000
  int unsigned            abandon_all_pm;    // per-cycle probability of abandon-all, in 1/10000
  bit                     out_set [int];      // tags outstanding in the tracker (model)
  bit                     abandoned [int];    // tags marked abandoned (model)
  int unsigned            ctx_expect [int];   // descriptor id per outstanding tag
  int unsigned            cycles;

  logic                   want_alloc;
  logic                   req_free_next;     // the link register can take a new request at this edge
  logic                   stg_moving;        // the staged request moves onto the link at this edge
  logic                   stg_free_next;     // the staging register is empty or being emptied
  assign req_free_next   = !req_valid || req_ready;
  assign stg_moving      = stg_valid && req_free_next;
  assign stg_free_next   = !stg_valid || req_free_next;
  assign want_alloc      = rst_ni && src_go && (issued < target_total) && stg_free_next;
  assign trk_alloc_valid = want_alloc;
  assign trk_alloc_ctx   = 32'(next_desc);

  logic       prev_abandon_valid;
  logic       prev_abandon_all;
  logic [7:0] prev_abandon_tag;
  logic       req_acc, rsp_acc, alloc_fire_w;
  assign req_acc      = req_valid && req_ready;
  assign rsp_acc      = rsp_valid && rsp_ready;
  assign alloc_fire_w = trk_alloc_valid && trk_alloc_ready;

  // Main per-cycle model.  All DUT/tracker inputs are driven with non-blocking
  // assignments; model state uses blocking assignments.
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      req_valid        <= 1'b0;
      req              <= '0;
      stg_valid        <= 1'b0;
      stg_req          <= '0;
      stg_desc         <= 0;
      req_desc         <= 0;
      issued           <= 0;
      accepted_reqs    = 0;
      completed        = 0;
      dropped          = 0;
      next_desc        <= 0;
      trk_abandon_valid<= 1'b0;
      trk_abandon_all  <= 1'b0;
      trk_abandon_tag  <= '0;
      prev_abandon_valid = 1'b0;
      prev_abandon_all   = 1'b0;
      prev_abandon_tag   = '0;
      model_mem.delete();
      exp_q.delete();
      out_set.delete();
      abandoned.delete();
      ctx_expect.delete();
    end else begin
      cycles = cycles + 1;
      // ---- 1. response accepted: compare with the model and retire the tag
      if (rsp_acc) begin
        if (exp_q.size() == 0) begin
          tb_fail("system: response with no expected response queued");
        end else begin
          exp_t e;
          logic [147:0] got_bits, exp_bits;
          e = exp_q.pop_front();
          got_bits = rsp;
          exp_bits = e.rsp;
          tb_check(got_bits === exp_bits,
            $sformatf("system: response mismatch desc=%0d got=%h expected=%h", e.desc_id, got_bits, exp_bits));
          tb_cov($sformatf("%sstatus_%0d_seen", PFX, e.rsp.status));
          if (e.rsp.status == 4'h0 && !e.rsp.meta.is_write) tb_cov({PFX, "read_ok"});
          if (e.rsp.status == 4'h0 &&  e.rsp.meta.is_write) tb_cov({PFX, "write_ok"});
        end
        // tracker-level checks (pre-edge combinational outputs)
        tb_check(!trk_free_unexpected, "system: tracker reports an unexpected response");
        tb_check(!trk_free_order_err,  "system: tracker reports out-of-order response");
        tb_check(out_set.exists(int'(rsp.tag)), $sformatf("system: response for tag %0d that is not outstanding", rsp.tag));
        if (out_set.exists(int'(rsp.tag))) begin
          bit expect_drop;
          expect_drop = abandoned.exists(int'(rsp.tag));
          tb_check(trk_free_drop == expect_drop,
                   $sformatf("system: tag %0d drop flag %b expected %b", rsp.tag, trk_free_drop, expect_drop));
          if (expect_drop) begin dropped = dropped + 1; tb_cov({PFX, "abandoned_response_dropped"}); end
          else begin
            tb_check(trk_free_ctx == 32'(ctx_expect[int'(rsp.tag)]),
                     $sformatf("system: tag %0d context %0d expected %0d", rsp.tag, trk_free_ctx, ctx_expect[int'(rsp.tag)]));
            completed = completed + 1;
          end
          out_set.delete(int'(rsp.tag));
          abandoned.delete(int'(rsp.tag));
          ctx_expect.delete(int'(rsp.tag));
        end
      end
      // ---- 2. abandon requests driven during the previous cycle take effect now
      if (prev_abandon_all) begin
        foreach (out_set[t]) abandoned[t] = 1'b1;
        tb_cov({PFX, "abandon_all"});
      end
      if (prev_abandon_valid && out_set.exists(int'(prev_abandon_tag))) begin
        abandoned[int'(prev_abandon_tag)] = 1'b1;
        tb_cov({PFX, "abandon_one"});
      end
      // ---- 3. request accepted on the link: run it through the model
      if (req_acc) begin
        exp_t e;
        e.rsp     = model_exec(req);
        e.desc_id = req_desc;
        exp_q.push_back(e);
        accepted_reqs = accepted_reqs + 1;
        tb_cov({PFX, "link_request_accepted"});
        if (link_outstanding == 16'(NUM_TAGS - 1)) tb_cov({PFX, "link_at_max_outstanding"});
      end
      if (req_valid && !req_ready) tb_cov({PFX, "request_back_pressured"});
      if (rsp_valid && !rsp_ready) tb_cov({PFX, "response_back_pressured"});
      if (want_alloc && !trk_alloc_ready) tb_cov({PFX, "tag_exhausted"});
      // ---- 4. tag allocated at this edge: model bookkeeping
      if (alloc_fire_w) begin
        out_set[int'(trk_alloc_tag)]    = 1'b1;
        ctx_expect[int'(trk_alloc_tag)] = next_desc;
      end
      // ---- 5. staging register and link register (all via non-blocking assignment,
      //         because they feed the DUT / tracker combinationally)
      //   moving: the staged request is placed on the link this edge
      //   alloc_fire_w implies the staging register is empty or moving (see want_alloc)
      if (stg_moving) begin
        req       <= stg_req;
        req_desc  <= stg_desc;
        req_valid <= 1'b1;
      end else if (req_free_next) begin
        req_valid <= 1'b0;
      end
      if (alloc_fire_w) begin
        stg_req   <= gen_req(trk_alloc_tag);
        stg_desc  <= next_desc;
        stg_valid <= 1'b1;
        next_desc <= next_desc + 1;
        issued    <= issued + 1;
      end else if (stg_moving) begin
        stg_valid <= 1'b0;
      end
      // ---- 6. choose abandon requests for the next cycle
      prev_abandon_valid = 1'b0;
      prev_abandon_all   = 1'b0;
      trk_abandon_valid <= 1'b0;
      trk_abandon_all   <= 1'b0;
      if (out_set.size() != 0) begin
        if (tb_below(10000) < abandon_all_pm) begin
          trk_abandon_all  <= 1'b1;
          prev_abandon_all = 1'b1;
        end else if (tb_below(1000) < abandon_pct) begin
          int unsigned pick, n;
          int t;
          pick = tb_below(out_set.size());
          n = 0;
          foreach (out_set[tt]) begin
            if (n == pick) t = tt;
            n++;
          end
          trk_abandon_valid <= 1'b1;
          trk_abandon_tag   <= 8'(t);
          prev_abandon_valid = 1'b1;
          prev_abandon_tag   = 8'(t);
        end
      end
    end
  end

  // Sanity: the tracker's outstanding count must equal the model's set size.
  always @(negedge clk_i) begin
    if (rst_ni) begin
      tb_check(int'(trk_outstanding) == out_set.size(),
               $sformatf("system: tracker outstanding %0d but model holds %0d", trk_outstanding, out_set.size()));
      tb_check(!trk_sticky, "system: tracker latched a fatal protocol error");
      if (trk_full) tb_cov({PFX, "tracker_full"});
      if (req_valid && !rsp_valid && exp_q.size() > 1) tb_cov({PFX, "pipelined_requests"});
    end
  end

  // Functional cover points inside the DUT (hierarchical probes, testbench only).
  always @(posedge clk_i) begin
    if (rst_ni) begin
      if (probe_merge_err_released)      tb_cov({PFX, "merge_error_response_released"});
      if (probe_merge_err_waits_for_mem) tb_cov({PFX, "merge_holds_error_behind_slow_memory_response"});
    end
  end

  // ---------------------------------------------------------------- test sequence
  function automatic bit drained();
    return (issued == target_total) && out_set.size() == 0 && !stg_valid && !req_valid &&
           exp_q.size() == 0 && trk_empty;
  endfunction

  task automatic wait_drained(input string what);
    int unsigned guard;
    guard = 0;
    while (!drained() && guard < 200000) begin
      @(posedge clk_i);
      guard++;
    end
    tb_check(drained(), $sformatf("system: not drained (%s): issued=%0d/%0d outstanding=%0d exp=%0d",
                                  what, issued, target_total, out_set.size(), exp_q.size()));
  endtask

  task automatic run_phase(input logic [2:0] sm, input logic [2:0] km, input int unsigned n,
                           input int unsigned apct, input int unsigned apm, input string what);
    @(negedge clk_i);                       // change stimulus away from the sampling edge
    src_mode = sm; snk_mode = km;
    abandon_pct = apct; abandon_all_pm = apm;
    target_total = target_total + n;
    @(posedge clk_i);
    wait_drained(what);
    tb_cov({PFX, "phase_completed"});
  endtask

  // Random back-pressure mode in {0..5, 7}: mode 6 ("never go") can never complete a phase.
  function automatic logic [2:0] pick_mode();
    int unsigned m;
    m = tb_below(7);
    return (m >= 6) ? 3'd7 : 3'(m);
  endfunction

  initial begin
    finished_o = 1'b0;
    cycles = 0;
    src_mode = 3'd0; snk_mode = 3'd0;
    abandon_pct = 0; abandon_all_pm = 0;
    target_total = 0;
    for (int s = 0; s < 12; s++) tb_cov_declare($sformatf("%sstatus_%0d_seen", PFX, s));
    tb_cov_declare({PFX, "read_ok"}); tb_cov_declare({PFX, "write_ok"});
    tb_cov_declare({PFX, "abandon_one"}); tb_cov_declare({PFX, "abandon_all"}); tb_cov_declare({PFX, "abandoned_response_dropped"});
    tb_cov_declare({PFX, "link_request_accepted"}); tb_cov_declare({PFX, "link_at_max_outstanding"});
    tb_cov_declare({PFX, "request_back_pressured"}); tb_cov_declare({PFX, "response_back_pressured"});
    tb_cov_declare({PFX, "tag_exhausted"}); tb_cov_declare({PFX, "tracker_full"}); tb_cov_declare({PFX, "pipelined_requests"});
    tb_cov_declare({PFX, "merge_error_response_released"});
    tb_cov_declare({PFX, "merge_holds_error_behind_slow_memory_response"});
    tb_cov_declare({PFX, "exhaustion_by_tag_limit"}); tb_cov_declare({PFX, "exhaustion_by_link_back_pressure"});
    tb_cov_declare({PFX, "phase_completed"}); tb_cov_declare({PFX, "async_reset_mid_traffic"});
    tb_cov_declare({PFX, "region_access_denied"}); tb_cov_declare({PFX, "region_bad_attr"});
    tb_cov_declare({PFX, "decode_precedes_access"});

    #1 rst_ni = 1'b0;
    repeat (4) @(posedge clk_i);
    @(negedge clk_i);
    rst_ni = 1'b1;
    repeat (3) @(posedge clk_i);

    // 1. full-rate, no back-pressure
    run_phase(3'd0, 3'd0, FULL ? 600 : 300, 0, 0, "full rate");
    // 2. back-pressure regimes (mode 6 "never go" is reserved): every source x sink pair, or a random sample
    if (FULL) begin
      for (int sm = 0; sm < 8; sm++)
        for (int km = 0; km < 8; km++) begin
          if (sm == 6 || km == 6) continue;
          run_phase(sm[2:0], km[2:0], 120, 0, 0, $sformatf("regime src=%0d snk=%0d", sm, km));
        end
    end else begin
      for (int k = 0; k < 12; k++) run_phase(pick_mode(), pick_mode(), 100, 0, 0, "sampled regime");
    end
    if (FULL) begin
      // 3. tag exhaustion: sink stalls completely while the source keeps trying
      @(negedge clk_i);
      src_mode = 3'd0; snk_mode = 3'd6;
      target_total = target_total + 4 * NUM_TAGS + 8;
      repeat (200) @(posedge clk_i);
      // With the sink stalled the source must be stopped, either by the tag limit
      // (NUM_TAGS below the subsystem capacity) or by link back-pressure.
      tb_check(trk_full || (req_valid && !req_ready),
               "system: with the sink stalled neither the tag limit nor link back-pressure stopped the source");
      tb_cov({PFX, trk_full ? "exhaustion_by_tag_limit" : "exhaustion_by_link_back_pressure"});
      $display("SYSTEM_CAPACITY link_outstanding_with_sink_stalled=%0d advertised_bound=%0d tags=%0d",
               link_outstanding, ADVERTISED_MAX_OUT, NUM_TAGS);
      tb_check(int'(link_outstanding) <= ADVERTISED_MAX_OUT, "system: link outstanding above the advertised bound");
      tb_check(int'(link_outstanding) <= NUM_TAGS, "system: link outstanding above NUM_TAGS");
      @(negedge clk_i);
      snk_mode = 3'd0;
      @(posedge clk_i);
      wait_drained("drain after exhaustion");
    end
    // 4. cancellation by abandoning tags, across regimes
    for (int sm = 0; sm < 8; sm++) begin
      if (sm == 6) continue;
      if (!FULL && sm > 2) continue;
      run_phase(sm[2:0], 3'd2, FULL ? 200 : 120, 80, 40, $sformatf("abandon src=%0d", sm));
    end
    // 5. asynchronous reset in the middle of traffic, then full recovery
    for (int round = 0; round < (FULL ? 4 : 2); round++) begin
      @(negedge clk_i);
      src_mode = 3'd1; snk_mode = 3'd2; abandon_pct = 30; abandon_all_pm = 10;
      target_total = target_total + 500;
      repeat (20 + tb_below(80)) @(posedge clk_i);
      #3;
      rst_ni = 1'b0;                      // asynchronous assertion
      target_total = 0;
      #1;
      tb_check(req_valid === 1'b0 && rsp_valid === 1'b0, "system: valid asserted while reset is asserted (ALP-RST-01)");
      repeat (3) @(posedge clk_i);
      @(negedge clk_i);
      rst_ni = 1'b1;
      repeat (2) @(posedge clk_i);
      tb_cov({PFX, "async_reset_mid_traffic"});
      run_phase(3'd3, 3'd3, 150, 20, 5, "recovery after reset");
    end
    // 6. long mixed run
    for (int k = 0; k < (FULL ? 60 : 12); k++) begin
      int unsigned s, d;
      s = tb_below(8); d = tb_below(8);
      if (s == 6) s = 7;
      if (d == 6) d = 7;
      run_phase(3'(s), 3'(d), 200, tb_below(40), tb_below(10), "mixed");
    end

    tb_check(accepted_reqs > 0, "system: no requests were accepted");
    $display("SYSTEM_SUMMARY case=%s attr=%02h cycles=%0d completed=%0d dropped=%0d profile_tags=%0d mem_words=%0d",
             (NAME == "") ? "profile" : NAME, REGION_ATTR, cycles, completed, dropped, NUM_TAGS, MEM_WORDS);
    finished_o = 1'b1;
  end
endmodule

`default_nettype wire
