// =============================================================================
//  tb_sf_albion_err_resp.sv  --  self-checking test of sf_albion_err_resp
//  (depth 1 / 2 / 3 / 4, legality check on and off)
// =============================================================================
`default_nettype none
module tb_sf_albion_err_resp;
  logic [3:0] fin;
  sf_albion_tb_err_case #(.NAME("tb_sf_albion_err_resp"), .ID(0), .DEPTH(1), .CHECK_LEGALITY(1'b1)) u0 (.finished_o(fin[0]));
  sf_albion_tb_err_case #(.NAME("tb_sf_albion_err_resp"), .ID(1), .DEPTH(2), .CHECK_LEGALITY(1'b1)) u1 (.finished_o(fin[1]));
  sf_albion_tb_err_case #(.NAME("tb_sf_albion_err_resp"), .ID(2), .DEPTH(3), .CHECK_LEGALITY(1'b0)) u2 (.finished_o(fin[2]));
  sf_albion_tb_err_case #(.NAME("tb_sf_albion_err_resp"), .ID(3), .DEPTH(4), .CHECK_LEGALITY(1'b1)) u3 (.finished_o(fin[3]));
  initial begin
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_err_resp");
    $finish;
  end
endmodule
`default_nettype wire
