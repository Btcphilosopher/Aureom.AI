// =============================================================================
//  tb_sf_albion_system.sv  --  randomised system test of the ALP v1 contract
// -----------------------------------------------------------------------------
//  Runs sf_albion_tb_sys_case (see there for the checks and the stimulus) once on
//  the hardware profile as configured (complete schedule, sf_albion_ref_top) and once
//  for each of a set of region attribute words that make the region access check
//  fail in every way it can:
//      attr_ro      read-only region                    attr_wo      write-only region
//      attr_noexec  no instruction fetch                attr_priv    privileged access only
//      attr_sec     secure access only                  attr_dev     device memory type
//      attr_strict  privileged + secure + device type   attr_none    nothing is permitted
//  (region attribute byte: bit0 read, bit1 write, bit2 exec, bit3 priv only,
//   bit4 secure only, bit5 cacheable, bits 7:6 memory type, 2 = device).
// =============================================================================
`default_nettype none

module tb_sf_albion_system;
  localparam int unsigned N_CASES = 9;
  logic [N_CASES-1:0] fin;

  sf_albion_tb_sys_case #(.NAME(""),            .ID(0), .FULL(1'b1)) u_case_profile (.finished_o(fin[0]));
  sf_albion_tb_sys_case #(.NAME("attr_ro"),     .ID(1), .REGION_ATTR(8'h01), .FULL(1'b0)) u_case_ro     (.finished_o(fin[1]));
  sf_albion_tb_sys_case #(.NAME("attr_wo"),     .ID(2), .REGION_ATTR(8'h02), .FULL(1'b0)) u_case_wo     (.finished_o(fin[2]));
  sf_albion_tb_sys_case #(.NAME("attr_noexec"), .ID(3), .REGION_ATTR(8'h03), .FULL(1'b0)) u_case_noexec (.finished_o(fin[3]));
  sf_albion_tb_sys_case #(.NAME("attr_priv"),   .ID(4), .REGION_ATTR(8'h0F), .FULL(1'b0)) u_case_priv   (.finished_o(fin[4]));
  sf_albion_tb_sys_case #(.NAME("attr_sec"),    .ID(5), .REGION_ATTR(8'h17), .FULL(1'b0)) u_case_sec    (.finished_o(fin[5]));
  sf_albion_tb_sys_case #(.NAME("attr_dev"),    .ID(6), .REGION_ATTR(8'h83), .FULL(1'b0)) u_case_dev    (.finished_o(fin[6]));
  sf_albion_tb_sys_case #(.NAME("attr_strict"), .ID(7), .REGION_ATTR(8'h9B), .FULL(1'b0)) u_case_strict (.finished_o(fin[7]));
  sf_albion_tb_sys_case #(.NAME("attr_none"),   .ID(8), .REGION_ATTR(8'h00), .FULL(1'b0)) u_case_none   (.finished_o(fin[8]));

  initial begin
    sf_albion_tb_pkg::tb_seed(32'd2026);
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_system");
    $finish;
  end
endmodule

`default_nettype wire
