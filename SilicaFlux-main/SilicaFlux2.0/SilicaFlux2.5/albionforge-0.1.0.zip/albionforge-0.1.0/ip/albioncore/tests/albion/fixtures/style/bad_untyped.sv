// expect: S17
`default_nettype none
module sf_albion_fixture_a #(
  parameter WIDTH = 8
) (
  input  wire clk_i,
  output logic q_o
);
  assign q_o = 1'b0;
endmodule
`default_nettype wire
