// =============================================================================
//  sf_albion_tb_stage_harness.sv  --  self-checking harness for one buffering
//  stage (FIFO / skid buffer / register slice).   Testbench only.
// -----------------------------------------------------------------------------
//  Contains: randomised source, randomised sink, the device under test, an
//  in-order scoreboard, two channel protocol checkers, an occupancy model and
//  functional-coverage bins.
//
//  KIND   0 = sf_albion_fifo   1 = sf_albion_skid   2 = sf_albion_regslice
//  The parent selects the back-pressure regime of source and sink every phase
//  (modes of sf_albion_tb_stall) and raises target_total_i by the number of
//  items for that phase; done_o goes high when every item has been offered,
//  accepted, delivered, compared and the stage is empty.
// =============================================================================
`default_nettype none

module sf_albion_tb_stage_harness #(
  parameter string       NAME  = "stage",
  parameter int unsigned ID    = 0,
  parameter int unsigned KIND  = 0,
  parameter int unsigned WIDTH = 16,
  parameter int unsigned DEPTH = 4,       // FIFO depth
  parameter int unsigned MODE  = 3,       // regslice mode
  parameter logic [31:0] SEED  = 32'h1
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  input  wire logic [2:0]  src_mode_i,
  input  wire logic [2:0]  snk_mode_i,
  input  wire logic [7:0]  flush_pct_i,       // per-cycle flush probability, in 1/256 (FIFO only)
  input  wire int unsigned target_total_i,    // cumulative number of items to offer
  output logic             done_o,
  output int unsigned      accepted_o,
  output int unsigned      delivered_o,
  output int unsigned      occupancy_o,
  output int unsigned      cycle_o
);
  import sf_albion_tb_pkg::*;

  // Capacity of the stage in items, used as an occupancy bound.
  localparam int unsigned CAPACITY =
      (KIND == 0) ? DEPTH :
      (KIND == 1) ? 2 :
      (MODE == 0) ? 0 : (MODE == 1) ? 1 : (MODE == 2) ? 1 : 2;

  // ---------------------------------------------------------------- stimulus
  logic src_go, snk_go;
  sf_albion_tb_stall #(.SEED(SEED ^ 32'h0000_00A1)) u_src_stall (.clk_i, .rst_ni, .mode_i(src_mode_i), .go_o(src_go));
  sf_albion_tb_stall #(.SEED(SEED ^ 32'h0000_00B2)) u_snk_stall (.clk_i, .rst_ni, .mode_i(snk_mode_i), .go_o(snk_go));

  logic [63:0]       rng_q;
  logic [63:0]       rng_next;
  always_comb begin
    rng_next = rng_q;
    rng_next = rng_next ^ (rng_next >> 12);
    rng_next = rng_next ^ (rng_next << 25);
    rng_next = rng_next ^ (rng_next >> 27);
  end

  logic              in_valid;
  logic              in_ready;
  logic [WIDTH-1:0]  in_data;
  logic              out_valid;
  logic              out_ready;
  logic [WIDTH-1:0]  out_data;
  logic              flush;
  logic [$clog2(DEPTH+1)-1:0] fifo_count;
  logic              fifo_full;
  logic              fifo_empty;

  int unsigned       issued_q;
  int unsigned       cycle_q;
  int unsigned       accepted_q;

  assign out_ready = snk_go;
  assign cycle_o   = cycle_q;
  assign accepted_o = accepted_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rng_q      <= {32'h0, SEED} | 64'h1_0000_0000;
      in_valid   <= 1'b0;
      in_data    <= '0;
      issued_q   <= 0;
      cycle_q    <= 0;
      accepted_q <= 0;
      flush      <= 1'b0;
    end else begin
      rng_q   <= rng_next;
      cycle_q <= cycle_q + 1;
      // Flush pulses (FIFO only).  A flush never coincides with the first
      // cycle after reset, so the reset-to-idle path is also exercised cleanly.
      flush   <= (KIND == 0) && (rng_next[47:40] < flush_pct_i);
      if (in_valid && in_ready) begin
        accepted_q <= accepted_q + 1;
        in_valid   <= 1'b0;
      end
      // Offer a new item only if none is pending (or the pending one is being
      // accepted this cycle) -- valid is never withdrawn once raised.
      if ((!in_valid || in_ready) && issued_q < target_total_i && src_go) begin
        in_valid <= 1'b1;
        in_data  <= rng_next[WIDTH-1:0] ^ WIDTH'(issued_q);
        issued_q <= issued_q + 1;
      end
    end
  end

  // ---------------------------------------------------------------- DUT
  if (KIND == 0) begin : gen_fifo
    sf_albion_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH)) u_dut (
      .clk_i, .rst_ni, .flush_i(flush),
      .in_valid_i(in_valid), .in_ready_o(in_ready), .in_data_i(in_data),
      .out_valid_o(out_valid), .out_ready_i(out_ready), .out_data_o(out_data),
      .count_o(fifo_count), .full_o(fifo_full), .empty_o(fifo_empty)
    );
  end else if (KIND == 1) begin : gen_skid
    sf_albion_skid #(.WIDTH(WIDTH)) u_dut (
      .clk_i, .rst_ni,
      .in_valid_i(in_valid), .in_ready_o(in_ready), .in_data_i(in_data),
      .out_valid_o(out_valid), .out_ready_i(out_ready), .out_data_o(out_data)
    );
    assign fifo_count = '0;
    assign fifo_full  = 1'b0;
    assign fifo_empty = 1'b0;
  end else begin : gen_regslice
    sf_albion_regslice #(.WIDTH(WIDTH), .MODE(MODE)) u_dut (
      .clk_i, .rst_ni,
      .in_valid_i(in_valid), .in_ready_o(in_ready), .in_data_i(in_data),
      .out_valid_o(out_valid), .out_ready_i(out_ready), .out_data_o(out_data)
    );
    assign fifo_count = '0;
    assign fifo_full  = 1'b0;
    assign fifo_empty = 1'b0;
  end

  // ---------------------------------------------------------------- checkers
  int unsigned sb_pending, sb_pushed, sb_popped;
  sf_albion_stream_scoreboard #(.WIDTH(WIDTH)) u_sb (
    .clk_i, .rst_ni, .flush_i(flush),
    .in_valid_i(in_valid),   .in_ready_i(in_ready),   .in_data_i(in_data),
    .out_valid_i(out_valid), .out_ready_i(out_ready), .out_data_i(out_data),
    .pending_o(sb_pending), .pushed_o(sb_pushed), .popped_o(sb_popped)
  );
  assign delivered_o = sb_popped;
  assign occupancy_o = sb_pending;

  // The source must obey the channel rules; the DUT's output must too.
  // A FIFO flush may withdraw its own output valid (ALP-CAN-03).
  sf_albion_chan_checker #(.WIDTH(WIDTH)) u_in_chk (
    .clk_i, .rst_ni, .valid_i(in_valid), .ready_i(in_ready), .payload_i(in_data), .waive_i(1'b0));
  sf_albion_chan_checker #(.WIDTH(WIDTH)) u_out_chk (
    .clk_i, .rst_ni, .valid_i(out_valid), .ready_i(out_ready), .payload_i(out_data), .waive_i(flush));

  assign done_o = rst_ni && (issued_q == target_total_i) && !in_valid && (sb_pending == 0) &&
                  ((KIND != 0) || fifo_empty);

  // ---------------------------------------------------------------- model checks (negedge)
  always @(negedge clk_i) begin
    if (!rst_ni) begin
      tb_check(out_valid === 1'b0, $sformatf("%s: out_valid asserted during reset (ALP-RST-01)", NAME));
    end
    if (rst_ni) begin
      tb_check(sb_pending <= CAPACITY || (KIND == 2 && MODE == 0),
               $sformatf("%s: occupancy %0d exceeds capacity %0d", NAME, sb_pending, CAPACITY));
      if (KIND == 0) begin
        tb_check(int'(fifo_count) == sb_pending,
                 $sformatf("%s: count_o=%0d but model holds %0d", NAME, fifo_count, sb_pending));
        tb_check(fifo_full  == (sb_pending == DEPTH), $sformatf("%s: full_o wrong", NAME));
        tb_check(fifo_empty == (sb_pending == 0),     $sformatf("%s: empty_o wrong", NAME));
        tb_check(out_valid  == (sb_pending != 0),     $sformatf("%s: out_valid_o wrong", NAME));
        tb_check(in_ready   == (sb_pending != DEPTH && !flush), $sformatf("%s: in_ready_o wrong", NAME));
      end
      if (KIND == 1) tb_check(out_valid == (sb_pending != 0), $sformatf("%s: skid out_valid vs model", NAME));
    end
  end

  // ---------------------------------------------------------------- functional coverage
  string pfx;
  initial begin
    pfx = $sformatf("%s%0d", NAME, ID);
    tb_cov_declare({pfx, ".in_stalled"});
    tb_cov_declare({pfx, ".out_stalled"});
    tb_cov_declare({pfx, ".src_gap"});
    tb_cov_declare({pfx, ".both_move"});
    tb_cov_declare({pfx, ".sink_idle_ready"});
    tb_cov_declare({pfx, ".phase_done"});
    if (KIND == 0) begin
      tb_cov_declare({pfx, ".reached_full"});
      tb_cov_declare({pfx, ".reached_empty_after_use"});
      tb_cov_declare({pfx, ".push_pop_same_cycle"});
      tb_cov_declare({pfx, ".flush_with_data"});
      tb_cov_declare({pfx, ".flush_while_full"});
      tb_cov_declare({pfx, ".pointer_wrap"});
    end
  end

  logic was_nonempty;
  int unsigned wraps;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      was_nonempty = 1'b0;
      wraps = 0;
    end else begin
      if (in_valid && !in_ready && !flush)  tb_cov({pfx, ".in_stalled"});
      if (out_valid && !out_ready)          tb_cov({pfx, ".out_stalled"});
      if (!in_valid)                        tb_cov({pfx, ".src_gap"});
      if (in_valid && in_ready && out_valid && out_ready) tb_cov({pfx, ".both_move"});
      if (!out_valid && out_ready)          tb_cov({pfx, ".sink_idle_ready"});
      if (done_o)                           tb_cov({pfx, ".phase_done"});
      if (KIND == 0) begin
        if (fifo_full)                                  tb_cov({pfx, ".reached_full"});
        if (was_nonempty && fifo_empty)                 tb_cov({pfx, ".reached_empty_after_use"});
        if (in_valid && in_ready && out_valid && out_ready) tb_cov({pfx, ".push_pop_same_cycle"});
        if (flush && !fifo_empty)                       tb_cov({pfx, ".flush_with_data"});
        if (flush && fifo_full)                         tb_cov({pfx, ".flush_while_full"});
        if (in_valid && in_ready) begin
          wraps++;
          if (wraps == DEPTH) tb_cov({pfx, ".pointer_wrap"});
        end
        if (!fifo_empty) was_nonempty = 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
