// =============================================================================
//  sf_albion_link_checker_narrow.sv  --  ALP v1 checker for a link of any data width
// -----------------------------------------------------------------------------
//  sf_albion_link_checker is written for the 128-bit package structs.  A narrow
//  link (see sf_albion_width_adapter) carries the same fields with NW-bit data,
//  so it gets this flat-port twin.  The rule labels are the same, so the
//  traceability tool treats both files as evidence for the same contract rules.
//
//    ALP-OUT-01  accepted requests never exceed MAX_OUTSTANDING
//    ALP-TAG-01  a tag is not reused while its transaction is outstanding
//    ALP-LEG-01  legality at this link's word size (NW/8 bytes): opcode READ/WRITE,
//                address aligned to NW/8, byte enables non-zero, attributes, domain
//                  REQ_MUST_BE_LEGAL = 1  every request must be legal (the initiator is
//                                         an adapter that must not forward illegal requests)
//                  CHECK_RSP = 1          an illegal request is answered with its
//                                         legality status (precedence as in the package)
//    ALP-RSP-03  a response never appears without an earlier accepted request
//    ALP-RST-01  valids are low while reset is asserted
//    ALP-RST-02  reset abandons all outstanding transactions (counter cleared)
//  and, when CHECK_RSP = 1 (the target is expected to be conforming)
//    ALP-ORD-01  the response tag equals the tag of the oldest outstanding request
//    ALP-RSP-04  the response operation equals the request's
//    ALP-RSP-05  the response is well-formed (sf_rsp_wellformed_bits)
//    ALP-RSP-07  a read response carries zero in every byte lane that was not enabled
//  CHECK_RSP = 0 is for a link whose target injects faults on purpose: responses
//  are then only counted (in order), and the tag freed is the oldest request's.
//
//  The channel stability rules (ALP-REQ-02 / ALP-RSP-02) are checked by
//  sf_albion_chan_checker instances next to this module.
// =============================================================================
`default_nettype none

module sf_albion_link_checker_narrow #(
  parameter int unsigned NW              = 32,
  parameter int unsigned MAX_OUTSTANDING = 8,
  parameter bit          CHECK_RSP       = 1'b1,
  parameter bit          REQ_MUST_BE_LEGAL = 1'b0
) (
  input wire logic                                   clk_i,
  input wire logic                                   rst_ni,
  input wire logic                                   req_valid_i,
  input wire logic                                   req_ready_i,
  input wire logic [sf_albion_pkg::SF_OP_W-1:0]      req_op_i,
  input wire logic [sf_albion_pkg::SF_TAG_W-1:0]     req_tag_i,
  input wire logic [sf_albion_pkg::SF_DOM_W-1:0]     req_dom_i,
  input wire logic [sf_albion_pkg::SF_ATTR_W-1:0]    req_attr_i,
  input wire logic [sf_albion_pkg::SF_ADDR_W-1:0]    req_addr_i,
  input wire logic [NW/8-1:0]                        req_be_i,
  input wire logic                                   rsp_valid_i,
  input wire logic                                   rsp_ready_i,
  input wire logic [sf_albion_pkg::SF_TAG_W-1:0]     rsp_tag_i,
  input wire logic [sf_albion_pkg::SF_STATUS_W-1:0]  rsp_status_i,
  input wire logic [sf_albion_pkg::SF_CMETA_W-1:0]   rsp_meta_i,
  input wire logic [NW-1:0]                          rsp_data_i,
  output logic [15:0]                                outstanding_o
);
  localparam int unsigned NB      = NW / 8;
  localparam int unsigned NLANE_W = $clog2(NB);
  localparam int unsigned CNT_W   = $clog2(MAX_OUTSTANDING + 1);
  localparam int unsigned PTR_W   = (MAX_OUTSTANDING > 1) ? $clog2(MAX_OUTSTANDING) : 1;

  if (MAX_OUTSTANDING < 1 || MAX_OUTSTANDING > sf_albion_pkg::SF_MAX_OUTSTANDING_LIMIT) begin : gen_param_check
    $error("sf_albion_link_checker_narrow: MAX_OUTSTANDING out of range");
  end
  if (NW != 8 && NW != 16 && NW != 32 && NW != 64) begin : gen_param_check_width
    $error("sf_albion_link_checker_narrow: NW must be 8, 16, 32 or 64");
  end

  logic [CNT_W-1:0]                                   cnt_q;
  logic [PTR_W-1:0]                                   wr_ptr_q;
  logic [PTR_W-1:0]                                   rd_ptr_q;
  logic [sf_albion_pkg::SF_TAG_W-1:0]                 q_tag      [MAX_OUTSTANDING];
  logic                                               q_is_write [MAX_OUTSTANDING];
  logic [sf_albion_pkg::SF_STATUS_W-1:0]              q_legal    [MAX_OUTSTANDING];
  logic [NB-1:0]                                      q_be       [MAX_OUTSTANDING];
  logic [sf_albion_pkg::SF_MAX_OUTSTANDING_LIMIT-1:0] busy_q;

  logic req_acc, rsp_acc, rsp_retire, cnt_nonzero;
  assign req_acc     = req_valid_i && req_ready_i;
  assign rsp_acc     = rsp_valid_i && rsp_ready_i;
  assign cnt_nonzero = (cnt_q != '0);
  assign rsp_retire  = rsp_acc && cnt_nonzero;

  logic [sf_albion_pkg::SF_TAG_W-1:0] head_tag;
  logic                               head_is_write;
  logic [sf_albion_pkg::SF_STATUS_W-1:0] head_legal;
  assign head_tag      = q_tag[rd_ptr_q];
  assign head_is_write = q_is_write[rd_ptr_q];
  assign head_legal    = q_legal[rd_ptr_q];
  logic [NW-1:0] head_unsel;      // data bits of the byte lanes NOT enabled by the oldest request
  always_comb begin
    for (int unsigned b = 0; b < NB; b++) head_unsel[b*8 +: 8] = {8{!q_be[rd_ptr_q][b]}};
  end
  assign outstanding_o = 16'(cnt_q);

  // legality at this link's word size, restated here (independent of the package function)
  logic req_misaligned;
  logic [sf_albion_pkg::SF_STATUS_W-1:0] req_legal;     // 0 = legal, else the status to answer with
  assign req_misaligned = (NLANE_W > 0) && (req_addr_i[(NLANE_W > 0 ? NLANE_W : 1)-1:0] != '0);
  always_comb begin
    if (req_op_i != sf_albion_pkg::SF_OP_READ && req_op_i != sf_albion_pkg::SF_OP_WRITE) req_legal = 4'd3;  // BAD_OPCODE
    else if (req_misaligned)                                                            req_legal = 4'd5;  // ALIGN_ERR
    else if (req_be_i == '0)                                                            req_legal = 4'd4;  // BAD_BE
    else if (req_attr_i[7] || req_attr_i[1:0] == 2'd3)                                  req_legal = 4'd6;  // BAD_ATTR
    else if (req_dom_i == 8'hFF)                                                        req_legal = 4'd2;  // ACCESS_DENIED
    else                                                                                req_legal = 4'd0;
  end

  function automatic logic [PTR_W-1:0] ptr_inc(input logic [PTR_W-1:0] p);
    if (p == PTR_W'(MAX_OUTSTANDING - 1)) ptr_inc = '0;
    else                                   ptr_inc = p + 1'b1;
  endfunction

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cnt_q    <= '0;
      wr_ptr_q <= '0;
      rd_ptr_q <= '0;
      busy_q   <= '0;
    end else begin
      if (req_acc && cnt_q < CNT_W'(MAX_OUTSTANDING)) begin
        q_tag[wr_ptr_q]      <= req_tag_i;
        q_is_write[wr_ptr_q] <= (req_op_i == sf_albion_pkg::SF_OP_WRITE);
        q_legal[wr_ptr_q]    <= req_legal;
        q_be[wr_ptr_q]       <= req_be_i;
        wr_ptr_q             <= ptr_inc(wr_ptr_q);
        busy_q[req_tag_i]    <= 1'b1;
      end
      if (rsp_retire) begin
        rd_ptr_q         <= ptr_inc(rd_ptr_q);
        busy_q[head_tag] <= 1'b0;
      end
      if (req_acc && cnt_q < CNT_W'(MAX_OUTSTANDING) && !rsp_retire)      cnt_q <= cnt_q + 1'b1;
      else if (!(req_acc && cnt_q < CNT_W'(MAX_OUTSTANDING)) && rsp_retire) cnt_q <= cnt_q - 1'b1;
    end
  end

  always_ff @(posedge clk_i) begin
    if (rst_ni) begin
      a_alp_out_01: assert (!req_acc || (cnt_q < CNT_W'(MAX_OUTSTANDING)));
      a_alp_tag_01: assert (!req_acc || !busy_q[req_tag_i]);
      a_alp_leg_01_req: assert (!REQ_MUST_BE_LEGAL || !req_acc || (req_legal == 4'd0));
      a_alp_rsp_03: assert (!rsp_valid_i || cnt_nonzero);
      if (CHECK_RSP) begin
        a_alp_ord_01: assert (!rsp_valid_i || !cnt_nonzero || (rsp_tag_i == head_tag));
        a_alp_rsp_04: assert (!rsp_valid_i || !cnt_nonzero ||
                              (rsp_meta_i[sf_albion_pkg::SF_CMETA_IS_WRITE_BIT] == head_is_write));
        a_alp_rsp_07: assert (!rsp_valid_i || !cnt_nonzero || ((rsp_data_i & head_unsel) == '0));
        a_alp_leg_01: assert (!rsp_valid_i || !cnt_nonzero || (head_legal == 4'd0) || (rsp_status_i == head_legal));
        a_alp_rsp_05: assert (!rsp_valid_i || sf_albion_pkg::sf_rsp_wellformed_bits(
                                {rsp_tag_i, rsp_status_i, rsp_meta_i, {(sf_albion_pkg::SF_DATA_W-NW){1'b0}}, rsp_data_i}));
      end
    end
    a_alp_rst_01_req: assert (rst_ni || !req_valid_i);
    a_alp_rst_01_rsp: assert (rst_ni || !rsp_valid_i);
    a_alp_rst_02:     assert (rst_ni || (cnt_q == '0));
  end
endmodule

`default_nettype wire
