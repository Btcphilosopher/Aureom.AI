// expect: S08
`default_nettype none
module sf_albion_fixture_a (input wire logic d_i, output logic q_o);
  always_comb begin
    q_o <= d_i;
  end
endmodule
`default_nettype wire
