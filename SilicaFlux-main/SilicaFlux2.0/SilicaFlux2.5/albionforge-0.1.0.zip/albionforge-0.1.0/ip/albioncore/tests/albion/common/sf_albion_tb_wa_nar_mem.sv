// =============================================================================
//  sf_albion_tb_wa_nar_mem.sv  --  behavioural narrow-link ALP target with
//  fault injection (testbench only)
// -----------------------------------------------------------------------------
//  Implements a target for a flat ALP link of data width NW:
//    * legality at the link's own word size (opcode, NW/8-byte alignment,
//      byte enables, attributes, domain), written independently of the package
//    * deterministic fault injection by address (see sf_albion_tb_fault_pkg
//      below): TARGET_ERR, TIMEOUT, ECC_UNCORR on selected beats and a
//      "corrected" flag on some beats of any status
//    * deterministic PROTOCOL VIOLATIONS by beat sequence number (VIOLATE = 1):
//      the response of a selected beat has the wrong tag, the wrong operation
//      flag, an out-of-range status, last = 0, a reserved metadata bit, an
//      inconsistent poisoned flag, or data on an error / write completion.  The
//      access itself is performed as usual; only the response is corrupted.
//    * random response latency (>= 1 cycle, occasionally long) and random
//      back-pressure; up to QDEPTH beats can be outstanding
//    * in-order responses; executes in acceptance order; a faulty beat has NO
//      effect on memory
// =============================================================================
`default_nettype none

package sf_albion_tb_fault_pkg;
  // Deterministic fault model shared by the narrow memory and the reference model.
  // Returns 0 (no fault) or the status code to inject for a beat at `addr`.
  function automatic logic [3:0] nar_fault(input logic [63:0] addr);
    logic [63:0] x;
    x = (addr >> 2) ^ (addr >> 7) ^ (addr >> 13);
    x = x % 61;
    if (x == 5)  return 4'd7;     // TARGET_ERR
    if (x == 23) return 4'd8;     // TIMEOUT
    if (x == 41) return 4'd10;    // ECC_UNCORR
    return 4'd0;
  endfunction

  // True when a conforming beat at `addr` reports a corrected error (any status).
  function automatic logic nar_corrected(input logic [63:0] addr);
    logic [63:0] x;
    x = (addr >> 3) % 7;
    return (x == 3);
  endfunction

  // Protocol violation injected into the response of the beat with sequence number
  // `seq` (counted from reset).  Returns 0 (none) or the violation kind:
  //   1 wrong tag  2 wrong is_write flag  3 status 14  4 last = 0
  //   5 reserved metadata bit set  6 poisoned flag inconsistent with the status
  //   7 non-zero data on an error or write completion (only effective then)
  // `is_wr` is the beat's operation, `st` its underlying status.
  function automatic logic [2:0] nar_violation(input int unsigned seq, input logic is_wr,
                                               input logic [3:0] st);
    logic [31:0] h;
    logic [2:0]  kind;
    h = 32'(seq) * 32'd2654435761;
    h = (h >> 11) ^ h;
    case (h % 211)
      32'd5:   kind = 3'd1;
      32'd23:  kind = 3'd2;
      32'd47:  kind = 3'd3;
      32'd71:  kind = 3'd4;
      32'd97:  kind = 3'd5;
      32'd131: kind = 3'd6;
      32'd167: kind = 3'd7;
      default: kind = 3'd0;
    endcase
    if (kind == 3'd7 && st == 4'd0 && !is_wr) kind = 3'd0;      // data is legitimate on a good read
    return kind;
  endfunction

  // The same violation kinds for the WIDE target of an upsizing adapter, chosen by the
  // request tag (the testbench numbers requests 0, 1, 2 ... so every kind occurs).
  function automatic logic [2:0] wide_violation(input logic [7:0] tag, input logic is_wr,
                                                input logic [3:0] st);
    logic [2:0] kind;
    case (tag % 8'd29)
      8'd3:    kind = 3'd1;
      8'd7:    kind = 3'd2;
      8'd11:   kind = 3'd3;
      8'd15:   kind = 3'd4;
      8'd19:   kind = 3'd5;
      8'd23:   kind = 3'd6;
      8'd27:   kind = 3'd7;
      default: kind = 3'd0;
    endcase
    if (kind == 3'd7 && st == 4'd0 && !is_wr) kind = 3'd0;
    return kind;
  endfunction

  // A conforming wide response that reports a corrected error (informational).
  function automatic logic wide_corrected(input logic [7:0] tag);
    return (tag % 8'd9) == 8'd4;
  endfunction
endpackage

module sf_albion_tb_wa_nar_mem #(
  parameter int unsigned NW         = 32,
  parameter logic [31:0] SEED       = 32'h77,
  parameter bit          FAULTS     = 1'b1,
  parameter bit          VIOLATE    = 1'b1,
  parameter int unsigned QDEPTH     = 24,
  parameter int unsigned LONG_PCT   = 12       // % of beats that get up to 24 extra cycles of latency
) (
  input  wire logic            clk_i,
  input  wire logic            rst_ni,
  input  wire logic [2:0]      accept_mode_i,
  input  wire logic [2:0]      resp_mode_i,
  input  wire logic            req_valid_i,
  output logic                 req_ready_o,
  input  wire logic [3:0]      req_op_i,
  input  wire logic [7:0]      req_tag_i,
  input  wire logic [7:0]      req_dom_i,
  input  wire logic [7:0]      req_attr_i,
  input  wire logic [63:0]     req_addr_i,
  input  wire logic [NW/8-1:0] req_be_i,
  input  wire logic [NW-1:0]   req_data_i,
  output logic                 rsp_valid_o,
  input  wire logic            rsp_ready_i,
  output logic [7:0]           rsp_tag_o,
  output logic [3:0]           rsp_status_o,
  output logic [7:0]           rsp_meta_o,
  output logic [NW-1:0]        rsp_data_o
);
  import sf_albion_tb_pkg::*;
  import sf_albion_tb_fault_pkg::*;
  localparam int unsigned NB = NW / 8;

  typedef struct {
    logic [7:0]    tag;
    logic [3:0]    status;
    logic [7:0]    meta;
    logic [NW-1:0] data;
    int unsigned   due;
    logic [2:0]    kind;
  } ent_t;

  bit [7:0]    mem [bit [63:0]];
  ent_t        q [$];
  int unsigned now;
  int unsigned seq;
  logic        acc_go, rsp_go;
  logic        rsp_valid_q;
  logic        room_q;        // registered: queue has room (DUT-visible values must change by NBA only)
  ent_t        cur_q;

  sf_albion_tb_stall #(.SEED(SEED ^ 32'h51)) u_acc (.clk_i, .rst_ni, .mode_i(accept_mode_i), .go_o(acc_go));
  sf_albion_tb_stall #(.SEED(SEED ^ 32'h52)) u_rsp (.clk_i, .rst_ni, .mode_i(resp_mode_i),   .go_o(rsp_go));

  assign req_ready_o = acc_go && room_q && rst_ni;
  assign rsp_valid_o = rsp_valid_q;
  assign rsp_tag_o   = cur_q.tag;
  assign rsp_status_o= cur_q.status;
  assign rsp_meta_o  = cur_q.meta;
  assign rsp_data_o  = cur_q.data;

  // Independent legality at this link's word size.
  function automatic logic [3:0] nar_legal(input logic [3:0] op, input logic [63:0] addr,
                                           input logic [NB-1:0] be, input logic [7:0] attr,
                                           input logic [7:0] dom);
    if (op != 4'd1 && op != 4'd2)      return 4'd3;
    if ((addr % NB) != 0)              return 4'd5;
    if (be == '0)                      return 4'd4;
    if (attr >= 8'd128 || (attr % 4) == 3) return 4'd6;
    if (dom == 8'd255)                 return 4'd2;
    return 4'd0;
  endfunction

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mem.delete();
      q.delete();
      now         = 0;
      seq         = 0;
      rsp_valid_q <= 1'b0;
      room_q      <= 1'b1;
      cur_q       <= '{default: '0};
    end else begin
      ent_t e;
      ent_t nxt;
      logic [3:0] st;
      now = now + 1;
      if (req_valid_i && req_ready_o) begin
        e.tag    = req_tag_i;
        e.meta   = {4'b0000, 1'b0, 1'b0, 1'b1, (req_op_i == 4'd2)};
        e.data   = '0;
        e.status = 4'd0;
        e.due    = now + 1 + tb_below(4) + ((tb_below(100) < LONG_PCT) ? tb_below(25) : 0);
        e.kind   = 3'd0;
        st = nar_legal(req_op_i, req_addr_i, req_be_i, req_attr_i, req_dom_i);
        if (st == 4'd0 && FAULTS) st = nar_fault(req_addr_i);
        e.status = st;
        if (st == 4'd10) e.meta[2] = 1'b1;                    // poisoned
        if (FAULTS && nar_corrected(req_addr_i)) e.meta[3] = 1'b1;
        if (VIOLATE) e.kind = nar_violation(seq, req_op_i == 4'd2, st);
        seq = seq + 1;
        if (st == 4'd0) begin
          for (int b = 0; b < NB; b++) begin
            if (req_be_i[b]) begin
              if (req_op_i == 4'd2) mem[req_addr_i + 64'(b)] = req_data_i[b*8 +: 8];
              else begin
                if (mem.exists(req_addr_i + 64'(b))) e.data[b*8 +: 8] = mem[req_addr_i + 64'(b)];
              end
            end
          end
        end
        q.push_back(e);
      end
      if (rsp_valid_q && rsp_ready_i) rsp_valid_q <= 1'b0;
      if ((!rsp_valid_q || rsp_ready_i) && q.size() != 0 && q[0].due <= now && rsp_go) begin
        nxt = q.pop_front();
        case (nxt.kind)
          3'd1:    nxt.tag      = nxt.tag + 8'd1;
          3'd2:    nxt.meta[0]  = ~nxt.meta[0];
          3'd3:    nxt.status   = 4'd14;
          3'd4:    nxt.meta[1]  = 1'b0;
          3'd5:    nxt.meta[7]  = 1'b1;
          3'd6:    nxt.meta[2]  = ~nxt.meta[2];
          3'd7:    nxt.data     = '1;
          default: ;
        endcase
        cur_q       <= nxt;
        rsp_valid_q <= 1'b1;
      end
      room_q <= (q.size() < QDEPTH);
    end
  end
endmodule

`default_nettype wire
