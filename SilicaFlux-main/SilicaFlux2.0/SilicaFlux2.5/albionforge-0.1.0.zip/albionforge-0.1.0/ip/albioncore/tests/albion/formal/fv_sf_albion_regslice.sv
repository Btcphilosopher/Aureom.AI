// =============================================================================
//  fv_sf_albion_regslice.sv  --  formal wrapper for sf_albion_regslice
//                                (MODE 3 is the sf_albion_skid buffer)
// -----------------------------------------------------------------------------
//  KIND 0 : DUT = sf_albion_regslice #(.MODE(MODE))
//  KIND 1 : DUT = sf_albion_skid  (same properties as MODE 3)
//
//  Proved for every input sequence, with reset allowed at any time after the
//  first cycle:
//    RS-1  no loss, duplication or reordering (symbolic watch item), including
//          an item accepted and delivered in the same cycle (bypass, backward)
//    RS-2  occupancy never exceeds the storage of the mode (0 / 1 / 1 / 2)
//    RS-3  exact in_ready / out_valid behaviour per mode, which pins down which
//          combinational paths exist (none from in_valid or data to in_ready)
//    RS-4  output valid and data are stable until accepted
//    RS-5  out_valid is low while reset is asserted
//  COVER_IDX >= 0 selects reachability mode (see fv_sf_albion_fifo.sv).
// =============================================================================
module fv_sf_albion_regslice #(
  parameter integer WIDTH     = 2,
  parameter integer MODE      = 3,
  parameter integer KIND      = 0,
  parameter integer COVER_IDX = -1
) (
  input  wire             clk_i,
  input  wire             rst_ni,
  input  wire             in_valid_i,
  input  wire [WIDTH-1:0] in_data_i,
  input  wire             out_ready_i
);
  localparam integer EMODE = (KIND == 1) ? 3 : MODE;        // effective mode
  localparam integer CAP   = (EMODE == 0) ? 0 : (EMODE == 3) ? 2 : 1;
  localparam integer IW    = 2;                              // modulus 4 > CAP
  localparam         PROVE = (COVER_IDX < 0);

  wire             in_ready;
  wire             out_valid;
  wire [WIDTH-1:0] out_data;

  generate
    if (KIND == 1) begin : gen_skid
      sf_albion_skid #(.WIDTH(WIDTH)) dut (
        .clk_i(clk_i), .rst_ni(rst_ni),
        .in_valid_i(in_valid_i), .in_ready_o(in_ready), .in_data_i(in_data_i),
        .out_valid_o(out_valid), .out_ready_i(out_ready_i), .out_data_o(out_data));
    end else begin : gen_rs
      sf_albion_regslice #(.WIDTH(WIDTH), .MODE(MODE)) dut (
        .clk_i(clk_i), .rst_ni(rst_ni),
        .in_valid_i(in_valid_i), .in_ready_o(in_ready), .in_data_i(in_data_i),
        .out_valid_o(out_valid), .out_ready_i(out_ready_i), .out_data_o(out_data));
    end
  endgenerate

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  // Environment obligations of the INPUT channel (the contract's rules on the
  // initiator): valid and payload are held until accepted (ALP-REQ-02 / ALP-RSP-02)
  // and valid is low while reset is asserted (ALP-RST-01).  Pass-through modes
  // (bypass, backward) forward in_valid / in_data combinationally, so RS-4 and
  // RS-5 hold only relative to these rules; registered modes need neither.
  sf_albion_chan_checker #(.WIDTH(WIDTH), .ASSUME_MODE(1'b1)) u_env_in (
    .clk_i(clk_i), .rst_ni(rst_ni), .valid_i(in_valid_i), .ready_i(in_ready),
    .payload_i(in_data_i), .waive_i(1'b0));
  always @(*) if (!rst_ni) assume (!in_valid_i);

  wire push = in_valid_i && in_ready;
  wire pop  = out_valid && out_ready_i;

  (* anyconst *) reg [IW-1:0] watch_n;
  reg [IW-1:0]    push_idx_q, pop_idx_q;
  reg [WIDTH-1:0] watch_data_q;
  reg             watch_stored_q;
  wire [IW-1:0]   count = push_idx_q - pop_idx_q;           // items stored at cycle start

  wire push_is_watch = push && (push_idx_q == watch_n);

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      push_idx_q     <= {IW{1'b0}};
      pop_idx_q      <= {IW{1'b0}};
      watch_stored_q <= 1'b0;
      watch_data_q   <= {WIDTH{1'b0}};
    end else begin
      if (push) push_idx_q <= push_idx_q + 1'b1;
      if (pop)  pop_idx_q  <= pop_idx_q + 1'b1;
      if (push_is_watch) begin
        watch_stored_q <= 1'b1;
        watch_data_q   <= in_data_i;
      end
    end
  end

  reg             hold_q;
  reg [WIDTH-1:0] data_q;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin hold_q <= 1'b0; data_q <= {WIDTH{1'b0}}; end
    else begin hold_q <= out_valid && !out_ready_i; data_q <= out_data; end
  end

  wire [WIDTH-1:0] expected_watch = push_is_watch ? in_data_i : watch_data_q;

  always @(posedge clk_i) begin
    if (PROVE && rst_ni && !init_q) begin
      // RS-1
      if (pop && pop_idx_q == watch_n) begin
        a_rs_1_data: assert ((watch_stored_q || push_is_watch) && out_data == expected_watch);
      end
      // RS-2
      a_rs_2_cap: assert (count <= CAP);
      // RS-3
      if (EMODE == 0) begin
        a_rs_3_ready: assert (in_ready  == out_ready_i);
        a_rs_3_valid: assert (out_valid == in_valid_i);
      end
      if (EMODE == 1) begin
        a_rs_3_ready: assert (in_ready  == ((count == 0) || out_ready_i));
        a_rs_3_valid: assert (out_valid == (count != 0));
      end
      if (EMODE == 2) begin
        a_rs_3_ready: assert (in_ready  == (count == 0));
        a_rs_3_valid: assert (out_valid == ((count != 0) || in_valid_i));
      end
      if (EMODE == 3) begin
        a_rs_3_ready: assert (in_ready  == (count != 2));
        a_rs_3_valid: assert (out_valid == (count != 0));
      end
      // RS-4
      if (hold_q) begin
        a_rs_4_valid: assert (out_valid);
        a_rs_4_data:  assert (out_data == data_q);
      end
    end
    // RS-5
    if (PROVE && !rst_ni && !init_q) a_rs_5_reset: assert (!out_valid);
  end

  wire [4:0] cov_vec;
  assign cov_vec[0] = rst_ni && !init_q && (count == CAP) && (CAP > 0);          // storage full
  assign cov_vec[1] = rst_ni && !init_q && push && pop;                           // streaming
  assign cov_vec[2] = rst_ni && !init_q && push_is_watch && pop && pop_idx_q == watch_n; // same-cycle pass
  assign cov_vec[3] = rst_ni && !init_q && pop && pop_idx_q == watch_n && watch_stored_q; // watch delivered later
  assign cov_vec[4] = rst_ni && !init_q && in_valid_i && !in_ready;               // upstream blocked
  always @(posedge clk_i) begin
    if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
  end
endmodule
