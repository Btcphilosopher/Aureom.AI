// =============================================================================
//  sf_albion_tb_wa_case.sv  --  one width-adapter test case (testbench only)
// -----------------------------------------------------------------------------
//  MODE 0  DOWN   wide initiator -> sf_albion_width_adapter(DOWNSIZE=1) -> narrow memory model
//  MODE 1  UP     narrow initiator -> sf_albion_width_adapter(DOWNSIZE=0) -> sf_albion_ref_mem (RTL)
//  MODE 2  CHAIN  narrow initiator -> UP -> (128-bit link) -> DOWN -> narrow memory model
//
//  Every response is compared (tag, status, metadata, data) with an INDEPENDENT
//  model of the whole composition:
//    MODE 0  the wide request is executed beat by beat on the narrow memory:
//            empty beats skipped, faulty beats have no effect, the first fault
//            of a conforming beat gives the status, a NON-CONFORMING beat
//            response (protocol violation injected by the narrow memory) turns
//            the status into PROTOCOL_ERR, read data is zero on any fault,
//            corrected flags of conforming beats merge.  Wide-link legality uses
//            the 128-bit rules.
//    MODE 1  legality at the narrow word size, then the wide memory's range check
//            (offset beyond the memory -> DECODE_ERR), then the byte access.  A
//            shim between the wide memory and the adapter injects protocol
//            violations (-> PROTOCOL_ERR) and corrected flags (forwarded).
//    MODE 2  legality at the narrow word size, then the narrow memory's faults
//            and violations.
//  Illegal requests must be answered by the adapter itself, in order with the
//  forwarded ones.  Protocol checkers watch every link: the full ALP checker on
//  the wide link and sf_albion_link_checker_narrow (tag uniqueness, outstanding bound,
//  legality, response order) on every narrow link; addresses cover all 64 bits.
// =============================================================================
`default_nettype none

module sf_albion_tb_wa_case #(
  parameter string       NAME     = "wa",
  parameter int unsigned ID       = 0,
  parameter int unsigned MODE     = 0,
  parameter int unsigned NW       = 32,
  parameter int unsigned MAX_OUT  = 4,
  parameter int unsigned NUM_REQS = 3000,
  parameter int unsigned MEM_WORDS = 16
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;
  import sf_albion_tb_fault_pkg::*;

  localparam int unsigned WIDE_W = 128;
  localparam int unsigned IW     = (MODE == 0) ? WIDE_W : NW;     // initiator data width
  localparam int unsigned IB     = IW / 8;                         // initiator word bytes
  localparam int unsigned NB     = NW / 8;
  localparam int unsigned RATIO  = WIDE_W / NW;

  logic clk_i = 1'b0;
  logic rst_ni = 1'b1;
  always #5 clk_i = ~clk_i;

  // ---------------------------------------------------------------- initiator link (flat, width IW)
  logic            i_req_valid, i_req_ready;
  logic [3:0]      i_op;
  logic [7:0]      i_tag, i_dom, i_attr;
  logic [63:0]     i_addr;
  logic [IB-1:0]   i_be;
  logic [IW-1:0]   i_data;
  logic            i_rsp_valid, i_rsp_ready;
  logic [7:0]      i_rsp_tag;
  logic [3:0]      i_rsp_status;
  logic [7:0]      i_rsp_meta;
  logic [IW-1:0]   i_rsp_data;

  // ---------------------------------------------------------------- stimulus control
  logic [2:0] src_mode, snk_mode, nm_acc_mode, nm_rsp_mode;
  logic       src_go, snk_go;
  sf_albion_tb_stall #(.SEED(32'hA000_0000 + 32'(ID))) u_src_stall (.clk_i, .rst_ni, .mode_i(src_mode), .go_o(src_go));
  sf_albion_tb_stall #(.SEED(32'hB000_0000 + 32'(ID))) u_snk_stall (.clk_i, .rst_ni, .mode_i(snk_mode), .go_o(snk_go));
  assign i_rsp_ready = snk_go;

  // ---------------------------------------------------------------- DUT chain
  // narrow-memory side flat link (MODE 0 and 2)
  logic            n_req_valid, n_req_ready;
  logic [3:0]      n_op;
  logic [7:0]      n_tag, n_dom, n_attr;
  logic [63:0]     n_addr;
  logic [NB-1:0]   n_be;
  logic [NW-1:0]   n_data;
  logic            n_rsp_valid, n_rsp_ready;
  logic [7:0]      n_rsp_tag;
  logic [3:0]      n_rsp_status;
  logic [7:0]      n_rsp_meta;
  logic [NW-1:0]   n_rsp_data;

  // wide flat link (MODE 1 and 2)
  logic            w_req_valid, w_req_ready;
  logic [3:0]      w_op;
  logic [7:0]      w_tag, w_dom, w_attr;
  logic [63:0]     w_addr;
  logic [15:0]     w_be;
  logic [127:0]    w_data;
  logic            w_rsp_valid, w_rsp_ready;
  logic [7:0]      w_rsp_tag;
  logic [3:0]      w_rsp_status;
  logic [7:0]      w_rsp_meta;
  logic [127:0]    w_rsp_data;

  // the wide link as ALP structs, for the protocol checker (MODE 0: initiator side)
  sf_albion_pkg::sf_req_t wl_req;
  sf_albion_pkg::sf_rsp_t wl_rsp;
  logic                   wl_req_valid, wl_req_ready, wl_rsp_valid, wl_rsp_ready;
  logic [15:0]            wl_outstanding;

  if (MODE == 0) begin : gen_m0
    sf_albion_width_adapter #(.DOWNSIZE(1'b1), .NARROW_W(NW)) u_down (
      .clk_i, .rst_ni,
      .s_req_valid_i(i_req_valid), .s_req_ready_o(i_req_ready), .s_req_op_i(i_op), .s_req_tag_i(i_tag),
      .s_req_dom_i(i_dom), .s_req_attr_i(i_attr), .s_req_addr_i(i_addr), .s_req_be_i(i_be), .s_req_data_i(i_data),
      .s_rsp_valid_o(i_rsp_valid), .s_rsp_ready_i(i_rsp_ready), .s_rsp_tag_o(i_rsp_tag),
      .s_rsp_status_o(i_rsp_status), .s_rsp_meta_o(i_rsp_meta), .s_rsp_data_o(i_rsp_data),
      .m_req_valid_o(n_req_valid), .m_req_ready_i(n_req_ready), .m_req_op_o(n_op), .m_req_tag_o(n_tag),
      .m_req_dom_o(n_dom), .m_req_attr_o(n_attr), .m_req_addr_o(n_addr), .m_req_be_o(n_be), .m_req_data_o(n_data),
      .m_rsp_valid_i(n_rsp_valid), .m_rsp_ready_o(n_rsp_ready), .m_rsp_tag_i(n_rsp_tag),
      .m_rsp_status_i(n_rsp_status), .m_rsp_meta_i(n_rsp_meta), .m_rsp_data_i(n_rsp_data)
    );
    // wide link = the initiator link
    assign wl_req_valid = i_req_valid; assign wl_req_ready = i_req_ready;
    assign wl_req       = {i_op, i_tag, i_dom, i_attr, i_addr, i_be, i_data};
    assign wl_rsp_valid = i_rsp_valid; assign wl_rsp_ready = i_rsp_ready;
    assign wl_rsp       = {i_rsp_tag, i_rsp_status, i_rsp_meta, i_rsp_data};
    // unused wide-link wires of this mode
    assign {w_req_valid, w_op, w_tag, w_dom, w_attr, w_addr, w_be, w_data} = '0;
    assign {w_rsp_ready} = 1'b0;
  end else if (MODE == 1) begin : gen_m1
    sf_albion_width_adapter #(.DOWNSIZE(1'b0), .NARROW_W(NW), .MAX_OUT(MAX_OUT)) u_up (
      .clk_i, .rst_ni,
      .s_req_valid_i(i_req_valid), .s_req_ready_o(i_req_ready), .s_req_op_i(i_op), .s_req_tag_i(i_tag),
      .s_req_dom_i(i_dom), .s_req_attr_i(i_attr), .s_req_addr_i(i_addr), .s_req_be_i(i_be), .s_req_data_i(i_data),
      .s_rsp_valid_o(i_rsp_valid), .s_rsp_ready_i(i_rsp_ready), .s_rsp_tag_o(i_rsp_tag),
      .s_rsp_status_o(i_rsp_status), .s_rsp_meta_o(i_rsp_meta), .s_rsp_data_o(i_rsp_data),
      .m_req_valid_o(w_req_valid), .m_req_ready_i(w_req_ready), .m_req_op_o(w_op), .m_req_tag_o(w_tag),
      .m_req_dom_o(w_dom), .m_req_attr_o(w_attr), .m_req_addr_o(w_addr), .m_req_be_o(w_be), .m_req_data_o(w_data),
      .m_rsp_valid_i(w_rsp_valid), .m_rsp_ready_o(w_rsp_ready), .m_rsp_tag_i(w_rsp_tag),
      .m_rsp_status_i(w_rsp_status), .m_rsp_meta_i(w_rsp_meta), .m_rsp_data_i(w_rsp_data)
    );
    sf_albion_pkg::sf_req_t mem_req;
    sf_albion_pkg::sf_rsp_t mem_rsp;
    logic                   mem_rsp_valid, mem_rsp_ready;
    assign mem_req = {w_op, w_tag, w_dom, w_attr, w_addr, w_be, w_data};
    sf_albion_ref_mem #(.WORDS(MEM_WORDS), .RSP_DEPTH(2), .EXTRA_LAT(1), .INIT_ZERO(1'b1)) u_mem (
      .clk_i, .rst_ni,
      .req_valid_i(w_req_valid), .req_ready_o(w_req_ready), .req_i(mem_req),
      .rsp_valid_o(mem_rsp_valid), .rsp_ready_i(mem_rsp_ready), .rsp_o(mem_rsp)
    );
    // Fault shim between the (conforming) wide memory and the adapter: deterministic
    // protocol violations and corrected flags, chosen by the request tag.
    function automatic logic [147:0] wide_shim(input logic [147:0] r);
      logic [7:0]   tg;
      logic [3:0]   st;
      logic [7:0]   mt;
      logic [127:0] dt;
      logic [2:0]   kind;
      {tg, st, mt, dt} = r;
      kind = sf_albion_tb_fault_pkg::wide_violation(tg, mt[0], st);
      if (sf_albion_tb_fault_pkg::wide_corrected(tg)) mt[3] = 1'b1;
      case (kind)
        3'd1:    tg     = tg + 8'd1;
        3'd2:    mt[0]  = ~mt[0];
        3'd3:    st     = 4'd14;
        3'd4:    mt[1]  = 1'b0;
        3'd5:    mt[7]  = 1'b1;
        3'd6:    mt[2]  = ~mt[2];
        3'd7:    dt     = '1;
        default: ;
      endcase
      return {tg, st, mt, dt};
    endfunction
    logic [147:0] shim_rsp;
    assign shim_rsp      = wide_shim(mem_rsp);
    assign w_rsp_valid   = mem_rsp_valid;
    assign mem_rsp_ready = w_rsp_ready;
    assign {w_rsp_tag, w_rsp_status, w_rsp_meta, w_rsp_data} = shim_rsp;
    // the wide-link checker watches the conforming memory side of the shim
    assign wl_req_valid = w_req_valid; assign wl_req_ready = w_req_ready; assign wl_req = mem_req;
    assign wl_rsp_valid = mem_rsp_valid; assign wl_rsp_ready = mem_rsp_ready; assign wl_rsp = mem_rsp;
    assign {n_req_valid, n_op, n_tag, n_dom, n_attr, n_addr, n_be, n_data} = '0;
    assign n_rsp_ready = 1'b0;
  end else begin : gen_m2
    sf_albion_width_adapter #(.DOWNSIZE(1'b0), .NARROW_W(NW), .MAX_OUT(MAX_OUT)) u_up (
      .clk_i, .rst_ni,
      .s_req_valid_i(i_req_valid), .s_req_ready_o(i_req_ready), .s_req_op_i(i_op), .s_req_tag_i(i_tag),
      .s_req_dom_i(i_dom), .s_req_attr_i(i_attr), .s_req_addr_i(i_addr), .s_req_be_i(i_be), .s_req_data_i(i_data),
      .s_rsp_valid_o(i_rsp_valid), .s_rsp_ready_i(i_rsp_ready), .s_rsp_tag_o(i_rsp_tag),
      .s_rsp_status_o(i_rsp_status), .s_rsp_meta_o(i_rsp_meta), .s_rsp_data_o(i_rsp_data),
      .m_req_valid_o(w_req_valid), .m_req_ready_i(w_req_ready), .m_req_op_o(w_op), .m_req_tag_o(w_tag),
      .m_req_dom_o(w_dom), .m_req_attr_o(w_attr), .m_req_addr_o(w_addr), .m_req_be_o(w_be), .m_req_data_o(w_data),
      .m_rsp_valid_i(w_rsp_valid), .m_rsp_ready_o(w_rsp_ready), .m_rsp_tag_i(w_rsp_tag),
      .m_rsp_status_i(w_rsp_status), .m_rsp_meta_i(w_rsp_meta), .m_rsp_data_i(w_rsp_data)
    );
    sf_albion_width_adapter #(.DOWNSIZE(1'b1), .NARROW_W(NW)) u_down (
      .clk_i, .rst_ni,
      .s_req_valid_i(w_req_valid), .s_req_ready_o(w_req_ready), .s_req_op_i(w_op), .s_req_tag_i(w_tag),
      .s_req_dom_i(w_dom), .s_req_attr_i(w_attr), .s_req_addr_i(w_addr), .s_req_be_i(w_be), .s_req_data_i(w_data),
      .s_rsp_valid_o(w_rsp_valid), .s_rsp_ready_i(w_rsp_ready), .s_rsp_tag_o(w_rsp_tag),
      .s_rsp_status_o(w_rsp_status), .s_rsp_meta_o(w_rsp_meta), .s_rsp_data_o(w_rsp_data),
      .m_req_valid_o(n_req_valid), .m_req_ready_i(n_req_ready), .m_req_op_o(n_op), .m_req_tag_o(n_tag),
      .m_req_dom_o(n_dom), .m_req_attr_o(n_attr), .m_req_addr_o(n_addr), .m_req_be_o(n_be), .m_req_data_o(n_data),
      .m_rsp_valid_i(n_rsp_valid), .m_rsp_ready_o(n_rsp_ready), .m_rsp_tag_i(n_rsp_tag),
      .m_rsp_status_i(n_rsp_status), .m_rsp_meta_i(n_rsp_meta), .m_rsp_data_i(n_rsp_data)
    );
    assign wl_req_valid = w_req_valid; assign wl_req_ready = w_req_ready;
    assign wl_req       = {w_op, w_tag, w_dom, w_attr, w_addr, w_be, w_data};
    assign wl_rsp_valid = w_rsp_valid; assign wl_rsp_ready = w_rsp_ready;
    assign wl_rsp       = {w_rsp_tag, w_rsp_status, w_rsp_meta, w_rsp_data};
  end

  if (MODE != 1) begin : gen_nar_mem
    sf_albion_tb_wa_nar_mem #(.NW(NW), .SEED(32'h5500 + 32'(ID)), .FAULTS(1'b1), .VIOLATE(1'b1)) u_nmem (
      .clk_i, .rst_ni, .accept_mode_i(nm_acc_mode), .resp_mode_i(nm_rsp_mode),
      .req_valid_i(n_req_valid), .req_ready_o(n_req_ready), .req_op_i(n_op), .req_tag_i(n_tag),
      .req_dom_i(n_dom), .req_attr_i(n_attr), .req_addr_i(n_addr), .req_be_i(n_be), .req_data_i(n_data),
      .rsp_valid_o(n_rsp_valid), .rsp_ready_i(n_rsp_ready), .rsp_tag_o(n_rsp_tag),
      .rsp_status_o(n_rsp_status), .rsp_meta_o(n_rsp_meta), .rsp_data_o(n_rsp_data)
    );
  end else begin : gen_no_nar_mem
    assign n_req_ready = 1'b0;
    assign {n_rsp_valid, n_rsp_tag, n_rsp_status, n_rsp_meta, n_rsp_data} = '0;
  end

  // ---------------------------------------------------------------- protocol checkers
  // wide link: full ALP checker.  Outstanding bound: a DOWN adapter holds one; an UP adapter MAX_OUT.
  sf_albion_link_checker #(.MAX_OUTSTANDING(MODE == 0 ? 1 : MAX_OUT), .CHECK_LEGALITY(1'b1)) u_wide_chk (
    .clk_i, .rst_ni,
    .req_valid_i(wl_req_valid), .req_ready_i(wl_req_ready), .req_i(wl_req),
    .rsp_valid_i(wl_rsp_valid), .rsp_ready_i(wl_rsp_ready), .rsp_i(wl_rsp),
    .waive_req_i(1'b0), .outstanding_o(wl_outstanding)
  );
  // flat channels: stability (ALP-REQ-02 / ALP-RSP-02) of the initiator and narrow links
  sf_albion_chan_checker #(.WIDTH(4+8+8+8+64+IB+IW)) u_i_req_chk (
    .clk_i, .rst_ni, .valid_i(i_req_valid), .ready_i(i_req_ready),
    .payload_i({i_op, i_tag, i_dom, i_attr, i_addr, i_be, i_data}), .waive_i(1'b0));
  sf_albion_chan_checker #(.WIDTH(8+4+8+IW)) u_i_rsp_chk (
    .clk_i, .rst_ni, .valid_i(i_rsp_valid), .ready_i(i_rsp_ready),
    .payload_i({i_rsp_tag, i_rsp_status, i_rsp_meta, i_rsp_data}), .waive_i(1'b0));
  // narrow links: ALP-TAG-01 / OUT-01 / LEG-01 / RSP-03 / RST on every one.
  //   DOWN master side : up to RATIO beats outstanding, the narrow memory injects violations
  //   UP slave side    : MAX_OUT + 2 outstanding (order queue + the 2-entry response skid), a conforming target
  logic [15:0] chk_n_outstanding, chk_i_outstanding;
  if (MODE != 1) begin : gen_nlink_chk_n
    sf_albion_link_checker_narrow #(.NW(NW), .MAX_OUTSTANDING(RATIO), .CHECK_RSP(1'b0), .REQ_MUST_BE_LEGAL(1'b1)) u_n_link_chk (
      .clk_i, .rst_ni,
      .req_valid_i(n_req_valid), .req_ready_i(n_req_ready), .req_op_i(n_op), .req_tag_i(n_tag),
      .req_dom_i(n_dom), .req_attr_i(n_attr),
      .req_addr_i(n_addr), .req_be_i(n_be),
      .rsp_valid_i(n_rsp_valid), .rsp_ready_i(n_rsp_ready), .rsp_tag_i(n_rsp_tag),
      .rsp_status_i(n_rsp_status), .rsp_meta_i(n_rsp_meta), .rsp_data_i(n_rsp_data),
      .outstanding_o(chk_n_outstanding)
    );
  end else begin : gen_no_nlink_chk_n
    assign chk_n_outstanding = '0;
  end
  if (MODE != 0) begin : gen_nlink_chk_i
    sf_albion_link_checker_narrow #(.NW(NW), .MAX_OUTSTANDING(MAX_OUT + 2), .CHECK_RSP(1'b1), .REQ_MUST_BE_LEGAL(1'b0)) u_i_link_chk (
      .clk_i, .rst_ni,
      .req_valid_i(i_req_valid), .req_ready_i(i_req_ready), .req_op_i(i_op), .req_tag_i(i_tag),
      .req_dom_i(i_dom), .req_attr_i(i_attr),
      .req_addr_i(i_addr), .req_be_i(i_be),
      .rsp_valid_i(i_rsp_valid), .rsp_ready_i(i_rsp_ready), .rsp_tag_i(i_rsp_tag),
      .rsp_status_i(i_rsp_status), .rsp_meta_i(i_rsp_meta), .rsp_data_i(i_rsp_data),
      .outstanding_o(chk_i_outstanding)
    );
  end else begin : gen_no_nlink_chk_i
    assign chk_i_outstanding = '0;
  end
  if (MODE != 1) begin : gen_nar_chk
    sf_albion_chan_checker #(.WIDTH(4+8+8+8+64+NB+NW)) u_n_req_chk (
      .clk_i, .rst_ni, .valid_i(n_req_valid), .ready_i(n_req_ready),
      .payload_i({n_op, n_tag, n_dom, n_attr, n_addr, n_be, n_data}), .waive_i(1'b0));
    sf_albion_chan_checker #(.WIDTH(8+4+8+NW)) u_n_rsp_chk (
      .clk_i, .rst_ni, .valid_i(n_rsp_valid), .ready_i(n_rsp_ready),
      .payload_i({n_rsp_tag, n_rsp_status, n_rsp_meta, n_rsp_data}), .waive_i(1'b0));
  end

  // ---------------------------------------------------------------- reference model
  typedef struct {
    logic [7:0]    tag;
    logic [3:0]    status;
    logic [7:0]    meta;
    logic [IW-1:0] data;
  } exp_t;

  bit [7:0]    mmem [bit [63:0]];
  exp_t        exp_q [$];
  int unsigned exp_beats;
  int unsigned seen_beats;
  int unsigned n_accepted, n_completed, n_target;
  int unsigned out_count;
  logic [7:0]  next_tag;

  function automatic bit [7:0] mrd(input bit [63:0] a);
    if (mmem.exists(a)) return mmem[a];
    return 8'h00;
  endfunction

  // legality at the INITIATOR link's word size (IB bytes)
  function automatic logic [3:0] link_legal(input logic [3:0] op, input logic [63:0] addr,
                                            input logic [IB-1:0] be, input logic [7:0] attr, input logic [7:0] dom);
    if (op != 4'd1 && op != 4'd2)          return 4'd3;
    if ((addr % IB) != 0)                  return 4'd5;
    if (be == '0)                          return 4'd4;
    if (attr >= 8'd128 || (attr % 4) == 3) return 4'd6;
    if (dom == 8'd255)                     return 4'd2;
    return 4'd0;
  endfunction

  function automatic exp_t model_exec(input logic [3:0] op, input logic [7:0] tag, input logic [7:0] dom,
                                      input logic [7:0] attr, input logic [63:0] addr,
                                      input logic [IB-1:0] be, input logic [IW-1:0] data);
    exp_t       e;
    logic [3:0] st;
    logic       is_wr;
    logic       corr;
    logic [3:0] acc;
    logic [3:0] f;
    logic [2:0] v;
    logic       proto;
    logic [IW-1:0] rdata;
    logic [63:0] baddr;
    logic [NB-1:0] slice;
    e = '{default: '0};
    is_wr = (op == 4'd2);
    st = link_legal(op, addr, be, attr, dom);
    e.tag = tag;
    e.meta = {4'b0000, 1'b0, 1'b0, 1'b1, is_wr};
    if (st != 4'd0) begin
      e.status = st;
      return e;
    end
    corr = 1'b0; acc = 4'd0; rdata = '0; proto = 1'b0;
    if (MODE == 0) begin
      // wide request executed as RATIO narrow beats on the faulty narrow memory
      for (int k = 0; k < RATIO; k++) begin
        slice = be[k*NB +: NB];
        if (slice != '0) begin
          baddr = (addr & ~64'hF) + 64'(k * NB);
          f     = nar_fault(baddr);
          v     = nar_violation(exp_beats, is_wr, f);
          exp_beats++;
          if (f == 4'd0) begin
            for (int b = 0; b < NB; b++) if (slice[b]) begin
              if (is_wr) mmem[baddr + 64'(b)] = data[(k*NB + b)*8 +: 8];
              else       rdata[(k*NB + b)*8 +: 8] = mrd(baddr + 64'(b));
            end
          end
          if (v != 3'd0) begin
            proto = 1'b1;
            tb_cov({NAME, ".violation_expected"});
          end else begin
            if (f != 4'd0 && acc == 4'd0) acc = f;
            if (nar_corrected(baddr)) corr = 1'b1;
          end
        end
      end
      if (proto) acc = 4'd11;
    end else if (MODE == 1) begin
      // narrow request on a wide memory of MEM_WORDS words, behind the fault shim
      exp_beats++;
      if ((addr >> 4) >= 64'(MEM_WORDS)) acc = 4'd1;
      else for (int b = 0; b < IB; b++) if (be[b]) begin
        if (is_wr) mmem[addr + 64'(b)] = data[b*8 +: 8];
        else       rdata[b*8 +: 8] = mrd(addr + 64'(b));
      end
      v = wide_violation(tag, is_wr, acc);
      if (v != 3'd0) begin
        acc  = 4'd11;
        tb_cov({NAME, ".violation_expected"});
      end else if (wide_corrected(tag)) begin
        corr = 1'b1;
      end
    end else begin
      // chain: narrow beat on the faulty narrow memory
      f = nar_fault(addr);
      v = nar_violation(exp_beats, is_wr, f);
      exp_beats++;
      if (f == 4'd0) begin
        for (int b = 0; b < IB; b++) if (be[b]) begin
          if (is_wr) mmem[addr + 64'(b)] = data[b*8 +: 8];
          else       rdata[b*8 +: 8] = mrd(addr + 64'(b));
        end
      end
      if (v != 3'd0) begin
        acc = 4'd11;
        tb_cov({NAME, ".violation_expected"});
      end else begin
        acc = f;
        if (nar_corrected(addr)) corr = 1'b1;
      end
    end
    e.status = acc;
    e.meta   = {4'b0000, corr, (acc == 4'd10), 1'b1, is_wr};
    e.data   = (acc == 4'd0 && !is_wr) ? rdata : '0;
    return e;
  endfunction

  // ---------------------------------------------------------------- stimulus
  function automatic logic [IB-1:0] gen_be();
    logic [IB-1:0] be;
    int unsigned   r;
    r = tb_below(100);
    be = '0;
    if (r < 30)       be = '1;
    else if (r < 55)  begin for (int b = 0; b < IB; b++) be[b] = tb_pct(50); end
    else if (r < 63)  be[tb_below(IB)] = 1'b1;
    else if (r < 71)  be = '0;
    else begin
      // beat-structured: whole narrow slices on or off (exercises beat skipping)
      for (int k = 0; k < IB / NB; k++) begin
        if (tb_pct(50)) for (int b = 0; b < NB; b++) be[k*NB + b] = 1'b1;
      end
      if (be == '0) be[0] = 1'b1;
    end
    return be;
  endfunction

  logic [63:0] pool_words;
  initial pool_words = (MODE == 0) ? 24 : (MODE == 1) ? (MEM_WORDS * 16 + 64) / IB : 40;   // addressable IB-byte words

  function automatic logic [63:0] gen_addr();
    logic [63:0] a;
    logic [63:0] hi;
    a = 64'(IB) * 64'(tb_below(int'(pool_words)));
    if (tb_below(100) < 14) begin
      // every address bit above the pool: a random 8 KiB-aligned base
      hi = tb_rand64();
      a  = {hi[63:13], 13'b0} + a;
    end
    if (tb_below(100) < 6) a = a + 64'(1 + tb_below(IB - 1 > 0 ? IB - 1 : 1));   // misaligned
    return a;
  endfunction

  logic issue_ok;
  assign issue_ok = rst_ni && src_go && (n_accepted + (i_req_valid ? 1 : 0) < n_target) && (out_count < 40);

  logic [3:0]     p_op;
  logic [7:0]     p_dom, p_attr;
  logic [63:0]    p_addr;
  logic [IB-1:0]  p_be;
  logic [IW-1:0]  p_data;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      i_req_valid <= 1'b0;
      i_op <= '0; i_tag <= '0; i_dom <= '0; i_attr <= '0; i_addr <= '0; i_be <= '0; i_data <= '0;
      exp_q.delete();
      mmem.delete();
      n_accepted  = 0;
      n_completed = 0;
      out_count   = 0;
      exp_beats   = 0;
      seen_beats  = 0;
      next_tag    = 8'd0;
    end else begin
      // request accepted
      if (i_req_valid && i_req_ready) begin
        exp_t e;
        e = model_exec(i_op, i_tag, i_dom, i_attr, i_addr, i_be, i_data);
        exp_q.push_back(e);
        n_accepted = n_accepted + 1;
        out_count  = out_count + 1;
        if (e.status != 4'd0) tb_cov({NAME, ".error_response_expected"});
        if (e.status == 4'd10) tb_cov({NAME, ".ecc_uncorrectable_expected"});
        if (e.status == 4'd7 || e.status == 4'd8) tb_cov({NAME, ".target_fault_expected"});
        if (e.meta[3] && e.status == 4'd0) tb_cov({NAME, ".corrected_flag_expected"});
        if (e.meta[3] && e.status != 4'd0 && e.status != 4'd11) tb_cov({NAME, ".corrected_on_error_expected"});
        if (e.status == 4'd11) tb_cov({NAME, ".protocol_error_expected"});
      end
      if (MODE != 1 && n_req_valid && n_req_ready) seen_beats = seen_beats + 1;
      if (MODE == 0 && chk_n_outstanding == 16'(RATIO)) tb_cov({NAME, ".beats_outstanding_at_ratio"});
      if (MODE != 0 && chk_i_outstanding > 16'(MAX_OUT)) tb_cov({NAME, ".slave_outstanding_above_max_out"});
      if (i_req_valid && i_req_ready && i_addr[63:13] != '0) tb_cov({NAME, ".high_address_used"});
      if (MODE == 1 && w_req_valid && w_req_ready) seen_beats = seen_beats + 1;
      // response accepted
      if (i_rsp_valid && i_rsp_ready) begin
        exp_t e;
        logic [IW+19:0] got, want;
        if (exp_q.size() == 0) tb_fail({NAME, ": response with nothing expected"});
        else begin
          e = exp_q.pop_front();
          got  = {i_rsp_tag, i_rsp_status, i_rsp_meta, i_rsp_data};
          want = {e.tag, e.status, e.meta, e.data};
          tb_check(got === want, $sformatf("%s: response mismatch got=%h expected=%h", NAME, got, want));
          n_completed = n_completed + 1;
          out_count   = out_count - 1;
          tb_cov({NAME, ".responses_checked"});
          if (e.status == 4'd0 && !e.meta[0]) tb_cov({NAME, ".read_ok"});
          if (e.status == 4'd0 &&  e.meta[0]) tb_cov({NAME, ".write_ok"});
        end
      end
      // next request
      if (!i_req_valid || i_req_ready) begin
        if (issue_ok) begin
          int unsigned r;
          r = tb_below(100);
          p_op   = (r < 46) ? 4'd2 : (r < 92) ? 4'd1 : 4'(tb_below(16));
          p_addr = gen_addr();
          p_be   = gen_be();
          p_data = {tb_rand128(), tb_rand128()};
          p_attr = {tb_pct(3), 2'(tb_below(4)), tb_pct(10), tb_pct(50), tb_pct(50), 2'(tb_below(3))};
          if (tb_pct(3)) p_attr[1:0] = 2'd3;
          p_dom  = tb_pct(3) ? 8'hFF : 8'(tb_below(255));
          i_req_valid <= 1'b1;
          i_op <= p_op; i_tag <= next_tag; i_dom <= p_dom; i_attr <= p_attr;
          i_addr <= p_addr; i_be <= p_be; i_data <= p_data;
          next_tag = next_tag + 8'd1;
        end else begin
          i_req_valid <= 1'b0;
        end
      end
    end
  end

  // ---------------------------------------------------------------- sequence
  // Random back-pressure mode in {0..5, 7}: mode 6 ("never go") can never complete a phase.
  function automatic logic [2:0] pick_mode();
    int unsigned m;
    m = tb_below(7);
    return (m >= 6) ? 3'd7 : 3'(m);
  endfunction

  task automatic wait_done(input string what);
    int unsigned guard;
    guard = 0;
    while (!(n_completed == n_target && exp_q.size() == 0 && !i_req_valid) && guard < 400000) begin
      @(posedge clk_i);
      guard++;
    end
    tb_check(n_completed == n_target && exp_q.size() == 0,
             $sformatf("%s: timed out (%s): completed %0d of %0d, expected-queue %0d", NAME, what, n_completed, n_target, exp_q.size()));
  endtask

  task automatic run_phase(input logic [2:0] sm, input logic [2:0] km, input logic [2:0] am, input logic [2:0] rm,
                           input int unsigned n, input string what);
    @(negedge clk_i);
    src_mode = sm; snk_mode = km; nm_acc_mode = am; nm_rsp_mode = rm;
    n_target = n_target + n;
    @(posedge clk_i);
    wait_done(what);
  endtask

  initial begin
    finished_o = 1'b0;
    n_target = 0;
    src_mode = 3'd0; snk_mode = 3'd0; nm_acc_mode = 3'd0; nm_rsp_mode = 3'd0;
    tb_cov_declare({NAME, ".responses_checked"});
    tb_cov_declare({NAME, ".read_ok"});
    tb_cov_declare({NAME, ".write_ok"});
    tb_cov_declare({NAME, ".error_response_expected"});
    tb_cov_declare({NAME, ".ecc_uncorrectable_expected"});
    tb_cov_declare({NAME, ".target_fault_expected"});
    tb_cov_declare({NAME, ".corrected_flag_expected"});
    tb_cov_declare({NAME, ".corrected_on_error_expected"});
    tb_cov_declare({NAME, ".protocol_error_expected"});
    tb_cov_declare({NAME, ".violation_expected"});
    tb_cov_declare({NAME, ".beats_outstanding_at_ratio"});
    tb_cov_declare({NAME, ".slave_outstanding_above_max_out"});
    tb_cov_declare({NAME, ".high_address_used"});
    tb_cov_declare({NAME, ".async_reset_mid_traffic"});
    #1 rst_ni = 1'b0;
    repeat (4) @(posedge clk_i);
    @(negedge clk_i);
    rst_ni = 1'b1;
    repeat (MEM_WORDS + 4) @(posedge clk_i);     // ref_mem clears itself after reset

    run_phase(3'd0, 3'd0, 3'd0, 3'd0, 400, "full rate");
    for (int s = 0; s < 8; s++)
      for (int k = 0; k < 8; k++) begin
        if (s == 6 || k == 6) continue;
        run_phase(s[2:0], k[2:0], pick_mode(), pick_mode(), 60, $sformatf("src=%0d snk=%0d", s, k));
      end
    // asynchronous reset in the middle of traffic, then recovery with a cleared memory
    for (int round = 0; round < 3; round++) begin
      @(negedge clk_i);
      src_mode = 3'd1; snk_mode = 3'd2; nm_acc_mode = 3'd1; nm_rsp_mode = 3'd2;
      n_target = n_target + 400;
      repeat (15 + tb_below(60)) @(posedge clk_i);
      #3;
      rst_ni = 1'b0;
      n_target = 0;
      #1;
      tb_check(i_rsp_valid === 1'b0, $sformatf("%s: response valid during reset (ALP-RST-01)", NAME));
      repeat (3) @(posedge clk_i);
      @(negedge clk_i);
      rst_ni = 1'b1;
      repeat (MEM_WORDS + 4) @(posedge clk_i);
      tb_cov({NAME, ".async_reset_mid_traffic"});
      run_phase(3'd3, 3'd3, 3'd3, 3'd3, 100, "recovery");
    end
    for (int k = 0; k < 30; k++) begin
      run_phase(pick_mode(), pick_mode(), pick_mode(), pick_mode(), NUM_REQS / 30, "mixed");
    end
    // beats actually issued downstream must equal the model's beat count (empty beats skipped)
    tb_check(seen_beats == exp_beats,
             $sformatf("%s: narrow beats issued %0d but model expects %0d", NAME, seen_beats, exp_beats));
    finished_o = 1'b1;
  end
endmodule

`default_nettype wire
