// expect: S03 S04 S05 S06 S13
`default_nettype none
module Bad_Module #(
  parameter int unsigned width = 8
) (
  input  wire logic clk_i,
  input  wire logic data,
  output logic      q_o
);
  logic Sig_A;
  sf_albion_fixture_good #(.WIDTH(1)) inst_x (.clk_i(clk_i), .rst_ni(1'b1), .d_i(data), .q_o(q_o));
  assign Sig_A = data;
endmodule
`default_nettype wire
