// =============================================================================
//  tb_sf_albion_width_adapter.sv  --  self-checking test of sf_albion_width_adapter
//  DOWN (wide -> narrow), UP (narrow -> wide) and CHAIN (narrow -> wide -> narrow)
//  for narrow widths 8, 16, 32 and 64, each against an independent reference
//  model of the whole composition (see sf_albion_tb_wa_case).
// =============================================================================
`default_nettype none
module tb_sf_albion_width_adapter;
  localparam int unsigned N = 10;
  logic [N-1:0] fin;
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.down32"), .ID(0), .MODE(0), .NW(32), .MAX_OUT(1), .NUM_REQS(3000)) u_case_0 (.finished_o(fin[0]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.down8"), .ID(1), .MODE(0), .NW(8), .MAX_OUT(1), .NUM_REQS(3000)) u_case_1 (.finished_o(fin[1]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.down16"), .ID(2), .MODE(0), .NW(16), .MAX_OUT(1), .NUM_REQS(3000)) u_case_2 (.finished_o(fin[2]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.down64"), .ID(3), .MODE(0), .NW(64), .MAX_OUT(1), .NUM_REQS(3000)) u_case_3 (.finished_o(fin[3]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.up32"), .ID(4), .MODE(1), .NW(32), .MAX_OUT(4), .NUM_REQS(3000)) u_case_4 (.finished_o(fin[4]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.up8"), .ID(5), .MODE(1), .NW(8), .MAX_OUT(1), .NUM_REQS(3000)) u_case_5 (.finished_o(fin[5]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.up64"), .ID(6), .MODE(1), .NW(64), .MAX_OUT(8), .NUM_REQS(3000)) u_case_6 (.finished_o(fin[6]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.up16"), .ID(7), .MODE(1), .NW(16), .MAX_OUT(2), .NUM_REQS(3000)) u_case_7 (.finished_o(fin[7]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.chain32"), .ID(8), .MODE(2), .NW(32), .MAX_OUT(4), .NUM_REQS(3000)) u_case_8 (.finished_o(fin[8]));
  sf_albion_tb_wa_case #(.NAME("tb_sf_albion_width_adapter.chain64"), .ID(9), .MODE(2), .NW(64), .MAX_OUT(3), .NUM_REQS(3000)) u_case_9 (.finished_o(fin[9]));

  initial begin
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_width_adapter");
    $finish;
  end
endmodule
`default_nettype wire
