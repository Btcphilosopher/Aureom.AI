// expect: S09
`default_nettype none
module sf_albion_fixture_a (input wire logic d_i, output logic q_o);
  always @(*) q_o = d_i;
endmodule
`default_nettype wire
