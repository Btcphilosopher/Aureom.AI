// =============================================================================
//  tb_sf_albion_fifo.sv  --  self-checking test of sf_albion_fifo: depths 1,2,3,4,5,7,8,16 (degenerate, non-power-of-two wrap) and payload widths 1..236
// =============================================================================
`default_nettype none
module tb_sf_albion_fifo;
  localparam int unsigned N = 8;
  logic [N-1:0] fin;
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(0), .KIND(0), .WIDTH(8), .DEPTH(1), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_0 (.finished_o(fin[0]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(1), .KIND(0), .WIDTH(16), .DEPTH(2), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_1 (.finished_o(fin[1]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(2), .KIND(0), .WIDTH(32), .DEPTH(3), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_2 (.finished_o(fin[2]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(3), .KIND(0), .WIDTH(1), .DEPTH(4), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_3 (.finished_o(fin[3]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(4), .KIND(0), .WIDTH(64), .DEPTH(5), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_4 (.finished_o(fin[4]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(5), .KIND(0), .WIDTH(236), .DEPTH(8), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_5 (.finished_o(fin[5]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(6), .KIND(0), .WIDTH(148), .DEPTH(16), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_6 (.finished_o(fin[6]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_fifo"), .ID(7), .KIND(0), .WIDTH(12), .DEPTH(7), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b1)) u_sweep_7 (.finished_o(fin[7]));

  initial begin
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_fifo");
    $finish;
  end
endmodule
`default_nettype wire
