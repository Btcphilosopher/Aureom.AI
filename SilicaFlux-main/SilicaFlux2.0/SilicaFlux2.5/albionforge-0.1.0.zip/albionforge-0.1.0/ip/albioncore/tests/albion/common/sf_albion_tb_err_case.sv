// =============================================================================
//  sf_albion_tb_err_case.sv  --  one sf_albion_err_resp test case (testbench only)
// -----------------------------------------------------------------------------
//  Random requests (legal, illegal, all opcodes, all 16 status_i codes) under
//  random back-pressure.  Every response is compared with an independent model
//  of the selection rules; the link checker verifies the protocol on every cycle.
// =============================================================================
`default_nettype none

module sf_albion_tb_err_case #(
  parameter string       NAME           = "err",
  parameter int unsigned ID             = 0,
  parameter int unsigned DEPTH          = 2,
  parameter bit          CHECK_LEGALITY = 1'b1,
  parameter int unsigned NUM_REQS       = 6000
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;

  logic clk_i = 1'b0;
  logic rst_ni = 1'b1;
  always #5 clk_i = ~clk_i;

  logic                   req_valid, req_ready;
  sf_albion_pkg::sf_req_t req;
  logic [3:0]             status_in;
  logic                   rsp_valid, rsp_ready;
  sf_albion_pkg::sf_rsp_t rsp;

  sf_albion_err_resp #(.DEPTH(DEPTH), .CHECK_LEGALITY(CHECK_LEGALITY)) u_dut (
    .clk_i, .rst_ni, .req_valid_i(req_valid), .req_ready_o(req_ready), .req_i(req), .status_i(status_in),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp));

  logic [2:0] src_mode, snk_mode;
  logic       src_go, snk_go;
  sf_albion_tb_stall #(.SEED(32'hE000_0000 + 32'(ID))) u_src (.clk_i, .rst_ni, .mode_i(src_mode), .go_o(src_go));
  sf_albion_tb_stall #(.SEED(32'hE100_0000 + 32'(ID))) u_snk (.clk_i, .rst_ni, .mode_i(snk_mode), .go_o(snk_go));
  assign rsp_ready = snk_go;

  // The err_resp is a target of its own: the checker's tag-uniqueness rule is met
  // because the driver numbers requests sequentially and keeps <= 64 outstanding.
  logic [15:0] outstanding;
  sf_albion_link_checker #(.MAX_OUTSTANDING(64), .CHECK_LEGALITY(CHECK_LEGALITY)) u_chk (
    .clk_i, .rst_ni, .req_valid_i(req_valid), .req_ready_i(req_ready), .req_i(req),
    .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_i(rsp), .waive_req_i(1'b0), .outstanding_o(outstanding));

  typedef struct { logic [147:0] rsp; } exp_t;
  exp_t        exp_q [$];
  int unsigned n_target, n_issued, n_done;
  logic [7:0]  next_tag;
  string       pfx;

  // Independent expected response.
  function automatic logic [147:0] expect_rsp(input sf_albion_pkg::sf_req_t r, input logic [3:0] st_in);
    logic [235:0] raw;
    logic [3:0]   leg, st;
    logic [147:0] e;
    raw = r;
    leg = tb_ref_legal_status(raw);
    if (CHECK_LEGALITY && leg != 4'd0) st = leg;
    else if (st_in == 4'd0)            st = 4'd1;
    else if (st_in > 4'd11)            st = 4'd7;
    else                               st = st_in;
    e = '0;
    e[147:140] = r.tag;
    e[139:136] = st;
    e[135:128] = {4'b0000, 1'b0, (st == 4'd10), 1'b1, (r.op == 4'd2)};
    return e;
  endfunction

  logic gate;
  assign gate = rst_ni && src_go && (n_issued < n_target) && (outstanding < 60);
  logic [31:0] cyc_q;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      req_valid <= 1'b0; req <= '0; status_in <= '0;
      exp_q.delete(); n_issued = 0; n_done = 0; next_tag = 8'd0; cyc_q <= '0;
    end else begin
      cyc_q <= cyc_q + 1;
      if (req_valid && req_ready) begin
        exp_t ne;
        ne.rsp = expect_rsp(req, status_in);
        exp_q.push_back(ne);
        n_issued = n_issued + 1;
      end
      if (rsp_valid && rsp_ready) begin
        exp_t e;
        if (exp_q.size() == 0) tb_fail({pfx, ": unexpected response"});
        else begin
          e = exp_q.pop_front();
          tb_check(rsp === e.rsp[147:0], $sformatf("%s: response %h expected %h", pfx, 148'(rsp), e.rsp));
          n_done = n_done + 1;
          tb_cov($sformatf("%s.status_%0d", pfx, rsp.status));
          if (rsp.meta.is_write) tb_cov({pfx, ".write_completion"}); else tb_cov({pfx, ".read_completion"});
        end
      end
      if (!req_valid || req_ready) begin
        if (gate) begin
          sf_albion_pkg::sf_req_t r;
          r = '0;
          r.tag  = next_tag;
          r.op   = 4'(tb_below(16));
          if (tb_pct(60)) r.op = tb_pct(50) ? 4'd1 : 4'd2;
          r.addr = {tb_rand64()};
          if (tb_pct(70)) r.addr[3:0] = 4'h0;
          r.be   = tb_pct(10) ? 16'h0 : 16'(tb_rand32());
          r.dom  = tb_pct(5) ? 8'hFF : 8'(tb_below(255));
          r.attr = 8'(tb_rand32());
          if (tb_pct(70)) r.attr[7] = 1'b0;
          if (tb_pct(70)) r.attr[1:0] = 2'(tb_below(3));
          r.data = tb_rand128();
          req_valid <= 1'b1; req <= r; status_in <= 4'(tb_below(16));
          next_tag = next_tag + 8'd1;
        end else begin
          req_valid <= 1'b0;
        end
      end
    end
  end

  task automatic phase(input logic [2:0] sm, input logic [2:0] km, input int unsigned n);
    int unsigned guard;
    @(negedge clk_i);
    src_mode = sm; snk_mode = km; n_target = n_target + n;
    guard = 0;
    @(posedge clk_i);
    while (!(n_done == n_target) && guard < 200000) begin @(posedge clk_i); guard++; end
    tb_check(n_done == n_target, $sformatf("%s: timed out, done %0d of %0d", pfx, n_done, n_target));
  endtask

  int unsigned cyc0, t0;
  initial begin
    finished_o = 1'b0;
    pfx = $sformatf("%s%0d", NAME, ID);
    n_target = 0; src_mode = 3'd0; snk_mode = 3'd0;
    for (int s = 1; s <= 11; s++) tb_cov_declare($sformatf("%s.status_%0d", pfx, s));
    tb_cov_declare({pfx, ".write_completion"}); tb_cov_declare({pfx, ".read_completion"});
    tb_cov_declare({pfx, ".full_rate_phase"});
    tb_cov_declare({pfx, ".async_reset_mid_traffic"});
    #1 rst_ni = 1'b0;
    repeat (4) @(posedge clk_i);
    @(negedge clk_i);
    rst_ni = 1'b1;
    repeat (2) @(posedge clk_i);
    // full-rate phase: DEPTH >= 2 must sustain one request per cycle
    t0 = cyc_q;
    phase(3'd0, 3'd0, 400);
    cyc0 = cyc_q - t0;
    if (DEPTH >= 2) tb_check(cyc0 <= 400 + 8, $sformatf("%s: full-rate phase took %0d cycles for 400 requests", pfx, cyc0));
    tb_cov({pfx, ".full_rate_phase"});
    for (int s = 0; s < 8; s++)
      for (int k = 0; k < 8; k++) begin
        if (s == 6 || k == 6) continue;
        phase(s[2:0], k[2:0], 80);
      end
    // asynchronous reset in the middle of traffic: valids drop at once, nothing is answered afterwards,
    // and the responder recovers completely
    for (int round = 0; round < 3; round++) begin
      @(negedge clk_i);
      src_mode = 3'd1; snk_mode = 3'd2;
      n_target = n_target + 300;
      repeat (10 + tb_below(40)) @(posedge clk_i);
      #3;
      rst_ni = 1'b0;
      n_target = 0;
      #1;
      tb_check(req_valid === 1'b0 && rsp_valid === 1'b0, $sformatf("%s: valid asserted during reset (ALP-RST-01)", pfx));
      repeat (3) @(posedge clk_i);
      @(negedge clk_i);
      rst_ni = 1'b1;
      repeat (2) @(posedge clk_i);
      tb_cov({pfx, ".async_reset_mid_traffic"});
      phase(3'd3, 3'd3, 100);
    end
    phase(3'd1, 3'd1, NUM_REQS);
    finished_o = 1'b1;
  end
endmodule

`default_nettype wire
