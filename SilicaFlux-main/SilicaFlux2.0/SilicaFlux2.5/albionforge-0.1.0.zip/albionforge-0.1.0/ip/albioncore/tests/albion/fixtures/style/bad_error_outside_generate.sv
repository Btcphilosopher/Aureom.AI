// expect: S12
`default_nettype none
module sf_albion_fixture_a (input wire logic d_i, output logic q_o);
  if (1 > 2) begin : gen_other
    $error("not a parameter check block");
  end
  assign q_o = d_i;
endmodule
`default_nettype wire
