// =============================================================================
//  sf_albion_tb_stage_sweep.sv  --  complete test sequence for ONE buffering-
//  stage configuration.  Testbench only.
// -----------------------------------------------------------------------------
//  Instantiates one sf_albion_tb_stage_harness (source, sink, DUT, scoreboard,
//  channel checkers) with its own clock and reset, and runs
//    1. reset-state check
//    2. full-throughput check (both sides always ready)
//    3. directed fill: sink never ready, source offers more than the capacity;
//       occupancy must equal the capacity, then drain and compare
//    4. 8 x 8 sweep of source and sink back-pressure regimes
//    5. flush phases (FIFO only) at several flush rates
//    6. asynchronous reset in the middle of traffic, then full recovery
//    7. a long mixed-regime random phase
//  The harness scoreboard and checkers watch every cycle of all of it.
//  finished_o rises when the sequence is complete; the parent prints the report.
// =============================================================================
`default_nettype none

module sf_albion_tb_stage_sweep #(
  parameter string       TB_NAME    = "stage",
  parameter int unsigned ID         = 0,
  parameter int unsigned KIND       = 0,      // 0 fifo, 1 skid, 2 regslice
  parameter int unsigned WIDTH      = 8,
  parameter int unsigned DEPTH      = 4,
  parameter int unsigned MODE       = 3,
  parameter int unsigned ITEMS      = 150,
  parameter bit          FLUSH_TEST = 1'b0
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;

  logic clk_i = 1'b0;
  logic rst_ni = 1'b1;          // power-on: reset asserted asynchronously at 1 ns
  always #5 clk_i = ~clk_i;

  logic [2:0]  src_mode, snk_mode;
  logic [7:0]  flush_pct;
  int unsigned target_total;
  logic        done;
  int unsigned accepted, delivered, occupancy, cycles;

  sf_albion_tb_stage_harness #(
    .NAME(TB_NAME), .ID(ID), .KIND(KIND), .WIDTH(WIDTH), .DEPTH(DEPTH), .MODE(MODE),
    .SEED(32'h1000_0000 + 32'(ID) * 32'h0001_0001 + 32'h77)
  ) u_h (
    .clk_i, .rst_ni,
    .src_mode_i(src_mode), .snk_mode_i(snk_mode), .flush_pct_i(flush_pct),
    .target_total_i(target_total),
    .done_o(done), .accepted_o(accepted), .delivered_o(delivered),
    .occupancy_o(occupancy), .cycle_o(cycles)
  );

  localparam int unsigned CAPACITY =
      (KIND == 0) ? DEPTH :
      (KIND == 1) ? 2 :
      (MODE == 0) ? 0 : (MODE == 3) ? 2 : 1;

  string pfx;
  logic  verbose;

  // Wait until the harness is done, or fail after a timeout.
  task automatic wait_done(input string what);
    int unsigned guard;
    guard = 0;
    while (!done && guard < 100000) begin
      @(posedge clk_i);
      guard++;
    end
    tb_check(done, $sformatf("%s: timed out waiting for completion (%s)", pfx, what));
  endtask

  task automatic run_phase(input logic [2:0] sm, input logic [2:0] km, input int unsigned items,
                           input logic [7:0] fpct, input string what);
    @(negedge clk_i);                       // change stimulus away from the sampling edge
    src_mode = sm; snk_mode = km; flush_pct = fpct;
    target_total = target_total + items;
    if (verbose) $display("[%0t] %s phase '%s' target=%0d", $time, pfx, what, target_total);
    @(posedge clk_i);
    wait_done(what);
  endtask

  int unsigned cyc0;
  int unsigned pick_s, pick_k;
  int unsigned slack;

  initial begin
    finished_o = 1'b0;
    verbose = $test$plusargs("albion_verbose");
    pfx = $sformatf("%s%0d", TB_NAME, ID);
    src_mode = 3'd0; snk_mode = 3'd0; flush_pct = 8'd0; target_total = 0;
    tb_cov_declare({pfx, ".sweep_phases"});
    tb_cov_declare({pfx, ".async_reset_mid_traffic"});
    tb_cov_declare({pfx, ".full_throughput_phase"});
    tb_cov_declare({pfx, ".fill_to_capacity"});

    // ---- reset sequence: asserted at 1 ns, released synchronously ------------
    #1 rst_ni = 1'b0;
    repeat (4) @(posedge clk_i);
    @(negedge clk_i);
    rst_ni = 1'b1;
    repeat (3) @(posedge clk_i);

    // ---- 1. reset state ------------------------------------------------------
    tb_check(occupancy == 0, $sformatf("%s: not empty after reset", pfx));

    // ---- 2. full throughput --------------------------------------------------
    cyc0 = cycles;
    run_phase(3'd0, 3'd0, 400, 8'd0, "full throughput");
    slack = 12;
    if (KIND == 0 && DEPTH < 2) slack = 400 + 12;     // a 1-entry FIFO moves one item per two cycles
    tb_check(cycles - cyc0 <= 400 + slack,
             $sformatf("%s: full-throughput phase took %0d cycles for 400 items", pfx, cycles - cyc0));
    tb_cov({pfx, ".full_throughput_phase"});

    // ---- 3. directed fill (sink never ready) ----------------------------------
    @(negedge clk_i);
    src_mode = 3'd0; snk_mode = 3'd6; flush_pct = 8'd0;
    target_total = target_total + 40;
    repeat (80) @(posedge clk_i);
    tb_check(occupancy == CAPACITY,
             $sformatf("%s: filled occupancy %0d, expected capacity %0d", pfx, occupancy, CAPACITY));
    tb_cov({pfx, ".fill_to_capacity"});
    @(negedge clk_i);
    snk_mode = 3'd0;
    @(posedge clk_i);
    wait_done("drain after fill");

    // ---- 4. regime sweep -------------------------------------------------------
    // Mode 6 ("never go") is reserved for the directed fill above: a phase
    // run in that mode could never complete.
    for (int sm = 0; sm < 8; sm++)
      for (int km = 0; km < 8; km++) begin
        if (sm == 6 || km == 6) continue;
        run_phase(sm[2:0], km[2:0], ITEMS, 8'd0, $sformatf("sweep src=%0d snk=%0d", sm, km));
        tb_cov({pfx, ".sweep_phases"});
      end

    // ---- 5. flush phases -------------------------------------------------------
    if (FLUSH_TEST) begin
      for (int sm = 0; sm < 8; sm++)
        for (int km = 0; km < 4; km++) begin
          if (sm == 6) continue;
          run_phase(sm[2:0], km[2:0], ITEMS, 8'(4 + 12 * km), $sformatf("flush src=%0d snk=%0d", sm, km));
        end
    end

    // ---- 6. asynchronous reset in the middle of traffic ------------------------
    for (int round = 0; round < 6; round++) begin
      @(negedge clk_i);
      src_mode = 3'd1; snk_mode = 3'd2; flush_pct = 8'd0;
      target_total = target_total + 1000;
      repeat (10 + tb_below(60)) @(posedge clk_i);
      #3;                                    // not aligned with any clock edge
      rst_ni = 1'b0;                         // asynchronous assertion
      target_total = 0;
      #1;
      tb_check(occupancy == 0, $sformatf("%s: not cleared by asynchronous reset", pfx));
      repeat (3) @(posedge clk_i);
      @(negedge clk_i);
      rst_ni = 1'b1;                         // released synchronously (away from the edge)
      repeat (2) @(posedge clk_i);
      tb_cov({pfx, ".async_reset_mid_traffic"});
      run_phase(3'd3, 3'd3, 60, 8'd0, "recovery after reset");
    end

    // ---- 7. long mixed random phase -------------------------------------------
    for (int k = 0; k < 40; k++) begin
      pick_s = tb_below(8); pick_k = tb_below(8);
      if (pick_s == 6) pick_s = 7;
      if (pick_k == 6) pick_k = 7;
      run_phase(3'(pick_s), 3'(pick_k), 120, FLUSH_TEST ? 8'(tb_below(40)) : 8'd0, "mixed");
    end

    // ---- final accounting --------------------------------------------------------
    tb_check(occupancy == 0, $sformatf("%s: not drained at end", pfx));
    if (!FLUSH_TEST) tb_check(delivered == accepted,
        $sformatf("%s: delivered %0d != accepted %0d (loss or duplication)", pfx, delivered, accepted));
    finished_o = 1'b1;
  end
endmodule

`default_nettype wire
