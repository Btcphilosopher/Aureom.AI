// =============================================================================
//  sf_albion_stream_scoreboard.sv  --  in-order transaction scoreboard
//  (testbench only; uses SystemVerilog queues, never synthesized)
// -----------------------------------------------------------------------------
//  Taps the input and output handshakes of any in-order, loss-free stage
//  (FIFO, skid buffer, register slice, ...).  Every item accepted at the input
//  must appear, unchanged and in order, at the output.
//
//    in  accept  : in_valid_i && in_ready_i   -> push expected item
//    out accept  : out_valid_i && out_ready_i -> pop the oldest item and compare
//    (push is processed before pop within a cycle, see below)
//    flush_i     : at the clock edge where flush_i is high the expected queue
//                  is emptied after the push/pop of that cycle are processed
//                  (items accepted while flush_i is high would be discarded,
//                  but a correct stage never accepts one).
//
//  Failures are reported through sf_albion_tb_pkg::tb_check so they are
//  counted in the single end-of-test report.
// =============================================================================
`default_nettype none

module sf_albion_stream_scoreboard #(
  parameter int unsigned WIDTH     = 8,
  parameter int unsigned MAX_DEPTH = 4096     // overflow guard on the expected queue
) (
  input wire logic             clk_i,
  input wire logic             rst_ni,
  input wire logic             flush_i,
  input wire logic             in_valid_i,
  input wire logic             in_ready_i,
  input wire logic [WIDTH-1:0] in_data_i,
  input wire logic             out_valid_i,
  input wire logic             out_ready_i,
  input wire logic [WIDTH-1:0] out_data_i,
  output int unsigned          pending_o,
  output int unsigned          pushed_o,
  output int unsigned          popped_o
);
  logic [WIDTH-1:0] expected [$];
  int unsigned      pushed;
  int unsigned      popped;
  logic [WIDTH-1:0] exp_word;

  assign pending_o = expected.size();
  assign pushed_o  = pushed;
  assign popped_o  = popped;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      expected.delete();
      pushed = 0;
      popped = 0;
    end else begin
      // Push first: a pass-through stage (bypass / backward slice) may accept
      // and deliver the same item in the same cycle.  For registered stages
      // the queue is already non-empty when an item is delivered, so the pop
      // below still takes the OLDEST item and ordering is fully checked.
      if (in_valid_i && in_ready_i) begin
        if (expected.size() >= MAX_DEPTH) begin
          sf_albion_tb_pkg::tb_fail("scoreboard: expected queue overflow");
        end else begin
          expected.push_back(in_data_i);
          pushed++;
        end
      end
      if (out_valid_i && out_ready_i) begin
        if (expected.size() == 0) begin
          sf_albion_tb_pkg::tb_fail("scoreboard: output item with nothing expected (duplicate or spurious)");
        end else begin
          exp_word = expected.pop_front();
          popped++;
          sf_albion_tb_pkg::tb_check(out_data_i === exp_word,
            $sformatf("scoreboard: data mismatch got=%h expected=%h", out_data_i, exp_word));
        end
      end
      if (flush_i) expected.delete();
    end
  end
endmodule

`default_nettype wire
