// expect: S11
`default_nettype none
module sf_albion_fixture_a (input wire logic d_i, output logic q_o);
  initial begin
    $display("hello");
  end
  assign #5 q_o = d_i;
endmodule
`default_nettype wire
