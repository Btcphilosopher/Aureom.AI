// expect: S07
`default_nettype none
module sf_albion_fixture_a (input wire logic clk_i, input wire logic d_i, output logic q_o);
  always_ff @(posedge clk_i) begin
    q_o = d_i;
  end
endmodule
`default_nettype wire
