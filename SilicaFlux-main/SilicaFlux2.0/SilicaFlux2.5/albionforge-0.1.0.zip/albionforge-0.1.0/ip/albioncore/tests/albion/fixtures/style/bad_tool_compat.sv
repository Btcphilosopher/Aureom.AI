// expect: S15
`default_nettype none
module sf_albion_fixture_a (input wire logic [3:0] d_i, output logic [7:0] q_o);
  function automatic logic [7:0] widen(input logic [3:0] v);
    return 8'(v);
  endfunction
  assign q_o = widen(d_i) + 8'(int'(d_i));
endmodule
`default_nettype wire
