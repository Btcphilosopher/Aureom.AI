// =============================================================================
//  fv_sf_albion_pkg_funcs.sv  --  formal equivalence of the package functions
// -----------------------------------------------------------------------------
//  Proves, for ALL 2**236 requests, 2**8 region attributes and 2**148
//  responses, that the package functions as ELABORATED BY YOSYS compute
//  exactly the contract rules.  The reference below is an independent
//  restatement written with plain Verilog operators and decimal constants; it
//  does not call the package.  (A tool that mis-resolved a package identifier
//  would make this fail, which is how the Yosys 0.33 scoping limit is guarded.)
// =============================================================================
module fv_sf_albion_pkg_funcs (
  input wire         clk_i,
  input wire [235:0] req_i,
  input wire [7:0]   ra_i,
  input wire [147:0] rsp_i
);
  // ---- reference: request legality
  wire [3:0]  op   = req_i[235:232];
  wire [7:0]  dom  = req_i[223:216];
  wire [7:0]  attr = req_i[215:208];
  wire [63:0] addr = req_i[207:144];
  wire [15:0] be   = req_i[143:128];
  reg  [3:0]  ref_legal;
  always @(*) begin
    ref_legal = 4'd0;
    if (op != 4'd1 && op != 4'd2)               ref_legal = 4'd3;
    else if (addr[3:0] != 4'd0)                 ref_legal = 4'd5;
    else if (be == 16'd0)                       ref_legal = 4'd4;
    else if (attr[7] || attr[1:0] == 2'd3)      ref_legal = 4'd6;
    else if (dom == 8'd255)                     ref_legal = 4'd2;
  end

  // ---- reference: region access check
  reg [3:0] ref_access;
  always @(*) begin
    ref_access = 4'd0;
    if (op == 4'd1 && !ra_i[0])                 ref_access = 4'd2;
    else if (op == 4'd2 && !ra_i[1])            ref_access = 4'd2;
    else if (attr[4] && !ra_i[2])               ref_access = 4'd2;
    else if (ra_i[3] && !attr[2])               ref_access = 4'd2;
    else if (ra_i[4] && !attr[3])               ref_access = 4'd2;
    else if (ra_i[7:6] == 2'd2 && attr[1:0] != 2'd2) ref_access = 4'd6;
  end

  // ---- reference: response well-formedness
  wire [3:0]   r_st   = rsp_i[139:136];
  wire [7:0]   r_meta = rsp_i[135:128];
  wire [127:0] r_data = rsp_i[127:0];
  wire ref_wf = (r_st <= 4'd11) && (r_meta[7:4] == 4'd0) && r_meta[1] &&
                (r_st == 4'd0 || r_data == 128'd0) &&
                (!r_meta[0] || r_data == 128'd0) &&
                (r_meta[2] == (r_st == 4'd10));

  // ---- device under proof: the package functions
  wire [3:0] dut_legal  = sf_albion_pkg::sf_req_check_bits(req_i);
  wire [3:0] dut_access = sf_albion_pkg::sf_access_check_bits(ra_i, req_i);
  wire       dut_wf     = sf_albion_pkg::sf_rsp_wellformed_bits(rsp_i);

  always @(posedge clk_i) begin
    a_legal:  assert (dut_legal  == ref_legal);
    a_access: assert (dut_access == ref_access);
    a_wf:     assert (dut_wf     == ref_wf);
  end
endmodule
