// =============================================================================
//  tb_sf_albion_cdc.sv  --  self-checking tests of the optional CDC modules
// -----------------------------------------------------------------------------
//  Independent sub-testbenches, each with its own pair of unrelated clocks
//  (different periods and start offsets, so the relative phase drifts through
//  every alignment):
//    sf_albion_tb_cdc_rst_case    sf_albion_reset_sync  : asserts asynchronously,
//        releases only on a clock edge, exactly STAGES edges after release
//    sf_albion_tb_cdc_bit_case    sf_albion_cdc_bit_sync: latency, no glitches,
//        settled value equals the source
//    sf_albion_tb_cdc_pulse_case  sf_albion_cdc_pulse   : every accepted event
//        produces exactly one one-cycle pulse, none lost, none duplicated
//    sf_albion_tb_cdc_fifo_case   sf_albion_async_fifo  : in-order, loss-free,
//        duplicate-free transfer under random back-pressure on both sides,
//        Gray pointers change by <= 1 bit per cycle, occupancy bound, reset in
//        the middle of traffic
//  NOTE: simulation is cycle-based and does not model metastability; see
//  docs/albion/RESET_CLOCK_CONTRACT.md for what is and is not verified.
// =============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
module sf_albion_tb_cdc_rst_case #(
  parameter int unsigned ID     = 0,
  parameter int unsigned STAGES = 2,
  parameter int unsigned PERIOD = 10
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;
  logic clk_i = 1'b0;
  logic arst_ni = 1'b1;
  logic rst_no;
  initial begin #(3 + ID); forever #(PERIOD / 2) clk_i = ~clk_i; end
  sf_albion_reset_sync #(.STAGES(STAGES)) u_dut (.clk_i, .arst_ni, .rst_no);

  int unsigned edges_since_release;
  bit          released;
  time         t_assert, t_edge;
  always @(posedge clk_i) begin
    t_edge = $time;
    if (released) edges_since_release++;
  end

  // assertion must be asynchronous: rst_no low in the same time step
  always @(negedge arst_ni) begin
    t_assert = $time;
    released = 1'b0;
    #1;
    tb_check(rst_no === 1'b0, "reset_sync: rst_no not low right after asynchronous assertion");
  end
  // ... and it must fall in the SAME time step as arst_ni (not wait for a clock edge)
  always @(negedge rst_no) if (armed) tb_check($time == t_assert, "reset_sync: rst_no fell later than the asynchronous assertion");
  // deassertion must happen on a clock edge, STAGES edges after release
  bit armed;                 // true from the first real release on (before it, flops hold power-on values)
  always @(posedge rst_no) if (armed) begin
    tb_check(released, "reset_sync: rst_no rose without arst_ni being released");
    tb_check($time == t_edge, "reset_sync: rst_no rose away from a clock edge");
    tb_check(edges_since_release == STAGES,
             $sformatf("reset_sync[%0d]: rst_no rose %0d edges after release, expected %0d", ID, edges_since_release, STAGES));
    tb_cov($sformatf("tb_sf_albion_cdc.rst%0d.release_checked", ID));
  end

  initial begin
    finished_o = 1'b0;
    released = 1'b0;
    armed = 1'b0;
    edges_since_release = 0;
    tb_cov_declare($sformatf("tb_sf_albion_cdc.rst%0d.release_checked", ID));
    #1 arst_ni = 1'b0;
    for (int n = 0; n < 60; n++) begin
      #(20 + tb_below(40));
      // release at an arbitrary sub-cycle offset, never exactly on a clock edge
      #(1 + tb_below(PERIOD - 1));
      while ((($time + PERIOD - (3 + ID + PERIOD / 2) % PERIOD) % PERIOD) == 0) #1;
      edges_since_release = 0;
      released = 1'b1;
      armed    = 1'b1;
      arst_ni = 1'b1;
      repeat (STAGES + 3) @(posedge clk_i);
      tb_check(rst_no === 1'b1, "reset_sync: rst_no still low long after release");
      // re-assert at an arbitrary time
      #(tb_below(PERIOD) + 1);
      arst_ni = 1'b0;
      #1;
      tb_check(rst_no === 1'b0, "reset_sync: rst_no not low right after re-assertion");
    end
    finished_o = 1'b1;
  end
endmodule

// ----------------------------------------------------------------------------
module sf_albion_tb_cdc_bit_case #(
  parameter int unsigned ID     = 0,
  parameter int unsigned STAGES = 2,
  parameter int unsigned SP     = 10,
  parameter int unsigned DP     = 7
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;
  logic sclk = 1'b0, dclk = 1'b0, rst_ni = 1'b1;
  initial begin #2; forever #(SP / 2) sclk = ~sclk; end
  initial begin #5; forever #(DP / 2) dclk = ~dclk; end
  logic src_q, dst;
  sf_albion_cdc_bit_sync #(.STAGES(STAGES)) u_dut (.dst_clk_i(dclk), .dst_rst_ni(rst_ni), .src_i(src_q), .dst_o(dst));

  // source: registered, changes at random sclk edges
  int unsigned hold;
  always @(posedge sclk or negedge rst_ni) begin
    if (!rst_ni) begin src_q <= 1'b0; hold = 0; end
    else begin
      if (hold == 0) begin src_q <= ~src_q; hold = 1 + tb_below(40); end
      else hold--;
    end
  end

  // Exact model: at every dst edge, dst equals the source value sampled STAGES
  // dst edges earlier.  This proves the latency, the absence of glitches and
  // that the settled value equals the source.
  logic [STAGES-1:0] hist;
  always @(posedge dclk or negedge rst_ni) begin
    if (!rst_ni) hist = '0;
    else begin
      tb_check(dst === hist[STAGES-1], $sformatf("bit_sync[%0d]: dst %b but source sampled %0d edges ago was %b", ID, dst, STAGES, hist[STAGES-1]));
      hist = {hist[STAGES-2:0], src_q};
      tb_cov($sformatf("tb_sf_albion_cdc.bit%0d.cycles_checked", ID));
    end
  end
  // dst must never change except in the time step of a dclk rising edge
  time t_edge;
  always @(posedge dclk) t_edge = $time;
  always @(dst) if ($time != t_edge && $time > 20) tb_fail($sformatf("bit_sync[%0d]: dst changed away from a dst clock edge", ID));

  initial begin
    finished_o = 1'b0;
    tb_cov_declare($sformatf("tb_sf_albion_cdc.bit%0d.cycles_checked", ID));
    #1 rst_ni = 1'b0;
    #40 rst_ni = 1'b1;
    #200000;
    finished_o = 1'b1;
  end
endmodule

// ----------------------------------------------------------------------------
module sf_albion_tb_cdc_pulse_case #(
  parameter int unsigned ID     = 0,
  parameter int unsigned STAGES = 2,
  parameter int unsigned SP     = 10,
  parameter int unsigned DP     = 7
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;
  logic sclk = 1'b0, dclk = 1'b0, srst_ni = 1'b1, drst_ni = 1'b1;
  initial begin #2; forever #(SP / 2) sclk = ~sclk; end
  initial begin #5; forever #(DP / 2) dclk = ~dclk; end
  logic valid_q, ready, pulse;
  sf_albion_cdc_pulse #(.SYNC_STAGES(STAGES)) u_dut (
    .src_clk_i(sclk), .src_rst_ni(srst_ni), .src_valid_i(valid_q), .src_ready_o(ready),
    .dst_clk_i(dclk), .dst_rst_ni(drst_ni), .pulse_o(pulse));

  int unsigned sent, got;
  logic        pulse_prev;
  logic        go;
  bit          idle;
  sf_albion_tb_stall #(.SEED(32'h9100 + 32'(ID))) u_go (.clk_i(sclk), .rst_ni(srst_ni), .mode_i(3'd1), .go_o(go));

  always @(posedge sclk or negedge srst_ni) begin
    if (!srst_ni) begin valid_q <= 1'b0; sent = 0; end
    else begin
      if (valid_q && ready) begin sent = sent + 1; valid_q <= 1'b0; end
      if ((!valid_q || ready) && go && !idle && !(valid_q && ready)) valid_q <= 1'b1;
      if (valid_q && !ready) tb_cov($sformatf("tb_sf_albion_cdc.pulse%0d.source_blocked", ID));
    end
  end
  always @(posedge dclk or negedge drst_ni) begin
    if (!drst_ni) begin got = 0; pulse_prev = 1'b0; end
    else begin
      if (pulse) begin
        got = got + 1;
        tb_check(!pulse_prev, $sformatf("pulse[%0d]: pulse_o high for two consecutive dst cycles", ID));
      end
      pulse_prev = pulse;
    end
  end

  initial begin
    finished_o = 1'b0;
    tb_cov_declare($sformatf("tb_sf_albion_cdc.pulse%0d.source_blocked", ID));
    tb_cov_declare($sformatf("tb_sf_albion_cdc.pulse%0d.events_checked", ID));
    #1 srst_ni = 1'b0; drst_ni = 1'b0;
    #50 srst_ni = 1'b1; drst_ni = 1'b1;
    for (int k = 0; k < 6; k++) begin
      #50000;
      // stop sending, wait for everything in flight, then compare counts
      force_idle();
      #((8 * STAGES + 8) * (SP > DP ? SP : DP));
      tb_check(got == sent, $sformatf("pulse[%0d]: %0d events accepted but %0d pulses received", ID, sent, got));
      tb_cov($sformatf("tb_sf_albion_cdc.pulse%0d.events_checked", ID));
      release_idle();
    end
    finished_o = 1'b1;
  end

  task automatic force_idle(); idle = 1'b1; endtask
  task automatic release_idle(); idle = 1'b0; endtask
  initial idle = 1'b0;
endmodule

// ----------------------------------------------------------------------------
module sf_albion_tb_cdc_fifo_case #(
  parameter int unsigned ID     = 0,
  parameter int unsigned WIDTH  = 16,
  parameter int unsigned ADDR_W = 3,
  parameter int unsigned WP     = 10,
  parameter int unsigned RP     = 14,
  parameter int unsigned STAGES = 2
) (
  output logic finished_o
);
  import sf_albion_tb_pkg::*;
  localparam int unsigned DEPTH = 2 ** ADDR_W;
  logic wclk = 1'b0, rclk = 1'b0, arst_ni = 1'b1;
  initial begin #(2 + ID);     forever #(WP / 2) wclk = ~wclk; end
  initial begin #(5 + 2 * ID); forever #(RP / 2) rclk = ~rclk; end

  logic wr_rst_n, rd_rst_n;
  sf_albion_reset_sync u_wrs (.clk_i(wclk), .arst_ni, .rst_no(wr_rst_n));
  sf_albion_reset_sync u_rrs (.clk_i(rclk), .arst_ni, .rst_no(rd_rst_n));

  logic             wr_valid, wr_ready, rd_valid, rd_ready;
  logic [WIDTH-1:0] wr_data, rd_data;
  sf_albion_async_fifo #(.WIDTH(WIDTH), .ADDR_W(ADDR_W), .SYNC_STAGES(STAGES)) u_dut (
    .wr_clk_i(wclk), .wr_rst_ni(wr_rst_n), .wr_valid_i(wr_valid), .wr_ready_o(wr_ready), .wr_data_i(wr_data),
    .rd_clk_i(rclk), .rd_rst_ni(rd_rst_n), .rd_valid_o(rd_valid), .rd_ready_i(rd_ready), .rd_data_o(rd_data));

  logic [2:0] wmode, rmode;
  logic       wgo, rgo;
  sf_albion_tb_stall #(.SEED(32'h7100 + 32'(ID))) u_wgo (.clk_i(wclk), .rst_ni(wr_rst_n), .mode_i(wmode), .go_o(wgo));
  sf_albion_tb_stall #(.SEED(32'h7200 + 32'(ID))) u_rgo (.clk_i(rclk), .rst_ni(rd_rst_n), .mode_i(rmode), .go_o(rgo));
  assign rd_ready = rgo;

  logic [WIDTH-1:0] expected [$];
  int unsigned wr_count, rd_count, target, issued;
  logic [63:0] rng;
  string pfx;

  // writer
  always @(posedge wclk or negedge wr_rst_n) begin
    if (!wr_rst_n) begin
      wr_valid <= 1'b0; wr_data <= '0; wr_count = 0; issued = 0;
    end else begin
      if (wr_valid && wr_ready) begin
        expected.push_back(wr_data);
        wr_count = wr_count + 1;
        wr_valid <= 1'b0;
      end
      if ((!wr_valid || wr_ready) && wgo && issued < target) begin
        wr_valid <= 1'b1;
        wr_data  <= WIDTH'(tb_rand64());
        issued = issued + 1;
      end
      if (wr_valid && !wr_ready) tb_cov({pfx, ".writer_blocked_full"});
    end
  end
  // reader + scoreboard
  always @(posedge rclk or negedge rd_rst_n) begin
    if (!rd_rst_n) begin
      rd_count = 0;
    end else begin
      if (rd_valid && rd_ready) begin
        if (expected.size() == 0) tb_fail({pfx, ": data read from an empty scoreboard (duplicate / spurious)"});
        else begin
          logic [WIDTH-1:0] e;
          e = expected.pop_front();
          tb_check(rd_data === e, $sformatf("%s: read %h expected %h", pfx, rd_data, e));
          rd_count = rd_count + 1;
          tb_cov({pfx, ".words_checked"});
        end
      end
      if (!rd_valid && rd_ready) tb_cov({pfx, ".reader_waiting_empty"});
    end
  end
  // the scoreboard is emptied by the same asynchronous reset as the FIFO
  always @(negedge arst_ni) begin expected.delete(); end
  always @(negedge wr_rst_n) begin expected.delete(); end

  // pointer / occupancy monitors
  logic [ADDR_W:0] wg_prev, rg_prev;
  always @(posedge wclk) begin
    if (wr_rst_n) begin
      tb_check($countones(u_dut.wgray_q ^ wg_prev) <= 1, $sformatf("%s: write Gray pointer changed by more than one bit", pfx));
    end
    wg_prev <= u_dut.wgray_q;
  end
  always @(posedge rclk) begin
    if (rd_rst_n) begin
      tb_check($countones(u_dut.rgray_q ^ rg_prev) <= 1, $sformatf("%s: read Gray pointer changed by more than one bit", pfx));
    end
    rg_prev <= u_dut.rgray_q;
  end
  always @(posedge wclk) if (wr_rst_n) tb_check(expected.size() <= DEPTH, $sformatf("%s: occupancy %0d above depth %0d", pfx, expected.size(), DEPTH));

  task automatic phase(input logic [2:0] wm, input logic [2:0] rm, input int unsigned n);
    int unsigned guard;
    #1;
    wmode = wm; rmode = rm;
    target = issued + n;
    guard = 0;
    while (!(wr_count >= target && expected.size() == 0 && !wr_valid) && guard < 400000) begin
      @(posedge rclk);
      guard++;
    end
    tb_check(wr_count >= target && expected.size() == 0,
             $sformatf("%s: timed out: written %0d target %0d unread %0d", pfx, wr_count, target, expected.size()));
  endtask

  initial begin
    finished_o = 1'b0;
    pfx = $sformatf("tb_sf_albion_cdc.fifo%0d", ID);
    wmode = 3'd0; rmode = 3'd0; target = 0; rng = 64'h1;
    tb_cov_declare({pfx, ".words_checked"}); tb_cov_declare({pfx, ".writer_blocked_full"});
    tb_cov_declare({pfx, ".reader_waiting_empty"}); tb_cov_declare({pfx, ".reset_mid_traffic"});
    #1 arst_ni = 1'b0;
    #60 arst_ni = 1'b1;
    repeat (8) @(posedge wclk);
    for (int sm = 0; sm < 8; sm++)
      for (int km = 0; km < 8; km++) begin
        if (sm == 6 || km == 6) continue;
        phase(sm[2:0], km[2:0], 60);
      end
    // reset in the middle of traffic (both domains reset together, asynchronously)
    for (int round = 0; round < 4; round++) begin
      #1;
      wmode = 3'd1; rmode = 3'd2; target = target + 300;
      #(WP * (30 + tb_below(40)));
      arst_ni = 1'b0;
      #(WP + RP);
      arst_ni = 1'b1;
      repeat (8) @(posedge wclk);
      repeat (8) @(posedge rclk);
      tb_cov({pfx, ".reset_mid_traffic"});
      phase(3'd3, 3'd3, 120);
    end
    phase(3'd0, 3'd0, 500);
    finished_o = 1'b1;
  end
endmodule

// ----------------------------------------------------------------------------
module tb_sf_albion_cdc;
  localparam int unsigned N = 17;
  logic [N-1:0] fin;
  // reset synchroniser: 2 and 3 stages
  sf_albion_tb_cdc_rst_case   #(.ID(0), .STAGES(2), .PERIOD(10)) u_r0 (.finished_o(fin[0]));
  sf_albion_tb_cdc_rst_case   #(.ID(1), .STAGES(3), .PERIOD(14)) u_r1 (.finished_o(fin[1]));
  // bit synchroniser: fast->slow, slow->fast, equal, 3 stages
  sf_albion_tb_cdc_bit_case   #(.ID(0), .STAGES(2), .SP(10), .DP(7))  u_b0 (.finished_o(fin[2]));
  sf_albion_tb_cdc_bit_case   #(.ID(1), .STAGES(2), .SP(6),  .DP(14)) u_b1 (.finished_o(fin[3]));
  sf_albion_tb_cdc_bit_case   #(.ID(2), .STAGES(3), .SP(10), .DP(10)) u_b2 (.finished_o(fin[4]));
  // pulse crossing
  sf_albion_tb_cdc_pulse_case #(.ID(0), .STAGES(2), .SP(10), .DP(7))  u_p0 (.finished_o(fin[5]));
  sf_albion_tb_cdc_pulse_case #(.ID(1), .STAGES(2), .SP(6),  .DP(22)) u_p1 (.finished_o(fin[6]));
  sf_albion_tb_cdc_pulse_case #(.ID(2), .STAGES(3), .SP(22), .DP(6))  u_p2 (.finished_o(fin[7]));
  // asynchronous FIFO over several clock ratios, depths, widths
  sf_albion_tb_cdc_fifo_case  #(.ID(0), .WIDTH(16), .ADDR_W(2), .WP(10), .RP(14), .STAGES(2)) u_f0 (.finished_o(fin[8]));
  sf_albion_tb_cdc_fifo_case  #(.ID(1), .WIDTH(8),  .ADDR_W(3), .WP(14), .RP(10), .STAGES(2)) u_f1 (.finished_o(fin[9]));
  sf_albion_tb_cdc_fifo_case  #(.ID(2), .WIDTH(32), .ADDR_W(4), .WP(10), .RP(10), .STAGES(2)) u_f2 (.finished_o(fin[10]));
  sf_albion_tb_cdc_fifo_case  #(.ID(3), .WIDTH(5),  .ADDR_W(2), .WP(6),  .RP(34), .STAGES(2)) u_f3 (.finished_o(fin[11]));
  sf_albion_tb_cdc_fifo_case  #(.ID(4), .WIDTH(64), .ADDR_W(3), .WP(34), .RP(6),  .STAGES(2)) u_f4 (.finished_o(fin[12]));
  sf_albion_tb_cdc_fifo_case  #(.ID(5), .WIDTH(12), .ADDR_W(3), .WP(22), .RP(26), .STAGES(3)) u_f5 (.finished_o(fin[13]));
  sf_albion_tb_cdc_fifo_case  #(.ID(6), .WIDTH(148), .ADDR_W(2), .WP(10), .RP(16), .STAGES(2)) u_f6 (.finished_o(fin[14]));
  sf_albion_tb_cdc_fifo_case  #(.ID(7), .WIDTH(9),  .ADDR_W(5), .WP(18), .RP(10), .STAGES(2)) u_f7 (.finished_o(fin[15]));
  sf_albion_tb_cdc_fifo_case  #(.ID(8), .WIDTH(7),  .ADDR_W(2), .WP(10), .RP(12), .STAGES(2)) u_f8 (.finished_o(fin[16]));

  initial begin
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_cdc");
    $finish;
  end
endmodule

`default_nettype wire
