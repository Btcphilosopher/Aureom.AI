// =============================================================================
//  sf_albion_tb_stall.sv  --  randomised valid/ready "go" pattern generator
//  (testbench only; never synthesized)
// -----------------------------------------------------------------------------
//  Drives a one-bit `go_o` that testbenches use as "the source offers data
//  this cycle" or "the sink is ready this cycle".  The pattern is selected at
//  run time by mode_i so one testbench can sweep every back-pressure regime:
//
//    mode_i  behaviour
//    ------  --------------------------------------------------------------
//      0     always go (no back-pressure)
//      1     go with 50 % probability each cycle
//      2     go with 10 % probability (heavily back-pressured)
//      3     go with 90 % probability (lightly back-pressured)
//      4     bursty: alternates runs of 1..16 go cycles and 1..16 stall cycles
//      5     long stalls: runs of 20..60 stall cycles between 1..4 go cycles
//      6     never go (used to fill buffers completely)
//      7     alternate every cycle
//
//  Each instance has its own xorshift32 state, so instances are independent
//  and a SEED parameter reproduces the stream exactly.
// =============================================================================
`default_nettype none

module sf_albion_tb_stall #(
  parameter logic [31:0] SEED = 32'h1234_5678
) (
  input  wire logic       clk_i,
  input  wire logic       rst_ni,
  input  wire logic [2:0] mode_i,
  output logic            go_o
);
  logic [31:0] rng_q;
  logic [31:0] rng_next;
  logic [7:0]  run_q;     // remaining cycles in the current bursty run
  logic        phase_q;   // current bursty phase level
  logic        toggle_q;

  always_comb begin
    rng_next = rng_q;
    rng_next = rng_next ^ (rng_next << 13);
    rng_next = rng_next ^ (rng_next >> 17);
    rng_next = rng_next ^ (rng_next << 5);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rng_q    <= (SEED == 32'h0) ? 32'h1 : SEED;
      run_q    <= 8'd0;
      phase_q  <= 1'b0;
      toggle_q <= 1'b0;
      go_o     <= 1'b0;
    end else begin
      rng_q    <= rng_next;
      toggle_q <= ~toggle_q;
      case (mode_i)
        3'd0:    go_o <= 1'b1;
        3'd1:    go_o <= rng_next[7];
        3'd2:    go_o <= (rng_next[15:8] < 8'd26);
        3'd3:    go_o <= (rng_next[15:8] < 8'd230);
        3'd4: begin
          if (run_q == 8'd0) begin
            phase_q <= ~phase_q;
            run_q   <= {4'h0, rng_next[19:16]} + 8'd1;
            go_o    <= ~phase_q;
          end else begin
            run_q <= run_q - 8'd1;
            go_o  <= phase_q;
          end
        end
        3'd5: begin
          if (run_q == 8'd0) begin
            phase_q <= ~phase_q;
            // The new level is ~phase_q.  New level 1 = a short go run,
            // new level 0 = a long stall run.
            run_q   <= phase_q ? ({2'h0, rng_next[21:16]} % 8'd41 + 8'd20)
                               : ({6'h0, rng_next[17:16]} + 8'd1);
            go_o    <= ~phase_q;
          end else begin
            run_q <= run_q - 8'd1;
            go_o  <= phase_q;
          end
        end
        3'd6:    go_o <= 1'b0;
        default: go_o <= toggle_q;
      endcase
    end
  end
endmodule

`default_nettype wire
