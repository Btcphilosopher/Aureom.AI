// =============================================================================
//  fv_sf_albion_tag_tracker.sv  --  formal wrapper for sf_albion_tag_tracker
// -----------------------------------------------------------------------------
//  WELL = 1 : the environment obeys the initiator contract (it returns only
//             tags that are outstanding, in request order -- stated as
//             assumptions by sf_albion_link_checker in ASSUME_RSP mode).
//             Proved for every such environment:
//    TT-1  the allocations form a legal request stream: no tag is reused while
//          outstanding (ALP-TAG-01) and the limit is respected (ALP-OUT-01)
//          -- asserted by sf_albion_link_checker
//    TT-2  the tag handed out is the lowest free one; it is always < NUM_TAGS
//    TT-3  outstanding_o / full_o / empty_o / alloc_ready_o are exact
//    TT-4  no error flag or fatal error ever rises
//    TT-5  context: the context stored at allocation comes back at free
//          (symbolic watch tag, any value)
//    TT-6  abandon: a tag abandoned while outstanding is reported "drop" when
//          its response arrives, a normal tag is not (symbolic watch tag);
//          an abandon in the cycle of the response is too late
//  WELL = 0 : the environment is arbitrary (spurious, duplicate, out-of-order
//             frees; abandons of any tag).  CHECK_ORDER is off.  Proved:
//    TT-7  outstanding_o <= NUM_TAGS; alloc never returns a busy tag
//    TT-8  free_unexpected_o is exactly "free of a tag that is not outstanding"
//    TT-9  the fatal error latches on such a free, blocks allocation, and
//          stays set until reset
//  COVER_IDX >= 0 selects reachability mode (see fv_sf_albion_fifo.sv).
// =============================================================================
module fv_sf_albion_tag_tracker #(
  parameter integer NUM_TAGS    = 3,
  parameter integer CTX_W       = 2,
  parameter integer CHECK_ORDER = 1,
  parameter integer WELL        = 1,
  parameter integer COVER_IDX   = -1
) (
  input  wire             clk_i,
  input  wire             rst_ni,
  input  wire             alloc_valid_i,
  input  wire [CTX_W-1:0] alloc_ctx_i,
  input  wire             free_valid_i,
  input  wire [7:0]       free_tag_i,
  input  wire             abandon_valid_i,
  input  wire [7:0]       abandon_tag_i,
  input  wire             abandon_all_i
);
  localparam         PROVE = (COVER_IDX < 0);
  localparam integer CNT_W = $clog2(NUM_TAGS + 1);

  wire             alloc_ready;
  wire [7:0]       alloc_tag;
  wire [CTX_W-1:0] free_ctx;
  wire             free_drop, free_unexpected, free_order_err;
  wire [CNT_W-1:0] outstanding;
  wire             full, empty, sticky;

  sf_albion_tag_tracker #(.NUM_TAGS(NUM_TAGS), .CTX_W(CTX_W), .CHECK_ORDER(CHECK_ORDER != 0)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .alloc_valid_i(alloc_valid_i), .alloc_ready_o(alloc_ready), .alloc_tag_o(alloc_tag), .alloc_ctx_i(alloc_ctx_i),
    .free_valid_i(free_valid_i), .free_tag_i(free_tag_i), .free_ctx_o(free_ctx), .free_drop_o(free_drop),
    .free_unexpected_o(free_unexpected), .free_order_err_o(free_order_err),
    .abandon_valid_i(abandon_valid_i), .abandon_tag_i(abandon_tag_i), .abandon_all_i(abandon_all_i),
    .outstanding_o(outstanding), .full_o(full), .empty_o(empty), .sticky_err_o(sticky));

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  // Initiator obligation ALP-RST-01: no valid while reset is asserted.
  always @(*) if (!rst_ni) assume (!alloc_valid_i && !free_valid_i);

  wire alloc_fire = alloc_valid_i && alloc_ready;

  // ---------------- shadow state, kept from the interface events only
  reg [NUM_TAGS-1:0] sh_busy_q;
  wire tag_in_range = (free_tag_i < NUM_TAGS);
  reg  free_hit;
  integer i, k;
  always @(*) begin
    free_hit = 1'b0;
    for (i = 0; i < NUM_TAGS; i = i + 1) if (free_tag_i == i) free_hit = sh_busy_q[i];
  end

  (* anyconst *) reg [7:0] wt;                       // watch tag
  reg [CTX_W-1:0] wt_ctx_q;
  reg             wt_aband_q;
  wire            wt_valid = (wt < NUM_TAGS);

  // In WELL mode a response is only ever returned for an outstanding tag, in order.
  // The in-order assumption is provided by the link checker below; here the
  // "free ok" event is simply a free of an outstanding tag.
  wire free_event = free_valid_i && free_hit;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sh_busy_q  <= {NUM_TAGS{1'b0}};
      wt_ctx_q   <= {CTX_W{1'b0}};
      wt_aband_q <= 1'b0;
    end else begin
      // order of updates mirrors the contract: abandon marks, free clears, alloc sets
      if ((abandon_all_i && sh_busy_q[wt]) || (abandon_valid_i && abandon_tag_i == wt && sh_busy_q[wt]))
        wt_aband_q <= 1'b1;
      if (free_event && free_tag_i == wt) wt_aband_q <= 1'b0;
      if (alloc_fire && alloc_tag == wt) begin wt_aband_q <= 1'b0; wt_ctx_q <= alloc_ctx_i; end
      for (i = 0; i < NUM_TAGS; i = i + 1) begin
        if (free_event && free_tag_i == i && !(WELL == 0 && CHECK_ORDER != 0)) sh_busy_q[i] <= 1'b0;
        if (alloc_fire && alloc_tag == i) sh_busy_q[i] <= 1'b1;
      end
    end
  end

  generate
    if (WELL != 0) begin : gen_well
      // The allocation stream as a link: request = allocation, response = free.
      // The response side is ASSUMED to obey the contract (outstanding tag, in order).
      wire [235:0] lreq = {4'd1, alloc_tag, 8'd16, 8'd0, 64'd0, 16'hFFFF, 128'd0};
      wire [147:0] lrsp = {free_tag_i, 4'd0, 8'b0000_0010, 128'd0};
      wire [15:0]  lout;
      sf_albion_link_checker #(.MAX_OUTSTANDING(NUM_TAGS), .CHECK_LEGALITY(1'b0), .CHECK_LANES(1'b0), .ASSUME_REQ(1'b0), .ASSUME_RSP(1'b1)) u_link (
        .clk_i(clk_i), .rst_ni(rst_ni),
        .req_valid_i(alloc_fire), .req_ready_i(1'b1), .req_i(lreq),
        .rsp_valid_i(free_valid_i), .rsp_ready_i(1'b1), .rsp_i(lrsp),
        .waive_req_i(1'b0), .outstanding_o(lout));

      always @(posedge clk_i) begin
        if (PROVE && rst_ni && !init_q) begin
          if (alloc_ready) begin
            a_tt_2_range:  assert (alloc_tag < NUM_TAGS);
            a_tt_2_free:   assert (!sh_busy_q[alloc_tag]);
          end
          for (k = 0; k < NUM_TAGS; k = k + 1)
            if (alloc_ready && k < alloc_tag) assert (sh_busy_q[k]);   // TT-2 lowest free (unlabelled: unrolled loop)
          a_tt_3_count: assert (outstanding == lout[CNT_W-1:0]);
          a_tt_3_full:  assert (full  == (lout == NUM_TAGS));
          a_tt_3_empty: assert (empty == (lout == 0));
          a_tt_3_ready: assert (alloc_ready == (lout != NUM_TAGS));
          a_tt_4_unexp: assert (!free_unexpected);
          a_tt_4_order: assert (!free_order_err);
          a_tt_4_stick: assert (!sticky);
          if (free_event && free_tag_i == wt && wt_valid) begin
            a_tt_5_ctx:  assert (free_ctx == wt_ctx_q);
            a_tt_6_drop: assert (free_drop == wt_aband_q);
          end
        end
      end
    end else begin : gen_arb
      always @(posedge clk_i) begin
        if (PROVE && rst_ni && !init_q) begin
          a_tt_7_bound: assert (outstanding <= NUM_TAGS);
          if (alloc_ready) a_tt_7_free: assert (alloc_tag < NUM_TAGS && !sh_busy_q[alloc_tag]);
          a_tt_8_unexp: assert (free_unexpected == (free_valid_i && !free_hit));
          a_tt_9_block: assert (!(sticky && alloc_ready));
        end
      end
      // the fatal error latches and stays set until reset
      reg prev_event_q, prev_sticky_q;
      always @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin prev_event_q <= 1'b0; prev_sticky_q <= 1'b0; end
        else begin prev_event_q <= free_unexpected || free_order_err; prev_sticky_q <= sticky; end
      end
      always @(posedge clk_i) begin
        if (PROVE && rst_ni && !init_q) begin
          if (prev_event_q)  a_tt_9_latch: assert (sticky);
          if (prev_sticky_q) a_tt_9_hold:  assert (sticky);
        end
      end
    end
  endgenerate

  wire [5:0] cov_vec;
  assign cov_vec[0] = rst_ni && !init_q && full;
  assign cov_vec[1] = rst_ni && !init_q && alloc_fire && free_event;
  assign cov_vec[2] = rst_ni && !init_q && free_event && free_tag_i == wt && wt_valid && wt_aband_q;
  assign cov_vec[3] = rst_ni && !init_q && free_event && free_tag_i == wt && wt_valid && !wt_aband_q;
  assign cov_vec[4] = rst_ni && !init_q && free_unexpected;
  assign cov_vec[5] = rst_ni && !init_q && sticky;
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
