// =============================================================================
//  tb_sf_albion_regslice.sv  --  self-checking test of sf_albion_regslice in all four modes (bypass, forward, backward, full)
// =============================================================================
`default_nettype none
module tb_sf_albion_regslice;
  localparam int unsigned N = 8;
  logic [N-1:0] fin;
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(0), .KIND(2), .WIDTH(8), .DEPTH(1), .MODE(0),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_0 (.finished_o(fin[0]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(1), .KIND(2), .WIDTH(8), .DEPTH(1), .MODE(1),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_1 (.finished_o(fin[1]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(2), .KIND(2), .WIDTH(8), .DEPTH(1), .MODE(2),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_2 (.finished_o(fin[2]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(3), .KIND(2), .WIDTH(8), .DEPTH(1), .MODE(3),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_3 (.finished_o(fin[3]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(4), .KIND(2), .WIDTH(1), .DEPTH(1), .MODE(1),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_4 (.finished_o(fin[4]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(5), .KIND(2), .WIDTH(236), .DEPTH(1), .MODE(2),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_5 (.finished_o(fin[5]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(6), .KIND(2), .WIDTH(148), .DEPTH(1), .MODE(3),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_6 (.finished_o(fin[6]));
  sf_albion_tb_stage_sweep #(.TB_NAME("tb_sf_albion_regslice"), .ID(7), .KIND(2), .WIDTH(33), .DEPTH(1), .MODE(2),
                            .ITEMS(150), .FLUSH_TEST(1'b0)) u_sweep_7 (.finished_o(fin[7]));

  initial begin
    wait (&fin);
    #20;
    sf_albion_tb_pkg::tb_report("tb_sf_albion_regslice");
    $finish;
  end
endmodule
`default_nettype wire
