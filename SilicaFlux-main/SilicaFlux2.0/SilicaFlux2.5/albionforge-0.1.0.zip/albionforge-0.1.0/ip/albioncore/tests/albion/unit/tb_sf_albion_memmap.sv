// =============================================================================
//  tb_sf_albion_memmap.sv  --  self-check and dump of the generated memory map
// -----------------------------------------------------------------------------
//  Elaborated against the PROFILE's sf_albion_memmap_pkg.  Two jobs:
//   1. an independent SystemVerilog check of the map invariants (a third
//      implementation next to the Python generator and the brute-force oracle
//      of the tool tests): sizes are powers of two, bases are aligned to their
//      sizes, masks are ~(size-1), enabled regions never overlap, attribute
//      words have no reserved bits, every region lies inside 64 bits;
//   2. a dump  "MM <i> <base> <size> <attr> <asid> <enabled>"  per region,
//      which tools/albion/build/check_memmap_xlang.py compares line by line with
//      the C table, the Rust table and the Python model of the same profile.
// =============================================================================
`default_nettype none

module tb_sf_albion_memmap;
  import sf_albion_tb_pkg::*;
  localparam int unsigned N = sf_albion_memmap_pkg::SF_MM_NUM_REGIONS;

  logic [63:0] base_i [N];
  logic [63:0] size_i [N];
  logic [63:0] mask_i [N];
  logic [7:0]  attr_i [N];
  logic [3:0]  asid_i [N];
  logic        en_i   [N];

  initial begin
    for (int i = 0; i < N; i++) begin
      base_i[i] = sf_albion_memmap_pkg::SF_MM_BASES[i*64 +: 64];
      size_i[i] = sf_albion_memmap_pkg::SF_MM_SIZES[i*64 +: 64];
      mask_i[i] = sf_albion_memmap_pkg::SF_MM_MASKS[i*64 +: 64];
      attr_i[i] = sf_albion_memmap_pkg::SF_MM_ATTRS[i*8 +: 8];
      asid_i[i] = sf_albion_memmap_pkg::SF_MM_ASIDS[i*4 +: 4];
      en_i[i]   = sf_albion_memmap_pkg::SF_MM_ENABLED[i];
    end
    tb_cov_declare("regions_checked");
    tb_cov_declare("enabled_regions");
    tb_cov_declare("disabled_regions");
    tb_cov_declare("pairs_checked");
    for (int i = 0; i < N; i++) begin
      tb_check(size_i[i] != 0 && (size_i[i] & (size_i[i] - 64'd1)) == 0, $sformatf("region %0d: size not a power of two", i));
      tb_check((base_i[i] & (size_i[i] - 64'd1)) == 0, $sformatf("region %0d: base not aligned to size", i));
      tb_check(mask_i[i] == ~(size_i[i] - 64'd1), $sformatf("region %0d: mask != ~(size-1)", i));
      tb_check(base_i[i] + size_i[i] > base_i[i] || (base_i[i] + size_i[i]) == 64'd0, $sformatf("region %0d: wraps 2**64", i));
      tb_check(attr_i[i][1:0] != 2'd0, $sformatf("region %0d: neither readable nor writable", i));
      tb_check(attr_i[i][7:6] != 2'd3, $sformatf("region %0d: reserved memory type", i));
      tb_check(asid_i[i] <= 4'd4, $sformatf("region %0d: undefined address space", i));
      tb_cov("regions_checked");
      if (en_i[i]) tb_cov("enabled_regions"); else tb_cov("disabled_regions");
      for (int j = i + 1; j < N; j++) begin
        if (en_i[i] && en_i[j]) begin
          // masked-compare overlap test: two aligned power-of-two ranges overlap iff the
          // larger one's mask matches the other's base
          logic [63:0] big_mask;
          big_mask = (size_i[i] >= size_i[j]) ? mask_i[i] : mask_i[j];
          tb_check((base_i[i] & big_mask) != (base_i[j] & big_mask),
                   $sformatf("regions %0d and %0d overlap", i, j));
          tb_cov("pairs_checked");
        end
      end
      $display("MM %0d %016h %016h %02h %0d %0d", i, base_i[i], size_i[i], attr_i[i], asid_i[i], en_i[i]);
    end
    tb_report("tb_sf_albion_memmap");
    $finish;
  end
endmodule

`default_nettype wire
