#!/usr/bin/env python3
"""Self-tests of the AlbionCore build tools (python3 -m unittest, no extra dependencies).

A checker that only ever reports "OK" proves nothing.  These tests inject violations and check that
every tool refuses them with the right message:

  style_check      every rule S01..S17 fires on a fixture, the reference fixture is clean
  check_deps       orphan file, duplicate definition, undefined instance, cycle, layering, legacy-name collision
  gen_memmap       malformed maps are refused with the documented error codes, and the overlap decision agrees with
                   a page-granular brute-force oracle on thousands of random maps
  validate_params  unsupported features, other widths, oversize reference memory, unknown keys
  trace            missing evidence token, dangling rule id
  gen_proto        generated C / Rust agree with the package for every enum member
  make_dist        the zip contains every build tool and every manifest file, and no build output
"""
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
BUILD = os.path.join(ROOT, "tools", "albion", "build")
sys.path.insert(0, BUILD)

import albion_lib as lib  # noqa: E402
import style_check  # noqa: E402
import gen_memmap  # noqa: E402
import gen_proto  # noqa: E402
import albion_profile  # noqa: E402


def tool(name, *args, root=None):
    env = dict(os.environ)
    if root:
        env["ALBION_ROOT"] = root
    p = subprocess.run([sys.executable, os.path.join(BUILD, name)] + list(args), cwd=root or ROOT, env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return p.returncode, p.stdout


def copy_tree(dst):
    for sub in ("rtl", "tests/albion/common", "tests/albion/unit", "tests/albion/system", "tests/albion/cdc",
                "tests/albion/formal", "tools/albion/config", "docs/albion"):
        src = os.path.join(ROOT, sub)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(dst, sub), ignore=shutil.ignore_patterns("generated") if sub == "docs/albion" else None)
    os.makedirs(os.path.join(dst, "build", "gen"), exist_ok=True)


class StyleRules(unittest.TestCase):
    def test_fixtures(self):
        fx = os.path.join(ROOT, "tests", "albion", "fixtures", "style")
        for f in sorted(os.listdir(fx)):
            path = os.path.join(fx, f)
            with open(path) as fh:
                first = fh.readline()
            m = re.match(r"//\s*expect:(.*)", first)
            found = {r for _, r, _ in style_check.check_file(path)}
            if m is None:
                self.assertEqual(found, {"S01", "S02"}, "%s should violate S01 and S02, got %s" % (f, found))
                continue
            expect = set(m.group(1).split())
            self.assertEqual(found, expect, "%s: expected %s, got %s" % (f, sorted(expect), sorted(found)))

    def test_every_rule_has_a_fixture(self):
        fx = os.path.join(ROOT, "tests", "albion", "fixtures", "style")
        covered = set()
        for f in os.listdir(fx):
            covered |= {r for _, r, _ in style_check.check_file(os.path.join(fx, f))}
        self.assertEqual(set(style_check.RULES) - covered, set(), "style rules without a fixture that makes them fire")

    def test_repository_rtl_is_clean(self):
        rc, out = tool("style_check.py")
        self.assertEqual(rc, 0, out)


class DependencyChecker(unittest.TestCase):
    def run_variant(self, mutate):
        with tempfile.TemporaryDirectory() as tmp:
            copy_tree(tmp)
            mutate(tmp)
            return tool("check_deps.py", root=tmp)

    def add_file(self, tmp, rel, text, group=None):
        full = os.path.join(tmp, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w") as fh:
            fh.write(text)
        if group:
            mf = os.path.join(tmp, "tools/albion/config/manifest.yaml")
            with open(mf) as fh:
                s = fh.read()
            s = s.replace("\n%s:\n" % group, "\n%s:\n  - %s\n" % (group, rel), 1)
            with open(mf, "w") as fh:
                fh.write(s)

    SIMPLE = "// header\n`default_nettype none\nmodule %s (input wire logic a_i, output logic b_o);\n%s\n  assign b_o = a_i;\nendmodule\n`default_nettype wire\n"

    def test_baseline_clean(self):
        rc, out = self.run_variant(lambda t: None)
        self.assertEqual(rc, 0, out)

    def test_orphan_file(self):
        rc, out = self.run_variant(lambda t: self.add_file(t, "rtl/albion/sf_albion_orphan.sv", self.SIMPLE % ("sf_albion_orphan", "")))
        self.assertNotEqual(rc, 0)
        self.assertIn("D01", out)

    def test_undefined_instance(self):
        rc, out = self.run_variant(lambda t: self.add_file(
            t, "rtl/albion/sf_albion_undef.sv", self.SIMPLE % ("sf_albion_undef", "  sf_albion_nonexistent u_x (.a_i(a_i));"), "core"))
        self.assertIn("D04", out)

    def test_duplicate_definition(self):
        rc, out = self.run_variant(lambda t: self.add_file(
            t, "rtl/albion/sf_albion_dup.sv", self.SIMPLE % ("sf_albion_fifo", ""), "core"))
        self.assertIn("D03", out)

    def test_layering_core_to_cdc(self):
        rc, out = self.run_variant(lambda t: self.add_file(
            t, "rtl/albion/sf_albion_bad_layer.sv",
            self.SIMPLE % ("sf_albion_bad_layer", "  sf_albion_cdc_bit_sync u_s (.dst_clk_i(1'b0), .dst_rst_ni(1'b1), .src_i(a_i), .dst_o());"), "core"))
        self.assertIn("D06", out)

    def test_cycle(self):
        def mut(t):
            self.add_file(t, "rtl/albion/sf_albion_cyc_a.sv", self.SIMPLE % ("sf_albion_cyc_a", "  sf_albion_cyc_b u_b (.a_i(a_i), .b_o());"), "core")
            self.add_file(t, "rtl/albion/sf_albion_cyc_b.sv", self.SIMPLE % ("sf_albion_cyc_b", "  sf_albion_cyc_a u_a (.a_i(a_i), .b_o());"), "core")
        rc, out = self.run_variant(mut)
        self.assertIn("D05", out)

    def test_legacy_name_collision(self):
        def mut(t):
            self.add_file(t, "rtl/albion/sf_albion_sync_fifo.sv", self.SIMPLE % ("sf_albion_sync_fifo", ""), "core")
            with open(os.path.join(t, "tools/albion/config/legacy_names.txt"), "a") as fh:
                fh.write("sf_albion_sync_fifo\n")
        rc, out = self.run_variant(mut)
        self.assertIn("D07", out)

    def test_package_import_in_rtl(self):
        def mut(t):
            p = os.path.join(t, "rtl/albion/sf_albion_skid.sv")
            with open(p) as fh:
                s = fh.read().replace("  logic [WIDTH-1:0] main_data_q,", "  import sf_albion_pkg::*;\n  logic [WIDTH-1:0] main_data_q,", 1)
            with open(p, "w") as fh:
                fh.write(s)
        rc, out = self.run_variant(mut)
        self.assertIn("D09", out)


class MemoryMap(unittest.TestCase):
    CAT = {"address_width": 64, "min_region_bytes": 4096, "reserved": [{"name": "low", "base": 0, "size": 1 << 32}]}

    def codes(self, regions, reserved=None, addr_w=64, min_bytes=4096):
        return {c for c, _ in gen_memmap.check_regions(regions, reserved or [], addr_w, min_bytes)}

    def test_good(self):
        regs = [{"name": "a", "base": 1 << 32, "size": 1 << 20}, {"name": "b", "base": (1 << 32) + (1 << 20), "size": 1 << 12}]
        self.assertEqual(self.codes(regs, self.CAT["reserved"]), set())

    def test_overlap(self):
        regs = [{"name": "a", "base": 1 << 32, "size": 1 << 20}, {"name": "b", "base": (1 << 32) + (1 << 12), "size": 1 << 12}]
        self.assertEqual(self.codes(regs), {"E_OVERLAP"})

    def test_misaligned(self):
        self.assertEqual(self.codes([{"name": "a", "base": (1 << 32) + 4096, "size": 1 << 20}]), {"E_ALIGN"})

    def test_not_power_of_two(self):
        self.assertEqual(self.codes([{"name": "a", "base": 1 << 32, "size": 3 << 12}]), {"E_SIZE_POW2"})

    def test_too_small(self):
        self.assertEqual(self.codes([{"name": "a", "base": 1 << 32, "size": 16}]), {"E_SIZE_MIN"})

    def test_out_of_range(self):
        self.assertIn("E_RANGE", self.codes([{"name": "a", "base": 1 << 63, "size": 1 << 63}], addr_w=40))

    def test_duplicate_and_format(self):
        regs = [{"name": "a", "base": 1 << 32, "size": 4096}, {"name": "a", "base": 2 << 32, "size": 4096},
                {"name": "Bad-Name", "base": 3 << 32, "size": 4096}]
        self.assertEqual(self.codes(regs), {"E_NAME_DUP", "E_NAME_FMT"})

    def test_reserved_window(self):
        self.assertEqual(self.codes([{"name": "a", "base": 0, "size": 1 << 20}], self.CAT["reserved"]), {"E_RESERVED"})

    def test_oracle_random_maps(self):
        """Overlap decision == page-granular brute force, on random aligned power-of-two regions."""
        rng = random.Random(7)
        page, space_pages = 4096, 256
        for _ in range(4000):
            regs = []
            for i in range(rng.randint(2, 6)):
                size_pages = 1 << rng.randint(0, 5)
                base_page = rng.randrange(0, space_pages // size_pages) * size_pages
                regs.append({"name": "r%d" % i, "base": base_page * page, "size": size_pages * page})
            occupied, collision = set(), False
            for r in regs:
                pages = set(range(r["base"] // page, (r["base"] + r["size"]) // page))
                if occupied & pages:
                    collision = True
                occupied |= pages
            got = "E_OVERLAP" in self.codes(regs, addr_w=20)
            self.assertEqual(got, collision, regs)

    def test_cli_refuses_collision(self):
        with tempfile.TemporaryDirectory() as tmp:
            cat = os.path.join(tmp, "cat.yaml")
            with open(cat, "w") as cf:
                cf.write(
                "version: 1\naddress_width: 64\nmin_region_bytes: 4096\nreserved: []\nregions:\n"
                "  - {name: a, base: 0x100000000, size: 0x100000, asid: device, attr: {read: true}}\n"
                "  - {name: b, base: 0x100010000, size: 0x10000, asid: device, attr: {read: true}}\n")
            p = subprocess.run([sys.executable, os.path.join(BUILD, "gen_memmap.py"), "--catalogue", cat, "--catalogue-default", "--check-only"],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            self.assertNotEqual(p.returncode, 0)
            self.assertIn("E_OVERLAP", p.stdout)


class Profiles(unittest.TestCase):
    def prof(self, **over):
        p = lib.load_yaml(os.path.join(ROOT, "tools", "albion", "config", "albion_min.yaml"))
        for k, v in over.items():
            sect, _, key = k.partition("__")
            if key:
                p[sect][key] = v
            else:
                p[sect] = v
        return p

    def errors(self, p):
        return albion_profile.validate("min", p)[0]

    def test_valid(self):
        self.assertEqual(self.errors(self.prof()), [])

    def test_atomics_refused(self):
        self.assertTrue(any("atomic" in e for e in self.errors(self.prof(features__atomics=True))))

    def test_out_of_order_refused(self):
        self.assertTrue(any("out_of_order" in e for e in self.errors(self.prof(features__out_of_order=True))))

    def test_other_width_refused(self):
        errs = self.errors(self.prof(protocol__data_w=256))
        self.assertTrue(any("sf_albion_width_adapter" in e for e in errs), errs)

    def test_oversize_reference_memory(self):
        errs = self.errors(self.prof(reference_design__mem_words=1 << 14))
        self.assertTrue(any("mem_words" in e for e in errs), errs)

    def test_too_many_tags(self):
        self.assertTrue(any("client_tags" in e for e in self.errors(self.prof(limits__client_tags=300))))

    def test_unknown_key(self):
        p = self.prof()
        p["typo_section"] = {}
        self.assertTrue(any("unknown top-level key" in e for e in self.errors(p)))

    def test_collision_in_profile(self):
        p = self.prof()
        p["memory_map"]["regions"]["sram"]["size"] = 1 << 40
        self.assertTrue(any("memory_map" in e for e in self.errors(p)))

    def test_disabled_sram_refused(self):
        p = self.prof()
        p["memory_map"]["regions"]["sram"] = {"enabled": False}
        self.assertTrue(any("sram" in e for e in self.errors(p)))


class Traceability(unittest.TestCase):
    def test_missing_token_and_dangling_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            copy_tree(tmp)
            cr = os.path.join(tmp, "tools/albion/config/contract_rules.yaml")
            with open(cr) as fh:
                s = fh.read().replace('token: "a_valid_held"', 'token: "no_such_label_anywhere"', 1)
            with open(cr, "w") as fh:
                fh.write(s)
            with open(os.path.join(tmp, "rtl/albion/sf_albion_skid.sv"), "a") as fh:
                fh.write("// mentions ALP-ZZZ-99 which is not a rule\n")
            rc, out = tool("contract_trace.py", "--check", root=tmp)
            self.assertNotEqual(rc, 0)
            self.assertIn("T02", out)
            self.assertIn("T03", out)

    def test_repository_is_consistent(self):
        rc, out = tool("contract_trace.py", "--check")
        self.assertEqual(rc, 0, out)


class ProtocolGenerator(unittest.TestCase):
    def test_enum_values_reach_c_and_rust(self):
        pkg = gen_proto.parse_package()
        c = gen_proto.gen_c(pkg)
        r = gen_proto.gen_rust(pkg)
        for ename, e in pkg["enums"].items():
            for m in e["members"]:
                self.assertRegex(c, r"#define ALBION_%s 0x%Xu" % (m["name"][3:], m["value"]))
                self.assertIn("= %d," % m["value"], r)

    def test_layout_cross_check_detects_drift(self):
        pkg = gen_proto.parse_package()
        pkg["consts"]["SF_REQ_TAG_LSB"] = 225
        self.assertTrue(gen_proto.crosscheck(pkg))


class Distribution(unittest.TestCase):
    def test_zip_is_complete_and_clean(self):
        with tempfile.TemporaryDirectory() as out:
            rc, o = tool("make_dist.py", "--out", out)
            self.assertEqual(rc, 0, o)
            zips = [f for f in os.listdir(out) if f.endswith(".zip")]
            self.assertEqual(len(zips), 1, o)
            with zipfile.ZipFile(os.path.join(out, zips[0])) as z:
                names = z.namelist()
            top = names[0].split("/")[0]
            rel = {n[len(top) + 1:] for n in names}
            # every build tool (tools/albion/build is SOURCE, not build output) and every manifest file
            for f in os.listdir(BUILD):
                if f.endswith(".py"):
                    self.assertIn("tools/albion/build/" + f, rel, f)
            man, group_of = __import__("check_deps").load_manifest()
            for f in group_of:
                self.assertIn(f, rel, f)
            for must in ("Makefile", "README.md", "tools/albion/config/tests.yaml", "docs/albion/BUILD.md"):
                self.assertIn(must, rel, must)
            # no build output, no caches
            self.assertFalse([n for n in rel if n.startswith(("build/", "dist/"))], "build output in the zip")
            self.assertFalse([n for n in rel if "__pycache__" in n or n.endswith(".pyc")], "caches in the zip")


if __name__ == "__main__":
    unittest.main(verbosity=1)
