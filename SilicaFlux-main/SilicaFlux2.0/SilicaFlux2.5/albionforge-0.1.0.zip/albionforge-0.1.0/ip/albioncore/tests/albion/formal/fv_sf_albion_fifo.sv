// =============================================================================
//  fv_sf_albion_fifo.sv  --  formal wrapper for sf_albion_fifo
// -----------------------------------------------------------------------------
//  Proved for every input sequence (inputs are free; reset may be asserted at
//  any time after the first cycle, asynchronously):
//    FIFO-1  no loss, no duplication, no reordering: a symbolic "watch item"
//            (the n-th accepted push, n chosen by the solver) comes out of the
//            FIFO unchanged and in its turn, for any data value
//    FIFO-2  occupancy: count_o == accepted pushes - delivered pops - flushed
//    FIFO-3  count_o <= DEPTH; full_o / empty_o / out_valid_o / in_ready_o are
//            exactly the functions of count_o and flush_i documented in the RTL
//    FIFO-4  a full FIFO never accepts a push
//    FIFO-5  output valid and data are stable until accepted, except for a flush
//    FIFO-6  out_valid_o is low and the FIFO is empty while reset is asserted
//  Cover points show the properties are not vacuous.  COVER_IDX >= 0 selects
//  "reachability mode": all proof assertions are disabled and the single
//  assertion "cover point COVER_IDX is never hit" is checked; a counterexample
//  is a witness trace that the point can be reached.
//  Plain Verilog-2005 style on purpose: it must run in the Yosys 0.33 flow.
// =============================================================================
module fv_sf_albion_fifo #(
  parameter integer WIDTH = 2,
  parameter integer DEPTH = 3,
  parameter integer COVER_IDX = -1
) (
  input  wire             clk_i,
  input  wire             rst_ni,
  input  wire             flush_i,
  input  wire             in_valid_i,
  input  wire [WIDTH-1:0] in_data_i,
  input  wire             out_ready_i
);
  localparam integer CNT_W = $clog2(DEPTH + 1);
  // Index counters count modulo 2**IW.  IW = CNT_W gives a modulus > DEPTH, which
  // is enough: item n + 2**IW cannot be pushed before item n has been popped,
  // so a watch index never refers to two live items at once.
  localparam integer IW    = CNT_W;
  localparam         PROVE = (COVER_IDX < 0);

  wire             in_ready;
  wire             out_valid;
  wire [WIDTH-1:0] out_data;
  wire [CNT_W-1:0] count;
  wire             full, empty;

  sf_albion_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni), .flush_i(flush_i),
    .in_valid_i(in_valid_i), .in_ready_o(in_ready), .in_data_i(in_data_i),
    .out_valid_o(out_valid), .out_ready_i(out_ready_i), .out_data_o(out_data),
    .count_o(count), .full_o(full), .empty_o(empty)
  );

  // reset is asserted in the first cycle only by assumption; afterwards it is free
  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  wire push = in_valid_i && in_ready;
  wire pop  = out_valid && out_ready_i;

  (* anyconst *) reg [IW-1:0] watch_n;
  reg [IW-1:0]    push_idx_q, pop_idx_q;
  reg [WIDTH-1:0] watch_data_q;
  reg             watch_stored_q;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      push_idx_q     <= {IW{1'b0}};
      pop_idx_q      <= {IW{1'b0}};
      watch_stored_q <= 1'b0;
      watch_data_q   <= {WIDTH{1'b0}};
    end else begin
      if (push) push_idx_q <= push_idx_q + 1'b1;
      if (flush_i)  pop_idx_q <= push_idx_q;          // everything queued is discarded
      else if (pop) pop_idx_q <= pop_idx_q + 1'b1;
      if (push && push_idx_q == watch_n) begin
        watch_stored_q <= 1'b1;
        watch_data_q   <= in_data_i;
      end
    end
  end

  // -------- output stability bookkeeping (valid held until accepted)
  reg             hold_q;
  reg [WIDTH-1:0] data_q;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin hold_q <= 1'b0; data_q <= {WIDTH{1'b0}}; end
    else begin hold_q <= out_valid && !out_ready_i && !flush_i; data_q <= out_data; end
  end

  always @(posedge clk_i) begin
    if (PROVE && rst_ni && !init_q) begin
      // FIFO-1
      if (pop && pop_idx_q == watch_n) begin
        a_fifo_1_data: assert (watch_stored_q && out_data == watch_data_q);
      end
      // FIFO-2 / FIFO-3
      a_fifo_2_count: assert (count == {1'b0, (push_idx_q - pop_idx_q)});
      a_fifo_3_bound: assert (count <= DEPTH);
      a_fifo_3_full:  assert (full  == (count == DEPTH));
      a_fifo_3_empty: assert (empty == (count == 0));
      a_fifo_3_valid: assert (out_valid == (count != 0));
      a_fifo_3_ready: assert (in_ready == ((count != DEPTH) && !flush_i));
      // FIFO-4
      a_fifo_4_full:  assert (!(push && full));
      // FIFO-5
      if (hold_q) begin
        a_fifo_5_valid: assert (out_valid);
        a_fifo_5_data:  assert (out_data == data_q);
      end
    end
    // FIFO-6
    if (PROVE && !rst_ni && !init_q) a_fifo_6_reset: assert (!out_valid && empty);
  end

  // -------- non-vacuity: reachability of interesting situations
  wire [5:0] cov_vec;
  assign cov_vec[0] = rst_ni && !init_q && full;
  assign cov_vec[1] = rst_ni && !init_q && push && pop;
  assign cov_vec[2] = rst_ni && !init_q && flush_i && !empty;
  assign cov_vec[3] = rst_ni && !init_q && pop && pop_idx_q == watch_n && watch_stored_q;
  assign cov_vec[4] = rst_ni && !init_q && push && push_idx_q == {IW{1'b0}} && pop_idx_q != push_idx_q;
  assign cov_vec[5] = rst_ni && !init_q && full && pop && !flush_i;
  always @(posedge clk_i) begin
    if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
  end
endmodule
