// =============================================================================
//  sf_albion_ref_top.sv  --  profile-configured reference target
// -----------------------------------------------------------------------------
//  Instantiates sf_albion_ref_subsystem with every parameter taken from the
//  generated sf_albion_cfg_pkg of the selected hardware profile
//  (tools/albion/config/albion_{min,cloud,hpc}.yaml).  This is the design that
//  is elaborated, simulated and synthesized to check a profile's resource budget.
// =============================================================================
`default_nettype none

module sf_albion_ref_top (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  input  wire logic              req_valid_i,
  output logic                   req_ready_o,
  input  sf_albion_pkg::sf_req_t req_i,
  output logic                   rsp_valid_o,
  input  wire logic              rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t rsp_o
);
  sf_albion_ref_subsystem #(
    .MAX_OUT       (sf_albion_cfg_pkg::CFG_MAX_OUT),
    .REGION_BASE   (sf_albion_cfg_pkg::CFG_REGION_BASE),
    .REGION_BYTES  (sf_albion_cfg_pkg::CFG_REGION_BYTES),
    .REGION_ATTR   (sf_albion_cfg_pkg::CFG_REGION_ATTR),
    .MEM_WORDS     (sf_albion_cfg_pkg::CFG_MEM_WORDS),
    .MEM_RSP_DEPTH (sf_albion_cfg_pkg::CFG_MEM_RSP_DEPTH),
    .MEM_EXTRA_LAT (sf_albion_cfg_pkg::CFG_MEM_EXTRA_LAT),
    .ERR_RSP_DEPTH (sf_albion_cfg_pkg::CFG_ERR_RSP_DEPTH)
  ) u_sub (
    .clk_i, .rst_ni,
    .req_valid_i, .req_ready_o, .req_i,
    .rsp_valid_o, .rsp_ready_i, .rsp_o
  );
endmodule

`default_nettype wire
