// =============================================================================
//  sf_albion_reset_sync.sv  --  reset synchroniser: asynchronous assertion,
//                               synchronous deassertion
// -----------------------------------------------------------------------------
//  Implements the Albion reset convention (docs/albion/RESET_CLOCK_CONTRACT.md):
//    * assertion is asynchronous: rst_no goes low as soon as arst_ni goes low;
//    * deassertion is synchronous: rst_no rises only on a clk_i edge, STAGES
//      edges after arst_ni was released, so that every flop in the domain
//      leaves reset in the same cycle and no flop sees reset removal near its
//      clock edge (recovery / removal).
//  Instantiate one per clock domain at the domain boundary; fan rst_no out to
//  all logic of that domain.  OPTIONAL when the whole design shares one clock
//  and an external, already synchronised reset.
//
//  Parameter  STAGES  number of flops in series (>= 2)
// =============================================================================
`default_nettype none

module sf_albion_reset_sync #(
  parameter int unsigned STAGES = 2
) (
  input  wire logic clk_i,
  input  wire logic arst_ni,    // asynchronous reset input, active low
  output logic      rst_no      // synchronised reset, active low
);
  if (STAGES < 2) begin : gen_param_check
    $error("sf_albion_reset_sync: STAGES must be >= 2");
  end

  logic [STAGES-1:0] sync_q;

  always_ff @(posedge clk_i or negedge arst_ni) begin
    if (!arst_ni) sync_q <= '0;
    else          sync_q <= {sync_q[STAGES-2:0], 1'b1};
  end

  assign rst_no = sync_q[STAGES-1];
endmodule

`default_nettype wire
