// =============================================================================
//  sf_albion_width_adapter.sv  --  explicit data-width converter for ALP links
// -----------------------------------------------------------------------------
//  ALP v1 fixes the package data width at 128 bits.  Other widths are reached
//  through this adapter.  It connects a "slave-side" link (this module is the
//  TARGET of that link) to a "master-side" link (this module is the INITIATOR
//  of that link).  Both links carry the same request / response fields; only
//  the data / byte-enable widths differ.  All port signals are flat so the
//  narrow link needs no package type.
//
//    DOWNSIZE = 1   slave side WIDE (128), master side NARROW_W
//    DOWNSIZE = 0   slave side NARROW_W,   master side WIDE (128)
//
//  Parameters
//    DOWNSIZE  see above
//    NARROW_W  narrow data width in bits: 8, 16, 32 or 64
//    MAX_OUT   DOWNSIZE = 0 only: size of the order queue.  At most MAX_OUT requests
//              are outstanding on the wide (master) link and at most MAX_OUT + 2 on
//              the narrow (slave) link (the order queue plus the two entries of the
//              response skid buffer).
//
//  Link word size and legality
//    A link of data width W obeys the ALP rules with W/8-byte words: addresses
//    are aligned to W/8 bytes, byte enables have W/8 bits.  The adapter checks
//    every slave-side request with the package legality rules (ALP-LEG-01).
//    An illegal request is never forwarded; the adapter answers it locally
//    with the legality status, in order with all other responses.
//
//  DOWNSIZE = 1  (wide request -> RATIO = 128/NARROW_W narrow beats)
//    * One wide transaction is in flight at a time: s_req_ready_o is high only
//      when idle.  Beats are issued back to back and their responses collected
//      in order.
//    * A beat whose byte-enable slice is all zero is skipped.  Beat k carries
//      wide bytes [k*NB +: NB] at address {wide_addr[63:4], 4'b0} + k*NB, and
//      the parent's op, domain and attributes.
//    * Narrow tag (ALP-TAG-01): the tag of a beat on the narrow link is its beat
//      index k (0 .. RATIO-1), NOT the parent's tag.  Up to RATIO beats can be
//      outstanding at once and their tags are pairwise different; the next
//      parent starts only after every beat of the previous one has responded.
//      The parent's tag is kept inside the adapter and returned on the wide link.
//    * Response rules.  A beat response is NON-CONFORMING if its tag is not the
//      beat's tag, its is_write flag is not the parent's, or it is not
//      well-formed (sf_rsp_wellformed_bits).  The wide status is
//        1. SF_ST_PROTOCOL_ERR if any beat response was non-conforming
//           (this wins over every other status, whatever the beat order),
//        2. else the status of the FIRST non-OKAY beat in beat order,
//        3. else OKAY.
//      Read data is reassembled from the beats; unless the status is OKAY the
//      data is all-zero (ALP-RSP-05).  The completion metadata is regenerated
//      (last = 1, poisoned == (status == ECC_UNCORR), is_write from the parent);
//      meta.corrected is the OR of the corrected flags of the CONFORMING beat
//      responses, whatever their status (it is informational).
//    * Atomicity: a wide write is NOT atomic across beats.  If a beat fails,
//      earlier beats have already been performed (ALP does not define atomics).
//
//  DOWNSIZE = 0  (narrow request -> one wide request)
//    * The narrow word is placed in its lane of the wide word chosen by
//      addr[3:log2(NARROW_W/8)]; the wide byte enables select only that lane.
//      Read data is extracted from the same lane.
//    * Up to MAX_OUT transactions are outstanding on the wide link; responses
//      return in order (forwarded and locally generated ones are merged by an
//      order queue).  The tag is passed through unchanged.
//    * A wide response that is NON-CONFORMING (wrong tag, wrong is_write flag or
//      not well-formed) is replaced by SF_ST_PROTOCOL_ERR with zero data and
//      regenerated metadata (corrected = 0).  A conforming response is forwarded
//      with its status and metadata; the data lane is extracted.
//
//  Timing.  No ready output depends combinationally on any input.  DOWNSIZE: the
//  slave-side ready and every response signal come from registers; the master-side
//  request fields are combinational functions of registers only.  UPSIZE: requests
//  and responses pass through skid buffers.
// =============================================================================
`default_nettype none

module sf_albion_width_adapter #(
  parameter bit          DOWNSIZE = 1'b1,
  parameter int unsigned NARROW_W = 32,
  parameter int unsigned MAX_OUT  = 4
) (
  input  wire logic                                     clk_i,
  input  wire logic                                     rst_ni,
  // ------------------------------------------------ slave-side link (we are the target)
  input  wire logic                                     s_req_valid_i,
  output logic                                          s_req_ready_o,
  input  wire logic [sf_albion_pkg::SF_OP_W-1:0]        s_req_op_i,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]       s_req_tag_i,
  input  wire logic [sf_albion_pkg::SF_DOM_W-1:0]       s_req_dom_i,
  input  wire logic [sf_albion_pkg::SF_ATTR_W-1:0]      s_req_attr_i,
  input  wire logic [sf_albion_pkg::SF_ADDR_W-1:0]      s_req_addr_i,
  input  wire logic [(DOWNSIZE ? sf_albion_pkg::SF_BE_W : NARROW_W/8)-1:0]   s_req_be_i,
  input  wire logic [(DOWNSIZE ? sf_albion_pkg::SF_DATA_W : NARROW_W)-1:0]   s_req_data_i,
  output logic                                          s_rsp_valid_o,
  input  wire logic                                     s_rsp_ready_i,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]            s_rsp_tag_o,
  output logic [sf_albion_pkg::SF_STATUS_W-1:0]         s_rsp_status_o,
  output logic [sf_albion_pkg::SF_CMETA_W-1:0]          s_rsp_meta_o,
  output logic [(DOWNSIZE ? sf_albion_pkg::SF_DATA_W : NARROW_W)-1:0]        s_rsp_data_o,
  // ------------------------------------------------ master-side link (we are the initiator)
  output logic                                          m_req_valid_o,
  input  wire logic                                     m_req_ready_i,
  output logic [sf_albion_pkg::SF_OP_W-1:0]             m_req_op_o,
  output logic [sf_albion_pkg::SF_TAG_W-1:0]            m_req_tag_o,
  output logic [sf_albion_pkg::SF_DOM_W-1:0]            m_req_dom_o,
  output logic [sf_albion_pkg::SF_ATTR_W-1:0]           m_req_attr_o,
  output logic [sf_albion_pkg::SF_ADDR_W-1:0]           m_req_addr_o,
  output logic [(DOWNSIZE ? NARROW_W/8 : sf_albion_pkg::SF_BE_W)-1:0]        m_req_be_o,
  output logic [(DOWNSIZE ? NARROW_W : sf_albion_pkg::SF_DATA_W)-1:0]        m_req_data_o,
  input  wire logic                                     m_rsp_valid_i,
  output logic                                          m_rsp_ready_o,
  input  wire logic [sf_albion_pkg::SF_TAG_W-1:0]       m_rsp_tag_i,
  input  wire logic [sf_albion_pkg::SF_STATUS_W-1:0]    m_rsp_status_i,
  input  wire logic [sf_albion_pkg::SF_CMETA_W-1:0]     m_rsp_meta_i,
  input  wire logic [(DOWNSIZE ? NARROW_W : sf_albion_pkg::SF_DATA_W)-1:0]   m_rsp_data_i
);
  localparam int unsigned WIDE_W  = sf_albion_pkg::SF_DATA_W;
  localparam int unsigned WIDE_B  = sf_albion_pkg::SF_BE_W;
  localparam int unsigned RATIO   = WIDE_W / NARROW_W;
  localparam int unsigned NB      = NARROW_W / 8;
  localparam int unsigned NLANE_W = $clog2(NB);                          // 0 when NARROW_W == 8
  localparam int unsigned OFF_W   = sf_albion_pkg::SF_LANE_W - NLANE_W;  // index of the narrow word in the wide word
  localparam int unsigned REQ_W   = sf_albion_pkg::SF_REQ_W;

  if (NARROW_W != 8 && NARROW_W != 16 && NARROW_W != 32 && NARROW_W != 64) begin : gen_param_check_width
    $error("sf_albion_width_adapter: NARROW_W must be 8, 16, 32 or 64");
  end
  if (MAX_OUT < 1 || MAX_OUT > 256) begin : gen_param_check_out
    $error("sf_albion_width_adapter: MAX_OUT must be in 1..256");
  end

  // ===========================================================================
  //  DOWNSIZE: wide slave side -> narrow master side
  // ===========================================================================
  if (DOWNSIZE) begin : gen_down
    localparam int unsigned BEAT_W = $clog2(RATIO);        // RATIO >= 2
    localparam logic [1:0]  ST_IDLE = 2'd0;
    localparam logic [1:0]  ST_BUSY = 2'd1;
    localparam logic [1:0]  ST_RESP = 2'd2;

    // ---- registers
    logic [1:0]               state_q, state_d;
    logic [sf_albion_pkg::SF_OP_W-1:0]   p_op_q;
    logic [sf_albion_pkg::SF_TAG_W-1:0]  p_tag_q;
    logic [sf_albion_pkg::SF_DOM_W-1:0]  p_dom_q;
    logic [sf_albion_pkg::SF_ATTR_W-1:0] p_attr_q;
    logic [sf_albion_pkg::SF_ADDR_W-1:sf_albion_pkg::SF_LANE_W] p_addr_hi_q;   // low bits are zero by legality
    logic [WIDE_B-1:0]        p_be_q;
    logic [WIDE_W-1:0]        p_data_q;
    logic [RATIO-1:0]         mask_q;
    logic [BEAT_W-1:0]        iss_idx_q, iss_idx_d;
    logic                     iss_act_q, iss_act_d;
    logic [BEAT_W-1:0]        col_idx_q, col_idx_d;
    logic [BEAT_W:0]          outst_q,   outst_d;
    logic [sf_albion_pkg::SF_STATUS_W-1:0] acc_st_q, acc_st_d;
    logic                     acc_corr_q, acc_corr_d;
    logic [WIDE_W-1:0]        rd_data_q, rd_data_d;
    logic [sf_albion_pkg::SF_TAG_W-1:0]    rsp_tag_q;
    logic [sf_albion_pkg::SF_STATUS_W-1:0] rsp_st_q;
    logic [sf_albion_pkg::SF_CMETA_W-1:0]  rsp_meta_q;
    logic [WIDE_W-1:0]        rsp_data_q;

    // First set bit of mask at an index greater than cur (or from index 0 when
    // `first`).  Returns {found, index}.
    function automatic logic [BEAT_W:0] next_beat(input logic [RATIO-1:0] mask,
                                                  input logic [BEAT_W-1:0] cur,
                                                  input logic              first);
      logic              found;
      logic [BEAT_W-1:0] idx;
      begin
        found = 1'b0;
        idx   = '0;
        for (int unsigned k = 0; k < RATIO; k++) begin
          if (!found && mask[k] && (first || (BEAT_W+1)'(k) > (BEAT_W+1)'(cur))) begin
            found = 1'b1;
            idx   = BEAT_W'(k);
          end
        end
        next_beat = {found, idx};
      end
    endfunction

    // ---- slave-side acceptance and legality
    logic [REQ_W-1:0] s_vec;
    logic [sf_albion_pkg::SF_STATUS_W-1:0] leg;
    logic             s_acc;
    logic [RATIO-1:0] mask_new;
    logic [BEAT_W-1:0] first_idx_new;
    // The found flag is unused: legality (be != 0) guarantees a first beat exists.
    /* verilator lint_off UNUSEDSIGNAL */
    logic [BEAT_W:0]   first_tmp;
    /* verilator lint_on UNUSEDSIGNAL */
    assign s_vec = {s_req_op_i, s_req_tag_i, s_req_dom_i, s_req_attr_i,
                    s_req_addr_i, s_req_be_i, s_req_data_i};
    assign leg   = sf_albion_pkg::sf_req_check_bits(s_vec);
    assign s_req_ready_o = (state_q == ST_IDLE);
    assign s_acc         = s_req_valid_i && s_req_ready_o;

    always_comb begin
      for (int unsigned k = 0; k < RATIO; k++) mask_new[k] = |s_req_be_i[k*NB +: NB];
      first_tmp     = next_beat(mask_new, '0, 1'b1);
      first_idx_new = first_tmp[BEAT_W-1:0];
    end

    // ---- master-side request (beat issue_idx of the latched parent)
    logic [sf_albion_pkg::SF_ADDR_W-1:0] beat_addr;
    always_comb begin
      beat_addr     = {p_addr_hi_q, {sf_albion_pkg::SF_LANE_W{1'b0}}}
                      + sf_albion_pkg::SF_ADDR_W'(iss_idx_q) * sf_albion_pkg::SF_ADDR_W'(NB);
      m_req_valid_o = (state_q == ST_BUSY) && iss_act_q;
      m_req_op_o    = p_op_q;
      m_req_tag_o   = sf_albion_pkg::SF_TAG_W'(iss_idx_q);      // narrow tag = beat index (ALP-TAG-01)
      m_req_dom_o   = p_dom_q;
      m_req_attr_o  = p_attr_q;
      m_req_addr_o  = beat_addr;
      m_req_be_o    = NB'(p_be_q >> (iss_idx_q * NB));
      m_req_data_o  = NARROW_W'(p_data_q >> (iss_idx_q * NARROW_W));
    end

    logic m_req_fire;
    logic m_rsp_fire;
    assign m_req_fire    = m_req_valid_o && m_req_ready_i;
    assign m_rsp_ready_o = (state_q == ST_BUSY) && (outst_q != '0);
    assign m_rsp_fire    = m_rsp_valid_i && m_rsp_ready_o;

    // ---- response merge
    logic [WIDE_W-1:0]  shift_mask;
    logic [BEAT_W:0]    next_col;
    logic [BEAT_W:0]    next_iss;
    logic               beat_bad;
    logic [sf_albion_pkg::SF_RSP_W-1:0]    beat_rsp;        // the beat response as a full-width ALP response
    logic [sf_albion_pkg::SF_STATUS_W-1:0] merged_st;
    logic               merged_corr;
    logic [WIDE_W-1:0]  merged_data;
    logic               last_beat;
    logic               p_is_write;
    logic [sf_albion_pkg::SF_STATUS_W-1:0] fin_st;
    logic [WIDE_W-1:0]  fin_data;

    always_comb begin
      p_is_write    = (p_op_q == sf_albion_pkg::SF_OP_WRITE);
      beat_rsp      = {m_rsp_tag_i, m_rsp_status_i, m_rsp_meta_i,
                       {(WIDE_W-NARROW_W){1'b0}}, m_rsp_data_i};
      beat_bad      = (m_rsp_tag_i != sf_albion_pkg::SF_TAG_W'(col_idx_q)) ||
                      (m_rsp_meta_i[sf_albion_pkg::SF_CMETA_IS_WRITE_BIT] != p_is_write) ||
                      !sf_albion_pkg::sf_rsp_wellformed_bits(beat_rsp);
      // PROTOCOL_ERR wins (and, once accumulated, stays: acc_st_q is then not OKAY);
      // otherwise the first non-OKAY status is kept.
      merged_st     = acc_st_q;
      if (beat_bad) begin
        merged_st = sf_albion_pkg::SF_ST_PROTOCOL_ERR;
      end else if (acc_st_q == sf_albion_pkg::SF_ST_OKAY && m_rsp_status_i != sf_albion_pkg::SF_ST_OKAY) begin
        merged_st = m_rsp_status_i;
      end
      merged_corr = acc_corr_q || (!beat_bad && m_rsp_meta_i[sf_albion_pkg::SF_CMETA_CORRECTED_BIT]);
      shift_mask  = {{(WIDE_W-NARROW_W){1'b0}}, {NARROW_W{1'b1}}} << (col_idx_q * NARROW_W);
      merged_data = (rd_data_q & ~shift_mask) |
                    ((WIDE_W'(m_rsp_data_i) << (col_idx_q * NARROW_W)) & shift_mask);
      next_col    = next_beat(mask_q, col_idx_q, 1'b0);
      next_iss    = next_beat(mask_q, iss_idx_q, 1'b0);
      last_beat   = !next_col[BEAT_W];
      fin_st   = merged_st;
      // A conforming target returns zero in lanes that were not enabled (ALP-RSP-07) and
      // skipped beats leave their lanes zero, so the merged data needs no further masking.
      fin_data = (merged_st == sf_albion_pkg::SF_ST_OKAY && !p_is_write) ? merged_data : '0;
    end

    // ---- next state
    always_comb begin
      state_d    = state_q;
      iss_idx_d  = iss_idx_q;
      iss_act_d  = iss_act_q;
      col_idx_d  = col_idx_q;
      outst_d    = outst_q;
      acc_st_d   = acc_st_q;
      acc_corr_d = acc_corr_q;
      rd_data_d  = rd_data_q;
      case (state_q)
        ST_IDLE: begin
          if (s_acc) begin
            if (leg != sf_albion_pkg::SF_ST_OKAY) begin
              state_d = ST_RESP;
            end else begin
              state_d    = ST_BUSY;
              iss_idx_d  = first_idx_new;
              iss_act_d  = 1'b1;
              col_idx_d  = first_idx_new;
              outst_d    = '0;
              acc_st_d   = sf_albion_pkg::SF_ST_OKAY;
              acc_corr_d = 1'b0;
              rd_data_d  = '0;
            end
          end
        end
        ST_BUSY: begin
          if (m_req_fire) begin
            if (next_iss[BEAT_W]) iss_idx_d = next_iss[BEAT_W-1:0];
            else                  iss_act_d = 1'b0;
          end
          if (m_req_fire && !m_rsp_fire)      outst_d = outst_q + 1'b1;
          else if (!m_req_fire && m_rsp_fire) outst_d = outst_q - 1'b1;
          if (m_rsp_fire) begin
            acc_st_d   = merged_st;
            acc_corr_d = merged_corr;
            rd_data_d  = merged_data;
            if (last_beat) state_d = ST_RESP;
            else           col_idx_d = next_col[BEAT_W-1:0];
          end
        end
        default: begin   // ST_RESP
          if (s_rsp_ready_i) state_d = ST_IDLE;
        end
      endcase
    end

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        state_q    <= ST_IDLE;
        iss_act_q  <= 1'b0;
        outst_q    <= '0;
      end else begin
        state_q    <= state_d;
        iss_act_q  <= iss_act_d;
        outst_q    <= outst_d;
      end
    end

    always_ff @(posedge clk_i) begin
      iss_idx_q  <= iss_idx_d;
      col_idx_q  <= col_idx_d;
      acc_st_q   <= acc_st_d;
      acc_corr_q <= acc_corr_d;
      rd_data_q  <= rd_data_d;
      if (s_acc) begin
        p_op_q   <= s_req_op_i;
        p_tag_q  <= s_req_tag_i;
        p_dom_q  <= s_req_dom_i;
        p_attr_q <= s_req_attr_i;
        p_addr_hi_q <= s_req_addr_i[sf_albion_pkg::SF_ADDR_W-1:sf_albion_pkg::SF_LANE_W];
        p_be_q   <= s_req_be_i;
        p_data_q <= s_req_data_i;
        mask_q   <= mask_new;
      end
      // response register: local error response, or the merged parent response
      if (s_acc && leg != sf_albion_pkg::SF_ST_OKAY) begin
        rsp_tag_q  <= s_req_tag_i;
        rsp_st_q   <= leg;
        rsp_meta_q <= {4'b0000, 1'b0, 1'b0, 1'b1, (s_req_op_i == sf_albion_pkg::SF_OP_WRITE)};
        rsp_data_q <= '0;
      end else if (state_q == ST_BUSY && m_rsp_fire && last_beat) begin
        rsp_tag_q  <= p_tag_q;
        rsp_st_q   <= fin_st;
        rsp_meta_q <= {4'b0000, merged_corr, (fin_st == sf_albion_pkg::SF_ST_ECC_UNCORR), 1'b1, p_is_write};
        rsp_data_q <= fin_data;
      end
    end

    assign s_rsp_valid_o  = (state_q == ST_RESP);
    assign s_rsp_tag_o    = rsp_tag_q;
    assign s_rsp_status_o = rsp_st_q;
    assign s_rsp_meta_o   = rsp_meta_q;
    assign s_rsp_data_o   = rsp_data_q;

  // ===========================================================================
  //  UPSIZE: narrow slave side -> wide master side
  // ===========================================================================
  end else begin : gen_up
    localparam int unsigned ORD_W = 1 + sf_albion_pkg::SF_STATUS_W + sf_albion_pkg::SF_TAG_W + 1
                                  + sf_albion_pkg::SF_LANE_W;
    localparam int unsigned RSP_W = sf_albion_pkg::SF_TAG_W + sf_albion_pkg::SF_STATUS_W
                                  + sf_albion_pkg::SF_CMETA_W + NARROW_W;

    // ---- legality of the narrow request, using the package rules.  The check
    //      vector carries the narrow alignment and byte-enable condition in the
    //      fields the package function inspects.
    logic [REQ_W-1:0] chk_vec;
    logic [sf_albion_pkg::SF_STATUS_W-1:0] leg;
    logic             misaligned;
    logic             local_err;
    logic [OFF_W-1:0] off;
    logic             s_fire;
    logic             ord_in_ready;
    logic             skid_in_ready;

    always_comb begin
      misaligned = (NLANE_W > 0) && (s_req_addr_i[(NLANE_W > 0 ? NLANE_W : 1)-1:0] != '0);
      chk_vec    = {s_req_op_i, s_req_tag_i, s_req_dom_i, s_req_attr_i,
                    s_req_addr_i[sf_albion_pkg::SF_ADDR_W-1:sf_albion_pkg::SF_LANE_W],
                    misaligned ? 4'h1 : 4'h0,
                    {{(WIDE_B-1){1'b0}}, |s_req_be_i},
                    {WIDE_W{1'b0}}};
      leg        = sf_albion_pkg::sf_req_check_bits(chk_vec);
      local_err  = (leg != sf_albion_pkg::SF_ST_OKAY);
      off        = s_req_addr_i[sf_albion_pkg::SF_LANE_W-1:NLANE_W];
    end

    assign s_req_ready_o = ord_in_ready && skid_in_ready;
    assign s_fire        = s_req_valid_i && s_req_ready_o;

    // ---- wide request, registered in a skid buffer
    logic [WIDE_B-1:0]  wide_be;
    logic [WIDE_W-1:0]  wide_data;
    logic [REQ_W-1:0]   wide_req;
    logic [REQ_W-1:0]   skid_out;
    logic               skid_out_valid;
    always_comb begin
      wide_be   = WIDE_B'(s_req_be_i)   << (off * NB);
      wide_data = WIDE_W'(s_req_data_i) << (off * NARROW_W);
      wide_req  = {s_req_op_i, s_req_tag_i, s_req_dom_i, s_req_attr_i,
                   s_req_addr_i[sf_albion_pkg::SF_ADDR_W-1:sf_albion_pkg::SF_LANE_W],
                   {sf_albion_pkg::SF_LANE_W{1'b0}}, wide_be, wide_data};
    end

    sf_albion_skid #(.WIDTH(REQ_W)) u_req_skid (
      .clk_i, .rst_ni,
      .in_valid_i (s_fire && !local_err),
      .in_ready_o (skid_in_ready),
      .in_data_i  (wide_req),
      .out_valid_o(skid_out_valid),
      .out_ready_i(m_req_ready_i),
      .out_data_o (skid_out)
    );
    assign m_req_valid_o = skid_out_valid;
    assign m_req_op_o    = skid_out[sf_albion_pkg::SF_REQ_OP_LSB   +: sf_albion_pkg::SF_OP_W];
    assign m_req_tag_o   = skid_out[sf_albion_pkg::SF_REQ_TAG_LSB  +: sf_albion_pkg::SF_TAG_W];
    assign m_req_dom_o   = skid_out[sf_albion_pkg::SF_REQ_DOM_LSB  +: sf_albion_pkg::SF_DOM_W];
    assign m_req_attr_o  = skid_out[sf_albion_pkg::SF_REQ_ATTR_LSB +: sf_albion_pkg::SF_ATTR_W];
    assign m_req_addr_o  = skid_out[sf_albion_pkg::SF_REQ_ADDR_LSB +: sf_albion_pkg::SF_ADDR_W];
    assign m_req_be_o    = skid_out[sf_albion_pkg::SF_REQ_BE_LSB   +: sf_albion_pkg::SF_BE_W];
    assign m_req_data_o  = skid_out[sf_albion_pkg::SF_REQ_DATA_LSB +: sf_albion_pkg::SF_DATA_W];

    // ---- order queue: one entry per accepted request, popped when its
    //      response is handed to the response skid buffer
    logic [ORD_W-1:0] ord_in;
    logic [ORD_W-1:0] ord_out;
    logic             ord_out_valid;
    logic             ord_pop;
    assign ord_in = {local_err, leg, s_req_tag_i, (s_req_op_i == sf_albion_pkg::SF_OP_WRITE),
                     {{(sf_albion_pkg::SF_LANE_W-OFF_W){1'b0}}, off}};

    // count_o / full_o / empty_o are intentionally unused.
    /* verilator lint_off PINCONNECTEMPTY */
    sf_albion_fifo #(.WIDTH(ORD_W), .DEPTH(MAX_OUT)) u_order (
      .clk_i, .rst_ni, .flush_i(1'b0),
      .in_valid_i (s_fire),
      .in_ready_o (ord_in_ready),
      .in_data_i  (ord_in),
      .out_valid_o(ord_out_valid),
      .out_ready_i(ord_pop),
      .out_data_o (ord_out),
      .count_o    (),
      .full_o     (),
      .empty_o    ()
    );
    /* verilator lint_on PINCONNECTEMPTY */

    logic                                  h_local;
    logic [sf_albion_pkg::SF_STATUS_W-1:0] h_status;
    logic [sf_albion_pkg::SF_TAG_W-1:0]    h_tag;
    logic                                  h_is_write;
    logic [OFF_W-1:0]                      h_off;
    assign h_local    = ord_out[ORD_W-1];
    assign h_status   = ord_out[ORD_W-2 -: sf_albion_pkg::SF_STATUS_W];
    assign h_tag      = ord_out[sf_albion_pkg::SF_LANE_W + 1 +: sf_albion_pkg::SF_TAG_W];
    assign h_is_write = ord_out[sf_albion_pkg::SF_LANE_W];
    assign h_off      = ord_out[OFF_W-1:0];

    // ---- response construction
    logic                                  rsp_skid_in_valid;
    logic                                  rsp_skid_in_ready;
    logic [RSP_W-1:0]                      rsp_in;
    logic                                  mismatch;
    logic [sf_albion_pkg::SF_STATUS_W-1:0] f_status;
    logic [sf_albion_pkg::SF_CMETA_W-1:0]  f_meta;
    logic [NARROW_W-1:0]                   f_data;
    logic [NARROW_W-1:0]                   m_shifted;

    always_comb begin
      mismatch  = (m_rsp_tag_i != h_tag) ||
                  (m_rsp_meta_i[sf_albion_pkg::SF_CMETA_IS_WRITE_BIT] != h_is_write) ||
                  !sf_albion_pkg::sf_rsp_wellformed_bits({m_rsp_tag_i, m_rsp_status_i, m_rsp_meta_i, m_rsp_data_i});
      m_shifted = NARROW_W'(m_rsp_data_i >> (h_off * NARROW_W));
      if (h_local) begin
        f_status = h_status;
        f_meta   = {4'b0000, 1'b0, (h_status == sf_albion_pkg::SF_ST_ECC_UNCORR), 1'b1, h_is_write};
        f_data   = '0;
      end else if (mismatch) begin
        f_status = sf_albion_pkg::SF_ST_PROTOCOL_ERR;
        f_meta   = {4'b0000, 1'b0, 1'b0, 1'b1, h_is_write};
        f_data   = '0;
      end else begin
        f_status = m_rsp_status_i;          // conforming: well-formed, so data is zero unless OKAY read
        f_meta   = m_rsp_meta_i;
        f_data   = m_shifted;
      end
      rsp_in = {h_tag, f_status, f_meta, f_data};
    end

    assign rsp_skid_in_valid = ord_out_valid && (h_local || m_rsp_valid_i);
    assign m_rsp_ready_o     = ord_out_valid && !h_local && rsp_skid_in_ready;
    assign ord_pop           = rsp_skid_in_valid && rsp_skid_in_ready;

    logic [RSP_W-1:0] rsp_out;
    sf_albion_skid #(.WIDTH(RSP_W)) u_rsp_skid (
      .clk_i, .rst_ni,
      .in_valid_i (rsp_skid_in_valid),
      .in_ready_o (rsp_skid_in_ready),
      .in_data_i  (rsp_in),
      .out_valid_o(s_rsp_valid_o),
      .out_ready_i(s_rsp_ready_i),
      .out_data_o (rsp_out)
    );
    assign s_rsp_tag_o    = rsp_out[RSP_W-1 -: sf_albion_pkg::SF_TAG_W];
    assign s_rsp_status_o = rsp_out[NARROW_W + sf_albion_pkg::SF_CMETA_W +: sf_albion_pkg::SF_STATUS_W];
    assign s_rsp_meta_o   = rsp_out[NARROW_W +: sf_albion_pkg::SF_CMETA_W];
    assign s_rsp_data_o   = rsp_out[NARROW_W-1:0];
  end
endmodule

`default_nettype wire
