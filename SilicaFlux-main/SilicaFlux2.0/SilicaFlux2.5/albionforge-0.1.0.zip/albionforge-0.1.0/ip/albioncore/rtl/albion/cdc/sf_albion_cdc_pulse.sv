// =============================================================================
//  sf_albion_cdc_pulse.sv  --  event (pulse) crossing with acknowledge
// -----------------------------------------------------------------------------
//  OPTIONAL module.  Sends one event per accepted source request from the src
//  domain to the dst domain, with a full request / acknowledge round trip so
//  that events can never be lost or merged, whatever the clock ratio.
//
//    src domain:  src_valid_i / src_ready_o handshake.  An event is accepted when
//                 src_valid_i && src_ready_o; src_ready_o is low while the
//                 previous event is still in flight.
//    dst domain:  pulse_o is high for exactly ONE dst_clk_i cycle per event.
//
//  Mechanism: a toggle flop in the source domain flips per event; the toggle is
//  carried through sf_albion_cdc_bit_sync (one bit: safe) to the dst domain where
//  an edge detector produces the pulse; the dst-side toggle copy is carried back
//  through a second sf_albion_cdc_bit_sync as the acknowledge.
//
//  Throughput: one event per (2 * SYNC_STAGES + 2) clock periods of the slower
//  domain, approximately.  Use for rare control events, not data.
//  Reset: each domain has its own active-low reset; both must be asserted
//  together (overlapping) and released synchronously in their own domain.
// =============================================================================
`default_nettype none

module sf_albion_cdc_pulse #(
  parameter int unsigned SYNC_STAGES = 2
) (
  input  wire logic src_clk_i,
  input  wire logic src_rst_ni,
  input  wire logic src_valid_i,
  output logic      src_ready_o,
  input  wire logic dst_clk_i,
  input  wire logic dst_rst_ni,
  output logic      pulse_o
);
  logic req_toggle_q;       // source domain
  logic req_sync;           // dst domain: synchronised request toggle
  logic dst_seen_q;         // dst domain: last toggle value acted on
  logic ack_sync;           // src domain: synchronised acknowledge

  // The source may send again once the acknowledge has caught up with the request.
  assign src_ready_o = (req_toggle_q == ack_sync);

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni)                         req_toggle_q <= 1'b0;
    else if (src_valid_i && src_ready_o)     req_toggle_q <= ~req_toggle_q;
  end

  sf_albion_cdc_bit_sync #(.STAGES(SYNC_STAGES)) u_req_sync (
    .dst_clk_i, .dst_rst_ni, .src_i(req_toggle_q), .dst_o(req_sync));

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) dst_seen_q <= 1'b0;
    else             dst_seen_q <= req_sync;
  end

  assign pulse_o = (req_sync != dst_seen_q);

  sf_albion_cdc_bit_sync #(.STAGES(SYNC_STAGES)) u_ack_sync (
    .dst_clk_i(src_clk_i), .dst_rst_ni(src_rst_ni), .src_i(dst_seen_q), .dst_o(ack_sync));
endmodule

`default_nettype wire
