// =============================================================================
//  sf_albion_async_fifo.sv  --  Gray-pointer asynchronous FIFO
// -----------------------------------------------------------------------------
//  OPTIONAL module.  The multibit data path between two unrelated clock
//  domains.  Data never crosses through synchronisers; only the write and read
//  POINTERS do, and they are Gray coded so that at most one pointer bit changes
//  per increment -- each bit goes through its own sf_albion_cdc_bit_sync, which
//  is therefore safe.  (This is the only multibit crossing the library provides.)
//
//  Parameters
//    WIDTH       payload width (>= 1)
//    ADDR_W      log2(depth); depth = 2**ADDR_W, ADDR_W >= 2
//    SYNC_STAGES synchroniser depth for the pointers (>= 2)
//
//  Interface: valid/ready on both sides.  wr_ready_o is the (registered, pessimistic)
//  "not full" flag in the write domain; rd_valid_o is the "not empty" flag in the
//  read domain; rd_data_o shows the head word while rd_valid_o is high.
//
//  Latency: a word written at write edge t becomes visible after the write
//  pointer has crossed (SYNC_STAGES read edges) -- the FIFO never shows data
//  early and never loses or duplicates data; flags are conservative.
//
//  Reset: wr_rst_ni and rd_rst_ni are separate (one per clock domain, each
//  released synchronously, see sf_albion_reset_sync) but they MUST OVERLAP: both
//  must be low at the same time, and neither side may transfer while the other is
//  in reset.  Resetting ONE side only is outside the contract and is not detected
//  (for example a read-side-only reset re-delivers the words still in the array).
//
//  Back-end constraints (not checked here, see docs/albion/RESET_CLOCK_CONTRACT.md):
//  the ADDR_W + 1 Gray bits of each pointer are a BUS: constrain them with a bus-skew
//  / max-delay constraint, not a false path.  rd_data_o is read combinationally from
//  the write-clock storage array and needs a max-delay constraint as well.
// =============================================================================
`default_nettype none

module sf_albion_async_fifo #(
  parameter int unsigned WIDTH       = 8,
  parameter int unsigned ADDR_W      = 3,
  parameter int unsigned SYNC_STAGES = 2
) (
  // write domain
  input  wire logic             wr_clk_i,
  input  wire logic             wr_rst_ni,
  input  wire logic             wr_valid_i,
  output logic                  wr_ready_o,
  input  wire logic [WIDTH-1:0] wr_data_i,
  // read domain
  input  wire logic             rd_clk_i,
  input  wire logic             rd_rst_ni,
  output logic                  rd_valid_o,
  input  wire logic             rd_ready_i,
  output logic [WIDTH-1:0]      rd_data_o
);
  localparam int unsigned DEPTH = 2 ** ADDR_W;
  if (WIDTH < 1 || ADDR_W < 2 || ADDR_W > 16) begin : gen_param_check
    $error("sf_albion_async_fifo: WIDTH >= 1 and 2 <= ADDR_W <= 16 required");
  end

  logic [WIDTH-1:0] mem_q [DEPTH];

  // ---------------------------------------------------------------- write domain
  logic [ADDR_W:0]   wbin_q, wbin_d;
  logic [ADDR_W:0]   wgray_q, wgray_d;
  logic [ADDR_W:0]   rgray_in_wr;          // read pointer, synchronised into the write domain
  logic              wfull_q;
  logic              wfull_d;
  logic              wr_fire;

  assign wr_fire    = wr_valid_i && wr_ready_o;
  assign wbin_d     = wbin_q + (ADDR_W+1)'(wr_fire);
  assign wgray_d    = (wbin_d >> 1) ^ wbin_d;
  // full when the next write Gray pointer equals the synchronised read Gray pointer
  // with the two MSBs inverted
  assign wfull_d    = (wgray_d == {~rgray_in_wr[ADDR_W:ADDR_W-1], rgray_in_wr[ADDR_W-2:0]});
  assign wr_ready_o = !wfull_q;

  always_ff @(posedge wr_clk_i or negedge wr_rst_ni) begin
    if (!wr_rst_ni) begin
      wbin_q  <= '0;
      wgray_q <= '0;
      wfull_q <= 1'b0;
    end else begin
      wbin_q  <= wbin_d;
      wgray_q <= wgray_d;
      wfull_q <= wfull_d;
    end
  end

  always_ff @(posedge wr_clk_i) begin
    if (wr_fire) mem_q[wbin_q[ADDR_W-1:0]] <= wr_data_i;
  end

  // ---------------------------------------------------------------- read domain
  logic [ADDR_W:0]   rbin_q, rbin_d;
  logic [ADDR_W:0]   rgray_q, rgray_d;
  logic [ADDR_W:0]   wgray_in_rd;          // write pointer, synchronised into the read domain
  logic              rempty_q;
  logic              rempty_d;
  logic              rd_fire;

  assign rd_fire    = rd_valid_o && rd_ready_i;
  assign rbin_d     = rbin_q + (ADDR_W+1)'(rd_fire);
  assign rgray_d    = (rbin_d >> 1) ^ rbin_d;
  assign rempty_d   = (rgray_d == wgray_in_rd);
  assign rd_valid_o = !rempty_q;
  assign rd_data_o  = mem_q[rbin_q[ADDR_W-1:0]];

  always_ff @(posedge rd_clk_i or negedge rd_rst_ni) begin
    if (!rd_rst_ni) begin
      rbin_q   <= '0;
      rgray_q  <= '0;
      rempty_q <= 1'b1;
    end else begin
      rbin_q   <= rbin_d;
      rgray_q  <= rgray_d;
      rempty_q <= rempty_d;
    end
  end

  // ---------------------------------------------------------------- pointer crossings
  for (genvar i = 0; i <= ADDR_W; i++) begin : gen_ptr_sync
    sf_albion_cdc_bit_sync #(.STAGES(SYNC_STAGES)) u_w2r (
      .dst_clk_i(rd_clk_i), .dst_rst_ni(rd_rst_ni), .src_i(wgray_q[i]), .dst_o(wgray_in_rd[i]));
    sf_albion_cdc_bit_sync #(.STAGES(SYNC_STAGES)) u_r2w (
      .dst_clk_i(wr_clk_i), .dst_rst_ni(wr_rst_ni), .src_i(rgray_q[i]), .dst_o(rgray_in_wr[i]));
  end
endmodule

`default_nettype wire
