// =============================================================================
//  sf_albion_cdc_bit_sync.sv  --  single-bit clock-domain-crossing synchroniser
// -----------------------------------------------------------------------------
//  OPTIONAL module (not used by the single-clock baseline).
//
//  Passes ONE bit from any other clock domain into dst_clk_i through STAGES
//  flip-flops in series.  Rules of use:
//    * the source signal must come directly from a flip-flop in its own domain
//      (no combinational logic before the first synchroniser flop) and must be
//      held long enough to be sampled (>= 1 dst clock period + setup);
//    * the signal must be ONE bit.  NEVER connect several of these to the bits
//      of a bus: bits can be captured on different dst edges.  A bus needs the
//      Gray-coded sf_albion_async_fifo (or a handshake, sf_albion_cdc_pulse).
//    * the first flop is the one that may go metastable.  Constrain the path into
//      it as an asynchronous path in the back-end flow (false path or max delay),
//      and keep the flops together.  Simulation does not model metastability.
//      This advice is for a SINGLE bit.  The Gray pointers of sf_albion_async_fifo
//      form a bus and need the bus constraints of docs/albion/RESET_CLOCK_CONTRACT.md.
//
//  Latency: STAGES dst_clk_i edges.  Reset: asynchronous, active low, to RESET_VALUE
//  (release this reset with sf_albion_reset_sync in the dst domain).
// =============================================================================
`default_nettype none

module sf_albion_cdc_bit_sync #(
  parameter int unsigned STAGES      = 2,
  parameter bit          RESET_VALUE = 1'b0
) (
  input  wire logic dst_clk_i,
  input  wire logic dst_rst_ni,
  input  wire logic src_i,
  output logic      dst_o
);
  if (STAGES < 2) begin : gen_param_check
    $error("sf_albion_cdc_bit_sync: STAGES must be >= 2");
  end

  logic [STAGES-1:0] sync_q;

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) sync_q <= {STAGES{RESET_VALUE}};
    else             sync_q <= {sync_q[STAGES-2:0], src_i};
  end

  assign dst_o = sync_q[STAGES-1];
endmodule

`default_nettype wire
