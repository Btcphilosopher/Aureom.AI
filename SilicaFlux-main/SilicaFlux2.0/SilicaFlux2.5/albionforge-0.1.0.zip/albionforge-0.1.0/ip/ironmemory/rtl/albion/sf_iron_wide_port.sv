// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_wide_port.sv : wide accelerator interface built from banking
//
// Presents a LANES x DW-bit port (default 4 x 64 = 256 bits) to an
// accelerator (ComputeWorks vector/tensor engines) and splits each request
// across LANES ordinary IronMemory master ports. With word interleaving and
// a request address aligned to LANES*DW/8, lane i always lands in bank i,
// so the lanes never conflict with each other and a full-width access
// completes every cycle when the banks are otherwise idle.
//
// Integration: give the lane ports the accelerator's ownership domain in
// sf_iron_memory's PORT_DOMAIN_MAP (e.g. 24'o33343210 maps ports 3,5,6,7 to
// ComputeWorks). Misaligned addresses still work (lanes then share banks;
// correctness is unchanged, only throughput drops).
//
// Semantics: each lane is an independent memory access. A wide write is
// NOT atomic across lanes: if one lane is refused (e.g. permission or
// bounds), the others still complete. The wide response reports the error
// of the lowest-numbered failing lane. Write lanes with an all-zero strobe
// are skipped; a wide write with no active lane returns RSP_ALIGN.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_wide_port #(
  parameter int LANES = 4,
  parameter int DW    = 64,
  parameter int AW    = 32,
  parameter int QD    = 8,          // in-flight wide requests (>= lane MAX_OUT)
  parameter int NB    = DW / 8,
  parameter int QW    = sf_iron_pkg::clog2_min1(QD)
) (
  input  logic                    clk,
  input  logic                    rst_n,
  // ---- wide port ----
  input  logic                    w_req_valid,
  output logic                    w_req_ready,
  input  logic [AW-1:0]           w_req_addr,
  input  logic                    w_req_we,
  input  logic [LANES*DW-1:0]     w_req_wdata,
  input  logic [LANES*NB-1:0]     w_req_wstrb,
  output logic                    w_rsp_valid,
  input  logic                    w_rsp_ready,
  output logic [LANES*DW-1:0]     w_rsp_rdata,
  output logic [2:0]              w_rsp_err,
  output logic                    w_rsp_ecc_corr,
  // ---- lane master ports into sf_iron_memory ----
  output logic [LANES-1:0]        l_req_valid,
  input  logic [LANES-1:0]        l_req_ready,
  output logic [LANES*AW-1:0]     l_req_addr,
  output logic [LANES*3-1:0]      l_req_size,
  output logic [LANES-1:0]        l_req_we,
  output logic [LANES*DW-1:0]     l_req_wdata,
  output logic [LANES*NB-1:0]     l_req_wstrb,
  input  logic [LANES-1:0]        l_rsp_valid,
  output logic [LANES-1:0]        l_rsp_ready,
  input  logic [LANES*DW-1:0]     l_rsp_rdata,
  input  logic [LANES*3-1:0]      l_rsp_err,
  input  logic [LANES-1:0]        l_rsp_ecc_corr
);
  `include "sf_iron_defs.svh"
  initial if (is_pow2(QD) == 0) $fatal(1, "wide_port: QD must be a power of two");

  logic [LANES-1:0] active, sent, done;
  logic [LANES-1:0] fifo [QD];
  logic [QW-1:0]    head, tail;
  logic [QW:0]      cnt;
  logic             fifo_full, w_fire, r_fire;
  logic [LANES-1:0] hm;

  assign fifo_full = (cnt == (QW+1)'(QD));

  always_comb begin
    for (int i = 0; i < LANES; i++) begin
      active[i] = !w_req_we || (w_req_wstrb[i*NB +: NB] != '0);
      l_req_valid[i] = w_req_valid && active[i] && !sent[i] && !fifo_full;
      l_req_addr[i*AW +: AW]  = w_req_addr + AW'(i * NB);
      l_req_size[i*3 +: 3]    = 3'($clog2(NB));
      l_req_we[i]             = w_req_we;
      l_req_wdata[i*DW +: DW] = w_req_wdata[i*DW +: DW];
      l_req_wstrb[i*NB +: NB] = w_req_wstrb[i*NB +: NB];
      done[i] = sent[i] || !active[i] || (l_req_valid[i] && l_req_ready[i]);
    end
    w_req_ready = w_req_valid && !fifo_full && (&done);
    w_fire      = w_req_ready;
  end

  // response join
  assign hm          = fifo[head];
  assign w_rsp_valid = (cnt != '0) && ((l_rsp_valid | ~hm) == '1);
  assign r_fire      = w_rsp_valid && w_rsp_ready;
  always_comb begin
    w_rsp_err      = (hm == '0) ? RSP_ALIGN : RSP_OK;
    w_rsp_ecc_corr = 1'b0;
    for (int i = LANES - 1; i >= 0; i--) begin
      w_rsp_rdata[i*DW +: DW] = hm[i] ? l_rsp_rdata[i*DW +: DW] : '0;
      if (hm[i] && l_rsp_err[i*3 +: 3] != RSP_OK) w_rsp_err = l_rsp_err[i*3 +: 3];
      if (hm[i] && l_rsp_ecc_corr[i]) w_rsp_ecc_corr = 1'b1;
    end
    l_rsp_ready = r_fire ? hm : '0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sent <= '0; head <= '0; tail <= '0; cnt <= '0;
      for (int q = 0; q < QD; q++) fifo[q] <= '0;
    end else begin
      if (w_fire) begin
        sent       <= '0;
        fifo[tail] <= active;
        tail       <= tail + 1'b1;
      end else begin
        for (int i = 0; i < LANES; i++) if (l_req_valid[i] && l_req_ready[i]) sent[i] <= 1'b1;
      end
      if (r_fire) head <= head + 1'b1;
      cnt <= cnt + (QW+1)'(w_fire) - (QW+1)'(r_fire);
    end
  end
endmodule
