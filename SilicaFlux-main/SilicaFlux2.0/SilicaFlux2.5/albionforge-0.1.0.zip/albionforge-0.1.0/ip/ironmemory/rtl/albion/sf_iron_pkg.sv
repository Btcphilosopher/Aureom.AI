// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_pkg.sv : shared constants, encodings and constant functions
// Aureom.AI / SilicaFlux Albion
// =============================================================================
`ifndef SF_IRON_PKG_SV
`define SF_IRON_PKG_SV

package sf_iron_pkg;

  // ---------------------------------------------------------------------------
  // Master response codes (m_rsp_err)
  // ---------------------------------------------------------------------------
  localparam logic [2:0] RSP_OK     = 3'd0;  // success (check m_rsp_ecc_corr)
  localparam logic [2:0] RSP_DECODE = 3'd1;  // address not in any mapped window
  localparam logic [2:0] RSP_ALIGN  = 3'd2;  // misaligned / bad size / empty strobe
  localparam logic [2:0] RSP_PERM   = 3'd3;  // ownership or permission violation
  localparam logic [2:0] RSP_ECC_UE = 3'd4;  // uncorrectable ECC error (data poisoned)
  localparam logic [2:0] RSP_EXT    = 3'd5;  // external memory controller error
  localparam logic [2:0] RSP_BOUNDS = 3'd6;  // access straddles a buffer boundary

  // ---------------------------------------------------------------------------
  // Ownership domains (one per SilicaFlux Albion master class)
  // ---------------------------------------------------------------------------
  localparam int NUM_DOMAINS = 5;
  localparam logic [2:0] DOM_KEYSTONE  = 3'd0;  // ControlCore (supervisor)
  localparam logic [2:0] DOM_BRIDGE    = 3'd1;  // BridgeEngine (DMA)
  localparam logic [2:0] DOM_PACKET    = 3'd2;  // PacketForge
  localparam logic [2:0] DOM_COMPUTE   = 3'd3;  // ComputeWorks (vector/tensor)
  localparam logic [2:0] DOM_VFOUNDRY  = 3'd4;  // VirtualFoundry (virtual I/O)

  // ---------------------------------------------------------------------------
  // Address regions
  // ---------------------------------------------------------------------------
  localparam logic [1:0] REGION_NONE = 2'd0;
  localparam logic [1:0] REGION_SRAM = 2'd1;
  localparam logic [1:0] REGION_EXT  = 2'd2;

  // ---------------------------------------------------------------------------
  // Buffer types
  // ---------------------------------------------------------------------------
  localparam logic [2:0] BT_DMA_STAGING    = 3'd0;
  localparam logic [2:0] BT_PACKET         = 3'd1;
  localparam logic [2:0] BT_VIRTIO_DESC    = 3'd2;
  localparam logic [2:0] BT_TENSOR_OPERAND = 3'd3;
  localparam logic [2:0] BT_COMPUTE_RESULT = 3'd4;
  localparam logic [2:0] BT_CTRL_META      = 3'd5;
  localparam int         BT_MAX            = 5;

  // ---------------------------------------------------------------------------
  // Buffer-manager operations and status codes
  // ---------------------------------------------------------------------------
  localparam logic [2:0] BM_ALLOC     = 3'd0;
  localparam logic [2:0] BM_ALLOC_AT  = 3'd1;
  localparam logic [2:0] BM_FREE      = 3'd2;
  localparam logic [2:0] BM_TRANSFER  = 3'd3;
  localparam logic [2:0] BM_QUERY     = 3'd4;
  localparam logic [2:0] BM_CLEAR_ERR = 3'd5;

  localparam logic [3:0] BMS_OK       = 4'd0;
  localparam logic [3:0] BMS_NODESC   = 4'd1;  // descriptor table exhausted
  localparam logic [3:0] BMS_NOSPACE  = 4'd2;  // no contiguous free granule run
  localparam logic [3:0] BMS_BADLEN   = 4'd3;  // zero length or larger than pool
  localparam logic [3:0] BMS_BADID    = 4'd4;  // id out of range or not in use
  localparam logic [3:0] BMS_NOTOWNER = 4'd5;  // requester may not manage buffer
  localparam logic [3:0] BMS_ALIGN    = 4'd6;  // ALLOC_AT start not granule aligned / outside pool
  localparam logic [3:0] BMS_OVERLAP  = 4'd7;  // ALLOC_AT range overlaps a live buffer
  localparam logic [3:0] BMS_BADARG   = 4'd8;  // bad type / owner / opcode

  // Buffer sticky error-status bits
  localparam int BERR_RD_PERM = 0;
  localparam int BERR_WR_PERM = 1;
  localparam int BERR_BOUNDS  = 2;
  localparam int BERR_ECC_CE  = 3;
  localparam int BERR_ECC_UE  = 4;

  // ---------------------------------------------------------------------------
  // Constant functions
  // ---------------------------------------------------------------------------
  // ceil(log2(v)) with a minimum of 1 (safe for signal widths)
  function automatic int clog2_min1(input int v);
    int r;
    r = $clog2(v);
    if (r < 1) clog2_min1 = 1;
    else       clog2_min1 = r;
  endfunction

  // number of Hamming check bits r for DW data bits: smallest r with
  // 2^r >= DW + r + 1. The SECDED codeword adds one overall-parity bit.
  function automatic int secded_r(input int dw);
    int r;
    r = 1;
    while ((1 << r) < (dw + r + 1)) r = r + 1;
    secded_r = r;
  endfunction

  function automatic int is_pow2(input int v);
    if ((v > 0) && ((v & (v - 1)) == 0)) is_pow2 = 1;
    else                                  is_pow2 = 0;
  endfunction

endpackage

`endif
