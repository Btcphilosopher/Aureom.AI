/* SilicaFlux ControlCore boot ROM link script.  Regions: generated cc_memory.ld.
 * Code and read-only data in BOOTROM; .bss (CRC table, small state) and the
 * stack at the top of DMEM.  No initialised .data (nothing to copy). */
INCLUDE cc_memory.ld
OUTPUT_ARCH("riscv")
ENTRY(_start)

SECTIONS
{
  .text : {
    KEEP(*(.text.start))
    *(.text .text.*)
  } > BOOTROM
  .rodata : {
    *(.srodata .srodata.*) *(.rodata .rodata.*)
    . = ALIGN(4);
  } > BOOTROM
  .data : { *(.sdata .sdata.*) *(.data .data.*) } > BOOTROM
  ASSERT(SIZEOF(.data) == 0, "boot ROM must not have initialised .data")
  .bss (NOLOAD) : {
    . = ALIGN(4);
    __bss_start = .;
    *(.sbss .sbss.*) *(.bss .bss.*) *(COMMON)
    . = ALIGN(4);
    __bss_end = .;
  } > DMEM
  __global_pointer$ = __bss_start + 0x800;
  __stack_top = ORIGIN(DMEM) + LENGTH(DMEM);
  ASSERT(__bss_end <= __stack_top - 0x1000, "boot ROM .bss collides with its 4 KiB stack")
  /DISCARD/ : { *(.comment) *(.riscv.attributes) *(.note*) *(.eh_frame*) }
}
