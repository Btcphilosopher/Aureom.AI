/* SilicaFlux ControlCore firmware link script.  Regions: generated cc_memory.ld.
 * The image is loaded at ORIGIN(IMEM); its first CC_IMAGE_HDR_BYTES hold the
 * header written by scripts/mkimage.py, so code starts after it.
 *   IMEM: .text .rodata, .data load image (LMA)
 *   DMEM: .data (VMA) .bss, heap-free; 4 KiB+ stack at the top.  Execute-never. */
INCLUDE cc_memory.ld
OUTPUT_ARCH("riscv")
ENTRY(_start)

SECTIONS
{
  .text ORIGIN(IMEM) + CC_IMAGE_HDR_BYTES : {
    KEEP(*(.text.start))
    *(.text .text.*)
  } > IMEM
  .rodata : {
    *(.srodata .srodata.*) *(.rodata .rodata.*)
    . = ALIGN(4);
  } > IMEM
  .data : {
    . = ALIGN(4);
    __data_start = .;
    *(.sdata .sdata.*) *(.data .data.*)
    . = ALIGN(4);
    __data_end = .;
  } > DMEM AT > IMEM
  __data_lma = LOADADDR(.data);
  __image_end = __data_lma + SIZEOF(.data);
  .bss (NOLOAD) : {
    . = ALIGN(4);
    __bss_start = .;
    *(.sbss .sbss.*) *(.bss .bss.*) *(COMMON)
    . = ALIGN(4);
    __bss_end = .;
  } > DMEM
  __global_pointer$ = __data_start + 0x800;
  __stack_top = ORIGIN(DMEM) + LENGTH(DMEM);
  ASSERT(__bss_end <= __stack_top - 0x1000, "firmware .data/.bss leave less than 4 KiB of stack")
  /DISCARD/ : { *(.comment) *(.riscv.attributes) *(.note*) *(.eh_frame*) }
}
