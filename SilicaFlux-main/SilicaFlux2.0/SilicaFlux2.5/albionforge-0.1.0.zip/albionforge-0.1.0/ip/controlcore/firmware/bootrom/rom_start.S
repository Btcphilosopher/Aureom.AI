/* =============================================================================
 * SilicaFlux ControlCore boot ROM -- reset entry (CC_BOOTROM_BASE = reset vector)
 *
 * 1. mtvec -> rom_trap (any trap in the ROM is reported and parks the CPU).
 * 2. Scrub DMEM: every word is written once BEFORE parity checking is enabled
 *    (odd byte parity: an unwritten SRAM word reads as a parity error).  This
 *    runs without a stack, so it is the first thing that touches DMEM.
 * 3. sp = top of DMEM, gp, then rom_main() (C).  rom_main never returns: it
 *    jumps to the verified firmware entry point.
 * ===========================================================================*/
#include "generated/cc_memmap.h"

  .section .text.start, "ax"
  .globl _start
_start:
  la    t0, rom_trap
  csrw  mtvec, t0
  csrw  mie, zero
  li    t0, CC_DMEM_BASE
  li    t1, CC_DMEM_BASE + CC_DMEM_SIZE
1:
  sw    zero, 0(t0)
  sw    zero, 4(t0)
  sw    zero, 8(t0)
  sw    zero, 12(t0)
  addi  t0, t0, 16
  bltu  t0, t1, 1b
  la    sp, __stack_top
  .option push
  .option norelax
  la    gp, __global_pointer$
  .option pop
  call  rom_main
2:
  wfi
  j     2b

  /* trap: report (mcause, mepc, mtval) from C on a fresh stack, then park */
  .align 2
rom_trap:
  la    sp, __stack_top
  csrr  a0, mcause
  csrr  a1, mepc
  csrr  a2, mtval
  call  rom_trap_c
3:
  wfi
  j     3b
