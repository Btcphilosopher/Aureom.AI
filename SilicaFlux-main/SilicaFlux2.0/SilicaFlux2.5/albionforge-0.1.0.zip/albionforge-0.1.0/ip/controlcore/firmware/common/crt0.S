/* =============================================================================
 * SilicaFlux ControlCore firmware -- startup (entry point recorded in the image
 * header; the boot ROM jumps here after the CRC check).
 *   sp/gp, mtvec = trap_entry (direct mode), copy .data (LMA in IMEM -> VMA in
 *   DMEM), zero .bss, call main().  main() does not return.
 * ===========================================================================*/
  .section .text.start, "ax"
  .globl _start
_start:
  la    sp, __stack_top
  .option push
  .option norelax
  la    gp, __global_pointer$
  .option pop
  la    t0, trap_entry
  csrw  mtvec, t0
  /* .data */
  la    t0, __data_lma
  la    t1, __data_start
  la    t2, __data_end
1:
  bgeu  t1, t2, 2f
  lw    t3, 0(t0)
  sw    t3, 0(t1)
  addi  t0, t0, 4
  addi  t1, t1, 4
  j     1b
2:
  /* .bss */
  la    t1, __bss_start
  la    t2, __bss_end
3:
  bgeu  t1, t2, 4f
  sw    zero, 0(t1)
  addi  t1, t1, 4
  j     3b
4:
  call  main
5:
  wfi
  j     5b
