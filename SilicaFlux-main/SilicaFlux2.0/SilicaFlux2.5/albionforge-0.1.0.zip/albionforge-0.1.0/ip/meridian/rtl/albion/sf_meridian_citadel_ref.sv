// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_citadel_ref
//
// REFERENCE model of the Citadel permission check -- NOT the Citadel.  The repository contains no block named
// Citadel; docs/meridian/00_AUDIT.md maps it to the permission-check role of CloudDMA (Project 64:
// sfdma_perm_table / sfdma_perm_checker: "a domain number is a label software can lie about") and SecureStore
// (P59).  This module defines the check interface the fabric enforces and gives the fabric a deterministic,
// testable policy.  A real Citadel replaces it through CITADEL_MODE = CIT_EXT.
//
// Policy: NENT entries { valid, src_mask[NM], dom_mask[NDOM], need_priv, base, mask, rd, wr }.  A request
// { src (the port), dom, priv, write, addr } is PERMITTED iff some valid entry satisfies
//     (addr & mask) == base  &&  src_mask[src]  &&  dom_mask[dom]  &&  (!need_priv || priv)  &&  (write ? wr : rd).
// Otherwise it is denied, with the most specific cause:  no entry covers the address -> F_NOMAP; covered but not for
// this src/domain -> F_DOMAIN; covered for src/domain but privilege missing -> F_PRIV; else the right is missing -> F_PERM.
// DEFAULT DENY: after reset no entry is valid, every request is denied until the management plane programs the table
// (Keystone through the policy port).  Programming is a write port; it must only be reachable from the management
// plane (the Citadel CSR target is reachable from Keystone only in the Albion configuration).  A policy change applies
// to the next check; a request already forwarded completes (the same revocation rule CloudDMA states: quiesce first).
//
// Check interface (per master port, one outstanding query per port):
//   cit_req_valid/ready : query handshake (the fabric holds fields stable while valid && !ready)
//   cit_rsp_valid       : one verdict per accepted query, in the SAME cycle (LAT = 0, combinational) or later
//                         (LAT = 1: registered, next cycle)
//   cit_rsp_ok/fault    : verdict, fault code sf_meridian_pkg::F_*
// tst_stall[m]: verification hook, 1 = accept the query but never answer (Citadel failure; fabric must fail closed).
// =============================================================================
`default_nettype none

module sf_meridian_citadel_ref #(
  parameter int NM   = 2,
  parameter int DOMW = 3,
  parameter int AW   = 32,
  parameter int NENT = 8,
  parameter int LAT  = 0,
  localparam int NDOM = 1 << DOMW,
  localparam int IW   = sf_meridian_pkg::clog2c(NENT),
  localparam int FW   = sf_meridian_pkg::FW
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // management-plane policy port
  input  wire logic                pol_we,
  input  wire logic [IW-1:0]       pol_idx,
  input  wire logic                pol_valid,
  input  wire logic [NM-1:0]       pol_src,
  input  wire logic [NDOM-1:0]     pol_dom,
  input  wire logic                pol_priv,
  input  wire logic [AW-1:0]       pol_base,
  input  wire logic [AW-1:0]       pol_mask,
  input  wire logic                pol_rd,
  input  wire logic                pol_wr,
  // check ports
  input  wire logic [NM-1:0]       cit_req_valid,
  output logic      [NM-1:0]       cit_req_ready,
  input  wire logic [NM*DOMW-1:0]  cit_req_dom,
  input  wire logic [NM-1:0]       cit_req_priv,
  input  wire logic [NM-1:0]       cit_req_write,
  input  wire logic [NM*AW-1:0]    cit_req_addr,
  output logic      [NM-1:0]       cit_rsp_valid,
  output logic      [NM-1:0]       cit_rsp_ok,
  output logic      [NM*FW-1:0]    cit_rsp_fault,
  input  wire logic [NM-1:0]       tst_stall
);

  logic [NENT-1:0]      e_v, e_priv, e_rd, e_wr;
  logic [NENT*NM-1:0]   e_src;
  logic [NENT*NDOM-1:0] e_dom;
  logic [NENT*AW-1:0]   e_base, e_mask;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      e_v <= '0; e_priv <= '0; e_rd <= '0; e_wr <= '0;
      e_src <= '0; e_dom <= '0; e_base <= '0; e_mask <= '0;
    end else if (pol_we) begin
      e_v[pol_idx]                    <= pol_valid;
      e_priv[pol_idx]                 <= pol_priv;
      e_rd[pol_idx]                   <= pol_rd;
      e_wr[pol_idx]                   <= pol_wr;
      e_src[pol_idx*NM +: NM]         <= pol_src;
      e_dom[pol_idx*NDOM +: NDOM]     <= pol_dom;
      e_base[pol_idx*AW +: AW]        <= pol_base;
      e_mask[pol_idx*AW +: AW]        <= pol_mask;
    end
  end

  logic [NM-1:0]    v_ok;
  logic [NM*FW-1:0] v_fault;

  always_comb begin
    for (int m = 0; m < NM; m++) begin
      logic any_addr, any_sd, any_sdp, any_ok;
      logic [DOMW-1:0] d;
      d = cit_req_dom[m*DOMW +: DOMW];
      any_addr = 1'b0; any_sd = 1'b0; any_sdp = 1'b0; any_ok = 1'b0;
      for (int e = 0; e < NENT; e++) begin
        if (e_v[e] && ((cit_req_addr[m*AW +: AW] & e_mask[e*AW +: AW]) == e_base[e*AW +: AW])) begin
          any_addr = 1'b1;
          if (e_src[e*NM + m] && e_dom[e*NDOM + 32'(d)]) begin
            any_sd = 1'b1;
            if (!e_priv[e] || cit_req_priv[m]) begin
              any_sdp = 1'b1;
              if (cit_req_write[m] ? e_wr[e] : e_rd[e]) any_ok = 1'b1;
            end
          end
        end
      end
      v_ok[m] = any_ok;
      if (any_ok)        v_fault[m*FW +: FW] = sf_meridian_pkg::F_NONE;
      else if (!any_addr) v_fault[m*FW +: FW] = sf_meridian_pkg::F_NOMAP;
      else if (!any_sd)   v_fault[m*FW +: FW] = sf_meridian_pkg::F_DOMAIN;
      else if (!any_sdp)  v_fault[m*FW +: FW] = sf_meridian_pkg::F_PRIV;
      else                v_fault[m*FW +: FW] = sf_meridian_pkg::F_PERM;
    end
  end

  assign cit_req_ready = '1;

  generate
    if (LAT == 0) begin : g_comb
      assign cit_rsp_valid = cit_req_valid & ~tst_stall;
      assign cit_rsp_ok    = v_ok;
      assign cit_rsp_fault = v_fault;
    end else begin : g_reg
      logic [NM-1:0]    rv_q, rok_q;
      logic [NM*FW-1:0] rf_q;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin rv_q <= '0; rok_q <= '0; rf_q <= '0; end
        else begin
          rv_q  <= cit_req_valid & ~tst_stall;
          rok_q <= v_ok;
          rf_q  <= v_fault;
        end
      end
      assign cit_rsp_valid = rv_q;
      assign cit_rsp_ok    = rok_q;
      assign cit_rsp_fault = rf_q;
    end
  endgenerate
endmodule

`default_nettype wire
