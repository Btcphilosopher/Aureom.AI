// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_router
//
// The switching core: a REGISTERED, CROSSPOINT-BUFFERED crossbar of NM master ports x NT target ports.
//
// Request path   master port m --push--> crosspoint buffer (m,t) --arbiter(t)--> egress slice(t) --> target t
//   * one buffer (sfn_fifo, REQ_DEPTH entries, Project 22) per CONNECTED (m,t) pair: a request waits only for its own
//     target -- a stalled target t fills only the buffers (*,t); traffic to every other target, from every master, is
//     untouched (no head-of-line blocking between targets inside the fabric);
//   * one arbiter per target (sf_meridian_arbiter) over the NM buffer heads, class-aware (ARB_QOS) or plain round
//     robin (ARB_RR); the winner moves into the egress slice in the same cycle (transfer = grant, no grant lock);
//     different targets arbitrate and transfer concurrently: NT independent transfers per cycle at most;
//   * the egress slice has 1 + TGT_SLICE[t] stages: the mandatory first stage registers every target request port
//     (no combinational path from a target's ready into the fabric), the others are physical pipeline stages;
//   * the SOURCE is stamped here from the buffer index: a master cannot choose its `src`.
// Response path  target t --> (TGT_SLICE[t] stages) --> steer by `src` --> master port m (response slots)
//   * no buffers: a master port always accepts (response capacity is reserved by its outstanding limit), so the
//     response network never blocks a target and a stalled master cannot hold up anyone else's responses;
//   * a response whose src is out of range or has no path to that target is consumed here (ev_badsrc), never forwarded.
// Latency added by the router with empty buffers: request  = 1 (buffer) + 1 (egress stage) + TGT_SLICE[t];
//                                                 response = TGT_SLICE[t] (+ 1 master-port slot register).
//
// Request word (RQW) layout, MSB..LSB: {op[1:0], tag, dom, priv, tc[2:0], addr, wdata, wstrb}
// Egress word                        : {src, op, tag, dom, priv, tc, addr, wdata, wstrb}
// =============================================================================
`default_nettype none

module sf_meridian_router #(
  parameter int                 NM        = 2,
  parameter int                 NT        = 2,
  parameter int                 AW        = 32,
  parameter int                 DW        = 64,
  parameter int                 TAGW      = 4,
  parameter int                 DOMW      = 3,
  parameter int                 REQ_DEPTH = 2,
  parameter int                 ARB_MODE  = 1,
  parameter int                 STARVE    = 8,
  parameter logic [NM*NT-1:0]   CONN      = {(NM*NT){1'b1}},      // bit m*NT + t
  parameter logic [NT*4-1:0]    TGT_SLICE = {(NT*4){1'b0}},
  localparam int                SRCW      = sf_meridian_pkg::clog2c(NM),
  localparam int                RQW       = 2 + TAGW + DOMW + 1 + 3 + AW + DW + DW / 8,
  localparam int                EGW       = SRCW + RQW,
  localparam int                RPW       = SRCW + TAGW + DOMW + 2 + 3 + DW,
  localparam int                SW        = sf_meridian_pkg::clog2c(NM + 1),
  localparam int                OW        = sf_meridian_pkg::clog2c(NM * REQ_DEPTH + 1),
  localparam int                CNW       = sf_meridian_pkg::clog2c(REQ_DEPTH + 1)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,

  // ---- from the master ports
  input  wire logic [NM*NT-1:0]     xp_valid,
  output logic      [NM*NT-1:0]     xp_ready,
  input  wire logic [NM*RQW-1:0]    xp_word,

  // ---- target request channels
  output logic      [NT-1:0]        t_req_valid,
  input  wire logic [NT-1:0]        t_req_ready,
  output logic      [NT*SRCW-1:0]   t_req_src,
  output logic      [NT*2-1:0]      t_req_op,
  output logic      [NT*TAGW-1:0]   t_req_tag,
  output logic      [NT*DOMW-1:0]   t_req_dom,
  output logic      [NT-1:0]        t_req_priv,
  output logic      [NT*3-1:0]      t_req_tc,
  output logic      [NT*AW-1:0]     t_req_addr,
  output logic      [NT*DW-1:0]     t_req_wdata,
  output logic      [NT*DW/8-1:0]   t_req_wstrb,

  // ---- target response channels
  input  wire logic [NT-1:0]        t_rsp_valid,
  output logic      [NT-1:0]        t_rsp_ready,
  input  wire logic [NT*SRCW-1:0]   t_rsp_src,
  input  wire logic [NT*TAGW-1:0]   t_rsp_tag,
  input  wire logic [NT*DOMW-1:0]   t_rsp_dom,
  input  wire logic [NT*2-1:0]      t_rsp_op,
  input  wire logic [NT*3-1:0]      t_rsp_status,
  input  wire logic [NT*DW-1:0]     t_rsp_rdata,

  // ---- steered responses to the master ports, indexed [m*NT + t]
  output logic      [NM*NT-1:0]     mr_valid,
  output logic      [NM*NT*TAGW-1:0] mr_tag,
  output logic      [NM*NT*DOMW-1:0] mr_dom,
  output logic      [NM*NT*2-1:0]   mr_op,
  output logic      [NM*NT*3-1:0]   mr_status,
  output logic      [NM*NT*DW-1:0]  mr_rdata,

  // ---- observability (per target)
  output logic      [NT*SW-1:0]     ev_arb_stall,   // requesters present but not served this cycle
  output logic      [NT*OW-1:0]     ev_occ,         // entries held in the crosspoint buffers of the target
  output logic      [NT-1:0]        ev_badsrc       // response consumed: src out of range / unreachable
);

`ifndef SYNTHESIS
  // elaboration-time sanity: stage counts in range
  initial begin
    for (int t = 0; t < NT; t++)
      if (TGT_SLICE[t*4 +: 4] > 4'd8) $error("sf_meridian_router: TGT_SLICE[%0d] too large", t);
  end
`endif

  // ------------------------------------------------------------ crosspoint buffers
  logic [NM*NT-1:0]      xq_v;
  logic [NM*NT*RQW-1:0]  xq_d;
  logic [NM*NT-1:0]      xq_pop;
  logic [NM*NT*CNW-1:0]  xq_cnt;

  generate
    for (genvar m = 0; m < NM; m++) begin : g_m
      for (genvar t = 0; t < NT; t++) begin : g_t
        if (CONN[m*NT + t]) begin : g_c
          sfn_fifo #(.W(RQW), .DEPTH(REQ_DEPTH), .PASS_FULL(0)) u_xq (
            .clk, .rst_n,
            .in_valid (xp_valid[m*NT + t]),
            .in_ready (xp_ready[m*NT + t]),
            .in_data  (xp_word[m*RQW +: RQW]),
            .out_valid(xq_v[m*NT + t]),
            .out_ready(xq_pop[m*NT + t]),
            .out_data (xq_d[(m*NT + t)*RQW +: RQW]),
            .count    (xq_cnt[(m*NT + t)*CNW +: CNW]));
        end else begin : g_n
          assign xp_ready[m*NT + t] = 1'b0;
          assign xq_v[m*NT + t]     = 1'b0;
          assign xq_d[(m*NT + t)*RQW +: RQW] = '0;
          assign xq_cnt[(m*NT + t)*CNW +: CNW] = '0;
          /* verilator lint_off UNUSEDSIGNAL */
          wire unused_xp = xp_valid[m*NT + t] ^ xq_pop[m*NT + t];
          /* verilator lint_on UNUSEDSIGNAL */
        end
      end
    end
  endgenerate

  // ------------------------------------------------------------ per-target arbitration + egress
  generate
    for (genvar t = 0; t < NT; t++) begin : g_tgt
      localparam int ESTG = 1 + 32'(TGT_SLICE[t*4 +: 4]);
      localparam int RSTG = 32'(TGT_SLICE[t*4 +: 4]);

      logic [NM-1:0]    req;
      logic [NM*3-1:0]  lvl;
      logic [NM-1:0]    grant;
      logic [SRCW-1:0]  gidx;     // arbiter index width is clog2c(NM) == SRCW
      logic             gvalid;
      logic [NM-1:0]    urg;
      logic             en;
      logic [EGW-1:0]   eg_word, eg_out;
      logic             eg_in_ready, eg_out_valid;

      for (genvar m = 0; m < NM; m++) begin : g_r
        assign req[m]        = xq_v[m*NT + t];
        assign lvl[m*3 +: 3] = xq_d[(m*NT + t)*RQW + (DW/8 + DW + AW) +: 3];   // tc field of the buffer head
        assign xq_pop[m*NT + t] = grant[m] && en;
      end

      assign en = eg_in_ready;

      sf_meridian_arbiter #(.N(NM), .MODE(ARB_MODE), .STARVE(STARVE)) u_arb (
        .clk, .rst_n, .req, .lvl, .en, .grant, .gidx, .gvalid, .urgent(urg));

      always_comb begin
        logic [RQW-1:0] w;
        w = '0;
        for (int m = 0; m < NM; m++)
          if (grant[m]) w = w | xq_d[(m*NT + t)*RQW +: RQW];
        eg_word = {gidx, w};
      end

      wire eg_valid = gvalid;

      sf_meridian_slice #(.W(EGW), .STAGES(ESTG)) u_eg (
        .clk, .rst_n,
        .in_valid(eg_valid), .in_ready(eg_in_ready), .in_data(eg_word),
        .out_valid(eg_out_valid), .out_ready(t_req_ready[t]), .out_data(eg_out));

      assign t_req_valid[t]                = eg_out_valid;
      assign t_req_src[t*SRCW +: SRCW]     = eg_out[RQW +: SRCW];
      assign t_req_op[t*2 +: 2]            = eg_out[RQW-1 -: 2];
      assign t_req_tag[t*TAGW +: TAGW]     = eg_out[RQW-3 -: TAGW];
      assign t_req_dom[t*DOMW +: DOMW]     = eg_out[RQW-3-TAGW -: DOMW];
      assign t_req_priv[t]                 = eg_out[RQW-3-TAGW-DOMW];
      assign t_req_tc[t*3 +: 3]            = eg_out[DW/8 + DW + AW +: 3];
      assign t_req_addr[t*AW +: AW]        = eg_out[DW/8 + DW +: AW];
      assign t_req_wdata[t*DW +: DW]       = eg_out[DW/8 +: DW];
      assign t_req_wstrb[t*(DW/8) +: DW/8] = eg_out[0 +: DW/8];

      // arbitration stall: requesters present minus the one transferred
      always_comb begin
        logic [SW-1:0] n;
        n = '0;
        for (int m = 0; m < NM; m++) if (req[m]) n = n + SW'(1);
        if (gvalid && en) n = n - SW'(1);
        ev_arb_stall[t*SW +: SW] = n;
      end

      // occupancy of the buffers in front of this target
      always_comb begin
        logic [OW-1:0] o;
        o = '0;
        for (int m = 0; m < NM; m++) o = o + OW'(xq_cnt[(m*NT + t)*CNW +: CNW]);
        ev_occ[t*OW +: OW] = o;
      end

      // ---------------- response side: slice, then steer by src
      logic              rs_v, rs_in_ready;
      logic [RPW-1:0]    rs_w, rs_o;
      assign rs_w = {t_rsp_src[t*SRCW +: SRCW], t_rsp_tag[t*TAGW +: TAGW], t_rsp_dom[t*DOMW +: DOMW],
                     t_rsp_op[t*2 +: 2], t_rsp_status[t*3 +: 3], t_rsp_rdata[t*DW +: DW]};
      sf_meridian_slice #(.W(RPW), .STAGES(RSTG)) u_rs (
        .clk, .rst_n,
        .in_valid(t_rsp_valid[t]), .in_ready(rs_in_ready), .in_data(rs_w),
        .out_valid(rs_v), .out_ready(1'b1), .out_data(rs_o));
      assign t_rsp_ready[t] = rs_in_ready;

      wire [SRCW-1:0] r_src = rs_o[RPW-1 -: SRCW];
      logic src_ok;
      always_comb begin
        src_ok = 1'b0;
        for (int m = 0; m < NM; m++)
          if (r_src == SRCW'(m) && CONN[m*NT + t]) src_ok = 1'b1;
      end
      assign ev_badsrc[t] = rs_v && !src_ok;

      for (genvar m = 0; m < NM; m++) begin : g_s
        assign mr_valid[m*NT + t]                   = rs_v && (r_src == SRCW'(m)) && CONN[m*NT + t];
        assign mr_tag[(m*NT + t)*TAGW +: TAGW]      = rs_o[RPW-SRCW-1 -: TAGW];
        assign mr_dom[(m*NT + t)*DOMW +: DOMW]      = rs_o[RPW-SRCW-TAGW-1 -: DOMW];
        assign mr_op[(m*NT + t)*2 +: 2]             = rs_o[RPW-SRCW-TAGW-DOMW-1 -: 2];
        assign mr_status[(m*NT + t)*3 +: 3]         = rs_o[DW +: 3];
        assign mr_rdata[(m*NT + t)*DW +: DW]        = rs_o[0 +: DW];
      end
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_urg = ^urg;
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate
endmodule

`default_nettype wire
