// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_arbiter
//
// Per-target request arbiter of the crossbar.  N requesters present `req[i]` and a traffic-class level
// `lvl[i]` (sf_meridian_pkg::TC_*, larger = more urgent).  `en` is the downstream's registered "I can take
// one" signal; a transfer happens in the cycle `gvalid && en` -- the grant IS the transfer (no grant lock is
// needed: nothing is granted that is not moved in the same cycle).
//
// MODE = ARB_RR  : plain round robin.  Levels are ignored.
//                  Bound: a requester that keeps requesting is served after at most N-1 transfers of others.
// MODE = ARB_QOS : selection order
//                    1. aging: a requester that has seen STARVE transfers of others while requesting is URGENT
//                       and sits above every class level;
//                    2. otherwise the highest class level wins;
//                    3. ties inside the winning level: round robin from `ptr`, which moves past the winner
//                       on every transfer.
//                  Bound: a requester that keeps requesting is served after at most STARVE + N - 1 transfers of
//                  others.  STARVE = 0 makes everyone urgent at once = plain round robin.
//                  Priority is a latency preference, NOT a bandwidth reservation: under saturation a class gets
//                  what the classes above it leave, down to the aging floor of one transfer per STARVE + N - 1.
//
// Determinism: grant is a pure function of (req, lvl, ptr, age): same-target contention always resolves the
// same way for the same history.  `req` may change freely between cycles (the payload mux sits behind the grant
// in the router; the transfer is atomic).  Combinational path: req/lvl -> grant.  No path from `en`.
// The policy is identical to the verified sfn_qos_arbiter (Project 22) with its grant lock disabled; the
// structure is new and is checked against it cycle by cycle in tests/meridian/tb/tb_arb_diff.sv.
// =============================================================================
`default_nettype none

module sf_meridian_arbiter #(
  parameter int N      = 4,
  parameter int MODE   = 1,           // sf_meridian_pkg::ARB_RR / ARB_QOS
  parameter int STARVE = 8,
  localparam int LW    = 3,
  localparam int IW    = sf_meridian_pkg::clog2c(N),
  localparam int AGW   = sf_meridian_pkg::clog2c(STARVE + 1)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic [N-1:0]    req,
  input  wire logic [N*LW-1:0] lvl,
  input  wire logic            en,
  output logic      [N-1:0]    grant,       // one-hot or zero; independent of `en`
  output logic      [IW-1:0]   gidx,
  output logic                 gvalid,
  output logic      [N-1:0]    urgent       // observability: aging reached
);
  logic [IW-1:0]    ptr_q;
  logic [N*AGW-1:0] age_q;

  logic [LW:0]  eff   [N];
  logic [LW:0]  top;
  logic [N-1:0] elig, upper;
  logic         found;
  logic [IW-1:0] pick;

  wire xfer = gvalid && en;

  always_comb begin
    for (int i = 0; i < N; i++) begin
      urgent[i] = (MODE != 0) && (age_q[i*AGW +: AGW] >= AGW'(STARVE));
      if (MODE == 0)        eff[i] = '0;
      else if (urgent[i])   eff[i] = {1'b1, {LW{1'b0}}};
      else                  eff[i] = {1'b0, lvl[i*LW +: LW]};
    end
    top = '0;
    for (int i = 0; i < N; i++)
      if (req[i] && eff[i] > top) top = eff[i];
    for (int i = 0; i < N; i++) begin
      elig[i]  = req[i] && (eff[i] == top);
      upper[i] = elig[i] && (i >= 32'(ptr_q));
    end
    found = 1'b0;
    pick  = '0;
    if (|upper) begin
      for (int i = N - 1; i >= 0; i--) if (upper[i]) begin pick = IW'(i); found = 1'b1; end
    end else begin
      for (int i = N - 1; i >= 0; i--) if (elig[i])  begin pick = IW'(i); found = 1'b1; end
    end
    gvalid = found;
    gidx   = pick;
    grant  = found ? (N'(1) << pick) : '0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ptr_q <= '0;
      age_q <= '0;
    end else begin
      if (xfer) ptr_q <= (gidx == IW'(N - 1)) ? '0 : gidx + IW'(1);
      for (int i = 0; i < N; i++) begin
        if (!req[i] || (xfer && gidx == IW'(i)))
          age_q[i*AGW +: AGW] <= '0;
        else if (xfer && age_q[i*AGW +: AGW] < AGW'(STARVE))
          age_q[i*AGW +: AGW] <= age_q[i*AGW +: AGW] + AGW'(1);
      end
    end
  end
endmodule

`default_nettype wire
