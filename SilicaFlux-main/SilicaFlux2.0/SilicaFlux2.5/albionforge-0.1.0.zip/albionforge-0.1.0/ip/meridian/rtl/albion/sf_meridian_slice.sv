// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_slice
//
// Physical register slice: STAGES back-to-back stages between two distant regions.
// STAGES = 0 : a wire (no register, no latency).
// STAGES >= 1: each stage is a 2-entry valid/ready FIFO with REGISTERED status flags (the verified sfn_fifo of
//              Project 22, DEPTH 2, vendored unmodified).  Consequences, each checked by formal/tb:
//    * outputs come from registers, so `out_valid` / `out_data` never depend on the downstream ready and
//      `in_ready` never depends on `out_ready`: NO combinational valid/ready path crosses a stage, hence no
//      combinational loop through any number of slices (the long-wire timing cut works in BOTH directions);
//    * no transaction loss, duplication or reordering (FIFO count / order / integrity proof, formal/fv_slice*);
//    * a stalled output holds its entry unchanged (stability) and back-pressure propagates stage by stage;
//    * full throughput: one transfer per cycle in steady state;
//    * latency: +1 cycle per stage when the slice is empty (measured in reports/latency.md);
//    * reset: asynchronous assert, synchronous release; every stage is empty after reset (nothing survives reset).
// =============================================================================
`default_nettype none

module sf_meridian_slice #(
  parameter int W      = 8,
  parameter int STAGES = 1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         in_valid,
  output logic              in_ready,
  input  wire logic [W-1:0] in_data,
  output logic              out_valid,
  input  wire logic         out_ready,
  output logic      [W-1:0] out_data
);
  generate
    if (STAGES == 0) begin : g_wire
      assign in_ready  = out_ready;
      assign out_valid = in_valid;
      assign out_data  = in_data;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_clk = clk ^ rst_n;
      /* verilator lint_on UNUSEDSIGNAL */
    end else begin : g_chain
      logic         v [STAGES + 1];
      logic         r [STAGES + 1];
      logic [W-1:0] d [STAGES + 1];
      assign v[0]      = in_valid;
      assign d[0]      = in_data;
      assign in_ready  = r[0];
      assign out_valid = v[STAGES];
      assign out_data  = d[STAGES];
      assign r[STAGES] = out_ready;
      for (genvar s = 0; s < STAGES; s++) begin : g_st
        /* verilator lint_off UNUSEDSIGNAL */
        logic [1:0] cnt_unused;
        /* verilator lint_on UNUSEDSIGNAL */
        sfn_fifo #(.W(W), .DEPTH(2), .PASS_FULL(0)) u_f (
          .clk, .rst_n,
          .in_valid(v[s]),  .in_ready(r[s]),  .in_data(d[s]),
          .out_valid(v[s+1]), .out_ready(r[s+1]), .out_data(d[s+1]),
          .count(cnt_unused));
      end
    end
  endgenerate
endmodule

`default_nettype wire
