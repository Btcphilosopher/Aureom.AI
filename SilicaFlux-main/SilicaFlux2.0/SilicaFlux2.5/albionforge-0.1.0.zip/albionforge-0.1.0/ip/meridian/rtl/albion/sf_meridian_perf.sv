// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_perf
//
// Performance counters of the fabric.  One flat bank of CW-bit SATURATING counters read through rd_sel (combinational
// read, index map: sf_meridian_pkg PF_* / pf_m / pf_t / pf_x, documented in docs/meridian/05_PERFORMANCE_COUNTERS.md).
//   global      cycles, busy cycles (any transaction pending anywhere), requests, completions, bytes, arbitration stalls
//   per master  requests accepted, completions, error completions by status, bytes written / read (OK completions),
//               response latency sum / count / max (acceptance -> delivery to the master), outstanding occupancy sum / max,
//               input stall cycles, protocol-violation counts
//   per target  requests delivered, bytes, arbitration stalls (requesters present but not served), crosspoint occupancy
//               sum / max, back-pressure cycles (egress valid, target not ready), consumed bad-source responses
//   matrix      requests delivered from master m to target t   ("traffic by endpoint")
// ctl_freeze holds every counter (consistent snapshot); ctl_clear zeroes them (clear wins over freeze).
// Counters observe the datapath; they never influence it.  Every counter is cross-checked by the testbench against its
// own independent count at the end of each run.
// =============================================================================
`default_nettype none

module sf_meridian_perf #(
  parameter int NM   = 2,
  parameter int NT   = 2,
  parameter int DW   = 64,
  parameter int LATW = 16,
  parameter int CW   = 32,
  parameter int OW   = 8,                                          // width of the per-target occupancy bus (router)
  localparam int SRCW = sf_meridian_pkg::clog2c(NM),
  localparam int BW   = sf_meridian_pkg::clog2c(DW / 8 + 1),
  localparam int SW   = sf_meridian_pkg::clog2c(NM + 1),
  localparam int NCNT = sf_meridian_pkg::pf_n(NM, NT),
  localparam int RSW  = sf_meridian_pkg::clog2c(NCNT)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 ctl_clear,
  input  wire logic                 ctl_freeze,
  // per master
  input  wire logic [NM-1:0]        m_acc,
  input  wire logic [NM-1:0]        m_stall_in,
  input  wire logic [NM-1:0]        m_dlv,
  input  wire logic [NM*3-1:0]      m_dlv_status,
  input  wire logic [NM-1:0]        m_dlv_wr,
  input  wire logic [NM*BW-1:0]     m_dlv_bytes,
  input  wire logic [NM*LATW-1:0]   m_dlv_lat,
  input  wire logic [NM*4-1:0]      m_viol,          // {SPOOF, TAGREUSE, MISALIGN, BADOP}
  input  wire logic [NM*8-1:0]      m_orph_n,
  input  wire logic [NM*8-1:0]      m_echo_n,
  input  wire logic [NM*8-1:0]      m_late_n,
  input  wire logic [NM*8-1:0]      m_pend,
  // per target
  input  wire logic [NT-1:0]        t_tx,            // request delivered to the target this cycle
  input  wire logic [NT*SRCW-1:0]   t_tx_src,
  input  wire logic [NT*BW-1:0]     t_tx_bytes,
  input  wire logic [NT*SW-1:0]     t_arb_stall,
  input  wire logic [NT*OW-1:0]     t_occ,
  input  wire logic [NT-1:0]        t_blocked,
  input  wire logic [NT-1:0]        t_badsrc,
  // read port
  input  wire logic [RSW-1:0]       rd_sel,
  output logic      [CW-1:0]        rd_data
);

  logic [CW-1:0] c [NCNT];

  function automatic logic [CW-1:0] sadd(input logic [CW-1:0] a, input logic [CW-1:0] b);
    logic [CW:0] s;
    begin
      s = {1'b0, a} + {1'b0, b};
      sadd = s[CW] ? {CW{1'b1}} : s[CW-1:0];
    end
  endfunction

  assign rd_data = (32'(rd_sel) < NCNT) ? c[rd_sel] : '0;

  always_ff @(posedge clk or negedge rst_n) begin
    // Reset / clear of the counter array.  AlbionForge fix: the original form `c[k] <= '0` inside a for loop is rejected
    // by the 5.020 release of the simulator front end (BLKLOOPINIT, "Unsupported"). A blocking clear is accepted by that
    // release and by Yosys 0.33 and has the same effect: every element is overwritten in this branch.
    if (!rst_n) begin
      /* verilator lint_off BLKSEQ */
      for (int k = 0; k < NCNT; k++) c[k] = '0;
    end else if (ctl_clear) begin
      for (int k = 0; k < NCNT; k++) c[k] = '0;
      /* verilator lint_on BLKSEQ */
    end else if (!ctl_freeze) begin
      logic [CW-1:0] s_req, s_cpl, s_bytes, s_arb, s_viol, s_pend;
      s_req = '0; s_cpl = '0; s_bytes = '0; s_arb = '0; s_viol = '0; s_pend = '0;

      for (int m = 0; m < NM; m++) begin
        logic [2:0]      st;
        logic [BW-1:0]   by;
        logic [LATW-1:0] la;
        logic [7:0]      pe;
        logic            dl, ok;
        st = m_dlv_status[m*3 +: 3];
        by = m_dlv_bytes[m*BW +: BW];
        la = m_dlv_lat[m*LATW +: LATW];
        pe = m_pend[m*8 +: 8];
        dl = m_dlv[m];
        ok = dl && (st == sf_meridian_pkg::ST_OKAY);

        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_REQ)]     <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_REQ)], CW'(m_acc[m]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_CPL)]     <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_CPL)], CW'(dl));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_CPLERR)]  <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_CPLERR)], CW'(dl && st != sf_meridian_pkg::ST_OKAY));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_DECERR)]  <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_DECERR)], CW'(dl && st == sf_meridian_pkg::ST_DECERR));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_DENIED)]  <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_DENIED)], CW'(dl && st == sf_meridian_pkg::ST_DENIED));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_TIMEOUT)] <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_TIMEOUT)], CW'(dl && st == sf_meridian_pkg::ST_TIMEOUT));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_PROTO)]   <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_PROTO)], CW'(dl && st == sf_meridian_pkg::ST_PROTO));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_SLVERR)]  <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_SLVERR)], CW'(dl && st == sf_meridian_pkg::ST_SLVERR));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_BYTES_WR)] <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_BYTES_WR)], (ok && m_dlv_wr[m]) ? CW'(by) : '0);
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_BYTES_RD)] <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_BYTES_RD)], (ok && !m_dlv_wr[m]) ? CW'(by) : '0);
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_LAT_SUM)] <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_LAT_SUM)], dl ? CW'(la) : '0);
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_LAT_CNT)] <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_LAT_CNT)], CW'(dl));
        if (dl && CW'(la) > c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_LAT_MAX)]) c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_LAT_MAX)] <= CW'(la);
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_OUT_SUM)] <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_OUT_SUM)], CW'(pe));
        if (CW'(pe) > c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_OUT_MAX)]) c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_OUT_MAX)] <= CW'(pe);
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_STALL_IN)] <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_STALL_IN)], CW'(m_stall_in[m]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_BADOP)]     <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_BADOP)], CW'(m_viol[m*4 + 0]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_MISALIGN)]  <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_MISALIGN)], CW'(m_viol[m*4 + 1]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_TAGREUSE)]  <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_TAGREUSE)], CW'(m_viol[m*4 + 2]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_SPOOF)]     <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_SPOOF)], CW'(m_viol[m*4 + 3]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_ORPHAN)]    <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_ORPHAN)], CW'(m_orph_n[m*8 +: 8]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_ECHO)]      <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_ECHO)], CW'(m_echo_n[m*8 +: 8]));
        c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_LATE)]      <= sadd(c[sf_meridian_pkg::pf_m(m, sf_meridian_pkg::PFM_V_LATE)], CW'(m_late_n[m*8 +: 8]));

        s_req   = sadd(s_req, CW'(m_acc[m]));
        s_cpl   = sadd(s_cpl, CW'(dl));
        s_bytes = sadd(s_bytes, ok ? CW'(by) : '0);
        s_pend  = sadd(s_pend, CW'(pe));
        s_viol  = sadd(s_viol, CW'(m_viol[m*4 + 0]) + CW'(m_viol[m*4 + 1]) + CW'(m_viol[m*4 + 2]) + CW'(m_viol[m*4 + 3])
                               + CW'(m_orph_n[m*8 +: 8]) + CW'(m_echo_n[m*8 +: 8]));
      end

      for (int t = 0; t < NT; t++) begin
        c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_REQ)]     <= sadd(c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_REQ)], CW'(t_tx[t]));
        c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_BYTES)]   <= sadd(c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_BYTES)], t_tx[t] ? CW'(t_tx_bytes[t*BW +: BW]) : '0);
        c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_ARBSTALL)] <= sadd(c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_ARBSTALL)], CW'(t_arb_stall[t*SW +: SW]));
        c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_OCC_SUM)] <= sadd(c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_OCC_SUM)], CW'(t_occ[t*OW +: OW]));
        if (CW'(t_occ[t*OW +: OW]) > c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_OCC_MAX)]) c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_OCC_MAX)] <= CW'(t_occ[t*OW +: OW]);
        c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_BUSY)]    <= sadd(c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_BUSY)], CW'(t_blocked[t]));
        c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_BADSRC)]  <= sadd(c[sf_meridian_pkg::pf_t(NM, t, sf_meridian_pkg::PFT_BADSRC)], CW'(t_badsrc[t]));
        s_arb  = sadd(s_arb, CW'(t_arb_stall[t*SW +: SW]));
        s_viol = sadd(s_viol, CW'(t_badsrc[t]));
        for (int m = 0; m < NM; m++)
          if (t_tx[t] && t_tx_src[t*SRCW +: SRCW] == SRCW'(m))
            c[sf_meridian_pkg::pf_x(NM, NT, m, t)] <= sadd(c[sf_meridian_pkg::pf_x(NM, NT, m, t)], CW'(1));
      end

      c[sf_meridian_pkg::PFG_CYCLES]   <= sadd(c[sf_meridian_pkg::PFG_CYCLES], CW'(1));
      c[sf_meridian_pkg::PFG_BUSY]     <= sadd(c[sf_meridian_pkg::PFG_BUSY], CW'(s_pend != '0));
      c[sf_meridian_pkg::PFG_REQ]      <= sadd(c[sf_meridian_pkg::PFG_REQ], s_req);
      c[sf_meridian_pkg::PFG_CPL]      <= sadd(c[sf_meridian_pkg::PFG_CPL], s_cpl);
      c[sf_meridian_pkg::PFG_BYTES]    <= sadd(c[sf_meridian_pkg::PFG_BYTES], s_bytes);
      c[sf_meridian_pkg::PFG_ARBSTALL] <= sadd(c[sf_meridian_pkg::PFG_ARBSTALL], s_arb);
      c[sf_meridian_pkg::PFG_VIOL]     <= sadd(c[sf_meridian_pkg::PFG_VIOL], s_viol);
    end
  end
endmodule

`default_nettype wire
