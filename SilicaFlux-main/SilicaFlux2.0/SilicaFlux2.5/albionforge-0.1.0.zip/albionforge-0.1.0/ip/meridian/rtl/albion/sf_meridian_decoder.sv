// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_decoder
//
// One master port's address decoder.  Target t is selected when (addr & TGT_MASK[t]) == TGT_BASE[t]
// (base / mask windows, the DataFabric convention; windows must not overlap -- scripts/check_config.py
// and the elaboration check in sf_meridian_fabric reject overlaps; if they did, the lowest target
// index would win).  `reach` additionally requires the topology connectivity bit CONN[tgt] of this
// master: an address can decode while no physical path exists from this master (a segmented or
// sparse crossbar), which is reported differently (F_NOROUTE) from an unmapped address (F_UNMAPPED).
// `misaligned`: an address with addr[OFF-1:0] != 0 (OFF = log2(DW/8)): the target interface is beat
// based, byte lanes are selected with the write strobes.
// Purely combinational.  Reference: sfb_addr_decoder (DataFabric), same window rule.
// =============================================================================
`default_nettype none

module sf_meridian_decoder #(
  parameter int               NT          = 2,
  parameter int               AW          = 32,
  parameter int               DW          = 64,
  parameter int               CHECK_ALIGN = 1,
  parameter logic [NT*AW-1:0] TGT_BASE    = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK    = {(NT*AW){1'b0}},
  parameter logic [NT-1:0]    CONN        = {NT{1'b1}},
  localparam int              TW          = sf_meridian_pkg::clog2c(NT),
  localparam int              OFF         = (DW > 8) ? $clog2(DW / 8) : 1
) (
  input  wire logic [AW-1:0] addr,
  output logic               hit,         // some window matches
  output logic [TW-1:0]      tgt,         // lowest matching target (valid when hit)
  output logic               reach,       // hit and this master is connected to tgt
  output logic               misaligned
);
  always_comb begin
    hit  = 1'b0;
    tgt  = '0;
    for (int t = NT - 1; t >= 0; t--) begin
      if ((addr & TGT_MASK[t*AW +: AW]) == TGT_BASE[t*AW +: AW]) begin
        hit = 1'b1;
        tgt = TW'(t);
      end
    end
    reach      = hit && CONN[tgt];
    misaligned = (CHECK_ALIGN != 0) && (DW > 8) && (addr[OFF-1:0] != '0);
  end
endmodule

`default_nettype wire
