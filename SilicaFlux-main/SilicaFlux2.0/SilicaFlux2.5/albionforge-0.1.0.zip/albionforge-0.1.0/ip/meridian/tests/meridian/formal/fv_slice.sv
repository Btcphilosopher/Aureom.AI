// Formal harness: sf_meridian_slice with STAGES register stages (no loss, no duplication, no reordering, stability,
// bounded latency, capacity).  Environment: none, except for the latency property which assumes the sink is always ready.
//   S1 conservation / capacity: elements inside = pushes - pops, never above 2*STAGES  (nothing lost, nothing invented)
//   S2 order and integrity of a tracked element        S3 stability of a held output
//   S4 bounded latency (LAT = 1): with the sink always ready a tracked element leaves within 3*STAGES cycles
module fv_slice #(parameter int W = 3, parameter int STAGES = 2, parameter int LAT = 0) (
  input logic         clk,
  input logic         in_valid,
  input logic [W-1:0] in_data,
  input logic         out_ready_free,
  input logic         track
);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  wire out_ready = (LAT != 0) ? 1'b1 : out_ready_free;
  logic in_ready, out_valid;
  logic [W-1:0] out_data;
  sf_meridian_slice #(.W(W), .STAGES(STAGES)) dut (.clk, .rst_n, .in_valid, .in_ready, .in_data, .out_valid, .out_ready, .out_data);
`ifdef FORMAL
  localparam int CAP = 2 * STAGES;
  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;
  logic [4:0] m_cnt, trk_pos, trk_age;
  logic       trk_v, held_q;
  logic [W-1:0] trk_d, head_q;
  initial begin m_cnt = '0; trk_v = 1'b0; trk_pos = '0; trk_age = '0; trk_d = '0; held_q = 1'b0; head_q = '0; end
  always_ff @(posedge clk) begin
    if (!rst_n) begin m_cnt <= '0; trk_v <= 1'b0; held_q <= 1'b0; end
    else begin
      m_cnt <= m_cnt + 5'(push) - 5'(pop);
      if (trk_v) trk_age <= trk_age + 5'd1;
      if (trk_v && pop) begin if (trk_pos == '0) trk_v <= 1'b0; else trk_pos <= trk_pos - 5'd1; end
      if (!trk_v && push && track) begin trk_v <= 1'b1; trk_d <= in_data; trk_pos <= m_cnt - 5'(pop); trk_age <= '0; end
      held_q <= out_valid && !out_ready;
      head_q <= out_data;
    end
  end
  always_comb if (rst_n) begin
    assert (m_cnt <= 5'(CAP));                                              // S1
    if (!in_ready) assert (m_cnt != '0);                                    // back-pressure only when something is held
    if (trk_v) assert (trk_pos < m_cnt);
    if (trk_v && trk_pos == '0 && pop) assert (out_data == trk_d);          // S2
    if (LAT != 0 && trk_v) assert (trk_age <= 5'(3 * STAGES));              // S4
  end
  always_ff @(posedge clk) if (rst_n && held_q) assert (out_valid && out_data == head_q);   // S3
`endif
endmodule
