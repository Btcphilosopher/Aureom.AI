// Formal harness: sf_meridian_decoder (combinational, free address).  NT = 3 windows given by base / mask, CONN row 3'b101.
// The windows deliberately OVERLAP (T0 and T1 both cover addr[7:6] == 00): legal configurations never overlap, but the tie-break is part
// of the contract (lowest index wins) and is checked here.
//   D1 hit <=> some window matches;  D2 the selected target's window matches and no lower-index window does (lowest wins)
//   D3 reach <=> hit && CONN[tgt];   D4 misaligned <=> addr[OFF-1:0] != 0
module fv_decoder (input logic [7:0] addr);
  localparam int NT = 3, AW = 8, DW = 32;
  localparam logic [NT*AW-1:0] BASE = {8'h80, 8'h00, 8'h00};
  localparam logic [NT*AW-1:0] MASK = {8'h80, 8'hC0, 8'h80};
  localparam logic [NT-1:0]    CONN = 3'b101;
  logic hit, reach, mis;
  logic [1:0] tgt;
  sf_meridian_decoder #(.NT(NT), .AW(AW), .DW(DW), .TGT_BASE(BASE), .TGT_MASK(MASK), .CONN(CONN)) dut (.addr, .hit, .tgt, .reach, .misaligned(mis));
`ifdef FORMAL
  logic [NT-1:0] m;
  always_comb begin
    for (int t = 0; t < NT; t++) m[t] = ((addr & MASK[t*AW +: AW]) == BASE[t*AW +: AW]);
    assert (hit == (m != '0));                                              // D1
    if (hit) begin
      assert (m[tgt]);                                                      // D2
      for (int t = 0; t < NT; t++) if (t < int'(tgt)) assert (!m[t]);
    end
    assert (reach == (hit && CONN[tgt]));                                   // D3
    assert (mis == (addr[1:0] != 2'b00));                                   // D4
  end
`endif
endmodule
