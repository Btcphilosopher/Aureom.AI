# tests/meridian

| file | what |
|---|---|
| `tb/tb_meridian.sv` | self-checking system bench for every configuration (oracle, scoreboard, target models with fault injection, monitors, counter mirror, 16 tests) |
| `tb/tb_arb_diff.sv` | arbiter differential test against the verified `sfn_qos_arbiter` + starvation-bound monitor |
| `formal/fv_fifo.sv`, `fv_slice.sv`, `fv_arbiter.sv`, `fv_decoder.sv`, `fv_fabric.sv` | formal harnesses (properties in the file headers) |

Run them through `scripts/` (see the top-level `Makefile` and docs/meridian/07_VERIFICATION.md): `run_tb.py CONFIG [--tests a,b] [--seed N]`,
`regress.py`, `run_arb.py`, `formal.py`, `mutate.py`. Configurations: `scripts/meridian_cfgs.py`.
