// Formal harness: sfn_fifo (Project 22, vendored unmodified) -- the primitive behind every crosspoint buffer and register slice.
// Re-proved in this project's flow.  Environment: none (inputs free).  Properties:
//   F1 occupancy equals pushes - pops (shadow counter) and never exceeds DEPTH;   F2 in_ready <=> not full, out_valid <=> not empty
//   F3 order and integrity: a chosen pushed element leaves after exactly the elements ahead of it, data unchanged
//   F4 stability: a held head is unchanged in the next cycle
module fv_fifo #(parameter int W = 4, parameter int DEPTH = 3) (
  input logic         clk,
  input logic         in_valid,
  input logic [W-1:0] in_data,
  input logic         out_ready,
  input logic         track
);
  localparam int CNTW = sfn_pkg::clog2c(DEPTH + 1);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic            in_ready, out_valid;
  logic [W-1:0]    out_data;
  logic [CNTW-1:0] count;
  sfn_fifo #(.W(W), .DEPTH(DEPTH), .PASS_FULL(0)) dut (.clk, .rst_n, .in_valid, .in_ready, .in_data, .out_valid, .out_ready, .out_data, .count);

`ifdef FORMAL
  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;
  logic [CNTW:0] m_cnt, trk_pos;
  logic          trk_v, held_q;
  logic [W-1:0]  trk_d, head_q;
  initial begin m_cnt = '0; trk_v = 1'b0; trk_d = '0; trk_pos = '0; held_q = 1'b0; head_q = '0; end
  always_ff @(posedge clk) begin
    if (!rst_n) begin m_cnt <= '0; trk_v <= 1'b0; held_q <= 1'b0; end
    else begin
      m_cnt <= m_cnt + (CNTW+1)'(push) - (CNTW+1)'(pop);
      if (trk_v && pop) begin
        if (trk_pos == '0) trk_v <= 1'b0; else trk_pos <= trk_pos - 1'b1;
      end
      if (!trk_v && push && track) begin trk_v <= 1'b1; trk_d <= in_data; trk_pos <= m_cnt - (CNTW+1)'(pop); end
      held_q <= out_valid && !out_ready;
      head_q <= out_data;
    end
  end
  always_comb if (rst_n) begin
    assert ((CNTW+1)'(count) == m_cnt);                                   // F1
    assert (m_cnt <= (CNTW+1)'(DEPTH));
    assert (in_ready == (m_cnt < (CNTW+1)'(DEPTH)));                      // F2
    assert (out_valid == (m_cnt != '0));
    if (trk_v) assert (trk_pos < m_cnt);
    if (trk_v && trk_pos == '0) assert (out_valid && out_data == trk_d);  // F3
  end
  always_ff @(posedge clk) if (rst_n && held_q) assert (out_valid && out_data == head_q);   // F4
`endif
endmodule
