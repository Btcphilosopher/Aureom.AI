// =============================================================================
// Formal harness: sf_meridian_fabric, 2 masters x 2 targets, tiny widths (AW 6, DW 16, TAGW 1, DOMW 2), MAXO = 1.
// Routing / protection safety through the WHOLE fabric (master port, Citadel reference, crosspoint buffers, arbiters,
// egress slices, response steering), checked against an INDEPENDENT shadow model written in this file:
//   R1 authorization   a request reaches a target only if the shadow oracle (domain binding, decode, reachability, policy)
//                      said "forward" for that master when it was accepted -- a denied request never reaches a target
//   R2 routing         it reaches exactly the decoded target
//   R3 identity        t_req_src, tag, domain, privilege, class, opcode, address, data and strobes equal the accepted request
//                      of that source: nothing is changed, lost or mixed up between masters
//   R4 once            a request reaches a target at most once; a master has at most one accepted, undelivered transaction
//   R5 responses       a response is presented to master m only while m has an outstanding transaction, with m's own tag,
//                      domain and opcode; locally answered requests get exactly the oracle's error status; forwarded requests
//                      never get DECERR / DENIED
//   R6 (ADV = 0, targets obey their contract) a response with status OKAY / SLVERR is presented only after the request
//                      reached the target (no response out of thin air)
// ADV = 1 gives NO assumptions about the targets at all: any response at any time.  Only the RESPONSE-side properties (R4 one outstanding,
// R5) are asserted then: an early or duplicated response from a faulty target legitimately completes a transaction while its request is still in
// flight, so request-side identity (R1-R3) is a property of targets that obey their contract (ADV = 0), exactly as 02_PROTOCOL.md states.
// TMO > 0: a timed-out transaction is delivered ST_TIMEOUT while its request may still be in flight (it may even be performed later): the shadow
// keeps it BUSY (`zombie`) until the target's late response, and the DUT must not accept a new request in the meantime (R4).
// Policy programming (pol_*) is free: any table at any time; the shadow table sees the same writes.
// Parameters: ADV, TSL (egress slice stages beyond the mandatory one), TMO.
// =============================================================================
module fv_fabric #(parameter int ADV = 0, parameter int TSL = 0, parameter int TMO = 0) (
  input logic        clk,
  input logic [1:0]  m_req_valid,
  input logic [3:0]  m_req_op,
  input logic [1:0]  m_req_tag,
  input logic [3:0]  m_req_dom,
  input logic [1:0]  m_req_priv,
  input logic [5:0]  m_req_tc,
  input logic [11:0] m_req_addr,
  input logic [31:0] m_req_wdata,
  input logic [3:0]  m_req_wstrb,
  input logic [1:0]  m_rsp_ready,
  input logic [1:0]  t_req_ready,
  input logic [1:0]  t_rsp_valid,
  input logic [1:0]  t_rsp_src,
  input logic [1:0]  t_rsp_tag,
  input logic [3:0]  t_rsp_dom,
  input logic [3:0]  t_rsp_op,
  input logic [5:0]  t_rsp_status,
  input logic [31:0] t_rsp_rdata,
  input logic        pol_we,
  input logic        pol_idx,
  input logic        pol_valid,
  input logic [1:0]  pol_src,
  input logic [3:0]  pol_dom,
  input logic        pol_priv,
  input logic [5:0]  pol_base,
  input logic [5:0]  pol_mask,
  input logic        pol_rd,
  input logic        pol_wr
);
  // ---- configuration (kept in the harness so the oracle is independent of the RTL)
  localparam int NM = 2, NT = 2, AW = 6, DW = 16, TAGW = 1, DOMW = 2;
  localparam logic [NT*AW-1:0] BASE = {6'h20, 6'h00};          // T0: addr[5:4] == 00, T1: addr[5:4] == 10  (01 / 11 unmapped)
  localparam logic [NT*AW-1:0] MASK = {6'h30, 6'h30};
  localparam logic [NM*4-1:0]  DOMALLOW = {4'b1100, 4'b0011};  // M0: domains 0,1   M1: domains 2,3
  localparam logic [NM*NT-1:0] CONN = 4'b1101;                 // bit m*NT + t: M0 -> T0 only; M1 -> T0 and T1

  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  // ---- DUT
  logic [1:0]  m_req_ready, m_rsp_valid, t_req_valid, t_req_src, t_req_priv, t_rsp_ready;
  logic [3:0]  m_rsp_op, t_req_op;
  logic [1:0]  m_rsp_tag, t_req_tag;
  logic [3:0]  m_rsp_dom, t_req_dom;
  logic [5:0]  m_rsp_status, t_req_tc;
  logic [31:0] m_rsp_rdata, t_req_wdata;
  logic [11:0] t_req_addr;
  logic [3:0]  t_req_wstrb;
  logic [1:0]  cit_req_valid, cit_req_priv, cit_req_write, o_cit_orphan;
  logic [3:0]  cit_req_dom;
  logic [11:0] cit_req_addr;
  logic [3:0]  o_iso;
  logic        elog_valid, evt_err, evt_sec;
  logic        elog_src;
  logic [2:0]  elog_status;
  logic [3:0]  elog_fault;
  logic [5:0]  elog_addr;
  logic [1:0]  elog_dom;
  logic        elog_tag, elog_tgt;
  logic [7:0]  elog_count, perf_data;
  logic [$clog2(sf_meridian_pkg::pf_n(2, 2))-1:0] perf_sel;
  assign perf_sel = '0;

  sf_meridian_fabric #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW),
    .TGT_BASE(BASE), .TGT_MASK(MASK), .CONN(CONN), .REQ_DEPTH(2),
    .MST_MAXO(16'h0101), .MST_OOO(2'b00), .MST_DOM_ALLOW(DOMALLOW),
    .MST_SLICE(8'h00), .TGT_SLICE(TSL == 0 ? 8'h00 : 8'h11), .ARB_MODE(1), .STARVE(2),
    .CITADEL_MODE(1), .CIT_NENT(2), .CIT_LAT(0), .CHK_TMO(8), .TMO(TMO), .ISOLATE(0), .CW(8)
  ) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_op, .m_req_tag, .m_req_dom, .m_req_priv, .m_req_tc, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_tag, .m_rsp_dom, .m_rsp_op, .m_rsp_status, .m_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_src, .t_req_op, .t_req_tag, .t_req_dom, .t_req_priv, .t_req_tc, .t_req_addr, .t_req_wdata, .t_req_wstrb,
    .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_tag, .t_rsp_dom, .t_rsp_op, .t_rsp_status, .t_rsp_rdata,
    .cit_req_valid, .cit_req_ready(2'b11), .cit_req_dom, .cit_req_priv, .cit_req_write, .cit_req_addr,
    .cit_rsp_valid(2'b00), .cit_rsp_ok(2'b00), .cit_rsp_fault(8'h00),
    .pol_we, .pol_idx, .pol_valid, .pol_src, .pol_dom, .pol_priv, .pol_base, .pol_mask, .pol_rd, .pol_wr, .tst_cit_stall(2'b00),
    .iso_clear(2'b00), .zomb_flush(1'b0), .o_iso, .o_cit_orphan,
    .elog_clear(1'b0), .elog_valid, .elog_src, .elog_status, .elog_fault, .elog_addr, .elog_dom, .elog_tag, .elog_tgt, .elog_count,
    .evt_err, .evt_sec, .perf_clear(1'b0), .perf_freeze(1'b0), .perf_sel, .perf_data);

`ifdef FORMAL
  // ---------------------------------------------------------------- environment assumptions
  logic past_ok = 1'b0;
  always_ff @(posedge clk) past_ok <= 1'b1;
  logic [1:0]  p_mv, p_mr;  logic [3:0] p_mop, p_mdom; logic [1:0] p_mtag, p_mpriv; logic [5:0] p_mtc; logic [11:0] p_maddr; logic [31:0] p_mwd; logic [3:0] p_mws;
  always_ff @(posedge clk) begin
    p_mv <= m_req_valid; p_mr <= m_req_ready; p_mop <= m_req_op; p_mdom <= m_req_dom; p_mtag <= m_req_tag; p_mpriv <= m_req_priv;
    p_mtc <= m_req_tc; p_maddr <= m_req_addr; p_mwd <= m_req_wdata; p_mws <= m_req_wstrb;
  end
  // masters hold a request, unchanged, until it is accepted
  always_comb if (past_ok && rst_n) begin
    for (int m = 0; m < NM; m++) if (p_mv[m] && !p_mr[m]) begin
      assume (m_req_valid[m]);
      assume (m_req_op[m*2 +: 2] == p_mop[m*2 +: 2] && m_req_dom[m*2 +: 2] == p_mdom[m*2 +: 2] && m_req_tag[m] == p_mtag[m] &&
              m_req_priv[m] == p_mpriv[m] && m_req_tc[m*3 +: 3] == p_mtc[m*3 +: 3] && m_req_addr[m*6 +: 6] == p_maddr[m*6 +: 6] &&
              m_req_wdata[m*16 +: 16] == p_mwd[m*16 +: 16] && m_req_wstrb[m*2 +: 2] == p_mws[m*2 +: 2]);
    end
  end

  // ---------------------------------------------------------------- shadow policy table (independent copy)
  logic [1:0] sp_v, sp_priv, sp_rd, sp_wr;
  logic [3:0] sp_src;                       // [e*2 + m]
  logic [7:0] sp_dom;                       // [e*4 + d]
  logic [11:0] sp_base, sp_mask;
  initial begin sp_v = '0; sp_priv = '0; sp_rd = '0; sp_wr = '0; sp_src = '0; sp_dom = '0; sp_base = '0; sp_mask = '0; end
  always_ff @(posedge clk) begin
    if (!rst_n) begin sp_v <= '0; sp_priv <= '0; sp_rd <= '0; sp_wr <= '0; sp_src <= '0; sp_dom <= '0; sp_base <= '0; sp_mask <= '0; end
    else if (pol_we) begin
      sp_v[pol_idx] <= pol_valid; sp_priv[pol_idx] <= pol_priv; sp_rd[pol_idx] <= pol_rd; sp_wr[pol_idx] <= pol_wr;
      sp_src[pol_idx*2 +: 2] <= pol_src; sp_dom[pol_idx*4 +: 4] <= pol_dom;
      sp_base[pol_idx*6 +: 6] <= pol_base; sp_mask[pol_idx*6 +: 6] <= pol_mask;
    end
  end
  function automatic logic permitted(input int m, input logic [1:0] dom, input logic priv, input logic wr, input logic [5:0] a);
    logic ok;
    ok = 1'b0;
    for (int e = 0; e < 2; e++)
      if (sp_v[e] && ((a & sp_mask[e*6 +: 6]) == sp_base[e*6 +: 6]) && sp_src[e*2 + m] && sp_dom[e*4 + int'(dom)] &&
          (!sp_priv[e] || priv) && (wr ? sp_wr[e] : sp_rd[e])) ok = 1'b1;
    permitted = ok;
  endfunction

  // ---------------------------------------------------------------- shadow transactions (one per master)
  logic [1:0]  sh_v, sh_fwd, sh_at, sh_tgt, sh_z;
  logic [5:0]  sh_st;
  logic [3:0]  sh_op, sh_dom;
  logic [1:0]  sh_tag, sh_priv;
  logic [5:0]  sh_tc;
  logic [11:0] sh_addr;
  logic [31:0] sh_wd;
  logic [3:0]  sh_ws;
  initial begin sh_v = '0; sh_fwd = '0; sh_at = '0; sh_tgt = '0; sh_st = '0; sh_z = '0; end
  wire [1:0] sh_busy = sh_v | sh_z;               // outstanding, or timed out but still in flight

  logic [1:0] oc_fwd, oc_tgt;                // oracle for the request presented by each master
  logic [5:0] oc_st;
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      logic [1:0] op, dm; logic [5:0] a; logic hit; int tg;
      op = m_req_op[m*2 +: 2]; dm = m_req_dom[m*2 +: 2]; a = m_req_addr[m*6 +: 6];
      hit = 1'b0; tg = 0;
      for (int t = NT - 1; t >= 0; t--) if ((a & MASK[t*AW +: AW]) == BASE[t*AW +: AW]) begin hit = 1'b1; tg = t; end
      oc_fwd[m] = 1'b0; oc_tgt[m] = (tg == 1); oc_st[m*3 +: 3] = sf_meridian_pkg::ST_OKAY;
      if (op[1])                                oc_st[m*3 +: 3] = sf_meridian_pkg::ST_PROTO;
      else if (a[0])                            oc_st[m*3 +: 3] = sf_meridian_pkg::ST_PROTO;      // DW = 16: addr[0] misaligned
      else if (!DOMALLOW[m*4 + int'(dm)])       oc_st[m*3 +: 3] = sf_meridian_pkg::ST_DENIED;
      else if (!hit)                            oc_st[m*3 +: 3] = sf_meridian_pkg::ST_DECERR;
      else if (!CONN[m*NT + tg])                oc_st[m*3 +: 3] = sf_meridian_pkg::ST_DECERR;
      else if (!permitted(m, dm, m_req_priv[m], (op == sf_meridian_pkg::OP_WRITE), a)) oc_st[m*3 +: 3] = sf_meridian_pkg::ST_DENIED;
      else oc_fwd[m] = 1'b1;
    end
  end

  // targets' pending requests (contract assumptions, ADV = 0)
  logic [3:0] tp_v;                          // [t*2 + src]
  logic [3:0] tp_tag;
  logic [7:0] tp_dom;
  logic [7:0] tp_op;

  always_ff @(posedge clk) begin
    if (!rst_n) begin sh_v <= '0; sh_fwd <= '0; sh_at <= '0; sh_z <= '0; tp_v <= '0; end
    else begin
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && m_req_ready[m]) begin
          sh_v[m] <= 1'b1; sh_fwd[m] <= oc_fwd[m]; sh_tgt[m] <= oc_tgt[m]; sh_at[m] <= 1'b0;
          sh_st[m*3 +: 3] <= oc_st[m*3 +: 3];
          sh_op[m*2 +: 2] <= m_req_op[m*2 +: 2]; sh_dom[m*2 +: 2] <= m_req_dom[m*2 +: 2]; sh_tag[m] <= m_req_tag[m];
          sh_priv[m] <= m_req_priv[m]; sh_tc[m*3 +: 3] <= m_req_tc[m*3 +: 3]; sh_addr[m*6 +: 6] <= m_req_addr[m*6 +: 6];
          sh_wd[m*16 +: 16] <= m_req_wdata[m*16 +: 16]; sh_ws[m*2 +: 2] <= m_req_wstrb[m*2 +: 2];
        end
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          sh_v[m] <= 1'b0;
          if (TMO != 0 && sh_fwd[m] && m_rsp_status[m*3 +: 3] == sf_meridian_pkg::ST_TIMEOUT) sh_z[m] <= 1'b1;   // issued, timed out: still in flight
        end
      end
      for (int t = 0; t < NT; t++) begin
        if (t_req_valid[t] && t_req_ready[t]) begin
          sh_at[t_req_src[t]] <= 1'b1;
          tp_v[t*2 + int'(t_req_src[t])] <= 1'b1; tp_tag[t*2 + int'(t_req_src[t])] <= t_req_tag[t];
          tp_dom[t*4 + int'(t_req_src[t])*2 +: 2] <= t_req_dom[t*2 +: 2]; tp_op[t*4 + int'(t_req_src[t])*2 +: 2] <= t_req_op[t*2 +: 2];
        end
        if (t_rsp_valid[t] && t_rsp_ready[t] ) begin
          tp_v[t*2 + int'(t_rsp_src[t])] <= 1'b0;
          sh_z[t_rsp_src[t]] <= 1'b0;                                              // the late response reclaims the zombie
        end
      end
    end
  end

  // ---------------------------------------------------------------- target contract (ADV = 0)
  logic [1:0] p_rv; logic [1:0] p_rr; logic [1:0] p_rsrc, p_rtag; logic [3:0] p_rdom, p_rop; logic [5:0] p_rst;
  always_ff @(posedge clk) begin p_rv <= t_rsp_valid; p_rr <= t_rsp_ready; p_rsrc <= t_rsp_src; p_rtag <= t_rsp_tag; p_rdom <= t_rsp_dom; p_rop <= t_rsp_op; p_rst <= t_rsp_status; end
  always_comb if (past_ok && rst_n && ADV == 0) begin
    for (int t = 0; t < NT; t++) begin
      if (t_rsp_valid[t]) begin
        assume (tp_v[t*2 + int'(t_rsp_src[t])]);
        assume (t_rsp_tag[t] == tp_tag[t*2 + int'(t_rsp_src[t])]);
        assume (t_rsp_dom[t*2 +: 2] == tp_dom[t*4 + int'(t_rsp_src[t])*2 +: 2]);
        assume (t_rsp_op[t*2 +: 2] == tp_op[t*4 + int'(t_rsp_src[t])*2 +: 2]);
        assume (t_rsp_status[t*3 +: 3] <= sf_meridian_pkg::ST_SLVERR);
      end
      if (p_rv[t] && !p_rr[t]) assume (t_rsp_valid[t] && t_rsp_src[t] == p_rsrc[t] && t_rsp_tag[t] == p_rtag[t]);
    end
  end

  // ---------------------------------------------------------------- assertions
  generate
    for (genvar t = 0; t < NT; t++) begin : g_t
      wire sidx = t_req_src[t];
      always_comb if (rst_n && ADV == 0 && t_req_valid[t]) begin
        assert (sh_busy[sidx]);                                                                  // R4 / R3
        assert (sh_fwd[sidx]);                                                                // R1 authorization
        assert (sh_tgt[sidx] == (t == 1));                                                    // R2 routing
        assert (t_req_op[t*2 +: 2] == sh_op[sidx*2 +: 2]);                                    // R3 identity
        assert (t_req_dom[t*2 +: 2] == sh_dom[sidx*2 +: 2]);
        assert (t_req_tag[t] == sh_tag[sidx]);
        assert (t_req_priv[t] == sh_priv[sidx]);
        assert (t_req_tc[t*3 +: 3] == sh_tc[sidx*3 +: 3]);
        assert (t_req_addr[t*6 +: 6] == sh_addr[sidx*6 +: 6]);
        assert (t_req_wdata[t*16 +: 16] == sh_wd[sidx*16 +: 16]);
        assert (t_req_wstrb[t*2 +: 2] == sh_ws[sidx*2 +: 2]);
        if (t_req_ready[t]) assert (!sh_at[sidx]);                                            // R4 once
      end
    end
    for (genvar m = 0; m < NM; m++) begin : g_m
      always_comb if (rst_n) begin
        if (m_req_valid[m] && m_req_ready[m]) assert (!sh_busy[m]);                           // R4 one outstanding (a zombie holds the slot)
        if (m_rsp_valid[m]) begin
          assert (sh_v[m]);                                                                   // R5
          assert (m_rsp_tag[m] == sh_tag[m]);
          assert (m_rsp_dom[m*2 +: 2] == sh_dom[m*2 +: 2]);
          assert (m_rsp_op[m*2 +: 2] == sh_op[m*2 +: 2]);
          if (!sh_fwd[m]) assert (m_rsp_status[m*3 +: 3] == sh_st[m*3 +: 3]);
          else begin
            assert (m_rsp_status[m*3 +: 3] != sf_meridian_pkg::ST_DECERR);
            assert (m_rsp_status[m*3 +: 3] != sf_meridian_pkg::ST_DENIED);
            if (TMO == 0 && ADV == 0) assert (sh_at[m]);                                      // R6
          end
        end
      end
    end
  endgenerate

  // ---------------------------------------------------------------- reachability: the checked depth really exercises transactions
  always_comb if (rst_n) begin
    cover (m_rsp_valid[0] && m_rsp_ready[0] && sh_fwd[0] && m_rsp_status[2:0] == sf_meridian_pkg::ST_OKAY);   // a permitted transaction of M0 completes
    cover (m_rsp_valid[1] && m_rsp_ready[1] && sh_fwd[1] && m_rsp_status[5:3] == sf_meridian_pkg::ST_OKAY);   // ... of M1
    cover (m_rsp_valid[1] && m_rsp_ready[1] && !sh_fwd[1] && m_rsp_status[5:3] == sf_meridian_pkg::ST_DENIED); // a denial is delivered
    cover (m_rsp_valid[0] && m_rsp_ready[0] && !sh_fwd[0] && m_rsp_status[2:0] == sf_meridian_pkg::ST_DECERR); // a decode error is delivered
    cover (t_req_valid[1] && t_req_ready[1]);                                                               // a request is accepted by target 1
  end
`endif
endmodule
