// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: tb_arb_diff -- arbiter differential and property test
//
// 1. DIFFERENTIAL: sf_meridian_arbiter (new structure) against the verified sfn_qos_arbiter (Project 22, vendored
//    unmodified, grant lock disabled with stall = 0) under random requests, random class levels and random
//    downstream `en`.  grant / index / valid / urgent must agree in EVERY cycle.  ARB_RR is compared against
//    sfn_qos_arbiter with STARVE = 0 (everyone urgent at once = plain round robin).
// 2. PROPERTIES (independent of both): grant is one-hot or zero; granted requester is requesting; a request exists
//    iff gvalid (work conserving); starvation bound -- a requester that keeps requesting waits at most
//    STARVE + N - 1 transfers of others (ARB_QOS) or N - 1 (ARB_RR); the bound is reached in some run (tightness).
// Parameters: N, MODE (0 RR, 1 QOS), STARVE, NCYC.  Prints RESULT: PASS|FAIL.
// =============================================================================
`timescale 1ns/1ps

module tb_arb_diff #(
  parameter int N      = 4,
  parameter int MODE   = 1,
  parameter int STARVE = 4,
  parameter int NCYC   = 400000
);
  localparam int IW = sf_meridian_pkg::clog2c(N);

  logic clk = 0;
  always #5 clk = ~clk;
  logic rst_n = 0;

  logic [N-1:0]   req;
  logic [N*3-1:0] lvl;
  logic           en;

  logic [N-1:0]   g_a, g_b, u_a, u_b;
  logic [IW-1:0]  i_a, i_b;
  logic           v_a, v_b;

  sf_meridian_arbiter #(.N(N), .MODE(MODE), .STARVE(STARVE)) dut (
    .clk, .rst_n, .req, .lvl, .en, .grant(g_a), .gidx(i_a), .gvalid(v_a), .urgent(u_a));

  sfn_qos_arbiter #(.N(N), .STARVE((MODE == 0) ? 0 : STARVE)) ref_arb (
    .clk, .rst_n, .req, .qos(lvl), .stall(1'b0), .accept(en), .grant(g_b), .grant_idx(i_b), .grant_valid(v_b), .urgent(u_b));

  int unsigned rs = 32'hC0FFEE11;
  function automatic int unsigned rnd();
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5);
    return rs;
  endfunction

  int n_chk = 0, n_fail = 0, bound, wait_max = 0;
  int waitc [N];

  // random environment with phases: sparse, dense, always-on, all-same-class, en mostly low
  int phase = 0, phase_len = 0;
  int p_req, p_en, lvl_mode;

  always @(posedge clk) begin
    // ---------------- checks on the values of the cycle that is ending
    if (rst_n) begin
      n_chk++;
      if (g_a !== g_b || (v_a && i_a !== i_b) || v_a !== v_b || (MODE != 0 && u_a !== u_b)) begin   // `urgent` is an observability output of QOS mode only   // the index is a don't-care when nothing is granted
        n_fail++;
        if (n_fail < 10) $display("  FAIL diff @%0t grant %b/%b idx %0d/%0d valid %b/%b urgent %b/%b req %b", $time, g_a, g_b, i_a, i_b, v_a, v_b, u_a, u_b, req);
      end
      if ($countones(g_a) > 1 || (g_a & ~req) != '0 || (v_a != (req != '0)) || (v_a != (g_a != '0))) begin
        n_fail++;
        if (n_fail < 10) $display("  FAIL property @%0t grant %b req %b valid %b", $time, g_a, req, v_a);
      end
      // starvation bound (a transfer happens when valid && en)
      for (int i = 0; i < N; i++) begin
        if (!req[i]) waitc[i] = 0;
        else if (v_a && en && g_a[i]) waitc[i] = 0;
        else if (v_a && en) begin
          waitc[i]++;
          if (waitc[i] > wait_max) wait_max = waitc[i];
          if (waitc[i] > bound) begin
            n_fail++;
            if (n_fail < 10) $display("  FAIL starvation @%0t requester %0d waited %0d transfers (bound %0d)", $time, i, waitc[i], bound);
          end
        end
      end
    end
    // ---------------- next stimulus
    if (phase_len == 0) begin
      phase     = int'(rnd() % 6);
      phase_len = 50 + int'(rnd() % 400);
      case (phase)
        0: begin p_req = 20; p_en = 100; lvl_mode = 0; end
        1: begin p_req = 100; p_en = 100; lvl_mode = 0; end
        2: begin p_req = 100; p_en = 40; lvl_mode = 1; end
        3: begin p_req = 70; p_en = 70; lvl_mode = 0; end
        4: begin p_req = 100; p_en = 100; lvl_mode = 2; end
        default: begin p_req = 90; p_en = 25; lvl_mode = 0; end
      endcase
    end
    phase_len--;
    for (int i = 0; i < N; i++) begin
      // a request, once raised, is held until served (as the crosspoint buffers do) in the dense phases; random otherwise
      if (!(req[i] && !(v_a && en && g_a[i]) && (p_req >= 70))) req[i] <= (int'(rnd() % 100) < p_req);
      case (lvl_mode)
        0: lvl[i*3 +: 3] <= 3'(rnd());
        1: lvl[i*3 +: 3] <= 3'(i % 5);
        default: lvl[i*3 +: 3] <= 3'd2;
      endcase
    end
    en <= (int'(rnd() % 100) < p_en);
  end

  initial begin
    bound = (MODE == 0) ? N - 1 : STARVE + N - 1;
    req = '0; lvl = '0; en = 1'b0;
    for (int i = 0; i < N; i++) waitc[i] = 0;
    repeat (4) @(posedge clk);
    rst_n = 1;
    repeat (NCYC) @(posedge clk);
    $display("tb_arb_diff N=%0d MODE=%0d STARVE=%0d: %0d cycles compared, longest wait %0d (bound %0d)", N, MODE, STARVE, n_chk, wait_max, bound);
    if (n_fail == 0 && (wait_max > 0 || N == 1)) $display("RESULT: PASS"); else $display("RESULT: FAIL");
    $finish;
  end
endmodule
