// Formal harness: sf_meridian_arbiter.  Inputs are free (any request pattern, any class, any downstream `en`).
//   A1 grant is one-hot or zero, and only to a requester      A2 work conserving: gvalid <=> some request
//   A3 starvation bound: a requester that keeps requesting is served after at most BOUND transfers of others
//      (BOUND = STARVE + N - 1 for ARB_QOS, N - 1 for ARB_RR);  shadow counters watch each requester
//   A4 (QOS) the aging counters never exceed STARVE
module fv_arbiter #(parameter int N = 3, parameter int MODE = 1, parameter int STARVE = 2) (
  input logic           clk,
  input logic [N-1:0]   req,
  input logic [N*3-1:0] lvl,
  input logic           en
);
  localparam int IW = sf_meridian_pkg::clog2c(N);
  localparam int BOUND = (MODE == 0) ? N - 1 : STARVE + N - 1;
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;
  logic [N-1:0] grant, urgent;
  logic [IW-1:0] gidx;
  logic gvalid;
  sf_meridian_arbiter #(.N(N), .MODE(MODE), .STARVE(STARVE)) dut (.clk, .rst_n, .req, .lvl, .en, .grant, .gidx, .gvalid, .urgent);
`ifdef FORMAL
  wire xfer = gvalid && en;
  logic [4:0] w [N];
  initial for (int i = 0; i < N; i++) w[i] = '0;
  always_ff @(posedge clk) begin
    for (int i = 0; i < N; i++) begin
      if (!rst_n || !req[i] || (xfer && grant[i])) w[i] <= '0;
      else if (xfer) w[i] <= w[i] + 5'd1;
    end
  end
  always_comb if (rst_n) begin
    assert ((grant & (grant - 1'b1)) == '0);                                // A1 one-hot or zero
    assert ((grant & ~req) == '0);
    assert (gvalid == (req != '0));                                         // A2
    assert (gvalid == (grant != '0));
    for (int i = 0; i < N; i++) assert (w[i] <= 5'(BOUND));                 // A3
  end
`endif
endmodule
