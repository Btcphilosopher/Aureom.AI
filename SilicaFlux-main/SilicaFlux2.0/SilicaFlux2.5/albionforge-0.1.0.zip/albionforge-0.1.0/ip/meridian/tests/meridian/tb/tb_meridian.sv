// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: tb_meridian -- self-checking system testbench
//
// One parameterised bench for every configuration (the runner passes the same parameters to the bench and, through it,
// to the DUT).  Independent of the RTL:
//   * ORACLE        a second, structurally different implementation of the decode / domain-binding / Citadel policy
//                   rules decides at the moment a request is accepted what must happen to it;
//   * SCOREBOARD    every accepted request is recorded by (master, tag); the target models check every request they
//                   receive field by field against that record (identity, domain, class, payload, source stamp,
//                   per-(master,target) order) and that the oracle allowed it; the response collectors check every
//                   delivered response (tag, domain echo, opcode, status, read data, in-order delivery, no duplicate);
//   * TARGET MODELS memories with latency, back-pressure, in-order or reordering responses, SLVERR, dead / stalled
//                   endpoints, duplicate / corrupted / mis-sourced responses;
//   * MONITORS      valid/ready stability on the DUT outputs, token conservation, arbitration-bound monitor on the crossbar,
//                   counter mirror (every performance counter that can be mirrored is compared exactly).
// Tests are selected with +tests=a,b,c (default: all that apply); +seed=N changes every random decision.
// Results: one line per test and "RESULT: PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps

`define CHK(c, msg) do begin n_chk = n_chk + 1; if (!(c)) fail(msg); end while (0)

module tb_meridian #(
  parameter int                          NM            = 2,
  parameter int                          NT            = 2,
  parameter int                          AW            = 32,
  parameter int                          DW            = 64,
  parameter int                          TAGW          = 4,
  parameter int                          DOMW          = 3,
  parameter logic [NM*8-1:0]             MST_MAXO      = {NM{8'd1}},
  parameter logic [NM-1:0]               MST_OOO       = {NM{1'b0}},
  parameter logic [NM*NT-1:0]            CONN          = {(NM*NT){1'b1}},
  parameter logic [NM*NT-1:0]            PERM          = {(NM*NT){1'b1}},     // Citadel policy: master m may use target t
  parameter logic [NM*4-1:0]             MST_SLICE     = {(NM*4){1'b0}},
  parameter logic [NT*4-1:0]             TGT_SLICE     = {(NT*4){1'b0}},
  parameter int                          REQ_DEPTH     = 2,
  parameter int                          ARB_MODE      = 1,
  parameter int                          STARVE        = 8,
  parameter int                          CITADEL_MODE  = 1,
  parameter int                          CIT_LAT       = 0,
  parameter int                          CHK_TMO       = 24,
  parameter int                          TMO           = 0,
  parameter int                          ISOLATE       = 1,
  parameter int                          CW            = 32
);
  import sf_meridian_pkg::*;

  localparam int NDOM  = 1 << DOMW;
  localparam int NTAG  = 1 << TAGW;
  localparam int OFF   = $clog2(DW / 8);
  localparam int RWIN  = 28;
  localparam int SRCW  = clog2c(NM);
  localparam int TW    = clog2c(NT);
  localparam int BW    = clog2c(DW / 8 + 1);
  localparam int NCNT  = pf_n(NM, NT);
  localparam int RSW   = clog2c(NCNT);
  localparam int CITN  = 3 * NT;
  localparam int CITIW = clog2c(CITN);

  // ---------------------------------------------------------------- configuration derived inside the bench
  function automatic logic [NT*AW-1:0] mk_base();
    logic [NT*AW-1:0] v;
    v = '0;
    for (int t = 0; t < NT; t++) v[t*AW +: AW] = AW'(t) << RWIN;
    return v;
  endfunction
  function automatic logic [NT*AW-1:0] mk_mask();
    logic [NT*AW-1:0] v;
    v = '0;
    for (int t = 0; t < NT; t++) v[t*AW +: AW] = ~((AW'(1) << RWIN) - AW'(1));
    return v;
  endfunction
  // domains bound to master m: its own (m % 4), plus 4 and 5 (bound everywhere, never granted by the policy)
  function automatic logic [NM*NDOM-1:0] mk_domallow();
    logic [NM*NDOM-1:0] v;
    v = '0;
    for (int m = 0; m < NM; m++) begin
      v[m*NDOM + (m % 4)] = 1'b1;
      v[m*NDOM + 4]       = 1'b1;
      v[m*NDOM + 5]       = 1'b1;
    end
    return v;
  endfunction
  localparam logic [NT*AW-1:0]        TGT_BASE      = mk_base();
  localparam logic [NT*AW-1:0]        TGT_MASK      = mk_mask();
  localparam logic [NM*NDOM-1:0]      MST_DOM_ALLOW = mk_domallow();

  // ---------------------------------------------------------------- clock / DUT
  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n = 1'b0;

  logic [NM-1:0]      m_req_valid, m_req_ready;
  logic [NM*2-1:0]    m_req_op;
  logic [NM*TAGW-1:0] m_req_tag;
  logic [NM*DOMW-1:0] m_req_dom;
  logic [NM-1:0]      m_req_priv;
  logic [NM*3-1:0]    m_req_tc;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata;
  logic [NM*DW/8-1:0] m_req_wstrb;
  logic [NM-1:0]      m_rsp_valid, m_rsp_ready;
  logic [NM*TAGW-1:0] m_rsp_tag;
  logic [NM*DOMW-1:0] m_rsp_dom;
  logic [NM*2-1:0]    m_rsp_op;
  logic [NM*3-1:0]    m_rsp_status;
  logic [NM*DW-1:0]   m_rsp_rdata;
  logic [NT-1:0]      t_req_valid, t_req_ready;
  logic [NT*SRCW-1:0] t_req_src;
  logic [NT*2-1:0]    t_req_op;
  logic [NT*TAGW-1:0] t_req_tag;
  logic [NT*DOMW-1:0] t_req_dom;
  logic [NT-1:0]      t_req_priv;
  logic [NT*3-1:0]    t_req_tc;
  logic [NT*AW-1:0]   t_req_addr;
  logic [NT*DW-1:0]   t_req_wdata;
  logic [NT*DW/8-1:0] t_req_wstrb;
  logic [NT-1:0]      t_rsp_valid, t_rsp_ready;
  logic [NT*SRCW-1:0] t_rsp_src;
  logic [NT*TAGW-1:0] t_rsp_tag;
  logic [NT*DOMW-1:0] t_rsp_dom;
  logic [NT*2-1:0]    t_rsp_op;
  logic [NT*3-1:0]    t_rsp_status;
  logic [NT*DW-1:0]   t_rsp_rdata;
  logic [NM-1:0]      cit_req_valid, cit_req_ready, cit_rsp_valid, cit_rsp_ok;
  logic [NM*DOMW-1:0] cit_req_dom;
  logic [NM-1:0]      cit_req_priv, cit_req_write;
  logic [NM*AW-1:0]   cit_req_addr;
  logic [NM*4-1:0]    cit_rsp_fault;
  logic               pol_we = 1'b0;
  logic [CITIW-1:0]   pol_idx = '0;
  logic               pol_valid = 1'b0;
  logic [NM-1:0]      pol_src = '0;
  logic [NDOM-1:0]    pol_dom = '0;
  logic               pol_priv = 1'b0;
  logic [AW-1:0]      pol_base = '0, pol_mask = '0;
  logic               pol_rd = 1'b0, pol_wr = 1'b0;
  logic [NM-1:0]      tst_cit_stall = '0;
  logic [NT-1:0]      iso_clear = '0;
  logic               zomb_flush = 1'b0;
  logic [NM*NT-1:0]   o_iso;
  logic [NM-1:0]      o_cit_orphan;
  logic               elog_clear = 1'b0;
  logic               elog_valid;
  logic [SRCW-1:0]    elog_src;
  logic [2:0]         elog_status;
  logic [3:0]         elog_fault;
  logic [AW-1:0]      elog_addr;
  logic [DOMW-1:0]    elog_dom;
  logic [TAGW-1:0]    elog_tag;
  logic [TW-1:0]      elog_tgt;
  logic [CW-1:0]      elog_count;
  logic               evt_err, evt_sec;
  logic               perf_clear = 1'b0, perf_freeze = 1'b0;
  logic [RSW-1:0]     perf_sel = '0;
  logic [CW-1:0]      perf_data;

  // the Citadel for CIT_EXT is a separate instance of the reference table, wired through the external ports
  generate
    if (CITADEL_MODE == 2) begin : g_ext
      sf_meridian_citadel_ref #(.NM(NM), .DOMW(DOMW), .AW(AW), .NENT(CITN), .LAT(CIT_LAT)) u_ext_cit (
        .clk, .rst_n, .pol_we, .pol_idx, .pol_valid, .pol_src, .pol_dom, .pol_priv, .pol_base, .pol_mask, .pol_rd, .pol_wr,
        .cit_req_valid, .cit_req_ready, .cit_req_dom, .cit_req_priv, .cit_req_write, .cit_req_addr,
        .cit_rsp_valid, .cit_rsp_ok, .cit_rsp_fault, .tst_stall(tst_cit_stall));
    end else begin : g_noext
      assign cit_req_ready = '0;
      assign cit_rsp_valid = '0;
      assign cit_rsp_ok    = '0;
      assign cit_rsp_fault = '0;
    end
  endgenerate

  sf_meridian_fabric #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW),
    .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .CONN(CONN), .REQ_DEPTH(REQ_DEPTH),
    .MST_MAXO(MST_MAXO), .MST_OOO(MST_OOO), .MST_DOM_ALLOW(MST_DOM_ALLOW),
    .MST_SLICE(MST_SLICE), .TGT_SLICE(TGT_SLICE), .ARB_MODE(ARB_MODE), .STARVE(STARVE),
    .CITADEL_MODE(CITADEL_MODE), .CIT_NENT(CITN), .CIT_LAT(CIT_LAT), .CHK_TMO(CHK_TMO),
    .TMO(TMO), .ISOLATE(ISOLATE), .CW(CW)
  ) dut (.*);

  // per-port pending count probed from the DUT (generate-block references need constant indices)
  logic [7:0] dut_pend [NM];
  generate
    for (genvar gm = 0; gm < NM; gm++) begin : g_probe
      assign dut_pend[gm] = 8'(dut.g_mp[gm].o_pend_m);
    end
  endgenerate

  // ---------------------------------------------------------------- bookkeeping
  int unsigned cyc = 0;
  int          n_chk = 0, n_fail = 0, n_tests = 0, n_tests_fail = 0;
  int          fail_at_test_start = 0;
  string       cur_test = "";
  int unsigned rs = 32'h1234_5678;

  function automatic int unsigned rnd();
    rs = rs ^ (rs << 13);
    rs = rs ^ (rs >> 17);
    rs = rs ^ (rs << 5);
    return rs;
  endfunction
  function automatic int rr(input int n);
    return (n <= 1) ? 0 : int'(rnd() % unsigned'(n));
  endfunction
  function automatic bit pct(input int p);
    return (p >= 100) ? 1'b1 : (p <= 0) ? 1'b0 : (int'(rnd() % 100) < p);
  endfunction
  function automatic logic [DW-1:0] rnd_data();
    logic [DW-1:0] d;
    d = '0;
    for (int k = 0; k < DW; k += 32) d = d | (DW'(rnd()) << k);
    return d;
  endfunction

  task automatic fail(input string msg);
    n_fail = n_fail + 1;
    if (n_fail <= 25) $display("  FAIL @%0d [%s] %s", cyc, cur_test, msg);
  endtask

  // ---------------------------------------------------------------- transaction descriptors
  typedef struct {
    logic [1:0]        op;
    logic [TAGW-1:0]   tag;
    bit                tagfix;
    logic [DOMW-1:0]   dom;
    logic              priv;
    logic [2:0]        tc;
    logic [AW-1:0]     addr;
    logic [DW-1:0]     wdata;
    logic [DW/8-1:0]   wstrb;
    bit                rdchk;
    logic [DW-1:0]     rdexp;
    bit                ovr;        // expectation override: answered locally with ovr_st
    logic [2:0]        ovr_st;
  } rq_t;

  typedef struct {
    logic [SRCW-1:0]   src;
    logic [TAGW-1:0]   tag;
    logic [DOMW-1:0]   dom;
    logic [1:0]        op;
    logic [2:0]        status;
    logic [DW-1:0]     rdata;
    longint unsigned   due;
    bit                dup;        // a duplicate copy follows immediately (back to back)
    bit                is_dup;
  } rsp_t;

  // Queues are explicit circular buffers: Verilator 5.49 mishandles arrays of queues of structs
  // (wrong element and wrong size after a pop -- see docs/meridian/07_VERIFICATION.md).
  localparam int QD  = 4096;      // per-master request queue
  localparam int OQD = 64;        // per-master order queue (>= NTAG)
  localparam int TQD = 1024;      // per-target response queue
  rq_t   mqb [NM*QD];
  int    mq_h [NM];
  int    mq_n [NM];
  rq_t   cur  [NM];
  bit    cur_v[NM];
  int    oqb [NM*OQD];
  int    oq_h [NM];
  int    oq_n [NM];
  rsp_t  tqb [NT*TQD];
  int    tq_h [NT];
  int    tq_n [NT];
  rsp_t  trsp [NT];
  bit    trsp_v[NT];
  bit    dup_next[NT];
  rsp_t  dup_copy[NT];

  // expectation records, index m*NTAG + tag
  bit                e_v      [NM*NTAG];
  bit                e_fwd    [NM*NTAG];
  logic [2:0]        e_status [NM*NTAG];
  logic [3:0]        e_fault  [NM*NTAG];
  int                e_tgt    [NM*NTAG];
  logic [1:0]        e_op     [NM*NTAG];
  logic [DOMW-1:0]   e_dom    [NM*NTAG];
  bit                e_priv   [NM*NTAG];
  logic [2:0]        e_tc     [NM*NTAG];
  logic [AW-1:0]     e_addr   [NM*NTAG];
  logic [DW-1:0]     e_wdata  [NM*NTAG];
  logic [DW/8-1:0]   e_wstrb  [NM*NTAG];
  longint            e_seq    [NM*NTAG];
  longint unsigned   e_acc    [NM*NTAG];
  bit                e_at_tgt [NM*NTAG];
  bit                e_tl_v   [NM*NTAG];
  logic [2:0]        e_tl_st  [NM*NTAG];
  logic [DW-1:0]     e_tl_rd  [NM*NTAG];
  bit                e_rdchk  [NM*NTAG];
  logic [DW-1:0]     e_rdexp  [NM*NTAG];
  bit                e_zomb   [NM*NTAG];     // timed out after issue: tag stays busy until the late response / flush
  bit                e_flushed[NM*NTAG];     // zombie reclaimed by zomb_flush: its late response will be an orphan
  longint unsigned   lat_ok_max [NM];
  longint unsigned   last_lat   [NM];
  longint unsigned   e_tcyc   [NM*NTAG];     // cycle the request reached its target
  longint unsigned   e_rcyc   [NM*NTAG];     // cycle the target's response was taken by the fabric
  longint unsigned   last_resp_path [NM];
  longint unsigned   req_path_last;
  longint unsigned   first_acc [NM];
  longint unsigned   last_dlv  [NM];
  longint            last_seq [NM][NT];
  longint            seq_ctr  [NM];
  int                pend     [NM];

  logic [DW-1:0]     tmem [logic [AW+7:0]];

  // ---- circular-buffer queues
  task automatic mq_push(input int m, input rq_t r);
    if (mq_n[m] >= QD) fail("bench request queue overflow");
    else begin mqb[m*QD + (mq_h[m] + mq_n[m]) % QD] = r; mq_n[m] = mq_n[m] + 1; end
  endtask
  function automatic rq_t mq_front(input int m);
    return mqb[m*QD + mq_h[m]];
  endfunction
  task automatic mq_pop(input int m);
    mq_h[m] = (mq_h[m] + 1) % QD; mq_n[m] = mq_n[m] - 1;
  endtask
  task automatic mq_clear(input int m);
    mq_h[m] = 0; mq_n[m] = 0;
  endtask
  task automatic oq_push(input int m, input int v);
    if (oq_n[m] >= OQD) fail("bench order queue overflow");
    else begin oqb[m*OQD + (oq_h[m] + oq_n[m]) % OQD] = v; oq_n[m] = oq_n[m] + 1; end
  endtask
  function automatic int oq_at(input int m, input int k);
    return oqb[m*OQD + (oq_h[m] + k) % OQD];
  endfunction
  task automatic oq_del(input int m, input int k);
    for (int j = k; j < oq_n[m] - 1; j++) oqb[m*OQD + (oq_h[m] + j) % OQD] = oqb[m*OQD + (oq_h[m] + j + 1) % OQD];
    oq_n[m] = oq_n[m] - 1;
  endtask
  task automatic oq_clear(input int m);
    oq_h[m] = 0; oq_n[m] = 0;
  endtask
  task automatic tq_push(input int t, input rsp_t r);
    if (tq_n[t] >= TQD) fail("bench response queue overflow");
    else begin tqb[t*TQD + (tq_h[t] + tq_n[t]) % TQD] = r; tq_n[t] = tq_n[t] + 1; end
  endtask
  function automatic rsp_t tq_at(input int t, input int k);
    return tqb[t*TQD + (tq_h[t] + k) % TQD];
  endfunction
  task automatic tq_del(input int t, input int k);
    for (int j = k; j < tq_n[t] - 1; j++) tqb[t*TQD + (tq_h[t] + j) % TQD] = tqb[t*TQD + (tq_h[t] + j + 1) % TQD];
    tq_n[t] = tq_n[t] - 1;
  endtask
  task automatic tq_clear(input int t);
    tq_h[t] = 0; tq_n[t] = 0;
  endtask


  // knobs (set by the tests)
  int  gap_pct   [NM];
  int  rrdy_pct  [NM];
  int  tready_pct[NT];
  int  tlat_min  [NT];
  int  tlat_max  [NT];
  bit  t_ooo     [NT];
  int  t_err_pct [NT];
  int  t_dead    [NT];      // 1: accepts, never responds
  bit  t_stall   [NT];      // 1: never ready
  int  t_dup_pct [NT];
  int  t_badecho_pct[NT];
  int  t_badsrc_pct [NT];
  bit  allow_tmo [NM];

  // performance-counter mirror
  longint unsigned mc [NM][PF_PM];
  longint unsigned tcn[NT][PF_PT];
  longint unsigned mx [NM][NT];
  longint unsigned gcn[PF_G];
  int              grants_by_src [NT][NM];   // requests delivered per (target, source) since the test start

  // per-class latency statistics (accept -> delivery)
  longint unsigned cls_n [8];
  longint unsigned cls_sum [8];
  longint unsigned cls_max [8];

  // arbitration bound monitor
  int  arb_wait [NM][NT];      // transfers of others seen while (m,t) buffer head waits
  int  arb_wait_max;
  int  arb_wait_hi = 0;          // longest wait seen in the whole run (never reset)
  int  arb_bound;
  longint unsigned total_acc, total_dlv, total_tx, total_rx_rsp;

  // previous-cycle snapshots for the stability monitors
  logic [NM-1:0]      p_rsp_v, p_rsp_r;
  logic [NM*TAGW-1:0] p_rsp_tag;
  logic [NM*3-1:0]    p_rsp_st;
  logic [NM*DW-1:0]   p_rsp_rd;
  logic [NT-1:0]      p_req_v, p_req_r;
  logic [NT*AW-1:0]   p_req_addr;
  logic [NT*DW-1:0]   p_req_wd;
  logic [NT*TAGW-1:0] p_req_tag;
  logic [NT*SRCW-1:0] p_req_src;

  bit  dbg = 1'b0;
  int  flush_req = 0;        // 0 none, 1 masters + counters only (fabric reset), 2 everything

  function automatic int popcnt(input logic [DW/8-1:0] v);
    int n;
    n = 0;
    for (int k = 0; k < DW / 8; k++) if (v[k]) n++;
    return n;
  endfunction

  // ---------------------------------------------------------------- the ORACLE
  // returns {tgt[15:8], fault[7:4], fwd[3], status[2:0]}
  function automatic logic [15:0] oracle(input int m, input logic [1:0] op, input logic [DOMW-1:0] dom,
                                         input logic priv, input logic [AW-1:0] addr);
    int tg;
    logic [1:0] reg2;
    logic [2:0] st;
    logic [3:0] fl;
    bit fwd;
    st = ST_OKAY; fl = F_NONE; fwd = 1'b0; tg = 0;
    if (op[1])                                   begin st = ST_PROTO;  fl = F_BADOP;    end
    else if (OFF > 0 && addr[OFF-1:0] != '0)     begin st = ST_PROTO;  fl = F_MISALIGN; end
    else if (!MST_DOM_ALLOW[m*NDOM + int'(dom)]) begin st = ST_DENIED; fl = F_SPOOF;    end
    else begin
      tg = -1;
      for (int t = NT - 1; t >= 0; t--)
        if ((addr & TGT_MASK[t*AW +: AW]) == TGT_BASE[t*AW +: AW]) tg = t;
      if (tg < 0)                        begin st = ST_DECERR; fl = F_UNMAPPED; tg = 0; end
      else if (!CONN[m*NT + tg])         begin st = ST_DECERR; fl = F_NOROUTE;          end
      else if (CITADEL_MODE != 0) begin
        reg2 = addr[RWIN-1 -: 2];
        if (!PERM[m*NT + tg] || int'(dom) >= 4) begin st = ST_DENIED; fl = F_DOMAIN; end
        else if (reg2 == 2'b10 && op == OP_WRITE) begin st = ST_DENIED; fl = F_PERM; end
        else if (reg2 == 2'b11 && !priv)          begin st = ST_DENIED; fl = F_PRIV; end
        else fwd = 1'b1;
      end else fwd = 1'b1;
    end
    return {8'(tg), fl, fwd, st};
  endfunction

  // ---------------------------------------------------------------- request construction helpers
  function automatic logic [AW-1:0] taddr(input int t, input int region, input int slot);
    return (AW'(t) << RWIN) | (AW'(region) << (RWIN - 2)) | (AW'(slot) << OFF);
  endfunction

  function automatic rq_t mkreq(input logic [1:0] op, input int dom, input bit priv, input int tc,
                                input logic [AW-1:0] addr, input logic [DW-1:0] wdata, input logic [DW/8-1:0] wstrb);
    rq_t r;
    r.op = op; r.tag = '0; r.tagfix = 1'b0; r.dom = DOMW'(dom); r.priv = priv; r.tc = 3'(tc);
    r.addr = addr; r.wdata = wdata; r.wstrb = wstrb; r.rdchk = 1'b0; r.rdexp = '0; r.ovr = 1'b0; r.ovr_st = '0;
    return r;
  endfunction

  // a random request of master m; pbad = percentage of deliberately faulty requests
  function automatic rq_t rand_req(input int m, input int pbad);
    rq_t r;
    int  t, kind, tries;
    bit  ok;
    int  mydom;
    mydom = m % 4;
    // choose a legal target (connected and permitted)
    t = -1; ok = 1'b0;
    for (tries = 0; tries < 16 && !ok; tries++) begin
      t = rr(NT);
      ok = CONN[m*NT + t] && (CITADEL_MODE == 0 || PERM[m*NT + t]);
    end
    r = mkreq(rr(2) == 0 ? OP_READ : OP_WRITE, mydom, pct(25), rr(5),
              ok ? taddr(t, rr(2), rr(32)) : taddr(0, 0, 0), rnd_data(), pct(70) ? '1 : DW/8'(rnd()));
    if (!ok) r.addr = (AW'(NT + 1 + rr(3)) << RWIN) | (AW'(rr(32)) << OFF);   // nothing legal reachable: unmapped
    if (pct(pbad)) begin
      kind = rr(9);
      case (kind)
        0: r.addr = (AW'(NT + rr(15 - NT > 0 ? 15 - NT : 1)) << RWIN) | (AW'(rr(32)) << OFF);   // unmapped (top nibble >= NT)
        1: r.addr = r.addr | AW'(1 + rr((DW / 8) - 1 > 0 ? (DW / 8) - 1 : 1));                  // misaligned
        2: r.op = 2'(2 + rr(2));                                                                  // reserved opcode
        3: r.dom = DOMW'(6 + rr(2));                                                              // domain not bound to the port
        4: r.dom = DOMW'(4 + rr(2));                                                              // bound but never granted
        5: begin r.op = OP_WRITE; r.addr = taddr(rr(NT), 2, rr(32)); end                          // write to the read-only region
        6: begin r.priv = 1'b0; r.addr = taddr(rr(NT), 3, rr(32)); end                            // privileged region, no priv
        7: begin t = rr(NT); r.addr = taddr(t, rr(2), rr(32)); end                                // maybe an unreachable / unpermitted target
        default: r.dom = DOMW'((m + 1 + rr(3)) % 4);                                              // another master's domain
      endcase
    end
    return r;
  endfunction

  task automatic enq(input int m, input rq_t r);
    if (dbg) $display("    DBG @%0d enq master %0d op %0d addr %h tagfix %0d (queue %0d)", cyc, m, int'(r.op), r.addr, r.tagfix, mq_n[m]);
    mq_push(m, r);
  endtask

  // ---------------------------------------------------------------- engine
  int tag_try;
  function automatic int free_tag(input int m);
    int start, k;
    start = rr(NTAG);
    for (k = 0; k < NTAG; k++) begin
      int tg;
      tg = (start + k) % NTAG;
      if (!e_v[m*NTAG + tg]) return tg;
    end
    return -1;
  endfunction

  task automatic clear_master_state(input int m);
    mq_clear(m);
    oq_clear(m);
    cur_v[m] = 1'b0;
    pend[m]  = 0;
    for (int k = 0; k < NTAG; k++) begin e_v[m*NTAG + k] = 1'b0; e_at_tgt[m*NTAG + k] = 1'b0; e_tl_v[m*NTAG + k] = 1'b0; e_zomb[m*NTAG + k] = 1'b0; e_flushed[m*NTAG + k] = 1'b0; end
    for (int t = 0; t < NT; t++) last_seq[m][t] = -1;
  endtask

  task automatic clear_target_state(input int t);
    tq_clear(t);
    trsp_v[t]  = 1'b0;
    dup_next[t] = 1'b0;
  endtask

  task automatic zero_mirror();
    for (int m = 0; m < NM; m++) for (int k = 0; k < PF_PM; k++) mc[m][k] = 0;
    for (int t = 0; t < NT; t++) for (int k = 0; k < PF_PT; k++) tcn[t][k] = 0;
    for (int m = 0; m < NM; m++) for (int t = 0; t < NT; t++) mx[m][t] = 0;
    for (int k = 0; k < PF_G; k++) gcn[k] = 0;
  endtask

  // ---- accept: a request was taken by the fabric this cycle
  task automatic on_accept(input int m);
    int e;
    logic [15:0] o;
    rq_t q;
    q = cur[m];
    e = m * NTAG + int'(q.tag);
    if (dbg) $display("    DBG @%0d master %0d ACCEPT tag %0d op %0d busy=%0d", cyc, m, int'(q.tag), int'(q.op), e_v[e]);
    if (e_v[e]) begin
      // the DUT must have dropped it (illegal tag reuse): no record, no response
      mc[m][PFM_V_TAGREUSE]++;
    end else begin
      o = oracle(m, q.op, q.dom, q.priv, q.addr);
      if (q.ovr) o = {8'd0, 4'd0, 1'b0, q.ovr_st};
      e_v[e] = 1'b1; e_fwd[e] = o[3]; e_status[e] = o[2:0]; e_fault[e] = o[7:4]; e_tgt[e] = int'(o[15:8]);
      e_op[e] = q.op; e_dom[e] = q.dom; e_priv[e] = q.priv; e_tc[e] = q.tc; e_addr[e] = q.addr;
      e_wdata[e] = q.wdata; e_wstrb[e] = q.wstrb; e_seq[e] = seq_ctr[m]; seq_ctr[m]++;
      if (first_acc[m] == 64'hFFFF_FFFF_FFFF_FFFF) first_acc[m] = cyc;
      e_zomb[e] = 1'b0; e_flushed[e] = 1'b0;
      e_acc[e] = cyc; e_at_tgt[e] = 1'b0; e_tl_v[e] = 1'b0; e_rdchk[e] = q.rdchk; e_rdexp[e] = q.rdexp;
      oq_push(m, int'(q.tag));
      pend[m]++;
      total_acc++;
      mc[m][PFM_REQ]++;
      if (!o[3]) begin
        // local error: violation events are counted at acceptance
        case (o[7:4])
          F_BADOP:    mc[m][PFM_V_BADOP]++;
          F_MISALIGN: mc[m][PFM_V_MISALIGN]++;
          F_SPOOF:    mc[m][PFM_V_SPOOF]++;
          default: ;
        endcase
      end
    end
  endtask

  // ---- a target accepted a request
  task automatic on_target_req(input int t);
    int      src, e;
    logic [TAGW-1:0] tag;
    rsp_t    r;
    logic [AW-1:0] a;
    logic [DW-1:0] old, nw;
    bit      slverr, bad_echo;
    int      lat;
    src = int'(t_req_src[t*SRCW +: SRCW]);
    tag = t_req_tag[t*TAGW +: TAGW];
    a   = t_req_addr[t*AW +: AW];
    if (src >= NM) begin fail($sformatf("target %0d received src %0d out of range", t, src)); return; end
    e = src * NTAG + int'(tag);
    if (dbg) $display("    DBG @%0d target %0d <- src %0d tag %0d op %0d addr %h wd %h ws %h", cyc, t, src, int'(tag), int'(t_req_op[t*2 +: 2]), a, t_req_wdata[t*DW +: DW], t_req_wstrb[t*(DW/8) +: DW/8]);
    `CHK(e_v[e], $sformatf("target %0d received (src %0d, tag %0d) that is not outstanding", t, src, int'(tag)));
    if (!e_v[e]) return;
    `CHK(e_fwd[e], $sformatf("target %0d received a request the oracle says must be answered locally (src %0d tag %0d, status %0d)", t, src, int'(tag), int'(e_status[e])));
    `CHK(!e_at_tgt[e], $sformatf("target %0d received a request twice (src %0d tag %0d)", t, src, int'(tag)));
    `CHK(e_tgt[e] == t, $sformatf("misrouted: request (src %0d tag %0d) for target %0d arrived at %0d", src, int'(tag), e_tgt[e], t));
    `CHK(t_req_op[t*2 +: 2] == e_op[e], "request op changed in the fabric");
    `CHK(t_req_dom[t*DOMW +: DOMW] == e_dom[e], "request domain changed in the fabric");
    `CHK(t_req_priv[t] == e_priv[e], "request priv changed in the fabric");
    `CHK(t_req_tc[t*3 +: 3] == e_tc[e], "request class changed in the fabric");
    `CHK(a == e_addr[e], "request address changed in the fabric");
    `CHK(t_req_wdata[t*DW +: DW] == e_wdata[e], "request write data changed in the fabric");
    `CHK(t_req_wstrb[t*(DW/8) +: DW/8] == e_wstrb[e], "request write strobes changed in the fabric");
    `CHK(e_seq[e] > last_seq[src][t], $sformatf("order: requests of master %0d to target %0d overtaken", src, t));
    last_seq[src][t] = e_seq[e];
    e_at_tgt[e] = 1'b1;
    e_tcyc[e] = cyc;
    req_path_last = cyc - e_acc[e];
    total_tx++;
    tcn[t][PFT_REQ]++;
    tcn[t][PFT_BYTES] += (e_op[e] == OP_WRITE) ? popcnt(e_wstrb[e]) : DW / 8;
    mx[src][t]++;
    grants_by_src[t][src]++;
    if (t_dead[t] == 1 && !allow_tmo[src]) return;
    // ---- the target's behaviour
    slverr = pct(t_err_pct[t]);
    old = tmem.exists({8'(t), a}) ? tmem[{8'(t), a}] : {DW{1'b0}};
    r.src = SRCW'(src); r.tag = tag; r.dom = e_dom[e]; r.op = e_op[e]; r.status = slverr ? ST_SLVERR : ST_OKAY;
    r.rdata = '0; r.dup = 1'b0; r.is_dup = 1'b0;
    if (!slverr) begin
      if (e_op[e] == OP_WRITE) begin
        nw = old;
        for (int b = 0; b < DW / 8; b++) if (e_wstrb[e][b]) nw[b*8 +: 8] = e_wdata[e][b*8 +: 8];
        tmem[{8'(t), a}] = nw;
      end else begin
        r.rdata = old;
      end
    end
    e_tl_v[e] = 1'b1; e_tl_st[e] = r.status; e_tl_rd[e] = (r.status == ST_OKAY && r.op == OP_READ) ? r.rdata : '0;
    bad_echo = pct(t_badecho_pct[t]);
    if (bad_echo) begin
      if (rr(2) == 0) r.dom = r.dom ^ DOMW'(1); else r.op = r.op ^ 2'd1;
      e_tl_st[e] = ST_PROTO; e_tl_rd[e] = '0;
      mc[src][PFM_V_ECHO]++;
    end
    if (!bad_echo && pct(t_dup_pct[t])) r.dup = 1'b1;
    lat = tlat_min[t] + rr(tlat_max[t] - tlat_min[t] + 1);
    r.due = cyc + lat;
    tq_push(t, r);
    if (pct(t_badsrc_pct[t])) begin
      // an extra response nobody asked for: out-of-range source, else a master without a path to this target
      rsp_t b;
      int   bs;
      bs = -1;
      if ((1 << SRCW) > NM) bs = NM;
      else for (int mm = 0; mm < NM; mm++) if (!CONN[mm*NT + t]) bs = mm;
      if (bs >= 0) begin
        b = r; b.src = SRCW'(bs); b.dup = 1'b0; b.is_dup = 1'b1; b.due = r.due + 1;
        tq_push(t, b);
        tcn[t][PFT_BADSRC]++;
      end
    end
  endtask

  // ---- a response was delivered to a master
  task automatic on_deliver(input int m);
    int  e;
    logic [TAGW-1:0] tag;
    logic [2:0] st;
    logic [DW-1:0] rd, exp_rd;
    int unsigned lat;
    tag = m_rsp_tag[m*TAGW +: TAGW];
    st  = m_rsp_status[m*3 +: 3];
    rd  = m_rsp_rdata[m*DW +: DW];
    e   = m * NTAG + int'(tag);
    if (dbg) $display("    DBG @%0d master %0d <- tag %0d st %0d rd %h", cyc, m, int'(tag), int'(st), rd);
    `CHK(e_v[e], $sformatf("master %0d received a response for tag %0d that is not outstanding (duplicate / foreign)", m, int'(tag)));
    if (!e_v[e]) return;
    `CHK(m_rsp_dom[m*DOMW +: DOMW] == e_dom[e], $sformatf("master %0d: response domain echo wrong (tag %0d)", m, int'(tag)));
    `CHK(m_rsp_op[m*2 +: 2] == e_op[e], $sformatf("master %0d: response opcode echo wrong (tag %0d)", m, int'(tag)));
    exp_rd = '0;
    if (!e_fwd[e]) begin
      `CHK(st == e_status[e], $sformatf("master %0d tag %0d: local error status %0d, expected %0d", m, int'(tag), int'(st), int'(e_status[e])));
    end else if (allow_tmo[m] && st == ST_TIMEOUT) begin
      // accepted: the scenario provoked it
    end else begin
      `CHK(e_tl_v[e], $sformatf("master %0d tag %0d: response although the request never reached a target (status %0d)", m, int'(tag), int'(st)));
      if (e_tl_v[e]) begin
        `CHK(st == e_tl_st[e], $sformatf("master %0d tag %0d: status %0d, target answered %0d", m, int'(tag), int'(st), int'(e_tl_st[e])));
        exp_rd = e_tl_rd[e];
        if (e_rdchk[e] && st == ST_OKAY) `CHK(rd == e_rdexp[e], $sformatf("master %0d tag %0d: read data %h, expected %h", m, int'(tag), rd, e_rdexp[e]));
      end
    end
    if (!(allow_tmo[m] && st == ST_TIMEOUT)) `CHK(rd == exp_rd, $sformatf("master %0d tag %0d: read data %h, expected %h", m, int'(tag), rd, exp_rd));
    // ordering: ports without OOO deliver in acceptance order
    if (oq_n[m] > 0) begin
      if (!MST_OOO[m]) begin
        `CHK(oq_at(m, 0) == int'(tag), $sformatf("master %0d: response order violated (got tag %0d, oldest outstanding %0d)", m, int'(tag), oq_at(m, 0)));
      end
      for (int k = 0; k < oq_n[m]; k++) if (oq_at(m, k) == int'(tag)) begin oq_del(m, k); break; end
    end
    // counters
    lat = cyc - e_acc[e];
    mc[m][PFM_CPL]++;
    if (st != ST_OKAY) mc[m][PFM_CPLERR]++;
    case (st)
      ST_DECERR:  mc[m][PFM_DECERR]++;
      ST_DENIED:  mc[m][PFM_DENIED]++;
      ST_TIMEOUT: mc[m][PFM_TIMEOUT]++;
      ST_PROTO:   mc[m][PFM_PROTO]++;
      ST_SLVERR:  mc[m][PFM_SLVERR]++;
      default: ;
    endcase
    if (st == ST_OKAY) begin
      if (e_op[e] == OP_WRITE) mc[m][PFM_BYTES_WR] += popcnt(e_wstrb[e]); else mc[m][PFM_BYTES_RD] += DW / 8;
    end
    mc[m][PFM_LAT_SUM] += lat; mc[m][PFM_LAT_CNT]++;
    if (lat > mc[m][PFM_LAT_MAX]) mc[m][PFM_LAT_MAX] = lat;
    cls_n[e_tc[e]]++; cls_sum[e_tc[e]] += lat; if (lat > cls_max[e_tc[e]]) cls_max[e_tc[e]] = lat;
    total_dlv++;
    pend[m]--;
    if (st == ST_OKAY && lat > lat_ok_max[m]) lat_ok_max[m] = lat;
    last_dlv[m] = cyc;
    last_lat[m] = lat;
    last_resp_path[m] = cyc - e_rcyc[e];
    if (!e_zomb[e]) e_v[e] = 1'b0;           // a zombie keeps its tag busy
  endtask

  // ---- the clocked engine
  always @(posedge clk) begin
    int e;
    if (!rst_n) begin
      for (int m = 0; m < NM; m++) begin
        m_req_valid[m] <= 1'b0;
        m_rsp_ready[m] <= 1'b0;
        if (flush_req >= 1) clear_master_state(m);
      end
      for (int t = 0; t < NT; t++) begin
        t_req_ready[t] <= 1'b0;
        t_rsp_valid[t] <= 1'b0;
        if (flush_req >= 2) clear_target_state(t);
      end
      zero_mirror();
      p_rsp_v = '0; p_rsp_r = '0; p_req_v = '0; p_req_r = '0;
    end else begin
      // ------------- per-cycle counter mirror (values during the cycle that is ending)
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && !m_req_ready[m]) mc[m][PFM_STALL_IN]++;
        mc[m][PFM_OUT_SUM] += pend[m];
        if (pend[m] > mc[m][PFM_OUT_MAX]) mc[m][PFM_OUT_MAX] = pend[m];
      end
      begin
        bit anyp;
        anyp = 1'b0;
        for (int m = 0; m < NM; m++) if (pend[m] > 0) anyp = 1'b1;
        gcn[PFG_CYCLES]++;
        if (anyp) gcn[PFG_BUSY]++;
      end
      for (int t = 0; t < NT; t++) if (t_req_valid[t] && !t_req_ready[t]) tcn[t][PFT_BUSY]++;

      // ------------- stability monitors on the DUT outputs
      for (int m = 0; m < NM; m++) begin
        if (p_rsp_v[m] && !p_rsp_r[m]) begin
          `CHK(m_rsp_valid[m], "m_rsp_valid dropped while not accepted");
          `CHK(m_rsp_tag[m*TAGW +: TAGW] == p_rsp_tag[m*TAGW +: TAGW] && m_rsp_status[m*3 +: 3] == p_rsp_st[m*3 +: 3] &&
               m_rsp_rdata[m*DW +: DW] == p_rsp_rd[m*DW +: DW], "m_rsp payload changed while not accepted");
        end
      end
      for (int t = 0; t < NT; t++) begin
        if (p_req_v[t] && !p_req_r[t]) begin
          `CHK(t_req_valid[t], "t_req_valid dropped while not accepted");
          `CHK(t_req_addr[t*AW +: AW] == p_req_addr[t*AW +: AW] && t_req_wdata[t*DW +: DW] == p_req_wd[t*DW +: DW] &&
               t_req_tag[t*TAGW +: TAGW] == p_req_tag[t*TAGW +: TAGW] && t_req_src[t*SRCW +: SRCW] == p_req_src[t*SRCW +: SRCW],
               "t_req payload changed while not accepted");
        end
      end

      // ------------- arbitration bound monitor (probes the crosspoint buffers)
      for (int t = 0; t < NT; t++) begin
        for (int m = 0; m < NM; m++) begin
          bit wait_m;
          wait_m = dut.u_router.xq_v[m*NT + t];
          if (wait_m && dut.u_router.xq_pop[m*NT + t]) arb_wait[m][t] = 0;
          else if (!wait_m) arb_wait[m][t] = 0;
          else begin
            for (int o = 0; o < NM; o++) if (o != m && dut.u_router.xq_pop[o*NT + t]) arb_wait[m][t]++;
            if (arb_wait[m][t] > arb_wait_max) arb_wait_max = arb_wait[m][t];
            if (arb_wait[m][t] > arb_wait_hi) arb_wait_hi = arb_wait[m][t];
            if (arb_wait[m][t] > arb_bound) fail($sformatf("arbitration bound %0d exceeded at target %0d for master %0d (%0d transfers of others)", arb_bound, t, m, arb_wait[m][t]));
          end
        end
      end

      // ------------- events
      for (int m = 0; m < NM; m++) if (m_rsp_valid[m] && m_rsp_ready[m]) on_deliver(m);
      for (int t = 0; t < NT; t++) if (t_req_valid[t] && t_req_ready[t]) on_target_req(t);
      for (int m = 0; m < NM; m++) if (m_req_valid[m] && m_req_ready[m]) begin
        on_accept(m);
        cur_v[m] = 1'b0;
      end
      // the fault logs of each port tell the bench what kind of timeout happened (they do not decide pass / fail):
      // lgt (F_RSPTMO) = the request was issued, its late response is still to come (zombie);
      // lg with F_HOL / F_ISO = the request was never issued (cancelled / failed fast)
      for (int m = 0; m < NM; m++) begin
        if (dut.lgt_v[m]) begin
          e = m * NTAG + int'(dut.lgt_tag[m*TAGW +: TAGW]);
          if (e_v[e]) e_zomb[e] = 1'b1;
        end
        if (dut.lg_v[m]) begin
          logic [3:0] f;
          f = dut.lg_fault[m*4 +: 4];
          e = m * NTAG + int'(dut.lg_tag[m*TAGW +: TAGW]);
          if (e_v[e] && (f == F_HOL || f == F_ISO)) begin e_fwd[e] = 1'b0; e_status[e] = ST_TIMEOUT; end
        end
      end
      for (int t = 0; t < NT; t++) if (trsp_v[t] && t_rsp_ready[t]) begin
        if (!trsp[t].is_dup) begin
          e = int'(trsp[t].src) * NTAG + int'(trsp[t].tag);
          if (int'(trsp[t].src) < NM) e_rcyc[e] = cyc;
          if (int'(trsp[t].src) < NM && e_zomb[e]) begin
            e_zomb[e] = 1'b0; e_v[e] = 1'b0; mc[int'(trsp[t].src)][PFM_V_LATE]++;       // swallowed by the zombie slot
          end else if (int'(trsp[t].src) < NM && e_flushed[e]) begin
            e_flushed[e] = 1'b0; mc[int'(trsp[t].src)][PFM_V_ORPHAN]++;                  // slot already reclaimed
          end
        end
        trsp_v[t] = 1'b0;
        total_rx_rsp++;
      end

      // ------------- drive next cycle
      for (int m = 0; m < NM; m++) begin
        if (!cur_v[m] && mq_n[m] > 0 && !pct(gap_pct[m])) begin
          rq_t q;
          int  tg;
          q = mq_front(m);
          tg = q.tagfix ? int'(q.tag) : free_tag(m);
          if (tg >= 0) begin
            q.tag = TAGW'(tg);
            mq_pop(m);
            cur[m] = q; cur_v[m] = 1'b1;
          end
        end
        m_req_valid[m] <= cur_v[m];
        if (dbg && cur_v[m] && !m_req_valid[m]) $display("    DBG @%0d master %0d presents tag %0d op %0d addr %h", cyc, m, int'(cur[m].tag), int'(cur[m].op), cur[m].addr);
        if (cur_v[m]) begin
          m_req_op[m*2 +: 2]          <= cur[m].op;
          m_req_tag[m*TAGW +: TAGW]   <= cur[m].tag;
          m_req_dom[m*DOMW +: DOMW]   <= cur[m].dom;
          m_req_priv[m]               <= cur[m].priv;
          m_req_tc[m*3 +: 3]          <= cur[m].tc;
          m_req_addr[m*AW +: AW]      <= cur[m].addr;
          m_req_wdata[m*DW +: DW]     <= cur[m].wdata;
          m_req_wstrb[m*(DW/8) +: DW/8] <= cur[m].wstrb;
        end
        m_rsp_ready[m] <= pct(rrdy_pct[m]);
      end
      for (int t = 0; t < NT; t++) begin
        t_req_ready[t] <= !t_stall[t] && pct(tready_pct[t]);
        // response driver: a pending duplicate goes out back to back, then the next eligible response
        if (!trsp_v[t]) begin
          if (dup_next[t]) begin
            trsp[t] = dup_copy[t]; trsp_v[t] = 1'b1; dup_next[t] = 1'b0;
          end else if (t_dead[t] != 1 && tq_n[t] > 0) begin
            int pick;
            pick = -1;
            if (!t_ooo[t]) begin
              if (tq_at(t, 0).due <= cyc) pick = 0;
            end else begin
              int cnt, nth;
              cnt = 0;
              for (int k = 0; k < tq_n[t]; k++) if (tq_at(t, k).due <= cyc) cnt++;
              if (cnt > 0) begin
                nth = rr(cnt);
                for (int k = 0; k < tq_n[t]; k++) if (tq_at(t, k).due <= cyc) begin
                  if (nth == 0) begin pick = k; break; end
                  nth--;
                end
              end
            end
            if (pick >= 0) begin
              trsp[t] = tq_at(t, pick); trsp_v[t] = 1'b1;
              tq_del(t, pick);
              if (trsp[t].dup) begin
                dup_copy[t] = trsp[t]; dup_copy[t].dup = 1'b0; dup_copy[t].is_dup = 1'b1;
                dup_next[t] = 1'b1;
                mc[int'(trsp[t].src)][PFM_V_ORPHAN]++;       // the copy must be consumed as an orphan
              end
            end
          end
        end
        t_rsp_valid[t] <= trsp_v[t];
        if (trsp_v[t]) begin
          t_rsp_src[t*SRCW +: SRCW]    <= trsp[t].src;
          t_rsp_tag[t*TAGW +: TAGW]    <= trsp[t].tag;
          t_rsp_dom[t*DOMW +: DOMW]    <= trsp[t].dom;
          t_rsp_op[t*2 +: 2]           <= trsp[t].op;
          t_rsp_status[t*3 +: 3]       <= trsp[t].status;
          t_rsp_rdata[t*DW +: DW]      <= trsp[t].rdata;
        end
      end

      // ------------- snapshots
      p_rsp_v = m_rsp_valid; p_rsp_r = m_rsp_ready; p_rsp_tag = m_rsp_tag; p_rsp_st = m_rsp_status; p_rsp_rd = m_rsp_rdata;
      p_req_v = t_req_valid; p_req_r = t_req_ready; p_req_addr = t_req_addr; p_req_wd = t_req_wdata; p_req_tag = t_req_tag;
      p_req_src = t_req_src;
      if (perf_clear) zero_mirror();
    end
    cyc = cyc + 1;
  end

  // ---------------------------------------------------------------- sequencer helpers
  task automatic tick(input int n);
    repeat (n) @(posedge clk);
    #1;
  endtask

  task automatic set_defaults();
    for (int m = 0; m < NM; m++) begin gap_pct[m] = 0; rrdy_pct[m] = 100; allow_tmo[m] = 1'b0; end
    for (int t = 0; t < NT; t++) begin
      tready_pct[t] = 100; tlat_min[t] = 0; tlat_max[t] = 1; t_ooo[t] = 1'b0; t_err_pct[t] = 0; t_dead[t] = 0;
      t_stall[t] = 1'b0; t_dup_pct[t] = 0; t_badecho_pct[t] = 0; t_badsrc_pct[t] = 0;
    end
  endtask

  task automatic reset_dut(input int full);
    rst_n = 1'b0;
    flush_req = full;
    tick(4);
    for (int m = 0; m < NM; m++) begin
      for (int t = 0; t < NT; t++) last_seq[m][t] = -1;
      seq_ctr[m] = 0;
    end
    for (int t = 0; t < NT; t++) for (int m = 0; m < NM; m++) grants_by_src[t][m] = 0;
    for (int k = 0; k < 8; k++) begin cls_n[k] = 0; cls_sum[k] = 0; cls_max[k] = 0; end
    if (full >= 2) tmem.delete();
    total_acc = 0; total_dlv = 0; total_tx = 0; total_rx_rsp = 0;
    arb_wait_max = 0;
    for (int m = 0; m < NM; m++) for (int t = 0; t < NT; t++) arb_wait[m][t] = 0;
    rst_n = 1'b1;
    flush_req = 0;
    tick(2);
  endtask

  // program the policy: for each target three regions (RW, read-only, privileged RW) for the masters PERM allows
  task automatic prog_policy();
    logic [NM-1:0] sm;
    for (int t = 0; t < NT; t++) begin
      sm = '0;
      for (int m = 0; m < NM; m++) sm[m] = PERM[m*NT + t];
      for (int r = 0; r < 3; r++) begin
        pol_we = 1'b1; pol_idx = CITIW'(3 * t + r); pol_valid = 1'b1; pol_src = sm;
        pol_dom = NDOM'(4'b1111);
        pol_priv = (r == 2);
        case (r)
          0: begin pol_base = AW'(t) << RWIN;                          pol_mask = TGT_MASK[t*AW +: AW] | (AW'(1) << (RWIN-1)); pol_rd = 1'b1; pol_wr = 1'b1; end
          1: begin pol_base = (AW'(t) << RWIN) | (AW'(2) << (RWIN-2)); pol_mask = TGT_MASK[t*AW +: AW] | (AW'(3) << (RWIN-2)); pol_rd = 1'b1; pol_wr = 1'b0; end
          default: begin pol_base = (AW'(t) << RWIN) | (AW'(3) << (RWIN-2)); pol_mask = TGT_MASK[t*AW +: AW] | (AW'(3) << (RWIN-2)); pol_rd = 1'b1; pol_wr = 1'b1; end
        endcase
        tick(1);
      end
    end
    pol_we = 1'b0;
    tick(1);
  endtask

  task automatic begin_test(input string name);
    cur_test = name;
    fail_at_test_start = n_fail;
    set_defaults();
    for (int m = 0; m < NM; m++) begin lat_ok_max[m] = 0; first_acc[m] = 64'hFFFF_FFFF_FFFF_FFFF; last_dlv[m] = 0; end
    reset_dut(2);
    prog_policy();
    perf_clear = 1'b1; tick(1); perf_clear = 1'b0;
    tick(1);
  endtask

  task automatic end_test();
    n_tests++;
    if (n_fail == fail_at_test_start) $display("  [PASS] %s", cur_test);
    else begin n_tests_fail++; $display("  [FAIL] %s (%0d failures)", cur_test, n_fail - fail_at_test_start); end
  endtask

  // wait until the system is quiet: nothing queued, presented, outstanding or in a target
  task automatic wait_quiet(input int maxcyc);
    int n;
    bit busy;
    n = 0;
    do begin
      tick(1);
      busy = 1'b0;
      for (int m = 0; m < NM; m++) if (mq_n[m] > 0 || cur_v[m] || pend[m] != 0) busy = 1'b1;
      for (int t = 0; t < NT; t++) if (tq_n[t] > 0 || trsp_v[t] || dup_next[t]) busy = 1'b1;
      n++;
    end while (busy && n < maxcyc);
    `CHK(!busy, $sformatf("wait_quiet: system did not drain in %0d cycles (pend=%0d,%0d)", maxcyc, pend[0], (NM > 1) ? pend[1] : 0));
    tick(6);          // let late events (orphans, counters) settle
  endtask

  // like wait_quiet, but dead / stalled targets keep their requests and zombies keep their tags
  task automatic wait_quiet_ign(input int maxcyc);
    int n;
    bit busy;
    n = 0;
    do begin
      tick(1);
      busy = 1'b0;
      for (int m = 0; m < NM; m++) if (mq_n[m] > 0 || cur_v[m] || pend[m] != 0) busy = 1'b1;
      for (int t = 0; t < NT; t++) if (t_dead[t] != 1 && !t_stall[t] && (tq_n[t] > 0 || trsp_v[t] || dup_next[t])) busy = 1'b1;
      n++;
    end while (busy && n < maxcyc);
    `CHK(!busy, $sformatf("wait_quiet_ign: system did not drain in %0d cycles", maxcyc));
    tick(6);
  endtask

  // reclaim every zombie slot (management recovery)
  task automatic do_flush();
    zomb_flush = 1'b1; tick(2); zomb_flush = 1'b0; tick(1);
    for (int e = 0; e < NM * NTAG; e++) if (e_zomb[e]) begin
      e_zomb[e] = 1'b0; e_v[e] = 1'b0;
      e_flushed[e] = e_at_tgt[e];            // a response may still come from the target: it will be an orphan
    end
  endtask

  // ---- end-of-test global checks
  task automatic check_conservation();
    `CHK(total_acc == total_dlv, $sformatf("conservation: %0d accepted, %0d delivered", total_acc, total_dlv));
    for (int m = 0; m < NM; m++) begin
      `CHK(pend[m] == 0, $sformatf("master %0d: %0d transactions still outstanding", m, pend[m]));
      `CHK(oq_n[m] == 0, $sformatf("master %0d: order queue not empty", m));
      for (int k = 0; k < NTAG; k++) `CHK(!e_v[m*NTAG + k], $sformatf("master %0d tag %0d never completed", m, k));
    end
    `CHK(m_rsp_valid == '0, "a response is still presented after quiescence");
    `CHK(t_req_valid == '0, "a request is still presented to a target after quiescence");
    for (int t = 0; t < NT; t++) `CHK(tq_n[t] == 0 && !trsp_v[t], "target response queue not empty");
  endtask

  // counter read: the read port is combinational, give it a delta to settle
  task automatic rd_cnt(input int k, output longint unsigned v);
    perf_sel = RSW'(k);
    #1;
    v = longint'(perf_data);
  endtask

  task automatic check_one(input string what, input int idx, input longint unsigned want);
    longint unsigned got;
    rd_cnt(idx, got);
    `CHK(got == want, $sformatf("counter %s: DUT %0d, mirror %0d", what, got, want));
  endtask

  task automatic check_le(input string what, input int idx, input longint unsigned upper);
    longint unsigned got;
    rd_cnt(idx, got);
    `CHK(got <= upper, $sformatf("counter %s: DUT %0d above the bench's outer-edge value %0d", what, got, upper));
  endtask

  // every counter the bench can mirror exactly is compared; the rest are bounded.
  // Per-master latency / occupancy / input-stall counters are measured at the master PORT, behind the master-side slice:
  // for a sliced master the bench (which sees the outer edge) can only bound them from above.
  task automatic check_perf(input bit exact_occ);
    bit okc;
    tick(2);
    check_one("CYCLES", PFG_CYCLES, gcn[PFG_CYCLES]);
    for (int m = 0; m < NM; m++) begin
      check_one($sformatf("m%0d.REQ", m), pf_m(m, PFM_REQ), mc[m][PFM_REQ]);
      check_one($sformatf("m%0d.CPL", m), pf_m(m, PFM_CPL), mc[m][PFM_CPL]);
      check_one($sformatf("m%0d.CPLERR", m), pf_m(m, PFM_CPLERR), mc[m][PFM_CPLERR]);
      check_one($sformatf("m%0d.DECERR", m), pf_m(m, PFM_DECERR), mc[m][PFM_DECERR]);
      check_one($sformatf("m%0d.DENIED", m), pf_m(m, PFM_DENIED), mc[m][PFM_DENIED]);
      check_one($sformatf("m%0d.TIMEOUT", m), pf_m(m, PFM_TIMEOUT), mc[m][PFM_TIMEOUT]);
      check_one($sformatf("m%0d.PROTO", m), pf_m(m, PFM_PROTO), mc[m][PFM_PROTO]);
      check_one($sformatf("m%0d.SLVERR", m), pf_m(m, PFM_SLVERR), mc[m][PFM_SLVERR]);
      check_one($sformatf("m%0d.BYTES_WR", m), pf_m(m, PFM_BYTES_WR), mc[m][PFM_BYTES_WR]);
      check_one($sformatf("m%0d.BYTES_RD", m), pf_m(m, PFM_BYTES_RD), mc[m][PFM_BYTES_RD]);
      if (MST_SLICE[m*4 +: 4] == 0) check_one($sformatf("m%0d.LAT_SUM", m), pf_m(m, PFM_LAT_SUM), mc[m][PFM_LAT_SUM]);
      else check_le($sformatf("m%0d.LAT_SUM", m), pf_m(m, PFM_LAT_SUM), mc[m][PFM_LAT_SUM]);
      check_one($sformatf("m%0d.LAT_CNT", m), pf_m(m, PFM_LAT_CNT), mc[m][PFM_LAT_CNT]);
      if (MST_SLICE[m*4 +: 4] == 0) check_one($sformatf("m%0d.LAT_MAX", m), pf_m(m, PFM_LAT_MAX), mc[m][PFM_LAT_MAX]);
      else check_le($sformatf("m%0d.LAT_MAX", m), pf_m(m, PFM_LAT_MAX), mc[m][PFM_LAT_MAX]);
      if (MST_SLICE[m*4 +: 4] == 0) check_one($sformatf("m%0d.OUT_SUM", m), pf_m(m, PFM_OUT_SUM), mc[m][PFM_OUT_SUM]);
      else check_le($sformatf("m%0d.OUT_SUM", m), pf_m(m, PFM_OUT_SUM), mc[m][PFM_OUT_SUM]);
      if (MST_SLICE[m*4 +: 4] == 0) check_one($sformatf("m%0d.OUT_MAX", m), pf_m(m, PFM_OUT_MAX), mc[m][PFM_OUT_MAX]);
      else check_le($sformatf("m%0d.OUT_MAX", m), pf_m(m, PFM_OUT_MAX), mc[m][PFM_OUT_MAX]);
      if (MST_SLICE[m*4 +: 4] == 0) check_one($sformatf("m%0d.STALL_IN", m), pf_m(m, PFM_STALL_IN), mc[m][PFM_STALL_IN]);
      check_one($sformatf("m%0d.V_BADOP", m), pf_m(m, PFM_V_BADOP), mc[m][PFM_V_BADOP]);
      check_one($sformatf("m%0d.V_MISALIGN", m), pf_m(m, PFM_V_MISALIGN), mc[m][PFM_V_MISALIGN]);
      check_one($sformatf("m%0d.V_TAGREUSE", m), pf_m(m, PFM_V_TAGREUSE), mc[m][PFM_V_TAGREUSE]);
      check_one($sformatf("m%0d.V_SPOOF", m), pf_m(m, PFM_V_SPOOF), mc[m][PFM_V_SPOOF]);
      check_one($sformatf("m%0d.V_ORPHAN", m), pf_m(m, PFM_V_ORPHAN), mc[m][PFM_V_ORPHAN]);
      check_one($sformatf("m%0d.V_ECHO", m), pf_m(m, PFM_V_ECHO), mc[m][PFM_V_ECHO]);
      check_one($sformatf("m%0d.V_LATE", m), pf_m(m, PFM_V_LATE), mc[m][PFM_V_LATE]);
    end
    for (int t = 0; t < NT; t++) begin
      check_one($sformatf("t%0d.REQ", t), pf_t(NM, t, PFT_REQ), tcn[t][PFT_REQ]);
      check_one($sformatf("t%0d.BYTES", t), pf_t(NM, t, PFT_BYTES), tcn[t][PFT_BYTES]);
      check_one($sformatf("t%0d.BUSY", t), pf_t(NM, t, PFT_BUSY), tcn[t][PFT_BUSY]);
      check_one($sformatf("t%0d.BADSRC", t), pf_t(NM, t, PFT_BADSRC), tcn[t][PFT_BADSRC]);
      begin
        longint unsigned om;
        rd_cnt(pf_t(NM, t, PFT_OCC_MAX), om);
        okc = om <= unsigned'(NM * REQ_DEPTH);
        `CHK(okc, $sformatf("t%0d.OCC_MAX above NM*REQ_DEPTH", t));
      end
      for (int m = 0; m < NM; m++) check_one($sformatf("x[%0d][%0d]", m, t), pf_x(NM, NT, m, t), mx[m][t]);
    end
    begin
      bit any_sl;
      any_sl = (MST_SLICE != '0);
      if (!any_sl) check_one("G.BUSY", PFG_BUSY, gcn[PFG_BUSY]);
      else         check_le("G.BUSY", PFG_BUSY, gcn[PFG_BUSY]);
    end
    begin
      longint unsigned sr, sc, sb;
      sr = 0; sc = 0; sb = 0;
      for (int m = 0; m < NM; m++) begin sr += mc[m][PFM_REQ]; sc += mc[m][PFM_CPL]; sb += mc[m][PFM_BYTES_WR] + mc[m][PFM_BYTES_RD]; end
      check_one("G.REQ", PFG_REQ, sr);
      check_one("G.CPL", PFG_CPL, sc);
      check_one("G.BYTES", PFG_BYTES, sb);
    end
    // informational line with the counters that cannot be mirrored exactly
    begin
      longint unsigned ga, gb, gc, o0, a0, om0;
      rd_cnt(PFG_ARBSTALL, ga); rd_cnt(PFG_BUSY, gb); rd_cnt(PFG_CYCLES, gc);
      rd_cnt(pf_t(NM, 0, PFT_OCC_SUM), o0); rd_cnt(pf_t(NM, 0, PFT_ARBSTALL), a0); rd_cnt(pf_t(NM, 0, PFT_OCC_MAX), om0);
      $display("    PERF cycles=%0d busy=%0d arb_stall_total=%0d | t0: arb_stall=%0d occ_sum=%0d occ_max=%0d | arb wait max so far %0d",
               gc, gb, ga, a0, o0, om0, arb_wait_max);
    end
  endtask

  // ---- directed single transaction helper: issue, wait, no checks beyond the scoreboard
  task automatic one(input int m, input rq_t r);
    enq(m, r);
  endtask

  // =============================================================================================================
  //  TESTS
  // =============================================================================================================

  // ---- every master -> every target, write then read back, data checked end to end
  task automatic t_routes();
    begin_test("routes");
    for (int m = 0; m < NM; m++) begin
      for (int t = 0; t < NT; t++) begin
        rq_t w, r;
        logic [DW-1:0] d;
        logic [AW-1:0] a;
        d = {DW/32{32'(32'hA5A50000 | (m << 8) | t)}} ^ rnd_data();
        a = taddr(t, 0, 4 + m);
        w = mkreq(OP_WRITE, m % 4, 1'b0, TC_COMPUTE, a, d, '1);
        r = mkreq(OP_READ,  m % 4, 1'b0, TC_COMPUTE, a, '0, '0);
        r.rdchk = 1'b1; r.rdexp = d;
        enq(m, w); enq(m, r);
        wait_quiet(4000);
        // the write must have landed in exactly that target's memory iff the route is legal
        if (CONN[m*NT + t] && (CITADEL_MODE == 0 || PERM[m*NT + t])) begin
          `CHK(tmem.exists({8'(t), a}) && tmem[{8'(t), a}] == d, $sformatf("route m%0d->t%0d: data did not land", m, t));
        end else begin
          `CHK(!tmem.exists({8'(t), a}), $sformatf("route m%0d->t%0d: forbidden write reached the target memory", m, t));
        end
      end
    end
    check_conservation();
    check_perf(1);
    end_test();
  endtask

  // ---- simultaneous traffic from every master, random mix, full speed
  task automatic t_simul(input int n_per_master, input int pbad);
    begin_test($sformatf("simultaneous_n%0d_bad%0d", n_per_master, pbad));
    for (int m = 0; m < NM; m++) for (int k = 0; k < n_per_master; k++) enq(m, rand_req(m, pbad));
    wait_quiet(200000);
    check_conservation();
    check_perf(1);
    end_test();
  endtask

  // ---- randomised arbitration, back-pressure and latency; several rounds with different knob settings
  task automatic t_random(input int rounds);
    begin_test("random_backpressure");
    for (int rd = 0; rd < rounds; rd++) begin
      for (int m = 0; m < NM; m++) begin gap_pct[m] = rr(60); rrdy_pct[m] = 10 + rr(91); end
      for (int t = 0; t < NT; t++) begin
        tready_pct[t] = 10 + rr(91); tlat_min[t] = rr(3); tlat_max[t] = tlat_min[t] + rr(12);
        t_ooo[t] = (rr(2) == 0); t_err_pct[t] = rr(15);
      end
      for (int m = 0; m < NM; m++) for (int k = 0; k < 150; k++) enq(m, rand_req(m, 8));
      wait_quiet(400000);
    end
    check_conservation();
    check_perf(1);
    end_test();
  endtask

  // ---- invalid destinations, decode errors, protocol violations: exact statuses, no side effects
  task automatic t_invalid();
    begin_test("invalid_and_protocol");
    for (int m = 0; m < NM; m++) begin
      rq_t r;
      // unmapped address
      r = mkreq(OP_WRITE, m % 4, 1'b0, TC_IO, (AW'(NT + 1) << RWIN) | AW'(8 << OFF), 64'hDEAD, '1); enq(m, r);
      r = mkreq(OP_READ,  m % 4, 1'b0, TC_IO, AW'(32'hF000_0000) & ~AW'((1 << OFF) - 1), '0, '0);   enq(m, r);
      // misaligned
      if (OFF > 0) begin
        r = mkreq(OP_READ, m % 4, 1'b0, TC_IO, taddr(0, 0, 3) | AW'(1), '0, '0); enq(m, r);
        r = mkreq(OP_WRITE, m % 4, 1'b0, TC_IO, taddr(0, 0, 3) | AW'((1 << OFF) - 1), rnd_data(), '1); enq(m, r);
      end
      // reserved opcodes
      r = mkreq(2'd2, m % 4, 1'b0, TC_IO, taddr(0, 0, 5), rnd_data(), '1); enq(m, r);
      r = mkreq(2'd3, m % 4, 1'b0, TC_IO, taddr(0, 0, 5), rnd_data(), '1); enq(m, r);
      // no route / not permitted targets
      for (int t = 0; t < NT; t++) begin
        r = mkreq(OP_WRITE, m % 4, 1'b1, TC_IO, taddr(t, 0, 9), rnd_data(), '1); enq(m, r);
      end
      wait_quiet(20000);
    end
    // nothing illegal reached any target memory
    for (int m = 0; m < NM; m++) begin
      for (int t = 0; t < NT; t++) begin
        if (!(CONN[m*NT + t] && (CITADEL_MODE == 0 || PERM[m*NT + t]))) begin end
      end
    end
    `CHK(total_tx == mcount_fwd(), $sformatf("targets received %0d requests, %0d were legal", total_tx, mcount_fwd()));
    check_conservation();
    check_perf(1);
    end_test();
  endtask

  function automatic longint unsigned mcount_fwd();
    longint unsigned n;
    n = 0;
    for (int e = 0; e < NM * NTAG; e++) begin end
    // legal requests = accepted requests that were not answered locally: derived from the DUT-independent mirror
    for (int m = 0; m < NM; m++) n += mc[m][PFM_CPL] - mc[m][PFM_DECERR] - mc[m][PFM_DENIED] - mc[m][PFM_PROTO] - mc[m][PFM_TIMEOUT];
    // PROTO responses can also come from a target echo fault; none are injected in this test
    return n;
  endfunction

  // find a (master, target) pair that is connected and permitted; returns -1 if none
  function automatic int legal_target(input int m);
    for (int t = 0; t < NT; t++) if (CONN[m*NT + t] && (CITADEL_MODE == 0 || PERM[m*NT + t])) return t;
    return -1;
  endfunction

  // ---- protection domains, privilege, run-time policy changes
  task automatic t_domain();
    begin_test("domain_protection");
    // 1. the policy decides: legal, read-only write, privileged region, foreign / ungranted domains
    for (int m = 0; m < NM; m++) begin
      for (int t = 0; t < NT; t++) begin
        rq_t r;
        r = mkreq(OP_WRITE, m % 4, 1'b0, TC_IO, taddr(t, 0, 2), rnd_data(), '1);  enq(m, r);        // legal (if permitted)
        r = mkreq(OP_WRITE, m % 4, 1'b0, TC_IO, taddr(t, 2, 2), rnd_data(), '1);  enq(m, r);        // read-only region
        r = mkreq(OP_READ,  m % 4, 1'b0, TC_IO, taddr(t, 2, 2), '0, '0);          enq(m, r);        // read of it: legal
        r = mkreq(OP_READ,  m % 4, 1'b0, TC_IO, taddr(t, 3, 2), '0, '0);          enq(m, r);        // priv region, no priv
        r = mkreq(OP_READ,  m % 4, 1'b1, TC_IO, taddr(t, 3, 2), '0, '0);          enq(m, r);        // priv region, priv
        r = mkreq(OP_WRITE, 4,     1'b1, TC_IO, taddr(t, 0, 3), rnd_data(), '1);  enq(m, r);        // bound, never granted
        r = mkreq(OP_WRITE, 6,     1'b1, TC_IO, taddr(t, 0, 3), rnd_data(), '1);  enq(m, r);        // not bound to the port
        if (NM > 1) begin
          r = mkreq(OP_WRITE, (m + 1) % 4, 1'b1, TC_IO, taddr(t, 0, 3), rnd_data(), '1); enq(m, r);   // another master's domain
        end
      end
      wait_quiet(60000);
    end
    check_conservation();
    // the scoreboard fails any request that the oracle denies and that nevertheless reaches a target
    begin
      longint unsigned sp;
      rd_cnt(pf_m(0, PFM_V_SPOOF), sp);
      `CHK(sp > 0, "no spoof event counted");
    end
    check_perf(1);

    if (CITADEL_MODE != 0) begin
      // 2. revoke the whole policy at run time: the Citadel denies everything although the (standard-policy) oracle says
      //    "forward" -- the expectation is overridden; a request that reached a target would fail the scoreboard
      elog_clear = 1'b1; tick(1); elog_clear = 1'b0; tick(1);
      for (int i = 0; i < CITN; i++) begin
        pol_we = 1'b1; pol_idx = CITIW'(i); pol_valid = 1'b0; pol_src = '0; pol_dom = '0; pol_priv = 1'b0;
        pol_base = '0; pol_mask = '0; pol_rd = 1'b0; pol_wr = 1'b0; tick(1);
      end
      pol_we = 1'b0; tick(2);
      for (int m = 0; m < NM; m++) begin
        int t;
        t = legal_target(m);
        if (t >= 0) begin
          rq_t r;
          r = mkreq(OP_WRITE, m % 4, 1'b1, TC_IO, taddr(t, 0, 6), rnd_data(), '1);
          r.ovr = 1'b1; r.ovr_st = ST_DENIED;
          enq(m, r);
          r.op = OP_READ; enq(m, r);
        end
      end
      wait_quiet(20000);
      `CHK(elog_valid && elog_status == ST_DENIED && elog_fault == F_NOMAP, $sformatf("error log after revocation: valid=%0d status=%0d fault=%0d", elog_valid, int'(elog_status), int'(elog_fault)));
      `CHK(elog_count >= unsigned'(NM > 0 ? 1 : 0), "error count not incremented");
      // 3. re-grant: the same requests go through again
      prog_policy();
      for (int m = 0; m < NM; m++) begin
        int t;
        t = legal_target(m);
        if (t >= 0) begin
          rq_t r;
          r = mkreq(OP_WRITE, m % 4, 1'b1, TC_IO, taddr(t, 0, 6), rnd_data(), '1); enq(m, r);
          r = mkreq(OP_READ,  m % 4, 1'b1, TC_IO, taddr(t, 0, 6), '0, '0);         enq(m, r);
        end
      end
      wait_quiet(20000);
      check_conservation();
      check_perf(1);
    end
    end_test();
  endtask

  // ---- Citadel unresponsive: fail closed, other masters unaffected, recover by probing
  task automatic t_citadel_fail();
    begin_test("citadel_failclosed");
    if (CITADEL_MODE == 0) begin
      $display("    (skipped: no Citadel in this configuration)");
    end else begin
      int t0, t1;
      int unsigned c0;
      rq_t r;
      t0 = legal_target(0);
      t1 = (NM > 1) ? legal_target(1) : -1;
      tst_cit_stall[0] = 1'b1;
      r = mkreq(OP_WRITE, 0, 1'b1, TC_IO, taddr(t0, 0, 1), rnd_data(), '1);
      r.ovr = 1'b1; r.ovr_st = ST_DENIED;
      c0 = cyc; enq(0, r);
      if (t1 >= 0) begin
        rq_t q;
        q = mkreq(OP_WRITE, 1 % 4, 1'b1, TC_IO, taddr(t1, 0, 2), rnd_data(), '1);
        enq(1, q);
      end
      wait_quiet(8 * CHK_TMO + 400);
      // the wait for the verdict is spent at the master's input, before the request is accepted: input stall cycles
      begin
        longint unsigned st;
        // behind a master-side slice the wait is not visible at the outer edge: read the port's own counter
        if (MST_SLICE[3:0] == 0) st = mc[0][PFM_STALL_IN]; else rd_cnt(pf_m(0, PFM_STALL_IN), st);
        `CHK(st >= unsigned'(CHK_TMO - 1) && st <= unsigned'(CHK_TMO + 8),
             $sformatf("denial after the verdict timeout: %0d input stall cycles (CHK_TMO %0d)", st, CHK_TMO));
      end
      `CHK(o_cit_orphan[0], "port 0 is not failing closed after the verdict timeout");
      `CHK(elog_valid && elog_fault == F_CITTMO, $sformatf("error log: fault %0d, expected F_CITTMO", int'(elog_fault)));
      if (t1 >= 0) `CHK(mc[1][PFM_LAT_MAX] < 40, "master 1 delayed by master 0's Citadel outage");
      // fail closed at once while the port is in the orphan state
      c0 = cyc;
      r = mkreq(OP_READ, 0, 1'b1, TC_IO, taddr(t0, 0, 1), '0, '0);
      r.ovr = 1'b1; r.ovr_st = ST_DENIED;
      enq(0, r);
      wait_quiet(1000);
      `CHK((cyc - c0) < 30, $sformatf("request during the outage took %0d cycles: not failing fast", cyc - c0));
      // the Citadel comes back; after the probe interval the port queries again and traffic flows
      tst_cit_stall[0] = 1'b0;
      tick(8 * CHK_TMO + 20);
      r = mkreq(OP_WRITE, 0, 1'b1, TC_IO, taddr(t0, 0, 4), rnd_data(), '1);
      enq(0, r);
      r = mkreq(OP_READ, 0, 1'b1, TC_IO, taddr(t0, 0, 4), '0, '0);
      r.rdchk = 1'b1; r.rdexp = tmem.exists({8'(t0), taddr(t0, 0, 4)}) ? tmem[{8'(t0), taddr(t0, 0, 4)}] : '0;
      wait_quiet(2000);
      `CHK(!o_cit_orphan[0], "port 0 did not recover after the Citadel came back");
      check_conservation();
      check_perf(1);
    end
    end_test();
  endtask

  // ---- reset under load (whole system and fabric only)
  task automatic t_reset();
    begin_test("reset_under_load");
    for (int round = 0; round < 4; round++) begin
      for (int m = 0; m < NM; m++) begin gap_pct[m] = 10; rrdy_pct[m] = 70; end
      for (int t = 0; t < NT; t++) begin tready_pct[t] = 60; tlat_min[t] = 1; tlat_max[t] = 9; end
      for (int m = 0; m < NM; m++) for (int k = 0; k < 100; k++) enq(m, rand_req(m, 5));
      tick(40 + rr(80));
      // reset in the middle of the traffic; odd rounds reset the fabric only (the targets keep stale responses)
      rst_n = 1'b0;
      flush_req = (round % 2 == 0) ? 2 : 1;
      tick(3);
      `CHK(m_rsp_valid == '0 && t_req_valid == '0, "outputs not idle during reset");
      if (round % 2 == 0) begin tmem.delete(); end
      for (int m = 0; m < NM; m++) begin seq_ctr[m] = 0; for (int t = 0; t < NT; t++) last_seq[m][t] = -1; end
      total_acc = 0; total_dlv = 0;
      rst_n = 1'b1; flush_req = 0;
      tick(3);
      `CHK(dut.u_router.xq_v == '0, "crosspoint buffers not empty after reset");
      for (int m = 0; m < NM; m++) `CHK(dut_pend[m] == 8'd0, "slots not free after reset");
      prog_policy();
      // system works again
      for (int m = 0; m < NM; m++) for (int k = 0; k < 30; k++) enq(m, rand_req(m, 0));
      wait_quiet(100000);
      `CHK(total_acc == total_dlv, "post-reset traffic not conserved");
    end
    check_conservation();
    end_test();
  endtask

  // ---- fairness: saturate target 0 from every connected master with equal class
  task automatic t_fairness();
    int lo, hi, n;
    begin_test("fairness_saturation");
    for (int m = 0; m < NM; m++) for (int k = 0; k < 200; k++) begin
      rq_t r;
      if (CONN[m*NT + 0] && (CITADEL_MODE == 0 || PERM[m*NT + 0])) begin
        r = mkreq(OP_WRITE, m % 4, 1'b0, TC_BULK, taddr(0, 0, rr(16)), rnd_data(), '1);
        enq(m, r);
      end
    end
    wait_quiet(100000);
    lo = 1 << 30; hi = 0; n = 0;
    for (int m = 0; m < NM; m++) if (CONN[m*NT + 0] && (CITADEL_MODE == 0 || PERM[m*NT + 0])) begin
      if (grants_by_src[0][m] < lo) lo = grants_by_src[0][m];
      if (grants_by_src[0][m] > hi) hi = grants_by_src[0][m];
      n++;
    end
    // 200 each requested: with equal classes and equal offered load the shares must be equal
    `CHK(hi - lo <= 1, $sformatf("unfair shares at target 0: min %0d max %0d", lo, hi));
    check_conservation();
    check_perf(1);
    end_test();
  endtask

  // ---- request timeout, response timeout, zombie slots, fault isolation (configurations with TMO > 0)
  task automatic t_timeout();
    int ma, tv, th, mb;
    begin_test("timeout_isolation");
    // victim target tv (dead), healthy target th, master ma (issuer), master mb (bystander)
    ma = -1; tv = -1; th = -1; mb = -1;
    for (int m = 0; m < NM && ma < 0; m++)
      for (int a = 0; a < NT && ma < 0; a++)
        for (int b = 0; b < NT && ma < 0; b++)
          if (a != b && CONN[m*NT + a] && CONN[m*NT + b] && (CITADEL_MODE == 0 || (PERM[m*NT + a] && PERM[m*NT + b]))) begin
            ma = m; tv = a; th = b;
          end
    for (int m = 0; m < NM; m++) if (m != ma && CONN[m*NT + th] && (CITADEL_MODE == 0 || PERM[m*NT + th])) mb = m;
    if (ma < 0) begin $display("    (skipped: no suitable master/targets)"); end
    else if (MST_MAXO[ma*8 +: 8] == 1) begin
      // ---------- single outstanding request: the timed-out slot stays a ZOMBIE (tag and slot reserved) until the late
      // response arrives or the management plane flushes it -- documented limitation of MAXO = 1 with timeouts
      t_dead[tv] = 1; allow_tmo[ma] = 1'b1;
      enq(ma, mkreq(OP_WRITE, ma % 4, 1'b0, TC_IO, taddr(tv, 0, 0), rnd_data(), '1));
      wait_quiet_ign(4 * TMO + 400);
      `CHK(mc[ma][PFM_TIMEOUT] == 1, "no timeout response for the dead target");
      `CHK(mc[ma][PFM_LAT_MAX] >= unsigned'(TMO) && mc[ma][PFM_LAT_MAX] <= unsigned'(TMO + 10), $sformatf("timeout response after %0d cycles (TMO %0d)", mc[ma][PFM_LAT_MAX], TMO));
      if (ISOLATE != 0) `CHK(o_iso[ma*NT + tv], "target not isolated after the timeout");
      // the only slot is a zombie: the next request waits (it is not lost) ...
      allow_tmo[ma] = 1'b0;
      enq(ma, mkreq(OP_READ, ma % 4, 1'b0, TC_IO, taddr(th, 0, 1), '0, '0));
      tick(200);
      `CHK(mc[ma][PFM_CPL] == 1, "a request completed although the only slot is held by a zombie");
      // ... until the management plane reclaims the zombie
      do_flush();
      wait_quiet_ign(2000);
      `CHK(mc[ma][PFM_CPL] == 2, "request did not complete after the zombie was flushed");
      // the target is still isolated: requests to it fail fast; then it comes back
      allow_tmo[ma] = 1'b1;
      if (ISOLATE != 0) begin
        enq(ma, mkreq(OP_READ, ma % 4, 1'b0, TC_IO, taddr(tv, 0, 2), '0, '0));
        wait_quiet_ign(2000);
        `CHK(mc[ma][PFM_TIMEOUT] == 2, "isolated target did not fail fast");
      end
      allow_tmo[ma] = 1'b0;
      t_dead[tv] = 0;
      tick(100);
      iso_clear = '1; tick(2); iso_clear = '0; tick(2);
      enq(ma, mkreq(OP_WRITE, ma % 4, 1'b0, TC_IO, taddr(tv, 0, 3), rnd_data(), '1));
      enq(ma, mkreq(OP_READ,  ma % 4, 1'b0, TC_IO, taddr(tv, 0, 3), '0, '0));
      wait_quiet(4000);
      check_conservation();
      check_perf(1);
    end
    else begin
      // ---------- A: response timeout on a dead target; healthy traffic unaffected; isolation; recovery
      t_dead[tv] = 1; allow_tmo[ma] = 1'b1;
      for (int k = 0; k < 2; k++) enq(ma, mkreq(OP_WRITE, ma % 4, 1'b0, TC_IO, taddr(tv, 0, k), rnd_data(), '1));
      for (int k = 0; k < 24; k++) enq(ma, mkreq(rr(2) == 0 ? OP_READ : OP_WRITE, ma % 4, 1'b0, TC_IO, taddr(th, 0, rr(16)), rnd_data(), '1));
      if (mb >= 0) for (int k = 0; k < 40; k++) enq(mb, mkreq(rr(2) == 0 ? OP_READ : OP_WRITE, mb % 4, 1'b0, TC_IO, taddr(th, 0, rr(16)), rnd_data(), '1));
      wait_quiet_ign(6 * TMO + 4000);
      `CHK(mc[ma][PFM_TIMEOUT] >= 1, "no timeout response for the dead target");
      `CHK(lat_ok_max[ma] < unsigned'(TMO), $sformatf("healthy traffic of the issuing master waited %0d cycles (TMO %0d)", lat_ok_max[ma], TMO));
      if (mb >= 0) `CHK(lat_ok_max[mb] < 200, $sformatf("bystander master delayed by the dead target: %0d cycles", lat_ok_max[mb]));
      `CHK(mc[ma][PFM_LAT_MAX] >= unsigned'(TMO) && mc[ma][PFM_LAT_MAX] <= unsigned'(TMO + 10),
           $sformatf("timeout response after %0d cycles (TMO %0d)", mc[ma][PFM_LAT_MAX], TMO));
      if (ISOLATE != 0) begin
        `CHK(o_iso[ma*NT + tv], "target not isolated after the timeout");
        // isolated: requests to it fail fast instead of waiting TMO again
        begin
          longint unsigned lm;
          lm = mc[ma][PFM_LAT_MAX];
          for (int k = 0; k < 3; k++) enq(ma, mkreq(OP_READ, ma % 4, 1'b0, TC_IO, taddr(tv, 0, 8 + k), '0, '0));
          wait_quiet_ign(2000);
          `CHK(mc[ma][PFM_LAT_MAX] == lm, "requests to the isolated target did not fail fast");
        end
      end
      // revive: the late responses arrive, are swallowed (V_LATE), the slot and tag are reusable, isolation clears
      t_dead[tv] = 0;
      tick(200);
      `CHK(!o_iso[ma*NT + tv], "isolation not cleared by the late response");
      allow_tmo[ma] = 1'b0;
      enq(ma, mkreq(OP_WRITE, ma % 4, 1'b0, TC_IO, taddr(tv, 0, 3), rnd_data(), '1));
      enq(ma, mkreq(OP_READ,  ma % 4, 1'b0, TC_IO, taddr(tv, 0, 3), '0, '0));
      wait_quiet(4000);
      // ---------- B: a target that never accepts: the head-of-line request is cancelled after TMO, never issued
      t_stall[tv] = 1'b1; allow_tmo[ma] = 1'b1;
      for (int k = 0; k < 8; k++) enq(ma, mkreq(OP_WRITE, ma % 4, 1'b0, TC_IO, taddr(tv, 0, 20 + k), rnd_data(), '1));
      for (int k = 0; k < 8; k++) enq(ma, mkreq(OP_READ,  ma % 4, 1'b0, TC_IO, taddr(th, 0, 20 + k), '0, '0));
      wait_quiet_ign(8 * TMO + 4000);
      // with isolation the first timeouts isolate the target and the blocked requests fail at once (~ 2*TMO); without it every blocked
      // request pays its own head-of-line timeout (the 4 requests that did not fit in the buffers: ~ 5*TMO)
      `CHK(lat_ok_max[ma] < unsigned'((ISOLATE != 0) ? 3 * TMO + 200 : 6 * TMO + 400), $sformatf("healthy requests behind the stalled target waited %0d cycles", lat_ok_max[ma]));
      t_stall[tv] = 1'b0;
      tick(300);
      do_flush();
      allow_tmo[ma] = 1'b0;
      wait_quiet(8000);
      tick(50);
      check_conservation();
      check_perf(1);
    end
    end_test();
  endtask

  // ---- fault injection by the targets: duplicates, corrupted echoes, mis-sourced responses; tag reuse by a master
  task automatic t_faults();
    begin_test("faults_dup_echo_badsrc");
    for (int t = 0; t < NT; t++) begin
      t_dup_pct[t] = 8; t_badecho_pct[t] = 6; t_badsrc_pct[t] = 8; t_ooo[t] = (t % 2 == 1);
      tlat_min[t] = 1; tlat_max[t] = 12; t_err_pct[t] = 5;
    end
    for (int m = 0; m < NM; m++) begin rrdy_pct[m] = 80; gap_pct[m] = 20; end
    for (int m = 0; m < NM; m++) for (int k = 0; k < 200; k++) enq(m, rand_req(m, 4));
    wait_quiet(300000);
    check_conservation();
    check_perf(1);
    end_test();
  endtask

  task automatic t_tagreuse();
    int m, ta, tb;
    begin_test("tag_reuse_rejected");
    m = -1; ta = -1; tb = -1;
    for (int k = 0; k < NM && m < 0; k++) if (MST_MAXO[k*8 +: 8] >= 2) begin
      for (int a = 0; a < NT && ta < 0; a++) if (CONN[k*NT + a] && (CITADEL_MODE == 0 || PERM[k*NT + a])) ta = a;
      for (int b = NT - 1; b >= 0 && tb < 0; b--) if (CONN[k*NT + b] && (CITADEL_MODE == 0 || PERM[k*NT + b])) tb = b;
      if (ta >= 0) m = k;
    end
    if (m < 0) begin $display("    (skipped: no master with more than one outstanding request)"); end
    else begin
      rq_t a, b, c;
      for (int t = 0; t < NT; t++) begin tlat_min[t] = 25; tlat_max[t] = 30; t_ooo[t] = 1'b1; end
      a = mkreq(OP_READ,  m % 4, 1'b0, TC_IO, taddr(ta, 0, 1), '0, '0);        a.tagfix = 1'b1; a.tag = TAGW'(5);
      b = mkreq(OP_WRITE, m % 4, 1'b0, TC_IO, taddr(tb, 0, 2), rnd_data(), '1); b.tagfix = 1'b1; b.tag = TAGW'(5);   // same tag, still outstanding
      c = mkreq(OP_WRITE, m % 4, 1'b0, TC_IO, taddr(tb, 0, 3), rnd_data(), '1); c.tagfix = 1'b1; c.tag = TAGW'(6);
      enq(m, a); enq(m, b); enq(m, c);
      wait_quiet(4000);
      `CHK(mc[m][PFM_V_TAGREUSE] == 1, $sformatf("expected one rejected tag reuse, bench saw %0d", mc[m][PFM_V_TAGREUSE]));
      `CHK(mc[m][PFM_CPL] == 2, $sformatf("master %0d: expected 2 responses (the rejected request gets none), got %0d", m, mc[m][PFM_CPL]));
      // after the first transaction completed, the tag is free again
      b.tagfix = 1'b1; enq(m, b);
      wait_quiet(4000);
      `CHK(mc[m][PFM_CPL] == 3, "tag not reusable after its transaction completed");
      check_conservation();
      check_perf(1);
    end
    end_test();
  endtask

  // ---- traffic classes under saturation of one target
  task automatic t_qos();
    int ct;
    begin_test("qos_classes");
    ct = -1;
    for (int t = 0; t < NT && ct < 0; t++) begin
      bit all;
      all = 1'b1;
      for (int m = 0; m < NM; m++) if (!(CONN[m*NT + t] && (CITADEL_MODE == 0 || PERM[m*NT + t]))) all = 1'b0;
      if (all) ct = t;
    end
    if (ct < 0 || NM < 2) begin $display("    (skipped: no common target)"); end
    else begin
      for (int m = 0; m < NM; m++) begin gap_pct[m] = 0; end
      tready_pct[ct] = 50; tlat_min[ct] = 0; tlat_max[ct] = 3;
      for (int m = 0; m < NM; m++) for (int k = 0; k < 300; k++) begin
        rq_t r;
        r = mkreq(OP_WRITE, m % 4, 1'b0, m % 5, taddr(ct, 0, rr(32)), rnd_data(), '1);       // class = master index
        enq(m, r);
      end
      wait_quiet(400000);
      for (int c = 0; c < 5; c++) if (cls_n[c] > 0)
        $display("    QOS class %0d: %0d transactions, mean latency %0d.%02d cycles, max %0d", c, cls_n[c],
                 cls_sum[c] / cls_n[c], (cls_sum[c] * 100 / cls_n[c]) % 100, cls_max[c]);
      if (ARB_MODE == 1 && NM >= 2) begin
        longint unsigned hi_n, lo_n, hi_s, lo_s;
        hi_n = cls_n[(NM - 1) % 5]; hi_s = cls_sum[(NM - 1) % 5];
        lo_n = cls_n[0]; lo_s = cls_sum[0];
        // class order: the highest class must not be slower on average than the lowest (strictly faster when MAXO > 1)
        // only meaningful with real contention and comparable paths (same slice depth on every master)
        begin
          bit uniform, busy;
          uniform = 1'b1; busy = (NM >= 3);
          for (int m = 1; m < NM; m++) if (MST_SLICE[m*4 +: 4] != MST_SLICE[3:0]) uniform = 1'b0;
          for (int m = 0; m < NM; m++) if (MST_MAXO[m*8 +: 8] >= 2) busy = 1'b1;
          if (hi_n > 0 && lo_n > 0 && (NM - 1) % 5 != 0 && uniform && busy) begin
            `CHK(hi_s * lo_n * 20 <= lo_s * hi_n * 21, "the higher class has a worse mean latency than the lowest class");
            // with a large STARVE the classes must make a clear difference (highest class >= 10 % better)
            if (STARVE >= 16 && NM >= 3) `CHK(hi_s * lo_n * 10 <= lo_s * hi_n * 9, "class levels have no effect on latency (STARVE >= 16)");
          end
        end
      end
      check_conservation();
      check_perf(1);
    end
    end_test();
  endtask

  // ---- a stalled endpoint must not block independent traffic of other masters
  task automatic t_indep();
    int ma, ta, mb, tb;
    longint unsigned d0, d1;
    begin_test("stalled_endpoint_independence");
    ma = -1; ta = -1; mb = -1; tb = -1;
    for (int m1 = 0; m1 < NM && ma < 0; m1++)
      for (int m2 = 0; m2 < NM && ma < 0; m2++)
        for (int a = 0; a < NT && ma < 0; a++)
          for (int b = 0; b < NT && ma < 0; b++)
            if (m1 != m2 && a != b && CONN[m1*NT + a] && CONN[m2*NT + b] &&
                (CITADEL_MODE == 0 || (PERM[m1*NT + a] && PERM[m2*NT + b]))) begin ma = m1; mb = m2; ta = a; tb = b; end
    if (ma < 0 || TMO != 0) begin $display("    (skipped)"); end
    else begin
      // baseline: mb streams to tb alone
      for (int k = 0; k < 300; k++) enq(mb, mkreq(rr(2) == 0 ? OP_READ : OP_WRITE, mb % 4, 1'b0, TC_BULK, taddr(tb, 0, rr(32)), rnd_data(), '1));
      wait_quiet(60000);
      d0 = last_dlv[mb] - first_acc[mb];
      check_conservation();
      // jam: ta never ready, ma piles requests onto it; mb streams again
      first_acc[mb] = 64'hFFFF_FFFF_FFFF_FFFF;
      t_stall[ta] = 1'b1;
      for (int k = 0; k < 24; k++) enq(ma, mkreq(OP_WRITE, ma % 4, 1'b0, TC_BULK, taddr(ta, 0, rr(32)), rnd_data(), '1));
      for (int k = 0; k < 300; k++) enq(mb, mkreq(rr(2) == 0 ? OP_READ : OP_WRITE, mb % 4, 1'b0, TC_BULK, taddr(tb, 0, rr(32)), rnd_data(), '1));
      tick(20 * 300);
      begin
        bit done_b;
        done_b = (mq_n[mb] == 0 && !cur_v[mb]);
        d1 = last_dlv[mb] - first_acc[mb];
        $display("    INDEP stream of master %0d to target %0d: %0d cycles alone, %0d cycles while target %0d is stalled by master %0d",
                 mb, tb, d0, d1, ta, ma);
        `CHK(done_b, "bystander stream blocked by the stalled endpoint");
        `CHK(d1 <= d0 + d0 / 20 + 10, "bystander stream slowed by the stalled endpoint");
      end
      t_stall[ta] = 1'b0;                  // release: nothing was lost, everything completes
      wait_quiet(60000);
      check_conservation();
      check_perf(1);
    end
    end_test();
  endtask

  // ---- two independent streams to different targets run at full rate concurrently
  task automatic t_concurrent();
    int m1, m2, a, b;
    longint unsigned d_one, d_two;
    begin_test("concurrent_independent_targets");
    m1 = -1; m2 = -1; a = -1; b = -1;
    for (int x = 0; x < NM && m1 < 0; x++)
      for (int y = 0; y < NM && m1 < 0; y++)
        for (int p = 0; p < NT && m1 < 0; p++)
          for (int q = 0; q < NT && m1 < 0; q++)
            if (x != y && p != q && CONN[x*NT + p] && CONN[y*NT + q] &&
                (CITADEL_MODE == 0 || (PERM[x*NT + p] && PERM[y*NT + q]))) begin m1 = x; m2 = y; a = p; b = q; end
    if (m1 < 0) begin $display("    (skipped)"); end
    else begin
      for (int k = 0; k < 200; k++) enq(m1, mkreq(OP_WRITE, m1 % 4, 1'b0, TC_BULK, taddr(a, 0, rr(32)), rnd_data(), '1));
      wait_quiet(60000);
      d_one = last_dlv[m1] - first_acc[m1];
      first_acc[m1] = 64'hFFFF_FFFF_FFFF_FFFF; first_acc[m2] = 64'hFFFF_FFFF_FFFF_FFFF;
      for (int k = 0; k < 200; k++) begin
        enq(m1, mkreq(OP_WRITE, m1 % 4, 1'b0, TC_BULK, taddr(a, 0, rr(32)), rnd_data(), '1));
        enq(m2, mkreq(OP_WRITE, m2 % 4, 1'b0, TC_BULK, taddr(b, 0, rr(32)), rnd_data(), '1));
      end
      wait_quiet(60000);
      d_two = last_dlv[m1] - first_acc[m1];
      $display("    CONCURRENT master %0d -> target %0d: %0d cycles alone, %0d cycles with master %0d -> target %0d running at the same time",
               m1, a, d_one, d_two, m2, b);
      `CHK(d_two <= d_one + d_one / 20 + 10, "independent traffic to different targets did not run concurrently");
      check_conservation();
      check_perf(1);
    end
    end_test();
  endtask

  // ---- latency of an idle fabric: decomposed and compared with the architecture's formula
  //      request path  = 2 + MST_SLICE[m] + TGT_SLICE[t]   (master-edge accept -> target request valid)
  //      response path = 1 + MST_SLICE[m] + TGT_SLICE[t]   (target response taken -> master response valid)
  task automatic t_latency();
    begin_test("latency_idle");
    for (int t = 0; t < NT; t++) begin tlat_min[t] = 0; tlat_max[t] = 0; end
    for (int m = 0; m < NM; m++) for (int t = 0; t < NT; t++) begin
      if (CONN[m*NT + t] && (CITADEL_MODE == 0 || PERM[m*NT + t])) begin
        rq_t r;
        int  sm, st, ea, eb;
        longint unsigned ta;
        r = mkreq(OP_READ, m % 4, 1'b0, TC_IO, taddr(t, 0, 1), '0, '0);
        enq(m, r);
        wait_quiet(2000);
        sm = int'(MST_SLICE[m*4 +: 4]); st = int'(TGT_SLICE[t*4 +: 4]);
        // a registered Citadel verdict (CIT_LAT = 1) delays the acceptance at the master PORT: an unsliced master sees it as a later
        // handshake, a sliced master has already been accepted into the slice, so the cycle appears in its request path
        ea = 2 + sm + st + ((sm > 0 && CITADEL_MODE != 0) ? CIT_LAT : 0); eb = 1 + sm + st;
        ta = 0;
        for (int k = 0; k < NTAG; k++) if (e_tcyc[m*NTAG + k] > ta) ta = e_tcyc[m*NTAG + k];
        $display("    LATENCY m%0d->t%0d: request path %0d cycles, response path %0d cycles, accept-to-response %0d (master slices %0d, target slices %0d; model %0d / %0d)",
                 m, t, req_path_last, last_resp_path[m], last_lat[m], sm, st, ea, eb);
        `CHK(req_path_last == ea, $sformatf("request path m%0d->t%0d is %0d cycles, expected %0d", m, t, req_path_last, ea));
        `CHK(last_resp_path[m] == eb, $sformatf("response path m%0d->t%0d is %0d cycles, expected %0d", m, t, last_resp_path[m], eb));
      end
    end
    check_conservation();
    end_test();
  endtask

  // ---------------------------------------------------------------- sequencer
  string tests_sel;
  int    seed_arg;
  function automatic bit want(input string name);
    return (tests_sel == "all") || (tests_sel.len() > 0 && (tests_sel.substr(0, 0) != "") && (find_in(tests_sel, name) >= 0));
  endfunction
  function automatic int find_in(input string hay, input string needle);
    int hl, nl;
    hl = hay.len(); nl = needle.len();
    for (int i = 0; i + nl <= hl; i++) if (hay.substr(i, i + nl - 1) == needle) return i;
    return -1;
  endfunction

  initial begin
    if (!$value$plusargs("tests=%s", tests_sel)) tests_sel = "all";
    if ($test$plusargs("debug")) dbg = 1'b1;
    if ($value$plusargs("seed=%d", seed_arg)) rs = 32'h1234_5678 ^ (32'(seed_arg) * 32'h9E37_79B9) ^ 32'h1;
    if (rs == 0) rs = 1;
    zero_mirror();
    for (int m = 0; m < NM; m++) begin clear_master_state(m); seq_ctr[m] = 0; end
    for (int t = 0; t < NT; t++) clear_target_state(t);
    set_defaults();
    m_req_valid = '0; m_req_op = '0; m_req_tag = '0; m_req_dom = '0; m_req_priv = '0; m_req_tc = '0;
    m_req_addr = '0; m_req_wdata = '0; m_req_wstrb = '0; m_rsp_ready = '0; t_req_ready = '0; t_rsp_valid = '0;
    t_rsp_src = '0; t_rsp_tag = '0; t_rsp_dom = '0; t_rsp_op = '0; t_rsp_status = '0; t_rsp_rdata = '0;
    arb_bound = (ARB_MODE == 0) ? NM - 1 : STARVE + NM - 1;
    tick(5);
    $display("tb_meridian: NM=%0d NT=%0d DW=%0d AW=%0d MAXO=%h OOO=%b ARB=%0d CIT=%0d/%0d TMO=%0d slices m=%h t=%h depth=%0d tests=%s",
             NM, NT, DW, AW, MST_MAXO, MST_OOO, ARB_MODE, CITADEL_MODE, CIT_LAT, TMO, MST_SLICE, TGT_SLICE, REQ_DEPTH, tests_sel);
    if (want("routes"))     t_routes();
    if (want("invalid"))    t_invalid();
    if (want("domain"))     t_domain();
    if (want("citfail"))    t_citadel_fail();
    if (want("simul"))      begin t_simul(120, 0); t_simul(200, 10); end
    if (want("random"))     t_random(4);
    if (want("faults"))     t_faults();
    if (want("tagreuse"))   t_tagreuse();
    if (want("reset"))      t_reset();
    if (want("fair"))       t_fairness();
    if (want("qos"))        t_qos();
    if (want("concurrent")) t_concurrent();
    if (want("indep"))      t_indep();
    if (want("timeout") && TMO != 0) t_timeout();
    if (want("latency"))    t_latency();
    $display("  arbitration: longest wait seen in the run %0d transfers of others (bound %0d)", arb_wait_hi, arb_bound);
    $display("SUMMARY tests=%0d failed_tests=%0d checks=%0d failures=%0d cycles=%0d", n_tests, n_tests_fail, n_chk, n_fail, cyc);
    if (n_fail == 0 && n_tests > 0) $display("RESULT: PASS"); else $display("RESULT: FAIL");
    $finish;
  end

  // watchdog
  initial begin
    #2000000000;
    $display("RESULT: FAIL (global timeout)");
    $finish;
  end
endmodule
