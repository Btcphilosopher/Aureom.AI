#!/usr/bin/env python3
"""Mutation check of the simulation regression: each mutant is ONE deliberate RTL defect applied to a private copy of the sources; the
named configuration must FAIL (some check must notice).  A survivor means the bench has a blind spot.  Writes reports/mutation.md.

usage: mutate.py [--jobs 2] [--only substr]
"""
import argparse, json, os, shutil, subprocess, sys, re, time
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
P = "sf_meridian_pkg::"
# name, file, old, new, config, what
M = [
 ("M01_ignore_citadel", "sf_meridian_mport.sv", "wire permit  = !pre_err && vd_ok;", "wire permit  = !pre_err;", "ref_2x2", "Citadel verdict ignored"),
 ("M02_no_domain_binding", "sf_meridian_mport.sv", "wire dom_bound = DOM_ALLOW[rq_dom];", "wire dom_bound = 1'b1;", "ref_2x2", "domain-binding check removed"),
 ("M03_citadel_fail_open", "sf_meridian_mport.sv", "vd_valid = 1'b1; vd_ok = 1'b0; vd_fault = " + P + "F_CITTMO;", "vd_valid = 1'b1; vd_ok = 1'b1; vd_fault = " + P + "F_CITTMO;", "ref_2x2", "Citadel outage fails OPEN (orphan state permits)"),
 ("M04_denial_wrong_status", "sf_meridian_mport.sv", "else               begin err_status = " + P + "ST_DENIED;  err_fault = vd_fault;  end", "else               begin err_status = " + P + "ST_DECERR;  err_fault = vd_fault;  end", "ref_2x2", "denial reported as decode error"),
 ("M05_src_stamp", "sf_meridian_router.sv", "eg_word = {gidx, w};", "eg_word = {" + P + "clog2c(NM)'(0), w};", "ref_2x2", "source stamp always 0"),
 ("M06_tag_lost", "sf_meridian_mport.sv", "assign xp_word = {rq_op, rq_tag, rq_dom,", "assign xp_word = {rq_op, TAGW'(0), rq_dom,", "ref_2x2", "tag not forwarded"),
 ("M07_domain_lost", "sf_meridian_mport.sv", "assign xp_word = {rq_op, rq_tag, rq_dom,", "assign xp_word = {rq_op, rq_tag, DOMW'(0),", "ref_2x2", "domain not forwarded"),
 ("M08_priv_lost", "sf_meridian_mport.sv", "assign xp_word = {rq_op, rq_tag, rq_dom, rq_priv,", "assign xp_word = {rq_op, rq_tag, rq_dom, 1'b0,", "ref_2x2", "privilege not forwarded"),
 ("M09_steer_all", "sf_meridian_router.sv", "assign mr_valid[m*NT + t]                   = rs_v && (r_src == SRCW'(m)) && CONN[m*NT + t];", "assign mr_valid[m*NT + t]                   = rs_v && CONN[m*NT + t];", "ref_2x2", "responses steered to every master"),
 ("M10_wdata_corrupt", "sf_meridian_router.sv", "assign t_req_wdata[t*DW +: DW]       = eg_out[DW/8 +: DW];", "assign t_req_wdata[t*DW +: DW]       = eg_out[DW/8 +: DW] ^ DW'(1);", "ref_2x2", "write data bit flipped"),
 ("M11_strobe_corrupt", "sf_meridian_router.sv", "assign t_req_wstrb[t*(DW/8) +: DW/8] = eg_out[0 +: DW/8];", "assign t_req_wstrb[t*(DW/8) +: DW/8] = ~eg_out[0 +: DW/8];", "ref_2x2", "strobes inverted"),
 ("M12_arb_ptr_frozen", "sf_meridian_arbiter.sv", "if (xfer) ptr_q <= (gidx == IW'(N - 1)) ? '0 : gidx + IW'(1);", "if (xfer) ptr_q <= ptr_q;", "stress_4x2_rr", "round-robin pointer frozen"),
 ("M13_arb_no_aging", "sf_meridian_arbiter.sv", "urgent[i] = (MODE != 0) && (age_q[i*AGW +: AGW] >= AGW'(STARVE));", "urgent[i] = 1'b0;", "stress_4x2_s30", "aging disabled: starvation"),
 ("M14_arb_ignore_class", "sf_meridian_arbiter.sv", "else                  eff[i] = {1'b0, lvl[i*LW +: LW]};", "else                  eff[i] = '0;", "stress_4x2_s30", "class levels ignored"),
 ("M15_pop_ignores_ready", "sf_meridian_router.sv", "assign xq_pop[m*NT + t] = grant[m] && en;", "assign xq_pop[m*NT + t] = grant[m];", "stress_4x2", "request popped although the egress stage is full (loss)"),
 ("M16_push_ignores_full", "sf_meridian_mport.sv", "(!fwd || xp_ready[d_tgt] || hol_exp)", "(!fwd || 1'b1 || hol_exp)", "stress_4x2", "request pushed into a full buffer (loss)"),
 ("M17_fifo_overflow", "../../third_party/p22/sfn_fifo.sv", "assign in_ready  = (cnt_q != CNTW'(DEPTH)) || ((PASS_FULL != 0) && out_ready);", "assign in_ready  = 1'b1;", "stress_4x2", "vendored FIFO accepts when full"),
 ("M18_tag_reuse_accepted", "sf_meridian_mport.sv", "if (s_st[i*3 +: 3] != S_FREE && s_tag[i*TAGW +: TAGW] == rq_tag) tag_busy = 1'b1;", "if (1'b0) tag_busy = 1'b1;", "m3t2_ooo", "illegal tag reuse not rejected"),
 ("M19_inorder_broken", "sf_meridian_mport.sv", "elig[i] = (s_st[i*3 +: 3] == S_DONE) && ((OOO != 0) || !older_pend[i]);", "elig[i] = (s_st[i*3 +: 3] == S_DONE);", "m3t2_ooo", "in-order delivery not enforced"),
 ("M20_echo_unchecked", "sf_meridian_mport.sv", "r_echo_ok[i] = (tr_dom[tt*DOMW +: DOMW] == s_dom[i*DOMW +: DOMW]) &&", "r_echo_ok[i] = 1'b1 || (tr_dom[tt*DOMW +: DOMW] == s_dom[i*DOMW +: DOMW]) &&", "ref_2x2", "response echo not checked"),
 ("M21_no_timeout", "sf_meridian_mport.sv", "tmo_hit[i] = (TMO != 0) && (s_st[i*3 +: 3] == S_ISS)", "tmo_hit[i] = 1'b0 && (s_st[i*3 +: 3] == S_ISS)", "m2t2_tmo", "response timeout never fires"),
 ("M22_zombie_freed_early", "sf_meridian_mport.sv", "s_st[i*3 +: 3] <= s_zf[i] ? S_ZOMB : S_FREE;", "s_st[i*3 +: 3] <= S_FREE;", "m2t2_tmo", "timed-out slot freed at once (tag reusable before the late response)"),
 ("M23_no_isolation", "sf_meridian_mport.sv", "if (tmo_hit[i]) iso_q[s_tgt[i*TW +: TW]] <= 1'b1;", "if (1'b0) iso_q[s_tgt[i*TW +: TW]] <= 1'b1;", "m2t2_tmo", "timeout does not isolate the target"),
 ("M24_hol_never_cancels", "sf_meridian_mport.sv", "wire hol_exp = blocked && (TMO != 0) && (hol_cnt >= LATW'(TMO - 1));", "wire hol_exp = 1'b0;", "m2t2_tmo_noiso", "head-of-line request never cancelled (isolation off: only the watchdog can help)"),
 ("M25_perf_cplerr", "sf_meridian_perf.sv", "CW'(dl && st != " + P + "ST_OKAY)", "CW'(dl)", "ref_2x2", "error-completion counter counts every completion"),
 ("M26_reset_slots", "sf_meridian_mport.sv", "s_st <= '0; s_tag <= '0;", "s_tag <= '0;", "ref_2x2", "slot state not cleared by reset"),
 ("M27_alignment_unchecked", "sf_meridian_decoder.sv", "misaligned = (CHECK_ALIGN != 0) && (DW > 8) && (addr[OFF-1:0] != '0);", "misaligned = 1'b0;", "ref_2x2", "misaligned addresses accepted"),
 ("M28_reach_ignores_conn", "sf_meridian_decoder.sv", "reach      = hit && CONN[tgt];", "reach      = hit;", "m4t3_mixed", "topology connectivity ignored"),
 ("M29_deny_still_forwards_domain", "sf_meridian_mport.sv", "wire fwd     = decide && permit;", "wire fwd     = decide && (permit || (!pre_err && vd_fault == " + P + "F_DOMAIN));", "ref_2x2", "requests denied for the domain still forwarded"),
 ("M31_duplicate_accepted", "sf_meridian_mport.sv", "if (tr_valid[t] && (s_st[i*3 +: 3] == S_ISS || s_st[i*3 +: 3] == S_ZOMB) &&", "if (tr_valid[t] && (s_st[i*3 +: 3] == S_ISS || s_st[i*3 +: 3] == S_ZOMB || s_st[i*3 +: 3] == S_DONE) &&", "ref_2x2", "a completed slot accepts a second response"),
 ("M30_slot_status_lost", "sf_meridian_mport.sv", "s_status[i*3 +: 3]   <= r_status[i*3 +: 3];", "s_status[i*3 +: 3]   <= " + P + "ST_OKAY;", "ref_2x2", "target error status replaced by OKAY"),
]

def run(m):
    name, f, old, new, cfg, what = m
    t0 = time.time()
    d = os.path.join(ROOT, "build", "mut", name)
    shutil.rmtree(d, ignore_errors=True)
    for sub in ("rtl", "third_party", "tests"):
        shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub))
    path = os.path.normpath(os.path.join(d, "rtl", "albion", f))
    src = open(path).read()
    if old not in src:
        return dict(name=name, what=what, cfg=cfg, result="ANCHOR NOT FOUND", secs=0, detail=old[:70])
    open(path, "w").write(src.replace(old, new, 1))
    r = subprocess.run([sys.executable, os.path.join(HERE, "run_tb.py"), cfg, "--root", d, "--build", os.path.join(d, "b"), "--quiet"],
                       capture_output=True, text=True, env=dict(os.environ, VJOBS="2"))
    out = r.stdout + r.stderr
    killed = (r.returncode != 0)
    first = next((l.strip() for l in out.splitlines() if "FAIL" in l), "")
    if r.returncode in (2,):
        first = "BUILD ERROR: " + out[-200:]
    shutil.rmtree(os.path.join(d, "b"), ignore_errors=True)
    return dict(name=name, what=what, cfg=cfg, result="KILLED" if killed and r.returncode != 2 else ("BUILD ERROR" if r.returncode == 2 else "SURVIVED"),
                secs=round(time.time() - t0), detail=first[:150])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    todo = [m for m in M if any(x in m[0] for x in a.only.split(","))]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, todo))
    json.dump(res, open(os.path.join(ROOT, "reports", "mutation.json"), "w"), indent=1)
    L = ["# Mutation check of the simulation regression", "",
         "Each mutant is one deliberate RTL defect on a private copy of the sources (scripts/mutate.py); the named configuration of tb_meridian",
         "(all tests, seed 1) must FAIL. KILLED = some check noticed; SURVIVED = blind spot.", "",
         "| mutant | defect | configuration | result | first failing check | s |", "|---|---|---|---|---|---|"]
    for r in res:
        L.append(f"| {r['name']} | {r['what']} | {r['cfg']} | **{r['result']}** | {r['detail']} | {r['secs']} |")
    k = sum(1 for r in res if r["result"] == "KILLED")
    L += ["", f"**{k} / {len(res)} mutants killed.**", ""]
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(L))
    print("\n".join(L))
    return 0 if k == len(res) else 1

if __name__ == "__main__":
    sys.exit(main())
