#!/usr/bin/env python3
"""Build the delivery archive (nothing is committed to any repository): MANIFEST.sha256 + zip of the project without build products."""
import hashlib, os, sys, zipfile
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
NAME = os.path.basename(ROOT)
SKIP = ("build", "__pycache__", ".git")
def files():
    for d, ds, fs in os.walk(ROOT):
        ds[:] = sorted(x for x in ds if x not in SKIP)
        for f in sorted(fs):
            if f.endswith((".pyc",)) or f == "MANIFEST.sha256" or f.endswith(".zip"): continue
            yield os.path.relpath(os.path.join(d, f), ROOT)
fl = list(files())
with open(os.path.join(ROOT, "MANIFEST.sha256"), "w") as m:
    for f in fl: m.write(hashlib.sha256(open(os.path.join(ROOT, f), "rb").read()).hexdigest() + "  " + f + "\n")
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(ROOT), NAME + ".zip")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in fl + ["MANIFEST.sha256"]: z.write(os.path.join(ROOT, f), os.path.join(NAME, f))
print(out, len(fl) + 1, "files")
