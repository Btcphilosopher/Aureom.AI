#!/usr/bin/env python3
"""Static sanity check of a Meridian configuration: address windows must not overlap, MAXO in 1..16, matrix sizes, tag space >= MAXO.
Run on every configuration of scripts/meridian_cfgs.py (also usable on a user's own TGT_BASE / TGT_MASK lists).
usage: check_config.py            (checks all bundled configurations)
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from meridian_cfgs import CONFIGS

def windows_overlap(base, mask):
    """windows (addr & mask) == base overlap iff the bases agree on the common mask bits"""
    bad = []
    for i in range(len(base)):
        for j in range(i + 1, len(base)):
            c = mask[i] & mask[j]
            if (base[i] ^ base[j]) & c == 0: bad.append((i, j))
    return bad

def main():
    ok = True
    for name, p in CONFIGS.items():
        nm, nt = p["NM"], p["NT"]
        base = [(t << 28) for t in range(nt)]; mask = [0xF0000000] * nt          # the bench's address map
        problems = []
        if windows_overlap(base, mask): problems.append("windows overlap")
        if nt > 16: problems.append("more than 16 targets with a 4-bit window")
        maxo = [(p["MST_MAXO"][0] >> (8 * m)) & 0xFF for m in range(nm)]
        if any(x < 1 or x > 16 for x in maxo): problems.append(f"MAXO out of range {maxo}")
        if any(x > 16 for x in maxo): problems.append("MAXO exceeds the 4-bit tag space")
        if p["CONN"][1] != nm * nt: problems.append("CONN size")
        print(f"{name:20s} {'OK' if not problems else 'PROBLEM: ' + '; '.join(problems)}")
        ok &= not problems
    return 0 if ok else 1
if __name__ == "__main__":
    sys.exit(main())
