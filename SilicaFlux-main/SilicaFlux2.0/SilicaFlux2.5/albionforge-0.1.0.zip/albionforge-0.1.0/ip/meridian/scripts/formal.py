#!/usr/bin/env python3
"""Formal jobs: SymbiYosys (Yosys front end, smtbmc + z3).  BMC to a depth, and k-induction ("prove") where it closes.

Every job is run against the RTL as it is; "mutant" jobs run the same harness on one deliberately broken copy and MUST produce a
counterexample (non-vacuity: the properties really can fail).  Writes reports/formal.md and reports/formal.json.
usage: formal.py [--jobs N] [--only substr]
Needs: yowasp-sby / sby, yosys, yosys-smtbmc, z3 on PATH (see docs/meridian/07_VERIFICATION.md).
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(ROOT, "build", "formal")
R = lambda *f: [os.path.join(ROOT, "rtl", "albion", x) for x in f]
T = lambda *f: [os.path.join(ROOT, "third_party", "p22", x) for x in f]
H = lambda f: os.path.join(ROOT, "tests", "meridian", "formal", f)
PKG = T("sfn_pkg.sv") + R("sf_meridian_pkg.sv")
FIFO = PKG + T("sfn_fifo.sv") + [H("fv_fifo.sv")]
SLICE = PKG + T("sfn_fifo.sv") + R("sf_meridian_slice.sv") + [H("fv_slice.sv")]
ARB = PKG + R("sf_meridian_arbiter.sv") + [H("fv_arbiter.sv")]
DEC = PKG + R("sf_meridian_decoder.sv") + [H("fv_decoder.sv")]
FAB = PKG + T("sfn_fifo.sv") + R("sf_meridian_decoder.sv", "sf_meridian_arbiter.sv", "sf_meridian_slice.sv", "sf_meridian_citadel_ref.sv",
                                  "sf_meridian_mport.sv", "sf_meridian_router.sv", "sf_meridian_perf.sv", "sf_meridian_fabric.sv") + [H("fv_fabric.sv")]

# name, top, files, params, mode, depth, expect, mutation (file basename, old, new) or None, note
JOBS = []
JOBS.append(("fifo_d1_prove", "fv_fifo", FIFO, {"W": 4, "DEPTH": 1}, "prove", 14, "PASS", None, "sfn_fifo depth 1: count / order / integrity / stability (unbounded)"))
for d in (2, 3, 4):
    JOBS.append((f"fifo_d{d}_bmc", "fv_fifo", FIFO, {"W": 4, "DEPTH": d}, "bmc", {2: 16, 3: 20, 4: 16}[d], "PASS", None, "sfn_fifo: count / order / integrity / stability"))
for st in (1, 2, 3):
    JOBS.append((f"slice_s{st}_bmc", "fv_slice", SLICE, {"W": 3, "STAGES": st}, "bmc", 16, "PASS", None, "conservation, order, integrity, stability"))
    JOBS.append((f"slice_s{st}_latency", "fv_slice", SLICE, {"W": 3, "STAGES": st, "LAT": 1}, "bmc", 18, "PASS", None, "bounded latency with an always-ready sink"))
for (n, mode, sv, dep) in ((2, 1, 3, 26), (3, 1, 2, 24), (4, 1, 1, 18), (3, 0, 0, 24), (4, 0, 0, 20)):
    nm = f"arb_n{n}_{'qos' if mode else 'rr'}{'_s%d' % sv if mode else ''}"
    JOBS.append((nm + "_bmc", "fv_arbiter", ARB, {"N": n, "MODE": mode, "STARVE": sv}, "bmc", dep, "PASS", None, "one-hot, work conserving, starvation bound"))
JOBS.append(("decoder_bmc", "fv_decoder", DEC, {}, "bmc", 2, "PASS", None, "windows, lowest index wins, reach, alignment"))
for adv in (0, 1):
    for tsl in (0, 1):
        JOBS.append((f"fabric_adv{adv}_tsl{tsl}_bmc", "fv_fabric", FAB, {"ADV": adv, "TSL": tsl, "TMO": 0}, "bmc", 10 + tsl, "PASS", None,
                     "authorization, routing, identity, exactly-once, response ownership " + ("(responses only; adversarial targets)" if adv else "(targets obey their contract)")))
JOBS.append(("fabric_tmo_bmc", "fv_fabric", FAB, {"ADV": 0, "TSL": 0, "TMO": 3}, "bmc", 11, "PASS", None, "same with request / response timeouts and zombie slots"))
JOBS.append(("fabric_cover", "fv_fabric", FAB, {"ADV": 0, "TSL": 0, "TMO": 0}, "cover", 11, "PASS", None, "non-vacuity: permitted / denied / decode-error transactions complete within the checked depth"))

# ------------------------------------------------------------------ non-vacuity: each mutant must be caught
MUT = [
  ("mut_fifo_overflow", "fv_fifo", FIFO, {"W": 4, "DEPTH": 3}, "bmc", 12, ("sfn_fifo.sv", "assign in_ready  = (cnt_q != CNTW'(DEPTH)) || ((PASS_FULL != 0) && out_ready);", "assign in_ready  = 1'b1;"), "FIFO accepts when full"),
  ("mut_fifo_underflow", "fv_fifo", FIFO, {"W": 4, "DEPTH": 3}, "bmc", 12, ("sfn_fifo.sv", "if (pop)  rd_q <= inc(rd_q);", "if (out_ready)  rd_q <= inc(rd_q);"), "read pointer moves without data"),
  ("mut_slice_loss", "fv_slice", SLICE, {"W": 3, "STAGES": 2}, "bmc", 12, ("sfn_fifo.sv", "if (push) wr_q <= inc(wr_q);", "if (push && !(in_data == '0)) wr_q <= inc(wr_q);"), "a stage loses an element"),
  ("mut_arb_ptr", "fv_arbiter", ARB, {"N": 3, "MODE": 0, "STARVE": 0}, "bmc", 20, ("sf_meridian_arbiter.sv", "if (xfer) ptr_q <= (gidx == IW'(N - 1)) ? '0 : gidx + IW'(1);", "if (xfer) ptr_q <= ptr_q;"), "round-robin pointer frozen: starvation"),
  ("mut_arb_aging", "fv_arbiter", ARB, {"N": 3, "MODE": 1, "STARVE": 2}, "bmc", 26, ("sf_meridian_arbiter.sv", "urgent[i] = (MODE != 0) && (age_q[i*AGW +: AGW] >= AGW'(STARVE));", "urgent[i] = 1'b0;"), "aging removed: low class starves"),
  ("mut_arb_ignore_req", "fv_arbiter", ARB, {"N": 3, "MODE": 0, "STARVE": 0}, "bmc", 6, ("sf_meridian_arbiter.sv", "elig[i]  = req[i] && (eff[i] == top);", "elig[i]  = (eff[i] == top);"), "grant to a non-requester"),
  ("mut_dec_lowest", "fv_decoder", DEC, {}, "bmc", 2, ("sf_meridian_decoder.sv", "for (int t = NT - 1; t >= 0; t--) begin", "for (int t = 0; t < NT; t++) begin"), "highest index wins"),
  ("mut_fab_ignore_citadel", "fv_fabric", FAB, {"ADV": 0, "TSL": 0, "TMO": 0}, "bmc", 10, ("sf_meridian_mport.sv", "wire permit  = !pre_err && vd_ok;", "wire permit  = !pre_err;"), "Citadel verdict ignored"),
  ("mut_fab_no_domain_bind", "fv_fabric", FAB, {"ADV": 0, "TSL": 0, "TMO": 0}, "bmc", 10, ("sf_meridian_mport.sv", "wire dom_bound = DOM_ALLOW[rq_dom];", "wire dom_bound = 1'b1;"), "domain binding check removed"),
  ("mut_fab_src_stamp", "fv_fabric", FAB, {"ADV": 0, "TSL": 0, "TMO": 0}, "bmc", 10, ("sf_meridian_router.sv", "eg_word = {gidx, w};", "eg_word = {SRCW'(0), w};"), "source stamp wrong"),
  ("mut_fab_tag_lost", "fv_fabric", FAB, {"ADV": 0, "TSL": 0, "TMO": 0}, "bmc", 10, ("sf_meridian_mport.sv", "assign xp_word = {rq_op, rq_tag, rq_dom,", "assign xp_word = {rq_op, TAGW'(0), rq_dom,"), "tag not preserved"),
  ("mut_fab_steer", "fv_fabric", FAB, {"ADV": 0, "TSL": 0, "TMO": 0}, "bmc", 10, ("sf_meridian_router.sv", "assign mr_valid[m*NT + t]                   = rs_v && (r_src == SRCW'(m)) && CONN[m*NT + t];", "assign mr_valid[m*NT + t]                   = rs_v && CONN[m*NT + t];"), "responses steered to every master"),
]
for (nm, top, files, params, mode, depth, mut, note) in MUT:
    JOBS.append((nm, top, files, params, mode, depth, "FAIL", mut, note))

def mutate(name, files, mut):
    d = os.path.join(OUT, name, "mut"); os.makedirs(d, exist_ok=True)
    out = []
    for f in files:
        if os.path.basename(f) == mut[0]:
            src = open(f).read()
            assert mut[1] in src, (name, "mutation anchor not found: " + mut[1][:60])
            g = os.path.join(d, mut[0]); open(g, "w").write(src.replace(mut[1], mut[2], 1)); out.append(g)
        else:
            out.append(f)
    return out

def run_job(job):
    name, top, files, params, mode, depth, expect, mut, note = job
    t0 = time.time()
    d = os.path.join(OUT, name)
    shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
    if mut: files = mutate(name, files, mut)
    ch = "\n".join(f"chparam -set {k} {v} {top}" for k, v in params.items())
    sby = (f"[options]\nmode {mode}\ndepth {depth}\n\n[engines]\nsmtbmc z3\n\n[script]\n"
           f"read_verilog -sv -formal -DFORMAL -DSYNTHESIS {' '.join(os.path.basename(f) for f in files)}\n{ch}\nprep -top {top}\nmemory_map\n\n[files]\n" +
           "\n".join(files) + "\n")
    open(os.path.join(d, "job.sby"), "w").write(sby)
    try:
        r = subprocess.run(["sby", "-f", "job.sby"], cwd=d, capture_output=True, text=True, timeout=int(os.environ.get("FORMAL_TIMEOUT", "1500")))
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        out = "TIMEOUT"
    m = re.search(r"DONE \((\w+), rc=(\d+)\)", out)
    status = m.group(1) if m else ("TIMEOUT" if out == "TIMEOUT" else "ERROR")
    ok = (status == "PASS" and expect == "PASS") or (status == "FAIL" and expect == "FAIL")
    bounded = (mode == "bmc")
    # "prove" jobs that do not close return UNKNOWN: reported honestly, not as failures of the design
    if mode == "prove" and status == "UNKNOWN" and expect == "PASS": ok = None
    detail = ""
    if status in ("ERROR",): detail = out[-700:]
    return dict(job=name, top=top, params=params, mode=mode, depth=depth, expect=expect, status=status, ok=ok, secs=round(time.time() - t0, 1),
                note=note, detail=detail)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    jobs = [j for j in JOBS if any(x in j[0] for x in a.only.split(","))]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run_job, jobs))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "formal.json"), "w"), indent=1)
    L = ["# Formal verification (SymbiYosys: Yosys + smtbmc + z3)", "",
         "`bmc` = bounded model check to the stated depth (a bounded proof: no counterexample within that many cycles). `prove` = BMC base case plus",
         "k-induction: PASS means an UNBOUNDED proof; UNKNOWN means induction did not close at that depth (the property was still checked by BMC to the depth;",
         "it is NOT counted as proved). `mutant` jobs run the same harness on a deliberately broken copy of the RTL and must FAIL (counterexample found):",
         "they show the properties are not vacuous.", "",
         "| job | harness | mode | depth | expected | result | as expected | time |", "|---|---|---|---|---|---|---|---|"]
    for r in res:
        asx = "yes" if r["ok"] else ("**no**" if r["ok"] is False else "unknown (not proved)")
        L.append(f"| {r['job']} | {r['top']} {json.dumps(r['params'])} | {r['mode']} | {r['depth']} | {r['expect']} | {r['status']} | {asx} | {r['secs']} s |")
    nok = sum(1 for r in res if r["ok"]); nbad = sum(1 for r in res if r["ok"] is False); nunk = sum(1 for r in res if r["ok"] is None)
    unb = sum(1 for r in res if r["mode"] == "prove" and r["status"] == "PASS")
    L += ["", f"**{nok} / {len(res)} jobs as expected, {nbad} not as expected, {nunk} induction attempts did not close; {unb} unbounded proofs.**", ""]
    for r in res:
        if r["ok"] is False and r["detail"]: L += [f"### {r['job']}", "```", r["detail"], "```"]
    open(os.path.join(ROOT, "reports", "formal.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))
    return 1 if nbad else 0

if __name__ == "__main__":
    sys.exit(main())
