#!/usr/bin/env python3
"""Collect the per-route idle latencies measured by the latency_idle test (and asserted against 2 + S_m + S_t / 1 + S_m + S_t)
from the regression logs; writes reports/latency.md."""
import os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
LOGS = os.path.join(ROOT, "reports", "logs")
rows = []
for f in sorted(os.listdir(LOGS)):
    m = re.match(r"tb_(.+)_seed1\.log", f)
    if not m: continue
    cfg = m.group(1)
    for l in open(os.path.join(LOGS, f)):
        mm = re.search(r"LATENCY m(\d+)->t(\d+): request path (\d+) cycles, response path (\d+) cycles, accept-to-response (\d+) \(master slices (\d+), target slices (\d+); model (\d+) / (\d+)\)", l)
        if mm: rows.append((cfg,) + tuple(int(x) for x in mm.groups()))
L = ["# Idle-fabric latency per route (measured, and asserted against the model by the `latency_idle` test)", "",
     "Request path = master-edge accept to target request valid; response path = target response taken to master response valid; the target answers",
     "in 0 cycles. Model: request 2 + S_m + S_t, response 1 + S_m + S_t (S_m = `MST_SLICE[m]`, S_t = `TGT_SLICE[t]`). `match` = measured equals model.", "",
     "| configuration | route | S_m | S_t | request path | response path | accept-to-response | model (req / rsp) | match |", "|---|---|---|---|---|---|---|---|---|"]
bad = 0
for (cfg, m, t, rq, rs, tot, sm, st, mq, mr) in rows:
    ok = (rq == mq and rs == mr)
    bad += (not ok)
    L.append(f"| {cfg} | m{m} -> t{t} | {sm} | {st} | {rq} | {rs} | {tot} | {mq} / {mr} | {'yes' if ok else '**NO**'} |")
L += ["", f"**{len(rows) - bad} / {len(rows)} routes match the model.**", ""]
open(os.path.join(ROOT, "reports", "latency.md"), "w").write("\n".join(L))
print("\n".join(L[-3:]))
sys.exit(1 if bad or not rows else 0)
