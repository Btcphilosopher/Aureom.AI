#!/usr/bin/env python3
"""Arbiter differential / property runs (tests/meridian/tb/tb_arb_diff.sv): writes reports/arbiter.md."""
import os, subprocess, sys, shutil, re
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
V = os.environ.get("VERILATOR", "verilator-cli")
JOBS = [(n, 0, 0) for n in (2, 3, 4, 5, 7, 8)] + [(n, 1, s) for n in (2, 3, 4, 5, 7) for s in (0, 1, 3, 8)] + [(1, 1, 2), (8, 1, 12)]

def main():
    rows = []
    files = [os.path.join(ROOT, f) for f in ("third_party/p22/sfn_pkg.sv", "rtl/albion/sf_meridian_pkg.sv", "third_party/p22/sfn_qos_arbiter.sv",
                                              "rtl/albion/sf_meridian_arbiter.sv", "tests/meridian/tb/tb_arb_diff.sv")]
    for (n, m, s) in JOBS:
        b = os.path.join(ROOT, "build", f"arb_n{n}_m{m}_s{s}")
        shutil.rmtree(b, ignore_errors=True)
        cmd = [V, "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", "tb_arb_diff",
               "--Mdir", b, "-o", "sim", f"-GN={n}", f"-GMODE={m}", f"-GSTARVE={s}", "-GNCYC=300000",
               "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include"] + files
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            rows.append((n, m, s, "BUILD FAIL", r.stderr[-200:])); continue
        o = subprocess.run([os.path.join(b, "sim")], capture_output=True, text=True).stdout
        ok = "RESULT: PASS" in o
        mm = re.search(r"(\d+) cycles compared, longest wait (\d+) \(bound (\d+)\)", o)
        rows.append((n, m, s, "PASS" if ok else "FAIL", mm.groups() if mm else o[-200:]))
        print(rows[-1], flush=True)
    L = ["# Arbiter: differential test against the verified sfn_qos_arbiter, and starvation bound", "",
         "`sf_meridian_arbiter` vs `third_party/p22/sfn_qos_arbiter.sv` (Project 22, unmodified, stall = 0), compared every cycle on grant / index / valid /",
         "urgent under random requests, classes and downstream `en` (tests/meridian/tb/tb_arb_diff.sv). RR mode is compared with STARVE = 0.",
         "The longest observed wait of a continuously requesting requester is compared with the bound (QOS: STARVE + N - 1; RR: N - 1).", "",
         "| N | mode | STARVE | result | cycles compared | longest wait | bound |", "|---|---|---|---|---|---|---|"]
    for (n, m, s, res, d) in rows:
        d = d if isinstance(d, tuple) else (d, "", "")
        L.append(f"| {n} | {'QOS' if m else 'RR'} | {s} | {res} | {d[0]} | {d[1]} | {d[2]} |")
    npass = sum(1 for r in rows if r[3] == "PASS")
    L += ["", f"**{npass} / {len(rows)} configurations passed.**", ""]
    open(os.path.join(ROOT, "reports", "arbiter.md"), "w").write("\n".join(L))
    return 0 if npass == len(rows) else 1

if __name__ == "__main__":
    sys.exit(main())
