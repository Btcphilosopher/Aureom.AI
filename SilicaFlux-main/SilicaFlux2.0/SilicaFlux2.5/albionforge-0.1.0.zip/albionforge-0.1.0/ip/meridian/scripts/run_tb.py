#!/usr/bin/env python3
"""Build and run tb_meridian for one configuration.

usage: run_tb.py CONFIG [--tests a,b] [--seed N] [--rtl PATH_TO_RTL_ROOT] [--tag NAME] [--quiet]
Verilator 5 with --binary --timing.  Exit status 0 = RESULT: PASS and no UNOPTFLAT (combinational loop) warning.
"""
import argparse, os, subprocess, sys, shutil, re
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from meridian_cfgs import CONFIGS, gflags

ROOT = os.path.abspath(os.path.join(HERE, ".."))
VERILATOR = os.environ.get("VERILATOR", "verilator-cli")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--tests", default="all")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--root", default=ROOT, help="project root holding rtl/ and tests/ (mutation runs use a copy)")
    ap.add_argument("--build", default=None)
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--nobuild", action="store_true")
    ap.add_argument("--buildonly", action="store_true")
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    p = CONFIGS[a.config]
    bdir = a.build or os.path.join(ROOT, "build", a.config)
    os.makedirs(bdir, exist_ok=True)
    flist = [os.path.join(root, l.strip()) for l in open(os.path.join(root, "rtl", "files.f")) if l.strip()]
    tb = os.path.join(root, "tests", "meridian", "tb", "tb_meridian.sv")
    exe = os.path.join(bdir, "sim")
    if not a.nobuild:
        cmd = [VERILATOR, "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style",
               "-Wno-MULTIDRIVEN", "-Wno-WIDTHTRUNC", "-Wno-WIDTHEXPAND", "-Wno-UNUSEDSIGNAL", "-Wno-DECLFILENAME",
               "--top-module", "tb_meridian", "--Mdir", os.path.join(bdir, "obj"), "-o", "sim",
               "-j", os.environ.get("VJOBS", "4"), "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include"] + gflags(p) + flist + [tb]
        r = subprocess.run(cmd, capture_output=True, text=True)
        open(os.path.join(bdir, "build.log"), "w").write(r.stdout + r.stderr)
        if r.returncode != 0:
            print("BUILD FAILED\n" + (r.stdout + r.stderr)[-4000:])
            return 2
        loops = [l for l in (r.stdout + r.stderr).splitlines() if "UNOPTFLAT" in l]
        if loops:
            print("COMBINATIONAL LOOP WARNINGS:\n" + "\n".join(loops[:10]))
            return 3
        shutil.copy(os.path.join(bdir, "obj", "sim"), exe)
    if a.buildonly:
        return 0
    r = subprocess.run([exe, f"+tests={a.tests}", f"+seed={a.seed}"] + (["+debug"] if a.debug else []), capture_output=True, text=True)
    out = r.stdout + r.stderr
    open(os.path.join(bdir, f"run_seed{a.seed}.log"), "w").write(out)
    if not a.quiet:
        print(out)
    else:
        print("\n".join(l for l in out.splitlines() if "FAIL" in l or "RESULT" in l or "SUMMARY" in l)[-3000:])
    return 0 if "RESULT: PASS" in out else 1

if __name__ == "__main__":
    sys.exit(main())
