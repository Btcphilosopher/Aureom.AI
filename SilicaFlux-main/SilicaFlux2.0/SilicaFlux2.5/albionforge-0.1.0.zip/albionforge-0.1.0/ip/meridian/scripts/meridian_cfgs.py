"""Configurations of the Meridian verification runs (shared by run_tb.py, regress.py, mutate.py).

A configuration is a dict of the parameters of tests/meridian/tb/tb_meridian.sv; per-master / per-target lists are
packed into the vector parameters the RTL uses.
"""

def pack(vals, width):
    v = 0
    for i, x in enumerate(vals):
        v |= (x & ((1 << width) - 1)) << (i * width)
    return v

def mk(name, nm, nt, maxo=None, ooo=None, conn=None, perm=None, mslice=None, tslice=None, **kw):
    maxo = maxo or [1] * nm
    ooo = ooo or [0] * nm
    mslice = mslice or [0] * nm
    tslice = tslice or [0] * nt
    conn = conn if conn is not None else [[1] * nt for _ in range(nm)]
    perm = perm if perm is not None else [[1] * nt for _ in range(nm)]
    flat = lambda mat: [mat[m][t] for m in range(nm) for t in range(nt)]
    p = dict(NM=nm, NT=nt,
             MST_MAXO=(pack(maxo, 8), nm * 8), MST_OOO=(pack(ooo, 1), nm),
             CONN=(pack(flat(conn), 1), nm * nt), PERM=(pack(flat(perm), 1), nm * nt),
             MST_SLICE=(pack(mslice, 4), nm * 4), TGT_SLICE=(pack(tslice, 4), nt * 4))
    p.update(kw)
    return name, p

def gflags(p):
    out = []
    for k, v in p.items():
        if isinstance(v, tuple):
            val, w = v
            out.append(f"-G{k}={w}'h{val:x}")
        else:
            out.append(f"-G{k}={v}")
    return out

# the Albion system: 5 masters (Keystone, BridgeEngine, PacketForge, VirtualFoundry, ComputeWorks) and 7 targets
# (Keystone SHM/mailbox, IronMemory, BridgeEngine, PacketForge, VirtualFoundry, ComputeWorks, Citadel CSR)
ALBION_M = ["Keystone", "BridgeEngine", "PacketForge", "VirtualFoundry", "ComputeWorks"]
ALBION_T = ["KeystoneSHM", "IronMemory", "BridgeCSR", "PacketCSR", "VFoundryCSR", "ComputeCSR", "CitadelCSR"]

def albion():
    nm, nt = 5, 7
    # physical connectivity: every master reaches memory and the shared buffer; control windows (the engine CSRs and
    # the Citadel CSR) are reached from Keystone only; engines reach their own CSR page? no -- masters reach other
    # engines' data windows only through IronMemory/SHM, so the engine CSR windows are Keystone-only.
    conn = [[0] * nt for _ in range(nm)]
    for m in range(nm):
        conn[m][0] = 1      # shared buffer
        conn[m][1] = 1      # IronMemory
    for t in range(2, nt):
        conn[0][t] = 1      # Keystone reaches every CSR window, incl. Citadel
    conn[1][3] = 1          # BridgeEngine can also reach the PacketForge page (packet DMA hand-off)
    # Citadel policy: same as the physical map except BridgeEngine -> PacketForge is denied by policy (a wired path
    # the policy does not allow), and PacketForge -> IronMemory is allowed
    perm = [row[:] for row in conn]
    perm[1][3] = 0
    maxo = [2, 8, 8, 4, 8]
    ooo = [0, 1, 1, 1, 1]
    mslice = [0, 1, 1, 0, 2]
    tslice = [0, 1, 0, 0, 0, 1, 0]
    return mk("albion_5x7", nm, nt, maxo, ooo, conn, perm, mslice, tslice, ARB_MODE=1, STARVE=8, CIT_LAT=1, TMO=0, REQ_DEPTH=2)

CONFIGS = dict([
    mk("ref_2x2", 2, 2),
    mk("ref_2x2_citlat1", 2, 2, CIT_LAT=1),
    mk("ref_2x2_rr", 2, 2, ARB_MODE=0),
    mk("ref_2x2_depth1", 2, 2, REQ_DEPTH=1),
    mk("ref_2x2_slices", 2, 2, mslice=[1, 2], tslice=[2, 1]),
    mk("ref_2x2_nocit", 2, 2, CITADEL_MODE=0),
    mk("ref_2x2_extcit", 2, 2, CITADEL_MODE=2, CIT_LAT=1),
    mk("m2t2_tmo", 2, 2, maxo=[8, 2], ooo=[1, 0], TMO=300, ISOLATE=1),
    mk("m2t2_tmo_noiso", 2, 2, maxo=[8, 2], ooo=[1, 0], TMO=300, ISOLATE=0),
    mk("ref_2x2_tmo", 2, 2, maxo=[1, 1], TMO=300, ISOLATE=1),
    mk("stress_4x2", 4, 2, maxo=[8, 8, 8, 8], ooo=[1, 1, 0, 0], STARVE=3),
    mk("stress_4x2_s30", 4, 2, maxo=[8, 8, 8, 8], ooo=[1, 1, 0, 0], STARVE=30),
    mk("stress_4x2_rr", 4, 2, maxo=[8, 8, 8, 8], ooo=[1, 1, 0, 0], ARB_MODE=0),
    mk("m3t2_ooo", 3, 2, maxo=[4, 4, 1], ooo=[0, 1, 0]),
    mk("m4t3_mixed", 4, 3, maxo=[1, 2, 4, 8], ooo=[0, 0, 1, 1], mslice=[0, 1, 0, 0], tslice=[0, 0, 1],
       conn=[[1, 1, 1], [1, 1, 0], [1, 0, 1], [1, 1, 1]]),
    albion(),
])
