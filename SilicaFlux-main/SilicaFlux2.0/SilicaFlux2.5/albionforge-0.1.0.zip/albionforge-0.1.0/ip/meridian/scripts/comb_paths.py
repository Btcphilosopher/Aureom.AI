#!/usr/bin/env python3
"""Structural combinational-path analysis of the RTL (Yosys netlist, flops break paths).

For a top module and parameters: flatten with Yosys, build the bit-level combinational dependency graph (every non-sequential cell
connects all its input bits to all its output bits -- an OVER-approximation, so a reported path may be false but a missing path is
proved), then
  * detect combinational LOOPS (strongly connected components): there must be none;
  * report which input ports reach which output ports combinationally (the valid/ready dependency matrix).
Writes reports/comb_paths.md.  usage: comb_paths.py
"""
import json, os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.setrecursionlimit(1 << 20)
RTL = [f for f in (
    "third_party/p22/sfn_pkg.sv", "rtl/albion/sf_meridian_pkg.sv", "third_party/p22/sfn_fifo.sv", "rtl/albion/sf_meridian_decoder.sv",
    "rtl/albion/sf_meridian_arbiter.sv", "rtl/albion/sf_meridian_slice.sv", "rtl/albion/sf_meridian_citadel_ref.sv",
    "rtl/albion/sf_meridian_mport.sv", "rtl/albion/sf_meridian_router.sv", "rtl/albion/sf_meridian_perf.sv", "rtl/albion/sf_meridian_fabric.sv")]

def netlist(top, params, tag):
    d = os.path.join(ROOT, "build", "comb"); os.makedirs(d, exist_ok=True)
    js = os.path.join("build", "comb", f"{tag}.json")        # relative: the YoWASP build only sees paths under its cwd
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in params.items())
    cmd = (f"read_verilog -sv -DSYNTHESIS {' '.join(RTL)}; {ch}hierarchy -top {top} -check; proc; flatten; opt_clean; memory_map; opt_clean; write_json {js}")
    r = subprocess.run(["yosys", "-q", "-p", cmd], capture_output=True, text=True, cwd=ROOT)
    if r.returncode: raise SystemExit("yosys failed:\n" + (r.stdout + r.stderr)[-1500:])
    return json.load(open(os.path.join(ROOT, js)))

SEQ_PREFIX = ("$dff", "$adff", "$sdff", "$dlatch", "$adlatch", "$mem", "$sr", "$aldff", "$dffsr", "$ff", "$fsm")

def analyse(nl, top):
    # chparam renames the top module ($paramod...): find it by its `top` attribute
    name = next((n for n, m in nl["modules"].items() if str(m.get("attributes", {}).get("top", "0")).strip("0") != ""), top)
    mod = nl["modules"][name]
    succ = {}
    def edge(a, b): succ.setdefault(a, set()).add(b)
    for cname, c in mod["cells"].items():
        if c["type"].startswith(SEQ_PREFIX): continue
        ins, outs = [], []
        for p, bits in c["connections"].items():
            dirn = c["port_directions"].get(p, "input")
            (outs if dirn == "output" else ins).extend(b for b in bits if isinstance(b, int))
        for o in outs:
            for i in ins: edge(i, o)
    ports = mod["ports"]
    # --- loops: iterative Tarjan
    index, low, onst, st, nscc, loops = {}, {}, set(), [], 0, []
    counter = [0]
    nodes = set(succ) | {b for s in succ.values() for b in s}
    for root in nodes:
        if root in index: continue
        work = [(root, iter(succ.get(root, ())))]
        index[root] = low[root] = counter[0]; counter[0] += 1; st.append(root); onst.add(root)
        while work:
            v, it = work[-1]
            adv = False
            for w in it:
                if w not in index:
                    index[w] = low[w] = counter[0]; counter[0] += 1; st.append(w); onst.add(w)
                    work.append((w, iter(succ.get(w, ())))); adv = True; break
                elif w in onst:
                    low[v] = min(low[v], index[w])
            if adv: continue
            work.pop()
            if work: low[work[-1][0]] = min(low[work[-1][0]], low[v])
            if low[v] == index[v]:
                comp = []
                while True:
                    w = st.pop(); onst.discard(w); comp.append(w)
                    if w == v: break
                if len(comp) > 1 or v in succ.get(v, ()): loops.append(comp)
    # --- port-level reachability
    outbits = {}
    for n, p in ports.items():
        if p["direction"] == "output":
            for b in p["bits"]:
                if isinstance(b, int): outbits.setdefault(b, set()).add(n)
    reach = {}
    for n, p in ports.items():
        if p["direction"] != "input": continue
        seen, stack = set(), [b for b in p["bits"] if isinstance(b, int)]
        seen.update(stack)
        while stack:
            v = stack.pop()
            for w in succ.get(v, ()):
                if w not in seen: seen.add(w); stack.append(w)
        hit = set()
        for b in seen:
            if b in outbits: hit |= outbits[b]
        reach[n] = hit
    return loops, reach

def main():
    JOBS = [
        ("sf_meridian_slice (1 stage)", "sf_meridian_slice", {"W": 8, "STAGES": 1}),
        ("sf_meridian_slice (3 stages)", "sf_meridian_slice", {"W": 8, "STAGES": 3}),
        ("sf_meridian_arbiter (N=5, QOS)", "sf_meridian_arbiter", {"N": 5, "MODE": 1, "STARVE": 8}),
        ("sf_meridian_fabric 2x2 reference", "sf_meridian_fabric", {"NM": 2, "NT": 2, "TGT_BASE": "64'h1000000000000000", "TGT_MASK": "64'hF0000000F0000000"}),
        ("sf_meridian_fabric 2x2, slices 2/2, MAXO 4, OOO", "sf_meridian_fabric",
         {"NM": 2, "NT": 2, "TGT_BASE": "64'h1000000000000000", "TGT_MASK": "64'hF0000000F0000000", "MST_SLICE": "8'h22", "TGT_SLICE": "8'h22",
          "MST_MAXO": "16'h0404", "MST_OOO": "2'b11", "TMO": 100}),
    ]
    L = ["# Combinational-path analysis (structural, from the Yosys netlist)", "",
         "Flattened with `proc; flatten; memory_map`; every flip-flop breaks a path; every other cell connects ALL its inputs to ALL its outputs",
         "(over-approximation: a listed path may be false, an absent path is proved absent). Generated by scripts/comb_paths.py.", ""]
    allok = True
    for i, (title, top, params) in enumerate(JOBS):
        nl = netlist(top, params, f"j{i}")
        loops, reach = analyse(nl, top)
        L += [f"## {title}", "", f"* combinational loops: **{len(loops)}**" + ("" if not loops else "  (!!)"), ""]
        allok &= (len(loops) == 0)
        L += ["| input port | combinationally reaches output ports |", "|---|---|"]
        for n in sorted(reach):
            if n in ("clk", "rst_n"): continue
            L.append(f"| `{n}` | " + (", ".join(f"`{o}`" for o in sorted(reach[n])) or "(none: registered before every output)") + " |")
        L.append("")
        if top == "sf_meridian_slice":
            ok = ("out_ready" not in reach or "in_ready" not in reach["out_ready"]) and ("in_valid" not in reach or "out_valid" not in reach["in_valid"])
            L += [f"* **slice: out_ready -> in_ready path: {'ABSENT' if 'in_ready' not in reach.get('out_ready', set()) else 'PRESENT'}; "
                  f"in_valid -> out_valid path: {'ABSENT' if 'out_valid' not in reach.get('in_valid', set()) else 'PRESENT'}** -- the slice cuts both directions.", ""]
            allok &= ok
    L += [f"**Result: {'no combinational loops in any analysed design' if allok else 'PROBLEMS FOUND'}.**", ""]
    open(os.path.join(ROOT, "reports", "comb_paths.md"), "w").write("\n".join(L))
    print("\n".join(L))
    return 0 if allok else 1

if __name__ == "__main__":
    sys.exit(main())
