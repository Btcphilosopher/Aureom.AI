# SilicaFlux Albion — Project 83 · Meridian: cloud system interconnect

**Primary RTL:** `rtl/albion/sf_meridian_fabric.sv` · Aureom.AI / SilicaFlux Albion · delivered as this archive — **nothing was committed to GitHub**.

Meridian is the common on-chip communication fabric of the Albion cloud device: a **registered crossbar with one buffer per crosspoint**
connecting Keystone, IronMemory, BridgeEngine, PacketForge, VirtualFoundry, ComputeWorks and Citadel, with **domain-bound, Citadel-checked
access control at every master port**, tags and ownership, per-target round-robin / class-aware arbitration with a stated starvation bound,
configurable outstanding transactions (in order or out of order), register slices for distant regions, timeouts and fault isolation, an error
log and performance counters. The reference configuration is **2 masters × 2 targets, one outstanding transaction per master**; the same RTL
scales by parameters to the 5 × 7 Albion system and beyond.

> **Status — read this first.** Everything below is **RTL simulation** (Verilator) and **bounded formal** (Yosys / z3). No FPGA, no synthesis with
> timing, no placement, no power result exists; **no frequency, area or power is claimed**. The **Citadel is a reference model** and the
> **AlbionCore transaction format did not exist in the repository and is defined here**; the endpoints are bench models. Most formal results are
> *bounded*; only the 1-entry FIFO closes as an unbounded proof. Details and everything else that is not claimed:
> [docs/meridian/08_LIMITATIONS.md](docs/meridian/08_LIMITATIONS.md).

## Definition of done — met in RTL simulation

> *Every supported master exchanges data correctly with permitted targets under contention, and transaction identities are preserved
> throughout the fabric.*

* **Every route**: `routes` writes unique data from every master to every target and reads it back; it lands in exactly the permitted
  targets' memories and in no others.
* **Under contention**: `simultaneous`, `random_backpressure`, `stress_4x2` (4 masters × 8 outstanding, thousands of arbitration stalls) and the
  Albion 5 × 7 system, with random target latency / back-pressure / response reordering / errors, 3 seeds each.
* **Identity preserved**: every request is compared field by field (source, tag, domain, privilege, class, opcode, address, data, strobes) at the
  target against what the master issued; every response is compared (tag, domain, opcode, status, data) at the master; formal properties R1–R6 say the same
  for any policy. Results and counts: [reports/regression.md](reports/regression.md), [reports/formal.md](reports/formal.md),
  [reports/mutation.md](reports/mutation.md).

## Results at delivery (all reproducible with the commands below; raw tables in `reports/`)

| Evidence | Result |
|---|---|
| Simulation regression, 16 configurations × 3 seeds (the 2 × 2 reference, variants, stress, out-of-order, timeouts, slices, the 5 × 7 Albion system) | **48 / 48 runs pass, 6 575 063 checks** ([reports/regression.md](reports/regression.md)) |
| Mutation check: 31 deliberate RTL defects against that regression | **31 / 31 killed** ([reports/mutation.md](reports/mutation.md)) |
| Arbiter vs the verified `sfn_qos_arbiter`, cycle by cycle, 28 configurations; starvation bound | **28 / 28** ([reports/arbiter.md](reports/arbiter.md)) |
| Formal (Yosys / z3): FIFO, slice, arbiter, decoder, routing / protection safety of the whole fabric | **34 / 34 jobs as expected** — 1 unbounded proof, 21 **bounded** checks, 12 mutants caught ([reports/formal.md](reports/formal.md)) |
| Structural combinational-path analysis | **0 combinational loops**; a slice has no path in either direction ([reports/comb_paths.md](reports/comb_paths.md)) |
| Idle latency per route against the model (2 + slices request, 1 + slices response) | **95 / 95 routes match** ([reports/latency.md](reports/latency.md)) |

What is *not* established (no timing / area / power, bounded formal only, models for Citadel and endpoints): [docs/meridian/08_LIMITATIONS.md](docs/meridian/08_LIMITATIONS.md).

## Quick start

```bash
make check lint quick          # the 2 x 2 reference: every protocol test (~1 minute including the build)
make regress                   # every configuration x 3 seeds -> reports/regression.md
make arbiter formal comb latency
make mutate                    # 31 deliberate RTL defects, all must be caught -> reports/mutation.md
```

Tools and the environment notes (pip Verilator needs a PCH flag; YoWASP tools need shims): [docs/meridian/07_VERIFICATION.md](docs/meridian/07_VERIFICATION.md) §5.

## Layout

```
rtl/albion/        sf_meridian_fabric.sv (TOP) · _mport (master port) · _router · _arbiter · _decoder · _slice · _citadel_ref · _perf · _pkg
rtl/files.f        file list (Verilator / Yosys)
third_party/p22/   sfn_fifo, sfn_pkg, sfn_qos_arbiter -- Project 22, unmodified, SHA256SUMS (the arbiter is the verification oracle only)
tests/meridian/    tb/tb_meridian.sv (system bench) · tb/tb_arb_diff.sv · formal/fv_*.sv (harnesses)
scripts/           run_tb · regress · run_arb · formal · mutate · comb_paths · report_latency · synth_stat · check_config · make_zip · meridian_cfgs
docs/meridian/     00 audit · 01 architecture · 02 protocol · 03 access control · 04 arbitration / QoS · 05 faults / counters ·
                   06 physical pipeline · 07 verification · 08 limitations
reports/           regression · arbiter · formal · mutation · comb_paths · latency · synth (+ logs/)
Makefile · MANIFEST.sha256
```

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit; reuse of verified logic | [docs/meridian/00_AUDIT.md](docs/meridian/00_AUDIT.md): P22 SFB3 extended, `sfn_fifo` vendored unmodified (SHA-256), `sfn_qos_arbiter` as the oracle, P34 / CloudDMA / Keystone conventions adopted; the brief's code names mapped to real blocks |
| 2 | Registered crossbar first; multiple masters / targets; decode; read / write routing; tags; error responses; configurable topology | `sf_meridian_fabric/router/mport/decoder`; `NM`, `NT`, `CONN` (sparse / segmented), `REQ_DEPTH`, slices — 01; reference first, then the same tests on every other configuration — 07 |
| 3 | Request / response channels; tag preservation; source id; destination decode; domain metadata | 02 (the Albion format); `src` stamped by the router; `dom` / `priv` / `tc` carried unchanged and echoed — checked at every target and master |
| 4 | Round-robin arbitration; concurrency; deterministic same-target contention; fairness and starvation properties | `sf_meridian_arbiter`; 04 (bound `STARVE + N − 1` / `N − 1`, checked every cycle, differential test, bounded formal) |
| 5 | Outstanding requests; out-of-order: tags, ownership, bounded queues, no duplicate delivery, reject illegal tag reuse | `MST_MAXO`, `MST_OOO`; slot table in `sf_meridian_mport` (01 §3, 02 §2); `tagreuse`, `faults` tests |
| 6 | Register slices; no combinational loops; no loss / reorder; back-pressure; reset-safe; report added latency | `sf_meridian_slice`; 06 (comb-path analysis, formal S1–S4, latency asserted per route: [reports/latency.md](reports/latency.md)) |
| 7 | Citadel at defined boundaries; documented error response; enforcement, not just carrying | 03: master-port ingress; `ST_DENIED` with fault codes; fail-closed; domain binding independent of the Citadel |
| 8 | Optional QoS, no unanalysed guarantees | five traffic classes, `ARB_QOS`; 04 §5 states why no service level is promised and what is bounded |
| 9 | Faults: invalid destination, decode error, slave failure, timeout, protocol violation; a stalled endpoint must not block independent traffic | 05 §1; `timeout`, `indep`, `invalid`, `faults` tests |
| 10 | Performance counters | `sf_meridian_perf`; 05 §3 (requests, completions, busy, arbitration stalls, bytes, latency, occupancy, per-endpoint and matrix), mirrored exactly in every test |
| 11 | Verification list | 07 §1: every item → a test; formal, mutation, differential |
| 12 | Deliverables | `sf_meridian_fabric / arbiter / decoder / router / perf .sv` in `rtl/albion/` (+ `_mport`, `_slice`, `_citadel_ref`, `_pkg`); `tests/meridian/`; `docs/meridian/` |
