# 01 — Architecture

Meridian is the common on-chip fabric of the SilicaFlux Albion cloud device: **NM master ports × NT target ports**, a **registered crossbar
with one buffer per crosspoint**, per-master protection (domain binding + Citadel check), tags and slots, per-target arbitration,
configurable outstanding transactions, register slices for distant regions, fault handling and performance counters. Reference
configuration: **2 masters × 2 targets, one outstanding transaction per master**. Everything else is the same RTL with different
parameters (§6). Status of every claim: docs/meridian/08_LIMITATIONS.md — RTL simulation and bounded formal only.

```
                 master side (valid/ready, flat vectors)                                       target side
   m_req ──►[MST_SLICE]──► ┌──────────────── sf_meridian_mport (one per master) ─────────────┐
   m_rsp ◄──[MST_SLICE]◄── │ decode ► domain-binding ► Citadel check ► tag/slot table        │
                           │   local error responses (DECERR/DENIED/PROTO/TIMEOUT) end here │
                           └──push (permitted only)──┐                          ▲ responses (src-steered, always accepted)
                                                     ▼                          │
                           ┌───────── sf_meridian_router ───────────────────────┴───────────┐
                           │  crosspoint buffer (m,t)  [sfn_fifo, REQ_DEPTH]   for each connected pair
                           │  per-target sf_meridian_arbiter (RR / class levels + aging)
                           │  egress slice (1 + TGT_SLICE[t] stages)  ── stamps `src` ──────────┼──► t_req
                           │  response slice (TGT_SLICE[t] stages) ◄─────────────────────────────┼─── t_rsp
                           └────────────────────────────────────────────────────────────────────┘
   sf_meridian_citadel_ref (CIT_REF) or external Citadel (CIT_EXT) ── check port per master, policy port (management plane)
   sf_meridian_perf  counters      error log (first fault, sticky)      sf_meridian_pkg  constants
```

## 1. Files

| File | Role |
|---|---|
| `rtl/albion/sf_meridian_fabric.sv` | **primary RTL**: parameters, master-side slices, master ports, router, Citadel wiring, error log, counters |
| `rtl/albion/sf_meridian_mport.sv` | one master port: protocol / domain / decode / Citadel gate, slot table, local errors, timeouts, response collection and delivery |
| `rtl/albion/sf_meridian_router.sv` | crosspoint buffers, per-target arbitration and egress, response slices and `src` steering |
| `rtl/albion/sf_meridian_arbiter.sv` | round robin / class levels with aging; the same policy as the verified `sfn_qos_arbiter` |
| `rtl/albion/sf_meridian_decoder.sv` | address → target (base / mask windows), reachability, alignment |
| `rtl/albion/sf_meridian_slice.sv` | physical register slice: `STAGES` × 2-entry registered FIFO stage |
| `rtl/albion/sf_meridian_citadel_ref.sv` | **reference model of the Citadel check** (default-deny policy table, 0- or 1-cycle verdict) |
| `rtl/albion/sf_meridian_perf.sv` | saturating counter bank with freeze / clear and a flat read port |
| `rtl/albion/sf_meridian_pkg.sv` | opcodes, status, fault codes, classes, counter map |
| `third_party/p22/` | `sfn_fifo`, `sfn_pkg`, `sfn_qos_arbiter` (oracle), unmodified, `SHA256SUMS` |

## 2. The path of a transaction

**Request, master → target** (latencies are for empty buffers; formula in §5):

1. *Master edge.* The master presents `m_req_*`; with `MST_SLICE[m] = s` it first passes `s` slice stages.
2. *Master port, same cycle as acceptance.* In one combinational evaluation the port: checks the opcode and alignment; checks that the
   presented **domain is bound to this port** (`MST_DOM_ALLOW`); decodes the address to a target; checks the topology connectivity
   (`CONN`); if the target is isolated (timeouts) fails fast; asks the **Citadel**; looks for a free slot and an unused tag; and, if the
   request is permitted, checks that the crosspoint buffer `(m, target)` has room. If everything holds the request is **accepted**: it is
   pushed into that buffer and a slot is allocated (state ISS). Any local failure is accepted too, but answered locally (state DONE with
   an error status) — it never enters a buffer, an arbiter or a target.
3. *Crosspoint buffer* `(m, t)` (`sfn_fifo`, `REQ_DEPTH` entries). One buffer per connected pair: a request waits only for its own target.
4. *Arbiter of target t.* Each cycle the arbiter picks one non-empty buffer head (class level + aging, ties round robin) and moves it
   into the egress slice **in the same cycle** (the grant is the transfer: no grant lock, no stall between grant and move). All targets
   arbitrate and move concurrently.
5. *Egress slice* (1 + `TGT_SLICE[t]` stages) — the first stage registers every target request port, so no combinational path leads from a
   target's `ready` into the fabric. The **source `src` is stamped here** from the buffer index; a master cannot choose it.

**Response, target → master:** the target response passes `TGT_SLICE[t]` stages, is steered by `src` to its master port and written
into the slot that owns `(tag, target)` — **there is no response buffer**: capacity is reserved by the outstanding limit (one slot per
outstanding transaction), so the response network **never back-pressures a target** and a stalled master cannot delay anyone else's
responses. A response that matches no slot (orphan, duplicate, wrong target) is consumed and counted. The slot is then presented on the
master's response channel (in acceptance order for `OOO = 0`, as completed for `OOO = 1`), through `MST_SLICE[m]` stages.

## 3. The master port in detail

* **Slot table** (`MAXO` slots per master, 1..16): each slot holds `tag, dom, op, target, bytes, sequence number, age, status, rdata`.
  States: FREE → ISS (issued, waiting) → DONE (response / error ready, waiting for delivery) → FREE, or → ZOMB (see timeouts).
* **Outstanding limit.** A request is accepted only if a slot is free. `MAXO = 1` is the reference configuration.
* **Tag rule.** A request whose tag matches any non-free slot (including a ZOMB) is **consumed without a response** and reported
  (`V_TAGREUSE`): an answer would be indistinguishable from the first transaction's. A master must not reuse a tag until its response
  has been delivered (and, after a timeout, until the late response was swallowed or the zombie flushed).
* **Ordering.** `OOO = 0`: a completed slot waits until every older pending slot has been delivered (sequence-number comparison, bounded
  by `MAXO`); targets may answer in any order. `OOO = 1`: delivery as completed, round-robin among completed slots. A presented response
  is held (not re-selected) until accepted.
* **Citadel handshake.** One query per port at a time; verdict in the query cycle (`CIT_LAT = 0`) or later; no verdict within `CHK_TMO`
  cycles ⇒ **deny (F_CITTMO), fail closed**, and further requests are denied immediately until a verdict arrives or `8 × CHK_TMO`
  cycles pass, when the next request probes again. See 03_ACCESS_CONTROL.md.
* **Timeouts** (`TMO > 0`): see 05_FAULTS_AND_PERFORMANCE.md §1.

## 4. Why this topology

| Requirement | How it is met |
|---|---|
| independent targets run concurrently | one buffer per pair, one arbiter per target, NT transfers per cycle (measured: reports/regression.md, `concurrent_independent_targets`) |
| a stalled endpoint must not block independent traffic | a stalled target fills only its own column; other masters never see it; the same master is held only until the head-of-line timeout (§5 of doc 05) |
| no combinational valid/ready loops | every stage boundary is a registered FIFO; `valid` outputs never depend on `ready` inputs; checked by Verilator (`UNOPTFLAT` is a hard error in `run_tb.py`) and by `scripts/comb_paths.py` (reports/comb_paths.md) |
| response path cannot deadlock | separate from the request path; always accepted (slots reserved) |
| scales from a small FPGA to a multi-engine ASIC | parameters only (§6); `CONN` removes unused crosspoints; slices cut long wires; `REQ_DEPTH = 1` halves buffer area |

Not chosen: a **combinational crossbar** (P22 `sfn_xbar`; one long path master → target); a **shared bus** (one transfer per cycle; one
stalled target stalls all); a **mesh** (no verified mesh exists for these endpoints; the brief forbids starting there). A mesh or a
hierarchy of Meridian instances is the scaling path beyond a few tens of ports (08_LIMITATIONS.md).

## 5. Latency added by the fabric (empty, `REQ_DEPTH ≥ 2`; measured and asserted by the `latency_idle` test)

| segment | cycles |
|---|---|
| request: master edge → target request valid | **2 + MST_SLICE[m] + TGT_SLICE[t]** (1 crosspoint buffer, 1 egress register, plus the slices), **+ `CIT_LAT` when the master is behind a slice** (a registered Citadel verdict is absorbed before acceptance at an unsliced port) |
| response: target response taken → master response valid | **1 + MST_SLICE[m] + TGT_SLICE[t]** (1 slot register, plus the slices) |
| round trip with a target that answers in 0 cycles | 4 + 2·(MST_SLICE[m] + TGT_SLICE[t]) accept-to-response, as reported per route in reports/latency.md |
| with a combinational Citadel (`CIT_LAT = 0`) | +0 |
| with a registered Citadel (`CIT_LAT = 1`) | the request is accepted one cycle after it is presented (verdict next cycle); a master port then issues at most one request per 2 cycles |

Contention adds the arbitration wait (bounded, 04_ARBITRATION_QOS.md) and buffer occupancy.

## 6. Configuration and scaling

`sf_meridian_fabric` parameters (full list in the module header): `NM`, `NT`, `AW`, `DW` (8..256, power of two), `TAGW`, `DOMW`;
`TGT_BASE` / `TGT_MASK` (address windows); `CONN` (NM×NT connectivity matrix — **sparse / segmented crossbars**); `REQ_DEPTH`;
`MST_MAXO`, `MST_OOO`, `MST_DOM_ALLOW` (per master); `MST_SLICE`, `TGT_SLICE` (pipeline stages per region boundary); `ARB_MODE`,
`STARVE`; `CITADEL_MODE`, `CIT_NENT`, `CIT_LAT`, `CHK_TMO`; `TMO`, `ISOLATE`; `LATW`, `CW`.

State grows as: crosspoint buffers `connected pairs × REQ_DEPTH × RQW` (RQW = 6 + TAGW + DOMW + AW + DW + DW/8 bits; 117 for the
default widths), egress slices `NT × (1 + TGT_SLICE) × 2 × (RQW + SRCW)`, slots `Σ MAXO × (DW + ~40)`, plus counters. Concrete flop /
cell counts from a Yosys synthesis of three configurations are in reports/synth.md (generic gates, no timing, no area in µm², no technology
mapping): **4 337 flip-flops for the 2 × 2 reference, 10 402 for 4 × 3, 19 211 for the 5 × 7 Albion system**. Note that the **performance-counter
bank is a large share of the small configurations** (76 counters × 32 bits = 2 432 of the 4 337 flip-flops in the reference; 219 × 32 = 7 008 of
19 211 in Albion): a small FPGA build should reduce `CW` or drop the counter set (the datapath does not depend on it).

| Scale | Recipe |
|---|---|
| small FPGA | `NM`/`NT` 2–4, `MAXO` 1, `REQ_DEPTH` 1 or 2, no slices, `CIT_LAT` 0, `DW` 32–64 |
| Albion system | 5 × 7 (§7), `MAXO` per master, slices on the far regions, `CIT_LAT` 1 |
| multi-engine ASIC | slices on every region boundary the floorplan says is long; `CONN` removes pairs that must never talk; replicate or hierarchise beyond ~16 ports |

## 7. The Albion configuration (system test `albion_5x7`)

Masters: 0 Keystone, 1 BridgeEngine, 2 PacketForge, 3 VirtualFoundry, 4 ComputeWorks. Targets: 0 Keystone SHM / mailbox, 1 IronMemory,
2 BridgeEngine CSR, 3 PacketForge CSR, 4 VirtualFoundry CSR, 5 ComputeWorks CSR, 6 Citadel CSR; each a 256 MiB window at `t << 28`.

* **Physical connectivity (`CONN`)**: every master reaches targets 0 and 1; only Keystone reaches the CSR windows 2–6 (including the
  Citadel's); BridgeEngine additionally has a wire to PacketForge's CSR (target 3).
* **Policy (`PERM`, programmed into the Citadel by Keystone)**: the same, except that BridgeEngine → PacketForge is **denied by policy**
  although a wire exists — exercising "decode OK, route OK, Citadel says no" (`ST_DENIED`) separately from "no wire" (`ST_DECERR`).
* Per window, three regions: read / write, read-only, privileged read / write (a request needs `priv`).
* `MAXO` = 2, 8, 8, 4, 8; `OOO` = 0, 1, 1, 1, 1; master slices 0, 1, 1, 0, 2; target slices on targets 1 and 5.

The domains of master *m* are `m mod 4` plus the never-granted domains 4 and 5; the Citadel grants domains 0–3 on every permitted target
(so a request using the domain of another master is a **spoof** (`F_SPOOF`), a request using domain 4 / 5 is a **policy denial** (`F_DOMAIN`),
and domains 6 / 7 are unbound everywhere).

## 8. Clock and reset

One clock. `rst_n`: asynchronous assert, synchronous release provided by the platform (Keystone's `SYS` block already does this).
Reset clears every buffer, slot, arbiter pointer and age counter, the Citadel policy (default deny), the counters and the error log:
**no transaction survives reset**; responses still in flight from a target after a fabric-only reset arrive as orphans and are consumed
(tested: `reset_under_load`, odd rounds reset the fabric only).
