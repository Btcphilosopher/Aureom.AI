# 06 — Physical pipeline design: register slices, combinational paths, reset

## 1. The register slice (`sf_meridian_slice`)

`STAGES = 0`: a wire. `STAGES ≥ 1`: `STAGES` back-to-back stages, each a **2-entry valid/ready FIFO with registered status flags** — the
`sfn_fifo` of Project 22, `DEPTH = 2`, vendored unmodified. It is used for the master-side boundary (request and response, `MST_SLICE[m]`
stages each), for the target-side boundary (request after the mandatory egress register and response, `TGT_SLICE[t]` stages each), and as
the mandatory first egress stage. Place slices where the floorplan has a long wire between a functional region and the crossbar; the
request and the response direction get the same count so the round trip is symmetric.

| requirement | how it holds | evidence |
|---|---|---|
| **no combinational valid/ready loop**, and no combinational valid / ready path *through* a slice | every output of a stage comes from registers; `in_ready` is a function of the stage's own occupancy only; `out_valid` / `out_data` of its registers only | `scripts/comb_paths.py` (reports/comb_paths.md): slice (1 and 3 stages): **no path from `out_ready` to `in_ready`, none from `in_valid` to `out_valid`, none from `in_data` to `out_data`**; **0 combinational loops** in the slice, the arbiter and two fabric configurations; Verilator `UNOPTFLAT` (combinational loop) is a hard failure of every simulation build (`scripts/run_tb.py`) |
| **no transaction loss, duplication or reordering** | FIFO discipline; push only with `in_ready`, pop only with `out_valid` | formal `fv_slice` S1 (occupancy = pushes − pops ≤ 2·STAGES) and S2 (a tracked element leaves in order, unchanged), bounded; `sfn_fifo` itself unbounded in Project 22 and bounded here (reports/formal.md); simulation: every request and response is compared field by field at the far end of every slice in all slice configurations |
| **stability under back-pressure** | a stalled output holds its head unchanged | formal S3; bench monitors on `t_req` and `m_rsp` in every cycle of every run |
| **correct back-pressure propagation** | a full stage deasserts `in_ready` next cycle; the stage behind it fills, and so on back to the buffer / master | tests `random_backpressure`, `stalled_endpoint_independence` (target never ready), `qos_classes` (target ready 50 %) |
| **full throughput** | 2 entries hide the registered-ready bubble: one transfer per cycle in steady state | `fv_slice` latency job; `concurrent_independent_targets` (a stream through the fabric runs at one request per cycle) |
| **reset-safe buffering** | asynchronous assert, synchronous release; every stage is empty after reset; nothing survives | test `reset_under_load` (reset mid-traffic, whole system and fabric-only; all buffers empty, slots free, no response delivered for a pre-reset transaction, stale target responses consumed as orphans) |

## 2. Added latency (all empty-fabric figures measured and *asserted* by the `latency_idle` test, every route of every configuration)

| path | cycles | note |
|---|---|---|
| each slice stage, either direction | **+1** | when empty; +0 added to throughput |
| request, master edge → target request valid | **2 + MST_SLICE[m] + TGT_SLICE[t]** (+ `CIT_LAT` if `MST_SLICE[m] > 0` and a Citadel is present) | 1 crosspoint buffer + 1 egress register + slices |
| response, target response taken → master response valid | **1 + MST_SLICE[m] + TGT_SLICE[t]** | 1 slot register + slices |
| `CIT_LAT = 1` (registered Citadel verdict) | the master port accepts 1 cycle after the request is presented; **behind a master-side slice this shows up as +1 in the request path** (the slice has already taken the request), at an unsliced port as a later handshake | one request per 2 cycles per master port |

Per-route figures for the configurations that were run (including the Albion 5 × 7, whose slices differ per region) are in
reports/latency.md. Contention, buffer occupancy and arbitration waits add to these (04, 05).

## 3. Combinational paths that remain, and why

`reports/comb_paths.md` lists, for each analysed design, every input that combinationally reaches an output (over-approximated; a missing
path is proved missing).

* **Master request channel → `m_req_ready` / `cit_req_*` / `evt_*`** in an unsliced fabric: the acceptance decision (decode, domain binding,
  Citadel verdict when `CIT_LAT = 0`, slot and buffer availability) is made in the cycle the request is presented. This is a single
  `valid → ready` dependency (the allowed direction); `valid` outputs never depend on `ready` inputs, so no loop exists. For a distant or
  fast master use `MST_SLICE ≥ 1`: **with master-side slices the analysis shows no combinational path from any master input to any output** (second fabric
  configuration in the report, 2 stages; the only exception is the `tst_cit_stall` verification hook).
* **Target side and response side**: `t_req_ready`, `t_rsp_*`, `m_rsp_ready` reach **no** output combinationally in either configuration.
* **Arbiter**: `req`, `lvl` → grant (the decision); `en` → nothing.
* **`CIT_EXT` with a combinational (`LAT = 0`) Citadel** adds the chain `m_req → cit_req → cit_rsp → m_req_ready` through the external block;
  a registered Citadel (`LAT ≥ 1`) or a master-side slice removes it.
* **Verification hook** `tst_cit_stall` reaches `m_req_ready` and the event pulses (it models a Citadel failure; tie it to 0).

## 4. What is *not* claimed

No synthesis-with-timing, placement or routing was run: **no clock frequency, no critical path, no area in µm² or gate-equivalents of a
mapped netlist, no power** is claimed. reports/synth.md gives only technology-independent Yosys cell counts of the generic netlist (flops,
logic cells) to show how the state scales. The recommended slice counts are structural (cut every long wire in both directions at a
boundary where the register slice is free of combinational dependence), not timing-driven.
