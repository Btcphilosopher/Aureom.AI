# 05 — Fault handling, error log, performance counters

## 1. Faults and where they are handled

| fault | detected | response | recorded |
|---|---|---|---|
| **invalid destination** (address decodes to no target) | master port, at acceptance | `ST_DECERR`, `F_UNMAPPED`; never forwarded | error log, `DECERR` counter |
| **no route** (decodes, but `CONN` has no wire from this master) | master port | `ST_DECERR`, `F_NOROUTE` | same |
| **access denied / domain spoof / Citadel failure** | master port | `ST_DENIED` (+ `F_*`) — see 03 | error log, `DENIED`, `V_SPOOF`, `evt_sec` |
| **slave failure** | target answers `ST_SLVERR` | passed to the master unchanged, `rdata = 0` | `SLVERR` counter |
| **request timeout** (`TMO` > 0) | per slot age; head-of-line watchdog | `ST_TIMEOUT` (`F_RSPTMO` / `F_HOL`) | error log (own channel), `TIMEOUT` |
| **target isolated** | after a timeout | `ST_TIMEOUT`, `F_ISO`, at once | same |
| **protocol violation by a master** | master port | reserved opcode / misaligned → `ST_PROTO` (`F_BADOP` / `F_MISALIGN`); tag reuse → request consumed, **no response** | `V_BADOP`, `V_MISALIGN`, `V_TAGREUSE` |
| **protocol violation by a target** | master port / router | orphan or duplicate response → consumed; echo mismatch / illegal status → `ST_PROTO`, zero data; bad `src` → consumed at the target | `V_ORPHAN`, `V_ECHO`, `V_LATE` (informational), `BADSRC` (per target) |

### Timeouts, zombies, isolation (`TMO` > 0)

* **Response timeout.** A slot in ISS for `TMO` cycles is answered `ST_TIMEOUT` and becomes a **zombie**: its tag and slot stay reserved until the
  late response arrives (then it is swallowed, `V_LATE`, and the target's isolation clears) or the management plane pulses `zomb_flush`. This is
  what makes tag reuse after a timeout safe. A write that timed out may still be performed later — a timeout says "no answer", not "not done".
* **Head-of-line timeout.** A permitted request that cannot enter its crosspoint buffer for `TMO` cycles (the target is stalled and its buffer
  full) is answered `ST_TIMEOUT / F_HOL` and was **never issued**: it is not in any buffer and will never reach a target. This bounds how long
  a stalled target can hold *the same master's* later requests (they wait at the ingress behind the blocked one) to `TMO` cycles.
* **Isolation** (`ISOLATE = 1`): either event marks the target isolated for that master port, so new requests to it fail **at once** instead of
  waiting `TMO` again behind a dead endpoint. Cleared by a late response from the target, or by `iso_clear[t]`.

### Does one stalled endpoint block independent traffic?

| traffic | stalled target |
|---|---|
| other masters, other targets | **never** — measured: a 300-request stream takes the same number of cycles alone and while another master has jammed a different target (`stalled_endpoint_independence`); proved structurally (separate buffers, arbiters, response slots) and in the formal routing harness |
| other masters, **same** target | blocked as far as that target is (it is the stalled resource); their requests wait only in their own crosspoint buffers; with `TMO > 0` they time out like any other |
| the **same master**, other targets | `TMO = 0`: its later requests wait at the master port ingress behind a request whose buffer is full (the ingress is in order) — **unbounded** while the target never accepts; `TMO > 0`, `ISOLATE = 0`: each blocked request costs one `TMO` (asserted: healthy requests behind four blocked ones complete within 6·`TMO` + 400); `TMO > 0`, `ISOLATE = 1`: bounded by `TMO` for the first, then isolation makes the rest fail at once (`timeout_isolation` asserts that healthy requests queued behind the stalled target complete within 3·`TMO` + 200 cycles) |
| in-order port (`OOO = 0`), dead target, older request outstanding | later responses of that master wait for the older one's `ST_TIMEOUT` (≈ `TMO`); use `OOO = 1` ports for masters that talk to unreliable targets |
| `MAXO = 1` and a zombie | the master's only slot is reserved until the late response or `zomb_flush`; its next request waits (it is not lost) — **use `MAXO ≥ 2` with timeouts, or flush** (tested: `ref_2x2_tmo`) |

## 2. Error log and events

`elog_*` (first fault, sticky until `elog_clear`): `valid`, source master, `status`, `fault` (`F_*`), `addr` (zero for timeouts), `dom`, `tag`,
target; `elog_count` counts every error event (saturating). Priority inside one cycle: an error created at acceptance (lowest master first)
before a response timeout; **both channels are counted** (a defect found by the bench: an earlier version lost a timeout that coincided with a
local error — fixed, mutant coverage in reports/mutation.md). Pulses: `evt_err` (any error), `evt_sec` (a denial). Per-port state: `o_iso[m*NT+t]`,
`o_cit_orphan[m]`.

## 3. Performance counters (`sf_meridian_perf`)

Flat bank of saturating `CW`-bit counters read through `perf_sel` / `perf_data` (combinational); `perf_freeze` holds all (consistent snapshot),
`perf_clear` zeroes (wins over freeze). Counters observe; they never influence the datapath. Index map: `sf_meridian_pkg` (`PF_*`, `pf_m`, `pf_t`, `pf_x`, `pf_n`).

| block | counter | definition |
|---|---|---|
| global | `CYCLES`, `BUSY` | cycles; cycles with any transaction pending |
| global | `REQ`, `CPL`, `BYTES`, `ARBSTALL`, `VIOL` | requests accepted; responses delivered; OK bytes; arbitration stalls; violations |
| master *m* | `REQ`, `CPL`, `CPLERR` | accepted (incl. locally answered); delivered; delivered with status ≠ OKAY |
| master *m* | `DECERR`, `DENIED`, `TIMEOUT`, `PROTO`, `SLVERR` | delivered with that status |
| master *m* | `BYTES_WR`, `BYTES_RD` | bytes of OKAY completions (write: strobe count; read: `DW/8`) |
| master *m* | `LAT_SUM`, `LAT_CNT`, `LAT_MAX` | **response latency**: cycles from acceptance to delivery on the master channel |
| master *m* | `OUT_SUM`, `OUT_MAX` | **queue occupancy**: outstanding transactions, summed over cycles / maximum |
| master *m* | `STALL_IN` | cycles a request was presented and not accepted |
| master *m* | `V_BADOP`, `V_MISALIGN`, `V_TAGREUSE`, `V_SPOOF`, `V_ORPHAN`, `V_ECHO`, `V_LATE` | violation events |
| target *t* | `REQ`, `BYTES` | requests / bytes delivered to the target (**traffic by endpoint**) |
| target *t* | `ARBSTALL` | arbitration stalls: requesters present minus the one served, summed over cycles |
| target *t* | `OCC_SUM`, `OCC_MAX` | **queue occupancy**: entries in the crosspoint buffers of the target |
| target *t* | `BUSY`, `BADSRC` | cycles the egress holds a request the target did not take; consumed bad-source responses |
| matrix | `x[m][t]` | requests delivered from master *m* to target *t* |

**Measurement point.** Per-master latency, occupancy and input-stall counters are measured at the **master port, behind the master-side slice**;
the bench sees the outer edge, so for a master with `MST_SLICE > 0` it compares those counters with ≤ rather than =. Every other counter
(and every counter of an unsliced master) is compared **exactly** with an independent mirror in every test; the remaining relations
(`OCC_MAX ≤ NM·REQ_DEPTH`, global sums) are checked too. Counter width: saturating, never wrapping.
