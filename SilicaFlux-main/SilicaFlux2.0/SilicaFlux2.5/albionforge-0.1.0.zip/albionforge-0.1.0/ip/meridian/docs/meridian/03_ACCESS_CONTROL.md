# 03 — Access control: Citadel integration

> *A domain number alone does not provide isolation.* (CloudDMA, `docs/03_PROTECTION.md`.) Meridian never relies on the `dom` field being
> honest, and never merely carries it: it **enforces** at a defined boundary, before a request touches any shared resource.

## 1. The enforcement boundary

There is one enforcement point per master, **the master port ingress** — the first thing a request meets, before the crosspoint buffer,
the arbiter or any target:

```
 request ─► opcode / alignment ─► (1) DOMAIN BINDING ─► decode / route ─► (2) CITADEL CHECK ─► slot + push to crosspoint buffer
                │ ST_PROTO             │ ST_DENIED F_SPOOF    │ ST_DECERR             │ ST_DENIED (+ fault code)
                └──────────────────────┴──────────────────────┴───────────────────────┴──► error response to the master, never forwarded
```

Consequences of choosing the ingress: a denied request consumes **no shared bandwidth** (no buffer entry, no arbiter slot, no target
cycle), cannot cause contention, and cannot be observed by any other master or by the target. The check is made **for every request**,
including management-class traffic (`tc = 4` is not exempt, and `priv` is an *input to* the check, not a bypass of it). Every request
that is forwarded was checked in the cycle it was accepted (the same cycle when `CIT_LAT = 0`).

Other boundaries, defined explicitly:

| boundary | what is enforced / checked there |
|---|---|
| master port ingress | everything above |
| crosspoint / topology (`CONN`) | a pair with no wire does not exist: the request is answered `ST_DECERR / F_NOROUTE` (a *physical* absence, distinct from a *policy* denial) |
| target egress | `src` is **stamped** by the fabric; the target learns the true master and the domain / privilege that were checked |
| master port response side | a response is accepted only for an outstanding transaction of **that** target with the right `tag`; the echoed `dom` / `op` must match (`ST_PROTO` otherwise) |

## 2. Check 1: domain binding (`MST_DOM_ALLOW`, fabric-local, always on)

Each master port has a mask of the domains it may present. A request presenting another domain is a **spoof**: `ST_DENIED`, fault
`F_SPOOF`, security event (`evt_sec`, counter `V_SPOOF`). The port, not the label, is trusted. The check is independent of the Citadel and
stays on even with `CITADEL_MODE = CIT_OFF` (bring-up: there is then *no permission check*, only binding; do not ship it).

## 3. Check 2: the Citadel check interface

Per master port: `cit_req_valid / ready`, `cit_req_dom`, `cit_req_priv`, `cit_req_write`, `cit_req_addr`; `cit_rsp_valid`, `cit_rsp_ok`,
`cit_rsp_fault[3:0]`. The source is the port index. Contract:

* one query per port at a time; the fabric holds the fields stable while `valid && !ready`;
* **exactly one verdict per accepted query**, in the same cycle (combinational responder, `CIT_LAT = 0`) or later;
* `ok = 1` permits; `ok = 0` denies with a fault code (`F_NOMAP` no entry covers the address, `F_PERM` the right is missing, `F_DOMAIN` covered
  but not for this source / domain, `F_PRIV` needs privilege);
* **fail closed**: no verdict within `CHK_TMO` cycles ⇒ the request is denied (`F_CITTMO`); the port then denies at once (no waiting) until a
  verdict arrives or `8 × CHK_TMO` cycles pass, after which one request probes again. Verified: `citadel_failclosed` (the outage delays
  only the affected port; another master is unaffected; recovery after the Citadel returns).

`CITADEL_MODE`: `CIT_OFF` none, `CIT_REF` the reference table `sf_meridian_citadel_ref` inside the fabric, `CIT_EXT` an external Citadel on the
`cit_*` ports (tested with the reference table instantiated outside, `ref_2x2_extcit`).

### The reference Citadel is a model, not the Citadel

`sf_meridian_citadel_ref` is a default-deny table of entries `{valid, src_mask, dom_mask, need_priv, base, mask, rd, wr}`; a request is
permitted iff some valid entry covers the address and names the source and the domain, privilege is met, and the right is granted.
It gives the fabric a deterministic, testable policy and defines the interface; the real Citadel (not in the repository) must keep the
interface and its guarantees: **default deny**, a verdict per query, no verdict ⇒ no access. Policy programming is a management-plane port
(`pol_*`): it must be reachable only from Keystone's privileged path (in the Albion configuration the Citadel CSR is connected to Keystone
only). A policy change applies to the next check; a request already forwarded completes — revoke by quiescing first (the same rule
CloudDMA states).

## 4. The documented error response

A denied request is answered on the master's response channel, in the normal response slot order, with:
`status = ST_DENIED (3)`, `tag` / `dom` / `op` of the request, `rdata = 0`. The detail is recorded in the **error log** (first fault, sticky):
source, status, fault code (`F_SPOOF` / `F_NOMAP` / `F_PERM` / `F_DOMAIN` / `F_PRIV` / `F_CITTMO`), address, domain, tag, target; counters
`DENIED` and `V_SPOOF` per master; `evt_sec` pulses when a denial is created. Nothing about a denial is visible at any target.

## 5. What is tested, and what is not claimed

Tested (bench + formal): every request the oracle denies and that nevertheless reaches a target fails the scoreboard (property R1 in the
formal harness, over any policy table programmed at any time); spoofed, ungranted, privileged-without-`priv`, read-only-write, unreachable
and Citadel-unresponsive cases; run-time revocation and re-grant with the error log checked; mutants M01 (verdict ignored), M02 (binding
removed), M03 (fail open), M04 (wrong status), M29 (domain denial still forwarded) are killed (reports/mutation.md).

**Not claimed:** side-channel isolation (shared arbiters, buffers and the Citadel are observable through latency); protection against a
compromised management plane; that the reference table is a hardware IOMMU / firewall; authentication of `priv` (it is an input the
platform must derive from an authenticated source); isolation of *targets* from each other (the fabric stamps the source and checks the
master side; a shared target must enforce its own tenancy).
