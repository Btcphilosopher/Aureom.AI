# 04 — Arbitration, fairness, starvation and traffic classes

## 1. What is arbitrated

Contention exists only **per target**: the buffer heads `(0, t) … (NM-1, t)` compete for the egress register of target *t*. Each target has
its own `sf_meridian_arbiter`; different targets never interact, so independent traffic proceeds concurrently ("NT transfers per cycle").
Inside the master port there is no arbitration (one request per cycle enters, one response per cycle leaves).

## 2. The policy (`sf_meridian_arbiter`)

Inputs per requester: `req` (the buffer head is valid) and a 3-bit class `lvl` (the request's `tc`, larger = more urgent); input `en`
(the egress register can take one, a registered signal). **A transfer happens in the cycle `gvalid && en`; the grant is the transfer** —
there is no grant lock, nothing is granted that is not moved.

* `ARB_MODE = ARB_RR`: plain round robin. The pointer moves past the winner on every transfer; levels are ignored.
* `ARB_MODE = ARB_QOS`: (1) **aging**: a requester that has seen `STARVE` transfers of others while requesting is *urgent* and sits above every
  class; (2) otherwise the highest class wins; (3) ties inside the winning level (urgent included) are resolved round robin from the pointer.
  `STARVE = 0` makes everyone urgent at once = round robin.

**Deterministic**: the grant is a pure function of `(req, lvl, pointer, age counters)`; same-target contention always resolves the same way
for the same history. A request, once at the head of its buffer, stays there (the FIFO head is stable) until it is transferred.

## 3. Properties, and what proves them

| property | statement | evidence |
|---|---|---|
| A1 | grant is one-hot or zero, only to a requester | bounded formal (`fv_arbiter`), differential test, simulation monitor |
| A2 | work conserving: some request ⇒ some grant | same |
| A3 | **bounded wait (starvation freedom)**: a requester that keeps requesting is transferred after at most **`N − 1`** transfers of others (`ARB_RR`) or **`STARVE + N − 1`** (`ARB_QOS`), `N` = masters | bounded formal to 18–26 cycles (reports/formal.md; k-induction did **not** close — the proof needs invariants over internal registers the harness cannot see, so this is a *bounded* result), the same bound **proved unbounded by Project 22 for `sfn_qos_arbiter`** (same policy), and **checked in every simulation cycle** at every target by the bench's arbitration monitor (a failure if exceeded) |
| A4 | the new structure implements the verified policy | `tb_arb_diff`: grant / valid / urgent compared with `sfn_qos_arbiter` every cycle in 28 configurations (N = 1…8, RR and QOS, STARVE 0…12), 300 000 cycles each (reports/arbiter.md) |
| A5 | the bound is tight (the monitor can reach it) | stress_4x2 with `STARVE = 30`: longest observed wait 32 transfers, bound 33; `tb_arb_diff` requires a non-zero maximum |
| A6 | a priority class cannot be starved by a higher class | follows from aging (A3); mutant M13 (aging off) is caught by the bound monitor and the class test |

## 4. Fairness definition and measurement

*Fairness* here is **bounded waiting plus equal shares for equal class and equal offered load**: with equal classes the pointer rotation
gives every requester a transfer in every window of `N` transfers. Measured: `fairness_saturation` saturates a target from every master with
equal class — the transfer counts per master must differ by at most 1 (a failure otherwise; passed in every configuration and seed). Fairness is **not**
a bandwidth guarantee and does not account for masters that offer different loads.

## 5. Traffic classes

| `tc` | class | default use |
|---|---|---|
| 0 | background maintenance | scrubbers, housekeeping |
| 1 | bulk DMA | BridgeEngine bulk moves |
| 2 | compute | ComputeWorks operand / result traffic |
| 3 | latency-sensitive I/O | PacketForge / VirtualFoundry control |
| 4 | management | Keystone |

The class is part of the request (3 bits), assigned by the master (it is **not** checked against the master's identity — a master may mark any
class; the Citadel or the platform must police that if classes are a protection concern). `ARB_QOS` uses the class as the arbitration level.

### What the classes do — measured, and what they cost

Four masters, one target accepting 50 % of cycles, 8 outstanding each, class = master index (`qos_classes`, mean accept-to-delivery latency in cycles):

| configuration | class 0 | class 1 | class 2 | class 3 |
|---|---|---|---|---|
| `STARVE = 30` | 21.59 (max 153) | 18.28 (max 155) | 15.01 (max 145) | **10.18** (max 38) |
| `STARVE = 3` | 22.02 (max 38) | 22.22 (max 38) | 22.02 (max 37) | 21.75 (max 37) |
| `ARB_RR` | 22.19 (max 42) | 22.11 (max 41) | 22.10 (max 41) | 22.19 (max 42) |

(seed 1; reports/logs/tb_stress_4x2_s30_seed1.log, `_seed1.log` of `stress_4x2` and `stress_4x2_rr` hold the lines. The test requires, for `STARVE ≥ 16`, the highest class to be ≥ 10 % faster than the lowest.) `STARVE` is the knob that trades priority for the starvation bound:
a small `STARVE` turns the arbiter into an almost plain round robin (every requester becomes urgent after 3 transfers of others), a large one
lets the classes dominate but lengthens the worst wait for the lowest class to `STARVE + N − 1` transfers.

### Why no service level is promised

A guaranteed service level needs (a) a bound on the target's service time, (b) a bound on offered load of every higher class, (c) an
admission policy. The fabric has none of the three: targets may stall without limit, and masters may offer any load. What **is** proved
and checked is the *relative* rule above: **at one target's arbiter, a request at the head of its buffer is transferred after at most
`STARVE + N − 1` transfers of other requesters** (`N − 1` for `ARB_RR`). If the target accepts one request every `Ts` cycles this is at most
`(STARVE + N) · Ts` cycles from reaching the head to the transfer, and a request reaches the head after at most `REQ_DEPTH − 1` earlier
requests of the same master to the same target. These are *analysis-level bounds under the stated assumption on `Ts`*, not guarantees about
latency end to end: the master-port input can still wait for a full crosspoint buffer (and, with `TMO = 0`, without bound if the target never
accepts). Priority is a latency preference, not a bandwidth reservation: under saturation a class gets what the higher classes leave, down to the
aging floor of one transfer per `STARVE + N − 1`.
