# 07 — Verification

Method: *independent* checking. The bench contains its own oracle (a second implementation of decode / domain binding / Citadel policy, written
differently from the RTL), a scoreboard keyed by `(master, tag)`, target models that inject faults, protocol monitors and an exact mirror of
the performance counters; the formal harnesses contain a second shadow model; the arbiter is compared with a separately verified one; and a
mutation check shows the whole set catches deliberate defects. Phase gate (brief: *"scale only after the reference implementation passes all
protocol tests"*): the 2-master × 2-target, one-outstanding configuration `ref_2x2` was brought to a clean pass of every test below **before** any
configuration with more masters, more outstanding requests, out-of-order delivery or slices was run; the larger configurations then ran the **same** tests.

## 1. Brief §11 → tests (`tests/meridian/tb/tb_meridian.sv`, selected with `+tests=`)

| Brief §11 item | test (`+tests=`) | what is checked |
|---|---|---|
| every master-to-target route | `routes` | write + read back of unique data, every master × target pair; data must land in exactly the permitted targets' memories; forbidden pairs must leave memory untouched |
| simultaneous traffic | `simul` (n = 120 clean, 200 with 10 % faults) | all masters at full rate to all targets; conservation, identity, order |
| randomised arbitration | `random` | 4 rounds of random gaps, ready rates, latencies, response reordering, SLVERR; the arbitration-bound monitor is active in every test |
| backpressure | `random`, `indep`, `qos` | targets ready 10–100 %, masters ready 10–100 %, a target that never accepts |
| invalid addresses | `invalid` | unmapped, misaligned, reserved opcodes, no route / not permitted — exact status, no side effect |
| domain violations | `domain`, `citfail` | policy classes (read-only write, privileged without `priv`, ungranted domain, spoofed domain, another master's domain), run-time revocation with error-log check, re-grant, Citadel outage (fail closed, fast deny, recovery) |
| reset under load | `reset` | 4 rounds; whole-system and fabric-only resets mid-traffic; all buffers empty, slots free, no response for a pre-reset transaction, stale target responses consumed |
| timeout | `timeout` (configurations with `TMO > 0`) | response timeout after exactly `TMO`, zombie slot, isolation and fast failure, late-response swallow, head-of-line cancel, flush, recovery; reduced scenario for `MAXO = 1` |
| transaction conservation | every test | accepted = delivered, nothing outstanding, nothing presented, queues empty |
| response ordering | every test | in-order ports: delivery in acceptance order; per (master, target): requests overtaken ⇒ fail |
| fairness | `fair`, `qos` | equal class, saturated target: per-master transfer counts differ by ≤ 1; class latencies; the starvation bound is checked at every target in every cycle of every run |
| out-of-order / tag rules | `faults`, `tagreuse` | duplicate responses, corrupted echoes, mis-sourced responses; tag reuse rejected without a response, then allowed after completion |
| independence of a stalled endpoint | `indep`, `concurrent` | a bystander's 300-request stream takes the same cycles with a jammed target elsewhere; two streams to different targets run concurrently |
| latency | `latency` | each route's request and response path asserted equal to the model (06 §2) |

Every test ends with the conservation checks and the **performance-counter comparison** (05 §3). Failures print the first 25 messages with the
test name and cycle.

## 2. Configurations (`scripts/meridian_cfgs.py`)

| name | what it adds |
|---|---|
| `ref_2x2` | **the reference**: 2 × 2, one outstanding per master, in order, no slices, reference Citadel, combinational verdict, `REQ_DEPTH` 2, class arbiter |
| `ref_2x2_citlat1` / `_extcit` | registered Citadel verdict; Citadel outside the fabric on the external ports |
| `ref_2x2_rr`, `_depth1`, `_nocit` | round-robin arbiter; 1-entry crosspoint buffers; no Citadel (bring-up) |
| `ref_2x2_slices` | master slices 1 / 2, target slices 2 / 1 (latency formula, counters behind slices) |
| `ref_2x2_tmo`, `m2t2_tmo`, `m2t2_tmo_noiso` | timeouts and isolation, with `MAXO` 1 and with `MAXO` 8 (head-of-line); the last has isolation **off**, so only the head-of-line watchdog can release the blocked master (it separates the two mechanisms) |
| `stress_4x2`, `_s30`, `_rr` | 4 masters × 8 outstanding on 2 targets: real contention (thousands of arbitration stalls), `STARVE` 3 / 30, round robin |
| `m3t2_ooo` | 3 masters (non-power-of-two), `MAXO` 4 / 4 / 1, one out-of-order port, tag reuse |
| `m4t3_mixed` | 4 masters × 3 targets, mixed `MAXO` / `OOO`, a sparse `CONN` matrix, slices |
| `albion_5x7` | **the Albion system** (01 §7): 5 masters × 7 targets, sparse connectivity, policy ≠ connectivity, `MAXO` 2–8, mixed order, slices |

Regression: reports/regression.md (every configuration × the seeds listed there; `+seed=N` changes every random decision).

## 3. Other evidence

| artifact | what it shows |
|---|---|
| `scripts/run_arb.py` → reports/arbiter.md | `sf_meridian_arbiter` equals the verified `sfn_qos_arbiter` cycle by cycle (28 configurations); the starvation bound; tightness |
| `scripts/formal.py` → reports/formal.md | bounded formal + non-vacuity mutants (below) |
| `scripts/mutate.py` → reports/mutation.md | 31 deliberate RTL defects, each of which the regression must catch |
| `scripts/comb_paths.py` → reports/comb_paths.md | zero combinational loops; slices cut both directions; the only unsliced combinational path is the acceptance decision |
| `scripts/report_latency.py` → reports/latency.md | measured latency of every route against the model |
| `scripts/synth_stat.py` → reports/synth.md | generic cell / flip-flop counts (not area / timing) |
| Verilator `UNOPTFLAT` | any combinational-loop warning in a build is a hard failure (`run_tb.py`) |

### Formal harnesses (`tests/meridian/formal/`)

| harness | properties |
|---|---|
| `fv_fifo` (`sfn_fifo`) | occupancy = pushes − pops ≤ DEPTH; `in_ready` ⇔ not full; order and integrity of a tracked element; head stability |
| `fv_slice` | S1 conservation / capacity ≤ 2·STAGES, S2 order and integrity, S3 stability, S4 bounded latency (sink always ready) |
| `fv_arbiter` | A1 one-hot, only requesters; A2 work conserving; A3 starvation bound (shadow counters) |
| `fv_decoder` | window match, lowest index wins (overlapping windows), reachability, alignment |
| `fv_fabric` | R1 authorization (a request reaches a target only if an independent shadow oracle — binding, decode, reachability, a shadow copy of the policy table — said "forward" when it was accepted, for **any** policy programmed at any time); R2 routing; R3 identity (every field equal, `src` true); R4 once, and one outstanding transaction per master (a timed-out *zombie* keeps the slot: no new request is accepted while it is in flight); R5 response ownership (own tag / domain / opcode, locally answered requests get exactly the oracle's status, forwarded requests never DECERR / DENIED); R6 no response before the request reached the target. **`ADV = 0`**: targets obey their contract; R1–R6 asserted (also with `TMO > 0`, where a timed-out transaction is tracked as still in flight). **`ADV = 1`**: no assumption on the targets at all (any response at any time); only the response-side properties R4 / R5 are asserted — an early or duplicated response from a *faulty* target legitimately completes a transaction while its request is still in flight, so request-side identity is a property of well-behaved targets (02 §2) |

**Mutants.** Each mutant job runs the same harness on a broken copy and must produce a counterexample (reports/formal.md: `mut_*`); the unmutated
design passes the *same* job (otherwise a mutant would be "caught" for the wrong reason — an early version of the adversarial-target jobs had exactly
that flaw and was corrected): FIFO accepts when full; FIFO read pointer moves without data; a slice stage loses an element; arbiter pointer frozen;
aging removed; grant to a non-requester; decoder tie-break reversed; Citadel verdict ignored; domain binding removed; source stamp wrong; tag lost;
responses steered to every master (caught by R6 in contract mode).

### Mutation check of the simulation regression (`scripts/mutate.py`)

31 mutants: access control (verdict ignored, binding removed, timeout fails open, wrong denial status, denial still forwards), identity and routing
(source stamp, tag / domain / privilege lost, response steered to all, data and strobe corruption), arbitration (pointer frozen, aging off, classes
ignored), buffering (pop ignores egress, push ignores full, FIFO accepts when full), tags and ordering (tag reuse accepted, in-order not enforced,
echo unchecked, a completed slot accepting a second response), timeouts (never fires, zombie freed early, no isolation, head-of-line never cancels
with isolation off), counters, reset, decoder alignment and connectivity, error status lost. The table with the first failing check of each is reports/mutation.md.

## 4. What the bench cannot see

* It checks what it models. The oracle, the target rules and the counter definitions were written from the same specification as the RTL (by the
  same author); the arbiter differential test and the vendored FIFO are the only pieces of independent provenance.
* Timing behaviour is cycle-accurate RTL simulation only.
* The target models are behavioural; real engines may stall in patterns the models never produce (the `t_stall` / `t_dead` / random-ready modes
  are the coverage).
* Coverage was not measured with a coverage tool; it is argued from the test list and the mutation result.

## 5. How to reproduce

```bash
pip install verilator yowasp-yosys z3-solver          # or system Verilator 5.x, Yosys, SymbiYosys, z3
# the pip Verilator needs the PCH flag (set in scripts/run_tb.py); the YoWASP tools need shims named yosys / yosys-smtbmc / sby on PATH
make check lint quick                                  # the 2 x 2 reference, every test
make regress arbiter formal comb latency               # the rest
make mutate                                            # ~31 builds
```

Tool versions used for the reported results: Verilator 5.049 (pip wheel `verilator 5.48.0`), YoWASP Yosys 0.71 with SymbiYosys, z3 (PyPI), Python 3.13.
Run times (4 cores): a configuration builds in 15–60 s and runs in < 10 s; the full regression (16 configurations × 3 seeds) ≈ 8–9 min; the bounded fabric
formal jobs 1–5 min each (time doubles per added cycle); the full mutation check ≈ 25 min; the full formal run ≈ 20 min.
