# 02 — Albion transaction format as carried by Meridian

The repository contains no "AlbionCore" format (00_AUDIT.md §1). This document **defines** it. It is SFB3 (Project 22) extended so that
protection-domain information and the traffic class travel with every transaction and so that every kind of fabric-generated failure has
its own status. Wire-level field order and widths are fixed by the port lists of `sf_meridian_fabric`.

## 1. Fields

**Request** (master → fabric, and fabric → target; the target side adds `src`):

| field | width | meaning |
|---|---|---|
| `op` | 2 | `0` READ one `DW`-bit beat; `1` WRITE one beat, acknowledged (response after the target performed it); `2`, `3` reserved |
| `tag` | `TAGW` | transaction identity chosen by the master; unique among the master's outstanding transactions |
| `dom` | `DOMW` | protection domain presented by the master; **checked, never trusted** (03) |
| `priv` | 1 | privileged access (management plane); part of the permission check |
| `tc` | 3 | traffic class, larger = more urgent: 0 background maintenance, 1 bulk DMA, 2 compute, 3 latency-sensitive I/O, 4 management; 5–7 legal, unnamed |
| `addr` | `AW` | byte address, aligned to `DW/8` |
| `wdata`, `wstrb` | `DW`, `DW/8` | write data and byte enables (ignored for READ, but forwarded unchanged) |
| `src` (target side only) | `clog2(NM)` | **stamped by the fabric** from the crosspoint the request came through |

**Response** (target → fabric, and fabric → master; the target side adds `src`):

| field | width | meaning |
|---|---|---|
| `src` (target side only) | `clog2(NM)` | the master being answered: copied from the request |
| `tag`, `dom`, `op` | as request | echoed from the request |
| `status` | 3 | see §3 |
| `rdata` | `DW` | read data (only meaningful for an OKAY READ; the fabric returns zero otherwise) |

Channels are independent valid / ready channels (request, response) per port. **Single-beat transactions**: a burst is a sequence of
transactions; there are no posted writes, fences or atomic operations (08).

## 2. Rules

**Masters** (M1) do not wait for `ready` before asserting `valid`; (M2) hold `valid` and every field stable until `ready`; (M3) use only
opcodes 0 / 1 and addresses aligned to `DW/8`; (M4) never present a `tag` that is outstanding — a transaction is outstanding from its
acceptance until its response has been delivered (and, after a timeout, until the late response was swallowed or the zombie was flushed).
Violations of M3 / M4 are **handled, not trusted**: reserved opcode and misalignment are answered `ST_PROTO`; a tag reuse is consumed
and reported without a response (a response could not be told apart from the first transaction's).

**Targets** (T1) answer each request exactly once, echoing `src`, `tag`, `dom`, `op`; (T2) answer only `ST_OKAY` or `ST_SLVERR`; an
`ST_SLVERR` request has no side effect; an acknowledged write is answered after it was performed; (T3) hold response `valid` and
fields until `ready`. Targets may answer **in any order**. The fabric does not trust T1: a response that matches no outstanding transaction
(orphan, duplicate), comes from the wrong target, has an out-of-range / unreachable `src`, echoes a wrong domain or opcode, or carries a
status the targets may not produce is **detected and contained**: orphans and bad sources are consumed and counted; an echo mismatch is
delivered to the master as `ST_PROTO` with zero data. One limit is stated plainly: a duplicate response that arrives *after* the tag was
re-issued to the *same* target cannot be told from the second transaction's response (no sequence numbers on the wire); the fabric
rejects every other duplicate (the slot must be ISS or a timed-out zombie, for that tag and that target).

## 3. Status codes (`status`)

| code | name | produced by | meaning |
|---|---|---|---|
| 0 | `ST_OKAY` | target | performed |
| 1 | `ST_SLVERR` | target | slave failure: not performed, no side effect |
| 2 | `ST_DECERR` | fabric | address decodes to no target (`F_UNMAPPED`), or this master has no path to the target (`F_NOROUTE`) |
| 3 | `ST_DENIED` | fabric | domain not bound to the port (`F_SPOOF`), or the Citadel denied (`F_NOMAP` / `F_PERM` / `F_DOMAIN` / `F_PRIV`), or no verdict in time (`F_CITTMO`): **the request never reached a target** |
| 4 | `ST_TIMEOUT` | fabric | no response within `TMO` (`F_RSPTMO`), could not enter the fabric within `TMO` (`F_HOL`, never issued), or target isolated (`F_ISO`, never issued) |
| 5 | `ST_PROTO` | fabric | reserved opcode (`F_BADOP`), misaligned address (`F_MISALIGN`), response echo / status illegal (`F_ECHO`) |
| 6, 7 | reserved | | |

The detail code (`F_*`) is not on the response; it is in the error log (05 §2). Error responses carry the master's own `tag`, `dom`, `op`
and `rdata = 0`.

## 4. Ordering and identity guarantees

| relation | guarantee |
|---|---|
| requests of one master to one target | reach the target **in issue order** (one FIFO per crosspoint) |
| requests of one master to different targets | no relative order at the targets |
| responses to one master, port `OOO = 0` | delivered **in acceptance order** (locally answered requests included), whatever order the targets answer in |
| responses to one master, port `OOO = 1` | delivered as completed; the `tag` identifies the transaction |
| across masters | none; no coherence; use acknowledged writes |
| identity | `tag`, `dom`, `priv`, `tc`, `op`, `addr`, `wdata`, `wstrb` reach the target **unchanged** (checked field by field in every test and formally); the response returns `tag`, `dom`, `op` of the same transaction |
| source | `src` at the target is the true master; it cannot be forged |
| exactly once | an accepted request is delivered to at most one target once; one response is delivered per accepted request (except a rejected tag reuse, which gets none) |

## 5. Protection-domain information is never lost

`dom` and `priv` are part of the request word from the master port to the target; `src` is added; the response echoes `dom`. The echo is
**checked** at the master port against the slot (a target that returns another domain is answered `ST_PROTO`). The domain also feeds the
Citadel check at the master port. Between the check and the target no stage drops, narrows or recomputes any of them (identical-field
check at the target in the bench and as property R3 in the formal harness).
