# 00 — Repository audit (Project 83, Meridian)

Audited: `btcphilosopher/Aureom.AI`, working tree as cloned (last commit `a5fb177`). The SilicaFlux work lives almost entirely inside
zip archives (`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`); nothing is checked in as loose RTL, and there is
no `rtl/albion/` directory in the repository itself. Every archive that could contain a fabric, bus, arbiter, DMA, SRAM or
protocol block was extracted into a scratch directory (untrusted data, never executed) and read. **Nothing was committed to the
repository; this project is delivered as an archive.**

## 1. The names in the brief

A text search of all archive member names and of every extracted README / document found the names *Albion*, *PacketForge* and
*ComputeWorks* only inside Project 82 (Keystone), which itself records them as new code names (its `00_AUDIT.md` §1). *AlbionCore*,
*IronMemory*, *BridgeEngine*, *VirtualFoundry* and *Citadel* occur nowhere. They are **new code names in the brief**, not existing
blocks, and the brief's "AlbionCore's shared transaction format" and "shared Albion protocol" therefore do not exist as a document or
as RTL. This project **defines** that format (docs/meridian/02_PROTOCOL.md) and is explicit about it. The mapping onto real SilicaFlux
blocks follows Keystone's, extended:

| Brief name | Real block in the repository | Role at the fabric | In this project |
|---|---|---|---|
| AlbionCore shared transaction format | **SFB3** (Project 22, DataFabric-NoC `sfn_pkg`): opcode, id, qos, address, data, strobes, `src` stamp, response status | the wire format | SFB3 **extended** (domain, privilege, class, 3-bit status) — *Albion Transaction Format as carried by Meridian* |
| Keystone | Project 82 (RV32IM management controller; MMIO engine windows; AXI4 shared buffer) | master (CPU I/D, command engine) + target (SHM, mailbox) | master 0 and target 0 of the Albion configuration |
| IronMemory | MemoryPool (P65) and the ECC SRAM family (P71–P77: `sramcore`, `srambank`, `sramcontroller`, `sramfabric`, `eccmemory`, `tensorscratch`, `vectorscratch`) | target | target 1 of the Albion configuration |
| BridgeEngine | CloudDMA (P64) data mover + HostLink / ExtMem bridge (P24, P25) | master (DMA memory port) + target (CSR page) | master 1, target 2 |
| PacketForge | PacketCore (P62) | master (packet buffers) + target (CSR page) | master 2, target 3 |
| VirtualFoundry | VirtualIO (P63) | master + target | master 3, target 4 |
| ComputeWorks | CloudDPU command / compute queues (P61), ComputeCluster (P32) | master + target | master 4, target 5 |
| Citadel | no module. Role = permission checking: CloudDMA `sfdma_perm_checker` / `sfdma_perm_table` (P64), SecureStore (P59), SecureBoot (P28, not a policy engine) | policy authority; check port; CSR target | **reference model** `sf_meridian_citadel_ref` + the check interface; CSR target 6 |
| Albion | the SilicaFlux CloudDPU family (P61–P65, P82) as a device | the system | `config/` Albion configuration (5 masters × 7 targets) |

The endpoints themselves (CloudDMA, PacketCore, ...) are **not** integrated by this project: the brief asks for the fabric. Each is
represented in the system test by a behavioural master / target model that follows the fabric's rules.

## 2. What exists, and the decision for each

| Area | Found (archive) | Evidence recorded by that project | Decision |
|---|---|---|---|
| **DataFabric-NoC (P22)** | `silicaflux-datafabric-noc.zip`: SFB3 protocol, `sfn_mst_port`, `sfn_xbar` (combinational crossbar), `sfn_sbus`, `sfn_mesh`/`router`/`ni`, `sfn_qos_arbiter`, `sfn_fifo`, `sfn_perf`, SFB2 bridges, scoreboard testbench, formal harnesses | 782 runs, 38/38 formal jobs (21 unbounded), 35/35 mutants | **Protocol reused as the base** (extended, not forked). `sfn_fifo` **vendored unmodified** (every crosspoint buffer and register-slice stage). `sfn_qos_arbiter` **vendored unmodified as the verification oracle** for the new arbiter. `sfn_xbar` / `sfn_mesh` not used (see below). |
| **NoC spine (P34)** | `silicaflux-noc-spine-p34.zip`: segmented crossbar with link register stages, traffic classes, aging arbiter, placement analysis | 349/349 + 420/420 runs, 27/27 formal | **Architecture precedent**: segmented crossbar + register slices on long links + class-aware arbiter with an aging floor. Its `sfs_link` (= STAGES × `sfn_fifo`) is the same structure as `sf_meridian_slice`. P34 keeps P22's *combinational* central crossbar; Meridian registers it (below). |
| DataFabric (SFB2) | `silicaflux-datafabric.zip`: `sfb_arbiter`, `sfb_addr_decoder`, `sfb_skid_buffer`, DMA, SRAM | unbounded arbiter proofs | `sfb_addr_decoder`'s base / mask window rule is **adopted** in `sf_meridian_decoder` (same lowest-index tie-break, same alignment rule); re-implemented because the topology-connectivity check (`reach`) is new. |
| **CloudDMA (P64)** | `silicaflux-clouddma-p64.zip`: AXI4 master, permission checker with a *request / response* check interface, `domain` sideband | 45/45 + 12/12 runs, 29/29 mutants | **Protection model adopted**: "a domain number is a label software can lie about" — the domain is bound by hardware at the port (`DOM_ALLOW`), never trusted from the request; every request is checked; the check result forms the decision. The fault classes (NO_MAP / PERM / DOMAIN) are reused as `F_NOMAP / F_PERM / F_DOMAIN`. CloudDMA is the first real BridgeEngine master. |
| **Keystone (P82)** | `silicaflux-keystone-p82.zip`: `rtl/albion/` + `tests/keystone/` + `docs/keystone/` layout, generated register map, mailbox, shared buffer SRAM with AXI4 slave | regression + 17/17 mutants | **Layout and conventions adopted** (`rtl/albion/`, `tests/meridian/`, `docs/meridian/`, nothing committed, honest-status header, mutation check). Keystone is master 0 / target 0. Its management plane is the only legitimate programmer of the Citadel policy. |
| SRAM family (P71–P77, MemoryCore) | ECC SRAM banks / fabric / controller | verified in simulation | IronMemory targets. Not instantiated; the target model stands in. |
| PacketCore / VirtualIO / CloudDPU / MemoryPool | P62, P63, P61, P65 | verified in simulation | engine targets / masters, models only (as in Keystone). |
| `Finite State Machines Library` | `round_robin_arbiter.sv`, `priority_arbiter.sv` | simple benches | **Not reused**: plain round robin, no class levels, no aging, no starvation bound statement. |
| `formal verification` archive | `fifo_formal_props.sv`, `sva_assertion_lib.sv`, handshake / deadlock properties | small proofs | **Method adopted** (shadow-counter FIFO properties); harnesses rewritten for this flow. |
| `noc_interconnect.sf` (SilicaFlux 2×2 mesh), `comm_protocols` (AXI-Lite, SPI, ...) | early 2×2 XY mesh; AXI-Lite slave | simple benches | **Not reused**: an unproven mesh is exactly what the brief forbids as a starting point; AXI-Lite has no tags, domains or classes. |
| SFB2 → SFB3 bridges (P22) | `sfn_sfb2_mst_bridge` / `tgt_bridge` | verified | Available for legacy SFB2 endpoints; not needed here. |

## 3. Decision: registered, crosspoint-buffered crossbar; extend SFB3; reuse `sfn_fifo`

* **Topology.** P22's crossbar (and P34's central stage) is a single combinational stage from every master port to every target port;
  P34 concluded (by estimate; no physical design was run there either) that a single combinational stage over a 28 × 24 mm die needs
  registered link boundaries. Meridian instead starts from a **registered
  crossbar with one small buffer per crosspoint** and a registered output per target: no combinational valid / ready path crosses the
  fabric, a stalled target fills only its own column, and per-target arbiters run concurrently. It is the smallest structure that meets
  the brief's concurrency, fault-isolation and "no combinational loop" requirements. A mesh was **not** attempted: no verified mesh
  has been exercised on the Albion endpoint set, and the brief says not to begin with one.
* **Protocol.** SFB3 is the only transaction protocol already used by verified SilicaFlux endpoints; a second format would be the
  "incompatible second interconnect" P34 rejected. SFB3 lacks a protection domain, privilege and a response status wide enough for
  denied / timeout / protocol errors, and has 3-bit QoS levels named after the HPC die's clients (DMA, tensor, vector, control, event), unrelated to the brief's five traffic classes; Meridian extends
  it additively (docs/meridian/02_PROTOCOL.md §1) and drops SFB3's posted writes and fence (no tag-ownership story for posted
  transactions yet, see 08_LIMITATIONS.md).
* **Reused unmodified, hash-proven** (`third_party/p22/SHA256SUMS`, byte-identical to `silicaflux-datafabric-noc.zip`):

| file | sha256 | used as |
|---|---|---|
| `sfn_pkg.sv` | `2ef74ee4549b21bf4f405c806a7dd04f32cc71cfb7c747cef5580b057e208973` | package needed by `sfn_fifo` |
| `sfn_fifo.sv` | `6fe79fca43586fa7e5b7fdaf03c623e3275de9484cd5b0e43a3fd91be182aefc` | every crosspoint buffer and every slice stage |
| `sfn_qos_arbiter.sv` | `d9bc3c36d6ffa6de6bab45b2f6d28127ee26ec9137ec3b0af0303c3a016e5fa6` | **oracle only** (differential test, `tests/meridian/tb/tb_arb_diff.sv`); not in the design |

  The new `sf_meridian_arbiter` implements the *same policy* as `sfn_qos_arbiter` with a different structure and without the grant lock
  (a transfer is the grant, nothing is held), and is compared with it in every cycle (reports/arbiter.md). There is no licence file in
  the repository; the vendored files carry their original headers and are used under the repository owner's own authorship.

## 4. Gaps found that this project does not close

* The **AlbionCore format** and the **Citadel** are not in the repository: defined / modelled here; a real Citadel must implement the
  check interface of 03_ACCESS_CONTROL.md.
* The endpoint blocks (CloudDMA, PacketCore, VirtualIO, CloudDPU, MemoryPool) are **not integrated**; models stand in.
* No licence file; no FPGA / synthesis-with-timing / place-and-route result exists for Meridian (none was run here — see 08_LIMITATIONS.md).
* P22's formal flow used ABC PDR for unbounded proofs; PDR is not available in this environment (Yosys is the YoWASP build: no `yosys-abc`
  applet), so most properties here are **bounded** model checks (reports/formal.md says which).
