# 08 — Limitations and honest status

## What exists

RTL (SystemVerilog), a self-checking simulation environment, bounded formal checks, a mutation check, and documentation. **Everything is
RTL simulation (Verilator) plus bounded model checking (Yosys / z3).** No FPGA, no synthesis with timing, no placement or routing, no power
analysis, no silicon. **No clock frequency, critical path, area or power is claimed** (reports/synth.md has technology-independent cell counts
only).

## Verification scope — what is and is not proved

* **Simulation** covers the configurations in reports/regression.md × the seeds listed there. It is exhaustive in nothing; it is
  evidence, strengthened by an independent oracle, a field-by-field scoreboard, exact counter mirrors and a 31-mutant check.
* **Formal is bounded.** Of the 22 formal property jobs only the 1-entry FIFO closes as an unbounded proof (k-induction); the other 21 (FIFOs, slices,
  arbiters, decoder, fabric, one cover job) are **bounded model checks** to the depths in reports/formal.md (arbiters 18–26 cycles, slices 16–18, FIFOs
  16–20, fabric 10–11). A further 12 jobs are mutants that must fail (they do).
  k-induction did not close for the arbiters, the 2+-entry FIFOs and the slices: the needed invariants relate internal registers (read / write
  pointers, ages) that the harness cannot see, and the YoWASP Yosys build has no `yosys-abc` applet, so the ABC-PDR route Project 22 used is not
  available. Project 22 reports **unbounded** proofs for `sfn_fifo` and `sfn_qos_arbiter`; those were **not** re-run here.
* **The fabric-level formal harness is small**: 2 × 2, `AW = 6`, `DW = 16`, `TAGW = 1`, `DOMW = 2`, `MAXO = 1`, no master-side slice, 10–11 cycles
  (a full transaction needs ≈ 7–8; the solver time doubles with every added cycle). It proves nothing about deeper pipelines, larger widths, `MAXO > 1`, or `OOO`; those are covered by simulation only.
  The authorization property is checked with the combinational reference Citadel (`CIT_LAT = 0`).
* The bounded depth was chosen so that every checked configuration still *reaches* real transactions: the `fabric_cover` job reaches a permitted
  transaction of each master, a delivered denial and a delivered decode error within the checked depth.
* Counters: `CYCLES`, every per-master counter (unsliced masters), per-target `REQ / BYTES / BUSY / BADSRC`, the matrix and the global
  `BUSY / REQ / CPL / BYTES` are compared **exactly** with an independent mirror; `ARBSTALL`, `OCC_SUM`, `OCC_MAX` and the global `ARBSTALL / VIOL`
  are only range-checked (`OCC_MAX ≤ NM·REQ_DEPTH`); sliced masters' latency / occupancy / stall counters are bounded from above (05 §3).

## Models, not the real blocks

* **Citadel** is `sf_meridian_citadel_ref`, a reference model that defines the check interface (03). **AlbionCore's transaction format**
  did not exist and is defined here (02). **The endpoints** (Keystone, IronMemory, BridgeEngine, PacketForge, VirtualFoundry, ComputeWorks) are
  behavioural bench models; CloudDMA, PacketCore, VirtualIO, CloudDPU, MemoryPool are not integrated. Real endpoints must obey the target rules (02 §2);
  the fabric detects and contains violations but a real block may expose behaviours a model does not.
* Keystone's generated register map was not extended: the fabric exposes **ports** (`pol_*`, `elog_*`, `perf_*`, `iso_clear`, `zomb_flush`); a
  memory-mapped CSR block that Keystone's firmware drives is integration work.

## Protocol and functional limits

* **Single-beat transactions only**: no bursts, posted writes, fences or atomics; a DMA burst is a stream of single beats (each pays the
  acceptance cycle). There is no coherence, no multicast, no ordering across masters.
* **Duplicate responses** are rejected except when a duplicate arrives after the *same tag* has been re-issued to the *same target* (02 §2).
  Sequence numbers on the wire would close this; they are not part of the format.
* **`tc` and `priv` are not policed**: a master may label any class; `priv` is an input the platform must derive from an authenticated source.
* **No service-level guarantee** (04 §5): relative bounds only.
* **Head-of-line.** With `TMO = 0` a master whose request waits for a full crosspoint buffer blocks its own later requests (unbounded if the
  target never accepts); other masters and other targets are unaffected. `TMO > 0` bounds it. In-order ports wait for an older timed-out
  request; a `MAXO = 1` master holds a zombie slot until the late response or `zomb_flush`. A timed-out write may still be performed.
* **Citadel throughput.** One outstanding query per port; with a registered Citadel (`CIT_LAT = 1`) a port issues at most one request per two
  cycles. Pipelined queries would remove this (not built).
* **Scale.** State grows with `connected pairs × REQ_DEPTH × RQW`; practical for tens of ports, not hundreds. Beyond that: hierarchy or a
  verified NoC (not attempted, by the brief's instruction).
* **Reset** assumes the platform supplies synchronous release (as Keystone's SYS block does). Elaboration checks (window overlap, parameter
  ranges) run in simulation only.
* **Counters** are 32-bit saturating (parameter `CW`); there are no per-class counters or latency histograms; response latency is measured
  to delivery on the master channel and includes time waiting for in-order delivery.

## Findings during verification (kept, not hidden)

* **Timeout log loss (RTL defect, fixed):** an early version lost a response timeout that coincided with a locally answered error (error log and
  count); found when the bench's zombie tracking disagreed with the DUT. Timeouts now have their own log channel.
* **Citadel recovery gap (RTL defect, fixed while designing the failure test, before it first ran):** a stalled combinational Citadel never sends a
  late verdict, so the fail-closed state could not clear; re-probing after `8 × CHK_TMO` was added.
* **Event-count width (RTL defect, found by code review, fixed):** the per-cycle orphan / echo / late-response counts of a master port were as wide as
  `clog2(MAXO + 1)` (1 bit for `MAXO = 1`), so two simultaneous orphans from two targets would wrap to zero; the width now covers `MAXO + NT`.
* **Dead logic found by the mutation check (removed):** the latched verdict assigned at a Citadel-verdict timeout was never used (the fail-closed
  orphan state overrides it), so a mutant that flipped it survived; the assignment was removed and the mutant re-aimed at the real enforcement logic.
* **Bench blind spot found by the mutation check (closed):** with isolation on, response timeouts and the head-of-line watchdog fire together, so a mutant that
  disabled the watchdog survived; configuration `m2t2_tmo_noiso` separates them.
* **Formal harness defect (corrected, kept visible):** the first fabric harness asserted request-side identity against a single "outstanding" shadow; that is
  false when a *faulty* target answers early or when a *timeout* response is delivered while the request is still in flight. Three jobs produced counterexamples
  and two adversarial-mode mutants had been "caught" only because the unmutated design already failed. The harness now tracks timed-out (zombie) transactions,
  asserts request-side properties for contract-obeying targets only, and every mutant is run against a job that the unmutated design passes.
* **Verilator 5.49 mis-handles arrays of queues of structs** (wrong element, wrong size after a pop); every bench queue is therefore an explicit
  circular buffer. Until it was found, some early results of the bench could not be trusted; all reported results are from the corrected bench.
* **YoWASP Yosys** rejects `import pkg::*;` inside modules, `return`, and `$error` without `SYNTHESIS`; the RTL uses scoped names (`sf_meridian_pkg::X`).
  The pip-built Verilator needs `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include` to compile larger designs (set in `scripts/run_tb.py`).
* An ABC-PDR formal route, an Icarus run and a commercial simulator were **not** available; nothing here was run on them.

## Not done

Synthesis with timing; FPGA / ASIC floorplan-aware slice placement; integration with the real endpoint RTL; a memory-mapped management CSR block;
pipelined Citadel queries; burst support; formal verification of `MAXO > 1`, `OOO` and sliced masters; a mesh.
