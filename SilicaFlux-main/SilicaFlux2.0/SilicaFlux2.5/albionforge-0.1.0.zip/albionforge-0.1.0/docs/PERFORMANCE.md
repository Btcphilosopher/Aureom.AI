# Performance measurement method

All numbers are **simulation cycles** of the 10 ns testbench clock.  They are not FPGA or silicon bandwidth (limitation L-02).

| metric | how it is measured | independent of the DUT? |
|---|---|---|
| total cycles | testbench cycle counter at the end of the run; firmware's `mcycle` and the SoC's 64-bit cycle register at report time | testbench: yes |
| DMA bytes transferred | CloudDMA counters `PC_BYTES_RD / WR` (read by firmware) and the scoreboard's byte counts on the DMA link | scoreboard: yes |
| bytes per cycle | firmware sweep of 64 B .. 4 KiB copies: `length / latency` (copy) and `2 x length / latency` (read + write link traffic) | latency from `SUBMIT_GO` to completion in `sf_asoc_dma_ctl` |
| memory access latency | scoreboard: cycle of request accept at the Meridian master port -> cycle of response accept; min / mean / max, reads and writes, per link | yes |
| arbitration stalls | Meridian `PFG_ARBSTALL`, per-target arbitration stalls, per-master `STALL_IN`; IronMemory bank-wait and conflict-loss counters | counters |
| busy cycles | Meridian `PFG_BUSY`, CloudDMA `PC_ACTIVE`, IronMemory per-bank busy | counters |
| completion latency | `LAT_LAST` register (cycles from submit to completion record) for each sweep size | hardware counter |

Expect about **1 byte per cycle of copy bandwidth** (2 bytes per cycle on the link): the AlbionCore downsizing adapter handles one 16-byte transaction at a time per
IronMemory port, so each word costs two 64-bit memory beats plus handshakes.  CloudDMA by itself sustains 8 B/cycle at 64-bit width; the limit is the SoC integration, not the DMA.
Lifting it is next action NA-03.
