# Verification

Layers (every expected value is computed independently of the RTL under test):

1. **Tool tests** (`tests/test_tools.py`, pytest): the address-map generator refuses eight kinds of illegal map; source lists order packages first and report missing modules / cycles; the vendoring record detects tampering; the synthesis-report parsers.
2. **RTL unit tests** (`tests/unit`, cocotb 1.9.2 + Verilator, Python reference models, random back-pressure, several seeds):
   `regtgt` (600 requests: legality precedence, lane steering, register-bus access log), `axi_init` (260 bursts: splitting, IDs, R / B ordering, error classes, refused sideband violations, memory image, event counts; also with 40 % random back-pressure),
   `sfb2_init` (700 transactions: window translation, lane / strobe steering, local errors, exact ALP request stream), `iron_alp` (520 transactions on two ports: ECC read-modify-write, buffer permissions, ALP legality statuses).
3. **System simulation** (`tb/tb_albion_soc.sv`): the real boot ROM and the cross-compiled firmware on the RTL.  The testbench is the *Host Simulation Interface* (SFB2 master on ControlCore's host port: waits for the ROM's WAIT_IMAGE stage, writes the image, mailbox handshake) and the checker:
   * `alp_scoreboard`: ALP v1 rules on both fabric master links (valid held, fields stable, tags in order and echoed, metadata, zero data on errors, hardware-bound domain, no tag reuse, outstanding bound); a byte-accurate reference memory built from acknowledged writes and compared with every OKAY read on its enabled lanes; "the restricted (DMA) link never gets OKAY outside the SRAM window"; no response without a request, flushed on reset; latency, bytes and busy-window measurement.
   * control-bus (SFB2) monitor on the ControlCore external port.
   * **backdoor comparison** of the shared SRAM (IronMemory banks, read at word / bank / row level) with xorshift32 patterns recomputed by the testbench.
   * firmware self-test (`fw/app/albion_main.c`): identity / policy / init, SRAM word, half-word and byte accesses with a C model, illegal-address faults, buffer manager (allocation, overlap / alignment refusals, ownership), DMA copies (aligned with CRC, unaligned partial beats with guard bytes, 2-element chain, zero length), six DMA refusal paths, Citadel policy revocation in both directions, bandwidth sweep, counter read-out.
4. **Scenario matrix** (`tools/run_sims.py`): back-pressure 0 / 15 / 40 / 70 % (random, legal on every valid / ready channel: `sf_asoc_gate` may only start a block while nothing is pending), host-port response back-pressure, host reset and asynchronous (clock-unaligned) reset triggered while DMA / CPU transactions are in flight followed by a full re-run, plus the FPGA wrapper booting the firmware by itself.
5. **Mutation check of the new glue** (`make albion-mutate`): 15 deliberate defects, each must make a unit test or the system simulation fail.

**Defects found by this process** (all fixed): Meridian does not lint under Verilator 5.020; Meridian and IronMemory do not parse under Yosys 0.33 (patches); the register target took the lane from the address although ALP word addresses are lane aligned (found by the first SoC run); the AXI bridge lost the DECERR class on multi-beat write bursts (found by the independent Python model); two testbench mistakes (scoreboard compared lanes a read did not enable; stale-response bookkeeping after reset).

What is not verified: see `reports/KNOWN_LIMITATIONS.md`.
