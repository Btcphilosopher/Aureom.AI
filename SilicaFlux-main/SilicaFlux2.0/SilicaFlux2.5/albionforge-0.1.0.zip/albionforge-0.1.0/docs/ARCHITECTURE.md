# Architecture of the minimum Albion SoC (`sf_albion_soc_min`)

```
 host (testbench BFM | sf_asoc_host_loader) --hs_* (SFB2, 32 bit)--> +-------------------------------------+
                                                                      | ControlCore (P21)                    |
                                                                      | RV32IM_Zicsr, 8 KiB boot ROM, 64 KiB |
                                                                      | IMEM + 32 KiB DMEM (parity), mailbox,|
                                                                      | perf, RAS, watchdog, own DMA        |
                                                                      +--------------+----------------------+
                                                                                     | ext_* (SFB2 master)
                                                         sf_asoc_sfb2_init  (SFB2 -> ALP v1, 32 -> 128 bit, window table)
                                                                                     | ALP master 0 (domain 0, priv, qos 3)
 CloudDMA P64 --AXI4 (DW 128, AW 40, bursts)--> sf_asoc_axi_init (burst -> words)    |
 ("BridgeEngine")                                         | ALP master 1 (domain 1, qos 1)
                                                          v                          v
                                          sf_asoc_mer_core = sf_meridian_fabric (Meridian P83), NM 2 x NT 4,
                                          AW 64 / DW 128 / TAG 8 / DOM 3, reference Citadel (default deny, 8 entries)
              +----------------+----------------+---------------------+--------------------+
              | t0 sram        | t1 sram_ctl    | t2 dma              | t3 soc_ctl ("perf") |
              | 64 KiB window  | 4 KiB          | 4 KiB               | 4 KiB               |
        sf_asoc_mer_tgt x2  sf_asoc_mer_tgt    sf_asoc_mer_tgt       sf_asoc_mer_tgt
        (one ALP link per   + sf_asoc_regtgt   + sf_asoc_regtgt      + sf_asoc_regtgt
         source master)     + sf_asoc_iron_ctl + sf_asoc_dma_ctl     + sf_asoc_soc_ctl
              |                    |                  |                      |
        sf_asoc_iron_alp = IronMemory P84      CloudDMA CSR / cmd /     Citadel policy port,
        (2 x [width adapter 128 -> 64 +        done / ptbl ports        Meridian counters + error log
         sf_asoc_iron_port], 4 banks x 2048
         x (64 + 8 ECC), buffer manager)
```

## The contract: ALP v1

`ip/albioncore` defines the one shared transaction protocol (docs: `ip/albioncore/docs/albion/ARCHITECTURE_CONTRACT.md`): 64-bit address, 128-bit data,
16 byte enables, 8-bit tag, 8-bit domain, 8-bit attributes, READ / WRITE only, single-beat, in-order completion, bounded outstanding.
Everything that is not ALP is converted at the IP boundary by one glue module (`rtl/soc/`):

| module | converts | decisions / rules |
|---|---|---|
| `sf_asoc_sfb2_init` | ControlCore SFB2 master (32-bit, strobes, 1 error bit) -> ALP initiator | one transaction at a time; the AlbionCore width adapter (UPSIZE) steers the word into its 16-byte lane; the **ControlCore window table** (generated) translates 0x2000_0000.. to the 64-bit Albion addresses; no window -> local SFB2 error (never reaches the fabric); a store with no strobe is completed locally; domain / privilege / QoS are parameters (hardware binding) |
| `sf_asoc_axi_init` | CloudDMA AXI4 (INCR bursts, IDs, sidebands) -> ALP initiator | bursts split into single words; one combined in-order queue for R beats and write acknowledgements; B only after every beat is acknowledged; error classes: DECODE_ERR -> DECERR (only if every failed beat decoded wrong), anything else -> SLVERR; **second checks**: sideband domain != hardware binding, ASID != 0, size != 16 B, burst != INCR or a misaligned address -> the burst is refused locally with SLVERR beats, nothing reaches the fabric |
| `sf_asoc_mer_core` | ALP initiators -> Meridian master ports (`sf_meridian_fabric`) | op READ/WRITE -> 0/1; an unrepresentable domain (>= 8) or a reserved opcode -> Meridian's reserved opcode -> PROTOCOL_ERR; `priv`, `tc = {0, qos}` mapped; Meridian status -> ALP status |
| `sf_asoc_mer_tgt` | Meridian target port -> N ALP initiator links | one link per source master (target 0) so IronMemory's per-port domain binding is preserved; `{src, dom, op}` kept in an in-order context FIFO and re-attached to the response; targets may only answer OKAY / SLVERR |
| `sf_asoc_regtgt` | ALP target (128-bit) -> 32-bit register bus | one lane, whole words only; ALP legality statuses for the rest; passes the access **domain / privilege** to the register block |
| `sf_asoc_iron_port` | 64-bit ALP target -> one IronMemory master port | in-order tag FIFO; IronMemory error code -> ALP status; ECC corrected / uncorrectable -> metadata |
| `sf_asoc_iron_alp` | IronMemory + 2 x (width adapter DOWNSIZE 128 -> 64 + iron_port) | `PORT_DOMAIN_MAP` binds port 0 to domain 0 (ControlCore), port 1 to domain 1 (DMA) in hardware |
| `sf_asoc_iron_ctl` | IronMemory CSR port + buffer-manager command port -> registers | the buffer manager needs a hardware-sourced requester: it is the domain of the access that wrote BM_GO |
| `sf_asoc_dma_ctl` | CloudDMA CSR + hardware `cmd_*` / `done_*` / `ptbl_*` ports -> registers | the command DOMAIN is the parameter `BIND_DOM`, **not a register**; completion latency measured in cycles; permission table programming |
| `sf_asoc_soc_ctl` | Meridian management plane -> registers | boot-policy loader (hardware, after reset) + firmware-writable policy entries; counters, error log, security-event count, 64-bit cycle counter |
| `sf_asoc_gate` | -- | verification-only random back-pressure (absent from the default build) |

## Address map

One source of truth, `config/albion_soc.yaml`, validated by **AlbionCore's own collision checker** (`gen_memmap.check_regions`: overlap, alignment,
reserved legacy window, power-of-two sizes) and turned into SystemVerilog constants, a C header and Markdown by `tools/gen_soc.py`
(`docs/MEMORY_MAP_SOC.md`).  The IronMemory control window is a catalogue extension (`sram_ctl`).  The ControlCore sees each region through a window of its
own 32-bit EXT space; the translation table is part of the same generated package.  Eight negative tests (`tests/test_tools.py`) prove that overlapping,
misaligned, reserved-window, non-power-of-two and capacity-mismatched maps are refused.

## Security model (what enforces what)

| layer | enforces | where |
|---|---|---|
| master-port domain binding (`MST_DOM_ALLOW`) | a master can only present its own domain | Meridian |
| Citadel reference table (default deny) | (source, domain, privilege, address window, read / write) | Meridian (`sf_meridian_citadel_ref`) |
| DMA permission table (IOMMU model) | IOVA -> physical window per domain / ASID, read / write | CloudDMA |
| DMA domain claim + hardware-bound `cmd_domain` | the descriptor's DOMAIN field must equal the hardware binding | CloudDMA + `sf_asoc_dma_ctl` |
| AXI sideband second check | domain / ASID / size / burst / alignment | `sf_asoc_axi_init` |
| buffer ownership (read / write masks per domain; unmanaged memory is the supervisor's only) | per-buffer access | IronMemory |
| control windows reachable only by the ControlCore domain | DMA cannot reach CloudDMA CSRs, the policy port or the buffer manager | Citadel table |

None of these is claimed to be a complete security architecture (docs: `reports/KNOWN_LIMITATIONS.md`, L-03, L-04, L-12).

## Reset and clock

One functional clock.  `rst_ni` is asynchronous-assert; ControlCore synchronises its release and derives `acc_rst_no` (reset of the ControlCore **plus**
soft / watchdog / host reset sources); the fabric, memory, DMA and every bridge run in that domain, so no transaction survives any reset
(scenarios `reset_mid_dma`, `reset_early`, `reset_async`).  IronMemory zero-initialises its arrays after every reset (`init_done`); the Citadel table is
reloaded by the boot-policy loader.  ControlCore's gated accelerator clock is not used.

## Boot and firmware flow

`host loads image into IMEM (hs port) -> mailbox IMAGE_READY -> boot ROM checks CRC-32 and jumps -> firmware` (see `fw/app/albion_main.c`).
The firmware runs the self-test described in `docs/VERIFICATION.md` and reports PASS / FAIL on the console, in the mailbox and on the
`SYSCTRL.TEST_CTRL` pins.  Register maps: `docs/MEMORY_MAP_SOC.md` (generated).
