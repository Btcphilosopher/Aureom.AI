# Building and running

## Tools (Ubuntu 24.04)

```bash
sudo apt-get install -y make build-essential python3 python3-yaml python3-pip verilator yosys iverilog z3 gcc-riscv64-unknown-elf binutils-riscv64-unknown-elf
pip install "cocotb==1.9.2" pytest pyyaml
make albion-doctor      # records versions in build/reports/tool_versions.json
```

Tested with Verilator 5.020, Yosys 0.33, GNU riscv64-unknown-elf-gcc 13.2.0 (rv32im / ilp32 multilib), Icarus 12.0, Python 3.13, cocotb 1.9.2
(cocotb 2.x does not support Verilator 5.020), pytest 9.2, z3 4.8.12.  SymbiYosys is not packaged for this distribution (formal checks needing it are not run).
No network access is needed after installing the tools.

## Targets

| target | work done | main outputs |
|---|---|---|
| `make albion-lint` | generated files fresh; vendored IP == archives + patches; Verilator `-Wall` (SoC at two back-pressure settings, each glue module as a top); Yosys elaboration + `check -assert`; firmware `-Wall -Wextra`; python compile | `build/reports/lint.json` |
| `make albion-test` | cocotb unit tests of the new bridges / shims (15 runs over several seeds and back-pressure settings, independent Python models) + pytest of the tooling (map validation, source lists, provenance, parsers) | `build/reports/unit.json`, `pytest.xml` |
| `make albion-firmware` | rebuild the boot ROM from source and compare with the RTL image; cross-compile the firmware twice (determinism); image + hex | `build/fw/albion_fw.{elf,img,hex}`, `build/reports/firmware.json` |
| `make albion-sim` | build 4 back-pressure variants of the system simulation; 13 scenario runs (normal, host back-pressure, host reset and asynchronous reset with transactions in flight); the FPGA wrapper booting by itself | `build/reports/sim.json`, `fpga_sim.json`, `build/run/*.json` |
| `make albion-synth` | Yosys elaboration, word-level synthesis (inferred memories), `synth_ecp5` mapping and longest path of the wrapper (long: tens of minutes) | `build/reports/synth.json`, `build/synth*/` |
| `make albion-report` | everything into `reports/` (engineering report, JSON, test summary, build manifest, limitations, next actions) | `reports/*` |
| `make albion-mutate` | optional: 15 deliberate defects in the new glue, every one must be caught | `build/reports/mutation.json` |
| `make albion-all` | all of the above in order | |
| `make albion-ip REPO=<Aureom.AI checkout>` | re-create `ip/` from the repository archives and apply `patches/` | `ip/PROVENANCE.json` |
| `make albion-audit REPO=<checkout>` | static inventory of every HDL file in the archives + the audit manifest | `audit/` |

Dependency-aware source lists are generated (`tools/srclist.py`): the top module is resolved through instantiations, package scopes and `include`s, packages
first; a missing module, a name declared in two files or a package cycle is an error.  `build/filelists/soc.f` is the Verilator / Yosys / Icarus list.

## Running one thing

```bash
make albion-firmware
build/sim_s0/vtb_albion_soc +scenario=normal +fw=build/fw/albion_fw.hex +out=out.json +trace=60     # after make albion-sim
# scenarios: normal | reset_mid_dma | reset_early | reset_async ; options +rst_at=N +hostbp=PCT +seed=N
make -C tests/unit -f Makefile.unit TOP=sf_asoc_regtgt MOD=test_regtgt SRCS="ip/albioncore/rtl/albion/sf_albion_pkg.sv rtl/soc/sf_asoc_regtgt.sv"
```

## Reproducibility

The firmware image and hex are bit-identical between two builds (`firmware.json`: `deterministic`), the boot ROM equals the image compiled into the RTL, the IP tree equals
`vendor(archives) + patches` (`tools/vendor.py --verify`), and `reports/BUILD_MANIFEST.json` records the SHA-256 of every project source, the IP provenance and the artefacts.
