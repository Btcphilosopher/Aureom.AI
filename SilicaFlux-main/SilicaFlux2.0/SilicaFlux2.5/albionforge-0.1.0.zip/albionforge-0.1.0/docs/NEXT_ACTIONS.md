# Next engineering actions (see reports/NEXT_ACTIONS.md for the generated list)

The authoritative, always-current list is generated into `reports/KNOWN_LIMITATIONS.md` (L-01 .. L-15) and repeated in `reports/ENGINEERING_REPORT.md`; the next engineering steps are in `reports/NEXT_ACTIONS.md`.
Headlines: simulation and generic synthesis only (no hardware run); the Citadel and the IOMMU are reference / simulation models; no interrupts; ~1 byte/cycle copy bandwidth because of the 128 -> 64-bit adaptation; no formal proofs of the new glue;
the firmware boot path is integrity-checked, not authenticated.
