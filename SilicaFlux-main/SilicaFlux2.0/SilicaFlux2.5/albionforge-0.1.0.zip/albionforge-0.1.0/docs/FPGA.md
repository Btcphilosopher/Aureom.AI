# FPGA integration wrapper (board-neutral)

`rtl/fpga/sf_albion_fpga_top.sv` has five ports: `clk_i`, `rst_ni` (asynchronous, active low), `uart_tx_o`, `led_o[7:0]`.  It contains **no** pin, PLL, clock gate,
memory macro or vendor primitive.  It adds a reset synchroniser (asynchronous assert, synchronous release), the image loader
`sf_asoc_host_loader` (a ROM initialised from `IMAGE_FILE`, written through ControlCore's host port exactly as the testbench does), a UART console
(16 KiB FIFO fed by ControlCore's console tap, 8N1, `BAUD_DIV = CLK_HZ / BAUD`) and status LEDs
(`[7]` heartbeat `[6]` CPU sleep `[5]` RAS fatal `[4]` test fail `[3]` test done `[2]` IronMemory init `[1]` loader error `[0]` loader done).

**Status.**  Simulated (`tb/tb_fpga_top.sv`: loader done, firmware test done, no fail, `ALBION RESULT PASS` received on the UART).  Synthesised with Yosys.  **Not run on a board.**

What a board bring-up must settle (none of it is verified here):

1. A clock the implementation really reaches: the wrapper's `CLK_HZ` only sets the UART divider.  The synthesis longest-path figure is a topological LUT depth, not a frequency.
2. Block-RAM mapping: IronMemory (4 x 2048 x 72 bit, `BACKEND = 1`), ControlCore's I / D SRAM with parity (`CC_SRAM_BACKEND = FPGA`), the loader ROM and the console FIFO are inferred memories.  Check the target maps them to block RAM and that the ECC read-modify-write (RL = 1) meets timing.
3. `IMAGE_FILE` (`build/fw/albion_fw.hex`) must exist at configuration time (`$readmemh` is bitstream initialisation).  Loader length comes from the image header.
4. Reset: the board's reset button feeds `rst_ni` directly.
5. The firmware is integrity-checked (CRC-32), not authenticated.
6. Size: the SoC with CloudDMA's 1 KiB data buffer, 64 KiB SRAM and Meridian is not small; see `reports/ENGINEERING_REPORT.md` section 6 for the synthesis estimate before choosing a device.
7. Synthesis effort and the DMA buffer.  A generic ECP5 mapping of this wrapper maps about 1.04 million cells, **75 % of them in one module**: CloudDMA's `sfdma_bytebuf` (1 KiB per channel, a combinational read of sixteen byte lanes, i.e. a flop array with 16 write and 16 read ports) which Yosys correctly refuses to put in block RAM.  The Yosys 0.33 flow itself did not survive this netlist: both a flattened and a hierarchical `synth_ecp5` were killed by the 16 GB memory limit (about 14 GB resident, measured) in the very last pass, `autoname`.  `make albion-synth` therefore maps hierarchically (`-noflatten`) and stops before `autoname` (`-run begin:check`), which only renames cells; totals come from `stat -top`.  The longest path of the *mapped* netlist is not reported (`ltp` finds false loops through an un-flattened hierarchy); a word-level (pre-ABC) path of the SoC is reported instead and is not a LUT depth.  Re-architecting the buffer for block RAM is next action NA-11; until then the SoC does not fit a small FPGA.
