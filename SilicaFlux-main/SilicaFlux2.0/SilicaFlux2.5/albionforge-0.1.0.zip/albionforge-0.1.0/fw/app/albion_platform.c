/* =============================================================================
 * AlbionForge firmware -- platform layer.  DERIVED from SilicaFlux ControlCore firmware/app/platform.c (Project 21):
 * the trap handler, expected-trap probes, timer tick and watchdog supervision are kept; the accelerator / system-DMA /
 * host-command parts are removed (the minimum Albion SoC has no accelerators and the firmware runs a fixed self-test).
 * ===========================================================================*/
#include "albion_fw.h"

expect_t g_expect;
volatile uint32_t g_ticks, g_msi_count, g_wdt_ewi;
volatile uint32_t g_ras_warn_bits, g_ras_fatal_bits;
static void (*isr_table[16])(void);
#define RAS_WARN_ALL  0x7Fu
#define RAS_FATAL_ALL 0x0Fu
#define TICK_CYCLES      20000u
#define WDT_PRESCALE_RUN 63u
#define WDT_LOAD_RUN     50000u
#define WDT_EWI_RUN      5000u
uint32_t cycles(void) { return csr_read(mcycle); }

uint64_t mtime(void) {
  uint32_t hi, lo;
  do {
    hi = MTIMER(CC_MTIMER_MTIME_HI);
    lo = MTIMER(CC_MTIMER_MTIME_LO);
  } while (hi != MTIMER(CC_MTIMER_MTIME_HI));
  return ((uint64_t)hi << 32) | lo;
}

static void timer_arm(uint32_t delta) {
  uint64_t t = mtime() + delta;
  MTIMER(CC_MTIMER_MTIMECMP_HI) = 0xFFFFFFFFu;          /* no spurious match while updating */
  MTIMER(CC_MTIMER_MTIMECMP_LO) = (uint32_t)t;
  MTIMER(CC_MTIMER_MTIMECMP_HI) = (uint32_t)(t >> 32);
}

void wdt_service(void) {
  WDT(CC_WDT_SERVICE) = CC_WDT_KEY1;
  WDT(CC_WDT_SERVICE) = CC_WDT_KEY2;
}

/* ---------------------------------------------------------------- expected-trap probes */
void expect_arm(uint32_t mode) {
  g_expect.cause = 0;
  g_expect.mode = mode;
  g_expect.armed = 1;
  __asm__ volatile("" ::: "memory");
}
uint32_t expect_result(void) {
  __asm__ volatile("" ::: "memory");
  g_expect.armed = 0;
  return g_expect.cause;
}
uint32_t probe_rd(uint32_t addr, uint32_t *val) {
  uint32_t v = 0xDEADBEEFu;
  expect_arm(EXP_SKIP);
  __asm__ volatile("lw %0, 0(%1)" : "+r"(v) : "r"(addr) : "memory");
  uint32_t c = expect_result();
  if (val) *val = v;
  return c;
}
uint32_t probe_wr(uint32_t addr, uint32_t val) {
  expect_arm(EXP_SKIP);
  __asm__ volatile("sw %0, 0(%1)" ::"r"(val), "r"(addr) : "memory");
  return expect_result();
}
uint32_t probe_wr8(uint32_t addr, uint8_t val) {
  expect_arm(EXP_SKIP);
  __asm__ volatile("sb %0, 0(%1)" ::"r"(val), "r"(addr) : "memory");
  return expect_result();
}

/* ---------------------------------------------------------------- interrupt service routines */
static void isr_fatal(void) {
  uint32_t st = (RAS(CC_RAS_STATUS) >> 8) & 0xFFu;
  g_ras_fatal_bits |= st;
  RAS(CC_RAS_STATUS) = st << 8;
  (void)RAS(CC_RAS_STATUS);
}
static void isr_ras_warn(void) {
  /* the SoC warning input is the OR of the IronMemory and CloudDMA interrupt lines (level): record and mask it */
  uint32_t st = RAS(CC_RAS_STATUS) & 0xFFu;
  g_ras_warn_bits |= st;
  uint32_t lvl = st & (1u << CC_RAS_SRC_EXT_WARN);
  if (lvl) RAS(CC_RAS_WARN_EN) = RAS(CC_RAS_WARN_EN) & ~lvl;
  RAS(CC_RAS_STATUS) = st;
  (void)RAS(CC_RAS_STATUS);
}
static void isr_wdt(void) {
  g_wdt_ewi++;
  WDT(CC_WDT_EWI_THRESH) = WDT_EWI_RUN;
  wdt_service();
  WDT(CC_WDT_STATUS) = CC_WDT_STATUS_EWI;
}
static void dispatch_ext(void) {
  uint32_t id, guard = 0;
  while ((id = INTC(CC_INTC_CLAIM)) != 0u) {
    uint32_t s = id - 1u;
    if (isr_table[s]) isr_table[s]();
    if (++guard > 64u || !isr_table[s]) {            /* a source that cannot be cleared is masked, never allowed to storm */
      INTC(CC_INTC_ENABLE) = INTC(CC_INTC_ENABLE) & ~(1u << s);
      guard = 0;
    }
  }
}

/* ---------------------------------------------------------------- trap handler */
static void fatal_trap(uint32_t cause, uint32_t epc, uint32_t tval) {
  cprintf("\n[FATAL] unexpected trap mcause=%08x mepc=%08x mtval=%08x\n", cause, epc, tval);
  boot_stage(CC_BOOT_STAGE_FATAL);
  SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0xC0000000u | 0xDEADu;
  for (;;) wfi();
}
void trap_handler(trap_frame_t *f) {
  uint32_t cause = csr_read(mcause);
  if (cause & MCAUSE_INT) {
    switch (cause & 0x1Fu) {
      case 11: dispatch_ext(); break;
      case 7:
        g_ticks++;
        wdt_service();
        timer_arm(TICK_CYCLES);
        break;
      case 3:
        g_msi_count++;
        MTIMER(CC_MTIMER_MSIP) = 0u;
        break;
      default: break;
    }
    return;
  }
  uint32_t tval = csr_read(mtval);
  if (g_expect.armed) {
    g_expect.cause = cause;
    g_expect.epc = f->mepc;
    g_expect.tval = tval;
    g_expect.count++;
    g_expect.armed = 0;
    f->mepc = (g_expect.mode == EXP_RESUME_RA) ? f->x[1] : f->mepc + 4u;
    return;
  }
  fatal_trap(cause, f->mepc, tval);
}

/* ---------------------------------------------------------------- init */
void platform_init(void) {
  isr_table[CC_IRQ_FATAL] = isr_fatal;
  isr_table[CC_IRQ_WDT] = isr_wdt;
  isr_table[CC_IRQ_RAS_WARN] = isr_ras_warn;
  INTC(CC_INTC_ENABLE) = 0u;
  INTC(CC_INTC_SWPEND) = 0u;
  INTC(CC_INTC_PRIO0) = (CC_IRQ_FATAL_PRIO << (4 * CC_IRQ_FATAL)) | (CC_IRQ_WDT_PRIO << (4 * CC_IRQ_WDT)) |
                        (CC_IRQ_RAS_WARN_PRIO << (4 * CC_IRQ_RAS_WARN));
  INTC(CC_INTC_PRIO1) = 0u;
  INTC(CC_INTC_THRESHOLD) = 0u;
  RAS(CC_RAS_STATUS) = 0xFFFFu;
  RAS(CC_RAS_WARN_EN) = RAS_WARN_ALL & ~(1u << CC_RAS_SRC_EXT_WARN);   /* the SoC warning line is polled, not interrupt-driven */
  RAS(CC_RAS_FATAL_EN) = RAS_FATAL_ALL;
  RAS(CC_RAS_CTRL) = 0x1u | 0x4u;
  MTIMER(CC_MTIMER_PRESCALE) = 0u;
  timer_arm(TICK_CYCLES);
  WDT(CC_WDT_PRESCALE) = WDT_PRESCALE_RUN;
  WDT(CC_WDT_LOAD) = WDT_LOAD_RUN;
  WDT(CC_WDT_EWI_THRESH) = WDT_EWI_RUN;
  WDT(CC_WDT_CTRL) = CC_WDT_CTRL_EN | CC_WDT_CTRL_EWI_EN;
  wdt_service();
  INTC(CC_INTC_ENABLE) = (1u << CC_IRQ_FATAL) | (1u << CC_IRQ_WDT) | (1u << CC_IRQ_RAS_WARN);
  csr_write(mie, MIE_MEIE | MIE_MTIE | MIE_MSIE);
  irq_enable();
}
