/* =============================================================================
 * AlbionForge firmware -- minimum Albion SoC bring-up and self-test (runs on the ControlCore RV32IM CPU)
 *
 *   1  boot            ControlCore boot ROM has validated this image and jumped here; stages are published in SYSCTRL
 *   2  SRAM init       wait for the Citadel boot policy and for IronMemory's post-reset sweep, read IDs, enable scrubbing
 *   3  DMA config      IOMMU-model entries (domain-bound), buffer-manager buffers (ownership + read / write masks), DMA enable
 *   4  DMA issue       descriptors built in SRAM, submitted through the hardware-bound submission queue
 *   5  wait            poll for completion (DONE_COUNT), bounded by a cycle timeout
 *   6  check           destination vs source (byte exact, guard bytes untouched), DMA CRC vs the firmware's own CRC-32
 *   7  counters        Meridian / IronMemory / CloudDMA / CPU counters printed as "ALBION PERF key=value" lines
 *   8  report          "ALBION RESULT PASS|FAIL", mailbox words, TEST_CTRL pins (DONE / FAIL / code)
 *
 * Every test result is derived from hardware behaviour read back by this program; the testbench independently
 * recomputes the expected data (xorshift32 patterns, addresses) and checks the SRAM contents through a backdoor.
 * ===========================================================================*/
#include "albion_fw.h"

/* ---------------------------------------------------------------- bookkeeping */
static uint32_t g_checks, g_fails;
static const char *g_test = "boot";

static void chk(const char *what, int ok, uint32_t got, uint32_t exp) {
  g_checks++;
  if (!ok) {
    g_fails++;
    cprintf("ALBION FAIL test=%s check=%s got=%08x exp=%08x\n", g_test, what, got, exp);
  }
}
#define CHECK_EQ(what, got, exp) do { uint32_t __g = (uint32_t)(got), __e = (uint32_t)(exp); chk(what, __g == __e, __g, __e); } while (0)
#define CHECK_TRUE(what, c)      do { int __c = !!(c); chk(what, __c, (uint32_t)__c, 1u); } while (0)

static void test_begin(const char *name) { g_test = name; cprintf("ALBION TEST %s begin cycle=%u\n", name, cycles()); }
static void test_end(void) { cprintf("ALBION TEST %s end checks=%u fails=%u\n", g_test, g_checks, g_fails); }

/* xorshift32: the testbench re-implements the same generator */
static uint32_t xs(uint32_t *s) {
  uint32_t x = *s;
  x ^= x << 13; x ^= x >> 17; x ^= x << 5;
  return *s = x;
}
#define SEED_SRC 0xA1B10001u
#define SEED_RW  0x5EED0002u

/* ---------------------------------------------------------------- register helpers */
static uint32_t soc_rd(uint32_t off) { return ALB_SOCR(off); }
static void     soc_wr(uint32_t off, uint32_t v) { ALB_SOCR(off) = v; }
static uint32_t iron_rd(uint32_t off) { return ALB_IRONR(off); }
static void     iron_wr(uint32_t off, uint32_t v) { ALB_IRONR(off) = v; }
static uint32_t dma_rd(uint32_t off) { return ALB_DMAR(off); }
static void     dma_wr(uint32_t off, uint32_t v) { ALB_DMAR(off) = v; }

static uint32_t mer_cnt(uint32_t idx) { soc_wr(ALB_SOC_PERF_SEL, idx); return soc_rd(ALB_SOC_PERF_DATA); }
static uint64_t dma_perf(uint32_t id) {
  dma_wr(DMA_PERF_SEL, id);
  uint32_t lo = dma_rd(DMA_PERF_LO);
  uint32_t hi = dma_rd(DMA_PERF_HI);
  return ((uint64_t)hi << 32) | lo;
}

/* ---------------------------------------------------------------- buffer manager (IronMemory) */
typedef struct { uint32_t status, id, start_lo, start_hi, len, owner, rd, wr, err, info; } bm_rsp_t;
static int bm_cmd(uint32_t op, uint32_t id, uint32_t type, uint64_t start, uint32_t len, uint32_t owner, uint32_t rd,
                  uint32_t wr, bm_rsp_t *r) {
  iron_wr(ALB_IRON_BM_ID, id);
  iron_wr(ALB_IRON_BM_TYPE, type);
  iron_wr(ALB_IRON_BM_START_LO, (uint32_t)start);
  iron_wr(ALB_IRON_BM_START_HI, (uint32_t)(start >> 32));
  iron_wr(ALB_IRON_BM_LEN, len);
  iron_wr(ALB_IRON_BM_OWNER, owner);
  iron_wr(ALB_IRON_BM_RDMASK, rd);
  iron_wr(ALB_IRON_BM_WRMASK, wr);
  iron_wr(ALB_IRON_BM_GO, op);
  if (WAIT_FOR(iron_rd(ALB_IRON_BM_STATUS) & 2u, 200000)) return -1;
  r->status = (iron_rd(ALB_IRON_BM_STATUS) >> 4) & 0xFu;
  r->id = iron_rd(ALB_IRON_BM_RSP_ID);
  r->info = iron_rd(ALB_IRON_BM_RSP_INFO);
  r->start_lo = iron_rd(ALB_IRON_BM_RSP_START_LO);
  r->start_hi = iron_rd(ALB_IRON_BM_RSP_START_HI);
  r->len = iron_rd(ALB_IRON_BM_RSP_LEN);
  r->rd = iron_rd(ALB_IRON_BM_RSP_RDMASK);
  r->wr = iron_rd(ALB_IRON_BM_RSP_WRMASK);
  r->err = iron_rd(ALB_IRON_BM_RSP_ERRBITS);
  return 0;
}
static int bm_alloc_at(uint32_t id, uint32_t off, uint32_t len, uint32_t owner, uint32_t rd, uint32_t wr, uint32_t type) {
  bm_rsp_t r;
  if (bm_cmd(BM_ALLOC_AT, id, type, ALB_SRAM_ALP_BASE + off, len, owner, rd, wr, &r)) return -1;
  return (int)r.status;
}

/* ---------------------------------------------------------------- DMA driver (CloudDMA behind the BridgeEngine shims) */
typedef struct { int timeout; uint32_t status, fault, err, txn, bytes, crc, latency, count; } dma_res_t;

static void ptbl_set(uint32_t idx, uint32_t dom, uint32_t asid, uint64_t iova, uint64_t size, uint64_t pa, uint32_t perm) {
  dma_wr(ALB_DMA_PTBL_IDX, idx);
  dma_wr(ALB_DMA_PTBL_DOM, dom);
  dma_wr(ALB_DMA_PTBL_ASID, asid);
  dma_wr(ALB_DMA_PTBL_BASE_LO, (uint32_t)iova);  dma_wr(ALB_DMA_PTBL_BASE_HI, (uint32_t)(iova >> 32));
  dma_wr(ALB_DMA_PTBL_SIZE_LO, (uint32_t)size);  dma_wr(ALB_DMA_PTBL_SIZE_HI, (uint32_t)(size >> 32));
  dma_wr(ALB_DMA_PTBL_PA_LO, (uint32_t)pa);      dma_wr(ALB_DMA_PTBL_PA_HI, (uint32_t)(pa >> 32));
  dma_wr(ALB_DMA_PTBL_FLAGS, 1u | (perm << 1));
  dma_wr(ALB_DMA_PTBL_GO, 1u);
}

/* descriptor word layout: ip/clouddma/docs/02_DESCRIPTOR_FORMAT.md (64 bytes, little endian) */
static void desc_make(uint32_t off, uint32_t flags, uint32_t txn, uint32_t dom_claim, uint32_t len, uint64_t src,
                      uint64_t dst, uint32_t seq) {
  volatile uint32_t *d = (volatile uint32_t *)(uintptr_t)(ALB_SRAM_BASE + off);
  d[0] = 1u | (0u << 8) | (flags << 16);
  d[1] = txn | (dom_claim << 16);
  d[2] = 0u;                                    /* SRC_ASID = DST_ASID = CPL_ASID = 0 (the device address space) */
  d[3] = len;
  d[4] = (uint32_t)src;  d[5] = (uint32_t)(src >> 32);
  d[6] = (uint32_t)dst;  d[7] = (uint32_t)(dst >> 32);
  for (int i = 8; i < 12; i++) d[i] = 0u;       /* NEXT_PTR (unused in array mode), CPL_ADDR */
  d[12] = seq;
  d[13] = 0u; d[14] = 0u; d[15] = 0u;
}

static void dma_run(uint32_t head_iova, dma_res_t *r) {
  uint32_t cnt = dma_rd(ALB_DMA_DONE_COUNT);
  uint32_t t0 = cycles();
  dma_wr(ALB_DMA_SUBMIT_HEAD_LO, head_iova);
  dma_wr(ALB_DMA_SUBMIT_HEAD_HI, 0u);
  dma_wr(ALB_DMA_SUBMIT_ASID, 0u);
  dma_wr(ALB_DMA_SUBMIT_GO, 1u);
  r->timeout = WAIT_FOR(dma_rd(ALB_DMA_DONE_COUNT) != cnt, 2000000);
  uint32_t last = dma_rd(ALB_DMA_DONE_LAST);
  r->status = last & 0xFu;
  r->fault = (last >> 4) & 0xFu;
  r->err = (last >> 8) & 0xFFu;
  r->txn = last >> 16;
  r->bytes = dma_rd(ALB_DMA_DONE_BYTES);
  r->crc = dma_rd(ALB_DMA_DONE_CRC);
  r->latency = dma_rd(ALB_DMA_LAT_LAST);
  r->count = dma_rd(ALB_DMA_DONE_COUNT);
  (void)t0;
}

/* ---------------------------------------------------------------- memory layout inside the shared SRAM (offsets) */
#define OFF_DESC     0x0000u      /* buffer B0: descriptors (read by the DMA, written by the CPU) */
#define OFF_SRC      0x1000u      /* buffer B1: 1 KiB source  (DMA reads) */
#define OFF_DST      0x2000u      /* buffer B2: 1 KiB destination (DMA writes) */
#define OFF_FORBID   0x3000u      /* buffer B3: owned by the CPU domain only */
#define OFF_RO       0x3100u      /* buffer B4: readable by the CPU domain, writable by nobody */
#define OFF_SCRATCH  0x4000u      /* unmanaged memory (raw supervisor access only) */
#define OFF_BIGSRC   0x5000u      /* buffer B5: 4 KiB source for the bandwidth sweep */
#define OFF_BIGDST   0x6000u      /* buffer B6: 4 KiB destination for the bandwidth sweep */
#define IOVA_DESC    0x00000u
#define IOVA_SRC     0x10000u
#define IOVA_DST     0x20000u
#define IOVA_FORBID  0x30000u
#define IOVA_CTL     0x40000u
#define IOVA_SCRATCH 0x50000u
#define IOVA_NONE    0x70000u     /* no IOMMU entry */
#define IOVA_BIGSRC  0x60000u
#define IOVA_BIGDST  0x80000u
#define SEED_BIG     0xB16B00B5u
#define SRC_LEN      0x400u

static uint32_t g_src_words[SRC_LEN / 4];       /* what the source buffer must contain, kept in the CPU's own DMEM */
static void fill_src(void) {
  uint32_t s = SEED_SRC;
  for (uint32_t i = 0; i < SRC_LEN / 4; i++) { g_src_words[i] = xs(&s); SRAM32(OFF_SRC + 4 * i) = g_src_words[i]; }
}
static void fill_dst(uint8_t v) {
  for (uint32_t i = 0; i < 0x400u; i++) SRAM8(OFF_DST + i) = v;
}
static uint32_t src_byte(uint32_t i) { return (g_src_words[i / 4] >> (8 * (i & 3))) & 0xFFu; }
static uint32_t count_diff_dst(uint32_t dst_off, uint32_t src_idx, uint32_t len) {
  uint32_t bad = 0;
  for (uint32_t i = 0; i < len; i++)
    if (SRAM8(dst_off + i) != src_byte(src_idx + i)) bad++;
  return bad;
}
static uint32_t count_guard(uint32_t from, uint32_t to, uint8_t v) {
  uint32_t bad = 0;
  for (uint32_t i = from; i < to; i++) if (SRAM8(OFF_DST + i) != v) bad++;
  return bad;
}

/* ================================================================================================================ tests */
static void t_ident(void) {
  test_begin("ident");
  CHECK_EQ("soc id", soc_rd(ALB_SOC_ID), 0x414C424Eu);
  CHECK_EQ("soc version", soc_rd(ALB_SOC_VERSION), 0x00010000u);
  uint32_t cfg = soc_rd(ALB_SOC_CONFIG);
  CHECK_EQ("soc NM", cfg & 0xFFu, ALB_NM);
  CHECK_EQ("soc NT", (cfg >> 8) & 0xFFu, ALB_NT);
  CHECK_EQ("policy loaded", WAIT_FOR(soc_rd(ALB_SOC_STATUS) & 1u, 100000), 0);
  CHECK_EQ("policy entries", soc_rd(ALB_SOC_POL_ENTRIES), ALB_POLICY_ENTRIES);
  /* SRAM controller: IronMemory */
  CHECK_EQ("iron id", iron_rd(IRON_ID), IRON_ID_VALUE);
  CHECK_EQ("iron init sweep done", WAIT_FOR(iron_rd(IRON_STATUS) & 1u, 400000), 0);
  uint32_t ic = iron_rd(IRON_CONFIG);
  CHECK_EQ("iron banks", ic & 0xFFu, 4);
  CHECK_EQ("iron ecc enabled", (ic >> 20) & 1u, 1);
  CHECK_EQ("iron ports", (ic >> 24) & 0xFu, 2);
  iron_wr(IRON_SCRUB_INT, 4096u);
  iron_wr(IRON_CTRL, 0x3u);                      /* raw supervisor access + scrubbing on */
  CHECK_EQ("iron ctrl", iron_rd(IRON_CTRL) & 0x3Fu, 0x3);
  /* BridgeEngine: CloudDMA */
  CHECK_EQ("dma id", dma_rd(DMA_ID), DMA_ID_VALUE);
  CHECK_EQ("dma bind domain (hardware)", dma_rd(ALB_DMA_BIND_DOM), ALB_DOM_DMA);
  CHECK_EQ("dma data width", (dma_rd(DMA_CAPS0) >> 8) & 0xFFu, 4);   /* log2(16 bytes) */
  test_end();
}

static void t_sram_rw(void) {
  test_begin("sram_rw");
  uint32_t s = SEED_RW;
  /* word writes then read back (spans all four banks many times) */
  for (uint32_t i = 0; i < 256; i++) SRAM32(OFF_SCRATCH + 4 * i) = xs(&s);
  s = SEED_RW;
  uint32_t bad = 0;
  for (uint32_t i = 0; i < 256; i++) if (SRAM32(OFF_SCRATCH + 4 * i) != xs(&s)) bad++;
  CHECK_EQ("word readback", bad, 0);
  /* sub-word writes (read-modify-write inside the ECC word): bytes and halves, neighbours must not change.
   * The expected words come from a model kept in DMEM and updated with the same byte / half writes. */
  uint32_t base = OFF_SCRATCH + 0x800u;
  uint32_t model[20];
  for (uint32_t i = 0; i < 20; i++) { model[i] = 0x11223344u * (i + 1); SRAM32(base + 4 * i) = model[i]; }
  SRAM8(base + 1) = 0xAA;   model[0] = (model[0] & 0xFFFF00FFu) | 0x0000AA00u;
  SRAM8(base + 6) = 0xBB;   model[1] = (model[1] & 0xFF00FFFFu) | 0x00BB0000u;
  SRAM16(base + 10) = 0xCCDD; model[2] = (model[2] & 0x0000FFFFu) | 0xCCDD0000u;
  SRAM8(base + 15) = 0xEE;  model[3] = (model[3] & 0x00FFFFFFu) | 0xEE000000u;
  SRAM8(base + 16) = 0x01;  model[4] = (model[4] & 0xFFFFFF00u) | 0x00000001u;     /* start of the next 8-byte word */
  SRAM16(base + 22) = 0x7E7E; model[5] = (model[5] & 0x0000FFFFu) | 0x7E7E0000u;
  bad = 0;
  for (uint32_t i = 0; i < 20; i++) if (SRAM32(base + 4 * i) != model[i]) bad++;
  CHECK_EQ("sub-word stores vs model", bad, 0);
  /* a read must return what the last write left even across back-to-back different-bank accesses */
  for (uint32_t i = 0; i < 32; i++) SRAM32(OFF_SCRATCH + 0xC00u + 4 * i) = 0xC0DE0000u | i;
  bad = 0;
  for (uint32_t i = 0; i < 32; i++) if (SRAM32(OFF_SCRATCH + 0xC00u + 4 * i) != (0xC0DE0000u | i)) bad++;
  CHECK_EQ("bank interleave readback", bad, 0);
  test_end();
}

static void t_illegal_addr(void) {
  test_begin("illegal_addr");
  uint32_t v = 0;
  /* inside the ControlCore external window but outside every Albion window: answered locally with a bus error */
  CHECK_EQ("read past the SRAM window faults", probe_rd(ALB_SRAM_BASE + ALB_SRAM_SIZE, &v), 5);
  CHECK_EQ("write past the SRAM window faults", probe_wr(ALB_SRAM_BASE + ALB_SRAM_SIZE, 0x12345678u), 7);
  CHECK_EQ("read of unmapped window faults", probe_rd(0x2B000000u, &v), 5);
  CHECK_EQ("write of unmapped window faults", probe_wr(0x3FFFFFFCu, 1u), 7);
  /* register windows: an undefined offset answers a register error */
  CHECK_EQ("undefined SoC register faults", probe_rd(ALB_PERF_BASE + 0x7F0u, &v), 5);
  CHECK_EQ("undefined IronMemory CSR faults", probe_rd(ALB_SRAM_CTL_BASE + 0x7FCu, &v), 5);
  CHECK_EQ("undefined DMA CSR faults", probe_rd(ALB_DMA_BASE + 0x7FCu, &v), 5);
  /* the legal neighbours still work (no state was corrupted by the faults) */
  CHECK_EQ("SoC id still readable", soc_rd(ALB_SOC_ID), 0x414C424Eu);
  SRAM32(OFF_SCRATCH + 0x20u) = 0x600DF00Du;
  CHECK_EQ("SRAM still works", SRAM32(OFF_SCRATCH + 0x20u), 0x600DF00Du);
  test_end();
}

static void t_buffers(void) {
  test_begin("buffers");
  CHECK_EQ("alloc B0 desc",   bm_alloc_at(0, OFF_DESC,   0x100, 0, DOM_BIT(0) | DOM_BIT(1), DOM_BIT(0), BT_CTRL_META), BMS_OK);
  CHECK_EQ("alloc B1 src",    bm_alloc_at(1, OFF_SRC,    SRC_LEN, 0, DOM_BIT(0) | DOM_BIT(1), DOM_BIT(0), BT_DMA_STAGING), BMS_OK);
  CHECK_EQ("alloc B2 dst",    bm_alloc_at(2, OFF_DST,    SRC_LEN, 0, DOM_BIT(0) | DOM_BIT(1), DOM_BIT(0) | DOM_BIT(1), BT_DMA_STAGING), BMS_OK);
  CHECK_EQ("alloc B3 forbid", bm_alloc_at(3, OFF_FORBID, 0x100, 0, DOM_BIT(0), DOM_BIT(0), BT_CTRL_META), BMS_OK);
  CHECK_EQ("alloc B4 ro",     bm_alloc_at(4, OFF_RO,     0x100, 0, DOM_BIT(0), 0, BT_CTRL_META), BMS_OK);
  CHECK_EQ("alloc B5 big src", bm_alloc_at(5, OFF_BIGSRC, 0x1000, 0, DOM_BIT(0) | DOM_BIT(1), DOM_BIT(0), BT_DMA_STAGING), BMS_OK);
  CHECK_EQ("alloc B6 big dst", bm_alloc_at(6, OFF_BIGDST, 0x1000, 0, DOM_BIT(0) | DOM_BIT(1), DOM_BIT(0) | DOM_BIT(1), BT_DMA_STAGING), BMS_OK);
  bm_rsp_t r;
  CHECK_EQ("query B2", bm_cmd(BM_QUERY, 2, 0, 0, 0, 0, 0, 0, &r), 0);
  CHECK_EQ("query status", r.status, BMS_OK);
  CHECK_EQ("query in use", r.info & 1u, 1);
  CHECK_EQ("query length", r.len, SRC_LEN);
  CHECK_EQ("query start", r.start_lo, (uint32_t)(ALB_SRAM_ALP_BASE + OFF_DST));
  CHECK_EQ("query wr mask", r.wr, DOM_BIT(0) | DOM_BIT(1));
  CHECK_EQ("alloc overlapping range refused", bm_alloc_at(7, OFF_SRC + 0x100, 0x100, 0, 1, 1, 0), BMS_OVERLAP);
  CHECK_EQ("misaligned start refused", bm_alloc_at(7, OFF_SRC + 0x10, 0x100, 0, 1, 1, 0), BMS_ALIGN);
  CHECK_EQ("free of an unused id refused", bm_cmd(BM_FREE, 9, 0, 0, 0, 0, 0, 0, &r) == 0 ? (int)r.status : -1, BMS_BADID);
  /* the CPU's own access rules now apply inside managed buffers */
  uint32_t v;
  CHECK_EQ("CPU read of RO buffer ok", probe_rd(ALB_SRAM_BASE + OFF_RO, &v), 0);
  CHECK_EQ("CPU write to RO buffer refused", probe_wr(ALB_SRAM_BASE + OFF_RO, 0xDEADBEEFu), 7);
  CHECK_EQ("RO buffer unchanged", SRAM32(OFF_RO), 0u);
  CHECK_EQ("iron saw a violation", (iron_rd(IRON_STATUS) >> 2) & 1u, 1);
  iron_wr(IRON_STATUS_CLR, 0x3Eu);
  test_end();
}

static void t_dma_copy(void) {
  test_begin("dma_copy");
  dma_wr(DMA_TIMEOUT, 200000u);
  dma_wr(DMA_CTRL, 1u);                                  /* enable (it is 0 at reset: no command starts) */
  ptbl_set(0, ALB_DOM_DMA, 0, IOVA_DESC,   0x1000, ALB_SRAM_ALP_BASE + OFF_DESC,   PERM_R);
  ptbl_set(1, ALB_DOM_DMA, 0, IOVA_SRC,    0x1000, ALB_SRAM_ALP_BASE + OFF_SRC,    PERM_R);
  ptbl_set(2, ALB_DOM_DMA, 0, IOVA_DST,    0x1000, ALB_SRAM_ALP_BASE + OFF_DST,    PERM_W);
  ptbl_set(3, ALB_DOM_DMA, 0, IOVA_FORBID, 0x1000, ALB_SRAM_ALP_BASE + OFF_FORBID, PERM_R | PERM_W);
  ptbl_set(4, ALB_DOM_DMA, 0, IOVA_CTL,    0x1000, ALB_DMA_ALP_BASE,               PERM_R | PERM_W);
  ptbl_set(5, ALB_DOM_DMA, 0, IOVA_SCRATCH, 0x1000, ALB_SRAM_ALP_BASE + OFF_SCRATCH, PERM_R | PERM_W);
  ptbl_set(6, ALB_DOM_DMA, 0, IOVA_BIGSRC, 0x1000, ALB_SRAM_ALP_BASE + OFF_BIGSRC, PERM_R);
  ptbl_set(7, ALB_DOM_DMA, 0, IOVA_BIGDST, 0x1000, ALB_SRAM_ALP_BASE + OFF_BIGDST, PERM_W);
  CHECK_EQ("permission table writes accepted", dma_rd(ALB_DMA_PTBL_STATUS) & 1u, 0);
  fill_src();
  fill_dst(0xA5);
  dma_res_t r;

  /* 1: aligned 1 KiB copy with CRC */
  uint32_t t0 = cycles();
  desc_make(OFF_DESC, DF_HEAD | DF_LAST | DF_CRC_EN, 0x0101, ALB_DOM_DMA, SRC_LEN, IOVA_SRC, IOVA_DST, 0);
  dma_run(IOVA_DESC, &r);
  uint32_t t1 = cycles();
  CHECK_EQ("1KiB: completed", r.timeout, 0);
  CHECK_EQ("1KiB: status OK", r.status, 0);
  CHECK_EQ("1KiB: bytes acknowledged", r.bytes, SRC_LEN);
  CHECK_EQ("1KiB: txn echoed", r.txn, 0x0101);
  CHECK_EQ("1KiB: destination equals source", count_diff_dst(OFF_DST, 0, SRC_LEN), 0);
  static uint8_t tmp[SRC_LEN];
  for (uint32_t i = 0; i < SRC_LEN; i++) tmp[i] = (uint8_t)src_byte(i);
  CHECK_EQ("1KiB: DMA CRC == firmware CRC-32", r.crc, cc_crc32(tmp, SRC_LEN));
  cprintf("ALBION PERF dma1k_cycles=%u dma1k_latency=%u dma1k_bytes=%u\n", t1 - t0, r.latency, r.bytes);

  /* 2: unaligned partial-beat copy: guard bytes around the target must not change */
  fill_dst(0xA5);
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0102, ALB_DOM_DMA, 61, IOVA_SRC + 3, IOVA_DST + 5, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("61B: completed", r.timeout, 0);
  CHECK_EQ("61B: status OK", r.status, 0);
  CHECK_EQ("61B: bytes", r.bytes, 61);
  CHECK_EQ("61B: payload", count_diff_dst(OFF_DST + 5, 3, 61), 0);
  CHECK_EQ("61B: bytes before untouched", count_guard(0, 5, 0xA5), 0);
  CHECK_EQ("61B: bytes after untouched", count_guard(66, 0x400, 0xA5), 0);

  /* 3: scatter-gather chain (array mode) of two elements */
  fill_dst(0xA5);
  desc_make(OFF_DESC,        DF_HEAD | DF_ARRAY, 0x0103, ALB_DOM_DMA, 100, IOVA_SRC + 0x100, IOVA_DST + 0x200, 0);
  desc_make(OFF_DESC + 0x40, DF_LAST,            0x0103, ALB_DOM_DMA, 200, IOVA_SRC + 0x200, IOVA_DST + 0x300, 1);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("chain: completed", r.timeout, 0);
  CHECK_EQ("chain: status OK", r.status, 0);
  CHECK_EQ("chain: bytes", r.bytes, 300);
  CHECK_EQ("chain: element 0", count_diff_dst(OFF_DST + 0x200, 0x100, 100), 0);
  CHECK_EQ("chain: element 1", count_diff_dst(OFF_DST + 0x300, 0x200, 200), 0);
  CHECK_EQ("chain: gap untouched", count_guard(0x264, 0x300, 0xA5), 0);

  /* 4: zero-length element is a validated no-op */
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0104, ALB_DOM_DMA, 0, IOVA_SRC, IOVA_DST, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("zero length: status OK", r.status, 0);
  CHECK_EQ("zero length: bytes", r.bytes, 0);
  test_end();
}

static void t_dma_perm(void) {
  test_begin("dma_perm");
  dma_res_t r;
  uint32_t viol0 = dma_rd(ALB_DMA_VIOL_COUNT);
  uint32_t sec0 = soc_rd(ALB_SOC_SEC_EVENTS);
  fill_dst(0xA5);

  /* (a) source IOVA with no IOMMU entry: refused by the permission checker, nothing is written */
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0201, ALB_DOM_DMA, 64, IOVA_NONE, IOVA_DST, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("unmapped src: error", r.status, 1);
  CHECK_EQ("unmapped src: ERR_PERM_SRC", r.err, ERR_PERM_SRC);
  CHECK_EQ("unmapped src: dst untouched", count_guard(0, 64, 0xA5), 0);

  /* (b) destination inside a read-only mapping */
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0202, ALB_DOM_DMA, 64, IOVA_SRC, IOVA_SRC + 0x200, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("read-only dst: error", r.status, 1);
  CHECK_EQ("read-only dst: ERR_PERM_DST", r.err, ERR_PERM_DST);

  /* (c) wrong tenant domain claimed in the descriptor: isolation violation */
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0203, 2, 64, IOVA_SRC, IOVA_DST, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("domain claim: error", r.status, 1);
  CHECK_EQ("domain claim: ERR_DOMAIN_MISMATCH", r.err, ERR_DOMAIN_MISMATCH);
  CHECK_TRUE("domain claim counted as a violation", dma_rd(ALB_DMA_VIOL_COUNT) > viol0);
  CHECK_EQ("domain claim: dst untouched", count_guard(0, 64, 0xA5), 0);

  /* (d) IOMMU allows, IronMemory ownership refuses: destination buffer is owned by the CPU domain only */
  uint32_t iron_viol0 = iron_rd(IRON_CNT_VIOL);
  SRAM32(OFF_FORBID) = 0x0F0F0F0Fu;
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0204, ALB_DOM_DMA, 64, IOVA_SRC, IOVA_FORBID, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("forbidden dst: error", r.status, 1);
  CHECK_EQ("forbidden dst: ERR_BUS_WR", r.err, ERR_BUS_WR);
  CHECK_EQ("forbidden dst: memory untouched", SRAM32(OFF_FORBID), 0x0F0F0F0Fu);
  CHECK_TRUE("IronMemory counted the violation", iron_rd(IRON_CNT_VIOL) > iron_viol0);
  /* the same for a read of the forbidden buffer */
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0205, ALB_DOM_DMA, 64, IOVA_FORBID, IOVA_DST, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("forbidden src: ERR_BUS_RD", r.err, ERR_BUS_RD);
  CHECK_EQ("forbidden src: nothing leaked to dst", count_guard(0, 64, 0xA5), 0);

  /* (e) unmanaged memory is the supervisor's only: the DMA domain is refused */
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0206, ALB_DOM_DMA, 32, IOVA_SRC, IOVA_SCRATCH, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("unmanaged dst: ERR_BUS_WR", r.err, ERR_BUS_WR);

  /* (f) the DMA addresses a control window (IOMMU model maps it): refused by the Meridian Citadel, never reaches a target */
  uint32_t sec1 = soc_rd(ALB_SOC_SEC_EVENTS);
  soc_wr(ALB_SOC_CTRL, 4u);                              /* clear the error log */
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0207, ALB_DOM_DMA, 16, IOVA_SRC, IOVA_CTL + 0x10, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("control window dst: ERR_BUS_WR", r.err, ERR_BUS_WR);
  CHECK_TRUE("fabric counted a security event", soc_rd(ALB_SOC_SEC_EVENTS) > sec1);
  uint32_t info = soc_rd(ALB_SOC_ELOG_INFO);
  CHECK_EQ("error log valid", soc_rd(ALB_SOC_ELOG_VALID), 1);
  CHECK_EQ("error log: master = DMA", (info >> 8) & 0xFu, 1);
  CHECK_EQ("error log: fault = domain not allowed", info & 0xFu, F_DOMAIN);
  CHECK_EQ("error log: status = DENIED", (info >> 4) & 0x7u, 3);
  CHECK_EQ("error log: address", soc_rd(ALB_SOC_ELOG_ADDR_LO), (uint32_t)(ALB_DMA_ALP_BASE + 0x10));
  /* the DMA control registers were not changed by that attempt */
  CHECK_EQ("DMA id intact", dma_rd(DMA_ID), DMA_ID_VALUE);

  /* a good copy still works after all the refusals (no hung state) */
  fill_dst(0xA5);
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0208, ALB_DOM_DMA, 128, IOVA_SRC + 0x40, IOVA_DST + 0x40, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("recovery copy: status OK", r.status, 0);
  CHECK_EQ("recovery copy: payload", count_diff_dst(OFF_DST + 0x40, 0x40, 128), 0);
  CHECK_TRUE("total security events", soc_rd(ALB_SOC_SEC_EVENTS) >= sec0 + 1);
  test_end();
}

/* bandwidth sweep: copies of 64 B .. 4 KiB between managed buffers; latency is measured by hardware (SUBMIT_GO -> completion) */
static void t_dma_sweep(void) {
  test_begin("dma_sweep");
  uint32_t s = SEED_BIG;
  for (uint32_t i = 0; i < 0x1000u / 4; i++) SRAM32(OFF_BIGSRC + 4 * i) = xs(&s);
  static const uint32_t sizes[] = {64u, 256u, 1024u, 4096u};
  for (uint32_t k = 0; k < 4; k++) {
    uint32_t len = sizes[k];
    dma_res_t r;
    for (uint32_t i = 0; i < 0x1000u; i += 4) SRAM32(OFF_BIGDST + i) = 0u;
    uint32_t c0 = mer_cnt(MER_G(MG_CYCLES));
    desc_make(OFF_DESC, DF_HEAD | DF_LAST | DF_CRC_EN, 0x0400 + k, ALB_DOM_DMA, len, IOVA_BIGSRC, IOVA_BIGDST, 0);
    dma_run(IOVA_DESC, &r);
    CHECK_EQ("sweep: completed", r.timeout, 0);
    CHECK_EQ("sweep: status OK", r.status, 0);
    CHECK_EQ("sweep: bytes", r.bytes, len);
    /* destination equals the independently regenerated source stream; bytes beyond len are still zero */
    uint32_t bad = 0, sg = SEED_BIG;
    for (uint32_t i = 0; i < 0x1000u / 4; i++) {
      uint32_t want = (4 * i < len) ? xs(&sg) : 0u;
      if (4 * i >= len) (void)xs(&sg);
      if (SRAM32(OFF_BIGDST + 4 * i) != want) bad++;
    }
    CHECK_EQ("sweep: destination equals source", bad, 0);
    cprintf("ALBION PERF dmasz len=%u latency=%u fabric_cycles=%u\n", len, r.latency, mer_cnt(MER_G(MG_CYCLES)) - c0);
  }
  test_end();
}

static void pol_write(uint32_t idx, uint32_t src, uint32_t dom, uint32_t flags, uint64_t base, uint64_t mask) {
  soc_wr(ALB_SOC_POL_IDX, idx);
  soc_wr(ALB_SOC_POL_SRC, src);
  soc_wr(ALB_SOC_POL_DOM, dom);
  soc_wr(ALB_SOC_POL_FLAGS, flags);
  soc_wr(ALB_SOC_POL_BASE_LO, (uint32_t)base);  soc_wr(ALB_SOC_POL_BASE_HI, (uint32_t)(base >> 32));
  soc_wr(ALB_SOC_POL_MASK_LO, (uint32_t)mask);  soc_wr(ALB_SOC_POL_MASK_HI, (uint32_t)(mask >> 32));
  soc_wr(ALB_SOC_POL_GO, 1u);
}

static void t_policy(void) {
  test_begin("citadel_policy");
  dma_res_t r;
  const uint64_t sram_mask = ~(uint64_t)(ALB_SRAM_SIZE - 1u);
  soc_wr(ALB_SOC_CTRL, 4u);                              /* clear the fabric error log */
  /* revoke the DMA's write right on the SRAM window (boot policy entry 1 = dma -> sram) */
  pol_write(1, 1u << 1, 1u << ALB_DOM_DMA, 0x1u | 0x4u, ALB_SRAM_ALP_BASE, sram_mask);   /* valid | read only */
  fill_dst(0xA5);
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0301, ALB_DOM_DMA, 64, IOVA_SRC, IOVA_DST, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("read-only policy: write refused", r.err, ERR_BUS_WR);
  CHECK_EQ("read-only policy: nothing written", count_guard(0, 64, 0xA5), 0);
  uint32_t info = soc_rd(ALB_SOC_ELOG_INFO);
  CHECK_EQ("error log valid", soc_rd(ALB_SOC_ELOG_VALID), 1);
  CHECK_EQ("error log: fault = right missing", info & 0xFu, F_PERM);
  CHECK_EQ("error log: status = DENIED", (info >> 4) & 0x7u, 3);
  /* restore read + write */
  pol_write(1, 1u << 1, 1u << ALB_DOM_DMA, 0x1u | 0x4u | 0x8u, ALB_SRAM_ALP_BASE, sram_mask);
  desc_make(OFF_DESC, DF_HEAD | DF_LAST, 0x0302, ALB_DOM_DMA, 64, IOVA_SRC, IOVA_DST, 0);
  dma_run(IOVA_DESC, &r);
  CHECK_EQ("restored policy: copy OK", r.status, 0);
  CHECK_EQ("restored policy: payload", count_diff_dst(OFF_DST, 0, 64), 0);

  /* revoke the CPU's own access to the IronMemory control window (entry 2), watch the fault, restore */
  uint32_t v = 0;
  pol_write(2, 1u << 0, 1u << ALB_DOM_CC, 0u, ALB_SRAM_CTL_ALP_BASE, ~(uint64_t)(ALB_SRAM_CTL_SIZE - 1u));   /* invalid entry */
  CHECK_EQ("revoked CPU access faults", probe_rd(ALB_SRAM_CTL_BASE + IRON_ID, &v), 5);
  pol_write(2, 1u << 0, 1u << ALB_DOM_CC, 0x1u | 0x2u | 0x4u | 0x8u, ALB_SRAM_CTL_ALP_BASE, ~(uint64_t)(ALB_SRAM_CTL_SIZE - 1u));
  CHECK_EQ("restored CPU access works", iron_rd(IRON_ID), IRON_ID_VALUE);
  test_end();
}

static void t_perf(void) {
  test_begin("perf");
  uint32_t cyc = mer_cnt(MER_G(MG_CYCLES));
  cprintf("ALBION PERF mer_cycles=%u mer_busy=%u mer_req=%u mer_cpl=%u mer_bytes=%u mer_arbstall=%u\n", cyc,
          mer_cnt(MER_G(MG_BUSY)), mer_cnt(MER_G(MG_REQ)), mer_cnt(MER_G(MG_CPL)), mer_cnt(MER_G(MG_BYTES)),
          mer_cnt(MER_G(MG_ARBSTALL)));
  for (uint32_t m = 0; m < ALB_NM; m++)
    cprintf("ALBION PERF m%u_req=%u m%u_cpl=%u m%u_denied=%u m%u_slverr=%u m%u_bytes_rd=%u m%u_bytes_wr=%u m%u_lat_sum=%u m%u_lat_cnt=%u m%u_lat_max=%u m%u_stall_in=%u\n",
            m, mer_cnt(MER_M(m, MM_REQ)), m, mer_cnt(MER_M(m, MM_CPL)), m, mer_cnt(MER_M(m, MM_DENIED)), m,
            mer_cnt(MER_M(m, MM_SLVERR)), m, mer_cnt(MER_M(m, MM_BYTES_RD)), m, mer_cnt(MER_M(m, MM_BYTES_WR)), m,
            mer_cnt(MER_M(m, MM_LAT_SUM)), m, mer_cnt(MER_M(m, MM_LAT_CNT)), m, mer_cnt(MER_M(m, MM_LAT_MAX)), m,
            mer_cnt(MER_M(m, MM_STALL_IN)));
  for (uint32_t t = 0; t < ALB_NT; t++)
    cprintf("ALBION PERF t%u_req=%u t%u_bytes=%u t%u_arbstall=%u t%u_occ_max=%u\n", t, mer_cnt(MER_T(t, MT_REQ)), t,
            mer_cnt(MER_T(t, MT_BYTES)), t, mer_cnt(MER_T(t, MT_ARBSTALL)), t, mer_cnt(MER_T(t, MT_OCC_MAX)));
  for (uint32_t p = 0; p < 2; p++)
    cprintf("ALBION PERF iron_p%u_req=%u iron_p%u_rd=%u iron_p%u_wr=%u iron_p%u_bytes_rd=%u iron_p%u_bytes_wr=%u iron_p%u_bank_wait=%u iron_p%u_conflict=%u\n",
            p, iron_rd(IRON_CNT_PORT(p, 0)), p, iron_rd(IRON_CNT_PORT(p, 1)), p, iron_rd(IRON_CNT_PORT(p, 2)), p,
            iron_rd(IRON_CNT_PORT(p, 3)), p, iron_rd(IRON_CNT_PORT(p, 4)), p, iron_rd(IRON_CNT_PORT(p, 6)), p,
            iron_rd(IRON_CNT_PORT(p, 7)));
  uint32_t busy = 0, rmw = 0;
  for (uint32_t b = 0; b < 4; b++) { busy += iron_rd(IRON_CNT_BANK(b, 2)); rmw += iron_rd(IRON_CNT_BANK(b, 4)); }
  cprintf("ALBION PERF iron_bank_busy=%u iron_rmw=%u\n", busy, rmw);
  cprintf("ALBION PERF dma_active=%u dma_bytes_rd=%u dma_bytes_wr=%u dma_beats_rd=%u dma_beats_wr=%u dma_xact_ok=%u dma_xact_err=%u dma_lat_sum=%u dma_perm_deny=%u dma_viol=%u\n",
          (uint32_t)dma_perf(PC_ACTIVE), (uint32_t)dma_perf(PC_BYTES_RD), (uint32_t)dma_perf(PC_BYTES_WR),
          (uint32_t)dma_perf(PC_BEATS_RD), (uint32_t)dma_perf(PC_BEATS_WR), (uint32_t)dma_perf(PC_XACT_OK),
          (uint32_t)dma_perf(PC_XACT_ERR), (uint32_t)dma_perf(PC_LAT_SUM), (uint32_t)dma_perf(PC_PERM_DENY),
          (uint32_t)dma_perf(PC_VIOL));
  cprintf("ALBION PERF cpu_cycles=%u soc_cycles=%u axi_errs=%u axi_refused=%u sec_events=%u elog_count=%u\n", cycles(),
          soc_rd(ALB_SOC_CYCLES_LO), dma_rd(ALB_DMA_AXI_ERRS) & 0xFFFFu, dma_rd(ALB_DMA_AXI_ERRS) >> 16,
          soc_rd(ALB_SOC_SEC_EVENTS), soc_rd(ALB_SOC_ELOG_COUNT));
  CHECK_TRUE("fabric carried traffic", mer_cnt(MER_G(MG_REQ)) > 0);
  CHECK_TRUE("fabric counted cycles", cyc > 1000);
  CHECK_TRUE("DMA moved bytes", (uint32_t)dma_perf(PC_BYTES_WR) >= SRC_LEN);
  CHECK_TRUE("DMA read bytes", (uint32_t)dma_perf(PC_BYTES_RD) >= SRC_LEN);
  test_end();
}

/* ================================================================================================================ main */
int main(void) {
  boot_stage(CC_BOOT_STAGE_FW_INIT);
  SYSCTRL(CC_SYSCTRL_RESET_CAUSE) = 0xFu;
  SYSCTRL(CC_SYSCTRL_FW_VERSION) = FW_VERSION;
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING;
  cprintf("\nALBION BOOT firmware=%x.%x misa=%08x mimpid=%08x cycle=%u\n", FW_VERSION >> 16, FW_VERSION & 0xFFFFu,
          csr_read(misa), csr_read(mimpid), cycles());
  platform_init();
  boot_stage(CC_BOOT_STAGE_SELF_TEST);

  uint32_t t_start = cycles();
  t_ident();
  t_sram_rw();
  t_illegal_addr();
  t_buffers();
  t_dma_copy();
  t_dma_perm();
  t_dma_sweep();
  t_policy();
  t_perf();

  uint32_t fails = g_fails;
  cprintf("ALBION SUMMARY checks=%u fails=%u cycles=%u\n", g_checks, fails, cycles() - t_start);
  cprintf("ALBION RESULT %s\n", fails ? "FAIL" : "PASS");
  /* host-visible report: mailbox words + simulation / lab pins (SYSCTRL.TEST_CTRL: [31] DONE [30] FAIL [15:0] code) */
  MBOX_F2H(1) = g_checks;
  MBOX_F2H(2) = fails;
  MBOX_F2H(3) = cycles() - t_start;
  MBOX_F2H(0) = fails ? 0xA1B0FA11u : 0xA1B0900Du;
  MBOX(CC_MBOX_F2H_RING) = 0xA1B0u;
  boot_stage(CC_BOOT_STAGE_HOST_READY);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING | CC_HOST_STATUS_CMDPROC_READY | CC_HOST_STATUS_HOST_READY;
  SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0x80000000u | (fails ? 0x40000000u : 0u) | (fails & 0xFFFFu);
  for (;;) wfi();
  return 0;
}
