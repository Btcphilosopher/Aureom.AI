/* =============================================================================
 * AlbionForge firmware -- shared declarations for the minimum Albion SoC
 *   ControlCore (RV32IM, machine mode) running the SoC bring-up and self-test.
 *   Address constants come from the GENERATED albion_soc_map.h (config/albion_soc.yaml) and the ControlCore
 *   cc_memmap.h; nothing about the memory map is hard-coded here.
 * ===========================================================================*/
#ifndef ALBION_FW_H
#define ALBION_FW_H

#include "cc_hw.h"
#include "albion_soc_map.h"

#define FW_VERSION 0x00010000u

/* ---------------------------------------------------------------- register blocks of the Albion SoC */
#define ALB_SOCR(off)   REG32(ALB_PERF_BASE + (off))
#define ALB_IRONR(off)  REG32(ALB_SRAM_CTL_BASE + (off))
#define ALB_DMAR(off)   REG32(ALB_DMA_BASE + (off))
#define SRAM32(off)     REG32(ALB_SRAM_BASE + (off))
#define SRAM8(off)      (*(volatile uint8_t *)(uintptr_t)(ALB_SRAM_BASE + (off)))
#define SRAM16(off)     (*(volatile uint16_t *)(uintptr_t)(ALB_SRAM_BASE + (off)))

/* ---------------------------------------------------------------- IronMemory CSRs (ip/ironmemory/docs/iron_memory/csr_map.md) */
#define IRON_ID          0x000u
#define IRON_CONFIG      0x004u
#define IRON_STATUS      0x008u
#define IRON_CTRL        0x00Cu
#define IRON_SCRUB_INT   0x010u
#define IRON_STATUS_CLR  0x024u
#define IRON_CNT_CTRL    0x038u
#define IRON_CNT_BANK(b, i)  (0x100u + (b) * 0x20u + (i) * 4u)     /* 0 rd 1 wr 2 busy 3 conflict 4 rmw 5 stall 6 ce 7 ue */
#define IRON_CNT_PORT(p, i)  (0x200u + (p) * 0x40u + (i) * 4u)     /* 0 req 1 rd 2 wr 3 bytes_rd 4 bytes_wr 5 req-stall 6 bank-wait 7 conflict-loss */
#define IRON_CNT_VIOL    0x440u
#define IRON_ID_VALUE    0x53460084u

/* buffer-manager operation codes / response status (sf_iron_pkg) */
enum { BM_ALLOC = 0, BM_ALLOC_AT = 1, BM_FREE = 2, BM_TRANSFER = 3, BM_QUERY = 4, BM_CLEAR_ERR = 5 };
enum { BMS_OK = 0, BMS_NODESC = 1, BMS_NOSPACE = 2, BMS_BADLEN = 3, BMS_BADID = 4, BMS_NOTOWNER = 5, BMS_ALIGN = 6,
       BMS_OVERLAP = 7, BMS_BADARG = 8 };
enum { BT_DMA_STAGING = 0, BT_CTRL_META = 5 };
#define DOM_BIT(d) (1u << (d))

/* ---------------------------------------------------------------- CloudDMA (ip/clouddma) */
#define DMA_ID        0x000u
#define DMA_CAPS0     0x008u
#define DMA_CTRL      0x010u
#define DMA_STATUS    0x014u
#define DMA_IRQ_STAT  0x01Cu
#define DMA_TIMEOUT   0x020u
#define DMA_PERF_SEL  0x030u
#define DMA_PERF_LO   0x034u
#define DMA_PERF_HI   0x038u
#define DMA_CH_STATUS 0x104u
#define DMA_CH_ERR    0x108u
#define DMA_ID_VALUE  0x5346444Du
/* performance counter ids (silicaflux_dma_pkg PC_*) */
enum { PC_ACTIVE = 0, PC_STALL_AR = 1, PC_STALL_AW = 2, PC_STALL_W = 3, PC_BYTES_RD = 9, PC_BYTES_WR = 10, PC_BEATS_RD = 11,
       PC_BEATS_WR = 12, PC_BURSTS_RD = 13, PC_BURSTS_WR = 14, PC_XACT_OK = 18, PC_XACT_ERR = 19, PC_LAT_SUM = 20,
       PC_DESC_FETCH = 21, PC_PERM_REQ = 23, PC_PERM_DENY = 25, PC_VIOL = 26, PC_RD_LAT = 27 };
/* descriptor flags (W0[31:16]) */
#define DF_LAST 0x1u
#define DF_ARRAY 0x2u
#define DF_HEAD 0x4u
#define DF_ORDERED 0x8u
#define DF_CPL_EN 0x10u
#define DF_CRC_EN 0x20u
/* completion error codes (silicaflux_dma_pkg ERR_*) */
enum { ERR_NONE = 0, ERR_DOMAIN_MISMATCH = 0x20, ERR_PERM_DESC = 0x21, ERR_PERM_SRC = 0x22, ERR_PERM_DST = 0x23,
       ERR_BUS_DESC = 0x30, ERR_BUS_RD = 0x31, ERR_BUS_WR = 0x32 };
#define PERM_R 1u
#define PERM_W 2u

/* ---------------------------------------------------------------- Meridian counters (sf_meridian_pkg flat bank, NM = 2, NT = 4) */
#define MER_G(k)      (k)
#define MER_M(m, k)   (8u + (m) * 24u + (k))
#define MER_T(t, k)   (8u + ALB_NM * 24u + (t) * 8u + (k))
enum { MG_CYCLES = 0, MG_BUSY = 1, MG_REQ = 2, MG_CPL = 3, MG_BYTES = 4, MG_ARBSTALL = 5, MG_VIOL = 6 };
enum { MM_REQ = 0, MM_CPL = 1, MM_CPLERR = 2, MM_DECERR = 3, MM_DENIED = 4, MM_TIMEOUT = 5, MM_PROTO = 6, MM_SLVERR = 7,
       MM_BYTES_WR = 8, MM_BYTES_RD = 9, MM_LAT_SUM = 10, MM_LAT_CNT = 11, MM_LAT_MAX = 12, MM_STALL_IN = 15 };
enum { MT_REQ = 0, MT_BYTES = 1, MT_ARBSTALL = 2, MT_OCC_SUM = 3, MT_OCC_MAX = 4, MT_BUSY = 5 };

/* Meridian fault codes (error log) */
enum { F_NONE = 0, F_NOMAP = 1, F_PERM = 2, F_DOMAIN = 3, F_PRIV = 4, F_SPOOF = 5 };

/* ---------------------------------------------------------------- libc subset + console (platform) */
void  *memcpy(void *d, const void *s, size_t n);
void  *memset(void *d, int c, size_t n);
int    memcmp(const void *a, const void *b, size_t n);
void   con_putc(char c);
void   con_puts(const char *s);
void   cprintf(const char *fmt, ...);
uint32_t cc_crc32(const void *data, uint32_t len);

/* ---------------------------------------------------------------- traps and probes (platform) */
typedef struct { uint32_t x[32]; uint32_t mepc; } trap_frame_t;
enum { EXP_SKIP = 0, EXP_RESUME_RA = 1 };
typedef struct { volatile uint32_t armed, mode, cause, epc, tval, count; } expect_t;
extern expect_t g_expect;
uint32_t probe_rd(uint32_t addr, uint32_t *val);       /* 0 = no trap, else mcause (5 = load access fault) */
uint32_t probe_wr(uint32_t addr, uint32_t val);        /* (7 = store access fault) */
uint32_t probe_wr8(uint32_t addr, uint8_t val);
void     platform_init(void);
uint32_t cycles(void);
void     wdt_service(void);
#define WAIT_FOR(cond, tmo) ({ int __r = 0; uint32_t __t0 = cycles(); \
                               while (!(cond)) { if (cycles() - __t0 > (uint32_t)(tmo)) { __r = -1; break; } } __r; })

#endif
