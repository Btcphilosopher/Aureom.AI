// tb_fpga_top: boots the real firmware through the board-neutral wrapper (no host BFM): the hardware loader writes the image,
// the boot ROM validates it, the firmware runs its self-test; the testbench only watches the LEDs and the UART line.
`timescale 1ns/1ps
`default_nettype none
module tb_fpga_top;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic uart_tx; logic [7:0] led;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  sf_albion_fpga_top #(.CLK_HZ(10_000_000), .BAUD(1_000_000), .IMAGE_FILE("build/fw/albion_fw.hex"), .IMG_WORDS(8192)) u_top (
    .clk_i(clk), .rst_ni(rst_n), .uart_tx_o(uart_tx), .led_o(led));
  // UART receiver (1 Mbaud at 100 MHz sim clock = 100 clocks per bit)
  string line = ""; int n_pass = 0, n_fail = 0; bit seen_result = 0, result_pass = 0;
  initial begin
    forever begin
      @(negedge uart_tx);
      repeat (5) @(posedge clk);                       // middle of the start bit (10 clocks per bit: CLK_HZ / BAUD)
      begin
        logic [7:0] b;
        for (int i = 0; i < 8; i++) begin repeat (10) @(posedge clk); b[i] = uart_tx; end
        repeat (10) @(posedge clk);
        if (b == 8'h0A) begin
          if (line == "ALBION RESULT PASS") begin seen_result = 1; result_pass = 1; end
          if (line == "ALBION RESULT FAIL") begin seen_result = 1; result_pass = 0; end
          if (line.len() > 6 && line.substr(0, 6) == "ALBION") $display("[%0d] UART| %s", cyc, line);
          line = "";
        end else line = {line, string'(b)};
      end
    end
  end
  initial begin
    #100 rst_n = 0; repeat (10) @(posedge clk); rst_n = 1;
    wait (led[3] || cyc > 40_000_000);
    wait (seen_result || cyc > 40_000_000);            // the UART drains the console slowly: wait for the result line
    repeat (2000) @(posedge clk);
    $display("TB FPGA RESULT %s: leds=%08b uart_result_seen=%0d uart_pass=%0d cycles=%0d", (led[3] && !led[4] && !led[1] && led[0] && seen_result && result_pass) ? "PASS" : "FAIL", led, seen_result, result_pass, cyc);
    if (led[3] && !led[4] && !led[1] && led[0] && seen_result && result_pass) $finish(0); else $fatal(1, "fpga wrapper run failed");
  end
endmodule
`default_nettype wire
