// =============================================================================
// AlbionForge :: tb_albion_soc -- system testbench and HOST SIMULATION INTERFACE of the minimum Albion SoC
//
// The testbench plays exactly two roles and never touches the design's state except through the host port:
//   * the HOST: an SFB2 master on ControlCore's host access port.  It waits for the boot ROM's WAIT_IMAGE stage, writes the
//     firmware image (built by the RISC-V cross compiler) into instruction SRAM, rings the mailbox, and then watches the
//     SYSCTRL.TEST_CTRL pins, the console and the mailbox report.  It also drives the host-reset and power-on reset pins.
//   * the CHECKER: passive monitors (alp_scoreboard on both fabric master ports; control-bus monitors), plus an independent
//     BACKDOOR comparison of the shared SRAM contents against data the testbench computes itself (xorshift32 patterns) --
//     the firmware's own checks are not trusted.
//
// Plusargs  +fw=<image.hex>  +scenario=normal|reset_mid_dma|reset_early|reset_async  +rst_at=<cycles after DMA test start>
//           +timeout=<cycles>  +seed=<n>  +out=<result.json>  +log=<console.log>  +hostbp=<0..90>
// Result    "TB RESULT PASS|FAIL ..." and a JSON file; exit status 0 / 1.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_albion_soc #(
  parameter int STALL_PCT = 0,
  parameter logic [31:0] STALL_SEED = 32'h1BADB002
);
  import cc_memmap_pkg::*;

  // ------------------------------------------------------------------ clock / reset
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  string   scenario, fw_path, out_path, log_path;
  longint  timeout;
  int      seed, hostbp, tb_fails = 0;
  logic [1:0] boot_mode = 2'b00;
  logic    host_rst = 1'b0;

  // ------------------------------------------------------------------ DUT
  logic        hs_req_valid = 1'b0, hs_req_ready, hs_req_write = 1'b0, hs_rsp_valid, hs_rsp_error, hs_rsp_ready = 1'b1;
  logic [31:0] hs_req_addr = '0, hs_req_wdata = '0, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb = 4'hF;
  logic        host_irq, host_ready, ras_fatal, diag_valid, test_done, test_fail, cpu_sleep, iron_init, fabric_rst_n;
  logic [7:0]  diag_char;
  logic [15:0] test_code;

  sf_albion_soc_min #(.STALL_PCT(STALL_PCT), .STALL_SEED(STALL_SEED)) u_dut (
    .clk, .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(boot_mode), .host_rst_req_i(host_rst),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(host_irq), .host_ready_o(host_ready), .ras_fatal_o(ras_fatal),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep), .iron_init_done_o(iron_init), .fabric_rst_no_o(fabric_rst_n)
  );

  // ------------------------------------------------------------------ passive checkers
  alp_scoreboard #(.NL(2), .LINK_DOM({8'd1, 8'd0}), .LINK_RESTRICTED(2'b10), .MAXO(16)) u_sb (
    .clk, .rst_n(fabric_rst_n),
    .req_valid({u_dut.d_req_valid, u_dut.c_req_valid}), .req_ready({u_dut.d_req_ready, u_dut.c_req_ready}),
    .req_op({u_dut.d_req_op, u_dut.c_req_op}), .req_tag({u_dut.d_req_tag, u_dut.c_req_tag}),
    .req_dom({u_dut.d_req_dom, u_dut.c_req_dom}), .req_attr({u_dut.d_req_attr, u_dut.c_req_attr}),
    .req_addr({u_dut.d_req_addr, u_dut.c_req_addr}), .req_be({u_dut.d_req_be, u_dut.c_req_be}),
    .req_data({u_dut.d_req_data, u_dut.c_req_data}),
    .rsp_valid({u_dut.d_rsp_valid, u_dut.c_rsp_valid}), .rsp_ready({u_dut.d_rsp_ready, u_dut.c_rsp_ready}),
    .rsp_tag({u_dut.d_rsp_tag, u_dut.c_rsp_tag}), .rsp_status({u_dut.d_rsp_status, u_dut.c_rsp_status}),
    .rsp_meta({u_dut.d_rsp_meta, u_dut.c_rsp_meta}), .rsp_data({u_dut.d_rsp_data, u_dut.c_rsp_data}));

  // ControlCore external-port (SFB2) monitor: one transaction in flight, response only after a request, error => zero data
  int unsigned sfb_req = 0, sfb_rsp = 0, sfb_err = 0, sfb_viol = 0;
  bit sfb_busy = 0;
  always @(posedge clk or negedge fabric_rst_n) begin
    if (!fabric_rst_n) sfb_busy <= 1'b0;
    else begin
      if (u_dut.ext_req_valid && u_dut.ext_req_ready) begin
        if (sfb_busy) begin sfb_viol++; $display("[%0t] SFB2 monitor: request accepted while a transaction is in flight", $time); end
        sfb_busy <= 1'b1; sfb_req++;
      end
      if (u_dut.ext_rsp_valid && u_dut.ext_rsp_ready) begin
        if (!sfb_busy && !(u_dut.ext_req_valid && u_dut.ext_req_ready)) begin sfb_viol++; $display("[%0t] SFB2 monitor: response without request", $time); end
        sfb_busy <= 1'b0; sfb_rsp++;
        if (u_dut.ext_rsp_error) begin sfb_err++; if (u_dut.ext_rsp_rdata !== 32'd0) begin sfb_viol++; $display("[%0t] SFB2 monitor: error response with data", $time); end end
      end
    end
  end


  // ------------------------------------------------------------------ optional transaction trace (+trace=<max lines>)
  int trace_max = 0, trace_n = 0;
  initial void'($value$plusargs("trace=%d", trace_max));
  always @(posedge clk) if (trace_max > 0 && trace_n < trace_max) begin
    if (u_dut.ext_req_valid && u_dut.ext_req_ready) begin $display("[%0d] TRACE sfb2 req  we=%0d a=%08h wd=%08h ws=%h", cyc, u_dut.ext_req_write, u_dut.ext_req_addr, u_dut.ext_req_wdata, u_dut.ext_req_wstrb); trace_n++; end
    if (u_dut.ext_rsp_valid && u_dut.ext_rsp_ready) begin $display("[%0d] TRACE sfb2 rsp  rd=%08h err=%0d", cyc, u_dut.ext_rsp_rdata, u_dut.ext_rsp_error); trace_n++; end
    if (u_dut.c_req_valid && u_dut.c_req_ready) begin $display("[%0d] TRACE alp0 req  op=%0h tag=%0d a=%016h be=%04h", cyc, u_dut.c_req_op, u_dut.c_req_tag, u_dut.c_req_addr, u_dut.c_req_be); trace_n++; end
    if (u_dut.c_rsp_valid && u_dut.c_rsp_ready) begin $display("[%0d] TRACE alp0 rsp  tag=%0d st=%0h data=%032h", cyc, u_dut.c_rsp_tag, u_dut.c_rsp_status, u_dut.c_rsp_data); trace_n++; end
    if (u_dut.d_req_valid && u_dut.d_req_ready) begin $display("[%0d] TRACE alp1 req  op=%0h tag=%0d a=%016h be=%04h", cyc, u_dut.d_req_op, u_dut.d_req_tag, u_dut.d_req_addr, u_dut.d_req_be); trace_n++; end
    if (u_dut.d_rsp_valid && u_dut.d_rsp_ready) begin $display("[%0d] TRACE alp1 rsp  tag=%0d st=%0h", cyc, u_dut.d_rsp_tag, u_dut.d_rsp_status); trace_n++; end
  end

  // ------------------------------------------------------------------ console capture
  string line = "";
  function automatic bit starts_with(input string s_, input string pre);
    return (s_.len() >= pre.len()) && (s_.substr(0, pre.len() - 1) == pre);
  endfunction
  int    con_fd;
  int unsigned fw_fail_lines = 0;
  bit    fw_result_seen = 0, fw_result_pass = 0;
  int    fw_checks = 0, fw_fails = 0, fw_cycles = 0;
  string perf_lines [$];
  string test_begin_lines [$];
  longint dma_test_cycle = 0, boot_cycle = 0;
  always @(posedge clk) if (diag_valid) begin
    if (diag_char == 8'h0A) begin
      $display("[%0d] FW| %s", cyc, line);
      if (con_fd != 0) $fdisplay(con_fd, "%s", line);
      if (starts_with(line, "ALBION FAIL")) fw_fail_lines++;
      if (starts_with(line, "ALBION PERF")) perf_lines.push_back(line);
      if (starts_with(line, "ALBION BOOT")) boot_cycle = cyc;
      if (starts_with(line, "ALBION TEST dma_copy begin")) dma_test_cycle = cyc;
      if (line == "ALBION RESULT PASS") begin fw_result_seen = 1; fw_result_pass = 1; end
      if (line == "ALBION RESULT FAIL") begin fw_result_seen = 1; fw_result_pass = 0; end
      if (starts_with(line, "ALBION SUMMARY")) begin
        int c, f, y;
        void'($sscanf(line, "ALBION SUMMARY checks=%d fails=%d cycles=%d", c, f, y));
        fw_checks = c; fw_fails = f; fw_cycles = y;
      end
      line = "";
    end else begin
      line = {line, string'(diag_char)};
    end
  end

  // ------------------------------------------------------------------ host BFM (SFB2 master)
  task automatic host_access(input bit wr, input logic [31:0] a, input logic [31:0] wd, output logic [31:0] rd, output bit err);
    @(negedge clk);
    hs_req_valid = 1'b1; hs_req_write = wr; hs_req_addr = a; hs_req_wdata = wd; hs_req_wstrb = 4'hF;
    #1;
    while (!hs_req_ready) begin @(negedge clk); #1; end
    @(posedge clk);
    #1;
    hs_req_valid = 1'b0;
    // random host-side response back-pressure
    if (hostbp > 0) begin
      while (!hs_rsp_valid) begin @(negedge clk); #1; end
      while ((($urandom % 100) < hostbp)) begin hs_rsp_ready = 1'b0; @(negedge clk); #1; end
      hs_rsp_ready = 1'b1;
    end
    while (!hs_rsp_valid) begin @(negedge clk); #1; end
    rd = hs_rsp_rdata; err = hs_rsp_error;
    @(posedge clk);
  endtask
  task automatic hwr(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; bit e;
    host_access(1'b1, a, d, r, e);
    if (e) begin $display("TB ERROR host write %08h refused", a); tb_fails++; end
  endtask
  task automatic hrd(input logic [31:0] a, output logic [31:0] d);
    bit e;
    host_access(1'b0, a, 32'd0, d, e);
    if (e) begin $display("TB ERROR host read %08h refused", a); tb_fails++; end
  endtask

  task automatic wait_stage(input logic [31:0] st, input longint tmo);
    logic [31:0] v; longint t0 = cyc;
    forever begin
      hrd(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v);
      if (v == st) break;
      if (cyc - t0 > tmo) begin $display("TB ERROR timeout waiting for boot stage %0h (at %0h)", st, v); tb_fails++; break; end
      repeat (200) @(posedge clk);
    end
  endtask

  logic [31:0] img [$];
  task automatic load_image_file();
    int fd; logic [31:0] w;
    img.delete();
    fd = $fopen(fw_path, "r");
    if (fd == 0) $fatal(1, "cannot open firmware image %s", fw_path);
    while ($fscanf(fd, "%h\n", w) == 1) img.push_back(w);
    $fclose(fd);
    $display("TB host: firmware image %s, %0d words", fw_path, img.size());
  endtask
  task automatic host_load();
    longint t0 = cyc;
    for (int i = 0; i < img.size(); i++) hwr(CC_IMEM_BASE + 32'(4 * i), img[i]);
    $display("TB host: image written to IMEM in %0d cycles", cyc - t0);
  endtask
  logic [31:0] rsp [8];
  task automatic mbox_cmd(input logic [31:0] cmd, input longint tmo);
    longint t0 = cyc;
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd);
    hwr(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd);
    while (!host_irq) begin
      @(posedge clk);
      if (cyc - t0 > tmo) begin $display("TB ERROR timeout waiting for the boot ROM answer"); tb_fails++; return; end
    end
    for (int i = 0; i < 8; i++) hrd(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 32'(4 * i), rsp[i]);
    hwr(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
  endtask
  task automatic boot_from_host();
    wait_stage(CC_BOOT_STAGE_WAIT_IMAGE, 2_000_000);
    host_load();
    mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 3_000_000);
    if ((rsp[0] & 32'hFF) != 0) begin $display("TB ERROR boot ROM refused the image: status %0d reason %0h", rsp[0] & 32'hFF, rsp[1]); tb_fails++; end
    else $display("TB host: image accepted by the boot ROM at cycle %0d", cyc);
  endtask

  // ------------------------------------------------------------------ independent expected data (xorshift32) and SRAM backdoor
  function automatic logic [31:0] xs32(inout logic [31:0] s);
    logic [31:0] x = s;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    s = x;
    return x;
  endfunction
  localparam logic [31:0] SEED_SRC = 32'hA1B10001, SEED_RW = 32'h5EED0002;
  localparam int OFF_DESC = 0, OFF_SRC = 'h1000, OFF_DST = 'h2000, OFF_FORBID = 'h3000, OFF_RO = 'h3100, OFF_SCRATCH = 'h4000,
                 OFF_BIGSRC = 'h5000, OFF_BIGDST = 'h6000;
  localparam logic [31:0] SEED_BIG = 32'hB16B00B5;

  // IronMemory bank storage: word w = byte/8, bank = w % 4, row = w / 4; low 64 bits of the SECDED codeword are the data
  function automatic logic [63:0] bd_word(input int unsigned off);
    int unsigned w = off / 8;
    int unsigned bnk = w % 4, row = w / 4;
    logic [71:0] cw;
    case (bnk)
      0: cw = u_dut.u_iron.u_iron.g_bank[0].u_bank.g_fpga.u_sram.ram[row];
      1: cw = u_dut.u_iron.u_iron.g_bank[1].u_bank.g_fpga.u_sram.ram[row];
      2: cw = u_dut.u_iron.u_iron.g_bank[2].u_bank.g_fpga.u_sram.ram[row];
      default: cw = u_dut.u_iron.u_iron.g_bank[3].u_bank.g_fpga.u_sram.ram[row];
    endcase
    return cw[63:0];
  endfunction
  function automatic logic [7:0] bd_byte(input int unsigned off);
    logic [63:0] w = bd_word(off & ~7);
    return w[8*(off & 7) +: 8];
  endfunction

  int unsigned bd_checks = 0, bd_bad = 0;
  task automatic bd_expect(input string what, input int unsigned off, input logic [7:0] exp);
    bd_checks++;
    if (bd_byte(off) !== exp) begin
      bd_bad++;
      if (bd_bad < 20) $display("TB BACKDOOR MISMATCH %s: SRAM[%05h] = %02h, expected %02h", what, off, bd_byte(off), exp);
    end
  endtask

  task automatic backdoor_final_check();
    logic [31:0] s;
    logic [7:0]  src [1024];
    s = SEED_SRC;
    for (int i = 0; i < 256; i++) begin logic [31:0] w = xs32(s); src[4*i] = w[7:0]; src[4*i+1] = w[15:8]; src[4*i+2] = w[23:16]; src[4*i+3] = w[31:24]; end
    // source buffer: exactly the pattern the firmware generated (never modified by anyone afterwards)
    for (int i = 0; i < 1024; i++) bd_expect("src", OFF_SRC + i, src[i]);
    // destination buffer: the last successful DMA copied src[0..63] to dst[0..63]; everything else is the 0xA5 guard fill
    for (int i = 0; i < 1024; i++) bd_expect("dst", OFF_DST + i, (i < 64) ? src[i] : 8'hA5);
    // refused writes left the CPU-owned buffer untouched: 0x0F0F0F0F in word 0, zeros elsewhere in the forbidden / read-only pages
    for (int i = 0; i < 4; i++) bd_expect("forbid", OFF_FORBID + i, 8'h0F);
    for (int i = 4; i < 256; i++) bd_expect("forbid-rest", OFF_FORBID + i, 8'h00);
    for (int i = 0; i < 256; i++) bd_expect("ro", OFF_RO + i, 8'h00);
    // bandwidth-sweep buffers: the last sweep copy moved all 4096 bytes, so destination == source (xorshift32 stream)
    s = SEED_BIG;
    for (int i = 0; i < 1024; i++) begin
      logic [31:0] w = xs32(s);
      for (int b = 0; b < 4; b++) begin bd_expect("bigsrc", OFF_BIGSRC + 4*i + b, w[8*b +: 8]); bd_expect("bigdst", OFF_BIGDST + 4*i + b, w[8*b +: 8]); end
    end
    // the CPU's 256-word random pattern in unmanaged scratch memory
    s = SEED_RW;
    for (int i = 0; i < 256; i++) begin
      logic [31:0] w = xs32(s);
      // words 0x20/4 = 8 was overwritten by the illegal-address test (0x600DF00D at scratch+0x20)
      if (i == 8) w = 32'h600DF00D;
      for (int b = 0; b < 4; b++) bd_expect("scratch", OFF_SCRATCH + 4*i + b, w[8*b +: 8]);
    end
  endtask

  // ------------------------------------------------------------------ result
  task automatic write_json(input bit pass);
    int fd;
    if (out_path == "") return;
    fd = $fopen(out_path, "w");
    $fdisplay(fd, "{");
    $fdisplay(fd, "  \"scenario\": \"%s\", \"pass\": %0d, \"cycles\": %0d, \"stall_pct\": %0d, \"stall_seed\": %0d, \"seed\": %0d,", scenario, pass, cyc, STALL_PCT, STALL_SEED, seed);
    $fdisplay(fd, "  \"firmware\": {\"result_seen\": %0d, \"pass\": %0d, \"checks\": %0d, \"fails\": %0d, \"fail_lines\": %0d, \"selftest_cpu_cycles\": %0d},", fw_result_seen, fw_result_pass, fw_checks, fw_fails, fw_fail_lines, fw_cycles);
    $fdisplay(fd, "  \"pins\": {\"test_done\": %0d, \"test_fail\": %0d, \"test_code\": %0d, \"ras_fatal\": %0d},", test_done, test_fail, test_code, ras_fatal);
    $fdisplay(fd, "  \"backdoor\": {\"checks\": %0d, \"mismatches\": %0d},", bd_checks, bd_bad);
    $fdisplay(fd, "  \"sfb2_monitor\": {\"requests\": %0d, \"responses\": %0d, \"error_responses\": %0d, \"violations\": %0d},", sfb_req, sfb_rsp, sfb_err, sfb_viol);
    $fdisplay(fd, "  \"tb_fails\": %0d,", tb_fails);
    $fdisplay(fd, "  \"scoreboard\": %s,", u_sb.json());
    $fdisplay(fd, "  \"firmware_perf\": [");
    for (int i = 0; i < perf_lines.size(); i++) $fdisplay(fd, "    \"%s\"%s", perf_lines[i], (i == perf_lines.size() - 1) ? "" : ",");
    $fdisplay(fd, "  ]");
    $fdisplay(fd, "}");
    $fclose(fd);
  endtask

  task automatic finish(input string why);
    bit pass;
    repeat (50) @(posedge clk);
    if (scenario == "normal" || scenario == "reset_mid_dma" || scenario == "reset_early" || scenario == "reset_async") backdoor_final_check();
    pass = (tb_fails == 0) && fw_result_seen && fw_result_pass && (fw_fail_lines == 0) && test_done && !test_fail &&
           (bd_bad == 0) && (u_sb.n_errors == 0) && (sfb_viol == 0) && !ras_fatal;
    $display("TB SUMMARY scenario=%s cycles=%0d fw_checks=%0d fw_fails=%0d backdoor=%0d/%0d scoreboard=%0d checks %0d errors sfb2_viol=%0d %s",
             scenario, cyc, fw_checks, fw_fails, bd_checks - bd_bad, bd_checks, u_sb.n_checks, u_sb.n_errors, sfb_viol, why);
    write_json(pass);
    $display("TB RESULT %s scenario=%s cycles=%0d", pass ? "PASS" : "FAIL", scenario, cyc);
    if (con_fd != 0) $fclose(con_fd);
    if (pass) $finish(0); else $fatal(1, "scenario %s failed", scenario);
  endtask

  // ------------------------------------------------------------------ watchdog on the whole run
  initial begin
    if (!$value$plusargs("timeout=%d", timeout)) timeout = 6_000_000;
    wait (cyc > timeout);
    $display("TB RESULT FAIL scenario=%s TIMEOUT at cycle %0d", scenario, cyc);
    tb_fails++;
    write_json(1'b0);
    $fatal(1, "timeout");
  end

  // ------------------------------------------------------------------ main
  initial begin
    logic [31:0] v;
    if (!$value$plusargs("scenario=%s", scenario)) scenario = "normal";
    if (!$value$plusargs("fw=%s", fw_path)) fw_path = "build/fw/albion_fw.hex";
    if (!$value$plusargs("out=%s", out_path)) out_path = "";
    if (!$value$plusargs("log=%s", log_path)) log_path = "";
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("hostbp=%d", hostbp)) hostbp = 0;
    void'($urandom(seed));
    con_fd = 0;
    if (log_path != "") con_fd = $fopen(log_path, "w");
    load_image_file();
    $display("TB scenario=%s stall_pct=%0d seed=%0d hostbp=%0d", scenario, STALL_PCT, seed, hostbp);

    // power-on reset: asserted at time 0 (a real negedge for the asynchronous-reset flops), released synchronously
    #1 rst_n = 1'b0;
    repeat (8) @(posedge clk);
    @(negedge clk); rst_n = 1'b1;

    case (scenario)
      "normal": begin
        boot_from_host();
        while (!test_done) begin @(posedge clk); end
        finish("normal run");
      end
      "reset_mid_dma", "reset_early", "reset_async": begin
        // 1st life: boot, run until the chosen instant, reset (host reset pin = cold-boot path, or rst_ni = power-style
        // asynchronous reset not aligned to the clock), then check that nothing survived and that a full re-run passes.
        int unsigned rst_at;
        int unsigned n_out0, n_out1, n_flush0;
        if (!$value$plusargs("rst_at=%d", rst_at)) rst_at = 0;
        boot_from_host();
        if (scenario == "reset_early") begin
          while (boot_cycle == 0) @(posedge clk);
          while (u_sb.outstanding(0) == 0) @(posedge clk);                 // CPU has a fabric access in flight
        end else begin
          while (dma_test_cycle == 0) @(posedge clk);
          while (u_sb.outstanding(1) < 2) @(posedge clk);                  // the DMA has at least two words in flight
        end
        repeat (rst_at) @(posedge clk);
        n_out0 = u_sb.outstanding(0); n_out1 = u_sb.outstanding(1);
        $display("TB: %s reset at cycle %0d with %0d (CPU link) and %0d (DMA link) transactions in flight", scenario, cyc, n_out0, n_out1);
        if (scenario == "reset_async") begin
          #3 rst_n = 1'b0;                                                  // asynchronous, not aligned to the clock
          repeat (5) @(posedge clk);
          @(negedge clk); rst_n = 1'b1;
        end else begin
          @(negedge clk); host_rst = 1'b1; repeat (4) @(posedge clk); @(negedge clk); host_rst = 1'b0;
        end
        fw_result_seen = 0; fw_result_pass = 0; fw_fail_lines = 0; dma_test_cycle = 0; boot_cycle = 0;
        n_flush0 = u_sb.n_reset_flushes;
        repeat (300) @(posedge clk);
        if (u_sb.n_stale != 0) begin $display("TB ERROR stale response after reset"); tb_fails++; end
        if (u_sb.outstanding(0) + u_sb.outstanding(1) != 0) begin $display("TB ERROR requests still outstanding after reset"); tb_fails++; end
        $display("TB: %0d in-flight requests were flushed by the reset (the rest completed before it took effect)", n_flush0);
        boot_from_host();
        while (!test_done) begin @(posedge clk); end
        finish($sformatf("recovered after a %s reset with %0d transactions in flight", scenario, n_out0 + n_out1));
      end
      default: $fatal(1, "unknown scenario %s", scenario);
    endcase
  end
endmodule

`default_nettype wire
