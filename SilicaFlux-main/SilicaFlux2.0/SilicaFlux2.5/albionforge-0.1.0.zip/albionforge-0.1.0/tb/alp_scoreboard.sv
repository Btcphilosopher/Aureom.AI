// =============================================================================
// AlbionForge :: alp_scoreboard -- passive protocol checker + independent reference model for ALP links
//
// Watches NL ALP v1 initiator links (here: the ControlCore link and the BridgeEngine link, at the Meridian master ports).
// Pure testbench code: no influence on the DUT.  Everything it expects is computed HERE, independently of the DUT:
//   * protocol  (ALP v1)   valid held and every field stable until ready; no X on control; tags returned in request order
//                          (ALP-ORD-01), echoed exactly (ALP-TAG-01); completion metadata well formed (is_write, last = 1);
//                          non-OKAY and write responses carry zero data (ALP-RSP-05); requests legal (aligned, non-zero byte
//                          enables, read/write only); hardware-bound domain correct for the link; at most MAXO outstanding.
//   * data      (SRAM window) a byte-accurate reference memory is built from the writes that were ACKNOWLEDGED with OKAY
//                          (byte enables applied); every OKAY read is compared, byte by byte on the lanes its byte enables select, with it.  Memory is zero after
//                          reset (IronMemory initialises it), so a read of never-written bytes must return zero.
//   * security             a link flagged `restricted` (the DMA) must never receive OKAY outside the SRAM window.
//   * ordering across reset  a fabric reset flushes the queues and the reference memory; a response that arrives with no
//                          outstanding request is an error (no stale transaction survives reset).
//   * measurement          per link / per operation latency (request accept -> response accept), bytes, busy windows.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module alp_scoreboard #(
  parameter int NL = 2,
  parameter logic [63:0] MEM_BASE = 64'h0000_0001_1000_0000,
  parameter int MEM_BYTES = 65536,
  parameter logic [NL*8-1:0] LINK_DOM = {8'd1, 8'd0},
  parameter logic [NL-1:0]   LINK_RESTRICTED = 2'b10,   // links that may only ever be OKAY inside the memory window
  parameter int MAXO = 16
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic [NL-1:0]     req_valid,
  input  wire logic [NL-1:0]     req_ready,
  input  wire logic [NL*4-1:0]   req_op,
  input  wire logic [NL*8-1:0]   req_tag,
  input  wire logic [NL*8-1:0]   req_dom,
  input  wire logic [NL*8-1:0]   req_attr,
  input  wire logic [NL*64-1:0]  req_addr,
  input  wire logic [NL*16-1:0]  req_be,
  input  wire logic [NL*128-1:0] req_data,
  input  wire logic [NL-1:0]     rsp_valid,
  input  wire logic [NL-1:0]     rsp_ready,
  input  wire logic [NL*8-1:0]   rsp_tag,
  input  wire logic [NL*4-1:0]   rsp_status,
  input  wire logic [NL*8-1:0]   rsp_meta,
  input  wire logic [NL*128-1:0] rsp_data
);
  typedef struct {
    bit [3:0]   op;
    bit [7:0]   tag;
    bit [63:0]  addr;
    bit [15:0]  be;
    bit [127:0] data;
    longint     t0;
  } req_t;

  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  byte mem [MEM_BYTES];
  bit  mem_wr [MEM_BYTES];            // byte has been written since reset
  req_t q [NL][$];

  // ---- counters (read by the testbench at the end)
  int unsigned n_checks = 0, n_errors = 0, n_proto_errors = 0, n_data_errors = 0, n_sec_errors = 0, n_stale = 0;
  int unsigned n_req [NL], n_rsp [NL], n_ok [NL], n_err_rsp [NL];
  int unsigned n_status [NL][16];
  longint unsigned bytes_rd [NL], bytes_wr [NL];
  longint unsigned lat_sum [NL][2], lat_cnt [NL][2], lat_max [NL][2], lat_min [NL][2];   // [link][0 = read, 1 = write]
  int unsigned max_outstanding [NL];
  longint unsigned first_cyc [NL], last_cyc [NL];
  int unsigned n_reset_flushes = 0;
  int unsigned n_episodes [NL];
  longint unsigned ep_bytes [NL][$], ep_cycles [NL][$];

  initial begin
    for (int l = 0; l < NL; l++) begin
      n_req[l] = 0; n_rsp[l] = 0; n_ok[l] = 0; n_err_rsp[l] = 0; bytes_rd[l] = 0; bytes_wr[l] = 0; max_outstanding[l] = 0;
      first_cyc[l] = 0; last_cyc[l] = 0; n_episodes[l] = 0;
      for (int s = 0; s < 16; s++) n_status[l][s] = 0;
      for (int k = 0; k < 2; k++) begin lat_sum[l][k] = 0; lat_cnt[l][k] = 0; lat_max[l][k] = 0; lat_min[l][k] = 64'hFFFF_FFFF; end
    end
    for (int i = 0; i < MEM_BYTES; i++) begin mem[i] = 8'h00; mem_wr[i] = 1'b0; end
  end

  task automatic err(input string kind, input string msg);
    n_errors++;
    if (kind == "proto") n_proto_errors++;
    else if (kind == "data") n_data_errors++;
    else if (kind == "sec") n_sec_errors++;
    if (n_errors < 30) $display("[%0t] SCOREBOARD %s ERROR: %s", $time, kind, msg);
  endtask
  task automatic chk(input bit ok, input string kind, input string msg);
    n_checks++;
    if (!ok) err(kind, msg);
  endtask

  // ---- previous-cycle snapshot for the hold / stability rules
  bit        pv_req [NL], pv_rsp [NL];
  bit [235:0] pf_req [NL];
  bit [147:0] pf_rsp [NL];
  bit        pv_valid_req [NL], pv_valid_rsp [NL];

  // ---- episode tracking for bandwidth measurement (gap larger than GAP cycles ends an episode)
  localparam int GAP = 200;
  longint unsigned ep_start [NL], ep_last [NL], ep_b [NL];
  bit              ep_open [NL];
  initial for (int l = 0; l < NL; l++) begin ep_open[l] = 0; ep_start[l] = 0; ep_last[l] = 0; ep_b[l] = 0; end

  task automatic ep_touch(input int l, input int bytes);
    if (ep_open[l] && (cyc - ep_last[l] > GAP)) begin
      ep_bytes[l].push_back(ep_b[l]); ep_cycles[l].push_back(ep_last[l] - ep_start[l] + 1); n_episodes[l]++;
      ep_open[l] = 0;
    end
    if (!ep_open[l]) begin ep_open[l] = 1; ep_start[l] = cyc; ep_b[l] = 0; end
    ep_last[l] = cyc;
    ep_b[l] += bytes;
  endtask
  task automatic ep_flush();
    for (int l = 0; l < NL; l++) if (ep_open[l]) begin
      ep_bytes[l].push_back(ep_b[l]); ep_cycles[l].push_back(ep_last[l] - ep_start[l] + 1); n_episodes[l]++; ep_open[l] = 0;
    end
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      // fabric reset: nothing survives
      for (int l = 0; l < NL; l++) begin
        if (q[l].size() != 0) n_reset_flushes += q[l].size();
        q[l].delete();
        pv_req[l] = 0; pv_rsp[l] = 0;
      end
      for (int i = 0; i < MEM_BYTES; i++) begin mem[i] = 8'h00; mem_wr[i] = 1'b0; end
    end else begin
      for (int l = 0; l < NL; l++) begin
        // ------------------------------------------------ request channel
        begin
          bit [235:0] f;
          f = {req_op[l*4 +: 4], req_tag[l*8 +: 8], req_dom[l*8 +: 8], req_attr[l*8 +: 8], req_addr[l*64 +: 64],
               req_be[l*16 +: 16], req_data[l*128 +: 128]};
          chk(!$isunknown(req_valid[l]) && !$isunknown(req_ready[l]), "proto", $sformatf("link %0d: X on request valid/ready", l));
          if (pv_req[l]) begin
            chk(req_valid[l], "proto", $sformatf("link %0d: request valid withdrawn before ready", l));
            if (req_valid[l]) chk(f === pf_req[l], "proto", $sformatf("link %0d: request fields changed while waiting for ready", l));
          end
          pv_req[l] = req_valid[l] && !req_ready[l];
          pf_req[l] = f;
          if (req_valid[l] && req_ready[l]) begin
            req_t r;
            r.op = req_op[l*4 +: 4]; r.tag = req_tag[l*8 +: 8]; r.addr = req_addr[l*64 +: 64]; r.be = req_be[l*16 +: 16];
            r.data = req_data[l*128 +: 128]; r.t0 = cyc;
            chk(r.op == 4'h1 || r.op == 4'h2, "proto", $sformatf("link %0d: illegal opcode %0h", l, r.op));
            chk(r.addr[3:0] == 4'h0, "proto", $sformatf("link %0d: request address %0h not lane aligned", l, r.addr));
            chk(r.be != 16'h0, "proto", $sformatf("link %0d: request with zero byte enables", l));
            chk(req_dom[l*8 +: 8] === LINK_DOM[l*8 +: 8], "proto",
                $sformatf("link %0d: domain %0d on the wire, hardware binding says %0d", l, req_dom[l*8 +: 8], LINK_DOM[l*8 +: 8]));
            chk(req_attr[l*8 + 7] === 1'b0 && req_attr[l*8 +: 2] != 2'd3, "proto", $sformatf("link %0d: reserved attribute bits", l));
            for (int k = 0; k < q[l].size(); k++)
              chk(q[l][k].tag != r.tag, "proto", $sformatf("link %0d: tag %0d reused while outstanding", l, r.tag));
            q[l].push_back(r);
            chk(q[l].size() <= MAXO, "proto", $sformatf("link %0d: more than %0d outstanding", l, MAXO));
            if (q[l].size() > max_outstanding[l]) max_outstanding[l] = q[l].size();
            n_req[l]++;
            if (first_cyc[l] == 0) first_cyc[l] = cyc;
          end
        end
        // ------------------------------------------------ response channel
        begin
          bit [147:0] f;
          f = {rsp_tag[l*8 +: 8], rsp_status[l*4 +: 4], rsp_meta[l*8 +: 8], rsp_data[l*128 +: 128]};
          chk(!$isunknown(rsp_valid[l]) && !$isunknown(rsp_ready[l]), "proto", $sformatf("link %0d: X on response valid/ready", l));
          if (pv_rsp[l]) begin
            chk(rsp_valid[l], "proto", $sformatf("link %0d: response valid withdrawn before ready", l));
            if (rsp_valid[l]) chk(f === pf_rsp[l], "proto", $sformatf("link %0d: response fields changed while waiting for ready", l));
          end
          pv_rsp[l] = rsp_valid[l] && !rsp_ready[l];
          pf_rsp[l] = f;
          if (rsp_valid[l] && rsp_ready[l]) begin
            if (q[l].size() == 0) begin
              n_stale++;
              err("proto", $sformatf("link %0d: response (tag %0d status %0d) with no outstanding request", l, rsp_tag[l*8 +: 8], rsp_status[l*4 +: 4]));
            end else begin
              req_t r;
              bit [3:0] st;
              int unsigned off;
              bit in_mem;
              r = q[l].pop_front();
              st = rsp_status[l*4 +: 4];
              n_rsp[l]++;
              n_status[l][st]++;
              last_cyc[l] = cyc;
              chk(rsp_tag[l*8 +: 8] == r.tag, "proto", $sformatf("link %0d: response tag %0d, oldest request has tag %0d (in-order rule)", l, rsp_tag[l*8 +: 8], r.tag));
              chk(rsp_meta[l*8 + 0] === (r.op == 4'h2), "proto", $sformatf("link %0d: meta.is_write wrong", l));
              chk(rsp_meta[l*8 + 1] === 1'b1, "proto", $sformatf("link %0d: meta.last not set", l));
              chk(rsp_meta[l*8 + 7 -: 4] == 4'h0, "proto", $sformatf("link %0d: meta reserved bits set", l));
              chk(st <= 4'hB, "proto", $sformatf("link %0d: undefined status %0h", l, st));
              if (st != 4'h0 || r.op == 4'h2) chk(rsp_data[l*128 +: 128] === 128'd0, "proto", $sformatf("link %0d: data lanes not zero on a %s", l, (st != 4'h0) ? "non-OKAY response" : "write completion"));
              in_mem = (r.addr >= MEM_BASE) && (r.addr + 16 <= MEM_BASE + MEM_BYTES);
              off = int'(r.addr - MEM_BASE);
              if (st == 4'h0) begin
                n_ok[l]++;
                if (r.op == 4'h1) begin
                  bytes_rd[l] += 16;
                  ep_touch(l, 16);
                  // only the lanes the request enabled carry read data (a narrow CPU read enables one 32-bit lane)
                  if (in_mem) for (int b = 0; b < 16; b++) if (r.be[b]) begin
                    bit [7:0] got = rsp_data[l*128 + b*8 +: 8];
                    chk(got === mem[off + b], "data",
                        $sformatf("link %0d read @%0h byte %0d: got %02h, reference memory has %02h (written: %0d)", l, r.addr, b, got, mem[off + b], mem_wr[off + b]));
                  end
                end else begin
                  for (int b = 0; b < 16; b++) if (r.be[b]) begin
                    bytes_wr[l]++;
                    if (in_mem) begin mem[off + b] = r.data[b*8 +: 8]; mem_wr[off + b] = 1'b1; end
                  end
                  ep_touch(l, $countones(r.be));
                end
                if (LINK_RESTRICTED[l]) chk(in_mem, "sec", $sformatf("link %0d (restricted) got OKAY outside the SRAM window @%0h", l, r.addr));
              end else begin
                n_err_rsp[l]++;
              end
              begin
                int k = (r.op == 4'h2) ? 1 : 0;
                longint unsigned d = cyc - r.t0;
                lat_sum[l][k] += d; lat_cnt[l][k]++;
                if (d > lat_max[l][k]) lat_max[l][k] = d;
                if (d < lat_min[l][k]) lat_min[l][k] = d;
              end
            end
          end
        end
      end
    end
  end

  function automatic int unsigned outstanding(input int l);
    return q[l].size();
  endfunction
  function automatic bit [7:0] ref_byte(input int unsigned off);
    return mem[off];
  endfunction
  function automatic bit ref_written(input int unsigned off);
    return mem_wr[off];
  endfunction

  function automatic string json();
    string s = "{";
    ep_flush();
    s = {s, $sformatf("\"checks\": %0d, \"errors\": %0d, \"proto_errors\": %0d, \"data_errors\": %0d, \"security_errors\": %0d, \"stale_responses\": %0d, \"reset_flushed_requests\": %0d, \"links\": [",
                      n_checks, n_errors, n_proto_errors, n_data_errors, n_sec_errors, n_stale, n_reset_flushes)};
    for (int l = 0; l < NL; l++) begin
      s = {s, $sformatf("%s{\"link\": %0d, \"requests\": %0d, \"responses\": %0d, \"ok\": %0d, \"error_responses\": %0d, \"bytes_read\": %0d, \"bytes_written\": %0d, \"max_outstanding\": %0d, ",
                        (l == 0) ? "" : ", ", l, n_req[l], n_rsp[l], n_ok[l], n_err_rsp[l], bytes_rd[l], bytes_wr[l], max_outstanding[l])};
      s = {s, $sformatf("\"read_latency\": {\"count\": %0d, \"mean\": %0.2f, \"min\": %0d, \"max\": %0d}, ",
                        lat_cnt[l][0], (lat_cnt[l][0] == 0) ? 0.0 : real'(lat_sum[l][0]) / real'(lat_cnt[l][0]), (lat_cnt[l][0] == 0) ? 0 : lat_min[l][0], lat_max[l][0])};
      s = {s, $sformatf("\"write_latency\": {\"count\": %0d, \"mean\": %0.2f, \"min\": %0d, \"max\": %0d}, ",
                        lat_cnt[l][1], (lat_cnt[l][1] == 0) ? 0.0 : real'(lat_sum[l][1]) / real'(lat_cnt[l][1]), (lat_cnt[l][1] == 0) ? 0 : lat_min[l][1], lat_max[l][1])};
      s = {s, "\"status_counts\": {"};
      begin
        bit first = 1;
        for (int k = 0; k < 16; k++) if (n_status[l][k] != 0) begin
          s = {s, $sformatf("%s\"%0d\": %0d", first ? "" : ", ", k, n_status[l][k])};
          first = 0;
        end
      end
      s = {s, "}, \"episodes\": ["};
      for (int e = 0; e < ep_bytes[l].size(); e++)
        s = {s, $sformatf("%s{\"bytes\": %0d, \"cycles\": %0d}", (e == 0) ? "" : ", ", ep_bytes[l][e], ep_cycles[l][e])};
      s = {s, "]}"};
    end
    s = {s, "]}"};
    return s;
  endfunction
endmodule

`default_nettype wire
