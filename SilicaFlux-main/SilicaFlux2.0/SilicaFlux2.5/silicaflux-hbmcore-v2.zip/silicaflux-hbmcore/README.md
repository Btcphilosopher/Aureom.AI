# SILICAFLUX HBMCORE — v2

A parameterised **HBM4-*style*** memory-controller subsystem for the SilicaFlux-HPC chip, from Aureom.AI / SilicaFlux-HPC.
It contains:

* SystemVerilog RTL, plus a generated Silica Flux `.sf` export;
* a behavioural DRAM model with an independent timing checker;
* an independent Python reference model;
* cocotb, formal, equivalence and mutation verification;
* DataFabric NoC and DMA integration;
* benchmarks, proxy synthesis, an activity export, a dashboard and documentation.

> ## Status — read this first
> * **Simulation-grade engineering model. Not silicon-ready.** Passing every test here does not make the controller usable
>   with a real HBM4 stack (`docs/REAL_SILICON_REQUIREMENTS.md`).
> * **No JEDEC / HBM4 / DFI compliance is claimed.** No JESD270-4 text, vendor datasheet or licensed PHY document was
>   available.
>   * Every timing profile is `HYPOTHETICAL_SIM`.
>   * The command set is an abstract controller command set with no pin encoding.
>   * PHY backend B is an explicit stub; training is an external PHY service.
>   * The standards matrix has **0** `VERIFIED_*` rows (`docs/STANDARDS_MATRIX.md`, `docs/standards_matrix.json`).
> * **Every performance number is MODELLED**: RTL simulation against a hypothetical profile, never measured hardware.
> * **Synthesis numbers are proxies**:
>   * technology-independent gate statistics (`reports/synth/`);
>   * an **open 45 nm library (NanGate45)** for area and delay (`reports/synth_ng45/`).
>
>   They are not the target node; no OpenROAD/OpenSTA/P&R was available.
> * **The refresh-management (RFM / directed-RFM) block is a research hook**, not RowHammer protection (`docs/ROWHAMMER.md`).
> * **Nothing was committed or pushed to GitHub.** This tree is delivered as a zip.

## What v2 is (and why it is not a rewrite)

The repository already contained a complete HBMCore (v1, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hbmcore.zip`).
The brief says not to duplicate a verified controller, so v2 **re-verified v1 independently** instead of starting again.

1. v1 was re-run unchanged on a stock toolchain (Verilator 5.020): **43 PASS / 26 FAIL**.
   * The main cause: a Verilator 5.020 defect silently disabled the bank-state checks of the behavioural DRAM model, i.e.
     of the *checker*. Reproducer: `verification/toolchain/`.
   * The other cause: an RTL construct that 5.020 rejects (`docs/AUDIT_V2.md`).
2. Three fresh-context reviewers (scheduling core, data path, integration) read the RTL; the new tests found more.
   * **25 findings** are recorded in `docs/REVIEW_V2.md`, plus 2 defects in the v2 tooling itself (S5 benchmark bench, S6 coverage merge), found and fixed while producing the final results.
   * Every fixed item has a test that **fails on v1 and passes on v2**.
   * Among them:
     * late read data after a timeout was delivered to the *next* requester as good data;
     * anti-starvation was defeated;
     * refresh could miss its deadline (three distinct ways);
     * re-init deadlocked;
     * two DMA deadlocks could wedge the shared DataFabric node.
3. New in v2:
   * the **refresh-management research hook** (`rtl/sf_hbm_rfm.sv`);
   * **line coverage** (`reports/coverage/`);
   * **NanGate45 proxy synthesis**;
   * a **restructured SECDED code**, about 6.4 ns -> 1.7 ns on the proxy, **proven equivalent** to v1 for all 2^266 inputs by SAT;
   * a **PHY-ready contract check**;
   * a **4th timing profile** (`sim_trc_slack`, tRC > tRAS + tRP);
   * an **activity export** for PowerGrid / ThermalLab / BandwidthLab;
   * the **external-simulator investigation** (`docs/SIMULATOR_COMPARISON.md`).

Change list: `CHANGELOG.md`. Verification results of the last run: **`reports/STATUS_V2.md`** (generated from the report files).

## Layout

| path | content |
|---|---|
| `rtl/` | 25 SystemVerilog files: `sf_hbm_pkg`, `sf_hbm4_controller`, `sf_hbm_top`, `sf_hbm_stack_cluster`, `sf_hbm_channel`, `sf_hbm_pseudochannel`, `sf_hbm_req_queue`, `sf_hbm_addr_map`, `sf_hbm_bank_fsm`, `sf_hbm_scheduler`, `sf_hbm_timing`, `sf_hbm_command_encoder`, `sf_hbm_write_data`, `sf_hbm_read_return`, `sf_hbm_refresh`, **`sf_hbm_rfm` (v2)**, `sf_hbm_power_state`, `sf_hbm_init`, `sf_hbm_phy_adapter`, `sf_hbm_ecc_ras`, `sf_hbm_perf`, `sf_hbm_csr`, `sf_hbm_rsp_arb`, `sf_hbm_cdc_fifo`, generated `sf_hbm_profile_pkg` |
| `integration/` | `datafabric/sf_hbm_datafabric.sv` (NoC v2 memory node), `dma/sf_hbm_dma_adapter.sv`, vendored NoC contract, VectorCore trace tools, `silicaflux_sf/*.sf` (generated export) |
| `verification/` | `tests/` (self-checking Verilator benches, incl. v2 `tb_read_return`), `hbm4/hbm4_dram_model.sv`, `bfm/`, `cocotb/`, `formal/` (SymbiYosys harnesses, mutants, **`eq_secded.py`**), `toolchain/` (simulator-defect reproducer) |
| `python/` | independent reference model (address map, bank state, timing rules 1-20, scheduler, scoreboard, SECDED, trace checkers), pytest |
| `configs/` | `timing/profiles.json` (4 HYPOTHETICAL profiles -> generated package), `energy/hbm_energy_coefficients.json` (empty template) |
| `scripts/` | regression, simulation, lint, coverage, synthesis (generic and NanGate45), benchmarks, activity export, reports, packaging |
| `reports/` | regression, formal, mutation, cocotb, coverage, SECDED equivalence, benchmarks, synthesis, RowHammer, activity, `STATUS_V2.md` |
| `dashboard/` | `index.html`: 17 views built from the report files ("no data" where an input is missing) |
| `docs/` | architecture and normative contracts, **`AUDIT_V2.md`, `REVIEW_V2.md`, `ROWHAMMER.md`, `SIMULATOR_COMPARISON.md`**, standards matrix, physical design, integration blockers, real-silicon requirements |

## Quick start

Tools used for the v2 results:

* Ubuntu 24.04 packages: `verilator` 5.020, `yosys` 0.33 (incl. `yosys-abc`), `z3`, `boolector`;
* Python 3.13 with `pytest`, `cocotb==1.9.2` and **`yowasp-yosys`**. The last provides the slang SystemVerilog front
  end and SymbiYosys; put its `bin/` on `PATH` or set `YOWASP_BIN`.
* `make hbm-deps` reports what is present. A missing tool is reported as a dependency failure, never as a pass.

```bash
make hbm-deps
make hbm-gen                # timing-profile package + standards matrix (both generated, validated)
make hbm-lint               # Verilator -Wall
make hbm-channel-test       # single pseudo-channel against the timing-aware DRAM model: all profiles x policies + v2 reproducers
make hbm-review-tests       # every v2 review reproducer (unit, channel, refresh, DMA)
make hbm-regression-full    # everything incl. 32 channels / 64 pseudo-channels, formal, cocotb, mutation -> reports/regression.*
make hbm-formal             # SymbiYosys proofs + mutants
make hbm-coverage           # Verilator line coverage -> reports/coverage/
make hbm-benchmark          # benchmarks A-L, scaling, design-space sweep (long)
./scripts/fetch_ng45.sh && make hbm-synthesis-ng45   # proxy area / delay on the open NanGate45 library
make hbm-activity           # activity export (power only with characterised coefficients)
make hbm-report hbm-dashboard
make hbm-zip                # dist/silicaflux-hbmcore-v2.zip
```

The first executable deliverable of the brief is the single-pseudo-channel controller scheduling ACT/RD/WR/PRE (and
refresh) against the timing-aware behavioural model:

```bash
./scripts/vsim.sh tb_pc_single && ./build/tb_pc_single/obj/Vtb_pc_single +TEST=all +PROFILE=1 +POLICY=1
```

## Architecture in one paragraph

The **pseudo-channel** is the replicated unit (`sf_hbm_pseudochannel`). Its request path:

* request queue with dependency / age matrices;
* scheduler: FCFS / FR-FCFS / bank-group-aware, QoS, deadline, batching, starvation override with bank drain, page
  policies, maintenance arbitration;
* 16 counter-based bank FSMs and a cross-bank timing engine;
* command encoder -> PHY adapter -> DRAM model.

Around that path it has:

* write-data staging;
* a read-return completion sequencer (in-order responses, credits, orphan-safe after timeouts);
* a refresh debt engine with bounded postpone / pull-in and an effective-mode switch;
* the RFM research hook;
* power states;
* a controller-side SECDED (256 + 10 bits) with fault injection.

Above it: a channel has two pseudo-channels, and a cluster up to eight channels. `sf_hbm4_controller` adds:

* the address map: linear / channel-interleave / bank-aware, optional bijective hash;
* same-ID order tracking, fence and error entries;
* response arbiters and the init sequencer.

`sf_hbm_top` adds performance counters and the CSR file. See `docs/ARCHITECTURE.md` and `docs/MODULES.md`.

## Results

* **Verification status:** `reports/STATUS_V2.md` (regression, formal, equivalence, mutation, cocotb, coverage).
  * Last full regression: **87 / 87 PASS** (`reports/regression.md`).
  * Line/branch coverage: **93.9 %** of 989 points. This is not functional coverage; the uncovered points are listed in
    `reports/coverage/uncovered.txt`.
* **Benchmarks:** `reports/BENCHMARKS.md` (103 runs, all MODELLED against the hypothetical `sim_ref` profile, 0 DRAM-model
  timing violations). On 64 pseudo-channels:
  * sequential read reaches 1812 GB/s, 88.5 % of the modelled 2048 GB/s;
  * random access reaches 303 GB/s;
  * sequential read with refresh off reaches 1924 GB/s.
  * v1 -> v2: `reports/BENCH_V1_V2.md`. 55 runs are identical; 46 changed by -4.5 % .. +3.3 %, all of them conflict /
    random / contention workloads.
* **Proxy synthesis:** `reports/synth_ng45/SYNTH_NG45.md` (NanGate45) and `reports/synth/SYNTH.md` (generic).
* **RowHammer research hook:** `reports/rowhammer.json` and `docs/ROWHAMMER.md`.
* **Dashboard:** `dashboard/index.html`.

## Not done / limits (full lists: `docs/REAL_SILICON_REQUIREMENTS.md`, `docs/INTEGRATION_BLOCKERS.md`, `docs/MISSING_SPEC.md`)

* No JEDEC HBM4 specification, vendor datasheet or licensed PHY: no compliance, no real timing values, no pin encodings,
  no PHY training. PHY backend B is a stub.
* **Read-modify-write** for partial writes with controller ECC is not implemented (such writes complete with `HERR_POLICY`).
* **Scheduler select** is a ~3.0 ns combinational path on the NanGate45 proxy (DEPTH 16). It needs pipelining before any
  frequency claim (`docs/PHYSICAL_DESIGN.md` §0).
* No independently validated HBM4 DRAM model was available for cross-checking. Ramulator 2.1's HBM4 model contains
  estimated values (`docs/SIMULATOR_COMPARISON.md`).
* RowHammer: the research hook only. No threat model, no device thresholds, no protection claim.
* Coverage is line/block coverage only; there is no functional coverage model. Formal proofs are on reduced-parameter
  harnesses under stated assumptions (`docs/FORMAL.md`).
* Integration:
  * NoC addresses are 32-bit (the `ADDRHI` window is required);
  * one host port cannot feed 32 channels (channel-sliced ingress is required);
  * TensorCore / VectorCore are traffic models and trace replays, because the compute-tile path does not compile from
    the tree and TensorCore has no operand-buffer RTL;
  * the Project 115 scheduler front end is not integrated.
