# v2 repository audit (2026-11-25)

**Scope.**

* Repository: `Aureom.AI`, branch `claude/wonderful-goldberg-ebh7sg`, working tree. 1,103 files: 533 zip, 299 png, 107 pdf, 74 py, 33 `.sf`.
* Method: archives were extracted into a scratch directory, and every statement below was checked by running a tool.
* No existing file was modified. HBMCore v2 lives in `silicaflux/hbmcore/`, next to the repository's existing `silicaflux/sim/`.
* Nothing was committed or pushed; the deliverable is a zip.

## 1. Existing HBM work found — and why v2 builds on it instead of starting again

| artefact | what it is | decision |
|---|---|---|
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hbmcore.zip` | **HBMCore v1**: a complete HBM4-*style* memory controller. 24 SystemVerilog RTL files, behavioural DRAM model with an independent timing checker, Python reference model, cocotb, SymbiYosys proofs, mutation tests, benchmarks A-L, a dashboard, a `.sf` export. Claimed 74/74 regression passes on Verilator 5.048. No JEDEC compliance claimed (all timing `HYPOTHETICAL_SIM`). | **Controller of record.** The brief says "do not duplicate an already verified controller", so v2 re-verifies v1 independently, fixes what is wrong and closes the gaps v1 listed. v1 is kept unmodified inside the repository. |
| `.../silicaflux-hbmscheduler-p115.zip` | Project 115. A multi-source HBM **transaction scheduler** front end (5 sources, lanes, response re-ordering, SFMC backend contract). It has no DRAM command sequencing, refresh or bank state. Flat ports and no packages, following the P24/P103/P107 coding rules. Its own audit references HBMCore. | Complementary, not a duplicate. A possible front end to HBMCore's host port (`docs/INTEGRATION_BLOCKERS.md`). Not integrated in v2. |
| `aureom.ai-hbm-digital-twin.zip` | TypeScript/Angular visualiser (per the v1 audit) | not re-checked in v2; not RTL |

The v1 audit (`docs/AUDIT.md`) remains valid for the rest of the repository. Two of its claims were re-checked with Verilator 5.020:

* `memory_controller.sf` lints clean as SystemVerilog (`+systemverilogext+sf`). This confirms that `.sf` is SystemVerilog text with a label.
* `SilicaFlux2.5/noc_interconnect.sf` still fails (`noc_packet_t` undefined).

## 2. Toolchain of v2 (what was actually available)

| tool | version | used for |
|---|---|---|
| Verilator | 5.020 (Ubuntu 24.04 package) | lint, every simulation, coverage |
| Icarus Verilog | 12.0 | installed; not used (no SVA support) |
| Yosys (native) | 0.33 | liberty mapping, ABC timing |
| YoWASP Yosys | 0.71 (PyPI `yowasp-yosys`, includes yosys-slang and SymbiYosys) | SystemVerilog front end for synthesis and formal |
| z3 / boolector | 4.8.12 / 1.5.118 | formal solvers |
| cocotb | 1.9.2 | cocotb tests (v1 needed cocotb 2.x + Verilator >= 5.036; v2 runs on both) |
| Python / pytest | 3.13 / 9.1.1 | reference model, scripts |
| NanGate45 open liberty | OpenROAD-flow-scripts `platforms/nangate45` (downloaded by `scripts/fetch_ng45.sh`, not redistributed) | **proxy** synthesis area/delay |

**Not available:** OpenROAD, OpenSTA, any commercial or target PDK, any HBM4 specification, any licensed PHY documentation.

## 3. Baseline re-verification (v1 exactly as shipped, on this toolchain)

First, the hard-coded `/opt/vl548` tool paths were replaced by `PATH` lookups. That is a portability defect, but without the change nothing could run.

`scripts/regress.py` was then run on all groups except formal, cocotb and the 32-channel build:

* **43 PASS, 26 FAIL.**
* Before that, `make hbm-lint` itself failed: 2 `WIDTHEXPAND` warnings under `-Wall` in Verilator 5.020.

Root causes, all of them now fixed (details: `docs/REVIEW_V2.md`):

1. **22 failures (`pc_single_*`, `timing_rules_*`, refresh, ECC) and the cocotb traffic test: a simulator defect.**
   * Verilator 5.020 keeps only the last member write to an element of a multi-dimensional array of unpacked structs.
   * The behavioural DRAM model kept its bank state in such an array, so it lost its reset values and never saw a bank open. Every first ACT then looked like a tRC violation.
   * The model was the *checker*, so on 5.020 it was blind, not merely noisy.
   * Standalone reproducer: `verification/toolchain/vl_ustruct_member_write.sv`.
2. **4 failures (DataFabric/DMA with the real controller): `BLKLOOPINIT`.** Verilator 5.020 rejects a reset `for` loop with non-blocking writes to an unpacked array in `sf_hbm4_controller` for those configurations.
3. **The benchmark bench never stopped (found when the v2 benchmarks were run; not a regression test).**
   * In `verification/tests/tb_bench.sv` an `always` block sets `finished = 1` when every request has completed, and the
     main `initial` loop waits for it. Built with Verilator 5.020, the loop did not see the flag. Every run went on to its
     4 M-cycle cap: hours for the 32-channel configuration.
   * The measured window (`t_start`..`t_end`) and the latency/bandwidth figures were not affected. The refresh and PRE
     counts, `dram_commands` and the refresh-overhead fraction, however, were counted over the whole capped run
     (e.g. an overhead "fraction" of 608).
   * Adding any statement to the same branch made it work, which points to a simulator scheduling/optimisation defect.
     The fix is structural: the loop also evaluates the completion condition itself.
   * The v1 benchmark JSON files (Verilator 5.048) are sane, so this is specific to 5.020. All shipped benchmark results
     were regenerated with the fixed bench.

After these two fixes alone, the same groups ran **71/71 PASS, including cocotb and the RTL mutation check** (a smoke run on intermediate RTL).

The independent review and the new tests then found further defects in the RTL itself: 4 in the scheduling core, 2 in the data path, 2 deadlocks in the DMA adapter, and 2 refresh-mode-switch failures. They are listed with reproducers in `docs/REVIEW_V2.md`.

## 4. Existing verification coverage (before v2)

* v1 collected **no** line or functional coverage metric. v2 adds Verilator line/block coverage (`reports/coverage/COVERAGE.md`).
* v1 formal results were real, but on Verilator-independent harnesses. v2 re-ran all of them with the PyPI YoWASP flow (`reports/formal.json`).

## 5. Integration blockers (unchanged from v1 unless noted)

* NoC address width (32 bits) vs. stack capacity: handled by the `ADDRHI` window.
* A single host port cannot feed 32 channels: the channel-sliced ingress used by the benchmarks is required.
* `compute_tile` / TensorCore operand buffers do not compile from the tree. TensorCore and VectorCore remain traffic models / trace replays.
* **v2 addition:** P115's SFMC backend contract is the natural front end. Adapting it to HBMCore's host port is listed in `docs/INTEGRATION_BLOCKERS.md`.
