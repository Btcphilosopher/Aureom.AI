# Phase 1 - Repository audit (what was actually found and run)

Scope: `Aureom.AI` repository, branch `claude/gallant-cori-4d2vuk`, directory `SilicaFlux-main/` and the top-level archives. Method: every claim
below was checked by extracting archives into a scratch directory and running tools; nothing here is taken from a README. **No existing file was
modified**; all HBMCore work is new files under `SilicaFlux-main/hbmcore/`. Nothing was committed or pushed.

## 0. Layout facts

* 16 top-level directories, 698 tracked non-image files + 32 large PNGs; **385 `.zip` archives**. SilicaFlux-main holds 254 tracked files.
* The SilicaFlux RTL/tool tree is spread across *archives* (131 extracted for this audit) and a handful of loose `.sf` files in
  `SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`.
* Requested filenames, where they are:

| requested | found | notes |
|---|---|---|
| `noc_interconnect.sf` | `SilicaFlux2.5/noc_interconnect.sf` (1069 lines); corrected `.sv` in `silicaflux-datafabric-noc-v2.zip` | the shipped `.sf` does not compile (see 2) |
| `memory_controller.sf` | `SilicaFlux2.5/memory_controller.sf`, `SilicaFlux-main/memory_controller.sf` | **on-chip scratchpad SRAM controller**, not a DRAM controller |
| `sp_ram.sv`, `dp_ram.sv`, `sync_fifo.sv`, `async_fifo.sv`, `mem_pkg.sv` | `memory_cache_repo.zip` (`rtl/`) | also `sf_sync_fifo.sv` (memorycore, sramfabric, memorytest), `extmem_async_fifo.sv`, `sf_crt_async_fifo.sv` |
| `compute_tile.sf` | `SilicaFlux2.5/compute_tile.sf` (2300 lines) | not integrated by the NoC v2 work: its package types are missing (their `KNOWN_LIMITATIONS.md` #3). Not compiled by this audit |
| DataFabric modules | `silicaflux-datafabric.zip`, `-noc.zip`, `-noc-v2.zip` | NoC v2 is the live integration surface |
| DMA interfaces | DataFabric `rtl/dma/*`, `silicaflux-hpc-m05-dma-adapter` (`hpc_dma_adapter`), TensorCore07 `tdma_*` | descriptor-based engines with scratchpad ports |
| TensorCore operand/result | `silicaflux-tensorcore01..10`; `tensor_unit.sf` (4x4 INT MATMUL) | **no dedicated operand-buffer RTL exists** (NoC v2 `KNOWN_LIMITATIONS.md` #4) |
| VectorCore memory | `vector_engine.sf`, `silicaflux-vectorscratch-p76` (`sf_vmem_pkg`) | 128-bit lines |
| clock / reset | `silicaflux-clocktree-p35` (`sf_crt_*`, CDC dir), `silicaflux-powerclock` | |
| Python benchmark tools | `silicaflux-bandwidthlab`, `silicaflux-memorylab` (`python/memorylab/dma.py`), `silicaflux-memoryflow` | modelling tools; not used as authority here |
| simulation / synthesis scripts | `run_sim.sh` (Icarus), `sfx_asm.py`; NoC v2 `synth/`, `Makefile`; `soc_integration.tar.gz`; `silicaflux.sdc` (README) | |
| **HBM controller** | **none.** `aureom.ai-hbm-digital-twin.zip` is an Angular/TypeScript visualiser | see 7 |

## 1. Is `.sf` a special language? - No (empirically)

* Header says "Language: Silica Flux-2017", but `memory_controller.sf` copied to `.sv` lints **clean** with Verilator `--language 1800-2017`.
* `run_sim.sh` compiles `.sf` through stock `iverilog -g2012`. NoC v2 documents `verilator --lint-only +systemverilogext+sf` accepting `.sf` directly,
  and **this repository's `scripts/export_sf.py` re-verifies that** for all HBMCore RTL (23 files, lint PASS).
* Conclusion: `.sf` = SystemVerilog text with a label. No proprietary toolchain is required; HBMCore ships a generated `.sf` export (`integration/silicaflux_sf/`).

## 2. Existing working functionality (reproduced here)

* **NoC v2 + real scratchpad `memory_controller` system test**: built with Verilator 5.020 and run: `tests_passed=10 tests_failed=0` (scalar/vector/burst
  read/write through the 2x2 mesh, error completions, response stall, reset during traffic, counters). This is the baseline HBMCore plugs into.
* `sf_noc_mem_target_ni` / `sf_noc_mem_master_ni`: working memory network interfaces (packet contract v1, 207-bit `noc_packet_t`).

## 3. Source compilation failures

| source | tool | failure |
|---|---|---|
| `SilicaFlux2.5/noc_interconnect.sf` | Verilator | `noc_packet_t` is **not defined** in the shipped `silicaflux_pkg (1).sf` (syntax error at `parameter type pkt_t = noc_packet_t`). NoC v2 supplies it (`silicaflux_noc_section.svh`) |
| `SilicaFlux2.5/memory_controller.sf` | **Icarus Verilog 12** (`run_sim.sh`) | fails at line 1413 (`assert property`): Icarus does not support SVA concurrent assertions. Verilator accepts it |
| `SilicaFlux2.5/tb_memory_controller.sf` | Verilator | **stale**: instantiates `memory_controller` with parameters `ADDR_W, ID_W, BLEN_W, MISALIGN_MODE` that the shipped controller does not have (49 elaboration errors) - it tests a different, older controller |
| `run_sim.sh` layout | - | expects `src/` + `tb/` trees that the repository does not have; needs a manual staging copy |

## 4. Missing packages and dependencies

* `silicaflux_pkg (1).sf` has the memory section only; the NoC section lives in NoC v2.
* `tile_interface`, `compute_tile`, `scheduler`, `silicaflux_top`: package types for the chiplet flit (`sf_tile_pkt_t`, `sf_noc_flit_t`) are absent
  from the tree (NoC v2 `KNOWN_LIMITATIONS.md` #3) - not integrated.
* No OpenROAD / OpenSTA / PDK / liberty library in the environment; no GitHub access from the sandbox.

## 5. Useful reusable modules (and what HBMCore did with them)

| module | reused? |
|---|---|
| `silicaflux_pkg` NoC contract (`noc_packet_t`, `sf_mem_exc_e`, `sf_noc_make_rsp`) | **yes** - imported unmodified, vendored with SHA-256 in `integration/datafabric/third_party/noc_v2/` |
| scratchpad `memory_controller` (burst port) | **yes** - as the real SRAM in `tb_dma_spm.sv` |
| `sf_secded_*`, `sfecc_*` | no - HBMCore needs a 256-bit-granule code with a different layout; written new (`sf_hbm_ecc_ras.sv`) and cross-checked against an independent Python implementation |
| `sync_fifo.sv`, `async_fifo.sv` | no - `sf_hbm_cdc_fifo.sv` written new and tested at four unrelated clock ratios (the existing ones were not re-audited) |
| register bus `rb_*` of `sf_crt_regs` | **yes (shape)** - `sf_hbm_csr.sv` uses the same `rb_sel/rb_we/rb_addr/rb_wdata/rb_rdata/rb_err` signals |
| `hpc_dma_adapter`, DataFabric DMA, `tdma_*` | no - they target the scratchpad/NoC; HBMCore's DMA is a thin NoC master (`sf_hbm_dma_adapter.sv`) |

## 6. Existing verification coverage

* NoC v2: Verilator simulation of 26 configurations x 3 seeds, bounded formal on the router/FIFO/mesh, mutation tests. **No functional or line coverage metric
  was collected** (their `KNOWN_LIMITATIONS.md` #16); formal is mostly bounded (#17).
* Scratchpad `memory_controller`: exercised through the NoC system test; its own `tb_memory_controller.sf` is stale (3).
* HBMCore adds (see `reports/regression.md` for the result of the last run): per-pseudo-channel sweeps over 3 timing profiles x 3 scheduler policies (+ close-page, batching/QoS, PHY-stall and response back-pressure variants,
  non-zero PHY command / read latency, the unimplemented vendor-PHY stub), timing-rule legal/illegal pairs, a starvation directed test, 1/2/4/8/32-channel controller suites, `sf_hbm_top` CSR + performance-counter tests
  (exact and saturating), DataFabric and DMA benches (mock and real backend), a CDC FIFO bench at five clock ratios with mid-run resets, an independent Python model (197 pytest tests) with trace/transaction checkers,
  cocotb tests, bounded **and** unbounded formal proofs (59 SymbiYosys tasks, 33 formal mutants) and a 15-mutant RTL kill check. **HBMCore also collected no functional or line coverage metric.**

## 7. Existing HBM material - and why none of it was reused

`aureom.ai-hbm-digital-twin.zip` is a TypeScript/Angular visualiser (`dram-engine.ts`, `hbm-simulator.ts`, thermal/PDN solvers), **not RTL and not a
verified controller**, so there was nothing to duplicate. Its `hbm-spec.ts` labels profiles "JEDEC HBM4 Next-Gen (2048-Bit)" and lists numbers
(`tRCD 9 ns, tRP 9 ns, tRAS 22 ns, tRC 31 ns, tRFC 380 ns, tREFI 3900 ns, 10 Gb/s, 16-Hi, 64 GB, 32 banks/channel`) **with no source citation**. These were
treated as **UNVERIFIED and not imported**. HBMCore's only timing values are its own HYPOTHETICAL profiles.

## 8. Integration blockers (summary; details in `INTEGRATION_BLOCKERS.md`)

1. 32-bit physical address (`SF_PADDR_W`) cannot address a multi-GiB stack -> address-extension register in the DataFabric adapter.
2. The top-level controller has **one request port** (<= 1 granule/cycle = 32 GB/s at 1 GHz); 32 channels need a channel-sliced ingress (measured, `reports/BENCHMARKS.md`).
3. `compute_tile`/`tile_interface`/`silicaflux_top` do not compile from the tree; TensorCore operand buffers do not exist - TensorCore is modelled as a traffic generator.
4. Shipped Icarus-based `run_sim.sh` cannot compile sources that use SVA (use Verilator).
5. No licensed PHY, no HBM4 specification, no PDK/STA in the environment (`MISSING_SPEC.md`).
