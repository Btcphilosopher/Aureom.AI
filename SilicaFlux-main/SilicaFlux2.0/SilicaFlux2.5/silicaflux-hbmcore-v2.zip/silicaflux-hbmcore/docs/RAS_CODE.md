# Controller-level SECDED code (normative)

One **32-byte granule = 256 data bits** is protected by a (265, 256) Hamming code plus an overall parity bit:
`9` Hamming check bits + `1` overall parity = **10 check bits** per granule (`ecc[9:0]`).

*Status:* ENGINEERING_ASSUMPTION. Whether the HBM4 PHY/DRAM interface offers a sideband path for these 10 bits
is UNVERIFIED (`STANDARDS_MATRIX.md`). This is the **controller** code only; on-die ECC, PHY parity/CRC and
end-to-end protection are separate mechanisms (`RAS.md`).

## Construction

Data bit `d` (0..255, bit 0 = least-significant bit of the granule) is placed at *Hamming position* `pos(d)`:
the positions `1, 2, 3, ...` that are **not powers of two**, in increasing order. So `pos(0) = 3, pos(1) = 5,
pos(2) = 6, pos(3) = 7, pos(4) = 9, ...`.

* check bit `i` (`i = 0..8`) = XOR of all data bits `d` whose `pos(d)` has bit `i` set
* check bit 9 (overall parity) = XOR of all 256 data bits XOR check bits 0..8

## Decoding

`syn[8:0] = recomputed_check[8:0] XOR stored_check[8:0]`, `op = XOR(all data bits) XOR XOR(all 10 stored check bits)`.

| `syn` | `op` | meaning | result |
|---|---|---|---|
| 0 | 0 | clean | data as read, no flag |
| != 0 | 1 | single-bit error | if `syn` is a power of two: a check bit flipped, data is fine (corrected). Else if `syn == pos(d)` for some data bit: flip data bit `d` (corrected). Else (points past the code): **uncorrectable** |
| 0 | 1 | overall-parity bit flipped | corrected, data fine |
| != 0 | 0 | double-bit error | **uncorrectable** |

*Corrected* means `ce = 1`; *uncorrectable* means `ue = 1` and the response carries error code `ECC` (poison).
All-zero data has all-zero check bits (so never-written, zero-initialised memory is a valid codeword).
