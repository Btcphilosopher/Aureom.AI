# Integration blockers: HBMCore <-> the existing SilicaFlux tree

> Scope: concrete, checkable obstacles to connecting HBMCore to the rest of the repository. Evidence is limited to files under `hbmcore/integration/`, `hbmcore/rtl/`, `hbmcore/verification/` and the surrounding `SilicaFlux-main/` tree
> (paths below are relative to `SilicaFlux-main/` unless they start with `hbmcore/`). Items that need a decision, not just code, are marked **[decision]**.
> Nothing here changes the status of HBMCore itself: it is an HBM-style controller, not HBM4-/JEDEC-/DFI-compliant, with hypothetical timing profiles.

Source of the NoC facts: the NoC v2 project's own documents `docs/KNOWN_LIMITATIONS.md`, `docs/AUDIT.md`, `docs/PACKET_SPEC.md`, inside
`SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric-noc-v2.zip` (`PACKET_SPEC.md` is also vendored at `hbmcore/integration/datafabric/third_party/noc_v2/PACKET_SPEC.md`). The zip was extracted to a scratch directory for reading only.

See also `AUDIT.md` (repository audit) and `SILICA_FLUX_COMPAT.md` (`.sf` compatibility); both were written separately and are not restated or reviewed here.

## Summary table

| # | blocker | where it bites | closes with |
|---|---|---|---|
| B1 | 32-bit physical address vs a multi-GiB stack | NoC `addr` is 32 bit; stack is 2^36 bytes at the default geometry | **[decision]** memory map + an `addr_hi` register / wider contract |
| B2 | single request port at the top | `sf_hbm4_controller` accepts one granule per cycle | RTL sliced ingress front end |
| B3 | no compute-core -> NoC producer | `tile_interface`, `compute_tile`, `scheduler`, `silicaflux_top` do not compile from the tree | the missing package section and a flit adapter |
| B4 | `noc_interconnect.sf` lacks `noc_packet_t` | shipped NoC source does not elaborate | vendored NoC v2 `silicaflux_noc_section.svh` (already used by HBMCore) |
| B5 | shipped `tb_memory_controller.sf` is stale | scratchpad regression unusable | rewrite the testbench against the current ports |
| B6 | Icarus 12 cannot compile the shipped SVA | flow scripts using Icarus | use Verilator (as HBMCore does) |
| B7 | tensor operand buffers do not exist | TensorCore traffic is not attached to a buffer | RTL for operand buffers |
| B8 | ordering/fence/hint not mapped | adapter cannot request `ORD_SRC`/`ORD_STRICT`/fence | adapter and contract extension |
| B9 | ECC mode vs partial writes | NoC scalar/vector writes are masked writes | RMW (RAS-04) or ECC off |
| B10 | CSR and perf blocks not wired; no CSR path from the NoC | nobody instantiates `sf_hbm_csr`/`sf_hbm_perf` | integration wrapper + register-map decision |
| B11 | tag/ID parameter coupling | same-ID tracker aliasing, `HBM_ID_W` | parameter rules |
| B12 | NoC-side limits that cap HBM-side use | burst contexts, ID width, no posted writes | NoC project work |
| B13 | clocking/reset assumptions | single clock, unsynchronised reset release | `CDC_AND_CLOCKS.md` |
| B14 | dangling references | files named in RTL/docs that do not exist | housekeeping |

## B1. 32-bit physical address vs a multi-GiB stack **[decision]**

| fact | evidence |
|---|---|
| the SilicaFlux physical address is 32 bit | `hbmcore/integration/datafabric/third_party/noc_v2/silicaflux_pkg.sv`: `SF_PADDR_W = 32`, `sf_paddr_t`; `noc_packet_t.addr` is `[175:144]` (`PACKET_SPEC.md` layout table) |
| an HBMCore stack at the default geometry is 2^36 bytes (64 GiB) | `hbmcore/docs/ADDRESS_MAP.md` / `STANDARDS_MATRIX.md` ARCH-06, `HBM_ADDR_W = 40` (`sf_hbm_geom.svh`) |
| the adapter extends the address | `sf_hbm_datafabric.sv`: `hbm_addr = {addr_hi_i, noc.addr[31:0]}`; one adapter instance sees **one 4 GiB window**; SYS-02 is an `ENGINEERING_ASSUMPTION` |
| `addr_hi_i` source | CSR register `ADDRHI` (0x012) -> `sf_hbm_top.addr_hi_o` (fixed after review); the testbenches drive a constant (`tb_datafabric.sv`, `tb_dma_spm.sv`) or set it explicitly |
| window-crossing bursts are inconsistent | HBM-side address is 40 bit, response flit `addr` wraps in 32 bit (`DATAFABRIC.md` section 5) |
| the DMA checks `hbm_addr_i[39:32]` against `node_addr_hi_i` and rejects a transfer that would wrap the 32-bit window (fixed after review) | `sf_hbm_dma_adapter.sv`, `tb_dma_spm.sv` `error_paths` |

Options (none implemented): one `addr_hi` register per node set by firmware; several nodes each owning a fixed 4 GiB window; widening `SF_PADDR_W` (a packet-contract change: "bump the version and re-check every producer and consumer", `PACKET_SPEC.md` section 4).

## B2. Single request port of the top

`sf_hbm4_controller` has one host request port and one response port (`rtl/sf_hbm4_controller.sv`): at most one 32 B granule per cycle, independent of `NUM_CHANNELS`. The DataFabric adapter in front of it also issues at most one granule per cycle and processes one request/burst at a time.
Channel-sliced ingress exists only as a testbench construct (`verification/tests/tb_bench.sv`, `PORTS=1`) that bypasses the controller top; no synthesizable sliced front end exists (`ARCHITECTURE.md` section 4).
The ordering contract (`docs/ORDERING.md`: same-`{src,id}` tracker, fence = "nothing outstanding anywhere") is defined for the single port; a sliced front end must re-define it. Bandwidth consequences: <!-- RESULTS: filled in by scripts/make_report.py -->.

## B3. No compute-core -> NoC path in the tree

| fact | evidence |
|---|---|
| `compute_tile`, `tile_interface`, `scheduler`, `silicaflux_top` "do not compile from this tree": they use package types (`sf_tile_pkt_t`, `sf_noc_flit_t`, `sf_exec_pkt_t`, ...) from a `silicaflux_pkg` section that is not present | NoC v2 `docs/AUDIT.md` ("What is in the tree"); `docs/KNOWN_LIMITATIONS.md` item 3 |
| `tile_interface` is "not connected": its package (`sf_tile_pkt_t`, `sf_noc_flit_t`) is absent; it speaks `sf_noc_flit_t`, not `noc_packet_t` | `hbmcore/.../noc_v2/PACKET_SPEC.md` section 6 (last row); AUDIT.md |
| re-checked here | `SilicaFlux2.0/SilicaFlux2.5/compute_tile.sf` uses `sf_tile_pkt_t` (lines 135, 182); neither `silicaflux_pkg.sf` nor `silicaflux_pkg (1).sf` defines `sf_tile_pkt_t` (0 matches); the files `tile_interface.sf`, `compute_tile.sf`, `scheduler.sf`, `silicaflux_top.sf` exist in `SilicaFlux2.0/SilicaFlux2.5/` |
| consequence | the ControlCore/VectorCore/TensorCore boxes of the data path (`ARCHITECTURE.md` section 1) have no RTL connection to the NoC in this repository; HBMCore is exercised by testbench masters and the DMA adapter only |

Closing it requires the missing `silicaflux_pkg` section (a source decision) and a tile-to-`noc_packet_t` adapter that does not exist. The `silicaflux-controlcore.zip` / `silicaflux-tensorcore*.zip` archives in the tree were not opened for this document.

## B4. `noc_interconnect.sf` references an undefined `noc_packet_t`

`SilicaFlux2.0/SilicaFlux2.5/noc_interconnect.sf` uses `noc_packet_t` (lines 83 and 814, `parameter type pkt_t = noc_packet_t`; line 45 names the contract) but no `.sf` file in the tree defines it
(`grep` for the name finds only `noc_interconnect.sf`); AUDIT.md defect D0: "router does not elaborate against the shipped package". The NoC v2 project supplies `silicaflux_noc_section.svh` (a 207-bit `noc_packet_t`, contract v1) through one added `include` in the package,
and HBMCore vendors exactly that package (`hbmcore/integration/datafabric/third_party/noc_v2/silicaflux_pkg.sv`, `SHA256SUMS`). **HBMCore therefore builds against the vendored package, not against the shipped `silicaflux_pkg*.sf`**; any flow that picks the shipped package fails to elaborate the NoC.
(The two shipped `silicaflux_pkg.sf` and `silicaflux_pkg (1).sf` files also differ from each other byte-wise.)

## B5. Shipped `tb_memory_controller.sf` is stale versus `memory_controller.sf`

Compared in this session (`SilicaFlux2.0/SilicaFlux2.5/`; the root `memory_controller.sf` is byte-identical to the 2.5 copy):

| aspect | `tb_memory_controller.sf` (instantiation at lines ~1251-1300; header) | `memory_controller.sf` (module header, lines 94-148) |
|---|---|---|
| parameters | `ADDR_W`, `ID_W`, `BLEN_W`, `MISALIGN_MODE` | `SPM_BASE`, `NUM_BANKS`, `BANK_DEPTH`, `SCALAR_LINES`, `SRAM_LATENCY`, `*_RSP_DEPTH`, `BURST_*`, `ARB_ROUND_ROBIN`, `STRICT_DOMAINS`, `FLUSH_KILLS_BURST`, `PARITY_EN`, `INIT_ON_RESET` |
| scalar/vector/burst ports | `s_req_*`, `s_rsp_*`, `v_req_*`, `v_rsp_*`, `b_req_*`, `b_wvalid_i`, `b_wdata_i`, `b_wlast_i`, `b_rsp_*` | `scalar_req_*`, `scalar_rsp_*`, vector ports, `burst_req_*`, `burst_wdata_*`, ... (struct-typed `sf_scalar_mem_req_t`, `sf_burst_desc_t`, ...) |
| other ports | `mem_stall_i`, `trc_valid_o`, `trc_*` (commit trace) | `flush_i`, `burst_kill_i` |
| status | 2-bit `OKAY / ERR_ALIGN / ERR_RANGE`; word-addressed storage `MC_WORDS` | 3-bit `sf_mem_exc_e`; banked 128-bit lines with an aperture tag |

The parameter and port sets do not match, so the testbench cannot instantiate the current DUT. Impact for HBMCore: the on-chip scratchpad that the DMA adapter talks to is exercised only through `verification/tests/tb_dma_spm.sv`
(with the vendored `scratchpad_memory_controller.sv` from NoC v2) and the NoC v2 system tests, not through its own shipped testbench.

## B6. Icarus Verilog 12 fails on the shipped SVA

| evidence | detail |
|---|---|
| NoC v2 `docs/AUDIT.md` | "Icarus 12 rejects the router's concurrent assertions and assignment patterns, even with `-DSYNTHESIS`"; the shipped flow script `run_sim.sh` (Icarus) "cannot build the NoC"; "Verilator is the supported simulator for this project; Icarus 12 is not" |
| NoC v2 `README.md` | "Verilator is the only simulator (Icarus cannot compile the design)" |
| re-run here (iverilog 12.0, scratch output) | on the vendored `scratchpad_memory_controller.sv`: `sorry: concurrent_assertion_item not supported` (lines 1354, 1358, 1378) and `syntax error` / `Error in property_spec of concurrent assertion item` (lines 1362-1367) |
| HBMCore | all scripts use Verilator (`scripts/vsim.sh`, `scripts/lint.sh`: "Verilator >= 5.020 (5.048 used for the shipped results)", default install path `/opt/vl548`, overridable with `VERILATOR`/`VERILATOR_ROOT`). On `rtl/sf_hbm_scheduler.sv` Icarus prints `sorry: constant selects in always_* processes are not currently supported`; Icarus is not a supported HBMCore flow and was not pursued |

## B7. Tensor operand buffers do not exist

NoC v2 `docs/KNOWN_LIMITATIONS.md` item 4: "no such RTL exists in the 2.5 tree; tensor traffic is expressed as VECTOR/BURST transfers to a scratchpad, not attached to a dedicated operand buffer."
In HBMCore, benchmark K (`verification/tests/tb_bench.sv`, "TensorCore GEMM tile loading, double buffered") is a **request-pattern model** (tile loads, a `MACS` compute-cycle number, double-buffer pacing); it is not a TensorCore, and any GEMM figure it prints
is a property of that traffic model against a hypothetical profile: <!-- RESULTS: filled in by scripts/make_report.py -->.

## B8. Ordering, fence and hint are not mapped from the NoC

The adapter's granule interface (`sf_hbm_datafabric.sv`) has no `order` or `fence` output; the controller's `req_order_i` and `req_fence_i` are tied (`ORD_RELAXED`, `0`) by the testbenches. Software that needs `ORD_SRC`, `ORD_STRICT` or a fence across the NoC has no way to express it; the NoC `hint` field is carried back unchanged.
Within one source the adapter ingests in request order and the controller keeps same-granule hazards and same-`{src,id}` order (`ORDERING.md`), but cross-granule order is not guaranteed.

## B9. Controller ECC vs NoC writes

SCALAR and VECTOR writes and unpaired burst beats are masked writes. With `cfg.ecc_en = 1` the controller answers every partial write with `HERR_POLICY` (RMW unimplemented, RAS-04). The adapter returns it as status 3. No testbench enables ECC behind the adapter.
Either ECC stays off in a NoC-attached system, or RMW must be implemented (`RAS.md` section 5, `DATAFABRIC.md` section 2).

## B10. CSR/perf blocks are not wired; no CSR path over the NoC

* No RTL instantiates `sf_hbm_csr`; `sf_hbm_perf` is instantiated only in `tb_ctrl_multi.sv`. The integrator must connect `cfg_o`, the pulses, the status inputs (`ready`, `init_*`, `ecc_alert_any_i`, `unimpl_any_i`, `ref_infeasible_i`, `profile_mhz_i`, `ecc_log_pc_i`, `ev_*_i`) and `perf_*`.
* The CSR bus is `rb_sel/rb_we/rb_addr/rb_wdata/rb_rdata/rb_err` (header: same shape as `sf_crt_regs.sv` of `silicaflux-clocktree-p35`, not re-verified); no address window is assigned in a SoC register map.
* The adapter answers `xfer == CTRL` with `RANGE`: "HBM has no control window behind this NI", so the NoC cannot reach the CSRs through it.
* `cfg.max_burst_m1` (CSR `MAXBURST`) is not consumed by any RTL; the adapter's `max_burst_m1_i` must be connected to it by the integrator.
* `sf_hbm_csr` has no simulation testbench, and its `SCHED0` read-back layout does not match its write layout (`PERF_COUNTERS.md` section 6).

## B11. ID / tag parameter coupling

* `HBM_ID_W = 8` equals `SF_MEM_TAG_W` (`sf_hbm_geom.svh`); `HBM_SRC_W = 4`. The adapter uses 64 tags (`NTAG`) and the constant `HBM_SRC`.
* The controller's same-ID tracker defaults to `TRK_SRC_W = 2`, `TRK_ID_W = 4`; the testbenches use `TRK_ID_W = 6` to match 64 tags. With the default, tags alias and can add stalls when aliasing requests target different pseudo-channels.
* The NoC `txn_id` must be unique per source while outstanding (`PACKET_SPEC.md` rule 4); the adapter's own tag space is separate and independent of it.

## B12. NoC-side limits that bound HBM-side use (from the NoC project)

`docs/KNOWN_LIMITATIONS.md` of NoC v2: one outstanding burst per master NI and one burst context per target NI (item 6); no posted writes on the memory ports (a store is acknowledged); no interrupts, atomics or coherence (item 7); mesh size bounded by `SF_NOC_ID_W = 4` (item 8);
a head-without-tail wormhole packet wedges an output until reset (item 11); the deadlock-freedom of the separate-network configuration is "an argument plus tests, not a machine proof" (item 15); simulation is Verilator-only with seeds 1-3 and no coverage metric (item 16).
`sf_hbm_datafabric` has the same one-burst-read and one-burst-write context limits.

## B13. Clock and reset

HBMCore expects one clock and a reset whose release is synchronised by the integrator; it generates no clock; the PHY side is 1:1. The NoC fabric also leaves reset synchronisation to the integrator (item 2 of the NoC limitations). See `CDC_AND_CLOCKS.md`.

## B14. Dangling references found while documenting

| referenced in | names | present? |
|---|---|---|
| `rtl/sf_hbm_stack_cluster.sv`, `rtl/sf_hbm_scheduler.sv` | `docs/PHYSICAL_DESIGN.md` | not in `docs/` when this document was written |
| `configs/timing/profiles.json` (profile `sim_ref` source text) | `docs/BANDWIDTH.md` | not present when the analysis started; a file of that name appeared in `docs/` while this document was being written (written separately, not reviewed here) |
| `scripts/gen_standards_matrix.py` (PHY-01) | `docs/REAL_SILICON_REQUIREMENTS.md` | same: appeared during writing, not reviewed here |
| `docs/ORDERING.md` | `sf_hbm_txn_split` | no such module in `rtl/` or `integration/`; splitting is done by `sf_hbm_datafabric` |
| `rtl/sf_hbm_refresh.sv` | `sf_hbm_rfm` hook | no such module (`RAS.md` section 7) |
| `rtl/sf_hbm_cdc_fifo.sv` | "bounded formal properties in verification/formal/" for the FIFO | no such harness (`CDC_AND_CLOCKS.md` section 4) |
| `rtl/sf_hbm_csr.sv` | `sf_crt_regs.sv` (silicaflux-clocktree-p35) | inside a zip in the SilicaFlux tree, not checked |

Reports referenced as generated (`reports/synth/`, `reports/regression.*`, `reports/bench/*.json` results) are produced by scripts and are not restated in these documents.

## B15. (v2) Project 115 scheduler front end

`silicaflux-hbmscheduler-p115.zip` is a multi-source scheduling front end with an SFMC backend contract and per-source
response re-ordering. It contains no DRAM command sequencing. Putting it in front of HBMCore needs three things:

* an SFMC -> `sf_hbm4_controller` host-port adapter: granule size, tags vs. `{src,id}`, write-data credit;
* a decision on which block owns reordering and QoS;
* a channel-sliced ingress (B2).

None of this was done in v2.
