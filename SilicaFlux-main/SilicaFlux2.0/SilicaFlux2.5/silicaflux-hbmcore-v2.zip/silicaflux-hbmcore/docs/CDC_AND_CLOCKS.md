# Clock domains, clock-domain crossing and reset-domain crossing

> **Status.** Everything in HBMCore runs on **one clock today**. The dual-clock FIFO and the reset synchroniser exist and are tested in isolation (`verification/tests/tb_cdc_fifo.sv`), but **no RTL module instantiates them**.
> The PHY clock ratio is **1:1 only**; any other ratio is a PHY-contract item (`docs/STANDARDS_MATRIX.md` IF-05, `UNIMPLEMENTED`). HBMCore **generates no clocks**.

## 1. Clock domains

| domain | members | what exists today | where a crossing would sit |
|---|---|---|---|
| **DataFabric** (NoC) | NoC masters, `integration/datafabric/sf_hbm_datafabric.sv`, `integration/dma/sf_hbm_dma_adapter.sv` | same `clk_i` as the controller in `tb_datafabric.sv` and `tb_dma_spm.sv`; the adapters contain only synchronous FIFOs/ROBs | between the NoC and the adapter, or between the adapter's `h_*` granule interface and the controller host port (section 3.1) |
| **Controller** | `sf_hbm4_controller` and everything below it, `sf_hbm_perf` | one `clk_i`, async-assert active-low `rst_ni` | -- |
| **PHY** | `sf_hbm_phy_adapter` and its `sim_*` side (the behavioural DRAM model in every testbench) | **same clock as the controller, 1:1** ("this adapter is 1:1 with the controller clock") | a ratio converter / PHY-side clocking is a *PHY-contract* item (section 3.2) |
| **Config** | `sf_hbm_csr` register bus `rb_*` | same `clk_i`; `cfg_o` and the 1-cycle control pulses are fed unsynchronised to the controller | a bus-clock crossing needs a register-transaction FIFO or synchronisers; none exists (section 3.3) |

The numbers `clock_mhz` in `configs/timing/profiles.json` are informational (reporting only; 1000 in all three profiles). Simulation clocks in the testbenches are arbitrary (`always #5 clk = ~clk`, 10 ns period under `timescale 1ns/1ps`);
`tb_bench.sv` converts cycles to time with the profile convention "1 cycle = 1 ns". No timing closure, STA or frequency claim exists (`reports/synth/` holds only technology-independent statistics, generated).

## 2. Clock and reset ownership

* **HBMCore generates no clocks.** There is no PLL, divider, clock gate, clock mux or delay line in `rtl/`; every module takes `clk_i` (or `wclk_i`/`rclk_i` for the FIFO) as an input.
* `clk_stable_i` and `power_good_i` are **inputs** of `sf_hbm_init` (`WAIT_POWER`, `WAIT_CLOCK` states): the controller waits for external clock/power infrastructure to report readiness; it does not produce either. Loss of either in `READY` returns the sequencer to `RESET`.
* Frequency/voltage switching is not implemented (`POWER.md` section 6).
* Reset: every sequential module uses an asynchronous, active-low reset with asynchronous assertion. Reset **release** is not synchronised inside HBMCore ("synchronous release semantics are the integrator's responsibility", `sf_hbm_bank_fsm.sv`);
  the NoC v2 fabric has the same property (`KNOWN_LIMITATIONS.md` item 2 of that project).
  `sf_hbm_rst_sync` (2 flops, asynchronous assert / synchronous de-assert) is provided for the integrator and is **not instantiated** anywhere in `rtl/`, `integration/` or the testbenches.

## 3. Where the CDC building blocks belong

`rtl/sf_hbm_cdc_fifo.sv` contains two modules.

### 3.1 `sf_hbm_cdc_fifo` (dual-clock FIFO)

| item | behaviour (RTL) |
|---|---|
| structure | Gray-coded pointers, 2-flop synchronisers in each direction, registered `full_o` (write domain) and `empty_o` (read domain) |
| parameters | `WIDTH` (default 32), `DEPTH` (default 8): a power of two `>= 4`, otherwise an elaboration `$error` |
| flow control | `push_i` is **ignored** when `full_o`, `pop_i` is **ignored** when `empty_o` (no corruption; a simulation-only `$error` flags the misuse) |
| flag pessimism | `full_o` and `empty_o` are pessimistic: a freed slot / a new word becomes visible only after the pointer crosses the synchroniser; they never report space or data that is not there |
| read interface | first-word-fall-through: `rdata_o = mem[rbin_q]` is valid whenever `!empty_o` and stable until `pop_i` |
| reset | two independent active-low asynchronous resets `wrst_n_i`, `rrst_n_i` |
| latency | not constant: it depends on the relative phase of the clocks (synchroniser depth plus pessimistic flags) |

Intended insertion points (none instantiated; sizes derived from the types in `sf_hbm_pkg.sv`):

| crossing | payload | notes |
|---|---|---|
| NoC/adapter clock -> controller clock, request direction | the host request: `req_addr` 40 + `write` 1 + `fence` 1 + `id` 8 + `src` 4 + `qos` 2 + `order` 2 + `wdata` 256 + `wmask` 32 = **346 bits** | the FWFT read side fits the controller port: present `!empty` as `req_valid_i`, pop on `req_valid_i && req_ready_o`; `req_ready_o` may depend on the payload, which is stable while the word is at the head |
| controller clock -> NoC/adapter clock, response direction | `hbm_rsp_t`: `src` 4 + `id` 8 + `write` 1 + `err` 3 + `corrected` 1 + `data` 256 = **273 bits** | push on `rsp_valid_o && !full`, i.e. `rsp_ready_i = !full_o` |
| CSR clock -> controller | register transactions | no wrapper exists; `cfg_o` is quasi-static, the pulses `ecc_clear_o`, `inj_arm_o`, `perf_clear_o`, `perf_snap_o` are 1-cycle pulses in the CSR clock and need pulse synchronisers if the clocks differ |

The datafabric adapter's own request FIFO and ROB are synchronous (`REQ_DEPTH`, `ROB_N`) and are **not** CDC structures.

### 3.2 Controller <-> PHY: a ratio converter is a PHY-contract item

* The abstract PHY boundary moves a whole 256-bit granule per controller cycle at a 1:1 clock (`PHY_CONTRACT.md`); there is no data-width or clock-ratio conversion (`IF-05`, `UNIMPLEMENTED`).
* `sf_hbm_cdc_fifo` **must not** simply be inserted in the command / write-data / read-data path: the contract is cycle-exact (write data exactly `WL` after the command, read data exactly `RL` after it plus fixed adapter latencies, checked by `sf_hbm_read_return`),
  while the FIFO latency is variable. A real PHY needs its own deterministic clocking/ratio scheme, and the controller's `WL`/`RL`/`RD_EXTRA_LAT` bookkeeping would have to be re-derived in PHY clock cycles.
* The clock ratio, the number of beats per granule and the PHY's data-bus occupancy are *properties of the licensed PHY* that this repository does not have.

### 3.3 Reset-domain-crossing rule

(Header of `sf_hbm_cdc_fifo.sv`; rule of HBMCore.)

1. Every clock domain gets its own `sf_hbm_rst_sync` instance fed by the **same** asynchronous source reset, so all domains **enter** reset together and **leave** it synchronously to their own clock.
2. For `sf_hbm_cdc_fifo`, assert **both** `wrst_n_i` and `rrst_n_i` together and de-assert each synchronously to its own clock. Resetting only one side leaves the pointer pair inconsistent (the FIFO keeps no cross-domain reset handshake).
3. With the present single-clock design one synchroniser at the top of the integration is sufficient; the FIFO rule applies as soon as a second clock appears.

## 4. What was actually tested

`verification/tests/tb_cdc_fifo.sv` (regression: `scripts/regress.py` group `cdc`, four runs with `+WPER/+RPER` = 7/11, 13/5, 10/10, 3/17 ns):

| aspect | covered |
|---|---|
| structure | `sf_hbm_cdc_fifo` with `W = 40`, `D = 8` (the testbench defaults); other `WIDTH`/`DEPTH` values are not built by any script |
| clocks | unrelated periods (default 7 ns / 11 ns), independent `forever` clock generators; equal 10/10 ns periods with the clocks started together |
| reset during operation | `mid_run_reset` task: write- and read-side resets in the middle of traffic (the v1 text said none existed - stale, review C9) |
| stimulus | producer pushes only when `!full_o` and consumer pops only when `!empty_o` (gating with the current flag, as the contract requires); three phases of 3000, 3000 and 6000 write-clock cycles: write-heavy (95 % push / 20 % pop), read-heavy (20 % / 95 %), balanced (60 % / 60 %); then a drain |
| scoreboard | a reference queue; every popped word must equal the oldest pushed word; no word may remain after the drain; `pushed == popped`; PASS requires `pushed > 1000` |
| not covered | metastability (a zero-delay RTL simulation cannot show it), explicit assertions that `full_o`/`empty_o` are never optimistic (only the data scoreboard would expose it), other depths/widths, back-to-back full/empty boundary corner cases beyond what the random phases reach |
| formal | `verification/formal/fv_cdc_fifo.sv` (WIDTH 2, DEPTH 4): no overflow / underflow, order and data integrity, Gray-pointer properties; unbounded proof + mutants (`reports/formal.json`). *(v2: this row was stale in v1 - review C9)* |
| tools | no CDC lint/static analysis, no constraints (SDC) for the synchronisers |

## 5. Integrator checklist (derived from the above)

1. Provide `clk_i` and a synchronised reset; HBMCore does neither.
2. Keep the NoC adapter, the controller, the CSR block, the perf block and the PHY adapter on the same clock, or add a crossing explicitly (FIFO for the 346-bit request and 273-bit response buses; pulse/handshake synchronisers for CSR pulses).
3. Do not place an asynchronous FIFO inside the exact-latency PHY path.
4. Keep `sf_hbm_csr` parameters (`NUM_STACKS`, `NUM_CH`, `CL_CH`, `QDEPTH`) equal to the controller instance.
5. Any change of clock ratio or PHY speed grade is a PHY-contract change (`PHY_CONTRACT.md` section 7).
