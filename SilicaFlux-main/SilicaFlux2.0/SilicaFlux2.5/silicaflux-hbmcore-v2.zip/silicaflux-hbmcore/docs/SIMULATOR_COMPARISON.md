# Independent DRAM simulator comparison (brief §34) — investigation result

**Result: no independently validated HBM4 model was available. Nothing in this repository uses an external simulator as an
authority. This remains an outstanding verification limitation (standards matrix row VER-01).**

## Candidates examined (2026-11-25)

**Ramulator 2.1** (`github.com/CMU-SAFARI/ramulator2`; shallow clone at commit `7bead6c`, 2026-11-04; source read only, nothing built or run).

What it contains:

* `src/ramulator/dram/impl/HBM4.cpp` is auto-generated from `python/ramulator/dram/hbm4.py`.
* Organisation: Channel → PseudoChannel → SID → BankGroup → Bank → Row → Column.
* Commands: ACT, PREpb, PREab, RD, WR, RDA, WRA, REFab, REFpb, **RFMab, RFMpb**.
* Many comments cite JESD270-4A tables.
* Several timing entries of the `HBM4_8000Mbps` / `HBM4_16000Mbps` presets sit inside blocks marked **"=== Ramulator Guesstimate ==="**.
* An extra preset is derived from an ISCA 2025 paper's projection.
* The org presets use **2 bank groups × 8 banks per pseudo-channel**. HBMCore's *assumed* default is 4 × 4.

What follows:

* A credible public reference.
* **Not** an HBM4 authority: part of the timing is explicitly estimated, and nothing here can check its citations against the standard.
* Its numbers were **not** imported into `configs/timing/profiles.json`.
* Its RFM command set is recorded as `PUBLIC_REFERENCE` (standards row REF-06).

**Ramulator 2.0** (2023 paper). Supports DDR3/4/5, LPDDR5, GDDR6, HBM(2) and HBM3. No HBM4.

**DRAMsim3** (`umd-memsys/DRAMsim3`). Its README lists HBM generically (with HMC, GDDR, DDR). It is not an HBM4 model, so it cannot validate HBM4 behaviour. Relabelling an HBM2/HBM3 configuration as HBM4 is exactly what the brief forbids.

## What a meaningful cross-check would be (not done in v2)

**Implementation cross-check (useful even without the standard).**

* Configure Ramulator 2.1's HBM4 model with HBMCore's *hypothetical* `sim_ref` timing (it overrides timing presets from YAML).
* Replay the same address traces (`traces/*.trace`, benchmark generators).
* Compare per-pattern sustained bandwidth and row-hit rates.

Agreement would only say that the two schedulers and timing engines enforce the same constraint set similarly. Disagreement would point at a rule one of them misses. Expected obstacles:

* Ramulator's SID level and 2×8 bank geometry differ from ours;
* its controller (`HBM34`) has its own scheduling policy;
* its refresh policy differs.

**Standards cross-check.** Requires JESD270-4 (and a vendor datasheet for a speed grade) to verify either model's timing table. Not possible here.

Sources: Ramulator 2.0 paper (arXiv 2308.11030), the Ramulator 2.1 repository README and sources at the commit above, and the DRAMsim3 repository README.
