# Module reference

One section per module of `rtl/` and of `integration/`. Every section has the same six sub-headings. Statements are traced to the cited file. "Verification" lists only tests that exist (`verification/tests/*.sv`, `verification/formal/*.sv`,
`python/tests/*.py`, `scripts/`); it does not state results (`scripts/regress.py` produces them, `reports/regression.*`, generated). "Synthesis status" deliberately holds no numbers.

**Status of everything below:** HBM-*style*, simulation-grade, every timing profile `HYPOTHETICAL_SIM`; abstract command set (not a JEDEC table); PHY backend B is a stub; training is an external PHY service. Not JEDEC/HBM4/DFI compliant; not silicon-ready (`docs/STANDARDS_MATRIX.md`).

Common conventions: single clock `clk_i`, active-low `rst_ni` with asynchronous assertion; reset release is the integrator's job (`CDC_AND_CLOCKS.md`). Names of the mutation checks come from `scripts/mutation_check.sh`; formal harnesses are listed only by file name (`docs/FORMAL.md` is maintained separately).

| section | file |
|---|---|
| [sf_hbm_pkg](#sf_hbm_pkg) | `rtl/sf_hbm_pkg.sv` |
| [sf_hbm_profile_pkg](#sf_hbm_profile_pkg) | `rtl/sf_hbm_profile_pkg.sv` (generated) |
| [sf_hbm_geom.svh](#sf_hbm_geomsvh) | `rtl/sf_hbm_geom.svh` |
| [sf_hbm_top](#sf_hbm_top) | `rtl/sf_hbm_top.sv` |
| [sf_hbm4_controller](#sf_hbm4_controller) | `rtl/sf_hbm4_controller.sv` |
| [sf_hbm_stack_cluster](#sf_hbm_stack_cluster) | `rtl/sf_hbm_stack_cluster.sv` |
| [sf_hbm_channel](#sf_hbm_channel) | `rtl/sf_hbm_channel.sv` |
| [sf_hbm_pseudochannel](#sf_hbm_pseudochannel) | `rtl/sf_hbm_pseudochannel.sv` |
| [sf_hbm_req_queue](#sf_hbm_req_queue) | `rtl/sf_hbm_req_queue.sv` |
| [sf_hbm_scheduler](#sf_hbm_scheduler) | `rtl/sf_hbm_scheduler.sv` |
| [sf_hbm_bank_fsm](#sf_hbm_bank_fsm) | `rtl/sf_hbm_bank_fsm.sv` |
| [sf_hbm_timing](#sf_hbm_timing) | `rtl/sf_hbm_timing.sv` |
| [sf_hbm_refresh](#sf_hbm_refresh) | `rtl/sf_hbm_refresh.sv` |
| [sf_hbm_rfm](#sf_hbm_rfm) (v2) | `rtl/sf_hbm_rfm.sv` |
| [sf_hbm_power_state](#sf_hbm_power_state) | `rtl/sf_hbm_power_state.sv` |
| [sf_hbm_write_data](#sf_hbm_write_data) | `rtl/sf_hbm_write_data.sv` |
| [sf_hbm_read_return](#sf_hbm_read_return) | `rtl/sf_hbm_read_return.sv` |
| [sf_hbm_command_encoder](#sf_hbm_command_encoder) | `rtl/sf_hbm_command_encoder.sv` |
| [sf_hbm_phy_adapter](#sf_hbm_phy_adapter) | `rtl/sf_hbm_phy_adapter.sv` |
| [sf_hbm_ecc_ras](#sf_hbm_ecc_ras) | `rtl/sf_hbm_ecc_ras.sv` |
| [sf_hbm_addr_map](#sf_hbm_addr_map) | `rtl/sf_hbm_addr_map.sv` |
| [sf_hbm_init](#sf_hbm_init) | `rtl/sf_hbm_init.sv` |
| [sf_hbm_rsp_arb](#sf_hbm_rsp_arb) | `rtl/sf_hbm_rsp_arb.sv` |
| [sf_hbm_perf](#sf_hbm_perf) | `rtl/sf_hbm_perf.sv` |
| [sf_hbm_csr](#sf_hbm_csr) | `rtl/sf_hbm_csr.sv` |
| [sf_hbm_cdc_fifo / sf_hbm_rst_sync](#sf_hbm_cdc_fifo--sf_hbm_rst_sync) | `rtl/sf_hbm_cdc_fifo.sv` |
| [sf_hbm_datafabric](#sf_hbm_datafabric) | `integration/datafabric/sf_hbm_datafabric.sv` |
| [sf_hbm_dma_adapter](#sf_hbm_dma_adapter) | `integration/dma/sf_hbm_dma_adapter.sv` |

---

## sf_hbm_pkg

### Interface contract
- Package, no ports. Exports typedefs `hbm_data_t` (256 b), `hbm_mask_t` (32 b), `hbm_txn_t`, `hbm_ctx_t`, `hbm_rsp_t`, `hbm_cmd_t`, `hbm_timing_t`, `hbm_sched_cfg_t`, `hbm_ref_cfg_t`, `hbm_cfg_t`, `hbm_loc_t`, `hbm_pc_evt_t`, `hbm_pc_stat_t`.
- Enums `hbm_err_e` (codes 0..7 numerically identical to `silicaflux_pkg::sf_mem_exc_e`), `hbm_order_e`, `hbm_cmd_e` (abstract, **not** a JEDEC table; `HCMD_REF_*` availability UNVERIFIED), `hbm_sched_policy_e`, `hbm_page_policy_e`, `hbm_ref_mode_e`, `hbm_map_e`.
- Pure functions: `hbm_ld` (rule "N cycles later" loads N-1), `hbm_dec16`, `hbm_max16`, `hbm_conflict` (ordering rule used by the queue), `hbm_bits`, `hbm_cap_bits`, `hbm_map_addr`, `hbm_unmap_loc` (the single definition of the address map).
- `HBM_TXN_VERSION = 1`: bump on any width/meaning change of a type.

### Parameters
- Localparams from `sf_hbm_geom.svh` macros: `HBM_DQ_PER_PC = 32` (PUBLIC_REFERENCE), `HBM_BEATS = 8`, `HBM_GRAN_BYTES = 32`, bank-group/bank/row/column widths (2/2/15/6), `HBM_ID_W = 8`, `HBM_SRC_W = 4`, `HBM_QOS_W = 2`, `HBM_ADDR_W = 40`, `HBM_ECC_W = 10`, `HBM_CYC_W = 16` (all ENGINEERING_ASSUMPTION unless stated).

### Reset semantics
- None: types, enums and pure functions only.

### Verification
- Used by every testbench. The address-map functions are cross-checked against the independent Python implementation `python/hbm4/address_map.py` by `python/tests/test_address_map.py` (hand-computed examples, exhaustive bijection on a small geometry) and by `tb_ctrl_multi.sv` tests `maps`, `basic`, `isolation` (`check_mapping`).
- `hbm_conflict` is exercised through `tb_pc_single.sv` test `hazards` and the mutant `raw_dependency_off`.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- `hbm_cmd_t` carries a `row` on column commands (abstract-model property) and an 8-bit placeholder `mrs`.
- `HBM_CYC_W = 16` wraps: due-time checks assume less than 2^15 cycles between events.
- `hbm_pc_stat_t.occ` is 6 bits; `sf_hbm_channel` connects the pseudo-channel's `$clog2(DEPTH)+1`-bit occupancy to it at full width (a 5-bit truncation that affected `DEPTH = 32` was fixed; `PERF_COUNTERS.md` caveat 6).

## sf_hbm_profile_pkg

### Interface contract
- Generated from `configs/timing/profiles.json` by `scripts/gen_profiles.py` ("GENERATED FILE - DO NOT EDIT"). Functions `hbm_profile(sel)` -> `hbm_timing_t`, `hbm_profile_status(sel)` (0 = HYPOTHETICAL_SIM, 1 = VERIFIED_STANDARD, 2 = VERIFIED_PHY_SPEC), `hbm_profile_pb_ok(sel)` (per-bank refresh feasibility: `trefi/16 >= max(tras, WR2PRE) + trp + 8`, rule in the generator).
- Profiles 0 `sim_fast`, 1 `sim_ref`, 2 `sim_strict`; any other `sel` falls back to profile 0. All three are `HYPOTHETICAL_SIM`; no value is a standard or datasheet value.

### Parameters
- `HBM_NUM_PROFILES = 3`. Timing fields (`trcdrd ... max_pullin`) are in controller clock cycles.

### Reset semantics
- None (constant functions).

### Verification
- `python/tests/test_timing.py` (`test_profiles_load_and_status`, `test_derived_values`, `test_rtw_clamps_at_one`, `test_profile_loader_rejects_missing_field`) check the JSON loader; `tb_timing_rules.sv` runs all rules against profiles 0..2 (`+PROFILE`).
- No test compares the generated SV package with the JSON field by field other than through the above.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- The clock frequency (`clock_mhz`) is not exported to RTL; `sf_hbm_csr` takes it as an integrator input.
- Hypothetical profiles only; `profile_sel` is a 4-bit selector with 3 valid values.

## sf_hbm_geom.svh

### Interface contract
- Include file defining macros `HBM_BG_BITS` (2), `HBM_BA_BITS` (2), `HBM_ROW_BITS` (15), `HBM_COL_BITS` (6), `HBM_ID_BITS` (8), `HBM_SRC_BITS` (4), `HBM_ADDR_BITS` (40); each overridable with `-D<NAME>=<value>` before inclusion.

### Parameters
- The macros above. Every value is an ENGINEERING_ASSUMPTION ("No value in this file is claimed to be a JESD270-4 requirement").

### Reset semantics
- None.

### Verification
- Default geometry used everywhere; `python/tests/test_address_map.py` also builds other geometries (`test_random_roundtrip_other_geometries`, `test_exhaustive_small_geometry_bijection`) against the Python model only. No RTL build with a non-default geometry is run by `scripts/regress.py`.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Changing the macros changes capacity and the width of `hbm_loc_t`-dependent fields; `sf_hbm_addr_map` rejects a capacity wider than `HBM_ADDR_W` at elaboration. Bank count `NB = 2^(BG+BA)` feeds per-bank arrays and `hbm_pc_stat_t`.

## sf_hbm_top

### Interface contract
- Integration wrapper = `sf_hbm4_controller` + `sf_hbm_perf` + `sf_hbm_csr`. Ports: register bus `rb_*` (same shape as `sf_crt_regs`), the controller's host request/response port, bring-up handshakes (`power_good_i`, `clk_stable_i`, `phy_init_done_i`, `train_done_i` -> `phy_init_start_o`, `train_start_o`, `ready_o`), the unchanged simulation-PHY bundle, `outstanding_o`, and the exported `cfg_o`, `addr_hi_o`, `max_burst_m1_o` (for `sf_hbm_datafabric` / `sf_hbm_dma_adapter`).
- Glue only: OR-reduction of the per-pseudo-channel status (`unimpl`, `ecc_alert`, violation, read-return protocol errors, refresh deadline miss, uncorrectable error) into the CSR `STATUS` / `ERRSTAT` inputs; `ECCLOG` shows the **lowest-numbered pseudo-channel that holds a log entry** (stateless, not the chronologically first error); `PROFINFO` MHz from `hbm_profile_mhz()` (generated from `configs/timing/profiles.json`).

### Parameters
- All controller parameters pass through; `PERF_CNT_W` (default 48; 6 in the saturation test), `PERF_PER_PC` (default 1; per-pseudo-channel counters cost `N*44*CNT_W` flops).

### Reset semantics
- Async assert, inherited from the three blocks: `enable = 0`, safe CSR defaults, counters 0.

### Verification
- `verification/tests/tb_top_csr.sv` (built for 2 channels / 48-bit counters and 4 channels / 6-bit saturating counters): reset defaults of every register, read-back and propagation of every RW register, access errors, init time-out and bring-up through `CONTROL`, profile and per-bank-refresh-infeasible flags, traffic with exact aggregate and per-pseudo-channel counters through `PERFSEL/PERFLO/PERFHI`, snapshot / freeze / clear, saturation + overflow flag, ECC injection through `ECCINJ` (corrected and uncorrectable), `ECCLOG`, `ERRSTAT` W1C, `ECCCLR`, zero DRAM-model violations.

### Synthesis status
- Not synthesized as a unit (the glue is a few OR-trees; `csr` and `perf_n2*` have their own rows in `reports/synth/SYNTH.md`).

### Known limitations
- Single host port (<= 1 granule per cycle) exactly as the controller; the CSR is not clock-domain-isolated (same clock; use `sf_hbm_cdc_fifo` / `sf_hbm_rst_sync` for a separate CSR clock, `CDC_AND_CLOCKS.md`); `ECCLOG` selection is by index, not by time.

---

## sf_hbm4_controller

### Interface contract
- Host port: `req_valid_i/req_ready_o` with `req_addr_i, req_write_i, req_fence_i, req_id_i, req_src_i, req_qos_i, req_order_i, req_wdata_i, req_wmask_i`; accepted iff `valid && ready`; `req_ready_o` may depend on the payload. Response: `rsp_valid_o/rsp_ready_i/rsp_o` (`hbm_rsp_t`), delivered to the source named in `src`.
- Bring-up: `power_good_i, clk_stable_i, phy_init_done_i, train_done_i` in; `phy_init_start_o, train_start_o, ready_o, init_error_o, init_cause_o, init_state_o` out. Config: `cfg_i` (`hbm_cfg_t`). RAS: `ecc_clear_i, inj_arm_i, inj_pc_i, inj_mode_i, inj_bit_i`.
- Per-pseudo-channel PHY-side bundles `sim_*`, `phy_ready_ext_i`, `phy_event_i`, `ondie_event_i`; observability `stat_o[]`, `ev_accept*_o`, `ev_err_req_o`, `ev_stall_id_o/q_o/fence_o`, `outstanding_o`, `ref_cfg_infeasible_o`.
- Behaviour: nothing is accepted before `ready_o`; bad address -> error entry steered to PC 0; partial write + ECC -> `HERR_POLICY`; same-`{src,id}` tracker; fence = accepted only with nothing outstanding.

### Parameters
- `NUM_STACKS` 1, `NUM_CHANNELS` 32, `CH_PER_CLUSTER` 8 (`TOT_CH % cluster size == 0` enforced), `DEPTH` 16, `CPL_DEPTH` 8, `TRK_SRC_W` 2, `TRK_ID_W` 4, `PHY_BACKEND` 0, `PHY_CMD_LAT` 0, `PHY_RD_LAT` 0, `WR_ACK_AT_DATA` 1, `NUM_MRS` 4.
- Not exposed: `PEND_DEPTH` (pseudo-channel default 16), `AGE_W`.

### Reset semantics
- Async assert: tracker counters, `outst_q` and the fence response register cleared; `sf_hbm_init` in `RESET`; everything below reset through the hierarchy.

### Verification
- `tb_ctrl_multi.sv`: tests `init`, `basic`, `random`, `maps`, `errors`, `ecc_policy`, `fence`, `same_id`, `isolation`, `backpressure`, `reset`, `perf` (builds for 1, 2, 4, 8 channels; 32 under `bigconfig`). `tb_bench.sv` with `PORTS=0`; `tb_datafabric.sv`/`tb_dma_spm.sv` with `BACKEND=1`.
- Python cross-checks: `python/hbm4/txn_check.py` on the RTL transaction log (`scripts/regress.py`: `python_scoreboard_on_rtl_transaction_log`).

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: the ID-order tracker uses one `always_ff` per entry (Verilator 5.020 `BLKLOOPINIT`); explicit widening in the cluster steering (`-Wall` clean on 5.020).**
- One request per cycle (single port); no sliced ingress in RTL (`ARCHITECTURE.md` section 4). `cfg_i` is not guarded against changes during traffic. `cfg.max_burst_m1` is not used by the controller itself (it is exported by `sf_hbm_top` for the DataFabric node). `sf_hbm_csr`/`sf_hbm_perf` are not instantiated here - `sf_hbm_top` wraps them around the controller.
- Tracker aliasing (`TRK_ID_W` bits) can add stalls; tracker counters saturate at 255 (stall, `$error` if exceeded).

## sf_hbm_stack_cluster

### Interface contract
- Group of `NCH` channels. `req_valid_i`/`req_pc_i` (local `{ch,pc}`) steer one request to one channel (`ready` is that channel's); one response arbiter (`sf_hbm_rsp_arb #(NCH)`); `init_mrs_ack_o` = AND over channels; per-pseudo-channel `sim_*` and `stat_o` slices; the configuration inputs are passed down unchanged.

### Parameters
- `NCH` 8, `PCS` 2, `DEPTH` 16, `CPL_DEPTH` 8, `PHY_BACKEND`, `PHY_CMD_LAT`, `PHY_RD_LAT`, `WR_ACK_AT_DATA`.

### Reset semantics
- Async reset passed down; no own state.

### Verification
- Through `tb_ctrl_multi.sv` (`CHCL` = channels per cluster, e.g. 1/2/4 builds) and `tb_bench.sv` (`CHCL`).

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Physical-partitioning convenience only (`docs/PHYSICAL_DESIGN.md` referenced by the header is not present). The request payload fans out to every channel.

## sf_hbm_channel

### Interface contract
- `PCS` (2) pseudo-channels + `sf_hbm_rsp_arb #(PCS)`. `req_pc_i` selects the pseudo-channel; `req_ready_o` = that pseudo-channel's ready, so back-pressure on one does not block the other once steered. Packs `hbm_pc_stat_t` per pseudo-channel.
- The two pseudo-channels share nothing but the response port.

### Parameters
- `PCS` 2, `DEPTH` 16, `CPL_DEPTH` 8, `PHY_BACKEND` 0, `PHY_CMD_LAT` 0, `PHY_RD_LAT` 0, `WR_ACK_AT_DATA` 1.

### Reset semantics
- Async reset passed down; no own state (arbiter pointer reset to 0).

### Verification
- As for the cluster; `tb_ctrl_multi.sv` test `isolation` ("nothing may leak between channels").

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Leaves `ecc_ce_o`, `ecc_ue_o`, `phy_err_o`, `ondie_err_o`, `res_*_o`, `dbg_cmd_*` of the pseudo-channel unconnected. The occupancy wire is 5 bits (`logic [4:0] occ_n`): an occupancy of 32 (`DEPTH = 32`) reads as 0.

## sf_hbm_pseudochannel

### Interface contract
- Request: `req_valid_i/req_ready_o`, `req_txn_i` (`hbm_txn_t`, one 32 B granule after mapping), `req_wdata_i`, `req_wmask_i`; accept = `valid && q_push_ready && ctrl_enable_i`. Response: `rsp_valid_o/rsp_ready_i/rsp_o` (stable while `valid && !ready`).
- Quasi-static config in: `tp_i`, `sched_cfg_i`, `ref_cfg_i`, `ecc_en_i`, `ctrl_enable_i`, `pwr_req_i`, `pd_idle_i`, `sr_idle_i`. Init MRS broadcast: `init_mrs_valid_i/code_i/ack_o` (ack held until the code changes). RAS: `ecc_clear_i`, `inj_*`. Simulation-PHY side: `sim_*`, `phy_ready_ext_i`, `phy_event_i`, `ondie_event_i`.
- Status out: `evt_o`, `lat_o`, `rsp_bytes_o`, `occ_o`, `pwr_state_o`, `res_*_o`, `ref_debt_o`, `quiet_o`, `backend_unimplemented_o`, RAS counters/log/alert, `bank_state_o`, `dbg_cmd_*`.
- Resource rules: queue slot == write-data slot; slot freed at column issue (held for write data); completion entry reserved at issue (`ARCHITECTURE.md` section 3). Maintenance priority: init MRS > power > refresh.

### Parameters
- `DEPTH` 16, `CPL_DEPTH` 8, `AGE_W` 16, `PEND_DEPTH` 16, `PHY_BACKEND` 0, `PHY_CMD_LAT` 0, `PHY_RD_LAT` 0, `WR_ACK_AT_DATA` 1 (`RD_EXTRA = PHY_CMD_LAT + PHY_RD_LAT`).

### Reset semantics
- Async assert, everything idle; `cyc_q` = 0. `ctrl_enable_i` must be high for traffic; while low only the init MRS port is serviced. `bytes_q` (per-slot byte counts) is not reset (written at accept).

### Verification
- `tb_pc_single.sv` (all tests: `single_read`, `single_write`, `write_readback`, `sequential`, `partial`, `hazards`, `random`, `random_hot`, `policy`, `backpressure`, `saturation`, `refresh`, `ecc`, `refmodes`, `power`, `reset`) against `hbm4_dram_model`, run for profiles 0..2 and policies 0..2 (`scripts/regress.py`); `tb_bench.sv` (`PORTS=1`).
- Simulation-time assertions inside the module (violation, unexpected/late read data, refresh deadline, error+command together). Mutation checks: `scripts/mutation_check.sh` (all mutants use `tb_pc_single`).

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: instantiates `sf_hbm_rfm`; the init port issues PREA before the MRS when rows are open (A4); PHY-ready contract assertion (C1 rule); events `rfm`, `rfm_block`.**
- One command per cycle; no auto-precharge. `PHY_CMD_LAT`/`PHY_RD_LAT` non-zero never simulated. Requests are accepted into the queue while the power state holds demand. `s_act`, `s_pre`, `s_pend` of the scheduler are unused. No ingress error checking (done at the controller top).

## sf_hbm_req_queue

### Interface contract
- Push: `push_valid_i/push_ready_o`, `push_txn_i`, `push_idx_o` (slot the push will take, stable while ready). Remove: `rem_valid_i/rem_idx_i` (column command or error completion). `hold_i[DEPTH]` masks slots from allocation (write data owed).
- Outputs: `ent_valid_o`, `ent_txn_o`, `ent_blocked_o`, `ent_older_o[i][j]`, `ent_age_o`, `occ_o/occ_rd_o/occ_wr_o`, `full_o`, `empty_o`. An accepted entry is visible the next cycle (no bypass). A slot is never overwritten while valid.
- Dependency rule: `hbm_conflict` (hazard on the same granule with a write, same `{src,id}`, `ORD_STRICT`, `ORD_SRC` same source).

### Parameters
- `DEPTH` 16, `AGE_W` 16 (age saturates).

### Reset semantics
- Async assert: empty; matrices and ages cleared.

### Verification
- `verification/formal/fv_req_queue.sv`; `tb_pc_single.sv` tests `hazards`, `saturation`, `random`; mutants `raw_dependency_off`, `slot_hold_off`.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Two `DEPTH x DEPTH` bit matrices and one comparator set per entry per push: area grows quadratically in total matrix bits. Ordering is released at the older entry's column-command issue, not at its response.

## sf_hbm_scheduler

### Interface contract
- Inputs: queue view, bank view (`bk_*`), cross-bank view (`tm_ok_*`), credits (`cpl_credit_i`, `wr_credit_i`, `phy_ready_i`), maintenance (`mnt_*`, `hold_*`), `cfg_i`. Outputs: `issue_valid_o/issue_cmd_o/issue_col_o/issue_err_o/issue_idx_o`, `mnt_grant_o`, accounting pulses `ev_*`.
- At most one command per cycle; priority never bypasses a timing rule; policies FCFS / FRFCFS / BGAWARE; tiers urgent > deadline > qos > batch > colhit > bgdiff; page policies open / close / timeout (details: `SCHEDULER.md`).

### Parameters
- `DEPTH` 16, `AGE_W` 16.

### Reset semantics
- Async assert: row-accounting flags, batch direction (reads), batch count, `last_bg_q`, per-bank idle timers cleared.

### Verification
- `tb_pc_single.sv` tests `policy`, `random`, `random_hot`, `backpressure`, `refresh`, plus `+PAGE`, `+BATCH`, `+PRIO` runs; simulation-time assertions for illegal ACT/RD/WR and a missing oldest entry in FCFS; mutant `pre_protect_off`. Tiers `urgent`, `deadline`, `bgdiff` have no directed test.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: drain keyed on older boosted PRE-needing entries and age-only order inside the boosted tiers (A1); REF/RFM legality requires tRC (`bk_can_act`) (A2); new `act_block_i` from `sf_hbm_rfm`; HCMD_RFM is per bank.**
- Combinational one-stage selection; `timing_stall` is a catch-all; PRE protection (never close a row that still has a pending hit) is **overridden for a starving entry** (`age >= starve_limit`) or a QoS-deadline-urgent entry (`boost`), with a per-bank *drain* that blocks new non-boosted hits while such an entry waits to precharge; tested by `tb_pc_single` `starvation` and the mutants `starve_boost_off` / `starve_never` / `starve_drain_off`; `batch_len = 0` toggles every cycle; the Python scheduler model is not cycle-matched to it (`SCHEDULER.md` section 10).

## sf_hbm_bank_fsm

### Interface contract
- Strobes `act_i, rd_i, wr_i, pre_i (PRE or PREA), refab_i, refpb_i` + `cmd_row_i`; at most one command per cycle; a strobe is raised only for the addressed bank (all banks for PREA/REF_AB).
- Outputs: `row_open_o`, `open_row_o`, `can_act/rd/wr/pre_o` (bank-local legality only), `idle_o`, `state_o` (0 IDLE, 1 ACTIVE, 2 PRECHARGING, 3 REFRESHING), `violation_o` (1-cycle pulse when a strobe is applied against a bank-local rule).
- Rules: tRCDRD, tRCDWR, tRAS, tRC, tRP, tRTP, `WL+burst+tWR`, tRFC/tRFCpb. Counters load `N-1` on the issue edge; `== 0` means legal.

### Parameters
- None (the timing profile arrives on `tp_i`).

### Reset semantics
- Async assert: bank closed (`IDLE`), counters 0, `violation_o` 0.

### Verification
- `tb_timing_rules.sv` (16 instances as judge 1: legal schedules accepted, one-cycle-short schedules rejected), `verification/formal/fv_bank_fsm.sv`; mutants `tRCDRD_short`, `tRAS_short`, `tRP_short`; Python oracle `python/tests/test_timing.py` (independent).

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: new `rfm_i` (busy for `trfm`, REF-class precondition; covered by the formal harness).**
- Auto-precharge (RDA/WRA) is not modelled. A `PRE` to a closed bank is a no-op (does not restart tRP; `python/SPEC_AMBIGUITIES.md` records the ambiguity).

## sf_hbm_timing

### Interface contract
- Strobes `act_i, rd_i, wr_i` (+ `bg_i`), `refab_i`, `mrs_i`, `pdx_i`, `srx_i`. Outputs `ok_act_o/ok_rd_o/ok_wr_o[bank group]`, `ok_ref_o`, `ok_misc_o`, `busy_o`, `violation_o`.
- Rules: tRRD_S/L, tFAW (4 sliding counters), tCCD_S/L, WR->RD `WL+burst+tWTR_S/L`, RD->WR `RL+burst+2-WL` (min 1; the `+2` turnaround convention is an ENGINEERING_ASSUMPTION), tRFC, tMRD, tXP/tXS. Same count-down convention as the bank FSM.

### Parameters
- None (bank-group count from `sf_hbm_pkg`).

### Reset semantics
- Async assert: all counters 0.

### Verification
- `tb_timing_rules.sv` (judge 2), mutants `tFAW_ignored`, `tCCD_L_as_S`, `tWTR_L_ignored`; Python oracle (`python/tests/test_timing.py`: tRRD, tFAW, tCCD, tWTR, tRTW, tRFC, tMRD, tXP, tXS).

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Single command bus per pseudo-channel; `REF_PB` does not consume tRRD; no minimum PDE->PDX / SRE->SRX residency; demand `PRE` is not gated by `ok_misc_o` (no bank is open inside the tMRD/tXP/tXS windows, so it does not arise).

## sf_hbm_refresh

### Interface contract
- Inputs: `cfg_i` (`mode` AB/PB/OFF, `eager`, `pullin_en`), `enable_i`, `pause_i`, `block_i`, `clear_i`, `queue_idle_i`, bank idle/open vectors, `mnt_grant_i`. Outputs: maintenance command + `mnt_prio_o`, `hold_act_o/hold_col_o`, per-bank hold, `debt_o` (signed 8 b), `urgent_o`, `active_o`, event pulses, `deadline_miss_o`.
- Debt model: +1 per tREFI (per-bank mode: per `tREFI >> HBM_BANK_W`), -1 per completed refresh; urgent at `debt >= max_postpone`; pull-in down to `-max_pullin`; sequence HOLD -> PREA/PRE -> REF; saturation at +-100.

### Parameters
- None.

### Reset semantics
- Async assert: `R_IDLE`, debt 0, interval counter 0, pointer 0.

### Verification
- `tb_pc_single.sv` tests `refresh`, `refmodes` (per-bank where `hbm_profile_pb_ok`; lazy refresh must become forced under a saturating stream), `power`; DRAM model refresh-deadline checker; mutant `refresh_disabled`; `python/tests/test_scheduler.py` (`test_idle_refresh_hand_computed`, `test_refresh_postponed_under_load_but_deadline_met`) for the Python model only.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Mode availability, postpone/pull-in limits and per-bank refresh are UNVERIFIED for HBM4 (REF-01/02). v2: `max_postpone`/`max_pullin` are clamped to the debt range (<= 100, also enforced by `gen_profiles.py`); the CSR mode is a request applied at a safe point (`mode_q`); the mode is latched per sequence; RFM sequences (docs/ROWHAMMER.md). Refresh is not staggered across pseudo-channels. `block_i` is tested only at sequence start and in `HOLD`. RFM/DRFM is not issued; no temperature-compensated refresh.

## sf_hbm_rfm

### Interface contract
- Inputs: `cfg_i` (`hbm_ref_cfg_t`: `rfm_en`, `rfm_dir`, `raaimt`, `raammt`, `raa_ref_dec`), the issued command (`cmd_valid_i`, `cmd_i`). Outputs: level request `rfm_req_o` / `rfm_bank_o` / `rfm_row_o` to `sf_hbm_refresh`, `act_block_o[NB]` to the scheduler, registered `raa_max_o`.
- Per bank: rolling ACT count (+1 per ACT, -`raa_ref_dec` per covering refresh, -`raaimt` per RFM, saturating); request at `>= raaimt` (lowest bank first); demand ACT blocked at `>= raammt`; directed mode names the heavier of a 2-entry Misra-Gries heavy-hitter pair.

### Parameters
- None (geometry from `sf_hbm_pkg`).

### Reset semantics
- Async assert: all counters and trackers 0. `rfm_en = 0` also clears them (no stale blocking).

### Verification
- `tb_pc_single.sv` test `rowhammer` (in `+TEST=all`): double-sided hammer with RFM off / directed / undirected, MMT blocking only, benign traffic with RFM on; DRAM-model RFM rules and research metric; Python rule 20; simulation assertion "no ACT at RAA >= raammt"; bank-FSM formal harness covers `rfm_i`.

### Synthesis status
- see reports/synth_ng45/ (generated)

### Known limitations
- ENGINEERING_ASSUMPTION research hook, **not RowHammer protection** (docs/ROWHAMMER.md). HBM4 RFM/DRFM definition, thresholds and tRFM are unverified; no all-bank RFM; the 2-entry tracker can be evaded by many-sided patterns.

## sf_hbm_power_state

### Interface contract
- Inputs: `enable_i`, `req_i[1:0]`, `pd_idle_i`, `sr_idle_i`, `quiet_i`, `work_pending_i`, `all_idle_i`, `ref_urgent_i`, `mnt_grant_i`. Outputs: maintenance command (`PREA`/`PDE`/`SRE`/`PDX`/`SRX`) with `mnt_valid_o`, `hold_o`, `pause_ref_o`, `ref_clear_o`, `state_o`, residency counters.
- States ACTIVE/PREP/ENTER/PD/SR/EXIT/WAKE; entry, abort and wake rules in `POWER.md`.

### Parameters
- None.

### Reset semantics
- Async assert: `ACTIVE`, counters 0.

### Verification
- `tb_pc_single.sv` test `power` (request, automatic entry, self-refresh, randomised requests); no directed test for the urgent-refresh wake in isolation.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Abstract commands; dynamic frequency/voltage switching not implemented; no `PD -> SR` promotion; residency counters 32-bit non-saturating and not exported above the pseudo-channel; reserved `req_i = 3` never wakes on work.

## sf_hbm_write_data

### Interface contract
- Store at accept (`st_valid_i/st_idx_i/st_data_i/st_mask_i`, same index as the queue slot). On WR issue (`wr_issue_i/wr_idx_i/wr_cpl_idx_i`) a pending entry `{slot, completion index, due = cyc + WL}` is pushed; at `cyc == due` the data is registered onto the PHY write bus (`wdata_valid_o/wdata_o/wmask_o`), visible `WL` cycles after the command is visible at the PHY interface.
- `can_issue_o` low when the pending FIFO is full (scheduler must not issue a WR); `slot_busy_o` holds a slot from issue until its data has left; `wr_done_*` at data (`WR_ACK_AT_DATA = 1`) or one cycle after issue (posted); `pend_empty_o`.

### Parameters
- `DEPTH` 16, `PEND_DEPTH` 16, `CPL_IDX_W` 4, `WR_ACK_AT_DATA` 1.

### Reset semantics
- Async assert: pending FIFO empty, `busy_q` 0, outputs 0; the data/mask arrays are not reset.

### Verification
- `tb_pc_single.sv` (DRAM-model write-data checker "exactly WL"), mutants `wdata_one_late`, `slot_hold_off`; `tb_timing_rules.sv` drives write data as part of its schedules.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- `WL = 0` unsupported (`$error`). No DRAM->controller write acknowledge exists: "complete" means "delivered to the PHY". The PHY write path is assumed non-blocking after command acceptance. Partial writes depend on UNVERIFIED mask support.

## sf_hbm_read_return

### Interface contract
- Allocate at column/error issue (`push_valid_i/push_ctx_i/push_kind_i` 0 read, 1 write, 2 error; `push_idx_o`, `credit_o`); write completion (`wr_done_*`); PHY read return `rd_valid_i/rd_data_i/rd_err_i/rd_corr_i` (already ECC-processed); response `rsp_valid_o/rsp_ready_i/rsp_o/rsp_bytes_o/rsp_lat_o` in allocation order; `occ_o`.
- Checks: a read pushed at `t` must return at exactly `t + 1 + RL + RD_EXTRA_LAT`; pulses `rd_timing_err_o`, `rd_timeout_o` (after `RD_TIMEOUT` cycles, entry completes `HERR_FLUSHED`), `rd_unexpected_o`. `rsp_o` is stable while `valid && !ready`.

### Parameters
- `CPL_DEPTH` 8, `RD_EXTRA_LAT` 0, `RD_TIMEOUT` 64 (not overridden by the pseudo-channel).

### Reset semantics
- Async assert: empty, outstanding-read FIFO empty, pulses 0.

### Verification
- `verification/formal/fv_read_return.sv`; `tb_pc_single.sv` tests `random`, `backpressure`, `ecc`, `reset`; mutant `read_data_swap`. No test suppresses read data, so the timeout path is not exercised.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: orphan accounting after a read-return timeout. An off-time return while timed-out reads are pending is dropped (`rd_orphan_drop_o`); off-time or ambiguous completions are poisoned (`HERR_FLUSHED`, corrected = 0); orphans clear after a quiet window (review B4; `tb_read_return`, formal ghost v2).**
- Strict in-order, tag-less return contract; after a timeout a late return would be paired with the next outstanding read. `rsp_lat_o` is 16 bit.

## sf_hbm_command_encoder

### Interface contract
- `cmd_valid_i/cmd_i` -> registered `phy_cmd_valid_o/phy_cmd_o` (`hbm_cmd_t`), one cycle later; the data bundle is zero when not valid. Abstract typed bundle, not a JEDEC pin table.

### Parameters
- `ENCODING` 0 (abstract); any other value is an elaboration `$error` ("pending specification").

### Reset semantics
- Async assert: NOP, not valid.

### Verification
- Exercised by every pseudo-channel testbench; no dedicated test, and the `ENCODING != 0` error path is not exercised.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- No physical command encoding exists (IF-02 UNIMPLEMENTED); this block is the single place where one would be added.

## sf_hbm_phy_adapter

### Interface contract
- Controller side: `cmd_valid_i/cmd_i`, `wdata_valid_i/wdata_i/wmask_i/wecc_i`, `rdata_valid_o/rdata_o/recc_o/rerr_o`, `cmd_ready_o`, `backend_unimplemented_o`, `phy_ready_ext_i`. Simulation side: `sim_cmd_*`, `sim_w*`, `sim_r*`.
- BACKEND 0: `CMD_LAT` register stages on command and write data (relative timing preserved), `RD_LAT` on read data, `cmd_ready_o = phy_ready_ext_i`. BACKEND 1: stub, all outputs idle, `cmd_ready_o = 0`, `backend_unimplemented_o = 1`. Contract rules: `PHY_CONTRACT.md`.

### Parameters
- `BACKEND` 0, `CMD_LAT` 0, `RD_LAT` 0.

### Reset semantics
- Async assert: pipeline registers cleared (BACKEND 0); constants in BACKEND 1.

### Verification
- BACKEND 0 with zero latencies in every testbench; the model behind it is `hbm4_dram_model`. BACKEND 1 and non-zero `CMD_LAT`/`RD_LAT` are not built by any test.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- No DFI, no analogue behaviour, no training, 1:1 clock only, whole 256-bit granule per cycle (`PHY_CONTRACT.md` section 7).

## sf_hbm_ecc_ras

### Interface contract
- Write path: `wdata_i -> wdata_o` + `wecc_o` (combinational encode; zero check bits when `ecc_en_i = 0`). Read path: `rdata_i, recc_i -> rdata_o, rerr_o (HERR_ECC on uncorrectable), rcorr_o` (combinational decode). Fault injection `inj_arm_i/inj_mode_i/inj_bit_i` (one shot). Status inputs `phy_event_i`, `ondie_event_i` are counted only.
- Outputs: saturating 32-bit `ce/ue/phy/ondie` counters, first-error log (`log_valid_o`, `log_ue_o`, `log_syndrome_o`), sticky `alert_o`, `ev_ce_o`, `ev_ue_o`. Code: `docs/RAS_CODE.md`.

### Parameters
- None.

### Reset semantics
- Async assert: counters 0, log invalid, alert 0, injector disarmed.

### Verification
- `tb_pc_single.sv` test `ecc`; Python code model `python/tests/test_reference_memory.py`; `tb_ctrl_multi.sv` test `ecc_policy` for the ingress rule. `phy_event_i`/`ondie_event_i` are tied to 0 in every testbench.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: the SECDED encode/decode are restructured as constant tables and reduction trees (about 6.4 ns -> 1.7 ns on the NanGate45 proxy) and proven equivalent to v1 for all inputs (`verification/formal/eq_secded.py`). An injection arm in the consuming cycle is kept (B5). Separate `phy_rd_err_i`, so two same-cycle PHY errors count 2 (B6).**
- Sideband availability UNVERIFIED; on-die ECC, PHY CRC/parity, RMW unimplemented. Enabling ECC over data written without it gives spurious events; no scrubbing; the log keeps the first error only and holds no address.

## sf_hbm_addr_map

### Interface contract
- Combinational: `addr_i, mode_i, il_bits_i, hash_i` -> `loc_o` (`hbm_loc_t`), `pc_o` (flat pseudo-channel index `((stk*NUM_CHANNELS)+ch)*PCS+pc`), `err_range_o`, `err_misalign_o`, `err_o` (RANGE takes precedence over MISALIGN).
- Modes LINEAR / CH_IL / BANK_AWARE + optional bijective XOR hash (`docs/ADDRESS_MAP.md`).

### Parameters
- `NUM_STACKS` 1, `NUM_CHANNELS` 32 (powers of two), `PCS` 2 (1 or 2); elaboration errors for non-power-of-two counts, other `PCS`, or capacity bits above `HBM_ADDR_W`.

### Reset semantics
- None (combinational).

### Verification
- `tb_ctrl_multi.sv` (`maps`, `basic`, `isolation`, `errors`); independent implementation `python/hbm4/address_map.py` written from `docs/ADDRESS_MAP.md` alone, tested by `python/tests/test_address_map.py`.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: elaboration error for more than 8 stacks or 64 channels (`hbm_loc_t` widths; review C3).**
- Geometry is a simulation reference geometry (ENGINEERING_ASSUMPTION); `il_bits` is clamped to `HBM_COL_W`; no hash variant other than the one in `ADDRESS_MAP.md`; 1, 2, 4, 8 and 32 channels are the exercised counts.

## sf_hbm_init

### Interface contract
- `enable_i`, `timeout_i`, `power_good_i`, `clk_stable_i`, `phy_init_done_i`, `train_done_i` in; `phy_init_start_o`, `train_start_o`, `mrs_valid_o/mrs_code_o/mrs_ack_i`, `ready_o`, `error_o`, `cause_o` (1 power-good, 2 clock, 3 PHY init, 4 mode config, 5 training), `state_o` out.
- Sequence `RESET -> PWR -> CLK -> PHY -> MRS (NUM_MRS steps, operand = step index) -> TRAIN -> READY`; per-state timeout (`timeout_i`, 0 = none) to `ERR`; losing power-good or clock in `READY` returns to `RESET`; `enable_i = 0` returns to `RESET`.

### Parameters
- `NUM_MRS` 4.

### Reset semantics
- Async assert: `RESET` state, cause 0.

### Verification
- `tb_ctrl_multi.sv` test `init` (`init_sequence_gating`): no readiness or request acceptance before each handshake; MRS commands counted at the DRAM boundary. Timeout/`ERR` paths are not exercised.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- MRS operands are placeholders (INIT-02); training, calibration, ZQ, VREF are an external PHY service (INIT-03); no error recovery other than `enable_i` toggling.

## sf_hbm_rsp_arb

### Interface contract
- `N` valid/ready inputs -> one output; exactly one input granted at a time; once an input is selected and `out_valid_o` is high the selection and payload are held until `out_ready_i`; round-robin pointer advances to the input after the winner; `in_ready_o[i]` high only for the selected input in the handshake cycle; `sel_o` exposes the selection.

### Parameters
- `N` 2.

### Reset semantics
- Async assert: pointer 0, no lock.

### Verification
- `verification/formal/fv_rsp_arb.sv`; indirectly every controller testbench (one response per request); simulation-time checks for double grant and withdrawn locked input.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- The locked input must not withdraw `valid` (checked only in simulation). A zero-latency combinational path from input valid to `out_valid_o`.

## sf_hbm_perf

### Interface contract
- Inputs: `stat_i[N]` (`hbm_pc_stat_t`), `ev_stall_id_i/ev_stall_q_i/ev_stall_fence_i`, `clear_i`, `snap_i`, `freeze_i`, read select `sel_pc_i/sel_cnt_i/sel_agg_i`. Outputs: `rdata_o[63:0]` (combinational), `ovf_o`.
- 44 per-pseudo-channel and 33 aggregate saturating counters; snapshot shadow for aggregates; freeze holds all counters; clear zeroes all (`PERF_COUNTERS.md`).

### Parameters
- `N` 2, `CNT_W` 48 (2..64 allowed; < 32 only for saturation tests), `PER_PC_EN` 1.

### Reset semantics
- Async assert: all counters, shadows and the overflow flag 0.

### Verification
- `tb_ctrl_multi.sv` test `perf` (`perf_counters_exact`); lint via `scripts/regress.py`. Saturation, histogram, `lat_max`/`occ_max`, `PER_PC_EN = 0` are not exercised.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: aggregate counters 33 `rfm`, 34 `rfm_block_cycles`; per-PC 44 / 45.**
- Per-PC counters have no shadow bank; events during freeze or in the clear cycle are lost; `PER_PC_EN = 1` is flop-heavy (`N*44*CNT_W`).

## sf_hbm_csr

### Interface contract
- Bus `rb_sel_i, rb_we_i, rb_addr_i[11:0], rb_wdata_i, rb_rdata_o (combinational), rb_err_o`; one access per cycle, no wait states. Outputs `cfg_o` (`hbm_cfg_t`), pulses (`ecc_clear_o`, `inj_arm_o`, `perf_clear_o`, `perf_snap_o`), levels/selects (`inj_*`, `perf_freeze_o`, `perf_pc_o/cnt_o/agg_o`); inputs for status, log and sticky error events. Register map: `PERF_COUNTERS.md` section 6.

### Parameters
- `NUM_STACKS` 1, `NUM_CH` 32, `CL_CH` 8, `QDEPTH` 16 (reported in `GEOMETRY`; not tied to the controller instance).

### Reset semantics
- Async assert: `enable = 0`, FR-FCFS, batch_len 8, close_timeout 32, AB refresh eager, profile 1, `init_timeout` 100000, `max_burst_m1` 31, sticky errors 0, pulses 0.

### Verification
- **None in simulation** (lint only: `scripts/regress.py` `lint_sf_hbm_csr`).

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: REFCFG[31:4] carries the RFM configuration; GEOMETRY reports the clamped cluster size (C7).**
- `ERRSTAT` sticky set wins over a coincident W1C clear (no event is lost). `SCHED0` read-back layout equals the write layout (a mismatch of the page-policy field was found by review and fixed; `tb_top_csr` `rw_readback` covers every RW register). `MAXBURST`/`ADDRHI` are exported through `sf_hbm_top` (`max_burst_m1_o`, `addr_hi_o`). Instantiated only through `sf_hbm_top`; tested by `tb_top_csr`.

## sf_hbm_cdc_fifo / sf_hbm_rst_sync

### Interface contract
- `sf_hbm_cdc_fifo`: write domain `wclk_i, wrst_n_i, push_i, wdata_i, full_o`; read domain `rclk_i, rrst_n_i, pop_i, rdata_o, empty_o`. Gray-coded pointers, 2-flop synchronisers, registered flags; push ignored when full, pop ignored when empty; flags pessimistic; first-word-fall-through read data.
- `sf_hbm_rst_sync`: `clk_i, arst_n_i -> srst_n_o` (asynchronous assert, synchronous de-assert, 2 flops).

### Parameters
- `WIDTH` 32, `DEPTH` 8 (power of two >= 4, otherwise elaboration `$error`). `sf_hbm_rst_sync`: none.

### Reset semantics
- Independent active-low async resets per domain; reset-domain-crossing rule: assert both together, de-assert each synchronously (use `sf_hbm_rst_sync`). After reset `empty_o = 1`, `full_o = 0`.

### Verification
- `tb_cdc_fifo.sv` (`W = 40`, `D = 8`, unrelated clock periods; four period pairs in `scripts/regress.py`). No test for `sf_hbm_rst_sync`, for a mid-run reset, or for other depths; no formal harness exists for the FIFO (`CDC_AND_CLOCKS.md` section 4).

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- Instantiated by no RTL module; variable latency means it cannot sit in the cycle-exact PHY path; read data is a combinational memory read in the read domain.

## sf_hbm_datafabric

### Interface contract
- NoC side `req_valid_i/req_ready_o/req_pkt_i`, `rsp_valid_o/rsp_ready_i/rsp_pkt_o` (`noc_packet_t`, SF-NOC contract v1); configuration `addr_hi_i`, `max_burst_m1_i`; HBM granule side `h_req_*` (no `order`/`fence`), `h_rsp_*` (`h_rsp_ready_o = 1`); events `ev_drop_o`, `ev_err_rsp_o`.
- SCALAR / VECTOR / BURST mapping, fusion, ROB in request order, unique tags, error mapping: `DATAFABRIC.md`.

### Parameters
- `REQ_DEPTH` 4, `ROB_N` 64, `NTAG` 64, `HBM_SRC` 0.

### Reset semantics
- Async assert: FIFO, ROB, tag table, burst contexts and `bw_*` state empty/idle.

### Verification
- `tb_datafabric.sv` (`BACKEND=0` mock with out-of-order responses and 3 seeds, `BACKEND=1` real controller with 2 channels): tests `basic`, `burst`, `mixed`, `errors`, `range`, `bp`; `tb_dma_spm.sv` drives it through the DMA adapter. Simulation-time assertions on foreign/unknown responses and ROB overflow.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: the offered request tag is held stable while `valid && !ready`, with a simulation assertion (C4).**
- One burst-read and one burst-write context, head-of-line blocking; 4 GiB window per instance with no `addr_hi` register; masked writes fail when controller ECC is on; no ordering/fence mapping; burst-read error beat count undefined by the contract; no formal harness.

## sf_hbm_dma_adapter

### Interface contract
- Control `start_i, dir_i, hbm_addr_i[39:0], spm_addr_i, bytes_i[23:0], burst_beats_i[5:0]` -> `busy_o, done_o, err_o, bytes_moved_o, chunks_o`; NoC master port; scratchpad burst port (`spm_req_*`, `spm_wdata_*`, `spm_rdata_*`, `spm_done_*`).
- 16 B beats, chunks of `min(burst, remaining, to next SRAM page, SPM_MAX_BEATS)`, strictly sequential; alignment errors (`MISALIGN`) at start; first error wins and stops after the current chunk; `done_o` pulses once per transfer (`DATAFABRIC.md` section 8).

### Parameters
- `MY_ID` `4'b0000`, `MEM_ID` `4'b0011`, `SPM_PAGE_BYTES` 4096, `SPM_MAX_BEATS` 256.

### Reset semantics
- Async assert: `D_IDLE`, burst 1, counters 0, `done_o`/`err_o` cleared.

### Verification
- `tb_dma_spm.sv` (mock and real-controller backends; scratchpad = vendored `memory_controller`): HBM->SRAM bursts 8/1/3/32, 16 B-aligned HBM sources, page-boundary splitting, SRAM->HBM, round trip 4 KiB, error paths (misaligned, out-of-aperture, out-of-capacity), recovery.

### Synthesis status
- see reports/synth/ (generated)

### Known limitations
- **v2: the descriptor is held until accepted (C1); zero-strobe filler beats close a NoC burst after an SRAM-side error (C2); ECC-flagged SRAM beats are sent with strobe 0 (C5); a response that ends early completes the SRAM burst (C6). Reproducers in `tb_dma_spm`.**
- `hbm_addr_i[39:32]` is checked against `node_addr_hi_i` and a transfer that would wrap the 32-bit NoC address is rejected (`RANGE`, nothing issued); chunks are clamped to `node_max_burst_m1_i + 1` beats; `bytes_moved_o` counts only error-free chunks (all in `tb_dma_spm` `error_paths`). A node that rejects a dir-0 chunk with a single flit while the DMA expects `chunk` flits is avoided by the clamp, not by a time-out: there is still no DMA time-out; no formal harness.
