# v2 verification audit and independent RTL review — findings and disposition

v2 did **not** start from a passing design. The v1 release (`silicaflux-hbmcore.zip` in the repository) claimed 74/74 regression
passes on Verilator 5.048. Re-run unchanged on the toolchain available for v2 (Verilator 5.020, Ubuntu 24.04), **43 passed and
26 failed** (`docs/AUDIT_V2.md`). Two of the causes were in the test environment and two in the RTL. Three fresh-context reviewers then
read the RTL without being told what to look for beyond "find real defects". They were split by subsystem: scheduling core (A), data
path and DRAM model (B), top level and integration (C). They ran experiments but edited nothing.

**Method.** Every finding was:

* re-checked against the code by the author;
* turned into a test that **fails on the v1 RTL**;
* then fixed.

The "pre-fix" column below is the observed result of that test on v1.

**Lesson (the same one v1 recorded).** A green regression only covers what the checks can see. Of the 25 design and verification items below (S5 and S6, two defects in the v2 tooling itself, come on top):

* 2 were invisible because the toolchain was different. The checker was silently blind.
* 3 were invisible because every shipped profile had `tRC == tRAS + tRP`.
* the rest were invisible because no stimulus reached them.

## Found while re-running the baseline (author)

| # | finding | where | fix | evidence |
|---|---|---|---|---|
| S1 | **Simulator defect makes the independent DRAM checker blind.** Verilator 5.020 keeps only the LAST member write to an element of a multi-dimensional array of unpacked structs (reproduced standalone: `verification/toolchain/vl_ustruct_member_write.sv`; reviewer B narrowed it to first dimension = 1). In `hbm4_dram_model` the bank state `bank_t bk[NUM_PC][NB]` lost its reset values (`NEVER` -> 0) and `open = 1` on ACT. Every single-pseudo-channel bench then failed on the first ACT, and checks such as ACT-to-open-bank or tRAS could never fire. | `verification/hbm4/hbm4_dram_model.sv` | per-field plain 2-D arrays (`bk_open`, `bk_last_act`, ...) | 22 FAILs of the baseline run become PASS. The checker's sensitivity is re-proven by `tb_timing_rules` (illegal pairs must be flagged) on profiles 0-3 and by 18 RTL mutants. |
| S2 | `sf_hbm4_controller` does not compile on Verilator 5.020 for some configurations: reset for-loop with non-blocking writes to an unpacked array (`BLKLOOPINIT`) | `rtl/sf_hbm4_controller.sv:261` | one `always_ff` per tracker entry (generate) | the 4 DataFabric/DMA "real controller" builds compile and pass |
| S3 | `-Wall` lint of the controller fails on 5.020 (`WIDTHEXPAND` in the cluster steering) | `rtl/sf_hbm4_controller.sv:192` | explicit 32-bit widening | `make hbm-lint` clean |
| S4 | every script hard-codes `/opt/vl548` (a private Verilator install), and cocotb required 2.x / Verilator >= 5.036 | `scripts/*`, `run_cocotb.py` | tools from `PATH`; cocotb 1.9 and 2.x supported | flows run on stock Ubuntu packages |
| S5 | **The benchmark bench never stopped on Verilator 5.020.** The `initial` loop did not see `finished = 1` set by an `always` block. Every benchmark therefore ran to its 4 M-cycle cap (hours at 32 channels), and the refresh / PRE / command counts in its JSON covered the whole capped run (a refresh-overhead "fraction" of 608). Found when the v2 benchmarks were run. | `verification/tests/tb_bench.sv` | the loop also evaluates the completion condition itself | 1-channel A run: 2286 DRAM commands / 42 s before, 234 / 0.01 s after, with an identical measured window. All 103 benchmark results regenerated. |
| S6 | **The coverage merge under-reported.** `verilator_coverage --write-info` (5.020) did not combine the same source point across different instance hierarchies: `sf_hbm_rfm.sv:107`, hit 2311 times in one run, was written as 0. | `scripts/coverage.py` | the script parses the raw `coverage.dat` points and merges them across instances and runs | the same data re-evaluated: 86.5 % -> 93.9 %; RFM 51 % -> 100 % |

## Reviewer A — scheduler, bank FSM, timing, refresh, power, queue

| # | finding | fix | reproducing test (v1 -> v2) |
|---|---|---|---|
| A1 | **Anti-starvation defeated once the competing row hits are themselves older than `starve_limit`.** v1 exempted boosted entries from the bank drain, and inside the boosted tier `colhit` outranked age. Each boosted hit re-armed tRTP, so the starving entry's PRE was never legal and B waited for the whole flood (555 / 765 cycles, the same as with the limit off). | drain applies to every entry **younger** than a boosted entry that needs PRE on the same bank (`drained[]`); inside the boosted tiers the order is age only | `v2_starvation_boosted_hits_low_limit` (LIM 10/20 on profiles 1-3): **FAIL -> PASS** (B served after 35 instead of 121 responses) |
| A2 | **Refresh could issue before tRC since the last ACT.** REF legality used `bank idle`, which has no tRC term. The controller's own bank-FSM checker flags this. It was hidden because every shipped profile has `tRC == tRAS + tRP` exactly. | REF_AB / REF_PB (and the new RFM) legality uses `bk_can_act` (idle and tRC). New rule 18 in the DRAM model and the Python checker. New profile 3 `sim_trc_slack` (`tRC > tRAS + tRP`) runs every suite. | `+TRCADD=10` refresh / refmodes and profile-3 suites: **FAIL (controller violation `$error`) -> PASS** |
| A3 | **Refresh could stop with no alarm.** `max_postpone` / `max_pullin` were truncated to 8 bits, while the debt register saturates at ±100. With 101-255, "urgent" was unreachable. With 256, the limit wrapped to 0 and `deadline_miss` fired spuriously. | limits clamped to the debt range in `sf_hbm_refresh`; `scripts/gen_profiles.py` rejects profiles above 100 | `v2_refresh_postpone_above_debt_range` (MAXPP 150, lazy refresh, 20 k requests): **FAIL (DRAM model `refresh_deadline`, controller silent) -> PASS** |
| A4 | **Re-init deadlocks if a row is open** (open-page policy, the default). The init MRS needs all banks idle, and with `enable` low nothing closes rows. | the init port issues PREA first while any row is open; only the MRS acknowledges the step | `v2_reinit_with_open_rows` (profiles 0-3): **FAIL (MRS not granted in 2000 cycles) -> PASS** |

## Reviewer B — data path, PHY adapter, ECC, init, DRAM model

| # | finding | fix | reproducing test |
|---|---|---|---|
| B1 | = S1 (found independently) | see S1 | see S1 |
| B2 | **PHY contract C1 (command only while `ready`) was checked by nothing.** A scheduler mutant that ignores PHY back-pressure passed the whole regression. | model rule `issued_while_phy_not_ready` (with `READY_LAT = 1 + CMD_LAT` history) **and** a pseudo-channel assertion | RTL mutant `phy_ready_ignored`: **survived -> killed**. It is also killed by the model alone with the RTL assertions compiled out. |
| B3 | the model exempted MRS -> MRS from tMRD (`TIMING_RULES.md` and the Python checker do not) | exemption removed | `tb_timing_rules` on profiles 0-3 |
| B4 | **Late data of a timed-out read was delivered to the NEXT read with `HERR_NONE`** (silent misdelivery to another requester) | orphan accounting in `sf_hbm_read_return`. An off-time return while timed-out reads are pending is dropped. Any off-time or ambiguous completion is poisoned (`HERR_FLUSHED`, `corrected = 0`). Orphans clear after a quiet window. | new unit bench `tb_read_return`: **v1: id4 received id3's data with HERR_NONE (5 errors) -> PASS**. Formal ghost model updated to the v2 contract (BMC with data integrity). Formal mutants `rr_orphan_nodrop` / `rr_orphan_unpoisoned` and RTL mutants of the same name are killed. |
| B5 | an ECC fault-injection arm issued in the cycle the previous shot is consumed was lost | consume-clear before arm | cocotb `v2_rearm_in_consuming_cycle_is_kept` |
| B6 | the PHY error counter counted two same-cycle sources as one | separate `phy_rd_err_i` input, +2 | cocotb `v2_two_phy_error_sources_in_one_cycle_count_two` |
| B7 | model gaps: REF_AB / MRS / PDE / SRE ignored a running per-bank refresh; REF_PB ignored a running all-bank refresh | rules added (model and Python rule 19) | Python tests `test_v2_trc_before_refresh_and_overlapping_refreshes` |
| B7b | not added: minimum power-down / self-refresh residency, data activity during power-down | **open** (no rule in `TIMING_RULES.md`; needs the standard) | — |
| B8 | stale comment in the model | fixed | — |

## Reviewer C — controller top, address map, arbiters, CDC, CSR, perf, DataFabric, DMA

| # | finding | fix | reproducing test |
|---|---|---|---|
| C1 | **DMA hangs for ever if the NoC request link is back-pressured in the descriptor cycle** (the descriptor was offered for one cycle only) | descriptor held until accepted | `tb_dma_spm` `v2_*_req_backpressure_at_descriptor` (both directions): **v1: DMA timeout -> PASS** |
| C2 | **SRAM -> HBM DMA with an SRAM-side error wedges the DMA and the DataFabric memory node** (node stuck in `S_BWR` waiting for announced beats; every other tile blocked) | zero-strobe filler beats close the announced NoC burst | `tb_dma_spm` dir-1 bad SRAM address: **v1: timeout, node in S_BWR -> PASS** |
| C3 | address map aliases silently for > 8 stacks or > 64 channels (`hbm_loc_t` field widths) | elaboration `$error` | lint / elaboration |
| C4 | DataFabric `h_req_id_o` changed while `valid && !ready` (unstable payload) | offered tag held until the handshake; simulation assertion added | assertion active in every DataFabric/DMA run |
| C5 | DMA forwarded ECC-flagged SRAM beats into HBM with full strobes (the corruption became invisible behind fresh ECC) | strobe 0 for flagged beats, error recorded | by inspection (the scratchpad bench has no SRAM ECC injection) |
| C6 | DMA HBM -> SRAM hung when the node answered with a single error flit (MAXBURST changed between sizing and decode) | an early `eop` completes the SRAM burst with zero-strobe beats; `eop` also ends `D_DRAIN` | `tb_dma_spm` node-limit mismatch: **-> PASS with BURST_LEN** |
| C7 | CSR GEOMETRY reported the unclamped cluster size | clamped value | by inspection |
| C8 | 6-bit occupancy in `hbm_pc_stat_t` wraps for DEPTH >= 64 | elaboration bound DEPTH <= 63 | elaboration |
| C9 | `docs/CDC_AND_CLOCKS.md` §4 stale | updated | — |

## Found by the v2 coverage regression (author)

The coverage build changes the order in which the bench processes draw from the shared `$urandom` stream, so it produced
different but *legal* traffic. One run hit the controller's own `refresh deadline missed` assertion. Two distinct RTL bugs,
both present in v1, were root-caused with a refresh-state monitor (`+define+DBG_REF` in `tb_pc_single`) and then reproduced
deterministically by the new directed test `refswitch`. That test switches the refresh mode and eagerness at random
moments under continuous traffic.

| # | finding | fix | test |
|---|---|---|---|
| R1 | **A CSR refresh-mode change in the middle of a sequence corrupted it.** `sf_hbm_refresh` read `cfg.mode` combinationally. Per-bank -> all-bank while the per-bank sequence was in `R_REF` became a REF_AB that had never closed the other banks. `R_REF` had no way back to PRE, so a bank with pending hits stayed open for ever and the refresh deadline was missed. | the mode is latched per sequence (`seq_pb_q`); `R_REF` returns to PRE if its target is open | coverage run `+TEST=all +SEED=3 +PROFILE=2 +POLICY=2` (instrumented): **deadline miss -> PASS** |
| R2 | **The refresh debt was re-interpreted across modes.** It counts intervals of the current mode. Right after a REF_AB (tRFC 350 cycles on `sim_strict`) a switch to per-bank mode (interval tREFI/16 = 121 cycles) accrued per-bank units while every bank was still busy. The result was a spurious deadline miss. | effective mode `mode_q` changes only at a safe point: sequencer idle and debt <= 0, with eager catch-up while a switch is pending. AB -> PB restarts the pointer with debt 0; PB -> AB starts with one REF_AB owed. | `v2_refresh_mode_switch_under_traffic` (5 profile/policy/seed combinations): **v1 logic + R1 fix: deadline miss -> PASS** |

## What the reviewers checked and found correct (not re-verified by the author)

* counter arithmetic of every timing rule (N-1 load, `== 0` legal);
* one command per cycle;
* RD/WR only to the open row;
* the request queue's push/remove interactions and total age order;
* ordering rules vs `ORDERING.md`;
* ECC (exhaustive single- and double-bit run);
* write-data slot hold;
* PHY adapter delay lines;
* init handshake;
* same-ID tracker;
* fence;
* arbiter locking;
* CDC FIFO Gray logic;
* CSR read-back layouts;
* perf saturation / snapshot priority;
* DataFabric packet mapping;
* DMA chunk sizing.
