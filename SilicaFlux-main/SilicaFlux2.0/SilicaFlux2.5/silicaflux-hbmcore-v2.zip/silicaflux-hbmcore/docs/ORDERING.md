# HBMCore memory ordering contract (v1)

Transactions enter the controller as **single 32-byte-granule transactions** (`hbm_txn_t` after address mapping;
multi-granule host bursts are split into granules - and their responses reassembled - by the DataFabric adapter `sf_hbm_datafabric` (and, for DMA transfers, chunked by `sf_hbm_dma_adapter`); the controller itself never sees a multi-granule request).
A transaction is **accepted** at the cycle `req_valid && req_ready`. Everything below is defined in terms of *acceptance order*.

## Guarantees

1. **Exactly one response per accepted transaction** (read data, write completion, or error). Never lost, never duplicated.
2. **Response ownership.** A response carries the `src` and `id` of its request and is delivered only to that source.
3. **Same-{src,id} order.** Responses with the same `{src,id}` leave the controller in request order. (Implemented at
   the top level: a new request whose `{src,id}` still has outstanding requests on a *different* pseudo-channel is not
   accepted until they drain; on one pseudo-channel the queue's ID dependency keeps them in order.)
4. **Per-granule coherence (RAW / WAR / WAW).** Two transactions to the *same 32-byte granule*, at least one of which is a write,
   take effect in acceptance order. A read returns the value produced by the youngest *older* write to that granule
   (byte-wise: a masked write only changes its enabled bytes). Two reads to the same granule are unordered with respect to each other.
5. **Cross-granule order is NOT guaranteed.** Reads and writes to different granules may complete in any order, across and within
   pseudo-channels, unless an ordering attribute or a fence says otherwise.
6. **`ORD_SRC`**: the transaction is additionally ordered after every older transaction of the same source in its pseudo-channel queue.
   **`ORD_STRICT`**: a barrier within its pseudo-channel queue — nothing older issues after it, nothing younger issues before it.
   Both only order within one pseudo-channel; they do **not** order across pseudo-channels.
7. **Fence** (`req_fence`): accepted only when *no* transaction is outstanding anywhere in the controller; it then completes
   immediately with an ordinary response (`write=1`, `err=NONE`, `id`=the fence's id). While a fence is waiting nothing else is accepted
   (head-of-line). A fence therefore orders every earlier transaction before every later one, globally.
8. **Aggressive reordering never changes the above.** Command scheduling (FR-FCFS, batching, QoS, anti-starvation) may reorder
   DRAM commands, but the dependency scoreboard (`sf_hbm_req_queue`) forbids any reordering that would violate 3, 4 or 6.

## Write completion

A write response is produced when its data has been *delivered to the PHY* (default), or one cycle after command issue
(`WR_ACK_AT_DATA = 0`, "posted"). There is no DRAM-to-controller write acknowledge in the abstract interface; "complete" never
means "committed in the DRAM array" (docs/PHY_CONTRACT.md).

## Error responses

Errors travel through the same queues so that rule 3 still holds. Codes (identical to `silicaflux_pkg::sf_mem_exc_e`):

| code | name | raised when |
|---|---|---|
| 0 | NONE | normal |
| 1 | MISALIGN | `addr[4:0] != 0` (granule interface) |
| 2 | RANGE | address beyond the configured capacity |
| 3 | POLICY (DOMAIN) | partial write while controller ECC is enabled |
| 4 | BURST_BND | **defined, never produced by the RTL**: every granule is range-checked on its own, so a burst that runs past the capacity aperture yields RANGE for the granules beyond it |
| 5 | BURST_LEN | host burst longer than the configured maximum - raised by `sf_hbm_datafabric` (CSR MAXBURST), not by the controller |
| 6 | ECC | uncorrectable error: the read data is poisoned |
| 7 | FLUSHED | aborted (reset, or read-return timeout) |

An error transaction issues no DRAM command and does not modify memory.

## Log formats used by the independent checkers

*Command trace* (`+HBM_TRACE=<file>` of the DRAM model), one event per line:

```
<cycle> <pc> <cmd> <bg> <ba> <row> <col>      command visible at the DRAM boundary
W <cycle> <pc>                                 write-data bus beat
```
`cmd`: 1 ACT, 2 RD, 3 WR, 4 PRE, 5 PREA, 6 REF_AB, 7 REF_PB, 8 MRS, 9 PDE, 10 PDX, 11 SRE, 12 SRX, 13 RFM. `pc` is the global pseudo-channel number.

*Transaction log* (testbenches, JSON Lines), one record per event:

```
{"ev":"req","t":<cycle>,"src":S,"id":I,"w":0|1,"addr":"0x<hex>","mask":"0x<hex>","data":"0x<hex>"}   at acceptance
{"ev":"rsp","t":<cycle>,"src":S,"id":I,"w":0|1,"err":E,"data":"0x<hex>"}                              at response hand-shake
```
`data` / `mask` are hex strings of the full 256-bit / 32-bit values (`mask` = 1 per byte; reads log mask `0xffffffff`).
