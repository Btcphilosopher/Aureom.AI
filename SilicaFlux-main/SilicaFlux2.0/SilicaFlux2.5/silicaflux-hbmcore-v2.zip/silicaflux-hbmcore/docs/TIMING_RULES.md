# HBMCore timing rules (normative for the RTL, the DRAM model and the Python reference)

> v2 changes (all ENGINEERING_ASSUMPTION, like every rule here): rules 18-20 (tRC before refresh / RFM, no overlapping
> all-bank and per-bank refreshes, RFM), tMRD also between two MRS, PHY rule C1, profile field `trfm`, profile 3
> `sim_trc_slack`, and `max_postpone` / `max_pullin` <= 100. Reasons: `docs/REVIEW_V2.md`.

> **Status: HYPOTHETICAL.** The rules below are the *abstract controller/DRAM contract* of SILICAFLUX HBMCORE.
> They are modelled on the *kinds* of constraints a DRAM imposes, but neither the rule set nor any number
> in `configs/timing/profiles.json` is taken from JESD270-4, a vendor datasheet or a PHY specification.
> Do not describe any result obtained with them as HBM4-compliant. See `STANDARDS_MATRIX.md`.

All times are **controller clock cycles**. A command is *issued at cycle `t`* when it is visible on the
(abstract) command bus during cycle `t`. At most **one command per pseudo-channel per cycle**. Pseudo-channels
are completely independent: no rule couples two pseudo-channels.

`now - last_X >= N` means: the earlier event happened at cycle `last_X`, the later command at cycle `now`.
A never-seen event satisfies every rule. "bank" = (bank group `bg`, bank `ba`); `bg` = bank-group index.

## Profile fields (`configs/timing/profiles.json`)

`trcdrd trcdwr trp tras trc tccd_s tccd_l trrd_s trrd_l tfaw twr twtr_s twtr_l trtp trfc trfcpb trefi rl wl burst tmrd txp txs max_postpone max_pullin trfm` (v2: `trfm`)

Derived (all integers):

| name | definition |
|---|---|
| `RTW` | `max(1, rl + burst + 2 - wl)` |
| `WTR_S` | `wl + burst + twtr_s` |
| `WTR_L` | `wl + burst + twtr_l` |
| `WR2PRE` | `wl + burst + twr` |

## Command rules

**ACT (bank b, bank group g)**
1. bank b must be precharged (no open row).
2. `now - last_PRE(b) >= trp`            (PRE-to-ACT, same bank)
3. `now - last_ACT(b) >= trc`            (ACT-to-ACT, same bank)
4. for every bank group `g2`: `now - last_ACT_in_group(g2) >= (trrd_l if g2 == g else trrd_s)`
5. at most four ACT in any window of `tfaw` cycles: `now - (4th most recent ACT in the pseudo-channel) >= tfaw`
6. `now >= ref_busy_until` (all-bank refresh) and `now >= bank_ref_until(b)` (per-bank refresh of b)

**RD / WR (bank b, group g, row r)** — bank b must be open and `open_row(b) == r`.
1. `now - last_ACT(b) >= (trcdrd for RD, trcdwr for WR)`
2. column-to-column: for every group `g2`: `now - last_col(g2) >= (tccd_l if g2 == g else tccd_s)`,
   where `last_col(g2)` is the most recent RD *or* WR to group `g2`.
3. **RD only** (write-to-read): for every group `g2`: `now - last_WR(g2) >= (WTR_L if g2 == g else WTR_S)`.
4. **WR only** (read-to-write): `now - last_RD(any group) >= RTW`.

Data timing: a RD issued at `t` returns its 256-bit granule on the read-data bus during cycle `t + rl`
(visible exactly then). A WR issued at `t` takes its write data on the write-data bus during cycle
`t + wl` — exactly then, not before or after.

**PRE (bank b) / PREA (all banks)** — for every *open* bank that the command closes:
1. `now - last_ACT(b) >= tras`
2. `now - last_RD(b) >= trtp`
3. `now - last_WR(b) >= WR2PRE`
Closed banks are unaffected (PRE to a closed bank is a legal no-op). After PRE the bank is precharged and
`last_PRE(b) = now`.

**REF_AB (all-bank refresh)**
1. every bank precharged, and `now - last_PRE(b) >= trp` for every bank
2. `now >= ref_busy_until` (previous all-bank refresh finished)
3. effect: `ref_busy_until = now + trfc`; `last_refresh(b) = now` for every bank
4. *(v2, rule 18)* `now - last_ACT(b) >= trc` for every bank
5. *(v2, rule 19)* `now >= bank_ref_until(b)` for every bank (no all-bank refresh during a per-bank refresh)

**REF_PB (per-bank refresh of bank b)**
1. bank b precharged, `now - last_PRE(b) >= trp`, `now >= bank_ref_until(b)`
2. *(v2, rule 18)* `now - last_ACT(b) >= trc`; *(v2, rule 19)* `now >= ref_busy_until`
3. effect: `bank_ref_until(b) = now + trfcpb`; `last_refresh(b) = now`

**RFM (v2, rule 20: abstract refresh management of bank b; ENGINEERING_ASSUMPTION, see docs/ROWHAMMER.md)**
1. as REF_PB: bank b precharged, `now - last_PRE(b) >= trp`, `now - last_ACT(b) >= trc`, `now >= bank_ref_until(b)`,
   `now >= ref_busy_until`
2. effect: `bank_ref_until(b) = now + trfm` (an ACT to b inside that window violates rule ACT.6). `last_refresh` is NOT
   updated (an RFM is not a refresh of the bank for the deadline rule).

**MRS** — every bank precharged and `now - last_PRE(b) >= trp`, `now >= ref_busy_until`, *(v2)* `now >= bank_ref_until(b)`
for every bank; effect: no command (other than PDX/SRX) may issue for `tmrd` cycles: `now' - last_MRS >= tmrd`
(**including a following MRS**; the v1 DRAM model exempted MRS -> MRS, v2 does not).

**PDE / SRE (low-power entry)** — every bank precharged with `trp` elapsed, `now >= ref_busy_until`, *(v2)* no per-bank
refresh running.
After PDE the channel is *in power-down*, after SRE *in self-refresh*. **Only PDX (resp. SRX) is legal while in
that state.** PDX / SRX must only be issued in the matching state. After PDX no command may issue for `txp`
cycles, after SRX for `txs` cycles (`now - last_exit >= txp|txs`).

## PHY contract rule (v2, checked by the DRAM model)

**C1** — a command other than PDX / SRX may only be issued in a cycle in which the PHY's `ready` was high
(`docs/PHY_CONTRACT.md`). The model keeps a `ready` history and checks it `READY_LAT = 1 + CMD_LAT` cycles back; the
pseudo-channel asserts the same rule at the issue point.

## Refresh deadline (independent of how the controller schedules it)

For every bank, `now - last_refresh(b) <= (max_postpone + 1) * trefi + trfc + 4 * trc`, except while in
self-refresh. An SRX resets `last_refresh(b) = now` for all banks. (Time zero counts as a refresh.)

## Row-hit accounting (controller statistic, not a DRAM rule)

A request is a **row hit** if its column command issued without any ACT or PRE having been issued on its behalf,
a **row empty** miss if the first command issued on its behalf was an ACT, a **row conflict** miss if it was a PRE.
`row_hit_rate = hit / (hit + empty + conflict)`.
