# HBMCore address mapping (normative)

Geometry is a **simulation reference geometry** (ENGINEERING_ASSUMPTION, `rtl/sf_hbm_geom.svh`):

| field | width | default |
|---|---|---|
| byte offset inside an access granule | `OFF = 5` | 32 B granule (BL8 x 32 DQ) |
| column (in granules) | `COL = 6` | 64 granules = 2 KiB page |
| bank | `BA = 2` | 4 banks per bank group |
| bank group | `BG = 2` | 4 bank groups |
| row | `ROW = 15` | 32768 rows |
| pseudo-channel | `PC = 1` | 2 pseudo-channels per channel (PUBLIC_REFERENCE) |
| channel | `CH = log2(NUM_CHANNELS)` | 32 channels per stack (PUBLIC_REFERENCE); 1,2,4,8,32 supported in simulation |
| stack | `NS = log2(NUM_STACKS)` | 1 |

`NUM_CHANNELS` and `NUM_STACKS` are powers of two. The byte address is `ADDR_W = 40` bits wide at the host
interface. The capacity addressed is `2^(OFF+COL+BA+BG+ROW+PC+CH+NS)` bytes; any address with higher bits set is
**out of range**. An address with `addr[OFF-1:0] != 0` is **misaligned**.

`g = addr >> OFF` is the granule address. Fields are extracted LSB-first in the order of the selected mode.
`il` (interleave bits, 0..COL) splits the column into `col_lo` (low `il` bits) and `col_hi` (the other `COL-il` bits);
the column value is `col = col_lo | (col_hi << il)`.

| mode | field order, LSB first (after the byte offset) |
|---|---|
| `0 LINEAR`     | `col(COL), ba, bg, row, pc, ch, stack` |
| `1 CH_IL`      | `col_lo(il), pc, ch, stack, col_hi(COL-il), ba, bg, row` |
| `2 BANK_AWARE` | `col_lo(il), pc, ch, stack, bg, ba, col_hi(COL-il), row` |

(`pc`, `ch`, `stack` take `PC`, `CH`, `NS` bits; zero-width fields vanish.)

**Hash (optional, any mode).** Applied after extraction, with `row` unchanged (so the map stays a bijection):

```
bg ^= row[BG-1:0]
ba ^= row[BG+BA-1:BG]
ch ^= (row >> (BG+BA)) & (2^CH - 1)       # only if CH > 0
```
The inverse applies the same XORs first (they are involutions given `row`), then reassembles the address.

A mapped location is `(stack, ch, pc, bg, ba, row, col)`. The flat pseudo-channel index used by the top level is
`((stack * NUM_CHANNELS) + ch) * 2 + pc`.

## Worked example (independently derivable)

Default geometry, `NUM_CHANNELS = 4` (`CH = 2`), `NS = 0`, mode `CH_IL`, `il = 0`, no hash. Granule fields from the LSB:
`pc`(1) `ch`(2) `col`(6) `ba`(2) `bg`(2) `row`(15) -> 28 granule bits (+5 offset = 33 address bits = 8 GiB).
Address `0x0000_0000_0000_0060` = granule 3 = binary `0b11` -> `pc = 1, ch = 1`, everything else 0.
Address `0x0000_0000_0000_0020` (granule 1) -> `pc = 1, ch = 0`. Address `0x...0040` (granule 2) -> `pc = 0, ch = 1`.
