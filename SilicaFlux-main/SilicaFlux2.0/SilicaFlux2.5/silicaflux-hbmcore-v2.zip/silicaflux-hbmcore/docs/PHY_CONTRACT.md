# Controller <-> PHY adapter contract

> **Status.** This is the contract of the **abstract** controller/PHY boundary of HBMCore. It is an `ENGINEERING_ASSUMPTION` (`docs/STANDARDS_MATRIX.md`: IF-01, IF-04, IF-06, IF-07).
> It is not DFI, not JEDEC, and carries no pin-level encoding. The vendor-PHY backend (BACKEND B) is an explicit stub; PHY training is an external service; the PHY clock ratio is 1:1 only.
> Latencies below are *parameters of a hypothetical simulation profile*; no number in this file is a standard value.

Files: `rtl/sf_hbm_phy_adapter.sv`, `rtl/sf_hbm_command_encoder.sv`, `rtl/sf_hbm_write_data.sv`, `rtl/sf_hbm_read_return.sv`, `rtl/sf_hbm_ecc_ras.sv` (data path), `rtl/sf_hbm_pseudochannel.sv` (wiring),
`verification/hbm4/hbm4_dram_model.sv` (the only PHY+DRAM counterpart that exists).

## 1. Boundary signals (one pseudo-channel)

| group | signal | dir (controller view) | width | meaning |
|---|---|---|---|---|
| command | `cmd_valid_i`, `cmd_i` (`hbm_cmd_t`) | out | 1 + `HBM_CMD_W` (37 bits of command at the default geometry: `cmd` 4, `bg` 2, `ba` 2, `row` 15, `col` 6, `mrs` 8) | abstract typed command bundle; `sim_cmd_valid_o`, `sim_cmd_o` at the top |
| command | `cmd_ready_o` | in | 1 | back-pressure; seen by the scheduler as `phy_ready_i` |
| write data | `wdata_valid_i`, `wdata_i`, `wmask_i`, `wecc_i` | out | 1, 256, 32 (1 bit per byte), 10 | one whole 32 B granule + byte enables + 10 sideband check bits in **one** controller cycle; `sim_wvalid_o`, `sim_wdata_o`, `sim_wmask_o`, `sim_wecc_o` |
| read data | `rdata_valid_o`, `rdata_o`, `recc_o`, `rerr_o` | in | 1, 256, 10, 1 | one granule per read command; `rerr_o` = PHY/interface-level error flag; `sim_rvalid_i`, `sim_rdata_i`, `sim_recc_i`, `sim_rerr_i` |
| status | `backend_unimplemented_o` | in | 1 | 1 for BACKEND B |
| external | `phy_ready_ext_i` | -- | 1 | external back-pressure input (1 = can accept); `phy_event_i`, `ondie_event_i` are *counted* events (`RAS.md`) |

Per command, the fields the controller fills (`sf_hbm_scheduler.sv`, `sf_hbm_refresh.sv`, `sf_hbm_power_state.sv`, `sf_hbm_pseudochannel.sv`):
`ACT` bg/ba/row; `RD`/`WR` bg/ba/row/col (**the row is carried on column commands too**, because the bank FSM and the DRAM model check `cmd_row == open_row`; this is a property of the abstract bundle);
`PRE` bg/ba (+ the open row, informational); `PREA` none; `REF_AB` none; `REF_PB` bg/ba; `MRS` the 8-bit abstract operand `mrs` (placeholder values: `sf_hbm_init.sv` uses the step index);
`PDE/PDX/SRE/SRX/RFM` none. At the controller top, the bundles are flat arrays indexed by pseudo-channel `((stack*NUM_CHANNELS)+ch)*2+pc`.

## 2. Contract rules (as implemented)

| # | rule | implemented by | checked by |
|---|---|---|---|
| C1 | A command is offered only in a cycle in which `cmd_ready_o` is high (`phy_ready_i` gates every command except `PDX` and `SRX`). Ready is evaluated **at issue time** (cycle `t`); a deassertion in cycle `t+1` does not retract the command already in the encoder register. In BACKEND A `cmd_ready_o = phy_ready_ext_i` (combinational pass-through) | `sf_hbm_scheduler.sv` (`leg_*`, `mnt_leg`), `sf_hbm_phy_adapter.sv` | v2: **checked** by the DRAM model (`issued_while_phy_not_ready`, ready history `READY_LAT = 1 + CMD_LAT`) and by a pseudo-channel assertion; mutant `phy_ready_ignored` is killed. (v1 named `tb_pc_single backpressure` here, but no check observed the rule: a scheduler ignoring `ready` passed - `docs/REVIEW_V2.md` B2) |
| C2 | At most one command per cycle | scheduler | `sf_hbm_timing.sv` assertion "more than one of ACT/RD/WR in a cycle" |
| C3 | Write data for a `WR` issued in cycle `t` is placed on the write-data bus **exactly `WL` cycles after the command is visible at the PHY interface** (cycle `t+1+WL`, section 3) | `sf_hbm_write_data.sv` | model's write-data checker; mutant `wdata_one_late` (`scripts/mutation_check.sh`) |
| C4 | Read data for an `RD` issued in cycle `t` returns **exactly `RL` cycles after the command is visible at the PHY interface**, plus the fixed adapter latencies `CMD_LAT + RD_LAT` (cycle `t+1+RL+CMD_LAT+RD_LAT`) | `sf_hbm_read_return.sv` (`rq_due`) | `rd_timing_err_o` pulse on any other cycle |
| C5 | Read data returns **in command order**; no tags cross the interface; the engine pairs each return with the oldest outstanding read | `sf_hbm_read_return.sv` (`rq_idx/rq_due` FIFO) | `rd_unexpected_o` when data arrives with no outstanding read |
| C6 | After a command is accepted, the PHY write-data path is **non-blocking** (the controller has no "write data not accepted" input) and read data needs no back-pressure (the completion entry was reserved at issue) | `sf_hbm_write_data.sv` header, `sf_hbm_read_return.sv` header | by construction |
| C7 | A read whose data does not arrive within `RD_TIMEOUT` (64, module default, not overridden by the pseudo-channel) cycles after its due cycle completes with `HERR_FLUSHED` and raises `rd_timeout_o` | `sf_hbm_read_return.sv` | no directed test found (`scripts/regress.py` and the testbenches never suppress read data) |
| C8 | `rerr_o` (PHY/interface flag) on a returned granule is **counted only** (`phy_err_o` via `phy_event_i || (pa_rvalid && pa_rerr)`); it does not poison the response | `sf_hbm_pseudochannel.sv`, `sf_hbm_ecc_ras.sv` | none: every testbench ties `phy_event_i` to 0 |

`WL >= 1` is required: `sf_hbm_write_data.sv` raises an `$error` for `tp_i.wl == 0`.

## 3. Exact cycle arithmetic (as implemented)

Notation: the scheduler's combinational decision is visible in **cycle `t`** (`issue_valid_o`, `issue_cmd_o`, `dbg_cmd_valid_o`); `cyc_q == t` in that cycle. A signal "visible in cycle `x`" is the output of a register
loaded at the end of cycle `x-1`. `RL`, `WL` are profile fields of the active `hbm_timing_t`. `CMD_LAT` = parameter `PHY_CMD_LAT`, `RD_LAT` = `PHY_RD_LAT` (BACKEND A pipeline depths, default 0).

```
cycle:           t                t+1                   t+1+CMD_LAT                 ...
scheduler        issue_valid/cmd   .                     .
bank/timing      strobes -> counters loaded at the END of t (rule "N cycles later" => allowed in t+N)
command encoder  (combinational in)  phy_cmd_valid/cmd registered -> visible at the PHY adapter input
phy adapter                         c_pipe[0]            sim_cmd_valid_o / sim_cmd_o  (after CMD_LAT register stages)   <- DRAM-side boundary
```

| quantity | formula | RTL source |
|---|---|---|
| command visible at the adapter input | `t + 1` ("the PHY sees the command one cycle after the scheduler issued it") | `sf_hbm_command_encoder.sv` (`phy_cmd_valid_o <= cmd_valid_i`) |
| command visible at `sim_cmd_*` (DRAM boundary) | `t + 1 + CMD_LAT` | `sf_hbm_phy_adapter.sv` `c_pipe[CMD_LAT]` |
| write-data pending entry created | end of `t`; `due = cyc_i + WL` evaluated with `cyc_i = t`, i.e. `due = t + WL` | `sf_hbm_write_data.sv` `pend_push` |
| write data popped from the buffer | cycle `t + WL` (`pend_pop` when `cyc_i == due`); the data is registered, `wdata_valid_o` is visible in cycle `t + WL + 1` | `sf_hbm_write_data.sv` |
| write data at `sim_w*` | `t + WL + 1 + CMD_LAT` (data pipeline has the same `CMD_LAT` stages as the command, so the command-to-data distance is **exactly `WL`** at the boundary) | `sf_hbm_phy_adapter.sv` `w_pipe[CMD_LAT]` |
| ECC encode on the write path | combinational between `sf_hbm_write_data` output and the adapter (no latency) | `sf_hbm_ecc_ras.sv` `enc` |
| read due cycle | `rq_due = t + 1 + RL + RD_EXTRA_LAT`, `RD_EXTRA_LAT = PHY_CMD_LAT + PHY_RD_LAT` | `sf_hbm_read_return.sv`, `sf_hbm_pseudochannel.sv` (`RD_EXTRA`) |
| read data at the adapter output | the DRAM-side return `RL` cycles after the command at `sim_cmd_*` (`t+1+CMD_LAT+RL`), plus `RD_LAT` stages = `t+1+CMD_LAT+RL+RD_LAT` | `sf_hbm_phy_adapter.sv` `r_pipe[RD_LAT]`, `hbm4_dram_model.sv` (`it.data = t + RL`) |
| ECC decode on the read path | combinational (no latency); `rd_valid_i` and the corrected data enter `sf_hbm_read_return` in the same cycle | `sf_hbm_pseudochannel.sv` (`rr_rd_*`) |
| earliest read response | `rsp_valid_o` is combinational from `done_q[head]`; the data is stored at the end of the return cycle, so the response can be visible one cycle after the return cycle if the entry is the head | `sf_hbm_read_return.sv` |
| write completion (default `WR_ACK_AT_DATA = 1`) | `wr_done` pulse registered with the data: visible `t+WL+1`; response earliest the cycle after | `sf_hbm_write_data.sv` |
| write completion (`WR_ACK_AT_DATA = 0`, "posted") | `wr_done` pulse visible `t+1` | `sf_hbm_write_data.sv` |
| "completion" meaning | a write is complete when its data has been **delivered to the PHY** (or one cycle after issue when posted). There is no DRAM-to-controller write acknowledge in the abstract interface; "complete" never means "committed in the DRAM array" | `docs/ORDERING.md`, `sf_hbm_write_data.sv` |

Worked symbolic example (`CMD_LAT = RD_LAT = 0`): a `RD` issued at `t` appears at `sim_cmd_*` at `t+1`, its data must be at `sim_rvalid_i` at `t+1+RL`; a `WR` issued at `t` appears at `t+1`, its data at `t+1+WL`.
Substituting a profile's `RL`/`WL`: <!-- RESULTS: filled in by scripts/make_report.py (no numbers are quoted here on purpose) -->.

**Verification status of the latency parameters.** `PHY_CMD_LAT` and `PHY_RD_LAT` are non-zero in **no** testbench: `tb_pc_single.sv` instantiates `.PHY_CMD_LAT(0), .PHY_RD_LAT(0)`; `tb_ctrl_multi.sv`, `tb_bench.sv`, `tb_datafabric.sv` and `tb_dma_spm.sv` use the defaults (0).
The `t+1+CMD_LAT` / `RD_EXTRA_LAT` arithmetic above is therefore derived from the RTL and consistent by inspection, but **not exercised** by a simulation in this repository.

## 4. Command encoder

`sf_hbm_command_encoder #(ENCODING = 0)`: typed pass-through `{valid, hbm_cmd_t}`, registered (`phy_cmd_o <= cmd_valid_i ? cmd_i : '0`, reset to NOP). `ENCODING != 0` triggers an elaboration `$error`
("no verified HBM4 command encoding is integrated (pending specification)"). The pseudo-channel instantiates it with `ENCODING(0)` hard-wired. A physical encoding (row/column command-bus partitioning, truth tables) is
to be added in this one place once a specification exists (`STANDARDS_MATRIX.md` IF-02, UNIMPLEMENTED). The controller's command-register pipeline stage is this block.

## 5. Backends

| | BACKEND A (`PHY_BACKEND = 0`) | BACKEND B (`PHY_BACKEND = 1`) |
|---|---|---|
| purpose | simulation PHY, "pure functional pipeline" into `verification/hbm4/hbm4_dram_model.sv` | placeholder for a licensed PHY ("UNIMPLEMENTED - PENDING PHY SPEC") |
| `cmd_ready_o` | `phy_ready_ext_i` | constant `0` |
| `backend_unimplemented_o` | `0` | constant `1` (exported as `stat_o[].unimpl`, CSR `STATUS[11]` once the integrator ORs it) |
| command / write path | `CMD_LAT` register stages on command **and** write data (relative timing preserved) | all `sim_*` outputs driven idle (`0`) |
| read path | `RD_LAT` stages | `rdata_valid_o = 0` |
| analogue / training / DFI timing | none ("It contains NO analogue behaviour, training or DFI timing") | none; "It is NOT labelled DFI" |
| simulation message | -- | `$display` "BACKEND=1 (vendor PHY) is UNIMPLEMENTED" |

Derived consequence for BACKEND B (from code; the stub's behaviour at the pseudo-channel level - flag raised, no command ever reaches the DRAM, no fabricated completion - is simulated by `tb_pc_single -GPHY_BACKEND=1`, the init-sequencer consequence below is not): since `cmd_ready_o = 0`, no command except `PDX`/`SRX` can ever be granted, including the init `MRS`, so `sf_hbm_init` would wait in its mode-configuration state and, if `init_timeout != 0`, land in `ERR`
with cause 4 (`rtl/sf_hbm_init.sv`). No testbench builds `PHY_BACKEND = 1` (the `BACKEND` parameter of `tb_datafabric`/`tb_dma_spm` selects mock vs real controller, a different thing).

## 6. Bring-up handshakes (external services)

`sf_hbm_init` raises `phy_init_start_o` (state `I_PHY`) and `train_start_o` (state `I_TRAIN`) and waits for `phy_init_done_i` / `train_done_i`; `power_good_i` and `clk_stable_i` gate the first two steps; losing either in `READY` returns to `RESET`.
Training, calibration, ZQ/impedance, eye search, VREF and delay tuning are **not implemented**: they are an external PHY service (`INIT-03`, UNIMPLEMENTED). The four `MRS` writes have placeholder operands (`INIT-02`).
Tested with testbench-driven handshakes in `tb_ctrl_multi.sv` test `init` (`init_sequence_gating`); the MRS commands are counted at the DRAM boundary (`cmd_cnt >= NPC*4`).

## 7. What a real PHY integration must provide

| need | why / where it hooks in | matrix id |
|---|---|---|
| a licensed PHY specification (DFI-compatible or vendor-specific) and its supported RTL | BACKEND B is empty; nothing may be described as DFI-compliant | IF-03 |
| the real command table and pin-level encoding, row/column command bus partitioning | `sf_hbm_command_encoder` (`ENCODING != 0`); the abstract bundle carries `row` on column commands and has no real MRS encoding | IF-01, IF-02 |
| clock-ratio and data-width conversion | the adapter is 1:1 and moves a whole 256-bit granule per cycle; a real PHY runs a different ratio and serialises a granule over several beats (`CDC_AND_CLOCKS.md`) | IF-05 |
| a read-return contract: fixed or bounded latency, ordering, tags (if any) | `sf_hbm_read_return` flags **every** deviation from "exactly `RL` after the command, in order" as `rd_timing_err`; a PHY with variable latency, tags or retry requires a different return engine | IF-06 |
| a write-data timing contract (including data-bus occupancy `burst`, preamble, DM/DBI behaviour) | `sf_hbm_write_data` delivers exactly `WL` after the command and assumes no back-pressure after acceptance | IF-07, IF-08 |
| a sideband path for 10 ECC bits per 32 B granule, or a different protection scheme | `wecc_o`/`recc_i` (UNVERIFIED for HBM4) | RAS-01 |
| a PHY parity/CRC/alert definition feeding `phy_event_i` / `rerr_o` | counted only today | RAS-03 |
| device mode-register map and mandatory MRS sequence | four placeholder MRS steps | INIT-02 |
| power-state command semantics and exit latencies | `PDE/PDX/SRE/SRX` are abstract; `txp`/`txs` come from the (hypothetical) profile | REF-03 |
| a real backend selection for training status | `phy_init_done_i`/`train_done_i` are plain inputs | INIT-03 |
| a decision on whether the two pseudo-channels share a command bus | the RTL schedules them independently | ARCH-07 |

## 8. Verification that exists

* `verification/hbm4/hbm4_dram_model.sv`: independent timestamp-based checker of every command, write-data timing (exactly `WL`), fixed `RL` read return, optional random `ready_o` back-pressure; "NOT a JEDEC-verified HBM4 device".
* `tb_pc_single.sv`: all tests run against the model; `backpressure` (`+RSPRDY`, `+PHYSTALL`), `ecc` (read/write-path injection).
* `tb_timing_rules.sv`: legal and one-cycle-short schedules, three judges.
* `python/hbm4/trace_check.py` re-checks the model's command trace (`+HBM_TRACE=<file>`), invoked by `scripts/regress.py` (`python_trace_check_of_rtl_traces`).
* Coverage: non-zero `PHY_CMD_LAT`/`PHY_RD_LAT` (2 / 3) run the whole `tb_pc_single` suite for all three policies (regress `pc_single_phy_cmd2_rd3_policy*`); BACKEND B stub: `pc_single_backend_b_unimplemented_stub`; `phy_event_i` / `ondie_event_i` counting: `tb_pc_single` test `phy_events`. Gaps: the PHY read-error input `rerr_o` and the read time-out (C7) are not exercised by any testbench; formal observation O2 (`docs/FORMAL.md`): a late read return after a time-out cannot be told apart from the next read's return.
