# Refresh management (RFM / directed RFM) — a RowHammer RESEARCH HOOK (v2)

> **Status: ENGINEERING_ASSUMPTION / UNVERIFIED. This is not RowHammer protection.**
> No HBM4 specification was available. Whether JESD270-4 defines RFM or DRFM — and with which counters, thresholds,
> command encodings, scope (all-bank / per-bank) and timing — is **not known here**. The open-source Ramulator 2.1 HBM4
> model lists `RFMab` / `RFMpb` commands and cites JESD270-4A tables (`docs/SIMULATOR_COMPARISON.md`). That is a public
> reference, not a verification. Protection claims need a threat model, the real device's mitigation behaviour and its
> RowHammer threshold. None of these are available, so none is claimed.

## What is implemented

`rtl/sf_hbm_rfm.sv` (one per pseudo-channel) watches the issued command stream:

| mechanism | behaviour | configuration (CSR `REFCFG`) |
|---|---|---|
| rolling accumulated ACT count **RAA[b]** per bank | +1 per ACT; −`raa_ref_dec` per refresh covering the bank (REF_AB: all, REF_PB: that bank); −`raaimt` per RFM to the bank; saturating 0..255 | `[31:24] raa_ref_dec` |
| **RFM request** | RAA[b] ≥ `raaimt` → the lowest such bank is handed to the refresh engine | `[4] rfm_en`, `[15:8] raaimt` (0 = no requests) |
| **ACT block** | RAA[b] ≥ `raammt` → demand ACT to bank b is not legal (maintenance commands are unaffected, so the RFM itself can still run) | `[23:16] raammt` |
| **directed mode** | a 2-entry Misra-Gries heavy-hitter tracker per bank names the most-activated row; the RFM carries it and the entry is cleared after the RFM | `[5] rfm_dir` |

`sf_hbm_refresh` executes an RFM as a per-bank sequence:

* **sequence:** HOLD bank (ACT and column) → PRE if open → wait idle → abstract `HCMD_RFM(bank, row)`;
* **priority:** the sequence has scheduler priority (otherwise demand on other banks could postpone it until the bank is ACT-blocked);
* **refresh debt:** untouched;
* **refresh precedence:** a refresh that is due starts first;
* **legality** (scheduler): bank idle and tRC since its last ACT;
* **cost:** the bank is busy for `trfm` cycles (a new HYPOTHETICAL profile field).

Defaults after reset (hypothetical): `rfm_en = 0`, `raaimt = 32`, `raammt = 64`, `raa_ref_dec = 16`.

**Observability:**

* performance counters 33 (`rfm`) and 34 (`rfm_block_cycles`), aggregate and per pseudo-channel (ids 44 / 45);
* `raa_max_o` (registered).

## How it is checked

* **DRAM model** (`hbm4_dram_model`): an RFM must target a precharged bank with tRP and tRC met, and must not overlap a refresh. The bank is then busy for `trfm`: a later ACT inside that window is a `tRFC` violation.
* **Python checker:** rule 20, the same rules, written independently.
* **RTL:** `sf_hbm_rfm` asserts (simulation only) that no ACT is ever issued to a bank at or above `raammt`.
* **Formal:** the bank FSM harness covers `rfm_i` symbolically (same assumptions and ghost as a per-bank refresh, `trfm <= 4`).
* **Research metric** in the DRAM model, `max_unmitigated_row_acts`: the most ACTs any single row received since that row was last mitigated by an RFM.
  * Directed mode: the RFM mitigates the named row.
  * Undirected mode: the RFM mitigates the most-activated row of the bank (a device-side tracking assumption).
  * **Regular refresh is deliberately not counted as mitigation.** The metric is therefore a conservative upper bound, and it can exceed `raammt` across refresh decrements.

## Adversarial test (`tb_pc_single +TEST=rowhammer`, part of `+TEST=all`)

Pattern: a double-sided hammer. Two rows of one bank are read alternately, 600 accesses, kept serial with `ORD_STRICT`. Without that, FR-FCFS simply regroups the accesses into row hits; an attacker serialises dependent accesses.

Configuration: IMT 16, MMT 32, decrement 8. Results of the v2 regression runs (MODELLED, hypothetical profiles; see `reports/regression.md` for the run):

| profile / policy | RFM off: max unmitigated ACTs on one row | directed RFM: metric / RFMs / cycles | undirected | cycles RFM off -> directed |
|---|---|---|---|---|
| sim_ref / FR-FCFS | 300 | 20 / 38 / 38,223 | 17 / 40 | 30,624 -> 38,223 (+24.8 %) |
| sim_fast / BG-aware | 300 | 24 / 31 / 9,618 | 24 / 30 | 8,708 -> 9,618 (+10.4 %) |
| sim_strict / FCFS | 300 | 24 / 27 / 53,249 | 24 / 28 | 45,266 -> 53,249 (+17.6 %) |
| sim_trc_slack / FR-FCFS | 300 | 37 / 17 / 13,954 | 37 / 18 | 13,321 -> 13,954 (+4.8 %) |

Further phases of the same test:

* **"MMT blocking only"** (`raaimt = 0`, `raammt = 8`): no RFM is issued. ACTs are held until refresh decrements the count. Progress continues; e.g. on `sim_ref`, 80,750 of 95,661 cycles had an ACT-blocked bank. This is the throughput cost of blocking without mitigation.
* **Benign random traffic with RFM on:** data exact, no violation.

## What would be needed for a real mitigation

* the JESD270-4 definition of RFM/DRFM and of the device's internal tracking;
* tRFM / tDRFM values for the speed grade;
* the device's RowHammer threshold and its blast radius;
* a threat model (single- and double-sided, many-sided, half-double, refresh-synchronised patterns);
* validation against device behaviour or a vendor model.

An all-bank RFM, an RFM during self-refresh, and interaction with per-bank refresh scheduling policies are not modelled.
