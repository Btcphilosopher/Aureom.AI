# Bandwidth calculation and scaling

## Convention
Decimal units: 1 GB = 1e9 bytes, 1 TB = 1e12 bytes. Theoretical bandwidth of a DDR-style parallel interface:

    bandwidth = data pins x data rate per pin / 8

Reference calculation required by the project brief:

    2048 pins x 8 Gb/s / 8 = 2048 GB/s = 2.048 TB/s

This is a **theoretical pin throughput**, not an application's sustained bandwidth. The 8 Gb/s per pin is an *input* of the calculation; it is not a claim
about any HBM4 speed grade (no speed grade is verified here, see `STANDARDS_MATRIX.md`). The same arithmetic is implemented and tested independently in
`python/hbm4/performance.py` (`pin_bandwidth_gb_s`; test asserts 2048 GB/s) and exposed by `python/benchmarks/bandwidth_calc.py`.

## Simulation convention (and why the numbers line up)
The shipped `sim_ref` profile uses a 1 GHz controller clock, one 32 B access granule per `burst` (=1) cycle per pseudo-channel, 64 pseudo-channels:

    64 x 32 B / 1 ns = 2048 GB/s

so the *modelled peak* of the 32-channel reference configuration equals the pin arithmetic **by construction**. `efficiency = measured / modelled peak` is therefore
meaningful for that profile. For other profiles (`sim_strict`: burst = 2) the modelled peak is lower; always read `peak_modelled_gb_s` from the result file.

## Measurement method (for any "efficiency" number)
* measured = bytes of error-free responses (reads: 32 B per granule; writes: popcount of the byte mask) / simulated time of the whole run, ramp-up included;
* source: `verification/tests/tb_bench.sv` (JSON), percentiles recomputed in Python from the exact histogram;
* an efficiency without this definition must not be quoted.

## What the gap to peak consists of (all measured or derivable from the result files)
| loss | where to read it |
|---|---|
| command scheduling / bank-conflict stalls | `stalls.timing_stall_pc_cycles`, `row.conflict`, `row.hit_rate` |
| row activation overhead | `row.act`, `row.pre` (each ACT costs tRC of bank time) |
| refresh | `refresh.overhead_fraction` (= refreshes x tRFC / (cycles x PCs)); analytic bound tRFC/tREFI |
| read/write turnaround | benchmark C vs A/B; DSE `batch0` vs `batch1` |
| limited queue depth / in-flight window | DSE queue x completion depth; `stalls.queue_full_cycles` |
| DataFabric / ingress width | single-port ceiling: 1 granule/cycle = 32 GB/s (benchmark A single-port vs sliced) |
| incomplete workload parallelism | DSE outstanding-window sweep; hotspot benchmark E |
| bank-group mapping | DSE address-mapping sweep: linear < channel-interleave < bank-aware |

No number in this repository is a hardware measurement.
