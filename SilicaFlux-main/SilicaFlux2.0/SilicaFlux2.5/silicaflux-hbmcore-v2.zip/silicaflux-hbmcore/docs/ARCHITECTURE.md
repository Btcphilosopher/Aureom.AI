# HBMCore architecture

> **v2 additions** (docs/REVIEW_V2.md, docs/ROWHAMMER.md):
> * Each pseudo-channel gains `sf_hbm_rfm`, a refresh-management research hook. It watches the issued command stream,
>   asks the refresh engine for per-bank RFM sequences and blocks demand ACTs at the `raammt` threshold.
> * The refresh engine runs on an **effective** mode that changes only at a safe point, and it latches the mode per
>   sequence.
> * The read-return engine never delivers ambiguous data as good after a PHY latency-contract violation (orphan
>   accounting).
> * The SECDED code is restructured for timing; it is proven equivalent to v1.
> * The scheduler's anti-starvation drain and its refresh legality (tRC) are corrected.

> **Status.** SILICAFLUX HBMCORE is an HBM-*style* memory-controller subsystem: synthesizable SystemVerilog (`rtl/`), a behavioural
> DRAM model (`verification/hbm4/hbm4_dram_model.sv`), a NoC adapter and a DMA adapter (`integration/`), and an independent Python
> reference (`python/hbm4/`). It is **not** JEDEC-, HBM4- or DFI-compliant and is not silicon-ready. Every timing profile is
> `HYPOTHETICAL_SIM` (`configs/timing/profiles.json`); the command set `hbm_cmd_e` is an abstract controller command set, not a
> JEDEC table, and has no pin-level encoding; the vendor-PHY backend is an explicit stub; training is an external PHY service.
> Classification of every requirement: `docs/STANDARDS_MATRIX.md`, `docs/MISSING_SPEC.md` (generated, not edited here).

Companion documents: `SCHEDULER.md`, `PHY_CONTRACT.md`, `POWER.md`, `RAS.md`, `PERF_COUNTERS.md`, `CDC_AND_CLOCKS.md`,
`DATAFABRIC.md`, `INTEGRATION_BLOCKERS.md`, `MODULES.md`; normative contracts `ADDRESS_MAP.md`, `ORDERING.md`, `TIMING_RULES.md`, `RAS_CODE.md`.

## 1. Data path

What the RTL in this repository implements is the part to the right of the "bridge" box. The three compute-core boxes belong to the
wider SilicaFlux tree and are **not integrated** (see `INTEGRATION_BLOCKERS.md`): the testbenches replace them by NoC-packet generators
(`verification/tests/tb_datafabric.sv`, `tb_dma_spm.sv`).

```
 ControlCore   VectorCore   TensorCore          (SilicaFlux tree; NOT integrated, no tile_interface / compute_tile compile)
      \            |           /
       +-------- DataFabric NoC v2 -----------+   noc_packet_t, SF-NOC contract v1 (vendored, integration/datafabric/third_party/noc_v2)
                                              |
                              integration/datafabric/sf_hbm_datafabric.sv      "bridge": request FIFO -> granule requests,
                                              |                                 reorder buffer (ROB) -> response flits
                                              |  HBM-TXN v1: ONE granule request per cycle, ONE response port
                                              v
 rtl/sf_hbm4_controller.sv  (single host request port; req_valid/req_ready, rsp_valid/rsp_ready)
   +- sf_hbm_init        gates traffic (ready_o), broadcasts 4 abstract MRS writes, PHY init/training handshakes (external)
   +- sf_hbm_addr_map    byte address -> {stack,ch,pc,bg,ba,row,col}; RANGE / MISALIGN checks      (combinational)
   +- ingress checks     partial write + controller ECC -> HERR_POLICY; error entries steered to PC 0 when the address is bad
   +- ID-order tracker + fence + outstanding counter
   +- cluster steering   tgt_cl = ch / NCH_CL ; tgt_local = pc % NPC_CL
   |
   +--> NCL x sf_hbm_stack_cluster --> NCH x sf_hbm_channel --> 2 x sf_hbm_pseudochannel
                                                                   |
        per pseudo-channel (rtl/sf_hbm_pseudochannel.sv):          |
                                                                   v
   request ------> sf_hbm_req_queue  (DEPTH slots, age matrix, dependency matrix)
   (+wdata,wmask)        |  \_____ slot index ______ sf_hbm_write_data (same slot index; data held until sent)
                         v
                  sf_hbm_scheduler  <--- bank view  (16 x sf_hbm_bank_fsm: row state, bank-local timing)
                         |         <--- timing view (sf_hbm_timing: cross-bank timing)
                         |         <--- credits     (completion slot, write-data pending slot, PHY ready)
                         |         <--- maintenance port: init MRS > power sequencer > refresh engine
                         v
                  sf_hbm_command_encoder   (abstract pass-through + one register stage)
                         v
                  sf_hbm_phy_adapter       BACKEND 0: simulation pipeline -> verification/hbm4/hbm4_dram_model.sv
                         |                 BACKEND 1: stub (backend_unimplemented_o = 1, cmd_ready_o = 0)
                         v
                       DRAM (behavioural model in every testbench)

   read data <- phy adapter <- sf_hbm_ecc_ras (combinational SECDED decode) <- sf_hbm_read_return (completion sequencer) -> response
   write data -> sf_hbm_write_data -> sf_hbm_ecc_ras (combinational encode) -> phy adapter
```

**Ordering of the stages differs from a pure "queues first" description.** In the RTL the address map and the ingress checks sit *upstream*
of the per-pseudo-channel request queues (`rtl/sf_hbm4_controller.sv`: `u_map`, `err_c`, `tgt_pc`), because a transaction must know its
pseudo-channel before it can be queued; the queues themselves are per pseudo-channel (`rtl/sf_hbm_pseudochannel.sv`: `u_queue`).

## 2. Module hierarchy

```
sf_hbm4_controller                        rtl/sf_hbm4_controller.sv   top; params NUM_STACKS, NUM_CHANNELS, CH_PER_CLUSTER, DEPTH, CPL_DEPTH,
 |                                                                     TRK_SRC_W, TRK_ID_W, PHY_BACKEND, PHY_CMD_LAT, PHY_RD_LAT, WR_ACK_AT_DATA, NUM_MRS
 +- sf_hbm_init            u_init         bring-up sequencer
 +- sf_hbm_addr_map        u_map          combinational (uses sf_hbm_pkg::hbm_map_addr)
 +- sf_hbm_rsp_arb #(NCL+1) u_top_arb     N clusters + the local fence response
 +- sf_hbm_stack_cluster   g_cl[NCL]      NCH_CL channels + cluster arbiter
     +- sf_hbm_rsp_arb #(NCH) u_arb
     +- sf_hbm_channel     g_ch[NCH_CL]   2 pseudo-channels + channel arbiter
         +- sf_hbm_rsp_arb #(PCS) u_arb
         +- sf_hbm_pseudochannel g_pc[2]
             +- sf_hbm_req_queue    u_queue
             +- sf_hbm_bank_fsm     g_bank[16]
             +- sf_hbm_timing       u_timing
             +- sf_hbm_read_return  u_rr            (completion sequencer)
             +- sf_hbm_write_data   u_wd
             +- sf_hbm_refresh      u_ref
             +- sf_hbm_power_state  u_pwr
             +- sf_hbm_scheduler    u_sched
             +- sf_hbm_command_encoder u_enc
             +- sf_hbm_phy_adapter  u_phy
             +- sf_hbm_ecc_ras      u_ecc

Integration wrapper:
  sf_hbm_top = sf_hbm4_controller + sf_hbm_perf (counters) + sf_hbm_csr (register file), the block an SoC instantiates
Stand-alone blocks (not instantiated by the controller; used where two clock domains meet):
  sf_hbm_cdc_fifo, sf_hbm_rst_sync (both in rtl/sf_hbm_cdc_fifo.sv)
Packages: sf_hbm_pkg (types, pure functions), sf_hbm_profile_pkg (GENERATED from configs/timing/profiles.json by scripts/gen_profiles.py)
Include:  sf_hbm_geom.svh (geometry macros, overridable with -D)
```

Default top-level derived values (`rtl/sf_hbm4_controller.sv` localparams): `TOT_CH = NUM_STACKS*NUM_CHANNELS`, `NPC = TOT_CH*2`,
`NCH_CL = min(CH_PER_CLUSTER, TOT_CH)`, `NCL = TOT_CH/NCH_CL` (`TOT_CH % NCH_CL != 0` is an elaboration `$error`). With the defaults
(`NUM_CHANNELS=32`, `CH_PER_CLUSTER=8`): 4 clusters, 64 pseudo-channels. 1, 2, 4, 8 and 32 channels are exercised by `tb_ctrl_multi.sv`
builds (`scripts/regress.py`); "a reduced-channel configuration is a verification vehicle, not an HBM4 product".

Flat pseudo-channel index (used by `sim_*` bundles, `stat_o`, `inj_pc_i`): `((stack*NUM_CHANNELS)+ch)*2+pc`.

### 2.1 Clock and reset conventions

| item | convention | where |
|---|---|---|
| clock | one `clk_i` for the whole controller tree, the CSR block, the perf block, the NoC adapter and the DMA adapter; no clock is generated, divided or gated anywhere in HBMCore | every module has a single `clk_i` |
| reset | active-low `rst_ni`, **asynchronous assert** (`always_ff @(posedge clk_i or negedge rst_ni)`); everything returns to idle/empty | every sequential module header ("RESET: async assert") |
| reset release | not synchronised inside HBMCore: "synchronous release semantics are the integrator's responsibility" | `rtl/sf_hbm_bank_fsm.sv` header; `sf_hbm_rst_sync` exists but is instantiated nowhere (`CDC_AND_CLOCKS.md`) |
| enable | `ctrl_enable_i` of each pseudo-channel = `ready_o` of `sf_hbm_init`. While low the queue refuses requests (`req_ready_o = q_push_ready && ctrl_enable_i`), refresh is not started, the scheduler holds ACT and column commands (`hold_act`/`hold_col` include `!ctrl_enable_i`); only the init MRS port is serviced | `rtl/sf_hbm_pseudochannel.sv` |
| time base | each pseudo-channel owns a free-running 16-bit `cyc_q`; due times are modulo 2^16 (`HBM_CYC_W = 16`) | `rtl/sf_hbm_pseudochannel.sv`, `sf_hbm_pkg.sv` |
| PHY clock ratio | 1:1 with the controller clock; any other ratio is a PHY-contract item (`CDC_AND_CLOCKS.md`, `PHY_CONTRACT.md`) | `rtl/sf_hbm_phy_adapter.sv` |

Runtime configuration (`hbm_cfg_t`, `sf_hbm_pkg.sv`) is *quasi-static*: it is fed unregistered from `cfg_i` to all pseudo-channels. Changing it while
traffic is in flight is not guarded in RTL (`sf_hbm_csr` header: profile select "change only while idle").

## 3. Resource relationships inside one pseudo-channel

```
 accept (req_valid && q_push_ready && ctrl_enable)
   |-- slot s = lowest free index of sf_hbm_req_queue              (txn_q[s], age_q[s], dep_q[s][*], older_q[s][*])
   |-- data_q[s], mask_q[s] of sf_hbm_write_data written the same cycle (same index s)   -> "queue slot == write-data slot"
   |-- bytes_q[s] = popcount(wmask) (write) | 32 (read)
   v
 scheduler issues the column command of slot s at cycle t
   |-- slot s freed in the queue (rem_valid)                     BUT for a WR the slot stays HELD (hold_i = wd_slot_busy)
   |        until its data has been registered onto the PHY write-data bus at cycle t+WL  (sf_hbm_write_data busy_q)
   |-- completion entry allocated in sf_hbm_read_return at issue (credit_o low when CPL_DEPTH entries are in use)
   v
 read:  entry done <- PHY read return        write: entry done <- write-data engine wr_done pulse
   v
 response accepted by the consumer (rsp_valid && rsp_ready)  -> completion entry freed
```

| resource | allocated | freed | what stops the scheduler when exhausted |
|---|---|---|---|
| request-queue slot (`DEPTH`) | at accept, lowest free index not held | at column-command issue (or error-entry completion) *and*, for a write, only after its data left (`hold_i`) | `q_push_ready = 0` -> `req_ready_o = 0` |
| write-data slot | same index as the queue slot | when the data is registered onto the PHY bus (`pend_pop`) | no separate stall: the slot cannot be re-allocated, so a write cannot be accepted without its data slot |
| write pending FIFO (`PEND_DEPTH`) | at WR issue | at `t+WL` | `wr_credit_i = can_issue_o = 0` -> WR not legal |
| completion entry (`CPL_DEPTH`) | at column / error issue | when the response is accepted | `cpl_credit_i = 0` -> no column command, no error completion is legal |
| PHY ready | combinational | -- | `phy_ready_i = 0` -> no ACT/RD/WR/PRE/PREA/REF/MRS/PDE/SRE (PDX/SRX are exempt, `sf_hbm_scheduler.sv` `mnt_leg`) |

Consequences (all visible in the code): (1) a queue/data deadlock is impossible because they are one resource;
(2) PHY read data never needs back-pressure because the completion entry is reserved before the command leaves, so a stalled response
consumer cannot lose data (`sf_hbm_read_return.sv` header); (3) each pseudo-channel returns responses in column-command *issue* order
(completion buffer is a FIFO), while the queue may issue commands out of acceptance order; the same-{src,id} and hazard order is held by the dependency
matrix (`SCHEDULER.md` section 6, `ORDERING.md`).

## 4. Ingress modes

| mode | where it exists | limit | what it bypasses |
|---|---|---|---|
| **Single host port** | RTL: `sf_hbm4_controller` request port (`req_valid_i/req_ready_o` + one `req_*` payload) | at most **one granule request accepted per cycle** (one 32 B granule, `HBM_GRAN_BYTES`) for the whole stack, independent of `NUM_CHANNELS`; `req_ready_o` may depend on the payload (target queue full, ID tracker busy) | nothing; this is the full ingress path (address map, checks, ID tracker, fence, init gating) |
| **Channel-sliced ingress** | **Testbench construct only**: `verification/tests/tb_bench.sv` with `PORTS=1` instantiates one `sf_hbm_pseudochannel` per pseudo-channel directly and drives its `req_*` port | one request port per pseudo-channel, i.e. up to one granule per cycle per pseudo-channel | `sf_hbm4_controller` entirely: no `sf_hbm_addr_map` RTL (the testbench calls `hbm_map_addr` itself), no error entries, no ID tracker, no fence, no `sf_hbm_init` (`ctrl_enable_i = 1`, `init_mrs_valid_i = 0`), response port tied ready |

Why it matters: the aggregate service rate of `NPC` pseudo-channels is bounded by their DRAM-side timing, whereas the single port feeds
at most 32 B per controller clock cycle. Any bandwidth figure for a many-channel configuration is therefore only attributable to the memory
side if it was measured with sliced ingress; a figure measured through the single port is ingress-limited by construction.
`tb_bench.sv` header: "PORTS=0 the single host port of sf_hbm4_controller (<= 1 granule / cycle = 32 B/cycle): shows the ingress limit".
**No synthesizable channel-sliced ingress module exists in `rtl/`**: a fabric that feeds several pseudo-channels per cycle would need
an RTL front end that replaces `sf_hbm4_controller`'s single port (address map, ID tracker and fence are per-port today). That is an
integration blocker, listed in `INTEGRATION_BLOCKERS.md`.

Measured throughput of both modes: <!-- RESULTS: filled in by scripts/make_report.py -->

## 5. What is shared across pseudo-channels

**Nothing but the response arbiters.** Each pseudo-channel owns its queue, bank machines, timing counters, scheduler, refresh engine,
power sequencer, completion sequencer, write-data buffer, ECC/RAS block and PHY-adapter instance
(`rtl/sf_hbm_channel.sv` header: "The two pseudo-channels share NOTHING except the response port"). Independent command scheduling per
pseudo-channel, with no shared command bus, is an `ENGINEERING_ASSUMPTION` (`STANDARDS_MATRIX.md` ARCH-07/ARCH-08; whether a real channel shares a command bus is unknown here).

| shared element | what is shared | where |
|---|---|---|
| response arbiters | 2-input (channel), `NCH`-input (cluster), `NCL+1`-input (top, the extra input is the fence response); round-robin with grant locking (payload held until accepted) | `sf_hbm_rsp_arb.sv`; formal harness `verification/formal/fv_rsp_arb.sv` |
| broadcast configuration (read-only inputs, not shared *state*) | `tp_i`, `sched_cfg_i`, `ref_cfg_i`, `ecc_en_i`, `ctrl_enable_i`, `pwr_req_i`, `pd_idle_i`, `sr_idle_i`, `ecc_clear_i`, `inj_mode_i`, `inj_bit_i` | top -> cluster -> channel -> pseudo-channel |
| init MRS broadcast | one `{valid, code}` broadcast; the sequencer advances when **every** pseudo-channel acknowledges (`init_mrs_ack = &cl_mrs_ack`) | `sf_hbm4_controller.sv`, `sf_hbm_stack_cluster.sv`, `sf_hbm_channel.sv` |
| request payload bus | the one `req_txn_i/req_wdata_i/req_wmask_i` payload fans out to every pseudo-channel; only the addressed one gets `valid` | `sf_hbm_stack_cluster.sv`, `sf_hbm_channel.sv` |

Not shared: refresh. There is no cross-pseudo-channel refresh coordination or staggering in RTL; every `sf_hbm_refresh` instance starts its
interval counter at reset, so identical configurations tick in lock-step. (Whether staggering matters for a real device is outside this repository.)

## 6. Per-module summary

| module | one-paragraph description |
|---|---|
| `sf_hbm_pkg` | Types (`hbm_txn_t`, `hbm_cmd_t`, `hbm_rsp_t`, `hbm_ctx_t`, `hbm_pc_evt_t`, `hbm_pc_stat_t`, `hbm_cfg_t`, `hbm_timing_t`), enums (error codes `hbm_err_e`, ordering `hbm_order_e`, abstract commands `hbm_cmd_e`, policies), and pure functions: `hbm_ld/hbm_dec16/hbm_max16`, `hbm_conflict` (ordering rule), `hbm_map_addr/hbm_unmap_loc` (the single definition of the address map). No sequential logic. |
| `sf_hbm_profile_pkg` | Generated. `hbm_profile(sel)` returns the `hbm_timing_t` of one of three profiles (`sim_fast`, `sim_ref`, `sim_strict`), `hbm_profile_status` (all 0 = HYPOTHETICAL_SIM), `hbm_profile_pb_ok` (per-bank refresh feasibility rule). |
| `sf_hbm4_controller` | Top. Bring-up gating, address map, ingress error checks, same-ID tracker, fence, cluster steering, top response arbiter. Exposes the single host port, per-pseudo-channel `sim_*` PHY-side bundles and `stat_o` observability. |
| `sf_hbm_init` | Controller-side bring-up sequence `RESET -> PWR -> CLK -> PHY -> MRS(NUM_MRS) -> TRAIN -> READY`, per-state timeout to `ERR` with a cause code; PHY init and training are external handshakes (`phy_init_start_o/done_i`, `train_start_o/done_i`). MRS operands are placeholders (`INIT-02`). |
| `sf_hbm_addr_map` | Combinational wrapper over `hbm_map_addr`: location, flat pseudo-channel index, RANGE/MISALIGN flags. Parameter checks for power-of-two counts and capacity. |
| `sf_hbm_stack_cluster` | Group of `NCH` channels + one response arbiter; steers a request by local `{ch,pc}`; ANDs the MRS acks. A physical-partitioning convenience, no behaviour of its own. |
| `sf_hbm_channel` | Two pseudo-channels + response arbiter; packs `hbm_pc_stat_t`. Leaves the per-PC RAS counters, `res_*` residency counters and debug command port unconnected. |
| `sf_hbm_pseudochannel` | One independently scheduled 32-DQ pseudo-channel controller (16 banks at the default geometry): wires queue, bank FSMs, timing, scheduler, refresh, power, init MRS, write data, read return, ECC, encoder and PHY adapter; builds event pulses and simulation-time assertions. |
| `sf_hbm_req_queue` | `DEPTH` slots + age matrix + dependency matrix (ordering scoreboard) + saturating age counters + occupancy. |
| `sf_hbm_scheduler` | Combinational one-command-per-cycle selection among maintenance, demand and proactive precharge; tiered priority; registered state only for batching, idle timers and row-hit accounting. |
| `sf_hbm_bank_fsm` | One bank: `row_open`, open row, bank-local down-counters (tRCD, tRAS, tRC, tRP, tRTP, WL+burst+tWR, tRFC/tRFCpb), legality outputs and a violation pulse. |
| `sf_hbm_timing` | Cross-bank rules: tRRD_S/L, tFAW (4 sliding counters), tCCD_S/L, WR->RD, RD->WR, tRFC, tMRD, tXP/tXS gate. |
| `sf_hbm_refresh` | Debt-based refresh manager (all-bank or per-bank), postpone/pull-in bounded by profile fields, emits maintenance commands and hold signals. |
| `sf_hbm_power_state` | Power-state sequencer `ACTIVE/PREP/ENTER/PD|SR/EXIT/WAKE` (`POWER.md`). |
| `sf_hbm_write_data` | Write-data buffer indexed by the queue slot, pending FIFO, exact `WL` delivery, slot hold, write completion policy. |
| `sf_hbm_read_return` | Completion sequencer: circular buffer in issue order, credit, read-return matching with exact-cycle check, timeout to `HERR_FLUSHED`. |
| `sf_hbm_command_encoder` | Abstract pass-through plus one register stage; `ENCODING != 0` is a build error by design. |
| `sf_hbm_phy_adapter` | Controller/PHY boundary: BACKEND 0 simulation pipeline (fixed latencies), BACKEND 1 stub (`PHY_CONTRACT.md`). |
| `sf_hbm_ecc_ras` | Controller SECDED (265,256)+parity encode/decode, counters, first-error log, one-shot fault injection (`RAS.md`). |
| `sf_hbm_rsp_arb` | N-to-1 round-robin response arbiter with grant locking. |
| `sf_hbm_csr` | 32-bit register window (`rb_*` bus) producing `hbm_cfg_t` and control pulses (`PERF_COUNTERS.md` section 6). |
| `sf_hbm_perf` | Per-pseudo-channel and aggregate counters with saturation, snapshot, freeze (`PERF_COUNTERS.md`). |
| `sf_hbm_cdc_fifo`, `sf_hbm_rst_sync` | Gray-code dual-clock FIFO; two-flop reset synchroniser (`CDC_AND_CLOCKS.md`). |
| `sf_hbm_datafabric` | NoC memory-node adapter (`DATAFABRIC.md`). |
| `sf_hbm_dma_adapter` | Descriptor DMA between HBM (through the NoC adapter) and the on-chip scratchpad (`DATAFABRIC.md` section 8). |

Full per-module contracts: `MODULES.md`.

## 7. Top-level ingress behaviour (as implemented)

* `req_ready_o = ready_o && (req_fence_i ? fence_ok : (trk_ok && pc_ready_sel))` (`sf_hbm4_controller.sv`). Nothing is accepted before `sf_hbm_init` reaches `READY`
  (`tb_ctrl_multi.sv`, test `init_sequence_gating`, checks "request accepted before init complete").
* Invalid address (RANGE or MISALIGN) -> error entry, steered to pseudo-channel 0; partial write (`wmask != '1`) with `cfg_i.ecc_en` -> `HERR_POLICY`,
  steered by its (valid) address. An error entry occupies a queue slot, takes part in ordering, consumes a completion credit and
  returns an ordinary response with its `err`; it issues no DRAM command (`sf_hbm_scheduler.sv` `is_err`).
* Same-`{src,id}` tracker: a table indexed by `{src[TRK_SRC_W-1:0], id[TRK_ID_W-1:0]}` (defaults 2 and 4 bits) counts outstanding requests (8-bit counters) and remembers the
  pseudo-channel; a new request is held back if the entry is busy on a *different* pseudo-channel, or the counter is saturated. Aliasing can only add stalls.
* Fence: accepted only when `outst_q == 0` and no fence response is pending; completes at once with a `write=1, err=NONE` response from a local register that
  competes in the top arbiter (`ORDERING.md`, rule 7).
* Hazard ordering within a pseudo-channel is done by the queue, not the top (`ORDERING.md`, rules 4 and 6).

## 8. Verification map (names that exist)

| layer | testbench / tool | what it exercises |
|---|---|---|
| one pseudo-channel | `verification/tests/tb_pc_single.sv` (tests `single_read`, `single_write`, `write_readback`, `sequential`, `partial`, `hazards`, `random`, `random_hot`, `policy`, `backpressure`, `saturation`, `refresh`, `ecc`, `refmodes`, `power`, `reset`) | legality against `hbm4_dram_model`, byte-accurate scoreboard, same-ID order, one response per request |
| bank/cross-bank timing | `verification/tests/tb_timing_rules.sv` | legal and one-cycle-short schedules against three independent judges |
| controller | `verification/tests/tb_ctrl_multi.sv` (tests `init`, `basic`, `random`, `maps`, `errors`, `ecc_policy`, `fence`, `same_id`, `isolation`, `backpressure`, `reset`, `perf`) | mapping/isolation, ordering, errors, perf-counter cross-check |
| NoC adapter / DMA | `tb_datafabric.sv`, `tb_dma_spm.sv` | `DATAFABRIC.md` |
| CDC | `tb_cdc_fifo.sv` | `CDC_AND_CLOCKS.md` |
| benchmarks | `tb_bench.sv`, `scripts/run_benchmarks.sh` | modelled numbers only; <!-- RESULTS: filled in by scripts/make_report.py --> |
| Python reference | `python/tests/*.py` (built from the normative docs only, "never looked at the RTL") | independent trace checker, address map, SECDED, scoreboard, performance model |
| formal | `verification/formal/fv_bank_fsm.sv`, `fv_read_return.sv`, `fv_req_queue.sv`, `fv_rsp_arb.sv` | see `docs/FORMAL.md` (maintained separately) |
| mutation | `scripts/mutation_check.sh` -> `reports/mutation_report.json` | injects single bugs into a scratch copy of the RTL; every mutant must be killed |

Results of these runs are produced by `scripts/regress.py` (`reports/regression.*`, generated); this document does not restate pass counts.
