// =============================================================================
//  SILICAFLUX HBMCORE  --  integration/datafabric/sf_hbm_datafabric.sv
//  Memory-side network interface of the SilicaFlux DataFabric NoC v2 for an HBMCore controller.
//
//  CONTRACT USED: SF-NOC packet contract v1 (noc_packet_t, silicaflux_pkg; vendored unmodified in
//  third_party/noc_v2, checksummed). This block plays the role of `sf_noc_mem_target_ni` for the HBM:
//
//      request  network ---> [ request FIFO ] -> ingest -> HBM granule requests (sf_hbm4_controller host port)
//      response network <--- [ reorder buffer, in request order ] <- HBM granule responses (any order)
//
//  SUPPORTED TRAFFIC (xfer / class)
//    SCALAR  RD_REQ/WR_REQ  4 B word, word aligned     -> one granule read / masked write
//    VECTOR  RD_REQ/WR_REQ  16 B line, 16 B aligned    -> one granule read / masked write (one half of a 32 B granule)
//    BURST   RD_REQ  (1 descriptor flit)   len_m1+1 beats of 16 B -> len_m1+1 response flits (sop..eop)
//            WR_REQ  (descriptor + beats)  completion = one WR_RSP, data[8:0] = beats committed
//            Two beats that form one aligned 32 B granule are fused into ONE granule access (read or write).
//    CTRL    answered with SF_MEM_EXC_RANGE (HBM has no control window behind this NI; CSRs use sf_hbm_csr)
//    MSG / response classes / !valid : dropped (ev_drop_o), as in the existing target NI.
//
//  ERRORS (silicaflux_pkg::sf_mem_exc_e, copied unchanged from the HBM response): MISALIGN (SCALAR addr[1:0],
//  VECTOR/BURST addr[3:0] != 0), BURST_LEN (len_m1 > max_burst_m1_i; the beats that follow are drained), RANGE
//  (outside HBM capacity or CTRL), ECC (poisoned data). An error completion carries be = 0 and no data.
//  Burst-read error semantics: every flit whose granule failed becomes an error flit (be=0, status=err);
//  the NoC contract says "an error completion carries no data" and does not define a burst-read error beat count -
//  documented limitation (docs/DATAFABRIC.md).
//
//  ADDRESSING: the NoC address is 32 bit (SF_PADDR_W). HBM stacks are larger, so the address is EXTENDED:
//  hbm_addr = { addr_hi_i, noc.addr[31:0] } (addr_hi_i from a CSR). That is an INTEGRATION BLOCKER for a flat
//  32-bit memory map (docs/INTEGRATION_BLOCKERS.md): one NI instance sees one 4 GiB window of the stack.
//
//  OWNERSHIP / ORDERING
//    * Every NoC request gets its response in REQUEST ORDER through a flit-level reorder buffer (ROB), carrying
//      the original src_id/dst_id swap, txn_id, addr, xfer, hint, qos (sf_noc_make_rsp). So a response can only ever
//      go to the tile that sent the request, with that tile's txn_id.
//    * Each granule request gets a UNIQUE tag (HBM id field); tags map to ROB slots. The HBM-side source id is the
//      constant HBM_SRC; the controller's own same-ID tracker therefore never serialises unrelated requests.
//  DEADLOCK SAFETY: HBM responses are always accepted (h_rsp_ready_o = 1: every response has a pre-reserved ROB slot),
//  so the HBM side can never block on this block; the ROB drains onto the response network, which the NoC contract
//  guarantees to drain (requesters reserve response buffers). Request->response dependency is therefore acyclic.
//  LIMITS: one burst-write context (a second burst write waits until the first completes), one burst-read context.
//  RESET: async assert; everything empty.
// =============================================================================
module sf_hbm_datafabric
  import sf_hbm_pkg::*;
  import silicaflux_pkg::*;
#(
  parameter int unsigned REQ_DEPTH = 4,
  parameter int unsigned ROB_N     = 64,
  parameter int unsigned NTAG      = 64,
  parameter int unsigned HBM_SRC   = 0
) (
  input  logic                clk_i,
  input  logic                rst_ni,

  // ---- NoC side (this block is the target NI of one memory node) ----
  input  logic                req_valid_i,
  output logic                req_ready_o,
  input  noc_packet_t         req_pkt_i,
  output logic                rsp_valid_o,
  input  logic                rsp_ready_i,
  output noc_packet_t         rsp_pkt_o,

  // ---- configuration ----
  input  logic [7:0]          addr_hi_i,          // address bits [39:32] of the HBM byte address
  input  logic [7:0]          max_burst_m1_i,

  // ---- HBM granule interface (sf_hbm4_controller host port) ----
  output logic                h_req_valid_o,
  input  logic                h_req_ready_i,
  output hbm_addr_t           h_req_addr_o,
  output logic                h_req_write_o,
  output hbm_id_t             h_req_id_o,
  output hbm_src_t            h_req_src_o,
  output hbm_qos_t            h_req_qos_o,
  output hbm_data_t           h_req_wdata_o,
  output hbm_mask_t           h_req_wmask_o,
  input  logic                h_rsp_valid_i,
  output logic                h_rsp_ready_o,
  input  hbm_rsp_t            h_rsp_i,

  output logic                ev_drop_o,
  output logic                ev_err_rsp_o
);
  localparam int unsigned RW = $clog2(ROB_N);
  localparam int unsigned TW = $clog2(NTAG);

  // --------------------------------------------------------------------------
  // request FIFO
  // --------------------------------------------------------------------------
  noc_packet_t fifo_q [REQ_DEPTH];
  logic [$clog2(REQ_DEPTH)-1:0] f_wp, f_rp;
  logic [$clog2(REQ_DEPTH):0]   f_cnt;
  wire  f_push = req_valid_i && req_ready_o;
  assign req_ready_o = (f_cnt != ($clog2(REQ_DEPTH)+1)'(REQ_DEPTH));
  wire  head_v = (f_cnt != '0);
  noc_packet_t head;
  assign head = fifo_q[f_rp];

  // --------------------------------------------------------------------------
  // reorder buffer + tags
  // --------------------------------------------------------------------------
  noc_packet_t rob_pkt [ROB_N];
  logic [ROB_N-1:0] rob_done;
  logic [RW-1:0]    rob_head, rob_tail;
  logic [RW:0]      rob_cnt;
  wire [RW:0]       rob_free = (RW+1)'(ROB_N) - rob_cnt;

  logic [NTAG-1:0]  tag_busy;
  logic [RW-1:0]    tag_slot [NTAG];
  logic [1:0]       tag_kind [NTAG];       // 0 read one flit, 1 read two flits, 2 single write, 3 granule of a burst write
  logic [2:0]       tag_sub  [NTAG];       // read one flit: [2]=half (vector/burst) ; scalar word index in [2:0]
  logic             tag_scal [NTAG];
  logic [TW-1:0]    tag_idx, tag_low;
  logic             tag_free, tag_low_free;
  // v2 (independent review C4): the request ID must be STABLE while h_req_valid_o && !h_req_ready_i. The lowest free
  // tag is combinational and a response that frees a lower tag used to change the ID mid-handshake. The offered tag is
  // now held until the handshake (it stays free: only this block's own h_fire allocates a tag).
  logic             id_hold_q;
  logic [TW-1:0]    id_q;
  always_comb begin
    tag_low_free = 1'b0; tag_low = '0;
    for (int t = NTAG-1; t >= 0; t--) if (!tag_busy[t]) begin tag_low_free = 1'b1; tag_low = TW'(t); end
    tag_free = id_hold_q || tag_low_free;
    tag_idx  = id_hold_q ? id_q : tag_low;
  end

  // burst contexts
  typedef enum logic [2:0] {S_IDLE, S_BRD, S_BWR, S_DRAIN} st_e;
  st_e          st_q;
  noc_packet_t  ctx_desc;
  hbm_addr_t    ctx_base;
  logic [8:0]   ctx_len, ctx_beat, ctx_drain;
  logic [RW-1:0] ctx_slot;                 // BRD: first flit slot ; BWR: the WR_RSP slot
  logic         hold_v;
  logic [127:0] hold_data;
  logic [15:0]  hold_be;
  logic         bw_fin_q;                  // all granules of the burst write issued; waiting for the last responses
  logic [RW-1:0] bw_slot_q;
  logic [7:0]   bw_issued_q, bw_acked_q;     // granules issued / acknowledged of the current burst write
  sf_mem_exc_e  bw_status_q;
  
  // --------------------------------------------------------------------------
  // decode of the FIFO head
  // --------------------------------------------------------------------------
  hbm_addr_t  h_addr;
  assign h_addr = {addr_hi_i, head.addr};
  wire is_rd   = (head.pclass == SF_NOC_RD_REQ);
  wire is_wr   = (head.pclass == SF_NOC_WR_REQ);
  wire is_req  = head.valid && (is_rd || is_wr);

  // outputs of the combinational control
  logic        pop_f;
  logic        h_v;
  hbm_addr_t   h_a;  logic h_w;  hbm_data_t h_d;  hbm_mask_t h_m;  hbm_qos_t h_q;
  logic        h_fire;
  logic [1:0]  new_kind;  logic [2:0] new_sub;  logic new_scal;
  logic [RW:0] alloc_n;                         // ROB slots allocated this cycle
  logic        alloc_err;                       // single-slot immediate error completion
  sf_mem_exc_e alloc_exc;
  logic        start_brd, start_bwr, start_drain;
  logic        ev_drop_c;
  logic        issue_adv1, issue_adv2;          // burst: beats consumed by the granule issued this cycle
  logic        pop_hold_only;                   // burst write: beat parked in the hold register (no issue)

  wire [8:0] desc_len  = {1'b0, head.data[7:0]} + 9'd1;
  // at most 32 beats (the ROB allocation loop is unrolled to 32) and never more than the ROB can hold
  wire       desc_bad_len = (head.data[7:0] > max_burst_m1_i) || (head.data[7:0] > 8'd31) || (desc_len > 9'(ROB_N));

  always_comb begin
    pop_f = 1'b0; h_v = 1'b0; h_a = '0; h_w = 1'b0; h_d = '0; h_m = '0; h_q = head.qos;
    new_kind = '0; new_sub = '0; new_scal = 1'b0; alloc_n = '0; alloc_err = 1'b0; alloc_exc = SF_MEM_EXC_NONE;
    start_brd = 1'b0; start_bwr = 1'b0; start_drain = 1'b0; ev_drop_c = 1'b0;
    issue_adv1 = 1'b0; issue_adv2 = 1'b0; pop_hold_only = 1'b0;

    case (st_q)
      // ---------------------------------------------------------------- idle: decode the next request
      S_IDLE: if (head_v) begin
        if (!is_req) begin
          pop_f = 1'b1; ev_drop_c = 1'b1;                                   // MSG / response class / !valid
        end else begin
          case (head.xfer)
            SF_NOC_X_CTRL: if (rob_free >= 1) begin
              pop_f = 1'b1; alloc_n = 1; alloc_err = 1'b1; alloc_exc = SF_MEM_EXC_RANGE;
            end
            SF_NOC_X_SCALAR: if (rob_free >= 1) begin
              if (head.addr[1:0] != 2'b00) begin
                pop_f = 1'b1; alloc_n = 1; alloc_err = 1'b1; alloc_exc = SF_MEM_EXC_MISALIGN;
              end else if (tag_free) begin
                h_v = 1'b1; h_a = {h_addr[HBM_ADDR_W-1:HBM_OFF_W], 5'b0}; h_w = is_wr;
                h_d = hbm_data_t'(head.data[31:0]) << (32 * head.addr[4:2]);
                h_m = hbm_mask_t'(head.be[3:0]) << (4 * head.addr[4:2]);
                new_kind = is_wr ? 2'd2 : 2'd0; new_sub = head.addr[4:2]; new_scal = 1'b1;
                if (h_req_ready_i) begin alloc_n = 1; pop_f = 1'b1; end
              end
            end
            SF_NOC_X_VECTOR: if (rob_free >= 1) begin
              if (head.addr[3:0] != 4'h0) begin
                pop_f = 1'b1; alloc_n = 1; alloc_err = 1'b1; alloc_exc = SF_MEM_EXC_MISALIGN;
              end else if (tag_free) begin
                h_v = 1'b1; h_a = {h_addr[HBM_ADDR_W-1:HBM_OFF_W], 5'b0}; h_w = is_wr;
                h_d = hbm_data_t'(head.data) << (128 * head.addr[4]);
                h_m = hbm_mask_t'(head.be) << (16 * head.addr[4]);
                new_kind = is_wr ? 2'd2 : 2'd0; new_sub = {head.addr[4], 2'b00};
                if (h_req_ready_i) begin alloc_n = 1; pop_f = 1'b1; end
              end
            end
            default: begin   // BURST
              if (!head.sop) begin
                pop_f = 1'b1; ev_drop_c = 1'b1;                              // stray beat
              end else if (head.addr[3:0] != 4'h0 || desc_bad_len) begin
                if (rob_free >= 1) begin
                  pop_f = 1'b1; alloc_n = 1; alloc_err = 1'b1;
                  alloc_exc = desc_bad_len ? SF_MEM_EXC_BURST_LEN : SF_MEM_EXC_MISALIGN;
                  if (is_wr) start_drain = 1'b1;                              // swallow the beats of a rejected write
                end
              end else if (is_rd) begin
                if (rob_free >= desc_len[RW:0]) begin pop_f = 1'b1; alloc_n = (RW+1)'(desc_len); start_brd = 1'b1; end
              end else begin
                if (rob_free >= 1 && !bw_fin_q) begin pop_f = 1'b1; alloc_n = 1; start_bwr = 1'b1; end
              end
            end
          endcase
        end
      end
      // ---------------------------------------------------------------- burst read: one granule per step
      S_BRD: if (tag_free) begin
        hbm_addr_t ba;  logic hb;  logic two;
        ba  = ctx_base + hbm_addr_t'({ctx_beat, 4'b0000});
        hb  = ba[4];
        two = !hb && (ctx_beat + 9'd1 < ctx_len);
        h_v = 1'b1; h_a = {ba[HBM_ADDR_W-1:HBM_OFF_W], 5'b0}; h_w = 1'b0; h_q = ctx_desc.qos;
        new_kind = two ? 2'd1 : 2'd0; new_sub = {hb, 2'b00};
        issue_adv1 = h_req_ready_i && !two; issue_adv2 = h_req_ready_i && two;
      end
      // ---------------------------------------------------------------- burst write: fuse beat pairs
      S_BWR: if (head_v && head.valid) begin
        hbm_addr_t ba;  logic hb;  logic two;
        ba  = ctx_base + hbm_addr_t'({ctx_beat, 4'b0000});
        hb  = ba[4];
        two = !hb && (ctx_beat + 9'd1 < ctx_len);
        h_q = ctx_desc.qos;
        if (two && !hold_v) begin
          pop_f = 1'b1; pop_hold_only = 1'b1;                                // park beat b, wait for beat b+1
        end else if (tag_free) begin
          h_v = 1'b1; h_a = {ba[HBM_ADDR_W-1:HBM_OFF_W], 5'b0}; h_w = 1'b1;
          if (two) begin h_d = {head.data, hold_data}; h_m = {head.be, hold_be}; end
          else     begin h_d = hbm_data_t'(head.data) << (128 * hb); h_m = hbm_mask_t'(head.be) << (16 * hb); end
          new_kind = 2'd3; new_sub = '0;                                      // kind 3 = one granule of a burst write
          if (h_req_ready_i) begin pop_f = 1'b1; issue_adv1 = !two; issue_adv2 = two; end
        end
      end
      // ---------------------------------------------------------------- drain the beats of a rejected burst write
      S_DRAIN: if (head_v) pop_f = 1'b1;
      default: ;
    endcase
  end

  assign h_fire        = h_v && h_req_ready_i;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin id_hold_q <= 1'b0; id_q <= '0; end
    else begin
      id_hold_q <= h_v && !h_req_ready_i;
      if (h_v && !h_req_ready_i) id_q <= tag_idx;
    end
  end
`ifndef SYNTHESIS
  logic          pv_q;
  hbm_id_t       pid_q;
  always_ff @(posedge clk_i) begin
    if (rst_ni && pv_q && h_v && (h_req_id_o != pid_q))
      $error("[%m] h_req_id_o changed while valid && !ready (%0d -> %0d)", pid_q, h_req_id_o);
    pv_q <= rst_ni && h_v && !h_req_ready_i; pid_q <= h_req_id_o;
  end
`endif
  assign h_req_valid_o = h_v;
  assign h_req_addr_o  = h_a;
  assign h_req_write_o = h_w;
  assign h_req_id_o    = hbm_id_t'(tag_idx);
  assign h_req_src_o   = hbm_src_t'(HBM_SRC);
  assign h_req_qos_o   = h_q;
  assign h_req_wdata_o = h_d;
  assign h_req_wmask_o = h_m;
  assign h_rsp_ready_o = 1'b1;
  assign ev_drop_o     = ev_drop_c;

  // --------------------------------------------------------------------------
  // HBM response handling (combinational lookup, applied in the clocked block)
  // --------------------------------------------------------------------------
  wire [TW-1:0]  r_tag   = h_rsp_i.id[TW-1:0];
  wire [RW-1:0]  r_slot  = tag_slot[r_tag];
  wire [RW-1:0]  r_slot1 = (r_slot == RW'(ROB_N-1)) ? '0 : (r_slot + 1'b1);
  wire           r_err   = (h_rsp_i.err != HERR_NONE);
  sf_mem_exc_e   r_exc;
  assign r_exc = sf_mem_exc_e'(h_rsp_i.err);

  // --------------------------------------------------------------------------
  // sequential state
  // --------------------------------------------------------------------------
  wire rsp_pop = rsp_valid_o && rsp_ready_i;
  assign rsp_valid_o = (rob_cnt != '0) && rob_done[rob_head];
  assign rsp_pkt_o   = rob_pkt[rob_head];

  function automatic logic [RW-1:0] radd(input logic [RW-1:0] a, input int unsigned n);
    return RW'((int'(a) + int'(n)) % ROB_N);
  endfunction

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      f_wp <= '0; f_rp <= '0; f_cnt <= '0;
      rob_done <= '0; rob_head <= '0; rob_tail <= '0; rob_cnt <= '0;
      tag_busy <= '0; st_q <= S_IDLE; hold_v <= 1'b0; bw_fin_q <= 1'b0; bw_slot_q <= '0;
      ctx_beat <= '0; ctx_len <= '0; ctx_slot <= '0; ctx_drain <= '0; ctx_base <= '0; ctx_desc <= '0;
      hold_data <= '0; hold_be <= '0; ev_err_rsp_o <= 1'b0;
      for (int i = 0; i < ROB_N; i++) begin rob_pkt[i] <= '0; end
      bw_issued_q <= '0; bw_acked_q <= '0; bw_status_q <= SF_MEM_EXC_NONE;
    end else begin
      ev_err_rsp_o <= 1'b0;
      // ---- request FIFO
      if (f_push) begin fifo_q[f_wp] <= req_pkt_i; f_wp <= (f_wp == $bits(f_wp)'(REQ_DEPTH-1)) ? '0 : f_wp + 1'b1; end
      if (pop_f)  begin f_rp <= (f_rp == $bits(f_rp)'(REQ_DEPTH-1)) ? '0 : f_rp + 1'b1; end
      case ({f_push, pop_f})
        2'b10: f_cnt <= f_cnt + 1'b1;
        2'b01: f_cnt <= f_cnt - 1'b1;
        default: ;
      endcase

      // ---- ROB allocation
      if (alloc_n != '0) begin
        if (alloc_err) begin
          rob_pkt[rob_tail]  <= sf_noc_make_rsp(head, '0, '0, alloc_exc);
          rob_done[rob_tail] <= 1'b1;
          ev_err_rsp_o <= 1'b1;
        end else if (start_brd) begin
          for (int i = 0; i < 32; i++) begin
            if (i < int'(alloc_n)) begin
              noc_packet_t fp;
              fp = sf_noc_make_rsp(head, '0, '0, SF_MEM_EXC_NONE);
              fp.addr = head.addr + sf_paddr_t'(16 * i);
              fp.sop  = (i == 0);
              fp.eop  = (i == int'(alloc_n) - 1);
              rob_pkt[radd(rob_tail, i)]  <= fp;
              rob_done[radd(rob_tail, i)] <= 1'b0;
            end
          end
        end else begin
          noc_packet_t np;
          np = sf_noc_make_rsp(head, '0, '0, SF_MEM_EXC_NONE);
          if (start_bwr) np.data = sf_noc_data_t'(desc_len);                    // beats committed (final value)
          rob_pkt[rob_tail]  <= np;
          rob_done[rob_tail] <= 1'b0;
        end
        rob_tail <= radd(rob_tail, int'(alloc_n));
      end
      case ({alloc_n != '0, rsp_pop})
        2'b10: rob_cnt <= rob_cnt + alloc_n;
        2'b11: rob_cnt <= rob_cnt + alloc_n - 1'b1;
        2'b01: rob_cnt <= rob_cnt - 1'b1;
        default: ;
      endcase
      if (rsp_pop) begin rob_done[rob_head] <= 1'b0; rob_head <= radd(rob_head, 1); end

      // ---- state machine / contexts
      if (start_brd)   begin st_q <= S_BRD; ctx_desc <= head; ctx_base <= h_addr; ctx_len <= desc_len; ctx_beat <= '0; ctx_slot <= rob_tail; end
      if (start_bwr)   begin st_q <= S_BWR; ctx_desc <= head; ctx_base <= h_addr; ctx_len <= desc_len; ctx_beat <= '0; ctx_slot <= rob_tail;
                             hold_v <= 1'b0; bw_slot_q <= rob_tail; bw_issued_q <= '0; bw_acked_q <= '0; bw_status_q <= SF_MEM_EXC_NONE; end
      if (start_drain) begin st_q <= S_DRAIN; ctx_drain <= {1'b0, head.data[7:0]} + 9'd1; end

      if (st_q == S_DRAIN && pop_f) begin
        ctx_drain <= ctx_drain - 9'd1;
        if (ctx_drain == 9'd1) st_q <= S_IDLE;
      end
      if (pop_hold_only) begin hold_v <= 1'b1; hold_data <= head.data; hold_be <= head.be; end

      // ---- granule issue bookkeeping
      if (h_fire) begin
        tag_busy[tag_idx] <= 1'b1;
        tag_kind[tag_idx] <= new_kind;
        tag_sub[tag_idx]  <= new_sub;
        tag_scal[tag_idx] <= new_scal;
        case (st_q)
          S_IDLE: tag_slot[tag_idx] <= rob_tail;                              // single flit: the slot allocated this cycle
          S_BRD:  tag_slot[tag_idx] <= radd(ctx_slot, int'(ctx_beat));
          default: tag_slot[tag_idx] <= ctx_slot;                             // S_BWR
        endcase
        if (st_q == S_BWR) bw_issued_q <= bw_issued_q + 8'd1;
      end
      if (issue_adv1 || issue_adv2) begin
        logic [8:0] nb;
        nb = ctx_beat + (issue_adv2 ? 9'd2 : 9'd1);
        ctx_beat <= nb;
        if (st_q == S_BWR) hold_v <= 1'b0;
        if (nb >= ctx_len) begin
          st_q <= S_IDLE;
          if (st_q == S_BWR) bw_fin_q <= 1'b1;
        end
      end

      // ---- HBM response -> ROB
      if (h_rsp_valid_i) begin
        tag_busy[r_tag] <= 1'b0;
        case (tag_kind[r_tag])
          2'd0: begin   // one read flit
            noc_packet_t p;
            p = rob_pkt[r_slot];
            if (r_err) begin p.status = r_exc; p.be = '0; p.data = '0; end
            else if (tag_scal[r_tag]) begin p.data = sf_noc_data_t'(h_rsp_i.data[32*tag_sub[r_tag] +: 32]); p.be = 16'h000F; end
            else begin p.data = h_rsp_i.data[128*tag_sub[r_tag][2] +: 128]; p.be = 16'hFFFF; end
            rob_pkt[r_slot] <= p; rob_done[r_slot] <= 1'b1;
          end
          2'd1: begin   // two read flits from one granule
            noc_packet_t p0, p1;
            p0 = rob_pkt[r_slot];  p1 = rob_pkt[r_slot1];
            if (r_err) begin p0.status = r_exc; p0.be = '0; p0.data = '0; p1.status = r_exc; p1.be = '0; p1.data = '0; end
            else begin p0.data = h_rsp_i.data[127:0]; p0.be = 16'hFFFF; p1.data = h_rsp_i.data[255:128]; p1.be = 16'hFFFF; end
            rob_pkt[r_slot] <= p0; rob_pkt[r_slot1] <= p1; rob_done[r_slot] <= 1'b1; rob_done[r_slot1] <= 1'b1;
          end
          2'd2: begin   // single write
            if (r_err) rob_pkt[r_slot].status <= r_exc;
            rob_done[r_slot] <= 1'b1;
          end
          default: begin // one granule of the burst write
            bw_acked_q <= bw_acked_q + 8'd1;
            if (r_err && bw_status_q == SF_MEM_EXC_NONE) bw_status_q <= r_exc;
          end
        endcase
      end
      // burst write completes when every granule is issued AND acknowledged (the ack of this cycle is visible next cycle)
      if (bw_fin_q && (bw_acked_q == bw_issued_q)) begin
        rob_done[bw_slot_q] <= 1'b1; bw_fin_q <= 1'b0;
        rob_pkt[bw_slot_q].status <= bw_status_q;
      end
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    if (h_rsp_valid_i && !tag_busy[r_tag]) $error("[%m] HBM response for a tag that is not outstanding");
    if (h_rsp_valid_i && h_rsp_i.src != hbm_src_t'(HBM_SRC)) $error("[%m] HBM response for a foreign source %0d", h_rsp_i.src);
    if (rob_cnt > (RW+1)'(ROB_N)) $error("[%m] ROB overflow");
  end
`endif
endmodule : sf_hbm_datafabric
