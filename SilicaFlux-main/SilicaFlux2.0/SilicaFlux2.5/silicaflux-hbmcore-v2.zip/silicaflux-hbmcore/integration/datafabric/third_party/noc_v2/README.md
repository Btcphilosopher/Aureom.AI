# Vendored from SilicaFlux DataFabric NoC v2 (unmodified copies)

Source: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric-noc-v2.zip` (packet contract `SF_NOC_PKT_VERSION = 1`).
Files are byte-identical copies; checksums in `SHA256SUMS`. HBMCore only IMPORTS `silicaflux_pkg` (packet types and
`sf_noc_make_rsp`); it does not modify the contract. If the contract changes (version bump), `sf_hbm_datafabric` must be re-checked.

* `silicaflux_pkg.sv` + `silicaflux_noc_section.svh` : memory types + `noc_packet_t` (207 bits)
* `PACKET_SPEC.md` : the contract text
* `sf_noc_mem_target_ni.sv` : the existing memory-side NI for the on-chip scratchpad (reference for response semantics; NOT used by HBMCore)
* `scratchpad_memory_controller.sv` : the existing on-chip SRAM `memory_controller` (burst port used by the DMA adapter test)
