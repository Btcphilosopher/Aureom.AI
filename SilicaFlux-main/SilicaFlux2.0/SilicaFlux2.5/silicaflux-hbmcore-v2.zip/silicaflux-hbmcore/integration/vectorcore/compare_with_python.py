#!/usr/bin/env python3
"""Replay every VectorCore trace through (a) the RTL bench (tb_bench +BENCH=R, 4 channels) and (b) the INDEPENDENT Python scheduler model
(python/hbm4/scheduler.py + address_map.py, written from the docs without reading the RTL). Writes reports/vector_replay.json / .md.

The Python scheduler is a transaction-level sanity reference, NOT a cycle-exact twin of the RTL: agreement within a modest factor and the same
ordering of workloads is the expectation; exact equality is not (different queue/credit details, see python/README.md)."""
import json, pathlib, subprocess, sys, collections
ROOT = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python"))
from hbm4.address_map import AddrMapCfg, map_addr, MAP_BANK_AWARE, pc_index
from hbm4.scheduler import simulate
from hbm4.timing import load_profiles

BIN = ROOT / "build/tb_bench_ch4r/obj/Vtb_bench"
NCH, PROFILE = 4, 1
cfg = AddrMapCfg(num_stacks=1, num_channels=NCH, pcs=2)
prof = load_profiles()[PROFILE]
rows = []
for tr in sorted((ROOT / "traces").glob("vector_*.trace")):
    acc = [l.split() for l in tr.read_text().splitlines() if l.strip()]
    for hsh in (0, 1):
        # ---- RTL
        js = ROOT / "reports" / "bench" / f"R_{tr.stem}_hash{hsh}.json"
        subprocess.run([str(BIN), "+BENCH=R", f"+TRACE={tr}", "+MAP=2", f"+HASH={hsh}", f"+PROFILE={PROFILE}", "+POLICY=1", "+NSRC=4", "+WINDOW=128", f"+JSON={js}"],
                       capture_output=True, text=True, cwd=ROOT)
        r = json.loads(js.read_text()) if js.exists() else None
        # ---- Python model: one pseudo-channel at a time (they are independent)
        per = collections.defaultdict(list)
        for t, rw, addr, src in acc:
            loc = map_addr(int(addr, 16), cfg, MAP_BANK_AWARE, 0, bool(hsh))
            per[pc_index(loc, cfg)].append((int(t), rw == "W", loc.bg, loc.ba, loc.row, loc.col))
        cyc, byt, hit, n = 0, 0, 0, 0
        viol = 0
        for pc, reqs in per.items():
            res = simulate(reqs, prof, policy="frfcfs", queue_depth=16, page="open", refresh=True)
            cyc = max(cyc, res.total_cycles); byt += res.bytes_moved
            c = res.summary(); hit += res.row_hit_rate * len(reqs); n += len(reqs)
            viol += len(res.check().violations)
        py_bw = byt / cyc if cyc else 0.0
        rows.append(dict(trace=tr.stem.replace("vector_", ""), hash=hsh, accesses=len(acc), writes=sum(1 for a in acc if a[1] == "W"),
                         rtl_gb_s=r["bandwidth_gb_s"] if r else None, rtl_cycles=r["cycles"] if r else None, rtl_hit=r["row"]["hit_rate"] if r else None,
                         rtl_lat_mean=r["latency"]["mean"] if r else None, py_gb_s=round(py_bw, 2), py_cycles=cyc, py_hit=round(hit / max(1, n), 4),
                         python_model_violations=viol, rtl_violations=r["dram_violations"] if r else None))
        print(rows[-1])
out = ROOT / "reports"
(out / "vector_replay.json").write_text(json.dumps(rows, indent=1))
md = ["# VectorCore trace replay: RTL vs independent Python scheduler model", "",
      "MODELLED (hypothetical profile 1, 4 channels, bank-aware map). The Python scheduler is a transaction-level sanity reference, not a cycle-exact twin.", "",
      "| workload | map hash | accesses | RTL GB/s | Python GB/s | RTL / Python | RTL row-hit | Python row-hit | RTL mean latency | DRAM violations (RTL / python model) |", "|---|---|---|---|---|---|---|---|---|---|"]
for r in rows:
    if r["rtl_gb_s"] is None: continue
    md.append(f"| {r['trace']} | {'on' if r['hash'] else 'off'} | {r['accesses']:,} | {r['rtl_gb_s']:.1f} | {r['py_gb_s']:.1f} | {r['rtl_gb_s']/max(r['py_gb_s'],1e-9):.2f} | {100*r['rtl_hit']:.0f}% | {100*r['py_hit']:.0f}% | {r['rtl_lat_mean']:.0f} | {r['rtl_violations']} / {r['python_model_violations']} |")
(out / "vector_replay.md").write_text("\n".join(md) + "\n")
