#!/usr/bin/env python3
"""VectorCore-style memory access traces at 32-byte HBM-granule level (deterministic, seeded).

SilicaFlux VectorCore moves 128-bit (16 B) lines (SF_VLEN) and FP32/FP64 elements. The HBM access granule is 32 B, so two consecutive 16 B line
accesses of the same stream to the same 32 B granule are COALESCED into one granule request (rule used here for every generator).
Trace format (one access per line, consumed by tb_bench +BENCH=R +TRACE=<file>):   <arrival_cycle> <R|W> <hex byte address> <source id>
`arrival_cycle` is when the vector load/store unit would issue it; the memory system may take longer (the bench applies a window per source).

Workloads (each also available through --all):
  fp32_seq_read   streaming FP32 reads              fp64_triad     STREAM triad a=b+s*c with FP64 (2 reads + 1 write streams)
  fp32_strided    stride-64-element FP32 reads      gather_fp32    gather from a random index vector (table of 64 MiB)
  spmv_csr        sparse matrix-vector (CSR): value/column streams, x[col] gather, y write stream (FP64 values)
  dense_matvec    row-major dense y = A x (A streams, x re-read per row)      copy_mixed   read stream + write stream
  sparse_random   uniform random reads/writes (sparse updates)
"""
import argparse, pathlib, random

G = 32  # granule bytes
OUT = pathlib.Path(__file__).resolve().parent.parent.parent / "traces"


def seq_read(n_elems, elem, base, src, pace):
    last, t, out = -1, 0, []
    for i in range(n_elems):
        g = (base + i * elem) // G
        if g != last:
            out.append((t, "R", g * G, src)); last = g; t += pace
    return out


def gen(name, rng, n):
    acc = []
    if name == "fp32_seq_read":
        for s in range(4):
            acc += seq_read(n * 8, 4, 0x0400_0000 * s, s, 2)
    elif name == "fp64_triad":
        for s in range(4):
            b, c, a = 0x0800_0000 + s * 0x0100_0000, 0x1800_0000 + s * 0x0100_0000, 0x2800_0000 + s * 0x0100_0000
            t = 0
            for i in range(0, n * 8, 4):                       # 4 FP64 = 32 B per array per step
                acc += [(t, "R", b + i * 8, s), (t + 1, "R", c + i * 8, s), (t + 2, "W", a + i * 8, s)]
                t += 3
    elif name == "fp32_strided":
        for s in range(4):
            acc += [(i * 2, "R", (0x0400_0000 * s + i * 64 * 4) // G * G, s) for i in range(n * 4)]
    elif name == "gather_fp32":
        for s in range(4):
            acc += [(i * 2, "R", rng.randrange(1 << 26) // G * G, s) for i in range(n * 4)]
    elif name == "spmv_csr":
        for s in range(4):
            t, valp, colp, yp = 0, 0x0000_0000 + s * 0x0100_0000, 0x1000_0000 + s * 0x0100_0000, 0x2000_0000 + s * 0x0100_0000
            for row in range(n // 4):
                nnz = rng.randrange(4, 33)
                for k in range(0, nnz, 4):                     # 4 FP64 values + 4 column indices per granule pair
                    acc += [(t, "R", valp, s), (t, "R", colp, s)]; valp += G; colp += G // 2
                    for _ in range(min(4, nnz - k)):           # x[col] gather: one granule each, random column
                        acc.append((t + 1, "R", 0x3000_0000 + rng.randrange(1 << 22) * 8 // G * G, s)); t += 1
                    t += 2
                acc.append((t, "W", yp, s)); yp += 8 if row % 4 == 3 else 0; t += 1
    elif name == "dense_matvec":
        for s in range(4):
            t, rows, cols = 0, n // 8, 512
            for r in range(rows):
                for c in range(0, cols * 8, G):
                    acc += [(t, "R", 0x0400_0000 * s + (r * cols * 8 + c), s), (t + 1, "R", 0x3800_0000 + c, s)]; t += 2   # A tile + x segment
                acc.append((t, "W", 0x3C00_0000 + s * 0x10000 + r * 8 // G * G, s)); t += 1
    elif name == "copy_mixed":
        for s in range(4):
            t = 0
            for i in range(n * 4):
                acc += [(t, "R", 0x0400_0000 * s + i * G, s), (t + 1, "W", 0x2000_0000 + 0x0400_0000 * s + i * G, s)]; t += 2
    elif name == "sparse_random":
        for s in range(4):
            acc += [(i * 2, "W" if rng.random() < 0.25 else "R", rng.randrange(1 << 27) // G * G, s) for i in range(n * 4)]
    else:
        raise SystemExit(f"unknown workload {name}")
    acc.sort(key=lambda a: (a[0], a[3]))
    return acc


WORKLOADS = ["fp32_seq_read", "fp64_triad", "fp32_strided", "gather_fp32", "spmv_csr", "dense_matvec", "copy_mixed", "sparse_random"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workload", choices=WORKLOADS)
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--n", type=int, default=512, help="size parameter (see generators)")
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    OUT.mkdir(exist_ok=True)
    for w in (WORKLOADS if a.all else [a.workload]):
        acc = gen(w, random.Random(a.seed), a.n)
        p = OUT / f"vector_{w}.trace"
        p.write_text("".join(f"{t} {rw} {addr:x} {s}\n" for t, rw, addr, s in acc))
        print(f"{p.name}: {len(acc)} accesses, {sum(1 for x in acc if x[1]=='W')} writes, span {acc[-1][0]} cycles")


if __name__ == "__main__":
    main()
