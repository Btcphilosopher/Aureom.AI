// =============================================================================
//  SILICAFLUX HBMCORE  --  integration/dma/sf_hbm_dma_adapter.sv
//  Descriptor-driven DMA between external HBM (through the DataFabric memory node = sf_hbm_datafabric)
//  and the on-chip scratchpad SRAM (the REAL silicaflux memory_controller burst port).
//
//     dir 0 :  HBM --(NoC BURST RD)--> response flits --(SRAM burst STORE)--> scratchpad
//     dir 1 :  scratchpad --(SRAM burst LOAD)--> read beats --(NoC BURST WR)--> HBM
//
//  This block is a NoC MASTER (src_id = MY_ID, dst_id = MEM_ID) and a client of the scratchpad's burst port. It
//  therefore uses the SAME verified packet contract as every other tile and reuses sf_hbm_datafabric's splitting,
//  reordering and error handling instead of re-implementing them.
//
//  SRAM PORT WIDTH IS REAL: one 128-bit line (SF_VLEN) per beat, i.e. 16 B/cycle at most; the scratchpad's burst rules
//  (single domain, single BURST_PAGE_BYTES page, aperture, BURST_MAX_BEATS) are enforced HERE by splitting.
//
//  PROGRAMMABLE BURST: burst_beats_i (1..32 beats of 16 B). Each chunk is  min(burst_beats, remaining beats,
//  beats to the next SRAM page boundary).  ALIGNMENT: hbm_addr_i and spm_addr_i must be 16 B aligned and bytes_i a
//  multiple of 16 (checked: err_o = MISALIGN, nothing issued). HBM addresses that are 16 B but not 32 B aligned are
//  handled by the DataFabric adapter (split granules).
//  ORDERING / BOUNDARIES: chunks are processed strictly one after another (no overlap between the chunks of one
//  transfer) so an HBM write chunk is complete (WR_RSP received) before the next chunk's data is read; a transfer never
//  reads or writes outside [addr, addr+bytes).
//  NODE LIMITS (inputs node_addr_hi_i / node_max_burst_m1_i = the SAME values the DataFabric memory node uses, i.e. the CSR
//  registers ADDRHI / MAXBURST):
//    * hbm_addr_i[39:32] must equal node_addr_hi_i, and the transfer must not cross a 4 GiB boundary of the 32-bit NoC
//      address (the node concatenates {addr_hi, noc.addr[31:0]}, so a crossing would silently WRAP): otherwise err = RANGE,
//      nothing is issued.
//    * every chunk is clamped to node_max_burst_m1_i + 1 beats, so the node never answers BURST_LEN to a chunk this block builds.
//  ERRORS (first one wins, transfer stops after the current chunk): NoC response status != NONE, SRAM done exc != NONE.
//  err_o carries the silicaflux sf_mem_exc_e code. done_o pulses once per transfer (also after an error).
//  COUNTERS: bytes_moved_o counts ONLY chunks that completed WITHOUT error (a failed chunk moved no trusted data); chunks_o
//  counts chunks that were issued (including the failed one).
//  v2 FIXES (independent review; each has a directed test in tb_dma_spm):
//    * the NoC descriptor is offered until it is ACCEPTED (v1 offered it for one cycle only: request-link back-pressure in
//      that cycle hung the DMA for ever);
//    * dir 1: an SRAM-side error (rejected or killed LOAD) before every beat was forwarded closes the already-announced NoC
//      burst write with zero-strobe FILLER beats (v1 left the DataFabric node waiting in S_BWR for beats that never came,
//      blocking every other tile's requests);
//    * dir 1: an SRAM beat flagged with an exception is forwarded with strobe 0 (v1 wrote the corrupt data into HBM with
//      fresh, valid ECC, so the corruption became invisible);
//    * dir 0: a response stream that ends early (an error flit with eop, e.g. BURST_LEN when the node's MAXBURST changed
//      between this block's chunk sizing and the node's decode) completes the SRAM burst with zero-strobe beats instead of
//      waiting for flits that never come; the same eop rule ends D_DRAIN.
//  RESET: async assert; idle.
// =============================================================================
module sf_hbm_dma_adapter
  import silicaflux_pkg::*;
#(
  parameter sf_noc_id_t    MY_ID           = 4'b0000,
  parameter sf_noc_id_t    MEM_ID          = 4'b0011,
  parameter int unsigned   SPM_PAGE_BYTES  = 4096,
  parameter int unsigned   SPM_MAX_BEATS   = 256
) (
  input  logic                clk_i,
  input  logic                rst_ni,

  // control
  input  logic                start_i,
  input  logic                dir_i,              // 0: HBM -> SRAM, 1: SRAM -> HBM
  input  logic [39:0]         hbm_addr_i,         // [31:0] goes into the NoC address, [39:32] must equal the node's addr_hi
  input  sf_paddr_t           spm_addr_i,
  input  logic [23:0]         bytes_i,
  input  logic [5:0]          burst_beats_i,
  input  logic [7:0]          node_addr_hi_i,     // = DataFabric node addr_hi_i (CSR ADDRHI)
  input  logic [7:0]          node_max_burst_m1_i,// = DataFabric node max_burst_m1_i (CSR MAXBURST), in 16 B NoC beats - 1
  output logic                busy_o,
  output logic                done_o,
  output sf_mem_exc_e         err_o,
  output logic [31:0]         bytes_moved_o,
  output logic [15:0]         chunks_o,

  // NoC master port (request / response networks)
  output logic                noc_req_valid_o,
  input  logic                noc_req_ready_i,
  output noc_packet_t         noc_req_o,
  input  logic                noc_rsp_valid_i,
  output logic                noc_rsp_ready_o,
  input  noc_packet_t         noc_rsp_i,

  // scratchpad burst port (memory_controller burst_*)
  output logic                spm_req_valid_o,
  input  logic                spm_req_ready_i,
  output sf_burst_desc_t      spm_req_o,
  output logic                spm_wdata_valid_o,
  input  logic                spm_wdata_ready_i,
  output sf_burst_wbeat_t     spm_wdata_o,
  input  logic                spm_rdata_valid_i,
  output logic                spm_rdata_ready_o,
  input  sf_burst_rbeat_t     spm_rdata_i,
  input  logic                spm_done_valid_i,
  output logic                spm_done_ready_o,
  input  sf_burst_done_t      spm_done_i
);
  localparam int unsigned PAGE_BEATS = SPM_PAGE_BYTES / SF_VBYTES;

  typedef enum logic [3:0] {D_IDLE, D_CHUNK, D_ISSUE, D_STREAM, D_WAIT, D_DRAIN, D_NEXT, D_FIN} st_e;
  st_e st_q;

  logic          dir_q;
  logic [39:0]   hbm_q;
  sf_paddr_t     spm_q;
  logic [23:0]   beats_left_q;                // 16 B beats still to transfer
  logic [5:0]    burst_q;
  logic [5:0]    chunk_q;                     // beats of the current chunk
  logic [5:0]    sent_q, recv_q;              // beats forwarded / received in this chunk
  sf_mem_exc_e   err_q;
  logic          noc_desc_sent_q, spm_desc_sent_q, spm_done_q, wr_rsp_q;
  logic          fill_q;                      // dir 1: closing the NoC burst write with zero-strobe filler beats
  logic          rfill_q;                     // dir 0: completing the SRAM burst with zero-strobe beats (response ended early)
  logic [7:0]    tag_q;

  assign busy_o = (st_q != D_IDLE);

  // ---- chunk size: min(burst, left, to-page-boundary, SRAM max) ------------------------------------
  logic [23:0] to_page;
  logic [5:0]  chunk_c;
  always_comb begin
    to_page = 24'(PAGE_BEATS) - 24'((spm_q / SF_VBYTES) % PAGE_BEATS);
    chunk_c = burst_q;
    if (beats_left_q < 24'(chunk_c)) chunk_c = 6'(beats_left_q);
    if (to_page < 24'(chunk_c))      chunk_c = 6'(to_page);
    if (SPM_MAX_BEATS < 32 && SPM_MAX_BEATS < int'(chunk_c)) chunk_c = 6'(SPM_MAX_BEATS);
    if ((9'(node_max_burst_m1_i) + 9'd1) < 9'(chunk_c))      chunk_c = 6'(node_max_burst_m1_i + 8'd1);
  end

  // ---- NoC request generation -------------------------------------------------------------------------
  noc_packet_t desc_pkt, beat_pkt;
  always_comb begin
    desc_pkt = '0;
    desc_pkt.valid = 1'b1; desc_pkt.sop = 1'b1; desc_pkt.eop = !dir_q;
    desc_pkt.pclass = dir_q ? SF_NOC_WR_REQ : SF_NOC_RD_REQ;
    desc_pkt.xfer   = SF_NOC_X_BURST; desc_pkt.dst_id = MEM_ID; desc_pkt.src_id = MY_ID;
    desc_pkt.txn_id = tag_q; desc_pkt.addr = hbm_q[31:0];
    desc_pkt.data   = sf_noc_data_t'({2'b00, chunk_q - 6'd1});
    beat_pkt = '0;
    beat_pkt.valid = 1'b1; beat_pkt.sop = 1'b0; beat_pkt.eop = (sent_q == chunk_q - 6'd1);
    beat_pkt.pclass = SF_NOC_WR_REQ; beat_pkt.xfer = SF_NOC_X_BURST; beat_pkt.dst_id = MEM_ID; beat_pkt.src_id = MY_ID;
    beat_pkt.txn_id = tag_q; beat_pkt.addr = hbm_q[31:0] + 32'(16 * sent_q);
    beat_pkt.data   = fill_q ? '0 : spm_rdata_i.data;
    beat_pkt.be     = (fill_q || (spm_rdata_i.exc != SF_MEM_EXC_NONE)) ? 16'h0000 : 16'hFFFF;
  end

  // request-side muxing
  logic send_desc, send_beat;
  always_comb begin
    send_desc = ((st_q == D_ISSUE) || (st_q == D_STREAM)) && !noc_desc_sent_q;     // held until accepted (v2)
    send_beat = (st_q == D_STREAM) && dir_q && noc_desc_sent_q && (fill_q || spm_rdata_valid_i) && (sent_q < chunk_q);
    noc_req_valid_o = send_desc || send_beat;
    noc_req_o       = send_desc ? desc_pkt : beat_pkt;
  end
  wire noc_req_fire = noc_req_valid_o && noc_req_ready_i;

  // ---- scratchpad side ---------------------------------------------------------------------------------------
  always_comb begin
    spm_req_o = '0;
    spm_req_o.op     = dir_q ? SF_MEM_LOAD : SF_MEM_STORE;      // dir 1 reads the scratchpad, dir 0 writes it
    spm_req_o.base   = spm_q;
    spm_req_o.len_m1 = sf_burst_len_t'(chunk_q - 6'd1);
    spm_req_o.tag    = tag_q;
    spm_req_o.hint   = SF_MEM_HINT_STREAM;
    spm_req_valid_o  = ((st_q == D_ISSUE) || (st_q == D_STREAM)) && !spm_desc_sent_q;
  end

  // dir 0: HBM response flit -> scratchpad write beat (flow-controlled by the SRAM write FIFO)
  wire rsp_is_beat = noc_rsp_valid_i && (noc_rsp_i.pclass == SF_NOC_RD_RSP);
  always_comb begin
    spm_wdata_valid_o = 1'b0; spm_wdata_o = '0; noc_rsp_ready_o = 1'b0;
    if (st_q == D_STREAM && !dir_q && rfill_q) begin
      spm_wdata_valid_o = spm_desc_sent_q && (recv_q < chunk_q);                     // filler beat: strobe 0, writes nothing
    end else if (st_q == D_STREAM && !dir_q) begin
      if (noc_rsp_valid_i && noc_rsp_i.pclass == SF_NOC_RD_RSP) begin
        // an ERROR flit (be = 0, no data) still occupies one beat of the SRAM burst: forward it with strobe 0 so the
        // burst keeps its length and completes (a zero-strobe beat writes nothing); the error is recorded and stops the DMA
        spm_wdata_valid_o = spm_desc_sent_q;
        spm_wdata_o.data  = (noc_rsp_i.status != SF_MEM_EXC_NONE) ? '0 : noc_rsp_i.data;
        spm_wdata_o.strb  = (noc_rsp_i.status != SF_MEM_EXC_NONE) ? '0 : noc_rsp_i.be;
        noc_rsp_ready_o   = spm_desc_sent_q && spm_wdata_ready_i;
      end else noc_rsp_ready_o = noc_rsp_valid_i;                                      // unexpected class: swallow
    end else if (st_q == D_DRAIN) begin
      noc_rsp_ready_o = noc_rsp_valid_i;                                               // swallow the flits of a rejected chunk
    end else if (st_q == D_WAIT && dir_q) begin
      noc_rsp_ready_o = noc_rsp_valid_i;                                               // the WR_RSP of a write chunk
    end else if (st_q == D_STREAM && dir_q) begin
      noc_rsp_ready_o = 1'b0;
    end
  end
  // dir 1: scratchpad read beat -> NoC beat flit
  assign spm_rdata_ready_o = (st_q == D_STREAM) && dir_q && noc_desc_sent_q && noc_req_ready_i && (sent_q < chunk_q) && !fill_q;
  assign spm_done_ready_o  = 1'b1;

  wire spm_wfire = spm_wdata_valid_o && spm_wdata_ready_i;
  wire rsp_fire  = noc_rsp_valid_i && noc_rsp_ready_o;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= D_IDLE; dir_q <= 1'b0; hbm_q <= '0; spm_q <= '0; beats_left_q <= '0; burst_q <= 6'd1; chunk_q <= '0;
      sent_q <= '0; recv_q <= '0; err_q <= SF_MEM_EXC_NONE; noc_desc_sent_q <= 1'b0; spm_desc_sent_q <= 1'b0;
      spm_done_q <= 1'b0; wr_rsp_q <= 1'b0; tag_q <= '0; done_o <= 1'b0; err_o <= SF_MEM_EXC_NONE;
      fill_q <= 1'b0; rfill_q <= 1'b0;
      bytes_moved_o <= '0; chunks_o <= '0;
    end else begin
      done_o <= 1'b0;
      case (st_q)
        D_IDLE: if (start_i) begin
          dir_q <= dir_i; hbm_q <= hbm_addr_i; spm_q <= spm_addr_i; beats_left_q <= bytes_i[23:4];
          burst_q <= (burst_beats_i == 6'd0) ? 6'd1 : ((burst_beats_i > 6'd32) ? 6'd32 : burst_beats_i);
          err_q <= SF_MEM_EXC_NONE; bytes_moved_o <= '0; chunks_o <= '0; err_o <= SF_MEM_EXC_NONE;
          if (hbm_addr_i[3:0] != 4'h0 || spm_addr_i[3:0] != 4'h0 || bytes_i[3:0] != 4'h0) begin
            err_q <= SF_MEM_EXC_MISALIGN; st_q <= D_FIN;
          end else if (hbm_addr_i[39:32] != node_addr_hi_i ||
                       ({1'b0, hbm_addr_i[31:0]} + 33'(bytes_i)) > 33'h1_0000_0000) begin
            err_q <= SF_MEM_EXC_RANGE; st_q <= D_FIN;          // wrong 4 GiB window, or the transfer would wrap the 32-bit NoC address
          end else if (bytes_i == 24'd0) st_q <= D_FIN;
          else st_q <= D_CHUNK;
        end
        D_CHUNK: begin
          chunk_q <= chunk_c; sent_q <= '0; recv_q <= '0; noc_desc_sent_q <= 1'b0; spm_desc_sent_q <= 1'b0;
          spm_done_q <= 1'b0; wr_rsp_q <= 1'b0; tag_q <= tag_q + 8'd1; st_q <= D_ISSUE;
          fill_q <= 1'b0; rfill_q <= 1'b0;
        end
        D_ISSUE, D_STREAM: begin
          st_q <= D_STREAM;
          if (noc_req_fire && send_desc) noc_desc_sent_q <= 1'b1;
          if (spm_req_valid_o && spm_req_ready_i) spm_desc_sent_q <= 1'b1;
          // dir 0: count response flits consumed (data flits forwarded to SRAM, error flits swallowed)
          if (!dir_q && rsp_fire) begin
            recv_q <= recv_q + 6'd1;
            if (noc_rsp_i.status != SF_MEM_EXC_NONE && err_q == SF_MEM_EXC_NONE) err_q <= noc_rsp_i.status;
            // response ended before chunk_q flits (single error flit with eop): finish the SRAM burst with filler beats
            if (noc_rsp_i.pclass == SF_NOC_RD_RSP && noc_rsp_i.eop && (recv_q + 6'd1 < chunk_q)) begin
              rfill_q <= 1'b1;
              if (noc_rsp_i.status == SF_MEM_EXC_NONE && err_q == SF_MEM_EXC_NONE) err_q <= SF_MEM_EXC_FLUSHED;
            end
          end
          if (!dir_q && rfill_q && spm_wfire) recv_q <= recv_q + 6'd1;
          // dir 1: count beats forwarded to the NoC; a beat the SRAM flagged is sent with strobe 0 and recorded
          if (dir_q && noc_req_fire && send_beat) begin
            sent_q <= sent_q + 6'd1;
            if (!fill_q && spm_rdata_i.exc != SF_MEM_EXC_NONE && err_q == SF_MEM_EXC_NONE) err_q <= spm_rdata_i.exc;
          end
          if (spm_done_valid_i && spm_done_ready_o) begin
            spm_done_q <= 1'b1;
            if (spm_done_i.exc != SF_MEM_EXC_NONE && err_q == SF_MEM_EXC_NONE) err_q <= spm_done_i.exc;
            // dir 1: SRAM LOAD rejected / killed before every beat was forwarded -> close the NoC burst with filler beats
            if (dir_q && spm_done_i.exc != SF_MEM_EXC_NONE && (sent_q + 6'(noc_req_fire && send_beat) < chunk_q)) fill_q <= 1'b1;
          end
          // dir 0 is finished when every flit was consumed and the SRAM burst is done
          if (!dir_q && (recv_q == chunk_q) && (spm_done_q || (spm_done_valid_i && spm_done_ready_o))) st_q <= D_NEXT;
          // dir 1: all beats sent -> wait for the HBM write completion
          if (dir_q && (sent_q == chunk_q) && (spm_done_q || (spm_done_valid_i && spm_done_ready_o))) st_q <= D_WAIT;
          // an SRAM-side rejection (done with error before any data): there will be no flits of a failed STORE; drain and stop
          if (!dir_q && spm_done_valid_i && spm_done_i.exc != SF_MEM_EXC_NONE && !(recv_q == chunk_q)) st_q <= D_DRAIN;
        end
        D_DRAIN: begin
          if (rsp_fire) recv_q <= recv_q + 6'd1;
          if ((recv_q + 6'(rsp_fire) >= chunk_q) || (rsp_fire && noc_rsp_i.eop)) st_q <= D_NEXT;   // v2: eop ends the drain
        end
        D_WAIT: begin
          if (rsp_fire) begin
            if (noc_rsp_i.status != SF_MEM_EXC_NONE && err_q == SF_MEM_EXC_NONE) err_q <= noc_rsp_i.status;
            st_q <= D_NEXT;
          end
        end
        D_NEXT: begin
          if (err_q == SF_MEM_EXC_NONE) bytes_moved_o <= bytes_moved_o + 32'(chunk_q) * 32'd16;   // only error-free chunks
          chunks_o      <= chunks_o + 16'd1;
          hbm_q <= hbm_q + 40'(chunk_q) * 40'd16;
          spm_q <= spm_q + sf_paddr_t'(chunk_q) * sf_paddr_t'(16);
          beats_left_q <= beats_left_q - 24'(chunk_q);
          if (err_q != SF_MEM_EXC_NONE || beats_left_q == 24'(chunk_q)) st_q <= D_FIN; else st_q <= D_CHUNK;
        end
        D_FIN: begin
          done_o <= 1'b1; err_o <= err_q; st_q <= D_IDLE;
        end
        default: st_q <= D_IDLE;
      endcase
    end
  end
endmodule : sf_hbm_dma_adapter
