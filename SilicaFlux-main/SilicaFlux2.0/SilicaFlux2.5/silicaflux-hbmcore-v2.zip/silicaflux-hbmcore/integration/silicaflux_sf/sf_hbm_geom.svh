// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_geom.svh
//  Simulation / reference geometry. EVERY value here is an ENGINEERING_ASSUMPTION
//  unless the standards matrix (docs/STANDARDS_MATRIX.md) says otherwise.
//
//  Override at build time with -D<NAME>=<value> (see Makefile). No value in this
//  file is claimed to be a JESD270-4 requirement.
//
//    HBM_BG_BITS    bank-group address bits              (2 => 4 groups)
//    HBM_BA_BITS    bank bits inside a group             (2 => 4 banks / group)
//    HBM_ROW_BITS   row address bits                     (15 => 32768 rows)
//    HBM_COL_BITS   column bits, in access GRANULES      (6 => 64 granules / row)
//    HBM_ID_BITS    transaction ID width                 (8 == SF_MEM_TAG_W)
//    HBM_SRC_BITS   requester (source) ID width
//    HBM_ADDR_BITS  byte-address width at the host interface
// =============================================================================
`ifndef SF_HBM_GEOM_SVH
`define SF_HBM_GEOM_SVH

`ifndef HBM_BG_BITS
  `define HBM_BG_BITS   2
`endif
`ifndef HBM_BA_BITS
  `define HBM_BA_BITS   2
`endif
`ifndef HBM_ROW_BITS
  `define HBM_ROW_BITS  15
`endif
`ifndef HBM_COL_BITS
  `define HBM_COL_BITS  6
`endif
`ifndef HBM_ID_BITS
  `define HBM_ID_BITS   8
`endif
`ifndef HBM_SRC_BITS
  `define HBM_SRC_BITS  4
`endif
`ifndef HBM_ADDR_BITS
  `define HBM_ADDR_BITS 40
`endif

`endif
