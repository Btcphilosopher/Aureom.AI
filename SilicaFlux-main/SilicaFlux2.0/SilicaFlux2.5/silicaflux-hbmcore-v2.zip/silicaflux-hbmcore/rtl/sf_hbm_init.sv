// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_init.sv
//  Controller-side power-on / configuration sequencing of one HBM stack.
//
//  WHAT THIS IS: bookkeeping of the controller's view of bring-up:
//        RESET -> WAIT_POWER -> WAIT_CLOCK -> PHY_INIT -> MODE_CFG -> TRAIN -> READY
//  WHAT THIS IS NOT: PHY training, calibration, ZQ/impedance, eye search, VREF / delay tuning.
//  Those are physical-interface behaviours implemented by dedicated, licensed PHY logic.
//  Here they are an EXTERNAL SERVICE: the controller raises phy_init_start_o / train_start_o and
//  waits for phy_init_done_i / train_done_i. No analogue calibration is invented in generic RTL.
//
//  MODE CONFIGURATION: NUM_MRS abstract mode-register writes (operand = step index). The real
//  HBM4 mode-register map and mandatory sequence come from JESD270-4 and are UNAVAILABLE here;
//  the operands are PLACEHOLDERS (docs/MISSING_SPEC.md) and the write is a typed abstract
//  HCMD_MRS. Every pseudo-channel must take each MRS (mrs_ack_i = AND of all pseudo-channel acks).
//
//  Each waiting state has a timeout (init_timeout cycles) that lands in ERROR with a cause code.
//  Cause: 1 power_good, 2 clock, 3 phy_init, 4 mode-config, 5 training.
//  RESET: async assert; RESET state.
// =============================================================================
module sf_hbm_init
  import sf_hbm_pkg::*;
#(
  parameter int unsigned NUM_MRS = 4
) (
  input  logic          clk_i,
  input  logic          rst_ni,
  input  logic          enable_i,          // CSR: start the sequence
  input  logic [31:0]   timeout_i,         // cycles per waiting state (0 = no timeout)

  input  logic          power_good_i,
  input  logic          clk_stable_i,
  input  logic          phy_init_done_i,
  input  logic          train_done_i,

  output logic          phy_init_start_o,
  output logic          train_start_o,

  output logic          mrs_valid_o,
  output logic [7:0]    mrs_code_o,
  input  logic          mrs_ack_i,

  output logic          ready_o,
  output logic          error_o,
  output logic [2:0]    cause_o,
  output logic [2:0]    state_o
);
  typedef enum logic [2:0] {I_RESET, I_PWR, I_CLK, I_PHY, I_MRS, I_TRAIN, I_READY, I_ERR} istate_e;
  istate_e st_q;
  logic [31:0] to_q;
  logic [7:0]  step_q;
  logic        mrs_pulse_q;

  assign state_o = st_q;
  assign ready_o = (st_q == I_READY);
  assign error_o = (st_q == I_ERR);

  wire to_hit = (timeout_i != 32'd0) && (to_q >= timeout_i);

  always_comb begin
    phy_init_start_o = (st_q == I_PHY);
    train_start_o    = (st_q == I_TRAIN);
    mrs_valid_o      = (st_q == I_MRS);
    mrs_code_o       = step_q;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= I_RESET; to_q <= '0; step_q <= '0; cause_o <= '0; mrs_pulse_q <= 1'b0;
    end else begin
      if (!enable_i) begin
        st_q <= I_RESET; to_q <= '0; step_q <= '0; cause_o <= '0;
      end else begin
        to_q <= to_q + 32'd1;
        case (st_q)
          I_RESET: begin st_q <= I_PWR; to_q <= '0; end
          I_PWR:   if (power_good_i)  begin st_q <= I_CLK;   to_q <= '0; end
                   else if (to_hit)   begin st_q <= I_ERR;   cause_o <= 3'd1; end
          I_CLK:   if (clk_stable_i)  begin st_q <= I_PHY;   to_q <= '0; end
                   else if (to_hit)   begin st_q <= I_ERR;   cause_o <= 3'd2; end
          I_PHY:   if (phy_init_done_i) begin st_q <= I_MRS; to_q <= '0; step_q <= '0; end
                   else if (to_hit)   begin st_q <= I_ERR;   cause_o <= 3'd3; end
          I_MRS:   begin
            if (mrs_ack_i) begin
              if (step_q == 8'(NUM_MRS-1)) begin st_q <= I_TRAIN; to_q <= '0; end
              else begin step_q <= step_q + 8'd1; to_q <= '0; end
            end else if (to_hit) begin st_q <= I_ERR; cause_o <= 3'd4; end
          end
          I_TRAIN: if (train_done_i)  begin st_q <= I_READY; end
                   else if (to_hit)   begin st_q <= I_ERR;   cause_o <= 3'd5; end
          I_READY: begin
            // lose power-good or the PHY's training status -> controller is no longer ready
            if (!power_good_i || !clk_stable_i) begin st_q <= I_RESET; end
          end
          default: ;
        endcase
      end
    end
  end

  // the MRS acknowledge of the previous step must drop before the next step is judged
`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) mrs_pulse_q <= mrs_ack_i;
`endif
endmodule : sf_hbm_init
