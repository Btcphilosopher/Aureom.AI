// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_power_state.sv
//  Power-state sequencer of one pseudo-channel.
//
//  STATES        ACTIVE -> PREP -> ENTER -> LOW(PD | SR) -> EXIT -> WAKE -> ACTIVE
//  The abstract commands PDE / PDX / SRE / SRX are NOT JEDEC encodings (see sf_hbm_pkg).
//  Whether HBM4 offers each state, and its entry/exit rules, is UNVERIFIED; exit latencies come
//  from the timing profile (txp / txs - hypothetical in every shipped profile).
//
//  SAFE ENTRY (docs/POWER.md)
//    Low power is entered only when
//      * nothing is queued, in flight, or waiting for write data / read return,
//      * no refresh sequence is running,
//      * every bank is precharged (PREA is issued during PREP if any row is open).
//    A new request during PREP/ENTER aborts the entry (work_pending_i) - requests are never
//    stranded behind a low-power command.
//    In POWER-DOWN the refresh engine keeps its debt; urgent refresh wakes the channel EVEN IF power-down is still
//    requested (it re-enters afterwards when quiet again).
//    In SELF-REFRESH the DRAM refreshes itself: the refresh engine is paused and its debt is cleared on exit.
//
//  REQUESTS     req_i: 0 stay/return ACTIVE, 1 power-down, 2 self-refresh (CSR level request)
//               idle thresholds pd_idle_i / sr_idle_i (cycles of continuous idle, 0 = disabled) arm
//               automatic entry. Automatic wake on new work is always on.
//  Dynamic frequency / voltage switching is NOT implemented: it needs a documented PHY and
//  system-level contract (docs/POWER.md).
//  RESET: async assert; ACTIVE.
// =============================================================================
module sf_hbm_power_state
  import sf_hbm_pkg::*;
(
  input  logic          clk_i,
  input  logic          rst_ni,
  input  hbm_timing_t   tp_i,
  input  logic          enable_i,         // controller ready

  input  logic [1:0]    req_i,
  input  logic [15:0]   pd_idle_i,
  input  logic [15:0]   sr_idle_i,

  input  logic          quiet_i,          // queue empty, nothing in flight, no refresh sequence
  input  logic          work_pending_i,   // a request is waiting / arriving
  input  logic          all_idle_i,       // every bank precharged
  input  logic          ref_urgent_i,

  output logic          mnt_valid_o,
  output hbm_cmd_t      mnt_cmd_o,
  input  logic          mnt_grant_i,

  output logic          hold_o,           // block demand ACT / column commands
  output logic          pause_ref_o,
  output logic          ref_clear_o,      // one-cycle registered pulse on self-refresh exit
  output logic [2:0]    state_o,          // 0 ACTIVE 1 PREP 2 ENTER 3 PD 4 SR 5 EXIT 6 WAKE
  output logic [31:0]   res_active_o,     // residency counters (cycles)
  output logic [31:0]   res_pd_o,
  output logic [31:0]   res_sr_o
);
  typedef enum logic [2:0] {PW_ACTIVE, PW_PREP, PW_ENTER, PW_PD, PW_SR, PW_EXIT, PW_WAKE} pstate_e;
  pstate_e st_q;
  logic    tgt_sr_q;           // target of the current entry: 0 PD, 1 SR
  logic [15:0] idle_cnt_q, wake_cnt_q;

  assign state_o = st_q;

  wire want_sr = (req_i == 2'd2) || ((sr_idle_i != 16'd0) && (idle_cnt_q >= sr_idle_i));
  wire want_pd = (req_i == 2'd1) || ((pd_idle_i != 16'd0) && (idle_cnt_q >= pd_idle_i));
  wire want_low = enable_i && quiet_i && !work_pending_i && (want_sr || want_pd);

  always_comb begin
    mnt_valid_o = 1'b0;
    mnt_cmd_o   = '0;
    hold_o      = (st_q != PW_ACTIVE) && (st_q != PW_PREP);   // PREP keeps serving until it must close rows
    pause_ref_o = (st_q == PW_SR) || (st_q == PW_ENTER && tgt_sr_q);
    case (st_q)
      PW_PREP:  if (!all_idle_i) begin mnt_valid_o = 1'b1; mnt_cmd_o.cmd = HCMD_PREA; end
      PW_ENTER: begin mnt_valid_o = 1'b1; mnt_cmd_o.cmd = tgt_sr_q ? HCMD_SRE : HCMD_PDE; end
      PW_EXIT:  begin mnt_valid_o = 1'b1; mnt_cmd_o.cmd = tgt_sr_q ? HCMD_SRX : HCMD_PDX; end
      default: ;
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= PW_ACTIVE; tgt_sr_q <= 1'b0; idle_cnt_q <= '0; wake_cnt_q <= '0; ref_clear_o <= 1'b0;
      res_active_o <= '0; res_pd_o <= '0; res_sr_o <= '0;
    end else begin
      ref_clear_o <= 1'b0;
      if (quiet_i && !work_pending_i && st_q == PW_ACTIVE) begin
        if (idle_cnt_q != 16'hFFFF) idle_cnt_q <= idle_cnt_q + 16'd1;
      end else if (st_q == PW_ACTIVE) idle_cnt_q <= '0;

      case (st_q)
        PW_PD:  res_pd_o <= res_pd_o + 32'd1;
        PW_SR:  res_sr_o <= res_sr_o + 32'd1;
        default: res_active_o <= res_active_o + 32'd1;
      endcase

      case (st_q)
        PW_ACTIVE: if (want_low) begin
          tgt_sr_q <= want_sr;
          st_q     <= PW_PREP;
        end
        PW_PREP: begin
          if (work_pending_i || !enable_i) st_q <= PW_ACTIVE;
          else if (all_idle_i && quiet_i)  st_q <= PW_ENTER;
        end
        PW_ENTER: begin
          if (work_pending_i && !mnt_grant_i) st_q <= PW_ACTIVE;      // abort before the command left
          else if (mnt_grant_i) st_q <= tgt_sr_q ? PW_SR : PW_PD;
        end
        PW_PD: begin
          idle_cnt_q <= '0;
          // new work wakes PD only once the PD request is withdrawn; an URGENT REFRESH wakes it regardless,
          // because refresh cannot be issued into a powered-down DRAM and must not be starved by a held request
          if (((req_i == 2'd0) && work_pending_i) || ref_urgent_i) st_q <= PW_EXIT;
          else if (!enable_i) st_q <= PW_EXIT;
        end
        PW_SR: begin
          idle_cnt_q <= '0;
          if ((req_i == 2'd0) && work_pending_i) st_q <= PW_EXIT;
          else if (!enable_i) st_q <= PW_EXIT;
        end
        PW_EXIT: if (mnt_grant_i) begin
          st_q       <= PW_WAKE;
          wake_cnt_q <= hbm_ld(tgt_sr_q ? tp_i.txs : tp_i.txp);
          ref_clear_o <= tgt_sr_q;
        end
        PW_WAKE: begin
          if (wake_cnt_q == 16'd0) st_q <= PW_ACTIVE;
          else wake_cnt_q <= wake_cnt_q - 16'd1;
        end
        default: st_q <= PW_ACTIVE;
      endcase
    end
  end
endmodule : sf_hbm_power_state
