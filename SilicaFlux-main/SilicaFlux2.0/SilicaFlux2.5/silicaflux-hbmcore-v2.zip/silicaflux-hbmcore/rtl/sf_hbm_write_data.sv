// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_write_data.sv
//  Write-data buffer, burst formatting and write-data timing.
//
//  DATA STORAGE
//    DEPTH slots {256-bit data, 32-bit byte-enable}, indexed by the request-queue slot
//    (1:1 with sf_hbm_req_queue, see that module). Written in the cycle the request is
//    accepted; held until the data has been delivered to the PHY adapter.
//
//  WRITE-COMMAND / DATA ASSOCIATION AND TIMING
//    When the scheduler issues a WR column command for slot s at cycle t, the command
//    reaches the PHY interface at t+1 (command register) and its data MUST be on the
//    PHY write-data bus exactly WL cycles after that: cycle t+1+WL. The command is
//    registered into a small pending FIFO {slot, completion-index, due cycle}; at
//    `cyc == t+WL` the slot is read and registered onto the PHY bus (visible t+1+WL).
//    The pending FIFO is the only structure between "command issued" and "data sent".
//
//  SLOT LIFETIME
//    The request-queue slot is freed when the WR command issues, but its DATA is needed WL cycles
//    later. slot_busy_o holds the slot (queue allocation is masked) from command issue until the data
//    has been placed on the PHY bus. (Found by the DRAM model's write-data checker on the first run:
//    a re-allocated slot overwrote data that had not yet been sent.)
//
//  REJECTION CONTRACT
//    can_issue_o is low if the pending FIFO is full; the scheduler must not issue a WR
//    in that case ("reject a command if its data cannot be delivered in time"). The PHY
//    data path is assumed non-blocking after a command is accepted (docs/PHY_CONTRACT.md).
//
//  WRITE COMPLETION POLICY
//    wr_done_* pulses when the data has been placed on the PHY bus (WR_ACK_AT_DATA=1) or
//    one cycle after command issue (posted, WR_ACK_AT_DATA=0). There is no DRAM->controller
//    write acknowledge in the abstract interface; the doc states what "complete" means.
//
//  PARTIAL WRITES: the byte-enable travels to the PHY as `wmask`. Whether the real PHY /
//  DRAM supports write data masking is UNVERIFIED for HBM4. With controller ECC on, partial
//  writes are rejected upstream (HERR_POLICY).
//  RESET: async assert; pending FIFO empty.
// =============================================================================
module sf_hbm_write_data
  import sf_hbm_pkg::*;
#(
  parameter int unsigned DEPTH         = 16,
  parameter int unsigned PEND_DEPTH    = 16,
  parameter int unsigned CPL_IDX_W     = 4,
  parameter bit          WR_ACK_AT_DATA = 1'b1
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,
  input  hbm_timing_t                  tp_i,
  input  hbm_cyc_t                     cyc_i,

  // store (at request accept)
  input  logic                         st_valid_i,
  input  logic [$clog2(DEPTH)-1:0]     st_idx_i,
  input  hbm_data_t                    st_data_i,
  input  hbm_mask_t                    st_mask_i,

  // WR command issue (scheduler)
  input  logic                         wr_issue_i,
  input  logic [$clog2(DEPTH)-1:0]     wr_idx_i,
  input  logic [CPL_IDX_W-1:0]         wr_cpl_idx_i,
  output logic                         can_issue_o,

  // write-data bus toward the PHY adapter
  output logic                         wdata_valid_o,
  output hbm_data_t                    wdata_o,
  output hbm_mask_t                    wmask_o,

  // write completion toward the completion sequencer
  output logic                         wr_done_valid_o,
  output logic [CPL_IDX_W-1:0]         wr_done_idx_o,

  output logic                         pend_empty_o,
  output logic [DEPTH-1:0]             slot_busy_o      // slot still owes its data to the PHY: must not be re-allocated
);
  localparam int unsigned IW = $clog2(DEPTH);
  localparam int unsigned PW = (PEND_DEPTH > 1) ? $clog2(PEND_DEPTH) : 1;

  hbm_data_t [DEPTH-1:0] data_q;
  hbm_mask_t [DEPTH-1:0] mask_q;

  typedef struct packed {
    logic [IW-1:0]         slot;
    logic [CPL_IDX_W-1:0]  cpl;
    hbm_cyc_t              due;
  } pend_t;

  pend_t [PEND_DEPTH-1:0] pend_q;
  logic [PW-1:0]  rp_q, wp_q;
  logic [PW:0]    cnt_q;
  logic [DEPTH-1:0] busy_q;
  assign slot_busy_o = busy_q;

  assign can_issue_o  = (cnt_q < (PW+1)'(PEND_DEPTH));
  assign pend_empty_o = (cnt_q == '0);

  wire pend_head_due = (cnt_q != '0) && (pend_q[rp_q].due == cyc_i);
  wire pend_pop      = pend_head_due;
  wire pend_push     = wr_issue_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rp_q <= '0; wp_q <= '0; cnt_q <= '0; busy_q <= '0;
      wdata_valid_o <= 1'b0; wdata_o <= '0; wmask_o <= '0;
      wr_done_valid_o <= 1'b0; wr_done_idx_o <= '0;
    end else begin
      wdata_valid_o   <= 1'b0;
      wr_done_valid_o <= 1'b0;

      if (st_valid_i) begin
        data_q[st_idx_i] <= st_data_i;
        mask_q[st_idx_i] <= st_mask_i;
      end

      if (pend_push) busy_q[wr_idx_i] <= 1'b1;
      if (pend_pop)  busy_q[pend_q[rp_q].slot] <= 1'b0;
      if (pend_push) begin
        // data is due WL cycles after the command is visible on the PHY bus (t+1) -> register at cyc == t+WL
        pend_q[wp_q].slot <= wr_idx_i;
        pend_q[wp_q].cpl  <= wr_cpl_idx_i;
        pend_q[wp_q].due  <= cyc_i + tp_i.wl[HBM_CYC_W-1:0];
        wp_q <= (wp_q == PW'(PEND_DEPTH-1)) ? '0 : (wp_q + 1'b1);
        if (!WR_ACK_AT_DATA) begin
          wr_done_valid_o <= 1'b1;
          wr_done_idx_o   <= wr_cpl_idx_i;
        end
      end
      if (pend_pop) begin
        wdata_valid_o <= 1'b1;
        wdata_o       <= data_q[pend_q[rp_q].slot];
        wmask_o       <= mask_q[pend_q[rp_q].slot];
        rp_q <= (rp_q == PW'(PEND_DEPTH-1)) ? '0 : (rp_q + 1'b1);
        if (WR_ACK_AT_DATA) begin
          wr_done_valid_o <= 1'b1;
          wr_done_idx_o   <= pend_q[rp_q].cpl;
        end
      end
      case ({pend_push, pend_pop})
        2'b10:   cnt_q <= cnt_q + 1'b1;
        2'b01:   cnt_q <= cnt_q - 1'b1;
        default: cnt_q <= cnt_q;
      endcase
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    if (pend_push && !can_issue_o) $error("[%m] WR issued with a full pending FIFO (data could not be delivered in time)");
    if (tp_i.wl == 16'd0)          $error("[%m] write latency 0 is not supported");
    // the head must never be late: dues are monotonic because WL is fixed
    if ((cnt_q != '0) && !pend_head_due && ((cyc_i - pend_q[rp_q].due) < 16'h8000) && (cyc_i != pend_q[rp_q].due))
      $error("[%m] write data missed its due cycle (head due %0d now %0d)", pend_q[rp_q].due, cyc_i);
  end
`endif
endmodule : sf_hbm_write_data
