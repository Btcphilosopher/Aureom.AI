// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_cdc_fifo.sv
//  Asynchronous (dual-clock) FIFO: Gray-coded pointers, 2-flop synchronisers, registered full/empty.
//  Used wherever two HBMCore clock domains meet (docs/CDC_AND_CLOCKS.md): DataFabric clock <-> controller clock,
//  controller clock <-> PHY clock (when the PHY contract needs a ratio converter), CSR clock <-> controller.
//
//  CONTRACT
//    * DEPTH must be a power of two >= 4. Data moves in order; every pushed word is popped exactly once.
//    * push is IGNORED when full_o is high, pop is IGNORED when empty_o is high (no overflow / underflow
//      corruption; the SVA below flags the misuse in simulation).
//    * full_o is generated in the WRITE domain and is pessimistic (a freed slot becomes visible after the
//      read pointer crosses); empty_o is generated in the READ domain and is pessimistic likewise. Neither
//      ever reports "space" / "data" that is not there.
//    * rdata_o is FIRST-WORD-FALL-THROUGH: valid whenever !empty_o, stable until pop.
//  RESET: each domain has its OWN active-low asynchronous reset (wrst_n / rrst_n). Reset-domain crossing rule:
//  assert BOTH resets together and de-assert each synchronously to its own clock (use sf_hbm_rst_sync).
//  STATUS: verified by verification/tests/tb_cdc_fifo.sv (five unrelated clock ratios, random stalls, two mid-run resets) and by the
//  formal harness verification/formal/fv_cdc_fifo.sv (pointer algebra, overflow, underflow, data order; unbounded PDR proofs on a
//  REDUCED-depth model under the stated assumptions, plus bounded multi-clock BMC; see docs/FORMAL.md). Metastability itself
//  is a circuit property no RTL simulation or formal run of this kind can show.
// =============================================================================
module sf_hbm_cdc_fifo #(
  parameter int unsigned WIDTH = 32,
  parameter int unsigned DEPTH = 8
) (
  input  logic             wclk_i,
  input  logic             wrst_n_i,
  input  logic             push_i,
  input  logic [WIDTH-1:0] wdata_i,
  output logic             full_o,

  input  logic             rclk_i,
  input  logic             rrst_n_i,
  input  logic             pop_i,
  output logic [WIDTH-1:0] rdata_o,
  output logic             empty_o
);
  localparam int unsigned AW = $clog2(DEPTH);
  if (DEPTH < 4 || (DEPTH & (DEPTH - 1)) != 0) begin : g_chk
    $error("sf_hbm_cdc_fifo: DEPTH must be a power of two >= 4");
  end

  logic [WIDTH-1:0] mem [DEPTH];

  logic [AW:0] wbin_q, wgray_q, rbin_q, rgray_q;
  logic [AW:0] rgray_w1, rgray_w2;      // read pointer synchronised into the write domain
  logic [AW:0] wgray_r1, wgray_r2;      // write pointer synchronised into the read domain

  function automatic logic [AW:0] bin2gray(input logic [AW:0] b); return b ^ (b >> 1); endfunction

  // ---- write domain -------------------------------------------------------------
  wire [AW:0] wbin_next  = wbin_q + (AW+1)'(push_i && !full_o);
  wire [AW:0] wgray_next = bin2gray(wbin_next);
  // full: next write gray equals read gray with the two MSBs inverted
  wire        full_next  = (wgray_next == {~rgray_w2[AW:AW-1], rgray_w2[AW-2:0]});

  always_ff @(posedge wclk_i or negedge wrst_n_i) begin
    if (!wrst_n_i) begin
      wbin_q <= '0; wgray_q <= '0; full_o <= 1'b0; rgray_w1 <= '0; rgray_w2 <= '0;
    end else begin
      rgray_w1 <= rgray_q; rgray_w2 <= rgray_w1;
      if (push_i && !full_o) mem[wbin_q[AW-1:0]] <= wdata_i;
      wbin_q  <= wbin_next;
      wgray_q <= wgray_next;
      full_o  <= full_next;
    end
  end

  // ---- read domain --------------------------------------------------------------
  wire [AW:0] rbin_next  = rbin_q + (AW+1)'(pop_i && !empty_o);
  wire [AW:0] rgray_next = bin2gray(rbin_next);
  wire        empty_next = (rgray_next == wgray_r2);

  always_ff @(posedge rclk_i or negedge rrst_n_i) begin
    if (!rrst_n_i) begin
      rbin_q <= '0; rgray_q <= '0; empty_o <= 1'b1; wgray_r1 <= '0; wgray_r2 <= '0;
    end else begin
      wgray_r1 <= wgray_q; wgray_r2 <= wgray_r1;
      rbin_q  <= rbin_next;
      rgray_q <= rgray_next;
      empty_o <= empty_next;
    end
  end
  assign rdata_o = mem[rbin_q[AW-1:0]];

`ifndef SYNTHESIS
  always @(posedge wclk_i) if (wrst_n_i && push_i && full_o)  $error("[%m] push while full (ignored)");
  always @(posedge rclk_i) if (rrst_n_i && pop_i && empty_o)  $error("[%m] pop while empty (ignored)");
`endif
endmodule : sf_hbm_cdc_fifo

// -----------------------------------------------------------------------------
//  sf_hbm_rst_sync : asynchronous assertion, synchronous de-assertion (2 flops).
//  Reset-domain crossing rule of HBMCore: every clock domain gets its own instance fed by the SAME
//  asynchronous source reset, so all domains enter reset together and leave it in their own clock.
// -----------------------------------------------------------------------------
module sf_hbm_rst_sync (
  input  logic clk_i,
  input  logic arst_n_i,
  output logic srst_n_o
);
  logic q1, q2;
  always_ff @(posedge clk_i or negedge arst_n_i) begin
    if (!arst_n_i) begin q1 <= 1'b0; q2 <= 1'b0; end
    else           begin q1 <= 1'b1; q2 <= q1; end
  end
  assign srst_n_o = q2;
endmodule : sf_hbm_rst_sync
