// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_stack_cluster.sv
//  A physically-manageable GROUP of NCH channels (each = 2 pseudo-channels) with one cluster-level
//  response arbiter. The 32-channel HBM4 reference is built from NUM_CLUSTERS of these instead of one
//  monolithic 2048-bit structure (docs/PHYSICAL_DESIGN.md): each cluster owns its slice of the PHY-side
//  bundle, so the request broadcast, the response mux and the PHY fan-in are all cluster-local.
//
//  Pseudo-channel local index = ch_local * PCS + pc. Everything below the cluster is independent.
//  RESET: async assert (passed down).
// =============================================================================
module sf_hbm_stack_cluster
  import sf_hbm_pkg::*;
#(
  parameter int unsigned NCH            = 8,
  parameter int unsigned PCS            = 2,
  parameter int unsigned DEPTH          = 16,
  parameter int unsigned CPL_DEPTH      = 8,
  parameter int unsigned PHY_BACKEND    = 0,
  parameter int unsigned PHY_CMD_LAT    = 0,
  parameter int unsigned PHY_RD_LAT     = 0,
  parameter bit          WR_ACK_AT_DATA = 1'b1
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  input  hbm_timing_t                  tp_i,
  input  hbm_sched_cfg_t               sched_cfg_i,
  input  hbm_ref_cfg_t                 ref_cfg_i,
  input  logic                         ecc_en_i,
  input  logic                         ctrl_enable_i,
  input  logic [1:0]                   pwr_req_i,
  input  logic [15:0]                  pd_idle_i,
  input  logic [15:0]                  sr_idle_i,
  input  logic                         init_mrs_valid_i,
  input  logic [7:0]                   init_mrs_code_i,
  output logic                         init_mrs_ack_o,
  input  logic                         ecc_clear_i,
  input  logic [NCH*PCS-1:0]           inj_arm_i,
  input  logic [1:0]                   inj_mode_i,
  input  logic [8:0]                   inj_bit_i,

  input  logic                         req_valid_i,
  input  logic [$clog2(NCH*PCS > 1 ? NCH*PCS : 2)-1:0] req_pc_i,   // local {ch,pc}
  output logic                         req_ready_o,
  input  hbm_txn_t                     req_txn_i,
  input  hbm_data_t                    req_wdata_i,
  input  hbm_mask_t                    req_wmask_i,

  output logic                         rsp_valid_o,
  input  logic                         rsp_ready_i,
  output hbm_rsp_t                     rsp_o,

  input  logic [NCH*PCS-1:0]           phy_ready_ext_i,
  input  logic [NCH*PCS-1:0]           phy_event_i,
  input  logic [NCH*PCS-1:0]           ondie_event_i,
  output logic [NCH*PCS-1:0]           sim_cmd_valid_o,
  output hbm_cmd_t [NCH*PCS-1:0]       sim_cmd_o,
  output logic [NCH*PCS-1:0]           sim_wvalid_o,
  output hbm_data_t [NCH*PCS-1:0]      sim_wdata_o,
  output hbm_mask_t [NCH*PCS-1:0]      sim_wmask_o,
  output hbm_ecc_t [NCH*PCS-1:0]       sim_wecc_o,
  input  logic [NCH*PCS-1:0]           sim_rvalid_i,
  input  hbm_data_t [NCH*PCS-1:0]      sim_rdata_i,
  input  hbm_ecc_t [NCH*PCS-1:0]       sim_recc_i,
  input  logic [NCH*PCS-1:0]           sim_rerr_i,

  output hbm_pc_stat_t [NCH*PCS-1:0]   stat_o
);
  localparam int unsigned NPC = NCH * PCS;
  localparam int unsigned CW  = (NCH > 1) ? $clog2(NCH) : 1;

  logic [NCH-1:0]      ch_req_valid, ch_req_ready, ch_rsp_valid, ch_rsp_ready, ch_mrs_ack;
  hbm_rsp_t [NCH-1:0]  ch_rsp;

  logic [CW-1:0] sel_ch;
  logic          sel_pc;
  assign sel_ch = (NCH > 1) ? req_pc_i[$clog2(NCH*PCS > 1 ? NCH*PCS : 2)-1 : (PCS > 1 ? 1 : 0)] : '0;
  assign sel_pc = (PCS > 1) ? req_pc_i[0] : 1'b0;

  always_comb begin
    ch_req_valid = '0;
    ch_req_valid[sel_ch] = req_valid_i;
    req_ready_o = ch_req_ready[sel_ch];
  end
  assign init_mrs_ack_o = &ch_mrs_ack;

  for (genvar c = 0; c < NCH; c++) begin : g_ch
    sf_hbm_channel #(
      .PCS(PCS), .DEPTH(DEPTH), .CPL_DEPTH(CPL_DEPTH), .PHY_BACKEND(PHY_BACKEND),
      .PHY_CMD_LAT(PHY_CMD_LAT), .PHY_RD_LAT(PHY_RD_LAT), .WR_ACK_AT_DATA(WR_ACK_AT_DATA)
    ) u_ch (
      .clk_i, .rst_ni, .tp_i, .sched_cfg_i, .ref_cfg_i, .ecc_en_i, .ctrl_enable_i,
      .pwr_req_i, .pd_idle_i, .sr_idle_i,
      .init_mrs_valid_i, .init_mrs_code_i, .init_mrs_ack_o(ch_mrs_ack[c]),
      .ecc_clear_i, .inj_arm_i(inj_arm_i[c*PCS +: PCS]), .inj_mode_i, .inj_bit_i,
      .req_valid_i(ch_req_valid[c]), .req_pc_i(sel_pc), .req_ready_o(ch_req_ready[c]),
      .req_txn_i, .req_wdata_i, .req_wmask_i,
      .rsp_valid_o(ch_rsp_valid[c]), .rsp_ready_i(ch_rsp_ready[c]), .rsp_o(ch_rsp[c]),
      .phy_ready_ext_i(phy_ready_ext_i[c*PCS +: PCS]), .phy_event_i(phy_event_i[c*PCS +: PCS]),
      .ondie_event_i(ondie_event_i[c*PCS +: PCS]),
      .sim_cmd_valid_o(sim_cmd_valid_o[c*PCS +: PCS]), .sim_cmd_o(sim_cmd_o[c*PCS +: PCS]),
      .sim_wvalid_o(sim_wvalid_o[c*PCS +: PCS]), .sim_wdata_o(sim_wdata_o[c*PCS +: PCS]),
      .sim_wmask_o(sim_wmask_o[c*PCS +: PCS]), .sim_wecc_o(sim_wecc_o[c*PCS +: PCS]),
      .sim_rvalid_i(sim_rvalid_i[c*PCS +: PCS]), .sim_rdata_i(sim_rdata_i[c*PCS +: PCS]),
      .sim_recc_i(sim_recc_i[c*PCS +: PCS]), .sim_rerr_i(sim_rerr_i[c*PCS +: PCS]),
      .stat_o(stat_o[c*PCS +: PCS])
    );
  end

  sf_hbm_rsp_arb #(.N(NCH)) u_arb (
    .clk_i, .rst_ni,
    .in_valid_i(ch_rsp_valid), .in_rsp_i(ch_rsp), .in_ready_o(ch_rsp_ready),
    .out_valid_o(rsp_valid_o), .out_rsp_o(rsp_o), .out_ready_i(rsp_ready_i), .sel_o()
  );
endmodule : sf_hbm_stack_cluster
