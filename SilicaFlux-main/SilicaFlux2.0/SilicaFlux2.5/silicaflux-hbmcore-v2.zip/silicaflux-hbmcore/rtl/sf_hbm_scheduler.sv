// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_scheduler.sv
//  Per-pseudo-channel memory command scheduler.
//
//  Picks ONE legal command per cycle from (a) maintenance (refresh / init / power),
//  (b) pending demand transactions, (c) proactive precharge. A command is legal only
//  if bank-local rules (sf_hbm_bank_fsm), cross-bank rules (sf_hbm_timing), resource
//  credits (completion slot, write-data pending slot, PHY ready) and refresh holds all
//  allow it. PRIORITY NEVER BYPASSES A TIMING RULE: priority only ranks commands that
//  are already legal.
//
//  DEMAND COMMAND DERIVATION (per entry, row-miss path of docs/SCHEDULER.md)
//      bank open on target row  -> column command (RD/WR)        [row hit]
//      bank open on other row   -> PRE, then ACT, then column    [row conflict]
//      bank precharged          -> ACT, then column               [row empty]
//
//  POLICIES (cfg_i.policy)
//      FCFS     only the oldest queued entry may issue; strict in-order command issue.
//      FRFCFS   among LEGAL entries prefer column commands (row hits), then oldest.
//               PRE is withheld from a bank while another unblocked entry still hits its row.
//      BGAWARE  FRFCFS + prefer a column command to a different bank group than the last one
//               (avoids the tCCD_L / tWTR_L penalties).
//  MODIFIERS (priority tiers, MSB = strongest):
//      [6] urgent    age >= starve_limit (anti-starvation, 0 = off)
//      [5] deadline  deadline_en && QOS_RT && age >= deadline_thr
//      [4:3] qos     prio_en ? qos : 0
//      [2] batch     entry direction == current batch direction (read/write batching)
//      [1] colhit    FRFCFS/BGAWARE: command is a column command
//      [0] bgdiff    BGAWARE: column command to a bank group != previous column command
//  Within the winning tier the OLDEST entry wins (exact order from the queue's age matrix).
//  Dependency-blocked entries (queue scoreboard) are never candidates.
//
//  OPEN/CLOSE PAGE: PAGE_OPEN leaves rows open; PAGE_CLOSE / PAGE_TIMEOUT issue a proactive
//  PRE for a bank that no queued entry (blocked or not) wants.
//
//  ROW-HIT ACCOUNTING: when an entry's column command issues it is a HIT if no ACT/PRE was ever
//  issued on its behalf, else a MISS (EMPTY if its first command was ACT, CONFLICT if PRE).
//
//  Combinational selection, registered state only for batching/idle timers/accounting.
//  RESET: async assert.   KNOWN LIMITATIONS: single command per cycle; selection is one
//  combinational stage (see docs/PHYSICAL_DESIGN.md for the pipelining plan).
// =============================================================================
module sf_hbm_scheduler
  import sf_hbm_pkg::*;
#(
  parameter int unsigned DEPTH = 16,
  parameter int unsigned AGE_W = 16
) (
  input  logic                              clk_i,
  input  logic                              rst_ni,
  input  hbm_sched_cfg_t                    cfg_i,

  // request queue view
  input  logic [DEPTH-1:0]                  ent_valid_i,
  input  hbm_txn_t [DEPTH-1:0]              ent_txn_i,
  input  logic [DEPTH-1:0]                  ent_blocked_i,
  input  logic [DEPTH-1:0][DEPTH-1:0]       ent_older_i,
  input  logic [DEPTH-1:0][AGE_W-1:0]       ent_age_i,

  // bank view
  input  logic [HBM_NUM_BANKS-1:0]          bk_row_open_i,
  input  logic [HBM_NUM_BANKS-1:0]          bk_can_act_i,
  input  logic [HBM_NUM_BANKS-1:0]          act_block_i,      // v2: demand ACT blocked (sf_hbm_rfm, RAA >= raammt); maintenance unaffected
  input  logic [HBM_NUM_BANKS-1:0]          bk_can_rd_i,
  input  logic [HBM_NUM_BANKS-1:0]          bk_can_wr_i,
  input  logic [HBM_NUM_BANKS-1:0]          bk_can_pre_i,
  input  logic [HBM_NUM_BANKS-1:0]          bk_idle_i,
  input  hbm_row_t [HBM_NUM_BANKS-1:0]      bk_open_row_i,

  // cross-bank timing view
  input  logic [HBM_NUM_BG-1:0]             tm_ok_act_i,
  input  logic [HBM_NUM_BG-1:0]             tm_ok_rd_i,
  input  logic [HBM_NUM_BG-1:0]             tm_ok_wr_i,
  input  logic                              tm_ok_ref_i,
  input  logic                              tm_ok_misc_i,

  // resource credits
  input  logic                              cpl_credit_i,
  input  logic                              wr_credit_i,
  input  logic                              phy_ready_i,

  // maintenance (refresh / init / power) - highest-priority legal source
  input  logic                              mnt_valid_i,
  input  hbm_cmd_t                          mnt_cmd_i,
  input  logic                              mnt_prio_i,        // 1: maintenance beats demand when legal
  output logic                              mnt_grant_o,
  input  logic                              hold_act_i,        // refresh/power: no new ACT
  input  logic                              hold_col_i,        // refresh urgent: no new column command
  input  logic                              hold_bank_valid_i, // per-bank refresh: target bank held
  input  logic [HBM_BANK_W-1:0]             hold_bank_i,
  input  logic                              hold_bank_col_i,   //   ...also block column commands to it

  // issue
  output logic                              issue_valid_o,     // a PHY command issues this cycle
  output hbm_cmd_t                          issue_cmd_o,
  output logic                              issue_col_o,       // column command for entry issue_idx_o
  output logic                              issue_err_o,       // error-entry completion (no PHY command)
  output logic [$clog2(DEPTH)-1:0]          issue_idx_o,

  // accounting pulses
  output logic                              ev_row_hit_o,
  output logic                              ev_row_empty_o,
  output logic                              ev_row_conflict_o,
  output logic                              ev_act_o,
  output logic                              ev_pre_o,
  output logic                              ev_timing_stall_o,
  output logic                              ev_ref_stall_o,
  output logic                              ev_bypass_o,
  output logic                              ev_qos_stall_o,
  output logic                              ev_phy_stall_o,
  output logic                              ev_demand_pending_o
);
  localparam int unsigned IW = $clog2(DEPTH);
  localparam int unsigned NB = HBM_NUM_BANKS;

  // --------------------------------------------------------------------------
  // registered scheduler state
  // --------------------------------------------------------------------------
  logic [DEPTH-1:0] touched_q;      // an ACT/PRE has been issued on behalf of this entry
  logic [DEPTH-1:0] conflict_q;     // ... and the first one was a PRE
  logic             cur_dir_q;      // batching: 0 reads, 1 writes
  logic [7:0]       batch_cnt_q;
  hbm_bg_t          last_bg_q;
  logic [15:0]      idle_cnt_q [NB];

  // --------------------------------------------------------------------------
  // per-entry analysis
  // --------------------------------------------------------------------------
  logic [DEPTH-1:0] cand, legal, is_err, is_hit, is_open;
  logic [DEPTH-1:0] need_col, need_pre, need_act;
  logic [DEPTH-1:0] oldest_valid;
  logic [NB-1:0]    hit_pending, any_pending;
  logic [DEPTH-1:0][HBM_BANK_W-1:0] bank_of;

  always_comb begin
    hit_pending = '0;
    any_pending = '0;
    for (int i = 0; i < DEPTH; i++) begin
      bank_of[i]      = {ent_txn_i[i].bg, ent_txn_i[i].ba};
      is_err[i]       = (ent_txn_i[i].err != HERR_NONE);
      is_open[i]      = bk_row_open_i[bank_of[i]];
      is_hit[i]       = is_open[i] && (bk_open_row_i[bank_of[i]] == ent_txn_i[i].row);
      oldest_valid[i] = ent_valid_i[i] && ((ent_older_i[i] & ent_valid_i) == '0);
      cand[i]         = ent_valid_i[i] && !ent_blocked_i[i] &&
                        ((cfg_i.policy != SCHED_FCFS) || oldest_valid[i]);
      need_col[i]     = !is_err[i] && is_hit[i];
      need_pre[i]     = !is_err[i] && is_open[i] && !is_hit[i];
      need_act[i]     = !is_err[i] && !is_open[i];
    end
    for (int i = 0; i < DEPTH; i++) begin
      if (ent_valid_i[i] && !is_err[i] && is_hit[i])
        any_pending[bank_of[i]] = 1'b1;
      if (cand[i] && !is_err[i] && is_hit[i])
        hit_pending[bank_of[i]] = 1'b1;
    end
  end

  // --------------------------------------------------------------------------
  // legality of each entry's NEXT command
  // --------------------------------------------------------------------------
  logic [DEPTH-1:0] leg_col, leg_act, leg_pre;
  logic [DEPTH-1:0] starve, dl_urg, boost;   // boost = anti-starvation OR QoS-deadline urgent: top tiers AND overrides PRE protection
  always_comb begin
    for (int i = 0; i < DEPTH; i++) begin
      starve[i] = (cfg_i.starve_limit != 16'd0) && (16'(ent_age_i[i]) >= cfg_i.starve_limit);
      dl_urg[i] = cfg_i.deadline_en && (ent_txn_i[i].qos == QOS_RT) && (16'(ent_age_i[i]) >= cfg_i.deadline_thr);
      boost[i]  = starve[i] || dl_urg[i];
    end
  end
  // DRAIN: while a boosted entry needs to PRECHARGE bank b, no NEW row hit may start on b (except boosted hits). Without this,
  // a hit stream re-arms tRTP / tWR on every column command and a PRE can stay illegal for ever when tRTP > tCCD_L
  // (observed on the sim_strict profile: with starve_limit = 60 the starving request still waited behind the whole flood).
  // v2 (independent review A1): the drain applies to every entry YOUNGER than a boosted entry that needs PRE on the same
  // bank - boosted or not. The v1 rule exempted boosted hits, so once the hits themselves had queued longer than
  // starve_limit they were boosted too and kept re-arming tRTP: the starving request waited for the whole flood.
  logic [DEPTH-1:0] drain_src;                  // boosted entries waiting to PRECHARGE their bank
  logic [DEPTH-1:0] drained;                    // entry i may not start a column command (an older boosted PRE waits on its bank)
  always_comb begin
    for (int j = 0; j < DEPTH; j++)
      drain_src[j] = (cfg_i.policy != SCHED_FCFS) && cand[j] && boost[j] && need_pre[j];
    for (int i = 0; i < DEPTH; i++) begin
      drained[i] = 1'b0;
      for (int j = 0; j < DEPTH; j++)
        if (drain_src[j] && ent_older_i[i][j] && (bank_of[j] == bank_of[i])) drained[i] = 1'b1;
    end
  end
  always_comb begin
    for (int i = 0; i < DEPTH; i++) begin
      logic [HBM_BANK_W-1:0] b;
      hbm_bg_t               g;
      logic                  held_bank;
      b = bank_of[i];
      g = ent_txn_i[i].bg;
      held_bank = hold_bank_valid_i && (hold_bank_i == b);

      leg_col[i] = ent_txn_i[i].write
                     ? (bk_can_wr_i[b] && tm_ok_wr_i[g] && wr_credit_i)
                     : (bk_can_rd_i[b] && tm_ok_rd_i[g]);
      leg_col[i] = leg_col[i] && cpl_credit_i && phy_ready_i && !hold_col_i &&
                   !(held_bank && hold_bank_col_i) && !drained[i];

      leg_act[i] = bk_can_act_i[b] && !act_block_i[b] && tm_ok_act_i[g] && phy_ready_i && !hold_act_i && !held_bank;

      // PRE protection ("do not close a row that still has pending hits") is OVERRIDDEN for a starving / deadline-urgent
      // entry: otherwise a continuous stream of row hits could postpone a conflicting request forever and starve_limit would be useless
      leg_pre[i] = bk_can_pre_i[b] && phy_ready_i && !held_bank &&
                   ((cfg_i.policy == SCHED_FCFS) || !hit_pending[b] || boost[i]);

      legal[i] = cand[i] && (is_err[i] ? cpl_credit_i :
                             (need_col[i] ? leg_col[i] :
                              (need_pre[i] ? leg_pre[i] : leg_act[i])));
    end
  end

  // --------------------------------------------------------------------------
  // priority tiers
  // --------------------------------------------------------------------------
  logic [6:0] tier [DEPTH];
  always_comb begin
    for (int i = 0; i < DEPTH; i++) begin
      logic batch, colhit, bgdiff;
      batch  = cfg_i.batch_en && (ent_txn_i[i].write == cur_dir_q);
      colhit = (cfg_i.policy != SCHED_FCFS) && (need_col[i] || is_err[i]);
      bgdiff = (cfg_i.policy == SCHED_BGAWARE) && need_col[i] && (ent_txn_i[i].bg != last_bg_q);
      // v2 (A1 variant): inside the boosted tiers the ORDER is age only - a boosted column hit must not outrank an older
      // boosted entry's PRE on the shared command bus
      tier[i] = {starve[i], dl_urg[i],
                 (starve[i] || dl_urg[i]) ? 5'b0 : {(cfg_i.prio_en ? ent_txn_i[i].qos : 2'b00), batch, colhit, bgdiff}};
    end
  end

  logic [DEPTH-1:0] narrowed, sub;
  logic [DEPTH-1:0] sel_oh, oldest_legal_oh;
  logic             have_demand;
  logic [IW-1:0]    sel_idx, oldest_legal_idx;

  always_comb begin
    narrowed = legal;
    for (int k = 6; k >= 0; k--) begin
      sub = '0;
      for (int i = 0; i < DEPTH; i++) sub[i] = narrowed[i] && tier[i][k];
      if (|sub) narrowed = sub;
    end
    sel_oh = '0;
    oldest_legal_oh = '0;
    for (int i = 0; i < DEPTH; i++) begin
      sel_oh[i]          = narrowed[i] && ((ent_older_i[i] & narrowed) == '0);
      oldest_legal_oh[i] = legal[i]    && ((ent_older_i[i] & legal)    == '0);
    end
    have_demand      = |legal;
    sel_idx          = '0;
    oldest_legal_idx = '0;
    for (int i = 0; i < DEPTH; i++) begin
      if (sel_oh[i])          sel_idx          = IW'(i);
      if (oldest_legal_oh[i]) oldest_legal_idx = IW'(i);
    end
  end

  // --------------------------------------------------------------------------
  // maintenance legality
  // --------------------------------------------------------------------------
  logic mnt_leg;
  logic all_idle, prea_ok;
  logic [HBM_BANK_W-1:0] mbank;
  always_comb begin
    all_idle = &bk_idle_i;
    prea_ok  = 1'b1;
    for (int b = 0; b < NB; b++)
      if (bk_row_open_i[b] && !bk_can_pre_i[b]) prea_ok = 1'b0;
    mbank = {mnt_cmd_i.bg, mnt_cmd_i.ba};
    case (mnt_cmd_i.cmd)
      HCMD_PREA:   mnt_leg = prea_ok && tm_ok_misc_i;
      HCMD_PRE:    mnt_leg = (!bk_row_open_i[mbank] || bk_can_pre_i[mbank]) && tm_ok_misc_i;
      // v2 (independent review A2): refresh also needs tRC since the bank's last ACT (bk_can_act = idle && tRC elapsed).
      // v1 used bk_idle only; hidden because every shipped profile had tRC == tRAS + tRP exactly.
      HCMD_REF_AB: mnt_leg = (&bk_can_act_i) && tm_ok_ref_i;
      HCMD_REF_PB: mnt_leg = bk_can_act_i[mbank] && tm_ok_ref_i;
      HCMD_MRS:    mnt_leg = all_idle && tm_ok_ref_i;
      HCMD_RFM:    mnt_leg = bk_can_act_i[mbank] && tm_ok_ref_i;      // v2: per-bank, like REF_PB (sf_hbm_rfm)
      HCMD_PDE,
      HCMD_SRE:    mnt_leg = all_idle && tm_ok_misc_i;
      HCMD_PDX,
      HCMD_SRX:    mnt_leg = 1'b1;
      default:     mnt_leg = 1'b0;
    endcase
    mnt_leg = mnt_leg && mnt_valid_i && (phy_ready_i || (mnt_cmd_i.cmd == HCMD_PDX) || (mnt_cmd_i.cmd == HCMD_SRX));
  end
  assign mnt_grant_o = mnt_leg && (mnt_prio_i || !have_demand);

  // --------------------------------------------------------------------------
  // proactive precharge (close-page / timeout policies)
  // --------------------------------------------------------------------------
  logic [NB-1:0] want_close;
  logic          have_close;
  logic [HBM_BANK_W-1:0] close_bank;
  always_comb begin
    have_close = 1'b0;
    close_bank = '0;
    want_close = '0;
    for (int b = 0; b < NB; b++) begin
      logic held_b;
      held_b = hold_bank_valid_i && (hold_bank_i == HBM_BANK_W'(b));
      want_close[b] = bk_row_open_i[b] && !any_pending[b] && bk_can_pre_i[b] && !held_b && phy_ready_i &&
                      ((cfg_i.page == PAGE_CLOSE) ||
                       ((cfg_i.page == PAGE_TIMEOUT) && (idle_cnt_q[b] >= cfg_i.close_timeout)));
    end
    for (int b = NB-1; b >= 0; b--)
      if (want_close[b]) begin have_close = 1'b1; close_bank = HBM_BANK_W'(b); end
  end

  // --------------------------------------------------------------------------
  // issue decision
  // --------------------------------------------------------------------------
  wire demand_go = have_demand && !mnt_grant_o;
  wire close_go  = have_close && !mnt_grant_o && !have_demand;

  hbm_txn_t sel_txn;
  assign sel_txn = ent_txn_i[sel_idx];

  always_comb begin
    issue_valid_o = 1'b0;
    issue_cmd_o   = '0;
    issue_col_o   = 1'b0;
    issue_err_o   = 1'b0;
    issue_idx_o   = sel_idx;
    if (mnt_grant_o) begin
      issue_valid_o = 1'b1;
      issue_cmd_o   = mnt_cmd_i;
    end else if (demand_go) begin
      issue_idx_o = sel_idx;
      if (is_err[sel_idx]) begin
        issue_err_o = 1'b1;
      end else if (need_col[sel_idx]) begin
        issue_valid_o  = 1'b1;
        issue_col_o    = 1'b1;
        issue_cmd_o.cmd = sel_txn.write ? HCMD_WR : HCMD_RD;
        issue_cmd_o.bg  = sel_txn.bg;  issue_cmd_o.ba = sel_txn.ba;
        issue_cmd_o.row = sel_txn.row; issue_cmd_o.col = sel_txn.col;
      end else if (need_pre[sel_idx]) begin
        issue_valid_o  = 1'b1;
        issue_cmd_o.cmd = HCMD_PRE;
        issue_cmd_o.bg  = sel_txn.bg;  issue_cmd_o.ba = sel_txn.ba;
        issue_cmd_o.row = bk_open_row_i[bank_of[sel_idx]];
      end else begin
        issue_valid_o  = 1'b1;
        issue_cmd_o.cmd = HCMD_ACT;
        issue_cmd_o.bg  = sel_txn.bg;  issue_cmd_o.ba = sel_txn.ba;
        issue_cmd_o.row = sel_txn.row;
      end
    end else if (close_go) begin
      issue_valid_o   = 1'b1;
      issue_cmd_o.cmd = HCMD_PRE;
      issue_cmd_o.bg  = hbm_bg_t'(close_bank[HBM_BANK_W-1 -: HBM_BG_W]);
      issue_cmd_o.ba  = hbm_ba_t'(close_bank[HBM_BA_W-1:0]);
      issue_cmd_o.row = bk_open_row_i[close_bank];
    end
  end

  // --------------------------------------------------------------------------
  // accounting events
  // --------------------------------------------------------------------------
  wire demand_col = demand_go && !is_err[sel_idx] && need_col[sel_idx];
  wire demand_act = demand_go && !is_err[sel_idx] && need_act[sel_idx];
  wire demand_pre = demand_go && !is_err[sel_idx] && need_pre[sel_idx];

  wire any_cand = |cand;
  assign ev_demand_pending_o = |ent_valid_i;
  assign ev_row_hit_o      = demand_col && !touched_q[sel_idx];
  assign ev_row_empty_o    = demand_col &&  touched_q[sel_idx] && !conflict_q[sel_idx];
  assign ev_row_conflict_o = demand_col &&  touched_q[sel_idx] &&  conflict_q[sel_idx];
  assign ev_act_o          = (mnt_grant_o ? 1'b0 : demand_act);
  assign ev_pre_o          = (mnt_grant_o ? 1'b0 : (demand_pre || close_go));
  wire   nothing_issued    = !issue_valid_o && !issue_err_o;
  assign ev_phy_stall_o    = any_cand && !phy_ready_i && nothing_issued;
  assign ev_ref_stall_o    = any_cand && nothing_issued && phy_ready_i && (hold_act_i || hold_col_i || hold_bank_valid_i);
  assign ev_timing_stall_o = any_cand && nothing_issued && phy_ready_i && !(hold_act_i || hold_col_i || hold_bank_valid_i);
  assign ev_bypass_o       = demand_go && (oldest_legal_idx != sel_idx);
  assign ev_qos_stall_o    = ev_bypass_o && cfg_i.prio_en &&
                             (ent_txn_i[oldest_legal_idx].qos < ent_txn_i[sel_idx].qos);

  // --------------------------------------------------------------------------
  // registered state
  // --------------------------------------------------------------------------
  logic [1:0] dir_work;
  always_comb begin
    dir_work = '0;
    for (int i = 0; i < DEPTH; i++)
      if (cand[i] && !is_err[i]) dir_work[ent_txn_i[i].write] = 1'b1;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      touched_q <= '0; conflict_q <= '0;
      cur_dir_q <= 1'b0; batch_cnt_q <= '0; last_bg_q <= '0;
      for (int b = 0; b < NB; b++) idle_cnt_q[b] <= '0;
    end else begin
      // per-bank idle timers (row open and nobody wants it)
      for (int b = 0; b < NB; b++) begin
        if (bk_row_open_i[b] && !any_pending[b]) begin
          if (idle_cnt_q[b] != 16'hFFFF) idle_cnt_q[b] <= idle_cnt_q[b] + 16'd1;
        end else idle_cnt_q[b] <= '0;
      end

      // row accounting
      if (demand_act || demand_pre) begin
        if (!touched_q[sel_idx]) conflict_q[sel_idx] <= demand_pre;
        touched_q[sel_idx] <= 1'b1;
      end
      if (issue_col_o || issue_err_o) begin
        touched_q[sel_idx]  <= 1'b0;
        conflict_q[sel_idx] <= 1'b0;
      end

      // batching direction
      if (cfg_i.batch_en) begin
        if (!dir_work[cur_dir_q] && dir_work[~cur_dir_q]) begin
          cur_dir_q <= ~cur_dir_q; batch_cnt_q <= '0;
        end else if ((batch_cnt_q >= cfg_i.batch_len) && dir_work[~cur_dir_q]) begin
          cur_dir_q <= ~cur_dir_q; batch_cnt_q <= '0;
        end else if (demand_col && (sel_txn.write == cur_dir_q)) begin
          if (batch_cnt_q != 8'hFF) batch_cnt_q <= batch_cnt_q + 8'd1;
        end
      end
      if (demand_col) last_bg_q <= sel_txn.bg;
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    // priority must never produce a command that the timing view forbids
    if (issue_valid_o && issue_cmd_o.cmd == HCMD_ACT &&
        !(bk_can_act_i[{issue_cmd_o.bg, issue_cmd_o.ba}] && tm_ok_act_i[issue_cmd_o.bg]))
      $error("[%m] scheduler issued an illegal ACT");
    if (issue_valid_o && issue_cmd_o.cmd == HCMD_RD &&
        !(bk_can_rd_i[{issue_cmd_o.bg, issue_cmd_o.ba}] && tm_ok_rd_i[issue_cmd_o.bg]))
      $error("[%m] scheduler issued an illegal RD");
    if (issue_valid_o && issue_cmd_o.cmd == HCMD_WR &&
        !(bk_can_wr_i[{issue_cmd_o.bg, issue_cmd_o.ba}] && tm_ok_wr_i[issue_cmd_o.bg]))
      $error("[%m] scheduler issued an illegal WR");
    if (cfg_i.policy == SCHED_FCFS && (|ent_valid_i) && !(|oldest_valid))
      $error("[%m] age matrix has no oldest entry");
  end
`endif
endmodule : sf_hbm_scheduler
