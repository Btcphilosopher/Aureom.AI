// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_req_queue.sv
//  Per-pseudo-channel request queue + ordering scoreboard.
//
//  STORAGE MODEL
//    DEPTH slots. A slot is allocated at push (lowest free index) and freed when the
//    scheduler issues the entry's column command (or error completion): rem_valid_i.
//    From that moment the transaction lives in the completion sequencer
//    (sf_hbm_read_return) until its response is accepted. A slot is NEVER overwritten
//    while valid.
//
//    The write-data buffer (sf_hbm_write_data) is indexed by the SAME slot number, so
//    "queue slot" and "write-data slot" are one resource: a write cannot be accepted
//    without its data slot, and no queue/data deadlock is possible.
//
//  ORDERING SCOREBOARD (docs/ORDERING.md)
//    On every push the new entry records, for every older valid entry j:
//        older[new][j]  = 1                        (total age order, wrap-free)
//        dep[new][j]    = hbm_conflict(new, j)     (must not issue before j)
//    Both columns clear when j is removed. blocked[i] = |dep[i].
//
//  OCCUPANCY / AGE
//    age[i] counts cycles since push (saturating) - used by anti-starvation and QoS
//    deadlines. occ/occ_rd/occ_wr feed the performance counters.
//
//  CONTRACT
//    push accepted iff push_valid_i && push_ready_o. push_idx_o is the slot the push
//    will take (stable while push_ready_o is high; used to address the data buffer).
//    No bypass: an accepted entry is visible to the scheduler the next cycle.
//  RESET: async assert; queue empty.
//  KNOWN LIMITATIONS: dependency compare is O(DEPTH) comparators per push (area grows linearly
//  in DEPTH per matrix row, quadratically in total matrix bits).
// =============================================================================
module sf_hbm_req_queue
  import sf_hbm_pkg::*;
#(
  parameter int unsigned DEPTH = 16,
  parameter int unsigned AGE_W = 16
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  input  logic                         push_valid_i,
  output logic                         push_ready_o,
  input  hbm_txn_t                     push_txn_i,
  output logic [$clog2(DEPTH)-1:0]     push_idx_o,

  input  logic                         rem_valid_i,
  input  logic [$clog2(DEPTH)-1:0]     rem_idx_i,
  input  logic [DEPTH-1:0]             hold_i,          // slots that must not be allocated (write data still owed)

  output logic [DEPTH-1:0]             ent_valid_o,
  output hbm_txn_t [DEPTH-1:0]         ent_txn_o,
  output logic [DEPTH-1:0]             ent_blocked_o,
  output logic [DEPTH-1:0][DEPTH-1:0]  ent_older_o,     // [i][j]: entry j is older than entry i
  output logic [DEPTH-1:0][AGE_W-1:0]  ent_age_o,

  output logic [$clog2(DEPTH):0]       occ_o,
  output logic [$clog2(DEPTH):0]       occ_rd_o,
  output logic [$clog2(DEPTH):0]       occ_wr_o,
  output logic                         full_o,
  output logic                         empty_o
);
  localparam int unsigned IW = $clog2(DEPTH);

  logic [DEPTH-1:0]            valid_q;
  hbm_txn_t [DEPTH-1:0]        txn_q;
  logic [DEPTH-1:0][DEPTH-1:0] dep_q, older_q;
  logic [DEPTH-1:0][AGE_W-1:0] age_q;

  // ---- allocation: lowest free slot -----------------------------------------
  logic [IW-1:0] free_idx;
  logic          any_free;
  always_comb begin
    any_free = 1'b0;
    free_idx = '0;
    for (int i = DEPTH-1; i >= 0; i--) begin
      if (!valid_q[i] && !hold_i[i]) begin any_free = 1'b1; free_idx = IW'(i); end
    end
  end
  assign push_ready_o = any_free;
  assign push_idx_o   = free_idx;
  wire   push_fire    = push_valid_i && any_free;

  // ---- new-entry relations --------------------------------------------------
  logic [DEPTH-1:0] rem_oh, conflict_vec;
  always_comb begin
    rem_oh = '0;
    if (rem_valid_i) rem_oh[rem_idx_i] = 1'b1;
    for (int j = 0; j < DEPTH; j++)
      conflict_vec[j] = valid_q[j] && !rem_oh[j] && hbm_conflict(push_txn_i, txn_q[j]);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      valid_q <= '0;
      txn_q   <= '0;
      dep_q   <= '0;
      older_q <= '0;
      age_q   <= '0;
    end else begin
      for (int i = 0; i < DEPTH; i++) begin
        if (valid_q[i] && (age_q[i] != {AGE_W{1'b1}}))
          age_q[i] <= age_q[i] + AGE_W'(1);
      end
      if (rem_valid_i) begin
        valid_q[rem_idx_i] <= 1'b0;
        for (int i = 0; i < DEPTH; i++) begin
          dep_q[i][rem_idx_i]   <= 1'b0;
          older_q[i][rem_idx_i] <= 1'b0;
        end
      end
      if (push_fire) begin
        valid_q[free_idx] <= 1'b1;
        txn_q[free_idx]   <= push_txn_i;
        age_q[free_idx]   <= '0;
        dep_q[free_idx]   <= conflict_vec;
        older_q[free_idx] <= valid_q & ~rem_oh;
      end
    end
  end

  // ---- outputs --------------------------------------------------------------
  assign ent_valid_o = valid_q;
  assign ent_txn_o   = txn_q;
  assign ent_older_o = older_q;
  assign ent_age_o   = age_q;
  always_comb begin
    for (int i = 0; i < DEPTH; i++)
      ent_blocked_o[i] = |dep_q[i];
  end

  always_comb begin
    occ_o = '0; occ_rd_o = '0; occ_wr_o = '0;
    for (int i = 0; i < DEPTH; i++) begin
      if (valid_q[i]) begin
        occ_o = occ_o + 1'b1;
        if (txn_q[i].write) occ_wr_o = occ_wr_o + 1'b1;
        else                occ_rd_o = occ_rd_o + 1'b1;
      end
    end
  end
  assign full_o  = ~any_free;
  assign empty_o = ~|valid_q;

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    if (push_valid_i && !any_free && push_fire) $error("[%m] push while full");
    if (rem_valid_i && !valid_q[rem_idx_i])     $error("[%m] removal of an invalid slot %0d", rem_idx_i);
    for (int i = 0; i < DEPTH; i++) begin
      // an entry can only depend on valid, older entries
      for (int j = 0; j < DEPTH; j++)
        if (dep_q[i][j] && !(valid_q[j] && older_q[i][j]))
          $error("[%m] dep[%0d][%0d] set without a valid older entry", i, j);
    end
  end
`endif
endmodule : sf_hbm_req_queue
