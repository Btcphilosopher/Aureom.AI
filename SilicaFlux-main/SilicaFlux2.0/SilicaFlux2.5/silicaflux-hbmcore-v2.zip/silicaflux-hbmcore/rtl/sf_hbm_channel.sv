// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_channel.sv
//  One HBM channel = PCS (2) independent pseudo-channel controllers + a locked round-robin
//  response arbiter. The two pseudo-channels share NOTHING except the response port: independent
//  command scheduling per pseudo-channel is an ENGINEERING_ASSUMPTION (docs/MISSING_SPEC.md).
//
//  req_pc_i selects the target pseudo-channel; req_ready_o is that pseudo-channel's queue-ready,
//  so back-pressure on one pseudo-channel never blocks the other once the request is steered.
//  RESET: async assert (passed down).
// =============================================================================
module sf_hbm_channel
  import sf_hbm_pkg::*;
#(
  parameter int unsigned PCS            = 2,
  parameter int unsigned DEPTH          = 16,
  parameter int unsigned CPL_DEPTH      = 8,
  parameter int unsigned PHY_BACKEND    = 0,
  parameter int unsigned PHY_CMD_LAT    = 0,
  parameter int unsigned PHY_RD_LAT     = 0,
  parameter bit          WR_ACK_AT_DATA = 1'b1
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  input  hbm_timing_t                  tp_i,
  input  hbm_sched_cfg_t               sched_cfg_i,
  input  hbm_ref_cfg_t                 ref_cfg_i,
  input  logic                         ecc_en_i,
  input  logic                         ctrl_enable_i,
  input  logic [1:0]                   pwr_req_i,
  input  logic [15:0]                  pd_idle_i,
  input  logic [15:0]                  sr_idle_i,
  input  logic                         init_mrs_valid_i,
  input  logic [7:0]                   init_mrs_code_i,
  output logic                         init_mrs_ack_o,     // AND over the channel's pseudo-channels
  input  logic                         ecc_clear_i,
  input  logic [PCS-1:0]               inj_arm_i,
  input  logic [1:0]                   inj_mode_i,
  input  logic [8:0]                   inj_bit_i,

  input  logic                         req_valid_i,
  input  logic [(PCS>1?$clog2(PCS):1)-1:0] req_pc_i,
  output logic                         req_ready_o,
  input  hbm_txn_t                     req_txn_i,
  input  hbm_data_t                    req_wdata_i,
  input  hbm_mask_t                    req_wmask_i,

  output logic                         rsp_valid_o,
  input  logic                         rsp_ready_i,
  output hbm_rsp_t                     rsp_o,

  // simulation-PHY side, one bundle per pseudo-channel
  input  logic [PCS-1:0]               phy_ready_ext_i,
  input  logic [PCS-1:0]               phy_event_i,
  input  logic [PCS-1:0]               ondie_event_i,
  output logic [PCS-1:0]               sim_cmd_valid_o,
  output hbm_cmd_t [PCS-1:0]           sim_cmd_o,
  output logic [PCS-1:0]               sim_wvalid_o,
  output hbm_data_t [PCS-1:0]          sim_wdata_o,
  output hbm_mask_t [PCS-1:0]          sim_wmask_o,
  output hbm_ecc_t [PCS-1:0]           sim_wecc_o,
  input  logic [PCS-1:0]               sim_rvalid_i,
  input  hbm_data_t [PCS-1:0]          sim_rdata_i,
  input  hbm_ecc_t [PCS-1:0]           sim_recc_i,
  input  logic [PCS-1:0]               sim_rerr_i,

  output hbm_pc_stat_t [PCS-1:0]       stat_o
);
  if (DEPTH > 63) begin : g_chk_depth
    $error("sf_hbm_channel: DEPTH must be <= 63 (6-bit occupancy in hbm_pc_stat_t)");
  end

  localparam int unsigned PW = (PCS > 1) ? $clog2(PCS) : 1;

  logic [PCS-1:0]     pc_req_valid, pc_req_ready, pc_rsp_valid, pc_rsp_ready, mrs_ack;
  hbm_rsp_t [PCS-1:0] pc_rsp;

  always_comb begin
    pc_req_valid = '0;
    pc_req_valid[req_pc_i] = req_valid_i;
    req_ready_o = pc_req_ready[req_pc_i];
  end
  assign init_mrs_ack_o = &mrs_ack;

  for (genvar p = 0; p < PCS; p++) begin : g_pc
    logic [15:0] lat;
    logic [5:0]  bytes;
    logic [5:0]  occ_w;
    logic [$clog2(DEPTH):0] occ_n;   // exactly the width of the pseudo-channel port (0..DEPTH needs clog2(DEPTH)+1 bits)
    hbm_pc_evt_t evt;
    logic [2:0]  pws;
    logic signed [7:0] debt;
    logic        quiet, unimpl, ecc_alert, ecc_lv, ecc_lue;
    logic [8:0]  ecc_lsyn;
    logic [HBM_NUM_BANKS-1:0][1:0] bst;

    sf_hbm_pseudochannel #(
      .DEPTH(DEPTH), .CPL_DEPTH(CPL_DEPTH), .PHY_BACKEND(PHY_BACKEND), .PHY_CMD_LAT(PHY_CMD_LAT),
      .PHY_RD_LAT(PHY_RD_LAT), .WR_ACK_AT_DATA(WR_ACK_AT_DATA)
    ) u_pc (
      .clk_i, .rst_ni, .tp_i, .sched_cfg_i, .ref_cfg_i, .ecc_en_i, .ctrl_enable_i,
      .pwr_req_i, .pd_idle_i, .sr_idle_i,
      .init_mrs_valid_i, .init_mrs_code_i, .init_mrs_ack_o(mrs_ack[p]),
      .ecc_clear_i, .inj_arm_i(inj_arm_i[p]), .inj_mode_i, .inj_bit_i,
      .req_valid_i(pc_req_valid[p]), .req_ready_o(pc_req_ready[p]), .req_txn_i,
      .req_wdata_i, .req_wmask_i,
      .rsp_valid_o(pc_rsp_valid[p]), .rsp_ready_i(pc_rsp_ready[p]), .rsp_o(pc_rsp[p]),
      .phy_ready_ext_i(phy_ready_ext_i[p]), .phy_event_i(phy_event_i[p]), .ondie_event_i(ondie_event_i[p]),
      .sim_cmd_valid_o(sim_cmd_valid_o[p]), .sim_cmd_o(sim_cmd_o[p]),
      .sim_wvalid_o(sim_wvalid_o[p]), .sim_wdata_o(sim_wdata_o[p]), .sim_wmask_o(sim_wmask_o[p]), .sim_wecc_o(sim_wecc_o[p]),
      .sim_rvalid_i(sim_rvalid_i[p]), .sim_rdata_i(sim_rdata_i[p]), .sim_recc_i(sim_recc_i[p]), .sim_rerr_i(sim_rerr_i[p]),
      .evt_o(evt), .lat_o(lat), .rsp_bytes_o(bytes), .occ_o(occ_n), .pwr_state_o(pws),
      .res_active_o(), .res_pd_o(), .res_sr_o(), .ref_debt_o(debt), .quiet_o(quiet),
      .backend_unimplemented_o(unimpl),
      .ecc_ce_o(), .ecc_ue_o(), .phy_err_o(), .ondie_err_o(),
      .ecc_log_valid_o(ecc_lv), .ecc_log_ue_o(ecc_lue), .ecc_log_syn_o(ecc_lsyn), .ecc_alert_o(ecc_alert),
      .bank_state_o(bst), .dbg_cmd_valid_o(), .dbg_cmd_o()
    );
    assign occ_w = 6'(occ_n);          // DEPTH <= 63 is enforced below (hbm_pc_stat_t.occ is 6 bits; review C8)
    assign stat_o[p] = '{evt: evt, lat: lat, bytes: bytes, occ: occ_w, pwr_state: pws, debt: debt,
                         quiet: quiet, unimpl: unimpl, ecc_alert: ecc_alert, ecc_lv: ecc_lv,
                         ecc_lue: ecc_lue, ecc_lsyn: ecc_lsyn, bank_state: bst};
  end

  sf_hbm_rsp_arb #(.N(PCS)) u_arb (
    .clk_i, .rst_ni,
    .in_valid_i(pc_rsp_valid), .in_rsp_i(pc_rsp), .in_ready_o(pc_rsp_ready),
    .out_valid_o(rsp_valid_o), .out_rsp_o(rsp_o), .out_ready_i(rsp_ready_i), .sel_o()
  );
endmodule : sf_hbm_channel
