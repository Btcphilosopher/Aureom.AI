// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_command_encoder.sv
//  Command-layer separation:
//
//     abstract controller command   hbm_cmd_t              (sf_hbm_pkg, internal to HBMCore)
//        -> [ this block ]
//     encoded memory command bus    hbm_phy_cmd_t           (ABSTRACT, one-hot-free typed struct)
//        -> PHY adapter -> (simulation DRAM model | vendor PHY)
//
//  STATUS: PENDING SPECIFICATION INTEGRATION.
//    HBM4 command structure, row/column command bus partitioning and pin-level encoding must
//    come from JESD270-4 (or the vendor datasheet) and the licensed PHY interface document.
//    NEITHER IS AVAILABLE in this repository, so NO pin-level command table is implemented and
//    none is invented. ENCODING = 0 selects the typed abstract pass-through used for behavioural
//    simulation. Any other value is a build error by design: a physical encoding is added here,
//    in one place, once the specification is available.
//
//  The block also registers the command (this is the controller's command-register pipeline
//  stage; the PHY sees the command one cycle after the scheduler issued it).
//  RESET: async assert; NOP.
// =============================================================================
module sf_hbm_command_encoder
  import sf_hbm_pkg::*;
#(
  parameter int unsigned ENCODING = 0     // 0 = abstract (simulation). Others: PENDING SPEC.
) (
  input  logic      clk_i,
  input  logic      rst_ni,
  input  logic      cmd_valid_i,
  input  hbm_cmd_t  cmd_i,
  output logic      phy_cmd_valid_o,
  output hbm_cmd_t  phy_cmd_o            // abstract typed bundle; NOT a JEDEC pin table
);
  if (ENCODING != 0) begin : g_pending_spec
    $error("sf_hbm_command_encoder: ENCODING=%0d requested but no verified HBM4 command encoding is integrated (pending specification).", ENCODING);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      phy_cmd_valid_o <= 1'b0;
      phy_cmd_o       <= '0;
    end else begin
      phy_cmd_valid_o <= cmd_valid_i;
      phy_cmd_o       <= cmd_valid_i ? cmd_i : '0;
    end
  end
endmodule : sf_hbm_command_encoder
