// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_rfm.sv                                              (v2, RESEARCH HOOK)
//  Refresh-management (RFM) / directed-RFM (DRFM-style) activation tracker of one pseudo-channel.
//
//  STANDARDS STATUS: ENGINEERING_ASSUMPTION / UNVERIFIED. Whether JESD270-4 (HBM4) defines RFM, DRFM, a rolling
//  accumulated-ACT (RAA) counter, its thresholds or the command's timing is NOT known here (no specification was
//  available - docs/MISSING_SPEC.md). The mechanism is modelled on the publicly described *concept* of RAA-based
//  refresh management; every threshold is a CSR value and the command is the ABSTRACT HCMD_RFM with a hypothetical
//  busy time `trfm` (configs/timing/profiles.json). This block does NOT provide RowHammer protection: that needs a
//  threat model and verified DRAM-device behaviour (docs/ROWHAMMER.md).
//
//  WHAT IT DOES
//    * RAA[b]: per-bank rolling count of ACTs. +1 per ACT to bank b (saturating at 255).
//              -raa_ref_dec on every refresh that covers bank b (REF_AB: all banks, REF_PB: that bank), floor 0.
//              -raaimt on an RFM to bank b, floor 0.
//    * RAA[b] >= raaimt  -> an RFM to bank b is requested (lowest such bank first; the refresh engine executes it as a
//                           per-bank HOLD -> PRE -> RFM sequence, sf_hbm_refresh).
//    * RAA[b] >= raammt  -> ACT to bank b is BLOCKED (act_block_o[b]) until an RFM brings the count down; demand traffic
//                           therefore cannot run the count past raammt.
//    * DIRECTED mode (rfm_dir = 1): a 2-entry Misra-Gries heavy-hitter tracker per bank names the most-activated row;
//      the RFM carries that row (abstract "directed" refresh management) and the tracked entry is cleared after the RFM.
//      Undirected mode sends row 0 and leaves the choice of victim rows to the (modelled) device.
//  CONFIGURATION: cfg_i.rfm_en, rfm_dir, raaimt, raammt, raa_ref_dec (CSR REFCFG[31:4]). raaimt = 0 disables requests.
//  RESET: async assert; all counters 0. Disabling rfm_en clears the counters (no stale blocking).
//  SYNTHESIS: NB x (8-bit RAA + 2 x (row + 8-bit count)) flops; per-bank compare trees.
// =============================================================================
module sf_hbm_rfm
  import sf_hbm_pkg::*;
(
  input  logic                         clk_i,
  input  logic                         rst_ni,
  input  hbm_ref_cfg_t                 cfg_i,

  // issued-command observation (one command per cycle, pre-register)
  input  logic                         cmd_valid_i,
  input  hbm_cmd_t                     cmd_i,

  // request to the refresh engine (level; held until rfm_done_i for that bank)
  output logic                         rfm_req_o,
  output logic [HBM_BANK_W-1:0]        rfm_bank_o,
  output hbm_row_t                     rfm_row_o,

  output logic [HBM_NUM_BANKS-1:0]     act_block_o,     // bank at or above raammt: no ACT
  output logic [7:0]                   raa_max_o        // highest RAA of any bank (observability)
);
  localparam int unsigned NB = HBM_NUM_BANKS;

  logic [7:0]          raa_q  [NB];
  hbm_row_t            hr_q   [NB][2];   // heavy-hitter rows
  logic [7:0]          hc_q   [NB][2];   // heavy-hitter counts

  wire [HBM_BANK_W-1:0] cbank = {cmd_i.bg, cmd_i.ba};
  wire is_act   = cmd_valid_i && (cmd_i.cmd == HCMD_ACT);
  wire is_refab = cmd_valid_i && (cmd_i.cmd == HCMD_REF_AB);
  wire is_refpb = cmd_valid_i && (cmd_i.cmd == HCMD_REF_PB);
  wire is_rfm   = cmd_valid_i && (cmd_i.cmd == HCMD_RFM);

  function automatic logic [7:0] sat_sub(input logic [7:0] a, input logic [7:0] b);
    return (a > b) ? (a - b) : 8'd0;
  endfunction

  // ---- request selection: lowest bank at or above the initial threshold -------------------------------
  always_comb begin
    rfm_req_o  = 1'b0;
    rfm_bank_o = '0;
    for (int b = NB - 1; b >= 0; b--) begin
      if (cfg_i.rfm_en && (cfg_i.raaimt != 8'd0) && (raa_q[b] >= cfg_i.raaimt)) begin
        rfm_req_o  = 1'b1;
        rfm_bank_o = HBM_BANK_W'(b);
      end
    end
    for (int b = 0; b < NB; b++)
      act_block_o[b] = cfg_i.rfm_en && (cfg_i.raammt != 8'd0) && (raa_q[b] >= cfg_i.raammt);
  end

  // observability: maximum RAA, a balanced comparator tree, REGISTERED (one cycle late; never used for control).
  // (the first version used a linear 16-deep max chain: 4.4 ns on the NanGate45 proxy - reports/synth_ng45)
  localparam int unsigned NBP = 1 << $clog2(NB);
  logic [7:0] mx [2*NBP-1];
  always_comb begin
    for (int i = 0; i < NBP; i++) mx[NBP - 1 + i] = (i < NB) ? raa_q[i] : 8'd0;
    for (int i = NBP - 2; i >= 0; i--) mx[i] = (mx[2*i+1] > mx[2*i+2]) ? mx[2*i+1] : mx[2*i+2];
  end
  always_ff @(posedge clk_i or negedge rst_ni)
    if (!rst_ni) raa_max_o <= '0; else raa_max_o <= mx[0];
  // directed target row: the heavier of the two tracked rows of the requested bank
  always_comb begin
    rfm_row_o = '0;
    if (cfg_i.rfm_dir)
      rfm_row_o = (hc_q[rfm_bank_o][1] > hc_q[rfm_bank_o][0]) ? hr_q[rfm_bank_o][1] : hr_q[rfm_bank_o][0];
  end

  // ---- counters ------------------------------------------------------------------------------------------
  for (genvar b = 0; b < NB; b++) begin : g_bank
    wire act_b = is_act && (cbank == HBM_BANK_W'(b));
    wire ref_b = is_refab || (is_refpb && (cbank == HBM_BANK_W'(b)));
    wire rfm_b = is_rfm && (cbank == HBM_BANK_W'(b));
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        raa_q[b] <= '0;
        hr_q[b][0] <= '0; hr_q[b][1] <= '0; hc_q[b][0] <= '0; hc_q[b][1] <= '0;
      end else if (!cfg_i.rfm_en) begin
        raa_q[b] <= '0;
        hc_q[b][0] <= '0; hc_q[b][1] <= '0;
      end else begin
        // RAA (one command per cycle: at most one of act_b / ref_b / rfm_b is set)
        if (act_b && raa_q[b] != 8'hFF) raa_q[b] <= raa_q[b] + 8'd1;
        if (ref_b)                      raa_q[b] <= sat_sub(raa_q[b], cfg_i.raa_ref_dec);
        if (rfm_b)                      raa_q[b] <= sat_sub(raa_q[b], cfg_i.raaimt);
        // 2-entry Misra-Gries heavy-hitter tracker (directed mode)
        if (act_b) begin
          if (hc_q[b][0] != 0 && hr_q[b][0] == cmd_i.row) begin
            if (hc_q[b][0] != 8'hFF) hc_q[b][0] <= hc_q[b][0] + 8'd1;
          end else if (hc_q[b][1] != 0 && hr_q[b][1] == cmd_i.row) begin
            if (hc_q[b][1] != 8'hFF) hc_q[b][1] <= hc_q[b][1] + 8'd1;
          end else if (hc_q[b][0] == 0) begin
            hr_q[b][0] <= cmd_i.row; hc_q[b][0] <= 8'd1;
          end else if (hc_q[b][1] == 0) begin
            hr_q[b][1] <= cmd_i.row; hc_q[b][1] <= 8'd1;
          end else begin
            hc_q[b][0] <= hc_q[b][0] - 8'd1; hc_q[b][1] <= hc_q[b][1] - 8'd1;
          end
        end
        // a directed RFM mitigates the row it named: forget it
        if (rfm_b && cfg_i.rfm_dir) begin
          if (hr_q[b][0] == cmd_i.row) hc_q[b][0] <= '0;
          if (hr_q[b][1] == cmd_i.row) hc_q[b][1] <= '0;
        end
      end
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    for (int b = 0; b < NB; b++)
      if (is_act && (cbank == HBM_BANK_W'(b)) && act_block_o[b])
        $error("[%m] ACT issued to bank %0d although its RAA %0d >= raammt %0d", b, raa_q[b], cfg_i.raammt);
  end
`endif
endmodule : sf_hbm_rfm
