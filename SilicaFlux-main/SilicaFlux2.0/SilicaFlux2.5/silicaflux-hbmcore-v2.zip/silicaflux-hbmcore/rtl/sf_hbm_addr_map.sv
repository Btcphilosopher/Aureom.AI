// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_addr_map.sv
//  System physical byte address -> {stack, channel, pseudo-channel, bank group, bank, row, column}.
//
//  Purely combinational. The mapping itself lives in sf_hbm_pkg (hbm_map_addr / hbm_unmap_loc) so the
//  forward map, the inverse map and every testbench share ONE definition; the INDEPENDENT second
//  implementation is python/hbm4/address_map.py, written from docs/ADDRESS_MAP.md alone.
//
//  MODES  (docs/ADDRESS_MAP.md)    0 LINEAR  1 CH_IL (channel/pc interleave at 2^il granules)
//                                  2 BANK_AWARE (bank-group/bank rotate below the column MSBs)
//         + optional bijective XOR hash of bank / channel bits with row bits.
//  PAGE-LOCALITY POLICY: il_bits chooses how many consecutive granules stay in one page of one
//  pseudo-channel before the stream moves on (il=COL keeps the whole 2 KiB page, il=0 interleaves 32 B).
//
//  CHECKS
//    err_range    address has bits above the configured capacity
//    err_misalign addr[4:0] != 0 (the granule interface does not do sub-granule addressing)
//    RANGE takes precedence when both apply.
//
//  Geometry is NOT hard-wired: NUM_STACKS / NUM_CHANNELS / PCS are parameters (powers of two); the
//  in-bank geometry comes from sf_hbm_geom.svh. 1, 2, 4, 8 and 32 channels are exercised in simulation;
//  a reduced-channel configuration is a verification vehicle, not an HBM4 product.
//  RESET: none (combinational).
// =============================================================================
module sf_hbm_addr_map
  import sf_hbm_pkg::*;
#(
  parameter int unsigned NUM_STACKS   = 1,
  parameter int unsigned NUM_CHANNELS = 32,
  parameter int unsigned PCS          = 2
) (
  input  hbm_addr_t  addr_i,
  input  hbm_map_e   mode_i,
  input  logic [2:0] il_bits_i,
  input  logic       hash_i,

  output hbm_loc_t   loc_o,
  output logic [$clog2(NUM_STACKS*NUM_CHANNELS*PCS > 1 ? NUM_STACKS*NUM_CHANNELS*PCS : 2)-1:0] pc_o,
  output logic       err_range_o,
  output logic       err_misalign_o,
  output hbm_err_e   err_o
);
  localparam int unsigned NS_BITS = (NUM_STACKS   > 1) ? $clog2(NUM_STACKS)   : 0;
  localparam int unsigned CH_BITS = (NUM_CHANNELS > 1) ? $clog2(NUM_CHANNELS) : 0;
  localparam int unsigned PC_BITS = (PCS          > 1) ? $clog2(PCS)          : 0;
  localparam int unsigned CAP_BITS = HBM_OFF_W + HBM_COL_W + HBM_BA_W + HBM_BG_W + HBM_ROW_W + PC_BITS + CH_BITS + NS_BITS;

  if ((NUM_STACKS & (NUM_STACKS - 1)) != 0 || (NUM_CHANNELS & (NUM_CHANNELS - 1)) != 0) begin : g_chk_pow2
    $error("sf_hbm_addr_map: NUM_STACKS and NUM_CHANNELS must be powers of two");
  end
  if (PCS != 1 && PCS != 2) begin : g_chk_pcs
    $error("sf_hbm_addr_map: PCS must be 1 or 2");
  end
  // v2 (independent review C3): hbm_loc_t carries stk[2:0] and ch[5:0]; wider stack / channel indices aliased silently
  if (NS_BITS > 3 || CH_BITS > 6) begin : g_chk_loc_width
    $error("sf_hbm_addr_map: NUM_STACKS <= 8 and NUM_CHANNELS <= 64 (hbm_loc_t field widths); got %0d stacks, %0d channels", NUM_STACKS, NUM_CHANNELS);
  end
  if (CAP_BITS > HBM_ADDR_W) begin : g_chk_cap
    $error("sf_hbm_addr_map: configured capacity needs %0d address bits but HBM_ADDR_W is %0d", CAP_BITS, HBM_ADDR_W);
  end

  hbm_loc_t loc;
  always_comb begin
    loc = hbm_map_addr(addr_i, mode_i, il_bits_i, hash_i, NS_BITS, CH_BITS, PC_BITS);
    loc_o = loc;
    pc_o  = '0;
    pc_o  = (($bits(pc_o))'(loc.stk) * ($bits(pc_o))'(NUM_CHANNELS) + ($bits(pc_o))'(loc.ch)) * ($bits(pc_o))'(PCS) + ($bits(pc_o))'(loc.pc);
    err_range_o    = ((addr_i >> CAP_BITS) != '0);
    err_misalign_o = (addr_i[HBM_OFF_W-1:0] != '0);
    err_o = err_range_o ? HERR_RANGE : (err_misalign_o ? HERR_MISALIGN : HERR_NONE);
  end
endmodule : sf_hbm_addr_map
