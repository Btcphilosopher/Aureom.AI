// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_rsp_arb.sv
//  N-to-1 response arbiter with round-robin fairness and GRANT LOCKING.
//
//  Contract
//    * Exactly one input is granted at a time (arbitration exclusivity: formal property in
//      verification/formal/fv_rsp_arb.sv).
//    * Once an input is selected and out_valid_o is high, the selection (and therefore the payload)
//      is held until out_ready_i accepts it: out_valid_o && !out_ready_i  =>  output payload stable.
//    * Round-robin: after a grant is accepted the pointer moves to the input after the winner, so no
//      continuously-valid input can starve another.
//    * A response is never duplicated or dropped: in_ready_o[i] is high only for the selected input and
//      only in the cycle the output hand-shake completes.
//  Reset: async assert; pointer 0, no lock.
// =============================================================================
module sf_hbm_rsp_arb
  import sf_hbm_pkg::*;
#(
  parameter int unsigned N = 2
) (
  input  logic                clk_i,
  input  logic                rst_ni,
  input  logic [N-1:0]        in_valid_i,
  input  hbm_rsp_t [N-1:0]    in_rsp_i,
  output logic [N-1:0]        in_ready_o,
  output logic                out_valid_o,
  output hbm_rsp_t            out_rsp_o,
  input  logic                out_ready_i,
  output logic [(N>1?$clog2(N):1)-1:0] sel_o
);
  localparam int unsigned IW = (N > 1) ? $clog2(N) : 1;

  logic [IW-1:0] ptr_q, lock_idx_q;
  logic          lock_q;

  logic [IW-1:0] rr_idx;
  logic          rr_any;
  always_comb begin
    rr_any = 1'b0;
    rr_idx = '0;
    for (int k = N-1; k >= 0; k--) begin
      int unsigned i;
      i = (int'(ptr_q) + k) % N;
      if (in_valid_i[i]) begin rr_any = 1'b1; rr_idx = IW'(i); end
    end
  end

  wire [IW-1:0] sel = lock_q ? lock_idx_q : rr_idx;
  assign sel_o       = sel;
  assign out_valid_o = lock_q ? in_valid_i[lock_idx_q] : rr_any;
  assign out_rsp_o   = in_rsp_i[sel];

  always_comb begin
    in_ready_o = '0;
    if (out_valid_o && out_ready_i) in_ready_o[sel] = 1'b1;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ptr_q <= '0; lock_q <= 1'b0; lock_idx_q <= '0;
    end else begin
      if (out_valid_o && out_ready_i) begin
        lock_q <= 1'b0;
        ptr_q  <= (int'(sel) == N-1) ? '0 : (sel + 1'b1);
      end else if (out_valid_o) begin
        lock_q     <= 1'b1;
        lock_idx_q <= sel;
      end
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    if ($countones(in_ready_o) > 1) $error("[%m] more than one input granted");
    if (lock_q && !in_valid_i[lock_idx_q]) $error("[%m] a locked input withdrew its valid before acceptance");
  end
`endif
endmodule : sf_hbm_rsp_arb
