// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_phy_adapter.sv
//  Controller <-> PHY boundary of ONE pseudo-channel. The controller never touches a PHY
//  signal directly; everything crosses this block.
//
//  CONTROLLER-SIDE CONTRACT (docs/PHY_CONTRACT.md)
//    * A command is offered with cmd_valid_i only when cmd_ready_o was high in the previous
//      scheduling cycle (the scheduler sees cmd_ready_o as `phy_ready`). After acceptance the
//      PHY must take the matching write data exactly WL cycles later and must return read data
//      exactly RL cycles after the command (+ the fixed adapter latencies below).
//    * Read data returns in command order. No tags cross the interface.
//
//  BACKEND = 0  SIMULATION PHY  (BACKEND A)
//    Pure functional pipeline into verification/hbm4/hbm4_dram_model.sv:
//        CMD_LAT register stages on command AND write data (so their relative timing is preserved)
//        RD_LAT  register stages on read data.
//    The controller is told the total read extra latency through RD_EXTRA_LAT = CMD_LAT + RD_LAT.
//    This is a functional model. It contains NO analogue behaviour, training or DFI timing.
//
//  BACKEND = 1  VENDOR / LICENSED PHY  (BACKEND B)   ***UNIMPLEMENTED - PENDING PHY SPEC***
//    Needs: the licensed PHY interface document (DFI 5.1-compatible or vendor specific), its
//    clock-ratio / data-width-conversion contract and supported RTL. None is in this repository, so
//    this backend drives idle values and raises backend_unimplemented_o. It is NOT labelled DFI.
//    A DFI-INSPIRED shim, were one written, must not be called DFI-compliant.
//
//  Clock ratio: this adapter is 1:1 with the controller clock. HBM pin data rate and PHY clock
//  ratio are PHY-specific; see docs/CDC_AND_CLOCKS.md for where a ratio converter belongs.
//  RESET: async assert; idle.
// =============================================================================
module sf_hbm_phy_adapter
  import sf_hbm_pkg::*;
#(
  parameter int unsigned BACKEND = 0,
  parameter int unsigned CMD_LAT = 0,
  parameter int unsigned RD_LAT  = 0
) (
  input  logic          clk_i,
  input  logic          rst_ni,

  // controller side
  input  logic          cmd_valid_i,
  input  hbm_cmd_t      cmd_i,
  input  logic          wdata_valid_i,
  input  hbm_data_t     wdata_i,
  input  hbm_mask_t     wmask_i,
  input  hbm_ecc_t      wecc_i,
  output logic          rdata_valid_o,
  output hbm_data_t     rdata_o,
  output hbm_ecc_t      recc_o,
  output logic          rerr_o,          // PHY/interface-level error flag (parity/CRC/alert) on this return
  output logic          cmd_ready_o,
  output logic          backend_unimplemented_o,
  input  logic          phy_ready_ext_i, // external back-pressure (e.g. PHY maintenance), 1 = can accept

  // simulation-PHY side (to the behavioural DRAM model)
  output logic          sim_cmd_valid_o,
  output hbm_cmd_t      sim_cmd_o,
  output logic          sim_wvalid_o,
  output hbm_data_t     sim_wdata_o,
  output hbm_mask_t     sim_wmask_o,
  output hbm_ecc_t      sim_wecc_o,
  input  logic          sim_rvalid_i,
  input  hbm_data_t     sim_rdata_i,
  input  hbm_ecc_t      sim_recc_i,
  input  logic          sim_rerr_i
);
  localparam int unsigned CW = 1 + HBM_CMD_W;
  localparam int unsigned WW = 1 + HBM_GRAN_BITS + HBM_MASK_W + HBM_ECC_W;
  localparam int unsigned RW = 1 + HBM_GRAN_BITS + HBM_ECC_W + 1;

  if (BACKEND == 0) begin : g_sim
    assign backend_unimplemented_o = 1'b0;
    assign cmd_ready_o = phy_ready_ext_i;

    logic [CW-1:0] c_pipe [CMD_LAT+1];
    logic [WW-1:0] w_pipe [CMD_LAT+1];
    logic [RW-1:0] r_pipe [RD_LAT+1];

    assign c_pipe[0] = {cmd_valid_i, cmd_i};
    assign w_pipe[0] = {wdata_valid_i, wdata_i, wmask_i, wecc_i};
    assign r_pipe[0] = {sim_rvalid_i, sim_rdata_i, sim_recc_i, sim_rerr_i};

    for (genvar k = 0; k < CMD_LAT; k++) begin : g_cl
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin c_pipe[k+1] <= '0; w_pipe[k+1] <= '0; end
        else         begin c_pipe[k+1] <= c_pipe[k]; w_pipe[k+1] <= w_pipe[k]; end
      end
    end
    for (genvar k = 0; k < RD_LAT; k++) begin : g_rl
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) r_pipe[k+1] <= '0;
        else         r_pipe[k+1] <= r_pipe[k];
      end
    end

    assign {sim_cmd_valid_o, sim_cmd_o}                               = c_pipe[CMD_LAT];
    assign {sim_wvalid_o, sim_wdata_o, sim_wmask_o, sim_wecc_o}       = w_pipe[CMD_LAT];
    assign {rdata_valid_o, rdata_o, recc_o, rerr_o}                   = r_pipe[RD_LAT];
  end else begin : g_vendor
    // BACKEND B: pending licensed-PHY specification. Idle outputs, flagged.
    assign backend_unimplemented_o = 1'b1;
    assign cmd_ready_o       = 1'b0;
    assign sim_cmd_valid_o   = 1'b0;
    assign sim_cmd_o         = '0;
    assign sim_wvalid_o      = 1'b0;
    assign sim_wdata_o       = '0;
    assign sim_wmask_o       = '0;
    assign sim_wecc_o        = '0;
    assign rdata_valid_o     = 1'b0;
    assign rdata_o           = '0;
    assign recc_o            = '0;
    assign rerr_o            = 1'b0;
  end

`ifndef SYNTHESIS
  initial if (BACKEND == 1)
    $display("[sf_hbm_phy_adapter] BACKEND=1 (vendor PHY) is UNIMPLEMENTED - pending licensed PHY specification");
`endif
endmodule : sf_hbm_phy_adapter
