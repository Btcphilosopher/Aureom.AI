// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_csr.sv
//  Configuration / observability registers.
//
//  REGISTER BUS: deliberately the SAME shape as the repository's existing control-plane bus
//  (sf_crt_regs.sv in silicaflux-clocktree-p35): rb_sel / rb_we / rb_addr / rb_wdata / rb_rdata / rb_err.
//  One access per cycle, zero wait states, read data valid in the same cycle (combinational read mux).
//  No second incompatible control protocol is introduced; an APB wrapper, if the SoC wants one, is a
//  3-line adaptation (psel&penable -> rb_sel, pwrite -> rb_we) and is NOT part of this block.
//  Word addresses (rb_addr[11:0]); unmapped read returns 0 and rb_err; writes to RO registers set rb_err.
//
//  0x000 ID        RO  {16'h4842 'HB', 8'h01 version, 8'h01 txn contract}
//  0x001 GEOMETRY  RO  {num_stacks[7:0], num_channels[7:0], cluster_ch[7:0], depth[7:0]}
//  0x002 CONTROL   RW  [0] enable
//  0x003 STATUS    RO  [0] ready [1] init_error [4:2] init_cause [7:5] init_state [9:8] profile_status(0=HYPOTHETICAL_SIM)
//                      [10] perf_overflow [11] any_unimplemented_phy [12] ecc_alert_any [13] per-bank refresh selected on a profile where it is infeasible
//  0x004 PROFILE   RW  [3:0] timing-profile select (change only while idle)
//  0x005 MAPCFG    RW  [1:0] map mode [4:2] interleave bits [8] hash
//  0x006 SCHED0    RW  [2:0] policy [4] prio_en [5] batch_en [6] deadline_en [9:8] page policy
//  0x007 SCHED1    RW  [7:0] batch_len [23:8] starve_limit
//  0x008 SCHED2    RW  [15:0] deadline_thr [31:16] close_timeout
//  0x009 REFCFG    RW  [1:0] mode(0 AB,1 PB,2 off) [2] eager [3] pull-in enable
//                      v2 refresh management (research hook, ENGINEERING_ASSUMPTION): [4] rfm_en [5] rfm_directed
//                      [15:8] raaimt (RFM request threshold) [23:16] raammt (ACT-block threshold) [31:24] RAA decrement per REF
//  0x00A POWER0    RW  [1:0] request (0 active,1 power-down,2 self-refresh)
//  0x00B POWER1    RW  [15:0] auto power-down idle cycles [31:16] auto self-refresh idle cycles (0 = off)
//  0x00C INITTO    RW  init per-state timeout cycles (0 = none)
//  0x00D ECCCFG    RW  [0] controller ECC enable
//  0x00E ECCINJ    RW  [1:0] mode [10:2] bit [31:16] target pseudo-channel;  write bit 12 = arm (self-clearing)
//  0x00F ECCCLR    WO  any write clears ECC/RAS counters and log
//  0x010 ECCLOG    RO  [8:0] syndrome [9] valid [10] uncorrectable [31:16] pseudo-channel (lowest-numbered PC that holds a log entry; see sf_hbm_top)
//  0x011 MAXBURST  RW  [7:0] host burst limit - 1 (granules/beats), exported to the DataFabric node
//  0x012 ADDRHI    RW  [7:0] HBM byte-address bits [39:32] used by the DataFabric node (the NoC address is only 32 bit)
//  0x020 PERFCTL   RW  [0] freeze  ;  write bit 4 = clear, bit 5 = snapshot (self-clearing pulses)
//  0x021 PERFSEL   RW  [15:0] pseudo-channel [21:16] counter id [24] 1 = read aggregate (snapshot bank)
//  0x022 PERFLO    RO  selected counter [31:0]
//  0x023 PERFHI    RO  selected counter [63:32]
//  0x030 ERRSTAT   RO  sticky: [0] DRAM-model/bank violation [1] read-return protocol error [2] refresh deadline miss
//                      (W1C)   [3] ECC uncorrectable
//  0x040 PROFINFO  RO  [15:0] clock MHz of the selected profile (informational)
//
//  RESET: async assert; enable=0, safe defaults (FR-FCFS, open page, AB refresh eager, profile 1 = sim_ref).
// =============================================================================
module sf_hbm_csr
  import sf_hbm_pkg::*;
#(
  parameter int unsigned NUM_STACKS = 1,
  parameter int unsigned NUM_CH     = 32,
  parameter int unsigned CL_CH      = 8,
  parameter int unsigned QDEPTH     = 16
) (
  input  logic          clk_i,
  input  logic          rst_ni,

  input  logic          rb_sel_i,
  input  logic          rb_we_i,
  input  logic [11:0]   rb_addr_i,
  input  logic [31:0]   rb_wdata_i,
  output logic [31:0]   rb_rdata_o,
  output logic          rb_err_o,

  output hbm_cfg_t      cfg_o,
  output logic [7:0]    addr_hi_o,          // HBM byte-address bits [39:32] for the DataFabric node
  output logic [7:0]    max_burst_m1_o,     // host burst limit - 1 (granules/beats) for the DataFabric node
  output logic          ecc_clear_o,
  output logic          inj_arm_o,
  output logic [15:0]   inj_pc_o,
  output logic [1:0]    inj_mode_o,
  output logic [8:0]    inj_bit_o,
  output logic          perf_clear_o,
  output logic          perf_snap_o,
  output logic          perf_freeze_o,
  output logic [15:0]   perf_pc_o,
  output logic [5:0]    perf_cnt_o,
  output logic          perf_agg_o,
  input  logic [63:0]   perf_rdata_i,

  input  logic          ready_i,
  input  logic          init_error_i,
  input  logic [2:0]    init_cause_i,
  input  logic [2:0]    init_state_i,
  input  logic [1:0]    profile_status_i,
  input  logic [15:0]   profile_mhz_i,
  input  logic          perf_ovf_i,
  input  logic          unimpl_any_i,
  input  logic          ecc_alert_any_i,
  input  logic          ref_infeasible_i,
  input  logic          ecc_log_valid_i,
  input  logic          ecc_log_ue_i,
  input  logic [8:0]    ecc_log_syn_i,
  input  logic [15:0]   ecc_log_pc_i,
  input  logic          ev_violation_i,
  input  logic          ev_protocol_i,
  input  logic          ev_deadline_i,
  input  logic          ev_ue_i
);
  hbm_cfg_t cfg_q;
  logic [3:0] errsticky_q;
  logic       freeze_q;
  logic [15:0] psel_pc_q;  logic [5:0] psel_cnt_q;  logic psel_agg_q;
  logic [15:0] inj_pc_q;   logic [1:0] inj_mode_q;  logic [8:0] inj_bit_q;
  logic [7:0]  addr_hi_q;

  assign cfg_o         = cfg_q;
  assign addr_hi_o     = addr_hi_q;
  assign max_burst_m1_o = cfg_q.max_burst_m1;
  assign perf_freeze_o = freeze_q;
  assign perf_pc_o  = psel_pc_q;  assign perf_cnt_o = psel_cnt_q;  assign perf_agg_o = psel_agg_q;
  assign inj_pc_o   = inj_pc_q;   assign inj_mode_o = inj_mode_q;  assign inj_bit_o  = inj_bit_q;

  wire wr = rb_sel_i && rb_we_i;
  wire rd = rb_sel_i && !rb_we_i;

  // ---- read mux ------------------------------------------------------------------
  always_comb begin
    rb_rdata_o = 32'd0;
    rb_err_o   = 1'b0;
    if (rb_sel_i) begin
      case (rb_addr_i)
        12'h000: rb_rdata_o = {16'h4842, 8'h01, 8'(HBM_TXN_VERSION)};
        12'h001: rb_rdata_o = {8'(NUM_STACKS), 8'(NUM_CH), 8'(CL_CH), 8'(QDEPTH)};
        12'h002: rb_rdata_o = {31'd0, cfg_q.enable};
        12'h003: rb_rdata_o = {18'd0, ref_infeasible_i, ecc_alert_any_i, unimpl_any_i, perf_ovf_i, profile_status_i, init_state_i,
                               init_cause_i, init_error_i, ready_i};
        12'h004: rb_rdata_o = {28'd0, cfg_q.profile_sel};
        12'h005: rb_rdata_o = {23'd0, cfg_q.map_hash, 3'd0, cfg_q.il_bits, cfg_q.map_mode};
        12'h006: rb_rdata_o = {22'd0, cfg_q.sched.page, 1'b0, cfg_q.sched.deadline_en, cfg_q.sched.batch_en,
                               cfg_q.sched.prio_en, 1'b0, cfg_q.sched.policy};
        12'h007: rb_rdata_o = {8'd0, cfg_q.sched.starve_limit, cfg_q.sched.batch_len};
        12'h008: rb_rdata_o = {cfg_q.sched.close_timeout, cfg_q.sched.deadline_thr};
        12'h009: rb_rdata_o = {cfg_q.ref_cfg.raa_ref_dec, cfg_q.ref_cfg.raammt, cfg_q.ref_cfg.raaimt, 2'b00,
                               cfg_q.ref_cfg.rfm_dir, cfg_q.ref_cfg.rfm_en,
                               cfg_q.ref_cfg.pullin_en, cfg_q.ref_cfg.eager, cfg_q.ref_cfg.mode};
        12'h00A: rb_rdata_o = {30'd0, cfg_q.pwr_req};
        12'h00B: rb_rdata_o = {cfg_q.sr_idle, cfg_q.pd_idle};
        12'h00C: rb_rdata_o = cfg_q.init_timeout;
        12'h00D: rb_rdata_o = {31'd0, cfg_q.ecc_en};
        12'h00E: rb_rdata_o = {inj_pc_q, 5'd0, inj_bit_q, inj_mode_q};
        12'h010: rb_rdata_o = {ecc_log_pc_i, 5'd0, ecc_log_ue_i, ecc_log_valid_i, ecc_log_syn_i};
        12'h011: rb_rdata_o = {24'd0, cfg_q.max_burst_m1};
        12'h012: rb_rdata_o = {24'd0, addr_hi_q};
        12'h020: rb_rdata_o = {31'd0, freeze_q};
        12'h021: rb_rdata_o = {7'd0, psel_agg_q, 2'd0, psel_cnt_q, psel_pc_q};
        12'h022: rb_rdata_o = perf_rdata_i[31:0];
        12'h023: rb_rdata_o = perf_rdata_i[63:32];
        12'h030: rb_rdata_o = {28'd0, errsticky_q};
        12'h040: rb_rdata_o = {16'd0, profile_mhz_i};
        12'h00F: rb_err_o = rd;
        default: rb_err_o = 1'b1;
      endcase
      if (wr && (rb_addr_i == 12'h000 || rb_addr_i == 12'h001 || rb_addr_i == 12'h003 || rb_addr_i == 12'h010 ||
                 rb_addr_i == 12'h022 || rb_addr_i == 12'h023 || rb_addr_i == 12'h040))
        rb_err_o = 1'b1;
    end
  end

  // ---- write side ----------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cfg_q <= '0;
      cfg_q.profile_sel         <= 4'd1;
      cfg_q.sched.policy        <= SCHED_FRFCFS;
      cfg_q.sched.batch_len     <= 8'd8;
      cfg_q.sched.close_timeout <= 16'd32;
      cfg_q.ref_cfg.mode        <= REFMODE_AB;
      cfg_q.ref_cfg.eager       <= 1'b1;
      cfg_q.ref_cfg.rfm_en      <= 1'b0;      // v2: off by default (research hook)
      cfg_q.ref_cfg.rfm_dir     <= 1'b0;
      cfg_q.ref_cfg.raaimt      <= 8'd32;     // HYPOTHETICAL defaults, not JEDEC values
      cfg_q.ref_cfg.raammt      <= 8'd64;
      cfg_q.ref_cfg.raa_ref_dec <= 8'd16;
      cfg_q.init_timeout        <= 32'd100000;
      cfg_q.max_burst_m1        <= 8'd31;
      errsticky_q <= '0; freeze_q <= 1'b0;
      psel_pc_q <= '0; psel_cnt_q <= '0; psel_agg_q <= 1'b0;
      inj_pc_q <= '0; inj_mode_q <= '0; inj_bit_q <= '0; addr_hi_q <= '0;
      ecc_clear_o <= 1'b0; inj_arm_o <= 1'b0; perf_clear_o <= 1'b0; perf_snap_o <= 1'b0;
    end else begin
      ecc_clear_o <= 1'b0; inj_arm_o <= 1'b0; perf_clear_o <= 1'b0; perf_snap_o <= 1'b0;
      if (wr) begin
        case (rb_addr_i)
          12'h002: cfg_q.enable <= rb_wdata_i[0];
          12'h004: cfg_q.profile_sel <= rb_wdata_i[3:0];
          12'h005: begin cfg_q.map_mode <= hbm_map_e'(rb_wdata_i[1:0]); cfg_q.il_bits <= rb_wdata_i[4:2]; cfg_q.map_hash <= rb_wdata_i[8]; end
          12'h006: begin
            cfg_q.sched.policy      <= hbm_sched_policy_e'(rb_wdata_i[2:0]);
            cfg_q.sched.prio_en     <= rb_wdata_i[4];
            cfg_q.sched.batch_en    <= rb_wdata_i[5];
            cfg_q.sched.deadline_en <= rb_wdata_i[6];
            cfg_q.sched.page        <= hbm_page_policy_e'(rb_wdata_i[9:8]);
          end
          12'h007: begin cfg_q.sched.batch_len <= rb_wdata_i[7:0]; cfg_q.sched.starve_limit <= rb_wdata_i[23:8]; end
          12'h008: begin cfg_q.sched.deadline_thr <= rb_wdata_i[15:0]; cfg_q.sched.close_timeout <= rb_wdata_i[31:16]; end
          12'h009: begin cfg_q.ref_cfg.mode <= hbm_ref_mode_e'(rb_wdata_i[1:0]); cfg_q.ref_cfg.eager <= rb_wdata_i[2]; cfg_q.ref_cfg.pullin_en <= rb_wdata_i[3];
                         cfg_q.ref_cfg.rfm_en <= rb_wdata_i[4]; cfg_q.ref_cfg.rfm_dir <= rb_wdata_i[5];
                         cfg_q.ref_cfg.raaimt <= rb_wdata_i[15:8]; cfg_q.ref_cfg.raammt <= rb_wdata_i[23:16]; cfg_q.ref_cfg.raa_ref_dec <= rb_wdata_i[31:24]; end
          12'h00A: cfg_q.pwr_req <= rb_wdata_i[1:0];
          12'h00B: begin cfg_q.pd_idle <= rb_wdata_i[15:0]; cfg_q.sr_idle <= rb_wdata_i[31:16]; end
          12'h00C: cfg_q.init_timeout <= rb_wdata_i;
          12'h00D: cfg_q.ecc_en <= rb_wdata_i[0];
          12'h00E: begin
            inj_mode_q <= rb_wdata_i[1:0]; inj_bit_q <= rb_wdata_i[10:2]; inj_pc_q <= rb_wdata_i[31:16];
            if (rb_wdata_i[12]) inj_arm_o <= 1'b1;
          end
          12'h00F: ecc_clear_o <= 1'b1;
          12'h011: cfg_q.max_burst_m1 <= rb_wdata_i[HBM_ID_W-1:0];
          12'h012: addr_hi_q <= rb_wdata_i[7:0];
          12'h020: begin
            freeze_q <= rb_wdata_i[0];
            if (rb_wdata_i[4]) perf_clear_o <= 1'b1;
            if (rb_wdata_i[5]) perf_snap_o  <= 1'b1;
          end
          12'h021: begin psel_pc_q <= rb_wdata_i[15:0]; psel_cnt_q <= rb_wdata_i[21:16]; psel_agg_q <= rb_wdata_i[24]; end
          12'h030: errsticky_q <= errsticky_q & ~rb_wdata_i[3:0];
          default: ;
        endcase
      end
      // sticky set AFTER the W1C clear in program order: an event that coincides with a clear is never lost
      if (ev_violation_i) errsticky_q[0] <= 1'b1;
      if (ev_protocol_i)  errsticky_q[1] <= 1'b1;
      if (ev_deadline_i)  errsticky_q[2] <= 1'b1;
      if (ev_ue_i)        errsticky_q[3] <= 1'b1;
    end
  end
endmodule : sf_hbm_csr
