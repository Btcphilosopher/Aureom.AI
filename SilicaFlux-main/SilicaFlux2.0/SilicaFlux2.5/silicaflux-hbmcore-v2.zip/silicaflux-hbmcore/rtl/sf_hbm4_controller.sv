// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm4_controller.sv
//  HBM4-style memory-controller subsystem top level (granule transaction interface "HBM-TXN v1").
//
//     host --> [ address map | error check | ID-order tracker | fence ] --> cluster steering
//          --> NUM_CLUSTERS x sf_hbm_stack_cluster (NCH channels x 2 pseudo-channels)
//          <-- response arbiter (clusters + local fence response) <--
//
//  HOST INTERFACE (single request port, single response port, valid/ready)
//    req: addr (byte, granule aligned), write, id, src, qos, order, fence, wdata[256], wmask[32]
//         Accepted iff req_valid_i && req_ready_o.   req_ready_o may depend on the request payload.
//    rsp: src, id, write, err, corrected, data[256]. Delivered only to the source named in `src`
//         (sf_hbm_datafabric demultiplexes on it; the testbenches assert ownership end to end).
//
//  INGRESS CHECKS (docs/ORDERING.md): address range, granule alignment, partial write with controller
//  ECC. A failing request becomes an ERROR ENTRY in a pseudo-channel queue so error responses obey
//  the same ordering rules as everything else; it issues no DRAM command.
//
//  SAME-ID ORDERING: responses with equal {src,id} stay in request order. A small table indexed by
//  {src[TRK_SRC_W-1:0], id[TRK_ID_W-1:0]} counts outstanding requests and remembers their pseudo-channel;
//  a new request is held back if its tracker entry is busy on a DIFFERENT pseudo-channel. Aliasing of
//  ids onto one entry can only add stalls, never reorder.
//
//  FENCE: accepted only when nothing is outstanding; completes at once with an ordinary write response.
//
//  INIT: sf_hbm_init gates traffic (ready_o). Training is an external PHY service (see sf_hbm_init.sv).
//
//  SCALING: NUM_STACKS x NUM_CHANNELS in {1,2,4,8,32,...}; clusters of CH_PER_CLUSTER channels.
//  A reduced-channel instance is a verification vehicle, NOT an HBM4 product.
//  RESET: async assert.
// =============================================================================
module sf_hbm4_controller
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;
#(
  parameter int unsigned NUM_STACKS     = 1,
  parameter int unsigned NUM_CHANNELS   = 32,
  parameter int unsigned CH_PER_CLUSTER = 8,
  parameter int unsigned DEPTH          = 16,
  parameter int unsigned CPL_DEPTH      = 8,
  parameter int unsigned TRK_SRC_W      = 2,
  parameter int unsigned TRK_ID_W       = 4,
  parameter int unsigned PHY_BACKEND    = 0,
  parameter int unsigned PHY_CMD_LAT    = 0,
  parameter int unsigned PHY_RD_LAT     = 0,
  parameter bit          WR_ACK_AT_DATA = 1'b1,
  parameter int unsigned NUM_MRS        = 4
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,
  input  hbm_cfg_t                     cfg_i,

  // bring-up handshakes with the (external) PHY / power / clock infrastructure
  input  logic                         power_good_i,
  input  logic                         clk_stable_i,
  input  logic                         phy_init_done_i,
  input  logic                         train_done_i,
  output logic                         phy_init_start_o,
  output logic                         train_start_o,
  output logic                         ready_o,
  output logic                         init_error_o,
  output logic [2:0]                   init_cause_o,
  output logic [2:0]                   init_state_o,

  // host request / response
  input  logic                         req_valid_i,
  output logic                         req_ready_o,
  input  hbm_addr_t                    req_addr_i,
  input  logic                         req_write_i,
  input  logic                         req_fence_i,
  input  hbm_id_t                      req_id_i,
  input  hbm_src_t                     req_src_i,
  input  hbm_qos_t                     req_qos_i,
  input  hbm_order_e                   req_order_i,
  input  hbm_data_t                    req_wdata_i,
  input  hbm_mask_t                    req_wmask_i,

  output logic                         rsp_valid_o,
  input  logic                         rsp_ready_i,
  output hbm_rsp_t                     rsp_o,

  // RAS control
  input  logic                         ecc_clear_i,
  input  logic                         inj_arm_i,
  input  logic [15:0]                  inj_pc_i,
  input  logic [1:0]                   inj_mode_i,
  input  logic [8:0]                   inj_bit_i,

  // simulation-PHY side: one bundle per pseudo-channel (flat index ((stack*NCH)+ch)*2+pc)
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 phy_ready_ext_i,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 phy_event_i,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 ondie_event_i,
  output logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_cmd_valid_o,
  output hbm_cmd_t [NUM_STACKS*NUM_CHANNELS*2-1:0]             sim_cmd_o,
  output logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_wvalid_o,
  output hbm_data_t [NUM_STACKS*NUM_CHANNELS*2-1:0]            sim_wdata_o,
  output hbm_mask_t [NUM_STACKS*NUM_CHANNELS*2-1:0]            sim_wmask_o,
  output hbm_ecc_t [NUM_STACKS*NUM_CHANNELS*2-1:0]             sim_wecc_o,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_rvalid_i,
  input  hbm_data_t [NUM_STACKS*NUM_CHANNELS*2-1:0]            sim_rdata_i,
  input  hbm_ecc_t [NUM_STACKS*NUM_CHANNELS*2-1:0]             sim_recc_i,
  input  logic [NUM_STACKS*NUM_CHANNELS*2-1:0]                 sim_rerr_i,

  // observability
  output hbm_pc_stat_t [NUM_STACKS*NUM_CHANNELS*2-1:0]        stat_o,
  output logic                         ev_accept_o,          // a request was accepted this cycle
  output logic                         ev_accept_rd_o,
  output logic                         ev_accept_wr_o,
  output logic                         ev_err_req_o,         // an error entry was created
  output logic                         ev_stall_id_o,        // held by the same-ID ordering tracker
  output logic                         ev_stall_q_o,         // held by a full pseudo-channel queue
  output logic                         ev_stall_fence_o,     // fence waiting for the machine to drain
  output logic [15:0]                  outstanding_o,
  output logic                         ref_cfg_infeasible_o   // per-bank refresh selected on a profile where it cannot keep up
);
  // --------------------------------------------------------------------------
  // geometry
  // --------------------------------------------------------------------------
  localparam int unsigned PCS     = 2;
  localparam int unsigned TOT_CH  = NUM_STACKS * NUM_CHANNELS;
  localparam int unsigned NPC     = TOT_CH * PCS;
  localparam int unsigned NCH_CL  = (CH_PER_CLUSTER < TOT_CH) ? CH_PER_CLUSTER : TOT_CH;
  localparam int unsigned NCL     = TOT_CH / NCH_CL;
  localparam int unsigned NPC_CL  = NCH_CL * PCS;
  localparam int unsigned PCW     = (NPC > 1) ? $clog2(NPC) : 1;
  localparam int unsigned LPW     = (NPC_CL > 1) ? $clog2(NPC_CL) : 1;
  localparam int unsigned CLW     = (NCL > 1) ? $clog2(NCL) : 1;
  localparam int unsigned TRK_N   = 1 << (TRK_SRC_W + TRK_ID_W);
  localparam int unsigned CNT_W   = 8;

  if (TOT_CH % NCH_CL != 0) begin : g_chk_cluster
    $error("sf_hbm4_controller: NUM_STACKS*NUM_CHANNELS must be a multiple of the cluster size");
  end

  // --------------------------------------------------------------------------
  // configuration derived signals
  // --------------------------------------------------------------------------
  hbm_timing_t tp;
  assign tp = hbm_profile(cfg_i.profile_sel);
  assign ref_cfg_infeasible_o = (cfg_i.ref_cfg.mode == REFMODE_PB) && !hbm_profile_pb_ok(cfg_i.profile_sel);

  // --------------------------------------------------------------------------
  // init
  // --------------------------------------------------------------------------
  logic        init_mrs_valid, init_mrs_ack;
  logic [7:0]  init_mrs_code;
  sf_hbm_init #(.NUM_MRS(NUM_MRS)) u_init (
    .clk_i, .rst_ni, .enable_i(cfg_i.enable), .timeout_i(cfg_i.init_timeout),
    .power_good_i, .clk_stable_i, .phy_init_done_i, .train_done_i,
    .phy_init_start_o, .train_start_o,
    .mrs_valid_o(init_mrs_valid), .mrs_code_o(init_mrs_code), .mrs_ack_i(init_mrs_ack),
    .ready_o, .error_o(init_error_o), .cause_o(init_cause_o), .state_o(init_state_o)
  );

  // --------------------------------------------------------------------------
  // ingress: map + checks
  // --------------------------------------------------------------------------
  hbm_loc_t         loc;
  logic [PCW-1:0]   map_pc;
  logic             err_range, err_mis;
  hbm_err_e         map_err;

  sf_hbm_addr_map #(.NUM_STACKS(NUM_STACKS), .NUM_CHANNELS(NUM_CHANNELS), .PCS(PCS)) u_map (
    .addr_i(req_addr_i), .mode_i(cfg_i.map_mode), .il_bits_i(cfg_i.il_bits), .hash_i(cfg_i.map_hash),
    .loc_o(loc), .pc_o(map_pc), .err_range_o(err_range), .err_misalign_o(err_mis), .err_o(map_err)
  );

  hbm_err_e err_c;
  always_comb begin
    err_c = map_err;
    if (err_c == HERR_NONE && req_write_i && cfg_i.ecc_en && (req_wmask_i != '1))
      err_c = HERR_POLICY;                      // partial write cannot keep a granule-wide ECC word valid
  end

  // error entries whose address is invalid are steered to pseudo-channel 0
  wire [PCW-1:0] tgt_pc = (err_c == HERR_RANGE || err_c == HERR_MISALIGN) ? '0 : map_pc;

  hbm_txn_t txn;
  always_comb begin
    txn        = '0;
    txn.src    = req_src_i;
    txn.id     = req_id_i;
    txn.qos    = req_qos_i;
    txn.order  = req_order_i;
    txn.write  = req_write_i;
    txn.err    = err_c;
    txn.bg     = loc.bg;  txn.ba = loc.ba;  txn.row = loc.row;  txn.col = loc.col;
  end

  // cluster steering
  wire [PCW-1:0]  tgt_ch    = tgt_pc >> 1;
  wire [CLW-1:0]  tgt_cl    = CLW'(32'(tgt_ch) / NCH_CL);   // explicit 32-bit widening (Verilator 5.020 -Wall WIDTHEXPAND)
  wire [LPW-1:0]  tgt_local = LPW'(32'(tgt_pc) % NPC_CL);

  // --------------------------------------------------------------------------
  // ID-order tracker, outstanding count, fence
  // --------------------------------------------------------------------------
  logic [CNT_W-1:0] trk_cnt [TRK_N];
  logic [PCW-1:0]   trk_pc  [TRK_N];
  logic [15:0]      outst_q;
  assign outstanding_o = outst_q;

  wire [TRK_SRC_W+TRK_ID_W-1:0] trk_idx = {req_src_i[TRK_SRC_W-1:0], req_id_i[TRK_ID_W-1:0]};
  wire trk_ok = (trk_cnt[trk_idx] == '0) || ((trk_pc[trk_idx] == tgt_pc) && (trk_cnt[trk_idx] != {CNT_W{1'b1}}));

  logic [NCL-1:0] cl_req_valid, cl_req_ready;
  logic [NCL-1:0] cl_rsp_valid, cl_rsp_ready, cl_mrs_ack;
  hbm_rsp_t [NCL-1:0] cl_rsp;

  logic        fence_rsp_valid_q;
  hbm_rsp_t    fence_rsp_q;

  wire fence_ok     = (outst_q == '0) && !fence_rsp_valid_q;
  wire pc_ready_sel = cl_req_ready[tgt_cl];
  wire normal_ok    = trk_ok && pc_ready_sel;

  assign req_ready_o = ready_o && (req_fence_i ? fence_ok : normal_ok);
  wire accept        = req_valid_i && req_ready_o;
  wire accept_norm   = accept && !req_fence_i;
  wire accept_fence  = accept &&  req_fence_i;

  always_comb begin
    cl_req_valid = '0;
    if (req_valid_i && ready_o && !req_fence_i && trk_ok) cl_req_valid[tgt_cl] = 1'b1;
  end

  assign ev_accept_o     = accept_norm;
  assign ev_accept_rd_o  = accept_norm && !req_write_i;
  assign ev_accept_wr_o  = accept_norm &&  req_write_i;
  assign ev_err_req_o    = accept_norm && (err_c != HERR_NONE);
  assign ev_stall_id_o   = req_valid_i && ready_o && !req_fence_i && !trk_ok;
  assign ev_stall_q_o    = req_valid_i && ready_o && !req_fence_i &&  trk_ok && !pc_ready_sel;
  assign ev_stall_fence_o = req_valid_i && ready_o && req_fence_i && !fence_ok;

  // ---- response side -------------------------------------------------------------
  logic top_valid, top_ready, top_sel_is_fence;
  hbm_rsp_t top_rsp;
  logic [NCL:0]      arb_valid, arb_ready;
  hbm_rsp_t [NCL:0]  arb_rsp;
  logic [(NCL>0?$clog2(NCL+1):1)-1:0] arb_sel;

  always_comb begin
    for (int c = 0; c < NCL; c++) begin arb_valid[c] = cl_rsp_valid[c]; arb_rsp[c] = cl_rsp[c]; end
    arb_valid[NCL] = fence_rsp_valid_q;
    arb_rsp[NCL]   = fence_rsp_q;
    for (int c = 0; c < NCL; c++) cl_rsp_ready[c] = arb_ready[c];
  end

  sf_hbm_rsp_arb #(.N(NCL+1)) u_top_arb (
    .clk_i, .rst_ni,
    .in_valid_i(arb_valid), .in_rsp_i(arb_rsp), .in_ready_o(arb_ready),
    .out_valid_o(rsp_valid_o), .out_rsp_o(rsp_o), .out_ready_i(rsp_ready_i), .sel_o(arb_sel)
  );
  wire rsp_fire     = rsp_valid_o && rsp_ready_i;
  wire rsp_is_fence = (int'(arb_sel) == NCL);
  wire rsp_norm_fire = rsp_fire && !rsp_is_fence;
  wire [TRK_SRC_W+TRK_ID_W-1:0] dec_idx = {rsp_o.src[TRK_SRC_W-1:0], rsp_o.id[TRK_ID_W-1:0]};

  // tracker: +1 on accept, -1 on response (same entry & same cycle nets to zero).
  // One always_ff per entry (generate) instead of a reset for-loop with non-blocking writes to an
  // unpacked array: Verilator 5.020 rejects the latter (BLKLOOPINIT) for large TRK_N, and per-entry
  // flops are also the more synthesis-friendly form.
  for (genvar e = 0; e < TRK_N; e++) begin : g_trk
    wire inc = accept_norm   && (trk_idx == (TRK_SRC_W+TRK_ID_W)'(e));
    wire dec = rsp_norm_fire && (dec_idx == (TRK_SRC_W+TRK_ID_W)'(e));
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        trk_cnt[e] <= '0;
        trk_pc[e]  <= '0;
      end else if (inc && !dec) begin
        trk_cnt[e] <= trk_cnt[e] + CNT_W'(1);
        trk_pc[e]  <= tgt_pc;
      end else if (dec && !inc) begin
        trk_cnt[e] <= trk_cnt[e] - CNT_W'(1);
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      outst_q <= '0; fence_rsp_valid_q <= 1'b0; fence_rsp_q <= '0;
    end else begin
      case ({accept_norm, rsp_norm_fire})
        2'b10:   outst_q <= outst_q + 16'd1;
        2'b01:   outst_q <= outst_q - 16'd1;
        default: outst_q <= outst_q;
      endcase
      // fence response register
      if (accept_fence) begin
        fence_rsp_valid_q <= 1'b1;
        fence_rsp_q       <= '0;
        fence_rsp_q.src   <= req_src_i;
        fence_rsp_q.id    <= req_id_i;
        fence_rsp_q.write <= 1'b1;
      end else if (arb_ready[NCL]) begin
        fence_rsp_valid_q <= 1'b0;
      end
    end
  end

  // --------------------------------------------------------------------------
  // clusters
  // --------------------------------------------------------------------------
  logic [1:0] pwr_req_w;
  assign pwr_req_w = cfg_i.pwr_req;
  assign init_mrs_ack = &cl_mrs_ack;

  for (genvar k = 0; k < NCL; k++) begin : g_cl
    logic [NPC_CL-1:0] inj_arm_cl;
    for (genvar q = 0; q < NPC_CL; q++) begin : g_inj
      assign inj_arm_cl[q] = inj_arm_i && (inj_pc_i == 16'(k*NPC_CL + q));
    end

    sf_hbm_stack_cluster #(
      .NCH(NCH_CL), .PCS(PCS), .DEPTH(DEPTH), .CPL_DEPTH(CPL_DEPTH), .PHY_BACKEND(PHY_BACKEND),
      .PHY_CMD_LAT(PHY_CMD_LAT), .PHY_RD_LAT(PHY_RD_LAT), .WR_ACK_AT_DATA(WR_ACK_AT_DATA)
    ) u_cl (
      .clk_i, .rst_ni, .tp_i(tp), .sched_cfg_i(cfg_i.sched), .ref_cfg_i(cfg_i.ref_cfg),
      .ecc_en_i(cfg_i.ecc_en), .ctrl_enable_i(ready_o),
      .pwr_req_i(pwr_req_w), .pd_idle_i(cfg_i.pd_idle), .sr_idle_i(cfg_i.sr_idle),
      .init_mrs_valid_i(init_mrs_valid), .init_mrs_code_i(init_mrs_code), .init_mrs_ack_o(cl_mrs_ack[k]),
      .ecc_clear_i, .inj_arm_i(inj_arm_cl), .inj_mode_i, .inj_bit_i,
      .req_valid_i(cl_req_valid[k]), .req_pc_i(tgt_local), .req_ready_o(cl_req_ready[k]),
      .req_txn_i(txn), .req_wdata_i, .req_wmask_i,
      .rsp_valid_o(cl_rsp_valid[k]), .rsp_ready_i(cl_rsp_ready[k]), .rsp_o(cl_rsp[k]),
      .phy_ready_ext_i(phy_ready_ext_i[k*NPC_CL +: NPC_CL]), .phy_event_i(phy_event_i[k*NPC_CL +: NPC_CL]),
      .ondie_event_i(ondie_event_i[k*NPC_CL +: NPC_CL]),
      .sim_cmd_valid_o(sim_cmd_valid_o[k*NPC_CL +: NPC_CL]), .sim_cmd_o(sim_cmd_o[k*NPC_CL +: NPC_CL]),
      .sim_wvalid_o(sim_wvalid_o[k*NPC_CL +: NPC_CL]), .sim_wdata_o(sim_wdata_o[k*NPC_CL +: NPC_CL]),
      .sim_wmask_o(sim_wmask_o[k*NPC_CL +: NPC_CL]), .sim_wecc_o(sim_wecc_o[k*NPC_CL +: NPC_CL]),
      .sim_rvalid_i(sim_rvalid_i[k*NPC_CL +: NPC_CL]), .sim_rdata_i(sim_rdata_i[k*NPC_CL +: NPC_CL]),
      .sim_recc_i(sim_recc_i[k*NPC_CL +: NPC_CL]), .sim_rerr_i(sim_rerr_i[k*NPC_CL +: NPC_CL]),
      .stat_o(stat_o[k*NPC_CL +: NPC_CL])
    );
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    if (accept_norm && (trk_cnt[trk_idx] == {CNT_W{1'b1}})) $error("[%m] ID tracker counter overflow");
    if (rsp_norm_fire && trk_cnt[dec_idx] == '0 && !(accept_norm && trk_idx == dec_idx))
      $error("[%m] response for {src=%0d,id=%0d} with no outstanding request", rsp_o.src, rsp_o.id);
  end
`endif
endmodule : sf_hbm4_controller
