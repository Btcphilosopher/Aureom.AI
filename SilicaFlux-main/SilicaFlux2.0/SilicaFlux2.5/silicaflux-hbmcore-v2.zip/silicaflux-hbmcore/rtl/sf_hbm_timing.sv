// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_timing.sv
//  Cross-bank / pseudo-channel timing enforcement engine.
//
//  Bank-local rules (tRCD, tRP, tRAS, tRC, tRTP, tWR) live in sf_hbm_bank_fsm.
//  This block enforces everything that couples banks:
//
//    tRRD_S / tRRD_L   ACT -> ACT, different / same bank group
//    tFAW              at most four ACT in any tFAW window (4 sliding counters)
//    tCCD_S / tCCD_L   column -> column, different / same bank group
//    WR -> RD          WL + burst + tWTR_S/L   (the L value applies to the same bank group)
//    RD -> WR          RL + burst + 2 - WL     (>=1)  [bus-turnaround convention: ENGINEERING_ASSUMPTION]
//    REF_AB -> any     tRFC         MRS -> any  tMRD         PDX -> any  tXP        SRX -> any  tXS
//
//  Every rule is a down-counter loaded with (N-1) on the issuing edge: `== 0` means
//  "the next dependent command is legal this cycle" (see hbm_ld in sf_hbm_pkg).
//  The DRAM model (verification/hbm4/hbm4_dram_model.sv) and the Python checker
//  implement the same rules INDEPENDENTLY, by comparing issue timestamps instead of
//  counting down, so a bug here is not silently shared.
//
//  CONTRACT
//    ok_*_o        legality of issuing that command class THIS cycle (per bank group).
//    *_i strobes   exactly the command issued this cycle (one per cycle).
//    violation_o   1-cycle pulse if a strobe arrives while its ok flag was low.
//  RESET: async assert; all counters clear.   Parameter: none (bank-group count from sf_hbm_pkg).
//  KNOWN LIMITATIONS: single command bus per pseudo-channel; REF_PB does not consume tRRD.
// =============================================================================
module sf_hbm_timing
  import sf_hbm_pkg::*;
(
  input  logic        clk_i,
  input  logic        rst_ni,
  input  hbm_timing_t tp_i,

  input  logic        act_i,
  input  logic        rd_i,
  input  logic        wr_i,
  input  hbm_bg_t     bg_i,           // bank group of the ACT/RD/WR
  input  logic        refab_i,
  input  logic        mrs_i,
  input  logic        pdx_i,          // power-down exit
  input  logic        srx_i,          // self-refresh exit

  output logic [HBM_NUM_BG-1:0] ok_act_o,
  output logic [HBM_NUM_BG-1:0] ok_rd_o,
  output logic [HBM_NUM_BG-1:0] ok_wr_o,
  output logic        ok_ref_o,       // REF_AB / REF_PB / MRS may issue (bank idleness is checked elsewhere)
  output logic        ok_misc_o,      // PRE / PREA / power commands are not blocked by tMRD / tXP / tXS
  output logic        busy_o,         // any cross-bank restriction active (for power-state idle detection)
  output logic        violation_o
);

  localparam int unsigned NBG = HBM_NUM_BG;

  logic [15:0] c_rrd [NBG];
  logic [15:0] c_ccd [NBG];
  logic [15:0] c_wtr [NBG];
  logic [15:0] c_faw [4];
  logic [15:0] c_rtw;
  logic [15:0] c_rfc, c_mrd, c_x;

  // derived constants (see header)
  logic [15:0] k_rtw, k_wtr_s, k_wtr_l;
  always_comb begin
    k_rtw   = (tp_i.rl + tp_i.burst + 16'd2 > tp_i.wl) ? (tp_i.rl + tp_i.burst + 16'd2 - tp_i.wl) : 16'd1;
    k_wtr_s = tp_i.wl + tp_i.burst + tp_i.twtr_s;
    k_wtr_l = tp_i.wl + tp_i.burst + tp_i.twtr_l;
  end

  logic blk_global;
  logic faw_ok;
  always_comb begin
    blk_global = (c_mrd != 16'd0) || (c_x != 16'd0);
    faw_ok     = (c_faw[0] == 16'd0) || (c_faw[1] == 16'd0) || (c_faw[2] == 16'd0) || (c_faw[3] == 16'd0);
    for (int g = 0; g < NBG; g++) begin
      ok_act_o[g] = (c_rrd[g] == 16'd0) && faw_ok && (c_rfc == 16'd0) && !blk_global;
      ok_rd_o[g]  = (c_ccd[g] == 16'd0) && (c_wtr[g] == 16'd0) && !blk_global;
      ok_wr_o[g]  = (c_ccd[g] == 16'd0) && (c_rtw == 16'd0) && !blk_global;
    end
    ok_ref_o  = (c_rfc == 16'd0) && !blk_global;
    ok_misc_o = !blk_global;
  end

  // busy: any counter non-zero
  always_comb begin
    busy_o = (c_rtw != 16'd0) || (c_rfc != 16'd0) || blk_global;
    for (int g = 0; g < NBG; g++)
      busy_o = busy_o || (c_rrd[g] != 16'd0) || (c_ccd[g] != 16'd0) || (c_wtr[g] != 16'd0);
    for (int f = 0; f < 4; f++)
      busy_o = busy_o || (c_faw[f] != 16'd0);
  end

  logic viol_c;
  always_comb begin
    viol_c = 1'b0;
    if (act_i  && !ok_act_o[bg_i]) viol_c = 1'b1;
    if (rd_i   && !ok_rd_o[bg_i])  viol_c = 1'b1;
    if (wr_i   && !ok_wr_o[bg_i])  viol_c = 1'b1;
    if ((refab_i || mrs_i) && !ok_ref_o) viol_c = 1'b1;
  end

  // slot used to record a new ACT in the FAW window: first expired slot, else the smallest counter
  logic [1:0] faw_slot;
  always_comb begin
    faw_slot = 2'd0;
    if      (c_faw[0] == 16'd0) faw_slot = 2'd0;
    else if (c_faw[1] == 16'd0) faw_slot = 2'd1;
    else if (c_faw[2] == 16'd0) faw_slot = 2'd2;
    else if (c_faw[3] == 16'd0) faw_slot = 2'd3;
    else begin
      faw_slot = 2'd0;
      if (c_faw[1] < c_faw[faw_slot]) faw_slot = 2'd1;
      if (c_faw[2] < c_faw[faw_slot]) faw_slot = 2'd2;
      if (c_faw[3] < c_faw[faw_slot]) faw_slot = 2'd3;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int g = 0; g < NBG; g++) begin c_rrd[g] <= '0; c_ccd[g] <= '0; c_wtr[g] <= '0; end
      for (int f = 0; f < 4; f++) c_faw[f] <= '0;
      c_rtw <= '0; c_rfc <= '0; c_mrd <= '0; c_x <= '0;
      violation_o <= 1'b0;
    end else begin
      violation_o <= viol_c;

      for (int g = 0; g < NBG; g++) begin
        c_rrd[g] <= hbm_dec16(c_rrd[g]);
        c_ccd[g] <= hbm_dec16(c_ccd[g]);
        c_wtr[g] <= hbm_dec16(c_wtr[g]);
      end
      for (int f = 0; f < 4; f++) c_faw[f] <= hbm_dec16(c_faw[f]);
      c_rtw <= hbm_dec16(c_rtw);
      c_rfc <= hbm_dec16(c_rfc);
      c_mrd <= hbm_dec16(c_mrd);
      c_x   <= hbm_dec16(c_x);

      if (act_i) begin
        for (int g = 0; g < NBG; g++)
          c_rrd[g] <= hbm_max16(hbm_dec16(c_rrd[g]), hbm_ld((g == int'(bg_i)) ? tp_i.trrd_l : tp_i.trrd_s));
        c_faw[faw_slot] <= hbm_ld(tp_i.tfaw);
      end
      if (rd_i || wr_i) begin
        for (int g = 0; g < NBG; g++)
          c_ccd[g] <= hbm_max16(hbm_dec16(c_ccd[g]), hbm_ld((g == int'(bg_i)) ? tp_i.tccd_l : tp_i.tccd_s));
      end
      if (rd_i)
        c_rtw <= hbm_max16(hbm_dec16(c_rtw), hbm_ld(k_rtw));
      if (wr_i) begin
        for (int g = 0; g < NBG; g++)
          c_wtr[g] <= hbm_max16(hbm_dec16(c_wtr[g]), hbm_ld((g == int'(bg_i)) ? k_wtr_l : k_wtr_s));
      end
      if (refab_i) c_rfc <= hbm_ld(tp_i.trfc);
      if (mrs_i)   c_mrd <= hbm_ld(tp_i.tmrd);
      if (pdx_i)   c_x   <= hbm_ld(tp_i.txp);
      if (srx_i)   c_x   <= hbm_ld(tp_i.txs);
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk_i) if (rst_ni) begin
    if ((int'(act_i) + int'(rd_i) + int'(wr_i)) > 1) $error("[%m] more than one of ACT/RD/WR in a cycle");
  end
`endif
endmodule : sf_hbm_timing
