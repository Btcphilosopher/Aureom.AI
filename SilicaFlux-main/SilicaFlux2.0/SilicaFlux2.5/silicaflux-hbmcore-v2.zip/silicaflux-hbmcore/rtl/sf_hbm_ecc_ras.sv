// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_ecc_ras.sv
//  Controller-level data protection (SECDED) + RAS bookkeeping of one pseudo-channel.
//
//  SEPARATION OF RESPONSIBILITIES (docs/RAS.md) - these are four DIFFERENT mechanisms:
//    1. ON-DIE DRAM ECC     inside the DRAM; invisible to this block except through an optional
//                           status/alert input (ondie_event_i). It is counted, never "corrected" here.
//    2. CONTROLLER SECDED   THIS block: (265,256) Hamming + overall parity over one 32 B granule:
//                           9 check bits + 1 overall parity bit = HBM_ECC_W = 10 sideband bits.
//                           ASSUMPTION (UNVERIFIED for HBM4): the PHY interface offers a sideband
//                           path that can carry/store those 10 bits per granule.
//    3. PHY/INTERFACE CHECK parity / CRC / alert seen by the PHY: phy_event_i, counted separately.
//    4. SYSTEM END-TO-END   not implemented here. Do not assume (1) provides (4).
//
//  CODE: data bit d sits at Hamming position pos(d) (positions that are not powers of two, in order);
//  check bit i covers the positions with bit i set; check bit 9 is overall parity.
//      syndrome == 0, parity ok      : clean
//      syndrome != 0, parity bad     : single-bit error -> corrected (or a check bit flipped)
//      syndrome == 0, parity bad     : overall-parity bit flipped -> corrected
//      syndrome != 0, parity ok      : double-bit error -> UNCORRECTABLE -> response err = HERR_ECC (poison)
//      syndrome points past the code : uncorrectable
//
//  PARTIAL WRITES with ECC enabled are not supported (a granule-wide code needs read-modify-write,
//  which is UNIMPLEMENTED); the ingress rejects them with HERR_POLICY.
//
//  FAULT INJECTION (test/RAS research): inj_arm_i arms ONE shot of inj_mode_i on bit inj_bit_i:
//      1  flip 1 bit of the next write data AFTER encoding (so the stored word is corrupted)
//      2  flip 2 adjacent bits of the next write data after encoding
//      3  flip 1 bit of the next read data BEFORE decoding
//  Counters are saturating 32-bit; log_* holds the FIRST error since clear.
//  RESET: async assert.
// =============================================================================
module sf_hbm_ecc_ras
  import sf_hbm_pkg::*;
(
  input  logic          clk_i,
  input  logic          rst_ni,
  input  logic          ecc_en_i,
  input  logic          clear_i,

  // fault injection
  input  logic          inj_arm_i,
  input  logic [1:0]    inj_mode_i,
  input  logic [8:0]    inj_bit_i,

  // write path (combinational encode; wr_fire_i marks the cycle the data really leaves)
  input  logic          wr_fire_i,
  input  hbm_data_t     wdata_i,
  output hbm_data_t     wdata_o,
  output hbm_ecc_t      wecc_o,

  // read path (combinational decode; rd_fire_i marks a real return)
  input  logic          rd_fire_i,
  input  hbm_data_t     rdata_i,
  input  hbm_ecc_t      recc_i,
  output hbm_data_t     rdata_o,
  output hbm_err_e      rerr_o,
  output logic          rcorr_o,

  // interface / on-die status inputs (counted only)
  input  logic          phy_event_i,
  input  logic                 phy_rd_err_i,     // PHY flagged the returned read data (counted separately from phy_event_i)
  input  logic          ondie_event_i,

  // RAS outputs
  output logic [31:0]   ce_cnt_o,
  output logic [31:0]   ue_cnt_o,
  output logic [31:0]   phy_cnt_o,
  output logic [31:0]   ondie_cnt_o,
  output logic          log_valid_o,
  output logic          log_ue_o,
  output logic [8:0]    log_syndrome_o,
  output logic          alert_o,          // maintenance alert: any UE since clear
  output logic          ev_ce_o,
  output logic          ev_ue_o
);

  // -------- code construction --------------------------------------------------
  // v2: the same SECDED code (docs/RAS_CODE.md) written for synthesis as CONSTANT tables + reduction-XOR trees.
  // v1 expressed encode and decode as 256 sequential loop iterations (bit-serial XOR accumulation, a priority chain for
  // the correction): function-identical, but it mapped to a ~6.4 ns path on the NanGate45 proxy. Function equivalence
  // is PROVEN for all 2^266 inputs against the v1 functions (verification/formal/eq_secded.py, SAT) and checked by the
  // cocotb comparison against the independent Python SECDED (random + exhaustive single-bit).
  typedef logic [8:0] pos_t;
  typedef pos_t [HBM_GRAN_BITS-1:0]       pos_tab_t;     // Hamming position of every data bit (powers of two skipped)
  typedef hbm_data_t [8:0]                mask_tab_t;    // mask_tab[i][k] = bit i of position(k)
  function automatic pos_tab_t mk_pos();
    pos_tab_t t;
    int unsigned pos;
    t = '0; pos = 0;
    for (int k = 0; k < HBM_GRAN_BITS; k++) begin
      pos = pos + 1;
      while ((pos & (pos - 1)) == 0) pos = pos + 1;
      t[k] = pos_t'(pos);
    end
    return t;
  endfunction
  function automatic mask_tab_t mk_mask(input pos_tab_t t);
    mask_tab_t m;
    m = '0;
    for (int i = 0; i < 9; i++)
      for (int k = 0; k < HBM_GRAN_BITS; k++) m[i][k] = t[k][i];
    return m;
  endfunction
  localparam pos_tab_t  POS  = mk_pos();
  localparam mask_tab_t MASK = mk_mask(POS);

  function automatic hbm_ecc_t enc(input hbm_data_t d);
    hbm_ecc_t c;
    for (int i = 0; i < 9; i++) c[i] = ^(d & MASK[i]);
    c[9] = (^d) ^ (^c[8:0]);
    return c;
  endfunction

  // returns {uncorrectable, corrected, syndrome[8:0], corrected_data}
  typedef struct packed {
    logic      ue;
    logic      ce;
    logic [8:0] syn;
    hbm_data_t data;
  } dec_t;

  function automatic dec_t dec(input hbm_data_t d, input hbm_ecc_t c);
    dec_t      r;
    hbm_ecc_t  cc;
    logic [8:0] syn;
    logic      op, is_pow2, any_match, nz;
    hbm_data_t match;
    cc  = enc(d);
    syn = cc[8:0] ^ c[8:0];
    op  = (^d) ^ (^c);                  // overall parity over data + all 10 stored check bits
    nz  = (syn != 9'd0);
    is_pow2 = ((syn & (syn - 9'd1)) == 9'd0);
    for (int k = 0; k < HBM_GRAN_BITS; k++) match[k] = (syn == POS[k]);
    any_match = |match;
    // clean: syn == 0 && !op ; single (odd) error: op -> data bit (match), check bit (pow2 / syn 0) or uncorrectable (no match)
    r.syn  = syn;
    r.data = d ^ (op ? match : '0);
    r.ue   = (!op && nz) || (op && nz && !is_pow2 && !any_match);
    r.ce   = op && !(nz && !is_pow2 && !any_match);
    return r;
  endfunction

  // -------- one-shot injection state ----------------------------------------
  logic        armed_q;
  logic [1:0]  mode_q;
  logic [8:0]  bit_q;

  hbm_ecc_t    enc_c;
  hbm_data_t   w_data;
  always_comb begin
    enc_c  = enc(wdata_i);
    w_data = wdata_i;
    if (armed_q && (mode_q == 2'd1) && !bit_q[8]) w_data[bit_q[7:0]] = ~wdata_i[bit_q[7:0]];
    if (armed_q && (mode_q == 2'd2) && !bit_q[8] && (bit_q[7:0] != 8'hFF)) begin
      w_data[bit_q[7:0]]        = ~wdata_i[bit_q[7:0]];
      w_data[bit_q[7:0] + 8'd1] = ~wdata_i[bit_q[7:0] + 8'd1];
    end
    wdata_o = w_data;
    wecc_o  = ecc_en_i ? enc_c : '0;
  end

  hbm_data_t r_in;
  dec_t      dres;
  always_comb begin
    r_in = rdata_i;
    if (armed_q && (mode_q == 2'd3) && !bit_q[8]) r_in[bit_q[7:0]] = ~rdata_i[bit_q[7:0]];
    dres    = dec(r_in, recc_i);
    if (ecc_en_i) begin
      rdata_o = dres.data;
      rerr_o  = dres.ue ? HERR_ECC : HERR_NONE;
      rcorr_o = dres.ce && !dres.ue;
    end else begin
      rdata_o = r_in;
      rerr_o  = HERR_NONE;
      rcorr_o = 1'b0;
    end
  end

  assign ev_ce_o = rd_fire_i && ecc_en_i && dres.ce && !dres.ue;
  assign ev_ue_o = rd_fire_i && ecc_en_i && dres.ue;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      armed_q <= 1'b0; mode_q <= '0; bit_q <= '0;
      ce_cnt_o <= '0; ue_cnt_o <= '0; phy_cnt_o <= '0; ondie_cnt_o <= '0;
      log_valid_o <= 1'b0; log_ue_o <= 1'b0; log_syndrome_o <= '0; alert_o <= 1'b0;
    end else begin
      // consume the shot when the targeted path fires ...
      if (armed_q && (((mode_q == 2'd1 || mode_q == 2'd2) && wr_fire_i) || ((mode_q == 2'd3) && rd_fire_i)))
        armed_q <= 1'b0;
      // ... and THEN accept a new arm request, so an arm arriving in the consuming cycle is not lost
      // (v2 fix: the previous order let the consume-clear override a same-cycle arm)
      if (inj_arm_i) begin armed_q <= 1'b1; mode_q <= inj_mode_i; bit_q <= inj_bit_i; end

      if (clear_i) begin
        ce_cnt_o <= '0; ue_cnt_o <= '0; phy_cnt_o <= '0; ondie_cnt_o <= '0;
        log_valid_o <= 1'b0; alert_o <= 1'b0;
      end else begin
        if (ev_ce_o && ce_cnt_o != 32'hFFFF_FFFF) ce_cnt_o <= ce_cnt_o + 32'd1;
        if (ev_ue_o && ue_cnt_o != 32'hFFFF_FFFF) ue_cnt_o <= ue_cnt_o + 32'd1;
        // two independent PHY-error sources may fire in one cycle: count both (v2 fix, saturating)
        if ((phy_event_i || phy_rd_err_i) && phy_cnt_o != 32'hFFFF_FFFF)
          phy_cnt_o <= (phy_event_i && phy_rd_err_i && phy_cnt_o != 32'hFFFF_FFFE) ? phy_cnt_o + 32'd2 :
                       (phy_event_i && phy_rd_err_i)                               ? 32'hFFFF_FFFF  : phy_cnt_o + 32'd1;
        if (ondie_event_i && ondie_cnt_o != 32'hFFFF_FFFF) ondie_cnt_o <= ondie_cnt_o + 32'd1;
        if ((ev_ce_o || ev_ue_o) && !log_valid_o) begin
          log_valid_o    <= 1'b1;
          log_ue_o       <= ev_ue_o;
          log_syndrome_o <= dres.syn;
        end
        if (ev_ue_o) alert_o <= 1'b1;
      end
    end
  end
endmodule : sf_hbm_ecc_ras
