// =============================================================================
//  SILICAFLUX HBMCORE  --  sf_hbm_refresh.sv
//  Refresh manager of one pseudo-channel.
//
//  MODEL (abstract; refresh MODE availability for HBM4 is UNVERIFIED - docs/STANDARDS_MATRIX.md)
//    A free-running interval counter adds one unit of refresh DEBT every tREFI cycles
//    (all-bank mode) or every tREFI/NUM_BANKS cycles (per-bank mode). Each completed refresh
//    command repays one unit.
//        debt >  0            refresh owed
//        debt >= max_postpone refresh URGENT: new ACT and (all-bank) column commands are held,
//                             the sequence gets scheduler priority -> refresh cannot be starved
//        debt <= -max_pullin  no more pull-in
//    Postponement is therefore bounded by max_postpone intervals and pull-in by max_pullin
//    intervals - both profile fields, never implicit.
//    deadline_miss_o pulses if debt ever exceeds max_postpone (must never happen; asserted in tests).
//
//  START CONDITIONS
//      urgent
//      || (cfg.eager && debt > 0)
//      || (queue idle && (debt > 0 || (cfg.pullin_en && debt > -max_pullin)))
//
//  SEQUENCE (all-bank):  HOLD (no new ACT) -> PREA until every bank idle -> REF_AB -> back to IDLE.
//           (per-bank):  HOLD target bank -> PRE if open -> wait idle -> REF_PB(bank) -> next bank.
//  The sequence is expressed as maintenance commands; sf_hbm_scheduler arbitrates them against
//  demand traffic and only grants them when every timing rule allows.
//
//  pause_i (self-refresh) freezes the engine; block_i (power state ENTER, PD, SR, EXIT or WAKE, i.e. neither ACTIVE nor PREP) stops a sequence from starting - and aborts one still in its HOLD phase - while the debt keeps accruing,
//  so a refresh that becomes urgent during power-down is serviced after the power module wakes the channel (found by tb_pc_single power test); clear_i (self-refresh exit) zeroes debt,
//  because the DRAM refreshed itself.
//  RESET: async assert; debt 0, IDLE.
//  v2 REFRESH MANAGEMENT (sf_hbm_rfm, research hook): when no refresh sequence starts, a level request
//  rfm_req_i/rfm_bank_i/rfm_row_i starts an RFM sequence on that bank: HOLD bank (ACT and column) -> PRE if open ->
//  wait idle -> HCMD_RFM(bank,row). The RFM sequence has scheduler priority (otherwise demand on other banks could
//  postpone it until the bank's ACTs are blocked at raammt) and does not change the refresh debt. A refresh that
//  becomes due meanwhile starts right after it (bounded: one RFM sequence ~ tRAS + tRP + tRFM).
//  v2 FIX (independent review A3): max_postpone / max_pullin are clamped to the debt-register range (see below).
//  v2 FIX (found by the coverage regression): the refresh MODE is latched for the duration of a sequence (seq_pb_q).
//  v1 read cfg_i.mode combinationally: a CSR switch from per-bank to all-bank while a per-bank sequence sat in R_REF
//  turned it into a REF_AB sequence that had never closed the other banks, and R_REF had no way back to PRE - a bank
//  with pending hits stayed open, REF_AB was never legal and the refresh deadline was missed. In addition R_REF now
//  returns to PRE if its target is (re)opened.
//  v2 FIX (found by tb_pc_single refswitch): the debt counts intervals of the CURRENT mode (tREFI or tREFI/NB), so a
//  CSR mode change must not re-interpret an existing debt (e.g. right after a REF_AB, whose tRFC can exceed the per-bank
//  interval, every bank is busy while per-bank units accrue: spurious deadline miss). The CSR mode is therefore a
//  REQUEST; the effective mode (mode_q) changes only with the sequencer idle and the debt repaid (<= 0). While a switch
//  is pending the engine refreshes eagerly to get there. AB -> PB restarts the per-bank pointer at bank 0 with debt 0;
//  PB -> AB starts with one REF_AB owed (margin against the per-bank deadlines). Switching to / from OFF is immediate.
// =============================================================================
module sf_hbm_refresh
  import sf_hbm_pkg::*;
(
  input  logic                         clk_i,
  input  logic                         rst_ni,
  input  hbm_timing_t                  tp_i,
  input  hbm_ref_cfg_t                 cfg_i,
  input  logic                         enable_i,        // controller ready
  input  logic                         pause_i,         // self-refresh: timer frozen, sequencer idle
  input  logic                         block_i,         // channel not ACTIVE/PREP: never START a sequence and abort one still in HOLD; PREA/PREWAIT/REF run to completion (power-down entry waits for quiet_o, which includes this engine being idle); debt keeps accruing
  input  logic                         clear_i,
  input  logic                         queue_idle_i,

  input  logic [HBM_NUM_BANKS-1:0]     bk_idle_i,
  input  logic [HBM_NUM_BANKS-1:0]     bk_row_open_i,

  // v2: refresh-management request (sf_hbm_rfm)
  input  logic                         rfm_req_i,
  input  logic [HBM_BANK_W-1:0]        rfm_bank_i,
  input  hbm_row_t                     rfm_row_i,
  output logic                         ev_rfm_o,

  output logic                         mnt_valid_o,
  output hbm_cmd_t                     mnt_cmd_o,
  output logic                         mnt_prio_o,
  input  logic                         mnt_grant_i,

  output logic                         hold_act_o,
  output logic                         hold_col_o,
  output logic                         hold_bank_valid_o,
  output logic [HBM_BANK_W-1:0]        hold_bank_o,
  output logic                         hold_bank_col_o,

  output logic signed [7:0]            debt_o,
  output logic                         urgent_o,
  output logic                         active_o,        // a refresh sequence is in progress
  output logic                         ev_ref_o,
  output logic                         ev_forced_o,
  output logic                         ev_pullin_o,
  output logic                         deadline_miss_o
);
  localparam int unsigned NB = HBM_NUM_BANKS;

  typedef enum logic [2:0] {R_IDLE, R_HOLD, R_PREA, R_PREWAIT, R_REF} rstate_e;
  rstate_e st_q;

  logic [15:0]        ivl_cnt_q;
  logic signed [7:0]  debt_q;
  logic [HBM_BANK_W-1:0] ptr_q;
  logic                  kind_q;        // 0 refresh sequence, 1 refresh-management (RFM) sequence
  logic                  seq_pb_q;      // per-bank mode latched at the start of the running refresh sequence
  logic [HBM_BANK_W-1:0] tgt_q;         // RFM target bank
  hbm_row_t              rrow_q;        // RFM row (directed mode)

  hbm_ref_mode_e mode_q;                                  // v2: EFFECTIVE refresh mode (see header)
  wire pb_mode  = (mode_q == REFMODE_PB);
  wire off_mode = (mode_q == REFMODE_OFF);

  logic [15:0] interval;
  always_comb begin
    interval = pb_mode ? (tp_i.trefi >> HBM_BANK_W) : tp_i.trefi;
    if (interval == 16'd0) interval = 16'd1;
  end

  // v2 (independent review A3): the debt register saturates at +/-DEBT_SAT; a postpone / pull-in limit above that range
  // was truncated to 8 bits (256 -> 0) or could never be reached (101..255): refresh could stop with no alarm.
  // The limits are clamped to the register range here AND rejected above it by scripts/gen_profiles.py.
  localparam int unsigned DEBT_SAT = 100;
  wire [15:0] mp_c = (tp_i.max_postpone > 16'(DEBT_SAT)) ? 16'(DEBT_SAT) : tp_i.max_postpone;
  wire [15:0] mu_c = (tp_i.max_pullin   > 16'(DEBT_SAT)) ? 16'(DEBT_SAT) : tp_i.max_pullin;
  wire signed [8:0] mp = $signed({1'b0, mp_c[7:0]});
  wire signed [8:0] mu = $signed({1'b0, mu_c[7:0]});
  wire signed [8:0] debt_ext = {debt_q[7], debt_q};

  wire urgent   = !off_mode && (debt_ext >= mp);
  wire pending  = (debt_ext > 9'sd0);
  wire can_pull = cfg_i.pullin_en && (debt_ext > -mu);
  wire sw_pend   = (cfg_i.mode != mode_q);
  wire sw_ok     = sw_pend && (st_q == R_IDLE) &&
                   (off_mode || (cfg_i.mode == REFMODE_OFF) || (debt_ext <= 9'sd0) || !enable_i);
  wire start    = !off_mode && enable_i && !pause_i && !block_i && !sw_ok &&
                  (urgent || ((cfg_i.eager || sw_pend) && pending) || (queue_idle_i && (pending || can_pull)));
  wire rfm_start = enable_i && !pause_i && !block_i && rfm_req_i && !start;
  wire pbk       = seq_pb_q || kind_q;                      // the running sequence targets ONE bank (latched mode)
  wire [HBM_BANK_W-1:0] tbank = kind_q ? tgt_q : ptr_q;

  assign debt_o   = debt_q;
  assign urgent_o = urgent;
  assign active_o = (st_q != R_IDLE);

  logic all_idle;
  assign all_idle = &bk_idle_i;

  // ---- maintenance command / holds (combinational from state) ----------------
  always_comb begin
    mnt_valid_o       = 1'b0;
    mnt_cmd_o         = '0;
    mnt_prio_o        = urgent || kind_q;
    hold_act_o        = 1'b0;
    hold_col_o        = 1'b0;
    hold_bank_valid_o = 1'b0;
    hold_bank_o       = tbank;
    hold_bank_col_o   = 1'b0;
    case (st_q)
      R_HOLD, R_PREA, R_PREWAIT, R_REF: begin
        if (!pbk) begin
          hold_act_o = 1'b1;
          hold_col_o = urgent;
        end else begin
          hold_bank_valid_o = 1'b1;
          hold_bank_col_o   = urgent || kind_q;            // RFM: drain the bank so its PRE becomes legal
        end
        if (st_q == R_PREA) begin
          mnt_valid_o = 1'b1;
          if (pbk) begin
            mnt_cmd_o.cmd = HCMD_PRE;
            mnt_cmd_o.bg  = hbm_bg_t'(tbank[HBM_BANK_W-1 -: HBM_BG_W]);
            mnt_cmd_o.ba  = hbm_ba_t'(tbank[HBM_BA_W-1:0]);
          end else begin
            mnt_cmd_o.cmd = HCMD_PREA;
          end
        end else if (st_q == R_REF) begin
          mnt_valid_o = 1'b1;
          mnt_prio_o  = 1'b1;
          if (kind_q) begin
            mnt_cmd_o.cmd = HCMD_RFM;
            mnt_cmd_o.bg  = hbm_bg_t'(tgt_q[HBM_BANK_W-1 -: HBM_BG_W]);
            mnt_cmd_o.ba  = hbm_ba_t'(tgt_q[HBM_BA_W-1:0]);
            mnt_cmd_o.row = rrow_q;
          end else if (seq_pb_q) begin
            mnt_cmd_o.cmd = HCMD_REF_PB;
            mnt_cmd_o.bg  = hbm_bg_t'(ptr_q[HBM_BANK_W-1 -: HBM_BG_W]);
            mnt_cmd_o.ba  = hbm_ba_t'(ptr_q[HBM_BA_W-1:0]);
          end else begin
            mnt_cmd_o.cmd = HCMD_REF_AB;
          end
        end
      end
      default: ;
    endcase
  end

  wire target_idle = pbk ? bk_idle_i[tbank] : all_idle;
  wire target_open = pbk ? bk_row_open_i[tbank] : (|bk_row_open_i);

  logic tick;
  assign tick = (ivl_cnt_q == 16'd0);

  // next debt value (combinational): accrual on the interval tick, repayment on a granted REF
  logic signed [8:0] nd_c;
  always_comb begin
    nd_c = debt_ext;
    if (off_mode || clear_i || !enable_i) begin
      if (clear_i) nd_c = 9'sd0;
    end else if (!pause_i) begin
      if (tick) nd_c = nd_c + 9'sd1;
    end
    if (st_q == R_REF && mnt_grant_i && !kind_q) nd_c = nd_c - 9'sd1;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= R_IDLE; ivl_cnt_q <= 16'd0; debt_q <= '0; ptr_q <= '0;
      kind_q <= 1'b0; tgt_q <= '0; rrow_q <= '0; ev_rfm_o <= 1'b0; seq_pb_q <= 1'b0; mode_q <= REFMODE_AB;
      ev_ref_o <= 1'b0; ev_forced_o <= 1'b0; ev_pullin_o <= 1'b0; deadline_miss_o <= 1'b0;
    end else begin
      ev_ref_o <= 1'b0; ev_forced_o <= 1'b0; ev_pullin_o <= 1'b0; deadline_miss_o <= 1'b0; ev_rfm_o <= 1'b0;

      // interval timer
      if (off_mode || clear_i || !enable_i) begin
        ivl_cnt_q <= interval - 16'd1;
      end else if (!pause_i) begin
        if (tick) ivl_cnt_q <= interval - 16'd1;
        else      ivl_cnt_q <= ivl_cnt_q - 16'd1;
      end

      // sequencer
      case (st_q)
        R_IDLE: begin
          if (start) begin
            st_q <= R_HOLD; kind_q <= 1'b0; seq_pb_q <= pb_mode;
          end else if (rfm_start) begin
            st_q <= R_HOLD; kind_q <= 1'b1; tgt_q <= rfm_bank_i; rrow_q <= rfm_row_i;
          end
        end
        R_HOLD: begin
          if (pause_i || (off_mode && !kind_q) || block_i) st_q <= R_IDLE;
          else if (target_open)    st_q <= R_PREA;
          else if (target_idle)    st_q <= R_REF;
          else                     st_q <= R_PREWAIT;   // closing / refreshing already in flight
        end
        R_PREA: if (mnt_grant_i) st_q <= R_PREWAIT;
        R_PREWAIT: begin
          if (target_idle) st_q <= R_REF;
          else if (target_open) st_q <= R_PREA;        // something re-opened the target (should not happen under hold)
        end
        R_REF: if (!mnt_grant_i && target_open) begin
          st_q <= R_PREA;                                  // v2: the target was (re)opened - close it again
        end else if (mnt_grant_i) begin
          st_q <= R_IDLE;
          if (kind_q) begin
            ev_rfm_o <= 1'b1;
          end else begin
            ev_ref_o    <= 1'b1;
            ev_forced_o <= urgent;
            ev_pullin_o <= !pending;
            if (seq_pb_q) ptr_q <= ptr_q + HBM_BANK_W'(1);
          end
        end
        default: st_q <= R_IDLE;
      endcase

      // saturate debt into the 8-bit register; flag a missed deadline
      if (nd_c > mp) deadline_miss_o <= 1'b1;
      if (nd_c > 9'sd100)       debt_q <= 8'sd100;
      else if (nd_c < -9'sd100) debt_q <= -8'sd100;
      else                      debt_q <= nd_c[7:0];

      // v2: effective-mode switch at a safe point (overrides the debt / interval updates above)
      if (sw_ok) begin
        mode_q <= cfg_i.mode;
        ptr_q  <= '0;
        debt_q <= ((mode_q == REFMODE_PB) && (cfg_i.mode == REFMODE_AB)) ? 8'sd1 : 8'sd0;
        ivl_cnt_q <= ((cfg_i.mode == REFMODE_PB) ? ((tp_i.trefi >> HBM_BANK_W) == 16'd0 ? 16'd1 : (tp_i.trefi >> HBM_BANK_W))
                                                 : ((tp_i.trefi == 16'd0) ? 16'd1 : tp_i.trefi)) - 16'd1;
      end
    end
  end
endmodule : sf_hbm_refresh
