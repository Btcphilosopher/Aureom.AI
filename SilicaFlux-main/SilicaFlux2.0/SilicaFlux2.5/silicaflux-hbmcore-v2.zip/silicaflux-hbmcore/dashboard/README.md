# SILICAFLUX HBMCORE engineering dashboard

`build_dashboard.py` turns the real simulation, synthesis and verification outputs of this project into **one
self-contained HTML file**, `dashboard/index.html` (inline CSS / JS / SVG; no network access, no CDN, no webfonts).

```
python3 dashboard/build_dashboard.py          # or: make hbm-dashboard   (runs make hbm-report first)
python3 dashboard/build_dashboard.py --quiet
open dashboard/index.html                     # any browser, works from file://
```

Plain `python3` (standard library only). It prints every input as found / MISSING, always exits 0 when inputs are
missing (the affected views then show `no data: <file> not found (run <make target>)`), and is deterministic: the same
inputs give a byte-identical page (no wall-clock time is embedded; a content fingerprint is shown instead).
Re-run it whenever more benchmarks, traces, synthesis or verification results appear.

## Inputs (all optional)

| input | produced by | views |
|---|---|---|
| `reports/bench/*.json` | `make hbm-benchmark` (tb_bench) | 2 3 5 8 9 10 11 12 14 15 |
| `reports/bench/timeline/*.timeline.json`, `*.cmds` | `make hbm-benchmark` | 4 5 6 8 |
| `reports/traces/pc_single_p<profile>_pol<policy>.trace` | `tb_pc_single +HBM_TRACE=...` | 7 10 |
| `configs/timing/profiles.json` | `make hbm-gen` | 7 10 |
| `reports/summary.json` | `make hbm-report` | fallback for benchmarks, regression, formal, synthesis; refused list |
| `reports/regression.json`, `formal.json`, `mutation_report.json`, `cocotb.json` | `make hbm-regression`, `hbm-formal`, `hbm-mutation`, `run_cocotb.py` | 14 |
| `reports/synth/*.json`, `SYNTH.md` | `make hbm-synthesis` | 1 15 16 |
| `reports/datafabric_summary.json` | DataFabric / DMA testbench summary | 13 |
| `integration/datafabric/third_party/noc_v2/PACKET_SPEC.md` | vendored contract | 13 (field table) |

## Honesty rules (enforced in the page)

* No fabricated data: every number, bar, heat cell and timeline point is read from a file above. Missing input = explicit
  `no data` panel. Nothing is smoothed, extrapolated or synthesised.
* Values computed in the page or by the build script are labelled "derived": nearest-rank latency percentiles from the exact
  histogram, GB/s split by read/write bytes, completion rate from the timeline `done` counter, the open/active estimate from
  ACT/PRE events (cross-checked against the sampled RTL `bank_state` where available), the Jain index, REF intervals, the
  per-pseudo-channel gate-equivalent sum used for the floorplan.
* Every view carries the banner `MODELLED - RTL simulation against a behavioural DRAM model with a HYPOTHETICAL timing
  profile. Not hardware measurements. Not HBM4 performance.` Synthesis numbers are labelled
  `technology-independent proxy (no PDK / no STA)`. Views 1, 13 and 16 are labelled `schematic`.
* Large inputs are down-sampled deterministically (fixed stride) and the view says so; at the time of writing nothing needed it
  (caps: 4000 timeline samples, 60000 command-log rows, 4000 REF commands per trace).
* The build refuses to write a page containing a compliance claim phrase, and scrubs such phrases out of embedded text.

## Notes on specific views

* **7 DRAM timing diagram / 10 refresh**: sequences and REF lists are extracted from the real RTL trace at build time;
  minima come from the selected profile of `profiles.json` (profile id taken from the trace file name). Candidate row visits are
  those with ACT-to-ACT span <= 8 x tRC; the whole-trace check covers every row visit.
* **4 bank-state heat map**: row 3 is the sampled `bank_state` of pseudo-channel 0 (timeline `bank0`: 2 bits per bank,
  0 IDLE, 1 ACTIVE, 2 PRECHARGING, 3 REFRESHING).
* **9 latency**: one histogram per run; per-channel latency is not instrumented in the bench.
* **16 floorplan**: schematic only. Block area is proportional to gate equivalents (`reports/synth/pseudochannel.json` if present,
  otherwise the sum of standalone module proxies x instance count).
* Light theme toggle in the header (dark navy is the default; the choice is remembered in `localStorage` when available).

Only files under `dashboard/` are created or modified by this tool.
