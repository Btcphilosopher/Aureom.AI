#!/usr/bin/env bash
# v2 finalisation: everything after the full regression, in order, each step logged to build/finalize/<step>.log.
# A failing step is RECORDED (build/finalize/STEPS.txt) and the script continues; nothing is reported as passing that did not run.
#   usage: scripts/v2_finalize.sh [step ...]      (no argument: all steps, STEPS.txt restarted; with arguments: only those
#                                                  steps, appended to STEPS.txt - lets a long finalisation run in parts)
#   prerequisites: scripts/regress.py --full has run (benches built), scripts/build_bench_variants.sh has run,
#                  yowasp-yosys on PATH (or YOWASP_BIN), build/lib/ng45.lib (scripts/fetch_ng45.sh)
cd "$(dirname "$0")/.."
mkdir -p build/finalize
ALL="benchmarks vector_replay integration rowhammer coverage synth_ng45 activity report status export_sf dashboard"
if [ $# -eq 0 ]; then set -- $ALL; : > build/finalize/STEPS.txt; fi
cmd_of() {
  case $1 in
    benchmarks)    echo "./scripts/run_benchmarks.sh all" ;;
    vector_replay) echo "python3 integration/vectorcore/compare_with_python.py" ;;
    integration)   echo "python3 scripts/collect_integration.py" ;;
    rowhammer)     echo "python3 scripts/rowhammer_report.py" ;;
    coverage)      echo "env JOBS=2 python3 scripts/coverage.py" ;;
    synth_ng45)    echo "python3 scripts/synth_ng45.py --jobs 2" ;;
    activity)      echo "python3 scripts/activity_export.py" ;;
    report)        echo "python3 scripts/make_report.py" ;;
    status)        echo "python3 scripts/status_v2.py" ;;
    export_sf)     echo "python3 scripts/export_sf.py" ;;
    dashboard)     echo "python3 dashboard/build_dashboard.py --quiet" ;;
    *)             echo "" ;;
  esac
}
for name in "$@"; do
  cmd=$(cmd_of "$name")
  if [ -z "$cmd" ]; then echo "$(date +%H:%M:%S) $name UNKNOWN_STEP" | tee -a build/finalize/STEPS.txt; continue; fi
  t0=$(date +%s)
  if $cmd > "build/finalize/$name.log" 2>&1; then st=OK; else st="FAILED(rc=$?)"; fi
  echo "$(date +%H:%M:%S) $name $st $(( $(date +%s) - t0 ))s" | tee -a build/finalize/STEPS.txt
done
echo "finalize done: $*" | tee -a build/finalize/STEPS.txt
