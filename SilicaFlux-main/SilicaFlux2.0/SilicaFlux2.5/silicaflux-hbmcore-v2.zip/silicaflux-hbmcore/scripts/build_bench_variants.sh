#!/usr/bin/env bash
# Build the benchmark testbench variants used by scripts/run_benchmarks.sh (memory heavy: sequential, 2 jobs each).
cd "$(dirname "$0")/.."
export VOPT="-O1 -CFLAGS -O1"
build() { tag=$1; shift; if [ -x build/tb_bench_$tag/obj/Vtb_bench ] && [ -z "${REBUILD:-}" ]; then echo "[skip ] $tag (already built)"; return; fi; echo "[build] $tag $*"; JOBS=2 TAG=$tag ./scripts/vsim.sh tb_bench "$@" 2>&1 | tail -1; }
build ch32p1  -GNCH=32 -GCHCL=8 -GCPLD=32 -GQD=16 -GPORTS=1
build ch32p0  -GNCH=32 -GCHCL=8 -GCPLD=32 -GQD=16 -GPORTS=0
for qd in 8 16 32; do for cp in 8 16 32; do build dse_q${qd}_c${cp} -GNCH=4 -GCHCL=4 -GCPLD=$cp -GQD=$qd -GPORTS=1; done; done
build ch1p1   -GNCH=1  -GCHCL=1 -GCPLD=32 -GQD=16 -GPORTS=1
build ch2p1   -GNCH=2  -GCHCL=2 -GCPLD=32 -GQD=16 -GPORTS=1
build ch8p1   -GNCH=8  -GCHCL=4 -GCPLD=32 -GQD=16 -GPORTS=1
build ch4r    -GNCH=4  -GCHCL=4 -GCPLD=32 -GQD=16 -GPORTS=1      # v2: VectorCore trace replay (integration/vectorcore/compare_with_python.py)
echo "[build] all done"
