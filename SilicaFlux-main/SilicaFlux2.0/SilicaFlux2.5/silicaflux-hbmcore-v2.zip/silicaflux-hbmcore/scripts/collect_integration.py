#!/usr/bin/env python3
"""Run the DataFabric / DMA / scratchpad integration benches and record their REAL summary lines in reports/datafabric_summary.json."""
import json, pathlib, re, subprocess, time
ROOT = pathlib.Path(__file__).resolve().parent.parent
out = {"generated": time.strftime("%Y-%m-%dT%H:%M:%S"), "runs": []}
def run(name, binary, args):
    p = subprocess.run([str(ROOT / binary)] + args, capture_output=True, text=True, cwd=ROOT)
    t = p.stdout + p.stderr
    res = re.findall(r"RESULT: (PASS|FAIL)", t)
    r = dict(name=name, status=res[-1] if res else "NO_RESULT", tests=re.findall(r"TEST (\S+)\s+(PASS|FAIL)", t))
    m = re.search(r"SUMMARY requests=(\d+) request_flits=(\d+) response_flits=(\d+) per_tile=(\d+)/(\d+)/(\d+)/(\d+) cycles=(\d+)", t)
    if m:
        v = list(map(int, m.groups())); r.update(requests=v[0], request_flits=v[1], response_flits=v[2], per_tile_responses=v[3:7], cycles=v[7])
    m = re.search(r"DMA aggregate: (\d+) bytes in (\d+) cycles = ([\d.]+) B/cycle", t)
    if m: r.update(dma_bytes=int(m.group(1)), dma_cycles=int(m.group(2)), dma_bytes_per_cycle=float(m.group(3)))
    out["runs"].append(r); print(name, r["status"])
for sd in (1, 2, 3): run(f"datafabric_mock_ooo_seed{sd}", "build/tb_datafabric_mock/obj/Vtb_datafabric", [f"+TEST=all", f"+SEED={sd}"])
run("datafabric_real_controller", "build/tb_datafabric_real/obj/Vtb_datafabric", ["+TEST=all", "+SEED=1"])
run("dma_scratchpad_mock", "build/tb_dma_spm_mock/obj/Vtb_dma_spm", ["+SEED=1"])
run("dma_scratchpad_real_controller", "build/tb_dma_spm_real/obj/Vtb_dma_spm", ["+SEED=2"])
(ROOT / "reports" / "datafabric_summary.json").write_text(json.dumps(out, indent=1))
