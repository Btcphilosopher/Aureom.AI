#!/usr/bin/env bash
# Download the NanGate45 (FreePDK45) OPEN standard-cell liberty used ONLY for proxy-node synthesis (scripts/synth_ng45.py).
# The file is not redistributed with HBMCore. Source: The-OpenROAD-Project/OpenROAD-flow-scripts, platforms/nangate45.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/lib
URL=https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/master/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib
curl -fsSL -o build/lib/ng45.lib "$URL"
grep -q "library (NangateOpenCellLibrary)" build/lib/ng45.lib && echo "ok: build/lib/ng45.lib ($(grep -c 'cell (' build/lib/ng45.lib) cells)"
