#!/usr/bin/env bash
# Run the benchmark matrix (needs the variants built by scripts/build_bench_variants.sh).
# Every run writes reports/bench/<name>.json. All numbers are MODELLED against a HYPOTHETICAL timing profile.
# usage: scripts/run_benchmarks.sh [main|scale|dse|all]     (default: all)
cd "$(dirname "$0")/.."
mkdir -p reports/bench reports/bench/timeline
PHASE=${1:-all}
run() {   # name binary args...    (ONLY=<regex> runs just the matching result names - used to run slow items in parallel)
  local name=$1 bin=$2; shift 2
  if [ -n "${ONLY:-}" ] && ! [[ $name =~ $ONLY ]]; then return; fi
  [ -x "$bin" ] || { echo "SKIP $name (missing $bin)"; return; }
  local t0=$(date +%s)
  "$bin" "$@" +JSON=reports/bench/$name.json 2>&1 | grep -E "RESULT bench|Error|violated" | head -2
  echo "  [$name] $(( $(date +%s) - t0 ))s"
}
B32=build/tb_bench_ch32p1/obj/Vtb_bench
B32S=build/tb_bench_ch32p0/obj/Vtb_bench
# common: bank-aware map, profile 1 (sim_ref), FR-FCFS, open page. 16 sources x 4 issues/cycle = enough parallelism for 64 PCs.
COMMON32="+MAP=2 +PROFILE=1 +POLICY=1 +NSRC=16 +WINDOW=128 +ISSUEW=4 +SEED=1"

if [ "$PHASE" = main ] || [ "$PHASE" = all ]; then
  echo "== benchmarks A-L, 32 channels / 64 pseudo-channels (channel-sliced ingress) =="
  N=${NREQ32:-16000}
  run A_seq_read          $B32 +BENCH=A +NREQ=$N $COMMON32 +TIMELINE=reports/bench/timeline/A.timeline.json +CMDLOG=reports/bench/timeline/A.cmds
  run B_seq_write         $B32 +BENCH=B +NREQ=$N $COMMON32
  run C_balanced          $B32 +BENCH=C +NREQ=$N $COMMON32
  run D_random            $B32 +BENCH=D +NREQ=$((N/2)) $COMMON32
  run E_hotspot_1ch       $B32 +BENCH=E +NREQ=$((N/32)) $COMMON32
  run F_all_channels      $B32 +BENCH=F +NREQ=$((N/2)) $COMMON32
  run G_high_locality     $B32 +BENCH=G +NREQ=$N $COMMON32
  run H_low_locality      $B32 +BENCH=H +NREQ=$((N/4)) $COMMON32
  run I_refresh_on        $B32 +BENCH=I +NREQ=$((N*6)) $COMMON32 +REFMODE=0
  run I_refresh_off       $B32 +BENCH=I +NREQ=$((N*6)) $COMMON32 +REFMODE=2 +HBM_NO_REFCHECK=1
  # J: the hotspot sources hammer ONE pseudo-channel with random rows (~10 cycles per request), so the run is bounded by that
  # pseudo-channel: NREQ/4 requests per source keeps the run at minutes while still being thousands of requests per class.
  run J_compete_noqos     $B32 +BENCH=J +NREQ=$((N/4)) $COMMON32 +NSRC=8 +PRIO=0
  run J_compete_qos       $B32 +BENCH=J +NREQ=$((N/4)) $COMMON32 +NSRC=8 +PRIO=1 +DEADLINE=1
  # J on a 2-channel / 4-pseudo-channel system: the same 8 sources now genuinely CONTEND for few pseudo-channels, which is where QoS can matter
  B2=build/tb_bench_ch2p1/obj/Vtb_bench
  run J_compete_noqos_4pc $B2 +BENCH=J +NREQ=4000 +MAP=2 +PROFILE=1 +POLICY=1 +NSRC=8 +WINDOW=64 +ISSUEW=4 +SEED=1 +PRIO=0
  run J_compete_qos_4pc   $B2 +BENCH=J +NREQ=4000 +MAP=2 +PROFILE=1 +POLICY=1 +NSRC=8 +WINDOW=64 +ISSUEW=4 +SEED=1 +PRIO=1 +DEADLINE=1
  # K: TensorCore GEMM tile loading. 512x512 FP32, 128x128 tiles, configured tensor throughput = 4096 MAC/cycle
  run K_tensor_gemm_4096  $B32 +BENCH=K +NREQ=12 $COMMON32 +NSRC=1 +TILE=128 +GEMM=512 +MACS=4096
  run K_tensor_gemm_32768 $B32 +BENCH=K +NREQ=12 $COMMON32 +NSRC=1 +TILE=128 +GEMM=512 +MACS=32768
  run K_tensor_gemm_262144 $B32 +BENCH=K +NREQ=12 $COMMON32 +NSRC=1 +TILE=128 +GEMM=512 +MACS=262144
  run L_fp64_stream       $B32 +BENCH=L +NREQ=$N $COMMON32
  echo "== single host port (<=1 granule/cycle) of sf_hbm4_controller: the ingress limit =="
  run A_seq_read_single_port $B32S +BENCH=A +NREQ=$((N/4)) +MAP=2 +PROFILE=1 +NSRC=8 +WINDOW=128 +ISSUEW=1 +SEED=1
  run F_all_ch_single_port   $B32S +BENCH=F +NREQ=$((N/4)) +MAP=2 +PROFILE=1 +NSRC=8 +WINDOW=128 +ISSUEW=1 +SEED=1
fi

if [ "$PHASE" = scale ] || [ "$PHASE" = all ]; then
  echo "== channel scaling (benchmark A and F) =="
  for c in 1 2 4 8; do
    case $c in 1) B=build/tb_bench_ch1p1/obj/Vtb_bench;; 2) B=build/tb_bench_ch2p1/obj/Vtb_bench;; 4) B=build/tb_bench_dse_q16_c32/obj/Vtb_bench;; 8) B=build/tb_bench_ch8p1/obj/Vtb_bench;; esac
    n=$((c*2)); ns=$(( n < 16 ? n : 16 ))
    per=$(( 1000 * n / ns ))                      # 1000 granules per pseudo-channel in total, whatever the source count
    run scale_A_${c}ch $B +BENCH=A +NREQ=$per +MAP=2 +PROFILE=1 +NSRC=$ns +WINDOW=128 +ISSUEW=4 +SEED=1
    run scale_F_${c}ch $B +BENCH=F +NREQ=$per +MAP=2 +PROFILE=1 +NSRC=$ns +WINDOW=128 +ISSUEW=4 +SEED=1
  done
  run scale_A_32ch $B32 +BENCH=A +NREQ=4000 $COMMON32
  run scale_F_32ch $B32 +BENCH=F +NREQ=4000 $COMMON32
fi

if [ "$PHASE" = dse ] || [ "$PHASE" = all ]; then
  echo "== design-space sweep on 4 channels: IDENTICAL traces (same seed / same generators) for every point =="
  W="+PROFILE=1 +NSRC=8 +WINDOW=64 +ISSUEW=2 +SEED=7"
  # (1) queue depth x completion depth (compile-time variants), workload D (random) and A (stream)
  for qd in 8 16 32; do for cp in 8 16 32; do
    B=build/tb_bench_dse_q${qd}_c${cp}/obj/Vtb_bench
    run dse_q${qd}_c${cp}_A $B +BENCH=A +NREQ=1500 +MAP=2 $W
    run dse_q${qd}_c${cp}_D $B +BENCH=D +NREQ=1500 +MAP=2 $W
  done; done
  B=build/tb_bench_dse_q16_c32/obj/Vtb_bench
  # (2) scheduler policy x workload
  for pol in 0 1 2; do for wl in D H G; do run dse_policy${pol}_${wl} $B +BENCH=$wl +NREQ=1500 +MAP=2 $W +POLICY=$pol; done; done
  # (3) address mapping x workload
  for mp in 0 1 2; do for wl in A D; do run dse_map${mp}_${wl} $B +BENCH=$wl +NREQ=1500 $W +MAP=$mp +POLICY=1; done; done
  run dse_map2_hash_D $B +BENCH=D +NREQ=1500 $W +MAP=2 +HASH=1 +POLICY=1
  run dse_map1_il3_A  $B +BENCH=A +NREQ=1500 $W +MAP=1 +IL=3 +POLICY=1
  # (4) page policy / batching / QoS
  for pg in 0 1 2; do run dse_page${pg}_H $B +BENCH=H +NREQ=1500 +MAP=2 $W +PAGE=$pg; run dse_page${pg}_G $B +BENCH=G +NREQ=1500 +MAP=2 $W +PAGE=$pg; done
  run dse_batch1_C $B +BENCH=C +NREQ=1500 +MAP=2 $W +BATCH=1
  run dse_batch0_C $B +BENCH=C +NREQ=1500 +MAP=2 $W +BATCH=0
  # (5) outstanding window (workload parallelism) and profile (latency assumptions)
  for wnd in 4 8 16 32 64 128; do run dse_window${wnd}_A $B +BENCH=A +NREQ=1500 +MAP=2 +PROFILE=1 +NSRC=8 +WINDOW=$wnd +ISSUEW=2 +SEED=7; done
  for pf in 0 1 2 3; do run dse_profile${pf}_A $B +BENCH=A +NREQ=1500 +MAP=2 +PROFILE=$pf +NSRC=8 +WINDOW=64 +ISSUEW=2 +SEED=7; run dse_profile${pf}_D $B +BENCH=D +NREQ=1500 +MAP=2 +PROFILE=$pf +NSRC=8 +WINDOW=64 +ISSUEW=2 +SEED=7; done
fi
echo "benchmarks done: $(ls reports/bench/*.json 2>/dev/null | wc -l) result files"
