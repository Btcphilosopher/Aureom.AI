#!/usr/bin/env python3
"""Export HBMCore memory ACTIVITY for the SilicaFlux power / thermal / bandwidth tools (brief section 41).

INPUT   reports/bench/*.json (RTL simulation results: command counts, bytes, cycles, per-pseudo-channel utilisation),
        configs/timing/profiles.json (clock of the profile), configs/energy/hbm_energy_coefficients.json (optional).
OUTPUT  reports/activity/hbm_activity.json   every benchmark: counts, rates, per-PC utilisation / bytes
        reports/activity/hbm_activity.csv    one row per benchmark (for PowerGrid / ThermalLab / BandwidthLab scripts)
        reports/activity/powergrid_workloads.csv   ONLY when every energy coefficient is present: PowerGrid
                                             workload rows (workload, source, total_power_mw, group_power_mw) with the
                                             coefficient file's provenance label
PROVENANCE  activity = SIMULATED (RTL simulation against a HYPOTHETICAL timing profile; not hardware).
            power    = NOT RUN unless coefficients are supplied; then labelled with the coefficients' provenance.
This script never invents energy values and never claims DRAM stack power from traffic counts alone.
"""
import csv, json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "reports" / "activity"
GRAN = 32
KEYS = ["e_act_pj", "e_pre_pj", "e_rd_pj_per_granule", "e_wr_pj_per_granule", "e_ref_ab_pj", "e_rfm_pj",
        "p_background_mw_per_pc", "p_controller_mw_per_pc_active"]
LABELS = {"MEASURED", "SIMULATED", "MODELLED", "ASSUMED"}

def main():
    profiles = {p["id"]: p for p in json.loads((ROOT / "configs/timing/profiles.json").read_text())["profiles"]}
    coef = json.loads((ROOT / "configs/energy/hbm_energy_coefficients.json").read_text())
    have_coef = all(isinstance(coef.get(k), (int, float)) for k in KEYS) and coef.get("provenance") in LABELS and coef.get("source")
    files = sorted((ROOT / "reports" / "bench").glob("*.json"))
    if not files:
        print("no reports/bench/*.json (run make hbm-benchmark)"); sys.exit(2)
    OUT.mkdir(parents=True, exist_ok=True)
    rows, full = [], []
    for f in files:
        d = json.loads(f.read_text())
        if "cycles" not in d or "config" not in d:
            continue
        c = d["config"]; prof = profiles.get(c.get("profile"), {}); mhz = prof.get("clock_mhz") or 0
        cyc = d["cycles"]; npc = c.get("npc") or len(d.get("pc_utilisation") or []) or 1
        row = d.get("row", {}); ref = d.get("refresh", {})
        a = dict(workload=f.stem, benchmark=d.get("benchmark"), activity_provenance="SIMULATED (RTL simulation, HYPOTHETICAL timing profile)",
                 status=d.get("status"), profile=prof.get("name"), clock_mhz=mhz, npc=npc, cycles=cyc,
                 time_ns=round(cyc * 1000.0 / mhz, 1) if mhz else None,
                 act=row.get("act"), pre=row.get("pre"), refresh=ref.get("commands"), rfm=d.get("rfm"),
                 rd_granules=(d.get("read_bytes") or 0) // GRAN, wr_granules=(d.get("write_bytes") or 0) // GRAN,
                 read_bytes=d.get("read_bytes"), write_bytes=d.get("write_bytes"),
                 mean_pc_busy_fraction=d.get("mean_pc_busy_fraction"), dram_violations=d.get("dram_violations"),
                 pc_utilisation=d.get("pc_utilisation"), pc_bytes=d.get("pc_bytes"))
        cyc_pc = cyc * npc if cyc else 1
        a["rates_per_pc_cycle"] = {k: (round(a[k] / cyc_pc, 6) if isinstance(a[k], (int, float)) else None)
                                   for k in ("act", "pre", "refresh", "rd_granules", "wr_granules")}
        if have_coef and a["time_ns"]:
            e_pj = ((a["act"] or 0) * coef["e_act_pj"] + (a["pre"] or 0) * coef["e_pre_pj"]
                    + a["rd_granules"] * coef["e_rd_pj_per_granule"] + a["wr_granules"] * coef["e_wr_pj_per_granule"]
                    + (a["refresh"] or 0) * coef["e_ref_ab_pj"] + (a["rfm"] or 0) * coef["e_rfm_pj"])
            p_dyn_mw = e_pj / a["time_ns"]                       # pJ / ns = mW
            p_bg = npc * coef["p_background_mw_per_pc"]
            p_ctl = npc * coef["p_controller_mw_per_pc_active"] * (a["mean_pc_busy_fraction"] or 0)
            a["power_mw"] = dict(dram_dynamic=round(p_dyn_mw, 3), dram_background=round(p_bg, 3), controller=round(p_ctl, 3),
                                 total=round(p_dyn_mw + p_bg + p_ctl, 3), provenance=coef["provenance"], source=coef["source"])
        else:
            a["power_mw"] = dict(status="NOT RUN: configs/energy/hbm_energy_coefficients.json has no characterised values")
        full.append(a)
        rows.append({k: a[k] for k in ("workload", "benchmark", "profile", "npc", "cycles", "time_ns", "act", "pre", "refresh",
                                       "rd_granules", "wr_granules", "mean_pc_busy_fraction", "dram_violations")})
    (OUT / "hbm_activity.json").write_text(json.dumps(dict(
        note="ACTIVITY ONLY unless power_mw.total is present. Simulated against hypothetical timing; not hardware.",
        coefficients_used=bool(have_coef), workloads=full), indent=1))
    with open(OUT / "hbm_activity.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    pg = OUT / "powergrid_workloads.csv"
    if have_coef:
        with open(pg, "w", newline="") as fh:
            w = csv.writer(fh); w.writerow(["workload", "source", "total_power_mw", "group_power_mw"])
            for a in full:
                if "total" in a["power_mw"]:
                    w.writerow([f"hbm_{a['workload']}", a["power_mw"]["provenance"], a["power_mw"]["total"],
                                json.dumps({"hbm_ctrl": a["power_mw"]["controller"], "hbm_dram": a["power_mw"]["dram_dynamic"] + a["power_mw"]["dram_background"]})])
    elif pg.exists():
        pg.unlink()
    print(f"activity for {len(full)} workloads -> {OUT.relative_to(ROOT)}; power: {'computed (' + coef['provenance'] + ')' if have_coef else 'NOT RUN (no coefficients)'}")

if __name__ == "__main__":
    main()
