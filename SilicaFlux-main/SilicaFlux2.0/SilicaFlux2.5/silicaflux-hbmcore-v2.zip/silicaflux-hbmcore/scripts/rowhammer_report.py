#!/usr/bin/env python3
"""Run the refresh-management research test (tb_pc_single +TEST=rowhammer) on every timing profile and write
reports/rowhammer.json from the ACTUAL simulation output (MODELLED numbers, hypothetical profiles; docs/ROWHAMMER.md).
Needs build/tb_pc_single (./scripts/vsim.sh tb_pc_single)."""
import json, pathlib, re, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
BIN = ROOT / "build" / "tb_pc_single" / "obj" / "Vtb_pc_single"
RUNS = [(0, 2, 10), (1, 1, 11), (2, 0, 12), (3, 1, 13)]
PNAME = {0: "sim_fast", 1: "sim_ref", 2: "sim_strict", 3: "sim_trc_slack"}
POL = {0: "FCFS", 1: "FR-FCFS", 2: "BG-aware"}
if not BIN.exists():
    sys.exit("build/tb_pc_single missing: run ./scripts/vsim.sh tb_pc_single")
rows = []
for prof, pol, seed in RUNS:
    out = subprocess.run([str(BIN), "+TEST=rowhammer", f"+SEED={seed}", f"+PROFILE={prof}", f"+POLICY={pol}"],
                         capture_output=True, text=True, cwd=ROOT).stdout
    def grab(tag):
        m = re.search(tag + r"\s*: max_unmitigated=(\d+) rfm=(\d+) cycles=(\d+)", out)
        return tuple(int(x) for x in m.groups()) if m else (None, None, None)
    off, dr, un = grab("hammer RFM off"), grab("hammer RFM directed"), grab("hammer RFM undirect")
    mb = re.search(r"MMT blocking only\s*: rfm=(\d+) cycles=(\d+) block_cycles=(\d+)", out)
    rows.append(dict(profile=PNAME[prof], policy=POL[pol], seed=seed, off_max=off[0], off_cycles=off[2], dir_max=dr[0], dir_rfm=dr[1],
                     dir_cycles=dr[2], und_max=un[0], und_rfm=un[1], und_cycles=un[2],
                     mmt_only_cycles=int(mb.group(2)) if mb else None, mmt_only_block_cycles=int(mb.group(3)) if mb else None,
                     result="PASS" if "RESULT: PASS" in out else "FAIL"))
    print(rows[-1])
rep = dict(kind="MODELLED (hypothetical timing profiles); research metric, not a RowHammer threshold",
           note="600 serial accesses alternating two rows of one bank; IMT 16, MMT 32, RAA decrement 8 per refresh. "
                "max unmitigated = most ACTs to one row since its last RFM mitigation (regular refresh not counted).",
           rows=rows)
(ROOT / "reports" / "rowhammer.json").write_text(json.dumps(rep, indent=1))
sys.exit(0 if all(r["result"] == "PASS" for r in rows) else 1)
