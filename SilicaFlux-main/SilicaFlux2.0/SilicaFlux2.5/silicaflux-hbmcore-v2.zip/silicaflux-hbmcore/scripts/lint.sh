#!/usr/bin/env bash
# Verilator lint of the whole synthesizable RTL (usage: scripts/lint.sh [top])
set -euo pipefail
cd "$(dirname "$0")/.."
[ -n "${VERILATOR_ROOT:-}" ] && export VERILATOR_ROOT
V=${VERILATOR:-verilator}
TOP=${1:-sf_hbm_pseudochannel}
$V --lint-only -Wall -Wno-UNUSEDPARAM -Wno-UNUSEDSIGNAL -Wno-DECLFILENAME -Wno-PINCONNECTEMPTY -Wno-SYNCASYNCNET -Irtl \
  rtl/sf_hbm_pkg.sv rtl/sf_hbm_profile_pkg.sv $(ls rtl/sf_hbm*.sv | grep -v -e sf_hbm_pkg -e profile_pkg) --top-module "$TOP"
