#!/usr/bin/env python3
"""PROXY-NODE synthesis of the HBMCore RTL against an OPEN standard-cell library (NanGate45 / FreePDK45 typical corner).

WHY:   scripts/synth.py gives technology-independent gate counts and logic levels. This script maps the same RTL to real
       liberty cells so that area (um^2) and a combinational critical-path delay (ps) can be quoted - ON A 45 nm OPEN
       PROXY LIBRARY. It is NOT a target-node result, NOT sign-off, and says nothing about an HBM4 PHY or package.

FLOW   1. YoWASP Yosys + yosys-slang : parse SystemVerilog (packages / packed structs), flatten + techmap to a generic netlist
          (full `synth` is NOT run in the WASM build: its opt_muxtree pass exhausts the WASM stack on the largest modules)
       2. native Yosys 0.33 + ABC     : `synth` (optimisation), dfflibmap + `abc -liberty` (delay-driven mapping, buffering, gate sizing), `stime -p`
OUTPUT reports/synth_ng45/<label>.json and reports/synth_ng45/SYNTH_NG45.md

WHAT THE NUMBERS ARE
  area_um2        : sum of liberty cell areas (no placement utilisation, no clock tree, no wires, no fill)
  comb_delay_ps   : ABC `stime -p` longest combinational path at the typical corner, NO wire load ("WireLoad = none"),
                    flop clk->Q / setup / clock skew / interconnect NOT included. Paths start at flops or primary inputs
                    (quasi-static configuration inputs such as the timing profile count as primary inputs).
  flip_flops      : mapped DFF cells
WHAT THEY ARE NOT: post-layout timing, power, or any statement about a commercial HBM4 node.

LIBRARY: the liberty file is NOT redistributed. scripts/fetch_ng45.sh downloads it (OpenROAD-flow-scripts, nangate45 platform)
         to build/lib/ng45.lib.   usage: scripts/synth_ng45.py [--only label,...] [--jobs N] [--report]
"""
import argparse, concurrent.futures as cf, json, os, pathlib, re, shutil, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "reports" / "synth_ng45"
BUILD = ROOT / "build" / "synth_ng45"
LIB = "build/lib/ng45.lib"                     # relative: YoWASP (WASI) only sees the working directory
YW = os.environ.get("YOWASP_YOSYS") or shutil.which("yowasp-yosys") or os.path.join(os.environ.get("YOWASP_BIN", ""), "yowasp-yosys")
NATIVE = os.environ.get("YOSYS") or shutil.which("yosys") or "yosys"
TARGET_PS = int(os.environ.get("NG45_TARGET_PS", "1000"))      # delay target handed to ABC (1 GHz)
TIMEOUT = int(os.environ.get("NG45_TIMEOUT", "3600"))
PKG = ["rtl/sf_hbm_pkg.sv", "rtl/sf_hbm_profile_pkg.sv"]

# (label, top, extra sources, parameter overrides)
M = [
    ("bank_fsm", "sf_hbm_bank_fsm", [], {}),
    ("timing", "sf_hbm_timing", [], {}),
    ("req_queue_d16", "sf_hbm_req_queue", [], {"DEPTH": 16}),
    ("scheduler_d16", "sf_hbm_scheduler", [], {"DEPTH": 16}),
    ("scheduler_d8", "sf_hbm_scheduler", [], {"DEPTH": 8}),
    ("write_data", "sf_hbm_write_data", [], {"DEPTH": 16, "PEND_DEPTH": 16, "CPL_IDX_W": 3}),
    ("read_return", "sf_hbm_read_return", [], {"CPL_DEPTH": 8}),
    ("refresh", "sf_hbm_refresh", [], {}),
    ("rfm", "sf_hbm_rfm", [], {}),
    ("power_state", "sf_hbm_power_state", [], {}),
    ("init", "sf_hbm_init", [], {}),
    ("ecc_ras", "sf_hbm_ecc_ras", [], {}),
    ("rsp_arb_n8", "sf_hbm_rsp_arb", [], {"N": 8}),
    ("addr_map_32ch", "sf_hbm_addr_map", [], {"NUM_STACKS": 1, "NUM_CHANNELS": 32, "PCS": 2}),
    ("csr", "sf_hbm_csr", [], {}),
    ("cdc_fifo_w288_d8", "sf_hbm_cdc_fifo", [], {"WIDTH": 288, "DEPTH": 8}),
    ("pseudochannel", "sf_hbm_pseudochannel", [], {}),
]


def run(cmd, timeout=TIMEOUT):
    return subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT, timeout=timeout)


def synth(label, top, extra, params):
    t0 = time.time()
    BUILD.mkdir(parents=True, exist_ok=True)
    files = PKG + sorted(str(p.relative_to(ROOT)) for p in (ROOT / "rtl").glob("sf_hbm*.sv") if "pkg" not in p.name) + extra
    g = " ".join(f"-G {k}={v}" for k, v in params.items())
    gen = f"build/synth_ng45/{label}_generic.v"
    log1, log2 = BUILD / f"{label}_stage1.log", BUILD / f"{label}_stage2.log"
    res = dict(label=label, top=top, params=params, library="NanGate45 FreePDK45 typical (open proxy)", target_ps=TARGET_PS)
    try:
        p = run([YW, "-q", "-l", str(log1.relative_to(ROOT)), "-p",
                 f"read_slang -j 1 -D SYNTHESIS --top {top} {g} -I rtl {' '.join(files)}; hierarchy -check -top {top}; proc; flatten; "
                 f"opt_expr; opt_clean; memory_map; techmap; opt -fast; opt_clean; "
                 f"write_verilog -noattr {gen}"])
        if p.returncode != 0:
            return dict(res, status="FAIL_STAGE1", detail=(p.stdout + p.stderr)[-1500:])
        p = run([NATIVE, "-l", str(log2), "-p",
                 f"read_verilog {gen}; hierarchy -top {top}; proc; flatten; synth -top {top}; "
                 f"dfflibmap -liberty {LIB}; abc -liberty {LIB} -script build/synth_ng45/abc.script; opt_clean; "
                 f"stat -liberty {LIB}"])
        if p.returncode != 0:
            return dict(res, status="FAIL_STAGE2", detail=(p.stdout + p.stderr)[-1500:])
    except subprocess.TimeoutExpired:
        return dict(res, status="TIMEOUT", detail=f"exceeded {TIMEOUT} s", seconds=round(time.time() - t0, 1))
    txt = log2.read_text()
    area = re.findall(r"Chip area for module .*?: ([0-9.]+)", txt)
    st = re.findall(r'WireLoad = "none"\s+Gates =\s*(\d+).*?Area =\s*([0-9.]+).*?Delay =\s*([0-9.]+) ps', txt)
    sp = re.findall(r"Start-point = (.*?)\.\s+End-point = (.*?)\.\s*$", txt, re.M)
    stat_tail = txt[txt.rfind("Printing statistics"):] if "Printing statistics" in txt else txt
    ff = sum(int(n) for n in re.findall(r"^\s+(?:S?DFF\w*|DLH\w*|DLL\w*)\s+(\d+)\s*$", stat_tail, re.M))
    cells = re.findall(r"Number of cells:\s+(\d+)", stat_tail)
    if not area or not st:
        return dict(res, status="PARSE_FAIL", detail="no area / stime line in the stage-2 log", seconds=round(time.time() - t0, 1))
    worst = max(st, key=lambda x: float(x[2]))
    return dict(res, status="OK", area_um2=round(float(area[-1]), 1), comb_delay_ps=round(float(worst[2]), 1),
                cells=int(cells[-1]) if cells else None, flip_flops=ff,
                start_point=sp[-1][0] if sp else None, end_point=sp[-1][1] if sp else None,
                seconds=round(time.time() - t0, 1),
                flow="yowasp-yosys(slang) synth -flatten -> native yosys dfflibmap + abc -liberty (&nf, buffer, upsize, dnsize, stime -p)")


def report():
    rows = [json.loads(p.read_text()) for p in sorted(OUT.glob("*.json"))]
    order = {m[0]: i for i, m in enumerate(M)}
    rows.sort(key=lambda r: order.get(r["label"], 999))
    md = ["# Proxy-node synthesis: NanGate45 open cell library (generated by scripts/synth_ng45.py --report)", "",
          "**PROXY RESULTS on a 45 nm OPEN library (FreePDK45 / NanGate typical corner).** Not the target node, not sign-off, no PHY, no package.",
          f"Flow: YoWASP Yosys + yosys-slang -> generic netlist -> native Yosys 0.33 + ABC `abc -liberty` with a {TARGET_PS} ps delay target, "
          "buffering and gate sizing, then `stime -p`. `comb delay` = longest combinational path, **no wire load, no clk->Q, no setup, no clock skew**. "
          "Area = sum of cell areas (no utilisation, no clock tree). Each module is flattened and synthesized alone with the parameters shown.", "",
          "| module | params | flip-flops | cells | area (um^2) | comb. delay (ps) | critical path start -> end | status |",
          "|---|---|---|---|---|---|---|---|"]
    for r in rows:
        if r["status"] == "OK":
            md.append(f"| {r['label']} | {r['params'] or ''} | {r['flip_flops']:,} | {r['cells']:,} | {r['area_um2']:,.0f} | {r['comb_delay_ps']:,.0f} | "
                      f"`{r.get('start_point')}` -> `{r.get('end_point')}` | OK |")
        else:
            md.append(f"| {r['label']} | {r['params'] or ''} | | | | | | {r['status']}: {r.get('detail', '')[:160]} |")
    md += ["", "Reading the delay column: at 1 GHz (1000 ps) a register-to-register path also has to absorb clk->Q (~80-100 ps for DFFR_X1 in this library), "
           "setup and interconnect, so a module whose comb. delay is near or above ~850 ps is a pipelining candidate *on this proxy node*. "
           "An advanced-node result would be different; the ranking of hotspots is the useful information."]
    (OUT / "SYNTH_NG45.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--report", action="store_true")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if a.report:
        return report()
    missing = [t for t in (YW, NATIVE) if not (shutil.which(t) or os.path.exists(t))]
    if missing or not (ROOT / LIB).exists():
        print(f"DEPENDENCY MISSING: {missing or ''} {'' if (ROOT / LIB).exists() else LIB + ' (run scripts/fetch_ng45.sh)'}")
        sys.exit(2)
    BUILD.mkdir(parents=True, exist_ok=True)
    (BUILD / "abc.script").write_text(
        f"strash; &get -n; &fraig -x; &put; scorr; dc2; strash; &get -n; &dch -f; &nf -D {TARGET_PS}; &put; "
        f"buffer; upsize -D {TARGET_PS}; dnsize -D {TARGET_PS}; stime -p\n")
    sel = [m for m in M if not a.only or m[0] in a.only.split(",")]
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(lambda m: synth(*m), sel):
            (OUT / f"{r['label']}.json").write_text(json.dumps(r, indent=1))
            print(f"[{r['status']:<11}] {r['label']:<22} area={r.get('area_um2')} um2  delay={r.get('comb_delay_ps')} ps  ff={r.get('flip_flops')}  "
                  f"{r.get('seconds')} s", flush=True)
    report()


if __name__ == "__main__":
    main()
