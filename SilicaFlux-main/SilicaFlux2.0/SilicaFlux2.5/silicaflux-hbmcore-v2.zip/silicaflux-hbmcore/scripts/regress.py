#!/usr/bin/env python3
"""SILICAFLUX HBMCORE regression runner.

Runs every test group, parses the REAL result of each run and writes
  reports/regression.json   (machine readable, for CI)
  reports/regression.xml    (JUnit)
  reports/regression.md     (human readable)

A test is PASS only if its command exited 0 AND its log contains the expected PASS marker.
If a required tool is missing the test is reported as DEPENDENCY_MISSING - never as passed.
Nothing here is cached: every invocation re-executes what it reports.

usage: scripts/regress.py [--group GROUP ...] [--full] [--jobs N] [--list]
       groups: lint unit channel csr transaction timing refresh ecc python datafabric dma cdc formal cocotb mutation bigconfig
"""
import argparse, json, os, pathlib, re, shutil, subprocess, sys, time, xml.sax.saxutils as xs

ROOT = pathlib.Path(__file__).resolve().parent.parent
ENV = dict(os.environ)
VERILATOR = ENV.get("VERILATOR") or shutil.which("verilator") or "verilator"
PY = sys.executable

def have(tool):
    return shutil.which(tool) is not None or pathlib.Path(tool).exists()

# (group, name, needs, [shell commands], pass-regex)
T = []
def add(group, name, needs, cmds, ok=r"RESULT: PASS"):
    T.append(dict(group=group, name=name, needs=needs, cmds=cmds, ok=ok))

SIM = lambda tb, tag="", extra="", env="": f"{env} {('TAG='+tag) if tag else ''} JOBS=2 ./scripts/vsim.sh {tb} {extra}".strip()
RUN = lambda tb, tag, args: f"./build/{tb}{('_'+tag) if tag else ''}/obj/V{tb} {args}"

# ---- lint / elaboration
add("lint", "lint_pseudochannel", [VERILATOR], ["./scripts/lint.sh sf_hbm_pseudochannel && echo RESULT: PASS"])
add("lint", "lint_controller_32ch", [VERILATOR],
    ["./scripts/lint.sh sf_hbm4_controller && echo RESULT: PASS"])
for top in ("sf_hbm_top", "sf_hbm_perf", "sf_hbm_csr", "sf_hbm_cdc_fifo", "sf_hbm_rsp_arb", "sf_hbm_addr_map"):
    add("lint", f"lint_{top}", [VERILATOR], [f"./scripts/lint.sh {top} && echo RESULT: PASS"])
for n in (1, 2, 4, 8, 32):
    add("lint", f"elaborate_controller_NUM_CHANNELS_{n}", [VERILATOR],
        [f"{VERILATOR} --lint-only -Wno-fatal -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-SYNCASYNCNET -Irtl "
         f"rtl/sf_hbm_pkg.sv rtl/sf_hbm_profile_pkg.sv $(ls rtl/sf_hbm*.sv | grep -v -e sf_hbm_pkg -e profile_pkg) --top-module sf_hbm4_controller "
         f"-GNUM_CHANNELS={n} -GCH_PER_CLUSTER={min(n,8)} && echo RESULT: PASS"])

# ---- channel-level (single pseudo-channel)
add("channel", "build_tb_pc_single", [VERILATOR], [SIM("tb_pc_single") + " && echo RESULT: PASS"])
for prof in (0, 1, 2, 3):          # profile 3 = sim_trc_slack (v2: trc > tras + trp corner)
    for pol in (0, 1, 2):
        add("channel", f"pc_single_profile{prof}_policy{pol}", [VERILATOR],
            [RUN("tb_pc_single", "", f"+TEST=all +SEED={prof*3+pol+1} +PROFILE={prof} +POLICY={pol} +JSON=reports/json/pc_single_p{prof}_pol{pol}.json")])
add("channel", "pc_single_page_close_batch_prio", [VERILATOR],
    [RUN("tb_pc_single", "", "+TEST=all +SEED=21 +PROFILE=1 +POLICY=1 +PAGE=1 +BATCH=1 +PRIO=1")])
add("channel", "pc_single_phy_and_rsp_backpressure", [VERILATOR],
    [RUN("tb_pc_single", "", "+TEST=all +SEED=22 +PROFILE=0 +POLICY=1 +PHYSTALL=30 +RSPRDY=40")])

# extra PHY-adapter coverage: non-zero command / read-data latency stages, the starvation directed test, and the unimplemented vendor-PHY stub
add("channel", "build_tb_pc_single_phy_latency", [VERILATOR], [SIM("tb_pc_single", "lat", "-GPHY_CMD_LAT=2 -GPHY_RD_LAT=3") + " && echo RESULT: PASS"])
for pol in (0, 1, 2):
    add("channel", f"pc_single_phy_cmd2_rd3_policy{pol}", [VERILATOR],
        [RUN("tb_pc_single", "lat", f"+TEST=all +SEED={50+pol} +PROFILE=1 +POLICY={pol}")])
add("channel", "pc_single_starvation_all_profiles", [VERILATOR],
    [RUN("tb_pc_single", "", f"+TEST=starvation +SEED=3 +PROFILE={p} +POLICY=1") for p in (1, 2)] + [RUN("tb_pc_single", "", "+TEST=starvation +SEED=3 +PROFILE=1 +POLICY=0")])
# v2: reproducers of the independent-review findings (each FAILED on the v1 RTL; see docs/REVIEW_V2.md)
add("channel", "v2_starvation_boosted_hits_low_limit", [VERILATOR],
    [RUN("tb_pc_single", "", f"+TEST=starvation +SEED=3 +PROFILE={p} +POLICY={pol} +LIM={lim}") for p, pol, lim in ((1, 1, 20), (2, 1, 10), (2, 2, 20), (3, 1, 10))])
add("channel", "v2_refresh_trc_slack", [VERILATOR],
    [RUN("tb_pc_single", "", "+TEST=refresh +SEED=31 +PROFILE=1 +TRCADD=10"), RUN("tb_pc_single", "", "+TEST=refmodes +SEED=31 +PROFILE=2 +TRCADD=10")])
add("channel", "v2_refresh_postpone_above_debt_range", [VERILATOR],
    [RUN("tb_pc_single", "", "+TEST=longsat +SEED=5 +PROFILE=0 +POLICY=1 +MAXPP=150 +EAGER=0 +NREQ=20000")])
add("refresh", "v2_refresh_mode_switch_under_traffic", [VERILATOR],
    [RUN("tb_pc_single", "", f"+TEST=refswitch +SEED={sd} +PROFILE={p} +POLICY={pol}") for sd, p, pol in ((3, 2, 0), (1, 2, 2), (5, 1, 1), (7, 0, 0), (8, 3, 1))])
add("refresh", "v2_rowhammer_rfm_research_hook", [VERILATOR],
    [RUN("tb_pc_single", "", f"+TEST=rowhammer +SEED={10+p} +PROFILE={p} +POLICY={pol}") for p, pol in ((0, 2), (1, 1), (2, 0), (3, 1))])
add("channel", "v2_reinit_with_open_rows", [VERILATOR],
    [RUN("tb_pc_single", "", f"+TEST=reinit +SEED={5+p} +PROFILE={p} +POLICY=1") for p in (0, 1, 2, 3)])
add("unit", "build_tb_read_return", [VERILATOR], [SIM("tb_read_return") + " && echo RESULT: PASS"])
add("unit", "read_return_contract_violations", [VERILATOR], [RUN("tb_read_return", "", f"+SEED={s}") for s in (1, 2, 3)])
add("channel", "build_tb_pc_single_backend_b_stub", [VERILATOR], [SIM("tb_pc_single", "be1", "-GPHY_BACKEND=1") + " && echo RESULT: PASS"])
add("channel", "pc_single_backend_b_unimplemented_stub", [VERILATOR], [RUN("tb_pc_single", "be1", "+TEST=all")])

# ---- timing rules
add("timing", "build_tb_timing_rules", [VERILATOR], [SIM("tb_timing_rules") + " && echo RESULT: PASS"])
for prof in (0, 1, 2, 3):
    add("timing", f"timing_rules_profile{prof}", [VERILATOR], [RUN("tb_timing_rules", "", f"+PROFILE={prof}")])

# ---- refresh / ecc / power
for tst in ("refresh", "refmodes", "power"):
    add("refresh" if tst != "power" else "refresh", f"pc_single_{tst}", [VERILATOR],
        [RUN("tb_pc_single", "", f"+TEST={tst} +SEED=31 +PROFILE=1"), RUN("tb_pc_single", "", f"+TEST={tst} +SEED=32 +PROFILE=2")])
add("ecc", "pc_single_ecc", [VERILATOR], [RUN("tb_pc_single", "", "+TEST=ecc +SEED=41 +PROFILE=1")])

# ---- sf_hbm_top: CSR register file + controller + performance counters, driven only through the register bus
add("csr", "build_tb_top_csr_2ch", [VERILATOR], [SIM("tb_top_csr", "n2", "-GNCH=2 -GCHCL=2 -GPERF_W=48") + " && echo RESULT: PASS"])
add("csr", "top_csr_2ch_exact_counters", [VERILATOR], [RUN("tb_top_csr", "n2", "")])
add("csr", "build_tb_top_csr_4ch_saturating_counters", [VERILATOR], [SIM("tb_top_csr", "sat", "-GNCH=4 -GCHCL=2 -GPERF_W=6") + " && echo RESULT: PASS"])
add("csr", "top_csr_4ch_counter_saturation", [VERILATOR], [RUN("tb_top_csr", "sat", "")])

# ---- multi-channel transaction tests (1,2,4,8 channels; 32 under `bigconfig`)
for nch, chcl in ((1, 1), (2, 2), (4, 2), (8, 4)):
    add("transaction", f"build_tb_ctrl_multi_{nch}ch", [VERILATOR], [SIM("tb_ctrl_multi", f"ch{nch}", f"-GNCH={nch} -GCHCL={chcl}") + " && echo RESULT: PASS"])
    add("transaction", f"ctrl_multi_{nch}ch", [VERILATOR], [RUN("tb_ctrl_multi", f"ch{nch}", f"+TEST=all +SEED={nch+10}")])
add("bigconfig", "build_tb_ctrl_multi_32ch", [VERILATOR], [SIM("tb_ctrl_multi", "ch32", "-GNCH=32 -GCHCL=8") + " && echo RESULT: PASS"])
add("bigconfig", "ctrl_multi_32ch_64pc", [VERILATOR], [RUN("tb_ctrl_multi", "ch32", "+TEST=all +SEED=32")])

# ---- DataFabric / DMA / CDC
add("datafabric", "build_tb_datafabric_mock", [VERILATOR], [SIM("tb_datafabric", "mock", "-GBACKEND=0", "WITH_DF=1") + " && echo RESULT: PASS"])
add("datafabric", "datafabric_mock_ooo_3seeds", [VERILATOR], [RUN("tb_datafabric", "mock", f"+TEST=all +SEED={s}") for s in (1, 2, 3)])
add("datafabric", "build_tb_datafabric_real", [VERILATOR], [SIM("tb_datafabric", "real", "-GBACKEND=1 -GNCH=2", "WITH_DF=1") + " && echo RESULT: PASS"])
add("datafabric", "datafabric_real_controller", [VERILATOR], [RUN("tb_datafabric", "real", "+TEST=all +SEED=1")])
add("dma", "build_tb_dma_spm_mock", [VERILATOR], [SIM("tb_dma_spm", "mock", "-GBACKEND=0", "WITH_DF=1 WITH_DMA=1") + " && echo RESULT: PASS"])
add("dma", "dma_scratchpad_mock", [VERILATOR], [RUN("tb_dma_spm", "mock", "+SEED=1")])
add("dma", "build_tb_dma_spm_real", [VERILATOR], [SIM("tb_dma_spm", "real", "-GBACKEND=1", "WITH_DF=1 WITH_DMA=1") + " && echo RESULT: PASS"])
add("dma", "dma_scratchpad_real_controller", [VERILATOR], [RUN("tb_dma_spm", "real", "+SEED=2")])
add("cdc", "build_tb_cdc_fifo", [VERILATOR], [SIM("tb_cdc_fifo") + " && echo RESULT: PASS"])
for w, r in ((7, 11), (13, 5), (10, 10), (3, 17), (5, 13)):
    add("cdc", f"cdc_fifo_{w}ns_{r}ns", [VERILATOR], [RUN("tb_cdc_fifo", "", f"+WPER={w} +RPER={r}")])

# ---- formal (SymbiYosys via YoWASP) and cocotb
add("formal", "formal_properties_and_mutants", ["bash", "python3"], ["./verification/formal/run_formal.sh && echo RESULT: PASS"])
add("formal", "secded_equivalence_vs_v1_sat", ["python3"], ["python3 verification/formal/eq_secded.py"])
add("cocotb", "cocotb_addr_map_ecc_pc_traffic", ["python3", VERILATOR], ["python3 verification/cocotb/run_cocotb.py && echo RESULT: PASS"])

# ---- python reference
add("python", "pytest_python_reference_model", [PY], ["PYTHONPATH=python " + PY + " -m pytest python/tests -q -x && echo RESULT: PASS"])
add("python", "python_trace_check_of_rtl_traces", [PY, VERILATOR],
    [("mkdir -p reports/traces; " + RUN("tb_pc_single", "", f"+TEST=all +NORESET=1 +SEED=5 +PROFILE={p} +POLICY=1 +HBM_TRACE=reports/traces/rtl_p{p}.trace > /dev/null; "
         f"PYTHONPATH=python {PY} -m hbm4.trace_check reports/traces/rtl_p{p}.trace --profile {p} --num-pcs 1")) for p in (0, 1, 2, 3)],
    ok=r"RESULT: CLEAN")
add("python", "python_scoreboard_on_rtl_transaction_log", [PY, VERILATOR],
    [RUN("tb_ctrl_multi", "ch4", "+TEST=random +SEED=7 +TXLOG=reports/traces/ctrl_multi_4ch.jsonl > /dev/null; "
         f"PYTHONPATH=python {PY} -m hbm4.txn_check reports/traces/ctrl_multi_4ch.jsonl")], ok=r"(RESULT: PASS|PASS)")

# ---- mutation
add("mutation", "mutation_survivors_zero", [VERILATOR], ["./scripts/mutation_check.sh > build/mutation_check.log 2>&1; grep -E 'survivors|SURVIVED|did not apply|build failed' build/mutation_check.log; grep -q 'survivors: 0' build/mutation_check.log && ! grep -qE 'SURVIVED|did not apply|build failed' build/mutation_check.log && echo RESULT: PASS"])


def run_one(t):
    for n in t["needs"]:
        if not have(n):
            return dict(status="DEPENDENCY_MISSING", seconds=0.0, detail=f"missing tool: {n}", log="")
    t0 = time.time()
    log = []
    ok_all = True
    for cmd in t["cmds"]:
        p = subprocess.run(cmd, shell=True, cwd=ROOT, env=ENV, capture_output=True, text=True, executable="/bin/bash")
        out = (p.stdout or "") + (p.stderr or "")
        log.append(f"$ {cmd}\n{out[-6000:]}")
        if p.returncode != 0 or not re.search(t["ok"], out) or re.search(r"RESULT: FAIL|%Error|Assertion failed", out):
            ok_all = False
            break
    return dict(status="PASS" if ok_all else "FAIL", seconds=round(time.time() - t0, 2), detail="", log="\n".join(log)[-4000:])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group", action="append")
    ap.add_argument("--full", action="store_true", help="include the 32-channel (64 pseudo-channel) configuration")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--out", default="reports/regression")
    ap.add_argument("--merge", action="store_true",
                    help="merge this run's entries into the existing result file (entries with the same name are REPLACED; every replacement is recorded under 'merged_reruns')")
    a = ap.parse_args()
    groups = a.group
    sel = [t for t in T if (groups is None and (a.full or t["group"] != "bigconfig")) or (groups and t["group"] in groups)]
    if a.list:
        for t in sel: print(t["group"], t["name"])
        return 0
    (ROOT / "reports" / "json").mkdir(parents=True, exist_ok=True)
    results = []
    for t in sel:
        r = run_one(t)
        r.update(group=t["group"], name=t["name"])
        results.append(r)
        print(f"[{r['status']:<18}] {t['group']:<12} {t['name']:<48} {r['seconds']:>8.1f}s", flush=True)
        if r["status"] == "FAIL":
            print("    " + "\n    ".join(r["log"].splitlines()[-8:]), flush=True)
    out = ROOT / a.out
    out.parent.mkdir(parents=True, exist_ok=True)
    reruns = []
    if a.merge and out.with_suffix(".json").exists():
        prev = json.loads(out.with_suffix(".json").read_text())
        reruns = list(prev.get("merged_reruns", []))
        new_by = {r["name"]: r for r in results}
        merged = []
        for old in prev["results"]:
            if old["name"] in new_by:
                reruns.append(dict(name=old["name"], previous_status=old["status"], new_status=new_by[old["name"]]["status"], rerun_at=time.strftime("%Y-%m-%dT%H:%M:%S")))
                merged.append(new_by.pop(old["name"]))
            else:
                merged.append(old)
        merged += list(new_by.values())            # entries that did not exist before (e.g. the 32-channel group)
        results = merged
    summary = {s: sum(1 for r in results if r["status"] == s) for s in ("PASS", "FAIL", "DEPENDENCY_MISSING")}
    out.with_suffix(".json").write_text(json.dumps(dict(project="SILICAFLUX HBMCORE", generated=time.strftime("%Y-%m-%dT%H:%M:%S"),
                                                         summary=summary, merged_reruns=reruns,
                                                         results=[{k: v for k, v in r.items() if k != "log"} for r in results]), indent=2))
    xml = ['<?xml version="1.0"?>', f'<testsuite name="hbmcore" tests="{len(results)}" failures="{summary["FAIL"]}" errors="{summary["DEPENDENCY_MISSING"]}">']
    for r in results:
        xml.append(f'  <testcase classname="{xs.escape(r["group"])}" name="{xs.escape(r["name"])}" time="{r["seconds"]}">')
        if r["status"] == "FAIL": xml.append(f'    <failure message="failed">{xs.escape(r.get("log", "")[-1500:])}</failure>')
        if r["status"] == "DEPENDENCY_MISSING": xml.append(f'    <error message="{xs.escape(r["detail"])}"/>')
        xml.append("  </testcase>")
    xml.append("</testsuite>")
    out.with_suffix(".xml").write_text("\n".join(xml) + "\n")
    md = ["# Regression result (generated by scripts/regress.py)", "", f"summary: {summary}", "", "| group | test | status | seconds |", "|---|---|---|---|"]
    md += [f"| {r['group']} | {r['name']} | {r['status']} | {r['seconds']} |" for r in results]
    if reruns:
        md += ["", "Entries that were re-run after a fix and merged into this file (their earlier result is replaced; listed for transparency):", "",
               "| test | previous | now |", "|---|---|---|"] + [f"| {x['name']} | {x['previous_status']} | {x['new_status']} |" for x in reruns]
    out.with_suffix(".md").write_text("\n".join(md) + "\n")
    print("SUMMARY", summary)
    return 1 if summary["FAIL"] or summary["DEPENDENCY_MISSING"] else 0


if __name__ == "__main__":
    sys.exit(main())
