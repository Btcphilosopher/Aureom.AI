# VectorCore trace replay: RTL vs independent Python scheduler model

MODELLED (hypothetical profile 1, 4 channels, bank-aware map). The Python scheduler is a transaction-level sanity reference, not a cycle-exact twin.

| workload | map hash | accesses | RTL GB/s | Python GB/s | RTL / Python | RTL row-hit | Python row-hit | RTL mean latency | DRAM violations (RTL / python model) |
|---|---|---|---|---|---|---|---|---|---|
| copy_mixed | off | 16,384 | 21.3 | 22.8 | 0.93 | 0% | 0% | 202 | 0 / 0 |
| copy_mixed | on | 16,384 | 21.3 | 22.8 | 0.93 | 0% | 0% | 202 | 0 / 0 |
| dense_matvec | off | 65,792 | 26.4 | 27.0 | 0.98 | 38% | 38% | 176 | 0 / 0 |
| dense_matvec | on | 65,792 | 26.4 | 27.0 | 0.98 | 38% | 38% | 176 | 0 / 0 |
| fp32_seq_read | off | 2,048 | 34.2 | 40.3 | 0.85 | 0% | 1% | 131 | 0 / 0 |
| fp32_seq_read | on | 2,048 | 34.2 | 40.3 | 0.85 | 0% | 1% | 131 | 0 / 0 |
| fp32_strided | off | 8,192 | 4.8 | 4.9 | 0.98 | 0% | 0% | 128 | 0 / 0 |
| fp32_strided | on | 8,192 | 4.8 | 4.9 | 0.98 | 0% | 0% | 128 | 0 / 0 |
| fp64_triad | off | 12,288 | 16.9 | 17.6 | 0.96 | 0% | 0% | 254 | 0 / 0 |
| fp64_triad | on | 12,288 | 16.9 | 17.6 | 0.96 | 0% | 0% | 254 | 0 / 0 |
| gather_fp32 | off | 8,192 | 45.6 | 51.0 | 0.89 | 1% | 1% | 105 | 0 / 0 |
| gather_fp32 | on | 8,192 | 43.8 | 48.8 | 0.90 | 1% | 1% | 105 | 0 / 0 |
| sparse_random | off | 8,192 | 37.1 | 40.0 | 0.93 | 0% | 0% | 115 | 0 / 0 |
| sparse_random | on | 8,192 | 38.3 | 43.0 | 0.89 | 0% | 0% | 117 | 0 / 0 |
| spmv_csr | off | 14,867 | 38.6 | 44.4 | 0.87 | 11% | 11% | 115 | 0 / 0 |
| spmv_csr | on | 14,867 | 37.4 | 44.0 | 0.85 | 11% | 11% | 116 | 0 / 0 |
